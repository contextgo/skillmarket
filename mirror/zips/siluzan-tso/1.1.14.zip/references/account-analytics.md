# 账户分析数据拉取与周期报告

> 所属 skill：`siluzan-tso`。
>
> 本文档说明如何通过 CLI 拉取 **Google / Meta / TikTok / Bing** 的账户分析数据，供撰写**分析报告、诊断报告**使用。  
> **TSO 平台生成的优化报告**（`report list` / `create` / `push`）见 `references/reporting.md`。

---

## 默认做法

1. **先确认统计区间**：除非用户已明确给出起止日期，否则**必须先反问**时间范围（例如"本月 1 号到昨天？还是自定义 YYYY-MM-DD 起止？"），**不得擅自默认**（参见 SKILL.md 的"时间范围强制反问"）。
2. 询问用户需要生成哪些维度的报告，或直接生成默认报告：包含以下维度：执行摘要、每日投放趋势、月度汇总、广告系列表现、设备分布、地域分布、关键词表现、优化建议
3. 确定报告需要如何分析请查看（`report-templates/README.md`）
4. **数值与表格（各格式通用）**：在 **`google-analysis … --json-out`** 快照目录就绪后，须通过 **编写并执行代码**（Node.js / Python 等，配合 `fs`/`json`、表格/统计类库或 `node -e` 短脚本）**从磁盘读取** `manifest.json` 与各 `*.json`，在进程内完成筛选、聚合、排序等计算；**不得**依赖大模型用 `Read` 看 JSON 后在对话里「心算」或手填报告数字（无论最终是 HTML、Excel、PDF、PPT 还是 Markdown）。
5. **报告产物（交付文件）**：最终文件须由 **上述代码** 写出或调用库生成，形态包括但不限于 **HTML、Excel（`.xlsx` 等）、PDF、PowerPoint（`.pptx`）、Markdown（`.md`）** 等，按用户或场景选择；其中 **HTML** 可对齐 `report-templates/report-template.html` 的结构与 class 作为版式参考。**禁止**由大模型在对话中直接输出带真实指标的完整交付稿（整页 HTML、整表粘贴、可执行文件内容等）。HTML→PDF、表格→PDF 等转换可由同一脚本链或外部工具完成。
6. **代码中的数据纪律**：生成报告用的脚本里 **禁止** 以源码字面量形式写死任何应从 JSON 读取的业务数据（示例：具体消耗金额、系列名与对应指标、与当次 CLI 无关的日期区间、货币代码等）。允许的「常量」仅限：由参数/环境变量传入的快照目录路径、JSON **字段键名**（如 `"spend"`）、各格式下的**版式/结构**占位（HTML 标签与 class、Markdown 标题层级、空表头样式等）、与具体账户/投放结果无关的纯格式串。
7. 若交付 **PDF**：可由代码先写中间格式（如 HTML/Office）再转换，或使用 PDF 库直接绘制；确保图中的数字仍来自 JSON 计算结果。
8. 交付后使用相应应用或浏览器帮用户打开报告（如 `.html` / `.pdf` / `.pptx` / `.xlsx`）。
9. **报告首行**（须出现在主交付物**可见正文**中，如 HTML 页眉、PDF/Markdown 首段、Excel 只读说明表首行等）：`统计区间：YYYY-MM-DD ~ YYYY-MM-DD（货币：XXX）`，须由脚本从 JSON（如 `overview.json` / `manifest` 所反映的区间与 `currencyCode`）**拼接写入**，不得手写常量冒充。
10. **Google 账户分析拉数**：统一使用 **`google-analysis … --json-out <目录>`** 落盘；详见「Google 分析快照工作流」。

用于按账户维度拉取 Google Ads 报表、结构类数据。

## Google 分析快照工作流（推荐）

**目的**：把「拉数结果」变成磁盘上的**单一事实源**；Agent **只负责编写/迭代可执行脚本与模板骨架**，由程序 **读取 JSON → 计算 → 写报告产物**（HTML / Excel / PDF / PPT / Markdown 等），避免整包 JSON 进对话、避免模型凭记忆填数或整份生成带真实数据的交付文件。

**约定步骤**：

1. 选定或创建本机空目录作为本次分析的 **run 目录**（例如 `./siluzan-snapshots/run-20260429-google-<mediaCustomerId>`）。
2. 按报告维度多次执行 **`siluzan-tso google-analysis <子命令> -a <id> [--start/--end] --json-out <run目录>`**；每执行一次，目录内会新增或覆盖 **`<子命令>.json`**，并更新 **`manifest.json`**（含 `accountId`、统计区间、`artifacts[]` 与字段说明引用）。
3. **编写数据处理脚本**：用 Node.js、Python 等读取 **`manifest.json`** 与各数据文件路径（路径由**命令行参数或环境变量**传入脚本，勿在源码里写死用户机器绝对路径常量）；用标准库或数据处理库（如按语言选用表格/统计工具）完成报告所需的过滤、分组、求和、排序等；**所有写入交付文件的展示用数值与文案中的数字**（表格单元格、图表数据系列、Markdown 正文中的数等）均须来自本次运行读入的 JSON 对象字段，**不得**在源码中另写一份「示例数据」常量。
4. **由脚本写出报告文件**：按选定格式使用相应库写出 **`.html` / `.xlsx` / `.pdf` / `.pptx` / `.md`** 等（例如 HTML 可对齐 `report-templates/report-template.html` 仅作版式参考；Excel 用 `openpyxl` / `xlsx` 等写入单元格；PPT/PDF 用各语言生态中的库生成）。**禁止**让大模型在对话中直接打印完整交付文件正文。
5. **stdout（CLI）**：使用 `--json-out` 时，CLI 不在 stdout 输出整包 JSON，只输出 **一行摘要 JSON**（含 `absoluteSnapshotDir`、`writtenFiles`、`section` 等）；完整数据一律从**落盘文件**读取。

**清单文件**：

- **Google `google-analysis`**：目录根下 **`manifest.json`**（与 `google-analysis-api` 类型说明对应）。
- **Meta / TikTok / Bing `report …` 账户分析子命令**：同一约定下使用 **`report-manifest.json`** + 各 `*.json`（如 `meta-overview.json`、`tiktok-overview.json`），便于与 Google 快照分文件维护。

**`manifest.json` / `report-manifest.json` 中的字段说明引用**：`fieldGuide.markdownRefs` 指向本 Skill 的 `references/account-analytics.md`；Google 路径另含 `tsTypesModule` 指向 CLI 类型模块名（供维护者对照字段含义）。

**评测 / CI**：仓库内 `skill-eval` 命题与命令字串门禁以 **`tso-cli/eval/scenarios`** 为准；本 Skill 正文以 **`--json-out`** 为账户分析拉数规范。

### 与「只用 Read」的区别（必读）

- **不推荐**：用 `Read` 打开 JSON 后，由模型在回复里写 HTML / 贴 Excel 表 / 长篇 Markdown 报告——易产生截断、抄错、与 CLI 不一致。
- **推荐**：模型产出的是 **可运行的 `.mjs` / `.py` / `.ts` 等**（及可选的**无业务数据**的版式模板壳），由 **`node` / `python` 在 Bash 中执行**，从快照目录读入 JSON 再写 **选定格式的报告文件**；审查时检查源码中**是否出现业务数据字面量**（应无）。

## 报告中的硬约束（必须遵守）

### 账户状态 ≠ 广告系列状态（出报告最高优先级）

**常见错误**：Agent 看到 `stats`、`balance` 或账户列表里 `status: Enabled`（或「账户正常」），就在报告中把**广告系列**写成「启用」「在投」。这会导致**已暂停、已结束排期或已从投放层面移除**的系列被误标为启用。

| 含义 | 数据来源（示例） | `status` / 状态字段表示什么 |
|------|------------------|-----------------------------|
| **广告账户**是否在媒体侧关联可用、能否拉数 | `stats`、`balance`、`list-accounts` | 账户级启用/可用，**不描述单个系列是否在投** |
| **广告系列**是否暂停、是否在排期内可投放 | **`ad campaigns`**（含 `statusDisplay` 等）、系列维报表 | 系列级启停；**唯一**用于写「某系列启用/暂停」 |

**写报告时的硬性规则**：

1. **禁止**用 `stats` / `balance` / `list-accounts` 返回的账户 `status` 推断或概括**广告系列**是否启用；不得在报告正文写「根据账户状态，各系列均为启用」这类表述（除非已逐条用 `ad campaigns` 核对）。
2. **凡是**描述「某广告系列是否投放 / 启用 / 暂停 / 移除」，**必须**基于 **`google-analysis campaigns --json-out <dir>`** 落盘后的系列数据，或 **`ad campaigns`** 拉取并以与上文相同的**快照落盘**方式供脚本解析（字段键名以当次 CLI 响应为准；详见 `references/google-ads.md`）。账户总览里的消耗/点击可以与系列表并列，但**系列状态列不得来自账户接口**。
3. 若报告中有「账户概况」与「广告系列明细」两块：前者可用账户级接口；后者**系列状态列只能**来自系列级接口（如 `statusDisplay`），与账户 `status` **不得混为一谈**。

**一句话**：账户「能用 / Enabled」≠ 系列「在投」；系列是否启用只看系列级数据（首推 `ad campaigns`）。

### 品牌名 / 公司名来源

生成带品牌名、方案、邮件、广告文案的报告时，**严禁自行生成品牌名（包括中文译名、拼音、意译）**。品牌名必须来自以下来源之一，按优先级：

1. 用户在对话里明确给出的品牌名
2. `list-accounts` 结构化输出中的 `mag.advertiserName` 字段（用法见 `references/accounts.md`）
3. 用户仅提供网址时：**使用域名本身作为占位**（例如 `hy-steelpipe.com`），并在交付物里用 `[待确认品牌名]` 标注，让用户补充

反面案例（**绝对禁止**）：

- `https://hy-steelpipe.com/` → 自行臆造成"华悦钢管 / 海悦钢管"
- `list-accounts` 拿到 `advertiserName: "ABC Steel"`，报告里写成"ABC 钢铁公司"

### 金额单位

- 所有金额字段必须使用命令返回的 `*Display` 字段或已转换后的主币种数值（例如 `budgetDisplay`、主币种消耗），**不得**将 `budget` / `maxCPCAmount` 等 `×100` 分单位直接当作金额展示（否则会出现"¥50 日预算被写成 ¥5000"的错误）。
- 金额保留 2 位小数并带货币代码（示例：`¥50.00 CNY` / `$200.00 USD`）。
- 货币代码从响应 `currencyCode` 字段读取；不要混用多账户货币——必要时**分币种分表**。

### 预算建议

- 方案里给出的"日预算 / 月预算 / 预估消耗"必须基于：当前账户实际预算（`budgetDisplay`）、历史日均消耗、用户给的预算上限。
- 不要拍脑袋给出明显不符合账户规模的预算（例如账户日均 ¥50 的情况下建议 ¥5000/日）。若数据不足以判断，请**在报告里写明"建议区间需用户确认"**，而不是直接给一个高风险数字。

## Google 账户分析数据接口

### 指标字段对照

多条报表行的原始体里，消耗类指标常用下列字段名（调用方若要做统一展示，可按此对照；**以实际响应为准**）：

| 常见展示名   | 响应中常见字段名    |
| ------------ | ------------------- |
| 消耗         | `spend`             |
| 展示         | `impressions`       |
| 点击         | `clicks`            |
| 转化         | `conversions`       |
| 点击率       | `ctr`               |
| 转化率       | `conversionRate`    |
| 平均点击成本 | `averageCpc`        |
| 转化成本     | `costPerConversion` |

---

### CampaignSectionData（`campaigns[]`）

**CLI**：Google 为 `siluzan-tso google-analysis campaigns`；TikTok 为 `siluzan-tso report tiktok-campaigns`（另带 `take`，默认 100）。

`campaigns` 数组每一行在既有指标外，另包含：

| 字段 | 说明 |
| --- | --- |
| `conversionsValue` | 转化价值 |
| `conversionsValuePerCost` | 转化价值相对消耗；接口按 **`conversionsValue / spend`** 计算，当 **`spend ≤ 0`** 时为 **`0`** |
| `campaignTargetCpaMicros` | 系列目标 CPA（微货币单位） |
| `maximizeConversionsTargetCpaMicros` | 「尽可能提高转化次数」下的目标 CPA（微货币单位） |
| `manualCpcEnhancedCpcEnabled` | 人工 CPC 是否启用增强 CPC |
| `percentCpcEnhancedCpcEnabled` | 百分比 CPC 是否启用增强 CPC |

展示微货币字段时须按账户 `currencyCode` 换算为金额，**不要**把 micros 直接当元展示。

---

### campaign-hour（系列按小时）

**CLI**：`siluzan-tso google-analysis campaign-hour -a <mediaCustomerId> [--start YYYY-MM-DD --end YYYY-MM-DD] --json-out <dir>`

响应体为 **JSON 数组**（非 `{ campaigns: … }` 包装）。元素常见字段：

| 字段 | 说明 |
| --- | --- |
| `campaignId` | 广告系列 ID |
| `campaignName` | 广告系列名称 |
| `date` | 日期 |
| `hour` | 小时 |
| `spend` | 消耗 |
| `impressions` | 展示 |
| `clicks` | 点击 |
| `conversions` | 转化 |

---

### google-analysis



> **路由（重要）**：用户要「关键词花费 / 点击 / 转化 / CPA」等**搜索关键词维度**表现时，须用 **`siluzan-tso google-analysis keywords -a <mediaCustomerId> [--start/--end] --json-out <dir>`**。不要用 `ad keywords` 代替（后者偏结构/出价与列表字段，与命题中的「账户内关键词报表」不是同一路径）。

```text
siluzan-tso google-analysis <子命令> -a <mediaCustomerId> [选项]
```

**通用选项**

| 选项                | 说明                                                                                       |
| ------------------- | ------------------------------------------------------------------------------------------ |
| `-a, --account`     | Google `mediaCustomerId`（必填）                                                         |
| `--start` / `--end` | 统计区间；**须同传或同省略**（省略则默认近 7 天截至昨天）；无日期子命令见上表「不要传」说明 |
| `--json-out <dir>`  | **必选（本 Skill）**：将 JSON 写入目录下 `<子命令>.json` 并更新 **`manifest.json`**；stdout 仅一行摘要 JSON |
| `-t, --token`       | 鉴权 Token（可选，默认读配置）                                                             |
| `--verbose`         | 打印详细错误                                                                               |

**子命令与拉数路径**

| 子命令               | 说明                                                                                    |
| -------------------- | --------------------------------------------------------------------------------------- |
| `overview`           | 总览 `OverviewSectionData`                                                              |
| `keywords`           | 关键词 `KeywordSectionData`；可选 `--limit`、`--no-order-by-cost`                       |
| `search-terms`       | 搜索词 `searchtermmanagement/v2/list`；同上                                             |
| `campaigns`          | 系列 `CampaignSectionData`                                                              |
| `campaign-hour`      | 系列按小时 `campaign-hour`（`?startDate=&endDate=`；**根为 JSON 数组**）                 |
| `ads`                | 广告 `admanagement/v2/list`                                                             |
| `extensions`         | 附加信息 `extensionmanagement/v2/list`；可选 `--level`（Account / Campaign / Ad Group） |
| `devices`            | 设备 `DeviceSectionData`                                                                |
| `geographic`         | 地域 `GeographicSectionData`                                                            |
| `audience`           | 受众 `AdGroupAudienceData`；可选 `--audience-type SystemDefined \| UserDefined`         |
| `asset-images`       | 图片素材 `CampaignAssetView`                                                            |
| `videos`             | 视频 `Videos`                                                                           |
| `materials`          | 合并 `CampaignAssetView` + `Videos`（一次输出 `{ images, videos }`）                    |
| `resource-counts`    | 结构 `resource-counts`                                                                  |
| `conversion-actions` | 转化动作                                                                                |
| `daily-metrics`      | 按日 `reports`                                                                          |
| `gold-account`       | 黄金账户 `GoldAccountData`                                                              |
| `ads-index`          | 质量指标 `AdsIndexData`                                                                 |
| `final-urls`         | 最终到达网址（**不要**传 `--start`/`--end`）                                            |
| `dimension-summary`  | 账户汇总 `reports/combined`                                                             |
| `campaign-types`     | 系列类型（**不要**传 `--start`/`--end`）                                                |

`ads` 与 **`ad list`** 同源；带日期区间时创意可能 **按日多行**，宿主编排（降价/扩量/A/B）见 **`references/hosted-automation-optimize-index.md`**。

**示例**

```bash
mkdir -p ./snap-google
siluzan-tso google-analysis overview -a 6326027735 --start 2026-03-01 --end 2026-03-31 --json-out ./snap-google
siluzan-tso google-analysis keywords -a 6326027735 --limit 50 --json-out ./snap-google
siluzan-tso google-analysis campaign-hour -a 6326027735 --start 2026-03-01 --end 2026-03-07 --json-out ./snap-google
siluzan-tso google-analysis final-urls -a 6326027735 --json-out ./snap-google
```

**CPC / 花费异常巡检（先查后停）**：用户要先定位异常再考虑暂停时，在确认统计区间后，优先用 `google-analysis` 拉**带花费/CPC 粒度**的数据（如 `campaigns`、`campaign-hour`、`daily-metrics`、`keywords` 等，按 CLI `siluzan-tso google-analysis --help` 选择子命令），**不要**在未拉数前就把暂停阈值与写操作一并推进；暂停类命令须遵守 `references/google-ads.md` 的确认流程。

---

## Meta 账户分析总览（TSO）

```bash
siluzan-tso report meta-overview -a <mediaCustomerId> [--start YYYY-MM-DD --end YYYY-MM-DD] --json-out <dir>
```

`--start` / `--end` 须**同传或同省略**；省略时默认**近 7 天（截至昨天）**，与 `google-analysis` 日期规则一致。

响应结构可与 Google 总览类比（如 `accountId`、`totalCost`、`currentPeriod` / `previousPeriod`、`optimizationScore` 等），**以实际 JSON 为准**。

**报告模板**：`report-templates/meta-period-report.md`

---

## TikTok 账户分析（TSO）

与周期报告常见数据块对应关系见 **`report-templates/tiktok-period-report.md`**。

| 子命令                          | HTTP 段 / 说明                                                                                     |
| ------------------------------- | -------------------------------------------------------------------------------------------------- |
| `report tiktok-overview`        | `.../OverviewSectionData?startDate=&endDate=`                                                      |
| `report tiktok-campaigns`       | `.../CampaignSectionData?startDate=&endDate=&take=`（默认 `take=100`）                             |
| `report tiktok-ad-groups`       | `.../AdGroupReport?...`                                                                            |
| `report tiktok-ads`             | `.../AdReport?...`                                                                                 |
| `report tiktok-videos`          | `.../VideoReport?...`                                                                              |
| `report tiktok-audience`        | `.../AudienceReport?...&dimensions=` + `-d` 取值见 CLI 帮助（gender / age / interest_category 等） |
| `report tiktok-audience-merged` | 同上接口三次（`gender`、`age`、`interest_category`），**合并输出 JSON**                            |
| `report tiktok-areacode`        | `GET {mainApiUrl}/query/media-account/tiktok/TikTokAreacode/Read`                                  |
| `report tiktok-interest-list`   | `{tiktokApiUrl}/.../GetInterestList?mediaCustomerId=`（需配置 `tiktokApiUrl`）                     |

**日期与鉴权**：`--start` / `--end` 须**同传或同省略**；省略时默认**近 7 天（截至昨天）**。鉴权与 TSO 其他接口相同。

**示例**

```bash
mkdir -p ./snap-tt
siluzan-tso report tiktok-overview -a 1234567890 --json-out ./snap-tt
siluzan-tso report tiktok-campaigns -a 1234567890 --start 2026-03-01 --end 2026-03-31 --take 50 --json-out ./snap-tt
siluzan-tso report tiktok-audience -a 1234567890 -d gender --json-out ./snap-tt
siluzan-tso report tiktok-audience-merged -a 1234567890 --start 2026-03-01 --end 2026-03-07 --json-out ./snap-tt
siluzan-tso report tiktok-areacode --json-out ./snap-tt
```

---

## Bing（BingV2）账户分析（TSO）

章节与数据块对照见 **`report-templates/bing-period-report.md`**。

**重要（日期）**：Bing 报表**不能包含「今天」或「昨天」**（接口限制，与 Web 端校验一致）。`--start` / `--end` 须**同传或同省略**；**省略时** CLI 默认区间为**截至前天**的近 7 天（避免误含昨天）。

| 子命令                        | HTTP 段 / 说明                                                                      |
| ----------------------------- | ----------------------------------------------------------------------------------- |
| `report bing-overview`        | `.../OverviewSectionData?startDate=&endDate=`                                       |
| `report bing-device`          | `.../DeviceSectionData?...`                                                         |
| `report bing-geographic`      | `.../GeographicSectionData?...`                                                     |
| `report bing-age-audience`    | `.../AgeAudienceData?...`                                                           |
| `report bing-gender-audience` | `.../GenderAudienceData?...`                                                        |
| `report bing-audience-merged` | 上两项并行拉取，**合并输出 JSON**                                                   |
| `report bing-campaigns`       | `.../CampaignReport?...`                                                            |
| `report bing-ad-groups`       | `.../AdGroupReport?...`                                                             |
| `report bing-ads`             | `.../AdReport?...`                                                                  |
| `report bing-keywords`        | `.../KeywordReport?startDate=&endDate=&limit=&orderByCost=true`（默认 `limit=100`） |
| `report bing-search-terms`    | `.../SearchQueryReport?...`（同上）                                                 |

**示例**

```bash
mkdir -p ./snap-bing
siluzan-tso report bing-overview -a <mediaCustomerId> --json-out ./snap-bing
siluzan-tso report bing-keywords -a <mediaCustomerId> --start 2026-03-01 --end 2026-03-20 --limit 50 --json-out ./snap-bing
siluzan-tso report bing-audience-merged -a <mediaCustomerId> --json-out ./snap-bing
```

---

## 报告模板与输出形式

**报告产物**：除传统 **HTML → PDF** 外，可按需交付 **Excel**（便于用户二次透视）、**原生 PDF**、**PPT**（汇报）、**Markdown**（纳入文档库）等；**数据口径与数值来源仍须与快照 JSON 一致**，且由代码写入，规则见上文「默认做法」「快照工作流」。

报告输出内容参考 **`report-templates/`**：

- `report-templates/google-period-report.md` — 单周期汇总报告章节
- `report-templates/google-account-diagnosis-report.md` — 诊断类报告章节（纲要）
- `report-templates/google-ads-diagnosis.md` — 与网页版《Google Ads 账户诊断报告》**章节与数据块对齐**的完整骨架
- `report-templates/meta-period-report.md` — Meta（Facebook）周期报告纲要（当前仅总览）
- `report-templates/tiktok-period-report.md` — TikTok 周期报告纲要（与 `report tiktok-*` 对齐）
- `report-templates/bing-period-report.md` — Bing（BingV2）分析纲要（与 `report bing-*` 对齐）
- `report-templates/README.md` — 索引与规则

`report-templates` 目录下的 `.html` 文件（如 `report-template.html`、`report-template-academic.html` 等）为 **HTML 路线**的样式参考；选 **HTML** 交付时可先生成 `.html` 再转 PDF。选 **Excel / PPT / 纯 MD** 等时，仍以各 `*.md` 纲要为**章节与数据块清单**，用代码把 JSON 映射到对应格式的表格与幻灯片占位。

> **分析报告做法**：按 `google-period-report.md`（或对应媒体 `*.md`）中的默认维度拉数撰写，同时列出可选追加维度询问用户。**TSO 优化报告**（`report list` / `create` / `push`）不走此流程，详见 `references/reporting.md`。  
> 报告内容以各 `*.md` 纲要为准；若交付 **HTML**，`report-template*.html` 仅提供样式，如未另行指定，默认对齐 `report-templates/report-template.html` 的区块结构与视觉风格。
