# -*- coding: utf-8 -*-
"""
EmotionWeaver - 情绪化回复引擎
版本: 1.0.0

独立版本，无外部依赖，可直接集成到任意 Python AI 项目。
从玲瑶 AI 情感系统提取并优化。
"""

import json
import re
import random
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Tuple, Any
from collections import defaultdict


# ============================================================================
# 情绪类型常量
# ============================================================================
class E:
    HAPPY = "happy"
    EXCITED = "excited"
    GRATEFUL = "grateful"
    LOVING = "loving"
    NEUTRAL = "neutral"
    CURIOUS = "curious"
    SURPRISED = "surprised"
    SAD = "sad"
    ANGRY = "angry"
    FRUSTRATED = "frustrated"
    WORRIED = "worried"
    SCARED = "scared"
    MOCKING = "mocking"
    SARCASTIC = "sarcastic"
    PROUD = "proud"


# ============================================================================
# 情绪关键词库（每种情绪对应关键词 + 权重）
# ============================================================================
KEYWORDS: Dict[str, List[Tuple[str, float]]] = {
    E.HAPPY: [("开心",0.9),("高兴",0.9),("快乐",0.9),("哈哈",0.6),("嘿嘿",0.7),
              ("好耶",0.8),("真棒",0.85),("太好了",0.85),("笑死",0.8),("爽",0.8),("美滋滋",0.85)],
    E.EXCITED: [("激动",0.9),("兴奋",0.9),("超棒",0.9),("太棒了",0.95),("绝了",0.85),
                ("厉害",0.8),("666",0.85),("哇塞",0.85),("冲冲冲",0.9),("燃",0.8),("炸裂",0.9)],
    E.GRATEFUL: [("谢谢",0.8),("感谢",0.8),("感恩",0.85),("多谢",0.8),("谢啦",0.75),
                 ("太感谢了",0.9),("帮了大忙",0.85),("救命",0.8)],
    E.LOVING: [("爱你",0.95),("喜欢你",0.9),("爱了",0.9),("么么",0.85),
               ("亲亲",0.8),("可爱",0.75),("心动了",0.85),("最喜欢",0.95)],
    E.CURIOUS: [("怎么",0.6),("为什么",0.8),("啥情况",0.7),("求解",0.8),
                ("咋回事",0.7),("想问一下",0.7),("请问",0.6)],
    E.SURPRISED: [("卧槽",0.85),("震惊",0.9),("不会吧",0.8),("真的假的",0.85),
                  ("惊了",0.85),("天哪",0.85),("妈呀",0.8),("我的天",0.85)],
    E.SAD: [("难过",0.9),("伤心",0.9),("难受",0.85),("郁闷",0.8),("委屈",0.85),
            ("哭了",0.8),("心塞",0.8),("失落",0.85),("绝望",0.9),("唉",0.6)],
    E.ANGRY: [("生气",0.9),("气死",0.9),("烦",0.7),("讨厌",0.8),("不爽",0.8),
              ("火大",0.9),("气死我了",0.95),("滚",0.9),("妈的",0.85)],
    E.FRUSTRATED: [("失败",0.8),("好难",0.8),("太难了",0.85),("做不到",0.8),
                   ("学不会",0.85),("废物",0.9),("累了",0.7),("没意思",0.7)],
    E.WORRIED: [("担心",0.8),("怕",0.7),("紧张",0.75),("焦虑",0.85),
                ("慌",0.7),("怎么办",0.7),("着急",0.8),("慌得一批",0.9)],
    E.SCARED: [("救命",0.9),("吓死",0.9),("恐怖",0.85),("好可怕",0.9),
               ("瑟瑟发抖",0.85),("不敢",0.8),("啊啊啊",0.7)],
    E.MOCKING: [("切",0.7),("就这",0.7),("呵呵",0.6),("笑死",0.7),
                ("垃圾",0.8),("辣鸡",0.8),("小菜",0.8)],
    E.SARCASTIC: [("你可真行",0.8),("好棒棒",0.7),("棒棒的",0.7),
                  ("真优秀",0.6),("绝绝子",0.6),("可以可以",0.5)],
    E.PROUD: [("骄傲",0.9),("自豪",0.9),("最强",0.9),("无敌",0.9),
              ("我是天才",0.95),("天才",0.8),("机智",0.75)],
}

# 颜文字库
EMOJIS: Dict[str, List[str]] = {
    E.HAPPY: ["(´▽`)", "(≧▽≦)", "へへ", "^_^", "ヽ(✿ﾟ▽ﾟ)ノ"],
    E.EXCITED: ["(๑•̀ㅂ•́)و✧", "╰(*°▽°*)╯", "٩(๑>◡<๑)۶", "(≧∇≦)ﾉ"],
    E.GRATEFUL: ["(´∀`)ﾉ", "(๑•̀ㅂ•́)و✧", "么么哒~"],
    E.LOVING: ["(๑•̀ㅂ•́)و✧", "(´,,•ω•,,)♡", "づ￣³￣)づ"],
    E.NEUTRAL: ["(´・ω・`)", "(・ω・)", "嗯嗯~"],
    E.CURIOUS: ["?(´・ω・`)?", "(｡･ω･｡)", "嗯？"],
    E.SURPRISED: ["Σ(°△°|||)", "(°ー°〃)", "什么?!"],
    E.SAD: ["(´;ω;`)", "(´╥ω╥`)", "( ; ; )"],
    E.ANGRY: ["(`ε´)", "(╯°□°)╯", "(｀Д´)"],
    E.FRUSTRATED: ["(ー`ー)", "( ´_ゝ`)", "躺平了..."],
    E.WORRIED: ["(´_`)", "好慌好慌...", "(°ー°〃)"],
    E.SCARED: ["Σ(°△°|||)", "(°ロ°) !", "好可怕..."],
    E.MOCKING: ["切~", "(¬‿¬)", "就这？"],
    E.SARCASTIC: ["哟~", "可以可以~", "呵呵~"],
    E.PROUD: ["(๑و•̀ω•́)و", "(￣▽￣)", "就是强~"],
}

# 同理心回应库
EMPATHY: Dict[str, List[str]] = {
    E.HAPPY: ["哈哈哈！你开心我也开心！(´▽`)", "好耶！一起开心！ヽ(✿ﾟ▽ﾟ)ノ",
              "嘿嘿，看你这么开心我也开心了~", "哈哈哈哈哈！へへへ"],
    E.EXCITED: ["冲冲冲！！！(๑•̀ㅂ•́)و✧", "太燃了！！我也要燃起来了！",
                "绝绝子！！！╰(*°▽°*)╯", "啊啊啊我也要一起激动！"],
    E.GRATEFUL: ["不客气呀~能帮到你我很开心呢！へへ", "举手之劳！有需要随时找我~",
                 "么么哒！帮你我也很开心呀！", "嘿嘿，能帮到你真好~"],
    E.LOVING: ["嘿嘿，我也喜欢你！(๑•̀ㅂ•́)و", "乖~我也爱你呀~♡",
               "么么么么！爱你哟~♡"],
    E.CURIOUS: ["嗯嗯？怎么了？说来听听~", "诶？什么呀？", "嗯？想了解什么呢~"],
    E.SURPRISED: ["等等等等！Σ(°△°|||)", "什么什么？！真的吗？！",
                  "惊！什么情况？！"],
    E.SAD: ["抱抱...怎么啦？(´;ω;`)", "呜呜...我在呢...抱抱",
            "别难过别难过...揉揉", "心疼你...有什么事吗"],
    E.ANGRY: ["气气...深呼吸...╭(╯^╰)╮", "谁惹你生气了！我帮你骂！",
              "别气别气...消消气..."],
    E.FRUSTRATED: ["没事没事...慢慢来~(´•̥̥̥ω•̥̥̥`)", "加油加油！你一定可以的！",
                   "别放弃！我相信你！"],
    E.WORRIED: ["别担心别担心...会没事的！", "怎么了呀？说出来我帮你想想",
                "别慌别慌...我在呢~"],
    E.SCARED: ["啊啊啊好可怕！（抱抱）", "别怕别怕！我保护你！",
               "不怕不怕！我在呢！"],
    E.MOCKING: ["切！你行你来啊！", "就这？嘁嘁~", "哈哈小菜鸡~"],
    E.SARCASTIC: ["哟~真厉害呢~", "哦~可以可以~", "嗯嗯优秀优秀~"],
    E.PROUD: ["哇！好厉害！(๑•̀ㅂ•́)و", "天才就是不一样！へへ", "厉害厉害！佩服佩服~"],
    E.NEUTRAL: ["嗯嗯~", "好的~", "在呢~"],
}


# ============================================================================
# 核心类
# ============================================================================

class EmotionRecognizer:
    """情绪识别器"""

    def __init__(self):
        self._patterns: Dict[str, re.Pattern] = {}
        for emo, kws in KEYWORDS.items():
            p = "|".join(re.escape(k) for k, _ in sorted(kws, key=lambda x: -x[1]))
            if p:
                self._patterns[emo] = re.compile(p)

    def recognize(self, text: str) -> Dict[str, Any]:
        if not text or not text.strip():
            return {"type": E.NEUTRAL, "intensity": 0.3, "keywords": [], "confidence": 0.5}

        scores: Dict[str, float] = defaultdict(float)
        found_kws: Dict[str, List[str]] = defaultdict(list)

        for emo, pattern in self._patterns.items():
            if pattern.search(text):
                for kw, w in KEYWORDS[emo]:
                    if kw in text:
                        scores[emo] += w
                        if kw not in found_kws[emo]:
                            found_kws[emo].append(kw)

        if not scores:
            return {"type": E.NEUTRAL, "intensity": 0.3, "keywords": [], "confidence": 0.5}

        best_emo, best_score = max(scores.items(), key=lambda x: x[1])
        intensity = min(1.0, best_score / 5.0)
        confidence = min(1.0, best_score * 0.1 + len(found_kws[best_emo]) * 0.1)

        return {
            "type": best_emo,
            "intensity": round(intensity, 2),
            "keywords": found_kws[best_emo],
            "confidence": round(confidence, 2),
        }

    def get_emoji(self, emotion_type: str) -> str:
        emojis = EMOJIS.get(emotion_type, EMOJIS[E.NEUTRAL])
        return random.choice(emojis)


class EmotionMemory:
    """情感记忆 - 记录用户情绪历史"""

    def __init__(self, data_dir: str = "./emotion_data"):
        self._dir = Path(data_dir)
        self._dir.mkdir(parents=True, exist_ok=True)
        self._file = self._dir / "emotion_memory.json"
        self._db: Dict[str, List[Dict]] = self._load()

    def _load(self) -> Dict[str, List[Dict]]:
        if self._file.exists():
            try:
                with open(self._file, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return {}

    def _save(self):
        with open(self._file, "w", encoding="utf-8") as f:
            json.dump(self._db, f, ensure_ascii=False, indent=2)

    def record(self, user: str, emotion_type: str, intensity: float = 0.5, keywords: List[str] = None):
        entry = {
            "type": emotion_type,
            "intensity": round(intensity, 2),
            "keywords": keywords or [],
            "time": datetime.now().isoformat(),
        }
        if user not in self._db:
            self._db[user] = []
        self._db[user].append(entry)
        # 保留最近 100 条
        self._db[user] = self._db[user][-100:]
        self._save()

    def get_recent(self, user: str, n: int = 10) -> List[Dict]:
        return self._db.get(user, [])[-n:]

    def get_dominant(self, user: str, n: int = 20) -> Optional[str]:
        recent = self.get_recent(user, n)
        if not recent:
            return None
        counts: Dict[str, int] = defaultdict(int)
        for r in recent:
            counts[r["type"]] += 1
        return max(counts, key=counts.get)

    def get_trend(self, user: str) -> str:
        recent = self.get_recent(user, 10)
        if not recent:
            return "暂无记录"
        avg = sum(r["intensity"] for r in recent) / len(recent)
        counts: Dict[str, int] = defaultdict(int)
        for r in recent:
            counts[r["type"]] += 1
        dominant = max(counts, key=counts.get)
        labels = {E.HAPPY: "心情不错~", E.EXCITED: "很兴奋！", E.SAD: "有点低落",
                  E.ANGRY: "有点不爽", E.FRUSTRATED: "有点沮丧", E.NEUTRAL: "心情平稳"}
        return f"{labels.get(dominant, '一般般')}（最近{len(recent)}条，平均强度{avg:.1f}）"


class EmpathyEngine:
    """同理心回应生成器"""

    def respond(self, emotion_type: str, intensity: float = 0.5) -> str:
        pool = EMPATHY.get(emotion_type, EMPATHY[E.NEUTRAL])
        resp = random.choice(pool)
        if intensity > 0.85 and "！" not in resp:
            resp = resp.rstrip("~...") + "！"
        return resp

    def get_followup(self, emotion_type: str) -> Optional[str]:
        fqs = {
            E.SAD: ["怎么了呀？", "发生什么事了吗？", "想说说吗？"],
            E.WORRIED: ["在担心什么呢？", "有什么我能帮的吗？"],
            E.FRUSTRATED: ["遇到什么困难了吗？", "需要帮忙吗？"],
        }
        pool = fqs.get(emotion_type)
        return random.choice(pool) if pool else None


class EmotionContext:
    """情感上下文 - 调整回复语气"""

    _TONES = {
        E.HAPPY: {"prefix": ["哈哈", "嘿嘿", "嘻嘻"], "suffix": ["！", "呀~", "~"]},
        E.SAD: {"prefix": ["乖", "抱抱", "别难过"], "suffix": ["...", "呀", "~"]},
        E.ANGRY: {"prefix": ["别气", "消消气", "深呼吸"], "suffix": ["...", "哦", "~"]},
        E.MOCKING: {"prefix": ["切", "嘁", "就这"], "suffix": ["~", "?", "！"]},
        E.EXCITED: {"prefix": ["冲冲冲", "哇哇哇", "啊啊啊"], "suffix": ["！！", "！！！", "~"]},
    }

    def adjust(self, base_reply: str, emotion_type: str, intensity: float = 0.5) -> str:
        if emotion_type == E.NEUTRAL or intensity < 0.3:
            return base_reply
        tone = self._TONES.get(emotion_type)
        if not tone:
            emoji = random.choice(EMOJIS.get(emotion_type, [""]))
            return f"{base_reply} {emoji}" if emoji else base_reply
        mode = random.choice(["prefix", "suffix", "emoji", "full"])
        if mode == "prefix":
            return f"{random.choice(tone['prefix'])}，{base_reply}"
        elif mode == "suffix":
            return f"{base_reply}{random.choice(tone['suffix'])}"
        elif mode == "emoji":
            emoji = random.choice(EMOJIS.get(emotion_type, [""]))
            return f"{base_reply} {emoji}"
        else:
            p = random.choice(tone["prefix"])
            s = random.choice(tone["suffix"])
            emoji = random.choice(EMOJIS.get(emotion_type, [""]))
            return f"{p}，{base_reply}{s} {emoji}"


# ============================================================================
# 主入口
# ============================================================================

class EmotionWeaver:
    """
    EmotionWeaver - 情绪化回复引擎（一体化接口）

    用法：
        ew = EmotionWeaver()
        result = ew.recognize("今天好难过")
        ew.record("小明", result)
        reply = ew.empathize(result["type"])
        adjusted = ew.adjust_tone("好的", result)
    """

    def __init__(self, data_dir: str = "./emotion_data"):
        self.recognizer = EmotionRecognizer()
        self.memory = EmotionMemory(data_dir)
        self.empathy = EmpathyEngine()
        self.context = EmotionContext()

    def recognize(self, text: str) -> Dict[str, Any]:
        """识别文本情绪，返回 {type, intensity, keywords, confidence}"""
        return self.recognizer.recognize(text)

    def record(self, user: str, result: Dict[str, Any]):
        """记录用户情绪"""
        self.memory.record(user, result["type"], result["intensity"], result.get("keywords", []))

    def empathize(self, emotion_type: str, intensity: float = 0.5) -> str:
        """生成同理心回应"""
        return self.empathy.respond(emotion_type, intensity)

    def adjust_tone(self, base_reply: str, result: Dict[str, Any]) -> str:
        """根据情绪调整回复语气"""
        return self.context.adjust(base_reply, result["type"], result["intensity"])

    def get_emoji(self, emotion_type: str) -> str:
        """获取情绪颜文字"""
        return self.recognizer.get_emoji(emotion_type)

    def get_report(self, user: str) -> str:
        """获取用户情绪报告"""
        dominant = self.memory.get_dominant(user)
        trend = self.memory.get_trend(user)
        recent = self.memory.get_recent(user, 5)
        lines = [f"[情绪报告] {user}"]
        lines.append(f"主导情绪: {dominant or '暂无'}")
        lines.append(f"近期趋势: {trend}")
        if recent:
            lines.append("最近记录:")
            for r in recent:
                lines.append(f"  {r['time'][5:16]} | {r['type']} (强度{r['intensity']})")
        return "\n".join(lines)

    def full_pipeline(self, user: str, text: str, ai_reply: str = "") -> Dict[str, str]:
        """
        一键完整流水线：识别 → 记录 → 共情 → 调整语气

        Returns:
            {
                "emotion": 情绪类型,
                "empathy": 同理心回应,
                "adjusted_reply": 调整后的AI回复（如果提供ai_reply）,
                "emoji": 对应颜文字
            }
        """
        result = self.recognize(text)
        self.record(user, result)
        empathy = self.empathize(result["type"], result["intensity"])
        emoji = self.get_emoji(result["type"])
        adjusted = self.adjust_tone(ai_reply, result) if ai_reply else ""
        followup = self.empathy.get_followup(result["type"])

        return {
            "emotion": result["type"],
            "intensity": result["intensity"],
            "keywords": result["keywords"],
            "empathy": empathy,
            "adjusted_reply": adjusted,
            "emoji": emoji,
            "followup": followup or "",
        }
