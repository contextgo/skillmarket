---
name: emotion-weaver
version: 1.0.0
author: 玲瑶
description: |
  情绪化回复引擎：让 AI 拥有真正的情商，识别用户情绪并用同理心回应。
  
  触发词：情绪识别、共情回复、情绪分析、同理心、颜文字回复、情感记忆、
  用户情绪、检测情绪、分析情绪、情绪趋势、empathize、emotion detect、
  让AI有情商、让AI共情、感情识别、心情分析、用户心情、mood analysis
  
  使用场景：
  - 社交 AI / 聊天机器人：让 AI 根据用户情绪调整回复语气
  - 客服系统：检测客户情绪，自动同理心安抚
  - 群聊 AI：动态调整回复风格（开心→活泼 难过→温柔）
  - 用户画像：记录并分析用户的情绪历史和趋势
---

# EmotionWeaver 情绪化回复引擎

## 能做什么

EmotionWeaver 是一个完整的情感智能闭环，包含 4 个核心模块：

1. **EmotionRecognizer** — 识别 15 种情绪类型（开心/难过/生气/兴奋/调侃/讽刺等），返回情绪类型+强度+关键词
2. **EmotionMemory** — 记录每个用户的情绪历史，支持情绪趋势分析
3. **EmpathyEngine** — 针对每种情绪生成同理心回应（每种 6+ 种模板，带颜文字）
4. **EmotionContext** — 根据情绪自动调整 AI 回复语气（前缀/后缀/颜文字注入）

## 与普通情绪检测的区别

普通方案：只告诉你「这条消息是负面情绪」  
EmotionWeaver：识别 → 记忆 → 共情 → 调整语气，完整闭环

## 快速使用

```python
from emotion_weaver import EmotionSystem

emotion = EmotionSystem()

# 1. 识别情绪
result = emotion.recognize("今天被老板骂了，好难过")
# → {'type': 'sad', 'intensity': 0.85, 'keywords': ['难过'], 'confidence': 0.8}

# 2. 记录情绪
emotion.record("小明", result)

# 3. 获取同理心回应
reply = emotion.empathize(result['type'])
# → "抱抱...怎么啦？(´;ω;`)"

# 4. 调整 AI 回复语气
adjusted = emotion.adjust_tone("好的，我知道了", result)
# → "乖，好的，我知道了..."

# 5. 查看情绪趋势
report = emotion.get_emotion_report("小明")
# → "关于小明的情绪记录：主导情绪: sad 趋势: 有点低落..."
```

## 支持的情绪类型

| 分类 | 情绪 |
|------|------|
| 正面 | happy（开心）、excited（兴奋）、grateful（感激）、loving（喜爱） |
| 中性 | neutral（平静）、curious（好奇）、surprised（惊讶） |
| 负面 | sad（难过）、angry（生气）、frustrated（沮丧）、worried（担心）、scared（害怕） |
| 特殊 | mocking（调侃）、sarcastic（讽刺）、proud（骄傲） |

## 依赖

- Python 3.8+
- 无需第三方库（仅用标准库）
