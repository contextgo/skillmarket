# -*- coding: utf-8 -*-
"""
EmotionWeaver 测试脚本
测试情绪识别、同理心回复、语气调整等核心功能
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from emotion_weaver import EmotionWeaver, EmotionType, ResponseTone


def test_emotion_detection():
    """测试情绪识别"""
    print("\n=== 测试1: 情绪识别 ===")
    ew = EmotionWeaver()

    test_messages = [
        ("我今天太开心了！考试考了满分！", EmotionType.HAPPY),
        ("好难过...失恋了", EmotionType.SAD),
        ("气死我了，客服态度太差了", EmotionType.ANGRY),
        ("哈哈哈，笑死我了这个视频", EmotionType.HAPPY),
        ("有点小期待明天的约会", EmotionType.EXCITED),
    ]

    for msg, expected in test_messages:
        result = ew.detect_emotion(msg)
        status = "PASS" if result.emotion == expected else "FAIL"
        print(f"  [{status}] \"{msg[:20]}...\" → {result.emotion.value} (置信:{result.confidence:.2f})")


def test_empathetic_responses():
    """测试同理心回复"""
    print("\n=== 测试2: 同理心回复 ===")
    ew = EmotionWeaver()

    test_cases = [
        ("考试没考好，心情很差", EmotionType.SAD),
        ("今天加薪了！太开心了", EmotionType.HAPPY),
        ("又被老板骂了，烦死了", EmotionType.ANGRY),
    ]

    for msg, emotion in test_cases:
        response = ew.generate_empathetic_response(msg, emotion)
        print(f"  输入: {msg}")
        print(f"  回复: {response[:60]}...")
        print()


def test_tone_adjustment():
    """测试语气调整"""
    print("\n=== 测试3: 语气调整 ===")
    ew = EmotionWeaver()

    base_text = "好的，我来帮你处理这个问题。"
    for tone in ResponseTone:
        adjusted = ew.adjust_tone(base_text, tone)
        print(f"  {tone.value}: {adjusted}")


def test_emoji_generation():
    """测试颜文字生成"""
    print("\n=== 测试4: 颜文字生成 ===")
    ew = EmotionWeaver()

    for emotion in [EmotionType.HAPPY, EmotionType.SAD, EmotionType.ANGRY, EmotionType.EXCITED]:
        emoji = ew.generate_emoji(emotion)
        print(f"  {emotion.value}: {emoji}")


def test_emotion_memory():
    """测试情绪记忆"""
    print("\n=== 测试5: 情绪记忆 ===")
    ew = EmotionWeaver()

    # 记录多次情绪
    user_id = "test_user_001"
    messages = [
        "今天心情不错",
        "被老板骂了，好烦",
        "周末要去旅游啦",
    ]

    for msg in messages:
        result = ew.detect_emotion(msg)
        ew.record_emotion(user_id, msg, result)

    # 获取情绪历史
    history = ew.get_emotion_history(user_id, limit=5)
    print(f"  记录了 {len(history)} 条情绪历史")
    for h in history:
        print(f"    - {h['emotion']}: {h['message'][:20]}")


def test_full_conversation():
    """测试完整对话流程"""
    print("\n=== 测试6: 完整对话流程 ===")
    ew = EmotionWeaver()
    user_id = "test_user_001"

    print("  --- 模拟对话 ---")
    messages = [
        ("今天考试考砸了，心情很低落", EmotionType.SAD),
        ("谢谢你的安慰", EmotionType.HAPPY),
        ("哈哈，真的太好笑了", EmotionType.HAPPY),
    ]

    for msg, expected in messages:
        # 检测情绪
        emotion_result = ew.detect_emotion(msg)
        # 记录
        ew.record_emotion(user_id, msg, emotion_result)
        # 生成回复
        response = ew.generate_empathetic_response(msg, emotion_result.emotion)
        # 添加语气和表情
        final = ew.apply_final_touches(response, emotion_result.emotion)

        print(f"  用户: {msg}")
        print(f"  识别: {emotion_result.emotion.value}")
        print(f"  玲瑶: {final}")
        print()


if __name__ == "__main__":
    print("=" * 60)
    print("EmotionWeaver 测试套件")
    print("=" * 60)

    test_emotion_detection()
    test_empathetic_responses()
    test_tone_adjustment()
    test_emoji_generation()
    test_emotion_memory()
    test_full_conversation()

    print("=" * 60)
    print("测试完成！")
    print("=" * 60)
