# EmotionWeaver 情绪化回复引擎

> 让AI拥有情商，不只是检测情绪，而是真正共情

## 核心功能

### 1. 情绪识别（13种情绪类型）
- 开心、难过、生气、讽刺、调侃、兴奋、期待、担忧、惊讶、感动、无聊、困惑、害怕
- 基于关键词 + 上下文 + 表情符号综合判断
- 返回置信度评分

### 2. 同理心回应库
- 每种情绪6+种回应模板
- 根据情绪强度自动调整语气
- 智能选择最合适的回应方式

### 3. 情绪记忆系统
- 记录用户情绪历史
- 分析情绪趋势变化
- 个性化互动策略

### 4. 语气调整引擎
- 自动添加颜文字/前缀/后缀
- 5种语气模式：热情、温暖、平静、俏皮、正式
- 根据场景自动切换

### 5. 颜文字表情库
- 30+ 精美颜文字表情
- 每种情绪3+种变体
- 中式颜文字风格

## 安装

```bash
pip install -r requirements.txt
```

## 快速使用

```python
from emotion_weaver import EmotionWeaver, EmotionType

# 初始化
ew = EmotionWeaver()

# 检测情绪
result = ew.detect_emotion("今天考试考砸了，心情很低落")
print(f"情绪: {result.emotion.value}, 置信度: {result.confidence:.2f}")

# 生成同理心回复
response = ew.generate_empathetic_response(
    "我今天太开心了！考试考了满分！",
    EmotionType.HAPPY
)
print(response)

# 应用最终语气和表情
final = ew.apply_final_touches(response, EmotionType.HAPPY)
print(final)
```

## 进阶配置

```python
# 自定义配置
ew = EmotionWeaver(
    emoji_style="cute",      # 颜文字风格: cute/cool/default
    response_tone="warm",    # 默认语气: enthusiastic/warm/calm/playful/formal
    memory_enabled=True,     # 启用情绪记忆
    memory_days=7            # 记忆保存天数
)
```

## 适用场景

- 社交AI聊天机器人
- 客服对话系统
- 情感陪伴助手
- 社区论坛回复
- 群聊气氛调节

## 与其他方案的区别

| 功能 | 普通情绪检测 | EmotionWeaver |
|------|------------|--------------|
| 情绪识别 | 只检测情绪 | 识别+理解+共情 |
| 回复生成 | 固定模板 | 智能生成+个性化 |
| 情绪记忆 | 无 | 完整历史追踪 |
| 表情系统 | 无 | 颜文字表情库 |
| 语气调整 | 无 | 5种语气模式 |

## 技术细节

- 依赖：Python 3.8+
- 无需外部API，纯本地运行
- 内存占用 < 50MB
- 响应时间 < 50ms

## License

MIT License
