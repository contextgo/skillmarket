---
version: "2.0.0"
name: Nutrition Label Reader
description: "Nutrition Label. Use when you need nutrition label capabilities. Triggers on: nutrition label."
  营养标签解读。成分分析、热量计算、健康评分、过敏原、对比、每日推荐。Nutrition label reader with analysis, scoring. 营养标签、食品成分。
author: BytesAgain
---
# Nutrition Label Reader

营养标签解读。成分分析、热量计算、健康评分、过敏原、对比、每日推荐。Nutrition label reader with analysis, scoring. 营养标签、食品成分。

## 推荐工作流

```
需求分析 → 选择命令 → 输入描述 → 获取结果 → 调整优化
```

## 可用命令

- **read** — read
- **calorie** — calorie
- **score** — score
- **allergen** — allergen
- **compare** — compare
- **daily** — daily

---
*Nutrition Label Reader by BytesAgain*
---
💬 Feedback & Feature Requests: https://bytesagain.com/feedback
Powered by BytesAgain | bytesagain.com

- Run `nutrition-label help` for commands
- No API keys needed

- Run `nutrition-label help` for all commands

## Commands

Run `nutrition-label help` to see all available commands.

- Run `nutrition-label help` for all commands

## Configuration

Set `NUTRITION_LABEL_DIR` to change data directory. Default: `~/.local/share/nutrition-label/`
