#!/usr/bin/env bash
# System Self-Check v2.0 — OpenClaw / MiClaw / Hermes 通用
# Usage: bash selfcheck.sh [--brief] [--json] [--fix] [--platform <name>]

set -euo pipefail

# ============================================================
# 参数解析
# ============================================================
BRIEF=false
JSON=false
FIX=false
PLATFORM=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --brief)    BRIEF=true; shift ;;
    --json)     JSON=true; shift ;;
    --fix)      FIX=true; shift ;;
    --platform) PLATFORM="$2"; shift 2 ;;
    *)          echo "Unknown option: $1"; exit 1 ;;
  esac
done

# ============================================================
# 计数器
# ============================================================
PASS=0
WARN=0
FAIL=0
TOTAL=0

# ============================================================
# 工具函数
# ============================================================
result() {
  local status="$1" module="$2" detail="$3"
  TOTAL=$((TOTAL + 1))
  case "$status" in
    pass) PASS=$((PASS + 1)) ;;
    warn) WARN=$((WARN + 1)) ;;
    fail) FAIL=$((FAIL + 1)) ;;
  esac
  if $BRIEF && [[ "$status" == "pass" ]]; then return; fi
  local icon
  case "$status" in
    pass) icon="✅" ;;
    warn) icon="⚠️" ;;
    fail) icon="❌" ;;
  esac
  if $JSON; then
    echo "{\"status\":\"$status\",\"module\":\"$module\",\"detail\":\"$detail\"}"
  else
    printf "  %-4s %-10s %s\n" "$icon" "[$module]" "$detail"
  fi
}

# 网络请求（带重试）
curl_retry() {
  local url="$1"
  local timeout="${2:-10}"
  local retries=2
  local code="" latency_s=0 start_s end_s

  for ((i=1; i<=retries; i++)); do
    start_s=$(date +%s%N 2>/dev/null || date +%s)
    code=$(curl -s -o /dev/null -w "%{http_code}" "$url" \
      --connect-timeout 5 --max-time "$timeout" 2>/dev/null || true)
    end_s=$(date +%s%N 2>/dev/null || date +%s)
    code=$(echo "$code" | tr -d '[:space:]')
    code=${code:-000}

    # 计算延迟（毫秒精度）
    if [[ ${#start_s} -gt 10 ]]; then
      latency_s=$(( (end_s - start_s) / 1000000 / 1000 ))
    else
      latency_s=$(( end_s - start_s ))
    fi

    if [[ "$code" != "000" ]]; then
      echo "$code $latency_s"
      return 0
    fi
    sleep 1
  done
  echo "000 $latency_s"
  return 1
}

# ============================================================
# 平台检测
# ============================================================
detect_platform() {
  if [[ -n "$PLATFORM" ]]; then
    echo "$PLATFORM"
    return
  fi
  if command -v openclaw &>/dev/null; then
    echo "openclaw"
  elif command -v miclaw &>/dev/null; then
    echo "miclaw"
  elif command -v hermes &>/dev/null; then
    echo "hermes"
  else
    echo "unknown"
  fi
}

DETECTED_PLATFORM=$(detect_platform)
OS=$(uname -s)

# ============================================================
# 通用检查
# ============================================================

# --- System ---
check_system() {
  local kernel cpus arch hostname_str
  kernel=$(uname -r)
  cpus=$(nproc 2>/dev/null || echo "?")
  arch=$(uname -m)
  hostname_str=$(hostname -s 2>/dev/null || echo "?")
  result pass "System" "$OS $kernel | $cpus cores | $arch | $hostname_str"
}

# --- Uptime ---
check_uptime() {
  local uptime_str
  if [[ -f /proc/uptime ]]; then
    local seconds=$(awk '{print int($1)}' /proc/uptime)
    local days=$((seconds / 86400))
    local hours=$(( (seconds % 86400) / 3600 ))
    local mins=$(( (seconds % 3600) / 60 ))
    if (( days > 30 )); then
      result warn "Uptime" "${days}d ${hours}h ${mins}m — 建议重启"
    elif (( days > 7 )); then
      result pass "Uptime" "${days}d ${hours}h ${mins}m — 较长"
    else
      result pass "Uptime" "${days}d ${hours}h ${mins}m"
    fi
  else
    uptime_str=$(uptime -p 2>/dev/null || uptime | sed 's/.*up //' | sed 's/,.*//')
    result pass "Uptime" "$uptime_str"
  fi
}

# --- Load Average ---
check_load() {
  if [[ -f /proc/loadavg ]]; then
    local load1 load5 load15 cpus
    read -r load1 load5 load15 _ < /proc/loadavg
    cpus=$(nproc 2>/dev/null || echo 1)
    # 去掉小数点做比较
    local l1=${load1%%.*}
    local l5=${load5%%.*}
    local l15=${load15%%.*}
    if (( l1 > cpus * 2 )); then
      result fail "Load" "1m=$load1 5m=$load5 15m=$load15 (cores=$cpus) — OVERLOADED"
    elif (( l1 > cpus )); then
      result warn "Load" "1m=$load1 5m=$load5 15m=$load15 (cores=$cpus) — HIGH"
    else
      result pass "Load" "1m=$load1 5m=$load5 15m=$load15"
    fi
  else
    result pass "Load" "N/A (no /proc/loadavg)"
  fi
}

# --- Memory ---
check_memory() {
  if [[ "$OS" == "Linux" ]]; then
    local total available pct swap_total swap_used
    total=$(free -m | awk '/Mem:/ {print $2}')
    available=$(free -m | awk '/Mem:/ {print $7}')
    pct=$((available * 100 / total))
    swap_total=$(free -m | awk '/Swap:/ {print $2}')
    swap_used=$(free -m | awk '/Swap:/ {print $3}')

    local detail="${total}M total / ${available}M available (${pct}%)"
    if (( pct < 10 )); then
      result fail "Memory" "$detail — CRITICAL"
    elif (( pct < 30 )); then
      result warn "Memory" "$detail — LOW"
    else
      result pass "Memory" "$detail"
    fi

    # Swap 检查
    if (( swap_total > 0 )); then
      local swap_pct=$((swap_used * 100 / swap_total))
      if (( swap_pct > 80 )); then
        result warn "Swap" "${swap_used}M / ${swap_total}M (${swap_pct}%) — HIGH"
      elif (( swap_pct > 50 )); then
        result pass "Swap" "${swap_used}M / ${swap_total}M (${swap_pct}%)"
      else
        result pass "Swap" "${swap_used}M / ${swap_total}M (${swap_pct}%)"
      fi
    else
      result pass "Swap" "No swap configured"
    fi
  else
    # macOS
    local page_size free_pages speculative_pages total_bytes avail_bytes total_mb avail_mb pct
    page_size=$(sysctl -n hw.pagesize 2>/dev/null || echo 4096)
    total_bytes=$(sysctl -n hw.memsize 2>/dev/null || echo 0)
    total_mb=$((total_bytes / 1024 / 1024))
    free_pages=$(vm_stat 2>/dev/null | awk '/Pages free/ {gsub(/\./,"",$3); print $3}')
    speculative_pages=$(vm_stat 2>/dev/null | awk '/Pages speculative/ {gsub(/\./,"",$3); print $3}')
    free_pages=${free_pages:-0}
    speculative_pages=${speculative_pages:-0}
    avail_bytes=$(( (free_pages + speculative_pages) * page_size ))
    avail_mb=$((avail_bytes / 1024 / 1024))
    if (( total_mb > 0 )); then
      pct=$((avail_mb * 100 / total_mb))
    else
      pct=100
    fi
    local detail="${total_mb}M total / ${avail_mb}M available (${pct}%)"
    if (( pct < 10 )); then
      result fail "Memory" "$detail — CRITICAL"
    elif (( pct < 30 )); then
      result warn "Memory" "$detail — LOW"
    else
      result pass "Memory" "$detail"
    fi
  fi
}

# --- Disk ---
check_disk() {
  local total used avail pct
  read -r total used avail pct <<< $(df -h / | awk 'NR==2 {print $2, $3, $4, $5}')
  local pct_num=${pct%\%}
  local avail_pct=$((100 - pct_num))
  local detail="$total total / $avail available (${pct_num}% used)"
  if (( avail_pct < 10 )); then
    result fail "Disk" "$detail — CRITICAL"
  elif (( avail_pct < 30 )); then
    result warn "Disk" "$detail — LOW"
  else
    result pass "Disk" "$detail"
  fi
}

# --- Runtime ---
check_runtime() {
  local py_ver node_ver
  py_ver=$(python3 --version 2>&1 | awk '{print $2}')
  node_ver=$(node --version 2>&1 || echo "not found")
  result pass "Runtime" "Python $py_ver | Node $node_ver"
}

# --- Core Dependencies ---
check_deps() {
  local missing=""
  local found=""

  if command -v ffmpeg &>/dev/null; then
    local ff_ver=$(ffmpeg -version 2>&1 | head -1 | awk '{print $3}')
    found+="ffmpeg $ff_ver | "
  else
    missing+="ffmpeg "
  fi

  if command -v jq &>/dev/null; then
    found+="jq ✅ | "
  else
    missing+="jq "
  fi

  if command -v curl &>/dev/null; then
    found+="curl ✅ | "
  else
    missing+="curl "
  fi

  if command -v git &>/dev/null; then
    found+="git ✅ | "
  else
    missing+="git "
  fi

  if command -v docker &>/dev/null; then
    local docker_ver=$(docker --version 2>&1 | awk '{print $3}' | tr -d ',')
    found+="docker $docker_ver ✅ | "
  fi

  # 去掉末尾的 " | "
  found=${found% | }

  if [[ -n "$missing" ]]; then
    result fail "Deps" "${found} | MISSING: $missing"
  else
    result pass "Deps" "$found"
  fi
}

# --- Docker ---
check_docker() {
  if ! command -v docker &>/dev/null; then
    return  # 没装 docker 就跳过
  fi

  # Docker daemon 状态
  if docker info &>/dev/null; then
    local containers_running=$(docker ps -q 2>/dev/null | wc -l)
    local containers_stopped=$(docker ps -aq --filter "status=exited" 2>/dev/null | wc -l)
    local images=$(docker images -q 2>/dev/null | wc -l)
    local detail="running=$containers_running stopped=$containers_stopped images=$images"
    if (( containers_stopped > 10 )); then
      result warn "Docker" "$detail — 多个停止的容器"
    else
      result pass "Docker" "$detail"
    fi
  else
    result warn "Docker" "installed but daemon not running"
  fi
}

# --- Network ---
check_network() {
  local urls=("github.com" "api.xiaomimimo.com" "clawhub.ai")
  for url in "${urls[@]}"; do
    local code latency_s
    read -r code latency_s <<< $(curl_retry "https://$url" 10)

    if [[ "$code" == "000" ]]; then
      result fail "Network" "$url — TIMEOUT"
    elif (( latency_s > 5 )); then
      result warn "Network" "$url — $code (${latency_s}s) SLOW"
    elif (( latency_s > 3 )); then
      result warn "Network" "$url — $code (${latency_s}s) — 较慢"
    else
      result pass "Network" "$url — $code (${latency_s}s)"
    fi
  done
}


# --- OpenClaw ---
check_openclaw() {
  if command -v openclaw &>/dev/null; then
    local oc_ver=$(openclaw --version 2>&1 | head -1)
    # Check latest version from npm registry
    local latest_ver=""
    if command -v curl &>/dev/null; then
      latest_ver=$(curl -s --connect-timeout 5 --max-time 10 \
        "https://registry.npmjs.org/openclaw/latest" 2>/dev/null \
        | grep -o '"version":"[^"]*"' | head -1 | cut -d'"' -f4 || echo "")
    fi
    if [[ -n "$latest_ver" && "$oc_ver" != *"$latest_ver"* ]]; then
      result warn "Platform" "OpenClaw $oc_ver (latest: $latest_ver)"
    else
      result pass "Platform" "OpenClaw $oc_ver"
    fi

    # Gateway
    local gw_status=$(openclaw gateway status 2>&1 || echo "unknown")
    if echo "$gw_status" | grep -qi "running\|active\|ok"; then
      result pass "Gateway" "Running"
    else
      result warn "Gateway" "Status: $gw_status"
    fi

    # Config
    if [[ -f ~/.openclaw/openclaw.json ]]; then
      result pass "Config" "~/.openclaw/openclaw.json exists"
    else
      result fail "Config" "~/.openclaw/openclaw.json NOT FOUND"
    fi
  else
    result fail "Platform" "openclaw command not found"
  fi
}

# --- Skills ---
check_skills() {
  local skill_dir=""
  # 尝试从 openclaw config 获取
  if command -v openclaw &>/dev/null; then
    skill_dir=$(openclaw config get skills.dir 2>/dev/null || echo "")
  fi
  # 依次尝试多个可能的路径
  local search_dirs=(
    "$skill_dir"
    "${HOME}/.openclaw/workspace/skills"
    "${HOME}/.openclaw/skills"
  )
  local found_dir=""
  for dir in "${search_dirs[@]}"; do
    [[ -z "$dir" ]] && continue
    # 处理相对路径
    [[ "$dir" != /* ]] && dir="${HOME}/.openclaw/$dir"
    if [[ -d "$dir" ]]; then
      found_dir="$dir"
      break
    fi
  done

  if [[ -n "$found_dir" ]]; then
    local count=$(ls -d "$found_dir"/*/ 2>/dev/null | wc -l)
    result pass "Skills" "$count installed ($found_dir)"
  else
    result warn "Skills" "No skills directory found"
  fi
}

# --- API Keys ---
check_api_keys() {
  local key_status=""

  if [[ -n "${MIMO_API_KEY:-}" ]]; then
    key_status+="MIMO_API_KEY ✅ | "
  else
    key_status+="MIMO_API_KEY ❌ | "
  fi

  # Check ClawHub token (in config or env)
  local clawhub_ok=false
  if [[ -n "${CLAWHUB_TOKEN:-}" ]]; then
    clawhub_ok=true
  elif [[ -f ~/.config/clawhub/config.json ]]; then
    clawhub_ok=true
  elif command -v npx &>/dev/null; then
    local whoami=$(timeout 10 npx clawhub@latest whoami 2>/dev/null || echo "")
    if [[ -n "$whoami" && "$whoami" != *"not logged"* ]]; then
      clawhub_ok=true
    fi
  fi

  if $clawhub_ok; then
    key_status+="ClawHub ✅"
  else
    key_status+="ClawHub ❌"
  fi

  # Check for any missing
  if [[ -z "${MIMO_API_KEY:-}" ]] || ! $clawhub_ok; then
    result warn "API Keys" "$key_status"
  else
    result pass "API Keys" "$key_status"
  fi
}

# ============================================================
# Platform-specific checks
# ============================================================
check_platform_specific() {
  case "$DETECTED_PLATFORM" in
    openclaw)
      check_openclaw
      check_skills
      check_api_keys
      ;;
    miclaw)
      result pass "Platform" "MiClaw detected (checks TODO)"
      ;;
    hermes)
      result pass "Platform" "Hermes detected (checks TODO)"
      ;;
    *)
      result warn "Platform" "Unknown — skipping platform checks"
      ;;
  esac
}

# ============================================================
# Auto-fix
# ============================================================
do_fix() {
  echo ""
  echo "🔧 Auto-fix mode"
  echo "━━━━━━━━━━━━━━━━"

  local fixed=0

  # Fix missing jq
  if ! command -v jq &>/dev/null; then
    echo "  Installing jq..."
    if apt-get install -y jq 2>/dev/null; then
      echo "  ✅ jq installed"
      fixed=$((fixed + 1))
    else
      echo "  ❌ jq install failed (apt may be unreachable)"
    fi
  fi

  # Fix missing curl
  if ! command -v curl &>/dev/null; then
    echo "  Installing curl..."
    if apt-get install -y curl 2>/dev/null; then
      echo "  ✅ curl installed"
      fixed=$((fixed + 1))
    else
      echo "  ❌ curl install failed"
    fi
  fi

  # Fix missing git
  if ! command -v git &>/dev/null; then
    echo "  Installing git..."
    if apt-get install -y git 2>/dev/null; then
      echo "  ✅ git installed"
      fixed=$((fixed + 1))
    else
      echo "  ❌ git install failed"
    fi
  fi

  # Fix missing python3-pip
  if ! command -v pip3 &>/dev/null; then
    echo "  Installing python3-pip..."
    if apt-get install -y python3-pip 2>/dev/null; then
      echo "  ✅ python3-pip installed"
      fixed=$((fixed + 1))
    else
      echo "  ❌ python3-pip install failed"
    fi
  fi

  # Fix missing edge-tts
  if ! python3 -c "import edge_tts" 2>/dev/null; then
    echo "  Installing edge-tts..."
    if pip3 install --break-system-packages edge-tts 2>/dev/null; then
      echo "  ✅ edge-tts installed"
      fixed=$((fixed + 1))
    else
      echo "  ❌ edge-tts install failed"
    fi
  fi

  # 清理 apt 缓存
  if command -v apt-get &>/dev/null; then
    echo "  Cleaning apt cache..."
    apt-get autoremove -y 2>/dev/null && echo "  ✅ apt cache cleaned"
  fi

  echo ""
  echo "  🔧 Fixed: $fixed items"
}

# ============================================================
# Health Score
# ============================================================
calc_health_score() {
  if (( TOTAL == 0 )); then
    echo 100
    return
  fi
  # pass=100分, warn=70分, fail=0分
  local score=$(( (PASS * 100 + WARN * 70) / TOTAL ))
  echo "$score"
}

# ============================================================
# Main
# ============================================================

if ! $JSON; then
  echo ""
  echo "⚡ System Self-Check v2.0 — ${DETECTED_PLATFORM^}"
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
fi

check_system
check_uptime
check_load
check_memory
check_disk
check_runtime
check_deps
check_docker
check_network
check_platform_specific

if $FIX; then
  do_fix
fi

if ! $JSON; then
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  health_score=$(calc_health_score)
  health_icon="✅"
  health_label="良好"
  if (( health_score < 60 )); then
    health_icon="🔴"
    health_label="较差"
  elif (( health_score < 80 )); then
    health_icon="⚠️"
    health_label="一般"
  fi

  if $BRIEF && (( WARN == 0 )) && (( FAIL == 0 )); then
    echo "  All clear ✅"
  else
    echo "  Summary: $PASS passed | $WARN warnings | $FAIL failed"
    echo "  Health:  $health_icon $health_score/100 ($health_label)"
  fi
  echo ""
fi

# Exit code: 0 = all clear, 1 = has failures, 2 = has warnings
if (( FAIL > 0 )); then exit 1; fi
if (( WARN > 0 )); then exit 2; fi
exit 0
