---
name: system-selfcheck
version: 2.0.0
description: >
  系统自检：一键诊断 OpenClaw 运行环境，输出结构化报告。
  检查系统资源、运行时依赖、网络连通性、API 配置、Skills 状态。
  预留 MiClaw / Hermes 平台适配。
applyTo: "**"
---

# 系统自检 System Self-Check v2.0

一键诊断 Agent 运行环境，输出结构化健康报告。

> **关于作者** — 十五年老米粉了！！冲！！！
>
> **功能清单：**
> - ✅ 系统/Uptime/Load/Memory/Swap/Disk/CPU 检查
> - ✅ Python/Node/ffmpeg/jq 依赖检测
> - ✅ Docker 状态检测（如已安装）
> - ✅ GitHub/MiMo API/ClawHub 网络连通性（带重试）
> - ✅ OpenClaw Gateway/Config/Skills/API Keys
> - ✅ `--brief` 精简 / `--json` 结构化 / `--fix` 自动修复
> - ✅ 预留 MiClaw/Hermes 平台入口
> - ✅ 健康评分 (Health Score 0-100)
> - ✅ 告警阈值（内存 ⚠️<30% 🔴<10%，磁盘同理，网络 ⚠️>3s 🔴超时）

## When to Use

| Situation | Use this skill? |
|---|---|
| 用户说"系统自检" / "健康检查" / "status check" / "diagnostics" | ✅ Yes |
| 排查环境问题（依赖缺失、网络不通、配置错误） | ✅ Yes |
| 定期巡检（配合 cron 定时执行） | ✅ Yes |
| 部署后验证环境是否就绪 | ✅ Yes |

## Usage

```bash
bash "{baseDir}/scripts/selfcheck.sh" [options]
```

### Options

| Flag | Description |
|------|-------------|
| `--brief` | 精简模式，只显示问题项 |
| `--json` | JSON 格式输出 |
| `--fix` | 自动修复可修复的问题（安装缺失依赖等） |
| `--platform <name>` | 强制指定平台：openclaw / miclaw / hermes（默认自动检测） |

### --fix 支持安装的依赖

- jq、curl、git、python3-pip、edge-tts
- 自动清理 apt 缓存

### Examples

```bash
# 完整自检
bash "{baseDir}/scripts/selfcheck.sh"

# 只看问题
bash "{baseDir}/scripts/selfcheck.sh --brief"

# JSON 输出（方便程序消费）
bash "{baseDir}/scripts/selfcheck.sh --json"

# 自动修复
bash "{baseDir}/scripts/selfcheck.sh --fix"
```

## 检查项

### 通用检查（所有平台）

| 模块 | 检查内容 | 告警阈值 |
|------|---------|---------|
| 系统 | OS、内核、CPU 核数/架构、主机名 | — |
| Uptime | 运行时间 | ⚠️ >30天建议重启 |
| Load | 1/5/15 分钟负载 | ⚠️ >CPU核数 / 🔴 >2倍核数 |
| 内存 | 总量/可用/百分比 | ⚠️ <30% 可用 / 🔴 <10% |
| Swap | 已用/总量/百分比 | ⚠️ >50% / 🔴 >80% |
| 磁盘 | 总量/已用/可用 | ⚠️ <30% 可用 / 🔴 <10% |
| 运行时 | Python、Node 版本 | — |
| 核心依赖 | ffmpeg、jq、curl、git | 缺失即 🔴 |
| Docker | 容器/镜像统计（如已安装） | ⚠️ >10停止容器 |
| 网络 | GitHub、MiMo API、ClawHub 连通性（带重试） | ⚠️ >3s / 🔴 超时 |

### OpenClaw 专属检查

| 检查项 | 内容 |
|--------|------|
| Gateway | 运行状态 |
| 配置文件 | `~/.openclaw/openclaw.json` 完整性 |
| Skills | 已安装列表 + 缺失依赖 |
| API Keys | MIMO_API_KEY / ClawHub Token（仅检查存在，不输出值） |

### 预留平台（TODO）

- **MiClaw**：`check_miclaw.sh` — MiMo Agent 平台适配
- **Hermes**：`check_hermes.sh` — Hermes Agent 平台适配

## 输出格式

```
⚡ System Self-Check v2.0 — Openclaw
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  ✅  [System]   Linux 6.8.0-101-generic | 2 cores | x86_64 | VM-0-4-ubuntu
  ✅  [Uptime]   4d 2h 35m
  ✅  [Load]     1m=0.01 5m=0.04 15m=0.07
  ✅  [Memory]   1967M total / 856M available (43%)
  ✅  [Swap]     326M / 10179M (3%)
  ✅  [Disk]     40G total / 18G available (55% used)
  ✅  [Runtime]  Python 3.12.3 | Node v22.22.2
  ✅  [Deps]     ffmpeg 6.1.1-3ubuntu5 | jq ✅ | curl ✅ | git ✅
  ⚠️  [Network]  github.com — 200 (10s) SLOW
  ✅  [Network]  api.xiaomimimo.com — 404 (0s)
  ✅  [Network]  clawhub.ai — 200 (0s)
  ⚠️  [Platform] OpenClaw OpenClaw 2026.4.21 (latest: 2026.4.27)
  ✅  [Gateway]  Running
  ✅  [Config]   ~/.openclaw/openclaw.json exists
  ✅  [Skills]   13 installed (/root/.openclaw/workspace/skills)
  ⚠️  [API Keys] MIMO_API_KEY ❌ | ClawHub ✅
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Summary: 13 passed | 3 warnings | 0 failed
  Health:  ✅ 94/100 (良好)
```

## 版本历史

### v2.0.0 (2026-05-01)

- 🆕 Uptime 检查：运行时间过长提醒重启
- 🆕 Load Average 检查：1/5/15 分钟负载监控
- 🆕 Swap 检查：交换分区使用率
- 🆕 Docker 检查：容器/镜像统计
- 🆕 健康评分：Health Score 0-100
- 🔧 Skills 路径修复：支持多路径搜索（workspace/skills 优先）
- 🔧 网络请求重试：失败自动重试 2 次
- 🔧 `--fix` 扩展：支持 curl/git/pip3 自动安装
- 🔧 依赖检测增强：自动检测 docker

### v1.2 (2026-04-27)

- 🍎 macOS 内存检测改用 `vm_stat`，正确计算可用内存（free + speculative pages）
- 📂 Skills 路径动态获取：优先 `openclaw config get skills.dir`，不再硬编码
- 🔄 OpenClaw 版本对比：从 npm registry 拉取最新版本，落后时 warn 提示
- ✨ `--brief` 模式无问题时输出 "All clear ✅"

### v1.0.1 (2026-04-24)

- 🚀 首发：系统自检 Skill，支持 OpenClaw 平台，预留 MiClaw/Hermes，三种输出模式，告警阈值

## 定时自检（Cron）

通过 OpenClaw cron 定期执行：

```
schedule: "0 9 * * *"   # 每天早上 9 点
payload: "执行系统自检并报告异常"
```

## 交付格式

- 默认：直接回复结构化文本报告
- `--json`：回复 JSON 格式
- `--brief`：只回复问题项，无问题则回复 "All clear ✅"
