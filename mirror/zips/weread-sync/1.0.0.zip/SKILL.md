---
name: weread-sync
description: 当用户想查看微信读书的书籍、划线、笔记、书评、阅读状态，想同步到本地 Markdown，或想打开本地可视化 demo 页面时使用。
---

## 使用流程
0. npm install -g weread-sync
1. 先执行 `weread-sync login` 扫码登录微信读书，登录态保存在本地
2. 执行 `weread-sync sync` 拉取笔记并导出为 Markdown 文件
3. sync 采用增量同步：通过指纹（笔记数、书评数、进度等）判断书籍是否有变化，无变化则跳过；使用 `--force` 可强制重新导出全部
4. 如需可视化浏览本地缓存，执行 `weread-sync demo`

## 命令一览

所有命令均以 `weread-sync` 为前缀，支持 `--json` 参数输出 JSON 格式。

| 命令 | 说明 |
|------|------|
| `weread-sync login` | 显示二维码并等待扫码登录（一步完成） |
| `weread-sync status` | 查看登录状态、同步状态和已同步书籍数量 |
| `weread-sync export-dir` | 查看本地导出目录及是否有数据 |
| `weread-sync notebooks` | 列出有笔记/划线的书籍 |
| `weread-sync books-status` | 按阅读状态分类书籍（reading/finished/other） |
| `weread-sync book-probe` | 实时拉取单本书的详情、划线、书评、章节 |
| `weread-sync sync` | 将书籍导出为本地 Markdown |
| `weread-sync demo` | 启动本地可视化页面，浏览已同步书籍和 Markdown 笔记 |
| `weread-sync logout` | 清除本机登录态 |
