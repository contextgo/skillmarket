---
name: Favicon
description: "Fetch and download favicons from any website for your design projects. Use when grabbing icons, checking availability, or previewing favicon renders."
version: "2.0.0"
author: "BytesAgain"
homepage: https://bytesagain.com
source: https://github.com/bytesagain/ai-skills
tags: ["favicon","icon","website","image","web","html","branding","developer"]
categories: ["Developer Tools", "Utility"]
---

# Favicon — Design Toolkit

Favicon is a command-line design toolkit for managing color palettes, previewing designs, generating assets, converting formats, and more. All entries are logged with timestamps for full history tracking.

## Commands

| Command | Description |
|---------|-------------|
| `favicon palette <input>` | Record or browse palette entries (colors, themes, etc.) |
| `favicon preview <input>` | Log a preview note or review recent previews |
| `favicon generate <input>` | Generate and log a design asset entry |
| `favicon convert <input>` | Log a format conversion task |
| `favicon harmonize <input>` | Record color harmonization notes |
| `favicon contrast <input>` | Log contrast check results |
| `favicon export <input>` | Record an export operation |
| `favicon random <input>` | Log a random generation entry |
| `favicon browse <input>` | Record a browsing/search session |
| `favicon mix <input>` | Log color mixing experiments |
| `favicon gradient <input>` | Record gradient design entries |
| `favicon swatch <input>` | Log swatch samples |
| `favicon stats` | Show summary statistics across all log files |
| `favicon search <term>` | Search all logs for a keyword |
| `favicon recent` | Show the 20 most recent history entries |
| `favicon status` | Health check — version, disk usage, last activity |
| `favicon export json\|csv\|txt` | Export all data in JSON, CSV, or plain text format |
| `favicon help` | Show available commands |
| `favicon version` | Print version string |

Each command (palette, preview, generate, etc.) works in two modes:

- **With arguments**: Saves the input with a timestamp to its dedicated log file
- **Without arguments**: Displays the 20 most recent entries from that log

## Data Storage

All data is stored in `~/.local/share/favicon/`:

- **Per-command logs**: `palette.log`, `preview.log`, `generate.log`, `convert.log`, `harmonize.log`, `contrast.log`, `export.log`, `random.log`, `browse.log`, `mix.log`, `gradient.log`, `swatch.log`
- **History log**: `history.log` — unified activity log across all commands
- **Export files**: `export.json`, `export.csv`, or `export.txt` when using the export feature

Each log entry is stored as `YYYY-MM-DD HH:MM|<value>` (pipe-delimited).

## Requirements

- Bash 4+
- No external dependencies or API keys required
- Standard POSIX utilities (`wc`, `du`, `grep`, `tail`, `head`, `date`)

## When to Use

1. **Building a color palette** — Use `favicon palette` to log and review color choices, hex codes, or theme names during a design session
2. **Tracking design iterations** — Use `favicon preview` and `favicon generate` to keep a running log of design previews and generated assets
3. **Checking accessibility** — Use `favicon contrast` and `favicon harmonize` to record contrast ratios and color harmony evaluations
4. **Exporting design data** — Use `favicon export json` to produce a structured JSON dump of all logged entries for reporting or sharing
5. **Reviewing recent activity** — Use `favicon recent` or `favicon stats` to get a quick overview of what design work has been logged

## Examples

```bash
# Log a new palette color
favicon palette "#3B82F6 sky-blue primary"

# Record a contrast check
favicon contrast "foreground #FFF vs background #1E293B ratio 14.5:1 PASS"

# Mix two colors
favicon mix "blend #FF6B6B + #4ECDC4 = #9A9CC7"

# Create a gradient entry
favicon gradient "linear 45deg from #667eea to #764ba2"

# View all recent activity
favicon recent

# Export everything as CSV
favicon export csv

# Check system health
favicon status
```

---

*Powered by BytesAgain | bytesagain.com | hello@bytesagain.com*
