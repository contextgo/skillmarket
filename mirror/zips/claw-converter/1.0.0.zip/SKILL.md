---
summary: "小龙虾模型切换器 - 更换AI模型但保持记忆不变，支持市面所有大模型"
read_when:
  - 用户想要更换AI模型但保持对话记忆
  - 用户提到"小龙虾"、"更换模型"、"记忆不变"
  - 用户询问有哪些模型可用
---

# 🦞 小龙虾模型切换器

## 功能说明

这个技能让"小龙虾"（你的AI助手）可以**更换使用的AI模型，但保持所有对话记忆和上下文不变**！

支持市面所有主流大模型！

## 核心特性

- ✅ **无缝切换模型** - 在不同AI模型之间自由切换
- ✅ **记忆保持** - 所有对话历史、记忆完全保留
- ✅ **多模型支持** - 支持市面所有主流大模型
- ✅ **快速切换** - 一键切换，无需重新开始对话
- ✅ **智能推荐** - 根据任务类型推荐最佳模型

## 支持的模型大全

### 🌟 火山方舟（Ark）模型

| 模型名称 | 说明 | 推理模式 | 图片支持 | 上下文窗口 | 最佳用途 |
|---------|------|---------|---------|-----------|---------|
| `doubao-seed-2.0-code` | ✅ **当前在用** | ✅ 深度思考 | ✅ 支持 | 256K | 代码/编程 |
| `doubao-seed-2.0-pro` | 豆包Seed 2.0 Pro | ✅ 深度思考 | ✅ 支持 | 256K | 创意/写作 |
| `doubao-seed-2.0-lite` | 豆包Seed 2.0 Lite | ✅ 深度思考 | ✅ 支持 | 256K | 快速对话 |
| `doubao-seed-2.0-mini-260215` | 豆包Seed 2.0 Mini | ✅ 深度思考 | ✅ 支持 | 128K | 轻量任务 |
| `doubao-seed-code` | 豆包Seed代码版 | ❌ 无推理 | ✅ 支持 | 256K | 代码任务 |
| `doubao-seed-1-8-251228` | 豆包Seed 1.8 | ✅ 深度思考 | ✅ 支持 | 256K | 稳定版本 |
| `doubao-seed-character-251128` | 角色版 | ✅ 深度思考 | ❌ 仅文本 | 200K | 角色扮演 |
| `kimi-k2.5` | Kimi K2.5 | ✅ 深度思考 | ✅ 支持 | 256K | 长文档 |
| `glm-4.7` | 智谱GLM 4.7 | ✅ 深度思考 | ❌ 仅文本 | 200K | 中文优化 |
| `glm-4-7-251222` | GLM 4.7 (251222) | ✅ 深度思考 | ❌ 仅文本 | 200K | 最新版本 |
| `deepseek-v3.2` | DeepSeek V3.2 | ✅ 深度思考 | ❌ 仅文本 | 128K | 代码/数学 |
| `deepseek-v3-2-251201` | DeepSeek V3.2 (251201) | ✅ 深度思考 | ❌ 仅文本 | 128K | 最新版本 |
| `minimax-m2.5` | MiniMax M2.5 | ✅ 深度思考 | ❌ 仅文本 | 200K | 创意写作 |

### 🌐 OpenRouter 模型

| 模型名称 | 说明 | 最佳用途 |
|---------|------|---------|
| `openai/gpt-4o` | GPT-4o | 多模态/通用 |
| `openai/gpt-4-turbo` | GPT-4 Turbo | 通用任务 |
| `openai/gpt-3.5-turbo` | GPT-3.5 Turbo | 快速任务 |
| `anthropic/claude-3-opus` | Claude 3 Opus | 深度思考 |
| `anthropic/claude-3-sonnet` | Claude 3 Sonnet | 平衡型 |
| `anthropic/claude-3-haiku` | Claude 3 Haiku | 快速响应 |
| `google/gemini-2.0-pro-exp` | Gemini 2.0 Pro | 多模态 |
| `google/gemini-1.5-pro` | Gemini 1.5 Pro | 长文档 |
| `mistralai/mistral-large` | Mistral Large | 通用任务 |
| `meta-llama/llama-3-70b-instruct` | Llama 3 70B | 开源模型 |
| `qwen/qwen3-next-80b-a3b-instruct` | Qwen 3 Next | 中文优化 |

### 🆓 免费备用模型

| 模型名称 | 说明 |
|---------|------|
| `openrouter/free` | OpenRouter免费模型 |
| `nvidia/nemotron-3-super-120b-a12b:free` | Nemotron 3 Super (免费) |
| `nvidia/nemotron-3-nano-30b-a3b:free` | Nemotron 3 Nano (免费) |
| `qwen/qwen3-next-80b-a3b-instruct:free` | Qwen 3 Next (免费) |
| `stepfun/step-3.5-flash:free` | Step 3.5 Flash (免费) |
| `arcee-ai/trinity-mini:free` | Trinity Mini (免费) |

## 使用方法

### 切换模型

```
小龙虾，切换到 [模型名称]
```

**示例：**
- "小龙虾，切换到 doubao-seed-2.0-pro"
- "小龙虾，换成 gpt-4o"
- "小龙虾，用 claude-3-opus"
- "小龙虾，切换到 gemini-2.0-pro"

### 查看当前模型

```
小龙虾，你现在用的是什么模型？
```

### 查看可用模型

```
小龙虾，有哪些模型可以用？
```

### 智能推荐模型

```
小龙虾，推荐一个适合[任务类型]的模型
```

**示例：**
- "小龙虾，推荐一个适合写代码的模型"
- "小龙虾，推荐一个适合写文章的模型"
- "小龙虾，推荐一个适合快速回答的模型"

## 记忆保持机制

切换模型时，以下内容会完全保留：
- 📝 所有对话历史
- 🧠 长期记忆（MEMORY.md）
- 📅 每日记忆文件
- 🎯 用户偏好和设置
- 📁 工作区上下文

## 智能推荐规则

### 根据任务类型推荐

| 任务类型 | 推荐模型 | 理由 |
|---------|---------|------|
| 代码/编程 | `doubao-seed-2.0-code` | 代码优化版 |
| 创意/写作 | `doubao-seed-2.0-pro` | 深度思考能力强 |
| 快速对话 | `doubao-seed-2.0-lite` | 响应更快 |
| 长文档 | `kimi-k2.5` | 256K上下文 |
| 中文任务 | `glm-4.7` | 中文优化 |
| 数学/推理 | `deepseek-v3.2` | 推理能力强 |

## 快速开始

1. 说"小龙虾，切换到 [你想用的模型]"
2. 继续对话，记忆完全保持！
3. 或说"小龙虾，推荐一个适合[任务类型]的模型"

---

**让小龙虾拥有多重身份，但记忆永远不变！** 🦞✨

**支持市面所有主流大模型！** 🚀
