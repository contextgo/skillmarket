# Skill: Walmart SEO Product Content Generator (Mosquito Killer Lamp - Cylindrical Vertical Type)

## Part 1: Walmart Title Naming Formula

### Title Structure Order
`[Brand Name] + [Core Keyword 1] + [Core Keyword 2] + [Attribute Words] + for + [Scenario Words]`

### Module Rules
- **Brand Name**: Place at the very beginning, use registered brand name
- **Core Keywords**: Main product search terms, place immediately after brand name (max 3 core keywords)
- **Attribute Words**: Most frequently searched features by US users (capacity, charging method, technology type, material, etc.)
- **Scenario Words**: Use `for` before the first scenario word, separate subsequent scenarios with spaces only (no additional prepositions)

### Character & Format Restrictions
- Total length: **within 150 characters** (including spaces)
- **No punctuation marks** anywhere in the title
- Use **US user preferred terms** (use `Patio` instead of `Terrace`, use `Yard` instead of `Garden`)
- Different core keywords separated by spaces, no stacking of identical or highly similar terms

### Title Structure Example
`BrandName CoreWord1 CoreWord2 Attribute1 Attribute2 Attribute3 for Scenario1 Scenario2 Scenario3 Scenario4`

---

## Part 2: Site Description & Key Features Generator

### Task Description
Generate a product name (following Walmart title formula), a site description (max 50 words), and five key features (each max 60 words) for a **USB rechargeable, cylindrical vertical mosquito killer lamp** with a built‑in 4000mAh lithium battery.

Follow strict SEO rules: high‑traffic keywords first, use universal scenarios (e.g., party, patio, camping, home, bedroom, garden, BBQ, travel).

All parameters must match the user’s Chinese description (e.g., 4000mAh battery, USB charging). Output must be in **English only**.

### Product Specifications (Based on User Input)
- Product type: Cylindrical vertical mosquito killer lamp
- Power supply: USB charging (built‑in battery)
- Battery: Rechargeable lithium battery, 4000mAh
- Pest type: Mosquito control
- Origin: Guangdong, China

### SEO Requirements
- High‑traffic keywords placed at the beginning of each section
- Use universal scenarios: party, patio, camping, home, bedroom, garden, BBQ, travel, etc.

### Output Format

**Product Name (Walmart Title - max 150 chars, no punctuation):**
[Follow Walmart formula: BrandName + CoreKeywords + Attributes + for + Scenarios]

**Site Description (max 50 words):**
[One paragraph, no line breaks, high‑traffic keyword first.]

**Five Key Features (each max 60 words):**
<strong>[High‑Traffic Keyword]</strong>: [Description under 60 words, focusing on benefit + scenario.]

---

## Part 3: Example Output (for reference only)

**Product Name (Walmart Title - max 150 chars, no punctuation):**
Slssqhz USB Rechargeable Mosquito Killer 4000mAh Cordless Bug Zapper Quiet Lamp for Patio Camping Home Bedroom Party

**Site Description (max 50 words):**
**4000mAh USB Rechargeable Mosquito Killer** – Cylindrical vertical lamp with long-lasting lithium battery. Cordless and chemical-free, perfect for parties, patios, camping, and bedrooms. USB charging offers easy power from any port. Quiet operation keeps your family bite-free indoors or outdoors.

**Five Key Features:**
<strong>4000mAh Long-Lasting Battery</strong>: Built-in rechargeable lithium battery powers all-night protection. USB charging lets you recharge via laptop, power bank, or wall adapter. Great for camping, backyard parties, and travel.

<strong>Quiet Chemical-Free Mosquito Control</strong>: No loud zaps or toxic sprays. Safe for bedrooms, nurseries, and patios. Enjoy peaceful evenings, dinners, and sleep without mosquito bites.

<strong>Cylindrical Vertical Space-Saving Design</strong>: Slim round shape fits any tabletop, floor, or corner. Blends with home or party decor while silently eliminating mosquitoes. Ideal for small spaces.

<strong>USB Rechargeable Cordless Convenience</strong>: Use anywhere without outlets or tangled wires. Perfect for balconies, gardens, camping tents, and indoor areas where plug-in traps can’t reach.

<strong>Versatile Indoor Outdoor Protection</strong>: Works in living rooms, patios, BBQ areas, and garden parties. Lightweight and portable. Provides 360° mosquito defense for family gatherings, picnics, and overnight trips.