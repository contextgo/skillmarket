#!/usr/bin/env python3
"""
企业微信 API 客户端
支持功能：access_token 管理、通讯录查询、消息推送
"""

import argparse
import json
import os
import sys
import time
from datetime import datetime
from pathlib import Path

try:
    import requests
except ImportError:
    print("ERROR: 需要安装 requests 库。请运行: pip install requests", file=sys.stderr)
    sys.exit(1)

# ──────────────────── 配置 ────────────────────

SKILL_DIR = Path(__file__).resolve().parent.parent
ENV_FILE = SKILL_DIR / ".env"
CUSTOM_ENV_FILE = os.environ.get("WECOM_ENV_FILE", "").strip()
DEFAULT_CACHE_DIR = SKILL_DIR / ".cache"
STATE_DIR = SKILL_DIR / ".state"


def load_dotenv(env_file: Path):
    """从 .env 加载环境变量，不覆盖已存在的系统环境变量。"""
    if not env_file.exists():
        return

    for raw_line in env_file.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip("'").strip('"')
        if key and key not in os.environ:
            os.environ[key] = value


if CUSTOM_ENV_FILE:
    load_dotenv(Path(CUSTOM_ENV_FILE).expanduser())
load_dotenv(ENV_FILE)

CORP_ID = os.environ.get("WECOM_CORP_ID", "")
AGENT_ID = os.environ.get("WECOM_AGENT_ID", "")
SECRET = os.environ.get("WECOM_SECRET", "")
CONTACT_SECRET = os.environ.get("WECOM_CONTACT_SECRET", "")

BASE_URL = "https://qyapi.weixin.qq.com/cgi-bin"


def _resolve_skill_path(raw_path: str, default_path: Path) -> Path:
    if not raw_path:
        return default_path
    path = Path(raw_path).expanduser()
    if path.is_absolute():
        return path
    return (SKILL_DIR / path).resolve()


# Token 缓存文件路径
CACHE_DIR = _resolve_skill_path(os.environ.get("WECOM_CACHE_DIR", ""), DEFAULT_CACHE_DIR)
APP_TOKEN_CACHE = CACHE_DIR / "app_token.json"
CONTACT_TOKEN_CACHE = CACHE_DIR / "contact_token.json"
AUDIT_LOG = STATE_DIR / "message_audit.json"
STATE_FILE = STATE_DIR / "runtime_state.json"


def _json_error(message: str, errcode: int = -1, **extra) -> dict:
    payload = {
        "errcode": errcode,
        "errmsg": message,
    }
    payload.update(extra)
    return payload


def _now_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def _ensure_runtime_dirs():
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    STATE_DIR.mkdir(parents=True, exist_ok=True)


def _write_json_file(path: Path, data: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _append_json_array(path: Path, data: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    items = []
    if path.exists():
        try:
            loaded = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(loaded, list):
                items = loaded
        except json.JSONDecodeError:
            items = []
    items.append(data)
    path.write_text(json.dumps(items, ensure_ascii=False, indent=2), encoding="utf-8")


def _mask_secret(value: str) -> str:
    if not value:
        return ""
    if len(value) <= 6:
        return "*" * len(value)
    return value[:3] + "*" * (len(value) - 6) + value[-3:]


def _runtime_state() -> dict:
    return {
        "updated_at": _now_iso(),
        "skill_dir": str(SKILL_DIR),
        "env_file": str(ENV_FILE),
        "cache_dir": str(CACHE_DIR),
        "state_dir": str(STATE_DIR),
        "audit_log": str(AUDIT_LOG),
        "config": {
            "WECOM_CORP_ID": bool(CORP_ID),
            "WECOM_AGENT_ID": bool(AGENT_ID),
            "WECOM_SECRET": bool(SECRET),
            "WECOM_CONTACT_SECRET": bool(CONTACT_SECRET),
        },
    }


def _save_runtime_state():
    _write_json_file(STATE_FILE, _runtime_state())


def _get_agent_id() -> int:
    """返回合法的 AgentID。"""
    try:
        return int(AGENT_ID)
    except ValueError:
        raise SystemExit("ERROR: WECOM_AGENT_ID 必须是数字。")


def _split_recipients(user_ids: str) -> list[str]:
    return [item.strip() for item in user_ids.split("|") if item.strip()]


def build_send_preview(user_ids: str, msgtype: str, content: str = "", title: str = "") -> dict:
    recipients = _split_recipients(user_ids)
    is_broadcast = "@all" in recipients or len(recipients) > 1
    preview = {
        "preview": True,
        "touser": user_ids,
        "recipient_count": len(recipients),
        "recipients": recipients,
        "msgtype": msgtype,
        "is_broadcast": is_broadcast,
        "requires_confirmation": is_broadcast,
    }
    if content:
        preview["content_preview"] = content[:200]
    if title:
        preview["title"] = title
    return preview


def _record_send_attempt(action: str, payload: dict, response: dict):
    event = {
        "timestamp": _now_iso(),
        "action": action,
        "payload": payload,
        "response": response,
    }
    _append_json_array(AUDIT_LOG, event)


def _load_recent_history(limit: int = 10) -> list[dict]:
    if not AUDIT_LOG.exists():
        return []
    try:
        items = json.loads(AUDIT_LOG.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return []
    if not isinstance(items, list):
        return []
    return items[-limit:]


def write_env_file(corp_id: str, agent_id: str, secret: str, contact_secret: str = "") -> dict:
    env_lines = [
        "# 企业微信自建应用配置",
        f"WECOM_CORP_ID={corp_id}",
        f"WECOM_AGENT_ID={agent_id}",
        f"WECOM_SECRET={secret}",
        f"WECOM_CONTACT_SECRET={contact_secret}",
        f"WECOM_CACHE_DIR={CACHE_DIR}",
    ]
    ENV_FILE.write_text("\n".join(env_lines) + "\n", encoding="utf-8")
    summary = {
        "success": True,
        "env_file": str(ENV_FILE),
        "saved": {
            "WECOM_CORP_ID": corp_id,
            "WECOM_AGENT_ID": agent_id,
            "WECOM_SECRET": _mask_secret(secret),
            "WECOM_CONTACT_SECRET": _mask_secret(contact_secret),
            "WECOM_CACHE_DIR": str(CACHE_DIR),
        },
    }
    _save_runtime_state()
    return summary


# ──────────────────── Token 管理 ────────────────────

def _load_cached_token(cache_file: Path) -> str | None:
    """从缓存文件加载未过期的 token"""
    if not cache_file.exists():
        return None
    try:
        data = json.loads(cache_file.read_text(encoding="utf-8"))
        # 预留 5 分钟缓冲
        if data.get("expires_at", 0) > time.time() + 300:
            return data["access_token"]
    except (json.JSONDecodeError, KeyError):
        pass
    return None


def _save_token_cache(cache_file: Path, token: str, expires_in: int):
    """保存 token 到缓存文件"""
    _ensure_runtime_dirs()
    data = {
        "access_token": token,
        "expires_at": time.time() + expires_in,
    }
    cache_file.write_text(json.dumps(data), encoding="utf-8")


def _clear_token_cache(cache_file: Path):
    """删除 token 缓存，供 access_token 失效时重取。"""
    if cache_file.exists():
        cache_file.unlink()


def _request_json(method: str, url: str, *, retry_on_token_expired: bool = False, **kwargs) -> dict:
    """统一处理网络请求、JSON 解析和 token 过期重试。"""
    cache_file = kwargs.pop("token_cache_file", None)
    token_builder = kwargs.pop("token_refresh", None)

    try:
        response = requests.request(method, url, timeout=10, **kwargs)
        response.raise_for_status()
    except requests.RequestException as exc:
        return _json_error(f"请求失败: {exc}", errcode=-2)

    try:
        data = response.json()
    except ValueError:
        return _json_error("接口返回了非 JSON 响应", errcode=-3, status_code=response.status_code)

    if retry_on_token_expired and data.get("errcode") == 40014:
        if cache_file is not None:
            _clear_token_cache(cache_file)
        if callable(token_builder):
            refreshed_url = token_builder()
            return _request_json(method, refreshed_url, **kwargs)

    return data


def get_access_token(secret: str = "", cache_file: Path | None = None) -> str:
    """获取 access_token（自动缓存，2 小时有效期）"""
    if not secret:
        secret = SECRET
    if cache_file is None:
        cache_file = APP_TOKEN_CACHE if secret == SECRET else CONTACT_TOKEN_CACHE

    # 尝试缓存
    cached = _load_cached_token(cache_file)
    if cached:
        return cached

    if not CORP_ID or not secret:
        print("ERROR: 缺少 WECOM_CORP_ID 或 Secret，请先配置环境变量。", file=sys.stderr)
        sys.exit(1)

    url = f"{BASE_URL}/gettoken?corpid={CORP_ID}&corpsecret={secret}"
    resp = _request_json("GET", url)

    if resp.get("errcode") != 0:
        print(f"ERROR: 获取 access_token 失败: {json.dumps(resp, ensure_ascii=False)}", file=sys.stderr)
        sys.exit(1)

    token = resp["access_token"]
    _save_token_cache(cache_file, token, resp.get("expires_in", 7200))
    _save_runtime_state()
    return token


def _get_contact_token() -> str:
    """获取通讯录专用 token（优先使用 CONTACT_SECRET，fallback 到 SECRET）"""
    secret = CONTACT_SECRET if CONTACT_SECRET else SECRET
    cache = CONTACT_TOKEN_CACHE if CONTACT_SECRET else APP_TOKEN_CACHE
    return get_access_token(secret=secret, cache_file=cache)


# ──────────────────── 通讯录查询 ────────────────────

def search_user_by_mobile(mobile: str) -> dict:
    """通过手机号查找用户 UserID"""
    token = _get_contact_token()
    url = f"{BASE_URL}/user/getuserid?access_token={token}"
    resp = _request_json(
        "POST",
        url,
        json={"mobile": mobile},
        retry_on_token_expired=True,
        token_cache_file=CONTACT_TOKEN_CACHE if CONTACT_SECRET else APP_TOKEN_CACHE,
        token_refresh=lambda: f"{BASE_URL}/user/getuserid?access_token={_get_contact_token()}",
    )
    return resp


def search_user_by_email(email: str) -> dict:
    """通过邮箱查找用户 UserID"""
    token = _get_contact_token()
    url = f"{BASE_URL}/user/get_userid_by_email?access_token={token}"
    # email_type: 1=企业邮箱, 2=个人邮箱
    resp = _request_json(
        "POST",
        url,
        json={"email": email, "email_type": 1},
        retry_on_token_expired=True,
        token_cache_file=CONTACT_TOKEN_CACHE if CONTACT_SECRET else APP_TOKEN_CACHE,
        token_refresh=lambda: f"{BASE_URL}/user/get_userid_by_email?access_token={_get_contact_token()}",
    )
    return resp


def get_user_info(user_id: str) -> dict:
    """获取用户详细信息"""
    token = _get_contact_token()
    url = f"{BASE_URL}/user/get?access_token={token}&userid={user_id}"
    resp = _request_json(
        "GET",
        url,
        retry_on_token_expired=True,
        token_cache_file=CONTACT_TOKEN_CACHE if CONTACT_SECRET else APP_TOKEN_CACHE,
        token_refresh=lambda: f"{BASE_URL}/user/get?access_token={_get_contact_token()}&userid={user_id}",
    )
    return resp


def get_department_list(dept_id: int = 1) -> dict:
    """获取部门列表（默认获取根部门下所有子部门）"""
    token = _get_contact_token()
    url = f"{BASE_URL}/department/list?access_token={token}&id={dept_id}"
    resp = _request_json(
        "GET",
        url,
        retry_on_token_expired=True,
        token_cache_file=CONTACT_TOKEN_CACHE if CONTACT_SECRET else APP_TOKEN_CACHE,
        token_refresh=lambda: f"{BASE_URL}/department/list?access_token={_get_contact_token()}&id={dept_id}",
    )
    return resp


def get_department_users(dept_id: int, fetch_child: bool = False) -> dict:
    """获取部门成员列表"""
    token = _get_contact_token()
    url = f"{BASE_URL}/user/simplelist?access_token={token}&department_id={dept_id}&fetch_child={'1' if fetch_child else '0'}"
    resp = _request_json(
        "GET",
        url,
        retry_on_token_expired=True,
        token_cache_file=CONTACT_TOKEN_CACHE if CONTACT_SECRET else APP_TOKEN_CACHE,
        token_refresh=lambda: f"{BASE_URL}/user/simplelist?access_token={_get_contact_token()}&department_id={dept_id}&fetch_child={'1' if fetch_child else '0'}",
    )
    return resp


def get_department_users_detail(dept_id: int, fetch_child: bool = False) -> dict:
    """获取部门成员详情"""
    token = _get_contact_token()
    url = f"{BASE_URL}/user/list?access_token={token}&department_id={dept_id}&fetch_child={'1' if fetch_child else '0'}"
    resp = _request_json(
        "GET",
        url,
        retry_on_token_expired=True,
        token_cache_file=CONTACT_TOKEN_CACHE if CONTACT_SECRET else APP_TOKEN_CACHE,
        token_refresh=lambda: f"{BASE_URL}/user/list?access_token={_get_contact_token()}&department_id={dept_id}&fetch_child={'1' if fetch_child else '0'}",
    )
    return resp


def search_user_by_name(name: str, dept_id: int = 1) -> list[dict]:
    """通过姓名模糊搜索用户（遍历部门成员列表匹配）"""
    result = get_department_users_detail(dept_id, fetch_child=True)
    if result.get("errcode") != 0:
        return [result]
    matches = []
    for user in result.get("userlist", []):
        if name in user.get("name", ""):
            matches.append({
                "userid": user.get("userid"),
                "name": user.get("name"),
                "department": user.get("department"),
                "position": user.get("position", ""),
                "mobile": user.get("mobile", ""),
                "email": user.get("email", ""),
            })
    return matches


# ──────────────────── 消息推送 ────────────────────

def send_text(user_ids: str, content: str, *, preview_only: bool = False, force: bool = False) -> dict:
    """发送文本消息
    Args:
        user_ids: 用户 ID，多人用 | 分隔，"@all" 表示全部
        content: 消息内容
    """
    preview = build_send_preview(user_ids, "text", content=content)
    if preview_only or (preview["requires_confirmation"] and not force):
        return preview

    token = get_access_token()
    url = f"{BASE_URL}/message/send?access_token={token}"
    data = {
        "touser": user_ids,
        "msgtype": "text",
        "agentid": _get_agent_id(),
        "text": {"content": content},
    }
    resp = _request_json(
        "POST",
        url,
        json=data,
        retry_on_token_expired=True,
        token_cache_file=APP_TOKEN_CACHE,
        token_refresh=lambda: f"{BASE_URL}/message/send?access_token={get_access_token()}",
    )
    _record_send_attempt("send-text", preview, resp)
    return resp


def send_markdown(user_ids: str, content: str, *, preview_only: bool = False, force: bool = False) -> dict:
    """发送 Markdown 消息
    Args:
        user_ids: 用户 ID，多人用 | 分隔，"@all" 表示全部
        content: Markdown 内容（企微支持有限 markdown 语法）
    """
    preview = build_send_preview(user_ids, "markdown", content=content)
    if preview_only or (preview["requires_confirmation"] and not force):
        return preview

    token = get_access_token()
    url = f"{BASE_URL}/message/send?access_token={token}"
    data = {
        "touser": user_ids,
        "msgtype": "markdown",
        "agentid": _get_agent_id(),
        "markdown": {"content": content},
    }
    resp = _request_json(
        "POST",
        url,
        json=data,
        retry_on_token_expired=True,
        token_cache_file=APP_TOKEN_CACHE,
        token_refresh=lambda: f"{BASE_URL}/message/send?access_token={get_access_token()}",
    )
    _record_send_attempt("send-markdown", preview, resp)
    return resp


def send_textcard(
    user_ids: str,
    title: str,
    description: str,
    url_link: str,
    btntxt: str = "详情",
    *,
    preview_only: bool = False,
    force: bool = False,
) -> dict:
    """发送文本卡片消息"""
    preview = build_send_preview(user_ids, "textcard", content=description, title=title)
    preview["url"] = url_link
    if preview_only or (preview["requires_confirmation"] and not force):
        return preview

    token = get_access_token()
    url = f"{BASE_URL}/message/send?access_token={token}"
    data = {
        "touser": user_ids,
        "msgtype": "textcard",
        "agentid": _get_agent_id(),
        "textcard": {
            "title": title,
            "description": description,
            "url": url_link,
            "btntxt": btntxt,
        },
    }
    resp = _request_json(
        "POST",
        url,
        json=data,
        retry_on_token_expired=True,
        token_cache_file=APP_TOKEN_CACHE,
        token_refresh=lambda: f"{BASE_URL}/message/send?access_token={get_access_token()}",
    )
    _record_send_attempt("send-card", preview, resp)
    return resp


# ──────────────────── 初始化检查 ────────────────────

def check_config() -> dict:
    """检查配置是否完整，返回状态"""
    status = {
        "WECOM_CORP_ID": bool(CORP_ID),
        "WECOM_AGENT_ID": bool(AGENT_ID),
        "WECOM_SECRET": bool(SECRET),
        "WECOM_CONTACT_SECRET": bool(CONTACT_SECRET),
    }
    status["ready"] = all([status["WECOM_CORP_ID"], status["WECOM_AGENT_ID"], status["WECOM_SECRET"]])
    status["contact_ready"] = status["ready"] and (status["WECOM_CONTACT_SECRET"] or status["WECOM_SECRET"])
    status["env_file"] = str(ENV_FILE)
    status["cache_dir"] = str(CACHE_DIR)
    status["state_dir"] = str(STATE_DIR)
    status["audit_log"] = str(AUDIT_LOG)
    status["group_send_requires_confirmation"] = True
    _save_runtime_state()
    return status


def verify_connection() -> dict:
    """验证连接：尝试获取 token 并返回结果"""
    try:
        token = get_access_token()
        return {"success": True, "message": "应用 Token 获取成功", "token_preview": token[:8] + "..."}
    except SystemExit:
        return {"success": False, "message": "应用 Token 获取失败，请检查 WECOM_CORP_ID 和 WECOM_SECRET"}


# ──────────────────── CLI 入口 ────────────────────

def main():
    parser = argparse.ArgumentParser(description="企业微信 API 客户端")
    subparsers = parser.add_subparsers(dest="command", help="可用命令")

    # check - 检查配置
    subparsers.add_parser("check", help="检查环境变量配置")

    # setup - 将凭证写入 skill 私有 .env
    p_setup = subparsers.add_parser("setup", help="写入 skill 私有 .env 配置")
    p_setup.add_argument("--corp-id", required=True, help="企业 ID")
    p_setup.add_argument("--agent-id", required=True, help="应用 AgentID")
    p_setup.add_argument("--secret", required=True, help="应用 Secret")
    p_setup.add_argument("--contact-secret", default="", help="通讯录 Secret（可选）")

    # verify - 验证连接
    subparsers.add_parser("verify", help="验证 API 连接")

    # history - 查看最近发送记录
    p_history = subparsers.add_parser("history", help="查看最近发送审计日志")
    p_history.add_argument("--limit", type=int, default=10, help="最近记录条数")

    # send-text - 发送文本消息
    p_send = subparsers.add_parser("send-text", help="发送文本消息")
    p_send.add_argument("--to", required=True, help="接收者 UserID（多人用 | 分隔）")
    p_send.add_argument("--content", required=True, help="消息内容")
    p_send.add_argument("--preview", action="store_true", help="仅输出发送预览，不真正发送")
    p_send.add_argument("--yes", action="store_true", help="确认执行群发/@all 发送")

    # send-markdown - 发送 Markdown 消息
    p_md = subparsers.add_parser("send-markdown", help="发送 Markdown 消息")
    p_md.add_argument("--to", required=True, help="接收者 UserID")
    p_md.add_argument("--content", required=True, help="Markdown 内容")
    p_md.add_argument("--preview", action="store_true", help="仅输出发送预览，不真正发送")
    p_md.add_argument("--yes", action="store_true", help="确认执行群发/@all 发送")

    # send-card - 发送文本卡片消息
    p_card = subparsers.add_parser("send-card", help="发送文本卡片消息")
    p_card.add_argument("--to", required=True, help="接收者 UserID")
    p_card.add_argument("--title", required=True, help="标题")
    p_card.add_argument("--desc", required=True, help="描述")
    p_card.add_argument("--url", required=True, help="跳转链接")
    p_card.add_argument("--btn", default="详情", help="按钮文字（默认'详情'）")
    p_card.add_argument("--preview", action="store_true", help="仅输出发送预览，不真正发送")
    p_card.add_argument("--yes", action="store_true", help="确认执行群发/@all 发送")

    # search-mobile - 通过手机号查用户
    p_mobile = subparsers.add_parser("search-mobile", help="通过手机号查找用户")
    p_mobile.add_argument("--mobile", required=True, help="手机号")

    # search-email - 通过邮箱查用户
    p_email = subparsers.add_parser("search-email", help="通过邮箱查找用户")
    p_email.add_argument("--email", required=True, help="邮箱")

    # search-name - 通过姓名查用户
    p_name = subparsers.add_parser("search-name", help="通过姓名查找用户")
    p_name.add_argument("--name", required=True, help="姓名（支持模糊匹配）")
    p_name.add_argument("--dept-id", type=int, default=1, help="搜索的部门 ID（默认根部门）")

    # user-info - 获取用户详情
    p_info = subparsers.add_parser("user-info", help="获取用户详细信息")
    p_info.add_argument("--userid", required=True, help="用户 UserID")

    # dept-list - 获取部门列表
    p_dept = subparsers.add_parser("dept-list", help="获取部门列表")
    p_dept.add_argument("--dept-id", type=int, default=1, help="父部门 ID（默认根部门）")

    # dept-users - 获取部门成员
    p_du = subparsers.add_parser("dept-users", help="获取部门成员列表")
    p_du.add_argument("--dept-id", type=int, required=True, help="部门 ID")
    p_du.add_argument("--recursive", action="store_true", help="是否递归获取子部门成员")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    # 执行命令
    result = None

    if args.command == "check":
        result = check_config()
    elif args.command == "setup":
        result = write_env_file(args.corp_id, args.agent_id, args.secret, args.contact_secret)
    elif args.command == "verify":
        result = verify_connection()
    elif args.command == "history":
        result = {
            "audit_log": str(AUDIT_LOG),
            "items": _load_recent_history(args.limit),
        }
    elif args.command == "send-text":
        result = send_text(args.to, args.content, preview_only=args.preview, force=args.yes)
    elif args.command == "send-markdown":
        result = send_markdown(args.to, args.content, preview_only=args.preview, force=args.yes)
    elif args.command == "send-card":
        result = send_textcard(
            args.to,
            args.title,
            args.desc,
            args.url,
            args.btn,
            preview_only=args.preview,
            force=args.yes,
        )
    elif args.command == "search-mobile":
        result = search_user_by_mobile(args.mobile)
    elif args.command == "search-email":
        result = search_user_by_email(args.email)
    elif args.command == "search-name":
        result = search_user_by_name(args.name, args.dept_id)
    elif args.command == "user-info":
        result = get_user_info(args.userid)
    elif args.command == "dept-list":
        result = get_department_list(args.dept_id)
    elif args.command == "dept-users":
        result = get_department_users_detail(args.dept_id, args.recursive)

    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
