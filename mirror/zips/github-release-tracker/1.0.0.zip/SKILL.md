---
name: "github-release-tracker"
description: "GitHub 项目更新追踪工具 - 自动检查多个 GitHub 项目的 Releases 和 CHANGELOG，生成更新摘要与影响分析报告。支持自动化定时任务。触发词：「追踪项目更新」「检查 GitHub 更新」「项目更新报告」「设置更新提醒」"
---

# GitHub Release Tracker

追踪多个 GitHub 项目的 Releases 和 CHANGELOG，自动生成更新摘要与影响分析。

## 功能特性

- ✅ 多项目追踪（可配置项目列表）
- ✅ 自动获取 Releases 和 CHANGELOG
- ✅ AI 驱动的变更分析与影响评估
- ✅ 生成结构化更新报告
- ✅ 支持自动化定时任务

## 工作流程

### 1. 读取项目配置

读取 `references/projects.json` 获取要追踪的 GitHub 项目列表。

配置文件格式：
```json
{
  "projects": [
    {
      "name": "openclaw",
      "owner": "openclaw",
      "repo": "openclaw",
      "enabled": true,
      "tags": ["自动化", "AI"]
    }
  ],
  "last_check": {
    "openclaw": "2026-04-01T00:00:00Z"
  }
}
```

### 2. 检查更新

使用 `scripts/check_updates.py` 脚本：

```bash
python scripts/check_updates.py --project openclaw/openclaw
```

脚本会：
- 获取最新 Release 信息
- 获取 CHANGELOG 内容
- 返回 JSON 格式的结构化数据

### 3. AI 分析与报告

基于脚本返回的数据，AI 进行深度分析：

1. **变更类型识别**
   - 🆕 新功能 (New Features)
   - 🐛 Bug 修复 (Bug Fixes)
   - ⚠️ Breaking Changes
   - 📚 文档更新 (Documentation)
   - 🔧 性能优化 (Performance)
   - 🔒 安全更新 (Security)

2. **影响分析**
   - 对现有功能的影响
   - 需要注意的迁移变更
   - 推荐的升级策略

### 4. 生成报告

输出结构化报告，保存到工作目录的 `github-updates/` 目录：

```
github-updates/
├── 2026-04-10-openclaw-update.md
├── 2026-04-10-update-summary.md
└── projects_status.json
```

## 自动化设置

当用户请求设置自动化任务时：

1. 使用 `automation_update` 工具创建定时任务
2. 配置检查频率（有更新就通知 → 每天检查）
3. 提示用户提供需要追踪的项目列表

自动化 Prompt 示例：
```
检查以下 GitHub 项目的最新更新：
1. 读取 ~/.workbuddy/skills/github-release-tracker/references/projects.json 中的项目列表
2. 使用 scripts/check_updates.py 检查每个项目是否有新版本
3. 如果有新版本，获取 CHANGELOG 并生成更新摘要报告
4. 保存报告到 github-updates/ 目录
5. 通知用户有新的更新可用
```

## 新增项目

用户可以通过以下方式添加新项目：

1. 直接编辑 `references/projects.json`
2. 或告诉 AI：「添加项目 xxx/yyy 到追踪列表」

## 配置文件路径

- 项目配置：`references/projects.json`
- 检查脚本：`scripts/check_updates.py`
- 输出目录：`github-updates/`
