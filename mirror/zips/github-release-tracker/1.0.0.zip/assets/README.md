# GitHub Release Tracker 使用指南

## 快速开始

### 1. 安装 GitHub CLI

```bash
# Windows (使用 winget)
winget install GitHub.cli

# 或下载安装包
# https://cli.github.com/
```

### 2. 登录 GitHub

```bash
gh auth login
```

### 3. 验证安装

```bash
gh auth status
```

## 使用方法

### 手动检查更新

```bash
# 检查单个项目
python scripts/check_updates.py --project openclaw/openclaw

# 检查并保存到文件
python scripts/check_updates.py --project openclaw/openclaw --output result.json
```

### 添加新项目

编辑 `references/projects.json`：

```json
{
  "projects": [
    {
      "name": "项目名称",
      "owner": "所有者",
      "repo": "仓库名",
      "enabled": true,
      "tags": ["标签1", "标签2"]
    }
  ]
}
```

## 自动化任务

设置每日自动检查：
- 告诉 WorkBuddy：「设置 GitHub 项目更新检查自动化」
- 系统会自动配置每日定时任务

## 依赖

- Python 3.8+
- GitHub CLI (`gh`)
