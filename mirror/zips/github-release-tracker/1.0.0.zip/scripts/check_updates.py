#!/usr/bin/env python3
"""
GitHub Release Tracker - 检查 GitHub 项目更新
支持获取 Releases、CHANGELOG 和 Commit 历史
"""

import argparse
import json
import sys
import subprocess
from datetime import datetime
from pathlib import Path


def run_github_cli(cmd: list) -> dict:
    """执行 gh CLI 命令"""
    try:
        result = subprocess.run(
            ["gh"] + cmd,
            capture_output=True,
            text=True,
            check=True
        )
        return {"success": True, "data": result.stdout.strip()}
    except subprocess.CalledProcessError as e:
        return {"success": False, "error": e.stderr.strip()}
    except FileNotFoundError:
        return {"success": False, "error": "gh CLI 未安装"}


def check_gh_auth():
    """检查 gh CLI 是否已登录"""
    result = run_github_cli(["auth", "status"])
    if not result["success"]:
        print(json.dumps({
            "type": "error",
            "message": "GitHub CLI 未登录，请运行 'gh auth login'",
            "action": "login"
        }, ensure_ascii=False, indent=2))
        sys.exit(1)


def get_latest_release(owner: str, repo: str) -> dict:
    """获取最新 Release 信息"""
    result = run_github_cli(["release", "view", "--repo", f"{owner}/{repo}", "--json", "tagName,name,body,createdAt"])

    if result["success"] and result["data"]:
        try:
            return json.loads(result["data"])
        except json.JSONDecodeError:
            return {"tagName": "unknown", "name": "Unknown", "body": result["data"], "createdAt": ""}
    return {}


def get_changelog(owner: str, repo: str) -> dict:
    """获取 CHANGELOG 内容"""
    paths = ["CHANGELOG.md", "CHANGELOG", "changelog.md", "CHANGELOG.html"]

    for path in paths:
        result = run_github_cli(["api", "repos", f"{owner}/{repo}", "contents", path])
        if result["success"]:
            try:
                data = json.loads(result["data"])
                content = data.get("content", "")
                # Base64 解码
                import base64
                decoded = base64.b64decode(content).decode("utf-8")
                return {
                    "path": path,
                    "content": decoded[:5000],  # 限制长度
                    "url": data.get("html_url", "")
                }
            except:
                continue
    return {"path": None, "content": "", "url": ""}


def get_commits_since(owner: str, repo: str, since: str) -> list:
    """获取指定日期之后的提交"""
    result = run_github_cli([
        "api", "repos", f"{owner}/{repo}", "commits",
        "--jq", "[.[] | {sha: .sha, message: .commit.message, date: .commit.author.date}]",
        "--since", since
    ])

    if result["success"]:
        try:
            return json.loads(result["data"])
        except:
            return []
    return []


def check_repository_exists(owner: str, repo: str) -> bool:
    """检查仓库是否存在"""
    result = run_github_cli(["repo", "view", f"{owner}/{repo}", "--json", "name"])
    return result["success"]


def main():
    parser = argparse.ArgumentParser(description="GitHub 项目更新检查工具")
    parser.add_argument("--project", "-p", required=True, help="项目名称，格式: owner/repo")
    parser.add_argument("--since", "-s", help="检查此日期之后的更新 (ISO 8601格式)")
    parser.add_argument("--output", "-o", help="输出文件路径 (JSON)")
    parser.add_argument("--format", "-f", choices=["json", "markdown"], default="json", help="输出格式")

    args = parser.parse_args()

    # 检查 gh CLI 认证
    check_gh_auth()

    # 解析项目名称
    if "/" not in args.project:
        print(json.dumps({
            "type": "error",
            "message": f"项目格式错误: {args.project}，应为 owner/repo 格式"
        }, ensure_ascii=False, indent=2))
        sys.exit(1)

    owner, repo = args.project.split("/", 1)

    # 检查仓库是否存在
    if not check_repository_exists(owner, repo):
        print(json.dumps({
            "type": "error",
            "message": f"仓库不存在或无权访问: {owner}/{repo}"
        }, ensure_ascii=False, indent=2))
        sys.exit(1)

    # 获取最新 Release
    latest_release = get_latest_release(owner, repo)

    # 获取 CHANGELOG
    changelog = get_changelog(owner, repo)

    # 获取最近提交
    since = args.since or "2026-01-01T00:00:00Z"
    recent_commits = get_commits_since(owner, repo, since)

    # 组装结果
    result = {
        "type": "update_check",
        "project": f"{owner}/{repo}",
        "checked_at": datetime.now().isoformat(),
        "latest_release": latest_release,
        "changelog": changelog,
        "recent_commits_count": len(recent_commits),
        "recent_commits": recent_commits[:10]  # 只返回最近10条
    }

    # 输出结果
    if args.output:
        Path(args.output).write_text(json.dumps(result, ensure_ascii=False, indent=2))
        print(f"结果已保存到: {args.output}")
    else:
        print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
