# public data fallbacks
