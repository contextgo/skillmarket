import re
import threading
from enum import Enum
from pathlib import Path
from typing import Callable, Optional

from core import BiliDownloader, DownloadException


class State(Enum):
    IDLE = "IDLE"
    DOWNLOADING = "DOWNLOADING"


class BilibiliDownloadSkill:
    TRIGGERS = ["下载B站视频", "下载B站音频", "保存BV", "bilibili下载"]
    BV_PATTERN = re.compile(r"(BV[0-9A-Za-z]+)", re.IGNORECASE)

    def __init__(self, downloader: BiliDownloader, save_dir: Path, reply: Callable[[str], None]):
        self.downloader = downloader
        self.save_dir = save_dir
        self.reply = reply

        self.state = State.IDLE
        self.pending_bvid: Optional[str] = None
        self.pending_title: Optional[str] = None
        self.pending_media_type: str = "video"
        self._lock = threading.RLock()

    @staticmethod
    def is_trigger_message(message: Optional[str]) -> bool:
        if message is None:
            return False
        return any(keyword in message for keyword in BilibiliDownloadSkill.TRIGGERS)

    def on_message(self, message: Optional[str]) -> str:
        with self._lock:
            if message is None or not message.strip():
                return "请发送包含BV号的消息，例如：下载B站视频 BV1xx411c7mD"

            if self.state == State.DOWNLOADING:
                return "正在下载中，请稍候…"

            if not self.is_trigger_message(message):
                return "未触发Skill。可用关键词：下载B站视频 / 下载B站音频 / 保存BV / bilibili下载"

            bvid = self._extract_bvid(message)
            if bvid is None:
                return "未识别到BV号，请按示例发送：下载B站视频 BV1xx411c7mD"

            media_type = self._detect_media_type(message)

            try:
                info = self.downloader.get_video_info(bvid)
                qn_list = self.downloader.get_available_qualities(bvid)
                self.pending_bvid = info.bvid
                self.pending_title = info.title
                self.pending_media_type = media_type
                self._start_download_async()
                target = "音频" if media_type == "audio" else "视频"
                return (
                    f"找到视频：《{self.pending_title}》\n"
                    f"可用清晰度(QN)：{qn_list if qn_list else '未知(将自动选择最高可用)'}\n"
                    f"开始下载{target}，完成后将通知结果。"
                )
            except Exception as e:  # Java 行为：统一兜底分类
                return self._to_friendly_error(e)

    def _start_download_async(self) -> None:
        self.state = State.DOWNLOADING
        bvid = self.pending_bvid
        media_type = self.pending_media_type

        def _worker() -> None:
            try:
                # 静默下载：不输出开始提示、不输出进度百分比
                output = self.downloader.download(bvid, str(self.save_dir), None, media_type)
                self.reply(f"下载完成，文件已保存到：{output}")
            except Exception as e:
                self.reply(self._to_friendly_error(e))
            finally:
                with self._lock:
                    self._reset_pending()

        t = threading.Thread(target=_worker, name="Skill-Bili-Download", daemon=True)
        t.start()

    @classmethod
    def _extract_bvid(cls, message: str) -> Optional[str]:
        m = cls.BV_PATTERN.search(message)
        if not m:
            return None
        bv = m.group(1)
        return "BV" + bv[2:]

    @staticmethod
    def _detect_media_type(message: str) -> str:
        return "audio" if "下载B站音频" in message else "video"

    def _reset_pending(self) -> None:
        self.pending_bvid = None
        self.pending_title = None
        self.pending_media_type = "video"
        self.state = State.IDLE

    @staticmethod
    def _to_friendly_error(e: Exception) -> str:
        msg = str(e) if str(e) else e.__class__.__name__
        low = msg.lower()

        if isinstance(e, DownloadException):
            # 保持 Java 行为：仍按关键字映射，不新增额外分支文案
            pass

        if "invalid bvid" in low or "未识别" in low or "empty pagelist" in low:
            return "BV号无效或不存在，请检查后重试。"

        if (
            "cannot run program" in low
            or "createprocess error=2" in low
            or "ffmpeg failed" in low
            or "ffmpeg.exe" in low
            or "no such file or directory" in low and "ffmpeg" in low
        ):
            return "FFmpeg 未找到或执行失败，请确认 `release/ffmpeg.exe` 存在，或在 BiliDownloader 构造时指定 ffmpeg 路径。"

        if "timed out" in low or "unknownhost" in low or "http" in low:
            return f"网络请求失败，请检查网络连接后重试。详细错误：{msg}"

        return f"发生错误：{msg}"
