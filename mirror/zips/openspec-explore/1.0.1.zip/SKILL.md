---
name: bilibili-down
description: >
  当用户希望在对话中通过 BV 号下载 B 站视频时使用此技能，
  包括“下载B站视频”“下载B站音频”“保存BV”等请求。该技能会解析 BV、预览标题与清晰度列表、
  直接开始下载，完成后按请求输出视频或音频。
version: 1.1.0
---

# BilibiliDown Skill

## 作用范围
- 仅处理基于 Bilibili BV 号的对话式下载流程。
- 复用 `core/` 与 `scripts/` 下的本地 Python 运行模块。

## 资源映射
- `scripts/bilibili_download_skill.py`
  - 有状态对话编排器（`IDLE / DOWNLOADING`）。
- `core/bili_downloader.py`
  - 下载器核心（WBI 签名、信息查询、媒体下载、ffmpeg 合并）。
- `core/exceptions.py`
  - 下载异常分类定义。
- `reference/python-usage-order.md`
  - 面向 Agent 的唯一首读说明（入口、调用链、边界）。

## 触发规则（L0 严格）
- 触发关键词：
  - `下载B站视频`
  - `下载B站音频`
  - `保存BV`
  - `bilibili下载`
- 在 `IDLE` 状态下若未命中触发词，返回未触发提示。

## 输入解析
- 使用正则提取 BV：`BV[0-9A-Za-z]+`（大小写不敏感）。
- 将 BV 前缀标准化为大写 `BV`。
- 若缺少 BV，返回引导提示。

## 状态机
- `IDLE`
  - 校验触发词 -> 解析 BV -> 查询视频信息与清晰度 -> 直接启动异步下载。
- `DOWNLOADING`
  - 收到任何新消息：回复“正在下载中，请稍候…”。
  - 工作线程完成后：发送最终结果消息并重置为 `IDLE`。

## 直接下载规则
- 一旦检测到有效触发词 + BV，立即开始下载。
- 不需要确认步骤。
- 触发词包含 `下载B站音频` 时优先输出音频文件（`.m4a`，无损抽取）。
- 若当前 ffmpeg/源流不支持 m4a 抽取，则自动回退输出 `.mp3`（优先 `libmp3lame`，再退化到 `mp3` 编码器）。
- 其余触发词默认输出视频文件（`.mp4`）。

## 错误映射
1. BV 无效
- 匹配：`invalid bvid` / `empty pagelist` / `未识别`
- 输出：`BV号无效或不存在，请检查后重试。`

2. FFmpeg 缺失/失败
- 匹配：`cannot run program` / `createprocess error=2` / `ffmpeg failed` / `ffmpeg.exe`
- 输出：`FFmpeg 未找到或执行失败，请确认 \`release/ffmpeg.exe\` 存在，或在 BiliDownloader 构造时指定 ffmpeg 路径。`

3. 网络错误
- 匹配：`timed out` / `unknownhost` / `http`
- 输出：`网络请求失败，请检查网络连接后重试。详细错误：{msg}`

4. 兜底
- 输出：`发生错误：{msg}`

## 反模式
- 在直接下载模式下，不要引入确认状态或 yes/no 门控。
- 不要在同一个 skill 实例中启动并发下载。
- 在完成/取消/报错后，不要保留过期的 pending 状态。
