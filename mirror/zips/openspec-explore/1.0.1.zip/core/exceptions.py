class DownloadException(Exception):
    """Base exception for downloader core."""


class InvalidBvidError(DownloadException):
    pass


class NetworkError(DownloadException):
    pass


class FfmpegNotFoundError(DownloadException):
    pass


class FfmpegExecutionError(DownloadException):
    pass


class CoreApiError(DownloadException):
    pass

