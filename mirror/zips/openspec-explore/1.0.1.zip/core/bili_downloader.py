import hashlib
import os
import re
import subprocess
import threading
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple
from urllib.parse import quote
from concurrent.futures import ThreadPoolExecutor, as_completed

import httpx

from .exceptions import (
    CoreApiError,
    FfmpegExecutionError,
    FfmpegNotFoundError,
    InvalidBvidError,
    NetworkError,
)


ProgressListener = Callable[[str, float], None]


@dataclass
class Clip:
    cid: int
    page: int
    part: str


@dataclass
class VideoInfo:
    bvid: str = ""
    aid: int = 0
    title: str = ""
    desc: str = ""
    cover: str = ""
    owner_name: str = ""
    clips: List[Clip] = field(default_factory=list)


class BiliDownloader:
    DEFAULT_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:93.0) Gecko/20100101 Firefox/93.0"

    def __init__(self, user_agent: Optional[str] = None, ffmpeg_path: Optional[str] = None, multi_thread_count: int = 0):
        self.user_agent = user_agent.strip() if user_agent and user_agent.strip() else self.DEFAULT_UA
        self.ffmpeg_path = ffmpeg_path.strip() if ffmpeg_path and ffmpeg_path.strip() else "ffmpeg"
        self.http = _HttpClient(self.user_agent)
        self.signer = _WbiSigner(self.http)
        self.downloader = _FileDownloader(self.user_agent, max(0, int(multi_thread_count)))

    def get_video_info(self, bvid: str) -> VideoInfo:
        normalized = self._normalize_bvid(bvid)
        headers = self._bili_api_headers(normalized)

        pagelist_url = f"https://api.bilibili.com/x/player/pagelist?bvid={normalized}&jsonp=jsonp"
        pagelist_obj = self.http.get_json(pagelist_url, headers, with_fingerprint_cookie=True)
        pages = pagelist_obj.get("data", [])
        if not pages:
            raise InvalidBvidError(f"Empty pagelist for bvid: {normalized}")

        detail_url = (
            "https://api.bilibili.com/x/web-interface/wbi/view/detail?"
            f"platform=web&page_no=1&p=1&need_operation_card=1&web_rm_repeat=1&need_elec=1&bvid={normalized}"
        )
        detail_url = self.signer.enc_wbi(detail_url)
        detail_raw = self.http.get_json(detail_url, headers, with_fingerprint_cookie=True)

        try:
            view = detail_raw["data"]["View"]
        except Exception as exc:
            raise CoreApiError(f"Invalid detail response for bvid: {normalized}") from exc

        info = VideoInfo(
            bvid=normalized,
            aid=int(view.get("aid", 0) or 0),
            title=view.get("title", "") or "",
            desc=view.get("desc", "") or "",
            cover=view.get("pic", "") or "",
            owner_name=(view.get("owner") or {}).get("name", "") or "",
        )

        for i, p in enumerate(pages):
            info.clips.append(
                Clip(
                    cid=int(p.get("cid", 0) or 0),
                    page=int(p.get("page", i + 1) or (i + 1)),
                    part=(p.get("part", f"P{i + 1}") or f"P{i + 1}"),
                )
            )
        return info

    def get_available_qualities(self, bvid: str) -> List[int]:
        info = self.get_video_info(bvid)
        if not info.clips:
            return []

        clip = info.clips[0]
        play = self._query_play_url(info.bvid, clip.cid, 127)
        data = play.get("data") or {}

        quality_list: List[int] = []
        accept = data.get("accept_quality")
        if isinstance(accept, list):
            for q in accept:
                try:
                    quality_list.append(int(q))
                except Exception:
                    pass
        else:
            dash = data.get("dash") or {}
            videos = dash.get("video") or []
            for v in videos:
                qn = int(v.get("id", 0) or 0)
                if qn > 0 and qn not in quality_list:
                    quality_list.append(qn)

        quality_list.sort(reverse=True)
        return quality_list

    def download(
        self,
        bvid: str,
        path: str,
        progress_cb: Optional[ProgressListener] = None,
        media_type: str = "video",
    ) -> Path:
        info = self.get_video_info(bvid)
        if not info.clips:
            raise InvalidBvidError(f"No clips for bvid: {info.bvid}")

        media_kind = (media_type or "video").strip().lower()
        audio_only = media_kind == "audio"

        clip = info.clips[0]
        save_dir = Path(path)
        save_dir.mkdir(parents=True, exist_ok=True)

        play = self._query_play_url(info.bvid, clip.cid, 127)
        data = play.get("data")
        if not isinstance(data, dict):
            raise CoreApiError(f"No play data for bvid: {info.bvid}")

        safe_name = self._sanitize_file_name(info.title if info.title else info.bvid)
        output_ext = ".m4a" if audio_only else ".mp4"
        output = save_dir / f"{safe_name}-p{clip.page}{output_ext}"

        dash = data.get("dash")
        if isinstance(dash, dict):
            video_url, audio_url = self._choose_dash(dash, int(data.get("quality", 80) or 80))
            if audio_only:
                if not audio_url:
                    raise CoreApiError(f"No dash audio url for {info.bvid}")

                a_tmp = save_dir / f"{safe_name}-p{clip.page}_audio.m4s"
                self.downloader.download(
                    audio_url,
                    a_tmp,
                    self._bili_media_headers(info.bvid),
                    lambda stage, p: progress_cb("audio", p) if progress_cb else None,
                )
                if progress_cb:
                    progress_cb("merge", 99.0)
                output = _FfmpegMerger.extract_audio_prefer_m4a(self.ffmpeg_path, a_tmp, output)
                try:
                    a_tmp.unlink(missing_ok=True)
                except Exception:
                    pass
                if progress_cb:
                    progress_cb("done", 100.0)
                return output.resolve()

            if not video_url:
                raise CoreApiError(f"No dash video url for {info.bvid}")

            v_tmp = save_dir / f"{safe_name}-p{clip.page}_video.m4s"
            a_tmp = save_dir / f"{safe_name}-p{clip.page}_audio.m4s"

            self.downloader.download(
                video_url,
                v_tmp,
                self._bili_media_headers(info.bvid),
                lambda stage, p: progress_cb("video", p * 0.50) if progress_cb else None,
            )

            if audio_url:
                self.downloader.download(
                    audio_url,
                    a_tmp,
                    self._bili_media_headers(info.bvid),
                    lambda stage, p: progress_cb("audio", 50.0 + p * 0.50) if progress_cb else None,
                )
                if progress_cb:
                    progress_cb("merge", 99.0)
                _FfmpegMerger.merge_av(self.ffmpeg_path, v_tmp, a_tmp, output)
                try:
                    a_tmp.unlink(missing_ok=True)
                except Exception:
                    pass
            else:
                if progress_cb:
                    progress_cb("merge", 99.0)
                _FfmpegMerger.remux_single(self.ffmpeg_path, v_tmp, output)

            try:
                v_tmp.unlink(missing_ok=True)
            except Exception:
                pass

            if progress_cb:
                progress_cb("done", 100.0)
            return output.resolve()

        durl = data.get("durl")
        if not isinstance(durl, list) or not durl:
            raise CoreApiError(f"No dash/durl links for {info.bvid}")

        if len(durl) == 1:
            media_url = durl[0].get("url")
            if not media_url:
                raise CoreApiError(f"No durl media url for {info.bvid}")

            if audio_only:
                media_tmp = save_dir / f"{safe_name}-p{clip.page}_full.mp4"
                self.downloader.download(media_url, media_tmp, self._bili_media_headers(info.bvid), progress_cb)
                if progress_cb:
                    progress_cb("merge", 99.0)
                output = _FfmpegMerger.extract_audio_prefer_m4a(self.ffmpeg_path, media_tmp, output)
                try:
                    media_tmp.unlink(missing_ok=True)
                except Exception:
                    pass
            else:
                self.downloader.download(media_url, output, self._bili_media_headers(info.bvid), progress_cb)

            if progress_cb:
                progress_cb("done", 100.0)
            return output.resolve()

        parts: List[Path] = []
        total = len(durl)
        for idx, item in enumerate(durl):
            order = int(item.get("order", idx + 1) or (idx + 1))
            p_file = save_dir / f"{safe_name}-p{clip.page}-part{order}.flv"

            def _part_progress(stage: str, percent: float, i=idx, t=total) -> None:
                if progress_cb:
                    base = (i * 100.0) / t
                    step = percent / t
                    progress_cb("flv-part", base + step)

            media_url = item.get("url")
            if not media_url:
                raise CoreApiError(f"No flv part url for {info.bvid}")
            self.downloader.download(media_url, p_file, self._bili_media_headers(info.bvid), _part_progress)
            parts.append(p_file)

        if progress_cb:
            progress_cb("merge", 99.0)
        if audio_only:
            merged_tmp = save_dir / f"{safe_name}-p{clip.page}_merged.mp4"
            _FfmpegMerger.concat(self.ffmpeg_path, parts, merged_tmp)
            output = _FfmpegMerger.extract_audio_prefer_m4a(self.ffmpeg_path, merged_tmp, output)
            try:
                merged_tmp.unlink(missing_ok=True)
            except Exception:
                pass
        else:
            _FfmpegMerger.concat(self.ffmpeg_path, parts, output)

        for p in parts:
            try:
                p.unlink(missing_ok=True)
            except Exception:
                pass

        if progress_cb:
            progress_cb("done", 100.0)
        return output.resolve()

    def _query_play_url(self, bvid: str, cid: int, qn: int) -> dict:
        url = (
            "https://api.bilibili.com/x/player/wbi/playurl?"
            f"cid={cid}&bvid={bvid}&qn={qn}&type=&otype=json&fnver=0&fnval=4048&fourk=1&try_look=1"
        )
        url = self.signer.enc_wbi(url)
        return self.http.get_json(url, self._bili_api_headers(bvid), with_fingerprint_cookie=True)

    @staticmethod
    def _normalize_bvid(bvid: str) -> str:
        if bvid is None:
            raise InvalidBvidError("bvid is null")
        m = re.search(r"(BV[0-9A-Za-z]+)", bvid, re.IGNORECASE)
        if not m:
            raise InvalidBvidError(f"Invalid bvid: {bvid}")
        result = m.group(1)
        return "BV" + result[2:]

    def _bili_api_headers(self, av_id_or_bvid: str) -> Dict[str, str]:
        return {
            "Accept": "*/*",
            "Accept-Encoding": "gzip, deflate",
            "Accept-Language": "zh-CN,zh;q=0.8",
            "Connection": "keep-alive",
            "Host": "api.bilibili.com",
            "Referer": f"https://www.bilibili.com/video/{av_id_or_bvid}",
            "User-Agent": self.user_agent,
            "X-Requested-With": "ShockwaveFlash/28.0.0.137",
        }

    def _bili_media_headers(self, bvid: str) -> Dict[str, str]:
        return {
            "Referer": f"https://www.bilibili.com/video/{bvid}",
            "User-Agent": self.user_agent,
        }

    @staticmethod
    def _sanitize_file_name(name: str) -> str:
        return re.sub(r"[\\/:*?\"<>|]", "_", name)

    @staticmethod
    def _choose_dash(dash: dict, preferred_qn: int) -> Tuple[Optional[str], Optional[str]]:
        video_url = None
        audio_url = None

        videos = dash.get("video") or []
        audios = dash.get("audio") or []

        if isinstance(videos, list) and videos:
            sorted_v = sorted(videos, key=lambda x: abs(int(x.get("id", preferred_qn) or preferred_qn) - preferred_qn))
            v = sorted_v[0]
            video_url = v.get("base_url") or v.get("baseUrl")
            if not video_url:
                backups = v.get("backup_url") or []
                if backups:
                    video_url = backups[0]

        if isinstance(audios, list) and audios:
            a = audios[0]
            audio_url = a.get("base_url") or a.get("baseUrl")
            if not audio_url:
                backups = a.get("backup_url") or []
                if backups:
                    audio_url = backups[0]

        return video_url, audio_url


class _WbiSigner:
    MIXIN_ARRAY = [
        46, 47, 18, 2, 53, 8, 23, 32, 15, 50, 10, 31, 58, 3, 45, 35,
        27, 43, 5, 49, 33, 9, 42, 19, 29, 28, 14, 39, 12, 38, 41, 13,
        37, 48, 7, 16, 24, 55, 40, 61, 26, 17, 0, 1, 60, 51, 30, 4,
        22, 25, 54, 21, 56, 59, 6, 63, 57, 62, 11, 36, 20, 34, 44, 52,
    ]

    def __init__(self, http_client: "_HttpClient"):
        self._http = http_client
        self._wbi_img: Optional[str] = None
        self._lock = threading.Lock()

    def enc_wbi(self, url: str) -> str:
        self._ensure_wbi_url()
        assert self._wbi_img is not None

        mixin_key = self._get_mixin_key(self._wbi_img)
        wts = f"wts={int(time.time())}"

        q_idx = url.find("?")
        if q_idx >= 0:
            raw = url[q_idx + 1 :]
            sep = "" if not raw else "&"
            raw = f"{raw}{sep}{wts}"
            params = raw.split("&")
            encoded = []
            for p in params:
                kv = p.split("=", 1)
                key = quote(kv[0], safe="")
                value = self._encode_url_preserving_percent(kv[1]) if len(kv) >= 2 else ""
                encoded.append(f"{key}={value}")
            encoded.sort()
            param_encoded_sorted = "&".join(encoded)
            sep2 = "&" if raw else ""
        else:
            param_encoded_sorted = wts
            sep2 = "?"

        md5 = hashlib.md5((param_encoded_sorted + mixin_key).encode("utf-8")).hexdigest()
        return f"{url}{sep2}w_rid={md5}&{wts}"

    def _ensure_wbi_url(self) -> None:
        if self._wbi_img is not None:
            return
        with self._lock:
            if self._wbi_img is not None:
                return
            nav = self._http.get_json(
                "https://api.bilibili.com/x/web-interface/nav",
                self._common_headers(),
                with_fingerprint_cookie=True,
            )
            wbi = nav.get("data", {}).get("wbi_img", {})
            img_url = wbi.get("img_url", "")
            sub_url = wbi.get("sub_url", "")
            if not img_url or not sub_url:
                raise CoreApiError("wbi_img missing from nav response")
            self._wbi_img = self._file_name_without_ext(img_url) + self._file_name_without_ext(sub_url)

    @staticmethod
    def _file_name_without_ext(url: str) -> str:
        s = url.rfind("/")
        e = url.find(".", s)
        return url[s + 1 : e]

    @classmethod
    def _get_mixin_key(cls, content: str) -> str:
        return "".join(content[i] for i in cls.MIXIN_ARRAY[:32])

    @staticmethod
    def _encode_url_preserving_percent(raw: str) -> str:
        if "%" in raw:
            return raw.replace("+", "%20")
        return quote(raw, safe="").replace("+", "%20")

    @staticmethod
    def _common_headers() -> Dict[str, str]:
        return {
            "Accept": "text/html,application/xhtml+xml;q=0.9,image/webp,*/*;q=0.8",
            "Accept-Encoding": "gzip, deflate",
            "Accept-Language": "zh-CN,zh;q=0.8",
            "Connection": "keep-alive",
            "User-Agent": BiliDownloader.DEFAULT_UA,
        }


class _HttpClient:
    def __init__(self, user_agent: str):
        self.user_agent = user_agent
        self._fingerprint_cookies: Optional[Dict[str, str]] = None
        self._lock = threading.Lock()

    def get_json(self, url: str, headers: Optional[Dict[str, str]], with_fingerprint_cookie: bool) -> dict:
        text = self.get(url, headers, with_fingerprint_cookie)
        try:
            return httpx.Response(200, text=text).json()
        except Exception as exc:
            raise CoreApiError(f"Invalid JSON response from {url}") from exc

    def get(self, url: str, headers: Optional[Dict[str, str]], with_fingerprint_cookie: bool) -> str:
        req_headers = dict(headers or {})
        if "User-Agent" not in req_headers:
            req_headers["User-Agent"] = self.user_agent

        cookies = self._fingerprint_cookies_dict() if with_fingerprint_cookie else None
        try:
            with httpx.Client(timeout=10.0, follow_redirects=True) as client:
                resp = client.get(url, headers=req_headers, cookies=cookies)
            if resp.status_code >= 400 and not resp.text:
                raise NetworkError(f"HTTP {resp.status_code} with empty response for {url}")
            return resp.text
        except httpx.HTTPError as exc:
            raise NetworkError(str(exc)) from exc

    def _fingerprint_cookies_dict(self) -> Dict[str, str]:
        if self._fingerprint_cookies is not None:
            return self._fingerprint_cookies

        with self._lock:
            if self._fingerprint_cookies is not None:
                return self._fingerprint_cookies

            kv: Dict[str, str] = {}
            try:
                with httpx.Client(timeout=10.0, follow_redirects=True) as client:
                    resp = client.get("https://www.bilibili.com/", headers={"User-Agent": self.user_agent})
                for c in resp.cookies.jar:
                    kv[c.name] = c.value
            except httpx.HTTPError as exc:
                raise NetworkError(str(exc)) from exc

            kv["i-wanna-go-back"] = "-1"
            kv["b_lsid"] = f"{_random_hex(8)}_{format(int(time.time() * 1000), 'X')}"
            kv["_uuid"] = uuid.uuid4().hex + "infoc"
            kv["buvid_fp"] = _random_hex(32)
            kv["fingerprint"] = kv["buvid_fp"]

            try:
                with httpx.Client(timeout=10.0, follow_redirects=True) as client:
                    spi = client.get(
                        "https://api.bilibili.com/x/frontend/finger/spi",
                        headers={"User-Agent": self.user_agent},
                        cookies=kv,
                    )
                obj = spi.json()
                b4 = (obj.get("data") or {}).get("b_4", "")
                if b4:
                    kv["buvid4"] = b4
            except Exception:
                # 与 Java 行为对齐：该字段获取失败不终止流程
                pass

            self._fingerprint_cookies = kv
            return self._fingerprint_cookies


class _FileDownloader:
    def __init__(self, user_agent: str, multi_thread_count: int):
        self.user_agent = user_agent
        self.multi_thread_count = multi_thread_count

    def download(
        self,
        url: str,
        dst: Path,
        headers: Optional[Dict[str, str]],
        listener: Optional[ProgressListener] = None,
    ) -> None:
        dst.parent.mkdir(parents=True, exist_ok=True)
        if self.multi_thread_count > 1 and not re.search(r"(github|ffmpeg|\.jpg|\.png|\.webp|\.xml)", url):
            self._multi_thread_download(url, dst, headers, listener)
            if listener:
                listener("download", 100.0)
            return
        self._single_thread_download(url, dst, headers, listener)

    def _single_thread_download(
        self,
        url: str,
        dst: Path,
        headers: Optional[Dict[str, str]],
        listener: Optional[ProgressListener],
    ) -> None:
        part = Path(str(dst) + ".part")
        offset = part.stat().st_size if part.exists() else 0
        h = dict(headers or {})
        h["User-Agent"] = self.user_agent
        if offset > 0:
            h["range"] = f"bytes={offset}-"

        try:
            with httpx.Client(timeout=10.0, follow_redirects=True) as client:
                with client.stream("GET", url, headers=h) as resp:
                    resp.raise_for_status()
                    cl = resp.headers.get("Content-Length")
                    total = offset + int(cl) if cl and cl.isdigit() else -1
                    with open(part, "ab") as f:
                        downloaded = offset
                        for chunk in resp.iter_bytes(chunk_size=1024 * 1024):
                            if not chunk:
                                continue
                            f.write(chunk)
                            downloaded += len(chunk)
                            if listener and total > 0:
                                listener("download", min(100.0, downloaded * 100.0 / total))
        except httpx.HTTPError as exc:
            raise NetworkError(str(exc)) from exc

        os.replace(part, dst)
        if listener:
            listener("download", 100.0)

    def _multi_thread_download(
        self,
        url: str,
        dst: Path,
        headers: Optional[Dict[str, str]],
        listener: Optional[ProgressListener],
    ) -> None:
        total = self._probe_size(url, headers)
        if total <= 0:
            self._single_thread_download(url, dst, headers, listener)
            return

        part_size = total // self.multi_thread_count
        temp_parts = [Path(f"{dst}.part{i}") for i in range(self.multi_thread_count)]

        def _download_part(i: int) -> None:
            p = temp_parts[i]
            min_b = i * part_size
            max_b = total - 1 if i == self.multi_thread_count - 1 else (min_b + part_size - 1)
            offset = p.stat().st_size if p.exists() else 0
            if offset >= (max_b - min_b + 1):
                return
            h = dict(headers or {})
            h["User-Agent"] = self.user_agent
            h["range"] = f"bytes={min_b + offset}-{max_b}"
            try:
                with httpx.Client(timeout=10.0, follow_redirects=True) as client:
                    with client.stream("GET", url, headers=h) as resp:
                        resp.raise_for_status()
                        with open(p, "ab") as f:
                            for chunk in resp.iter_bytes(chunk_size=1024 * 1024):
                                if chunk:
                                    f.write(chunk)
            except httpx.HTTPError as exc:
                raise NetworkError(str(exc)) from exc

        with ThreadPoolExecutor(max_workers=self.multi_thread_count) as executor:
            futures = [executor.submit(_download_part, i) for i in range(self.multi_thread_count)]
            for fut in as_completed(futures):
                fut.result()

        with open(dst, "wb") as out:
            for p in temp_parts:
                with open(p, "rb") as src:
                    while True:
                        data = src.read(4 * 1024 * 1024)
                        if not data:
                            break
                        out.write(data)
                try:
                    p.unlink(missing_ok=True)
                except Exception:
                    pass

    def _probe_size(self, url: str, headers: Optional[Dict[str, str]]) -> int:
        h = dict(headers or {})
        h["User-Agent"] = self.user_agent
        try:
            with httpx.Client(timeout=10.0, follow_redirects=True) as client:
                resp = client.get(url, headers=h)
                resp.raise_for_status()
            cl = resp.headers.get("Content-Length")
            return int(cl) if cl and cl.isdigit() else -1
        except httpx.HTTPError as exc:
            raise NetworkError(str(exc)) from exc


class _FfmpegMerger:
    @staticmethod
    def merge_av(ffmpeg_path: str, video: Path, audio: Path, out: Path) -> None:
        cmd = [ffmpeg_path, "-y", "-i", str(video), "-i", str(audio), "-c", "copy", str(out)]
        _FfmpegMerger._run(cmd)

    @staticmethod
    def remux_single(ffmpeg_path: str, src: Path, out: Path) -> None:
        cmd = [ffmpeg_path, "-y", "-i", str(src), "-c", "copy", str(out)]
        _FfmpegMerger._run(cmd)

    @staticmethod
    def transcode_to_mp3(ffmpeg_path: str, src: Path, out: Path) -> None:
        cmd = [ffmpeg_path, "-y", "-i", str(src), "-vn", "-c:a", "libmp3lame", "-q:a", "2", str(out)]
        try:
            _FfmpegMerger._run(cmd)
        except FfmpegExecutionError as exc:
            # 某些精简版 ffmpeg 未暴露 libmp3lame 名称，回退到 mp3 编码器以保证功能可用。
            if "Unknown encoder 'libmp3lame'" not in str(exc):
                raise
            fallback = [ffmpeg_path, "-y", "-i", str(src), "-vn", "-c:a", "mp3", str(out)]
            _FfmpegMerger._run(fallback)

    @staticmethod
    def extract_audio_prefer_m4a(ffmpeg_path: str, src: Path, out_m4a: Path) -> Path:
        # 先尝试无损封装为 m4a，若 ffmpeg/流不支持再回退到 mp3。
        cmd = [ffmpeg_path, "-y", "-i", str(src), "-vn", "-c:a", "copy", "-f", "mp4", str(out_m4a)]
        try:
            _FfmpegMerger._run(cmd)
            return out_m4a
        except FfmpegExecutionError:
            try:
                out_m4a.unlink(missing_ok=True)
            except Exception:
                pass

        out_mp3 = out_m4a.with_suffix(".mp3")
        _FfmpegMerger.transcode_to_mp3(ffmpeg_path, src, out_mp3)
        return out_mp3

    @staticmethod
    def concat(ffmpeg_path: str, parts: List[Path], out: Path) -> None:
        list_file = Path(str(out) + ".txt")
        with open(list_file, "w", encoding="utf-8") as f:
            for p in parts:
                f.write(f"file '{str(p.resolve()).replace('\\\\', '/')}'\n")

        cmd = [ffmpeg_path, "-y", "-f", "concat", "-safe", "0", "-i", str(list_file), "-c", "copy", str(out)]
        try:
            _FfmpegMerger._run(cmd)
        finally:
            try:
                list_file.unlink(missing_ok=True)
            except Exception:
                pass

    @staticmethod
    def _run(cmd: List[str]) -> None:
        try:
            # 使用字节模式捕获输出，避免 text=True 在 Windows 上按本地编码解码崩溃。
            proc = subprocess.run(cmd, capture_output=True, text=False, check=False)
        except FileNotFoundError as exc:
            raise FfmpegNotFoundError(str(exc)) from exc

        stdout_text = _FfmpegMerger._decode_bytes(proc.stdout)
        stderr_text = _FfmpegMerger._decode_bytes(proc.stderr)
        if proc.returncode != 0:
            output = stdout_text + stderr_text
            raise FfmpegExecutionError(f"ffmpeg failed ({proc.returncode})\n{output}")

    @staticmethod
    def _decode_bytes(data: Optional[bytes]) -> str:
        if not data:
            return ""
        # 优先 UTF-8，其次 GBK，再兜底替换非法字符，确保永不抛 UnicodeDecodeError。
        for enc in ("utf-8", "gbk"):
            try:
                return data.decode(enc)
            except UnicodeDecodeError:
                pass
        return data.decode("utf-8", errors="replace")


def _random_hex(n: int) -> str:
    raw = uuid.uuid4().hex + uuid.uuid4().hex
    return raw[:n]

