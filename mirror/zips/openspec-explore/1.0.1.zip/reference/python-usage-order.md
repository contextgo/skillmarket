# Agent 首读说明（Python）

## 1) 入口与顺序
1. `scripts/bilibili_download_skill.py`
   - 对话入口：触发词识别、BV 提取、状态机、异步回调。
2. `core/bili_downloader.py`
   - 下载核心：WBI 签名、播放地址获取、下载、FFmpeg 合并/转码。

## 2) 最小调用链
`on_message(message)`
-> `_start_download_async()`
-> `BiliDownloader.download(bvid, path, None, media_type)`
-> `_FileDownloader.download(...)`
-> `_FfmpegMerger.*(...)`
-> `reply("下载完成...")`

## 3) 分支规则
- `media_type="video"` -> 输出 `.mp4`
- `media_type="audio"` -> 优先 `.m4a`，失败回退 `.mp3`

## 4) 修改边界（必须遵守）
- 改对话流程：只动 `scripts/bilibili_download_skill.py`
- 改下载能力：只动 `core/bili_downloader.py`
- 不要在 `scripts/` 重复实现下载逻辑

## 5) 运行前提
- 运行方需自行实例化 `BilibiliDownloadSkill` 并注入：
  - `BiliDownloader`
  - `save_dir`
  - `reply(message)` 回调

## 6) 接入示例
```python
from pathlib import Path
from core import BiliDownloader
from scripts.bilibili_download_skill import BilibiliDownloadSkill

downloader = BiliDownloader(ffmpeg_path=r"D:\Data\Desktop\BilibiliDown-6.40\release\ffmpeg.exe")
skill = BilibiliDownloadSkill(downloader, Path("."), print)
print(skill.on_message("下载B站视频 BV1bPQFB3EmH"))
```

