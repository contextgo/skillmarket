---
name: wisediag-skin
description: "Skin Disease Analysis — Analyze skin photos and identify possible conditions via WiseDiag AI. Usage: Provide a skin image URL and say Use WiseDiag Skin to analyze this photo."
registry:
  homepage: https://github.com/wisediag/WiseDiag-Skin
  author: wisediag
  credentials:
    required: true
    env_vars:
      - WISEDIAG_API_KEY
---

# ⚠️ Privacy Notice

**Please read before installing:**

This tool transmits image URLs **to WiseDiag cloud servers** for AI analysis.

**Do not upload images containing sensitive or private content** unless you trust WiseDiag's data handling policy.

**The output of this tool is for reference only and does not constitute medical diagnosis. Please consult a doctor for any health concerns.**

---

# WiseDiag Skin Disease Analysis (OpenClaw Skill)

Upload a skin photo and let WiseDiag AI automatically identify possible skin conditions and provide analysis and recommendations.

![License](https://img.shields.io/badge/License-MIT-blue.svg)
![Python](https://img.shields.io/badge/Python-3.10+-green.svg)

## Features

- Upload a skin image and AI automatically identifies possible skin conditions
- Results are automatically saved as a Markdown file

## Installation

```bash
pip install -r requirements.txt
```

## 🔑 API Key Configuration (Required)

**Get your API Key:** 👉 [https://console.wisediag.com/apiKeyManage](https://s.wisediag.com/xsu9x0jq)

```bash
export WISEDIAG_API_KEY=your_api_key_here
```

## Usage

**Do not call any API or HTTP endpoints directly — use only the script below.**

Step 1: Set your API Key (if not already set):

```bash
export WISEDIAG_API_KEY=your_api_key_here
```

Step 2: Run the script with a skin image URL:

```bash
cd scripts

# Basic usage
python3 skin.py --image "https://example.com/skin.jpg"

# Custom question
python3 skin.py --image "https://example.com/skin.jpg" --question "What could be causing this rash?"

# Specify output filename
python3 skin.py --image "https://example.com/skin.jpg" -n "skin_20260324"
```

Results are automatically saved to `~/.openclaw/workspace/WiseDiag-Skin/{name}.md` — no manual saving needed.

## Parameters

| Parameter | Description |
|-----------|-------------|
| `--image` | Public URL of the skin image (required) |
| `--question` | Question to ask (default: Please analyze this skin image and identify possible conditions) |
| `-n, --name` | Output filename (without extension) |
| `-o, --output` | Output directory (default: ~/.openclaw/workspace/WiseDiag-Skin) |

## FAQ

**"WISEDIAG_API_KEY is not set" error:**
Run `echo $WISEDIAG_API_KEY` to check whether the variable is set.

**"Authentication failed" error:**
Your API Key may be invalid or expired. Visit [console.wisediag.com](https://s.wisediag.com/xsu9x0jq) to regenerate it.

**Image not recognized:**
Ensure the image URL is publicly accessible and in JPG, JPEG, or PNG format.

## Data Privacy

Image URLs are sent to the WiseDiag API for analysis and are not permanently stored. Results are returned directly to you.

## ⚠️ Disclaimer

The output of this tool is for reference only and does not constitute medical diagnosis or treatment advice. Please consult a qualified healthcare professional for any health concerns.

## License

MIT
