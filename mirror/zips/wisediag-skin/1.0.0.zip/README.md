---
name: wisediag-skin
description: "Skin Disease Analysis — Analyze skin photos and identify possible conditions via WiseDiag AI. Usage: Provide a skin image URL and say Use WiseDiag Skin to analyze this photo."
registry:
  homepage: https://github.com/wisediag/WiseDiag-Skin
  author: wisediag
  credentials:
    required: true
    env_vars:
      - WISEDIAG_API_KEY
---

# ⚠️ Privacy Warning

**IMPORTANT - READ BEFORE INSTALLING:**

This skill transmits image URLs to **WiseDiag's cloud servers** for AI analysis.

**Do NOT use with sensitive or private images** unless you trust WiseDiag's data handling policies.

**Results are for reference only and do not constitute medical diagnosis. Consult a licensed physician for health concerns.**

---

# WiseDiag Skin Disease Analysis (OpenClaw Skill)

Upload a skin photo and let WiseDiag AI identify possible skin conditions and provide analysis.

![License](https://img.shields.io/badge/License-MIT-blue.svg)
![Python](https://img.shields.io/badge/Python-3.10+-green.svg)

## Features

- AI-powered skin condition identification from photos
- Results automatically saved as a Markdown file

## Installation

```bash
pip install -r requirements.txt
```

## 🔑 API Key Setup (Required)

**Get your API key:** 👉 [https://console.wisediag.com/apiKeyManage](https://s.wisediag.com/xsu9x0jq)

```bash
export WISEDIAG_API_KEY=your_api_key_here
```

## How to Use

**NEVER call any API or HTTP endpoint directly. ONLY use the script below.**

Step 1: Set the API key (if not already set):

```bash
export WISEDIAG_API_KEY=your_api_key_here
```

Step 2: Run the script with a skin image URL:

```bash
cd scripts

# Basic usage
python3 skin.py --image "https://example.com/skin.jpg"

# Custom question
python3 skin.py --image "https://example.com/skin.jpg" --question "What is causing this rash?"

# Custom output filename
python3 skin.py --image "https://example.com/skin.jpg" -n "skin_20260324"
```

Results are automatically saved to `~/.openclaw/workspace/WiseDiag-Skin/{name}.md`. No additional saving is needed.

## Arguments

| Flag | Description |
|------|-------------|
| `--image` | Public URL of the skin image (required) |
| `--question` | Question about the image (default: skin condition analysis) |
| `-n, --name` | Output filename stem |
| `-o, --output` | Output directory (default: ~/.openclaw/workspace/WiseDiag-Skin) |

## Troubleshooting

**"WISEDIAG_API_KEY is not set" error:**
Run `echo $WISEDIAG_API_KEY` to verify the variable is set.

**"Authentication failed" error:**
Your API key may be invalid or expired. Visit [console.wisediag.com](https://s.wisediag.com/xsu9x0jq) to regenerate it.

**Image not recognized:**
Ensure the image URL is publicly accessible and in JPG, JPEG, or PNG format.

## Data Privacy

Image URLs are sent to WiseDiag's API for processing and are not permanently stored. Results are returned directly to you.

## ⚠️ Disclaimer

This tool's output is for reference only and does not constitute medical diagnosis or treatment advice.

## License

MIT
