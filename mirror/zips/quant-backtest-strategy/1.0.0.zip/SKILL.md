---
name: quant-backtest-strategy
version: 1.0.0
description: 量化策略回测，5套内置A股策略+自定义策略，专业绩效报告含胜率/回撤/夏普/评分，模拟盘自动交易。触发词：策略回测、回测、量化回测、backtest、策略测试、回测报告、策略绩效、模拟盘、paper trading、量化策略
---

# 量化策略回测

## 概述

专业级A股量化策略回测系统，5套内置策略开箱即用，支持自定义策略开发。逐日驱动回测引擎，生成专业绩效报告（胜率/最大回撤/夏普比率/综合评分/优化建议），模拟盘可直接上线验证。

## 5套内置策略

| # | 策略ID | 名称 | 原理 | 适合行情 | 不适合行情 |
|---|--------|------|------|----------|------------|
| 1 | trend_ma | 📈 趋势追踪 | MA均线金叉死叉 | 单边趋势 | 横盘震荡 |
| 2 | bollinger_rsi | 📊 震荡突破 | 布林带+RSI | 横盘震荡 | 单边趋势 |
| 3 | td_sequential | 🔄 短线九转 | 神奇九转TD序列 | 震荡反弹 | 强趋势 |
| 4 | grid | 🔲 网格交易 | 自动高抛低吸 | 区间震荡 | 单边暴跌 |
| 5 | multi_factor | 🌟 多因子融合 | 趋势+资金+筹码三维合一 | 全行情 | - |

## 回测框架架构

```
BacktestEngine（回测引擎）
  ├── StrategyBase（策略基类）
  │   ├── generate_signals()  → 产生买卖信号
  │   ├── on_bar()            → 每日回调
  │   └── 工具方法: sma/ema/crossover/atr
  ├── Portfolio（投资组合）
  │   ├── buy/sell()           → 模拟交易（含滑点+手续费）
  │   ├── check_stop_loss()    → 止损止盈检查
  │   └── update_daily()       → 每日净值更新
  └── PerformanceAnalyzer（绩效分析）
      ├── 基础指标: 收益率/年化/交易天数
      ├── 风险指标: 最大回撤/夏普比率/波动率
      ├── 交易统计: 胜率/盈亏比/平均盈利
      └── 综合评分: S/A/B/C/D 五档评级
```

## API使用

### 获取策略列表

```
GET /api/backtest/strategies
```

返回5套策略的名称、描述、参数定义。

### 运行回测

```
POST /api/backtest/run
Content-Type: application/json

{
  "strategy": "trend_ma",
  "symbols": ["000001.SZ", "600519.SH"],
  "start_date": "2025-01-01",
  "end_date": "2026-01-01",
  "initial_capital": 1000000,
  "params": {
    "fast_period": 5,
    "slow_period": 20
  }
}
```

### 回测报告结构

```json
{
  "success": true,
  "report": {
    "basic": {
      "strategy_name": "趋势追踪",
      "symbols": ["000001.SZ"],
      "start_date": "2025-01-01",
      "end_date": "2026-01-01",
      "initial_capital": 1000000,
      "final_capital": 1150000
    },
    "returns": {
      "total_return_pct": 15.0,
      "annual_return_pct": 15.0,
      "benchmark_return_pct": 8.5,
      "excess_return_pct": 6.5
    },
    "risk": {
      "max_drawdown_pct": -8.2,
      "max_drawdown_start": "2025-03-15",
      "max_drawdown_end": "2025-04-10",
      "sharpe_ratio": 1.35,
      "volatility_pct": 12.5
    },
    "trades": {
      "total_trades": 24,
      "win_trades": 16,
      "loss_trades": 8,
      "win_rate": 66.7,
      "profit_loss_ratio": 2.1,
      "avg_profit_pct": 3.5,
      "avg_loss_pct": -1.7
    },
    "score": {
      "grade": "A",
      "total_score": 82,
      "suggestion": "策略表现优秀，胜率66.7%超过基准，最大回撤8.2%可控。建议：可适当提高仓位，关注止损执行。"
    },
    "monthly": [
      {"month": "2025-01", "return_pct": 2.3, "trades": 3},
      ...
    ]
  }
}
```

## 自定义策略开发

继承 `StrategyBase` 类，只需实现 `generate_signals()` 方法：

```python
from backtest.strategy_base import StrategyBase, Signal, SignalType

class MyStrategy(StrategyBase):
    name = "我的策略"
    description = "自定义策略描述"
    symbols = ['000001.SZ']
    params = {'period': 20}

    def generate_signals(self, date, kline_data, portfolio):
        signals = []
        for symbol in self.symbols:
            if symbol not in kline_data:
                continue
            closes = [k['close'] for k in kline_data[symbol]]
            # ... 你的策略逻辑 ...
            if should_buy:
                signals.append(Signal(
                    symbol=symbol,
                    signal_type=SignalType.BUY,
                    price=closes[-1],
                    date=date,
                    strength=0.8,
                    reason="买入原因"
                ))
        return signals
```

## 模拟盘使用

回测通过后，可在模拟盘上线验证：

```
POST /api/paper-trader/order
{
  "symbol": "000001.SZ",
  "side": "buy",
  "quantity": 100,
  "price": 0,
  "order_type": "market"
}
```

模拟盘功能：
- 手动下单 / 策略自动下单
- 持仓实时同步（RQData价格）
- 盈亏统计（总资产/总盈亏/可用资金/持仓市值）
- 微信推送（信号/成交/预警/日报）

## 绩效评分标准

| 评级 | 总分 | 说明 |
|------|------|------|
| S | 90-100 | 极优策略，可直接实盘 |
| A | 75-89 | 优秀策略，小幅优化后实盘 |
| B | 60-74 | 良好策略，需进一步验证 |
| C | 40-59 | 一般策略，需大幅优化 |
| D | 0-39 | 较差策略，不建议使用 |

## 注意事项

- 回测结果不代表未来收益，仅供参考
- 回测默认使用沪深300作为基准
- 滑点默认0.1%，佣金默认万三（含印花税千一）
- 回测时间越长，结果越可靠（建议≥125个交易日）
- 自定义策略需放置在 main/backtest/strategies.py 中

## 免责声明

本Skill提供的量化分析结果仅供参考学习，不构成任何投资建议。投资有风险，入市需谨慎。
