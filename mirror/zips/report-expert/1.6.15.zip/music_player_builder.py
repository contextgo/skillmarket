#!/usr/bin/env python3
"""
音乐播放页面生成器 (v3)

v3: 播放页从 song.json 和 lyrics-timed.json 动态加载，
构建脚本只需将模板复制到目标目录即可。

歌曲目录结构：
  {dir}/index.html      -- 播放页面（从模板复制，无需修改）
  {dir}/song.json      -- 歌曲信息
  {dir}/song.mp3       -- 音乐文件
  {dir}/cover.jpg      -- 封面图
  {dir}/lyrics.txt     -- 纯文本歌词
  {dir}/lyrics-timed.json -- 带时序歌词

用法：
  python3 music_player_builder.py \
    --mp3 song.mp3 \
    --cover cover.jpg \
    --lyrics lyrics-timed.json \
    --lyrics-text lyrics.txt \
    --title "歌曲名" \
    --subtitle "副标题" \
    --artist "microsnow" \
    --output /path/to/song-dir/index.html

  # 最简用法（只指定 mp3、cover、title）
  python3 music_player_builder.py \
    --mp3 song.mp3 --cover cover.jpg --title "歌名" \
    --output /path/to/song-dir/index.html
"""

import argparse
import json
import os
import re
import shutil
import sys


def get_template_path():
    template_dir = os.path.dirname(os.path.abspath(__file__))
    template = os.path.join(template_dir, 'templates', 'music-player.html')
    if os.path.exists(template):
        return template
    template = os.path.join(os.path.dirname(template_dir), 'templates', 'music-player.html')
    if os.path.exists(template):
        return template
    raise FileNotFoundError(f"Template not found: {template}")


def copy_mp3_cover(src_mp3, src_cover, output_dir):
    """Copy mp3 and cover to target directory."""
    if src_mp3 and os.path.exists(src_mp3):
        dst = os.path.join(output_dir, 'song.mp3')
        if os.path.abspath(src_mp3) != os.path.abspath(dst):
            shutil.copy2(src_mp3, dst)
        sz = os.path.getsize(dst)
        print(f"   song.mp3  ({sz / 1024 / 1024:.1f} MB)")
    if src_cover and os.path.exists(src_cover):
        dst = os.path.join(output_dir, 'cover.jpg')
        if os.path.abspath(src_cover) != os.path.abspath(dst):
            shutil.copy2(src_cover, dst)
        sz = os.path.getsize(dst)
        print(f"   cover.jpg ({sz / 1024:.1f} KB)")


def copy_lyrics(src_lyrics, output_dir):
    """Copy lyrics-timed.json and/or lyrics.txt to target directory."""
    if src_lyrics and os.path.exists(src_lyrics):
        dest = os.path.join(output_dir, 'lyrics-timed.json')
        if os.path.abspath(src_lyrics) != os.path.abspath(dest):
            shutil.copy2(src_lyrics, dest)
        print(f"   lyrics-timed.json")
        return True
    return False


def write_song_json(output_dir, title, subtitle, artist, credits):
    """Write song.json with metadata."""
    data = {
        "title": title,
        "subtitle": subtitle or "",
        "artist": artist or "",
        "credits": {
            "lyrics": credits.get("lyrics", artist),
            "compose": credits.get("compose", artist),
            "sing": credits.get("sing", artist),
            "produce": credits.get("produce", artist),
        }
    }
    path = os.path.join(output_dir, 'song.json')
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    print(f"   song.json")


def copy_template(output_dir):
    """Copy the template as index.html."""
    template = get_template_path()
    dest = os.path.join(output_dir, 'index.html')
    shutil.copy2(template, dest)
    print(f"   index.html (template)")
    return dest


def build_player(mp3_path=None, cover_path=None, title='', subtitle='',
                 artist='', lyrics_path=None, lyrics_text_path=None,
                 output_path=None, credits=None):
    output_dir = os.path.dirname(os.path.abspath(output_path))
    os.makedirs(output_dir, exist_ok=True)

    if not credits:
        credits = {}

    print(f"🎵 Building: {title}")
    print(f"   Dir: {output_dir}")

    copy_mp3_cover(mp3_path, cover_path, output_dir)
    copy_lyrics(lyrics_path, output_dir)

    # If plain text lyrics provided, copy as lyrics.txt
    if lyrics_text_path and os.path.exists(lyrics_text_path):
        shutil.copy2(lyrics_text_path, os.path.join(output_dir, 'lyrics.txt'))
        print(f"   lyrics.txt")

    write_song_json(output_dir, title, subtitle, artist, credits)
    copy_template(output_dir)

    # Count files
    files = os.listdir(output_dir)
    size = sum(os.path.getsize(os.path.join(output_dir, f)) for f in files)
    print(f"✅ Done: {len(files)} files, {size / 1024:.0f} KB total")
    print(f"   URL: {output_dir}")
    return output_dir


def main():
    parser = argparse.ArgumentParser(description='Music Player Builder v3')
    parser.add_argument('--mp3', help='MP3 file path')
    parser.add_argument('--cover', help='Cover image path')
    parser.add_argument('--title', required=True, help='Song title')
    parser.add_argument('--subtitle', default='', help='Subtitle')
    parser.add_argument('--artist', default='', help='Artist name')
    parser.add_argument('--lyrics', help='Timed lyrics JSON path')
    parser.add_argument('--lyrics-text', help='Plain text lyrics path')
    parser.add_argument('--output', required=True, help='Output index.html path (directory auto-created)')
    parser.add_argument('--credits-lyrics', default='')
    parser.add_argument('--credits-compose', default='')
    parser.add_argument('--credits-sing', default='')
    parser.add_argument('--credits-produce', default='')
    args = parser.parse_args()

    credits = {
        'lyrics': args.credits_lyrics,
        'compose': args.credits_compose,
        'sing': args.credits_sing,
        'produce': args.credits_produce,
    }
    for k in credits:
        if not credits[k]:
            credits[k] = args.artist

    build_player(
        mp3_path=args.mp3,
        cover_path=args.cover,
        title=args.title,
        subtitle=args.subtitle,
        artist=args.artist,
        lyrics_path=args.lyrics,
        lyrics_text_path=args.lyrics_text,
        output_path=args.output,
        credits=credits,
    )


if __name__ == '__main__':
    main()
