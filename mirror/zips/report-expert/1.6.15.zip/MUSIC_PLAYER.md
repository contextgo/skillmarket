# 音乐播放页面模板

使用 `music_player_builder.py` 从模板快速生成歌曲播放页面。

## 文件位置

- **模板：** `templates/music-player.html`
- **构建脚本：** `music_player_builder.py`

## 使用方法

### 基本用法

```bash
cd /root/.openclaw/workspace/skills/report-expert

python3 music_player_builder.py \
  --mp3 /path/to/song.mp3 \
  --cover /path/to/cover.jpg \
  --title "歌曲名" \
  --output /path/to/output.html
```

### 完整参数

| 参数 | 必填 | 说明 |
|------|------|------|
| `--mp3` | ✅ | MP3 文件路径 |
| `--cover` | ✅ | 封面图路径（jpg/png/webp） |
| `--title` | ✅ | 歌曲名 |
| `--subtitle` | ❌ | 副标题（如"AI Generated Music"） |
| `--lyrics` | ❌ | 歌词文件（JSON 或纯文本） |
| `--output` | ✅ | 输出 HTML 文件路径 |
| `--download-filename` | ❌ | 下载文件名，默认为"歌曲名.mp3" |
| `--duration` | ❌ | 歌曲时长（秒），纯文本歌词自动分配时间时使用 |

### 歌词格式

**JSON 格式（带时间信息）：**
```json
[
  { "time": 0.0, "text": "Intro", "isSection": true },
  { "time": 0.0, "text": "第一句歌词", "isSection": false },
  { "time": 5.2, "text": "第二句歌词", "isSection": false }
]
```

**纯文本格式（无时间信息，自动分配）：**
```
[Intro]
第一句歌词
第二句歌词

[Verse 1]
第三句歌词
第四句歌词
```

### 生成并部署

```bash
# 1. 生成播放页面
python3 music_player_builder.py \
  --mp3 /path/to/song.mp3 \
  --cover /path/to/cover.jpg \
  --title "歌曲名" \
  --lyrics /path/to/lyrics.txt \
  --output /root/space/rego/static-site/claw/other/song-player.html

# 2. 注册到索引
python3 deploy.py add song-player.html \
  --title "歌曲名 - 播放" \
  --desc "歌曲描述" \
  --category other \
  --url "https://www.rego.vip/claw/other/song-player.html"

# 3. 同步部署
python3 -c "from lib.config import sync_to_deploy; sync_to_deploy()"
```

### 模板变量

| 变量 | 说明 |
|------|------|
| `{{TITLE}}` | 歌曲名（页面标题、封面 alt、下载文件名） |
| `{{SUBTITLE}}` | 副标题 |
| `{{COVER_SRC}}` | 封面图（base64 data URI 或 URL） |
| `{{AUDIO_SRC}}` | 音频源（base64 data URI 或 URL） |
| `{{DOWNLOAD_FILENAME}}` | 下载时的文件名 |
| `{{LYRICS_JSON}}` | 歌词 JSON 数组 |

## 页面特性

- 左右布局：播放器 + 封面 | 歌词同步滚动
- 播放/暂停、进度条拖动、音量控制
- 点击歌词跳转播放位置
- 下载按钮（文件名为歌名.mp3）
- 深色紫蓝渐变背景，粉紫强调色
- 响应式：手机端自动上下布局
- 封面旋转动画
