---
name: minimax-tools
description: MiniMax web search and image understanding tools. Use when you need to search the internet or analyze images. Triggers on queries like "search for X", "find information about X", "analyze this image", "describe this picture", "what's in this photo". Uses mcporter to call MiniMax MCP tools - web_search for internet search, understand_image for image analysis.
---

# MiniMax Tools

Call these tools via mcporter:

## Web Search

```bash
mcporter call MiniMax.web_search query="搜索内容" count=10
```

## Image Understanding

```bash
mcporter call MiniMax.understand_image prompt="你的问题" image_source="图片URL或本地路径"
```

**Note**: If the image path starts with `@`, remove the `@` prefix before passing to `image_source`.

**Supported formats**: JPEG, PNG, WebP

## Example Usage

- "Search for latest news about AI" → `mcporter call MiniMax.web_search query="AI 最新消息 2026"`
- "Describe what's in this image" → `mcporter call MiniMax.understand_image prompt="描述图片内容" image_source="https://example.com/image.jpg"`
- "Find stock market data" → `mcporter call MiniMax.web_search query="A股行情 今日"`
