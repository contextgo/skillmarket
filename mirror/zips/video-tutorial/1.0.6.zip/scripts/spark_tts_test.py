# -*- coding: utf-8 -*-
"""
讯飞 Spark 超拟人 TTS API 测试脚本

首次使用前，请先配置凭证：
1. 复制 config_example.py 为 config.py
2. 填入你的讯飞 AppID / APIKey / APISecret / WS URL
3. 保存后运行本脚本

使用方式：
    python spark_tts_test.py
"""

import json
import base64
import time
import hmac
import hashlib
import os
from datetime import datetime
from urllib.parse import urlencode, urlparse as parse_url
from pathlib import Path

import websocket

# ── 加载凭证（从 config.py 读取）──────────────────────────
_SCRIPT_DIR = Path(__file__).parent.resolve()

def _load_config():
    config_path = _SCRIPT_DIR / 'config.py'
    if config_path.exists():
        import importlib.util
        spec = importlib.util.spec_from_file_location('spark_config', str(config_path))
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return (
            getattr(mod, 'SPARK_APP_ID', None),
            getattr(mod, 'SPARK_API_KEY', None),
            getattr(mod, 'SPARK_API_SECRET', None),
            getattr(mod, 'SPARK_WS_URL', None),
        )
    return None, None, None, None

cfg = _load_config()

if cfg[0]:
    APP_ID     = cfg[0]
    API_KEY    = cfg[1]
    API_SECRET = cfg[2]
    BASE_URL   = cfg[3]
else:
    print("❌ 错误：未找到讯飞凭证！")
    print("   请复制 config_example.py 为 config.py，并填写你的讯飞凭证。")
    print("   凭证获取地址：https://www.xfyun.cn/services/smart-tts")
    exit(1)


def assemble_ws_auth_url(request_url: str, api_key: str, api_secret: str) -> str:
    """构造带鉴权参数的 WebSocket URL"""
    u = parse_url(request_url)
    host = u.hostname
    path = u.path

    # RFC 7231 IMF-fixdate 格式（Kong 网关要求）
    now = datetime.utcnow()
    date = now.strftime("%a, %d %b %Y %H:%M:%S GMT")

    # 签名原文（按讯飞文档格式）
    signature_origin = f"host: {host}\ndate: {date}\nGET {path} HTTP/1.1"

    # HMAC-SHA256 签名
    signature_sha = hmac.new(
        api_secret.encode("utf-8"),
        signature_origin.encode("utf-8"),
        digestmod=hashlib.sha256,
    ).digest()
    signature_sha_b64 = base64.b64encode(signature_sha).decode("utf-8")

    # 授权信息
    authorization_origin = (
        f'api_key="{api_key}", algorithm="hmac-sha256", '
        f'headers="host date request-line", signature="{signature_sha_b64}"'
    )
    authorization_b64 = base64.b64encode(authorization_origin.encode("utf-8")).decode("utf-8")

    params = {
        "host": host,
        "date": date,
        "authorization": authorization_b64,
    }
    return request_url + "?" + urlencode(params)


def build_request(text: str, vcn: str = "x5_lingxiaotang_flow",
                   speed: int = 50, volume: int = 50, pitch: int = 50) -> str:
    """构造 TTS 请求体（status=2 表示一次性合成）"""
    payload = {
        "header": {"app_id": APP_ID, "status": 2},
        "parameter": {
            "tts": {
                "vcn": vcn,
                "speed": speed,
                "volume": volume,
                "pitch": pitch,
                "bgs": 0,
                "reg": 0,
                "rdn": 0,
                "rhy": 0,
                "audio": {
                    "encoding": "lame",    # → mp3
                    "sample_rate": 24000,
                    "channels": 1,
                    "bit_depth": 16,
                    "frame_size": 0,
                },
            }
        },
        "payload": {
            "text": {
                "encoding": "utf8",
                "compress": "raw",
                "format": "plain",
                "status": 2,
                "seq": 0,
                "text": base64.b64encode(text.encode("utf-8")).decode("utf-8"),
            }
        },
    }
    return json.dumps(payload)


def synthesize(text: str, vcn: str = "x5_lingxiaotang_flow",
              speed: int = 50, volume: int = 50, pitch: int = 50) -> bytes:
    """发起 TTS 请求，返回 mp3 音频数据"""
    auth_url = assemble_ws_auth_url(BASE_URL, API_KEY, API_SECRET)
    audio_chunks = []
    done = False

    def on_open(ws):
        print("[WS] 连接建立，发送请求...")
        req = build_request(text, vcn, speed, volume, pitch)
        ws.send(req)

    def on_message(ws, message):
        nonlocal done
        resp = json.loads(message)
        code = resp["header"].get("code", -1)
        sid  = resp["header"].get("sid", "")
        msg  = resp["header"].get("message", "")

        if code != 0:
            print(f"[ERROR] code={code}  message={msg}  sid={sid}")
            ws.close()
            return

        # 提取音频帧
        audio_payload = resp.get("payload", {}).get("audio", {})
        if "audio" in audio_payload and audio_payload["audio"]:
            chunk = base64.b64decode(audio_payload["audio"])
            audio_chunks.append(chunk)
            status = audio_payload.get("status", -1)
            seq    = audio_payload.get("seq", 0)
            print(f"[收到音频] status={status}  seq={seq}  chunk大小={len(chunk)} bytes")

        if audio_payload.get("status") == 2:
            print("[完成] 音频接收完毕")
            done = True
            ws.close()

    def on_error(ws, error):
        print(f"[WS ERROR] {error}")

    def on_close(ws, code, reason):
        print(f"[WS] 连接关闭 code={code} reason={reason}")

    ws = websocket.WebSocketApp(
        auth_url,
        on_open=on_open,
        on_message=on_message,
        on_error=on_error,
        on_close=on_close,
    )
    ws.run_forever(ping_timeout=30)

    return b"".join(audio_chunks)


# ── 主测试 ─────────────────────────────────────────────
if __name__ == "__main__":
    test_text = "白日依山尽，黄河入海流。欲穷千里目，更上一层楼。"

    print("=" * 60)
    print("讯飞 Spark TTS 超拟人语音合成测试")
    print("=" * 60)
    print(f"测试文本：{test_text}")
    print(f"发音人：x5_lingxiaotang_flow（聆小糖）")
    print()

    t0 = time.time()
    audio_data = synthesize(test_text, vcn="x5_lingxiaotang_flow")
    elapsed = time.time() - t0

    if not audio_data:
        print("\n❌ 未获取到音频数据！")
    else:
        out_path = _SCRIPT_DIR / 'test_output.mp3'
        with open(out_path, "wb") as f:
            f.write(audio_data)
        print(f"\n✅ 音频已保存：{out_path}")
        print(f"   文件大小：{len(audio_data):,} bytes")
        print(f"   耗时：{elapsed:.2f}s")

        # 用 pygame 播放验证
        try:
            import pygame
            pygame.mixer.init()
            pygame.mixer.music.load(str(out_path))
            pygame.mixer.music.play()
            print("   ▶ 正在播放（pygame）...")
            while pygame.mixer.music.get_busy():
                pygame.time.Clock().tick(10)
            print("   ■ 播放结束")
        except Exception as e:
            print(f"   ⚠ pygame 播放失败：{e}")
            print("   请双击文件自行验证音频效果")
