#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
视频教学配音合成脚本
自动将文案转语音并与视频合成

使用方法：
    python synthesize.py [--video VIDEO] [--script SCRIPT] [--output OUTPUT] [--voice VOICE] [--subtitle yes|no] [--stretch freeze|slow|none]
"""

import os
import sys
import argparse
import subprocess
import time
import glob
from pathlib import Path

# ---- ffmpeg 路径配置 ----
# 请确保 ffmpeg 已安装并添加到系统 PATH 环境变量
# 下载地址：https://ffmpeg.org/download.html

FFMPEG_PATH = 'ffmpeg'
FFPROBE_PATH = 'ffprobe'

def _resolve_ffmpeg():
    """验证 ffmpeg 是否可用"""
    global FFMPEG_PATH, FFPROBE_PATH
    try:
        subprocess.run([FFMPEG_PATH, '-version'],
                       capture_output=True, check=True, timeout=5)
        print(f"✅ ffmpeg 已就绪: {FFMPEG_PATH}")
    except Exception as e:
        print(f"❌ ffmpeg 未找到或不可用: {e}")
        print("请从 https://ffmpeg.org/download.html 下载并安装 ffmpeg，并确保已添加到 PATH 环境变量。")
        sys.exit(1)

# ========================================================================
# 讯飞 Spark TTS 凭证配置
# ========================================================================
# ⚠️ 重要：请先填写以下凭证，再使用讯飞 Spark TTS 功能。
# 凭证获取：https://www.xfyun.cn/services/smart-tts
#
# 方式一（推荐）：创建 config.py 文件，内容如下：
#   SPARK_APP_ID     = '你的AppID'
#   SPARK_API_KEY    = '你的APIKey'
#   SPARK_API_SECRET = '你的APISecret'
#   SPARK_WS_URL     = '你的WebSocket地址'
#
# 方式二：直接修改下方占位符（不推荐，升级时会被覆盖）
# ========================================================================

def _load_spark_config():
    """从 config.py 加载讯飞凭证，如未配置则使用占位符"""
    config_path = _SCRIPT_DIR / 'config.py'
    if config_path.exists():
        import importlib.util
        spec = importlib.util.spec_from_file_location('spark_config', str(config_path))
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return (
            getattr(mod, 'SPARK_APP_ID', None),
            getattr(mod, 'SPARK_API_KEY', None),
            getattr(mod, 'SPARK_API_SECRET', None),
            getattr(mod, 'SPARK_WS_URL', None),
        )
    return None, None, None, None

_spark_cfg = _load_spark_config()

# 优先使用 config.py 中的配置，否则使用占位符（会提示用户配置）
if _spark_cfg[0]:
    SPARK_APP_ID     = _spark_cfg[0]
    SPARK_API_KEY    = _spark_cfg[1]
    SPARK_API_SECRET = _spark_cfg[2]
    SPARK_WS_URL     = _spark_cfg[3]
else:
    # 占位符（未配置时使用）
    SPARK_APP_ID     = 'YOUR_APP_ID'
    SPARK_API_KEY    = 'YOUR_API_KEY'
    SPARK_API_SECRET = 'YOUR_API_SECRET'
    SPARK_WS_URL     = 'wss://YOUR_WS_URL'

# ---- 讯飞 Spark TTS 音色映射表 ----
SPARK_VOICE_MAP = {
    'x5_lingxiaotang_flow': '聆小糖（女声）',
    'x5_lingfeiyi_flow':    '聆非易（超拟人）',
}


def generate_audio_spark(text, output_path, vcn='x5_lingxiaotang_flow',
                          speed=50, volume=50, pitch=50):
    """
    使用讯飞 Spark 超拟人 TTS 生成音频（返回 mp3 数据）。

    Parameters
    ----------
    text       : 要合成的文本
    output_path: 保存路径（.mp3）
    vcn        : 发音人 ID（默认聆小糖）
    speed      : 语速 0-100
    volume     : 音量 0-100
    pitch      : 语调 0-100
    """
    import json
    import base64
    import hmac
    import hashlib
    from datetime import datetime
    from urllib.parse import urlencode, urlparse

    # ---- 凭证校验 ----
    if SPARK_APP_ID == 'YOUR_APP_ID':
        raise RuntimeError(
            '讯飞 Spark TTS 凭证未配置！\n'
            '请在 scripts/config.py 中填写你的讯飞凭证。\n'
            '注册地址：https://www.xfyun.cn/services/smart-tts\n'
            '参考 scripts/config_example.py 填写。'
        )

    try:
        import websocket
    except ImportError:
        raise RuntimeError(
            '讯飞 Spark TTS 需要 websocket-client 库，请执行：\n'
            '  pip install websocket-client==1.8.0\n'
            '或联系技能开发者安装。'
        )

    # ── 鉴权 URL ────────────────────────────────────────────────────────────
    u = urlparse(SPARK_WS_URL)
    host = u.hostname
    path = u.path

    # RFC 7231 日期格式（Kong 网关要求）
    date = datetime.utcnow().strftime('%a, %d %b %Y %H:%M:%S GMT')

    sig_origin = f'host: {host}\ndate: {date}\nGET {path} HTTP/1.1'
    sig_sha = hmac.new(
        SPARK_API_SECRET.encode('utf-8'),
        sig_origin.encode('utf-8'),
        digestmod=hashlib.sha256,
    ).digest()
    sig_b64 = base64.b64encode(sig_sha).decode('utf-8')

    auth_origin = (
        f'api_key="{SPARK_API_KEY}", algorithm="hmac-sha256", '
        f'headers="host date request-line", signature="{sig_b64}"'
    )
    auth_b64 = base64.b64encode(auth_origin.encode('utf-8')).decode('utf-8')

    auth_url = SPARK_WS_URL + '?' + urlencode({
        'host': host,
        'date': date,
        'authorization': auth_b64,
    })

    # ── 请求体 ──────────────────────────────────────────────────────────────
    payload = {
        'header': {'app_id': SPARK_APP_ID, 'status': 2},
        'parameter': {
            'tts': {
                'vcn': vcn,
                'speed': speed,
                'volume': volume,
                'pitch': pitch,
                'bgs': 0, 'reg': 0, 'rdn': 0, 'rhy': 0,
                'audio': {
                    'encoding': 'lame',
                    'sample_rate': 24000,
                    'channels': 1,
                    'bit_depth': 16,
                    'frame_size': 0,
                },
            }
        },
        'payload': {
            'text': {
                'encoding': 'utf8',
                'compress': 'raw',
                'format': 'plain',
                'status': 2,
                'seq': 0,
                'text': base64.b64encode(text.encode('utf-8')).decode('utf-8'),
            }
        },
    }

    audio_chunks = []

    def on_open(ws):
        ws.send(json.dumps(payload))

    def on_message(ws, message):
        resp = json.loads(message)
        code = resp['header'].get('code', -1)
        if code != 0:
            raise RuntimeError(
                f'讯飞 Spark TTS 错误 code={code}：{resp["header"].get("message","")} '
                f'sid={resp["header"].get("sid","")}'
            )
        audio_payload = resp.get('payload', {}).get('audio', {})
        if 'audio' in audio_payload and audio_payload['audio']:
            audio_chunks.append(base64.b64decode(audio_payload['audio']))
        if audio_payload.get('status') == 2:
            ws.close()

    ws = websocket.WebSocketApp(
        auth_url,
        on_open=on_open,
        on_message=on_message,
        on_error=lambda ws, e: (_ for _ in ()).throw(RuntimeError(f'WebSocket错误: {e}')),
        on_close=lambda ws, *_: None,
    )
    ws.run_forever(ping_timeout=30)

    if not audio_chunks:
        raise RuntimeError('讯飞 Spark TTS 未返回音频数据')

    Path(output_path).write_bytes(b''.join(audio_chunks))


# ── TTS 引擎可用性检测（惰性）──────────────────────────────────────────────
TTS_ENGINE = None  # 'edge-tts', 'pyttsx3', 'spark'
EDGE_TTS_AVAILABLE = False
PYTTSX3_AVAILABLE = False
SPARK_AVAILABLE = None  # None=未检测，True=凭证有效，False=凭证无效

# ---- 固定依赖版本，防止供应链投毒 ----
PINNED_VERSIONS = {
    'edge-tts': '7.2.8',   # 2026-03-22 发布
    'pyttsx3':  '2.99',    # 2025-07-08 发布
}

def _pip_install_pinned(package, pinned_version):
    """安装固定版本的包，并校验安装后版本是否匹配"""
    spec = f'{package}=={pinned_version}'
    print(f"   安装固定版本: {spec}")
    result = subprocess.run(
        [sys.executable, '-m', 'pip', 'install', spec, '-q'],
        capture_output=True, text=True
    )
    if result.returncode != 0:
        raise RuntimeError(f"pip install {spec} 失败: {result.stderr}")
    
    # 安装后校验版本
    try:
        import importlib
        mod = importlib.import_module(package.replace('-', '_'))
        installed_ver = getattr(mod, '__version__', None)
        if installed_ver and installed_ver != pinned_version:
            raise RuntimeError(
                f"版本校验失败: 期望 {pinned_version}，实际 {installed_ver}。"
                f"可能存在供应链攻击，已终止。"
            )
    except ImportError:
        pass  # 包名和模块名不一致时跳过校验
    
    return True

def check_dependencies(forced_engine=None):
    """
    检查并安装依赖。

    Parameters
    ----------
    forced_engine : str, optional
        强制使用的 TTS 引擎。
        'edge'    → 仅 edge-tts
        'spark'   → 仅讯飞 Spark TTS
        'pyttsx3' → 仅 pyttsx3（离线）
        None      → 自动探测可用引擎（默认）
    """
    global EDGE_TTS_AVAILABLE, PYTTSX3_AVAILABLE, TTS_ENGINE, SPARK_AVAILABLE

    print("🔍 检查依赖...")

    # 解析 ffmpeg 路径
    _resolve_ffmpeg()

    # ── 强制引擎模式 ──────────────────────────────────────────────────────────
    if forced_engine == 'spark':
        _check_spark()
        TTS_ENGINE = 'spark'
        return

    if forced_engine == 'edge' or forced_engine == 'edge-tts':
        _check_edge_tts()
        return

    if forced_engine == 'pyttsx3':
        _check_pyttsx3()
        return

    # ── 自动探测（优先级：edge-tts > pyttsx3）───────────────────────────────
    try:
        _check_edge_tts()
        return
    except Exception:
        pass

    try:
        _check_pyttsx3()
        return
    except Exception:
        pass

    print("❌ 无法安装任何语音合成引擎")
    TTS_ENGINE = None


def _check_edge_tts():
    """检测/安装 edge-tts"""
    global EDGE_TTS_AVAILABLE, TTS_ENGINE
    try:
        import edge_tts
        installed_ver = getattr(edge_tts, '__version__', None)
        if installed_ver and installed_ver != PINNED_VERSIONS['edge-tts']:
            print(f"⚠️ edge-tts 版本 {installed_ver} != 固定 {PINNED_VERSIONS['edge-tts']}，正在修正...")
            _pip_install_pinned('edge-tts', PINNED_VERSIONS['edge-tts'])
            import importlib
            importlib.reload(edge_tts)
        EDGE_TTS_AVAILABLE = True
        TTS_ENGINE = 'edge-tts'
        print("✅ edge-tts 已安装")
        return
    except ImportError:
        pass

    print("⏳ 正在安装 edge-tts...")
    try:
        _pip_install_pinned('edge-tts', PINNED_VERSIONS['edge-tts'])
        import edge_tts
        EDGE_TTS_AVAILABLE = True
        TTS_ENGINE = 'edge-tts'
        print("✅ edge-tts 安装成功")
        return
    except Exception as e:
        print(f"   edge-tts 安装失败: {e}")
    raise RuntimeError("edge-tts 不可用")


def _check_pyttsx3():
    """检测/安装 pyttsx3"""
    global PYTTSX3_AVAILABLE, TTS_ENGINE
    try:
        import pyttsx3
        PYTTSX3_AVAILABLE = True
        TTS_ENGINE = 'pyttsx3'
        print("✅ pyttsx3 已安装（离线模式）")
        return
    except ImportError:
        pass

    print("⏳ 正在安装 pyttsx3...")
    try:
        _pip_install_pinned('pyttsx3', PINNED_VERSIONS['pyttsx3'])
        import pyttsx3
        PYTTSX3_AVAILABLE = True
        TTS_ENGINE = 'pyttsx3'
        print("✅ pyttsx3 安装成功（离线模式）")
        return
    except Exception as e:
        print(f"   pyttsx3 安装失败: {e}")
    raise RuntimeError("pyttsx3 不可用")


def _check_spark():
    """检测讯飞 Spark TTS 凭证和网络连通性"""
    global SPARK_AVAILABLE

    # 凭证校验
    if SPARK_APP_ID == 'YOUR_APP_ID':
        raise RuntimeError(
            '讯飞 Spark TTS 凭证未配置！\n'
            '请在 scripts/config.py 中填写你的讯飞凭证。\n'
            '注册地址：https://www.xfyun.cn/services/smart-tts\n'
            '参考 scripts/config_example.py 填写。'
        )

    try:
        import websocket
    except ImportError:
        try:
            _pip_install_pinned('websocket-client', '1.8.0')
            import websocket
        except Exception as e:
            raise RuntimeError(
                f'讯飞 Spark TTS 需要 websocket-client 库，安装失败: {e}'
            )
    # 快速连通性测试（发一个空请求）
    try:
        import json, base64, hmac, hashlib
        from datetime import datetime
        from urllib.parse import urlencode, urlparse

        u = urlparse(SPARK_WS_URL)
        date = datetime.utcnow().strftime('%a, %d %b %Y %H:%M:%S GMT')
        sig_origin = f'host: {u.hostname}\ndate: {date}\nGET {u.path} HTTP/1.1'
        sig_sha = hmac.new(
            SPARK_API_SECRET.encode(), sig_origin.encode(),
            digestmod=hashlib.sha256,
        ).digest()
        sig_b64 = base64.b64encode(sig_sha).decode()
        auth_origin = (
            f'api_key="{SPARK_API_KEY}", algorithm="hmac-sha256", '
            f'headers="host date request-line", signature="{sig_b64}"'
        )
        auth_b64 = base64.b64encode(auth_origin.encode()).decode()
        auth_url = SPARK_WS_URL + '?' + urlencode({
            'host': u.hostname, 'date': date, 'authorization': auth_b64,
        })

        test_payload = {
            'header': {'app_id': SPARK_APP_ID, 'status': 2},
            'parameter': {'tts': {
                'vcn': 'x5_lingxiaotang_flow', 'speed': 50, 'volume': 50, 'pitch': 50,
                'audio': {'encoding': 'lame', 'sample_rate': 24000, 'channels': 1,
                          'bit_depth': 16, 'frame_size': 0},
            }},
            'payload': {'text': {
                'encoding': 'utf8', 'compress': 'raw', 'format': 'plain',
                'status': 2, 'seq': 0,
                'text': base64.b64encode('测试'.encode()).decode(),
            }},
        }

        done = []

        def on_open(ws):
            ws.send(json.dumps(test_payload))

        def on_message(ws, message):
            resp = json.loads(message)
            code = resp['header'].get('code', -1)
            if code == 11200:
                done.append('auth_error')
                ws.close()
            elif code != 0:
                done.append('other_error')
                ws.close()
            else:
                audio_payload = resp.get('payload', {}).get('audio', {})
                if audio_payload.get('status') == 2:
                    done.append('ok')
                    ws.close()

        ws = websocket.WebSocketApp(
            auth_url,
            on_open=on_open, on_message=on_message,
            on_error=lambda *_: None, on_close=lambda *_: None,
        )
        ws.run_forever(ping_timeout=10, ping_interval=5)

        if 'ok' in done:
            SPARK_AVAILABLE = True
            print("✅ 讯飞 Spark TTS 凭证有效")
            return
        elif 'auth_error' in done:
            SPARK_AVAILABLE = False
            raise RuntimeError(
                '讯飞 Spark TTS 凭证无效或服务未开通（code=11200）。\n'
                '请检查：1. AppID/APIKey/APISecret 是否正确；'
                '2. 是否在讯飞控制台开通了"超拟人语音合成"服务。\n'
                '注册地址：https://www.xfyun.cn/services/smart-tts'
            )
        else:
            SPARK_AVAILABLE = False
            raise RuntimeError('讯飞 Spark TTS 连接超时，请检查网络。')
    except RuntimeError:
        raise
    except Exception as e:
        SPARK_AVAILABLE = False
        raise RuntimeError(f'讯飞 Spark TTS 检测失败: {e}')


def install_ffmpeg():
    """检查 ffmpeg 是否可用"""
    _resolve_ffmpeg()
    print(f"✅ ffmpeg 路径: {FFMPEG_PATH}")

def generate_audio_edge_tts(text, output_path, voice='zh-CN-XiaoxiaoNeural'):
    """使用 edge-tts 生成音频"""
    import edge_tts
    import asyncio
    
    async def _generate():
        communicate = edge_tts.Communicate(text, voice)
        await communicate.save(output_path)
    
    asyncio.run(_generate())

def generate_audio_pyttsx3(text, output_path):
    """使用 pyttsx3 生成音频"""
    import pyttsx3
    engine = pyttsx3.init()
    engine.save_to_file(text, output_path)
    engine.runAndWait()

def parse_time(time_str):
    """解析时间字符串为秒数"""
    time_str = time_str.strip()
    parts = time_str.split(':')
    
    if len(parts) == 2:  # MM:SS
        return int(parts[0]) * 60 + int(parts[1])
    elif len(parts) == 3:  # HH:MM:SS
        return int(parts[0]) * 3600 + int(parts[1]) * 60 + int(parts[2])
    else:
        raise ValueError(f"无法解析时间格式: {time_str}")

def parse_markdown_table(md_text):
    """解析 Markdown 表格，返回列名列表和数据行列表"""
    lines = [line.strip() for line in md_text.split('\n')]
    
    # 找第一个表格行（以 | 开头）
    table_start = -1
    for i, line in enumerate(lines):
        if line.startswith('|') and line.count('|') >= 3:
            table_start = i
            break
    
    if table_start == -1:
        return None, None
    
    # 第一行：表头
    header_line = lines[table_start]
    headers = [h.strip() for h in header_line.split('|') if h.strip()]
    
    # 第二行：分隔行（|---|），跳过
    # 后续行：数据
    data_lines = []
    for line in lines[table_start+2:]:
        line = line.strip()
        if line.startswith('|'):
            # 提取每个单元格
            cells = [c.strip() for c in line.split('|') if c.strip()]
            if cells:
                data_lines.append(cells)
    
    return headers, data_lines


def get_media_duration(path):
    """获取音视频文件时长（秒），使用 ffprobe"""
    result = subprocess.run(
        [FFPROBE_PATH, '-v', 'error', '-show_entries', 'format=duration',
         '-of', 'default=noprint_wrappers=1:nokey=1', str(path)],
        capture_output=True, text=True
    )
    try:
        return float(result.stdout.strip())
    except (ValueError, IndexError):
        return 0.0


def read_script(script_path):
    """读取 Markdown 文案表格"""
    print(f"📖 读取文案: {script_path}")
    
    if not str(script_path).endswith('.md'):
        raise ValueError(
            f"仅支持 .md 格式（Markdown 表格），不支持 .xlsx / .csv。"
            f"请使用 Markdown 格式的文案文件。"
        )
    
    with open(script_path, 'r', encoding='utf-8') as f:
        md_content = f.read()
    
    headers, data_lines = parse_markdown_table(md_content)
    if headers is None:
        raise ValueError(f"未找到 Markdown 表格: {script_path}")
    
    # 匹配列名
    start_col = end_col = content_col = None
    for i, h in enumerate(headers):
        if '开始' in h or 'start' in h.lower():
            start_col = i
        elif '结束' in h or 'end' in h.lower():
            end_col = i
        elif '文案' in h or '内容' in h or 'text' in h.lower() or 'content' in h.lower():
            content_col = i
    
    if any(c is None for c in [start_col, end_col, content_col]):
        raise ValueError(
            f"Markdown 表格列名不正确。需要: 开始时间、结束时间、文案内容。"
            f"找到列: {headers}"
        )
    
    segments = []
    for row in data_lines:
        if len(row) > max(start_col, end_col, content_col):
            segments.append({
                'start': parse_time(row[start_col]),
                'end': parse_time(row[end_col]),
                'text': row[content_col].strip()
            })
    
    print(f"✅ 读取到 {len(segments)} 个文案段落")
    return segments

def generate_audio_files(segments, output_dir, voice='zh-CN-XiaoxiaoNeural',
                         engine=None, spark_voice='x5_lingxiaotang_flow'):
    """
    生成所有语音文件。

    Parameters
    ----------
    segments    : 段落列表（每段含 start/end/text）
    output_dir  : 输出目录
    voice       : edge-tts 音色（默认 zh-CN-XiaoxiaoNeural）
    engine      : TTS 引擎。None=自动，'edge'=edge-tts，'spark'=讯飞，'pyttsx3'=离线
    spark_voice : 讯飞 Spark TTS 发音人 ID（默认聆小糖）
    """
    global TTS_ENGINE
    if engine:
        TTS_ENGINE = engine

    engine_display = {
        'edge-tts': f'edge-tts（{voice}）',
        'spark':    f'讯飞 Spark（{SPARK_VOICE_MAP.get(spark_voice, spark_voice)}）',
        'pyttsx3':  'pyttsx3（离线）',
    }.get(TTS_ENGINE, TTS_ENGINE)

    print(f"🎙️ 开始生成语音... [引擎: {engine_display}]")

    audio_dir = Path(output_dir) / 'audio'
    audio_dir.mkdir(parents=True, exist_ok=True)

    audio_files = []

    for i, seg in enumerate(segments):
        audio_path = audio_dir / f"audio_{i:03d}.mp3"
        print(f"   [{i+1}/{len(segments)}] {seg['text'][:30]}...")

        try:
            if TTS_ENGINE == 'edge-tts':
                generate_audio_edge_tts(seg['text'], str(audio_path), voice)
            elif TTS_ENGINE == 'pyttsx3':
                generate_audio_pyttsx3(seg['text'], str(audio_path))
            elif TTS_ENGINE == 'spark':
                generate_audio_spark(seg['text'], str(audio_path), vcn=spark_voice)
            else:
                # 尝试 edge-tts
                try:
                    generate_audio_edge_tts(seg['text'], str(audio_path), voice)
                except Exception:
                    generate_audio_pyttsx3(seg['text'], str(audio_path))
        except Exception as e:
            print(f"   ⚠️ 生成失败: {e}，使用静音替代")
            silent_path = audio_dir / f"silent_{i:03d}.mp3"
            create_silent_audio(silent_path, max(seg['end'] - seg['start'], 1))
            audio_path = silent_path

        audio_files.append({
            'path': str(audio_path),
            'start': seg['start'],
            'end': seg['end'],
            'text': seg['text']
        })

    print(f"✅ 生成了 {len(audio_files)} 个音频文件")
    return audio_files

def create_silent_audio(output_path, duration_sec):
    """创建静音音频"""
    subprocess.run([
        FFMPEG_PATH, '-y',
        '-f', 'lavfi',
        '-i', f'anullsrc=r=44100:cl=stereo',
        '-t', str(duration_sec),
        '-q:a', '9',
        str(output_path)
    ], capture_output=True)

def concat_audio_files(audio_files, output_path):
    """拼接多个音频文件"""
    concat_list = Path(output_path).parent / 'concat_list.txt'
    
    with open(concat_list, 'w') as f:
        for af in audio_files:
            f.write(f"file '{af['path']}'\n")
    
    subprocess.run([
        FFMPEG_PATH, '-y',
        '-f', 'concat', '-safe', '0',
        '-i', str(concat_list),
        '-c', 'copy',
        str(output_path)
    ], capture_output=True)
    
    concat_list.unlink()

def adjust_audio_timing(audio_files, output_path):
    """调整音频到正确的时间位置，填充静音"""
    print("⏱️ 调整音频时间轴...")
    
    # 创建完整时间轴的音频
    if not audio_files:
        print("⚠️ 没有音频文件，创建静音")
        create_silent_audio(output_path, 60)
        return
    
    max_time = max(af['end'] for af in audio_files)
    
    # 创建空白音频
    silent_path = Path(output_path).parent / 'silent_full.mp3'
    create_silent_audio(silent_path, max_time)
    
    # 混合音频
    filter_complex = []
    for i, af in enumerate(audio_files):
        # 延迟到正确位置
        delay_ms = af['start'] * 1000
        filter_complex.append(f"[{i}:a]adelay={delay_ms}|{delay_ms}[d{i}]")
    
    inputs = []
    for i, af in enumerate(audio_files):
        inputs.extend(['-i', af['path']])
    
    print(f"   混合 {len(audio_files)} 个音频片段...")
    
    subprocess.run([
        FFMPEG_PATH, '-y',
        *inputs,
        '-filter_complex', ';'.join(filter_complex) + ';' +
        ';'.join([f'[d{i}]' for i in range(len(audio_files))]) +
        f'amix=inputs={len(audio_files)}:duration=longest[aout]',
        '-map', '[aout]',
        str(output_path)
    ] + (['-q:a', '9'] if not str(output_path).endswith('.wav') else []),
        capture_output=True
    )
    
    silent_path.unlink()

def _check_video_audio(video_path):
    """检测视频是否有音频轨道，返回音频信息或None"""
    try:
        result = subprocess.run([
            FFPROBE_PATH, '-v', 'error',
            '-select_streams', 'a:0',
            '-show_entries', 'stream=codec_name,sample_rate,channels',
            '-of', 'default=noprint_wrappers=1',
            str(video_path)
        ], capture_output=True, text=True, timeout=10)
        output = result.stdout.strip()
        if output:
            # 解析音频信息
            info = {}
            for line in output.split('\n'):
                if '=' in line:
                    key, val = line.split('=', 1)
                    info[key] = val
            return info
        return None
    except Exception:
        return None

def synthesize_video(video_path, audio_path, output_path):
    """合成视频和音频"""
    print("🎬 合成最终视频...")

    # 检测原视频是否有音频
    video_audio = _check_video_audio(video_path)
    if video_audio:
        print(f"ℹ️  原视频有音频轨道: {video_audio.get('codec_name', '?')} "
              f"{video_audio.get('sample_rate', '?')}Hz {video_audio.get('channels', '?')}声道")
        print(f"   → 新配音将替换原音频，如需混合请手动使用 amix 滤镜")
    else:
        print("ℹ️  原视频无音频轨道，直接添加配音")

    # 确保输出目录存在
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)

    # 使用 ffmpeg 合并
    result = subprocess.run([
        FFMPEG_PATH, '-y',
        '-i', video_path,
        '-i', audio_path,
        '-c:v', 'copy',      # 复制视频流，不重新编码
        '-c:a', 'aac',       # 音频转 AAC
        '-b:a', '192k',
        '-shortest',         # 以较短的为准
        str(output_path)
    ], capture_output=True, text=True)

    if result.returncode != 0:
        print(f"⚠️ 标准合并失败，尝试备选方案...")
        # 备选：直接替换音频
        subprocess.run([
            FFMPEG_PATH, '-y',
            '-i', video_path,
            '-i', audio_path,
            '-map', '0:v',
            '-map', '1:a',
            '-c:v', 'copy',
            str(output_path)
        ], capture_output=True)
    
    print(f"✅ 视频已生成: {output_path}")

# ============================================================
# 以配音为准的视频扩展功能
# ============================================================

def build_audio_driven_video(video_path, segments, audio_files, output_dir, stretch_mode='freeze'):
    """以配音时长为准构建视频

    当某段配音时长超过对应视频时段时，自动扩展视频使其匹配。

    Args:
        video_path: 源视频路径
        segments: 文案段落列表 [{start, end, text}, ...]
        audio_files: 音频文件列表 [{path, start, end, text}, ...]
        output_dir: 输出目录
        stretch_mode: 扩展模式
            - 'freeze': 冻结溢出段最后一帧（推荐，适合教程）
            - 'slow': 慢放视频以匹配配音时长
            - 'none': 不扩展，截断配音以匹配视频

    Returns:
        (video_path, audio_files): 返回视频路径和调整后的音频时间信息
    """
    if stretch_mode == 'none':
        return video_path, audio_files

    work_dir = Path(output_dir) / 'extend_work'
    work_dir.mkdir(parents=True, exist_ok=True)

    # 测量每段音频实际时长
    overflow_info = []
    for seg, af in zip(segments, audio_files):
        audio_dur = get_media_duration(af['path'])
        seg_dur = seg['end'] - seg['start']
        overflow = max(0, audio_dur - seg_dur)
        overflow_info.append({
            'audio_duration': audio_dur,
            'segment_duration': seg_dur,
            'overflow': overflow,
        })

    total_overflow = sum(o['overflow'] for o in overflow_info)
    if total_overflow <= 0:
        print("✅ 所有配音时长均在视频时段内，无需扩展视频")
        return video_path, audio_files

    overflow_count = sum(1 for o in overflow_info if o['overflow'] > 0)
    print(f"⏱️ {overflow_count} 段配音溢出，共 {total_overflow:.1f} 秒")
    print(f"   扩展模式: {stretch_mode}")

    video_dur = get_media_duration(video_path)

    # 构建区域列表（间隙 + 段落）
    regions = _build_timeline_regions(segments, overflow_info, video_dur)

    # 逐段处理，生成视频片段和调整后的音频时间线
    clip_paths = []
    adjusted_audio = []
    current_time = 0.0

    for region in regions:
        if region['type'] == 'gap':
            clip_path = _extract_video_clip(
                video_path, region['source_start'], region['source_end'],
                work_dir, f"gap_{len(clip_paths)}")
            if clip_path:
                clip_paths.append(clip_path)
                current_time += region['source_end'] - region['source_start']

        elif region['type'] == 'segment':
            idx = region['index']
            seg = segments[idx]
            af = audio_files[idx]
            info = overflow_info[idx]
            overflow = info['overflow']
            seg_dur = info['segment_duration']
            audio_dur = info['audio_duration']

            if overflow > 0 and stretch_mode == 'freeze':
                clip_path = _extract_video_clip_with_freeze(
                    video_path, seg['start'], seg['end'], overflow,
                    work_dir, f"seg_{idx}")
            elif overflow > 0 and stretch_mode == 'slow':
                clip_path = _extract_video_clip_slowdown(
                    video_path, seg['start'], seg['end'], audio_dur,
                    work_dir, f"seg_{idx}")
            else:
                clip_path = _extract_video_clip(
                    video_path, seg['start'], seg['end'],
                    work_dir, f"seg_{idx}")

            if clip_path:
                clip_paths.append(clip_path)
                adjusted_audio.append({
                    'path': af['path'],
                    'start': current_time,
                    'end': current_time + max(seg_dur, audio_dur),
                    'text': seg['text'],
                })
                current_time += max(seg_dur, audio_dur)

    # 合并所有视频片段
    extended_video = _concat_video_clips(clip_paths, work_dir)
    if not extended_video:
        print("⚠️ 视频扩展失败，使用原始视频")
        return video_path, audio_files

    print(f"✅ 视频已扩展，总时长 {current_time:.1f} 秒（原始 {video_dur:.1f} 秒）")

    return extended_video, adjusted_audio


def _build_timeline_regions(segments, overflow_info, video_dur):
    """构建时间线区域列表（间隙 + 段落）"""
    regions = []

    # 第一段之前的间隙
    if segments[0]['start'] > 0:
        regions.append({
            'type': 'gap', 'source_start': 0,
            'source_end': segments[0]['start']
        })

    for i, (seg, info) in enumerate(zip(segments, overflow_info)):
        regions.append({
            'type': 'segment', 'index': i,
            'source_start': seg['start'], 'source_end': seg['end'],
            'audio_duration': info['audio_duration'],
            'overflow': info['overflow'],
        })

        # 段落之间的间隙
        if i < len(segments) - 1:
            next_start = segments[i + 1]['start']
            if seg['end'] < next_start:
                regions.append({
                    'type': 'gap',
                    'source_start': seg['end'],
                    'source_end': next_start,
                })

    # 最后一段之后的间隙
    if segments[-1]['end'] < video_dur:
        regions.append({
            'type': 'gap',
            'source_start': segments[-1]['end'],
            'source_end': video_dur,
        })

    return regions


def _extract_video_clip(video_path, start, end, work_dir, name):
    """从源视频截取一段（重新编码以确保拼接兼容）"""
    clip_path = work_dir / f'{name}.mp4'
    result = subprocess.run([
        FFMPEG_PATH, '-y', '-i', str(video_path),
        '-ss', str(start), '-to', str(end),
        '-c:v', 'libx264', '-preset', 'fast',
        '-pix_fmt', 'yuv420p',
        '-an',   # 去掉原始音频，后面用 TTS 音频
        str(clip_path)
    ], capture_output=True, text=True)

    if result.returncode != 0:
        print(f"   ⚠️ 截取视频片段失败: {name}")
        return None
    return str(clip_path)


def _extract_video_clip_with_freeze(video_path, start, end, freeze_seconds, work_dir, name):
    """截取视频段并在末尾冻结最后一帧

    优先使用 ffmpeg tpad 滤镜；不可用时回退到逐帧方案。
    """
    clip_path = work_dir / f'{name}_freeze.mp4'

    # 方案一：tpad 滤镜（ffmpeg 4.0+）
    result = subprocess.run([
        FFMPEG_PATH, '-y', '-i', str(video_path),
        '-ss', str(start), '-to', str(end),
        '-vf', f'tpad=stop_duration={freeze_seconds:.2f}:stop_mode=clone',
        '-c:v', 'libx264', '-preset', 'fast',
        '-pix_fmt', 'yuv420p',
        '-an',
        str(clip_path)
    ], capture_output=True, text=True)

    if result.returncode == 0:
        return str(clip_path)

    # 方案二：提取最后一帧 → 生成静止视频 → 拼接
    print(f"   ⚠️ tpad 滤镜失败，尝试备选方案...")
    return _extract_video_clip_with_freeze_fallback(
        video_path, start, end, freeze_seconds, work_dir, name)


def _extract_video_clip_with_freeze_fallback(video_path, start, end, freeze_seconds, work_dir, name):
    """冻结最后一帧的备选方案（提取最后一帧 → 生成静止视频 → 拼接）"""
    # 提取该段最后一帧
    frame_path = work_dir / f'{name}_lastframe.png'
    subprocess.run([
        FFMPEG_PATH, '-y', '-i', str(video_path),
        '-ss', str(max(0, end - 0.1)), '-frames:v', '1',
        '-q:v', '2', str(frame_path)
    ], capture_output=True)

    if not frame_path.exists():
        # 无法提取帧，回退到不带冻结的版本
        return _extract_video_clip(video_path, start, end, work_dir, name)

    # 截取视频段
    seg_path = _extract_video_clip(video_path, start, end, work_dir, f'{name}_seg')
    if not seg_path:
        return None

    # 获取源视频分辨率，确保静止视频分辨率一致
    probe = subprocess.run([
        FFPROBE_PATH, '-v', 'error', '-select_streams', 'v:0',
        '-show_entries', 'stream=width,height',
        '-of', 'csv=s=x:p=0', str(video_path)
    ], capture_output=True, text=True)
    resolution = probe.stdout.strip() if probe.stdout.strip() else '1920x1080'

    # 从最后一帧生成静止视频
    freeze_path = work_dir / f'{name}_still.mp4'
    subprocess.run([
        FFMPEG_PATH, '-y',
        '-loop', '1', '-i', str(frame_path),
        '-c:v', 'libx264', '-preset', 'fast',
        '-t', str(freeze_seconds),
        '-pix_fmt', 'yuv420p', '-r', '30',
        '-vf', f'scale={resolution}',
        '-an',
        str(freeze_path)
    ], capture_output=True)

    if not freeze_path.exists():
        return seg_path  # 回退到不带冻结的版本

    # 拼接视频段 + 冻结帧视频
    concat_file = work_dir / f'{name}_concat.txt'
    with open(concat_file, 'w') as f:
        f.write(f"file '{seg_path}'\n")
        f.write(f"file '{freeze_path}'\n")

    clip_path = work_dir / f'{name}_freeze.mp4'
    result = subprocess.run([
        FFMPEG_PATH, '-y', '-f', 'concat', '-safe', '0',
        '-i', str(concat_file), '-c', 'copy', str(clip_path)
    ], capture_output=True)

    if result.returncode != 0:
        return seg_path  # 回退到不带冻结的版本
    return str(clip_path)


def _extract_video_clip_slowdown(video_path, start, end, target_duration, work_dir, name):
    """慢放视频段以匹配配音时长"""
    clip_path = work_dir / f'{name}_slow.mp4'
    seg_duration = end - start
    speed_factor = seg_duration / target_duration  # < 1.0 = 慢放

    result = subprocess.run([
        FFMPEG_PATH, '-y', '-i', str(video_path),
        '-ss', str(start), '-to', str(end),
        '-vf', f'setpts={speed_factor:.4f}*PTS',
        '-c:v', 'libx264', '-preset', 'fast',
        '-pix_fmt', 'yuv420p',
        '-an',
        str(clip_path)
    ], capture_output=True, text=True)

    if result.returncode != 0:
        print(f"   ⚠️ 慢放处理失败: {name}，使用原始速度")
        return _extract_video_clip(video_path, start, end, work_dir, name)
    return str(clip_path)


def _concat_video_clips(clip_paths, work_dir):
    """拼接多个视频片段"""
    if not clip_paths:
        return None

    # 方案一：concat demuxer + copy（快速，要求片段编码一致）
    concat_file = work_dir / 'concat_all.txt'
    with open(concat_file, 'w') as f:
        for p in clip_paths:
            f.write(f"file '{p}'\n")

    output_path = work_dir / 'extended_video.mp4'
    result = subprocess.run([
        FFMPEG_PATH, '-y', '-f', 'concat', '-safe', '0',
        '-i', str(concat_file), '-c', 'copy', str(output_path)
    ], capture_output=True, text=True)

    if result.returncode == 0:
        return str(output_path)

    # 方案二：filter_complex concat（重新编码，兼容性好）
    print("   ⚠️ 快速拼接失败，尝试重新编码拼接...")
    inputs = []
    for p in clip_paths:
        inputs.extend(['-i', p])

    n = len(clip_paths)
    filter_parts = ''.join(f'[{i}:v]' for i in range(n))
    filter_complex = f"{filter_parts}concat=n={n}:v=1:a=0[vout]"

    result = subprocess.run([
        FFMPEG_PATH, '-y', *inputs,
        '-filter_complex', filter_complex,
        '-map', '[vout]', '-c:v', 'libx264', '-preset', 'fast',
        '-pix_fmt', 'yuv420p',
        str(output_path)
    ], capture_output=True, text=True)

    if result.returncode != 0:
        return None
    return str(output_path)

def main():
    parser = argparse.ArgumentParser(
        description='视频教学配音合成工具（支持 edge-tts / 讯飞 Spark TTS / pyttsx3）',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
TTS 引擎说明：
  --engine edge      edge-tts（微软，音质好，需要网络，默认）
  --engine spark     讯飞 Spark 超拟人 TTS（更自然，需要讯飞账号）
  --engine pyttsx3   pyttsx3（离线，无网络时使用）

讯飞音色示例：
  --engine spark --spark-voice x5_lingxiaotang_flow   聆小糖（女声）
  --engine spark --spark-voice x5_lingfeiyi_flow      聆非易（超拟人）
''',
    )
    parser.add_argument('--video', '-v', default='video.mp4', help='视频文件路径')
    parser.add_argument('--script', '-s', default='script.md', help='文案文件路径（仅支持 .md 格式）')
    parser.add_argument('--output', '-o', default='output', help='输出目录')
    parser.add_argument('--voice', default='zh-CN-XiaoxiaoNeural',
                        help='edge-tts 音色（默认 zh-CN-XiaoxiaoNeural）')
    parser.add_argument('--engine', '-e', default=None,
                        choices=['edge', 'edge-tts', 'spark', 'pyttsx3'],
                        help='TTS 引擎（默认自动探测）')
    parser.add_argument('--spark-voice', default='x5_lingxiaotang_flow',
                        help='讯飞 Spark TTS 发音人（默认聆小糖）')
    parser.add_argument('--subtitle', choices=['yes', 'no'], default='no', help='是否生成字幕')
    parser.add_argument('--stretch', choices=['freeze', 'slow', 'none'], default='freeze',
                        help='配音溢出时: freeze=冻结帧(默认), slow=慢放, none=截断')

    args = parser.parse_args()

    # 获取当前目录
    current_dir = Path.cwd()

    # 解析路径
    video_path = Path(args.video) if Path(args.video).is_absolute() else current_dir / args.video
    script_path = Path(args.script) if Path(args.script).is_absolute() else current_dir / args.script
    output_dir = Path(args.output) if Path(args.output).is_absolute() else current_dir / args.output

    print("=" * 50)
    print("🎬 视频教学配音合成工具")
    print("=" * 50)
    print(f"📹 视频: {video_path}")
    print(f"📝 文案: {script_path}")
    print(f"📁 输出: {output_dir}")
    print(f"⚙️ 引擎: {args.engine or 'auto'}")
    print(f"🎙️ 音色: {args.voice}")
    print(f"⏱️ 溢出策略: {args.stretch}")
    print("=" * 50)

    # 检查依赖（传入强制引擎）
    check_dependencies(forced_engine=args.engine)

    # 检查文件
    if not video_path.exists():
        print(f"❌ 视频文件不存在: {video_path}")
        return
    if not script_path.exists():
        print(f"❌ 文案文件不存在: {script_path}")
        return

    # 创建输出目录
    output_dir.mkdir(parents=True, exist_ok=True)

    # 读取文案
    segments = read_script(script_path)

    if not segments:
        print("❌ 文案为空")
        return

    # 生成音频（传入引擎和讯飞音色）
    audio_files = generate_audio_files(
        segments, output_dir,
        voice=args.voice,
        engine=args.engine,
        spark_voice=args.spark_voice,
    )

    # 以配音为准构建视频（如需扩展）
    result_video, result_audio = build_audio_driven_video(
        video_path, segments, audio_files, output_dir, args.stretch)

    # 合成音频时间轴
    final_audio = output_dir / 'final_audio.mp3'
    adjust_audio_timing(result_audio, final_audio)

    # 合成最终视频
    final_video = output_dir / 'final_video.mp4'
    synthesize_video(result_video, final_audio, final_video)

    print("\n" + "=" * 50)
    print("🎉 完成！")
    print(f"📁 输出文件: {final_video}")
    print("=" * 50)

if __name__ == '__main__':
    main()
