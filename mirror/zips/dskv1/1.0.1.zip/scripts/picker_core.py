"""
每日游资选股核心逻辑 - V2.2

9 阶段漏斗模型，与 stock_picker.py v2.2 保持一致。
AI agent 调用 neodata-financial-search 逐股查询后，按此逻辑执行筛选。
"""

from typing import List, Optional


# ── 9 阶段漏斗定义 ──────────────────────────────────────────

FUNNEL_STAGES = [
    (1, "连板>=2",   lambda c: c.limit_days >= 2),
    (2, "成交额>=3亿", lambda c: c.amount >= 3.0),
    (3, "换手率5~25%", lambda c: 5.0 <= c.turnover <= 25.0),
    (4, "市值范围",   lambda c: _check_market_cap(c)),
    (5, "题材支撑",   lambda c: bool(c.theme and c.theme.strip())),
    (6, "封板质量",   lambda c: c.open_times <= 1),
    (7, "早盘封板",   lambda c: _check_seal_time(c)),
    (8, "风险收益",   lambda c: not (c.limit_days >= 3 and c.open_times >= 1)),
]


def _check_market_cap(c) -> bool:
    """漏斗第4阶段：市值范围"""
    if c.market_type in ("创业板", "科创板"):
        return 30.0 <= c.market_cap <= 200.0
    return 50.0 <= c.market_cap <= 300.0


def _check_seal_time(c) -> bool:
    """漏斗第7阶段：早盘封板（未解析则宽松通过）"""
    if not c.first_limit_time:
        return True
    return c.first_limit_time <= "10:30"


# ── 放宽回填规则 ──────────────────────────────────────────

RELAX_CONDITIONS = {
    "limit_days": lambda v: v >= 2,     # 不放宽
    "amount":      lambda v: v >= 3.0,  # 不放宽
    "turnover":    lambda v: 3.0 <= v <= 25.0,  # 放宽至3%
    # 市值不限
}


def is_relax_pass(c) -> bool:
    """放宽回填判断：连板>=2 + 成交额>=3亿 + 换手率3%~25%"""
    return (c.limit_days >= 2
            and c.amount >= 3.0
            and 3.0 <= c.turnover <= 25.0)


# ── 评分维度（漏斗第9阶段）────────────────────────────────

SCORE_WEIGHTS = {
    "limit_days":  lambda v: min(v * 15, 60),
    "amount":      lambda v: (15 if 3 <= v <= 30
                             else 10 if v > 30
                             else 5 if v > 0 else 0),
    "turnover":    lambda v: (15 if 8 <= v <= 18
                             else 8 if 5 <= v <= 25 else 0),
    "open_times":  lambda v: (15 if v == 0
                             else 8 if v == 1 else 0),
    "main_theme":  10,   # 主线题材加分
    "early_seal":   5,    # 10:30前封板
    "一字板":       3,    # 09:30封板额外
}

MAIN_THEMES = [
    "AI", "人工智能", "算力", "商业航天", "半导体", "机器人",
    "低空经济", "电力", "煤炭", "绿电", "特高压", "特种气体",
    "国产替代", "消费电子", "算力芯片", "工业气体", "氦气",
]


def compute_score(c) -> float:
    """计算综合评分（100分制）"""
    s = 0.0
    s += min(c.limit_days * 15, 60)
    if 3 <= c.amount <= 30:
        s += 15
    elif c.amount > 30:
        s += 10
    elif c.amount > 0:
        s += 5
    if 8 <= c.turnover <= 18:
        s += 15
    elif 5 <= c.turnover <= 25:
        s += 8
    if c.open_times == 0:
        s += 15
    elif c.open_times == 1:
        s += 8
    if any(t in (c.theme or "") for t in MAIN_THEMES):
        s += 10
    if c.first_limit_time and c.first_limit_time <= "10:30":
        s += 5
    if c.first_limit_time == "09:30":
        s += 3
    return s


# ── 风险提示生成 ──────────────────────────────────────────

def generate_risk(c) -> str:
    """生成精确风险提示（via_relax 标的需要补充放宽原因）"""
    if c.limit_days >= 5:
        return f"高位{c.limit_days}连板，仓位<=10%，竞价低开即止损"
    if c.open_times >= 2:
        return "多次炸板，封板质量差，严控仓位，低开>2%止损"
    if c.turnover > 20:
        return "换手率偏高，主力减仓风险，注意低开信号"
    if getattr(c, "via_relax", False):
        parts = []
        if c.market_type == "主板" and c.market_cap < 50:
            parts.append(f"主板小市值({c.market_cap:.0f}亿)，流动性有限")
        if c.market_cap > 300:
            parts.append(f"大市值({c.market_cap:.0f}亿)，连板后抛压重")
        if c.turnover < 5:
            parts.append(f"换手率偏低({c.turnover:.1f}%)，主力参与不足")
        if parts:
            return "；".join(parts) + "，注意高位炸板风险"
        return "放宽条件通过，注意炸板风险，低开>3%止损"
    return "注意炸板风险，低开>3%止损"


# ── 漏斗报告生成 ──────────────────────────────────────────

def funnel_table_headers() -> List[str]:
    return [
        "| # | 股票 | 代码 | 阶段1连板 | 阶段2成交额 | 阶段3换手率 | "
        "阶段4市值 | 阶段5题材 | 阶段6封板 | 阶段7早盘 | 阶段8风险 | 评分 |",
        "|---|------|------|---------|---------|---------|------|------|"
        "-------|------|------|------|",
    ]


def funnel_table_row(i: int, c) -> str:
    fr = c.filter_report()
    def mark(passed, val):
        return "o" if passed else "x", val
    s1, v1 = mark(*fr["连板>=2"])
    s2, v2 = mark(*fr["成交额>=3亿"])
    s3, v3 = mark(*fr["换手率5~25%"])
    s4, v4 = mark(*fr["市值范围"])
    s5, v5 = mark(*fr["有题材"])
    s6, v6 = mark(*fr["封板质量"])
    s7, v7 = mark(*fr["早盘封板"])
    s8, v8 = mark(*fr["风险收益"])
    return (f"| {i+1} | {c.name} | {c.code} | "
            f"{s1} {v1} | {s2} {v2} | "
            f"{s3} {v3} | {s4} {v4} | "
            f"{s5} {v5} | {s6} {v6} | "
            f"{s7} {v7} | {s8} | "
            f"{c.score:.0f} |")


# ── 推送文本格式（无 emoji）───────────────────────────────

def build_push(candidates: list, market_summary: str, trade_date: str) -> str:
    items = []
    for i, c in enumerate(candidates[:5]):
        items.append(
            f"[{i+1}] 【{c.name}】{c.code}\n"
            f"  连板：{c.limit_days}连板 | 题材：{c.theme or '待确认'}\n"
            f"  成交额：{c.amount:.2f}亿 | 换手率：{c.turnover:.1f}%\n"
            f"  封板时间：{c.first_limit_time or '待确认'} | 市值：{c.market_cap:.2f}亿\n"
            f"  核心逻辑：{c.logic}\n"
            f"  风险提示：{c.risk}"
        )
    stocks_block = "\n\n".join(items) + "\n" if items else "（暂无符合条件标的）\n"
    return (
        f"[每日游资选股]\n"
        f"时间：{trade_date}\n"
        f"市场：{market_summary}\n\n"
        f"{stocks_block}\n"
        f"仅供参考，不构成投资建议"
    )
