---
name: gongwen-format
description: >
  中国政府机关公文格式规范（依据最新公文格式修订标准）。
  涵盖页面设置、标题层级、正文格式、附件格式、落款格式及版记要求。
  Navigate when: 创建或调整中国政府公文、红头文件、机关文件格式；
  对 docx 文档应用公文格式标准；公文排版、格式化。
  Keywords: 公文, 红头文件, 政府文件, 党政机关公文格式, 仿宋GB2312, 方正小标宋, 黑体, 楷体, 页边距, 行间距28磅, 附件格式, 落款格式, 版记。
---

# 中国政府公文格式规范 (Government Document Format Standard)

## 概述

本规范依据最新公文格式修订标准，适用于中国党政机关公文的排版与格式化。
涵盖国家标准15种公文的要求，其余公文可参照执行。

使用本 skill 时，应同时加载 `docx` skill 以获取 docx-js 创建文档的基础能力。

---

## 一、页面设置

### 纸张
- 标准 A4 纸 (210mm × 297mm)

### 页边距
| 方向 | 数值 (mm) | DXA 换算 (约) |
|------|-----------|---------------|
| 上   | 37mm      | 2098          |
| 下   | 35mm      | 1984          |
| 左   | 28mm      | 1588          |
| 右   | 26mm      | 1474          |

```javascript
// docx-js 页面设置
const pageConfig = {
  page: {
    size: { width: 11906, height: 16838 },  // A4
    margin: {
      top:    2098,  // 37mm
      bottom: 1984,  // 35mm
      left:   1588,  // 28mm
      right:  1474   // 26mm
    }
  }
};
```

---

## 二、大标题（公文标题）

### 格式要求
| 属性     | 规格                              |
|----------|-----------------------------------|
| 字体     | 方正小标宋简体 (FZXiaoBiaoSong-B05S) |
| 字号     | 二号 (22pt / 44 half-pts)         |
| 加粗     | 是                                |
| 对齐     | 居中                              |

### 特殊规则
- 若大标题过长，需调整格式使其呈**倒梯形**排列（中间行长，上下行短）
- 大标题与正文之间**空一行**

```javascript
// docx-js 大标题段落
new Paragraph({
  alignment: AlignmentType.CENTER,
  spacing: { line: 560, lineRule: "exact", after: 560 },  // 28磅行距 + 空一行
  children: [new TextRun({
    text: "公文大标题",
    font: { ascii: "FZXiaoBiaoSong-B05S", eastAsia: "FZXiaoBiaoSong-B05S" },
    size: 44,  // 二号 = 22pt = 44 half-pts
    bold: true
  })]
})
```

---

## 三、正文标题层级

### 字体与加粗对照表
| 层级     | 字体              | 加粗 | 字号 | half-pts |
|----------|-------------------|------|------|----------|
| 一级标题 | 黑体 (SimHei)     | 是   | 三号 | 32       |
| 二级标题 | 楷体 (KaiTi)      | 是   | 三号 | 32       |
| 三级标题 | 仿宋_GB2312       | 是   | 三号 | 32       |
| 四级标题 | 仿宋_GB2312       | 否   | 三号 | 32       |

### 编号符号规则
| 层级     | 编号格式                  | 示例              |
|----------|--------------------------|-------------------|
| 一级标题 | 汉字数字 + "、"           | 一、二、三、      |
| 二级标题 | 括号 + 汉字数字 + 括号    | （一）（二）（三） |
| 三级标题 | 阿拉伯数字 + "."          | 1. 2. 3.          |
| 四级标题 | 括号 + 阿拉伯数字 + 括号  | （1）（2）（3）   |

**重要规则**：
- 四级标题符号不做其他符号留尾
- 针对没有标题的事项用 "1."，**不用** "1、"

### docx-js 字体配置
```javascript
const HEADING_FONTS = {
  level1: { ascii: "SimHei", eastAsia: "SimHei" },
  level2: { ascii: "KaiTi", eastAsia: "KaiTi" },
  level3: { ascii: "FangSong_GB2312", eastAsia: "FangSong_GB2312" },
  level4: { ascii: "FangSong_GB2312", eastAsia: "FangSong_GB2312" }
};
```

---

## 四、正文格式

### 格式要求
| 属性         | 规格                                       |
|-------------|--------------------------------------------|
| 字体         | 仿宋_GB2312 (FangSong_GB2312)              |
| 字号         | 三号 (16pt / 32 half-pts)                  |
| 加粗         | 否                                         |
| 行间距       | 固定值 28磅 (可根据内容在 25-30磅 间微调)   |
| 首行缩进     | 2字符 (约 640 DXA)                         |

```javascript
// docx-js 正文段落
new Paragraph({
  indent: { firstLine: 640 },  // 首行缩进2字符
  spacing: { line: 560, lineRule: "exact" },  // 28磅行距
  children: [new TextRun({
    text: "正文内容...",
    font: { ascii: "FangSong_GB2312", eastAsia: "FangSong_GB2312" },
    size: 32,  // 三号
    bold: false
  })]
})
```

### 间距规则
- 大标题与正文之间：空一行
- 正文与附件标题之间：空一行
- 正文与落款之间：空三行

---

## 五、附件格式

### 附件标题在正文中的格式
- "附件"二字**不要顶格**，**首行缩进2字符**
- 附件名称过长需换行时，第二行**不要顶格**，要与**序号后第一个字对齐**

```
正确示例：
    附件：1. 这是一个非常非常长的附件名称，
           需要换行显示
    附件：2. 这是第二个附件
```

### 附件本身的格式
- 文件打开后左上角应有 "附件X" 字样
- Excel 和 PPT 除外
- PDF 文件若可编辑，先把字样做好再生成 PDF
- **字体**：黑体 (SimHei)，三号 (16pt)，加粗
- 附件与正文上空一行

---

## 六、落款格式

### 规则一：落款名称比成文日期长
- 名称**右空2字符**
- 日期以落款名称为中心居中对齐

### 规则二：落款名称比成文日期短
- 成文日期**右空4字符**
- 落款名称以日期为中心居中对齐

### 联系人与联系电话
- 联系人与联系电话之间用**中文逗号"，"**隔开，**不用空格**
- 若为调整行间距保持美观，联系人一行可**单独放一页**

---

## 七、版记

- 版记必须放在**偶数页**

---

## 八、字体备用方案

由于 "方正小标宋简体" 和 "仿宋_GB2312" 可能不在所有系统上安装，
在实际操作时应尝试查找系统已安装字体，若缺失则降级使用：

| 规范字体           | 备用字体               |
|-------------------|------------------------|
| 方正小标宋简体     | SimSun (宋体)          |
| 仿宋_GB2312       | FangSong (仿宋)        |
| 黑体 (SimHei)     | Microsoft YaHei        |
| 楷体 (KaiTi)      | 无直接替代，保留 KaiTi |

```python
# 检查并选择字体的辅助逻辑
import subprocess

def get_available_font(primary, fallback):
    """检查首选字体是否可用，否则返回备用字体"""
    try:
        result = subprocess.run(
            ['powershell', '-Command',
             f'[System.Drawing.FontFamily]::Families | Where-Object {{$_.Name -eq "{primary}"}} | Select-Object -First 1'],
            capture_output=True, text=True
        )
        if primary in result.stdout:
            return primary
    except:
        pass
    return fallback
```

---

## 九、快速检查清单

格式化完成后，逐项检查：

- [ ] 纸张为 A4
- [ ] 页边距：上37 下35 左28 右26 (mm)
- [ ] 大标题：方正小标宋简体 / 二号 / 加粗 / 居中
- [ ] 一级标题：黑体 / 三号 / 加粗 / 编号格式 "一、"
- [ ] 二级标题：楷体 / 三号 / 加粗 / 编号格式 "（一）"
- [ ] 三级标题：仿宋_GB2312 / 三号 / 加粗 / 编号格式 "1."
- [ ] 四级标题：仿宋_GB2312 / 三号 / 不加粗 / 编号格式 "（1）"
- [ ] 正文：仿宋_GB2312 / 三号 / 不加粗 / 首行缩进2字符
- [ ] 行间距：固定值 28磅（可25-30磅间微调）
- [ ] 正文与落款空三行
- [ ] 附件格式正确（缩进、字体）
- [ ] 落款格式正确（对齐方式取决于名称与日期长度关系）
- [ ] 版记在偶数页

---

## 十、完整文档生成示例

当需要生成完整公文时，以下为 docx-js 的完整代码参考模板：

```javascript
const { Document, Packer, Paragraph, TextRun, AlignmentType, PageBreak } = require('docx');
const fs = require('fs');

// ===== 常量定义 =====
const FONT_TITLE = "FZXiaoBiaoSong-B05S";  // 方正小标宋简体
const FONT_BODY = "FangSong_GB2312";        // 仿宋_GB2312
const FONT_HEI = "SimHei";                  // 黑体
const FONT_KAI = "KaiTi";                   // 楷体

const SIZE_ER_HAO = 44;  // 二号 = 22pt
const SIZE_SAN_HAO = 32; // 三号 = 16pt

const LINE_SPACING = 560;        // 28磅 (DXA)
const FIRST_LINE_INDENT = 640;   // 首行缩进2字符

// ===== 辅助函数 =====
function bodyParagraph(text, options = {}) {
  return new Paragraph({
    indent: { firstLine: FIRST_LINE_INDENT },
    spacing: { line: LINE_SPACING, lineRule: "exact" },
    ...options,
    children: [
      new TextRun({
        text: text,
        font: { ascii: FONT_BODY, eastAsia: FONT_BODY },
        size: SIZE_SAN_HAO,
        bold: false
      })
    ]
  });
}

function headingParagraph(text, level) {
  const fonts = {
    1: { font: FONT_HEI, bold: true },
    2: { font: FONT_KAI, bold: true },
    3: { font: FONT_BODY, bold: true },
    4: { font: FONT_BODY, bold: false }
  };
  const cfg = fonts[level];
  return new Paragraph({
    indent: { firstLine: FIRST_LINE_INDENT },
    spacing: { line: LINE_SPACING, lineRule: "exact" },
    children: [
      new TextRun({
        text: text,
        font: { ascii: cfg.font, eastAsia: cfg.font },
        size: SIZE_SAN_HAO,
        bold: cfg.bold
      })
    ]
  });
}

function emptyLine() {
  return new Paragraph({
    spacing: { line: LINE_SPACING, lineRule: "exact" },
    children: [new TextRun({ text: "", size: SIZE_SAN_HAO })]
  });
}

// ===== 构建文档 =====
const doc = new Document({
  sections: [{
    properties: {
      page: {
        size: { width: 11906, height: 16838 },
        margin: { top: 2098, bottom: 1984, left: 1588, right: 1474 }
      }
    },
    children: [
      // 大标题
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { line: LINE_SPACING, lineRule: "exact" },
        children: [new TextRun({
          text: "公文大标题",
          font: { ascii: FONT_TITLE, eastAsia: FONT_TITLE },
          size: SIZE_ER_HAO,
          bold: true
        })]
      }),
      // 空一行
      emptyLine(),
      // 一级标题
      headingParagraph("一、一级标题示例", 1),
      bodyParagraph("这是正文内容，字体为仿宋_GB2312，三号字，首行缩进2字符，行间距固定值28磅。"),
      // 二级标题
      headingParagraph("（一）二级标题示例", 2),
      bodyParagraph("正文内容继续..."),
      // 正文与落款之间空三行
      emptyLine(), emptyLine(), emptyLine(),
      // 落款
      bodyParagraph("落款单位名称", { indent: { firstLine: 0 }, alignment: AlignmentType.RIGHT }),
      bodyParagraph("2026年5月7日", { indent: { firstLine: 0 }, alignment: AlignmentType.RIGHT }),
    ]
  }]
});

Packer.toBuffer(doc).then(buffer => {
  fs.writeFileSync("公文示例.docx", buffer);
  console.log("公文生成完成!");
});
```
