# schema

> Print the GraphQL schema to stdout

## Usage

```
Usage:   linear schema

Description:

  Print the GraphQL schema to stdout

Options:

  -h, --help                  - Show this help.                                                      
  -w, --workspace  <slug>     - Target workspace (uses credentials)                                  
  --profile        <profile>  - Execution profile override (agent-safe default, human-debug opt-in)  
  --json                      - Output as JSON introspection result instead of SDL                   
  -o, --output     <file>     - Write schema to file instead of stdout
```
