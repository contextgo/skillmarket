#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
2D分析 - 主执行脚本（固化版本）
功能：一键执行完整的2D分析流程

流程：
1. SQL分箱统计（数据库端）
2. 生成分箱统计Excel表格
3. 生成PDF图表

使用方法：
    # 调试模式
    python run_2d_analysis.py --features "appv4_score_1m10" --risks "1m7,2m7" --output_dir ./output --debug
    
    # 正常模式
    python run_2d_analysis.py --features "appv4_score_1m10" --risks "1m7" --output_dir ./output
    
    # 按月细分
    python run_2d_analysis.py --features "appv4_score_1m10" --risks "1m7" --mode monthly --output_dir ./output
    
    # 按季度细分
    python run_2d_analysis.py --features "appv4_score_1m10" --risks "1m7" --mode quarterly --output_dir ./output
"""

import argparse
import os
import subprocess
import pandas as pd


def run_script(cmd):
    """执行脚本命令"""
    print(f"\n执行: {cmd}")
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    print(result.stdout)
    if result.stderr:
        print(result.stderr)
    return result.returncode == 0


def create_excel_report(input_csv, output_dir):
    """创建Excel报告"""
    print(f"\n=== 生成Excel报告 ===")
    
    df = pd.read_csv(input_csv)
    excel_file = os.path.join(output_dir, '分箱统计结果.xlsx')
    
    with pd.ExcelWriter(excel_file, engine='openpyxl') as writer:
        features = df['特征名'].unique()
        
        for feature in features:
            df_feat = df[df['特征名'] == feature].copy()
            for col in df_feat.columns:
                if '风险率' in col or '缺失率' in col:
                    df_feat[col] = df_feat[col].apply(lambda x: f'{x*100:.2f}%' if pd.notna(x) else '')
            df_feat.to_excel(writer, sheet_name=feature[:31], index=False)
        
        # 汇总sheet：变量之间空一行
        df_summary = pd.DataFrame()
        for i, feature in enumerate(features):
            df_feat = df[df['特征名'] == feature].copy()
            for col in df_feat.columns:
                if '风险率' in col or '缺失率' in col:
                    df_feat[col] = df_feat[col].apply(lambda x: f'{x*100:.2f}%' if pd.notna(x) else '')
            df_summary = pd.concat([df_summary, df_feat], ignore_index=True)
            # 特征之间加空行（最后一个特征不加）
            if i < len(features) - 1:
                empty_row = pd.DataFrame([[''] * len(df.columns)], columns=df.columns)
                df_summary = pd.concat([df_summary, empty_row], ignore_index=True)
        
        df_summary.to_excel(writer, sheet_name='汇总', index=False)
    
    print(f"  ✓ 保存Excel: {excel_file}")
    return excel_file


def validate_data(csv_file, features, risks):
    """验证数据完整性，检查是否有错误"""
    import pandas as pd
    
    print(f"\n{'='*60}")
    print("📋 数据完整性检查")
    print("="*60)
    
    df = pd.read_csv(csv_file)
    
    features_list = [f.strip() for f in features.split(',')]
    risks_list = [r.strip() for r in risks.split(',')]
    
    errors = []
    warnings = []
    
    # 1. 检查每个特征是否都有数据
    for feat in features_list:
        feat_df = df[df['特征名'] == feat]
        if len(feat_df) == 0:
            errors.append(f"❌ 特征 [{feat}] 没有数据！")
    
    # 2. 检查每个特征的风险指标是否都有数据
    for feat in features_list:
        feat_df = df[df['特征名'] == feat]
        for risk in risks_list:
            risk_col = f'{risk}_风险率'
            if risk_col in feat_df.columns:
                null_count = feat_df[risk_col].isna().sum()
                total_count = len(feat_df)
                if null_count == total_count:
                    errors.append(f"❌ 特征 [{feat}] 的风险指标 [{risk}] 全部为空！")
                elif null_count > 0:
                    warnings.append(f"⚠️ 特征 [{feat}] 的风险指标 [{risk}] 有 {null_count}/{total_count} 个空值")
            else:
                errors.append(f"❌ 缺少风险指标列: {risk_col}")
    
    # 3. 检查样本量是否合理
    if '样本量' in df.columns:
        for feat in features_list:
            feat_df = df[df['特征名'] == feat]
            if feat_df['样本量'].isna().all():
                errors.append(f"❌ 特征 [{feat}] 样本量全部为空！")
    
    # 输出结果
    if errors:
        print("\n❌ 发现严重错误：")
        for e in errors:
            print(f"  {e}")
    
    if warnings:
        print("\n⚠️ 发现警告：")
        for w in warnings:
            print(f"  {w}")
    
    if not errors and not warnings:
        print("✅ 数据完整性检查通过！")
    
    return errors, warnings


def main():
    parser = argparse.ArgumentParser(description='2D分析 - 主执行脚本')
    parser.add_argument('--features', type=str, required=True, help='特征列表')
    parser.add_argument('--risks', type=str, required=True, help='风险指标列表')
    parser.add_argument('--output_dir', type=str, default='./output', help='输出目录')
    parser.add_argument('--n_bins', type=int, default=10, help='分箱数量')
    parser.add_argument('--debug', action='store_true', help='调试模式（LIMIT 50000）')
    parser.add_argument('--mode', type=str, default='normal', choices=['normal', 'monthly', 'quarterly'], help='分析模式')
    
    args = parser.parse_args()
    script_dir = os.path.dirname(os.path.abspath(__file__))
    os.makedirs(args.output_dir, exist_ok=True)
    
    print("="*60)
    print("2D分析 - 主执行脚本")
    print("="*60)
    print(f"特征: {args.features}")
    print(f"风险指标: {args.risks}")
    print(f"模式: {'调试模式' if args.debug else '正常模式'}{' - 按'+('月' if args.mode == 'monthly' else '季度')+'细分' if args.mode != 'normal' else ''}")
    
    # 步骤1：SQL分箱统计
    print("\n" + "="*60)
    print("步骤1：SQL分箱统计（数据库端）")
    print("="*60)
    
    export_cmd = f'python {script_dir}/export_data.py --output_dir "{args.output_dir}" --features "{args.features}" --risks "{args.risks}" --n_bins {args.n_bins}'
    if args.debug:
        export_cmd += ' --debug'
    if args.mode != 'normal':
        export_cmd += f' --mode {args.mode}'
    
    if not run_script(export_cmd):
        print("❌ SQL分箱统计失败")
        return
    
    # 步骤2：数据验证
    csv_file = os.path.join(args.output_dir, '分箱统计结果.csv')
    if os.path.exists(csv_file):
        errors, warnings = validate_data(csv_file, args.features, args.risks)
        
        # 如果有严重错误，停止执行
        if errors:
            print("\n❌ 数据验证失败，请检查缓存合并逻辑！")
            print("建议：清空缓存后重新执行，或检查export_data.py中的缓存合并代码")
            return
    
    # 步骤3：生成Excel
    if os.path.exists(csv_file):
        create_excel_report(csv_file, args.output_dir)
    
    # 步骤4：生成PDF
    print("\n" + "="*60)
    print("步骤3：生成PDF图表")
    print("="*60)
    
    if args.mode == 'normal':
        plot_cmd = f'python {script_dir}/plot_risk_analysis.py --input "{csv_file}" --output_dir "{args.output_dir}" --features "{args.features}" --risks "{args.risks}"'
    else:
        plot_cmd = f'python {script_dir}/plot_by_date.py --input "{csv_file}" --output_dir "{args.output_dir}" --features "{args.features}" --risks "{args.risks}"'
    
    if not run_script(plot_cmd):
        print("❌ 生成图表失败")
        return
    
    print("\n" + "="*60)
    print("✓ 2D分析完成！")
    print("="*60)
    print(f"\n输出文件:")
    print(f"  - {args.output_dir}/analysis_queries.sql")
    print(f"  - {args.output_dir}/分箱统计结果.csv")
    print(f"  - {args.output_dir}/分箱统计结果.xlsx")
    for risk in args.risks.split(','):
        suffix = f"_按日期_{risk.strip()}" if args.mode != 'normal' else f"_{risk.strip()}"
        print(f"  - {args.output_dir}/特征区分度分析{suffix}.pdf")


if __name__ == "__main__":
    main()
