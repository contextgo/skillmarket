#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
2D分析 - 主执行脚本（带缓存汇总功能）
功能：执行2D分析，生成缓存使用情况汇总表
"""

import argparse
import os
import sys
import json
import pandas as pd

# 将脚本目录添加到路径
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, script_dir)

# 导入核心功能
from export_data import export_binned_data

# 缓存使用记录
cache_usage_log = []


def log_cache_usage(feature, risk, source, cache_id=None, date=None):
    """记录缓存使用情况"""
    cache_usage_log.append({
        '特征': feature,
        '风险指标': risk,
        '数据来源': source,  # '缓存' or '实时生成'
        '缓存ID': cache_id or '',
        '数据日期': date or '',
        '是否覆盖': 'Yes' if source == '缓存' else 'No'
    })


def run_analysis_with_summary(output_dir, features, risk_metrics, n_bins=10, debug=False, mode='normal'):
    """执行分析并生成汇总"""
    
    print("="*60)
    print("2D分析 - 带缓存汇总")
    print("="*60)
    print(f"模式: {'调试模式' if debug else '正常模式'}{' - 按'+('月' if mode == 'monthly' else '季度')+'细分' if mode != 'normal' else ''}")
    print(f"特征: {len(features)}个")
    print(f"风险指标: {len(risk_metrics)}个")
    print("="*60)
    
    # 执行数据导出
    print("\n步骤1: 导出分箱统计数据")
    print("-"*60)
    
    # 这里需要修改 export_binned_data 函数以支持回调
    # 暂时先执行导出，然后分析缓存使用情况
    
    result_df, data_date = export_binned_data(
        features, risk_metrics, output_dir, n_bins, debug, mode
    )
    
    # 生成缓存使用汇总
    print("\n步骤2: 生成缓存使用汇总")
    print("-"*60)
    
    # 读取缓存使用日志（从 export_data.py 的输出中解析）
    # 这里需要修改 export_data.py 以输出日志文件
    
    # 尝试解析输出中的缓存信息
    summary_file = os.path.join(output_dir, '缓存使用汇总.csv')
    
    # 如果导出过程中没有日志，则生成默认汇总
    if not cache_usage_log:
        # 默认所有都是实时生成
        for feat in features:
            for risk in risk_metrics:
                log_cache_usage(feat, risk, '实时生成')
    
    # 生成汇总表
    summary_df = pd.DataFrame(cache_usage_log)
    
    # 按数据来源分组统计
    cache_summary = summary_df.groupby('数据来源').size().reset_index(name='数量')
    
    print("\n缓存使用统计:")
    print(cache_summary.to_string(index=False))
    
    # 保存汇总表
    summary_df.to_csv(summary_file, index=False, encoding='utf-8-sig')
    print(f"\n✓ 缓存使用汇总已保存: {summary_file}")
    
    # 保存统计信息
    stats_file = os.path.join(output_dir, '分析统计.json')
    stats = {
        '总特征数': len(features),
        '总风险指标数': len(risk_metrics),
        '总组合数': len(features) * len(risk_metrics),
        '缓存覆盖': len(summary_df[summary_df['数据来源'] == '缓存']),
        '实时生成': len(summary_df[summary_df['数据来源'] == '实时生成']),
        '缓存命中率': f"{len(summary_df[summary_df['数据来源'] == '缓存']) / (len(features) * len(risk_metrics)) * 100:.1f}%"
    }
    
    with open(stats_file, 'w', encoding='utf-8') as f:
        json.dump(stats, f, ensure_ascii=False, indent=2)
    
    print(f"✓ 分析统计已保存: {stats_file}")
    print("\n分析统计:")
    for k, v in stats.items():
        print(f"  {k}: {v}")
    
    print("\n" + "="*60)
    print("分析完成！")
    print("="*60)
    
    return result_df, data_date


def main():
    parser = argparse.ArgumentParser(description='2D分析 - 带缓存汇总功能')
    parser.add_argument('--output_dir', type=str, required=True)
    parser.add_argument('--features', type=str, required=True)
    parser.add_argument('--risks', type=str, required=True)
    parser.add_argument('--n_bins', type=int, default=10)
    parser.add_argument('--debug', action='store_true')
    parser.add_argument('--mode', type=str, default='normal', choices=['normal', 'monthly', 'quarterly'])
    
    args = parser.parse_args()
    features = [f.strip() for f in args.features.split(',')]
    risk_metrics = [r.strip() for r in args.risks.split(',')]
    
    os.makedirs(args.output_dir, exist_ok=True)
    
    run_analysis_with_summary(
        args.output_dir, features, risk_metrics, args.n_bins, args.debug, args.mode
    )


if __name__ == "__main__":
    main()
