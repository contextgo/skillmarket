#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
2D分析 - 绘图脚本（固化版本）
功能：从分箱统计结果生成PDF图表

要求（必须严格遵守）：
1. 每个风险指标一个PDF（包含所有特征的多子图）
2. 横坐标：特征均值（不是分箱序号）
3. 纵轴（左）：风险率(%)
4. 纵轴（右）：缺失率(%)
5. 平均线：灰色虚线
6. 最高点：红色三角标注 + 数值
7. 最低点：绿色三角标注 + 数值
8. 图表类型：折线图（禁止柱状图）
9. 格式：PDF（禁止PNG）

使用方法：
    python plot_risk_analysis.py --input 分箱统计结果.csv --output_dir ./output --features "特征1,特征2" --risks "1m7,2m7,3m7,4m7"
"""

import argparse
import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
from matplotlib.font_manager import FontProperties
import warnings
warnings.filterwarnings('ignore')


def get_chinese_font():
    """
    获取中文字体，严格按照字体优先级选择
    
    字体优先级（按SKILL.md第123行要求）：
    1. Noto Sans CJK SC（首选）
    2. WenQuanYi Micro Hei（次选）
    3. SimHei（第三选择）
    4. Microsoft YaHei（第四选择）
    5. Arial Unicode MS（第五选择）
    6. Arial Unicode（第六选择）
    7. DejaVu Sans（最终回退）
    
    v2.8.5修复：原逻辑在某些情况下直接使用DejaVu Sans导致中文乱码
    """
    import urllib.request
    import tempfile
    
    # 字体优先级列表（严格按照SKILL.md要求）
    preferred_fonts = [
        'Noto Sans CJK SC',      # 首选
        'WenQuanYi Micro Hei',   # 次选
        'SimHei',                # 第三选择
        'Microsoft YaHei',       # 第四选择
        'Arial Unicode MS',      # 第五选择
        'Arial Unicode',         # 第六选择
        'DejaVu Sans'            # 最终回退（不含中文字形，仅作为最后备选）
    ]
    
    available_fonts = [f.name for f in fm.fontManager.ttflist]
    
    # 1. 按优先级检查系统中是否有可用字体
    for font_name in preferred_fonts:
        if font_name in available_fonts:
            for f in fm.fontManager.ttflist:
                if f.name == font_name:
                    # 检查是否支持中文（前6个字体支持中文）
                    if font_name != 'DejaVu Sans':
                        print(f"找到中文字体: {font_name}")
                        return FontProperties(fname=f.fname)
                    else:
                        # DejaVu Sans是最终回退，打印警告
                        print(f"警告: 未找到中文字体，使用回退字体: {font_name}（中文可能显示为方框）")
                        print("建议手动安装字体: apt-get install fonts-wqy-microhei 或 fonts-noto-cjk")
                        return FontProperties(fname=f.fname)
    
    print("警告: 系统未找到任何可用字体，尝试下载中文字体...")
    
    # 2. 尝试下载开源中文字体
    font_urls = {
        'NotoSansSC': 'https://github.com/googlefonts/noto-cjk/raw/main/Sans/OTF/SimplifiedChinese/NotoSansCJKsc-Regular.otf',
        'WenQuanYi': 'https://github.com/AaronFeng753/Waifu2x-Extension-GUI/raw/master/SRC/Waifu2x-Extension-QT/fonts/WenQuanYi-Micro-Hei.ttf'
    }
    
    font_cache_dir = os.path.join(tempfile.gettempdir(), '2d_analysis_fonts')
    os.makedirs(font_cache_dir, exist_ok=True)
    
    for font_key, url in font_urls.items():
        font_path = os.path.join(font_cache_dir, f'{font_key}.ttf')
        
        # 如果已下载过，直接使用
        if os.path.exists(font_path):
            try:
                fp = FontProperties(fname=font_path)
                print(f"使用已下载字体: {font_key}")
                return fp
            except:
                pass
        
        # 尝试下载
        try:
            print(f"正在下载字体: {font_key}...")
            urllib.request.urlretrieve(url, font_path)
            fp = FontProperties(fname=font_path)
            print(f"✓ 字体下载成功: {font_key}")
            return fp
        except Exception as e:
            print(f"字体下载失败: {font_key} - {str(e)[:50]}")
            continue
    
    # 3. 所有方法都失败，返回None（调用方应处理此情况）
    print("错误: 无法获取任何字体，PDF中文将显示为方框")
    print("解决方案: apt-get install fonts-wqy-microhei 或 fonts-noto-cjk")
    
    return None


def plot_risk_metric_pdf(df, risk_col, features, output_file, chinese_fp, data_date=''):
    """为指定风险指标生成PDF图表"""
    line_colors = ['#007AFF', '#34C759', '#FF9500', '#AF52DE', '#5AC8FA', '#FF2D55',
                   '#5856D6', '#32ADE6', '#FF9500', '#AF52DE', '#5AC8FA', '#FF2D55',
                   '#007AFF', '#34C759']
    gray_color = '#8E8E93'
    red_color = '#FF3B30'
    green_color = '#34C759'
    
    # 过滤有效特征
    valid_features = []
    for feature in features:
        df_feat = df[df['特征名'] == feature]
        if len(df_feat) > 0 and f'{risk_col}_风险率' in df_feat.columns:
            valid_features.append(feature)
    
    if len(valid_features) == 0:
        print(f"  ⚠️ {risk_col} 无有效数据")
        return None
    
    # 创建子图
    n_features = len(valid_features)
    n_cols = min(4, n_features)
    n_rows = (n_features + n_cols - 1) // n_cols
    
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(5*n_cols, 5*n_rows), facecolor='#FFFFFF')
    
    if n_rows == 1 and n_cols == 1:
        axes = np.array([[axes]])
    elif n_rows == 1:
        axes = axes.reshape(1, -1)
    elif n_cols == 1:
        axes = axes.reshape(-1, 1)
    
    for feature_idx, feature_name in enumerate(valid_features):
        row = feature_idx // n_cols
        col = feature_idx % n_cols
        ax1 = axes[row, col]
        
        df_feat = df[df['特征名'] == feature_name].sort_values('分箱序号')
        
        # 判断特征类型：如果有"分箱值"列且值是字符串，则为分类变量
        is_categorical = False
        if '分箱值' in df_feat.columns:
            bin_values = df_feat['分箱值'].values
            # 检查是否为字符串类型（分类变量）
            if any(isinstance(v, str) and v not in ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10'] for v in bin_values if pd.notna(v)):
                is_categorical = True
        
        if is_categorical:
            # 分类变量：用分箱值作为横轴标签
            x_labels = df_feat['分箱值'].astype(str).values
            x = np.arange(len(x_labels))  # 数值位置
            y = pd.to_numeric(df_feat[f'{risk_col}_风险率'], errors='coerce').values * 100
            
            missing_col = f'{risk_col}_缺失率'
            if missing_col in df_feat.columns:
                missing_rate = pd.to_numeric(df_feat[missing_col], errors='coerce').values * 100
            else:
                missing_rate = np.zeros(len(x))
            
            mean_y = np.nanmean(y)
            y_valid = y[~np.isnan(y)]
            x_valid = x[~np.isnan(y)]
            
            if len(y_valid) == 0:
                continue
            
            high_idx = np.argmax(y_valid)
            low_idx = np.argmin(y_valid)
            high_x, high_y = x_valid[high_idx], y_valid[high_idx]
            low_x, low_y = x_valid[low_idx], y_valid[low_idx]
            
            color_idx = feature_idx % len(line_colors)
            
            # 平均线（灰色虚线）
            ax1.axhline(y=mean_y, color=gray_color, linestyle='--', linewidth=2, alpha=0.6)
            
            # 折线图（分类变量）
            ax1.plot(x, y, marker='o', linewidth=2.5, markersize=8,
                    color=line_colors[color_idx], markerfacecolor='#FFFFFF',
                    markeredgewidth=2, markeredgecolor=line_colors[color_idx])
            
            # 设置分类变量的横轴标签
            ax1.set_xticks(x)
            ax1.set_xticklabels(x_labels, rotation=45, ha='right', fontproperties=chinese_fp, fontsize=9)
            
        else:
            # 数值变量：用特征均值作为横轴
            x = pd.to_numeric(df_feat['特征均值'], errors='coerce').values
            y = pd.to_numeric(df_feat[f'{risk_col}_风险率'], errors='coerce').values * 100
            
            missing_col = f'{risk_col}_缺失率'
            if missing_col in df_feat.columns:
                missing_rate = pd.to_numeric(df_feat[missing_col], errors='coerce').values * 100
            else:
                missing_rate = np.zeros(len(x))
            
            mean_y = np.nanmean(y)
            y_valid = y[~np.isnan(y)]
            x_valid = x[~np.isnan(y)]
            
            if len(y_valid) == 0:
                continue
            
            high_idx = np.argmax(y_valid)
            low_idx = np.argmin(y_valid)
            high_x, high_y = x_valid[high_idx], y_valid[high_idx]
            low_x, low_y = x_valid[low_idx], y_valid[low_idx]
            
            color_idx = feature_idx % len(line_colors)
            
            # 平均线（灰色虚线）
            ax1.axhline(y=mean_y, color=gray_color, linestyle='--', linewidth=2, alpha=0.6)
            
            # 折线图（数值变量）
            ax1.plot(x, y, marker='o', linewidth=2.5, markersize=8,
                    color=line_colors[color_idx], markerfacecolor='#FFFFFF',
                    markeredgewidth=2, markeredgecolor=line_colors[color_idx])
        
        # 最高点（红色三角）
        ax1.scatter([high_x], [high_y], s=150, c=red_color, marker='^', zorder=5)
        ax1.annotate(f'{high_y:.2f}%', xy=(high_x, high_y), xytext=(8, 8),
                    textcoords='offset points', fontproperties=chinese_fp, fontsize=10, color=red_color)
        
        # 最低点（绿色三角）
        ax1.scatter([low_x], [low_y], s=150, c=green_color, marker='v', zorder=5)
        ax1.annotate(f'{low_y:.2f}%', xy=(low_x, low_y), xytext=(8, -12),
                    textcoords='offset points', fontproperties=chinese_fp, fontsize=10, color=green_color)
        
        ax1.set_xlabel(feature_name, fontproperties=chinese_fp, fontsize=12)
        ax1.set_ylabel(f'{risk_col} 逾期率 (%)', fontproperties=chinese_fp, fontsize=12)
        ax1.grid(True, linestyle='--', alpha=0.3)
        
        for label in ax1.get_xticklabels():
            label.set_fontproperties(chinese_fp)
        for label in ax1.get_yticklabels():
            label.set_fontproperties(chinese_fp)
        
        # 右轴：样本量（LOG10对数坐标轴）
        ax2 = ax1.twinx()
        
        # 获取样本量数据
        if '样本量' in df_feat.columns:
            sample_count = pd.to_numeric(df_feat['样本量'], errors='coerce').values
        else:
            sample_count = np.ones(len(x))  # 如果没有样本量，默认为1
        
        # 过滤掉无效值
        valid_mask = ~np.isnan(sample_count) & (sample_count > 0)
        sample_count_valid = sample_count[valid_mask]
        
        if len(sample_count_valid) == 0:
            sample_count_valid = np.ones(len(x))
        
        # 使用LOG10对数坐标轴
        ax2.set_yscale('log', base=10)
        
        # 计算合适的坐标轴范围（基于数据范围）
        min_val = max(1, sample_count_valid.min() * 0.5)  # 最小值的0.5倍作为下限
        max_val = sample_count_valid.max() * 2  # 最大值的2倍作为上限
        ax2.set_ylim(min_val, max_val)
        
        # 绘制样本量柱状图
        bar_width = 0.56 if is_categorical else (x.max() - x.min()) / len(x) * 0.56 if len(x) > 1 else 0.35
        ax2.bar(x, sample_count, alpha=0.3, color='#FF9500', width=bar_width)
        
        ax2.set_ylabel('样本量 (log₁₀)', fontproperties=chinese_fp, fontsize=11, color='#FF9500')
        ax2.tick_params(axis='y', labelcolor='#FF9500')
        
        # 设置对数坐标轴的刻度（自动根据数据范围）
        from matplotlib.ticker import LogLocator, FuncFormatter, NullFormatter
        ax2.yaxis.set_major_locator(LogLocator(base=10))
        
        # 设置对数坐标轴的刻度格式
        def log_formatter(x, pos):
            if x >= 1000000:
                return f'{x/1000000:.0f}M'
            elif x >= 1000:
                return f'{x/1000:.0f}K'
            else:
                return f'{x:.0f}'
        ax2.yaxis.set_major_formatter(FuncFormatter(log_formatter))
        
        # 禁用次刻度显示（避免显示科学计数法如 2×10^5）
        ax2.yaxis.set_minor_formatter(NullFormatter())
        
        for label in ax2.get_yticklabels():
            label.set_fontproperties(chinese_fp)
        
        ax1.set_title(f'{feature_name} 对 {risk_col} 的区分度',
                     fontproperties=chinese_fp, fontsize=11, fontweight='bold')
    
    # 隐藏多余子图
    for idx in range(n_features, n_rows * n_cols):
        row = idx // n_cols
        col = idx % n_cols
        axes[row, col].set_visible(False)
    
    fig.suptitle(f'特征对 {risk_col} 的区分度分析',
                 fontproperties=chinese_fp, fontsize=16, fontweight='bold', y=1.02)
    
    # 在右下角添加数据截止日期戳
    if data_date:
        fig.text(0.98, 0.02, f'数据截止: {data_date}', 
                 ha='right', va='bottom', fontsize=9,
                 fontproperties=chinese_fp, color='#666666',
                 style='italic')
    
    plt.tight_layout()
    plt.savefig(output_file, format='pdf', bbox_inches='tight', facecolor='#FFFFFF')
    plt.close()
    
    print(f"  ✓ 已保存: {output_file}")
    return output_file


def main():
    parser = argparse.ArgumentParser(description='2D分析 - 绘图脚本')
    parser.add_argument('--input', type=str, required=True, help='分箱统计结果CSV')
    parser.add_argument('--output_dir', type=str, required=True, help='输出目录')
    parser.add_argument('--features', type=str, required=True, help='特征列表')
    parser.add_argument('--risks', type=str, required=True, help='风险指标列表')
    parser.add_argument('--data_date', type=str, default='', help='数据截止日期')
    
    args = parser.parse_args()
    features = [f.strip() for f in args.features.split(',')]
    risk_metrics = [r.strip() for r in args.risks.split(',')]
    
    # 如果没有传入data_date，尝试从文件读取
    if not args.data_date:
        date_file = os.path.join(os.path.dirname(args.input), 'data_date.txt')
        if os.path.exists(date_file):
            with open(date_file, 'r', encoding='utf-8') as f:
                args.data_date = f.read().strip()
    
    print("="*60)
    print("2D分析 - 绘图脚本")
    print("="*60)
    if args.data_date:
        print(f"数据截止日期: {args.data_date}")
    
    os.makedirs(args.output_dir, exist_ok=True)
    
    # 获取中文字体
    chinese_fp = get_chinese_font()
    
    # 加载数据
    df = pd.read_csv(args.input)
    print(f"加载数据: {len(df)} 行")
    
    # 为每个风险指标生成PDF
    for risk_col in risk_metrics:
        output_file = os.path.join(args.output_dir, f"特征区分度分析_{risk_col}.pdf")
        plot_risk_metric_pdf(df, risk_col, features, output_file, chinese_fp, args.data_date)
    
    print("\n完成！")


if __name__ == "__main__":
    main()
