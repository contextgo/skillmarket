#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
2D分析 - 按日期细分绘图脚本（固化版本）
功能：从分箱统计结果生成分月/分季度的PDF图表

要求（必须严格遵守）：
1. 每个风险指标一个PDF（包含所有特征的多子图）
2. 每个子图中多条折线（每个时间段一条）
3. 横坐标：特征均值（数值变量）或 分箱值标签（分类变量）
4. 纵轴：风险率(%)
5. 图例：显示时间段
6. 图表类型：折线图（禁止柱状图）
7. 格式：PDF（禁止PNG）
8. 分类变量：横轴标签旋转45度显示

使用方法：
    python plot_by_date.py --input 分箱统计结果.csv --output_dir ./output --features "特征1,特征2" --risks "1m7,2m7,3m7,4m7"
"""

import argparse
import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
from matplotlib.font_manager import FontProperties
import warnings
warnings.filterwarnings('ignore')


def get_chinese_font():
    """
    获取中文字体，严格按照字体优先级选择
    
    字体优先级（按SKILL.md第123行要求）：
    1. Noto Sans CJK SC（首选）
    2. WenQuanYi Micro Hei（次选）
    3. SimHei（第三选择）
    4. Microsoft YaHei（第四选择）
    5. Arial Unicode MS（第五选择）
    6. Arial Unicode（第六选择）
    7. DejaVu Sans（最终回退）
    
    v2.8.5修复：原逻辑在某些情况下直接使用DejaVu Sans导致中文乱码
    """
    import urllib.request
    import tempfile
    
    # 字体优先级列表（严格按照SKILL.md要求）
    preferred_fonts = [
        'Noto Sans CJK SC',      # 首选
        'WenQuanYi Micro Hei',   # 次选
        'SimHei',                # 第三选择
        'Microsoft YaHei',       # 第四选择
        'Arial Unicode MS',      # 第五选择
        'Arial Unicode',         # 第六选择
        'DejaVu Sans'            # 最终回退（不含中文字形，仅作为最后备选）
    ]
    
    available_fonts = [f.name for f in fm.fontManager.ttflist]
    
    # 1. 按优先级检查系统中是否有可用字体
    for font_name in preferred_fonts:
        if font_name in available_fonts:
            for f in fm.fontManager.ttflist:
                if f.name == font_name:
                    # 检查是否支持中文（前6个字体支持中文）
                    if font_name != 'DejaVu Sans':
                        print(f"找到中文字体: {font_name}")
                        return FontProperties(fname=f.fname)
                    else:
                        # DejaVu Sans是最终回退，打印警告
                        print(f"警告: 未找到中文字体，使用回退字体: {font_name}（中文可能显示为方框）")
                        print("建议手动安装字体: apt-get install fonts-wqy-microhei 或 fonts-noto-cjk")
                        return FontProperties(fname=f.fname)
    
    print("警告: 系统未找到任何可用字体，尝试下载中文字体...")
    
    # 2. 尝试下载开源中文字体
    font_urls = {
        'NotoSansSC': 'https://github.com/googlefonts/noto-cjk/raw/main/Sans/OTF/SimplifiedChinese/NotoSansCJKsc-Regular.otf',
        'WenQuanYi': 'https://github.com/AaronFeng753/Waifu2x-Extension-GUI/raw/master/SRC/Waifu2x-Extension-QT/fonts/WenQuanYi-Micro-Hei.ttf'
    }
    
    font_cache_dir = os.path.join(tempfile.gettempdir(), '2d_analysis_fonts')
    os.makedirs(font_cache_dir, exist_ok=True)
    
    for font_key, url in font_urls.items():
        font_path = os.path.join(font_cache_dir, f'{font_key}.ttf')
        
        # 如果已下载过，直接使用
        if os.path.exists(font_path):
            try:
                fp = FontProperties(fname=font_path)
                print(f"使用已下载字体: {font_key}")
                return fp
            except:
                pass
        
        # 尝试下载
        try:
            print(f"正在下载字体: {font_key}...")
            urllib.request.urlretrieve(url, font_path)
            fp = FontProperties(fname=font_path)
            print(f"✓ 字体下载成功: {font_key}")
            return fp
        except Exception as e:
            print(f"字体下载失败: {font_key} - {str(e)[:50]}")
            continue
    
    # 3. 所有方法都失败，返回None（调用方应处理此情况）
    print("错误: 无法获取任何字体，PDF中文将显示为方框")
    print("解决方案: apt-get install fonts-wqy-microhei 或 fonts-noto-cjk")
    
    return None


# 时间段配色方案
PERIOD_COLORS = [
    '#FF3B30', '#FF9500', '#FFCC00', '#34C759', '#00C7BE', '#30B0C7',
    '#007AFF', '#5856D6', '#AF52DE', '#FF2D55', '#A2845E', '#8E8E93'
]


def plot_risk_by_date_pdf(df, risk_col, features, output_file, chinese_fp, data_date=''):
    """为指定风险指标生成按日期细分的PDF图表"""
    
    # 过滤有效特征
    valid_features = []
    for feature in features:
        df_feat = df[df['特征名'] == feature]
        if len(df_feat) > 0 and f'{risk_col}_风险率' in df_feat.columns:
            valid_features.append(feature)
    
    if len(valid_features) == 0:
        print(f"  ⚠️ {risk_col} 无有效数据")
        return None
    
    # 获取时间段列表
    time_periods = sorted(df['时间段'].dropna().unique())
    print(f"  时间段: {time_periods}")
    
    # 创建子图
    n_features = len(valid_features)
    n_cols = min(4, n_features)
    n_rows = (n_features + n_cols - 1) // n_cols
    
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(5*n_cols, 5*n_rows), facecolor='#FFFFFF')
    
    if n_rows == 1 and n_cols == 1:
        axes = np.array([[axes]])
    elif n_rows == 1:
        axes = axes.reshape(1, -1)
    elif n_cols == 1:
        axes = axes.reshape(-1, 1)
    
    for feature_idx, feature_name in enumerate(valid_features):
        row = feature_idx // n_cols
        col = feature_idx % n_cols
        ax = axes[row, col]
        
        df_feat = df[df['特征名'] == feature_name]
        
        # 判断特征类型：检查是否有分箱标签列且值为非数字字符串
        is_categorical = False
        if '分箱标签' in df_feat.columns or '分箱值' in df_feat.columns:
            label_col = '分箱标签' if '分箱标签' in df_feat.columns else '分箱值'
            labels = df_feat[label_col].dropna().astype(str).unique()
            # 如果标签不是纯数字，认为是分类变量
            non_numeric_labels = [l for l in labels if not l.replace('.', '').replace('-', '').isdigit()]
            if len(non_numeric_labels) > 0:
                is_categorical = True
        
        # 每个时间段一条折线
        for period_idx, period in enumerate(time_periods):
            period_data = df_feat[df_feat['时间段'] == period].sort_values('分箱序号')
            
            if len(period_data) == 0:
                continue
            
            color = PERIOD_COLORS[period_idx % len(PERIOD_COLORS)]
            
            if is_categorical:
                # 分类变量：用分箱标签作为横轴
                label_col = '分箱标签' if '分箱标签' in period_data.columns else '分箱值'
                x_labels = period_data[label_col].astype(str).values
                x = np.arange(len(x_labels))  # 数值位置
                y = pd.to_numeric(period_data[f'{risk_col}_风险率'], errors='coerce').values * 100
                
                if len(x) == 0:
                    continue
                
                ax.plot(x, y, marker='o', linewidth=2, markersize=6,
                       color=color, label=period, alpha=0.8)
            else:
                # 数值变量：用特征均值作为横轴
                x = pd.to_numeric(period_data['特征均值'], errors='coerce').values
                y = pd.to_numeric(period_data[f'{risk_col}_风险率'], errors='coerce').values * 100
                
                if len(x) == 0:
                    continue
                
                ax.plot(x, y, marker='o', linewidth=2, markersize=6,
                       color=color, label=period, alpha=0.8)
        
        # 设置横轴标签
        if is_categorical:
            # 获取第一个时间段的标签作为x轴标签
            first_period_data = df_feat[df_feat['时间段'] == time_periods[0]].sort_values('分箱序号')
            label_col = '分箱标签' if '分箱标签' in first_period_data.columns else '分箱值'
            x_labels = first_period_data[label_col].astype(str).values
            ax.set_xticks(np.arange(len(x_labels)))
            ax.set_xticklabels(x_labels, rotation=45, ha='right')
        
        ax.set_xlabel(feature_name, fontproperties=chinese_fp, fontsize=12)
        ax.set_ylabel(f'{risk_col} 逾期率 (%)', fontproperties=chinese_fp, fontsize=12)
        ax.grid(True, linestyle='--', alpha=0.3)
        ax.legend(prop=chinese_fp, fontsize=8, loc='best')
        
        for label in ax.get_xticklabels():
            label.set_fontproperties(chinese_fp)
        for label in ax.get_yticklabels():
            label.set_fontproperties(chinese_fp)
        
        ax.set_title(f'{feature_name} 对 {risk_col} 的区分度（按时间）',
                     fontproperties=chinese_fp, fontsize=11, fontweight='bold')
    
    # 隐藏多余子图
    for idx in range(n_features, n_rows * n_cols):
        row = idx // n_cols
        col = idx % n_cols
        axes[row, col].set_visible(False)
    
    fig.suptitle(f'特征对 {risk_col} 的区分度分析（按日期细分）',
                 fontproperties=chinese_fp, fontsize=16, fontweight='bold', y=1.02)
    
    # 在右下角添加数据截止日期戳
    if data_date:
        fig.text(0.98, 0.02, f'数据截止: {data_date}', 
                 ha='right', va='bottom', fontsize=9,
                 fontproperties=chinese_fp, color='#666666',
                 style='italic')
    
    plt.tight_layout()
    plt.savefig(output_file, format='pdf', bbox_inches='tight', facecolor='#FFFFFF')
    plt.close()
    
    print(f"  ✓ 已保存: {output_file}")
    return output_file


def main():
    parser = argparse.ArgumentParser(description='2D分析 - 按日期细分绘图')
    parser.add_argument('--input', type=str, required=True, help='分箱统计结果CSV（需含时间段列）')
    parser.add_argument('--output_dir', type=str, required=True, help='输出目录')
    parser.add_argument('--features', type=str, required=True, help='特征列表')
    parser.add_argument('--risks', type=str, required=True, help='风险指标列表')
    parser.add_argument('--data_date', type=str, default='', help='数据截止日期')
    
    args = parser.parse_args()
    
    features = [f.strip() for f in args.features.split(',')]
    risk_metrics = [r.strip() for r in args.risks.split(',')]
    
    print("="*60)
    print("2D分析 - 按日期细分绘图")
    print("="*60)
    print(f"数据截止日期: {args.data_date}")
    
    # 获取中文字体
    chinese_fp = get_chinese_font()
    
    # 读取数据
    df = pd.read_csv(args.input, encoding='utf-8-sig')
    print(f"加载数据: {len(df)} 行")
    
    # 检查是否有时间段列
    if '时间段' not in df.columns:
        print("错误: 数据中缺少'时间段'列，无法按日期细分")
        return
    
    # 为每个风险指标生成PDF
    for risk_col in risk_metrics:
        output_file = os.path.join(args.output_dir, f'特征区分度分析_按日期_{risk_col}.pdf')
        plot_risk_by_date_pdf(df, risk_col, features, output_file, chinese_fp, args.data_date)
    
    print("\n完成！")


if __name__ == "__main__":
    main()
