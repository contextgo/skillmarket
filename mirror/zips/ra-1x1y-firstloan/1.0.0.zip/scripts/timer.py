#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
2D分析 - 计时工具

功能：记录每个步骤的执行时间，生成时间统计报告

使用方法：
    from timer import StepTimer
    
    timer = StepTimer()
    
    with timer.step("SQL分箱统计"):
        # 执行步骤1
        pass
    
    with timer.step("生成Excel"):
        # 执行步骤2
        pass
    
    timer.save_report("执行时间统计.json")
    timer.print_summary()
"""

import time
import json
import os
from datetime import datetime
from contextlib import contextmanager


class StepTimer:
    """步骤计时器"""
    
    def __init__(self):
        self.steps = []
        self.start_time = time.time()
        self.current_step_start = None
        self.current_step_name = None
    
    @contextmanager
    def step(self, step_name):
        """计时上下文管理器"""
        self.current_step_name = step_name
        self.current_step_start = time.time()
        
        print(f"\n⏱️  开始: {step_name}")
        
        try:
            yield
        finally:
            elapsed = time.time() - self.current_step_start
            self.steps.append({
                'step': step_name,
                'start_time': datetime.fromtimestamp(self.current_step_start).strftime('%H:%M:%S'),
                'elapsed_seconds': round(elapsed, 2),
                'elapsed_readable': self._format_duration(elapsed)
            })
            print(f"✅ 完成: {step_name} (耗时: {self._format_duration(elapsed)})")
    
    def _format_duration(self, seconds):
        """格式化时长"""
        if seconds < 60:
            return f"{seconds:.1f}秒"
        elif seconds < 3600:
            minutes = int(seconds // 60)
            secs = seconds % 60
            return f"{minutes}分{secs:.0f}秒"
        else:
            hours = int(seconds // 3600)
            minutes = int((seconds % 3600) // 60)
            return f"{hours}小时{minutes}分"
    
    def save_report(self, output_file):
        """保存时间统计报告"""
        total_time = time.time() - self.start_time
        
        report = {
            'total_time_seconds': round(total_time, 2),
            'total_time_readable': self._format_duration(total_time),
            'start_time': datetime.fromtimestamp(self.start_time).strftime('%Y-%m-%d %H:%M:%S'),
            'end_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'steps': self.steps
        }
        
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        
        print(f"\n📊 时间统计已保存: {output_file}")
    
    def print_summary(self):
        """打印时间统计摘要"""
        total_time = time.time() - self.start_time
        
        print("\n" + "="*60)
        print("⏱️  执行时间统计")
        print("="*60)
        
        for i, step in enumerate(self.steps, 1):
            pct = (step['elapsed_seconds'] / total_time * 100) if total_time > 0 else 0
            print(f"{i}. {step['step']}: {step['elapsed_readable']} ({pct:.1f}%)")
        
        print("-"*60)
        print(f"总耗时: {self._format_duration(total_time)}")
        print("="*60)
