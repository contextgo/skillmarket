#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
2D分析 - SQL数据导出脚本（固化版本）
功能：在数据库端完成分箱统计，只导出聚合结果

模式：
- 调试模式（--debug）：LIMIT 50000 样本
- 正常模式：全量数据
- 按月细分（--mode monthly）：按月份细分
- 按季度细分（--mode quarterly）：按季度细分

使用方法：
    python export_data.py --output_dir ./output --features "特征1,特征2" --risks "1m7,2m7" --debug
    python export_data.py --output_dir ./output --features "特征1" --risks "1m7" --mode monthly
"""

import argparse
import os
import pandas as pd
from odps import ODPS
import warnings
warnings.filterwarnings('ignore')

# 数据库配置
DB_CONFIG = {
    'access_id': 'LTAI5tR3U6U3kkuhp7FJodHm',
    'secret_access_key': 'Bf2KCRaGm4jFqd7TKFynFBCm1Ushwp',
    'project': 'ai_ys',
    'endpoint': 'https://service.ap-southeast-5.maxcompute.aliyun.com/api'
}

FEATURE_TABLE = 'rsk_ys.tmp_test_for_aiauto_drv_202604'
LABEL_TABLE = 'rsk_ys.tmp_test_for_aiauto_ylabel_202604'

# 缓存表名（使用当前项目ai_ys下的表）
CACHE_TABLE = 'tmp_2d_analysis_cache'

# 分类变量特征列表（需要根据实际数据字典维护）
# 包括：枚举型变量、机构数类变量
CATEGORICAL_FEATURES = [
    'gender',           # 性别
    'channel',          # 渠道
    'fdc蝌蚪贷近3个月放款机构数',  # 机构数（枚举值）
    'fdc近1个月放款机构数',       # 机构数（枚举值）
    'fdc在贷机构数',             # 机构数（枚举值）
]

# 技能版本号（修改脚本逻辑后需要更新）
SKILL_VERSION = '2.8.5'  # 修复get_chinese_font()字体选择逻辑，严格按照优先级选择中文字体

# 缓存有效期（天）
CACHE_EXPIRE_DAYS = 5


def generate_cache_key(features, risk_metrics, mode, debug):
    """生成缓存键（基于参数hash，区分调试/正常模式）
    
    注意：版本号只取前两位（如2.5.5→2.5），小版本号迭代不清缓存
    只有升级大版本号（如2.5→2.6或3.0）时才需要重新生成缓存
    """
    import hashlib
    # 只取版本号前两位（如2.5.5→2.5）
    version_prefix = '.'.join(SKILL_VERSION.split('.')[:2])
    # 调试模式和正常模式生成不同的缓存键
    debug_flag = 'debug' if debug else 'normal'
    params = f"{version_prefix}|{','.join(sorted(features))}|{','.join(sorted(risk_metrics))}|{mode}|{debug_flag}"
    return hashlib.md5(params.encode()).hexdigest()


def get_version_prefix():
    """获取版本号前两位（用于缓存匹配）"""
    return '.'.join(SKILL_VERSION.split('.')[:2])


def get_major_version():
    """获取大版本号（第一位，用于宽松匹配）"""
    return SKILL_VERSION.split('.')[0]


def create_cache_table(odps_conn):
    """创建缓存表（如果不存在）"""
    create_sql = f"""
    CREATE TABLE IF NOT EXISTS {CACHE_TABLE} (
        cache_id STRING COMMENT '缓存唯一标识',
        skill_version STRING COMMENT '技能版本号',
        mode STRING COMMENT '运行模式: normal/debug/monthly/quarterly',
        feature_list STRING COMMENT '特征列表(JSON)',
        risk_list STRING COMMENT '风险指标列表(JSON)',
        create_time DATETIME COMMENT '创建时间',
        expire_time DATETIME COMMENT '过期时间',
        data_csv STRING COMMENT '分箱统计结果(CSV格式)',
        is_debug BOOLEAN COMMENT '是否调试模式',
        data_date STRING COMMENT '数据截止日期'
    )
    COMMENT '2D分析缓存表 - 5天有效期'
    """
    try:
        odps_conn.execute_sql(create_sql)
        print(f"  ✓ 缓存表已就绪: {CACHE_TABLE}")
    except Exception as e:
        print(f"  ⚠️ 创建缓存表失败（可能已存在）: {e}")


def check_cache(odps_conn, features, risk_metrics, mode, debug):
    """
    智能缓存检查：
    1. 完全匹配 → 直接使用
    2. 多个缓存组合 → 合并缓存数据
    3. 部分覆盖 → 返回未覆盖的特征/风险列表，由调用方决定是否合并
    4. 无缓存 → 返回需要实时生成全部
    
    返回值：(cached_csv, data_date, uncovered_features, uncovered_risks, is_full_coverage, covered_combinations)
    - is_full_coverage=True: 完全覆盖，可直接使用cached_csv
    - is_full_coverage=False: 部分覆盖或无缓存，cached_csv为None
    - covered_combinations: 已缓存的(特征, 风险)组合集合
    """
    import json
    import io
    
    cache_id = generate_cache_key(features, risk_metrics, mode, debug)
    debug_flag = '调试模式' if debug else '正常模式'
    
    # 1. 先查找完全匹配的缓存
    # 版本匹配规则：匹配前两位（如 2.6%），小版本迭代（2.6.4→2.6.5）可复用缓存
    version_prefix = get_version_prefix()
    check_sql = f"""
    SELECT data_csv, data_date, create_time, skill_version
    FROM {CACHE_TABLE} 
    WHERE cache_id = '{cache_id}' 
      AND skill_version LIKE '{version_prefix}%'
      AND is_debug = {str(debug).lower()}
      AND expire_time > GETDATE()
    LIMIT 1
    """
    try:
        result = odps_conn.execute_sql(check_sql)
        with result.open_reader() as reader:
            records = list(reader)
        if records and len(records) > 0:
            print(f"\n{'='*60}")
            print(f"  📦 使用缓存数据（完全匹配）({debug_flag})")
            print(f"  数据截止日期: {records[0]['data_date']}")
            print(f"  缓存创建时间: {records[0]['create_time']}")
            print(f"{'='*60}\n")
            # 完全匹配，所有组合都缓存
            all_combinations = {(f, r) for f in features for r in risk_metrics}
            return records[0]['data_csv'], records[0]['data_date'], [], [], True, all_combinations
    except Exception as e:
        print(f"  ⚠️ 检查缓存失败: {e}")
    
    # 2. 查找所有可用缓存，智能组合
    subset_sql = f"""
    SELECT data_csv, data_date, create_time, feature_list, risk_list, skill_version
    FROM {CACHE_TABLE} 
    WHERE skill_version LIKE '{version_prefix}%'
      AND mode = '{mode}'
      AND is_debug = {str(debug).lower()}
      AND expire_time > GETDATE()
    ORDER BY create_time DESC
    """
    try:
        result = odps_conn.execute_sql(subset_sql)
        with result.open_reader() as reader:
            all_caches = list(reader)
        
        if not all_caches:
            print(f"\n{'='*60}")
            print(f"  ⚡ 无可用缓存，实时生成全部 ({debug_flag})")
            print(f"  特征: {len(features)}个，风险指标: {len(risk_metrics)}个")
            print(f"{'='*60}\n")
            return None, None, features, risk_metrics, False
        
        # 分析每个缓存能覆盖的特征和风险
        request_features = set(features)
        request_risks = set(risk_metrics)
        
        # 关键修复：按"特征+风险"组合来判断覆盖情况
        # 而不是分开判断特征和风险
        all_combinations = set()
        for f in request_features:
            for r in request_risks:
                all_combinations.add((f, r))
        
        # 记录每个缓存能覆盖的组合
        cache_coverage = {}  # cache_record -> set of (feat, risk) combinations
        for cache_record in all_caches:
            cached_features = set(json.loads(cache_record['feature_list']))
            cached_risks = set(json.loads(cache_record['risk_list']))
            
            # 计算这个缓存能覆盖的特征+风险组合
            covered = set()
            for feat in request_features & cached_features:
                for risk in request_risks & cached_risks:
                    covered.add((feat, risk))
            
            if covered:
                cache_coverage[cache_record] = covered
        
        # 贪心选择缓存，覆盖所有组合
        covered_combinations = set()
        selected_caches = []  # [(cache_record, feat_subset, risk_subset)]
        
        while covered_combinations != all_combinations and cache_coverage:
            # 选择能覆盖最多未覆盖组合的缓存
            best_cache = None
            best_new_coverage = set()
            
            for cache_record, coverage in cache_coverage.items():
                new_coverage = coverage - covered_combinations
                if len(new_coverage) > len(best_new_coverage):
                    best_cache = cache_record
                    best_new_coverage = new_coverage
            
            if best_cache is None or len(best_new_coverage) == 0:
                break
            
            # 记录选中的缓存及其覆盖的特征和风险
            selected_caches.append(best_cache)
            covered_combinations.update(best_new_coverage)
            
            # 从候选中移除已选缓存
            del cache_coverage[best_cache]
        
        # 计算未覆盖的特征+风险组合
        uncovered_combinations = all_combinations - covered_combinations
        
        # 转换为未覆盖的特征列表和风险列表（用于实时生成）
        uncovered_features = list(set(c[0] for c in uncovered_combinations))
        uncovered_risks = list(set(c[1] for c in uncovered_combinations))
        
        # 如果全部被覆盖，合并缓存数据
        if not uncovered_combinations:
            print(f"\n{'='*60}")
            print(f"  📦 使用缓存数据（多缓存组合复用）({debug_flag})")
            print(f"  使用缓存数: {len(selected_caches)}个")
            print(f"  数据截止日期: {selected_caches[0]['data_date']}")
            print(f"{'='*60}\n")
            
            # 合并多个缓存的CSV数据
            merged_df = None
            for cache_record in selected_caches:
                csv_data = cache_record['data_csv'].replace("\\n", "\n")
                df = pd.read_csv(io.StringIO(csv_data))
                
                # 统一列名：'特征' → '特征名'
                if '特征' in df.columns and '特征名' not in df.columns:
                    df = df.rename(columns={'特征': '特征名'})
                
                # 获取该缓存覆盖的特征和风险
                cached_features = set(json.loads(cache_record['feature_list']))
                cached_risks = set(json.loads(cache_record['risk_list']))
                feat_subset = request_features & cached_features
                risk_subset = request_risks & cached_risks
                
                # 筛选该缓存覆盖的特征
                if '特征名' in df.columns:
                    df_part = df[df['特征名'].isin(feat_subset)]
                else:
                    df_part = df
                
                # 筛选该缓存覆盖的风险列
                cols_to_keep = ['特征名', '分箱序号', '特征均值', '分箱均值', '分箱值', '分箱标签', '样本量']
                # 按日期细分模式下保留时间段列
                if '时间段' in df_part.columns:
                    cols_to_keep.append('时间段')
                for risk in risk_subset:
                    if f'{risk}_风险率' in df_part.columns:
                        cols_to_keep.append(f'{risk}_风险率')
                    if f'{risk}_缺失率' in df_part.columns:
                        cols_to_keep.append(f'{risk}_缺失率')
                cols_to_keep = [c for c in cols_to_keep if c in df_part.columns]
                df_part = df_part[cols_to_keep]
                
                if merged_df is None:
                    merged_df = df_part.copy()
                else:
                    # 合并：按特征名+分箱序号合并风险列
                    existing_features = set(merged_df['特征名'].unique()) if '特征名' in merged_df.columns else set()
                    new_features = feat_subset - existing_features
                    
                    # 新特征：直接添加
                    if new_features:
                        df_new = df_part[df_part['特征名'].isin(new_features)]
                        merged_df = pd.concat([merged_df, df_new], ignore_index=True)
                    
                    # 已有特征：合并风险列
                    common_features = feat_subset & existing_features
                    if common_features:
                        for feat in common_features:
                            # 获取风险列
                            new_risk_cols = [c for c in df_part.columns if '_风险率' in c or '_缺失率' in c]
                            for col in new_risk_cols:
                                if col not in merged_df.columns:
                                    # 添加新列
                                    merged_df[col] = None
                                # 填充数据
                                feat_idx = merged_df['特征名'] == feat
                                df_feat = df_part[df_part['特征名'] == feat]
                                for _, row in df_feat.iterrows():
                                    # 按日期细分模式下，需要同时匹配分箱序号和时间段
                                    if '时间段' in merged_df.columns and '时间段' in df_feat.columns:
                                        bin_idx = (merged_df[feat_idx]['分箱序号'] == row['分箱序号']) & \
                                                  (merged_df[feat_idx]['时间段'] == row['时间段'])
                                    else:
                                        bin_idx = merged_df[feat_idx]['分箱序号'] == row['分箱序号']
                                    if bin_idx.any():
                                        merged_df.loc[feat_idx & bin_idx, col] = row[col]
            
            # 最终筛选到请求的特征和风险
            if '特征名' in merged_df.columns:
                merged_df = merged_df[merged_df['特征名'].isin(features)]
            cols_final = ['特征名', '分箱序号', '特征均值', '分箱均值', '分箱值', '分箱标签', '样本量']
            # 按日期细分模式下保留时间段列
            if '时间段' in merged_df.columns:
                cols_final.append('时间段')
            for risk in risk_metrics:
                if f'{risk}_风险率' in merged_df.columns:
                    cols_final.append(f'{risk}_风险率')
                if f'{risk}_缺失率' in merged_df.columns:
                    cols_final.append(f'{risk}_缺失率')
            cols_final = [c for c in cols_final if c in merged_df.columns]
            merged_df = merged_df[cols_final]
            
            return merged_df.to_csv(index=False), selected_caches[0]['data_date'], [], [], True, all_combinations
        
        # 部分覆盖
        if covered_combinations:
            print(f"\n{'='*60}")
            print(f"  📦 缓存部分覆盖，合并使用 ({debug_flag})")
            print(f"  缓存覆盖: {len(covered_combinations)}/{len(all_combinations)}组合")
            print(f"  需实时生成: {len(uncovered_combinations)}组合")
            print(f"{'='*60}\n")
            
            # 提取缓存数据中已覆盖的部分
            merged_df = None
            for cache_record in selected_caches:
                csv_data = cache_record['data_csv'].replace("\\n", "\n")
                df = pd.read_csv(io.StringIO(csv_data))
                
                # 统一列名
                if '特征' in df.columns and '特征名' not in df.columns:
                    df = df.rename(columns={'特征': '特征名'})
                
                cached_features = set(json.loads(cache_record['feature_list']))
                cached_risks = set(json.loads(cache_record['risk_list']))
                feat_subset = request_features & cached_features
                risk_subset = request_risks & cached_risks
                
                # 筛选该缓存覆盖的特征
                if '特征名' in df.columns:
                    df_part = df[df['特征名'].isin(feat_subset)]
                else:
                    df_part = df
                
                # 筛选该缓存覆盖的风险列
                cols_to_keep = ['特征名', '分箱序号', '特征均值', '分箱均值', '分箱值', '分箱标签', '样本量']
                # 按日期细分模式下保留时间段列
                if '时间段' in df_part.columns:
                    cols_to_keep.append('时间段')
                for risk in risk_subset:
                    if f'{risk}_风险率' in df_part.columns:
                        cols_to_keep.append(f'{risk}_风险率')
                    if f'{risk}_缺失率' in df_part.columns:
                        cols_to_keep.append(f'{risk}_缺失率')
                cols_to_keep = [c for c in cols_to_keep if c in df_part.columns]
                df_part = df_part[cols_to_keep]
                
                if merged_df is None:
                    merged_df = df_part.copy()
                else:
                    # 合并：按特征名+分箱序号合并风险列
                    existing_features = set(merged_df['特征名'].unique()) if '特征名' in merged_df.columns else set()
                    new_features = feat_subset - existing_features
                    
                    if new_features:
                        df_new = df_part[df_part['特征名'].isin(new_features)]
                        merged_df = pd.concat([merged_df, df_new], ignore_index=True)
                    
                    common_features = feat_subset & existing_features
                    if common_features:
                        for feat in common_features:
                            new_risk_cols = [c for c in df_part.columns if '_风险率' in c or '_缺失率' in c]
                            for col in new_risk_cols:
                                if col not in merged_df.columns:
                                    merged_df[col] = None
                                feat_idx = merged_df['特征名'] == feat
                                df_feat = df_part[df_part['特征名'] == feat]
                                for _, row in df_feat.iterrows():
                                    # 按日期细分模式下，需要同时匹配分箱序号和时间段
                                    if '时间段' in merged_df.columns and '时间段' in df_feat.columns:
                                        bin_idx = (merged_df[feat_idx]['分箱序号'] == row['分箱序号']) & \
                                                  (merged_df[feat_idx]['时间段'] == row['时间段'])
                                    else:
                                        bin_idx = merged_df[feat_idx]['分箱序号'] == row['分箱序号']
                                    if bin_idx.any():
                                        merged_df.loc[feat_idx & bin_idx, col] = row[col]
            
            # 返回缓存数据、未覆盖的特征和风险
            # 注意：这里返回的是缓存中已有的数据，以及需要实时生成的特征和风险
            cache_csv = merged_df.to_csv(index=False) if merged_df is not None else None
            return cache_csv, selected_caches[0]['data_date'], uncovered_features, uncovered_risks, False, covered_combinations
        
        # 完全无覆盖
        print(f"\n{'='*60}")
        print(f"  ⚡ 无匹配缓存，实时生成全部 ({debug_flag})")
        print(f"  特征: {len(features)}个，风险指标: {len(risk_metrics)}个")
        print(f"{'='*60}\n")
        
    except Exception as e:
        print(f"  ⚠️ 缓存查询失败: {e}")
    
    return None, None, features, risk_metrics, False


def get_data_max_date(odps_conn):
    """获取数据的最大日期"""
    sql = f"""
    SELECT MAX(credit_time) as max_date
    FROM {FEATURE_TABLE}
    LIMIT 1
    """
    try:
        result = odps_conn.execute_sql(sql)
        with result.open_reader() as reader:
            records = list(reader)
        if records and len(records) > 0 and records[0]['max_date']:
            return records[0]['max_date'].strftime('%Y-%m-%d')
    except Exception as e:
        print(f"  ⚠️ 获取数据日期失败: {e}")
    from datetime import datetime
    return datetime.now().strftime('%Y-%m-%d')


def save_cache(odps_conn, features, risk_metrics, mode, debug, csv_data, data_date):
    """保存结果到缓存"""
    import json
    from datetime import datetime, timedelta
    
    cache_id = generate_cache_key(features, risk_metrics, mode, debug)
    create_time = datetime.now()
    expire_time = create_time + timedelta(days=CACHE_EXPIRE_DAYS)
    debug_flag = '调试模式' if debug else '正常模式'
    
    # 转义CSV数据中的特殊字符
    csv_escaped = csv_data.replace("'", "''").replace("\n", "\\n")
    
    insert_sql = f"""
    INSERT INTO {CACHE_TABLE} 
    (cache_id, skill_version, mode, feature_list, risk_list, create_time, expire_time, data_csv, is_debug, data_date)
    VALUES 
    ('{cache_id}', '{SKILL_VERSION}', '{mode}', 
     '{json.dumps(features, ensure_ascii=False)}', 
     '{json.dumps(risk_metrics, ensure_ascii=False)}',
     CAST('{create_time.strftime('%Y-%m-%d %H:%M:%S')}' AS DATETIME),
     CAST('{expire_time.strftime('%Y-%m-%d %H:%M:%S')}' AS DATETIME),
     '{csv_escaped}', {str(debug).lower()}, '{data_date}')
    """
    try:
        odps_conn.execute_sql(insert_sql)
        print(f"\n{'='*60}")
        print(f"  💾 已保存缓存 ({debug_flag})")
        print(f"  数据截止日期: {data_date}")
        print(f"  缓存有效期至: {expire_time.strftime('%Y-%m-%d')}")
        print(f"{'='*60}\n")
    except Exception as e:
        print(f"  ⚠️ 保存缓存失败: {e}")


def detect_feature_type(odps_conn, feature):
    """检测特征类型：数值型还是分类型"""
    if any(c in feature for c in ['中文', '(', ')', ' ']):
        feature_col = f'`{feature}`'
    else:
        feature_col = feature
    
    # 先检查是否在预定义的分类变量列表中
    if feature in CATEGORICAL_FEATURES or feature.lower() in [f.lower() for f in CATEGORICAL_FEATURES]:
        return 'categorical'
    
    # 查询特征的唯一值数量
    sql = f"""
    SELECT COUNT(DISTINCT {feature_col}) as n_unique
    FROM {FEATURE_TABLE}
    WHERE {feature_col} IS NOT NULL AND {feature_col} NOT IN (-1, -2)
    LIMIT 1
    """
    try:
        result = list(odps_conn.execute_sql(sql))
        if result and len(result) > 0:
            n_unique = result[0][0]
            # 如果唯一值小于等于20，可能是分类变量
            if n_unique <= 20:
                # 再检查值是否都是字符串或整数
                sample_sql = f"""
                SELECT DISTINCT {feature_col}
                FROM {FEATURE_TABLE}
                WHERE {feature_col} IS NOT NULL AND {feature_col} NOT IN (-1, -2)
                LIMIT 20
                """
                samples = list(odps_conn.execute_sql(sample_sql))
                # 检查是否都是字符串或小整数
                is_categorical = all(
                    isinstance(s[0], str) or (isinstance(s[0], (int, float)) and -100 < s[0] < 100)
                    for s in samples if s[0] is not None
                )
                if is_categorical:
                    return 'categorical'
    except Exception as e:
        print(f"  警告：检测特征类型失败 {feature}: {e}")
    
    return 'numerical'


def build_categorical_binning_sql(feature, risk_metrics, debug=False, other_threshold=20):
    """构建分类变量的SQL分箱统计查询"""
    if any(c in feature for c in ['中文', '(', ')', ' ']):
        feature_col = f'`{feature}`'
    else:
        feature_col = feature
    
    risk_cols = []
    for risk in risk_metrics:
        risk_cols.append(f"AVG(CASE WHEN b.{risk} IN (0, 1) THEN b.{risk} ELSE NULL END) AS `{risk}_风险率`")
        risk_cols.append(f"SUM(CASE WHEN b.{risk} NOT IN (0, 1) THEN 1 ELSE 0 END) * 1.0 / COUNT(*) AS `{risk}_缺失率`")
    
    risk_str = ',\n    '.join(risk_cols)
    
    # 分类变量：先统计每个值的频数，按频数降序，超过阈值合并为【other】
    if debug:
        # 调试模式：先取50000条样本
        sql = f"""
WITH sample_data AS (
    SELECT loan_id, {feature_col} AS feature_value
    FROM {FEATURE_TABLE}
    WHERE {feature_col} IS NOT NULL AND {feature_col} NOT IN (-1, -2) AND loan_id IS NOT NULL
    LIMIT 50000
),
value_freq AS (
    SELECT feature_value, COUNT(*) as freq,
           ROW_NUMBER() OVER (ORDER BY COUNT(*) DESC) as rn
    FROM sample_data
    GROUP BY feature_value
),
binned_data AS (
    SELECT a.loan_id, a.feature_value,
           CASE WHEN v.rn <= {other_threshold} THEN CAST(a.feature_value AS STRING) ELSE '【other】' END AS 分箱值,
           CASE WHEN v.rn <= {other_threshold} THEN v.rn ELSE {other_threshold + 1} END AS 分箱序号
    FROM sample_data a
    LEFT JOIN value_freq v ON a.feature_value = v.feature_value
)
SELECT 
    '{feature}' AS 特征名,
    分箱值,
    MIN(分箱序号) AS 分箱序号,
    CAST(分箱值 AS STRING) AS 特征均值,
    COUNT(*) AS 样本量,
    {risk_str}
FROM binned_data a
LEFT JOIN {LABEL_TABLE} b ON a.loan_id = b.loan_id
GROUP BY 分箱值
ORDER BY MIN(分箱序号)
"""
    else:
        sql = f"""
WITH value_freq AS (
    SELECT {feature_col} AS feature_value, COUNT(*) as freq,
           ROW_NUMBER() OVER (ORDER BY COUNT(*) DESC) as rn
    FROM {FEATURE_TABLE}
    WHERE {feature_col} IS NOT NULL AND {feature_col} NOT IN (-1, -2) AND loan_id IS NOT NULL
    GROUP BY {feature_col}
),
binned_data AS (
    SELECT a.loan_id, a.{feature_col} AS feature_value,
           CASE WHEN v.rn <= {other_threshold} THEN CAST(a.{feature_col} AS STRING) ELSE '【other】' END AS 分箱值,
           CASE WHEN v.rn <= {other_threshold} THEN v.rn ELSE {other_threshold + 1} END AS 分箱序号
    FROM {FEATURE_TABLE} a
    LEFT JOIN value_freq v ON a.{feature_col} = v.feature_value
    WHERE a.{feature_col} IS NOT NULL AND a.{feature_col} NOT IN (-1, -2) AND a.loan_id IS NOT NULL
)
SELECT 
    '{feature}' AS 特征名,
    分箱值,
    MIN(分箱序号) AS 分箱序号,
    CAST(分箱值 AS STRING) AS 特征均值,
    COUNT(*) AS 样本量,
    {risk_str}
FROM binned_data a
LEFT JOIN {LABEL_TABLE} b ON a.loan_id = b.loan_id
GROUP BY 分箱值
ORDER BY MIN(分箱序号)
"""
    return sql


def build_binning_sql(feature, risk_metrics, n_bins=10, debug=False, feature_type='numerical'):
    """构建SQL分箱统计查询"""
    # 分类变量：直接调用分类变量SQL
    if feature_type == 'categorical':
        return build_categorical_binning_sql(feature, risk_metrics, debug=debug)
    
    # 数值变量：等频分箱
    if any(c in feature for c in ['中文', '(', ')', ' ']):
        feature_col = f'`{feature}`'
    else:
        feature_col = feature
    
    risk_cols = []
    for risk in risk_metrics:
        risk_cols.append(f"AVG(CASE WHEN b.{risk} IN (0, 1) THEN b.{risk} ELSE NULL END) AS `{risk}_风险率`")
        risk_cols.append(f"SUM(CASE WHEN b.{risk} NOT IN (0, 1) THEN 1 ELSE 0 END) * 1.0 / COUNT(*) AS `{risk}_缺失率`")
    
    risk_str = ',\n    '.join(risk_cols)
    
    # 调试模式：LIMIT放在子查询内部，先用子查询限制数据量再分箱
    if debug:
        sql = f"""
SELECT 
    '{feature}' AS 特征名,
    ntile AS 分箱序号,
    CAST(ntile AS STRING) AS 分箱值,
    AVG(a.{feature_col}) AS 特征均值,
    COUNT(*) AS 样本量,
    {risk_str}
FROM (
    SELECT loan_id, {feature_col}, NTILE({n_bins}) OVER (ORDER BY {feature_col}) AS ntile
    FROM (
        SELECT loan_id, {feature_col}
        FROM {FEATURE_TABLE}
        WHERE {feature_col} IS NOT NULL AND {feature_col} NOT IN (-1, -2) AND loan_id IS NOT NULL
        LIMIT 50000
    ) tmp
) a
LEFT JOIN {LABEL_TABLE} b ON a.loan_id = b.loan_id
GROUP BY ntile ORDER BY ntile
"""
    else:
        sql = f"""
SELECT 
    '{feature}' AS 特征名,
    ntile AS 分箱序号,
    CAST(ntile AS STRING) AS 分箱值,
    AVG(a.{feature_col}) AS 特征均值,
    COUNT(*) AS 样本量,
    {risk_str}
FROM (
    SELECT loan_id, {feature_col}, NTILE({n_bins}) OVER (ORDER BY {feature_col}) AS ntile
    FROM {FEATURE_TABLE}
    WHERE {feature_col} IS NOT NULL AND {feature_col} NOT IN (-1, -2) AND loan_id IS NOT NULL
) a
LEFT JOIN {LABEL_TABLE} b ON a.loan_id = b.loan_id
GROUP BY ntile ORDER BY ntile
"""
    return sql


def build_binning_by_date_sql(feature, risk_metrics, n_bins=10, debug=False, mode='monthly', feature_type='numerical'):
    """构建按日期细分的SQL分箱统计查询（支持分类变量）"""
    if any(c in feature for c in ['中文', '(', ')', ' ']):
        feature_col = f'`{feature}`'
    else:
        feature_col = feature
    
    # 使用列名而非别名引用
    if mode == 'quarterly':
        time_expr = "CONCAT(YEAR(credit_time), '-Q', QUARTER(credit_time))"
        time_alias = "CONCAT(YEAR(a.credit_time), '-Q', QUARTER(a.credit_time))"
    else:
        time_expr = "TO_CHAR(credit_time, 'YYYY-MM')"
        time_alias = "TO_CHAR(a.credit_time, 'YYYY-MM')"
    
    risk_cols = []
    for risk in risk_metrics:
        risk_cols.append(f"AVG(CASE WHEN b.{risk} IN (0, 1) THEN b.{risk} ELSE NULL END) AS `{risk}_风险率`")
        risk_cols.append(f"SUM(CASE WHEN b.{risk} NOT IN (0, 1) THEN 1 ELSE 0 END) * 1.0 / COUNT(*) AS `{risk}_缺失率`")
    
    risk_str = ',\n    '.join(risk_cols)
    
    # 分类变量：按唯一值分箱
    if feature_type == 'categorical':
        if debug:
            sql = f"""
WITH sample_data AS (
    SELECT loan_id, credit_time, {feature_col} AS feature_value
    FROM {FEATURE_TABLE}
    WHERE {feature_col} IS NOT NULL AND {feature_col} NOT IN (-1, -2) AND credit_time IS NOT NULL AND loan_id IS NOT NULL
    LIMIT 50000
),
value_freq AS (
    SELECT feature_value, COUNT(*) as freq,
           ROW_NUMBER() OVER (ORDER BY COUNT(*) DESC) as rn
    FROM sample_data
    GROUP BY feature_value
),
binned_data AS (
    SELECT a.loan_id, a.credit_time, a.feature_value,
           CASE WHEN v.rn <= 20 THEN CAST(a.feature_value AS STRING) ELSE '【other】' END AS 分箱标签,
           CASE WHEN v.rn <= 20 THEN v.rn ELSE 21 END AS 分箱序号
    FROM sample_data a
    LEFT JOIN value_freq v ON a.feature_value = v.feature_value
)
SELECT 
    '{feature}' AS 特征名,
    {time_alias} AS 时间段,
    分箱标签,
    MIN(分箱序号) AS 分箱序号,
    CAST(分箱标签 AS STRING) AS 特征均值,
    COUNT(*) AS 样本量,
    {risk_str}
FROM binned_data a
LEFT JOIN {LABEL_TABLE} b ON a.loan_id = b.loan_id
GROUP BY {time_alias}, 分箱标签
ORDER BY 时间段, MIN(分箱序号)
"""
        else:
            sql = f"""
WITH value_freq AS (
    SELECT {feature_col} AS feature_value, COUNT(*) as freq,
           ROW_NUMBER() OVER (ORDER BY COUNT(*) DESC) as rn
    FROM {FEATURE_TABLE}
    WHERE {feature_col} IS NOT NULL AND {feature_col} NOT IN (-1, -2) AND loan_id IS NOT NULL
    GROUP BY {feature_col}
),
binned_data AS (
    SELECT a.loan_id, a.credit_time, a.{feature_col} AS feature_value,
           CASE WHEN v.rn <= 20 THEN CAST(a.{feature_col} AS STRING) ELSE '【other】' END AS 分箱标签,
           CASE WHEN v.rn <= 20 THEN v.rn ELSE 21 END AS 分箱序号
    FROM {FEATURE_TABLE} a
    LEFT JOIN value_freq v ON a.{feature_col} = v.feature_value
    WHERE a.{feature_col} IS NOT NULL AND a.{feature_col} NOT IN (-1, -2) AND a.credit_time IS NOT NULL AND a.loan_id IS NOT NULL
)
SELECT 
    '{feature}' AS 特征名,
    {time_alias} AS 时间段,
    分箱标签,
    MIN(分箱序号) AS 分箱序号,
    CAST(分箱标签 AS STRING) AS 特征均值,
    COUNT(*) AS 样本量,
    {risk_str}
FROM binned_data a
LEFT JOIN {LABEL_TABLE} b ON a.loan_id = b.loan_id
GROUP BY {time_alias}, 分箱标签
ORDER BY 时间段, MIN(分箱序号)
"""
        return sql
    
    # 数值变量：等频分箱
    if debug:
        sql = f"""
SELECT 
    '{feature}' AS 特征名,
    {time_alias} AS 时间段,
    ntile AS 分箱序号,
    CAST(ntile AS STRING) AS 分箱标签,
    AVG(a.{feature_col}) AS 特征均值,
    COUNT(*) AS 样本量,
    {risk_str}
FROM (
    SELECT loan_id, credit_time, {feature_col},
           NTILE({n_bins}) OVER (PARTITION BY {time_expr} ORDER BY {feature_col}) AS ntile
    FROM (
        SELECT loan_id, credit_time, {feature_col}
        FROM {FEATURE_TABLE}
        WHERE {feature_col} IS NOT NULL AND {feature_col} NOT IN (-1, -2) AND credit_time IS NOT NULL AND loan_id IS NOT NULL
        LIMIT 50000
    ) tmp
) a
LEFT JOIN {LABEL_TABLE} b ON a.loan_id = b.loan_id
GROUP BY {time_alias}, ntile ORDER BY 时间段, ntile
"""
    else:
        sql = f"""
SELECT 
    '{feature}' AS 特征名,
    {time_alias} AS 时间段,
    ntile AS 分箱序号,
    CAST(ntile AS STRING) AS 分箱标签,
    AVG(a.{feature_col}) AS 特征均值,
    COUNT(*) AS 样本量,
    {risk_str}
FROM (
    SELECT loan_id, credit_time, {feature_col},
           NTILE({n_bins}) OVER (PARTITION BY {time_expr} ORDER BY {feature_col}) AS ntile
    FROM {FEATURE_TABLE}
    WHERE {feature_col} IS NOT NULL AND {feature_col} NOT IN (-1, -2) AND credit_time IS NOT NULL AND loan_id IS NOT NULL
) a
LEFT JOIN {LABEL_TABLE} b ON a.loan_id = b.loan_id
GROUP BY {time_alias}, ntile ORDER BY 时间段, ntile
"""
    return sql


def export_binned_data(features, risk_metrics, output_dir, n_bins=10, debug=False, mode='normal'):
    """执行SQL分箱统计查询（支持缓存）
    
    自动判断规则：当mode='monthly'时，如果月份数>8，自动切换为quarterly
    """
    o = ODPS(DB_CONFIG['access_id'], DB_CONFIG['secret_access_key'],
             project=DB_CONFIG['project'], endpoint=DB_CONFIG['endpoint'])
    
    # 自动判断：月份数>8时切换为季度
    if mode == 'monthly':
        # 查询月份数量（MaxCompute使用TO_CHAR格式化日期）
        count_sql = f"""
        SELECT COUNT(DISTINCT TO_CHAR(credit_time, 'YYYY-MM')) as month_count
        FROM {FEATURE_TABLE}
        """
        try:
            result = o.execute_sql(count_sql)
            with result.open_reader() as reader:
                records = list(reader)
            if records and len(records) > 0:
                month_count = records[0]['month_count']
                if month_count > 8:
                    print(f"  ℹ️ 月份数量({month_count})>8，自动切换为按季度细分")
                    mode = 'quarterly'
        except Exception as e:
            print(f"  ⚠️ 无法获取月份数量: {e}，继续使用月度细分")
    
    mode_str = "调试模式（LIMIT 50000）" if debug else "正常模式"
    if mode != 'normal':
        mode_str += f" - 按{'月' if mode == 'monthly' else '季度'}细分"
    
    print(f"\n{'='*60}")
    print(f"执行SQL分箱统计（{mode_str}）")
    print(f"特征数量: {len(features)}, 风险指标数量: {len(risk_metrics)}, 分箱数量: {n_bins}")
    print(f"{'='*60}")
    
    # 确保缓存表存在
    create_cache_table(o)
    
    # 智能缓存检查
    cached_csv, data_date, uncovered_features, uncovered_risks, is_full_coverage, covered_combinations = check_cache(
        o, features, risk_metrics, mode, debug)
    
    if cached_csv and is_full_coverage:
        # 完全覆盖，直接使用缓存数据
        print("  📦 从缓存加载数据...")
        import io
        result_df = pd.read_csv(io.StringIO(cached_csv.replace('\\n', '\n')))
        
        # 保存到本地
        output_file = os.path.join(output_dir, '分箱统计结果.csv')
        result_df.to_csv(output_file, index=False, encoding='utf-8-sig')
        print(f"  ✓ 保存: {output_file} ({len(result_df)} 行)")
        
        # 即使完全使用缓存，也要生成缓存使用汇总和SQL文件
        _generate_cache_summary(output_dir, features, risk_metrics, covered_combinations, data_date)
        
        # 保存一个说明性的SQL文件
        sql_file = os.path.join(output_dir, 'analysis_queries.sql')
        with open(sql_file, 'w', encoding='utf-8') as f:
            f.write(f"-- 数据来源: 缓存复用 (版本 {get_version_prefix()}.x)\n")
            f.write(f"-- 数据截止日期: {data_date}\n")
            f.write(f"-- 特征: {', '.join(features)}\n")
            f.write(f"-- 风险指标: {', '.join(risk_metrics)}\n")
        print(f"  ✓ 保存SQL: {sql_file}")
        
        return result_df, data_date
    
    # 保存部分覆盖时的缓存数据（用于后续合并）
    partial_cache_df = None
    if cached_csv and not is_full_coverage:
        # 部分覆盖，保存缓存数据用于后续合并
        import io
        partial_cache_df = pd.read_csv(io.StringIO(cached_csv.replace('\\n', '\n')))
        if '特征' in partial_cache_df.columns and '特征名' not in partial_cache_df.columns:
            partial_cache_df = partial_cache_df.rename(columns={'特征': '特征名'})
        print(f"  📦 已加载缓存数据（{len(partial_cache_df)} 行），等待合并...")
    
    # 确定需要实时生成的特征和风险
    features_to_generate = uncovered_features if uncovered_features else features
    risks_to_generate = uncovered_risks if uncovered_risks else risk_metrics
    
    if uncovered_features or uncovered_risks:
        print(f"  ⚡ 部分数据需实时生成...")
        print(f"     需生成特征: {len(features_to_generate)}/{len(features)}")
        print(f"     需生成风险: {len(risks_to_generate)}/{len(risk_metrics)}")
    else:
        print("  ⚡ 实时生成全部统计数据...")
    
    # 获取数据截止日期
    data_date = get_data_max_date(o)
    print(f"  数据截止日期: {data_date}")
    
    # 只检测需要生成的特征类型
    print(f"\n=== 检测特征类型 ===")
    feature_types = {}
    for feature in features_to_generate:
        ftype = detect_feature_type(o, feature)
        feature_types[feature] = ftype
        print(f"  {feature}: {ftype}")
    
    all_results = []
    sql_list = []
    
    # 只生成需要实时计算的特征
    for i, feature in enumerate(features_to_generate):
        print(f"  处理特征 {i+1}/{len(features_to_generate)}: {feature} ({feature_types[feature]})")
        
        if mode == 'normal':
            sql = build_binning_sql(feature, risks_to_generate, n_bins, debug, feature_types[feature])
        else:
            sql = build_binning_by_date_sql(feature, risks_to_generate, n_bins, debug, mode, feature_types[feature])
        
        sql_list.append(f"-- {feature}\n{sql}")
        
        try:
            instance = o.execute_sql(sql)
            instance.wait_for_success()
            
            with instance.open_reader() as reader:
                records = list(reader)
            
            if len(records) > 0:
                # 兼容新旧ODPS SDK: 获取列名
                if hasattr(reader, '_columns'):
                    columns = reader._columns
                elif hasattr(reader, 'schema') and hasattr(reader.schema, 'names'):
                    columns = reader.schema.names
                else:
                    columns = None
                
                # 兼容新旧ODPS SDK: record可能是dict或有values属性
                first_record = records[0]
                if hasattr(first_record, 'values') and callable(getattr(first_record, 'values')):
                    data = [list(r.values()) for r in records]
                elif hasattr(first_record, 'values'):
                    data = [list(r.values) for r in records]
                elif hasattr(first_record, '_values'):
                    data = [list(r._values) for r in records]
                else:
                    # 尝试作为元组/列表处理
                    data = [list(r) if isinstance(r, (tuple, list)) else list(r.__dict__.values()) for r in records]
                    if columns is None:
                        columns = [f'col_{i}' for i in range(len(data[0]))]
                
                df = pd.DataFrame(data, columns=columns)
                all_results.append(df)
                print(f"    ✓ 获取 {len(df)} 行")
        except Exception as e:
            print(f"    ⚠️ 失败: {e}")
    
    if all_results:
        result_df = pd.concat(all_results, ignore_index=True)
        
        # 如果是部分覆盖，需要合并缓存数据
        if partial_cache_df is not None and len(partial_cache_df) > 0:
            print(f"\n=== 合并缓存数据 ===")
            
            # 统一列名
            if '特征' in result_df.columns and '特征名' not in result_df.columns:
                result_df = result_df.rename(columns={'特征': '特征名'})
            
            # 合并缓存数据和实时生成数据
            # 按特征名分组，每个特征单独处理
            final_dfs = []
            
            # 获取缓存数据中的特征
            cache_features = set(partial_cache_df['特征名'].unique()) if '特征名' in partial_cache_df.columns else set()
            result_features = set(result_df['特征名'].unique()) if '特征名' in result_df.columns else set()
            
            # 特征在缓存中有数据：需要合并缓存的风险列
            for feat in cache_features:
                # 该特征在缓存中的数据
                cache_feat_df = partial_cache_df[partial_cache_df['特征名'] == feat].copy()
                # 该特征在实时生成数据中的数据
                result_feat_df = result_df[result_df['特征名'] == feat].copy() if feat in result_features else None
                
                if result_feat_df is not None and len(result_feat_df) > 0:
                    # 合并：实时生成数据 + 缓存风险列
                    merge_keys = ['特征名', '分箱序号']
                    # 按日期细分模式下，需要包含时间段作为合并键
                    if '时间段' in result_feat_df.columns and '时间段' in cache_feat_df.columns:
                        merge_keys.append('时间段')
                    
                    cache_risk_cols = [c for c in cache_feat_df.columns if '_风险率' in c or '_缺失率' in c]
                    
                    # 只合并缓存独有的风险列
                    cache_only_risk_cols = [c for c in cache_risk_cols if c not in result_feat_df.columns]
                    if cache_only_risk_cols:
                        cols_to_merge = merge_keys + cache_only_risk_cols
                        cache_subset = cache_feat_df[cols_to_merge].drop_duplicates()
                        result_feat_df = result_feat_df.merge(cache_subset, on=merge_keys, how='left')
                    
                    final_dfs.append(result_feat_df)
                else:
                    # 该特征只在缓存中有数据，直接使用缓存
                    final_dfs.append(cache_feat_df)
            
            # 特征只在实时生成数据中有（不在缓存中）
            for feat in result_features - cache_features:
                result_feat_df = result_df[result_df['特征名'] == feat].copy()
                final_dfs.append(result_feat_df)
            
            # 合并所有
            if final_dfs:
                result_df = pd.concat(final_dfs, ignore_index=True)
                print(f"  ✓ 最终数据: {len(result_df)} 行")
        
        output_file = os.path.join(output_dir, '分箱统计结果.csv')
        result_df.to_csv(output_file, index=False, encoding='utf-8-sig')
        print(f"\n  ✓ 保存: {output_file} ({len(result_df)} 行)")
        
        sql_file = os.path.join(output_dir, 'analysis_queries.sql')
        with open(sql_file, 'w', encoding='utf-8') as f:
            f.write('\n\n'.join(sql_list))
        print(f"  ✓ 保存SQL: {sql_file}")
        
        # 生成缓存使用汇总
        _generate_cache_summary(output_dir, features, risk_metrics, covered_combinations, data_date)
        
        # 保存到缓存（保存原始请求的全部特征和风险）
        csv_data = result_df.to_csv(index=False, encoding='utf-8-sig')
        save_cache(o, features, risk_metrics, mode, debug, csv_data, data_date)
        
        return result_df, data_date
    return pd.DataFrame()


def _generate_cache_summary(output_dir, features, risk_metrics, covered_combinations, data_date):
    """生成缓存使用汇总表
    
    Args:
        output_dir: 输出目录
        features: 特征列表
        risk_metrics: 风险指标列表
        covered_combinations: 已缓存的(特征, 风险)组合集合
        data_date: 数据截止日期
    """
    import json
    
    summary_rows = []
    for feat in features:
        for risk in risk_metrics:
            # 根据组合判断是否缓存
            is_cached = (feat, risk) in covered_combinations
            summary_rows.append({
                '特征': feat,
                '风险指标': risk,
                '数据来源': '缓存' if is_cached else '实时生成',
                '数据截止日期': data_date
            })
    
    summary_df = pd.DataFrame(summary_rows)
    
    # 保存汇总表
    summary_file = os.path.join(output_dir, '缓存使用汇总.csv')
    summary_df.to_csv(summary_file, index=False, encoding='utf-8-sig')
    
    # 打印统计
    cache_count = len(summary_df[summary_df['数据来源'] == '缓存'])
    gen_count = len(summary_df[summary_df['数据来源'] == '实时生成'])
    total = len(summary_rows)
    
    print(f"\n=== 缓存使用汇总 ===")
    print(f"  总组合数: {total}")
    print(f"  缓存覆盖: {cache_count} ({cache_count/total*100:.1f}%)")
    print(f"  实时生成: {gen_count} ({gen_count/total*100:.1f}%)")
    print(f"  ✓ 汇总表已保存: {summary_file}")
    
    # 提取缓存和实时生成的特征/风险
    cached_features = sorted(list(set(row['特征'] for row in summary_rows if row['数据来源'] == '缓存')))
    generated_features = sorted(list(set(row['特征'] for row in summary_rows if row['数据来源'] == '实时生成')))
    cached_risks = sorted(list(set(row['风险指标'] for row in summary_rows if row['数据来源'] == '缓存')))
    generated_risks = sorted(list(set(row['风险指标'] for row in summary_rows if row['数据来源'] == '实时生成')))
    
    # 保存统计JSON
    stats = {
        '总组合数': total,
        '缓存覆盖': cache_count,
        '实时生成': gen_count,
        '缓存命中率': f"{cache_count/total*100:.1f}%",
        '数据截止日期': data_date,
        '缓存特征': cached_features,
        '实时生成特征': generated_features,
        '缓存风险': cached_risks,
        '实时生成风险': generated_risks
    }
    
    stats_file = os.path.join(output_dir, '缓存统计.json')
    with open(stats_file, 'w', encoding='utf-8') as f:
        json.dump(stats, f, ensure_ascii=False, indent=2)
    print(f"  ✓ 统计文件已保存: {stats_file}")


def main():
    parser = argparse.ArgumentParser(description='2D分析 - SQL分箱统计导出')
    parser.add_argument('--output_dir', type=str, required=True)
    parser.add_argument('--features', type=str, required=True)
    parser.add_argument('--risks', type=str, required=True)
    parser.add_argument('--n_bins', type=int, default=10)
    parser.add_argument('--debug', action='store_true')
    parser.add_argument('--mode', type=str, default='normal', choices=['normal', 'monthly', 'quarterly'])
    
    args = parser.parse_args()
    features = [f.strip() for f in args.features.split(',')]
    risk_metrics = [r.strip() for r in args.risks.split(',')]
    
    print("="*60)
    print("2D分析 - SQL分箱统计导出")
    print("="*60)
    print(f"模式: {'调试模式' if args.debug else '正常模式'}{' - 按'+('月' if args.mode == 'monthly' else '季度')+'细分' if args.mode != 'normal' else ''}")
    
    os.makedirs(args.output_dir, exist_ok=True)
    result_df, data_date = export_binned_data(features, risk_metrics, args.output_dir, args.n_bins, args.debug, args.mode)
    
    # 保存数据截止日期到文件
    if data_date:
        date_file = os.path.join(args.output_dir, 'data_date.txt')
        with open(date_file, 'w', encoding='utf-8') as f:
            f.write(data_date)
        print(f"  ✓ 数据截止日期: {data_date}")
    
    print("\n" + "="*60)
    print("完成！")
    print("="*60)


if __name__ == "__main__":
    main()
