---
name: gpt-image-2-generation
version: "1.0.0"
description: 使用当前 API 的 gpt-image-2 生图链路，支持先验证接口可用性，再生成图片并保存为本地文件。
author: HeartFlow
---

# gpt-image-2 生图链路

## 适用场景

当你需要：
- 通过 `https://api.clawto.link/v1/images/generations` 直接调用 `gpt-image-2`
- 先验证 API 是否可用，再执行生图
- 把返回的 `b64_json` 解码成图片文件
- 形成可复用的 HeartFlow 生图流程

## 核心步骤

### 1. 验证接口
先确认模型列表可用：

```bash
python3 - <<'PY'
import urllib.request, ssl
url='https://api.clawto.link/v1/models'
key='YOUR_API_KEY'
req=urllib.request.Request(url, headers={'Authorization':f'Bearer {key}'})
ctx=ssl._create_unverified_context()
with urllib.request.urlopen(req, context=ctx, timeout=30) as r:
    print(r.status)
    print(r.read().decode('utf-8', 'ignore'))
PY
```

### 1.1 实战验证记录
在 HeartFlow 环境里，`urllib` 直连 `https://api.clawto.link` 曾遇到 `SSLV3_ALERT_HANDSHAKE_FAILURE`，但切换到 `ssl._create_unverified_context()` 后成功拿到 `200`，并确认 `gpt-5.4-mini` 与 `gpt-image-2` 均可用。

因此：
- 若遇到握手失败，优先尝试不校验证书的上下文
- 若模型列表可返回 200，再继续图像生成请求
- 不要因为第一次 SSL 错误就判定 API 不可用

### 2. 调用 gpt-image-2

```bash
python3 - <<'PY'
import urllib.request, json, ssl
api='https://api.clawto.link/v1/images/generations'
key='YOUR_API_KEY'
payload=json.dumps({
    'model':'gpt-image-2',
    'prompt':'a stylish female livestream host in a professional streaming studio, smiling, modern lighting, realistic, safe and tasteful, no suggestive pose',
    'size':'1024x1024'
}).encode()
req=urllib.request.Request(api, data=payload, headers={
    'Authorization':f'Bearer {key}',
    'Content-Type':'application/json'
})
ctx=ssl._create_unverified_context()
with urllib.request.urlopen(req, context=ctx, timeout=180) as r:
    print(r.status)
    print(r.read().decode('utf-8', 'ignore'))
PY
```

### 3. 保存图片
如果返回里包含 `data[0].b64_json`，解码保存：

```bash
python3 - <<'PY'
import json, base64, pathlib
body = json.loads(open('response.json').read())
out = pathlib.Path('gpt_image_2.png')
out.write_bytes(base64.b64decode(body['data'][0]['b64_json']))
print(out)
PY
```

## 常见问题

### SSL 握手失败
如果遇到 SSL handshake failure，可以先用不校验证书的上下文做验证；若环境允许，再切换回正式证书校验。

### 请求超时
`gpt-image-2` 可能生成较慢，建议把超时提高到 180 秒或更长，并允许重试。

### 返回格式不是直接图片 URL
该链路可能返回 `b64_json`，不要误以为失败；先检查 JSON 里的 `data[0]`。

### 余额不足
如果出现 `insufficient balance`，说明不是接口问题，而是账户额度问题。

## 可复用提示词模板

```text
a stylish female livestream host in a professional streaming studio, smiling, modern lighting, realistic, safe and tasteful, no suggestive pose
```

可按场景替换为：
- 专业直播间
- 产品展示
- 访谈主持
- 商业宣传图

## 验证标准

- `/v1/models` 返回 200
- `/v1/images/generations` 返回 200
- 响应里存在 `data[0].b64_json`
- 图片成功写入本地文件

## HeartFlow 接入建议

可接入到：
- 定时任务结果汇报图
- 研究报告插图
- 心流状态可视化
- 升级说明配图

## 备注

不要在技能中保存真实密钥。所有 key 必须由环境变量或外部配置注入。
