#!/usr/bin/env python3
"""
钉钉表格推送模块 - 供 sync.py 导入使用，也可独立运行。

用法（独立）:
  python push_dingtalk.py reset  # 重置全true
  python push_dingtalk.py update  # 推送真实数据
  python push_dingtalk.py verify  # 验证结果
"""
import json, requests, sys, io
from pathlib import Path
from typing import List, Dict, Any, Optional

# UTF-8 输出
if hasattr(sys, 'stdout'):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

# ── 配置（由调用者传入或从 config.json 读取）─────────────────
SKILL_DIR = Path(__file__).parent.resolve()
MCP_URL = "https://mcp-gw.dingtalk.com/server/73ba964f5fc66d46a3c0499789a7aa330a47243c0fddb41ae2af1e5a2e1ae09d?key=abb1ef3e57855ca2a4716c690cc48da0"
ACCESS_TOKEN = ""  # 由调用者设置
NODE_ID = "QOG9lyrgJP3AZLd9fzKEjXA5VzN67Mw4"
SHEET_ID = "小九"
CACHE_FILE = SKILL_DIR / "table_ids_cache.json"


def set_token(token: str):
    global ACCESS_TOKEN
    ACCESS_TOKEN = token


def mcp_raw(tool_name: str, arguments: dict) -> dict:
    """直接发 JSON-RPC 请求到 MCP 端点"""
    payload = {
        "jsonrpc": "2.0", "method": "tools/call",
        "params": {"name": tool_name, "arguments": arguments}, "id": 1,
    }
    headers = {
        "Content-Type": "application/json", "Accept": "application/json",
        "Authorization": "Bearer " + ACCESS_TOKEN,
    }
    resp = requests.post(MCP_URL, json=payload, headers=headers, timeout=60)
    resp.raise_for_status()
    result = resp.json()
    if "error" in result:
        raise Exception(f"MCP error: {result['error']}")
    content = result.get("result", {}).get("content", [])
    if content:
        return json.loads(content[0].get("text", "{}"))
    return result.get("result", {})


def push_batch(range_addr: str, values: List[List[str]],
               phase: str, idx: int) -> bool:
    """推送单批，返回是否成功"""
    print(f"  [{phase}] 批次{idx+1}: {range_addr} ({len(values)}行)")
    result = mcp_raw("update_range", {
        "nodeId": NODE_ID, "sheetId": SHEET_ID,
        "rangeAddress": range_addr, "values": values, "format": "plain_text"
    })
    if result.get("success"):
        print(f"    OK")
        return True
    else:
        print(f"    FAIL: {result.get('errorMessage', result)}")
        return False


def push_batches(batches: List[Dict[str, Any]], phase: str = "update") -> bool:
    """推送所有批次，增量模式下自动跳过无变化的行"""
    print(f"\n[推送] {phase} {len(batches)} 批")
    ok_count = 0
    for i, b in enumerate(batches):
        vals = b.get("values", [])
        # 增量：整批都是 true 跳过（reset时）
        if phase == "reset" and all(v == ["true"] * len(v[0]) if vals else True for v in vals):
            print(f"  [跳过] 批次{i+1}: 全true无变化")
            continue
        if not push_batch(b["rangeAddress"], vals, phase, i):
            print(f"  批次{i+1}失败，停止")
            return False
        ok_count += 1
    print(f"  推送完成：{ok_count} 批")
    return True


def read_range(range_addr: str) -> List[List[str]]:
    """读取钉钉表格指定范围"""
    result = mcp_raw("get_range", {
        "nodeId": NODE_ID, "sheetId": SHEET_ID, "range": range_addr
    })
    return result.get("values", [])


def read_table_ids_via_mcp() -> List[str]:
    """通过 MCP 读取钉钉表格 A 列（用户ID）"""
    print("[缓存] 通过 MCP 读取钉钉表格 A 列...")
    rows = read_range("A2:A500")  # 读大一点避免漏
    ids = []
    for row in rows:
        if row and str(row[0]).strip().isdigit():
            ids.append(str(row[0]).strip())
    print(f"[缓存] 读取到 {len(ids)} 个用户ID")
    return ids


def load_cached_ids() -> Optional[List[str]]:
    """尝试从本地缓存加载 ID"""
    if not CACHE_FILE.exists():
        return None
    try:
        data = json.loads(CACHE_FILE.read_text(encoding="utf-8"))
        ids = data.get("ids", [])
        if ids:
            print(f"[缓存] 从 {CACHE_FILE.name} 加载 {len(ids)} 个ID")
            return ids
    except Exception:
        pass
    return None


def save_ids_cache(ids: List[str]):
    """保存 ID 到本地缓存"""
    data = {"ids": ids, "cached_at": "2026-05-04", "count": len(ids)}
    CACHE_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[缓存] 已保存 {len(ids)} 个ID到 {CACHE_FILE.name}")


def get_table_ids(force_refresh: bool = False) -> List[str]:
    """获取钉钉表格的ID列表（优先缓存）"""
    if not force_refresh:
        cached = load_cached_ids()
        if cached:
            return cached
    # 无缓存或强制刷新
    ids = read_table_ids_via_mcp()
    if ids:
        save_ids_cache(ids)
    return ids


def incremental_diff(
    new_values: List[List[str]],
    range_addr: str
) -> List[List[str]]:
    """
    增量对比：只返回与钉钉表格当前值不同的行。
    返回 None 表示整批无变化（跳过）。
    """
    current = read_range(range_addr)
    new_by_row = {i: v for i, v in enumerate(new_values)}

    changed = []
    changed_rows = []
    for i in range(min(len(current), len(new_values))):
        if str(current[i][0]).lower() != str(new_values[i][0]).lower() or \
           str(current[i][1]).lower() != str(new_values[i][1]).lower():
            changed.append(new_values[i])
            changed_rows.append(i + 2)  # 行号从2开始

    if not changed:
        return None  # 无变化

    # 找到连续变化区间，合并成更小的批次
    print(f"    增量：{len(changed)}/{len(new_values)} 行有变化")
    return changed


def rebuild_batches_for_changed(
    changed_vals: List[List[str]],
    orig_range: str,
    data_start: int = 2
) -> List[Dict[str, Any]]:
    """根据实际变化的行，重新生成最小批次"""
    if not changed_vals:
        return []

    # 从原range提取列信息
    import re
    m = re.match(r'([A-Z]+)(\d+):([A-Z]+)(\d+)', orig_range)
    if not m:
        return [{"rangeAddress": orig_range, "values": changed_vals}]
    first_col, last_col = m.group(1), m.group(3)

    # 计算变化的行号
    changed_ids = []
    current = read_range(orig_range)
    for i in range(min(len(current), len(changed_vals))):
        if str(current[i][0]).lower() != str(changed_vals[i][0]).lower() or \
           str(current[i][1]).lower() != str(changed_vals[i][1]).lower():
            changed_ids.append(data_start + i)

    if not changed_ids:
        return []

    # 合并连续行号区间
    batches = []
    batch_size = 50
    i = 0
    while i < len(changed_ids):
        # 找连续区间
        start_id = changed_ids[i]
        end_id = start_id
        j = i
        while j < len(changed_ids) - 1 and changed_ids[j+1] == changed_ids[j] + 1:
            j += 1
        end_id = changed_ids[j]
        count = end_id - start_id + 1

        # 如果连续区间超过批次大小，拆分
        if count > batch_size:
            # 先推满50
            chunk_end = start_id + batch_size - 1
            vals = []
            for rid in range(start_id, chunk_end + 1):
                ridx = rid - data_start
                if ridx < len(changed_vals):
                    vals.append(changed_vals[ridx - changed_ids[0] + (rid - start_id)])
            # 简化：直接取对应范围的值
            pass  # 复杂了，先不做区间拆分

        vals_for_range = changed_vals[i:j+1]
        batches.append({
            "rangeAddress": f"{first_col}{start_id}:{last_col}{end_id}",
            "values": vals_for_range
        })
        i = j + 1

    return batches


# ── 独立运行入口 ─────────────────────────────────────────────
if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python push_dingtalk.py reset|update|verify [--incremental]")
        sys.exit(1)

    phase = sys.argv[1]
    incremental = "--incremental" in sys.argv

    # 加载 config 读 token
    config_path = SKILL_DIR / "config.json"
    if config_path.exists():
        cfg = json.loads(config_path.read_text(encoding="utf-8"))
        mcp_cfg = cfg.get("mcp", {})
        if mcp_cfg.get("url") and mcp_cfg.get("auth_token"):
            # 优先用 config 中的 token
            set_token(mcp_cfg["auth_token"])
            print(f"[配置] 使用 config.json 中的 token")

    # 独立运行必须有 token，这里检查
    if not ACCESS_TOKEN:
        print("[错误] 未配置 ACCESS_TOKEN，请通过 connect_cloud_service 获取")
        sys.exit(1)

    if phase == "verify":
        print("[验证] 读取 AW1:AV5 ...")
        result = read_range("AW1:AV5")
        for i, row in enumerate(result):
            print(f"  行{i+1}: {row}")
        sys.exit(0)

    batch_file = SKILL_DIR / f"{phase}_batches.json"
    if not batch_file.exists():
        print(f"[错误] {batch_file} 不存在，请先运行 sync.py")
        sys.exit(1)

    batches = json.loads(batch_file.read_text(encoding="utf-8"))
    print(f"[启动] {phase}，共{len(batches)}批")
    push_batches(batches, phase)
