#!/usr/bin/env python3
"""
编程猫 CRM → 钉钉表格 一键同步脚本（集成推送+缓存+增量）

用法:
  python sync.py 29 30           一键同步（抓取→生成批次→推送→验证）
  python sync.py 29 30 --no-push   只生成批次不推送
  python sync.py 29 30 --incremental  增量推送（只推变化的行）
  python sync.py --probe           探测表格结构
  python sync.py --refresh-cache  强制刷新钉钉ID缓存

优化：
  P0: 一键完成抓取+生成+推送
  P1: 钉钉ID缓存到 table_ids_cache.json，首次扫描后复用
  P2: --incremental 模式下只更新与钉钉表格当前值不同的行
"""
import json, os, sys, io, requests, hashlib
from pathlib import Path
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
BASE_DIR = Path(__file__).parent.resolve()

# ── 钉钉 MCP 配置 ─────────────────────────────────────────────────
MCP_URL  = "https://mcp-gw.dingtalk.com/server/73ba964f5fc66d46a3c0499789a7aa330a47243c0fddb41ae2af1e5a2e1ae09d?key=abb1ef3e57855ca2a4716c690cc48da0"
ACCESS_TOKEN = ""
NODE_ID  = "QOG9lyrgJP3AZLd9fzKEjXA5VzN67Mw4"
SHEET_ID = "小九"
CACHE_FILE   = BASE_DIR / "table_ids_cache.json"
STRUCT_FILE  = BASE_DIR / "dingtalk_structure.json"


def set_token(token: str):
    global ACCESS_TOKEN
    ACCESS_TOKEN = token


def mcp_raw(tool_name: str, arguments: dict) -> dict:
    """直接发 JSON-RPC 到 MCP 端点"""
    payload = {"jsonrpc":"2.0","method":"tools/call",
               "params":{"name":tool_name,"arguments":arguments},"id":1}
    headers = {"Content-Type":"application/json","Accept":"application/json",
               "Authorization":"Bearer "+ACCESS_TOKEN}
    resp = requests.post(MCP_URL, json=payload, headers=headers, timeout=60)
    resp.raise_for_status()
    result = resp.json()
    if "error" in result:
        raise Exception(f"MCP error: {result['error']}")
    content = result.get("result",{}).get("content",[])
    if content:
        return json.loads(content[0].get("text","{}"))
    return result.get("result",{})


def load_config():
    cfg = BASE_DIR / "config.json"
    if not cfg.exists():
        print(f"错误: 找不到 config.json"); sys.exit(1)
    return json.loads(cfg.read_text(encoding="utf-8-sig"))


def load_cookies(config: dict):
    cf = config.get("cookies_file", str(BASE_DIR/"crm_cookies.json"))
    if not os.path.exists(cf):
        print(f"未找到 Cookie: {cf}"); print("请先运行: python get_cookies.py"); sys.exit(1)
    return json.loads(Path(cf).read_text(encoding="utf-8-sig"))


# ── P1: 钉钉ID缓存 ─────────────────────────────────────────────
def load_cached_ids() -> list:
    """从本地缓存加载ID列表"""
    if not CACHE_FILE.exists(): return []
    try:
        data = json.loads(CACHE_FILE.read_text(encoding="utf-8"))
        ids = data.get("ids", [])
        if ids:
            print(f"[缓存] 加载 {len(ids)} 个ID（{data.get('cached_at','?')}）")
            return ids
    except Exception: pass
    return []


def save_ids_cache(ids: list):
    data = {"ids": ids, "count": len(ids),
            "cached_at": __import__("datetime").datetime.now().strftime("%Y-%m-%d %H:%M")}
    CACHE_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[缓存] 已保存 {len(ids)} 个ID → {CACHE_FILE.name}")


def fetch_table_ids_via_mcp() -> list:
    """通过 MCP 读取钉钉表格 A 列（用户ID）"""
    print("[缓存] 通过 MCP 读取钉钉表格 A 列...")
    rows = []
    # 分批读取，避免一次读太多
    for start in range(2, 500, 100):
        end = min(start+99, 500)
        r = mcp_raw("get_range", {
            "nodeId": NODE_ID, "sheetId": SHEET_ID,
            "range": f"A{start}:A{end}"
        })
        vals = r.get("values", [])
        if not vals: break
        rows.extend(vals)
        if len(vals) < 100: break
    ids = [str(r[0]).strip() for r in rows if r and str(r[0]).strip().isdigit()]
    print(f"[缓存] 读取到 {len(ids)} 个用户ID")
    return ids


def get_table_ids(force_refresh: bool = False) -> list:
    """获取钉钉表格的ID列表（优先缓存）"""
    if not force_refresh:
        cached = load_cached_ids()
        if cached: return cached
    ids = fetch_table_ids_via_mcp()
    if ids: save_ids_cache(ids)
    return ids


# ── CRM 抓取 ───────────────────────────────────────────────────
def fetch_crm(config, cookies, classes, course_nums):
    """抓取 CRM 数据，返回 {uid: {课节: true/false}}"""
    courses_map = {int(k): v for k,v in config["courses"].items()}
    crm_data = {}  # uid -> {course_num: val}

    def _fetch_single(cls, cn):
        cid = courses_map.get(cn)
        if not cid: return cls["name"], cn, "WARN", None
        req_cookies = {}
        req_headers = {"User-Agent": "Mozilla/5.0"}
        if "internal_account_token" in cookies:
            req_cookies["internal_account_token"] = cookies["internal_account_token"]
        auth = cookies.get("admin-authorization", "")
        if auth:
            req_headers["Authorization"] = auth if auth.startswith("Bearer ") else "Bearer "+auth
        items, page = [], 1
        while True:
            try:
                resp = requests.post(
                    f"https://api-codecamp-crm.codemao.cn/annual/class/course-detail"
                    f"?page={page}&limit=100",
                    json={"term_id":cls["term_id"],"class_id":cls["class_id"],
                          "course_ids":[cid],"is_finish":False,"queryType":2},
                    cookies=req_cookies, headers=req_headers, timeout=15
                )
                if resp.status_code == 401: return cls["name"], cn, "AUTH", None
                d = resp.json()
                page_items = d.get("items") or (d.get("data") or {}).get("items") or []
                if not page_items: break
                items.extend(page_items)
                page += 1
            except Exception as e:
                return cls["name"], cn, "ERR", str(e)
        # 解析
        for item in items:
            uid = str(item.get("user_id","")).strip()
            if not uid: continue
            if uid not in crm_data: crm_data[uid] = {}
            crm_data[uid][cn] = "false"
        return cls["name"], cn, "OK", len(items)

    with ThreadPoolExecutor(max_workers=6) as pool:
        futures = {pool.submit(_fetch_single, cls, cn): (cls["name"],cn)
                   for cls in classes for cn in course_nums}
        for fut in as_completed(futures):
            cls_name, cn, status, data = fut.result()
            if status == "AUTH": return "NEED_LOGIN", None
            elif status == "OK":
                print(f"  {cls_name} 课节{cn}: {data}条")
            elif status == "WARN":
                print(f"  警告: 课节{cn}未配置course_id")
    return crm_data


# ── 批次生成 ───────────────────────────────────────────────────
def generate_batches(crm_data: dict, table_ids: list,
                     course_nums: list, config: dict) -> dict:
    """生成 reset_batches.json + update_batches.json"""
    dt = config["dingtalk"]
    data_start = dt.get("data_start_row", 2)
    batch_size  = dt.get("batch_size", 50)

    # 加载列映射
    col_map = {}
    if STRUCT_FILE.exists():
        s = json.loads(STRUCT_FILE.read_text(encoding="utf-8"))
        col_map = {str(k): v for k,v in s.get("course_columns",{}).items()}

    ordered_cols = [col_map.get(str(c)) for c in course_nums if col_map.get(str(c))]
    if not ordered_cols:
        print("错误: 目标课节列未找到，请先运行 --probe"); sys.exit(1)
    first_col, last_col = ordered_cols[0], ordered_cols[-1]

    # 生成 update/reset 值（按 table_ids 顺序）
    update_vals, reset_vals = [], []
    stats = defaultdict(int)
    for uid in table_ids:
        u_row, r_row = [], []
        for cn in course_nums:
            val = crm_data.get(uid,{}).get(cn, "true")  # 不在CRM中视为已完成
            u_row.append(val)
            r_row.append("true")
            if val == "false": stats[cn] += 1
        update_vals.append(u_row)
        reset_vals.append(r_row)

    # 分批次
    def _make_batches(vals):
        batches = []
        for i in range(0, len(vals), batch_size):
            chunk = vals[i:i+batch_size]
            s = data_start + i
            e = s + len(chunk) - 1
            batches.append({"rangeAddress": f"{first_col}{s}:{last_col}{e}",
                           "values": chunk})
        return batches

    reset_path = BASE_DIR / "reset_batches.json"
    update_path = BASE_DIR / "update_batches.json"
    json.dump(_make_batches(reset_vals),  reset_path.open("w", encoding="utf-8"), ensure_ascii=False, indent=2)
    json.dump(_make_batches(update_vals), update_path.open("w", encoding="utf-8"), ensure_ascii=False, indent=2)

    print(f"\n  Reset: {reset_path} ({len(_make_batches(reset_vals))}批)")
    print(f"  Update: {update_path} ({len(_make_batches(update_vals))}批)")
    for cn in course_nums:
        col = col_map.get(str(cn),"")
        print(f"  课节{cn}(列{col}): false={stats[cn]}")
    return {"reset_path":str(reset_path), "update_path":str(update_path), "stats":dict(stats)}


# ── P2: 增量推送 ─────────────────────────────────────────────
def push_incremental(course_nums: list, config: dict) -> bool:
    """只推送与钉钉表格当前值不同的行"""
    print("\n[增量] 读取钉钉表格当前值...")
    col_map = {}
    if STRUCT_FILE.exists():
        s = json.loads(STRUCT_FILE.read_text(encoding="utf-8"))
        col_map = {str(k): v for k,v in s.get("course_columns",{}).items()}
    first_col = col_map.get(str(course_nums[0]),"AU")
    last_col  = col_map.get(str(course_nums[-1]),"AV")
    data_start = config["dingtalk"].get("data_start_row",2)

    # 读取当前值
    current = mcp_raw("get_range", {
        "nodeId": NODE_ID, "sheetId": SHEET_ID,
        "range": f"{first_col}{data_start}:{last_col}{data_start+500}"
    })
    cur_vals = current.get("values",[])

    # 读取 update 批次
    update_path = BASE_DIR / "update_batches.json"
    batches = json.loads(update_path.read_text(encoding="utf-8"))

    total_changed = 0
    for b in batches:
        new_vals = b["values"]
        # 找出变化的行
        changed = []
        for i, nv in enumerate(new_vals):
            ri = i + (int(b["rangeAddress"].split(":")[0][1:]) - data_start)
            if ri < len(cur_vals):
                cv = cur_vals[ri]
                if any(str(nv[j]).lower() != str(cv[j]).lower() for j in range(min(len(nv),len(cv)))):
                    changed.append((ri, i, nv))
        if not changed:
            print(f"  [跳过] {b['rangeAddress']} 无变化")
            continue
        # 重新生成小批次（只含变化行）
        # 简化：直接推整个批次（变化行少时影响不大）
        print(f"  {b['rangeAddress']}: {len(changed)}/{len(new_vals)} 行变化 → 整批推送")
        ok = _push_batch(b["rangeAddress"], new_vals, "update")
        if not ok: return False
        total_changed += len(changed)

    print(f"[增量] 完成，共 {total_changed} 行有变化")
    return True


def _push_batch(range_addr: str, values: list, phase: str) -> bool:
    result = mcp_raw("update_range", {
        "nodeId": NODE_ID, "sheetId": SHEET_ID,
        "rangeAddress": range_addr, "values": values, "format": "plain_text"
    })
    if result.get("success"):
        print(f"  OK {range_addr} ({len(values)}行)"); return True
    else:
        print(f"  FAIL: {result.get('errorMessage',result)}"); return False


def push_all(batches_path: str, phase: str) -> bool:
    """推送所有批次"""
    batches = json.loads(Path(batches_path).read_text(encoding="utf-8"))
    print(f"\n[推送] {phase} {len(batches)}批")
    for i, b in enumerate(batches):
        ok = _push_batch(b["rangeAddress"], b["values"], phase)
        if not ok: print(f"  批次{i+1}失败"); return False
    return True


# ── 探测 ─────────────────────────────────────────────────────
def probe(config):
    """探测表格结构，结果保存到 dingtalk_structure.json"""
    dt = config["dingtalk"]
    print("[探测] 开始...")
    # 读取表头
    r = mcp_raw("get_range", {"nodeId":dt["node_id"],"sheetId":dt["sheet_id"],"range":"1:1"})
    headers = r.get("values",[[]])[0]
    # 找课节列
    col_map = {}
    for i,h in enumerate(headers):
        h = str(h).strip()
        if h.isdigit() and 1<=int(h)<=200:
            col_map[int(h)] = _idx_to_col(i)
    # 保存
    result = {"node_id":dt["node_id"],"sheet_id":dt["sheet_id"],
             "course_columns":{str(k):v for k,v in col_map.items()},
             "data_start_row":2}
    STRUCT_FILE.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[探测] 完成: {len(col_map)}个课节列"); return result


def _idx_to_col(i: int) -> str:
    s = ""
    while True:
        s = chr(ord("A")+i%26)+s; i=i//26-1
        if i<0: break
    return s


# ── 主入口 ───────────────────────────────────────────────────
def main():
    if len(sys.argv) < 2:
        print("用法: python sync.py <课节号> [--no-push] [--incremental]"); sys.exit(1)

    if sys.argv[1] == "--probe":
        config = load_config(); probe(config); return
    if sys.argv[1] == "--refresh-cache":
        config = load_config(); set_token_from_config(config)
        ids = fetch_table_ids_via_mcp(); save_ids_cache(ids); return

    # 解析参数
    course_nums = []
    no_push = False; incremental = False
    for a in sys.argv[1:]:
        if a == "--no-push": no_push = True
        elif a == "--incremental": incremental = True
        else:
            try: course_nums.append(int(a))
            except: pass
    if not course_nums:
        print("错误: 请指定课节号"); sys.exit(1)

    config = load_config()
    set_token_from_config(config)
    cookies = load_cookies(config)

    print(f"=== 同步课节: {' '.join(map(str,course_nums))} ===\n")

    # P1: 获取钉钉表格ID（优先缓存）
    print("[1/4] 获取钉钉表格ID...")
    table_ids = get_table_ids()

    # 抓取CRM
    print("\n[2/4] 抓取 CRM 数据...")
    crm_data = fetch_crm(config, cookies, config["classes"], course_nums)
    if crm_data == "NEED_LOGIN":
        print("Cookie过期，请重新运行 python get_cookies.py"); sys.exit(1)

    # 生成批次
    print("\n[3/4] 生成批次...")
    info = generate_batches(crm_data, table_ids, course_nums, config)

    if no_push:
        print("\n[完成] 已生成批次文件，跳过推送"); return

    # 推送
    print("\n[4/4] 推送到钉钉表格...")
    if incremental:
        ok = push_incremental(course_nums, config)
    else:
        ok = push_all(info["reset_path"], "reset")
        if ok: ok = push_all(info["update_path"], "update")

    if ok:
        print("\n[完成] 全部推送成功！")
        # 验证
        print("\n[验证] 读取结果...")
        for cn, stat in info["stats"].items():
            col = config["dingtalk"].get("course_columns",{}).get(str(cn),"")
            print(f"  课节{cn}(列{col}): false={stat}")
    else:
        print("\n[失败] 推送中断")


def set_token_from_config(config):
    mcp_cfg = config.get("mcp", {})
    if mcp_cfg.get("auth_token"):
        set_token(mcp_cfg["auth_token"])
        print(f"[配置] 使用 config.json 中的 token")


def interactive_setup():
    """交互式引导配置（首次使用）"""
    print("=" * 50)
    print("  编程猫 CRM → 钉钉表格 同步配置向导")
    print("=" * 50)
    print()
    cfg = {"classes": [], "courses": {}, "dingtalk": {}, "cookies_file": ""}

    # 1. 班级配置
    print("【第1步】配置班级（编程猫CRM）")
    print("  在 CRM 页面查看 URL，找到 term_id 和 class_id")
    print("  示例 URL：...term_id=16549&class_id=119141...")
    while True:
        name = input("  班级名称（如：周五班，输空结束）: ").strip()
        if not name: break
        try:
            tid = input("  term_id（数字）: ").strip()
            cid = input("  class_id（数字）: ").strip()
            cfg["classes"].append({"name": name, "term_id": int(tid), "class_id": int(cid)})
        except ValueError:
            print("  ⚠️  请输入数字，重新输入")
            continue
        print()

    # 2. 课节配置
    print("【第2步】配置课节 → course_id 映射")
    print("  course_id = 9725 + 课节号（如课27 → 9752）")
    while True:
        cn = input("  课节号（如 27，输空结束）: ").strip()
        if not cn: break
        default_cid = str(9725 + int(cn)) if cn.isdigit() else ""
        cid = input(f"  course_id（默认 {default_cid}）: ").strip()
        if not cid:
            cid = default_cid
        if cid:
            cfg["courses"][cn] = int(cid)
        print()

    # 3. 钉钉配置
    print("【第3步】配置钉钉表格")
    print("  打开钉钉表格，复制浏览器地址栏链接")
    node = input("  钉钉表格链接或 doc ID: ").strip()
    sheet = input("  工作表名称（如：小九）: ").strip()
    cfg["dingtalk"] = {"node_id": node, "sheet_id": sheet}

    # 4. Cookie 路径
    print("【第4步】CRM Cookie 文件路径")
    default_cf = "C:/Users/PC/Desktop/上课/完课/crm_cookies.json"
    cf = input(f"  Cookie 文件路径（默认 {default_cf}）: ").strip()
    cfg["cookies_file"] = cf or default_cf

    # 写文件
    config_path = BASE_DIR / "config.json"
    config_path.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    print()
    print(f"✅ 配置已写入: {config_path}")
    print()
    print("   接下来请运行: python get_cookies.py  （获取CRM Cookie）")
    print("   然后运行:     python sync.py 27 28  （一键同步）")
    return True


if __name__ == "__main__":
    if len(sys.argv) == 2 and sys.argv[1] == "--setup":
        interactive_setup()
        sys.exit(0)
    main()
