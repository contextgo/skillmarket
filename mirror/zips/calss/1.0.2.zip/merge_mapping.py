import json

# 读取三个班的 cURL 数据
files = {
    '周五': 'curl_friday.json',
    '周六午': 'curl_sat_noon.json',
    '周六晚': 'curl_sat_night.json'
}

mapping = {}  # {className: {userId: [externalUserId, ...]}}
for cls, fname in files.items():
    with open(f'c:/Users/PC/.workbuddy/skills/codemao-course-data/{fname}', encoding='utf-8') as f:
        data = json.load(f)
    mapping[cls] = {u['userId']: u['externalUserIds'] for u in data['users']}

# 输出统计
print("=== 三个班映射统计 ===")
for cls, m in mapping.items():
    total_external = sum(len(v) for v in m.values())
    multi = sum(1 for v in m.values() if len(v) > 1)
    print(f'{cls}: {len(m)}学生, {total_external}个externalUserId, {multi}人多账号')

# 合并所有 externalUserId（按 userId 分组）
all_mapping = {}  # {userId: {class: [externalIds]}}
for cls, m in mapping.items():
    for uid, exts in m.items():
        if uid not in all_mapping:
            all_mapping[uid] = {}
        all_mapping[uid][cls] = exts

# 输出到文件
output = {}
for cls in files.keys():
    with open(f'c:/Users/PC/.workbuddy/skills/codemao-course-data/{files[cls]}', encoding='utf-8') as f:
        data = json.load(f)
    output[cls] = {u['userId']: u['externalUserIds'] for u in data['users']}

# 保存合并后的映射
result = {
    'classes': {
        '周五': {'termId': 16549, 'classId': 119141},
        '周六午': {'termId': 16550, 'classId': 119144},
        '周六晚': {'termId': 16551, 'classId': 119147}
    },
    'mapping': output
}

with open(r'c:\Users\PC\.workbuddy\skills\codemao-course-data\userid_externalid_mapping.json', 'w', encoding='utf-8') as f:
    json.dump(result, f, ensure_ascii=False, indent=2)

print('\n映射表已保存到 userid_externalid_mapping.json')
print(f'总 userId 数: {sum(len(v) for v in output.values())}')
