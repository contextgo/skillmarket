#!/usr/bin/env python3
"""
CodeMao → DingTalk 批次生成工具

纯本地工具，不含 MCP 调用：
- 解析 TSV 文件
- 生成 reset_batches.json + update_batches.json
- MCP 推送由 AI Agent 通过 WorkBuddy 钉钉 MCP 完成

用法:
  python dingtalk_sync.py --tsv courses_temp.tsv --courses 27 28 29 30
  python dingtalk_sync.py --probe           (探测表格结构)
"""

import argparse
import json
import os
import re
import sys
import requests
from pathlib import Path
from collections import defaultdict
from typing import Dict, List, Set, Optional

SCRIPT_DIR = Path(__file__).parent.resolve()
CONFIG_PATH = SCRIPT_DIR / "config.json"


def load_config() -> dict:
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def column_letter_to_index(col: str) -> int:
    idx = 0
    for ch in col.upper():
        idx = idx * 26 + (ord(ch) - ord("A") + 1)
    return idx - 1


def index_to_column_letter(idx: int) -> str:
    col = ""
    idx += 1
    while idx > 0:
        idx, rem = divmod(idx - 1, 26)
        col = chr(ord("A") + rem) + col
    return col


# ─── 探测 ─────────────────────────────────────────────────

def probe_spreadsheet(config: dict):
    """通过 MCP 探测表格结构"""
    mcp_cfg = config.get("mcp", {})
    if not mcp_cfg.get("url") or not mcp_cfg.get("auth_token"):
        print("MCP 未配置，无法自动探测")
        print("请让 AI Agent 使用 WorkBuddy 钉钉 MCP 执行 python sync.py --probe")
        return None

    mcp_url, auth = mcp_cfg["url"], mcp_cfg["auth_token"]
    dt = config["dingtalk"]
    node_id, sheet_id = dt["node_id"], dt["sheet_id"]

    def mcp_call(tool_name, args):
        payload = {
            "jsonrpc": "2.0", "method": "tools/call",
            "params": {"name": tool_name, "arguments": args}, "id": 1,
        }
        resp = requests.post(
            mcp_url, json=payload,
            headers={"Content-Type": "application/json", "Accept": "application/json",
                     "Authorization": "Bearer " + auth}, timeout=30,
        )
        return json.loads(resp.json()["result"]["content"][0]["text"])

    print("读取钉钉表格表头...")
    try:
        sheets = mcp_call("get_all_sheets", {"nodeId": node_id})
        resolved = sheet_id
        for s in sheets:
            sid = str(s.get("sheetId") or s.get("name", ""))
            if sid == str(sheet_id):
                resolved = s.get("sheetId") or sheet_id
                break
        else:
            if sheets:
                resolved = sheets[0].get("sheetId") or sheets[0].get("name")

        raw = mcp_call("get_range", {"nodeId": node_id, "sheetId": resolved, "range": "1:1"})
        values = raw.get("values", raw.get("displayValues", []))
        headers = values[0] if values and isinstance(values[0], list) else (values or [])
        if len(headers) < 5:
            raw2 = mcp_call("get_range", {"nodeId": node_id, "sheetId": resolved, "range": "R1:AZ1"})
            v2 = raw2.get("values", raw2.get("displayValues", []))
            if v2:
                headers = v2[0] if isinstance(v2[0], list) else v2
    except Exception as e:
        print(f"探测失败: {e}")
        return None

    headers = [str(v).strip() if v is not None else "" for v in headers]

    name_patterns = ["姓名", "孩子姓名", "孩子名字", "学号", "学生", "账号", "用户名"]
    name_col = dt.get("name_col_letter", "A")
    for i, h in enumerate(headers):
        if any(p in h for p in name_patterns):
            name_col = index_to_column_letter(i)
            break

    course_map = {}
    for i, h in enumerate(headers):
        text = str(h).strip()
        if not text:
            continue
        if text.isdigit() and 1 <= int(text) <= 200:
            course_map[int(text)] = index_to_column_letter(i)
        else:
            m = re.search(r"(\d+)", text)
            if m and 1 <= int(m.group(1)) <= 200:
                course_map[int(m.group(1))] = index_to_column_letter(i)

    result = {
        "node_id": node_id, "sheet_id": resolved,
        "name_col_letter": name_col,
        "course_columns": course_map,
        "data_start_row": dt.get("data_start_row", 2),
        "headers": headers,
    }

    out = SCRIPT_DIR / "dingtalk_structure.json"
    with open(out, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    print(f"  姓名列: {name_col}")
    print(f"  共 {len(course_map)} 个课节列:")
    for cn in sorted(course_map):
        print(f"    课节 {cn} → 列 {course_map[cn]}")
    print(f"  已保存: {out}")
    return result


# ─── 列映射 ──────────────────────────────────────────────

def resolve_column_map(config: dict) -> Dict[str, str]:
    cfg_cols = config.get("dingtalk", {}).get("course_columns", {})
    if cfg_cols:
        return {str(k): v for k, v in cfg_cols.items()}

    probe_path = SCRIPT_DIR / "dingtalk_structure.json"
    if probe_path.exists():
        with open(probe_path, "r", encoding="utf-8") as f:
            saved = json.load(f)
        if saved.get("course_columns"):
            return {str(k): v for k, v in saved["course_columns"].items()}

    print("错误: 缺少课节列映射，请运行 python sync.py --probe 探测")
    sys.exit(1)


# ─── TSV 解析 ────────────────────────────────────────────

def parse_tsv(tsv_path: str) -> List[dict]:
    with open(tsv_path, "r", encoding="utf-8") as f:
        lines = f.read().strip().split("\n")
    if not lines:
        return []

    header = lines[0].split("\t")
    is_wide = len(header) >= 5 and header[0] in ("班级", "className") and header[4].isdigit()

    if is_wide:
        course_nums = [int(h) for h in header[4:] if h.isdigit()]
        rows = []
        for line in lines[1:]:
            parts = line.split("\t")
            if len(parts) < 5:
                continue
            try:
                uid = int(parts[1].strip())
            except ValueError:
                continue
            for j, cn in enumerate(course_nums):
                val = parts[4 + j].strip().lower() if 4 + j < len(parts) else ""
                rows.append({
                    "class_name": parts[0].strip(),
                    "course_num": cn,
                    "user_id": uid,
                    "child_name": parts[2].strip(),
                    "course_name": parts[3].strip(),
                    "_val": val,
                })
        return rows
    else:
        rows = []
        for i, line in enumerate(lines):
            parts = line.split("\t")
            if i == 0 and parts[0] in ("班级", "className"):
                continue
            if len(parts) == 4:
                rows.append({"class_name": parts[0].strip(), "course_num": None,
                             "user_id": int(parts[1].strip()), "child_name": parts[2].strip(),
                             "course_name": parts[3].strip()})
            elif len(parts) >= 5:
                rows.append({"class_name": parts[0].strip(), "course_num": int(parts[1].strip()),
                             "user_id": int(parts[2].strip()), "child_name": parts[3].strip(),
                             "course_name": parts[4].strip()})
        return rows


def extract_unfinished(tsv_rows: List[dict], config: dict) -> Dict[int, Set[int]]:
    result = defaultdict(set)
    base = config.get("codecamp", {}).get("course_id_base", 9725)
    for row in tsv_rows:
        cn = row.get("course_num")
        if cn is None:
            m = re.match(r"(\d+)", row["course_name"])
            if m:
                cn = int(m.group(1)) - base
        if cn is not None:
            val = row.get("_val", "").lower()
            if "_val" not in row or val == "false":
                result[cn].add(row["user_id"])
    return dict(result)


# ─── 批次生成 ────────────────────────────────────────────

def generate_batches(tsv_path: str, course_nums: List[int], output_path: str = None):
    config = load_config()
    column_map = resolve_column_map(config)

    print(f"\n读取 TSV: {tsv_path}")
    tsv_rows = parse_tsv(tsv_path)
    print(f"记录数: {len(tsv_rows)}")

    unfinished_map = extract_unfinished(tsv_rows, config)
    print(f"发现 {len(unfinished_map)} 个课节:")
    for num, ids in sorted(unfinished_map.items()):
        print(f"  课节 {num}: {len(ids)} 人未完成")

    dt = config["dingtalk"]
    data_start = dt.get("data_start_row", 2)
    batch_size = dt.get("batch_size", 50)

    # 从钉钉读 ID 列（如果有 MCP 配置），否则用 TSV 中的
    ids = sorted(set(r["user_id"] for r in tsv_rows if r.get("user_id")))

    mcp_cfg = config.get("mcp", {})
    if mcp_cfg.get("url") and mcp_cfg.get("auth_token"):
        probe_path = SCRIPT_DIR / "dingtalk_structure.json"
        probe = json.load(open(probe_path)) if probe_path.exists() else {}
        name_col = probe.get("name_col_letter") or dt.get("name_col_letter", "A")
        try:
            payload = {
                "jsonrpc": "2.0", "method": "tools/call",
                "params": {"name": "get_range",
                           "arguments": {"nodeId": dt["node_id"],
                                        "sheetId": probe.get("sheet_id") or dt["sheet_id"],
                                        "range": f"{name_col}{data_start}:{name_col}{data_start+300}"}},
                "id": 1,
            }
            resp = requests.post(
                mcp_cfg["url"], json=payload,
                headers={"Content-Type": "application/json", "Accept": "application/json",
                         "Authorization": "Bearer " + mcp_cfg["auth_token"]}, timeout=30,
            )
            vals = json.loads(resp.json()["result"]["content"][0]["text"]).get("values", [])
            ids = sorted([int(str(row[0]).strip()) for row in vals if row and str(row[0]).strip().isdigit()])
            print(f"钉钉表格共 {len(ids)} 名学生")
        except Exception as e:
            print(f"读取钉钉 ID 失败: {e}，使用 TSV 中的 {len(ids)} 个 UID")

    target_cols = [column_map.get(str(c)) for c in course_nums if column_map.get(str(c))]
    if not target_cols:
        sys.exit(1)
    first_col, last_col = target_cols[0], target_cols[-1]

    update_values, reset_values = [], []
    for uid in ids:
        u_row, r_row = [], []
        for cn in course_nums:
            u_row.append("false" if uid in unfinished_map.get(cn, set()) else "true")
            r_row.append("true")
        update_values.append(u_row)
        reset_values.append(r_row)

    def make_batches(vals):
        batches = []
        for i in range(0, len(vals), batch_size):
            chunk = vals[i:i + batch_size]
            s, e = data_start + i, data_start + i + len(chunk) - 1
            batches.append({"rangeAddress": f"{first_col}{s}:{last_col}{e}", "values": chunk})
        return batches

    reset_batches, update_batches = make_batches(reset_values), make_batches(update_values)

    out_path = output_path or str(SCRIPT_DIR / "update_batches.json")
    reset_out = str(SCRIPT_DIR / "reset_batches.json")

    with open(reset_out, "w", encoding="utf-8") as f:
        json.dump(reset_batches, f, ensure_ascii=False, indent=2)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(update_batches, f, ensure_ascii=False, indent=2)

    print(f"\nReset: {reset_out} ({len(reset_batches)}批)")
    print(f"Update: {out_path} ({len(update_batches)}批)")

    print(f"\n预期更新结果:")
    for cn in course_nums:
        col = column_map.get(str(cn), "?")
        fc = sum(1 for row in update_values for i, c in enumerate(course_nums)
                 if c == cn and i < len(row) and row[i] == "false")
        print(f"  课节 {cn} (列{col}): false={fc}")


# ─── MCP 直推（绕过 mcp_call_tool JSON截断）───────────────

MCP_URL = "https://mcp-gw.dingtalk.com/server/73ba964f5fc66d46a3c0499789a7aa330a47243c0fddb41ae2af1e5a2e1ae09d?key=abb1ef3e57855ca2a4716c690cc48da0"

def mcp_raw(tool_name, arguments, token):
    import requests as _req
    payload = {"jsonrpc":"2.0","method":"tools/call",
               "params":{"name":tool_name,"arguments":arguments},"id":1}
    headers = {"Content-Type":"application/json","Accept":"application/json",
               "Authorization":"Bearer "+token}
    resp = _req.post(MCP_URL, json=payload, headers=headers, timeout=60)
    resp.raise_for_status()
    result = resp.json()
    if "error" in result:
        raise Exception(f"MCP error: {result['error']}")
    content = result.get("result",{}).get("content",[])
    if content:
        return json.loads(content[0].get("text","{}"))
    return result.get("result",{})

def push_via_http(batch_file, node_id, sheet_id, token):
    """通过Python requests直推批次文件，绕过mcp_call_tool"""
    import requests as _req
    batches = json.loads(Path(batch_file).read_text(encoding="utf-8"))
    print(f"  直推 {len(batches)} 批到钉钉...")
    for i, b in enumerate(batches):
        result = mcp_raw("update_range", {
            "nodeId": node_id, "sheetId": sheet_id,
            "rangeAddress": b["rangeAddress"], "values": b["values"], "format": "plain_text"
        }, token)
        if result.get("success"):
            print(f"  批次{i+1} OK")
        else:
            print(f"  批次{i+1} FAIL: {result.get('errorMessage', result)}")
            return False
    return True

# ─── CLI ─────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="CodeMao → DingTalk 批次生成")
    parser.add_argument("--tsv", help="TSV 文件路径")
    parser.add_argument("--courses", nargs="+", type=int, help="目标课节")
    parser.add_argument("--probe", action="store_true", help="探测表格结构")
    parser.add_argument("--output", help="批次输出路径")
    parser.add_argument("--excel", action="store_true", help="生成 Excel")

    args = parser.parse_args()

    if args.probe:
        config = load_config()
        probe_spreadsheet(config)
        return

    if args.tsv and args.courses:
        generate_batches(args.tsv, args.courses, args.output)
        if args.excel:
            try:
                import openpyxl as px
                rows = parse_tsv(args.tsv)
                wb = px.Workbook()
                ws = wb.active
                ws.append(["班级", "用户ID", "孩子姓名", "课程名称"])
                for r in rows:
                    ws.append([r["class_name"], r["user_id"], r["child_name"], r["course_name"]])
                out = f"未完课明细_{len(rows)}条.xlsx"
                wb.save(out)
                print(f"Excel: {out}")
            except ImportError:
                pass
        return

    parser.print_help()
    print("\n用法:")
    print("  python sync.py 27 28 29 30       (推荐: 一键同步)")
    print("  python sync.py --probe            (探测表格结构)")


if __name__ == "__main__":
    main()
