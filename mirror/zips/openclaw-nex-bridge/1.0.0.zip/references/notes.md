# OpenClaw NEX Bridge quick notes

- package path: `C:\Users\cloud_user\.openclaw\extensions\openclaw-nex-bridge`
- package name: `@soundwisdomai/openclaw-nex-bridge`
- config keys: `enabled`, `apiKey`, `serverUrl`, `reconnectInterval`, `heartbeatInterval`, `dmPolicy`, `allowFrom`, `textChunkLimit`
- DM policy values: `open`, `pairing`, `allowlist`
