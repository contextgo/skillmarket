---
name: openclaw-nex-bridge
description: Install, configure, and troubleshoot the @soundwisdomai/openclaw-nex-bridge OpenClaw plugin. Use when a user asks how to install the plugin, configure apiKey/serverUrl/dmPolicy/allowFrom/textChunkLimit, verify whether it is loaded or why it is unavailable, or debug common NEX Bridge connection and pairing problems.
---

# OpenClaw NEX Bridge

Use this skill for the `@soundwisdomai/openclaw-nex-bridge` plugin.

## What to check first

- Confirm the package is present under `~/.openclaw/extensions/openclaw-nex-bridge/`.
- Confirm the plugin is loaded in `openclaw plugins list`.
- Read the plugin config schema before proposing edits.

## Configuration schema

Required:
- `apiKey`

Common options:
- `enabled`: default true
- `serverUrl`: bridge API endpoint; default is the plugin's configured endpoint
- `reconnectInterval`: reconnect delay in ms
- `heartbeatInterval`: heartbeat delay in ms
- `dmPolicy`: `open`, `pairing`, or `allowlist`
- `allowFrom`: allowed sender list when policy needs it
- `textChunkLimit`: max chunk size for outbound text

## Installation workflow

1. Check whether the extension directory exists.
2. Check whether the plugin is listed as loaded.
3. If installed but not loaded, inspect the config and logs for missing `apiKey`, bad `serverUrl`, or invalid schema values.
4. If the package is missing, install it through the normal OpenClaw extension/plugin path, then restart or reload OpenClaw.

## Troubleshooting

### Plugin not visible in `openclaw plugins list`
- The package may be installed on disk but not allowed or not loaded.
- Verify `plugins.allow` if non-bundled plugins are restricted.
- Confirm the extension folder name is exactly `openclaw-nex-bridge`.

### Plugin loads but does not send or receive
- Check `apiKey`.
- Check `serverUrl`.
- Confirm the bridge service is reachable.
- Confirm `dmPolicy` is compatible with the sender flow.

### Messages are rejected
- If `dmPolicy=allowlist`, confirm the sender is in `allowFrom`.
- If `dmPolicy=pairing`, complete the pairing flow before sending.

### Stream or long responses cut off
- Raise `textChunkLimit` if the downstream bridge expects larger chunks.

## Output style

When answering users, prefer:
- exact config keys
- the minimum safe change set
- a short verification checklist

## Safe response pattern

- State whether the plugin is installed, loaded, or only present on disk.
- Show the smallest config change needed.
- End with one verification command or one check to run.
