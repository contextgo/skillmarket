# -*- coding: utf-8 -*-
"""
Agent经验提炼技能包
智能从任务执行中提取可复用经验，生成方法论卡片
"""

__version__ = "2.0.3"
__author__ = "Agent Experience Team"

from .experience_card_generator import ExperienceCardGenerator
from .input_processor import InputProcessor
from .relation_recommender import RelationRecommender
from .exporter import Exporter
from .experience_manager import ExperienceManager
from .retriever import Retriever
from .config import Config
from .utils import (
    generate_id,
    calculate_similarity,
    format_timestamp,
    parse_tags,
    validate_experience_card
)

__all__ = [
    # 核心类
    "ExperienceCardGenerator",
    "InputProcessor",
    "RelationRecommender",
    "Exporter",
    "ExperienceManager",
    "Retriever",
    "Config",
    # 工具函数
    "generate_id",
    "calculate_similarity",
    "format_timestamp",
    "parse_tags",
    "validate_experience_card",
]
