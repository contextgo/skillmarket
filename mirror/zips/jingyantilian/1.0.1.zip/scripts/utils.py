# -*- coding: utf-8 -*-
"""
工具函数模块
提供通用的辅助函数
"""

import re
import hashlib
import uuid
import logging
from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime, timedelta
from difflib import SequenceMatcher

logger = logging.getLogger(__name__)


def generate_id(prefix: str = "EXP") -> str:
    """
    生成唯一ID
    
    Args:
        prefix: ID前缀
        
    Returns:
        格式化的ID字符串
    """
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    unique_part = uuid.uuid4().hex[:6].upper()
    return f"{prefix}_{timestamp}_{unique_part}"


def calculate_similarity(text1: str, text2: str) -> float:
    """
    计算两个文本的相似度
    
    Args:
        text1: 文本1
        text2: 文本2
        
    Returns:
        相似度分数 (0-1)
    """
    if not text1 or not text2:
        return 0.0
    
    # 使用SequenceMatcher计算相似度
    similarity = SequenceMatcher(None, text1.lower(), text2.lower()).ratio()
    return round(similarity, 4)


def calculate_tag_overlap(tags1: List[str], tags2: List[str]) -> float:
    """
    计算标签重叠度
    
    Args:
        tags1: 标签列表1
        tags2: 标签列表2
        
    Returns:
        重叠度分数 (0-1)
    """
    if not tags1 or not tags2:
        return 0.0
    
    set1 = set(normalize_tags(tags1))
    set2 = set(normalize_tags(tags2))
    
    if not set1 or not set2:
        return 0.0
    
    intersection = len(set1 & set2)
    union = len(set1 | set2)
    
    return intersection / union if union > 0 else 0.0


def format_timestamp(dt: Optional[datetime] = None, format_str: str = "%Y-%m-%d %H:%M:%S") -> str:
    """
    格式化时间戳
    
    Args:
        dt: datetime对象，None则使用当前时间
        format_str: 格式化字符串
        
    Returns:
        格式化的时间字符串
    """
    if dt is None:
        dt = datetime.now()
    return dt.strftime(format_str)


def parse_tags(tag_string: str) -> List[str]:
    """
    解析标签字符串
    
    支持格式:
    - "#标签1 #标签2 #标签3"
    - "标签1, 标签2, 标签3"
    - "['标签1', '标签2']"
    - 混合上述格式
    
    Args:
        tag_string: 标签字符串
        
    Returns:
        标签列表
    """
    if not tag_string:
        return []
    
    tags = []
    
    # 处理 #标签 格式
    hash_tags = re.findall(r'#(\w+)', tag_string)
    tags.extend(hash_tags)
    
    # 处理逗号分隔格式
    comma_tags = [t.strip() for t in tag_string.split(',') if t.strip()]
    for tag in comma_tags:
        clean_tag = tag.lstrip('#').strip()
        if clean_tag and clean_tag not in tags:
            tags.append(clean_tag)
    
    # 处理列表格式
    list_match = re.findall(r"['\"]([^'\"]+)['\"]", tag_string)
    for tag in list_match:
        clean_tag = tag.strip()
        if clean_tag and clean_tag not in tags:
            tags.append(clean_tag)
    
    # 去重并清理
    tags = list(dict.fromkeys([t.strip() for t in tags if t.strip()]))
    
    return tags


def normalize_tags(tags: List[str]) -> List[str]:
    """
    标准化标签列表
    
    Args:
        tags: 原始标签列表
        
    Returns:
        标准化后的标签列表
    """
    normalized = []
    for tag in tags:
        clean_tag = tag.strip().lstrip('#').lower()
        if clean_tag:
            normalized.append(clean_tag)
    return normalized


def validate_experience_card(card: Dict[str, Any]) -> Tuple[bool, List[str]]:
    """
    验证经验卡片格式
    
    Args:
        card: 经验卡片字典
        
    Returns:
        (是否有效, 错误信息列表)
    """
    required_fields = ["id", "scenario", "method", "tags"]
    errors = []
    
    for field in required_fields:
        if field not in card or not card[field]:
            errors.append(f"缺少必填字段: {field}")
    
    # 验证标签
    if "tags" in card:
        tags = card["tags"]
        if not isinstance(tags, list):
            errors.append("tags 必须是列表")
        elif len(tags) == 0:
            errors.append("至少需要一个标签")
    
    # 验证ID格式
    if "id" in card:
        if not re.match(r'^[A-Z]+_\d{14}_\w{6}$', card["id"]):
            errors.append("ID格式不正确，应为: PREFIX_YYYYMMDDHHMMSS_XXXXXX")
    
    return len(errors) == 0, errors


def extract_keywords(text: str, max_keywords: int = 10) -> List[str]:
    """
    从文本中提取关键词
    
    Args:
        text: 输入文本
        max_keywords: 最大关键词数量
        
    Returns:
        关键词列表
    """
    if not text:
        return []
    
    # 简单关键词提取：去除停用词后取高频词
    stopwords = {
        '的', '了', '是', '在', '我', '有', '和', '就', '不', '人', '都', '一', '一个',
        '上', '也', '很', '到', '说', '要', '去', '你', '会', '着', '没有', '看', '好',
        '自己', '这', '那', '里', '为', '什么', '这个', '那个', '可以', '能', '来',
        '做', '对', '与', '或', '但', '如果', '因为', '所以', '而', '及', '等', '等等'
    }
    
    # 提取中文字符和英文单词
    chinese_chars = re.findall(r'[\u4e00-\u9fff]+', text)
    english_words = re.findall(r'[a-zA-Z]+', text.lower())
    
    # 处理中文：简单分词（实际应用可用jieba）
    words = []
    for chars in chinese_chars:
        if len(chars) >= 2:
            words.append(chars)
    
    # 合并英文
    words.extend([w for w in english_words if len(w) >= 3])
    
    # 过滤停用词
    filtered = [w for w in words if w not in stopwords]
    
    # 统计频率
    word_freq = {}
    for word in filtered:
        word_freq[word] = word_freq.get(word, 0) + 1
    
    # 按频率排序
    sorted_words = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)
    
    return [word for word, _ in sorted_words[:max_keywords]]


def calculate_recency_score(updated_at: str, decay_days: int = 90) -> float:
    """
    计算时效性分数
    
    Args:
        updated_at: 更新时间（ISO格式字符串）
        decay_days: 衰减周期天数
        
    Returns:
        时效性分数 (0-1)
    """
    try:
        update_time = datetime.fromisoformat(updated_at.replace('Z', '+08:00'))
        now = datetime.now()
        days_diff = (now - update_time).days
        
        if days_diff <= 0:
            return 1.0
        elif days_diff >= decay_days:
            return 0.0
        else:
            return 1.0 - (days_diff / decay_days)
    except Exception as e:
        logger.warning(f"计算时效性分数失败: {e}")
        return 0.5


def truncate_text(text: str, max_length: int = 100, suffix: str = "...") -> str:
    """
    截断文本
    
    Args:
        text: 输入文本
        max_length: 最大长度
        suffix: 截断后缀
        
    Returns:
        截断后的文本
    """
    if not text or len(text) <= max_length:
        return text
    
    return text[:max_length - len(suffix)] + suffix


def merge_dicts(dict1: Dict, dict2: Dict, overwrite: bool = False) -> Dict:
    """
    合并字典
    
    Args:
        dict1: 字典1
        dict2: 字典2
        overwrite: 是否覆盖冲突值
        
    Returns:
        合并后的字典
    """
    result = dict1.copy()
    
    for key, value in dict2.items():
        if key not in result or overwrite:
            result[key] = value
        elif isinstance(value, list) and isinstance(result[key], list):
            # 合并列表
            result[key] = list(set(result[key] + value))
        elif isinstance(value, dict) and isinstance(result[key], dict):
            # 递归合并字典
            result[key] = merge_dicts(result[key], value, overwrite)
    
    return result


def safe_filename(filename: str) -> str:
    """
    生成安全的文件名
    
    Args:
        filename: 原始文件名
        
    Returns:
        安全的文件名
    """
    # 替换不安全字符
    safe = re.sub(r'[<>:"/\\|?*]', '_', filename)
    # 去除首尾空格和点
    safe = safe.strip('. ')
    # 限制长度
    if len(safe) > 200:
        safe = safe[:200]
    return safe


def calculate_value_score(card: Dict[str, Any]) -> float:
    """
    计算经验价值分数
    
    Args:
        card: 经验卡片
        
    Returns:
        价值分数 (0-1)
    """
    score = 0.5  # 基础分
    
    # 标签加成
    tags = card.get("tags", [])
    if "高价值" in tags:
        score += 0.3
    elif "中价值" in tags:
        score += 0.15
    
    # 结果加成
    result = card.get("result", {})
    if result.get("success"):
        score += 0.2
    
    # 完整性加成
    if card.get("pitfalls"):  # 有避坑指南
        score += 0.1
    if card.get("extensions"):  # 有延伸应用
        score += 0.1
    
    return min(1.0, max(0.0, score))
