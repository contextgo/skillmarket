# -*- coding: utf-8 -*-
"""
Agent经验提炼技能 - 主入口模块
协调各模块完成经验提炼全流程
"""

import os
import sys
import json
import logging
from typing import Dict, List, Optional, Any

# 添加当前目录到路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import Config, get_config
from utils import (
    generate_id,
    validate_experience_card,
    format_timestamp
)
from experience_card_generator import ExperienceCardGenerator
from input_processor import InputProcessor
from relation_recommender import RelationRecommender
from exporter import Exporter
from experience_manager import ExperienceManager
from retriever import Retriever

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class ExperienceRefiningSkill:
    """Agent经验提炼技能主类"""
    
    def __init__(self, config_path: Optional[str] = None):
        """
        初始化技能
        
        Args:
            config_path: 配置文件路径
        """
        self.config = get_config(config_path)
        
        # 初始化各模块
        self.card_generator = ExperienceCardGenerator(self.config)
        self.input_processor = InputProcessor()
        self.relation_recommender = RelationRecommender(
            min_similarity=self.config.get("min_similarity", 0.6)
        )
        self.exporter = Exporter(
            include_version_history=self.config.get("include_version_history", True),
            include_relations=self.config.get("include_relations", True)
        )
        self.experience_manager = ExperienceManager(
            storage_path=self.config.get("storage_path", "./data/experience_db.json")
        )
        self.retriever = Retriever(
            min_similarity=self.config.get("min_similarity", 0.6),
            max_results=self.config.get("max_results", 10),
            recency_weight=self.config.get("recency_weight", 0.2),
            value_weight=self.config.get("value_weight", 0.3)
        )
        
        logger.info("Agent经验提炼技能初始化完成")
    
    # ========== 核心功能 ==========
    
    def refine_experience(
        self,
        task_info: Dict[str, Any],
        auto_save: bool = True,
        get_recommendations: bool = True
    ) -> Dict[str, Any]:
        """
        提炼经验（主入口）
        
        Args:
            task_info: 任务信息
            auto_save: 是否自动保存
            get_recommendations: 是否获取推荐
            
        Returns:
            处理结果
        """
        try:
            result = {
                "success": True,
                "card": None,
                "recommendations": None,
                "saved": False,
                "message": ""
            }
            
            # 1. 生成经验卡片
            logger.info("开始生成经验卡片...")
            card = self.card_generator.generate(task_info)
            result["card"] = card
            
            # 2. 检查重复
            duplicate = self.experience_manager.find_duplicate(card)
            if duplicate:
                result["duplicate_found"] = True
                result["duplicate_card"] = duplicate
                result["message"] = "检测到可能的重复经验"
            
            # 3. 保存到经验库
            if auto_save and not duplicate:
                success, save_result = self.experience_manager.add(card)
                result["saved"] = success
                if success:
                    result["message"] = "经验已保存"
                else:
                    result["message"] = save_result.get("status", "")
            
            # 4. 获取相关推荐
            if get_recommendations:
                existing = self.experience_manager.get_all()
                recommendations = self.relation_recommender.recommend_for_new_card(
                    card, existing, current_batch_cards=[card]
                )
                result["recommendations"] = recommendations
            
            logger.info(f"经验提炼完成: {card.get('id')}")
            return result
            
        except Exception as e:
            logger.error(f"经验提炼失败: {e}")
            return {
                "success": False,
                "error": str(e),
                "card": None
            }
    
    def refine_from_conversation(
        self,
        conversation_data: Union[str, List[Dict]],
        auto_save: bool = True
    ) -> Dict[str, Any]:
        """
        从对话历史提炼经验
        
        Args:
            conversation_data: 对话历史数据
            auto_save: 是否自动保存
            
        Returns:
            处理结果
        """
        # 加载对话历史
        conversation = self.input_processor.load_conversation_history(conversation_data)
        
        if not conversation:
            return {
                "success": False,
                "error": "对话历史为空"
            }
        
        # 提取任务
        tasks = self.input_processor.extract_tasks_from_conversation(conversation)
        
        if not tasks:
            return {
                "success": False,
                "error": "未从对话中提取到有效任务"
            }
        
        # 批量生成经验
        cards = []
        for task in tasks:
            try:
                card = self.card_generator.generate(task, cards)
                cards.append(card)
            except Exception as e:
                logger.error(f"生成卡片失败: {e}")
                continue
        
        # 批量保存
        if auto_save:
            save_results = self.experience_manager.batch_add(cards)
        else:
            save_results = {"added": 0}
        
        return {
            "success": True,
            "cards_count": len(cards),
            "saved_count": save_results.get("added", 0),
            "cards": cards
        }
    
    def import_experiences(
        self,
        source: str,
        source_type: str = "memory"
    ) -> Dict[str, Any]:
        """
        导入外部经验
        
        Args:
            source: 来源路径或内容
            source_type: 来源类型
                - memory: 记忆文件
                - tools: 工具文件
                - file: 外部文件
                - text: 自由文本
                
        Returns:
            导入结果
        """
        try:
            if source_type == "memory":
                raw_experiences = self.input_processor.import_from_memory_file(source)
            elif source_type == "tools":
                raw_experiences = self.input_processor.import_from_tools_file(source)
            elif source_type == "file":
                file_data = self.input_processor.import_from_file(source)
                if file_data.get("type") == "json":
                    raw_experiences = file_data.get("data", [])
                else:
                    raw_experiences = [{"description": file_data.get("content", "")}]
            elif source_type == "text":
                card = self.card_generator.generate_from_text(source)
                raw_experiences = [card]
            else:
                return {"success": False, "error": f"不支持的来源类型: {source_type}"}
            
            # 批量保存
            results = self.experience_manager.batch_add(raw_experiences)
            
            return {
                "success": True,
                "imported": len(raw_experiences),
                "saved": results.get("added", 0),
                "duplicates": results.get("duplicates", 0),
                "errors": results.get("errors", 0)
            }
            
        except Exception as e:
            logger.error(f"导入失败: {e}")
            return {"success": False, "error": str(e)}
    
    def search_experiences(
        self,
        query: str,
        filters: Optional[Dict[str, Any]] = None
    ) -> List[Dict[str, Any]]:
        """
        搜索经验
        
        Args:
            query: 搜索查询
            filters: 筛选条件
            
        Returns:
            搜索结果
        """
        experience_db = self.experience_manager.get_all()
        results = self.retriever.search(query, experience_db, filters)
        
        return [
            {
                "card": r["card"],
                "score": r["score"],
                "relevance": r.get("relevance", 0),
                "recency": r.get("recency", 0)
            }
            for r in results
        ]
    
    def recommend_experiences(
        self,
        current_task: Dict[str, Any],
        max_count: int = 5
    ) -> List[Dict[str, Any]]:
        """
        推荐相关经验
        
        Args:
            current_task: 当前任务
            max_count: 最大推荐数量
            
        Returns:
            推荐结果
        """
        experience_db = self.experience_manager.get_all()
        
        if len(experience_db) < 3:
            logger.info("经验库经验少于3条，暂不提供推荐")
            return []
        
        return self.retriever.recommend(current_task, experience_db, max_recommendations=max_count)
    
    def export_experiences(
        self,
        format: str = "json",
        output_path: Optional[str] = None,
        filters: Optional[Dict[str, Any]] = None
    ) -> str:
        """
        导出经验
        
        Args:
            format: 导出格式 (md/json/csv/pdf)
            output_path: 输出路径
            filters: 筛选条件
            
        Returns:
            导出内容或文件路径
        """
        experience_db = self.experience_manager.get_all()
        
        if filters:
            return self.exporter.export_filtered(experience_db, filters, format)
        else:
            return self.exporter.export(experience_db, format, output_path)
    
    def manage_duplicates(self, action: str = "find") -> Dict[str, Any]:
        """
        管理重复经验
        
        Args:
            action: 操作类型
                - find: 查找重复
                - merge: 合并重复
                
        Returns:
            处理结果
        """
        if action == "find":
            duplicates = self.experience_manager.find_all_duplicates()
            return {
                "success": True,
                "found": len(duplicates),
                "duplicates": duplicates
            }
        elif action == "merge":
            results = self.experience_manager.batch_merge_duplicates()
            return {
                "success": True,
                "merged": results.get("merged", 0),
                "failed": results.get("failed", 0)
            }
        else:
            return {"success": False, "error": f"不支持的操作: {action}"}
    
    def get_statistics(self) -> Dict[str, Any]:
        """获取统计信息"""
        return self.experience_manager.get_statistics()
    
    def get_all_experiences(self) -> List[Dict[str, Any]]:
        """获取所有经验"""
        return self.experience_manager.get_all()


# ========== 命令行接口 ==========

def main():
    """命令行入口"""
    import argparse
    
    parser = argparse.ArgumentParser(description="Agent经验提炼技能")
    subparsers = parser.add_subparsers(dest="command", help="子命令")
    
    # 提炼经验
    refine_parser = subparsers.add_parser("refine", help="提炼经验")
    refine_parser.add_argument("-i", "--input", required=True, help="任务信息JSON文件")
    refine_parser.add_argument("-o", "--output", help="输出文件")
    
    # 搜索经验
    search_parser = subparsers.add_parser("search", help="搜索经验")
    search_parser.add_argument("query", help="搜索关键词")
    search_parser.add_argument("-n", "--num", type=int, default=10, help="返回数量")
    
    # 导出经验
    export_parser = subparsers.add_parser("export", help="导出经验")
    export_parser.add_argument("-f", "--format", default="json", choices=["json", "md", "csv", "pdf"])
    export_parser.add_argument("-o", "--output", required=True, help="输出文件")
    
    # 查看统计
    subparsers.add_parser("stats", help="查看统计信息")
    
    args = parser.parse_args()
    
    # 创建技能实例
    skill = ExperienceRefiningSkill()
    
    if args.command == "refine":
        # 读取输入
        with open(args.input, 'r', encoding='utf-8') as f:
            task_info = json.load(f)
        
        # 提炼经验
        result = skill.refine_experience(task_info)
        
        # 输出结果
        if result.get("success"):
            print(f"✅ 经验提炼成功: {result['card']['id']}")
            if args.output:
                with open(args.output, 'w', encoding='utf-8') as f:
                    json.dump(result['card'], f, ensure_ascii=False, indent=2)
                print(f"📄 已保存到: {args.output}")
        else:
            print(f"❌ 经验提炼失败: {result.get('error')}")
    
    elif args.command == "search":
        results = skill.search_experiences(args.query)
        print(f"找到 {len(results)} 条相关经验:")
        for i, r in enumerate(results[:args.num], 1):
            card = r["card"]
            print(f"{i}. [{card['id']}] {card['scenario']['task_type']}: {card['scenario']['task_goal'][:40]}... (匹配度: {r['score']:.2f})")
    
    elif args.command == "export":
        output_path = skill.export_experiences(args.format, args.output)
        print(f"✅ 导出完成: {output_path}")
    
    elif args.command == "stats":
        stats = skill.get_statistics()
        print("## 经验库统计")
        print(f"- 总经验数: {stats['total']}")
        print("\n按结果:")
        for k, v in stats["by_result"].items():
            print(f"  - {k}: {v}")
        print("\n按可复用性:")
        for k, v in stats["by_reusability"].items():
            print(f"  - {k}: {v}")


if __name__ == "__main__":
    main()
