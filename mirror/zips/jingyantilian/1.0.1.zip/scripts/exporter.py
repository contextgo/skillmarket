# -*- coding: utf-8 -*-
"""
多格式导出模块
支持Markdown、JSON、CSV、PDF四种格式导出
"""

import os
import csv
import json
import logging
from typing import Dict, List, Optional, Any
from datetime import datetime
from io import StringIO

logger = logging.getLogger(__name__)


class Exporter:
    """多格式导出器"""
    
    SUPPORTED_FORMATS = ["md", "markdown", "json", "csv", "pdf"]
    
    def __init__(self, include_version_history: bool = True, include_relations: bool = True):
        """
        初始化导出器
        
        Args:
            include_version_history: 是否包含版本历史
            include_relations: 是否包含关联关系
        """
        self.include_version_history = include_version_history
        self.include_relations = include_relations
    
    def export(
        self,
        cards: List[Dict[str, Any]],
        format: str = "json",
        output_path: Optional[str] = None,
        **kwargs
    ) -> str:
        """
        导出经验卡片
        
        Args:
            cards: 经验卡片列表
            format: 导出格式 (md/json/csv/pdf)
            output_path: 输出文件路径
            **kwargs: 其他导出选项
            
        Returns:
            导出内容或文件路径
        """
        format = format.lower()
        
        if format not in self.SUPPORTED_FORMATS:
            raise ValueError(f"不支持的格式: {format}")
        
        # 执行导出
        if format in ["md", "markdown"]:
            content = self._export_markdown(cards, **kwargs)
        elif format == "json":
            content = self._export_json(cards, **kwargs)
        elif format == "csv":
            content = self._export_csv(cards, **kwargs)
        elif format == "pdf":
            content = self._export_pdf(cards, **kwargs)
        
        # 保存文件
        if output_path:
            self._save_to_file(content, output_path, format)
            return output_path
        
        return content
    
    def _export_markdown(self, cards: List[Dict[str, Any]], **kwargs) -> str:
        """导出为Markdown格式"""
        lines = []
        lines.append("# 经验库导出")
        lines.append(f"\n> 导出时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append(f"> 经验数量: {len(cards)} 条\n")
        
        for i, card in enumerate(cards, 1):
            lines.append(self._format_card_markdown(card, i))
            lines.append("\n---\n")
        
        return "\n".join(lines)
    
    def _format_card_markdown(self, card: Dict[str, Any], index: int) -> str:
        """格式化单个卡片为Markdown"""
        lines = [f"## 经验卡片 #{card.get('id', index)}"]
        
        # 场景
        scenario = card.get("scenario", {})
        lines.append("\n### 📋 场景")
        lines.append(f"- **任务类型**: {scenario.get('task_type', '未知')}")
        lines.append(f"- **任务目标**: {scenario.get('task_goal', '')}")
        lines.append(f"- **触发条件**: {scenario.get('trigger_condition', '')}")
        
        # 方法
        method = card.get("method", {})
        lines.append("\n### 🎯 方法")
        lines.append(f"- **核心方法**: {method.get('core_method', '')}")
        steps = method.get("steps", [])
        if steps:
            lines.append("- **关键步骤**:")
            for j, step in enumerate(steps, 1):
                lines.append(f"  {j}. {step}")
        skills = method.get("skills", [])
        if skills:
            lines.append(f"- **涉及技能**: {', '.join(skills)}")
        
        # 避坑指南
        pitfalls = card.get("pitfalls", {})
        if pitfalls.get("common_mistakes") or pitfalls.get("solutions"):
            lines.append("\n### ⚠️ 避坑指南")
            mistakes = pitfalls.get("common_mistakes", [])
            if mistakes:
                lines.append("- **常见错误**:")
                for m in mistakes:
                    lines.append(f"  - {m}")
            solutions = pitfalls.get("solutions", [])
            if solutions:
                lines.append("- **解决方案**:")
                for s in solutions:
                    lines.append(f"  - {s}")
        
        # 效果评估
        evaluation = card.get("evaluation", {})
        lines.append("\n### 📊 效果评估")
        success = evaluation.get("success")
        result_text = "✅ 成功" if success else "❌ 失败" if success is False else "⚠️ 待评估"
        lines.append(f"- **结果**: {result_text}")
        lines.append(f"- **结果描述**: {evaluation.get('result_summary', '')}")
        lines.append(f"- **效率提升**: {evaluation.get('efficiency_improvement', '')}")
        lines.append(f"- **可复用性**: {evaluation.get('reusability', '')}")
        
        # 延伸应用
        extensions = card.get("extensions", {})
        scenarios = extensions.get("applicable_scenarios", [])
        if scenarios:
            lines.append("\n### 💡 延伸应用")
            lines.append("- **还能用在**:")
            for s in scenarios:
                lines.append(f"  - {s}")
        
        # 标签
        tags = card.get("tags", [])
        if tags:
            lines.append("\n### 🏷️ 标签")
            lines.append(" ".join(f"#{tag}" for tag in tags))
        
        # 版本历史
        if self.include_version_history:
            history = card.get("version_history", [])
            if len(history) > 1:
                lines.append("\n### 📌 版本历史")
                for h in history:
                    lines.append(f"- {h.get('version', '')} ({h.get('timestamp', '')[:10]}): {h.get('change', '')}")
        
        return "\n".join(lines)
    
    def _export_json(self, cards: List[Dict[str, Any]], **kwargs) -> str:
        """导出为JSON格式"""
        export_data = {
            "export_info": {
                "timestamp": datetime.now().isoformat(),
                "count": len(cards),
                "version": "2.0.3"
            },
            "experiences": []
        }
        
        for card in cards:
            exp = card.copy()
            
            # 选择性包含字段
            if not self.include_version_history:
                exp.pop("version_history", None)
            if not self.include_relations:
                exp.pop("relations", None)
            
            export_data["experiences"].append(exp)
        
        return json.dumps(export_data, ensure_ascii=False, indent=2)
    
    def _export_csv(self, cards: List[Dict[str, Any]], **kwargs) -> str:
        """导出为CSV格式"""
        output = StringIO()
        
        # 定义字段
        fieldnames = [
            "id", "task_type", "task_goal", "core_method",
            "success", "efficiency", "reusability",
            "tags", "created_at", "value_score"
        ]
        
        writer = csv.DictWriter(output, fieldnames=fieldnames)
        writer.writeheader()
        
        for card in cards:
            scenario = card.get("scenario", {})
            method = card.get("method", {})
            evaluation = card.get("evaluation", {})
            
            row = {
                "id": card.get("id", ""),
                "task_type": scenario.get("task_type", ""),
                "task_goal": scenario.get("task_goal", ""),
                "core_method": method.get("core_method", ""),
                "success": "是" if evaluation.get("success") else "否",
                "efficiency": evaluation.get("efficiency_improvement", ""),
                "reusability": evaluation.get("reusability", ""),
                "tags": "|".join(card.get("tags", [])),
                "created_at": card.get("created_at", "")[:10],
                "value_score": card.get("value_score", 0)
            }
            writer.writerow(row)
        
        return output.getvalue()
    
    def _export_pdf(self, cards: List[Dict[str, Any]], **kwargs) -> str:
        """导出为PDF格式"""
        try:
            from reportlab.lib.pagesizes import A4
            from reportlab.lib.styles import getSampleStyleSheet
            from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak
            from reportlab.lib.units import cm
            
            # 创建PDF
            output = StringIO()
            pdf_path = kwargs.get("pdf_path", "./经验库导出.pdf")
            
            doc = SimpleDocTemplate(
                pdf_path,
                pagesize=A4,
                rightMargin=2*cm,
                leftMargin=2*cm,
                topMargin=2*cm,
                bottomMargin=2*cm
            )
            
            styles = getSampleStyleSheet()
            story = []
            
            # 标题
            title = Paragraph("经验库导出", styles['Title'])
            story.append(title)
            story.append(Spacer(1, 0.3*cm))
            
            # 统计信息
            info = Paragraph(
                f"导出时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | 经验数量: {len(cards)}",
                styles['Normal']
            )
            story.append(info)
            story.append(Spacer(1, 0.5*cm))
            
            # 每个经验卡片
            for card in cards:
                story.append(self._format_card_pdf(card, styles))
                story.append(PageBreak())
            
            doc.build(story)
            logger.info(f"PDF导出成功: {pdf_path}")
            return pdf_path
            
        except ImportError:
            logger.warning("reportlab未安装，PDF导出不可用")
            raise ImportError("需要安装reportlab库来支持PDF导出: pip install reportlab")
    
    def _format_card_pdf(self, card: Dict[str, Any], styles) -> List:
        """格式化卡片为PDF元素"""
        from reportlab.platypus import Paragraph, Spacer, Table, TableStyle
        from reportlab.lib import colors
        
        elements = []
        
        # 标题
        card_id = card.get("id", "")
        title = Paragraph(f"<b>经验卡片 #{card_id}</b>", styles['Heading1'])
        elements.append(title)
        elements.append(Spacer(1, 0.3*cm))
        
        # 场景
        scenario = card.get("scenario", {})
        elements.append(Paragraph("<b>📋 场景</b>", styles['Heading2']))
        elements.append(Paragraph(f"任务类型: {scenario.get('task_type', '')}", styles['Normal']))
        elements.append(Paragraph(f"任务目标: {scenario.get('task_goal', '')}", styles['Normal']))
        elements.append(Spacer(1, 0.3*cm))
        
        # 方法
        method = card.get("method", {})
        elements.append(Paragraph("<b>🎯 方法</b>", styles['Heading2']))
        elements.append(Paragraph(f"核心方法: {method.get('core_method', '')}", styles['Normal']))
        skills = method.get("skills", [])
        if skills:
            elements.append(Paragraph(f"涉及技能: {', '.join(skills)}", styles['Normal']))
        elements.append(Spacer(1, 0.3*cm))
        
        # 效果评估
        evaluation = card.get("evaluation", {})
        success = evaluation.get("success")
        result_text = "✅ 成功" if success else "❌ 失败" if success is False else "⚠️ 待评估"
        elements.append(Paragraph("<b>📊 效果评估</b>", styles['Heading2']))
        elements.append(Paragraph(f"结果: {result_text}", styles['Normal']))
        elements.append(Paragraph(f"可复用性: {evaluation.get('reusability', '')}", styles['Normal']))
        elements.append(Spacer(1, 0.3*cm))
        
        # 标签
        tags = card.get("tags", [])
        if tags:
            elements.append(Paragraph("<b>🏷️ 标签</b>", styles['Heading2']))
            elements.append(Paragraph(" ".join(f"#{tag}" for tag in tags), styles['Normal']))
        
        return elements
    
    def _save_to_file(self, content: str, path: str, format: str) -> None:
        """保存内容到文件"""
        try:
            os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
            
            with open(path, 'w', encoding='utf-8') as f:
                f.write(content)
            
            logger.info(f"导出文件已保存: {path}")
        except Exception as e:
            logger.error(f"保存文件失败: {e}")
            raise
    
    def export_filtered(
        self,
        cards: List[Dict[str, Any]],
        filters: Dict[str, Any],
        format: str = "json"
    ) -> str:
        """
        筛选后导出
        
        Args:
            cards: 经验卡片列表
            filters: 筛选条件
                - tags: 标签列表（包含任意一个即可）
                - start_date: 开始日期
                - end_date: 结束日期
                - value_level: 价值等级
                - success: 是否成功
            format: 导出格式
            
        Returns:
            导出内容
        """
        filtered = self._apply_filters(cards, filters)
        return self.export(filtered, format)
    
    def _apply_filters(
        self,
        cards: List[Dict[str, Any]],
        filters: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        """应用筛选条件"""
        result = cards.copy()
        
        # 标签筛选
        if "tags" in filters and filters["tags"]:
            target_tags = set(filters["tags"])
            result = [
                c for c in result
                if target_tags & set(c.get("tags", []))
            ]
        
        # 日期筛选
        start_date = filters.get("start_date")
        end_date = filters.get("end_date")
        if start_date or end_date:
            filtered = []
            for c in result:
                created = c.get("created_at", "")[:10]
                if start_date and created < start_date:
                    continue
                if end_date and created > end_date:
                    continue
                filtered.append(c)
            result = filtered
        
        # 价值等级筛选
        if "value_level" in filters:
            value = filters["value_level"]
            result = [
                c for c in result
                if value in c.get("tags", [])
            ]
        
        # 成功状态筛选
        if "success" in filters:
            success = filters["success"]
            result = [
                c for c in result
                if c.get("evaluation", {}).get("success") == success
            ]
        
        return result
