# -*- coding: utf-8 -*-
"""
多输入方式处理模块
支持对话历史、记忆文件、文件导入等多种输入
"""

import os
import re
import json
import logging
from typing import Dict, List, Optional, Any, Union
from pathlib import Path
from datetime import datetime

from .utils import parse_tags, extract_keywords

logger = logging.getLogger(__name__)


class InputProcessor:
    """多输入处理器"""
    
    # 支持的文件格式
    SUPPORTED_TEXT_FORMATS = {'.txt', '.md', '.markdown'}
    SUPPORTED_DATA_FORMATS = {'.json', '.yaml', '.yml'}
    SUPPORTED_FORMATS = SUPPORTED_TEXT_FORMATS | SUPPORTED_DATA_FORMATS
    
    def __init__(self):
        """初始化处理器"""
        self.current_conversation = []
    
    def process_manual_input(self, text: str) -> Dict[str, Any]:
        """
        处理手动输入
        
        Args:
            text: 用户输入的文本
            
        Returns:
            结构化的任务信息
        """
        task_info = {
            "task_type": self._infer_task_type(text),
            "task_goal": self._extract_goal(text),
            "process": self._extract_process(text),
            "result": self._extract_result(text),
            "notes": self._extract_notes(text),
            "raw_text": text,
            "input_mode": "manual"
        }
        
        # 智能解析其他信息
        if "成功" in text or "完成" in text:
            task_info["success"] = True
        elif "失败" in text or "问题" in text:
            task_info["success"] = False
        
        return task_info
    
    def load_conversation_history(self, history_data: Union[str, List[Dict]]) -> List[Dict]:
        """
        加载对话历史
        
        Args:
            history_data: 对话历史数据（JSON字符串或列表）
            
        Returns:
            处理后的对话列表
        """
        try:
            if isinstance(history_data, str):
                history = json.loads(history_data)
            else:
                history = history_data
            
            processed = []
            for i, msg in enumerate(history):
                if isinstance(msg, dict):
                    processed.append({
                        "role": msg.get("role", "user"),
                        "content": msg.get("content", ""),
                        "timestamp": msg.get("timestamp", datetime.now().isoformat()),
                        "index": i
                    })
            
            self.current_conversation = processed
            logger.info(f"加载对话历史成功: {len(processed)} 条")
            return processed
            
        except Exception as e:
            logger.error(f"加载对话历史失败: {e}")
            return []
    
    def extract_tasks_from_conversation(self, conversation: List[Dict]) -> List[Dict[str, Any]]:
        """
        从对话历史中提取任务信息
        
        Args:
            conversation: 对话列表
            
        Returns:
            提取的任务列表
        """
        tasks = []
        current_task = None
        current_content = []
        
        for msg in conversation:
            role = msg.get("role", "")
            content = msg.get("content", "")
            
            # 用户发起任务
            if role == "user" and self._is_task_start(content):
                if current_task and current_content:
                    # 保存上一个任务
                    task = self._build_task_from_content(current_content)
                    if task:
                        tasks.append(task)
                
                current_task = {"start": content}
                current_content = [content]
            
            elif current_task:
                current_content.append(content)
                
                # 检测任务结束
                if self._is_task_end(content):
                    task = self._build_task_from_content(current_content)
                    if task:
                        tasks.append(task)
                    current_task = None
                    current_content = []
        
        # 处理最后一个任务
        if current_task and current_content:
            task = self._build_task_from_content(current_content)
            if task:
                tasks.append(task)
        
        logger.info(f"从对话中提取任务: {len(tasks)} 个")
        return tasks
    
    def _build_task_from_content(self, content_list: List[str]) -> Optional[Dict[str, Any]]:
        """从内容片段构建任务"""
        full_text = "\n".join(content_list)
        
        # 检查是否包含有效任务信息
        if len(full_text) < 20:
            return None
        
        task_info = {
            "task_type": self._infer_task_type(full_text),
            "task_goal": self._extract_goal(full_text),
            "process": self._extract_process(full_text),
            "result": self._extract_result(full_text),
            "notes": "",
            "raw_text": full_text,
            "input_mode": "conversation"
        }
        
        return task_info
    
    def _is_task_start(self, text: str) -> bool:
        """判断是否任务开始"""
        start_keywords = [
            "我完成", "完成了", "做个", "做一个", "帮我", "我需要",
            "执行", "处理", "进行", "尝试", "开始", "输入"
        ]
        return any(kw in text for kw in start_keywords)
    
    def _is_task_end(self, text: str) -> bool:
        """判断是否任务结束"""
        end_keywords = [
            "完成了", "成功了", "失败了", "结束", "完成",
            "搞定", "好了", "可以了", "就这样", "结果"
        ]
        return any(kw in text for kw in end_keywords)
    
    def import_from_memory_file(
        self,
        memory_path: str = "./MEMORY.md"
    ) -> List[Dict[str, Any]]:
        """
        从记忆文件导入
        
        Args:
            memory_path: 记忆文件路径
            
        Returns:
            提取的经验列表
        """
        experiences = []
        
        try:
            if not os.path.exists(memory_path):
                logger.warning(f"记忆文件不存在: {memory_path}")
                return experiences
            
            with open(memory_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # 解析记忆文件
            sections = self._parse_memory_sections(content)
            
            for section in sections:
                if section.get("type") == "experience":
                    exp = self._convert_memory_to_experience(section)
                    experiences.append(exp)
            
            logger.info(f"从记忆文件导入经验: {len(experiences)} 条")
            
        except Exception as e:
            logger.error(f"从记忆文件导入失败: {e}")
        
        return experiences
    
    def import_from_tools_file(
        self,
        tools_path: str = "./TOOLS.md"
    ) -> List[Dict[str, Any]]:
        """
        从工具文件导入
        
        Args:
            tools_path: 工具文件路径
            
        Returns:
            提取的经验列表
        """
        experiences = []
        
        try:
            if not os.path.exists(tools_path):
                logger.warning(f"工具文件不存在: {tools_path}")
                return experiences
            
            with open(tools_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # 解析工具使用经验
            patterns = [
                r'### (.+?)\n(.+?)(?=### |$)',
                r'## (.+?)\n(.+?)(?=## |$)'
            ]
            
            for pattern in patterns:
                matches = re.findall(pattern, content, re.DOTALL)
                for title, desc in matches:
                    if len(desc.strip()) > 50:  # 过滤短描述
                        exp = {
                            "title": title.strip(),
                            "description": desc.strip(),
                            "tags": extract_keywords(desc, max_keywords=5)
                        }
                        experiences.append(exp)
            
            logger.info(f"从工具文件导入经验: {len(experiences)} 条")
            
        except Exception as e:
            logger.error(f"从工具文件导入失败: {e}")
        
        return experiences
    
    def import_from_file(self, file_path: str) -> Dict[str, Any]:
        """
        从文件导入
        
        Args:
            file_path: 文件路径
            
        Returns:
            导入的数据
        """
        path = Path(file_path)
        suffix = path.suffix.lower()
        
        if not path.exists():
            raise FileNotFoundError(f"文件不存在: {file_path}")
        
        if suffix not in self.SUPPORTED_FORMATS:
            raise ValueError(f"不支持的文件格式: {suffix}")
        
        if suffix in self.SUPPORTED_TEXT_FORMATS:
            return self._import_text_file(path)
        elif suffix in {'.json'}:
            return self._import_json_file(path)
        else:
            return self._import_yaml_file(path)
    
    def _import_text_file(self, path: Path) -> Dict[str, Any]:
        """导入文本文件"""
        with open(path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        return {
            "type": "text",
            "content": content,
            "format": path.suffix,
            "lines": len(content.split('\n'))
        }
    
    def _import_json_file(self, path: Path) -> Dict[str, Any]:
        """导入JSON文件"""
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        return {
            "type": "json",
            "data": data,
            "format": ".json"
        }
    
    def _import_yaml_file(self, path: Path) -> Dict[str, Any]:
        """导入YAML文件"""
        try:
            import yaml
            with open(path, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f)
            
            return {
                "type": "yaml",
                "data": data,
                "format": ".yaml"
            }
        except ImportError:
            logger.warning("PyYAML未安装，尝试解析为文本")
            return self._import_text_file(path)
    
    def _parse_memory_sections(self, content: str) -> List[Dict]:
        """解析记忆文件分区"""
        sections = []
        
        # 按标题分隔
        pattern = r'(?:^|\n)(#{1,3})\s+(.+?)\n(.*?)(?=\n#{1,3}\s+|\Z)'
        matches = re.findall(pattern, content, re.DOTALL)
        
        for match in matches:
            level, title, body = match
            sections.append({
                "level": len(level),
                "title": title.strip(),
                "body": body.strip()
            })
        
        return sections
    
    def _convert_memory_to_experience(self, section: Dict) -> Dict[str, Any]:
        """将记忆转换为经验格式"""
        return {
            "title": section.get("title", ""),
            "description": section.get("body", ""),
            "tags": extract_keywords(section.get("body", ""), max_keywords=5),
            "source": "memory"
        }
    
    def _infer_task_type(self, text: str) -> str:
        """推断任务类型"""
        type_keywords = {
            "设计": ["设计", "方案", "规划", "架构"],
            "开发": ["开发", "编程", "代码", "实现", "调试"],
            "写作": ["写作", "撰写", "编辑", "创作", "写"],
            "分析": ["分析", "研究", "调研", "评估"],
            "沟通": ["沟通", "协调", "讨论", "汇报"]
        }
        
        text_lower = text.lower()
        for type_name, keywords in type_keywords.items():
            if any(kw in text_lower for kw in keywords):
                return type_name
        
        return "通用"
    
    def _extract_goal(self, text: str) -> str:
        """提取任务目标"""
        # 尝试从文本中提取目标描述
        patterns = [
            r'目标[是为：:]\s*(.+?)[。\n]',
            r'想要[做得到]+(.+?)[。\n]',
            r'需要(.+?)[。\n]',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                return match.group(1).strip()
        
        # 返回前100字符作为目标
        return text[:100].strip()
    
    def _extract_process(self, text: str) -> str:
        """提取执行过程"""
        patterns = [
            r'过程[是为：:]\s*(.+?)[。\n]',
            r'步骤[是为：:]\s*(.+?)[。\n]',
            r'方法[是为：:]\s*(.+?)[。\n]',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                return match.group(1).strip()
        
        return ""
    
    def _extract_result(self, text: str) -> str:
        """提取结果"""
        patterns = [
            r'结果[是为：:]\s*(.+?)[。\n]',
            r'成功[是为：:]\s*(.+?)[。\n]',
            r'失败[是为：:]\s*(.+?)[。\n]',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                return match.group(1).strip()
        
        return ""
    
    def _extract_notes(self, text: str) -> str:
        """提取备注"""
        patterns = [
            r'备注[是为：:]\s*(.+?)[。\n]',
            r'注意[是为：:]\s*(.+?)[。\n]',
            r'说明[是为：:]\s*(.+?)[。\n]',
        ]
        
        notes = []
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                notes.append(match.group(1).strip())
        
        return "；".join(notes) if notes else ""
    
    def batch_import(self, file_paths: List[str]) -> List[Dict[str, Any]]:
        """
        批量导入文件
        
        Args:
            file_paths: 文件路径列表
            
        Returns:
            导入的数据列表
        """
        results = []
        
        for path in file_paths:
            try:
                data = self.import_from_file(path)
                results.append(data)
            except Exception as e:
                logger.error(f"批量导入失败 [{path}]: {e}")
        
        return results
