# -*- coding: utf-8 -*-
"""
经验间关联推荐模块
基于多维度识别经验间的关联关系
"""

import logging
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime

from .utils import (
    calculate_similarity,
    calculate_tag_overlap,
    normalize_tags
)

logger = logging.getLogger(__name__)


class RelationRecommender:
    """经验关联推荐器"""
    
    # 关联维度权重
    WEIGHTS = {
        "tag_overlap": 0.35,      # 标签重叠
        "task_type": 0.25,        # 任务类型
        "skill_overlap": 0.20,   # 技能重叠
        "keyword_match": 0.10,   # 关键词匹配
        "scenario_similarity": 0.10  # 场景相似
    }
    
    # 关联类型
    RELATION_TYPES = {
        "strong": "强关联",
        "complementary": "互补",
        "weak": "弱关联"
    }
    
    def __init__(self, min_similarity: float = 0.6):
        """
        初始化推荐器
        
        Args:
            min_similarity: 最小相似度阈值
        """
        self.min_similarity = min_similarity
    
    def find_relations(
        self,
        card: Dict[str, Any],
        experience_db: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """
        查找与指定卡片相关的经验
        
        Args:
            card: 目标经验卡片
            experience_db: 经验库
            
        Returns:
            关联经验列表（按相关性排序）
        """
        if not experience_db:
            return []
        
        relations = []
        
        for exp in experience_db:
            if exp.get("id") == card.get("id"):
                continue
            
            relation = self._analyze_relation(card, exp)
            if relation and relation["score"] >= self.min_similarity:
                relations.append(relation)
        
        # 按分数排序
        relations.sort(key=lambda x: x["score"], reverse=True)
        
        # 限制返回数量
        return relations[:10]
    
    def _analyze_relation(
        self,
        card1: Dict[str, Any],
        card2: Dict[str, Any]
    ) -> Optional[Dict[str, Any]]:
        """分析两个经验卡片的关联"""
        scores = {}
        reasons = []
        
        # 1. 标签重叠分析
        tag_score, tag_reasons = self._analyze_tag_overlap(card1, card2)
        scores["tag_overlap"] = tag_score
        reasons.extend(tag_reasons)
        
        # 2. 任务类型分析
        task_score, task_reasons = self._analyze_task_type(card1, card2)
        scores["task_type"] = task_score
        reasons.extend(task_reasons)
        
        # 3. 技能重叠分析
        skill_score, skill_reasons = self._analyze_skill_overlap(card1, card2)
        scores["skill_overlap"] = skill_score
        reasons.extend(skill_reasons)
        
        # 4. 关键词匹配
        keyword_score, keyword_reasons = self._analyze_keywords(card1, card2)
        scores["keyword_match"] = keyword_score
        reasons.extend(keyword_reasons)
        
        # 5. 场景相似度
        scenario_score, scenario_reasons = self._analyze_scenario(card1, card2)
        scores["scenario_similarity"] = scenario_score
        reasons.extend(scenario_reasons)
        
        # 计算加权总分
        total_score = sum(
            scores[key] * self.WEIGHTS[key]
            for key in scores
        )
        
        # 判断关联类型
        relation_type = self._determine_relation_type(total_score, scores)
        
        return {
            "target_id": card2.get("id"),
            "target_title": self._get_card_title(card2),
            "score": round(total_score, 4),
            "relation_type": relation_type,
            "reasons": reasons[:3],  # 最多3个原因
            "dimension_scores": {k: round(v, 4) for k, v in scores.items()}
        }
    
    def _analyze_tag_overlap(
        self,
        card1: Dict[str, Any],
        card2: Dict[str, Any]
    ) -> Tuple[float, List[str]]:
        """分析标签重叠"""
        tags1 = normalize_tags(card1.get("tags", []))
        tags2 = normalize_tags(card2.get("tags", []))
        
        overlap = calculate_tag_overlap(tags1, tags2)
        
        reasons = []
        if overlap > 0:
            common = set(tags1) & set(tags2)
            if common:
                reasons.append(f"标签重叠: {', '.join(list(common)[:3])}")
        
        return overlap, reasons
    
    def _analyze_task_type(
        self,
        card1: Dict[str, Any],
        card2: Dict[str, Any]
    ) -> Tuple[float, List[str]]:
        """分析任务类型"""
        type_tags = ["设计", "开发", "写作", "分析", "调研", "规划", "沟通"]
        
        types1 = self._extract_type_tags(card1.get("tags", []), type_tags)
        types2 = self._extract_type_tags(card2.get("tags", []), type_tags)
        
        common = set(types1) & set(types2)
        
        if common:
            return 1.0, [f"同为{''.join(common)}类任务"]
        
        # 检查场景描述中的类型
        scenario1 = str(card1.get("scenario", {}).get("task_type", ""))
        scenario2 = str(card2.get("scenario", {}).get("task_type", ""))
        
        if scenario1 and scenario2 and scenario1 == scenario2:
            return 0.8, [f"任务类型相同: {scenario1}"]
        
        return 0.0, []
    
    def _analyze_skill_overlap(
        self,
        card1: Dict[str, Any],
        card2: Dict[str, Any]
    ) -> Tuple[float, List[str]]:
        """分析技能重叠"""
        skills1 = card1.get("method", {}).get("skills", [])
        skills2 = card2.get("method", {}).get("skills", [])
        
        if not skills1 or not skills2:
            return 0.0, []
        
        common = set(skills1) & set(skills2)
        total = set(skills1) | set(skills2)
        
        overlap_ratio = len(common) / len(total) if total else 0
        
        reasons = []
        if common:
            reasons.append(f"技能重叠: {', '.join(list(common)[:2])}")
        
        return overlap_ratio, reasons
    
    def _analyze_keywords(
        self,
        card1: Dict[str, Any],
        card2: Dict[str, Any]
    ) -> Tuple[float, List[str]]:
        """分析关键词匹配"""
        # 从方法描述中提取关键词
        method1 = card1.get("method", {}).get("core_method", "")
        method2 = card2.get("method", {}).get("core_method", "")
        
        # 简单关键词匹配
        words1 = set(method1.lower().split())
        words2 = set(method2.lower().split())
        
        if not words1 or not words2:
            return 0.0, []
        
        common = words1 & words2
        if len(common) >= 2:
            # 过滤停用词
            stopwords = {"的", "了", "是", "在", "和", "与", "或", "以及"}
            significant = [w for w in common if w not in stopwords and len(w) > 1]
            if significant:
                return 0.5, [f"方法关键词匹配: {', '.join(significant[:2])}"]
        
        return 0.0, []
    
    def _analyze_scenario(
        self,
        card1: Dict[str, Any],
        card2: Dict[str, Any]
    ) -> Tuple[float, List[str]]:
        """分析场景相似度"""
        scenario1 = str(card1.get("scenario", {}).get("trigger_condition", ""))
        scenario2 = str(card2.get("scenario", {}).get("trigger_condition", ""))
        
        if not scenario1 or not scenario2:
            return 0.0, []
        
        similarity = calculate_similarity(scenario1, scenario2)
        
        if similarity > 0.5:
            return similarity, ["触发条件相近"]
        
        return similarity, []
    
    def _extract_type_tags(
        self,
        tags: List[str],
        type_tags: List[str]
    ) -> List[str]:
        """提取类型标签"""
        return [t for t in tags if t in type_tags]
    
    def _determine_relation_type(
        self,
        total_score: float,
        dimension_scores: Dict[str, float]
    ) -> str:
        """判断关联类型"""
        if total_score >= 0.7:
            return self.RELATION_TYPES["strong"]
        elif dimension_scores.get("skill_overlap", 0) > 0.5:
            return self.RELATION_TYPES["complementary"]
        else:
            return self.RELATION_TYPES["weak"]
    
    def _get_card_title(self, card: Dict[str, Any]) -> str:
        """获取卡片标题"""
        scenario = card.get("scenario", {})
        task_type = scenario.get("task_type", "未知")
        task_goal = scenario.get("task_goal", "")
        
        if task_goal:
            return f"{task_type}: {task_goal[:30]}"
        return f"{task_type}经验"
    
    def recommend_for_new_card(
        self,
        new_card: Dict[str, Any],
        existing_cards: List[Dict[str, Any]],
        current_batch_cards: Optional[List[Dict[str, Any]]] = None,
        max_recommendations: int = 5
    ) -> Dict[str, Any]:
        """
        为新卡片生成推荐
        
        Args:
            new_card: 新生成的经验卡片
            existing_cards: 现有经验库
            current_batch_cards: 本批次已生成的卡片
            max_recommendations: 最大推荐数量
            
        Returns:
            推荐结果
        """
        recommendations = {
            "from_batch": [],   # 同批次推荐
            "from_library": [], # 知识库推荐
            "complementary": [] # 互补推荐
        }
        
        # 1. 同批次推荐
        if current_batch_cards:
            batch_relations = self.find_relations(new_card, current_batch_cards)
            recommendations["from_batch"] = batch_relations[:2]
        
        # 2. 知识库推荐
        lib_relations = self.find_relations(new_card, existing_cards)
        recommendations["from_library"] = lib_relations[:max_recommendations]
        
        # 3. 互补推荐（成功+失败的对比）
        success_card = self._find_opposite_result_card(new_card, existing_cards)
        if success_card:
            recommendations["complementary"] = [success_card]
        
        return recommendations
    
    def _find_opposite_result_card(
        self,
        card: Dict[str, Any],
        existing_cards: List[Dict[str, Any]]
    ) -> Optional[Dict[str, Any]]:
        """查找结果相反的经验卡片"""
        current_result = card.get("evaluation", {}).get("success")
        if current_result is None:
            return None
        
        target_result = not current_result
        
        for exp in existing_cards:
            exp_result = exp.get("evaluation", {}).get("success")
            if exp_result == target_result:
                # 检查是否有共同的标签
                common_tags = set(card.get("tags", [])) & set(exp.get("tags", []))
                if len(common_tags) >= 1:
                    return {
                        "target_id": exp.get("id"),
                        "target_title": self._get_card_title(exp),
                        "relation_type": "互补",
                        "note": f"与当前{'成功' if target_result else '失败'}经验形成对比"
                    }
        
        return None
    
    def format_recommendation_response(
        self,
        recommendations: Dict[str, Any]
    ) -> str:
        """
        格式化推荐结果为响应文本
        
        Args:
            recommendations: 推荐结果
            
        Returns:
            格式化的响应文本
        """
        lines = ["## 🔗 相关经验推荐"]
        lines.append("")
        
        # 同批次推荐
        if recommendations.get("from_batch"):
            lines.append("### 本次对话相关：")
            for i, rec in enumerate(recommendations["from_batch"], 1):
                lines.append(f"{i}. **{rec['target_title']}** ({rec['relation_type']})")
                lines.append(f"   - 关联原因: {rec['reasons'][0] if rec['reasons'] else '自动关联'}")
            lines.append("")
        
        # 知识库推荐
        if recommendations.get("from_library"):
            lines.append("### 历史经验推荐：")
            for rec in recommendations["from_library"][:5]:
                lines.append(f"- **{rec['target_title']}**")
                lines.append(f"  - 关联度: {rec['score']*100:.0f}% | 类型: {rec['relation_type']}")
            lines.append("")
        
        # 互补推荐
        if recommendations.get("complementary"):
            lines.append("### 💡 对比学习建议：")
            for rec in recommendations["complementary"]:
                lines.append(f"- 查看 **{rec['target_title']}** - {rec['note']}")
        
        return "\n".join(lines)
    
    def batch_find_duplicates(
        self,
        cards: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """
        批量检测重复卡片
        
        Args:
            cards: 卡片列表
            
        Returns:
            重复对列表
        """
        duplicates = []
        
        for i in range(len(cards)):
            for j in range(i + 1, len(cards)):
                relation = self._analyze_relation(cards[i], cards[j])
                
                if relation and relation["score"] >= 0.7:
                    duplicates.append({
                        "card1_id": cards[i].get("id"),
                        "card2_id": cards[j].get("id"),
                        "similarity": relation["score"],
                        "reasons": relation["reasons"]
                    })
        
        return duplicates
