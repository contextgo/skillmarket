# -*- coding: utf-8 -*-
"""
经验卡片生成模块
从任务信息提取结构化经验卡片
"""

import logging
import re
from typing import Dict, List, Optional, Any
from datetime import datetime

from .utils import (
    generate_id,
    parse_tags,
    extract_keywords,
    validate_experience_card,
    calculate_value_score
)
from .config import Config

logger = logging.getLogger(__name__)


class ExperienceCardGenerator:
    """经验卡片生成器"""
    
    # 任务类型关键词映射
    TASK_TYPE_KEYWORDS = {
        "设计": ["设计", "方案", "规划", "架构"],
        "开发": ["开发", "编程", "代码", "实现", "调试"],
        "写作": ["写作", "撰写", "编辑", "创作", "写"],
        "分析": ["分析", "研究", "调研", "评估", "审查"],
        "沟通": ["沟通", "协调", "讨论", "会议", "汇报"],
        "规划": ["计划", "规划", "安排", "策划"]
    }
    
    # 成功/失败判定关键词
    SUCCESS_KEYWORDS = ["成功", "完成", "达成", "实现", "满意", "高效", "顺利"]
    FAILURE_KEYWORDS = ["失败", "错误", "问题", "困难", "阻碍", "不足", "缺陷"]
    
    def __init__(self, config: Optional[Config] = None):
        """
        初始化生成器
        
        Args:
            config: 配置对象
        """
        self.config = config or Config()
        self.tag_categories = {
            "task_type": self.config.get("task_type_tags", []),
            "skill": self.config.get("skill_tags", []),
            "result": self.config.get("result_tags", []),
            "value": self.config.get("value_tags", [])
        }
    
    def generate(
        self,
        task_info: Dict[str, Any],
        existing_cards: Optional[List[Dict]] = None
    ) -> Dict[str, Any]:
        """
        从任务信息生成经验卡片
        
        Args:
            task_info: 任务信息字典，包含:
                - task_type: 任务类型
                - task_goal: 任务目标
                - process: 执行过程
                - result: 最终结果
                - success: 是否成功 (可选)
                - notes: 备注说明 (可选)
            existing_cards: 现有经验卡片列表，用于去重参考
            
        Returns:
            生成的经验卡片字典
        """
        try:
            # 生成卡片ID
            card_id = generate_id(self.config.get("id_prefix", "EXP"))
            
            # 提取各部分内容
            scenario = self._extract_scenario(task_info)
            method = self._extract_method(task_info)
            pitfalls = self._extract_pitfalls(task_info)
            evaluation = self._extract_evaluation(task_info)
            extensions = self._extract_extensions(task_info)
            tags = self._extract_tags(task_info)
            
            # 构建卡片
            card = {
                "id": card_id,
                "scenario": scenario,
                "method": method,
                "pitfalls": pitfalls,
                "evaluation": evaluation,
                "extensions": extensions,
                "tags": tags,
                "created_at": datetime.now().isoformat(),
                "updated_at": datetime.now().isoformat(),
                "version": "v1",
                "version_history": [
                    {
                        "version": "v1",
                        "timestamp": datetime.now().isoformat(),
                        "change": "初始版本"
                    }
                ],
                "relations": []
            }
            
            # 计算价值分数
            card["value_score"] = calculate_value_score(card)
            
            # 验证卡片
            is_valid, errors = validate_experience_card(card)
            if not is_valid:
                logger.warning(f"卡片验证失败: {errors}")
            
            logger.info(f"经验卡片生成成功: {card_id}")
            return card
            
        except Exception as e:
            logger.error(f"经验卡片生成失败: {e}")
            raise
    
    def _extract_scenario(self, task_info: Dict) -> Dict[str, Any]:
        """提取场景信息"""
        return {
            "task_type": task_info.get("task_type", "未知"),
            "task_goal": task_info.get("task_goal", ""),
            "trigger_condition": self._infer_trigger_condition(task_info)
        }
    
    def _extract_method(self, task_info: Dict) -> Dict[str, Any]:
        """提取方法信息"""
        process = task_info.get("process", "")
        
        # 解析关键步骤
        steps = self._parse_steps(process)
        
        # 提取涉及技能
        skills = self._extract_skills(task_info)
        
        return {
            "core_method": self._infer_core_method(task_info),
            "steps": steps,
            "skills": skills
        }
    
    def _extract_pitfalls(self, task_info: Dict) -> Dict[str, Any]:
        """提取避坑指南"""
        # 从备注中提取可能的教训
        notes = task_info.get("notes", "")
        
        pitfalls = {
            "common_mistakes": [],
            "solutions": []
        }
        
        # 分析结果中的问题描述
        result = task_info.get("result", "")
        if any(kw in result for kw in self.FAILURE_KEYWORDS):
            pitfalls["common_mistakes"].append(result)
            pitfalls["solutions"].append("需要进一步分析原因并制定改进措施")
        
        # 从备注中提取教训
        if "注意" in notes or "避免" in notes:
            lessons = re.findall(r'[注意避免].*?[,。；]', notes)
            pitfalls["solutions"].extend(lessons)
        
        return pitfalls
    
    def _extract_evaluation(self, task_info: Dict) -> Dict[str, Any]:
        """提取效果评估"""
        result = task_info.get("result", "")
        success = task_info.get("success")
        
        # 自动判断成功与否
        if success is None:
            success = any(kw in result for kw in self.SUCCESS_KEYWORDS)
        
        # 计算效率提升
        efficiency = self._estimate_efficiency(task_info)
        
        # 评估可复用性
        reusability = self._estimate_reusability(task_info)
        
        return {
            "success": success,
            "result_summary": result[:200] if result else "",
            "efficiency_improvement": efficiency,
            "reusability": reusability
        }
    
    def _extract_extensions(self, task_info: Dict) -> Dict[str, Any]:
        """提取延伸应用"""
        return {
            "applicable_scenarios": self._find_applicable_scenarios(task_info),
            "similar_cases": []
        }
    
    def _extract_tags(self, task_info: Dict) -> List[str]:
        """提取标签"""
        tags = []
        
        # 从配置获取所有可用标签
        all_tags = []
        for category_tags in self.tag_categories.values():
            all_tags.extend(category_tags)
        
        # 从任务信息提取
        task_text = " ".join([
            str(v) for v in task_info.values() if isinstance(v, str)
        ])
        
        # 匹配已有标签
        for tag in all_tags:
            if tag in task_text:
                tags.append(tag)
        
        # 自动推断任务类型标签
        inferred_type = self._infer_task_type(task_info)
        if inferred_type and inferred_type not in tags:
            tags.insert(0, inferred_type)
        
        # 添加结果标签
        result = task_info.get("result", "")
        if any(kw in result for kw in self.SUCCESS_KEYWORDS):
            if "成功" not in tags:
                tags.append("成功")
        elif any(kw in result for kw in self.FAILURE_KEYWORDS):
            if "失败" not in tags:
                tags.append("失败")
        
        # 确保至少有一个标签
        if not tags:
            tags.append("通用")
        
        return list(set(tags))
    
    def _infer_trigger_condition(self, task_info: Dict) -> str:
        """推断触发条件"""
        task_goal = task_info.get("task_goal", "")
        task_type = task_info.get("task_type", "")
        
        conditions = []
        
        if "需要" in task_goal:
            conditions.append("需要完成相关任务时")
        if "解决" in task_goal:
            conditions.append("遇到问题时")
        if "提高" in task_goal:
            conditions.append("需要提升效率时")
        
        if not conditions:
            conditions.append(f"{task_type}相关的任务场景")
        
        return "；".join(conditions) if conditions else "常规任务场景"
    
    def _infer_core_method(self, task_info: Dict) -> str:
        """推断核心方法"""
        process = task_info.get("process", "")
        task_type = task_info.get("task_type", "")
        
        # 提取流程关键词
        method_keywords = re.findall(r'[通过使用按照先再然后最后]+[^\s,，。；]+', process)
        
        if method_keywords:
            return " → ".join(method_keywords[:3])
        
        return f"标准{task_type}流程"
    
    def _parse_steps(self, process: str) -> List[str]:
        """解析步骤列表"""
        steps = []
        
        # 尝试多种分隔符
        separators = ['\n', '；', '。', '；']
        
        for sep in separators:
            if sep in process:
                parts = [p.strip() for p in process.split(sep) if p.strip()]
                if len(parts) > 1:
                    steps = parts
                    break
        
        # 提取序号步骤
        numbered = re.findall(r'^\d+[.、)）]\s*(.+?)$', process, re.MULTILINE)
        if numbered:
            steps = numbered
        
        # 清理步骤
        steps = [s.strip() for s in steps if s.strip()]
        
        # 限制步骤数量
        return steps[:10]
    
    def _extract_skills(self, task_info: Dict) -> List[str]:
        """提取涉及技能"""
        skills = []
        process = task_info.get("process", "")
        
        skill_keywords = {
            "代码能力": ["代码", "编程", "开发", "调试"],
            "写作能力": ["写作", "撰写", "编辑", "文案"],
            "搜索能力": ["搜索", "调研", "查找", "搜集"],
            "分析能力": ["分析", "评估", "研究", "判断"],
            "绘图能力": ["绘图", "设计", "画图", "制图"]
        }
        
        for skill, keywords in skill_keywords.items():
            if any(kw in process for kw in keywords):
                skills.append(skill)
        
        return skills if skills else ["综合能力"]
    
    def _estimate_efficiency(self, task_info: Dict) -> str:
        """估算效率提升"""
        notes = task_info.get("notes", "")
        
        # 尝试提取具体数值
        percent_match = re.search(r'(\d+)%', notes)
        if percent_match:
            percent = int(percent_match.group(1))
            if percent > 0:
                return f"节省{percent}%时间"
            else:
                return f"耗时增加{abs(percent)}%"
        
        # 文字描述
        if "高效" in notes or "快" in notes:
            return "效率显著提升"
        elif "慢" in notes or "耗时" in notes:
            return "存在效率问题"
        
        return "效率一般"
    
    def _estimate_reusability(self, task_info: Dict) -> str:
        """估算可复用性"""
        tags = self._extract_tags(task_info)
        
        # 方法描述详细程度
        process = task_info.get("process", "")
        if len(process) > 100:
            return "高"
        elif len(process) > 50:
            return "中"
        else:
            return "低"
    
    def _infer_task_type(self, task_info: Dict) -> Optional[str]:
        """推断任务类型"""
        task_type = task_info.get("task_type", "")
        task_text = f"{task_type} {task_info.get('process', '')} {task_info.get('task_goal', '')}"
        
        for type_name, keywords in self.TASK_TYPE_KEYWORDS.items():
            if any(kw in task_text for kw in keywords):
                return type_name
        
        return None
    
    def _find_applicable_scenarios(self, task_info: Dict) -> List[str]:
        """查找适用场景"""
        scenarios = []
        task_type = task_info.get("task_type", "")
        
        # 基于任务类型推荐类似场景
        type_scenarios = {
            "设计": ["产品设计", "UI设计", "方案规划"],
            "开发": ["功能开发", "代码重构", "问题修复"],
            "写作": ["文档撰写", "内容创作", "报告编写"],
            "分析": ["数据分析", "市场调研", "竞品分析"],
            "沟通": ["团队协作", "客户沟通", "会议汇报"]
        }
        
        if task_type in type_scenarios:
            scenarios = type_scenarios[task_type]
        
        return scenarios
    
    def generate_from_text(self, text: str) -> Dict[str, Any]:
        """
        从自由文本生成经验卡片
        
        Args:
            text: 描述文本
            
        Returns:
            经验卡片
        """
        # 简单文本解析
        task_info = {
            "task_type": "通用",
            "task_goal": "",
            "process": text,
            "result": ""
        }
        
        # 提取关键词作为任务类型
        keywords = extract_keywords(text, max_keywords=5)
        if keywords:
            task_info["task_goal"] = " ".join(keywords)
        
        return self.generate(task_info)
    
    def batch_generate(self, task_list: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        批量生成经验卡片
        
        Args:
            task_list: 任务信息列表
            
        Returns:
            生成的经验卡片列表
        """
        cards = []
        
        for task in task_list:
            try:
                card = self.generate(task, cards)
                cards.append(card)
            except Exception as e:
                logger.error(f"批量生成失败，单条任务: {e}")
                continue
        
        logger.info(f"批量生成完成: {len(cards)}/{len(task_list)}")
        return cards
