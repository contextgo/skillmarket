# -*- coding: utf-8 -*-
"""
经验库管理模块
提供去重、合并、版本演化等功能
"""

import os
import json
import shutil
import logging
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime
from pathlib import Path

from .utils import (
    calculate_similarity,
    calculate_tag_overlap,
    normalize_tags,
    merge_dicts
)
from .relation_recommender import RelationRecommender

logger = logging.getLogger(__name__)


class ExperienceManager:
    """经验库管理器"""
    
    def __init__(self, storage_path: str = "./data/experience_db.json"):
        """
        初始化管理器
        
        Args:
            storage_path: 经验库存储路径
        """
        self.storage_path = storage_path
        self.relation_recommender = RelationRecommender()
        self._ensure_storage()
        self._load_database()
    
    def _ensure_storage(self) -> None:
        """确保存储目录存在"""
        os.makedirs(os.path.dirname(self.storage_path) or "./data", exist_ok=True)
    
    def _load_database(self) -> None:
        """加载经验库"""
        try:
            if os.path.exists(self.storage_path):
                with open(self.storage_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.experiences = data.get("experiences", [])
                    self.metadata = data.get("metadata", {})
            else:
                self.experiences = []
                self.metadata = {
                    "created_at": datetime.now().isoformat(),
                    "total_count": 0,
                    "last_updated": datetime.now().isoformat()
                }
        except Exception as e:
            logger.error(f"加载经验库失败: {e}")
            self.experiences = []
            self.metadata = {}
    
    def _save_database(self) -> None:
        """保存经验库"""
        try:
            self.metadata["last_updated"] = datetime.now().isoformat()
            self.metadata["total_count"] = len(self.experiences)
            
            data = {
                "experiences": self.experiences,
                "metadata": self.metadata
            }
            
            with open(self.storage_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            
            logger.info(f"经验库已保存: {len(self.experiences)} 条")
        except Exception as e:
            logger.error(f"保存经验库失败: {e}")
            raise
    
    # ========== 基础CRUD操作 ==========
    
    def add(self, card: Dict[str, Any]) -> Tuple[bool, Dict[str, Any]]:
        """
        添加经验卡片
        
        Args:
            card: 经验卡片
            
        Returns:
            (是否成功, 处理结果)
        """
        try:
            # 检查重复
            duplicate = self.find_duplicate(card)
            
            if duplicate:
                return False, {
                    "status": "duplicate",
                    "similar_card": duplicate,
                    "similarity": calculate_similarity(
                        card.get("scenario", {}).get("task_goal", ""),
                        duplicate.get("scenario", {}).get("task_goal", "")
                    )
                }
            
            # 添加卡片
            card["updated_at"] = datetime.now().isoformat()
            self.experiences.append(card)
            self._save_database()
            
            return True, {"status": "added", "card_id": card.get("id")}
            
        except Exception as e:
            logger.error(f"添加经验失败: {e}")
            return False, {"status": "error", "message": str(e)}
    
    def get(self, card_id: str) -> Optional[Dict[str, Any]]:
        """获取指定卡片"""
        for card in self.experiences:
            if card.get("id") == card_id:
                return card
        return None
    
    def get_all(self) -> List[Dict[str, Any]]:
        """获取所有卡片"""
        return self.experiences.copy()
    
    def update(self, card_id: str, updates: Dict[str, Any]) -> Tuple[bool, str]:
        """
        更新经验卡片
        
        Args:
            card_id: 卡片ID
            updates: 更新内容
            
        Returns:
            (是否成功, 消息)
        """
        for i, card in enumerate(self.experiences):
            if card.get("id") == card_id:
                # 记录版本历史
                if self.metadata.get("version_tracking", True):
                    self._add_version_record(card, updates)
                
                # 更新字段
                card.update(updates)
                card["updated_at"] = datetime.now().isoformat()
                
                # 更新版本号
                current_version = card.get("version", "v1")
                version_num = int(current_version[1:]) + 1
                card["version"] = f"v{version_num}"
                
                self._save_database()
                return True, f"已更新至 {card['version']}"
        
        return False, "卡片不存在"
    
    def delete(self, card_id: str) -> bool:
        """删除卡片"""
        for i, card in enumerate(self.experiences):
            if card.get("id") == card_id:
                deleted = self.experiences.pop(i)
                self._save_database()
                logger.info(f"已删除卡片: {card_id}")
                return True
        return False
    
    # ========== 去重与合并 ==========
    
    def find_duplicate(self, new_card: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        查找重复卡片
        
        Args:
            new_card: 新卡片
            
        Returns:
            重复的卡片，未找到返回None
        """
        threshold = 0.7
        
        new_goal = new_card.get("scenario", {}).get("task_goal", "")
        
        for card in self.experiences:
            existing_goal = card.get("scenario", {}).get("task_goal", "")
            
            similarity = calculate_similarity(new_goal, existing_goal)
            if similarity >= threshold:
                return card
            
            # 检查标签重叠
            tag_overlap = calculate_tag_overlap(
                new_card.get("tags", []),
                card.get("tags", [])
            )
            if tag_overlap >= 0.8 and similarity >= 0.5:
                return card
        
        return None
    
    def find_all_duplicates(self) -> List[Dict[str, Any]]:
        """
        查找所有可能的重复
        
        Returns:
            重复对列表
        """
        duplicates = []
        checked = set()
        
        for i, card1 in enumerate(self.experiences):
            for j, card2 in enumerate(self.experiences[i+1:], i+1):
                pair_key = f"{card1.get('id')}-{card2.get('id')}"
                if pair_key in checked:
                    continue
                
                similarity = calculate_similarity(
                    card1.get("scenario", {}).get("task_goal", ""),
                    card2.get("scenario", {}).get("task_goal", "")
                )
                
                if similarity >= 0.7:
                    duplicates.append({
                        "card1": card1,
                        "card2": card2,
                        "similarity": similarity
                    })
                    checked.add(pair_key)
        
        return duplicates
    
    def merge(
        self,
        card1_id: str,
        card2_id: str,
        strategy: str = "auto"
    ) -> Tuple[bool, Optional[Dict[str, Any]]]:
        """
        合并两张经验卡片
        
        Args:
            card1_id: 卡片1 ID
            card2_id: 卡片2 ID
            strategy: 合并策略
                - "keep_first": 保留第一个
                - "keep_second": 保留第二个
                - "auto": 自动合并（取最优）
                
        Returns:
            (是否成功, 合并后的卡片)
        """
        card1 = self.get(card1_id)
        card2 = self.get(card2_id)
        
        if not card1 or not card2:
            return False, None
        
        if strategy == "keep_first":
            merged = card1
        elif strategy == "keep_second":
            merged = card2
        else:
            merged = self._smart_merge(card1, card2)
        
        # 删除旧卡片
        self.delete(card1_id)
        self.delete(card2_id)
        
        # 添加合并后的卡片
        merged["updated_at"] = datetime.now().isoformat()
        self.experiences.append(merged)
        self._save_database()
        
        logger.info(f"合并完成: {card1_id} + {card2_id} -> {merged.get('id')}")
        return True, merged
    
    def _smart_merge(self, card1: Dict[str, Any], card2: Dict[str, Any]) -> Dict[str, Any]:
        """智能合并两张卡片"""
        merged = card1.copy()
        
        # 标签合并（并集）
        tags1 = set(card1.get("tags", []))
        tags2 = set(card2.get("tags", []))
        merged["tags"] = list(tags1 | tags2)
        
        # 方法融合（保留更详细的）
        if len(card1.get("method", {}).get("steps", [])) >= len(card2.get("method", {}).get("steps", [])):
            merged["method"] = card1.get("method", {})
        else:
            merged["method"] = card2.get("method", {})
        
        # 避坑指南合并（并集）
        pitfalls1 = card1.get("pitfalls", {})
        pitfalls2 = card2.get("pitfalls", {})
        merged["pitfalls"] = {
            "common_mistakes": list(set(pitfalls1.get("common_mistakes", []) + pitfalls2.get("common_mistakes", []))),
            "solutions": list(set(pitfalls1.get("solutions", []) + pitfalls2.get("solutions", [])))
        }
        
        # 延伸应用合并
        ext1 = set(card1.get("extensions", {}).get("applicable_scenarios", []))
        ext2 = set(card2.get("extensions", {}).get("applicable_scenarios", []))
        merged["extensions"] = {"applicable_scenarios": list(ext1 | ext2)}
        
        # 效果评估（保留最新的成功结果）
        eval1 = card1.get("evaluation", {})
        eval2 = card2.get("evaluation", {})
        if eval2.get("success") == True:
            merged["evaluation"] = eval2
        else:
            merged["evaluation"] = eval1
        
        # 版本历史
        merged["version_history"] = card1.get("version_history", []) + [
            {
                "version": "merged",
                "timestamp": datetime.now().isoformat(),
                "change": f"合并自 {card1.get('id')} 和 {card2.get('id')}"
            }
        ]
        
        return merged
    
    # ========== 版本管理 ==========
    
    def _add_version_record(self, card: Dict[str, Any], updates: Dict[str, Any]) -> None:
        """添加版本记录"""
        history = card.get("version_history", [])
        current_version = card.get("version", "v1")
        
        history.append({
            "version": current_version,
            "timestamp": datetime.now().isoformat(),
            "change": self._summarize_changes(updates)
        })
        
        card["version_history"] = history
    
    def _summarize_changes(self, updates: Dict[str, Any]) -> str:
        """总结变更内容"""
        changes = []
        for key in updates.keys():
            if key in ["scenario", "method", "pitfalls"]:
                changes.append(f"更新{key}")
            elif key == "tags":
                changes.append("更新标签")
            elif key == "evaluation":
                changes.append("更新效果评估")
            else:
                changes.append(f"更新{key}")
        
        return "; ".join(changes) if changes else "常规更新"
    
    def get_version_history(self, card_id: str) -> Optional[List[Dict[str, Any]]]:
        """获取卡片版本历史"""
        card = self.get(card_id)
        if card:
            return card.get("version_history", [])
        return None
    
    def rollback_to_version(self, card_id: str, version: str) -> Tuple[bool, str]:
        """
        回滚到指定版本
        
        Args:
            card_id: 卡片ID
            version: 版本号
            
        Returns:
            (是否成功, 消息)
        """
        history = self.get_version_history(card_id)
        if not history:
            return False, "版本历史不存在"
        
        # 查找目标版本
        target = None
        for h in history:
            if h.get("version") == version:
                target = h
                break
        
        if not target:
            return False, f"版本 {version} 不存在"
        
        # 更新卡片
        return self.update(card_id, {"version": version})
    
    # ========== 批量操作 ==========
    
    def batch_add(self, cards: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        批量添加卡片
        
        Args:
            cards: 卡片列表
            
        Returns:
            添加结果统计
        """
        results = {
            "total": len(cards),
            "added": 0,
            "duplicates": 0,
            "errors": 0
        }
        
        for card in cards:
            success, info = self.add(card)
            if success:
                results["added"] += 1
            elif info.get("status") == "duplicate":
                results["duplicates"] += 1
            else:
                results["errors"] += 1
        
        return results
    
    def batch_merge_duplicates(self) -> Dict[str, Any]:
        """
        批量合并重复卡片
        
        Returns:
            合并结果统计
        """
        duplicates = self.find_all_duplicates()
        
        results = {
            "found": len(duplicates),
            "merged": 0,
            "failed": 0
        }
        
        for dup in duplicates:
            card1 = dup.get("card1", {})
            card2 = dup.get("card2", {})
            
            success, _ = self.merge(card1.get("id"), card2.get("id"))
            if success:
                results["merged"] += 1
            else:
                results["failed"] += 1
        
        return results
    
    # ========== 统计分析 ==========
    
    def get_statistics(self) -> Dict[str, Any]:
        """获取经验库统计信息"""
        stats = {
            "total": len(self.experiences),
            "by_tag": {},
            "by_result": {},
            "by_reusability": {}
        }
        
        for card in self.experiences:
            # 按标签统计
            for tag in card.get("tags", []):
                stats["by_tag"][tag] = stats["by_tag"].get(tag, 0) + 1
            
            # 按结果统计
            success = card.get("evaluation", {}).get("success")
            result_key = "成功" if success else "失败" if success is False else "待验证"
            stats["by_result"][result_key] = stats["by_result"].get(result_key, 0) + 1
            
            # 按可复用性统计
            reuse = card.get("evaluation", {}).get("reusability", "中")
            stats["by_reusability"][reuse] = stats["by_reusability"].get(reuse, 0) + 1
        
        return stats
    
    def export_summary(self) -> str:
        """导出统计摘要"""
        stats = self.get_statistics()
        
        lines = [
            "## 经验库统计",
            f"- 总经验数: {stats['total']}",
            "",
            "### 按结果分类",
        ]
        
        for result, count in stats["by_result"].items():
            lines.append(f"  - {result}: {count}")
        
        lines.extend(["", "### 按可复用性", ""])
        for reuse, count in stats["by_reusability"].items():
            lines.append(f"  - {reuse}: {count}")
        
        lines.extend(["", "### Top 10 标签", ""])
        sorted_tags = sorted(stats["by_tag"].items(), key=lambda x: x[1], reverse=True)
        for tag, count in sorted_tags[:10]:
            lines.append(f"  - #{tag}: {count}")
        
        return "\n".join(lines)
