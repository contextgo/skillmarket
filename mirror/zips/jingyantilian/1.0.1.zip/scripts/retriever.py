# -*- coding: utf-8 -*-
"""
智能检索引擎模块
提供相似度检测、约束条件、推荐机制
"""

import logging
from typing import Dict, List, Optional, Any, Callable
from datetime import datetime, timedelta

from .utils import (
    calculate_similarity,
    normalize_tags,
    extract_keywords,
    calculate_recency_score,
    calculate_value_score
)
from .relation_recommender import RelationRecommender

logger = logging.getLogger(__name__)


class Retriever:
    """智能检索引擎"""
    
    # 最小匹配度阈值
    MIN_MATCH_SCORE = 0.6
    
    # 最大返回数量
    MAX_RESULTS = 10
    
    # 时效性衰减天数
    RECENCY_DECAY_DAYS = 90
    
    def __init__(
        self,
        min_similarity: float = 0.6,
        max_results: int = 10,
        recency_weight: float = 0.2,
        value_weight: float = 0.3
    ):
        """
        初始化检索引擎
        
        Args:
            min_similarity: 最小相似度阈值
            max_results: 最大返回结果数
            recency_weight: 时效性权重
            value_weight: 价值权重
        """
        self.min_similarity = min_similarity
        self.max_results = max_results
        self.recency_weight = recency_weight
        self.value_weight = value_weight
        self.relation_recommender = RelationRecommender()
        
        # 推荐冷却记录
        self._recommendation_cache: Dict[str, datetime] = {}
    
    def search(
        self,
        query: str,
        experience_db: List[Dict[str, Any]],
        constraints: Optional[Dict[str, Any]] = None,
        sort_by: str = "relevance"
    ) -> List[Dict[str, Any]]:
        """
        搜索经验
        
        Args:
            query: 搜索查询
            experience_db: 经验库
            constraints: 搜索约束
                - tags: 必须在这些标签中
                - exclude_tags: 不能包含这些标签
                - success: 结果状态
                - min_value: 最低价值分数
                - date_range: 日期范围 (start, end)
            sort_by: 排序方式
                - relevance: 相关度
                - recency: 时效性
                - value: 价值
                
        Returns:
            搜索结果列表
        """
        if not experience_db:
            return []
        
        # 解析查询
        query_keywords = extract_keywords(query, max_keywords=10)
        query_lower = query.lower()
        
        # 计算每条经验的匹配度
        scored_results = []
        
        for card in experience_db:
            # 应用约束
            if constraints and not self._check_constraints(card, constraints):
                continue
            
            # 计算基础相关度
            relevance = self._calculate_relevance(
                card, query, query_keywords, query_lower
            )
            
            if relevance < self.min_similarity:
                continue
            
            # 计算综合分数
            recency = calculate_recency_score(
                card.get("updated_at", ""),
                self.RECENCY_DECAY_DAYS
            )
            value = card.get("value_score", calculate_value_score(card))
            
            final_score = (
                relevance * (1 - self.recency_weight - self.value_weight) +
                recency * self.recency_weight +
                value * self.value_weight
            )
            
            scored_results.append({
                "card": card,
                "score": round(final_score, 4),
                "relevance": round(relevance, 4),
                "recency": round(recency, 4),
                "value": round(value, 4)
            })
        
        # 排序
        if sort_by == "recency":
            scored_results.sort(key=lambda x: x["recency"], reverse=True)
        elif sort_by == "value":
            scored_results.sort(key=lambda x: x["value"], reverse=True)
        else:  # relevance
            scored_results.sort(key=lambda x: x["score"], reverse=True)
        
        # 限制返回数量
        return scored_results[:self.max_results]
    
    def _calculate_relevance(
        self,
        card: Dict[str, Any],
        query: str,
        query_keywords: List[str],
        query_lower: str
    ) -> float:
        """计算查询与卡片的关联度"""
        scores = []
        
        # 1. 任务目标匹配
        goal = card.get("scenario", {}).get("task_goal", "")
        if goal:
            goal_sim = calculate_similarity(query_lower, goal.lower())
            scores.append(goal_sim)
        
        # 2. 标签匹配
        card_tags = normalize_tags(card.get("tags", []))
        query_tags = [k.lower() for k in query_keywords]
        tag_matches = sum(1 for t in card_tags if t in query_tags)
        tag_score = tag_matches / max(len(card_tags), 1)
        scores.append(tag_score)
        
        # 3. 方法描述匹配
        method = card.get("method", {}).get("core_method", "")
        if method:
            method_sim = calculate_similarity(query_lower, method.lower())
            scores.append(method_sim * 0.8)
        
        # 4. 场景触发条件匹配
        trigger = card.get("scenario", {}).get("trigger_condition", "")
        if trigger:
            trigger_sim = calculate_similarity(query_lower, trigger.lower())
            scores.append(trigger_sim * 0.5)
        
        # 5. 关键词匹配
        method_steps = " ".join(card.get("method", {}).get("steps", []))
        content = f"{goal} {method} {method_steps}"
        card_keywords = set(extract_keywords(content, max_keywords=10))
        query_keyword_set = set(query_keywords)
        keyword_overlap = len(card_keywords & query_keyword_set) / max(len(card_keywords), 1)
        scores.append(keyword_overlap * 0.6)
        
        # 返回最高分
        return max(scores) if scores else 0.0
    
    def _check_constraints(
        self,
        card: Dict[str, Any],
        constraints: Dict[str, Any]
    ) -> bool:
        """检查是否满足约束"""
        # 标签约束
        if "tags" in constraints:
            required_tags = set(normalize_tags(constraints["tags"]))
            card_tags = set(normalize_tags(card.get("tags", [])))
            if not required_tags & card_tags:  # 没有交集
                return False
        
        # 排除标签
        if "exclude_tags" in constraints:
            excluded = set(normalize_tags(constraints["exclude_tags"]))
            card_tags = set(normalize_tags(card.get("tags", [])))
            if excluded & card_tags:  # 有交集
                return False
        
        # 成功状态
        if "success" in constraints:
            success = card.get("evaluation", {}).get("success")
            if success != constraints["success"]:
                return False
        
        # 最低价值分数
        if "min_value" in constraints:
            value = card.get("value_score", calculate_value_score(card))
            if value < constraints["min_value"]:
                return False
        
        # 日期范围
        if "date_range" in constraints:
            date_range = constraints["date_range"]
            updated = card.get("updated_at", "")[:10]
            if date_range.get("start") and updated < date_range["start"]:
                return False
            if date_range.get("end") and updated > date_range["end"]:
                return False
        
        return True
    
    def recommend(
        self,
        task: Dict[str, Any],
        experience_db: List[Dict[str, Any]],
        user_id: Optional[str] = None,
        max_recommendations: int = 5
    ) -> List[Dict[str, Any]]:
        """
        智能推荐
        
        Args:
            task: 当前任务
            experience_db: 经验库
            user_id: 用户ID（用于去重推荐）
            max_recommendations: 最大推荐数量
            
        Returns:
            推荐结果
        """
        # 检查推荐冷却
        if user_id:
            last_recommend = self._recommendation_cache.get(user_id)
            if last_recommend:
                cooldown = timedelta(hours=24)
                if datetime.now() - last_recommend < cooldown:
                    logger.info(f"推荐冷却中: {user_id}")
        
        # 构建搜索查询
        query = task.get("task_goal", "") + " " + task.get("task_type", "")
        
        # 搜索相关经验
        results = self.search(
            query,
            experience_db,
            constraints={"min_value": 0.3},
            sort_by="value"
        )
        
        # 更新推荐缓存
        if user_id:
            self._recommendation_cache[user_id] = datetime.now()
        
        # 格式化和限制
        recommendations = []
        for r in results[:max_recommendations]:
            recommendations.append({
                "card_id": r["card"].get("id"),
                "title": self._get_card_title(r["card"]),
                "score": r["score"],
                "reason": self._generate_recommend_reason(r["card"], task),
                "preview": self._generate_preview(r["card"])
            })
        
        return recommendations
    
    def _get_card_title(self, card: Dict[str, Any]) -> str:
        """获取卡片标题"""
        scenario = card.get("scenario", {})
        return f"{scenario.get('task_type', '未知')}: {scenario.get('task_goal', '')[:40]}"
    
    def _generate_recommend_reason(self, card: Dict[str, Any], task: Dict[str, Any]) -> str:
        """生成推荐原因"""
        reasons = []
        
        # 标签重叠
        card_tags = set(card.get("tags", []))
        task_tags = set(task.get("tags", []))
        common = card_tags & task_tags
        if common:
            reasons.append(f"标签重叠: {', '.join(list(common)[:2])}")
        
        # 任务类型相同
        card_type = card.get("scenario", {}).get("task_type", "")
        task_type = task.get("task_type", "")
        if card_type == task_type and card_type:
            reasons.append(f"同属{card_type}类任务")
        
        # 高价值
        if card.get("value_score", 0) >= 0.7:
            reasons.append("高价值经验")
        
        # 成功案例
        if card.get("evaluation", {}).get("success"):
            reasons.append("成功经验可借鉴")
        
        return reasons[0] if reasons else "内容相关"
    
    def _generate_preview(self, card: Dict[str, Any]) -> str:
        """生成预览摘要"""
        method = card.get("method", {})
        steps = method.get("steps", [])
        
        if steps:
            preview = steps[0]
            if len(preview) > 50:
                preview = preview[:47] + "..."
            return preview
        
        return card.get("scenario", {}).get("task_goal", "")[:50]
    
    def find_similar(
        self,
        card: Dict[str, Any],
        experience_db: List[Dict[str, Any]],
        top_k: int = 5
    ) -> List[Dict[str, Any]]:
        """
        查找相似经验
        
        Args:
            card: 参考卡片
            experience_db: 经验库
            top_k: 返回数量
            
        Returns:
            相似经验列表
        """
        return self.relation_recommender.find_relations(card, experience_db)[:top_k]
    
    def filter_by_tags(
        self,
        experience_db: List[Dict[str, Any]],
        tags: List[str],
        match_all: bool = False
    ) -> List[Dict[str, Any]]:
        """
        按标签筛选
        
        Args:
            experience_db: 经验库
            tags: 标签列表
            match_all: 是否匹配所有标签
            
        Returns:
            筛选后的列表
        """
        target_tags = set(normalize_tags(tags))
        results = []
        
        for card in experience_db:
            card_tags = set(normalize_tags(card.get("tags", [])))
            
            if match_all:
                if target_tags <= card_tags:  # 是子集
                    results.append(card)
            else:
                if target_tags & card_tags:  # 有交集
                    results.append(card)
        
        return results
    
    def advanced_search(
        self,
        query: str,
        experience_db: List[Dict[str, Any]],
        filters: Optional[Dict[str, Any]] = None,
        boost_conditions: Optional[List[Dict[str, Any]]] = None
    ) -> List[Dict[str, Any]]:
        """
        高级搜索
        
        Args:
            query: 搜索查询
            experience_db: 经验库
            filters: 筛选条件
            boost_conditions: 加权条件
                - [{field: "tags", value: "成功", boost: 1.5}]
                
        Returns:
            搜索结果
        """
        # 基础搜索
        results = self.search(query, experience_db, filters)
        
        # 应用加权
        if boost_conditions:
            for r in results:
                boost = 1.0
                card = r["card"]
                
                for condition in boost_conditions:
                    field = condition["field"]
                    value = condition["value"]
                    boost_factor = condition.get("boost", 1.0)
                    
                    if field == "tags":
                        if value in card.get("tags", []):
                            boost *= boost_factor
                    elif field == "success":
                        if card.get("evaluation", {}).get("success") == value:
                            boost *= boost_factor
                
                r["score"] *= boost
                r["score"] = round(r["score"], 4)
            
            # 重新排序
            results.sort(key=lambda x: x["score"], reverse=True)
        
        return results
    
    def semantic_search(
        self,
        intent: str,
        experience_db: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """
        语义搜索（基于意图）
        
        Args:
            intent: 用户意图描述
            experience_db: 经验库
            
        Returns:
            搜索结果
        """
        # 意图关键词映射
        intent_patterns = {
            "想要成功": {"success": True},
            "避免失败": {"success": False},
            "高效": {"min_value": 0.6},
            "可复用": {"min_value": 0.5}
        }
        
        filters = {}
        for pattern, filter_def in intent_patterns.items():
            if pattern in intent:
                filters.update(filter_def)
        
        return self.search(intent, experience_db, filters)
