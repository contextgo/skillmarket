# -*- coding: utf-8 -*-
"""
配置管理模块
管理技能全局配置项
"""

import os
import json
import logging
from typing import Dict, List, Optional, Any
from datetime import datetime

logger = logging.getLogger(__name__)


class Config:
    """配置管理类"""
    
    # 默认配置
    DEFAULT_CONFIG = {
        # 存储配置
        "storage_path": "./data/experience_db.json",
        "backup_path": "./data/backups/",
        "auto_backup": True,
        "backup_interval": 7,  # 天
        
        # 检索配置
        "min_similarity": 0.6,  # 最小相似度阈值
        "max_results": 10,  # 最大返回结果数
        "recency_weight": 0.2,  # 时效性权重
        "value_weight": 0.3,  # 价值权重
        
        # 经验卡配置
        "id_prefix": "EXP",
        "auto_tagging": True,
        "version_tracking": True,
        
        # 导入导出配置
        "export_formats": ["md", "json", "csv", "pdf"],
        "default_export_format": "json",
        "include_version_history": True,
        "include_relations": True,
        
        # 推荐配置
        "auto_recommend": True,
        "max_recommendations": 5,
        "recommendation_cooldown": 86400,  # 24小时
        
        # 标签系统
        "task_type_tags": ["设计", "开发", "写作", "分析", "调研", "规划", "沟通"],
        "skill_tags": ["代码能力", "写作能力", "搜索能力", "分析能力", "绘图能力"],
        "result_tags": ["成功", "失败", "部分成功", "待验证"],
        "value_tags": ["高价值", "中价值", "低价值"],
        
        # 去重配置
        "dedup_similarity_threshold": 0.7,
        "dedup_auto_merge": False,
        
        # 日志配置
        "log_level": "INFO",
        "log_file": "./logs/experience.log",
    }
    
    def __init__(self, config_path: Optional[str] = None):
        """
        初始化配置
        
        Args:
            config_path: 自定义配置文件路径
        """
        self.config = self.DEFAULT_CONFIG.copy()
        self.config_path = config_path or "./data/config.json"
        self._load_config()
    
    def _load_config(self) -> None:
        """从文件加载配置"""
        try:
            if os.path.exists(self.config_path):
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    user_config = json.load(f)
                    self.config.update(user_config)
                logger.info(f"已加载配置文件: {self.config_path}")
            else:
                self._ensure_directories()
                self._save_config()
                logger.info("使用默认配置，已创建配置文件")
        except Exception as e:
            logger.warning(f"配置加载失败，使用默认配置: {e}")
    
    def _ensure_directories(self) -> None:
        """确保必要目录存在"""
        directories = [
            os.path.dirname(self.config_path),
            self.config.get("backup_path", "./data/backups/"),
            os.path.dirname(self.config.get("log_file", "./logs/experience.log"))
        ]
        for directory in directories:
            if directory:
                os.makedirs(directory, exist_ok=True)
    
    def _save_config(self) -> None:
        """保存配置到文件"""
        try:
            self._ensure_directories()
            with open(self.config_path, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, ensure_ascii=False, indent=2)
            logger.info(f"配置已保存: {self.config_path}")
        except Exception as e:
            logger.error(f"配置保存失败: {e}")
    
    def get(self, key: str, default: Any = None) -> Any:
        """获取配置项"""
        return self.config.get(key, default)
    
    def set(self, key: str, value: Any) -> None:
        """设置配置项"""
        self.config[key] = value
        logger.info(f"配置已更新: {key} = {value}")
    
    def update(self, updates: Dict[str, Any]) -> None:
        """批量更新配置"""
        self.config.update(updates)
        self._save_config()
    
    def reset(self) -> None:
        """重置为默认配置"""
        self.config = self.DEFAULT_CONFIG.copy()
        self._save_config()
        logger.info("配置已重置为默认值")
    
    def get_all(self) -> Dict[str, Any]:
        """获取所有配置"""
        return self.config.copy()
    
    def validate(self) -> tuple[bool, List[str]]:
        """
        验证配置有效性
        
        Returns:
            (是否有效, 错误信息列表)
        """
        errors = []
        
        # 验证数值范围
        if self.config["min_similarity"] < 0 or self.config["min_similarity"] > 1:
            errors.append("min_similarity 必须在 0-1 之间")
        
        if self.config["max_results"] < 1:
            errors.append("max_results 必须大于 0")
        
        if self.config["recency_weight"] < 0 or self.config["recency_weight"] > 1:
            errors.append("recency_weight 必须在 0-1 之间")
        
        # 验证路径
        storage_path = self.config.get("storage_path", "")
        if storage_path and not os.path.exists(os.path.dirname(storage_path)):
            errors.append(f"存储路径目录不存在: {os.path.dirname(storage_path)}")
        
        return len(errors) == 0, errors


# 全局配置实例
_global_config: Optional[Config] = None


def get_config(config_path: Optional[str] = None) -> Config:
    """获取全局配置实例"""
    global _global_config
    if _global_config is None:
        _global_config = Config(config_path)
    return _global_config


def reset_config() -> None:
    """重置全局配置"""
    global _global_config
    _global_config = None
