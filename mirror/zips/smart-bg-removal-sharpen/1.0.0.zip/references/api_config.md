# API 配置指南

本文件说明各在线抠图 API 的 Key 申请方式及配置方法。

---

## 三家 API 横向对比

| 维度 | Remove.bg | 腾讯云 BDA | Clipdrop |
|------|-----------|-----------|----------|
| **覆盖类型** | 通用 | 仅人像 | 通用 |
| **免费额度** | 50 次/月（持续） | 1000 次/月 | 100 次（一次性） |
| **付费单价** | $0.20/张起 | ~¥0.04/次 | 联系销售 |
| **申请门槛** | 网页直接领 ⭐⭐⭐ | 腾讯云账号 ⭐⭐ | 邮件申请 ⭐ |
| **精度** | 业界标杆 | 人像专精 | 自称最强 |
| **速度** | 快 | 快 | 中 |
| **限流** | 无明示 | QPS 默认 5 | 60 req/min |
| **最大尺寸** | 50MP | ~6MB | 25MP / 30MB |
| **环境变量** | `REMOVE_BG_API_KEY` | `TENCENT_SECRET_ID` + `TENCENT_SECRET_KEY` | `CLIPDROP_API_KEY` |

---

## 1. Remove.bg API

### 申请步骤
1. 访问 https://www.remove.bg/api
2. 注册账号并登录
3. 进入 Dashboard → API Keys
4. 免费版：**50 次/月**，支持最高 2MB / 2000×2000px
5. 付费版：$0.20/张（无尺寸限制）

### 配置方式

```bash
# 写入 ~/.zshrc 或 ~/.bashrc
export REMOVE_BG_API_KEY="your_api_key_here"
```

### 调用脚本
```bash
python3 scripts/remove_bg_api.py <input_path> [output_path] --api remove_bg
```

---

## 2. 腾讯云人像分割 API

### 适用场景
- **仅支持人像**（不支持商品/通用物体）
- 高精度人像分割，适合证件照、头像

### 申请步骤
1. 访问 https://console.cloud.tencent.com/bda
2. 开通「人体分析 BDA」服务
3. 进入「访问管理」→「API 密钥管理」
4. 创建 SecretId / SecretKey
5. 免费额度：1000次/月（具体以官网为准）

### 配置方式

```bash
export TENCENT_SECRET_ID="your_secret_id"
export TENCENT_SECRET_KEY="your_secret_key"
```

### 调用脚本
```bash
pip install tencentcloud-sdk-python
python3 scripts/remove_bg_api.py <input_path> [output_path] --api tencent
```

---

## 3. Clipdrop API（已并入 Jasper）

### 适用场景
- 通用抠图，精度对标 Remove.bg
- 适合复杂场景（毛发、半透明物体）
- 同账号还可用 Cleanup / Uncrop / Replace Background 等姊妹 API

### 申请步骤
1. 访问 https://clipdrop.co/apis
2. 发邮件到 `contact@clipdrop.co` 申请 API key
3. 注册即送 **100 credits**（一次性，非每月续期）
4. 1 次成功调用 = 1 credit
5. 如需更多额度联系 Jasper 团队

### 限制
- 最大分辨率：25 百万像素（约 5000×5000）
- 最大文件：30 MB
- 默认限流：60 req/min（可申请提升）

### 配置方式

```bash
export CLIPDROP_API_KEY="your_api_key_here"
```

### 调用脚本
```bash
python3 scripts/remove_bg_api.py <input_path> [output_path] --api clipdrop
```

### 接口细节（已封装在脚本中）

```
POST https://clipdrop-api.co/remove-background/v1
Header: x-api-key: <KEY>
Body:   multipart/form-data, image_file=<binary>
返回：  image/png（响应头带 x-remaining-credits / x-credits-consumed）
```

### 错误码速查

| 状态码 | 含义 |
|--------|------|
| 200 | 成功 |
| 400 | 请求格式错误 / 分辨率超限 |
| 401 | 缺 API key |
| 402 | 额度耗尽 |
| 403 | API key 无效 |
| 429 | 触发限流 |
| 500 | 服务端故障 |

---

## 优先级建议（更新版）

| 场景 | 推荐方式 |
|------|---------|
| 有隐私要求 / 大量图片 / 离线 | 本地 rembg + pymatting（默认） |
| 人像高精度 / 证件照 | 腾讯云 API |
| 通用物体 / 即开即用 | Remove.bg API |
| 复杂场景（发丝/半透明）追求极致 | Clipdrop API |
| 体验生成式背景替换 | Clipdrop（同账号还有 Replace Background） |

---

## 其他可选 API（待扩展）

- **PhotoRoom API**：https://www.photoroom.com/api
- **Pixelcut API**：https://www.pixelcut.ai/api
- **Bria.ai**：https://bria.ai/api

如需支持，可继续扩展 `scripts/remove_bg_api.py`。
