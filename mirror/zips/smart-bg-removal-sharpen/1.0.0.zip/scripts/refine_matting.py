#!/usr/bin/env python3
"""
发丝级精修抠图脚本
工作流：rembg 粗分割 → 生成 trimap → pymatting alpha matting 精修边缘

用法：
  python3 refine_matting.py <input_image> [output_path]
      [--model birefnet-portrait]
      [--kernel 10]  trimap 未知区宽度（像素）
      [--method cf]  matting 算法 (cf=closed-form, knn=KNN)
  python3 refine_matting.py <input_dir> <output_dir> --batch

批量模式会在输出目录额外生成：
  - batch_summary.md
  - batch_summary.json

为什么需要精修：
  - rembg 等分割模型只输出 0/1 硬边缘，发丝/半透明区域会被"一刀切"
  - pymatting 用 alpha matting 算法（求解稀疏线性系统）
  - 能恢复 0~1 连续透明度，发丝、纱、烟雾等细节都能保留
"""

import sys
import os
import json
import argparse
from datetime import datetime
from pathlib import Path

import numpy as np
from PIL import Image

SUPPORTED_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".bmp"}

# rembg
try:
    from rembg import remove, new_session
except ImportError:
    print("ERROR: 未安装 rembg。请运行：pip install 'rembg[cpu]'")
    sys.exit(1)

# pymatting
try:
    from pymatting import estimate_alpha_cf, estimate_alpha_knn, estimate_foreground_ml
except ImportError:
    print("ERROR: 未安装 pymatting。请运行：pip install pymatting numba")
    sys.exit(1)

# scipy for trimap dilation
try:
    from scipy.ndimage import binary_dilation, binary_erosion
except ImportError:
    print("ERROR: 未安装 scipy。请运行：pip install scipy")
    sys.exit(1)


def write_batch_reports(output_dir: str, model: str, kernel_size: int, method: str, rows: list[dict]):
    output_dir = os.path.abspath(output_dir)
    os.makedirs(output_dir, exist_ok=True)

    success_count = sum(1 for row in rows if row["ok"])
    fail_count = len(rows) - success_count
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    json_path = os.path.join(output_dir, "batch_summary.json")
    md_path = os.path.join(output_dir, "batch_summary.md")

    payload = {
        "generated_at": timestamp,
        "mode": "refine-matting",
        "model": model,
        "kernel": kernel_size,
        "method": method,
        "total": len(rows),
        "success": success_count,
        "failed": fail_count,
        "items": rows,
    }

    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)

    md_lines = [
        "# 批量精修抠图处理报告",
        "",
        f"- 生成时间：{timestamp}",
        f"- 模式：refine-matting",
        f"- 模型：{model}",
        f"- kernel：{kernel_size}",
        f"- method：{method}",
        f"- 总数：{len(rows)}",
        f"- 成功：{success_count}",
        f"- 失败：{fail_count}",
        "",
        "## 明细",
        "",
        "| 状态 | 输入文件 | 输出文件 | 错误 |",
        "|------|----------|----------|------|",
    ]

    for row in rows:
        status = "✅" if row["ok"] else "❌"
        input_name = os.path.basename(row["input"]).replace("|", "\\|")
        output_name = os.path.basename(row["output"]).replace("|", "\\|")
        error = (row["error"] or "-").replace("|", "\\|").replace("\n", " ")
        md_lines.append(f"| {status} | {input_name} | {output_name} | {error} |")

    with open(md_path, "w", encoding="utf-8") as f:
        f.write("\n".join(md_lines) + "\n")

    return md_path, json_path


def mask_to_trimap(mask: np.ndarray, kernel_size: int = 10) -> np.ndarray:
    """
    将 rembg 输出的硬 mask 转换为三元 trimap：
      - 0   = 背景（确定）
      - 128 = 未知区（边缘不确定区）
      - 255 = 前景（确定）

    kernel_size 越大，未知区越宽，matting 越能抢救细节但越慢。
    """
    binary = (mask > 127).astype(np.uint8)
    fg_core = binary_erosion(binary, iterations=kernel_size)
    fg_extended = binary_dilation(binary, iterations=kernel_size)

    trimap = np.zeros_like(mask, dtype=np.uint8)
    trimap[fg_extended > 0] = 128
    trimap[fg_core > 0] = 255
    return trimap


def refine_matting(
    input_path: str,
    output_path: str,
    model: str = "birefnet-portrait",
    kernel_size: int = 10,
    method: str = "cf",
    save_debug: bool = False,
):
    print(f"[1/5] 加载图片: {input_path}")
    img = Image.open(input_path).convert("RGB")
    img_arr = np.array(img).astype(np.float64) / 255.0
    h, w = img_arr.shape[:2]
    print(f"    尺寸: {w}x{h}")

    print(f"[2/5] rembg 粗分割（模型: {model}）...")
    session = new_session(model)
    mask_bytes = remove(img, session=session, only_mask=True)
    mask = np.array(mask_bytes)
    print(f"    mask 尺寸: {mask.shape}")

    print(f"[3/5] 生成 trimap（未知区宽度: {kernel_size}px）...")
    trimap = mask_to_trimap(mask, kernel_size=kernel_size)
    trimap_norm = trimap.astype(np.float64) / 255.0

    if save_debug:
        debug_dir = os.path.join(os.path.dirname(output_path), "_debug")
        os.makedirs(debug_dir, exist_ok=True)
        Image.fromarray(mask).save(os.path.join(debug_dir, "01_mask.png"))
        Image.fromarray(trimap).save(os.path.join(debug_dir, "02_trimap.png"))
        print(f"    调试文件: {debug_dir}")

    print(f"[4/5] Alpha Matting 精修（算法: {method}）...")
    if method == "cf":
        alpha = estimate_alpha_cf(img_arr, trimap_norm)
    elif method == "knn":
        alpha = estimate_alpha_knn(img_arr, trimap_norm)
    else:
        raise ValueError(f"未知算法: {method}")

    print(f"[5/5] 前景估计 + 合成 RGBA ...")
    foreground = estimate_foreground_ml(img_arr, alpha)

    rgba = np.zeros((h, w, 4), dtype=np.uint8)
    rgba[..., :3] = (foreground * 255).clip(0, 255).astype(np.uint8)
    rgba[..., 3] = (alpha * 255).clip(0, 255).astype(np.uint8)

    os.makedirs(os.path.dirname(os.path.abspath(output_path)) or ".", exist_ok=True)
    Image.fromarray(rgba, "RGBA").save(output_path)
    print(f"\n✓ 精修完成 → {output_path}")
    return output_path


def process_single(input_path: str, output_path: str, model: str, kernel_size: int, method: str, save_debug: bool = False):
    input_path = os.path.abspath(input_path)
    output_path = os.path.abspath(output_path)

    if not os.path.isfile(input_path):
        error = f"输入文件不存在：{input_path}"
        print(f"ERROR: {error}")
        return {
            "input": input_path,
            "output": output_path,
            "ok": False,
            "status": "failed",
            "model": model,
            "kernel": kernel_size,
            "method": method,
            "error": error,
        }

    try:
        refine_matting(
            input_path=input_path,
            output_path=output_path,
            model=model,
            kernel_size=kernel_size,
            method=method,
            save_debug=save_debug,
        )
        return {
            "input": input_path,
            "output": output_path,
            "ok": True,
            "status": "success",
            "model": model,
            "kernel": kernel_size,
            "method": method,
            "error": "",
        }
    except Exception as exc:
        error = str(exc)
        print(f"ERROR: 精修失败：{error}")
        return {
            "input": input_path,
            "output": output_path,
            "ok": False,
            "status": "failed",
            "model": model,
            "kernel": kernel_size,
            "method": method,
            "error": error,
        }


def refine_matting_batch(input_dir: str, output_dir: str, model: str, kernel_size: int, method: str):
    input_dir = os.path.abspath(input_dir)
    output_dir = os.path.abspath(output_dir)

    if not os.path.isdir(input_dir):
        print(f"ERROR: 输入目录不存在：{input_dir}")
        sys.exit(1)

    os.makedirs(output_dir, exist_ok=True)
    files = sorted(
        f for f in os.listdir(input_dir)
        if os.path.isfile(os.path.join(input_dir, f))
        and Path(f).suffix.lower() in SUPPORTED_EXTS
    )

    if not files:
        print(f"WARNING: 目录中没有找到支持的图片文件：{input_dir}")
        return None

    print(f"[refine] 批量模式：找到 {len(files)} 张图片")
    rows = []
    for index, file_name in enumerate(files, start=1):
        in_path = os.path.join(input_dir, file_name)
        out_path = os.path.join(output_dir, Path(file_name).stem + "_refined.png")
        print(f"[refine] ({index}/{len(files)}) {file_name}")
        rows.append(process_single(in_path, out_path, model, kernel_size, method, save_debug=False))

    md_path, json_path = write_batch_reports(output_dir, model, kernel_size, method, rows)
    success = sum(1 for row in rows if row["ok"])
    fail = len(rows) - success
    print(f"[refine] 批量完成：成功 {success} 张，失败 {fail} 张")
    print(f"[refine] 输出目录：{output_dir}")
    print(f"[refine] 报告：{md_path}")
    print(f"[refine] JSON：{json_path}")

    return {
        "success": success,
        "failed": fail,
        "report_md": md_path,
        "report_json": json_path,
    }


def main():
    parser = argparse.ArgumentParser(description="发丝级精修抠图")
    parser.add_argument("input", help="输入图片路径 或 输入目录（批量模式）")
    parser.add_argument("output", nargs="?", default=None, help="输出路径（默认同名 + _refined.png）或输出目录（批量模式）")
    parser.add_argument("--batch", action="store_true", help="批量处理目录")
    parser.add_argument("--model", default="birefnet-portrait",
                        choices=["birefnet-general", "birefnet-portrait", "birefnet-massive",
                                 "birefnet-general-lite", "isnet-general-use", "u2net"],
                        help="rembg 基础模型（默认 birefnet-portrait）")
    parser.add_argument("--kernel", type=int, default=10,
                        help="trimap 未知区宽度（像素，默认 10，发丝多可调到 15-20）")
    parser.add_argument("--method", default="cf", choices=["cf", "knn"],
                        help="matting 算法：cf=closed-form（默认），knn=KNN matting")
    parser.add_argument("--debug", action="store_true", help="保存中间 mask/trimap（仅单张模式）")
    args = parser.parse_args()

    if args.batch or os.path.isdir(args.input):
        output_dir = args.output or (args.input.rstrip("/") + "_refined")
        summary = refine_matting_batch(args.input, output_dir, args.model, args.kernel, args.method)
        if summary is None:
            sys.exit(1)
        sys.exit(0 if summary["failed"] == 0 else 2)

    input_path = os.path.abspath(args.input)
    if not os.path.isfile(input_path):
        print(f"ERROR: 输入文件不存在：{input_path}")
        sys.exit(1)

    if not args.output:
        stem = Path(input_path).stem
        out_dir = os.path.dirname(input_path) or "."
        args.output = os.path.join(out_dir, stem + "_refined.png")
    output_path = os.path.abspath(args.output)

    result = process_single(
        input_path=input_path,
        output_path=output_path,
        model=args.model,
        kernel_size=args.kernel,
        method=args.method,
        save_debug=args.debug,
    )
    sys.exit(0 if result["ok"] else 1)


if __name__ == "__main__":
    main()
