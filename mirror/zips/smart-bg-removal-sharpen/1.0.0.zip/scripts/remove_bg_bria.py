#!/usr/bin/env python3
"""
BG-Removal: BRIA RMBG-2.0 本地超精度抠图

用法：
  python3 remove_bg_bria.py <input_path> [output_path]
  python3 remove_bg_bria.py <input_dir> <output_dir> --batch

批量模式会在输出目录额外生成：
  - batch_summary.md
  - batch_summary.json

依赖：
  pip install torch torchvision pillow kornia transformers safetensors

说明：
  - 首次运行会从 Hugging Face 下载 briaai/RMBG-2.0 模型
  - 模型许可为非商用（CC BY-NC 4.0），商业使用需与 BRIA 签约
  - 若 BRIA 无法下载/授权失败，会自动回退到 refine_matting.py，再不行回退到 remove_bg.py
"""

import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from refine_matting import refine_matting
from remove_bg import remove_bg_single as remove_bg_standard_single

SUPPORTED_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".bmp"}
MODEL_ID = "briaai/RMBG-2.0"
IMAGE_SIZE = (1024, 1024)
FALLBACK_REFINED_MODEL = "birefnet-portrait"
FALLBACK_REFINED_KERNEL = 15
FALLBACK_REFINED_METHOD = "cf"
FALLBACK_STANDARD_MODEL = "birefnet-general-v3"


class BriaModelUnavailable(RuntimeError):
    pass


def choose_device(explicit_device: str | None = None) -> str:
    import torch

    if explicit_device and explicit_device != "auto":
        return explicit_device
    if torch.cuda.is_available():
        return "cuda"
    if getattr(torch.backends, "mps", None) and torch.backends.mps.is_available():
        return "mps"
    return "cpu"


def load_model(device: str):
    import torch
    from transformers import AutoModelForImageSegmentation

    try:
        model = AutoModelForImageSegmentation.from_pretrained(
            MODEL_ID,
            trust_remote_code=True,
        )
    except Exception as exc:
        msg = str(exc)
        if "401" in msg or "403" in msg or "gated" in msg.lower() or "access" in msg.lower() or "authorized" in msg.lower():
            raise BriaModelUnavailable(
                "无法下载 BRIA RMBG-2.0 模型，可能需要先在 Hugging Face 登录并同意模型条款。\n"
                "模型地址：https://huggingface.co/briaai/RMBG-2.0\n"
                "说明：该模型仅限非商用，商业用途需额外授权。"
            ) from exc
        raise

    model.eval().to(device)
    if hasattr(torch, "set_float32_matmul_precision"):
        try:
            torch.set_float32_matmul_precision("high")
        except Exception:
            pass
    return model


def build_transform():
    from torchvision import transforms

    return transforms.Compose([
        transforms.Resize(IMAGE_SIZE),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
    ])


def infer_alpha(model, image_path: str, device: str):
    import torch
    from PIL import Image
    from torchvision import transforms

    transform_image = build_transform()
    image = Image.open(image_path).convert("RGB")
    original_size = image.size
    input_tensor = transform_image(image).unsqueeze(0).to(device)

    with torch.inference_mode():
        preds = model(input_tensor)
        pred = preds[-1].sigmoid().cpu()[0].squeeze(0)

    mask = transforms.ToPILImage()(pred).resize(original_size, Image.LANCZOS)
    rgba = image.convert("RGBA")
    rgba.putalpha(mask)
    return rgba


def build_result(input_path: str, output_path: str, ok: bool, engine: str, error: str = ""):
    return {
        "input": os.path.abspath(input_path),
        "output": os.path.abspath(output_path),
        "ok": ok,
        "status": "success" if ok else "failed",
        "engine": engine,
        "error": error,
    }


def write_batch_reports(output_dir: str, device: str, auto_fallback: bool, rows: list[dict]):
    output_dir = os.path.abspath(output_dir)
    os.makedirs(output_dir, exist_ok=True)

    success_count = sum(1 for row in rows if row["ok"])
    fail_count = len(rows) - success_count
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    json_path = os.path.join(output_dir, "batch_summary.json")
    md_path = os.path.join(output_dir, "batch_summary.md")

    payload = {
        "generated_at": timestamp,
        "mode": "bria-rmbg-2.0",
        "model": MODEL_ID,
        "device": device,
        "auto_fallback": auto_fallback,
        "total": len(rows),
        "success": success_count,
        "failed": fail_count,
        "items": rows,
    }

    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)

    md_lines = [
        "# 批量超精度抠图处理报告",
        "",
        f"- 生成时间：{timestamp}",
        f"- 模式：bria-rmbg-2.0",
        f"- 模型：{MODEL_ID}",
        f"- 设备：{device}",
        f"- 自动回退：{'开启' if auto_fallback else '关闭'}",
        f"- 总数：{len(rows)}",
        f"- 成功：{success_count}",
        f"- 失败：{fail_count}",
        "",
        "## 明细",
        "",
        "| 状态 | 输入文件 | 输出文件 | 实际引擎 | 错误 |",
        "|------|----------|----------|----------|------|",
    ]

    for row in rows:
        status = "✅" if row["ok"] else "❌"
        input_name = os.path.basename(row["input"]).replace("|", "\\|")
        output_name = os.path.basename(row["output"]).replace("|", "\\|")
        engine = row["engine"].replace("|", "\\|")
        error = (row["error"] or "-").replace("|", "\\|").replace("\n", " ")
        md_lines.append(f"| {status} | {input_name} | {output_name} | {engine} | {error} |")

    with open(md_path, "w", encoding="utf-8") as f:
        f.write("\n".join(md_lines) + "\n")

    return md_path, json_path


def run_fallback(input_path: str, output_path: str):
    print("[fallback] BRIA 不可用，自动回退到发丝级精修 refine_matting.py")
    try:
        refine_matting(
            input_path=input_path,
            output_path=output_path,
            model=FALLBACK_REFINED_MODEL,
            kernel_size=FALLBACK_REFINED_KERNEL,
            method=FALLBACK_REFINED_METHOD,
            save_debug=False,
        )
        print("[fallback] 精修回退成功")
        return build_result(input_path, output_path, True, "fallback-refine")
    except Exception as exc:
        refine_error = str(exc)
        print(f"[fallback] 精修回退失败：{refine_error}")

    print("[fallback] 再次回退到标准 rembg 模式 remove_bg.py")
    standard_result = remove_bg_standard_single(
        input_path=input_path,
        output_path=output_path,
        model_name=FALLBACK_STANDARD_MODEL,
        return_detail=True,
    )
    if standard_result["ok"]:
        print("[fallback] 标准回退成功")
        return build_result(input_path, output_path, True, "fallback-standard")

    print("[fallback] 标准回退也失败")
    combined_error = f"refine: {refine_error}; standard: {standard_result['error']}"
    return build_result(input_path, output_path, False, "fallback-failed", combined_error)


def remove_bg_single(model, input_path: str, output_path: str, device: str, auto_fallback: bool = True, return_detail: bool = False):
    input_path = os.path.abspath(input_path)
    output_path = os.path.abspath(output_path)

    if not os.path.isfile(input_path):
        print(f"ERROR: 输入文件不存在：{input_path}")
        result = build_result(input_path, output_path, False, "bria", f"输入文件不存在：{input_path}")
        return result if return_detail else False

    if model is None:
        if auto_fallback:
            result = run_fallback(input_path, output_path)
            return result if return_detail else result["ok"]
        print("ERROR: BRIA 模型不可用，且已禁用自动回退。")
        result = build_result(input_path, output_path, False, "bria", "BRIA 模型不可用，且已禁用自动回退。")
        return result if return_detail else False

    print(f"[bria] 处理中：{input_path}")
    print(f"[bria] 使用设备：{device}")
    print(f"[bria] 使用模型：{MODEL_ID}")

    try:
        rgba = infer_alpha(model, input_path, device)
        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
        rgba.save(output_path, "PNG")
        print(f"[bria] 完成 → {output_path}")
        result = build_result(input_path, output_path, True, "bria")
        return result if return_detail else True
    except Exception as exc:
        error = str(exc)
        print(f"ERROR: BRIA 处理失败：{error}")
        if auto_fallback:
            result = run_fallback(input_path, output_path)
            return result if return_detail else result["ok"]
        result = build_result(input_path, output_path, False, "bria", error)
        return result if return_detail else False


def remove_bg_batch(model, input_dir: str, output_dir: str, device: str, auto_fallback: bool = True):
    input_dir = os.path.abspath(input_dir)
    output_dir = os.path.abspath(output_dir)

    if not os.path.isdir(input_dir):
        print(f"ERROR: 输入目录不存在：{input_dir}")
        sys.exit(1)

    os.makedirs(output_dir, exist_ok=True)
    files = sorted(
        f for f in os.listdir(input_dir)
        if os.path.isfile(os.path.join(input_dir, f))
        and Path(f).suffix.lower() in SUPPORTED_EXTS
    )

    if not files:
        print(f"WARNING: 目录中没有找到支持的图片文件：{input_dir}")
        return None

    print(f"[bria] 批量模式：找到 {len(files)} 张图片")
    if auto_fallback:
        print("[bria] 自动回退已开启：BRIA 失败时 → 精修模式 → 标准模式")

    rows = []
    for index, file_name in enumerate(files, start=1):
        in_path = os.path.join(input_dir, file_name)
        out_path = os.path.join(output_dir, Path(file_name).stem + "_no_bg.png")
        print(f"[bria] ({index}/{len(files)}) {file_name}")
        rows.append(remove_bg_single(model, in_path, out_path, device, auto_fallback=auto_fallback, return_detail=True))

    md_path, json_path = write_batch_reports(output_dir, device, auto_fallback, rows)
    success = sum(1 for row in rows if row["ok"])
    fail = len(rows) - success

    print(f"[bria] 批量完成：成功 {success} 张，失败 {fail} 张")
    print(f"[bria] 输出目录：{output_dir}")
    print(f"[bria] 报告：{md_path}")
    print(f"[bria] JSON：{json_path}")

    return {
        "success": success,
        "failed": fail,
        "report_md": md_path,
        "report_json": json_path,
    }


def main():
    parser = argparse.ArgumentParser(description="BRIA RMBG-2.0 本地超精度抠图")
    parser.add_argument("input", help="输入图片路径 或 输入目录（批量模式）")
    parser.add_argument("output", nargs="?", default=None, help="输出路径（单张模式）或输出目录（批量模式）")
    parser.add_argument("--batch", action="store_true", help="批量处理目录")
    parser.add_argument("--device", default="auto", choices=["auto", "cpu", "mps", "cuda"], help="推理设备")
    parser.add_argument("--no-fallback", action="store_true", help="BRIA 失败时不自动回退到精修/标准模式")
    args = parser.parse_args()

    device = choose_device(args.device)
    auto_fallback = not args.no_fallback
    model = None
    try:
        model = load_model(device)
    except BriaModelUnavailable as exc:
        print(f"WARNING: {exc}")
        if not auto_fallback:
            sys.exit(1)
        print("WARNING: 将自动改用本地精修模式继续处理。")

    if args.batch or os.path.isdir(args.input):
        output_dir = args.output or (args.input.rstrip("/") + "_no_bg_bria")
        summary = remove_bg_batch(model, args.input, output_dir, device, auto_fallback=auto_fallback)
        if summary is None:
            sys.exit(1)
        sys.exit(0 if summary["failed"] == 0 else 2)
    else:
        if not args.output:
            stem = Path(args.input).stem
            out_dir = os.path.dirname(args.input) or "."
            args.output = os.path.join(out_dir, stem + "_no_bg_bria.png")
        ok = remove_bg_single(model, args.input, args.output, device, auto_fallback=auto_fallback)
        sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
