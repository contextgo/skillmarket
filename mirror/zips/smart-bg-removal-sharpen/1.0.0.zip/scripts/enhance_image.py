#!/usr/bin/env python3
"""
本地图片增强脚本：放大 + 锐化一体
默认面向角色图 / 游戏海报 / 抠图后 PNG。
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

from enhance_common import (
    apply_sharpen_rgba,
    default_output_path,
    list_images,
    load_rgba,
    save_png,
    upscale_rgba,
    write_batch_report,
)


def process_single(input_path: str, output_path: str, scale: float, mode: str, preset: str):
    input_path = os.path.abspath(input_path)
    output_path = os.path.abspath(output_path)
    try:
        img = load_rgba(input_path)
        img = upscale_rgba(img, scale=scale, mode=mode)
        img = apply_sharpen_rgba(img, preset=preset)
        save_png(img, output_path)
        print(f"[enhance] 完成 → {output_path}")
        return {"input": input_path, "output": output_path, "ok": True, "error": ""}
    except Exception as exc:
        error = str(exc)
        print(f"ERROR: 增强失败：{error}")
        return {"input": input_path, "output": output_path, "ok": False, "error": error}


def process_batch(input_dir: str, output_dir: str, scale: float, mode: str, preset: str):
    files = list_images(input_dir)
    if not files:
        print(f"WARNING: 目录中没有找到支持的图片文件：{input_dir}")
        return None

    output_dir = os.path.abspath(output_dir)
    os.makedirs(output_dir, exist_ok=True)
    print(f"[enhance] 批量模式：找到 {len(files)} 张图片")

    rows = []
    for index, input_path in enumerate(files, start=1):
        name = os.path.basename(input_path)
        out_path = os.path.join(output_dir, f"{Path(name).stem}_enhanced.png")
        print(f"[enhance] ({index}/{len(files)}) {name}")
        rows.append(process_single(input_path, out_path, scale, mode, preset))

    md_path, json_path = write_batch_report(
        output_dir,
        title="批量图片增强报告",
        meta={"mode": "enhance", "pipeline": f"upscale x{scale} -> sharpen {preset}", "upscale_mode": mode},
        rows=rows,
    )
    success = sum(1 for row in rows if row["ok"])
    failed = len(rows) - success
    print(f"[enhance] 批量完成：成功 {success} 张，失败 {failed} 张")
    print(f"[enhance] 报告：{md_path}")
    print(f"[enhance] JSON：{json_path}")
    return {"success": success, "failed": failed, "report_md": md_path, "report_json": json_path}


def main():
    parser = argparse.ArgumentParser(description="本地图片增强（放大 + 锐化）")
    parser.add_argument("input", help="输入图片路径 或 输入目录（批量模式）")
    parser.add_argument("output", nargs="?", default=None, help="输出路径（单张）或输出目录（批量）")
    parser.add_argument("--batch", action="store_true", help="批量处理目录")
    parser.add_argument("--scale", type=float, default=2.0, help="放大倍数，默认 2")
    parser.add_argument("--mode", choices=["illustration", "photo", "lineart"], default="illustration", help="放大类型")
    parser.add_argument("--preset", choices=["light", "medium", "strong"], default="light", help="锐化强度预设")
    args = parser.parse_args()

    batch_mode = args.batch or os.path.isdir(args.input)
    if batch_mode:
        output_dir = os.path.abspath(args.output or (os.path.abspath(args.input.rstrip('/')) + "_enhanced"))
        summary = process_batch(args.input, output_dir, args.scale, args.mode, args.preset)
        if summary is None:
            sys.exit(1)
        sys.exit(0 if summary["failed"] == 0 else 2)

    input_path = os.path.abspath(args.input)
    if not os.path.isfile(input_path):
        print(f"ERROR: 输入文件不存在：{input_path}")
        sys.exit(1)
    output_path = os.path.abspath(args.output or default_output_path(input_path, "_enhanced"))
    result = process_single(input_path, output_path, args.scale, args.mode, args.preset)
    sys.exit(0 if result["ok"] else 1)


if __name__ == "__main__":
    main()
