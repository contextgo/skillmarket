#!/usr/bin/env python3
"""
BG-Removal: 在线 API 抠图脚本
支持 Remove.bg / 腾讯云 / Clipdrop 三家 API

用法：
  python3 remove_bg_api.py <input_path> [output_path] --api remove_bg
  python3 remove_bg_api.py <input_path> [output_path] --api tencent
  python3 remove_bg_api.py <input_path> [output_path] --api clipdrop

环境变量：
  REMOVE_BG_API_KEY  — Remove.bg API Key
  TENCENT_SECRET_ID  — 腾讯云 SecretId
  TENCENT_SECRET_KEY — 腾讯云 SecretKey
  CLIPDROP_API_KEY   — Clipdrop API Key
"""

import sys
import os
import argparse
import requests
from pathlib import Path
from PIL import Image
import io

SUPPORTED_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".bmp"}


# ─────────────────────────────────────────
# Remove.bg API
# ─────────────────────────────────────────
def remove_bg_removebg(input_path: str, output_path: str, api_key: str):
    url = "https://api.remove.bg/v1.0/removebg"
    headers = {"X-Api-Key": api_key}
    data = {"size": "auto", "format": "png"}

    with open(input_path, "rb") as f:
        files = {"image_file": f}
        print(f"[Remove.bg] 请求中...")
        resp = requests.post(url, headers=headers, data=data, files=files, timeout=60)

    if resp.status_code == 200:
        os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
        with open(output_path, "wb") as f:
            f.write(resp.content)
        print(f"[Remove.bg] 完成 → {output_path}")
        return True
    else:
        print(f"[Remove.bg] 错误 {resp.status_code}: {resp.text}")
        return False


# ─────────────────────────────────────────
# 腾讯云 API（人像分割）
# ─────────────────────────────────────────
def remove_bg_tencent(input_path: str, output_path: str, secret_id: str, secret_key: str):
    try:
        from tencentcloud.common import credential
        from tencentcloud.common.profile.client_profile import ClientProfile
        from tencentcloud.common.profile.http_profile import HttpProfile
        from tencentcloud.bda.v20200324 import bda_client, models
    except ImportError:
        print("ERROR: 未安装腾讯云 SDK。请运行：pip install tencentcloud-sdk-python")
        sys.exit(1)

    # 读取图片并转 base64
    import base64
    with open(input_path, "rb") as f:
        img_bytes = f.read()
    img_b64 = base64.b64encode(img_bytes).decode("utf-8")

    cred = credential.Credential(secret_id, secret_key)
    http_profile = HttpProfile()
    http_profile.endpoint = "bda.tencentcloudapi.com"
    client_profile = ClientProfile()
    client_profile.httpProfile = http_profile
    client = bda_client.BdaClient(cred, "", client_profile)

    req = models.SegmentPortraitPicRequest()
    req.Image = img_b64
    req.SegmentationOptions = {"BackgroundRemoval": True}

    print(f"[腾讯云] 请求中...")
    resp = client.SegmentPortraitPic(req)

    # 解析返回（返回为 base64 编码的 PNG）
    result_b64 = resp.ResultImage
    result_bytes = base64.b64decode(result_b64)

    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    with open(output_path, "wb") as f:
        f.write(result_bytes)
    print(f"[腾讯云] 完成 → {output_path}")
    return True


# ─────────────────────────────────────────
# Clipdrop API（通用，精度高）
# ─────────────────────────────────────────
def remove_bg_clipdrop(input_path: str, output_path: str, api_key: str):
    url = "https://clipdrop-api.co/remove-background/v1"
    headers = {"x-api-key": api_key, "accept": "image/png"}

    # 根据后缀猜 MIME type
    ext = Path(input_path).suffix.lower()
    mime_map = {
        ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
        ".png": "image/png", ".webp": "image/webp",
    }
    mime = mime_map.get(ext, "image/jpeg")

    with open(input_path, "rb") as f:
        files = {"image_file": (os.path.basename(input_path), f, mime)}
        print(f"[Clipdrop] 请求中...")
        resp = requests.post(url, headers=headers, files=files, timeout=60)

    if resp.status_code == 200:
        os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
        with open(output_path, "wb") as f:
            f.write(resp.content)
        remaining = resp.headers.get("x-remaining-credits", "?")
        consumed = resp.headers.get("x-credits-consumed", "1")
        print(f"[Clipdrop] 完成 → {output_path}")
        print(f"[Clipdrop] 本次消耗 {consumed} credit，剩余 {remaining}")
        return True
    else:
        # 错误码映射（参考官方文档）
        err_map = {
            400: "请求不完整或格式错误（检查 image_file 字段/图片格式/分辨率 ≤25MP）",
            401: "缺少 API key",
            402: "账户额度耗尽，请充值或切换 API",
            403: "API key 无效或已被吊销",
            406: "Accept 请求头不可接受",
            429: "请求过多，触发限流（默认 60 req/min）",
            500: "Clipdrop 服务端错误",
        }
        hint = err_map.get(resp.status_code, "")
        print(f"[Clipdrop] 错误 {resp.status_code}: {hint}")
        try:
            print(f"[Clipdrop] 详情: {resp.json()}")
        except Exception:
            print(f"[Clipdrop] 详情: {resp.text[:200]}")
        return False


def main():
    parser = argparse.ArgumentParser(description="在线 API 抠图")
    parser.add_argument("input", help="输入图片路径")
    parser.add_argument("output", nargs="?", default=None, help="输出路径（默认同名 + _no_bg.png）")
    parser.add_argument("--api", required=True,
                        choices=["remove_bg", "tencent", "clipdrop"],
                        help="API 类型")
    args = parser.parse_args()

    input_path = os.path.abspath(args.input)
    if not os.path.isfile(input_path):
        print(f"ERROR: 输入文件不存在：{input_path}")
        sys.exit(1)

    if not args.output:
        stem = Path(input_path).stem
        out_dir = os.path.dirname(input_path) or "."
        args.output = os.path.join(out_dir, stem + "_no_bg.png")
    output_path = os.path.abspath(args.output)

    if args.api == "remove_bg":
        api_key = os.environ.get("REMOVE_BG_API_KEY")
        if not api_key:
            print("ERROR: 未配置 REMOVE_BG_API_KEY 环境变量。")
            print("       请运行：export REMOVE_BG_API_KEY='your_key_here'")
            sys.exit(1)
        remove_bg_removebg(input_path, output_path, api_key)

    elif args.api == "tencent":
        secret_id = os.environ.get("TENCENT_SECRET_ID")
        secret_key = os.environ.get("TENCENT_SECRET_KEY")
        if not secret_id or not secret_key:
            print("ERROR: 未配置 TENCENT_SECRET_ID / TENCENT_SECRET_KEY 环境变量。")
            sys.exit(1)
        remove_bg_tencent(input_path, output_path, secret_id, secret_key)

    elif args.api == "clipdrop":
        api_key = os.environ.get("CLIPDROP_API_KEY")
        if not api_key:
            print("ERROR: 未配置 CLIPDROP_API_KEY 环境变量。")
            print("       请运行：export CLIPDROP_API_KEY='your_key_here'")
            print("       申请地址：发邮件到 contact@clipdrop.co")
            sys.exit(1)
        remove_bg_clipdrop(input_path, output_path, api_key)


if __name__ == "__main__":
    main()
