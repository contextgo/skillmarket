#!/usr/bin/env python3
"""
本地图片锐化脚本
适合抠图后边缘偏软、角色图线条不够利的场景。
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

from enhance_common import apply_sharpen_rgba, default_output_path, list_images, load_rgba, save_png, write_batch_report


def process_single(input_path: str, output_path: str, preset: str):
    input_path = os.path.abspath(input_path)
    output_path = os.path.abspath(output_path)
    try:
        img = load_rgba(input_path)
        out = apply_sharpen_rgba(img, preset=preset)
        save_png(out, output_path)
        print(f"[sharpen] 完成 → {output_path}")
        return {"input": input_path, "output": output_path, "ok": True, "error": ""}
    except Exception as exc:
        error = str(exc)
        print(f"ERROR: 锐化失败：{error}")
        return {"input": input_path, "output": output_path, "ok": False, "error": error}


def process_batch(input_dir: str, output_dir: str, preset: str):
    files = list_images(input_dir)
    if not files:
        print(f"WARNING: 目录中没有找到支持的图片文件：{input_dir}")
        return None

    output_dir = os.path.abspath(output_dir)
    os.makedirs(output_dir, exist_ok=True)
    print(f"[sharpen] 批量模式：找到 {len(files)} 张图片")

    rows = []
    for index, input_path in enumerate(files, start=1):
        name = os.path.basename(input_path)
        out_path = os.path.join(output_dir, f"{Path(name).stem}_sharpen_{preset}.png")
        print(f"[sharpen] ({index}/{len(files)}) {name}")
        rows.append(process_single(input_path, out_path, preset))

    md_path, json_path = write_batch_report(
        output_dir,
        title="批量图片锐化报告",
        meta={"mode": "sharpen", "preset": preset},
        rows=rows,
    )
    success = sum(1 for row in rows if row["ok"])
    failed = len(rows) - success
    print(f"[sharpen] 批量完成：成功 {success} 张，失败 {failed} 张")
    print(f"[sharpen] 报告：{md_path}")
    print(f"[sharpen] JSON：{json_path}")
    return {"success": success, "failed": failed, "report_md": md_path, "report_json": json_path}


def main():
    parser = argparse.ArgumentParser(description="本地图片锐化")
    parser.add_argument("input", help="输入图片路径 或 输入目录（批量模式）")
    parser.add_argument("output", nargs="?", default=None, help="输出路径（单张）或输出目录（批量）")
    parser.add_argument("--batch", action="store_true", help="批量处理目录")
    parser.add_argument("--preset", choices=["light", "medium", "strong"], default="medium", help="锐化强度预设")
    args = parser.parse_args()

    batch_mode = args.batch or os.path.isdir(args.input)
    if batch_mode:
        output_dir = os.path.abspath(args.output or (os.path.abspath(args.input.rstrip('/')) + f"_sharpen_{args.preset}"))
        summary = process_batch(args.input, output_dir, args.preset)
        if summary is None:
            sys.exit(1)
        sys.exit(0 if summary["failed"] == 0 else 2)

    input_path = os.path.abspath(args.input)
    if not os.path.isfile(input_path):
        print(f"ERROR: 输入文件不存在：{input_path}")
        sys.exit(1)
    output_path = os.path.abspath(args.output or default_output_path(input_path, f"_sharpen_{args.preset}"))
    result = process_single(input_path, output_path, args.preset)
    sys.exit(0 if result["ok"] else 1)


if __name__ == "__main__":
    main()
