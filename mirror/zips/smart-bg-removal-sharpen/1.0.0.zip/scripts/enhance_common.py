#!/usr/bin/env python3
"""
图片增强公共函数
- 渐进式放大
- RGBA 安全锐化
- 批量报告生成
"""

from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Iterable

from PIL import Image, ImageEnhance, ImageFilter

SUPPORTED_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".bmp"}

SHARPEN_PRESETS = {
    "light": {"radius": 1.2, "percent": 135, "threshold": 2, "sharpness": 1.05},
    "medium": {"radius": 1.6, "percent": 180, "threshold": 2, "sharpness": 1.12},
    "strong": {"radius": 2.0, "percent": 220, "threshold": 1, "sharpness": 1.2},
}

UPSCALE_MODES = {"illustration", "photo", "lineart"}


def ensure_parent(path: str):
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)


def list_images(input_dir: str) -> list[str]:
    input_dir = os.path.abspath(input_dir)
    if not os.path.isdir(input_dir):
        raise FileNotFoundError(f"输入目录不存在：{input_dir}")
    return sorted(
        os.path.join(input_dir, name)
        for name in os.listdir(input_dir)
        if os.path.isfile(os.path.join(input_dir, name))
        and Path(name).suffix.lower() in SUPPORTED_EXTS
    )


def default_output_path(input_path: str, suffix: str) -> str:
    input_path = os.path.abspath(input_path)
    stem = Path(input_path).stem
    out_dir = os.path.dirname(input_path) or "."
    return os.path.join(out_dir, f"{stem}{suffix}.png")


def load_rgba(input_path: str) -> Image.Image:
    with Image.open(input_path) as img:
        return img.convert("RGBA")


def save_png(img: Image.Image, output_path: str):
    ensure_parent(output_path)
    img.save(output_path, format="PNG")


def _target_size(width: int, height: int, scale: float) -> tuple[int, int]:
    return max(1, int(round(width * scale))), max(1, int(round(height * scale)))


def apply_sharpen_rgba(img: Image.Image, preset: str) -> Image.Image:
    if preset not in SHARPEN_PRESETS:
        raise ValueError(f"不支持的锐化预设：{preset}")

    params = SHARPEN_PRESETS[preset]
    rgba = img.convert("RGBA")
    rgb = rgba.convert("RGB")
    alpha = rgba.getchannel("A")

    rgb = rgb.filter(
        ImageFilter.UnsharpMask(
            radius=params["radius"],
            percent=params["percent"],
            threshold=params["threshold"],
        )
    )
    rgb = ImageEnhance.Sharpness(rgb).enhance(params["sharpness"])

    merged = rgb.convert("RGBA")
    merged.putalpha(alpha)
    return merged


def _finish_upscale(img: Image.Image, mode: str) -> Image.Image:
    if mode == "illustration":
        return apply_sharpen_rgba(img, "light")
    if mode == "lineart":
        img = apply_sharpen_rgba(img, "medium")
        return img.filter(ImageFilter.EDGE_ENHANCE_MORE)
    if mode == "photo":
        return img
    raise ValueError(f"不支持的放大模式：{mode}")


def upscale_rgba(img: Image.Image, scale: float, mode: str = "illustration") -> Image.Image:
    if scale <= 1:
        return img.convert("RGBA")
    if mode not in UPSCALE_MODES:
        raise ValueError(f"不支持的放大模式：{mode}")

    current = img.convert("RGBA")
    target_w, target_h = _target_size(current.width, current.height, scale)

    while current.width < target_w or current.height < target_h:
        next_w = min(target_w, max(current.width + 1, int(round(current.width * 2))))
        next_h = min(target_h, max(current.height + 1, int(round(current.height * 2))))
        current = current.resize((next_w, next_h), Image.Resampling.LANCZOS)
        if next_w != target_w or next_h != target_h:
            if mode in {"illustration", "lineart"}:
                current = apply_sharpen_rgba(current, "light")

    return _finish_upscale(current, mode)


def write_batch_report(output_dir: str, title: str, meta: dict, rows: list[dict]) -> tuple[str, str]:
    output_dir = os.path.abspath(output_dir)
    os.makedirs(output_dir, exist_ok=True)

    success_count = sum(1 for row in rows if row["ok"])
    fail_count = len(rows) - success_count
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    json_path = os.path.join(output_dir, "batch_summary.json")
    md_path = os.path.join(output_dir, "batch_summary.md")

    payload = {
        "generated_at": timestamp,
        **meta,
        "total": len(rows),
        "success": success_count,
        "failed": fail_count,
        "items": rows,
    }
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)

    md_lines = [f"# {title}", "", f"- 生成时间：{timestamp}"]
    for key, value in meta.items():
        pretty_key = {
            "mode": "模式",
            "scale": "放大倍数",
            "upscale_mode": "放大类型",
            "preset": "锐化预设",
            "pipeline": "处理链路",
        }.get(key, key)
        md_lines.append(f"- {pretty_key}：{value}")
    md_lines.extend([
        f"- 总数：{len(rows)}",
        f"- 成功：{success_count}",
        f"- 失败：{fail_count}",
        "",
        "## 明细",
        "",
        "| 状态 | 输入文件 | 输出文件 | 错误 |",
        "|------|----------|----------|------|",
    ])

    for row in rows:
        status = "✅" if row["ok"] else "❌"
        input_name = os.path.basename(row["input"]).replace("|", "\\|")
        output_name = os.path.basename(row["output"]).replace("|", "\\|")
        error = (row.get("error") or "-").replace("|", "\\|").replace("\n", " ")
        md_lines.append(f"| {status} | {input_name} | {output_name} | {error} |")

    with open(md_path, "w", encoding="utf-8") as f:
        f.write("\n".join(md_lines) + "\n")

    return md_path, json_path
