#!/usr/bin/env python3
"""
BG-Removal 统一入口脚本

目标：
- 不再让调用者记住多个脚本名
- 根据参数把请求路由到标准 / 精修 / 定向提取 / BRIA 模式
- 定向提取（如抠右边角色）优先级最高，自动走多模型融合链路

常见用法：
  python3 run_bg_removal.py image.jpg
  python3 run_bg_removal.py image.jpg --quality refine
  python3 run_bg_removal.py image.jpg --quality best
  python3 run_bg_removal.py image.jpg --subject right
  python3 run_bg_removal.py input_dir out_dir --batch --subject left
"""

import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from remove_bg import remove_bg_single as standard_single, remove_bg_batch as standard_batch
from refine_matting import process_single as refine_single, refine_matting_batch
from extract_target_subject import fuse_target_subject, DEFAULT_MODELS, SUPPORTED_TARGETS
from remove_bg_bria import (
    BriaModelUnavailable,
    choose_device,
    load_model,
    remove_bg_single as bria_single,
    remove_bg_batch as bria_batch,
)

SUPPORTED_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".bmp"}


def resolve_mode(args):
    if args.subject:
        return "subject"
    if args.mode != "auto":
        return args.mode
    if args.quality == "best":
        return "bria"
    if args.quality == "refine":
        return "refine"
    return "standard"


def default_output_for_single(input_path: str, mode: str, subject: str | None):
    stem = Path(input_path).stem
    out_dir = os.path.dirname(os.path.abspath(input_path)) or "."
    if mode == "refine":
        return os.path.join(out_dir, f"{stem}_refined.png")
    if mode == "subject":
        target = subject or "subject"
        return os.path.join(out_dir, f"{stem}_{target}_subject.png")
    return os.path.join(out_dir, f"{stem}_no_bg.png")


def default_output_for_batch(input_dir: str, mode: str, subject: str | None):
    base = os.path.abspath(input_dir.rstrip("/"))
    if mode == "refine":
        return base + "_refined"
    if mode == "subject":
        target = subject or "subject"
        return base + f"_{target}_subject"
    if mode == "bria":
        return base + "_bria"
    return base + "_no_bg"


def write_subject_batch_reports(output_dir: str, target: str, models: list[str], max_gap: int, rows: list[dict]):
    output_dir = os.path.abspath(output_dir)
    os.makedirs(output_dir, exist_ok=True)

    success_count = sum(1 for row in rows if row["ok"])
    fail_count = len(rows) - success_count
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    json_path = os.path.join(output_dir, "batch_summary.json")
    md_path = os.path.join(output_dir, "batch_summary.md")

    payload = {
        "generated_at": timestamp,
        "mode": "target-subject",
        "target": target,
        "models": models,
        "max_gap": max_gap,
        "total": len(rows),
        "success": success_count,
        "failed": fail_count,
        "items": rows,
    }

    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)

    md_lines = [
        "# 批量定向提取处理报告",
        "",
        f"- 生成时间：{timestamp}",
        f"- 模式：target-subject",
        f"- 目标方位：{target}",
        f"- 模型组合：{', '.join(models)}",
        f"- max_gap：{max_gap}",
        f"- 总数：{len(rows)}",
        f"- 成功：{success_count}",
        f"- 失败：{fail_count}",
        "",
        "## 明细",
        "",
        "| 状态 | 输入文件 | 输出文件 | 目标 | 错误 |",
        "|------|----------|----------|------|------|",
    ]

    for row in rows:
        status = "✅" if row["ok"] else "❌"
        input_name = os.path.basename(row["input"]).replace("|", "\\|")
        output_name = os.path.basename(row["output"]).replace("|", "\\|")
        target_label = row.get("target", target).replace("|", "\\|")
        error = (row.get("error") or "-").replace("|", "\\|").replace("\n", " ")
        md_lines.append(f"| {status} | {input_name} | {output_name} | {target_label} | {error} |")

    with open(md_path, "w", encoding="utf-8") as f:
        f.write("\n".join(md_lines) + "\n")

    return md_path, json_path


def subject_single(input_path: str, output_path: str, target: str, models: list[str], max_gap: int, debug: bool = False):
    input_path = os.path.abspath(input_path)
    output_path = os.path.abspath(output_path)
    try:
        result_path = fuse_target_subject(
            input_path=input_path,
            output_path=output_path,
            target=target,
            models=models,
            max_gap=max_gap,
            save_debug=debug,
        )
        return {
            "input": input_path,
            "output": result_path,
            "ok": True,
            "status": "success",
            "target": target,
            "models": models,
            "error": "",
        }
    except Exception as exc:
        error = str(exc)
        print(f"ERROR: 定向提取失败：{error}")
        return {
            "input": input_path,
            "output": output_path,
            "ok": False,
            "status": "failed",
            "target": target,
            "models": models,
            "error": error,
        }


def subject_batch(input_dir: str, output_dir: str, target: str, models: list[str], max_gap: int):
    input_dir = os.path.abspath(input_dir)
    output_dir = os.path.abspath(output_dir)

    if not os.path.isdir(input_dir):
        print(f"ERROR: 输入目录不存在：{input_dir}")
        sys.exit(1)

    os.makedirs(output_dir, exist_ok=True)
    files = sorted(
        f for f in os.listdir(input_dir)
        if os.path.isfile(os.path.join(input_dir, f))
        and Path(f).suffix.lower() in SUPPORTED_EXTS
    )

    if not files:
        print(f"WARNING: 目录中没有找到支持的图片文件：{input_dir}")
        return None

    print(f"[subject] 批量模式：找到 {len(files)} 张图片")
    print(f"[subject] 目标：{target}")
    print(f"[subject] 模型组合：{', '.join(models)}")

    rows = []
    for index, file_name in enumerate(files, start=1):
        in_path = os.path.join(input_dir, file_name)
        out_path = os.path.join(output_dir, f"{Path(file_name).stem}_{target}_subject.png")
        print(f"[subject] ({index}/{len(files)}) {file_name}")
        rows.append(subject_single(in_path, out_path, target, models, max_gap, debug=False))

    md_path, json_path = write_subject_batch_reports(output_dir, target, models, max_gap, rows)
    success = sum(1 for row in rows if row["ok"])
    fail = len(rows) - success
    print(f"[subject] 批量完成：成功 {success} 张，失败 {fail} 张")
    print(f"[subject] 输出目录：{output_dir}")
    print(f"[subject] 报告：{md_path}")
    print(f"[subject] JSON：{json_path}")

    return {
        "success": success,
        "failed": fail,
        "report_md": md_path,
        "report_json": json_path,
    }


def load_bria_or_warn(device: str):
    try:
        return load_model(device)
    except BriaModelUnavailable as exc:
        print(f"WARNING: {exc}")
        print("WARNING: 将自动改用本地精修模式继续处理。")
        return None


def main():
    parser = argparse.ArgumentParser(description="BG-Removal 统一入口")
    parser.add_argument("input", help="输入图片路径 或 输入目录（批量模式）")
    parser.add_argument("output", nargs="?", default=None, help="输出路径（单张）或输出目录（批量）")
    parser.add_argument("--batch", action="store_true", help="批量处理目录")

    parser.add_argument("--mode", default="auto", choices=["auto", "standard", "refine", "subject", "bria"], help="处理模式")
    parser.add_argument("--quality", default="auto", choices=["auto", "fast", "refine", "best"], help="质量偏好（auto=默认, refine=精修, best=BRIA）")
    parser.add_argument("--subject", default=None, choices=sorted(SUPPORTED_TARGETS), help="定向提取目标：left/right/center")

    parser.add_argument("--model", default=None, help="标准/精修模式下的基础模型名")
    parser.add_argument("--subject-models", default=",".join(DEFAULT_MODELS), help="定向提取时使用的模型组合")
    parser.add_argument("--kernel", type=int, default=15, help="精修模式 trimap 未知区宽度")
    parser.add_argument("--method", default="cf", choices=["cf", "knn"], help="精修模式算法")
    parser.add_argument("--max-gap", type=int, default=140, help="定向提取时允许合并近邻附件的最大间距")
    parser.add_argument("--device", default="auto", choices=["auto", "cpu", "mps", "cuda"], help="BRIA 推理设备")
    parser.add_argument("--no-fallback", action="store_true", help="BRIA 失败时不自动回退")
    parser.add_argument("--debug", action="store_true", help="保存调试中间结果（仅单张有效）")
    args = parser.parse_args()

    mode = resolve_mode(args)
    subject_models = [item.strip() for item in args.subject_models.split(",") if item.strip()]
    if mode == "subject" and not args.subject:
        print("ERROR: 定向提取模式必须指定 --subject left|right|center")
        sys.exit(1)
    if mode == "subject" and not subject_models:
        print("ERROR: --subject-models 不能为空")
        sys.exit(1)

    if args.mode == "subject" and args.subject:
        print(f"[router] 显式 subject 模式 → 提取 {args.subject} 目标")
    elif args.subject:
        print(f"[router] 检测到 --subject={args.subject} → 自动切换到定向提取")
    elif mode == "bria":
        print("[router] 质量偏好=best → 路由到 BRIA 超精度模式")
    elif mode == "refine":
        print("[router] 质量偏好=refine → 路由到发丝级精修模式")
    else:
        print("[router] 默认路由到标准抠图模式")

    batch_mode = args.batch or os.path.isdir(args.input)

    if batch_mode:
        output_dir = os.path.abspath(args.output or default_output_for_batch(args.input, mode, args.subject))
        if mode == "subject":
            summary = subject_batch(args.input, output_dir, args.subject, subject_models, args.max_gap)
        elif mode == "refine":
            model = args.model or "birefnet-portrait"
            summary = refine_matting_batch(args.input, output_dir, model, args.kernel, args.method)
        elif mode == "bria":
            device = choose_device(args.device)
            model = load_bria_or_warn(device)
            summary = bria_batch(model, args.input, output_dir, device, auto_fallback=not args.no_fallback)
        else:
            model = args.model or "birefnet-general-v3"
            summary = standard_batch(args.input, output_dir, model)

        if summary is None:
            sys.exit(1)
        sys.exit(0 if summary["failed"] == 0 else 2)

    input_path = os.path.abspath(args.input)
    if not os.path.isfile(input_path):
        print(f"ERROR: 输入文件不存在：{input_path}")
        sys.exit(1)

    output_path = os.path.abspath(args.output or default_output_for_single(input_path, mode, args.subject))

    if mode == "subject":
        result = subject_single(input_path, output_path, args.subject, subject_models, args.max_gap, debug=args.debug)
        sys.exit(0 if result["ok"] else 1)

    if mode == "refine":
        model = args.model or "birefnet-portrait"
        result = refine_single(input_path, output_path, model, args.kernel, args.method, save_debug=args.debug)
        sys.exit(0 if result["ok"] else 1)

    if mode == "bria":
        device = choose_device(args.device)
        model = load_bria_or_warn(device)
        result = bria_single(model, input_path, output_path, device, auto_fallback=not args.no_fallback, return_detail=True)
        sys.exit(0 if result["ok"] else 1)

    model = args.model or "birefnet-general-v3"
    result = standard_single(input_path, output_path, model_name=model, return_detail=True)
    sys.exit(0 if result["ok"] else 1)


if __name__ == "__main__":
    main()
