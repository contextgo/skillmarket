#!/usr/bin/env python3
"""
从多主体图片中提取指定目标主体（左/右/中间），适合游戏海报、双人图、群像图。

核心思路：
1. 用多个 rembg 模型分别抠出整张图前景
2. 在每个模型结果里定位目标侧（left/right/center）的主主体
3. 对各模型选中的目标 alpha 取最大值融合
4. 可选：合并靠近主体边界的卫星部件（武器、头绳、飘带、尾巴等）
5. 裁剪成单独透明 PNG

为什么需要这个脚本：
- 只用单一 portrait 模型时，常会漏掉角色附件（佩剑、头饰、飘带）
- 通用模型能补回附件，但边缘有时不如 portrait 干净
- 多模型融合能兼顾「主体边缘」和「离散配件」

用法：
  python3 extract_target_subject.py <input_image> [output_path] --target right
  python3 extract_target_subject.py <input_image> [output_path] --target left --models birefnet-portrait,birefnet-general,u2net
"""

import argparse
import math
import os
import sys
from pathlib import Path

import numpy as np
from PIL import Image
from scipy import ndimage

try:
    from rembg import remove, new_session
except ImportError:
    print("ERROR: 未安装 rembg。请运行：pip install 'rembg[cpu]'")
    sys.exit(1)

DEFAULT_MODELS = ["birefnet-portrait", "birefnet-general"]
SUPPORTED_TARGETS = {"left", "right", "center"}


def expand_bbox(bbox, margin_x, margin_y, width, height):
    x0, y0, x1, y1 = bbox
    return (
        max(0, x0 - margin_x),
        max(0, y0 - margin_y),
        min(width, x1 + margin_x),
        min(height, y1 + margin_y),
    )


def bbox_gap(a, b):
    ax0, ay0, ax1, ay1 = a
    bx0, by0, bx1, by1 = b
    dx = max(0, max(ax0 - bx1, bx0 - ax1))
    dy = max(0, max(ay0 - by1, by0 - ay1))
    return math.hypot(dx, dy)


def component_score(comp, width, target):
    area = comp["area"]
    cx = comp["cx"]
    if target == "right":
        side_bonus = max(0.0, (cx / width) - 0.5) * area * 0.8
    elif target == "left":
        side_bonus = max(0.0, 0.5 - (cx / width)) * area * 0.8
    else:
        side_bonus = max(0.0, 1.0 - abs((cx / width) - 0.5) * 2.0) * area * 0.4
    return area + side_bonus


def side_filter(components, width, target):
    if target == "right":
        picked = [c for c in components if c["cx"] >= width * 0.52]
        return picked or sorted(components, key=lambda c: c["cx"], reverse=True)
    if target == "left":
        picked = [c for c in components if c["cx"] <= width * 0.48]
        return picked or sorted(components, key=lambda c: c["cx"])
    return components


def extract_components(alpha, alpha_threshold, min_area):
    mask = alpha > alpha_threshold
    labeled, num_features = ndimage.label(mask)
    if num_features == 0:
        return []

    objects = ndimage.find_objects(labeled)
    components = []
    for comp_id, slc in enumerate(objects, start=1):
        if slc is None:
            continue
        ys, xs = np.where(labeled == comp_id)
        area = len(xs)
        if area < min_area:
            continue
        x0, x1 = slc[1].start, slc[1].stop
        y0, y1 = slc[0].start, slc[0].stop
        comp_mask = labeled == comp_id
        comp_alpha = np.where(comp_mask, alpha, 0)
        components.append({
            "id": comp_id,
            "area": area,
            "cx": float(xs.mean()),
            "cy": float(ys.mean()),
            "bbox": (x0, y0, x1, y1),
            "mask": comp_mask,
            "alpha": comp_alpha,
        })
    return components


def merge_satellites(anchor, candidates, width, height, target, max_gap, min_satellite_area):
    anchor_bbox = anchor["bbox"]
    merged_alpha = anchor["alpha"].copy()
    merged_components = [anchor]

    bbox_w = anchor_bbox[2] - anchor_bbox[0]
    bbox_h = anchor_bbox[3] - anchor_bbox[1]
    expanded_bbox = expand_bbox(
        anchor_bbox,
        margin_x=max(80, int(bbox_w * 0.35)),
        margin_y=max(80, int(bbox_h * 0.25)),
        width=width,
        height=height,
    )

    for comp in candidates:
        if comp["id"] == anchor["id"]:
            continue
        if comp["area"] < min_satellite_area:
            continue
        cx = comp["cx"]
        if target == "right" and cx < width * 0.45:
            continue
        if target == "left" and cx > width * 0.55:
            continue

        gap = bbox_gap(anchor_bbox, comp["bbox"])
        bx0, by0, bx1, by1 = comp["bbox"]
        ex0, ey0, ex1, ey1 = expanded_bbox
        inside_expanded = bx1 >= ex0 and bx0 <= ex1 and by1 >= ey0 and by0 <= ey1
        if inside_expanded or gap <= max_gap:
            merged_alpha = np.maximum(merged_alpha, comp["alpha"])
            merged_components.append(comp)

    return merged_alpha, merged_components


def select_target_from_model(img, model_name, target, alpha_threshold, min_area, max_gap, min_satellite_area):
    print(f"[model] 运行 {model_name} ...")
    session = new_session(model_name)
    cutout = remove(img, session=session)
    arr = np.array(cutout)
    alpha = arr[:, :, 3]
    height, width = alpha.shape

    components = extract_components(alpha, alpha_threshold=alpha_threshold, min_area=min_area)
    if not components:
        raise RuntimeError(f"{model_name}: 未找到有效前景组件")

    candidates = side_filter(components, width, target)
    candidates = sorted(candidates, key=lambda comp: component_score(comp, width, target), reverse=True)
    anchor = candidates[0]
    merged_alpha, merged_components = merge_satellites(
        anchor=anchor,
        candidates=components,
        width=width,
        height=height,
        target=target,
        max_gap=max_gap,
        min_satellite_area=min_satellite_area,
    )

    x0, y0, x1, y1 = anchor["bbox"]
    print(
        f"        anchor area={anchor['area']} bbox=({x0},{y0})-({x1},{y1}) "
        f"merged_parts={len(merged_components)}"
    )
    return {
        "model": model_name,
        "alpha": merged_alpha,
        "anchor": anchor,
        "merged_parts": merged_components,
    }


def fuse_target_subject(
    input_path,
    output_path,
    target,
    models,
    alpha_threshold=10,
    min_area=400,
    min_satellite_area=120,
    max_gap=140,
    padding=12,
    save_debug=False,
):
    input_path = os.path.abspath(input_path)
    output_path = os.path.abspath(output_path)
    if not os.path.isfile(input_path):
        raise FileNotFoundError(f"输入文件不存在：{input_path}")

    if target not in SUPPORTED_TARGETS:
        raise ValueError(f"target 必须是 {sorted(SUPPORTED_TARGETS)}")

    img = Image.open(input_path).convert("RGBA")
    width, height = img.size
    print(f"[input] {input_path}")
    print(f"[input] size = {width}x{height}")
    print(f"[target] {target}")
    print(f"[models] {', '.join(models)}")

    results = []
    for model_name in models:
        results.append(
            select_target_from_model(
                img=img,
                model_name=model_name,
                target=target,
                alpha_threshold=alpha_threshold,
                min_area=min_area,
                max_gap=max_gap,
                min_satellite_area=min_satellite_area,
            )
        )

    fused_alpha = np.maximum.reduce([row["alpha"] for row in results])
    fused_mask = fused_alpha > alpha_threshold
    if not fused_mask.any():
        raise RuntimeError("融合后没有前景，无法输出")

    ys, xs = np.where(fused_mask)
    x0 = max(0, int(xs.min()) - padding)
    x1 = min(width, int(xs.max()) + padding + 1)
    y0 = max(0, int(ys.min()) - padding)
    y1 = min(height, int(ys.max()) + padding + 1)

    rgba = np.array(img).copy()
    rgba[:, :, 3] = fused_alpha

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    cropped = Image.fromarray(rgba[y0:y1, x0:x1], "RGBA")
    cropped.save(output_path, "PNG")

    print(f"[output] bbox = ({x0},{y0})-({x1},{y1})")
    print(f"[output] size = {x1 - x0}x{y1 - y0}")
    print(f"[output] saved = {output_path}")

    if save_debug:
        debug_dir = os.path.join(os.path.dirname(output_path) or ".", Path(output_path).stem + "_debug")
        os.makedirs(debug_dir, exist_ok=True)
        for row in results:
            Image.fromarray(row["alpha"], "L").save(os.path.join(debug_dir, f"mask_{row['model']}.png"))
        Image.fromarray(fused_alpha, "L").save(os.path.join(debug_dir, "mask_fused.png"))
        print(f"[debug] {debug_dir}")

    return output_path


def main():
    parser = argparse.ArgumentParser(description="从多主体图片中提取指定目标主体")
    parser.add_argument("input", help="输入图片路径")
    parser.add_argument("output", nargs="?", default=None, help="输出路径（默认同名 + _target.png）")
    parser.add_argument("--target", default="right", choices=sorted(SUPPORTED_TARGETS), help="要提取的目标方位")
    parser.add_argument("--models", default=",".join(DEFAULT_MODELS), help="逗号分隔的 rembg 模型列表")
    parser.add_argument("--alpha-threshold", type=int, default=10, help="alpha 二值阈值（默认 10）")
    parser.add_argument("--min-area", type=int, default=400, help="主体最小面积（默认 400）")
    parser.add_argument("--min-satellite-area", type=int, default=120, help="附属部件最小面积（默认 120）")
    parser.add_argument("--max-gap", type=int, default=140, help="主主体与附属部件最大允许间距（默认 140）")
    parser.add_argument("--padding", type=int, default=12, help="裁剪外边距（默认 12）")
    parser.add_argument("--debug", action="store_true", help="保存每个模型和融合结果的 mask")
    args = parser.parse_args()

    input_path = os.path.abspath(args.input)
    if not args.output:
        stem = Path(input_path).stem
        out_dir = os.path.dirname(input_path) or "."
        args.output = os.path.join(out_dir, f"{stem}_{args.target}_subject.png")

    models = [item.strip() for item in args.models.split(",") if item.strip()]
    if not models:
        print("ERROR: --models 不能为空")
        sys.exit(1)

    try:
        fuse_target_subject(
            input_path=input_path,
            output_path=args.output,
            target=args.target,
            models=models,
            alpha_threshold=args.alpha_threshold,
            min_area=args.min_area,
            min_satellite_area=args.min_satellite_area,
            max_gap=args.max_gap,
            padding=args.padding,
            save_debug=args.debug,
        )
        sys.exit(0)
    except Exception as exc:
        print(f"ERROR: {exc}")
        sys.exit(1)


if __name__ == "__main__":
    main()
