#!/usr/bin/env python3
"""
BG-Removal: 本地抠图脚本（基于 rembg）
用法：
  python3 remove_bg.py <input_path> [output_path]
  python3 remove_bg.py <input_dir> <output_dir> --batch

批量模式会在输出目录额外生成：
  - batch_summary.md
  - batch_summary.json

依赖：
  pip install rembg[cli] pillow
"""

import sys
import os
import json
import argparse
from datetime import datetime
from pathlib import Path

SUPPORTED_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".bmp"}


def get_model_for_image(input_path: str) -> str:
    """根据图片特征选择模型（可扩展为人像检测逻辑）"""
    return "birefnet-general-v3"


def build_result(input_path: str, output_path: str, ok: bool, model_name: str, error: str = ""):
    return {
        "input": os.path.abspath(input_path),
        "output": os.path.abspath(output_path),
        "ok": ok,
        "status": "success" if ok else "failed",
        "model": model_name,
        "error": error,
    }


def write_batch_reports(output_dir: str, mode_name: str, model_name: str, rows: list[dict]):
    output_dir = os.path.abspath(output_dir)
    os.makedirs(output_dir, exist_ok=True)

    success_count = sum(1 for row in rows if row["ok"])
    fail_count = len(rows) - success_count
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    json_path = os.path.join(output_dir, "batch_summary.json")
    md_path = os.path.join(output_dir, "batch_summary.md")

    payload = {
        "generated_at": timestamp,
        "mode": mode_name,
        "model": model_name,
        "total": len(rows),
        "success": success_count,
        "failed": fail_count,
        "items": rows,
    }

    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)

    md_lines = [
        "# 批量抠图处理报告",
        "",
        f"- 生成时间：{timestamp}",
        f"- 处理模式：{mode_name}",
        f"- 使用模型：{model_name}",
        f"- 总数：{len(rows)}",
        f"- 成功：{success_count}",
        f"- 失败：{fail_count}",
        "",
        "## 明细",
        "",
        "| 状态 | 输入文件 | 输出文件 | 错误 |",
        "|------|----------|----------|------|",
    ]

    for row in rows:
        status = "✅" if row["ok"] else "❌"
        input_name = os.path.basename(row["input"]).replace("|", "\\|")
        output_name = os.path.basename(row["output"]).replace("|", "\\|")
        error = (row["error"] or "-").replace("|", "\\|").replace("\n", " ")
        md_lines.append(f"| {status} | {input_name} | {output_name} | {error} |")

    with open(md_path, "w", encoding="utf-8") as f:
        f.write("\n".join(md_lines) + "\n")

    return md_path, json_path


def remove_bg_single(input_path: str, output_path: str, model_name: str = None, return_detail: bool = False):
    try:
        from rembg import remove
        from PIL import Image
    except ImportError:
        error = "rembg 未安装。请运行：pip install rembg[cli] pillow"
        print(f"ERROR: {error}")
        result = build_result(input_path, output_path, False, model_name or "unknown", error)
        return result if return_detail else False

    input_path = os.path.abspath(input_path)
    output_path = os.path.abspath(output_path)

    if not os.path.isfile(input_path):
        error = f"输入文件不存在：{input_path}"
        print(f"ERROR: {error}")
        result = build_result(input_path, output_path, False, model_name or "unknown", error)
        return result if return_detail else False

    if not model_name:
        model_name = get_model_for_image(input_path)

    print(f"[rembg] 处理中：{input_path}")
    print(f"[rembg] 使用模型：{model_name}")

    try:
        input_img = Image.open(input_path)
        try:
            result_img = remove(input_img, model_name=model_name)
        except TypeError:
            print("[rembg] 警告：当前 rembg 版本不支持指定模型，使用默认模型")
            result_img = remove(input_img)

        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
        result_img.save(output_path, "PNG")
        print(f"[rembg] 完成 → {output_path}")
        result = build_result(input_path, output_path, True, model_name)
        return result if return_detail else True
    except Exception as exc:
        error = str(exc)
        print(f"ERROR: 处理失败：{error}")
        result = build_result(input_path, output_path, False, model_name, error)
        return result if return_detail else False


def remove_bg_batch(input_dir: str, output_dir: str, model_name: str = None):
    input_dir = os.path.abspath(input_dir)
    output_dir = os.path.abspath(output_dir)

    if not os.path.isdir(input_dir):
        print(f"ERROR: 输入目录不存在：{input_dir}")
        sys.exit(1)

    os.makedirs(output_dir, exist_ok=True)

    files = sorted(
        f for f in os.listdir(input_dir)
        if os.path.isfile(os.path.join(input_dir, f))
        and Path(f).suffix.lower() in SUPPORTED_EXTS
    )

    if not files:
        print(f"WARNING: 目录中没有找到支持的图片文件：{input_dir}")
        return None

    print(f"[rembg] 批量模式：找到 {len(files)} 张图片")

    rows = []
    for index, file_name in enumerate(files, start=1):
        in_path = os.path.join(input_dir, file_name)
        out_path = os.path.join(output_dir, Path(file_name).stem + "_no_bg.png")
        print(f"[rembg] ({index}/{len(files)}) {file_name}")
        rows.append(remove_bg_single(in_path, out_path, model_name, return_detail=True))

    actual_model = model_name or "auto(birefnet-general-v3)"
    md_path, json_path = write_batch_reports(output_dir, "rembg-standard", actual_model, rows)
    success = sum(1 for row in rows if row["ok"])
    fail = len(rows) - success

    print(f"[rembg] 批量完成：成功 {success} 张，失败 {fail} 张")
    print(f"[rembg] 输出目录：{output_dir}")
    print(f"[rembg] 报告：{md_path}")
    print(f"[rembg] JSON：{json_path}")

    return {
        "success": success,
        "failed": fail,
        "report_md": md_path,
        "report_json": json_path,
    }


def main():
    parser = argparse.ArgumentParser(description="本地抠图（基于 rembg）")
    parser.add_argument("input", help="输入图片路径 或 输入目录（批量模式）")
    parser.add_argument("output", nargs="?", default=None, help="输出路径（单张模式）或输出目录（批量模式）")
    parser.add_argument("--batch", action="store_true", help="批量处理目录")
    parser.add_argument("--model", default=None, help="指定模型名称（如 birefnet-general-v3, u2net_human_seg）")
    args = parser.parse_args()

    if args.batch or os.path.isdir(args.input):
        output_dir = args.output or (args.input.rstrip("/") + "_no_bg")
        summary = remove_bg_batch(args.input, output_dir, args.model)
        if summary is None:
            sys.exit(1)
        sys.exit(0 if summary["failed"] == 0 else 2)
    else:
        if not args.output:
            stem = Path(args.input).stem
            out_dir = os.path.dirname(args.input) or "."
            args.output = os.path.join(out_dir, stem + "_no_bg.png")
        ok = remove_bg_single(args.input, args.output, args.model)
        sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
