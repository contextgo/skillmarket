# Project Documentation Memory

This skill tracks and remembers key documents throughout the project lifecycle. It uses different categories to organize and recall important information about the project's features, code style, security issues, UI designs, and to-dos.

## Workflow

- **Auto-tracking**: The skill will automatically capture details from the following categories:
  1. **New Features**: Updates and additions to features.
  2. **Code Style**: Standards followed in code implementation.
  3. **Security**: Identified security issues and fixes.
  4. **UI Styles**: Design specifications for user interfaces.
  5. **To-Do Lists**: Tasks to be completed within the project.

### Key Documents Tracked:

- **Features**: `/project/feature-tracker`
- **Code Style**: `/project/code-style-tracker`
- **Security Issues**: `/project/security-issues`
- **UI Styles**: `/project/ui-styles`
- **To-Do Lists**: `/project/todolist`
