#!/usr/bin/env python3
"""
小红书全链路发布技能 - 环境检查脚本
验证运行环境是否就绪
"""

import sys
import os


def check_python_version():
    """检查 Python 版本"""
    version = sys.version_info
    if version.major >= 3 and version.minor >= 7:
        print(f"✅ Python 版本: {version.major}.{version.minor}.{version.micro}")
        return True
    else:
        print(f"❌ Python 版本过低: {version.major}.{version.minor}.{version.micro} (需要 >= 3.7)")
        return False


def check_dependencies():
    """检查依赖包"""
    required = [
        ('requests', 'HTTP 请求库'),
        ('PIL', 'Pillow 图像处理库'),
    ]
    all_ok = True
    
    for pkg, desc in required:
        try:
            if pkg == 'PIL':
                from PIL import Image
            else:
                __import__(pkg)
            print(f"✅ {pkg} ({desc})")
        except ImportError:
            print(f"❌ {pkg} ({desc}) 未安装")
            all_ok = False
    
    return all_ok


def check_env():
    """检查环境变量"""
    api_key = os.environ.get('ARK_API_KEY')
    if api_key:
        masked = api_key[:8] + '...' + api_key[-4:] if len(api_key) > 12 else '***'
        print(f"✅ ARK_API_KEY 已设置: {masked}")
        return True
    else:
        print("❌ ARK_API_KEY 未设置")
        print("   请设置环境变量: export ARK_API_KEY=你的豆包API密钥")
        return False


def main():
    print("=" * 50)
    print("小红书全链路发布技能 - 环境检查")
    print("=" * 50)
    print()
    
    checks = [
        ("Python 版本", check_python_version),
        ("依赖包", check_dependencies),
        ("环境变量", check_env),
    ]
    
    results = []
    for name, check_func in checks:
        print(f"\n📋 检查 {name}...")
        results.append(check_func())
    
    print()
    print("=" * 50)
    if all(results):
        print("✅ 所有检查通过！可以开始使用小红书全链路发布技能。")
        return 0
    else:
        print("❌ 部分检查未通过，请修复上述问题。")
        print()
        print("安装依赖:")
        print("  pip install -r requirements.txt")
        print()
        print("设置 API 密钥:")
        print("  export ARK_API_KEY=你的豆包API密钥")
        return 1


if __name__ == "__main__":
    sys.exit(main())
