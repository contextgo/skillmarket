#!/usr/bin/env python3
"""
小红书配图生成脚本
基于 Doubao Seedream 5.0 API，专为小红书 3:4 比例优化
"""

import os
import sys
import argparse
import json
import urllib.request
import urllib.error
from datetime import datetime
from pathlib import Path

# 豆包 Seedream API 配置
DOUBAO_API_URL = "https://ark.cn-beijing.volces.com/api/v3/images/generations"
DOUBAO_MODEL = "doubao-seedream-5-0-260128"

# ==================== 风格系统 ====================

# 面向小红书场景精选的常用风格
XHS_STYLES = {
    # 适合种草/好物推荐
    "杂志风": "magazine editorial style, fashion photography, clean composition, professional lighting",
    "产品": "product photography, clean background, professional lighting, commercial quality",
    
    # 适合干货/教程
    "扁平化": "flat design, simple geometric shapes, bright colors, minimal shadows, modern UI aesthetic",
    "等距": "isometric 3D perspective, clean lines, tech illustration style, dimensional",
    "极简": "minimalist design, single focal point, generous white space, 2-3 color palette",
    
    # 适合情感/成长
    "文艺": "literary aesthetic, soft muted tones, generous white space, gentle lighting, contemplative mood",
    "日系": "Japanese aesthetic, warm film grain, soft natural light, muted colors, wabi-sabi",
    
    # 适合探店/美食
    "电影感": "cinematic lighting, film grain, anamorphic lens, color grading, movie poster quality",
    "美食": "food photography, appetizing, warm lighting, shallow depth of field, styled",
    
    # 适合日常/vlog
    "韩系": "Korean aesthetic, clean bright pastels, soft lighting, minimalist, K-beauty inspired",
    
    # 适合母婴/亲子
    "手绘": "hand-drawn illustration, warm organic lines, sketchy quality, artistic texture",
    "蜡笔": "crayon drawing, childlike, textured strokes, colorful, playful",
    
    # 适合穿搭/美妆
    "国潮": "Chinese neo-traditional style, modern interpretation of Chinese elements, red and gold, dragon and phoenix motifs, contemporary chinoiserie",
    "水彩": "watercolor painting, soft washes, bleeding colors, artistic texture, dreamy",
    
    # 适合创业/副业
    "瑞士风格": "Swiss International Style, grid-based, Helvetica typography, clean functional",
    "新拟态": "neumorphism, soft shadows, tactile design, subtle gradients, button-like",
    
    # 其他常用风格
    "复古": "vintage retro aesthetic, 1970s-80s poster style, warm nostalgic colors, film grain",
    "赛博朋克": "cyberpunk aesthetic, neon lights, rain-soaked streets, high contrast, futuristic",
    "蒸汽波": "vaporwave aesthetic, neon pink and cyan, glitch effects, 80s nostalgia, palm trees",
    "国潮-水墨": "Chinese ink wash style, modern ink painting, splash ink, traditional meets contemporary",
    "浮世绘": "Ukiyo-e style, Japanese woodblock print, Hokusai inspired, bold outlines, flat colors",
    "矢量": "vector illustration, clean lines, scalable graphics, flat colors, modern icon style",
    "涂鸦": "graffiti style, urban street art, bold colors, spray paint texture, energetic",
    "像素": "pixel art, 8-bit style, retro gaming, blocky, nostalgic",
    "mondo": "Mondo poster style, screen print aesthetic, limited edition poster art, bold colors",
}

# 文案类型到风格的映射
TYPE_STYLE_MAP = {
    "好物推荐型": ["杂志风", "产品"],
    "干货教程型": ["扁平化", "等距"],
    "情感成长型": ["文艺", "日系"],
    "探店打卡型": ["电影感", "美食"],
    "日常vlog型": ["日系", "韩系"],
    "母婴亲子型": ["手绘", "蜡笔"],
    "穿搭美妆型": ["杂志风", "极简"],
    "创业副业型": ["扁平化", "极简"],
}


def get_api_key():
    """从环境变量获取 API 密钥"""
    api_key = os.getenv('ARK_API_KEY')
    if not api_key:
        print("❌ 错误：需要 ARK_API_KEY 环境变量")
        print("请设置：export ARK_API_KEY=你的密钥")
        sys.exit(1)
    return api_key


def parse_aspect_ratio(ratio_str):
    """解析宽高比字符串为尺寸 - 豆包要求最小 3686400 像素"""
    ratio_map = {
        "1:1": (1920, 1920),
        "3:4": (1664, 2218),    # 小红书最佳
        "4:3": (2218, 1664),
        "9:16": (1440, 2560),
        "16:9": (2560, 1440),
        "2:3": (1568, 2352),
    }

    if ratio_str in ratio_map:
        return ratio_map[ratio_str]

    try:
        w, h = map(int, ratio_str.split(':'))
        min_pixels = 3686400
        if w >= h:
            width = max(1920, int((min_pixels * w / h) ** 0.5))
            height = int(width * h / w)
        else:
            height = max(1920, int((min_pixels * h / w) ** 0.5))
            width = int(height * w / h)
        if width * height < min_pixels:
            if w >= h:
                width += 1
                height = int(width * h / w)
            else:
                height += 1
                width = int(height * w / h)
        return (width, height)
    except:
        print(f"⚠️  未知比例 '{ratio_str}'，使用默认 3:4")
        return ratio_map["3:4"]


def build_prompt(user_description, style="极简", ratio="3:4"):
    """
    根据用户配图描述和风格构建完整提示词
    
    Args:
        user_description: 用户配图描述（中文或英文）
        style: 艺术风格名称
        ratio: 宽高比
    
    Returns:
        完整的英文提示词
    """
    style_desc = XHS_STYLES.get(style, XHS_STYLES.get("极简"))
    
    # 构建提示词
    prompt_parts = [user_description, style_desc]
    
    # 添加比例描述
    if ratio == "3:4":
        prompt_parts.append("vertical 3:4 format, optimized for Xiaohongshu social media post")
    elif ratio == "1:1":
        prompt_parts.append("square 1:1 format")
    elif ratio == "9:16":
        prompt_parts.append("vertical 9:16 mobile format")
    
    # 添加质量修饰
    prompt_parts.append("high quality, professional, visually appealing")
    
    return ", ".join(prompt_parts)


def generate_image(prompt, output_path=None, ratio="3:4"):
    """
    使用豆包 Seedream API 生成图片
    
    Args:
        prompt: 完整提示词
        output_path: 输出文件路径（默认自动生成）
        ratio: 宽高比
    
    Returns:
        生成的图片路径，失败返回 None
    """
    api_key = get_api_key()
    width, height = parse_aspect_ratio(ratio)
    size = f"{width}x{height}"
    
    print(f"🎨 使用豆包 Seedream 5.0")
    print(f"📐 尺寸: {ratio} ({size})")
    print(f"✍️  提示词: {prompt[:100]}..." if len(prompt) > 100 else f"✍️  提示词: {prompt}")
    print("⏳ 生成中...\n")
    
    try:
        payload = {
            "model": DOUBAO_MODEL,
            "prompt": prompt,
            "size": size,
            "response_format": "url",
            "watermark": False,
        }
        
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }
        
        req = urllib.request.Request(
            DOUBAO_API_URL,
            data=json.dumps(payload).encode("utf-8"),
            headers=headers,
            method="POST"
        )
        
        with urllib.request.urlopen(req, timeout=120) as resp:
            result = json.loads(resp.read().decode("utf-8"))
        
        if "data" in result and len(result["data"]) > 0:
            image_url = result["data"][0].get("url", "")
            
            if not image_url:
                print("❌ 响应中没有图片URL")
                print(f"响应内容: {result}")
                return None
            
            # 确定输出路径
            if not output_path:
                timestamp = datetime.now().strftime('%Y%m%d-%H%M%S')
                default_dir = os.path.expanduser("~/xiaohongshu-fullpipe")
                os.makedirs(default_dir, exist_ok=True)
                safe_name = "".join(c if c.isalnum() else "_" for c in prompt[:20])
                output_path = f"{default_dir}/xhs-{safe_name}-{timestamp}.png"
            
            os.makedirs(os.path.dirname(output_path) or '.', exist_ok=True)
            
            # 下载图片
            urllib.request.urlretrieve(image_url, output_path)
            
            print(f"✅ 已保存: {output_path}")
            return output_path
        else:
            print(f"❌ 响应格式无效: {result}")
            return None
            
    except urllib.error.HTTPError as e:
        print(f"❌ HTTP错误: {e.code}")
        try:
            error_body = e.read().decode('utf-8')
            print(f"   详情: {error_body[:500]}")
        except:
            pass
        return None
    except Exception as e:
        print(f"❌ 错误: {e}")
        return None


def list_styles():
    """列出所有可用风格"""
    print("\n🎨 小红书配图生成器 - 可用风格\n")
    print("=" * 60)
    
    for category, styles in TYPE_STYLE_MAP.items():
        print(f"\n【{category}】推荐: {', '.join(styles)}")
    
    print(f"\n【全部风格】共 {len(XHS_STYLES)} 种:")
    for name in XHS_STYLES:
        print(f"  {name}")
    
    print("\n" + "=" * 60)


def main():
    parser = argparse.ArgumentParser(
        description='小红书配图生成器 - 基于 Doubao Seedream',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
常用示例:
  # 根据配图描述生成（自动使用极简风格）
  python3 generate_xhs_image.py --prompt "一杯拿铁放在木质桌面上，阳光透过窗户洒进来，温馨氛围"
  
  # 指定风格
  python3 generate_xhs_image.py --prompt "护肤产品摆放" --style 杂志风
  
  # 指定文案类型（自动匹配风格）
  python3 generate_xhs_image.py --prompt "五种高效学习方法" --type 干货教程型
  
  # 指定输出路径
  python3 generate_xhs_image.py --prompt "咖啡时光" --output ~/my-poster.png

查看所有风格:
  python3 generate_xhs_image.py --list-styles
        """
    )
    
    parser.add_argument('--prompt', help='配图描述（中文或英文）')
    parser.add_argument('--style', default='极简',
                       help='艺术风格（默认: 极简）')
    parser.add_argument('--type', 
                       help='文案类型，自动匹配风格（好物推荐型/干货教程型/情感成长型/探店打卡型/日常vlog型/母婴亲子型/穿搭美妆型/创业副业型）')
    parser.add_argument('--ratio', default='3:4',
                       help='宽高比（默认: 3:4 小红书最佳）')
    parser.add_argument('--output', help='输出文件路径')
    parser.add_argument('--list-styles', action='store_true',
                       help='列出所有可用风格')
    
    args = parser.parse_args()
    
    if args.list_styles:
        list_styles()
        return
    
    if not args.prompt:
        parser.print_help()
        print("\n❌ 错误: 需要提供 --prompt 配图描述")
        sys.exit(1)
    
    # 如果指定了文案类型，自动匹配风格
    style = args.style
    if args.type and args.type in TYPE_STYLE_MAP:
        style = TYPE_STYLE_MAP[args.type][0]
        print(f"📝 文案类型: {args.type} → 自动匹配风格: {style}")
    
    # 构建提示词
    full_prompt = build_prompt(args.prompt, style, args.ratio)
    
    print(f"\n{'='*60}")
    print("🎨 小红书配图生成")
    print(f"{'='*60}")
    print(f"风格: {style}")
    print(f"比例: {args.ratio}")
    print(f"{'='*60}\n")
    
    # 生成图片
    output = generate_image(full_prompt, args.output, args.ratio)
    if not output:
        sys.exit(1)


if __name__ == '__main__':
    main()
