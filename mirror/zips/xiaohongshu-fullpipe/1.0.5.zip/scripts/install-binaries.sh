#!/bin/bash
# xiaohongshu-mcp 二进制文件安装脚本
# 自动检测平台，从 GitHub Releases 下载对应二进制文件到 ~/.local/bin/
#
# 支持平台：darwin-arm64, darwin-amd64, windows-amd64

set -e

INSTALL_DIR="$HOME/.local/bin"
XHS_DATA_DIR="$HOME/.xiaohongshu"
GITHUB_RELEASE_BASE="https://github.com/xpzouying/xiaohongshu-mcp/releases/download/v2026.04.09.1645-7732044"

echo "================================================"
echo "🔧 xiaohongshu-mcp 二进制文件安装（GitHub 下载）"
echo "================================================"

# 检测平台
detect_platform() {
    local os arch
    os="$(uname -s | tr '[:upper:]' '[:lower:]')"
    arch="$(uname -m)"

    case "$os" in
        darwin) os="darwin" ;;
        linux)  os="linux" ;;
        mingw*|msys*|cygwin*|windows*)
            echo "❌ 检测到 Windows/MSYS 环境，请使用 PowerShell 脚本："
            echo "   powershell -ExecutionPolicy Bypass -File scripts/install-binaries.ps1"
            exit 1
            ;;
        *) echo "❌ 不支持的操作系统: $os"; exit 1 ;;
    esac

    case "$arch" in
        arm64|aarch64) arch="arm64" ;;
        x86_64|amd64)  arch="amd64" ;;
        *) echo "❌ 不支持的架构: $arch"; exit 1 ;;
    esac

    echo "$os-$arch"
}

PLATFORM=$(detect_platform)
echo "检测到平台: $PLATFORM"
echo ""

# 检查是否已安装
check_existing() {
    local name="$1"
    local path="$INSTALL_DIR/$name"
    if [ -x "$path" ]; then
        echo "✅ $name: 已存在 ($path)"
        return 0
    fi
    return 1
}

# 如果两个二进制都已存在，跳过下载
if check_existing "xiaohongshu-mcp" && check_existing "xiaohongshu-login"; then
    echo ""
    echo "所有二进制文件已安装，无需重新下载。"
    echo "如需强制重新安装，请先删除 ~/.local/bin/xiaohongshu-mcp 和 ~/.local/bin/xiaohongshu-login"
    exit 0
fi

# 创建安装目录
mkdir -p "$INSTALL_DIR" "$XHS_DATA_DIR"

# 下载函数
download_binary() {
    local platform="$1"
    local filename="$2"
    local dst_name="$3"
    local dst="$INSTALL_DIR/$dst_name"

    # 确定 URL 中的文件名格式
    local url_filename
    case "$platform" in
        darwin-arm64|darwin-amd64)
            # macOS: tar.gz 压缩包
            url_filename="${platform}.tar.gz"
            ;;
        windows-amd64)
            # Windows: zip 压缩包
            url_filename="${platform}.zip"
            ;;
        *)
            url_filename="${platform}.tar.gz"
            ;;
    esac

    local url="${GITHUB_RELEASE_BASE}/${url_filename}"
    local tmp_dir
    tmp_dir=$(mktemp -d)

    echo "⬇️  下载 $url_filename ..."
    if ! curl -fsSL "$url" -o "$tmp_dir/$url_filename"; then
        echo "❌ 下载失败: $url"
        echo "   请检查网络连接，或手动从以下地址下载："
        echo "   https://github.com/xpzouying/xiaohongshu-mcp/releases"
        rm -rf "$tmp_dir"
        exit 1
    fi

    echo "📦 解压 $url_filename ..."
    case "$url_filename" in
        *.tar.gz)
            tar -xzf "$tmp_dir/$url_filename" -C "$tmp_dir"
            ;;
        *.zip)
            if command -v unzip &>/dev/null; then
                unzip -o -q "$tmp_dir/$url_filename" -d "$tmp_dir"
            else
                echo "❌ 需要 unzip 工具来解压 .zip 文件"
                rm -rf "$tmp_dir"
                exit 1
            fi
            ;;
    esac

    # 查找并复制目标文件
    local src
    # 优先查找带 .exe 后缀的（Windows），其次无后缀的
    if [ -f "$tmp_dir/$filename.exe" ]; then
        src="$tmp_dir/$filename.exe"
        dst="$dst.exe"
    elif [ -f "$tmp_dir/$filename" ]; then
        src="$tmp_dir/$filename"
    else
        # 在子目录中查找
        src=$(find "$tmp_dir" -name "$filename" -o -name "${filename}.exe" | head -1)
        if [ -z "$src" ]; then
            echo "❌ 解压后未找到 $filename"
            rm -rf "$tmp_dir"
            exit 1
        fi
        # 如果找到的是 .exe，目标也加 .exe
        if [[ "$src" == *.exe ]]; then
            dst="$dst.exe"
        fi
    fi

    cp "$src" "$dst"
    chmod +x "$dst"
    echo "✅ $dst_name: 已安装到 $dst"
    rm -rf "$tmp_dir"
}

echo "下载并安装二进制文件..."
echo ""

# 根据 macOS 平台选择下载文件名
case "$PLATFORM" in
    darwin-arm64|darwin-amd64)
        download_binary "$PLATFORM" "xiaohongshu-mcp" "xiaohongshu-mcp"
        download_binary "$PLATFORM" "xiaohongshu-login" "xiaohongshu-login"
        ;;
    linux-*)
        echo "⚠️  Linux 平台暂未提供预编译二进制"
        echo "   请从源码编译或访问 GitHub Releases："
        echo "   https://github.com/xpzouying/xiaohongshu-mcp/releases"
        exit 1
        ;;
    *)
        echo "❌ 未知平台: $PLATFORM"
        exit 1
        ;;
esac

# 确保 ~/.local/bin 在 PATH 中
if echo ":$PATH:" | grep -q ":$INSTALL_DIR:"; then
    echo ""
    echo "✅ $INSTALL_DIR 已在 PATH 中"
else
    echo ""
    echo "⚠️  $INSTALL_DIR 不在 PATH 中"
    echo "   建议在 ~/.zshrc 中添加："
    echo "   export PATH=\"\$HOME/.local/bin:\$PATH\""
    echo ""
    echo "   当前技能的脚本会直接使用绝对路径，不影响使用。"
fi

# 显示版本信息
echo ""
echo "================================================"
echo "✅ 安装完成！"
echo ""
echo "二进制文件:"
echo "  xiaohongshu-mcp:  $INSTALL_DIR/xiaohongshu-mcp"
echo "  xiaohongshu-login: $INSTALL_DIR/xiaohongshu-login"
echo ""
echo "后续步骤:"
echo "  1. 启动 MCP 服务: bash scripts/start-mcp.sh"
echo "  2. 扫码登录: bash scripts/mcp-call.sh get_login_qrcode"
echo "================================================"
