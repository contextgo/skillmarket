---
name: xiaohongshu-fullpipe
description: 小红书全链路发布技能 - 从爆款文案生成、AI配图到一键发布的完整流水线。小红书全能创作助手。当你需要"发一篇小红书"、"写个小红书笔记"、"发布关于XXX的内容"或"生成小红书文案与配图"时使用。
triggers:
  - 发一篇小红书
  - 发布小红书
  - 小红书文案
  - 写个小红书
  - 帮我发小红书
  - 小红书发布
  - 创作小红书
  - 快速发布小红书
---

# 小红书全链路发布技能

一句话完成小红书内容创作到发布的全流程：**主题 → 爆款文案 → AI配图 → 预览确认 → 发布**。

本技能整合了文案生成、AI配图生成和 MCP API 发布三大能力，无需安装其他 skill 即可独立运行。

---

## 依赖环境

### 必需
- **ARK_API_KEY** 环境变量：Doubao Seedream 图像生成 API 密钥
  ```bash
  export ARK_API_KEY=你的豆包API密钥
  ```
  获取方式：访问 [火山引擎控制台](https://console.volcengine.com/) → 大模型推理 → 创建 API Key

- **xiaohongshu-mcp** 服务：用于笔记发布（本地 MCP 服务，监听 `localhost:18060`）
  - 二进制文件从 **GitHub Releases 自动下载**，支持 darwin-arm64 / darwin-amd64 / windows-amd64
  - 首次安装运行：
    - macOS/Linux：`bash scripts/install-binaries.sh`
    - Windows：`powershell -ExecutionPolicy Bypass -File scripts\install-binaries.ps1`
  - 登录：
    - macOS/Linux：`bash scripts/mcp-call.sh get_login_qrcode`
    - Windows：`.\scripts\mcp-call.ps1 get_login_qrcode`
  - 启动：
    - macOS/Linux：`bash scripts/start-mcp.sh`
    - Windows：`powershell -ExecutionPolicy Bypass -File scripts\start-mcp.ps1`
- **Python >= 3.7** + **requests** + **Pillow** 库

### 可选检查
```bash
# macOS / Linux：一键安装二进制文件（首次）
bash scripts/install-binaries.sh

# Windows：使用 PowerShell 脚本
powershell -ExecutionPolicy Bypass -File scripts\install-binaries.ps1

# 检查其他依赖（跨平台）
python3 scripts/check_install.py
pip install -r requirements.txt
```

---

## 全链路工作流

```
用户输入主题
    ↓
┌─────────────────────────────────┐
│  Phase 1: 爆款文案生成          │
│  - 主题类型分析                  │
│  - 匹配风格模板                  │
│  - 生成完整文案                  │
│  - 输出配图建议                  │
└─────────────┬───────────────────┘
              ↓
┌─────────────────────────────────┐
│  Phase 2: AI配图生成             │
│  - 根据配图建议构造提示词         │
│  - 调用 Doubao Seedream API      │
│  - 生成小红书比例(3:4)配图       │
│  - 下载保存到本地                │
└─────────────┬───────────────────┘
              ↓
┌─────────────────────────────────┐
│  Phase 3: 预览与确认             │
│  - 展示文案 + 配图给用户         │
│  - 用户确认或要求修改             │
└─────────────┬───────────────────┘
              ↓
┌─────────────────────────────────┐
│  Phase 4: MCP API 发布          │
│  - 检查 MCP 服务登录状态          │
│  - 调用 publish API 发布笔记     │
│  - 确认发布结果                  │
└─────────────────────────────────┘
```

---

## Phase 1: 爆款文案生成

当用户提供主题后，**立即执行以下步骤**，不要询问用户选择模板。

### 1.1 主题类型分析

自动判断用户主题属于以下哪种类型，选择最匹配的风格模板：

| 类型 | 适用场景 | 文案特点 |
|------|----------|----------|
| **好物推荐型** | 产品推荐、购物分享、开箱测评 | 真实体验感、对比评价、种草语气 |
| **干货教程型** | 技能教学、知识分享、避坑指南 | 分步骤、条理清晰、收藏价值高 |
| **情感成长型** | 个人经历、成长感悟、励志分享 | 共鸣感强、金句频出、走心 |
| **探店打卡型** | 美食探店、旅行打卡、咖啡店分享 | 画面感强、氛围描写、打卡攻略 |
| **日常vlog型** | 生活方式、日常记录、好习惯养成 | 轻松亲切、像朋友聊天、生活美学 |
| **母婴亲子型** | 育儿经验、宝宝好物、亲子互动 | 实用育儿经、真实场景、宝妈语气 |
| **穿搭美妆型** | 妆容教程、穿搭分享、变美技巧 | 前后对比、技巧分享、变美干货 |
| **创业副业型** | 副业分享、搞钱经验、成长干货 | 干货满满、数据支撑、可执行建议 |

### 1.2 文案创作规则

**标题**：
- 2-3个emoji + 10字以内爆款标题 + 一句话引入
- 必须有信息增量，让人有点击欲望

**正文**：
- 3-5个要点，每个带emoji
- 语言年轻化、口语化（善用"咱就是说"、"真的绝了"、"谁懂啊"等）
- 适当使用括号补充细节，增加真实感
- 每段不宜过长，手机阅读舒适
- 200-300字

**结尾**：
- 金句/核心观点 + 行动呼吁
- 互动语要具体（不要只说"欢迎评论"）

**标签**：
- 5-8个相关话题标签，以 # 开头

### 1.3 输出格式（必须严格遵守）

```
## 📝 小红书图文

[emoji] [标题]
[空行]
[正文内容]
[空行]
[互动引导语]
[空行]
#标签1 #标签2 #标签3 ...

---

## 🎨 配图方案

**配图描述**：[详细描述图片风格、画面内容、色调、构图、氛围]
（至少2句话，包含视觉元素的具体描述，便于AI生成）

**封面文案**：
[文案第1行，不超过5字]
[文案第2行，不超过5字]

**搜索关键词**：[keyword1, keyword2, keyword3, keyword4, keyword5]
```

**重要**：配图描述必须足够详细，包含画面主体、风格、色调、构图等关键信息，这是 Phase 2 生成配图的直接依据。

---

## Phase 2: AI配图生成

文案生成完毕后，**立即基于"配图方案"中的"配图描述"自动生成配图**，不要询问用户。

### 2.1 提示词构造

根据文案类型自动匹配最佳艺术风格，结合"配图描述"构造完整的英文提示词：

```python
# 运行配图生成脚本
python3 {SKILL_DIR}/scripts/generate_xhs_image.py \
  --prompt "配图描述的英文翻译" \
  --style "自动匹配的风格" \
  --output "输出路径"
```

**风格自动匹配规则**：

| 文案类型 | 推荐风格 | 说明 |
|----------|----------|------|
| 好物推荐型 | 杂志风 / 产品 | 干净、突出产品质感 |
| 干货教程型 | 扁平化 / 等距 | 信息清晰、图表感 |
| 情感成长型 | 文艺 / 日系 | 温暖、有故事感 |
| 探店打卡型 | 电影感 / 美食 | 氛围感强、诱人 |
| 日常vlog型 | 日系 / 韩系 | 清新、生活感 |
| 母婴亲子型 | 手绘 / 蜡笔 | 温馨、童趣 |
| 穿搭美妆型 | 杂志风 / 极简 | 时尚、高级感 |
| 创业副业型 | 扁平化 / 极简 | 专业、可信赖 |

### 2.2 生成参数

- **比例**：默认 3:4（小红书最佳比例）
- **尺寸**：1664×2218 像素
- **无水印**：`watermark=False`
- **输出**：保存到 `~/xiaohongshu-fullpipe/` 目录

### 2.3 如果生成失败

- 检查 ARK_API_KEY 是否配置
- 尝试简化提示词
- 如果多次失败，告知用户并建议跳过配图直接发布纯文字笔记

---

## Phase 3: 预览与确认

配图生成后，向用户展示完整方案：

1. **展示文案**：直接在对话中输出完整文案
2. **展示配图**：使用 `open_result_view` 或 `preview_url` 展示生成的图片
3. **询问用户**：
   - "文案和配图满意吗？需要修改哪里？"
   - "确认无误的话，我帮你发布到小红书"

**用户可能的选择**：
- **满意** → 进入 Phase 4 发布
- **修改文案** → 回到 Phase 1 重新生成
- **修改配图** → 回到 Phase 2 重新生成（可让用户指定风格）
- **调整整体** → 综合修改后再次预览
- **只发文字** → 跳过配图，进入 Phase 4 纯文字发布

---

## Phase 4: MCP 协议发布

用户确认后，通过 **xiaohongshu-mcp** 本地 MCP 服务发布笔记。

> **注意**：xiaohongshu-mcp 使用 MCP 协议（JSON-RPC over HTTP），不是 REST API。
> 所有调用必须通过 `scripts/mcp-call.sh` 脚本进行。

### 4.1 前置检查

在发布前，先确认 MCP 服务可用且已登录：

**macOS / Linux：**
```bash
# 1. 检查 MCP 服务是否运行
lsof -i :18060 2>/dev/null | head -3

# 2. 检查登录状态
bash {SKILL_DIR}/scripts/mcp-call.sh check_login_status
```

**Windows (PowerShell)：**
```powershell
# 1. 检查 MCP 服务是否运行
Get-NetTCPConnection -LocalPort 18060 -ErrorAction SilentlyContinue

# 2. 检查登录状态
.\scripts\mcp-call.ps1 check_login_status
```

- 如果 MCP 服务未运行：
  - macOS/Linux：`bash {SKILL_DIR}/scripts/start-mcp.sh`
  - Windows：`powershell -ExecutionPolicy Bypass -File scripts\start-mcp.ps1`
- 如果未登录：
  - macOS/Linux：`bash {SKILL_DIR}/scripts/mcp-call.sh get_login_qrcode`
  - Windows：`.\scripts\mcp-call.ps1 get_login_qrcode`

### 4.2 发布调用

通过 `mcp-call` 脚本调用 MCP 协议的 `publish_content` 工具：

**macOS / Linux：**
```bash
# 带配图发布
bash {SKILL_DIR}/scripts/mcp-call.sh publish_content \
  '{"title": "标题（≤20字符）", "content": "正文内容", "images": ["/absolute/path/to/image.png"], "tags": ["标签1", "标签2"]}'
```

**Windows (PowerShell)：**
```powershell
# 带配图发布
.\scripts\mcp-call.ps1 publish_content '{"title": "标题（≤20字符）", "content": "正文内容", "images": ["C:\path\to\image.png"], "tags": ["标签1", "标签2"]}'
```

**参数说明**（`publish_content` 工具参数，严格模式，不允许额外字段）：

| 参数 | 必填 | 说明 |
|------|------|------|
| `title` | ✅ | 笔记标题，**≤20字符**（含 emoji），超出会报错 |
| `content` | ✅ | 正文内容，**不含 # 标签**（标签用 tags 参数单独传） |
| `images` | ✅ | 图片路径数组，支持本地绝对路径和 HTTP/HTTPS 链接，如 `["/path/to/img.png"]` |
| `tags` | 可选 | 话题标签数组，如 `["美食", "旅行"]`（不要写在 content 里用 # 号） |
| `is_original` | 可选 | 是否声明原创，`true` 为声明 |
| `schedule_at` | 可选 | 定时发布时间，ISO8601 格式，如 `2024-01-20T10:30:00+08:00` |
| `visibility` | 可选 | 可见范围：`公开可见`（默认）、`仅自己可见`、`仅互关好友可见` |
| `products` | 可选 | 商品关键词数组，如 `["面膜", "防晒霜SPF50"]` |

> ⚠️ **重要踩坑**：该工具 `additionalProperties: false`，**绝不能传参数表中没有的字段**（如 `image_paths`、`desc`、`is_private` 等旧字段名会直接报错）。

### 4.3 标题长度处理

**关键踩坑**：小红书标题有 20 字符限制（含 emoji）。如果标题超长：

```python
# 自动截断标题到 20 字符以内
title = title[:20]
```

文案生成阶段（Phase 1）就应控制标题在 20 字符以内，但作为保险，发布前再次校验。

### 4.4 返回结果处理

`mcp-call.sh` 的输出为 MCP JSON-RPC 响应格式。发布成功的响应中 `result.content[0].text` 包含结果信息。

常见失败原因及处理：

| 错误 | 原因 | 解决方案 |
|------|------|----------|
| 标题长度超过限制 | title > 20 字符 | 截断到 20 字符 |
| 未登录 | MCP 服务 session 过期 | 重新运行 `mcp-call.sh get_login_qrcode` |
| 连接失败 | MCP 服务未启动 | 运行 `start-mcp.sh` |

### 4.5 纯文字发布

如果用户选择只发文字（无配图），`images` 传空数组即可（但注意 images 是必填项）：

**macOS / Linux：**
```bash
bash {SKILL_DIR}/scripts/mcp-call.sh publish_content \
  '{"title": "标题（≤20字符）", "content": "正文内容", "images": [], "tags": ["标签1", "标签2"]}'
```

**Windows (PowerShell)：**
```powershell
.\scripts\mcp-call.ps1 publish_content '{"title": "标题（≤20字符）", "content": "正文内容", "images": [], "tags": ["标签1", "标签2"]}'
```

---

## 简化触发流程

当用户只说了简短的关键词（如"发个小红书"、"写篇种草文"），按以下方式处理：

1. **主题不明确时**：追问一次主题/方向，然后立即开始全流程
2. **主题明确时**：直接开始 Phase 1，不要多问
3. **用户给了具体内容要求**（如"帮我写一篇关于XX的小红书"）：直接按主题执行

---

## 配图方案风格参考

以下是 `generate_xhs_image.py` 内置的 25 种精选风格，按场景分类：

### 种草/好物推荐
杂志风, 产品

### 干货/教程
扁平化, 等距, 极简

### 情感/成长
文艺, 日系

### 探店/美食
电影感, 美食

### 日常/Vlog
韩系

### 母婴/亲子
手绘, 蜡笔

### 穿搭/美妆
国潮, 水彩

### 创业/副业
瑞士风格, 新拟态

### 其他常用
复古, 赛博朋克, 蒸汽波, 国潮-水墨, 浮世绘, 矢量, 涂鸦, 像素, mondo

> 查看完整列表及风格映射：`python3 {SKILL_DIR}/scripts/generate_xhs_image.py --list-styles`

---

## 文件结构

```
xiaohongshu-fullpipe/
├── SKILL.md                    # 本文件 - 技能定义与工作流
├── _skillhub_meta.json         # 技能元数据
├── requirements.txt            # Python 依赖
└── scripts/
    ├── install-binaries.sh     # 二进制安装 - 从 GitHub 下载 (macOS/Linux)
    ├── install-binaries.ps1    # 二进制安装 - 从 GitHub 下载 (Windows)
    ├── start-mcp.sh            # MCP 启动 (macOS/Linux)
    ├── start-mcp.ps1           # MCP 启动 (Windows)
    ├── stop-mcp.sh             # MCP 停止 (macOS/Linux)
    ├── stop-mcp.ps1            # MCP 停止 (Windows)
    ├── status.sh               # 登录状态 (macOS/Linux)
    ├── status.ps1              # 登录状态 (Windows)
    ├── mcp-call.sh             # MCP 调用 (macOS/Linux)
    ├── mcp-call.ps1            # MCP 调用 (Windows)
    ├── generate_xhs_image.py   # 配图生成 (跨平台)
    └── check_install.py        # 环境检查 (跨平台)
```

> **二进制文件说明**：xiaohongshu-mcp 和 xiaohongshu-login 二进制文件通过 `install-binaries.sh` / `install-binaries.ps1` 从 [GitHub Releases](https://github.com/xpzouying/xiaohongshu-mcp/releases) 自动下载到 `~/.local/bin/`（SkillHub 不支持上传二进制文件）。

---

## 更新日志

### v1.2.0
- 二进制文件改为从 GitHub Releases 自动下载（SkillHub 不支持上传二进制文件）
- 新增 `install-binaries.sh` / `install-binaries.ps1` 自动下载安装脚本，支持多平台检测
- 内置 MCP 服务管理脚本（start/stop/status/mcp-call），bash + PowerShell 双版本
- 完全独立运行，不再需要安装其他 skill
- 修正 publish_content 参数：`images`（非 `image_paths`）、`content`（非 `desc`）、`tags`（非 # 号内嵌）
- 记录踩坑：`additionalProperties: false` 严格模式，额外字段会报错

### v1.1.0
- Phase 4 从浏览器自动化改为 xiaohongshu-mcp API 发布（更稳定、更快）
- 移除 agent-browser 依赖，改为 xiaohongshu-mcp 服务依赖
- 新增 MCP 服务状态检查和自动登录引导
- 修复标题超长问题（限制 ≤20 字符）
- 记录踩坑经验：用 curl + python3 构造 JSON 比 Python 客户端更可靠

### v1.0.0
- 整合文案生成、AI配图、自动发布三大能力
- 支持 8 种文案风格模板自动匹配
- 支持 54 种配图艺术风格
- 浏览器自动化发布支持上传配图和文字配图两种模式
