# 权威书籍参考库

> 本文件为技能内部参考索引。每本书只提炼核心观点供建议生成时调用，不存储原文。所有面向用户的表述均为团队自主编写。

---

## 英文核心文献

### 1. *Self-Determination Theory* — Ryan & Deci (2017)
- **出版**：Guilford Press
- **核心观点**：人类行为驱动力来自三大基本心理需求（自主感/胜任感/归属感），外部控制会侵蚀内在动机
- **本技能调用场景**：解释"为什么孩子沉迷游戏"——游戏精准满足了现实中被挫败的心理需求
- **关联理论**：SDT
> 来源：Ryan, R.M. & Deci, E.L. (2017). *Self-Determination Theory: Basic Psychological Needs in Motivation, Development, and Wellness*. Guilford Press.

### 2. *Screenwise* — Devorah Heitner (2016/2023修订)
- **出版**：Bibliomotion / 2023修订版
- **核心观点**：家长应做孩子数字生活的"导师"(mentor)而非"看门人"(gatekeeper)；与其监控不如建立信任和对话
- **本技能调用场景**：建议家长角色转换时引用——从"管控者"到"引导者"
- **关联理论**：媒介干预理论（主动型/共同使用型）
> 来源：Heitner, D. (2016). *Screenwise: Helping Kids Thrive (and Survive) in Their Digital World*. Bibliomotion.

### 3. *The Art of Screen Time* — Anya Kamenetz (2018)
- **出版**：PublicAffairs
- **核心观点**：反对一刀切的"屏幕时间限制"；提出"放松+警觉"(relax + be vigilant)原则——不必恐慌，但要保持关注和对话
- **本技能调用场景**：家长焦虑犹豫型(D型)时，帮助"定锚"——什么程度是正常的，什么程度需要干预
- **关联理论**：媒介素养、循证育儿
> 来源：Kamenetz, A. (2018). *The Art of Screen Time: How Your Family Can Balance Digital Media and Real Life*. PublicAffairs.

### 4. *The New Childhood* — Jordan Shapiro (2018)
- **出版**：Little, Brown Spark
- **核心观点**：反对"屏幕恐慌"叙事；主张家长应与孩子共同参与数字世界而非将其视为敌人
- **本技能调用场景**：纠正家长"游戏=洪水猛兽"的极端认知，建立更平衡的视角
- **关联理论**：数字公民教育
> 来源：Shapiro, J. (2018). *The New Childhood: Raising Kids to Thrive in a Connected World*. Little, Brown Spark.

### 5. *Growing Up in Public* — Devorah Heitner (2023)
- **出版**：TarcherPerigee
- **核心观点**：帮助青少年在数字世界中管理隐私、身份和声誉；家长要尊重青少年的数字主权
- **本技能调用场景**：高年龄段(15-17)的隐私边界问题——不要偷看手机/游戏记录
- **关联理论**：发展阶段理论（同一性探索期）
> 来源：Heitner, D. (2023). *Growing Up in Public: Coming of Age in a Digital World*. TarcherPerigee.

### 6. *Motivational Interviewing with Adolescents and Young Adults* — Naar & Suarez (2011/2021第2版)
- **出版**：Guilford Press
- **核心观点**：MI技术在青少年群体的系统应用指南：开放式提问、反映式倾听、引出矛盾、支持自主权
- **本技能调用场景**：生成MI风格的沟通话术和提问模板
- **关联理论**：动机式访谈
- **AI适用边界**：可转化为提问模板，但实时共情性回应需要家长自己执行
> 来源：Naar, S. & Suarez, M. (2021). *Motivational Interviewing with Adolescents and Young Adults* (2nd ed.). Guilford Press.

### 7. *Irresistible: The Rise of Addictive Technology* — Adam Alter (2017)
- **出版**：Penguin Press
- **核心观点**：行为设计（变比率强化、无限滚动等）如何系统性制造"停不下来"——不是孩子意志力差，是设计层面在"钩"他
- **本技能调用场景**：帮家长理解"为什么戒不掉"，降低对孩子的道德指责
- **关联理论**：行为科学、媒介素养
> 来源：Alter, A. (2017). *Irresistible: The Rise of Addictive Technology and the Business of Keeping Us Hooked*. Penguin Press.

---

## 中文核心文献

### 8. 《游戏不失控》 — 阿洛克·卡诺吉亚 (2025中译)
- **核心观点**：作者曾亲历游戏成瘾，以家长+专家双重视角提供指导；强调理解先于干预
- **本技能调用场景**：帮助家长建立同理心——"沉迷"不是道德缺陷
> 来源：卡诺吉亚 (2025). 《游戏不失控》. 中译版.

### 9. 《网络成瘾探析与干预》 — 陶然等
- **核心观点**：中国首部系统论述网络成瘾的专著，涵盖医学/心理学/教育学/社会生态学多视角
- **本技能调用场景**：识别真正的"成瘾"vs普通的"沉迷"，避免过度病理化
- **AI适用边界**：成瘾的临床判断需要专业人士，技能只帮助识别信号
> 来源：陶然等. 《网络成瘾探析与干预》. 多版本.

### 10. 《游戏力》 — 劳伦斯·科恩 (2011中译)
- **核心观点**：用"游戏"作为连接亲子关系的桥梁；理解孩子通过游戏表达的情感需求
- **本技能调用场景**：建议家长"一起玩"时的理论依据——共同使用(co-use)策略
> 来源：科恩 (2011). 《游戏力》. 中译版. 基于Cohen, L. *Playful Parenting*.

### 11. 《P.E.T.父母效能训练》 — 托马斯·戈登 (经典中译)
- **核心观点**："积极倾听"和"我-信息"技术——不评判、表达自己的感受而非指责对方
- **本技能调用场景**：NVC四步法的互补工具，特别是"我-信息"（"我担心..."替代"你又..."）
> 来源：戈登. 《P.E.T.父母效能训练》. 中译版. 基于Gordon, T. *Parent Effectiveness Training*.

### 12. 《如何说孩子才会听，怎么听孩子才肯说》 — Faber & Mazlish (经典中译)
- **核心观点**：实操性最强的亲子沟通工具书——接纳情绪、替代惩罚、鼓励自立
- **本技能调用场景**：话术生成时的风格参考——口语化、场景化、可执行
> 来源：Faber, A. & Mazlish, E. 《如何说孩子才会听，怎么听孩子才肯说》. 中译版.

---

## 使用原则

1. **提炼观点，不复制文字**：从书中提取思想层面的核心主张，用自己的语言重新表达
2. **多源交叉**：同一个观点至少来自2-3个不同来源，避免过度依赖单一作品
3. **标注来源但不向用户展示**：来源信息供内部维护、专家评审和迭代更新使用
4. **区分"理论书"和"实操书"**：理论书指导判断逻辑，实操书影响话术风格
