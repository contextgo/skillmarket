---
name: user-pip-install
description: "非 root 用户安装 pip — 无需 root/sudo。当用户说：没有 pip、没有 pip3、缺少 pip、安装 pip、pip 安装失败、装 pip、--break-system-packages 时使用。"
version: 1.0.0
---

# 非 root 用户安装 pip

```bash
bash {baseDir}/scripts/install_pip.sh
```

安装完成后 pip3 即可直接使用。

## 注意事项

- `--break-system-packages`：Debian bookworm (PEP 668) 必须加