import json
import sqlite3
import sys

DB_PATH = "/root/.openclaw/workspace/skills/accounting/accounting.db"

def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("CREATE TABLE IF NOT EXISTS transactions (id INTEGER PRIMARY KEY, user TEXT, action TEXT, amount REAL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)")
    conn.commit()
    conn.close()

def get_balance(user="default"):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT SUM(CASE WHEN action='deposit' THEN amount ELSE -amount END) FROM transactions WHERE user=?", (user,))
    row = c.fetchone()
    conn.close()
    return row[0] if row[0] else 0.0

def record(user, action, amount):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("INSERT INTO transactions (user, action, amount) VALUES (?,?,?)", (user, action, amount))
    conn.commit()
    conn.close()
    return get_balance(user)

def execute(args):
    init_db()
    user = args.get("user", "default")
    action = args.get("action", "").lower()
    amount = float(args.get("amount", 0))
    if action == "deposit":
        new_balance = record(user, "deposit", amount)
        return f"✅ 存入 {amount}万\n💰 当前余额 {new_balance}万"
    elif action == "withdraw":
        bal = get_balance(user)
        if bal < amount:
            return f"❌ 余额不足，无法取出 {amount}万 (当前余额 {bal}万)"
        new_balance = record(user, "withdraw", amount)
        return f"✅ 取出 {amount}万\n💰 当前余额 {new_balance}万"
    elif action == "query":
        bal = get_balance(user)
        return f"💰 当前余额 {bal}万"
    else:
        return "未知操作"

if __name__ == "__main__":
    input_data = json.loads(sys.stdin.read())
    result = execute(input_data)
    print(result)

