---
name: accounting
description: 记账助手，支持存入、取出、查询余额操作。
---
# 记账助手 (Accounting)

这是一个用于管理群内“卡片”余额的技能。

## 功能
- **存入 (deposit)**：记录一笔存入金额。
- **取出 (withdraw)**：记录一笔取出金额。
- **查询 (query)**：查询当前余额。

## 可用工具
- **exec**：用于执行后端计算脚本。

## 工作流 (Agent Instructions)
1. 当用户在群聊中说出包含“存、取、入、出、余额”等记账意图的句子时，提取动作和金额。
2. 将用户意图转换为结构化的输入参数：`user` (用户标识)，`action` (deposit/withdraw/query)，`amount` (金额，单位万)。
3. 调用 `exec` 工具执行以下命令：
   `echo '{"user":"[用户标识]","action":"[deposit/withdraw/query]","amount":[金额数字]}' | sudo python3 /root/.openclaw/workspace/skills/accounting/main.py`
4. 将脚本返回的结果直接作为回复发送给用户。
5. 如果用户没有明确的记账意图，不要调用此技能。
