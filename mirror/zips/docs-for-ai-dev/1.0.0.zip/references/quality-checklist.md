# Quality Verification Checklist

> Run this checklist after each documentation phase, and again after all phases are complete. Adapt stack-specific checks based on your project's stack profile (A-G).

## A. Structural Checks (7 items)

| # | Check | How to verify | Pass criteria |
|---|-------|---------------|---------------|
| A1 | All required doc files exist | Check `docs/` against required list from stack profile | All required docs (D01-D09, U01-U03 if UI, O01-O03 if applicable) present |
| A2 | No oversized files (>2000 lines) | Count lines per file | All files ≤2000 lines or properly split with header notes |
| A3 | No references to pre-split/renamed files | Grep for old filenames that were split or renamed | Zero stale references |
| A4 | Doc index in D01 matches actual files | Compare D01 doc table entries vs `ls docs/` | All files listed, descriptions accurate |
| A5 | D09 (AGENTS.md) doc index matches actual files | Compare D09 doc index section vs `ls docs/` | All files listed with correct "when to read" descriptions |
| A6 | D09 project structure matches D01 | Compare D09 directory tree vs D01 project structure section | Identical file/directory names |
| A7 | Split file headers explain the split | Read first 5 lines of each split file | Each has header note: "This file was split from X. See X-a and X-b for related topics." |

## B. Traceability Checks (7 items)

| # | Check | How to verify | Pass criteria |
|---|-------|---------------|---------------|
| B1 | Every feature in D02 has ≥1 task | List D02 feature modules, check each appears in D06 phase docs | All features covered |
| B2 | Every task has cross-ref field | Read each task in D06 docs, verify cross-ref exists | All tasks have cross-refs pointing to specific doc + section |
| B3 | Every cross-ref is valid | Check referenced doc file exists + section number exists | All refs resolve to real content |
| B4 | Every UI component has visual spec | Cross-reference D05 component list with U02 visual spec files (UI projects only) | All components covered or marked as framework primitive wrapper |
| B5 | Every data model struct has full annotations | Scan D05 for all structs/interfaces — check each has derive macros / serde tags / validators / Zod schemas (per stack) | All structs have complete framework-required annotations |
| B6 | D02 interfaces match D05 structs | Compare field names, types, optionality per struct between D02 and D05 | All fields match (with documented naming convention conversion if applicable, e.g., snake_case ↔ camelCase) |
| B7 | Phase dependencies reference real tasks | Verify each dependency ID exists in prior phase doc | No false dependency claims — every referenced task ID is real |

## C. Consistency Checks (8 items)

| # | Check | How to verify | Pass criteria |
|---|-------|---------------|---------------|
| C1 | Tagged/discriminated enum strategy consistent | Grep for untagged/ambiguous union patterns across all docs | Consistent use of tagged/discriminated unions — no untagged patterns unless explicitly documented as acceptable |
| C2 | No deprecated/outdated library references | Grep for libraries that were replaced during design evolution | Only current libraries appear as actual dependencies; replaced ones appear only in explanatory notes |
| C3 | Multi-instance state pattern (UI projects) | Grep for singular global state patterns (e.g., single `current*` variables holding one value instead of per-tab/per-context maps) in D05/D06 | Uses per-tab/per-context storage pattern where applicable |
| C4 | Storage authority per data type | Check D05 and D08 for each data type | Single authority per data type, stated consistently in both docs |
| C5 | API/command registration parity | Compare registration list in D04 vs registration in D05 | Identical command/endpoint list |
| C6 | Design token naming consistent | In non-authority docs, grep for shorthand tokens (e.g., `var(--brand)`) outside the U01 authority doc | Only implementation variable names used (e.g., `var(--color-brand)`); shorthand appears only in U01 mapping table |
| C7 | Security path validation present (Desktop/API) | Check D06 task acceptance criteria for path/file validation | Mentions path validation function or equivalent security measure |
| C8 | Async DB access pattern stated (if applicable) | Check D05 and D08 for database access patterns | Documents correct async pattern (spawn_blocking for blocking drivers, connection pooling for async drivers) |

## D. AI Consumption Checks (8 items)

| # | Check | How to verify | Pass criteria |
|---|-------|---------------|---------------|
| D1 | D09 (AGENTS.md) has all required sections | Read D09 | Commands, structure, conventions, principles, tokens (UI), deps, index, pitfalls — all present |
| D2 | D09 pitfall list has ≥8 items | Count pitfalls | ≥8 "don't use X, use Y instead" items with clear direction |
| D3 | D05 config files have full content | Read D05 config sections | Complete file contents, not snippets or "see example" |
| D4 | D05 entity list has testable ID column | Read D05 entity/component table header | Column exists (data-testid, endpoint path, command name, etc.) |
| D5 | D06 tasks have all 6 required fields | Read any 5 tasks from phase docs | ID, dependencies, time estimate, acceptance criteria, key files, cross-refs — all present |
| D6 | D07 error code/type enum complete | Read D07 | All error codes/types have consumer-side mapping AND recovery strategy (retry/fallback/degradation) per error category |
| D7 | Font/asset packaging strategy present (UI projects) | Read D05 asset sections | @font-face or equivalent declarations + file paths |
| D8 | CI type-sync step present (cross-language projects) | Read D05 CI sections | Type generation command + diff verification step documented |
| D9 | U01 accessibility spec present (UI projects) | Read U01 accessibility section | WCAG level target, focus ring spec, contrast ratios, touch targets, reduced-motion alternatives — all present |
| D10 | D05 deployment section present | Read D05 deployment section | Target platform, packaging/release process, rollback procedure — all present per stack |

## E. Depth & Completeness Checks (8 items)

| # | Check | How to verify | Pass criteria |
|---|-------|---------------|---------------|
| E1 | Naming conventions consistent | Check naming-conventions.md compliance across D02, D05, D04, U01/U02 | Same struct names in D02 and D05. CSS uses implementation variables, not shorthand tokens. File names follow kebab-case convention. |
| E2 | Template structure adherence | Compare each doc against doc-templates.md outline for that doc ID | All required sections present per template |
| E3 | D04 validation rules per endpoint/command | Read D04, check each endpoint/command has input validation rules | Every input has constraint + error message documented |
| E4 | D05 logging/observability specs | Read D05 logging section | Logging library stated, log format defined, log level guide present, error reporting integration mentioned, metrics approach described |
| E5 | D05 CI/CD pipeline completeness | Read D05 CI/CD section | Full pipeline YAML present, build matrix defined, lint+typecheck+test steps, artifact strategy, release automation, rollback procedure, env-specific deployment |
| E6 | U01 responsive breakpoint coverage (UI) | Read U01 breakpoints section | Named breakpoints with pixel widths + layout strategy per tier |
| E7 | U01 theme system completeness (UI) | Read U01 theme section | Light+dark palettes, token override table, preference persistence, system detection, transition approach |
| E8 | U01 notification system completeness (UI) | Read U01 notification section | Toast types, positioning, duration per type, stacking limit, dismissal, z-index, animation, aria-live |

**Total: 40 checks (A1-A7 + B1-B7 + C1-C8 + D1-D10 + E1-E8). Passing all 40 = near-perfect, AI-consumable documentation set.**

> **Stack adaptation**: Checks C7, C8, D7, D8, D9, D10, E6, E7, E8 only apply when the project type includes those concerns. Skip them (and note "N/A") for projects that don't need path validation, async DB, font packaging, type sync, UI, responsive design, theme system, or notification system. The remaining 31 checks apply universally.