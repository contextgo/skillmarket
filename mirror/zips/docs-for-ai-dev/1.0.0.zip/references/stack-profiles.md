# Stack Profiles: Per-Project-Type Doc Selection

> Determines which documents are required, optional, or skipped based on project type.

## Profile A: Desktop App (Tauri / Electron / native)

**Required**: D01-D09 + U01-U03 + O01
**Optional**: O02, O03 (multi-protocol, AI module), O04 (if multi-language)

Special considerations:
- **IPC layer**: Tauri Commands / Electron IPC / native FFI — define in D04
- **Backend embedded**: Rust/Swift/Kotlin runs in same process — state management, error handling across IPC boundary
- **invoke_handler parity**: Registration in D04 must match D05 exactly
- **Crypto in backend**: Keys never cross IPC — vault/keyring design in O01
- **Multi-window state**: Per-tab/per-window response storage pattern in D08

File count: ~20 files minimum

## Profile B: Web SPA (React / Vue / Svelte)

**Required**: D01-D09 + U01-U03
**Optional**: O01 (if SPA calls external APIs with auth/crypto), O02, O04 (if multi-language)

Special considerations:
- **No IPC layer**: D04 describes external HTTP API contracts (OpenAPI/Swagger or informal)
- **No backend structs**: D05 contains TypeScript interfaces + config files only
- **State management**: Zustand/Pinia/etc. store design in D03
- **CSS framework**: Tailwind/CSS Modules — token mapping in U01
- **Network calls**: HTTP client (fetch/axios) — state in D08
- **Responsive design**: U01 must define breakpoints; U02 must have per-breakpoint ASCII art
- **Auth security**: If SPA handles tokens (JWT, OAuth), include O01 for token handling, XSS prevention, CSP headers

File count: ~15 files minimum

## Profile C: Full-stack Web (React + Go/Python/Java backend)

**Required**: D01-D09 + U01-U03 + O01
**Optional**: O02, O04 (if multi-language)

Special considerations:
- **Separate backend**: D03 has two sub-docs: frontend architecture + backend architecture
- **API boundary**: D04 describes HTTP REST/gRPC API (request/response schemas, status codes, pagination)
- **Two codebases**: D05 splits into frontend dev guide + backend dev guide
- **Auth**: JWT/session/OAuth — cross-stack auth flow in O01
- **Database**: Backend ORM/query patterns in D08

File count: ~22 files minimum

## Profile D: API Service / Microservice

**Required**: D01-D09 + O01
**Optional**: O04 (if multi-language API responses)
**Skip**: U01-U03 (no UI)

Special considerations:
- **D04 is the core doc**: Every endpoint with method, path, params, response schema, auth requirement, rate limit
- **No component list**: D05 has entity/schema list instead of UI component list
- **No visual specs**: Skip all U-* docs
- **D07 is critical**: Error response format, HTTP status code mapping, retry/deadletter/queue strategy
- **Database schema**: D08 includes migration strategy, connection pooling, transaction patterns
- **API versioning**: D04 includes version strategy (URL header, content type)

File count: ~12 files minimum

## Profile E: CLI Tool

**Required**: D01-D09
**Optional**: O01 (if CLI has auth/credential management)

Special considerations:
- **D04 describes CLI commands**: Name, flags, args, output format, exit codes
- **D03 must include CLI pipeline architecture**: Input parsing → processing → output formatting, config loading priority, signal handling
- **D05 has main entry file**: Command routing, flag parsing, output formatting, terminal capability detection
- **No UI component list**: D05 has command list with flags and output format
- **D07 uses exit codes**: 0=success, 1=error, 2=usage — with stderr/stdout routing, partial success policy
- **D08 includes config schema**: Every config field with type, default, validation; location per OS

File count: ~10 files minimum

## Profile F: Library / SDK

**Required**: D01-D09 + D06 phase docs
**Optional**: O01 (if library has auth/credential management), O04 (if library provides user-facing strings in multiple locales)
**Note**: D07 (error handling) and D08 (state/persistence) are required even for libraries — every library needs error type definitions and state management patterns. D05 scope is narrower: package config + public API types only (no backend/main entry).
**Skip**: U01-U03

Special considerations:
- **D04 describes public API**: Every exported function/class/method with signature, params, return type, throws/errors
- **D05 has package config**: package.json / Cargo.toml / pyproject.toml + example usage
- **D02 interfaces are the library's public types**: These become the actual API contract
- **Error type export patterns**: How errors are surfaced to consumers (Result types, exception hierarchies, error code enums)
- **Versioning/compatibility strategy**: Semver policy, breaking change detection, backward compatibility guarantees
- **Deprecation policy**: How deprecated functions are marked, timeline for removal
- **Changelog format**: Convention (Keep a Changelog or equivalent), generation approach
- **Documentation generation**: API docs tool (rustdoc, JSDoc, Sphinx, etc.) and generation pipeline
- **No visual specs**: Skip all U-* docs

File count: ~8 files minimum

## Profile G: Mobile App (Swift / Kotlin / Flutter)

**Required**: D01-D09 + U01-U03 + O01
**Optional**: O02, O04 (if multi-language — common for mobile)

Special considerations:
- **IPC: platform-native** — SwiftUI bindings / Kotlin coroutines / Flutter channels
- **D04 describes platform APIs**: iOS UIKit/SwiftUI, Android Jetpack, Flutter platform channels
- **Responsive layout**: U02 visual specs include breakpoint/device variations
- **Platform-specific configs**: Info.plist, AndroidManifest, pubspec.yaml in D05
- **Offline-first**: D08 has local DB + cloud sync strategy

File count: ~18 files minimum

---

## Universal Rules (ALL profiles)

1. **AGENTS.md is always required** — it's the AI entry point
2. **Feature design (D02) always has complete interfaces** — in the project's primary language
3. **Phase task lists always have 6 required fields** — ID, dependencies, time estimate, acceptance criteria, key files, cross-refs
4. **Error handling (D07) always exists** — even CLI tools need exit code definitions
5. **State persistence (D08) always exists** — even libraries need config/state management patterns
6. **Any file >2000 lines must be split** — regardless of project type
7. **D05 always includes deployment section** — every project type needs deployment: SPA→CDN, API→Docker/K8s, CLI→package manager, Desktop→installer, Mobile→store
8. **U01 always includes responsive breakpoints and accessibility** — for ALL UI projects (not just Mobile)
9. **O01 required vs optional per profile** — Required for profiles A, C, D, G (Desktop, Full-stack, API, Mobile); Optional for profiles B, E, F (Web SPA, CLI, Library) when auth/crypto/user data is involved
10. **O04 is optional for ALL profiles** — any project requiring multi-language user-facing content should include i18n docs
11. **No size limits per doc** — docs can be as large as needed. Split only when a single file exceeds 2000 lines (see split rule in SKILL.md)