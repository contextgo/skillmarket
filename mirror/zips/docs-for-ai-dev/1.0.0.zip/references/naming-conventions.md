# Naming Conventions Reference

> Universal naming conventions for all artifacts across all project types. Follow these consistently in all docs to prevent AI confusion.

## Document File Naming

| Artifact | Convention | Example |
|----------|-----------|---------|
| Universal doc files | `{number}-{kebab-case}.md` | `01-overview.md`, `02-feature-design.md` |
| UI doc files | `ui-{number}-{kebab-case}.md` | `ui-01-design-system.md` |
| Visual spec files | `ui-02-{page-name}-visual-spec.md` | `ui-02-request-editor-visual-spec.md` |
| Phase task files | `06-task-list-phase{N}.md` | `06-task-list-phase1.md` |
| Additional phase files | `06-task-list-phase{N}{suffix}.md` | `06-task-list-phase2b-protocols.md` |
| Optional doc files | `{descriptive-kebab-case}.md` | `security-and-perf.md`, `i18n.md` |

## Code Naming (per language)

| Artifact | TS/JS Convention | Rust Convention | Go Convention | Python Convention |
|----------|-----------------|----------------|--------------|-------------------|
| Files (components) | PascalCase.tsx | snake_case.rs | snake_case.go | snake_case.py |
| Files (stores/hooks) | camelCase.ts / kebab-case.ts | snake_case.rs | snake_case.go | snake_case.py |
| Interfaces / Types | PascalCase | PascalCase struct | PascalCase struct | PascalCase class |
| Functions / Methods | camelCase | snake_case | PascalCase (exported) / camelCase (private) | snake_case |
| Constants | UPPER_SNAKE_CASE | UPPER_SNAKE_CASE | UPPER_SNAKE_CASE | UPPER_SNAKE_CASE |
| Variables | camelCase | snake_case | camelCase | snake_case |
| Enums (variants) | PascalCase | PascalCase | PascalCase | PascalCase |
| CSS variables | --{prefix}-{name} | — | — | — |

## IPC / API Naming

| Artifact | Convention | Example |
|----------|-----------|---------|
| Tauri commands | snake_case | `send_http_request` |
| Tauri events | kebab-case with domain prefix | `ws-message`, `http-response-chunk` |
| HTTP endpoints | kebab-case | `/api/v1/user-profile` |
| HTTP methods | UPPERCASE | `GET`, `POST` |
| CLI commands | kebab-case or lowercase | `analyze`, `convert` |
| CLI flags | kebab-case (long), single letter (short) | `--verbose`, `-v` |
| CLI env var overrides | UPPER_SNAKE_CASE | `APP_VERBOSE=1` |
| Library public functions | language convention (see Code Naming) | `getUser()` / `get_user()` / `GetUser()` |

## Design Token Naming

| Artifact | Convention | Example |
|----------|-----------|---------|
| Design token (concept) | `{category}-{name}` | `brand`, `bg-surface` |
| Implementation variable (CSS) | `--{prefix}-{category}-{name}` | `--color-brand`, `--color-bg-surface` |
| CSS utility class (Tailwind) | `{category}-{name}` | `text-brand`, `bg-bg-surface` |
| Spacing token | `--spacing-{name}` | `--spacing-sidebar`, `--spacing-url-bar` |

**Authority rule**: U01 CSS variable mapping table defines the token→variable→utility mapping. All other docs use implementation variable names only (e.g., `--color-brand`), never shorthand tokens (e.g., `--brand`).

## Doc Section Naming

| Artifact | Convention | Example |
|----------|-----------|---------|
| Section headers | `## {Number}. {Title}` | `## 3. Tech Stack Table` |
| Subsection headers | `### {Number}.{Sub}. {Title}` | `### 3.1. Responsibility` |
| Cross-references | `filename.md §{number}` | `03-architecture.md §3.1` |
| Task IDs | `{phase}.{sequence}` | `1.01`, `2.15`, `3.08` |

## General Rules

1. **Consistency across docs**: If a struct is called `HttpRequestConfig` in D02, it must be `HttpRequestConfig` in D05 too (not `RequestConfig` or `HttpReqConfig`)
2. **Language-appropriate conversion**: When crossing language boundaries (e.g., Rust→TS), document the conversion rule: `snake_case` → `camelCase` via ts-rs, serde `rename_all = "camelCase"`
3. **No abbreviations in docs**: `HttpRequestConfig`, not `HRC` or `ReqCfg`. Abbreviations are context-dependent and confuse AI
4. **Descriptive names for test IDs**: `data-testid="url-bar-method-dropdown"`, not `data-testid="mdd"`