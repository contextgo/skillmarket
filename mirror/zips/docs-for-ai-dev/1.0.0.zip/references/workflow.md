# Workflow: From Idea to AI-Ready Documentation

> 8-phase workflow for producing AI-consumable documentation. Adapt outputs per project type using the stack profiles (A-G) from stack-profiles.md.

---

## Phase 0: Project Type Detection (30 min)

**Output**: Selected stack profile (A-G) + required doc list

Steps:
1. Determine project type: Desktop / Web SPA / Full-stack / API Service / CLI / Library / Mobile
2. Select corresponding stack profile
3. List required docs (D01-D09, U01-U03 if UI, O01-O03 if applicable)
4. Estimate total file count and total effort

This determines which phases have UI-specific steps (Phase 5) and which docs are required vs optional.

---

## Phase 1: Research & Requirements Analysis (2-4 hours)

**Output**: `findings.md` + `task_plan.md`

Steps:
1. Study target application domain — UI layout patterns, feature conventions, industry trends
2. Study 3-4 competitors/alternatives — features, tech stack, strengths/weaknesses
3. Document findings: structure, feature list, auth patterns, data management, protocol support
4. Make technical decisions: framework, storage strategy, state management, deployment model
5. Create task_plan.md with phases and tracking

---

## Phase 2: Overview (4-6 hours)

**Output**: `01-overview.md` (D01)

Required content (see doc-requirements.md D01 for full spec):
- Vision statement (1 sentence)
- Target users with pain points
- Core values (3 items)
- Product positioning vs competitors
- Feature priority matrix (P0/P1/P2/P3)
- Phase roadmap (Phase 1-N with weeks and deliverables)
- Tech stack table with versions and rationale
- Project structure directory tree (matching future AGENTS.md)
- Success metrics (quantitative targets relevant to project type)
- Risk assessment with mitigation

Stack-specific additions per doc-requirements.md D01.

---

## Phase 3: Feature Design (8-12 hours) — MOST CRITICAL

**Output**: `02-feature-design.md` (D02)

**This document defines all data model interfaces. If interfaces are incomplete, everything downstream fails.**

Per feature module, write:
1. Feature description (2-3 sentences)
2. **Complete data model interfaces** in project's primary language — every field, every type, every enum variant. No `any`, no placeholders.
3. Business logic rules (validation, state transitions, edge cases)
4. Interaction flow
5. Data relationships (dependencies on other features)

**Critical rules**:
- Discriminated/tagged unions: Use explicit type discriminators, NEVER untagged/ambiguous patterns
- Field naming: Follow project's language conventions
- Every enum is exhaustive — no catch-all variants

Stack-specific interface patterns per doc-requirements.md D02.

---

## Phase 4: Technical Architecture + API Design (8-12 hours)

**Output**: `03-architecture.md` (D03) + `04-api-design.md` (D04) + optional `04c-security-and-perf.md` (O01)

### D03 — Architecture
- Full tech stack table (every library with version + purpose + rationale)
- Architecture diagram (ASCII art showing module boundaries, data flow)
- Module design per component
- Directory structure (matching AGENTS.md)

### D04 — API Design (structure varies by project type)
- Desktop (IPC): ALL commands + ALL events + state struct + registration list
- Web/API (HTTP): ALL endpoints + request/response schemas + error format + pagination + auth
- CLI: ALL commands + flags + output format + exit codes
- Library: ALL public functions + signatures + module organization

### O01 — Security & Performance (if applicable)
- Security design, auth flows, crypto strategy
- Performance targets with numbers
- Test strategy + CI workflow + deployment

**After this phase**: Split any file >2000 lines. Add header notes. Update ALL cross-references.

---

## Phase 5: Visual Specifications (12-16 hours) — UI PROJECTS ONLY

**Output**: `ui-01-design-system.md` (U01) + `ui-02-{page}-visual-spec.md` per major page (U02) + `ui-03-interaction-flow.md` (U03)

Skip this phase entirely for: API Service, CLI Tool, Library/SDK (no UI).

### U01 — Design System
- Color palette: Hex values for both light and dark
- Theme system: Class structure, token overrides per theme, preference persistence, system detection, transitions
- Typography: Font families, weight/size scales
- Spacing/radius/shadow scales
- Animation tokens: Per type table (enter/exit/emphasis/loading) with duration, easing, trigger, reduced-motion
- Responsive breakpoints: Names + pixel widths, layout strategy per tier
- Layout architecture: ASCII art with pixel dimensions per breakpoint tier
- Component specs: Per component — framework primitive, props, states, accessibility attributes
- Notification system: Toast types, positioning, duration, stacking, dismissal, z-index, animation, aria-live
- Accessibility: WCAG level, focus ring, contrast ratios, touch targets, reduced-motion, screen reader patterns
- **CSS variable mapping table** (THE AUTHORITY): design token → implementation variable → utility class

### U02 — Visual Specs (one file per major page/view)
Per page:
1. ASCII art layout diagram with pixel dimensions — **one diagram per breakpoint tier** (mobile + desktop minimum)
2. CSS/code blocks with exact values from U01 tokens (not vague descriptions)
3. State matrices with accessibility column (idle/hover/active/error/disabled + aria attributes per state)
4. Implementation variable names only (from U01 mapping table)
5. Toast overlay zone marked in ASCII art
6. Empty state visual spec with exact CSS
7. Loading skeleton spec with exact CSS

### U03 — Interaction Flow
- User flows for every major task
- State transitions
- Empty states
- Error flows with D07 error code references, toast vs inline per type
- Keyboard shortcuts complete list
- Drag-and-drop flows (if applicable)
- Undo/redo flows (if applicable)
- Bulk action flows (if applicable)
- Touch interaction patterns (if mobile/tablet)

**Critical**: Don't leave any component without a visual spec. AI will guess the layout, producing inconsistent UI.

---

## Phase 6: Dev Guide + AGENTS.md + Task Lists (8-12 hours)

**Output**: `05-dev-guide.md` (D05) + `AGENTS.md` (D09) + `06-task-list-phase1.md` (D06) + additional phase docs

### D05 — Dev Guide (most important for AI)
- Project prerequisites: OS, runtime versions, required tools
- Init steps: Exact commands, copy-paste-ready
- ALL config files: Full content (every line, pinned versions)
- ALL data model structs: With complete annotations
- Entity/component list: Table with testable ID column
- Interface definitions for every entity
- Error handling: Complete error code/type enum with mapping + recovery strategy
- Test strategy: Framework, test type matrix, mock/fixture strategy, coverage targets, naming convention
- Logging/observability: Library, format spec, level guide, error reporting, metrics
- CI/CD pipeline: Full YAML, build matrix, all steps, artifact strategy, release, rollback
- Deployment: Per stack — packaging, env vars, secrets, post-deploy verification, rollback

Stack-specific additions per doc-requirements.md D05.

### D09 — AGENTS.md (keep concise, aim for ≤400 lines)
- Key commands
- Project structure (matching D01)
- Code conventions
- Architecture principles (8-10)
- Design tokens (UI projects only)
- Dependency versions (authority)
- Doc index with "when to read" column
- Pitfall list (8-16 items)

### D06 — Phase Task Lists
Each task has 6 required fields:
1. Task ID (sequential: 1.01, 1.02, etc.)
2. Dependencies (specific prior task IDs)
3. Time estimate (hours)
4. Acceptance criteria (specific, testable)
5. Key files (exact paths)
6. Cross-refs (specific doc + section number)

Additional phase docs when features span multiple domains (O03).

**Never leave features without tasks** — if a feature in D02 has no task, it's a gap.

---

## Phase 7: Supporting Docs (4-6 hours)

**Output**: `07-error-handling.md` (D07) + `08-state-persistence.md` (D08) + optional docs (O01, O02)

### D07 — Error Handling
- Error type/code enum: All codes with detail structure
- Consumer-side mapping: Per error code — UI display / HTTP response / CLI output
- Error format spec: JSON shape or equivalent
- Recovery strategy: Per error category — retry params, fallback, degradation, user action

### D08 — State Persistence
- Storage authority per data type (ONE authority, stated explicitly)
- Sync protocol: Write → persist → confirm
- Conflict resolution strategy
- Schema DDL (CREATE TABLE for every table — DB-backed projects)
- Migration strategy (tool, rollback, zero-downtime — DB-backed projects)

Stack-specific additions per doc-requirements.md D07 and D08.

### O02 — Deep Analysis (if major corrections occurred)
- Decision record: What was wrong, what changed, why

---

## Phase 8: Audit & Fix (6-10 hours, 4 rounds minimum)

### Round 1: Structural Audit (7 checks — A1-A7)
- All required doc files exist per stack profile?
- No files >2000 lines without splits?
- No stale references to pre-split/renamed files?
- D01 and D09 doc tables match actual files?
- D09 project structure matches D01?
- Split file headers explain the split?

### Round 2: Traceability Audit (7 checks — B1-B7)
- Every feature in D02 has ≥1 task?
- Every task has valid cross-ref?
- Every UI component has visual spec? (UI projects)
- Every data model has full annotations?
- D02 interfaces match D05 structs?
- Phase dependencies reference real tasks?

### Round 3: Consistency Audit (8 checks — C1-C8)
- Enum strategy consistent (no untagged)?
- No deprecated library references as actual deps?
- Multi-instance state pattern used where needed? (UI)
- Storage authority consistent between D05 and D08?
- API/command registrations match between D04 and D05?
- Design tokens use implementation variable names? (UI)
- Security path validation present? (Desktop/API)
- Async DB pattern stated? (if applicable)

### Round 4+: AI Consumption & Depth Audit (18 checks — D1-D10 + E1-E8)
- D1: D09 has all required sections?
- D2: D09 pitfall list ≥8 items?
- D3: D05 config files have full content?
- D4: D05 entity list has testable ID column?
- D5: D06 tasks have all 6 fields?
- D6: D07 error enum complete with recovery strategy?
- D7: Font/asset packaging present? (UI)
- D8: CI type-sync step present? (cross-language)
- D9: U01 accessibility spec present? (UI)
- D10: D05 deployment section present?
- E1: Naming conventions consistent across docs?
- E2: Each doc follows doc-templates.md outline?
- E3: D04 validation rules per endpoint/command?
- E4: D05 logging/observability specs?
- E5: D05 CI/CD pipeline completeness?
- E6: U01 responsive breakpoints coverage? (UI)
- E7: U01 theme system completeness? (UI)
- E8: U01 notification system completeness? (UI)

**After each round**: Fix ALL issues, commit, push, re-verify. Expect ~30 issues total over 3-4 rounds, diminishing to 0-2 by final round.

**Passing all 40 checks = near-perfect, AI-consumable documentation set.**