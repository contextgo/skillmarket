# AI Consumption Optimization Patterns

> These 8 patterns ensure AI agents can consume documentation efficiently, without guessing, without wasting context, and without producing inconsistent output. Patterns apply to ALL project types — stack-specific examples are noted where relevant.

---

## Pattern 1: AGENTS.md as Single Entry Point

AI agents read files sequentially. Without an entry point, they randomly browse docs, wasting context.

**AGENTS.md (D09) solves this** — it tells AI:
1. What commands to run (install, dev, build, lint, test)
2. Where files live (project structure tree)
3. What code conventions to follow (language style, naming, import patterns, annotation patterns)
4. What NOT to do (pitfall list: "Don't use X, use Y instead")
5. What docs to read for each task (doc index with "when to read" column)

**Key**: AGENTS.md should be concise — aim for ≤400 lines. If it exceeds this, consider whether sections could be trimmed, but do not cut essential content.

**Stack examples**:
- Desktop (Tauri): `pnpm dev`, `cd apps/desktop && pnpm tauri dev`, `cargo check`
- Web SPA: `npm run dev`, `npm run lint`, `npm run typecheck`
- API Service: `go run .`, `go test ./...`, `docker-compose up`
- CLI: `cargo run`, `npm test`, `python -m pytest`

---

## Pattern 2: Atomic Tasks with Cross-References

Each task in phase docs (D06) has a cross-ref field pointing to specific doc + section. This is the most powerful AI consumption pattern:

```
Cross-ref: 03-architecture.md §3.1; ui-02-request-editor-visual-spec.md §2.2
```

AI reads only the referenced sections, not entire files. This:
- Reduces context usage by 10-50x
- Provides exact design guidance (not vague "make it look nice" or "implement correctly")
- Creates traceability chain: task → architecture → visual spec / API spec

**Failure mode**: Tasks without cross-refs force AI to guess design, producing inconsistent UI and wrong architecture choices.

**Applies to ALL project types** — cross-refs may point to architecture, API design, visual spec, error handling, or state persistence docs depending on the task's nature.

---

## Pattern 3: Pixel-Level / Exact-Value Specs

Specs (visual, API, CLI, library) must contain **exact values**, not vague descriptions.

**UI projects** (U02 visual specs):
- ASCII art layout diagrams with exact pixel dimensions
- CSS/code blocks with exact variable values and measurements
- State matrices showing every UI state variation

```css
.sidebar {
  width: 220px;          /* not "wide" */
  background: #13131B;   /* not "dark background" */
  border-right: 1px solid #2A2A38;
}
```

**API projects** (D04):
- Exact request/response schemas with field types, required/optional, validation rules
- Exact error response format with status codes and body structure
- Not "returns user data" — but "returns `{ id: string, name: string, email?: string }`"

**CLI projects** (D04):
- Exact flag names (short + long), exact default values, exact exit codes
- Not "supports verbose mode" — but `-v, --verbose: boolean, default false, outputs debug info to stderr`

**AI reproduces exact implementations from exact specs.** Vague descriptions produce inconsistent output.

---

## Pattern 4: Full Data Model Annotations

Every data model struct in D05 (dev guide) must include **complete framework-required annotations**. Missing annotations = AI guesses behavior.

**Desktop App (Tauri/Rust)**:
```rust
#[derive(Debug, Clone, Serialize, Deserialize, TS)]
#[ts(export_to = "HttpRequestConfig.ts")]
pub struct HttpRequestConfig {
    pub url: String,
    pub method: String,
}
```
Without `#[derive(TS)]`, AI doesn't know types are auto-generated. Without `#[ts(export_to)]`, AI doesn't know the generated file name. Without `Serialize/Deserialize`, AI doesn't know serde behavior.

**Tagged enums MUST use external tags**:
```rust
#[serde(tag = "type", content = "config")]
pub enum AuthConfig { ... }
```
Never `#[serde(untagged)]` — causes deserialization ambiguity that AI can't debug.

**Web SPA (TypeScript)**:
```typescript
export const UserSchema = z.object({
  id: z.string().uuid(),
  name: z.string().min(1),
  email: z.string().email().optional(),
});
export type User = z.infer<typeof UserSchema>;
```
Without Zod schema, AI doesn't know validation rules. Without inferred type, AI doesn't know the runtime-validated shape.

**API Service (Go)**:
```go
type User struct {
    ID    string `json:"id" validate:"required,uuid"`
    Name  string `json:"name" validate:"required,min=1"`
    Email string `json:"email,omitempty" validate:"omitempty,email"`
}
```
Without struct tags, AI doesn't know JSON field names or validation rules.

**General principle**: Include ALL annotations that the framework/language requires for serialization, validation, type generation, and documentation. If you'd need them in production code, AI needs them in the spec.

---

## Pattern 5: Pitfall List in AGENTS.md

The pitfall list prevents AI from choosing wrong libraries/patterns. Minimum 8 items, each with one clear direction. Pitfalls should be drawn from the project's specific stack — below are illustrative examples from different stacks:

```markdown
# Universal pitfalls (ALL projects):
- **Don't use untagged/ambiguous enums** — Use tagged/discriminated unions
- **Don't accept unvalidated file paths** — Validate paths are within allowed directories
- **Don't use blocking calls in async context** — Use spawn_blocking / async drivers / connection pooling

# Desktop (Tauri) pitfalls:
- **Don't use Axios** — Use Rust reqwest via IPC
- **Don't pass secrets through IPC** — Store secrets in backend-side keyring/vault
- **Don't create multiple heavyweight editor instances** — Use singleton pattern

# Web SPA pitfalls:
- **Don't use React Router for state-driven apps** — Use Zustand/Pinia NavigationStore
- **Don't store auth tokens in localStorage** — Use httpOnly cookies or secure session storage

# API Service pitfalls:
- **Don't return raw error messages to clients** — Use structured error response format
- **Don't skip rate limiting on public endpoints** — Apply rate limits per endpoint tier
```

Each pitfall: what NOT to do + what TO do instead. One direction per pitfall. No ambiguity.

**Stack-specific pitfalls**: Desktop apps have IPC pitfalls, API services have auth/middleware pitfalls, CLI tools have output-format pitfalls, libraries have API-stability pitfalls. Each stack has its own set.

---

## Pattern 6: File Size Control

AI context windows are limited. Files >2000 lines:
- Get truncated during reading
- Overflow context when loaded alongside other files
- Reduce AI's ability to follow cross-references within the same file

**Split threshold**: 2000 lines. Split by topic (not arbitrarily):
- Architecture → sub-topics (frontend-architecture, backend-architecture, security-and-performance)
- Visual specs → per-page (home-page, request-editor, sidebar)
- API design → per-domain if very large service

**After split**:
1. Add header note explaining split: "This file was split from X.md. See X-a.md and X-b.md for related topics."
2. Update ALL cross-references in other docs
3. Verify no doc references the old unsplit filename

---

## Pattern 7: Storage Authority Declaration

Each data type must have ONE declared storage authority, stated in BOTH D05 (dev guide) and D08 (state persistence):

```markdown
| Data Type | Storage Authority | Path/Table |
|-----------|-------------------|------------|
| Collections | File System | collections/{id}.json |
| Environments | File System | environments/{id}.json |
| Request History | Database | history table |
| Secrets | Encrypted Storage | vault/{name}.enc |
```

**AI confusion mode**: If D05 says "save to Database" but D08 says "save to File System", AI implements both, creating data inconsistency.

**Adapt per stack**:
- Desktop: File System vs SQLite/local DB vs in-memory — per data type
- Web SPA: localStorage vs sessionStorage vs cookie vs server-side — per data type
- API Service: Primary DB vs cache (Redis) vs file storage — per data type
- CLI: Config file (YAML/TOML) vs state file vs in-memory — per data type

---

## Pattern 8: API/Command Registration Parity

The command/endpoint registration in D04 (api design) and D05 (dev guide) MUST be identical lists.

**Desktop (IPC)**:
```rust
.invoke_handler(tauri::generate_handler![
    // Same commands, same order, same module paths
])
```
If they differ, AI follows whichever it reads first, creating missing commands at runtime.

**API Service**:
The middleware/route registration in D04 must match the actual server setup in D05 — same endpoints, same order, same middleware chain.

**CLI**:
The command registration in D04 must match the CLI router in D05 — same commands, same flags, same default values.

**Library**:
The public API listing in D04 must match the exported functions in D05 — same signatures, same module paths.

**Verify**: Diff the two registration lists. They must match exactly.