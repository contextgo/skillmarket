# Document Templates, Quality Grading & Examples

> For each doc ID, this file provides: (1) Template outline — exact section headings, (2) Quality grading — A/B/C criteria, (3) Example snippet — showing expected output quality. Use alongside doc-requirements.md for complete guidance.

---

## D01: Overview

### Template Outline

```
## 1. Vision
## 2. Target Users
## 3. Core Values
## 4. Product Positioning
## 5. Feature Priority Matrix
## 6. Phase Roadmap
## 7. Tech Stack
## 8. Project Structure
## 9. Success Metrics
## 10. Risk Assessment
[Stack-specific additions: §11 Platform/Browser/Deployment targets, etc.]
```

### Quality Grading

| Grade | Criteria |
|-------|----------|
| **A** | Every section filled with specific, quantitative data. Vision is 1 sentence. Users have pain points + goals. Metrics have exact numbers. Risks have probability + impact + mitigation strategy. Tech stack has version + rationale per item. |
| **B** | Most sections filled but some use vague language ("fast", "many users"). Metrics lack exact numbers. Tech stack lacks rationale. |
| **C** | Missing sections (e.g., no risk assessment). Vision is paragraph-length. Users are generic ("developers"). No quantitative metrics. |

### Example Snippet (A-grade Feature Priority Matrix)

```markdown
| Priority | Feature | Description |
|----------|---------|-------------|
| P0 | HTTP Request Editor | Send GET/POST/PUT/DELETE with headers, body, auth — core value proposition |
| P0 | Environment Variables | {{variable}} substitution in URLs, headers, body — essential for team workflows |
| P1 | Collection Runner | Batch-execute requests with variable iteration — automation need |
| P2 | WebSocket Client | Connect, send/receive messages with frame inspection — secondary protocol |
| P3 | AI Code Generation | Natural language → request generation — differentiation, not blocking |
```

---

## D02: Feature Design

### Template Outline

```
## Module 1: [Feature Name]
### 1.1 Description
### 1.2 Data Model Interfaces
  - [Primary interface — all fields, types, enums]
  - [Supporting interfaces — request/response, state, config]
### 1.3 Business Logic Rules
  - Validation rule table: Field | Type | Constraint | Error Message
  - State transitions: State A → trigger → State B
  - Edge cases: what happens when X fails / Y is empty / Z is concurrent
### 1.4 Interaction Flow
  - Trigger → system response → success path → error path
### 1.5 Data Relationships
  - Dependencies on Module N, Module M
### 1.6 Recovery Strategy
  - Per error scenario: retry params, fallback, degradation, user action

[Repeat for each module]
```

### Quality Grading

| Grade | Criteria |
|-------|----------|
| **A** | Every interface has ALL fields with types, optionality, and validation. Every enum lists all variants explicitly. Business logic has validation rule tables, not prose. Recovery strategy per error, not "handle errors". |
| **B** | Interfaces have most fields but some lack types or validation. Enums mostly exhaustive but 1-2 have catch-all. Business logic in prose, not tables. |
| **C** | Interfaces have placeholder types (`any`, `Record<string, any>`). Empty interfaces (`interface Foo {}`). Missing enums. No validation rules. No recovery strategy. |

### Example Snippet (A-grade Data Model Interface)

```typescript
interface HttpRequestConfig {
  url: string;                    // Required. Must be valid URL. Error: "Invalid URL format"
  method: HttpMethod;             // Required. Enum: GET | POST | PUT | DELETE | PATCH | HEAD | OPTIONS
  headers: Record<string, string>; // Optional. Default: {}
  body: RequestBody | null;       // Optional. Null if method=GET/HEAD
  auth: AuthConfig | null;        // Optional. Null = no auth
  timeout: number;                // Optional. Default: 30000. Min: 1000. Error: "Timeout must be ≥1000ms"
}

type RequestBody =
  | { type: 'json'; content: string }    // Must be valid JSON. Error: "Invalid JSON body"
  | { type: 'form'; entries: FormEntry[] }
  | { type: 'raw'; content: string; contentType: string }
  | { type: 'binary'; filePath: string } // Must be valid path within app data. Error: "File not found"

type AuthConfig =
  | { type: 'bearer'; token: string }          // Required: token non-empty
  | { type: 'basic'; username: string; password: string } // Required: both non-empty
  | { type: 'oauth2'; tokenUrl: string; clientId: string; clientSecret: string }
  | { type: 'apikey'; key: string; headerName: string; addTo: 'header' | 'query' }
```

### Example Snippet (C-grade — BAD, DO NOT produce)

```typescript
interface HttpRequestConfig {
  url: any;
  method: string;
  headers?: any;
  body?: any;
  auth?: any;
}
// Missing: type definitions, validation rules, enum variants, error messages
```

---

## D03: Architecture

### Template Outline

```
## 1. Tech Stack Table
## 2. Architecture Diagram (ASCII art)
## 3. Module Design
  - Per module: 3.1 Responsibility, 3.2 Public Interface, 3.3 State, 3.4 Error Handling
## 4. Directory Structure
## 5. Dependency Flow
[Stack-specific additions per doc-requirements.md D03]
```

### Quality Grading

| Grade | Criteria |
|-------|----------|
| **A** | ASCII diagram shows all modules with labeled arrows (sync/async/optional). Every module has 4 subsections. Directory tree matches AGENTS.md. Dependency flow has direction arrows. Tech stack has version + purpose + rationale per row. |
| **B** | ASCII diagram shows modules but arrows unlabeled. Most modules have subsections. Tech stack has version + purpose but no rationale. |
| **C** | No ASCII diagram (just text description). No module subsections. Tech stack is a list without table format. |

### Example Snippet (A-grade Architecture Diagram)

```
┌─────────────┐     ┌──────────────┐     ┌─────────────┐
│   Frontend   │ --> │  IPC Layer   │ --> │   Backend   │
│  (React/TS)  │     │ (Tauri cmds) │     │   (Rust)    │
└─────────────┘     └──────────────┘     └─────────────┘
      │                                          │
      │ ...> (optional)                          │ ==> (async)
      │                                          │
┌─────────────┐                          ┌─────────────┐
│   Store      │                          │  Storage    │
│  (Zustand)   │                          │ (SQLite/FS) │
└─────────────┘                          └─────────────┘

Notation: --> synchronous | ==> asynchronous/event | ...> optional/conditional
```

---

## D04: API Design

### Template Outline

```
## 1. Commands/Endpoints Registry
  - Per command/endpoint: Name | Params | Return | Error | Auth
## 2. Event Definitions (if applicable)
  - Per event: Name | Payload | Direction
## 3. State/Context Struct (if applicable)
## 4. Registration/List Summary
## 5. Stream/Chunk Handling (if applicable)
## 6. Validation Rules per endpoint/command
## 7. Error Response Format
[Stack-specific additions per doc-requirements.md D04]
```

### Quality Grading

| Grade | Criteria |
|-------|----------|
| **A** | Every endpoint/command has exact param types, return types, error types, and validation rules. Registration list matches D05 exactly. Error format defined with JSON schema. |
| **B** | Most endpoints defined but some lack validation or return types. Registration mostly matches D05 with minor differences. |
| **C** | Endpoint list incomplete. No validation rules. Registration differs from D05. Error format is prose description. |

### Example Snippet (A-grade API Endpoint)

```markdown
### POST /api/v1/collections

| Field | Value |
|-------|-------|
| Method | POST |
| Path | /api/v1/collections |
| Auth | Required: Bearer token |
| Rate Limit | 100 req/min (Tier: standard) |

Request body:
```json
{
  "name": "string, required, min=1, max=100, pattern=[a-zA-Z0-9_-]+",
  "description": "string, optional, max=500"
}
```

Response 200:
```json
{ "id": "uuid", "name": "string", "description": "string|null", "createdAt": "ISO8601" }
```

Response 400: `{ "code": "VALIDATION_ERROR", "detail": "name: must match [a-zA-Z0-9_-]+" }`
Response 401: `{ "code": "AUTH_REQUIRED", "detail": "Bearer token required" }`
```

---

## D05: Dev Guide

### Template Outline

```
## 1. Project Prerequisites
## 2. Init Steps
## 3. Config Files (full content per file)
## 4. Data Model Structs (full annotations)
## 5. Entity/Component List
## 6. Cross-cutting Pattern Implementations (pseudocode/code templates)
  - 6.1 Retry with exponential backoff + jitter
  - 6.2 Auth token refresh flow
  - 6.3 Streaming/chunked response handling
  - 6.4 File path validation
  - 6.5 Connection pool lifecycle
  - 6.6 Circuit breaker state machine
## 7. Interface Definitions
## 8. Error Handling (error enum + mapping)
## 9. Test Strategy
## 10. Logging/Observability
## 11. CI/CD Pipeline (full YAML)
## 12. Deployment
## 13. Distribution Artifacts (full content per stack)
## 14. Infrastructure Patterns (enumerated sub-fields per pattern)
  - 14.1 Rate limiting
  - 14.2 Circuit breaker
  - 14.3 Connection pooling
  - 14.4 Graceful shutdown
  - 14.5 Health check
  - 14.6 Observability
[Stack-specific additions per doc-requirements.md D05]
```

### Quality Grading

| Grade | Criteria |
|-------|----------|
| **A** | Config files AND distribution artifacts are copy-paste-ready (every line, pinned versions). Structs have ALL annotations. Entity list has testable ID column. Cross-cutting patterns have pseudocode with exact parameters (not prose "implement retry"). Infrastructure patterns have all enumerated sub-fields with exact values per pattern. CI/CD has full YAML. Deployment has per-stack config. Logging has format spec + metric names + alert thresholds. Health check has liveness + readiness endpoints with response schemas. |
| **B** | Config files mostly complete but some abbreviated. Distribution artifacts described but not full content. Structs have most annotations. Cross-cutting patterns described in prose, not pseudocode. Infrastructure patterns have some fields but not all (e.g., rate limiting lacks response headers). CI/CD described but no YAML. |
| **C** | Config files are snippets or "see docs". No distribution artifacts. No cross-cutting pattern implementations. No infrastructure pattern sub-fields. Structs lack annotations. No entity list. No CI/CD. No deployment. |

### Example Snippet (A-grade Config File — full content)

```json
// package.json — COMPLETE, copy-paste-ready
{
  "name": "api-client",
  "version": "0.1.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "tsc && vite build",
    "lint": "eslint . --max-warnings 0",
    "typecheck": "tsc --noEmit",
    "test": "vitest run",
    "test:watch": "vitest"
  },
  "dependencies": {
    "react": "^19.0.0",
    "react-dom": "^19.0.0",
    "zustand": "^5.0.0",
    "immer": "^10.0.0",
    "@tauri-apps/api": "^2.0.0"
  },
  "devDependencies": {
    "typescript": "^5.5.0",
    "vite": "^5.4.0",
    "eslint": "^9.0.0",
    "vitest": "^2.0.0",
    "@types/react": "^19.0.0"
  }
}
```

### Example Snippet (A-grade Distribution Artifact — Dockerfile for API Service)

```dockerfile
# Dockerfile — COMPLETE, copy-paste-ready, multi-stage build
FROM golang:1.22-alpine AS builder
WORKDIR /app
COPY go.mod go.sum ./
RUN go mod download
COPY . .
RUN CGO_ENABLED=0 GOOS=linux go build -o /server ./cmd/server

FROM alpine:3.19 AS runtime
RUN apk add --no-cache ca-certificates
COPY --from=builder /server /server
EXPOSE 8080
HEALTHCHECK --interval=30s --timeout=5s --retries=3 \
  CMD wget -qO- http://localhost:8080/health/ready || exit 1
ENTRYPOINT ["/server"]
```

### Example Snippet (A-grade Cross-cutting Pattern — Retry with Backoff + Jitter)

```python
# Retry with exponential backoff + jitter — pseudocode (language-agnostic)
function retry_with_backoff(operation, config):
    for attempt in range(0, config.max_attempts):
        try:
            result = operation()
            return result  # Success
        except RetryableError as e:
            if attempt == config.max_attempts - 1:
                raise e  # Final failure, no more retries
            
            # Calculate delay: exponential base + jitter
            base_delay = config.base_delay_ms * (2 ** attempt)
            jitter = random_range(-config.jitter_ms, config.jitter_ms)
            delay = min(base_delay + jitter, config.max_delay_ms)
            
            log.warn(f"Retry {attempt+1}/{config.max_attempts} after {delay}ms: {e}")
            sleep(delay_ms=delay)
    
    # Fallback after all retries exhausted
    return config.fallback()  # e.g., return cached_response or None

# Example config from D07 error entry E002 (NETWORK_TIMEOUT):
retry_config = RetryConfig(
    max_attempts=3,
    base_delay_ms=1000,     # 1s → 2s → 4s
    max_delay_ms=10000,     # Cap at 10s
    jitter_ms=200,          # ±200ms randomization
    fallback=cached_response_fetcher  # From D08 storage authority
)
```

### Example Snippet (A-grade Infrastructure Pattern — Rate Limiting)

```markdown
| Field | Value |
|-------|-------|
| Algorithm | Token bucket |
| Storage backend | Redis (key: `ratelimit:{extracted_key}`) |
| Tier definitions | |
| | Tier: free → 10 RPM, burst: 15 |
| | Tier: standard → 100 RPM, burst: 120 |
| | Tier: premium → 1000 RPM, burst: 1050 |
| Key extraction strategy | API key from X-Api-Key header; fallback: IP from X-Forwarded-For → remote_addr |
| Response headers | X-RateLimit-Limit (tier RPM), X-RateLimit-Remaining (tokens left), X-RateLimit-Reset (epoch seconds) |
| Exceeded response | HTTP 429, body: `{ "code": "RATE_LIMITED", "detail": "Retry after {reset_seconds}s", "tier": "{current_tier}" }` |
```

### Example Snippet (A-grade Infrastructure Pattern — Health Check)

```markdown
### Liveness: GET /health/live
- Response 200: `{ "status": "alive" }`
- Timeout: 5s
- Purpose: Process is running, not deadlocked

### Readiness: GET /health/ready
- Response 200: `{ "status": "ready", "checks": { "db": "connected", "cache": "connected" } }`
- Response 503: `{ "status": "not_ready", "checks": { "db": "disconnected", "cache": "connected" } }`
- Timeout: 10s
- Purpose: Ready to serve traffic (all dependencies available)
```

### Example Snippet (C-grade — BAD, DO NOT produce)

```json
// package.json — abbreviated, NOT copy-paste-ready
{
  "scripts": { "dev": "..." },
  "dependencies": { "react": "...", "zustand": "..." }
  // Remaining fields omitted for brevity — SEE DOCS for full file
}
```

```markdown
// Rate limiting — BAD, vague, no sub-fields
- Implement rate limiting using Redis
- Free tier: slow, Premium tier: fast
```

```markdown
// Health check — BAD, undefined format
- Add a health check endpoint
- Returns OK when healthy
```

---

## D06: Task Lists

### Template Outline

```
## Phase 1: Foundation

### Task 1.01: [Name]
- **ID**: 1.01
- **Dependencies**: (none for first task)
- **Time estimate**: 2h
- **Acceptance criteria**: [specific, testable, exact behavior]
- **Key files**: src/main.tsx, src/App.tsx
- **Cross-refs**: 03-architecture.md §4.1; 05-dev-guide.md §2

### Task 1.02: [Name]
- **ID**: 1.02
- **Dependencies**: 1.01
- ...

[Repeat for each task]
```

### Quality Grading

| Grade | Criteria |
|-------|----------|
| **A** | All 6 fields present per task. Dependencies reference real prior task IDs. Acceptance criteria are specific and testable (not "works correctly"). Cross-refs point to real sections. Every feature in D02 covered. |
| **B** | Most tasks have 6 fields. Some acceptance criteria vague ("looks good"). Some cross-refs point to wrong sections. 1-2 features from D02 uncovered. |
| **C** | Missing fields (no time estimate, no cross-refs). Dependencies say "Phase 1 completed" without task IDs. Features in D02 have no tasks. |

### Example Snippet (A-grade Task)

```markdown
### Task 1.05: Implement URL Bar Component

- **ID**: 1.05
- **Dependencies**: 1.02 (Store setup), 1.04 (Design tokens)
- **Time estimate**: 4h
- **Acceptance criteria**:
  - URL input renders with height 44px (`h-url-bar` token)
  - Method dropdown shows GET/POST/PUT/DELETE/PATCH with correct method color per selection (`text-method-*` tokens)
  - `{{variable}}` syntax highlighted with `.variable-highlight` CSS class
  - Enter key triggers request send (calls `send_http_request` command)
  - URL input validates on blur: empty → red border + error message "URL required"
- **Key files**: src/components/UrlBar.tsx, src/styles/index.css
- **Cross-refs**: 03-architecture.md §3.2 (Frontend architecture); ui-02-request-editor-visual-spec.md §2.1 (URL bar spec)
```

### Example Snippet (C-grade — BAD, DO NOT produce)

```markdown
### Task 1.05: URL Bar

- Implement the URL bar component
- Dependencies: Phase 1 completed
- Acceptance: works correctly, looks good
```

---

## D07: Error Handling

### Template Outline

```
## 1. Error Type/Code Enum
  - Complete list: Code | Name | Detail structure | Category
## 2. Consumer-Side Mapping
  - Per error code: UI display | API response | CLI output
## 3. Error Format Spec
  - JSON shape or equivalent with field definitions
## 4. Recovery Strategy
  - Per category: Retry params | Fallback | Degradation | User action
[Stack-specific additions per doc-requirements.md D07]
```

### Quality Grading

| Grade | Criteria |
|-------|----------|
| **A** | Every error code has consumer mapping + recovery strategy. Error format is JSON schema with exact fields. Recovery has numeric retry params (attempts, backoff seconds, jitter). |
| **B** | Error codes have mapping but some lack recovery strategy. Error format defined but not as schema. Retry params present but vague ("retry a few times"). |
| **C** | Error codes incomplete. No consumer mapping. No recovery strategy. Error format is prose. |

### Example Snippet (A-grade Error Entry)

```markdown
| Code | Name | Category | Detail | UI Display | Recovery |
|------|------|----------|--------|------------|----------|
| E001 | AUTH_REQUIRED | Auth | { requiredMethod: string } | Toast: warning icon, "Sign in required", action: "Go to login" | No retry. Prompt login. Fallback: show public content only. |
| E002 | NETWORK_TIMEOUT | Network | { url: string, timeout: number } | Toast: error icon, "Request timed out", auto-dismiss 5s | Retry: 3 attempts, backoff 1s→2s→4s, jitter ±200ms. Fallback: cached response. |
| E003 | VALIDATION_ERROR | Input | { field: string, rule: string } | Inline: red border on field, message below field | No retry. Highlight invalid field. User must fix input. |
```

---

## D08: State Persistence

### Template Outline

```
## 1. Storage Authority Table
  - Data Type | Authority | Path/Table | Sync Direction
## 2. Sync Protocol
  - Write path → persist → confirmation
## 3. Conflict Resolution
  - Strategy per data type
## 4. Schema Definition (if DB)
  - CREATE TABLE DDL for every table
## 5. Migration Strategy (if DB)
  - Tool + config + rollback procedure
[Stack-specific additions per doc-requirements.md D08]
```

### Quality Grading

| Grade | Criteria |
|-------|----------|
| **A** | Every data type has single authority declared in both D05 and D08. Schema has complete DDL (every column, type, nullable, default, constraint, index). Migration has tool, rollback, zero-downtime approach. |
| **B** | Most data types have authority but some ambiguous. Schema has DDL but missing constraints or indexes. Migration has tool but no rollback. |
| **C** | No authority table. Schema described in prose. No migration strategy. D05 and D08 contradict. |

### Example Snippet (A-grade Storage Authority)

```markdown
| Data Type | Authority | Path/Table | Sync Direction | Conflict Strategy |
|-----------|-----------|------------|----------------|-------------------|
| Collections | File System | collections/{id}.json | FS → UI on load | Last-write-wins (timestamp check) |
| Environments | File System | environments/{id}.json | FS → UI on load | Last-write-wins |
| History | SQLite | request_history table | DB → UI on demand | Append-only, no conflict |
| Vault Secrets | Encrypted FS | vault/{name}.enc.json | Never synced | Single-owner, no concurrent access |
```

---

## D09: AGENTS.md

### Template Outline

```
## 1. Key Commands
## 2. Project Structure (directory tree)
## 3. Code Conventions
## 4. Architecture Principles
## 5. Design Tokens (UI only — quick ref table)
## 6. Dependency Versions (authority table)
## 7. Doc Index (all docs + "when to read")
## 8. Common Pitfalls (8-16 items)
```

### Quality Grading

| Grade | Criteria |
|-------|----------|
| **A** | All 8 sections present. Commands are exact. Structure tree matches D01. Conventions cover naming + imports + annotations. Principles have rationale. Pitfalls have ≥8 items with clear direction. Doc index has "when to read" column. Concise (~300-400 lines). |
| **B** | Most sections present. Commands present but some missing. Conventions partial. Pitfalls have <8 items. Doc index lacks "when to read". |
| **C** | Missing sections (no conventions, no pitfalls). No structure tree. No doc index. |

---

## U01: Design System

### Template Outline

```
## 1. Color Palette (light + dark hex values)
## 2. Theme System (class structure, overrides, persistence, detection)
## 3. Typography (fonts, weight scale, size scale)
## 4. Spacing Scale
## 5. Border Radius Scale
## 6. Shadow Scale
## 7. Animation Tokens (type → duration → easing → trigger → reduced-motion)
## 8. Responsive Breakpoints (name + pixel widths + layout strategy)
## 9. Layout Architecture (ASCII art per breakpoint)
## 10. Component Specs (per component: primitive, props, states, accessibility)
## 11. Notification System (toast types, positioning, duration, stacking, z-index, aria-live)
## 12. Accessibility (WCAG level, focus ring, contrast, touch targets, reduced-motion, screen reader)
## 13. CSS Variable Mapping Table (THE AUTHORITY)
```

### Quality Grading

| Grade | Criteria |
|-------|----------|
| **A** | All 13 sections present. Colors have exact hex for both themes. Breakpoints have pixel widths + layout strategy per tier. Animation table has reduced-motion alternatives. Accessibility has WCAG level + focus ring + contrast ratios. Token mapping table is complete. |
| **B** | Most sections present. Colors only one theme. Breakpoints lack layout strategy. Animation lacks reduced-motion. Accessibility mentions WCAG but no specific ratios. |
| **C** | Missing sections (no breakpoints, no accessibility, no theme system). Token mapping incomplete. Colors are prose ("dark blue"). |

---

## U02: Visual Specs

### Template Outline

```
## [Page Name] Visual Spec

### 1. Layout Diagram (ASCII art per breakpoint tier)
### 2. CSS Code Blocks (exact values from U01 tokens)
### 3. State Matrices (with accessibility column)
### 4. Toast/Notification Overlay Zone
### 5. Empty State Spec
### 6. Loading Skeleton Spec
```

### Quality Grading

| Grade | Criteria |
|-------|----------|
| **A** | ASCII art for mobile + desktop minimum. CSS blocks use U01 implementation variable names. Every interactive element has state matrix with 5+ states + aria attributes. Toast zone marked. Empty + loading states have exact CSS. |
| **B** | ASCII art for desktop only (no mobile). CSS blocks use some shorthand tokens. State matrices missing accessibility column. No toast zone. |
| **C** | No ASCII art (just prose description). CSS values are vague ("dark background"). No state matrices. No empty/loading states. |

---

## U03: Interaction Flow

### Template Outline

```
## 1. User Flows (step-by-step per major task)
## 2. State Transitions (state → trigger → new state)
## 3. Empty States (what user sees with no data)
## 4. Error Flows (failure → recovery path per error type)
## 5. Keyboard Shortcuts (complete list with bindings)
## 6. Special Flows (drag-drop / undo-redo / bulk / touch — if applicable)
```

### Quality Grading

| Grade | Criteria |
|-------|----------|
| **A** | Every major user flow has step-by-step with exact UI response per step. State transitions have trigger + new state. Error flows reference D07 error codes. Keyboard shortcuts complete. |
| **B** | Most flows described but some skip steps. Error flows generic (no error code refs). Some shortcuts missing. |
| **C** | Flows are prose paragraphs. No state transitions. No error flows. Shortcuts list incomplete. |

---

## O01: Security & Performance

### Template Outline

```
## 1. OWASP Top 10 Checklist (which risks apply + mitigation)
## 2. Auth Flow Diagram (login → token → refresh → expiry → logout)
## 3. CSRF/XSS/SQLi/SSRF Prevention (exact mechanism per risk)
## 4. Input Sanitization Strategy
## 5. Audit Logging (format + retention)
## 6. TLS Configuration (min version, cipher suite)
## 7. Secret Management (location + rotation)
## 8. Dependency Vulnerability Scanning
## 9. CORS Policy (if browser clients)
## 10. Performance Targets (quantitative + measurement approach)
## 11. Security Test Strategy
## 12. CI Security Steps
## 13. Deployment Pipeline
```

### Quality Grading

| Grade | Criteria |
|-------|----------|
| **A** | All 13 sections present. OWASP checklist covers all applicable risks with specific mitigation code/config. Auth flow has ASCII diagram. Performance targets have exact numbers + measurement tool. TLS has min version + cipher suite list. |
| **B** | Most sections present. OWASP mentions risks but mitigation is prose. Auth flow described but no diagram. Performance targets lack measurement approach. |
| **C** | Missing sections. Auth flow not documented. No OWASP checklist. No TLS config. Performance targets are vague ("should be fast"). |

---

## O02: Deep Analysis

### Template Outline

```
## 1. Decision Record
  - Per decision: What was wrong | What changed | Why | Impact on downstream docs
## 2. Change Log
  - List of corrections: Doc ID | Section | Change description
## 3. Verification Status
  - Which docs were re-verified | Result (PASS/FAIL)
```

### Quality Grading

| Grade | Criteria |
|-------|----------|
| **A** | Every decision has wrong→changed→why→impact chain. Change log references specific doc IDs + sections. All affected docs re-verified with PASS result. |
| **B** | Decision record present but some decisions lack impact analysis. Change log present but section references vague. Some docs not re-verified. |
| **C** | Prose description of changes without structured decision records. No change log. No verification. |

---

## O03: Additional Phase Docs

### Template Outline

```
[Same structure as D06 — use D06 template with 6-field task format]
[Domain-specific title, e.g., "Phase 2b: Multi-Protocol Support"]
```

Same quality grading as D06.

---

## O04: Internationalization

### Template Outline

```
## 1. i18n Strategy (library, locale files, fallback, key naming)
## 2. Per-Feature String Inventory (which strings are user-facing)
## 3. RTL Support (layout flip strategy, CSS)
## 4. Date/Number/Currency Formatting (per locale)
## 5. Locale Detection (browser/system, user override, persistence)
```

### Quality Grading

| Grade | Criteria |
|-------|----------|
| **A** | Library choice stated with config example. Key naming convention defined (e.g., `feature.section.label`). Every user-facing string listed per feature. RTL has CSS approach. Locale detection has fallback chain. |
| **B** | Strategy stated but no config example. String inventory partial. RTL mentioned but no CSS. Locale detection lacks fallback. |
| **C** | "Use i18n" without specifics. No string inventory. No RTL. No locale detection. |