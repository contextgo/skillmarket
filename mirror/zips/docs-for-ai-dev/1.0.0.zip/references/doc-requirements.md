# Document Content Requirements

> Requirements are organized by doc ID. Each section lists **universal requirements** (all project types) then **stack-specific additions**.

---

## D01: Overview (01-overview.md)

### Universal (ALL projects)
- **Vision**: 1 sentence — what this software does and why it matters
- **Target users**: 3-5 personas with name, role, pain points, goals
- **Core values**: 3 values (what, why, how)
- **Product positioning**: vs 2-3 competitors — differentiation table
- **Feature priority matrix**: P0/P1/P2/P3 — feature name + brief description per row
- **Phase roadmap**: Phase 1-N, each with duration (weeks) and deliverables
- **Tech stack**: Primary language, framework, database, key libraries — with version and rationale
- **Project structure**: Full directory tree (matching AGENTS.md)
- **Success metrics**: Quantitative targets (startup time, latency, memory, throughput — whatever is relevant)
- **Risk assessment**: Top 5 risks with probability, impact, mitigation

### Desktop App additions
- **Platform targets**: Windows/macOS/Linux — minimum versions
- **Package size target**: e.g., <15MB

### Web SPA additions
- **Browser targets**: Chrome/Firefox/Safari/Edge — minimum versions
- **SPA deployment target**: CDN / Vercel / Netlify / self-hosted
- **Bundle size target**: Initial load <200KB (or project-specific target)
- **SSR vs CSR decision**: If applicable, state which pages use SSR vs CSR

### Mobile App additions
- **Platform targets**: iOS/Android — minimum OS versions
- **Store targets**: App Store / Google Play / both
- **Offline-first**: Required or optional

### API Service additions
- **Deployment target**: Cloud / on-prem / edge
- **SLA targets**: Availability, latency, error rate

### CLI Tool additions
- **Shell targets**: bash/zsh/powershell — which shells supported
- **Installation methods**: Homebrew/apt/npm/pip

---

## D02: Feature Design (02-feature-design.md) — MOST CRITICAL

### Universal (ALL projects)

Per feature module:
1. **Feature name + description** (2-3 sentences)
2. **Complete data model interfaces** in project's primary language:
   - Every field with type
   - Every enum with exhaustive variants (no catch-all)
   - Every optional/required field explicitly marked
   - No `any`, `Record<string, any>`, `interface Foo {}` (empty), or TODO placeholders
3. **Business logic rules**: Validation, state transitions, edge cases — with explicit validation rule table per field (field name, type, constraint, error message)
4. **Interaction flow**: What triggers the feature, what system responds, error paths
5. **Data relationships**: Dependencies on other features/modules
6. **Recovery strategy**: Per error scenario — retry parameters (attempts, backoff, jitter, timeout), fallback behavior, degradation pattern, user-facing recovery action

### General interface quality rules
- **Discriminated/tagged unions**: `{ type: 'x', data: Y }` — NEVER untagged/ambiguous union types that AI can't distinguish at runtime
- **Field naming conventions**: Follow project's language conventions (camelCase for TS/Java, snake_case for Rust/Python/Go)
- **Every enum is exhaustive**: List all possible values explicitly. `[string]` catch-all = AI will miss valid cases

### Desktop App (Tauri/Rust backend) additions
### Desktop App (Tauri/Rust backend) additions
- Rust structs with `#[derive(Debug, Clone, Serialize, Deserialize, TS)]` + `#[ts(export_to)]`
- `#[serde(tag = "type", content = "config")]` for tagged enums — NEVER `untagged`
- TypeScript types as discriminated unions matching Rust serde tags

### Desktop App (Electron/Node backend) additions
- TypeScript interfaces with Zod/Joi runtime validation schemas
- IPC channel type definitions (electron-ipc typed contracts)

### Desktop App (Native backend) additions
- Swift structs (macOS) or Kotlin data classes (Android) with Codable/Parcelable annotations
- JNI/FFI bridge interface definitions for cross-language calls

### Web SPA additions
- TypeScript interfaces with Zod validation schemas
- API request/response types matching backend contract
- Optimistic update data model (what updates locally before server confirms)
- Client-side cache/filter/sort state model

### API Service additions
- JSON Schema or Protobuf definitions for every endpoint
- Pagination/filter/sort patterns documented once, referenced by all list endpoints
- Idempotency key model (critical for payment/order APIs)
- Webhook/event model (outbound events, delivery + retry)

### CLI Tool additions
- Command structs: name, flags (short + long), args, default values, required/optional
- Output format definitions: table/JSON/quiet modes
- Config file model: what settings persist, schema definition
- Filter/expression grammar model (if applicable)

---

## D03: Architecture (03-architecture.md)

### Universal
- **Tech stack table**: Every library/package with version, purpose, rationale
- **Architecture diagram**: ASCII art showing module boundaries, data flow, dependency direction
- **Module design**: Per module — responsibility, public interface, state management, error handling
- **Directory structure**: Full tree (matching AGENTS.md)
- **Dependency flow**: What module calls what, in which direction

### Desktop App additions
- Backend module per protocol (HTTP, gRPC, WS, etc.)
- Frontend architecture: Store design, component hierarchy, singleton patterns
- IPC boundary: What crosses IPC, what stays in backend, serialization strategy

### Web SPA additions
- Component hierarchy: Page → Layout → Section → Component tree
- Route/page structure: URL path → page component mapping
- Store architecture: Store-per-feature vs store-per-domain, state shape per store
- API client service layer: Request interceptors, auth header injection, error normalization
- Cache layer: Client-side data caching strategy (SWR, React Query, manual)
- State hydration strategy: Initial data loading, SSR data transfer if applicable
- Code-splitting architecture: Route-based vs component-based splitting strategy

### Full-stack Web additions
- Two sub-docs if >2000 lines: frontend-architecture + backend-architecture
- API boundary contract: REST/gRPC API as the interface boundary
- Two separate deployment pipelines

### API Service additions
- Middleware chain: Auth, rate limit, logging, error handling
- Database layer: ORM/query patterns, connection pooling
- Background jobs: Queue/worker patterns if applicable
- External service integration: Circuit breaker, retry, timeout per external call
- Event bus / pub-sub: Async processing architecture if applicable

### CLI Tool additions
- Pipeline architecture: Input parsing → processing → output formatting
- Config loading priority: Flag > env var > config file > default
- Stdin/stdout/stderr routing architecture
- Signal handling: SIGINT/SIGPIPE handling strategy
- Progress reporting architecture: Progress bar / spinner / quiet mode

---

## D04: API Design (04-api-design.md)

### Desktop App (IPC)
- ALL commands: Name (snake_case), params, return type, error type
- ALL events: Name (kebab-case with domain prefix), payload type, direction
- State struct: Complete definition with field types and lock strategies
- **Registration list**: Complete command registration — must match D05 exactly
- Stream/chunk handling: How large data is streamed, cancel tokens

### Web SPA (HTTP API contract)
- ALL endpoints: Method, path, params, request body schema, response schema, auth requirement
- Error response format: Status codes + error body structure
- Pagination: Offset/cursor pattern, sort/filter params
- Rate limits: Per-endpoint or global
- CORS policy: Allowed origins, methods, headers
- Auth token flow: How SPA acquires/refreshes tokens
- Request cancellation: AbortController / timeout patterns
- Real-time: WebSocket/SSE endpoints if applicable

### API Service (HTTP API)
- OpenAPI/Swagger spec or equivalent
- Every endpoint with: method, path, query params, request body, response codes (200/400/401/403/404/500), response body per code
- Auth requirements per endpoint
- Rate limits and quota per tier
- **Versioning strategy**: Chosen method (URL path / header / content type), version format, lifecycle policy, deprecation timeline, backward compatibility guarantees
- Idempotency key header spec (if applicable)
- Health check endpoint spec
- Webhook outbound: Endpoint, payload schema, delivery + retry + exponential backoff

### CLI Tool
- ALL commands: Name, description, flags (short + long), positional args, default values
- Output formats: table/JSON/quiet per command
- Exit codes: 0/1/2 convention
- Help text: Man page or --help output spec
- Environment variable overrides per flag
- Config file ↔ flag interaction (priority order)
- Stdin piped input handling
- --color=always/never/auto behavior
- Shell completion generation (bash/zsh/fish/powershell)

### Library / SDK
- ALL public functions/methods: Signature, params, return type, throws/errors
- Module organization: Which functions are in which module/package
- Type exports: Which types are part of the public API

---

## D05: Dev Guide (05-dev-guide.md) — MOST IMPORTANT FOR AI

### Universal
- **Project prerequisites**: OS, runtime version (Node/Rust/Go/Python), required tools (git, docker, etc.) — exact versions
- **Init steps**: Exact commands to set up the project from scratch — copy-paste-ready, no "see docs"
- **ALL config files**: Full content — every line, every dependency with pinned version, no placeholders, no abbreviated snippets. Must be copy-paste-ready
- **ALL data model structs**: With complete annotations (derive macros, serde tags, validators — whatever the framework requires)
- **Cross-cutting pattern implementations**: Pseudocode or code templates for patterns referenced across multiple docs but never fully specified — provide exact implementation approach (not just "should retry" but HOW):
  - **Retry with exponential backoff + jitter**: Algorithm pseudocode (attempts, base_delay, max_delay, jitter_range) — e.g., `delay = min(base * 2^attempt + random(-jitter, +jitter), max_delay)`
  - **Auth token refresh flow**: OAuth2 refresh cycle with race condition handling (concurrent requests when token expires)
  - **Streaming/chunked response handling**: Per stack — Desktop: event-based streaming via IPC; API: SSE parsing; CLI: pipe-based chunked output
  - **File path validation**: Exact validation function pseudocode (canonicalize → check prefix against allowed directory)
  - **Connection pool lifecycle**: Acquire → use → release → health check — pseudocode showing pool state transitions
  - **Circuit breaker state machine**: Closed → Open → Half-Open state transitions with exact threshold values from infrastructure patterns section
- **Interface definitions**: Props/schemas/argument types for every entity
- **Error handling**: Error code/type enum with all codes, format spec, consumer-side handling
- **Test strategy**: Framework choice, test type matrix per feature (unit/integration/e2e), mock/stub strategy, fixture strategy, coverage target per type, test file naming/location convention
- **Logging/observability**: Logging library, log format spec (structured JSON or plain text), log level usage guide, error reporting integration, metrics collection approach
- **CI/CD pipeline**: Pipeline definition file (full YAML content), build matrix, lint + typecheck + test steps, artifact strategy, release automation, rollback procedure, environment-specific deployment
- **Deployment**: Per stack — SPA: CDN config / API: Docker/K8s config / CLI: package manager distribution / Desktop: installer packaging / Mobile: store submission. Includes environment variables, secrets management, post-deploy verification
- **Distribution artifacts**: Full content (same rigor as config files) for ALL deployment/distribution files per stack:
  - Desktop: Dockerfile (if containerized), installer config (MSI/DMG/AppImage bundle settings), code signing setup, auto-update server manifest template
  - API Service: Dockerfile (multi-stage build with exact stages), K8s manifests (Deployment + Service + Ingress + ConfigMap + Secret templates — full YAML), container registry config
  - CLI: Homebrew formula (full Ruby content), npm/pip package publish config, cargo publish config, release channel automation
  - Web SPA: CDN configuration, edge function config, deployment provider config (Vercel/Netlify/Cloudflare — full content)
  - Mobile: App Store Connect / Google Play Console config, signing certificate setup, OTA distribution config
- **Infrastructure patterns**: Per pattern, enumerate ALL required sub-fields with exact values:
  - **Rate limiting**: Algorithm (token bucket / sliding window / fixed window), storage backend (Redis / in-memory / DB), tier definitions table (tier name → RPM → burst allowance), key extraction strategy (IP / user ID / API key), response headers (X-RateLimit-Limit, X-RateLimit-Remaining, X-RateLimit-Reset), exceeded response format (status code + body schema)
  - **Circuit breaker**: Failure threshold (consecutive failures count), recovery timeout (seconds), half-open request count, per-external-service configuration table
  - **Connection pooling**: Min/max connections, idle timeout, max lifetime, health check interval, sizing formula (e.g., connections = (concurrent_requests * avg_latency) / 1000)
  - **Graceful shutdown**: Drain timeout (seconds), in-flight request tracking approach, shutdown signal handling sequence, force-kill timeout (seconds), cleanup steps
  - **Health check**: Endpoint path, expected response schema (JSON shape), timeout (ms), liveness vs readiness distinction (different endpoints or different response fields)
  - **Observability**: Metric names table (metric → type → unit → description → alert threshold → alert severity), tracing config (sampling rate, trace header format), dashboard definitions (which metrics on which panels), log correlation ID strategy

### Desktop App (Tauri/Rust backend) additions
- ALL Rust structs with `#[derive(Debug, Clone, Serialize, Deserialize, TS)]` + `#[ts(export_to)]`
- main.rs: Complete file with all imports, module declarations, state init, command registration
- Font packaging: @font-face declarations + file paths
- CI type sync: ts-rs generation + diff verification
- tauri.conf.json bundle section: Full content (installer type, code signing config, auto-update URL, file associations)
- Dockerfile (if dev container used): Full content

### Desktop App (Electron/Node backend) additions
- ALL TypeScript interfaces with runtime validation schemas (Zod/Joi)
- IPC channel type definitions (electron-ipc typed contracts)
- electron-builder config: Full content (installer targets, code signing, auto-update)
- Dockerfile (if dev container used): Full content

### Desktop App (Native backend) additions
- Swift structs (macOS) or Kotlin data classes (Android) with Codable/Parcelable annotations
- JNI/FFI bridge interface definitions for cross-language calls
- Xcode/Android Studio project config: Key settings for packaging
- App Store / Play Store submission config

### Web SPA additions
- ALL TypeScript interfaces matching API contract
- vite.config / next.config: Full content
- API client setup: Base URL, auth headers, error interceptor
- State store definitions: Zustand/Pinia store per feature
- .env management: Dev/staging/production env files, proxy config
- Responsive + dark mode config in Tailwind/CSS setup

### API Service additions
- ALL model/entity definitions (Go structs, Python classes, Java entities)
- ALL repository/interface definitions
- ALL middleware registrations (ordered chain with exact middleware names + config per middleware)
- Database connection config: Connection string template, pool size, timeout, pool sizing formula
- Dockerfile: Full content (multi-stage build, exact stages, base image with digest pinning)
- docker-compose: Full content (all services, health checks, network topology)
- K8s manifests: Full YAML content for Deployment + Service + Ingress + ConfigMap + Secret templates (not just "K8s config" — exact copy-paste-ready manifests)
- Migration tool config: Tool choice, version tracking, rollback commands
- Graceful shutdown pattern: Drain timeout, in-flight request tracking, signal handling sequence, force-kill timeout, cleanup steps — with pseudocode or code template
- Health check: Liveness endpoint path + response schema + timeout; Readiness endpoint path + response schema + timeout (if separate)
- Rate limiting implementation: Algorithm, storage backend, tier table, key strategy, response headers, exceeded response format

### CLI Tool additions
- main entry file: Command routing, flag parsing, output formatting
- Config file handling: Read/write/merge patterns, global + project-local config
- Terminal capability detection setup (color support, width)
- Shell completion generation setup
- Distribution artifacts: Homebrew formula (full Ruby content), Cargo.toml publish section / npm package.json publish config / pip pyproject.toml publish config — per distribution channel
- CI release pipeline per channel: GitHub Actions YAML for auto-publish (cargo publish / npm publish / Homebrew tap update)

---

## D06: Task Lists (06-task-list-phase1.md, phase2, etc.)

### Universal (ALL projects)

Each task MUST have 6 fields:
1. **Task ID**: Sequential (1.01, 1.02, etc.)
2. **Dependencies**: References specific prior task IDs — NEVER vague claims like "Phase 1 completed" without task IDs
3. **Time estimate**: Hours
4. **Acceptance criteria**: Specific, testable, exact behavior — NOT "works correctly" or "looks good"
5. **Key files**: Exact file paths
6. **Cross-refs**: Specific doc file + section number (e.g., "03-architecture.md §3.1")

Additional phase docs when features span multiple domains:
- Multi-protocol (gRPC, WS, MQTT): Separate phase-2b doc
- AI/Agent module: Separate phase-4+ doc
- Mobile-specific features: Separate phase doc
- **Never leave features without tasks** — if a feature appears in D02 but has no task, it's a gap

---

## D07: Error Handling (07-error-handling.md)

### Universal
- **Error type/code enum**: All error codes with numeric/string identifier + detail structure
- **Consumer-side mapping**: Per error code — what the UI/API response shows (toast type, icon, color, action button; or HTTP status + response body; or CLI exit code + stderr message)
- **Error format spec**: JSON shape `{ code, detail, ... }` or equivalent
- **Recovery strategy**: Per error category — retry parameters (max attempts, backoff curve, jitter, timeout), fallback behavior, degradation pattern, circuit breaker threshold, user-facing recovery action

### Desktop App additions
- Error enum → JSON serialized → frontend error handler mapping (language-specific pattern)
- CSS: Use implementation variable names from U01 mapping table (e.g., `var(--color-brand)`), not shorthand design tokens

### API Service additions
- HTTP status code mapping per error type
- Error response body schema
- Retry/deadletter/queue strategy for background failures
- External service error handling: Timeout, circuit breaker, fallback
- Webhook delivery failure + exponential backoff with max attempts
- Partial failure handling in multi-step transactions

### CLI Tool additions
- Exit code mapping: 0=success, 1=general error, 2=usage error
- Stderr/stdout routing: Errors to stderr, output to stdout
- Color/styling conventions for error messages
- Error message format template: What goes in stderr
- Error chaining display (cause chain)
- **Partial success handling**: Process N items, some fail — exit 0 or 1? Document the policy
- Warning vs error distinction
- Interactive error recovery: Prompt "continue or abort?"

---

## D08: State Persistence (08-state-persistence.md)

### Universal
- **Storage authority per data type**: ONE authority per data type (File System vs Database vs In-Memory), declared explicitly
- **Sync protocol**: Write path → persist → confirmation flow
- **Conflict resolution**: Strategy for concurrent modifications

### Desktop App additions
- File System vs SQLite per data type — explicit table
- SQLite/local DB access pattern: Use blocking wrapper (e.g., `spawn_blocking`) for blocking DB drivers, or async connection pooling for async drivers — document the chosen approach
- Vault secrets: Encrypted file storage, never plain

### API Service additions
- **Complete schema definition**: CREATE TABLE DDL for every table, column definitions (type, nullable, default, constraint), index definitions with rationale, foreign key relationships, ER diagram (ASCII), naming conventions, partitioning strategy if applicable
- **Migration strategy**: Tool choice + full config, version tracking table DDL, rollback procedure per migration type, zero-downtime approach, data migration pattern, migration testing checklist
- Caching layer (Redis/etc.) vs DB authority per data type
- Transaction patterns for multi-table operations
- Read replica setup if applicable
- Connection pool sizing formula

### Web SPA additions
- Local storage vs session storage vs cookie vs IndexedDB authority per data type
- Server-side state sync protocol
- Optimistic update rollback strategy
- URL query params as state source (which params drive which views)
- Session recovery after page refresh

### CLI Tool additions
- Config file schema definition: Every field with type, default, validation rule
- Config file location per OS ($XDG_CONFIG_HOME / %APPDATA% / ~/Library/Application Support)
- Config merge strategy: Global config + project-local config priority
- Cache/state file: Format, location, eviction policy

---

## D09: AGENTS.md (AI Entry Point)

### Universal (keep concise, aim for ≤400 lines — do not cut essential content for brevity)
1. **Key commands**: install, dev, build, lint, typecheck, test
2. **Project structure**: Directory tree (matching D01 §project-structure)
3. **Code conventions**: Project's language style guide, naming conventions, import style, annotation patterns
4. **Architecture principles**: Top 8-10 with brief rationale
5. **Design tokens** (UI projects): Quick reference table (token → implementation variable → utility)
6. **Dependency versions**: Authority version table
7. **Doc index**: All doc files with brief description + "when to read" column
8. **Common pitfalls**: 8-16 "don't use X, use Y instead" items with one direction per pitfall

---

## U01: Design System (ui-01-design-system.md)

### Universal (ALL UI projects)
- **Color palette**: Hex values for light and dark themes
- **Theme system**: Theme class structure (`.dark` / `[data-theme=dark]`), token override table per theme, preference persistence, system preference detection, transition approach
- **Typography**: Font families, weight scale, size scale
- **Spacing scale**: Base unit (4px/8px) + full scale
- **Border radius scale**: Full scale
- **Shadow scale**: Levels (sm/md/lg)
- **Animation tokens**: Table per animation type (enter/exit/emphasis/loading) → duration → easing → trigger → reduced-motion alternative
- **Responsive breakpoints**: Breakpoint names + pixel widths (mobile/tablet/desktop/wide), layout strategy per breakpoint
- **Layout architecture**: ASCII art with pixel dimensions per breakpoint tier
- **Component specs**: Per component — framework primitive, props interface, state matrix, accessibility attributes (aria-label per state, aria-live regions)
- **Notification system**: Toast types (success/error/warning/info), positioning, duration per type, stacking limit, dismissal pattern, z-index layer, enter/exit animation, aria-live region
- **Accessibility**: WCAG level target (AA minimum), focus ring spec (color, offset, width), semantic HTML requirements, color contrast ratios, touch target minimum sizes (44px), reduced-motion alternative, screen reader announcement patterns
- **CSS variable mapping table**: Design token → Implementation variable → CSS utility (THE AUTHORITY DOC)

---

## U02: Visual Specs (ui-02-{page}-visual-spec.md, one per page)

### Universal (ALL UI projects)
Per page/view:
1. **ASCII art layout diagram** with pixel dimensions for every element — **one diagram per breakpoint tier** (mobile + desktop minimum)
2. **CSS/code blocks** with exact values (not "approximately", not "similar to")
3. **State matrices**: idle/hover/active/error/disabled for every interactive element — **with accessibility column** (aria-label per state, aria-live regions)
4. **Implementation variable names**: Use the names from U01 mapping table (e.g., `--color-brand`), not design tokens (`--brand`)
5. **Toast overlay zone**: Marked in ASCII art (positioning, z-index layer)
6. **Empty state visual spec**: Exact CSS for what user sees when no data
7. **Loading skeleton spec**: Exact CSS for loading placeholders

---

## U03: Interaction Flow (ui-03-interaction-flow.md)

### Universal (ALL UI projects)
- **User flows**: Step-by-step for every major task
- **State transitions**: What state changes, when, triggers
- **Empty states**: What user sees when no data / first launch
- **Error flows**: What happens on failure, recovery paths, toast vs inline error per error type
- **Keyboard shortcuts**: Complete list with key bindings
- **Drag-and-drop flows** (if applicable): Reorder, move between lists
- **Undo/redo flow** (if applicable): Stack management, scope (local vs global)
- **Bulk action flows** (if applicable): Multi-select, action, confirmation, result summary
- **Touch interaction patterns** (if mobile/tablet): Long-press, swipe, pinch

---

## O01: Security & Performance (security-and-perf.md)

### Universal (ALL projects that include this doc)
- **Security design**:
  - OWASP top 10 checklist: Which risks apply to this project, how each is mitigated
  - Auth flow diagram: Login → token acquisition → refresh → expiry → logout (for all auth methods used)
  - CSRF / XSS / SQLi / SSRF prevention specifics (not just "we prevent it" — exact mechanism per risk)
  - Input sanitization strategy: Validation vs sanitization distinction, per endpoint/component
  - Audit logging: Who did what when — log format, retention policy
  - TLS config: Min version, cipher suite, certificate management
  - Secret management: Where secrets live (Vault / env vars / keyring / secrets manager), rotation policy
  - Dependency vulnerability scanning: Tool, frequency, CI step
  - CORS policy (if browser clients exist): Allowed origins, methods, headers
- **Performance targets**: Quantitative targets (startup time, latency, memory, throughput) + measurement approach (tool, baseline, when to measure), profiling strategy, performance regression test CI step, optimization strategy per concern
- **Test strategy**: Security test cases, penetration testing schedule, load testing approach
- **CI workflow**: Security scanning steps, performance benchmark steps
- **Deployment pipeline**: Build → test → stage → deploy → verify → rollback

### Desktop App additions
- Keyring / vault integration for secret storage
- Deep link security (URL scheme validation)
- Path traversal prevention for file operations

### API Service additions
- Rate limiting implementation details
- API key / JWT management specifics
- Request signing if applicable

---

## O02: Deep Analysis (deep-analysis.md)

### Universal
- **Decision record**: For each major correction — what was wrong, what changed, why, impact on downstream docs
- **Change log**: List of all corrections with affected doc IDs + section numbers
- **Verification status**: Which docs were re-verified after corrections

---

## O03: Additional Phase Docs (06-task-list-phase2b.md, phase4-ai.md, etc.)

### Universal
- Same 6-field task format as D06
- Created when features span multiple domains that don't fit neatly into sequential phases
- Examples: Multi-protocol support (gRPC, WS, MQTT, SSE), AI/Agent module, mobile-specific features, real-time collaboration
- **Never leave features without tasks** — if a feature in D02 has no task in D06 phase docs, create an O03 doc for it

---

## O04: Internationalization (i18n.md) — Optional, when project requires multi-language support

### Universal
- **i18n strategy**: Library choice, locale file structure, fallback locale, string key naming convention
- **Per-feature string inventory**: Which strings are user-facing, which need localization
- **RTL support**: If applicable, layout flip strategy, CSS approach
- **Date/number/currency formatting**: Per-locale patterns
- **Locale detection**: Browser/system preference detection, user override, persistence