"""OCSR skill package."""
