# useLoading 方法 Skill 说明（真实用法）

## 1. Basic
- Name: useLoading
- Kind: hook
- Status: active

## 2. Source Of Truth
- Export: admin-utils/src/index.ts
- Source: admin-utils/src/hooks/useLoading.ts

## 3. API（按源码提取）
- Import: import { useLoading } from "admin-utils";
- Signature: useLoading(initValue: boolean = false) => UseLoadingReturn
- Returns: UseLoadingReturn
- Behavior: 组合式方法，返回响应式状态与操作函数。

## 4. 真实用法示例

~~~ts
import { useLoading } from "admin-utils";

const state = useLoading();
console.log(state);
~~~

## 5. Guardrails
- 仅允许基于该方法 Source Of Truth 更新 API。
- 改动参数或返回后，必须同步更新本文件示例。
- 不允许复制其他方法的行为描述。
