# formatRange 方法 Skill 说明（真实用法）

## 1. Basic
- Name: formatRange
- Kind: function
- Status: active

## 2. Source Of Truth
- Export: admin-utils/src/index.ts
- Source: admin-utils/src/utils/index.ts

## 3. API（按源码提取）
- Import: import { formatRange } from "admin-utils";
- Signature: formatRange(min: number | string | null | undefined, max: number | string | null | undefined,) => string
- Returns: string
- Behavior: 以源码实现为准，使用前关注边界条件与异常处理。

## 4. 真实用法示例

~~~ts
import { formatRange } from "admin-utils";

const result = formatRange("demo-1", "demo-2");
console.log(result);
~~~

## 5. Guardrails
- 仅允许基于该方法 Source Of Truth 更新 API。
- 改动参数或返回后，必须同步更新本文件示例。
- 不允许复制其他方法的行为描述。
