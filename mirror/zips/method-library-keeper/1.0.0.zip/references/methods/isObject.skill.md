# isObject 方法 Skill 说明（真实用法）

## 1. Basic
- Name: isObject
- Kind: function
- Status: active

## 2. Source Of Truth
- Export: admin-utils/src/index.ts
- Source: admin-utils/src/utils/is.ts

## 3. API（按源码提取）
- Import: import { isObject } from "admin-utils";
- Signature: isObject(obj: unknown) => obj is Record<string, unknown>
- Returns: obj is Record<string, unknown>
- Behavior: 以源码实现为准，使用前关注边界条件与异常处理。

## 4. 真实用法示例

~~~ts
import { isObject } from "admin-utils";

const result = isObject(undefined);
console.log(result);
~~~

## 5. Guardrails
- 仅允许基于该方法 Source Of Truth 更新 API。
- 改动参数或返回后，必须同步更新本文件示例。
- 不允许复制其他方法的行为描述。
