# compareTime 方法 Skill 说明（真实用法）

## 1. Basic
- Name: compareTime
- Kind: function
- Status: active

## 2. Source Of Truth
- Export: admin-utils/src/index.ts
- Source: admin-utils/src/utils/date.ts

## 3. API（按源码提取）
- Import: import { compareTime } from "admin-utils";
- Signature: compareTime(time1: string | number | Date | null | undefined, time2: string | number | Date | null | undefined, options: CompareTimeOptions = {}) => number | null
- Returns: number | null
- Behavior: 以源码实现为准，使用前关注边界条件与异常处理。

## 4. 真实用法示例

~~~ts
import { compareTime } from "admin-utils";

const result = compareTime("demo-1", "demo-2", undefined);
console.log(result);
~~~

## 5. Guardrails
- 仅允许基于该方法 Source Of Truth 更新 API。
- 改动参数或返回后，必须同步更新本文件示例。
- 不允许复制其他方法的行为描述。
