# Method Spec Template

## 1. Basic
- Method Name:
- Module:
- Owner:
- Stability: `experimental | stable | deprecated`

## 2. Signature
- Inputs:
- Return:
- Throws:
- Side Effects:

## 3. Constraints
- Input boundary:
- Performance expectation:
- Idempotency requirement:

## 4. Examples
- Happy path:
- Edge path:
- Invalid input:

## 5. Test Cases
- Normal case:
- Boundary case:
- Error case:

## 6. Migration
- Old method:
- New method:
- Replacement plan:

