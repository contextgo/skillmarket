# admin-utils 私有方法库使用说明

本文档用于在项目内统一使用 `admin-utils` 方法库，适配 `method-library-keeper` 技能的方法沉淀、迁移和复用流程。

## 0. 单方法 Skill 文档

- 索引入口：`method-library-keeper/references/methods/README.md`
- 规则：`admin-utils` 对外导出项按“一方法（或一导出能力）一 skill.md”维护。
- 目的：限制误用，确保调用示例与源码签名同步。

## 1. 适用范围

- 技术栈：`Vue 3` + `TypeScript`
- 包名：`admin-utils`
- 内容类型：`utils` 函数 + `hooks` 组合式方法

## 2. 安装

```bash
pnpm add admin-utils
```

> `admin-utils` 依赖 `vue` 与 `@vueuse/core` 运行时能力，请确保业务项目中已安装。

## 3. 导入规范

### 3.1 utils 函数导入

```ts
import { formatMoney, compareTime, deepClone, regular } from "admin-utils";
```

### 3.2 hooks 导入

```ts
import { useLoading, usePaging, useStorage, useTableSelection } from "admin-utils";
```

## 4. 导出目录速查

### 4.1 通用工具（`utils/index.ts`）

- `delay`
- `downloadFileBlob`
- `downloadFileUrl`
- `stringToJson`
- `blobToJson`
- `deepClone`
- `filterTree`
- `sortTreeBySortNum`
- `expandTree`
- `formatIpList`
- `formatRange`
- `capitalizeFirst`
- `stringToArray`
- `arrayToString`
- `formatNumberToXYZ`

### 4.2 数值工具（`utils/number.ts`）

- `yuanToWan`
- `preciseCalculateSubtract`
- `preciseCalculateAdd`
- `preciseCalculateMultiply`
- `preciseCalculateDivide`
- `toPercentage`
- `formatMoney`
- `calculateDailyRatio`
- `calculateDailyNumber`

### 4.3 日期工具（`utils/date.ts`）

- `compareTime`
- `getAgeByBirthday`
- `timeToSeconds`
- `secondsToTime`
- `formatDate`

### 4.4 类型判断（`utils/is.ts`）

- `isArray`
- `isObject`
- `isString`
- `isNumber`
- `isRegExp`
- `isFile`
- `isBlob`
- `isUndefined`
- `isNull`
- `isFunction`
- `isEmptyObject`
- `isExist`
- `isWindow`
- `isEmpty`
- `isBoolean`
- `isFileChanged`

### 4.5 正则集合与存储工具

- `regular`（常用校验规则集合，如手机号、账号、密码、IP、验证码）
- `local` / `session` / `VStorage`（基于 `localStorage`、`sessionStorage` 的封装）

### 4.6 hooks（`src/hooks/*.ts`）

- `useClipboardCopy`
- `useFormReset`
- `useLoading`
- `useTableSelection`
- `usePaging`
- `useStorage`
- `useFormErrorScroll`

## 5. 常用示例

### 5.1 列表分页 + loading

```ts
import { useLoading, usePaging } from "admin-utils";

const { loading, setLoading } = useLoading();
const { paginationModel, pagingParams } = usePaging({ pageSize: 20 });

async function loadList() {
  setLoading(true);
  try {
    // API 参数示例：{ pageNum: pagingParams.value.pageNum, pageSize: pagingParams.value.pageSize }
  } finally {
    setLoading(false);
  }
}
```

### 5.2 本地缓存读写

```ts
import { useStorage } from "admin-utils";

const cache = useStorage("local");
cache.setItemJSON("user-info", { id: 1, name: "admin" });

const user = cache.getItemJSON<{ id: number; name: string }>("user-info");
```

### 5.3 校验与格式化

```ts
import { regular, formatMoney, compareTime } from "admin-utils";

const isValidIP = regular.ip.test("192.168.1.1");
const amountText = formatMoney(1234567.89, 2);
const compareResult = compareTime("2026-01-01", "2025-12-31"); // 1
```

## 6. 方法库沉淀约定（给技能执行）

- 新增函数优先按领域归档：`date`、`number`、`is`、`storage`、`index`。
- 对外暴露前必须补齐输入边界和异常策略（是否抛错、默认值策略）。
- 组合式 hooks 必须给出返回值类型，避免业务侧 `any` 扩散。
- 迁移旧逻辑时，先补“替换示例”再做大面积替换，确保可回滚。

## 7. 常见问题

- 浏览器环境报错：`localStorage`、`document` 相关方法需要在浏览器环境调用。
- 除零异常：`preciseCalculateDivide` 在除数为 `0` 时会抛错，需要业务侧兜底。
- 解析失败返回空：`getItemJSON`、`blobToJson` 等方法在异常场景会返回 `null`，调用方需判空。
