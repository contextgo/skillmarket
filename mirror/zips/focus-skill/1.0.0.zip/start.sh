#!/bin/bash
set -e

echo "==================================="
echo " 聚焦技能 启动中 "
echo "==================================="

pip3 install -r requirements.txt -q
python3 focus_skill.py

echo "✅ 已停止"