# -*- coding: utf-8 -*-
"""
QClaw Skill: 聚焦 · 全能关注助手
功能：价格/天气/股市/基金/汇率/网课/游戏/公告 智能监控 + 自定义阈值 + 自定义轮询频率
支持：卡片展示 + 语音播报 + 主动推送
"""
import time
import json
import datetime
from typing import Dict, List, Optional

# -------------------------- 配置常量 --------------------------
FOCUS_TYPES = [
    "price", "weather", "stock", "fund", "exchange",
    "course", "game", "notice", "logistics"
]

# 默认阈值
DEFAULT_THRESHOLD = {
    "price": 5,
    "stock": 2,
    "fund": 1,
    "exchange": 100,
    "weather": 5
}

# 默认轮询频率（分钟）
DEFAULT_INTERVAL = {
    "weather": 180,    # 天气 3小时一次
    "stock": 5,        # 股市 5分钟
    "fund": 60,        # 基金 1小时
    "exchange": 30,    # 汇率 30分钟
    "price": 10,       # 商品价格 10分钟
    "course": 360,
    "game": 120,
    "notice": 60,
    "logistics": 20
}

# -------------------------- 核心技能类 --------------------------
class FocusSkill:
    def __init__(self):
        self.name = "聚焦"
        self.desc = "自动盯紧你在意的所有信息，智能提醒不打扰"
        self.version = "1.0.0"
        self.user_focus = {}  # { user_id: [task...] }

    def handle_intent(self, user_id: str, text: str) -> Dict:
        text = text.strip()
        if any(key in text for key in ["关注", "盯", "留意", "监控"]):
            return self.add_focus(user_id, text)
        elif any(key in text for key in ["查看", "我的关注", "列表"]):
            return self.query_focus(user_id)
        elif any(key in text for key in ["修改", "阈值", "调整"]):
            return self.update_threshold(user_id, text)
        elif any(key in text for key in ["轮询", "频率", "间隔", "多久"]):
            return self.set_interval(user_id, text)
        elif any(key in text for key in ["取消", "停止", "删除"]):
            return self.delete_focus(user_id, text)
        else:
            return self.default_reply()

    # ==================== 添加关注（含自动轮询频率） ====================
    def add_focus(self, user_id: str, text: str) -> Dict:
        focus_type = self._recognize_type(text)
        target = self._extract_target(text)
        threshold = self._extract_threshold(text, focus_type)
        interval = self._extract_interval(text, focus_type)
        voice_remind = "语音" in text or "播报" in text

        if user_id not in self.user_focus:
            self.user_focus[user_id] = []

        task = {
            "id": int(time.time()),
            "type": focus_type,
            "target": target,
            "threshold": threshold,
            "interval_min": interval,
            "last_check": 0,
            "last_value": None,
            "create_time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
            "voice_remind": voice_remind
        }

        self.user_focus[user_id].append(task)

        return self.build_reply(
            title="✅ 已添加关注",
            content=f"对象：{self._get_type_name(focus_type)}「{target}」\n阈值：{threshold}\n检查频率：每{interval}分钟",
            voice=f"已为你关注{target}，满足条件会及时提醒"
        )

    # ==================== 设置自定义轮询频率 ====================
    def set_interval(self, user_id: str, text: str) -> Dict:
        tasks = self.user_focus.get(user_id, [])
        if not tasks:
            return self.build_reply("⚠️ 无关注", "请先添加关注", "暂无任务")
        target = self._extract_target(text)
        new_interval = self._extract_number(text)
        if not new_interval:
            return self.build_reply("❌ 格式错误", "请说：把XX轮询改为30分钟", "请告诉我分钟数")

        for task in tasks:
            if target in task["target"]:
                task["interval_min"] = int(new_interval)
                return self.build_reply(
                    "✅ 轮询频率已修改",
                    f"「{task['target']」将每{new_interval}分钟检查一次",
                    f"已更新{target}检查频率"
                )
        return self.build_reply("❌ 未找到", f"未找到关注对象：{target}", "未找到")

    # ==================== 查看列表 ====================
    def query_focus(self, user_id: str) -> Dict:
        tasks = self.user_focus.get(user_id, [])
        if not tasks:
            return self.build_reply("🔍 关注列表", "暂无关注", "你还没有关注")
        content = ""
        for i, t in enumerate(tasks, 1):
            tn = self._get_type_name(t["type"])
            content += f"{i}. {tn}：{t['target']}\n  阈值：{t['threshold']} ｜ 每{t['interval_min']}分钟\n"
        return self.build_reply("📋 我的关注", content, f"共关注{len(tasks)}项")

    # ==================== 其他方法略写 ====================
    def update_threshold(self, user_id: str, text: str) -> Dict:
        tasks = self.user_focus.get(user_id, [])
        if not tasks: return self.build_reply("⚠️ 无任务", "先添加关注", "")
        target = self._extract_target(text)
        new_val = self._extract_number(text)
        for t in tasks:
            if target in t["target"]:
                t["threshold"] = new_val
                return self.build_reply("✅ 已修改阈值", f"{t['target']} 阈值={new_val}", "修改成功")
        return self.build_reply("❌ 未找到", "", "")

    def delete_focus(self, user_id: str, text: str) -> Dict:
        tasks = self.user_focus.get(user_id, [])
        target = self._extract_target(text)
        new_tasks = [t for t in tasks if target not in t["target"]]
        if len(new_tasks) == len(tasks):
            return self.build_reply("❌ 未找到", "", "")
        self.user_focus[user_id] = new_tasks
        return self.build_reply("✅ 已取消", f"已停止监控 {target}", "取消成功")

    # ==================== 智能监控循环（按任务自身频率检查） ====================
    def monitor_loop(self):
        while True:
            now = time.time()
            for user_id, tasks in self.user_focus.items():
                for task in tasks:
                    interval_sec = task["interval_min"] * 60
                    if now - task["last_check"] >= interval_sec:
                        task["last_check"] = now
                        change = self._check_change(task)
                        if change:
                            self._send_notify(user_id, task, change)
            time.sleep(60)

    # ==================== 工具函数 ====================
    def _recognize_type(self, text: str) -> str:
        if any(k in text for k in ["天气","雨","温度","降温"]): return "weather"
        if any(k in text for k in ["股票","指数","股价"]): return "stock"
        if any(k in text for k in ["基金","净值"]): return "fund"
        if any(k in text for k in ["汇率","美元","欧元"]): return "exchange"
        if any(k in text for k in ["网课","课程","作业"]): return "course"
        if any(k in text for k in ["游戏","更新","维护","皮肤"]): return "game"
        if any(k in text for k in ["公告","通知","新闻"]): return "notice"
        if any(k in text for k in ["快递","物流"]): return "logistics"
        return "price"

    def _extract_target(self, text: str) -> str:
        for k in ["关注","盯","帮我","留意","监控","的","改为","调成","轮询","频率","间隔"]:
            text = text.replace(k, "")
        return text.strip()[:20]

    def _extract_threshold(self, text: str, f_type: str) -> float:
        n = self._extract_number(text)
        return n if n else DEFAULT_THRESHOLD.get(f_type, 5)

    def _extract_interval(self, text: str, f_type: str) -> int:
        n = self._extract_number(text)
        return int(n) if n else DEFAULT_INTERVAL.get(f_type, 10)

    def _extract_number(self, text: str) -> Optional[float]:
        for w in text.replace("%","").replace("分钟","").split():
            if w.replace(".","").isdigit():
                return float(w)
        return None

    def _get_type_name(self, t: str) -> str:
        m = {"price":"价格","weather":"天气","stock":"股票","fund":"基金","exchange":"汇率",
             "course":"网课","game":"游戏","notice":"公告","logistics":"物流"}
        return m.get(t, "监控")

    def _check_change(self, task: Dict) -> Optional[str]:
        if task["last_value"] is None:
            task["last_value"] = 100
            return None
        if time.time() % 120 < 2:
            return f"触发阈值（当前模拟值：{task['last_value']}）"
        return None

    def _send_notify(self, user_id: str, task: Dict, change: str):
        card = {"title": f"🔔 聚焦提醒 · {self._get_type_name(task['type'])}",
                "content": f"对象：{task['target']}\n变化：{change}"}
        voice = f"你关注的{task['target']}有更新"
        print(f"[推送] 用户{user_id} | {card} | 语音：{voice}")

    def build_reply(self, title: str, content: str, voice: str) -> Dict:
        return {"code":0,"msg":"ok","data":{"card":{"title":title,"content":content},"voice":voice,"need_voice":True}}

    def default_reply(self):
        return self.build_reply("🤖 聚焦助手",
            "支持价格/天气/股票/基金/汇率/网课/游戏/公告\n可自定义阈值、轮询频率",
            "我可以帮你盯紧所有在意的事情")

# ==================== 入口 ====================
if __name__ == "__main__":
    skill = FocusSkill()
    print(f"✅ QClaw聚焦技能 v{skill.version} 已启动")
    import threading
    threading.Thread(target=skill.monitor_loop, daemon=True).start()
    while True:
        msg = input("用户：")
        res = skill.handle_intent("test_user", msg)
        print("QClaw：", res["data"]["card"]["content"], "\n")