#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
大五人格测评计分模块
"""

import json
from typing import Dict, List, Tuple

class BigFiveScoring:
    """大五人格计分器"""
    
    def __init__(self, questions_path: str, interpretations_path: str):
        """初始化计分器"""
        with open(questions_path, 'r', encoding='utf-8') as f:
            self.questions_data = json.load(f)
        with open(interpretations_path, 'r', encoding='utf-8') as f:
            self.interpretations_data = json.load(f)
    
    def calculate_dimension_score(self, answers: Dict[int, int], dimension_key: str) -> int:
        """
        计算某个维度的得分
        
        Args:
            answers: 答题结果，{题号: 原始得分}
            dimension_key: 维度键名
            
        Returns:
            该维度的总分（12-60分）
        """
        dimension = self.questions_data['dimensions'][dimension_key]
        question_ids = dimension['questions']
        reverse_questions = set(dimension.get('reverse_questions', []))
        
        total_score = 0
        for qid in question_ids:
            if qid not in answers:
                raise ValueError(f"缺少第{qid}题的答案")
            
            raw_score = answers[qid]
            if qid in reverse_questions:
                # 反向计分：6 - 原始分
                score = 6 - raw_score
            else:
                score = raw_score
            
            total_score += score
        
        return total_score
    
    def calculate_all_scores(self, answers: Dict[int, int]) -> Dict[str, int]:
        """
        计算所有维度的得分
        
        Args:
            answers: 答题结果，{题号: 原始得分}
            
        Returns:
            各维度得分字典
        """
        scores = {}
        for dimension_key in self.questions_data['dimensions'].keys():
            scores[dimension_key] = self.calculate_dimension_score(answers, dimension_key)
        return scores
    
    def get_dimension_interpretation(self, dimension_key: str, score: int) -> Dict:
        """
        获取某个维度分数的解析
        
        Args:
            dimension_key: 维度键名
            score: 该维度的得分
            
        Returns:
            解析结果字典
        """
        dimension_interp = self.interpretations_data['dimensions'][dimension_key]
        
        for range_info in dimension_interp['ranges']:
            if range_info['min'] <= score <= range_info['max']:
                return {
                    'dimension_name': dimension_interp['name'],
                    'dimension_alias': dimension_interp.get('alias', ''),
                    'dimension_description': dimension_interp['description'],
                    'score': score,
                    'level': range_info['level'],
                    'label': range_info['label'],
                    'traits': range_info['traits'],
                    'description': range_info['description'],
                    'advice': range_info['advice'],
                    'career': range_info['career']
                }
        
        raise ValueError(f"分数{score}不在有效范围内")
    
    def get_all_interpretations(self, scores: Dict[str, int]) -> Dict[str, Dict]:
        """
        获取所有维度的解析
        
        Args:
            scores: 各维度得分字典
            
        Returns:
            各维度解析结果字典
        """
        interpretations = {}
        for dimension_key, score in scores.items():
            interpretations[dimension_key] = self.get_dimension_interpretation(dimension_key, score)
        return interpretations
    
    def get_overall_profile(self, scores: Dict[str, int]) -> Dict:
        """
        获取整体人格画像
        
        Args:
            scores: 各维度得分字典
            
        Returns:
            整体画像描述
        """
        profiles = []
        
        # 高开放 + 高尽责 = 创新型实干家
        if scores['openness'] >= 45 and scores['conscientiousness'] >= 45:
            profiles.append(self.interpretations_data['overall_profiles']['high_openness_high_conscientiousness'])
        
        # 高外向 + 高亲和 = 社交达人
        if scores['extraversion'] >= 45 and scores['agreeableness'] >= 45:
            profiles.append(self.interpretations_data['overall_profiles']['high_extraversion_high_agreeableness'])
        
        # 低神经质 + 高尽责 = 稳定可靠者
        if scores['neuroticism'] <= 30 and scores['conscientiousness'] >= 45:
            profiles.append(self.interpretations_data['overall_profiles']['low_neuroticism_high_conscientiousness'])
        
        # 高神经质 + 高开放 = 敏感艺术家
        if scores['neuroticism'] >= 45 and scores['openness'] >= 45:
            profiles.append(self.interpretations_data['overall_profiles']['high_neuroticism_high_openness'])
        
        # 低外向 + 高开放 = 独立思考者
        if scores['extraversion'] <= 30 and scores['openness'] >= 45:
            profiles.append(self.interpretations_data['overall_profiles']['low_extraversion_high_openness'])
        
        return {
            'profiles': profiles,
            'score_summary': {
                'neuroticism': {'score': scores['neuroticism'], 'level': self._get_level(scores['neuroticism'])},
                'conscientiousness': {'score': scores['conscientiousness'], 'level': self._get_level(scores['conscientiousness'])},
                'openness': {'score': scores['openness'], 'level': self._get_level(scores['openness'])},
                'extraversion': {'score': scores['extraversion'], 'level': self._get_level(scores['extraversion'])},
                'agreeableness': {'score': scores['agreeableness'], 'level': self._get_level(scores['agreeableness'])}
            }
        }
    
    def _get_level(self, score: int) -> str:
        """根据分数获取等级"""
        if score <= 24:
            return "低"
        elif score <= 36:
            return "中"
        elif score <= 48:
            return "中高"
        else:
            return "高"
    
    def generate_report(self, answers: Dict[int, int]) -> Dict:
        """
        生成完整的测评报告
        
        Args:
            answers: 答题结果，{题号: 原始得分}
            
        Returns:
            完整报告字典
        """
        # 计算各维度得分
        scores = self.calculate_all_scores(answers)
        
        # 获取各维度解析
        interpretations = self.get_all_interpretations(scores)
        
        # 获取整体画像
        overall = self.get_overall_profile(scores)
        
        return {
            'scores': scores,
            'interpretations': interpretations,
            'overall_profile': overall
        }


def format_report(report: Dict) -> str:
    """格式化报告为可读文本"""
    lines = []
    
    lines.append("=" * 60)
    lines.append("大五人格测评报告")
    lines.append("=" * 60)
    lines.append("")
    
    # 分数总览
    lines.append("【分数总览】")
    lines.append("-" * 40)
    for dim_key, interp in report['interpretations'].items():
        lines.append(f"{interp['dimension_name']}: {interp['score']}分 ({interp['level']})")
    lines.append("")
    
    # 各维度详细解析
    lines.append("【维度详细解析】")
    lines.append("=" * 60)
    
    for dim_key, interp in report['interpretations'].items():
        lines.append("")
        lines.append(f"▶ {interp['dimension_name']} ({interp['score']}分 - {interp['label']})")
        lines.append("-" * 40)
        lines.append(f"特征: {', '.join(interp['traits'])}")
        lines.append("")
        lines.append(f"解析: {interp['description']}")
        lines.append("")
        lines.append(f"建议: {interp['advice']}")
        lines.append("")
        lines.append(f"职业适配: {interp['career']}")
    
    # 整体画像
    if report['overall_profile']['profiles']:
        lines.append("")
        lines.append("【整体人格画像】")
        lines.append("=" * 60)
        for profile in report['overall_profile']['profiles']:
            lines.append(f"\n★ {profile['name']}")
            lines.append(f"  {profile['description']}")
    
    lines.append("")
    lines.append("=" * 60)
    lines.append("测评完成时间: 请查看系统记录")
    lines.append("=" * 60)
    
    return "\n".join(lines)


# 测试代码
if __name__ == "__main__":
    import os
    
    # 获取当前脚本所在目录
    script_dir = os.path.dirname(os.path.abspath(__file__))
    base_dir = os.path.dirname(script_dir)
    
    questions_path = os.path.join(base_dir, "assets", "questions.json")
    interpretations_path = os.path.join(base_dir, "assets", "interpretations.json")
    
    # 创建计分器
    scorer = BigFiveScoring(questions_path, interpretations_path)
    
    # 测试数据（所有题目选择3分）
    test_answers = {i: 3 for i in range(1, 61)}
    
    # 生成报告
    report = scorer.generate_report(test_answers)
    
    # 打印报告
    print(format_report(report))
