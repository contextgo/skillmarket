const ENV_KEY = "FN_API_KEY";

// Publish channel for this distribution. Change this value when packaging for another platform.
export const CHANNEL = "skillhub";

export const BASE_URL = "https://m.riskbird.com/prod-qbb-api";

export async function getApiKey() {
  const key = process.env[ENV_KEY]?.trim();
  if (key && key !== "YOUR_API_KEY") return key;
  return null;
}
