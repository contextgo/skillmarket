---
name: china-company-search-fengniao
description: >-
  Use when a user needs Fengniao (Riskbird) public Chinese company registration information by
  enterprise name, including basic registry details, shareholders, executives,
  outbound investments, or registration changes.
keywords:
  - 风鸟
  - Fengniao
  - Riskbird
  - 企业查询
  - 公司查询
  - 查公司
  - 工商查询
  - 工商信息
  - 企业工商信息
  - 企业登记信息
  - 工商注册信息
  - 查法人
  - 法定代表人
  - 股东信息
  - 股权结构
  - 主要人员
  - 董监高
  - 企业高管
  - 对外投资
  - 企业对外投资
  - 工商变更
  - 统一社会信用代码
  - 注册号
  - 官网
  - 电话
  - 邮箱
env:
  - FN_API_KEY  # required，必须由用户自行配置
security:
  child_process: false
  eval: false
  filesystem_write: false
  filesystem_read: true
auto_invoke: false
examples:
  - "帮我查一下腾讯的工商基本信息"
  - "查询比亚迪的股东结构"
  - "看一下宁德时代的主要人员"
  - "上海信数有哪些对外投资"
  - "查一下这家公司的工商变更记录"
  - "信数科技的法定代表人是谁"
  - "Do a company registry lookup for Tencent"
  - "Show me the shareholders of BYD"
---

# 企业查询 | 工商查询 | 风鸟 Fengniao（公开工商版）

**数据来源**：本 Skill 数据来源于风鸟（Riskbird）公开工商数据库，仅提供公开工商登记信息检索服务。

风鸟公开工商版仅用于根据企业名称查询公开工商登记信息。支持通过 `discover` 找到合适的查询维度，再通过 `call` 获取结构化结果。

**设置**：必须先配置环境变量 `FN_API_KEY`。公开市场包不内置凭证，也不自动代填。发布包会固定传入 `channel`，用户无需手动填写。

## 当前版本支持范围

- 企业模糊搜索：企业简称或全称匹配，返回内部查询所需的 `entid`
- 企业基本信息：法定代表人、注册资本、成立日期、统一社会信用代码、注册地址、经营范围、经营状态等
- 企业股东信息
- 企业主要人员：董事、监事、高管、法定代表人
- 企业对外投资
- 企业工商变更

字段细节以 `tools.json` 和 `references/field_definitions_common_bizinfo.md` 为准。

## 使用边界

- 仅支持基于企业名称的公开工商信息查询
- 仅提供事实检索与信息汇总，不输出结论性判断或建议
- 不支持自然人维度查询或个人相关反查
- 查询结果仅供参考，不构成任何投资、授信、合作或招聘决策依据
- 数据更新可能存在延迟，以国家企业信用信息公示系统为准

## 使用流程

1. 先识别用户要查的工商维度，不要直接假设需要全量查询。
2. 先用 `discover` 找到对应维度工具，例如“企业股东信息”“企业主要人员”“企业工商变更”。
3. 再调用 `fengniao_biz_fuzzy_search` 获取 `entid`。
4. 如果企业名称是简称或存在多义，先请用户确认目标企业后再继续。
5. 所有维度查询统一使用 `entid`，不直接传企业名称或统一社会信用代码。

## 结果要求

- 仅展示真实返回的数据，不编造未查询到的信息
- 若某维度无记录，可直接说明“未查询到相关记录”
- 若用户请求的是当前未支持的维度，例如专利、招投标、舆情等，明确说明当前版本暂不支持
- 不向用户展示 `entid`
- 结果中优先使用企业工商登记全称

## 错误恢复

- `FN_API_KEY` 未配置：提示用户先配置环境变量后再调用
- `code=8888`：通常是 `entid` 或参数错误，重新搜索企业主体后再试
- `code=20000` 且无记录：直接说明该企业在该维度下无记录
- `discover` 无匹配：说明当前版本暂不支持该维度

## 快速开始

```bash
# 1. 先按维度发现工具
node scripts/tool.mjs discover "企业股东信息"

# 2. 再模糊搜索企业，获取 entid
node scripts/tool.mjs call fengniao_biz_fuzzy_search --params '{"key":"腾讯"}'

# 3. 用 entid 查询具体维度
node scripts/tool.mjs call fengniao_biz_shareholders --params '{"entid":"AerjZTfkSh0"}'
```
