# 风鸟企业查询 Skill 本地验证说明（公开工商版）

## 适用范围

本文仅用于本地验证当前公开工商版 skill，不要求修改用户主目录、shell 启动文件或 agent 全局配置。

## 前置条件

- Node.js 18 或以上版本
- 已准备有效的 `FN_API_KEY`

验证 Node.js 版本：

```bash
node -v
```

## 配置 API Key

公开工商版不内置凭证。调用任何联网接口前，请先为当前终端会话设置 `FN_API_KEY`。

**macOS / Linux**

```bash
export FN_API_KEY="你的API Key"
```

**Windows PowerShell**

```powershell
$env:FN_API_KEY = "你的API Key"
```

**Windows CMD**

```cmd
set FN_API_KEY=你的API Key
```

## 校验环境变量

建议在调用查询前先确认当前会话已经能读到 `FN_API_KEY`。

**macOS / Linux**

```bash
printenv FN_API_KEY
```

**Windows PowerShell**

```powershell
$env:FN_API_KEY
```

也可以使用更显式的写法：

```powershell
Get-Item Env:FN_API_KEY -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Value
```

如果你是在另一个 PowerShell 进程里执行校验命令，优先使用单引号包裹命令，避免外层 shell 提前展开变量：

```powershell
powershell -Command '$env:FN_API_KEY'
```

## 本地验证命令

```bash
# 1. 测试工具发现（无需联网）
node scripts/tool.mjs discover "企业基本信息"

# 2. 测试模糊搜索（需要有效 API Key）
node scripts/tool.mjs call fengniao_biz_fuzzy_search --params '{"key":"腾讯"}'

# 3. 测试维度查询（用上一步返回的 entid）
node scripts/tool.mjs call fengniao_biz_basic_info --params '{"entid":"AerjZTfkSh0"}'
```

## 当前发布包的安全边界

- 只从环境变量 `FN_API_KEY` 读取凭证
- 只暴露企业模糊搜索、基本信息、股东、主要人员、对外投资、工商变更六类能力
- 只读取 skill 包内的 `tools.json` 和 `references/` 文件
- 不读取用户主目录中的 agent 配置或 shell 启动配置
- 不写入本地文件
- 实际调用通过 URL 参数传递 `apikey` 和 `channel`，不通过 HTTP 请求头传递

## 上架合规说明

- 数据来源为风鸟（Riskbird）公开工商数据库，仅提供公开工商登记信息检索服务
- 查询结果仅供参考，不构成任何投资、授信、合作或招聘决策依据
- 数据更新可能存在延迟，以国家企业信用信息公示系统为准
- SkillHub 如要求提供数据服务授权书或合作协议，请在上架材料中单独附加风鸟授权文件；本 skill 包不内置密钥或授权正文

## 生产环境说明

公开发布包固定使用生产地址 `https://m.riskbird.com/prod-qbb-api`。

如果你有自己的环境或私有部署，请在私有副本中审阅并修改源码后再使用，不建议在公开市场包中暴露可切换端点。
