# ima 笔记同步 Prompt 模板

## 触发场景

错题分析完成后，自动调用 ima-skills 将错题及分析结果同步到 ima 笔记。

> ⚠️ **ima-skills API 能力说明**：
> - ✅ 支持：`list_notebooks`（查询知识库列表）、`list_folders`（查询文件夹列表）、`create_note`（创建笔记）、`upload_file`（上传文件/附件）
> - ❌ 不支持：`create_notebook`（创建知识库）、`create_folder`（创建文件夹）
> - 当知识库或文件夹不存在时，需要**提示用户手动在 ima 中创建**，不能自动创建

## 前置条件检查

在执行同步前，必须按以下顺序检查：

### 第零步：检查 ima 账号是否已授权

```
调用平台接口：check_ima_auth_status()
```

- **已授权且 token 有效** → 直接进入第一步
- **token 过期** → 自动刷新 token（调用 `refresh_ima_token()`），刷新成功则继续，失败则走未授权流程
- **未授权** → 向用户展示授权引导：

```
🔗 关联 ima 笔记账号

要将错题自动同步到 ima 笔记，需要先关联你的 ima 账号。

关联后可以：
  · 📱 在 ima 笔记中随时查看和复习错题
  · 🔍 按知识点、错误类型搜索历史错题
  · 💻 手机、平板、电脑多端同步
  · 📓 自动整理成"数学错题本"笔记本

关联过程只需 3 步：
  ① 点击下方「关联 ima 账号」按钮
  ② 在 ima 页面登录你的账号（或注册新账号）
  ③ 点击"允许授权"即可

⚠️ 我们只申请笔记读写权限，不会访问你的其他数据。

👉 [关联 ima 账号]
```

- 用户点击授权 → 跳转 ima OAuth 授权页面（微信小程序通过 webview 或小程序跳转）
- 用户完成授权 → 回调获取 access_token → 平台安全存储 → 继续第一步
- 用户拒绝授权 → 向用户展示：

```
没关系！错题已保存在本地错题库中 📚
随时可以在设置中关联 ima 账号，开启自动同步。
```

- 标记 `ima_auth_status = "user_declined"`，本次不同步
- 后续每隔 3 次录题再温和提醒一次（不强制）

### 第一步：检查 ima-skills 是否已安装

```
调用平台接口：check_skill_installed("ima-skills")
```

- **已安装** → 直接进入第二步
- **未安装** → 向用户展示安装引导：

```
📓 检测到你还未安装「ima」skill

安装后，每次录入错题都会自动同步到 ima 笔记，方便你：
  · 📱 在手机、平板、电脑上随时复习
  · 🔍 按知识点搜索历史错题
  · 📊 自动整理成错题笔记本

👉 是否立即安装？
```

- 用户同意 → 调用 `install_skill("ima-skills")` → 安装完成后继续
- 用户拒绝 → 标记 `ima_sync_status = "user_skipped"`，本次不同步，后续每隔 5 次录题再提醒一次

### 第二步：检查「数学宝典」知识库是否存在

调用 ima-skills 的 `list_notebooks` 接口，查询用户所有知识库，检查是否存在名称为 **「数学宝典」** 的知识库：

- ✅ **已存在** → 直接进入第三步
- ❌ **不存在** → **提示用户手动创建**（⚠️ ima-skills 不支持自动创建知识库）：
  ```
  📚 首次同步需要你在 ima 中手动创建知识库

  请按以下步骤操作（只需一次）：
    ① 打开 ima 笔记 App
    ② 点击「新建知识库」
    ③ 名称输入：数学宝典
    ④ 创建完成后回到这里，我会自动继续同步

  ⏳ 等你创建好后，发送"继续同步"或点击下方按钮：
  👉 [我已创建好了]
  ```
  - 用户点击"我已创建好了" → 重新调用 `list_notebooks` 验证 → 存在则继续第三步，仍不存在则提示：
    ```
    🔍 还没找到「数学宝典」知识库，请确认：
    - 知识库名称是否为「数学宝典」（注意不要有多余空格）
    - 是否已保存创建

    错题已保存在本地错题库中 📚 你可以随时创建知识库后重新同步。
    ```
  - 标记 `ima_sync_status = "waiting_notebook_creation"`，本次终止同步

### 第三步：检查目标目录是否存在，不存在则提示用户手动创建

根据当前同步的内容类型，从 `config/skill_settings.yaml` 的 `knowledge_base.structure` 中读取目标目录模板，替换为实际参数，得到完整目标路径：

| 同步内容类型 | 路径模板 | 示例完整路径 |
|--------------|----------|--------------|
| 错题笔记 | `错题本/{knowledge_area}/{knowledge_point}` | `数学宝典/错题本/图形与几何/圆` |
| 组卷PDF | `组卷练习/{year}年{month}月` | `数学宝典/组卷练习/2026年5月` |
| 学习报告 | `学习报告/{report_type}` | `数学宝典/学习报告/月度学习报告` |
| 知识点总结 | `知识点总结` | `数学宝典/知识点总结` |

按层级逐级检查目录是否存在（调用 ima-skills 的 `list_folders` 接口，传入父目录ID/路径）：
1. 拆分目标路径为层级数组（如 `数学宝典/错题本/图形与几何/圆` 拆分为 `["数学宝典", "错题本", "图形与几何", "圆"]`）
2. 从顶级知识库「数学宝典」开始，逐级检查子目录是否存在：
   - 当前层级目录 **已存在** → 继续检查下一层级
   - 当前层级目录 **不存在** → **提示用户手动创建**（⚠️ ima-skills 不支持自动创建文件夹）：
     ```
     📂 同步目标路径中缺少以下文件夹，请在 ima 中手动创建：

     需要创建的文件夹路径：
       📁 数学宝典 / {缺失的文件夹层级路径}

     操作步骤：
       ① 打开 ima 笔记 → 进入「数学宝典」知识库
       ② 逐级创建以下文件夹：{列出所有缺失的层级}
       ③ 创建完成后发送"继续同步"

     💡 小提示：创建好顶层文件夹后，后续同类知识点的同步就不需要再创建了。

     👉 [我已创建好了]  [跳过同步，保存本地]
     ```
   - 用户点击"我已创建好了" → 重新逐级检查 → 全部存在则继续第四步
   - 用户点击"跳过同步，保存本地" → 标记 `ima_sync_status = "waiting_folder_creation"`，终止本次同步，错题保留在本地错题库
3. 所有层级目录都存在后，进入第四步。

### 第四步：调用 ima-skills 创建/更新笔记

## 输入

- `{error_card}`: 完整的错题卡片数据（符合 `schemas/error_card.json` 格式，其中 `question.image_url` 已经是优化压缩后的版本）
- `{analysis_result}`: 错题分析结果（来自 `prompts/error_analysis.md` 的输出，所有面向学生的文字使用 Unicode 格式）
- `{optimized_image_url}`: 优化压缩后的拍照图片 URL（由图片优化流程处理后生成，确保 ≤500KB 且清晰可读）
- `{figure_svg}`: 几何图形 SVG 代码（如有）

## 图片优化处理（同步前自动执行）

在同步到 ima 之前，**必须先对用户拍照的原始图片进行优化压缩**，确保在 ima 笔记中加载快速、可直接查看：

### 优化流程

```
用户拍照/选图
  ↓
获取原始图片（可能 3-10MB）
  ↓
【图片优化处理】（读取 config/skill_settings.yaml 中 image_optimization 配置）
  ① 等比缩小：宽度超过 1200px 或高度超过 1600px 时，按比例缩小到限制内
  ② 质量压缩：JPEG quality=85（在清晰度和文件大小之间取最佳平衡）
  ③ 文件大小检查：如果压缩后仍超过 500KB，逐步降低 quality（每次 -5）直到满足
  ④ 移除 EXIF：去除拍照设备、GPS 等隐私信息，同时减小体积
  ↓
优化后的图片（通常 200-500KB，清晰可读）
  ↓
上传到平台存储，获得 optimized_image_url
  ↓
更新错题卡片：
  - question.image_url = optimized_image_url
  - question.image_optimized = true
  - question.image_optimization = { original_size_kb, optimized_size_kb, ... }
```

### 优化参数说明

| 参数 | 默认值 | 说明 |
|------|--------|------|
| max_width | 1200px | 确保在手机/平板上清晰显示，不浪费流量 |
| max_height | 1600px | 适配竖版拍照（一道题通常为竖版） |
| quality | 85 | JPEG 压缩质量，85 是清晰度与体积的最佳平衡点 |
| max_file_size_kb | 500KB | 目标上限，确保 ima 笔记中秒开 |
| format | jpeg | 兼容性最好；后续可切换为 webp 进一步减小体积 |
| strip_exif | true | 保护学生隐私，同时减小 10-20% 体积 |

> ⚠️ **注意**：优化过程不得损害数学题目的可读性。如果图片中有小字注释或复杂几何图形，压缩后必须仍然清晰可辨。当 quality 降到 60 以下仍无法满足 max_file_size_kb 要求时，停止压缩并使用当前 quality=60 的版本。

## ima 笔记内容模板

调用 ima-skills 时，将错题分析结果组织为以下格式的笔记正文。

### ⚠️ 关键规则：原图置顶 + Unicode 格式

1. **原图必须内联显示在笔记正文最顶部**：使用 `![题目原图]({optimized_image_url})` 格式嵌入，不是作为附件，而是直接在正文中以图片形式展示，打开笔记即可看到题目原图
2. **所有数学内容必须使用 Unicode 格式**：π、×、÷、²、√、≈ 等 Unicode 符号，**禁止任何 LaTeX 代码**，确保在 ima 笔记中直接可读
3. **原图的作用**：方便学生在 ima 中复习时直接看到题目原貌（包括手写标注、老师批改痕迹等），无需回到小程序

```
请将以下错题分析结果同步到 ima 笔记：

【笔记标题】
📝 错题 - 第{question_number}题（{knowledge_point_name}）

【笔记本】
数学宝典/错题本/{knowledge_area}/{knowledge_point_name}
（动态生成，如：数学宝典/错题本/图形与几何/圆）

【标签】
自动生成以下标签：
- 错误类型标签：{error_type}（如：计算错误、概念错误、审题错误等）
- 知识点标签：{knowledge_point_name}（如：比与比例、圆的面积等）
- 年级标签：{grade}年级
- 难度标签：难度{difficulty}
- 状态标签：待复习

【知识库】
数学宝典（顶级知识库）

【笔记正文】
使用以下结构组织笔记内容。⚠️ 所有数学公式和符号必须使用 Unicode 格式（如 π、²、√、×、÷、≈ 等），禁止输出原始 LaTeX 代码（如 $\frac{a}{b}$、\pi 等）。

---

# 📝 错题记录 - 第{question_number}题

## 📷 题目原图

![题目原图]({optimized_image_url})

> ⬆️ 拍照原图（已优化，点击可查看大图）

---

📅 录入时间：{created_at}
📚 知识点：{knowledge_point_name}（{knowledge_point_id}）
⚠️ 错误类型：{error_type}
⭐ 难度：{"★" × difficulty}

---

## 📋 题目内容

{question_text}（使用 Unicode 数学符号展示，如 S = πr²、∠A = 90°）

{如果有几何图形，插入 figure_svg}

## ❌ 我的错误答案

{student_answer}

## ⚠️ 错在哪里

{error_description}（使用 Unicode 格式描述，如"将 3/4 × π 误算为 3π/2"）

**错误位置**：{error_location}
**根本原因**：{root_cause}

## ✅ 正确解法

{按 correct_solution.steps 逐步展示，每步使用 display 字段（Unicode 格式），格式如下：}

**第{step_number}步** — {description}
  {display}（如：S = π × 4² ÷ 4 = 4π ≈ 12.57）
  💡 {explanation}

**最终答案**：{final_answer}（Unicode 格式，如 3π + 4 ≈ 13.42）

## 💡 避错建议

{improvement_suggestions.immediate}

**练习方向**：{improvement_suggestions.practice}

## 📊 复习状态

- [ ] 第 1 次复习
- [ ] 第 2 次复习
- [ ] 第 3 次复习（连续 3 次全对即标记掌握）

---

> 📌 由「数学错题私教」skill 自动生成并同步

---

【附件】
- 原始拍照图片：{optimized_image_url}（已优化压缩，同时作为正文内联图和附件双重保存）
```

> 💡 **为什么同时内联和附件？**
> - **内联图片**（正文顶部）：打开笔记立即可见，方便快速复习
> - **附件备份**：防止正文渲染异常时仍可下载查看原图

## 同步结果处理

### 同步成功

```json
{
  "sync_status": "synced",
  "ima_note_id": "从 ima-skills 返回的笔记 ID",
  "ima_note_url": "笔记的访问链接",
  "synced_at": "同步完成时间"
}
```

向用户展示：
```
✅ 已同步到 ima 笔记
📓 笔记本：数学错题本
🏷️ 标签：{error_type} · {knowledge_point_name}
```

### 同步失败

```json
{
  "sync_status": "sync_failed",
  "error_code": "错误代码",
  "error_message": "错误描述",
  "retry_count": 0
}
```

处理策略：
1. 首次失败 → 静默重试一次（间隔 3 秒）
2. 重试仍失败 → 向用户展示：
```
⚠️ 同步到 ima 笔记暂时失败，错题已保存到本地。
稍后可以在错题库中点击"重新同步"按钮。
```
3. 将 `error_card.ima_sync_status` 设为 `"sync_failed"`，后续打开错题库时自动重试

## 同步内容映射关系

| 错题卡片字段 | ima 笔记对应位置 | 说明 |
|------------|----------------|------|
| `question.image_url` | **笔记正文顶部（内联图片）** + 笔记附件 | 优化后的题目原图，正文顶部直接显示，附件备份 |
| `question.text` | 笔记正文 - 题目内容区 | 题目原文（Unicode 格式） |
| `question.figure_svg` | 笔记正文 - 题目内容区 | 几何图形（内嵌 SVG） |
| `student_answer.answer_text` | 笔记正文 - 错误答案区 | 学生的错误作答 |
| `error_analysis.error_type` | 笔记标签 + 正文 | 错误类型 |
| `error_analysis.error_description` | 笔记正文 - 错误分析区 | 错误描述（Unicode 格式） |
| `error_analysis.root_cause` | 笔记正文 - 错误分析区 | 根本原因 |
| `error_analysis.friendly_summary` | 笔记正文 - 总结区 | 友好总结（Unicode 格式） |
| `correct_answer.solution_steps[]` | 笔记正文 - 正确解法区 | 逐步解题过程（使用 display 字段，Unicode 格式） |
| `knowledge_points[].name` | 笔记标签 + 正文头部 | 知识点标签 |
| `improvement_suggestions` | 笔记正文 - 避错建议区 | 改进建议 |
| `status` | 笔记正文 - 复习状态 | 复习 checklist |
