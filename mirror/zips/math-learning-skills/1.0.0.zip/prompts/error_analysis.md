# 错题分析 Prompt 模板

## 触发场景

用户上传错题图片或输入错题文字内容后，调用本 Prompt 进行错题分析。

## 输入

- `{image}`: 用户上传的错题图片（可选，若有则先调用 image_recognition Prompt）
- `{question_text}`: 题目文字内容（OCR 识别结果或用户手动输入）
- `{student_answer}`: 学生的错误答案（如有）
- `{correct_answer}`: 正确答案（如已知）
- `{grade}`: 年级（默认从用户画像获取）

## Prompt

```
请分析以下数学错题：

【题目内容】
{question_text}

【学生答案】
{student_answer}

【正确答案】
{correct_answer}

请按照以下结构进行分析，以 JSON 格式输出：

{
  "question_parse": {
    "original_text": "题目原文",
    "question_type": "题目类型（选择题/填空题/计算题/证明题/应用题）",
    "difficulty": 1-5,
    "latex_expression": "题目的 LaTeX 表达式"
  },
  "error_analysis": {
    "error_location": "错误出现在哪一步",
    "error_type": "错误类型（计算错误/概念错误/方法错误/审题错误/粗心大意）",
    "error_description": "用通俗的语言描述学生错在哪里",
    "root_cause": "深层原因分析（为什么会犯这个错误）"
  },
  "knowledge_points": [
    {
      "id": "知识点编号（参考 knowledge_points.yaml）",
      "name": "知识点名称",
      "chapter": "所属章节",
      "mastery_hint": "该知识点的掌握要点"
    }
  ],
  "correct_solution": {
    "steps": [
      {
        "step_number": 1,
        "description": "步骤描述",
        "latex": "数学表达式",
        "explanation": "为什么要这样做"
      }
    ],
    "final_answer": "最终正确答案"
  },
  "improvement_suggestions": {
    "immediate": "现在可以做什么来理解这个知识点",
    "practice": "建议练习的方向",
    "encouragement": "鼓励性的话语"
  },
  "friendly_summary": "用亲切的语言总结分析结果（直接展示给学生看的文字）"
}

注意事项：
1. "friendly_summary" 必须用鼓励性的语气，适合 12-15 岁学生阅读
2. "error_type" 的分类要准确，这影响后续的知识点推荐
3. 解题步骤要足够详细，每一步的逻辑要清晰
4. 知识点映射要精确到沪教版的具体章节
```

## 输出格式

严格 JSON 格式，字段如上所述。前端将根据此结构渲染错题分析卡片。

## 示例

**输入**：题目"解方程 $2x + 3 = 11$"，学生答案 $x = 3$

**期望输出要点**：
- error_type: "计算错误"
- error_location: "移项计算环节"
- knowledge_points: 一元一次方程
- correct_solution: $2x = 11 - 3 = 8$, $x = 4$
- friendly_summary: "你的解题思路是对的！只是在最后算 $2x = 8$ 求 $x$ 时算错了，$8 \div 2 = 4$ 而不是 3。这种计算小失误很正常，下次验算一下就能避免啦 💪"
