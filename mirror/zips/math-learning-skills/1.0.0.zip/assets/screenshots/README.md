# Screenshots

此目录存放 SkillHub 商店详情页的功能截图。

截图将在 Skill 开发完成后从 WorkBuddy 微信小程序中截取。
