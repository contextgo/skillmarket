# Assets 资源目录

本目录存放 SkillHub 商店展示所需的图片资源。

## 文件清单

| 文件 | 用途 | 建议规格 |
|------|------|---------|
| `icon.png` | Skill 图标 | 512×512 px, PNG |
| `banner.png` | 商店横幅图 | 1200×600 px, PNG |
| `screenshots/01_error_analysis.png` | 错题分析功能截图 | 1080×1920 px |
| `screenshots/02_practice.png` | 举一反三练习截图 | 1080×1920 px |
| `screenshots/03_exam_paper.png` | 组卷功能截图 | 1080×1920 px |

## 设计要求

- icon 应体现"数学+AI"主题，风格清新、适合教育场景
- 截图应在 WorkBuddy 微信小程序的真实界面中截取
- 所有图片不含个人隐私信息

> 注意：当前为占位说明文件，实际图片资源需在开发完成后补充。
