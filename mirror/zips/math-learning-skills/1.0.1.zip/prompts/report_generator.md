# 学习报告生成 Prompt 模板

## 触发场景

用户请求生成学习报告，或系统在积累一定数量的错题后自动触发。

## 输入

- `{error_cards}`: 错题卡片集合（包含错题内容、分析结果、知识点、时间戳）
- `{exercise_records}`: 练习记录（举一反三的作答记录和批改结果）
- `{time_range}`: 报告时间范围（如"近一周"/"近一月"/"本学期"）
- `{user_profile}`: 用户画像（年级、历史薄弱点等）

## Prompt

```
请根据以下学习数据生成一份数学学习报告：

【报告时间范围】
{time_range}

【学生基本信息】
{user_profile}

【错题数据】
{error_cards}

【练习记录】
{exercise_records}

请以 JSON 格式输出学习报告：

{
  "report_summary": {
    "title": "报告标题（如：小明同学 5月数学学习报告）",
    "period": "报告周期",
    "total_errors": "总错题数",
    "total_exercises": "总练习数",
    "overall_progress": "整体进步评价（进步明显/稳步提升/需要加油）"
  },
  "knowledge_analysis": {
    "mastery_overview": [
      {
        "knowledge_area": "知识板块（数与代数/图形与几何/统计与概率）",
        "mastery_level": 0-100,
        "trend": "上升/持平/下降"
      }
    ],
    "weak_points": [
      {
        "knowledge_point": "薄弱知识点名称",
        "error_count": "错题次数",
        "error_rate": "错误率",
        "severity": "严重程度（需重点关注/一般/轻微）",
        "suggestion": "针对性建议"
      }
    ],
    "strong_points": [
      {
        "knowledge_point": "掌握较好的知识点",
        "mastery_level": 0-100
      }
    ]
  },
  "error_pattern_analysis": {
    "most_common_error_type": "最常见的错误类型",
    "error_type_distribution": {
      "计算错误": 0,
      "概念错误": 0,
      "方法错误": 0,
      "审题错误": 0,
      "粗心大意": 0
    },
    "pattern_insight": "错误模式洞察（如：大部分错误集中在分式运算的通分环节）"
  },
  "progress_tracking": {
    "improvement_highlights": ["进步亮点"],
    "comparison_with_last": "与上期报告对比",
    "mastery_changes": [
      {
        "knowledge_point": "知识点",
        "before": 0-100,
        "after": 0-100,
        "change": "+/-"
      }
    ]
  },
  "recommendations": {
    "priority_focus": ["本周/本月重点攻克的知识点"],
    "practice_plan": "建议练习计划",
    "study_tips": ["学习方法建议"],
    "parent_note": "给家长的话（简短建议）"
  },
  "encouragement": "给学生的鼓励性总结（温暖、有力量的话语）"
}

注意事项：
1. 报告要客观但温暖，先说进步和亮点，再说需要改进的地方
2. 薄弱点分析要具体到知识点，不要笼统说"数学不好"
3. 建议要具体可执行，不要空泛的"多做练习"
4. 给家长的话要简洁专业，避免制造焦虑
5. 鼓励性总结要让学生感受到被认可和被支持
6. 如果数据量不足以生成有意义的统计，诚实说明并给出初步观察
```
