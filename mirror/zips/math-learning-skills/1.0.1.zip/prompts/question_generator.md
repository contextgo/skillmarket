# 题目生成 Prompt 模板

## 触发场景

用户完成错题分析后，选择"举一反三"功能，基于错题关联的知识点生成练习题。

## 输入

- `{knowledge_points}`: 关联知识点列表（来自错题分析结果）
- `{difficulty}`: 目标难度等级（1-5）
- `{mode}`: 生成模式（similar / variant / mixed）
- `{count}`: 生成题目数量（默认 3-5 题）
- `{original_question}`: 原始错题内容（用于生成相似题参考）
- `{grade}`: 年级

## 模式说明

- **similar（相似题）**：与原题考察相同知识点、相同题型、相近难度
- **variant（变式题）**：相同知识点，但改变条件、改变问法、或组合多个知识点
- **mixed（综合训练）**：混合相似题和变式题，难度梯度递增

## Prompt

```
请基于以下信息生成练习题：

【原始错题】
{original_question}

【关联知识点】
{knowledge_points}

【生成要求】
- 模式：{mode}
- 数量：{count} 道
- 目标难度：{difficulty}（1-5 级，1 最简单，5 最难）
- 课程标准：上海沪教版初中数学
- 年级：{grade}

请以 JSON 格式输出：

{
  "exercises": [
    {
      "id": "ex_001",
      "question_text": "题目文字描述（使用 Unicode 数学符号如 π、²、×、÷ 等，禁止原始 LaTeX 代码）",
      "question_latex": "题目的完整 LaTeX 表达式（机器可读，供前端渲染器使用）",
      "question_type": "题目类型（选择题/填空题/计算题/证明题/应用题）",
      "difficulty": 1-5,
      "mode": "similar / variant",
      "knowledge_points": ["关联知识点ID"],
      "options": ["选项A", "选项B", "选项C", "选项D"],
      "correct_answer": "正确答案（使用 Unicode 符号展示）",
      "solution": {
        "steps": [
          {
            "step_number": 1,
            "description": "步骤描述（中文说明）",
            "latex": "数学表达式（LaTeX 格式）",
            "display": "数学表达式（Unicode 可读格式，如 S = πr² = π × 4 = 4π ≈ 12.57）"
          }
        ],
        "key_insight": "解题关键思路"
      },
      "variant_description": "与原题的变化说明（仅 variant 模式）"
    }
  ],
  "difficulty_progression": "难度梯度说明",
  "practice_tips": "练习建议（展示给学生的鼓励性文字，使用 Unicode 符号，禁止 LaTeX）"
}

注意事项：
1. 题目必须符合上海沪教版课程标准，不超纲
2. 选择题必须提供 4 个选项，且干扰项要有合理性
3. 难度梯度要合理：如果是 mixed 模式，前 1-2 题稍简单，后面递增
4. 每道题必须有完整的解题步骤和正确答案
5. variant 模式的题目要明确说明与原题的差异点
6. 应用题的情境要贴近初中生的生活实际
7. practice_tips 要用鼓励性语言
8. 【关键 - 公式显示】question_text、correct_answer、practice_tips 等面向学生的文字，必须使用 Unicode 数学符号（π、×、÷、²、√、≈ 等），**禁止输出原始 LaTeX 代码**。分数用斜杠（如 1/4），复杂表达式拆成多步。solution.steps 同时提供 latex（机器格式）和 display（可读格式）。
```

## 难度等级对照

| 等级 | 描述 | 对应水平 |
|------|------|---------|
| 1 | 基础 | 课本例题难度 |
| 2 | 较易 | 课后练习难度 |
| 3 | 中等 | 期中/期末考试难度 |
| 4 | 较难 | 区统考/一模难度 |
| 5 | 挑战 | 中考压轴/竞赛入门难度 |
