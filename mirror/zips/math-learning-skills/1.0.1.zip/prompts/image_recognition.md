# 图片识别指令 Prompt

## 触发场景

用户上传错题图片后，调用平台视觉模型识别图片中的数学题目内容。

## 输入

- `{image}`: 用户上传的图片
- `{context_hint}`: 上下文提示（可选，如"这是一道几何题"）
- `{target_question}`: 用户指定的目标题号（可选，如"第22题"）

## Prompt

```
请仔细识别这张图片中的数学题目内容。

⚠️ 重要：这张图片中可能包含多道题目。请务必按照以下流程处理：

### 第一步：全局扫描与多题检测
1. 先快速扫描整张图片，判断图片中包含多少道独立的题目
2. 通过题号标记（如"22、""23.""第24题"等）、空白间隔、分隔线来识别题目边界
3. 将每道题目单独分离出来

### 第二步：逐题识别
对图片中检测到的**每一道题目**分别进行内容识别：
1. 将文字内容完整转录
2. 数学公式、方程式、表达式使用 LaTeX 格式输出
3. 如果包含几何图形，用文字描述图形的关键要素（点、线、角、标注）
4. 识别手写内容（含学生作答和老师批注）
5. 区分题目部分和学生的作答/订正部分
6. 判断每道题的作答是否正确（如果能判断的话）

### 第三步：确定目标题目
{target_question}
- 如果用户指定了目标题号，直接锁定该题目
- 如果用户未指定，根据以下优先级自动推荐：
  a. 有明显错误标记（红叉、圈出的错误）的题目
  b. 学生作答答案与正确答案不一致的题目
  c. 有手写订正痕迹的题目
  d. 如果无法确定，列出所有题目让用户选择

{context_hint}

请以 JSON 格式输出识别结果：

{
  "multi_question_detected": true/false,
  "total_questions_found": 0,
  "questions": [
    {
      "question_index": 1,
      "question_number": "图片中的原始题号（如'22'、'24'等）",
      "region_description": "题目在图片中的大致位置（如'图片上半部分'、'图片中部偏左'）",
      "recognition_result": {
        "full_text": "该题完整识别的文字内容",
        "question_part": "题目部分（纯题目，不含学生作答）",
        "student_answer_part": "学生作答/订正部分（如有）",
        "latex_expressions": [
          "该题包含的所有数学表达式（LaTeX 格式）"
        ]
      },
      "question_info": {
        "question_type": "题目类型推断（选择题/填空题/计算题/证明题/应用题/无法判断）",
        "has_figure": true/false,
        "figure_description": "几何图形的文字描述（如有）",
        "figure_data": {
          "type": "几何图形类型（circle/triangle/rectangle/sector/annular_sector/composite/coordinate/other）",
          "elements": [
            {
              "shape": "基本图形（circle/arc/line/rectangle/sector/polygon/point/label/angle_mark）",
              "params": "该图形的具体参数（JSON对象，根据shape不同而不同）",
              "style": "样式信息（如 fill/stroke/shaded 等）"
            }
          ],
          "labels": [
            {
              "text": "标注文字或数值（如 '2'、'R'、'O'）",
              "position": "标注位置描述",
              "type": "dimension/point_name/angle/text"
            }
          ],
          "viewport": {
            "width": "逻辑宽度（基于题目中的数值）",
            "height": "逻辑高度"
          },
          "shaded_region": "阴影区域的描述（如 '大扇形减去小扇形的区域'）"
        },
        "estimated_grade": "推测适用年级",
        "estimated_difficulty": 1-5
      },
      "answer_status": {
        "has_student_answer": true/false,
        "appears_correct": true/false/null,
        "has_correction_marks": true/false,
        "error_indicators": ["描述发现的错误线索，如'答案被划掉重写'、'有红色叉号'等"]
      },
      "confidence": 0.0-1.0
    }
  ],
  "recommended_target": {
    "question_index": "推荐分析的题目索引（从1开始）",
    "reason": "推荐原因（如'该题有明显的错误标记'、'学生答案与正确答案不一致'）"
  },
  "needs_user_selection": true/false,
  "selection_prompt": "如果需要用户选择，展示给用户的提示文字（如'我在图片中发现了3道题目：第22题（比与比例）、第23题、第24题（阴影面积）。请问你想分析哪一道？'）",
  "image_quality": {
    "clarity": "清晰度评级（高/中/低）",
    "completeness": "内容完整性（完整/部分截断/严重不全）",
    "issues": ["可能存在的识别问题，如光线不足、模糊、倾斜等"]
  },
  "crop_suggestion": {
    "should_crop": true/false,
    "reason": "建议裁剪的原因（如'图片包含多道题目，建议裁剪到目标题目区域以提高识别精度'）",
    "tip": "给用户的拍照建议（如'建议只拍摄一道题目，或拍照后裁剪到目标题目区域'）"
  }
}

注意事项：
1. 数学符号的识别要特别仔细：
   - 区分 x（变量）和 ×（乘号）
   - 区分 l（字母）和 1（数字）
   - 区分 O（字母）和 0（数字）
   - 正确识别上下标、分数线、根号等
2. 如果图片模糊或部分内容无法识别，在 confidence 中反映
3. 【关键 - 几何图形处理】：
   - 当题目包含几何图形时，`has_figure` 必须设为 true
   - 除了用 `figure_description` 做文字描述外，**必须同时输出 `figure_data` 结构化数据**
   - `figure_data.elements` 要精确描述图形中的每个基本元素（圆、弧、线段、多边形等）
   - `figure_data.labels` 要完整记录图形上的所有标注（尺寸、点名、角度等）
   - 阴影区域要在 `shaded_region` 中准确描述构成方式
   - 常见几何图形类型参考：
     * `annular_sector`: 扇环（大扇形减小扇形，如本题第24题）
     * `sector`: 扇形
     * `circle`: 圆
     * `triangle`: 三角形
     * `composite`: 组合图形
     * `coordinate`: 坐标系图形
4. 如果图片不是数学题（如风景照、无关图片），confidence 设为 0，并在 issues 中说明
5. 【关键】多道题目时，必须将每道题完整分离，不要将不同题目的内容混在一起
6. 【关键】优先推荐有错误迹象的题目作为分析目标，避免分析已经做对的题目
```

## 多题目处理流程

```
用户上传图片
  ↓
视觉模型扫描 → 检测到多道题目？
  ↓ 是                    ↓ 否
分离各题目            正常单题流程
  ↓
用户是否指定了目标题号？
  ↓ 是                    ↓ 否
锁定目标题            智能推荐（优先有错误标记的题目）
  ↓                       ↓
                    推荐结果 → 用户确认
  ↓
提取目标题目的识别结果 → 进入错题分析流程
```

## 置信度阈值

| 置信度区间 | 处理方式 |
|-----------|---------|
| >= 0.9 | 直接进入错题分析流程 |
| 0.7 - 0.9 | 展示识别结果，请用户确认 |
| 0.5 - 0.7 | 展示结果并高亮不确定部分，建议用户编辑 |
| < 0.5 | 提示识别困难，建议重拍或手动输入 |

## 裁剪引导策略

当检测到图片中包含多道题目时，系统应：
1. **首次使用时**：温馨提示「拍照时建议只对准一道题目，识别会更准确哦 📷」
2. **每次多题检测时**：在识别结果中附带 `crop_suggestion`，引导用户下次拍照时裁剪
3. **提供题目选择列表**：用简洁的文字列出检测到的所有题目，让用户快速选择
