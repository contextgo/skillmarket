# ima 笔记同步 Prompt 模板

## 触发场景

错题分析完成后，自动调用 ima-notes skill 将错题及分析结果同步到 ima 笔记。

## 前置条件检查

在执行同步前，必须按以下顺序检查：

### 第零步：检查 ima 账号是否已授权

```
调用平台接口：check_ima_auth_status()
```

- **已授权且 token 有效** → 直接进入第一步
- **token 过期** → 自动刷新 token（调用 `refresh_ima_token()`），刷新成功则继续，失败则走未授权流程
- **未授权** → 向用户展示授权引导：

```
🔗 关联 ima 笔记账号

要将错题自动同步到 ima 笔记，需要先关联你的 ima 账号。

关联后可以：
  · 📱 在 ima 笔记中随时查看和复习错题
  · 🔍 按知识点、错误类型搜索历史错题
  · 💻 手机、平板、电脑多端同步
  · 📓 自动整理成"数学错题本"笔记本

关联过程只需 3 步：
  ① 点击下方「关联 ima 账号」按钮
  ② 在 ima 页面登录你的账号（或注册新账号）
  ③ 点击"允许授权"即可

⚠️ 我们只申请笔记读写权限，不会访问你的其他数据。

👉 [关联 ima 账号]
```

- 用户点击授权 → 跳转 ima OAuth 授权页面（微信小程序通过 webview 或小程序跳转）
- 用户完成授权 → 回调获取 access_token → 平台安全存储 → 继续第一步
- 用户拒绝授权 → 向用户展示：

```
没关系！错题已保存在本地错题库中 📚
随时可以在设置中关联 ima 账号，开启自动同步。
```

- 标记 `ima_auth_status = "user_declined"`，本次不同步
- 后续每隔 3 次录题再温和提醒一次（不强制）

### 第一步：检查 ima-notes skill 是否已安装

```
调用平台接口：check_skill_installed("ima-notes")
```

- **已安装** → 直接进入第二步
- **未安装** → 向用户展示安装引导：

```
📓 检测到你还未安装「ima 笔记」skill

安装后，每次录入错题都会自动同步到 ima 笔记，方便你：
  · 📱 在手机、平板、电脑上随时复习
  · 🔍 按知识点搜索历史错题
  · 📊 自动整理成错题笔记本

👉 是否立即安装？
```

- 用户同意 → 调用 `install_skill("ima-notes")` → 安装完成后继续
- 用户拒绝 → 标记 `ima_sync_status = "user_skipped"`，本次不同步，后续每隔 5 次录题再提醒一次

### 第二步：调用 ima-notes skill 创建笔记

## 输入

- `{error_card}`: 完整的错题卡片数据（符合 `schemas/error_card.json` 格式）
- `{analysis_result}`: 错题分析结果（来自 `prompts/error_analysis.md` 的输出）
- `{original_image_url}`: 原始拍照图片 URL
- `{figure_svg}`: 几何图形 SVG 代码（如有）

## ima 笔记内容模板

调用 ima-notes skill 时，将错题分析结果组织为以下格式的笔记正文：

```
请将以下错题分析结果同步到 ima 笔记：

【笔记标题】
📝 错题 - 第{question_number}题（{knowledge_point_name}）

【笔记本】
数学错题本

【标签】
自动生成以下标签：
- 错误类型标签：{error_type}（如：计算错误、概念错误、审题错误等）
- 知识点标签：{knowledge_point_name}（如：比与比例、圆的面积等）
- 年级标签：{grade}年级
- 难度标签：难度{difficulty}
- 状态标签：待复习

【笔记正文】
使用以下结构组织笔记内容（使用 Unicode 数学符号，禁止 LaTeX 代码）：

---

# 📝 错题记录 - 第{question_number}题

📅 录入时间：{created_at}
📚 知识点：{knowledge_point_name}（{knowledge_point_id}）
⚠️ 错误类型：{error_type}
⭐ 难度：{"★" × difficulty}

---

## 📋 题目

{question_text}

{如果有几何图形，插入 figure_svg}

## ❌ 我的错误答案

{student_answer}

## ⚠️ 错在哪里

{error_description}

**错误位置**：{error_location}
**根本原因**：{root_cause}

## ✅ 正确解法

{按 correct_solution.steps 逐步展示，每步格式如下：}

**第{step_number}步** — {description}
  {display}
  💡 {explanation}

**最终答案**：{final_answer}

## 💡 避错建议

{improvement_suggestions.immediate}

**练习方向**：{improvement_suggestions.practice}

## 📊 复习状态

- [ ] 第 1 次复习
- [ ] 第 2 次复习
- [ ] 第 3 次复习（连续 3 次全对即标记掌握）

---

> 📌 由「数学错题私教」skill 自动生成并同步

---

【附件】
- 原始拍照图片：{original_image_url}
```

## 同步结果处理

### 同步成功

```json
{
  "sync_status": "synced",
  "ima_note_id": "从 ima-notes skill 返回的笔记 ID",
  "ima_note_url": "笔记的访问链接",
  "synced_at": "同步完成时间"
}
```

向用户展示：
```
✅ 已同步到 ima 笔记
📓 笔记本：数学错题本
🏷️ 标签：{error_type} · {knowledge_point_name}
```

### 同步失败

```json
{
  "sync_status": "sync_failed",
  "error_code": "错误代码",
  "error_message": "错误描述",
  "retry_count": 0
}
```

处理策略：
1. 首次失败 → 静默重试一次（间隔 3 秒）
2. 重试仍失败 → 向用户展示：
```
⚠️ 同步到 ima 笔记暂时失败，错题已保存到本地。
稍后可以在错题库中点击"重新同步"按钮。
```
3. 将 `error_card.ima_sync_status` 设为 `"sync_failed"`，后续打开错题库时自动重试

## 同步内容映射关系

| 错题卡片字段 | ima 笔记对应位置 | 说明 |
|------------|----------------|------|
| `question.text` | 笔记正文 - 题目区 | 题目原文 |
| `question.image_url` | 笔记附件 | 原始拍照图片 |
| `question.figure_svg` | 笔记正文 - 题目区 | 几何图形（内嵌 SVG） |
| `student_answer.answer_text` | 笔记正文 - 错误答案区 | 学生的错误作答 |
| `error_analysis.error_type` | 笔记标签 + 正文 | 错误类型 |
| `error_analysis.error_description` | 笔记正文 - 错误分析区 | 错误描述 |
| `error_analysis.root_cause` | 笔记正文 - 错误分析区 | 根本原因 |
| `error_analysis.friendly_summary` | 笔记正文 - 总结区 | 友好总结 |
| `correct_answer.solution_steps[]` | 笔记正文 - 正确解法区 | 逐步解题过程 |
| `knowledge_points[].name` | 笔记标签 + 正文头部 | 知识点标签 |
| `improvement_suggestions` | 笔记正文 - 避错建议区 | 改进建议 |
| `status` | 笔记正文 - 复习状态 | 复习 checklist |
