# 答案批改 Prompt 模板

## 触发场景

学生完成举一反三练习题作答后，提交答案进行智能批改。

## 输入

- `{question}`: 题目内容
- `{correct_answer}`: 标准答案
- `{correct_solution}`: 标准解题步骤
- `{student_answer}`: 学生提交的答案
- `{student_work_image}`: 学生手写解题过程图片（可选）

## Prompt

```
请批改以下数学题的学生答案：

【题目】
{question}

【标准答案】
{correct_answer}

【标准解法】
{correct_solution}

【学生答案】
{student_answer}

【学生解题过程图片】
{student_work_image}

请以 JSON 格式输出批改结果：

{
  "is_correct": true/false,
  "score": 0-100,
  "grading_detail": {
    "answer_match": "答案是否与标准答案一致（完全正确/部分正确/错误）",
    "process_evaluation": "解题过程评价（如有手写过程图片）",
    "partial_credit_reason": "部分得分原因（如果不是满分也不是零分）"
  },
  "error_analysis": {
    "has_error": true/false,
    "error_type": "错误类型（计算错误/概念错误/方法错误/审题错误/无错误）",
    "error_detail": "具体错误描述",
    "error_step": "出错的步骤编号（如果能定位）"
  },
  "feedback": {
    "praise": "值得肯定的地方（即使答错了也要找到亮点）",
    "correction": "纠正说明（如果有错误）",
    "next_step": "下一步建议",
    "encouragement": "鼓励性评语"
  },
  "friendly_comment": "用口语化的方式给学生的综合评语（直接展示给学生看）"
}

注意事项：
1. 【最高优先级】批改结论必须准确：先完整验算，确认对错后再给评语。绝对禁止先说"你做对了"后面又发现错误
2. 答案正确时：大方肯定，如"完全正确！解题过程也很规范"
3. 答案错误时：先明确指出错误（如"第3步有个小问题"），然后肯定做对的具体步骤（如"前两步的化简很熟练"），最后给出修正和鼓励
4. 如果学生的方法与标准解法不同但答案正确，要肯定学生的创造性思维
5. friendly_comment 控制在 2-3 句话，用 12-15 岁学生能理解的语言
6. 如果有手写过程图片，要分析解题步骤中的每一步是否正确
7. 【关键 - 公式显示】friendly_comment、praise、correction、encouragement 等面向学生的文字中，**禁止输出原始 LaTeX 代码**（如 $\frac{a}{b}$、\pi 等）。必须使用 Unicode 数学符号：π、×、÷、²、√、≈、≤、≥、≠ 等。分数用斜杠（如 1/4），复杂公式拆分为多行。
```

## 评分规则

- **100 分**：答案完全正确，过程规范
- **80-99 分**：答案正确，但过程有小瑕疵（如跳步、书写不规范）
- **50-79 分**：思路正确但答案有误，或部分步骤正确
- **20-49 分**：有正确的起步但中间出现关键错误
- **0-19 分**：完全偏离或未作答
