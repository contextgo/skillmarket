# 错题分析 Prompt 模板

## 触发场景

用户上传错题图片或输入错题文字内容后，调用本 Prompt 进行错题分析。

## 输入

- `{image}`: 用户上传的错题图片（可选，若有则先调用 image_recognition Prompt）
- `{question_text}`: 题目文字内容（OCR 识别结果或用户手动输入。**注意：如果原图包含多道题目，此处只传入用户选定的那一道题目的内容**）
- `{student_answer}`: 学生的错误答案（如有）
- `{correct_answer}`: 正确答案（如已知）
- `{grade}`: 年级（默认从用户画像获取）
- `{question_number}`: 题号（如有，如"第22题"）

## Prompt

```
请分析以下数学错题：

【题目内容】
{question_text}

【学生答案】
{student_answer}

【正确答案】
{correct_answer}

请按照以下结构进行分析，以 JSON 格式输出：

{
  "question_parse": {
    "original_text": "题目原文",
    "question_type": "题目类型（选择题/填空题/计算题/证明题/应用题）",
    "difficulty": 1-5,
    "latex_expression": "题目的 LaTeX 表达式（机器可读，供前端未来 LaTeX 渲染器使用）",
    "display_expression": "题目的可读文本表达式（使用 Unicode 数学符号，如 π、²、√、÷、× 等，直接展示给学生）",
    "has_figure": true/false,
    "figure_svg": "如果题目包含几何图形，在此输出完整的 SVG 代码用于前端渲染（见下方【几何图形 SVG 生成规范】）",
    "figure_description": "几何图形的文字辅助描述（用于无障碍访问和备用展示）"
  },
  "error_analysis": {
    "error_location": "错误出现在哪一步",
    "error_type": "错误类型（计算错误/概念错误/方法错误/审题错误/粗心大意）",
    "error_description": "用通俗的语言描述学生错在哪里（使用 Unicode 数学符号，禁止 LaTeX 代码）",
    "root_cause": "深层原因分析（为什么会犯这个错误）"
  },
  "knowledge_points": [
    {
      "id": "知识点编号（参考 knowledge_points.yaml）",
      "name": "知识点名称",
      "chapter": "所属章节",
      "mastery_hint": "该知识点的掌握要点"
    }
  ],
  "correct_solution": {
    "steps": [
      {
        "step_number": 1,
        "description": "步骤描述（中文，说明这一步在做什么）",
        "latex": "数学表达式（LaTeX 格式，机器可读）",
        "display": "数学表达式（Unicode 可读格式，如 S = πR² ÷ 4 = π × 16 ÷ 4 = 4π）",
        "explanation": "为什么要这样做"
      }
    ],
    "final_answer": "最终正确答案（使用 Unicode 符号，如 3π ≈ 9.42）",
    "final_answer_latex": "最终正确答案的 LaTeX 格式"
  },
  "improvement_suggestions": {
    "immediate": "现在可以做什么来理解这个知识点",
    "practice": "建议练习的方向",
    "encouragement": "鼓励性的话语"
  },
  "friendly_summary": "用亲切的语言总结分析结果（直接展示给学生看的文字。⚠️ 禁止包含任何 LaTeX 代码。必须使用 Unicode 符号。复杂公式要拆成多行逐步展示。🚨 最关键：必须先完成全部验算再写此字段！如果学生答案有错，开头必须明确指出有错误，禁止开头写'太棒了/你做对了'之后再反转说有错误。）"
}

注意事项：
1. 【最高优先级 - 反馈准确性】⚠️ 严格遵守以下规则：
   - **先验算，后评价**：必须先完整验算学生的每一步解答，确认正误之后，再撰写 friendly_summary 和其他面向学生的文字
   - **禁止盲目肯定**：绝对不允许先写"✅ 太棒了，你做对了！"然后在后文又发现错误、反转结论。这种先肯定后打脸的体验会严重误导学生
   - **正确做法**：
     * 答案完全正确 → 开头明确肯定："✅ 完全正确！"
     * 答案有错误 → 开头诚实说明："📝 这道题有一处需要修正"，然后具体定位错误步骤，最后再肯定做对的部分
     * 不确定时 → 先说"让我仔细看看你的解答过程"，逐步分析后再给结论
   - **鼓励的正确方式**：肯定具体做对的步骤（如"前两步化简做得非常好"），而不是笼统地说"太棒了"
2. "error_type" 的分类要准确，这影响后续的知识点推荐
3. 解题步骤要足够详细，每一步的逻辑要清晰
4. 知识点映射要精确到沪教版的具体章节
5. 【关键】只分析 {question_text} 中提供的单道题目，不要混入或引用图片中其他题目的内容
6. 如果 {question_text} 中仍然包含多道题目的内容，只分析题号为 {question_number} 的那道题
7. 【关键 - 几何图形渲染】如果题目包含几何图形（has_figure=true），必须在 figure_svg 中输出 SVG 代码，遵循下方【几何图形 SVG 生成规范】
8. 【关键 - 数学公式显示规范】⚠️ 严格遵守以下规则：
   - "friendly_summary"、"error_description"、"description"、"explanation"、"encouragement" 等面向学生的文字中，**绝对禁止**输出原始 LaTeX 代码（如 $\frac{a}{b}$、\pi、\times 等）
   - 必须使用 Unicode 数学符号替代：π（圆周率）、×（乘号）、÷（除号）、²（平方）、³（立方）、√（根号）、≈（约等于）、≤（小于等于）、≥（大于等于）、≠（不等于）、∠（角）、△（三角形）、⊥（垂直）、∥（平行）
   - 分数统一用斜杠表示：1/4、3/7，不要用 \frac{}{}
   - 复杂表达式必须拆分为多行逐步展示，每步附中文说明，不要在一行内堆砌超过 3 个运算符
   - 带标注的公式（如 \underbrace）改用分行列举方式替代
   - 每个 step 同时提供 "latex"（机器格式）和 "display"（可读格式）两个字段
   - 详细规范参见 `prompts/system.md` 中的【数学表达规范】

### 几何图形 SVG 生成规范

当题目包含几何图形时，**必须**生成 SVG 代码用于前端可视化展示，而不是仅用文字描述。

#### 基本要求：
1. SVG 画布大小：统一使用 `viewBox="0 0 300 300"`，实际显示大小由前端自适应
2. 使用简洁、清晰的线条，线宽 `stroke-width="2"`
3. 阴影区域使用浅灰色填充 `fill="#d0d0d0"` 或斜线填充
4. 标注文字使用 `font-size="14"` `font-family="sans-serif"`
5. 尺寸标注使用带箭头的线段 + 数值文字
6. 点标注使用小实心圆 `r="3"`
7. 直角标记使用小正方形（8x8 像素）

#### SVG 模板示例（扇环/阴影面积题）：

```svg
<svg viewBox="0 0 300 300" xmlns="http://www.w3.org/2000/svg">
  <!-- 阴影区域：大扇形 - 小扇形 -->
  <path d="M 150 250 L 150 50 A 200 200 0 0 1 350 250 Z" fill="none" stroke="#333" stroke-width="2"/>
  <path d="M 150 250 L 150 150 A 100 100 0 0 1 250 250 Z" fill="none" stroke="#333" stroke-width="2"/>
  <!-- 阴影填充 -->
  <path d="M 150 50 A 200 200 0 0 1 350 250 L 250 250 A 100 100 0 0 0 150 150 Z" fill="#d0d0d0" stroke="#333" stroke-width="2"/>
  <!-- 尺寸标注 -->
  <text x="145" y="200" text-anchor="end" font-size="14">r</text>
  <text x="145" y="145" text-anchor="end" font-size="14">R</text>
  <!-- 直角标记 -->
  <rect x="150" y="242" width="8" height="8" fill="none" stroke="#333" stroke-width="1"/>
</svg>
```

#### 常见几何图形 SVG 生成指南：

| 图形类型 | SVG 关键元素 | 注意事项 |
|---------|-------------|---------|
| 圆 | `<circle>` | 标注圆心、半径 |
| 扇形 | `<path>` 用圆弧 `A` 命令 | 标注圆心角、半径 |
| 扇环（本题） | 两个 `<path>` 扇形 + 阴影填充 | 大小扇形区域差集填充 |
| 三角形 | `<polygon>` | 标注顶点名、边长、角度 |
| 矩形/正方形 | `<rect>` | 标注边长 |
| 平行四边形 | `<polygon>` | 标注底和高 |
| 梯形 | `<polygon>` | 标注上底、下底、高 |
| 坐标系 | `<line>` 画轴 + `<path>` 画函数 | 标注坐标值 |
| 组合图形 | 多个基本元素组合 | 阴影区域用 `clipPath` 或 path 差集 |

#### 阴影区域的处理：
- 纯色填充：`fill="#d0d0d0"` (浅灰)
- 斜线填充（更接近数学课本风格）：
  ```svg
  <defs>
    <pattern id="hatch" patternUnits="userSpaceOnUse" width="6" height="6" patternTransform="rotate(45)">
      <line x1="0" y1="0" x2="0" y2="6" stroke="#666" stroke-width="1"/>
    </pattern>
  </defs>
  <path d="..." fill="url(#hatch)"/>
  ```

#### 质量检查清单：
- [ ] 图形比例与题目数据一致（如半径为2和4，则大圆半径应为小圆的2倍）
- [ ] 所有尺寸标注清晰可读
- [ ] 阴影区域明确标识
- [ ] 直角处有直角标记
- [ ] 关键点有名称标注
```

## 输出格式

严格 JSON 格式，字段如上所述。前端将根据此结构渲染错题分析卡片。

## 示例

**输入**：题目"解方程 2x + 3 = 11"，学生答案 x = 3

**期望输出要点**：
- error_type: "计算错误"
- error_location: "移项计算环节"
- knowledge_points: 一元一次方程
- correct_solution steps:
  - step 1: display: "2x = 11 - 3 = 8", latex: "2x = 11 - 3 = 8"
  - step 2: display: "x = 8 ÷ 2 = 4", latex: "x = 8 \\div 2 = 4"
- final_answer: "x = 4"
- friendly_summary: "你的解题思路是对的！只是在最后算 2x = 8 求 x 时算错了，8 ÷ 2 = 4 而不是 3。这种计算小失误很正常，下次验算一下就能避免啦 💪"

⚠️ **注意 friendly_summary 中没有使用任何 LaTeX 代码，全部使用 Unicode 符号和纯文本。**
