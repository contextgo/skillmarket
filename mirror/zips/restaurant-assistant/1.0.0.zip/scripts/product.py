# -*- coding: utf-8 -*-
"""
产品链路模块
包含：菜品研发、食谱库
作者：郝多鱼
版本：1.0.0
"""

from typing import Dict, List, Optional, Any
from datetime import datetime
import random
import re


def dish_development(
    菜品名称: str,
    店铺类型: str,
    成本目标: str = "",
    口味偏好: str = ""
) -> Dict[str, Any]:
    """
    菜品研发助手
    
    根据菜品名称和店铺类型，生成完整的菜品研发方案
    
    Args:
        菜品名称: 如"香辣蟹"、"奶茶新品"
        店铺类型: 如"川菜馆"、"火锅店"、"奶茶店"
        成本目标: 目标成本，如"成本控制在25元以内"
        口味偏好: 口味要求，如"微辣/重辣/甜/咸"
    
    Returns:
        配方设计、成本分析、定价建议、营养信息
    """
    if not 菜品名称 or not 菜品名称.strip():
        return {
            "error": "请提供菜品名称",
            "example": "dish_development(菜品名称='招牌辣子鸡', 店铺类型='川菜馆', 成本目标='30元以内', 口味偏好='麻辣')"
        }
    
    # 获取店铺类型对应的食材和风味
    store_features = _get_store_features(店铺类型)
    
    # 生成配方
    recipe = _generate_recipe(菜品名称, 店铺类型, store_features, 口味偏好)
    
    # 计算成本
    cost_analysis = _calculate_cost(recipe, 成本目标)
    
    # 定价建议
    pricing = _generate_pricing(recipe, cost_analysis)
    
    # 营养信息
    nutrition = _estimate_nutrition(菜品名称, 店铺类型)
    
    # 烹饪步骤
    cooking_steps = _generate_cooking_steps(菜品名称, 店铺类型)
    
    return {
        "generated_time": datetime.now().strftime("%Y-%m-%d"),
        "菜品名称": 菜品名称,
        "店铺类型": 店铺类型,
        
        "配方设计": recipe,
        
        "成本分析": cost_analysis,
        
        "定价建议": pricing,
        
        "营养信息": nutrition,
        
        "烹饪步骤": cooking_steps,
        
        "出品标准": _generate_quality_standards(菜品名称, 店铺类型),
        
        "研发建议": _generate_dev_suggestions(菜品名称, 店铺类型)
    }


def _get_store_features(store_type: str) -> Dict[str, Any]:
    """获取店铺类型特征"""
    features = {
        "火锅店": {
            "main_ingredients": ["牛肉卷", "羊肉卷", "毛肚", "鸭肠", "虾滑", "鱼丸"],
            "vegetables": ["娃娃菜", "土豆片", "藕片", "金针菇", "木耳"],
            "seasoning": ["牛油", "清油", "番茄锅底", "菌汤锅底", "辣椒", "花椒"],
            "cooking_method": "涮煮",
            "flavor": "麻辣/鲜香",
            "features": ["锅底", "蘸料", "涮品"]
        },
        "川菜馆": {
            "main_ingredients": ["猪肉", "牛肉", "鸡肉", "鱼肉", "内脏"],
            "vegetables": ["青椒", "红椒", "干辣椒", "花椒", "泡椒"],
            "seasoning": ["郫县豆瓣", "火锅底料", "豆豉", "芽菜"],
            "cooking_method": "炒/烧/蒸/炸",
            "flavor": "麻辣/香辣/家常",
            "features": ["重油", "调味丰富", "色泽红亮"]
        },
        "湘菜馆": {
            "main_ingredients": ["猪肉", "牛肉", "鱼", "腊肉", "腊鱼"],
            "vegetables": ["剁椒", "小米椒", "青椒", "豆豉"],
            "seasoning": ["剁椒", "茶油", "米酒", "浏阳豆豉"],
            "cooking_method": "炒/蒸/腊",
            "flavor": "酸辣/香辣/重油",
            "features": ["酸辣", "下饭", "重油"]
        },
        "奶茶店": {
            "main_ingredients": ["茶叶", "牛奶", "奶油", "水果", "珍珠"],
            "vegetables": [],  # 奶茶店不用蔬菜
            "seasoning": ["糖浆", "果酱", "椰果", "芋泥"],
            "cooking_method": "调配/摇晃",
            "flavor": "甜/香/清爽",
            "features": ["颜值", "口感层次", "小料"],
        },
        "烧烤店": {
            "main_ingredients": ["牛肉", "羊肉", "猪肉", "鸡肉", "海鲜"],
            "vegetables": ["茄子", "韭菜", "金针菇", "土豆片", "玉米"],
            "seasoning": ["孜然", "辣椒", "芝麻", "秘制酱料"],
            "cooking_method": "烤制",
            "flavor": "孜然/香辣/酱香",
            "features": ["炭香", "外焦里嫩", "下酒"]
        },
        "快餐店": {
            "main_ingredients": ["米饭", "面条", "饺子", "包子"],
            "vegetables": ["各类时蔬", "泡菜"],
            "seasoning": ["卤汁", "酱料", "汤底"],
            "cooking_method": "蒸/煮/炒/炸",
            "flavor": "家常/浓油赤酱",
            "features": ["出餐快", "饱腹", "性价比"]
        }
    }
    
    return features.get(store_type, features["川菜馆"])


def _generate_recipe(dish_name: str, store_type: str, features: Dict, flavor: str) -> Dict[str, Any]:
    """生成配方"""
    # 根据店铺类型选择食材
    main_ingredients = features.get("main_ingredients", [])[:3]
    vegetables = features.get("vegetables", [])[:2]
    seasonings = features.get("seasoning", [])[:4]
    
    # 构建配方
    recipe_items = []
    
    for ing in main_ingredients:
        qty = random.choice([100, 150, 200, 250])
        recipe_items.append({
            "食材": ing,
            "用量": f"{qty}g",
            "处理方式": random.choice(["切块", "切片", "切丝", "腌制", "直接使用"]),
            "成本": round(qty * random.uniform(0.02, 0.06), 2)
        })
    
    for veg in vegetables:
        qty = random.choice([50, 80, 100, 150])
        recipe_items.append({
            "食材": veg,
            "用量": f"{qty}g",
            "处理方式": random.choice(["切块", "切片", "切丝", "清洗"]),
            "成本": round(qty * random.uniform(0.01, 0.03), 2)
        })
    
    for sea in seasonings:
        qty = random.choice([5, 10, 15, 20, 30])
        unit = "g" if "油" not in sea and "酱" not in sea else "ml"
        recipe_items.append({
            "食材": sea,
            "用量": f"{qty}{unit}",
            "处理方式": "按需取用",
            "成本": round(qty * random.uniform(0.01, 0.05), 2)
        })
    
    return {
        "主料": main_ingredients,
        "辅料": vegetables,
        "调料": seasonings,
        "烹饪方法": features.get("cooking_method", "炒制"),
        "口味特点": flavor or features.get("flavor", "符合店铺风格"),
        "配方明细": recipe_items
    }


def _calculate_cost(recipe: Dict, cost_target: str) -> Dict[str, Any]:
    """计算成本"""
    # 从配方中提取成本
    recipe_items = recipe.get("配方明细", [])
    ingredient_cost = sum(item.get("成本", 0) for item in recipe_items)
    
    # 人工成本（假设5元）
    labor_cost = 5.0
    
    # 运营成本（食材的20%）
    overhead = ingredient_cost * 0.2
    
    # 总成本
    total_cost = ingredient_cost + labor_cost + overhead
    
    # 解析目标成本
    target_cost = None
    if cost_target:
        match = re.search(r'(\d+\.?\d*)', cost_target)
        if match:
            target_cost = float(match.group(1))
    
    return {
        "食材成本": round(ingredient_cost, 2),
        "人工成本": labor_cost,
        "运营成本": round(overhead, 2),
        "总成本": round(total_cost, 2),
        "目标成本": target_cost,
        "成本达标": target_cost is None or total_cost <= target_cost,
        "成本说明": f"食材成本占比 {ingredient_cost/total_cost*100:.1f}%，人工占比 {labor_cost/total_cost*100:.1f}%"
    }


def _generate_pricing(recipe: Dict, cost_analysis: Dict) -> Dict[str, Any]:
    """生成定价建议"""
    total_cost = cost_analysis.get("总成本", 30)
    
    # 毛利率定价
    margin_options = [0.60, 0.65, 0.70]
    prices = []
    
    for margin in margin_options:
        price = round(total_cost / (1 - margin), 0)
        prices.append({
            "定价": int(price),
            "毛利率": f"{margin*100:.0f}%",
            "毛利额": int(price - total_cost)
        })
    
    # 市场参考价
    market_price = round(total_cost * random.uniform(2.8, 3.5), 0)
    
    return {
        "建议售价": int(prices[1]["定价"]),  # 中档毛利率
        "定价区间": {
            "经济型(60%毛利)": f"{prices[0]['定价']}元",
            "标准型(65%毛利)": f"{prices[1]['定价']}元",
            "品质型(70%毛利)": f"{prices[2]['定价']}元"
        },
        "市场参考": f"参考价 {int(market_price)}元左右",
        "性价比分析": "价格适中，口味+份量是核心竞争力"
    }


def _estimate_nutrition(dish_name: str, store_type: str) -> Dict[str, Any]:
    """估算营养信息"""
    # 根据店铺类型估算
    base_calories = {
        "火锅店": 500,
        "川菜馆": 350,
        "湘菜馆": 380,
        "奶茶店": 350,
        "烧烤店": 450,
        "快餐店": 550
    }
    
    cal = base_calories.get(store_type, 400)
    cal += random.randint(-50, 100)
    
    return {
        "热量": f"{cal}kcal",
        "蛋白质": f"{random.randint(15, 35)}g",
        "脂肪": f"{random.randint(10, 30)}g",
        "碳水化合物": f"{random.randint(20, 50)}g",
        "钠含量": f"{random.randint(500, 1500)}mg",
        "说明": "估算值，实际以检测为准"
    }


def _generate_cooking_steps(dish_name: str, store_type: str) -> List[str]:
    """生成烹饪步骤"""
    features = _get_store_features(store_type)
    method = features.get("cooking_method", "制作")
    
    if method == "涮煮":
        steps = [
            f"1. 准备{features.get('main_ingredients', ['食材'])[0]}等涮品",
            "2. 锅底加热至沸腾",
            "3. 按易熟程度依次下锅",
            f"4. {features.get('seasoning', ['蘸料'])[0]}调蘸料",
            "5. 控制好时间，确保口感",
            "6. 出锅装盘，撒葱花"
        ]
    elif method == "炒":
        steps = [
            "1. 主料切片/切块，腌制入味",
            "2. 辅料（蔬菜）洗净切好",
            "3. 热锅凉油，下锅爆香调料",
            "4. 大火快速翻炒",
            "5. 调味，出锅前勾薄芡",
            "6. 装盘，撒葱花/芝麻"
        ]
    elif method == "烤制":
        steps = [
            "1. 食材腌制（提前2小时）",
            "2. 炭火预热至适当温度",
            "3. 按顺序摆放食材",
            "4. 适时翻面，刷油/酱",
            "5. 烤至金黄，撒孜然/辣椒",
            "6. 出炉装盘"
        ]
    elif method == "调配":
        steps = [
            "1. 按配方比例准备原料",
            "2. 茶/汤底准备好",
            "3. 加入小料（珍珠/椰果等）",
            "4. 倒入液体原料",
            "5. 摇匀或搅拌均匀",
            "6. 装饰出品"
        ]
    else:
        steps = [
            "1. 准备所有原料",
            "2. 处理食材（切/洗/腌制）",
            "3. 热锅热油",
            "4. 按步骤烹饪",
            "5. 调味出锅",
            "6. 装盘点缀"
        ]
    
    return steps


def _generate_quality_standards(dish_name: str, store_type: str) -> Dict[str, Any]:
    """生成出品标准"""
    return {
        "外观": {
            "标准": "色泽鲜亮，摆盘美观，份量充足",
            "不合格表现": "颜色暗淡/过焦/摆盘杂乱"
        },
        "口感": {
            "标准": f"符合{store_type}特色，口味地道",
            "不合格表现": "过咸/过淡/食材过生或过熟"
        },
        "温度": {
            "标准": "出品温度>65°C，热菜热吃",
            "不合格表现": "菜品发凉/冷凝水"
        },
        "卫生": {
            "标准": "无异物，无杂质，符合食品安全",
            "不合格表现": "发现异物/毛发/异物"
        },
        "分量": {
            "标准": "与标准配方一致，误差<10%",
            "不合格表现": "份量明显偏少"
        }
    }


def _generate_dev_suggestions(dish_name: str, store_type: str) -> List[str]:
    """生成研发建议"""
    return [
        f"【菜品定位】{dish_name}作为{store_type}的特色菜品，建议突出差异化",
        "【成本控制】批量采购可降低成本5-10%，建议与供应商签订长期协议",
        "【口味调整】根据本地口味适当调整，保持稳定出品是关键",
        "【营销推广】新菜品上市建议配合试吃活动，收集反馈快速迭代",
        "【标准化】制作标准操作卡，确保每家店口味一致",
        "【季节调整】根据季节推出限时版本，增加新鲜感"
    ]


def recipe_library(
    店铺类型: str,
    搜索关键词: str = ""
) -> Dict[str, Any]:
    """
    标准食谱库
    
    根据店铺类型和关键词，搜索/生成标准食谱
    
    Args:
        店铺类型: 如"川菜馆"、"火锅店"
        搜索关键词: 如"宫保鸡丁"、"下饭菜"
    
    Returns:
        食谱列表、详情查询、标准化指南
    """
    # 根据店铺类型生成推荐食谱
    recipes = _generate_recipe_list(店铺类型, 搜索关键词)
    
    return {
        "generated_time": datetime.now().strftime("%Y-%m-%d"),
        "店铺类型": 店铺类型,
        "搜索关键词": 搜索关键词,
        
        "推荐食谱": recipes,
        
        "标准化指南": {
            "核心要点": [
                "1. 所有原料必须标准化",
                "2. 火候时间精确控制",
                "3. 调味比例严格执行",
                "4. 出品必须符合质量标准"
            ],
            "标准化工具": [
                "电子秤（精确到克）",
                "量杯（精确到ml）",
                "温度计（测油温/中心温度）",
                "计时器（控制火候）"
            ]
        },
        
        "使用建议": "以上为参考食谱，实际操作请根据本店定位和顾客口味适当调整"
    }


def _generate_recipe_list(store_type: str, keyword: str) -> List[Dict]:
    """生成食谱列表"""
    # 各类型代表菜品
    type_recipes = {
        "川菜馆": [
            {"编号": "C001", "名称": "宫保鸡丁", "难度": "中", "毛利率": "67%", "销量": "日销50份", "标签": ["招牌", "下饭", "热销"]},
            {"编号": "C002", "名称": "麻婆豆腐", "难度": "低", "毛利率": "72%", "销量": "日销40份", "标签": ["家常", "下饭"]},
            {"编号": "C003", "名称": "水煮鱼", "难度": "高", "毛利率": "58%", "销量": "日销30份", "标签": ["招牌", "聚餐"]},
            {"编号": "C004", "名称": "鱼香肉丝", "难度": "中", "毛利率": "68%", "销量": "日销45份", "标签": ["经典", "下饭"]},
            {"编号": "C005", "名称": "回锅肉", "难度": "低", "毛利率": "70%", "销量": "日销35份", "标签": ["家常", "下饭"]}
        ],
        "火锅店": [
            {"编号": "H001", "名称": "精品毛肚", "难度": "低", "毛利率": "65%", "销量": "日销200份", "标签": ["必点", "招牌"]},
            {"编号": "H002", "名称": "手打虾滑", "难度": "中", "毛利率": "70%", "销量": "日销150份", "标签": ["特色", "热销"]},
            {"编号": "H003", "名称": "鲜切牛肉", "难度": "中", "毛利率": "55%", "销量": "日销100份", "标签": ["品质", "聚餐"]},
            {"编号": "H004", "名称": "嫩滑牛肉", "难度": "低", "毛利率": "68%", "销量": "日销180份", "标签": ["必点", "嫩滑"]}
        ],
        "奶茶店": [
            {"编号": "T001", "名称": "招牌珍珠奶茶", "难度": "低", "毛利率": "75%", "销量": "日销300杯", "标签": ["经典", "热销"]},
            {"编号": "T002", "名称": "杨枝甘露", "难度": "中", "毛利率": "70%", "销量": "日销200杯", "标签": ["招牌", "清爽"]},
            {"编号": "T003", "名称": "芋泥波波", "难度": "中", "毛利率": "72%", "销量": "日销180杯", "标签": ["网红", "浓郁"]}
        ],
        "湘菜馆": [
            {"编号": "X001", "名称": "剁椒鱼头", "难度": "高", "毛利率": "60%", "销量": "日销40份", "标签": ["招牌", "聚餐"]},
            {"编号": "X002", "名称": "辣椒炒肉", "难度": "低", "毛利率": "68%", "销量": "日销60份", "标签": ["经典", "下饭"]},
            {"编号": "X003", "名称": "小炒黄牛肉", "难度": "中", "毛利率": "65%", "销量": "日销45份", "标签": ["特色", "嫩滑"]}
        ]
    }
    
    recipes = type_recipes.get(store_type, type_recipes["川菜馆"])
    
    # 如果有搜索关键词，过滤匹配
    if keyword:
        recipes = [r for r in recipes if keyword in r["名称"] or any(keyword in tag for tag in r.get("标签", []))]
        if not recipes:
            recipes = type_recipes.get(store_type, type_recipes["川菜馆"])
    
    return recipes if recipes else [{"状态": "暂无相关食谱，请调整关键词"}]
