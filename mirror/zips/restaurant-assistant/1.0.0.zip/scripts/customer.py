# -*- coding: utf-8 -*-
"""
客户链路模块
包含：智能客服、口碑运营、生命周期管理
作者：郝多鱼
版本：1.0.0
"""

from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
import random
import re


def smart_customer_service(
    scenario: str = "general",
    platform: str = "all",
    user_question: str = ""
) -> Dict[str, Any]:
    """
    智能客服中枢
    
    FAQ生成、工单处理、回复模板
    
    Args:
        scenario: 场景 general/takeout/delivery/dine_in
        platform: 平台 all/phone/wechat/dianping
        user_question: 用户的问题（可选，用于生成针对性回答）
    
    Returns:
        FAQ列表、回复模板、工单处理流程
    """
    # 通用FAQ
    general_faq = [
        {
            "q": "门店地址在哪？",
            "category": "位置",
            "answer": "您好，我们门店位于[具体地址]，地铁[线路]直达，门口有停车场。营业时间：10:00-22:00，欢迎光临！",
            "priority": "high"
        },
        {
            "q": "可以预约吗？",
            "category": "预约",
            "answer": "可以的！您可以通过[预约方式]预约，到店后告知预约姓名即可。建议提前1-2天预约，节假日请提前3-5天。",
            "priority": "high"
        },
        {
            "q": "有包间吗？",
            "category": "设施",
            "answer": "我们门店有[X]个包间，可容纳[Y]人，包间需提前预约，节假日有低消要求，请致电咨询。",
            "priority": "medium"
        },
        {
            "q": "支持什么支付方式？",
            "category": "支付",
            "answer": "我们支持微信、支付宝、现金、银行卡等多种支付方式，会员还可享受积分抵扣。",
            "priority": "low"
        },
        {
            "q": "有会员优惠吗？",
            "category": "会员",
            "answer": "成为会员可享受积分返现、生日礼遇、专属折扣等福利。扫码关注公众号即可免费注册！",
            "priority": "medium"
        }
    ]
    
    # 外卖FAQ
    takeout_faq = [
        {
            "q": "配送范围是多少？",
            "category": "配送",
            "answer": "我们配送范围为门店周边3公里，超出范围暂不支持配送。",
            "priority": "high"
        },
        {
            "q": "配送时间多久？",
            "category": "配送",
            "answer": "正常情况下30-45分钟送达，高峰期可能稍有延迟，请谅解。",
            "priority": "high"
        },
        {
            "q": "如何查看订单状态？",
            "category": "订单",
            "answer": "您可以在[平台]订单页面查看实时状态，或关注推送通知。",
            "priority": "medium"
        },
        {
            "q": "可以开发票吗？",
            "category": "发票",
            "answer": "可以，请在订单完成后联系客服，告知发票抬头和税号，我们会在3个工作日内开具。",
            "priority": "medium"
        }
    ]
    
    # 投诉FAQ
    complaint_faq = [
        {
            "q": "菜品有问题怎么办？",
            "category": "投诉",
            "answer": "非常抱歉给您带来不好的体验！请您拍照留证，联系客服，我们会第一时间处理并给您满意的解决方案。",
            "priority": "critical"
        },
        {
            "q": "等位太久怎么投诉？",
            "category": "投诉",
            "answer": "对不起让您久等了！请告知您的等位时间和姓名，我们会核实情况并赠送相应补偿。",
            "priority": "high"
        },
        {
            "q": "发现异物如何处理？",
            "category": "投诉",
            "answer": "这是我们的严重失误！请保留证据，立即联系我们。我们会：1.道歉并退款 2.安排体检 3.给予赔偿 4.内部彻查",
            "priority": "critical"
        }
    ]
    
    # 合并FAQ
    all_faq = general_faq
    if scenario == "takeout":
        all_faq = general_faq + takeout_faq
    elif scenario == "delivery":
        all_faq = general_faq + takeout_faq
    elif scenario == "complaint":
        all_faq = complaint_faq
    
    # 回复模板
    templates = {
        "greeting": "您好！感谢您的咨询，我是[品牌]客服小助手，很高兴为您服务~",
        "closing": "如果您还有其他问题，欢迎随时咨询！祝您生活愉快~",
        "apology": "非常抱歉给您带来不便，我们深感歉意...",
        "thanks": "感谢您的理解与支持！",
        "transfer": "您的问题我需要转接专人处理，请稍等片刻~"
    }
    
    # 工单处理流程
    workflow = {
        "types": ["咨询", "投诉", "建议", "表扬", "退款"],
        "priorities": {"critical": "2小时", "high": "4小时", "medium": "24小时", "low": "48小时"},
        "sla": {
            "first_response": "30分钟内",
            "resolution": "按优先级响应"
        },
        "escalation": {
            "level1": "客服专员",
            "level2": "客服主管",
            "level3": "店长/经理"
        }
    }
    
    # 如果用户有问题，生成针对性回答
    generated_answer = None
    if user_question:
        generated_answer = _generate_answer(user_question, all_faq)
    
    return {
        "generated_time": datetime.now().strftime("%Y-%m-%d"),
        "scenario": scenario,
        "platform": platform,
        
        "faq_count": len(all_faq),
        "faqs": all_faq,
        
        "templates": templates,
        
        "workflow": workflow,
        
        "user_question": user_question,
        "generated_answer": generated_answer,
        
        "suggestions": [
            "定期更新FAQ，添加新问题",
            "重点关注投诉类问题的处理时效",
            "复杂问题及时升级处理",
            "处理完成后进行满意度回访"
        ]
    }


def review_management(
    店铺类型: str,
    具体差评内容: str,
    店铺名称: str = ""
) -> Dict[str, Any]:
    """
    口碑运营 - 差评回复生成器
    
    根据用户输入的具体差评内容，生成针对性的三段式回复
    
    Args:
        店铺类型: 如"火锅店"、"奶茶店"、"川菜馆"
        具体差评内容: 用户在大众点评/美团等平台发布的差评原文
        店铺名称: 店铺名称（可选）
    
    Returns:
        针对差评内容生成的三段式回复（道歉+补偿+引导）
    """
    if not 具体差评内容 or not 具体差评内容.strip():
        return {
            "error": "请提供具体的差评内容",
            "example": "例如：等了1个小时才上菜，味道也不行，不会再来了"
        }
    
    # 分析差评类型和关键词
    analysis = _analyze_review(具体差评内容, 店铺类型)
    
    # 生成三段式回复
    reply = _generate_review_reply(店铺类型, 具体差评内容, analysis, 店铺名称)
    
    return {
        "generated_time": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "店铺类型": 店铺类型,
        "店铺名称": 店铺名称,
        
        "原始差评": 具体差评内容,
        
        "差评分析": {
            "主要问题": analysis["main_issue"],
            "问题类型": analysis["issue_type"],
            "严重程度": analysis["severity"],
            "关键词": analysis["keywords"]
        },
        
        "回复内容": reply,
        
        "回复说明": {
            "结构": "道歉+补偿+引导",
            "字数": f"{len(reply['full_reply'])}字",
            "适用平台": ["大众点评", "美团", "小红书"]
        }
    }


def _analyze_review(review_text: str, store_type: str) -> Dict[str, Any]:
    """分析差评内容"""
    review_lower = review_text.lower()
    keywords_found = []
    issue_type = "服务态度"
    severity = "medium"
    main_issue = "服务问题"
    
    # 定义问题类型和关键词映射
    issue_mappings = [
        {
            "type": "等位太久",
            "keywords": ["等", "排队", "久", "半小时", "一小时", "浪费时间", "不耐烦"],
            "severity": "medium",
            "main_issue": "等位时间过长"
        },
        {
            "type": "服务态度差",
            "keywords": ["态度", "凶", "脸色", "爱答不理", "不耐烦", "翻白眼", "服务差", "冷漠"],
            "severity": "high",
            "main_issue": "服务态度问题"
        },
        {
            "type": "菜品问题",
            "keywords": ["不好吃", "难吃", "味道差", "不新鲜", "冷了", "咸", "淡", "腥"],
            "severity": "medium",
            "main_issue": "菜品质量问题"
        },
        {
            "type": "上菜慢",
            "keywords": ["慢", "等", "半小时", "一小时", "催", "上菜", "等很久"],
            "severity": "medium",
            "main_issue": "上菜速度慢"
        },
        {
            "type": "分量不足",
            "keywords": ["少", "分量", "小", "不够", "少得可怜", "坑"],
            "severity": "low",
            "main_issue": "分量问题"
        },
        {
            "type": "环境问题",
            "keywords": ["脏", "乱", "吵", "油烟", "味道大", "不干净", "异味"],
            "severity": "medium",
            "main_issue": "环境卫生问题"
        },
        {
            "type": "异物问题",
            "keywords": ["虫", "苍蝇", "头发", "异物", "钢丝", "塑料", "发现"],
            "severity": "critical",
            "main_issue": "食品安全问题"
        },
        {
            "type": "性价比低",
            "keywords": ["贵", "不值", "坑", "性价比", "不值得", "贵了"],
            "severity": "low",
            "main_issue": "性价比问题"
        },
        {
            "type": "投诉无果",
            "keywords": ["投诉", "没人管", "不理", "反馈", "没人处理"],
            "severity": "high",
            "main_issue": "投诉处理不当"
        }
    ]
    
    # 匹配问题类型
    for mapping in issue_mappings:
        for keyword in mapping["keywords"]:
            if keyword in review_lower:
                keywords_found.append(keyword)
                if mapping["severity"] in ["critical", "high"]:
                    issue_type = mapping["type"]
                    severity = mapping["severity"]
                    main_issue = mapping["main_issue"]
                    break
        if severity == "critical":
            break
    
    # 如果没有匹配到具体问题，使用默认分析
    if not keywords_found:
        issue_type = "综合问题"
        severity = "medium"
        main_issue = "用户体验不佳"
        keywords_found = ["综合反馈"]
    
    # 提取具体数字（等位时间、菜品数量等）
    numbers = re.findall(r'\d+', review_text)
    
    return {
        "main_issue": main_issue,
        "issue_type": issue_type,
        "severity": severity,
        "keywords": list(set(keywords_found)),
        "mentioned_numbers": numbers
    }


def _generate_review_reply(store_type: str, review_text: str, analysis: Dict, store_name: str) -> Dict[str, str]:
    """生成差评回复"""
    main_issue = analysis["main_issue"]
    issue_type = analysis["issue_type"]
    severity = analysis["severity"]
    
    # 店铺类型对应的特色
    store_features = {
        "火锅店": {"dish": "火锅", "feature": "热闹氛围"},
        "奶茶店": {"dish": "饮品", "feature": "清凉享受"},
        "川菜馆": {"dish": "菜品", "feature": "川味美食"},
        "湘菜馆": {"dish": "湘菜", "feature": "正宗辣味"},
        "烧烤店": {"dish": "烧烤", "feature": "烟火气"},
        "快餐店": {"dish": "餐品", "feature": "快捷服务"},
        "烤肉店": {"dish": "烤肉", "feature": "滋滋美味"},
        "面馆": {"dish": "面食", "feature": "地道口味"},
    }
    
    store_info = store_features.get(store_type, {"dish": "菜品", "feature": "美食"})
    brand_name = store_name or "[品牌名称]"
    
    # ============ 第一段：真诚道歉 ============
    apology_templates = {
        "等位时间过长": f"亲爱的顾客您好，感谢您的反馈。对于您在{brand_name}等位时间过长的问题，我们深感抱歉！🙏 让您等待这么久是我们的失误。",
        "服务态度问题": f"亲爱的顾客您好，感谢您的反馈。看到您描述的服务问题，我们非常痛心😢 这完全不符合我们的服务标准，让您受委屈了，诚挚地向您道歉！",
        "菜品质量问题": f"亲爱的顾客您好，感谢您的反馈。对于您提到的菜品问题，我们深表歉意。🥺 您的批评是我们进步的动力。",
        "上菜速度慢": f"亲爱的顾客您好，感谢您的反馈。等待上菜的过程让您久等了，我们非常抱歉！⏰ 我们会优化出餐流程。",
        "分量问题": f"亲爱的顾客您好，感谢您的反馈。对于分量让您不满意的问题，我们诚恳道歉🙏 我们会确保每份出品达标。",
        "环境卫生问题": f"亲爱的顾客您好，感谢您的反馈。环境卫生是餐饮的底线，您的反馈让我们警醒，我们深表歉意！",
        "食品安全问题": f"亲爱的顾客您好，感谢您的反馈。发现餐品异常是非常严重的问题，我们向您郑重道歉！😔 这完全不应该发生，我们正在彻查原因。",
        "性价比问题": f"亲爱的顾客您好，感谢您的反馈。您的用餐体验没有达到预期，我们深感抱歉🙏 我们会重新审视定价策略。",
        "投诉处理不当": f"亲爱的顾客您好，感谢您的反馈。没有及时处理您的问题，这是我们的失职，诚挚地向您道歉！",
        "用户体验不佳": f"亲爱的顾客您好，感谢您的反馈。很抱歉您的用餐体验没有达到预期，我们一定认真反思和改进！"
    }
    
    apology = apology_templates.get(main_issue, apology_templates["用户体验不佳"])
    
    # ============ 第二段：补偿方案 ============
    compensation_templates = {
        "critical": {
            "template": "针对这次问题，我们郑重承诺：1️⃣ 全额退款或免单处理 2️⃣ 报销您的医疗检查费用 3️⃣ 赠送[200-500元]代金券作为补偿 4️⃣ 门店全员食品安全再培训。请您保留好消费凭证联系我们处理。",
            "emoji": "🙏"
        },
        "high": {
            "template": "为了让您重新信任我们，特别为您准备：1️⃣ 本次消费免单/半价优惠 2️⃣ [50-100元]现金券下次使用 3️⃣ 专人跟进服务。相信我们一定会让您满意！",
            "emoji": "💝"
        },
        "medium": {
            "template": "感谢您的理解与支持，我们将赠送：1️⃣ [招牌{}/招牌菜]一份 2️⃣ [20-50元]优惠券下次使用 3️⃣ 优先接待服务。期待您的再次光临！",
            "emoji": "🎁"
        },
        "low": {
            "template": "感谢您的宝贵意见，小小心意请收下：[10-20元]优惠券一张，下次到店使用即可抵扣。您的反馈是我们进步的动力！",
            "emoji": "🍀"
        }
    }
    
    comp = compensation_templates.get(severity, compensation_templates["medium"])
    
    # 根据店铺类型定制补偿
    if "template" in comp and "{}" in comp["template"]:
        comp["template"] = comp["template"].format(store_info["dish"])
    
    compensation = comp["template"]
    
    # ============ 第三段：引导来店 ============
    guide_templates = {
        "等位时间过长": f"目前我们已优化了等位管理，增设了等候区座椅和茶水服务，并实行预约制。建议您下次提前通过[小程序/电话]预约，避开高峰时段，享受更好的用餐体验~",
        "服务态度问题": f"我们已经对相关员工进行了严肃处理和再培训，建立了服务质量监督机制。欢迎您下次莅临体验改变，我们也期待为您提供更好的服务！",
        "菜品质量问题": f"我们已经将您的反馈转达厨房团队进行了专项整改。如果您愿意给我们一次机会，推荐您下次尝试我们的招牌{store_info['dish']}，相信会为您带来满意的味觉体验！",
        "上菜速度慢": f"我们已优化了后厨流程，增加了备菜提前量。感谢您的耐心等待，欢迎下次体验我们的改进成果！",
        "分量问题": f"感谢您的反馈，我们已调整出餐标准，确保分量充足。推荐您下次点餐时参考服务员的专业建议！",
        "环境卫生问题": f"食品安全和卫生是我们的重中之重！我们已进行全店彻底清洁消毒，增加了清洁频次，欢迎您下次监督！",
        "食品安全问题": f"食品安全是不可逾越的红线！我们正在进行全链条彻查，并将结果公示。期待您再次监督，我们将用行动证明改变！",
        "性价比问题": f"感谢您的反馈，我们推出了多款高性价比套餐，兼顾口味和价格。欢迎您下次体验新菜单！",
        "投诉处理不当": f"我们已对客服流程进行了整改，建立了24小时快速响应机制。期待您再次给我们服务的机会！",
        "用户体验不佳": f"感谢您的每一次反馈！{brand_name}一直在努力做得更好，期待您的下次光临，共同见证我们的成长~"
    }
    
    guide = guide_templates.get(main_issue, guide_templates["用户体验不佳"])
    
    # 组装完整回复
    full_reply = f"{apology}\n\n{compensation}\n\n{guide}"
    
    return {
        "第一段_道歉": apology,
        "第二段_补偿": compensation,
        "第三段_引导": guide,
        "full_reply": full_reply,
        "recommended_emoji": comp["emoji"]
    }


def lifecycle_management(
    店铺类型: str,
    会员数据: str,
    分析类型: str = "all"
) -> Dict[str, Any]:
    """
    生命周期管理
    
    根据会员数据生成流失预警和复购激励方案
    
    Args:
        店铺类型: 如"火锅店"、"奶茶店"
        会员数据: 会员消费记录，如"张三，近3个月消费5次，最后消费是45天前"
        分析类型: all/loss_warning/repurchase
    
    Returns:
        流失预警名单、复购激励方案
    """
    if not 会员数据 or not 会员数据.strip():
        return {
            "error": "请提供会员数据",
            "example": "张三，2024-1-1消费150元，2024-2-15消费200元，已60天未消费"
        }
    
    return {
        "generated_time": datetime.now().strftime("%Y-%m-%d"),
        "店铺类型": 店铺类型,
        "原始数据": 会员数据,
        
        "分析结果": {
            "流失风险": "高" if "60" in 会员数据 or "90" in 会员数据 else ("中" if "45" in 会员数据 else "低"),
            "最近消费": "45天前" if "45" in 会员数据 else "未知",
            "累计消费": "分析中..."
        },
        
        "流失预警": {
            "风险等级": "高危" if "60" in 会员数据 else "中危",
            "建议动作": "立即触达，赠送专属优惠券",
            "推送话术": "亲爱的会员，您已有一段时间没来了，我们很想念您！特意为您准备了一张50元无门槛券，期待您的下次光临~"
        },
        
        "复购激励": {
            "优惠券": "50元无门槛券",
            "有效期": "30天",
            "叠加权益": "到店送招牌菜一份"
        },
        
        "推送时机": "今天发送效果最佳，建议配合短信+企微"
    }


# 辅助函数
def _generate_answer(question: str, faq_list: List[Dict]) -> str:
    """根据用户问题生成回答"""
    question_lower = question.lower()
    
    # 简单的关键词匹配
    for faq in faq_list:
        q_keywords = faq["q"].lower()
        if any(kw in question_lower for kw in q_keywords):
            return faq["answer"]
    
    # 默认回复
    return "您好，关于您的问题，建议您联系门店客服获取更详细的帮助。"
