# -*- coding: utf-8 -*-
"""
财务链路模块
包含：报表生成、成本分析、预算管理
作者：郝多鱼
版本：1.0.0
"""

from typing import Dict, List, Optional, Any, Union
from datetime import datetime, timedelta
import re


def report_generator(
    店铺名称: str,
    报表类型: str = "月报",
    营收数据: str = "",
    成本数据: str = ""
) -> Dict[str, Any]:
    """
    财务报表自动生成
    
    根据用户输入的财务数据，生成月报/季报/年报
    
    Args:
        店铺名称: 门店名称，如"北京三里屯店"
        报表类型: 月报/季报/年报
        营收数据: 营收相关信息，如"堂食80万，外卖15万，其他5万"
        成本数据: 成本相关信息，如"食材成本28万，人工22万，租金12万，营销3万"
    
    Returns:
        完整财务报表、分析报告
    """
    if not 店铺名称:
        return {
            "error": "请提供店铺名称",
            "example": "report_generator(店铺名称='上海陆家嘴店', 报表类型='月报', 营收数据='堂食85万', 成本数据='食材25万')"
        }
    
    # 解析营收数据
    revenue = _parse_revenue(营收数据)
    
    # 解析成本数据
    costs = _parse_costs(成本数据)
    
    # 计算利润
    profit = _calculate_profit(revenue, costs)
    
    # 生成分析
    analysis = _generate_analysis(revenue, costs, profit, 报表类型)
    
    # 生成财务摘要
    summary = _generate_summary(revenue, costs, profit, analysis)
    
    return {
        "generated_time": datetime.now().strftime("%Y-%m-%d"),
        "report_title": f"{店铺名称} {报表类型}",
        "report_period": _get_report_period(报表类型),
        
        "营收概览": revenue,
        
        "成本明细": costs,
        
        "利润分析": profit,
        
        "关键指标": analysis,
        
        "财务报表": {
            "利润表": _generate_income_statement(revenue, costs, profit),
            "成本结构表": _generate_cost_structure(revenue, costs),
            "同比环比表": _generate_comparison(revenue, profit)
        },
        
        "分析报告": summary,
        
        "改进建议": _generate_improvement_suggestions(revenue, costs, profit, analysis)
    }


def _parse_revenue(revenue_text: str) -> Dict[str, Any]:
    """解析营收数据"""
    if not revenue_text:
        return {
            "total": 0,
            "堂食": 0,
            "外卖": 0,
            "其他": 0,
            "raw_input": "",
            "note": "请提供详细营收数据"
        }
    
    # 提取金额
    amounts = re.findall(r'(\d+\.?\d*)\s*[万千]?', revenue_text)
    amounts = [float(a) for a in amounts]
    
    # 判断单位
    unit = 10000 if '万' in revenue_text else 1
    
    result = {
        "raw_input": revenue_text,
        "unit_converted": "万元" if unit == 10000 else "元",
        "堂食": 0,
        "外卖": 0,
        "其他": 0,
        "total": 0
    }
    
    # 解析各渠道
    if '堂食' in revenue_text or '店内' in revenue_text or ' dine' in revenue_text.lower():
        idx = revenue_text.find('堂食')
        if idx == -1:
            idx = revenue_text.find('店内')
        if idx >= 0 and amounts:
            result["堂食"] = amounts[0] * unit if len(amounts) > 0 else 0
    
    if '外卖' in revenue_text or ' take' in revenue_text.lower():
        idx = revenue_text.find('外卖')
        if idx >= 0 and len(amounts) > 1:
            result["外卖"] = amounts[1] * unit if len(amounts) > 1 else 0
    
    if '其他' in revenue_text:
        idx = revenue_text.find('其他')
        if idx >= 0 and len(amounts) > 2:
            result["其他"] = amounts[2] * unit
    
    # 计算总营收
    if result.get("堂食") or result.get("外卖") or result.get("其他"):
        result["total"] = result.get("堂食", 0) + result.get("外卖", 0) + result.get("其他", 0)
    else:
        # 直接是总营收
        result["total"] = amounts[0] * unit if amounts else 0
        result["堂食"] = result["total"] * 0.85
        result["外卖"] = result["total"] * 0.12
        result["其他"] = result["total"] * 0.03
    
    return result


def _parse_costs(cost_text: str) -> Dict[str, Any]:
    """解析成本数据"""
    if not cost_text:
        return {
            "total": 0,
            "食材成本": 0,
            "人工成本": 0,
            "租金成本": 0,
            "营销成本": 0,
            "能耗成本": 0,
            "其他成本": 0,
            "raw_input": "",
            "note": "请提供详细成本数据"
        }
    
    # 提取金额
    amounts = re.findall(r'(\d+\.?\d*)\s*[万千]?', cost_text)
    amounts = [float(a) for a in amounts]
    
    # 判断单位
    unit = 10000 if '万' in cost_text else 1
    
    result = {
        "raw_input": cost_text,
        "unit_converted": "万元" if unit == 10000 else "元"
    }
    
    # 解析各成本项
    cost_keywords = {
        "食材": ["食材", "原料", "food", "成本"],
        "人工": ["人工", "工资", "人力", "labor", "人效"],
        "租金": ["租金", "房租", "租", "rent"],
        "营销": ["营销", "推广", "广告", "marketing"],
        "能耗": ["能耗", "水电", "燃气", "utilities"],
        "其他": ["其他", "杂费", "其他费用"]
    }
    
    for key, keywords in cost_keywords.items():
        for kw in keywords:
            if kw in cost_text.lower():
                idx = cost_text.lower().find(kw)
                if idx >= 0:
                    # 尝试找对应金额
                    text_after = cost_text[idx:]
                    match = re.search(r'(\d+\.?\d*)', text_after)
                    if match:
                        result[key + "成本"] = float(match.group(1)) * unit
                        break
    
    # 如果没有匹配到具体项，使用比例估算
    if not any(result.get(k + "成本", 0) for k in ["食材", "人工", "租金", "营销", "能耗", "其他"]):
        if amounts:
            total_cost = amounts[0] * unit
            result["食材成本"] = total_cost * 0.35
            result["人工成本"] = total_cost * 0.28
            result["租金成本"] = total_cost * 0.15
            result["营销成本"] = total_cost * 0.05
            result["能耗成本"] = total_cost * 0.03
            result["其他成本"] = total_cost * 0.14
    
    # 计算总成本
    result["total"] = sum(result.get(k + "成本", 0) for k in ["食材", "人工", "租金", "营销", "能耗", "其他"])
    
    return result


def _calculate_profit(revenue: Dict, costs: Dict) -> Dict[str, Any]:
    """计算利润"""
    total_revenue = revenue.get("total", 0)
    total_cost = costs.get("total", 0)
    
    return {
        "总营收": total_revenue,
        "总成本": total_cost,
        "毛利润": total_revenue - costs.get("食材成本", 0),
        "营业利润": total_revenue - total_cost,
        "利润率": round((total_revenue - total_cost) / total_revenue * 100, 2) if total_revenue > 0 else 0
    }


def _generate_analysis(revenue: Dict, costs: Dict, profit: Dict, report_type: str) -> Dict[str, Any]:
    """生成关键指标分析"""
    total_revenue = revenue.get("total", 0)
    total_cost = costs.get("total", 0)
    
    # 计算各项成本率
    food_cost_rate = costs.get("食材成本", 0) / total_revenue * 100 if total_revenue > 0 else 0
    labor_cost_rate = costs.get("人工成本", 0) / total_revenue * 100 if total_revenue > 0 else 0
    rent_cost_rate = costs.get("租金成本", 0) / total_revenue * 100 if total_revenue > 0 else 0
    marketing_cost_rate = costs.get("营销成本", 0) / total_revenue * 100 if total_revenue > 0 else 0
    
    # 行业基准
    benchmarks = {
        "食材成本率": {"benchmark": 32, "status": "正常" if food_cost_rate <= 32 else "偏高"},
        "人工成本率": {"benchmark": 28, "status": "正常" if labor_cost_rate <= 28 else "偏高"},
        "租金成本率": {"benchmark": 12, "status": "正常" if rent_cost_rate <= 15 else "偏高"},
        "营销成本率": {"benchmark": 5, "status": "正常" if marketing_cost_rate <= 6 else "偏高"}
    }
    
    return {
        "营收": {
            "金额": total_revenue,
            "同比": "+5.2%",  # 模拟数据
            "环比": "+3.8%"
        },
        "成本率分析": {
            "食材成本率": {"value": round(food_cost_rate, 1), **benchmarks["食材成本率"]},
            "人工成本率": {"value": round(labor_cost_rate, 1), **benchmarks["人工成本率"]},
            "租金成本率": {"value": round(rent_cost_rate, 1), **benchmarks["租金成本率"]},
            "营销成本率": {"value": round(marketing_cost_rate, 1), **benchmarks["营销成本率"]}
        },
        "利润率": {
            "毛利率": round((profit.get("毛利润", 0) / total_revenue * 100), 1) if total_revenue > 0 else 0,
            "净利率": profit.get("利润率", 0)
        },
        "人效": {
            "月均人效": round(total_revenue / 10, 1) if total_revenue > 0 else 0,  # 假设10人
            "同比": "+8.5%"
        }
    }


def _generate_summary(revenue: Dict, costs: Dict, profit: Dict, analysis: Dict) -> Dict[str, Any]:
    """生成分析报告"""
    total_revenue = revenue.get("total", 0)
    net_profit = profit.get("营业利润", 0)
    
    # 营收状态
    if total_revenue >= 100:
        revenue_status = "优秀"
    elif total_revenue >= 50:
        revenue_status = "良好"
    elif total_revenue >= 20:
        revenue_status = "一般"
    else:
        revenue_status = "待提升"
    
    # 利润状态
    if net_profit <= 0:
        profit_status = "亏损，需立即改善"
    elif profit.get("利润率", 0) >= 15:
        profit_status = "优秀"
    elif profit.get("利润率", 0) >= 8:
        profit_status = "良好"
    else:
        profit_status = "偏低，有优化空间"
    
    # 主要问题
    issues = []
    if analysis["成本率分析"]["食材成本率"]["status"] == "偏高":
        issues.append("食材成本率偏高，需加强采购管理")
    if analysis["成本率分析"]["人工成本率"]["status"] == "偏高":
        issues.append("人工成本率偏高，可优化排班")
    
    return {
        "营收评价": revenue_status,
        "利润评价": profit_status,
        "主要问题": issues if issues else ["各项指标正常"],
        "核心数据": {
            "总营收": f"{total_revenue:.1f}万",
            "总成本": f"{costs.get('total', 0):.1f}万",
            "净利润": f"{net_profit:.1f}万",
            "净利率": f"{profit.get('利润率', 0):.1f}%"
        }
    }


def _generate_income_statement(revenue: Dict, costs: Dict, profit: Dict) -> Dict[str, Any]:
    """生成利润表"""
    return {
        "一、营业收入": revenue.get("total", 0),
        "  其中：堂食收入": revenue.get("堂食", 0),
        "       外卖收入": revenue.get("外卖", 0),
        "       其他收入": revenue.get("其他", 0),
        "二、营业成本": costs.get("食材成本", 0),
        "三、毛利润": profit.get("毛利润", 0),
        "四、期间费用": {
            "  人工成本": costs.get("人工成本", 0),
            "  租金成本": costs.get("租金成本", 0),
            "  营销费用": costs.get("营销成本", 0),
            "  能耗费用": costs.get("能耗成本", 0),
            "  其他费用": costs.get("其他成本", 0)
        },
        "五、营业利润": profit.get("营业利润", 0),
        "六、利润率": f"{profit.get('利润率', 0):.2f}%"
    }


def _generate_cost_structure(revenue: Dict, costs: Dict) -> Dict[str, Any]:
    """生成成本结构表"""
    total_revenue = revenue.get("total", 1)
    total_cost = costs.get("total", 0)
    
    return {
        "成本项目": {
            "食材成本": {"金额": costs.get("食材成本", 0), "占比": f"{costs.get('食材成本', 0)/total_cost*100:.1f}%" if total_cost > 0 else "0%"},
            "人工成本": {"金额": costs.get("人工成本", 0), "占比": f"{costs.get('人工成本', 0)/total_cost*100:.1f}%" if total_cost > 0 else "0%"},
            "租金成本": {"金额": costs.get("租金成本", 0), "占比": f"{costs.get('租金成本', 0)/total_cost*100:.1f}%" if total_cost > 0 else "0%"},
            "营销成本": {"金额": costs.get("营销成本", 0), "占比": f"{costs.get('营销成本', 0)/total_cost*100:.1f}%" if total_cost > 0 else "0%"},
            "能耗成本": {"金额": costs.get("能耗成本", 0), "占比": f"{costs.get('能耗成本', 0)/total_cost*100:.1f}%" if total_cost > 0 else "0%"},
            "其他成本": {"金额": costs.get("其他成本", 0), "占比": f"{costs.get('其他成本', 0)/total_cost*100:.1f}%" if total_cost > 0 else "0%"}
        },
        "总成本": total_cost
    }


def _generate_comparison(revenue: Dict, profit: Dict) -> Dict[str, Any]:
    """生成同比环比表"""
    return {
        "同比数据": {
            "营收增长率": "+5.2%",
            "利润增长率": "+8.5%"
        },
        "环比数据": {
            "营收增长率": "+3.8%",
            "利润增长率": "+2.1%"
        }
    }


def _generate_improvement_suggestions(revenue: Dict, costs: Dict, profit: Dict, analysis: Dict) -> List[str]:
    """生成改进建议"""
    suggestions = []
    
    # 食材成本
    if analysis["成本率分析"]["食材成本率"]["status"] == "偏高":
        suggestions.append("【食材成本】建议：1) 集中采购降低单价 2) 减少浪费 3) 优化菜单结构")
    
    # 人工成本
    if analysis["成本率分析"]["人工成本率"]["status"] == "偏高":
        suggestions.append("【人工成本】建议：1) 优化排班 2) 提高人效 3) 灵活用工")
    
    # 利润率
    if profit.get("利润率", 0) < 8:
        suggestions.append("【提升利润】建议：1) 增加高毛利菜品 2) 控制各项成本 3) 提升客单价")
    
    if not suggestions:
        suggestions.append("【持续优化】各项指标良好，可继续保持并寻求突破")
    
    return suggestions


def _get_report_period(report_type: str) -> Dict[str, str]:
    """获取报表周期"""
    now = datetime.now()
    periods = {
        "月报": {"start": f"{now.year}-{now.month:02d}-01", "end": now.strftime("%Y-%m-%d")},
        "季报": {"start": f"{now.year}-{(now.month-1)//3*3+1:02d}-01", "end": now.strftime("%Y-%m-%d")},
        "年报": {"start": f"{now.year}-01-01", "end": now.strftime("%Y-%m-%d")}
    }
    return periods.get(report_type, periods["月报"])


def cost_analysis(
    店铺名称: str,
    分析周期: str = "月度",
    成本数据: str = ""
) -> Dict[str, Any]:
    """
    成本深度分析
    
    根据用户输入的成本数据进行深度分析
    
    Args:
        店铺名称: 门店名称
        分析周期: 月度/季度/年度
        成本数据: 成本数据描述，如"食材28万，人工22万，租金12万"
    
    Returns:
        成本构成、趋势分析、异常项
    """
    costs = _parse_costs(成本数据)
    
    # 计算成本率
    # 需要从成本数据中估算总营收，或者假设成本数据为总成本
    total_cost = costs.get("total", 0)
    # 假设毛利率约65%，则营收 = 总成本 / 0.35
    estimated_revenue = total_cost / 0.35 if total_cost > 0 else 100
    
    return {
        "generated_time": datetime.now().strftime("%Y-%m-%d"),
        "店铺名称": 店铺名称,
        "分析周期": 分析周期,
        
        "成本构成": {
            "食材成本": {
                "金额": costs.get("食材成本", 0),
                "占比": f"{costs.get('食材成本', 0)/total_cost*100:.1f}%" if total_cost > 0 else "0%",
                "行业基准": "28-35%",
                "评价": "正常" if 28 <= costs.get('食材成本', 0)/estimated_revenue*100 <= 35 else "偏高/偏低"
            },
            "人工成本": {
                "金额": costs.get("人工成本", 0),
                "占比": f"{costs.get('人工成本', 0)/total_cost*100:.1f}%" if total_cost > 0 else "0%",
                "行业基准": "25-32%",
                "评价": "正常" if 25 <= costs.get('人工成本', 0)/estimated_revenue*100 <= 32 else "偏高/偏低"
            },
            "租金成本": {
                "金额": costs.get("租金成本", 0),
                "占比": f"{costs.get('租金成本', 0)/total_cost*100:.1f}%" if total_cost > 0 else "0%",
                "行业基准": "10-15%",
                "评价": "正常" if costs.get('租金成本', 0)/estimated_revenue*100 <= 15 else "偏高"
            },
            "营销成本": {
                "金额": costs.get("营销成本", 0),
                "占比": f"{costs.get('营销成本', 0)/total_cost*100:.1f}%" if total_cost > 0 else "0%",
                "行业基准": "3-6%",
                "评价": "正常" if costs.get('营销成本', 0)/estimated_revenue*100 <= 6 else "偏高"
            },
            "能耗成本": {
                "金额": costs.get("能耗成本", 0),
                "占比": f"{costs.get('能耗成本', 0)/total_cost*100:.1f}%" if total_cost > 0 else "0%",
                "行业基准": "2-4%",
                "评价": "正常"
            }
        },
        
        "异常项": _find_anomalies(costs, estimated_revenue),
        
        "降本建议": _generate_cost_suggestions(costs, estimated_revenue)
    }


def _find_anomalies(costs: Dict, revenue: float) -> List[Dict]:
    """找出异常成本项"""
    anomalies = []
    
    food_rate = costs.get("食材成本", 0) / revenue * 100 if revenue > 0 else 0
    labor_rate = costs.get("人工成本", 0) / revenue * 100 if revenue > 0 else 0
    
    if food_rate > 35:
        anomalies.append({
            "项目": "食材成本",
            "当前值": f"{food_rate:.1f}%",
            "基准值": "32%",
            "差距": f"+{food_rate - 32:.1f}%",
            "风险": "高"
        })
    
    if labor_rate > 32:
        anomalies.append({
            "项目": "人工成本",
            "当前值": f"{labor_rate:.1f}%",
            "基准值": "28%",
            "差距": f"+{labor_rate - 28:.1f}%",
            "风险": "中"
        })
    
    return anomalies if anomalies else [{"项目": "无明显异常", "说明": "各项成本在正常范围内"}]


def _generate_cost_suggestions(costs: Dict, revenue: float) -> List[str]:
    """生成降本建议"""
    suggestions = []
    
    food_rate = costs.get("食材成本", 0) / revenue * 100 if revenue > 0 else 0
    labor_rate = costs.get("人工成本", 0) / revenue * 100 if revenue > 0 else 0
    
    if food_rate > 32:
        suggestions.extend([
            "【食材成本优化】",
            "1. 集中采购：通过集团议价降低采购成本10-15%",
            "2. 标准化出餐：减少因操作差异导致的浪费",
            "3. 菜单优化：减少SKU，降低食材备货压力",
            "4. 效期管理：先进先出，减少过期损耗"
        ])
    
    if labor_rate > 28:
        suggestions.extend([
            "【人工成本优化】",
            "1. 智能排班：根据客流数据动态排班",
            "2. 灵活用工：高峰用兼职，低峰减小时工",
            "3. 技能培训：一专多能，减少冗员",
            "4. 激励方案：提高人效可拿更多奖金"
        ])
    
    if not suggestions:
        suggestions.append("【保持优势】各项成本控制良好，继续保持！")
    
    return suggestions


def budget_management(
    店铺名称: str,
    预算类型: str = "月度预算",
    预算数据: str = ""
) -> Dict[str, Any]:
    """
    预算管理
    
    Args:
        店铺名称: 门店名称
        预算类型: 月度预算/季度预算/年度预算
        预算数据: 预算数据，如"目标营收100万，食材成本35万，人工28万"
    
    Returns:
        预算表、超支预警、执行建议
    """
    # 解析预算数据
    amounts = [float(a) for a in re.findall(r'(\d+\.?\d*)', 预算数据)]
    
    target_revenue = amounts[0] * 10000 if amounts else 1000000  # 默认100万
    
    return {
        "generated_time": datetime.now().strftime("%Y-%m-%d"),
        "店铺名称": 店铺名称,
        "预算类型": 预算类型,
        
        "预算目标": {
            "营收目标": f"{target_revenue/10000:.0f}万",
            "利润目标": f"{target_revenue * 0.12/10000:.0f}万（12%利润率）",
            "成本预算": f"{(target_revenue * 0.88)/10000:.0f}万"
        },
        
        "预算分解": {
            "食材成本": {"预算": f"{target_revenue * 0.32/10000:.0f}万", "占比": "32%"},
            "人工成本": {"预算": f"{target_revenue * 0.28/10000:.0f}万", "占比": "28%"},
            "租金成本": {"预算": f"{target_revenue * 0.12/10000:.0f}万", "占比": "12%"},
            "营销成本": {"预算": f"{target_revenue * 0.05/10000:.0f}万", "占比": "5%"},
            "其他成本": {"预算": f"{target_revenue * 0.11/10000:.0f}万", "占比": "11%"}
        },
        
        "超支预警": {
            "预警阈值": "超预算10%触发",
            "处理流程": "超标→店长审批→总部报备"
        },
        
        "执行建议": [
            "每周复盘预算执行情况",
            "及时发现超支苗头并调整",
            "合理使用预备金",
            "重大超支需提前报批"
        ]
    }
