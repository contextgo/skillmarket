# -*- coding: utf-8 -*-
"""
餐饮小助手 - 核心模块导出
作者：郝多鱼
版本：1.1.0
"""

from .strategy import (
    strategic_decision_board,
    future_insights,
    profit_loss_prediction,
    market_research
)

from .marketing import (
    location_analysis,
    marketing_calendar,
    activity_planning,
    content_factory,
    private_domain,
    public_sentiment,
    brand_strategy
)

from .sales import (
    multi_store_analysis,
    kpi_warning,
    smart_inspection,
    smart_scheduling
)

from .supply import (
    smart_ordering,
    inventory_warning,
    supplier_evaluation,
    loss_analysis
)

from .product import (
    dish_development,
    recipe_library
)

from .customer import (
    smart_customer_service,
    review_management,
    lifecycle_management
)

from .hr import (
    recruiter_helper,
    training_system,
    performance_appraisal,
    turnover_warning
)

from .finance import (
    report_generator,
    cost_analysis,
    budget_management
)

from .food_safety import (
    food_safety_inspection,
    compliance_documents
)

from .digital import (
    business_dashboard,
    system_integration
)

from .data_store import (
    record_business_data,
    get_store_summary,
    get_all_stores_overview,
    get_comprehensive_report,
    clear_store_data
)

__all__ = [
    # 战略链路
    'strategic_decision_board',
    'future_insights',
    'profit_loss_prediction',
    'market_research',
    # 营销链路
    'location_analysis',
    'marketing_calendar',
    'activity_planning',
    'content_factory',
    'private_domain',
    'public_sentiment',
    'brand_strategy',
    # 销售链路
    'multi_store_analysis',
    'kpi_warning',
    'smart_inspection',
    'smart_scheduling',
    # 供应链路
    'smart_ordering',
    'inventory_warning',
    'supplier_evaluation',
    'loss_analysis',
    # 产品链路
    'dish_development',
    'recipe_library',
    # 客户链路
    'smart_customer_service',
    'review_management',
    'lifecycle_management',
    # 人资链路
    'recruiter_helper',
    'training_system',
    'performance_appraisal',
    'turnover_warning',
    # 财务链路
    'report_generator',
    'cost_analysis',
    'budget_management',
    # 食安链路
    'food_safety_inspection',
    'compliance_documents',
    # 数据链路
    'business_dashboard',
    'system_integration',
    # 数据积累
    'record_business_data',
    'get_store_summary',
    'get_all_stores_overview',
    'get_comprehensive_report',
    'clear_store_data',
]
