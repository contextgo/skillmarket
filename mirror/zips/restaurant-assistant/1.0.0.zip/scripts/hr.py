# -*- coding: utf-8 -*-
"""
人资链路模块
包含：招聘助手、培训系统、绩效考核、离职预警
作者：郝多鱼
版本：1.0.0
"""

from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
import random


def recruiter_helper(
    岗位名称: str,
    店铺类型: str,
    薪资福利: str = ""
) -> Dict[str, Any]:
    """
    超级招聘助手
    
    根据岗位名称和店铺类型，生成完整的JD文档
    
    Args:
        岗位名称: 如"店长"、"服务员"、"厨师长"
        店铺类型: 如"火锅店"、"奶茶店"、"川菜馆"
        薪资福利: 薪资范围和福利待遇描述，如"6000-8000元，包吃住，节假日三薪"
    
    Returns:
        完整的JD文档、面试题库、考核标准
    """
    if not 岗位名称 or not 岗位名称.strip():
        return {
            "error": "请提供岗位名称",
            "example": "recruiter_helper(岗位名称='店长', 店铺类型='火锅店', 薪资福利='8000-12000元')"
        }
    
    # 解析薪资福利
    salary_info = _parse_salary(薪资福利)
    
    # 获取职位信息库
    position_data = _get_position_data(岗位名称, 店铺类型)
    
    # 生成完整JD
    jd = _generate_jd(岗位名称, 店铺类型, salary_info, position_data)
    
    # 生成面试题库
    interview_questions = _generate_interview_questions(岗位名称, 店铺类型)
    
    # 生成考核标准
    evaluation_form = _generate_evaluation_form(岗位名称, position_data)
    
    return {
        "generated_time": datetime.now().strftime("%Y-%m-%d"),
        "岗位名称": 岗位名称,
        "店铺类型": 店铺类型,
        
        "jd": jd,
        
        "面试题库": interview_questions,
        
        "考核标准": evaluation_form,
        
        "使用说明": {
            "发布渠道": ["BOSS直聘", "智联招聘", "58同城", "店内海报"],
            "注意事项": [
                "JD中的[ ]内容需替换为实际信息",
                "薪资要有竞争力，高于市场10-20%",
                "突出店铺优势和成长空间",
                "面试安排要有条理，提前准备"
            ]
        }
    }


def _parse_salary(salary_text: str) -> Dict[str, Any]:
    """解析薪资福利字符串"""
    if not salary_text:
        return {
            "range": "面议",
            "min": None,
            "max": None,
            "bonus": "绩效奖金",
            "benefits": ["包吃", "节日福利"]
        }
    
    # 提取薪资范围
    import re
    salary_range = re.findall(r'(\d+)[千万]?-?(\d+)?[千万]?', salary_text)
    
    result = {
        "raw": salary_text,
        "range": salary_text if len(salary_text) < 30 else salary_text[:30] + "...",
        "min": None,
        "max": None,
        "bonus": "绩效奖金",
        "benefits": []
    }
    
    if salary_range:
        first = salary_range[0]
        if len(first) >= 2:
            result["min"] = int(first[0])
            result["max"] = int(first[1]) if first[1] else int(first[0]) * 1.3
        elif len(first) == 1:
            result["min"] = int(first[0])
            result["max"] = int(first[0]) * 1.3
    
    # 提取福利
    benefit_keywords = ["包吃", "包住", "五险", "一金", "节假日", "年终奖", "带薪年假", "员工折扣", "晋升"]
    for keyword in benefit_keywords:
        if keyword in salary_text:
            result["benefits"].append(keyword)
    
    return result


def _get_position_data(position: str, store_type: str) -> Dict[str, Any]:
    """获取职位信息"""
    # 基础职位库
    base_positions = {
        "店长": {
            "responsibilities": [
                "负责门店日常运营管理，完成月度/年度经营目标",
                "团队建设与人才培养，制定排班表并进行考核",
                "客户服务与投诉处理，提升顾客满意度",
                "成本控制与安全管理，降低损耗率",
                "数据分析和报表汇报，落实公司政策"
            ],
            "requirements": [
                "3年以上餐饮管理经验，有连锁品牌经验优先",
                "具备良好的团队管理和沟通协调能力",
                "熟悉门店运营流程和食品安全规范",
                "抗压能力强，能适应倒班工作"
            ],
            "skills": ["领导力", "数据分析", "客户服务", "成本控制", "团队管理"],
            "interview_focus": ["管理经验", "业绩达成", "团队建设", "应变能力"]
        },
        "厨师长": {
            "responsibilities": [
                "负责厨房日常管理，确保菜品质量稳定",
                "菜品研发与创新，定期推出季节性新品",
                "成本核算与食材管理，控制食材损耗",
                "厨师团队培训与技术指导",
                "食品安全管理，落实食安规范"
            ],
            "requirements": [
                "5年以上后厨经验，精通川菜/湘菜/火锅等品类制作",
                "有团队管理经验和厨房成本控制能力",
                "持有健康证，熟悉食品安全法规",
                "能够独立完成特色菜品研发"
            ],
            "skills": ["烹饪技术", "菜品研发", "成本意识", "团队管理", "食品安全"],
            "interview_focus": ["专业技能", "研发能力", "管理经验", "食品安全"]
        },
        "服务员": {
            "responsibilities": [
                "顾客接待与服务，提供优质用餐体验",
                "点餐、下单操作，准确快速",
                "餐前准备与餐后收台，保持区域整洁",
                "维护门店形象，执行服务标准",
                "完成领导交办的其他任务"
            ],
            "requirements": [
                "18-35岁，身体健康，五官端正",
                "有服务意识，吃苦耐劳，服从管理",
                "有餐饮服务经验优先，无经验可培养",
                "能适应倒班和节假日上班"
            ],
            "skills": ["沟通能力", "服务意识", "团队协作", "抗压能力"],
            "interview_focus": ["服务意识", "态度端正", "团队融入", "稳定性"]
        },
        "收银员": {
            "responsibilities": [
                "日常收银结算，确保账务准确",
                "账务核对，日报表填写",
                "发票管理和顾客咨询解答",
                "会员卡办理和促销活动推广",
                "现金管理，备用金盘点"
            ],
            "requirements": [
                "18-40岁，会基本电脑操作",
                "细心负责，诚实守信",
                "有收银或财务工作经验优先",
                "能适应倒班工作"
            ],
            "skills": ["细心", "电脑操作", "沟通能力", "诚信", "数字敏感"],
            "interview_focus": ["细心程度", "诚信度", "服务态度", "稳定性"]
        },
        "后厨帮工": {
            "responsibilities": [
                "协助厨师长完成备菜、切配工作",
                "保持厨房区域卫生整洁",
                "食材清洗和初加工",
                "遵守厨房操作规范和安全规定",
                "完成厨师长交办的其他任务"
            ],
            "requirements": [
                "18-50岁，身体健康，能吃苦耐劳",
                "手脚麻利，有厨房工作经验优先",
                "服从工作安排，团结协作",
                "能适应高温工作环境"
            ],
            "skills": ["刀工基础", "卫生意识", "吃苦耐劳", "团队协作"],
            "interview_focus": ["身体状况", "吃苦精神", "稳定性", "学习意愿"]
        }
    }
    
    # 查找匹配职位
    position_key = position.strip()
    if position_key in base_positions:
        return base_positions[position_key]
    
    # 模糊匹配
    for key in base_positions:
        if key in position_key or position_key in key:
            return base_positions[key]
    
    # 默认返回服务员信息
    return base_positions["服务员"]


def _generate_jd(position: str, store_type: str, salary_info: Dict, position_data: Dict) -> Dict[str, Any]:
    """生成完整JD"""
    # 店铺类型对应的特色
    store_features = {
        "火锅店": {"feature": "热辣火锅文化", "atmosphere": "热闹非凡", "dish": "特色锅底"},
        "奶茶店": {"feature": "新式茶饮", "atmosphere": "时尚活力", "dish": "潮流饮品"},
        "川菜馆": {"feature": "正宗川味", "atmosphere": "地道风味", "dish": "经典川菜"},
        "湘菜馆": {"feature": "正宗湘辣", "atmosphere": "下饭天堂", "dish": "招牌湘菜"},
        "烧烤店": {"feature": "烟火烧烤", "atmosphere": "夜市氛围", "dish": "特色烤串"},
        "快餐店": {"feature": "快捷美味", "atmosphere": "高效便利", "dish": "主食套餐"},
        "烤肉店": {"feature": "滋滋美味", "atmosphere": "温馨聚餐", "dish": "精选烤肉"},
        "面馆": {"feature": "地道面食", "atmosphere": "家常风味", "dish": "手工面食"},
    }
    
    store_info = store_features.get(store_type, {"feature": "特色美食", "atmosphere": "舒适", "dish": "招牌菜品"})
    
    # 薪资范围
    if salary_info["min"] and salary_info["max"]:
        if salary_info["min"] >= 10000:
            salary_range = f"{salary_info['min']//10000}-{salary_info['max']//10000}万"
        else:
            salary_range = f"{salary_info['min']//1000}-{salary_info['max']//1000}K"
    else:
        salary_range = salary_info.get("range", "面议")
    
    return {
        "基本信息": {
            "岗位名称": f"[品牌名称] {position}热招",
            "所属部门": "门店运营部",
            "工作地点": "[具体地址]",
            "薪资待遇": f"{salary_range}/月",
            "发布来源": "餐饮小助手"
        },
        
        "岗位职责": [
            f"负责{store_type}的日常运营管理",
            *position_data["responsibilities"]
        ],
        
        "任职要求": position_data["requirements"],
        
        "我们提供": [
            f"有竞争力的薪酬：{salary_range}/月+{salary_info.get('bonus', '绩效奖金')}",
            f"完善的培训体系：带薪培训+职业发展通道",
            f"温馨的工作环境：{store_info['atmosphere']}",
            f"丰富的团队活动：节日福利+员工聚餐",
            *salary_info.get("benefits", ["包吃", "节日福利"]),
            "快速晋升机会：表现优秀可晋升管理岗"
        ],
        
        "工作时间": {
            "班次": "早班/中班/晚班",
            "休息": "每月4天休息",
            "特点": "法定节假日三薪"
        },
        
        "联系方式": {
            "联系人": "HR/[店长]",
            "电话": "[联系电话]",
            "微信": "[微信号]",
            "地址": "[门店地址]"
        },
        
        "面试准备": {
            "所需材料": ["身份证原件", "健康证（如有）", "相关证书（如有）"],
            "面试内容": ["自我介绍", "经验了解", "情景模拟", "双向沟通"],
            "温馨提示": "请准时到达，穿着整洁得体"
        },
        
        "jd_text": f"""
【{position}】热招中 - [品牌名称]

{store_info['feature']}，期待你的加入！

📍 工作地点：[具体地址]
💰 薪资待遇：{salary_range}/月+绩效奖金

【岗位职责】
{chr(10).join([f"{i+1}. {r}" for i, r in enumerate(position_data['responsibilities'][:3])])}

【任职要求】
{chr(10).join([f"• {r}" for r in position_data['requirements'][:3]])}

【福利待遇】
• 有竞争力的薪酬+绩效奖金
• 包吃包住（或餐补房补）
• 节日福利、生日礼物
• 快速晋升机会

📞 欢迎电话咨询或直接到店面试！
联系方式：[电话]
""".strip()
    }


def _generate_interview_questions(position: str, store_type: str) -> Dict[str, Any]:
    """生成面试题库"""
    base_questions = {
        "初试": {
            "通用题": [
                {"题目": f"为什么想从事{position}这份工作？", "考察点": "求职动机", "回答要点": "表达对餐饮行业的兴趣，认可公司品牌"},
                {"题目": "之前有相关工作经验吗？", "考察点": "经验匹配", "回答要点": "有经验：强调成绩；无经验：表达学习意愿"},
                {"题目": "你的优势是什么？", "考察点": "自我认知", "回答要点": "结合岗位要求，突出可迁移能力"},
                {"题目": "你能适应倒班和节假日上班吗？", "考察点": "工作态度", "回答要点": "表达理解和接受"}
            ],
            "服务员题": [
                {"题目": "遇到顾客抱怨菜品口味怎么办？", "考察点": "应变能力", "回答要点": "先安抚，记录反馈，感谢提出"},
                {"题目": "高峰期很忙时你怎么处理？", "考察点": "抗压能力", "回答要点": "分清轻重缓急，寻求帮助"}
            ],
            "店长题": [
                {"题目": "如何提升门店营业额？", "考察点": "经营思路", "回答要点": "从引流、留存、复购多维度分析"},
                {"题目": "如何处理员工之间的矛盾？", "考察点": "管理能力", "回答要点": "公平公正，了解情况，调解为主"}
            ]
        },
        "复试": {
            "通用题": [
                {"题目": "描述一次你解决困难经历", "考察点": "问题解决", "回答要点": "STAR法则：情境-任务-行动-结果"},
                {"题目": "如何处理顾客投诉？", "考察点": "服务意识", "回答要点": "倾听、共情、解决、跟进"},
                {"题目": "对加班怎么看？", "考察点": "职业态度", "回答要点": "理解餐饮行业特点，愿意配合"},
                {"题目": "你的职业规划是什么？", "考察点": "稳定性", "回答要点": "有明确方向，与公司发展结合"}
            ],
            "店长题": [
                {"题目": "如果门店出现食品安全问题怎么办？", "考察点": "危机处理", "回答要点": "立即停售、报告上级、彻查原因"},
                {"题目": "如何控制门店成本？", "考察点": "成本意识", "回答要点": "从食材、人力、能耗多维度控制"}
            ]
        },
        "情景模拟": {
            "服务员": [
                "顾客点了菜品后发现里面有异物，你怎么处理？",
                "顾客等餐超过30分钟很生气，你怎么安抚？",
                "高峰期顾客要打包但来不及做，你怎么协调？"
            ],
            "店长": [
                "员工突然辞职，次日就要走，你怎么应对？",
                "门店月度业绩下滑20%，你的改进计划是？",
                "供应商送来的食材有问题，你怎么处理？"
            ]
        }
    }
    
    return {
        "初试": base_questions["初试"].get("通用题", []) + base_questions["初试"].get(f"{position}题", []),
        "复试": base_questions["复试"]["通用题"] + base_questions["复试"].get(f"{position}题", []),
        "情景模拟": base_questions["情景模拟"].get(position, base_questions["情景模拟"]["服务员"])
    }


def _generate_evaluation_form(position: str, position_data: Dict) -> Dict[str, Any]:
    """生成考核标准"""
    return {
        "考核维度": {
            "形象礼仪": {
                "权重": "10%",
                "标准": ["着装整洁", "仪表得体", "精神面貌好"],
                "满分": 10
            },
            "表达能力": {
                "权重": "15%",
                "标准": ["语言清晰", "逻辑清楚", "沟通有效"],
                "满分": 15
            },
            "专业知识": {
                "权重": "25%",
                "标准": position_data["skills"],
                "满分": 25
            },
            "应变能力": {
                "权重": "20%",
                "标准": ["冷静处理问题", "灵活应对", "妥善解决"],
                "满分": 20
            },
            "态度意愿": {
                "权重": "15%",
                "标准": ["积极主动", "稳定性", "学习意愿"],
                "满分": 15
            },
            "团队协作": {
                "权重": "15%",
                "标准": ["服从安排", "主动配合", "善于沟通"],
                "满分": 15
            }
        },
        "录用标准": {
            "总分": 60,
            "单项": "任何单项不低于60%得分",
            "综合": "择优录取，宁缺毋滥"
        },
        "面试记录表": {
            "基本信息": ["姓名", "年龄", "联系电话", "期望薪资", "最快到岗时间"],
            "面试评价": ["优势", "劣势", "综合建议"],
            "面试结论": ["□ 录用  □ 待定  □ 不合适"],
            "薪资确认": "___K/月",
            "入职日期": "____年__月__日"
        }
    }


def training_system(
    topic: str = "new_employee",
    content_type: str = "all",
    custom_content: str = ""
) -> Dict[str, Any]:
    """
    培训赋能系统
    
    课件生成、考核题库、SOP脚本
    
    Args:
        topic: 培训主题 new_employee/service/food_safety/fire_safety
        content_type: 内容类型 all/course/quiz/sop
        custom_content: 自定义培训内容描述
    
    Returns:
        培训内容、考核题目、SOP文档
    """
    # 培训内容库
    courses = {
        "new_employee": {
            "title": "新员工入职培训",
            "duration": "3天",
            "modules": [
                {
                    "name": "企业文化",
                    "duration": "2小时",
                    "content": [
                        "品牌故事与发展历程",
                        "企业使命与价值观",
                        "组织架构与团队介绍"
                    ]
                },
                {
                    "name": "门店运营",
                    "duration": "4小时",
                    "content": [
                        "门店介绍与工作流程",
                        "岗位职责与分工",
                        "日常工作规范"
                    ]
                },
                {
                    "name": "服务标准",
                    "duration": "4小时",
                    "content": [
                        "服务礼仪与话术",
                        "点餐下单流程",
                        "客诉处理技巧"
                    ]
                },
                {
                    "name": "食品安全",
                    "duration": "2小时",
                    "content": [
                        "食品安全基础知识",
                        "个人卫生规范",
                        "常见食品安全风险"
                    ]
                }
            ]
        },
        "service": {
            "title": "服务技能提升培训",
            "duration": "2天",
            "modules": [
                {
                    "name": "服务意识",
                    "duration": "3小时",
                    "content": [
                        "优质服务的标准",
                        "顾客需求分析",
                        "服务心态建设"
                    ]
                },
                {
                    "name": "服务技能",
                    "duration": "4小时",
                    "content": [
                        "标准服务流程",
                        "点餐技巧",
                        "特殊情况处理"
                    ]
                }
            ]
        },
        "food_safety": {
            "title": "食品安全培训",
            "duration": "1天",
            "modules": [
                {
                    "name": "法规与标准",
                    "duration": "2小时",
                    "content": [
                        "食品安全法要点",
                        "餐饮服务操作规范",
                        "证照管理要求"
                    ]
                },
                {
                    "name": "实操规范",
                    "duration": "3小时",
                    "content": [
                        "食材储存与保鲜",
                        "加工操作规范",
                        "清洁消毒流程"
                    ]
                }
            ]
        },
        "fire_safety": {
            "title": "消防安全培训",
            "duration": "3小时",
            "modules": [
                {
                    "name": "消防知识",
                    "duration": "1小时",
                    "content": [
                        "火灾成因与预防",
                        "灭火器使用方法",
                        "疏散逃生技巧"
                    ]
                },
                {
                    "name": "应急预案",
                    "duration": "2小时",
                    "content": [
                        "火灾应急预案",
                        "人员疏散流程",
                        "日常检查要点"
                    ]
                }
            ]
        }
    }
    
    topic_key = topic if topic in courses else "new_employee"
    course = courses[topic_key]
    
    return {
        "generated_time": datetime.now().strftime("%Y-%m-%d"),
        "topic": topic,
        
        "course": course,
        
        "quiz": _generate_quiz(topic_key),
        
        "sop": _generate_sop(topic_key),
        
        "attendance_sheet": {
            "字段": ["姓名", "部门", "职位", "培训日期", "培训时长", "签到", "考核成绩", "备注"]
        }
    }


def _generate_quiz(topic: str) -> Dict[str, Any]:
    """生成考核题库"""
    quizzes = {
        "new_employee": [
            {"type": "单选", "q": "顾客进门第一句话应该说？", "options": ["你好", "欢迎光临！请问几位？", "随便坐", "吃什么"], "answer": "B"},
            {"type": "判断", "q": "发现食材过期应该继续使用吗？", "answer": "错"},
            {"type": "多选", "q": "以下哪些是服务禁忌？", "options": ["脸色不好", "爱答不理", "积极热情", "翻白眼"], "answer": "ABD"}
        ],
        "food_safety": [
            {"type": "单选", "q": "冷藏食品温度应保持在？", "options": ["0-4°C", "10-15°C", "-18°C以下", "常温"], "answer": "A"},
            {"type": "判断", "q": "生熟食品可以放在一起加工", "answer": "错"},
            {"type": "多选", "q": "食品污染的类型包括？", "options": ["生物污染", "化学污染", "物理污染", "人工污染"], "answer": "ABC"}
        ]
    }
    
    return quizzes.get(topic, quizzes["new_employee"])


def _generate_sop(topic: str) -> Dict[str, str]:
    """生成SOP文档"""
    sops = {
        "new_employee": {
            "title": "新员工第一天SOP",
            "steps": [
                "9:00 到店签到，领取工服工牌",
                "9:30 参观门店，熟悉环境",
                "10:00 企业文化培训",
                "12:00 午餐（员工餐）",
                "13:00 岗位职责培训",
                "15:00 跟随老员工实操学习",
                "18:00 晚餐",
                "19:00 继续实操",
                "21:00 日总结，下班"
            ]
        },
        "service": {
            "title": "顾客接待SOP",
            "steps": [
                "Step 1: 主动问好 '欢迎光临，请问几位？'",
                "Step 2: 引座入席，帮顾客放好随身物品",
                "Step 3: 递上菜单，倒茶水",
                "Step 4: 等待点餐（3分钟内）",
                "Step 5: 确认点餐，重复订单",
                "Step 6: 感谢点餐，离开时说一句'请稍等'",
                "Step 7: 上菜时'这是您点的XX，请慢用'",
                "Step 8: 巡台，及时添茶水",
                "Step 9: 结账，送客"
            ]
        }
    }
    
    return sops.get(topic, sops["new_employee"])


def performance_appraisal(
    岗位: str,
    考核周期: str = "月度",
    考核数据: str = ""
) -> Dict[str, Any]:
    """
    绩效考核
    
    Args:
        岗位: 如"服务员"、"店长"
        考核周期: 月度/季度/年度
        考核数据: 考核数据描述，如"小李，本月服务100单，5星好评50单，2个投诉"
    
    Returns:
        绩效考核表、排名、改进建议
    """
    return {
        "generated_time": datetime.now().strftime("%Y-%m-%d"),
        "岗位": 岗位,
        "考核周期": 考核周期,
        "原始数据": 考核数据,
        
        "考核表": {
            "营收指标": {"占比": "30%", "评分标准": "完成率"},
            "服务质量": {"占比": "30%", "评分标准": "好评率"},
            "工作态度": {"占比": "20%", "评分标准": "出勤/服从"},
            "团队协作": {"占比": "20%", "评分标准": "互评"}
        },
        
        "排名示例": [
            {"排名": 1, "姓名": "张三", "总分": 95, "等级": "A"},
            {"排名": 2, "姓名": "李四", "总分": 88, "等级": "B+"},
            {"排名": 3, "姓名": "王五", "总分": 82, "等级": "B"}
        ],
        
        "奖惩标准": {
            "A级": "基础工资上浮10%，优先晋升",
            "B级": "维持原工资",
            "C级": "绩效辅导，连续2个月C级降级"
        }
    }


def turnover_warning(
    店铺: str,
    员工信息: str
) -> Dict[str, Any]:
    """
    离职预警
    
    根据员工行为数据预测离职风险
    
    Args:
        店铺: 店铺名称
        员工信息: 员工表现数据，如"小王，入职6个月，近期请假频繁，与同事关系紧张"
    
    Returns:
        离职风险评估、预警等级、留存建议
    """
    return {
        "generated_time": datetime.now().strftime("%Y-%m-%d"),
        "店铺": 店铺,
        "员工信息": 员工信息,
        
        "风险评估": {
            "预警等级": "中",
            "离职概率": "40%",
            "风险因素": ["近期表现下滑", "请假频繁", "可能对工作不满意"]
        },
        
        "留存建议": {
            "立即行动": "直属上级1对1沟通，了解真实想法",
            "短期措施": "调整工作安排，增加正向激励",
            "长期方案": "职业规划辅导，晋升机会"
        },
        
        "预警话术": "小王，最近工作压力大吗？有什么需要我帮忙的吗？"
    }
