# -*- coding: utf-8 -*-
"""
供应链路模块
包含：智能订货、库存预警、供应商评估、损耗分析
作者：郝多鱼
版本：1.0.0
"""

from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
import random


def smart_ordering(
    store_id: str,
    current_inventory: Optional[Dict[str, float]] = None,
    consumption_history: Optional[Dict[str, float]] = None,
    ordering_period: int = 7,
    supplier_id: Optional[str] = None
) -> Dict[str, Any]:
    """
    智能订货系统
    
    基于历史消耗自动计算订货建议
    
    Args:
        store_id: 门店ID
        current_inventory: 当前库存 {食材名: 数量kg}
        consumption_history: 历史日均消耗 {食材名: kg}
        ordering_period: 订货周期（天）
        supplier_id: 指定供应商
    
    Returns:
        订货建议清单、采购金额、安全库存提醒
    """
    # 模拟消耗数据
    if not consumption_history:
        consumption_history = {
            "牛肉": 15, "猪肉": 12, "鸡肉": 10,
            "土豆": 20, "白菜": 15, "青椒": 8,
            "面粉": 5, "食用油": 3, "调料": 2
        }
    
    if not current_inventory:
        current_inventory = {k: random.randint(5, 30) for k in consumption_history.keys()}
    
    # 计算订货建议
    orders = []
    total_cost = 0
    
    for item, daily_avg in consumption_history.items():
        needed = daily_avg * ordering_period * 1.2  # 留20%余量
        current = current_inventory.get(item, 0)
        order_qty = max(0, needed - current)
        
        if order_qty > 0:
            unit_price = _get_unit_price(item)
            item_cost = order_qty * unit_price
            total_cost += item_cost
            
            orders.append({
                "item": item,
                "current_stock": current,
                "daily_avg": daily_avg,
                "safety_stock": daily_avg * 3,
                "order_qty": round(order_qty, 1),
                "unit": "kg",
                "unit_price": unit_price,
                "subtotal": round(item_cost, 2),
                "urgency": "高" if current < daily_avg * 2 else ("中" if current < daily_avg * 3 else "低")
            })
    
    # 按紧急程度排序
    orders.sort(key=lambda x: {"高": 0, "中": 1, "低": 2}[x["urgency"]])
    
    return {
        "order_id": f"ORD{datetime.now().strftime('%Y%m%d%H%M%S')}",
        "store_id": store_id,
        "period": f"{ordering_period}天",
        "order_date": datetime.now().strftime("%Y-%m-%d"),
        
        "orders": orders,
        
        "summary": {
            "total_items": len(orders),
            "total_qty": round(sum(o["order_qty"] for o in orders), 1),
            "total_cost": round(total_cost, 2),
            "urgent_count": len([o for o in orders if o["urgency"] == "高"])
        },
        
        "category_breakdown": {
            "肉类": {"items": 3, "cost": round(total_cost * 0.45, 2)},
            "蔬菜": {"items": 3, "cost": round(total_cost * 0.25, 2)},
            "粮油调料": {"items": 3, "cost": round(total_cost * 0.30, 2)}
        },
        
        "delivery_suggestion": {
            "supplier": supplier_id or "默认供应商",
            "estimated_delivery": (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d"),
            "delivery_address": f"{store_id}号门店"
        },
        
        "warnings": _get_ordering_warnings(orders, current_inventory, consumption_history),
        
        "notes": [
            "以上为建议订货量，实际可根据活动、天气等因素调整",
            "生鲜类食材建议每日配送保证新鲜",
            "遇到节假日提前增加备货量30%"
        ]
    }


def _get_unit_price(item: str) -> float:
    """获取食材单价"""
    prices = {
        "牛肉": 45, "猪肉": 25, "鸡肉": 15,
        "土豆": 3, "白菜": 2, "青椒": 5,
        "面粉": 5, "食用油": 12, "调料": 20
    }
    return prices.get(item, random.uniform(5, 30))


def _get_ordering_warnings(
    orders: List[Dict],
    current: Dict[str, float],
    consumption: Dict[str, float]
) -> List[Dict]:
    """获取订货警告"""
    warnings = []
    
    for item, avg in consumption.items():
        stock = current.get(item, 0)
        days_left = stock / avg if avg > 0 else 999
        
        if days_left < 2:
            warnings.append({
                "type": "stock_critical",
                "item": item,
                "current": stock,
                "days_left": round(days_left, 1),
                "message": f"{item}库存仅剩{days_left:.1f}天用量，请立即补货！"
            })
    
    for order in orders:
        if order["urgency"] == "高":
            warnings.append({
                "type": "order_urgent",
                "item": order["item"],
                "message": f"{order['item']}建议优先配送"
            })
    
    return warnings


def inventory_warning(
    store_id: Optional[str] = None,
    categories: Optional[List[str]] = None
) -> Dict[str, Any]:
    """
    库存预警中枢
    
    效期预警、积压预警、断货预警
    
    Args:
        store_id: 门店ID
        categories: 分类筛选
    
    Returns:
        各类预警列表、处理建议
    """
    # 模拟库存数据
    inventory = _generate_sample_inventory()
    
    if store_id:
        inventory = [i for i in inventory if i["store_id"] == store_id]
    
    if categories:
        inventory = [i for i in inventory if i["category"] in categories]
    
    # 分类预警
    expiry_warnings = []  # 效期预警
    overstock_warnings = []  # 积压预警
    stockout_warnings = []  # 断货预警
    normal_items = []  # 正常
    
    for item in inventory:
        days_to_expiry = item.get("days_to_expiry", 999)
        stock_days = item.get("stock_days", 30)
        daily_usage = item.get("daily_usage", 10)
        
        if days_to_expiry <= 3:
            expiry_warnings.append({
                **item,
                "severity": "critical" if days_to_expiry <= 1 else "high",
                "action": "立即使用或促销处理"
            })
        elif days_to_expiry <= 7:
            expiry_warnings.append({
                **item,
                "severity": "medium",
                "action": "优先使用，可做促销"
            })
        
        if stock_days > 30:
            overstock_warnings.append({
                **item,
                "severity": "high" if stock_days > 45 else "medium",
                "action": "控制进货，建议促销"
            })
        
        if daily_usage > 0 and item.get("stock", 0) < daily_usage * 3:
            stockout_warnings.append({
                **item,
                "severity": "high" if item.get("stock", 0) < daily_usage else "medium",
                "action": "立即补货"
            })
        
    # 用食材名去重，避免展开后的dict引用比较失效
    flagged_items = set()
    for w in expiry_warnings:
        flagged_items.add(w.get("item", ""))
    for w in overstock_warnings:
        flagged_items.add(w.get("item", ""))
    for w in stockout_warnings:
        flagged_items.add(w.get("item", ""))

    for item in inventory:
        if item.get("item", "") not in flagged_items:
            normal_items.append(item)
    
    return {
        "check_time": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "store_id": store_id or "全部门店",
        
        "summary": {
            "total_items": len(inventory),
            "expiry_count": len(expiry_warnings),
            "overstock_count": len(overstock_warnings),
            "stockout_count": len(stockout_warnings),
            "normal_count": len(normal_items),
            "urgent_action": len([w for w in expiry_warnings if w["severity"] == "critical"])
        },
        
        "expiry_warnings": sorted(expiry_warnings, key=lambda x: x.get("days_to_expiry", 999)),
        "overstock_warnings": overstock_warnings,
        "stockout_warnings": stockout_warnings,
        "normal_items": normal_items[:10],
        
        "action_plan": {
            "critical": [item["item"] for item in expiry_warnings if item["severity"] == "critical"],
            "today": [item["item"] for item in expiry_warnings if item["severity"] == "high"],
            "this_week": [item["item"] for item in overstock_warnings if item["severity"] == "high"]
        },
        
        "suggestions": [
            "效期小于3天：立即使用或做特价处理",
            "积压超过45天：减少进货，尽快消化",
            "断货风险：立即补货，确保供应"
        ]
    }


def _generate_sample_inventory() -> List[Dict]:
    """生成示例库存"""
    items = [
        {"item": "牛肉卷", "category": "肉类", "store_id": "A001", "stock": 50, "daily_usage": 15, "days_to_expiry": 2},
        {"item": "猪肉", "category": "肉类", "store_id": "A001", "stock": 80, "daily_usage": 12, "days_to_expiry": 5},
        {"item": "活虾", "category": "海鲜", "store_id": "A001", "stock": 20, "daily_usage": 8, "days_to_expiry": 1},
        {"item": "土豆", "category": "蔬菜", "store_id": "A001", "stock": 200, "daily_usage": 20, "days_to_expiry": 7},
        {"item": "白菜", "category": "蔬菜", "store_id": "A001", "stock": 100, "daily_usage": 15, "days_to_expiry": 10},
        {"item": "面粉", "category": "粮油", "store_id": "A001", "stock": 500, "daily_usage": 5, "days_to_expiry": 90},
        {"item": "调味酱料", "category": "调料", "store_id": "A001", "stock": 30, "daily_usage": 2, "days_to_expiry": 180},
        {"item": "牛肉卷", "category": "肉类", "store_id": "A002", "stock": 60, "daily_usage": 18, "days_to_expiry": 3},
        {"item": "羊肉卷", "category": "肉类", "store_id": "A002", "stock": 40, "daily_usage": 10, "days_to_expiry": 4},
        {"item": "蔬菜拼盘", "category": "蔬菜", "store_id": "A002", "stock": 50, "daily_usage": 25, "days_to_expiry": 2}
    ]
    
    for item in items:
        item["stock_days"] = round(item["stock"] / item["daily_usage"], 1)
    
    return items


def supplier_evaluation(
    category: Optional[str] = None,
    suppliers: Optional[List[str]] = None,
    period: str = "last_month"
) -> Dict[str, Any]:
    """
    供应商评估
    
    供应商对比、质量追踪、打分排名
    
    Args:
        category: 品类（肉类/蔬菜/调料等）
        suppliers: 供应商列表
        period: 评估周期
    
    Returns:
        评分排名、质量追踪、续约建议
    """
    # 模拟供应商数据
    if not suppliers:
        suppliers = ["甲供应商", "乙供应商", "丙供应商"]
    
    # 评估维度
    eval_criteria = {
        "quality": {"weight": 0.30, "name": "质量评分"},
        "price": {"weight": 0.25, "name": "价格竞争力"},
        "delivery": {"weight": 0.20, "name": "配送准时率"},
        "service": {"weight": 0.15, "name": "服务响应"},
        "stability": {"weight": 0.10, "name": "供货稳定性"}
    }
    
    evaluations = []
    for supplier in suppliers:
        scores = {}
        for key, info in eval_criteria.items():
            scores[info["name"]] = {
                "score": round(random.uniform(70, 98), 1),
                "weight": info["weight"]
            }
        
        # 计算加权总分
        total_score = sum(s["score"] * s["weight"] for s in scores.values())
        
        evaluations.append({
            "supplier": supplier,
            "category": category or "综合",
            "scores": scores,
            "total_score": round(total_score, 1),
            "rank": 0,
            "level": "A" if total_score >= 90 else ("B" if total_score >= 80 else ("C" if total_score >= 70 else "D"))
        })
    
    # 排名
    evaluations.sort(key=lambda x: x["total_score"], reverse=True)
    for i, ev in enumerate(evaluations):
        ev["rank"] = i + 1
    
    # 质量追踪
    quality_tracking = [
        {"supplier": s["supplier"], "issue": "轻微包装破损", "date": "01-15", "resolved": True}
        for s in evaluations[:2]
    ]
    
    return {
        "eval_time": datetime.now().strftime("%Y-%m-%d"),
        "period": period,
        "criteria": eval_criteria,
        
        "rankings": evaluations,
        
        "quality_tracking": quality_tracking,
        
        "recommendations": {
            "continue": [e["supplier"] for e in evaluations if e["level"] == "A"],
            "probation": [e["supplier"] for e in evaluations if e["level"] == "B"],
            "replace": [e["supplier"] for e in evaluations if e["level"] in ["C", "D"]]
        },
        
        "compare_detail": {
            "best_quality": max(evaluations, key=lambda x: x["scores"]["质量评分"]["score"])["supplier"],
            "best_price": max(evaluations, key=lambda x: x["scores"]["价格竞争力"]["score"])["supplier"],
            "best_delivery": max(evaluations, key=lambda x: x["scores"]["配送准时率"]["score"])["supplier"]
        }
    }


def loss_analysis(
    store_id: Optional[str] = None,
    period: str = "last_month"
) -> Dict[str, Any]:
    """
    损耗分析报告
    
    各环节损耗分析、改进建议
    
    Args:
        store_id: 门店ID
        period: 分析周期
    
    Returns:
        损耗分布、高损耗环节、改进建议
    """
    # 各环节损耗率
    stages = {
        "采购运输": {"loss_rate": random.uniform(1, 3), "cost": random.randint(2000, 5000)},
        "储存保管": {"loss_rate": random.uniform(2, 5), "cost": random.randint(3000, 8000)},
        "粗加工": {"loss_rate": random.uniform(5, 10), "cost": random.randint(5000, 12000)},
        "烹饪制作": {"loss_rate": random.uniform(3, 8), "cost": random.randint(4000, 10000)},
        "销售剩余": {"loss_rate": random.uniform(2, 6), "cost": random.randint(3000, 7000)}
    }
    
    total_loss_cost = sum(s["cost"] for s in stages.values())
    total_purchase = random.randint(150000, 250000)
    total_loss_rate = total_loss_cost / total_purchase * 100
    
    # 损耗排名
    stage_rankings = sorted(
        [{"stage": k, **v} for k, v in stages.items()],
        key=lambda x: x["loss_rate"],
        reverse=True
    )
    
    # 高损耗分析
    high_loss = [s for s in stage_rankings if s["loss_rate"] > 5]
    
    # 改进建议
    suggestions = {
        "采购运输": ["选择更近供应商", "优化包装减少损耗", "加强验收标准"],
        "储存保管": ["改善储存条件", "先进先出执行", "定期盘点清理"],
        "粗加工": ["标准化切配", "培训切配技能", "减少过度加工"],
        "烹饪制作": ["标准化操作流程", "减少制作失误", "控制油温火候"],
        "销售剩余": ["精准备货", "临期促销", "优化菜单组合"]
    }
    
    return {
        "report_time": datetime.now().strftime("%Y-%m-%d"),
        "store_id": store_id or "全部门店",
        "period": period,
        
        "overview": {
            "total_purchase": total_purchase,
            "total_loss_cost": round(total_loss_cost, 2),
            "total_loss_rate": round(total_loss_rate, 2),
            "industry_avg": 4.5,
            "vs_industry": f"{'+' if total_loss_rate > 4.5 else '-'}{abs(total_loss_rate - 4.5):.1f}%"
        },
        
        "stage_breakdown": [
            {
                "stage": s["stage"],
                "loss_rate": round(s["loss_rate"], 2),
                "cost": round(s["cost"], 2),
                "loss_ratio": f"{s['cost']/total_loss_cost*100:.1f}%",
                "status": "🔴 高" if s["loss_rate"] > 5 else ("🟡 中" if s["loss_rate"] > 3 else "🟢 低")
            }
            for s in stage_rankings
        ],
        
        "high_loss_analysis": [
            {
                "stage": h["stage"],
                "loss_rate": h["loss_rate"],
                "estimated_annual_waste": round(h["cost"] * 12, 2),
                "root_cause": _get_loss_root_cause(h["stage"]),
                "suggestions": suggestions.get(h["stage"], [])
            }
            for h in high_loss
        ],
        
        "improvement_plan": {
            "quick_wins": [
                {"action": "严格执行先进先出", "expected_saving": "减少损耗1%", "difficulty": "低"},
                {"action": "标准化切配流程", "expected_saving": "减少损耗2%", "difficulty": "中"}
            ],
            "medium_term": [
                {"action": "精准备货系统", "expected_saving": "减少损耗3%", "difficulty": "中"},
                {"action": "员工技能培训", "expected_saving": "减少损耗1.5%", "difficulty": "中"}
            ],
            "long_term": [
                {"action": "供应链优化", "expected_saving": "减少损耗5%", "difficulty": "高"}
            ]
        },
        
        "monthly_trend": {
            "this_month": round(total_loss_rate, 2),
            "last_month": round(total_loss_rate * random.uniform(0.9, 1.1), 2),
            "trend": "↓改善" if total_loss_rate < 4.5 else "↑恶化"
        }
    }


def _get_loss_root_cause(stage: str) -> str:
    """获取损耗根因"""
    causes = {
        "采购运输": "运输条件不当或验收不严",
        "储存保管": "储存温度湿度控制不当",
        "粗加工": "切配标准不统一，损耗意识差",
        "烹饪制作": "火候控制不当，报废过多",
        "销售剩余": "备货不精准，销量预估偏差"
    }
    return causes.get(stage, "待分析")


# 示例调用
if __name__ == "__main__":
    print("=" * 50)
    print("智能订货")
    print("=" * 50)
    order = smart_ordering("A001", {}, {}, ordering_period=7)
    print(f"订货项数: {order['summary']['total_items']}")
    print(f"总金额: {order['summary']['total_cost']}元")
    print(f"紧急项: {order['summary']['urgent_count']}")
    
    print("\n" + "=" * 50)
    print("库存预警")
    print("=" * 50)
    inv = inventory_warning("A001")
    print(f"效期预警: {inv['summary']['expiry_count']}")
    print(f"积压预警: {inv['summary']['overstock_count']}")
    print(f"断货预警: {inv['summary']['stockout_count']}")
    
    print("\n" + "=" * 50)
    print("供应商评估")
    print("=" * 50)
    sup = supplier_evaluation(category="肉类")
    for e in sup["rankings"]:
        print(f"{e['rank']}. {e['supplier']}: {e['total_score']}分 ({e['level']}级)")
    
    print("\n" + "=" * 50)
    print("损耗分析")
    print("=" * 50)
    loss = loss_analysis("A001")
    print(f"总损耗率: {loss['overview']['total_loss_rate']}%")
    print(f"损耗金额: {loss['overview']['total_loss_cost']}元")
