# -*- coding: utf-8 -*-
"""
数据链路模块
包含：经营驾驶舱、系统集成
作者：郝多鱼
版本：1.0.0
"""

from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
import re
import random


def business_dashboard(
    店铺名称: str,
    数据时间范围: str = "今日",
    实时数据: str = ""
) -> Dict[str, Any]:
    """
    经营驾驶舱
    
    根据用户输入的经营数据，生成数据可视化报告
    
    Args:
        店铺名称: 门店名称
        数据时间范围: 今日/本周/本月
        实时数据: 实时数据描述，如"当前在店30人，等位5桌，今日营收5.8万"
    
    Returns:
        核心指标、趋势图表、预警提示
    """
    # 解析实时数据
    parsed_data = _parse_realtime_data(实时数据)
    
    # 计算核心指标
    metrics = _calculate_metrics(店铺名称, 数据时间范围, parsed_data)
    
    # 生成预警
    warnings = _generate_warnings(metrics)
    
    return {
        "generated_time": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "店铺名称": 店铺名称,
        "数据时间范围": 数据时间范围,
        
        "核心指标": metrics,
        
        "今日概况": {
            "营收": parsed_data.get("营收", 0),
            "到店顾客": parsed_data.get("到店人数", 0),
            "等位情况": parsed_data.get("等位桌数", 0),
            "客单价": round(parsed_data.get("营收", 0) / max(parsed_data.get("到店人数", 1), 1), 2)
        },
        
        "KPI状态": _generate_kpi_status(metrics),
        
        "时段分析": _generate_hourly_analysis(parsed_data),
        
        "菜品排行": _generate_dish_ranking(店铺名称),
        
        "预警中心": warnings,
        
        "环比对比": _generate_comparison(metrics)
    }


def _parse_realtime_data(data_text: str) -> Dict[str, Any]:
    """解析实时数据"""
    if not data_text:
        return {
            "营收": 0,
            "到店人数": 0,
            "等位桌数": 0,
            "在线座位": 0,
            "原始数据": ""
        }
    
    result = {"原始数据": data_text, "营收": 0, "到店人数": 0, "等位桌数": 0}
    
    # 提取金额：优先匹配"营收/收入"关键词后的数字
    revenue_match = re.search(r'营收[：:]?\s*([\d.]+)\s*(万|千)?', data_text)
    if not revenue_match:
        revenue_match = re.search(r'收入[：:]?\s*([\d.]+)\s*(万|千)?', data_text)
    if not revenue_match:
        revenue_match = re.search(r'([\d.]+)\s*(万|千)', data_text)  # 带单位的关键数字
    if not revenue_match:
        revenue_match = re.search(r'([\d.]+)\s*元', data_text)  # 带元的数字
    
    if revenue_match:
        value = float(revenue_match.group(1))
        unit_char = revenue_match.group(2) if revenue_match.lastindex >= 2 else None
        if unit_char == '万':
            unit = 10000
        elif unit_char == '千':
            unit = 1000
        else:
            unit = 1
        result["营收"] = value * unit
    
    # 提取人数
    people_match = re.search(r'(\d+)\s*[人位桌]', data_text)
    if people_match:
        num = int(people_match.group(1))
        if '等位' in data_text or '桌' in data_text:
            result["等位桌数"] = num
        else:
            result["到店人数"] = num
    
    return result


def _calculate_metrics(store_name: str, time_range: str, parsed_data: Dict) -> Dict[str, Any]:
    """计算核心指标"""
    revenue = parsed_data.get("营收", 0)
    customers = parsed_data.get("到店人数", 0)
    
    # 目标值
    targets = {
        "今日": {"revenue": 80000, "customers": 300, "avg_check": 60},
        "本周": {"revenue": 560000, "customers": 2100, "avg_check": 60},
        "本月": {"revenue": 2400000, "customers": 9000, "avg_check": 60}
    }
    
    target = targets.get(time_range, targets["今日"])
    
    # 计算完成率
    revenue_completion = revenue / target["revenue"] * 100 if target["revenue"] > 0 else 0
    customers_completion = customers / target["customers"] * 100 if target["customers"] > 0 else 0
    
    # 计算客单价
    avg_check = revenue / max(customers, 1)
    
    return {
        "营收": {
            "实际": revenue,
            "目标": target["revenue"],
            "完成率": round(revenue_completion, 1),
            "状态": "达标" if revenue_completion >= 100 else ("接近" if revenue_completion >= 85 else "落后")
        },
        "到店人数": {
            "实际": customers,
            "目标": target["customers"],
            "完成率": round(customers_completion, 1)
        },
        "客单价": {
            "实际": round(avg_check, 2),
            "目标": target["avg_check"],
            "状态": "正常" if avg_check >= target["avg_check"] * 0.9 else "偏低"
        },
        "翻台率": {
            "实际": 3.2,  # 模拟数据
            "目标": 3.5,
            "状态": "正常"
        },
        "等位": {
            "当前": parsed_data.get("等位桌数", 0),
            "状态": "繁忙" if parsed_data.get("等位桌数", 0) > 5 else "正常"
        }
    }


def _generate_kpi_status(metrics: Dict) -> List[Dict]:
    """生成KPI状态列表"""
    return [
        {
            "指标": "营收完成率",
            "数值": f"{metrics['营收']['完成率']}%",
            "目标": "100%",
            "状态": "🟢" if metrics['营收']['完成率'] >= 100 else ("🟡" if metrics['营收']['完成率'] >= 85 else "🔴")
        },
        {
            "指标": "客单价",
            "数值": f"{metrics['客单价']['实际']}元",
            "目标": f"{metrics['客单价']['目标']}元",
            "状态": "🟢" if metrics['客单价']['状态'] == "正常" else "🟡"
        },
        {
            "指标": "翻台率",
            "数值": f"{metrics['翻台率']['实际']}",
            "目标": f"{metrics['翻台率']['目标']}",
            "状态": "🟢" if metrics['翻台率']['状态'] == "正常" else "🟡"
        }
    ]


def _generate_hourly_analysis(parsed_data: Dict) -> List[Dict]:
    """生成时段分析"""
    hours = []
    current_hour = datetime.now().hour
    
    for hour in range(10, 23):
        is_peak = hour in [12, 13, 18, 19, 20]
        is_current = hour == current_hour
        
        hours.append({
            "时段": f"{hour}:00",
            "是否高峰": "⭐" if is_peak else "",
            "是否当前": "▶" if is_current else "",
            "营收预估": random.randint(5000, 20000) if is_peak else random.randint(2000, 8000),
            "客流预估": random.randint(50, 200) if is_peak else random.randint(20, 80)
        })
    
    return hours


def _generate_dish_ranking(store_name: str) -> List[Dict]:
    """生成菜品排行"""
    return [
        {"排名": 1, "菜品": "招牌剁椒鱼头", "销量": 45, "趋势": "↑", "销售额": 3060},
        {"排名": 2, "菜品": "农家小炒肉", "销量": 38, "趋势": "↑", "销售额": 1900},
        {"排名": 3, "菜品": "酸辣土豆丝", "销量": 35, "趋势": "→", "销售额": 1050},
        {"排名": 4, "菜品": "铁板牛肉", "销量": 28, "趋势": "↓", "销售额": 2520},
        {"排名": 5, "菜品": "宫保鸡丁", "销量": 25, "趋势": "→", "销售额": 1750}
    ]


def _generate_warnings(metrics: Dict) -> List[Dict]:
    """生成预警"""
    warnings = []
    
    if metrics['营收']['完成率'] < 85:
        warnings.append({
            "类型": "营收预警",
            "等级": "中",
            "内容": f"今日营收完成率仅{metrics['营收']['完成率']}%，需加强促销"
        })
    
    if metrics['客单价']['状态'] == "偏低":
        warnings.append({
            "类型": "客单价预警",
            "等级": "低",
            "内容": "客单价偏低，建议推高毛利菜品"
        })
    
    if metrics['等位']['状态'] == "繁忙":
        warnings.append({
            "类型": "等位预警",
            "等级": "高",
            "内容": f"当前等位{metrics['等位']['当前']}桌，建议加派人手"
        })
    
    if not warnings:
        warnings.append({"类型": "无预警", "等级": "-", "内容": "各项指标正常"})
    
    return warnings


def _generate_comparison(metrics: Dict) -> Dict[str, str]:
    """生成环比对比"""
    return {
        "同比昨日": "+5.2%" if metrics['营收']['完成率'] >= 90 else "-3.1%",
        "环比上周": "+8.5%",
        "同比上月": "+12.3%"
    }


def system_integration(
    集成类型: str = "overview",
    现有系统: str = ""
) -> Dict[str, Any]:
    """
    系统集成对接
    
    根据需求生成系统集成方案
    
    Args:
        集成类型: 概览/POS会员/POS供应链/外卖平台
        现有系统: 已有系统描述，如"使用美团收银，有赞会员"
    
    Returns:
        集成方案、API文档、自动化流程
    """
    overview = {
        "常用系统": {
            "POS系统": ["美团餐饮", "客如云", "二维火", "哗啦啦"],
            "会员系统": ["企微会员", "有赞", "微盟", "银豹"],
            "外卖平台": ["美团外卖", "饿了么", "抖音外卖"],
            "供应链": ["美菜", "鲜易达", "自建供应链"]
        },
        "集成优先级": [
            "1. POS + 外卖平台（必须）",
            "2. POS + 会员系统（推荐）",
            "3. 供应链对接（进阶）"
        ]
    }
    
    solutions = {
        "POS会员": {
            "方案": "打通POS收银与会员系统",
            "好处": ["消费自动积分", "会员识别", "优惠券核销"],
            "推荐组合": ["美团餐饮+企微会员", "客如云+有赞"]
        },
        "POS供应链": {
            "方案": "打通门店订货与供应商系统",
            "好处": ["自动订货", "库存同步", "成本自动核算"],
            "推荐组合": ["哗啦啦+美菜"]
        },
        "外卖平台": {
            "方案": "对接美团/饿了么外卖",
            "好处": ["订单自动同步", "库存统一管理", "评价聚合"],
            "注意事项": "需申请接口权限，流程约2周"
        }
    }
    
    return {
        "generated_time": datetime.now().strftime("%Y-%m-%d"),
        "集成类型": 集成类型,
        "现有系统": 现有系统,
        
        "集成概览": overview,
        
        "推荐方案": solutions.get(集成类型, overview),
        
        "实施步骤": [
            "1. 确认需求和现有系统",
            "2. 选择合适的系统组合",
            "3. 联系供应商咨询",
            "4. 安排技术对接",
            "5. 测试上线",
            "6. 培训使用"
        ],
        
        "注意事项": [
            "接口费用：各系统不同，需提前了解",
            "数据迁移：历史数据迁移需技术配合",
            "人员培训：上线前务必全员培训"
        ]
    }
