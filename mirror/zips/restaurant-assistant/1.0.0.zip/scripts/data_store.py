# -*- coding: utf-8 -*-
"""
数据积累与连贯性模块
提供跨调用的数据持久化，让每次交互不再是"孤儿"
支持：经营数据积累、问题追踪、综合分析、趋势对比

作者：郝多鱼
版本：1.0.1
"""

import json
import os
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
from collections import defaultdict
import statistics

# 数据存储路径
DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data")


def _ensure_data_dir():
    """确保数据目录存在"""
    os.makedirs(DATA_DIR, exist_ok=True)


def _read_json(filename: str) -> Any:
    """读取JSON文件"""
    filepath = os.path.join(DATA_DIR, filename)
    if not os.path.exists(filepath):
        return None
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError):
        return None


def _write_json(filename: str, data: Any):
    """写入JSON文件"""
    _ensure_data_dir()
    filepath = os.path.join(DATA_DIR, filename)
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def record_business_data(
    store_name: str,
    data_type: str,
    data: Dict[str, Any],
    timestamp: str = ""
) -> Dict[str, Any]:
    """
    记录经营数据，建立数据积累

    Args:
        store_name: 门店名称
        data_type: 数据类型，如 "dashboard"(经营驾驶舱)、"order"(订货)、"inspection"(巡检)、
                         "food_safety"(食安)、"finance"(财务)、"marketing"(营销)、"hr"(人资)
        data: 要记录的数据字典
        timestamp: 时间戳（可选，默认当前时间）

    Returns:
        记录确认信息
    """
    ts = timestamp or datetime.now().strftime("%Y-%m-%d %H:%M")
    date_key = datetime.now().strftime("%Y-%m-%d")

    # 读取现有记录
    history = _read_json("business_history.json") or []

    # 添加新记录
    record = {
        "timestamp": ts,
        "date": date_key,
        "store_name": store_name,
        "data_type": data_type,
        "data": data
    }
    history.append(record)

    # 保留最近500条记录（防止文件过大）
    if len(history) > 500:
        history = history[-500:]

    _write_json("business_history.json", history)

    # 更新门店摘要
    _update_store_summary(store_name, data_type, data, ts)

    return {
        "status": "已记录",
        "store": store_name,
        "data_type": data_type,
        "timestamp": ts,
        "累计记录数": len(history)
    }


def _update_store_summary(store_name: str, data_type: str, data: Dict, ts: str):
    """更新门店摘要信息"""
    summary = _read_json("store_summary.json") or {}

    if store_name not in summary:
        summary[store_name] = {
            "首次记录": ts,
            "最近记录": ts,
            "总记录数": 0,
            "数据类型统计": defaultdict(int),
            "最近问题": [],
            "经营快照": {}
        }

    store = summary[store_name]
    store["最近记录"] = ts
    store["总记录数"] = store.get("总记录数", 0) + 1
    store["数据类型统计"][data_type] = store.get("数据类型统计", {}).get(data_type, 0) + 1

    # 保存经营快照（最近一次各类型数据）
    if "经营快照" not in store:
        store["经营快照"] = {}
    store["经营快照"][data_type] = {
        "timestamp": ts,
        "data": data
    }

    _write_json("store_summary.json", summary)


def get_store_summary(store_name: str) -> Dict[str, Any]:
    """
    获取门店综合摘要

    Args:
        store_name: 门店名称

    Returns:
        该门店的历史数据摘要和综合分析
    """
    summary = _read_json("store_summary.json") or {}
    if store_name not in summary:
        return {
            "store_name": store_name,
            "status": "暂无历史数据",
            "suggestion": "请先使用各功能模块记录数据，系统会自动积累和分析"
        }

    store = summary[store_name]
    history = _read_json("business_history.json") or []
    store_records = [r for r in history if r.get("store_name") == store_name]

    # 按数据类型分组
    by_type = defaultdict(list)
    for r in store_records:
        by_type[r["data_type"]].append(r)

    return {
        "store_name": store_name,
        "首次记录": store["首次记录"],
        "最近记录": store["最近记录"],
        "总记录数": store["总记录数"],
        "数据类型统计": dict(store.get("数据类型统计", {})),
        "各类型记录数": {k: len(v) for k, v in by_type.items()},
        "经营快照": store.get("经营快照", {}),
        "历史问题": _summarize_issues(store_records)
    }


def get_all_stores_overview() -> Dict[str, Any]:
    """
    获取所有门店概览

    Returns:
        所有门店的汇总数据和综合分析
    """
    summary = _read_json("store_summary.json") or {}
    history = _read_json("business_history.json") or []

    if not summary:
        return {
            "status": "暂无任何数据",
            "total_records": len(history),
            "suggestion": "请先使用各功能模块记录数据，系统会自动积累和分析"
        }

    stores = {}
    for name, info in summary.items():
        stores[name] = {
            "总记录数": info["总记录数"],
            "最近记录": info["最近记录"],
            "数据类型统计": dict(info.get("数据类型统计", {})),
            "历史问题": _summarize_issues(
                [r for r in history if r.get("store_name") == name]
            )
        }

    return {
        "门店数量": len(stores),
        "总记录数": len(history),
        "数据时间跨度": f"{history[0]['timestamp']} ~ {history[-1]['timestamp']}" if history else "无",
        "各门店概览": stores,
        "综合分析": _cross_store_analysis(history)
    }


def _summarize_issues(records: List[Dict]) -> List[Dict]:
    """从历史记录中提取和汇总问题"""
    issues = []
    for r in records:
        data = r.get("data", {})
        data_type = r.get("data_type", "")

        # 从不同类型的记录中提取问题
        if data_type == "food_safety":
            problem_list = data.get("问题清单", [])
            if isinstance(problem_list, list):
                for item in problem_list:
                    if isinstance(item, dict) and "问题描述" in item:
                        issues.append({
                            "时间": r["timestamp"],
                            "类型": "食安问题",
                            "问题": item["问题描述"],
                            "严重程度": item.get("风险等级", "中"),
                            "状态": item.get("状态", "待处理")
                        })
        elif data_type == "inspection":
            issue_list = data.get("issues", [])
            for item in issue_list:
                if isinstance(item, dict) and "desc" in item:
                    issues.append({
                        "时间": r["timestamp"],
                        "类型": "巡店问题",
                        "问题": item["desc"],
                        "严重程度": item.get("severity", "中"),
                        "状态": "待整改"
                    })
        elif data_type == "dashboard":
            warnings = data.get("预警中心", [])
            for w in warnings:
                if isinstance(w, dict):
                    issues.append({
                        "时间": r["timestamp"],
                        "类型": "经营预警",
                        "问题": w.get("内容", w.get("类型", "")),
                        "严重程度": w.get("等级", "中"),
                        "状态": "待处理"
                    })

    # 按严重程度排序
    severity_order = {"高": 0, "critical": 0, "中": 1, "medium": 1, "低": 2, "low": 2}
    issues.sort(key=lambda x: severity_order.get(x.get("严重程度", ""), 2))

    return issues[-20:]  # 最近20条


def _cross_store_analysis(history: List[Dict]) -> Dict[str, Any]:
    """跨门店综合分析"""
    if len(history) < 2:
        return {"status": "数据不足，至少需要2条记录才能进行综合分析"}

    # 统计数据类型分布
    type_counts = defaultdict(int)
    store_counts = defaultdict(int)
    for r in history:
        type_counts[r["data_type"]] += 1
        store_counts[r["store_name"]] += 1

    # 问题趋势
    issues_over_time = defaultdict(int)
    for r in history:
        data = r.get("data", {})
        # 统计各类问题数量
        if "问题清单" in data and isinstance(data["问题清单"], list):
            issues_over_time[r["date"]] += len([i for i in data["问题清单"] if isinstance(i, dict)])
        if "issues" in data and isinstance(data["issues"], list):
            issues_over_time[r["date"]] += len(data["issues"])
        if "预警中心" in data and isinstance(data["预警中心"], list):
            issues_over_time[r["date"]] += len(data["预警中心"])

    # 提取最近趋势
    dates = sorted(issues_over_time.keys())[-7:]  # 最近7天
    trend_data = [(d, issues_over_time[d]) for d in dates]

    # 判断趋势方向
    trend_direction = "持平"
    if len(trend_data) >= 2:
        recent = sum(v for _, v in trend_data[-3:])
        earlier = sum(v for _, v in trend_data[:-3]) if len(trend_data) > 3 else recent
        if recent < earlier:
            trend_direction = "改善（问题减少）"
        elif recent > earlier:
            trend_direction = "恶化（问题增多）"

    return {
        "最活跃门店": max(store_counts, key=store_counts.get) if store_counts else "无",
        "最关注的数据类型": max(type_counts, key=type_counts.get) if type_counts else "无",
        "数据类型分布": dict(type_counts),
        "门店活跃度排名": sorted(
            [{"门店": k, "记录数": v} for k, v in store_counts.items()],
            key=lambda x: x["记录数"], reverse=True
        ),
        "问题趋势（最近7天）": trend_data,
        "趋势判断": trend_direction,
        "建议": _generate_analysis_suggestions(type_counts, issues_over_time, trend_direction)
    }


def _generate_analysis_suggestions(
    type_counts: Dict[str, int],
    issues_over_time: Dict[str, int],
    trend: str
) -> List[str]:
    """根据数据积累生成综合建议"""
    suggestions = []

    if not type_counts:
        return ["建议开始使用各功能模块记录经营数据"]

    # 根据数据覆盖情况给建议
    modules_used = set(type_counts.keys())
    all_modules = {"dashboard", "food_safety", "finance", "inspection", "marketing", "hr", "order"}
    missing = all_modules - modules_used

    if missing:
        missing_names = {
            "dashboard": "经营驾驶舱",
            "food_safety": "食品安全巡检",
            "finance": "财务报表",
            "inspection": "门店巡检",
            "marketing": "营销活动",
            "hr": "人事管理",
            "order": "采购订货"
        }
        names = [missing_names.get(m, m) for m in list(missing)[:3]]
        suggestions.append(f"建议补充使用：{'、'.join(names)}，让数据更全面")

    # 根据趋势给建议
    if trend == "恶化（问题增多）":
        suggestions.append("近期问题呈增多趋势，建议重点关注食品安全和门店巡检")
    elif trend == "改善（问题减少）":
        suggestions.append("近期问题呈减少趋势，说明管理改善措施有效，继续保持")

    # 根据使用频率给建议
    if type_counts.get("dashboard", 0) < 3:
        suggestions.append("建议每日使用经营驾驶舱记录经营数据，建立完整的经营档案")

    if type_counts.get("food_safety", 0) > type_counts.get("inspection", 0) * 2:
        suggestions.append("食安巡检频率较高，但巡店记录较少，建议加强日常门店巡检")

    return suggestions


def clear_store_data(store_name: str = "") -> Dict[str, Any]:
    """
    清除门店数据

    Args:
        store_name: 门店名称（为空则清除所有数据）

    Returns:
        清除确认信息
    """
    if store_name:
        summary = _read_json("store_summary.json") or {}
        if store_name in summary:
            del summary[store_name]
            _write_json("store_summary.json", summary)

        history = _read_json("business_history.json") or []
        remaining = [r for r in history if r.get("store_name") != store_name]
        _write_json("business_history.json", remaining)

        return {"status": "已清除", "store": store_name, "removed_count": len(history) - len(remaining)}
    else:
        _write_json("store_summary.json", {})
        _write_json("business_history.json", [])
        return {"status": "已清除所有数据"}


def get_comprehensive_report(store_name: str = "") -> Dict[str, Any]:
    """
    生成综合经营报告（基于积累的历史数据）

    Args:
        store_name: 门店名称（为空则生成全部门店的综合报告）

    Returns:
        综合报告，包含历史趋势、问题分析、改进建议
    """
    history = _read_json("business_history.json") or []

    if not history:
        return {
            "report_title": "综合经营报告",
            "generated_time": datetime.now().strftime("%Y-%m-%d %H:%M"),
            "status": "暂无数据积累",
            "suggestion": "请先使用各功能模块记录经营数据。每次使用功能后数据会自动积累，多使用几次后即可生成有价值的综合报告。"
        }

    if store_name:
        records = [r for r in history if r.get("store_name") == store_name]
        if not records:
            return {
                "report_title": f"{store_name} 综合经营报告",
                "generated_time": datetime.now().strftime("%Y-%m-%d %H:%M"),
                "status": "该门店暂无历史数据",
                "suggestion": "请先为该门店使用各功能模块记录数据"
            }
    else:
        records = history

    # 分析历史记录
    all_issues = _summarize_issues(records)

    # 按日期统计
    daily_counts = defaultdict(int)
    for r in records:
        daily_counts[r["date"]] += 1

    dates = sorted(daily_counts.keys())
    # 获取连续记录天数
    consecutive_days = 0
    today = datetime.now()
    for i in range(len(dates)):
        check_date = today - timedelta(days=i)
        if check_date.strftime("%Y-%m-%d") in daily_counts:
            consecutive_days += 1
        else:
            break

    # 生成报告
    report = {
        "report_title": f"{store_name} 综合经营报告" if store_name else "全部门店综合经营报告",
        "generated_time": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "数据概览": {
            "总记录数": len(records),
            "数据时间跨度": f"{records[0]['date']} ~ {records[-1]['date']}" if records else "无",
            "连续记录天数": consecutive_days,
            "覆盖数据类型": len(set(r["data_type"] for r in records))
        },
        "问题追踪": {
            "历史问题总数": len(all_issues),
            "高优先级问题": len([i for i in all_issues if i.get("严重程度") in ["高", "critical"]]),
            "中优先级问题": len([i for i in all_issues if i.get("严重程度") in ["中", "medium"]]),
            "最近问题": all_issues[-10:]
        },
        "数据使用情况": {
            "各类型使用次数": dict(
                defaultdict(int, {r["data_type"]: 0 for r in records})
            ),
            "各类型详细": {}
        },
        "改进建议": [],
        "数据成熟度": "初级"
    }

    # 统计各类型使用次数
    type_usage = defaultdict(int)
    for r in records:
        type_usage[r["data_type"]] += 1
    report["数据使用情况"]["各类型使用次数"] = dict(type_usage)

    # 数据成熟度评估
    coverage = len(type_usage) / 7 * 100  # 7个主要数据类型
    if coverage >= 80 and len(records) >= 20:
        report["数据成熟度"] = "成熟"
    elif coverage >= 50 and len(records) >= 10:
        report["数据成熟度"] = "成长中"
    elif coverage >= 20:
        report["数据成熟度"] = "起步中"
    else:
        report["数据成熟度"] = "初级"

    # 生成改进建议
    if all_issues:
        high_priority = [i for i in all_issues if i.get("严重程度") in ["高", "critical"]]
        if high_priority:
            report["改进建议"].append(f"有 {len(high_priority)} 个高优先级问题需要立即处理")

    if coverage < 50:
        report["改进建议"].append("数据覆盖还不够全面，建议多使用不同功能模块来积累更多维度的数据")

    if consecutive_days < 3:
        report["改进建议"].append("建议养成每日记录的习惯，连续的数据才能看出趋势")

    if report["数据成熟度"] == "成熟":
        report["改进建议"].append("数据积累已较充分，可以进行深度分析和趋势预测")

    return report
