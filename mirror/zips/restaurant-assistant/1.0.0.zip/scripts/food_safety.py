# -*- coding: utf-8 -*-
"""
食安链路模块
包含：食安巡检、合规文档
作者：郝多鱼
版本：1.0.0
"""

from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
import random
import re


def food_safety_inspection(
    店铺类型: str,
    巡检数据: str = "",
    巡检类型: str = "综合巡检"
) -> Dict[str, Any]:
    """
    食安巡检助手
    
    根据用户输入的巡检数据，生成检查报告和整改建议
    
    Args:
        店铺类型: 如"火锅店"、"奶茶店"、"川菜馆"
        巡检数据: 巡检发现的问题，如"P01健康证过期，P03后厨有积水"
        巡检类型: 综合巡检/日常巡检/专项巡检
    
    Returns:
        检查清单、问题记录、整改任务
    """
    # 解析巡检数据
    findings = _parse_inspection_findings(巡检数据)
    
    # 生成检查报告
    report = _generate_inspection_report(店铺类型, findings, 巡检类型)
    
    return report


def _parse_inspection_findings(data: str) -> List[Dict]:
    """解析巡检发现"""
    if not data or not data.strip():
        return []
    
    findings = []
    # 支持多种格式：P01-过期、C02-不达标 等
    patterns = [
        r'([A-Z]\d{2})[-：:](.+)',
        r'([A-Z]\d{2})\s+(.+)',
    ]
    
    for pattern in patterns:
        matches = re.findall(pattern, data)
        for match in matches:
            code, desc = match
            findings.append({
                "code": code,
                "description": desc.strip(),
                "category": _get_code_category(code)
            })
    
    return findings


def _get_code_category(code: str) -> str:
    """根据代码获取类别"""
    categories = {
        "P": "人员卫生",
        "S": "储存管理",
        "C": "加工操作",
        "L": "清洁消毒",
        "E": "环境设施"
    }
    prefix = code[0] if code else "O"
    return categories.get(prefix, "其他")


def _generate_inspection_report(store_type: str, findings: List[Dict], inspection_type: str) -> Dict[str, Any]:
    """生成巡检报告"""
    inspection_id = f"FSI{datetime.now().strftime('%Y%m%d%H%M%S')}"
    
    # 问题分类
    issues_by_category = {}
    for f in findings:
        cat = f.get("category", "其他")
        if cat not in issues_by_category:
            issues_by_category[cat] = []
        issues_by_category[cat].append(f)
    
    # 风险等级判断
    high_risk_codes = ["P01", "S01", "S02", "C01", "E01"]  # 关键项
    high_risk_issues = [f for f in findings if f.get("code") in high_risk_codes]
    
    severity = "高" if high_risk_issues else ("中" if findings else "低")
    
    # 评分计算（假设100分基准）
    base_score = 100
    for f in findings:
        code = f.get("code", "")
        if code in high_risk_codes:
            base_score -= 15
        else:
            base_score -= 8
    
    score = max(0, base_score)
    
    # 等级评定
    if score >= 95:
        grade = "A"
        grade_desc = "优秀"
    elif score >= 85:
        grade = "B"
        grade_desc = "良好"
    elif score >= 75:
        grade = "C"
        grade_desc = "合格"
    else:
        grade = "D"
        grade_desc = "不合格，需整改"
    
    return {
        "generated_time": datetime.now().strftime("%Y-%m-%d"),
        "inspection_id": inspection_id,
        "店铺类型": store_type,
        "巡检类型": inspection_type,
        
        "巡检概况": {
            "检查项目总数": _count_checklist_items(_get_checklist_template(store_type)),
            "发现问题数": len(findings),
            "高风险问题数": len(high_risk_issues),
            "综合评分": score,
            "等级评定": f"{grade}级（{grade_desc}）"
        },
        
        "检查清单": _get_checklist_template(store_type),
        
        "问题清单": [
            {
                "编号": i + 1,
                "代码": f.get("code", "-"),
                "类别": f.get("category", "其他"),
                "问题描述": f.get("description", ""),
                "风险等级": "高" if f.get("code") in high_risk_codes else "中",
                "整改期限": "24小时" if f.get("code") in high_risk_codes else "3天",
                "负责人": "店长/厨师长"
            }
            for i, f in enumerate(findings)
        ] if findings else [{"状态": "本次巡检未发现问题，继续保持！"}],
        
        "按类别汇总": issues_by_category if issues_by_category else {"状态": "无异常"},
        
        "整改任务": _generate_rectification_tasks(findings, high_risk_codes),
        
        "后续跟踪": {
            "复检日期": (datetime.now() + timedelta(days=7)).strftime("%Y-%m-%d"),
            "负责人": "食品安全管理员",
            "升级机制": "未按期整改将上报公司处理"
        },
        
        "改进建议": _generate_improvement_suggestions(issues_by_category, store_type)
    }


def _count_checklist_items(checklist) -> int:
    """统计检查清单中所有检查项的总数"""
    if isinstance(checklist, dict):
        return sum(len(items) for items in checklist.values())
    return len(checklist) if checklist else 0


def _get_checklist_template(store_type: str) -> Dict[str, Any]:
    """获取检查清单模板"""
    # 店铺类型对应的检查重点
    type_focus = {
        "火锅店": ["食材新鲜度", "锅底配制", "餐具消毒", "通风系统"],
        "奶茶店": ["原料效期", "制作卫生", "设备清洁", "操作规范"],
        "川菜馆": ["食材储存", "辣度把控", "后厨卫生", "用油质量"],
        "烧烤店": ["肉类腌制", "炭火安全", "油烟排放", "通风消防"],
        "快餐店": ["出餐速度", "标准化操作", "保温措施", "包装卫生"]
    }
    
    focus = type_focus.get(store_type, ["基础卫生", "食材管理", "操作规范"])
    
    return {
        "人员卫生": {
            "P01": "健康证持证率100%",
            "P02": "个人卫生习惯良好",
            "P03": "手部清洁消毒到位"
        },
        "储存管理": {
            "S01": "冷藏温度0-4°C",
            "S02": "冷冻温度<-18°C",
            "S03": "生熟分开存放",
            "S04": "先进先出执行"
        },
        "加工操作": {
            "C01": "烧熟煮透中心温度≥75°C",
            "C02": "添加剂专人管理",
            "C03": "交叉污染防控到位"
        },
        "清洁消毒": {
            "L01": "餐具消毒柜正常使用",
            "L02": "消毒浓度符合标准",
            "L03": "清洁工具分类使用"
        },
        "环境设施": {
            "E01": "三防设施完备",
            "E02": "通风换气正常",
            "E03": "下水道无异味",
            "E04": "废弃物容器带盖"
        }
    }


def _generate_rectification_tasks(findings: List[Dict], high_risk_codes: List[str]) -> List[Dict]:
    """生成整改任务"""
    if not findings:
        return [{"任务": "继续保持", "期限": "日常", "状态": "进行中"}]
    
    tasks = []
    for f in findings:
        is_high_risk = f.get("code") in high_risk_codes
        tasks.append({
            "问题": f.get("description", ""),
            "整改措施": _get_rectification_measure(f.get("code", "")),
            "期限": "24小时" if is_high_risk else "3天",
            "负责人": "店长" if is_high_risk else "相关岗位",
            "优先级": "高" if is_high_risk else "中",
            "状态": "待整改"
        })
    
    return tasks


def _get_rectification_measure(code: str) -> str:
    """获取整改措施"""
    measures = {
        "P01": "立即检查全员健康证，过期或缺失需在3天内补办",
        "P02": "加强个人卫生培训，落实穿戴规范",
        "P03": "增设手部消毒点，纳入每日检查项",
        "S01": "检查制冷设备温度，调整至标准范围",
        "S02": "检查冷冻设备，确保温度达标",
        "S03": "重新规划储物空间，生熟严格分区",
        "S04": "完善出入库记录，执行先进先出",
        "C01": "配备温度计，确保出品达标",
        "C02": "设立添加剂专用柜，双人管理制度",
        "C03": "重新培训分区操作规范",
        "L01": "检查消毒柜运行状态，维修或更换",
        "L02": "重新配制消毒液，浓度试纸检测",
        "L03": "更换清洁工具，明确分类标识",
        "E01": "增设防鼠防蝇设施",
        "E02": "清洁或维修通风设备",
        "E03": "彻底清洁下水道，消除异味源",
        "E04": "更换带盖垃圾桶"
    }
    return measures.get(code, "对照标准整改，加强培训")


def _generate_improvement_suggestions(issues_by_category: Dict, store_type: str) -> List[str]:
    """生成改进建议"""
    suggestions = []
    
    if "人员卫生" in issues_by_category:
        suggestions.append("【人员管理】加强晨检制度，定期组织食品安全培训")
    if "储存管理" in issues_by_category:
        suggestions.append("【储存管理】完善出入库系统，加强效期管理培训")
    if "加工操作" in issues_by_category:
        suggestions.append("【加工操作】优化操作流程，关键节点配置检查表")
    if "清洁消毒" in issues_by_category:
        suggestions.append("【清洁消毒】建立清洁轮值制度，专人监督执行")
    if "环境设施" in issues_by_category:
        suggestions.append("【环境设施】定期维护保养设施设备，建立检查台账")
    
    if not suggestions:
        suggestions.append("【持续保持】食安工作落实到位，继续保持！")
        suggestions.append(f"【精细化管理】针对{store_type}特点，可进一步优化以下方面：")
        suggestions.append("- 强化关键风险点管控")
        suggestions.append("- 定期开展食安应急演练")
        suggestions.append("- 建立员工食安考核机制")
    
    return suggestions


def compliance_documents(
    店铺类型: str,
    文档类型: str = "自查清单",
    店铺信息: str = ""
) -> Dict[str, Any]:
    """
    食安合规文档
    
    根据店铺类型和需求，生成合规文档
    
    Args:
        店铺类型: 如"火锅店"、"奶茶店"
        文档类型: 自查清单/许可证办理/应急预案/培训记录
        店铺信息: 店铺相关信息，如"面积200平，员工15人"
    
    Returns:
        合规文档内容
    """
    docs = {
        "自查清单": _generate_self_check_list(店铺类型, 店铺信息),
        "许可证办理": _generate_license_guide(店铺类型),
        "应急预案": _generate_emergency_plan(店铺类型),
        "培训记录": _generate_training_record()
    }
    
    return {
        "generated_time": datetime.now().strftime("%Y-%m-%d"),
        "店铺类型": 店铺类型,
        "文档类型": 文档类型,
        
        "文档内容": docs.get(文档类型, docs["自查清单"]),
        
        "使用说明": "本文档为标准模板，请根据实际情况填写和使用"
    }


def _generate_self_check_list(store_type: str, store_info: str) -> Dict[str, Any]:
    """生成自查清单"""
    # 提取面积信息
    area_match = re.search(r'(\d+)\s*[平方]*', store_info)
    area = int(area_match.group(1)) if area_match else 200
    
    return {
        "文档标题": f"{store_type}食品安全自查清单",
        "检查频率": "每日/每周/每月",
        
        "每日自查": [
            "☐ 员工健康证均在有效期内",
            "☐ 晨检记录完整（体温/健康状况）",
            "☐ 原材料感官检查正常",
            "☐ 冷藏冷冻温度达标",
            "☐ 加工区域清洁",
            "☐ 餐具消毒记录完整",
            "☐ 垃圾日产日清"
        ],
        
        "每周自查": [
            "☐ 库存原材料效期检查",
            "☐ 清洁消毒效果检查",
            "☐ 设备维护保养检查",
            "☐ 防护设施完好性检查"
        ],
        
        "每月自查": [
            "☐ 食品安全培训完成",
            "☐ 全面清洁消毒",
            "☐ 供应商资质复核",
            "☐ 消防设施检查",
            "☐ 证照有效期检查"
        ],
        
        "附件": {
            "晨检表": "员工姓名-日期-体温-健康状况-检查人",
            "温度记录表": "日期-时间-冷藏温度-冷冻温度-记录人",
            "消毒记录表": "日期-消毒对象-消毒方式-浓度-执行人"
        }
    }


def _generate_license_guide(store_type: str) -> Dict[str, Any]:
    """生成许可证办理指南"""
    return {
        "文档标题": "餐饮许可证办理指南",
        "有效期": "4年（每年需年审）",
        
        "所需材料": {
            "基础材料": [
                "1. 营业执照原件及复印件",
                "2. 法人身份证原件及复印件",
                "3. 房产证或租赁合同原件及复印件",
                "4. 门店平面图"
            ],
            "人员材料": [
                "1. 食品安全管理员证书",
                "2. 员工健康证（全员）"
            ],
            "设施材料": [
                "1. 厨房布局图",
                "2. 油烟净化设备证明",
                "3. 污水处理设备证明",
                "4. 消防验收证明"
            ]
        },
        
        "办理流程": [
            "Step 1: 准备材料（约3-5天）",
            "Step 2: 网上申请/现场提交",
            "Step 3: 现场核查（约15个工作日）",
            "Step 4: 整改完善（如需）",
            "Step 5: 领取许可证"
        ],
        
        "注意事项": [
            "1. 面积≥50㎡需办理食品经营许可证",
            "2. 小餐饮可申请小餐饮登记证",
            "3. 火锅店需额外配置通风系统",
            "4. 奶茶店需制冰设备符合标准"
        ],
        
        "有效期提醒": {
            "营业执照": "长期（到期换发）",
            "食品经营许可证": "4年（提前30天续期）",
            "健康证": "1年（全员）",
            "消防安全": "1年（年度检查）"
        }
    }


def _generate_emergency_plan(store_type: str) -> Dict[str, Any]:
    """生成应急预案"""
    return {
        "文档标题": "食品安全应急预案",
        "版本号": "V1.0",
        
        "一、食物中毒处置": {
            "发生情形": "顾客出现恶心/呕吐/腹泻等疑似食物中毒症状",
            "处置步骤": [
                "1. 立即停止供餐，保留可疑食品",
                "2. 拨打120救治患者",
                "3. 保护现场，禁止人员进出",
                "4. 立即报告店长/总部",
                "5. 配合监管部门调查",
                "6. 内部彻查原因，整改落实"
            ],
            "责任分工": {
                "店长": "现场指挥、报告上级",
                "员工": "执行指示、配合调查",
                "厨师长": "封存食材、协助排查"
            }
        },
        
        "二、火灾应急": {
            "处置步骤": [
                "1. 立即切断电源/气源",
                "2. 使用灭火器扑灭初期火灾",
                "3. 拨打119报警",
                "4. 组织顾客有序疏散",
                "5. 确认人员全部撤离",
                "6. 协助消防部门调查"
            ],
            "疏散路线": "后厨→前厅→正门→安全区域"
        },
        
        "三、舆情危机": {
            "触发条件": "出现食品安全投诉/曝光",
            "处置步骤": [
                "1. 30分钟内响应，诚恳道歉",
                "2. 了解情况，承诺处理",
                "3. 内部调查，公布结果",
                "4. 联系平台删除不实信息",
                "5. 持续跟进，挽回声誉"
            ]
        },
        
        "紧急联系电话": {
            "急救": "120",
            "火警": "119",
            "报警": "110",
            "市场监管": "12315",
            "公司总部": "[填写]"
        }
    }


def _generate_training_record() -> Dict[str, Any]:
    """生成培训记录模板"""
    return {
        "文档标题": "食品安全培训记录表",
        
        "培训项目": "餐饮食品安全基础知识",
        "培训时长": "2小时",
        "培训方式": "理论+实操",
        
        "培训内容": [
            "1. 食品安全法律法规",
            "2. 食品安全基础知识",
            "3. 个人卫生与健康",
            "4. 食材储存与保鲜",
            "5. 加工操作规范",
            "6. 清洁消毒流程",
            "7. 应急处置方法"
        ],
        
        "考核方式": "笔试+实操",
        "合格标准": "80分及以上",
        
        "培训签到表": {
            "字段": ["姓名", "部门", "职位", "培训日期", "考核成绩", "签名"],
            "说明": "共__页，每页10人"
        },
        
        "培训效果评估": [
            "□ 理论知识掌握 □ 基本技能达标 □ 应急处置熟练",
            "□ 需补训 □ 合格"
        ]
    }
