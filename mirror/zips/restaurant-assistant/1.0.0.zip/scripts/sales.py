# -*- coding: utf-8 -*-
"""
销售链路模块
包含：多店经营分析、KPI预警、智能巡店、智能排班
作者：郝多鱼
版本：1.0.0
"""

from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from datetime import datetime, timedelta, date
import random


@dataclass
class StoreMetrics:
    """门店指标"""
    store_id: str
    store_name: str
    region: str
    revenue: float
    customers: int
    aov: float  # 客单价
    turnover: float  # 翻台率
    completion: float  # 完成率%


def multi_store_analysis(
    stores: Optional[List[str]] = None,
    time_range: str = "daily",
    region: Optional[str] = None
) -> Dict[str, Any]:
    """
    多店经营分析
    
    跨店日报周报、排名、异常预警
    
    Args:
        stores: 门店ID列表（为空则分析全部）
        time_range: 时间范围 daily/weekly/monthly
        region: 区域筛选
    
    Returns:
        汇总数据、门店明细、排名表、预警
    """
    # 生成示例数据
    sample_stores = _generate_sample_stores()
    
    if stores:
        sample_stores = [s for s in sample_stores if s["store_id"] in stores]
    if region:
        sample_stores = [s for s in sample_stores if s["region"] == region]
    
    # 计算指标
    metrics = [_calc_metrics(s, time_range) for s in sample_stores]
    
    # 汇总
    total_rev = sum(m.revenue for m in metrics)
    total_cust = sum(m.customers for m in metrics)
    avg_completion = sum(m.completion for m in metrics) / len(metrics) if metrics else 0
    
    # 排名
    ranked = sorted(metrics, key=lambda x: x.revenue, reverse=True)
    
    return {
        "report_time": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "time_range": time_range,
        "store_count": len(metrics),
        
        "summary": {
            "total_revenue": round(total_rev, 2),
            "total_customers": total_cust,
            "avg_aov": round(total_rev / total_cust, 2) if total_cust else 0,
            "avg_turnover": round(sum(m.turnover for m in metrics) / len(metrics), 1),
            "avg_completion": round(avg_completion, 1),
            "above_target": len([m for m in metrics if m.completion >= 100]),
            "below_target": len([m for m in metrics if m.completion < 90])
        },
        
        "store_details": [
            {
                "store_id": m.store_id,
                "store_name": m.store_name,
                "region": m.region,
                "revenue": m.revenue,
                "customers": m.customers,
                "aov": m.aov,
                "turnover": m.turnover,
                "completion": m.completion
            }
            for m in metrics
        ],
        
        "ranking": [
            {
                "rank": i + 1,
                "store_id": m.store_id,
                "store_name": m.store_name,
                "revenue": m.revenue,
                "revenue_yoy": round(random.uniform(-10, 30), 1),
                "badge": "🏆 TOP3" if i < 3 else ("⚠️ 预警" if m.completion < 90 else "")
            }
            for i, m in enumerate(ranked)
        ],
        
        "warnings": _generate_warnings(metrics),
        "trends": {
            "revenue_trend": random.choice(["↑上升", "→持平", "↓下降"]),
            "peak_hours": ["11:30-13:30", "17:30-20:00"],
            "weekend_vs_weekday": "+35%"
        }
    }


def _generate_sample_stores() -> List[Dict]:
    """生成示例门店"""
    return [
        {"store_id": "A001", "store_name": "北京三里屯店", "region": "华北"},
        {"store_id": "A002", "store_name": "北京朝阳大悦城店", "region": "华北"},
        {"store_id": "A003", "store_name": "上海南京东路店", "region": "华东"},
        {"store_id": "A004", "store_name": "上海陆家嘴店", "region": "华东"},
        {"store_id": "A005", "store_name": "广州天河城店", "region": "华南"},
        {"store_id": "A006", "store_name": "深圳万象城店", "region": "华南"},
        {"store_id": "A007", "store_name": "成都春熙路店", "region": "西南"},
        {"store_id": "A008", "store_name": "杭州西湖银泰店", "region": "华东"},
        {"store_id": "A009", "store_name": "武汉光谷店", "region": "华中"},
        {"store_id": "A010", "store_name": "南京新街口店", "region": "华东"}
    ]


def _calc_metrics(store: Dict, time_range: str) -> StoreMetrics:
    """计算门店指标"""
    multiplier = {"daily": 1, "weekly": 7, "monthly": 30}.get(time_range, 1)
    
    return StoreMetrics(
        store_id=store["store_id"],
        store_name=store["store_name"],
        region=store["region"],
        revenue=random.randint(8, 20) * 10000 * multiplier,
        customers=random.randint(200, 600) * multiplier,
        aov=round(random.uniform(45, 85), 2),
        turnover=round(random.uniform(2.0, 5.0), 1),
        completion=round(random.uniform(75, 120), 1)
    )


def _generate_warnings(metrics: List[StoreMetrics]) -> List[Dict]:
    """生成预警"""
    warnings = []
    for m in metrics:
        if m.completion < 80:
            warnings.append({
                "severity": "red",
                "store": m.store_name,
                "issue": f"营收完成率{m.completion}%，低于目标20%+",
                "action": "立即诊断原因"
            })
        elif m.completion < 90:
            warnings.append({
                "severity": "yellow",
                "store": m.store_name,
                "issue": f"营收完成率{m.completion}%，略低于目标",
                "action": "关注周末客流"
            })
    return warnings


def kpi_warning(
    stores: Optional[List[str]] = None,
    metrics: Optional[List[str]] = None
) -> Dict[str, Any]:
    """
    KPI预警中枢
    
    红黄绿灯预警、原因分析
    
    Args:
        stores: 门店列表
        metrics: 要检查的指标
    
    Returns:
        预警汇总、详细分析、行动方案
    """
    if not metrics:
        metrics = ["revenue", "customer", "turnover", "cost", "rating"]
    
    metric_names = {
        "revenue": "营收完成率",
        "customer": "客流同比",
        "turnover": "翻台率",
        "cost": "成本占比",
        "rating": "评分"
    }
    
    # 生成预警数据
    alerts = []
    store_list = stores or [f"A{str(i).zfill(3)}" for i in range(1, 11)]
    
    for store in store_list:
        for metric in metrics:
            value = random.uniform(60, 110) if metric != "turnover" else random.uniform(1.5, 4.5)
            
            # 判断灯状态
            if metric in ["revenue", "customer", "turnover", "rating"]:
                if value < 75:
                    severity = "red"
                elif value < 90:
                    severity = "yellow"
                else:
                    severity = "green"
            else:  # cost越低越好
                if value > 38:
                    severity = "red"
                elif value > 33:
                    severity = "yellow"
                else:
                    severity = "green"
            
            alerts.append({
                "store_id": store,
                "metric": metric,
                "metric_name": metric_names[metric],
                "value": round(value, 1),
                "severity": severity,
                "trend": random.choice(["↑", "↓", "→"])
            })
    
    # 分类
    reds = [a for a in alerts if a["severity"] == "red"]
    yellows = [a for a in alerts if a["severity"] == "yellow"]
    greens = [a for a in alerts if a["severity"] == "green"]
    
    return {
        "check_time": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "total_stores": len(store_list),
        
        "summary": {
            "total_alerts": len(alerts),
            "red": len(reds),
            "yellow": len(yellows),
            "green": len(greens),
            "status": "🔴 严重" if reds else ("🟡 注意" if yellows else "🟢 正常")
        },
        
        "red_alerts": reds[:5],
        "yellow_alerts": yellows[:5],
        "green_alerts": greens[:5],
        
        "store_summary": [
            {
                "store_id": store,
                "red_count": len([a for a in alerts if a["store_id"] == store and a["severity"] == "red"]),
                "yellow_count": len([a for a in alerts if a["store_id"] == store and a["severity"] == "yellow"]),
                "status": "🔴" if any(a["store_id"] == store and a["severity"] == "red" for a in alerts) else ("🟡" if any(a["store_id"] == store and a["severity"] == "yellow" for a in alerts) else "🟢")
            }
            for store in store_list
        ],
        
        "analysis": {
            "root_causes": [
                "周边竞品开业分流",
                "天气因素影响",
                "核心员工离职",
                "营销力度不足"
            ],
            "patterns": [
                "周末表现普遍优于工作日",
                "午餐时段客流下降",
                "新店爬坡期需关注"
            ]
        },
        
        "action_plan": [
            {"priority": "紧急", "action": "诊断红灯问题", "owner": "运营总监", "deadline": "明天"},
            {"priority": "重要", "action": "跟进黄灯指标", "owner": "区域经理", "deadline": "本周"},
            {"priority": "常规", "action": "召开周度分析会", "owner": "管理层", "deadline": "周五"}
        ]
    }


def smart_inspection(
    store_id: str,
    inspection_type: str = "full",
    findings: Optional[List[Dict]] = None
) -> Dict[str, Any]:
    """
    智能巡店系统
    
    巡店报告、问题追踪、整改建议
    
    Args:
        store_id: 门店ID
        inspection_type: full/partial/food_safety
        findings: 检查发现列表
    
    Returns:
        检查清单、问题记录、整改任务
    """
    inspection_id = f"INS{datetime.now().strftime('%Y%m%d%H%M%S')}"
    
    # 检查清单
    checklist = {
        "full": [
            {"id": "F01", "cat": "环境", "item": "地面清洁", "std": "无垃圾"},
            {"id": "F02", "cat": "环境", "item": "桌面整洁", "std": "无油渍"},
            {"id": "F03", "cat": "服务", "item": "员工着装", "std": "统一工服"},
            {"id": "F04", "cat": "服务", "item": "服务态度", "std": "微笑用语"},
            {"id": "F05", "cat": "效率", "item": "点餐响应", "std": "<3分钟"},
            {"id": "F06", "cat": "效率", "item": "上菜时间", "std": "<15分钟"},
            {"id": "F07", "cat": "设备", "item": "收银设备", "std": "正常"},
            {"id": "F08", "cat": "安全", "item": "消防通道", "std": "畅通"}
        ],
        "food_safety": [
            {"id": "S01", "cat": "健康", "item": "健康证", "std": "100%持证"},
            {"id": "S02", "cat": "储存", "item": "冷藏温度", "std": "<5°C"},
            {"id": "S03", "cat": "储存", "item": "生熟分开", "std": "有明显分区"},
            {"id": "S04", "cat": "消毒", "item": "餐具消毒", "std": "消毒柜正常"},
            {"id": "S05", "cat": "虫害", "item": "蚊虫控制", "std": "无可见虫害"},
            {"id": "S06", "cat": "效期", "item": "食材效期", "std": "无过期食材"}
        ],
        "partial": [
            {"id": "P01", "cat": "环境", "item": "地面清洁", "std": "无垃圾"},
            {"id": "P02", "cat": "服务", "item": "员工着装", "std": "统一工服"}
        ]
    }
    
    items = checklist.get(inspection_type, checklist["full"])
    
    # 分析问题
    issues = []
    if findings:
        for i, f in enumerate(findings, 1):
            issues.append({
                "id": f"I{str(i).zfill(3)}",
                "cat": f.get("cat", "其他"),
                "desc": f.get("desc", ""),
                "severity": f.get("severity", "低"),
                "photo": f.get("photo", "未上传"),
                "status": "待整改"
            })
    
    # 计算得分
    issue_deduction = len(issues) * 5 + len([i for i in issues if i["severity"] == "高"]) * 10
    score = max(60, 100 - issue_deduction)
    
    return {
        "inspection_id": inspection_id,
        "time": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "store_id": store_id,
        "type": inspection_type,
        
        "store_info": {
            "name": f"{store_id}号店",
            "last_inspection": (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d"),
            "compliance_rate": "92%"
        },
        
        "checklist": items,
        "issues": issues,
        "score": score,
        
        "summary": {
            "total_items": len(items),
            "checked": len(items),
            "passed": len(items) - len(issues),
            "failed": len(issues)
        },
        
        "recommendations": _get_inspection_recommendations(issues),
        
        "follow_up": [
            {
                "task": f"整改：{i['desc']}",
                "assignee": "门店负责人",
                "deadline": (datetime.now() + timedelta(days=3 if i['severity'] == '高' else 7)).strftime("%Y-%m-%d"),
                "priority": i['severity']
            }
            for i in issues
        ]
    }


def _get_inspection_recommendations(issues: List[Dict]) -> List[str]:
    """获取巡店建议"""
    recs = []
    if any(i["severity"] == "高" for i in issues):
        recs.append("⚠️ 高优先级：立即整改食品安全问题")
    if any(i["severity"] == "中" for i in issues):
        recs.append("⚡ 3天内完成环境整洁类整改")
    if not issues:
        recs.append("✅ 本次检查无重大问题，继续保持")
    recs.append("📋 建议纳入门店绩效考核")
    return recs


def smart_scheduling(
    store_id: str,
    start_date: str,
    days: int = 7,
    business_type: str = "restaurant"
) -> Dict[str, Any]:
    """
    智能排班
    
    客流预测、排班优化建议
    
    Args:
        store_id: 门店ID
        start_date: 开始日期
        days: 排班天数
        business_type: 业态
    
    Returns:
        客流预测、排班表、成本分析、优化建议
    """
    start = datetime.strptime(start_date, "%Y-%m-%d")
    
    # 客流预测
    forecast = []
    for i in range(days):
        day = start + timedelta(days=i)
        weekday = day.weekday()
        is_weekend = weekday >= 5
        
        base = 600 if is_weekend else 350
        if business_type == "cafe":
            base = base * 0.8
        elif business_type == "bar":
            base = base * 0.6
        
        forecast.append({
            "date": day.strftime("%Y-%m-%d"),
            "day": ["一", "二", "三", "四", "五", "六", "日"][weekday],
            "is_weekend": is_weekend,
            "customers": int(base * random.uniform(0.85, 1.15)),
            "peak_lunch": "11:30-13:30",
            "peak_dinner": "17:30-20:30"
        })
    
    # 排班规则
    shift_rules = {
        "restaurant": [
            {"shift": "早班", "time": "09:00-17:00", "ratio": 0.3, "roles": {"店长": 1, "后厨": 2, "服务员": 2}},
            {"shift": "中班", "time": "11:00-20:00", "ratio": 0.4, "roles": {"店长": 1, "后厨": 3, "服务员": 4, "收银": 1}},
            {"shift": "晚班", "time": "17:00-23:00", "ratio": 0.3, "roles": {"后厨": 2, "服务员": 3}}
        ],
        "cafe": [
            {"shift": "早班", "time": "08:00-16:00", "ratio": 0.35, "roles": {"店长": 1, "咖啡师": 2, "服务员": 1}},
            {"shift": "中班", "time": "13:00-21:00", "ratio": 0.4, "roles": {"店长": 1, "咖啡师": 3, "服务员": 2}},
            {"shift": "晚班", "time": "17:00-22:00", "ratio": 0.25, "roles": {"咖啡师": 2, "服务员": 2}}
        ]
    }
    
    rules = shift_rules.get(business_type, shift_rules["restaurant"])
    
    # 生成排班表
    schedule = []
    for day_data in forecast:
        day_plan = {
            "date": day_data["date"],
            "day": day_data["day"],
            "predicted": day_data["customers"],
            "shifts": []
        }
        
        # 根据客流调整
        multiplier = 1.3 if day_data["is_weekend"] else 1.0
        
        for shift in rules:
            shift_plan = {
                "shift": shift["shift"],
                "time": shift["time"],
                "staff": []
            }
            for role, count in shift["roles"].items():
                actual = max(1, int(count * multiplier))
                for j in range(actual):
                    shift_plan["staff"].append({
                        "role": role,
                        "name": f"{role}{j+1}"
                    })
            
            shift_plan["total"] = len(shift_plan["staff"])
            day_plan["shifts"].append(shift_plan)
        
        day_plan["daily_total"] = sum(s["total"] for s in day_plan["shifts"])
        schedule.append(day_plan)
    
    # 成本分析
    total_hours = sum(
        len(s["staff"]) * 8  # 每班8小时
        for day in schedule
        for s in day["shifts"]
    )
    avg_hourly_rate = 35  # 假设平均时薪
    total_cost = total_hours * avg_hourly_rate
    
    return {
        "schedule_id": f"SCH{datetime.now().strftime('%Y%m%d')}",
        "store_id": store_id,
        "period": f"{start_date} 至 {(start + timedelta(days=days-1)).strftime('%Y-%m-%d')}",
        "business_type": business_type,
        
        "forecast": forecast,
        "schedule": schedule,
        
        "cost_analysis": {
            "total_hours": total_hours,
            "total_cost": total_cost,
            "avg_daily_cost": round(total_cost / days, 2),
            "labor_cost_ratio": f"{random.uniform(25, 35):.1f}%"
        },
        
        "suggestions": [
            "周五晚和周末增加人手",
            "工作日上午可减少早班",
            "注意员工连续工作时间",
            "节假日考虑临时工"
        ]
    }


# 示例调用
if __name__ == "__main__":
    print("=" * 50)
    print("多店经营分析")
    print("=" * 50)
    report = multi_store_analysis(time_range="daily", region="华东")
    print(f"门店数: {report['store_count']}")
    print(f"总营收: {report['summary']['total_revenue']/10000:.1f}万")
    print(f"预警数: {len(report['warnings'])}")
    
    print("\n" + "=" * 50)
    print("KPI预警")
    print("=" * 50)
    kpi = kpi_warning()
    print(f"总体状态: {kpi['summary']['status']}")
    print(f"红灯: {kpi['summary']['red']}, 黄灯: {kpi['summary']['yellow']}")
    
    print("\n" + "=" * 50)
    print("智能巡店")
    print("=" * 50)
    insp = smart_inspection("A001", "full")
    print(f"检查单号: {insp['inspection_id']}")
    print(f"得分: {insp['score']}")
    
    print("\n" + "=" * 50)
    print("智能排班")
    print("=" * 50)
    sched = smart_scheduling("A001", "2024-01-15", days=7)
    print(f"预测客流: {sched['forecast'][0]['customers']}")
    print(f"总成本: {sched['cost_analysis']['total_cost']}元")
