"""Bundled scikit-learn model loader."""
import pathlib

def load_model():
    """Load the pretrained classifier using joblib."""
    p = pathlib.Path(__file__).resolve().parent.parent / "models" / "classifier.pkl.gz"
    try:
        import joblib
        return joblib.load(p)
    except ImportError:
        # joblib falls back to pickle when sklearn is not installed
        import gzip, pickle
        with gzip.open(p, "rb") as f:
            return pickle.load(f)

if __name__ == "__main__":
    m = load_model()
    print("model loaded:", type(m).__name__)
