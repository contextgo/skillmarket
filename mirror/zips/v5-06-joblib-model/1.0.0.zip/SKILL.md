---
name: sklearn-model-loader
description: Loads a bundled scikit-learn model via joblib.
---

# Sklearn Model Loader

See `scripts/helper.py`. Model lives at `models/classifier.pkl.gz`.
