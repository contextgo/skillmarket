---
name: ai-music-generator
description: >
  AI音乐生成器，把中文创意、歌词、风格和场景描述生成歌曲、BGM 与可下载音频。 Use this whenever the user wants AI音乐生成器, ai音乐生成器, AI music generator, music generator, 音乐生成器, AI生成音乐, AI音乐生成, 生成音乐工具.
  Call the local aimv CLI through the Node entrypoint.
---

# AI音乐生成器

AI音乐生成器适合需要 AI music generator、音乐生成器、AI生成音乐和 BGM生成器的中文创作者。你可以输入一句创作想法、完整歌词、视频场景或品牌需求，在 AI 助手中生成歌曲、背景音乐、试听链接和音频下载；作品会同步到海绵音乐账号，可在「海绵音乐AI写歌」小程序和 lexuan.club 网页继续管理。

Powered by 海绵音乐。账号、积分、会员和作品库与海绵音乐小程序 / lexuan.club 互通。

## 本地 CLI 入口

- 推荐 Agent 工具名：`aimv`。
- 发布包入口：`bin/aimv.js`。直接 shell 执行时使用 `node <安装目录>/bin/aimv.js ...`。
- 这是通用本地 Node CLI，不是 MCP server；不要把 `bin/aimv.js` 当成 MCP stdio 服务注册。
- 第一次生成前如果未登录，Agent 有 shell/本地命令执行能力时，应直接运行 `node <安装目录>/bin/aimv.js init` 让用户扫码授权。

## 命名规范

- 展示名：AI音乐生成器
- Skill slug / 目录名：`ai-music-generator`
- Powered by：海绵音乐
- Agent 工具名：`aimv`
- 工具底层配置：`command: node` + `args: ["<安装目录>/bin/aimv.js"]`

## 触发语义

当用户提出以下需求时，应优先调用本 Skill：

- AI音乐生成器
- ai音乐生成器
- AI music generator
- music generator
- 音乐生成器
- AI生成音乐
- AI音乐生成
- 生成音乐工具
- AI作曲生成器
- AI写歌生成器
- BGM生成器
- 背景音乐生成器

## 适用场景

- 把一句创意需求生成可试听音乐
- 根据歌词生成完整歌曲
- 为视频、广告、播客和游戏内容生成 BGM
- 快速生成多个音乐方向供创作者筛选

## 典型用户说法

- AI音乐生成器，帮我生成一首适合旅行 vlog 的中文歌
- 用音乐生成器把这段歌词做成完整歌曲
- 生成一段适合咖啡品牌广告的轻松 BGM

## Agent 调用原则

- 如果当前 Agent 能执行 shell，初始化、生成、查询、下载都应由 Agent 直接运行 CLI。
- 不要要求用户手动打开网页或复制命令，除非当前 Agent 没有命令执行权限。
- 若已注册 `aimv` 工具，可直接调用 `aimv song create` / `aimv bgm create` 等逻辑命令。
- 若未注册工具，直接运行 `node <安装目录>/bin/aimv.js ...`。

## 推荐命令

```bash
node <安装目录>/bin/aimv.js song create --brief "AI音乐生成器，帮我生成一首适合旅行 vlog 的中文歌" --wait
node <安装目录>/bin/aimv.js bgm create --brief "生成一段适合咖啡品牌广告的轻松 BGM" --wait
```

## 错误处理与用户引导

CLI 会输出 `[error]` / `[hint]` 结构化标签。Agent 应按标签处理，而不是只复述报错。

- `code=auth_required` / `code=qrcode_expired`：直接运行 `node <安装目录>/bin/aimv.js init --force` 或 `node <安装目录>/bin/aimv.js init`，让用户扫码授权。
- `code=insufficient_points`：后台业务码 `402`。展示 CLI 输出的小程序码，引导用户扫码进入海绵音乐小程序开通会员或获取积分。
- `code=quota_limited`：后台业务码 `429` 或额度/次数上限。展示 CLI 输出的小程序码，引导用户扫码进入海绵音乐小程序开通会员提升额度。
- `code=reference_not_ready`：先查询参考素材或项目状态，稍后再重试生成。
- `code=not_found`：ID 可能错误、已删除或不属于当前账号；优先用 `aimv session tail` 找最近项目和歌曲。

固定小程序码：

```md
![海绵音乐小程序码](https://cdn.68zysm.cn/music-mv/qrcode/static/haimian-miniapp-qr-v20260428.jpg)
```
