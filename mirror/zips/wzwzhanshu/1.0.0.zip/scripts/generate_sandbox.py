#!/usr/bin/env python3
"""
wzwzhanshu战术沙盘生成脚本 v1.0.0
"""

import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side

# 版本号
__version__ = "1.0.0"

# 固定openpyxl版本，防止恶意包攻击
assert openpyxl.__version__ >= "3.0.0", f"openpyxl版本需要>=3.0.0，当前版本{openpyxl.__version__}"

def create_tactical_sandbox(data, output_path="/Users/wangzhongwei/Desktop/战术沙盘_已完成.xlsx"):
    """
    生成战术沙盘Excel文件

    参数:
        data: 字典，包含业务流程和每个环节的量、技能、心态信息
        output_path: 输出文件路径

    示例data格式:
    {
        "流程": ["客户名单", "电话", "拜访", "分类", "回款", "售后服务"],
        "客户名单": {
            "量": "数量要求：...\n名单标准：...\n客户画像：...\n年度目标：...",
            "技能": "资料来源：...\n方法培训：...\n公司层面：...",
            "心态": "员工心态：...\n管理心态：..."
        },
        ...
    }
    """

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "战术沙盘"

    # 定义样式
    header_fill = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")  # 黄色
    header_font = Font(bold=True)
    thin_border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )
    wrap_alignment = Alignment(wrap_text=True, vertical='top')

    # 设置列宽
    ws.column_dimensions['A'].width = 15  # 环节
    ws.column_dimensions['B'].width = 40  # 量
    ws.column_dimensions['C'].width = 50  # 技能
    ws.column_dimensions['D'].width = 40  # 心态

    # 写入表头（第一行，标黄）
    headers = ["环节", "量（数量 质量）", "技能（组织 制度 流程 技术 工具）", "心态（客户 员工 管理者）"]
    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.fill = header_fill
        cell.font = header_font
        cell.border = thin_border
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)

    # 写入业务流程数据
    if "流程" in data:
        business_flow = data["流程"]
    else:
        business_flow = []

    row = 2  # 从第二行开始
    for step in business_flow:
        if step in data:
            item = data[step]
            # 第一列：环节名称（标黄）
            cell = ws.cell(row=row, column=1, value=step)
            cell.fill = header_fill
            cell.font = header_font
            cell.border = thin_border
            cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)

            # 第二列：量
            cell = ws.cell(row=row, column=2, value=item.get("量", ""))
            cell.border = thin_border
            cell.alignment = wrap_alignment

            # 第三列：技能
            cell = ws.cell(row=row, column=3, value=item.get("技能", ""))
            cell.border = thin_border
            cell.alignment = wrap_alignment

            # 第四列：心态
            cell = ws.cell(row=row, column=4, value=item.get("心态", ""))
            cell.border = thin_border
            cell.alignment = wrap_alignment

        row += 1

    # 自动调整行高
    for row in range(1, ws.max_row + 1):
        ws.row_dimensions[row].height = None  # 让行高自动适应内容

    # 保存文件
    wb.save(output_path)
    return output_path


def create_from_conversation(flow_data):
    """
    从对话数据创建战术沙盘

    参数:
        flow_data: 包含业务流程和完整信息的字典
    """
    return create_tactical_sandbox(flow_data)


if __name__ == "__main__":
    # 测试代码
    test_data = {
        "流程": ["客户名单", "电话", "拜访", "分类", "回款", "售后服务"],
        "客户名单": {
            "量": "数量要求：准备50个名单\n名单标准：姓名、电话、公司、职位、公司简介、过往跟进记录\n客户画像：500强企业，跨国企业，出海企业，软件互联网，新消费企业，智能制造企业等，营收规模1亿元以上，人员规模200人以上\n年度目标：公司+自拓要达到12.25万",
            "技能": "资料来源：老客户转介绍，客户CRM库公开，同行竞对，行业协会，行业社群，招聘网站，三方榜单，企查查/天眼查，技术论坛，报纸杂志等\n方法培训：培训找到有效名单的方法\n公司层面：BD客户名单、投流、同业异业合作、展会、社群营销、公域私域营销、直播",
            "心态": "员工心态：觉得没啥用，随便拉个名单应付了事；太浪费时间，不愿做；花很长时间也找不到名单，不会做；每次整理名单都花太长时间，做不好效率太低；第二天电话客户不一定会接\n管理心态：持续辅导；定期检查；这类事情看起来比较简单比较LOW，大部分管理者容易忽略"
        },
        "电话": {
            "量": "数量要求：打通30个电话或加微信\n通话标准：接通30秒以上，老板本人沟通\n通话目的：判断是否是目标客户，了解客户背景和具体地点，邀约上门拜访",
            "技能": "首通电话：开场白，话天地、挖需求，讲服务，试缔结，异议处理、约上门\n二次跟进：继续解决客户的痛点问题\nCLOSE：签订单、转介绍\n公司层面：电话机器人、callcenter、CRM",
            "心态": "客户心态：客户不愿接陌生电话；客户接通后，认为对自己没啥价值，浪费时间，赶紧挂断；客户被各种推销打扰，接到电销电话非常讨厌\n员工心态-第一层：由于第一通电话接通率低和反馈差，给员工信心造成打击，让员工不敢打、不愿打；老人多做转介绍\n员工心态-第二层：做好准备，调整心态，用价值吸引客户\n管理心态：培训和每天演练第一通电话；晚会对打电话中遇到的问题做解答与辅导；制定标准流程"
        }
    }

    output = create_tactical_sandbox(test_data)
    print(f"测试文件已生成: {output}")