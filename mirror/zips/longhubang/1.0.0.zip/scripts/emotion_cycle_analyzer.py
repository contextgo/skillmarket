#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
打板3 v3.2 —— 情绪周期分析模块
基于市场情绪周期理论，量化识别冰点→回暖→高潮→退潮四阶段
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

try:
    import akshare as ak
    AKSHARE_AVAILABLE = True
except ImportError:
    AKSHARE_AVAILABLE = False


class EmotionCycleAnalyzer:
    """
    情绪周期分析器
    
    核心逻辑：通过4个量化指标判断当前市场处于哪个情绪阶段
    1. 情绪温度(0-100) - 综合指标
    2. 涨停家数 - 市场活跃度
    3. 连板高度 - 龙头股强度 
    4. 亏钱效应(跌停家数) - 风险程度
    
    四阶段：
    - 冰点期(🧊): 情绪温度≤25, 涨停<20, 连板≤2, 极度悲观
    - 回暖期(🌱): 情绪温度25-65, 涨停30-50, 连板3-4, 蓄力向上
    - 高潮期(🔥): 情绪温度≥65, 涨停≥50, 连板≥5, 极度狂热
    - 退潮期(🌀): 情绪温度快速下降, 跌停≥30, 炸板率>50%, 恐慌出逃
    """
    
    # 情绪周期定义
    PHASES = {
        'ice': {
            'name': '冰点期',
            'emoji': '🧊',
            'color': '#3498db',
            'description': '地量地价，涨停<20家，连板≤2板，极度悲观',
            'recommendation': '空仓或极低仓位观望',
            'max_position': 0.2,
            'category_boost': {  # 各分类的推荐等级调整
                'A+': '维持', 'A': '维持',
                'B+': '降为C', 'B': '降为D', 'C': '降为D', 'D': '维持'
            }
        },
        'warm': {
            'name': '回暖期',
            'emoji': '🌱',
            'color': '#27ae60',
            'description': '量增20-30%，涨停30-50家，连板3-4板，最具性价比',
            'recommendation': '加仓布局主线龙头',
            'max_position': 0.6,
            'category_boost': {
                'A+': '升级(A+加分)', 'A': '升级(A+加分)',
                'B+': '升级(A)', 'B': '升级(B+)', 'C': '维持', 'D': '维持'
            }
        },
        'boom': {
            'name': '高潮期',
            'emoji': '🔥',
            'color': '#e74c3c',
            'description': '天量天价，涨停≥50家，连板≥5板，极度狂热',
            'recommendation': '逐步减仓落袋为安',
            'max_position': 0.3,
            'category_boost': {
                'A+': '维持', 'A': '维持',
                'B+': '降为C', 'B': '降为D', 'C': '降为D', 'D': '维持'
            }
        },
        'ebb': {
            'name': '退潮期',
            'emoji': '🌀',
            'color': '#8e44ad',
            'description': '缩量，炸板率>50%，龙头跌停，恐慌蔓延',
            'recommendation': '坚决空仓保本金',
            'max_position': 0.1,
            'category_boost': {
                'A+': '降为B+', 'A': '降为C',
                'B+': '降为D', 'B': '降为D', 'C': '降为D', 'D': '维持'
            }
        }
    }
    
    def __init__(self):
        self.phase = 'unknown'
        self.phase_info = None
        self.indicators = {}
    
    def fetch_market_data(self, date_str=None):
        """
        获取市场情绪数据
        
        Args:
            date_str: 日期YYYYMMDD，默认最近交易日
            
        Returns:
            dict: 市场情绪指标
        """
        if not AKSHARE_AVAILABLE:
            # 降级：返回模拟数据
            return self._estimate_indicators_fallback()
        
        indicators = {}
        
        try:
            # 1. 获取涨停池数据
            if date_str:
                zt_df = ak.stock_zt_pool_em(date=date_str)
            else:
                from datetime import datetime
                d = datetime.now()
                while d.weekday() >= 5:
                    d -= timedelta(days=1)
                zt_df = ak.stock_zt_pool_em(date=d.strftime('%Y%m%d'))
            
            if zt_df is not None and len(zt_df) > 0:
                indicators['涨停家数'] = len(zt_df)
                indicators['涨停换手'] = zt_df['涨停换手率'].mean() if '涨停换手率' in zt_df.columns else 0
                
                # 连板高度
                if '连板数' in zt_df.columns:
                    max_lb = zt_df['连板数'].max()
                    indicators['连板高度'] = int(max_lb)
                else:
                    indicators['连板高度'] = 0
                
                # 二连板以上家数（连板梯队深度）
                if '连板数' in zt_df.columns:
                    lb2plus = len(zt_df[zt_df['连板数'] >= 2])
                    indicators['连板梯队'] = lb2plus
                else:
                    indicators['连板梯队'] = 0
                    
                # 首板家数
                if '连板数' in zt_df.columns:
                    lb1 = len(zt_df[zt_df['连板数'] == 1])
                    indicators['首板家数'] = lb1
                else:
                    indicators['首板家数'] = 0
            else:
                indicators['涨停家数'] = 0
                indicators['连板高度'] = 0
                indicators['连板梯队'] = 0
                indicators['首板家数'] = 0
        except Exception as e:
            indicators['涨停家数'] = 0
            indicators['连板高度'] = 0
            indicators['连板梯队'] = 0
            indicators['首板家数'] = 0
        
        try:
            # 2. 获取跌停板数据
            if date_str:
                dt_df = ak.stock_zt_pool_dtgc_em(date=date_str)
            else:
                d = datetime.now()
                while d.weekday() >= 5:
                    d -= timedelta(days=1)
                dt_df = ak.stock_zt_pool_dtgc_em(date=d.strftime('%Y%m%d'))
            
            if dt_df is not None and len(dt_df) > 0:
                indicators['跌停家数'] = len(dt_df)
            else:
                indicators['跌停家数'] = 0
        except:
            indicators['跌停家数'] = 0
        
        # 3. 计算情绪温度
        indicators['情绪温度'] = self._calc_emotion_temperature(indicators)
        
        # 4. 计算炸板率（近似）
        total_zt = indicators.get('涨停家数', 0) + indicators.get('跌停家数', 0)
        if total_zt > 0:
            indicators['炸板率'] = 0  # 精确炸板率需要盘中数据，简化处理
        else:
            indicators['炸板率'] = 0
        
        self.indicators = indicators
        return indicators
    
    def _estimate_indicators_fallback(self):
        """akshare不可用时的降级估算"""
        indicators = {
            '涨停家数': 0,
            '连板高度': 0,
            '连板梯队': 0,
            '首板家数': 0,
            '跌停家数': 0,
            '情绪温度': 50,
            '炸板率': 0,
        }
        self.indicators = indicators
        return indicators
    
    def _calc_emotion_temperature(self, indicators):
        """
        计算情绪温度(0-100)
        
        核心算法：综合涨停家数、连板高度、连板梯队深度、跌停亏钱效应
        """
        zt = indicators.get('涨停家数', 0)
        lb = indicators.get('连板高度', 0)
        lb2 = indicators.get('连板梯队', 0)
        dt = indicators.get('跌停家数', 0)
        
        # 涨停家数得分 (0-40分)
        if zt >= 80: zt_score = 40
        elif zt >= 50: zt_score = 35
        elif zt >= 40: zt_score = 30
        elif zt >= 30: zt_score = 22
        elif zt >= 20: zt_score = 15
        elif zt >= 10: zt_score = 10
        else: zt_score = 5
        
        # 连板高度得分 (0-30分)
        if lb >= 7: lb_score = 30
        elif lb >= 5: lb_score = 25
        elif lb >= 4: lb_score = 20
        elif lb >= 3: lb_score = 15
        elif lb >= 2: lb_score = 8
        elif lb >= 1: lb_score = 4
        else: lb_score = 0
        
        # 连板梯队得分 (0-15分)
        if lb2 >= 10: lb2_score = 15
        elif lb2 >= 6: lb2_score = 12
        elif lb2 >= 4: lb2_score = 9
        elif lb2 >= 2: lb2_score = 6
        elif lb2 >= 1: lb2_score = 3
        else: lb2_score = 0
        
        # 跌停扣分 (0-15分)
        if dt >= 50: dt_penalty = 15
        elif dt >= 30: dt_penalty = 12
        elif dt >= 20: dt_penalty = 8
        elif dt >= 10: dt_penalty = 4
        elif dt >= 5: dt_penalty = 2
        else: dt_penalty = 0
        
        temperature = min(100, max(0, zt_score + lb_score + lb2_score - dt_penalty))
        return temperature
    
    def classify_phase(self, indicators=None):
        """
        判断当前市场情绪阶段
        
        Returns:
            str: 'ice' | 'warm' | 'boom' | 'ebb'
        """
        if indicators is None:
            indicators = self.indicators
        
        temp = indicators.get('情绪温度', 50)
        zt = indicators.get('涨停家数', 0)
        lb = indicators.get('连板高度', 0)
        dt = indicators.get('跌停家数', 0)
        
        # 先检查退潮信号（退潮优先——安全第一）
        if dt >= 30:
            self.phase = 'ebb'
            self.phase_info = self.PHASES['ebb']
            return 'ebb'
        
        # 检查高潮信号
        if (temp >= 65 and zt >= 50) or (temp >= 70) or (lb >= 7):
            self.phase = 'boom'
            self.phase_info = self.PHASES['boom']
            return 'boom'
        
        # 检查冰点信号
        if (temp <= 25 and zt < 25) or (zt < 15) or (lb <= 1 and zt < 20):
            self.phase = 'ice'
            self.phase_info = self.PHASES['ice']
            return 'ice'
        
        # 检查回暖信号
        if (25 < temp < 65 and 25 < zt < 50) or (lb >= 3 and zt >= 30):
            self.phase = 'warm'
            self.phase_info = self.PHASES['warm']
            return 'warm'
        
        # 默认：根据温度做最佳判断
        if temp <= 30:
            self.phase = 'ice'
            self.phase_info = self.PHASES['ice']
        elif temp <= 55:
            self.phase = 'warm'
            self.phase_info = self.PHASES['warm']
        else:
            self.phase = 'boom'
            self.phase_info = self.PHASES['boom']
        
        return self.phase
    
    def get_phase_adjustment(self, category):
        """
        根据情绪周期调整推荐分类
        
        Args:
            category: 当前分类 'A+'|'A'|'B+'|'B'|'C'|'D'
            
        Returns:
            (new_category, adjustment_reason, position_limit)
        """
        if self.phase == 'unknown':
            self.classify_phase()
        
        phase_info = self.phase_info
        boost_rules = phase_info['category_boost']
        
        if category not in boost_rules:
            return category, '未受影响', phase_info['max_position']
        
        rule = boost_rules[category]
        
        if '维持' in rule or '升级' in rule:
            return category, f"情绪{phase_info['name']}: {rule}", phase_info['max_position']
        
        if '降为' in rule:
            new_cat = rule.split('降为')[1].strip()
            return new_cat, f"情绪{phase_info['name']}: 降级({rule})", phase_info['max_position']
        
        return category, f"情绪{phase_info['name']}: {rule}", phase_info['max_position']
    
    def get_phase_description(self):
        """获取当前情绪周期描述"""
        if self.phase == 'unknown':
            self.classify_phase()
        
        p = self.phase_info
        indicators = self.indicators
        
        desc = f"{p['emoji']} 市场情绪周期: {p['name']}\n"
        desc += f"  ├─ 情绪温度: {indicators.get('情绪温度', 'N/A')}/100\n"
        desc += f"  ├─ 涨停家数: {indicators.get('涨停家数', 'N/A')}家\n"
        desc += f"  ├─ 连板高度: {indicators.get('连板高度', 'N/A')}板\n"
        desc += f"  ├─ 连板梯队: {indicators.get('连板梯队', 'N/A')}只(2板+)\n"
        desc += f"  ├─ 跌停家数: {indicators.get('跌停家数', 'N/A')}家\n"
        desc += f"  ├─ 策略: {p['recommendation']}\n"
        desc += f"  └─ 最高仓位: {p['max_position']*100:.0f}%\n"
        
        return desc
    
    def get_phase_dict(self):
        """返回情绪周期字典（供HTML报告使用）"""
        if self.phase == 'unknown':
            self.classify_phase()
        
        p = self.phase_info
        return {
            'phase_key': self.phase,
            'phase_name': p['name'],
            'emoji': p['emoji'],
            'color': p['color'],
            'description': p['description'],
            'recommendation': p['recommendation'],
            'max_position': p['max_position'],
            'indicators': self.indicators,
        }


def analyze_market_emotion(date_str=None):
    """
    一站式市场情绪分析
    
    Args:
        date_str: 日期YYYYMMDD
        
    Returns:
        (phase_key, phase_dict, indicators)
    """
    analyzer = EmotionCycleAnalyzer()
    indicators = analyzer.fetch_market_data(date_str)
    phase = analyzer.classify_phase(indicators)
    return phase, analyzer.get_phase_dict(), indicators


if __name__ == '__main__':
    print("=" * 60)
    print("  打板3 v3.2 情绪周期分析模块")
    print("=" * 60)
    
    phase, phase_dict, indicators = analyze_market_emotion()
    
    print(f"\n📊 市场情绪指标:")
    for k, v in indicators.items():
        print(f"  {k}: {v}")
    
    print(f"\n{phase_dict['emoji']} 情绪周期阶段: {phase_dict['phase_name']}")
    print(f"  策略: {phase_dict['recommendation']}")
    print(f"  最高仓位: {phase_dict['max_position']*100:.0f}%")
