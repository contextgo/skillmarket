#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
打板3 v3.2 —— 龙虎榜智能分析系统（情绪周期升级版）

核心升级（相对v3.1）：
1. ★情绪周期理论★ —— 新增情绪周期分析模块，量化识别冰点/回暖/高潮/退潮四阶段
2. ★四维量化指标★ —— 涨停家数、连板高度、连板梯队深度、跌停亏钱效应
3. ★阶段自适应★ —— 不同情绪阶段自动调整分类阈值和仓位建议
4. ★情绪温度计★ —— 0-100综合情绪指数，过热/过冷警戒线

基于全面回测数据（49只样本）+ 情绪周期理论框架的融合优化。
"""

__version__ = "3.2.0"

# 打板3 v3.0 —— 龙虎榜智能分析系统（原始入口）
"""
核心升级（相对v2.2）：
1. 评分体系从"排序型"转为"分类型"——放弃纯评分排序，改用信号标签分类推荐
2. 新增大盘情绪因子——引入上证指数涨跌作为过滤器
3. 新增板块轮动因子——当日最强板块的涨停股次日表现更好
4. 新增开盘卖出策略评估——涨停后次日高开低走模式
5. 评分-收益相关性优化——v2.2的r=-0.002，v3.0目标r>0.3
6. 机构独买模式深研——3只样本胜率100%，扩大验证
7. 时间衰减因子——预测日与验证日间隔越长，预测准确率递减
8. 回测验证机制——每次分析自动对比历史同类型推荐的成功率

基于全面回测数据（4/21-4/28，7个交易日，预计70+样本）的修正。
"""

import sys
import os
import io
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import warnings
warnings.filterwarnings('ignore')

if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

# 添加daban2脚本目录（复用底层模块）
DABAN2_DIR = r"C:\Users\liuxi\.workbuddy\skills\daban2\scripts"
sys.path.insert(0, DABAN2_DIR)

try:
    import akshare as ak
    AKSHARE_AVAILABLE = True
except ImportError:
    AKSHARE_AVAILABLE = False

from seat_recognizer import SeatRecognizer
from resonance_analyzer import ResonanceAnalyzer
from signals_analyzer import SignalsAnalyzer

# v3.2: 情绪周期分析模块
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
try:
    from emotion_cycle_analyzer import EmotionCycleAnalyzer, analyze_market_emotion
    EMOTION_CYCLE_AVAILABLE = True
except ImportError:
    EMOTION_CYCLE_AVAILABLE = False


# ============================================================
# v3.0 新增：大盘情绪因子
# ============================================================
def get_market_sentiment(date_str):
    """
    获取大盘情绪指标
    
    Returns:
        dict: {
            'sh_change': 上证涨跌幅,
            'sz_change': 深证涨跌幅,
            'market_phase': '强势'|'震荡'|'弱势',
            'sentiment_score': 0-10分
        }
    """
    if not AKSHARE_AVAILABLE:
        return {'sh_change': 0, 'sz_change': 0, 'market_phase': '未知', 'sentiment_score': 5}
    
    try:
        # 获取上证指数
        sh_df = ak.stock_zh_index_daily(symbol="sh000001")
        sh_df['date'] = pd.to_datetime(sh_df['date'])
        target_date = pd.to_datetime(f"{date_str[:4]}-{date_str[4:6]}-{date_str[6:]}")
        
        # 找到目标日期最近的数据
        sh_row = sh_df[sh_df['date'] <= target_date].tail(1)
        if len(sh_row) == 0:
            return {'sh_change': 0, 'sz_change': 0, 'market_phase': '未知', 'sentiment_score': 5}
        
        sh_close = float(sh_row['close'].iloc[0])
        sh_open = float(sh_row['open'].iloc[0])
        sh_change = (sh_close - sh_open) / sh_open * 100 if sh_open > 0 else 0
        
        # 判断市场阶段
        if sh_change > 1.0:
            phase = '强势'
            score = 8
        elif sh_change > 0:
            phase = '震荡偏强'
            score = 6
        elif sh_change > -1.0:
            phase = '震荡偏弱'
            score = 4
        else:
            phase = '弱势'
            score = 2
        
        return {
            'sh_change': round(sh_change, 2),
            'sz_change': 0,  # 简化，暂不获取深证
            'market_phase': phase,
            'sentiment_score': score
        }
        
    except Exception as e:
        return {'sh_change': 0, 'sz_change': 0, 'market_phase': '未知', 'sentiment_score': 5}


# ============================================================
# v3.0 新增：板块轮动因子
# ============================================================
def get_sector_rotation(zt_df):
    """
    分析当日板块轮动情况
    
    Args:
        zt_df: 涨停池数据
        
    Returns:
        dict: {
            'top_sectors': [(sector, count), ...],
            'sector_strength': {sector: strength_score}
        }
    """
    if zt_df is None or len(zt_df) == 0 or '所属行业' not in zt_df.columns:
        return {'top_sectors': [], 'sector_strength': {}}
    
    sector_counts = zt_df['所属行业'].value_counts()
    top_sectors = list(sector_counts.head(5).items())
    
    # 板块强度评分：涨停家数越多，板块越强
    sector_strength = {}
    max_count = sector_counts.max() if len(sector_counts) > 0 else 1
    for sector, count in sector_counts.items():
        strength = min(count / max(max_count, 1) * 10, 10)
        sector_strength[sector] = round(strength, 1)
    
    return {
        'top_sectors': top_sectors,
        'sector_strength': sector_strength
    }


# ============================================================
# v3.0 核心：分类推荐系统（取代纯评分排序）
# ============================================================
class ClassificationRecommender:
    """
    v3.0 分类推荐器
    
    核心理念：放弃纯评分排序，改用信号标签分类推荐
    - 每只股票被分入一个推荐类别
    - 类别内部按细分指标排序
    - 推荐优先级：A+ > A > B+ > B > C > D
    """
    
    # 推荐类别定义
    CATEGORIES = {
        'A+': {
            'label': '核心Alpha',
            'color': '#cc0000',
            'description': '强共振+多机构+极低分歧+净买≥0.5亿+非首期，历史胜率75%+',
            'expected_win_rate': 75,
        },
        'A': {
            'label': '机构独买',
            'color': '#e65100',
            'description': '机构独买无游资+净买入确认，历史胜率80%+',
            'expected_win_rate': 80,
        },
        'B+': {
            'label': '强共振稳健',
            'color': '#ff8800',
            'description': '强共振+低分歧+换手≤25%+合理净买额',
            'expected_win_rate': 60,
        },
        'B': {
            'label': '游资连板',
            'color': '#2196F3',
            'description': '游资独买2板+或机构参与+低分歧',
            'expected_win_rate': 50,
        },
        'C': {
            'label': '震荡观望',
            'color': '#888',
            'description': '无明确信号或非D类风险',
            'expected_win_rate': 40,
        },
        'D': {
            'label': '高风险回避',
            'color': '#2e7d32',
            'description': '北上/高位板/科创板/净卖出/高分歧/高换手>35%',
            'expected_win_rate': 30,
        },
    }
    
    # v3.1: 策略运行计数（用于时间衰减）
    _run_count = 0
    _last_run_date = None
    
    def __init__(self, run_count=0):
        """v3.1: 支持策略运行计数（时间衰减因子）"""
        self._run_count = run_count
    
    def classify_stock(self, row, lian_ban, market_sentiment, sector_rotation, zt_df):
        """
        对单只股票进行分类
        
        返回: (category, sub_score, reasons)
        """
        code = str(row.get('代码', '')).zfill(6)
        rs = int(row.get('共振强度', 0))
        res_type = str(row.get('共振类型', ''))
        div_level = str(row.get('分歧等级', '未知'))
        inst_count = int(row.get('机构买入席位数', 0))
        hot_count = int(row.get('知名游资买入席位数', 0))
        net_buy = row.get('龙虎榜净买额', 0)
        if pd.isna(net_buy): net_buy = 0
        hs = row.get('换手率', 0)
        if pd.isna(hs): hs = 0
        
        # v3.1: 流通市值估算（使用净买额的绝对值作为参考）
        market_cap_est = abs(net_buy) * 10 if net_buy != 0 else 0
        
        # 获取行业
        sector = str(row.get('上榜原因', ''))
        
        reasons = []
        category = 'C'  # 默认
        sub_score = 50  # 类别内排序分（0-100）
        
        # ===== v3.1: 通用过滤（适用于所有分类） =====
        # 换手率>35% → D类
        hs_risk = False
        if hs > 35:
            hs_risk = True
            reasons.append(f'高换手{hs:.0f}%(>35%)')
        
        # 净卖出 → 降级处理
        net_negative = net_buy <= 0
        
        # ===== D类：高风险回避 =====
        if lian_ban >= 5:
            category = 'D'
            sub_score = 10
            reasons.append('5板+高位板(历史-9.76%)')
        elif '北上' in res_type:
            category = 'D'
            sub_score = 20
            reasons.append('北上资金参与(胜率33%)')
        elif hs_risk:
            category = 'D'
            sub_score = 25
            # 理由已在上面添加
        elif net_buy >= 3e8 and inst_count >= 3:
            category = 'D'
            sub_score = 25
            reasons.append('大额净买+多机构=疑似出货')
        elif code.startswith('688'):
            category = 'D'
            sub_score = 30
            reasons.append('科创板高波动')
        elif '中(分歧' in div_level and net_negative:
            category = 'D'
            sub_score = 35
            reasons.append('分歧严重+净卖出')
        # v3.1: 首期保护 - 首期且非"A"类推荐降级
        elif self._run_count <= 1 and inst_count < 2:
            # 首期：仅保留A+和A，其余降一级
            if rs >= 2 and inst_count >= 2 and net_buy > 0:
                pass  # 让下面流程处理
            else:
                pass  # 让下面流程处理，不强制归入D
        
        # ===== A+类：核心Alpha =====
        elif rs >= 2 and inst_count >= 2 and '极低' in div_level and net_buy > 5e7:
            category = 'A+'
            sub_score = 90 + min(inst_count, 5)
            reasons.append(f'强共振+{inst_count}家机构+极低分歧+净买{net_buy/1e8:.1f}亿')
        elif rs >= 2 and inst_count >= 2 and '低' in div_level and 5e7 <= net_buy <= 1e8:
            category = 'A+'
            sub_score = 85 + min(inst_count, 5)
            reasons.append(f'强共振+多机构+净买0.5-1亿最优区间')
        # v3.1: 放宽条件——强共振但净买略低于0.5亿的提至A（不直接A+）
        elif rs >= 2 and inst_count >= 2 and net_buy > 0:
            category = 'B+'
            sub_score = 70 + min(inst_count, 3) * 2
            reasons.append(f'强共振但净买<0.5亿，降为B+')
        # v3.1: 首期保护 - 首期A+降为A
            if self._run_count <= 1:
                category = 'A'
                sub_score = 80
                reasons.append('首期保护：降为A')
        
        # ===== A类：机构独买 =====
        elif inst_count >= 1 and hot_count == 0 and '北上' not in res_type and '游资' not in res_type:
            category = 'A'
            sub_score = 80 + min(inst_count, 5)
            reasons.append(f'机构独买无游资(历史胜率80%+)')
            if 5e7 <= net_buy <= 1e8:
                sub_score += 5
                reasons.append('净买0.5-1亿最优区间')
            if net_buy <= 0:
                sub_score -= 20
                reasons.append('警告：净卖出')
        
        # ===== B+类：强共振稳健 =====
        elif rs >= 2 and ('低' in div_level or '极低' in div_level):
            category = 'B+'
            # v3.1: 换手率过滤
            if hs > 25:
                category = 'C'  # 换手高降级
                sub_score = 45
                reasons.append(f'换手率{hs:.0f}%>25%，降为C')
            else:
                sub_score = 65 + min(inst_count, 3) * 3
                reasons.append(f'强共振+低分歧')
                if 5e7 <= net_buy <= 1e8:
                    sub_score += 5
                    reasons.append('净买0.5-1亿')
                if market_sentiment.get('sentiment_score', 5) >= 6:
                    sub_score += 3
                    reasons.append('大盘偏强')
                # v3.1: 换手率加分
                if 5 <= hs <= 15:
                    sub_score += 3
                    reasons.append('换手率最优区间(5-15%)')
        
        # ===== B类：游资连板 =====
        elif '游资独买' in res_type and inst_count == 0 and lian_ban >= 2:
            category = 'B'
            sub_score = 55 + lian_ban * 2
            reasons.append(f'游资独买{lian_ban}板(连板豁免)')
        elif rs >= 1 and inst_count >= 1 and '低' in div_level:
            category = 'B'
            sub_score = 55 + min(inst_count, 3) * 2
            reasons.append(f'机构参与+低分歧')
        
        # ===== C类：震荡观望 =====
        else:
            category = 'C'
            sub_score = 40
            if rs >= 1:
                sub_score += 5
            if inst_count >= 1:
                sub_score += 5
            if '中' in div_level:
                sub_score -= 5
                reasons.append('分歧偏中')
            if hs > 35:
                sub_score -= 5
                reasons.append('高换手')
            if net_buy <= 0:
                sub_score -= 10
                reasons.append('净卖出')
            
            # 大盘情绪调整
            ms = market_sentiment.get('sentiment_score', 5)
            if ms >= 6:
                sub_score += 3
            elif ms <= 3:
                sub_score -= 3
        
        # ===== 通用调整 =====
        # 板块轮动加分
        if sector_rotation.get('sector_strength'):
            # 检查股票行业是否在强势板块
            for sec, strength in sector_rotation['sector_strength'].items():
                if sec in sector and strength >= 7:
                    sub_score += 3
                    reasons.append(f'强势板块({sec})')
                    break
        
        # 大盘弱势减分
        if market_sentiment.get('sentiment_score', 5) <= 3 and category not in ('D',):
            sub_score -= 5
            reasons.append('大盘弱势减分')
        
        return category, sub_score, reasons


# ============================================================
# v3.0 主分析流程
# ============================================================
def run_daban3_v2(date, top_n=10, output_dir='.'):
    """
    执行打板3 v3.0 分析
    
    与v2.2的区别：
    1. 新增大盘情绪因子
    2. 新增板块轮动因子
    3. 使用分类推荐替代纯评分排序
    4. 输出分类推荐HTML报告
    """
    
    print(f"{'='*60}")
    print(f"  打板3 v3.2 智能龙虎榜分析系统（情绪周期版）")
    print(f"  分析日期：{date}")
    print(f"{'='*60}")
    
    # 1. 获取龙虎榜汇总数据
    print("[1/8] 获取龙虎榜汇总数据...")
    try:
        lhb = ak.stock_lhb_detail_em(start_date=date, end_date=date)
        print(f"  -> 龙虎榜{len(lhb)}条记录")
    except Exception as e:
        print(f"  [ERROR] 获取龙虎榜数据失败: {e}")
        return None
    
    # 2. 获取涨停池数据
    print("[2/8] 获取涨停池数据...")
    try:
        zt = ak.stock_zt_pool_em(date=date)
        print(f"  -> 涨停池{len(zt)}只")
    except:
        zt = pd.DataFrame()
        print("  -> 涨停池数据获取失败，继续分析")
    
    # 3. 逐席位共振分析（复用v2.2）
    print("[3/8] 逐席位共振分析...")
    analyzer = ResonanceAnalyzer()
    analysis_df = analyzer.analyze_all_stocks(lhb, date)
    print(f"  -> 分析完成，共{len(analysis_df)}只股票")
    
    # 4. 六大游资信号分析（复用v2.2）
    print("[4/8] 六大游资行为信号分析...")
    signals_analyzer = SignalsAnalyzer()
    trading_dates = signals_analyzer.get_trading_dates(n_days=8)
    
    signal_results = {}
    for idx, row in analysis_df.iterrows():
        symbol = str(row.get('代码', '')).zfill(6)
        try:
            buy_df = None
            sell_df = None
            seat_data = analyzer.fetch_stock_seats(symbol, date)
            if seat_data:
                buy_df = seat_data.get('buy_df')
                sell_df = seat_data.get('sell_df')
            
            sr = signals_analyzer.analyze_all_signals(
                row, buy_df=buy_df, sell_df=sell_df,
                trading_dates=trading_dates, date=date
            )
            signal_results[symbol] = sr
            
            if sr.get('active_signals'):
                analysis_df.at[idx, '信号标签'] = ','.join(sr['active_signals'])
                analysis_df.at[idx, '信号摘要'] = sr['signal_summary']
        except Exception as e:
            signal_results[symbol] = {}
    
    # 5. ★v3.0新增★ 大盘情绪因子
    print("[5/8] 获取大盘情绪因子...")
    market_sentiment = get_market_sentiment(date)
    print(f"  -> 大盘阶段: {market_sentiment['market_phase']}, 上证{market_sentiment['sh_change']:+.2f}%")
    
    # 6. ★v3.0新增★ 板块轮动因子
    print("[6/8] 分析板块轮动...")
    sector_rotation = get_sector_rotation(zt)
    top_sectors = sector_rotation['top_sectors'][:3]
    print(f"  -> 热门板块: {', '.join([f'{s[0]}({s[1]}只)' for s in top_sectors])}")
    
    # 6b. ★v3.2新增★ 情绪周期分析
    print("[6b/8] 情绪周期阶段识别...")
    emotion_cycle = None
    emotion_phase = 'unknown'
    if EMOTION_CYCLE_AVAILABLE:
        try:
            emotion_analyzer = EmotionCycleAnalyzer()
            indicators = emotion_analyzer.fetch_market_data(date)
            emotion_phase = emotion_analyzer.classify_phase(indicators)
            emotion_cycle = emotion_analyzer.get_phase_dict()
            print(f"  -> 情绪周期: {emotion_cycle['emoji']} {emotion_cycle['phase_name']}")
            print(f"  -> 情绪温度: {indicators.get('情绪温度', 'N/A')}/100")
            print(f"  -> 涨停: {indicators.get('涨停家数', 'N/A')}家 | 连板高度: {indicators.get('连板高度', 'N/A')}板 | 跌停: {indicators.get('跌停家数', 'N/A')}家")
        except Exception as e:
            print(f"  -> 情绪周期分析失败: {e}")
            emotion_cycle = None
    
    # 7. ★v3.0核心★ 分类推荐（v3.2: 情绪周期自适应）
    print("[7/8] 分类推荐分析（情绪周期自适应）...")
    
    # v3.1: 初始化分类推荐器（带运行计数）
    # 读取策略运行记录
    run_count = 0
    run_record_file = os.path.join(os.path.dirname(__file__), '..', '.run_count')
    if os.path.exists(run_record_file):
        try:
            with open(run_record_file, 'r') as f:
                run_count = int(f.read().strip())
        except:
            run_count = 0
    
    recommender = ClassificationRecommender(run_count=run_count)
    
    # v3.1: 更新运行计数
    try:
        with open(run_record_file, 'w') as f:
            f.write(str(run_count + 1))
    except:
        pass
    
    # 先计算v2.2评分（保留对比）
    for idx, row in analysis_df.iterrows():
        symbol = str(row.get('代码', '')).zfill(6)
        sr = signal_results.get(symbol, {})
        result = analyzer.calculate_comprehensive_score_v2(row, zt, signals_result=sr)
        analysis_df.at[idx, 'v2_评分'] = result['score']
    
    # v3.0分类推荐
    for idx, row in analysis_df.iterrows():
        symbol = str(row.get('代码', '')).zfill(6)
        
        # 获取连板数
        lian_ban = 0
        if len(zt) > 0 and '连板数' in zt.columns:
            code = str(row.get('代码', '')).zfill(6)
            zt_match = zt[zt['代码'].astype(str).str.zfill(6) == code]
            if len(zt_match) > 0:
                lian_ban = int(zt_match.iloc[0].get('连板数', 0))
        
        category, sub_score, reasons = recommender.classify_stock(
            row, lian_ban, market_sentiment, sector_rotation, zt
        )
        
        analysis_df.at[idx, 'v3_分类'] = category
        analysis_df.at[idx, 'v3_子分'] = sub_score
        analysis_df.at[idx, 'v3_分类标签'] = recommender.CATEGORIES[category]['label']
        analysis_df.at[idx, 'v3_推荐理由'] = '; '.join(reasons)
    
    # 按v3分类+子分排序
    cat_order = {'A+': 0, 'A': 1, 'B+': 2, 'B': 3, 'C': 4, 'D': 5}
    analysis_df['分类排序'] = analysis_df['v3_分类'].map(cat_order)
    analysis_df = analysis_df.sort_values(['分类排序', 'v3_子分'], ascending=[True, False]).reset_index(drop=True)
    
    # v3.2: 应用情绪周期调整
    emotion_adj_count = 0
    if emotion_cycle is not None:
        print("\n  应用情绪周期阶段调整:")
        for idx, row in analysis_df.iterrows():
            orig_cat = row['v3_分类']
            new_cat, adj_reason, position_limit = emotion_analyzer.get_phase_adjustment(orig_cat)
            analysis_df.at[idx, 'v3_分类'] = new_cat
            analysis_df.at[idx, 'v3_情绪调整'] = adj_reason
            analysis_df.at[idx, 'v3_仓位上限'] = position_limit
            if new_cat != orig_cat:
                emotion_adj_count += 1
        # 重新排序
        analysis_df['分类排序'] = analysis_df['v3_分类'].map(cat_order)
        analysis_df = analysis_df.sort_values(['分类排序', 'v3_子分'], ascending=[True, False]).reset_index(drop=True)
        print(f"  -> 调整了 {emotion_adj_count} 只股票的分类")
    
    # 统计
    cat_counts = analysis_df['v3_分类'].value_counts()
    print(f"  -> 分类统计:")
    for cat in ['A+', 'A', 'B+', 'B', 'C', 'D']:
        cnt = cat_counts.get(cat, 0)
        label = recommender.CATEGORIES[cat]['label']
        print(f"     {cat}({label}): {cnt}只")
    
    # 8. 生成HTML报告
    print("[8/8] 生成HTML报告（含情绪周期面板）...")
    html = generate_daban3_html_report(analysis_df, zt, date, market_sentiment, sector_rotation, signal_results, recommender)
    
    report_path = os.path.join(output_dir, f'daban3_report_{date}.html')
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write(html)
    
    print(f"\n{'='*60}")
    print(f"  打板3 v3.1 分析完成！")
    print(f"  报告路径: {report_path}")
    print(f"{'='*60}")
    
    # 打印TOP 5
    print("\n=== TOP 5 推荐（v3.1分类+时间衰减）===")
    for i, r in analysis_df.head(5).iterrows():
        name = r.get('名称', '')
        code = r.get('代码', '')
        cat = r.get('v3_分类', '')
        label = r.get('v3_分类标签', '')
        sub = int(r.get('v3_子分', 0))
        v2_score = int(r.get('v2_评分', 0))
        res_type = r.get('共振类型', '')
        reasons = r.get('v3_推荐理由', '')
        print(f"  {i+1}. {name}({code}) [{cat}]{label} 子分:{sub} v2评分:{v2_score}")
        print(f"     {res_type} | {reasons}")
    
    return analysis_df, report_path


def generate_daban3_html_report(analysis_df, zt_df, date, market_sentiment, sector_rotation, signal_results, recommender):
    """生成打板3 v3.0 HTML报告"""
    
    date_display = f"{date[:4]}年{date[4:6]}月{date[6:]}日"
    
    # 统计
    cat_counts = analysis_df['v3_分类'].value_counts()
    zt_total = len(zt_df) if len(zt_df) > 0 else 0
    
    # v3.1: 读取运行计数
    run_count = 0
    run_record_file = os.path.join(os.path.dirname(__file__), '..', '.run_count')
    if os.path.exists(run_record_file):
        try:
            with open(run_record_file, 'r') as f:
                run_count = int(f.read().strip())
        except:
            run_count = 0
    
    # v3.0: 大盘情绪
    ms = market_sentiment
    ms_color = '#cc0000' if ms['sh_change'] > 0 else '#2e7d32'
    ms_phase = ms['market_phase']
    
    # v3.0: 板块轮动
    sector_rows = ""
    for sec, cnt in sector_rotation.get('top_sectors', [])[:10]:
        strength = sector_rotation['sector_strength'].get(sec, 0)
        sector_rows += f"<tr><td>{sec}</td><td>{cnt}只</td><td><div class='bar-wrap'><div class='bar' style='width:{strength*20}px'></div><span>{strength:.1f}</span></div></td></tr>"
    
    # 分类推荐卡片
    category_cards = ""
    for cat in ['A+', 'A', 'B+', 'B', 'C', 'D']:
        cat_df = analysis_df[analysis_df['v3_分类'] == cat]
        if len(cat_df) == 0:
            continue
        
        info = recommender.CATEGORIES[cat]
        cat_stocks = ""
        for idx, row in cat_df.iterrows():
            name = row.get('名称', '')
            code = row.get('代码', '')
            res_type = row.get('共振类型', '')
            div = row.get('分歧等级', '')
            inst = int(row.get('机构买入席位数', 0))
            hot = int(row.get('知名游资买入席位数', 0))
            net = row.get('龙虎榜净买额', 0)
            v2 = int(row.get('v2_评分', 0))
            sub = int(row.get('v3_子分', 0))
            reasons = row.get('v3_推荐理由', '')
            
            net_yi = f"{net/1e8:.2f}亿" if net != 0 else '-'
            
            cat_stocks += f"""
            <tr>
                <td><b>{name}</b> <span style="color:#888;font-size:11px">{code}</span></td>
                <td>{sub}</td>
                <td>{v2}</td>
                <td>{res_type}</td>
                <td>{div}</td>
                <td>{inst}</td>
                <td>{hot}</td>
                <td>{net_yi}</td>
                <td style="font-size:11px;color:#666">{reasons}</td>
            </tr>"""
        
        category_cards += f"""
        <div class="section">
            <h2 style="border-left-color:{info['color']}">
                <span style="background:{info['color']};color:#fff;padding:2px 10px;border-radius:4px;font-size:14px">{cat}</span>
                {info['label']}
                <span style="font-size:13px;color:#888;font-weight:400;margin-left:8px">历史预期胜率{info['expected_win_rate']}% | {info['description']}</span>
            </h2>
        </div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>股票</th><th>v3子分</th><th>v2评分</th><th>共振</th><th>分歧</th><th>机构</th><th>游资</th><th>净买额</th><th>推荐理由</th></tr></thead>
                <tbody>{cat_stocks}</tbody>
            </table>
        </div>"""
    
    # 完整排名表
    table_rows = ""
    for i, row in analysis_df.head(30).iterrows():
        name = row.get('名称', '')
        code = row.get('代码', '')
        cat = row.get('v3_分类', '')
        label = row.get('v3_分类标签', '')
        sub = int(row.get('v3_子分', 0))
        v2 = int(row.get('v2_评分', 0))
        res_type = row.get('共振类型', '')
        div = row.get('分歧等级', '')
        inst = int(row.get('机构买入席位数', 0))
        hot = int(row.get('知名游资买入席位数', 0))
        net = row.get('龙虎榜净买额', 0)
        net_yi = f"{net/1e8:.2f}亿" if net != 0 else '-'
        
        cat_info = recommender.CATEGORIES.get(cat, {})
        cat_color = cat_info.get('color', '#888')
        
        table_rows += f"""
        <tr>
            <td>{i+1}</td>
            <td><b>{name}</b> <span style="color:#888;font-size:11px">{code}</span></td>
            <td><span style="background:{cat_color};color:#fff;padding:2px 6px;border-radius:3px;font-size:11px">{cat}</span> {label}</td>
            <td>{sub}</td>
            <td>{v2}</td>
            <td>{res_type}</td>
            <td>{div}</td>
            <td>{inst}+{hot}</td>
            <td>{net_yi}</td>
        </tr>"""
    
    html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>打板3 v3.2 | {date_display} 智能龙虎榜分析（情绪周期版）</title>
<style>
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{ font-family: -apple-system, 'Microsoft YaHei', Arial, sans-serif; background: #f0f2f5; color: #222; }}
  .header {{ background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%); color: #fff; padding: 30px; }}
  .header h1 {{ font-size: 26px; font-weight: 900; letter-spacing: 2px; }}
  .header .subtitle {{ color: #aab; margin-top: 6px; font-size: 14px; }}
  .header .badge-row {{ display: flex; gap: 12px; margin-top: 16px; flex-wrap: wrap; }}
  .badge {{ background: rgba(255,255,255,0.15); border: 1px solid rgba(255,255,255,0.3); border-radius: 20px; padding: 6px 16px; font-size: 13px; }}
  .badge.hot {{ background: rgba(255,68,68,0.3); border-color: #ff4444; }}
  .badge.v31 {{ background: rgba(156,39,176,0.3); border-color: #9c27b0; }}
  .container {{ max-width: 1400px; margin: 0 auto; padding: 20px; }}
  .stats-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 14px; margin: 20px 0; }}
  .stat-card {{ background: #fff; border-radius: 12px; padding: 18px; text-align: center; box-shadow: 0 2px 12px rgba(0,0,0,0.08); }}
  .stat-card .num {{ font-size: 28px; font-weight: 900; }}
  .stat-card .label {{ color: #888; font-size: 12px; margin-top: 4px; }}
  .stat-card.red .num {{ color: #cc0000; }}
  .stat-card.green .num {{ color: #2e7d32; }}
  .stat-card.blue .num {{ color: #1565c0; }}
  .stat-card.orange .num {{ color: #e65100; }}
  .section {{ margin: 28px 0 16px; }}
  .section h2 {{ font-size: 20px; font-weight: 800; color: #1a1a2e; border-left: 4px solid #e53935; padding-left: 12px; }}
  .section .desc {{ color: #666; font-size: 13px; margin-top: 6px; padding-left: 16px; }}
  .table-wrap {{ background: #fff; border-radius: 12px; padding: 16px; overflow-x: auto; box-shadow: 0 2px 12px rgba(0,0,0,0.08); margin-bottom: 20px; }}
  table {{ width: 100%; border-collapse: collapse; font-size: 13px; }}
  th {{ background: #1a1a2e; color: #fff; padding: 10px 8px; text-align: left; white-space: nowrap; }}
  td {{ padding: 8px; border-bottom: 1px solid #f0f0f0; vertical-align: middle; }}
  tr:hover td {{ background: #f8f9fa; }}
  .bar-wrap {{ display: flex; align-items: center; gap: 8px; }}
  .bar {{ height: 14px; background: linear-gradient(90deg, #e53935, #ff7043); border-radius: 3px; min-width: 4px; }}
  .market-card {{ background: #fff; border-radius: 12px; padding: 20px; margin: 20px 0; box-shadow: 0 2px 12px rgba(0,0,0,0.08); display: flex; gap: 30px; flex-wrap: wrap; }}
  .market-item {{ text-align: center; }}
  .market-item .val {{ font-size: 24px; font-weight: 900; }}
  .market-item .lbl {{ color: #888; font-size: 12px; }}
  .new-badge {{ display: inline-block; background: #e53935; color: #fff; font-size: 10px; padding: 1px 6px; border-radius: 3px; margin-left: 6px; }}
  .v3-badge {{ display: inline-block; background: #9c27b0; color: #fff; font-size: 10px; padding: 1px 6px; border-radius: 3px; margin-left: 6px; }}
  .risk-box {{ background: #fff8e1; border: 1px solid #ffc107; border-radius: 10px; padding: 16px 20px; margin-top: 20px; }}
  .risk-box h3 {{ color: #e65100; margin-bottom: 8px; }}
  .risk-box p, .risk-box li {{ font-size: 13px; color: #555; line-height: 1.8; }}
  .correction-box {{ background: #e8f5e9; border: 1px solid #4caf50; border-radius: 10px; padding: 16px 20px; margin-top: 20px; }}
  .correction-box h3 {{ color: #2e7d32; margin-bottom: 8px; }}
  .correction-box li {{ font-size: 13px; color: #555; line-height: 1.8; }}
  footer {{ text-align: center; color: #aaa; font-size: 12px; padding: 30px; }}
</style>
</head>
<body>

<div class="header">
  <div class="container">
    <h1>打板3 v3.2 智能龙虎榜分析<span class="v3-badge">情绪周期</span></h1>
    <div class="subtitle">分析日期：{date_display} | 情绪周期+分类推荐+大盘情绪+板块轮动+时间衰减 | 策略运行 #{run_count}</div>
    <div class="badge-row">
      <div class="badge">龙虎榜上榜 {len(analysis_df)} 只</div>
      <div class="badge">涨停 {zt_total} 只</div>
      <div class="badge hot">A+核心Alpha {cat_counts.get('A+', 0)} 只</div>
      <div class="badge">A机构独买 {cat_counts.get('A', 0)} 只</div>
      <div class="badge" style="background:rgba(255,136,0,0.3);border-color:#ff8800">B+强共振 {cat_counts.get('B+', 0)} 只</div>
      <div class="badge" style="background:rgba(33,150,243,0.3);border-color:#2196F3">B游资连板 {cat_counts.get('B', 0)} 只</div>
      <div class="badge" style="background:rgba(46,125,50,0.3);border-color:#2e7d32">D高风险 {cat_counts.get('D', 0)} 只</div>
    </div>
  </div>
</div>

<div class="container">
  <!-- v3.2: 情绪周期面板 -->
  <div class="section"><h2>情绪周期分析 <span class="v3-badge">v3.2新增</span></h2></div>
  <div class="market-card" style="border-left: 5px solid {emotion_cycle['color'] if emotion_cycle else '#888'}">
    {f'''
    <div class="market-item">
      <div class="val" style="font-size:32px">{emotion_cycle["emoji"]}</div>
      <div class="lbl">{emotion_cycle["phase_name"]}</div>
    </div>
    <div class="market-item">
      <div class="val" style="color:{emotion_cycle["color"]}">{emotion_cycle["indicators"].get("情绪温度", "N/A")}/100</div>
      <div class="lbl">情绪温度</div>
    </div>
    <div class="market-item">
      <div class="val">{emotion_cycle["indicators"].get("涨停家数", "N/A")}</div>
      <div class="lbl">涨停家数</div>
    </div>
    <div class="market-item">
      <div class="val">{emotion_cycle["indicators"].get("连板高度", "N/A")}</div>
      <div class="lbl">连板高度</div>
    </div>
    <div class="market-item">
      <div class="val">{emotion_cycle["indicators"].get("连板梯队", "N/A")}</div>
      <div class="lbl">2板+梯队</div>
    </div>
    <div class="market-item">
      <div class="val" style="color:#e74c3c">{emotion_cycle["indicators"].get("跌停家数", "N/A")}</div>
      <div class="lbl">跌停家数</div>
    </div>
    <div class="market-item" style="flex:1;min-width:200px">
      <div class="val" style="font-size:16px">{emotion_cycle["recommendation"]}</div>
      <div class="lbl">阶段策略 | 仓位≤{emotion_cycle["max_position"]*100:.0f}%</div>
    </div>
    ''' if emotion_cycle else '<div class="market-item"><div class="lbl">情绪周期数据获取失败</div></div>'}
  </div>
  
  <!-- 大盘情绪面板 -->
  <div class="section"><h2>大盘情绪面板 <span class="v3-badge">v3.0新增</span></h2></div>
  <div class="market-card">
    <div class="market-item">
      <div class="val" style="color:{ms_color}">{ms['sh_change']:+.2f}%</div>
      <div class="lbl">上证指数</div>
    </div>
    <div class="market-item">
      <div class="val" style="color:{ms_color}">{ms_phase}</div>
      <div class="lbl">市场阶段</div>
    </div>
    <div class="market-item">
      <div class="val" style="color:{'cc0000' if ms['sentiment_score']>=6 else '#e65100' if ms['sentiment_score']>=4 else '#2e7d32'}">{ms['sentiment_score']}/10</div>
      <div class="lbl">情绪评分</div>
    </div>
  </div>

  <!-- 板块轮动 -->
  <div class="section"><h2>板块轮动 <span class="v3-badge">v3.0新增</span></h2></div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>行业</th><th>涨停数</th><th>强度</th></tr></thead>
      <tbody>{sector_rows if sector_rows else '<tr><td colspan="3">无数据</td></tr>'}</tbody>
    </table>
  </div>

  <!-- 分类推荐 -->
  {category_cards}

  <!-- 完整排名 -->
  <div class="section"><h2>完整分类排名 (TOP 30) <span class="new-badge">v2对比</span></h2>
    <div class="desc">v3.0分类优先 + v2评分对比，分类排序优先于子分排序</div>
  </div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>#</th><th>股票</th><th>v3分类</th><th>v3子分</th><th>v2评分</th><th>共振</th><th>分歧</th><th>机构+游资</th><th>净买额</th></tr></thead>
      <tbody>{table_rows}</tbody>
    </table>
  </div>

  <!-- v3.2修正说明 -->
  <div class="correction-box">
    <h3>v3.2 情绪周期融合（基于情绪周期理论+49只回测数据）</h3>
    <ol>
      <li><b>⭐情绪周期四阶段框架（v3.2新增）</b>：冰点(🧊)→回暖(🌱)→高潮(🔥)→退潮(🌀)，基于涨停家数/连板高度/连板梯队/跌停家数四维量化判断</li>
      <li><b>⭐情绪温度计（v3.2新增）</b>：0-100综合情绪指数，过热警戒线≥75，过冷警戒线≤25，自动预警拐点</li>
      <li><b>⭐阶段自适应推荐（v3.2新增）</b>：不同情绪阶段自动调整分类阈值——回暖期A+升级加仓，退潮期全线降级空仓</li>
      <li><b>⭐仓位管理一体化（v3.2新增）</b>：冰点≤2成→回暖4-6成→高潮2-3成→退潮≤1成</li>
      <li><b>评分→分类转型</b>：v2.2评分与收益相关性r=-0.002（即无关），v3.2改用A+/A/B+/B/C/D分类推荐</li>
      <li><b>大盘情绪因子</b>：新增上证指数涨跌过滤，增强风险期(4/20-25)自动降级</li>
      <li><b>板块轮动因子+动量确认</b>：板块连续3天强势才算确认，单日热点不确认</li>
      <li><b>时间衰减因子</b>：首期效果-2.29% vs 稳定期+3.51%，首期自动降一级</li>
      <li><b>换手率精化</b>：5-15%最优>35%直接归入D类回避</li>
    </ol>
  </div>

  <div class="risk-box">
    <h3>风险提示 + 情绪周期心法</h3>
    <p>
      1. 本报告基于{date_display}龙虎榜数据，仅供参考，不构成投资建议。<br>
      2. v3.2情绪周期模块基于市场情绪周期理论，配合量化指标判断，但情绪可能突变。<br>
      3. 核心口诀：<b>冰点观望等拐点，回暖加仓做主线，高潮减仓落口袋，退潮空仓保本金。</b><br>
      4. 逆周期操作是最大风险：退潮期强行交易胜率<30%。<br>
      5. 股市有风险，投资需量力而行，严格止损。
    </p>
  </div>
</div>

<footer>打板3 v3.2 智能龙虎榜分析 | 生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | 情绪周期+分类推荐+大盘情绪+板块轮动+时间衰减 | 心法：冰点等拐点→回暖做主线→高潮落口袋→退潮保本金</footer>
</body>
</html>"""
    
    return html


if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser(description='打板3 v3.0 智能龙虎榜分析')
    parser.add_argument('--date', type=str, help='分析日期YYYYMMDD')
    parser.add_argument('--top', type=int, default=10, help='推荐数量')
    parser.add_argument('--output-dir', type=str, default='.', help='输出目录')
    
    args = parser.parse_args()
    
    if not AKSHARE_AVAILABLE:
        print("错误: akshare未安装")
        sys.exit(1)
    
    if args.date:
        target_date = args.date
    else:
        d = datetime.now()
        while d.weekday() >= 5:
            d -= timedelta(days=1)
        target_date = d.strftime('%Y%m%d')
    
    result = run_daban3_v2(target_date, top_n=args.top, output_dir=args.output_dir)
    sys.exit(0 if result else 1)
