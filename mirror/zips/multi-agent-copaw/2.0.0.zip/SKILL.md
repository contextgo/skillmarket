---
name: multi_agent_collab
description: "CoPaw 多智能体协作技能 — 快速搭建、配置和管理多智能体协作系统。支持智能体创建、互信配置、任务分发、协作对话、结果汇总等功能。"
metadata:
  {
    "builtin_skill_version": "1.0",
    "copaw":
      {
        "emoji": "🤝",
        "requires": {"bins": [], "envs": []}
      }
  }
---

# CoPaw 多智能体协作技能

本技能帮助用户快速搭建和管理 CoPaw 多智能体协作系统，实现多个智能体之间的高效协作。

## 核心功能

| 功能 | 说明 |
|------|------|
| 🏗️ **智能体创建** | 快速创建多个具有不同角色的智能体 |
| 🔗 **互信配置** | 配置智能体之间的通信权限和信任关系 |
| 📋 **任务分发** | 将复杂任务分解并分发给不同智能体 |
| 💬 **协作对话** | 管理智能体之间的多轮对话和会话 |
| 📊 **结果汇总** | 收集并汇总各智能体的工作成果 |
| 🔄 **流程编排** | 定义智能体协作的工作流程 |

## 使用步骤

### 1. 环境发现

首先确认 CoPaw 多智能体环境：

```bash
# 查看当前所有智能体
copaw agents list

# 查看 CoPaw 版本
copaw --version

# 确认工作区目录
echo $COPAW_WORKING_DIR  # 默认 ~/.copaw
```

### 2. 创建协作智能体

使用 CLI 或 API 创建多个智能体：

```bash
# 方式 1: 通过 config.json 配置（推荐批量创建）
# 编辑 ~/.copaw/config.json，添加 agents.profiles

# 方式 2: 通过 API 创建单个智能体
curl -X POST http://127.0.0.1:8088/agents \
  -H "Content-Type: application/json" \
  -d '{"name": "智能体名称", "description": "描述"}'
```

### 3. 配置智能体角色

为每个智能体创建角色定义文件（在工作区目录下）：

```
~/.copaw/workspaces/{agent_id}/
├── agent.json          # 智能体配置
├── AGENTS.md           # 角色职责定义
├── SOUL.md             # 行为原则
└── PROFILE.md          # 身份资料
```

### 4. 智能体间通信

```bash
# CLI 方式：智能体 A 与智能体 B 对话
copaw agents chat \
  --from-agent agent_a \
  --to-agent agent_b \
  --text "请处理这个任务..."

# 创建新会话
copaw agents chat \
  --from-agent agent_a \
  --to-agent agent_b \
  --text "开始新任务" \
  --new-session
```

### 5. 任务编排流程

典型的多智能体协作流程：

```
用户请求
   ↓
[协调者智能体] ← 任务分解
   ↓
┌────┬────┬────┐
↓    ↓    ↓    ↓
[A]  [B]  [C]  [D]  ← 执行智能体
↓    ↓    ↓    ↓
└────┴────┴────┘
   ↓
[汇总智能体] ← 结果收集
   ↓
返回用户
```

## 智能体角色模板

### 协调者 (Coordinator)

```markdown
## 职责
- 接收用户请求
- 分析任务并分解为子任务
- 分发给合适的执行智能体
- 监控进度并协调冲突
- 汇总结果返回用户

## 能力
- 任务分析
- 智能体选择
- 进度跟踪
- 冲突解决
```

### 执行者 (Executor)

```markdown
## 职责
- 接收协调者分发的子任务
- 执行具体工作
- 返回执行结果
- 报告异常情况

## 能力
- 专业领域技能
- 独立完成任务
- 清晰汇报结果
```

### 审核者 (Reviewer)

```markdown
## 职责
- 审核执行者的输出
- 确保质量标准
- 提供改进建议
- 最终批准或驳回

## 能力
- 质量检查
- 标准制定
- 反馈提供
```

## 会话管理

### 会话 ID 格式

```
{from_agent}:to:{to_agent}:{timestamp_ms}:{uuid_short}
示例：agent_a:to:agent_b:1775061852956:2ba24d30
```

### 会话最佳实践

1. **唯一会话**：每个任务使用新会话 ID
2. **身份前缀**：消息包含 `[Agent {id} requesting]` 前缀
3. **会话追踪**：记录会话 ID 便于追溯
4. **超时处理**：设置合理的响应超时

## 配置文件示例

### config.json 多智能体配置

```json
{
  "agents": {
    "profiles": {
      "coordinator": {
        "id": "coordinator",
        "workspace_dir": "~/.copaw/workspaces/coordinator"
      },
      "researcher": {
        "id": "researcher",
        "workspace_dir": "~/.copaw/workspaces/researcher"
      },
      "writer": {
        "id": "writer",
        "workspace_dir": "~/.copaw/workspaces/writer"
      }
    },
    "active_agent": "coordinator"
  }
}
```

### agent.json 智能体配置

```json
{
  "id": "coordinator",
  "name": "协调者",
  "description": "负责任务分解和协调",
  "workspace_dir": "~/.copaw/workspaces/coordinator",
  "channels": {
    "imessage": {"enabled": false},
    "discord": {"enabled": false}
  },
  "language": "zh",
  "system_prompt_files": ["AGENTS.md", "SOUL.md", "PROFILE.md"]
}
```

## 协作模式

### 1. 链式协作

```
A → B → C → 结果
```

每个智能体处理后将结果传递给下一个。

### 2. 并行协作

```
     → A →
用户 → B → 汇总
     → C →
```

多个智能体并行处理，最后汇总。

### 3. 层级协作

```
        协调者
       /  |  \
      A   B   C
```

协调者管理多个执行者。

### 4. 迭代协作

```
用户 → A → B → 审核 → (不通过) → A → ...
                          ↓ (通过)
                        结果
```

带反馈循环的迭代优化。

## 常见问题

### Q: 如何确保智能体不互相干扰？

**A:** 使用独立的工作区目录和会话 ID。

### Q: 智能体通信有延迟吗？

**A:** 本地智能体通信延迟很低，通过 HTTP API 或 CLI。

### Q: 如何调试多智能体协作？

**A:** 查看日志 `~/.copaw/copaw.log`，使用 `copaw daemon logs`。

### Q: 智能体可以动态添加吗？

**A:** 可以，通过 API 或修改 config.json 后 reload。

## 安全注意事项

1. **权限隔离**：不同智能体使用不同的 API 密钥
2. **数据边界**：智能体只能访问自己的工作区
3. **通信审计**：记录智能体间的所有通信
4. **资源限制**：为每个智能体设置资源配额

## 性能优化

1. **并发控制**：配置 `LLM_MAX_CONCURRENT` 限制并发调用
2. **速率限制**：配置 `LLM_MAX_QPM` 防止 API 超限
3. **缓存策略**：对重复查询使用缓存
4. **批量处理**：合并小任务减少调用次数

## 监控与日志

```bash
# 查看智能体状态
copaw daemon status

# 查看实时日志
copaw daemon logs --follow

# 查看特定智能体日志
grep "agent_id=coordinator" ~/.copaw/copaw.log
```

## 快速开始示例

创建一个简单的研究 - 写作协作系统：

```bash
# 1. 创建智能体工作区目录
mkdir -p ~/.copaw/workspaces/{researcher,writer,reviewer}

# 2. 编辑 config.json 添加智能体配置

# 3. 为每个智能体创建角色文件
# ~/.copaw/workspaces/researcher/AGENTS.md
# ~/.copaw/workspaces/writer/AGENTS.md
# ~/.copaw/workspaces/reviewer/AGENTS.md

# 4. 重启 CoPaw 加载新配置
copaw daemon restart

# 5. 测试智能体通信
copaw agents chat \
  --from-agent default \
  --to-agent researcher \
  --text "请研究人工智能的最新发展"
```

## API 参考

| 端点 | 方法 | 说明 |
|------|------|------|
| `/agents` | GET | 列出所有智能体 |
| `/agents` | POST | 创建新智能体 |
| `/agents/{id}` | GET | 获取智能体详情 |
| `/agents/{id}` | PUT | 更新智能体配置 |
| `/agents/{id}` | DELETE | 删除智能体 |
| `/agents/{id}/chat` | POST | 与智能体对话 |
| `/agents/{id}/enable` | POST | 启用智能体 |
| `/agents/{id}/disable` | POST | 禁用智能体 |

---

**版本：** 1.0  
**最后更新：** 2026-04-02  
**兼容 CoPaw：** v1.0.0+
