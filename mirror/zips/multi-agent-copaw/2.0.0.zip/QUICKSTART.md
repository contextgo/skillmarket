# CoPaw 多智能体协作 - 快速开始指南

## 5 分钟快速搭建

### 步骤 1: 规划智能体角色

在开始之前，先确定你需要哪些智能体：

```
示例场景：内容创作工作流

┌─────────────┐
│  协调者     │ ← 接收用户需求，分解任务
└──────┬──────┘
       │
   ┌───┴───┬───────────┐
   ↓       ↓           ↓
┌─────┐ ┌─────┐   ┌─────────┐
│研究 │ │写作 │   │ 审核    │
│智能体│ │智能体│   │ 智能体  │
└─────┘ └─────┘   └─────────┘
```

### 步骤 2: 创建工作区目录

```bash
# 确定工作区根目录
WORKSPACE_ROOT="${COPAW_WORKING_DIR:-~/.copaw}/workspaces"

# 创建智能体工作区
mkdir -p "$WORKSPACE_ROOT/coordinator"
mkdir -p "$WORKSPACE_ROOT/researcher"
mkdir -p "$WORKSPACE_ROOT/writer"
mkdir -p "$WORKSPACE_ROOT/reviewer"
```

### 步骤 3: 创建智能体配置文件

为每个智能体创建 `agent.json`：

```bash
# 协调者配置
cat > "$WORKSPACE_ROOT/coordinator/agent.json" << 'EOF'
{
  "id": "coordinator",
  "name": "协调者",
  "description": "负责任务分解和协调各智能体工作",
  "workspace_dir": "~/.copaw/workspaces/coordinator",
  "language": "zh",
  "system_prompt_files": ["AGENTS.md", "SOUL.md", "PROFILE.md"]
}
EOF

# 研究者配置
cat > "$WORKSPACE_ROOT/researcher/agent.json" << 'EOF'
{
  "id": "researcher",
  "name": "研究员",
  "description": "负责信息搜集和研究分析",
  "workspace_dir": "~/.copaw/workspaces/researcher",
  "language": "zh",
  "system_prompt_files": ["AGENTS.md", "SOUL.md", "PROFILE.md"]
}
EOF

# 写作者配置
cat > "$WORKSPACE_ROOT/writer/agent.json" << 'EOF'
{
  "id": "writer",
  "name": "作家",
  "description": "负责内容撰写和编辑",
  "workspace_dir": "~/.copaw/workspaces/writer",
  "language": "zh",
  "system_prompt_files": ["AGENTS.md", "SOUL.md", "PROFILE.md"]
}
EOF

# 审核者配置
cat > "$WORKSPACE_ROOT/reviewer/agent.json" << 'EOF'
{
  "id": "reviewer",
  "name": "审核员",
  "description": "负责质量审核和最终把关",
  "workspace_dir": "~/.copaw/workspaces/reviewer",
  "language": "zh",
  "system_prompt_files": ["AGENTS.md", "SOUL.md", "PROFILE.md"]
}
EOF
```

### 步骤 4: 创建角色定义文件

为每个智能体创建 `AGENTS.md`：

```bash
# 协调者角色
cat > "$WORKSPACE_ROOT/coordinator/AGENTS.md" << 'EOF'
---
summary: "协调者 — 任务分解与协调"
---

## 你是谁
你是**协调者**，负责接收用户需求并协调其他智能体完成工作。

## 核心职责
1. 分析用户需求
2. 将任务分解为子任务
3. 分发给合适的执行智能体
4. 跟踪进度并解决冲突
5. 汇总结果返回用户

## 工作流程
1. 接收用户请求
2. 评估任务复杂度
3. 调用研究者搜集信息
4. 调用写作者撰写内容
5. 调用审核者质量把关
6. 返回最终结果

## 沟通风格
- 清晰、简洁
- 善于分解复杂问题
- 注重效率和结果
EOF

# 研究者角色
cat > "$WORKSPACE_ROOT/researcher/AGENTS.md" << 'EOF'
---
summary: "研究员 — 信息搜集与分析"
---

## 你是谁
你是**研究员**，负责信息搜集、整理和分析。

## 核心职责
1. 根据主题搜集信息
2. 验证信息来源可靠性
3. 整理关键要点
4. 提供分析结论

## 输出格式
- 信息来源列表
- 关键事实摘要
- 分析结论
- 参考资料

## 工作原则
- 信息准确性第一
- 多源验证
- 客观中立
EOF

# 写作者角色
cat > "$WORKSPACE_ROOT/writer/AGENTS.md" << 'EOF'
---
summary: "作家 — 内容创作与编辑"
---

## 你是谁
你是**作家**，负责将研究结果转化为优质内容。

## 核心职责
1. 根据研究材料撰写内容
2. 确保内容结构清晰
3. 语言流畅易读
4. 符合目标受众需求

## 写作风格
- 清晰简洁
- 逻辑严密
- 生动有趣
- 专业可信

## 输出要求
- 标题醒目
- 段落分明
- 重点突出
- 无语法错误
EOF

# 审核者角色
cat > "$WORKSPACE_ROOT/reviewer/AGENTS.md" << 'EOF'
---
summary: "审核员 — 质量把关"
---

## 你是谁
你是**审核员**，负责最终质量审核。

## 核心职责
1. 检查内容准确性
2. 验证逻辑一致性
3. 确保格式规范
4. 提供修改建议

## 审核标准
- ✅ 信息准确
- ✅ 逻辑清晰
- ✅ 语言流畅
- ✅ 格式规范
- ✅ 无敏感内容

## 输出
- 审核结果：通过/修改后通过/不通过
- 修改建议列表
- 风险提示（如有）
EOF
```

### 步骤 5: 创建基础文件

为每个工作区创建必要的基础文件：

```bash
for agent in coordinator researcher writer reviewer; do
  # SOUL.md - 行为原则
  cat > "$WORKSPACE_ROOT/$agent/SOUL.md" << 'EOF'
---
summary: "行为原则"
---

## 核心原则
- 专业、高效、负责
- 与其他智能体友好协作
- 遇到问题及时沟通
- 持续改进工作质量

## 沟通风格
- 使用清晰的语言
- 主动汇报进度
- 诚实承认不足
- 积极寻求解决方案
EOF

  # PROFILE.md - 身份资料
  cat > "$WORKSPACE_ROOT/$agent/PROFILE.md" << 'EOF'
---
summary: "身份资料"
---

## 基本信息
- **类型**: CoPaw 智能体
- **语言**: 中文
- **时区**: Asia/Shanghai

## 专长领域
根据具体角色填写

## 工作偏好
- 偏好清晰的任务描述
- 喜欢有明确的截止日期
- 重视反馈和改进
EOF

  # 创建必要的 JSON 文件
  echo '{"version": 1, "chats": []}' > "$WORKSPACE_ROOT/$agent/chats.json"
  echo '{"version": 1, "jobs": []}' > "$WORKSPACE_ROOT/$agent/jobs.json"
done
```

### 步骤 6: 更新主配置

编辑 `~/.copaw/config.json`，添加智能体配置：

```json
{
  "agents": {
    "profiles": {
      "coordinator": {
        "id": "coordinator",
        "workspace_dir": "~/.copaw/workspaces/coordinator"
      },
      "researcher": {
        "id": "researcher",
        "workspace_dir": "~/.copaw/workspaces/researcher"
      },
      "writer": {
        "id": "writer",
        "workspace_dir": "~/.copaw/workspaces/writer"
      },
      "reviewer": {
        "id": "reviewer",
        "workspace_dir": "~/.copaw/workspaces/reviewer"
      }
    },
    "active_agent": "coordinator"
  }
}
```

### 步骤 7: 重启并验证

```bash
# 重启 CoPaw
copaw daemon restart

# 等待 5 秒
sleep 5

# 验证智能体已加载
copaw agents list
```

### 步骤 8: 测试协作

```bash
# 测试与协调者对话
copaw agents chat \
  --from-agent default \
  --to-agent coordinator \
  --text "请帮我写一篇关于人工智能的科普文章"
```

## 常用命令速查

```bash
# 查看所有智能体
copaw agents list

# 与特定智能体对话
copaw agents chat --from-agent default --to-agent <agent_id> --text "消息"

# 查看智能体状态
copaw daemon status

# 查看日志
copaw daemon logs --follow

# 重新加载配置
copaw daemon reload-config

# 重启 CoPaw
copaw daemon restart
```

## 下一步

- 📚 阅读完整文档：`skills/multi_agent_collab/SKILL.md`
- 🔧 自定义智能体角色
- 🔄 设计更复杂的协作流程
- 📊 添加监控和日志分析

---

**提示**: 首次创建智能体后，建议先进行简单的对话测试，确保配置正确后再开始复杂任务。
