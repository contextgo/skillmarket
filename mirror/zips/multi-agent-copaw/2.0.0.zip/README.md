# CoPaw 多智能体协作技能 (multi_agent_collab)

🤝 **快速搭建和管理 CoPaw 多智能体协作系统**

---

## 📖 概述

本技能提供完整的工具集和模板，帮助用户快速搭建 CoPaw 多智能体协作系统。通过本技能，您可以：

- ✅ 快速创建多个具有不同角色的智能体
- ✅ 配置智能体之间的通信和协作
- ✅ 使用预定义的角色模板
- ✅ 管理智能体工作流程
- ✅ 监控协作进度和结果

---

## 🚀 快速开始

### 方式 1: 使用 Python 脚本（推荐）

```bash
# 创建内容创作团队（4 个智能体）
python3 /app/working/workspaces/default/skills/multi_agent_collab/multi_agent_setup.py --team content

# 创建开发团队
python3 /app/working/workspaces/default/skills/multi_agent_collab/multi_agent_setup.py --team dev

# 创建研究团队
python3 /app/working/workspaces/default/skills/multi_agent_collab/multi_agent_setup.py --team research

# 创建单个智能体
python3 /app/working/workspaces/default/skills/multi_agent_collab/multi_agent_setup.py \
  --name "我的智能体" \
  --role coordinator \
  --id my_agent
```

### 方式 2: 手动创建

参考 [`QUICKSTART.md`](./QUICKSTART.md) 详细步骤。

---

## 📁 文件结构

```
multi_agent_collab/
├── SKILL.md              # 技能完整文档
├── QUICKSTART.md         # 5 分钟快速开始指南
├── TEMPLATES.md          # 角色模板库
├── multi_agent_setup.py  # 自动化搭建脚本
├── skill.json            # 技能配置
└── README.md             # 本文件
```

---

## 🎭 预定义角色

| 角色 | ID | 职责 |
|------|-----|------|
| 协调者 | coordinator | 任务分解与协调 |
| 研究员 | researcher | 信息搜集与分析 |
| 作家 | writer | 内容创作与编辑 |
| 审核员 | reviewer | 质量审核与把关 |

---

## 👥 预设团队

### 内容创作团队 (content)

```
协调者 → 研究员 → 作家 → 审核员
```

适用于：文章写作、报告生成、内容创作等场景。

### 开发团队 (dev)

```
产品经理 → 架构师 → 开发者 → 测试工程师
```

适用于：软件开发、代码审查、技术文档等场景。

### 研究团队 (research)

```
研究主管 → 分析师 → 报告撰写 → 审核员
```

适用于：市场调研、数据分析、学术研究等场景。

---

## 💬 智能体通信

### CLI 方式

```bash
# 智能体 A 与智能体 B 对话
copaw agents chat \
  --from-agent default \
  --to-agent coordinator \
  --text "请帮我写一篇关于 AI 的文章"

# 创建新会话
copaw agents chat \
  --from-agent default \
  --to-agent researcher \
  --text "请研究 AI 的最新发展" \
  --new-session
```

### API 方式

```bash
# 列出所有智能体
curl http://127.0.0.1:8088/agents

# 与智能体对话
curl -X POST http://127.0.0.1:8088/agents/coordinator/chat \
  -H "Content-Type: application/json" \
  -d '{"text": "请开始任务"}'
```

---

## 📊 协作模式

### 链式协作

```
A → B → C → 结果
```

### 并行协作

```
     → A →
用户 → B → 汇总
     → C →
```

### 层级协作

```
        协调者
       /  |  \
      A   B   C
```

### 迭代协作

```
用户 → A → B → 审核 → (不通过) → A → ...
                          ↓ (通过)
                        结果
```

---

## 🔧 常用命令

```bash
# 查看所有智能体
copaw agents list

# 查看智能体状态
copaw daemon status

# 查看日志
copaw daemon logs --follow

# 重启 CoPaw
copaw daemon restart

# 重新加载配置
copaw daemon reload-config
```

---

## 📚 文档链接

- [完整技能文档](./SKILL.md) - 详细功能说明和 API 参考
- [快速开始指南](./QUICKSTART.md) - 5 分钟搭建教程
- [角色模板库](./TEMPLATES.md) - 8 种通用角色模板

---

## 🛠️ 自定义角色

1. 复制 `TEMPLATES.md` 中的角色模板
2. 修改角色定义（AGENTS.md、SOUL.md、PROFILE.md）
3. 运行搭建脚本创建智能体
4. 测试并调整

---

## ⚠️ 注意事项

1. **工作区隔离**: 每个智能体有独立的工作区目录
2. **会话管理**: 使用唯一会话 ID 追踪对话
3. **资源配置**: 合理设置 LLM 并发和速率限制
4. **安全边界**: 不同智能体使用不同的 API 密钥

---

## 📝 更新日志

### v1.0 (2026-04-02)

- ✅ 初始版本发布
- ✅ 4 种预定义角色
- ✅ 3 种预设团队
- ✅ 自动化搭建脚本
- ✅ 完整文档

---

## 🤝 贡献

欢迎提交 Issue 和 Pull Request 改进本技能！

---

**兼容 CoPaw**: v1.0.0+  
**最后更新**: 2026-04-02  
**作者**: CoPaw Community
