# 报告生成脚本使用指南

## 脚本位置
`scripts/generate_report.py`

## 前置要求
- Python 3.12+
- 无需额外安装包（仅使用标准库 json, os, datetime）

## 使用方式

### 1. 准备数据文件

创建JSON数据文件，默认路径为脚本同目录下的 `v12_data.json`。

JSON结构：
```json
{
  "行业key": [
    {
      "name": "企业全称 - 需求描述",
      "prob": 88,
      "high": 1,
      "urgent": 1,
      "urgent_text": "紧急描述",
      "case_badge": 1,
      "case_text": "案例标签",
      "reason": "<b>行业匹配：</b>20/20分<br><b>产品相似：</b>18/20分<br><b>需求证据：</b>...",
      "sources": [["链接标题", "https://url"], ["标题2", "https://url2"]]
    }
  ]
}
```

### 2. 行业key映射

脚本中硬编码了以下行业分类：
| JSON key | 报告显示名 |
|----------|-----------|
| insurance | 保险行业 |
| liquor | 零售行业（白酒） |
| education | 教育行业 |
| game | 游戏行业 |
| ecommerce | 电商行业 |
| cpa | 渠道-CPA投放行业 |

如需新增行业，需修改 `generate_report.py` 中的 `inds` 列表。

### 3. 修改默认路径

脚本中的 `DATA_DIR` 和 `OUT_DIR` 默认指向：
```
/Users/zhou/WorkBuddy/20260413203005/rta_agent/data
```

使用时需根据实际项目路径修改这两个变量，或改为动态获取：
```python
DATA_DIR = os.path.dirname(os.path.abspath(__file__))
```

### 4. 执行命令

```bash
/Library/Frameworks/Python.framework/Versions/3.12/bin/python3 scripts/generate_report.py
```

### 5. 输出文件

默认输出：`{OUT_DIR}/作战地图商机分析报告_20260415_v12.html`

## 注意事项

- `execute_command` 有8000字节限制，大数据需分批写入JSON
- 先用Python分批写入JSON各行业数据，再执行脚本
- HTML报告使用CSS内联样式，无需外部依赖
- reason字段支持HTML标签（<b>, <br>, <span>）
