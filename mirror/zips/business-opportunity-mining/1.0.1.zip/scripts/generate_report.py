#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""V12 report - data + generator"""
import json,os
from datetime import datetime

# Read data from JSON file
DATA_DIR = "/Users/zhou/WorkBuddy/20260413203005/rta_agent/data"
OUT_DIR = DATA_DIR

def render_card(opp):
    pc = "ph" if opp["prob"] >= 80 else "pm"
    tag = '<span class="pt th">高优先级</span>' if opp.get("high") else '<span class="pt tm">中优先级</span>'
    urg = f' <span class="pt tu">{opp["urgent_text"]}</span>' if opp.get("urgent") else ""
    case = f' <span class="cb">{opp["case_text"]}</span>' if opp.get("case_badge") else ""
    srcs = ""
    for s in opp.get("sources", []):
        srcs += f'<a class="sl" href="{s[1]}" target="_blank">[{s[0]}]</a> '
    if not srcs: srcs = '<span style="color:#a0aec0;font-size:12px;">暂无外部链接</span>'
    return f'<div class="oc"><div class="oh"><span class="on">{opp["name"]}{case}</span><span><span class="op {pc}">{opp["prob"]}%</span>{tag}{urg}</span></div><div class="or">{opp["reason"]}</div><div style="margin-top:8px;">{srcs}</div></div>'

def build_html():
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    # Load data
    data_path = os.path.join(DATA_DIR, "v12_data.json")
    with open(data_path, 'r', encoding='utf-8') as f:
        DATA = json.load(f)
    
    inds = [
        ("insurance","保险行业","标杆3家 | 推荐10家"),
        ("liquor","零售行业（白酒）","标杆1家（五粮液） | 推荐5家"),
        ("education","教育行业","标杆1家（广州简知） | 推荐5家"),
        ("game","游戏行业","标杆1家（深圳必凡） | 推荐5家"),
        ("ecommerce","电商行业","标杆1家（广州枳云-兜爸严选） | 推荐5家"),
        ("cpa","渠道-CPA投放行业","标杆2家（深圳辉煌、深圳乐龙） | 推荐5家"),
    ]
    oh = ""
    hl = []
    for k,l,cl in inds:
        items = DATA[k]
        oh += f'<div class="ig"><div class="it">{l} <span class="ic">{cl}</span></div>'
        for i in items:
            oh += render_card(i)
            if i.get("high"): hl.append(i)
        oh += "</div>"
    hh = ""
    for i in hl:
        pc = "ph" if i["prob"]>=80 else "pm"
        u = f' <span style="color:#c53030;font-weight:700;">{i["urgent_text"]}</span>' if i.get("urgent") else ""
        c = f' <span class="cb">{i["case_text"]}</span>' if i.get("case_badge") else ""
        hh += f'<tr><td>{i["name"]}{c}{u}</td><td class="{pc}" style="font-size:18px;font-weight:800;">{i["prob"]}%</td></tr>\n'
    
    fp = os.path.join(OUT_DIR, "作战地图商机分析报告_20260415_v12.html")
    
    # CSS
    css = """*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif;color:#1a1a2e;background:#f8f9fa;line-height:1.7;}
.c{max-width:1100px;margin:0 auto;padding:40px 30px;}
.cover{text-align:center;padding:60px 0 40px;border-bottom:3px solid #1a365d;margin-bottom:40px;}
.cover h1{font-size:32px;color:#1a365d;font-weight:700;letter-spacing:2px;margin-bottom:12px;}
.cover .sub{font-size:16px;color:#4a5568;margin-bottom:6px;}
.cover .t{font-size:14px;color:#718096;}
.toc{background:#fff;border-radius:12px;padding:30px 40px;margin-bottom:30px;box-shadow:0 2px 8px rgba(0,0,0,.06);}
.toc h2{font-size:20px;color:#1a365d;margin-bottom:16px;border-left:4px solid #2b6cb0;padding-left:12px;}
.toc ol{padding-left:24px;}.toc li{margin:8px 0;font-size:15px;}.toc a{color:#2b6cb0;text-decoration:none;}
.sec{background:#fff;border-radius:12px;padding:30px 36px;margin-bottom:24px;box-shadow:0 2px 8px rgba(0,0,0,.06);}
.sec h2{font-size:22px;color:#1a365d;margin-bottom:20px;border-left:4px solid #2b6cb0;padding-left:12px;}
.sec h3{font-size:18px;color:#2d3748;margin:20px 0 12px;}
.ib{background:#f7fafc;border:1px solid #e2e8f0;border-radius:8px;padding:20px 24px;margin:16px 0;}
.ib .lb{font-size:13px;color:#718096;font-weight:600;letter-spacing:1px;margin-bottom:8px;}
.ib .vl{font-size:15px;color:#2d3748;}
table{width:100%;border-collapse:collapse;margin:16px 0;font-size:14px;}
th{background:#edf2f7;color:#2d3748;font-weight:600;padding:12px 14px;text-align:left;border-bottom:2px solid #cbd5e0;}
td{padding:10px 14px;border-bottom:1px solid #e2e8f0;color:#4a5568;}
tr:hover{background:#f7fafc;}
.oc{border:1px solid #e2e8f0;border-radius:10px;padding:20px 24px;margin:14px 0;}
.oh{display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;flex-wrap:wrap;gap:8px;}
.on{font-size:17px;font-weight:700;color:#1a365d;}
.op{font-size:20px;font-weight:800;}
.ph{color:#c53030;}.pm{color:#2b6cb0;}
.pt{display:inline-block;font-size:11px;font-weight:700;padding:2px 10px;border-radius:10px;margin-left:10px;}
.th{background:#fed7d7;color:#c53030;}.tm{background:#bee3f8;color:#2b6cb0;}
.tu{background:#fc8181;color:#fff;animation:pulse 1.5s infinite;}
@keyframes pulse{0%,100%{opacity:1;}50%{opacity:.7;}}
.or{font-size:14px;color:#4a5568;line-height:1.8;margin-top:8px;}
.or b{color:#2d3748;}
.sl{font-size:12px;color:#2b6cb0;display:inline-block;margin:4px 6px 4px 0;}
.cb{display:inline-block;font-size:11px;font-weight:600;padding:2px 8px;border-radius:4px;background:#c6f6d5;color:#276749;margin-left:6px;}
.ig{margin:24px 0;}
.it{font-size:19px;font-weight:700;color:#1a365d;margin-bottom:14px;padding-bottom:8px;border-bottom:2px solid #e2e8f0;display:flex;align-items:center;gap:10px;}
.ic{font-size:13px;font-weight:500;background:#edf2f7;color:#4a5568;padding:2px 10px;border-radius:10px;}
.sb{background:linear-gradient(135deg,#ebf4ff,#e6fffa);border-radius:10px;padding:20px 24px;margin:20px 0;}
.sb h4{font-size:15px;color:#1a365d;margin-bottom:8px;}.sb ul{padding-left:20px;font-size:14px;color:#2d3748;}.sb li{margin:4px 0;}
.ft{text-align:center;padding:30px 0;font-size:12px;color:#a0aec0;border-top:1px solid #e2e8f0;margin-top:30px;}
"""
    
    html = f'''<!DOCTYPE html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>作战地图商机分析报告</title>
<style>{css}</style></head><body><div class="c">
<div class="cover"><h1>作战地图商机分析报告</h1><div class="sub">基于腾讯广告RTA实时优化解决方案的潜在商机挖掘</div><div class="t">报告生成时间：{now}</div></div>
<div class="toc"><h2>报告目录</h2><ol><li><a href="#s1">输入信息概览</a></li><li><a href="#s2">项目分类结果</a></li><li><a href="#s3">标杆企业画像摘要</a></li><li><a href="#s4">潜在商机推荐列表</a></li><li><a href="#s5">高价值商机重点标注</a></li><li><a href="#s6">销售跟进建议</a></li></ol></div>
<div class="sec" id="s1"><h2>一、输入信息概览</h2>
<div class="ib"><div class="lb">售卖产品名称</div><div class="vl">腾讯广告RTA实时优化解决方案</div></div>
<div class="ib"><div class="lb">核心能力</div><div class="vl">精准人群圈选 | 实时ROI优化 | 成本控量 | 全域投放 | 效果追踪</div></div>
<div class="ib"><div class="lb">核心场景关键词</div><div class="vl">广告投放 | 营销转化 | 效果优化 | 人群包 | RTA | 朋友圈 | 视频号 | 公众号</div></div>
<div class="ib"><div class="lb">作战地图来源</div><div class="vl">【内部】广告流量筛选专项.xlsx - 作战地图（共9家企业）</div></div></div>
<div class="sec" id="s2"><h2>二、项目分类结果</h2>
<h3>已签项目（1家）</h3><table><tr><th>企业名称</th><th>行业</th><th>项目阶段</th></tr><tr><td>五粮液</td><td>零售</td><td><b style="color:#276749;">合同签订</b></td></tr></table>
<h3>POC项目（8家）</h3><table><tr><th>企业名称</th><th>行业</th><th>项目阶段</th></tr>
<tr><td>广州简知</td><td>教育</td><td>POC</td></tr><tr><td>深圳必凡</td><td>游戏</td><td>POC</td></tr><tr><td>广州枳云-兜爸严选</td><td>电商</td><td>POC</td></tr><tr><td>星火保</td><td>金融-保险</td><td>POC</td></tr><tr><td>深圳辉煌</td><td>渠道-CPA投放</td><td>POC</td></tr><tr><td>深圳乐龙</td><td>渠道-CPA投放</td><td>POC</td></tr><tr><td>众安-企财</td><td>保险</td><td>POC</td></tr><tr><td>众安-家财安心保</td><td>保险</td><td>POC</td></tr></table>
<div class="sb"><h4>行业分布汇总</h4><ul>
<li><b>保险/金融-保险</b>：3家标杆 - 推荐10家商机</li>
<li><b>零售</b>：1家标杆（五粮液）- 推荐5家商机</li>
<li><b>教育</b>：1家标杆（广州简知）- 推荐5家商机</li>
<li><b>游戏</b>：1家标杆（深圳必凡）- 推荐5家商机</li>
<li><b>电商</b>：1家标杆（广州枳云-兜爸严选）- 推荐5家商机</li>
<li><b>渠道-CPA投放</b>：2家标杆（深圳辉煌、深圳乐龙）- 推荐5家商机</li>
</ul></div></div>
<div class="sec" id="s3"><h2>三、标杆企业画像摘要</h2>
<h3>已签标杆：五粮液</h3>
<div class="oc"><div class="or"><b>行业：</b>零售-白酒品牌 | <b>核心产品：</b>五粮液系列白酒<br><b>产品适配特征：</b>大型品牌企业，持续大规模广告投放，已签约验证合作意愿<br><b>需求痛点：</b>白酒行业竞争加剧，获客成本攀升，需精准触达高端消费人群</div></div>
<h3>POC标杆画像</h3>
<div class="oc"><div class="or"><b>保险（3家）：</b>星火保（互联网保险经纪，AI+双资质）、众安-企财（企业财产险）、众安-家财安心保（家庭财产险）。共性：线上保险获客需求强，依赖效果广告。<br><br><b>教育（1家）：</b>广州简知 - 在线教育平台<br><b>游戏（1家）：</b>深圳必凡 - 游戏公司<br><b>电商（1家）：</b>广州枳云-兜爸严选 - 社交电商<br><b>渠道-CPA投放（2家）：</b>深圳辉煌、深圳乐龙 - 广告投放代理</div></div></div>
<div class="sec" id="s4"><h2>四、潜在商机推荐列表</h2>
<p style="color:#718096;font-size:14px;margin-bottom:16px;">按行业分类，商机概率降序排列。评分模型：行业20% + 产品20% + 需求60%。标杆>=3家推荐10家，其余各推荐5家。</p>
{oh}
</div>
<div class="sec" id="s5"><h2>五、高价值商机重点标注</h2>
<table><tr><th>商机名称</th><th>商机概率</th></tr>{hh}</table>
<div class="sb"><h4>标注说明</h4><ul>
<li><span class="cb" style="margin:0 6px 0 0;">腾讯广告案例客户</span> 已验证合作意愿，合作风险低</li>
<li><span style="color:#c53030;font-weight:700;">紧急行动</span> 正在招标/征集供应商中，需立即跟进</li>
<li><span style="color:#2b6cb0;font-weight:700;">蓝色标注</span> 具备明确的产品适配需求或腾讯生态合作基础</li>
</ul></div></div>
<div class="sec" id="s6"><h2>六、销售跟进建议</h2>
<div class="sb"><h4>高优先级商机（>=80%）- 共{len(hl)}家</h4><ul>
<li><b>立即行动</b>：泰康保险（征集截止中）、古井贡酒（招标中）、舍得酒业（招标中）、太平人寿（招标中）- 需第一时间对接</li>
<li><b>重点推介</b>：剑南春、水滴保、微盟集团 - 已有腾讯生态合作基础</li>
<li><b>跟进策略</b>：重点推介RTA精准人群圈选和实时ROI优化能力</li>
</ul></div>
<div class="sb"><h4>中优先级商机（60%-79%）- 常规跟进</h4><ul>
<li><b>跟进策略</b>：先发送产品资料和成功案例，同步补充核实企业核心需求</li>
<li><b>重点培育</b>：小雨伞（招聘广告投放岗）、中国人寿（大规模广告招标）、三七互娱（买量需求极大）</li>
<li><b>持续关注</b>：定期监控招投标动态，把握合作窗口期</li>
</ul></div>
<div class="sb"><h4>紧急行动清单</h4><ul>
<li style="color:#c53030;font-weight:700;">1. 泰康保险 - 2026年4月2日征集效果广告供应商（tip.taikang.com）</li>
<li style="color:#c53030;font-weight:700;">2. 古井贡酒 - 2025-2026年度腾讯系广告投放竞争性选择（ahtba.org.cn）</li>
<li style="color:#c53030;font-weight:700;">3. 太平人寿 - 2025-2026年网络广告采购招标（eps.cntaiping.com）</li>
<li style="color:#c53030;font-weight:700;">4. 舍得酒业 - Q4程序化广告招标进行中（shede.cn）</li>
</ul></div></div>
<div class="ft">本报告由 WorkBuddy 作战地图商机分析Agent自动生成 | 数据来源：公开招投标平台、企业官网、权威媒体报道、招聘平台等</div>
</div></body></html>'''
    
    with open(fp, 'w', encoding='utf-8') as f:
        f.write(html)
    print(f"Report generated: {fp}")
    print(f"Total opportunities: {sum(len(DATA[k]) for k in DATA)}")
    print(f"High priority: {len(hl)}")

if __name__ == "__main__":
    build_html()
