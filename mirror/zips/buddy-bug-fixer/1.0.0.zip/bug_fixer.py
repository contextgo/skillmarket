"""
Bug Fixer - 极简版
Philosophy: Strong prompts, minimal code

确定性规则硬编码，复杂模式交给AI推理。
Skill由AI驱动，无CLI入口。
"""

import json
import re
import os
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Optional

# ============================================================
# 提示词配置 - 所有AI推理规则
# ============================================================

SYSTEM_PROMPT = """你是一个代码Bug修复助手。

任务流程：
1. 扫描代码找出所有潜在Bug
2. 分类：
   - AUTO-FIX: 可自动修复的简单模式
   - NEEDS-REVIEW: 需要人工审核的复杂问题
3. 对AUTO-FIX类型应用修复
4. 返回JSON格式结果

【自动修复规则 - 确定性】
- if/for/def/while 缺少冒号 → 添加冒号
- if x = y（赋值）→ if x == y（比较）
- 日期/时间排序缺少 reverse=True → 添加 reverse=True
- .append([...]) 创建嵌套列表 → 改为 .extend([...])
- 可变默认参数 def foo(data=[]) → 内部初始化
- except: → except Exception:

【需人工审核 - 复杂模式】
- 业务逻辑错误
- 空指针/类型错误
- 安全漏洞（SQL注入、XSS等）
- 性能问题
- 并发/线程安全问题

返回格式：
{
  "status": "ok|fixed|needs_review",
  "scanned": "文件名",
  "bugs_found": 数量,
  "auto_fixed": 数量,
  "needs_review": 数量,
  "details": [
    {
      "type": "auto_fix|needs_review",
      "line": 行号或null,
      "issue": "问题描述",
      "fix": "修复方案或'requires human review'"
    }
  ],
  "fixed_code": "修复后代码 或 null",
  "summary": "一行总结"
}"""


# ============================================================
# 确定性规则 - 硬编码，毫秒级检测
# ============================================================

PATTERNS = {
    "date_sort_no_reverse": {
        "type": "auto_fix",
        "severity": "low",
        "pattern": r"(\.sort\(|sorted\()(.*?)(\))",
        "check": lambda m, ctx: any(
            f in ctx["line"].lower()
            for f in ["created", "modified", "date", "time", "updated", "timestamp"]
        ) and "reverse" not in ctx["line"],
        "fix": lambda m: m.group(1) + m.group(2) + ", reverse=True" + m.group(3),
        "issue": "日期排序缺少 reverse=True"
    },
    "nested_append": {
        "type": "auto_fix",
        "severity": "low",
        "pattern": r"\.append\(\s*\[",
        "check": lambda m, ctx: True,
        "fix": lambda m: ".extend(",
        "issue": ".append([...]) 会创建嵌套列表"
    },
    "assignment_in_condition": {
        "type": "auto_fix",
        "severity": "medium",
        "pattern": r"if\s+(\w+)\s*=\s*(\w+)",
        "check": lambda m, ctx: "==" not in ctx["line"],
        "fix": lambda m: f"if {m.group(1)} == {m.group(2)}",
        "issue": "条件中使用了赋值而非比较"
    },
    "mutable_default": {
        "type": "needs_review",
        "severity": "medium",
        "pattern": r"def\s+\w+\([^)]*=\s*(\[\]|\{\}|set\(\))",
        "check": lambda m, ctx: True,
        "fix": lambda m: "requires human review",
        "issue": "可变默认参数可能导致意外行为"
    }
}


def quick_scan(code: str) -> List[Dict]:
    """确定性规则扫描 - 毫秒级"""
    bugs = []
    lines = code.split("\n")

    for i, line in enumerate(lines, 1):
        ctx = {"line": line, "line_num": i}

        for name, rule in PATTERNS.items():
            for match in re.finditer(rule["pattern"], line):
                if rule["check"](match, ctx):
                    fix_result = rule["fix"](match)
                    bugs.append({
                        "type": rule["type"],
                        "line": i,
                        "issue": rule["issue"],
                        "fix": fix_result if rule["type"] == "auto_fix" else "requires human review"
                    })
                    break  # 每行每种模式只报一次

    return bugs


def auto_fix(code: str, bugs: List[Dict]) -> tuple[str, List[Dict]]:
    """应用自动修复"""
    fixed = []
    new_code = code

    for bug in bugs:
        if bug["type"] != "auto_fix":
            continue

        old = bug["issue"]
        new = bug["fix"]

        if old == "日期排序缺少 reverse=True":
            new_code = re.sub(
                r"(\.sort\(|sorted\()(.*?)(\))",
                lambda m: m.group(1) + m.group(2) + ", reverse=True" + m.group(3),
                new_code
            )
            fixed.append({"issue": old, "fixed": new})

        elif old == ".append([...]) 会创建嵌套列表":
            new_code = new_code.replace(".append([", ".extend([")
            fixed.append({"issue": old, "fixed": new})

        elif old == "条件中使用了赋值而非比较":
            new_code = re.sub(
                r"if\s+(\w+)\s*=\s*(\w+)",
                lambda m: f"if {m.group(1)} == {m.group(2)}",
                new_code
            )
            fixed.append({"issue": old, "fixed": new})

    return new_code, fixed


# ============================================================
# AI分析接口 - DeepSeek API
# ============================================================

API_URL = "https://api.siliconflow.cn/v1/chat/completions"
API_KEY = os.environ.get("SILICONFLOW_API_KEY", "")


def ai_analyze(code: str, filename: str = "input") -> Optional[Dict]:
    """调用 DeepSeek 深度分析代码"""
    if not API_KEY:
        return {"error": "SILICONFLOW_API_KEY not set"}

    try:
        import requests

        messages = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": f"分析代码，找出Bug并修复：\n\n文件名: {filename}\n\n```{filename.split('.')[-1] if '.' in filename else 'python'}\n{code}\n```"}
        ]

        response = requests.post(
            API_URL,
            headers={
                "Authorization": f"Bearer {API_KEY}",
                "Content-Type": "application/json"
            },
            json={
                "model": "deepseek-ai/DeepSeek-V3",
                "messages": messages,
                "temperature": 0.1,
                "max_tokens": 4096
            },
            timeout=60
        )

        if response.status_code == 200:
            result = response.json()
            content = result["choices"][0]["message"]["content"]

            # 提取JSON
            if "```json" in content:
                content = content.split("```json")[1].split("```")[0]
            elif "```" in content:
                content = content.split("```")[1].split("```")[0]

            return json.loads(content.strip())
        else:
            return {"error": f"API error: {response.status_code}"}

    except Exception as e:
        return {"error": str(e)}


# ============================================================
# 主逻辑
# ============================================================

def analyze(code: str, filename: str = "input", use_ai: bool = True) -> Dict:
    """完整分析流程：快速扫描 → 自动修复 → AI深度分析"""

    # 1. 确定性规则扫描
    bugs = quick_scan(code)

    # 2. 自动修复简单Bug
    fixed_code, fixed = auto_fix(code, bugs)

    # 3. AI深度分析
    remaining = [b for b in bugs if b["type"] == "needs_review"]

    if use_ai and remaining and API_KEY:
        ai_result = ai_analyze(code, filename)
        if ai_result and "error" not in ai_result:
            # 合并AI发现的问题
            for detail in ai_result.get("details", []):
                if detail["type"] == "auto_fix":
                    bugs.append(detail)
            # AI可能有更好的修复
            if ai_result.get("fixed_code"):
                fixed_code = ai_result["fixed_code"]

    # 4. 生成报告
    return {
        "status": "ok" if not fixed else "fixed",
        "scanned": filename,
        "time": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "bugs_found": len(bugs),
        "auto_fixed": len(fixed),
        "needs_review": len(remaining),
        "details": bugs,
        "fixed_code": fixed_code if fixed else None,
        "summary": f"扫描完成，发现{len(bugs)}个Bug，自动修复{len(fixed)}个"
    }


def scan_file(filepath: str, auto_fix: bool = True) -> Dict:
    """扫描单个文件"""
    path = Path(filepath)
    code = path.read_text(encoding="utf-8")

    result = analyze(code, path.name)

    if auto_fix and result.get("fixed_code"):
        path.write_text(result["fixed_code"], encoding="utf-8")

    return result


def scan_directory(directory: str = ".") -> List[Dict]:
    """扫描目录下所有Python文件"""
    results = []

    for py_file in Path(directory).rglob("*.py"):
        if "__pycache__" in str(py_file):
            continue

        try:
            result = scan_file(str(py_file))
            results.append(result)
        except Exception as e:
            results.append({
                "scanned": py_file.name,
                "status": "error",
                "error": str(e)
            })

    return results
