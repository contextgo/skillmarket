#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from scripts.taoguba_crawler import TaogubaBlogCrawler

crawler = TaogubaBlogCrawler('5894557')

print("正在获取最新1篇博客...")
blogs = crawler.get_latest_blogs(count=1, include_content=True)

if blogs:
    print(f"成功获取 {len(blogs)} 篇")
    print("\n文章列表：")
    for i, b in enumerate(blogs, 1):
        print(f"{i:>2}. [{b.get('time','')}] {b.get('title','')} | 浏览:{b.get('views','')}")
    
    out = crawler.save_to_file(blogs, 'blog_latest_1.txt')
    print(f"\n已保存到: blog_latest_31.txt")
else:
    print("获取失败")
