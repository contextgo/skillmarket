# -*- coding: utf-8 -*-
import requests
from bs4 import BeautifulSoup
import re

# 读取Cookie
with open('cookies.txt', 'r', encoding='utf-8') as f:
    cookie_str = f.read().strip()

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'zh-CN,zh;q=0.9',
}

session = requests.Session()
session.headers.update(headers)

for item in cookie_str.split(';'):
    item = item.strip()
    if '=' in item:
        name, value = item.split('=', 1)
        session.cookies.set(name.strip(), value.strip(), domain='.tgb.cn')

# 访问博客列表页
resp = session.get('https://www.tgb.cn/user/blog/moreTopic?userID=5894557&pageNo=1', timeout=15)
resp.encoding = 'utf-8'

soup = BeautifulSoup(resp.text, 'html.parser')

# 查找包含今日日期的元素
dates = soup.find_all(string=re.compile(r'2026-04-03'))
print(f'找到包含今日日期的元素: {len(dates)}')

for date in dates:
    # 找到父元素
    parent = date.parent
    # 向上查找包含文章信息的容器
    for _ in range(10):
        if parent:
            # 查找标题链接
            link = parent.find('a', href=True)
            if link and '/a/' in link.get('href', ''):
                title = link.get_text(strip=True)
                href = link.get('href', '')
                print(f'标题: {title}')
                print(f'链接: {href}')
                print(f'时间: {date.strip()}')
                print()
                break
            parent = parent.parent

# 保存页面内容供分析
with open('page_content.html', 'w', encoding='utf-8') as f:
    f.write(resp.text[:50000])
print('页面内容已保存到 page_content.html')
