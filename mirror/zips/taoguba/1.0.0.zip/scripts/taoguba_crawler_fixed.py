# -*- coding: utf-8 -*-
"""
淘股吧博客爬虫 - 修复版
修复了文章内容提取（新版 class: article-content）
"""
import requests
from bs4 import BeautifulSoup
from datetime import datetime
import os
import re
import json
import time

class TaogubaBlogCrawler:
    def __init__(self, user_id, cookie=None, cookie_file=None):
        self.user_id = user_id
        self.base_url = 'https://www.tgb.cn'
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'zh-CN,zh;q=0.9',
            'Referer': f'{self.base_url}/blog/{user_id}',
        }
        self.session = requests.Session()
        self.session.headers.update(self.headers)
        
        self.cookie = cookie
        self.cookie_file = cookie_file or os.path.join(os.path.dirname(os.path.abspath(__file__)), 'cookies.txt')
        self.history_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'crawl_history.json')
        
        self._load_cookie()
    
    def _load_cookie(self):
        if self.cookie:
            self._set_cookie_string(self.cookie)
        elif os.path.exists(self.cookie_file):
            with open(self.cookie_file, 'r', encoding='utf-8') as f:
                cookie_str = f.read().strip()
                if cookie_str:
                    self._set_cookie_string(cookie_str)
    
    def _set_cookie_string(self, cookie_str):
        if '=' in cookie_str:
            for item in cookie_str.split(';'):
                item = item.strip()
                if '=' in item:
                    name, value = item.split('=', 1)
                    self.session.cookies.set(name.strip(), value.strip(), domain='.tgb.cn')
    
    def has_cookie(self):
        return len(self.session.cookies) > 0

    def get_blog_list_page(self, page=1, use_more_topic=False):
        headers = self.headers.copy()
        if use_more_topic:
            url = f'{self.base_url}/user/blog/moreTopic?userID={self.user_id}&pageNo={page}'
            headers['X-Requested-With'] = 'XMLHttpRequest'
        else:
            url = f'{self.base_url}/blog/{self.user_id}'
        
        try:
            response = self.session.get(url, timeout=15, headers=headers)
            response.raise_for_status()
            response.encoding = 'utf-8'
            return response.text
        except Exception as e:
            print(f'访问页面失败: {e}')
            return None

    def parse_blog_list(self, html):
        soup = BeautifulSoup(html, 'html.parser')
        blogs = []
        articles = soup.find_all('div', class_='article_tittle')
        
        if articles:
            for article in articles:
                title_elem = article.find('a', href=True)
                time_elem = article.find('div', class_='tittle_fbshijian')
                
                if title_elem and time_elem:
                    title = title_elem.get('title', title_elem.get_text(strip=True))
                    href = title_elem.get('href', '')
                    create_time = time_elem.get_text(strip=True)
                    views_elem = article.find('div', class_='tittle_llhf')
                    views = views_elem.get_text(strip=True) if views_elem else ''
                    is_jinghua = article.find('span', class_='tittle_jinghua') is not None
                    
                    blogs.append({
                        'title': title,
                        'link': f'{self.base_url}/{href}' if href.startswith('a/') else f'{self.base_url}{href}',
                        'time': create_time,
                        'views': views,
                        'is_jinghua': is_jinghua,
                        'blog_id': href.split('/')[-1] if '/' in href else href,
                    })
        else:
            tds = soup.find_all('td', class_='suh')
            for td in tds:
                tr = td.parent
                if not tr:
                    continue
                title_elem = td.find('a', href=True)
                if not title_elem:
                    continue
                
                title = title_elem.get('title', title_elem.get_text(strip=True))
                href = title_elem.get('href', '')
                all_tds = tr.find_all('td')
                create_time = ''
                views = ''
                if len(all_tds) >= 8:
                    create_time = all_tds[7].get_text(strip=True)
                if len(all_tds) >= 5:
                    views = all_tds[4].get_text(strip=True)
                
                blogs.append({
                    'title': title,
                    'link': f'{self.base_url}/{href}' if href.startswith('a/') else f'{self.base_url}{href}',
                    'time': create_time,
                    'views': views,
                    'is_jinghua': False,
                    'blog_id': href.split('/')[-1] if '/' in href else href,
                })
        
        return blogs

    def get_blog_content(self, blog_url):
        """新版内容提取：支持 article-content class"""
        try:
            response = self.session.get(blog_url, timeout=15)
            response.raise_for_status()
            response.encoding = 'utf-8'
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # 新版淘股吧使用 article-content
            content_elem = soup.find('div', class_='article-content')
            
            if content_elem:
                # 移除元信息元素
                for elem in content_elem.find_all(['div', 'span'], class_=['article-tittle', 'article-data', 'article-biaoqian']):
                    elem.decompose()
                
                content = content_elem.get_text(separator='\n', strip=True)
                content = re.sub(r'\n{3,}', '\n\n', content)
                return content.strip()
            
            # 备用旧版选择器
            content_elem = soup.find('div', class_='blog_content') or \
                          soup.find('div', class_='content')
            if content_elem:
                return content_elem.get_text(separator='\n', strip=True)
            
            return '无法获取内容'
        except Exception as e:
            return f'获取失败: {e}'

    def get_today_blogs(self, include_content=True):
        """获取今日博客（支持相对时间：分钟前、小时前等）"""
        today = datetime.now().strftime('%Y-%m-%d')
        
        html = self.get_blog_list_page(page=1, use_more_topic=True)
        if not html:
            return []
        
        blogs = self.parse_blog_list(html)
        
        # 过滤今日博客
        today_blogs = []
        for blog in blogs:
            t = blog['time']
            if today in t:
                today_blogs.append(blog)
        
        if include_content:
            for blog in today_blogs:
                content = self.get_blog_content(blog['link'])
                blog['content'] = content
                time.sleep(0.3)
        
        return today_blogs

    def save_to_file(self, blogs, filepath):
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(f'淘股吧博客订阅 - {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}\n')
            f.write(f'用户ID: {self.user_id}\n')
            f.write('=' * 60 + '\n\n')
            
            for blog in blogs:
                jinghua = '[精华] ' if blog.get('is_jinghua') else ''
                f.write(f'{jinghua}标题: {blog["title"]}\n')
                f.write(f'时间: {blog["time"]}\n')
                f.write(f'链接: {blog["link"]}\n')
                f.write('-' * 40 + '\n')
                f.write(blog.get('content', '无内容'))
                f.write('\n' + '=' * 60 + '\n\n')
        
        return filepath


def fetch_today_blog():
    """获取今日博客"""
    crawler = TaogubaBlogCrawler('5894557')
    today_blogs = crawler.get_today_blogs(include_content=True)
    
    if today_blogs:
        today = datetime.now().strftime('%Y-%m-%d')
        filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), f'blog_{today}.txt')
        crawler.save_to_file(today_blogs, filepath)
        return today_blogs, str(filepath)
    else:
        return [], None


if __name__ == '__main__':
    blogs, fp = fetch_today_blog()
    if blogs:
        print(f'成功获取 {len(blogs)} 篇博客')
    else:
        print('今日暂无更新')
