# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding='utf-8')
sys.path.insert(0, '.')

from taoguba_crawler import TaogubaBlogCrawler

crawler = TaogubaBlogCrawler('5894557')

print('=== 获取今日博客 ===')
blogs = crawler.get_today_blogs(include_content=True)
print(f'今日博客: {len(blogs)} 篇')
print()

for i, b in enumerate(blogs):
    print(f'=== [{i+1}] {b.get("title", "?")} ===')
    print(f'时间: {b.get("time", "?")}')
    print(f'链接: {b.get("link", "?")}')
    print(f'浏览: {b.get("views", "?")}')
    content = b.get('content', '')
    if content:
        print(f'内容: {content[:800]}')
    print()
    print('-' * 60)
    print()

# 保存到文件
crawler.save_to_file(blogs, 'blog_today_0331.txt')
print(f'保存成功: {len(blogs)} 篇')
