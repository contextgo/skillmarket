import requests
from bs4 import BeautifulSoup
from datetime import datetime, timedelta
import os
import re
import json
import time

class TaogubaBlogCrawler:
    def __init__(self, user_id, cookie=None, cookie_file=None):
        self.user_id = user_id
        self.base_url = 'https://www.tgb.cn'
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
            'Referer': f'{self.base_url}/blog/{user_id}',
        }
        self.session = requests.Session()
        self.session.headers.update(self.headers)
        
        self.cookie = cookie
        self.cookie_file = cookie_file or os.path.join(os.path.dirname(os.path.abspath(__file__)), 'cookies.txt')
        self.history_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'crawl_history.json')
        
        self._load_cookie()
    
    def _load_cookie(self):
        if self.cookie:
            self._set_cookie_string(self.cookie)
        elif os.path.exists(self.cookie_file):
            with open(self.cookie_file, 'r', encoding='utf-8') as f:
                cookie_str = f.read().strip()
                if cookie_str:
                    self._set_cookie_string(cookie_str)
                    print('已加载 Cookie 文件')
    
    def _set_cookie_string(self, cookie_str):
        if '=' in cookie_str:
            for item in cookie_str.split(';'):
                item = item.strip()
                if '=' in item:
                    name, value = item.split('=', 1)
                    self.session.cookies.set(name.strip(), value.strip(), domain='.tgb.cn')
    
    def set_cookie_from_browser(self, cookie_str):
        self._set_cookie_string(cookie_str)
        with open(self.cookie_file, 'w', encoding='utf-8') as f:
            f.write(cookie_str)
        print('Cookie 已保存到文件')
    
    def has_cookie(self):
        return len(self.session.cookies) > 0

    def get_blog_list_page(self, page=1, use_more_topic=False):
        headers = self.headers.copy()
        
        if use_more_topic:
            url = f'{self.base_url}/user/blog/moreTopic?userID={self.user_id}&pageNo={page}'
            headers['X-Requested-With'] = 'XMLHttpRequest'
        else:
            url = f'{self.base_url}/blog/{self.user_id}'
        
        print(f'正在访问: {url}')
        try:
            response = self.session.get(url, timeout=15, headers=headers)
            response.raise_for_status()
            response.encoding = 'utf-8'
            return response.text
        except Exception as e:
            print(f'访问页面失败: {e}')
            return None

    def parse_blog_list(self, html):
        soup = BeautifulSoup(html, 'html.parser')
        blogs = []
        
        articles = soup.find_all('div', class_='article_tittle')
        
        if articles:
            for article in articles:
                title_elem = article.find('a', href=True)
                time_elem = article.find('div', class_='tittle_fbshijian')
                
                if title_elem and time_elem:
                    title = title_elem.get('title', title_elem.get_text(strip=True))
                    href = title_elem.get('href', '')
                    create_time = time_elem.get_text(strip=True)
                    
                    views_elem = article.find('div', class_='tittle_llhf')
                    views = views_elem.get_text(strip=True) if views_elem else ''
                    
                    is_jinghua = article.find('span', class_='tittle_jinghua') is not None
                    
                    blogs.append({
                        'title': title,
                        'link': f'{self.base_url}/{href}' if href.startswith('a/') else f'{self.base_url}{href}',
                        'time': create_time,
                        'views': views,
                        'is_jinghua': is_jinghua,
                        'blog_id': href.split('/')[-1] if '/' in href else href,
                    })
        else:
            tds = soup.find_all('td', class_='suh')
            for td in tds:
                tr = td.parent
                if not tr:
                    continue
                
                title_elem = td.find('a', href=True)
                if not title_elem:
                    continue
                
                title = title_elem.get('title', title_elem.get_text(strip=True))
                href = title_elem.get('href', '')
                
                all_tds = tr.find_all('td')
                create_time = ''
                views = ''
                
                if len(all_tds) >= 5:
                    views = all_tds[4].get_text(strip=True)
                if len(all_tds) >= 8:
                    create_time = all_tds[7].get_text(strip=True)
                
                blogs.append({
                    'title': title,
                    'link': f'{self.base_url}/{href}' if href.startswith('a/') else f'{self.base_url}{href}',
                    'time': create_time,
                    'views': views,
                    'is_jinghua': False,
                    'blog_id': href.split('/')[-1] if '/' in href else href,
                })
        
        return blogs
    
    def _parse_date(self, time_str):
        try:
            if '分钟前' in time_str:
                minutes = int(re.search(r'(\d+)', time_str).group(1))
                return datetime.now() - timedelta(minutes=minutes)
            elif '小时前' in time_str:
                hours = int(re.search(r'(\d+)', time_str).group(1))
                return datetime.now() - timedelta(hours=hours)
            elif '昨天' in time_str:
                return datetime.now() - timedelta(days=1)
            elif '前天' in time_str:
                return datetime.now() - timedelta(days=2)
            else:
                match = re.search(r'(\d{4})-(\d{2})-(\d{2})', time_str)
                if match:
                    return datetime(int(match.group(1)), int(match.group(2)), int(match.group(3)))
                match = re.search(r'(\d{2})-(\d{2})', time_str)
                if match:
                    year = datetime.now().year
                    return datetime(year, int(match.group(1)), int(match.group(2)))
        except:
            pass
        return None

    def get_blog_content(self, blog_url):
        print(f'  获取文章内容: {blog_url}')
        try:
            response = self.session.get(blog_url, timeout=15)
            response.raise_for_status()
            response.encoding = 'utf-8'
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            content_elem = soup.find('div', class_='blog_content') or \
                          soup.find('div', class_='article-content') or \
                          soup.find('div', id='blog_content') or \
                          soup.find('div', class_='content')
            
            if content_elem:
                content = content_elem.get_text(separator='\n', strip=True)
                content = re.sub(r'\n{3,}', '\n\n', content)
                return content
            
            return '无法获取内容'
        except Exception as e:
            print(f'  获取内容失败: {e}')
            return f'获取失败: {e}'

    def load_history(self):
        if os.path.exists(self.history_file):
            with open(self.history_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {'crawled_ids': [], 'last_crawl_time': ''}

    def save_history(self, history):
        with open(self.history_file, 'w', encoding='utf-8') as f:
            json.dump(history, f, ensure_ascii=False, indent=2)

    def get_blogs_by_days(self, days=7, include_content=True):
        print(f'正在获取最近 {days} 天的博客...')
        
        if not self.has_cookie():
            print('警告: 未设置 Cookie，可能无法获取完整历史数据')
            print('提示: 使用 set_cookie_from_browser() 方法设置 Cookie')
        
        all_blogs = []
        target_date = datetime.now() - timedelta(days=days)
        page = 1
        max_pages = 50
        
        while page <= max_pages:
            html = self.get_blog_list_page(page, use_more_topic=True)
            if not html:
                print(f'第 {page} 页获取失败，停止翻页')
                break
            
            blogs = self.parse_blog_list(html)
            if not blogs:
                print(f'第 {page} 页无数据，停止翻页')
                break
            
            print(f'第 {page} 页找到 {len(blogs)} 篇博客')
            
            stop_paging = False
            for blog in blogs:
                blog_date = self._parse_date(blog['time'])
                
                if blog_date and blog_date < target_date:
                    print(f'已到达目标日期范围，停止翻页')
                    stop_paging = True
                    break
                
                all_blogs.append(blog)
            
            if stop_paging:
                break
            
            page += 1
            time.sleep(0.5)
        
        seen_ids = set()
        unique_blogs = []
        for blog in all_blogs:
            if blog['blog_id'] not in seen_ids:
                seen_ids.add(blog['blog_id'])
                unique_blogs.append(blog)
        
        print(f'共找到 {len(unique_blogs)} 篇博客')
        
        if include_content:
            for i, blog in enumerate(unique_blogs):
                print(f'获取内容 ({i+1}/{len(unique_blogs)}): {blog["title"]}')
                content = self.get_blog_content(blog['link'])
                blog['content'] = content
                time.sleep(0.3)
        
        return unique_blogs

    def get_new_blogs(self, include_content=True):
        print(f'正在检查新博客...')
        
        html = self.get_blog_list_page()
        if not html:
            return []
        
        blogs = self.parse_blog_list(html)
        print(f'共找到 {len(blogs)} 篇博客')
        
        history = self.load_history()
        crawled_ids = set(history.get('crawled_ids', []))
        
        new_blogs = []
        for blog in blogs:
            if blog['blog_id'] not in crawled_ids:
                print(f"发现新博客: {blog['title']}")
                
                if include_content:
                    content = self.get_blog_content(blog['link'])
                    blog['content'] = content
                
                new_blogs.append(blog)
                crawled_ids.add(blog['blog_id'])
        
        history['crawled_ids'] = list(crawled_ids)[-100:]
        history['last_crawl_time'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        self.save_history(history)
        
        return new_blogs

    def get_today_blogs(self, include_content=True):
        today = datetime.now().strftime('%Y-%m-%d')
        print(f'正在获取 {today} 的博客内容...')
        
        html = self.get_blog_list_page()
        if not html:
            return []
        
        blogs = self.parse_blog_list(html)
        print(f'共找到 {len(blogs)} 篇博客')
        
        today_blogs = []
        for blog in blogs:
            if today in blog['time']:
                print(f"找到今日博客: {blog['title']}")
                
                if include_content:
                    content = self.get_blog_content(blog['link'])
                    blog['content'] = content
                
                today_blogs.append(blog)
        
        return today_blogs

    def get_latest_blogs(self, count=5, include_content=True):
        print(f'正在获取最新 {count} 篇博客...')
        
        html = self.get_blog_list_page()
        if not html:
            return []
        
        blogs = self.parse_blog_list(html)
        print(f'共找到 {len(blogs)} 篇博客')
        
        latest_blogs = blogs[:count]
        
        if include_content:
            for blog in latest_blogs:
                print(f"获取: {blog['title']}")
                content = self.get_blog_content(blog['link'])
                blog['content'] = content
        
        return latest_blogs

    def save_to_file(self, blogs, filename=None):
        if not filename:
            today = datetime.now().strftime('%Y-%m-%d')
            filename = f'blog_{today}.txt'
        
        filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), filename)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(f'淘股吧博客订阅 - {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}\n')
            f.write(f'用户ID: {self.user_id}\n')
            f.write('=' * 60 + '\n\n')
            
            for blog in blogs:
                jinghua = '[精华] ' if blog.get('is_jinghua') else ''
                f.write(f'{jinghua}标题: {blog["title"]}\n')
                f.write(f'时间: {blog["time"]}\n')
                f.write(f'浏览: {blog.get("views", "N/A")}\n')
                f.write(f'链接: {blog["link"]}\n')
                f.write('-' * 40 + '\n')
                f.write(blog.get('content', '无内容'))
                f.write('\n' + '=' * 60 + '\n\n')
        
        print(f'已保存到: {filepath}')
        return filepath


def print_cookie_help():
    print('''
========================================
如何获取淘股吧 Cookie
========================================

方法一：Chrome/Edge 浏览器
1. 登录 https://www.tgb.cn
2. 按 F12 打开开发者工具
3. 切换到 "Network" 标签
4. 刷新页面
5. 点击任意请求
6. 在 Headers 中找到 Cookie 字段
7. 复制整个 Cookie 值

方法二：使用 EditThisCookie 扩展
1. 安装 EditThisCookie 浏览器扩展
2. 登录淘股吧
3. 点击扩展图标
4. 点击 "Export" 导出 Cookie

========================================
''')

def main():
    user_id = '5894557'
    crawler = TaogubaBlogCrawler(user_id)
    
    print('=' * 50)
    print('淘股吧博客订阅工具')
    print('=' * 50)
    print('1. 获取今日博客')
    print('2. 获取最新博客')
    print('3. 检查新博客(增量订阅)')
    print('4. 获取最近N天博客 (需要Cookie)')
    print('5. 设置Cookie')
    print('6. Cookie获取帮助')
    print('=' * 50)
    
    choice = input('请选择 (1-6): ').strip()
    
    if choice == '1':
        blogs = crawler.get_today_blogs(include_content=True)
        if blogs:
            crawler.save_to_file(blogs)
        else:
            print('今日暂无更新')
    
    elif choice == '2':
        count = input('获取数量 (默认5): ').strip()
        count = int(count) if count.isdigit() else 5
        blogs = crawler.get_latest_blogs(count=count, include_content=True)
        if blogs:
            crawler.save_to_file(blogs, 'blog_latest.txt')
    
    elif choice == '3':
        blogs = crawler.get_new_blogs(include_content=True)
        if blogs:
            print(f'\n发现 {len(blogs)} 篇新博客')
            crawler.save_to_file(blogs, 'blog_new.txt')
        else:
            print('暂无新博客')
    
    elif choice == '4':
        if not crawler.has_cookie():
            print('警告: 未设置 Cookie，可能无法获取完整数据')
            proceed = input('是否继续? (y/n): ').strip().lower()
            if proceed != 'y':
                return
        days = input('获取最近多少天? (默认7): ').strip()
        days = int(days) if days.isdigit() else 7
        blogs = crawler.get_blogs_by_days(days=days, include_content=True)
        if blogs:
            crawler.save_to_file(blogs, f'blog_{days}days.txt')
    
    elif choice == '5':
        print('请粘贴 Cookie (从浏览器复制):')
        cookie = input().strip()
        if cookie:
            crawler.set_cookie_from_browser(cookie)
            print('Cookie 设置成功!')
        else:
            print('Cookie 不能为空')
    
    elif choice == '6':
        print_cookie_help()
    
    else:
        print('无效选择')

def test_get_by_days():
    user_id = '5894557'
    crawler = TaogubaBlogCrawler(user_id)
    
    print('=' * 50)
    print('测试: 获取最近3天博客')
    print('=' * 50)
    
    if not crawler.has_cookie():
        print('提示: 未设置 Cookie，尝试无认证访问...')
    
    blogs = crawler.get_blogs_by_days(days=3, include_content=False)
    
    if blogs:
        print(f'\n找到 {len(blogs)} 篇博客')
        for blog in blogs[:5]:
            print(f"\n标题: {blog['title']}")
            print(f"时间: {blog['time']}")
            print(f"链接: {blog['link']}")
        if len(blogs) > 5:
            print(f"\n... 还有 {len(blogs) - 5} 篇博客")
    else:
        print('\n未找到博客')

if __name__ == '__main__':
    main()
