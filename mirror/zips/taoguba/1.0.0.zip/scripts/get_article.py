# -*- coding: utf-8 -*-
import requests
from bs4 import BeautifulSoup
import re

# 读取Cookie
with open('cookies.txt', 'r', encoding='utf-8') as f:
    cookie_str = f.read().strip()

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'zh-CN,zh;q=0.9',
    'Referer': 'https://www.tgb.cn/blog/5894557',
}

session = requests.Session()
session.headers.update(headers)

for item in cookie_str.split(';'):
    item = item.strip()
    if '=' in item:
        name, value = item.split('=', 1)
        session.cookies.set(name.strip(), value.strip(), domain='.tgb.cn')

# 获取文章内容
article_url = 'https://www.tgb.cn/a/2qH8iXDwCwz'
print(f'正在获取文章: {article_url}')

resp = session.get(article_url, timeout=15)
resp.encoding = 'utf-8'

print(f'状态码: {resp.status_code}')
print(f'页面长度: {len(resp.text)}')

soup = BeautifulSoup(resp.text, 'html.parser')

# 尝试多种选择器
content_elem = soup.find('div', class_='article-content')
if not content_elem:
    content_elem = soup.find('div', class_='blog_content')
if not content_elem:
    content_elem = soup.find('div', class_='content')

if content_elem:
    content = content_elem.get_text(separator='\n', strip=True)
    print(f'内容长度: {len(content)}')
    print('文章内容:')
    print('=' * 60)
    print(content[:5000])
else:
    # 保存页面供分析
    with open('article_page.html', 'w', encoding='utf-8') as f:
        f.write(resp.text)
    print('未找到内容元素，页面已保存到 article_page.html')

    # 检查是否有403错误页面
    if '403' in resp.text[:1000]:
        print('页面可能返回了403错误')
