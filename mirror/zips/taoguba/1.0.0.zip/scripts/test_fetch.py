# -*- coding: utf-8 -*-
import requests
from bs4 import BeautifulSoup
import re
import json

# 读取Cookie
with open('cookies.txt', 'r', encoding='utf-8') as f:
    cookie_str = f.read().strip()

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'zh-CN,zh;q=0.9',
}

session = requests.Session()
session.headers.update(headers)

for item in cookie_str.split(';'):
    item = item.strip()
    if '=' in item:
        name, value = item.split('=', 1)
        session.cookies.set(name.strip(), value.strip(), domain='.tgb.cn')

# 访问博客列表页
resp = session.get('https://www.tgb.cn/user/blog/moreTopic?userID=5894557&pageNo=1', timeout=15)
resp.encoding = 'utf-8'

# 检查是否有JSON数据
try:
    data = json.loads(resp.text)
    print('返回的是JSON数据')
    print(json.dumps(data, ensure_ascii=False, indent=2)[:2000])
except:
    # 检查HTML结构
    soup = BeautifulSoup(resp.text, 'html.parser')
    # 查找所有包含日期的元素
    dates = soup.find_all(string=re.compile(r'2026-04-03'))
    print(f'找到包含今日日期的元素: {len(dates)}')
    
    # 查找文章链接
    links = soup.find_all('a', href=re.compile(r'/a/'))
    print(f'找到文章链接数: {len(links)}')
    for link in links[:5]:
        text = link.get_text(strip=True)[:50]
        href = link.get('href', '')
        print(f'  - {text} | {href}')
