# -*- coding: utf-8 -*-
"""获取今日博客"""
import sys
sys.path.insert(0, '.')
from taoguba_crawler import TaogubaBlogCrawler
from datetime import datetime
import os

user_id = sys.argv[1] if len(sys.argv) > 1 else '5894557'

crawler = TaogubaBlogCrawler(user_id)
print(f'Cookie数量: {len(crawler.session.cookies)}')

# 获取今日博客
today_blogs = crawler.get_today_blogs(include_content=True)

if today_blogs:
    today = datetime.now().strftime('%Y-%m-%d')
    filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), f'blog_{today}.txt')
    crawler.save_to_file(today_blogs, filepath)
    print(f'成功获取 {len(today_blogs)} 篇博客')
    print(f'保存到: {filepath}')
else:
    print('今日暂无更新')
