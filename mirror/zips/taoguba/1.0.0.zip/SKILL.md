---
name: "taoguba-crawler"
description: "爬取淘股吧博客文章获取股市见解。当用户想要订阅或获取 taoguba.cn 的博客内容时调用。"
---

# 淘股吧博客爬虫

本技能用于爬取和获取淘股吧（taoguba.cn）的博客文章，淘股吧是中国知名的股市社区。

## 功能特点

- 获取特定用户的今日博客文章
- 获取最新 N 篇博客文章的完整内容
- 增量订阅（仅获取新文章）
- **按天数获取历史博客（需要 Cookie）**
- **Cookie 认证支持**
- 将内容保存到本地文件

## 使用方法

### 基本使用（无需登录）

```python
from scripts.taoguba_crawler import TaogubaBlogCrawler

# 初始化爬虫（使用用户ID）
crawler = TaogubaBlogCrawler('5894557')

# 获取今日博客
blogs = crawler.get_today_blogs(include_content=True)

# 获取最新5篇博客
blogs = crawler.get_latest_blogs(count=5, include_content=True)

# 检查新博客（增量订阅）
blogs = crawler.get_new_blogs(include_content=True)

# 保存到文件
crawler.save_to_file(blogs, 'output.txt')
```

### 使用 Cookie 获取历史数据

```python
from scripts.taoguba_crawler import TaogubaBlogCrawler

# 方式1：初始化时传入 Cookie
crawler = TaogubaBlogCrawler('5894557', cookie='your_cookie_string')

# 方式2：运行时设置 Cookie
crawler = TaogubaBlogCrawler('5894557')
crawler.set_cookie_from_browser('your_cookie_string')

# 获取最近7天的博客
blogs = crawler.get_blogs_by_days(days=7, include_content=True)

# 保存到文件
crawler.save_to_file(blogs, 'blog_7days.txt')
```

### 直接运行

```bash
python scripts/taoguba_crawler.py
```

运行后显示菜单：
1. 获取今日博客
2. 获取最新博客
3. 检查新博客(增量订阅)
4. 获取最近N天博客 (需要Cookie)
5. 设置Cookie
6. Cookie获取帮助

## Cookie 获取方法

### 方法一：Chrome/Edge 浏览器
1. 登录 https://www.tgb.cn
2. 按 F12 打开开发者工具
3. 切换到 "Network" 标签
4. 刷新页面
5. 点击任意请求
6. 在 Headers 中找到 Cookie 字段
7. 复制整个 Cookie 值

### 方法二：使用 EditThisCookie 扩展
1. 安装 EditThisCookie 浏览器扩展
2. 登录淘股吧
3. 点击扩展图标
4. 点击 "Export" 导出 Cookie

## 输出文件

- `blog_YYYY-MM-DD.txt` - 今日博客
- `blog_latest.txt` - 最新博客
- `blog_new.txt` - 新博客（增量）
- `blog_Ndays.txt` - 最近N天博客
- `cookies.txt` - Cookie 缓存文件
- `crawl_history.json` - 爬取历史记录

## 配置说明

编辑脚本中的 `user_id` 以订阅不同的博主：

```python
user_id = '5894557'  # 淘股吧博主ID
```

## 依赖包

```bash
pip install requests beautifulsoup4
```

## 博客文章结构

每篇博客文章包含：
- `title` - 文章标题
- `time` - 发布时间
- `link` - 原文链接
- `views` - 浏览/回复数
- `is_jinghua` - 是否为精华帖
- `content` - 完整正文内容

## API 说明

### TaogubaBlogCrawler 类

| 方法 | 参数 | 说明 |
|------|------|------|
| `__init__` | user_id, cookie=None, cookie_file=None | 初始化爬虫 |
| `set_cookie_from_browser` | cookie_str | 设置并保存 Cookie |
| `has_cookie` | - | 检查是否已设置 Cookie |
| `get_today_blogs` | include_content=True | 获取今日博客 |
| `get_latest_blogs` | count=5, include_content=True | 获取最新N篇 |
| `get_new_blogs` | include_content=True | 增量获取新博客 |
| `get_blogs_by_days` | days=7, include_content=True | 获取最近N天博客 |
| `save_to_file` | blogs, filename=None | 保存到文件 |
