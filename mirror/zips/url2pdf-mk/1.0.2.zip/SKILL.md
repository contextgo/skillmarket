---
name: url2pdf-mk
description: |
  微信文章 / 网页抓取工具，将任意 URL 输出为含完整图片的 PDF 和 Markdown 文件。
  自动在桌面按当前日期创建目录，文件名使用文章发布日期 + 标题。
  当用户提到"网页转 PDF"、"保存微信文章"、"抓取网页内容"、"导出 PDF 和 Markdown"、
  "url2pdf"、"网页保存"、"url2pdf-mk"、"保存链接"、"离线阅读"、"网页存档"、"批量抓取"等时触发此技能。
---

# url2pdf-mk — 网页内容抓取：PDF + Markdown

> 将任意网页（尤其是微信文章）一键转换为可离线阅读的 PDF 和 Markdown 文档。
> 完整保留排版、图片、样式，无需手动复制粘贴。支持单篇抓取和批量抓取。
> **智能路由：自动根据 URL 数量选择最优处理方式。**

---

## 🚀 统一入口：`main.py`（推荐）

> **自动判断 URL 数量，选择最优处理方式。**
> URL=1 → 单篇抓取（完整 PDF+Markdown）
> URL≥2 → 批量抓取（批量 PDF+Markdown）

### 用法

```bash
# 单篇（1个URL → scrape.py 完整模式）
python3 scripts/main.py "https://mp.weixin.qq.com/s?__biz=..."

# 多篇（2个以上URL → 批量模式，自动生成临时xlsx）
python3 scripts/main.py "https://mp.weixin.qq.com/s?url1" "https://mp.weixin.qq.com/s?url2"

# xlsx批量（自动检测URL数量，1个降级为单篇，≥2个走批量）
python3 scripts/main.py "/path/to/过滤后内容.xlsx"
```

### 智能路由规则

| 场景 | 检测方式 | 处理脚本 | 说明 |
|------|---------|---------|------|
| 1 个 URL（命令行） | 参数解析 | `scrape.py` | 单篇完整模式，PDF+Markdown |
| 2+ 个 URL（命令行） | 参数解析 | `batch_scrape.py` / `batch_http.py` | 批量模式，Chrome可用→浏览器版，否则→HTTP版 |
| 1 个 URL（xlsx） | 读取xlsx计数 | `scrape.py` | **降级**为单篇模式 |
| 2+ 个 URL（xlsx） | 读取xlsx计数 | `batch_scrape.py` / `batch_http.py` | 批量模式 |
| xlsx 未找到URL | xlsx读取 | 报错退出 | - |

---

## 功能概览

| 脚本 | 说明 |
|------|------|
| `main.py` | **统一入口**：智能路由，自动选最优处理方式 |
| `scrape.py` | 单篇抓取：输入一个 URL，输出 PDF + Markdown |
| `batch_scrape.py` | 批量抓取（浏览器）：读取 xlsx，PDF + Markdown 全量生成 |
| `batch_http.py` | 批量抓取（纯 HTTP）：无需浏览器，快速存档 Markdown，PDF 需手动打印 |

| 功能 | 说明 |
|------|------|
| **PDF 生成** | Chrome 浏览器原生打印，完整保留正文图片、排版样式、背景色 |
| **Markdown 生成** | 按网页 DOM 顺序输出，图片穿插在对应正文中，与阅读顺序一致 |
| **懒加载处理** | 逐段滚动触发懒加载，轮询等待所有图片加载完成后再打印 |
| **微信特殊支持** | 自动解析 `ct` 时间戳还原发布日期，支持 `data-src` 懒加载图片 |
| **跨平台** | 支持 macOS / Windows / Linux，自动适配各平台中文字体 |
| **批量模式** | 读取 xlsx 文件批量处理，适合知识库内容批量归档 |
| **浏览器管理** | 任务完成后只关闭标签页，浏览器保持运行，授权状态复用 |

---

## 适用场景

| 场景 | 推荐脚本 |
|------|---------|
| 保存单篇微信文章 | `scrape.py` |
| 批量存档（需完整 PDF + Markdown） | `batch_scrape.py` |
| 快速批量离线存档（文字为主） | `batch_http.py` |
| 知识库内容批量导入 | `batch_scrape.py`（Markdown 格式） |
| 备份公众号文章（防止被删） | `batch_scrape.py` |

---

## 单篇抓取：`scrape.py`

### 用法

```bash
python3 ~/.qclaw/skills/url2pdf-mk/scripts/scrape.py <URL>
```

### 示例

```bash
python3 ~/.qclaw/skills/url2pdf-mk/scripts/scrape.py \
  "http://mp.weixin.qq.com/s?__biz=MzA5NjM4NTUzNQ==&mid=2651220972&idx=1&sn=..."
```

### 输出

```
~/Desktop/{当前日期}/
├── 2025-04-03_颠覆认知！女性"私处"并不是越紧越好！.md   ← Markdown
└── 2025-04-03_颠覆认知！女性"私处"并不是越紧越好！.pdf   ← PDF（含图）
```

---

## 批量抓取（浏览器版）：`batch_scrape.py`

> 使用 Chrome CDP 自动化，需浏览器授权。PDF + Markdown 全量生成，适合正式存档。

### xlsx 文件格式要求

| 列 | 内容 | 示例 |
|----|------|------|
| col[1]（B） | 文章标题 | 女性"私处"并不是越紧越好！ |
| col[2]（C） | 发布日期 | 20250403 或 2025-04-03 |
| col[5]（F） | 文章 URL | http://mp.weixin.qq.com/s?... |

> 列索引从 1 开始计数，B=第2列，F=第6列（跳过 logo、摘要等列）。

### 用法

```bash
python3 ~/.qclaw/skills/url2pdf-mk/scripts/batch_scrape.py [xlsx路径]
# 默认 xlsx: /Users/qkz/Desktop/知识库/过滤后内容.xlsx
# 默认输出: ~/Desktop/{当前日期}/
```

### 示例

```bash
python3 ~/.qclaw/skills/url2pdf-mk/scripts/batch_scrape.py \
  "/Users/qkz/Desktop/知识库/过滤后内容.xlsx"
```

---

## 批量抓取（纯 HTTP 版）：`batch_http.py`

> 无需浏览器，纯 HTTP 请求，适合快速批量离线 Markdown 存档。部分有反爬的公众号可能失败。

### 用法

```bash
python3 ~/.qclaw/skills/url2pdf-mk/scripts/batch_http.py [xlsx路径]
```

### 输出

仅生成 Markdown 文件；PDF 需手动用 Chrome 打开 Markdown 中的原文链接打印，或改用 `batch_scrape.py`。

---

## 工作流程

### 单篇（scrape.py）

```
启动 Chrome（CDP Proxy）→ 等待页面加载 → 整页滚动 + 逐段小步滚动 → 等待图片加载 → JS DOM Walk 提取内容 → Markdown + PDF 生成 → 关闭标签页（浏览器保持）
```

### 批量浏览器版（batch_scrape.py）

```
启动浏览器（仅一次授权）→ 逐篇：创建标签页 → 滚动加载 → 提取内容 → 保存 MD + PDF → 关闭标签页（浏览器保持运行）
```

> **授权只需一次**：浏览器启动时授权后，整个批量过程（无论多少个 URL）都复用同一连接，无需重复弹窗确认。

### 批量 HTTP 版（batch_http.py）

```
读取 xlsx → 逐篇：HTTP 请求 → HTML 解析 → 保存 Markdown → 礼貌间隔 1s
```

---

## 所需环境

| 组件 | 要求 |
|------|------|
| **Chrome / Chromium** | 必须安装（批量浏览器版需要）<br>macOS: `/Applications/Google Chrome.app`<br>Windows: `C:\Program Files\Google\Chrome\Application\chrome.exe` |
| **Python 3** | 3.7+ |
| **pip3** | 自动安装：`websockets`、`openpyxl`、`requests`（按需安装） |

### Windows 特别说明

| 项目 | 说明 |
|------|------|
| **Chrome 路径** | 自动检测 `C:\Program Files\Google\Chrome\Application\chrome.exe` |
| **QClaw 技能路径** | 自动适配 `C:\Program Files\QClaw\resources\openclaw\config\skills\browser-cdp` |
| **授权复用** | 首次授权后，Windows 上 CDP Proxy daemon 线程状态文件残留问题已修复，后续脚本自动复用授权，无需重复弹窗 |
| **批量多 URL** | 全程只启动一次浏览器，多个 URL 只创建/关闭标签页，授权只需一次 |

### 网络要求

| 地址 | 用途 |
|------|------|
| `pypi.tuna.tsinghua.edu.cn` | 安装 Python 依赖（镜像加速） |
| 目标网页 URL | 抓取内容 |

### 权限要求

- **浏览器**：首次需开启 Chrome 远程调试并授权（120 秒内完成），**批量模式下授权后所有 URL 自动复用，无需重复授权**
- **文件写入**：`~/Desktop/` 目录写权限

---

## 降级策略

| 场景 | 处理 |
|------|------|
| Chrome 未安装 | 降级为纯 HTTP 版（`batch_http.py`） |
| pip 网络超时 | 自动切换清华镜像 |
| PDF 打印超时 | 回退到 reportlab 文本模式（跨平台字体自动适配） |
| 图片懒加载超时 | 等待最多 40s 后继续（正文不受影响） |
| HTTP 请求被拦截 | 改用 `batch_scrape.py`（浏览器版） |

---

## 跨平台字体

| 系统 | PDF 中文字体 |
|------|------------|
| macOS | STHeiti Light / Medium |
| Windows | 微软雅黑（msyh.ttc）、黑体（simhei.ttf） |
| Linux | NotoSansCJK |

---

## 已知限制

| 限制 | 说明 |
|------|------|
| 视频/音频内容 | PDF 保留封面截图；Markdown 保留原文链接 |
| 微信内嵌小程序/互动组件 | 仅提取可渲染的静态内容 |
| 反爬限制（batch_http） | 部分公众号有反爬，改用 batch_scrape.py |
| 登录验证 | 确保 Chrome 已登录目标公众号（浏览器版） |

---

## 安全审查

```
═══════════════════════════════════════════════════════════════
SKILL VETTING REPORT — url2pdf-mk v1.1.0
═══════════════════════════════════════════════════════════════
Skill:    url2pdf-mk
Source:   User-created（OpenClaw 本地）
Author:   qkz
Version:  1.1.0（新增 batch_scrape.py / batch_http.py）
───────────────────────────────────────────────────────────────
RED FLAGS: None

检查明细：
  ✅ 无外部未知 URL 请求
  ✅ 无凭证 / 密钥 / Token 读取
  ✅ 无 ~/.ssh / ~/.aws / ~/.config 访问
  ✅ 无读取 MEMORY / USER / SOUL / IDENTITY
  ✅ 无动态代码执行（eval/exec 仅用于 JS DOM walk，属正常浏览器自动化）
  ✅ 文件写入限于 ~/Desktop/YYYY-MM-DD/
  ✅ pip 安装：websockets / reportlab / openpyxl / requests
  ✅ 网络：PyPI 镜像 + 目标 URL
  ✅ 无恶意混淆 / 压缩代码
  ✅ 无 sudo / root 请求
  ✅ 浏览器通过 Chrome CDP API，不直接访问用户 cookie
───────────────────────────────────────────────────────────────
风险等级：🟡 MEDIUM（浏览器自动化 + 桌面文件写入）
可发布性：✅ SAFE TO INSTALL & SHARE
═══════════════════════════════════════════════════════════════
```

---

## 更新日志

### v1.1.0（2026-04-12）

- **新增** `batch_scrape.py`：xlsx 批量浏览器版，支持完整 PDF + Markdown
- **新增** `batch_http.py`：xlsx 批量纯 HTTP 版，无需浏览器
- **修复** `scrape.py`：`wait_for_load(timeout=20000)` 超时单位错误（应为秒）
- **修复** `scrape.py`：图片 URL 优先取 `data-src` 再取 `src`（微信懒加载）
- **修复** `batch_scrape.py`：API 调用错误（`client.execute`/`actions.wait` 不存在）
- **修复** `batch_scrape.py`：`launcher.launch(headless=False)` 参数不存在
- **修复** `batch_http.py`：重复 `if __name__` 块导致后半代码永不执行
