# -*- coding: utf-8 -*-
import sys, io, platform
if platform.system() == 'Windows':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

"""
url2pdf-mk 统一入口：智能路由
  • 1 个 URL  → 单篇抓取（scrape.py），PDF + Markdown 完整保留
  • ≥2 个 URL 或 xlsx → 批量抓取（batch_scrape.py），PDF + Markdown 全量生成

用法：
  python3 scripts/main.py <URL>                                    # 单篇
  python3 scripts/main.py <URL1> <URL2> <URL3> ...                 # 多篇
  python3 scripts/main.py /path/to/list.xlsx                       # xlsx 批量

作者：qkz | 2026-04-13
"""
import sys, os, re, subprocess, platform, tempfile, openpyxl

SYSTEM = platform.system()
SKILL_DIR = os.path.dirname(os.path.abspath(__file__))

# ══════════════════════════════════════════════════════════════
# 0. 检测 Chrome 是否可用（决定批量用哪个版本）
# ══════════════════════════════════════════════════════════════
def chrome_available():
    if SYSTEM == 'Windows':
        paths = [
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        ]
        return any(os.path.isfile(p) for p in paths)
    elif SYSTEM == 'Darwin':
        return os.path.isfile('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome')
    else:
        for p in ('chromium', 'chromium-browser', 'google-chrome'):
            try:
                subprocess.run([p, '--version'], capture_output=True, timeout=5)
                return True
            except Exception:
                pass
        return False

# ══════════════════════════════════════════════════════════════
# 1. 分析参数，判断处理模式
# ══════════════════════════════════════════════════════════════
def analyze_args(args):
    """
    返回:
      mode: 'single' | 'batch_xlsx' | 'batch_urls'
      urls: [str]           # 单篇时为 [url]，批量时为 [url, ...]
      xlsx_path: str|None   # batch_xlsx 时有效
    """
    if not args:
        return None, [], None

    first = args[0]

    # 判断是否是 xlsx 文件（按扩展名，不依赖文件是否存在）
    if first.endswith('.xlsx') or first.endswith('.xls'):
        return 'batch_xlsx', [], first

    # 收集所有 URL（支持 http:// / https:// 开头，或 mp.weixin.qq.com）
    urls = []
    for a in args:
        s = str(a).strip()
        if s and ('mp.weixin.qq.com' in s or s.startswith('http') or s.startswith('https://')):
            urls.append(s if s.startswith('http') else f'https://{s}')

    if len(urls) == 0:
        return None, [], None
    elif len(urls) == 1:
        return 'single', urls, None
    else:
        return 'batch_urls', urls, None

# ══════════════════════════════════════════════════════════════
# 2. 生成临时 xlsx（batch_urls 模式需要）
# ══════════════════════════════════════════════════════════════
def urls_to_xlsx(urls):
    """
    将 URL 列表写入临时 xlsx，格式与 batch_scrape.py 兼容：
    col[1]=标题(B), col[2]=日期(C), col[5]=URL(F)
    """
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "URL列表"
    headers = ['logo', '标题', '日期', '摘要', '标签', 'URL']
    ws.append(headers)
    for i, url in enumerate(urls, 1):
        ws.append(['', f'文章{i}', '', '', '', url])
    tmp = tempfile.NamedTemporaryFile(suffix='.xlsx', delete=False)
    wb.save(tmp.name)
    tmp.close()
    return tmp.name

# ══════════════════════════════════════════════════════════════
# 3. 主路由
# ══════════════════════════════════════════════════════════════
def main():
    args = sys.argv[1:]

    if not args:
        print("❌ 未提供参数")
        print(__doc__)
        sys.exit(1)

    mode, urls, xlsx_path = analyze_args(args)

    if mode is None:
        print("❌ 未识别到有效的 URL")
        print(__doc__)
        sys.exit(1)

    # ── 单篇模式 ────────────────────────────────────────────────
    if mode == 'single':
        url = urls[0]
        print(f"📌 单篇模式（URL=1）")
        print(f"   使用 scrape.py 完整抓取（PDF + Markdown）")
        print(f"   URL: {url[:80]}")
        print()
        ret = subprocess.run(
            [sys.executable, os.path.join(SKILL_DIR, 'scrape.py'), url],
            cwd=SKILL_DIR
        )
        sys.exit(ret.returncode)

    # ── 批量 xlsx 模式 ───────────────────────────────────────────
    elif mode == 'batch_xlsx':
        xlsx_path = os.path.abspath(xlsx_path)

        # 统计 xlsx 中的 URL 数量
        try:
            wb = openpyxl.load_workbook(xlsx_path, read_only=True)
            ws = wb.active
            rows = list(ws.iter_rows(min_row=2, values_only=True))
            wb.close()
        except Exception as e:
            print(f"❌ 无法读取 xlsx: {e}")
            sys.exit(1)

        url_count = sum(1 for r in rows if r[5] and str(r[5]).strip())
        print(f"📦 批量模式（xlsx，检测到 {url_count} 个 URL）")

        if url_count == 0:
            print("❌ xlsx 中未找到有效 URL（第6列 F）")
            sys.exit(1)
        elif url_count == 1:
            print(f"   ⚡ 仅 1 个 URL，降级为 scrape.py 单篇模式")
            row = next(r for r in rows if r[5] and str(r[5]).strip())
            url = str(row[5]).strip()
            ret = subprocess.run(
                [sys.executable, os.path.join(SKILL_DIR, 'scrape.py'), url],
                cwd=SKILL_DIR
            )
            sys.exit(ret.returncode)

        use_chrome = chrome_available()
        script = 'batch_scrape.py' if use_chrome else 'batch_http.py'
        print(f"   使用 {script}（Chrome {'可用' if use_chrome else '不可用'}）")
        print()
        ret = subprocess.run(
            [sys.executable, os.path.join(SKILL_DIR, script), xlsx_path],
            cwd=SKILL_DIR
        )
        sys.exit(ret.returncode)

    # ── 批量多 URL 模式 ──────────────────────────────────────────
    elif mode == 'batch_urls':
        url_count = len(urls)
        print(f"📦 批量模式（{url_count} 个 URL）")
        if url_count == 1:
            print(f"   ⚡ 仅 1 个 URL，降级为 scrape.py 单篇模式")
            ret = subprocess.run(
                [sys.executable, os.path.join(SKILL_DIR, 'scrape.py'), urls[0]],
                cwd=SKILL_DIR
            )
            sys.exit(ret.returncode)

        print(f"   将 {url_count} 个 URL 写入临时 xlsx ...")
        tmp_xlsx = urls_to_xlsx(urls)
        print(f"   临时文件: {tmp_xlsx}")
        print()

        use_chrome = chrome_available()
        script = 'batch_scrape.py' if use_chrome else 'batch_http.py'
        print(f"   使用 {script}（Chrome {'可用' if use_chrome else '不可用'}）")
        ret = subprocess.run(
            [sys.executable, os.path.join(SKILL_DIR, script), tmp_xlsx],
            cwd=SKILL_DIR
        )
        try:
            os.remove(tmp_xlsx)
        except Exception:
            pass
        sys.exit(ret.returncode)

if __name__ == '__main__':
    main()
