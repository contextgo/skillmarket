#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Word 文档排版清理脚本
功能：
1. 删除中文字符与英文/数字之间的多余空格（保留英文词组内部空格）
2. 清理 Markdown 格式符号（#、-、*、>、**、`、~~、[]() 等）
3. 删除 AI 免责声明文本（如 "|（注：文档部分内容可能由 AI 生成）"）
4. 支持 .doc（通过 COM 转换）和 .docx 格式
5. 输出处理统计

用法：
  python clean_docx.py <input_file> [--output-mode <new|overwrite>]
"""

import re
import sys
import os
import argparse
import copy

# UTF-8 输出（Windows 兼容）
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass

# ============================================================
# 中文字符范围定义
# ============================================================
# CJK 统一汉字 + CJK 兼容汉字 + 全角字符 + 中文标点
CJK_PATTERN = (
    r'\u4e00-\u9fff'       # CJK 统一汉字
    r'\u3400-\u4dbf'       # CJK 扩展A
    r'\uf900-\ufaff'       # CJK 兼容汉字
    r'\u3000-\u303f'       # CJK 标点符号
    r'\uff00-\uffef'       # 全角ASCII、全角标点
    r'\u20000-\u2a6df'     # CJK 扩展B（ surrogate pair 范围由 regex 库处理，此处仅标注）
)

# 用于正则的字符类
CJK_CLASS = r'[\u4e00-\u9fff\u3400-\u4dbf\uf900-\ufaff\u3000-\u303f\uff00-\uffef]'


# ============================================================
# 空格清理函数
# ============================================================
def clean_spaces(text):
    """
    清理中文字符与英文/数字之间的多余空格。
    保留英文词组内部空格。
    
    返回: (cleaned_text, count)
    """
    count = 0
    original = text
    
    # 规则1: 中文字符后跟空格再跟英文/数字 → 删除空格
    # 例如: "使用 iPhone" → "使用iPhone"
    pattern1 = re.compile(f'({CJK_CLASS})\\s+([a-zA-Z0-9])')
    while pattern1.search(text):
        matches = len(pattern1.findall(text))
        count += matches
        text = pattern1.sub(r'\1\2', text)
    
    # 规则2: 英文/数字后跟空格再跟中文字符 → 删除空格
    # 例如: "iPhone 手机" → "iPhone手机"
    pattern2 = re.compile(f'([a-zA-Z0-9])\\s+({CJK_CLASS})')
    while pattern2.search(text):
        matches = len(pattern2.findall(text))
        count += matches
        text = pattern2.sub(r'\1\2', text)
    
    # 规则3: 中文标点后的多余空格（但保留标点前必要的格式空格）
    # 例如: "， " → "，"  "。 " → "。"
    pattern3 = re.compile(f'([\\u3000-\\u303f\\uff00-\\uffef\\u201c\\u201d\\u2018\\u2019])\\s+({CJK_CLASS})')
    while pattern3.search(text):
        matches = len(pattern3.findall(text))
        count += matches
        text = pattern3.sub(r'\1\2', text)
    
    return text, count


# ============================================================
# Markdown 符号清理函数
# ============================================================
def clean_markdown(text):
    """
    清理 Markdown 格式符号，保留内部文字。
    
    返回: (cleaned_text, count)
    """
    count = 0
    original = text
    
    # 1. 行首标题标记: # / ## / ### / #### / ##### / ###### + 空格
    pattern = re.compile(r'^#{1,6}\s+', re.MULTILINE)
    matches = len(pattern.findall(text))
    count += matches
    text = pattern.sub('', text)
    
    # 2. 行首无序列表标记: - / * / + + 空格
    pattern = re.compile(r'^[-*+]\s+', re.MULTILINE)
    matches = len(pattern.findall(text))
    count += matches
    text = pattern.sub('', text)
    
    # 3. 行首引用标记: > + 空格
    pattern = re.compile(r'^>\s+', re.MULTILINE)
    matches = len(pattern.findall(text))
    count += matches
    text = pattern.sub('', text)
    
    # 4. 行首有序列表标记: 1. / 2. 等 + 空格
    pattern = re.compile(r'^\d+\.\s+', re.MULTILINE)
    matches = len(pattern.findall(text))
    count += matches
    text = pattern.sub('', text)
    
    # 5. 加粗: **text** 或 __text__
    pattern = re.compile(r'\*\*(.+?)\*\*')
    matches = len(pattern.findall(text))
    count += matches
    text = pattern.sub(r'\1', text)
    
    pattern = re.compile(r'__(.+?)__')
    matches = len(pattern.findall(text))
    count += matches
    text = pattern.sub(r'\1', text)
    
    # 6. 斜体: *text* 或 _text_（注意不要误伤英文连字符等）
    # 使用更谨慎的匹配：左右边界为非空白或行首/行尾
    pattern = re.compile(r'(?<!\w)\*(.+?)\*(?!\w)')
    matches = len(pattern.findall(text))
    count += matches
    text = pattern.sub(r'\1', text)
    
    pattern = re.compile(r'(?<!\w)_(.+?)_(?!\w)')
    matches = len(pattern.findall(text))
    count += matches
    text = pattern.sub(r'\1', text)
    
    # 7. 行内代码: `text`
    pattern = re.compile(r'`(.+?)`')
    matches = len(pattern.findall(text))
    count += matches
    text = pattern.sub(r'\1', text)
    
    # 8. 删除线: ~~text~~
    pattern = re.compile(r'~~(.+?)~~')
    matches = len(pattern.findall(text))
    count += matches
    text = pattern.sub(r'\1', text)
    
    # 9. 链接: [text](url) → text
    pattern = re.compile(r'\[([^\]]+)\]\([^\)]+\)')
    matches = len(pattern.findall(text))
    count += matches
    text = pattern.sub(r'\1', text)
    
    # 10. 行首分隔线: --- / *** / ___ （3个及以上连续符号独占一行）
    pattern = re.compile(r'^[-*_]{3,}\s*$', re.MULTILINE)
    matches = len(pattern.findall(text))
    count += matches
    text = pattern.sub('', text)
    
    # 11. 清理残留的行首/行尾多余空格
    text = re.sub(r'^[ \t]+', '', text, flags=re.MULTILINE)
    text = re.sub(r'[ \t]+$', '', text, flags=re.MULTILINE)
    
    return text, count


# ============================================================
# 合并连续空行
# ============================================================
def clean_blank_lines(text):
    """将连续多个空行合并为单个空行。"""
    cleaned = re.sub(r'\n{3,}', '\n\n', text)
    return cleaned


# ============================================================
# AI 免责声明清理
# ============================================================
def clean_ai_disclaimer(text):
    """
    删除文档中的 AI 免责声明文本。
    
    返回: (cleaned_text, count)
    """
    count = 0
    original = text
    
    # 删除 AI 免责声明
    pattern = re.compile(r'\|\s*（注：文档部分内容可能由 AI 生成）')
    matches = pattern.findall(text)
    count += len(matches)
    text = pattern.sub('', text)
    
    # 清理因删除后产生的连续分隔符（如 "内容内容|" 后紧跟 "正文"）
    # 管道符前后多余的分隔符
    pattern2 = re.compile(r'\|{2,}')
    matches2 = pattern2.findall(text)
    count += len(matches2)
    text = pattern2.sub('|', text)
    
    # 清理行首/行尾的孤立管道符
    pattern3 = re.compile(r'^\|+|\|+$')
    matches3 = pattern3.findall(text)
    count += len(matches3)
    text = pattern3.sub('', text)
    
    return text, count


# ============================================================
# 对单个 run 应用所有清理规则
# ============================================================
def clean_run_text(text):
    """对 run 文本应用所有清理规则，返回 (cleaned_text, space_count, md_count, ai_count)"""
    text, space_count = clean_spaces(text)
    text, md_count = clean_markdown(text)
    text, ai_count = clean_ai_disclaimer(text)
    return text, space_count, md_count, ai_count


# ============================================================
# 处理段落（处理跨 run 的中英文空格）
# ============================================================
def clean_paragraph(paragraph, total_stats):
    """
    处理单个段落。
    策略：
    1. 先在 run 级别清理 Markdown 符号和 run 内空格
    2. 再检测段落全文，处理跨 run 的中英文空格
    """
    space_count = 0
    md_count = 0
    ai_count = 0
    
    # 第一步：在 run 级别清理 Markdown 符号和 run 内空格
    for run in paragraph.runs:
        if not run.text:
            continue
        original_text = run.text
        cleaned_text, sc, mc, ac = clean_run_text(run.text)
        if cleaned_text != original_text:
            run.text = cleaned_text
            space_count += sc
            md_count += mc
            ai_count += ac
    
    # 第二步：处理跨 run 的中英文空格
    # 例如: run1="中文 " + run2="English" → 需要删除 run1 末尾的空格
    runs = paragraph.runs
    for i in range(len(runs) - 1):
        current_run = runs[i]
        next_run = runs[i + 1]
        
        if not current_run.text or not next_run.text:
            continue
        
        # 当前 run 末尾是空格，下一个 run 开头是英文/数字，且当前 run 末尾前一个字符是中文
        if (current_run.text.rstrip() != current_run.text and 
            current_run.text.rstrip() and
            re.search(CJK_CLASS + r'$', current_run.text.rstrip()) and
            re.match(r'[a-zA-Z0-9]', next_run.text.lstrip())):
            
            # 删除当前 run 末尾的空格
            stripped = current_run.text.rstrip()
            removed = len(current_run.text) - len(stripped)
            current_run.text = stripped
            space_count += removed
        
        # 当前 run 末尾是英文/数字，下一个 run 开头是空格+中文
        elif (current_run.text and
              re.search(r'[a-zA-Z0-9]$', current_run.text) and
              next_run.text.lstrip() != next_run.text and
              re.search(f'^{CJK_CLASS}', next_run.text.lstrip())):
            
            # 删除下一个 run 开头的空格
            stripped = next_run.text.lstrip()
            removed = len(next_run.text) - len(stripped)
            next_run.text = stripped
            space_count += removed
    
    total_stats['spaces'] += space_count
    total_stats['markdown'] += md_count
    total_stats['ai_disclaimer'] += ai_count
    return space_count, md_count, ai_count


# ============================================================
# 处理表格
# ============================================================
def clean_table(table, total_stats):
    """处理表格中所有单元格的段落。"""
    space_count = 0
    md_count = 0
    ai_count = 0
    for row in table.rows:
        for cell in row.cells:
            for paragraph in cell.paragraphs:
                sc, mc, ac = clean_paragraph(paragraph, total_stats)
                space_count += sc
                md_count += mc
                ai_count += ac
    return space_count, md_count, ai_count


# ============================================================
# 处理页眉页脚
# ============================================================
def clean_header_footer(section, total_stats):
    """处理节的页眉页脚。"""
    space_count = 0
    md_count = 0
    ai_count = 0
    
    # 页眉
    if section.header and not section.header.is_linked_to_previous:
        for paragraph in section.header.paragraphs:
            sc, mc, ac = clean_paragraph(paragraph, total_stats)
            space_count += sc
            md_count += mc
            ai_count += ac
    
    # 页脚
    if section.footer and not section.footer.is_linked_to_previous:
        for paragraph in section.footer.paragraphs:
            sc, mc, ac = clean_paragraph(paragraph, total_stats)
            space_count += sc
            md_count += mc
            ai_count += ac
    
    return space_count, md_count, ai_count


# ============================================================
# .doc → .docx 转换（Windows COM）
# ============================================================
def convert_doc_to_docx(doc_path):
    """
    使用 Windows COM 接口将 .doc 转换为 .docx。
    返回转换后的 .docx 文件路径。
    """
    try:
        import win32com.client
    except ImportError:
        print("错误: 需要安装 pywin32 库来处理 .doc 文件。")
        print("请运行: pip install pywin32")
        sys.exit(1)
    
    doc_path = os.path.abspath(doc_path)
    docx_path = os.path.splitext(doc_path)[0] + '_converted.docx'
    
    word = None
    doc = None
    try:
        word = win32com.client.Dispatch("Word.Application")
        word.Visible = False
        doc = word.Documents.Open(doc_path)
        
        # wdFormatXMLDocument = 12 (docx format)
        doc.SaveAs(docx_path, FileFormat=12)
        print(f"已将 .doc 转换为 .docx: {docx_path}")
        return docx_path
    except Exception as e:
        print(f"转换 .doc 文件失败: {e}")
        sys.exit(1)
    finally:
        if doc:
            doc.Close(False)
        if word:
            word.Quit()


# ============================================================
# 主处理流程
# ============================================================
def process_docx(input_path, output_mode='new'):
    """
    处理 .docx 文件，执行所有清理规则。
    
    Args:
        input_path: 输入文件路径
        output_mode: 'new' 另存为新文件，'overwrite' 覆盖原文件
    
    Returns:
        output_path: 输出文件路径
        stats: 处理统计
    """
    from docx import Document
    
    input_path = os.path.abspath(input_path)
    
    if not os.path.exists(input_path):
        print(f"错误: 文件不存在: {input_path}")
        sys.exit(1)
    
    # 处理 .doc 格式
    converted_path = None
    if input_path.lower().endswith('.doc') and not input_path.lower().endswith('.docx'):
        converted_path = convert_doc_to_docx(input_path)
        input_path = converted_path
    
    # 加载文档
    doc = Document(input_path)
    
    total_stats = {'spaces': 0, 'markdown': 0, 'ai_disclaimer': 0}
    
    # 1. 处理所有段落
    for paragraph in doc.paragraphs:
        clean_paragraph(paragraph, total_stats)
    
    # 2. 处理所有表格
    for table in doc.tables:
        clean_table(table, total_stats)
    
    # 3. 处理页眉页脚
    for section in doc.sections:
        clean_header_footer(section, total_stats)
    
    # 确定输出路径
    if output_mode == 'overwrite':
        output_path = input_path
    else:
        base, ext = os.path.splitext(input_path)
        output_path = f"{base}_cleaned{ext}"
    
    # 保存文档
    doc.save(output_path)
    
    # 清理临时转换文件
    if converted_path and os.path.exists(converted_path) and output_mode != 'overwrite':
        try:
            os.remove(converted_path)
        except Exception:
            pass
    
    return output_path, total_stats


# ============================================================
# 命令行入口
# ============================================================
def main():
    parser = argparse.ArgumentParser(description='Word 文档排版清理工具')
    parser.add_argument('input_file', help='输入文件路径 (.doc 或 .docx)')
    parser.add_argument(
        '--output-mode',
        choices=['new', 'overwrite'],
        default='new',
        help='输出模式: new=另存为新文件, overwrite=覆盖原文件 (默认: new)'
    )
    
    args = parser.parse_args()
    
    print(f"正在处理: {args.input_file}")
    print(f"输出模式: {'另存为新文件' if args.output_mode == 'new' else '覆盖原文件'}")
    print("-" * 50)
    
    output_path, stats = process_docx(args.input_file, args.output_mode)
    
    print("-" * 50)
    print(f"处理完成！")
    print(f"输出文件: {output_path}")
    print(f"清理中英文空格: {stats['spaces']} 处")
    print(f"清理 Markdown 符号: {stats['markdown']} 处")
    print(f"删除 AI 免责声明: {stats['ai_disclaimer']} 处")
    print(f"总计修改: {stats['spaces'] + stats['markdown'] + stats['ai_disclaimer']} 处")


if __name__ == '__main__':
    main()
