const http = require('http');
const { spawn } = require('child_process');
const os = require('os');
const path = require('path');
const fs = require('fs');

// 读取配置文件（与 CLI 同级目录的 config.json）
const configPath = path.join(__dirname, 'config.json');
let CONFIG = { host: '127.0.0.1', port: 23330 };
try {
  const configData = fs.readFileSync(configPath, 'utf-8');
  CONFIG = JSON.parse(configData);
} catch (err) {
  // 配置文件不存在或解析失败，使用默认值
}

// HTTP 请求封装
function request(path) {
  return new Promise((resolve, reject) => {
    const req = http.get(`http://${CONFIG.host}:${CONFIG.port}${path}`, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch {
          resolve(data);
        }
      });
    });

    req.on('error', reject);
    req.setTimeout(5000, () => {
      req.destroy();
      reject(new Error('Request timeout'));
    });
  });
}

// 格式化时间
function formatTime(seconds) {
  if (!seconds || isNaN(seconds)) return '0:00';
  const totalSeconds = Math.floor(seconds);
  const minutes = Math.floor(totalSeconds / 60);
  const secs = totalSeconds % 60;
  return `${minutes}:${secs.toString().padStart(2, '0')}`;
}

// 格式化状态输出
function formatStatus(data) {
  if (!data || !data.name) {
    return '⏹️  未在播放';
  }

  const progress = data.progress || 0;
  const duration = data.duration || 0;
  const status = data.status === 'playing' ? '▶️' : '⏸️';
  const volume = data.volume !== undefined ? `${data.volume}%` : '未知';
  const mute = data.mute ? ' (已静音)' : '';
  const collect = data.collect === true ? '❤️ 已收藏' : (data.collect === false ? '🤍 未收藏' : '');

  return `${status}  ${data.name}${data.singer ? ` - ${data.singer}` : ''}
   歌手: ${data.singer || '未知'}
   专辑: ${data.albumName || '未知'}
   进度: ${formatTime(progress)} / ${formatTime(duration)}
   音量: ${volume}${mute}${collect ? '\n   收藏: ' + collect : ''}
   歌词: ${data.lyricLineText || '无'}`;
}

// 唤起 Scheme URL（跨平台）
function openSchemeUrl(url) {
  return new Promise((resolve, reject) => {
    const platform = os.platform();
    let cmd, args;

    if (platform === 'win32') {
      cmd = 'cmd';
      args = ['/c', 'start', '', url];
    } else if (platform === 'darwin') {
      cmd = 'open';
      args = ['-g', url];
    } else {
      cmd = 'xdg-open';
      args = [url];
    }

    const child = spawn(cmd, args, { detached: true, stdio: 'ignore' });
    child.on('error', reject);
    child.on('close', (code) => {
      if (code === 0) resolve();
      else reject(new Error(`Exit code: ${code}`));
    });
    // 不等待进程结束，立即 resolve
    setTimeout(() => resolve(), 100);
  });
}

// API 封装
const api = {
  status: () => request('/status?filter=status,name,singer,albumName,lyricLineText,duration,progress,playbackRate,volume,mute,collect'),
  play: () => request('/play'),
  pause: () => request('/pause'),
  next: () => request('/next'),
  prev: () => request('/prev'),
  volume: (vol) => request(`/volume?volume=${vol}`),
  mute: () => request('/mute'),
  unmute: () => request('/unmute'),
  collect: () => request('/collect'),
  uncollect: () => request('/uncollect'),
};

// 主函数
async function main() {
  const args = process.argv.slice(2);
  const command = args[0];
  
  // 智能参数获取：支持带空格的歌名/关键词
  // 从指定位置开始合并所有剩余参数
  function getArgsFrom(index) {
    return args.slice(index).join(' ');
  }

  if (!command) {
    console.log('用法: node lx-music-cli.js <命令> [参数]');
    console.log('');
    console.log('命令:');
    console.log('  search <关键词> [源]     搜索歌曲（唤醒程序）');
    console.log('  searchPlay <歌名> [歌手] 搜索并播放（唤醒程序）');
    console.log('  play                    播放');
    console.log('  pause                   暂停');
    console.log('  toggle                  切换播放/暂停');
    console.log('  next                    下一首');
    console.log('  prev                    上一首');
    console.log('  status                  播放状态');
    console.log('  now                     当前歌曲');
    console.log('  lyric                   歌词');
    console.log('  volume <0-100>          设置音量');
    console.log('  mute                    静音');
    console.log('  unmute                  取消静音');
    console.log('  openlist <源> <歌单ID>   打开歌单');
    console.log('  playlist <源> <歌单ID> [起始序号] 播放歌单');
    console.log('  collect                 收藏');
    console.log('  uncollect               取消收藏');
    console.log('  dislike                 不喜欢');
    process.exit(1);
  }

  try {
    switch (command) {
      case 'search': {
        let keyword = getArgsFrom(1);
        let source = '';
        
        // 如果参数超过1个且最后一个是源（2个字母），分离出来
        const parts = keyword.split(' ');
        const validSources = ['kw', 'kg', 'tx', 'wy', 'mg'];
        if (parts.length > 1 && validSources.includes(parts[parts.length - 1])) {
          source = parts.pop();
          keyword = parts.join(' ');
        }
        
        if (!keyword) {
          console.log('❌ 用法: search <关键词> [源]');
          console.log('   例: search 周杰伦');
          console.log('   例: search Beat It');
          console.log('   例: search 周杰伦 kw');
          process.exit(1);
        }
        const encodedKeyword = encodeURIComponent(keyword);
        const url = source
          ? `lxmusic://music/search/${source}/${encodedKeyword}`
          : `lxmusic://music/search/${encodedKeyword}`;
        await openSchemeUrl(url);
        console.log(`🔍 搜索: ${keyword}${source ? ` (源: ${source})` : ''}`);
        break;
      }

      case 'searchPlay': {
        let songName, singer;
        
        if (args.length >= 4) {
          // 3个及以上参数：尝试识别歌手（最后一个参数如果是常见歌手名）
          const commonSingers = ['周杰伦', '林俊杰', '张学友', '刘德华', '邓紫棋', '薛之谦', '陈奕迅', '王菲', '那英', '李宗盛', 'Adele', 'Avril', 'Westlife', 'Backstreet', 'Michael', 'Jackson'];
          const lastArg = args[args.length - 1];
          if (commonSingers.some(s => lastArg.toLowerCase().includes(s.toLowerCase()))) {
            singer = lastArg;
            songName = args.slice(1, -1).join(' ');
          } else {
            songName = getArgsFrom(1);
          }
        } else if (args.length === 3) {
          // 2个参数：可能是 "歌名 歌手" 或 "多词歌名"
          const commonSingers = ['周杰伦', '林俊杰', '张学友', '刘德华', '邓紫棋', '薛之谦', '陈奕迅', '王菲', '那英', '李宗盛', 'Adele', 'Avril', 'Westlife', 'Backstreet', 'Michael', 'Jackson'];
          if (commonSingers.some(s => args[2].toLowerCase().includes(s.toLowerCase()))) {
            songName = args[1];
            singer = args[2];
          } else {
            songName = getArgsFrom(1);
          }
        } else {
          songName = args[1] || '';
        }
        
        if (!songName) {
          console.log('❌ 用法: searchPlay <歌名> [歌手]');
          console.log('   例: searchPlay 晴天');
          console.log('   例: searchPlay Beat It');
          console.log('   例: searchPlay God is a girl');
          console.log('   例: searchPlay 晴天 周杰伦');
          process.exit(1);
        }
        const query = singer ? `${songName}-${singer}` : songName;
        const encodedQuery = encodeURIComponent(query);
        const url = `lxmusic://music/searchPlay/${encodedQuery}`;
        await openSchemeUrl(url);
        console.log(`🎵 尝试播放: ${query}`);
        break;
      }

      case 'play': {
        await api.play();
        console.log('▶️  播放');
        break;
      }

      case 'pause': {
        await api.pause();
        console.log('⏸️  暂停');
        break;
      }

      case 'toggle': {
        await openSchemeUrl('lxmusic://player/togglePlay');
        console.log('⏯️  切换播放/暂停');
        break;
      }

      case 'next': {
        await api.next();
        console.log('⏭️  下一首');
        break;
      }

      case 'prev': {
        await api.prev();
        console.log('⏮️  上一首');
        break;
      }

      case 'status': {
        const data = await api.status();
        console.log(formatStatus(data));
        break;
      }

      case 'now': {
        const data = await api.status();
        if (data && data.name) {
          console.log(`${data.name} - ${data.singer || '未知歌手'}`);
        } else {
          console.log('⏹️  未在播放');
        }
        break;
      }

      case 'lyric': {
        const data = await api.status();
        if (data && data.lyric) {
          console.log(data.lyric);
        } else {
          console.log('无歌词');
        }
        break;
      }

      case 'volume': {
        const vol = parseInt(args[1]);
        if (isNaN(vol) || vol < 0 || vol > 100) {
          console.log('❌ 用法: volume <0-100>');
          process.exit(1);
        }
        await api.volume(vol);
        console.log(`🔊 音量设置为 ${vol}%`);
        break;
      }

      case 'mute': {
        await api.mute();
        console.log('🔇 静音');
        break;
      }

      case 'unmute': {
        await api.unmute();
        console.log('🔊 取消静音');
        break;
      }

      case 'openlist': {
        const source = args[1];
        const id = args[2];
        if (!source || !id) {
          console.log('❌ 用法: openlist <源> <歌单ID>');
          console.log('  源: kw(酷我), kg(酷狗), tx(QQ), wy(网易), mg(咪咕)');
          process.exit(1);
        }
        const url = `lxmusic://songlist/open/${source}/${id}`;
        await openSchemeUrl(url);
        console.log(`📂 打开歌单: ${source} ${id}`);
        break;
      }

      case 'playlist': {
        const plSource = args[1];
        const plId = args[2];
        const startIndex = args[3] || '1';
        if (!plSource || !plId) {
          console.log('❌ 用法: playlist <源> <歌单ID> [起始序号]');
          console.log('  源: kw(酷我), kg(酷狗), tx(QQ), wy(网易), mg(咪咕)');
          process.exit(1);
        }
        const url = `lxmusic://songlist/play/${plSource}/${plId}/${startIndex}`;
        await openSchemeUrl(url);
        console.log(`▶️  播放歌单: ${plSource} ${plId} (从第 ${startIndex} 首开始)`);
        break;
      }

      case 'collect': {
        await api.collect();
        console.log('❤️  已收藏');
        break;
      }

      case 'uncollect': {
        await api.uncollect();
        console.log('💔 已取消收藏');
        break;
      }

      case 'dislike': {
        await openSchemeUrl('lxmusic://player/dislike');
        console.log('👎 已标记不喜欢');
        break;
      }

      default:
        console.log(`❌ 未知命令: ${command}`);
        console.log('使用 "node lx-music-cli.js" 查看帮助');
        process.exit(1);
    }
  } catch (error) {
    console.error(`❌ 错误: ${error.message}`);
    process.exit(1);
  }
}

main();
