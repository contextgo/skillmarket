#!/usr/bin/env node
/**
 * LX Music CLI - 集成版
 * 内嵌在 lx-music-assistant skill 中，无需单独安装
 */

const http = require('http');
const { execSync } = require('child_process');
const os = require('os');

const DEFAULT_CONFIG = {
  host: '127.0.0.1',
  port: 23330,
};

// HTTP API 请求
function request(path, method = 'GET') {
  return new Promise((resolve, reject) => {
    const req = http.request(
      {
        hostname: DEFAULT_CONFIG.host,
        port: DEFAULT_CONFIG.port,
        path,
        method,
        timeout: 5000,
      },
      (res) => {
        let data = '';
        res.setEncoding('utf8');
        res.on('data', chunk => { data += chunk; });
        res.on('end', () => {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            try {
              const isJson = res.headers['content-type']?.includes('application/json');
              resolve(isJson ? JSON.parse(data) : data);
            } catch {
              resolve(data);
            }
          } else {
            reject(new Error(`HTTP ${res.statusCode}: ${data}`));
          }
        });
      }
    );
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('timeout')); });
    req.end();
  });
}

// Scheme URL 唤起
function openSchemeUrl(url) {
  const platform = os.platform();
  try {
    if (platform === 'win32') {
      execSync(`start "" "${url}"`, { shell: 'cmd.exe', stdio: 'ignore' });
    } else if (platform === 'darwin') {
      execSync(`open "${url}"`, { stdio: 'ignore' });
    } else {
      execSync(`xdg-open "${url}"`, { stdio: 'ignore' });
    }
  } catch (err) {
    console.error('❌ 无法唤起 Scheme URL:', err.message);
  }
}

// 格式化时长
function formatDuration(seconds) {
  if (!seconds || isNaN(seconds)) return '0:00';
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${s.toString().padStart(2, '0')}`;
}

// 打印状态
function printStatus(data) {
  if (!data || !data.name) {
    console.log('⚠️ 没有正在播放的歌曲');
    return;
  }
  const icon = data.status === 'playing' ? '▶️' : data.status === 'paused' ? '⏸️' : '⏹️';
  console.log(`${icon}  ${data.name}`);
  console.log(`   歌手: ${data.singer || '-'}`);
  console.log(`   专辑: ${data.albumName || '-'}`);
  console.log(`   进度: ${formatDuration(data.progress)} / ${formatDuration(data.duration)}`);
  console.log(`   音量: ${Math.round((data.volume || 0) * 100)}% ${data.mute ? '(静音)' : ''}`);
  if (data.lyricLineText) {
    console.log(`   歌词: ${data.lyricLineText}`);
  }
}

// API 封装
const api = {
  status: () => request('/status'),
  lyric: () => request('/lyric'),
  play: () => request('/play'),
  pause: () => request('/pause'),
  skipNext: () => request('/skip-next'),
  skipPrev: () => request('/skip-prev'),
  volume: (vol) => request(`/volume?volume=${vol}`),
  mute: (m) => request(`/mute?mute=${m}`),
  collect: () => request('/collect'),
  uncollect: () => request('/uncollect'),
};

// 命令处理
const args = process.argv.slice(2);
const cmd = args[0];

async function main() {
  try {
    switch (cmd) {
      case 'play':
        openSchemeUrl('lxmusic://player/play');
        console.log('▶️  播放');
        break;
      case 'pause':
        openSchemeUrl('lxmusic://player/pause');
        console.log('⏸️  暂停');
        break;
      case 'toggle':
        openSchemeUrl('lxmusic://player/togglePlay');
        console.log('⏯️  切换播放/暂停');
        break;
      case 'next':
        openSchemeUrl('lxmusic://player/skipNext');
        console.log('⏭️  下一首');
        break;
      case 'prev':
        openSchemeUrl('lxmusic://player/skipPrev');
        console.log('⏮️  上一首');
        break;
      case 'search': {
        const keyword = args[1];
        const searchSource = args[2]; // 可选源
        if (!keyword) {
          console.log('❌ 用法: search <关键词> [源]');
          console.log('   例: search 周杰伦');
          console.log('   例: search 周杰伦 kw');
          process.exit(1);
        }
        const searchUrl = searchSource
          ? `lxmusic://music/search/${searchSource}/${encodeURIComponent(keyword)}`
          : `lxmusic://music/search/${encodeURIComponent(keyword)}`;
        openSchemeUrl(searchUrl);
        console.log(`🔍 已打开搜索页面: ${keyword}`);
        break;
      }
      case 'searchPlay': {
        const songName = args[1];
        const singer = args[2]; // 可选歌手
        if (!songName) {
          console.log('❌ 用法: searchPlay <歌名> [歌手]');
          console.log('   例: searchPlay 晴天');
          console.log('   例: searchPlay 晴天 周杰伦');
          process.exit(1);
        }
        const playQuery = singer ? `${songName}-${singer}` : songName;
        openSchemeUrl(`lxmusic://music/searchPlay/${encodeURIComponent(playQuery)}`);
        console.log(`🎵 尝试播放: ${playQuery}`);
        break;
      }
      case 'status': {
        const data = await api.status();
        printStatus(data);
        break;
      }
      case 'now': {
        const data = await api.status();
        if (data.name) {
          console.log(`${data.name} - ${data.singer || '未知歌手'}`);
        } else {
          console.log('没有正在播放的歌曲');
        }
        break;
      }
      case 'lyric': {
        const data = await api.lyric();
        if (data.lyricLineText) {
          console.log(data.lyricLineText);
        } else {
          console.log('暂无歌词');
        }
        break;
      }
      case 'volume': {
        const vol = parseInt(args[1]);
        if (isNaN(vol) || vol < 0 || vol > 100) {
          console.log('❌ 音量范围: 0-100');
          process.exit(1);
        }
        await api.volume(vol / 100);
        console.log(`🔊 音量设置为 ${vol}%`);
        break;
      }
      case 'mute':
        await api.mute(true);
        console.log('🔇 已静音');
        break;
      case 'unmute':
        await api.mute(false);
        console.log('🔊 已取消静音');
        break;
      case 'collect':
        await api.collect();
        console.log('❤️  已收藏');
        break;
      case 'uncollect':
        await api.uncollect();
        console.log('💔 已取消收藏');
        break;
      case 'dislike':
        openSchemeUrl('lxmusic://player/dislike');
        console.log('👎 已标记为不喜欢');
        break;
      case 'songlist': {
        const slSource = args[1];
        const slId = args[2];
        if (!slSource || !slId) {
          console.log('❌ 用法: songlist <源> <ID>');
          console.log('   例: songlist kw 123456');
          process.exit(1);
        }
        openSchemeUrl(`lxmusic://songlist/open/${slSource}/${encodeURIComponent(slId)}`);
        console.log(`📋 已打开歌单: ${slSource}/${slId}`);
        break;
      }
      case 'songlist-play': {
        const slpSource = args[1];
        const slpId = args[2];
        if (!slpSource || !slpId) {
          console.log('❌ 用法: songlist-play <源> <ID>');
          console.log('   例: songlist-play kw 123456');
          process.exit(1);
        }
        openSchemeUrl(`lxmusic://songlist/play/${slpSource}/${encodeURIComponent(slpId)}`);
        console.log(`▶️  开始播放歌单: ${slpSource}/${slpId}`);
        break;
      }
      case 'help':
      case '-h':
      case '--help':
      default:
        showHelp();
        break;
    }
  } catch (err) {
    console.error('❌ 错误:', err.message);
    if (err.message.includes('ECONNREFUSED')) {
      console.log('   请确保 LX Music 桌面端已启动并开启 OpenAPI');
      console.log('   设置 -> 基础设置 -> 开放 API');
    }
    process.exit(1);
  }
}

function showHelp() {
  console.log(`
🎵  LX Music CLI (集成版)

用法: node lx-music-cli.js <command> [args]

播放控制:
  play              播放
  pause             暂停
  toggle            播放/暂停切换
  next              下一首
  prev              上一首

搜索:
  search <关键词> [源]       打开搜索页面（源可选）
  searchPlay <歌名> [歌手]   直接播放（需缓存）

歌单:
  songlist <源> <ID>         打开歌单
  songlist-play <源> <ID>    播放歌单

收藏:
  collect           收藏当前歌曲
  uncollect         取消收藏
  dislike           不喜欢

状态查询:
  status            显示播放状态
  now               显示当前歌曲
  lyric             显示歌词

音量:
  volume <0-100>    设置音量
  mute              静音
  unmute            取消静音

帮助:
  help              显示此帮助
`);
}

main();
