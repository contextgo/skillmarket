﻿﻿---
name: lx-music-assistant
description: 通过内嵌 CLI 控制洛雪音乐助手桌面版。支持搜索唤醒、播放控制、状态查询。
---

# 洛雪音乐助手技能

通过内嵌 CLI 工具控制洛雪音乐助手桌面版。**搜索&搜索并播放功能可唤醒程序**。

## 前置条件

1. 已安装洛雪音乐助手桌面版
2. 已开启 OpenAPI 服务：设置 → 开放 API → 启用开放 API 服务（端口 23330）

## 内嵌 CLI 路径

```
{skill_dir}/cli/lx-music-cli.js
```

## 配置

API 地址和端口配置在 `{skill_dir}/config.md`。

## 标准执行流程

**每个命令执行后必须执行此流程：**

```javascript
// 1. 执行命令
await execCommand(cmd);

// 2. 等待 500ms
await sleep(500);

// 3. 查询状态
const status = await execCommand('status');

// 4. 用 Markdown 汇报结果
if (status.name) {
  "✅ 操作成功\n\n| 项目 | 值 |\n|------|-----|\n| 歌曲 | " + status.name + " |\n| 歌手 | " + status.singer + " |\n| 进度 | " + formatDuration(status.progress) + " / " + formatDuration(status.duration) + " |\n| 音量 | " + Math.round(status.volume * 100) + "% |"
} else {
  "⚠️ 操作已执行，但 API 未启动\n\n请确认：\n1. LX Music 已启动\n2. 设置 → 基础设置 → 启用 OpenAPI 服务"
}
```

## 常用命令

### 搜索并播放（优先使用）

```bash
# 直接搜索并播放歌曲（唤醒程序）
node {skill_dir}/cli/lx-music-cli.js searchPlay <歌名>


# 打开搜索页面（唤醒程序）
node {skill_dir}/cli/lx-music-cli.js search <关键词>
```

### 播放控制

```bash
node {skill_dir}/cli/lx-music-cli.js play      # 播放
node {skill_dir}/cli/lx-music-cli.js pause     # 暂停
node {skill_dir}/cli/lx-music-cli.js toggle    # 切换播放/暂停
node {skill_dir}/cli/lx-music-cli.js next      # 下一首
node {skill_dir}/cli/lx-music-cli.js prev      # 上一首
```

### 状态查询

```bash
node {skill_dir}/cli/lx-music-cli.js status    # 完整状态
node {skill_dir}/cli/lx-music-cli.js now       # 当前歌曲
node {skill_dir}/cli/lx-music-cli.js lyric     # 歌词
```

### 音量控制

```bash
node {skill_dir}/cli/lx-music-cli.js volume <0-100>  # 设置音量
node {skill_dir}/cli/lx-music-cli.js mute            # 静音
node {skill_dir}/cli/lx-music-cli.js unmute          # 取消静音
```

### 收藏

```bash
node {skill_dir}/cli/lx-music-cli.js collect     # 收藏
node {skill_dir}/cli/lx-music-cli.js uncollect   # 取消收藏
node {skill_dir}/cli/lx-music-cli.js dislike     # 不喜欢
```

## 完整命令列表

| 命令 | 说明 | 示例 |
|------|------|------|
| `search <关键词> [源]` | 打开搜索页面 | `search 周杰伦` / `search 周杰伦 kw` |
| `searchPlay <歌名> [歌手]` | 播放已缓存歌曲 | `searchPlay 晴天` / `searchPlay 晴天 周杰伦` |
| `play` | 播放 | `play` |
| `pause` | 暂停 | `pause` |
| `toggle` | 切换播放/暂停 | `toggle` |
| `next` | 下一首 | `next` |
| `prev` | 上一首 | `prev` |
| `status` | 显示播放状态 | `status` |
| `now` | 显示当前歌曲 | `now` |
| `lyric` | 显示歌词 | `lyric` |
| `volume <0-100>` | 设置音量 | `volume 80` |
| `mute` | 静音 | `mute` |
| `unmute` | 取消静音 | `unmute` |
| `collect` | 收藏 | `collect` |
| `uncollect` | 取消收藏 | `uncollect` |
| `dislike` | 不喜欢 | `dislike` |

**参数说明：**
- `<关键词>`: 搜索关键词（必填）
- `[源]`: 音乐平台代码，可选。常见：`kw`(酷我), `kg`(酷狗), `tx`(腾讯), `wy`(网易), `mg`(咪咕)
- `<歌名>`: 歌曲名称（必填）
- `[歌手]`: 歌手名，可选。传入时格式为 `歌名-歌手`
- `<源>`: 歌单来源平台（必填）
- `<ID>`: 歌单ID或URL（必填）

## 对话示例

### 播放歌曲
```
用户：播放青花瓷
→ 执行: node {skill_dir}/cli/lx-music-cli.js searchPlay 青花瓷
→ 等待 500ms
→ 执行: node {skill_dir}/cli/lx-music-cli.js status
→ 汇报结果
```

### 搜索歌曲
```
用户：搜索周杰伦的歌
→ 执行: node {skill_dir}/cli/lx-music-cli.js search 周杰伦
→ 等待 500ms
→ 执行: node {skill_dir}/cli/lx-music-cli.js status
→ 汇报结果
```

### 播放控制
```
用户：播放
→ 执行: node {skill_dir}/cli/lx-music-cli.js play
→ 等待 500ms
→ 执行: node {skill_dir}/cli/lx-music-cli.js status
→ 汇报结果
```

## 重要提示

1. **每个命令执行后必须查询状态并汇报**
2. **等待 500ms 后再查询** - 确保 LX Music 有时间响应
3. **如果 status 查询无有效反馈** - 提示用户 "API 未启动，请打开 API 功能（设置 → 开放 API → 启用开放 API 服务）"
4. **汇报格式必须使用 Markdown 表格**