#!/usr/bin/env python3
"""
Example usage of Feishu Interactive Cards for Hermes Agent

This script demonstrates how to send interactive cards with buttons
in Feishu using the Hermes framework patterns.
"""

import json
import asyncio


def create_confirmation_card(
    title: str,
    message: str,
    confirm_label: str = "✅ Confirm",
    cancel_label: str = "❌ Cancel",
    template: str = "orange"
) -> dict:
    """
    Create a confirmation card with Confirm/Cancel buttons.

    Args:
        title: Card header title
        message: Main message content
        confirm_label: Text for confirm button
        cancel_label: Text for cancel button
        template: Color template (orange, red, green, blue, wathet)

    Returns:
        Feishu interactive card JSON structure
    """
    return {
        "config": {"wide_screen_mode": True},
        "header": {
            "title": {"content": title, "tag": "plain_text"},
            "template": template
        },
        "elements": [
            {"tag": "markdown", "content": message},
            {
                "tag": "action",
                "actions": [
                    {
                        "tag": "button",
                        "text": {"tag": "plain_text", "content": confirm_label},
                        "type": "primary",
                        "value": {"action": "confirm", "source": "hermes-skill"}
                    },
                    {
                        "tag": "button",
                        "text": {"tag": "plain_text", "content": cancel_label},
                        "type": "danger",
                        "value": {"action": "cancel", "source": "hermes-skill"}
                    }
                ]
            }
        ]
    }


def create_approval_card(
    command: str,
    description: str,
    approval_id: str,
    session_key: str,
    chat_id: str
) -> dict:
    """
    Create an approval card for dangerous command execution.

    Args:
        command: The command to be approved
        description: Human-readable description
        approval_id: Unique ID for this approval
        session_key: Session identifier
        chat_id: Chat/channel ID

    Returns:
        Feishu interactive card JSON structure
    """
    def btn(label: str, action_name: str, btn_type: str = "default") -> dict:
        return {
            "tag": "button",
            "text": {"tag": "plain_text", "content": label},
            "type": btn_type,
            "value": {
                "hermes_action": action_name,
                "approval_id": approval_id,
                "session_key": session_key,
                "chat_id": chat_id
            }
        }

    cmd_preview = command[:3000] + "..." if len(command) > 3000 else command

    return {
        "config": {"wide_screen_mode": True},
        "header": {"title": {"content": "⚠️ Approval Required", "tag": "plain_text"}, "template": "orange"},
        "elements": [
            {
                "tag": "markdown",
                "content": f"```\n{cmd_preview}\n```\n**Reason:** {description}"
            },
            {
                "tag": "action",
                "actions": [
                    btn("Allow Once", "approve_once", "primary"),
                    btn("Allow Session", "approve_session"),
                    btn("Allow Always", "approve_always"),
                    btn("Deny", "deny", "danger")
                ]
            }
        ]
    }


def parse_button_callback(action_value: dict) -> tuple[str, str]:
    """
    Parse button callback data.

    Args:
        action_value: The value dict from button click event

    Returns:
        Tuple of (action_name, approval_id)
    """
    hermes_action = action_value.get("hermes_action", "unknown")
    approval_id = action_value.get("approval_id", "")
    return hermes_action, approval_id


def create_result_card(
    choice: str,
    user_name: str,
    is_deny: bool = False
) -> dict:
    """
    Create a result card showing approval/denial result.

    Args:
        choice: One of "once", "session", "always", "deny"
        user_name: Name of user who took action
        is_deny: True if this is a denial

    Returns:
        Feishu interactive card JSON structure
    """
    labels = {
        "once": "✅ Allowed Once",
        "session": "✅ Allowed for Session",
        "always": "✅ Always Allowed",
        "deny": "❌ Denied"
    }

    icon = "❌" if is_deny else "✅"
    label = labels.get(choice, "Resolved")
    template = "red" if is_deny else "green"

    return {
        "config": {"wide_screen_mode": True},
        "header": {
            "title": {"content": f"{icon} {label}", "tag": "plain_text"},
            "template": template
        },
        "elements": [
            {"tag": "markdown", "content": f"{icon} **{label}** · By: {user_name}"}
        ]
    }


async def send_card_example():
    """
    Example of how to send a card (pseudo-code).
    Replace with actual Hermes adapter implementation.
    """
    card = create_confirmation_card(
        title="⚠️ Confirm Action",
        message="Are you sure you want to proceed?",
        confirm_label="Yes, Proceed",
        cancel_label="No, Cancel"
    )

    print("Card JSON:")
    print(json.dumps(card, indent=2, ensure_ascii=False))

    # In actual Hermes implementation:
    # await adapter._feishu_send_with_retry(
    #     chat_id=chat_id,
    #     msg_type="interactive",
    #     payload=json.dumps(card, ensure_ascii=False)
    # )


if __name__ == "__main__":
    print("Feishu Interactive Cards - Example Usage")
    print("=" * 50)

    # Example 1: Simple confirmation
    print("\n1. Simple Confirmation Card:")
    card1 = create_confirmation_card(
        title="Delete File?",
        message="This action cannot be undone.",
        confirm_label="Delete",
        cancel_label="Keep"
    )
    print(json.dumps(card1, indent=2, ensure_ascii=False))

    # Example 2: Approval card
    print("\n2. Approval Card:")
    card2 = create_approval_card(
        command="rm -rf /dangerous/path",
        description="Deletes all files in directory",
        approval_id="12345",
        session_key="session-abc",
        chat_id="chat-xyz"
    )
    print(json.dumps(card2, indent=2, ensure_ascii=False))

    # Example 3: Result card
    print("\n3. Result Card:")
    card3 = create_result_card(choice="once", user_name="User123")
    print(json.dumps(card3, indent=2, ensure_ascii=False))

    print("\n" + "=" * 50)
    print("Run with: python3 scripts/example.py")