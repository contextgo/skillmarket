# memory-manager SKILL.md

## 概述

memory-manager 是 AI agent 记忆管理工具集，负责将对话记忆从临时日志自动整理为长期记忆。

## 命令参考

| 命令 | 功能 | 用法 |
|------|------|------|
| `log` | 追加今日日志 | `memory_cli.py log "内容"` |
| `search` | 全文搜索（jieba分词） | `memory_cli.py search "关键词"` |
| `recall` | 上下文记忆提取 | `memory_cli.py recall "主题"` |
| `summary` | 近期摘要 | `memory_cli.py summary [天数]` |
| `merge` | 从daily md合并到MEMORY.md | `memory_cli.py merge` |
| `clean` | 归档旧日志 | `memory_cli.py clean [天数]` |
| `bridge` | 跨session恢复摘要 | `memory_cli.py bridge` |
| `list` | 列出所有日志文件 | `memory_cli.py list` |
| `stats` | 记忆库统计 | `memory_cli.py stats` |

## AI Agent 操作规则

### 即时落盘规则（⚠️ L1 — 最高优先级，所有 agent 必须遵守）

**以下场景必须立即调用 `python3 scripts/memory_cli.py log` 追加今日日志：**

1. 🚨 **触发词实时检测**：老板消息包含以下任何关键词 → 立即落盘，不得延迟：
   - 决定 / 确定 / 选型 / 方案 / 确认 / 采用 / 定下来
   - 记住 / 记住了 / 保存记忆 / 下次记得
   - 执行 / 完成 / 部署 / 安装成功 / 上线

2. 📦 **重要操作完成**：安装、部署、配置变更、文件创建/修改 → 完成即 log

3. ⏱️ **15轮强制 checkpoint**：对话 ≥ 15 轮且距上次 log > 5 分钟 → 主动写 checkpoint

4. 🌉 **bridge 专用**：老板说"记忆桥接" → 执行 `bridge` 而非 `log`

### 落盘合规检查（📊 check 命令）

**agent 可随时执行 `python3 scripts/memory_cli.py check` 查看落盘状态：**
- 今日日志最后落盘时间
- MEMORY.md 最后 merge 时间
- bridge 快照新鲜度
- daemon 进程状态
- 综合风险评估（🟢 正常 / 🟡 注意 / 🔴 危险）

**建议：每次重要操作落盘后执行 `check` 确认。**

### 新 Session 启动规则（⚠️ 多 Agent 通用 — 最高优先级）

**此规则对所有使用 memory-manager 的 agent 生效，无需在每个 agent 的配置文件中重复写入。**

**每个 /new 或 /reset 后的新 session 必须：**

1. 检查是否存在上一 session 上下文（bridge 文件 / memory/ 目录近期记录）
2. **主动执行 bridge**：`python3 scripts/memory_cli.py bridge [--workdir <agent_workspace>]`
   - 输出摘要，展示最近话题、未完成任务、关键决策
   - 不得被动等待老板喊"记忆桥接" — agent 必须主动
3. 如果 bridge 返回空（无历史）→ 直接问老板要做什么
4. 如果有未完成任务 → 优先提醒老板是否继续

**为什么：** agent 新 session 无记忆，bridge 是唯一恢复上下文的手段。靠老板手动触发不可靠（多 agent 场景下老板不可能记住每个 agent 的状态）。

### 写入格式规范

- 日志时间戳格式：`## HH:MM 主题`
- 关键决策标记：`🔴` 强调、`✅` 完成、`⚠️` 风险
- 合并到 MEMORY.md 时自动去重（按时间戳 + 内容相似度）

## 守护进程

```bash
# 启动 memory daemon（监听文件变化自动 merge）
python3 ~/.openclaw/workspace/skills/memory-manager/scripts/memory_daemon.py

# 或通过 log_and_merge.sh 包装脚本
bash ~/.openclaw/workspace/skills/memory-manager/scripts/log_and_merge.sh "内容"
```

## Cron 守护

| Job | 频率 | 功能 |
|-----|------|------|
| memory-auto-merge | 每30分钟 | shell直接执行merge（0 AI tokens） |

## 龙影兼容

通过 `--workdir` 指定龙影工作目录即可独立使用：

```bash
python3 memory_cli.py --workdir ~/.openclaw/workspace/longying-workspace bridge
```

## 路径

- 脚本目录：`~/.openclaw/workspace/skills/memory-manager/scripts/`
- 记忆目录：`~/.openclaw/workspace/memory/`
- 长期记忆：`~/.openclaw/workspace/MEMORY.md`
- 桥接快照：`~/.openclaw/workspace/memory/bridge/`
