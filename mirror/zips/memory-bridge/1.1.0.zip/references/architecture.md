# memory-manager 技术架构文档

## 版本

v1.1.0 — 2026-05-03

## 全链路架构

```
┌──────────────────────────────────────────────────────┐
│                    AI Agent (管家/龙影/...)             │
│                                                      │
│  SKILL.md 规则驱动:                                    │
│  L1: 触发词检测 → memory_cli.py log                   │
│  L2: 15轮 checkpoint → memory_cli.py check            │
│  新session: 主动 bridge                              │
└────────────┬─────────────────────────────────────────┘
             │
             ▼
┌──────────────────────────────────────────────────────┐
│              memory_cli.py v1.1.0                     │
│                                                      │
│  10条命令:                                            │
│  log / search / recall / summary / merge / clean      │
│  bridge / list / stats / check                       │
│                                                      │
│  MemoryStore 数据层:                                  │
│  ├── 今日日志 (YYYY-MM-DD.md)                        │
│  ├── MEMORY.md (长期记忆)                             │
│  ├── memory/bridge/ (桥接快照)                       │
│  └── memory/archive/ (归档旧日志)                     │
└────────────┬─────────────────────────────────────────┘
             │
             ▼
┌──────────────────────────────────────────────────────┐
│           memory_daemon.py (launchd 守护)             │
│                                                      │
│  检测 memory/*.md 文件变化                           │
│  → 120秒防抖                                         │
│  → 自动 merge 到 MEMORY.md                           │
│  → 自动 bridge 生成快照                               │
└────────────┬─────────────────────────────────────────┘
             │
             ▼
┌──────────────────────────────────────────────────────┐
│          OpenClaw session-memory hook                 │
│                                                      │
│  触发: /new 或 /reset                                 │
│  → LLM 生成语义 slug 文件名                            │
│  → 保存上一 session 上下文到 memory/                   │
└──────────────────────────────────────────────────────┘
```

## 命令详解

| 命令 | 功能 | 触发方式 |
|------|------|---------|
| `log` | 追加今日日志（去重） | L1 触发词 / agent 主动 |
| `search` | 全文搜索（jieba分词） | 按需 |
| `recall` | 上下文记忆提取 | 按需 |
| `summary` | 近期智能摘要 | 按需 |
| `merge` | 日志 → MEMORY.md | daemon 自动 / 手动 |
| `clean` | 归档旧日志 | cron 每天 3AM |
| `bridge` | 跨session上下文恢复 | 新 session 自动 / 手动 |
| `list` | 日志文件列表 | 按需 |
| `stats` | 记忆库统计 | 按需 |
| `check` | 落盘合规检查 | agent 每 15 轮 / 每次重要操作后 |

## L1 即时落盘规则

**触发词检测（13个关键词）：**

| 类别 | 关键词 |
|------|--------|
| 决策 | 决定、确定、选型、方案、确认、采用、定下来 |
| 记忆 | 记住、记住了、保存记忆、下次记得 |
| 操作 | 执行、完成、部署、安装成功、上线 |

**15轮强制 checkpoint：**
- 对话 ≥ 15 轮且距上次 log > 5 分钟
- 先执行 `check`，🟡/🔴 则立即 `log`

## 新 Session 启动规则

**所有 agent 通用规则（集中写在 SKILL.md）：**

1. /new 或 /reset → session-memory hook 自动保存上一上下文
2. 新 session → agent 主动执行 `bridge`（不得被动等待）
3. bridge 空 → 直接问老板要做什么
4. 有未完成任务 → 提醒老板是否继续

## 多 Agent 兼容

```bash
# 管家（默认）
python3 memory_cli.py bridge

# 龙影
python3 memory_cli.py --workdir ~/.openclaw/workspace/longying-workspace bridge

# 任意 agent
python3 memory_cli.py --workdir <agent_workspace> bridge
```

## launchd 守护配置

```xml
<!-- ~/Library/LaunchAgents/ai.openclaw.memory-daemon.plist -->
RunAtLoad: true     → 开机自启
KeepAlive: true      → 崩溃自动重启
WatchPaths: memory/  → 文件变化触发
ThrottleInterval: 120 → 2分钟防抖
```

## Cron 作业

| Job | 频率 | 功能 |
|-----|------|------|
| memory-auto-merge | 每30分钟 | shell 直接 merge（0 AI tokens） |

## 风险评估体系

`check` 命令输出状态评估：

| 等级 | 含义 | 典型场景 |
|------|------|---------|
| 🟢 正常 | 全链路健康 | 日志 <30分钟 / bridge <60分钟 / daemon 运行 |
| 🟡 注意 | 部分延迟 | 日志 30-60分钟未更新 / bridge 过期 |
| 🔴 危险 | 需要立即处理 | 今日无日志 / daemon 未运行 / 落盘中止 |

## 文件清单

```
skills/memory-manager/
├── SKILL.md                      # Agent 操作规则（单一真相源）
├── README.md                     # 用户文档
├── references/
│   └── architecture.md           # 本文档
└── scripts/
    ├── install.sh                # 一键安装（Python3/pip3/jieba/初始化/验证）
    ├── memory_cli.py             # 核心 CLI (10条命令)
    ├── memory_daemon.py          # 守护进程
    └── log_and_merge.sh          # 日志+合并包装脚本

workspace/
├── MEMORY.md                     # 长期记忆（bridge 摘要注入 BRIDGE_START/END）
└── memory/
    ├── YYYY-MM-DD.md             # 每日日志
    ├── bridge/
    │   └── latest.md             # 最新桥接快照
    └── archive/                  # 归档旧日志
```

## 版本历史

| 版本 | 日期 | 变更 |
|------|------|------|
| 1.0.0 | 2026-05-02 | 初始版本，9条命令 |
| 1.1.0 | 2026-05-03 | +check命令、强化L1/L2规则、重写install.sh、+references/ |
