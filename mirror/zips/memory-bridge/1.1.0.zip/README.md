# memory-manager — 记忆管理工具

> v1.1.0 | 产品级 AI Agent 记忆管理 Skill

## 是什么

轻量级记忆管理 CLI + 守护进程，实现 **写日志 → 自动 merge → bridge 跨 session 恢复** 全链路无人值守。

**10条命令：**
- 📝 **log** — 追加日志（自动去重）
- 🔍 **search** — 全文搜索（jieba分词）
- 🧠 **recall** — 上下文记忆提取
- 📄 **summary** — 智能摘要
- 📥 **merge** — 日志 → MEMORY.md
- 📦 **clean** — 归档旧日志
- 🌉 **bridge** — 跨 session 记忆桥接恢复
- 📋 **list** — 日志文件列表
- 📊 **stats** — 记忆库统计
- ✅ **check** — 落盘合规检查（🟢🟡🔴 风险评估）

## 安装

```bash
bash ~/.openclaw/workspace/skills/memory-manager/scripts/install.sh
# 强制重装: bash install.sh --force
```

依赖：python3.8+ + jieba（可选，自动降级 n-gram）

## 全链路架构

```
AI Agent (SKILL.md 规则驱动)
  ├── L1 触发词检测 → memory_cli.py log
  ├── L2 15轮 checkpoint → memory_cli.py check
  └── 新 session → 主动 bridge

memory_cli.py (核心 CLI, 10条命令)
  ↓
launchd daemon (120秒防抖 → 自动 merge + bridge)
  ↓
OpenClaw session-memory hook (/new 或 /reset 触发)
```

## 使用

```bash
MEM=~/.openclaw/workspace/skills/memory-manager/scripts/memory_cli.py

# ── 日常使用 ──
python3 $MEM log "做了某事"       # 追加日志
python3 $MEM check                  # 落盘状态检查
python3 $MEM bridge                 # 记忆桥接

# ── 按需使用 ──
python3 $MEM search "关键词"        # 搜索
python3 $MEM recall "主题"          # 回忆
python3 $MEM summary 7              # 近7天摘要
python3 $MEM merge                  # 手动合并
python3 $MEM clean 30               # 归档旧日志
python3 $MEM list                   # 文件列表
python3 $MEM stats                  # 统计

# ── 多 Agent ──
python3 $MEM --workdir ~/.openclaw/workspace/longying-workspace bridge
```

## 守护进程

```bash
# launchd 自启 (开机启动 + 崩溃重启)
ls ~/Library/LaunchAgents/ai.openclaw.memory-daemon.plist

# 手动启动
python3 ~/.openclaw/workspace/skills/memory-manager/scripts/memory_daemon.py
```

## Cron 作业

```bash
# 每 30 分钟自动合并 (0 AI tokens)
*/30 * * * * python3 ~/.openclaw/workspace/skills/memory-manager/scripts/memory_cli.py merge
```

## 文档

- **SKILL.md** — AI Agent 操作规则（L1/L2 落盘 + 新 session 启动 + 多 agent 兼容）
- **references/architecture.md** — 完整技术架构文档
- **scripts/install.sh** — 一键安装脚本

## 版本

| 版本 | 日期 | 变更 |
|------|------|------|
| 1.1.0 | 2026-05-03 | +check命令、强化L1/L2、重写install.sh、+references/ |
| 1.0.0 | 2026-05-02 | 初始版本，9条命令 |
