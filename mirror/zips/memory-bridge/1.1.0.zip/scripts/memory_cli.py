#!/usr/bin/env python3
"""
memory_cli.py — memory-manager 核心 CLI 工具
版本: 1.1.0
用法: python3 memory_cli.py <命令> [参数...]

命令:
  log <内容>          — 追加今日日志（自动去重）
  search <关键词>     — 全文搜索所有 memory 文件
  recall <主题>       — 上下文记忆提取（搜索+摘要）
  summary [天数]      — 生成近期智能摘要
  merge              — 扫日志、提取永久信息、更新 MEMORY.md
  clean [天数]        — 归档 N 天前的日志（默认30天）
  bridge             — 跨 session 恢复摘要
  list               — 列出所有日志文件及大小
  stats              — 记忆库统计信息
  check              — 落盘合规检查（日志/MEMORY/bridge/daemon/风险评估）

专属参数:
  --workdir PATH     — 指定工作目录（默认管家 ~/.openclaw/workspace）
  --no-color         — 禁用颜色输出
"""

import sys, os, re, json, argparse
from datetime import datetime, timedelta
from pathlib import Path
from collections import Counter

# ====== 常量 ======
VERSION = "1.0.0"
DEFAULT_WORKDIR = os.path.expanduser("~/.openclaw/workspace")
MEMORY_DIR = "memory"
MEMORY_FILE = "MEMORY.md"
ARCHIVE_DIR = "memory/archive"
MAX_LINES_PER_RESULT = 80

# ====== 中文分词 ======
try:
    import jieba
    HAS_JIEBA = True
except ImportError:
    HAS_JIEBA = False

# ====== 数据层 ======
class MemoryStore:
    """记忆文件管理（所有读写操作封装在此）"""
    
    def __init__(self, workdir=DEFAULT_WORKDIR):
        self.workdir = Path(workdir)
        self.memory_dir = self.workdir / MEMORY_DIR
        self.memory_file = self.workdir / MEMORY_FILE
        self.archive_dir = self.workdir / ARCHIVE_DIR
        self._ensure_dirs()
    
    def _ensure_dirs(self):
        """保证目录存在"""
        self.memory_dir.mkdir(parents=True, exist_ok=True)
        self.archive_dir.mkdir(parents=True, exist_ok=True)
        if not self.memory_file.exists():
            self.memory_file.write_text("# MEMORY.md - Long-term Memory\n\n")
    
    def today_log(self) -> Path:
        """今日日志文件路径"""
        return self.memory_dir / f"{datetime.now().strftime('%Y-%m-%d')}.md"
    
    def log_files(self) -> list[Path]:
        """按日期排序的日志文件列表"""
        files = sorted(
            [f for f in self.memory_dir.glob("*.md") if f.name != MEMORY_FILE],
            reverse=True
        )
        return files
    
    def append_to_log(self, content: str, tag: str = "") -> Path:
        """追加内容到今日日志，自动加时间戳"""
        log_file = self.today_log()
        timestamp = datetime.now().strftime("%H:%M")
        tag_prefix = f"[{tag}] " if tag else ""
        entry = f"\n- **{timestamp}** {tag_prefix}{content}\n"
        
        # 简单去重：最近3条不重复追加
        existing = log_file.read_text() if log_file.exists() else ""
        recent_lines = "\n".join(existing.strip().split("\n")[-6:])
        if content[:30] in recent_lines:
            return log_file  # 视为重复，跳过
        
        with open(log_file, "a") as f:
            f.write(entry)
        return log_file
    
    def search_files(self, keyword: str) -> list[dict]:
        """搜索所有 memory 文件，返回命中列表"""
        results = []
        search_files = [self.memory_file] + self.log_files()
        
        for fp in search_files:
            if not fp.exists():
                continue
            text = fp.read_text()
            lines = text.split("\n")
            for i, line in enumerate(lines):
                if keyword.lower() in line.lower():
                    start = max(0, i - 2)
                    end = min(len(lines), i + 3)
                    results.append({
                        "file": str(fp.relative_to(self.workdir)),
                        "line_num": i + 1,
                        "content": "\n".join(lines[start:end]),
                        "match_line": line.strip()
                    })
        return results
    
    def read_memory(self) -> str:
        """读取 MEMORY.md"""
        return self.memory_file.read_text() if self.memory_file.exists() else ""
    
    def write_memory(self, content: str):
        """写入 MEMORY.md"""
        self.memory_file.write_text(content)
    
    def append_memory(self, section: str):
        """追加章节到 MEMORY.md"""
        current = self.read_memory()
        if section.strip() in current:
            return  # 去重
        with open(self.memory_file, "a") as f:
            f.write(f"\n{section.strip()}\n")
    
    def recent_logs(self, days: int = 7) -> str:
        """获取近 N 天日志合并字符串"""
        cutoff = datetime.now() - timedelta(days=days)
        texts = []
        for fp in self.log_files():
            try:
                date_str = fp.stem
                dt = datetime.strptime(date_str, "%Y-%m-%d")
                if dt >= cutoff:
                    texts.append(f"## {date_str}\n{fp.read_text()}")
            except ValueError:
                continue
        return "\n\n".join(texts)
    
    def archive_old_logs(self, days: int = 30):
        """归档 N 天前的日志"""
        cutoff = datetime.now() - timedelta(days=days)
        archived = []
        for fp in self.log_files():
            try:
                dt = datetime.strptime(fp.stem, "%Y-%m-%d")
                if dt < cutoff:
                    dest = self.archive_dir / fp.name
                    fp.rename(dest)
                    archived.append(fp.name)
            except (ValueError, OSError):
                continue
        return archived

# ====== 分词辅助 ======
def tokenize(text: str) -> list[str]:
    """中文分词，无 jieba 时降级为字符 n-gram"""
    if HAS_JIEBA:
        return list(jieba.cut(text))
    # 降级：2-4 字滑动窗口
    tokens = []
    for n in (2, 3, 4):
        tokens.extend(text[i:i+n] for i in range(len(text)-n+1))
    return tokens

def summary_text(text: str, max_sentences: int = 8) -> str:
    """简单摘要：提取首句 + 关键词句"""
    sentences = re.split(r'[。！？\n]+', text)
    sentences = [s.strip() for s in sentences if len(s.strip()) > 6]
    if len(sentences) <= max_sentences:
        return "\n".join(sentences)
    return "\n".join(sentences[:max_sentences-2]) + "\n..."

# ====== 命令实现 ======
def cmd_log(store: MemoryStore, content: str, tag: str = ""):
    """追加今日日志"""
    fp = store.append_to_log(content, tag)
    print(f"✅ 已追加到 {fp.relative_to(store.workdir)}")
    return fp

def cmd_search(store: MemoryStore, keyword: str, max_results: int = 10):
    """全文搜索"""
    results = store.search_files(keyword)
    if not results:
        print(f"🔍 未找到 '{keyword}'")
        return
    print(f"🔍 搜索 '{keyword}' — 找到 {len(results)} 条命中（显示前 {max_results} 条）：\n")
    for i, r in enumerate(results[:max_results]):
        print(f"{'─'*60}")
        print(f"[{i+1}] 📄 {r['file']} (第{r['line_num']}行)")
        print(f"{r['content']}")
    if len(results) > max_results:
        print(f"\n... 还有 {len(results)-max_results} 条结果")

def cmd_recall(store: MemoryStore, topic: str):
    """上下文提取"""
    print(f"🧠 回忆 '{topic}' ...\n")
    memory_text = store.read_memory()
    recent_text = store.recent_logs(days=3)
    combined = memory_text + "\n" + recent_text
    if topic.lower() in combined.lower():
        lines = [l for l in combined.split("\n") if topic.lower() in l.lower()]
        print("\n".join(lines[:20]))
    else:
        print("未找到相关内容，尝试分词搜索...")
        tokens = tokenize(topic)
        for t in tokens[:5]:
            hits = [l.strip() for l in combined.split("\n") if t in l]
            if hits:
                print(f"\n匹配 '{t}':")
                for h in hits[:5]:
                    print(f"  {h}")

def cmd_summary(store: MemoryStore, days: int = 7):
    """生成摘要"""
    print(f"📝 近{days}天日志摘要：\n")
    recent = store.recent_logs(days)
    if not recent.strip():
        print("暂无日志。")
        return
    print(summary_text(recent, 12))

def cmd_merge(store: MemoryStore):
    """整理入库"""
    print("📥 整理日志 → MEMORY.md ...")
    recent = store.recent_logs(days=7)
    if not recent.strip():
        print("暂无日志，无需合并。")
        return
    # 提取以 - ** 开头的关键句
    key_lines = re.findall(r'- \*\*\d{2}:\d{2}\*\* (.+)', recent)
    if not key_lines:
        print("未找到结构化日志，跳过。")
        return
    current = store.read_memory()
    new_entries = []
    for line in key_lines[-30:]:  # 最多取30条
        if line[:30] not in current:
            new_entries.append(line)
    if new_entries:
        section = f"\n## {datetime.now().strftime('%Y-%m-%d')} — 自动合并\n"
        for e in new_entries:
            section += f"- {e}\n"
        store.append_memory(section)
        print(f"✅ 已合并 {len(new_entries)} 条信息到 MEMORY.md")
    else:
        print("无新信息需要合并。")

def cmd_clean(store: MemoryStore, days: int = 30):
    """归档旧日志"""
    archived = store.archive_old_logs(days)
    if archived:
        print(f"📦 已归档 {len(archived)} 个旧日志到 memory/archive/：")
        for f in archived:
            print(f"  {f}")
    else:
        print("没有需要归档的旧日志。")

def cmd_bridge(store: MemoryStore):
    """跨 session 恢复 — 同时写入 bridge/latest.md 和更新 MEMORY.md 头部桥接块"""
    ts = datetime.now().strftime('%Y-%m-%d %H:%M')
    lines = []
    lines.append("🌉 记忆桥接 — 最近上下文摘要：\n")
    lines.append(f"{'='*60}")
    lines.append(f"🕐 当前时间: {ts}")
    lines.append(f"📁 工作目录: {store.workdir}")
    lines.append(f"{'='*60}\n")

    memory = store.read_memory()
    mem_snippet = ""
    if memory:
        sections = [s for s in memory.split("## ") if s.strip()]
        recent = sections[-3:] if len(sections) > 3 else sections
        mem_snippet = "\n## ".join(recent)[:1200]
        lines.append("【MEMORY.md 最近章节】\n" + mem_snippet)

    lines.append(f"\n{'-'*40}")
    today = store.today_log()
    today_snippet = ""
    if today.exists():
        today_snippet = today.read_text()[:800]
        lines.append(f"【今日日志 ({today.name})】\n{today_snippet}")
    else:
        lines.append("【今日日志】暂无。")

    lines.append(f"\n{'-'*40}")
    log_count = len(store.log_files())
    lines.append(f"📊 总计 {log_count} 个日志文件 | 上次 merge: 检查 MEMORY.md 末尾日期")

    output = "\n".join(lines)
    print(output)

    # === 方案 1：写入 bridge/latest.md ===
    bridge_dir = store.workdir / "memory" / "bridge"
    bridge_dir.mkdir(parents=True, exist_ok=True)
    bridge_file = bridge_dir / "latest.md"
    bridge_file.write_text(f"<!-- 自动生成 @ {ts} -->\n\n{output}\n", encoding="utf-8")

    # === 方案 3：更新 MEMORY.md 头部 BRIDGE 块 ===
    if memory:
        bridge_block = f"""## 🔄 最近上下文 (自动生成 @ {ts})

{mem_snippet[:600]}

### 今日动态
{today_snippet[:400]}

---
"""
        # 查找并替换已有的 BRIDGE_START/BRIDGE_END 块，或插入到开头
        if "<!-- BRIDGE_START -->" in memory:
            import re
            new_memory = re.sub(
                r"<!-- BRIDGE_START -->.*?<!-- BRIDGE_END -->",
                f"<!-- BRIDGE_START -->\n{bridge_block}\n<!-- BRIDGE_END -->",
                memory,
                flags=re.DOTALL
            )
        else:
            # 在第一个 ## 之前插入
            first_h2 = memory.find("## ")
            if first_h2 >= 0:
                new_memory = (memory[:first_h2] +
                             f"<!-- BRIDGE_START -->\n{bridge_block}\n<!-- BRIDGE_END -->\n\n" +
                             memory[first_h2:])
            else:
                new_memory = f"<!-- BRIDGE_START -->\n{bridge_block}\n<!-- BRIDGE_END -->\n\n{memory}"
        store.memory_file.write_text(new_memory, encoding="utf-8")

def cmd_list(store: MemoryStore):
    """列出日志文件"""
    files = store.log_files()
    if not files:
        print("暂无日志文件。")
        return
    print(f"📋 日志文件（{len(files)}个）：")
    for fp in files:
        size = fp.stat().st_size
        mod = datetime.fromtimestamp(fp.stat().st_mtime).strftime("%m-%d %H:%M")
        print(f"  {fp.name}  ({size}B, {mod})")
    print(f"\n📄 MEMORY.md: {store.memory_file.stat().st_size}B" if store.memory_file.exists() else "📄 MEMORY.md: 不存在")

def cmd_stats(store: MemoryStore):
    """统计信息"""
    files = store.log_files()
    total_lines = 0
    total_size = 0
    for fp in files:
        text = fp.read_text()
        total_lines += text.count("\n")
        total_size += fp.stat().st_size
    mem_size = store.memory_file.stat().st_size if store.memory_file.exists() else 0
    print("📊 记忆库统计：")
    print(f"  日志文件: {len(files)} 个")
    print(f"  日志总行数: ~{total_lines}")
    print(f"  日志总大小: {total_size}B")
    print(f"  MEMORY.md: {mem_size}B")
    print(f"  jieba 分词: {'✅ 可用' if HAS_JIEBA else '⚠️ 不可用（降级 n-gram）'}")
def cmd_check(store: MemoryStore):
    """落盘合规检查 — 日志/MEMORY/bridge/daemon/风险评估"""
    log_file = store.today_log()
    now = datetime.now()
    status = []
    
    # 1. 今日日志
    minutes_ago = 999
    if log_file.exists():
        mtime = datetime.fromtimestamp(log_file.stat().st_mtime)
        minutes_ago = int((now - mtime).total_seconds() / 60)
        last_entry = ""
        try:
            lines = log_file.read_text().strip().split("\n")
            for l in reversed(lines):
                if l.startswith("- **"):
                    last_entry = l.strip()
                    break
        except:
            pass
        status.append(f"📄 今日日志: {log_file.name}")
        status.append(f"   最后修改: {mtime.strftime('%H:%M:%S')} ({minutes_ago}分钟前)")
        if last_entry:
            status.append(f"   最新条目: {last_entry[:80]}")
    else:
        status.append("📄 今日日志: ❌ 尚未创建")
    
    # 2. MEMORY.md
    if store.memory_file.exists():
        mem_mtime = datetime.fromtimestamp(store.memory_file.stat().st_mtime)
        mem_minutes = int((now - mem_mtime).total_seconds() / 60)
        status.append(f"📘 MEMORY.md: 最后 merge @ {mem_mtime.strftime('%H:%M:%S')} ({mem_minutes}分钟前)")
    
    # 3. bridge 快照
    bridge_file = store.workdir / "memory" / "bridge" / "latest.md"
    bridge_minutes = 999
    if bridge_file.exists():
        br_mtime = datetime.fromtimestamp(bridge_file.stat().st_mtime)
        bridge_minutes = int((now - br_mtime).total_seconds() / 60)
        status.append(f"🌉 桥接快照: 生成 @ {br_mtime.strftime('%H:%M:%S')} ({bridge_minutes}分钟前)")
    else:
        status.append("🌉 桥接快照: ❌ 不存在")
    
    # 4. daemon 状态
    import subprocess
    try:
        result = subprocess.run(["pgrep", "-f", "memory_daemon.py"], capture_output=True, text=True)
        if result.stdout.strip():
            status.append(f"🛡️ daemon: ✅ 运行中 (PID {result.stdout.strip()})")
        else:
            status.append("🛡️ daemon: ⚠️ 未运行")
    except:
        status.append("🛡️ daemon: ❓ 无法检测")
    
    # 5. 风险评估
    risk = "🟢 正常"
    risk_factors = []
    if not log_file.exists():
        risk = "🔴 危险"
        risk_factors.append("今日无日志")
    else:
        if minutes_ago > 30:
            risk = "🟡 注意"
            risk_factors.append(f"日志 {minutes_ago} 分钟未更新")
        if bridge_minutes > 60:
            if risk == "🟢 正常":
                risk = "🟡 注意"
            risk_factors.append(f"bridge {bridge_minutes} 分钟未更新")
    
    status.append(f"\n状态评估: {risk}")
    if risk_factors:
        for f in risk_factors:
            status.append(f"  → {f}")
    
    print("\n".join(status))

# ====== 主入口 ======
def main():
    parser = argparse.ArgumentParser(
        prog="memory-cli",
        description=f"memory-manager v{VERSION} — AI 记忆管理 CLI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
命令:
  log <内容>          追加今日日志（自动去重）
  search <关键词>     全文搜索
  recall <主题>       上下文提取
  summary [天数]      生成摘要（默认7天）
  merge              整理入库
  clean [天数]        归档旧日志（默认30天）
  bridge             跨session桥接
  list               列出日志文件
  stats              统计信息

示例:
  python3 memory_cli.py log "重要决策: 采用方案B"
  python3 memory_cli.py search "龙影"
  python3 memory_cli.py bridge
  python3 memory_cli.py --workdir ~/longying-workspace stats
        """
    )
    parser.add_argument("command", nargs="?", default="bridge",
                        choices=["log", "search", "recall", "summary", "merge", "clean", "bridge", "list", "stats", "check"],
                        help="执行命令（默认 bridge）")
    parser.add_argument("argument", nargs="?", default="", help="命令参数")
    parser.add_argument("--workdir", "-w", default=DEFAULT_WORKDIR, help="工作目录")
    parser.add_argument("--no-color", action="store_true", help="禁用颜色")
    parser.add_argument("--version", "-V", action="version", version=f"memory-cli v{VERSION}")
    parser.add_argument("--tag", "-t", default="", help="日志标签（配合 log 命令）")

    args = parser.parse_args()
    store = MemoryStore(args.workdir)

    if args.command == "log":
        if not args.argument:
            print("❌ log 命令需要内容参数")
            sys.exit(1)
        cmd_log(store, args.argument, args.tag)
    elif args.command == "search":
        if not args.argument:
            print("❌ search 命令需要关键词")
            sys.exit(1)
        cmd_search(store, args.argument)
    elif args.command == "recall":
        if not args.argument:
            print("❌ recall 命令需要主题")
            sys.exit(1)
        cmd_recall(store, args.argument)
    elif args.command == "summary":
        days = int(args.argument) if args.argument.isdigit() else 7
        cmd_summary(store, days)
    elif args.command == "merge":
        cmd_merge(store)
    elif args.command == "clean":
        days = int(args.argument) if args.argument.isdigit() else 30
        cmd_clean(store, days)
    elif args.command == "bridge":
        cmd_bridge(store)
    elif args.command == "list":
        cmd_list(store)
    elif args.command == "stats":
        cmd_stats(store)
    elif args.command == "check":
        cmd_check(store)

if __name__ == "__main__":
    main()
