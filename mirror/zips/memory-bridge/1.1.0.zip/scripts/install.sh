#!/bin/bash
# memory-manager — 一键安装脚本
# 版本: 1.1.0 | 用法: bash install.sh [--force]
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
FORCE=false
[[ "${1:-}" == "--force" ]] && FORCE=true

echo "╔══════════════════════════════════╗"
echo "║  memory-manager v1.1.0 安装程序  ║"
echo "╚══════════════════════════════════╝"
echo ""

# ── 1. Python3 检查 ──
echo "── [1/5] 检查 Python3 ──"
if command -v python3 &>/dev/null; then
    PY_VER=$(python3 --version 2>&1)
    PY_MAJOR=$(python3 -c 'import sys; print(sys.version_info.minor)')
    echo "  ✅ $PY_VER"
    if [ "$PY_MAJOR" -lt 8 ]; then
        echo "  ❌ 需要 Python 3.8+, 当前版本不满足"
        exit 1
    fi
else
    echo "  ❌ python3 未安装"
    echo "  macOS: brew install python3"
    echo "  Ubuntu: sudo apt install python3"
    exit 1
fi

# ── 2. pip3 检查 ──
echo "── [2/5] 检查 pip3 ──"
PIP_CMD=""
if python3 -m pip --version &>/dev/null; then
    PIP_CMD="python3 -m pip"
    echo "  ✅ pip3 可用"
elif command -v pip3 &>/dev/null; then
    PIP_CMD="pip3"
    echo "  ✅ pip3 可用"
else
    echo "  ⚠️  pip3 未找到，尝试安装..."
    python3 -m ensurepip --upgrade 2>/dev/null && PIP_CMD="python3 -m pip" || {
        echo "  ❌ 无法安装 pip3，请手动安装"
        exit 1
    }
fi

# ── 3. jieba 分词 ──
echo "── [3/5] 安装 jieba 分词 ──"
if python3 -c "import jieba" 2>/dev/null && [ "$FORCE" = false ]; then
    echo "  ✅ jieba 已安装 (跳过)"
else
    $PIP_CMD install jieba -q 2>/dev/null && echo "  ✅ jieba 安装成功" || echo "  ⚠️  jieba 安装失败，搜索将降级为 n-gram"
fi

# ── 4. 目录初始化 ──
echo "── [4/5] 初始化目录结构 ──"
MEMORY_DIR="$HOME/.openclaw/workspace/memory"
BRIDGE_DIR="$MEMORY_DIR/bridge"
ARCHIVE_DIR="$MEMORY_DIR/archive"

mkdir -p "$MEMORY_DIR" "$BRIDGE_DIR" "$ARCHIVE_DIR"

# 初始化 MEMORY.md（如果不存在）
MEMORY_FILE="$HOME/.openclaw/workspace/MEMORY.md"
if [ ! -f "$MEMORY_FILE" ]; then
    echo "# MEMORY.md - Long-term Memory" > "$MEMORY_FILE"
    echo "  ✅ 创建 MEMORY.md"
fi

# 初始化今日日志
TODAY_LOG="$MEMORY_DIR/$(date +%Y-%m-%d).md"
if [ ! -f "$TODAY_LOG" ]; then
    echo "# $(date +%Y-%m-%d) 工作日志" > "$TODAY_LOG"
    echo "  ✅ 创建 $TODAY_LOG"
fi

echo "  ✅ 目录结构就绪"

# ── 5. 功能验证 ──
echo "── [5/5] 功能验证 ──"
python3 "$SCRIPT_DIR/memory_cli.py" check 2>/dev/null || {
    echo "  ❌ 核心脚本验证失败"
    echo "  请检查: python3 $SCRIPT_DIR/memory_cli.py check"
    exit 1
}
echo "  ✅ 核心脚本验证通过"

echo ""
echo "╔══════════════════════════════════╗"
echo "║  ✅ memory-manager v1.1.0 就绪   ║"
echo "╚══════════════════════════════════╝"
echo ""
echo "  快速测试:"
echo "    python3 $SCRIPT_DIR/memory_cli.py check"
echo "    python3 $SCRIPT_DIR/memory_cli.py log \"测试日志\""
echo "    python3 $SCRIPT_DIR/memory_cli.py bridge"
