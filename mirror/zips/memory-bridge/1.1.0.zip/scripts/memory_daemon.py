#!/usr/bin/env python3
"""
memory_daemon.py — 记忆守护进程
监听 memory/ 目录文件变化，自动触发 merge 到 MEMORY.md

原理：
- macOS 用 watchdog (kqueue) 监听 memory/ 目录
- 检测到 daily md 文件被修改后，延迟 2 分钟执行 merge（防抖）
- 零 AI token 消耗，纯文件级操作

用法：
  python3 memory_daemon.py                          # 前台运行
  python3 memory_daemon.py --daemon                 # 后台运行（需配合 screen/tmux）
  python3 memory_daemon.py --workdir /path/to/mem   # 指定记忆目录
"""

import os
import sys
import time
import signal
import subprocess
import argparse
from pathlib import Path

try:
    from watchdog.observers import Observer
    from watchdog.events import FileSystemEventHandler
except ImportError:
    print("❌ 需要安装 watchdog: pip3 install watchdog")
    sys.exit(1)


# ========== 配置 ==========

DEFAULT_WORKSPACE = os.path.expanduser("~/.openclaw/workspace")
MEMORY_CLI = os.path.join(DEFAULT_WORKSPACE, "skills/memory-manager/scripts/memory_cli.py")
DEBOUNCE_SECONDS = 120  # 文件变化后等待 2 分钟再 merge（防抖）
LOG_FILE = os.path.join(DEFAULT_WORKSPACE, "memory/daemon.log")


class MemoryEventHandler(FileSystemEventHandler):
    """监听文件修改事件，防抖触发 merge"""

    def __init__(self, workspace_path, memory_cli_path, debounce_seconds):
        self.workspace = workspace_path
        self.memory_cli = memory_cli_path
        self.debounce = debounce_seconds
        self.last_event_time = 0
        self.pending_merge = False
        self.memory_dir = os.path.join(workspace_path, "memory")

    def on_modified(self, event):
        if event.is_directory:
            return

        src = event.src_path
        # 只监听 memory/ 目录下的 .md 文件
        if not src.startswith(self.memory_dir):
            return
        if not src.endswith('.md'):
            return
        # 忽略 daemon.log 自身
        if src.endswith('daemon.log'):
            return

        now = time.time()
        self.last_event_time = now

        if not self.pending_merge:
            self.pending_merge = True
            self._log(f"🔔 检测到记忆文件变化: {os.path.basename(src)}，{self.debounce}秒后自动 merge")
            # 在独立线程中等待防抖
            import threading
            t = threading.Thread(target=self._debounce_merge, daemon=True)
            t.start()

    def _debounce_merge(self):
        """防抖等待，确认无新变化后才执行 merge"""
        time.sleep(self.debounce)

        # 检查在等待期间是否有新事件
        elapsed = time.time() - self.last_event_time
        if elapsed < self.debounce - 1:
            # 有新事件，重置防抖
            self._log(f"⏳ 有新变化，重置防抖计时")
            return

        # 执行 merge
        self.pending_merge = False
        self._do_merge()

    def _do_merge(self):
        """执行 merge 命令"""
        self._log("🔄 开始合并记忆到 MEMORY.md...")
        try:
            result = subprocess.run(
                ['python3', self.memory_cli, 'merge'],
                capture_output=True,
                text=True,
                timeout=30,
                cwd=self.workspace
            )
            if result.returncode == 0:
                self._log(f"✅ merge 完成: {result.stdout.strip()}")
            else:
                self._log(f"⚠️ merge 返回非零: {result.stderr.strip()}")
        except subprocess.TimeoutExpired:
            self._log("❌ merge 超时")
        except Exception as e:
            self._log(f"❌ merge 异常: {e}")

    def _log(self, msg):
        """写日志到 daemon.log"""
        ts = time.strftime("%Y-%m-%d %H:%M:%S")
        line = f"[{ts}] {msg}\n"
        print(line, end='')
        try:
            with open(LOG_FILE, 'a') as f:
                f.write(line)
        except Exception:
            pass


def start_daemon(workspace_path, foreground=True):
    """启动文件监听守护"""
    memory_dir = os.path.join(workspace_path, "memory")
    os.makedirs(memory_dir, exist_ok=True)

    print(f"🧠 memory-daemon 启动")
    print(f"   监听目录: {memory_dir}")
    print(f"   merge 脚本: {MEMORY_CLI}")
    print(f"   防抖时间: {DEBOUNCE_SECONDS}秒")
    print(f"   日志文件: {LOG_FILE}")
    print(f"   PID: {os.getpid()}")

    if not os.path.exists(MEMORY_CLI):
        print(f"❌ merge 脚本不存在: {MEMORY_CLI}")
        sys.exit(1)

    handler = MemoryEventHandler(workspace_path, MEMORY_CLI, DEBOUNCE_SECONDS)
    observer = Observer()
    observer.schedule(handler, memory_dir, recursive=False)
    observer.start()

    print("✅ 守护进程已启动，按 Ctrl+C 停止")

    # 信号处理
    def shutdown(signum, frame):
        print("\n🛑 正在停止守护进程...")
        observer.stop()
        observer.join()
        print("✅ 已停止")
        sys.exit(0)

    signal.signal(signal.SIGINT, shutdown)
    signal.signal(signal.SIGTERM, shutdown)

    try:
        if foreground:
            observer.join()
        else:
            # 后台模式：detach
            pid = os.fork()
            if pid > 0:
                print(f"🔒 已进入后台，PID: {pid}")
                sys.exit(0)
            # 子进程继续
            observer.join()
    except KeyboardInterrupt:
        shutdown(None, None)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='memory-daemon 记忆守护进程')
    parser.add_argument('--workdir', default=DEFAULT_WORKSPACE,
                        help=f'工作目录 (默认: {DEFAULT_WORKSPACE})')
    parser.add_argument('--daemon', action='store_true',
                        help='后台运行')
    args = parser.parse_args()

    start_daemon(args.workdir, foreground=not args.daemon)
