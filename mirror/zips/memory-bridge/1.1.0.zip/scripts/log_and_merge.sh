#!/bin/bash
# log_and_merge.sh — 统一日志追加 + 合并守护
# 用法: bash log_and_merge.sh "<日志内容>"
# 功能: 1. 追加到今日 daily md   2. 触发 merge 到 MEMORY.md

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
MEMORY_CLI="$SCRIPT_DIR/memory_cli.py"

if [ $# -eq 0 ]; then
    echo "用法: log_and_merge.sh \"<日志内容>\""
    exit 1
fi

CONTENT="$1"

echo "📝 追加日志..."
python3 "$MEMORY_CLI" log "$CONTENT"

echo "🔄 合并到长期记忆..."
python3 "$MEMORY_CLI" merge

echo "✅ log_and_merge 完成"
