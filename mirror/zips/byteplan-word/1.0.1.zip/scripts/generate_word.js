#!/usr/bin/env node
/**
 * 数据分析报告 Word 文档生成脚本（通用模板）
 * 使用 docx 库创建专业 Word 文档
 *
 * 设计原则：
 * - 模板与业务解耦，通过数据配置生成内容
 * - 支持任意维度的数据可视化
 * - 生成包含封面、目录、正文、附录等完整结构
 */

import { Document, Paragraph, TextRun, Table, TableRow, TableCell,
         HeadingLevel, AlignmentType, BorderStyle, WidthType,
         PageBreak, ShadingType, convertInchesToTwip, Packer } from 'docx';
import fs from 'fs';
import path from 'path';

// 颜色配置（十六进制）
const COLORS = {
  primary: '0F172A',
  secondary: '1E293B',
  blue: '3B82F6',
  green: '10B185',
  purple: '8B5CF6',
  red: 'EF4444',
  orange: 'F97316',
  textDark: '0F172A',
  textGray: '64748B',
  white: 'FFFFFF',
  lightGray: 'F1F5F9',
};

// 图表配色循环
const CHART_COLORS = [COLORS.blue, COLORS.green, COLORS.purple, COLORS.orange, COLORS.red];

// ============ 辅助函数 ============

function createTextRun(text, options = {}) {
  const { bold = false, size = 24, color = COLORS.textDark, font = 'Microsoft YaHei' } = options;
  return new TextRun({ text, bold, size, color, font });
}

function createParagraph(text, options = {}) {
  const { heading, alignment = AlignmentType.LEFT, spacing = {}, children } = options;

  const textRuns = children || (text ? [createTextRun(text, options)] : []);

  return new Paragraph({
    heading,
    alignment,
    spacing,
    children: textRuns,
  });
}

// ============ 封面页 ============

function createCoverPage(data) {
  const elements = [];

  // 空行撑开页面
  for (let i = 0; i < 5; i++) {
    elements.push(createParagraph(''));
  }

  // 主标题
  elements.push(createParagraph(data.title || '数据分析报告', {
    alignment: AlignmentType.CENTER,
    bold: true,
    size: 72,
  }));

  // 副标题
  if (data.subtitle) {
    elements.push(createParagraph(data.subtitle, {
      alignment: AlignmentType.CENTER,
      size: 40,
      color: COLORS.textGray,
    }));
  }

  // 空行
  for (let i = 0; i < 4; i++) {
    elements.push(createParagraph(''));
  }

  // 数据周期
  if (data.period) {
    elements.push(createParagraph(`数据周期: ${data.period}`, {
      alignment: AlignmentType.CENTER,
      size: 28,
      color: COLORS.textGray,
    }));
  }

  // 生成时间
  const genTime = new Date().toISOString().slice(0, 10);
  elements.push(createParagraph(`生成时间: ${genTime}`, {
    alignment: AlignmentType.CENTER,
    size: 24,
    color: COLORS.textGray,
  }));

  // 数据来源
  elements.push(createParagraph(`数据来源: ${data.source || 'BytePlan 数据平台'}`, {
    alignment: AlignmentType.CENTER,
    size: 24,
    color: COLORS.textGray,
  }));

  // 分页
  elements.push(new Paragraph({ children: [new PageBreak()] }));

  return elements;
}

// ============ 目录页 ============

function createTocPage(sections) {
  const elements = [];

  elements.push(createParagraph('目录', { heading: HeadingLevel.HEADING_1 }));

  const tocItems = sections || [
    '一、核心指标概览',
    '二、数据分布分析',
    '三、排行与对比',
    '四、趋势与洞察',
    '五、总结与建议',
  ];

  tocItems.forEach(section => {
    elements.push(createParagraph(section, { size: 28 }));
  });

  elements.push(new Paragraph({ children: [new PageBreak()] }));

  return elements;
}

// ============ 执行摘要 ============

function createSummaryPage(summary) {
  const elements = [];

  elements.push(createParagraph('执行摘要', { heading: HeadingLevel.HEADING_1 }));

  const items = summary || ['暂无数据摘要'];

  items.forEach(item => {
    elements.push(createParagraph(`• ${item}`, {
      size: 24,
      color: COLORS.textGray,
    }));
  });

  elements.push(createParagraph(''));

  return elements;
}

// ============ 核心 KPI ============

function createKpiPage(kpis) {
  const elements = [];

  elements.push(createParagraph('核心指标概览', { heading: HeadingLevel.HEADING_1 }));

  const kpiList = kpis || [
    { label: '总数量', value: '0', unit: '' },
    { label: '总金额', value: '0', unit: '' },
    { label: '平均值', value: '0', unit: '' },
    { label: '最大值', value: '0', unit: '' },
  ];

  // 创建 KPI 表格
  const table = new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    rows: [
      // 表头
      new TableRow({
        children: kpiList.map(kpi => new TableCell({
          shading: { fill: COLORS.blue, type: ShadingType.CLEAR, color: COLORS.blue },
          children: [createParagraph(kpi.label || '', {
            alignment: AlignmentType.CENTER,
            bold: true,
            size: 22,
            color: COLORS.white,
          })],
        })),
      }),
      // 数值行
      new TableRow({
        children: kpiList.map(kpi => new TableCell({
          children: [createParagraph(`${kpi.value || ''} ${kpi.unit || ''}`.trim(), {
            alignment: AlignmentType.CENTER,
            bold: true,
            size: 32,
            color: COLORS.blue,
          })],
        })),
      }),
    ],
  });

  elements.push(table);
  elements.push(createParagraph(''));

  return elements;
}

// ============ 柱状图数据 ============

function createBarChartPage(barChart) {
  const elements = [];

  const data = barChart?.data || [];
  if (data.length === 0) return elements;

  elements.push(createParagraph(barChart?.title || '数据分布分析', { heading: HeadingLevel.HEADING_1 }));

  const maxValue = Math.max(...data.map(d => d.value || 0), 1);

  data.forEach(item => {
    const value = item.value || 0;
    const barLength = Math.round(30 * value / maxValue);
    const bar = '█'.repeat(barLength);

    elements.push(createParagraph(`${item.name || ''}: ${bar} ${value}`, {
      size: 22,
    }));
  });

  elements.push(createParagraph(''));

  return elements;
}

// ============ 占比分析 ============

function createRatioPage(ratioData) {
  const elements = [];

  const data = ratioData?.data || [];
  if (data.length === 0) return elements;

  elements.push(createParagraph(ratioData?.title || '占比分析', { heading: HeadingLevel.HEADING_1 }));

  const total = data.reduce((sum, d) => sum + (d.value || 0), 0);

  data.forEach((item, i) => {
    const value = item.value || 0;
    const ratio = total > 0 ? (value / total * 100) : 0;
    const barLength = Math.round(30 * ratio / 100);
    const bar = '█'.repeat(barLength) + '░'.repeat(30 - barLength);

    elements.push(createParagraph(`${item.name || ''}: ${bar} ${ratio.toFixed(1)}%`, {
      size: 22,
      color: CHART_COLORS[i % CHART_COLORS.length],
    }));
  });

  elements.push(createParagraph(''));

  return elements;
}

// ============ 排行分析 ============

function createRankingPage(rankingData) {
  const elements = [];

  const data = rankingData?.data || [];
  if (data.length === 0) return elements;

  elements.push(createParagraph(rankingData?.title || '排行分析', { heading: HeadingLevel.HEADING_1 }));

  const maxItems = rankingData?.maxItems || 10;
  const sortedData = [...data].sort((a, b) => (b.value || 0) - (a.value || 0)).slice(0, maxItems);
  const maxValue = Math.max(...sortedData.map(d => d.value || 0), 1);

  sortedData.forEach((item, i) => {
    const value = item.value || 0;
    const barLength = Math.round(30 * value / maxValue);
    const bar = '█'.repeat(barLength);

    elements.push(createParagraph(`${i + 1}. ${item.name || ''}: ${bar} ${value}`, {
      size: 22,
    }));
  });

  elements.push(createParagraph(''));

  return elements;
}

// ============ 数据表格 ============

function createTablePage(tableData) {
  const elements = [];

  const rows = tableData?.rows || [];
  if (rows.length === 0) return elements;

  elements.push(createParagraph(tableData?.title || '数据明细', { heading: HeadingLevel.HEADING_1 }));

  const columns = tableData?.columns || Object.keys(rows[0] || {}).map(k => ({ key: k, label: k }));
  const maxRows = tableData?.maxRows || 20;
  const displayRows = rows.slice(0, maxRows);

  const table = new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    rows: [
      // 表头
      new TableRow({
        children: columns.map(col => new TableCell({
          shading: { fill: COLORS.blue, type: ShadingType.CLEAR, color: COLORS.blue },
          children: [createParagraph(col.label || col.key || '', {
            bold: true,
            size: 20,
            color: COLORS.white,
          })],
        })),
      }),
      // 数据行
      ...displayRows.map((rowData, rowIdx) => new TableRow({
        children: columns.map(col => {
          const value = rowData[col.key] ?? '';
          const displayValue = typeof value === 'number' ? value.toFixed(2) : String(value);
          const isEven = rowIdx % 2 === 0;

          return new TableCell({
            shading: isEven ? { fill: COLORS.lightGray, type: ShadingType.CLEAR, color: COLORS.lightGray } : undefined,
            children: [createParagraph(displayValue, {
              size: 20,
              color: COLORS.textGray,
            })],
          });
        }),
      })),
    ],
  });

  elements.push(table);
  elements.push(createParagraph(''));

  return elements;
}

// ============ 洞察发现 ============

function createInsightPage(insights) {
  const elements = [];

  elements.push(createParagraph('关键洞察', { heading: HeadingLevel.HEADING_1 }));

  const items = insights || [
    { title: '数据特征', content: '本期数据整体表现稳定，呈现上升趋势' },
    { title: '异常发现', content: '部分维度存在显著差异，需关注' },
  ];

  items.forEach((item, i) => {
    elements.push(createParagraph(`${i + 1}. ${item.title || ''}`, {
      heading: HeadingLevel.HEADING_2,
      color: COLORS.blue,
    }));

    elements.push(createParagraph(item.content || '', {
      size: 24,
      color: COLORS.textGray,
    }));
  });

  elements.push(createParagraph(''));

  return elements;
}

// ============ 建议措施 ============

function createRecommendationPage(recommendations) {
  const elements = [];

  elements.push(createParagraph('总结与建议', { heading: HeadingLevel.HEADING_1 }));

  const items = recommendations || [
    { title: '短期建议', content: '持续关注数据变化，及时调整策略' },
    { title: '长期规划', content: '建立数据驱动决策机制' },
  ];

  items.forEach((item, i) => {
    elements.push(createParagraph(`${i + 1}. ${item.title || ''}`, {
      heading: HeadingLevel.HEADING_2,
      color: COLORS.green,
    }));

    elements.push(createParagraph(item.content || '', {
      size: 24,
      color: COLORS.textGray,
    }));
  });

  elements.push(createParagraph(''));

  return elements;
}

// ============ 附录 ============

function createAppendixPage(appendix) {
  const elements = [];

  if (!appendix || Object.keys(appendix).length === 0) return elements;

  elements.push(createParagraph('附录：补充数据', { heading: HeadingLevel.HEADING_1 }));

  Object.entries(appendix).forEach(([key, value]) => {
    elements.push(createParagraph('', {
      children: [
        createTextRun(`${key}: `, { bold: true, size: 24 }),
        createTextRun(String(value), { size: 24, color: COLORS.textGray }),
      ],
    }));
  });

  elements.push(new Paragraph({ children: [new PageBreak()] }));

  return elements;
}

// ============ 结尾页 ============

function createEndingPage(source) {
  const elements = [];

  for (let i = 0; i < 6; i++) {
    elements.push(createParagraph(''));
  }

  elements.push(createParagraph('— 报告结束 —', {
    alignment: AlignmentType.CENTER,
    bold: true,
    size: 32,
  }));

  for (let i = 0; i < 2; i++) {
    elements.push(createParagraph(''));
  }

  elements.push(createParagraph(`数据来源: ${source || 'BytePlan 数据平台'}`, {
    alignment: AlignmentType.CENTER,
    size: 24,
    color: COLORS.textGray,
  }));

  const genTime = new Date().toISOString().slice(0, 10);
  elements.push(createParagraph(`生成时间: ${genTime}`, {
    alignment: AlignmentType.CENTER,
    size: 22,
    color: COLORS.textGray,
  }));

  return elements;
}

// ============ 主函数 ============

function generateWord(outputFile, dataFile = null) {
  // 加载数据
  let data = {};

  if (dataFile) {
    const filePath = path.resolve(dataFile);
    if (fs.existsSync(filePath)) {
      data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
    }
  } else {
    const defaultPath = path.resolve('word_data.json');
    if (fs.existsSync(defaultPath)) {
      data = JSON.parse(fs.readFileSync(defaultPath, 'utf-8'));
    }
  }

  // 创建文档
  const doc = new Document({
    sections: [{
      properties: {},
      children: [
        // 1. 封面
        ...createCoverPage(data),

        // 2. 目录
        ...createTocPage(data.sections),

        // 3. 执行摘要
        ...createSummaryPage(data.summary),

        // 4. 核心 KPI
        ...createKpiPage(data.kpis),

        // 5. 柱状图数据
        ...createBarChartPage(data.barChart),

        // 6. 占比分析
        ...createRatioPage(data.ratioData),

        // 7. 排行分析
        ...createRankingPage(data.rankingData),

        // 8. 数据明细表
        ...createTablePage(data.tableData),

        // 9. 关键洞察
        ...createInsightPage(data.insights),

        // 10. 总结与建议
        ...createRecommendationPage(data.recommendations),

        // 11. 附录
        ...createAppendixPage(data.appendix),

        // 12. 结尾页
        ...createEndingPage(data.source),
      ],
    }],
  });

  // 保存
  Packer.toBuffer(doc).then(buffer => {
    fs.writeFileSync(outputFile, buffer);
    console.log(`Successfully generated Word document -> ${outputFile}`);
  });
}

// CLI 入口
const args = process.argv.slice(2);
let outputFile = 'analysis-report.docx';
let dataFile = null;

for (let i = 0; i < args.length; i++) {
  if (args[i] === '-o' || args[i] === '--output-file') {
    outputFile = args[++i];
  } else if (args[i] === '-d' || args[i] === '--data-file') {
    dataFile = args[++i];
  }
}

generateWord(outputFile, dataFile);