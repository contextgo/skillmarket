---
name: byteplan-word
description: 根据已有的分析数据（analysisPlan.json + analysis_report.md）生成 Word 报告。需要先使用 byteplan-analysis skill 完成数据分析。
---

# BytePlan Word 报告 Skill

## 概述

此 Skill 根据已有的分析数据生成 Word 报告：

1. **检查数据** - 确认 analysisPlan.json 和 analysis_report.md 存在
2. **组装数据** - 将分析数据转换为 Word 格式
3. **生成 Word** - 使用 docx 库创建 Word 文档

**前置条件**：必须先使用 [byteplan-analysis](../byteplan-analysis/SKILL.md) skill 完成数据分析。

## 技术栈

使用 Node.js + docx 库，与项目其他 skill 保持一致：
- `docx` - Word 文档生成库

## 核心流程

```
用户输入"生成 Word"
       ↓
   检查分析数据是否存在
       ↓
   读取 analysisPlan.json
       ↓
   读取 analysis_report.md
       ↓
   组装报告数据
       ↓
   pnpm run generate
       ↓
   完成
```

## 前置条件

### 安装依赖

```bash
cd skills/byteplan-word
pnpm install
```

### 检查分析数据

```javascript
import { existsSync, readFileSync } from 'fs';

// 检查必要文件
if (!existsSync('analysisPlan.json')) {
  throw new Error('缺少分析计划文件 analysisPlan.json，请先使用 /byteplan-analysis');
}

if (!existsSync('analysis_report.md')) {
  throw new Error('缺少分析报告文件 analysis_report.md，请先使用 /byteplan-analysis');
}

console.log('✅ 分析数据检查通过');
```

## 工作流程

### 步骤 1：读取分析计划

```javascript
const plan = JSON.parse(readFileSync('analysisPlan.json', 'utf-8'));

console.log(`计划名称: ${plan.planName}`);
console.log(`任务数量: ${plan.tasks.length}`);
```

### 步骤 2：读取分析报告

```javascript
const reportMd = readFileSync('analysis_report.md', 'utf-8');

// 解析 Markdown 中的表格数据
const parsedData = parseMarkdownReport(reportMd);
```

### 步骤 3：组装 Word 数据

根据分析计划中的任务，组装 Word 支持的数据格式：

```javascript
const wordData = {
  title: plan.planName,
  subtitle: plan.planDescription,
  period: new Date().toLocaleDateString('zh-CN'),
  sections: plan.tasks.map(t => t.taskName),
  summary: extractSummary(parsedData),
  kpis: extractKPIs(parsedData),
  tables: extractTables(parsedData),
  insights: extractInsights(parsedData),
  recommendations: extractRecommendations(parsedData),
  source: 'BytePlan 数据平台'
};
```

### 步骤 4：生成 Word

```bash
cd skills/byteplan-word
pnpm run generate -- -o analysis_report.docx -d word_data.json
```

## Word 数据格式

```json
{
  "title": "报告标题",
  "subtitle": "副标题",
  "period": "2026年3月",
  "sections": ["一、核心指标概览", "二、数据分布分析"],
  "summary": ["摘要1", "摘要2"],
  "kpis": [
    { "label": "指标名称", "value": "数值", "unit": "单位" }
  ],
  "barChart": {
    "title": "图表标题",
    "data": [
      { "name": "类别A", "value": 100 },
      { "name": "类别B", "value": 80 }
    ]
  },
  "ratioData": {
    "title": "占比标题",
    "data": [
      { "name": "类别A", "value": 35 },
      { "name": "类别B", "value": 28 }
    ]
  },
  "rankingData": {
    "title": "排行标题",
    "data": [
      { "name": "项目A", "value": 100 },
      { "name": "项目B", "value": 85 }
    ],
    "maxItems": 10
  },
  "tableData": {
    "title": "明细表",
    "columns": [
      { "key": "字段1", "label": "显示名" }
    ],
    "rows": [
      { "字段1": "值1", "字段2": "值2" }
    ],
    "maxRows": 20
  },
  "insights": [
    { "title": "关键发现", "content": "内容" }
  ],
  "recommendations": [
    { "title": "建议", "content": "内容" }
  ],
  "appendix": {
    "说明": "补充内容"
  },
  "source": "BytePlan 数据平台"
}
```

## Word 文档结构

| 章节 | 内容 | 说明 |
|-----|------|------|
| 1 | 封面 | 报告标题、副标题、数据周期 |
| 2 | 目录 | 报告结构概览 |
| 3 | 执行摘要 | 核心发现汇总 |
| 4 | 核心指标 | 关键数据表格 |
| 5 | 数据分布 | 柱状图数据 |
| 6 | 占比分析 | 进度条形式 |
| 7 | 排行分析 | 排名列表 |
| 8 | 数据明细 | 数据表格 |
| 9 | 洞察发现 | 关键洞察 |
| 10 | 总结建议 | 结论和建议 |
| 11 | 附录 | 补充数据（可选） |
| 12 | 结尾页 | 报告结束 |

## 完整示例

### 1. 检查数据文件

```javascript
if (!existsSync('analysisPlan.json') || !existsSync('analysis_report.md')) {
  console.log('请先使用 /byteplan-analysis 完成数据分析');
  return;
}
```

### 2. 读取并组装数据

```javascript
const plan = JSON.parse(readFileSync('analysisPlan.json', 'utf-8'));
const report = readFileSync('analysis_report.md', 'utf-8');

// 从 Markdown 中提取数据
const data = extractDataFromMarkdown(report);

// 组装 Word 数据
const wordData = {
  title: plan.planName,
  subtitle: `分析主题: ${plan.planDescription}`,
  period: new Date().toLocaleDateString('zh-CN'),
  kpis: extractKPIs(data),
  tables: extractTables(data),
  insights: extractInsights(data),
  // ...
};

writeFileSync('word_data.json', JSON.stringify(wordData, null, 2));
```

### 3. 生成 Word

```bash
cd skills/byteplan-word
pnpm run generate -- -o analysis_report.docx -d ../word_data.json
```

## 注意事项

- **前置条件**：必须先使用 `/byteplan-analysis` 完成数据分析
- **数据文件**：确保 `analysisPlan.json` 和 `analysis_report.md` 存在
- **数据转换**：自动从 Markdown 中提取表格和关键数据
- **包管理器**：使用 pnpm 安装依赖