#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
park-viz 生成器
将 buildings.csv + tenants.csv 转换为 2.5D 白模楼宇交互可视化 HTML

用法:
  python generate_park.py \
    --buildings buildings.csv \
    --tenants tenants.csv \
    --park-name "智慧产业园区" \
    --work-label "调研" \
    --output output.html
"""

import argparse
import csv
import json
import os
import sys
import io

# ─────────────────────────────────────────────
# CSV 解析
# ─────────────────────────────────────────────

def parse_bool(val):
    return str(val).strip().lower() in ("是", "true", "1", "y", "yes", "完成", "已完成")

def parse_floors(val):
    """解析楼层字段，支持 '3,4' 或 '3' 或 '3-5' 等"""
    floors = []
    for part in str(val).replace("，", ",").split(","):
        part = part.strip()
        if "-" in part:
            try:
                a, b = part.split("-")
                floors.extend(range(int(a), int(b)+1))
            except:
                pass
        else:
            try:
                floors.append(int(part))
            except:
                pass
    return sorted(set(floors))

def load_csv_from_string(content):
    content = content.strip()
    if content.startswith("\ufeff"):
        content = content[1:]  # 去除 BOM
    return list(csv.DictReader(io.StringIO(content)))

def load_buildings(path_or_json):
    """加载建筑数据，返回列表"""
    if path_or_json.startswith("json:"):
        rows = json.loads(path_or_json[5:])
    else:
        with open(path_or_json, encoding="utf-8-sig") as f:
            content = f.read()
        rows = load_csv_from_string(content)

    buildings = []
    for row in rows:
        # 兼容中英文字段名
        bid   = row.get("楼宇编号") or row.get("id") or str(len(buildings)+1)
        name  = row.get("楼宇名称") or row.get("name") or f"楼宇{bid}"
        floors= int(row.get("楼层数") or row.get("floors") or 8)
        area  = row.get("功能区域") or row.get("area") or ""
        buildings.append({
            "id": int(bid),
            "name": name,
            "floors": floors,
            "area": area,
            "tenants": []
        })
    return buildings

def load_tenants(path_or_json, buildings):
    """加载企业数据，填入 buildings[].tenants"""
    if path_or_json.startswith("json:"):
        rows = json.loads(path_or_json[5:])
    else:
        with open(path_or_json, encoding="utf-8-sig") as f:
            content = f.read()
        rows = load_csv_from_string(content)

    bmap = {b["id"]: b for b in buildings}
    for row in rows:
        bid       = int(row.get("楼宇编号") or row.get("building_id") or 0)
        name      = row.get("企业名称") or row.get("name") or ""
        floors_s  = row.get("所在楼层") or row.get("floors") or "1"
        done      = parse_bool(row.get("是否完成") or row.get("done") or "否")
        tag       = row.get("企业类型") or row.get("type") or ""
        if bid in bmap and name:
            bmap[bid]["tenants"].append({
                "name": name,
                "type": tag,
                "floors": parse_floors(floors_s),
                "done": done
            })

def calc_layout(buildings):
    """根据楼栋数量计算行列布局，给每栋楼赋 cx/cy"""
    n = len(buildings)
    if n <= 3:
        rows = [n]
    elif n <= 6:
        rows = [3, n-3] if n > 3 else [n]
    elif n <= 9:
        r1 = (n+2)//3
        r2 = (n - r1 + 1)//2
        r3 = n - r1 - r2
        rows = [r for r in [r1, r2, r3] if r > 0]
    else:
        # 超过 9 栋，4行
        q, rem = divmod(n, 4)
        rows = [q + (1 if i < rem else 0) for i in range(4)]

    GAP_X = 280
    GAP_Y = 300
    START_X = 0
    START_Y = 0

    idx = 0
    for row_i, cols in enumerate(rows):
        row_width = cols * GAP_X
        offset_x = -row_width / 2 + GAP_X / 2
        for col in range(cols):
            if idx < len(buildings):
                buildings[idx]["cx"] = START_X + offset_x + col * GAP_X
                buildings[idx]["cy"] = START_Y + row_i * GAP_Y
            idx += 1

# ─────────────────────────────────────────────
# HTML 模板生成
# ─────────────────────────────────────────────

def buildings_to_js(buildings):
    """将 buildings 列表序列化为 JS 对象字面量"""
    lines = ["const buildings = ["]
    for b in buildings:
        surveyed = sum(1 for t in b["tenants"] if t["done"])
        tenants_js = []
        for t in b["tenants"]:
            floors_js = json.dumps(t["floors"])
            done_js = "true" if t["done"] else "false"
            typ = t.get("type","").replace('"', '\\"')
            nm  = t["name"].replace('"', '\\"')
            tenants_js.append(
                f'    {{ name: "{nm}", type: "{typ}", floors: {floors_js}, done: {done_js} }}'
            )
        tenants_str = ",\n".join(tenants_js)
        lines.append(
            f'  {{ id: {b["id"]}, name: "{b["name"]}", floors: {b["floors"]}, '
            f'area: "{b["area"]}", surveyed: {surveyed}, tenants: [\n{tenants_str}\n  ]}},'
        )
    lines.append("];")
    return "\n".join(lines)


HTML_TEMPLATE = r"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{{PARK_NAME}} - 2.5D 白模楼宇可视化</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', sans-serif;
    background: #dde3ec; color: #1e293b;
    min-height: 100vh; display: flex; flex-direction: column; overflow: hidden;
  }
  header {
    background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
    border-bottom: 1px solid #334155;
    padding: 10px 32px;
    display: flex; align-items: center; justify-content: space-between;
    flex-shrink: 0;
  }
  .header-left { display: flex; align-items: center; gap: 14px; }
  .header-logo {
    width: 34px; height: 34px;
    background: linear-gradient(135deg, #94a3b8, #cbd5e1);
    border-radius: 8px; display: flex; align-items: center; justify-content: center;
    font-size: 17px;
  }
  .header-title h1 { font-size: 15px; font-weight: 700; color: #f1f5f9; }
  .header-title p  { font-size: 10px; color: #64748b; margin-top: 1px; }
  .header-stats { display: flex; gap: 8px; }
  .stat-card {
    background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.12);
    border-radius: 8px; padding: 5px 14px; text-align: center; min-width: 62px;
  }
  .stat-card .num   { font-size: 18px; font-weight: 800; color: #f1f5f9; }
  .stat-card .label { font-size: 9px; color: #94a3b8; margin-top: 1px; }
  .stat-card.accent { border-color: rgba(245,158,11,0.3); background: rgba(245,158,11,0.1); }
  .stat-card.accent .num { color: #fbbf24; }
  .main { display: flex; flex: 1; overflow: hidden; }
  .canvas-view {
    flex: 1; position: relative; overflow: hidden;
    background: linear-gradient(180deg, #c8d0de 0%, #dde3ec 30%, #e8edf5 100%);
  }
  #parkCanvas { position: absolute; inset: 0; width: 100%; height: 100%; }
  .tooltip {
    position: absolute; background: rgba(15,23,42,0.95);
    border: 1px solid #475569; border-radius: 10px;
    padding: 12px 16px; pointer-events: none; opacity: 0;
    transition: opacity 0.15s; min-width: 200px;
    box-shadow: 0 8px 30px rgba(0,0,0,0.25);
    backdrop-filter: blur(8px); z-index: 100;
  }
  .tooltip.show { opacity: 1; }
  .tooltip-header {
    display: flex; align-items: center; justify-content: space-between;
    margin-bottom: 8px; padding-bottom: 8px; border-bottom: 1px solid #334155;
  }
  .tooltip-name { font-size: 13px; font-weight: 700; color: #f1f5f9; }
  .tooltip-badge {
    font-size: 10px; font-weight: 700; padding: 3px 9px; border-radius: 20px;
    background: #f59e0b; color: #fff;
  }
  .tooltip-badge.done { background: #22c55e; }
  .tooltip-row {
    display: flex; justify-content: space-between; align-items: center;
    font-size: 11px; margin-top: 4px;
  }
  .tooltip-row .key { color: #94a3b8; }
  .tooltip-row .val { color: #f1f5f9; font-weight: 600; }
  .park-legend {
    position: absolute; bottom: 14px; left: 14px;
    background: rgba(255,255,255,0.95); border: 1px solid #cbd5e1;
    border-radius: 10px; padding: 10px 14px; box-shadow: 0 4px 20px rgba(0,0,0,0.1);
  }
  .park-legend-title {
    font-size: 9px; color: #64748b; text-transform: uppercase;
    letter-spacing: 1px; margin-bottom: 6px; font-weight: 700;
  }
  .legend-row {
    display: flex; align-items: center; gap: 7px;
    font-size: 10px; color: #475569; margin-bottom: 3px;
  }
  .legend-swatch {
    width: 13px; height: 13px; border-radius: 3px; border: 1px solid rgba(0,0,0,0.1);
  }
  .detail-panel {
    width: 320px; background: #fff;
    border-left: 1px solid #e2e8f0;
    display: flex; flex-direction: column; overflow: hidden; flex-shrink: 0;
  }
  .detail-header {
    padding: 14px 16px; border-bottom: 1px solid #e2e8f0;
    background: linear-gradient(135deg, #f8fafc, #f1f5f9);
  }
  .detail-header h2 { font-size: 14px; font-weight: 700; color: #1e293b; }
  .detail-subtitle {
    font-size: 10px; color: #64748b; margin-top: 3px;
    display: flex; align-items: center; gap: 6px;
  }
  .area-badge {
    display: inline-block; font-size: 10px; padding: 1px 7px;
    border-radius: 20px; background: #e2e8f0; color: #475569;
  }
  .work-badge-detail {
    display: inline-flex; align-items: center; gap: 3px;
    font-size: 10px; padding: 1px 7px; border-radius: 20px;
    background: rgba(245,158,11,0.1); color: #f59e0b;
    border: 1px solid rgba(245,158,11,0.2);
  }
  .work-badge-detail.done {
    background: rgba(34,197,94,0.1); color: #22c55e; border-color: rgba(34,197,94,0.2);
  }
  .detail-content {
    flex: 1; overflow-y: auto; padding: 12px 16px; background: #f8fafc;
  }
  .detail-content::-webkit-scrollbar { width: 4px; }
  .detail-content::-webkit-scrollbar-track { background: #f1f5f9; }
  .detail-content::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 2px; }
  .detail-content { scrollbar-width: thin; scrollbar-color: #cbd5e1 #f1f5f9; }
  .stats-grid {
    display: grid; grid-template-columns: repeat(4, 1fr); gap: 5px; margin-bottom: 12px;
  }
  .stat-item {
    background: #fff; border: 1px solid #e2e8f0;
    border-radius: 8px; padding: 7px 5px; text-align: center;
  }
  .stat-item .val { font-size: 17px; font-weight: 800; color: #1e293b; }
  .stat-item .lbl { font-size: 8px; color: #94a3b8; margin-top: 2px; text-transform: uppercase; }
  .work-card {
    background: #fff; border: 1px solid #e2e8f0;
    border-radius: 10px; padding: 10px; margin-bottom: 12px;
  }
  .work-card-header {
    display: flex; justify-content: space-between; align-items: center; margin-bottom: 7px;
  }
  .work-card-title { font-size: 11px; font-weight: 700; color: #1e293b; }
  .work-card-num   { font-size: 12px; font-weight: 800; color: #f59e0b; }
  .work-bar-bg   { height: 5px; background: #e2e8f0; border-radius: 3px; overflow: hidden; }
  .work-bar-fill {
    height: 100%; background: linear-gradient(90deg, #f59e0b, #f97316);
    border-radius: 3px; transition: width 0.6s ease;
  }
  .work-bar-fill.done { background: linear-gradient(90deg, #22c55e, #10b981); }
  .section-title {
    font-size: 9px; color: #64748b; text-transform: uppercase;
    letter-spacing: 1px; margin: 12px 0 7px;
    display: flex; align-items: center; gap: 7px;
  }
  .section-title::after { content: ''; flex: 1; height: 1px; background: #e2e8f0; }
  .floor-grid {
    display: grid; grid-template-columns: repeat(auto-fill, minmax(26px, 1fr)); gap: 3px;
  }
  .floor-cell {
    aspect-ratio: 1; border-radius: 4px;
    display: flex; align-items: center; justify-content: center;
    font-size: 9px; font-weight: 700;
    background: #e2e8f0; color: #94a3b8;
  }
  .floor-cell.occupied { background: #22c55e; color: #fff; }
  .floor-cell.occupied.done { background: linear-gradient(135deg,#22c55e,#10b981); }
  .floor-cell.occupied.pending { background: #64748b; }
  .company-list { display: flex; flex-direction: column; gap: 5px; }
  .company-item {
    background: #fff; border: 1px solid #e2e8f0;
    border-radius: 8px; padding: 9px 11px;
    border-left: 3px solid #22c55e;
  }
  .company-item.pending { border-left-color: #cbd5e1; }
  .company-name { font-size: 12px; font-weight: 600; color: #1e293b; }
  .company-tags { display: flex; gap: 5px; margin-top: 4px; flex-wrap: wrap; }
  .company-tag {
    font-size: 9px; padding: 1px 6px; border-radius: 4px; background: #e2e8f0; color: #475569;
  }
  .company-tag.done    { background: rgba(34,197,94,0.1); color: #22c55e; }
  .company-tag.pending { background: rgba(100,116,139,0.1); color: #64748b; }
  .company-tag.floor   { background: rgba(59,130,246,0.1); color: #3b82f6; }
  .empty-state { text-align: center; padding: 50px 20px; color: #94a3b8; }
  .empty-state .es-icon { font-size: 40px; margin-bottom: 12px; }
  .empty-state p { font-size: 12px; line-height: 1.6; }
  @keyframes fadeIn { from{opacity:0;transform:translateY(8px)} to{opacity:1;transform:translateY(0)} }
  .detail-content > * { animation: fadeIn 0.3s ease both; }
</style>
</head>
<body>

<header>
  <div class="header-left">
    <div class="header-logo">🏢</div>
    <div class="header-title">
      <h1>{{PARK_NAME}}</h1>
      <p>2.5D 白模楼宇可视化</p>
    </div>
  </div>
  <div class="header-stats" id="headerStats"></div>
</header>

<div class="main">
  <div class="canvas-view" id="canvasView">
    <canvas id="parkCanvas"></canvas>
    <div class="park-legend">
      <div class="park-legend-title">图例</div>
      <div class="legend-row">
        <div class="legend-swatch" style="background:linear-gradient(135deg,#22c55e,#10b981)"></div>
        <span>已入驻 + 已{{WORK_LABEL}}</span>
      </div>
      <div class="legend-row">
        <div class="legend-swatch" style="background:#64748b"></div>
        <span>已入驻（待{{WORK_LABEL}}）</span>
      </div>
      <div class="legend-row">
        <div class="legend-swatch" style="background:#e2e8f0;border-color:#cbd5e1"></div>
        <span>空置楼层</span>
      </div>
    </div>
    <div class="tooltip" id="tooltip">
      <div class="tooltip-header">
        <span class="tooltip-name" id="tipName"></span>
        <span class="tooltip-badge" id="tipBadge"></span>
      </div>
      <div class="tooltip-row"><span class="key">功能区域</span><span class="val" id="tipArea"></span></div>
      <div class="tooltip-row"><span class="key">楼层总数</span><span class="val" id="tipFloors"></span></div>
      <div class="tooltip-row"><span class="key">入驻企业</span><span class="val" id="tipTenants"></span></div>
    </div>
  </div>

  <div class="detail-panel">
    <div class="detail-header">
      <h2 id="detailTitle">选择楼宇</h2>
      <div class="detail-subtitle" id="detailSubtitle">点击左侧白模楼宇查看详情</div>
    </div>
    <div class="detail-content" id="detailContent">
      <div class="empty-state">
        <div class="es-icon">🏗️</div>
        <p>点击园区内任意白模楼宇<br>查看企业入驻与{{WORK_LABEL}}详情</p>
      </div>
    </div>
  </div>
</div>

<script>
const WORK_LABEL = "{{WORK_LABEL}}";

{{BUILDINGS_JS}}

// 自动计算布局坐标
(function calcLayout() {
  const n = buildings.length;
  let rows;
  if (n <= 3)      rows = [n];
  else if (n <= 6) rows = [Math.ceil(n/2), Math.floor(n/2)];
  else if (n <= 9) { const r1=Math.ceil(n/3),r2=Math.ceil((n-r1)/2),r3=n-r1-r2; rows=[r1,r2,r3].filter(r=>r>0); }
  else { const q=Math.floor(n/4),rem=n%4; rows=Array.from({length:4},(_,i)=>q+(i<rem?1:0)).filter(r=>r>0); }

  const GAP_X=280, GAP_Y=300;
  let idx=0;
  for(let ri=0;ri<rows.length;ri++){
    const cols=rows[ri];
    const ox = -cols*GAP_X/2+GAP_X/2;
    for(let ci=0;ci<cols;ci++){
      if(idx<buildings.length){
        buildings[idx].cx = ox + ci*GAP_X;
        buildings[idx].cy = ri*GAP_Y;
      }
      idx++;
    }
  }
})();

// 统计
const totalFloors   = buildings.reduce((s,b)=>s+b.floors,0);
const totalTenants  = buildings.reduce((s,b)=>s+b.tenants.length,0);
const totalDone     = buildings.reduce((s,b)=>s+b.surveyed,0);
const occupiedRmsAll= buildings.reduce((s,b)=>s+b.tenants.reduce((a,t)=>a+t.floors.length,0),0);
const occupancy     = (occupiedRmsAll/totalFloors*100).toFixed(1);
const doneRate      = totalTenants>0?(totalDone/totalTenants*100).toFixed(1):"0.0";

document.getElementById('headerStats').innerHTML = `
  <div class="stat-card"><div class="num">${buildings.length}</div><div class="label">楼宇</div></div>
  <div class="stat-card"><div class="num">${totalFloors}</div><div class="label">总楼层</div></div>
  <div class="stat-card"><div class="num">${totalTenants}</div><div class="label">入驻企业</div></div>
  <div class="stat-card accent"><div class="num">${totalDone}</div><div class="label">已${WORK_LABEL}</div></div>
  <div class="stat-card"><div class="num">${occupancy}%</div><div class="label">入驻率</div></div>
  <div class="stat-card accent"><div class="num">${doneRate}%</div><div class="label">${WORK_LABEL}率</div></div>
`;

// ===== 2.5D 渲染 =====
const ISO_X=0.55, ISO_Y=0.45, FLOOR_H=12, BASE_W=160, BASE_D=110;
const WHITE_TOP='#f8fafc', WHITE_FRONT='#e2e8f0', WHITE_RIGHT='#cbd5e1', WHITE_EDGE='#94a3b8';

let canvas, ctx, hoveredId=null, selectedId=null;

function toIso(x,y){ return { sx: x*ISO_X - y*ISO_X, sy: x*ISO_Y + y*ISO_Y }; }

function drawBuilding(b, highlight) {
  const h=b.floors*FLOOR_H, w=BASE_W, d=BASE_D, cx=b.cx, cy=b.cy;
  const p0=toIso(cx-w/2,cy),   p1=toIso(cx+w/2,cy);
  const p2=toIso(cx+w/2,cy-d), p3=toIso(cx-w/2,cy-d);
  const p4={sx:p0.sx,sy:p0.sy-h}, p5={sx:p1.sx,sy:p1.sy-h};
  const p6={sx:p2.sx,sy:p2.sy-h}, p7={sx:p3.sx,sy:p3.sy-h};

  ctx.save();
  ctx.shadowColor = highlight ? 'rgba(0,0,0,0.25)' : 'rgba(0,0,0,0.1)';
  ctx.shadowBlur  = highlight ? 30 : 15;
  ctx.shadowOffsetY = highlight ? 15 : 8;

  // 顶面
  ctx.fillStyle = highlight ? '#ffffff' : WHITE_TOP;
  ctx.beginPath(); ctx.moveTo(p4.sx,p4.sy); ctx.lineTo(p5.sx,p5.sy);
  ctx.lineTo(p6.sx,p6.sy); ctx.lineTo(p7.sx,p7.sy); ctx.closePath(); ctx.fill();

  // 顶面网格
  ctx.strokeStyle='rgba(148,163,184,0.25)'; ctx.lineWidth=0.5;
  for(let i=1;i<5;i++){
    const t=i/5;
    ctx.beginPath();
    ctx.moveTo(p4.sx+(p7.sx-p4.sx)*t, p4.sy+(p7.sy-p4.sy)*t);
    ctx.lineTo(p5.sx+(p6.sx-p5.sx)*t, p5.sy+(p6.sy-p5.sy)*t); ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(p4.sx+(p5.sx-p4.sx)*t, p4.sy+(p5.sy-p4.sy)*t);
    ctx.lineTo(p7.sx+(p6.sx-p7.sx)*t, p7.sy+(p6.sy-p7.sy)*t); ctx.stroke();
  }

  // 前面 + 右面
  ctx.fillStyle=WHITE_FRONT;
  ctx.beginPath(); ctx.moveTo(p0.sx,p0.sy); ctx.lineTo(p1.sx,p1.sy);
  ctx.lineTo(p5.sx,p5.sy); ctx.lineTo(p4.sx,p4.sy); ctx.closePath(); ctx.fill();
  ctx.fillStyle=WHITE_RIGHT;
  ctx.beginPath(); ctx.moveTo(p1.sx,p1.sy); ctx.lineTo(p2.sx,p2.sy);
  ctx.lineTo(p6.sx,p6.sy); ctx.lineTo(p5.sx,p5.sy); ctx.closePath(); ctx.fill();

  // 楼层横线
  ctx.strokeStyle = highlight ? WHITE_EDGE : 'rgba(148,163,184,0.45)';
  ctx.lineWidth   = highlight ? 1 : 0.5;
  for(let f=1;f<b.floors;f++){
    const t=f/b.floors;
    const lx=p0.sx+(p4.sx-p0.sx)*t, ly=p0.sy+(p4.sy-p0.sy)*t;
    const rx=p1.sx+(p5.sx-p1.sx)*t, ry=p1.sy+(p5.sy-p1.sy)*t;
    ctx.beginPath(); ctx.moveTo(lx,ly); ctx.lineTo(rx,ry); ctx.stroke();
    const rsx=p1.sx+(p2.sx-p1.sx)*(1-t), rsx2=p5.sx+(p6.sx-p5.sx)*(1-t);
    ctx.beginPath(); ctx.moveTo(rsx,ly); ctx.lineTo(rsx2,ry); ctx.stroke();
  }

  // 入驻楼层填色 + 窗户
  const occupiedSet = new Set(b.tenants.flatMap(t=>t.floors));
  for(let f=0;f<b.floors;f++){
    const floorNum=b.floors-f;
    if(!occupiedSet.has(floorNum)) continue;
    const tenant=b.tenants.find(t=>t.floors.includes(floorNum));
    if(!tenant) continue;
    const tT=f/b.floors, tB=(f+1)/b.floors;
    const tl={sx:p0.sx+(p4.sx-p0.sx)*tT, sy:p0.sy+(p4.sy-p0.sy)*tT};
    const tr={sx:p1.sx+(p5.sx-p1.sx)*tT, sy:p1.sy+(p5.sy-p1.sy)*tT};
    const bl={sx:p0.sx+(p4.sx-p0.sx)*tB, sy:p0.sy+(p4.sy-p0.sy)*tB};
    const br={sx:p1.sx+(p5.sx-p1.sx)*tB, sy:p1.sy+(p5.sy-p1.sy)*tB};

    ctx.fillStyle = tenant.done ? 'rgba(34,197,94,0.88)' : 'rgba(100,116,139,0.88)';
    ctx.beginPath(); ctx.moveTo(tl.sx,tl.sy); ctx.lineTo(tr.sx,tr.sy);
    ctx.lineTo(br.sx,br.sy); ctx.lineTo(bl.sx,bl.sy); ctx.closePath(); ctx.fill();

    // 窗户
    const wc=7,ww=10,wh=6,wgx=7;
    const waW=wc*ww+(wc-1)*wgx;
    const wsx=(tl.sx+tr.sx)/2-waW/2;
    const wy=(tl.sy+bl.sy)/2-wh/2;
    ctx.fillStyle=tenant.done?'rgba(255,255,255,0.95)':'rgba(255,255,255,0.55)';
    for(let c=0;c<wc;c++) ctx.fillRect(wsx+c*(ww+wgx),wy,ww,wh);

    // 右面窗户
    const rwc=5, rwaW=rwc*ww+(rwc-1)*wgx;
    const rsx=(tr.sx+br.sx)/2-rwaW/2;
    ctx.fillStyle=tenant.done?'rgba(255,255,255,0.8)':'rgba(255,255,255,0.35)';
    for(let c=0;c<rwc;c++) ctx.fillRect(rsx+c*(ww+wgx),wy,ww,wh);
  }

  // 轮廓线
  ctx.shadowBlur=0; ctx.shadowOffsetY=0;
  ctx.strokeStyle = highlight ? '#475569' : 'rgba(148,163,184,0.55)';
  ctx.lineWidth   = highlight ? 1.5 : 0.8;

  // 顶面轮廓
  ctx.beginPath(); ctx.moveTo(p4.sx,p4.sy); ctx.lineTo(p5.sx,p5.sy);
  ctx.lineTo(p6.sx,p6.sy); ctx.lineTo(p7.sx,p7.sy); ctx.closePath(); ctx.stroke();
  // 前面轮廓
  ctx.beginPath(); ctx.moveTo(p0.sx,p0.sy); ctx.lineTo(p1.sx,p1.sy);
  ctx.lineTo(p5.sx,p5.sy); ctx.lineTo(p4.sx,p4.sy); ctx.closePath(); ctx.stroke();
  // 右面轮廓
  ctx.beginPath(); ctx.moveTo(p1.sx,p1.sy); ctx.lineTo(p2.sx,p2.sy);
  ctx.lineTo(p6.sx,p6.sy); ctx.lineTo(p5.sx,p5.sy); ctx.closePath(); ctx.stroke();
  // 竖向棱线
  ctx.beginPath();
  ctx.moveTo(p0.sx,p0.sy); ctx.lineTo(p4.sx,p4.sy);
  ctx.moveTo(p1.sx,p1.sy); ctx.lineTo(p5.sx,p5.sy);
  ctx.moveTo(p2.sx,p2.sy); ctx.lineTo(p6.sx,p6.sy);
  ctx.moveTo(p3.sx,p3.sy); ctx.lineTo(p7.sx,p7.sy);
  ctx.stroke();

  ctx.restore();

  // 工作进度徽章（楼顶）
  const bp = toIso(cx, cy-d/2);
  const bx=bp.sx, by=bp.sy-h-16;
  ctx.fillStyle = b.surveyed===b.tenants.length ? '#22c55e' : '#f59e0b';
  ctx.beginPath(); ctx.arc(bx,by,16,0,Math.PI*2); ctx.fill();
  ctx.fillStyle='#fff'; ctx.font='bold 11px Segoe UI,sans-serif';
  ctx.textAlign='center'; ctx.textBaseline='middle';
  ctx.fillText(`${b.surveyed}/${b.tenants.length}`, bx, by);

  // 名称标签（底部）
  const lx=(p0.sx+p1.sx)/2, ly=p0.sy+16;
  ctx.fillStyle='rgba(15,23,42,0.92)'; ctx.font='bold 12px Segoe UI,sans-serif';
  const lw=ctx.measureText(b.name).width+16;
  ctx.fillRect(lx-lw/2, ly-7, lw, 20);
  ctx.fillStyle='#f1f5f9'; ctx.textAlign='center'; ctx.textBaseline='middle';
  ctx.fillText(b.name, lx, ly+3);
}

function getCenter() {
  const xs=buildings.map(b=>b.cx), ys=buildings.map(b=>b.cy);
  const mn=Math.min, mx=Math.max;
  const corners=[toIso(mn(...xs),mn(...ys)),toIso(mx(...xs),mn(...ys)),
                 toIso(mn(...xs),mx(...ys)),toIso(mx(...xs),mx(...ys))];
  return {
    cx:(mn(...corners.map(c=>c.sx))+mx(...corners.map(c=>c.sx)))/2,
    cy:(mn(...corners.map(c=>c.sy))+mx(...corners.map(c=>c.sy)))/2
  };
}

function render() {
  if(!canvas) return;
  ctx.clearRect(0,0,canvas.width,canvas.height);

  const {cx:bcx,cy:bcy}=getCenter();
  const ox=canvas.width/2-bcx, oy=canvas.height/2-bcy;
  ctx.save(); ctx.translate(ox,oy);

  // 等轴网格
  const xs=buildings.map(b=>b.cx), ys=buildings.map(b=>b.cy);
  const gMinX=Math.min(...xs)-400, gMaxX=Math.max(...xs)+400;
  const gMinY=Math.min(...ys)-300, gMaxY=Math.max(...ys)+300;
  const gs=80;
  ctx.strokeStyle='rgba(180,190,210,0.35)'; ctx.lineWidth=0.5;
  for(let gx=Math.floor(gMinX/gs)*gs; gx<=gMaxX; gx+=gs){
    const a=toIso(gx,gMinY), b=toIso(gx,gMaxY);
    ctx.beginPath(); ctx.moveTo(a.sx,a.sy); ctx.lineTo(b.sx,b.sy); ctx.stroke();
  }
  for(let gy=Math.floor(gMinY/gs)*gs; gy<=gMaxY; gy+=gs){
    const a=toIso(gMinX,gy), b=toIso(gMaxX,gy);
    ctx.beginPath(); ctx.moveTo(a.sx,a.sy); ctx.lineTo(b.sx,b.sy); ctx.stroke();
  }

  const sorted=[...buildings].sort((a,b)=>(a.cx+a.cy)-(b.cx+b.cy));
  sorted.forEach(b=>drawBuilding(b, b.id===hoveredId||b.id===selectedId));
  ctx.restore();
}

function hitTest(mx,my) {
  const {cx:bcx,cy:bcy}=getCenter();
  const ox=canvas.width/2-bcx, oy=canvas.height/2-bcy;
  const ax=mx-ox, ay=my-oy;
  for(let i=buildings.length-1;i>=0;i--){
    const b=buildings[i];
    const h=b.floors*FLOOR_H, w=BASE_W, d=BASE_D;
    const p0=toIso(b.cx-w/2,b.cy), p1=toIso(b.cx+w/2,b.cy);
    const p7=toIso(b.cx-w/2,b.cy-d);
    const p4={sx:p0.sx,sy:p0.sy-h};
    const mnX=Math.min(p0.sx,p1.sx,toIso(b.cx+w/2,b.cy-d).sx,p7.sx);
    const mxX=Math.max(p0.sx,p1.sx,toIso(b.cx+w/2,b.cy-d).sx,p7.sx);
    if(ax>=mnX&&ax<=mxX&&ay>=Math.min(p7.sy,p4.sy)&&ay<=p0.sy) return b.id;
  }
  return null;
}

function getMousePos(e){
  const r=canvas.getBoundingClientRect();
  return {x:(e.clientX-r.left)*(canvas.width/r.width), y:(e.clientY-r.top)*(canvas.height/r.height)};
}

function showTooltip(e,id){
  const b=buildings.find(b=>b.id===id); if(!b) return;
  document.getElementById('tipName').textContent=b.name;
  document.getElementById('tipArea').textContent=b.area;
  document.getElementById('tipFloors').textContent=b.floors+'层';
  document.getElementById('tipTenants').textContent=b.tenants.length+'家';
  const el=document.getElementById('tipBadge');
  if(b.surveyed===b.tenants.length){
    el.textContent=`✓ ${WORK_LABEL}完成`; el.className='tooltip-badge done';
  } else {
    el.textContent=`已${WORK_LABEL} ${b.surveyed}/${b.tenants.length}`; el.className='tooltip-badge';
  }
  const vp=document.getElementById('canvasView');
  const r=vp.getBoundingClientRect();
  const tip=document.getElementById('tooltip');
  tip.style.left=(e.clientX-r.left+15)+'px';
  tip.style.top=(e.clientY-r.top-10)+'px';
  tip.classList.add('show');
}
function hideTooltip(){ document.getElementById('tooltip').classList.remove('show'); }

function selectBuilding(id){
  const b=buildings.find(b=>b.id===id); if(!b) return;
  const done=b.tenants.filter(t=>t.done).length;
  const doneRate=((done/b.tenants.length)*100).toFixed(0);
  const occ=b.tenants.reduce((a,t)=>a+t.floors.length,0);

  document.getElementById('detailTitle').textContent=b.name;
  document.getElementById('detailSubtitle').innerHTML=`
    <span class="area-badge">${b.area}</span>
    <span class="work-badge-detail ${done===b.tenants.length?'done':''}">
      ${done===b.tenants.length?'✓ ':''}已${WORK_LABEL} ${done}/${b.tenants.length} 家
    </span>`;

  let fh='<div class="floor-grid">';
  for(let f=b.floors;f>=1;f--){
    const t=b.tenants.find(t=>t.floors.includes(f));
    let cls='floor-cell'; if(t){ cls+=' occupied'; cls+=t.done?' done':' pending'; }
    fh+=`<div class="${cls}" title="${f}F${t?' '+t.name:' 空置'}"><span>${f}</span></div>`;
  }
  fh+='</div>';

  const th=b.tenants.map(t=>`
    <div class="company-item ${t.done?'':'pending'}">
      <div class="company-name">${t.name}</div>
      <div class="company-tags">
        <span class="company-tag floor">${t.floors.join('F / ')}F</span>
        ${t.type?`<span class="company-tag">${t.type}</span>`:''}
        <span class="company-tag ${t.done?'done':'pending'}">${t.done?'✓ 已'+WORK_LABEL:'待'+WORK_LABEL}</span>
      </div>
    </div>`).join('');

  document.getElementById('detailContent').innerHTML=`
    <div class="work-card">
      <div class="work-card-header">
        <span class="work-card-title">📊 企业${WORK_LABEL}进度</span>
        <span class="work-card-num">${done} / ${b.tenants.length} 家</span>
      </div>
      <div class="work-bar-bg">
        <div class="work-bar-fill ${done===b.tenants.length?'done':''}" style="width:${doneRate}%"></div>
      </div>
    </div>
    <div class="stats-grid">
      <div class="stat-item"><div class="val">${b.floors}</div><div class="lbl">总楼层</div></div>
      <div class="stat-item"><div class="val" style="color:#22c55e">${occ}</div><div class="lbl">已入驻</div></div>
      <div class="stat-item"><div class="val" style="color:#f59e0b">${done}</div><div class="lbl">已${WORK_LABEL}</div></div>
      <div class="stat-item"><div class="val" style="color:#94a3b8">${b.floors-occ}</div><div class="lbl">空置</div></div>
    </div>
    <div class="section-title">📋 楼层入驻情况</div>${fh}
    <div class="section-title">🏢 入驻企业（${b.tenants.length}家）</div>
    <div class="company-list">${th}</div>`;
}

function initCanvas(){
  canvas=document.getElementById('parkCanvas'); ctx=canvas.getContext('2d');
  const vp=document.getElementById('canvasView');
  canvas.width=vp.clientWidth; canvas.height=vp.clientHeight;
  render();
  canvas.addEventListener('mousemove',e=>{
    const pos=getMousePos(e), id=hitTest(pos.x,pos.y);
    if(id!==hoveredId){ hoveredId=id; canvas.style.cursor=id?'pointer':'default'; render(); }
    if(id) showTooltip(e,id); else hideTooltip();
  });
  canvas.addEventListener('mouseleave',()=>{ hoveredId=null; hideTooltip(); render(); });
  canvas.addEventListener('click',e=>{
    const pos=getMousePos(e), id=hitTest(pos.x,pos.y);
    if(id){ selectedId=id; render(); selectBuilding(id); }
  });
  window.addEventListener('resize',()=>{
    canvas.width=vp.clientWidth; canvas.height=vp.clientHeight; render();
  });
}

window.addEventListener('load',()=>{ initCanvas(); setTimeout(()=>selectBuilding(buildings[0].id),300); });
</script>
</body>
</html>
"""


def generate_html(buildings, park_name="智慧产业园区", work_label="调研"):
    js = buildings_to_js(buildings)
    html = HTML_TEMPLATE
    html = html.replace("{{PARK_NAME}}", park_name)
    html = html.replace("{{WORK_LABEL}}", work_label)
    html = html.replace("{{BUILDINGS_JS}}", js)
    return html


# ─────────────────────────────────────────────
# CLI 入口
# ─────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="产业园区 2.5D 可视化生成器")
    parser.add_argument("--buildings", required=True, help="建筑 CSV 文件路径或 json:... 格式")
    parser.add_argument("--tenants",   required=True, help="企业 CSV 文件路径或 json:... 格式")
    parser.add_argument("--park-name", default="智慧产业园区", help="园区名称")
    parser.add_argument("--work-label", default="调研", help="工作项名称（调研/拜访/签约等）")
    parser.add_argument("--output",    required=True, help="输出 HTML 文件路径")
    args = parser.parse_args()

    buildings = load_buildings(args.buildings)
    load_tenants(args.tenants, buildings)
    calc_layout(buildings)
    html = generate_html(buildings, park_name=args.park_name, work_label=args.work_label)

    out_dir = os.path.dirname(os.path.abspath(args.output))
    os.makedirs(out_dir, exist_ok=True)
    with open(args.output, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"Generated: {args.output}")
    print(f"Buildings: {len(buildings)}, Tenants: {sum(len(b['tenants']) for b in buildings)}")


if __name__ == "__main__":
    main()
