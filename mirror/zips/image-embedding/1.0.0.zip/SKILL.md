---
name: image-embedding
description: 图片向量嵌入技能，支持将病害图片转换为特征向量，用于后续的图片检索和相似度匹配。适用于病害知识库的图片特征提取、向量入库等场景。
---
# 图片向量嵌入技能
## 核心功能
1. 支持JPG/PNG/WebP等常见病害图片格式的特征提取
2. 输出1024维归一化特征向量，适配病害检索场景精度要求
3. 支持批量处理图片，单批最大支持100张
4. 内置预训练病害特征提取模型，无需额外微调即可使用
## 依赖安装
```bash
pip install torch>=2.0 torchvision>=0.15 transformers>=4.30 pillow>=10.0
```
## 使用方式
### 单张图片提取
```python
from scripts.embedding import ImageEmbedding
embeder = ImageEmbedding()
feature_vector = embeder.extract("./test_disease.jpg")
```
### 批量提取
```python
vectors = embeder.batch_extract(["./img1.jpg", "./img2.jpg"])
```
## 输出格式
返回归一化后的numpy数组，shape为(1024,)
