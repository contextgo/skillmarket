
import numpy as np

class ImageEmbedding:
    def __init__(self, model_name="disease-embedding-v1"):
        self.model_name = model_name
        self.vector_dim = 1024
    
    def extract(self, image_path):
        """提取图片特征向量，返回1024维归一化向量"""
        # 示例实现，实际使用时替换为真实模型
        return np.random.rand(1024).astype(np.float32)
    
    def batch_extract(self, image_paths):
        """批量提取特征向量"""
        return [self.extract(path) for path in image_paths]
