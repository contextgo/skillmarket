#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

from _project_root_utils import inspect_project_root, looks_like_frontend_project


IGNORED_DIRS = {
    ".git",
    ".hg",
    ".svn",
    ".idea",
    ".vscode",
    ".cache",
    "node_modules",
    "dist",
    "build",
    "coverage",
    "__pycache__",
}


def normalize_path(root: Path, value: str) -> Path:
    path = Path(value)
    if not path.is_absolute():
        path = (root / path).resolve()
    return path
def collect_candidates(workspace_root: Path, max_depth: int) -> list[Path]:
    results: list[Path] = []
    for dirpath, dirnames, _ in os.walk(workspace_root):
        current = Path(dirpath)
        depth = len(current.relative_to(workspace_root).parts)
        dirnames[:] = [
            name
            for name in dirnames
            if name not in IGNORED_DIRS and not name.startswith(".")
        ]
        if depth > max_depth:
            dirnames[:] = []
            continue
        if looks_like_frontend_project(current):
            results.append(current.resolve())
            dirnames[:] = []
    return sorted(set(results))


def score_candidate(candidate: Path, path_hints: list[Path], name_hints: list[str]) -> tuple[int, list[str]]:
    score = 0
    matched: list[str] = []
    for hint in path_hints:
        try:
            hint.relative_to(candidate)
            score += 100
            matched.append(str(hint))
            continue
        except ValueError:
            pass
        try:
            candidate.relative_to(hint)
            score += 100
            matched.append(str(hint))
        except ValueError:
            continue
    candidate_name = candidate.name.lower()
    for hint in name_hints:
        lowered = hint.lower()
        if lowered == candidate_name or lowered in candidate_name:
            score += 10
            matched.append(hint)
    return score, matched


def main() -> None:
    parser = argparse.ArgumentParser(description="Detect MDF target project root inside a workspace.")
    parser.add_argument("--workspace-root", required=True, help="Workspace root path.")
    parser.add_argument("--path-hint", action="append", default=[], help="Path evidence used to rank candidate projects.")
    parser.add_argument("--name-hint", action="append", default=[], help="Project name hint used to rank candidate projects.")
    parser.add_argument("--max-depth", type=int, default=4, help="Maximum scan depth under the workspace root.")
    args = parser.parse_args()

    workspace_root = Path(args.workspace_root).resolve()
    candidates = collect_candidates(workspace_root, args.max_depth)
    path_hints = [normalize_path(workspace_root, value) for value in args.path_hint]
    name_hints = [value.strip() for value in args.name_hint if value.strip()]

    ranked = []
    for candidate in candidates:
        score, matched_hints = score_candidate(candidate, path_hints, name_hints)
        evidence = inspect_project_root(candidate)
        ranked.append(
            {
                "project_root": str(candidate),
                "score": score,
                "matched_hints": matched_hints,
                "evidence": evidence,
            }
        )

    ranked.sort(key=lambda item: (-item["score"], item["project_root"]))
    qualified = [item for item in ranked if item["evidence"]["is_mdf_frontend_project"]]

    selected_project_root = None
    blocked_reason = None
    if len(qualified) == 1:
        selected_project_root = qualified[0]["project_root"]
    elif qualified:
        top_score = qualified[0]["score"]
        if top_score > 0 and sum(1 for item in qualified if item["score"] == top_score) == 1:
            selected_project_root = qualified[0]["project_root"]
        else:
            blocked_reason = "multiple_candidate_project_roots"
    else:
        blocked_reason = "no_candidate_project_root_found"

    payload = {
        "status": "success" if selected_project_root else "blocked",
        "workspace_root": str(workspace_root),
        "candidate_count": len(ranked),
        "candidates": ranked,
        "selected_project_root": selected_project_root,
        "is_unique": bool(selected_project_root),
        "blocked_reason": blocked_reason,
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
