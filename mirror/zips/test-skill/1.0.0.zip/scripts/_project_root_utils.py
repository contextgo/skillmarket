from __future__ import annotations

from pathlib import Path
import xml.etree.ElementTree as ET


def looks_like_frontend_project(project_root: Path) -> bool:
    return (
        (project_root / "package.json").is_file()
        and (project_root / "module.xml").is_file()
        and (project_root / "src").is_dir()
    )


def inspect_project_root(project_root: Path) -> dict[str, object]:
    module_xml_path = project_root / "module.xml"
    evidence: dict[str, object] = {
        "package_json": str(project_root / "package.json"),
        "module_xml": str(module_xml_path),
        "src_dir": str(project_root / "src"),
        "looks_like_frontend_project": looks_like_frontend_project(project_root),
        "nginx_mode": None,
        "is_mdf_frontend_project": False,
        "qualification_reason": None,
        "rejection_reason": None,
    }

    if not evidence["looks_like_frontend_project"]:
        evidence["rejection_reason"] = "frontend_project_markers_missing"
        return evidence

    try:
        root = ET.parse(module_xml_path).getroot()
    except ET.ParseError:
        evidence["rejection_reason"] = "module_xml_parse_error"
        return evidence

    nginx_mode_node = root.find("nginx_mode")
    if nginx_mode_node is None:
        evidence["rejection_reason"] = "nginx_mode_missing"
        return evidence

    nginx_mode = (nginx_mode_node.text or "").strip().lower()
    if not nginx_mode:
        evidence["rejection_reason"] = "nginx_mode_missing"
        return evidence

    evidence["nginx_mode"] = nginx_mode
    if nginx_mode == "mdf":
        evidence["is_mdf_frontend_project"] = True
        evidence["qualification_reason"] = "nginx_mode_is_mdf"
        return evidence

    evidence["rejection_reason"] = f"nginx_mode_is_{nginx_mode}"
    return evidence
