"""
双驱三维归一记忆系统 - L0 Watcher
===================================
L0 原始层实时监听器

功能：
1. 监听 OpenClaw .jsonl 文件变动
2. 实时追加到 L0 存档 .md
3. 达到 4MB 阈值时分离 2MB 到历史文件
4. 自动触发 L1/L2/L3 分类处理

触发规则：
- 阈值：4MB
- 分离大小：2MB
- 冷却：3 次检查
"""

import os
import sys
import json
import time
import logging
import subprocess
from datetime import datetime
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

# 路径配置
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    from paths_config import (
        WORKSPACE, MEMORY_DIR, MEMORY_SESSIONS,
        L0_SIZE_LIMIT, SEPARATE_SIZE,
        get_all_agent_sessions, find_openclaw_json
    )
except ImportError:
    print("[WARN] paths_config not found, using defaults")
    WORKSPACE = "/root/.openclaw/workspace/main"
    MEMORY_DIR = os.path.join(WORKSPACE, "memory")
    MEMORY_SESSIONS = os.path.join(MEMORY_DIR, "sessions")
    L0_SIZE_LIMIT = 4 * 1024 * 1024  # 4MB
    SEPARATE_SIZE = 2 * 1024 * 1024  # 2MB
    def get_all_agent_sessions():
        return [{'id': 'main', 'sessions_dir': '/root/.openclaw/agents/main/sessions'}]
    def find_openclaw_json():
        return "/root/.openclaw/openclaw.json"

os.makedirs(MEMORY_SESSIONS, exist_ok=True)

# 日志配置
LOG_FILE = os.path.join(MEMORY_SESSIONS, "l0_watcher.log")
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s %(message)s',
    handlers=[
        logging.FileHandler(LOG_FILE, encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# ==================== 工具函数 ====================

def safe_ts(ts):
    """解析时间戳"""
    if ts is None:
        return None
    if isinstance(ts, str):
        try:
            if 'T' in ts:
                ts = ts.replace('Z', '+00:00')
                return datetime.fromisoformat(ts).astimezone()
            ts = int(ts)
        except:
            return None
    try:
        return datetime.fromtimestamp(ts / 1000)
    except:
        return None

def load_log():
    """加载归档日志"""
    log_file = os.path.join(MEMORY_SESSIONS, "archive_log.json")
    if os.path.exists(log_file):
        try:
            with open(log_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return {}
    return {}

def save_log(log):
    """保存归档日志"""
    log_file = os.path.join(MEMORY_SESSIONS, "archive_log.json")
    try:
        with open(log_file, 'w', encoding='utf-8') as f:
            json.dump(log, f, ensure_ascii=False, indent=2)
    except Exception as e:
        logger.error(f"[存档日志写入失败] {e}")

def parse_jsonl(path):
    """解析 JSONL 文件"""
    messages = []
    try:
        with open(path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    messages.append(json.loads(line))
                except:
                    continue
    except Exception as e:
        logger.error(f"[解析JSONL失败] {path}: {e}")
    return messages

def format_message(entry):
    """格式化消息为可读文本"""
    t = entry.get('type')
    if t == 'session':
        return None
    if t == 'message':
        msg = entry.get('message', {})
        role = msg.get('role', 'unknown')
        content = msg.get('content', '')
        if isinstance(content, list):
            text_parts = []
            for part in content:
                if isinstance(part, dict):
                    if part.get('type') == 'text':
                        text_parts.append(part.get('text', ''))
                    elif part.get('type') == 'tool_use':
                        text_parts.append(f"[工具: {part.get('name', 'tool')}]")
            content = '\n'.join(text_parts)
        elif not isinstance(content, str):
            content = str(content) if content else ''
        ts = safe_ts(entry.get('timestamp'))
        time_str = ts.strftime('%H:%M') if ts else ''
        if role == 'tool':
            return None
        return f"[{time_str} {role}] {content}"
    return None

def archive_session(jsonl_path, agent_id='main'):
    """归档会话到 L0 存档"""
    session_id = os.path.splitext(os.path.basename(jsonl_path))[0]
    basename = os.path.basename(jsonl_path)
    if basename.endswith('.lock'):
        return False, 'lock'
    if '.reset.' in basename or '.deleted.' in basename:
        return False, 'reset/del'

    messages = parse_jsonl(jsonl_path)
    if not messages:
        return False, 'empty'

    first_ts = safe_ts(messages[0].get('timestamp'))
    session_date = first_ts.strftime('%Y-%m-%d') if first_ts else 'unknown'
    first_time = first_ts.strftime('%H%M') if first_ts else '0000'

    archive_name = f"{agent_id}-{session_date}-{first_time}-{session_id[:8]}.md"
    archive_path = os.path.join(MEMORY_SESSIONS, archive_name)

    user_msgs = [m for m in messages if m.get('type') == 'message' and m.get('message', {}).get('role') == 'user']
    assistant_msgs = [m for m in messages if m.get('type') == 'message' and m.get('message', {}).get('role') == 'assistant']

    lines = [
        f"# 会话存档：{first_ts.strftime('%Y-%m-%d %H:%M') if first_ts else '未知'}",
        f"- 会话ID: {session_id}",
        f"- Agent: {agent_id}",
        f"- 消息数: {len(messages)}（用户: {len(user_msgs)}，助手: {len(assistant_msgs)}）",
        f"",
        f"---",
        f""
    ]
    for entry in messages:
        formatted = format_message(entry)
        if formatted and formatted.strip():
            lines.append(formatted)
            lines.append("")

    try:
        content = '\n'.join(lines)
        with open(archive_path, 'w', encoding='utf-8') as f:
            f.write(content)
        return True, archive_path
    except Exception as e:
        logger.error(f"[归档失败] {archive_path}: {e}")
        return False, str(e)

def check_size_threshold(jsonl_path):
    """检查文件是否超过 4MB"""
    try:
        size = os.path.getsize(jsonl_path)
        return size > L0_SIZE_LIMIT
    except:
        return False

def separate_and_archive(jsonl_path, agent_id='main'):
    """
    超过 4MB 阈值时：
    1. 分离最早的 2MB 内容 -> 写入 L0 历史文件
    2. 保留剩余内容在当前文件
    3. 触发 L1/L2/L3 处理
    """
    session_id = os.path.splitext(os.path.basename(jsonl_path))[0]
    basename = os.path.basename(jsonl_path)

    # 跳过非活跃文件
    if '.reset.' in basename or '.deleted.' in basename or '.lock' in basename:
        return False, 'skipped'

    try:
        # 读取全部内容
        with open(jsonl_path, 'r', encoding='utf-8') as f:
            content = f.read()

        total_size = len(content.encode('utf-8'))

        if total_size <= L0_SIZE_LIMIT:
            return False, 'not_exceeded'

        # 从头分离 2MB 内容（最早的对话）
        separate_content = ''
        remaining_content = content

        if total_size > SEPARATE_SIZE:
            bytes_count = 0
            lines = content.split('\n')
            for i, line in enumerate(lines):
                line_bytes = len((line + '\n').encode('utf-8'))
                if bytes_count + line_bytes <= SEPARATE_SIZE:
                    separate_content += line + '\n'
                    bytes_count += line_bytes
                else:
                    remaining_content = '\n'.join(lines[i:])
                    if content.endswith('\n'):
                        remaining_content += '\n'
                    break
        else:
            separate_content = content
            remaining_content = ''

        # 生成历史文件名
        messages = parse_jsonl(jsonl_path)
        first_ts = safe_ts(messages[0].get('timestamp')) if messages else datetime.now()
        hist_date = first_ts.strftime('%Y-%m-%d') if first_ts else 'unknown'
        hist_time = first_ts.strftime('%H%M') if first_ts else '0000'

        hist_name = f"{agent_id}-hist-{hist_date}-{hist_time}-{session_id[:8]}.md"
        hist_path = os.path.join(MEMORY_SESSIONS, hist_name)

        # 写入历史文件
        with open(hist_path, 'w', encoding='utf-8') as f:
            f.write(separate_content)

        logger.info(f"[L0-历史分离] {session_id[:16]}... 分离 {len(separate_content)} bytes -> {hist_name}")

        # 更新当前文件（只保留剩余内容）
        with open(jsonl_path, 'w', encoding='utf-8') as f:
            f.write(remaining_content)

        logger.info(f"[L0-保留] {session_id[:16]}... 保留 {len(remaining_content)} bytes")

        # 记录到日志
        log = load_log()
        log[session_id] = {
            'archived_path': hist_path,
            'archived_at': datetime.now().isoformat(),
            'reason': '4mb_threshold_separate',
            'separate_size': len(separate_content),
            'remaining_size': len(remaining_content)
        }
        save_log(log)

        # 触发 L1/L2/L3 处理
        trigger_l1_l2_processing(hist_path)

        return True, hist_path

    except Exception as e:
        logger.error(f"[L0-分离失败] {session_id[:16]}...: {e}")
        return False, str(e)

def trigger_l1_l2_processing(hist_path):
    """触发 L1/L2/L3 处理脚本"""
    try:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        migrate_script = os.path.join(script_dir, 'migrate_l1_l2.py')

        if os.path.exists(migrate_script):
            subprocess.Popen(
                ['python3', migrate_script, '--single', hist_path],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
            logger.info(f"[L0-L1L2触发] 已触发处理: {os.path.basename(hist_path)}")
        else:
            logger.warn(f"[L0-L1L2触发] 脚本不存在: {migrate_script}")
    except Exception as e:
        logger.error(f"[L0-L1L2触发失败] {e}")

# ==================== 文件监听 ====================

class SessionHandler(FileSystemEventHandler):
    def __init__(self, sessions_dir, agent_id='main'):
        super().__init__()
        self.sessions_dir = sessions_dir
        self.agent_id = agent_id
        self.log = load_log()
        self.processed_lines = {}  # session_id -> last_line_count
        self.just_truncated = {}   # session_id -> cooldown counter

    def on_modified(self, event):
        if event.is_directory:
            return
        path = event.src_path
        if not path.endswith('.jsonl') or '.lock' in path:
            return

        session_id = os.path.splitext(os.path.basename(path))[0]
        basename = os.path.basename(path)

        if '.reset.' in basename or '.deleted.' in basename:
            return

        # 冷却机制：分离后跳过 3 次检查
        if session_id in self.just_truncated and self.just_truncated[session_id] > 0:
            self.just_truncated[session_id] -= 1
            return

        try:
            # 检查文件大小是否超过 4MB 阈值
            if check_size_threshold(path):
                logger.info(f"[L0-阈值触发] {session_id[:16]}... 超过{L0_SIZE_LIMIT}字节({L0_SIZE_LIMIT//1024//1024}MB)，执行分离...")
                result = separate_and_archive(path, self.agent_id)
                if result[0]:
                    # 设置冷却：分离后跳过 3 次检查
                    self.just_truncated[session_id] = 3
                    self.processed_lines[session_id] = 0
                return

            # 获取当前行数
            with open(path, 'r', encoding='utf-8') as f:
                lines = f.readlines()

            current_lines = len(lines)
            last_processed = self.processed_lines.get(session_id, 0)

            if current_lines <= last_processed:
                return

            # 只处理新增行
            new_lines = lines[last_processed:]
            self.processed_lines[session_id] = current_lines

            # 解析新消息
            new_messages = []
            for line in new_lines:
                line = line.strip()
                if not line:
                    continue
                try:
                    new_messages.append(json.loads(line))
                except:
                    continue

            if not new_messages:
                return

            logger.info(f"[L0-实时] [{self.agent_id}] {session_id[:16]}... 新增 {len(new_messages)} 条消息")

            # 更新存档（追加模式）
            self._append_to_archive(session_id, path, new_messages)

        except Exception as e:
            logger.error(f"[L0-错误] [{self.agent_id}] {session_id[:16]}...: {e}")

    def _append_to_archive(self, session_id, jsonl_path, new_messages):
        log = load_log()
        existing = log.get(session_id, {}).get('archived_path')

        if existing and os.path.exists(existing):
            append_lines = []
            for entry in new_messages:
                formatted = format_message(entry)
                if formatted and formatted.strip():
                    append_lines.append(formatted)
                    append_lines.append("")

            if append_lines:
                try:
                    with open(existing, 'a', encoding='utf-8') as f:
                        f.write('\n'.join(append_lines) + '\n')

                    log[session_id] = {
                        'archived_path': existing,
                        'archived_at': os.path.getmtime(jsonl_path),
                        'archived_at_dt': datetime.now().isoformat()
                    }
                    save_log(log)
                    logger.info(f"[L0-追加] [{self.agent_id}] {session_id[:16]}... +{len(new_messages)} 条 -> {os.path.basename(existing)}")
                except Exception as e:
                    logger.error(f"[L0-追加失败] {existing}: {e}")
        else:
            ok, result = archive_session(jsonl_path, self.agent_id)
            if ok:
                log[session_id] = {
                    'archived_path': result,
                    'archived_at': os.path.getmtime(jsonl_path),
                    'archived_at_dt': datetime.now().isoformat()
                }
                save_log(log)
                self.processed_lines[session_id] = 0
                logger.info(f"[L0-新建] [{self.agent_id}] {session_id[:16]}... -> {os.path.basename(result)}")

# ==================== 主程序 ====================

def main():
    logger.info("=" * 50)
    logger.info("[双驱三维归一记忆系统] L0 Watcher 启动")
    logger.info(f"工作区: {WORKSPACE}")
    logger.info(f"存档目录: {MEMORY_SESSIONS}")
    logger.info(f"触发阈值: {L0_SIZE_LIMIT} bytes ({L0_SIZE_LIMIT//1024//1024}MB)")
    logger.info(f"分离大小: {SEPARATE_SIZE} bytes ({SEPARATE_SIZE//1024//1024}MB)")

    # 获取所有智能体的会话目录
    agents = get_all_agent_sessions()
    logger.info(f"监控 {len(agents)} 个智能体的会话目录:")
    for agent in agents:
        logger.info(f"  - {agent['id']}: {agent['sessions_dir']}")

    logger.info("=" * 50)

    # 启动监听（每个 agent 一个 observer）
    observers = []
    for agent in agents:
        sessions_dir = agent['sessions_dir']
        if os.path.exists(sessions_dir):
            handler = SessionHandler(sessions_dir, agent['id'])
            observer = Observer()
            observer.schedule(handler, sessions_dir, recursive=False)
            observer.start()
            observers.append(observer)
            logger.info(f"[L0-监听中] {agent['id']} @ {sessions_dir}")
        else:
            logger.warning(f"[L0-警告] 目录不存在: {sessions_dir}")

    try:
        logger.info("[L0-运行中] Ctrl+C 停止")
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        logger.info("[L0-停止] 监控系统退出")
        for observer in observers:
            observer.stop()
    for observer in observers:
        observer.join()

if __name__ == "__main__":
    main()
