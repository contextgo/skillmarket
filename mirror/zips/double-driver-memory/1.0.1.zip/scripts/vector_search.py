"""
双驱三维归一记忆系统 - 向量搜索
=================================
语义搜索双向量索引：memory_index + knowledge_index
"""

import sys
import os
sys.stdout.reconfigure(encoding='utf-8')
sys.stderr.reconfigure(encoding='utf-8')
os.environ['PYTHONIOENCODING'] = 'utf-8'

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    from paths_config import (
        WORKSPACE, VECTOR_STORE, LAYER_MEMORY, LAYER_KNOWLEDGE,
        OLLAMA_URL, EMBED_MODEL, EMBEDDING_BACKEND
    )
except ImportError:
    WORKSPACE = "/root/.openclaw/workspace/main"
    VECTOR_STORE = os.path.join(WORKSPACE, "memory", "sessions")
    LAYER_MEMORY = {
        "name": "Personal Memory",
        "sources": [os.path.join(WORKSPACE, "memory")],
        "index_file": os.path.join(VECTOR_STORE, "memory_index.faiss"),
        "meta_file": os.path.join(VECTOR_STORE, "memory_index_meta.json")
    }
    LAYER_KNOWLEDGE = {
        "name": "Business Knowledge",
        "sources": [os.path.join(WORKSPACE, "knowledge-repo")],
        "index_file": os.path.join(VECTOR_STORE, "knowledge_index.faiss"),
        "meta_file": os.path.join(VECTOR_STORE, "knowledge_index_meta.json")
    }
    OLLAMA_URL = "http://localhost:11434"
    EMBED_MODEL = "nomic-embed-text"
    EMBEDDING_BACKEND = "api"

import json
import numpy as np
import faiss

# ==================== Embedding 后端 ====================

def get_embedding_ollama(text):
    """从 Ollama 获取 embedding"""
    import requests
    response = requests.post(
        f"{OLLAMA_URL}/api/embeddings",
        json={"model": EMBED_MODEL, "prompt": text},
        timeout=60
    )
    response.raise_for_status()
    return np.array(response.json()["embedding"], dtype=np.float32)

def get_embedding_api(text):
    """从 OpenAI 兼容 API 获取 embedding"""
    api_key = os.environ.get("OPENAI_API_KEY", "")
    api_base = os.environ.get("OPENAI_API_BASE", "https://api.openai.com/v1")
    model = os.environ.get("EMBEDDING_MODEL", "text-embedding-3-small")

    if not api_key:
        raise RuntimeError("API mode selected but OPENAI_API_KEY is not set")

    import requests
    response = requests.post(
        f"{api_base}/embeddings",
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        },
        json={"input": text, "model": model},
        timeout=30
    )
    response.raise_for_status()
    data = response.json()
    return np.array(data["data"][0]["embedding"], dtype=np.float32)

def get_embedding(text):
    """根据配置选择后端"""
    if EMBEDDING_BACKEND == "ollama":
        return get_embedding_ollama(text)
    else:
        return get_embedding_api(text)

# ==================== 搜索函数 ====================

def search_index(query, layer, top_k=5):
    """搜索单个索引"""
    index_file = layer["index_file"]
    meta_file = layer["meta_file"]

    if not os.path.exists(index_file) or not os.path.exists(meta_file):
        return []

    # 加载索引
    index = faiss.read_index(index_file)

    # 加载元数据
    with open(meta_file, 'r', encoding='utf-8') as f:
        docs = json.load(f)

    # 生成 query embedding
    query_emb = get_embedding(query).reshape(1, -1)

    # 搜索
    D, I = index.search(query_emb, min(top_k, len(docs)))

    # 整理结果
    results = []
    for i, (d, idx) in enumerate(zip(D[0], I[0])):
        if idx < len(docs):
            results.append({
                "rank": i + 1,
                "score": float(d),
                "content": docs[idx]["content"][:200],
                "path": docs[idx]["path"],
                "rel_path": docs[idx].get("rel_path", "")
            })

    return results

def print_results(results, label):
    """打印搜索结果"""
    if not results:
        print(f"\n[{label}] 无结果")
        return

    print(f"\n[{label}] 找到 {len(results)} 个结果:")
    for r in results:
        print(f"\n--- 结果 {r['rank']} (相似度: {r['score']:.4f}) ---")
        print(f"路径: {r['rel_path']}")
        print(f"内容: {r['content'][:150]}...")

# ==================== 主程序 ====================

def main():
    import argparse
    parser = argparse.ArgumentParser(description='双驱三维归一 - 向量搜索')
    parser.add_argument('query', nargs='+', help='搜索关键词')
    parser.add_argument('--top', type=int, default=5, help='返回数量')
    args = parser.parse_args()

    query = ' '.join(args.query)
    top_k = args.top

    print("=" * 50)
    print(f"搜索: {query}")
    print(f"返回: 最多 {top_k} 个结果")
    print("=" * 50)

    # 搜索个人记忆索引
    print_results(search_index(query, LAYER_MEMORY, top_k), "个人记忆 (memory_index)")

    # 搜索业务知识索引
    print_results(search_index(query, LAYER_KNOWLEDGE, top_k), "业务知识 (knowledge_index)")

if __name__ == "__main__":
    main()
