"""
双驱三维归一记忆系统 - 向量索引构建
=====================================
构建双向量索引：memory_index + knowledge_index
"""

import sys
import os
sys.stdout.reconfigure(encoding='utf-8')
sys.stderr.reconfigure(encoding='utf-8')
os.environ['PYTHONIOENCODING'] = 'utf-8'

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    from paths_config import (
        WORKSPACE, VECTOR_STORE, LAYER_MEMORY, LAYER_KNOWLEDGE,
        OLLAMA_URL, EMBED_MODEL, EMBEDDING_BACKEND
    )
except ImportError:
    print("[WARN] paths_config not found, using defaults")
    WORKSPACE = "/root/.openclaw/workspace/main"
    VECTOR_STORE = os.path.join(WORKSPACE, "memory", "sessions")
    LAYER_MEMORY = {
        "name": "Personal Memory",
        "sources": [os.path.join(WORKSPACE, "memory")],
        "index_file": os.path.join(VECTOR_STORE, "memory_index.faiss"),
        "meta_file": os.path.join(VECTOR_STORE, "memory_index_meta.json")
    }
    LAYER_KNOWLEDGE = {
        "name": "Business Knowledge",
        "sources": [os.path.join(WORKSPACE, "knowledge-repo")],
        "index_file": os.path.join(VECTOR_STORE, "knowledge_index.faiss"),
        "meta_file": os.path.join(VECTOR_STORE, "knowledge_index_meta.json")
    }
    OLLAMA_URL = "http://localhost:11434"
    EMBED_MODEL = "nomic-embed-text"
    EMBEDDING_BACKEND = "api"

import json
import numpy as np
import faiss

os.makedirs(VECTOR_STORE, exist_ok=True)

# ==================== Embedding 后端 ====================

def get_embedding_ollama(text):
    """从 Ollama 获取 embedding"""
    import requests
    response = requests.post(
        f"{OLLAMA_URL}/api/embeddings",
        json={"model": EMBED_MODEL, "prompt": text},
        timeout=60
    )
    response.raise_for_status()
    return np.array(response.json()["embedding"], dtype=np.float32)

def get_embedding_api(text):
    """从 OpenAI 兼容 API 获取 embedding"""
    api_key = os.environ.get("OPENAI_API_KEY", "")
    api_base = os.environ.get("OPENAI_API_BASE", "https://api.openai.com/v1")
    model = os.environ.get("EMBEDDING_MODEL", "text-embedding-3-small")

    if not api_key:
        raise RuntimeError("API mode selected but OPENAI_API_KEY is not set")

    import requests
    response = requests.post(
        f"{api_base}/embeddings",
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        },
        json={"input": text, "model": model},
        timeout=30
    )
    response.raise_for_status()
    data = response.json()
    return np.array(data["data"][0]["embedding"], dtype=np.float32)

def get_embedding(text):
    """根据配置选择后端"""
    if EMBEDDING_BACKEND == "ollama":
        return get_embedding_ollama(text)
    else:
        return get_embedding_api(text)

def get_embeddings_batch(texts, progress_callback=None):
    """批量获取 embedding"""
    embeddings = []
    total = len(texts)
    for i, text in enumerate(texts):
        try:
            emb = get_embedding(text)
            embeddings.append(emb)
        except Exception as e:
            print(f"  [错误] Embedding {i+1}: {e}", flush=True)
            dim = 768 if EMBEDDING_BACKEND == "ollama" else 1536
            embeddings.append(np.zeros(dim, dtype=np.float32))
        if progress_callback:
            progress_callback(i + 1, total)
        elif (i + 1) % 50 == 0:
            print(f"  已处理 {i+1}/{total}", flush=True)
    return np.array(embeddings, dtype=np.float32)

# ==================== 文档扫描 ====================

def scan_docs(sources, chunk_size=500):
    """扫描目录下的所有文档"""
    docs = []
    for source in sources:
        if not os.path.exists(source):
            print(f"  [警告] 目录不存在: {source}", flush=True)
            continue
        if os.path.isfile(source):
            docs.extend(scan_file(source, chunk_size))
        else:
            for root, dirs, files in os.walk(source):
                dirs[:] = [d for d in dirs if d not in ['node_modules', '.git', '__pycache__']]
                for f in files:
                    if f.endswith(('.md', '.txt')):
                        path = os.path.join(root, f)
                        docs.extend(scan_file(path, chunk_size))
    return docs

def scan_file(path, chunk_size=500):
    """扫描单个文件"""
    docs = []
    try:
        with open(path, 'r', encoding='utf-8') as fp:
            content = fp.read()
    except:
        try:
            with open(path, 'r', encoding='gbk') as fp:
                content = fp.read()
        except:
            return docs

    rel_path = os.path.relpath(path, WORKSPACE)
    for i in range(0, len(content), chunk_size):
        chunk = content[i:i+chunk_size].strip()
        if chunk:
            docs.append({
                "path": path,
                "rel_path": rel_path,
                "chunk_idx": i // chunk_size,
                "content": chunk,
                "char_count": len(chunk)
            })
    return docs

# ==================== 索引构建 ====================

def build_index(layer):
    """构建单个索引"""
    print(f"\n[索引构建] {layer['name']}", flush=True)
    docs = scan_docs(layer["sources"])
    print(f"[索引构建] 发现 {len(docs)} 个文本块", flush=True)

    if not docs:
        print(f"[索引构建] 无内容，跳过", flush=True)
        return 0

    texts = [d["content"] for d in docs]
    print(f"[索引构建] 生成 Embedding ({EMBEDDING_BACKEND})...", flush=True)

    embeddings = get_embeddings_batch(texts)
    dim = embeddings.shape[1]

    # 创建 FAISS 索引
    index = faiss.IndexFlatL2(dim)
    index.add(embeddings)

    # 保存索引
    os.makedirs(os.path.dirname(layer["index_file"]), exist_ok=True)
    faiss.write_index(index, layer["index_file"])

    # 保存元数据
    with open(layer["meta_file"], 'w', encoding='utf-8') as f:
        json.dump(docs, f, ensure_ascii=False, indent=2)

    print(f"[索引构建] 完成: {len(docs)} 块, 维度={dim}", flush=True)
    return len(docs)

def build_all():
    """构建所有索引"""
    print("=" * 50, flush=True)
    print("双驱三维归一记忆系统 - 向量索引构建", flush=True)
    print(f"后端: {EMBEDDING_BACKEND}", flush=True)
    print("=" * 50, flush=True)

    total = 0
    total += build_index(LAYER_MEMORY)
    total += build_index(LAYER_KNOWLEDGE)

    print(f"\n[完成] 共构建 {total} 个文本块的索引", flush=True)

if __name__ == "__main__":
    build_all()
