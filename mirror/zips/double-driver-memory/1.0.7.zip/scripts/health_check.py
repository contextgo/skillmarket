#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
双驱三维归一记忆系统 - 健康检查脚本
===================================
用于 OpenClaw 集成，检查双驱系统运行状态

输出：
- OK: 系统正常运行
- WARNING: 需要注意
- ERROR: 系统异常
"""

import os
import sys
import json
from datetime import datetime, timedelta

# 路径配置
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    from paths_config import WORKSPACE, MEMORY_DIR, MEMORY_SESSIONS
except ImportError:
    WORKSPACE = "/root/.openclaw/workspace/main"
    MEMORY_DIR = os.path.join(WORKSPACE, "memory")
    MEMORY_SESSIONS = os.path.join(MEMORY_DIR, "sessions")

# 状态文件
STATUS_FILE = os.path.join(MEMORY_DIR, "l0_watcher_status.json")
RUN_LOG_FILE = os.path.join(MEMORY_SESSIONS, "l0_session_log.json")

def check_watcher_status():
    """检查 L0 Watcher 状态"""
    if not os.path.exists(STATUS_FILE):
        return "ERROR", "状态文件不存在"
    
    try:
        with open(STATUS_FILE, 'r', encoding='utf-8') as f:
            status = json.load(f)
        
        if not status.get('running'):
            last_stop = status.get('last_stop', 'unknown')
            return "ERROR", f"L0 Watcher 已停止 (上次: {last_stop})"
        
        last_start = status.get('last_start', 'unknown')
        return "OK", f"运行中 (启动: {last_start})"
    except Exception as e:
        return "ERROR", f"读取状态失败: {e}"

def check_session_updates():
    """检查最近会话更新"""
    if not os.path.exists(RUN_LOG_FILE):
        return "WARNING", "运行日志不存在"
    
    try:
        with open(RUN_LOG_FILE, 'r', encoding='utf-8') as f:
            log_data = json.load(f)
        
        if not log_data:
            return "WARNING", "无会话更新记录"
        
        # 检查最近30分钟有更新的会话
        now = datetime.now()
        recent_count = 0
        total_sessions = len(log_data)
        
        for session_id, data in log_data.items():
            last_update = data.get('last_update')
            if last_update:
                try:
                    update_time = datetime.fromisoformat(last_update)
                    if (now - update_time).total_seconds() < 1800:  # 30分钟
                        recent_count += 1
                except:
                    pass
        
        if recent_count == 0:
            return "WARNING", f"最近30分钟无更新 ({total_sessions} 个会话记录)"
        
        return "OK", f"最近30分钟 {recent_count} 个会话有更新 ({total_sessions} 个总会话)"
    except Exception as e:
        return "ERROR", f"读取运行日志失败: {e}"

def check_l0_files():
    """检查 L0 文件"""
    try:
        if not os.path.exists(MEMORY_SESSIONS):
            return "ERROR", "会话目录不存在"
        
        # 统计 L0 文件
        md_files = [f for f in os.listdir(MEMORY_SESSIONS) if f.endswith('.md')]
        hist_files = [f for f in md_files if '-hist-' in f]
        
        return "OK", f"L0文件: {len(md_files)} 个 (历史: {len(hist_files)})"
    except Exception as e:
        return "ERROR", f"检查失败: {e}"

def check_vector_index():
    """检查向量索引"""
    vector_store = os.path.join(WORKSPACE, "vector_store")
    
    if not os.path.exists(vector_store):
        return "ERROR", "向量存储目录不存在"
    
    try:
        files = os.listdir(vector_store)
        index_files = [f for f in files if f.endswith('.faiss')]
        
        if not index_files:
            return "ERROR", "无向量索引文件"
        
        total_size = sum(os.path.getsize(os.path.join(vector_store, f)) for f in index_files)
        return "OK", f"索引: {len(index_files)} 个 ({total_size//1024//1024}MB)"
    except Exception as e:
        return "ERROR", f"检查失败: {e}"

def main():
    """健康检查主函数"""
    results = {
        "L0_Watcher": check_watcher_status(),
        "会话更新": check_session_updates(),
        "L0文件": check_l0_files(),
        "向量索引": check_vector_index()
    }
    
    # 汇总状态
    has_error = any(r[0] == "ERROR" for r in results.values())
    has_warning = any(r[0] == "WARNING" for r in results.values())
    
    print("=" * 50)
    print("双驱三维归一记忆系统 - 健康检查")
    print("=" * 50)
    print(f"检查时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    all_ok = True
    for name, (status, msg) in results.items():
        icon = {"OK": "✅", "WARNING": "⚠️", "ERROR": "❌"}.get(status, "?")
        print(f"{icon} {name}: {status}")
        print(f"   {msg}")
        if status != "OK":
            all_ok = False
        print()
    
    print("-" * 50)
    if has_error:
        print("❌ 系统异常，请检查上述问题")
        sys.exit(1)
    elif has_warning:
        print("⚠️ 系统需要注意")
        sys.exit(0)
    else:
        print("✅ 系统正常")
        sys.exit(0)

if __name__ == "__main__":
    main()
