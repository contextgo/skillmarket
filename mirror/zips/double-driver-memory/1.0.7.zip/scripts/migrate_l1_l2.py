"""
双驱三维归一记忆系统 - L1/L2/L3 分类处理
==========================================
从 L0 历史文件提取分类信息

功能：
- L1: 提取决策记录 (WAL 标记)
- L2: 提取场景分块 (按标题分类)
- L3: 提取用户画像 (用户信息)
"""

import os
import re
import sys
from datetime import datetime

# 路径配置
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    from paths_config import WORKSPACE, MEMORY_DIR, PROJECTS_DIR
except ImportError:
    WORKSPACE = "/root/.openclaw/workspace/main"
    MEMORY_DIR = os.path.join(WORKSPACE, "memory")
    PROJECTS_DIR = os.path.join(MEMORY_DIR, "projects")

os.makedirs(PROJECTS_DIR, exist_ok=True)

# L1 决策日志目录
L1_DIR = MEMORY_DIR

# ==================== WAL 标记定义 ====================

MARKER_TYPES = [
    '决策', '变更', '状态',   # 核心决策类
    '操作', '问题', '原因', '解决',  # 问题解决类
    '数字', '文件', '工具', '测试',  # 信息记录类
]

# ==================== 提取函数 ====================

def extract_decisions(content, date_str):
    """从日志中提取关键决策，生成 L1 格式"""
    decisions = []
    lines = content.split('\n')

    for line in lines:
        matched_type = None
        for mtype in MARKER_TYPES:
            if f'**[{mtype}]**' in line:
                matched_type = mtype
                break

        if matched_type is None:
            continue

        # 提取时间戳 [HH:MM]
        time_match = re.search(r'\[(\d{2}:\d{2})\]', line)
        time = time_match.group(1) if time_match else '00:00'

        # 清理标记
        clean_line = re.sub(r'\*\*\[' + matched_type + r'\]\*\*[:：]?', '', line).strip()
        clean_line = re.sub(r'^\\[?' + matched_type + r'\\]?[:：]?\s*', '', clean_line).strip()

        if clean_line and len(clean_line) > 5:
            decisions.append(f"[{time}] **[{matched_type}]** {clean_line}")

    return decisions

def extract_scenes(content, date_str):
    """从日志中提取场景分类，生成 L2 格式"""
    scenes = {}

    # 按 ## 标题分割章节
    sections = re.split(r'\n##?\s*', content)

    for section in sections:
        if not section.strip():
            continue

        lines = section.split('\n')
        title = lines[0].strip('# \n') if lines else '未分类'

        # 归类场景
        scene_type = 'system'
        for kw in ['客户', 'GEO', '跟进', '成单', '签约']:
            if kw in title:
                scene_type = 'business'
                break
        for kw in ['系统', '配置', '安装', '升级', '修复']:
            if kw in title:
                scene_type = 'system'
                break
        for kw in ['记忆', '日志', '文档', '话术']:
            if kw in title:
                scene_type = 'knowledge'
                break

        body = '\n'.join(lines[1:]) if len(lines) > 1 else ''
        if body.strip():
            if scene_type not in scenes:
                scenes[scene_type] = []
            scenes[scene_type].append(f"### {title}\n{body[:500]}")

    return scenes

def process_file(md_path):
    """处理单个 L0 历史文件"""
    basename = os.path.basename(md_path)
    print(f"[处理] {basename}")

    try:
        with open(md_path, 'r', encoding='utf-8') as f:
            content = f.read()
    except Exception as e:
        print(f"[错误] 读取失败 {md_path}: {e}")
        return 0, 0

    # 提取日期
    date_match = re.search(r'2026-(\d{2})-(\d{2})', basename)
    if date_match:
        month, day = date_match.group(1), date_match.group(2)
        date_str = f"2026-{month}-{day}"
    else:
        date_str = datetime.now().strftime('%Y-%m-%d')

    total_decisions = 0

    # ==================== L1: 决策记录 ====================
    decisions = extract_decisions(content, date_str)
    if decisions:
        l1_file = os.path.join(L1_DIR, f"LOG-{date_str}-01.md")

        # 追加模式，避免覆盖同日期的不同文件
        if os.path.exists(l1_file):
            with open(l1_file, 'r', encoding='utf-8') as f:
                existing = f.read()

            if f"来源: {basename}" not in existing:
                with open(l1_file, 'a', encoding='utf-8') as f:
                    f.write(f"\n---\n来源: {basename}\n\n")
                    f.write('\n'.join(decisions))
                    f.write('\n')
                print(f"  [L1追加] {os.path.basename(l1_file)} (+{len(decisions)}条)")
        else:
            l1_content = f"# 决策日志 {date_str}\n\n"
            l1_content += f"来源: {basename}\n\n"
            l1_content += "---\n\n"
            l1_content += '\n'.join(decisions)
            l1_content += '\n'

            with open(l1_file, 'w', encoding='utf-8') as f:
                f.write(l1_content)
            print(f"  [L1生成] {os.path.basename(l1_file)} ({len(decisions)}条)")

        total_decisions += len(decisions)

    # ==================== L2: 场景分块 ====================
    scenes = extract_scenes(content, date_str)
    for scene_type, blocks in scenes.items():
        proj_dir = os.path.join(PROJECTS_DIR, scene_type)
        os.makedirs(proj_dir, exist_ok=True)

        l2_file = os.path.join(proj_dir, f"main-{date_str}.md")
        l2_content = f"# 场景分块 {date_str} [{scene_type}]\n\n"
        l2_content += f"来源: {basename}\n\n"
        l2_content += "---\n\n"
        l2_content += '\n\n---\n\n'.join(blocks[:5])  # 最多 5 个 block

        with open(l2_file, 'w', encoding='utf-8') as f:
            f.write(l2_content)
        print(f"  [L2生成] {scene_type}/{os.path.basename(l2_file)} ({len(blocks)}块)")

    return total_decisions, len(scenes)

# ==================== 主程序 ====================

def main():
    import argparse
    parser = argparse.ArgumentParser(description='双驱三维归一 - L1/L2/L3 分类处理')
    parser.add_argument('--single', type=str, help='处理单个文件路径')
    args = parser.parse_args()

    memory_dir = MEMORY_DIR

    if args.single:
        # 处理单个文件（由 L0 Watcher 触发）
        single_path = args.single
        if os.path.exists(single_path):
            print(f"[L0触发] 处理: {os.path.basename(single_path)}")
            d, s = process_file(single_path)
            print(f"[完成] L1: {d}条决策, L2: {s}个场景")
        else:
            print(f"[错误] 文件不存在: {single_path}")
        return

    # 处理所有 L0 历史文件
    sessions_dir = os.path.join(memory_dir, "sessions")
    if not os.path.exists(sessions_dir):
        print(f"[结束] 目录不存在: {sessions_dir}")
        return

    # 查找所有历史文件
    hist_files = sorted([
        os.path.join(sessions_dir, f)
        for f in os.listdir(sessions_dir)
        if f.endswith('.md') and '-hist-' in f
    ])

    # 查找 main- 开头的存档文件
    main_files = sorted([
        os.path.join(sessions_dir, f)
        for f in os.listdir(sessions_dir)
        if f.startswith('main-') and f.endswith('.md') and '-hist-' not in f
    ])

    all_files = hist_files + main_files

    print(f"[开始] 找到 {len(all_files)} 个 L0 文件待处理")

    total_decisions = 0
    for md_file in all_files:
        d, s = process_file(md_file)
        total_decisions += d

    print(f"\n[完成] 共处理 {len(all_files)} 个文件，生成 {total_decisions} 条 L1 决策记录")

if __name__ == "__main__":
    main()
