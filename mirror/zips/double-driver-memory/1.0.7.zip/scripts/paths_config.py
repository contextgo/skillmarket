"""
双驱三维归一记忆系统 - 路径配置
================================
自动从 openclaw.json 读取 workspace 配置
"""

import os
import json

# 默认路径
DEFAULT_WORKSPACE = "/root/.openclaw/workspace/main"
DEFAULT_SESSIONS = "/root/.openclaw/agents/main/sessions"
DEFAULT_MEMORY = "/workspace/main/memory"

# L0 阈值配置
L0_SIZE_LIMIT = 4 * 1024 * 1024  # 4MB
SEPARATE_SIZE = 2 * 1024 * 1024  # 2MB

# Embedding 配置
EMBEDDING_BACKEND = "api"  # "ollama" 或 "api"
OLLAMA_URL = "http://127.0.0.1:11434"
EMBED_MODEL = "nomic-embed-text"

def find_openclaw_json():
    """查找 openclaw.json 位置"""
    paths = [
        "/root/.openclaw/openclaw.json",
        os.path.expanduser("~/.openclaw/openclaw.json"),
    ]
    for p in paths:
        if os.path.exists(p):
            return p
    return None

def get_workspace():
    """获取 workspace 路径 - 优先使用 main agent 的 workspace"""
    openclaw_path = find_openclaw_json()
    if openclaw_path:
        try:
            with open(openclaw_path, 'r', encoding='utf-8') as f:
                config = json.load(f)
                
                # 优先从 agents.list 中找 main agent
                agents_list = config.get('agents', {}).get('list', [])
                for agent in agents_list:
                    if agent.get('id') == 'main':
                        ws = agent.get('workspace')
                        if ws:
                            return os.path.expanduser(ws)
                
                # 回退到 defaults.workspace
                defaults = config.get('agents', {}).get('defaults', {})
                ws = defaults.get('workspace')
                if ws:
                    return os.path.expanduser(ws)
        except Exception as e:
            print(f"[WARN] 读取 openclaw.json 失败: {e}")
    return DEFAULT_WORKSPACE

def get_all_agent_sessions():
    """获取所有智能体的会话目录"""
    openclaw_path = find_openclaw_json()
    if openclaw_path:
        try:
            with open(openclaw_path, 'r', encoding='utf-8') as f:
                config = json.load(f)
                agents = config.get('agents', {})
                sessions = []
                for agent_id, agent_config in agents.items():
                    if isinstance(agent_config, dict):
                        sessions_dir = agent_config.get('sessionsDir')
                        if sessions_dir:
                            sessions.append({
                                'id': agent_id,
                                'sessions_dir': os.path.expanduser(sessions_dir)
                            })
                if sessions:
                    return sessions
        except Exception:
            pass
    
    # 默认返回 main
    return [{
        'id': 'main',
        'sessions_dir': DEFAULT_SESSIONS
    }]

# 全局变量
WORKSPACE = get_workspace()
MEMORY_DIR = os.path.join(WORKSPACE, "memory")
MEMORY_SESSIONS = os.path.join(MEMORY_DIR, "sessions")
VECTOR_STORE = MEMORY_SESSIONS
PROJECTS_DIR = os.path.join(MEMORY_DIR, "projects")

# 向量索引配置 - 使用已有的 vector_store 目录
VECTOR_STORE = os.path.join(WORKSPACE, "vector_store")

LAYER_MEMORY = {
    "name": "Personal Memory (L0/L1/L2/L3)",
    "sources": [
        MEMORY_SESSIONS,
        MEMORY_DIR,
    ],
    "index_file": os.path.join(VECTOR_STORE, "memory_index.faiss"),
    "meta_file": os.path.join(VECTOR_STORE, "memory_meta.json")
}

LAYER_KNOWLEDGE = {
    "name": "Business Knowledge",
    "sources": [
        os.path.join(WORKSPACE, "knowledge-repo"),
        os.path.join(WORKSPACE, "本盘knowledge-repo"),
    ],
    "index_file": os.path.join(VECTOR_STORE, "knowledge_index.faiss"),
    "meta_file": os.path.join(VECTOR_STORE, "knowledge_meta.json")
}

# API 配置
import os
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "")
OPENAI_API_BASE = os.environ.get("OPENAI_API_BASE", "https://api.openai.com/v1")
EMBEDDING_MODEL = os.environ.get("EMBEDDING_MODEL", "text-embedding-3-small")

print(f"[DEBUG] paths_config imported OK")
print(f"  WORKSPACE: {WORKSPACE}")
print(f"  MEMORY_DIR: {MEMORY_DIR}")
print(f"  MEMORY_SESSIONS: {MEMORY_SESSIONS}")
