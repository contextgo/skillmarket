"""
双驱三维归一记忆系统 - 系统状态
==================================
查看系统各组件状态
"""

import sys
import os
sys.stdout.reconfigure(encoding='utf-8')
sys.stderr.reconfigure(encoding='utf-8')
os.environ['PYTHONIOENCODING'] = 'utf-8'

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    from paths_config import (
        WORKSPACE, MEMORY_DIR, MEMORY_SESSIONS, PROJECTS_DIR,
        L0_SIZE_LIMIT, SEPARATE_SIZE,
        LAYER_MEMORY, LAYER_KNOWLEDGE,
        EMBEDDING_BACKEND, OLLAMA_URL
    )
except ImportError:
    WORKSPACE = "/root/.openclaw/workspace/main"
    MEMORY_DIR = os.path.join(WORKSPACE, "memory")
    MEMORY_SESSIONS = os.path.join(MEMORY_DIR, "sessions")
    PROJECTS_DIR = os.path.join(MEMORY_DIR, "projects")
    L0_SIZE_LIMIT = 4 * 1024 * 1024
    SEPARATE_SIZE = 2 * 1024 * 1024
    LAYER_MEMORY = {
        "name": "Personal Memory",
        "index_file": os.path.join(MEMORY_SESSIONS, "memory_index.faiss"),
        "meta_file": os.path.join(MEMORY_SESSIONS, "memory_index_meta.json")
    }
    LAYER_KNOWLEDGE = {
        "name": "Business Knowledge",
        "index_file": os.path.join(MEMORY_SESSIONS, "knowledge_index.faiss"),
        "meta_file": os.path.join(MEMORY_SESSIONS, "knowledge_index_meta.json")
    }
    EMBEDDING_BACKEND = "api"
    OLLAMA_URL = "http://127.0.0.1:11434"

import glob
import json

def format_size(size_bytes):
    """格式化文件大小"""
    if size_bytes < 1024:
        return f"{size_bytes}B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f}KB"
    else:
        return f"{size_bytes / 1024 / 1024:.1f}MB"

def check_vector_indices():
    """检查向量索引"""
    print("\n[双驱：向量索引]")
    total_chunks = 0

    for layer in [LAYER_MEMORY, LAYER_KNOWLEDGE]:
        label = layer["name"]
        index_file = layer["index_file"]
        meta_file = layer["meta_file"]

        if os.path.exists(index_file) and os.path.exists(meta_file):
            try:
                import faiss
                index = faiss.read_index(index_file)
                with open(meta_file, 'r', encoding='utf-8') as f:
                    meta = json.load(f)
                chunks = len(meta) if isinstance(meta, list) else 0
                total_chunks += chunks
                print(f"  {label}: OK ({chunks} chunks)")
            except Exception as e:
                print(f"  {label}: ERROR ({e})")
        else:
            print(f"  {label}: MISSING")

    print(f"  总计: {total_chunks} chunks")

def check_memory_layers():
    """检查记忆层"""
    print("\n[三维：分类层]")

    # L0 原始存档
    sessions_dir = MEMORY_SESSIONS
    l0_count = l0_size = 0
    if os.path.exists(sessions_dir):
        files = glob.glob(os.path.join(sessions_dir, "*.md"))
        l0_count = len(files)
        l0_size = sum(os.path.getsize(f) for f in files)
    print(f"  L0 原始存档: {l0_count} 文件 ({format_size(l0_size)}) [阈值: 4MB, 分离: 2MB]")

    # L1 决策记录
    log_files = sorted(glob.glob(os.path.join(MEMORY_DIR, "Decision Log-*.md")))
    log_files.extend(sorted(glob.glob(os.path.join(MEMORY_DIR, "LOG-*.md"))))
    l1_size = sum(os.path.getsize(f) for f in log_files)
    print(f"  L1 决策记录: {len(log_files)} 文件 ({format_size(l1_size)})")

    # L2 场景分块
    projects_dir = PROJECTS_DIR
    l2_count = l2_size = 0
    if os.path.exists(projects_dir):
        for root, dirs, files in os.walk(projects_dir):
            md_files = [f for f in files if f.endswith('.md')]
            l2_count += len(md_files)
            l2_size += sum(os.path.getsize(os.path.join(root, f)) for f in md_files)
    print(f"  L2 场景分块: {l2_count} 文件 ({format_size(l2_size)})")

    # L3 用户画像
    l3_files = ["MEMORY.md", "SOUL.md", "USER.md"]
    l3_total = l3_count = 0
    for f in l3_files:
        fpath = os.path.join(WORKSPACE, f)
        if os.path.exists(fpath):
            l3_count += 1
            l3_total += os.path.getsize(fpath)
    print(f"  L3 用户画像: {l3_count}/3 文件 ({format_size(l3_total)})")

def check_knowledge_base():
    """检查外部知识库"""
    print("\n[外部知识库]")
    kb_paths = [
        os.path.join(WORKSPACE, "knowledge-repo"),
        os.path.join(WORKSPACE, "本盘knowledge-repo"),
    ]
    total_files = total_size = 0
    for kb in kb_paths:
        if os.path.exists(kb):
            for root, dirs, files in os.walk(kb):
                dirs[:] = [d for d in dirs if d not in ['node_modules', '.git', '__pycache__']]
                md_files = [f for f in files if f.endswith(('.md', '.txt'))]
                total_files += len(md_files)
                total_size += sum(os.path.getsize(os.path.join(root, f)) for f in md_files)
    if total_files > 0:
        print(f"  knowledge-repo: {total_files} 文件 ({format_size(total_size)})")
    else:
        print(f"  knowledge-repo: 未找到")

def main():
    print("=" * 50)
    print("双驱三维归一记忆系统状态")
    print("=" * 50)
    print(f"工作区: {WORKSPACE}")
    print(f"Embedding 后端: {EMBEDDING_BACKEND}")
    if EMBEDDING_BACKEND == "ollama":
        print(f"Ollama URL: {OLLAMA_URL}")

    check_vector_indices()
    check_memory_layers()
    check_knowledge_base()

    print("\n[推荐 Cron 任务]")
    print("  12:00 - 检查向量索引健康")
    print("  18:00 - 重建双向量索引")
    print("  18:00 - 检查 L1 决策记录配额")
    print("  23:00 - 检查 L0 会话归档")

    print("\n" + "=" * 50)
    print("检查完成")
    print("=" * 50)

if __name__ == "__main__":
    main()
