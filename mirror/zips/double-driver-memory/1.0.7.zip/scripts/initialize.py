#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
双驱三维归一记忆系统 - 初始化向导
==========================================

初始化流程：
1. 检查环境依赖
2. 初始化目录结构
3. 询问用户是否有旧记忆文件
4. 如有，处理旧记忆文件（生成L0 → L1/L2/L3 → 向量索引）
5. 生成旧记忆WORD日志文档
6. 创建初始文件，开始会话转写
7. 生成新记忆WORD日志文档
8. 激活L0 Watcher
"""

import os
import sys
import json
import subprocess
from datetime import datetime

# 添加脚本目录到路径
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
SKILL_DIR = os.path.dirname(SCRIPT_DIR)
WORKSPACE = '/root/.openclaw/workspace/main'

sys.path.insert(0, SCRIPT_DIR)

# 导入配置
try:
    from paths_config import (
        WORKSPACE, MEMORY_DIR, MEMORY_SESSIONS, PROJECTS_DIR,
        L0_SIZE_LIMIT, SEPARATE_SIZE
    )
except ImportError:
    print("[WARN] paths_config 导入失败，使用默认配置")
    WORKSPACE = '/root/.openclaw/workspace/main'
    MEMORY_DIR = os.path.join(WORKSPACE, "memory")
    MEMORY_SESSIONS = os.path.join(MEMORY_DIR, "sessions")
    PROJECTS_DIR = os.path.join(MEMORY_DIR, "projects")
    L0_SIZE_LIMIT = 4 * 1024 * 1024
    SEPARATE_SIZE = 2 * 1024 * 1024

class Colors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'

def log(msg, level="INFO"):
    levels = {
        "INFO": f"{Colors.OKBLUE}[INFO]{Colors.ENDC}",
        "OK": f"{Colors.OKGREEN}[OK]{Colors.ENDC}",
        "WARN": f"{Colors.WARNING}[WARN]{Colors.ENDC}",
        "ERROR": f"{Colors.FAIL}[ERROR]{Colors.ENDC}",
        "STEP": f"{Colors.HEADER}[STEP]{Colors.ENDC}",
    }
    print(f"{levels.get(level, '[INFO]')} {msg}")

def log_section(title):
    print(f"\n{'='*60}")
    print(f"{Colors.BOLD}{title}{Colors.ENDC}")
    print(f"{'='*60}")

# ==================== 步骤1：环境检查 ====================

def check_environment():
    """检查环境依赖"""
    log_section("步骤1：环境检查")
    
    checks = [
        ("Python 版本", lambda: sys.version_info >= (3, 8)),
        ("watchdog 库", lambda: __import__('watchdog')),
        ("faiss 库", lambda: __import__('faiss')),
        ("docx 库", lambda: __import__('docx')),
        ("numpy 库", lambda: __import__('numpy')),
    ]
    
    all_passed = True
    for name, check in checks:
        try:
            check()
            log(f"{name}: {Colors.OKGREEN}OK{Colors.ENDC}", "OK")
        except Exception as e:
            log(f"{name}: {Colors.FAIL}缺失 ({e}){Colors.ENDC}", "ERROR")
            all_passed = False
    
    if not all_passed:
        log("安装缺失的依赖：pip install watchdog faiss-cpu python-docx numpy", "WARN")
        return False
    
    log("环境检查完成，所有依赖就绪", "OK")
    return True

# ==================== 步骤1.5：Embedding 后端检查 ====================

def check_embedding_backend():
    """检查并配置 Embedding 后端"""
    log_section("步骤1.5：Embedding 向量模型配置")
    
    print("""
请选择向量嵌入模型后端（用于语义搜索）：

1. 【推荐】Ollama 本地部署（免费、私密、离线可用）
   - 优点：免费使用、无需 API Key、离线可用、数据私密
   - 安装要求：
     a) 安装 Ollama: curl -fsSL https://ollama.com/install.sh | sh
     b) 启动服务: ollama serve
     c) 下载模型: ollama pull nomic-embed-text
   - 适用场景：长期使用、重视数据隐私、需要离线运行

2. 云端大模型 API（配置简单、快速上手）
   - 优点：配置简单、速度快、无需本地部署
   - 推荐国内服务商：
     • MiniMAX API（推荐，性价比高）
       - 注册: https://platform.minimax.io/
       - 获取 Key 后设置环境变量: export OPENAI_API_KEY=xxx
       - 或修改配置文件中的 OPENAI_API_BASE
     • 硅基流动 / 阿里云百炼 / 百度智能云 等
   - 适用场景：快速体验、少量使用、懒得部署本地

""")
    
    # 检查当前配置状态
    api_key = os.environ.get('OPENAI_API_KEY', '')
    ollama_available = False
    try:
        import requests
        r = requests.get('http://localhost:11434', timeout=2)
        if r.status_code == 200:
            ollama_available = True
    except:
        pass
    
    print(f"【当前状态】")
    if ollama_available:
        log(f"Ollama 本地服务: {Colors.OKGREEN}已运行{Colors.ENDC} (http://localhost:11434)", "OK")
    else:
        log(f"Ollama 本地服务: {Colors.WARNING}未运行{Colors.ENDC}", "WARN")
    
    if api_key:
        log(f"云端 API Key: {Colors.OKGREEN}已配置{Colors.ENDC}", "OK")
    else:
        log(f"云端 API Key: {Colors.WARNING}未配置{Colors.ENDC}", "WARN")
    
    print(f"""
【推荐方案】
  如果是首次安装，推荐使用方案2：
  1. 注册 MiniMAX: https://platform.minimax.io/
  2. 获取 API Key
  3. 设置环境变量: export OPENAI_API_KEY=你的KEY
  
  如果追求长期使用和隐私，推荐方案1（Ollama）
""")
    
    # 询问用户选择
    print(f"请选择后端方案 [{Colors.OKGREEN}1{Colors.ENDC}/2] (直接回车默认方案2): ", end='')
    try:
        choice = input().strip()
    except:
        choice = '2'  # 默认方案2
    
    if choice == '1':
        # Ollama 方案
        if not ollama_available:
            log("Ollama 未运行，正在启动...", "INFO")
            print("""
【Ollama 安装指引】

1. 安装 Ollama:
   curl -fsSL https://ollama.com/install.sh | sh

2. 启动服务:
   ollama serve

3. 下载向量模型:
   ollama pull nomic-embed-text

4. 重启本向导后选择方案1
""")
            log("请先安装并启动 Ollama，然后重新运行本向导", "WARN")
            return False
        else:
            log("已选择 Ollama 本地方案", "OK")
            # 更新配置为 Ollama 模式
            update_config('ollama')
            return True
    else:
        # API 方案
        if not api_key:
            log("未检测到 OPENAI_API_KEY 环境变量", "WARN")
            print("""
【MiniMAX API 配置指引】

1. 注册 MiniMAX:
   访问 https://platform.minimax.io/

2. 获取 API Key:
   个人中心 → API Keys → 创建 Key

3. 设置环境变量:
   export OPENAI_API_KEY=你的MiniMAX API Key

4. 配置 MiniMAX 兼容接口（可选）:
   export OPENAI_API_BASE=https://api.minimax.chat/v1

5. 重新运行本向导
""")
            print(f"{Colors.WARNING}请先配置好 API Key 后重新运行向导{Colors.ENDC}")
            return False
        else:
            log(f"已选择云端 API 方案 (OPENAI_API_KEY 已配置)", "OK")
            update_config('api')
            return True

def update_config(mode):
    """更新配置为指定模式"""
    config_path = os.path.join(SCRIPT_DIR, 'paths_config.py')
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # 替换 EMBEDDING_BACKEND
        if 'EMBEDDING_BACKEND = ' in content:
            content = content.replace(
                'EMBEDDING_BACKEND = "api"',
                f'EMBEDDING_BACKEND = "{mode}"'
            )
        
        with open(config_path, 'w', encoding='utf-8') as f:
            f.write(content)
        
        log(f"配置已更新: EMBEDDING_BACKEND = \"{mode}\"", "OK")
    except Exception as e:
        log(f"配置更新失败: {e}", "WARN")

# ==================== 步骤2：初始化目录 ====================

def initialize_directories():
    """初始化目录结构"""
    log_section("步骤2：初始化目录结构")
    
    dirs = [
        MEMORY_SESSIONS,
        PROJECTS_DIR,
        os.path.join(PROJECTS_DIR, "business"),
        os.path.join(PROJECTS_DIR, "knowledge"),
        os.path.join(PROJECTS_DIR, "system"),
        os.path.join(WORKSPACE, "vector_store"),
        os.path.join(WORKSPACE, "memory", "docs"),
    ]
    
    for d in dirs:
        os.makedirs(d, exist_ok=True)
        log(f"创建目录: {d}", "OK")
    
    log("目录结构初始化完成", "OK")
    return True

# ==================== 步骤3：检查旧记忆文件 ====================

def check_old_memory_files():
    """询问并检查旧记忆文件"""
    log_section("步骤3：检查旧记忆文件")
    
    print(f"\n{Colors.WARNING}请问是否有旧记忆文件需要迁移？{Colors.ENDC}")
    print("常见旧记忆文件位置：")
    print(f"  1. {MEMORY_SESSIONS}/")
    print("  2. {WORKSPACE}/memory/  (旧版记忆目录)")
    print("  3. 其他自定义路径")
    print()
    
    # 检查现有文件
    existing_files = []
    
    # 检查当前L0存档
    if os.path.exists(MEMORY_SESSIONS):
        for f in os.listdir(MEMORY_SESSIONS):
            if f.endswith('.md') and '-hist-' not in f:
                path = os.path.join(MEMORY_SESSIONS, f)
                size = os.path.getsize(path)
                existing_files.append({
                    'path': path,
                    'name': f,
                    'size': size,
                    'type': 'L0_current'
                })
    
    # 检查历史文件
    if os.path.exists(MEMORY_SESSIONS):
        for f in os.listdir(MEMORY_SESSIONS):
            if f.endswith('.md') and '-hist-' in f:
                path = os.path.join(MEMORY_SESSIONS, f)
                size = os.path.getsize(path)
                existing_files.append({
                    'path': path,
                    'name': f,
                    'size': size,
                    'type': 'L0_historical'
                })
    
    # 检查旧版memory目录
    old_memory_dir = os.path.join(WORKSPACE, "memory")
    if os.path.exists(old_memory_dir):
        for root, dirs, files in os.walk(old_memory_dir):
            for f in files:
                if f.endswith('.md') and 'sessions' not in root:
                    path = os.path.join(root, f)
                    size = os.path.getsize(path)
                    rel_path = os.path.relpath(path, WORKSPACE)
                    existing_files.append({
                        'path': path,
                        'name': f,
                        'size': size,
                        'type': 'old_memory'
                    })
    
    if existing_files:
        log(f"发现 {len(existing_files)} 个旧记忆文件：", "INFO")
        total_size = 0
        for f in existing_files[:10]:  # 只显示前10个
            size_str = f"{f['size'] / 1024 / 1024:.2f}MB" if f['size'] > 1024*1024 else f"{f['size'] / 1024:.1f}KB"
            log(f"  [{f['type']}] {f['name']} ({size_str})", "INFO")
            total_size += f['size']
        
        if len(existing_files) > 10:
            log(f"  ... 还有 {len(existing_files) - 10} 个文件", "INFO")
        
        log(f"总计: {total_size / 1024 / 1024:.2f}MB", "INFO")
        
        print(f"\n{Colors.WARNING}是否处理这些旧记忆文件？{Colors.ENDC}")
        print("  输入 'y' 或 'yes' 确认处理")
        print("  输入 'n' 或 'no' 跳过处理")
        print("  输入 'p' 查看完整文件列表")
        
        return existing_files
    else:
        log("未发现旧记忆文件", "OK")
        return []

# ==================== 步骤4：处理旧记忆文件 ====================

def process_old_files(old_files):
    """处理旧记忆文件：生成L0 → L1/L2/L3 → 向量索引"""
    log_section("步骤4：处理旧记忆文件")
    
    if not old_files:
        log("跳过旧文件处理", "INFO")
        return
    
    log(f"准备处理 {len(old_files)} 个旧记忆文件...", "INFO")
    
    # 按时间排序（从文件名或路径提取时间）
    def get_file_time(f):
        # 尝试从文件名提取时间
        name = f['name']
        # 匹配 main-YYYY-MM-DD 或 main-YYYYMMDD 格式
        import re
        match = re.search(r'main[-_]?(\d{4})[-_]?(\d{2})[-_]?(\d{2})', name)
        if match:
            return f"{match.group(1)}-{match.group(2)}-{match.group(3)}"
        return "1900-01-01"
    
    old_files.sort(key=get_file_time)
    
    log("文件按时间排序完成（从旧到新）", "OK")
    
    # 统计信息
    total_size = sum(f['size'] for f in old_files)
    estimated_l0_files = int(total_size / (2 * 1024 * 1024)) + 1
    
    log(f"预计生成约 {estimated_l0_files} 个 L0 文件", "INFO")
    
    # 处理每个文件
    processed = 0
    for f in old_files:
        log(f"处理: {f['name']} ({f['size'] / 1024:.1f}KB)", "INFO")
        
        # 1. 如果文件大于2MB，按2MB分割
        if f['size'] > 2 * 1024 * 1024:
            # 分割文件
            split_file = split_large_file(f['path'])
            if split_file:
                # 对分割后的文件进行L1/L2/L3处理
                trigger_l1_l2_processing(split_file)
                processed += 1
        else:
            # 直接进行L1/L2/L3处理
            trigger_l1_l2_processing(f['path'])
            processed += 1
    
    log(f"旧文件处理完成: {processed} 个文件已处理", "OK")

def split_large_file(file_path, chunk_size=2*1024*1024):
    """分割大文件为2MB的块"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        total_size = len(content.encode('utf-8'))
        if total_size <= chunk_size:
            return file_path
        
        # 计算分割点
        split_content = content[:chunk_size]
        remaining_content = content[chunk_size:]
        
        # 生成新文件名
        basename = os.path.basename(file_path)
        name, ext = os.path.splitext(basename)
        
        # 分割后的文件名
        split_name = f"{name}_part1{ext}"
        split_path = os.path.join(MEMORY_SESSIONS, split_name)
        
        with open(split_path, 'w', encoding='utf-8') as f:
            f.write(split_content)
        
        # 保留剩余内容到原文件
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(remaining_content)
        
        log(f"分割文件: {basename} -> {split_name} + {basename}", "OK")
        return split_path
        
    except Exception as e:
        log(f"分割文件失败 {file_path}: {e}", "ERROR")
        return file_path

def trigger_l1_l2_processing(file_path):
    """触发L1/L2/L3处理"""
    try:
        migrate_script = os.path.join(SCRIPT_DIR, 'migrate_l1_l2.py')
        if os.path.exists(migrate_script):
            result = subprocess.run(
                ['python3', migrate_script, '--single', file_path],
                capture_output=True,
                text=True,
                timeout=60
            )
            if result.returncode == 0:
                log(f"  L1/L2/L3处理完成: {os.path.basename(file_path)}", "OK")
            else:
                log(f"  L1/L2/L3处理失败: {result.stderr}", "WARN")
        else:
            log(f"  migrate_l1_l2.py 不存在，跳过", "WARN")
    except Exception as e:
        log(f"  L1/L2/L3处理异常: {e}", "WARN")

# ==================== 步骤5：构建向量索引 ====================

def build_vector_index():
    """构建向量索引"""
    log_section("步骤5：构建向量索引")
    
    try:
        build_script = os.path.join(SCRIPT_DIR, 'build_index.py')
        if os.path.exists(build_script):
            log("正在构建向量索引（这可能需要几分钟）...", "INFO")
            result = subprocess.run(
                ['python3', build_script],
                capture_output=True,
                text=True,
                timeout=3600  # 1小时超时
            )
            if result.returncode == 0:
                log("向量索引构建完成", "OK")
                print(result.stdout[-500:] if len(result.stdout) > 500 else result.stdout)
            else:
                log(f"向量索引构建失败: {result.stderr}", "ERROR")
        else:
            log("build_index.py 不存在，跳过", "WARN")
    except Exception as e:
        log(f"向量索引构建异常: {e}", "ERROR")

# ==================== 步骤6：生成WORD文档1 ====================

def generate_word_doc_phase1():
    """生成旧记忆WORD日志文档"""
    log_section("步骤6：生成旧记忆WORD日志文档")
    
    try:
        doc_script = os.path.join(SCRIPT_DIR, 'generate_docx.py')
        if os.path.exists(doc_script):
            result = subprocess.run(
                ['python3', doc_script],
                capture_output=True,
                text=True,
                timeout=60
            )
            if result.returncode == 0:
                output = result.stdout.strip()
                log(f"旧记忆WORD文档生成完成: {output}", "OK")
            else:
                log(f"WORD文档生成失败: {result.stderr}", "ERROR")
        else:
            log("generate_docx.py 不存在，跳过", "WARN")
    except Exception as e:
        log(f"WORD文档生成异常: {e}", "ERROR")

# ==================== 步骤7：创建初始文件 ====================

def create_initial_files():
    """创建初始文件"""
    log_section("步骤7：创建初始文件")
    
    # 创建初始L0文件（空文件，带时间戳）
    now = datetime.now()
    initial_l0_name = f"main-{now.strftime('%Y-%m-%d')}-0000-initial.md"
    initial_l0_path = os.path.join(MEMORY_SESSIONS, initial_l0_name)
    
    initial_content = f"""# 会话存档初始化
- 创建时间: {now.strftime('%Y-%m-%d %H:%M:%S')}
- 状态: 活跃会话
- 用途: 双驱三维归一记忆系统初始化文件

---
本文件是系统初始化后创建的第一个会话存档。
所有新对话将实时追加到此文件。
"""
    
    with open(initial_l0_path, 'w', encoding='utf-8') as f:
        f.write(initial_content)
    
    log(f"创建初始L0文件: {initial_l0_name}", "OK")
    
    # 创建会话转写状态文件
    transfer_state = {
        'started_at': now.isoformat(),
        'status': 'initializing',
        'current_file': initial_l0_path,
        'processed_size': 0
    }
    
    state_file = os.path.join(MEMORY_SESSIONS, 'transfer_state.json')
    with open(state_file, 'w', encoding='utf-8') as f:
        json.dump(transfer_state, f, ensure_ascii=False, indent=2)
    
    log("创建转写状态文件", "OK")
    
    # 扫描并转写活跃会话
    log("开始扫描活跃会话文件...", "INFO")
    active_sessions = scan_active_sessions()
    
    if active_sessions:
        log(f"发现 {len(active_sessions)} 个活跃会话", "INFO")
        process_active_sessions(active_sessions)
    else:
        log("未发现活跃会话，转写步骤完成", "OK")
    
    return initial_l0_path

def scan_active_sessions():
    """扫描活跃会话文件"""
    sessions_dir = '/root/.openclaw/agents/main/sessions'
    active = []
    
    if os.path.exists(sessions_dir):
        for f in os.listdir(sessions_dir):
            if f.endswith('.jsonl') and 'checkpoint' not in f and 'trajectory' not in f:
                path = os.path.join(sessions_dir, f)
                size = os.path.getsize(path)
                if size > 1024:  # 只处理大于1KB的文件
                    active.append({
                        'path': path,
                        'name': f,
                        'size': size
                    })
    
    return active

def process_active_sessions(sessions):
    """处理活跃会话文件"""
    for session in sessions:
        log(f"转写会话: {session['name']} ({session['size']/1024:.1f}KB)", "INFO")
        
        # 这里会触发L0 Watcher的自动处理
        # L0 Watcher会监听.jsonl文件并实时追加到L0存档
        # 达到2MB时会自动分离
        
        # 立即触发一次处理，确保会话被追加
        try:
            from l0_watcher import archive_session
            result, info = archive_session(session['path'], 'main')
            if result:
                log(f"  会话已追加: {os.path.basename(info)}", "OK")
        except Exception as e:
            log(f"  转写失败: {e}", "WARN")

# ==================== 步骤8：生成WORD文档2 ====================

def generate_word_doc_phase2():
    """生成新记忆WORD日志文档"""
    log_section("步骤8：生成新记忆WORD日志文档")
    
    try:
        doc_script = os.path.join(SCRIPT_DIR, 'generate_docx.py')
        if os.path.exists(doc_script):
            result = subprocess.run(
                ['python3', doc_script],
                capture_output=True,
                text=True,
                timeout=60
            )
            if result.returncode == 0:
                output = result.stdout.strip()
                log(f"新记忆WORD文档生成完成: {output}", "OK")
            else:
                log(f"WORD文档生成失败: {result.stderr}", "ERROR")
        else:
            log("generate_docx.py 不存在，跳过", "WARN")
    except Exception as e:
        log(f"WORD文档生成异常: {e}", "ERROR")

# ==================== 步骤9：激活L0 Watcher ====================

def activate_l0_watcher():
    """激活L0 Watcher"""
    log_section("步骤9：激活L0 Watcher")
    
    # 检查是否已在运行
    result = subprocess.run(
        ['ps aux | grep l0_watcher | grep -v grep'],
        shell=True,
        capture_output=True,
        text=True
    )
    
    if result.stdout.strip():
        log("L0 Watcher 已在运行中", "OK")
    else:
        # 启动L0 Watcher
        try:
            l0_script = os.path.join(SCRIPT_DIR, 'l0_watcher.py')
            if os.path.exists(l0_script):
                subprocess.Popen(
                    ['python3', l0_script],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL
                )
                log("L0 Watcher 已启动", "OK")
            else:
                log("l0_watcher.py 不存在，无法启动", "ERROR")
        except Exception as e:
            log(f"启动L0 Watcher失败: {e}", "ERROR")
    
    # 验证L0 Watcher状态
    import time
    time.sleep(2)
    result = subprocess.run(
        ['ps aux | grep l0_watcher | grep -v grep'],
        shell=True,
        capture_output=True,
        text=True
    )
    
    if result.stdout.strip():
        log("L0 Watcher 状态: 运行中", "OK")
    else:
        log("L0 Watcher 状态: 未运行", "WARN")

# ==================== 步骤10：OpenClaw集成 ====================

def setup_openclaw_integration():
    """设置OpenClaw集成（cron自动启动+健康检查）"""
    log_section("步骤10：OpenClaw集成配置")
    
    # 检查健康检查脚本
    health_script = os.path.join(SCRIPT_DIR, 'health_check.py')
    if not os.path.exists(health_script):
        log("health_check.py 不存在，跳过集成", "WARN")
        return False
    
    # 1. 设置cron自动启动
    cron_entry = f"@reboot nohup python3 {SCRIPT_DIR}/l0_watcher.py > /tmp/l0_watcher.log 2>&1 &"
    
    try:
        # 读取现有crontab
        result = subprocess.run(['crontab', '-l'], capture_output=True, text=True)
        existing_cron = result.stdout if result.returncode == 0 else ""
        
        # 检查是否已有double-driver的cron
        if 'double-driver-memory' in existing_cron or 'l0_watcher.py' in existing_cron:
            # 替换旧的stratum-memory cron
            lines = existing_cron.split('\n')
            new_lines = []
            for line in lines:
                if 'stratum-memory' not in line and 'l0_watcher.py' not in line:
                    new_lines.append(line)
            new_cron = '\n'.join(new_lines)
        else:
            new_cron = existing_cron
        
        # 添加新的cron
        if new_cron.strip():
            new_cron += '\n'
        new_cron += cron_entry
        
        # 保存crontab
        subprocess.run(['crontab', '-'], input=new_cron, text=True)
        log("Cron自动启动配置: 已添加", "OK")
        
    except Exception as e:
        log(f"Cron配置失败: {e}", "WARN")
    
    # 2. 创建OpenClaw健康检查脚本链接
    # 在systemd服务目录下创建检查脚本（用于systemd restart时检查）
    check_script_path = '/usr/local/bin/openclaw-memory-check.sh'
    try:
        with open(check_script_path, 'w', encoding='utf-8') as f:
            f.write(f"#!/bin/bash\n")
            f.write(f"# 双驱系统健康检查\n")
            f.write(f"python3 {health_script}\n")
        os.chmod(check_script_path, 0o755)
        log(f"健康检查脚本: {check_script_path}", "OK")
    except Exception as e:
        log(f"健康检查脚本创建失败: {e}", "WARN")
    
    # 3. 运行首次健康检查
    try:
        result = subprocess.run(
            ['python3', health_script],
            capture_output=True,
            text=True,
            timeout=30
        )
        if result.returncode == 0:
            log("健康检查: 通过", "OK")
        else:
            log("健康检查: 需注意", "WARN")
    except Exception as e:
        log(f"健康检查执行失败: {e}", "WARN")
    
    log("OpenClaw集成配置完成", "OK")
    return True

# ==================== 主流程 ====================

def main():
    """主初始化流程"""
    print(f"\n{Colors.BOLD}{'='*60}")
    print("双驱三维归一记忆系统 - 初始化向导")
    print(f"{'='*60}{Colors.ENDC}\n")
    
    start_time = datetime.now()
    log(f"开始时间: {start_time.strftime('%Y-%m-%d %H:%M:%S')}", "INFO")
    
    # 步骤1：环境检查
    if not check_environment():
        log("环境检查未通过，请先安装依赖", "ERROR")
        return False
    
    # 步骤1.5：Embedding 后端检查
    if not check_embedding_backend():
        log("Embedding 后端配置未完成", "ERROR")
        return False
    
    # 步骤2：初始化目录
    if not initialize_directories():
        log("目录初始化失败", "ERROR")
        return False
    
    # 步骤3：检查旧记忆文件
    old_files = check_old_memory_files()
    
    # 步骤4：处理旧记忆文件
    if old_files:
        process_old_files(old_files)
        
        # 步骤5：构建向量索引
        build_vector_index()
        
        # 步骤6：生成WORD文档1
        generate_word_doc_phase1()
    
    # 步骤7：创建初始文件
    initial_file = create_initial_files()
    
    # 步骤8：生成WORD文档2
    generate_word_doc_phase2()
    
    # 步骤9：激活L0 Watcher
    activate_l0_watcher()
    
    # 步骤10：OpenClaw集成
    setup_openclaw_integration()
    
    # 完成
    end_time = datetime.now()
    duration = (end_time - start_time).total_seconds()
    
    log_section("初始化完成")
    log(f"结束时间: {end_time.strftime('%Y-%m-%d %H:%M:%S')}", "INFO")
    log(f"总耗时: {duration:.1f} 秒", "INFO")
    log(f"初始文件: {initial_file}", "INFO")
    log(f"记忆目录: {MEMORY_SESSIONS}", "INFO")
    log(f"向量索引: {os.path.join(WORKSPACE, 'vector_store')}", "INFO")
    
    print(f"\n{Colors.BOLD}初始化流程完成！系统已进入正常工作状态。{Colors.ENDC}\n")
    
    return True

if __name__ == "__main__":
    # 处理命令行参数
    if len(sys.argv) > 1 and sys.argv[1] == '--dry-run':
        print("========== 模拟运行（不实际执行）==========\n")
        print("[DRY-RUN] 环境检查...")
        print("[DRY-RUN] 初始化目录...")
        print("[DRY-RUN] 检查旧记忆文件...")
        print("[DRY-RUN] 处理旧记忆文件（生成L0 → L1/L2/L3 → 向量索引）...")
        print("[DRY-RUN] 生成WORD文档1...")
        print("[DRY-RUN] 创建初始文件...")
        print("[DRY-RUN] 生成WORD文档2...")
        print("[DRY-RUN] 激活L0 Watcher...")
        print("\n========== 模拟运行结束 ==========")
    else:
        main()
