#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
双驱三维归一记忆系统 - L0 Watcher
===================================
L0 原始层实时监听器

功能：
1. 监听 OpenClaw .jsonl 文件变动
2. 实时追加到 L0 存档 .md
3. 达到 4MB 阈值时分离 2MB 到历史文件
4. 自动触发 L1/L2/L3 分类处理
5. 启动时检查并补全停机期间的会话
6. 记录运行日志（每个会话更新时间戳）

触发规则：
- 阈值：4MB
- 分离大小：2MB
- 冷却：3 次检查
"""

import os
import sys
import json
import time
import logging
import subprocess
from datetime import datetime
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

# 路径配置
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    from paths_config import (
        WORKSPACE, MEMORY_DIR, MEMORY_SESSIONS,
        L0_SIZE_LIMIT, SEPARATE_SIZE,
        get_all_agent_sessions, find_openclaw_json
    )
except ImportError:
    print("[WARN] paths_config not found, using defaults")
    WORKSPACE = "/root/.openclaw/workspace/main"
    MEMORY_DIR = os.path.join(WORKSPACE, "memory")
    MEMORY_SESSIONS = os.path.join(MEMORY_DIR, "sessions")
    L0_SIZE_LIMIT = 4 * 1024 * 1024  # 4MB
    SEPARATE_SIZE = 2 * 1024 * 1024  # 2MB
    def get_all_agent_sessions():
        return [{'id': 'main', 'sessions_dir': '/root/.openclaw/agents/main/sessions'}]
    def find_openclaw_json():
        return "/root/.openclaw/openclaw.json"

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
SKILL_DIR = os.path.dirname(SCRIPT_DIR)

# 日志配置 - 放在技能目录下
LOG_DIR = os.path.join(SKILL_DIR, 'logs')
os.makedirs(LOG_DIR, exist_ok=True)
LOG_FILE = os.path.join(LOG_DIR, "l0_watcher.log")
RUN_LOG_FILE = os.path.join(LOG_DIR, "l0_session_log.json")  # 会话更新日志
STATUS_FILE = os.path.join(LOG_DIR, "l0_watcher_status.json")  # 状态文件（记录停止时间）

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s %(message)s',
    handlers=[
        logging.FileHandler(LOG_FILE, encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# ==================== 运行日志管理 ====================

def load_run_log():
    """加载会话更新日志"""
    if os.path.exists(RUN_LOG_FILE):
        try:
            with open(RUN_LOG_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return {}
    return {}

def save_run_log(log_data):
    """保存会话更新日志"""
    try:
        with open(RUN_LOG_FILE, 'w', encoding='utf-8') as f:
            json.dump(log_data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        logger.error(f"[L0-日志] 保存运行日志失败: {e}")

def log_session_update(session_id, action, details=None):
    """记录会话更新时间戳"""
    log_data = load_run_log()
    timestamp = datetime.now().isoformat()
    
    if session_id not in log_data:
        log_data[session_id] = {
            'updates': [],
            'last_action': None,
            'last_update': None
        }
    
    entry = {
        'timestamp': timestamp,
        'action': action,  # 'start', 'append', 'separate', 'archive'
        'details': details
    }
    log_data[session_id]['updates'].append(entry)
    log_data[session_id]['last_action'] = action
    log_data[session_id]['last_update'] = timestamp
    
    save_run_log(log_data)
    logger.info(f"[L0-日志] {session_id[:16]}... [{action}] {timestamp}")

def get_session_last_update(session_id):
    """获取会话最后更新时间"""
    log_data = load_run_log()
    if session_id in log_data:
        return log_data[session_id].get('last_update')
    return None

# ==================== 状态管理 ====================

def load_status():
    """加载状态文件"""
    if os.path.exists(STATUS_FILE):
        try:
            with open(STATUS_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            pass
    return {'running': False, 'last_stop': None, 'last_start': None}

def save_status(status):
    """保存状态文件"""
    try:
        with open(STATUS_FILE, 'w', encoding='utf-8') as f:
            json.dump(status, f, ensure_ascii=False, indent=2)
    except Exception as e:
        logger.error(f"[L0-状态] 保存状态失败: {e}")

def mark_started():
    """标记启动"""
    status = load_status()
    status['running'] = True
    status['last_start'] = datetime.now().isoformat()
    save_status(status)
    logger.info(f"[L0-状态] 标记启动: {status['last_start']}")

def mark_stopped():
    """标记停止"""
    status = load_status()
    status['running'] = False
    status['last_stop'] = datetime.now().isoformat()
    save_status(status)
    logger.info(f"[L0-状态] 标记停止: {status['last_stop']}")

# ==================== 启动补全检查 ====================

def check_recovery():
    """启动时检查并补全停机期间的会话"""
    status = load_status()
    last_stop = status.get('last_stop')
    
    if not last_stop:
        logger.info("[L0-恢复] 首次启动，无需恢复检查")
        return
    
    logger.info(f"[L0-恢复] 上次停止时间: {last_stop}")
    
    # 获取所有会话文件
    agents = get_all_agent_sessions()
    recovered_count = 0
    
    for agent in agents:
        sessions_dir = agent['sessions_dir']
        if not os.path.exists(sessions_dir):
            continue
        
        for filename in os.listdir(sessions_dir):
            if not filename.endswith('.jsonl') or '.lock' in filename:
                continue
            
            jsonl_path = os.path.join(sessions_dir, filename)
            session_id = os.path.splitext(filename)[0]
            
            # 检查该会话是否有未归档的更新
            last_update = get_session_last_update(session_id)
            
            if last_update and last_update > last_stop:
                # 会话在停止期间有更新
                logger.info(f"[L0-恢复] 发现停机期间更新的会话: {session_id[:16]}...")
                recovered_count += 1
    
    if recovered_count > 0:
        logger.info(f"[L0-恢复] 共发现 {recovered_count} 个会话需要补全处理")
    else:
        logger.info(f"[L0-恢复] 无需补全，所有会话已归档")

# ==================== 工具函数 ====================

def safe_ts(ts):
    """解析时间戳"""
    if ts is None:
        return None
    if isinstance(ts, str):
        try:
            if 'T' in ts:
                return datetime.fromisoformat(ts.replace('Z', '+00:00'))
            return datetime.strptime(ts, '%Y-%m-%d %H:%M:%S')
        except:
            return None
    return None

def load_log():
    """加载归档日志"""
    log_path = os.path.join(MEMORY_SESSIONS, "l0_archive_log.json")
    if os.path.exists(log_path):
        try:
            with open(log_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return {}
    return {}

def save_log(log_data):
    """保存归档日志"""
    log_path = os.path.join(MEMORY_SESSIONS, "l0_archive_log.json")
    try:
        with open(log_path, 'w', encoding='utf-8') as f:
            json.dump(log_data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        logger.error(f"[L0-归档日志] 保存失败: {e}")

def parse_jsonl(path):
    """解析 jsonl 文件"""
    messages = []
    if not os.path.exists(path):
        return messages
    try:
        with open(path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    messages.append(json.loads(line))
                except:
                    continue
    except Exception as e:
        logger.error(f"[L0-解析] 读取文件失败 {path}: {e}")
    return messages

def format_message(entry):
    """格式化消息为可读文本"""
    # 尝试提取消息内容
    role = entry.get('role', 'unknown')
    
    # 处理不同格式
    if 'content' in entry:
        content = entry['content']
    elif 'message' in entry:
        content = entry['message']
    else:
        content = str(entry)
    
    # 截断过长内容
    if len(content) > 500:
        content = content[:500] + "..."
    
    # 获取时间戳
    ts = entry.get('timestamp') or entry.get('time')
    if ts:
        dt = safe_ts(ts)
        if dt:
            ts_str = dt.strftime('%Y-%m-%d %H:%M:%S')
        else:
            ts_str = str(ts)
    else:
        ts_str = 'unknown'
    
    return f"[{ts_str}] {role}: {content}"

def check_size_threshold(jsonl_path):
    """检查文件是否超过阈值"""
    try:
        size = os.path.getsize(jsonl_path)
        return size >= L0_SIZE_LIMIT
    except:
        return False

def get_archive_path(session_id):
    """获取当前会话的存档路径"""
    log = load_log()
    if session_id in log:
        return log[session_id].get('archived_path')
    return None

def archive_session(jsonl_path, agent_id='main'):
    """将会话归档到 L0"""
    session_id = os.path.splitext(os.path.basename(jsonl_path))[0]
    messages = parse_jsonl(jsonl_path)
    
    if not messages:
        return False, "no_messages"
    
    # 生成存档文件名
    first_ts = safe_ts(messages[0].get('timestamp')) if messages else datetime.now()
    archive_name = f"{agent_id}-{first_ts.strftime('%Y-%m-%d-%H%M')}-{session_id[:8]}.md"
    archive_path = os.path.join(MEMORY_SESSIONS, archive_name)
    
    # 写入存档
    with open(archive_path, 'w', encoding='utf-8') as f:
        f.write(f"# {session_id}\n\n")
        f.write(f"**归档时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"**消息数**: {len(messages)}\n\n")
        f.write("---\n\n")
        for msg in messages:
            f.write(format_message(msg) + "\n\n")
    
    # 更新日志
    log = load_log()
    log[session_id] = {
        'archived_path': archive_path,
        'archived_at': datetime.now().isoformat(),
        'message_count': len(messages)
    }
    save_log(log)
    
    logger.info(f"[L0-归档] {session_id[:16]}... -> {archive_name} ({len(messages)} 条)")
    log_session_update(session_id, 'archive', {'count': len(messages), 'file': archive_name})
    
    return True, archive_path

def separate_and_archive(jsonl_path, agent_id='main'):
    """超过 4MB 阈值时分离并归档"""
    session_id = os.path.splitext(os.path.basename(jsonl_path))[0]
    basename = os.path.basename(jsonl_path)

    # 跳过非活跃文件
    if '.reset.' in basename or '.deleted.' in basename or '.lock' in basename:
        return False, 'skipped'

    try:
        # 读取全部内容
        with open(jsonl_path, 'r', encoding='utf-8') as f:
            content = f.read()

        total_size = len(content.encode('utf-8'))

        if total_size <= L0_SIZE_LIMIT:
            return False, 'not_exceeded'

        # 从头分离 2MB 内容（最早的对话）
        separate_content = ''
        remaining_content = content

        if total_size > SEPARATE_SIZE:
            bytes_count = 0
            lines = content.split('\n')
            for i, line in enumerate(lines):
                line_bytes = len((line + '\n').encode('utf-8'))
                if bytes_count + line_bytes <= SEPARATE_SIZE:
                    separate_content += line + '\n'
                    bytes_count += line_bytes
                else:
                    remaining_content = '\n'.join(lines[i:])
                    if content.endswith('\n'):
                        remaining_content += '\n'
                    break
        else:
            separate_content = content
            remaining_content = ''

        # 生成历史文件名
        messages = parse_jsonl(jsonl_path)
        first_ts = safe_ts(messages[0].get('timestamp')) if messages else datetime.now()
        hist_date = first_ts.strftime('%Y-%m-%d') if first_ts else 'unknown'
        hist_time = first_ts.strftime('%H%M') if first_ts else '0000'

        hist_name = f"{agent_id}-hist-{hist_date}-{hist_time}-{session_id[:8]}.md"
        hist_path = os.path.join(MEMORY_SESSIONS, hist_name)

        # 写入历史文件
        with open(hist_path, 'w', encoding='utf-8') as f:
            f.write(separate_content)

        logger.info(f"[L0-历史分离] {session_id[:16]}... 分离 {len(separate_content)} bytes -> {hist_name}")

        # 更新当前文件（只保留剩余内容）
        with open(jsonl_path, 'w', encoding='utf-8') as f:
            f.write(remaining_content)

        logger.info(f"[L0-保留] {session_id[:16]}... 保留 {len(remaining_content)} bytes")

        # 记录到日志
        log = load_log()
        log[session_id] = {
            'archived_path': hist_path,
            'archived_at': datetime.now().isoformat(),
            'reason': '4mb_threshold_separate',
            'separate_size': len(separate_content),
            'remaining_size': len(remaining_content)
        }
        save_log(log)

        # 触发 L1/L2/L3 处理
        trigger_l1_l2_processing(hist_path)
        
        log_session_update(session_id, 'separate', {
            'hist_file': hist_name,
            'separated_bytes': len(separate_content),
            'remaining_bytes': len(remaining_content)
        })

        return True, hist_path

    except Exception as e:
        logger.error(f"[L0-分离失败] {session_id[:16]}...: {e}")
        return False, str(e)

def trigger_l1_l2_processing(hist_path):
    """触发 L1/L2/L3 处理脚本"""
    try:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        migrate_script = os.path.join(script_dir, 'migrate_l1_l2.py')

        if os.path.exists(migrate_script):
            subprocess.Popen(
                ['python3', migrate_script, '--single', hist_path],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
            logger.info(f"[L0-L1L2触发] 已触发处理: {os.path.basename(hist_path)}")
        else:
            logger.warn(f"[L0-L1L2触发] 脚本不存在: {migrate_script}")
    except Exception as e:
        logger.error(f"[L0-L1L2触发失败] {e}")

# ==================== 文件监听 ====================

class SessionHandler(FileSystemEventHandler):
    def __init__(self, sessions_dir, agent_id='main'):
        super().__init__()
        self.sessions_dir = sessions_dir
        self.agent_id = agent_id
        self.log = load_log()
        self.processed_lines = {}  # session_id -> last_line_count
        self.just_truncated = {}   # session_id -> cooldown counter

    def on_modified(self, event):
        if event.is_directory:
            return
        path = event.src_path
        if not path.endswith('.jsonl') or '.lock' in path:
            return

        session_id = os.path.splitext(os.path.basename(path))[0]
        basename = os.path.basename(path)

        if '.reset.' in basename or '.deleted.' in basename:
            return

        # 冷却机制：分离后跳过 3 次检查
        if session_id in self.just_truncated and self.just_truncated[session_id] > 0:
            self.just_truncated[session_id] -= 1
            return

        try:
            # 检查文件大小是否超过 4MB 阈值
            if check_size_threshold(path):
                logger.info(f"[L0-阈值触发] {session_id[:16]}... 超过{L0_SIZE_LIMIT}字节({L0_SIZE_LIMIT//1024//1024}MB)，执行分离...")
                result = separate_and_archive(path, self.agent_id)
                if result[0]:
                    # 设置冷却：分离后跳过 3 次检查
                    self.just_truncated[session_id] = 3
                    self.processed_lines[session_id] = 0
                return

            # 获取当前行数
            with open(path, 'r', encoding='utf-8') as f:
                lines = f.readlines()

            current_lines = len(lines)
            last_processed = self.processed_lines.get(session_id, 0)

            if current_lines <= last_processed:
                return

            # 只处理新增行
            new_lines = lines[last_processed:]
            self.processed_lines[session_id] = current_lines

            # 解析新消息
            new_messages = []
            for line in new_lines:
                line = line.strip()
                if not line:
                    continue
                try:
                    new_messages.append(json.loads(line))
                except:
                    continue

            if not new_messages:
                return

            logger.info(f"[L0-实时] [{self.agent_id}] {session_id[:16]}... 新增 {len(new_messages)} 条消息")

            # 更新存档（追加模式）
            self._append_to_archive(session_id, path, new_messages)

        except Exception as e:
            logger.error(f"[L0-错误] [{self.agent_id}] {session_id[:16]}...: {e}")

    def _append_to_archive(self, session_id, jsonl_path, new_messages):
        log = load_log()
        existing = log.get(session_id, {}).get('archived_path')

        if existing and os.path.exists(existing):
            # 追加到现有存档
            with open(existing, 'a', encoding='utf-8') as f:
                for msg in new_messages:
                    f.write(format_message(msg) + "\n\n")
            logger.info(f"[L0-追加] {session_id[:16]}... +{len(new_messages)} 条 -> {os.path.basename(existing)}")
            log_session_update(session_id, 'append', {'count': len(new_messages)})
        else:
            # 新会话，先创建存档
            messages = parse_jsonl(jsonl_path)
            if messages:
                first_ts = safe_ts(messages[0].get('timestamp')) if messages else datetime.now()
                archive_name = f"{self.agent_id}-{first_ts.strftime('%Y-%m-%d-%H%M')}-{session_id[:8]}.md"
                archive_path = os.path.join(MEMORY_SESSIONS, archive_name)

                with open(archive_path, 'w', encoding='utf-8') as f:
                    f.write(f"# {session_id}\n\n")
                    f.write(f"**归档时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                    f.write(f"**消息数**: {len(messages)}\n\n")
                    f.write("---\n\n")
                    for msg in messages:
                        f.write(format_message(msg) + "\n\n")

                log[session_id] = {
                    'archived_path': archive_path,
                    'archived_at': datetime.now().isoformat(),
                    'message_count': len(messages)
                }
                save_log(log)
                logger.info(f"[L0-新建] {session_id[:16]}... -> {archive_name} ({len(messages)} 条)")
                log_session_update(session_id, 'start', {'count': len(new_messages), 'file': archive_name})

    def on_created(self, event):
        """新会话创建时记录"""
        if event.is_directory:
            return
        path = event.src_path
        if not path.endswith('.jsonl') or '.lock' in path:
            return
        
        session_id = os.path.splitext(os.path.basename(path))[0]
        logger.info(f"[L0-新会话] {session_id[:16]}...")
        log_session_update(session_id, 'created', {'file': os.path.basename(path)})

# ==================== 主函数 ====================

def main():
    logger.info("=" * 50)
    logger.info("[双驱三维归一记忆系统] L0 Watcher 启动")
    logger.info(f"工作区: {WORKSPACE}")
    logger.info(f"存档目录: {MEMORY_SESSIONS}")
    logger.info(f"触发阈值: {L0_SIZE_LIMIT} bytes ({L0_SIZE_LIMIT//1024//1024}MB)")
    logger.info(f"分离大小: {SEPARATE_SIZE} bytes ({SEPARATE_SIZE//1024//1024}MB)")

    # 标记启动
    mark_started()
    
    # 启动补全检查
    check_recovery()

    # 获取所有智能体的会话目录
    agents = get_all_agent_sessions()
    logger.info(f"监控 {len(agents)} 个智能体的会话目录:")
    for agent in agents:
        logger.info(f"  - {agent['id']}: {agent['sessions_dir']}")

    logger.info("=" * 50)

    # 启动监听（每个 agent 一个 observer）
    observers = []
    for agent in agents:
        sessions_dir = agent['sessions_dir']
        if os.path.exists(sessions_dir):
            handler = SessionHandler(sessions_dir, agent['id'])
            observer = Observer()
            observer.schedule(handler, sessions_dir, recursive=False)
            observer.start()
            observers.append(observer)
            logger.info(f"[L0-监听中] {agent['id']} @ {sessions_dir}")
        else:
            logger.warning(f"[L0-警告] 目录不存在: {sessions_dir}")

    try:
        logger.info("[L0-运行中] Ctrl+C 停止")
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        logger.info("[L0-停止] 监控系统退出")
        mark_stopped()
        for observer in observers:
            observer.stop()
    for observer in observers:
        observer.join()

if __name__ == "__main__":
    main()
