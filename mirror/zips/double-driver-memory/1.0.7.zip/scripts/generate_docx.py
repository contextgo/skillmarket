#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
双驱三维归一记忆系统 - Word 文档生成工具
"""

from docx import Document
from docx.shared import Inches, Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.table import WD_TABLE_ALIGNMENT
from datetime import datetime
import os

def create_document():
    doc = Document()
    
    # ==================== 标题设置 ====================
    title = doc.add_heading('双驱三维归一记忆系统', 0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    subtitle = doc.add_paragraph('完整操作手册与技术文档')
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    subtitle_run = subtitle.runs[0]
    subtitle_run.font.size = Pt(14)
    subtitle_run.font.color.rgb = RGBColor(100, 100, 100)
    
    doc.add_paragraph(f'版本：1.0 | 日期：{datetime.now().strftime("%Y-%m-%d")} | 状态：正式发布')
    doc.add_paragraph('')
    
    # ==================== 目录 ====================
    doc.add_heading('目录', level=1)
    toc_items = [
        '一、系统概述',
        '二、核心架构',
        '三、系统流程',
        '四、目录结构',
        '五、核心脚本说明',
        '六、快速开始',
        '七、WAL 标记规范',
        '八、故障排查',
        '九、配置说明',
        '十、常见问题'
    ]
    for item in toc_items:
        p = doc.add_paragraph(item)
        p.paragraph_format.left_indent = Cm(1)
    
    doc.add_page_break()
    
    # ==================== 第一章：系统概述 ====================
    doc.add_heading('一、系统概述', level=1)
    
    doc.add_heading('1.1 设计背景', level=2)
    doc.add_paragraph(
        '双驱三维归一记忆系统是专为 AI 智能体设计的长期记忆解决方案。'
        '随着智能体运行时间增长，会话历史不断累积，导致上下文膨胀、记忆衰退、'
        '关键决策难以追溯等问题。本系统通过「双驱×三维×归一」的设计理念，'
        '实现记忆的高效存储、快速召回和完整追溯。'
    )
    
    doc.add_heading('1.2 核心问题与解决方案', level=2)
    
    # 问题-方案表格
    table = doc.add_table(rows=6, cols=2)
    table.style = 'Table Grid'
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    
    # 表头
    header_cells = table.rows[0].cells
    header_cells[0].text = '问题'
    header_cells[1].text = '解决方案'
    for cell in header_cells:
        cell.paragraphs[0].runs[0].bold = True
    
    problems = [
        ('记忆随时间衰退', '双向量索引驱动，快速召回历史记忆'),
        ('上下文无限膨胀', '4MB 阈值触发分离，保持轻盈当前会话'),
        ('关键决策被遗忘', 'L1 决策记录层，实时提取 WAL 标记'),
        ('历史信息难以查找', '三维分类追溯，精准定位原始记忆'),
        ('新会话从零开始', '归一原始层，追溯最真实记忆来源'),
    ]
    for i, (problem, solution) in enumerate(problems):
        row = table.rows[i + 1]
        row.cells[0].text = problem
        row.cells[1].text = solution
    
    doc.add_paragraph('')
    
    doc.add_heading('1.3 系统公式', level=2)
    formula = doc.add_paragraph()
    formula_run = formula.add_run('双驱 × 三维 × 归一 = 完整记忆系统')
    formula_run.bold = True
    formula_run.font.size = Pt(14)
    formula.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    explanation = doc.add_paragraph()
    explanation.add_run('双驱 = ').bold = True
    explanation.add_run('2 个向量索引（搜索入口）\n')
    explanation.add_run('三维 = ').bold = True
    explanation.add_run('3 个分类追溯层\n')
    explanation.add_run('归一 = ').bold = True
    explanation.add_run('1 个原始层')
    explanation.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    # ==================== 第二章：核心架构 ====================
    doc.add_heading('二、核心架构', level=1)
    
    doc.add_heading('2.1 架构总览', level=2)
    doc.add_paragraph(
        '系统采用「双驱×三维×归一」的六角架构，六个核心概念构成完整记忆体系：'
    )
    
    # 架构图示（用表格模拟）
    arch_table = doc.add_table(rows=4, cols=1)
    arch_table.alignment = WD_TABLE_ALIGNMENT.CENTER
    
    rows_data = [
        ('【双驱】向量索引层', 'memory_index.faiss（个人记忆） | knowledge_index.faiss（业务知识）'),
        ('【三维】分类追溯层', 'L3 用户画像 → L2 场景分块 → L1 决策记录'),
        ('【归一】原始存档层', 'L0 原始对话存档（最真实的记忆来源）'),
    ]
    for i, (layer, desc) in enumerate(rows_data):
        arch_table.rows[i].cells[0].text = f'{layer}\n{desc}'
    
    doc.add_paragraph('')
    
    doc.add_heading('2.2 双驱 — 向量索引层', level=2)
    
    doc.add_heading('memory_index（个人记忆索引）', level=3)
    mem_items = [
        '内容：L0/L1/L2/L3 全部记忆文件',
        '用途：个人记忆搜索、决策追溯',
        '位置：/workspace/main/vector_store/memory_index.faiss'
    ]
    for item in mem_items:
        p = doc.add_paragraph(item, style='List Bullet')
    
    doc.add_heading('knowledge_index（业务知识索引）', level=3)
    kb_items = [
        '内容：knowledge-repo 外部知识库',
        '用途：业务知识搜索、产品查询',
        '位置：/workspace/main/vector_store/knowledge_index.faiss'
    ]
    for item in kb_items:
        p = doc.add_paragraph(item, style='List Bullet')
    
    doc.add_heading('2.3 三维 — 分类追溯层', level=2)
    
    doc.add_heading('L3 用户画像层', level=3)
    l3_items = [
        '内容：用户偏好、习惯、重要信息',
        '文件：SOUL.md、USER.md、MEMORY.md',
        '特点：长期不变，跨会话通用'
    ]
    for item in l3_items:
        p = doc.add_paragraph(item, style='List Bullet')
    
    doc.add_heading('L2 场景分块层', level=3)
    l2_items = [
        '内容：按业务场景组织的记忆',
        '分类：business（客户/GEO/跟进）、knowledge（记忆/日志）、system（系统/配置）',
        '文件：projects/{type}/main-{date}.md'
    ]
    for item in l2_items:
        p = doc.add_paragraph(item, style='List Bullet')
    
    doc.add_heading('L1 决策记录层', level=3)
    l1_items = [
        '内容：WAL 标记提取的决策信息',
        '标记：[决策]、[操作]、[数字]、[问题] 等',
        '文件：LOG-{date}-{seq}.md'
    ]
    for item in l1_items:
        p = doc.add_paragraph(item, style='List Bullet')
    
    doc.add_heading('2.4 归一 — 原始存档层', level=2)
    doc.add_paragraph(
        'L0 是所有记忆的最终来源，保证信息完整性：'
    )
    l0_items = [
        '当前存档：{agent}-{date}-{time}-{id}.md',
        '历史分离：{agent}-hist-{date}-{time}-{id}.md',
        '特点：完整保留原始对话，不做任何处理'
    ]
    for item in l0_items:
        p = doc.add_paragraph(item, style='List Bullet')
    
    # ==================== 第三章：系统流程 ====================
    doc.add_heading('三、系统流程', level=1)
    
    doc.add_heading('3.1 记忆召回流程（双驱驱动）', level=2)
    
    recall_steps = [
        ('步骤 1：用户发起查询', '输入：「查找关于 XX 决策的记忆」'),
        ('步骤 2：双驱启动', '并行搜索 memory_index 和 knowledge_index'),
        ('步骤 3：三维追溯', 'L3 用户画像 → L2 场景分块 → L1 决策记录'),
        ('步骤 4：归一追溯', '根据 path 字段定位 L0 原始文件'),
    ]
    for step, desc in recall_steps:
        p = doc.add_paragraph()
        p.add_run(f'{step}\n').bold = True
        p.add_run(desc)
        p.paragraph_format.left_indent = Cm(1)
    
    doc.add_heading('3.2 记忆归档流程（自动触发）', level=2)
    
    archive_steps = [
        ('步骤 1：会话进行中', 'OpenClaw 实时写入 .jsonl 文件'),
        ('步骤 2：L0 Watcher 监听', '实时追加到 L0 存档 .md'),
        ('步骤 3：达到 4MB 阈值', '分离最早的 2MB 内容到历史文件'),
        ('步骤 4：触发三维分类', '自动调用 migrate_l1_l2.py'),
        ('步骤 5：更新向量索引', '增量添加新内容到索引'),
    ]
    for step, desc in archive_steps:
        p = doc.add_paragraph()
        p.add_run(f'{step}\n').bold = True
        p.add_run(desc)
        p.paragraph_format.left_indent = Cm(1)
    
    # ==================== 第四章：目录结构 ====================
    doc.add_heading('四、目录结构', level=1)
    
    doc.add_paragraph('工作区目录结构如下：')
    
    dir_table = doc.add_table(rows=15, cols=2)
    dir_table.style = 'Table Grid'
    
    dir_header = dir_table.rows[0].cells
    dir_header[0].text = '路径'
    dir_header[1].text = '说明'
    for cell in dir_header:
        cell.paragraphs[0].runs[0].bold = True
    
    dir_data = [
        ('/workspace/main/SOUL.md', 'L3: AI 灵魂定义'),
        ('/workspace/main/USER.md', 'L3: 用户信息'),
        ('/workspace/main/MEMORY.md', 'L3: 长期记忆'),
        ('/workspace/main/memory/sessions/', 'L0: 原始对话存档'),
        ('/workspace/main/memory/sessions/*.md', '当前存档文件'),
        ('/workspace/main/memory/sessions/*-hist-*.md', '历史分离文件'),
        ('/workspace/main/memory/projects/', 'L2: 场景分块'),
        ('/workspace/main/memory/projects/business/', '业务场景'),
        ('/workspace/main/memory/projects/knowledge/', '知识场景'),
        ('/workspace/main/memory/projects/system/', '系统场景'),
        ('/workspace/main/vector_store/', '向量索引存储'),
        ('/workspace/main/vector_store/memory_index.faiss', '个人记忆索引'),
        ('/workspace/main/vector_store/knowledge_index.faiss', '业务知识索引'),
        ('/workspace/main/knowledge-repo/', '外部知识库'),
    ]
    for i, (path, desc) in enumerate(dir_data):
        row = dir_table.rows[i + 1]
        row.cells[0].text = path
        row.cells[1].text = desc
    
    # ==================== 第五章：核心脚本 ====================
    doc.add_heading('五、核心脚本说明', level=1)
    
    scripts = [
        ('l0_watcher.py', 'L0 实时监听，4MB 触发分离', '后台运行，持续监控'),
        ('migrate_l1_l2.py', 'L0 → L1/L2/L3 分类处理', '自动或手动触发'),
        ('build_index.py', '构建双向量索引', '首次构建或定期重建'),
        ('vector_search.py', '语义搜索', '快速查询记忆'),
        ('system_status.py', '查看系统状态', '诊断系统健康'),
        ('paths_config.py', '路径配置', '自动读取 openclaw.json'),
    ]
    
    script_table = doc.add_table(rows=len(scripts)+1, cols=3)
    script_table.style = 'Table Grid'
    
    script_header = script_table.rows[0].cells
    script_header[0].text = '脚本'
    script_header[1].text = '功能'
    script_header[2].text = '使用方式'
    for cell in script_header:
        cell.paragraphs[0].runs[0].bold = True
    
    for i, (script, func, usage) in enumerate(scripts):
        row = script_table.rows[i + 1]
        row.cells[0].text = script
        row.cells[1].text = func
        row.cells[2].text = usage
    
    # ==================== 第六章：快速开始 ====================
    doc.add_heading('六、快速开始', level=1)
    
    doc.add_heading('6.1 查看系统状态', level=2)
    code1 = doc.add_paragraph()
    code1.add_run('cd /root/.openclaw/workspace/main/skills/double-driver-memory\n'
                 'python3 scripts/system_status.py').font.name = 'Courier New'
    
    doc.add_heading('6.2 启动 L0 Watcher', level=2)
    code2 = doc.add_paragraph()
    code2.add_run('python3 scripts/l0_watcher.py').font.name = 'Courier New'
    
    doc.add_heading('6.3 构建向量索引', level=2)
    code3 = doc.add_paragraph()
    code3.add_run('python3 scripts/build_index.py').font.name = 'Courier New'
    doc.add_paragraph('（首次构建约需 30 分钟）')
    
    doc.add_heading('6.4 语义搜索', level=2)
    code4 = doc.add_paragraph()
    code4.add_run('python3 scripts/vector_search.py search "关键词"').font.name = 'Courier New'
    
    doc.add_heading('6.5 手动运行分类处理', level=2)
    code5 = doc.add_paragraph()
    code5.add_run('# 处理所有 L0 历史文件\n'
                 'python3 scripts/migrate_l1_l2.py\n\n'
                 '# 处理单个文件\n'
                 'python3 scripts/migrate_l1_l2.py --single /path/to/file.md').font.name = 'Courier New'
    
    # ==================== 第七章：WAL 标记 ====================
    doc.add_heading('七、WAL 标记规范（L1 提取）', level=1)
    
    doc.add_paragraph('在对话中使用以下标记，系统会自动提取到 L1 决策记录：')
    
    marker_table = doc.add_table(rows=9, cols=3)
    marker_table.style = 'Table Grid'
    
    marker_header = marker_table.rows[0].cells
    marker_header[0].text = '标记'
    marker_header[1].text = '类型'
    marker_header[2].text = '示例'
    for cell in marker_header:
        cell.paragraphs[0].runs[0].bold = True
    
    markers = [
        ('**[决策]**', '关键决策', '**[决策]**：确认使用方案A'),
        ('**[变更]**', '重要变更', '**[变更]**：更新系统配置'),
        ('**[操作]**', '具体操作', '**[操作]**：执行备份脚本'),
        ('**[问题]**', '发现问题', '**[问题]**：配置文件缺失'),
        ('**[原因]**', '问题根因', '**[原因]**：磁盘空间不足'),
        ('**[解决]**', '解决方法', '**[解决]**：清理临时文件'),
        ('**[数字]**', '关键数字', '**[数字]**：处理 1000 条数据'),
        ('**[状态]**', '状态更新', '**[状态]**：服务已重启'),
    ]
    for i, (marker, mtype, example) in enumerate(markers):
        row = marker_table.rows[i + 1]
        row.cells[0].text = marker
        row.cells[1].text = mtype
        row.cells[2].text = example
    
    doc.add_paragraph('')
    doc.add_paragraph('WAL 格式：')
    wal_format = doc.add_paragraph()
    wal_format.add_run('### [HH:MM]\n'
                      '- **[类型]**：[内容]').font.name = 'Courier New'
    
    # ==================== 第八章：故障排查 ====================
    doc.add_heading('八、故障排查', level=1)
    
    doc.add_heading('8.1 L0 Watcher 无法启动', level=2)
    doc.add_paragraph('检查项：')
    check_items = [
        '运行 ps aux | grep l0_watcher 检查进程',
        '运行 python3 --version 确认 Python 版本',
        '运行 python3 -c "import watchdog" 确认库安装',
    ]
    for item in check_items:
        doc.add_paragraph(item, style='List Bullet')
    
    doc.add_paragraph('解决方案：')
    doc.add_paragraph('pip install watchdog', style='List Bullet')
    
    doc.add_heading('8.2 向量索引搜索无结果', level=2)
    check_items2 = [
        '检查索引文件是否存在：ls -la /workspace/main/vector_store/*.faiss',
        '如不存在，运行：python3 scripts/build_index.py',
    ]
    for item in check_items2:
        doc.add_paragraph(item, style='List Bullet')
    
    doc.add_heading('8.3 L1/L2/L3 没有生成', level=2)
    check_items3 = [
        '确认 L0 历史文件存在：ls /workspace/main/memory/sessions/*-hist-*.md',
        '手动运行分类脚本：python3 scripts/migrate_l1_l2.py',
    ]
    for item in check_items3:
        doc.add_paragraph(item, style='List Bullet')
    
    # ==================== 第九章：配置说明 ====================
    doc.add_heading('九、配置说明', level=1)
    
    doc.add_heading('9.1 L0 阈值配置', level=2)
    doc.add_paragraph('在 scripts/paths_config.py 中：')
    
    config_code = doc.add_paragraph()
    config_code.add_run('# L0 阈值：达到 4MB 时触发归档\n'
                       'L0_SIZE_LIMIT = 4 * 1024 * 1024  # 4MB\n\n'
                       '# 分离大小：每次分离最早的 2MB\n'
                       'SEPARATE_SIZE = 2 * 1024 * 1024  # 2MB').font.name = 'Courier New'
    
    doc.add_heading('9.2 Embedding 后端配置', level=2)
    doc.add_paragraph('支持两种后端模式：')
    
    backend_table = doc.add_table(rows=3, cols=2)
    backend_table.style = 'Table Grid'
    
    backend_header = backend_table.rows[0].cells
    backend_header[0].text = '模式'
    backend_header[1].text = '配置'
    for cell in backend_header:
        cell.paragraphs[0].runs[0].bold = True
    
    backend_table.rows[1].cells[0].text = 'Ollama（推荐）'
    backend_table.rows[1].cells[1].text = 'EMBEDDING_BACKEND = "ollama"\nOLLAMA_URL = "http://localhost:11434"'
    
    backend_table.rows[2].cells[0].text = 'API 模式'
    backend_table.rows[2].cells[1].text = 'EMBEDDING_BACKEND = "api"\nOPENAI_API_KEY = "your-key"'
    
    # ==================== 第十章：常见问题 ====================
    doc.add_heading('十、常见问题', level=1)
    
    qas = [
        ('Q1：为什么要分离 L0 而不是一直累积？',
         'A：L0 文件过大会导致向量索引构建变慢、读取速度下降、难以管理。分离后保持 L0 文件轻盈，同时保留完整历史。'),
        ('Q2：L1/L2/L3 有什么区别？',
         'A：L1 决策记录提取 WAL 标记，适合快速查找决策；L2 场景分块按业务场景组织，适合主题搜索；L3 用户画像包含用户偏好/习惯，适合个性化服务。'),
        ('Q3：可以不分离 L0 吗？',
         'A：可以修改 L0_SIZE_LIMIT 阈值，但建议保持 4MB 以确保系统性能。'),
        ('Q4：如何查看当前 L0 大小？',
         'A：运行 du -sh /workspace/main/memory/sessions/*.md | sort -h'),
        ('Q5：向量索引需要多久重建一次？',
         'A：建议每周重建一次，或在 L0 文件发生重大变化后重建。'),
    ]
    
    for q, a in qas:
        p = doc.add_paragraph()
        p.add_run(q).bold = True
        doc.add_paragraph(a)
    
    # ==================== 附录 ====================
    doc.add_heading('附录 A：系统要求', level=1)
    
    req_table = doc.add_table(rows=5, cols=3)
    req_table.style = 'Table Grid'
    
    req_header = req_table.rows[0].cells
    req_header[0].text = '组件'
    req_header[1].text = '最低'
    req_header[2].text = '推荐'
    for cell in req_header:
        cell.paragraphs[0].runs[0].bold = True
    
    req_data = [
        ('CPU', '4 核', '8 核'),
        ('内存', '8GB', '16GB'),
        ('磁盘', '20GB', '50GB'),
        ('Python', '3.8+', '3.10+'),
    ]
    for i, (comp, min_req, rec) in enumerate(req_data):
        row = req_table.rows[i + 1]
        row.cells[0].text = comp
        row.cells[1].text = min_req
        row.cells[2].text = rec
    
    doc.add_heading('附录 B：版本历史', level=1)
    ver_table = doc.add_table(rows=3, cols=3)
    ver_table.style = 'Table Grid'
    
    ver_header = ver_table.rows[0].cells
    ver_header[0].text = '版本'
    ver_header[1].text = '日期'
    ver_header[2].text = '说明'
    for cell in ver_header:
        cell.paragraphs[0].runs[0].bold = True
    
    ver_table.rows[1].cells[0].text = '1.0'
    ver_table.rows[1].cells[1].text = '2026-04-29'
    ver_table.rows[1].cells[2].text = '正式发布版本'
    
    ver_table.rows[2].cells[0].text = '0.9'
    ver_table.rows[2].cells[1].text = '2026-04-26'
    ver_table.rows[2].cells[2].text = '内部测试版本'
    
    # 保存文档
    output_dir = '/root/.openclaw/workspace/main/memory/docs'
    os.makedirs(output_dir, exist_ok=True)
    output_path = os.path.join(output_dir, '双驱三维归一记忆系统_操作手册.docx')
    doc.save(output_path)
    print(f'文档已生成：{output_path}')
    return output_path

if __name__ == '__main__':
    create_document()
