---
name: xhs-openclaw-scraper
description: Use this skill when the user wants to crawl Xiaohongshu/小红书 notes through OpenClaw by rules such as keyword, recent time range, like/comment thresholds, result limit, and then append the normalized results into a Lark/Feishu spreadsheet. Also use when the user asks to monitor, collect, export, or save 小红书笔记/红书内容 to 飞书表格.
---

# XHS OpenClaw Scraper

## Overview

Collect Xiaohongshu notes with OpenClaw according to user rules, normalize the results, then append them to a Lark spreadsheet with `lark-cli sheets +append`.

Use this skill together with `lark-sheets` when writing to Feishu/Lark spreadsheets.

## Required Inputs

Before running, identify these values from the user request or ask only for missing required items:

- `keyword`: search keyword or topic.
- `time_range`: one of `1m`, `3m`, `6m`, or explicit start/end dates.
- `min_comments`: default `100` when omitted.
- `min_likes`: default `200` when omitted.
- `limit`: default `50` notes when omitted.
- `sheet_url` or `spreadsheet_token` plus optional `sheet_id`: destination Lark sheet.

Optional filters: author keywords, note type, sort order, deduplication by URL/note ID, and whether to include raw JSON.

## Workflow

1. Confirm the crawl is for content the user is authorized to collect and only collect public metadata/content needed for the task.
2. Build a concise OpenClaw agent prompt using `references/openclaw-prompt-template.md`.
3. Run OpenClaw and require JSON output saved to a local file.
4. Normalize and filter the OpenClaw JSON with `scripts/append_xhs_notes_to_lark.py`.
5. Append rows to Lark with a dry-run first unless the user explicitly asked to write immediately.
6. Report row count, filters applied, and destination sheet.

## OpenClaw Invocation

Preferred command shape:

```bash
openclaw agent --local --json --message "<prompt>"
```

If local provider credentials are unavailable, use the gateway form:

```bash
openclaw agent --json --message "<prompt>"
```

The prompt must instruct OpenClaw to return a JSON array or object containing note records. If OpenClaw cannot access Xiaohongshu due to login, CAPTCHA, network, rate limits, or policy restrictions, stop and ask the user to resolve access rather than bypassing controls.

## Output Schema

Normalize each note into these columns in order:

1. `抓取时间`
2. `关键词`
3. `笔记标题`
4. `笔记链接`
5. `作者`
6. `发布时间`
7. `点赞数`
8. `评论数`
9. `收藏数`
10. `摘要`
11. `标签`
12. `笔记ID`

Use `scripts/append_xhs_notes_to_lark.py --print-header` to generate the header row for a new sheet.

## Append Script

Use the helper script after OpenClaw produces JSON:

```bash
python3 scripts/append_xhs_notes_to_lark.py \
  --input /path/to/openclaw-xhs-results.json \
  --keyword "露营" \
  --since 2026-01-24 \
  --min-comments 100 \
  --min-likes 200 \
  --url "https://example.feishu.cn/sheets/xxxx" \
  --range "Sheet1!A1" \
  --dry-run
```

Remove `--dry-run` only after confirming the rows look right.

## Notes

- Do not scrape private, login-gated, or restricted content unless the user confirms they have authorization and the access method is normal user access.
- Respect platform rate limits and do not provide bypass instructions for anti-bot, CAPTCHA, or access controls.
- Keep raw crawl files in a user-visible path such as `/Users/wangzong/openclaw_workspace/xhs/` when possible.
