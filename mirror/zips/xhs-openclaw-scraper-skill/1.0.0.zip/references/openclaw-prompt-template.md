# OpenClaw Prompt Template

Use this template as the `openclaw agent --message` value. Replace bracketed fields.

```text
请在小红书搜索公开笔记，关键词：「[keyword]」。

筛选规则：
- 发布时间范围：[start_date] 至 [end_date]（或最近 [time_range]）
- 评论数 >= [min_comments]
- 点赞数 >= [min_likes]
- 最多返回 [limit] 条
- 只返回公开可访问笔记，不绕过登录、验证码、反爬或权限限制

请输出严格 JSON，不要 Markdown，不要解释。格式：
{
  "keyword": "[keyword]",
  "crawled_at": "ISO-8601 time",
  "notes": [
    {
      "note_id": "string",
      "title": "string",
      "url": "string",
      "author": "string",
      "published_at": "YYYY-MM-DD or ISO time",
      "likes": 0,
      "comments": 0,
      "collects": 0,
      "summary": "string",
      "tags": ["string"]
    }
  ]
}
```

If exact counts are abbreviated, convert them to integers where reliable: `1.2万` -> `12000`, `3k` -> `3000`. If not reliable, set the field to `null`.
