#!/usr/bin/env python3
"""Normalize OpenClaw Xiaohongshu results and append them to a Lark sheet."""

from __future__ import annotations

import argparse
import datetime as dt
import json
import re
import subprocess
import sys
from pathlib import Path
from typing import Any

HEADERS = [
    "抓取时间",
    "关键词",
    "笔记标题",
    "笔记链接",
    "作者",
    "发布时间",
    "点赞数",
    "评论数",
    "收藏数",
    "摘要",
    "标签",
    "笔记ID",
]


def parse_count(value: Any) -> int | None:
    if value is None or value == "":
        return None
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return int(value)
    text = str(value).strip().replace(",", "")
    match = re.fullmatch(r"([0-9]+(?:\.[0-9]+)?)(万|w|W|千|k|K)?", text)
    if not match:
        digits = re.sub(r"[^0-9]", "", text)
        return int(digits) if digits else None
    number = float(match.group(1))
    unit = match.group(2)
    if unit in {"万", "w", "W"}:
        number *= 10000
    elif unit in {"千", "k", "K"}:
        number *= 1000
    return int(number)


def parse_date(value: Any) -> dt.date | None:
    if not value:
        return None
    text = str(value).strip()
    for pattern in (r"(\d{4})-(\d{1,2})-(\d{1,2})", r"(\d{4})/(\d{1,2})/(\d{1,2})"):
        match = re.search(pattern, text)
        if match:
            year, month, day = map(int, match.groups())
            return dt.date(year, month, day)
    return None


def pick(record: dict[str, Any], *keys: str) -> Any:
    for key in keys:
        if key in record and record[key] not in (None, ""):
            return record[key]
    return None


def load_notes(path: Path) -> list[dict[str, Any]]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(data, list):
        notes = data
    elif isinstance(data, dict):
        notes = data.get("notes") or data.get("items") or data.get("data") or data.get("results") or []
    else:
        notes = []
    if not isinstance(notes, list):
        raise SystemExit("Input JSON does not contain a notes array")
    return [note for note in notes if isinstance(note, dict)]


def normalize_tags(value: Any) -> str:
    if isinstance(value, list):
        return ", ".join(str(item).strip() for item in value if str(item).strip())
    return str(value or "").strip()


def build_rows(args: argparse.Namespace) -> list[list[Any]]:
    crawled_at = dt.datetime.now().astimezone().isoformat(timespec="seconds")
    since = dt.date.fromisoformat(args.since) if args.since else None
    rows: list[list[Any]] = []
    seen: set[str] = set()

    for note in load_notes(Path(args.input)):
        likes = parse_count(pick(note, "likes", "like_count", "liked_count", "点赞数"))
        comments = parse_count(pick(note, "comments", "comment_count", "评论数"))
        collects = parse_count(pick(note, "collects", "collect_count", "favorites", "收藏数"))
        published = pick(note, "published_at", "publish_time", "created_at", "发布时间", "date")
        published_date = parse_date(published)
        url = str(pick(note, "url", "link", "笔记链接") or "").strip()
        note_id = str(pick(note, "note_id", "id", "笔记ID") or "").strip()
        dedupe_key = url or note_id

        if args.min_likes is not None and (likes is None or likes < args.min_likes):
            continue
        if args.min_comments is not None and (comments is None or comments < args.min_comments):
            continue
        if since and published_date and published_date < since:
            continue
        if args.dedupe and dedupe_key:
            if dedupe_key in seen:
                continue
            seen.add(dedupe_key)

        rows.append([
            crawled_at,
            args.keyword,
            pick(note, "title", "笔记标题") or "",
            url,
            pick(note, "author", "nickname", "user", "作者") or "",
            str(published or ""),
            likes if likes is not None else "",
            comments if comments is not None else "",
            collects if collects is not None else "",
            pick(note, "summary", "desc", "description", "content", "摘要") or "",
            normalize_tags(pick(note, "tags", "hashtags", "标签")),
            note_id,
        ])
        if args.limit and len(rows) >= args.limit:
            break
    return rows


def append_to_lark(args: argparse.Namespace, rows: list[list[Any]]) -> None:
    command = ["lark-cli", "sheets", "+append"]
    if args.url:
        command.extend(["--url", args.url])
    if args.spreadsheet_token:
        command.extend(["--spreadsheet-token", args.spreadsheet_token])
    if args.sheet_id:
        command.extend(["--sheet-id", args.sheet_id])
    if args.range:
        command.extend(["--range", args.range])
    command.extend(["--values", json.dumps(rows, ensure_ascii=False)])
    if args.dry_run:
        command.append("--dry-run")
    subprocess.run(command, check=True)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", help="OpenClaw JSON result file")
    parser.add_argument("--keyword", default="", help="Keyword written to the sheet")
    parser.add_argument("--since", help="Keep notes on/after YYYY-MM-DD when publish date is present")
    parser.add_argument("--min-comments", type=int, default=100)
    parser.add_argument("--min-likes", type=int, default=200)
    parser.add_argument("--limit", type=int, default=0, help="Maximum rows to append after filtering")
    parser.add_argument("--url", help="Lark/Feishu spreadsheet URL")
    parser.add_argument("--spreadsheet-token", help="Lark spreadsheet token")
    parser.add_argument("--sheet-id", help="Lark sheet ID")
    parser.add_argument("--range", default="A1", help="Append range, e.g. Sheet1!A1 or A1 with --sheet-id")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--dedupe", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--print-header", action="store_true", help="Print header row JSON and exit")
    parser.add_argument("--print-rows", action="store_true", help="Print normalized rows instead of appending")
    args = parser.parse_args()

    if args.print_header:
        print(json.dumps([HEADERS], ensure_ascii=False))
        return 0
    if not args.input:
        parser.error("--input is required unless --print-header is used")
    rows = build_rows(args)
    print(f"Prepared {len(rows)} row(s)", file=sys.stderr)
    if args.print_rows:
        print(json.dumps(rows, ensure_ascii=False, indent=2))
        return 0
    if not rows:
        return 0
    if not args.url and not args.spreadsheet_token:
        parser.error("--url or --spreadsheet-token is required unless --print-rows is used")
    append_to_lark(args, rows)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
