#!/usr/bin/env python3
from __future__ import annotations

import argparse
import getpass
import os
import re
import shutil
from pathlib import Path

MANAGED_NODE = "/Users/liubinyuan/.workbuddy/binaries/node/versions/22.12.0/bin/node"
MANAGED_NODE_PATH = "/Users/liubinyuan/.workbuddy/binaries/node/workspace/node_modules"
DEFAULT_WORKBUDDY_APP = "/Applications/WorkBuddy.app"

README_TEMPLATE = """# WorkBuddy 自动签到工具

这个工具走的是更稳的方案：**不再点个人面板，不再依赖签到卡片 DOM，而是直接调用 WorkBuddy 客户端内部的签到接口**。

核心调用链路：

- `codebuddy:getCheckinStatus`：读取今日签到状态
- `codebuddy:claimDailyCheckin`：执行今日礼包领取
- `codebuddy:getAccountUsage`：读取积分余额摘要

## 文件说明

- `checkin.cjs`：主脚本
- `run.sh`：启动包装脚本
- `install-launchd.sh`：安装 launchd agent
- `.workbuddy/workbuddy-checkin/profile/`：自动签到专用运行目录
- `.workbuddy/workbuddy-checkin/logs/`：每次执行的日志与截图

## 手动执行

```bash
{run_script}
```

可选参数：

```bash
{run_script} --dry-run
{run_script} --debug
{run_script} --keep-open
```

## 执行逻辑

1. 启动一份可调试的 WorkBuddy 实例
2. 连接桌面客户端调试端口
3. 打开 `Agents` 页面
4. 直接调用 WorkBuddy 内部 IPC 接口读取签到状态
5. 若未领取，则调用内部接口执行签到
6. 再次读取签到状态与积分摘要，确认结果
7. 保存执行结果、日志与截图

## 前提条件

- `.workbuddy/workbuddy-checkin/profile/` 这份专用会话里必须已经有有效登录态
- WorkBuddy 桌面端默认安装在 `{workbuddy_app}`

如果脚本提示“当前专用会话未登录 WorkBuddy”，说明这份专用 profile 里没有可用登录态，需要先补一次登录。

## 日志位置

```text
{log_dir}
```
"""

RUN_TEMPLATE = """#!/bin/zsh
set -euo pipefail

NODE_PATH={managed_node_path} \\
{managed_node} \\
{checkin_script} --catchup "$@"
"""

INSTALL_TEMPLATE = """#!/bin/zsh
set -euo pipefail

PLIST_SOURCE=\"{plist_source}\"
LAUNCH_AGENTS_DIR=\"$HOME/Library/LaunchAgents\"
PLIST_TARGET=\"$LAUNCH_AGENTS_DIR/{label}.plist\"

printf '📦 正在安装 WorkBuddy 签到 launchd agent...\\n'
mkdir -p \"$LAUNCH_AGENTS_DIR\"

if [ -f \"$PLIST_TARGET\" ]; then
  printf '🗑️  卸载旧版本...\\n'
  launchctl unload \"$PLIST_TARGET\" 2>/dev/null || true
  rm \"$PLIST_TARGET\"
fi

cp \"$PLIST_SOURCE\" \"$PLIST_TARGET\"
printf '✅ 已安装 plist: %s\\n' \"$PLIST_TARGET\"
launchctl load \"$PLIST_TARGET\"
printf '✅ launchd agent 已加载\\n\\n'
printf '📅 任务调度：每天 {hour:02d}:{minute:02d} 自动执行签到\\n'
printf '🔄 脚本默认使用 --catchup，适合休眠后补执行\\n\\n'
printf '管理命令：\\n'
printf '  查看状态: launchctl list | grep workbuddy-checkin\\n'
printf '  手动执行: launchctl kickstart -k gui/$(id -u)/{label}\\n'
printf '  卸载:     launchctl unload %s && rm %s\\n' \"$PLIST_TARGET\" \"$PLIST_TARGET\"
"""

PLIST_TEMPLATE = """<?xml version=\"1.0\" encoding=\"UTF-8\"?>
<!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">
<plist version=\"1.0\">
<dict>
    <key>Label</key>
    <string>{label}</string>

    <key>ProgramArguments</key>
    <array>
        <string>/bin/zsh</string>
        <string>{run_script}</string>
    </array>

    <key>StartCalendarInterval</key>
    <dict>
        <key>Hour</key>
        <integer>{hour}</integer>
        <key>Minute</key>
        <integer>{minute}</integer>
    </dict>

    <key>RunAtLoad</key>
    <true/>

    <key>KeepAlive</key>
    <false/>

    <key>StandardOutPath</key>
    <string>{stdout_log}</string>

    <key>StandardErrorPath</key>
    <string>{stderr_log}</string>
</dict>
</plist>
"""


def sanitize_label_part(value: str) -> str:
    value = value.strip().lower()
    value = re.sub(r"[^a-z0-9.-]+", "-", value)
    value = re.sub(r"-+", "-", value).strip("-.")
    return value or "user"


def write_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def make_executable(path: Path) -> None:
    path.chmod(path.stat().st_mode | 0o111)


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate a reusable WorkBuddy auto-checkin workspace scaffold.")
    parser.add_argument("--workspace", default=os.getcwd(), help="Target workspace root. Defaults to current working directory.")
    parser.add_argument("--hour", type=int, default=12, help="launchd schedule hour. Default: 12")
    parser.add_argument("--minute", type=int, default=0, help="launchd schedule minute. Default: 0")
    parser.add_argument("--label-prefix", default="com", help="launchd label prefix. Default: com")
    parser.add_argument("--workbuddy-app", default=DEFAULT_WORKBUDDY_APP, help="WorkBuddy app path. Default: /Applications/WorkBuddy.app")
    args = parser.parse_args()

    workspace = Path(args.workspace).expanduser().resolve()
    tools_dir = workspace / "tools" / "workbuddy-checkin"
    state_dir = workspace / ".workbuddy" / "workbuddy-checkin"
    logs_dir = state_dir / "logs"
    profile_dir = state_dir / "profile"

    user_part = sanitize_label_part(getpass.getuser())
    label_prefix = sanitize_label_part(args.label_prefix)
    label = f"{label_prefix}.{user_part}.workbuddy-checkin"

    skill_dir = Path(__file__).resolve().parent.parent
    bundled_checkin = skill_dir / "scripts" / "checkin.cjs"

    checkin_target = tools_dir / "checkin.cjs"
    run_target = tools_dir / "run.sh"
    install_target = tools_dir / "install-launchd.sh"
    readme_target = tools_dir / "README.md"
    plist_target = state_dir / f"{label}.plist"

    tools_dir.mkdir(parents=True, exist_ok=True)
    logs_dir.mkdir(parents=True, exist_ok=True)
    profile_dir.mkdir(parents=True, exist_ok=True)

    shutil.copy2(bundled_checkin, checkin_target)

    write_text(
        run_target,
        RUN_TEMPLATE.format(
            managed_node_path=MANAGED_NODE_PATH,
            managed_node=MANAGED_NODE,
            checkin_script=str(checkin_target),
        ),
    )
    make_executable(run_target)

    write_text(
        plist_target,
        PLIST_TEMPLATE.format(
            label=label,
            run_script=str(run_target),
            hour=args.hour,
            minute=args.minute,
            stdout_log=str(logs_dir / "launchd.log"),
            stderr_log=str(logs_dir / "launchd.err"),
        ),
    )

    write_text(
        install_target,
        INSTALL_TEMPLATE.format(
            plist_source=str(plist_target),
            label=label,
            hour=args.hour,
            minute=args.minute,
        ),
    )
    make_executable(install_target)

    write_text(
        readme_target,
        README_TEMPLATE.format(
            run_script=str(run_target),
            workbuddy_app=args.workbuddy_app,
            log_dir=str(logs_dir),
        ),
    )

    print("✅ 已生成 WorkBuddy 自动签到工作区文件")
    print(f"workspace: {workspace}")
    print(f"label: {label}")
    print(f"run script: {run_target}")
    print(f"plist: {plist_target}")
    print(f"logs dir: {logs_dir}")
    print(f"profile dir: {profile_dir}")


if __name__ == "__main__":
    main()
