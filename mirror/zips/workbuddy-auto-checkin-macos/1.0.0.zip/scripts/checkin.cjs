#!/usr/bin/env node
const fs = require("node:fs");
const fsp = require("node:fs/promises");
const path = require("node:path");
const { spawn } = require("node:child_process");
const process = require("node:process");
const { chromium } = require("playwright");

const WORKSPACE_ROOT = path.resolve(__dirname, "..", "..");
const TOOL_HOME = path.join(WORKSPACE_ROOT, ".workbuddy", "workbuddy-checkin");
const LOG_DIR = path.join(TOOL_HOME, "logs");
const DEFAULT_EXECUTABLE = "/Applications/WorkBuddy.app/Contents/MacOS/Electron";
const DEFAULT_APP_DIR = "/Applications/WorkBuddy.app/Contents/Resources/app";
const DEFAULT_PORT = 9333;
const DEFAULT_TIMEOUT = 60000;

function timestamp() {
  const now = new Date();
  const pad = (n) => String(n).padStart(2, "0");
  return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}_${pad(now.getHours())}-${pad(now.getMinutes())}-${pad(now.getSeconds())}`;
}

function log(message) {
  const time = new Date().toLocaleString("zh-CN", { hour12: false });
  console.log(`[${time}] ${message}`);
}

function parseArgs(argv) {
  const result = {
    port: DEFAULT_PORT,
    timeout: DEFAULT_TIMEOUT,
    debug: false,
    keepOpen: false,
    dryRun: false,
    catchup: false,
    executable: DEFAULT_EXECUTABLE,
    appDir: DEFAULT_APP_DIR,
    userDataDir: path.join(TOOL_HOME, "profile")
  };

  for (let i = 0; i < argv.length; i += 1) {
    const current = argv[i];
    const next = argv[i + 1];
    switch (current) {
      case "--port":
        result.port = Number(next);
        i += 1;
        break;
      case "--timeout":
        result.timeout = Number(next);
        i += 1;
        break;
      case "--catchup":
        result.catchup = true;
        break;
      case "--user-data-dir":
        result.userDataDir = path.resolve(next);
        i += 1;
        break;
      case "--executable":
        result.executable = next;
        i += 1;
        break;
      case "--app-dir":
        result.appDir = next;
        i += 1;
        break;
      case "--debug":
        result.debug = true;
        break;
      case "--keep-open":
        result.keepOpen = true;
        break;
      case "--dry-run":
        result.dryRun = true;
        break;
      default:
        break;
    }
  }

  return result;
}

async function ensureDir(dirPath) {
  await fsp.mkdir(dirPath, { recursive: true });
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function hasFile(filePath) {
  try {
    await fsp.access(filePath, fs.constants.F_OK);
    return true;
  } catch {
    return false;
  }
}

async function launchWorkBuddy(options) {
  if (!(await hasFile(options.executable))) {
    throw new Error(`未找到 WorkBuddy 可执行文件：${options.executable}`);
  }
  if (!(await hasFile(options.appDir))) {
    throw new Error(`未找到 WorkBuddy 应用目录：${options.appDir}`);
  }

  const args = [
    options.appDir,
    `--user-data-dir=${options.userDataDir}`,
    `--remote-debugging-port=${options.port}`,
    "--disable-renderer-backgrounding",
    "--disable-background-timer-throttling"
  ];

  log(`启动 WorkBuddy 自动签到实例，调试端口 ${options.port}`);
  const child = spawn(options.executable, args, {
    detached: true,
    stdio: "ignore"
  });
  child.unref();
  return child.pid;
}

async function connectToCdp(options) {
  const endpoint = `http://127.0.0.1:${options.port}`;
  const deadline = Date.now() + options.timeout;
  let lastError = null;

  while (Date.now() < deadline) {
    try {
      const browser = await chromium.connectOverCDP(endpoint);
      return browser;
    } catch (error) {
      lastError = error;
      await sleep(1000);
    }
  }

  throw new Error(`连接 WorkBuddy 调试端口失败：${lastError ? lastError.message : "未知错误"}`);
}

async function saveScreenshot(page, filePath) {
  if (!page) {
    return;
  }
  await page.screenshot({ path: filePath, fullPage: true }).catch(() => {});
}

async function openAgentsPage(browser) {
  const context = browser.contexts()[0];
  const existing = context.pages().find((page) => page.url().includes("agentManager.html"));
  if (existing) {
    await existing.bringToFront().catch(() => {});
    return existing;
  }

  const workbenchPages = context.pages().filter((page) => page.url().includes("workbench.html"));
  for (const page of workbenchPages) {
    await page.bringToFront().catch(() => {});
    await page.waitForTimeout(800);
    const openAgents = page.getByText(/Open Agents|打开 Agents/).first();
    try {
      if ((await openAgents.count()) > 0) {
        await openAgents.click({ timeout: 3000 });
        await page.waitForTimeout(2000);
        const opened = context.pages().find((candidate) => candidate.url().includes("agentManager.html"));
        if (opened) {
          await opened.bringToFront().catch(() => {});
          return opened;
        }
      }
    } catch {
      // ignore and continue
    }
  }

  throw new Error("未能打开 Agents 页面，请先确认 WorkBuddy 可以正常进入主界面。");
}

async function waitForBridge(agentPage, timeout) {
  await agentPage.waitForFunction(
    () => Boolean(window.vscode?.ipcRenderer && window.__genieAccountService),
    undefined,
    { timeout }
  );
  await agentPage.waitForTimeout(800);
}

function sanitizeAccount(account) {
  if (!account || typeof account !== "object") {
    return null;
  }
  return {
    nickname: account.nickname || null,
    type: account.type || null,
    editionType: account.editionType || null
  };
}

function sanitizeUsage(usage) {
  if (!usage || typeof usage !== "object") {
    return null;
  }
  return {
    editionType: usage.editionType || null,
    usageTotal: usage.usageTotal ?? null,
    usageUsed: usage.usageUsed ?? null,
    usageLeft: usage.usageLeft ?? null,
    expireAt: usage.expireAt ?? null,
    refreshAt: usage.refreshAt ?? null
  };
}

function sanitizeCheckin(checkin) {
  if (!checkin || typeof checkin !== "object") {
    return null;
  }
  return {
    active: Boolean(checkin.active),
    todayCheckedIn: Boolean(checkin.today_checked_in),
    streakDays: checkin.streak_days ?? null,
    dailyCredit: checkin.daily_credit ?? null,
    todayCredit: checkin.today_credit ?? null,
    isStreakDay: Boolean(checkin.is_streak_day),
    nextStreakDay: checkin.next_streak_day ?? null,
    streakBonusDays: checkin.streak_bonus_days ?? null,
    streakBonusCredit: checkin.streak_bonus_credit ?? null
  };
}

function extractUsageLeft(usage) {
  if (!usage || typeof usage !== "object") {
    return null;
  }
  const value = usage.usageLeft ?? usage.left ?? usage.availableCredits ?? null;
  return value == null ? null : String(value);
}

async function getApiSnapshot(agentPage) {
  return agentPage.evaluate(async () => {
    const ipc = window.vscode?.ipcRenderer;
    if (!ipc?.invoke) {
      throw new Error("未找到 WorkBuddy 内部 IPC 接口。");
    }
    const accountService = window.__genieAccountService;
    const account = typeof accountService?.getAccount === "function"
      ? accountService.getAccount()
      : accountService?.account ?? null;
    const [usage, checkin] = await Promise.all([
      ipc.invoke("codebuddy:getAccountUsage"),
      ipc.invoke("codebuddy:getCheckinStatus")
    ]);
    return { account, usage, checkin };
  });
}

async function claimDailyCheckin(agentPage) {
  return agentPage.evaluate(async () => {
    const ipc = window.vscode?.ipcRenderer;
    if (!ipc?.invoke) {
      throw new Error("未找到 WorkBuddy 内部 IPC 接口。");
    }
    return ipc.invoke("codebuddy:claimDailyCheckin");
  });
}

async function writeResultLog(filePath, payload) {
  await fsp.writeFile(filePath, JSON.stringify(payload, null, 2), "utf8");
}

(async () => {
  const options = parseArgs(process.argv.slice(2));
  await ensureDir(options.userDataDir);
  await ensureDir(LOG_DIR);

  const runId = timestamp();
  const resultPath = path.join(LOG_DIR, `${runId}.json`);
  const beforeShot = path.join(LOG_DIR, `${runId}-before.png`);
  const afterShot = path.join(LOG_DIR, `${runId}-after.png`);

  let browser;
  let agentPage = null;
  let launchedPid = null;
  let exitCode = 0;
  const result = {
    runId,
    startedAt: new Date().toISOString(),
    status: "running",
    port: options.port,
    userDataDir: options.userDataDir,
    beforeBalance: null,
    afterBalance: null,
    screenshots: {
      before: beforeShot,
      after: afterShot
    }
  };

  try {
    launchedPid = await launchWorkBuddy(options);
    result.pid = launchedPid;
    browser = await connectToCdp(options);
    agentPage = await openAgentsPage(browser);
    await agentPage.bringToFront().catch(() => {});
    await waitForBridge(agentPage, options.timeout);

    const before = await getApiSnapshot(agentPage);
    result.account = sanitizeAccount(before.account);
    result.beforeBalance = extractUsageLeft(before.usage);
    result.usageBefore = sanitizeUsage(before.usage);
    result.checkinBefore = sanitizeCheckin(before.checkin);

    await saveScreenshot(agentPage, beforeShot);

    if (!before.account?.uid) {
      throw new Error("当前专用会话未登录 WorkBuddy，请先在该会话中登录一次。");
    }

    if (!before.checkin?.active) {
      throw new Error("当前账号未启用每日礼包能力，无法执行签到。");
    }

    if (before.checkin.today_checked_in) {
      result.status = "already-claimed";
      result.message = "今日礼包已领取";
      log("今日礼包已领取，无需重复签到。");
    } else if (options.dryRun) {
      result.status = "dry-run";
      result.message = "已定位到签到接口，未执行领取。";
      log("已确认签到接口可用，当前为 dry-run 模式，没有执行领取。");
    } else if (!options.catchup && new Date().getHours() < 12) {
      result.status = "too-early";
      result.message = `当前时间 ${new Date().toLocaleTimeString("zh-CN")}，未到12点，跳过执行`;
      log(result.message);
    } else {
      log("检测到今日礼包可领取，开始通过内部接口执行签到。");
      try {
        const claimResponse = await claimDailyCheckin(agentPage);
        if (claimResponse !== undefined) {
          result.claimResponse = claimResponse;
        }
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        if (message.includes("今天已签到")) {
          result.status = "already-claimed";
          result.message = "今日礼包已领取";
          log("接口返回今天已签到，按已领取处理。");
        } else {
          throw error;
        }
      }

      const afterCheck = await getApiSnapshot(agentPage);
      result.afterBalance = extractUsageLeft(afterCheck.usage);
      result.usageAfter = sanitizeUsage(afterCheck.usage);
      result.checkinAfter = sanitizeCheckin(afterCheck.checkin);

      if (afterCheck.checkin?.today_checked_in) {
        if (result.status !== "already-claimed") {
          result.status = "claimed-now";
          result.message = "签到成功";
          log("签到成功。");
        }
      } else if (result.status !== "already-claimed") {
        throw new Error("接口调用已完成，但未检测到今日已签到状态。");
      }
    }

    if (!result.afterBalance) {
      result.afterBalance = result.beforeBalance;
    }
    if (!result.usageAfter) {
      result.usageAfter = result.usageBefore || null;
    }
    if (!result.checkinAfter) {
      result.checkinAfter = result.checkinBefore || null;
    }

    await saveScreenshot(agentPage, afterShot);
  } catch (error) {
    exitCode = 1;
    result.status = "failed";
    result.message = error instanceof Error ? error.message : String(error);
    log(`自动签到失败：${result.message}`);
    await saveScreenshot(agentPage, afterShot);
  } finally {
    result.finishedAt = new Date().toISOString();
    await writeResultLog(resultPath, result);
    if (browser && !options.keepOpen) {
      await browser.close().catch(() => {});
    }
  }

  console.log(JSON.stringify(result, null, 2));
  process.exit(exitCode);
})();
