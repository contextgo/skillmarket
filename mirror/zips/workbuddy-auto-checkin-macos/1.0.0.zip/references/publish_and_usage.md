# WorkBuddy Auto Checkin：部署与发布参考

## 1. 适用范围

- 仅适用于 macOS 桌面端 WorkBuddy
- 依赖 WorkBuddy 桌面端可被远程调试
- 依赖 `playwright` 可在托管 Node 工作区中被 `require`

## 2. 推荐部署顺序

1. 先运行 `scripts/setup_checkin.py --workspace <目标工作区>` 生成脚手架。
2. 再检查以下目录是否存在：
   - `tools/workbuddy-checkin/`
   - `.workbuddy/workbuddy-checkin/logs/`
   - `.workbuddy/workbuddy-checkin/profile/`
3. 手动执行一次：
   ```bash
   /绝对路径/到/tools/workbuddy-checkin/run.sh --debug --keep-open
   ```
4. 如果提示未登录，在自动签到专用 profile 对应的 WorkBuddy 窗口内手动登录。
5. 再执行一次不带 `--keep-open` 的手动运行，确认结果为 `claimed-now` 或 `already-claimed`。
6. 最后安装 launchd agent。

## 3. Playwright 依赖检查

推荐使用 WorkBuddy 托管 Node 工作区安装依赖：

```bash
cd /Users/liubinyuan/.workbuddy/binaries/node/workspace && /Users/liubinyuan/.workbuddy/binaries/node/versions/22.12.0/bin/npm install playwright
```

运行时用法：

```bash
NODE_PATH=/Users/liubinyuan/.workbuddy/binaries/node/workspace/node_modules /Users/liubinyuan/.workbuddy/binaries/node/versions/22.12.0/bin/node /绝对路径/到/checkin.cjs --catchup
```

## 4. launchd 常用命令

查看是否加载：

```bash
launchctl list | grep workbuddy-checkin
```

手动触发：

```bash
launchctl kickstart -k gui/$(id -u)/com.<user>.workbuddy-checkin
```

卸载：

```bash
launchctl unload ~/Library/LaunchAgents/com.<user>.workbuddy-checkin.plist && rm ~/Library/LaunchAgents/com.<user>.workbuddy-checkin.plist
```

## 5. 常见失败原因

1. WorkBuddy 应用路径变化。
2. 专用 profile 没有登录态或登录已失效。
3. `codebuddy:getCheckinStatus` / `codebuddy:claimDailyCheckin` / `codebuddy:getAccountUsage` 通道名发生变化。
4. 托管 Node 工作区缺少 `playwright`。
5. 用户把工具脚本直接放在技能目录里运行，而不是先复制到工作区工具目录。

## 6. 发布前检查清单

- [ ] `SKILL.md` 描述中明确写清使用场景、macOS 限制、IPC 思路
- [ ] `scripts/setup_checkin.py` 能在新工作区生成完整脚手架
- [ ] `scripts/checkin.cjs` 已包含可运行的签到逻辑
- [ ] 示例占位文件已删除
- [ ] 打包脚本校验通过
- [ ] zip 包内目录结构正确：根目录下直接包含 `SKILL.md`、`scripts/`、`references/`
- [ ] 发布页文案与技能真实行为一致，不夸大“自动登录”“跨平台可用”等不存在的能力

## 7. SkillHub 发布建议文案

### 标题

WorkBuddy Auto Checkin

### 简介

在 macOS 上为 WorkBuddy 桌面端生成一套可复用的每日礼包自动签到工具。方案基于客户端内部 IPC 接口，不依赖脆弱的 UI 点击链路，支持 launchd 定时执行与错过时段后的补执行。

### 适用场景

- 从零搭建 WorkBuddy 自动签到
- 修复已有但经常失效的签到脚本
- 将个人可用的签到方案封装成团队可复用技能
- 打包后发布到 SkillHub 供他人安装
