from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter
import os


def generate_warehouse_excel(data, output_path):
    """
    生成格式化仓储资源搜索报告 Excel 文件。

    参数:
        data: list[dict]，每条记录为一个字典，键对应表头字段。
              必填字段: 仓库标准, 联系人及电话, 价格（元/㎡/月）, 消防等级,
                       仓库详细地址, 面积（总面积/可租面积）, 恒温情况,
                       来源平台, 是否有月台
        output_path: str，输出文件完整路径，例如 "outputs/仓库搜索报告.xlsx"
    返回:
        保存后的文件绝对路径
    """
    wb = Workbook()
    ws = wb.active
    ws.title = "仓库资源汇总"

    headers = [
        "仓库标准",
        "联系人及电话",
        "价格（元/㎡/月）",
        "消防等级",
        "仓库详细地址",
        "面积（总面积/可租面积）",
        "恒温情况",
        "来源平台",
        "是否有月台",
    ]

    # 表头样式
    header_font = Font(bold=True, color="000000")
    header_fill = PatternFill(start_color="D9D9D9", end_color="D9D9D9", fill_type="solid")
    header_align = Alignment(horizontal="center", vertical="center", wrap_text=True)

    # 单元格边框
    thin_border = Border(
        left=Side(style="thin"),
        right=Side(style="thin"),
        top=Side(style="thin"),
        bottom=Side(style="thin"),
    )

    # 写入表头
    for col_idx, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col_idx, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_align
        cell.border = thin_border

    # 写入数据
    for row_idx, record in enumerate(data, 2):
        for col_idx, header in enumerate(headers, 1):
            value = record.get(header, "")
            cell = ws.cell(row=row_idx, column=col_idx, value=value)
            cell.border = thin_border
            cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)

            # 价格列保留两位小数
            if header == "价格（元/㎡/月）" and isinstance(value, (int, float)):
                cell.number_format = "0.00"
                cell.alignment = Alignment(horizontal="right", vertical="center")

    # 列宽自适应（按表头和内容最大字符数估算，最小宽度 12）
    for col_idx, header in enumerate(headers, 1):
        max_length = len(header)
        for row_idx in range(2, len(data) + 2):
            cell_value = ws.cell(row=row_idx, column=col_idx).value
            if cell_value:
                max_length = max(max_length, len(str(cell_value)))
        adjusted_width = min(max(max_length + 2, 12), 50)
        ws.column_dimensions[get_column_letter(col_idx)].width = adjusted_width

    # 行高适当调整
    ws.row_dimensions[1].height = 30
    for row_idx in range(2, len(data) + 2):
        ws.row_dimensions[row_idx].height = 22

    # 冻结首行
    ws.freeze_panes = "A2"

    # 保存
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    wb.save(output_path)
    return os.path.abspath(output_path)


if __name__ == "__main__":
    # 示例数据
    sample_data = [
        {
            "仓库标准": "高标仓",
            "联系人及电话": "张经理 13800138000",
            "价格（元/㎡/月）": 42.5,
            "消防等级": "丙二类",
            "仓库详细地址": "上海市青浦区华新镇华志路1688号",
            "面积（总面积/可租面积）": "12000㎡ / 5000㎡",
            "恒温情况": "常温",
            "来源平台": "物联云仓",
            "是否有月台": "有",
        },
        {
            "仓库标准": "普通仓",
            "联系人及电话": "李总 13900139000",
            "价格（元/㎡/月）": 28.0,
            "消防等级": "丙一类",
            "仓库详细地址": "苏州市昆山市周市镇长江北路",
            "面积（总面积/可租面积）": "8000㎡ / 3000㎡",
            "恒温情况": "常温",
            "来源平台": "物流街",
            "是否有月台": "无",
        },
    ]
    path = generate_warehouse_excel(sample_data, "outputs/仓库搜索报告.xlsx")
    print(f"Excel 已保存: {path}")
