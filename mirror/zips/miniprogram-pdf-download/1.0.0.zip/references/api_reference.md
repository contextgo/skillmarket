# 互联二维码平台 API 参考

## 平台概述

互联二维码（hlcode.cn）是一个二维码在线制作平台，支持将PDF、Word、Excel、PPT等文件生成二维码。生成的二维码通过小程序或H5页面提供在线预览，默认可设置"不允许下载"。

## 技术架构

### 前端
- **框架**：Vue.js 2.x + Vue Router（History模式）+ Vant UI
- **预览域名**：`preview.hlcode.cn`
- **JS资源版本化**：`/js/app.{timestamp}.js`、`/js/chunk-*.js`

### 后端
- **API域名**：`api.hlcode.cn`
- **文件存储**：阿里云OSS（`oss.hlcode.cn`）
- **认证方式**：可选token（通过 `Authorization` header），但文件查询接口不需要

## API 接口列表

### 1. 获取文件真实URL

```
POST https://api.hlcode.cn/qruser/file/get_url_byid
Content-Type: application/json

Request:
{
  "id": "string"  // 二维码/文件唯一标识ID
}

Response (success):
{
  "code": 0,
  "msg": "success",
  "data": {
    "url": "string"  // 文件的真实下载地址
  }
}

Response (error):
{
  "code": 500,
  "msg": "服务器异常"
}
```

### 2. 微信JS-SDK配置

```
POST https://api.hlcode.cn/qruser/wxapi/get_weconfig
Content-Type: application/json

Request: { ... }  // 微信签名相关参数
```

### 3. 文件传输提交

```
POST https://api.hlcode.cn/qruser/transfer/submitFile
Content-Type: application/json

Request:
{
  "fileList": "string",   // JSON字符串化的文件列表
  "validKey": "string"    // 验证密钥
}
```

## 预览URL结构

```
https://preview.hlcode.cn/?d=hl&type=pdf&time={timestamp}&id={fileId}&name={encoded_filename}
```

| 参数 | 类型 | 说明 |
|------|------|------|
| `d` | string | 渠道标识（hl=互联二维码） |
| `type` | string | 文件类型：pdf/word/excel/ppt |
| `time` | number | 毫秒级时间戳，用于链接有效期验证（10分钟） |
| `id` | string | 文件唯一标识 |
| `name` | string | URL编码的文件名 |
| `size` | string | 文件大小（可选，如"2M"） |
| `platform` | string | 平台标识（可选，如"windows"） |
| `preview` | string | 预览模式标识（可选） |
| `k` | number | 文件来源类型：0=code文件，1=form文件（可选） |
| `value` | string | OSS文件路径或完整URL（可选，与id二选一） |

## 文件存储URL格式

```
# 二维码文件（默认）
https://oss.hlcode.cn/server/code/file/{year}/{month}/{day}/{uuid}.{ext}

# 表单文件
https://oss.hlcode.cn/server/form/file/{year}/{month}/{day}/{uuid}.{ext}

# 第三方预览服务（用于在线预览）
https://api.yozocloud.cn/checkUrl?k=53548366176033177653030&url={encoded_oss_url}
```

## 前端关键组件

### 预览组件（Show）
- 通过 `$route.query.id` 获取文件ID
- 有ID时使用 yozocloud SDK 在线预览
- 无ID时构造 OSS URL 进行预览
- `handleOpen()` 方法调用 `get_url_byid` 获取真实下载URL

### 下载组件（DownLoad）
- 通过 `$route.params.value` 获取文件标识
- 构造下载链接并触发 `<a>` 标签下载
- 区分微信/企业微信/支付宝/QQ/PC等环境
- 微信环境跳转到DownLoad页面显示下载指引
- PC环境直接触发下载

### 下载进度组件（Progress）
- 接收 `value`、`name`、`k`、`time` 路由参数
- 非微信环境直接构造URL下载
- 有30分钟时间验证

## 在线预览SDK

文件预览使用 yozocloud Office SDK：
```
AppID: AK20230829NSVNLE
支持类型：Pdf, Writer, Spreadsheet, Presentation
模式：simple
```

## 安全机制

- **链接有效期**：预览URL的time参数有效期10分钟
- **下载控制**：二维码制作者可设置"不允许下载"
- **CORS**：OSS接口设置 `Access-Control-Allow-Origin: *`
- **文件ID不可猜测**：使用雪花算法生成的长数字ID
