---
name: 互联小程序PDF下载
description: |
  This skill downloads PDF files from mini-program-based QR code platforms (e.g. 互联二维码/hlcode.cn)
  that only allow online preview but not direct download. It works by:
  1. Extracting the real file ID from the preview URL
  2. Calling the platform's backend API to resolve the actual file download URL
  3. Downloading the PDF to local storage
  
  触发词：小程序PDF下载、互联二维码、hlcode、小程序文件下载、二维码PDF提取、
  小程序文件提取、只能预览不能下载、提取PDF、下载小程序文件、
  草料二维码文件下载、二维码里的PDF、小程序二维码下载、
  preview.hlcode.cn、互联码、H5二维码文件提取
---

# 互联小程序PDF下载

从微信小程序二维码平台（互联二维码/hlcode.cn）提取并下载仅限预览的PDF文件。

## 适用场景

- 扫描或收到微信小程序生成的二维码，内容为PDF文件
- 平台只提供在线预览，无直接下载按钮
- 用户提供了 `preview.hlcode.cn` 格式的预览链接
- 用户提供了 `#小程序://互联二维码/xxx` 格式的小程序链接（需引导获取H5链接）

## 工作流程

### Phase 1: 获取预览URL

小程序链接 `#小程序://xxx` 为微信内部协议，无法在浏览器中直接打开。

**需要用户提供的信息：**
1. **预览URL**（优先）：格式如 `https://preview.hlcode.cn/?d=hl&type=pdf&time=xxx&id=xxx&name=xxx.pdf`
2. **小程序链接**（次之）：格式如 `#小程序://互联二维码/xxx`，需引导用户获取H5链接

**获取H5预览链接的方法：**
- 在手机微信中打开小程序，点击右上角"..."→"复制链接"
- 或在电脑版微信中打开小程序，F12抓取 `preview.hlcode.cn` 的请求
- 部分小程序支持长按二维码→"识别图中二维码"获取H5链接

### Phase 2: 提取文件ID

从预览URL中提取关键参数：

| 参数 | 说明 | 示例 |
|------|------|------|
| `id` | 二维码/文件唯一标识 | `2044949821793517569` |
| `name` | 文件名（URL编码） | `%E5%AE%89%E7%AE%A1%E8%80%83%E6%A0%B8%E7%9F%A5%E8%AF%86%E7%82%B9.pdf` |
| `type` | 文件类型 | `pdf` / `word` / `excel` / `ppt` |
| `d` | 业务渠道标识 | `hl` |
| `time` | 时间戳（毫秒） | `1776416354569` |

**关键参数为 `id`**，这是调用后端API的必要参数。

### Phase 3: 调用后端API获取真实文件地址

**API端点：**
```
POST https://api.hlcode.cn/qruser/file/get_url_byid
```

**请求格式：**
```
Content-Type: application/json

{"id": "<文件ID>"}
```

**响应格式：**
```json
{
  "code": 0,
  "msg": "success",
  "data": {
    "url": "https://oss.hlcode.cn/server/code/file/2026/04/17/xxx.pdf"
  }
}
```

- `code: 0` 表示成功，文件URL在 `data.url` 中
- 其他code值表示失败，检查 `msg` 字段获取错误信息

**调用示例（PowerShell）：**
```powershell
Invoke-RestMethod -Uri 'https://api.hlcode.cn/qruser/file/get_url_byid' -Method Post -ContentType 'application/json; charset=utf-8' -Body '{"id":"<文件ID>"}'
```

### Phase 4: 下载文件

使用API返回的真实URL下载文件：

```bash
curl.exe -L -o "<保存路径>" "<真实文件URL>"
```

**验证下载结果：**
- 检查文件大小是否合理（>1KB）
- 检查HTTP响应头 `Content-Type` 是否为 `application/pdf`
- 首字节应为 `%PDF-`（PDF文件魔数）

## 已知平台API映射

| 平台 | 预览域名 | API域名 | 文件查询接口 |
|------|----------|---------|-------------|
| 互联二维码 | preview.hlcode.cn | api.hlcode.cn | POST /qruser/file/get_url_byid |
| 文件存储 | oss.hlcode.cn | - | GET /server/code/file/{path} |
| 文件存储(表单) | oss.hlcode.cn | - | GET /server/form/file/{path} |

## 踩坑经验

- **time参数会过期**：预览URL中的 `time` 参数有10分钟有效期，过期后页面显示"已超时"。但API调用不受time限制，只要 `id` 有效即可。
- **无需认证**：`get_url_byid` 接口不需要token或cookie，可直接调用。
- **PowerShell curl别名问题**：Windows PowerShell中 `curl` 是 `Invoke-WebRequest` 的别名，参数语法不同，需使用 `curl.exe` 或 `Invoke-RestMethod`。
- **文件名编码**：URL中的 `name` 参数为URL编码的中文，需 `decodeURIComponent` 解码。文件名中包含 `%` 时需要转义为 `%25`。
- **非PDF文件**：该流程同样适用于Word、Excel、PPT等文件类型，只需URL中 `type` 参数对应调整。

## 故障排除

| 问题 | 解决方案 |
|------|----------|
| API返回 `code: 500` | 检查id参数是否正确，重新从预览URL提取 |
| API返回 `code: 1` | 文件不存在或已被删除 |
| 下载文件为HTML而非PDF | 预览URL过期或被重定向，需重新获取真实URL |
| 用户只有小程序链接 | 引导用户获取H5预览链接，或使用F12抓包 |
