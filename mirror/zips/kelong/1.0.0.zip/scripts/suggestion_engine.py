#!/usr/bin/env python3
"""
话术推荐脚本 - suggestion_engine.py

功能说明:
    给定场景和上下文，按克隆体风格生成回复建议。
    不是通用AI回复，而是"他会怎么说"。支持多个建议版本。

使用方法:
    # 生成回复建议
    python suggestion_engine.py --profile ./clone_profile_final.json --scenario "客户要求打折"
    
    # 指定上下文
    python suggestion_engine.py --profile ./clone_profile_final.json --scenario "投诉处理" --context "客户已投诉3次"
    
    # 生成多个版本
    python suggestion_engine.py --profile ./clone_profile_final.json --scenario "初次拜访客户" --count 3
    
    # 保存建议
    python suggestion_engine.py --profile ./clone_profile_final.json --scenario "报价" --output ./suggestions.json

参数说明:
    --profile: 克隆体画像配置文件路径（必需）
    --scenario: 场景描述（必需）
    --context: 上下文背景信息
    --count: 生成建议数量，默认3
    --output: 输出文件路径

6大安全边界:
    1. 操作边界：只生成话术建议，不执行任何操作
    2. 内容边界：不承诺价格/优惠/期限等
    3. 知识边界：只使用授权的话术模板
    4. 权限边界：话术权限不越权
    5. 审计边界：记录推荐日志
    6. 退出边界：建议仅供参考，可随时停止

安全声明：本脚本仅处理本地JSON配置文件，无网络请求，无动态代码执行。
"""

import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, List, Any

try:
    import click
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.prompt import Confirm
except ImportError:
    print("请先安装依赖: pip install --no-deps -r requirements.txt")
    sys.exit(1)

console = Console()


class SuggestionEngine:
    """话术推荐引擎"""
    
    def __init__(self, profile_path: str):
        """初始化话术推荐引擎
        
        Args:
            profile_path: 克隆体画像配置文件路径
        """
        self.profile = self._load_profile(profile_path)
        self.clone_name = self.profile.get("clone_info", {}).get("name", "克隆体")
        
        # 提取配置
        self.comm = self.profile.get("dimensions", {}).get("communication", {})
        self.phrases = self.profile.get("dimensions", {}).get("phrases", {})
        self.expertise = self.profile.get("dimensions", {}).get("expertise", {})
    
    def _load_profile(self, path: str) -> Dict:
        """加载画像配置"""
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    
    def _get_scenario_type(self, scenario: str) -> str:
        """识别场景类型"""
        scenario_lower = scenario.lower()
        
        if any(kw in scenario_lower for kw in ["投诉", "抱怨", "不满", "差评"]):
            return "complaint"
        elif any(kw in scenario_lower for kw in ["报价", "价格", "折扣", "优惠"]):
            return "pricing"
        elif any(kw in scenario_lower for kw in ["合作", "签约", "合同", "商务"]):
            return "business"
        elif any(kw in scenario_lower for kw in ["技术", "支持", "排障", "问题"]):
            return "technical"
        elif any(kw in scenario_lower for kw in ["咨询", "了解", "介绍"]):
            return "inquiry"
        elif any(kw in scenario_lower for kw in ["催", "进度", "何时"]):
            return "followup"
        else:
            return "general"
    
    def _generate_suggestions(self, scenario: str, context: Optional[str] = None, count: int = 3) -> List[Dict]:
        """生成话术建议"""
        scenario_type = self._get_scenario_type(scenario)
        style = self.comm.get("style", "简洁高效")
        templates = self.phrases.get("fixed_expressions", [])
        catchphrase = self.phrases.get("catchphrase", "")
        
        suggestions = []
        
        # 根据场景类型生成不同风格的建议
        if scenario_type == "complaint":
            suggestion_data = [
                {
                    "type": "道歉+解决",
                    "content": "非常抱歉给您带来不便，我理解您的心情。针对您反映的问题，我们会立即跟进处理，争取在最短时间内给您一个满意的答复。",
                    "confidence": 0.92,
                    "reason": "高匹配度：符合投诉处理标准话术"
                },
                {
                    "type": "共情+行动",
                    "content": "我完全理解您的心情，换做是我也会着急。请放心，这件事我亲自跟进，有任何进展第一时间通知您。",
                    "confidence": 0.88,
                    "reason": "高匹配度：体现服务态度和专业度"
                },
                {
                    "type": "简洁确认",
                    "content": "收到投诉，我马上处理。请留下您的联系方式，稍后专人回电。",
                    "confidence": 0.75,
                    "reason": "中等匹配度：适用于高压场景"
                }
            ]
        elif scenario_type == "pricing":
            suggestion_data = [
                {
                    "type": "价值导向",
                    "content": "感谢您对我们产品的关注。关于价格，我可以为您详细介绍我们的方案配置和价值点，相信会让您觉得物有所值。",
                    "confidence": 0.90,
                    "reason": "高匹配度：强调产品价值"
                },
                {
                    "type": "需求导向",
                    "content": "价格需要根据您的具体需求来定制。建议您详细说说使用场景，我可以给您一个更精准的方案和报价。",
                    "confidence": 0.87,
                    "reason": "高匹配度：了解需求后报价"
                },
                {
                    "type": "专业说明",
                    "content": "我们的定价体系透明合理，包含XX、XX等服务保障。具体报价我会根据您的需求出一份详细方案。",
                    "confidence": 0.82,
                    "reason": "中等匹配度：专业且有诚意"
                }
            ]
        elif scenario_type == "inquiry":
            suggestion_data = [
                {
                    "type": "详细介绍",
                    "content": "您好，感谢您的咨询！我来为您详细介绍一下我们的产品/服务... 请问您具体想了解哪方面呢？",
                    "confidence": 0.91,
                    "reason": "高匹配度：热情且专业"
                },
                {
                    "type": "高效简洁",
                    "content": "请说，我在听。",
                    "confidence": 0.70,
                    "reason": "低匹配度：仅适用极简风格"
                },
                {
                    "type": "引导式",
                    "content": "好的，您想了解的是产品功能、价格还是合作方式？我们可以针对性地介绍。",
                    "confidence": 0.85,
                    "reason": "高匹配度：明确需求再介绍"
                }
            ]
        else:
            suggestion_data = [
                {
                    "type": "标准回复",
                    "content": "好的，我来帮您处理这个问题。请提供一下相关信息，我会尽快给您回复。",
                    "confidence": 0.85,
                    "reason": "通用场景适用"
                },
                {
                    "type": "确认跟进",
                    "content": "收到，我确认一下情况，稍后联系您。",
                    "confidence": 0.80,
                    "reason": "适用于需要核实的问题"
                },
                {
                    "type": "积极态度",
                    "content": "没问题，包在我身上！我来协调处理，有结果第一时间告知您。",
                    "confidence": 0.78,
                    "reason": "体现积极服务态度"
                }
            ]
        
        # 根据风格调整
        for i, sug in enumerate(suggestion_data[:count]):
            content = sug["content"]
            
            # 应用风格变化
            if style == "正式严谨":
                if not content.startswith("您好") and not content.startswith("感谢"):
                    content = "您好，" + content
            elif style == "亲切友好":
                if catchphrase:
                    content = content + f" {catchphrase}"
            elif style == "简洁高效":
                # 缩短内容
                sentences = content.split("。")
                content = "。".join(sentences[:2]) + "。"
            
            sug["content"] = content
            sug["style_match"] = style
            sug["timestamp"] = datetime.now().isoformat()
            
            suggestions.append(sug)
        
        return suggestions
    
    def generate(self, scenario: str, context: Optional[str] = None, count: int = 3) -> List[Dict]:
        """生成话术建议"""
        suggestions = self._generate_suggestions(scenario, context, count)
        return suggestions
    
    def display(self, suggestions: List[Dict], scenario: str, context: Optional[str] = None):
        """显示话术建议"""
        console.print(f"\n[bold cyan]📋 场景:[/bold cyan] {scenario}")
        if context:
            console.print(f"[bold cyan]📌 上下文:[/bold cyan] {context}")
        
        console.print(f"[bold cyan]👤 话术来源:[/bold cyan] {self.clone_name}\n")
        
        table = Table(title="💬 话术建议", show_header=True, header_style="bold magenta")
        table.add_column("版本", style="cyan", width=8)
        table.add_column("类型", style="yellow", width=12)
        table.add_column("建议回复", style="white", width=50)
        table.add_column("信心度", style="green", width=10)
        table.add_column("匹配理由", style="dim", width=25)
        
        for i, sug in enumerate(suggestions, 1):
            confidence_bar = "█" * int(sug["confidence"] * 10) + "░" * (10 - int(sug["confidence"] * 10))
            table.add_row(
                f"版本{i}",
                sug["type"],
                sug["content"][:48] + "..." if len(sug["content"]) > 48 else sug["content"],
                f"{sug['confidence']*100:.0f}%",
                sug["reason"][:24] + "..." if len(sug["reason"]) > 24 else sug["reason"]
            )
        
        console.print(table)
        
        # 提示
        console.print("\n[bold yellow]💡 提示:[/bold yellow] 以上为克隆体风格建议，仅供参考不做承诺")
        console.print("[dim]实际使用时请根据具体情况调整[/dim]")


@click.command(help="按员工风格生成回复建议，'他会怎么说'\n\n新手建议：先从 /创建克隆 快速模式开始")
@click.option("--profile", "-p", required=True, help="克隆体画像配置文件路径")
@click.option("--scenario", "-s", required=True, help="场景描述")
@click.option("--context", "-c", default=None, help="上下文背景信息")
@click.option("--count", "-n", default=3, help="生成建议数量")
@click.option("--output", "-o", default=None, help="输出文件路径")
def main(profile: str, scenario: str, context: str, count: int, output: str):
    """话术推荐主入口"""
    try:
        engine = SuggestionEngine(profile)
        suggestions = engine.generate(scenario, context, count)
        engine.display(suggestions, scenario, context)
        
        # 保存结果
        if output:
            result = {
                "scenario": scenario,
                "context": context,
                "clone_name": engine.clone_name,
                "suggestions": suggestions,
                "generated_at": datetime.now().isoformat()
            }
            with open(output, "w", encoding="utf-8") as f:
                json.dump(result, f, ensure_ascii=False, indent=2)
            console.print(f"\n[bold green]✅ 建议已保存到: {output}[/bold green]")
    
    except FileNotFoundError:
        console.print(f"[bold red]错误: 找不到文件: {profile}[/bold red]")
    except Exception as e:
        console.print(f"[bold red]处理出错: {e}[/bold red]")


if __name__ == "__main__":
    main()
