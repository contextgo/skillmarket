#!/usr/bin/env python3
"""
决策辅助脚本 - decision_aid.py

功能说明:
    给定问题，按克隆体思路分析，回答"如果是他，他会怎么判断"。
    输出推理过程和关键考虑因素，明确标注辅助参考。

使用方法:
    # 分析问题
    python decision_aid.py --profile ./clone_profile_final.json --question "是否接受这个订单"
    
    # 提供额外背景
    python decision_aid.py --profile ./clone_profile_final.json --question "是否升级服务器" --context "当前CPU使用率80%"
    
    # 多角度分析
    python decision_aid.py --profile ./clone_profile_final.json --question "项目是否延期" --multi-angle

参数说明:
    --profile: 克隆体画像配置文件路径（必需）
    --question: 需要决策的问题（必需）
    --context: 问题的背景信息
    --multi-angle: 是否进行多角度分析

6大安全边界:
    1. 操作边界：仅提供分析建议，不执行任何决策
    2. 内容边界：不承诺最终结果，只分析可能性
    3. 知识边界：只基于授权信息分析
    4. 权限边界：分析范围不越权
    5. 审计边界：记录分析日志
    6. 退出边界：最终决策权在真人

安全声明：本脚本仅处理本地JSON配置文件，无网络请求，无动态代码执行。
"""

import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, List, Any

try:
    import click
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.tree import Tree
except ImportError:
    print("请先安装依赖: pip install --no-deps -r requirements.txt")
    sys.exit(1)

console = Console()


class DecisionAid:
    """决策辅助引擎"""
    
    def __init__(self, profile_path: str):
        """初始化决策辅助引擎
        
        Args:
            profile_path: 克隆体画像配置文件路径
        """
        self.profile = self._load_profile(profile_path)
        self.clone_name = self.profile.get("clone_info", {}).get("name", "克隆体")
        self.clone_position = self.profile.get("clone_info", {}).get("position", "")
        
        # 提取配置
        self.decision = self.profile.get("dimensions", {}).get("decision", {})
        self.expertise = self.profile.get("dimensions", {}).get("expertise", {})
    
    def _load_profile(self, path: str) -> Dict:
        """加载画像配置"""
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    
    def _classify_question(self, question: str) -> str:
        """分类问题类型"""
        q_lower = question.lower()
        
        if any(kw in q_lower for kw in ["是否", "要不要", "该不"]):
            return "choice"  # 选择类
        elif any(kw in q_lower for kw in ["优先级", "先后", "先做"]):
            return "priority"  # 优先级类
        elif any(kw in q_lower for kw in ["风险", "会不会", "可能"]):
            return "risk"  # 风险评估类
        elif any(kw in q_lower for kw in ["投入", "成本", "资源"]):
            return "resource"  # 资源分配类
        else:
            return "general"
    
    def _get_key_factors(self, question_type: str) -> List[str]:
        """获取关键考虑因素"""
        approach = self.decision.get("approach", "数据驱动")
        
        factors_map = {
            "数据分析": ["数据指标", "历史对比", "趋势分析", "量化指标"],
            "经验判断": ["过往案例", "直觉经验", "类似情况", "专家意见"],
            "团队意见": ["团队共识", "多方意见", "协作影响", "沟通成本"],
            "成本效益": ["投入产出比", "性价比", "边际成本", "机会成本"]
        }
        
        return factors_map.get(approach, factors_map["数据分析"])
    
    def _analyze(self, question: str, context: Optional[str] = None, multi_angle: bool = False) -> Dict:
        """分析问题"""
        question_type = self._classify_question(question)
        approach = self.decision.get("approach", "数据驱动")
        risk_tolerance = self.decision.get("risk_tolerance", "中等")
        focus_areas = self.decision.get("focus_areas", [])
        key_factors = self._get_key_factors(question_type)
        
        # 生成可能的判断
        possible_judgment = self._generate_judgment(question, question_type, approach)
        
        # 生成推理过程
        reasoning = self._generate_reasoning(question, context, approach, key_factors)
        
        # 分析结果
        analysis = {
            "question": question,
            "context": context,
            "question_type": question_type,
            "clone_info": {
                "name": self.clone_name,
                "position": self.clone_position,
                "decision_approach": approach
            },
            "possible_judgment": possible_judgment,
            "reasoning": reasoning,
            "key_factors": key_factors,
            "focus_areas": focus_areas,
            "risk_assessment": self._assess_risk(question, risk_tolerance),
            "information_gaps": self._identify_gaps(question, context),
            "multi_angle": {}
        }
        
        # 多角度分析
        if multi_angle:
            analysis["multi_angle"] = self._multi_angle_analysis(question, context)
        
        return analysis
    
    def _generate_judgment(self, question: str, q_type: str, approach: str) -> Dict:
        """生成可能的判断"""
        judgments = {
            "choice": {
                "likely": "倾向于选择收益更高、风险可控的方案",
                "reason": f"采用{approach}的决策方式",
                "confidence": 0.75
            },
            "priority": {
                "likely": "优先处理紧急且重要的事项",
                "reason": "遵循重要性+紧急性的优先级排序",
                "confidence": 0.82
            },
            "risk": {
                "likely": "需要进一步评估风险敞口",
                "reason": "谨慎评估后再做判断",
                "confidence": 0.70
            },
            "resource": {
                "likely": "评估投入产出比后再决定",
                "reason": "关注资源使用效率",
                "confidence": 0.78
            },
            "general": {
                "likely": "需要综合分析后再给出建议",
                "reason": "全面考虑各种因素",
                "confidence": 0.68
            }
        }
        
        result = judgments.get(q_type, judgments["general"])
        result["note"] = "辅助参考，非最终决策"
        
        return result
    
    def _generate_reasoning(self, question: str, context: Optional[str], approach: str, factors: List[str]) -> str:
        """生成推理过程"""
        reasoning_parts = [
            f"基于{approach}的决策方式，"
        ]
        
        if approach == "数据分析":
            reasoning_parts.append("我会先收集相关数据指标，进行量化分析，")
            reasoning_parts.append("然后对比历史数据和行业基准，")
        elif approach == "经验判断":
            reasoning_parts.append("我会回顾类似案例的处理经验，")
            reasoning_parts.append("结合当前情况进行判断，")
        elif approach == "团队意见":
            reasoning_parts.append("我会征求团队相关人员的意见，")
            reasoning_parts.append("综合各方观点后再做决定，")
        elif approach == "成本效益":
            reasoning_parts.append("我会计算投入产出比，")
            reasoning_parts.append("评估性价比后再做决策，")
        else:
            reasoning_parts.append("我会综合考虑各种因素，")
        
        reasoning_parts.append("最终给出分析建议。")
        
        return "".join(reasoning_parts)
    
    def _assess_risk(self, question: str, risk_tolerance: str) -> Dict:
        """评估风险"""
        risk_map = {
            "较低": "倾向于保守策略，控制风险敞口",
            "中等": "平衡风险与收益，可接受适度风险",
            "依赖经验": "根据经验判断，灵活处理",
            "成本敏感": "优先控制成本，降低风险"
        }
        
        return {
            "tolerance": risk_tolerance,
            "strategy": risk_map.get(risk_tolerance, "平衡策略"),
            "note": "风险评估仅供参考"
        }
    
    def _identify_gaps(self, question: str, context: Optional[str]) -> List[str]:
        """识别信息缺口"""
        gaps = []
        
        if not context:
            gaps.append("缺少问题背景信息")
        
        # 检查常见信息缺失
        if any(kw in question for kw in ["客户", "对方"]):
            gaps.append("可能需要对方的具体需求和底线")
        
        if any(kw in question for kw in ["成本", "价格", "投入"]):
            gaps.append("需要具体的成本/收益数据")
        
        if any(kw in question for kw in ["时间", "期限", "何时"]):
            gaps.append("需要明确的时间要求")
        
        if not gaps:
            gaps.append("信息相对完整")
        
        return gaps
    
    def _multi_angle_analysis(self, question: str, context: Optional[str]) -> Dict:
        """多角度分析"""
        return {
            "from_data": {
                "angle": "数据视角",
                "analysis": "建议收集相关数据指标进行量化分析",
                "questions": ["有哪些可量化的指标？", "历史数据表现如何？"]
            },
            "from_experience": {
                "angle": "经验视角",
                "analysis": "参考过往类似案例的处理方式",
                "questions": ["之前遇到过类似情况吗？", "当时是怎么处理的？"]
            },
            "from_stakeholder": {
                "angle": "利益相关方视角",
                "analysis": "考虑各方的立场和诉求",
                "questions": ["这个决定会影响谁？", "各方的核心关切是什么？"]
            },
            "from_risk": {
                "angle": "风险视角",
                "analysis": "评估潜在风险和应对方案",
                "questions": ["最坏情况是什么？", "有什么预防措施？"]
            }
        }
    
    def analyze(self, question: str, context: Optional[str] = None, multi_angle: bool = False) -> Dict:
        """执行分析"""
        return self._analyze(question, context, multi_angle)
    
    def display(self, analysis: Dict):
        """显示分析结果"""
        console.print("\n")
        
        # 决策者信息
        info = analysis["clone_info"]
        console.print(Panel.fit(
            f"[bold cyan]👤 {info['name']}[/bold cyan] ({info['position']})\n"
            f"决策方式: {info['decision_approach']}",
            title="决策辅助分析",
            border_style="cyan"
        ))
        
        # 问题
        console.print(f"\n[bold yellow]❓ 问题:[/bold yellow] {analysis['question']}")
        if analysis['context']:
            console.print(f"[bold yellow]📌 背景:[/bold yellow] {analysis['context']}")
        
        # 可能的判断
        judgment = analysis["possible_judgment"]
        console.print(Panel.fit(
            f"[bold green]💡 可能的判断[/bold green]\n\n"
            f"{judgment['likely']}\n\n"
            f"[dim]原因: {judgment['reason']}[/dim]\n"
            f"[dim]置信度: {judgment['confidence']*100:.0f}%[/dim]",
            border_style="green"
        ))
        
        # 推理过程
        console.print(Panel.fit(
            f"[bold blue]🧠 推理过程[/bold blue]\n\n{analysis['reasoning']}",
            border_style="blue"
        ))
        
        # 关键考虑因素
        table = Table(title="⚖️ 关键考虑因素", show_header=True)
        table.add_column("因素", style="cyan", width=20)
        table.add_column("说明", style="white")
        
        for factor in analysis["key_factors"]:
            table.add_row(factor, "")
        
        console.print(table)
        
        # 信息缺口
        gaps = analysis["information_gaps"]
        console.print(f"\n[bold red]⚠️ 信息缺口:[/bold red]")
        for gap in gaps:
            console.print(f"  • {gap}")
        
        # 多角度分析
        if analysis.get("multi_angle"):
            console.print("\n")
            tree = Tree("[bold magenta]🔍 多角度分析[/bold magenta]")
            
            for key, angle in analysis["multi_angle"].items():
                angle_tree = Tree(f"[bold]{angle['angle']}[/bold]")
                angle_tree.add(f"分析: {angle['analysis']}")
                for q in angle.get("questions", []):
                    angle_tree.add(f"  → {q}")
                tree.add(angle_tree)
            
            console.print(tree)
        
        # 风险评估
        risk = analysis["risk_assessment"]
        console.print(Panel.fit(
            f"[bold orange]⚡ 风险态度[/bold orange]\n\n"
            f"承受度: {risk['tolerance']}\n"
            f"策略: {risk['strategy']}",
            border_style="orange"
        ))
        
        # 重要提示
        console.print("\n")
        console.print(Panel.fit(
            "[bold red]⚠️ 重要声明[/bold red]\n\n"
            "以上为克隆体辅助分析，仅供参考。\n"
            "最终决策权在真人，克隆体不对决策结果负责。",
            border_style="red"
        ))


@click.command(help="按员工思路分析问题，'如果是他，他会怎么判断'\n\n新手建议：先从 /创建克隆 快速模式开始")
@click.option("--profile", "-p", required=True, help="克隆体画像配置文件路径")
@click.option("--question", "-q", required=True, help="需要决策的问题")
@click.option("--context", "-c", default=None, help="问题的背景信息")
@click.option("--multi-angle", "-m", is_flag=True, help="进行多角度分析")
def main(profile: str, question: str, context: str, multi_angle: bool):
    """决策辅助主入口"""
    try:
        aid = DecisionAid(profile)
        analysis = aid.analyze(question, context, multi_angle)
        aid.display(analysis)
    
    except FileNotFoundError:
        console.print(f"[bold red]错误: 找不到文件: {profile}[/bold red]")
    except Exception as e:
        console.print(f"[bold red]处理出错: {e}[/bold red]")


if __name__ == "__main__":
    main()
