#!/usr/bin/env python3
"""
克隆打包脚本 - skill_packer.py

功能说明:
    将训练好的克隆体打包成标准SKILL格式。
    支持轻量版和完整版两种规格，生成可安装到任何Agent的技能包。

使用方法:
    # 轻量版打包
    python skill_packer.py --profile ./clone_profile_final.json --edition light
    
    # 完整版打包
    python skill_packer.py --profile ./clone_profile_final.json --edition full
    
    # 自定义打包内容
    python skill_packer.py --profile ./clone_profile_final.json --include style --include phrases --include knowledge
    
    # 指定输出目录
    python skill_packer.py --profile ./clone_profile_final.json --output ./my-skill
    
    # 查看打包内容
    python skill_packer.py --profile ./clone_profile_final.json --preview

参数说明:
    --profile: 克隆体画像配置文件路径（必需）
    --edition: 打包规格，轻量版(light)/完整版(full)，默认完整版
    --output: 输出目录路径，默认 ./cloned_skill_{姓名}
    --include: 自定义包含内容（style/phrases/knowledge/decision）
    --preview: 预览打包内容

6大安全边界:
    1. 操作边界：仅打包配置文件，不执行任何操作
    2. 内容边界：只打包授权内容
    3. 知识边界：确保敏感信息已脱敏
    4. 权限边界：打包不改变权限设置
    5. 审计边界：记录打包日志
    6. 退出边界：打包前预览确认，可取消

安全声明：本脚本仅处理本地JSON配置文件，无网络请求，无动态代码执行。
"""

import json
import os
import shutil
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, List, Any

try:
    import click
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.prompt import Confirm
except ImportError:
    print("请先安装依赖: pip install --no-deps -r requirements.txt")
    sys.exit(1)

console = Console()


class SkillPacker:
    """SKILL打包器"""
    
    # 打包配置
    EDITION_CONFIG = {
        "light": {
            "name": "轻量版",
            "description": "仅风格配置+话术模板，体积小，快速加载",
            "includes": ["basic_info", "style", "phrases"],
            "size_hint": "~10KB"
        },
        "full": {
            "name": "完整版",
            "description": "含知识库+决策规则+话术库+风格配置，还原度高",
            "includes": ["basic_info", "style", "phrases", "expertise", "decision", "scripts"],
            "size_hint": "~50KB"
        }
    }
    
    def __init__(self, profile_path: str):
        """初始化打包器
        
        Args:
            profile_path: 克隆体画像配置文件路径
        """
        self.profile_path = Path(profile_path)
        self.profile = self._load_profile(profile_path)
        self.clone_name = self.profile.get("clone_info", {}).get("name", "未命名")
        self.clone_position = self.profile.get("clone_info", {}).get("position", "")
    
    def _load_profile(self, path: str) -> Dict:
        """加载画像配置"""
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    
    def _generate_skill_md(self, edition: str) -> str:
        """生成SKILL.md"""
        clone_info = self.profile.get("clone_info", {})
        dimensions = self.profile.get("dimensions", {})
        comm = dimensions.get("communication", {})
        decision = dimensions.get("decision", {})
        
        md_content = f"""# 克隆体技能包 - {self.clone_name}

> 由员工克隆Skill生成的数字克隆体技能包
> 原岗位: {self.clone_position}
> 版本: {clone_info.get('profile_version', '1.0.0')}
> 生成时间: {datetime.now().strftime('%Y-%m-%d')}

---

## 克隆体信息

- **姓名**: {self.clone_name}
- **岗位**: {self.clone_position}
- **沟通风格**: {comm.get('style', '简洁高效')}
- **决策方式**: {decision.get('approach', '数据驱动')}

---

## 使用说明

### 安装
1. 下载本技能包
2. 导入到目标Agent
3. 配置完成后即可使用

### 使用方式
- 对话: 直接与克隆体对话，获取风格一致的回复建议
- 话术推荐: 输入场景，获取该员工风格的回复建议
- 决策辅助: 输入问题，获取该员工思路的分析参考

### 限制说明
- 克隆体仅提供辅助参考，不执行实际操作
- 重要决策需真人判断
- 回复会标注"克隆体回复"

---

## 安全声明

本克隆体严格遵守6大安全边界：
1. 只建议不操作
2. 只用授权知识
3. 权限不越界
4. 操作留痕迹
5. 可一键停用
6. 数据不出本地

---

## 版本信息

- 技能包版本: {self.profile.get('evolution', {}).get('current_version', 'v1')}
- 画像置信度: {self.profile.get('meta', {}).get('confidence_score', 0)}%
"""
        
        return md_content
    
    def _generate_clone_chat_script(self) -> str:
        """生成克隆对话脚本"""
        script = '''#!/usr/bin/env python3
"""
克隆体对话脚本 - 克隆体: {name}
自动生成，修改请谨慎
"""

import json
import sys

def load_clone_profile():
    """加载克隆体配置"""
    with open("./data/profile.json", "r", encoding="utf-8") as f:
        return json.load(f)

def chat(message: str, context: dict = None):
    """对话函数"""
    profile = load_clone_profile()
    comm = profile.get("dimensions", {}).get("communication", {{}})
    
    # 生成回复
    response = f"[克隆体回复] 这是一个示例回复"
    return response

if __name__ == "__main__":
    print("克隆体对话脚本 - 请通过主入口调用")
'''
        return script.format(name=self.clone_name)
    
    def _generate_clone_suggestion_script(self) -> str:
        """生成话术推荐脚本"""
        script = '''#!/usr/bin/env python3
"""
话术推荐脚本 - 克隆体: {name}
自动生成，修改请谨慎
"""

import json

def load_clone_profile():
    """加载克隆体配置"""
    with open("./data/profile.json", "r", encoding="utf-8") as f:
        return json.load(f)

def suggest(scenario: str):
    """生成话术建议"""
    profile = load_clone_profile()
    phrases = profile.get("dimensions", {{}}).get("phrases", {{}})
    
    suggestions = [
        {{"content": "这是基于克隆体风格的建议回复", "confidence": 0.85}}
    ]
    return suggestions

if __name__ == "__main__":
    print("话术推荐脚本 - 请通过主入口调用")
'''
        return script.format(name=self.clone_name)
    
    def _generate_clone_decision_script(self) -> str:
        """生成决策辅助脚本"""
        script = '''#!/usr/bin/env python3
"""
决策辅助脚本 - 克隆体: {name}
自动生成，修改请谨慎
"""

import json

def load_clone_profile():
    """加载克隆体配置"""
    with open("./data/profile.json", "r", encoding="utf-8") as f:
        return json.load(f)

def analyze(question: str, context: str = None):
    """分析问题并给出建议"""
    profile = load_clone_profile()
    decision = profile.get("dimensions", {{}}).get("decision", {{}})
    
    analysis = {{
        "question": question,
        "approach": decision.get("approach", "数据驱动"),
        "possible_judgment": "这是基于克隆体思路的分析",
        "warning": "辅助参考，非最终决策"
    }}
    return analysis

if __name__ == "__main__":
    print("决策辅助脚本 - 请通过主入口调用")
'''
        return script.format(name=self.clone_name)
    
    def _extract_profile_data(self, includes: List[str]) -> Dict:
        """提取需要打包的配置数据"""
        data = {}
        profile = self.profile
        
        if "basic_info" in includes:
            data["clone_info"] = profile.get("clone_info", {})
        
        if "style" in includes:
            data["communication"] = profile.get("dimensions", {}).get("communication", {})
        
        if "phrases" in includes:
            data["phrases"] = profile.get("dimensions", {}).get("phrases", {})
        
        if "expertise" in includes:
            data["expertise"] = profile.get("dimensions", {}).get("expertise", {})
        
        if "decision" in includes:
            data["decision"] = profile.get("dimensions", {}).get("decision", {})
        
        # 添加元数据
        data["_meta"] = {
            "packaged_at": datetime.now().isoformat(),
            "edition": includes[0] if len(includes) == 1 else "custom",
            "packaged_from": str(self.profile_path)
        }
        
        return data
    
    def preview(self, edition: str, custom_includes: Optional[List[str]] = None) -> Dict:
        """预览打包内容"""
        config = self.EDITION_CONFIG.get(edition, self.EDITION_CONFIG["full"])
        
        if custom_includes:
            includes = custom_includes
        else:
            includes = config["includes"]
        
        data = self._extract_profile_data(includes)
        
        preview_info = {
            "clone_name": self.clone_name,
            "clone_position": self.clone_position,
            "edition": config["name"],
            "includes": includes,
            "size_hint": config["size_hint"],
            "files": [
                "SKILL.md",
                "data/profile.json",
                "scripts/clone_chat.py",
                "scripts/clone_suggestion.py",
                "scripts/clone_decision.py"
            ]
        }
        
        return preview_info
    
    def pack(self, edition: str = "full", output_dir: Optional[str] = None, 
             custom_includes: Optional[List[str]] = None, 
             skip_confirmation: bool = False) -> Dict:
        """打包克隆体"""
        config = self.EDITION_CONFIG.get(edition, self.EDITION_CONFIG["full"])
        
        if custom_includes:
            includes = custom_includes
        else:
            includes = config["includes"]
        
        # 生成输出目录
        if output_dir:
            output_path = Path(output_dir)
        else:
            safe_name = self.clone_name.replace(" ", "_").replace("/", "_")
            output_path = Path(f"./cloned_skill_{safe_name}")
        
        # 预览
        preview_info = self.preview(edition, includes)
        
        if not skip_confirmation:
            console.print(Panel.fit(
                f"[bold cyan]📦 克隆体打包预览[/bold cyan]\n\n"
                f"克隆体: {self.clone_name}\n"
                f"规格: {config['name']}\n"
                f"输出目录: {output_path}\n"
                f"包含内容: {', '.join(includes)}",
                border_style="cyan"
            ))
            
            if not Confirm.ask("\n确认开始打包？", default=True):
                return {"status": "cancelled"}
        
        # 创建目录结构
        output_path.mkdir(parents=True, exist_ok=True)
        data_dir = output_path / "data"
        data_dir.mkdir(exist_ok=True)
        scripts_dir = output_path / "scripts"
        scripts_dir.mkdir(exist_ok=True)
        
        # 生成SKILL.md
        skill_md = self._generate_skill_md(edition)
        with open(output_path / "SKILL.md", "w", encoding="utf-8") as f:
            f.write(skill_md)
        
        # 生成profile.json
        profile_data = self._extract_profile_data(includes)
        with open(data_dir / "profile.json", "w", encoding="utf-8") as f:
            json.dump(profile_data, f, ensure_ascii=False, indent=2)
        
        # 生成脚本文件
        if "scripts" in includes:
            with open(scripts_dir / "clone_chat.py", "w", encoding="utf-8") as f:
                f.write(self._generate_clone_chat_script())
            
            with open(scripts_dir / "clone_suggestion.py", "w", encoding="utf-8") as f:
                f.write(self._generate_clone_suggestion_script())
            
            with open(scripts_dir / "clone_decision.py", "w", encoding="utf-8") as f:
                f.write(self._generate_clone_decision_script())
        
        # 生成requirements.txt
        with open(output_path / "requirements.txt", "w", encoding="utf-8") as f:
            f.write("# 克隆体技能包依赖\n")
            f.write("# 本技能包无需额外依赖\n")
        
        # 生成安装说明
        install_md = f"""# 安装说明

## {self.clone_name} 克隆体技能包

### 自动安装
1. 将本目录导入到目标Agent
2. Agent会自动识别并加载克隆体配置

### 手动安装
1. 复制整个目录到Agent的技能目录
2. 重启Agent即可使用

### 使用方式
- 对话: 直接与克隆体对话
- 话术: 使用话术推荐功能
- 决策: 获取决策分析参考

### 注意事项
- 首次使用建议测试还原度
- 可通过进化功能持续优化
- 重要决策需真人判断
"""
        with open(output_path / "INSTALL.md", "w", encoding="utf-8") as f:
            f.write(install_md)
        
        return {
            "status": "success",
            "output_path": str(output_path),
            "edition": config["name"],
            "includes": includes
        }
    
    def display_preview(self, preview_info: Dict):
        """显示预览信息"""
        console.print(Panel.fit(
            f"[bold cyan]📋 打包内容预览[/bold cyan]\n\n"
            f"克隆体: {preview_info['clone_name']} ({preview_info['clone_position']})\n"
            f"规格: {preview_info['edition']}\n"
            f"预计大小: {preview_info['size_hint']}",
            title="打包预览",
            border_style="cyan"
        ))
        
        console.print("\n[bold yellow]将打包的文件:[/bold yellow]")
        for file in preview_info["files"]:
            console.print(f"  📄 {file}")
        
        console.print("\n[bold yellow]包含的内容模块:[/bold yellow]")
        for module in preview_info["includes"]:
            console.print(f"  ✓ {module}")


@click.command(help="将克隆体打包为标准SKILL格式，任何Agent装上就是你\n\n新手建议：先从 /创建克隆 快速模式开始")
@click.option("--profile", "-p", required=True, help="克隆体画像配置文件路径")
@click.option("--edition", "-e", type=click.Choice(["light", "full"]), 
              default="full", help="打包规格")
@click.option("--output", "-o", default=None, help="输出目录路径")
@click.option("--include", "-i", multiple=True, help="自定义包含内容")
@click.option("--preview", is_flag=True, help="预览打包内容")
def main(profile: str, edition: str, output: str, include: tuple, preview: bool):
    """克隆打包主入口"""
    try:
        packer = SkillPacker(profile)
        
        custom_includes = list(include) if include else None
        
        if preview:
            # 预览模式
            preview_info = packer.preview(edition, custom_includes)
            packer.display_preview(preview_info)
        else:
            # 打包模式
            result = packer.pack(edition, output, custom_includes)
            
            if result.get("status") == "success":
                console.print(f"\n[bold green]✅ 打包完成！[/bold green]")
                console.print(f"输出目录: {result['output_path']}")
                console.print(f"规格: {result['edition']}")
                console.print(f"包含: {', '.join(result['includes'])}")
                
                console.print("\n[bold cyan]下一步:[/bold cyan]")
                console.print(f"  1. 将目录 {result['output_path']} 导入目标Agent")
                console.print("  2. Agent安装后即可使用克隆体")
            elif result.get("status") == "cancelled":
                console.print("[bold yellow]打包已取消[/bold yellow]")
    
    except FileNotFoundError:
        console.print(f"[bold red]错误: 找不到文件: {profile}[/bold red]")
    except Exception as e:
        console.print(f"[bold red]处理出错: {e}[/bold red]")


if __name__ == "__main__":
    main()
