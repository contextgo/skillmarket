#!/usr/bin/env python3
"""
克隆创建脚本 - clone_creator.py

功能说明:
    问答式引导创建克隆体，支持三种创建模式：快速（5分钟）、标准（20分钟）、深度（1-2小时）。
    通过交互式问答收集员工的工作特点、沟通风格、决策偏好等信息，生成克隆体基础配置文件。

使用方法:
    # 快速模式（默认）
    python clone_creator.py --mode quick
    
    # 标准模式（包含文件导入）
    python clone_creator.py --mode standard
    
    # 深度模式（包含决策案例）
    python clone_creator.py --mode deep
    
    # 保存到指定位置
    python clone_creator.py --output ./my_clone.json

参数说明:
    --mode: 创建模式，快速(quick)/标准(standard)/深度(deep)，默认快速
    --output: 输出文件路径，默认 ./clone_profile.json
    --name: 克隆体名称（可选）

6大安全边界:
    1. 操作边界：仅创建配置，不执行任何操作
    2. 内容边界：只记录授权信息，不承诺任何事项
    3. 知识边界：用户主动提供信息，不自动获取
    4. 权限边界：克隆体权限不高于创建者
    5. 审计边界：记录创建日志，可追溯
    6. 退出边界：随时可中断，配置文件可删除
"""

import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, List, Any

try:
    import click
    from rich.console import Console
    from rich.panel import Panel
    from rich.prompt import Prompt, Confirm
    from rich.table import Table
except ImportError:
    print("请先安装依赖: pip install --no-deps -r requirements.txt")
    sys.exit(1)

console = Console()


class CloneCreator:
    """克隆体创建器"""
    
    # 快速模式5个核心问题
    QUICK_QUESTIONS = [
        {
            "key": "name",
            "question": "请输入你的姓名和岗位（如：张三-销售经理）：",
            "required": True
        },
        {
            "key": "daily_tasks",
            "question": "你最常处理的3类工作是什么？请用逗号分隔：",
            "required": True
        },
        {
            "key": "communication_style",
            "question": "你的沟通风格是？\n  1. 正式严谨  2. 亲切友好  3. 简洁高效  4. 详细耐心\n请选择（1-4）：",
            "required": True,
            "options": {"1": "正式严谨", "2": "亲切友好", "3": "简洁高效", "4": "详细耐心"}
        },
        {
            "key": "catchphrase",
            "question": "你有什么口头禅或固定话术吗？（没有可跳过）：",
            "required": False
        },
        {
            "key": "typical_scenario",
            "question": "描述一个你最典型的工作场景（比如：处理客户投诉/晨会汇报/代码评审）：",
            "required": True
        }
    ]
    
    # 标准模式额外问题
    STANDARD_QUESTIONS = [
        {
            "key": "expertise_area",
            "question": "你的专业领域是什么？有哪些核心技能？",
            "required": True
        },
        {
            "key": "decision_pattern",
            "question": "你做决策时通常更看重什么？\n  1. 数据分析  2. 经验判断  3. 团队意见  4. 成本效益\n请选择（1-4）：",
            "required": True,
            "options": {"1": "数据分析", "2": "经验判断", "3": "团队意见", "4": "成本效益"}
        },
        {
            "key": "response_templates",
            "question": "你有哪些常用的回复模板？（如：感谢您的反馈/已收到/我们会尽快处理）",
            "required": False
        },
        {
            "key": "boundary_cases",
            "question": "工作中遇到边界情况你通常怎么处理？请举例：",
            "required": False
        }
    ]
    
    # 深度模式额外问题
    DEEP_QUESTIONS = [
        {
            "key": "case_history",
            "question": "请提供几个你的典型决策案例（可以是脱敏后的描述）：\n案例1 - 背景/决策/结果：",
            "required": True
        },
        {
            "key": "thinking_pattern",
            "question": "你思考问题的思维模式是怎样的？\n  1. 逻辑分析型  2. 直觉经验型  3. 创新突破型  4. 稳健保守型\n请选择（1-4）：",
            "required": True,
            "options": {"1": "逻辑分析型", "2": "直觉经验型", "3": "创新突破型", "4": "稳健保守型"}
        },
        {
            "key": "stress_response",
            "question": "高压情况下你的工作方式会有什么变化？",
            "required": False
        },
        {
            "key": "learning_style",
            "question": "你如何学习和更新知识？有哪些信息源？",
            "required": False
        }
    ]
    
    def __init__(self, mode: str = "quick"):
        """初始化克隆创建器
        
        Args:
            mode: 创建模式，快速(quick)/标准(standard)/深度(deep)
        """
        self.mode = mode
        self.profile: Dict[str, Any] = {
            "version": "1.0.0",
            "created_at": datetime.now().isoformat(),
            "created_mode": mode,
            "privacy_acknowledged": False,
            "data": {
                "basic": {},
                "expertise": {},
                "communication": {},
                "decision": {},
                "phrases": {}
            }
        }
    
    def _get_mode_description(self) -> str:
        """获取模式描述"""
        descriptions = {
            "quick": "快速模式（5分钟）：回答5个核心问题，生成基础克隆体",
            "standard": "标准模式（20分钟）：回答核心+专业问题，并可导入工作文档",
            "deep": "深度模式（1-2小时）：完整建模，包含决策案例分析"
        }
        return descriptions.get(self.mode, descriptions["quick"])
    
    def _ask_question(self, q: Dict) -> Optional[str]:
        """提问并获取回答"""
        console.print()
        response = Prompt.ask(
            f"[bold cyan]{q['question']}[/bold cyan]",
            default=""
        )
        return response if response.strip() else None
    
    def _parse_answer(self, q: Dict, answer: Optional[str]) -> Any:
        """解析回答"""
        if answer is None:
            return None if q.get("required", False) is False else ""
        
        if "options" in q and answer in q["options"]:
            return q["options"][answer]
        
        return answer
    
    def _update_profile(self, key: str, value: Any):
        """更新配置文件"""
        keys = key.split(".")
        d = self.profile["data"]
        for k in keys[:-1]:
            if k not in d:
                d[k] = {}
            d = d[k]
        d[keys[-1]] = value
    
    def create_quick(self) -> Dict[str, Any]:
        """快速创建模式"""
        console.print(Panel.fit(
            "[bold green]🚀 快速创建模式（5分钟）[/bold green]\n"
            "回答5个核心问题，快速生成基础克隆体",
            border_style="green"
        ))
        console.print("\n[dim]📌 这一步会问你5个简单问题，帮助AI了解你的工作风格[/dim]\n")
        
        step_descriptions = [
            "【个人信息】这一步收集你的基本身份信息，用于命名你的克隆体",
            "【日常工作】这一步了解你最常处理的工作类型，让克隆体知道你的专业领域",
            "【沟通风格】这一步选择你平时的沟通方式，是正式严谨还是亲切友好？",
            "【口头禅】这一步可以输入你的口头禅（可选），让克隆体更像你",
            "【典型场景】这一步描述一个你最典型的工作场景，帮助AI理解你的工作模式"
        ]
        
        for i, q in enumerate(self.QUICK_QUESTIONS, 1):
            console.print(f"\n[bold yellow]📝 问题 {i}/5 - {step_descriptions[i-1]}[/bold yellow]")
            answer = self._ask_question(q)
            parsed = self._parse_answer(q, answer)
            
            if q["key"] == "name":
                if "/" in (parsed or ""):
                    parts = (parsed or "").split("-", 1)
                    self.profile["data"]["basic"]["name"] = parts[0].strip()
                    self.profile["data"]["basic"]["position"] = parts[1].strip() if len(parts) > 1 else ""
                else:
                    self.profile["data"]["basic"]["name"] = parsed
            else:
                self._update_profile(q["key"], parsed)
        
        # 设置默认值
        self.profile["data"].setdefault("expertise", {})["level"] = "基础"
        self.profile["data"].setdefault("communication", {})["tone"] = self.profile["data"].get("communication_style", "简洁高效")
        
        return self.profile
    
    def create_standard(self) -> Dict[str, Any]:
        """标准创建模式"""
        console.print(Panel.fit(
            "[bold blue]📋 标准创建模式（20分钟）[/bold blue]\n"
            "回答核心+专业问题，并可导入工作文档",
            border_style="blue"
        ))
        
        # 先执行快速模式
        self.create_quick()
        
        console.print(f"\n[bold yellow]继续回答 {len(self.STANDARD_QUESTIONS)} 个专业问题[/bold yellow]")
        
        for i, q in enumerate(self.STANDARD_QUESTIONS, len(self.QUICK_QUESTIONS) + 1):
            console.print(f"\n[bold yellow]问题 {i}/{len(self.QUICK_QUESTIONS) + len(self.STANDARD_QUESTIONS)}[/bold yellow]")
            answer = self._ask_question(q)
            parsed = self._parse_answer(q, answer)
            self._update_profile(q["key"], parsed)
        
        return self.profile
    
    def create_deep(self) -> Dict[str, Any]:
        """深度创建模式"""
        console.print(Panel.fit(
            "[bold magenta]🎯 深度创建模式（1-2小时）[/bold magenta]\n"
            "完整建模，包含决策案例分析",
            border_style="magenta"
        ))
        
        # 先执行标准模式
        self.create_standard()
        
        console.print(f"\n[bold yellow]继续回答 {len(self.DEEP_QUESTIONS)} 个深度问题[/bold yellow]")
        
        for i, q in enumerate(self.DEEP_QUESTIONS, 1):
            console.print(f"\n[bold yellow]深度问题 {i}/{len(self.DEEP_QUESTIONS)}[/bold yellow]")
            answer = self._ask_question(q)
            parsed = self._parse_answer(q, answer)
            self._update_profile(q["key"], parsed)
        
        # 添加决策案例解析
        self._extract_decision_patterns()
        
        return self.profile
    
    def _extract_decision_patterns(self):
        """从案例中提取决策模式"""
        case_history = self.profile["data"].get("case_history", "")
        if case_history:
            self.profile["data"]["decision"]["case_reference"] = case_history
            self.profile["data"]["decision"]["pattern_extracted"] = True
    
    def create(self) -> Dict[str, Any]:
        """执行创建流程"""
        method_map = {
            "quick": self.create_quick,
            "standard": self.create_standard,
            "deep": self.create_deep
        }
        
        method = method_map.get(self.mode, self.create_quick)
        return method()
    
    def display_summary(self):
        """显示创建摘要"""
        console.print("\n")
        table = Table(title="📊 克隆体创建摘要", show_header=True, header_style="bold magenta")
        table.add_column("维度", style="cyan", width=15)
        table.add_column("内容", style="white")
        
        basic = self.profile["data"].get("basic", {})
        table.add_row("姓名", basic.get("name", "未设置"))
        table.add_row("岗位", basic.get("position", "未设置"))
        table.add_row("沟通风格", self.profile["data"].get("communication", {}).get("tone", "未设置"))
        table.add_row("决策倾向", self.profile["data"].get("decision", {}).get("pattern", "未设置"))
        
        console.print(table)
    
    def save(self, output_path: str):
        """保存配置文件"""
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.profile, f, ensure_ascii=False, indent=2)
        
        console.print(f"\n[bold green]✅ 克隆体配置已保存到: {path}[/bold green]")


def privacy_agreement() -> bool:
    """隐私协议确认"""
    console.print(Panel.fit(
        "[bold red]⚠️ 隐私与伦理声明[/bold red]\n\n"
        "1. 只能克隆自己，严禁克隆他人\n"
        "2. 训练完成后原始数据将删除，仅保留画像\n"
        "3. 克隆体归属员工本人，可带走或销毁\n"
        "4. 克隆体回复必须标明'AI克隆体回复'，不能伪装真人\n"
        "5. 克隆体只建议不操作，不能替代本人做决策",
        border_style="red"
    ))
    return Confirm.ask("你是否同意上述声明并确认克隆自己？", default=False)


@click.command(help="问答式创建克隆体 - 支持快速/标准/深度三种模式\n\n新手建议：先从 /创建克隆 快速模式开始")
@click.option("--mode", "-m", type=click.Choice(["quick", "standard", "deep"]), 
              default="quick", help="创建模式")
@click.option("--output", "-o", default="./clone_profile.json", help="输出文件路径")
@click.option("--name", "-n", default=None, help="克隆体名称")
def main(mode: str, output: str, name: str):
    """克隆创建主入口"""
    console.print(Panel.fit(
        "[bold cyan]👤 员工克隆Skill - 克隆创建向导[/bold cyan]\n"
        "克隆你的工作能力，让AI以你的风格工作",
        border_style="cyan"
    ))
    
    # 隐私协议确认
    if not privacy_agreement():
        console.print("[bold red]已取消创建[/bold red]")
        sys.exit(0)
    
    # 创建克隆体
    creator = CloneCreator(mode=mode)
    profile = creator.create()
    
    # 如果指定了名称
    if name:
        profile["data"]["basic"]["name"] = name
        profile["name"] = name
    
    # 显示摘要
    creator.display_summary()
    
    # 确认保存
    if Confirm.ask("是否保存克隆体配置？", default=True):
        creator.save(output)
        console.print("\n[bold green]🎉 克隆体创建完成！[/bold green]")
        console.print(f"可通过运行其他脚本使用克隆体，如：")
        console.print(f"  python style_chat.py --profile {output}")
    else:
        console.print("[bold yellow]配置未保存[/bold yellow]")


if __name__ == "__main__":
    main()
