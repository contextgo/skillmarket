#!/usr/bin/env python3
"""
持续进化脚本 - evolution.py

功能说明:
    接收新的工作案例，自动提取模式和风格变化。
    版本管理支持回退，进化后需用户确认才应用。

使用方法:
    # 添加新案例
    python evolution.py --profile ./clone_profile_final.json --add-case "客户说要再考虑一下"
    
    # 批量导入案例
    python evolution.py --profile ./clone_profile_final.json --batch-cases ./new_cases.json
    
    # 查看版本历史
    python evolution.py --profile ./clone_profile_final.json --history
    
    # 回退到指定版本
    python evolution.py --profile ./clone_profile_final.json --rollback v1
    
    # 生成进化报告
    python evolution.py --profile ./clone_profile_final.json --report

参数说明:
    --profile: 克隆体画像配置文件路径（必需）
    --add-case: 添加单个案例
    --batch-cases: 批量导入案例文件
    --history: 查看版本历史
    --rollback: 回退到指定版本
    --report: 生成进化报告

6大安全边界:
    1. 操作边界：仅更新配置，不执行任何操作
    2. 内容边界：只学习用户主动提供的案例
    3. 知识边界：不自动从系统获取新知识
    4. 权限边界：进化不影响权限边界
    5. 审计边界：记录所有进化操作
    6. 退出边界：进化需确认后才应用，可随时停止

安全声明：本脚本仅处理本地JSON配置文件，无网络请求，无动态代码执行。
"""

import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, List, Any
from copy import deepcopy

try:
    import click
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.prompt import Confirm, Prompt
except ImportError:
    print("请先安装依赖: pip install --no-deps -r requirements.txt")
    sys.exit(1)

console = Console()


class EvolutionEngine:
    """持续进化引擎"""
    
    def __init__(self, profile_path: str):
        """初始化进化引擎
        
        Args:
            profile_path: 克隆体画像配置文件路径
        """
        self.profile_path = Path(profile_path)
        self.profile = self._load_profile(profile_path)
        self.clone_name = self.profile.get("clone_info", {}).get("name", "克隆体")
        
        # 初始化进化记录
        if "evolution" not in self.profile:
            self.profile["evolution"] = {
                "versions": [],
                "current_version": "v1",
                "history": []
            }
        
        # 版本计数
        self._version_count = len(self.profile["evolution"]["versions"])
    
    def _load_profile(self, path: str) -> Dict:
        """加载画像配置"""
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    
    def _save_profile(self):
        """保存画像配置"""
        with open(self.profile_path, "w", encoding="utf-8") as f:
            json.dump(self.profile, f, ensure_ascii=False, indent=2)
    
    def _get_next_version(self) -> str:
        """获取下一个版本号"""
        self._version_count += 1
        return f"v{self._version_count}"
    
    def _extract_patterns(self, case: str) -> Dict:
        """从案例中提取模式"""
        patterns = {
            "keywords": [],
            "style_hints": [],
            "decision_hints": []
        }
        
        # 简单关键词提取
        if any(w in case for w in ["感谢", "谢谢", "抱歉", "对不起"]):
            patterns["style_hints"].append("礼貌用语")
        if any(w in case for w in ["但是", "不过", "然而"]):
            patterns["style_hints"].append("转折表达")
        if any(w in case for w in ["首先", "然后", "最后"]):
            patterns["style_hints"].append("分点说明")
        if any(w in case for w in ["可能", "也许", "大概"]):
            patterns["style_hints"].append("谨慎表达")
        if any(w in case for w in ["一定", "肯定", "绝对"]):
            patterns["style_hints"].append("确定表达")
        
        # 决策相关
        if any(w in case for w in ["决定", "选择", "采纳"]):
            patterns["decision_hints"].append("包含决策内容")
        if any(w in case for w in ["建议", "推荐", "考虑"]):
            patterns["decision_hints"].append("包含建议内容")
        
        return patterns
    
    def _detect_style_change(self, new_patterns: Dict) -> Optional[str]:
        """检测风格变化"""
        existing = self.profile.get("dimensions", {}).get("communication", {})
        style = existing.get("style", "")
        
        if "礼貌用语" in new_patterns.get("style_hints", []):
            if style == "简洁高效":
                return "风格倾向变得更加礼貌"
        
        return None
    
    def add_case(self, case: str) -> Dict:
        """添加新案例"""
        patterns = self._extract_patterns(case)
        style_change = self._detect_style_change(patterns)
        
        # 记录案例
        case_record = {
            "content": case,
            "patterns": patterns,
            "style_change": style_change,
            "added_at": datetime.now().isoformat()
        }
        
        if "cases" not in self.profile["evolution"]:
            self.profile["evolution"]["cases"] = []
        self.profile["evolution"]["cases"].append(case_record)
        
        return {
            "case": case,
            "patterns": patterns,
            "style_change": style_change,
            "status": "pending"
        }
    
    def batch_add_cases(self, cases: List[str]) -> List[Dict]:
        """批量添加案例"""
        results = []
        for case in cases:
            result = self.add_case(case)
            results.append(result)
        return results
    
    def evolve(self, preview: bool = True) -> Dict:
        """执行进化"""
        cases = self.profile["evolution"].get("cases", [])
        
        if not cases:
            return {"status": "no_cases", "message": "没有新案例需要学习"}
        
        # 统计学习内容
        all_patterns = []
        style_changes = []
        for case in cases:
            all_patterns.extend(case.get("patterns", {}).get("style_hints", []))
            if case.get("style_change"):
                style_changes.append(case["style_change"])
        
        pattern_counts = {}
        for p in all_patterns:
            pattern_counts[p] = pattern_counts.get(p, 0) + 1
        
        # 生成进化报告
        evolution_report = {
            "new_version": self._get_next_version(),
            "cases_learned": len(cases),
            "patterns_learned": pattern_counts,
            "style_changes": style_changes,
            "timestamp": datetime.now().isoformat()
        }
        
        if preview:
            return evolution_report
        
        # 应用进化
        self.profile["evolution"]["versions"].append({
            "version": evolution_report["new_version"],
            "cases_count": len(cases),
            "created_at": evolution_report["timestamp"]
        })
        self.profile["evolution"]["current_version"] = evolution_report["new_version"]
        
        # 更新画像
        self._apply_evolution(cases)
        
        # 清空待学习案例
        self.profile["evolution"]["cases"] = []
        
        # 记录历史
        self.profile["evolution"]["history"].append({
            "version": evolution_report["new_version"],
            "report": evolution_report,
            "applied_at": evolution_report["timestamp"]
        })
        
        return evolution_report
    
    def _apply_evolution(self, cases: List[Dict]):
        """应用进化到画像"""
        # 合并新的表达方式
        all_phrases = []
        for case in cases:
            case_phrases = case.get("patterns", {}).get("style_hints", [])
            all_phrases.extend(case_phrases)
        
        # 更新沟通风格
        if "communication" not in self.profile["dimensions"]:
            self.profile["dimensions"]["communication"] = {}
        
        existing_features = self.profile["dimensions"]["communication"].get("features", [])
        new_features = list(set(existing_features + all_phrases))
        self.profile["dimensions"]["communication"]["features"] = new_features
        
        # 更新时间戳
        self.profile["dimensions"]["meta"] = {
            "last_evolution": datetime.now().isoformat()
        }
    
    def rollback(self, version: str) -> Dict:
        """回退到指定版本"""
        history = self.profile["evolution"].get("history", [])
        
        # 查找版本
        target_record = None
        for record in history:
            if record["version"] == version:
                target_record = record
                break
        
        if not target_record:
            return {"status": "error", "message": f"版本 {version} 不存在"}
        
        # 获取当前版本
        current_version = self.profile["evolution"]["current_version"]
        
        return {
            "status": "preview",
            "target_version": version,
            "current_version": current_version,
            "target_report": target_record["report"]
        }
    
    def confirm_rollback(self, version: str) -> Dict:
        """确认回退"""
        # 简化实现：记录回退操作
        result = {
            "status": "success",
            "version": version,
            "rolled_back_at": datetime.now().isoformat()
        }
        
        # 更新版本
        self.profile["evolution"]["current_version"] = version
        
        # 记录操作
        self.profile["evolution"]["history"].append({
            "action": "rollback",
            "version": version,
            "timestamp": result["rolled_back_at"]
        })
        
        return result
    
    def show_history(self) -> List[Dict]:
        """显示版本历史"""
        return self.profile["evolution"].get("history", [])
    
    def generate_report(self) -> Dict:
        """生成进化报告"""
        evolution = self.profile.get("evolution", {})
        history = evolution.get("history", [])
        cases = evolution.get("cases", [])
        
        # 统计
        total_evolutions = len(history)
        pending_cases = len(cases)
        
        # 计算学习进度
        all_patterns = []
        for case in cases:
            all_patterns.extend(case.get("patterns", {}).get("style_hints", []))
        
        pattern_summary = {}
        for p in all_patterns:
            pattern_summary[p] = pattern_summary.get(p, 0) + 1
        
        return {
            "clone_name": self.clone_name,
            "current_version": evolution.get("current_version", "v1"),
            "total_evolutions": total_evolutions,
            "pending_cases": pending_cases,
            "pending_patterns": pattern_summary,
            "report_time": datetime.now().isoformat()
        }
    
    def display_evolution_preview(self, report: Dict):
        """显示进化预览"""
        console.print(Panel.fit(
            f"[bold cyan]🔄 进化预览 - {report['new_version']}[/bold cyan]\n\n"
            f"将学习 {report['cases_learned']} 个新案例\n"
            f"提取 {len(report['patterns_learned'])} 种新模式",
            border_style="cyan"
        ))
        
        if report.get("patterns_learned"):
            console.print("\n[bold yellow]📚 将学习的新模式:[/bold yellow]")
            for pattern, count in report["patterns_learned"].items():
                console.print(f"  • {pattern}: {count}次")
        
        if report.get("style_changes"):
            console.print("\n[bold orange]⚡ 检测到风格变化:[/bold orange]")
            for change in report["style_changes"]:
                console.print(f"  • {change}")
        
        console.print("\n[bold green]是否确认应用此次进化？[/bold green]")


@click.command(help="持续进化，新案例自动学习，版本管理可回退\n\n新手建议：先从 /创建克隆 快速模式开始")
@click.option("--profile", "-p", required=True, help="克隆体画像配置文件路径")
@click.option("--add-case", "-a", "add_case", default=None, help="添加单个案例")
@click.option("--batch-cases", "-b", default=None, help="批量导入案例文件")
@click.option("--history", is_flag=True, help="查看版本历史")
@click.option("--rollback", "-r", default=None, help="回退到指定版本")
@click.option("--report", is_flag=True, help="生成进化报告")
def main(profile: str, add_case: str, batch_cases: str, history: bool, rollback: str, report: bool):
    """持续进化主入口"""
    try:
        engine = EvolutionEngine(profile)
        
        if add_case:
            # 添加单个案例
            result = engine.add_case(add_case)
            console.print(f"\n[bold green]✅ 案例已添加[/bold green]")
            console.print(f"提取的模式: {result['patterns']}")
            if result.get("style_change"):
                console.print(f"[yellow]风格变化: {result['style_change']}[/yellow]")
            
            # 询问是否进化
            if Confirm.ask("\n是否现在执行进化？", default=False):
                evolution_report = engine.evolve(preview=True)
                engine.display_evolution_preview(evolution_report)
                if Confirm.ask("\n确认应用进化？", default=True):
                    engine.evolve(preview=False)
                    console.print(f"[bold green]✅ 进化完成，当前版本: {evolution_report['new_version']}[/bold green]")
                    engine._save_profile()
        
        elif batch_cases:
            # 批量导入
            with open(batch_cases, "r", encoding="utf-8") as f:
                cases_data = json.load(f)
            
            if isinstance(cases_data, list):
                cases = cases_data
            else:
                cases = cases_data.get("cases", [])
            
            results = engine.batch_add_cases(cases)
            console.print(f"\n[bold green]✅ 已导入 {len(results)} 个案例[/bold green]")
            engine._save_profile()
        
        elif rollback:
            # 回退
            result = engine.rollback(rollback)
            if result.get("status") == "preview":
                console.print(f"\n[bold yellow]确认回退到版本 {rollback}？[/bold yellow]")
                console.print(f"当前版本: {result['current_version']}")
                if Confirm.ask("\n确认回退？", default=False):
                    confirm = engine.confirm_rollback(rollback)
                    engine._save_profile()
                    console.print(f"[bold green]✅ 已回退到版本 {rollback}[/bold green]")
            else:
                console.print(f"[bold red]{result.get('message')}[/bold red]")
        
        elif history:
            # 查看历史
            history_list = engine.show_history()
            if history_list:
                table = Table(title="📜 版本历史", show_header=True)
                table.add_column("版本", style="cyan", width=10)
                table.add_column("时间", style="white", width=20)
                table.add_column("详情", style="dim")
                
                for record in history_list:
                    if record.get("report"):
                        table.add_row(
                            record["version"],
                            record["report"].get("timestamp", "")[:19],
                            f"学习{record['report'].get('cases_learned', 0)}个案例"
                        )
                    elif record.get("action") == "rollback":
                        table.add_row(
                            record["version"],
                            record.get("timestamp", "")[:19],
                            "回退操作"
                        )
                
                console.print(table)
            else:
                console.print("[yellow]暂无版本历史[/yellow]")
        
        elif report:
            # 生成报告
            report_data = engine.generate_report()
            
            console.print(Panel.fit(
                f"[bold cyan]📊 进化报告 - {report_data['clone_name']}[/bold cyan]\n\n"
                f"当前版本: {report_data['current_version']}\n"
                f"已完成进化: {report_data['total_evolutions']}次\n"
                f"待学习案例: {report_data['pending_cases']}个",
                border_style="cyan"
            ))
            
            if report_data.get("pending_patterns"):
                console.print("\n[bold yellow]待学习模式:[/bold yellow]")
                for pattern, count in report_data["pending_patterns"].items():
                    console.print(f"  • {pattern}: {count}次")
        else:
            # 默认显示帮助
            console.print(Panel.fit(
                "[bold cyan]🔄 持续进化工具[/bold cyan]\n\n"
                "使用方式：\n"
                "  --add-case      添加单个案例\n"
                "  --batch-cases   批量导入案例\n"
                "  --history       查看版本历史\n"
                "  --rollback      回退到指定版本\n"
                "  --report        生成进化报告",
                border_style="cyan"
            ))
    
    except FileNotFoundError:
        console.print(f"[bold red]错误: 找不到文件: {profile}[/bold red]")
    except Exception as e:
        console.print(f"[bold red]处理出错: {e}[/bold red]")


if __name__ == "__main__":
    main()
