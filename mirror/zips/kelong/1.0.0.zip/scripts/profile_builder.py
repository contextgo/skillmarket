#!/usr/bin/env python3
"""
画像建模脚本 - profile_builder.py

功能说明:
    构建员工四维画像：专业知识、沟通风格、决策偏好、常用话术。
    基于克隆创建的基础配置和采集的素材，生成完整的克隆体画像。

使用方法:
    # 基于基础配置构建画像
    python profile_builder.py --input ./clone_profile.json
    
    # 合并素材构建更完整的画像
    python profile_builder.py --input ./clone_profile.json --materials ./collected_materials
    
    # 可视化输出画像
    python profile_builder.py --input ./clone_profile.json --visualize
    
    # 保存为指定文件
    python profile_builder.py --input ./clone_profile.json --output ./final_profile.json

参数说明:
    --input: 输入的克隆体配置文件路径
    --materials: 素材采集结果目录（可选）
    --output: 输出文件路径，默认 ./clone_profile_final.json
    --visualize: 是否可视化输出画像

6大安全边界:
    1. 操作边界：仅构建配置，不执行任何操作
    2. 内容边界：只使用授权素材建模
    3. 知识边界：不自动获取未授权信息
    4. 权限边界：画像权限不高于员工本人
    5. 审计边界：记录建模日志，包括使用的素材
    6. 退出边界：画像可删除，原始数据需确认已清理

安全声明：本脚本仅处理本地JSON配置文件，无网络请求，无动态代码执行。
"""

import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, List, Any
from collections import Counter

try:
    import click
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.tree import Tree
    from rich.prompt import Confirm
except ImportError:
    print("请先安装依赖: pip install --no-deps -r requirements.txt")
    sys.exit(1)

console = Console()


class ProfileBuilder:
    """画像建模器"""
    
    # 专业知识层级
    EXPERTISE_LEVELS = {
        "基础": {"score": 25, "description": "了解基本概念和常规操作"},
        "进阶": {"score": 50, "description": "能独立处理常见问题"},
        "熟练": {"score": 75, "description": "有丰富实战经验"},
        "专家": {"score": 95, "description": "能解决复杂问题和带教他人"}
    }
    
    # 沟通风格配置
    COMMUNICATION_STYLES = {
        "正式严谨": {
            "tone": "正式",
            "sentence_length": "较长",
            "features": ["使用专业术语", "逻辑清晰", "很少使用口语"]
        },
        "亲切友好": {
            "tone": "亲和",
            "sentence_length": "中等",
            "features": ["使用称呼", "语气温和", "适当使用表情符号"]
        },
        "简洁高效": {
            "tone": "简洁",
            "sentence_length": "短",
            "features": ["直奔主题", "少废话", "常用短句"]
        },
        "详细耐心": {
            "tone": "详细",
            "sentence_length": "较长",
            "features": ["解释背景", "分点说明", "耐心解答"]
        }
    }
    
    # 决策偏好配置
    DECISION_PATTERNS = {
        "数据分析": {
            "approach": "数据驱动",
            "risk_tolerance": "中等",
            "focus": ["指标", "数据", "效果"]
        },
        "经验判断": {
            "approach": "经验导向",
            "risk_tolerance": "依赖经验",
            "focus": ["案例", "经历", "直觉"]
        },
        "团队意见": {
            "approach": "民主决策",
            "risk_tolerance": "较低",
            "focus": ["共识", "讨论", "反馈"]
        },
        "成本效益": {
            "approach": "效益优先",
            "risk_tolerance": "成本敏感",
            "focus": ["投入产出", "性价比", "资源"]
        }
    }
    
    def __init__(self, input_profile: Dict, materials: Optional[Dict] = None):
        """初始化画像建模器
        
        Args:
            input_profile: 克隆体基础配置
            materials: 采集的素材数据（可选）
        """
        self.profile = input_profile
        self.materials = materials or {}
        self.profile["profile_version"] = "1.0.0"
        self.profile["built_at"] = datetime.now().isoformat()
    
    def _extract_expertise(self) -> Dict[str, Any]:
        """提取专业知识维度"""
        expertise = {
            "level": "基础",
            "skill_tree": [],
            "domain_keywords": [],
            "experience_notes": ""
        }
        
        # 从基础配置提取
        basic_data = self.profile.get("data", {}).get("basic", {})
        expertise_data = self.profile.get("data", {}).get("expertise", {})
        
        # 推断专业等级
        position = basic_data.get("position", "")
        if any(kw in position for kw in ["经理", "总监", "专家", "资深"]):
            expertise["level"] = "熟练"
        elif any(kw in position for kw in ["初级", "助理", "实习"]):
            expertise["level"] = "进阶"
        
        # 从素材中提取关键词
        if self.materials:
            keywords = self.materials.get("extracted_data", {}).get("keywords", [])
            expertise["domain_keywords"] = keywords[:20]
        
        # 技能树
        daily_tasks = self.profile.get("data", {}).get("daily_tasks", "")
        if daily_tasks:
            expertise["skill_tree"] = [t.strip() for t in daily_tasks.split(",")[:5]]
        
        # 专业说明
        exp_area = expertise_data.get("expertise_area", "")
        if exp_area:
            expertise["experience_notes"] = exp_area
        
        return expertise
    
    def _extract_communication(self) -> Dict[str, Any]:
        """提取沟通风格维度"""
        comm = {
            "style": "简洁高效",
            "tone": "简洁",
            "features": [],
            "templates": []
        }
        
        # 从基础配置获取风格
        style = self.profile.get("data", {}).get("communication", {}).get("tone", "简洁高效")
        
        if style in self.COMMUNICATION_STYLES:
            config = self.COMMUNICATION_STYLES[style]
            comm.update(config)
        else:
            comm["style"] = style
        
        # 从素材中提取话术模板
        if self.materials:
            phrases = self.materials.get("extracted_data", {}).get("phrases", [])
            comm["templates"] = phrases[:10]
        
        # 添加口头禅
        catchphrase = self.profile.get("data", {}).get("catchphrase", "")
        if catchphrase:
            comm["catchphrase"] = catchphrase
        
        # 典型回复样本
        comm_samples = self.profile.get("data", {}).get("response_templates", "")
        if comm_samples:
            comm["sample_responses"] = [s.strip() for s in comm_samples.split(";") if s.strip()]
        
        return comm
    
    def _extract_decision(self) -> Dict[str, Any]:
        """提取决策偏好维度"""
        decision = {
            "approach": "数据驱动",
            "risk_tolerance": "中等",
            "focus_areas": [],
            "thinking_mode": "逻辑分析型"
        }
        
        # 从基础配置获取决策模式
        pattern = self.profile.get("data", {}).get("decision", {}).get("pattern", "")
        if pattern in self.DECISION_PATTERNS:
            config = self.DECISION_PATTERNS[pattern]
            decision.update(config)
        
        # 从素材中提取关键考虑因素
        if self.materials:
            cases = self.materials.get("extracted_data", {}).get("decision_cases", [])
            if cases:
                decision["case_references"] = [c.get("summary", "")[:100] for c in cases[:3]]
        
        # 添加边界处理方式
        boundary = self.profile.get("data", {}).get("boundary_cases", "")
        if boundary:
            decision["boundary_handling"] = boundary
        
        return decision
    
    def _extract_phrases(self) -> Dict[str, Any]:
        """提取常用话术维度"""
        phrases = {
            "greetings": [],
            "closures": [],
            "situation_scripts": {},
            "fixed_expressions": []
        }
        
        # 从沟通风格中获取模板
        comm = self.profile.get("data", {}).get("communication", {})
        if comm.get("templates"):
            templates = comm["templates"]
            phrases["fixed_expressions"] = templates[:10]
        
        # 从素材中提取话术
        if self.materials:
            materials_phrases = self.materials.get("extracted_data", {}).get("phrases", [])
            
            # 分类话术
            for phrase in materials_phrases:
                if any(g in phrase for g in ["你好", "您好", "早上"]):
                    phrases["greetings"].append(phrase)
                elif any(c in phrase for c in ["谢谢", "感谢", "再见", "拜拜"]):
                    phrases["closures"].append(phrase)
                else:
                    phrases["fixed_expressions"].append(phrase)
            
            # 提取场景话术
            workflows = self.materials.get("extracted_data", {}).get("workflows", [])
            phrases["situation_scripts"]["workflow"] = workflows[:5]
        
        # 添加口头禅
        catchphrase = self.profile.get("data", {}).get("catchphrase", "")
        if catchphrase:
            phrases["catchphrase"] = catchphrase
        
        return phrases
    
    def _build_profile_config(self) -> Dict[str, Any]:
        """构建完整画像配置"""
        profile_config = {
            "clone_info": {
                "name": self.profile.get("data", {}).get("basic", {}).get("name", "未命名"),
                "position": self.profile.get("data", {}).get("basic", {}).get("position", ""),
                "created_mode": self.profile.get("created_mode", "unknown"),
                "profile_version": self.profile["profile_version"],
                "built_at": self.profile["built_at"]
            },
            "dimensions": {
                "expertise": self._extract_expertise(),
                "communication": self._extract_communication(),
                "decision": self._extract_decision(),
                "phrases": self._extract_phrases()
            },
            "meta": {
                "confidence_score": 0,
                "training_completeness": 0,
                "last_updated": datetime.now().isoformat()
            }
        }
        
        # 计算置信度分数
        completeness = 0
        total_checks = 5
        
        if profile_config["clone_info"]["name"]:
            completeness += 1
        if profile_config["dimensions"]["expertise"]["skill_tree"]:
            completeness += 1
        if profile_config["dimensions"]["communication"]["features"]:
            completeness += 1
        if profile_config["dimensions"]["decision"]["approach"]:
            completeness += 1
        if profile_config["dimensions"]["phrases"]["fixed_expressions"]:
            completeness += 1
        
        profile_config["meta"]["confidence_score"] = int(completeness / total_checks * 100)
        profile_config["meta"]["training_completeness"] = completeness
        
        return profile_config
    
    def build(self) -> Dict[str, Any]:
        """构建完整画像"""
        console.print("[bold cyan]开始构建四维画像...[/bold cyan]")
        
        profile_config = self._build_profile_config()
        
        console.print("[bold green]✅ 四维画像构建完成[/bold green]")
        
        return profile_config
    
    def visualize(self, profile_config: Dict):
        """可视化输出画像"""
        console.print("\n")
        
        # 克隆体信息
        info = profile_config["clone_info"]
        console.print(Panel.fit(
            f"[bold yellow]👤 {info['name']}[/bold yellow]\n"
            f"岗位: {info['position']}\n"
            f"建模时间: {info['built_at'][:10]}",
            title="克隆体信息",
            border_style="yellow"
        ))
        
        # 四维画像树
        tree = Tree("[bold cyan]🧠 四维画像[/bold cyan]")
        
        # 专业知识
        exp = profile_config["dimensions"]["expertise"]
        exp_tree = Tree(f"📚 专业知识 [{exp['level']}]")
        exp_tree.add(f"技能: {', '.join(exp.get('skill_tree', [])[:3])}")
        exp_tree.add(f"关键词: {', '.join(exp.get('domain_keywords', [])[:5])}")
        tree.add(exp_tree)
        
        # 沟通风格
        comm = profile_config["dimensions"]["communication"]
        comm_tree = Tree(f"💬 沟通风格 [{comm['style']}]")
        comm_tree.add(f"语气: {comm['tone']}")
        comm_tree.add(f"特点: {', '.join(comm.get('features', [])[:3])}")
        tree.add(comm_tree)
        
        # 决策偏好
        dec = profile_config["dimensions"]["decision"]
        dec_tree = Tree(f"🎯 决策偏好 [{dec['approach']}]")
        dec_tree.add(f"风险承受: {dec['risk_tolerance']}")
        dec_tree.add(f"关注点: {', '.join(dec.get('focus_areas', [])[:3])}")
        tree.add(dec_tree)
        
        # 常用话术
        phr = profile_config["dimensions"]["phrases"]
        phr_tree = Tree(f"📝 常用话术")
        if phr.get("catchphrase"):
            phr_tree.add(f"口头禅: {phr['catchphrase']}")
        phr_tree.add(f"固定表达: {len(phr.get('fixed_expressions', []))}条")
        tree.add(phr_tree)
        
        console.print(tree)
        
        # 置信度
        meta = profile_config["meta"]
        console.print(f"\n[bold]📊 置信度: {meta['confidence_score']}%[/bold]")
        console.print(f"[bold]📊 训练完整度: {meta['training_completeness']}/5[/bold]")


@click.command(help="构建员工四维画像：专业知识、沟通风格、决策偏好、常用话术\n\n新手建议：先从 /创建克隆 快速模式开始")
@click.option("--input", "-i", "input_path", required=True, help="克隆体配置文件路径")
@click.option("--materials", "-m", "materials_path", default=None, help="素材采集结果目录")
@click.option("--output", "-o", default="./clone_profile_final.json", help="输出文件路径")
@click.option("--visualize", "-v", is_flag=True, help="可视化输出画像")
def main(input_path: str, materials_path: str, output: str, visualize: bool):
    """画像建模主入口"""
    console.print(Panel.fit(
        "[bold cyan]🧠 画像建模工具[/bold cyan]\n"
        "构建员工四维画像",
        border_style="cyan"
    ))
    
    try:
        # 读取输入配置
        with open(input_path, "r", encoding="utf-8") as f:
            profile = json.load(f)
        
        # 读取素材
        materials = {}
        if materials_path:
            materials_dir = Path(materials_path)
            if materials_dir.is_dir():
                for json_file in materials_dir.glob("*.json"):
                    with open(json_file, "r", encoding="utf-8") as f:
                        materials.update(json.load(f))
            elif materials_dir.suffix == ".json":
                with open(materials_path, "r", encoding="utf-8") as f:
                    materials = json.load(f)
        
        # 构建画像
        builder = ProfileBuilder(profile, materials)
        profile_config = builder.build()
        
        # 可视化
        if visualize:
            builder.visualize(profile_config)
        
        # 保存
        if Confirm.ask("\n是否保存画像配置？", default=True):
            with open(output, "w", encoding="utf-8") as f:
                json.dump(profile_config, f, ensure_ascii=False, indent=2)
            console.print(f"\n[bold green]✅ 画像已保存到: {output}[/bold green]")
        else:
            console.print("[bold yellow]画像未保存[/bold yellow]")
        
    except FileNotFoundError:
        console.print(f"[bold red]错误: 找不到文件: {input_path}[/bold red]")
    except Exception as e:
        console.print(f"[bold red]处理出错: {e}[/bold red]")


if __name__ == "__main__":
    main()
