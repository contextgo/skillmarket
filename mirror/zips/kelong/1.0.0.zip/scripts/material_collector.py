#!/usr/bin/env python3
"""
素材采集脚本 - material_collector.py

功能说明:
    从文档/聊天记录/邮件/决策案例中提取员工信息，构建结构化素材库。
    支持多种文件格式导入，自动识别和提取关键信息。

使用方法:
    # 导入单个文件
    python material_collector.py --input ./document.pdf
    
    # 导入多个文件
    python material_collector.py --input ./docs/*.txt
    
    # 指定输出目录
    python material_collector.py --input ./message.txt --output ./materials
    
    # 查看支持的文件格式
    python material_collector.py --show-formats

参数说明:
    --input: 输入文件路径或目录，支持通配符
    --output: 输出目录路径，默认 ./collected_materials
    --format: 指定文件格式类型（pdf/word/excel/txt/chat/mail）
    --show-formats: 显示支持的文件格式列表

6大安全边界:
    1. 操作边界：仅读取文件，不修改任何内容
    2. 内容边界：只提取用户主动提供的素材
    3. 知识边界：不自动访问公司系统，只处理本地文件
    4. 权限边界：只读取授权文件，不越权访问
    5. 审计边界：记录导入日志，包括文件名和处理状态
    6. 退出边界：随时可中断，已处理文件可单独删除
"""

import json
import os
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, List, Any
from collections import defaultdict

try:
    import click
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.prompt import Confirm
except ImportError:
    print("请先安装依赖: pip install --no-deps -r requirements.txt")
    sys.exit(1)

console = Console()


class MaterialCollector:
    """素材采集器"""
    
    SUPPORTED_EXTENSIONS = {
        "pdf": [".pdf"],
        "word": [".doc", ".docx"],
        "excel": [".xls", ".xlsx", ".xlsm"],
        "text": [".txt", ".md", ".json"],
        "chat": [".txt", ".json"],  # 聊天记录通常是导出的txt或json
        "mail": [".txt", ".eml", ".msg"]
    }
    
    def __init__(self, output_dir: str = "./collected_materials"):
        """初始化素材采集器
        
        Args:
            output_dir: 输出目录路径
        """
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        self.materials: Dict[str, Any] = {
            "version": "1.0.0",
            "collected_at": datetime.now().isoformat(),
            "files_processed": [],
            "extracted_data": {
                "keywords": [],
                "phrases": [],
                "workflows": [],
                "communication_patterns": [],
                "decision_cases": []
            }
        }
        
        self.processed_count = 0
        self.error_count = 0
    
    def _extract_text_from_txt(self, file_path: Path) -> str:
        """从TXT文件提取文本"""
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                return f.read()
        except UnicodeDecodeError:
            with open(file_path, "r", encoding="gbk") as f:
                return f.read()
    
    def _extract_text_from_json(self, file_path: Path) -> str:
        """从JSON文件提取文本"""
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)
            return self._flatten_json(data)
    
    def _flatten_json(self, obj, depth: int = 0) -> str:
        """将JSON展平为文本"""
        if depth > 10:  # 防止无限递归
            return str(obj)
        
        if isinstance(obj, str):
            return obj
        elif isinstance(obj, dict):
            return " ".join(self._flatten_json(v, depth + 1) for v in obj.values())
        elif isinstance(obj, list):
            return " ".join(self._flatten_json(item, depth + 1) for item in obj)
        else:
            return str(obj)
    
    def _detect_chat_format(self, content: str) -> str:
        """检测聊天记录格式"""
        # 微信格式检测
        if re.search(r'\d{4}-\d{2}-\d{2}\s+\d{1,2}:\d{2}:\d{2}', content):
            return "wechat"
        # 钉钉格式检测
        if re.search(r'^\[.*?\]\s*.*?:\s*', content, re.MULTILINE):
            return "dingtalk"
        # 邮件格式检测
        if 'Subject:' in content or 'From:' in content:
            return "email"
        # 通用格式
        return "generic"
    
    def _extract_from_wechat(self, content: str) -> List[Dict]:
        """从微信聊天记录提取信息"""
        messages = []
        pattern = r'(\d{4}-\d{2}-\d{2}\s+\d{1,2}:\d{2}:\d{2})\s*([^\n]+)\n([^\[]*)'
        
        for match in re.finditer(pattern, content):
            timestamp, sender, message = match.groups()
            messages.append({
                "timestamp": timestamp,
                "sender": sender.strip(),
                "message": message.strip()
            })
        
        return messages
    
    def _extract_from_dingtalk(self, content: str) -> List[Dict]:
        """从钉钉聊天记录提取信息"""
        messages = []
        pattern = r'\[(.*?)\]\s*(.*?):\s*(.*?)(?=\n\[|$)'
        
        for match in re.finditer(pattern, content, re.DOTALL):
            time, sender, message = match.groups()
            messages.append({
                "time": time,
                "sender": sender.strip(),
                "message": message.strip()
            })
        
        return messages
    
    def _extract_from_email(self, content: str) -> Dict:
        """从邮件提取信息"""
        info = {
            "subject": "",
            "from": "",
            "body": content
        }
        
        subject_match = re.search(r'Subject:\s*(.+?)(?:\n|$)', content)
        if subject_match:
            info["subject"] = subject_match.group(1).strip()
        
        from_match = re.search(r'From:\s*(.+?)(?:\n|$)', content)
        if from_match:
            info["from"] = from_match.group(1).strip()
        
        return info
    
    def _extract_keywords(self, text: str) -> List[str]:
        """提取关键词"""
        # 简单关键词提取（基于词频和模式）
        patterns = [
            r'[A-Z][a-z]+[A-Z]\w+',  # 技术术语模式
            r'\d+%',  # 百分比
            r'\$\d+',  # 金额
            r'项目[一二三四五六七八九十\d]+',
            r'客户\w+',
            r'产品\w+',
        ]
        
        keywords = []
        for pattern in patterns:
            keywords.extend(re.findall(pattern, text))
        
        # 去重并返回
        return list(set(keywords))[:50]
    
    def _extract_phrases(self, text: str) -> List[str]:
        """提取常用话术"""
        # 提取可能的固定话术
        phrase_patterns = [
            r'已收到',
            r'好的，收到',
            r'感谢您的',
            r'我们会尽快',
            r'请注意',
            r'根据.*规定',
            r'建议您',
            r'请确认',
            r'如有.*问题',
            r'期待您的'
        ]
        
        phrases = []
        for pattern in phrase_patterns:
            matches = re.findall(f'{pattern}[^。！？]*[。！？]?', text)
            phrases.extend([m.strip() for m in matches])
        
        return list(set(phrases))[:30]
    
    def _extract_workflows(self, text: str) -> List[str]:
        """提取工作流程"""
        workflow_patterns = [
            r'(?:首先|第一步|开始)(?:需要|要|先).*?(?:然后|接下来|之后).*?(?:最后|最终)',
            r'(?:1\.|一、|第一步).*?(?:2\.|二、|第二步)',
            r'流程：.*?完成',
        ]
        
        workflows = []
        for pattern in workflow_patterns:
            matches = re.findall(pattern, text, re.DOTALL)
            workflows.extend([m.strip()[:200] for m in matches])  # 限制长度
        
        return workflows[:10]
    
    def _extract_communication_patterns(self, messages: List[Dict]) -> Dict[str, Any]:
        """从消息中提取沟通模式"""
        patterns = {
            "total_messages": len(messages),
            "avg_length": 0,
            "response_style": "待分析",
            "greetings": [],
            "closures": [],
            "question_types": []
        }
        
        if not messages:
            return patterns
        
        total_length = sum(len(m.get("message", "")) for m in messages)
        patterns["avg_length"] = total_length // len(messages) if messages else 0
        
        # 提取问候语和结束语
        greeting_words = ["你好", "您好", "早上好", "下午好", "hi", "hello"]
        closure_words = ["谢谢", "感谢", "再见", "拜拜", "收到", "好的"]
        
        for msg in messages:
            content = msg.get("message", "")
            if any(g in content[:5] for g in greeting_words):
                patterns["greetings"].append(content[:50])
            if any(c in content[-5:] for c in closure_words):
                patterns["closures"].append(content[-50:] if len(content) > 50 else content)
            
            # 问句类型
            if "？" in content or "?" in content:
                if "怎么" in content:
                    patterns["question_types"].append("how")
                elif "什么" in content:
                    patterns["question_types"].append("what")
                elif "为什么" in content:
                    patterns["question_types"].append("why")
        
        # 判断回复风格
        if patterns["avg_length"] < 30:
            patterns["response_style"] = "简洁型"
        elif patterns["avg_length"] < 100:
            patterns["response_style"] = "适中型"
        else:
            patterns["response_style"] = "详细型"
        
        return patterns
    
    def _extract_decision_cases(self, text: str) -> List[Dict]:
        """提取决策案例"""
        cases = []
        
        # 寻找决策相关的内容
        decision_keywords = [
            "决定", "决策", "选择了", "最终方案", 
            "判断", "结论是", "采取", "处理方式"
        ]
        
        # 简单分割（实际场景需要更复杂的处理）
        sections = text.split("\n\n")
        
        for section in sections:
            if any(kw in section for kw in decision_keywords) and len(section) > 50:
                cases.append({
                    "summary": section[:100] + "..." if len(section) > 100 else section,
                    "full_text": section[:500]
                })
        
        return cases[:5]  # 最多保留5个案例
    
    def process_file(self, file_path: Path) -> Dict[str, Any]:
        """处理单个文件"""
        result = {
            "file": str(file_path),
            "status": "pending",
            "extracted": {}
        }
        
        ext = file_path.suffix.lower()
        
        try:
            if ext in [".txt", ".md"]:
                content = self._extract_text_from_txt(file_path)
            elif ext == ".json":
                content = self._extract_text_from_json(file_path)
            else:
                result["status"] = "skipped"
                result["note"] = f"暂不支持格式: {ext}"
                return result
            
            # 检测是否为聊天记录
            chat_format = self._detect_chat_format(content)
            
            if chat_format in ["wechat", "dingtalk"]:
                # 处理聊天记录
                if chat_format == "wechat":
                    messages = self._extract_from_wechat(content)
                else:
                    messages = self._extract_from_dingtalk(content)
                
                result["extracted"]["communication_patterns"] = self._extract_communication_patterns(messages)
                result["extracted"]["messages_sample"] = messages[:20]  # 保留样本
                
            elif chat_format == "email":
                # 处理邮件
                email_info = self._extract_from_email(content)
                result["extracted"]["email_info"] = email_info
                
            else:
                # 处理普通文档
                result["extracted"]["keywords"] = self._extract_keywords(content)
                result["extracted"]["phrases"] = self._extract_phrases(content)
                result["extracted"]["workflows"] = self._extract_workflows(content)
                result["extracted"]["decision_cases"] = self._extract_decision_cases(content)
            
            result["status"] = "success"
            
        except Exception as e:
            result["status"] = "error"
            result["error"] = str(e)
        
        return result
    
    def collect(self, input_path: str) -> Dict[str, Any]:
        """收集素材"""
        path = Path(input_path)
        
        if path.is_file():
            files = [path]
        elif path.is_dir():
            files = list(path.glob("*"))
        else:
            # 支持通配符
            files = list(Path(".").glob(str(path)))
        
        results = []
        
        for file_path in files:
            if file_path.is_file():
                console.print(f"处理中: {file_path.name}")
                result = self.process_file(file_path)
                results.append(result)
                
                if result["status"] == "success":
                    self.processed_count += 1
                    self._merge_extracted(result["extracted"])
                else:
                    self.error_count += 1
        
        self.materials["files_processed"] = results
        return self.materials
    
    def _merge_extracted(self, extracted: Dict):
        """合并提取的数据"""
        data = self.materials["extracted_data"]
        
        for key in ["keywords", "phrases", "workflows"]:
            if key in extracted:
                existing = set(data.get(key, []))
                data[key] = list(existing | set(extracted[key]))
        
        for key in ["communication_patterns", "decision_cases"]:
            if key in extracted:
                if key not in data:
                    data[key] = []
                data[key].append(extracted[key])
    
    def save(self) -> Path:
        """保存采集结果"""
        output_file = self.output_dir / f"materials_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        with open(output_file, "w", encoding="utf-8") as f:
            json.dump(self.materials, f, ensure_ascii=False, indent=2)
        
        return output_file
    
    def display_summary(self):
        """显示采集摘要"""
        table = Table(title="📊 素材采集摘要", show_header=True)
        table.add_column("指标", style="cyan", width=20)
        table.add_column("数值", style="green")
        
        data = self.materials["extracted_data"]
        
        table.add_row("处理文件数", str(len(self.materials["files_processed"])))
        table.add_row("成功处理", str(self.processed_count))
        table.add_row("处理失败", str(self.error_count))
        table.add_row("提取关键词", str(len(data.get("keywords", []))))
        table.add_row("提取话术", str(len(data.get("phrases", []))))
        table.add_row("提取流程", str(len(data.get("workflows", []))))
        
        console.print(table)


def show_formats():
    """显示支持的文件格式"""
    console.print(Panel.fit(
        "[bold cyan]支持的文件格式[/bold cyan]\n\n"
        "📄 文档类:\n"
        "  - PDF: .pdf\n"
        "  - Word: .doc, .docx\n"
        "  - Excel: .xls, .xlsx, .xlsm\n"
        "  - 文本: .txt, .md\n\n"
        "💬 聊天记录类:\n"
        "  - 微信导出: .txt (时间戳格式)\n"
        "  - 钉钉导出: .txt 或 .json\n"
        "  - 邮件导出: .txt, .eml, .json\n\n"
        "💡 提示: 上传前请确保文件已脱敏，移除敏感个人信息",
        border_style="cyan"
    ))


def show_minimum_checklist():
    """显示最低素材清单"""
    console.print(Panel.fit(
        "[bold green]📋 最低素材清单[/bold green]\n\n"
        "【最低要求】只需以下任意一种即可开始：\n"
        "  ✅ 1. 一份工作文档（.txt/.doc/.pdf 均可）\n"
        "  ✅ 2. 一段聊天记录导出（.txt）\n"
        "  ✅ 3. 几个工作邮件的正文内容（.txt）\n\n"
        "【推荐配置】提升还原度需要：\n"
        "  💎 工作职责文档 + 典型对话记录\n"
        "  💎 决策案例 + 回复话术样本\n\n"
        "【快速开始】没有任何素材？\n"
        "  直接运行 python clone_creator.py\n"
        "  只需回答5个问题，5分钟即可生成基础克隆体\n\n"
        "【注意事项】\n"
        "  ⚠️ 所有素材请先脱敏处理\n"
        "  ⚠️ 移除客户姓名、手机号、地址等个人信息",
        border_style="green"
    ))


@click.command(help="从文档/聊天记录/邮件中采集员工信息素材\n\n新手建议：先从 /创建克隆 快速模式开始")
@click.option("--input", "-i", "input_path", required=True, help="输入文件或目录路径")
@click.option("--output", "-o", default="./collected_materials", help="输出目录路径")
@click.option("--format", "-f", "file_format", type=click.Choice(["pdf", "word", "excel", "txt", "chat", "mail", "all"]),
              default="all", help="指定文件格式类型")
@click.option("--show-formats", is_flag=True, help="显示支持的文件格式")
@click.option("--min-check", is_flag=True, help="显示最低素材清单要求")
def main(input_path: str, output: str, file_format: str, show_formats: bool, min_check: bool):
    """素材采集主入口"""
    if show_formats:
        show_formats()
        return
    
    if min_check:
        show_minimum_checklist()
        return
    
    console.print(Panel.fit(
        "[bold cyan]📥 素材采集工具[/bold cyan]\n"
        f"输入: {input_path}\n"
        f"输出: {output}",
        border_style="cyan"
    ))
    
    collector = MaterialCollector(output_dir=output)
    
    try:
        result = collector.collect(input_path)
        collector.display_summary()
        
        if Confirm.ask("\n是否保存采集结果？", default=True):
            output_file = collector.save()
            console.print(f"\n[bold green]✅ 素材已保存到: {output_file}[/bold green]")
            console.print(f"可通过 profile_builder.py 使用这些素材构建画像")
        else:
            console.print("[bold yellow]素材未保存[/bold yellow]")
            
    except FileNotFoundError:
        console.print(f"[bold red]错误: 找不到文件或目录: {input_path}[/bold red]")
    except Exception as e:
        console.print(f"[bold red]处理出错: {e}[/bold red]")


if __name__ == "__main__":
    main()
