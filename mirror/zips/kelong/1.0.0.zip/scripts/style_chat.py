#!/usr/bin/env python3
"""
风格对话脚本 - style_chat.py

功能说明:
    以克隆体风格进行对话，回答"他会怎么说"。
    支持直接对话、模拟回复、批量回复三种模式。

使用方法:
    # 直接对话模式
    python style_chat.py --profile ./clone_profile_final.json
    
    # 模拟回复模式（给定场景）
    python style_chat.py --profile ./clone_profile_final.json --simulate "客户询问产品报价"
    
    # 批量回复模式
    python style_chat.py --profile ./clone_profile_final.json --batch ./messages.txt
    
    # 交互式对话
    python style_chat.py --profile ./clone_profile_final.json --interactive

参数说明:
    --profile: 克隆体画像配置文件路径（必需）
    --simulate: 模拟场景，生成该场景下的回复
    --batch: 批量处理文件路径
    --interactive: 交互式对话模式
    --output: 输出文件路径（批量模式）

6大安全边界:
    1. 操作边界：仅生成回复文字，不执行任何操作
    2. 内容边界：只生成建议，不承诺任何事项
    3. 知识边界：只使用画像中的授权信息
    4. 权限边界：回复权限不越权
    5. 审计边界：记录对话日志，可追溯
    6. 退出边界：随时可中断对话，可一键停用

安全声明：本脚本仅处理本地JSON配置文件，无网络请求，无动态代码执行。
"""

import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, List, Any

try:
    import click
    from rich.console import Console
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.prompt import Prompt, Confirm
except ImportError:
    print("请先安装依赖: pip install --no-deps -r requirements.txt")
    sys.exit(1)

console = Console()


class StyleChat:
    """风格对话引擎"""
    
    def __init__(self, profile_path: str):
        """初始化风格对话引擎
        
        Args:
            profile_path: 克隆体画像配置文件路径
        """
        self.profile = self._load_profile(profile_path)
        self.conversation_history: List[Dict] = []
        self.clone_name = self.profile.get("clone_info", {}).get("name", "克隆体")
        self.clone_position = self.profile.get("clone_info", {}).get("position", "")
        
        # 提取风格配置
        self.comm = self.profile.get("dimensions", {}).get("communication", {})
        self.phrases = self.profile.get("dimensions", {}).get("phrases", {})
        self.expertise = self.profile.get("dimensions", {}).get("expertise", {})
    
    def _load_profile(self, path: str) -> Dict:
        """加载画像配置"""
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    
    def _get_style_config(self) -> Dict[str, Any]:
        """获取风格配置"""
        style = self.comm.get("style", "简洁高效")
        
        style_configs = {
            "正式严谨": {
                "prefix": "尊敬的用户，",
                "suffix": "如有疑问，请随时联系。",
                "use_polite": True,
                "sentence_pattern": "长句优先，逻辑清晰"
            },
            "亲切友好": {
                "prefix": "你好呀！",
                "suffix": "有什么问题随时问我哦～",
                "use_polite": True,
                "sentence_pattern": "长短结合，语气温暖"
            },
            "简洁高效": {
                "prefix": "",
                "suffix": "有问题再说。",
                "use_polite": False,
                "sentence_pattern": "短句为主，直奔主题"
            },
            "详细耐心": {
                "prefix": "好的，让我来详细说明：",
                "suffix": "还有其他需要解释的地方吗？",
                "use_polite": True,
                "sentence_pattern": "长句为主，充分解释"
            }
        }
        
        return style_configs.get(style, style_configs["简洁高效"])
    
    def _apply_style(self, base_response: str) -> str:
        """应用风格配置"""
        config = self._get_style_config()
        
        # 添加前缀
        if config["prefix"] and not base_response.startswith(config["prefix"]):
            base_response = config["prefix"] + base_response
        
        # 添加后缀（如果内容较长且没有结束语）
        if config["suffix"] and len(base_response) > 50:
            if not any(base_response.rstrip().endswith(end) for end in ["。", "！", "？", "～"]):
                base_response = base_response.rstrip() + config["suffix"]
        
        return base_response
    
    def _get_catchphrase(self) -> Optional[str]:
        """获取口头禅"""
        catchphrase = self.phrases.get("catchphrase", "")
        if catchphrase:
            return f"（{catchphrase}）"
        return None
    
    def _generate_response(self, message: str, context: Optional[str] = None) -> str:
        """生成回复"""
        # 基础回复生成（实际场景会调用AI模型）
        # 这里用模板模拟
        style = self.comm.get("style", "简洁高效")
        
        # 分析消息类型
        is_question = "?" in message or "？" in message
        is_greeting = any(g in message for g in ["你好", "您好", "hi", "hello", "在吗"])
        is_complaint = any(c in message for c in ["投诉", "不满", "问题", "糟糕"])
        
        responses = []
        
        # 生成回复
        if is_greeting:
            if style == "亲切友好":
                responses.append("你好！很高兴见到你，有什么我可以帮忙的吗？")
            elif style == "正式严谨":
                responses.append("您好，请问有什么可以帮到您？")
            else:
                responses.append("你好，请说。")
        elif is_complaint:
            if style == "亲切友好":
                responses.append("非常抱歉给您带来不好的体验，我理解您的心情。让我来帮您解决这个问题。")
            elif style == "正式严谨":
                responses.append("感谢您的反馈，我们会认真对待并尽快处理您的问题。")
            else:
                responses.append("收到，我来处理。")
        elif is_question:
            # 模拟问答
            if "报价" in message or "价格" in message:
                responses.append("关于价格方面，我们需要根据具体需求来定制方案。建议您告诉我更详细的使用场景，我可以给您更准确的参考。")
            elif "怎么" in message or "如何" in message:
                responses.append("这个问题我来帮你分析一下。首先，我们需要了解几个关键信息，然后我会给出具体的建议。")
            else:
                responses.append("这是一个很好的问题。根据我的经验，建议您从以下几个方面考虑...")
        else:
            # 一般性回复
            responses.append("好的，我明白了。关于这件事，我的建议是...")
        
        base_response = responses[0] if responses else "收到，我会认真处理的。"
        
        # 应用风格
        styled_response = self._apply_style(base_response)
        
        # 添加口头禅
        catchphrase = self._get_catchphrase()
        if catchphrase and style == "亲切友好":
            styled_response = styled_response + " " + catchphrase
        
        # 标记为克隆体回复
        return f"[克隆体回复] {styled_response}"
    
    def chat(self, message: str, context: Optional[str] = None) -> str:
        """对话"""
        # 记录对话
        self.conversation_history.append({
            "role": "user",
            "content": message,
            "timestamp": datetime.now().isoformat()
        })
        
        # 生成回复
        response = self._generate_response(message, context)
        
        # 记录回复
        self.conversation_history.append({
            "role": "assistant",
            "content": response,
            "timestamp": datetime.now().isoformat(),
            "clone": self.clone_name
        })
        
        return response
    
    def simulate(self, scenario: str) -> str:
        """模拟场景回复"""
        console.print(f"\n[bold yellow]📋 场景:[/bold yellow] {scenario}")
        console.print(f"[bold cyan]👤 {self.clone_name} 的回复:[/bold cyan]")
        
        response = self._generate_response(scenario, context="模拟场景")
        
        console.print(Panel.fit(response, border_style="green"))
        
        return response
    
    def batch_process(self, messages_file: str, output_file: Optional[str] = None) -> List[Dict]:
        """批量处理消息"""
        # 读取消息
        with open(messages_file, "r", encoding="utf-8") as f:
            lines = f.readlines()
        
        results = []
        
        console.print(f"\n[bold cyan]开始批量处理 {len(lines)} 条消息...[/bold cyan]\n")
        
        for i, line in enumerate(lines, 1):
            message = line.strip()
            if not message:
                continue
            
            console.print(f"[{i}] 输入: {message[:50]}...")
            response = self.chat(message)
            console.print(f"    回复: {response[:80]}...")
            
            results.append({
                "input": message,
                "output": response,
                "status": "success"
            })
        
        # 保存结果
        if output_file:
            with open(output_file, "w", encoding="utf-8") as f:
                json.dump(results, f, ensure_ascii=False, indent=2)
            console.print(f"\n[bold green]✅ 结果已保存到: {output_file}[/bold green]")
        
        return results
    
    def interactive(self):
        """交互式对话"""
        console.print(Panel.fit(
            f"[bold cyan]💬 交互式对话[/bold cyan]\n"
            f"克隆体: {self.clone_name} ({self.clone_position})\n"
            f"输入消息开始对话，输入 'quit' 退出",
            border_style="cyan"
        ))
        
        while True:
            console.print()
            message = Prompt.ask("[bold green]你[/bold green]")
            
            if message.lower() in ["quit", "exit", "退出", "q"]:
                console.print("[bold yellow]对话结束[/bold yellow]")
                break
            
            response = self.chat(message)
            console.print(f"[bold magenta]{self.clone_name}[/bold magenta]: {response}")
    
    def get_conversation_history(self) -> List[Dict]:
        """获取对话历史"""
        return self.conversation_history


@click.command(help="以克隆体风格进行对话，回答'他会怎么说'\n\n新手建议：先从 /创建克隆 快速模式开始")
@click.option("--profile", "-p", required=True, help="克隆体画像配置文件路径")
@click.option("--simulate", "-s", default=None, help="模拟场景，生成该场景下的回复")
@click.option("--batch", "-b", default=None, help="批量处理文件路径")
@click.option("--interactive", "-i", is_flag=True, help="交互式对话模式")
@click.option("--output", "-o", default=None, help="输出文件路径")
def main(profile: str, simulate: str, batch: str, interactive: bool, output: str):
    """风格对话主入口"""
    try:
        chat_engine = StyleChat(profile)
        
        if simulate:
            # 模拟场景模式
            chat_engine.simulate(simulate)
        
        elif batch:
            # 批量处理模式
            chat_engine.batch_process(batch, output)
        
        elif interactive:
            # 交互式对话模式
            chat_engine.interactive()
        
        else:
            # 默认显示帮助信息
            console.print(Panel.fit(
                "[bold cyan]💬 风格对话工具[/bold cyan]\n\n"
                "请选择运行模式：\n"
                "  --simulate    模拟场景回复\n"
                "  --batch       批量处理消息\n"
                "  --interactive 交互式对话",
                border_style="cyan"
            ))
    
    except FileNotFoundError:
        console.print(f"[bold red]错误: 找不到文件: {profile}[/bold red]")
    except Exception as e:
        console.print(f"[bold red]处理出错: {e}[/bold red]")


if __name__ == "__main__":
    main()
