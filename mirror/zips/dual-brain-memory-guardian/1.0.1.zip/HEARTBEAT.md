﻿## Dual-Brain Memory Guardian Check

- Read `./heartbeat-rules.md`
- Use `~/dual-brain-memory-guardian/heartbeat-state.md` for run markers and digest notes
- If no local changes and no promotable DEEP digest signal, return `HEARTBEAT_OK`
