---
name: production-scheduler
description: 生产调度排程与甘特图可视化工具。用于处理制造业工单排程场景：从CSV导入工单数据，支持FCFS先到先做和蚁群算法ACO负载均衡两种排程算法，支持工作时间日历配置（两班倒、三班倒、白班、节假日），生成可视化HTML甘特图展示各机器负荷和工序负荷。触发关键词：生产调度、排程、甘特图、工单排程、机器负荷、生产计划、工作时间、日历、蚁群算法、负载均衡。
---

# 生产调度排程器

生产调度排程与可视化工具，支持CSV工单导入、**双算法排程**、**工作时间日历**、HTML甘特图生成。

## 使用流程

1. **准备工单CSV**
2. **选择排程算法**
3. **配置工作时间日历（可选）**
4. **运行排程脚本**
5. **查看HTML甘特图**

---

## 1. 准备工单数据

### CSV格式

| 字段 | 说明 | 示例 |
|------|------|------|
| `order_id` | 工单编号 | WO-001 |
| `product` | 产品名称 | 零件A |
| `quantity` | 数量 | 5 |
| `arrival_time` | 到达时间(YYYY-MM-DD HH:MM) | 2026-04-18 08:00 |
| `due_date` | 交付日期(YYYY-MM-DD) | 2026-04-20 |
| `priority` | 优先级(数字越小越高) | 1 |

### 示例CSV
```csv
order_id,product,quantity,arrival_time,due_date,priority
WO-001,零件A,5,2026-04-18 08:00,2026-04-20,1
WO-002,零件B,3,2026-04-18 09:00,2026-04-21,2
```

---

## 2. 排程算法

### FCFS (先到先做)
按工单到达时间排序，适合简单场景。

### 蚁群算法 (ACO - 负载均衡)
模拟蚂蚁觅食行为，迭代优化，目标是最小化各机器负荷差异。

### 贪婪算法 (Greedy - 负载均衡)
每次选当前负荷最小的机器，简单高效。

---

## 3. 命令行执行

```bash
cd /root/.openclaw/workspace/skills/production-scheduler

# === 算法选择 ===

# FCFS 先到先做（默认）
python scripts/gantt_generator.py orders.csv output.html --algo fcfs

# 贪婪算法（负载均衡）
python scripts/gantt_generator.py orders.csv output.html --algo greedy

# 蚁群算法（负载均衡优化）
python scripts/gantt_generator.py orders.csv output.html --algo aco

# === 工作班次 ===

# 24小时连续生产（默认）
python scripts/gantt_generator.py orders.csv output.html --shift 24h

# 两班倒（白班8-17 + 夜班18-02）
python scripts/gantt_generator.py orders.csv output.html --shift 2shift

# 白班（8:00-17:00，周一至周五）
python scripts/gantt_generator.py orders.csv output.html --shift day

# 三班倒（全天24小时）
python scripts/gantt_generator.py orders.csv output.html --shift 3shift

# === 组合使用 ===

# 蚁群算法 + 两班倒（推荐生产场景）
python scripts/gantt_generator.py orders.csv output.html --algo aco --shift 2shift

# 贪婪 + 自定义工作日（含周六）
python scripts/gantt_generator.py orders.csv output.html --algo greedy --shift day --work-days 0 1 2 3 4 5

# === 仿真可视化 ===

# 生成仿真动画页面（加 --sim 参数）
python scripts/gantt_generator.py orders.csv output.html --shift 2shift --sim
```

**参数说明：**

| 参数 | 选项 | 说明 |
|------|------|------|
| `--algo` | fcfs / greedy / aco | 排程算法 |
| `--shift` | 24h / day / 2shift / 3shift | 工作班次 |
| `--work-days` | 0-6（空格分隔） | 自定义工作日，0=周一，6=周日 |
| `--sim` | 无参数 | 同时生成仿真可视化页面 |

## 4. 机器级维护窗口（可选）

每台机器可以配置独立的维护窗口，排程时自动跳过：

```python
from work_calendar import create_two_shift_calendar, add_maintenance
from datetime import datetime

cal = create_two_shift_calendar()

# 车床1 4/18 9:00-12:00 设备维修
add_maintenance(cal, 'M3',
    datetime(2026, 4, 18, 9, 0),
    datetime(2026, 4, 18, 12, 0),
    '设备维修')

# 喷涂线 4/19 全天换线保养
add_maintenance(cal, 'M7',
    datetime(2026, 4, 19, 8, 0),
    datetime(2026, 4, 20, 2, 0),  # 跨天
    '换线保养')

# 调用排程（传入带维护的日历）
data = gantt_generator.jobs_to_json(scheduler, 'orders.csv', cal, 'fcfs')
```

## 5. Python调用

```python
import sys
sys.path.insert(0, '/root/.openclaw/workspace/skills/production-scheduler/scripts')
import scheduler, gantt_generator
from work_calendar import create_two_shift_calendar, add_maintenance
from aco_scheduler import schedule_aco, ACOConfig
from datetime import datetime

calendar = create_two_shift_calendar()

# 可选：加维护窗口
add_maintenance(calendar, 'M3',
    datetime(2026, 4, 18, 9, 0),
    datetime(2026, 4, 18, 12, 0), '设备维修')

# 排程
data = gantt_generator.jobs_to_json(scheduler, 'orders.csv', calendar, 'aco')
gantt_generator.generate_gantt_html(data, 'gantt.html')
```

---

## 6. 工序与机器配置

| 工序ID | 工序名称 | 可用机器 | 单件加工时间 |
|--------|----------|----------|--------------|
| P1 | 下料 | M1, M2 | 10分钟 |
| P2 | 机加工 | M3, M4 | 30分钟 |
| P3 | 焊接 | M5, M6 | 20分钟 |
| P4 | 表面处理 | M7 | 15分钟 |
| P5 | 质检 | M8, M9 | 10分钟 |

修改 `scripts/scheduler.py` 中的 `DEFAULT_PROCESSES` 和 `DEFAULT_MACHINES`。

---

## 7. 蚁群算法参数调优

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `n_ants` | 20 | 蚂蚁数量 |
| `n_iterations` | 50 | 迭代次数 |
| `alpha` | 1.0 | 信息素权重 |
| `beta` | 2.0 | 启发信息权重 |

---

## 8. 生产仿真可视化

加 `--sim` 参数可生成交互式仿真动画页面：

```bash
python scripts/gantt_generator.py orders.csv output.html --shift 2shift --sim
```

仿真页面包含：
- 🏭 **车间平面图** — 5个工位、9台机器的布局
- 📦 **工件流转动画** — 实时显示工件在各工序间的移动
- 📊 **实时统计面板** — 已完成、在制品、待加工数量
- 🔧 **设备状态监控** — 每台机器的实时状态（空闲/加工中）
- ⏯️ **播放控制** — 开始/暂停/重置，支持 1x/10x/50x/100x 倍速

```
simulator.html
├── 顶部统计栏: 已完成 | 在制品 | 待加工 | 设备利用率
├── 左侧车间视图: Canvas 动画展示
│   ├── 工位区域（下料→机加工→焊接→表面处理→质检）
│   ├── 机器图标（显示加工状态）
│   └── 工件动画（加工中黄色闪烁，流转中移动）
└── 右侧面板:
    ├── 播放控制（倍速按钮）
    ├── 事件日志（实时加工记录）
    └── 设备状态网格
```

## 9. 模块结构

```
scripts/
├── scheduler.py          # FCFS算法 + 数据模型
├── work_calendar.py      # 工作时间日历
├── aco_scheduler.py      # 蚁群算法 + 贪婪算法
├── gantt_generator.py    # 甘特图HTML生成 + 命令行入口
└── factory_simulator.py  # 仿真可视化页面生成
```
