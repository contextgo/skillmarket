#!/usr/bin/env python3
"""
生产调度排程器 - FCFS (先到先服务)
"""

import csv
from dataclasses import dataclass
from typing import List, Dict
from datetime import datetime, timedelta

from work_calendar import (
    WorkCalendar, WorkShift,
    create_standard_calendar,
    calculate_work_end,
    get_next_available_time
)


@dataclass
class WorkOrder:
    """工单"""
    order_id: str           # 工单号
    product: str            # 产品名称
    quantity: int           # 数量
    arrival_time: str       # 到达时间 (YYYY-MM-DD HH:MM)
    due_date: str           # 交付日期 (YYYY-MM-DD)
    priority: int = 0       # 优先级 (数字越小越高)


@dataclass
class ProcessStep:
    """工序"""
    step_id: str            # 工序ID
    step_name: str          # 工序名称
    machine_ids: List[str]  # 可用机器列表
    processing_time: int    # 单件加工时间(分钟)


@dataclass
class Machine:
    """机器"""
    machine_id: str
    machine_name: str
    current_job_end: datetime = None


@dataclass
class ScheduledJob:
    """已排程的作业"""
    order_id: str
    product: str
    quantity: int
    step_id: str
    step_name: str
    machine_id: str
    machine_name: str
    start_time: datetime
    end_time: datetime


# 默认工序和机器配置（可扩展）
DEFAULT_PROCESSES = [
    ProcessStep("P1", "下料", ["M1", "M2"], 10),
    ProcessStep("P2", "机加工", ["M3", "M4"], 30),
    ProcessStep("P3", "焊接", ["M5", "M6"], 20),
    ProcessStep("P4", "表面处理", ["M7"], 15),
    ProcessStep("P5", "质检", ["M8", "M9"], 10),
]

DEFAULT_MACHINES = {
    "M1": "下料机1",
    "M2": "下料机2",
    "M3": "车床1",
    "M4": "车床2",
    "M5": "焊接机1",
    "M6": "焊接机2",
    "M7": "喷涂线",
    "M8": "质检台1",
    "M9": "质检台2",
}


def parse_orders_from_csv(csv_path: str) -> List[WorkOrder]:
    """从CSV文件解析工单"""
    orders = []
    with open(csv_path, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            order = WorkOrder(
                order_id=row['order_id'],
                product=row['product'],
                quantity=int(row['quantity']),
                arrival_time=row['arrival_time'],
                due_date=row['due_date'],
                priority=int(row.get('priority', 0))
            )
            orders.append(order)
    # 按到达时间排序 (FCFS)
    orders.sort(key=lambda x: x.arrival_time)
    return orders


def load_custom_config(config_path: str = None) -> tuple:
    """加载自定义配置（可选）"""
    processes = DEFAULT_PROCESSES
    machines = DEFAULT_MACHINES
    
    if config_path:
        import json
        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)
            # TODO: 解析自定义配置
            pass
    
    return processes, machines


def schedule_fcfs(orders: List[WorkOrder], 
                  processes: List[ProcessStep], 
                  machines: Dict[str, str],
                  calendar: WorkCalendar = None) -> List[ScheduledJob]:
    """FCFS 排程算法（支持工作时间日历 + 机器级维护窗口）"""
    
    if calendar is None:
        from work_calendar import create_standard_calendar
        calendar = create_standard_calendar(work_start=0, work_end=23, work_days=list(range(7)))
    
    scheduled_jobs = []
    machine_status = {m: None for m in machines.keys()}
    
    for order in orders:
        arrival = datetime.strptime(order.arrival_time, "%Y-%m-%d %H:%M")
        
        for process in processes:
            # 找到最早可用的机器（考虑每台机器的工作时间和维护窗口）
            earliest_start = None
            selected_machine = process.machine_ids[0]
            
            for machine_id in process.machine_ids:
                machine_time = machine_status[machine_id]
                if machine_time is None:
                    machine_time = arrival
                
                # 调整到该机器的下一个可用时间
                candidate = get_next_available_time(calendar, machine_time, machine_id)
                if candidate < arrival:
                    candidate = get_next_available_time(calendar, arrival, machine_id)
                
                if earliest_start is None or candidate < earliest_start:
                    earliest_start = candidate
                    selected_machine = machine_id
            
            # 计算结束时间（传入machine_id，考虑该机器的维护窗口）
            total_time = process.processing_time * order.quantity
            end_time = calculate_work_end(calendar, earliest_start, total_time, selected_machine)
            
            job = ScheduledJob(
                order_id=order.order_id,
                product=order.product,
                quantity=order.quantity,
                step_id=process.step_id,
                step_name=process.step_name,
                machine_id=selected_machine,
                machine_name=machines[selected_machine],
                start_time=earliest_start,
                end_time=end_time
            )
            scheduled_jobs.append(job)
            
            machine_status[selected_machine] = end_time
            arrival = end_time
    
    return scheduled_jobs


def get_machine_loads(scheduled_jobs: List[ScheduledJob]) -> Dict[str, dict]:
    """计算各机器负荷"""
    loads = {}
    for job in scheduled_jobs:
        if job.machine_id not in loads:
            loads[job.machine_id] = {
                'machine_name': job.machine_name,
                'total_minutes': 0,
                'job_count': 0,
                'orders': []
            }
        duration = (job.end_time - job.start_time).total_seconds() / 60
        loads[job.machine_id]['total_minutes'] += duration
        loads[job.machine_id]['job_count'] += 1
        loads[job.machine_id]['orders'].append(job.order_id)
    return loads


def get_personnel_loads(scheduled_jobs: List[ScheduledJob]) -> Dict[str, dict]:
    """计算人员负荷（按工序）"""
    loads = {}
    for job in scheduled_jobs:
        if job.step_id not in loads:
            loads[job.step_id] = {
                'step_name': job.step_name,
                'total_minutes': 0,
                'job_count': 0,
                'orders': []
            }
        duration = (job.end_time - job.start_time).total_seconds() / 60
        loads[job.step_id]['total_minutes'] += duration
        loads[job.step_id]['job_count'] += 1
        loads[job.step_id]['orders'].append(job.order_id)
    return loads


if __name__ == "__main__":
    # 测试
    print("生产调度模块加载成功")
