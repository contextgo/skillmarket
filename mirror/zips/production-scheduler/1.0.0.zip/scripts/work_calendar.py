#!/usr/bin/env python3
"""
工作时间日历模块 - 管理机器的工作时间、休息日、节假日、维护窗口
支持全局日历 + 单机器级别的覆盖
"""

from datetime import datetime, timedelta, time, date
from typing import List, Tuple, Optional, Dict
from dataclasses import dataclass, field


@dataclass
class WorkShift:
    """工作班次"""
    name: str           # 班次名称，如"白班"、"夜班"
    start: time         # 开始时间，如 time(8, 0)
    end: time           # 结束时间，如 time(17, 0)


@dataclass
class MaintenanceWindow:
    """维护/不可用窗口"""
    machine_id: str             # 机器ID（留空表示全局）
    start: datetime             # 开始时间
    end: datetime               # 结束时间
    reason: str = ""            # 原因，如"设备维修"、"保养"

    def overlaps(self, other_start: datetime, other_end: datetime) -> bool:
        """检查是否与给定时间段重叠"""
        return self.start < other_end and self.end > other_start

    def contains(self, dt: datetime) -> bool:
        """检查是否包含某个时间点"""
        return self.start <= dt < self.end


@dataclass
class MachineSchedule:
    """单台机器的时间安排"""
    machine_id: str
    shifts: Optional[List[WorkShift]] = None    # 该机器的班次（None=使用全局）
    work_days: Optional[List[int]] = None       # 该机器的工作日（None=使用全局）
    maintenance: List[MaintenanceWindow] = field(default_factory=list)  # 维护窗口
    available_overrides: List[MaintenanceWindow] = field(default_factory=list)  # 额外可用时间


@dataclass 
class WorkCalendar:
    """工作日历配置"""
    shifts: List[WorkShift] = field(default_factory=list)
    work_days: List[int] = field(default_factory=lambda: [0, 1, 2, 3, 4])
    holidays: List[str] = field(default_factory=list)
    maintenance: List[MaintenanceWindow] = field(default_factory=list)  # 全局维护
    machine_schedules: Dict[str, MachineSchedule] = field(default_factory=dict)
    
    def __post_init__(self):
        if not self.shifts:
            self.shifts = [WorkShift("白班", time(8, 0), time(17, 0))]
        self._holiday_dates = set()
        for h in self.holidays:
            try:
                self._holiday_dates.add(datetime.strptime(h, "%Y-%m-%d").date())
            except:
                pass

    def get_shifts_for_machine(self, machine_id: str) -> List[WorkShift]:
        """获取某台机器的班次安排"""
        if machine_id in self.machine_schedules:
            ms = self.machine_schedules[machine_id]
            if ms.shifts is not None:
                return ms.shifts
        return self.shifts

    def get_work_days_for_machine(self, machine_id: str) -> List[int]:
        """获取某台机器的工作日"""
        if machine_id in self.machine_schedules:
            ms = self.machine_schedules[machine_id]
            if ms.work_days is not None:
                return ms.work_days
        return self.work_days

    def get_maintenance_for_machine(self, machine_id: str) -> List[MaintenanceWindow]:
        """获取某台机器的维护窗口（全局 + 机器级别）"""
        windows = list(self.maintenance)  # 全局维护
        if machine_id in self.machine_schedules:
            windows.extend(self.machine_schedules[machine_id].maintenance)
        return windows


# ========================
# 判断函数（带机器级别支持）
# ========================

def is_work_day(calendar: WorkCalendar, dt: datetime, machine_id: str = None) -> bool:
    """判断某天是否是工作日"""
    d = dt.date()
    if d in calendar._holiday_dates:
        return False
    work_days = calendar.get_work_days_for_machine(machine_id) if machine_id else calendar.work_days
    return d.weekday() in work_days


def is_in_maintenance(calendar: WorkCalendar, dt: datetime, machine_id: str = None) -> bool:
    """检查某个时间点是否在维护窗口内"""
    # 检查全局维护
    for mw in calendar.maintenance:
        if mw.contains(dt):
            return True
    # 检查机器级别维护
    if machine_id:
        for mw in calendar.get_maintenance_for_machine(machine_id):
            if mw.contains(dt):
                return True
    return False


def is_available(calendar: WorkCalendar, dt: datetime, machine_id: str = None) -> bool:
    """检查某个时间点机器是否可用"""
    if not is_work_day(calendar, dt, machine_id):
        return False
    if is_in_maintenance(calendar, dt, machine_id):
        return False
    # 检查是否在班次内
    shifts = calendar.get_shifts_for_machine(machine_id) if machine_id else calendar.shifts
    current_time = dt.time()
    for shift in shifts:
        if shift.end < shift.start:  # 夜班跨天
            if current_time >= shift.start or current_time < shift.end:
                return True
        else:
            if shift.start <= current_time < shift.end:
                return True
    return False


def get_next_available_time(calendar: WorkCalendar, dt: datetime, 
                            machine_id: str = None, ignore_shifts: bool = False) -> datetime:
    """
    获取某台机器下一个可用时间
    跳过非工作日、维护窗口、班次外时间
    """
    max_iterations = 400
    for _ in range(max_iterations):
        shifts = calendar.get_shifts_for_machine(machine_id) if machine_id else calendar.shifts
        
        # 检查是否是工作日
        if not is_work_day(calendar, dt, machine_id):
            next_date = dt.date() + timedelta(days=1)
            dt = datetime.combine(next_date, shifts[0].start)
            continue

        current_time = dt.time()
        current_date = dt.date()
        
        # 先检查维护
        if is_in_maintenance(calendar, dt, machine_id):
            dt = _get_maintenance_end(calendar, dt, machine_id)
            continue

        # 检查是否在班次内
        for shift in shifts:
            if shift.end < shift.start:  # 夜班跨天
                if current_time >= shift.start or current_time < shift.end:
                    return dt
            else:
                if shift.start <= current_time < shift.end:
                    return dt

        # 不在班次内，找下一个班次
        found_next = False
        for shift in shifts:
            if shift.end < shift.start:  # 夜班
                if current_time < shift.end:
                    # 凌晨跨天时段
                    if not is_in_maintenance(calendar, dt, machine_id):
                        return dt
            else:
                if current_time < shift.start:
                    candidate = datetime.combine(current_date, shift.start)
                    if is_in_maintenance(calendar, candidate, machine_id):
                        dt = _get_maintenance_end(calendar, candidate, machine_id)
                        found_next = True
                        break
                    dt = candidate
                    found_next = True
                    break
        
        if not found_next:
            # 所有班次都过了，跳到下一天
            next_date = current_date + timedelta(days=1)
            dt = datetime.combine(next_date, shifts[0].start)

    raise RuntimeError("无法找到可用时间，请检查日历配置")


def _get_maintenance_end(calendar: WorkCalendar, dt: datetime, 
                         machine_id: str = None) -> datetime:
    """获取包含dt的维护窗口的结束时间"""
    for mw in calendar.get_maintenance_for_machine(machine_id):
        if mw.contains(dt):
            return mw.end
    return dt + timedelta(minutes=30)


def calculate_work_end(calendar: WorkCalendar, start: datetime, 
                       duration_minutes: int, machine_id: str = None) -> datetime:
    """
    根据开始时间和工作时长，计算工作结束时间
    考虑工作时间、维护窗口
    """
    if duration_minutes <= 0:
        return start

    current = start
    remaining = duration_minutes
    max_iterations = 2000

    for _ in range(max_iterations):
        if remaining <= 0:
            return current

        # 确保当前时间是可用的
        current = get_next_available_time(calendar, current, machine_id)

        shifts = calendar.get_shifts_for_machine(machine_id) if machine_id else calendar.shifts
        current_time = current.time()
        current_date = current.date()

        # 找到当前班次
        for shift in shifts:
            shift_end = None
            in_shift = False

            if shift.end < shift.start:  # 夜班跨天
                if current_time >= shift.start:
                    in_shift = True
                    shift_end = datetime.combine(current_date + timedelta(days=1), shift.end)
                elif current_time < shift.end:
                    in_shift = True
                    shift_end = datetime.combine(current_date, shift.end)
            else:
                if shift.start <= current_time < shift.end:
                    in_shift = True
                    shift_end = datetime.combine(current_date, shift.end)

            if in_shift and shift_end:
                # 检查当前班次内是否有维护窗口
                available_until = _get_next_maintenance_or_shift_end(
                    calendar, current, shift_end, machine_id
                )
                
                available_minutes = (available_until - current).total_seconds() / 60

                if available_minutes >= remaining:
                    return current + timedelta(minutes=remaining)

                remaining -= int(available_minutes)
                current = available_until
                break
        else:
            # 不在班次内，跳到下一个班次
            dt = datetime.combine(current_date + timedelta(days=1), shifts[0].start)
            current = dt

    raise RuntimeError("计算工作时间超出最大迭代次数")


def _get_next_maintenance_or_shift_end(calendar: WorkCalendar, start: datetime,
                                        shift_end: datetime, machine_id: str) -> datetime:
    """获取当前班次内下一个维护窗口开始时间，或班次结束时间（取较早的）"""
    next_stop = shift_end
    
    for mw in calendar.get_maintenance_for_machine(machine_id):
        if mw.start >= start and mw.start < shift_end:
            if mw.start < next_stop:
                next_stop = mw.start
    
    return next_stop


# ========================
# 预设日历工厂
# ========================

def create_standard_calendar(
    work_start: int = 8,
    work_end: int = 17,
    lunch_start: int = 12,
    lunch_end: int = 13,
    work_days: List[int] = None,
    holidays: List[str] = None
) -> WorkCalendar:
    """标准工作日历（白班）"""
    if work_days is None:
        work_days = [0, 1, 2, 3, 4]
    if holidays is None:
        holidays = []

    shift = WorkShift("白班", time(work_start, 0), time(work_end, 0))

    # 午休作为维护窗口处理
    maintenance = []
    if lunch_start and lunch_end and lunch_start != lunch_end:
        maintenance.append(MaintenanceWindow(
            machine_id="",
            start=datetime(2000, 1, 1, lunch_start, 0),
            end=datetime(2000, 1, 1, lunch_end, 0),
            reason="午休"
        ))

    return WorkCalendar(
        shifts=[shift],
        work_days=work_days,
        holidays=holidays,
        maintenance=maintenance
    )


def create_two_shift_calendar(
    day_start: int = 8,
    day_end: int = 17,
    night_start: int = 18,
    night_end: int = 2,
    work_days: List[int] = None,
    holidays: List[str] = None
) -> WorkCalendar:
    """两班倒日历"""
    if work_days is None:
        work_days = [0, 1, 2, 3, 4, 5]
    if holidays is None:
        holidays = []

    day_shift = WorkShift("白班", time(day_start, 0), time(day_end, 0))
    night_shift = WorkShift("夜班", time(night_start, 0), time(23, 59))

    return WorkCalendar(
        shifts=[day_shift, night_shift],
        work_days=work_days,
        holidays=holidays
    )


def create_three_shift_calendar(
    work_days: List[int] = None,
    holidays: List[str] = None
) -> WorkCalendar:
    """三班倒日历（24小时）"""
    if work_days is None:
        work_days = [0, 1, 2, 3, 4, 5, 6]
    if holidays is None:
        holidays = []

    shifts = [
        WorkShift("早班", time(0, 0), time(8, 0)),
        WorkShift("中班", time(8, 0), time(16, 0)),
        WorkShift("晚班", time(16, 0), time(23, 59)),
    ]

    return WorkCalendar(
        shifts=shifts,
        work_days=work_days,
        holidays=holidays
    )


# ========================
# 机器级别配置辅助
# ========================

def add_maintenance(calendar: WorkCalendar, machine_id: str, 
                    start: datetime, end: datetime, reason: str = ""):
    """给某台机器添加维护窗口"""
    if machine_id not in calendar.machine_schedules:
        calendar.machine_schedules[machine_id] = MachineSchedule(machine_id=machine_id)
    calendar.machine_schedules[machine_id].maintenance.append(
        MaintenanceWindow(machine_id=machine_id, start=start, end=end, reason=reason)
    )


def set_machine_work_days(calendar: WorkCalendar, machine_id: str, work_days: List[int]):
    """设置某台机器的工作日"""
    if machine_id not in calendar.machine_schedules:
        calendar.machine_schedules[machine_id] = MachineSchedule(machine_id=machine_id)
    calendar.machine_schedules[machine_id].work_days = work_days


def set_machine_shifts(calendar: WorkCalendar, machine_id: str, shifts: List[WorkShift]):
    """设置某台机器的班次"""
    if machine_id not in calendar.machine_schedules:
        calendar.machine_schedules[machine_id] = MachineSchedule(machine_id=machine_id)
    calendar.machine_schedules[machine_id].shifts = shifts


def print_calendar_summary(calendar: WorkCalendar):
    """打印日历摘要"""
    print("=== 全局日历 ===")
    print(f"  班次: {', '.join(f'{s.name}({s.start}-{s.end})' for s in calendar.shifts)}")
    day_names = {0:'周一', 1:'周二', 2:'周三', 3:'周四', 4:'周五', 5:'周六', 6:'周日'}
    work_day_names = [day_names[d] for d in sorted(calendar.work_days)]
    print(f"  工作日: {', '.join(work_day_names)}")
    if calendar.holidays:
        print(f"  节假日: {', '.join(calendar.holidays)}")

    if calendar.machine_schedules:
        print("\n=== 机器级别配置 ===")
        for mid, ms in calendar.machine_schedules.items():
            print(f"\n  机器: {mid}")
            if ms.shifts:
                print(f"    班次: {', '.join(f'{s.name}({s.start}-{s.end})' for s in ms.shifts)}")
            if ms.work_days:
                wd_names = [day_names[d] for d in sorted(ms.work_days)]
                print(f"    工作日: {', '.join(wd_names)}")
            if ms.maintenance:
                print(f"    维护窗口:")
                for mw in ms.maintenance:
                    print(f"      {mw.start} ~ {mw.end}  ({mw.reason})")


if __name__ == "__main__":
    print("工作时间日历模块加载成功（支持机器级别配置）")

    # 测试
    cal = create_two_shift_calendar()

    # 给车床1加维护
    add_maintenance(cal, "M3", 
                    datetime(2026, 4, 18, 9, 0),
                    datetime(2026, 4, 18, 12, 0),
                    "设备维修")

    # 给喷涂线加维护
    add_maintenance(cal, "M7",
                    datetime(2026, 4, 19, 8, 0),
                    datetime(2026, 4, 19, 17, 0),
                    "换线保养")

    print_calendar_summary(cal)

    # 测试维护期间的时间跳转
    t = get_next_available_time(cal, datetime(2026, 4, 18, 10, 0), "M3")
    print(f"\n车床1 在 4/18 10:00 的下一个可用时间: {t}")
    assert t == datetime(2026, 4, 18, 12, 0), f"Expected 12:00, got {t}"
    print("✅ 测试通过")
