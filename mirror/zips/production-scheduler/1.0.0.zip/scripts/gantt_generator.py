#!/usr/bin/env python3
"""
甘特图生成器 - 输出交互式 HTML 甘特图
"""

import sys
import os
import json
from datetime import datetime


def jobs_to_json(scheduler, csv_path: str, calendar=None, algorithm='fcfs') -> dict:
    """排程并生成JSON数据"""
    from aco_scheduler import schedule_aco, schedule_greedy
    
    orders = scheduler.parse_orders_from_csv(csv_path)
    processes, machines = scheduler.load_custom_config()
    
    if algorithm == 'aco':
        jobs, _ = schedule_aco(orders, processes, machines, calendar)
    elif algorithm == 'greedy':
        jobs = schedule_greedy(orders, processes, machines, calendar)
    else:  # fcfs
        jobs = scheduler.schedule_fcfs(orders, processes, machines, calendar)
    machine_loads = scheduler.get_machine_loads(jobs)
    personnel_loads = scheduler.get_personnel_loads(jobs)

    # 找出时间范围
    if not jobs:
        return {"error": "没有排程数据"}

    all_times = []
    for j in jobs:
        all_times.append(j.start_time)
        all_times.append(j.end_time)
    min_time = min(all_times)
    max_time = max(all_times)

    # 序列化
    jobs_data = []
    for j in jobs:
        jobs_data.append({
            "order_id": j.order_id,
            "product": j.product,
            "quantity": j.quantity,
            "step_id": j.step_id,
            "step_name": j.step_name,
            "machine_id": j.machine_id,
            "machine_name": j.machine_name,
            "start": j.start_time.strftime("%Y-%m-%d %H:%M"),
            "end": j.end_time.strftime("%Y-%m-%d %H:%M"),
            "start_ts": j.start_time.timestamp() * 1000,
            "end_ts": j.end_time.timestamp() * 1000,
        })

    machines_data = []
    for mid, info in machine_loads.items():
        hours = info['total_minutes'] / 60
        machines_data.append({
            "machine_id": mid,
            "machine_name": info['machine_name'],
            "total_hours": round(hours, 1),
            "job_count": info['job_count'],
        })

    personnel_data = []
    for sid, info in personnel_loads.items():
        hours = info['total_minutes'] / 60
        personnel_data.append({
            "step_id": sid,
            "step_name": info['step_name'],
            "total_hours": round(hours, 1),
            "job_count": info['job_count'],
        })

    return {
        "jobs": jobs_data,
        "machines": machines_data,
        "personnel": personnel_data,
        "time_range": {
            "start": min_time.strftime("%Y-%m-%d %H:%M"),
            "end": max_time.strftime("%Y-%m-%d %H:%M"),
        },
        "order_count": len(orders),
        "_jobs": jobs,  # 原始jobs数据，用于仿真
    }


HTML_TEMPLATE = r"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>生产调度甘特图</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.7/dist/chart.umd.min.js"></script>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: -apple-system, 'PingFang SC', 'Microsoft YaHei', sans-serif; background: #f0f2f5; padding: 20px; }

.header { text-align: center; margin-bottom: 20px; }
.header h1 { color: #1a1a2e; font-size: 24px; }
.header .meta { color: #666; font-size: 14px; margin-top: 4px; }

.stats { display: flex; gap: 16px; margin-bottom: 20px; flex-wrap: wrap; }
.stat-card { background: white; border-radius: 10px; padding: 16px 20px; flex: 1; min-width: 200px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
.stat-card h3 { font-size: 13px; color: #888; margin-bottom: 8px; }
.stat-card .value { font-size: 24px; font-weight: 700; color: #1a1a2e; }
.stat-card .sub { font-size: 12px; color: #999; margin-top: 4px; }

.section { background: white; border-radius: 10px; padding: 20px; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
.section h2 { font-size: 16px; color: #1a1a2e; margin-bottom: 16px; padding-bottom: 8px; border-bottom: 2px solid #f0f0f0; }

.gantt-container { overflow-x: auto; }
.gantt-chart { position: relative; }
.gantt-row { display: flex; align-items: center; border-bottom: 1px solid #f5f5f5; height: 32px; }
.gantt-label { width: 140px; min-width: 140px; font-size: 12px; color: #555; padding: 0 8px; text-align: right; }
.gantt-bar-area { flex: 1; position: relative; height: 100%; }
.gantt-bar { position: absolute; height: 22px; top: 5px; border-radius: 4px; font-size: 10px; color: white; display: flex; align-items: center; padding: 0 6px; white-space: nowrap; overflow: hidden; cursor: pointer; transition: opacity 0.2s; }
.gantt-bar:hover { opacity: 0.85; z-index: 10; }

.load-bars { display: flex; flex-direction: column; gap: 10px; }
.load-row { display: flex; align-items: center; gap: 12px; }
.load-name { width: 120px; font-size: 13px; color: #555; text-align: right; }
.load-bar-bg { flex: 1; height: 24px; background: #f0f0f0; border-radius: 4px; overflow: hidden; position: relative; }
.load-bar-fill { height: 100%; border-radius: 4px; transition: width 0.5s; }
.load-value { width: 80px; font-size: 12px; color: #666; }

.tooltip { display: none; position: fixed; background: #333; color: white; padding: 8px 12px; border-radius: 6px; font-size: 12px; z-index: 100; pointer-events: none; max-width: 300px; }

.tabs { display: flex; gap: 4px; margin-bottom: 16px; }
.tab { padding: 8px 20px; border-radius: 8px 8px 0 0; cursor: pointer; font-size: 14px; color: #666; background: #e8e8e8; border: none; }
.tab.active { background: white; color: #1a1a2e; font-weight: 600; box-shadow: 0 -2px 8px rgba(0,0,0,0.08); }

.tab-content { display: none; }
.tab-content.active { display: block; }
</style>
</head>
<body>

<div class="header">
  <h1>🏭 生产调度甘特图</h1>
  <div class="meta" id="meta"></div>
</div>

<div class="stats" id="stats"></div>

<div class="tabs">
  <button class="tab active" onclick="switchTab('gantt')">工单甘特图</button>
  <button class="tab" onclick="switchTab('machine')">机器负荷</button>
  <button class="tab" onclick="switchTab('personnel')">人员/工序负荷</button>
</div>

<div class="section">
  <div id="gantt-tab" class="tab-content active">
    <h2>工单排程甘特图</h2>
    <div class="gantt-container"><div class="gantt-chart" id="gantt-chart"></div></div>
  </div>
  <div id="machine-tab" class="tab-content">
    <h2>各机器负荷分布</h2>
    <div class="load-bars" id="machine-loads"></div>
  </div>
  <div id="personnel-tab" class="tab-content">
    <h2>各工序负荷分布</h2>
    <div class="load-bars" id="personnel-loads"></div>
  </div>
</div>

<div class="tooltip" id="tooltip"></div>

<script>
const DATA = __DATA_PLACEHOLDER__;

// 颜色方案
const COLORS = [
  '#4C78A8','#F58518','#E45756','#72B7B2','#54A24B',
  '#EECA3B','#B279A2','#FF9DA6','#9D755D','#BAB0AC',
  '#6B8E9B','#D4A76A','#7B68EE','#20B2AA','#CD853F'
];
const orderColors = {};
let colorIdx = 0;
function getColor(orderId) {
  if (!orderColors[orderId]) {
    orderColors[orderId] = COLORS[colorIdx % COLORS.length];
    colorIdx++;
  }
  return orderColors[orderId];
}

// 元信息
document.getElementById('meta').textContent =
  `排程时间范围: ${DATA.time_range.start} ~ ${DATA.time_range.end} | 共 ${DATA.order_count} 个工单`;

// 统计卡片
const totalHours = DATA.machines.reduce((s, m) => s + m.total_hours, 0);
const maxMachine = DATA.machines.reduce((a, b) => a.total_hours > b.total_hours ? a : b);
document.getElementById('stats').innerHTML = `
  <div class="stat-card">
    <h3>工单总数</h3>
    <div class="value">${DATA.order_count}</div>
  </div>
  <div class="stat-card">
    <h3>总排程时长</h3>
    <div class="value">${totalHours.toFixed(1)}h</div>
    <div class="sub">${(totalHours / 24).toFixed(1)} 天</div>
  </div>
  <div class="stat-card">
    <h3>最繁忙机器</h3>
    <div class="value">${maxMachine.machine_name}</div>
    <div class="sub">${maxMachine.total_hours}h / ${maxMachine.job_count} 个作业</div>
  </div>
  <div class="stat-card">
    <h3>机器总数</h3>
    <div class="value">${DATA.machines.length}</div>
    <div class="sub">${DATA.personnel.length} 道工序</div>
  </div>
`;

// 甘特图
function renderGantt() {
  const chart = document.getElementById('gantt-chart');
  if (!DATA.jobs.length) { chart.innerHTML = '<p>暂无数据</p>'; return; }

  const allStart = Math.min(...DATA.jobs.map(j => j.start_ts));
  const allEnd = Math.max(...DATA.jobs.map(j => j.end_ts));
  const range = allEnd - allStart || 1;

  // 按机器分组
  const machineMap = {};
  DATA.jobs.forEach(j => {
    if (!machineMap[j.machine_id]) machineMap[j.machine_id] = { name: j.machine_name, jobs: [] };
    machineMap[j.machine_id].jobs.push(j);
  });

  let html = '';
  Object.entries(machineMap).forEach(([mid, info]) => {
    info.jobs.forEach(j => {
      const left = ((j.start_ts - allStart) / range * 100).toFixed(2);
      const width = (((j.end_ts - j.start_ts) / range) * 100).toFixed(2);
      const color = getColor(j.order_id);
      html += `<div class="gantt-row">
        <div class="gantt-label">${info.name}</div>
        <div class="gantt-bar-area">
          <div class="gantt-bar" style="left:${left}%;width:${width}%;background:${color}"
               data-tip="${j.order_id} | ${j.product} ×${j.quantity}\n${j.step_name}: ${j.start} → ${j.end}">
            ${width > 5 ? j.order_id : ''}
          </div>
        </div>
      </div>`;
    });
  });
  chart.innerHTML = html;

  // Tooltip
  chart.addEventListener('mouseover', e => {
    const bar = e.target.closest('.gantt-bar');
    if (!bar) return;
    const tip = document.getElementById('tooltip');
    tip.style.display = 'block';
    tip.textContent = bar.dataset.tip;
  });
  chart.addEventListener('mouseout', () => {
    document.getElementById('tooltip').style.display = 'none';
  });
  chart.addEventListener('mousemove', e => {
    const tip = document.getElementById('tooltip');
    tip.style.left = (e.clientX + 12) + 'px';
    tip.style.top = (e.clientY + 12) + 'px';
  });
}

// 负荷条
function renderLoads(containerId, data, keyName, keyLabel) {
  const container = document.getElementById(containerId);
  const maxVal = Math.max(...data.map(d => d.total_hours)) || 1;
  let html = '';
  data.forEach(d => {
    const pct = (d.total_hours / maxVal * 100).toFixed(1);
    const hours = d.total_hours;
    const color = hours / maxVal > 0.8 ? '#E45756' : hours / maxVal > 0.5 ? '#F58518' : '#4C78A8';
    html += `<div class="load-row">
      <div class="load-name">${d[keyLabel]}</div>
      <div class="load-bar-bg">
        <div class="load-bar-fill" style="width:${pct}%;background:${color}"></div>
      </div>
      <div class="load-value">${hours}h (${d.job_count}件)</div>
    </div>`;
  });
  container.innerHTML = html;
}

// Tab 切换
function switchTab(name) {
  document.querySelectorAll('.tab').forEach((t, i) => {
    const names = ['gantt', 'machine', 'personnel'];
    t.classList.toggle('active', names[i] === name);
  });
  document.querySelectorAll('.tab-content').forEach(tc => {
    tc.classList.remove('active');
  });
  document.getElementById(name + '-tab').classList.add('active');
}

// 初始化
renderGantt();
renderLoads('machine-loads', DATA.machines, 'machine_id', 'machine_name');
renderLoads('personnel-loads', DATA.personnel, 'step_id', 'step_name');
</script>
</body>
</html>"""


def generate_gantt_html(data: dict, output_path: str = None) -> str:
    """生成甘特图HTML文件"""
    html = HTML_TEMPLATE.replace('__DATA_PLACEHOLDER__', json.dumps(data, ensure_ascii=False))
    if output_path:
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html)
        return output_path
    return html


def generate_csv_template(output_path: str = "order_template.csv"):
    """生成CSV工单模板"""
    header = "order_id,product,quantity,arrival_time,due_date,priority\n"
    sample = (
        "WO-001,零件A,5,2026-04-18 08:00,2026-04-20,1\n"
        "WO-002,零件B,3,2026-04-18 09:00,2026-04-21,2\n"
        "WO-003,零件A,2,2026-04-18 10:00,2026-04-20,1\n"
    )
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(header + sample)
    return output_path


if __name__ == "__main__":
    # 当作独立脚本运行时，执行完整流程
    import sys
    import argparse
    sys.path.insert(0, os.path.dirname(__file__))
    import scheduler
    from work_calendar import (
        create_standard_calendar,
        create_two_shift_calendar,
        create_three_shift_calendar
    )
    
    parser = argparse.ArgumentParser(description='生产调度甘特图生成器')
    parser.add_argument('csv', help='工单CSV文件路径')
    parser.add_argument('output', nargs='?', default='gantt.html', help='输出HTML路径')
    parser.add_argument('--shift', choices=['24h', 'day', '2shift', '3shift'], 
                        default='24h', help='工作班次: 24h=24小时, day=白班(8-17), 2shift=两班倒, 3shift=三班倒')
    parser.add_argument('--work-days', type=int, nargs='+', default=None,
                        help='工作日，0=周一，6=周日，如：--work-days 0 1 2 3 4')
    parser.add_argument('--algo', choices=['fcfs', 'greedy', 'aco'], default='fcfs',
                        help='排程算法: fcfs=先到先做, greedy=贪婪(负载均衡), aco=蚁群算法(负载均衡)')
    parser.add_argument('--sim', action='store_true',
                        help='同时生成仿真可视化页面')
    
    args = parser.parse_args()
    
    # 创建日历配置
    work_days = args.work_days if args.work_days else None
    
    if args.shift == '24h':
        calendar = create_standard_calendar(work_start=0, work_end=23, work_days=list(range(7)))
        shift_name = "24小时生产"
    elif args.shift == 'day':
        calendar = create_standard_calendar(work_start=8, work_end=17, work_days=work_days or [0,1,2,3,4])
        shift_name = "白班(8:00-17:00)"
    elif args.shift == '2shift':
        calendar = create_two_shift_calendar(
            day_start=8, day_end=17,
            night_start=18, night_end=2,
            work_days=work_days or [0,1,2,3,4,5]
        )
        shift_name = "两班倒(8:00-17:00 + 18:00-02:00)"
    elif args.shift == '3shift':
        calendar = create_three_shift_calendar(work_days=work_days or list(range(7)))
        shift_name = "三班倒(24小时)"
    
    data = jobs_to_json(scheduler, args.csv, calendar, args.algo)
    if "error" in data:
        print(f"错误: {data['error']}")
        sys.exit(1)

    algo_name = {'fcfs': 'FCFS', 'greedy': '贪婪(负载均衡)', 'aco': '蚁群(负载均衡)'}
    
    # 保存原始jobs用于仿真，然后从data中移除（因为不可JSON序列化）
    jobs_for_sim = data.pop('_jobs', [])
    
    generate_gantt_html(data, args.output)
    print(f"✅ 甘特图已生成: {args.output}")
    print(f"   排程算法: {algo_name[args.algo]}")
    print(f"   班次模式: {shift_name}")
    print(f"   工单数: {data['order_count']}")
    print(f"   时间范围: {data['time_range']['start']} ~ {data['time_range']['end']}")
    
    # 生成仿真页面
    from factory_simulator import generate_simulator
    sim_path = args.output.replace('.html', '_simulator.html')
    generate_simulator(jobs_for_sim, sim_path)
    print(f"✅ 仿真页面已生成: {sim_path}")
    
    # 生成合并版（甘特图 + 仿真）
    from combined_generator import generate_combined_html
    combined_path = args.output.replace('.html', '_combined.html')
    generate_combined_html(args.csv, combined_path, calendar, args.algo)
    print(f"✅ 合并页面已生成: {combined_path}")
