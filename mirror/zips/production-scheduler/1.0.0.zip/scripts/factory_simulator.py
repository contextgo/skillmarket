#!/usr/bin/env python3
"""
生产仿真可视化 - 工件水平串行排列版
点击机器查看详情弹窗
"""

import json
import sys
from datetime import datetime, timedelta
from typing import List, Dict

from scheduler import WorkOrder, ProcessStep, ScheduledJob, DEFAULT_MACHINES
from work_calendar import WorkCalendar


def build_simulation_data(jobs: List[ScheduledJob]) -> Dict:
    """构建仿真数据"""
    stations = {
        'P1': {'name': '下料区', 'x': 100, 'y': 300, 'color': '#60A5FA'},
        'P2': {'name': '机加工', 'x': 300, 'y': 300, 'color': '#FBBF24'},
        'P3': {'name': '焊接区', 'x': 500, 'y': 300, 'color': '#F87171'},
        'P4': {'name': '表面处理', 'x': 700, 'y': 300, 'color': '#A78BFA'},
        'P5': {'name': '质检区', 'x': 900, 'y': 300, 'color': '#34D399'},
    }
    
    machines_pos = {
        'M1': {'x': 70, 'y': 200},
        'M2': {'x': 130, 'y': 400},
        'M3': {'x': 270, 'y': 200},
        'M4': {'x': 330, 'y': 400},
        'M5': {'x': 470, 'y': 200},
        'M6': {'x': 530, 'y': 400},
        'M7': {'x': 700, 'y': 300},
        'M8': {'x': 870, 'y': 200},
        'M9': {'x': 930, 'y': 400},
    }
    
    timeline = []
    all_orders = set()
    
    for job in jobs:
        all_orders.add(job.order_id)
        timeline.append({
            'time': job.start_time.timestamp() * 1000,
            'type': 'start',
            'order_id': job.order_id,
            'product': job.product,
            'quantity': job.quantity,
            'step': job.step_id,
            'step_name': job.step_name,
            'machine': job.machine_id,
            'machine_name': job.machine_name,
        })
        timeline.append({
            'time': job.end_time.timestamp() * 1000,
            'type': 'end',
            'order_id': job.order_id,
            'product': job.product,
            'quantity': job.quantity,
            'step': job.step_id,
            'step_name': job.step_name,
            'machine': job.machine_id,
            'machine_name': job.machine_name,
        })
    
    timeline.sort(key=lambda x: x['time'])
    
    start_time = min(e['time'] for e in timeline)
    end_time = max(e['time'] for e in timeline)
    total_duration = end_time - start_time
    
    return {
        'stations': stations,
        'machines_pos': machines_pos,
        'machine_names': DEFAULT_MACHINES,
        'timeline': timeline,
        'start_time': start_time,
        'end_time': end_time,
        'total_duration': total_duration,
        'total_orders': len(all_orders),
        'total_jobs': len(jobs),
    }


SIMULATOR_HTML = r'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>生产仿真可视化</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body { 
    font-family: -apple-system, 'PingFang SC', 'Microsoft YaHei', sans-serif; 
    background: #0B1121; 
    color: #E2E8F0;
    overflow: hidden;
}

.header { 
    background: linear-gradient(135deg, #1E293B, #0F172A); 
    padding: 12px 20px; 
    display: flex; 
    justify-content: space-between; 
    align-items: center;
    border-bottom: 1px solid #334155;
}
.header h1 { font-size: 17px; color: #60A5FA; font-weight: 600; }

.stats-panel { display: flex; gap: 24px; }
.stat-item { text-align: center; }
.stat-value { font-size: 20px; font-weight: 700; color: #60A5FA; }
.stat-label { font-size: 11px; color: #94A3B8; margin-top: 1px; }

.main-container { display: flex; height: calc(100vh - 52px); }

#canvas-container { 
    flex: 1; position: relative; 
    background: radial-gradient(circle at 50% 30%, #1E293B 0%, #0B1121 100%);
}
#factory-canvas { display: block; cursor: pointer; }

.panel {
    width: 300px;
    background: #1E293B;
    border-left: 1px solid #334155;
    display: flex;
    flex-direction: column;
}

.controls { padding: 16px; border-bottom: 1px solid #334155; }

.btn {
    padding: 7px 18px; border: none; border-radius: 8px;
    cursor: pointer; font-size: 13px; font-weight: 500;
    transition: all .15s;
}
.btn-primary { background: #3B82F6; color: #fff; }
.btn-primary:hover { background: #2563EB; }
.btn-secondary { background: #334155; color: #94A3B8; }
.btn-secondary:hover { background: #475569; color: #E2E8F0; }

.row { display: flex; align-items: center; gap: 8px; margin-bottom: 14px; }
.row label { width: 48px; font-size: 12px; color: #64748B; }

.speed-buttons { display: flex; gap: 4px; }
.spd {
    padding: 5px 10px; background: #334155; border: 1px solid #475569;
    border-radius: 6px; color: #94A3B8; cursor: pointer; font-size: 11px; font-weight: 500;
}
.spd.active { background: #3B82F6; color: #fff; border-color: #3B82F6; }

.slider-wrap { margin-bottom: 8px; }
#time-slider {
    -webkit-appearance: none; width: 100%; height: 8px;
    background: #334155; border-radius: 4px; outline: none; cursor: pointer;
}
#time-slider::-webkit-slider-thumb {
    -webkit-appearance: none; width: 20px; height: 20px;
    background: #3B82F6; border-radius: 50%; cursor: pointer;
    box-shadow: 0 2px 8px rgba(59,130,246,.5); border: 2px solid #fff;
}
#time-slider::-moz-range-thumb {
    width: 20px; height: 20px;
    background: #3B82F6; border-radius: 50%; border: 2px solid #fff; cursor: pointer;
}
#current-time {
    font-family: 'SF Mono', monospace; font-size: 13px;
    color: #60A5FA; margin-top: 6px; font-weight: 600;
}

.log { flex: 1; overflow-y: auto; padding: 12px; }
.log h3 { font-size: 12px; color: #64748B; margin-bottom: 8px; text-transform: uppercase; letter-spacing: .5px; }
.log-item {
    padding: 7px 10px; margin-bottom: 5px; border-radius: 6px;
    font-size: 11px; background: #0F172A; border-left: 3px solid;
    animation: fadeIn .25s ease;
}
@keyframes fadeIn { from { opacity:0; transform:translateY(-4px); } to { opacity:1; transform:translateY(0); } }
.log-item.start { border-color: #3B82F6; }
.log-item.end   { border-color: #10B981; }
.log-time { color: #64748B; margin-right: 6px; font-family: monospace; font-size: 10px; }

.machines { padding: 12px; border-top: 1px solid #334155; }
.machines h3 { font-size: 12px; color: #64748B; margin-bottom: 8px; }
.mgrid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 6px; }
.mcard {
    padding: 6px 4px; border-radius: 6px; text-align: center; font-size: 10px;
    transition: background .2s; cursor: pointer;
}
.mcard:hover { transform: scale(1.05); }
.mcard.idle  { background: #1E293B; border: 1px solid #334155; }
.mcard.busy  { background: #1E3A8A; border: 1px solid #3B82F6; }
.mcard .mn { color: #94A3B8; font-weight: 500; }
.mcard .mo { color: #60A5FA; font-size: 9px; margin-top: 2px; }

/* 详情弹窗 */
.modal-overlay {
    position: fixed; top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(0,0,0,0.7); display: none; justify-content: center; align-items: center;
    z-index: 100;
}
.modal-overlay.show { display: flex; }
.modal {
    background: #1E293B; border-radius: 12px; padding: 20px;
    max-width: 400px; width: 90%; max-height: 70vh; overflow-y: auto;
    border: 1px solid #334155;
}
.modal h3 { color: #60A5FA; margin-bottom: 12px; font-size: 16px; }
.modal-close {
    float: right; background: #334155; border: none; color: #94A3B8;
    width: 28px; height: 28px; border-radius: 6px; cursor: pointer; font-size: 16px;
}
.modal-close:hover { background: #475569; color: #fff; }
.job-list { margin-top: 10px; }
.job-item {
    display: flex; justify-content: space-between; align-items: center;
    padding: 10px; background: #0F172A; border-radius: 8px;
    margin-bottom: 8px; font-size: 12px;
}
.job-item .jid { color: #60A5FA; font-weight: 600; }
.job-item .jtime { color: #64748B; font-size: 10px; }

.legend {
    position: absolute; bottom: 16px; left: 16px;
    background: rgba(15, 23, 42, .9); backdrop-filter: blur(6px);
    padding: 12px 16px; border-radius: 10px;
    border: 1px solid #334155;
    display: flex; gap: 14px;
}
.leg { display: flex; align-items: center; gap: 5px; font-size: 11px; color: #94A3B8; }
.leg-dot { width: 10px; height: 10px; border-radius: 3px; }
</style>
</head>
<body>

<div class="header">
    <h1>🏭 生产仿真可视化</h1>
    <div class="stats-panel">
        <div class="stat-item"><div class="stat-value" id="s-done">0</div><div class="stat-label">已完成</div></div>
        <div class="stat-item"><div class="stat-value" id="s-wip">0</div><div class="stat-label">在制品</div></div>
        <div class="stat-item"><div class="stat-value" id="s-wait">0</div><div class="stat-label">待加工</div></div>
        <div class="stat-item"><div class="stat-value" id="s-util">0%</div><div class="stat-label">利用率</div></div>
    </div>
</div>

<div class="main-container">
    <div id="canvas-container">
        <canvas id="factory-canvas"></canvas>
        <div class="legend">
            <div class="leg"><div class="leg-dot" style="background:#60A5FA"></div>下料</div>
            <div class="leg"><div class="leg-dot" style="background:#FBBF24"></div>机加工</div>
            <div class="leg"><div class="leg-dot" style="background:#F87171"></div>焊接</div>
            <div class="leg"><div class="leg-dot" style="background:#A78BFA"></div>表面处理</div>
            <div class="leg"><div class="leg-dot" style="background:#34D399"></div>质检</div>
        </div>
    </div>
    <div class="panel">
        <div class="controls">
            <div class="row">
                <button id="play-btn" class="btn btn-primary">▶ 开始</button>
                <button id="reset-btn" class="btn btn-secondary">↺ 重置</button>
            </div>
            <div class="row">
                <label>倍速</label>
                <div class="speed-buttons">
                    <button class="spd" data-s="1">1×</button>
                    <button class="spd active" data-s="10">10×</button>
                    <button class="spd" data-s="50">50×</button>
                    <button class="spd" data-s="100">100×</button>
                </div>
            </div>
            <div class="slider-wrap">
                <input type="range" id="time-slider" min="0" max="1000" value="0">
            </div>
            <div id="current-time">--:-- --</div>
        </div>
        <div class="log"><h3>📋 事件日志</h3><div id="log-box"></div></div>
        <div class="machines">
            <h3>🔧 设备状态 (点击机器查看详情)</h3>
            <div class="mgrid" id="mgrid"></div>
        </div>
    </div>
</div>

<!-- 详情弹窗 -->
<div class="modal-overlay" id="modal">
    <div class="modal">
        <button class="modal-close" onclick="closeModal()">×</button>
        <h3 id="modal-title">机器详情</h3>
        <div class="job-list" id="modal-content"></div>
    </div>
</div>

<script>
const D = __DATA_PLACEHOLDER__;
let playing = false, ct = D.start_time, speed = 10, raf = null, lastTs = 0;
const canvas = document.getElementById('factory-canvas');
const ctx = canvas.getContext('2d');
const slider = document.getElementById('time-slider');

// 工件颜色
const oClr = {};
const palette = ['#60A5FA','#FBBF24','#F87171','#34D399','#A78BFA','#EC4899','#22D3EE','#FB923C','#818CF8','#2DD4BF'];
let ci = 0;
function clr(id){ if(!oClr[id]) oClr[id]=palette[ci++%palette.length]; return oClr[id]; }

// 机器状态
const mBusy = {};
const machineClickAreas = []; // 点击区域
Object.keys(D.machines_pos).forEach(k => mBusy[k]=null);

let processedIdx = 0;
let isDragging = false;

/* ── Canvas尺寸 ── */
function resize(){ 
    canvas.width=canvas.parentElement.clientWidth; 
    canvas.height=canvas.parentElement.clientHeight; 
    draw(); 
}
resize(); window.addEventListener('resize', resize);

/* ── 绘制 ── */
function draw(){
    const W=canvas.width, H=canvas.height;
    ctx.clearRect(0,0,W,H);
    const s=Math.min(W/1100, H/600)*.85, ox=(W-1100*s)/2, oy=(H-600*s)/2;
    ctx.save(); ctx.translate(ox,oy); ctx.scale(s,s);

    machineClickAreas.length = 0; // 清空点击区域

    // 连接线
    const stns=Object.values(D.stations);
    ctx.strokeStyle='#334155'; ctx.lineWidth=3; ctx.setLineDash([8,6]);
    stns.forEach((st,i)=>{
        if(i<stns.length-1){ 
            ctx.beginPath(); ctx.moveTo(st.x+70,st.y); ctx.lineTo(stns[i+1].x-70,stns[i+1].y); ctx.stroke(); 
        }
    });
    ctx.setLineDash([]);

    // 工位区域
    Object.values(D.stations).forEach(st=>{
        roundRect(ctx, st.x-80, st.y-65, 160, 130, 12, st.color+'15');
        ctx.strokeStyle=st.color+'60'; ctx.lineWidth=1.5;
        roundRect(ctx, st.x-80, st.y-65, 160, 130, 12, null, true);
        ctx.fillStyle='#E2E8F0'; ctx.font='bold 13px sans-serif'; ctx.textAlign='center';
        ctx.fillText(st.name, st.x, st.y-42);
    });

    // 获取当前各机器上的工单
    const activeByMachine = {};
    D.timeline.forEach((e,i)=>{
        if(i >= processedIdx) return;
        if(e.type!=='start') return;
        const ended = D.timeline.find(x=> x.order_id===e.order_id && x.step===e.step && x.type==='end' && x.time<=ct);
        if(ended) return;
        if(!activeByMachine[e.machine]) activeByMachine[e.machine]=[];
        activeByMachine[e.machine].push(e);
    });

    // 机器和上方工单队列
    Object.entries(D.machines_pos).forEach(([mid,p])=>{
        const jobs = activeByMachine[mid] || [];
        const busy = jobs.length > 0;
        
        // 机器上方队列区域背景（如果有工单）
        if(busy){
            const qy = p.y - 90;
            ctx.fillStyle = '#1E293B';
            roundRect(ctx, p.x - 60, qy, 120, 35, 6, null, false, true);
            ctx.strokeStyle = '#3B82F6';
            ctx.lineWidth = 1;
            ctx.stroke();
        }
        
        // 工件队列（水平串行排列，最多显示3个）
        jobs.slice(0, 3).forEach((job, idx)=>{
            const c = clr(job.order_id);
            const jx = p.x - 50 + idx * 36;
            const jy = p.y - 82;
            
            // 工件方块
            ctx.fillStyle = c;
            roundRect(ctx, jx, jy, 32, 22, 4, null, false, true);
            
            // 工单号
            ctx.fillStyle = '#fff';
            ctx.font = 'bold 9px sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText(job.order_id.slice(-3), jx + 16, jy + 14);
        });
        
        // +n 指示器
        if(jobs.length > 3){
            ctx.fillStyle = '#60A5FA';
            ctx.font = 'bold 10px sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText(`+${jobs.length-3}`, p.x + 55, p.y - 70);
        }
        
        // 机器本体
        ctx.fillStyle='rgba(0,0,0,0.3)';
        ctx.beginPath(); ctx.ellipse(p.x, p.y+22, 22, 6, 0, 0, Math.PI*2); ctx.fill();
        ctx.fillStyle = busy ? '#1E40AF' : '#334155';
        roundRect(ctx, p.x-22, p.y-18, 44, 36, 8, null, false, true);
        ctx.fillStyle = busy ? '#22C55E' : '#64748B';
        ctx.beginPath(); ctx.arc(p.x+14, p.y-8, 3, 0, Math.PI*2); ctx.fill();
        ctx.fillStyle = busy ? '#fff' : '#94A3B8';
        ctx.font='600 9px sans-serif'; ctx.textAlign='center';
        ctx.fillText(D.machine_names[mid], p.x, p.y+4);
        
        // 记录点击区域
        machineClickAreas.push({
            x: p.x-22, y: p.y-90, w: 44, h: 108,
            mid: mid, mname: D.machine_names[mid], jobs: jobs
        });
    });

    // 传送中工件（在输送线上方）
    D.timeline.forEach((e,i)=>{
        if(i>=processedIdx) return;
        if(e.type!=='end' || e.time>ct) return;
        const nx=D.timeline.find(x=> x.order_id===e.order_id && x.type==='start' && x.time>e.time);
        if(!nx) return;
        const fs=D.stations[e.step], ts=D.stations[nx.step];
        const prog = Math.min(1, (ct-e.time)/5000);
        if(prog<=0 || prog>=1) return;
        const cx=fs.x+(ts.x-fs.x)*prog;
        const cy=fs.y - 50;
        ctx.fillStyle=clr(e.order_id);
        ctx.beginPath(); ctx.arc(cx, cy, 12, 0, Math.PI*2); ctx.fill();
        ctx.strokeStyle='#fff'; ctx.lineWidth=2; ctx.stroke();
        ctx.fillStyle='#fff'; ctx.font='bold 8px sans-serif'; ctx.textAlign='center';
        ctx.fillText(e.order_id.slice(-3), cx, cy+3);
    });

    ctx.restore();
}

function roundRect(c, x, y, w, h, r, fill, stroke, shadow){
    c.beginPath(); c.moveTo(x+r,y);
    c.lineTo(x+w-r,y); c.quadraticCurveTo(x+w,y,x+w,y+r);
    c.lineTo(x+w,y+h-r); c.quadraticCurveTo(x+w,y+h,x+w-r,y+h);
    c.lineTo(x+r,y+h); c.quadraticCurveTo(x,y+h,x,y+h-r);
    c.lineTo(x,y+r); c.quadraticCurveTo(x,y,x+r,y);
    c.closePath();
    if(shadow){ c.shadowColor='rgba(0,0,0,0.4)'; c.shadowBlur=12; c.shadowOffsetY=4; c.fill(); c.shadowColor='transparent'; }
    if(fill) c.fillStyle=fill, c.fill();
    if(stroke){ c.strokeStyle=stroke; c.lineWidth=1.5; c.stroke(); }
    else{ c.fillStyle=c.fillStyle||'#334155'; c.fill(); }
}

/* ── 统计 ── */
function recalc(){
    processedIdx = D.timeline.findIndex(e=> e.time>ct);
    if(processedIdx<0) processedIdx=D.timeline.length;

    Object.keys(mBusy).forEach(k=>mBusy[k]=null);
    D.timeline.forEach((e,i)=>{
        if(i>=processedIdx) return;
        if(e.type==='start') mBusy[e.machine]=e.order_id;
        if(e.type==='end') mBusy[e.machine]=null;
    });

    const done = D.timeline.filter((e,i)=> i<processedIdx && e.type==='end').length;
    const wip = Object.values(mBusy).filter(x=>x).length;
    const busy = Object.values(mBusy).filter(x=>x).length;
    const total = Object.keys(mBusy).length;
    document.getElementById('s-done').textContent = done;
    document.getElementById('s-wip').textContent = wip;
    document.getElementById('s-wait').textContent = Math.max(0, D.total_jobs - done - wip);
    document.getElementById('s-util').textContent = Math.round(busy/total*100)+'%';

    const pct = ((ct-D.start_time)/D.total_duration)*100;
    if(!isDragging) slider.value = pct/0.1;
    document.getElementById('current-time').textContent = fmtTime(ct);

    updateLog(); updateMGrid();
}

let lastLogIdx = 0;
function updateLog(){
    const box = document.getElementById('log-box');
    for(let i=lastLogIdx; i<processedIdx; i++){
        const e = D.timeline[i];
        const div = document.createElement('div');
        div.className = 'log-item ' + e.type;
        const ts = fmtTime(e.time);
        const action = e.type==='start' ? '▶ 开始加工' : '✓ 加工完成';
        div.innerHTML = `<span class="log-time">${ts}</span>${action} <b>${e.order_id.slice(-3)}</b> → ${e.step_name} (${e.machine_name})`;
        box.insertBefore(div, box.firstChild);
        if(box.children.length>60) box.removeChild(box.lastChild);
    }
    lastLogIdx = processedIdx;
}

function updateMGrid(){
    const g = document.getElementById('mgrid');
    g.innerHTML = '';
    Object.entries(mBusy).forEach(([mid, oid])=>{
        const d = document.createElement('div');
        d.className = 'mcard ' + (oid?'busy':'idle');
        d.innerHTML = `<div class="mn">${D.machine_names[mid]}</div><div class="mo">${oid?oid.slice(-3)+'件':'空闲'}</div>`;
        d.onclick = ()=> showMachineDetail(mid);
        g.appendChild(d);
    });
}

function fmtTime(ms){
    const d = new Date(ms);
    return `${String(d.getMonth()+1).padStart(2,'0')}/${String(d.getDate()).padStart(2,'0')} ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;
}

/* ── 弹窗 ── */
function showMachineDetail(mid){
    const jobs = [];
    D.timeline.forEach((e,i)=>{
        if(i >= processedIdx) return;
        if(e.type!=='start' || e.machine!==mid) return;
        const ended = D.timeline.find(x=> x.order_id===e.order_id && x.step===e.step && x.type==='end' && x.time<=ct);
        if(!ended) jobs.push(e);
    });
    
    document.getElementById('modal-title').textContent = `${D.machine_names[mid]} - 加工中工单 (${jobs.length})`;
    const content = document.getElementById('modal-content');
    content.innerHTML = '';
    
    if(jobs.length===0){
        content.innerHTML = '<div style="color:#64748B;text-align:center;padding:20px;">当前无加工中工单</div>';
    }else{
        jobs.forEach(j=>{
            const div = document.createElement('div');
            div.className = 'job-item';
            div.innerHTML = `<span class="jid">${j.order_id}</span><span>${j.step_name} ×${j.quantity}</span>`;
            content.appendChild(div);
        });
    }
    document.getElementById('modal').classList.add('show');
}

function closeModal(){ document.getElementById('modal').classList.remove('show'); }

// 点击Canvas上的机器
canvas.addEventListener('click', (e)=>{
    const rect = canvas.getBoundingClientRect();
    const s = Math.min(canvas.width/1100, canvas.height/600)*0.85;
    const ox = (canvas.width - 1100*s)/2;
    const oy = (canvas.height - 600*s)/2;
    const cx = (e.clientX - rect.left - ox) / s;
    const cy = (e.clientY - rect.top - oy) / s;
    
    for(const area of machineClickAreas){
        if(cx>=area.x && cx<=area.x+area.w && cy>=area.y && cy<=area.y+area.h){
            showMachineDetail(area.mid);
            return;
        }
    }
});

// 点击遮罩关闭弹窗
document.getElementById('modal').addEventListener('click', (e)=>{
    if(e.target.id==='modal') closeModal();
});

/* ── 动画 ── */
function tick(ts){
    if(!playing) return;
    if(lastTs){ ct += (ts-lastTs)*speed; if(ct>=D.end_time){ ct=D.end_time; pause(); } }
    lastTs=ts;
    recalc(); draw();
    raf=requestAnimationFrame(tick);
}

function play(){ if(ct>=D.end_time) resetState(); playing=true; lastTs=0; document.getElementById('play-btn').textContent='⏸ 暂停'; raf=requestAnimationFrame(tick); }
function pause(){ playing=false; document.getElementById('play-btn').textContent='▶ 继续'; if(raf) cancelAnimationFrame(raf); }
function resetState(){ ct=D.start_time; processedIdx=0; lastLogIdx=0; Object.keys(mBusy).forEach(k=>mBusy[k]=null); document.getElementById('log-box').innerHTML=''; }

/* ── 事件 ── */
document.getElementById('play-btn').addEventListener('click', ()=> playing? pause() : play());
document.getElementById('reset-btn').addEventListener('click', ()=>{ pause(); resetState(); document.getElementById('play-btn').textContent='▶ 开始'; draw(); recalc(); updateMGrid(); });

document.querySelectorAll('.spd').forEach(b=>b.addEventListener('click',()=>{
    document.querySelectorAll('.spd').forEach(x=>x.classList.remove('active'));
    b.classList.add('active'); speed=parseInt(b.dataset.s);
}));

slider.addEventListener('mousedown', ()=>{ isDragging=true; if(playing) pause(); });
slider.addEventListener('touchstart', ()=>{ isDragging=true; if(playing) pause(); }, {passive:true});

slider.addEventListener('input', ()=>{
    const pct = slider.value / 1000;
    ct = D.start_time + D.total_duration * pct;
    lastLogIdx = 0;
    document.getElementById('log-box').innerHTML = '';
    recalc(); draw();
});

document.addEventListener('mouseup', ()=>{ isDragging=false; });
document.addEventListener('touchend', ()=>{ isDragging=false; });

document.addEventListener('keydown', e=>{
    if(e.code==='Space'){ e.preventDefault(); playing? pause() : play(); }
    if(e.code==='ArrowRight'){ ct=Math.min(D.end_time, ct+D.total_duration*0.02); lastLogIdx=0; document.getElementById('log-box').innerHTML=''; recalc(); draw(); }
    if(e.code==='ArrowLeft'){ ct=Math.max(D.start_time, ct-D.total_duration*0.02); lastLogIdx=0; document.getElementById('log-box').innerHTML=''; recalc(); draw(); }
});

// 初始
draw(); recalc(); updateMGrid();
</script>
</body>
</html>'''


def generate_simulator(jobs: List[ScheduledJob], output_path: str = "simulator.html"):
    """生成仿真HTML页面"""
    data = build_simulation_data(jobs)
    html = SIMULATOR_HTML.replace('__DATA_PLACEHOLDER__', json.dumps(data, ensure_ascii=False))
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(html)
    return output_path


if __name__ == "__main__":
    import scheduler
    from work_calendar import create_two_shift_calendar
    
    cal = create_two_shift_calendar()
    orders = scheduler.parse_orders_from_csv('../orders.csv')
    processes, machines = scheduler.load_custom_config()
    jobs = scheduler.schedule_fcfs(orders, processes, machines, cal)
    
    generate_simulator(jobs, '../simulator.html')
    print(f"✅ 仿真页面已生成: simulator.html")
