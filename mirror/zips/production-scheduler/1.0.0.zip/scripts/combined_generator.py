#!/usr/bin/env python3
"""
合并甘特图+仿真 → 单页HTML，Tab切换
"""

import json, sys, os
sys.path.insert(0, os.path.dirname(__file__))

from scheduler import parse_orders_from_csv, load_custom_config, schedule_fcfs
from work_calendar import WorkCalendar
from factory_simulator import build_simulation_data


def generate_combined_html(csv_path: str, output_path: str, calendar: WorkCalendar, algorithm: str = 'fcfs') -> str:
    """合并甘特图+仿真到单个HTML"""
    from aco_scheduler import schedule_aco, schedule_greedy
    
    orders = parse_orders_from_csv(csv_path)
    processes, machines = load_custom_config()
    
    if algorithm == 'aco':
        jobs, _ = schedule_aco(orders, processes, machines, calendar)
    elif algorithm == 'greedy':
        jobs = schedule_greedy(orders, processes, machines, calendar)
    else:
        jobs = schedule_fcfs(orders, processes, machines, calendar)
    
    machine_loads = schedule_fcfs.__module__ and __import__('scheduler', fromlist=['get_machine_loads']).get_machine_loads(jobs)
    personnel_loads = __import__('scheduler', fromlist=['get_personnel_loads']).get_personnel_loads(jobs)

    # 找时间范围
    all_times = [j.start_time for j in jobs] + [j.end_time for j in jobs]
    min_time, max_time = min(all_times), max(all_times)

    # 甘特图数据
    jobs_data = []
    for j in jobs:
        jobs_data.append({
            "order_id": j.order_id, "product": j.product, "quantity": j.quantity,
            "step_id": j.step_id, "step_name": j.step_name,
            "machine_id": j.machine_id, "machine_name": j.machine_name,
            "start": j.start_time.strftime("%Y-%m-%d %H:%M"),
            "end": j.end_time.strftime("%Y-%m-%d %H:%M"),
            "start_ts": j.start_time.timestamp() * 1000,
            "end_ts": j.end_time.timestamp() * 1000,
        })
    machines_data = [{"machine_id": mid, "machine_name": info['machine_name'],
                       "total_hours": round(info['total_minutes']/60, 1), "job_count": info['job_count']}
                      for mid, info in machine_loads.items()]
    personnel_data = [{"step_id": sid, "step_name": info['step_name'],
                        "total_hours": round(info['total_minutes']/60, 1), "job_count": info['job_count']}
                       for sid, info in personnel_loads.items()]
    gantt_data = {
        "jobs": jobs_data, "machines": machines_data, "personnel": personnel_data,
        "time_range": {"start": min_time.strftime("%Y-%m-%d %H:%M"), "end": max_time.strftime("%Y-%m-%d %H:%M")},
        "order_count": len(orders),
    }

    # 仿真数据
    sim_data = build_simulation_data(jobs)

    combined = json.dumps({"gantt": gantt_data, "sim": sim_data}, ensure_ascii=False)
    
    html = COMBINED_TEMPLATE.replace('__DATA__', combined)
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(html)
    return output_path


COMBINED_TEMPLATE = r'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>生产排程 · 甘特图 & 仿真</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:-apple-system,'PingFang SC','Microsoft YaHei',sans-serif;background:#0B1121;color:#E2E8F0;overflow:hidden;height:100vh;display:flex;flex-direction:column}

/* ── 顶部导航 ── */
.topbar{background:#1E293B;border-bottom:1px solid #334155;display:flex;align-items:center;justify-content:space-between;padding:0 20px;height:50px;flex-shrink:0}
.topbar h1{font-size:16px;color:#60A5FA;font-weight:600}
.tabs{display:flex;gap:4px}
.tab{padding:8px 20px;border-radius:8px 8px 0 0;cursor:pointer;font-size:13px;font-weight:500;color:#94A3B8;background:transparent;border:1px solid transparent;border-bottom:none;transition:all .15s}
.tab:hover{color:#E2E8F0;background:#334155}
.tab.active{color:#60A5FA;background:#0B1121;border-color:#334155}

/* ── 内容区 ── */
.content{flex:1;overflow:hidden;position:relative}
.page{position:absolute;top:0;left:0;right:0;bottom:0;display:none}
.page.active{display:flex}

/* ═══════════ 甘特图样式 ═══════════ */
#gantt-page{flex-direction:column;overflow:hidden}
.gantt-header{display:flex;justify-content:space-between;align-items:center;padding:12px 16px;background:#1E293B;border-bottom:1px solid #334155}
.gantt-header .info{font-size:13px;color:#94A3B8}
.gantt-header .info b{color:#60A5FA}
.gantt-container{flex:1;display:flex;overflow:hidden}
.gantt-left{width:160px;background:#1E293B;border-right:1px solid #334155;overflow-y:auto;flex-shrink:0}
.gantt-row{height:36px;display:flex;align-items:center;padding:0 12px;font-size:11px;color:#94A3B8;border-bottom:1px solid #1E293B}
.gantt-row-label{color:#CBD5E1;font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.gantt-right{flex:1;overflow:auto;position:relative}
.gantt-canvas-wrap{position:relative;min-height:100%}
.gantt-grid-line{position:absolute;top:0;bottom:0;width:1px;background:#1E293B;z-index:1}
.gantt-grid-label{position:absolute;top:4px;font-size:9px;color:#64748B;transform:translateX(-50%);white-space:nowrap;z-index:2}
.gantt-bar{position:absolute;height:24px;border-radius:4px;cursor:pointer;z-index:5;transition:opacity .15s,filter .15s;display:flex;align-items:center;padding:0 6px;font-size:9px;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.gantt-bar:hover{filter:brightness(1.2);z-index:10}

/* 甘特图详情面板 */
.gantt-detail{position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:#1E293B;border:1px solid #334155;border-radius:12px;padding:20px;min-width:280px;z-index:200;display:none;box-shadow:0 20px 60px rgba(0,0,0,.5)}
.gantt-detail.show{display:block}
.gantt-detail h3{color:#60A5FA;margin-bottom:12px;font-size:15px}
.gantt-detail .row{display:flex;justify-content:space-between;padding:6px 0;font-size:12px;border-bottom:1px solid #334155}
.gantt-detail .row .label{color:#64748B}
.gantt-detail .row .val{color:#E2E8F0}
.gantt-detail-close{position:absolute;top:12px;right:12px;background:#334155;border:none;color:#94A3B8;width:24px;height:24px;border-radius:6px;cursor:pointer;font-size:14px}
.gantt-detail-close:hover{background:#475569;color:#fff}
.gantt-overlay{position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:199;display:none}
.gantt-overlay.show{display:block}

/* 负荷面板 */
.loads{padding:16px;background:#1E293B;border-top:1px solid #334155;flex-shrink:0}
.loads h3{font-size:12px;color:#64748B;margin-bottom:8px}
.loads-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.load-group h4{font-size:11px;color:#94A3B8;margin-bottom:6px}
.load-row{display:flex;align-items:center;gap:8px;margin-bottom:4px;font-size:10px}
.load-name{width:70px;color:#CBD5E1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.load-bar-bg{flex:1;height:8px;background:#334155;border-radius:4px;overflow:hidden}
.load-bar-fill{height:100%;border-radius:4px;transition:width .3s}
.load-val{width:50px;text-align:right;color:#64748B;font-size:9px}

/* ═══════════ 仿真样式 ═══════════ */
#sim-page{flex-direction:row}
.sim-stats{display:flex;gap:20px;padding:8px 16px;background:#1E293B;border-bottom:1px solid #334155;align-items:center;flex-shrink:0}
.sim-stat{text-align:center}
.sim-stat .v{font-size:17px;font-weight:700;color:#60A5FA}
.sim-stat .l{font-size:10px;color:#94A3B8}
.sim-controls{display:flex;align-items:center;gap:10px;margin-left:auto}
.sbtn{padding:5px 14px;border:none;border-radius:6px;cursor:pointer;font-size:12px;font-weight:500;transition:all .15s}
.sbtn-play{background:#3B82F6;color:#fff}.sbtn-play:hover{background:#2563EB}
.sbtn-rst{background:#334155;color:#94A3B8}.sbtn-rst:hover{background:#475569;color:#E2E8F0}
.spd-btns{display:flex;gap:3px}
.sp{padding:4px 8px;background:#334155;border:1px solid #475569;border-radius:5px;color:#94A3B8;cursor:pointer;font-size:10px;font-weight:500}
.sp.on{background:#3B82F6;color:#fff;border-color:#3B82F6}
.sim-slider{flex:1;max-width:300px}
.sim-slider input{width:100%;height:6px;-webkit-appearance:none;background:#334155;border-radius:3px;outline:none;cursor:pointer}
.sim-slider input::-webkit-slider-thumb{-webkit-appearance:none;width:16px;height:16px;background:#3B82F6;border-radius:50%;cursor:pointer;border:2px solid #fff;box-shadow:0 2px 6px rgba(59,130,246,.4)}
.sim-slider input::-moz-range-thumb{width:16px;height:16px;background:#3B82F6;border-radius:50%;border:2px solid #fff;cursor:pointer}
#sim-time{font-family:'SF Mono',monospace;font-size:12px;color:#60A5FA;font-weight:600;min-width:90px}

#canvas-container{flex:1;position:relative;background:radial-gradient(circle at 50% 30%,#1E293B 0%,#0B1121 100%)}
#factory-canvas{display:block;cursor:pointer}

.sim-panel{width:280px;background:#1E293B;border-left:1px solid #334155;display:flex;flex-direction:column;flex-shrink:0}
.sim-log{flex:1;overflow-y:auto;padding:10px}
.sim-log h3{font-size:11px;color:#64748B;margin-bottom:6px;letter-spacing:.5px}
.log-item{padding:6px 8px;margin-bottom:4px;border-radius:5px;font-size:10px;background:#0F172A;border-left:3px solid;animation:fadeIn .2s}
@keyframes fadeIn{from{opacity:0;transform:translateY(-3px)}to{opacity:1;transform:translateY(0)}}
.log-item.start{border-color:#3B82F6}.log-item.end{border-color:#10B981}
.log-t{color:#64748B;font-family:monospace;font-size:9px;margin-right:4px}

.sim-machines{padding:10px;border-top:1px solid #334155}
.sim-machines h3{font-size:11px;color:#64748B;margin-bottom:6px}
.mgrid{display:grid;grid-template-columns:repeat(3,1fr);gap:4px}
.mc{padding:5px 3px;border-radius:5px;text-align:center;font-size:9px;cursor:pointer;transition:transform .1s}
.mc:hover{transform:scale(1.05)}
.mc.idle{background:#1E293B;border:1px solid #334155}
.mc.busy{background:#1E3A8A;border:1px solid #3B82F6}
.mc .mn{color:#94A3B8;font-weight:500}.mc .mo{color:#60A5FA;font-size:8px;margin-top:1px}

/* 弹窗 */
.modal-bg{position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:100;display:none;justify-content:center;align-items:center}
.modal-bg.show{display:flex}
.modal{background:#1E293B;border-radius:12px;padding:16px;max-width:360px;width:90%;max-height:60vh;overflow-y:auto;border:1px solid #334155}
.modal h3{color:#60A5FA;margin-bottom:10px;font-size:14px}
.modal-x{float:right;background:#334155;border:none;color:#94A3B8;width:24px;height:24px;border-radius:6px;cursor:pointer;font-size:14px}
.modal-x:hover{background:#475569;color:#fff}
.ji{display:flex;justify-content:space-between;align-items:center;padding:8px;background:#0F172A;border-radius:6px;margin-bottom:6px;font-size:11px}
.ji .jid{color:#60A5FA;font-weight:600}

.legend{position:absolute;bottom:12px;left:12px;background:rgba(15,23,42,.9);backdrop-filter:blur(6px);padding:10px 14px;border-radius:8px;border:1px solid #334155;display:flex;gap:12px}
.leg{display:flex;align-items:center;gap:4px;font-size:10px;color:#94A3B8}
.ld{width:8px;height:8px;border-radius:2px}
</style>
</head>
<body>

<div class="topbar">
    <h1>📊 生产排程系统</h1>
    <div class="tabs">
        <div class="tab active" data-tab="sim">🏭 生产仿真</div>
        <div class="tab" data-tab="gantt">📈 甘特图</div>
    </div>
</div>

<div class="content">
    <!-- ═══ 仿真页 ═══ -->
    <div class="page active" id="sim-page">
        <div style="display:flex;flex-direction:column;flex:1;height:100%">
            <div class="sim-stats">
                <div class="sim-stat"><div class="v" id="s-done">0</div><div class="l">已完成</div></div>
                <div class="sim-stat"><div class="v" id="s-wip">0</div><div class="l">在制品</div></div>
                <div class="sim-stat"><div class="v" id="s-wait">0</div><div class="l">待加工</div></div>
                <div class="sim-stat"><div class="v" id="s-util">0%</div><div class="l">利用率</div></div>
                <div class="sim-controls">
                    <button class="sbtn sbtn-play" id="sim-play">▶ 开始</button>
                    <button class="sbtn sbtn-rst" id="sim-reset">↺</button>
                    <div class="spd-btns"><button class="sp" data-s="1">1×</button><button class="sp on" data-s="10">10×</button><button class="sp" data-s="50">50×</button><button class="sp" data-s="100">100×</button></div>
                    <div class="sim-slider"><input type="range" id="time-slider" min="0" max="1000" value="0"></div>
                    <div id="sim-time">--:--</div>
                </div>
            </div>
            <div id="canvas-container">
                <canvas id="factory-canvas"></canvas>
                <div class="legend">
                    <div class="leg"><div class="ld" style="background:#60A5FA"></div>下料</div>
                    <div class="leg"><div class="ld" style="background:#FBBF24"></div>机加工</div>
                    <div class="leg"><div class="ld" style="background:#F87171"></div>焊接</div>
                    <div class="leg"><div class="ld" style="background:#A78BFA"></div>表面处理</div>
                    <div class="leg"><div class="ld" style="background:#34D399"></div>质检</div>
                </div>
            </div>
        </div>
        <div class="sim-panel">
            <div class="sim-log"><h3>📋 事件日志</h3><div id="log-box"></div></div>
            <div class="sim-machines"><h3>🔧 设备状态</h3><div class="mgrid" id="mgrid"></div></div>
        </div>
    </div>

    <!-- ═══ 甘特图页 ═══ -->
    <div class="page" id="gantt-page">
        <div class="gantt-header">
            <div class="info">工单: <b id="g-order-count">0</b> | 时间: <b id="g-range">-</b></div>
        </div>
        <div class="gantt-container">
            <div class="gantt-left" id="gantt-left"></div>
            <div class="gantt-right" id="gantt-right"><div class="gantt-canvas-wrap" id="gantt-wrap"></div></div>
        </div>
        <div class="loads">
            <div class="loads-grid">
                <div class="load-group"><h4>🔧 机器负荷</h4><div id="machine-loads"></div></div>
                <div class="load-group"><h4>👷 工序负荷</h4><div id="personnel-loads"></div></div>
            </div>
        </div>
    </div>
</div>

<!-- 甘特图详情弹窗 -->
<div class="gantt-overlay" id="gantt-overlay"></div>
<div class="gantt-detail" id="gantt-detail">
    <button class="gantt-detail-close" onclick="closeGanttDetail()">×</button>
    <h3 id="gd-title"></h3>
    <div id="gd-body"></div>
</div>

<!-- 仿真弹窗 -->
<div class="modal-bg" id="sim-modal">
    <div class="modal"><button class="modal-x" onclick="closeSimModal()">×</button><h3 id="sm-title"></h3><div id="sm-body"></div></div>
</div>

<script>
const DATA = __DATA__;
const G = DATA.gantt, S = DATA.sim;

/* ══════════ Tab切换 ══════════ */
let simInited = false;
function initSim(){ if(simInited) return; simInited=true; resizeCanvas(); drawSim(); simRecalc(); simUpdateMGrid(); }
document.querySelectorAll('.tab').forEach(t=>t.addEventListener('click',()=>{
    document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));
    document.querySelectorAll('.page').forEach(x=>x.classList.remove('active'));
    t.classList.add('active');
    document.getElementById(t.dataset.tab+'-page').classList.add('active');
    if(t.dataset.tab==='sim') initSim();
}));

/* ══════════ 甘特图 ══════════ */
const STEP_COLORS = {'下料':'#3B82F6','机加工':'#F59E0B','焊接':'#EF4444','表面处理':'#8B5CF6','质检':'#10B981','包装':'#EC4899'};
const ROW_H = 36, BAR_H = 24, HEADER_H = 28;

function renderGantt(){
    const jobs = G.jobs;
    if(!jobs.length) return;
    document.getElementById('g-order-count').textContent = G.order_count;
    document.getElementById('g-range').textContent = G.time_range.start + ' ~ ' + G.time_range.end;

    const t0 = new Date(G.time_range.start).getTime();
    const t1 = new Date(G.time_range.end).getTime();
    const totalMs = t1 - t0 || 1;
    const totalH = totalMs / 3600000;

    // 按order_id分组
    const orders = [...new Set(jobs.map(j=>j.order_id))];
    const totalRows = orders.length;

    const left = document.getElementById('gantt-left');
    const wrap = document.getElementById('gantt-wrap');

    // 像素宽度
    const pxPerHour = Math.max(30, Math.min(80, 800 / totalH));
    const totalW = totalH * pxPerHour;

    // 左侧
    let leftHtml = '';
    orders.forEach(oid=>{
        leftHtml += `<div class="gantt-row"><span class="gantt-row-label">${oid}</span></div>`;
    });
    left.innerHTML = leftHtml;

    // 右侧
    // 时间网格
    let gridHtml = '';
    // 每隔一定小时画一条线
    const stepH = totalH < 48 ? 4 : totalH < 120 ? 8 : 24;
    for(let h=0; h<=totalH; h+=stepH){
        const x = h * pxPerHour;
        const d = new Date(t0 + h*3600000);
        const label = `${String(d.getMonth()+1).padStart(2,'0')}/${String(d.getDate()).padStart(2,'0')} ${String(d.getHours()).padStart(2,'0')}:00`;
        gridHtml += `<div class="gantt-grid-line" style="left:${x}px"></div>`;
        gridHtml += `<div class="gantt-grid-label" style="left:${x}px">${label}</div>`;
    }

    // 工序条
    let barsHtml = '';
    orders.forEach((oid, ri)=>{
        const oJobs = jobs.filter(j=>j.order_id===oid);
        oJobs.forEach(j=>{
            const x = (new Date(j.start).getTime() - t0) / 3600000 * pxPerHour;
            const w = Math.max(4, (new Date(j.end).getTime() - new Date(j.start).getTime()) / 3600000 * pxPerHour);
            const color = STEP_COLORS[j.step_name] || '#6366F1';
            barsHtml += `<div class="gantt-bar" style="left:${x}px;top:${ri*ROW_H + (ROW_H-BAR_H)/2}px;width:${w}px;background:${color}" 
                data-oid="${j.order_id}" data-step="${j.step_name}" data-mid="${j.machine_name}" 
                data-start="${j.start}" data-end="${j.end}" data-product="${j.product}" data-qty="${j.quantity}"
                onclick="showGanttDetail(this)">${j.step_name}</div>`;
        });
    });

    wrap.style.width = totalW + 'px';
    wrap.style.height = (totalRows * ROW_H + HEADER_H) + 'px';
    wrap.innerHTML = gridHtml + barsHtml;

    // 同步滚动
    const right = document.getElementById('gantt-right');
    left.onscroll = ()=>{ right.scrollTop = left.scrollTop; };
    right.onscroll = ()=>{ left.scrollTop = right.scrollTop; };

    // 负荷
    renderLoads('machine-loads', G.machines, 'machine_name', 'machine_name');
    renderLoads('personnel-loads', G.personnel, 'step_name', 'step_name');
}

function renderLoads(id, data, nameKey, labelKey){
    const el = document.getElementById(id);
    const max = Math.max(...data.map(d=>d.total_hours)) || 1;
    el.innerHTML = data.map(d=>{
        const pct = (d.total_hours/max*100).toFixed(1);
        const h = d.total_hours;
        const c = h/max>.8?'#E45756':h/max>.5?'#F58518':'#4C78A8';
        return `<div class="load-row"><span class="load-name">${d[nameKey]}</span><div class="load-bar-bg"><div class="load-bar-fill" style="width:${pct}%;background:${c}"></div></div><span class="load-val">${h}h / ${d.job_count}件</span></div>`;
    }).join('');
}

function showGanttDetail(el){
    const d = el.dataset;
    document.getElementById('gd-title').textContent = d.oid;
    document.getElementById('gd-body').innerHTML = [
        ['产品', d.product], ['数量', d.qty], ['工序', d.step], ['机器', d.mid],
        ['开始', d.start], ['结束', d.end]
    ].map(([l,v])=>`<div class="row"><span class="label">${l}</span><span class="val">${v}</span></div>`).join('');
    document.getElementById('gantt-overlay').classList.add('show');
    document.getElementById('gantt-detail').classList.add('show');
}
function closeGanttDetail(){
    document.getElementById('gantt-overlay').classList.remove('show');
    document.getElementById('gantt-detail').classList.remove('show');
}
document.getElementById('gantt-overlay').onclick = closeGanttDetail;

renderGantt();

/* ══════════ 仿真 ══════════ */
let playing=false, ct=S.start_time, speed=10, raf=null, lastTs=0, isDragging=false;
const canvas=document.getElementById('factory-canvas');
const ctx=canvas.getContext('2d');
const slider=document.getElementById('time-slider');

const oClr={}, palette=['#60A5FA','#FBBF24','#F87171','#34D399','#A78BFA','#EC4899','#22D3EE','#FB923C','#818CF8','#2DD4BF'];
let cIdx=0;
function clr(id){if(!oClr[id])oClr[id]=palette[cIdx++%palette.length];return oClr[id];}

const mBusy={};
Object.keys(S.machines_pos).forEach(k=>mBusy[k]=null);
let processedIdx=0, lastLogIdx=0;
const clickAreas=[];

function resizeCanvas(){canvas.width=canvas.parentElement.clientWidth;canvas.height=canvas.parentElement.clientHeight;drawSim();}
resizeCanvas();
window.addEventListener('resize', resizeCanvas);

function drawSim(){
    const W=canvas.width,H=canvas.height;
    ctx.clearRect(0,0,W,H);
    const s=Math.min(W/1100,H/600)*.85,ox=(W-1100*s)/2,oy=(H-600*s)/2;
    ctx.save();ctx.translate(ox,oy);ctx.scale(s,s);
    clickAreas.length=0;

    const stns=Object.values(S.stations);
    ctx.strokeStyle='#334155';ctx.lineWidth=3;ctx.setLineDash([8,6]);
    stns.forEach((st,i)=>{if(i<stns.length-1){ctx.beginPath();ctx.moveTo(st.x+70,st.y);ctx.lineTo(stns[i+1].x-70,stns[i+1].y);ctx.stroke();}});
    ctx.setLineDash([]);

    Object.values(S.stations).forEach(st=>{
        rr(ctx,st.x-80,st.y-65,160,130,12,st.color+'15');
        ctx.strokeStyle=st.color+'60';ctx.lineWidth=1.5;rr(ctx,st.x-80,st.y-65,160,130,12,null,true);
        ctx.fillStyle='#E2E8F0';ctx.font='bold 13px sans-serif';ctx.textAlign='center';ctx.fillText(st.name,st.x,st.y-42);
    });

    const activeByMachine={};
    S.timeline.forEach((e,i)=>{if(i>=processedIdx||e.type!=='start')return;if(S.timeline.find(x=>x.order_id===e.order_id&&x.step===e.step&&x.type==='end'&&x.time<=ct))return;if(!activeByMachine[e.machine])activeByMachine[e.machine]=[];activeByMachine[e.machine].push(e);});

    Object.entries(S.machines_pos).forEach(([mid,p])=>{
        const jobs=activeByMachine[mid]||[];
        const busy=jobs.length>0;
        if(busy){ctx.fillStyle='#1E293B';rr(ctx,p.x-60,p.y-90,120,35,6,null,false,true);ctx.strokeStyle='#3B82F6';ctx.lineWidth=1;ctx.stroke();}
        jobs.slice(0,3).forEach((job,idx)=>{const c=clr(job.order_id),jx=p.x-50+idx*36,jy=p.y-82;ctx.fillStyle=c;rr(ctx,jx,jy,32,22,4,null,false,true);ctx.fillStyle='#fff';ctx.font='bold 9px sans-serif';ctx.textAlign='center';ctx.fillText(job.order_id.slice(-3),jx+16,jy+14);});
        if(jobs.length>3){ctx.fillStyle='#60A5FA';ctx.font='bold 10px sans-serif';ctx.textAlign='center';ctx.fillText(`+${jobs.length-3}`,p.x+55,p.y-70);}
        ctx.fillStyle='rgba(0,0,0,0.3)';ctx.beginPath();ctx.ellipse(p.x,p.y+22,22,6,0,0,Math.PI*2);ctx.fill();
        ctx.fillStyle=busy?'#1E40AF':'#334155';rr(ctx,p.x-22,p.y-18,44,36,8,null,false,true);
        ctx.fillStyle=busy?'#22C55E':'#64748B';ctx.beginPath();ctx.arc(p.x+14,p.y-8,3,0,Math.PI*2);ctx.fill();
        ctx.fillStyle=busy?'#fff':'#94A3B8';ctx.font='600 9px sans-serif';ctx.textAlign='center';ctx.fillText(S.machine_names[mid],p.x,p.y+4);
        clickAreas.push({x:p.x-22,y:p.y-90,w:44,h:108,mid,mname:S.machine_names[mid],jobs});
    });

    S.timeline.forEach((e,i)=>{if(i>=processedIdx||e.type!=='end'||e.time>ct)return;const nx=S.timeline.find(x=>x.order_id===e.order_id&&x.type==='start'&&x.time>e.time);if(!nx)return;const fs=S.stations[e.step],ts=S.stations[nx.step],prog=Math.min(1,(ct-e.time)/5000);if(prog<=0||prog>=1)return;const cx=fs.x+(ts.x-fs.x)*prog,cy=fs.y-50;ctx.fillStyle=clr(e.order_id);ctx.beginPath();ctx.arc(cx,cy,12,0,Math.PI*2);ctx.fill();ctx.strokeStyle='#fff';ctx.lineWidth=2;ctx.stroke();ctx.fillStyle='#fff';ctx.font='bold 8px sans-serif';ctx.textAlign='center';ctx.fillText(e.order_id.slice(-3),cx,cy+3);});
    ctx.restore();
}

function rr(c,x,y,w,h,r,fill,stroke,shadow){
    c.beginPath();c.moveTo(x+r,y);c.lineTo(x+w-r,y);c.quadraticCurveTo(x+w,y,x+w,y+r);c.lineTo(x+w,y+h-r);c.quadraticCurveTo(x+w,y+h,x+w-r,y+h);c.lineTo(x+r,y+h);c.quadraticCurveTo(x,y+h,x,y+h-r);c.lineTo(x,y+r);c.quadraticCurveTo(x,y,x+r,y);c.closePath();
    if(shadow){c.shadowColor='rgba(0,0,0,0.4)';c.shadowBlur=12;c.shadowOffsetY=4;c.fill();c.shadowColor='transparent';}
    if(fill)c.fillStyle=fill,c.fill();
    if(stroke){c.strokeStyle=stroke;c.lineWidth=1.5;c.stroke();}
    else{c.fillStyle=c.fillStyle||'#334155';c.fill();}
}

function simRecalc(){
    processedIdx=S.timeline.findIndex(e=>e.time>ct);if(processedIdx<0)processedIdx=S.timeline.length;
    Object.keys(mBusy).forEach(k=>mBusy[k]=null);
    S.timeline.forEach((e,i)=>{if(i>=processedIdx)return;if(e.type==='start')mBusy[e.machine]=e.order_id;if(e.type==='end')mBusy[e.machine]=null;});
    const done=S.timeline.filter((e,i)=>i<processedIdx&&e.type==='end').length;
    const wip=Object.values(mBusy).filter(x=>x).length;
    const busy=Object.values(mBusy).filter(x=>x).length;
    const total=Object.keys(mBusy).length;
    document.getElementById('s-done').textContent=done;
    document.getElementById('s-wip').textContent=wip;
    document.getElementById('s-wait').textContent=Math.max(0,S.total_jobs-done-wip);
    document.getElementById('s-util').textContent=Math.round(busy/total*100)+'%';
    if(!isDragging)slider.value=((ct-S.start_time)/S.total_duration)*100/0.1;
    document.getElementById('sim-time').textContent=fmtT(ct);
    simUpdateLog();simUpdateMGrid();
}

function simUpdateLog(){
    const box=document.getElementById('log-box');
    for(let i=lastLogIdx;i<processedIdx;i++){
        const e=S.timeline[i],div=document.createElement('div');div.className='log-item '+e.type;
        div.innerHTML=`<span class="log-t">${fmtT(e.time)}</span>${e.type==='start'?'▶ 开始':'✓ 完成'} <b>${e.order_id.slice(-3)}</b> → ${e.step_name} (${e.machine_name})`;
        box.insertBefore(div,box.firstChild);if(box.children.length>50)box.removeChild(box.lastChild);
    }
    lastLogIdx=processedIdx;
}

function simUpdateMGrid(){
    const g=document.getElementById('mgrid');g.innerHTML='';
    Object.entries(mBusy).forEach(([mid,oid])=>{
        const d=document.createElement('div');d.className='mc '+(oid?'busy':'idle');
        d.innerHTML=`<div class="mn">${S.machine_names[mid]}</div><div class="mo">${oid?oid.slice(-3)+'件':'空闲'}</div>`;
        d.onclick=()=>showSimDetail(mid);g.appendChild(d);
    });
}

function fmtT(ms){const d=new Date(ms);return`${String(d.getMonth()+1).padStart(2,'0')}/${String(d.getDate()).padStart(2,'0')} ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;}

function showSimDetail(mid){
    const jobs=[];S.timeline.forEach((e,i)=>{if(i>=processedIdx||e.type!=='start'||e.machine!==mid)return;if(!S.timeline.find(x=>x.order_id===e.order_id&&x.step===e.step&&x.type==='end'&&x.time<=ct))jobs.push(e);});
    document.getElementById('sm-title').textContent=`${S.machine_names[mid]} - ${jobs.length}件加工中`;
    const body=document.getElementById('sm-body');body.innerHTML='';
    if(!jobs.length){body.innerHTML='<div style="color:#64748B;text-align:center;padding:16px">当前无工单</div>';}
    else jobs.forEach(j=>{const d=document.createElement('div');d.className='ji';d.innerHTML=`<span class="jid">${j.order_id}</span><span>${j.step_name} ×${j.quantity}</span>`;body.appendChild(d);});
    document.getElementById('sim-modal').classList.add('show');
}
function closeSimModal(){document.getElementById('sim-modal').classList.remove('show');}
document.getElementById('sim-modal').onclick=e=>{if(e.target.id==='sim-modal')closeSimModal();};

canvas.addEventListener('click',e=>{
    const rect=canvas.getBoundingClientRect(),s=Math.min(canvas.width/1100,canvas.height/600)*.85,ox=(canvas.width-1100*s)/2,oy=(canvas.height-600*s)/2;
    const cx=(e.clientX-rect.left-ox)/s,cy=(e.clientY-rect.top-oy)/s;
    for(const a of clickAreas){if(cx>=a.x&&cx<=a.x+a.w&&cy>=a.y&&cy<=a.y+a.h){showSimDetail(a.mid);return;}}
});

function tick(ts){if(!playing)return;if(lastTs){ct+=(ts-lastTs)*speed;if(ct>=S.end_time){ct=S.end_time;simPause();}}lastTs=ts;simRecalc();drawSim();raf=requestAnimationFrame(tick);}
function simPlay(){if(ct>=S.end_time)simResetState();playing=true;lastTs=0;document.getElementById('sim-play').textContent='⏸ 暂停';raf=requestAnimationFrame(tick);}
function simPause(){playing=false;document.getElementById('sim-play').textContent='▶ 继续';if(raf)cancelAnimationFrame(raf);}
function simResetState(){ct=S.start_time;processedIdx=0;lastLogIdx=0;Object.keys(mBusy).forEach(k=>mBusy[k]=null);document.getElementById('log-box').innerHTML='';}

document.getElementById('sim-play').onclick=()=>playing?simPause():simPlay();
document.getElementById('sim-reset').onclick=()=>{simPause();simResetState();document.getElementById('sim-play').textContent='▶ 开始';drawSim();simRecalc();simUpdateMGrid();};
document.querySelectorAll('.sp').forEach(b=>b.onclick=()=>{document.querySelectorAll('.sp').forEach(x=>x.classList.remove('on'));b.classList.add('on');speed=parseInt(b.dataset.s);});
slider.addEventListener('mousedown',()=>{isDragging=true;if(playing)simPause();});
slider.addEventListener('touchstart',()=>{isDragging=true;if(playing)simPause();},{passive:true});
slider.addEventListener('input',()=>{ct=S.start_time+S.total_duration*(slider.value/1000);lastLogIdx=0;document.getElementById('log-box').innerHTML='';simRecalc();drawSim();});
document.addEventListener('mouseup',()=>{isDragging=false;});
document.addEventListener('touchend',()=>{isDragging=false;});
document.addEventListener('keydown',e=>{
    if(e.code==='Space'&&document.getElementById('sim-page').classList.contains('active')){e.preventDefault();playing?simPause():simPlay();}
});

initSim();
</script>
</body>
</html>'''


if __name__ == "__main__":
    from work_calendar import create_two_shift_calendar
    cal = create_two_shift_calendar()
    orders = parse_orders_from_csv('../orders.csv')
    generate_combined_html('../orders.csv', '../combined.html', cal)
    print("✅ 合并页面已生成: combined.html")
