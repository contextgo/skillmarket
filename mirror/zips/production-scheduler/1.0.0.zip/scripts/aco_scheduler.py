#!/usr/bin/env python3
"""
蚁群算法排程器 (ACO - Ant Colony Optimization)
优化目标：负载均衡（最小化各机器负荷差异）
"""

import random
import math
from dataclasses import dataclass
from typing import List, Dict, Tuple
from datetime import datetime, timedelta

from scheduler import WorkOrder, ProcessStep, ScheduledJob, DEFAULT_MACHINES
from work_calendar import WorkCalendar, calculate_work_end, get_next_available_time


@dataclass
class ACOConfig:
    """蚁群算法配置"""
    n_ants: int = 20          # 蚂蚁数量
    n_iterations: int = 50    # 迭代次数
    alpha: float = 1.0        # 信息素重要程度
    beta: float = 2.0         # 启发信息重要程度
    rho: float = 0.5          # 信息素挥发率
    q: float = 100.0          # 信息素常数


def calculate_makespan(jobs: List[ScheduledJob]) -> float:
    """计算完工时间 (makespan)"""
    if not jobs:
        return 0.0
    return max((j.end_time - min(j.start_time for j in jobs)).total_seconds() / 3600 
               for j in jobs)


def calculate_load_balance_score(jobs: List[ScheduledJob]) -> float:
    """
    计算负载均衡得分（越小越好）
    综合考虑：
    1. 机器负荷的标准差
    2. 最大机器负荷
    """
    from collections import defaultdict
    machine_loads = defaultdict(float)
    
    for job in jobs:
        duration = (job.end_time - job.start_time).total_seconds() / 3600
        machine_loads[job.machine_id] += duration
    
    if not machine_loads:
        return float('inf')
    
    loads = list(machine_loads.values())
    avg_load = sum(loads) / len(loads)
    
    # 标准差
    variance = sum((x - avg_load) ** 2 for x in loads) / len(loads)
    std_dev = math.sqrt(variance)
    
    # 最大负荷（惩罚最重机器）
    max_load = max(loads)
    
    # 综合得分：标准差 + 最大负荷 * 0.5
    return std_dev + max_load * 0.3


def schedule_greedy(orders: List[WorkOrder],
                   processes: List[ProcessStep],
                   machines: Dict[str, str],
                   calendar: WorkCalendar = None) -> List[ScheduledJob]:
    """
    贪婪算法排程（作为蚁群初始解）
    策略：每次选择当前负荷最小的机器
    """
    if calendar is None:
        from work_calendar import create_standard_calendar
        calendar = create_standard_calendar(work_start=0, work_end=23, work_days=list(range(7)))
    
    scheduled_jobs = []
    machine_status = {m: None for m in machines.keys()}
    machine_loads = {m: 0.0 for m in machines.keys()}
    
    for order in orders:
        arrival = datetime.strptime(order.arrival_time, "%Y-%m-%d %H:%M")
        
        for process in processes:
            best_machine = None
            best_start = None
            best_load = float('inf')
            
            for machine_id in process.machine_ids:
                machine_time = machine_status[machine_id]
                if machine_time is None:
                    machine_time = arrival
                # 考虑该机器的可用时间
                candidate = get_next_available_time(calendar, machine_time, machine_id)
                if candidate < arrival:
                    candidate = get_next_available_time(calendar, arrival, machine_id)
                
                future_load = machine_loads[machine_id]
                
                if future_load < best_load or (future_load == best_load and (best_start is None or candidate < best_start)):
                    best_load = future_load
                    best_machine = machine_id
                    best_start = candidate
            
            total_time = process.processing_time * order.quantity
            end = calculate_work_end(calendar, best_start, total_time, best_machine)
            
            job = ScheduledJob(
                order_id=order.order_id,
                product=order.product,
                quantity=order.quantity,
                step_id=process.step_id,
                step_name=process.step_name,
                machine_id=best_machine,
                machine_name=machines[best_machine],
                start_time=best_start,
                end_time=end
            )
            scheduled_jobs.append(job)
            
            duration = (end - best_start).total_seconds() / 3600
            machine_loads[best_machine] += duration
            machine_status[best_machine] = end
            arrival = end
    
    return scheduled_jobs


def schedule_aco(orders: List[WorkOrder],
                 processes: List[ProcessStep],
                 machines: Dict[str, str],
                 calendar: WorkCalendar = None,
                 config: ACOConfig = None) -> Tuple[List[ScheduledJob], float]:
    """
    蚁群算法排程
    
    返回: (最优排程方案, 最优得分)
    """
    if calendar is None:
        from work_calendar import create_standard_calendar
        calendar = create_standard_calendar(work_start=0, work_end=23, work_days=list(range(7)))
    
    if config is None:
        config = ACOConfig()
    
    n_orders = len(orders)
    n_processes = len(processes)
    
    # 初始化信息素矩阵
    # tau[i][j][k]: 第i个工单的第j个工序选择机器k的信息素浓度
    tau = {}
    for i in range(n_orders):
        tau[i] = {}
        for j in range(n_processes):
            process = processes[j]
            tau[i][j] = {m: 1.0 for m in process.machine_ids}
    
    best_solution = None
    best_score = float('inf')
    
    for iteration in range(config.n_iterations):
        solutions = []
        scores = []
        
        for ant in range(config.n_ants):
            solution = _build_solution(orders, processes, machines, calendar, tau, config)
            score = calculate_load_balance_score(solution)
            
            solutions.append(solution)
            scores.append(score)
            
            if score < best_score:
                best_score = score
                best_solution = solution[:]
        
        # 更新信息素
        _update_pheromone(tau, solutions, scores, config)
        
        # 打印进度
        if (iteration + 1) % 10 == 0:
            avg_score = sum(scores) / len(scores)
            print(f"  迭代 {iteration+1}/{config.n_iterations}: 最佳={best_score:.2f}, 平均={avg_score:.2f}")
    
    return best_solution, best_score


def _build_solution(orders: List[WorkOrder],
                   processes: List[ProcessStep],
                   machines: Dict[str, str],
                   calendar: WorkCalendar,
                   tau: Dict,
                   config: ACOConfig) -> List[ScheduledJob]:
    """构建一个蚂蚁的解"""
    
    # 随机打乱工单顺序（增加多样性）
    shuffled_indices = list(range(len(orders)))
    random.shuffle(shuffled_indices)
    
    scheduled_jobs = []
    machine_status = {m: None for m in machines.keys()}
    
    for idx in shuffled_indices:
        order = orders[idx]
        arrival = datetime.strptime(order.arrival_time, "%Y-%m-%d %H:%M")
        
        for p_idx, process in enumerate(processes):
            # 计算每台机器的选择概率
            candidates = []
            for machine_id in process.machine_ids:
                machine_time = machine_status[machine_id]
                if machine_time is None:
                    machine_time = arrival
                machine_time = get_next_available_time(calendar, machine_time, machine_id)
                if machine_time < arrival:
                    machine_time = get_next_available_time(calendar, arrival, machine_id)
                
                start = machine_time
                
                # 启发信息：越早完成越好
                total_time = process.processing_time * order.quantity
                end = calculate_work_end(calendar, start, total_time, machine_id)
                makespan = (end - arrival).total_seconds() / 3600
                
                # 信息素 * 启发信息^beta
                pheromone = tau[idx][p_idx][machine_id]
                heuristic = 1.0 / (1 + makespan)
                
                prob = (pheromone ** config.alpha) * (heuristic ** config.beta)
                candidates.append((machine_id, start, end, prob))
            
            # 轮盘赌选择机器
            total_prob = sum(c[3] for c in candidates)
            if total_prob == 0:
                selected = candidates[0]
            else:
                r = random.uniform(0, total_prob)
                cumsum = 0
                for c in candidates:
                    cumsum += c[3]
                    if r <= cumsum:
                        selected = c
                        break
                else:
                    selected = candidates[-1]
            
            machine_id, start, end = selected[0], selected[1], selected[2]
            
            job = ScheduledJob(
                order_id=order.order_id,
                product=order.product,
                quantity=order.quantity,
                step_id=process.step_id,
                step_name=process.step_name,
                machine_id=machine_id,
                machine_name=machines[machine_id],
                start_time=start,
                end_time=end
            )
            scheduled_jobs.append(job)
            
            machine_status[machine_id] = end
            arrival = end
    
    return scheduled_jobs


def _update_pheromone(tau: Dict,
                     solutions: List[List[ScheduledJob]],
                     scores: List[float],
                     config: ACOConfig):
    """更新信息素"""
    
    # 挥发
    for i in tau:
        for j in tau[i]:
            for m in tau[i][j]:
                tau[i][j][m] *= (1 - config.rho)
    
    # 增加
    for solution, score in zip(solutions, scores):
        if score == float('inf'):
            continue
        
        # 得分越低，信息素越多
        delta = config.q / (1 + score)
        
        # 找到每个工序的机器选择并增加信息素
        machine_map = {}
        for job in solution:
            key = (job.order_id, job.step_id)
            machine_map[key] = job.machine_id
        
        for (order_id, step_id), machine_id in machine_map.items():
            # 找到对应的索引（简化处理）
            for i in tau:
                for j in tau[i]:
                    if machine_id in tau[i][j]:
                        tau[i][j][machine_id] += delta


def compare_scheduling_methods(orders: List[WorkOrder],
                               processes: List[ProcessStep],
                               machines: Dict[str, str],
                               calendar: WorkCalendar = None):
    """对比不同排程方法的效果"""
    
    print("=" * 60)
    print("排程方法对比")
    print("=" * 60)
    
    # 1. FCFS
    from scheduler import schedule_fcfs
    fcfs_jobs = schedule_fcfs(orders, processes, machines, calendar)
    fcfs_balance = calculate_load_balance_score(fcfs_jobs)
    fcfs_makespan = calculate_makespan(fcfs_jobs)
    
    # 2. 贪婪（负载均衡）
    greedy_jobs = schedule_greedy(orders, processes, machines, calendar)
    greedy_balance = calculate_load_balance_score(greedy_jobs)
    greedy_makespan = calculate_makespan(greedy_jobs)
    
    # 3. 蚁群算法
    print("\n蚁群算法优化中...")
    aco_jobs, aco_balance = schedule_aco(orders, processes, machines, calendar)
    aco_makespan = calculate_makespan(aco_jobs)
    
    print("\n" + "=" * 60)
    print(f"{'方法':<15} {'负载均衡得分':<15} {'完工时间(h)':<15}")
    print("-" * 60)
    print(f"{'FCFS':<15} {fcfs_balance:<15.2f} {fcfs_makespan:<15.1f}")
    print(f"{'贪婪算法':<15} {greedy_balance:<15.2f} {greedy_makespan:<15.1f}")
    print(f"{'蚁群算法':<15} {aco_balance:<15.2f} {aco_makespan:<15.1f}")
    print("=" * 60)
    
    print("\n机器负荷分布（蚁群算法）:")
    from collections import defaultdict
    machine_loads = defaultdict(float)
    for job in aco_jobs:
        duration = (job.end_time - job.start_time).total_seconds() / 3600
        machine_loads[job.machine_name] += duration
    
    for name, load in sorted(machine_loads.items(), key=lambda x: -x[1]):
        print(f"  {name:10s}: {load:6.1f}h")
    
    return aco_jobs


if __name__ == "__main__":
    # 测试
    print("蚁群算法排程模块加载成功")
