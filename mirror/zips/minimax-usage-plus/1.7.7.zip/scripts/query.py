#!/usr/bin/env python3
"""Minimax Coding Plan 用量查询"""

from __future__ import annotations

import json, os, sys, ssl, time
from dataclasses import dataclass
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import URLError


API_URL = "https://www.minimaxi.com/v1/api/openplatform/coding_plan/remains"
ENV_FILE = Path.home() / ".minimax-usage.env"


@dataclass
class Model:
    name: str
    dt: int
    du: int
    dr: int
    dms: int
    wt: int
    wu: int
    wr: int
    wms: int


def load_credentials() -> tuple[str, str]:
    ak = os.getenv("MINIMAX_API_KEY")
    gi = os.getenv("MINIMAX_GROUP_ID")
    if not ak or not gi:
        if ENV_FILE.exists():
            for line in ENV_FILE.read_text().splitlines():
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if "=" in line:
                    k, v = line.split("=", 1)
                    if k == "MINIMAX_API_KEY":
                        ak = v.strip()
                    elif k == "MINIMAX_GROUP_ID":
                        gi = v.strip()
    if not ak or not gi:
        print("❌ 请配置 ~/.minimax-usage.env")
        sys.exit(1)
    return ak, gi


def fetch(api_key: str, group_id: str) -> list[Model]:
    req = Request(f"{API_URL}?GroupId={group_id}",
                  headers={"Authorization": f"Bearer {api_key}"}, method="GET")
    ctx = ssl._create_unverified_context()
    try:
        with urlopen(req, timeout=15, context=ctx) as resp:
            data = json.loads(resp.read().decode())
    except URLError as e:
        print(f"❌ 网络错误: {e}")
        sys.exit(1)
    if data.get("base_resp", {}).get("status_code") != 0:
        print("❌ API 错误")
        sys.exit(1)
    models = []
    for item in data.get("model_remains", []):
        dt = int(item["current_interval_total_count"] or 0)
        dr = int(item["current_interval_usage_count"] or 0)
        wt = int(item["current_weekly_total_count"] or 0)
        wr = int(item["current_weekly_usage_count"] or 0)
        models.append(Model(
            name=item["model_name"],
            dt=dt, dr=dr, du=dt - dr, dms=int(item.get("remains_time") or 0),
            wt=wt, wr=wr, wu=wt - wr, wms=int(item.get("weekly_remains_time") or 0),
        ))
    return models


def dur(ms: int) -> str:
    h = ms // 3600000
    m = (ms % 3600000) // 60000
    return f"{h}h{m}m" if h else f"{m}m"


def flag(p: int) -> str:
    return "🔴" if p >= 90 else "🟡" if p >= 60 else "🟢"


WINDOW = {"MiniMax-M*": "5h", "coding-plan-vlm": "5h",
          "coding-plan-search": "5h", "music-2.6": "日",
          "music-cover": "日", "lyrics_generation": "日"}


def pct(u: int, t: int) -> int:
    return round(u * 100 / t) if t else 0


def main() -> None:
    api_key, group_id = load_credentials()
    models = fetch(api_key, group_id)
    ts = time.strftime("%m/%d %H:%M")

    print(f"\n📊 Minimax Coding Plan  [{ts}]")
    print("─" * 54)

    # MiniMax-M* 主行
    m0 = next((m for m in models if m.name == "MiniMax-M*"), None)
    if m0 and (m0.wt > 0 or m0.dt > 0):
        dp = pct(m0.du, m0.dt)
        wp = pct(m0.wu, m0.wt)
        print(f"  🟢 {m0.name:<20} 5h  {m0.du:>3}/{m0.dt:<4} {dp:>3}%  {m0.dr:<4} {dur(m0.dms)}")
        print(f"     {'本周配额':<22}      {m0.wu:>4}/{m0.wt:<5} {wp:>3}%  {m0.wr:<4} {dur(m0.wms)}")
        print("─" * 54)

    # 次要模型
    sub = [m for m in models if m.name != "MiniMax-M*" and (m.wt > 0 or m.dt > 0)]
    for m in sub:
        w = WINDOW.get(m.name, "?")
        dp = pct(m.du, m.dt)
        print(f"  {flag(dp)} {m.name:<20} {w}  {m.du:>3}/{m.dt:<4} {dp:>3}%  {m.dr:<4} {dur(m.dms)}")

    print("─" * 54)


if __name__ == "__main__":
    main()
