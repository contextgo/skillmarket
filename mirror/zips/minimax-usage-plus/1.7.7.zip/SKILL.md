---
name: minimax-usage
description: 查询 Minimax Coding Plan 实时用量。显示本周/今日双窗口的已用、剩余、重置时间。当用户要求查询 Minimax 用量、查看 API 配额、检查 coding plan 剩余额度时使用。
---

# Minimax 用量查询

实时查询 Minimax Coding Plan 各模型的用量，支持本周 + 今日双窗口显示。

## 快速开始

### 1. 配置凭证

在 `~/.minimax-usage.env` 中写入：

```bash
MINIMAX_API_KEY=sk-cp-xxxxxxxxxxxx
MINIMAX_GROUP_ID=1234567890
```

获取地址：https://platform.minimaxi.com/user-center/basic-information

### 2. 运行查询

```bash
python3 ./scripts/query.py
```

## 输出示例

```
📊  Minimax Coding Plan 实时用量
═══════════════════════════════════════════════

  ┌─ MiniMax-M*
  │  5小时窗口: 171 / 600  (28%)  💚 OK
  │  剩余: 429  |  3小时26分钟 后重置
  │  ────
  │  本周配额: 1034 / 6000  (17%)
  │  剩余: 4966  |  132小时26分钟 后重置
  └─────────────────────────────────

  ┌─ coding-plan-vlm
  │  每日窗口: 0 / 60  (0%)  💚 OK
  │  剩余: 60  |  3小时26分钟 后重置
  └─────────────────────────────────
```

## 模型分组

| 分组 | 模型 | 窗口类型 |
|------|------|----------|
| 5小时 + 每周配额 | MiniMax-M* | 10:00-15:00 UTC+8 |
| 5小时窗口 | coding-plan-vlm, coding-plan-search | 10:00-15:00 UTC+8 |
| 每日窗口 | music-2.6, music-cover, lyrics_generation | 00:00-次日 00:00 UTC+8 |

## 关键陷阱

⚠️ **API 字段名误导**：`usage_count` 字段名看起来是"已用量"，实际存的是**剩余量**。

```python
# 计算公式
used = total - usage_count
```

## 技术规范

- **语言**: Python 3（遵循 PEP 8）
- **依赖**: 仅标准库（urllib、json、dataclasses、pathlib）
- **无第三方依赖**
- **类型提示**: dataclass + 函数注解
