---
name: "clash-vpn-linux"
description: "Install and configure Clash VPN for Linux with airport subscription. Invoke when user needs to set up Clash proxy on Linux system."
---

# Clash VPN for Linux 配置工具

用于在 **Linux 系统** 上快速安装和配置 Clash 代理客户端，支持机场订阅链接。

---

## 1. 安装 Clash

### 方法一：一键安装（推荐）
```bash
git clone --branch master --depth 1 https://github.com/nelvko/clash-for-linux-install.git \
  && cd clash-for-linux-install \
  && bash install.sh
```

### 方法二：压缩包安装（网络不好时使用）
```bash
# 下载压缩包
wget --no-check-certificate https://github.com/nelvko/clash-for-linux-install/archive/refs/heads/master.zip

# 解压
unzip master.zip
mv clash-for-linux-install-master clash-for-linux-install

# 安装
cd clash-for-linux-install
bash install.sh
```

---

## 2. 通过机场订阅链接配置 VPN

### 方式 A：安装前配置（推荐）
1. 编辑 `.env` 文件：
```bash
cd clash-for-linux-install
vim .env
```

2. 修改订阅链接配置：
```env
# 机场订阅
CLASH_CONFIG_URL=https://your-subscription-url.com
```

3. 运行安装脚本：
```bash
bash install.sh
```

### 方式 B：安装后添加订阅
```bash
# 加载环境变量
source ~/.bashrc

# 添加订阅
clashctl sub add <订阅链接>

# 查看订阅列表（获取ID）
clashctl sub ls

# 使用指定订阅
clashctl sub use <订阅ID>
```

### 常用订阅管理命令
```bash
# 查看所有订阅
clashctl sub ls

# 更新订阅
clashctl sub update <ID>

# 更新所有订阅
clashctl sub update

# 删除订阅
clashctl sub del <ID>

# 查看订阅日志
clashctl sub log
```

---

## 3. 基本用法与注意事项

### 基础命令
```bash
# 开启代理
clashctl on

# 关闭代理
clashctl off

# 查看运行状态
clashctl status

# 查看内核日志
clashctl log
```

### 系统代理设置
```bash
# 查看系统代理状态
clashctl proxy

# 开启系统代理
clashctl proxy on

# 关闭系统代理
clashctl proxy off
```

### Web 控制台
```bash
# 查看面板地址
clashctl ui

# 查看/重置 Web 密钥
clashctl secret
```

### 高级功能
```bash
# Tun 模式
clashctl tun

# Mixin 配置
clashctl mixin

# 升级内核
clashctl upgrade
```

### 注意事项
1. **环境变量**：每次打开新终端需执行 `source ~/.bashrc` 或重新登录
2. **端口冲突**：安装时如遇端口冲突，会自动分配随机端口
3. **订阅更新**：建议定期更新订阅以获取最新节点
4. **安装路径**：默认安装在 `~/clashctl` 目录
5. **防火墙**：确保 9090 端口（Web控制台）已放行

---

## 4. 连通性测试

### 基础测试
```bash
# 测试 Google 访问（HTTP状态码）
curl -I https://www.google.com

# 预期输出包含：HTTP/2 200
```

### 详细测试
```bash
# 测试连接速度
curl -o /dev/null -s -w "Speed: %{speed_download} bytes/s\nTime: %{time_total}s\n" https://www.google.com

# 查看当前IP
curl https://api.ipify.org

# 查看IP地理位置
curl ipinfo.io
```

### 故障排查
```bash
# 1. 检查 clash 是否运行
clashctl status

# 2. 检查代理环境变量
echo $http_proxy
echo $https_proxy

# 3. 查看内核日志
clashctl log

# 4. 重启代理
clashctl off
clashctl on
```

---

## 完整流程示例

```bash
# 1. 下载安装包
wget --no-check-certificate https://github.com/nelvko/clash-for-linux-install/archive/refs/heads/master.zip
unzip master.zip
mv clash-for-linux-install-master clash-for-linux-install

# 2. 配置订阅
cd clash-for-linux-install
vim .env  # 添加 CLASH_CONFIG_URL

# 3. 安装
bash install.sh

# 4. 加载环境并启动
source ~/.bashrc
clashctl on

# 5. 测试连通性
curl -I https://www.google.com
```
