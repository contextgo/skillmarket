#!/usr/bin/env python3
"""
错别字修正主脚本

在 Word 文档的修订模式下修正错别字，并为每处修改添加批注。
支持跨 w:r 元素的错别字精准匹配与修正。

用法:
    python typo_fixer.py <input_docx> <output_docx> --typos '[{"wrong":"按装","correct":"安装","reason":"同音错别字"}]'

    或通过 JSON 文件:
    python typo_fixer.py <input_docx> <output_docx> --typos-file typos.json
"""

import argparse
import json
import sys
import tempfile
from pathlib import Path

SKILL_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(SKILL_ROOT))

from ooxml.scripts.unpack import unpack_document
from ooxml.scripts.pack import pack_document
from scripts.document import Document


def _escape_xml(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _get_run_text(r_elem):
    text = ""
    for t_node in r_elem.getElementsByTagName("w:t"):
        for child in t_node.childNodes:
            if child.nodeType == child.TEXT_NODE:
                text += child.data
    return text


def _get_run_rpr(r_elem):
    rpr_nodes = r_elem.getElementsByTagName("w:rPr")
    if rpr_nodes:
        return rpr_nodes[0].toxml()
    return ""


def _collect_active_runs(paragraph_elem):
    runs = []
    full_text = ""

    for r_elem in paragraph_elem.getElementsByTagName("w:r"):
        parent = r_elem.parentNode
        inside_del = False
        while parent:
            if parent.nodeType == parent.ELEMENT_NODE and parent.tagName == "w:del":
                inside_del = True
                break
            parent = parent.parentNode

        if inside_del:
            continue

        if r_elem.getElementsByTagName("w:delText"):
            continue

        r_text = _get_run_text(r_elem)
        if not r_text:
            continue

        rpr = _get_run_rpr(r_elem)
        runs.append({
            'elem': r_elem,
            'text': r_text,
            'start': len(full_text),
            'rpr': rpr,
        })
        full_text += r_text

    return runs, full_text


def _find_and_fix_one(doc, wrong, correct, reason):
    document_editor = doc["word/document.xml"]
    paragraphs = list(document_editor.dom.getElementsByTagName("w:p"))

    for paragraph_elem in paragraphs:
        runs, full_text = _collect_active_runs(paragraph_elem)

        if not full_text:
            continue

        idx = full_text.find(wrong)
        if idx == -1:
            continue

        match_end = idx + len(wrong)

        first_run_idx = None
        last_run_idx = None
        for i, run in enumerate(runs):
            run_start = run['start']
            run_end = run_start + len(run['text'])
            if first_run_idx is None and run_start <= idx < run_end:
                first_run_idx = i
            if run_start < match_end <= run_end:
                last_run_idx = i

        if first_run_idx is None or last_run_idx is None:
            continue

        affected_runs = runs[first_run_idx:last_run_idx + 1]
        first_run = affected_runs[0]
        last_run = affected_runs[-1]

        common_parent = first_run['elem'].parentNode
        if not all(run['elem'].parentNode is common_parent for run in affected_runs):
            continue

        first_local_start = idx - first_run['start']
        last_local_end = match_end - last_run['start']

        parts = []

        before_text = first_run['text'][:first_local_start]

        if len(affected_runs) == 1:
            wrong_part = first_run['text'][first_local_start:last_local_end]
        else:
            wrong_part = None

        first_wrong_part = first_run['text'][first_local_start:] if len(affected_runs) > 1 else None

        if before_text:
            parts.append(f'<w:r>{first_run["rpr"]}<w:t xml:space="preserve">{_escape_xml(before_text)}</w:t></w:r>')

        if len(affected_runs) == 1 and wrong_part:
            parts.append(f'<w:del><w:r>{first_run["rpr"]}<w:delText>{_escape_xml(wrong_part)}</w:delText></w:r></w:del>')

        if len(affected_runs) > 1 and first_wrong_part:
            parts.append(f'<w:del><w:r>{first_run["rpr"]}<w:delText>{_escape_xml(first_wrong_part)}</w:delText></w:r></w:del>')

        for run in affected_runs[1:-1]:
            if run['text']:
                parts.append(f'<w:del><w:r>{run["rpr"]}<w:delText>{_escape_xml(run["text"])}</w:delText></w:r></w:del>')

        if len(affected_runs) > 1:
            last_wrong_part = last_run['text'][:last_local_end]
            if last_wrong_part:
                parts.append(f'<w:del><w:r>{last_run["rpr"]}<w:delText>{_escape_xml(last_wrong_part)}</w:delText></w:r></w:del>')

        parts.append(f'<w:ins><w:r>{first_run["rpr"]}<w:t>{_escape_xml(correct)}</w:t></w:r></w:ins>')

        after_text = last_run['text'][last_local_end:]
        if after_text:
            parts.append(f'<w:r>{last_run["rpr"]}<w:t xml:space="preserve">{_escape_xml(after_text)}</w:t></w:r>')

        replacement = "".join(parts)

        new_nodes = document_editor.replace_node(first_run['elem'], replacement)

        for run in affected_runs[1:]:
            run['elem'].parentNode.removeChild(run['elem'])

        comment_text = f'\u9519\u522b\u5b57\u4fee\u6b63\uff1a\u201c{wrong}\u201d\u2192\u201c{correct}\u201d'
        if reason:
            comment_text += f"\u3002\u539f\u56e0\uff1a{reason}"

        doc.add_comment(
            start=new_nodes[0],
            end=new_nodes[-1],
            text=comment_text
        )

        return True

    return False


def fix_typos(input_path: str, output_path: str, typos: list, author: str = "docx_typo_checker.skill"):
    input_path = Path(input_path)
    output_path = Path(output_path)

    if not input_path.exists():
        raise FileNotFoundError(f"输入文件不存在: {input_path}")

    with tempfile.TemporaryDirectory(prefix="typo_fix_") as temp_dir:
        unpacked_dir = Path(temp_dir) / "unpacked"

        print(f"正在解压 {input_path.name} ...")
        unpack_document(str(input_path), str(unpacked_dir))

        print(f"正在初始化文档编辑器 ...")
        doc = Document(
            str(unpacked_dir),
            track_revisions=True,
            author=author,
            initials="DC"
        )

        success_count = 0
        fail_count = 0
        results = []

        for i, typo in enumerate(typos):
            wrong = typo.get("wrong", "")
            correct = typo.get("correct", "")
            reason = typo.get("reason", "")

            if not wrong or not correct:
                print(f"  跳过无效条目 #{i+1}: wrong={wrong!r}, correct={correct!r}")
                fail_count += 1
                continue

            print(f'  \u5904\u7406 #{i+1}: \u201c{wrong}\u201d \u2192 \u201c{correct}\u201d')

            fixed_for_this = 0
            max_attempts = 50

            for attempt in range(max_attempts):
                if not _find_and_fix_one(doc, wrong, correct, reason):
                    break
                fixed_for_this += 1

            if fixed_for_this > 0:
                success_count += 1
                results.append({
                    "wrong": wrong,
                    "correct": correct,
                    "reason": reason,
                    "status": "success",
                    "occurrences": fixed_for_this
                })
                print(f"    \u2713 \u5df2\u4fee\u6b63 {fixed_for_this} \u5904\u5e76\u6dfb\u52a0\u6279\u6ce8")
            else:
                fail_count += 1
                results.append({
                    "wrong": wrong,
                    "correct": correct,
                    "reason": reason,
                    "status": "failed",
                    "error": "\u672a\u627e\u5230\u6587\u672c"
                })
                print(f"    \u2717 \u672a\u627e\u5230\u6587\u672c")

        print(f"正在保存修改 ...")
        doc.save()

        print(f"正在打包为 {output_path.name} ...")
        output_path.parent.mkdir(parents=True, exist_ok=True)
        pack_document(str(unpacked_dir), str(output_path), validate=False)

    summary = {
        "total": len(typos),
        "success": success_count,
        "failed": fail_count,
        "results": results
    }

    print(f"\n处理完成：共 {summary['total']} 处，成功 {success_count} 处，失败 {fail_count} 处")
    return summary


def extract_text_from_docx(input_path: str) -> str:
    try:
        from docx import Document as DocxDocument
        doc = DocxDocument(input_path)

        paragraphs = []
        for para in doc.paragraphs:
            text = para.text.strip()
            if text:
                paragraphs.append(text)

        for table in doc.tables:
            for row in table.rows:
                row_text = [cell.text.strip() for cell in row.cells]
                if any(row_text):
                    paragraphs.append(" | ".join(row_text))

        for section in doc.sections:
            for para in section.header.paragraphs:
                text = para.text.strip()
                if text:
                    paragraphs.append(f"[页眉] {text}")
            for para in section.footer.paragraphs:
                text = para.text.strip()
                if text:
                    paragraphs.append(f"[页脚] {text}")

        return "\n".join(paragraphs)
    except ImportError:
        print("警告：python-docx 未安装，尝试使用 pandoc")
        import subprocess
        try:
            result = subprocess.run(
                ["pandoc", input_path, "-t", "plain", "--wrap=none"],
                capture_output=True, text=True, timeout=30
            )
            if result.returncode == 0:
                return result.stdout
            else:
                raise RuntimeError(f"pandoc 失败: {result.stderr}")
        except FileNotFoundError:
            raise RuntimeError("需要 python-docx 或 pandoc 来提取文本")


def main():
    parser = argparse.ArgumentParser(description="错别字修正工具")
    parser.add_argument("input", help="输入 docx 文件路径")
    parser.add_argument("output", nargs="?", default=None, help="输出 docx 文件路径")
    parser.add_argument("--typos", help="错别字 JSON 字符串")
    parser.add_argument("--typos-file", help="错别字 JSON 文件路径")
    parser.add_argument("--author", default="docx_typo_checker.skill", help="修订作者名称")
    parser.add_argument("--extract-only", action="store_true", help="仅提取文本，不修正")

    args = parser.parse_args()

    if args.extract_only:
        text = extract_text_from_docx(args.input)
        print(text)
        return

    if not args.output:
        print("错误：修正模式需要指定输出文件路径")
        sys.exit(1)

    if args.typos:
        typos = json.loads(args.typos)
    elif args.typos_file:
        with open(args.typos_file, "r", encoding="utf-8") as f:
            typos = json.load(f)
    else:
        print("错误：请通过 --typos 或 --typos-file 提供错别字列表")
        sys.exit(1)

    result = fix_typos(args.input, args.output, typos, args.author)

    if result["failed"] > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
