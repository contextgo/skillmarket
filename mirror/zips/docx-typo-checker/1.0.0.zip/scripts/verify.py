#!/usr/bin/env python3
"""
内容完整性验证脚本

验证修正版 docx 文档的内容完整性，确保没有意外丢失原始内容。
必须在 typo_fixer.py 修正后、输出结果前执行。

用法:
    python verify.py <input_docx> <corrected_docx> <work_dir>
"""

import argparse
import os
import sys
from pathlib import Path

SKILL_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(SKILL_ROOT))

from ooxml.scripts.unpack import unpack_document
from defusedxml import minidom


def count_paragraphs(xml_path):
    with open(xml_path, 'r', encoding='utf-8') as f:
        dom = minidom.parse(f)
    return len(dom.getElementsByTagName('w:p'))


def is_inside_tag(elem, tag_name):
    parent = elem.parentNode
    while parent:
        if parent.nodeType == parent.ELEMENT_NODE and parent.tagName == tag_name:
            return True
        parent = parent.parentNode
    return False


def accept_all_changes_and_extract(xml_path):
    with open(xml_path, 'r', encoding='utf-8') as f:
        dom = minidom.parse(f)
    paras = dom.getElementsByTagName('w:p')
    result = []
    for para in paras:
        texts = []
        for t_elem in para.getElementsByTagName('w:t'):
            if is_inside_tag(t_elem, 'w:del'):
                continue
            for child in t_elem.childNodes:
                if child.nodeType == child.TEXT_NODE:
                    texts.append(child.data)
        text = ''.join(texts)
        if text.strip():
            result.append(text.strip())
    return result


def get_all_files(base_dir):
    files = set()
    for root, dirs, filenames in os.walk(base_dir):
        for f in filenames:
            rel = os.path.relpath(os.path.join(root, f), base_dir).replace('\\', '/')
            files.add(rel)
    return files


def verify(input_docx, corrected_docx, work_dir):
    work_dir = Path(work_dir)
    unpacked_original = work_dir / "unpacked_original"
    unpacked_corrected = work_dir / "unpacked_corrected"

    if not unpacked_original.exists():
        print(f"正在解压原始文档到 {unpacked_original} ...")
        unpack_document(str(input_docx), str(unpacked_original))
    else:
        print(f"原始文档已解压：{unpacked_original}")

    if not unpacked_corrected.exists():
        print(f"正在解压修正文档到 {unpacked_corrected} ...")
        unpack_document(str(corrected_docx), str(unpacked_corrected))
    else:
        print(f"修正文档已解压：{unpacked_corrected}")

    orig_xml = unpacked_original / "word" / "document.xml"
    corr_xml = unpacked_corrected / "word" / "document.xml"

    all_pass = True

    print("\n===== 1. 段落数量验证 =====")
    orig_count = count_paragraphs(str(orig_xml))
    corr_count = count_paragraphs(str(corr_xml))

    if orig_count != corr_count:
        print(f"❌ 验证失败：段落数量不一致！原始={orig_count}, 修正={corr_count}")
        all_pass = False
    else:
        print(f"✅ 段落数量验证通过：{orig_count} 段")

    print("\n===== 2. 模拟接受修订验证 =====")
    orig_text = accept_all_changes_and_extract(str(orig_xml))
    corr_text = accept_all_changes_and_extract(str(corr_xml))

    if len(orig_text) != len(corr_text):
        print(f"❌ 验证失败：段落数不一致！原始={len(orig_text)}, 修正={len(corr_text)}")
        all_pass = False

    diff_count = 0
    for i, (o, c) in enumerate(zip(orig_text, corr_text)):
        if o != c:
            diff_count += 1
            print(f"段落 {i+1} 有差异（预期为错别字修正）:")
            print(f"  原始: {o}")
            print(f"  修正: {c}")

    if all_pass and len(orig_text) == len(corr_text):
        if diff_count > 0:
            print(f"✅ 模拟接受修订验证通过：共 {diff_count} 处差异，均为预期错别字修正")
        else:
            print("✅ 模拟接受修订验证通过：无差异")

    print("\n===== 3. 文件结构验证 =====")
    orig_files = get_all_files(str(unpacked_original))
    corr_files = get_all_files(str(unpacked_corrected))

    missing = orig_files - corr_files
    if missing:
        print(f"❌ 验证失败：修正版缺少以下文件: {sorted(missing)}")
        all_pass = False
    else:
        print("✅ 文件结构验证通过：原始文件全部保留")

    added = corr_files - orig_files
    expected_new = {
        'word/comments.xml',
        'word/commentsExtended.xml',
        'word/commentsIds.xml',
        'word/commentsExtensible.xml',
        'word/people.xml',
    }
    unexpected_new = added - expected_new
    if unexpected_new:
        print(f"⚠️ 修正版包含非预期新增文件: {sorted(unexpected_new)}")
    else:
        print("✅ 新增文件验证通过：仅添加了预期的批注相关文件")

    print("\n===== 验证总结 =====")
    if all_pass:
        print("✅ 所有验证项通过，文档内容完整")
        return 0
    else:
        print("❌ 存在验证失败项，请排查原因后修正")
        return 1


def main():
    parser = argparse.ArgumentParser(description="docx 修正内容完整性验证")
    parser.add_argument("input_docx", help="原始 docx 文件路径")
    parser.add_argument("corrected_docx", help="修正后 docx 文件路径")
    parser.add_argument("work_dir", help="工作文件夹路径（用于存放解压内容）")
    args = parser.parse_args()

    sys.exit(verify(args.input_docx, args.corrected_docx, args.work_dir))


if __name__ == "__main__":
    main()
