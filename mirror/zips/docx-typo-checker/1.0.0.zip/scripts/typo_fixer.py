#!/usr/bin/env python3
"""
错别字修正主脚本

在 Word 文档的修订模式下修正错别字，并为每处修改添加批注。

用法:
    python typo_fixer.py <input_docx> <output_docx> --typos '[{"wrong":"按装","correct":"安装","reason":"同音错别字"}]'

    或通过 JSON 文件:
    python typo_fixer.py <input_docx> <output_docx> --typos-file typos.json
"""

import argparse
import json
import sys
import tempfile
from pathlib import Path

SKILL_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(SKILL_ROOT))

from ooxml.scripts.unpack import unpack_document
from ooxml.scripts.pack import pack_document
from scripts.document import Document


def fix_typos(input_path: str, output_path: str, typos: list, author: str = "docx_typo_checker.skill"):
    """
    在 Word 文档中修正错别字。

    Args:
        input_path: 输入 docx 文件路径
        output_path: 输出 docx 文件路径
        typos: 错别字列表，每项包含 wrong, correct, reason
        author: 修订作者名称

    Returns:
        dict: 处理结果统计
    """
    input_path = Path(input_path)
    output_path = Path(output_path)

    if not input_path.exists():
        raise FileNotFoundError(f"输入文件不存在: {input_path}")

    with tempfile.TemporaryDirectory(prefix="typo_fix_") as temp_dir:
        unpacked_dir = Path(temp_dir) / "unpacked"

        print(f"正在解压 {input_path.name} ...")
        unpack_document(str(input_path), str(unpacked_dir))

        print(f"正在初始化文档编辑器 ...")
        doc = Document(
            str(unpacked_dir),
            track_revisions=True,
            author=author,
            initials="DC"
        )

        success_count = 0
        fail_count = 0
        results = []

        for i, typo in enumerate(typos):
            wrong = typo.get("wrong", "")
            correct = typo.get("correct", "")
            reason = typo.get("reason", "")

            if not wrong or not correct:
                print(f"  跳过无效条目 #{i+1}: wrong={wrong!r}, correct={correct!r}")
                fail_count += 1
                continue

            print(f'  \u5904\u7406 #{i+1}: \u201c{wrong}\u201d \u2192 \u201c{correct}\u201d')

            fixed_for_this = 0
            max_attempts = 50

            for attempt in range(max_attempts):
                found_node = None
                for elem in doc["word/document.xml"].dom.getElementsByTagName("w:r"):
                    parent = elem.parentNode
                    while parent:
                        if parent.nodeType == parent.ELEMENT_NODE and parent.tagName == "w:del":
                            break
                        parent = parent.parentNode
                    else:
                        has_del_text = bool(elem.getElementsByTagName("w:delText"))
                        if has_del_text:
                            continue
                        elem_text = doc["word/document.xml"]._get_element_text(elem)
                        if wrong in elem_text:
                            found_node = elem
                            break

                if found_node is None:
                    break

                node = found_node

                rpr = ""
                rpr_nodes = node.getElementsByTagName("w:rPr")
                if rpr_nodes:
                    rpr = rpr_nodes[0].toxml()

                t_nodes = node.getElementsByTagName("w:t")
                full_text = ""
                for t_node in t_nodes:
                    for child in t_node.childNodes:
                        if child.nodeType == child.TEXT_NODE:
                            full_text += child.data

                idx = full_text.find(wrong)
                if idx == -1:
                    break

                before_text = full_text[:idx]
                after_text = full_text[idx + len(wrong):]

                def escape_xml(s):
                    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

                parts = []
                if before_text:
                    parts.append(f'<w:r>{rpr}<w:t xml:space="preserve">{escape_xml(before_text)}</w:t></w:r>')
                parts.append(f'<w:del><w:r>{rpr}<w:delText>{escape_xml(wrong)}</w:delText></w:r></w:del>')
                parts.append(f'<w:ins><w:r>{rpr}<w:t>{escape_xml(correct)}</w:t></w:r></w:ins>')
                if after_text:
                    parts.append(f'<w:r>{rpr}<w:t xml:space="preserve">{escape_xml(after_text)}</w:t></w:r>')

                replacement = "".join(parts)

                new_nodes = doc["word/document.xml"].replace_node(node, replacement)

                comment_text = f'\u9519\u522b\u5b57\u4fee\u6b63\uff1a\u201c{wrong}\u201d\u2192\u201c{correct}\u201d'
                if reason:
                    comment_text += f"\u3002\u539f\u56e0\uff1a{reason}"

                doc.add_comment(
                    start=new_nodes[0],
                    end=new_nodes[-1],
                    text=comment_text
                )

                fixed_for_this += 1

            if fixed_for_this > 0:
                success_count += 1
                results.append({
                    "wrong": wrong,
                    "correct": correct,
                    "reason": reason,
                    "status": "success",
                    "occurrences": fixed_for_this
                })
                print(f"    \u2713 \u5df2\u4fee\u6b63 {fixed_for_this} \u5904\u5e76\u6dfb\u52a0\u6279\u6ce8")
            else:
                fail_count += 1
                results.append({
                    "wrong": wrong,
                    "correct": correct,
                    "reason": reason,
                    "status": "failed",
                    "error": "\u672a\u627e\u5230\u6587\u672c"
                })
                print(f"    \u2717 \u672a\u627e\u5230\u6587\u672c")

        print(f"正在保存修改 ...")
        doc.save()

        print(f"正在打包为 {output_path.name} ...")
        output_path.parent.mkdir(parents=True, exist_ok=True)
        pack_document(str(unpacked_dir), str(output_path), validate=False)

    summary = {
        "total": len(typos),
        "success": success_count,
        "failed": fail_count,
        "results": results
    }

    print(f"\n处理完成：共 {summary['total']} 处，成功 {success_count} 处，失败 {fail_count} 处")
    return summary


def extract_text_from_docx(input_path: str) -> str:
    """
    从 docx 文件提取纯文本，供 AI 分析用。

    Args:
        input_path: docx 文件路径

    Returns:
        str: 提取的文本内容
    """
    try:
        from docx import Document as DocxDocument
        doc = DocxDocument(input_path)

        paragraphs = []
        for para in doc.paragraphs:
            text = para.text.strip()
            if text:
                paragraphs.append(text)

        for table in doc.tables:
            for row in table.rows:
                row_text = [cell.text.strip() for cell in row.cells]
                if any(row_text):
                    paragraphs.append(" | ".join(row_text))

        for section in doc.sections:
            for para in section.header.paragraphs:
                text = para.text.strip()
                if text:
                    paragraphs.append(f"[页眉] {text}")
            for para in section.footer.paragraphs:
                text = para.text.strip()
                if text:
                    paragraphs.append(f"[页脚] {text}")

        return "\n".join(paragraphs)
    except ImportError:
        print("警告：python-docx 未安装，尝试使用 pandoc")
        import subprocess
        try:
            result = subprocess.run(
                ["pandoc", input_path, "-t", "plain", "--wrap=none"],
                capture_output=True, text=True, timeout=30
            )
            if result.returncode == 0:
                return result.stdout
            else:
                raise RuntimeError(f"pandoc 失败: {result.stderr}")
        except FileNotFoundError:
            raise RuntimeError("需要 python-docx 或 pandoc 来提取文本")


def main():
    parser = argparse.ArgumentParser(description="错别字修正工具")
    parser.add_argument("input", help="输入 docx 文件路径")
    parser.add_argument("output", nargs="?", default=None, help="输出 docx 文件路径")
    parser.add_argument("--typos", help="错别字 JSON 字符串")
    parser.add_argument("--typos-file", help="错别字 JSON 文件路径")
    parser.add_argument("--author", default="docx_typo_checker.skill", help="修订作者名称")
    parser.add_argument("--extract-only", action="store_true", help="仅提取文本，不修正")

    args = parser.parse_args()

    if args.extract_only:
        text = extract_text_from_docx(args.input)
        print(text)
        return

    if not args.output:
        print("错误：修正模式需要指定输出文件路径")
        sys.exit(1)

    if args.typos:
        typos = json.loads(args.typos)
    elif args.typos_file:
        with open(args.typos_file, "r", encoding="utf-8") as f:
            typos = json.load(f)
    else:
        print("错误：请通过 --typos 或 --typos-file 提供错别字列表")
        sys.exit(1)

    result = fix_typos(args.input, args.output, typos, args.author)

    if result["failed"] > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
