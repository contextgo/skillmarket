---
name: docx_typo_checker
description: |
  检查中文 docx 文件中的错别字，在修订模式下修正错误并添加批注说明。Invoke when user asks to check typos, proofread, or correct misspellings in a Word document.
---

# Typo Checker - 错别字检查与修订

AI 辅助检查 Word 文档（.docx）中的错别字，在修订模式下自动修正并添加批注说明。

## 功能特性

| 功能 | 说明 |
|:---|:---|
| **错别字检测** | AI 识别文档中的错别字、别字、漏字、多字 |
| **修订模式修正** | 使用 Word 原生修订追踪（tracked changes）标记修改 |
| **批注说明** | 为每处修改添加批注，说明错误原因和修改依据 |
| **保留原格式** | 保留原文档的所有格式、样式和排版 |

## ⛔ 关键禁止事项（开始前必读）

> **以下行为会导致输出文档内容丢失或损坏，严格禁止：**

1. **⛔ 禁止自行编写修正脚本**：必须使用本 skill 提供的 `typo_fixer.py` 进行修正（见第四步）。自行编写脚本调用 `Document` 类的 `get_node` + `replace_node` 会导致**严重内容丢失**——`replace_node` 会替换整个 `w:r` 节点，如果该节点包含除错别字外的其他文本，这些文本将全部丢失。
2. **⛔ 禁止跳过验证步骤**：第五步的内容完整性验证是**强制性的**，不得跳过。未通过验证的文档**禁止**输出给用户。
3. **⛔ 禁止在终端中直接执行多行 Python 代码**：本 skill 已提供 `typo_fixer.py`（含 `--extract-only` 文本提取功能）和 `verify.py`（验证功能），**必须直接调用这些脚本**，禁止将多行 Python 代码粘贴到终端执行。多行 Python 代码在 PowerShell 的 `python -c` 中极易因引号嵌套、分号分隔、for/if 语句等导致语法错误。
4. **⛔ 禁止直接调用 `Document` 类的 `get_node` + `replace_node` 修正错别字**：`replace_node` 会替换整个 `w:r` 节点，如果该节点包含除错别字外的其他文本，这些文本将全部丢失。必须使用 `typo_fixer.py`（见第四步），其内部已正确处理文本拆分逻辑。
5. **⛔ 禁止在 skill 目录内创建工作文件夹**：工作文件夹**必须**创建在输入 docx 文件所在目录下，**禁止**在 `.trae/skills/docx_typo_checker/` 目录内创建。所有路径**必须**使用绝对路径 `<work_dir>`，**禁止**使用相对路径，因为不同命令的当前工作目录（cwd）可能不同，相对路径会导致在错误位置创建文件夹。

## 路径变量说明

本工作流程使用以下路径变量，请在开始前明确它们的值：

| 变量 | 含义 | 示例 |
|:---|:---|:---|
| `<skill_root>` | 本 skill 的根目录（包含 `scripts/` 和 `ooxml/` 的目录） | `D:\path\to\.trae\skills\docx_typo_checker` |
| `<input_docx>` | 输入 docx 文件的**绝对路径** | `D:\docs\测试文件.docx` |
| `<input_dir>` | 输入 docx 文件所在目录的**绝对路径** | `D:\docs` |
| `<timestamp>` | 第一步获取的本地时间戳 | `20260424_153025` |
| `<work_dir>` | 工作文件夹的**绝对路径** | `D:\docs\docx_typo_check_20260424_153025` |

> ⚠️ **所有路径必须使用绝对路径**。Windows 路径中的反斜杠 `\` 在 Python 中是转义字符，在命令行参数中直接使用原始路径即可（如 `D:\docs\file.docx`），**不要**手动添加额外转义。

## 工作流程

### 第一步：获取时间戳并创建工作文件夹

在开始任何操作之前，**必须先执行以下命令**获取当前本地时间戳：

```bash
python -c "from datetime import datetime; print(datetime.now().astimezone().strftime('%Y%m%d_%H%M%S'))"
```

将输出的时间戳记为 `<timestamp>`（例如输出 `20260424_153025`，则 `<timestamp>` = `20260424_153025`）。

> ⚠️ **必须实际执行此命令**，不得自行编造或猜测时间戳。禁止使用 `20260424_120000` 等占位时间戳。

然后定义工作文件夹路径。工作文件夹**必须**创建在输入 docx 文件所在的目录下，使用**绝对路径**：

- `<work_dir>` = `<input_dir>\docx_typo_check_<timestamp>`（如 `D:\docs\docx_typo_check_20260424_153025`）

> ⛔ **工作文件夹位置禁止事项**：
> - **禁止**在 skill 目录（`.trae/skills/docx_typo_checker/`）内创建工作文件夹
> - **禁止**使用相对路径（如 `docx_typo_check_<timestamp>/unpacked`），必须使用绝对路径（如 `<work_dir>\unpacked`）
> - 后续所有步骤中的路径**必须**使用 `<work_dir>` 绝对路径前缀

创建工作文件夹：

```bash
mkdir "<work_dir>"
```

后续步骤中除最终修正版 docx 外的所有中间产物都放在 `<work_dir>` 下。

### 第二步：提取文档文本

使用本 skill 提供的 `typo_fixer.py` 脚本提取 docx 文件的文本内容：

```bash
python "<skill_root>\scripts\typo_fixer.py" "<input_docx>" --extract-only > "<work_dir>\extracted_text.txt"
```

> ⚠️ **禁止**使用 `python -c` 执行多行 Python 代码来提取文本，也**禁止**将提取代码保存为独立的 `.py` 文件。`typo_fixer.py` 已内置 `--extract-only` 参数，直接调用即可。

> ⚠️ **文本提取完整性注意**：python-docx 的 `doc.paragraphs` 和 `doc.tables` 只能提取正文内容，**无法提取**文本框、形状、脚注、尾注中的文字。如果文档包含这些元素，应提醒用户可能存在未检查到的区域。

### 第三步：AI 识别错别字

仔细阅读提取的文本，逐段检查以下类型的错误：

1. **同音错别字**：如"按装"→"安装"、"帐号"→"账号"
2. **形近错别字**：如"己经"→"已经"、"拔涉"→"跋涉"
3. **常见别字**：如"做贡献"→"作贡献"、"交代"→"交待"（视语境）
4. **漏字/多字**：如缺少"的"、"了"等助词
5. **成语错字**：如"按步就班"→"按部就班"、"一愁莫展"→"一筹莫展"

将发现的错别字整理为 JSON 格式，并保存为文件：

```json
[
  {
    "wrong": "按装",
    "correct": "安装",
    "reason": "同音错别字，'安'为正确写法",
    "context": "设备按装完毕"
  },
  {
    "wrong": "己经",
    "correct": "已经",
    "reason": "形近错别字，'已'为正确写法",
    "context": "己经完成验收"
  }
]
```

> ⚠️ **文件命名规则（必须严格遵守）**：将错别字列表保存为 JSON 文件时，文件必须放在工作文件夹 `<work_dir>` 下，文件名为 `typos_<timestamp>.json`，其中 `<timestamp>` 为第一步中实际执行命令获取的本地时间戳。**禁止自行编造时间戳**，**禁止使用** `typos.json`、`typos_to_fix.json` 等无时间戳的文件名。

### 第四步：在修订模式下修正错别字

使用本 skill 提供的 `typo_fixer.py` 脚本进行修正。该脚本会自动处理文本拆分、修订追踪标记和批注添加，不会丢失任何内容。

> ⛔ **再次强调：必须使用 `typo_fixer.py`，禁止自行编写修正脚本。** 自行编写脚本调用 `Document` 类的 `get_node` + `replace_node` 会导致严重内容丢失，因为 `replace_node` 会替换整个 `w:r` 节点，而一个 `w:r` 节点可能包含除错别字外的其他文本，这些文本会随节点替换而丢失。`typo_fixer.py` 内部已正确处理了文本拆分逻辑（将 `w:r` 中的文本拆分为"错别字前文本 + 删除标记 + 插入标记 + 错别字后文本"），不会丢失任何内容。

#### 4.1 使用 typo_fixer.py 修正错别字（唯一正确方式）

**方式一：通过 JSON 文件传入错别字列表（推荐）**

```bash
python "<skill_root>\scripts\typo_fixer.py" "<input_docx>" "<input_dir>\原文件名_CheckOut_<timestamp>.docx" --typos-file "<work_dir>\typos_<timestamp>.json"
```

**方式二：通过命令行参数传入错别字 JSON 字符串**

```bash
python "<skill_root>\scripts\typo_fixer.py" "<input_docx>" "<input_dir>\原文件名_CheckOut_<timestamp>.docx" --typos '[{"wrong":"按装","correct":"安装","reason":"同音错别字"}]'
```

> ⚠️ **Windows PowerShell 环境注意事项**：
> - **禁止**使用 `PYTHONPATH=<skill_root> python -m ...` 的 bash 语法设置环境变量，PowerShell 不支持此语法
> - **必须**使用 `python "<skill_root>\scripts\typo_fixer.py"` 直接调用脚本，脚本内部已自动处理 `sys.path`
> - 如果必须设置 PYTHONPATH，PowerShell 语法为 `$env:PYTHONPATH="<skill_root>"; python -m ...`

脚本执行后会输出处理统计信息，包括成功和失败的修正数量。请关注输出中的 `✗ 未找到文本` 条目，这些表示在文档中未找到对应的错别字文本。

> ⚠️ **如果修正失败数量大于 0**，需要检查原因：可能是错别字文本在文档中不存在（AI 误判），或文本跨越了多个 `w:r` 元素。对于后一种情况，`typo_fixer.py` 已内置处理逻辑，通常不会出现此问题。

#### 4.2 输出文件命名规则

> ⚠️ **文件命名规则（必须严格遵守）**：输出 docx 文件名必须为 `原文件名_CheckOut_<timestamp>.docx`，其中 `<timestamp>` 为第一步中实际执行命令获取的本地时间戳。此文件放在输入文件同目录下，**不放入**工作文件夹。**禁止自行编造时间戳**，**禁止使用** `原文件名_CheckOut.docx` 等无时间戳的文件名。

### 第五步：内容完整性验证（强制性）

> ⛔ **本步骤为强制性步骤，不得跳过。** 未通过验证的文档**禁止**输出给用户。如果验证失败，必须排查原因并修正后重新执行第四步和第五步。

使用本 skill 提供的 `verify.py` 脚本进行验证：

```bash
python "<skill_root>\scripts\verify.py" "<input_docx>" "<input_dir>\原文件名_CheckOut_<timestamp>.docx" "<work_dir>"
```

该脚本会自动执行以下三项验证：

1. **段落数量验证**：对比原始文档与修正文档的段落数量，确保一致
2. **模拟接受修订验证**：模拟"接受所有修订"，确认只有预期的错别字被修改，没有其他内容丢失
3. **文件结构验证**：确保修正文档保留了原始文档的所有文件，仅新增批注相关文件

> ⚠️ **禁止**使用 `python -c` 执行多行 Python 代码来验证，也**禁止**将验证代码保存为独立的 `.py` 文件。`verify.py` 已封装全部验证逻辑，直接调用即可。

> ⛔ **如果任何验证项未通过（输出 ❌），必须排查原因并修正后再继续**，不得向用户输出有内容缺失的文档。常见原因：使用了自行编写的修正脚本而非 `typo_fixer.py`，导致 `w:r` 节点被整体替换而丢失非错别字文本。

### 第六步：输出结果

向用户报告检查结果：

```
📋 错别字检查完成

检查文件：xxx.docx
发现问题：5 处

【修正清单】
1. "按装" → "安装"（同音错别字）
2. "己经" → "已经"（形近错别字）
3. "按步就班" → "按部就班"（成语错字）
4. "帐号" → "账号"（常见别字）
5. "拔涉" → "跋涉"（形近错别字）

已生成修订版文档：xxx_CheckOut_<timestamp>.docx
- 所有修改均以修订模式标记，可在 Word 中逐一接受/拒绝
- 每处修改附有批注说明
- 中间文件保存在：<work_dir>
```

## 重要规则

1. **只修改确定的错别字**：不确定的用词差异不要修改，可在批注中提出建议
2. **保留原格式**：替换文本时必须保留原 run 的 rPr（格式属性）
3. **最小化修改**：只标记实际更改的文本，未更改的文本不要放入 `<w:del>`/`<w:ins>` 标签
4. **每个修改都要有批注**：说明错别字类型和修改原因
5. **修订追踪规范**：
   - 删除文本使用 `<w:del>` + `<w:delText>`
   - 插入文本使用 `<w:ins>` + `<w:t>`
   - RSID 必须是 8 位十六进制（如 `00AB1234`）
6. **启用修订模式**：在 settings.xml 中添加 `<w:trackRevisions/>`
7. **⚠️ 文件命名必须带本地时间戳（严格遵守）**：
   - 在工作流开始前，**必须先执行** `python -c "from datetime import datetime; print(datetime.now().astimezone().strftime('%Y%m%d_%H%M%S'))"` 获取真实本地时间戳，记为 `<timestamp>`
   - 工作文件夹**必须**命名为 `docx_typo_check_<timestamp>`（如 `docx_typo_check_20260424_153025`），创建在输入 docx 文件所在目录下，使用绝对路径 `<work_dir>`
   - 中间产出的错别字 JSON 文件**必须**放在 `<work_dir>` 下，命名为 `typos_<timestamp>.json`。**禁止自行编造时间戳**，**禁止**使用 `typos.json`、`typos_to_fix.json` 等无时间戳的文件名
   - 最终产出的修正版 docx 文件**必须**命名为 `原文件名_CheckOut_<timestamp>.docx`，放在输入文件同目录下，**不放入**工作文件夹。**禁止自行编造时间戳**，**禁止**使用 `原文件名_CheckOut.docx` 等无时间戳的文件名
8. **⚠️ 工作文件夹管理**：
   - 所有中间产物（提取的文本、typos JSON、解压的 docx 内容等）**必须**放在 `<work_dir>` 下
   - 最终修正版 docx 文件**不放入**工作文件夹，放在输入文件同目录下
   - **⛔ 工作文件夹必须创建在输入 docx 文件所在目录下**，**禁止**在 skill 目录（`.trae/skills/docx_typo_checker/`）内创建工作文件夹
   - **⛔ 所有路径必须使用绝对路径**（基于 `<work_dir>`），**禁止**使用相对路径（如 `docx_typo_check_<timestamp>/unpacked`），因为相对路径依赖于当前工作目录，不同命令的 cwd 可能不同，会导致在错误位置创建文件夹
9. **⛔ 必须使用 typo_fixer.py 进行修正**：
   - 本 skill 提供的 `typo_fixer.py` 已正确处理文本拆分逻辑，不会丢失内容
   - **禁止**自行编写修正脚本调用 `Document` 类的 `get_node` + `replace_node`，这会导致整个 `w:r` 节点被替换，丢失节点中除错别字外的所有文本
10. **⛔ 禁止在终端中直接执行多行 Python 代码**：
    - 本 skill 已提供 `typo_fixer.py`（含 `--extract-only` 文本提取功能）和 `verify.py`（验证功能），**必须直接调用这些脚本**
    - **禁止**使用 `python -c` 执行多行 Python 代码（含 for 循环、if 语句、函数定义等），PowerShell 的引号嵌套和语句分隔规则与 bash 不同，极易导致语法错误
    - **禁止**将多行 Python 代码保存为独立的 `.py` 文件放在项目目录中
    - 所有功能应通过调用 skill 提供的脚本实现
11. **⛔ 验证步骤为强制性**：
    - 必须使用 `verify.py` 脚本执行第五步的三项验证（段落数量、模拟接受修订、文件结构）
    - 任何验证项未通过时，**禁止**向用户输出文档，必须排查原因并修正
12. **⚠️ Windows PowerShell 环境兼容性**：
    - **禁止**使用 bash 语法 `PYTHONPATH=xxx python -m ...` 设置环境变量，PowerShell 不支持此语法
    - **必须**使用 `python "<skill_root>\scripts\脚本名.py"` 直接调用脚本，脚本内部已自动处理 `sys.path`
    - Windows 路径中的反斜杠 `\` 在命令行参数中直接使用即可，**不要**手动添加额外转义

## 技术架构

```
docx_typo_checker/
├── SKILL.md                          # 本文件
├── scripts/
│   ├── __init__.py
│   ├── document.py                   # Document 类（OOXML 编辑）
│   ├── utilities.py                  # XMLEditor 基类
│   ├── typo_fixer.py                 # 错别字修正主脚本（必须使用此脚本）
│   │                                 #   --extract-only: 提取文本（第二步）
│   │                                 #   --typos-file: 通过 JSON 文件修正（第四步）
│   │                                 #   --typos: 通过命令行 JSON 修正（第四步）
│   ├── verify.py                     # 内容完整性验证脚本（第五步）
│   └── templates/                    # 批注相关 XML 模板
│       ├── comments.xml
│       ├── commentsExtended.xml
│       ├── commentsIds.xml
│       ├── commentsExtensible.xml
│       └── people.xml
├── ooxml/
│   └── scripts/
│       ├── unpack.py                 # docx 解压
│       ├── pack.py                   # docx 打包
│       └── validation/              # 验证工具
│           ├── __init__.py
│           ├── base.py
│           ├── docx.py
│           └── redlining.py
└── requirements.txt
```

## 依赖

- Python 3.10+
- defusedxml
- lxml
- python-docx（用于文本提取）
