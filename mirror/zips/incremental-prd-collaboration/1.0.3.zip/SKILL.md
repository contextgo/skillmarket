---
name: incremental-prd-collaboration
description: 当用户要开始写需求、撰写 PRD、把功能想法整理成需求文档，或通过逐轮提问来梳理产品需求时使用。适合一次问一个或几个关键问题，但不要过多，并尽早起草 V0.1 PRD；当需要补 PRD 结构、范围取舍、访谈提炼或下游交接时也可按需加载对应参考资料。
---

# 渐进式 PRD 协作

## 概述

把 PRD 协作当作一次需求访谈，而不是填表。优先一次问一个关键问题；如果确实有必要，也可以一次问几个关键问题，但不要过多。尽早起草，再逐步迭代。PRD 要始终聚焦产品表达：说明业务意图、规则、状态、文案和验收标准，但不要默认滑向 API、字段类型或后端实现细节。

当用户明显进入需求梳理阶段时，即使没有明确说出 `开始写 PRD`，这个 skill 也应该自动触发。

这是一个“主流程 + 按需方法参考”的 skill：

- `SKILL.md` 负责需求协作主流程
- `references/` 负责按需加载的 PM 方法，不要在每次触发时全部展开

## 核心流程

1. 识别需求意图。
   当用户想开始做需求、写 PRD、把功能想法整理成需求文档，或使用类似表达时触发，例如：
   - 开始写 PRD
   - 帮我写需求文档
   - 我们来做这个需求
   - 帮我梳理这个功能
   - 把这个功能写成 PRD

2. 控制提问数量。
   优先一次问一个问题；如果信息之间强相关，也可以一次问几个关键问题，但不要太多。
   始终优先补齐当前最关键、最影响方向的缺失信息。
   必读顺序参考：阅读 [references/prd-input-workflow.md](references/prd-input-workflow.md)。
   默认输入模板来源：使用 [references/prd-input-template.md](references/prd-input-template.md)。

3. 尽早起草。
   当下面这些信息已经基本清楚时，就先写出 `V0.1`，不要无限追问：
   - 需求名称
   - 为什么要做
   - 目标用户是谁
   - 核心场景是什么
   - 核心功能点有哪些
   - 期望输出是什么

4. 使用项目的输出模板撰写 PRD。
   默认使用内置标准模板 [references/prd-output-template.md](references/prd-output-template.md)。
   只有在以下情况才覆盖默认模板：
   - 用户明确指定了项目专用模板
   - 工作区里清晰存在一个可复用的 PRD 模板文件，而不是一份历史 PRD 草稿
   起草后用 [references/prd-output-guardrails.md](references/prd-output-guardrails.md) 做复核边界。

5. 在 `V0.1` 之后继续迭代。
   继续以少量关键问题为单位推进，优先补齐高风险缺口：
   - 规则与边界
   - 异常场景
   - 页面标题、按钮文案、交互状态
   - 验收标准
   - 上线方式和剩余待确认项

   如果在迭代中遇到下面这些问题，再按需读取参考资料：
   - PRD 结构是否完整：看 [references/prd-structure-checklist.md](references/prd-structure-checklist.md)
   - 范围太大、优先级难定：看 [references/prioritization-and-scope.md](references/prioritization-and-scope.md)
   - 用户提供了一堆访谈原话，需要提炼成需求：看 [references/interview-synthesis.md](references/interview-synthesis.md)
   - 需求要交给设计 / 研发 / 测试继续开工：看 [references/downstream-handoff.md](references/downstream-handoff.md)
   - 需要在交付前按评分机制判断需求文档质量：先看统一引擎 [references/prd-output-review-rubric.md](references/prd-output-review-rubric.md)
   - 检查 AI 产出 PRD 或正式 PRD：再看 [references/ai-prd-review-rubric.md](references/ai-prd-review-rubric.md)
   - 检查公司内部需求文档、禅道需求、字段化导出内容或粘贴正文：再看 [references/company-requirement-review-rubric.md](references/company-requirement-review-rubric.md)

6. 把可复用知识回流到长期文档。
   如果某个事实跨项目都稳定成立，就沉淀到业务知识体系。
   如果发生了关键决策、命名变化或结构变化，就记录到复盘日志。
   如果一个需求跨多轮持续澄清，就创建或更新项目级的需求访谈记录。
   必读参考：
   - [references/business-knowledge-system.md](references/business-knowledge-system.md)
   - [references/recap-log-pattern.md](references/recap-log-pattern.md)
   - [references/requirement-interview-record.md](references/requirement-interview-record.md)

## 产品边界

- 说明功能做什么、给谁用、在哪个场景用、遵循什么规则。
- 说明页面展示什么、用户可以做什么、系统返回什么，以及什么算成功。
- 用产品语言描述数据需求，例如：
  - 输入项
  - 输出项
  - 业务含义
  - 使用位置
- 不要默认展开成：
  - API 路径
  - HTTP 方法
  - 异常码
  - 数据库结构
  - `string`、`enum`、`text`、`object` 这类字段类型

如果用户明确要求技术设计，把它当作 PRD 之后的另一层工作来处理。

## 文档边界

- PRD 是项目级文档。
- 复盘日志是项目级文档。
- 业务知识是全局的、跨项目的。

不要默认把业务知识当作项目里的附录。

除非用户明确提出例外，否则稳定的业务规则、术语、角色、流程和上下游关系，都应该沉淀到 [references/business-knowledge-system.md](references/business-knowledge-system.md) 所描述的全局业务知识体系中。

## 高频遗漏检查

在判断 PRD 可以进入评审前，先检查是否明确覆盖以下内容：

- 页面标题、副标题、目标页面名称
- 主按钮和次按钮文案
- 倒计时文案和重试文案
- 输入限制和可点击条件
- 成功、失败和异常状态
- 自动处理条件和强拦截条件
- 账号限制和边界规则
- 成功后的去向和会话有效性
- 阻断文案和报错文案
- 主流程和关键异常流程的验收标准

精简复核清单见 [references/prd-output-guardrails.md](references/prd-output-guardrails.md)。

如果用户已经不在“从 0 到 1 梳理需求”，而是在补文档结构、判断范围优先级、整理下游交接，可以跳过连续提问，直接基于现有 PRD 与上述参考资料做增量修订。

如果用户要求对已有文档做质量检查，先判断输入来源：

- 完整 PRD、AI 生成 PRD、项目正式交付版 PRD：按 PRD 规则集检查
- 公司内部需求文档、禅道需求、字段化需求导出、聊天整理后的需求正文：按公司需求规则集检查
- 如果内容混合，先按公司需求规则集保证“来源兼容”，再补一轮 PRD 完整性视角

## 资源

### references/

- [references/prd-input-workflow.md](references/prd-input-workflow.md)
  问题顺序、最小起草门槛和后续追问优先级。
- [references/prd-input-template.md](references/prd-input-template.md)
  当用户没有提供项目专用输入模板时，可跨项目复用的标准 PRD 输入模板。
- [references/prd-output-template.md](references/prd-output-template.md)
  当用户没有提供项目专用输出模板时，可跨项目复用的标准 PRD 输出模板。
- [references/prd-output-guardrails.md](references/prd-output-guardrails.md)
  PRD 最终起草时的产品边界规则和防遗漏检查。
- [references/prd-output-review-rubric.md](references/prd-output-review-rubric.md)
  用于在准备交付或评审需求文档时，执行统一的带分数、带结论、强约束的结构化自检主流程。
- [references/ai-prd-review-rubric.md](references/ai-prd-review-rubric.md)
  用于检查 AI 生成 PRD、正式 PRD、项目输出版 PRD，重点关注结构完整性、流程闭环、规则与验收可执行性。
- [references/company-requirement-review-rubric.md](references/company-requirement-review-rubric.md)
  用于检查公司内部需求文档、禅道需求、字段化导出内容或纯文本需求正文，重点关注章节完备度、业务规则清晰度与公司模板适配度。
- [references/prd-structure-checklist.md](references/prd-structure-checklist.md)
  用于检查 PRD 是否缺关键章节，以及哪些内容更适合归到功能流程、页面方案、规则、异常或协作附录。
- [references/prioritization-and-scope.md](references/prioritization-and-scope.md)
  用于需求范围收敛、优先级判断、Must/Should/Could 区分，以及避免 PRD 一次装下过多子问题。
- [references/interview-synthesis.md](references/interview-synthesis.md)
  用于把零散访谈原话、聊天记录、事实描述提炼成目标用户、核心场景、功能点、规则和风险。
- [references/downstream-handoff.md](references/downstream-handoff.md)
  用于把 PRD 转成给设计、研发、测试的可执行交接清单，而不是重复正文目录。
- [references/business-knowledge-system.md](references/business-knowledge-system.md)
  如何把业务知识当作跨项目可复用的长期文档来维护。
- [references/recap-log-pattern.md](references/recap-log-pattern.md)
  复盘日志该记录什么，以及在什么情况下记录。
- [references/requirement-interview-record.md](references/requirement-interview-record.md)
  如何配合 PRD 和复盘日志，一起维护项目级需求访谈记录。
