import { registerTiktokHotProductsTools } from "./src/tiktok-hot-products.js";
const plugin = {
    id: "4seller-tk-sourcing",
    name: "4seller-tk-sourcing",
    description: "TikTok hot-products query plugin",
    configSchema: { type: "object", properties: {} },
    register(api) {
        registerTiktokHotProductsTools(api);
    },
};
export default plugin;
