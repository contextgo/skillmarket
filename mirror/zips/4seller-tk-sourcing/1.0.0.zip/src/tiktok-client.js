const SALE_RANK_PATH = "/api/listing/tiktok/sale-rank-by-tk-api";
const L1_CATEGORY_PATH = "/api/listing/tiktok/l1-category-list";
const DEFAULT_BASE_URL = "https://www.4seller.com";
function resolveBaseUrl(config) {
    const base = config.apiBaseUrl ?? DEFAULT_BASE_URL;
    return base.replace(/\/$/, "");
}
function toDateType(dateRange) {
    switch (dateRange) {
        case "7d":
            return 2;
        case "30d":
            return 3;
        case "day":
        default:
            return 1;
    }
}
function toOrder(sortBy) {
    switch (sortBy) {
        case "revenue":
            return "sale_amount";
        case "growth":
            return "sold_count_inc_rate";
        case "sales":
        default:
            return "sold_count";
    }
}
function buildRequestBody(options) {
    return {
        pageCurrent: 1,
        pageSize: options.limit ?? 10,
        dateType: toDateType(options.dateRange),
        dateValue: options.dateValue,
        region: options.region,
        order: toOrder(options.sortBy),
        orderDesc: "desc",
        pcname: options.category,
        keyword: options.keyword,
    };
}
function mapHttpError(status) {
    if (status === 401 || status === 403) {
        return new Error("Authentication failed, please check API key");
    }
    if (status === 429) {
        return new Error("Rate limited, try later or reduce cron frequency");
    }
    if (status >= 500) {
        return new Error("Service temporarily unavailable");
    }
    return new Error("Request to TikTok API failed");
}
async function requestWithTimeout(config, url, options) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), config.requestTimeoutMs);
    try {
        const response = await fetch(url, {
            method: "POST",
            headers: {
                "X-Api-Key": config.apiKey ?? "",
                "Content-Type": "application/json;charset=UTF-8",
            },
            ...options,
            signal: controller.signal,
        });
        if (!response.ok) {
            throw mapHttpError(response.status);
        }
        return response;
    }
    catch (error) {
        if (error instanceof Error && error.name === "AbortError") {
            throw new Error("Request timed out");
        }
        throw error;
    }
    finally {
        clearTimeout(timeout);
    }
}
function validatePayload(payload) {
    if (!payload || typeof payload !== "object" || !("code" in payload)) {
        throw new Error("Invalid API response format");
    }
    const typedPayload = payload;
    const records = typedPayload.data?.records;
    if (typedPayload.code === 0 && !Array.isArray(records)) {
        throw new Error("Invalid API response format");
    }
    return {
        ...typedPayload,
        message: typedPayload.message ?? typedPayload.msg,
        data: typedPayload.data
            ? {
                ...typedPayload.data,
                items: typedPayload.data.records,
            }
            : undefined,
    };
}
export async function fetchHotProducts(config, options) {
    if (!config.apiKey) {
        throw new Error("TikTok API key not configured");
    }
    const response = await requestWithTimeout(config, resolveBaseUrl(config) + SALE_RANK_PATH, {
        body: JSON.stringify(buildRequestBody(options)),
    });
    return validatePayload(await response.json());
}
export async function fetchL1Categories(config, site) {
    if (!config.apiKey) {
        throw new Error("TikTok API key not configured");
    }
    const response = await requestWithTimeout(config, resolveBaseUrl(config) + L1_CATEGORY_PATH, {
        body: JSON.stringify({ site: site || "" }),
    });
    const payload = (await response.json());
    if (!payload || typeof payload !== "object" || !("code" in payload)) {
        throw new Error("Category API response format error");
    }
    return payload;
}
