import type { OpenClawPluginApi } from "openclaw/plugin-sdk/core";
export declare function registerTiktokHotProductsTools(api: OpenClawPluginApi): void;
