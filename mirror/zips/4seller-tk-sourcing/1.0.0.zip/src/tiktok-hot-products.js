import { Type } from "@sinclair/typebox";
import { getTiktokConfig } from "./tiktok-config.js";
import { fetchHotProducts, fetchL1Categories } from "./tiktok-client.js";
const TiktokHotProductsSchema = Type.Object({
    region: Type.String({ description: "市场/地区，例如 US" }),
    category: Type.Optional(Type.String({ description: "商品类目，例如 Beauty" })),
    dateRange: Type.Optional(Type.Union([Type.Literal("day"), Type.Literal("7d"), Type.Literal("30d")], {
        description: "时间范围",
    })),
    dateValue: Type.Optional(Type.Number({ description: "查询数据归属日期，格式 YYYYMMDD，例如 20260415" })),
    limit: Type.Optional(Type.Number({ minimum: 1, maximum: 100, description: "返回数量" })),
    sortBy: Type.Optional(Type.Union([Type.Literal("sales"), Type.Literal("revenue"), Type.Literal("growth")], {
        description: "排序字段",
    })),
    keyword: Type.Optional(Type.String({ description: "关键词过滤" })),
    mode: Type.Optional(Type.Union([Type.Literal("interactive"), Type.Literal("scheduled")], {
        description: "调用模式",
    })),
    summaryMode: Type.Optional(Type.Union([Type.Literal("summary"), Type.Literal("full")], {
        description: "定时任务返回模式",
    })),
});
function json(data) {
    return {
        content: [{ type: "text", text: JSON.stringify(data, null, 2) }],
        details: data,
    };
}
function toDefaultDateValue(now = new Date()) {
    const date = new Date(now);
    date.setDate(date.getDate() - 2);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    return Number(`${year}${month}${day}`);
}
function normalizeQueryOptions(params) {
    return {
        region: params.region,
        category: params.category,
        dateRange: params.dateRange,
        dateValue: params.dateValue ?? toDefaultDateValue(),
        limit: params.limit,
        sortBy: params.sortBy,
        keyword: params.keyword,
        mode: params.mode ?? "interactive",
        summaryMode: params.summaryMode,
    };
}
function toProductRecord(item, index) {
    return {
        rank: index + 1,
        productId: item.product_id,
        title: item.title,
        shopName: item.shop_info?.name,
        price: item.real_price,
        sales: item.sold_count,
        revenue: item.sale_amount,
        growthRate: item.sold_count_inc_rate,
        productUrl: item.detail_url,
    };
}
function formatQueryResult(options, result) {
    if (result.code !== 0) {
        return {
            success: false,
            error: result.message || result.msg || "获取 TikTok 热销品失败",
        };
    }
    const items = (result.data?.items ?? []).map(toProductRecord);
    const total = result.data?.total ?? items.length;
    if (items.length === 0) {
        return {
            success: true,
            region: options.region,
            category: options.category,
            dateRange: options.dateRange,
            total,
            callTime: result.data?.callTime,
            source: result.data?.source,
            items: [],
            message: "当前条件下暂无热销品数据",
        };
    }
    return {
        success: true,
        region: options.region,
        category: options.category,
        dateRange: options.dateRange,
        total,
        callTime: result.data?.callTime,
        source: result.data?.source,
        items,
    };
}
function formatL1CategoryResult(result) {
    if (result.code !== 0) {
        throw new Error(result.message || result.msg || "获取 TikTok 一级类目失败");
    }
    return result.data ?? [];
}
export function registerTiktokHotProductsTools(api) {
    const config = getTiktokConfig(api);
    if (!config.apiKey) {
        api.logger.debug?.("tiktok_hot_products: apiKey not configured, tool disabled");
        return;
    }
    api.registerTool(() => ({
        name: "tiktok_hot_products",
        label: "TikTok Hot Products",
        description: "获取 TikTok 热销品榜单，支持按市场、类目、时间范围和排序方式查询。返回商品信息、销量、销售额、增长率及数据来源时间。",
        parameters: TiktokHotProductsSchema,
        async execute(_toolCallId, params) {
            try {
                const options = normalizeQueryOptions(params);
                const result = await fetchHotProducts(config, options);
                return json(formatQueryResult(options, result));
            }
            catch (error) {
                return json({
                    success: false,
                    error: error instanceof Error ? error.message : String(error),
                });
            }
        },
    }), { name: "tiktok_hot_products" });
    const TiktokL1CategoriesSchema = Type.Object({
        site: Type.Optional(Type.String({ description: "站点代码，默认 US" })),
    });
    api.registerTool(() => ({
        name: "tiktok_l1_categories",
        label: "TikTok L1 Categories",
        description: "获取 TikTok 销售排行榜可选一级类目列表。返回指定站点下所有可选类目的 ID 和名称，用于热销品查询的 category 参数。",
        parameters: TiktokL1CategoriesSchema,
        async execute(_toolCallId, params) {
            try {
                const { site } = params;
                const result = await fetchL1Categories(config, site);
                return json(formatL1CategoryResult(result));
            }
            catch (error) {
                return json({
                    success: false,
                    error: error instanceof Error ? error.message : String(error),
                });
            }
        },
    }), { name: "tiktok_l1_categories" });
}
