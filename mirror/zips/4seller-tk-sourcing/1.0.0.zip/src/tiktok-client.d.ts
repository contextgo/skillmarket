import type { TiktokConfig } from "./tiktok-config.js";
import type { QueryOptions, TiktokHotProductsApiResponse, TiktokL1CategoryApiResponse } from "./tiktok-types.js";
export declare function fetchHotProducts(config: TiktokConfig, options: QueryOptions): Promise<TiktokHotProductsApiResponse>;
export declare function fetchL1Categories(config: TiktokConfig, site?: string): Promise<TiktokL1CategoryApiResponse>;
