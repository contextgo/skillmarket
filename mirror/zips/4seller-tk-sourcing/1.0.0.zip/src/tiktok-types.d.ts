export type TiktokL1CategoryItem = {
    categoryId: string;
    categoryName: string;
};
export type TiktokL1CategoryApiResponse = {
    code: number;
    msg?: string;
    message?: string;
    data?: TiktokL1CategoryItem[];
};
export type QueryMode = "interactive" | "scheduled";
export type SummaryMode = "summary" | "full";
export type DateRange = "day" | "7d" | "30d";
export type SortBy = "sales" | "revenue" | "growth";
export type QueryOptions = {
    region: string;
    category?: string;
    dateRange?: DateRange;
    dateValue: number;
    limit?: number;
    sortBy?: SortBy;
    keyword?: string;
    mode: QueryMode;
    summaryMode?: SummaryMode;
};
export type TiktokHotProductsApiItem = {
    product_id: string;
    sold_count?: number;
    sale_amount?: number;
    total_sold_count?: number;
    total_sale_amount?: number;
    sold_count_inc_rate?: string | number;
    title: string;
    cover?: string;
    region?: string;
    currency?: string;
    real_price?: string | number;
    commission_rate?: string;
    category_name?: string[];
    detail_url?: string;
    source?: string | null;
    ctime?: string | null;
    shop_info?: {
        avatar?: string;
        seller_id?: string;
        name?: string | null;
        sold_count?: number | null;
    };
};
export type TiktokHotProductsApiResponse = {
    code: number;
    msg?: string;
    message?: string;
    data?: {
        records?: TiktokHotProductsApiItem[];
        total?: number;
        pageSize?: number;
        pageCurrent?: number;
        idList?: string[] | null;
        callTime?: string;
        source?: string;
        items?: TiktokHotProductsApiItem[];
    };
};
export type ProductRecord = {
    rank: number;
    productId: string;
    title: string;
    shopName?: string | null;
    price?: string | number;
    sales?: number;
    revenue?: number;
    growthRate?: string | number;
    productUrl?: string;
};
export type QueryResult = {
    success: boolean;
    region?: string;
    category?: string;
    dateRange?: DateRange;
    total?: number;
    callTime?: string;
    source?: string;
    items?: ProductRecord[];
    message?: string;
    error?: string;
};
