import type { OpenClawPluginApi } from "openclaw/plugin-sdk/core";
export type TiktokConfig = {
    apiBaseUrl?: string;
    apiKey?: string;
    requestTimeoutMs: number;
};
export declare function getTiktokConfig(api: Pick<OpenClawPluginApi, "config" | "pluginConfig">): TiktokConfig;
