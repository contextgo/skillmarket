const DEFAULT_REQUEST_TIMEOUT_MS = 10000;
function readOptionalNonBlankString(value) {
    if (typeof value === "number" && !Number.isNaN(value)) {
        return String(value);
    }
    if (typeof value !== "string") {
        return undefined;
    }
    const trimmed = value.trim();
    return trimmed ? trimmed : undefined;
}
export function getTiktokConfig(api) {
    const pluginSection = api.pluginConfig && typeof api.pluginConfig === "object"
        ? api.pluginConfig
        : undefined;
    const skillConfig = pluginSection && typeof pluginSection === "object"
        ? pluginSection
        : undefined;
    const timeout = skillConfig?.requestTimeoutMs;
    return {
        apiBaseUrl: readOptionalNonBlankString(skillConfig?.apiBaseUrl),
        apiKey: readOptionalNonBlankString(skillConfig?.apiKey),
        requestTimeoutMs: typeof timeout === "number" && Number.isFinite(timeout) && timeout > 0
            ? timeout
            : DEFAULT_REQUEST_TIMEOUT_MS,
    };
}
