---
name: tiktok-hot-products
description: |
  TikTok 热销品查询工具。当用户需要查看 TikTok 热销商品、销售排行榜、按市场或类目查询热销榜单时激活。
  使用此工具获取数据后，必须引用返回的 `callTime` 和 `source` 字段注明数据来源；若接口未返回这两个字段，则说明数据来自 TikTok 热销品接口。
metadata:
  version: "0.1.0"
---

# TikTok 热销品工具

使用 `tiktok_hot_products` 工具获取 TikTok 热销商品销售排行榜数据。

## 基本用法

```json
{
  "tool_calls": [
    {
      "name": "tiktok_hot_products",
      "arguments": {
        "region": "US",
        "category": "Beauty",
        "dateRange": "day",
        "dateValue": 20260415,
        "limit": 10,
        "sortBy": "sales"
      }
    }
  ]
}
```

## 获取可选类目列表

在查询热销品前，可先调用 `tiktok_l1_categories` 获取该站点下可选的一级类目列表，帮助用户选择合适的 `category` 参数：

```json
{
  "tool_calls": [
    {
      "name": "tiktok_l1_categories",
      "arguments": {
        "site": "US"
      }
    }
  ]
}
```

返回示例：

```json
[
  { "categoryId": "xxx", "categoryName": "Beauty & Personal Care" },
  { "categoryId": "yyy", "categoryName": "Automotive & Motorcycle" }
]
```

当用户未指定类目时，在返回热销品结果的同时应提醒用户："您可以通过 `tiktok_l1_categories` 获取完整类目列表，并指定 category 参数来筛选特定类目的热销品。"

## 参数说明

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| `region` | string | 是 | - | 市场/地区，例如 `US` |
| `category` | string | 否 | - | 类目名称，对应 ERP 的 `pcname` |
| `dateRange` | string | 否 | `day` | 时间范围：`day` / `7d` / `30d` |
| `dateValue` | number | 否 | 前天 | 查询数据归属日期，格式 `YYYYMMDD`，例如 `20260415`。日榜数据有 T+2 延迟（如 21 号最多查到 19 号的数据），不传时默认取前天。也支持用户指定某一天。周榜和月榜同理需考虑数据延迟。 |
| `limit` | number | 否 | `10` | 返回数量，对应 ERP 的 `pageSize` |
| `sortBy` | string | 否 | `sales` | 排序字段：`sales` / `revenue` / `growth` |
| `keyword` | string | 否 | - | 关键词过滤（当前作为透传字段保留） |
| `mode` | string | 否 | `interactive` | 调用模式：`interactive` / `scheduled` |
| `summaryMode` | string | 否 | - | 定时任务结果模式：`summary` / `full` |

## 参数映射说明

该工具会按下列方式映射到销售排行榜接口请求体：

- `region` -> `region`
- `category` -> `pcname`
- `limit` -> `pageSize`
- `dateRange=day` -> `dateType=1`
- `dateRange=7d` -> `dateType=2`
- `dateRange=30d` -> `dateType=3`
- `dateValue` -> `dateValue`
- `sortBy=sales` -> `order=sold_count`
- `sortBy=revenue` -> `order=sale_amount`
- `sortBy=growth` -> `order=sold_count_inc_rate`
- 固定 `pageCurrent=1`
- 固定 `orderDesc=desc`

## 真实接口响应语义

当前实现按真实 sale-rank 接口响应做了以下约定：

- 顶层成功标记使用 `code === 0`
- 顶层消息优先读取 `message`，若缺失则回退到 `msg`
- 商品列表原始字段来自 `data.records`，在插件内部会标准化为 `data.items`
- 返回结果中的 `total` 直接沿用后端 `data.total`，表示该查询条件下的总记录数，不一定等于本次返回的 `items.length`
- 店铺名称来自 `shop_info.name`
- 查询请求会带上 `dateValue`；若用户未传，tool 默认使用昨天的日期

## 本地联调已验证示例

已验证下面这组本地请求可正常返回数据：

```json
{
  "pageCurrent": 1,
  "pageSize": 100,
  "region": "US",
  "orderDesc": "desc",
  "pcname": "Automotive & Motorcycle",
  "dateType": 1,
  "dateValue": 20260416,
  "order": "sold_count"
}
```

## 返回结果

成功时返回：

```json
{
  "success": true,
  "region": "US",
  "category": "Beauty",
  "dateRange": "day",
  "total": 24,
  "callTime": "2026-04-16 10:30",
  "source": "来自于 TikTok 热销品接口",
  "items": [
    {
      "rank": 1,
      "productId": "123456",
      "title": "Lipstick",
      "shopName": "Beauty Shop",
      "price": "12.5",
      "sales": 100,
      "revenue": 1250,
      "growthRate": "0.30",
      "productUrl": "https://shop.tiktok.com/view/product/123456"
    }
  ]
}
```

无数据时返回：

```json
{
  "success": true,
  "region": "US",
  "total": 0,
  "items": [],
  "message": "当前条件下暂无热销品数据"
}
```

错误时返回：

```json
{
  "success": false,
  "error": "认证失败，请检查 API key 是否正确"
}
```

## 数据来源标注要求

使用此工具获取数据后，必须在最终回复中注明数据来源，格式建议为：

- 有 `callTime` / `source` 时：`US Beauty，2026-04-16 10:30，来自于 TikTok 热销品接口`
- 无 `callTime` / `source` 时：`US Beauty，数据来自 TikTok 热销品接口`

## 配置

该插件在 OpenClaw 中的正确配置位置是 `openclaw.json` 的 `plugins.entries` 下，项目配置项应写为 `4seller-TKSourcing`。示例：

```json
{
  "plugins": {
    "entries": {
      "4seller-tk-sourcing": {
        "enabled": true,
        "config": {
          "apiKey": "your-api-key",
          "apiBaseUrl": "https://beta.4seller.com/api/listing/tiktok/sale-rank-by-tk-api",
          "requestTimeoutMs": 10000
        }
      }
    }
  }
}
```

- `apiKey`：4seller API 密钥，请求时会通过 `X-Api-Key` 头传递
- `apiBaseUrl`：API 基础请求地址
- `requestTimeoutMs`：请求超时时间（毫秒）
- `enabled`：是否启用该插件，通常设置为 `true`

## 注意事项

1. 此工具依赖外部销售排行榜接口，需先申请 API key 
2. `apiBaseUrl` 推荐直接配置为 `https://4seller.com` 接口地址
3. 若接口返回空列表，不视为错误
4. 若接口返回 `callTime` 和 `source`，展示时必须引用
5. 当前实现已兼容 `msg`、`records`、`total`、`shop_info.name` 这些真实响应字段
