---
name: tiktok-cron
description: |
  TikTok 定时查询任务说明。当用户需要安装或更新 TikTok 热销品定时任务、每日自动拉取榜单时激活。
metadata:
  version: "0.1.0"
---

# TikTok 定时任务 Skill

此 skill 用于指导 OpenClaw cron 定时触发 `tiktok_hot_products` 查询。

## 可用任务

| 任务名称 | 执行时间 | 功能描述 |
|----------|----------|----------|
| `tiktok-hot-products-daily` | 每天一次 | 拉取指定市场/类目的 TikTok 热销品摘要 |

## 推荐安装命令

在安装定时任务前，请先确保在 `openclaw.json` 的 `plugins.entries` 下正确配置该插件，项目配置项应写为 `4seller-TKSourcing`：

```json
{
  "plugins": {
    "entries": {
      "4seller-tk-sourcing": {
        "enabled": true,
        "config": {
          "apiKey": "your-api-key",
          "apiBaseUrl": "https://beta.4seller.com/api/listing/tiktok/sale-rank-by-tk-api",
          "requestTimeoutMs": 10000
        }
      }
    }
  }
}
```

其中：

- `enabled`：是否启用该插件，通常设置为 `true`
- `apiKey`：4seller API 密钥
- `apiBaseUrl`：API 基础请求地址
- `requestTimeoutMs`：请求超时时间（毫秒）

然后执行：

```bash
openclaw cron add \
  --name "tiktok-hot-products-daily" \
  --cron "15 9 * * *" \
  --tz "Asia/Shanghai" \
  --session isolated \
  --message "请调用 tiktok_hot_products，查询 US 市场 Beauty 类目 day 热销品，返回前10条摘要，并注明 callTime 和 source。"
```

## 已有任务更新命令

```bash
openclaw cron edit <job-id> \
  --cron "15 9 * * *" \
  --tz "Asia/Shanghai" \
  --session isolated \
  --message "请调用 tiktok_hot_products，查询 US 市场 Beauty 类目 day 热销品，返回前10条摘要，并注明 callTime 和 source。"
```

## 参数说明

| 参数 | 值 | 说明 |
|------|-----|------|
| `--name` | `tiktok-hot-products-daily` | 任务唯一名称 |
| `--cron` | `15 9 * * *` | 每天 09:15 执行，可按需调整 |
| `--tz` | `Asia/Shanghai` | 使用上海时区 |
| `--session` | `isolated` | 每次触发在独立会话中执行 |
| `--message` | 调用 `tiktok_hot_products` 的指令 | 由 AI 按消息触发工具 |

## 推荐消息模板

### 每日榜单摘要

```text
请调用 tiktok_hot_products，查询 US 市场 Beauty 类目 day 热销品，返回前10条摘要，并注明 callTime 和 source。
```

### 每周榜单摘要

```text
请调用 tiktok_hot_products，查询 US 市场 Beauty 类目 7d 热销品，按 sales 排序，返回前10条摘要，并注明 callTime 和 source。
```

### 月榜完整榜单

```text
请调用 tiktok_hot_products，查询 US 市场 Beauty 类目 30d 热销品，按 revenue 排序，返回 full 模式结果，并注明 callTime 和 source。
```

## 使用建议

1. cron 只负责定时发送消息，不直接实现查询逻辑
2. 实际查询统一由 `tiktok_hot_products` 工具完成
3. 安装定时任务前，先在 OpenClaw 插件配置中配置 `4seller-tk-sourcing.apiKey`
4. 建议先手动验证查询参数，再安装定时任务
5. 如果接口限流，优先降低执行频率或缩小查询范围
6. 可通过 `tiktok_l1_categories` 获取站点下可选的一级类目列表，用于定时任务配置中的类目参数
7. 日榜数据存在 T+2 延迟；例如 21 号通常最多查到 19 号数据，定时任务默认日期建议按前天理解
