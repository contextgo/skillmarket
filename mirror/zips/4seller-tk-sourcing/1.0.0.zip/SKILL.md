# 4seller TKSourcing Plugin

这是一个为 TikTok 卖家业务提供的综合自动化插件包。

## 包含的技能 (Skills)

本插件包含以下两个主要技能：

1. **获取爆款商品 (tiktok-hot-products)**
   - **功能**：用于获取和分析 TikTok 当前的爆款商品数据。
   
2. **定时任务 (tiktok-cron)**
   - **功能**：用于定期执行数据同步或拉取任务。

## 环境与配置要求
需要在 `openclaw.json` 中提供 4seller 的 API 密钥 (`apiKey`) 等必要配置。