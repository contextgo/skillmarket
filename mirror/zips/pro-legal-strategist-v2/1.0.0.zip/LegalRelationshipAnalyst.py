#!/bin/bash
#
# LegalRelationshipAnalyst 法律关系分析技能命令行接口
#

# 获取技能目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_SCRIPT="${SCRIPT_DIR}/legal_analyst.py"

# 检查Python脚本是否存在
if [ ! -f "$PYTHON_SCRIPT" ]; then
    echo "错误: 找不到Python脚本: $PYTHON_SCRIPT"
    exit 1
fi

# 检查Python3
if ! command -v python3 &> /dev/null; then
    echo "错误: 未找到python3，请安装Python 3"
    exit 1
fi

# 解析参数并直接传递给Python脚本
if [ $# -eq 0 ]; then
    # 无参数时显示帮助
    exec python3 "$PYTHON_SCRIPT" --help
else
    # 传递所有参数给Python脚本
    exec python3 "$PYTHON_SCRIPT" "$@"
fi