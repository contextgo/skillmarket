---
name: feishu-bot
description: 从零搭建飞书机器人。支持 MiniMax/MiMo 等模型、工具调用（搜索/天气/百科/记忆）、Skill 架构。一站式交付可上线运行的飞书群聊 bot。
---

# feishu-bot

从零到上线，一站式搭建飞书机器人。

## 快速开始（3 步完成）

**Step 1：创建空目录，运行初始化**
```bash
mkdir my-feishu-bot && cd my-feishu-bot
node C:/Users/Pap/.workbuddy/skills/feishu-bot/templates/setup.js
```

**Step 2：编辑 bot.js 配置区**
填入以下 6 个值：
- `APP_ID` / `APP_SECRET` — 飞书开放平台创建应用获得
- `CHAT_ID` — 目标群的 chat_id
- `BOT_NAME` — 群里 @机器人的名字
- `MODEL_NAME` / `LLM_BASE_URL` / `LLM_API_KEY` — LLM 接口凭证

**Step 3：启动**
```bash
node bot.js
```

---

## 准备工作（创建飞书应用）

1. 登录 [open.feishu.cn](https://open.feishu.cn)，创建企业自建应用
2. 在「应用功能 → 机器人」开启机器人
3. 配置权限：`im:message`（读取）、`im:message:send_as_bot`（发送）
4. 发布应用
5. 获取群 chat_id：在目标群里添加机器人后，从群设置或调用 `GET /im/v1/chats` 获取

---

## 交付物结构

```
my-feishu-bot/
├── bot.js              ← 主入口（修改配置区 6 个值）
├── setup.js            ← 初始化脚本（仅首次用）
├── skills/             ← 5 个技能
│   ├── memory.js       ← 保存记忆
│   ├── memread.js      ← 读取记忆
│   ├── search.js       ← 网页搜索
│   ├── weather.js      ← 天气查询
│   └── wiki.js         ← 百科查询
└── memory/
    └── memory.json     ← 记忆持久化文件（自动创建）
```

---

## 配置清单

| 配置项 | 说明 |
|--------|------|
| `APP_ID` | 飞书应用 App ID，如 `cli_a95bc5ceb7f8dbc2` |
| `APP_SECRET` | 飞书应用 App Secret |
| `CHAT_ID` | 目标群 chat_id，如 `oc_af90c47132cb7c9a05cecc9529adc3dc` |
| `BOT_NAME` | 群里 @的名字，如 `2号` |
| `MODEL_NAME` | LLM 模型名，如 `MiniMax-M2.7` |
| `LLM_BASE_URL` | API 地址，如 `https://api.minimaxi.com/v1` |
| `LLM_API_KEY` | API 密钥 |
| `POLL_INTERVAL` | 轮询间隔，默认 3000ms（可选） |

---

## 内置 Skills

| Skill | 功能 |
|-------|------|
| `save_memory` | 保存重要事实到记忆库，重启不丢 |
| `load_memory` | 查询记忆库，模糊匹配关键词 |
| `web_search` | 搜索互联网，获取实时信息 |
| `get_weather` | 查询城市天气 |
| `wiki_search` | 查询维基百科词条 |

---

## 扩展方式

**加新 skill**：
1. 在 `skills/` 下新建 `xxx.js`
2. 导出 `{ name, description, parameters, execute }`
3. 重启 bot，自动加载，无需修改 bot.js

**换模型**：
确保模型支持 tool call，修改配置区的 `MODEL_NAME` 和 `LLM_BASE_URL` 即可。

**改身份设定**：
修改 bot.js 中的 `BOT_IDENTITY` 变量，机器人会以对应风格回复。

---

## 常见坑

| 问题 | 原因 | 解决 |
|------|------|------|
| 消息不回复 | 字段名写错 | 用 `msg.msg_type`，不是 `content.msg_type` |
| 工具不触发 | 模型不支持 function call | 确认模型支持 tool call，或去掉 tools 数组降级 |
| 回复有冗余标签 | 未过滤 `<|im_start|>` | bot.js 已内置过滤，检查正则是否被删 |
| 进程无响应 | 依赖没装 | 运行 `npm install axios` |
| 401 错误 | token 过期 | bot.js 已内置自动刷新，检查 APP_ID/SECRET 是否正确 |

---

## 日志查看

- 正常运行日志：`bot.log`
- 报错日志：`bot.err`
- 重启后日志会追加，tail 实时看：
  ```powershell
  Get-Content bot.log -Wait -Tail 20
  ```
