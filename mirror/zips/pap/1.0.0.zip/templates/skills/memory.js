const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'save_memory',
  description: '当用户告诉你重要的事实、偏好或决定时，将它保存到记忆库。格式：{ "key": "关键标识", "content": "具体内容" }',
  parameters: {
    type: 'object',
    properties: {
      key: { type: 'string', description: '记忆的关键标识，如"姓名"、"公司"、"语言偏好"' },
      content: { type: 'string', description: '要记忆的具体内容' }
    },
    required: ['key', 'content']
  },
  execute: async ({ key, content }) => {
    const MEMORY_FILE = path.join(__dirname, '..', 'memory', 'memory.json');
    let data = { facts: [] };
    if (fs.existsSync(MEMORY_FILE)) {
      try { data = JSON.parse(fs.readFileSync(MEMORY_FILE, 'utf8')); } catch (e) {}
    }
    // 去重：同名 key 覆盖
    const idx = data.facts.findIndex(f => f.key === key);
    if (idx >= 0) data.facts[idx] = { key, content };
    else data.facts.push({ key, content, created_at: new Date().toISOString() });

    const dir = path.dirname(MEMORY_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(MEMORY_FILE, JSON.stringify(data, null, 2), 'utf8');
    return `已记住：${key} = ${content}`;
  }
};
