const https = require('https');

module.exports = {
  name: 'get_weather',
  description: '查询指定城市的当前天气。输入城市名（中文或英文），返回天气、温度、湿度等信息。',
  parameters: {
    type: 'object',
    properties: {
      city: { type: 'string', description: '城市名，如"北京"、"上海"、"东京"' }
    },
    required: ['city']
  },
  execute: async ({ city }) => {
    // 这里使用 wttr.in 免费 API，无需 key
    return new Promise((resolve) => {
      https.get(`https://wttr.in/${encodeURIComponent(city)}?format=j1`, res => {
        let d = ''; res.on('data', c => d += c); res.on('end', () => {
          try {
            const json = JSON.parse(d);
            const current = json.current_condition[0];
            const desc = `${city}当前天气：${current.weatherDesc[0].value}，温度${current.temp_C}℃，湿度${current.humidity}%`;
            resolve(desc);
          } catch { resolve(`无法获取${city}的天气`); }
        });
      }).on('error', () => resolve('天气查询失败'));
    });
  }
};
