const https = require('https');
const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'load_memory',
  description: '查询记忆库中是否已保存某些信息。当你不确定用户之前是否告诉过你什么事时，调用此工具查询。输入关键词，返回记忆库中匹配的内容。',
  parameters: {
    type: 'object',
    properties: {
      key: { type: 'string', description: '要查询的记忆关键词，如"姓名"、"公司"、"语言偏好"' }
    },
    required: ['key']
  },
  execute: async ({ key }) => {
    const MEMORY_FILE = path.join(__dirname, '..', 'memory', 'memory.json');
    if (!fs.existsSync(MEMORY_FILE)) return `记忆库为空，尚无任何记忆。`;
    try {
      const data = JSON.parse(fs.readFileSync(MEMORY_FILE, 'utf8'));
      const facts = data.facts || [];
      if (facts.length === 0) return `记忆库为空。`;
      // 模糊匹配 key
      const matched = facts.filter(f => f.key.includes(key) || key.includes(f.key));
      if (matched.length === 0) return `未找到与"${key}"相关的记忆。`;
      return matched.map(f => `• ${f.key}: ${f.content}`).join('\n');
    } catch (e) {
      return `读取记忆失败: ${e.message}`;
    }
  }
};
