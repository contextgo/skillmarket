const https = require('https');

module.exports = {
  name: 'wiki_search',
  description: '搜索中文或英文维基百科，获取词条的简要介绍。适合查人物、概念、历史事件等。',
  parameters: {
    type: 'object',
    properties: {
      topic: { type: 'string', description: '要查询的词条名称，如"人工智能"、"牛顿"' }
    },
    required: ['topic']
  },
  execute: async ({ topic }) => {
    return new Promise((resolve) => {
      // 使用 Wikipedia REST API
      const url = `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(topic)}`;
      https.get(url, { headers: { 'Accept': 'application/json' } }, res => {
        let d = ''; res.on('data', c => d += c); res.on('end', () => {
          try {
            const json = JSON.parse(d);
            if (json.title && json.extract) {
              resolve(`${json.title}：${json.extract.slice(0, 300)}${json.extract.length > 300 ? '...' : ''}`);
            } else {
              resolve(`未找到"${topic}"的相关词条`);
            }
          } catch { resolve('百科查询失败'); }
        });
      }).on('error', () => resolve('百科查询失败'));
    });
  }
};
