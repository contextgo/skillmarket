const https = require('https');

module.exports = {
  name: 'web_search',
  description: '搜索互联网获取实时信息。输入搜索关键词，返回最相关的内容摘要。',
  parameters: {
    type: 'object',
    properties: {
      query: { type: 'string', description: '搜索关键词' }
    },
    required: ['query']
  },
  execute: async ({ query }) => {
    return new Promise((resolve, reject) => {
      const url = `https://www.googleapis.com/customsearch/v1?q=${encodeURIComponent(query)}&key=YOUR_GOOGLE_API_KEY&cx=YOUR_CSE_ID`;
      https.get(url, res => {
        let d = ''; res.on('data', c => d += c); res.on('end', () => {
          try {
            const json = JSON.parse(d);
            const results = (json.items || []).slice(0, 3).map(i => `${i.title}: ${i.snippet}`).join('\n');
            resolve(results || '未找到相关结果');
          } catch { resolve('搜索失败'); }
        });
      }).on('error', reject);
    });
  }
};
