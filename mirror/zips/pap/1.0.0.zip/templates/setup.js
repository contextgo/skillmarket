/**
 * feishu-bot 初始化脚本
 * 运行方式: node setup.js
 *
 * 自动完成：
 * 1. 复制模板到当前目录
 * 2. 安装依赖 (axios)
 * 3. 创建 memory 目录
 *
 * 之后手动修改 bot.js 配置区的 6 个值，再运行 restart.bat 即可
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const TEMPLATE_DIR = path.join(__dirname);
const TARGET_DIR = process.cwd();
const SKILLS_SRC = path.join(TEMPLATE_DIR, 'skills');

// ========== 1. 复制模板 ==========
function copyFile(src, dst) {
  if (fs.existsSync(dst)) {
    const ans = ask(`${dst} 已存在，是否覆盖？ (y/n): `);
    if (ans.toLowerCase() !== 'y') { console.log('跳过:', dst); return; }
  }
  fs.copyFileSync(src, dst);
  console.log('✅', dst.replace(TARGET_DIR, '.'));
}

function copyDir(src, dst) {
  if (!fs.existsSync(dst)) fs.mkdirSync(dst, { recursive: true });
  for (const file of fs.readdirSync(src)) {
    const s = path.join(src, file);
    const d = path.join(dst, file);
    if (fs.statSync(s).isDirectory()) copyDir(s, d);
    else copyFile(s, d);
  }
}

// 复制主文件
console.log('\n📦 复制模板文件...');
for (const file of ['bot.js', 'restart.bat']) {
  copyFile(path.join(TEMPLATE_DIR, file), path.join(TARGET_DIR, file));
}

// 复制 skills
if (fs.existsSync(SKILLS_SRC)) {
  console.log('\n📦 复制 skills...');
  const skillsDst = path.join(TARGET_DIR, 'skills');
  copyDir(SKILLS_SRC, skillsDst);
}

// 创建 memory 目录
console.log('\n📦 创建 memory 目录...');
const memDir = path.join(TARGET_DIR, 'memory');
if (!fs.existsSync(memDir)) {
  fs.mkdirSync(memDir, { recursive: true });
  fs.writeFileSync(path.join(memDir, 'memory.json'), JSON.stringify({ facts: [] }, null, 2));
  console.log('✅ memory/memory.json 已创建');
} else {
  console.log('⏭️ memory 目录已存在，跳过');
}

// ========== 2. 安装依赖 ==========
console.log('\n📦 安装依赖 (axios)...');
try {
  execSync('npm install axios', { stdio: 'inherit', cwd: TARGET_DIR });
  console.log('✅ axios 安装成功');
} catch (e) {
  console.log('⚠️ npm install 失败，请手动运行: npm install axios');
}

// ========== 3. 完成提示 ==========
console.log(`
====================================
✅ 初始化完成！

下一步：编辑 bot.js 配置区，填入：
  - APP_ID / APP_SECRET
  - CHAT_ID
  - BOT_NAME
  - MODEL_NAME / LLM_BASE_URL / LLM_API_KEY

然后运行：
  双击 restart.bat

日志文件：bot.log / bot.err
====================================
`);
