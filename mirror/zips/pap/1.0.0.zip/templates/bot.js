const axios = require('axios');
const fs = require('fs');
const path = require('path');

// ===================== 配置区 =====================
const APP_ID = 'cli_xxxxxxxxxxxx';           // 飞书 App ID
const APP_SECRET = 'xxxxxxxxxxxxxxxx';       // 飞书 App Secret
const CHAT_ID = 'oc_xxxxxxxxxxxxxxxx';       // 目标群 chat_id
const BOT_NAME = '机器人名';                  // @名字（群里的 @名）
const MODEL_NAME = 'MiniMax-M2.7';          // LLM 模型
const LLM_BASE_URL = 'https://api.minimaxi.com/v1';  // LLM API 地址
const LLM_API_KEY = 'sk-xxxxxxxxxxxx';      // LLM API Key
const POLL_INTERVAL = 3000;                  // 轮询间隔（毫秒）
// ===================== 配置区结束 =====================

const API_BASE = 'https://open.feishu.cn/open-apis';
const SKILLS_DIR = path.join(__dirname, 'skills');
const MEMORY_FILE = path.join(__dirname, 'memory', 'memory.json');

let token = '';
let tools = [];
let toolMap = {};
let sessionHistory = {};  // chat_id -> [messages]

const BOT_IDENTITY = `你叫${BOT_NAME}，是一个勤快、简洁的AI助手。回复直接，不废话。当需要实时信息时，优先使用工具（web_search、get_weather、wiki_search）。有值得记住的信息（用户偏好、重要事实、决定），主动调用 save_memory 保存。如果不确定用户之前是否告诉过你某件事，先调用 load_memory 查询。`;

// ===================== Skills 加载 =====================
function loadSkills() {
  if (!fs.existsSync(SKILLS_DIR)) return;
  const files = fs.readdirSync(SKILLS_DIR).filter(f => f.endsWith('.js'));
  for (const file of files) {
    try {
      const skill = require(path.join(SKILLS_DIR, file));
      tools.push({
        type: 'function',
        function: {
          name: skill.name,
          description: skill.description,
          parameters: skill.parameters
        }
      });
      toolMap[skill.name] = skill;
      console.log(`✅ 技能: ${skill.name}`);
    } catch (e) {
      console.error(`❌ 技能 ${file} 加载失败:`, e.message);
    }
  }
}

function loadMemoryForPrompt() {
  if (!fs.existsSync(MEMORY_FILE)) return '';
  try {
    const data = JSON.parse(fs.readFileSync(MEMORY_FILE, 'utf8'));
    const facts = data.facts || [];
    if (facts.length === 0) return '';
    const memoryText = '【已知信息】\n' + facts.map(f => `• ${f.key}: ${f.content}`).join('\n');
    console.log(`📝 已加载 ${facts.length} 条记忆`);
    return '\n\n' + memoryText;
  } catch (e) { return ''; }
}

const SYSTEM_PROMPT = (() => {
  loadSkills();
  return BOT_IDENTITY + loadMemoryForPrompt();
})();

// ===================== 飞书 API =====================
async function getToken() {
  const { data } = await axios.post(`${API_BASE}/auth/v3/tenant_access_token/internal`, {
    app_id: APP_ID,
    app_secret: APP_SECRET
  });
  return data.tenant_access_token;
}

async function getMessages(cursor = '') {
  const { data } = await axios.get(`${API_BASE}/im/v1/messages`, {
    params: { container_id_type: 'chat', container_id: CHAT_ID, page_size: 10, sort_type: 'ByCreateTimeDesc', cursor },
    headers: { Authorization: `Bearer ${token}` }
  });
  return data.items || [];
}

async function sendMessage(content, msg_id) {
  await axios.post(`${API_BASE}/im/v1/messages/${msg_id}/reply`, {
    msg_type: 'text',
    content: JSON.stringify({ text: content })
  }, {
    headers: { Authorization: `Bearer ${token}` }
  });
}

function cleanReply(text) {
  text = text.replace(/<\|im_start\|>[\s\S]*?<\|im_end\|>/gi, '');
  text = text.replace(/<think>[\s\S]*?<\/think>/gi, '');
  text = text.replace(/\n{3,}/g, '\n\n').trim();
  return text || '（暂时没想好怎么回）';
}

// ===================== LLM 调用 =====================
async function chatWithLLM(messages) {
  const hasTools = tools.length > 0;
  const payload = {
    model: MODEL_NAME,
    messages,
    max_tokens: 2048,
    temperature: 0.7
  };
  if (hasTools) payload.tools = tools;

  const { data } = await axios.post(`${LLM_BASE_URL}/chat/completions`, payload, {
    headers: { Authorization: `Bearer ${LLM_API_KEY}`, 'Content-Type': 'application/json' }
  });

  const choice = data.choices[0];
  if (!choice) return { content: '', toolCalls: [] };

  // 处理工具调用
  if (choice.finish_reason === 'tool_calls' || choice.message.tool_calls) {
    const toolCalls = choice.message.tool_calls || [];
    const results = [];
    for (const tc of toolCalls) {
      const fn = toolMap[tc.function.name];
      if (!fn) { results.push({ name: tc.function.name, error: '未找到工具' }); continue; }
      try {
        const args = JSON.parse(tc.function.arguments);
        const result = await fn.execute(args);
        results.push({ name: tc.function.name, result });
      } catch (e) {
        results.push({ name: tc.function.name, error: e.message });
      }
    }
    // 把工具结果追加到对话，重新调用
    messages.push(choice.message);
    for (const r of results) {
      messages.push({
        role: 'tool',
        tool_call_id: tc.id || null,
        content: typeof r === 'string' ? r : JSON.stringify(r)
      });
    }
    return chatWithLLM(messages);
  }

  return { content: choice.message.content, toolCalls: [] };
}

// ===================== 消息处理 =====================
async function processMessage(msg) {
  if (msg.chat_id !== CHAT_ID) return;
  if (msg.msg_type !== 'text') return;
  const body = JSON.parse(msg.body);
  if (!body.content || !body.content.includes(`@_user_${msg.mentions?.[0]?.tenant_key || ''}`)) return;

  const text = body.content.replace(/@[_user#.].+?( |$)/gi, '').trim();
  if (!text) return;

  console.log(`📩 ${msg.sender?.sender_id?.open_id || '?'}: ${text}`);

  if (!sessionHistory[CHAT_ID]) sessionHistory[CHAT_ID] = [];
  const history = sessionHistory[CHAT_ID];

  history.push({ role: 'user', content: text });
  const messages = [{ role: 'system', content: SYSTEM_PROMPT }, ...history];
  const { content } = await chatWithLLM(messages);

  const reply = cleanReply(content);
  history.push({ role: 'assistant', content: reply });
  if (history.length > 50) sessionHistory[CHAT_ID] = history.slice(-50);

  await sendMessage(reply, msg.message_id);
  console.log(`📤 ${BOT_NAME}: ${reply.slice(0, 80)}`);
}

// ===================== 主循环 =====================
let lastMsgTime = Date.now();

async function main() {
  console.log(`🤖 ${BOT_NAME} 启动中...`);
  console.log(`📦 ${tools.length} 个技能已加载`);
  token = await getToken();

  while (true) {
    try {
      const msgs = await getMessages();
      const newMsgs = msgs.filter(m => new Date(m.create_time).getTime() > lastMsgTime - 5000);
      for (const msg of newMsgs.reverse()) {
        await processMessage(msg);
        lastMsgTime = Math.max(lastMsgTime, new Date(msg.create_time).getTime());
      }
    } catch (e) {
      if (e.response?.status === 401) token = await getToken();
      else console.error('轮询错误:', e.message);
    }
    await new Promise(r => setTimeout(r, POLL_INTERVAL));
  }
}

main();
