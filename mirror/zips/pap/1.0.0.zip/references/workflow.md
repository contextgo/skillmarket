# 从零搭建飞书机器人的完整流程

## Step 1：飞书开放平台创建应用

1. 登录 [open.feishu.cn](https://open.feishu.cn)
2. 创建企业自建应用，获得 `App ID` 和 `App Secret`
3. 在「应用功能 → 机器人」中开启机器人
4. 配置权限：至少需要 `im:message`（读取消息）、`im:message:send_as_bot`（发消息）
5. 发布应用

## Step 2：获取目标群的 chat_id

在目标群里添加机器人，然后从群设置 → 群信息 → 群 ID，或者调用 API `GET /im/v1/chats` 获取。

## Step 3：准备 LLM API

- **MiniMax**：注册 miniMax.io，获取 API Key
- **小米 MiMo**：使用 `https://token-plan-cn.xiaomimimo.com/v1/chat/completions`
- **任意 OpenAI 兼容接口**：确保支持 tool call

## Step 4：组装代码

1. 复制 `templates/bot.js` 到目标目录，如 `e:/tmp/mybot/`
2. 填入配置区的 6 个值（APP_ID、APP_SECRET、CHAT_ID、BOT_NAME、MODEL_NAME、LLM_BASE_URL、LLM_API_KEY）
3. 复制 `templates/skills/` 下的所有 skill 到 `mybot/skills/`
4. 创建 `mybot/memory/` 目录
5. 复制 `templates/restart.bat` 到 `mybot/` 同级

## Step 5：安装依赖

```bash
cd mybot
npm init -y
npm install axios
```

## Step 6：启动并测试

```bash
node mybot/bot.js
```

群里 @机器人 说句话，看是否回复。

## Step 7：持续运行

双击 `restart.bat` 启动，以后改完代码再双击即可重启。

## Skill 扩展流程

想加新能力：
1. 在 `mybot/skills/` 新建 `xxx.js`
2. 导出 `{ name, description, parameters, execute }`
3. 重启 bot，自动加载
