# visual-note-prompt

将简短文本转换为知识卡片图片的提示词生成器。

## 功能特点

- 自动分析内容要点数和字数
- 智能判断图片拆分数量（1-4张+）
- 支持6种视觉风格：经典手账、科技未来、清新自然、商务专业、国潮中式、极简线条
- 支持8种构图布局：时间线、金字塔、中心发散、对比、卡片堆叠、笔记本、山峰、树状
- 严格遵循标准化输出格式，确保AI图像生成器正确解析

## 技能结构

```
visual-note-prompt/
├── SKILL.md                    # 主技能文件
├── references/
│   └── format-guide.md         # 格式规范指南
└── assets/
    └── style-library.md         # 风格与构图库
```

## 使用方法

### 输入格式

```
主标题
要点1
要点2
要点3
```

### 可选参数

- **风格**：classic / tech / nature / business / chinese / minimal
- **构图**：timeline / pyramid / center / compare / cards / notebook / mountain / tree

### 输出格式

```
---【图开始】---
[Style]: 手绘涂鸦笔记(Sketchnote)，classic，...
[Layout]: 3:4竖版，cards，...
[Series]: 01/02
[Title]: `主标题`
[Core Content]: 
- 区域一位于画面左侧：`内容文字`（旁边画简笔画）
[Decoration]: 手绘箭头、星星、连接线
[Details]: 系列标识"[01/02]"置于右上角
---【图结束】---
```

## 安装

将此技能复制到 WorkBuddy 的 skills 目录：

```bash
# WorkBuddy
cp -r visual-note-prompt ~/.workbuddy/skills/

# 或使用 symlink
ln -s /path/to/visual-note-prompt ~/.workbuddy/skills/visual-note-prompt
```

## 示例

**输入：**
```
学习效率提升方法
番茄工作法：25分钟专注+5分钟休息
时间块管理：将任务分配到固定时间段
目标分解：将大目标拆分为小步骤
```

**输出：**
```
---【图开始】---
[Style]: 手绘涂鸦笔记(Sketchnote)，classic，手绘感线条，浅米色纸张，暖色系+黑轮廓+黄绿点缀
[Layout]: 3:4竖版，cards，独立完整画布，非拼接
[Series]: 01/01
[Title]: `学习效率提升方法`（位于画面顶部15-20%，醒目横幅内，旁边画思考小人简笔画）
[Core Content]: 
- 区域一位于画面左上：`番茄工作法`（旁边画番茄时钟简笔画）
- 区域二位于画面右上：`时间块管理`（旁边画日历图标简笔画）
- 区域三位于画面左下：`目标分解`（旁边画阶梯简笔画）
[Decoration]: 手绘箭头、星星、连接线、点缀图标
[Details]: 系列标识"[01/01]"置于右上角
---【图结束】---
```

## 配合使用

此技能与 visual-note-generator 配合使用效果最佳：
1. 使用 `visual-note-prompt` 生成标准化提示词
2. 使用 `visual-note-generator` 将提示词转换为图片

## License

MIT
