pub mod strip;
