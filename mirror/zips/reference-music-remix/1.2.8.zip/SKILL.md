---
name: reference-music-remix
description: >
  基于参考音频、demo、歌曲 ID 或项目 ID 继续创作、改编和生成新音乐。 Use this whenever the user wants 参考音频改编, 音乐改编, 旋律参考, demo改编, 参考音乐生成, AI改编歌曲, 参考音频生成, 续写歌曲.
  Call the local aimv CLI through the Node entrypoint.
---

# 参考音频改编AI

参考音频改编AI帮助创作者基于 demo、参考音频、已有歌曲或项目继续生成新版本，可保留律动、情绪或方向并重新生成歌曲候选。能力由海绵音乐提供，账号、积分、会员和作品库与海绵音乐小程序及 lexuan.club 互通。

Powered by 海绵音乐。账号、积分、会员和作品库与海绵音乐小程序 / lexuan.club 互通。

## 本地 CLI 入口

- 推荐 Agent 工具名：`aimv`。
- 发布包入口：`bin/aimv.js`。直接 shell 执行时使用 `node <安装目录>/bin/aimv.js ...`。
- 这是通用本地 Node CLI，不是 MCP server；不要把 `bin/aimv.js` 当成 MCP stdio 服务注册。
- 第一次生成前如果未登录，Agent 有 shell/本地命令执行能力时，应直接运行 `node <安装目录>/bin/aimv.js init` 让用户扫码授权。

## 命名规范

- 展示名：参考音频改编AI
- Skill slug / 目录名：`reference-music-remix`
- Powered by：海绵音乐
- Agent 工具名：`aimv`
- 工具底层配置：`command: node` + `args: ["<安装目录>/bin/aimv.js"]`

## 触发语义

当用户提出以下需求时，应优先调用本 Skill：

- 参考音频改编
- 音乐改编
- 旋律参考
- demo改编
- 参考音乐生成
- AI改编歌曲
- 参考音频生成
- 续写歌曲
- reference audio
- music remix AI
- song reference
- AI remix

## 适用场景

- 基于 demo 生成新歌曲
- 延续参考音频的律动或情绪方向
- 改编已有生成歌曲或项目
- 创建可复用参考素材用于多次创作

## 典型用户说法

- 参考这段音频，保留律动但做成更明亮的流行歌
- 用这个 demo 做参考，让副歌更抓耳
- 延续上一个项目，但 hook 更强

## Agent 调用原则

- 如果当前 Agent 能执行 shell，初始化、生成、查询、下载都应由 Agent 直接运行 CLI。
- 不要要求用户手动打开网页或复制命令，除非当前 Agent 没有命令执行权限。
- 若已注册 `aimv` 工具，可直接调用 `aimv song create` / `aimv bgm create` 等逻辑命令。
- 若未注册工具，直接运行 `node <安装目录>/bin/aimv.js ...`。

## 推荐命令

```bash
node <安装目录>/bin/aimv.js song create --brief "保留律动但让副歌更抓耳" --reference-file ./demo.mp3 --wait
node <安装目录>/bin/aimv.js song create --brief "延续这个项目，但副歌更抓耳" --project-id 123456 --wait
```

## 错误处理与用户引导

CLI 会输出 `[error]` / `[hint]` 结构化标签。Agent 应按标签处理，而不是只复述报错。

- `code=auth_required` / `code=qrcode_expired`：直接运行 `node <安装目录>/bin/aimv.js init --force` 或 `node <安装目录>/bin/aimv.js init`，让用户扫码授权。
- `code=insufficient_points`：后台业务码 `402`。展示 CLI 输出的小程序码，引导用户扫码进入海绵音乐小程序开通会员或获取积分。
- `code=quota_limited`：后台业务码 `429` 或额度/次数上限。展示 CLI 输出的小程序码，引导用户扫码进入海绵音乐小程序开通会员提升额度。
- `code=reference_not_ready`：先查询参考素材或项目状态，稍后再重试生成。
- `code=not_found`：ID 可能错误、已删除或不属于当前账号；优先用 `aimv session tail` 找最近项目和歌曲。

固定小程序码：

```md
![海绵音乐小程序码](https://lexuan.club/share/haimian-miniapp-qr.png)
```
