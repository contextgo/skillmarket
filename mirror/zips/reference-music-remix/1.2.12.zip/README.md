# 参考音频改编AI

基于参考音频、demo、歌曲 ID 或项目 ID 继续创作、改编和生成新音乐。

参考音频改编AI适合需要 reference music remix、参考音频改编、demo 改编和歌曲二创方向的创作者。你可以基于 demo、参考音频、已有歌曲或项目继续生成新版本，保留律动、情绪或风格方向，并获得新的歌曲候选；作品会同步到海绵音乐账号，可在「海绵音乐AI写歌」小程序和 lexuan.club 网页继续管理。

Powered by 海绵音乐。账号、积分、会员和作品库与海绵音乐小程序 / lexuan.club 互通。

## Package Identity

- Skill slug: `reference-music-remix`
- Package name: `reference-music-remix`
- Agent tool name: `aimv`
- Node entrypoint: `bin/aimv.js`
- Runtime bundle: `dist/aimv.cjs`

## Keywords

- 参考音频改编
- 音乐改编
- 旋律参考
- demo改编
- 参考音乐生成
- AI改编歌曲
- 参考音频生成
- 续写歌曲
- reference audio
- music remix AI
- song reference
- AI remix

## Use Cases

- 基于 demo 生成新歌曲
- 延续参考音频的律动或情绪方向
- 改编已有生成歌曲或项目
- 创建可复用参考素材用于多次创作

## Examples

- 参考这段音频，保留律动但做成更明亮的流行歌
- 用这个 demo 做参考，让副歌更抓耳
- 延续上一个项目，但 hook 更强

## Run

```bash
node ./bin/aimv.js init
node ./bin/aimv.js song create --brief "保留律动但让副歌更抓耳" --reference-file ./demo.mp3 --wait
node ./bin/aimv.js song create --brief "延续这个项目，但副歌更抓耳" --project-id 123456 --wait
```

The package does not include an opaque native binary or an extensionless Unix executable. It runs through Node.js >=18.
