#!/usr/bin/env python3
"""
退休规划计算器
计算退休时间和社保缴费总额
支持：职工社保、灵活就业社保
"""

import sys
import json
from datetime import datetime, timedelta
from typing import Dict, Tuple, Optional

# 中国延迟退休政策参数（2025年1月1日起实施）
RETIREMENT_POLICY = {
    "male": {
        "base_age": 60,  # 原退休年龄
        "target_age": 63,  # 目标退休年龄
        "transition_start": "2025-01-01",
        "transition_months": 36,  # 每4个月延迟1个月，总共36个月（3年）
    },
    "female_worker": {
        "base_age": 50,
        "target_age": 55,
        "transition_start": "2025-01-01",
        "transition_months": 60,  # 每2个月延迟1个月，总共60个月（5年）
    },
    "female_cadre": {
        "base_age": 55,
        "target_age": 58,
        "transition_start": "2025-01-01",
        "transition_months": 36,  # 每4个月延迟1个月，总共36个月（3年）
    }
}

# 职工社保缴费比例（有单位）
EMPLOYEE_RATES = {
    "pension": 0.08,       # 养老保险个人缴费比例 8%
    "medical": 0.02,       # 医疗保险个人缴费比例 2%
    "unemployment": 0.005, # 失业保险个人缴费比例 0.5%
    "housing_fund": 0.07,  # 住房公积金个人缴费比例 7%（范围5%-12%）
}

# 灵活就业缴费比例（无单位，自己缴纳）
FLEXIBLE_RATES = {
    "pension": 0.20,       # 养老保险 20%（8%进个人账户，12%进统筹）
    "medical": None,       # 医疗保险各地不同，见下方字典
    "unemployment": 0,     # 灵活就业没有失业保险
    "housing_fund": 0,     # 灵活就业一般没有公积金（可选，但很少交）
}

# 各城市灵活就业医疗保险缴费比例（各地差异较大）
CITY_FLEXIBLE_MEDICAL_RATES = {
    "北京": 0.065,    # 6.5%
    "上海": 0.11,     # 11%
    "广州": 0.08,     # 8%
    "深圳": 0.08,     # 8%
    "杭州": 0.095,    # 9.5%
    "成都": 0.088,    # 8.8%
    "武汉": 0.06,     # 6%
    "西安": 0.06,     # 6%
    "南京": 0.10,     # 10%
    "重庆": 0.10,     # 10%（分两档，这里取二档）
    "天津": 0.075,    # 7.5%
    "苏州": 0.10,     # 10%
    "其他城市": 0.08,  # 默认 8%
}

# 各城市2024年社保缴费基数上下限（单位：元）
CITY_SOCIAL_INSURANCE_BASE = {
    "北京": {"min": 6821, "max": 35283},
    "上海": {"min": 7384, "max": 36921},
    "广州": {"min": 5284, "max": 26421},
    "深圳": {"min": 4492, "max": 26421},
    "杭州": {"min": 4812, "max": 24930},
    "成都": {"min": 4246, "max": 21228},
    "武汉": {"min": 4224, "max": 21120},
    "西安": {"min": 4224, "max": 21120},
    "南京": {"min": 4494, "max": 24042},
    "重庆": {"min": 4118, "max": 20587},
    "天津": {"min": 5013, "max": 25065},
    "苏州": {"min": 4494, "max": 24042},
    "其他城市": {"min": 4000, "max": 20000},  # 默认值
}

# 各城市2023年职工月平均工资（用于养老金计算，单位：元）
# 数据来源：各城市统计局公布的2023年城镇单位就业人员平均工资
CITY_AVG_SALARY = {
    "北京": 15701,     # 2023年全口径城镇单位就业人员月平均工资
    "上海": 12183,     # 2023年全口径城镇单位就业人员月平均工资
    "广州": 10449,     # 2023年城镇非私营单位就业人员月平均工资
    "深圳": 10758,     # 2023年城镇非私营单位就业人员月平均工资
    "杭州": 9600,      # 2023年杭州市非私营单位就业人员月平均工资
    "成都": 8500,      # 估算值
    "武汉": 8200,      # 估算值
    "西安": 7800,      # 估算值
    "南京": 9500,      # 估算值
    "重庆": 7500,      # 估算值
    "天津": 8900,      # 估算值
    "苏州": 9200,      # 估算值
    "其他城市": 8000,   # 默认值
}

# 养老金计发月数（根据退休年龄）
# 60岁退休：139个月；55岁退休：170个月；50岁退休：195个月
PENSION_PAYMENT_MONTHS = {
    50: 195,
    51: 190,
    52: 185,
    53: 180,
    54: 175,
    55: 170,
    56: 164,
    57: 158,
    58: 152,
    59: 145,
    60: 139,
    61: 132,
    62: 125,
    63: 117,
    64: 109,
    65: 101,
    66: 93,
    67: 84,
    68: 75,
    69: 65,
    70: 56,
}


def calculate_retirement_age(birth_date: str, gender: str, job_type: str = "worker") -> Tuple[int, int]:
    """
    计算退休年龄和延迟月数
    
    Args:
        birth_date: 出生日期，格式 "YYYY-MM-DD"
        gender: "male" 或 "female"
        job_type: 女性需要区分 "worker" (工人) 或 "cadre" (干部)
    
    Returns:
        (退休年龄, 延迟月数)
    """
    birth = datetime.strptime(birth_date, "%Y-%m-%d")
    policy_key = "male" if gender == "male" else f"female_{job_type}"
    policy = RETIREMENT_POLICY[policy_key]
    
    transition_start = datetime.strptime(policy["transition_start"], "%Y-%m-%d")
    
    # 计算原退休日期
    original_retirement_year = birth.year + policy["base_age"]
    original_retirement_date = datetime(original_retirement_year, birth.month, 1)
    
    # 如果原退休日期在过渡期开始之前，不延迟
    if original_retirement_date <= transition_start:
        return policy["base_age"], 0
    
    # 计算过渡期经过的月数
    months_since_transition = (original_retirement_date.year - transition_start.year) * 12 + \
                              (original_retirement_date.month - transition_start.month)
    
    # 计算延迟月数
    if policy_key == "male" or policy_key == "female_cadre":
        # 每4个月延迟1个月
        delay_months = min(months_since_transition // 4, policy["transition_months"])
    else:  # female_worker
        # 每2个月延迟1个月
        delay_months = min(months_since_transition // 2, policy["transition_months"])
    
    retirement_age = policy["base_age"] + (delay_months / 12)
    
    return retirement_age, delay_months


def calculate_retirement_date(birth_date: str, gender: str, job_type: str = "worker") -> Dict:
    """
    计算退休日期
    
    Returns:
        包含退休日期详细信息的字典
    """
    birth = datetime.strptime(birth_date, "%Y-%m-%d")
    retirement_age, delay_months = calculate_retirement_age(birth_date, gender, job_type)
    
    # 计算退休日期
    retirement_year = birth.year + int(retirement_age)
    retirement_month = birth.month + int((retirement_age % 1) * 12)
    
    # 处理月份溢出
    if retirement_month > 12:
        retirement_year += retirement_month // 12
        retirement_month = retirement_month % 12
    
    retirement_date = datetime(retirement_year, retirement_month, 1)
    
    # 计算距离退休还有多少个月
    today = datetime.now()
    months_until_retirement = (retirement_year - today.year) * 12 + (retirement_month - today.month)
    
    return {
        "birth_date": birth_date,
        "gender": "男性" if gender == "male" else "女性",
        "job_type": "工人" if job_type == "worker" else "干部" if gender == "female" else "",
        "retirement_age": retirement_age,
        "delay_months": delay_months,
        "retirement_year": retirement_year,
        "retirement_month": retirement_month,
        "retirement_date": f"{retirement_year}年{retirement_month}月",
        "months_until_retirement": max(0, months_until_retirement),
        "years_until_retirement": round(max(0, months_until_retirement) / 12, 1),
    }


def calculate_social_insurance_employee(
    base: float,
    months_until_retirement: int,
    include_housing_fund: bool = True
) -> Dict:
    """
    计算职工社保缴费（有单位）
    """
    # 计算各项社保费用（个人缴纳部分）
    pension = base * EMPLOYEE_RATES["pension"]
    medical = base * EMPLOYEE_RATES["medical"]
    unemployment = base * EMPLOYEE_RATES["unemployment"]
    
    monthly_total = pension + medical + unemployment
    
    if include_housing_fund:
        housing_fund = base * EMPLOYEE_RATES["housing_fund"]
        monthly_total += housing_fund
    else:
        housing_fund = 0
    
    # 计算总额
    total = monthly_total * months_until_retirement
    
    return {
        "employment_type": "employee",
        "employment_type_name": "职工社保（单位代缴）",
        "monthly_payments": {
            "pension": round(pension, 2),
            "medical": round(medical, 2),
            "unemployment": round(unemployment, 2),
            "housing_fund": round(housing_fund, 2) if include_housing_fund else 0,
            "total": round(monthly_total, 2),
        },
        "total_payments": {
            "pension": round(pension * months_until_retirement, 2),
            "medical": round(medical * months_until_retirement, 2),
            "unemployment": round(unemployment * months_until_retirement, 2),
            "housing_fund": round(housing_fund * months_until_retirement, 2) if include_housing_fund else 0,
            "total": round(total, 2),
        },
    }


def calculate_social_insurance_flexible(
    base: float,
    city: str,
    months_until_retirement: int
) -> Dict:
    """
    计算灵活就业社保（无单位，自己缴纳）
    """
    # 获取该城市医疗保险比例
    medical_rate = CITY_FLEXIBLE_MEDICAL_RATES.get(city, CITY_FLEXIBLE_MEDICAL_RATES["其他城市"])
    
    # 计算各项社保费用（全部自己承担）
    pension = base * FLEXIBLE_RATES["pension"]  # 20%
    medical = base * medical_rate  # 各地不同，约6%-11%
    unemployment = 0  # 灵活就业没有失业保险
    housing_fund = 0  # 灵活就业一般没有公积金
    
    monthly_total = pension + medical
    
    # 计算总额
    total = monthly_total * months_until_retirement
    
    return {
        "employment_type": "flexible",
        "employment_type_name": "灵活就业（个人缴纳）",
        "monthly_payments": {
            "pension": round(pension, 2),
            "medical": round(medical, 2),
            "unemployment": 0,
            "housing_fund": 0,
            "total": round(monthly_total, 2),
        },
        "total_payments": {
            "pension": round(pension * months_until_retirement, 2),
            "medical": round(medical * months_until_retirement, 2),
            "unemployment": 0,
            "housing_fund": 0,
            "total": round(total, 2),
        },
        "notes": "灵活就业养老保险20%中只有8%进个人账户，12%进统筹账户",
    }


def calculate_social_insurance(
    monthly_salary: float,
    city: str,
    months_until_retirement: int,
    employment_type: str = "employee",
    include_housing_fund: bool = True
) -> Dict:
    """
    计算社保缴费总额
    
    Args:
        monthly_salary: 月工资（元）
        city: 城市名称
        months_until_retirement: 距离退休的月数
        employment_type: "employee" 职工社保 或 "flexible" 灵活就业
        include_housing_fund: 是否包含住房公积金（仅职工社保有效）
    
    Returns:
        社保缴费详情
    """
    # 获取城市缴费基数
    city_base = CITY_SOCIAL_INSURANCE_BASE.get(city, CITY_SOCIAL_INSURANCE_BASE["其他城市"])
    
    # 确定缴费基数（在上下限之间）
    base = max(city_base["min"], min(monthly_salary, city_base["max"]))
    
    # 根据就业类型计算
    if employment_type == "flexible":
        insurance_details = calculate_social_insurance_flexible(base, city, months_until_retirement)
    else:
        insurance_details = calculate_social_insurance_employee(base, months_until_retirement, include_housing_fund)
    
    return {
        "city": city,
        "monthly_salary": monthly_salary,
        "social_insurance_base": base,
        "months_until_retirement": months_until_retirement,
        "years_until_retirement": round(months_until_retirement / 12, 1),
        **insurance_details,
    }


def compare_employment_types(
    monthly_salary: float,
    city: str,
    months_until_retirement: int,
    include_housing_fund: bool = True
) -> Dict:
    """
    对比职工社保和灵活就业的缴费差异
    """
    employee = calculate_social_insurance(monthly_salary, city, months_until_retirement, "employee", include_housing_fund)
    flexible = calculate_social_insurance(monthly_salary, city, months_until_retirement, "flexible")
    
    employee_monthly = employee["monthly_payments"]["total"]
    flexible_monthly = flexible["monthly_payments"]["total"]
    employee_total = employee["total_payments"]["total"]
    flexible_total = flexible["total_payments"]["total"]
    
    return {
        "employee": employee,
        "flexible": flexible,
        "comparison": {
            "monthly_difference": round(flexible_monthly - employee_monthly, 2),
            "total_difference": round(flexible_total - employee_total, 2),
            "flexible_more_expensive_by": round((flexible_monthly / employee_monthly - 1) * 100, 1) if employee_monthly > 0 else 0,
        }
    }


def calculate_pension(
    city: str,
    monthly_salary: float,
    years_contributed: float,
    retirement_age: float,
    employment_type: str = "employee"
) -> Dict:
    """
    计算退休后每月养老金领取金额
    
    养老金 = 基础养老金 + 个人账户养老金
    
    基础养老金 = (退休时上年度全市职工月平均工资 + 本人指数化月平均缴费工资) ÷ 2 × 缴费年限 × 1%
    个人账户养老金 = 个人账户储存额 ÷ 计发月数
    
    Args:
        city: 城市名称
        monthly_salary: 月工资（元）
        years_contributed: 已缴纳社保年限（年）
        retirement_age: 退休年龄
        employment_type: "employee" 或 "flexible"
    
    Returns:
        养老金计算详情
    """
    # 获取城市平均工资和缴费基数
    avg_salary = CITY_AVG_SALARY.get(city, CITY_AVG_SALARY["其他城市"])
    city_base = CITY_SOCIAL_INSURANCE_BASE.get(city, CITY_SOCIAL_INSURANCE_BASE["其他城市"])
    
    # 确定缴费基数
    contribution_base = max(city_base["min"], min(monthly_salary, city_base["max"]))
    
    # 计算缴费工资指数（简化计算：假设一直按当前基数缴费）
    # 指数化月平均缴费工资 = 退休时上年度全市职工月平均工资 × 平均缴费工资指数
    wage_index = contribution_base / avg_salary  # 缴费指数
    indexed_monthly_wage = avg_salary * wage_index
    
    # 计算基础养老金
    basic_pension = (avg_salary + indexed_monthly_wage) / 2 * years_contributed * 0.01
    
    # 计算个人账户储存额
    # 职工社保：个人缴纳8%进入个人账户
    # 灵活就业：缴纳20%，其中8%进入个人账户
    monthly_personal_contribution = contribution_base * 0.08  # 每月进入个人账户的金额
    
    # 假设年利率3%的复利计算（简化）
    # 个人账户储存额 = 每月缴存额 × 12 × 缴费年限 × (1 + 平均利率)^缴费年限
    interest_rate = 0.03  # 3%年利率
    personal_account_balance = monthly_personal_contribution * 12 * years_contributed * (1 + interest_rate) ** (years_contributed / 2)
    
    # 获取计发月数
    retirement_age_int = int(retirement_age)
    payment_months = PENSION_PAYMENT_MONTHS.get(retirement_age_int, 139)  # 默认139个月（60岁）
    
    # 计算个人账户养老金
    personal_pension = personal_account_balance / payment_months
    
    # 总养老金
    total_pension = basic_pension + personal_pension
    
    # 计算替代率（养老金/退休前工资）
    replacement_rate = (total_pension / monthly_salary * 100) if monthly_salary > 0 else 0
    
    return {
        "city": city,
        "monthly_salary": monthly_salary,
        "contribution_base": contribution_base,
        "years_contributed": years_contributed,
        "retirement_age": retirement_age,
        "employment_type": employment_type,
        "pension_details": {
            "basic_pension": round(basic_pension, 2),           # 基础养老金
            "personal_pension": round(personal_pension, 2),      # 个人账户养老金
            "total_monthly_pension": round(total_pension, 2),    # 每月养老金合计
            "personal_account_balance": round(personal_account_balance, 2),  # 个人账户累计储存额
            "payment_months": payment_months,                    # 计发月数
            "replacement_rate": round(replacement_rate, 1),      # 养老金替代率（%）
        },
        "calculation_formula": {
            "basic_pension_formula": f"({avg_salary} + {round(indexed_monthly_wage, 2)}) / 2 × {years_contributed} × 1% = {round(basic_pension, 2)}",
            "personal_pension_formula": f"{round(personal_account_balance, 2)} / {payment_months} = {round(personal_pension, 2)}",
        },
        "notes": [
            "基础养老金与缴费年限、缴费基数、当地平均工资相关",
            "缴费年限越长、缴费基数越高，基础养老金越多",
            "个人账户养老金取决于个人账户累计储存额",
            "以上计算为估算值，实际养老金以社保局核算为准",
            "养老金每年都会根据物价和工资增长进行调整（养老金上调）",
        ]
    }


def calculate_payback_period(
    total_insurance_paid: float,
    monthly_pension: float,
    pension_growth_rate: float = 0.04,  # 养老金年增长率（默认4%）
    life_expectancy: int = 80
) -> Dict:
    """
    计算社保回本年限
    
    计算退休后需要活多少年才能通过领取养老金收回缴纳的社保成本
    
    Args:
        total_insurance_paid: 退休前缴纳的社保总额（只算养老保险相关部分）
        monthly_pension: 退休后每月领取的养老金
        pension_growth_rate: 养老金年增长率（默认4%，考虑每年养老金上调）
        life_expectancy: 预期寿命（默认80岁）
    
    Returns:
        回本分析详情
    """
    # 只计算养老保险相关缴费（养老+医疗，不算失业和公积金）
    # 这里假设约60%的缴费与养老金相关
    pension_related_paid = total_insurance_paid * 0.6
    
    # 简单计算（不考虑增长）：回本月数 = 总缴费 / 月养老金
    simple_payback_months = pension_related_paid / monthly_pension if monthly_pension > 0 else float('inf')
    simple_payback_years = simple_payback_months / 12
    
    # 考虑养老金每年增长的精确计算
    # 使用逐年累加法，考虑每年养老金上调
    accumulated_pension = 0
    year = 0
    current_monthly_pension = monthly_pension
    exact_payback_years = None
    accumulated_by_year = []
    
    while accumulated_pension < pension_related_paid and year < 50:  # 最多计算50年
        year += 1
        # 当年领取的养老金（考虑增长）
        year_pension = current_monthly_pension * 12
        accumulated_pension += year_pension
        
        accumulated_by_year.append({
            "year": year,
            "monthly_pension": round(current_monthly_pension, 2),
            "year_pension": round(year_pension, 2),
            "accumulated_pension": round(accumulated_pension, 2),
            "remaining_to_payback": round(max(0, pension_related_paid - accumulated_pension), 2),
            "payback_percentage": round(min(100, accumulated_pension / pension_related_paid * 100), 1)
        })
        
        if exact_payback_years is None and accumulated_pension >= pension_related_paid:
            exact_payback_years = year - 1 + (accumulated_pension - year_pension - pension_related_paid) / (-year_pension)
            exact_payback_years = year  # 简化处理
        
        # 下一年养老金增长
        current_monthly_pension *= (1 + pension_growth_rate)
    
    # 如果没有找到精确回本点，使用最后一年数据
    if exact_payback_years is None:
        exact_payback_years = simple_payback_years
    
    # 计算到预期寿命的总收益
    years_to_life_expectancy = life_expectancy - 60  # 假设60岁退休
    total_lifetime_pension = 0
    current_pension = monthly_pension
    for _ in range(years_to_life_expectancy):
        total_lifetime_pension += current_pension * 12
        current_pension *= (1 + pension_growth_rate)
    
    # 投资回报率计算（简化）
    # 如果把钱存入银行（3%年利率）vs 交社保
    bank_rate = 0.03
    bank_future_value = pension_related_paid * (1 + bank_rate) ** simple_payback_years
    
    return {
        "total_insurance_paid": round(total_insurance_paid, 2),
        "pension_related_paid": round(pension_related_paid, 2),
        "monthly_pension_first_year": round(monthly_pension, 2),
        "payback_analysis": {
            "simple_payback_years": round(simple_payback_years, 1),
            "simple_payback_months": round(simple_payback_months, 0),
            "exact_payback_years": round(exact_payback_years, 1),
            "payback_at_age": 60 + round(exact_payback_years, 1),  # 假设60岁退休
        },
        "lifetime_analysis": {
            "life_expectancy": life_expectancy,
            "years_in_retirement": years_to_life_expectancy,
            "total_lifetime_pension": round(total_lifetime_pension, 2),
            "net_benefit": round(total_lifetime_pension - pension_related_paid, 2),
            "roi_percentage": round((total_lifetime_pension - pension_related_paid) / pension_related_paid * 100, 1) if pension_related_paid > 0 else 0,
        },
        "comparison_with_bank": {
            "bank_future_value": round(bank_future_value, 2),
            "pension_is_better": total_lifetime_pension > bank_future_value,
            "advantage_amount": round(total_lifetime_pension - bank_future_value, 2),
        },
        "accumulated_by_year": accumulated_by_year[:10],  # 只返回前10年数据
        "notes": [
            "回本年限只计算养老保险相关缴费（约占社保总缴费的60%）",
            "简单回本 = 总缴费 ÷ 月养老金，不考虑养老金增长",
            "实际回本更快，因为养老金每年会上调（约3-5%）",
            "如果活过回本年限，之后领取的养老金都是净收益",
            "社保还具有抗通胀、终身领取、家属继承等优势",
        ]
    }


def compare_retirement_ages(
    birth_date: str,
    gender: str,
    job_type: str,
    monthly_salary: float,
    city: str,
    employment_type: str = "employee",
    include_housing_fund: bool = True,
    target_ages: list = None
) -> Dict:
    """
    对比不同退休年龄选择的收益差异
    
    计算不同退休年龄下的：
    - 多缴的社保金额
    - 每月养老金差异
    - 达到盈亏平衡需要的年限
    - 总收益对比
    
    Args:
        birth_date: 出生日期
        gender: 性别
        job_type: 工作类型
        monthly_salary: 月工资
        city: 城市
        employment_type: 就业类型
        include_housing_fund: 是否含公积金
        target_ages: 要对比的退休年龄列表，如 [60, 63, 65]
    
    Returns:
        对比结果字典
    """
    from datetime import datetime
    
    birth = datetime.strptime(birth_date, "%Y-%m-%d")
    
    # 如果没有指定目标年龄，根据性别获取默认范围
    if target_ages is None:
        if gender == "male":
            target_ages = [60, 63, 65]
        elif gender == "female":
            if job_type == "worker":
                target_ages = [50, 55]
            else:  # cadre
                target_ages = [55, 58, 60]
    
    scenarios = []
    base_scenario = None
    
    for age in target_ages:
        # 计算退休年份和月份
        retirement_year = birth.year + int(age)
        retirement_month = birth.month + int((age % 1) * 12)
        if retirement_month > 12:
            retirement_year += retirement_month // 12
            retirement_month = retirement_month % 12
        
        # 计算距离退休的月数
        today = datetime.now()
        months_until = (retirement_year - today.year) * 12 + (retirement_month - today.month)
        months_until = max(0, months_until)
        years_until = months_until / 12
        
        # 计算社保缴费（从现在到该退休年龄）
        insurance = calculate_social_insurance(
            monthly_salary, city, months_until, employment_type, include_housing_fund
        )
        
        # 计算已缴费年限（假设从22岁开始工作）
        current_age = today.year - birth.year
        years_contributed = max(15, current_age - 22 + years_until)  # 至少15年
        
        # 计算养老金
        pension = calculate_pension(city, monthly_salary, years_contributed, age, employment_type)
        
        scenario = {
            "retirement_age": age,
            "retirement_date": f"{retirement_year}年{retirement_month}月",
            "years_until": round(years_until, 1),
            "months_until": months_until,
            "years_contributed": round(years_contributed, 1),
            "total_insurance_paid": insurance["total_payments"]["total"],
            "monthly_pension": pension["pension_details"]["total_monthly_pension"],
            "pension_details": pension["pension_details"],
        }
        
        scenarios.append(scenario)
        
        # 以第一个（最早退休）为基准
        if base_scenario is None:
            base_scenario = scenario
    
    # 计算对比分析
    comparisons = []
    for i, scenario in enumerate(scenarios):
        if i == 0:
            comparison = {
                "vs_base": "基准（最早退休）",
                "extra_paid": 0,
                "monthly_pension_increase": 0,
                "break_even_years": 0,
                "lifetime_benefit_20y": scenario["monthly_pension"] * 12 * 20,
            }
        else:
            # 比基准多缴的金额
            extra_paid = scenario["total_insurance_paid"] - base_scenario["total_insurance_paid"]
            # 每月多领的养老金
            monthly_increase = scenario["monthly_pension"] - base_scenario["monthly_pension"]
            # 盈亏平衡年限（多缴的钱需要多少年才能通过多领的养老金回本）
            break_even_years = extra_paid / (monthly_increase * 12) if monthly_increase > 0 else float('inf')
            
            # 假设领取20年的总收益对比
            base_lifetime = base_scenario["monthly_pension"] * 12 * 20
            scenario_lifetime = scenario["monthly_pension"] * 12 * (20 - (scenario["retirement_age"] - base_scenario["retirement_age"]))
            
            comparison = {
                "vs_base": f"比{base_scenario['retirement_age']}岁退休",
                "extra_paid": round(extra_paid, 2),
                "monthly_pension_increase": round(monthly_increase, 2),
                "pension_increase_rate": round(monthly_increase / base_scenario["monthly_pension"] * 100, 1) if base_scenario["monthly_pension"] > 0 else 0,
                "break_even_years": round(break_even_years, 1),
                "lifetime_benefit_20y": round(scenario_lifetime, 2),
                "net_benefit_vs_base": round(scenario_lifetime - base_lifetime - extra_paid, 2),
            }
        
        scenario["comparison"] = comparison
        comparisons.append(comparison)
    
    return {
        "user_info": {
            "birth_date": birth_date,
            "gender": gender,
            "job_type": job_type,
            "monthly_salary": monthly_salary,
            "city": city,
            "employment_type": employment_type,
        },
        "scenarios": scenarios,
        "summary": {
            "total_scenarios": len(scenarios),
            "age_range": f"{min(target_ages)}岁 - {max(target_ages)}岁",
            "recommendation_notes": [
                "延迟退休可以增加缴费年限，提高基础养老金",
                "晚退休计发月数更少，个人账户养老金更高",
                "但需要权衡多工作几年 vs 多领养老金",
                "如果身体健康、工作稳定，延迟退休通常更划算",
            ]
        }
    }


def main():
    """主函数"""
    if len(sys.argv) < 2:
        print("Usage: python calculate_retirement.py <command> [options]")
        print("")
        print("命令:")
        print("  calculate    计算退休时间和社保缴费（默认）")
        print("  pension      计算退休后养老金领取金额")
        print("  compare      对比不同退休年龄的收益差异")
        print("  payback      计算社保回本年限")
        print("")
        print("calculate 命令参数:")
        print("  python calculate_retirement.py calculate <birth_date> <gender> <job_type> <monthly_salary> [city] [employment_type] [include_housing_fund]")
        print("  示例: python calculate_retirement.py calculate 1985-06-15 male worker 15000 北京 employee true")
        print("")
        print("pension 命令参数:")
        print("  python calculate_retirement.py pension <city> <monthly_salary> <years_contributed> <retirement_age> [employment_type]")
        print("  示例: python calculate_retirement.py pension 北京 15000 25 63")
        print("")
        print("compare 命令参数:")
        print("  python calculate_retirement.py compare <birth_date> <gender> <job_type> <monthly_salary> [city] [employment_type] [include_housing_fund]")
        print("  示例: python calculate_retirement.py compare 1985-06-15 male worker 15000 北京 employee true")
        print("")
        print("payback 命令参数:")
        print("  python calculate_retirement.py payback <出生日期> <性别> <身份类型> <月工资> [城市] [就业类型] [是否含公积金]")
        print("  示例: python calculate_retirement.py payback 1985-06-15 male worker 15000 北京 employee true")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "pension":
        # 养老金计算模式
        if len(sys.argv) < 6:
            print("养老金计算参数不足")
            print("Usage: python calculate_retirement.py pension <city> <monthly_salary> <years_contributed> <retirement_age> [employment_type]")
            sys.exit(1)
        
        city = sys.argv[2]
        monthly_salary = float(sys.argv[3])
        years_contributed = float(sys.argv[4])
        retirement_age = float(sys.argv[5])
        employment_type = sys.argv[6] if len(sys.argv) > 6 else "employee"
        
        result = calculate_pension(city, monthly_salary, years_contributed, retirement_age, employment_type)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        
    elif command == "compare":
        # 退休年龄对比模式
        if len(sys.argv) < 6:
            print("对比分析参数不足")
            print("Usage: python calculate_retirement.py compare <birth_date> <gender> <job_type> <monthly_salary> [city] [employment_type] [include_housing_fund]")
            sys.exit(1)
        
        birth_date = sys.argv[2]
        gender = sys.argv[3]
        job_type = sys.argv[4]
        monthly_salary = float(sys.argv[5])
        city = sys.argv[6] if len(sys.argv) > 6 else "其他城市"
        employment_type = sys.argv[7] if len(sys.argv) > 7 else "employee"
        include_housing_fund = sys.argv[8].lower() == "true" if len(sys.argv) > 8 else True
        
        result = compare_retirement_ages(
            birth_date, gender, job_type, monthly_salary, 
            city, employment_type, include_housing_fund
        )
        print(json.dumps(result, ensure_ascii=False, indent=2))
        
    elif command == "payback":
        # 社保回本年限计算模式
        if len(sys.argv) < 6:
            print("回本计算参数不足")
            print("Usage: python calculate_retirement.py payback <birth_date> <gender> <job_type> <monthly_salary> [city] [employment_type] [include_housing_fund]")
            sys.exit(1)
        
        birth_date = sys.argv[2]
        gender = sys.argv[3]
        job_type = sys.argv[4]
        monthly_salary = float(sys.argv[5])
        city = sys.argv[6] if len(sys.argv) > 6 else "其他城市"
        employment_type = sys.argv[7] if len(sys.argv) > 7 else "employee"
        include_housing_fund = sys.argv[8].lower() == "true" if len(sys.argv) > 8 else True
        
        # 计算退休信息
        retirement_info = calculate_retirement_date(birth_date, gender, job_type)
        
        # 计算社保缴费总额
        insurance_info = calculate_social_insurance(
            monthly_salary,
            city,
            retirement_info["months_until_retirement"],
            employment_type,
            include_housing_fund
        )
        
        # 计算养老金
        years_to_retire = retirement_info["years_until_retirement"]
        total_years = max(15, years_to_retire)
        pension_info = calculate_pension(
            city, monthly_salary, total_years, retirement_info["retirement_age"], employment_type
        )
        
        # 计算回本年限
        payback_info = calculate_payback_period(
            insurance_info["total_payments"]["total"],
            pension_info["pension_details"]["total_monthly_pension"],
            pension_growth_rate=0.04,
            life_expectancy=80
        )
        
        # 合并结果
        result = {
            "user_info": {
                "birth_date": birth_date,
                "gender": "男性" if gender == "male" else "女性",
                "job_type": job_type,
                "monthly_salary": monthly_salary,
                "city": city,
                "employment_type": employment_type,
            },
            "retirement": retirement_info,
            "payback_analysis": payback_info,
            "summary": {
                "total_insurance_paid": insurance_info["total_payments"]["total"],
                "monthly_pension": pension_info["pension_details"]["total_monthly_pension"],
                "payback_years": payback_info["payback_analysis"]["exact_payback_years"],
                "payback_at_age": retirement_info["retirement_age"] + payback_info["payback_analysis"]["exact_payback_years"],
            }
        }
        
        print(json.dumps(result, ensure_ascii=False, indent=2))
        
    else:
        # 默认 calculate 模式（兼容旧用法）
        # 如果第一个参数不是命令，则当作 calculate 的参数处理
        if command in ["calculate", "male", "female"]:
            if command == "calculate":
                # 新格式：calculate 命令
                if len(sys.argv) < 6:
                    print("calculate 命令参数不足")
                    sys.exit(1)
                birth_date = sys.argv[2]
                gender = sys.argv[3]
                job_type = sys.argv[4]
                monthly_salary = float(sys.argv[5])
                city = sys.argv[6] if len(sys.argv) > 6 else "其他城市"
                employment_type = sys.argv[7] if len(sys.argv) > 7 else "employee"
                include_housing_fund = sys.argv[8].lower() == "true" if len(sys.argv) > 8 else True
            else:
                # 旧格式：直接是参数
                birth_date = sys.argv[1]
                gender = sys.argv[2]
                job_type = sys.argv[3]
                monthly_salary = float(sys.argv[4])
                city = sys.argv[5] if len(sys.argv) > 5 else "其他城市"
                employment_type = sys.argv[6] if len(sys.argv) > 6 else "employee"
                include_housing_fund = sys.argv[7].lower() == "true" if len(sys.argv) > 7 else True
            
            # 计算退休信息
            retirement_info = calculate_retirement_date(birth_date, gender, job_type)
            
            # 计算社保
            insurance_info = calculate_social_insurance(
                monthly_salary,
                city,
                retirement_info["months_until_retirement"],
                employment_type,
                include_housing_fund
            )
            
            # 计算养老金（假设从现在开始缴费到退休）
            years_to_retire = retirement_info["years_until_retirement"]
            total_years = max(15, years_to_retire)  # 假设至少有15年缴费（或从现在到退休的年限）
            pension_info = calculate_pension(
                city, monthly_salary, total_years, retirement_info["retirement_age"], employment_type
            )
            
            # 如果是对比模式，也计算另一种方式
            comparison = None
            if employment_type == "employee":
                flexible_info = calculate_social_insurance(
                    monthly_salary, city, retirement_info["months_until_retirement"], "flexible"
                )
                comparison = {
                    "flexible_alternative": flexible_info,
                    "note": f"如选择灵活就业，每月需多缴 ¥{round(flexible_info['monthly_payments']['total'] - insurance_info['monthly_payments']['total'], 2)}，退休前总计多缴 ¥{round(flexible_info['total_payments']['total'] - insurance_info['total_payments']['total'], 2)}"
                }
            
            # 合并结果
            result = {
                "retirement": retirement_info,
                "social_insurance": insurance_info,
                "pension": pension_info,
            }
            
            if comparison:
                result["comparison"] = comparison
            
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            print(f"未知命令: {command}")
            print("可用命令: calculate, pension, compare, payback")
            sys.exit(1)


if __name__ == "__main__":
    main()
