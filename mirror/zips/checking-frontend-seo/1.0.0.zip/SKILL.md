---
name: checking-frontend-seo
description: 当需要审查前端项目、落地页、SSR 或 SPA 应用、或生成后的 HTML 是否符合站内 SEO 规范时使用，尤其适用于检查标题、meta 标签、标题层级、链接、图片、语义化结构，以及输出可直接修复的问题报告。
---

# 前端 SEO 规范检查

## 概述

使用这个 skill 对前端源码或生成后的页面进行站内 SEO 合规检查。先运行内置扫描脚本完成机械规则检测，再结合人工判断审查标题质量、内容相关性和页面类型规范。

## 适用场景

- 前端项目上线前需要做 SEO 规范审查。
- 官网、营销页、专题页、内容页改版后需要做合规复查。
- 用户希望输出带问题、证据、严重级别和修复建议的检查报告。

不要将这个 skill 用于站外 SEO、关键词策略研究或纯数据分析类工作。

## 工作流程

1. 先确认检查对象。
   - 如果有构建产物或 SSR 输出，优先检查生成后的 HTML。
   - 如果只有前端仓库源码，则退回到源码层面检查。
2. 先运行扫描脚本：

```bash
python3 scripts/check_frontend_seo.py /path/to/project --format md
```

默认会在被检查项目根目录下生成 `frontend-seo-report.md`。如果需要指定输出位置，使用：

```bash
python3 scripts/check_frontend_seo.py /path/to/project --format md --output /path/to/seo-report.md
```

3. 阅读脚本输出后，再按 [references/checklist.md](./references/checklist.md) 进行人工复核。
4. 输出扁平化报告，至少包含：
   - `High`：阻断型 SEO 问题，或缺少必需元信息
   - `Medium`：会削弱 SEO 质量的结构或标记问题
   - `Manual`：必须人工判断的语义类问题

## 脚本检查范围

- 是否缺少 `title`、`meta description`、`meta keywords`
- 是否缺少 `h1` 或存在多个 `h1`
- `img` 是否缺少 `alt` 或 `title`
- `a` 和 `video` 是否缺少 `title`
- 外链是否缺少 `rel="nofollow"`
- 是否存在 `iframe`、`display:none`、`&nbsp;`、超大源码文件、语义化标签不足
- 页面类文件中是否存在重复的静态 `title` 或 `description`

扫描结果是启发式的。框架级 metadata API、动态标题、CMS 注入内容等场景仍然需要人工复核。

## 必做人工复核

- 标题是否虚假、模糊，或存在关键词堆砌
- 重要页面之间的标题和描述是否真正唯一
- 标题是否符合首页、列表页、聚合页、内容页的命名规范
- 核心内容是否依赖 JS 渲染，导致源码 HTML 中缺失
- 图片是否过大、未压缩，或上传大图后仅通过样式缩小显示

## 输出要求

输出报告时应尽量简洁，至少包含：

- 检查范围：扫描路径，以及基于源码还是构建产物进行判断
- 问题明细：严重级别、规则名、文件路径、具体修复建议
- 人工复核项：仍需人工确认的语义风险
- 修复优先级：上线前应优先处理的问题
- 报告文件：默认写入被检查项目下的 `frontend-seo-report.md`
