#!/usr/bin/env python3
"""用于扫描前端源码或生成页面的启发式 SEO 检查脚本。"""

from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass
from pathlib import Path

SCAN_EXTENSIONS = {
    ".html",
    ".htm",
    ".xhtml",
    ".jsx",
    ".tsx",
    ".vue",
    ".astro",
    ".svelte",
    ".mdx",
}
IGNORE_DIRS = {
    ".git",
    ".next",
    ".nuxt",
    ".svelte-kit",
    ".vercel",
    "coverage",
    "dist",
    "build",
    "node_modules",
    "vendor",
}
PAGE_PATH_HINTS = (
    "page",
    "layout",
    "route",
    "screen",
    "view",
    "index",
    "home",
    "article",
    "post",
    "product",
)
MANUAL_REVIEW_ITEMS = [
    "复核标题是否虚假、模糊，或存在关键词堆砌。",
    "确认关键页面和路由之间的标题、描述是否真正唯一。",
    "检查标题是否符合首页、列表页、聚合页、内容页的命名规范。",
    "确认核心 SEO 文本不是只依赖客户端渲染后才出现。",
    "检查图片是否做过压缩，以及资源尺寸是否明显大于实际展示尺寸。",
]

TITLE_HTML_RE = re.compile(r"<title\b[^>]*>(.*?)</title>", re.IGNORECASE | re.DOTALL)
TITLE_PROP_RE = re.compile(r"\btitle\s*:\s*([\"'`])(.+?)\1", re.IGNORECASE | re.DOTALL)
DESCRIPTION_HTML_RE = re.compile(
    r"<meta\b[^>]*name\s*=\s*([\"'])description\1[^>]*content\s*=\s*([\"'])(.*?)\2",
    re.IGNORECASE | re.DOTALL,
)
DESCRIPTION_PROP_RE = re.compile(
    r"\bdescription\s*:\s*([\"'`])(.+?)\1", re.IGNORECASE | re.DOTALL
)
HEAD_SCRIPT_RE = re.compile(r"<head\b.*?<script\b", re.IGNORECASE | re.DOTALL)
SEMANTIC_TAG_RE = re.compile(r"<(header|nav|main|article|section|footer)\b", re.IGNORECASE)
DISPLAY_NONE_RE = re.compile(r"display\s*:\s*none", re.IGNORECASE)
NBSP_RE = re.compile(r"&nbsp;", re.IGNORECASE)
H1_RE = re.compile(r"<h1\b", re.IGNORECASE)
IFRAME_RE = re.compile(r"<iframe\b", re.IGNORECASE)
IMG_RE = re.compile(r"<img\b[^>]*>", re.IGNORECASE | re.DOTALL)
VIDEO_RE = re.compile(r"<video\b[^>]*>", re.IGNORECASE | re.DOTALL)
ANCHOR_RE = re.compile(r"<a\b[^>]*>", re.IGNORECASE | re.DOTALL)
TAG_ATTR_RE = re.compile(r"([:@A-Za-z0-9_-]+)\s*=\s*(\".*?\"|'.*?'|\{.*?\})", re.DOTALL)


@dataclass
class Finding:
    severity: str
    rule: str
    message: str
    file: str
    line: int | None = None


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="扫描前端源码，执行可复用的站内 SEO 规则检查。")
    parser.add_argument("root", help="待扫描的项目根目录")
    parser.add_argument("--format", choices=("md", "json"), default="md", help="输出格式")
    parser.add_argument(
        "--output",
        help="报告输出路径。未指定时，Markdown 报告默认写入项目根目录下的 frontend-seo-report.md",
    )
    parser.add_argument(
        "--max-files", type=int, default=400, help="最多扫描多少个候选文件"
    )
    parser.add_argument(
        "--max-file-size-kb",
        type=int,
        default=500,
        help="当源码文件超过该大小时给出告警",
    )
    return parser.parse_args()


def iter_candidate_files(root: Path, max_files: int) -> list[Path]:
    files: list[Path] = []
    for path in root.rglob("*"):
        if any(part in IGNORE_DIRS for part in path.parts):
            continue
        if not path.is_file():
            continue
        if path.suffix.lower() not in SCAN_EXTENSIONS:
            continue
        files.append(path)
        if len(files) >= max_files:
            break
    return files


def read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return path.read_text(encoding="utf-8", errors="ignore")


def line_number(content: str, index: int) -> int:
    return content.count("\n", 0, index) + 1


def normalize_space(value: str) -> str:
    return re.sub(r"\s+", " ", value).strip()


def attrs_for_tag(tag: str) -> dict[str, str]:
    attrs: dict[str, str] = {}
    for name, value in TAG_ATTR_RE.findall(tag):
        attrs[name.lower()] = value.strip()
    return attrs


def quoted_value(raw: str) -> str:
    if len(raw) >= 2 and raw[0] in "\"'`" and raw[-1] == raw[0]:
        return raw[1:-1]
    return raw


def is_markup_file(content: str) -> bool:
    return bool(re.search(r"<[A-Za-z][^>]*>", content))


def is_page_like(path: Path, content: str) -> bool:
    suffix = path.suffix.lower()
    if suffix in {".html", ".htm", ".xhtml"}:
        return True
    lowered = str(path).lower()
    if any(hint in lowered for hint in PAGE_PATH_HINTS):
        return True
    page_signals = (
        "<title",
        "<head",
        "<h1",
        "generateMetadata(",
        "export const metadata",
        "useHead(",
        "useSeoMeta(",
        "<Helmet",
        "<Head",
    )
    return any(signal in content for signal in page_signals)


def extract_static_literal(regex: re.Pattern[str], content: str, group: int) -> str | None:
    match = regex.search(content)
    if not match:
        return None
    value = normalize_space(match.group(group))
    if "{" in value or "}" in value or "${" in value:
        return None
    return value or None


def add_finding(
    findings: list[Finding],
    severity: str,
    rule: str,
    message: str,
    path: Path,
    index: int | None = None,
) -> None:
    findings.append(
        Finding(
            severity=severity,
            rule=rule,
            message=message,
            file=str(path),
            line=line_number(read_text(path), index) if index is not None else None,
        )
    )


def has_title_signal(content: str) -> bool:
    return any(
        (
            re.search(r"<title\b", content, re.IGNORECASE),
            re.search(r"\btitle\s*:", content, re.IGNORECASE),
            re.search(r"\bgenerateMetadata\s*\(", content),
            re.search(r"\buseHead\s*\(", content),
            re.search(r"\buseSeoMeta\s*\(", content),
            re.search(r"<Helmet\b", content),
            re.search(r"<Head\b", content),
            re.search(r"\btitleTemplate\s*:", content, re.IGNORECASE),
        )
    )


def has_description_signal(content: str) -> bool:
    patterns = (
        r"<meta\b[^>]*name\s*=\s*([\"'])description\1",
        r"\bdescription\s*:",
        r"\buseSeoMeta\s*\(",
        r"\buseHead\s*\(",
        r"\bgenerateMetadata\s*\(",
    )
    return any(re.search(pattern, content, re.IGNORECASE) for pattern in patterns)


def has_keywords_signal(content: str) -> bool:
    patterns = (
        r"<meta\b[^>]*name\s*=\s*([\"'])keywords\1",
        r"\bkeywords\s*:",
    )
    return any(re.search(pattern, content, re.IGNORECASE) for pattern in patterns)


def analyze_markup(path: Path, content: str, findings: list[Finding], size_limit: int) -> None:
    size_bytes = path.stat().st_size
    if size_bytes > size_limit:
        add_finding(
            findings,
            "medium",
            "large-source-file",
            f"源码文件大小为 {size_bytes // 1024} KB，超过了配置的 500 KB 建议阈值。",
            path,
        )

    if IFRAME_RE.search(content):
        match = IFRAME_RE.search(content)
        add_finding(
            findings,
            "high",
            "iframe-used",
            "重要内容应避免使用 iframe，因为这类内容通常不利于 SEO 抓取。",
            path,
            match.start() if match else None,
        )

    if DISPLAY_NONE_RE.search(content):
        match = DISPLAY_NONE_RE.search(content)
        add_finding(
            findings,
            "medium",
            "display-none-content",
            "发现 display:none。被隐藏的 SEO 文本需要重点复核。",
            path,
            match.start() if match else None,
        )

    nbsp_count = len(NBSP_RE.findall(content))
    if nbsp_count:
        match = NBSP_RE.search(content)
        add_finding(
            findings,
            "low",
            "nbsp-used",
            f"发现 {nbsp_count} 处 &nbsp;；建议使用 CSS 处理间距和缩进。",
            path,
            match.start() if match else None,
        )

    img_tags = list(IMG_RE.finditer(content))
    img_missing_alt = 0
    img_missing_title = 0
    img_line = None
    for match in img_tags:
        attrs = attrs_for_tag(match.group(0))
        if "alt" not in attrs:
            img_missing_alt += 1
            img_line = img_line or match.start()
        if "title" not in attrs:
            img_missing_title += 1
            img_line = img_line or match.start()
    if img_missing_alt:
        add_finding(
            findings,
            "high",
            "img-missing-alt",
            f"发现 {img_missing_alt} 个图片标签缺少 alt 文本。",
            path,
            img_line,
        )
    if img_missing_title:
        add_finding(
            findings,
            "medium",
            "img-missing-title",
            f"发现 {img_missing_title} 个图片标签缺少 title 文本。",
            path,
            img_line,
        )

    video_tags = list(VIDEO_RE.finditer(content))
    video_missing_title = 0
    video_line = None
    for match in video_tags:
        attrs = attrs_for_tag(match.group(0))
        if "title" not in attrs:
            video_missing_title += 1
            video_line = video_line or match.start()
    if video_missing_title:
        add_finding(
            findings,
            "medium",
            "video-missing-title",
            f"发现 {video_missing_title} 个视频标签缺少 title 文本。",
            path,
            video_line,
        )

    anchor_tags = list(ANCHOR_RE.finditer(content))
    anchor_missing_title = 0
    external_missing_nofollow = 0
    link_line = None
    for match in anchor_tags:
        attrs = attrs_for_tag(match.group(0))
        if "title" not in attrs:
            anchor_missing_title += 1
            link_line = link_line or match.start()
        href = quoted_value(attrs.get("href", ""))
        rel = quoted_value(attrs.get("rel", "")).lower()
        if href.startswith(("http://", "https://")) and "nofollow" not in rel:
            external_missing_nofollow += 1
            link_line = link_line or match.start()
    if anchor_missing_title:
        add_finding(
            findings,
            "medium",
            "anchor-missing-title",
            f"发现 {anchor_missing_title} 个链接标签缺少 title 文本。",
            path,
            link_line,
        )
    if external_missing_nofollow:
        add_finding(
            findings,
            "high",
            "external-link-missing-nofollow",
            f"发现 {external_missing_nofollow} 个外链缺少 rel=\"nofollow\"。",
            path,
            link_line,
        )


def analyze_page_like(path: Path, content: str, findings: list[Finding]) -> tuple[str | None, str | None]:
    if not has_title_signal(content):
        add_finding(
            findings,
            "high",
            "missing-title-signal",
            "这个页面类文件中没有发现 title 信号。",
            path,
        )
    if not has_description_signal(content):
        add_finding(
            findings,
            "high",
            "missing-description-signal",
            "这个页面类文件中没有发现 description 信号。",
            path,
        )
    if not has_keywords_signal(content):
        add_finding(
            findings,
            "high",
            "missing-keywords-signal",
            "这个页面类文件中没有发现 keywords 信号。",
            path,
        )

    h1_matches = list(H1_RE.finditer(content))
    if len(h1_matches) == 0:
        add_finding(
            findings,
            "medium",
            "missing-h1",
            "这个页面类文件中没有发现 h1。",
            path,
        )
    elif len(h1_matches) > 1:
        add_finding(
            findings,
            "medium",
            "multiple-h1",
            f"发现 {len(h1_matches)} 个 h1；应只保留一个主 h1。",
            path,
            h1_matches[1].start(),
        )

    if not SEMANTIC_TAG_RE.search(content):
        add_finding(
            findings,
            "low",
            "weak-semantic-structure",
            "未发现 nav、main、article、section 等语义化结构标签。",
            path,
        )

    if HEAD_SCRIPT_RE.search(content):
        match = HEAD_SCRIPT_RE.search(content)
        add_finding(
            findings,
            "high",
            "script-in-head",
            "发现 head 中存在 script；应复核这部分 JS 是否可以移到 body 结束前。",
            path,
            match.start() if match else None,
        )

    title_value = extract_static_literal(TITLE_HTML_RE, content, 1) or extract_static_literal(
        TITLE_PROP_RE, content, 2
    )
    description_value = extract_static_literal(
        DESCRIPTION_HTML_RE, content, 3
    ) or extract_static_literal(DESCRIPTION_PROP_RE, content, 2)
    return title_value, description_value


def render_markdown(
    root: Path,
    scanned: list[Path],
    findings: list[Finding],
    duplicate_titles: dict[str, list[str]],
    duplicate_descriptions: dict[str, list[str]],
) -> str:
    counts = Counter(item.severity for item in findings)
    lines = [
        "# 前端 SEO 检查报告",
        "",
        f"- 项目路径：`{root}`",
        f"- 扫描文件数：{len(scanned)}",
        f"- 问题总数：{len(findings)}",
        f"- 严重级别统计：high={counts['high']}，medium={counts['medium']}，low={counts['low']}",
        "",
        "## 问题明细",
    ]

    if not findings:
        lines.extend(["", "自动扫描未发现问题，但仍需进行人工复核。"])
    else:
        for finding in sorted(findings, key=lambda item: (item.file, item.line or 0, item.rule)):
            location = f"{finding.file}:{finding.line}" if finding.line else finding.file
            lines.append(
                f"- [{finding.severity.upper()}] `{finding.rule}`，位置 `{location}`：{finding.message}"
            )

    if duplicate_titles:
        lines.extend(["", "## 重复的静态标题"])
        for value, files in sorted(duplicate_titles.items()):
            lines.append(f"- `{value}`")
            for file_path in files:
                lines.append(f"  - `{file_path}`")

    if duplicate_descriptions:
        lines.extend(["", "## 重复的静态描述"])
        for value, files in sorted(duplicate_descriptions.items()):
            lines.append(f"- `{value}`")
            for file_path in files:
                lines.append(f"  - `{file_path}`")

    lines.extend(["", "## 仍需人工复核"])
    for item in MANUAL_REVIEW_ITEMS:
        lines.append(f"- {item}")
    return "\n".join(lines)


def default_output_path(root: Path, output_format: str) -> Path | None:
    if output_format == "md":
        return root / "frontend-seo-report.md"
    return None


def write_report(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def main() -> int:
    args = parse_args()
    root = Path(args.root).resolve()
    if not root.exists():
        print(f"路径不存在：{root}", file=sys.stderr)
        return 1

    scanned = iter_candidate_files(root, args.max_files)
    findings: list[Finding] = []
    static_titles: defaultdict[str, list[str]] = defaultdict(list)
    static_descriptions: defaultdict[str, list[str]] = defaultdict(list)
    size_limit = args.max_file_size_kb * 1024

    for path in scanned:
        content = read_text(path)
        if not is_markup_file(content):
            continue

        analyze_markup(path, content, findings, size_limit)

        if is_page_like(path, content):
            title_value, description_value = analyze_page_like(path, content, findings)
            if title_value:
                static_titles[title_value].append(str(path))
            if description_value:
                static_descriptions[description_value].append(str(path))

    duplicate_titles = {key: value for key, value in static_titles.items() if len(value) > 1}
    duplicate_descriptions = {
        key: value for key, value in static_descriptions.items() if len(value) > 1
    }

    for value, files in duplicate_titles.items():
        for file_path in files:
            findings.append(
                Finding(
                    severity="medium",
                    rule="duplicate-static-title",
                    message=f"静态 title 文案在多个文件中重复使用：{value}",
                    file=file_path,
                )
            )
    for value, files in duplicate_descriptions.items():
        for file_path in files:
            findings.append(
                Finding(
                    severity="medium",
                    rule="duplicate-static-description",
                    message=f"静态 description 文案在多个文件中重复使用：{value}",
                    file=file_path,
                )
            )

    payload = {
        "project": str(root),
        "scanned_files": [str(path) for path in scanned],
        "findings": [asdict(item) for item in findings],
        "manual_review_required": MANUAL_REVIEW_ITEMS,
        "duplicate_titles": duplicate_titles,
        "duplicate_descriptions": duplicate_descriptions,
    }

    if args.format == "json":
        content = json.dumps(payload, ensure_ascii=False, indent=2)
    else:
        content = render_markdown(
            root=root,
            scanned=scanned,
            findings=findings,
            duplicate_titles=duplicate_titles,
            duplicate_descriptions=duplicate_descriptions,
        )

    output_path = Path(args.output).expanduser().resolve() if args.output else default_output_path(root, args.format)
    if output_path is not None:
        write_report(output_path, content)
        print(f"报告已生成：{output_path}")
        print(f"扫描文件数：{len(scanned)}")
        print(f"问题总数：{len(findings)}")
        return 0

    print(content)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
