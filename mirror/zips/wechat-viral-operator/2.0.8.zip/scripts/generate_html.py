#!/usr/bin/env python3
"""
微信公众号HTML生成脚本
输出：纯内联样式HTML（0个style标签，0个class），微信100%兼容
"""

import re
import sys
from pathlib import Path


# =====================================================================
# 内联样式常量
# =====================================================================
STYLE_BODY = (
    'margin: 0; padding: 0; '
    'background-color: #f5f3f0; '
    'font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", sans-serif;'
)
STYLE_CARD = (
    'background-color: #ffffff; '
    'max-width: 600px; margin: 0 auto;'
)
STYLE_MAIN_TD = 'padding: 24px 20px;'
STYLE_H1 = (
    'margin: 0 0 24px 0; '
    'font-size: 22px; font-weight: bold; color: #1a1a1a; '
    'line-height: 1.4; border-bottom: 2px solid #c9a227; padding-bottom: 16px;'
)
STYLE_META = (
    'font-size: 13px; color: #999; margin-bottom: 20px; '
    'padding-bottom: 12px; border-bottom: 1px solid #e8e4df;'
)
STYLE_P = (
    'margin: 0 0 16px 0; font-size: 16px; line-height: 1.75; color: #333;'
)
STYLE_H2 = (
    'margin: 28px 0 16px 0; font-size: 20px; font-weight: bold; color: #1a1a1a; line-height: 1.4;'
)
STYLE_H3 = (
    'margin: 20px 0 12px 0; font-size: 17px; font-weight: bold; color: #333; line-height: 1.4;'
)
STYLE_BLOCKQUOTE = (
    'margin: 20px 0; padding: 16px 20px; '
    'background-color: #faf8f5; border: 1px solid #e8e4df;'
)
STYLE_BQ_P = 'margin: 0; font-style: italic; color: #555; line-height: 1.7;'
STYLE_HIGHLIGHT = (
    'margin: 20px 0; padding: 16px 20px; '
    'background-color: #fff9e6; border-left: 4px solid #c9a227;'
)
STYLE_HL_P = 'margin: 0; color: #333; line-height: 1.7;'
STYLE_CHAPTER_WRAP = 'margin: 28px 0 16px 0;'
STYLE_CHAPTER_INNER = 'border-bottom: 2px solid #c9a227; padding-bottom: 12px;'
STYLE_CHAPTER_NUM = (
    'margin: 0 0 4px 0; '
    'font-size: 11px; color: #c9a227; text-transform: uppercase; letter-spacing: 2px;'
)
STYLE_CHAPTER_TITLE = 'margin: 0 0 4px 0; font-size: 18px; font-weight: bold; color: #1a1a1a;'
STYLE_CHAPTER_SUB = 'margin: 0; font-size: 14px; color: #666;'
STYLE_STRONG = 'color: #c9a227; font-weight: bold;'
STYLE_EM = 'color: #666;'
STYLE_HR = (
    'margin: 24px auto; height: 1px; background-color: #e8e4df; border: none; width: 80%;'
)
STYLE_IMG = (
    'max-width: 100%; height: auto; display: block; margin: 16px auto; border-radius: 4px;'
)
STYLE_UL = 'margin: 16px 0; padding-left: 24px;'
STYLE_LI = 'margin-bottom: 8px; list-style-type: disc; font-size: 16px; line-height: 1.7; color: #333;'


def esc(s):
    """HTML实体转义（防注入 + 防歧义）"""
    return (s
            .replace('&', '&amp;')
            .replace('<', '&lt;')
            .replace('>', '&gt;')
            .replace('"', '&quot;'))


def inline(tag, content, style):
    """生成带内联样式的标签"""
    return f'<{tag} style="{style}">{content}</{tag}>'


def build_wrapper(body_content):
    """构建完整HTML外壳（顶部+底部装饰条）"""
    return f'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
</head>
<body style="{STYLE_BODY}">
<!-- 顶部装饰 -->
<table width="100%" cellpadding="0" cellspacing="0" border="0">
<tr><td height="6" style="background-color: #1a1a2e;"></td></tr>
</table>
<!-- 主容器 -->
<table width="100%" cellpadding="0" cellspacing="0" border="0">
<tr>
<td style="padding: 20px 16px;">
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="{STYLE_CARD}">
<tr>
<td style="{STYLE_MAIN_TD}">
{body_content}
</td>
</tr>
</table>
</td>
</tr>
</table>
<!-- 底部装饰 -->
<table width="100%" cellpadding="0" cellspacing="0" border="0">
<tr><td height="6" style="background-color: #1a1a2e;"></td></tr>
</table>
</body>
</html>'''


def md_to_html(text):
    """
    将Markdown文本转换为纯内联样式HTML片段。
    支持：
    - h1 / ## h2 / ### h3
    - 普通段落（支持 **bold**、*italic*、==highlight==）
    - > 引用块
    - - 无序列表
    - 分割线 ---
    - 章节块（CHAPTER ONE / 一二三四五六七八九十）
    - 原始HTML段落（直接透传）
    """
    parts = []
    lines = text.strip().split('\n')
    i = 0

    def flush_ul(buf, parts):
        if buf:
            ul_inner = '\n'.join(
                f'<li style="{STYLE_LI}">{esc(item)}</li>' for item in buf
            )
            parts.append(f'<ul style="{STYLE_UL}">{ul_inner}</ul>')

    while i < len(lines):
        raw = lines[i]
        line = raw.strip()

        # 空行
        if not line:
            i += 1
            continue

        # ===== 分割线 =====
        if re.match(r'^---+$', line):
            parts.append(f'<hr style="{STYLE_HR}">')
            i += 1
            continue

        # ===== h1 / ## h2 / ### h3 =====
        if line.startswith('### '):
            t = esc(line[4:])
            parts.append(inline('h3', t, STYLE_H3))
            i += 1
            continue
        if line.startswith('## '):
            t = esc(line[3:])
            parts.append(inline('h2', t, STYLE_H2))
            i += 1
            continue

        # ===== 章节标题（CHAPTER ONE / 一二三四五六七八九十） =====
        # CHAPTER X（独立一行，后面跟中文小标题）
        chapter_match = re.match(r'^(CHAPTER\s+[A-Z]+)\s*$', line, re.IGNORECASE)
        if chapter_match:
            en_title = chapter_match.group(1).upper()
            zh_title = ''
            zh_sub = ''
            # 尝试读下一行（中文标题）
            if i + 1 < len(lines):
                next_line = lines[i + 1].strip()
                if next_line and not next_line.startswith('##') and not next_line.startswith('>') and not next_line.startswith('-') and not re.match(r'^---+$', next_line) and not next_line.startswith('**'):
                    zh_title = next_line
                    i += 1
                    # 再读下一行（副标题/小节说明）
                    if i + 1 < len(lines):
                        sub_line = lines[i + 1].strip()
                        if sub_line and not sub_line.startswith('##') and not sub_line.startswith('>') and not sub_line.startswith('-') and not re.match(r'^---+$', sub_line):
                            zh_sub = sub_line
                            i += 1
            # 构建章节块
            inner = ''
            inner += f'<div style="{STYLE_CHAPTER_NUM}">{esc(en_title)}</div>'
            if zh_title:
                inner += f'<div style="{STYLE_CHAPTER_TITLE}">{esc(zh_title)}</div>'
            if zh_sub:
                inner += f'<div style="{STYLE_CHAPTER_SUB}">{esc(zh_sub)}</div>'
            chapter_html = (
                f'<div style="{STYLE_CHAPTER_WRAP}">'
                f'<div style="{STYLE_CHAPTER_INNER}">{inner}</div>'
                f'</div>'
            )
            parts.append(chapter_html)
            i += 1
            continue

        # ===== 引用块 =====
        if line.startswith('>'):
            # 收集连续引用行
            quote_lines = []
            while i < len(lines) and lines[i].strip().startswith('>'):
                quote_lines.append(lines[i].strip()[1:].strip())
                i += 1
            content = ' '.join(esc(q) for q in quote_lines)
            parts.append(
                f'<div style="{STYLE_BLOCKQUOTE}">'
                f'<p style="{STYLE_BQ_P}">{content}</p>'
                f'</div>'
            )
            continue

        # ===== 无序列表 =====
        if line.startswith('- ') or line.startswith('* '):
            buf = [line[2:]]
            j = i + 1
            while j < len(lines) and (lines[j].strip().startswith('- ') or lines[j].strip().startswith('* ')):
                buf.append(lines[j].strip()[2:])
                j += 1
            flush_ul(buf, parts)
            i = j
            continue

        # ===== 普通段落：inline格式化 =====
        # HTML标签段落直接透传（以<table/等开头）
        if re.match(r'^<(table|div|section|p|img|figure)', line, re.I):
            parts.append(line)
        else:
            # **bold**、*italic*、==highlight==
            formatted = esc(line)
            formatted = re.sub(r'\*\*(.+?)\*\*', rf'<strong style="{STYLE_STRONG}">\1</strong>', formatted)
            formatted = re.sub(r'\*(.+?)\*', rf'<em style="{STYLE_EM}">\1</em>', formatted)
            formatted = re.sub(r'==(.+?)==', r'<strong style="background-color:#fff3cd;padding:2px 4px;">\1</strong>', formatted)
            parts.append(inline('p', formatted, STYLE_P))
        i += 1

    return '\n'.join(parts)


def markdown_to_wechat_html(markdown_text, title="", author=""):
    """
    主入口：Markdown → 纯内联样式HTML（完整页面）
    """
    body_parts = []

    # 主标题
    if title:
        body_parts.append(inline('h1', esc(title), STYLE_H1))

    # 元信息
    if author:
        body_parts.append(inline('p', f'作者：{esc(author)}', STYLE_META))

    # 正文
    body_parts.append(md_to_html(markdown_text))

    body_content = '\n'.join(body_parts)
    return build_wrapper(body_content)


def generate_wechat_html(title, content, author="", cover_image=""):
    """
    兼容旧API：generate_wechat_html(title, content, author, cover_image)
    cover_image 仅在本地预览时嵌入，微信同步时不需要（用 thumb_media_id）
    """
    html = markdown_to_wechat_html(content, title, author)
    # 封面图（仅预览用）
    if cover_image:
        img_tag = f'<img src="{esc(cover_image)}" style="{STYLE_IMG}" alt="封面图">'
        html = html.replace('</head>', f'{img_tag}\n</head>', 1)
    return html


def main():
    if len(sys.argv) < 3:
        print("用法: python generate_html.py <标题> <内容文件.md> [输出.html]")
        sys.exit(1)
    title = sys.argv[1]
    content_file = Path(sys.argv[2])
    output_file = Path(sys.argv[3]) if len(sys.argv) > 3 else content_file.with_suffix('.html')
    if not content_file.exists():
        print(f"错误: 找不到文件 {content_file}")
        sys.exit(1)
    content = content_file.read_text(encoding='utf-8')
    html = generate_wechat_html(title, content)
    output_file.write_text(html, encoding='utf-8')
    print(f"HTML已生成: {output_file}")
    print(f"字符数: {len(html)} | style标签数: {html.count('<style')}")


if __name__ == "__main__":
    main()
