#!/usr/bin/env python3
"""
微信公众号文章预览服务器
启动本地HTTP服务器，方便在浏览器中预览生成的HTML文章
"""

import http.server
import socketserver
import sys
import os
import webbrowser
from pathlib import Path
import threading

DEFAULT_PORT = 8080
DEFAULT_DIRECTORY = os.getcwd()


def start_server(port=DEFAULT_PORT, directory=DEFAULT_DIRECTORY, open_browser=True):
    """
    启动本地预览服务器

    Args:
        port: 端口号，默认8080
        directory: 服务目录，默认当前目录
        open_browser: 是否自动打开浏览器
    """
    os.chdir(directory)

    handler = http.server.SimpleHTTPRequestHandler

    # 设置默认编码
    handler.extensions_map.update({
        '.html': 'text/html; charset=utf-8',
        '.css': 'text/css; charset=utf-8',
        '.js': 'application/javascript; charset=utf-8',
        '.json': 'application/json; charset=utf-8',
        '.png': 'image/png',
        '.jpg': 'image/jpeg',
        '.gif': 'image/gif',
        '.svg': 'image/svg+xml',
    })

    with socketserver.TCPServer(("", port), handler) as httpd:
        url = f"http://localhost:{port}"

        print(f"""
╔════════════════════════════════════════════════════════════╗
║           微信公众号文章预览服务器                          ║
╠════════════════════════════════════════════════════════════╣
║  服务地址: {url:<47}║
║  服务目录: {directory:<47}║
╠════════════════════════════════════════════════════════════╣
║  提示:                                                      ║
║  - 在浏览器中打开上述地址预览文章                          ║
║  - 按 Ctrl+C 停止服务器                                    ║
╚════════════════════════════════════════════════════════════╝
""")

        if open_browser:
            # 延迟打开浏览器，确保服务器已启动
            def delayed_open():
                import time
                time.sleep(0.5)
                webbrowser.open(url)

            threading.Thread(target=delayed_open, daemon=True).start()

        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n服务器已停止")


def main():
    """命令行入口"""
    port = DEFAULT_PORT
    directory = DEFAULT_DIRECTORY

    args = sys.argv[1:]
    if '--help' in args or '-h' in args:
        print("""
用法: python preview_server.py [端口号] [目录路径]

示例:
  python preview_server.py                # 使用默认设置
  python preview_server.py 9000            # 使用9000端口
  python preview_server.py 9000 ./articles # 指定端口和目录
  python preview_server.py --no-browser    # 不自动打开浏览器
""")
        sys.exit(0)

    open_browser = True
    if '--no-browser' in args:
        open_browser = False
        args.remove('--no-browser')

    if len(args) >= 1:
        try:
            port = int(args[0])
        except ValueError:
            print(f"错误: 无效的端口号 '{args[0]}'")
            sys.exit(1)

    if len(args) >= 2:
        directory = args[1]

    if not os.path.isdir(directory):
        print(f"错误: 目录不存在 '{directory}'")
        sys.exit(1)

    start_server(port, directory, open_browser)


if __name__ == "__main__":
    main()
