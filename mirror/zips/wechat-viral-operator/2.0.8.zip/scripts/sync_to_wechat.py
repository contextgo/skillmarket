#!/usr/bin/env python3
"""
微信公众号文章同步脚本
修复版（2026-04-21）：
1. 乱码修复：ensure_ascii=False + UTF-8 bytes 发送
2. 排版修复：不再依赖 <style> 标签（HTML生成脚本已全面内联）
3. body提取：改为取 <body>...</body> 内容，而非截取 table
4. 微信裁剪参数：pic_crop_235_1 / pic_crop_1_1
"""

import json
import requests
import re
import os
import sys
import time
from pathlib import Path

# skill根目录（供外部导入时能正常找到同级模块）
sys.path.insert(0, str(Path(__file__).parent))


# =====================================================================
# 凭证管理（临时存储，不落文件）
# =====================================================================
_access_token_cache = {"token": None, "expires_at": 0}


def get_access_token(appid, appsecret):
    """获取 access_token（带内存缓存，5分钟内不重复请求）"""
    now = time.time()
    if _access_token_cache["token"] and _access_token_cache["expires_at"] > now + 60:
        return _access_token_cache["token"]

    url = (f"https://api.weixin.qq.com/cgi-bin/token"
           f"?grant_type=client_credential&appid={appid}&secret={appsecret}")
    try:
        resp = requests.get(url, timeout=30)
        result = resp.json()
        if "access_token" in result:
            _access_token_cache["token"] = result["access_token"]
            _access_token_cache["expires_at"] = now + result.get("expires_in", 7200)
            return result["access_token"]
        else:
            print(f"[FAIL] 获取access_token失败: {result}")
            return None
    except Exception as e:
        print(f"[FAIL] 请求异常: {e}")
        return None


def upload_image(access_token, image_path):
    """上传图片/封面图到公众号素材库，返回 media_id"""
    url = f"https://api.weixin.qq.com/cgi-bin/media/upload?access_token={access_token}&type=image"
    try:
        with open(image_path, "rb") as f:
            resp = requests.post(url, files={"media": f}, timeout=60)
        result = resp.json()
        if "media_id" in result:
            return result["media_id"]
        print(f"[FAIL] 上传图片失败: {result}")
        return None
    except Exception as e:
        print(f"[FAIL] 上传图片异常: {e}")
        return None


# =====================================================================
# 文本清洗（防止乱码）
# =====================================================================
def clean_text(text):
    """移除控制字符，保留换行/制表符"""
    text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', text)
    text = re.sub(r'[\u200b-\u200f\ufeff]', '', text)
    return text


def clean_html(html):
    """清洗HTML（移除微信不支持的标签，保留内联样式）"""
    html = re.sub(r'<style[^>]*>.*?</style>', '', html, flags=re.DOTALL | re.IGNORECASE)
    html = re.sub(r'<link[^>]*>', '', html, flags=re.IGNORECASE)
    html = re.sub(r'<script[^>]*>.*?</script>', '', html, flags=re.DOTALL | re.IGNORECASE)
    html = re.sub(r'<!--.*?-->', '', html, flags=re.DOTALL)
    return html.strip()


def extract_body_content(html):
    """
    从HTML中提取正文内容（<body>标签内的内容）。
    微信只需要正文，不需要 <html>/<head>/<body> 外壳。
    如果没有 body 标签则返回完整内容。
    """
    match = re.search(r'<body[^>]*>(.*?)</body>', html, re.DOTALL | re.IGNORECASE)
    if match:
        return match.group(1).strip()
    return html.strip()


def validate_title(title, max_len=64):
    """截取超长标题"""
    if len(title) <= max_len:
        return title
    truncated = title[:max_len - 3] + "..."
    print(f"[WARN] 标题超长({len(title)}字符)，已截取: {truncated}")
    return truncated


def validate_digest(digest, max_len=120):
    """截取超长摘要"""
    if len(digest) <= max_len:
        return digest
    return digest[:max_len - 3] + "..."


# =====================================================================
# 草稿上传（核心修复：ensure_ascii=False）
# =====================================================================
def create_draft(access_token, title, author, digest, content,
                 thumb_media_id=None, crop235=True, crop11=True):
    """
    创建微信草稿。
    修复：手动 json.dumps(ensure_ascii=False) + UTF-8 bytes，
         彻底避免 requests 内部默认转义中文为 \\uXXXX。
    """
    url = f"https://api.weixin.qq.com/cgi-bin/draft/add?access_token={access_token}"
    article = {
        "title": title,
        "author": author,
        "digest": digest,
        "content": content,
        "content_source_url": "",
        "need_open_comment": 1,
        "only_fans_can_comment": 0,
        "pic_crop_235_1": 1 if crop235 else 0,
        "pic_crop_1_1": 1 if crop11 else 0,
    }
    if thumb_media_id:
        article["thumb_media_id"] = thumb_media_id

    payload = json.dumps({"articles": [article]}, ensure_ascii=False).encode("utf-8")
    headers = {"Content-Type": "application/json; charset=utf-8"}
    try:
        resp = requests.post(url, data=payload, headers=headers, timeout=60)
        return resp.json()
    except Exception as e:
        return {"errcode": -1, "errmsg": str(e)}


# =====================================================================
# 主同步流程
# =====================================================================
def sync_article(appid, appsecret, html_file, title,
                 digest="", author="", cover_image=None,
                 crop235=True, crop11=True):
    """
    同步文章到微信公众号草稿箱。

    参数：
        appid / appsecret: 公众号凭证
        html_file: HTML文件路径
        title: 文章标题（自动截取≤64字符）
        digest: 摘要（自动截取≤120字符，不填则自动生成）
        author: 作者
        cover_image: 封面图路径（可选，PNG/JPG均可）
        crop235 / crop11: 封面图裁剪参数（默认True，自动裁剪）
    """
    print("=" * 50)
    print("📤 微信草稿同步")
    print("=" * 50)

    # 1. 读取HTML
    with open(html_file, 'r', encoding='utf-8') as f:
        html = f.read()
    print(f"[OK] 读取HTML: {len(html)} 字符 | style标签: {html.count('<style')}")

    # 2. 清洗
    html = clean_html(html)
    html = clean_text(html)

    # 3. 提取body内容（微信只需要正文，不要外壳）
    body = extract_body_content(html)
    print(f"[OK] 提取正文: {len(body)} 字符")

    # 4. 标题/摘要
    title = validate_title(title)
    print(f"  标题: {title}")
    if not digest:
        plain = re.sub(r'<[^>]+>', '', body)
        digest = plain[:100] + ("..." if len(plain) > 100 else "")
    digest = validate_digest(digest)
    print(f"  摘要: {digest}")
    print(f"  作者: {author or '（无）'}")

    # 5. 获取token
    token = get_access_token(appid, appsecret)
    if not token:
        return None

    # 6. 上传封面图
    thumb_id = None
    if cover_image and os.path.exists(cover_image):
        print(f"[...] 上传封面图: {cover_image}")
        thumb_id = upload_image(token, cover_image)
        if thumb_id:
            print(f"[OK] 封面图 media_id: {thumb_id}")
        else:
            print("[WARN] 封面图上传失败，将不带封面图同步")

    # 7. 创建草稿
    print("[...] 创建草稿...")
    result = create_draft(token, title, author, digest, body,
                          thumb_id, crop235, crop11)

    if "media_id" in result:
        mid = result["media_id"]
        print("=" * 50)
        print(f"✅ 草稿创建成功！")
        print(f"   media_id: {mid}")
        print(f"   请登录公众号后台 → 内容与互动 → 草稿箱 查看")
        print("=" * 50)
        return mid
    else:
        print(f"[FAIL] 草稿创建失败: {result}")
        return None


# =====================================================================
# 命令行入口
# =====================================================================
def main():
    if len(sys.argv) < 5:
        print("用法: python sync_to_wechat.py <appid> <appsecret> <html文件> <标题> [摘要] [作者] [封面图]")
        print("示例: python sync_to_wechat.py wx12345678 abcdefghi article.html '我的标题' '摘要' '作者名' cover.png")
        sys.exit(1)

    appid     = sys.argv[1]
    appsecret = sys.argv[2]
    html_file = sys.argv[3]
    title     = sys.argv[4]
    digest    = sys.argv[5] if len(sys.argv) > 5 else ""
    author    = sys.argv[6] if len(sys.argv) > 6 else ""
    cover     = sys.argv[7] if len(sys.argv) > 7 else None

    sync_article(appid, appsecret, html_file, title, digest, author, cover)


if __name__ == "__main__":
    main()
