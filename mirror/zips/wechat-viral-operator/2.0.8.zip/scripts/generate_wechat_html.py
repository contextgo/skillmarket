#!/usr/bin/env python3
"""
微信公众号HTML生成脚本（微信原生兼容版）
使用表格布局，确保微信兼容性
"""

import re
import sys
from pathlib import Path


def generate_cover_image_prompt(title, theme=""):
    """
    生成封面图提示词
    
    Args:
        title: 文章标题
        theme: 文章主题/领域
    
    Returns:
        str: 图片生成提示词
    """
    base_prompt = f"""A professional and elegant cover image for a WeChat article.
Title theme: {title}
Style: Clean, modern, minimalist design
Colors: Deep blue (#1a1a2e) as primary, gold (#c9a227) as accent, light background
Size: 900x500 pixels, landscape orientation
Elements: Abstract geometric shapes, subtle gradients (if any), professional typography feel
Mood: Sophisticated, trustworthy, professional
No text in the image, pure visual design
"""
    
    if "财务" in theme or "finance" in theme.lower():
        base_prompt += """
Additional elements: Subtle financial symbols (charts, graphs, abstract data visualization), 
corporate professional style, clean lines, business aesthetic
"""
    
    return base_prompt.strip()


def markdown_to_wechat_html(markdown_text, title="", author=""):
    """
    将 Markdown 转换为微信原生兼容的 HTML（表格布局）
    
    Args:
        markdown_text: Markdown 格式的文章内容
        title: 文章标题
        author: 作者名称
    
    Returns:
        str: 微信公众号适配的 HTML 代码（表格布局）
    """
    html_parts = []
    
    # HTML 头部
    html_parts.append('''<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>''')
    html_parts.append(title if title else "文章")
    html_parts.append('''</title>
</head>
<body style="margin: 0; padding: 0; background-color: #f5f3f0;">
''')
    
    # 顶部装饰条
    html_parts.append('''    <!-- 顶部装饰条 -->
    <table width="100%" cellpadding="0" cellspacing="0" border="0">
        <tr><td height="8" style="background-color: #1a1a2e; line-height: 0; font-size: 0;"></td></tr>
    </table>
    
    <!-- 主容器 -->
    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color: #f5f3f0;">
        <tr>
            <td style="padding: 20px 16px;">
                <!-- 内容卡片 -->
                <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color: #ffffff; max-width: 600px; margin: 0 auto;">
                    <tr>
                        <td style="padding: 24px 20px;">
''')
    
    # 标题区域
    if title:
        html_parts.append(f'''                            <!-- 标题区域 -->
                            <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom: 24px;">
                                <tr>
                                    <td style="border-bottom: 2px solid #c9a227; padding-bottom: 16px;">
                                        <h1 style="margin: 0; font-size: 22px; font-weight: bold; color: #1a1a1a; line-height: 1.4; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', sans-serif;">{title}</h1>
                                    </td>
                                </tr>
                            </table>
''')
    
    # 作者信息
    if author:
        html_parts.append(f'''                            <!-- 作者信息 -->
                            <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom: 20px;">
                                <tr>
                                    <td style="font-size: 14px; color: #999;">
                                        作者：{author}
                                    </td>
                                </tr>
                            </table>
''')
    
    # 处理 Markdown 内容
    lines = markdown_text.strip().split('\n')
    in_list = False
    list_items = []
    list_type = 'ul'  # 'ul' 或 'ol'
    
    for i, line in enumerate(lines):
        line = line.strip()
        
        # 空行处理
        if not line:
            if in_list:
                # 结束列表
                html_parts.append(f'                                    </{list_type}>\n')
                html_parts.append('                                </td>\n')
                html_parts.append('                            </tr>\n')
                html_parts.append('                        </table>\n')
                in_list = False
                list_items = []
            continue
        
        # 章节标题处理（## 或 ###）
        if line.startswith('## '):
            if in_list:
                html_parts.append(f'                                    </{list_type}>\n')
                html_parts.append('                                </td>\n')
                html_parts.append('                            </tr>\n')
                html_parts.append('                        </table>\n')
                in_list = False
                list_items = []
            
            title_text = line[3:].strip()
            html_parts.append(f'''                            <!-- 章节标题 -->
                            <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin: 28px 0 16px 0;">
                                <tr>
                                    <td style="border-bottom: 1px solid #e8e4df; padding-bottom: 12px;">
                                        <h2 style="margin: 0; font-size: 18px; font-weight: bold; color: #1a1a1a; line-height: 1.4; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', sans-serif;">{title_text}</h2>
                                    </td>
                                </tr>
                            </table>
''')
            continue
        
        if line.startswith('### '):
            if in_list:
                html_parts.append(f'                                    </{list_type}>\n')
                html_parts.append('                                </td>\n')
                html_parts.append('                            </tr>\n')
                html_parts.append('                        </table>\n')
                in_list = False
                list_items = []
            
            title_text = line[4:].strip()
            html_parts.append(f'''                            <!-- 小标题 -->
                            <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin: 20px 0 12px 0;">
                                <tr>
                                    <td style="padding-left: 12px; border-left: 3px solid #c9a227;">
                                        <h3 style="margin: 0; font-size: 16px; font-weight: bold; color: #333; line-height: 1.4; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', sans-serif;">{title_text}</h3>
                                    </td>
                                </tr>
                            </table>
''')
            continue
        
        # 无序列表处理
        if line.startswith('- ') or line.startswith('* '):
            if not in_list:
                list_type = 'ul'
                html_parts.append('''                            <!-- 列表 -->
                            <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin: 16px 0;">
                                <tr>
                                    <td>
                                        <ul style="margin: 0; padding-left: 20px; color: #333; line-height: 1.7;">
''')
                in_list = True
            item_text = line[2:]
            # 处理加粗和斜体
            item_text = re.sub(r'\*\*(.+?)\*\*', r'<strong style="color: #1a1a1a;">\1</strong>', item_text)
            item_text = re.sub(r'\*(.+?)\*', r'<em>\1</em>', item_text)
            html_parts.append(f'                                            <li style="margin-bottom: 8px;">{item_text}</li>\n')
            continue
        
        # 有序列表处理
        ordered_match = re.match(r'^(\d+)\.\s+(.+)$', line)
        if ordered_match:
            if not in_list:
                list_type = 'ol'
                html_parts.append('''                            <!-- 有序列表 -->
                            <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin: 16px 0;">
                                <tr>
                                    <td>
                                        <ol style="margin: 0; padding-left: 20px; color: #333; line-height: 1.7;">
''')
                in_list = True
            item_text = ordered_match.group(2)
            # 处理加粗和斜体
            item_text = re.sub(r'\*\*(.+?)\*\*', r'<strong style="color: #1a1a1a;">\1</strong>', item_text)
            item_text = re.sub(r'\*(.+?)\*', r'<em>\1</em>', item_text)
            html_parts.append(f'                                            <li style="margin-bottom: 8px;">{item_text}</li>\n')
            continue
        
        # 如果之前在列表中，现在结束了
        if in_list:
            html_parts.append(f'                                    </{list_type}>\n')
            html_parts.append('                                </td>\n')
            html_parts.append('                            </tr>\n')
            html_parts.append('                        </table>\n')
            in_list = False
            list_items = []
        
        # 引用处理（> 开头）
        if line.startswith('>'):
            quote_text = line[1:].strip()
            # 处理加粗和斜体
            quote_text = re.sub(r'\*\*(.+?)\*\*', r'<strong style="color: #1a1a1a;">\1</strong>', quote_text)
            quote_text = re.sub(r'\*(.+?)\*', r'<em>\1</em>', quote_text)
            html_parts.append(f'''                            <!-- 引用框 -->
                            <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin: 20px 0; background-color: #faf8f5; border: 1px solid #e8e4df;">
                                <tr>
                                    <td style="padding: 16px 20px;">
                                        <p style="margin: 0; font-style: italic; color: #555; line-height: 1.7; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', sans-serif;">{quote_text}</p>
                                    </td>
                                </tr>
                            </table>
''')
            continue
        
        # 高亮处理（==text==）
        if line.startswith('==') and line.endswith('=='):
            highlight_text = line[2:-2]
            html_parts.append(f'''                            <!-- 高亮框 -->
                            <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin: 20px 0; background-color: #fff9e6; border-left: 4px solid #c9a227;">
                                <tr>
                                    <td style="padding: 16px 20px;">
                                        <p style="margin: 0; color: #333; line-height: 1.7; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', sans-serif;">{highlight_text}</p>
                                    </td>
                                </tr>
                            </table>
''')
            continue
        
        # 分隔线处理
        if line == '---' or line == '***':
            html_parts.append('''                            <!-- 分隔线 -->
                            <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin: 24px 0;">
                                <tr>
                                    <td height="1" style="background-color: #e8e4df; line-height: 0; font-size: 0;"></td>
                                </tr>
                            </table>
''')
            continue
        
        # 普通段落处理
        # 处理加粗和斜体
        processed_line = line
        processed_line = re.sub(r'\*\*(.+?)\*\*', r'<strong style="color: #1a1a1a;">\1</strong>', processed_line)
        processed_line = re.sub(r'\*(.+?)\*', r'<em>\1</em>', processed_line)
        
        html_parts.append(f'''                            <!-- 段落 -->
                            <p style="margin: 0 0 16px 0; font-size: 16px; line-height: 1.75; color: #333; text-align: justify; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', sans-serif;">{processed_line}</p>
''')
    
    # 处理未结束的列表
    if in_list:
        html_parts.append(f'                                    </{list_type}>\n')
        html_parts.append('                                </td>\n')
        html_parts.append('                            </tr>\n')
        html_parts.append('                        </table>\n')
    
    # HTML 尾部
    html_parts.append('''                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
    
    <!-- 底部装饰条 -->
    <table width="100%" cellpadding="0" cellspacing="0" border="0">
        <tr><td height="8" style="background-color: #1a1a2e; line-height: 0; font-size: 0;"></td></tr>
    </table>
</body>
</html>
''')
    
    return ''.join(html_parts)


def generate_chapter_title(chapter_num, main_title, sub_title=""):
    """
    生成章节标题 HTML（表格布局）
    
    Args:
        chapter_num: 章节编号（1, 2, 3...）
        main_title: 主标题
        sub_title: 副标题（可选）
    
    Returns:
        str: 章节标题 HTML
    """
    chapter_words = ["ONE", "TWO", "THREE", "FOUR", "FIVE", "SIX", "SEVEN", "EIGHT", "NINE", "TEN"]
    chapter_word = chapter_words[chapter_num - 1] if chapter_num <= len(chapter_words) else str(chapter_num)
    
    sub_title_html = f'<div style="font-size: 14px; color: #666; margin-top: 4px;">{sub_title}</div>' if sub_title else ''
    
    return f'''<!-- 章节标题 -->
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin: 28px 0 16px 0;">
    <tr>
        <td style="border-bottom: 1px solid #e8e4df; padding-bottom: 12px;">
            <div style="font-size: 11px; color: #c9a227; margin-bottom: 4px; text-transform: uppercase; letter-spacing: 1px;">CHAPTER {chapter_word}</div>
            <div style="font-size: 18px; font-weight: bold; color: #1a1a1a; line-height: 1.4; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', sans-serif;">{main_title}</div>
            {sub_title_html}
        </td>
    </tr>
</table>
'''


def generate_epilogue_title(title="写在最后"):
    """
    生成结语标题 HTML（表格布局）
    
    Args:
        title: 结语标题
    
    Returns:
        str: 结语标题 HTML
    """
    return f'''<!-- 结语标题 -->
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin: 28px 0 16px 0;">
    <tr>
        <td style="border-bottom: 1px solid #e8e4df; padding-bottom: 12px;">
            <div style="font-size: 11px; color: #c9a227; margin-bottom: 4px; text-transform: uppercase; letter-spacing: 1px;">EPILOGUE</div>
            <div style="font-size: 18px; font-weight: bold; color: #1a1a1a; line-height: 1.4; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', sans-serif;">{title}</div>
        </td>
    </tr>
</table>
'''


def main():
    """命令行入口"""
    if len(sys.argv) < 3:
        print("用法: python generate_wechat_html.py <标题> <内容文件路径> [作者] [输出文件路径]")
        sys.exit(1)
    
    title = sys.argv[1]
    content_file = Path(sys.argv[2])
    author = sys.argv[3] if len(sys.argv) > 3 else ""
    output_file = Path(sys.argv[4]) if len(sys.argv) > 4 else content_file.with_suffix('.html')
    
    if not content_file.exists():
        print(f"错误: 找不到内容文件 {content_file}")
        sys.exit(1)
    
    content = content_file.read_text(encoding='utf-8')
    html_content = markdown_to_wechat_html(content, title, author)
    
    output_file.write_text(html_content, encoding='utf-8')
    print(f"HTML已生成: {output_file}")


if __name__ == "__main__":
    main()
