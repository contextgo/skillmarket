# 微信公众号HTML排版模板参考

## 设计原则

1. **表格布局**：使用 `<table>` 替代 `<div>` 实现复杂布局，确保微信兼容性
2. **内联样式**：所有样式必须内联，禁止使用 `<style>` 标签
3. **纯色颜色**：使用 `#RRGGBB` 格式，禁止使用 `rgba()`、`linear-gradient`
4. **无阴影**：禁止使用 `box-shadow`，使用边框替代
5. **移动优先**：设计以手机端阅读为主
6. **简洁清晰**：避免过于复杂的设计，确保在各设备上正常显示

## 微信排版限制

| 限制项 | 说明 | 处理方案 |
|--------|------|----------|
| `<style>` 标签 | **不支持** | 所有样式必须内联 |
| `linear-gradient` | **不支持** | 使用纯色背景替代 |
| `rgba()` / `hsla()` | **不支持** | 使用十六进制颜色 `#RRGGBB` |
| `box-shadow` | **不支持** | 使用边框替代 |
| Flexbox / Grid | **不支持** | 使用表格布局 `<table>` |
| 伪元素 `::before/after` | **不支持** | 使用实际元素替代 |
| `<br>` 换行 | **慎用** | 标题避免使用 |

## 标准排版结构

### 完整文章模板

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>文章标题</title>
</head>
<body style="margin: 0; padding: 0; background-color: #f5f3f0;">
    <!-- 顶部装饰条 -->
    <table width="100%" cellpadding="0" cellspacing="0" border="0">
        <tr><td height="8" style="background-color: #1a1a2e; line-height: 0; font-size: 0;"></td></tr>
    </table>
    
    <!-- 主容器 -->
    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color: #f5f3f0;">
        <tr>
            <td style="padding: 20px 16px;">
                <!-- 内容卡片 -->
                <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color: #ffffff; max-width: 600px; margin: 0 auto;">
                    <tr>
                        <td style="padding: 24px 20px;">
                            
                            <!-- 标题区域 -->
                            <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom: 24px;">
                                <tr>
                                    <td style="border-bottom: 2px solid #c9a227; padding-bottom: 16px;">
                                        <h1 style="margin: 0; font-size: 22px; font-weight: bold; color: #1a1a1a; line-height: 1.4; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', sans-serif;">文章标题</h1>
                                    </td>
                                </tr>
                            </table>
                            
                            <!-- 正文段落 -->
                            <p style="margin: 0 0 16px 0; font-size: 16px; line-height: 1.75; color: #333; text-align: justify; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', sans-serif;">正文内容...</p>
                            
                            <!-- 章节标题 -->
                            <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin: 28px 0 16px 0;">
                                <tr>
                                    <td style="border-bottom: 1px solid #e8e4df; padding-bottom: 12px;">
                                        <div style="font-size: 11px; color: #c9a227; margin-bottom: 4px; text-transform: uppercase; letter-spacing: 1px;">CHAPTER ONE</div>
                                        <div style="font-size: 18px; font-weight: bold; color: #1a1a1a; line-height: 1.4;">章节主标题</div>
                                        <div style="font-size: 14px; color: #666; margin-top: 4px;">章节副标题</div>
                                    </td>
                                </tr>
                            </table>
                            
                            <!-- 引言框 -->
                            <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin: 20px 0; background-color: #faf8f5; border: 1px solid #e8e4df;">
                                <tr>
                                    <td style="padding: 16px 20px;">
                                        <p style="margin: 0; font-style: italic; color: #555; line-height: 1.7;">引言内容...</p>
                                    </td>
                                </tr>
                            </table>
                            
                            <!-- 高亮框 -->
                            <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin: 20px 0; background-color: #fff9e6; border-left: 4px solid #c9a227;">
                                <tr>
                                    <td style="padding: 16px 20px;">
                                        <p style="margin: 0; color: #333; line-height: 1.7;">高亮内容...</p>
                                    </td>
                                </tr>
                            </table>
                            
                            <!-- 场景框 -->
                            <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin: 20px 0; background-color: #f5f3f0; border-left: 3px solid #c9a227;">
                                <tr>
                                    <td style="padding: 14px 18px;">
                                        <p style="margin: 0; font-style: italic; color: #555; line-height: 1.7;">场景描述内容...</p>
                                    </td>
                                </tr>
                            </table>
                            
                            <!-- 列表 -->
                            <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin: 16px 0;">
                                <tr>
                                    <td>
                                        <ul style="margin: 0; padding-left: 20px; color: #333; line-height: 1.7;">
                                            <li style="margin-bottom: 8px;">列表项1</li>
                                            <li style="margin-bottom: 8px;">列表项2</li>
                                            <li style="margin-bottom: 8px;">列表项3</li>
                                        </ul>
                                    </td>
                                </tr>
                            </table>
                            
                            <!-- 分隔线 -->
                            <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin: 24px 0;">
                                <tr>
                                    <td height="1" style="background-color: #e8e4df; line-height: 0; font-size: 0;"></td>
                                </tr>
                            </table>
                            
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
    
    <!-- 底部装饰条 -->
    <table width="100%" cellpadding="0" cellspacing="0" border="0">
        <tr><td height="8" style="background-color: #1a1a2e; line-height: 0; font-size: 0;"></td></tr>
    </table>
</body>
</html>
```

## 常用样式组件

### 1. 标题样式

#### 主标题（文章标题）
```html
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom: 24px;">
    <tr>
        <td style="border-bottom: 2px solid #c9a227; padding-bottom: 16px;">
            <h1 style="margin: 0; font-size: 22px; font-weight: bold; color: #1a1a1a; line-height: 1.4; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', sans-serif;">文章标题</h1>
        </td>
    </tr>
</table>
```

#### 章节标题（带英文编号）
```html
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin: 28px 0 16px 0;">
    <tr>
        <td style="border-bottom: 1px solid #e8e4df; padding-bottom: 12px;">
            <div style="font-size: 11px; color: #c9a227; margin-bottom: 4px; text-transform: uppercase; letter-spacing: 1px;">CHAPTER ONE</div>
            <div style="font-size: 18px; font-weight: bold; color: #1a1a1a; line-height: 1.4;">章节主标题</div>
            <div style="font-size: 14px; color: #666; margin-top: 4px;">章节副标题</div>
        </td>
    </tr>
</table>
```

#### 小标题（带左侧边框）
```html
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin: 20px 0 12px 0;">
    <tr>
        <td style="padding-left: 12px; border-left: 3px solid #c9a227;">
            <h3 style="margin: 0; font-size: 16px; font-weight: bold; color: #333; line-height: 1.4;">小标题</h3>
        </td>
    </tr>
</table>
```

#### 结语标题
```html
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin: 28px 0 16px 0;">
    <tr>
        <td style="border-bottom: 1px solid #e8e4df; padding-bottom: 12px;">
            <div style="font-size: 11px; color: #c9a227; margin-bottom: 4px; text-transform: uppercase; letter-spacing: 1px;">EPILOGUE</div>
            <div style="font-size: 18px; font-weight: bold; color: #1a1a1a; line-height: 1.4;">写在最后</div>
        </td>
    </tr>
</table>
```

### 2. 引用区块

#### 引言框（米白色背景 + 边框）
```html
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin: 20px 0; background-color: #faf8f5; border: 1px solid #e8e4df;">
    <tr>
        <td style="padding: 16px 20px;">
            <p style="margin: 0; font-style: italic; color: #555; line-height: 1.7;">引言内容...</p>
        </td>
    </tr>
</table>
```

#### 高亮框（暖黄色背景 + 左侧边框）
```html
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin: 20px 0; background-color: #fff9e6; border-left: 4px solid #c9a227;">
    <tr>
        <td style="padding: 16px 20px;">
            <p style="margin: 0; color: #333; line-height: 1.7;">高亮内容...</p>
        </td>
    </tr>
</table>
```

#### 场景框（浅灰背景 + 左侧边框）
```html
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin: 20px 0; background-color: #f5f3f0; border-left: 3px solid #c9a227;">
    <tr>
        <td style="padding: 14px 18px;">
            <p style="margin: 0; font-style: italic; color: #555; line-height: 1.7;">场景描述内容...</p>
        </td>
    </tr>
</table>
```

### 3. 段落样式

#### 标准段落
```html
<p style="margin: 0 0 16px 0; font-size: 16px; line-height: 1.75; color: #333; text-align: justify; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', sans-serif;">正文内容...</p>
```

#### 加粗文字
```html
<strong style="color: #1a1a1a;">加粗内容</strong>
```

### 4. 列表样式

#### 无序列表
```html
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin: 16px 0;">
    <tr>
        <td>
            <ul style="margin: 0; padding-left: 20px; color: #333; line-height: 1.7;">
                <li style="margin-bottom: 8px;">列表项1</li>
                <li style="margin-bottom: 8px;">列表项2</li>
                <li style="margin-bottom: 8px;">列表项3</li>
            </ul>
        </td>
    </tr>
</table>
```

#### 有序列表
```html
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin: 16px 0;">
    <tr>
        <td>
            <ol style="margin: 0; padding-left: 20px; color: #333; line-height: 1.7;">
                <li style="margin-bottom: 8px;">第一步</li>
                <li style="margin-bottom: 8px;">第二步</li>
                <li style="margin-bottom: 8px;">第三步</li>
            </ol>
        </td>
    </tr>
</table>
```

### 5. 分隔线

#### 简单分隔线
```html
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin: 24px 0;">
    <tr>
        <td height="1" style="background-color: #e8e4df; line-height: 0; font-size: 0;"></td>
    </tr>
</table>
```

#### 装饰性分隔线（菱形符号）
```html
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin: 24px 0;">
    <tr>
        <td style="text-align: center; color: #c9a227; font-size: 14px; letter-spacing: 8px;">◆ ◆ ◆</td>
    </tr>
</table>
```

### 6. 图片样式

#### 带说明图片
```html
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin: 20px 0;">
    <tr>
        <td>
            <img src="图片URL" style="width: 100%; max-width: 100%; height: auto; display: block; border-radius: 4px;" alt="图片说明">
        </td>
    </tr>
    <tr>
        <td style="text-align: center; color: #999; font-size: 14px; padding-top: 8px;">图片说明文字</td>
    </tr>
</table>
```

### 7. 互动区域

#### 深色背景互动区
```html
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin: 24px 0; background-color: #1a1a2e;">
    <tr>
        <td style="padding: 24px 20px;">
            <p style="margin: 0 0 12px 0; color: #c9a227; font-size: 14px; text-align: center;">✦ ✦ ✦</p>
            <p style="margin: 0; color: #fff; font-size: 16px; line-height: 1.7; text-align: center;">互动内容...</p>
        </td>
    </tr>
</table>
```

## 色彩方案参考

### 默认配色
- **主背景**：`#f5f3f0`（暖灰色）
- **卡片背景**：`#ffffff`（纯白）
- **主强调色**：`#c9a227`（金色）
- **深色装饰**：`#1a1a2e`（深蓝黑）
- **主文字**：`#1a1a1a`（近黑）
- **副文字**：`#333`（深灰）
- **辅助文字**：`#666`（中灰）
- **引言背景**：`#faf8f5`（米白）
- **高亮背景**：`#fff9e6`（暖黄）
- **边框色**：`#e8e4df`（浅灰）

### 商务专业
- **主色**：`#2c3e50`（深蓝灰）
- **强调色**：`#3498db`（蓝色）
- **背景**：`#fafafa`

### 活力清新
- **主色**：`#27ae60`（绿色）
- **强调色**：`#f39c12`（橙黄）
- **背景**：`#f8fff8`

## 排版规范

### 行间距与段间距
- **行高**：`line-height: 1.75`
- **段落间距**：`margin-bottom: 16px`
- **章节间距**：`margin: 28px 0 16px 0`

### 字号规范
- **主标题**：`font-size: 22px`
- **章节标题**：`font-size: 18px`
- **小标题**：`font-size: 16px`
- **正文**：`font-size: 16px`
- **辅助文字**：`font-size: 14px`

### 字体栈
```css
font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', sans-serif;
```

## 注意事项

1. **避免使用复杂CSS**：不支持 Flexbox、Grid 等现代布局
2. **图片使用绝对URL**：确保图片可访问
3. **字体降级**：首选系统字体，设置多个备选
4. **避免JavaScript**：微信公众号不支持动态脚本
5. **表格处理**：复杂表格建议转为图片
6. **emoji使用**：部分 emoji 在某些手机上显示异常，建议谨慎使用
