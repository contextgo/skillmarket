# 微信公众号API对接参考文档

## 概述

本文档提供微信公众号后台API的对接规范，用于实现草稿同步和自动发布功能。

## 接口基础信息

- 基础URL: `https://api.weixin.qq.com`
- 认证方式: Access Token（需使用AppID和AppSecret获取）
- 数据格式: JSON
- 编码: UTF-8

## 获取Access Token

### 接口地址
```
GET https://api.weixin.qq.com/cgi-bin/token
```

### 请求参数
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| grant_type | string | 是 | 填写client_credential |
| appid | string | 是 | 第三方用户唯一凭证 |
| secret | string | 是 | 第三方用户唯一凭证密钥 |

### 响应示例
```json
{
    "access_token": "ACCESS_TOKEN",
    "expires_in": 7200
}
```

### 注意事项
- Access Token有效期为2小时，需定时刷新
- 重复获取会导致上次获取的Access Token失效
- 建议在本地缓存Token，并设置1.5小时的自动刷新机制

## 新增草稿

### 接口地址
```
POST https://api.weixin.qq.com/cgi-bin/draft/add
```

### 请求示例
```json
{
    "articles": [
        {
            "title": "文章标题",
            "author": "作者",
            "digest": "文章摘要",
            "content": "<p>文章内容HTML</p>",
            "content_source_url": "原文链接",
            "thumb_media_id": "封面图片media_id",
            "need_open_comment": 1,
            "only_fans_can_comment": 0
        }
    ]
}
```

### 字段说明
| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| title | string | 是 | 标题 |
| author | string | 否 | 作者 |
| digest | string | 否 | 摘要（推荐填写，不超过54个字） |
| content | string | 是 | 文章内容（HTML格式，不超过500万字符） |
| content_source_url | string | 否 | 原文链接 |
| thumb_media_id | string | 否 | 封面图片的media_id（必须通过素材接口上传） |
| need_open_comment | int | 否 | 是否打开评论（0-关闭，1-打开） |
| only_fans_can_comment | int | 否 | 是否粉丝才可评论（0-所有人，1-粉丝） |

### 响应示例
```json
{
    "media_id": " MEDIA_ID"
}
```

## 获取草稿列表

### 接口地址
```
GET https://api.weixin.qq.com/cgi-bin/draft/count
```

### 响应示例
```json
{
    "total_count": 1
}
```

## 删除草稿

### 接口地址
```
POST https://api.weixin.qq.com/cgi-bin/draft/delete
```

### 请求示例
```json
{
    "media_id": "MEDIA_ID"
}
```

## 发布接口

### 接口地址（群发）
```
POST https://api.weixin.qq.com/cgi-bin/message/mass/sendall
```

### 请求示例（图文消息）
```json
{
    "filter": {
        "is_to_all": true
    },
    "mpnews": {
        "media_id": "MEDIA_ID"
    },
    "msgtype": "mpnews"
}
```

## 定时发布接口

### 接口地址
```
POST https://api.weixin.qq.com/cgi-bin/message/schedule/send
```

### 请求示例
```json
{
    "filter": {
        "is_to_all": true
    },
    "mpnews": {
        "media_id": "MEDIA_ID"
    },
    "msgtype": "mpnews",
    "send_time": 1604064000
}
```

### 定时发布规则
- `send_time`: Unix时间戳（秒级），必须设置为未来时间
- 定时时间必须大于当前时间，精确到秒
- 定时时间跨度不得大于7天

## 素材管理接口

### 上传封面图片
```
POST https://api.weixin.qq.com/cgi-bin/media/upload
```

### 请求参数
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| media | file | 是 | form-data中媒体文件标识 |
| type | string | 是 | 媒体文件类型（image、voice、video、thumb） |

### 响应示例
```json
{
    "media_id": "MEDIA_ID",
    "url": "https://mmbiz.qpic.cn/..."
}
```

## 错误码说明

| 错误码 | 说明 |
|--------|------|
| 40001 | 获取access_token时AppSecret错误 |
| 40013 | 不合法的AppID |
| 40125 | 无效的appsecret |
| 41006 | 缺少media_id参数 |
| 41004 | 缺少secret参数 |
| 44001 | 多媒体文件为空 |
| 44002 | POST数据包为空 |
| 44003 | 图文消息内容为空 |
| 45001 | 媒体文件为空 |
| 45002 | 消息内容超过限制 |
| 45003 | 标题超过限制 |
| 45004 | 描述超过限制 |

## Python调用示例

```python
import requests
import json
from datetime import datetime, timedelta

class WeChatClient:
    def __init__(self, app_id, app_secret):
        self.app_id = app_id
        self.app_secret = app_secret
        self.access_token = None
        self.token_expires_at = None

    def get_access_token(self):
        """获取Access Token"""
        if self.access_token and self.token_expires_at:
            if datetime.now() < self.token_expires_at:
                return self.access_token

        url = f"https://api.weixin.qq.com/cgi-bin/token"
        params = {
            "grant_type": "client_credential",
            "appid": self.app_id,
            "secret": self.app_secret
        }

        response = requests.get(url, params=params)
        data = response.json()

        if "access_token" in data:
            self.access_token = data["access_token"]
            expires_in = data.get("expires_in", 7200)
            self.token_expires_at = datetime.now() + timedelta(seconds=expires_in * 0.8)
            return self.access_token
        else:
            raise Exception(f"获取Access Token失败: {data}")

    def add_draft(self, articles):
        """新增草稿"""
        url = "https://api.weixin.qq.com/cgi-bin/draft/add"
        access_token = self.get_access_token()
        params = {"access_token": access_token}

        payload = {"articles": articles}
        response = requests.post(url, params=params, json=payload)
        return response.json()

    def upload_image(self, image_path):
        """上传图片"""
        url = "https://api.weixin.qq.com/cgi-bin/media/upload"
        access_token = self.get_access_token()
        params = {"access_token": access_token, "type": "image"}

        with open(image_path, "rb") as f:
            files = {"media": f}
            response = requests.post(url, params=params, files=files)

        return response.json()
```

## 安全注意事项

1. **AppSecret保护**: 切勿在前端代码或公开场合暴露AppSecret
2. **Token缓存**: 务必实现Token的本地缓存机制，避免频繁请求
3. **参数校验**: 在调用接口前务必校验参数格式和必填项
4. **错误处理**: 实现完善的错误处理和重试机制
5. **日志记录**: 记录所有接口调用的请求和响应，便于排查问题
6. **不存储凭证**: 本Skill不存储AppID和AppSecret，仅用于实时鉴权
