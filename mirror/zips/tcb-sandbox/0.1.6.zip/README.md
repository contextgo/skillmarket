# tcb-sandbox skill

Skill package for operating `tcb-remote-workspace` via `tcb-sandbox-cli`.

## TCB Sandbox Runtime Model

`tcb-sandbox` is designed around session affinity and elastic lifecycle management:

- single-instance, single-session affinity: one sandbox instance serves one session context
- single-instance, multi-concurrency for tools: the same instance can process multiple tool requests concurrently for that session
- idle freeze: instance is frozen after idle to reduce resource cost
- request wake-up: new requests wake the frozen instance for continued session execution
- TTL rotation: when TTL is reached, the instance is rotated and destroyed for lifecycle hygiene

This model provides stable per-session state while keeping cost and isolation under control.

## What This Skill Provides

- standardized workflow for TRW health, docs, tools, files, secrets, preview, and PTY
- safety-first operating rules for session-scoped execution
- reusable command playbooks for common remote workspace tasks
- RFC 9457-aware failure handling guidance for HTTP/CLI channels

## Top Use Cases

- remote coding agent reads/edits files in a session-affine workspace
- secure API key lifecycle management (`set/list/rotate/delete`) per session
- build artifact upload and validation inside remote workspace
- dev server bring-up and preview URL delivery for human validation
- PTY lifecycle operations (`create/send-input/read-output/resize/kill`) for interactive process control
- declarative stdio MCP registration via `tools call add_mcp_servers` / `remove_mcp_servers` / `list_mcp_servers` (see `SKILL.md` playbooks; response field `available_mcp_servers`)

## Requirements

- Node.js 22+
- reachable TRW endpoint
- `tcb-sandbox-cli` installed globally or available in PATH

Install CLI:

```bash
pnpm add -g tcb-sandbox-cli@0.3.0
```

## Environment Variables

Required:

- `TCB_SANDBOX_ENDPOINT`
- `TCB_SANDBOX_SESSION_ID` (required for non-health commands)

Optional:

- `TCB_SANDBOX_HEADERS_JSON` (JSON object of additional headers)

## Credential Safety Policy

- this skill only requires `TCB_SANDBOX_ENDPOINT` and `TCB_SANDBOX_SESSION_ID` to operate
- do not read unrelated local environment variables
- do not transfer any secret to TRW unless user explicitly requests that specific secret key/value
- prefer short-lived and least-privilege credentials for session injection

Example:

```bash
export TCB_SANDBOX_ENDPOINT="https://your-trw-gateway.example.com"
export TCB_SANDBOX_SESSION_ID="demo-session"
export TCB_SANDBOX_HEADERS_JSON='{"X-Trace-Id":"demo"}'
```

## Quick Validation

```bash
tcb-sandbox --endpoint "$TCB_SANDBOX_ENDPOINT" health
tcb-sandbox --endpoint "$TCB_SANDBOX_ENDPOINT" tools list
tcb-sandbox --endpoint "$TCB_SANDBOX_ENDPOINT" --session-id "$TCB_SANDBOX_SESSION_ID" \
  tools call read --param path=README.md
```

## MCP server config (mcporter)

After connectivity smoke test, agents may merge Cursor-style `mcpServers` into the session:

```bash
tcb-sandbox --endpoint "$TCB_SANDBOX_ENDPOINT" --session-id "$TCB_SANDBOX_SESSION_ID" \
  tools call list_mcp_servers --data '{}'
tcb-sandbox --endpoint "$TCB_SANDBOX_ENDPOINT" --session-id "$TCB_SANDBOX_SESSION_ID" \
  tools call add_mcp_servers --data '{"mcpServers":{"demo":{"command":"node","args":["-e","0"]}}}'
```

## PTY Quick Usage

```bash
tcb-sandbox --endpoint "$TCB_SANDBOX_ENDPOINT" --session-id "$TCB_SANDBOX_SESSION_ID" \
  pty create --command bash --args -lc 'sleep 60'

tcb-sandbox --endpoint "$TCB_SANDBOX_ENDPOINT" --session-id "$TCB_SANDBOX_SESSION_ID" \
  pty send-input 12345 --text 'echo hello\n'

tcb-sandbox --endpoint "$TCB_SANDBOX_ENDPOINT" --session-id "$TCB_SANDBOX_SESSION_ID" \
  pty read-output 12345 --after-seq 0 --limit 64

tcb-sandbox --endpoint "$TCB_SANDBOX_ENDPOINT" --session-id "$TCB_SANDBOX_SESSION_ID" \
  pty resize 12345 --cols 120 --rows 40

tcb-sandbox --endpoint "$TCB_SANDBOX_ENDPOINT" --session-id "$TCB_SANDBOX_SESSION_ID" \
  pty kill 12345 --signal SIGTERM
```

## Capability Workflow (Recommended)

```bash
# 1) discover capabilities
tcb-sandbox --endpoint "$TCB_SANDBOX_ENDPOINT" --session-id "$TCB_SANDBOX_SESSION_ID" \
  tools call capability_list

# 2) inspect one capability
tcb-sandbox --endpoint "$TCB_SANDBOX_ENDPOINT" --session-id "$TCB_SANDBOX_SESSION_ID" \
  tools call capability_describe --param id=mcporter-cli

# 3) execute via described route (example: executionBy=sandbox, executionVia=bash)
tcb-sandbox --endpoint "$TCB_SANDBOX_ENDPOINT" --session-id "$TCB_SANDBOX_SESSION_ID" \
  tools call bash --param command='mcporter --version'
```

Agent strategy:

- always query capabilities first for hidden/indirect abilities
- capabilities are metadata-only; execute via `bash_in_sandbox` / `mcporter_in_sandbox` / `caller`

## Lifecycle-Aware Troubleshooting

- first request after idle may be slower due to freeze-to-wake transition
- if process state appears missing, check whether instance TTL rotation happened
- if preview is unreachable, verify service bind address (`0.0.0.0`) and session consistency
- if command behavior drifts, re-run `docs` and `tools list` before retry

## Skill Files

- `SKILL.md`: operational policy and command playbooks
- `README.md`: packaging and onboarding guide

## Publishing Notes

Recommended slug: `tcb-sandbox`

Example publish command:

```bash
# From repo root (tcb-remote-workspace/)
clawhub publish ./skills/tcb-sandbox \
  --slug tcb-sandbox \
  --name "TCB Sandbox Skill" \
  --version 0.3.1 \
  --changelog "Skill release: install pin tcb-sandbox-cli@0.3.0; MCP/mcporter playbooks; align with CLI release docs." \
  --tags latest
```

If publishing to domestic registries, keep slug and display name aligned with `tcb-sandbox` for discoverability.

## Skill changelog

- **0.3.1** — Clawhub skill package refresh; metadata/install still targets `tcb-sandbox-cli@0.3.0`; playbooks unchanged for CLI API.
- **0.3.0** — Initial skill line aligned with `tcb-sandbox-cli@0.3.0`.
