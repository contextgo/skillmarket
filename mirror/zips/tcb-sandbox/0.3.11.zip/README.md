# tcb-sandbox Skill

TRW 官方 Skill 包，提供工作流指引和 CLI playbooks。

## 包含内容

| 文件 | 说明 |
|------|------|
| `SKILL.md` | 完整技能文档（26KB） |
| `metadata.json` | Skill 元数据 |

## 使用方式

通过 Capability 系统发现和执行：

```bash
# 发现 Skill
tcb-sandbox capability-list

# 查看详情
tcb-sandbox capability-describe --id tcb-sandbox-skill

# 读取 Skill 内容
tcb-sandbox read --path .tcb-sandbox/SKILL.md
```

## 主要内容

- TRW 操作指引
- CLI 命令示例
- 常见工作流（部署、调试、快照等）

## 更新

Skill 随 TRW 版本更新，无需单独安装。
