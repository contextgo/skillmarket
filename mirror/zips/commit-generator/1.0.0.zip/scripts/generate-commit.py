#!/usr/bin/env python3
"""
Commit 消息生成参考脚本
使用示例：
  python generate-commit.py "添加用户登录功能"
  python generate-commit.py "修复登录页面崩溃" fix
  python generate-commit.py "更新文档" docs gitmoji
"""

import sys

def detect_type(description):
    """自动检测提交类型"""
    keywords = {
        'feat': ['新增', '添加', 'feature', '新功能', '实现', 'add', 'implement', 'introduce'],
        'fix': ['修复', 'bug', '错误', 'fix', 'bugfix', 'resolve', 'correct'],
        'docs': ['文档', 'README', '注释', 'doc', 'documentation', 'readme', 'comment'],
        'style': ['格式', '格式化', '缩进', '空格', 'style', 'format', 'indent', 'whitespace'],
        'refactor': ['重构', '优化', '改进', 'refactor', 'optimize', 'improve', 'restructure'],
        'test': ['测试', '测试用例', 'test', 'spec', 'unittest', 'e2e'],
        'chore': ['构建', '依赖', '配置', 'chore', 'build', 'dependency', 'config', 'setup'],
    }
    
    description_lower = description.lower()
    for commit_type, words in keywords.items():
        if any(word in description_lower for word in words):
            return commit_type
    return 'feat'

def generate_commit(description, commit_type=None, convention='conventional'):
    """生成 commit 消息"""
    if not commit_type:
        commit_type = detect_type(description)
    
    if convention == 'gitmoji':
        gitmojis = {
            'feat': '✨',
            'fix': '🐛',
            'docs': '📚',
            'style': '💎',
            'refactor': '♻️',
            'test': '🧪',
            'chore': '🔧',
        }
        emoji = gitmojis.get(commit_type, '✨')
        return f"{emoji} {description}"
    else:
        return f"{commit_type}: {description}"

def main():
    if len(sys.argv) < 2:
        print("=" * 60)
        print("智能 Commit 生成器")
        print("=" * 60)
        print("\n用法: python generate-commit.py <描述> [类型] [规范]")
        print("\n参数说明:")
        print("  <描述>    : 变更描述（必需）")
        print("  [类型]    : 提交类型（可选）- feat/fix/docs/style/refactor/test/chore")
        print("  [规范]    : 提交规范（可选）- conventional/gitmoji/angular")
        print("\n示例:")
        print('  python generate-commit.py "添加用户登录功能"')
        print('  python generate-commit.py "修复登录页面崩溃" fix')
        print('  python generate-commit.py "更新文档" docs gitmoji')
        print("\n" + "=" * 60)
        sys.exit(1)
    
    description = sys.argv[1]
    commit_type = sys.argv[2] if len(sys.argv) > 2 else None
    convention = sys.argv[3] if len(sys.argv) > 3 else 'conventional'
    
    commit_msg = generate_commit(description, commit_type, convention)
    
    print("\n" + "=" * 60)
    print("🎯 生成的 Commit 消息")
    print("=" * 60)
    print(f"\n{commit_msg}")
    print("\n" + "=" * 60)
    print(f"类型: {commit_type or detect_type(description)}")
    print(f"规范: {convention}")
    print("=" * 60 + "\n")

if __name__ == '__main__':
    main()
