#!/bin/bash
# 获取当前 git diff
# Usage: ./git-diff.sh [--staged|--workspace|--all]

# 检查是否在 Git 仓库中
if ! git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
    echo "❌ 错误：当前目录不是 Git 仓库"
    echo "请在 Git 仓库目录中运行此脚本"
    exit 1
fi

MODE=${1:-"--staged"}

if [ "$MODE" = "--staged" ]; then
    echo "📋 获取暂存区变更..."
    git diff --staged
elif [ "$MODE" = "--workspace" ]; then
    echo "📋 获取工作区变更..."
    git diff HEAD
elif [ "$MODE" = "--all" ]; then
    echo "📋 获取所有变更（暂存区+工作区）..."
    git diff HEAD
else
    echo "用法: $0 [--staged|--workspace|--all]"
    echo "  --staged     : 暂存区变更（默认）"
    echo "  --workspace  : 工作区变更"
    echo "  --all        : 所有变更"
    exit 1
fi
