---
name: commit-generator
description: |
  智能 Git Commit 消息生成器。当用户需要生成符合规范的 Git commit 消息时触发。
  支持 Conventional Commits（默认）、Angular、Gitmoji 等多种规范，自动检测 7 种提交类型。
  生成 4 个版本的 commit 消息：精简中文、精简英文、详细中文、详细英文。
  支持智能 Git 集成，可自动获取 git diff 分析变更。
  触发词：生成commit、写commit、git提交、提交信息、commit消息、帮我commit、diff怎么提交、我改了代码、提交信息怎么写、generate commit, write commit, git commit, commit message, help me commit, what to commit
---


## 工作流程

### Step 1: 提取关键信息

从用户输入中提取：
- **变更描述**：用户修改了什么代码、功能、文件
- **规范偏好**：用户希望使用哪种提交规范（Conventional Commits/Angular/Gitmoji）
- **类型偏好**：用户是否指定了提交类型（feat/fix/docs等）
- **Git 仓库**：判断是否在 Git 仓库中，是否可以自动获取 diff

**信息提取原则**：
- 用户说啥提取啥，不强行归类
- 信息模糊就原样传递给模型判断
- 如果用户没有指定规范，默认使用 **Conventional Commits**

---

### Step 2: 智能类型检测

如果用户没有指定提交类型，根据变更描述自动检测类型：

| 类型 | 关键词检测 | 说明 |
|------|-----------|------|
| **feat** | 新增、添加、feature、新功能、实现、add、implement、introduce | 新功能、新特性 |
| **fix** | 修复、bug、错误、修复、fix、bugfix、resolve、correct | Bug 修复、问题解决 |
| **docs** | 文档、README、注释、doc、documentation、readme、comment | 文档更新、注释修改 |
| **style** | 格式、格式化、缩进、空格、style、format、indent、whitespace | 代码格式调整、不影响功能 |
| **refactor** | 重构、优化、改进、refactor、optimize、improve、restructure | 代码重构、不改变外部行为 |
| **test** | 测试、测试用例、test、spec、unittest、e2e | 测试相关变更 |
| **chore** | 构建、依赖、配置、chore、build、dependency、config、setup | 构建工具、依赖更新 |

**检测规则**：
1. 优先匹配明确的关键词
2. 如果有多个类型匹配，选择最相关的
3. 如果无法确定，默认使用 `feat` 或让用户选择

---

### Step 3: 智能 Git 集成（可选）

**核心原则**：如果不在 Git 仓库中，直接基于用户输入生成 commit 消息，不执行任何 git 相关操作。

**详细流程**：
1. **快速判断**：运行 `git rev-parse --is-inside-work-tree 2>/dev/null`

2. **如果是 Git 仓库**：
   - 主动询问用户："需要我自动获取当前的 git diff 来分析变更吗？"
   - 如果用户同意：
     * 运行 `git diff` 获取当前变更
     * 分析 diff 内容辅助生成 commit 消息
     * 如果 diff 太大，只分析主要变更文件

3. **如果不是 Git 仓库**：
   - **直接跳过所有 git 相关操作**
   - **直接使用用户提供的变更描述**
   - **进入步骤 4 生成 commit 消息**
   - **不要**：
     * 不要检查其他目录是否是 Git 仓库
     * 不要询问用户在哪个项目中修改
     * 不要执行任何文件系统操作

---

### Step 4: 生成 Commit 消息

根据提取的信息和规范，生成高质量的 commit 消息。

**提示词模板（Conventional Commits）**：
```
请根据以下代码变更生成一个符合 Conventional Commits 规范的 Git commit 消息。

变更描述：
{变更描述}

{如果有 git diff，也提供 diff 内容}

要求：
1. 使用类型：{检测到的类型或用户指定的类型}
2. 标题简洁明了（不超过 50 字符）
3. 如有需要可添加详细描述（body）
4. 使用中文或英文，与用户输入语言一致
5. 直接输出 commit 消息，不要额外解释
```

**Gitmoji 规范提示词**：
```
请根据以下代码变更生成一个使用 Gitmoji 的 Git commit 消息。

变更描述：
{变更描述}

Gitmoji 对应关系：
✨ feat - 新功能
🐛 fix - Bug 修复
📚 docs - 文档更新
💎 style - 代码格式
♻️ refactor - 重构
🧪 test - 测试
🔧 chore - 构建/工具

要求：
1. 使用对应的 Gitmoji 开头
2. 标题简洁明了
3. 直接输出 commit 消息
```

---

### Step 5: 输出格式

**生成4种版本供用户选择**：

```
🎯 生成的 Commit 消息（4个版本）

【版本 1】精简中文（≤20字符）
{精简中文commit消息}

【版本 2】精简英文（≤20字符）
{精简英文commit消息}

【版本 3】详细中文
{详细中文commit消息}

【版本 4】详细英文
{详细英文commit消息}

📋 说明
- 类型：{type}
- 规范：{Conventional Commits/Angular/Gitmoji}
- 检测方式：{自动检测/用户指定}

💡 选择您喜欢的版本，或告诉我：
- "用版本1"
- "再生成一组"
- "改成 Gitmoji 格式"
```

**示例输出**：
```
🎯 生成的 Commit 消息（4个版本）

【版本 1】精简中文（≤20字符）
feat: 添加登录功能

【版本 2】精简英文（≤20字符）
feat: add login feature

【版本 3】详细中文
feat(auth): 添加用户登录功能

- 支持邮箱/密码登录
- 支持第三方登录（GitHub/Google）
- 添加登录状态管理

【版本 4】详细英文
feat(auth): add user login feature

- support email/password login
- support third-party login (GitHub/Google)
- add login state management

📋 说明
- 类型：feat
- 规范：Conventional Commits
- 检测方式：自动检测

💡 选择您喜欢的版本，或告诉我：
- "用版本1"
- "再生成一组"
- "改成 Gitmoji 格式"
```

---

## 提交规范参考

### Conventional Commits（默认）

```
<type>(<scope>): <subject>

<body>

<footer>
```

**type**：feat、fix、docs、style、refactor、test、chore
**scope**：可选，影响的范围（如 auth、api、ui）
**subject**：简洁描述（不超过 50 字符）
**body**：可选，详细说明
**footer**：可选，关联 issue 等

**示例**：
```
feat(auth): 添加用户登录功能

- 支持邮箱/密码登录
- 支持第三方登录
- 添加登录状态管理

Closes #123
```

---

### Angular 规范

与 Conventional Commits 类似，但有更严格的要求：
- type 必须是指定的类型
- subject 首字母小写
- 结尾不加标点

**示例**：
```
feat(auth): add user login functionality
```

---

### Gitmoji 规范

使用 emoji 开头，更直观：

```
{emoji} {subject}
```

**Gitmoji 对照表**：
| Emoji | Type | 说明 |
|-------|------|------|
| ✨ | feat | 新功能 |
| 🐛 | fix | Bug 修复 |
| 📚 | docs | 文档更新 |
| 💎 | style | 代码格式 |
| ♻️ | refactor | 重构 |
| 🧪 | test | 测试 |
| 🔧 | chore | 构建/工具 |

**示例**：
```
✨ 添加用户登录功能
```

---

## 快捷提示词模板

### 模板 1：快速生成（默认 Conventional Commits）
```
根据以下变更生成 commit 消息：
{变更描述}
```

### 模板 2：指定类型
```
生成一个 {type} 类型的 commit 消息：
{变更描述}
```

### 模板 3：指定规范
```
用 {规范} 格式生成 commit 消息：
{变更描述}
```

### 模板 4：从 git diff 生成
```
根据 git diff 生成 commit 消息：
{git diff 内容}
```

---

## 示例

### 示例 1：新功能

**用户输入**："我添加了用户登录功能，支持邮箱密码和第三方登录"

**输出**：
```
🎯 生成的 Commit 消息（4个版本）

【版本 1】精简中文（≤20字符）
feat: 添加登录功能

【版本 2】精简英文（≤20字符）
feat: add login feature

【版本 3】详细中文
feat(auth): 添加用户登录功能

- 支持邮箱/密码登录
- 支持第三方登录（GitHub/Google）
- 添加登录状态管理

【版本 4】详细英文
feat(auth): add user login feature

- support email/password login
- support third-party login (GitHub/Google)
- add login state management

📋 说明
- 类型：feat
- 规范：Conventional Commits
- 检测方式：自动检测

💡 选择您喜欢的版本，或告诉我：
- "用版本1"
- "再生成一组"
- "改成 Gitmoji 格式"
```

---

### 示例 2：Bug 修复

**用户输入**："修复了登录页面在移动端崩溃的问题"

**输出**：
```
🎯 生成的 Commit 消息（4个版本）

【版本 1】精简中文（≤20字符）
fix: 修复登录崩溃

【版本 2】精简英文（≤20字符）
fix: fix login crash

【版本 3】详细中文
fix(auth): 修复登录页面移动端崩溃

- 修复移动端布局问题
- 添加响应式断点
- 优化触摸事件处理

【版本 4】详细英文
fix(auth): fix login page mobile crash

- fix mobile layout issues
- add responsive breakpoints
- optimize touch event handling

📋 说明
- 类型：fix
- 规范：Conventional Commits
- 检测方式：自动检测

💡 选择您喜欢的版本，或告诉我：
- "用版本1"
- "再生成一组"
- "改成 Gitmoji 格式"
```

---

### 示例 3：Gitmoji 格式

**用户输入**："用 Gitmoji 格式，更新了 README 文档"

**输出**：
```
🎯 生成的 Commit 消息（4个版本）

【版本 1】精简中文（≤20字符）
📚 更新文档

【版本 2】精简英文（≤20字符）
📚 update docs

【版本 3】详细中文
📚 更新 README 文档

- 添加快速开始指南
- 更新 API 文档
- 补充常见问题

【版本 4】详细英文
📚 update README documentation

- add quick start guide
- update API documentation
- add FAQs

📋 说明
- 类型：docs
- 规范：Gitmoji
- 检测方式：用户指定

💡 选择您喜欢的版本，或告诉我：
- "用版本1"
- "再生成一组"
- "改成 Conventional Commits 格式"
```

---

## 脚本资源

### scripts/git-diff.sh

获取当前 git diff 的脚本：
```bash
#!/bin/bash
# 获取当前 git diff
git diff --staged  # 暂存区
# 或者
git diff HEAD  # 工作区
```

### scripts/generate-commit.py

Python 参考脚本（可选使用）：
```python
#!/usr/bin/env python3
"""
Commit 消息生成参考脚本
使用示例：python generate-commit.py "添加用户登录功能"
"""

import sys

def detect_type(description):
    """自动检测提交类型"""
    keywords = {
        'feat': ['新增', '添加', 'feature', '新功能', '实现', 'add', 'implement', 'introduce'],
        'fix': ['修复', 'bug', '错误', 'fix', 'bugfix', 'resolve', 'correct'],
        'docs': ['文档', 'README', '注释', 'doc', 'documentation', 'readme', 'comment'],
        'style': ['格式', '格式化', '缩进', '空格', 'style', 'format', 'indent', 'whitespace'],
        'refactor': ['重构', '优化', '改进', 'refactor', 'optimize', 'improve', 'restructure'],
        'test': ['测试', '测试用例', 'test', 'spec', 'unittest', 'e2e'],
        'chore': ['构建', '依赖', '配置', 'chore', 'build', 'dependency', 'config', 'setup'],
    }
    
    description_lower = description.lower()
    for commit_type, words in keywords.items():
        if any(word in description_lower for word in words):
            return commit_type
    return 'feat'

def generate_commit(description, commit_type=None, convention='conventional'):
    """生成 commit 消息"""
    if not commit_type:
        commit_type = detect_type(description)
    
    if convention == 'gitmoji':
        gitmojis = {
            'feat': '✨',
            'fix': '🐛',
            'docs': '📚',
            'style': '💎',
            'refactor': '♻️',
            'test': '🧪',
            'chore': '🔧',
        }
        emoji = gitmojis.get(commit_type, '✨')
        return f"{emoji} {description}"
    else:
        return f"{commit_type}: {description}"

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python generate-commit.py <description> [type] [convention]")
        sys.exit(1)
    
    description = sys.argv[1]
    commit_type = sys.argv[2] if len(sys.argv) > 2 else None
    convention = sys.argv[3] if len(sys.argv) > 3 else 'conventional'
    
    commit_msg = generate_commit(description, commit_type, convention)
    print(commit_msg)
```

---

## 常见场景快速参考

| 场景 | 推荐类型 | 示例 |
|------|---------|------|
| 添加新功能 | feat | `feat: 添加用户登录功能` |
| 修复 Bug | fix | `fix: 修复登录页面崩溃` |
| 更新文档 | docs | `docs: 更新 API 文档` |
| 调整格式 | style | `style: 格式化代码` |
| 代码重构 | refactor | `refactor: 重构认证模块` |
| 添加测试 | test | `test: 添加单元测试` |
| 更新依赖 | chore | `chore: 更新依赖版本` |

---

## 最佳实践

1. **标题简洁**：不超过 50 字符
2. **使用动词开头**：添加、修复、更新、重构等
3. **详细描述**：复杂变更添加 body 说明
4. **保持一致**：团队内使用统一的规范
5. **关联 Issue**：如有相关 issue，在 footer 中提及
