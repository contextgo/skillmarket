#!/usr/bin/env python3
"""
职业专家Skill生成脚本 (v1.1)
接收专家框架数据，生成完整的SKILL.md文件
支持专业视角内核、表达规范DNA、职业内在张力、专业谱系、回答工作流
"""

import argparse
import json
import sys
from pathlib import Path


def generate_yaml_frontmatter(expert_name, description):
    """生成YAML前言区"""
    expert_name_clean = expert_name.lower().replace(" ", "-")
    return f"""---
name: {expert_name_clean}
description: {description}
---
"""


def generate_skill_content(expert_name, knowledge_system, analysis_framework,
                          decision_rules, ethics, expression_style,
                          core_kernels=None, expression_dna=None,
                          internal_tensions=None, professional_lineage=None,
                          answer_workflow=None):
    """生成SKILL.md正文内容"""
    content = f"""# {expert_name}

## 核心理念
由artisan-expert-generator自动生成，提炼专业视角，赋能角色扮演。

"""

    # 专业视角内核（v1.1新增）
    if core_kernels:
        content += "## 专业视角内核\n\n"
        for i, kernel in enumerate(core_kernels, 1):
            content += f"### 内核{i}: {kernel.get('name', '')}\n"
            content += f"**一句话**：{kernel.get('summary', '')}\n\n"
            content += f"**证据**：{kernel.get('evidence', '')}\n\n"
            content += f"**应用**：{kernel.get('application', '')}\n\n"
            content += f"**局限**：{kernel.get('limitation', '')}\n\n"

    # 角色扮演规则（v1.1新增）
    content += """## 角色扮演规则（最重要）

**此Skill激活后，直接以[职业身份]的身份回应。**

- 用「我」而非「[职业身份]会认为...」
- 直接用专业术语、逻辑回答问题
- 遇到超出专业范围的问题，明确说「这超出了我的专业领域，建议咨询...」
- **免责声明仅首次激活时说一次**，后续对话不再重复：
"""
    # 根据领域生成不同的免责声明
    domain = knowledge_system.get('domain', '').lower()
    if '法律' in domain or '法务' in domain or '律师' in expert_name:
        content += "  - 法律类：「我以法律专业人士视角提供分析，不构成正式法律意见，具体案件请咨询执业律师。」"
    elif '医疗' in domain or '医' in domain or '健康' in domain:
        content += "  - 医疗类：「我以医学专业人士视角提供分析，不构成诊疗建议，具体病情请咨询执业医师。」"
    elif '财务' in domain or '投资' in domain or '金融' in domain:
        content += "  - 财务类：「我以财务专业人士视角提供分析，不构成投资建议，具体决策请咨询持牌顾问。」"
    else:
        content += f"  - 通用：「我以{expert_name}视角提供专业分析，仅供参考，具体问题请咨询相关专业人士。」"

    content += """
- 不跳出角色做meta分析（除非用户明确要求「退出角色」）
- 不说「如果我是[职业身份]，我会...」「[职业身份]一般会...」

**退出角色**：用户说「退出」「切回正常」「不用扮演了」时恢复正常模式

---

## 身份卡

"""

    # 身份卡（v1.1新增）
    content += f"""**我是谁**：{knowledge_system.get('identity_summary', f'{expert_name}专业人士')}\n"""
    content += f"**我的专业背景**：{knowledge_system.get('background', '')}\n"
    content += f"**我能帮你做什么**：{knowledge_system.get('service_scope', '')}\n"
    content += f"**我不能做什么**：{knowledge_system.get('limitations', '')}\n\n"

    # 分析框架
    content += "## 分析框架\n"
    steps = analysis_framework.get('steps', [])
    for i, step in enumerate(steps, 1):
        if isinstance(step, str):
            content += f"### Step {i}: {step}\n\n"
        else:
            content += f"### Step {i}: {step.get('name', '步骤' + str(i))}\n"
            content += f"{step.get('description', '')}\n\n"

    # 决策启发式
    content += "## 决策启发式\n\n"
    for i, rule in enumerate(decision_rules, 1):
        condition = rule.get('condition', '')
        action = rule.get('action', '')
        scenario = rule.get('scenario', '')
        content += f"{i}. **{rule.get('name', '规则' + str(i))}**：{action}\n"
        if scenario:
            content += f"   - 应用场景：{scenario}\n"
        content += f"   - 条件：如果{condition}\n\n"

    # 表达规范DNA（v1.1新增）
    if expression_dna:
        content += "## 表达规范DNA\n\n"
        content += "角色扮演时必须遵循的风格规则：\n\n"

        # 专业术语使用
        content += "### 专业术语使用\n"
        content += "**必须使用的核心术语**：\n"
        for term in expression_dna.get('core_terms', []):
            content += f"- {term.get('name', '')}：{term.get('definition', '')}\n"

        content += "\n**避免使用的外行表述**：\n"
        for avoid in expression_dna.get('avoid_phrases', []):
            content += f"- 不说「{avoid.get('avoid', '')}」（专业说法是「{avoid.get('proper', '')}」）\n"

        # 表达结构偏好
        content += "\n### 表达结构偏好\n"
        content += f"- **结论方式**：{expression_dna.get('conclusion_style', '结论先行')}\n"
        content += f"- **论证强度**：{expression_dna.get('argument_strength', '充分论证')}\n"
        content += f"- **引用习惯**：{expression_dna.get('citation_style', '适度引用')}\n"
        content += f"- **数据使用**：{expression_dna.get('data_usage', '平衡')}\n"

        # 沟通风格
        content += "\n### 沟通风格\n"
        content += "| 对象 | 风格 | 示例 |\n"
        content += "|------|------|------|\n"
        for style_item in expression_dna.get('communication_styles', []):
            content += f"| {style_item.get('audience', '')} | {style_item.get('style', '')} | {style_item.get('example', '')} |\n"

        # 禁忌表达
        content += "\n### 禁忌表达\n"
        content += "此职业绝对不会使用的表述方式：\n"
        for taboo in expression_dna.get('taboos', []):
            content += f"- {taboo.get('phrase', '')} → 原因：{taboo.get('reason', '')}\n"

        content += "\n"

    # 职业伦理与边界
    content += "## 职业伦理与边界\n\n"
    content += "### 必须做的事\n"
    for must in ethics.get('must', []):
        content += f"- {must}\n"

    content += "\n### 绝对不做的事\n"
    for must_not in ethics.get('must_not', []):
        content += f"- {must_not}\n"

    content += "\n### 能力边界\n"
    for boundary in ethics.get('boundaries', []):
        content += f"- {boundary}\n"

    # 职业内在张力（v1.1新增）
    if internal_tensions:
        content += "\n## 职业内张力\n\n"
        content += "此职业视角中存在的内在矛盾和权衡：\n\n"
        for i, tension in enumerate(internal_tensions, 1):
            content += f"### 张力{i}: {tension.get('name', '')}\n"
            content += "**矛盾双方**：\n"
            content += f"- 一方：{tension.get('side_a', '')}\n"
            content += f"- 另一方：{tension.get('side_b', '')}\n\n"
            content += f"**冲突场景**：{tension.get('conflict_scenario', '')}\n\n"
            content += "**处理建议**：\n"
            for rec in tension.get('recommendations', []):
                content += f"- {rec}\n"
            content += "\n"

        # 价值观与反模式
        content += "---\n\n"
        content += "## 价值观与反模式\n\n"
        values = ethics.get('values', [])
        if values:
            content += f"**我追求的**：{'；'.join(values)}\n"
        anti_patterns = ethics.get('anti_patterns', [])
        if anti_patterns:
            content += f"**我拒绝的**：{'；'.join(anti_patterns)}\n"
        uncertainties = ethics.get('uncertainties', [])
        if uncertainties:
            content += f"**我也有困惑的**：{'；'.join(uncertainties)}\n"
        content += "\n"

    # 专业谱系（v1.1新增）
    if professional_lineage:
        content += "## 专业谱系\n\n"
        content += "### 理论来源\n"
        content += "此职业的核心理论来自哪些学科/流派：\n"
        for source in professional_lineage.get('theory_sources', []):
            content += f"- {source.get('name', '')}：{source.get('contribution', '')}\n"

        content += "\n### 方法论演进\n"
        content += "从传统做法到现代方法的演变：\n"
        for evolution in professional_lineage.get('methodology_evolution', []):
            content += f"- {evolution.get('period', '')}：{evolution.get('approach', '')}\n"

        content += "\n### 跨领域关联\n"
        content += "与哪些相关职业的方法论互通：\n"
        for related in professional_lineage.get('related_fields', []):
            content += f"- {related.get('profession', '')}：{related.get('shared_methodology', '')}\n"

        content += "\n"

    # 典型案例库
    cases = knowledge_system.get('cases', [])
    if cases:
        content += "## 典型案例库\n"
        for i, case in enumerate(cases, 1):
            content += f"### 案例{i}: {case.get('title', '')}\n"
            content += f"**背景**：{case.get('background', '')}\n\n"
            content += f"**分析**：{case.get('analysis', '')}\n\n"
            content += f"**结论**：{case.get('conclusion', '')}\n\n"

    # 资源工具
    tools = knowledge_system.get('tools', [])
    if tools:
        content += "## 资源工具\n"
        for tool in tools:
            content += f"- {tool}\n"
        content += "\n"

    # 回答工作流（v1.1增强）
    if answer_workflow:
        content += "## 回答工作流（Agentic Protocol）\n\n"
        content += f"**核心原则：{expert_name}不凭经验说话。遇到需要事实/数据的问题时，先做功课再回答。**\n\n"
        content += answer_workflow
    else:
        # 默认回答工作流
        content += """## 回答工作流（Agentic Protocol）

**核心原则：不凭经验说话。遇到需要事实/数据的问题时，先做功课再回答。**

### Step 1: 问题分类

收到问题后，先判断类型：

| 类型 | 特征 | 行动 |
|------|------|------|
| **需要事实的问题** | 涉及具体法规/案例/数据/市场现状 | → 先研究再回答 |
| **纯框架问题** | 方法论、理论讨论、假设分析 | → 直接用专业视角内核回答 |
| **混合问题** | 用具体案例讨论方法论 | → 先获取案例事实，再用框架分析 |

### Step 2: 研究获取事实

⚠️ 必须使用工具获取真实信息，不可跳过。

### Step 3: 基于事实的专业回答

运用专业视角内核和表达规范输出回答。
"""

    # 诚实边界
    content += "\n## 诚实边界\n"
    content += f"""本Skill基于{expert_name}的标准化知识体系构建。
- 不替代真实专业人士的法律/医疗等专业建议
- 知识更新依赖外部资源，可能存在滞后性
- 复杂案例建议咨询人类专家
- 对待敏感问题保持客观中立
"""

    return content


def main():
    parser = argparse.ArgumentParser(description='生成职业专家SKILL.md文件 (v1.1)')
    parser.add_argument('--expert_name', required=True, help='专家名称')
    parser.add_argument('--knowledge_system', required=True,
                       help='JSON格式知识体系')
    parser.add_argument('--analysis_framework', required=True,
                       help='JSON格式分析框架')
    parser.add_argument('--decision_rules', required=True,
                       help='JSON格式决策规则')
    parser.add_argument('--ethics', required=True,
                       help='JSON格式伦理边界')
    parser.add_argument('--expression_style', required=True,
                       help='JSON格式表达风格')
    parser.add_argument('--output_path', required=True, help='输出文件路径')
    # v1.1 新增参数（可选）
    parser.add_argument('--core_kernels', help='JSON格式专业视角内核（3-7个）')
    parser.add_argument('--expression_dna', help='JSON格式表达规范DNA')
    parser.add_argument('--internal_tensions', help='JSON格式职业内在张力')
    parser.add_argument('--professional_lineage', help='JSON格式专业谱系')
    parser.add_argument('--answer_workflow', help='回答工作流内容（Markdown字符串）')

    args = parser.parse_args()

    try:
        # 解析JSON参数
        knowledge_system = json.loads(args.knowledge_system)
        analysis_framework = json.loads(args.analysis_framework)
        decision_rules = json.loads(args.decision_rules)
        ethics = json.loads(args.ethics)
        expression_style = json.loads(args.expression_style)

        # v1.1 可选参数
        core_kernels = json.loads(args.core_kernels) if args.core_kernels else None
        expression_dna = json.loads(args.expression_dna) if args.expression_dna else None
        internal_tensions = json.loads(args.internal_tensions) if args.internal_tensions else None
        professional_lineage = json.loads(args.professional_lineage) if args.professional_lineage else None
        answer_workflow = args.answer_workflow  # 保持为字符串

        # 生成描述
        description = f"{args.expert_name}专家：提供专业的{knowledge_system.get('domain', '该领域')}分析与建议；当用户需要{knowledge_system.get('trigger_scenarios', '相关领域咨询')}时使用"

        # 生成完整内容
        yaml_frontmatter = generate_yaml_frontmatter(args.expert_name, description)
        skill_content = generate_skill_content(
            args.expert_name, knowledge_system, analysis_framework,
            decision_rules, ethics, expression_style,
            core_kernels, expression_dna, internal_tensions,
            professional_lineage, answer_workflow
        )

        full_content = yaml_frontmatter + "\n" + skill_content

        # 写入文件
        output_path = Path(args.output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(full_content, encoding='utf-8')

        result = {
            "status": "success",
            "message": "SKILL.md生成成功 (v1.1)",
            "output_path": str(output_path.absolute()),
            "expert_name": args.expert_name,
            "features": [
                "角色扮演规则",
                "专业视角内核" if core_kernels else None,
                "表达规范DNA" if expression_dna else None,
                "职业内在张力" if internal_tensions else None,
                "专业谱系" if professional_lineage else None,
                "回答工作流"
            ]
        }
        # 过滤掉None值
        result["features"] = [f for f in result["features"] if f]

        print(json.dumps(result, ensure_ascii=False))

    except json.JSONDecodeError as e:
        result = {
            "status": "error",
            "message": f"JSON解析失败: {str(e)}"
        }
        print(json.dumps(result, ensure_ascii=False))
        sys.exit(1)
    except Exception as e:
        result = {
            "status": "error",
            "message": f"生成失败: {str(e)}"
        }
        print(json.dumps(result, ensure_ascii=False))
        sys.exit(1)


if __name__ == "__main__":
    main()
