#!/usr/bin/env python3
"""
三重验证脚本
对提取的内容单元执行V1/V2/V3三重验证筛选
"""

import argparse
import json
import sys
from pathlib import Path


def verify_v1_cross_domain(content_unit):
    """
    V1 跨域验证
    判断：是否有至少2个独立来源佐证？
    """
    sources = content_unit.get('sources', [])
    if len(sources) >= 2:
        return {
            'result': '✅',
            'status': 'pass',
            'reason': f'有{len(sources)}个独立来源佐证',
            'evidence': sources
        }
    elif len(sources) == 1:
        return {
            'result': '⚠️',
            'status': 'pending',
            'reason': '只有1个来源提及',
            'evidence': sources
        }
    else:
        return {
            'result': '❌',
            'status': 'fail',
            'reason': '无明确出处或仅提及一次',
            'evidence': []
        }


def verify_v2_predictability(content_unit):
    """
    V2 预测力验证
    判断：能用它解决实际工作中的具体问题吗？
    """
    applications = content_unit.get('applications', [])
    if applications and len(applications) >= 1:
        return {
            'result': '✅',
            'status': 'pass',
            'reason': f'能解决{len(applications)}个实际工作问题',
            'evidence': applications
        }
    elif content_unit.get('theoretical_only', False):
        return {
            'result': '⚠️',
            'status': 'pending',
            'reason': '只能解释理论问题，无法解决实际问题',
            'evidence': []
        }
    else:
        return {
            'result': '❌',
            'status': 'fail',
            'reason': '无法迁移应用到实际场景',
            'evidence': []
        }


def verify_v3_uniqueness(content_unit):
    """
    V3 独特性验证
    判断：这不是任何聪明人都会说的常识吗？
    """
    unique_insights = content_unit.get('unique_insights', [])
    is_common_sense = content_unit.get('is_common_sense', False)

    if unique_insights and len(unique_insights) >= 1 and not is_common_sense:
        return {
            'result': '✅',
            'status': 'pass',
            'reason': '有独特洞见或反常识观点',
            'evidence': unique_insights
        }
    elif is_common_sense:
        return {
            'result': '❌',
            'status': 'fail',
            'reason': '纯属常识或陈词滥调',
            'evidence': []
        }
    else:
        return {
            'result': '⚠️',
            'status': 'pending',
            'reason': '有一定深度但不够独特',
            'evidence': unique_insights
        }


def determine_skill_level(v1_result, v2_result, v3_result):
    """
    根据三重验证结果确定技能等级
    """
    pass_count = sum([
        1 if v1_result['status'] == 'pass' else 0,
        1 if v2_result['status'] == 'pass' else 0,
        1 if v3_result['status'] == 'pass' else 0
    ])

    pending_count = sum([
        1 if v1_result['status'] == 'pending' else 0,
        1 if v2_result['status'] == 'pending' else 0,
        1 if v3_result['status'] == 'pending' else 0
    ])

    if pass_count == 3:
        return '核心'
    elif pass_count == 2 and pending_count == 1:
        return '辅助'
    else:
        return '淘汰'


def verify_content_unit(content_unit):
    """
    对单个内容单元执行三重验证
    """
    v1_result = verify_v1_cross_domain(content_unit)
    v2_result = verify_v2_predictability(content_unit)
    v3_result = verify_v3_uniqueness(content_unit)

    skill_level = determine_skill_level(v1_result, v2_result, v3_result)

    return {
        'unit_name': content_unit.get('name', '未知'),
        'type': content_unit.get('type', '未知'),
        'v1_cross_domain': v1_result,
        'v2_predictability': v2_result,
        'v3_uniqueness': v3_result,
        'skill_level': skill_level,
        'should_advance': skill_level in ['核心', '辅助'],
        'verification_summary': {
            'pass_count': sum([
                1 if v1_result['status'] == 'pass' else 0,
                1 if v2_result['status'] == 'pass' else 0,
                1 if v3_result['status'] == 'pass' else 0
            ]),
            'pending_count': sum([
                1 if v1_result['status'] == 'pending' else 0,
                1 if v2_result['status'] == 'pending' else 0,
                1 if v3_result['status'] == 'pending' else 0
            ]),
            'fail_count': sum([
                1 if v1_result['status'] == 'fail' else 0,
                1 if v2_result['status'] == 'fail' else 0,
                1 if v3_result['status'] == 'fail' else 0
            ])
        }
    }


def main():
    parser = argparse.ArgumentParser(description='三重验证脚本')
    parser.add_argument('--input_dir', required=True, help='原始提取内容目录（candidates/）')
    parser.add_argument('--output_dir', required=True, help='验证通过内容输出目录（skills/pending/）')
    parser.add_argument('--rejected_dir', required=True, help='未通过验证内容目录（rejected/）')
    parser.add_argument('--summary_output', help='验证汇总报告输出路径')

    args = parser.parse_args()

    try:
        input_dir = Path(args.input_dir)
        output_dir = Path(args.output_dir)
        rejected_dir = Path(args.rejected_dir)

        # 创建输出目录
        output_dir.mkdir(parents=True, exist_ok=True)
        rejected_dir.mkdir(parents=True, exist_ok=True)

        # 读取所有候选内容单元
        candidates_files = list(input_dir.glob('*.md'))
        candidates_files.extend(input_dir.glob('*.json'))

        if not candidates_files:
            result = {
                'status': 'warning',
                'message': '未找到候选内容文件',
                'input_dir': str(input_dir)
            }
            print(json.dumps(result, ensure_ascii=False))
            return

        # 验证所有内容单元
        verification_results = []
        passed_units = []
        rejected_units = []

        for file_path in candidates_files:
            # 读取文件内容（这里简化处理，实际应根据文件类型解析）
            content_unit = {
                'name': file_path.stem,
                'type': file_path.suffix[1:],
                'sources': ['来源1', '来源2'],  # 示例数据
                'applications': ['应用场景1'],  # 示例数据
                'unique_insights': ['独特点1'],  # 示例数据
                'is_common_sense': False  # 示例数据
            }

            # 执行三重验证
            verification = verify_content_unit(content_unit)
            verification['source_file'] = str(file_path.name)
            verification_results.append(verification)

            # 分类输出
            if verification['should_advance']:
                passed_units.append(verification)
            else:
                rejected_units.append(verification)

        # 生成汇总报告
        summary = {
            'total_units': len(verification_results),
            'passed': len(passed_units),
            'rejected': len(rejected_units),
            'pass_rate': len(passed_units) / len(verification_results) if verification_results else 0,
            'core_skills': len([u for u in passed_units if u['skill_level'] == '核心']),
            'auxiliary_skills': len([u for u in passed_units if u['skill_level'] == '辅助']),
            'verification_results': verification_results
        }

        # 输出汇总报告
        if args.summary_output:
            summary_path = Path(args.summary_output)
            summary_path.parent.mkdir(parents=True, exist_ok=True)
            summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')

        result = {
            'status': 'success',
            'message': '三重验证完成',
            'summary': summary,
            'output_dirs': {
                'passed': str(output_dir.absolute()),
                'rejected': str(rejected_dir.absolute())
            }
        }
        print(json.dumps(result, ensure_ascii=False))

    except Exception as e:
        result = {
            'status': 'error',
            'message': f'验证失败: {str(e)}'
        }
        print(json.dumps(result, ensure_ascii=False))
        sys.exit(1)


if __name__ == "__main__":
    main()
