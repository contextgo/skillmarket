#!/usr/bin/env python3
"""
质量验证脚本 (v1.1)
验证专家Skill的质量指标，生成质量报告
"""

import argparse
import json
import sys
import re
from pathlib import Path


def validate_skill_structure(skill_path: str) -> dict:
    """验证Skill结构完整性"""
    skill_file = Path(skill_path)
    if not skill_file.exists():
        raise FileNotFoundError(f"Skill文件不存在: {skill_path}")

    content = skill_file.read_text(encoding='utf-8')

    # 验证YAML前言区
    yaml_match = re.match(r'^---\n(.*?)\n---', content, re.DOTALL)
    if not yaml_match:
        return {
            "valid": False,
            "error": "缺少YAML前言区"
        }

    yaml_content = yaml_match.group(1)
    markdown_content = content[yaml_match.end():]

    # 验证必需字段
    if 'name:' not in yaml_content:
        return {
            "valid": False,
            "error": "YAML中缺少name字段"
        }

    if 'description:' not in yaml_content:
        return {
            "valid": False,
            "error": "YAML中缺少description字段"
        }

    # 验证description长度（100-150字符）
    desc_match = re.search(r'description:\s*(.+)', yaml_content)
    if desc_match:
        description = desc_match.group(1).strip()
        char_count = len(description)
        if char_count < 100 or char_count > 150:
            return {
                "valid": False,
                "error": f"description长度不符合要求（当前{char_count}字符，要求100-150字符）"
            }

    # 验证正文必需章节（v1.1增强）
    required_sections = [
        "核心理念",
        "专业视角内核",
        "角色扮演规则",
        "分析框架",
        "决策启发式",
        "职业伦理与边界",
        "回答工作流",
        "诚实边界"
    ]

    missing_sections = []
    for section in required_sections:
        if section not in markdown_content:
            missing_sections.append(section)

    optional_sections = [
        "表达规范DNA",
        "职业内在张力",
        "专业谱系",
        "典型案例库",
        "资源工具"
    ]

    missing_optional = []
    for section in optional_sections:
        if section not in markdown_content:
            missing_optional.append(section)

    return {
        "valid": len(missing_sections) == 0,
        "yaml_valid": True,
        "required_sections": {
            "total": len(required_sections),
            "present": len(required_sections) - len(missing_sections),
            "missing": missing_sections
        },
        "optional_sections": {
            "total": len(optional_sections),
            "present": len(optional_sections) - len(missing_optional),
            "missing": missing_optional
        },
        "description_length": len(desc_match.group(1).strip()) if desc_match else 0
    }


def calculate_quality_metrics(skill_content: str) -> dict:
    """计算质量指标（简化版，实际应由智能体完成）"""
    metrics = {
        "knowledge_coverage": 0.85,  # 示例值
        "logical_consistency": 0.85,
        "operability": 0.80,
        "professional_standards": 0.90
    }

    # 简单的内容统计
    content_length = len(skill_content)
    metrics["content_length"] = content_length

    # 统计关键词出现频率（简化）
    keywords = ["概念", "理论", "案例", "规则", "框架"]
    keyword_counts = {}
    for keyword in keywords:
        count = skill_content.count(keyword)
        keyword_counts[keyword] = count

    metrics["keyword_counts"] = keyword_counts

    return metrics


def generate_quality_report(skill_path: str) -> dict:
    """生成质量报告"""
    # 验证结构
    structure_validation = validate_skill_structure(skill_path)

    if not structure_validation["valid"]:
        return {
            "status": "error",
            "error": structure_validation["error"],
            "structure_validation": structure_validation
        }

    # 读取内容
    skill_file = Path(skill_path)
    content = skill_file.read_text(encoding='utf-8')

    # 计算质量指标
    metrics = calculate_quality_metrics(content)

    # 生成报告
    report = {
        "status": "success",
        "skill_path": str(skill_file.absolute()),
        "structure_validation": structure_validation,
        "quality_metrics": metrics,
        "overall_score": sum(metrics.values()) / len(metrics),
        "recommendations": generate_recommendations(metrics, structure_validation)
    }

    return report


def generate_recommendations(metrics: dict, structure_validation: dict) -> list:
    """生成改进建议"""
    recommendations = []

    # 检查必需章节
    missing = structure_validation["required_sections"]["missing"]
    if missing:
        recommendations.append({
            "type": "missing_sections",
            "severity": "high",
            "message": f"缺少必需章节: {', '.join(missing)}",
            "action": "补充缺失的章节内容"
        })

    # 检查质量指标
    if metrics["knowledge_coverage"] < 0.80:
        recommendations.append({
            "type": "low_coverage",
            "severity": "high",
            "message": f"知识覆盖率不足（{metrics['knowledge_coverage']}）",
            "action": "补充更多核心概念、案例和理论框架"
        })

    if metrics["logical_consistency"] < 0.75:
        recommendations.append({
            "type": "inconsistent_logic",
            "severity": "medium",
            "message": f"逻辑一致性不足（{metrics['logical_consistency']}）",
            "action": "检查分析框架的逻辑关系，修复断裂点"
        })

    if metrics["operability"] < 0.75:
        recommendations.append({
            "type": "low_operability",
            "severity": "medium",
            "message": f"可操作性不足（{metrics['operability']}）",
            "action": "细化决策规则的触发条件和行动建议"
        })

    if metrics["professional_standards"] < 0.80:
        recommendations.append({
            "type": "low_standards",
            "severity": "medium",
            "message": f"专业规范性不足（{metrics['professional_standards']}）",
            "action": "统一术语使用，规范表达风格"
        })

    # 检查可选章节
    missing_optional = structure_validation["optional_sections"]["missing"]
    if missing_optional:
        recommendations.append({
            "type": "missing_optional_sections",
            "severity": "low",
            "message": f"缺少可选章节（可增强）：{', '.join(missing_optional)}",
            "action": "根据需要补充可选章节内容"
        })

    return recommendations


def main():
    parser = argparse.ArgumentParser(description='质量验证脚本 (v1.1)')
    parser.add_argument('--skill_path', required=True, help='专家SKILL.md文件路径')
    parser.add_argument('--output_report', help='质量报告输出路径（Markdown格式）')
    parser.add_argument('--output_json', help='质量报告输出路径（JSON格式）')

    args = parser.parse_args()

    try:
        # 生成质量报告
        report = generate_quality_report(args.skill_path)

        # 如果有错误，直接返回
        if report["status"] == "error":
            print(json.dumps(report, ensure_ascii=False))
            sys.exit(1)

        # 输出JSON
        if args.output_json:
            output_path = Path(args.output_json)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')

        # 输出Markdown报告
        if args.output_report:
            markdown_report = format_markdown_report(report)
            output_path = Path(args.output_report)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(markdown_report, encoding='utf-8')

        # 输出结果
        result = {
            "status": "success",
            "message": "质量验证完成",
            "overall_score": report["overall_score"],
            "skill_path": report["skill_path"],
            "recommendations_count": len(report["recommendations"]),
            "outputs": []
        }

        if args.output_json:
            result["outputs"].append(str(Path(args.output_json).absolute()))
        if args.output_report:
            result["outputs"].append(str(Path(args.output_report).absolute()))

        print(json.dumps(result, ensure_ascii=False))

    except FileNotFoundError as e:
        result = {
            "status": "error",
            "message": str(e)
        }
        print(json.dumps(result, ensure_ascii=False))
        sys.exit(1)
    except Exception as e:
        result = {
            "status": "error",
            "message": f"验证失败: {str(e)}"
        }
        print(json.dumps(result, ensure_ascii=False))
        sys.exit(1)


def format_markdown_report(report: dict) -> str:
    """格式化Markdown报告"""
    lines = []

    lines.append("# 质量验证报告")
    lines.append("")
    lines.append(f"**Skill路径**: {report['skill_path']}")
    lines.append(f"**总体评分**: {report['overall_score']:.2f}")
    lines.append("")

    # 结构验证
    lines.append("## 结构验证")
    lines.append("")
    sv = report["structure_validation"]
    lines.append(f"- YAML前言区: {'✅ 通过' if sv['yaml_valid'] else '❌ 失败'}")
    lines.append(f"- 必需章节: {sv['required_sections']['present']}/{sv['required_sections']['total']}")
    if sv["required_sections"]["missing"]:
        lines.append(f"  - 缺失: {', '.join(sv['required_sections']['missing'])}")
    lines.append(f"- 可选章节: {sv['optional_sections']['present']}/{sv['optional_sections']['total']}")
    lines.append("")

    # 质量指标
    lines.append("## 质量指标")
    lines.append("")
    metrics = report["quality_metrics"]
    lines.append(f"- 知识覆盖率: {metrics['knowledge_coverage']:.2f}")
    lines.append(f"- 逻辑一致性: {metrics['logical_consistency']:.2f}")
    lines.append(f"- 可操作性: {metrics['operability']:.2f}")
    lines.append(f"- 专业规范性: {metrics['professional_standards']:.2f}")
    lines.append("")

    # 改进建议
    lines.append("## 改进建议")
    lines.append("")

    if not report["recommendations"]:
        lines.append("✅ 无需改进")
    else:
        for i, rec in enumerate(report["recommendations"], 1):
            severity_emoji = {
                "high": "🔴",
                "medium": "🟡",
                "low": "🟢"
            }.get(rec["severity"], "⚪")

            lines.append(f"{i}. {severity_emoji} {rec['message']}")
            lines.append(f"   - 行动: {rec['action']}")
            lines.append("")

    return "\n".join(lines)


if __name__ == "__main__":
    main()
