#!/usr/bin/env python3
"""
自测问题生成脚本
为每个技能卡片设计自测问题
"""

import argparse
import json
import sys
from pathlib import Path


def generate_self_test_questions(skill_card):
    """
    为技能卡片生成自测问题
    """
    skill_name = skill_card.get('name', '未知技能')
    trigger_conditions = skill_card.get('trigger_conditions', [])
    boundary_conditions = skill_card.get('boundary_conditions', [])

    self_test = {
        'skill_name': skill_name,
        'should_use_scenarios': [],
        'should_not_use_scenarios': [],
        'boundary_scenarios': []
    }

    # 生成应该使用此方法的场景（2题）
    for i, trigger in enumerate(trigger_conditions[:2], 1):
        self_test['should_use_scenarios'].append({
            'scenario_number': i,
            'description': trigger.get('description', ''),
            'correct_answer': '使用此方法',
            'reason': f"符合Trigger条件：{trigger.get('condition', '')}",
            'evidence': trigger.get('evidence', [])
        })

    # 生成不应该使用此方法的场景（2题）
    for i, boundary in enumerate(boundary_conditions[:2], 3):
        self_test['should_not_use_scenarios'].append({
            'scenario_number': i,
            'description': boundary.get('description', ''),
            'correct_answer': '不适用',
            'reason': f"属于Boundary中定义的不适用场景：{boundary.get('reason', '')}",
            'alternative_method': boundary.get('alternative_method', '')
        })

    # 生成边界场景（1题）
    if trigger_conditions and boundary_conditions:
        self_test['boundary_scenarios'].append({
            'scenario_number': 5,
            'description': '需要判断的边界场景',
            'correct_answer': '需要判断',
            'judgment_criteria': [
                trigger_conditions[0].get('condition', ''),
                boundary_conditions[0].get('reason', '')
            ],
            'suggestion': '如果满足Trigger条件则用，如果满足Boundary条件则不用'
        })

    return self_test


def format_self_test_markdown(self_test):
    """
    将自测问题格式化为Markdown
    """
    lines = []

    lines.append(f"# {self_test['skill_name']} - 自测问题")
    lines.append("")

    # 应该使用此方法的场景
    lines.append("## 应该使用此方法的场景")
    lines.append("")

    for scenario in self_test['should_use_scenarios']:
        lines.append(f"### 场景{scenario['scenario_number']}")
        lines.append(f"**场景描述：** {scenario['description']}")
        lines.append("")
        lines.append(f"**正确答案：** {scenario['correct_answer']}")
        lines.append(f"**理由：** {scenario['reason']}")
        if scenario.get('evidence'):
            lines.append("**判断依据：**")
            for evidence in scenario['evidence']:
                lines.append(f"- {evidence}")
        lines.append("")
        lines.append("---")
        lines.append("")

    # 不应该使用此方法的场景
    lines.append("## 不应该使用此方法的场景（诱饵）")
    lines.append("")

    for scenario in self_test['should_not_use_scenarios']:
        lines.append(f"### 场景{scenario['scenario_number']}")
        lines.append(f"**场景描述：** {scenario['description']}")
        lines.append("")
        lines.append(f"**正确答案：** {scenario['correct_answer']}")
        lines.append(f"**理由：** {scenario['reason']}")
        if scenario.get('alternative_method'):
            lines.append(f"**替代方法：** {scenario['alternative_method']}")
        lines.append("")
        lines.append("---")
        lines.append("")

    # 边界场景
    lines.append("## 边界场景")
    lines.append("")

    for scenario in self_test['boundary_scenarios']:
        lines.append(f"### 场景{scenario['scenario_number']}")
        lines.append(f"**场景描述：** {scenario['description']}")
        lines.append("")
        lines.append(f"**正确答案：** {scenario['correct_answer']}")
        lines.append("**判断依据：**")
        for criteria in scenario['judgment_criteria']:
            lines.append(f"- {criteria}")
        lines.append("")
        lines.append(f"**建议：** {scenario['suggestion']}")
        lines.append("")

    # 测试评分表格
    lines.append("## 测试评分")
    lines.append("")
    lines.append("| 场景 | 你的答案 | 正确答案 | 理由 |")
    lines.append("|------|---------|---------|------|")

    total_scenarios = (
        len(self_test['should_use_scenarios']) +
        len(self_test['should_not_use_scenarios']) +
        len(self_test['boundary_scenarios'])
    )

    for i in range(1, total_scenarios + 1):
        lines.append(f"| 场景{i} | | | |")

    lines.append("")
    lines.append(f"**得分：** ___/{total_scenarios}")
    lines.append("")
    lines.append("**掌握程度评估：**")
    lines.append(f"- {total_scenarios}分：完全掌握")
    lines.append(f"- {total_scenarios-1}分：基本掌握")
    lines.append(f"- {total_scenarios-2}分：部分掌握")
    lines.append(f"- {total_scenarios-3}分：需要加强")
    lines.append(f"- 1分：需要重新学习")

    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description='自测问题生成脚本')
    parser.add_argument('--skills_dir', required=True, help='技能卡片目录（skills/）')
    parser.add_argument('--output_dir', required=True, help='自测问题输出目录（tests/）')
    parser.add_argument('--format', choices=['json', 'markdown', 'both'], default='both', help='输出格式')

    args = parser.parse_args()

    try:
        skills_dir = Path(args.skills_dir)
        output_dir = Path(args.output_dir)

        # 创建输出目录
        output_dir.mkdir(parents=True, exist_ok=True)

        # 读取所有技能卡片
        skill_files = list(skills_dir.glob('skill-*.md'))
        skill_files.extend(skills_dir.glob('skill-*.json'))

        if not skill_files:
            result = {
                'status': 'warning',
                'message': '未找到技能卡片文件',
                'skills_dir': str(skills_dir)
            }
            print(json.dumps(result, ensure_ascii=False))
            return

        # 生成自测问题
        generated_tests = []
        summary = {
            'total_skills': len(skill_files),
            'generated_tests': 0,
            'total_questions': 0
        }

        for skill_file in skill_files:
            # 读取技能卡片（这里简化处理，实际应根据文件类型解析）
            skill_card = {
                'name': skill_file.stem.replace('skill-', ''),
                'trigger_conditions': [
                    {
                        'description': '触发条件示例1',
                        'condition': '条件1',
                        'evidence': ['证据1', '证据2']
                    },
                    {
                        'description': '触发条件示例2',
                        'condition': '条件2',
                        'evidence': ['证据3']
                    }
                ],
                'boundary_conditions': [
                    {
                        'description': '边界条件示例1',
                        'reason': '不适用原因1',
                        'alternative_method': '替代方法1'
                    },
                    {
                        'description': '边界条件示例2',
                        'reason': '不适用原因2',
                        'alternative_method': '替代方法2'
                    }
                ]
            }

            # 生成自测问题
            self_test = generate_self_test_questions(skill_card)
            generated_tests.append(self_test)

            # 计算问题数量
            total_questions = (
                len(self_test['should_use_scenarios']) +
                len(self_test['should_not_use_scenarios']) +
                len(self_test['boundary_scenarios'])
            )

            summary['generated_tests'] += 1
            summary['total_questions'] += total_questions

            # 输出文件
            output_filename = f"test-{skill_file.stem.replace('skill-', '')}.md"

            if args.format in ['json', 'both']:
                json_path = output_dir / f"{output_filename}.json"
                json_path.write_text(json.dumps(self_test, ensure_ascii=False, indent=2), encoding='utf-8')

            if args.format in ['markdown', 'both']:
                markdown_path = output_dir / output_filename
                markdown_content = format_self_test_markdown(self_test)
                markdown_path.write_text(markdown_content, encoding='utf-8')

        # 生成汇总报告
        summary_report = {
            'summary': summary,
            'generated_tests': generated_tests
        }

        summary_path = output_dir / 'self-tests-summary.json'
        summary_path.write_text(json.dumps(summary_report, ensure_ascii=False, indent=2), encoding='utf-8')

        result = {
            'status': 'success',
            'message': '自测问题生成完成',
            'summary': summary,
            'output_dir': str(output_dir.absolute())
        }
        print(json.dumps(result, ensure_ascii=False))

    except Exception as e:
        result = {
            'status': 'error',
            'message': f'生成失败: {str(e)}'
        }
        print(json.dumps(result, ensure_ascii=False))
        sys.exit(1)


if __name__ == "__main__":
    main()
