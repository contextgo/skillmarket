# 双Agent精炼工作流指南

## 概览
本文档详细说明双Agent精炼模块的工作流程、评估标准和实施方法，用于Phase 5对生成的专家Skill进行质量提升和优化。

## 工作流程

```
生成的专家Skill
  ↓
Agent A: 结构评审
  ↓ 输出：结构评审报告
Agent B: 内容优化
  ↓ 输出：优化建议方案
用户确认
  ↓ [接受/修改/重新精炼/跳过]
精炼后的专家Skill
  ↓ [可选迭代]
质量验证
```

## Agent A: 结构评审专家

### 核心职责
评估专家Skill的完整性和合理性，识别结构性问题并提供改进方向。

### 评审维度（v1.1增强）

#### 1. 专业视角内核（v1.1新增）
**评估要点**：
- 是否有3-7个可验证的核心方法论
- 每个内核是否满足三重验证
  - 验证1：跨场景复现（≥2个不同职业场景）
  - 验证2：生成力（推断新问题的处理方式）
  - 验证3：专业独特性（不是所有职业都这样看问题）

**验收标准**：
- 优秀：3-7个内核，全部通过三重验证
- 良好：3-7个内核，大部分通过验证
- 需改进：内核数量不足或验证不充分

**评分权重**：20%

#### 2. 角色扮演规则（v1.1新增）
**评估要点**：
- 是否有沉浸式扮演规则
- 是否有免责声明模板（法律/医疗/财务/通用）
- 是否有退出角色机制
- 是否有身份卡（我是谁、专业背景、服务范围、能力边界）

**验收标准**：
- 优秀：所有要素完整，免责声明根据领域自动适配
- 良好：大部分要素完整
- 需改进：缺少关键要素或免责声明不准确

**评分权重**：15%

#### 3. 知识体系
**评估要点**：
- 核心概念数量（≥5个）
- 理论框架数量（≥2个）
- 概念定义是否清晰
- 理论框架是否与职业相关

**验收标准**：
- 优秀：≥8个核心概念，≥3个理论框架，定义清晰
- 良好：≥5个核心概念，≥2个理论框架
- 需改进：核心概念或理论框架不足

**评分权重**：15%

#### 4. 分析框架
**评估要点**：
- 步骤数量是否合理（3-6步）
- 步骤间是否有明确的输入输出关系
- 逻辑是否连贯
- 是否覆盖问题解决的全流程

**验收标准**：
- 优秀：4-6步，逻辑严密，覆盖完整
- 良好：3-5步，逻辑基本连贯
- 需改进：步骤过少或逻辑断裂

**评分权重**：15%

#### 5. 决策启发式
**评估要点**：
- 规则数量（5-10条）
- 每条规则是否有明确的条件和行动
- 规则是否覆盖主要场景
- 规则是否具体可操作

**验收标准**：
- 优秀：8-10条，每条都有条件+行动+场景
- 良好：5-8条，规则基本完整
- 需改进：规则过少或条件不明确

**评分权重**：10%

#### 6. 表达规范DNA（v1.1新增）
**评估要点**：
- 是否有专业术语使用规则
- 是否有禁忌词列表
- 是否有沟通风格矩阵（对不同对象的表达方式）
- 是否有表达结构偏好（结论方式、论证强度、引用习惯、数据使用）

**验收标准**：
- 优秀：所有要素完整，量化清晰
- 良好：大部分要素完整
- 需改进：缺少关键要素

**评分权重**：10%

#### 7. 职业内在张力（v1.1新增）
**评估要点**：
- 是否承认职业矛盾和张力
- 是否有≥2对张力识别
- 是否有冲突场景和处理建议
- 是否有价值观与反模式

**验收标准**：
- 优秀：≥3对张力，有完整的冲突场景和处理建议
- 良好：≥2对张力
- 需改进：缺少张力识别或张力度不足

**评分权重**：5%

#### 8. 专业谱系（v1.1新增）
**评估要点**：
- 是否有理论来源
- 是否有方法论演进
- 是否有跨领域关联

**验收标准**：
- 优秀：≥2个理论来源，完整的演进历程
- 良好：≥1个理论来源，基本的演进描述
- 需改进：缺少谱系信息

**评分权重**：5%

#### 9. 回答工作流（v1.1新增）
**评估要点**：
- 是否有动态研究能力
- 是否有问题分类机制
- 是否有研究维度设计
- 是否有基于事实的回答方式

**验收标准**：
- 优秀：完整的问题分类→研究→回答流程，研究维度具体
- 良好：基本的研究流程
- 需改进：缺少动态研究能力

**评分权重**：3%

#### 10. 伦理边界
**评估要点**：
- 必须做的事是否明确
- 绝对不做的事是否清晰
- 能力边界是否准确

**验收标准**：
- 优秀：三个层次都明确，边界清晰
- 良好：大部分层次明确
- 需改进：边界模糊或缺失

**评分权重**：1%

#### 11. 诚实边界
**评估要点**：
- 是否明确Skill的局限性
- 是否有替代真实专业人士的免责

**验收标准**：
- 优秀：完整的能力边界说明
- 良好：基本的能力边界
- 需改进：缺少诚实边界

**评分权重**：1%

### 输出格式：结构评审报告

```json
{
  "overall_score": 0.85,
  "dimensions": {
    "core_kernels": {
      "score": 0.90,
      "kernel_count": 5,
      "validation_status": "pass",
      "issues": []
    },
    "role_play_rules": {
      "score": 0.95,
      "identity_card": "complete",
      "disclaimer": "legal_template",
      "exit_mechanism": "present",
      "issues": []
    },
    "knowledge_system": {
      "score": 0.80,
      "concept_count": 6,
      "theory_count": 2,
      "issues": [
        {
          "type": "knowledge_gap",
          "severity": "low",
          "suggestion": "补充更多经济犯罪案例"
        }
      ]
    },
    "analysis_framework": {
      "score": 0.85,
      "step_count": 4,
      "logical_consistency": 0.90,
      "issues": []
    },
    "decision_rules": {
      "score": 0.75,
      "rule_count": 5,
      "issues": [
        {
          "type": "vague_condition",
          "severity": "medium",
          "suggestion": "规则2的条件需要更具体"
        }
      ]
    },
    "expression_dna": {
      "score": 0.90,
      "core_terms": "complete",
      "taboos": "complete",
      "communication_styles": "complete",
      "issues": []
    },
    "internal_tensions": {
      "score": 0.80,
      "tension_count": 2,
      "issues": []
    },
    "professional_lineage": {
      "score": 0.75,
      "theory_sources": 1,
      "issues": [
        {
          "type": "insufficient_sources",
          "severity": "low",
          "suggestion": "补充更多理论来源"
        }
      ]
    },
    "answer_workflow": {
      "score": 0.85,
      "research_capability": "present",
      "classification": "present",
      "issues": []
    },
    "ethical_boundary": {
      "score": 0.95,
      "must_do": "clear",
      "must_not_do": "clear",
      "capability_boundary": "clear",
      "issues": []
    },
    "honesty_boundary": {
      "score": 0.90,
      "limitations": "explicit",
      "issues": []
    }
  },
  "priority_issues": [
    {
      "dimension": "decision_rules",
      "type": "vague_condition",
      "severity": "medium",
      "suggestion": "规则2的条件需要更具体"
    }
  ]
}
```

## Agent B: 内容优化专家

### 核心职责
根据Agent A的评审报告，生成具体的优化建议和改进方案。

### 优化维度

#### 1. 知识补充
**触发条件**：知识覆盖率<0.85 或 评审报告中标识为knowledge_gap
**优化策略**：
- 补充缺失的核心概念
- 增加相关案例
- 补充法规规范
- 扩展理论框架

**输出示例**：
```json
{
  "location": "knowledge_system",
  "action": "add",
  "target": "core_concepts",
  "content": "经济犯罪：指在经济活动中违反法律法规，破坏经济秩序的行为"
}
```

#### 2. 逻辑优化
**触发条件**：逻辑一致性<0.80 或 评审报告中标识为逻辑问题
**优化策略**：
- 调整分析框架的步骤顺序
- 优化决策规则的触发条件
- 明确步骤间的输入输出关系
- 修复逻辑断裂点

**输出示例**：
```json
{
  "location": "analysis_framework",
  "action": "modify",
  "target": "step_3",
  "content": "将步骤3前置到步骤2之前，确保先收集证据再进行分析"
}
```

#### 3. 规则细化
**触发条件**：决策规则清晰度<0.80 或 评审报告中标识为条件模糊
**优化策略**：
- 明确模糊的触发条件
- 细化行动建议
- 增加应用场景说明
- 提供判断依据

**输出示例**：
```json
{
  "location": "decision_rules",
  "action": "refine",
  "target": "rule_2",
  "content": "将'合同条款无效'细化为'依据《民法典》第153条，违反法律强制性规定的条款无效'"
}
```

#### 4. 边界明确
**触发条件**：伦理边界明确性<0.80
**优化策略**：
- 澄清能力边界
- 补充伦理说明
- 明确禁忌事项
- 增加边界案例

**输出示例**：
```json
{
  "location": "ethical_boundary",
  "action": "add",
  "target": "capability_boundary",
  "content": "不能处理国际法问题，仅限中国法律体系"
}
```

#### 5. 风格统一
**触发条件**：表达规范一致性<0.80
**优化策略**：
- 统一术语使用
- 调整表达风格
- 规范文档格式
- 修正语法错误

**输出示例**：
```json
{
  "location": "expression_dna",
  "action": "standardize",
  "target": "terminology",
  "content": "统一使用'被告人'而非'嫌疑人'（除非在侦查阶段）"
}
```

### 知识融合机制

**优先级**：
1. 用户私有知识（最高优先级）
2. 网络搜索补充的公共知识
3. 智能体推理生成的知识

**知识来源追踪**：
```json
{
  "knowledge_source": "user_upload",
  "file_path": "/path/to/document.pdf",
  "confidence": 0.95
}
```

### 输出格式：优化建议方案

```json
{
  "refinement": {
    "knowledge_suggestions": [
      {
        "location": "knowledge_system",
        "action": "add",
        "target": "core_concepts",
        "content": "经济犯罪：指在经济活动中违反法律法规，破坏经济秩序的行为",
        "source": "network_search",
        "confidence": 0.85
      },
      {
        "location": "knowledge_system",
        "action": "add",
        "target": "cases",
        "content": "案例：某公司财务造假案（2023）",
        "source": "user_upload",
        "confidence": 0.95
      }
    ],
    "logic_suggestions": [
      {
        "location": "analysis_framework",
        "action": "modify",
        "target": "step_3",
        "content": "将步骤3前置到步骤2之前，确保先收集证据再进行分析"
      }
    ],
    "rule_suggestions": [
      {
        "location": "decision_rules",
        "action": "refine",
        "target": "rule_2",
        "content": "将'合同条款无效'细化为'依据《民法典》第153条，违反法律强制性规定的条款无效'"
      }
    ],
    "boundary_suggestions": [
      {
        "location": "ethical_boundary",
        "action": "add",
        "target": "capability_boundary",
        "content": "不能处理国际法问题，仅限中国法律体系"
      }
    ],
    "style_suggestions": [
      {
        "location": "expression_dna",
        "action": "standardize",
        "target": "terminology",
        "content": "统一使用'被告人'而非'嫌疑人'（除非在侦查阶段）"
      }
    ]
  },
  "estimated_improvement": {
    "knowledge_coverage": 0.85,
    "logical_consistency": 0.85,
    "decision_clarity": 0.90,
    "ethical_boundary": 0.95,
    "expression_consistency": 0.90
  }
}
```

## 用户确认检查点

### 展示内容

#### 1. 结构评审报告
- 总体评分
- 各维度详细评分
- 优先级问题列表

#### 2. 优化建议方案
- 各类优化建议
- 预计改进效果

#### 3. 改进对比
| 维度 | 当前评分 | 预计评分 | 改进幅度 |
|------|---------|---------|---------|
| 知识覆盖率 | 0.75 | 0.85 | +0.10 |
| 逻辑一致性 | 0.75 | 0.85 | +0.10 |
| 决策规则清晰度 | 0.75 | 0.90 | +0.15 |

### 用户操作选项

#### [接受] 应用所有优化建议
- 自动应用所有优化建议
- 更新SKILL.md文件
- 生成优化报告

#### [修改] 选择性应用部分建议
- 展示所有优化建议
- 用户勾选需要应用的建议
- 更新SKILL.md文件
- 生成优化报告

#### [重新精炼] 重新执行Agent A评审
- 重新执行结构评审
- 可能产生不同的评审结果

#### [跳过] 保持当前版本
- 不应用任何优化
- 直接进入下一阶段

## 迭代精炼策略

### 质量阈值

| 维度 | 最低要求 | 理想目标 |
|------|---------|---------|
| 知识覆盖率 | ≥0.80 | ≥0.90 |
| 逻辑一致性 | ≥0.75 | ≥0.85 |
| 可操作性 | ≥0.75 | ≥0.85 |
| 专业规范性 | ≥0.80 | ≥0.90 |

### 迭代规则

1. 如果任一维度低于最低要求，自动触发新一轮精炼
2. 每轮精炼最多迭代3次
3. 3次后仍未达标，进入人工干预流程
4. 每轮精炼后生成进度报告

### 进度报告格式

```markdown
# 精炼进度报告

## 第1轮精炼

### 输入评分
- 知识覆盖率: 0.75
- 逻辑一致性: 0.75
- 可操作性: 0.75
- 专业规范性: 0.80

### 优化应用
- 知识补充: 3项
- 逻辑优化: 1项
- 规则细化: 2项
- 边界明确: 1项

### 输出评分
- 知识覆盖率: 0.85
- 逻辑一致性: 0.85
- 可操作性: 0.80
- 专业规范性: 0.85

### 改进幅度
- 知识覆盖率: +0.10
- 逻辑一致性: +0.10
- 可操作性: +0.05
- 专业规范性: +0.05

### 状态
✅ 所有维度达标，精炼完成
```

## 质量验证指标

### 指标说明

#### 知识覆盖率
**计算方法**：(实际包含的知识要素 / 应包含的知识要素) × 100%
**应包含的知识要素**：
- 核心概念：≥8个
- 理论框架：≥3个
- 典型案例：≥5个
- 决策规则：≥8条

#### 逻辑一致性
**评估方法**：
- 步骤间的逻辑关系是否连贯
- 输入输出是否明确
- 是否存在矛盾或断裂

#### 可操作性
**评估方法**：
- 决策规则是否具体可执行
- 条件是否明确
- 行动是否可操作

#### 专业规范性
**评估方法**：
- 表达风格是否专业
- 术语使用是否准确
- 格式是否规范

## 使用示例

### 示例1: 完整精炼流程

```bash
# 步骤1: 执行精炼
python scripts/refine_skill.py \
  --skill_path "/workspace/projects/criminal-law-expert/SKILL.md" \
  --output_path "/workspace/projects/criminal-law-expert/optimization_suggestions.json"

# 步骤2: 用户确认
# 查看评审报告和优化建议
# 选择"接受"应用所有建议

# 步骤3: 质量验证
python scripts/validate_skill_quality.py \
  --skill_path "/workspace/projects/criminal-law-expert/SKILL.md" \
  --output_report "/workspace/projects/criminal-law-expert/quality_report.md"
```

### 示例2: 迭代精炼

```bash
# 第1轮精炼
python scripts/refine_skill.py --skill_path "..." --output_path "..."

# 查看质量报告，发现知识覆盖率仍低于0.80
# 触发第2轮精炼

python scripts/refine_skill.py --skill_path "..." --output_path "..." \
  --focus_on "knowledge_coverage"

# 第2轮精炼完成，所有指标达标
```

## 注意事项

1. **智能体主导流程**：Agent A和Agent B的评审和优化由智能体完成，脚本仅提供工具支持
2. **用户确认必选**：每轮精炼后必须等待用户确认
3. **知识来源追踪**：所有补充的知识必须记录来源
4. **迭代上限控制**：最多迭代3次，避免无限循环
5. **人工干预机制**：3次后仍未达标，进入人工干预流程

## 附录

### A. 评分标准

| 评分范围 | 等级 | 说明 |
|---------|------|------|
| 0.90-1.00 | 优秀 | 完全符合要求，达到最佳实践 |
| 0.80-0.89 | 良好 | 基本符合要求，有小幅改进空间 |
| 0.70-0.79 | 一般 | 部分符合要求，需要改进 |
| 0.60-0.69 | 较差 | 不符合要求，需要大幅改进 |
| 0.00-0.59 | 不可接受 | 完全不符合要求 |

### B. 问题严重程度

| 严重程度 | 处理优先级 | 示例 |
|---------|-----------|------|
| high | 必须修复 | 缺少专业视角内核、决策规则缺失 |
| medium | 建议修复 | 条件模糊、案例不足 |
| low | 可选修复 | 格式微调、标点符号 |

### C. 优化行动类型

| 类型 | 说明 | 示例 |
|------|------|------|
| add | 新增内容 | 新增核心概念、新增决策规则 |
| modify | 修改内容 | 修改分析框架步骤、调整规则条件 |
| refine | 细化内容 | 细化触发条件、补充应用场景 |
| remove | 删除内容 | 删除冗余规则、删除重复内容 |
| standardize | 规范化 | 统一术语、调整格式 |
