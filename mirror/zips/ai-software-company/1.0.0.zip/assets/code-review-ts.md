# 代码审查清单（TypeScript/JS 专项）

## TypeScript 类型
- [ ] 无 `any` 类型泛滥
- [ ] 接口和类型别名命名清晰
- [ ] `strictNullChecks` 开启时，null/undefined 有处理

## React/Vue 专项
- [ ] 组件 Props 有类型定义
- [ ] useEffect 依赖数组正确
- [ ] 列表渲染有 key（避免 index 作为 key）
- [ ] 无直接操作 DOM

## Node.js 后端专项
- [ ] async/await 替代 .then().catch()
- [ ] 错误处理中间件统一
- [ ] 路由有参数校验（zod/yup/class-validator）
- [ ] 环境变量有类型和默认值

## 安全专项
- [ ] SQL 使用 ORM 或参数化查询
- [ ] 敏感接口有频率限制
- [ ] CORS 配置正确（非 `*` 生产环境）
- [ ] JWT 签名密钥 >= 256 位

## Node.js 性能
- [ ] 连接池复用（数据库/Redis）
- [ ] 静态资源走 CDN/Nginx
- [ ] 压缩开启（Gzip/Brotli）
