# 代码审查清单（Python 专项）

## 类型与依赖
- [ ] 函数和方法的参数、返回值有 Type Hint
- [ ] 避免使用 `from module import *`
- [ ] 使用 requirements.txt / pyproject.toml / poetry.lock

## 安全性
- [ ] 不使用 `eval()` / `exec()` 处理外部输入
- [ ] 文件路径拼接用 `pathlib`
- [ ] YAML 解析只用 `safe_load`
- [ ] 使用加密库而非自己实现加密

## 异常处理
- [ ] 不裸抛 `raise Exception`，用具体异常类型
- [ ] 资源获取用 `with` 语句

## 性能
- [ ] 循环内避免重复查询数据库
- [ ] 大数据用生成器（yield）
- [ ] ORM 用 select_related/prefetch_related

## 测试 & 代码风格
- [ ] 核心逻辑有单元测试
- [ ] 符合 PEP 8（行长度 < 120）
- [ ] 使用 Black / Ruff 自动格式化
- [ ] 公开 API 有 docstring
