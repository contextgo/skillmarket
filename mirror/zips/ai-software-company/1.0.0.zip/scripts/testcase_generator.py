#!/usr/bin/env python3
"""
测试用例生成器
用法: python testcase_generator.py
输入功能描述，自动生成 7 种类型测试用例
"""

import sys
from pathlib import Path

TEST_TYPES = [
    ("功能测试", "验证功能是否符合需求文档"),
    ("边界测试", "测试边界值：空值、0、最大值、超长文本"),
    ("异常测试", "测试异常输入：错误格式、非法字符、无权限操作"),
    ("UI/交互测试", "验证页面布局、响应式、交互反馈"),
    ("性能测试", "响应时间、并发、压力下的系统表现"),
    ("安全测试", "XSS/SQL注入、越权、敏感信息泄露"),
    ("回归测试", "修改后原有功能是否正常"),
]


def generate_for_feature(feature: str) -> str:
    lines = [
        f"# 测试用例：{feature}",
        "",
        f"**生成时间：** 自动生成",
        "**测试类型：** 全类型覆盖",
        "",
        "## 用例汇总",
        "",
        "| ID | 测试类型 | 用例标题 | 优先级 | 前置条件 | 测试步骤 | 预期结果 |",
        "|--|--|--|--|--|--|--|",
    ]
    case_id = 1
    for test_type, desc in TEST_TYPES:
        lines.append(f"### {test_type}：{desc}")
        for scenario in _scenarios(feature, test_type):
            priority = _priority(test_type, scenario)
            lines.append(
                f"| TC-{case_id:03d} | {test_type} | {scenario['title']} "
                f"| {priority} | {scenario['pre']} | {scenario['steps']} "
                f"| {scenario['expect']} |"
            )
            case_id += 1
        lines.append("")
    return "\n".join(lines)


def _scenarios(feature: str, test_type: str) -> list:
    f = feature
    templates = {
        "功能测试": [
            {
                "title": f"正常流程：{f}功能可用",
                "pre": "用户已登录",
                "steps": f"1. 进入{f}页面\n2. 输入有效数据\n3. 点击提交",
                "expect": f"{f}成功，显示结果",
            },
            {
                "title": f"分支流程：{f}取消操作",
                "pre": "用户已登录",
                "steps": f"1. 进入{f}页面\n2. 输入数据\n3. 点击取消",
                "expect": "操作取消，无数据变更",
            },
        ],
        "边界测试": [
            {
                "title": "边界：空值输入",
                "pre": "无",
                "steps": f"1. 进入{f}页面\n2. 不输入任何数据\n3. 点击提交",
                "expect": "提示必填项不能为空",
            },
            {
                "title": "边界：超长文本输入",
                "pre": "无",
                "steps": f"1. 输入超长文本（>1000字符）\n2. 点击提交",
                "expect": "提示文本超长或截断处理",
            },
            {
                "title": "边界：特殊字符输入",
                "pre": "无",
                "steps": f"输入 {{{{}}}}[][]<>`~!@#$%^&*()_+-=;',./\"\\",
                "expect": "特殊字符被正确处理或过滤",
            },
            {
                "title": "边界：数字极值测试",
                "pre": "无",
                "steps": "输入0、最大整数999999999",
                "expect": "正确处理边界值",
            },
        ],
        "异常测试": [
            {
                "title": "异常：未登录访问",
                "pre": "用户未登录",
                "steps": f"直接访问{f}页面URL",
                "expect": "跳转登录页或提示未登录",
            },
            {
                "title": "异常：网络中断后提交",
                "pre": "数据已填写",
                "steps": "断开网络，点击提交",
                "expect": "提示网络异常，不丢失已填数据",
            },
            {
                "title": "异常：重复提交",
                "pre": "无",
                "steps": f"快速连续点击提交按钮2次",
                "expect": "防止重复提交，只处理一次",
            },
        ],
        "UI/交互测试": [
            {
                "title": "UI：页面布局正确显示",
                "pre": "无",
                "steps": "访问页面，检查元素对齐、字体、颜色",
                "expect": "布局与设计稿一致",
            },
            {
                "title": "UI：响应式适配",
                "pre": "无",
                "steps": "分别在PC/平板/手机访问",
                "expect": "各尺寸下正常显示",
            },
            {
                "title": "交互：加载状态反馈",
                "pre": "无",
                "steps": "触发需要等待的操作",
                "expect": "显示加载中状态，完成后消失",
            },
        ],
        "性能测试": [
            {
                "title": "性能：页面首次加载时间",
                "pre": "网络正常",
                "steps": "首次访问页面，记录加载时间",
                "expect": "首次加载 < 3秒",
            },
            {
                "title": "性能：大量数据渲染",
                "pre": "无",
                "steps": f"向{f}列表中导入1000条数据",
                "expect": "页面不卡顿，可滚动",
            },
        ],
        "安全测试": [
            {
                "title": "安全：XSS 注入",
                "pre": "无",
                "steps": "输入 <script>alert(1)</script>",
                "expect": "脚本不执行，被转义显示",
            },
            {
                "title": "安全：SQL 注入",
                "pre": "无",
                "steps": "输入 ' OR '1'='1",
                "expect": "不执行，显示查询错误",
            },
            {
                "title": "安全：越权访问",
                "pre": "用户A登录",
                "steps": "尝试直接通过URL访问用户B的数据",
                "expect": "无权限访问或返回空",
            },
        ],
        "回归测试": [
            {
                "title": "回归：修复后原有功能正常",
                "pre": "已修复Bug",
                "steps": "完整执行正常流程",
                "expect": "修复未引入新问题",
            },
        ],
    }
    return templates.get(test_type, [])


def _priority(test_type: str, scenario: dict) -> str:
    if test_type in ("功能测试", "安全测试"):
        return "P0"
    elif test_type in ("异常测试", "性能测试"):
        return "P1"
    return "P2"


def main():
    print("=== AI 软件一人公司 - 测试用例生成器 ===\n")
    feature = input("请输入功能名称（如：用户注册/订单支付）：").strip()
    if not feature:
        print("未输入功能，退出。")
        return
    count = int(input("每个测试类型生成几个用例场景？（直接回车=2）：").strip() or "2")
    output = generate_for_feature(feature)
    print(f"\n已生成测试用例：\n{output[:800]}...")
    save = input("\n保存到 testcases.md？(y/n): ").strip().lower()
    if save == "y":
        Path("testcases.md").write_text(output, encoding="utf-8")
        print("已保存: testcases.md")


if __name__ == "__main__":
    main()
