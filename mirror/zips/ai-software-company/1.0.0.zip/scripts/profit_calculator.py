#!/usr/bin/env python3
"""
项目利润计算器
用法: python profit_calculator.py
交互式输入，计算利润、毛利率、健康度
"""

import sys
from pathlib import Path

DAILY_COST = 1500  # 默认日均成本（元/天）
MGMT_FACTOR = 1.12  # 默认管理成本系数


def calc():
    print("=== AI 软件一人公司 - 利润计算器 ===\n")

    # 收入
    contract_amount = float(input("合同金额（元）："))
    received = float(input("已收款（元）："))
    invoice_tax = float(input("发票税率%（直接回车=6%）：").strip() or "6")
    invoice_rate = invoice_tax / 100

    # 成本
    print("\n--- 人力成本 ---")
    try:
        days = float(input("总工时（天）："))
        daily_cost = float(input(f"日均成本（直接回车={DAILY_COST}）：").strip() or str(DAILY_COST))
    except ValueError:
        days, daily_cost = 0, DAILY_COST
    labor_cost = days * daily_cost

    print("\n--- 其他成本 ---")
    outsourcing = float(input("外包/分包成本（元，直接回车=0）：").strip() or "0")
    third_party = float(input("第三方服务/授权成本（元，直接回车=0）：").strip() or "0")
    other = float(input("其他成本（元，直接回车=0）：").strip() or "0")

    # 计算
    total_cost = labor_cost + outsourcing + third_party + other
    mgmt_cost = total_cost * MGMT_FACTOR
    net_profit = contract_amount - mgmt_cost
    profit_rate = (net_profit / contract_amount * 100) if contract_amount else 0
    profit_per_day = net_profit / days if days else 0
    unreceived = contract_amount - received
    invoice_due = unreceived / (1 + invoice_rate)

    # 健康度评分
    if profit_rate >= 30:
        health = "🟢 优秀"
    elif profit_rate >= 15:
        health = "🟡 正常"
    elif profit_rate >= 0:
        health = "🟠 预警"
    else:
        health = "🔴 亏损"

    # 风险提示
    warnings = []
    if profit_rate < 15:
        warnings.append(f"⚠️ 毛利率 {profit_rate:.1f}% 低于 15%，盈利空间不足")
    if unreceived > contract_amount * 0.5:
        warnings.append(f"⚠️ 未收款比例过高：{unreceived/contract_amount*100:.0f}%")
    if days > 60:
        warnings.append(f"⚠️ 项目工时较长（{days}天），需关注进度风险")

    # 输出
    print("\n" + "=" * 40)
    print("              利润分析报告")
    print("=" * 40)
    print(f"  合同金额        ¥{contract_amount:>12,.2f}")
    print(f"  人力成本        ¥{labor_cost:>12,.2f}  ({days:.0f}天×¥{daily_cost:.0f})")
    print(f"  外包成本        ¥{ outsourcing:>12,.2f}")
    print(f"  第三方成本      ¥{third_party:>12,.2f}")
    print(f"  其他成本        ¥{   other:>12,.2f}")
    print(f"  ─────────────────────────────")
    print(f"  总成本          ¥{total_cost:>12,.2f}")
    print(f"  含管理成本      ¥{ mgmt_cost:>12,.2f}  (×{MGMT_FACTOR})")
    print(f"  毛利润          ¥{net_profit:>12,.2f}")
    print(f"  毛利率          {profit_rate:>13.1f}%")
    print(f"  日均利润        ¥{profit_per_day:>12,.2f}")
    print(f"  ─────────────────────────────")
    print(f"  已收款          ¥{  received:>12,.2f}")
    print(f"  未收款          ¥{unreceived:>12,.2f}")
    print(f"  预计待开票      ¥{invoice_due:>12,.2f}  (税率{invoice_tax}%)")
    print("=" * 40)
    print(f"  健康度: {health}\n")
    for w in warnings:
        print(f"  {w}")

    # 保存
    save = input("\n保存到 profit-report.md？(y/n): ").strip().lower()
    if save == "y":
        report = f"""# 项目利润分析报告

## 基本信息
- 合同金额：¥{contract_amount:,.2f}
- 已收款：¥{received:,.2f}
- 未收款：¥{unreceived:,.2f}

## 成本明细
- 人力成本：¥{labor_cost:,.2f}（{days:.0f}天 × ¥{daily_cost:.0f}/天）
- 外包成本：¥{outsourcing:,.2f}
- 第三方成本：¥{third_party:,.2f}
- 其他成本：¥{other:,.2f}
- **总成本（含管理）：¥{mgmt_cost:,.2f}**

## 利润分析
- 毛利润：¥{net_profit:,.2f}
- 毛利率：{profit_rate:.1f}%
- 日均利润：¥{profit_per_day:,.2f}

## 健康度：{health}

## 风险预警
{chr(10).join(warnings) if warnings else "无明显风险"}

---
生成时间：自动计算
"""
        Path("profit-report.md").write_text(report, encoding="utf-8")
        print("已保存: profit-report.md")


if __name__ == "__main__":
    calc()
