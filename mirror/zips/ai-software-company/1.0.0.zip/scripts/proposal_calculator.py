#!/usr/bin/env python3
"""
提案报价计算器
用法: python proposal_calculator.py
支持：工时报价、模板报价、市场参考价三种模式
"""

import sys
from pathlib import Path

PERSON_DAY = 1500  # 人天成本（元/天）


def calc_fee():
    print("=== AI 软件一人公司 - 提案报价计算器 ===\n")

    mode = input(
        "选择报价模式：\n"
        "  [1] 工时报价（最常用）\n"
        "  [2] 功能点数（IFPUG）\n"
        "  [3] 参考市场定价\n"
        "请输入（1/2/3，直接回车=1）："
    ).strip() or "1"

    if mode == "1":
        result = calc_by_days()
    elif mode == "2":
        result = calc_by_fp()
    else:
        result = calc_by_market()

    # 保存
    save = input("\n保存到 proposal-fee.md？(y/n): ").strip().lower()
    if save == "y":
        Path("proposal-fee.md").write_text(result, encoding="utf-8")
        print("已保存: proposal-fee.md")


def calc_by_days():
    print("\n--- 工时报价 ---")
    try:
        phases = []
        while True:
            name = input("阶段名称（直接回车结束）：").strip()
            if not name:
                break
            days = float(input(f"  {name} - 工时（天）："))
            price = float(input(f"  {name} - 人天单价（直接回车={PERSON_DAY}）：").strip() or str(PERSON_DAY))
            phases.append({"name": name, "days": days, "price": price})

        tax = float(input("\n税率%（直接回车=6）：").strip() or "6")
        profit = float(input("预期利润率%（直接回车=20）：").strip() or "20")
    except ValueError:
        return "输入有误，退出。"

    total_base = sum(p["days"] * p["price"] for p in phases)
    subtotal = total_base * (1 + profit / 100)
    tax_amount = subtotal * tax / 100
    total = subtotal + tax_amount

    lines = ["# 报价单（工时模式）\n", "| 阶段 | 工时(天) | 单价 | 小计 |", "|--|--|--|--|"]
    for p in phases:
        lines.append(f"| {p['name']} | {p['days']} | ¥{p['price']:,.0f} | ¥{p['days']*p['price']:,.0f} |")
    lines.append(f"| **合计** | | | **¥{total_base:,.0f}** |")
    lines.append(f"\n| 项目 | 数值 |")
    lines.append(f"|--|--|")
    lines.append(f"| 工作量 | {sum(p['days'] for p in phases):.1f} 天 |")
    lines.append(f"| 人工成本 | ¥{total_base:,.0f} |")
    lines.append(f"| 利润率 | {profit}% |")
    lines.append(f"| 小计（不含税） | ¥{subtotal:,.0f} |")
    lines.append(f"| 税额（{tax}%） | ¥{tax_amount:,.0f} |")
    lines.append(f"| **含税总价** | **¥{total:,.0f}** |")
    output = "\n".join(lines)
    print("\n" + output)
    return output


def calc_by_fp():
    print("\n--- 功能点报价（IFPUG） ---")
    try:
        ei = float(input("EI（外部输入）数量："))
        eo = float(input("EO（外部输出）数量："))
        eq = float(input("EQ（外部查询）数量："))
        ilf = float(input("ILF（内部逻辑文件）数量："))
        elf = float(input("ELF（外部接口文件）数量："))
        vp = float(input("每个功能点价值（元，直接回车=1000）：").strip() or "1000")
    except ValueError:
        return "输入有误，退出。"

    unadjusted_fp = ei * 4 + eo * 5 + eq * 4 + ilf * 10 + elf * 7
    adjusted_fp = unadjusted_fp * 1.3  # 技术复杂度因子
    total = adjusted_fp * vp

    lines = [
        "# 报价单（功能点模式）\n",
        "| 类型 | 数量 | 功能点系数 | 小计 |",
        "|--|--|--|--|",
        f"| EI（外部输入） | {ei} | ×4 | {ei*4:.0f} |",
        f"| EO（外部输出） | {eo} | ×5 | {eo*5:.0f} |",
        f"| EQ（外部查询） | {eq} | ×4 | {eq*4:.0f} |",
        f"| ILF（内部文件） | {ilf} | ×10 | {ilf*10:.0f} |",
        f"| ELF（外部接口） | {elf} | ×7 | {elf*7:.0f} |",
        f"| **未调整FP** | | | **{unadjusted_fp:.0f}** |",
        f"| 技术复杂度因子 | ×1.3 | | |",
        f"| **调整后FP** | | | **{adjusted_fp:.0f}** |",
        f"| 每功能点价值 | ¥{vp:,.0f} | | |",
        f"| **报价** | | | **¥{total:,.0f}** |",
    ]
    output = "\n".join(lines)
    print("\n" + output)
    return output


def calc_by_market():
    print("\n--- 市场参考定价 ---")
    items = [
        ("基础官网", 8000, "15000"),
        ("标准企业站", 20000, "50000"),
        ("管理后台", 30000, "80000"),
        ("小程序（展示类）", 15000, "40000"),
        ("小程序（功能类）", 30000, "100000"),
        ("App（单端）", 50000, "200000"),
        ("App（双端）", 100000, "400000"),
        ("CRM/ERP系统", 50000, "300000"),
        ("AI 智能体", 30000, "200000"),
    ]
    print("\n| 项目类型 | 低价 | 高价 |")
    print("|--|--|--|")
    for name, low, high in items:
        print(f"| {name} | ¥{low:,} | ¥{high:,} |")
    print("\n（以上为市场参考价，实际报价需结合需求复杂度）")
    return ""


if __name__ == "__main__":
    calc_fee()
