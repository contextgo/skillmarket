#!/usr/bin/env python3
"""
WBS 任务分解器
用法: python wbs_decomposer.py "功能1,功能2,功能3"
"""

import sys
import json
from pathlib import Path

DEFAULT_DAYS = {
    "需求分析": 2,
    "系统设计": 3,
    "前端开发": 5,
    "后端开发": 5,
    "数据库": 2,
    "接口开发": 3,
    "联调测试": 3,
    "部署上线": 1,
    "项目管理": 2,
    "项目沟通": 2,
}


def decompose(feature: str, base_days: dict = None) -> list:
    """将一个功能拆解为 WBS 任务"""
    if base_days is None:
        base_days = DEFAULT_DAYS
    phases = [
        {"name": "需求分析", "days": base_days["需求分析"]},
        {"name": "系统设计", "days": base_days["系统设计"]},
        {"name": "前端开发", "days": base_days["前端开发"]},
        {"name": "后端开发", "days": base_days["后端开发"]},
        {"name": "数据库", "days": base_days["数据库"]},
        {"name": "接口开发", "days": base_days["接口开发"]},
        {"name": "联调测试", "days": base_days["联调测试"]},
        {"name": "部署上线", "days": base_days["部署上线"]},
        {"name": "项目沟通", "days": base_days["项目沟通"]},
    ]
    return phases


def features_wbs(features: list, owner: str = "开发者") -> str:
    """生成完整的 WBS Markdown 表格"""
    total_days = 0
    task_id = 1
    lines = [
        "# WBS 任务分解表",
        "",
        f"**项目负责人：** {owner}",
        "",
        "| # | 任务名称 | 类型 | 工期(天) | 依赖 | 负责人 | 备注 |",
        "|--|---------|------|---------|------|--------|------|",
    ]
    for feat_idx, feat in enumerate(features, 1):
        lines.append(
            f"| **{feat_idx}. {feat}** | *— 阶段分解如下 —* | | | | | |"
        )
        phases = decompose(feat)
        for phase in phases:
            lines.append(
                f"| {task_id} | {phase['name']}（{feat}）"
                f" | {phase['name']} | {phase['days']} | "
                f"{task_id} | {owner} | |"
            )
            total_days += phase["days"]
            task_id += 1
    lines.append(f"| **合计** | | **{total_days} 工作日** | | | |")
    return "\n".join(lines)


def main():
    if len(sys.argv) < 2:
        features_input = input("请输入功能列表（逗号分隔）：").strip()
    else:
        features_input = sys.argv[1]
    features = [f.strip() for f in features_input.split(",") if f.strip()]
    if not features:
        print("未输入功能，退出。")
        return
    owner = input("负责人（直接回车默认'开发者'）：").strip() or "开发者"
    output = features_wbs(features, owner)
    print(output)
    save = input("\n保存到文件？(y/n，直接回车则不保存): ").strip().lower()
    if save == "y":
        fp = input("文件路径（直接回车默认 wbs.md）：").strip() or "wbs.md"
        Path(fp).write_text(output, encoding="utf-8")
        print(f"已保存: {fp}")


if __name__ == "__main__":
    main()
