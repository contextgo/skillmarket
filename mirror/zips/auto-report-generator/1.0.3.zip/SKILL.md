---
name: auto-report-generator
description: "Auto Report Generator — Upload CSV/Excel, AI analyzes data and generates professional reports (charts + narrative analysis). Supports monthly/weekly/financial/sales reports. Triggers: auto report, generate report, data report, monthly report, financial report, sales report, data analysis"
---

# Auto Report Generator Skill

## Features
Upload data (CSV/Excel) → AI analyzes → generates professional reports (charts + narrative + formatting) — one-click monthly/weekly reports.

## Core Files
- `SKILL.md` - This file
- `scripts/generator.py` - Main generator script (CLI entry point)
- `core/parser.py` - Data parsing (pandas)
- `core/charts.py` - Chart generation (matplotlib/xlsxwriter)
- `core/ai_analyzer.py` - AI analysis (OpenAI-compatible API)
- `core/report_builder.py` - Report building (multi-sheet Excel)
- `core/quota.py` - Quota management (Free: 5 uses absolute count)
- `core/templates.py` - Template system
- `core/token_validator.py` - API key verification
- `scripts/quick_report.sh` - Quick generation script

## Installation
```bash
pip install pandas openpyxl xlsxwriter matplotlib pillow -q
```

## Usage
Call via Skill system `scripts/generator.py` with arguments:
- `--file` Data file path
- `--template` Template type (monthly/financial/sales/comparison/custom)
- `--ai-provider` AI provider (openai/deepseek)
- `--ai-model` AI model
- `--tier` Subscription tier (FREE/STD/PRO/MAX)
- `--output` Output path

## Pricing
| Tier | Price | Uses | Features |
|------|-------|:----:|---------|
| FREE | ¥0 | 5 lifetime | 1 chart type |
| STD | ¥29/mo | 50/mo | 3 chart types |
| PRO | ¥99/mo | 200/mo | Unlimited charts, PDF export |
| MAX | ¥299/mo | Unlimited | Custom templates, API access |

## Token Prefix
`REPORT-FREE` / `REPORT-STD` / `REPORT-PRO` / `REPORT-MAX`

## Directory Structure
```
auto-report-generator/
├── SKILL.md
├── README.md
├── requirements.txt
├── CLAWHUB.md
├── SKILLHUB.md
├── scripts/
│   ├── generator.py     # CLI entry point
│   ├── quick_report.sh   # Quick generation script
│   └── __init__.py
└── core/
    ├── parser.py         # Data parsing
    ├── charts.py         # Chart generation
    ├── ai_analyzer.py   # AI analysis
    ├── report_builder.py # Excel report builder
    ├── quota.py         # Quota management
    ├── templates.py      # Template system
    └── token_validator.py # API key verification
```

## License
MIT

> For paid plans, visit [YK-Global.com](https://yk-global.com)
