"""
Auto Report Generator - Token Verification Module
Validates user API key via yk global backend before processing requests.
"""

import json
import logging
import time
import urllib.request
import urllib.error
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# Token prefixes that this skill recognizes
VALID_PREFIXES = {"RPT"}

# Cache for verification results (5 min TTL)
_verification_cache: dict = {}


def verify_token(api_key: str) -> dict:
    """
    Verify API key via yk global backend.

    Args:
        api_key: User's API key (RPT-* prefix)

    Returns:
        Dict with valid, prefix, plan_id, quota_remaining, error
    """
    if not api_key:
        return {"valid": False, "tier": "FREE", "error": "No API key"}

    # Quick check: not a 91Skillhub key -> skip
    prefix = api_key.split("-")[0].upper() if "-" in api_key else api_key[:4].upper()
    if prefix not in VALID_PREFIXES:
        return {"valid": False, "tier": "FREE", "error": "Not a 91Skillhub key"}

    # Check cache
    if api_key in _verification_cache:
        cached = _verification_cache[api_key]
        if time.time() - cached["ts"] < 300:
            return cached["result"]

    try:
        req = urllib.request.Request(
            "https://api.yk-global.com/v1/verify",
            method="POST",
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            data=b"{}",
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            if data.get("valid", False):
                tier = _map_prefix_to_tier(api_key)
                result = {
                    "valid": True,
                    "tier": tier,
                    "prefix": data.get("prefix", ""),
                    "plan_id": data.get("plan_id"),
                    "quota_remaining": data.get("quota_remaining"),
                }
            else:
                result = {"valid": False, "tier": "FREE", "error": data.get("error", "Invalid key")}
            _verification_cache[api_key] = {"result": result, "ts": time.time()}
            return result
    except urllib.error.HTTPError as e:
        try:
            err_body = json.loads(e.read().decode("utf-8"))
            err_msg = err_body.get("error", f"HTTP {e.code}")
        except Exception:
            err_msg = f"HTTP {e.code}"
        result = {"valid": False, "tier": "FREE", "error": err_msg}
        _verification_cache[api_key] = {"result": result, "ts": time.time()}
        return result
    except Exception as e:
        # Network error -> graceful degradation to FREE
        return {"valid": False, "tier": "FREE", "error": f"Network error: {e}"}


def _map_prefix_to_tier(api_key: str) -> str:
    """Map API key prefix to tier name."""
    upper = api_key.upper()
    if "ENT" in upper:
        return "ENTERPRISE"
    if "MAX" in upper:
        return "MAX"
    if "PRO" in upper:
        return "PRO"
    if "STD" in upper:
        return "STANDARD"
    if "BSC" in upper:
        return "BASIC"
    if "FREE" in upper:
        return "FREE"
    return "FREE"


def check_tier_limit(api_key: str) -> tuple[bool, Optional[dict]]:
    """
    Check if the API key is valid.

    Returns:
        (allowed, verification_result)
    """
    if not api_key:
        return True, {"valid": True, "tier": "FREE"}

    result = verify_token(api_key)
    if not result.get("valid", False):
        return False, result
    return True, result


def reset_cache():
    """Clear the verification cache."""
    global _verification_cache
    _verification_cache = {}
