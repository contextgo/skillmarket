# Auto Report Generator

Upload CSV/Excel → AI analyzes data → generates professional reports (charts + narrative analysis).

---

## Supported Formats

| Format | Extensions | Description |
|--------|------------|-------------|
| CSV | `.csv` | UTF-8 encoded comma-separated values |
| Excel | `.xlsx` / `.xls` | Microsoft Excel files |

---

## Key Features

- **Multiple Chart Types**: Line, bar, pie, scatter, area, heatmap
- **Report Templates**: Monthly, financial, sales, comparison, custom
- **AI Data Insights**: Auto-interpret data patterns, generate narrative analysis
- **Excel Export**: Multi-sheet with formatting, embedded charts

---

## Quick Start

```python
from scripts.generator import main

# CLI usage
# python scripts/generator.py \
#     --input data.csv \
#     --template monthly \
#     --output report.xlsx \
#     --api-key YOUR_API_KEY \
#     --api-base https://api.openai.com/v1
```

---

## Pricing

| Tier | Price | Features |
|------|-------|----------|
| Free | ¥0 | 5 uses (lifetime), basic charts |
| Standard | ¥29/mo | 50 uses/mo, multiple chart types |
| Pro | ¥99/mo | 200 uses/mo, unlimited charts, PDF export |
| Max | ¥299/mo | Unlimited, custom templates, API access |

---

> For paid plans, visit [YK-Global.com](https://yk-global.com)
