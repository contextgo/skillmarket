#!/usr/bin/env python3
"""
小红书违禁词检测脚本
用法：python3 check.py "你的文案内容"
"""
import sys
import re

def load_words_from_md(filepath):
    """从违禁词库.md解析出所有违禁词"""
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    # 提取表格行
    table_rows = re.findall(r'\| ([^\|]+) \| ([^\|]+) \| ([^\|]+) \| ([^\|]+) \| ([^\|]+) \|', content)

    words = []
    for row in table_rows:
        word = row[0].strip()
        example = row[1].strip()
        risk_level = row[2].strip()
        industry = row[3].strip()
        suggestion = row[4].strip()
        if word and word != '违禁词':
            words.append({
                'word': word,
                'example': example,
                'risk_level': risk_level,
                'industry': industry,
                'suggestion': suggestion
            })
    return words

def check_text(text, words):
    """检测文案中的违禁词"""
    text_lower = text.lower()
    violations = {
        '🔴绝对违禁': [],
        '🟡敏感': [],
        '🟠行业限制': [],
        '⚫规避': []
    }

    # 按风险等级分组
    risk_to_severity = {
        '极高': '🔴绝对违禁',
        '高': ['🟠行业限制', '⚫规避'],
        '中高': '🟡敏感',
        '中': '🟠行业限制',
    }

    for item in words:
        w = item['word']
        # 模糊匹配（包含关系）
        risk = item['risk_level']

        # 绝对违禁词：精确或包含匹配
        if risk in ['极高']:
            if w in text or (len(w) > 1 and w in text_lower):
                violations['🔴绝对违禁'].append(item)
                continue

        # 规避词：检查原文中的替代形式
        if '规避' in risk or '⚫' in item.get('example', ''):
            # 检查是否有规避形式
            if '→' in w:
                parts = w.split('→')
                if len(parts) == 2:
                    orig = parts[0].strip()
                    replaced = parts[1].strip().rstrip(')')
                    if replaced and replaced in text_lower:
                        violations['⚫规避'].append(item)
                        continue
                    # 拼音形式检测
                    if '拼音' in item['example']:
                        pinyin = parts[1].strip().rstrip(')').replace(' ', '')
                        if pinyin.lower() in text_lower or pinyin in text:
                            violations['⚫规避'].append(item)
                            continue

        # 敏感词：中高风险
        if risk == '中高':
            if w in text or (len(w) > 1 and w in text_lower):
                violations['🟡敏感'].append(item)
                continue

        # 行业限制词
        if risk in ['高', '中'] and '规避' not in item['example']:
            if w in text or (len(w) > 1 and w in text_lower):
                violations['🟠行业限制'].append(item)
                continue

    return violations

def print_report(text, violations):
    total = sum(len(v) for v in violations.values())

    print(f"\n{'='*50}")
    print(f"  🔍 小红书违禁词检测报告")
    print(f"{'='*50}\n")

    if total == 0:
        print("✅ 通过：未检测到违禁词\n")
        return

    print(f"⚠️  发现 {total} 处违禁词\n")

    # 按严重程度顺序输出
    severity_order = ['🔴绝对违禁', '🟡敏感', '🟠行业限制', '⚫规避']
    emoji_map = {'🔴绝对违禁': '🔴', '🟡敏感': '🟡', '🟠行业限制': '🟠', '⚫规避': '⚫'}

    for sev in severity_order:
        items = violations[sev]
        if not items:
            continue
        print(f"### {emoji_map[sev]}{sev}（{len(items)} 条）\n")
        print(f"| # | 违禁词 | 风险等级 | 安全替换 |")
        print(f"|---|--------|----------|----------|")
        for i, item in enumerate(items, 1):
            print(f"| {i} | {item['word']} | {item['risk_level']} | {item['suggestion']} |")
        print()

    # 风险总览
    overall = '🔴极高' if violations['🔴绝对违禁'] else \
              '🟡高' if violations['🟡敏感'] else \
              '🟠中' if violations['🟠行业限制'] else \
              '🟢低'
    print(f"### 📊 风险总览\n")
    print(f"| 违禁总数 | 🔴绝对违禁 | 🟡敏感 | 🟠行业限制 | ⚫规避 | 综合等级 |")
    print(f"|----------|------------|--------|------------|--------|----------|")
    print(f"| {total} | {len(violations['🔴绝对违禁'])} | {len(violations['🟡敏感'])} | {len(violations['🟠行业限制'])} | {len(violations['⚫规避'])} | {overall} |")
    print()

    # 替换建议
    print(f"### 💡 安全替换建议\n")
    print(f"**原文**：{text}\n")
    modified = text
    for sev in severity_order:
        for item in violations[sev]:
            if item['suggestion'] and item['word'] in modified:
                modified = modified.replace(item['word'], f"【{item['suggestion']}】")
    print(f"**修改后**：{modified}\n")

if __name__ == '__main__':
    # 查找词库路径
    import os
    base = os.path.dirname(os.path.abspath(__file__))
    ref_path = os.path.join(base, '..', 'references', '违禁词库.md')
    if not os.path.exists(ref_path):
        ref_path = '/Users/yejiayi/.workbuddy/skills/xhs-violation-checker/references/违禁词库.md'

    if len(sys.argv) < 2:
        print("用法：python3 check.py \"你的文案内容\"")
        sys.exit(1)

    text = sys.argv[1]
    words = load_words_from_md(ref_path)
    violations = check_text(text, words)
    print_report(text, violations)
