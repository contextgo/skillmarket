---
name: page-implement
description: >-
  根据 design-spec 输出的模块化设计 Prompt，生成基于 One Design Next 组件库的
  页面代码。用已有区块 + 设计系统拼装完整页面。
  当 design-spec 完成后自动接力；也可由用户直接贴设计稿/Prompt 触发。
args:
  - name: input
    description: design-spec 输出的模块化设计 Prompt，或直接的设计说明
    required: true
  - name: mode
    description: full / readonly（透传给下游 audit）
    required: false
next_skill: audit
next_skill_input: 生成的代码文件路径
requires_knowledge:
  - one-design
  - business-knowledge
  - block-catalog
user-invocable: true
---

# Page Implement — 页面级代码生成

> **职责定位**：把模块化设计 Prompt 转成基于 ODN 组件库的可运行代码。
> 上游：`design-spec`（输出模块化设计 Prompt）。
> 下游：`audit`（审查生成的代码）。

---

## 核心原则

1. **组件优先**：所有 UI 元素优先使用 ODN 组件库（`one-design-next`），禁止退化为 Tailwind 默认样式或手写 div。
2. **如翼页面用 `RuyiLayout`**：如果是如翼平台页面，必须以 `RuyiLayout` 为页面壳。
3. **设计系统 Token 约束**：颜色、间距、圆角、阴影必须使用 ODN Token，禁止硬编码值。
4. **延展设计**：库中没有的 UI 元素按 `../p2-one-design/rules/design-paradigm.md` 的设计范式手写。
5. **交互状态完整**：hover、active、selected、disabled 必须完整覆盖。
6. **视觉底线**：实色填充，禁止渐变（`gradient`）、毛玻璃（`backdrop-blur`）、霓虹效果。禁止 Tailwind 默认色板和硬编码色值。如果生成的 UI 看起来像 SaaS 官网（渐变 Hero、全屏大图、紫蓝配色），回退到白底 + 实色 + 文字层级的 ODN 风格。

---

## 知识依赖

执行前加载：

1. `../p2-one-design/GUIDE.md` — 组件速查表
2. `../p2-one-design/rules/` 对应类别规则文件
3. `../p2-block-catalog/GUIDE.md` — 已有区块目录，查找可复用区块
4. `../p2-business-knowledge/GUIDE.md` — 业务术语与模块知识（如涉及如翼业务场景）

---

## 执行流程

### Step 1 — 解析输入

- 解析 design-spec 输出的模块化 Prompt，提取每个模块的：
  - 模块名称与职责
  - 涉及的 ODN 组件
  - 交互状态清单
  - 业务数据结构

### Step 2 — 区块复用优先

- 对每个模块，检查 `../p2-block-catalog/` 是否有已注册的可复用区块
- 若有 → 直接复用区块
- 若无 → 用 ODN 组件从头搭建

### Step 3 — 组件组装

- 用 ODN 组件 + Tailwind 样式（透过 `app.css` 的 `@theme` 映射到 ODN Token）组装页面
- Token 使用规范：颜色用 `text-black-*` / `bg-brand-*` 等；间距用 Tailwind 工具类；圆角/阴影用 `rounded-*` / `shadow-*`

### Step 4 — 交互状态覆盖

- 对每个交互元素，显式实现 hover / active / selected / disabled 状态
- 状态样式通过 ODN Token 衍生（不要硬编码颜色）

### Step 5 — 输出与注册

页面文件写入 **`src/workshop/<slug>.tsx`**（不是 `src/pages/`——`src/pages/` 是路由基础设施）。

**5a. 写页面文件**：

```
src/workshop/<slug>.tsx
```

页面必须**完全自包含**——内置 RuyiLayout + 菜单配置 + 业务内容 + mock 数据，不依赖外部状态。与模板中已有的 workshop 页面风格一致。

**5b. 注册到 `workshopModules.ts`**：

在 `src/workshop/workshopModules.ts` 中添加两处：

```ts
// 1. WORKSHOP_SLUG_TO_IMPORT 中添加懒加载映射：
"<slug>": () => import("./<slug>"),

// 2. WORKSHOP_INDEX 中添加索引条目：
{ slug: "<slug>", title: "页面中文名" },
```

注册后即可通过 `/<slug>` 路由访问。

**5c. 模式差异**：

- **readonly 模式**：只输出代码文件到用户工作目录（仍写 `src/workshop/<slug>.tsx` + 注册 `workshopModules.ts`），不修改项目内知识文件
- **full 模式**：完整功能，所有步骤正常执行

> **注意**：如果项目是手动创建的最小项目（不含 `workshopModules.ts`），则直接写入 `src/workshop/<slug>.tsx` 并在 `src/App.tsx` 中添加路由即可。

### Step 6 — 交接给 audit

- 输出完成状态与文件清单
- frontmatter `next_skill: audit` 自动接力到下游审查

---

## mode 参数

- **readonly**（外部平台默认）：仅输出代码到用户工作目录，不修改 ODN 组件库、区块目录、业务知识文件。
- **full**（本项目内部默认）：完整功能，所有步骤正常执行。

---

## 完成状态协议

同对外 `../SKILL.md` 的「完成状态协议」章节。
