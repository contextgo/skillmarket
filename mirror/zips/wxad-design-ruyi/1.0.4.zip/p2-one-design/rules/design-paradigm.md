# ODN 设计范式

从 One Design Next 的 45+ 组件和 26+ 区块中提炼的设计思想与可复用范式。用于指导新 UI 的设计决策，确保每个新元素都像组件库的原生成员。

本文件分三层递进：**设计哲学**（为什么这样做）→ **设计范式**（怎么做）→ **延展规范**（组件和区块都没有时怎么手写）。

---

## 第一层：设计哲学

从组件库和区块体系中提炼出的 4 条核心设计信念。它们不是具体规则，而是所有规则背后的「为什么」。

### 朴素专业主义

ODN 的视觉语言是**白底、实色、方正、无装饰**。这不是"简陋"，而是数据密集型 B 端产品的视觉克制——把注意力留给数据本身，而不是界面装饰。

表现在：

- 白色容器 + 蓝灰页面底色（`#f2f5fa`），形成清晰的前景/背景分离
- 6px 圆角（控件面）和 12px 圆角（内容面板），方正而不生硬
- 实色填充，不用渐变、毛玻璃、霓虹等"AI 审美"效果
- 4 级投影体系（`shadow-1` ~ `shadow-4`），用层次感取代装饰性阴影

**终极检验**：如果生成的 UI 看起来像 AI 产品的官网（Vercel / Linear / OpenAI 风），那就偏离了 ODN 的设计语言。

### 动效即反馈

> 每一次交互都要有动效反馈。

组件库追求两种核心动效语言：

- **「跳跃」**（clip-path 过渡）：状态切换时的形变动效
- **「发芽」**（Floating UI 浮层）：从触发点自然生长出的浮层

具体体现：

- 每个可交互元素**必须有 hover 态**，过渡 `transition-colors duration-150`
- 可点击卡片的投影升级（`shadow-1` → `shadow-2`），过渡 `transition-shadow duration-200`
- 按钮色阶加深一级（`brand-6` → `brand-7`）
- 浮层从触发点「发芽」而非凭空出现
- **仅在 loading 态使用动画**（`animate-pulse` / `animate-spin`），纯装饰动效零容忍

### 信息密度优先

如翼是数据密集型产品。用户不是来"浏览"的，而是来"分析"的。设计的首要任务是建立清晰的信息层级，引导视觉扫描路径。

4 级信息层级：

```
第 1 层：核心指标数值（拉新/促活/回流）     → 最先看到（大字号 + font-semibold）
第 2 层：区块标题 / 操作按钮               → 然后注意（中字号 + font-semibold）
第 3 层：表格数据 / 图表                   → 按需阅读（正文字号）
第 4 层：辅助说明 / 时间戳 / 标签          → 需要时才看（小字号 + 弱化色）
```

对应的认知负荷检查：

- **单一焦点**：用户能否在不被干扰的情况下完成主要操作？
- **信息分组**：相关信息是否通过间距/背景/分隔线视觉分组？每组 ≤4 项？
- **层级清晰**：眯眼看（模糊视线），能否立刻分辨出最重要的元素？
- **渐进披露**：复杂度是否仅在需要时才暴露？（折叠、展开、hover 显示次要信息）

### Token 驱动一致性

`--odn-*` CSS 变量是设计系统的**单一事实来源**。所有色彩、字号、间距、圆角、投影都通过 Token 消费，禁止硬编码。

这确保了：

- 组件库组件和手写 UI 使用同一套视觉语言——无法从外观上分辨哪个是库内原生、哪个是延展手写
- 主题切换时全局一致（改一个 Token，全局生效）
- AI 生成代码时有明确的约束边界（只能用 ODN 色名，不能用 Tailwind 默认色板）

---

## 第二层：设计范式

从现有组件和区块中归纳的 6 类可复用设计模式。遇到新设计需求时，先从这些范式中找到最接近的模式，再按需调整。

### 布局范式

#### 双层导航壳

如翼采用**顶部一级导航 + 左侧二级菜单**的双层导航结构，统一通过 `RuyiLayout` 实现。

```
┌─────────────────────────────────────────────────────────────────┐
│ [如翼Logo]  首页 | 洞察诊断 | 人群策略 | ...  [工具] [品牌名 ID]  │  ← 顶栏 h-16
├────────┬────────────────────────────────────────────────────────┤
│ 二级菜单│  内容区 bg-[#f2f5fa]                                    │
│ w-[168] │  ┌─────────────────────────────────────────────────┐  │
│         │  │ 白色区块 (bg-white rounded-xl p-5)              │  │
│ 分组标题▼│  └─────────────────────────────────────────────────┘  │
│  菜单项  │  gap-4                                                │
│  菜单项  │  ┌─────────────────────────────────────────────────┐  │
│         │  │ 白色区块                                        │  │
│ 分组标题▼│  └─────────────────────────────────────────────────┘  │
│  菜单项  │                                                      │
└────────┴────────────────────────────────────────────────────────┘
```

#### 内容区两种模式

| 模式         | 布局                                                | 适用场景       | 典型区块                       |
| ------------ | --------------------------------------------------- | -------------- | ------------------------------ |
| 纵向 Card 栈 | `flex flex-col gap-4`                               | 仪表盘、概览页 | r0-audience-market、asset-flow |
| 主从分栏     | `flex gap-5`，左侧 `w-[320px]` 固定 + 右侧 `flex-1` | 列表-详情页    | conversion-review              |

#### 容器选择

| 场景                  | 选择                          | 判断依据                 |
| --------------------- | ----------------------------- | ------------------------ |
| 指标卡有明确边框      | `Card`                        | 视觉上每个指标有独立边界 |
| 白色内容区域          | `div.bg-white.rounded-xl`     | 只是与灰色背景形成对比   |
| 需要 hover 交互的卡片 | `Card` + hover 样式           | 有交互反馈的独立卡片     |
| 表格/图表的容器       | `div.bg-white.rounded-xl.p-5` | 纯容器功能               |
| 嵌套分区              | 间距 + 分隔线                 | **禁止** Card 嵌套 Card  |

### 数据展示范式

从 MetricCardGroup、MetricsOverview、RankingList、BulletChartPanel 等区块中提炼：

#### 指标卡模式

大数字 + 趋势箭头 + 对比文字。核心结构：

```
┌────────────────────┐
│ 标签文字（text-black-9）      │
│ 128,456 次                   │  ← headline-3 + font-semibold + tabular-nums
│ ↑ +12.5% 较昨日              │  ← 绿涨红跌 + comment 字号
└────────────────────┘
```

#### 排名模式

当前项高亮 + 有序列表。关键样式：

- 当前项：`bg-blue-1 text-blue-6`（与菜单激活态同一语言）
- 其余项：`hover:bg-solid-black-2 transition-colors`
- 序号/名称左对齐，数值右对齐
- 行间分隔：`border-b border-black-4 last:border-b-0`

#### 分布模式

彩色条段表达占比。来自 BulletChartPanel 和 MetricsOverview：

- 条段容器 `h-2 rounded-full overflow-hidden`
- 每段用 ODN 语义色（`bg-brand-6`、`bg-blue-3`、`bg-orange-5` 等）
- 配合色点图例 `flex items-center gap-1` + 色点 `w-2 h-2 rounded-full`

#### 趋势模式

双线趋势图。来自 MetricsOverview：

- 蓝实线 = 主指标，橙虚线 = 对比指标
- Y 轴刻度 `text-black-9` + X 轴日期 `text-black-9`
- 悬停时：十字线 + 数据点放大 + Tooltip 显示具体日期值
- 颜色使用 `var(--odn-color-*)` Token，不用图表库默认色板

#### 涨跌语义

全局统一的涨跌表达：

- 上涨：`text-green-6` + `<Icon name="up" />` + 正号前缀
- 下跌：`text-red-6` + `<Icon name="down" />` + 负号前缀
- 持平：`text-black-9`

### 页面结构范式

#### PageHeader 模式

从 page-header 区块提炼的 10 种页面头部模式，核心结构：

```
┌─────────────────────────────────────────────────────────────┐
│ 标题（左对齐）                                    操作按钮（右对齐）│  ← 标题栏
├─────────────────────────────────────────────────────────────┤
│ 筛选项 A ▼   筛选项 B ▼   日期范围 📅              更多筛选  │  ← 筛选栏
└─────────────────────────────────────────────────────────────┘
```

关键规则：

- 标题左、操作右——**不要**反过来
- 标题栏与筛选栏分为两行，中间用分割线 `border-b border-black-4`
- 筛选项横向排列 `gap-3`，超过 4 个用「更多筛选」收纳
- 操作按钮用 `Button(light)` 保持轻盈

#### 筛选工具栏模式

`Select` + `DatePicker` + `Button(light)` 横向排列：

```tsx
<div className="flex items-center gap-3">
  <Select size="small" options={...} />
  <DatePicker size="small" />
  <Button light icon="search">查询</Button>
</div>
```

#### Tab 内容切换

复杂信息用 `Tabs.Default` + `ScrollArea` 管理：

```tsx
<Tabs.Default items={tabItems} value={activeTab} onChange={setActiveTab} />
<ScrollArea className="flex-1 min-h-0">
  {activeTab === 'overview' ? <Overview /> : <Detail />}
</ScrollArea>
```

5 种 Tab 变体的选择：
| 变体 | 适用场景 |
|------|---------|
| `Tabs.Default` | 页面内容区的主要分面切换 |
| `Tabs.ButtonGroup` | 紧凑的视图模式切换（如列表/卡片视图） |
| `Tabs.Vertical` | 侧边面板内的分类 |
| `Tabs.Divider` | 带分隔线的区块内切换 |
| `Tabs.Tag` | 多选标签筛选 |

#### 状态处理统一

| 状态    | 组件/样式                                                             | 说明                               |
| ------- | --------------------------------------------------------------------- | ---------------------------------- |
| loading | `Loading` 组件或骨架屏 `bg-solid-black-3 animate-pulse rounded-[6px]` | 首次加载用骨架屏，操作中用 Loading |
| empty   | `Empty` 组件 + 主操作按钮                                             | 居中展示，引导下一步操作           |
| error   | 红色语义（`border-red-2 bg-red-1 text-red-6`）+ 具体错误说明          | 不只是"出错了"，要说明原因         |
| success | `text-green-6` + `<Icon name="check" />` + 确认文案                   | 确认结果 + 说明后续影响            |

### 交互反馈范式

#### 层级化 hover

不同语境下的 hover 有不同的反馈强度：

| 语境            | hover 样式                            | 过渡                             |
| --------------- | ------------------------------------- | -------------------------------- |
| 列表项 / 表格行 | `hover:bg-solid-black-2`              | `transition-colors duration-150` |
| 品牌强调区域    | `hover:bg-brand-1`                    | `transition-colors duration-150` |
| 可点击卡片      | `hover:shadow-[var(--odn-shadow-2)]`  | `transition-shadow duration-200` |
| 按钮色彩        | 色阶加深一级（`brand-6` → `brand-7`） | `transition-colors duration-150` |
| 图标按钮        | 图标色 `black-9` → `black-11`         | `transition-colors duration-150` |

#### 选中态

全局统一的蓝色系选中语言：

- 菜单激活：`text-blue-6 bg-blue-2 font-semibold`
- 列表当前项：`bg-blue-1 text-blue-6`
- Tab 激活：`text-brand-6` + 下划线/背景（取决于 Tab 变体）
- 筛选标签选中：`bg-brand-1 text-brand-6 border-brand-3`

#### 按钮层级

保持界面轻盈，如翼大量使用 `light` 变体：

| 重量 | 变体              | 用法                             |
| ---- | ----------------- | -------------------------------- |
| 最重 | `type="primary"`  | 页面主操作（每页通常只有 1 个）  |
| 次重 | 默认 Button       | 次要操作                         |
| 较轻 | `light`           | 工具按钮、行内操作（如翼最常用） |
| 最轻 | `ghost`           | 辅助操作、取消                   |
| 危险 | `intent="danger"` | 删除等破坏性操作                 |

### 色彩语义范式

#### 背景层次

4 级背景层次形成空间纵深：

```
页面底色 bg-[#f2f5fa]（蓝灰）
  └─ 内容容器 bg-white（白色面板）
       └─ 嵌套分区 bg-solid-black-2（浅灰）
            └─ 深层嵌套 bg-solid-black-3（更深灰）
```

#### 文字 4 级

| 级别     | 类名                 | 用途                   |
| -------- | -------------------- | ---------------------- |
| 主文字   | `text-black-12`      | 标题、正文、数据值     |
| 次要文字 | `text-black-11`      | 次要标题               |
| 辅助文字 | `text-black-9`       | 标签、占位符、说明文字 |
| 禁用文字 | `text-solid-black-8` | 禁用态文字             |

#### 状态语义

4 种语义场景的固定配色（学自 Alert 组件）：

| 语义    | 色系   | 背景          | 边框              | 文字/图标       | 用途                     |
| ------- | ------ | ------------- | ----------------- | --------------- | ------------------------ |
| info    | blue   | `bg-blue-1`   | `border-blue-2`   | `text-blue-6`   | 信息提示、激活态、选中态 |
| success | green  | `bg-green-1`  | `border-green-2`  | `text-green-6`  | 成功反馈、正增长         |
| warning | orange | `bg-orange-1` | `border-orange-2` | `text-orange-6` | 警告提示                 |
| danger  | red    | `bg-red-1`    | `border-red-2`    | `text-red-6`    | 错误反馈、负增长、删除   |

### 图表与可视化范式

#### 颜色约束

图表颜色**必须使用 ODN Token**（`var(--odn-color-*)`），不引入外部图表库的默认色板。常用图表色：

- 主指标线：`brand-6`（蓝色）
- 对比指标线：`orange-5`（橙色虚线）
- 分布条段：按语义分配（`brand-6` / `blue-3` / `green-5` / `orange-5`）

#### 内联 SVG 模式

轻量图表优先用内联 SVG（从 quadrant-scatter、metrics-overview 提炼）：

- 坐标轴文字 `fill: var(--odn-color-black-9)`
- 网格线 `stroke: var(--odn-color-black-4)`
- 数据点 hover 放大 + 其他点淡化（`opacity: 0.3`）
- 象限/矩阵标注用语义名称 + 半透明底色

#### 如翼特有可视化

| 类型       | 说明                          | 对应区块                     |
| ---------- | ----------------------------- | ---------------------------- |
| 资产流转图 | 拉新/促活/回流/稳固四象限指标 | metric-card-group            |
| 涟漪图     | 人群规模与增长的气泡可视化    | ripple-chart                 |
| 桑基图     | 人群资产流转关系              | sankey-chart                 |
| 矩形树图   | 品类/人群占比分布             | treemap-panel                |
| 四象限散点 | 双维度交叉分析                | quadrant-scatter             |
| 心智矩阵   | 品牌心智增长与竞争格局        | quadrant-scatter（心智变体） |

---

## 第三层：延展设计规范

当组件速查表和区块目录中都没有对应方案时，按以下规范手写新 UI。

**核心原则：新 UI 必须看起来像组件库的原生成员。** 不是"用 Tailwind 凑一个能用的"，而是从现有组件的设计 DNA 中延展出新的成员。

**终极检验：把新写的 UI 和旁边的库内组件截图放在一起，如果能一眼看出"这个是手写的"，就没过关。**

### AI 审美陷阱 — 绝对禁止

AI 模型的训练数据中充斥着特定的设计风格偏好，这些风格与 ODN 的产品设计语言**完全不兼容**。以下是最常见的 AI 审美陷阱，在 ODN 项目中**零容忍**。

#### 禁止的配色倾向

| 禁止                                          | 说明                                     | AI 为什么会用                                |
| --------------------------------------------- | ---------------------------------------- | -------------------------------------------- |
| 紫色系（`purple-*`、`violet-*`、`fuchsia-*`） | ODN 色板中没有紫色，它不是产品的视觉语言 | 紫色是 AI 生成设计中最高频的"科技感"用色     |
| 紫蓝渐变（`from-purple-* to-blue-*`）         | ODN 不使用渐变背景                       | AI 训练数据中 SaaS / AI 产品落地页的典型背景 |
| 靛蓝色系（`indigo-*`）                        | 非 ODN 色板成员                          | AI 常用作"比蓝色更有个性"的替代              |
| 玫红色系（`pink-*`、`rose-*`）                | 非 ODN 色板成员                          | AI 常用于强调或装饰                          |
| 青色系（`teal-*`、`cyan-*`）                  | 非 ODN 色板成员                          | AI 常用于"数据可视化"场景                    |

#### 禁止的视觉风格

| 禁止              | 说明                                                         | AI 为什么会用                              |
| ----------------- | ------------------------------------------------------------ | ------------------------------------------ |
| 渐变背景          | `bg-gradient-to-*`、`from-* via-* to-*`                      | AI 默认的"现代感"表达                      |
| 毛玻璃效果        | `backdrop-blur-*`、`bg-white/80` 半透明                      | AI 偏爱的"高级感"，但 ODN 是实色体系       |
| 深色模式 / 暗黑风 | 大面积深色背景 + 亮色文字                                    | AI 常无提示默认生成深色方案                |
| 霓虹光效          | `text-*-400` 亮色文字 + 深色背景 + glow                      | AI 的"科技感"表达                          |
| 过度圆润          | 大量 `rounded-2xl` / `rounded-3xl`                           | AI 的"友好感"表达，与 ODN 6px 方正风格冲突 |
| 装饰性动画        | 纯装饰的 `animate-bounce` / `animate-pulse` / `animate-spin` | AI 的"生动感"表达，ODN 仅在加载态使用动画  |

**识别方式**：如果生成的 UI 看起来像 AI 产品的官网（Vercel / Linear / OpenAI 风），那大概率触犯了以上规则。

### 延展设计流程

#### Step 1: 找到设计锚点

在动手之前，先确认没有现成方案，再找到最接近的组件作为设计基因的来源。

1. 查阅 GUIDE.md 组件速查表，确认库中没有对应组件
2. 查阅 block-catalog，确认没有可复用/参考的区块
3. 从库中找到最接近的组件作为**设计锚点** — 新 UI 的核心视觉基因从这里继承

常见锚点映射：

| 要做的新 UI          | 设计锚点  | 继承什么                              |
| -------------------- | --------- | ------------------------------------- |
| 状态标签 / Tag       | Alert     | 语义色模式（背景 `-1`、文字 `-6`）    |
| 步骤条 / Stepper     | Tabs      | 激活态配色（`brand-6` 文字 + 下划线） |
| 指标卡 / MetricCard  | Card      | 容器结构（圆角、投影、内边距）        |
| 进度条 / ProgressBar | Slider    | 轨道 + 填充的双层结构                 |
| 描述列表             | Form.Item | 标签 + 值的水平布局比例               |
| 筛选标签组           | Tabs.Tag  | 多选激活态的配色模式                  |
| 面包屑               | Link      | 文字色 + hover 色的层级               |

如果找不到明确的锚点，默认使用 Card（容器类）或 Button（交互类）的设计基因。

#### Step 2: 按顺序编码

按以下固定顺序构建新 UI，**不要跳步**。每完成一步，确认当前效果正确后再进入下一步。

| 顺序 | 阶段     | 做什么                                             | 对应维度   |
| ---- | -------- | -------------------------------------------------- | ---------- |
| 1    | 结构     | 语义化 HTML 骨架 + `data-odn-*` 标识，不加任何样式 | 代码结构   |
| 2    | 布局间距 | flex/grid 布局 + `gap-*` 间距 + 内边距             | 间距       |
| 3    | 排版色彩 | 字号 `--odn-font-size-*` + 字重 + ODN 色名         | 排版、色彩 |
| 4    | 圆角投影 | `rounded-[6px]` + `shadow-[var(--odn-shadow-N)]`   | 圆角、投影 |
| 5    | 交互状态 | hover / focus / active / disabled 态 + 过渡动画    | 交互反馈   |
| 6    | 边缘状态 | loading / error / empty / success 态               | 交互反馈   |
| 7    | 数据验证 | 用真实数据范围测试：空数据、极长文本、极大数字     | —          |

每个维度的硬规则见下方「7 个维度：内联硬规则」章节。

#### Step 3: 过反模式检查

写完代码后，逐条检查本文件「反模式清单」章节，确认没有触发任何一条。

#### Step 4: 认知负荷检查

新 UI 不仅要"看起来对"，还要"用起来对"。参照第一层「信息密度优先」的 4 条检查逐条过。如果任意一条不满足，在交付前修复。

#### Step 5: 终极验证

- 新 UI 与相邻的库内组件放在一起，视觉上无违和感
- 所有交互状态（hover / active / disabled / focus / loading / error / empty）已覆盖
- 无 Tailwind 默认色板、无硬编码色值、无通用投影
- 用真实数据（或拟真数据）测试过，不只是 placeholder

### 7 个维度：内联硬规则

每个维度的结构：先列出**必须遵守**的规则（不用查文档，直接执行），再指向深层参考获取完整规范。

#### 色彩

-> 查阅 [design-tokens.md](./design-tokens.md) 获取完整色板

必须遵守：

- 只用 ODN 色名：`brand-*`、`black-*`、`solid-black-*`、`blue-*`、`green-*`、`orange-*`、`red-*`
- **禁止** Tailwind 默认色板：`gray-*`、`slate-*`、`zinc-*`、`emerald-*`、`indigo-*`、`violet-*`、`rose-*`
- 语义色模式学自 Alert：背景用色阶 `-1`，边框用 `-2`，图标/文字用 `-6`
- 背景层次体系：页面 `bg-[#f2f5fa]` > 容器 `bg-white` > 嵌套区 `bg-solid-black-2` > 深层嵌套 `bg-solid-black-3`
- 文字色 4 级：主文字 `text-black-12`、次要 `text-black-11`、辅助 `text-black-9`、禁用 `text-solid-black-8`
- 4 种语义场景的固定配色：info = blue、success = green、warning = orange、danger = red

#### 排版

-> 查阅 [design-tokens.md](./design-tokens.md) 排版章节

必须遵守：

- 字号只用 `--odn-font-size-*` 的 10 级体系，写法：`text-[length:var(--odn-font-size-*)]`
- 层级选择捷径：大数字 `headline-3`(24px)、区块标题 `headline-5`(16px)、正文 `text-md`(14px)、辅助/注释 `comment`(12px)
- 数据表格中的数字使用 `font-variant-numeric: tabular-nums` 对齐
- 标题用 `font-semibold`，正文默认字重，辅助文字不加粗

#### 间距

-> 查阅 [design-tokens.md](./design-tokens.md) 间距章节

必须遵守：

- 4px 基准网格：4 / 8 / 12 / 16 / 20 / 24
- 用 `gap-*` 做兄弟间距，**禁止** `space-x-*` / `space-y-*`
- 卡片内边距 `p-4`(16px)，紧凑区域 `p-3`(12px)
- 区块间纵向间距 `gap-4` 到 `gap-6`
- 图标与文字间距 `gap-1`(4px) 或 `gap-2`(8px)

#### 圆角

无需查文档，值从组件 SCSS 中提取：

- 控件面（与 Button / Card / Input / Alert 对齐）：**`rounded-[6px]`**
- 浮层 / 大面板：`rounded-xl`(12px)
- 小徽标 / 指示器 / 进度条轨道：`rounded-full`
- **禁止** `rounded-md`(4px) 和 `rounded-lg`(8px) — 它们是 Tailwind 默认值，与组件库的 6px 不对齐
- **禁止** 在 Tag / Badge 上用 `rounded-full`（药丸形），除非设计明确要求

#### 投影

-> 查阅 [design-tokens.md](./design-tokens.md) 投影章节

必须遵守：

- 引用 `--odn-shadow-*`，写法：`shadow-[var(--odn-shadow-N)]`
- 卡片默认 `shadow-1`，hover 升到 `shadow-2`，下拉面板 `shadow-3`，弹窗 `shadow-4`
- **禁止** Tailwind 默认投影：`shadow-sm` / `shadow-md` / `shadow-lg`

#### 交互反馈

学自 Button / Card / HoverFill / Input 的实际实现：

- **每个可交互元素必须有 hover 态**，过渡 `transition-colors duration-150`
- 列表项 / 行 hover：`hover:bg-solid-black-2`
- 品牌强调 hover：`hover:bg-brand-1`
- 可点击卡片 hover：投影升级 `hover:shadow-[var(--odn-shadow-2)]`，过渡 `transition-shadow duration-200`
- 按钮色彩 hover：色阶加深一级（如 `brand-6` -> `brand-7`）
- 图标按钮 hover：图标色从 `black-9` 到 `black-11`
- 禁用态统一：`opacity-50 pointer-events-none`
- 聚焦环（输入型元素）：`box-shadow: 0 0 0 2px var(--odn-color-blue-2)`
- **loading 态**：骨架屏用 `bg-solid-black-3 animate-pulse rounded-[6px]` 占位；按钮/操作中 loading 用 `<Icon name="loading" />` + 文字"加载中"，同时 `pointer-events-none`
- **error 态**：红色语义 — 边框 `border-red-2`、背景 `bg-red-1`、文字 `text-red-6`；附带具体错误说明，不只是"出错了"
- **success 态**：绿色语义 — `text-green-6` + `<Icon name="check" />`；确认操作结果 + 说明后续影响
- **empty 态**：居中展示，`text-black-9` 说明文字 + 主操作按钮引导用户下一步；不要只显示空白

#### 代码结构

必须遵守：

- 根节点 `data-odn-<name>` 属性标识（如 `data-odn-metric-card`）
- 状态 / 变体通过 `data-odn-<name>-<prop>` 属性表达
- `clsx` 合并 className，**禁止** `cn()`
- `React.forwardRef` 包裹 + 设置 `displayName`
- Props 继承原生 HTML 元素类型（如 `extends React.HTMLAttributes<HTMLDivElement>`）
- 图标用内置 `<Icon name="..." />`，**禁止**外部图标库（`lucide-react`、`react-icons`、`heroicons`）

### 反模式清单

AI 在没有库内组件约束时，会退化为训练数据中的通用模板。以下模式**严格禁止**。

| ID    | 名称              | 识别方式                                                                               | 修复指引                                      |
| ----- | ----------------- | -------------------------------------------------------------------------------------- | --------------------------------------------- |
| AP-01 | Tailwind 默认色板 | 代码中出现 `gray-` / `slate-` / `zinc-` / `emerald-` / `indigo-` / `violet-` / `rose-` | 查阅色彩维度的规则，替换为 ODN 色名           |
| AP-02 | 硬编码色值        | 出现 `#xxx` / `rgb()` / `hsl()`（`bg-[#f2f5fa]` 页面底色除外）                         | 替换为 `--odn-*` 变量或 Tailwind 语义色       |
| AP-03 | 圆角不对齐        | 出现 `rounded-md`(4px) / `rounded-lg`(8px)                                             | 控件面用 `rounded-[6px]`，浮层用 `rounded-xl` |
| AP-04 | 通用投影          | 出现 `shadow-sm` / `shadow-md` / `shadow-lg`                                           | 替换为 `shadow-[var(--odn-shadow-N)]`         |
| AP-05 | 无交互反馈        | 可交互元素没有 `hover:` 类或 `transition`                                              | 添加 hover 态 + 过渡，见交互反馈维度          |
| AP-06 | space 替代 gap    | 出现 `space-y-*` / `space-x-*`                                                         | 替换为 `gap-*`                                |
| AP-07 | cn() 替代 clsx()  | 出现 `import { cn }` 或 `cn(`                                                          | 替换为 `import clsx from 'clsx'`              |
| AP-08 | 缺少 data-odn-\*  | 新 UI 根节点没有 `data-odn-` 属性                                                      | 添加 `data-odn-<name>`                        |
| AP-09 | 药丸形 Tag        | Tag / Badge 使用 `rounded-full`                                                        | 替换为 `rounded-[6px]`                        |
| AP-10 | 嵌套卡片          | Card 内部嵌套 Card                                                                     | 用间距和分隔线替代                            |
| AP-11 | 外部图标库        | 出现 `lucide-react` / `react-icons` / `heroicons`                                      | 替换为内置 `<Icon name="..." />`              |
| AP-12 | 通用禁用态        | 禁用样式各自为政（`text-gray-400` 等）                                                 | 统一 `opacity-50 pointer-events-none`         |
| AP-13 | 字号脱轨          | 出现 `text-xs` / `text-2xl` 等 Tailwind 默认字号                                       | 替换为 `--odn-font-size-*` 变量               |
| AP-14 | AI 紫色审美       | 出现 `purple-*` / `violet-*` / `fuchsia-*` / `indigo-*`                                | ODN 色板无紫色，见「AI 审美陷阱」章节         |
| AP-15 | 渐变背景          | 出现 `bg-gradient-to-*` / `from-*` / `via-*`                                           | ODN 使用实色，禁止渐变                        |
| AP-16 | 毛玻璃效果        | 出现 `backdrop-blur-*` / `bg-white/80` 等半透明                                        | ODN 是实色体系，禁止毛玻璃                    |
| AP-17 | 深色模式          | 大面积深色背景 + 亮色文字                                                              | ODN 是白底体系，禁止暗黑风                    |
| AP-18 | 装饰性动画        | 出现 `animate-bounce` / `animate-pulse`（非加载态）                                    | 仅加载态可用动画，禁止纯装饰动效              |

每条的 ❌ 错误 → ✅ 正确 对照：

```tsx
// AP-01 Tailwind 默认色板
// ❌ <div className="text-gray-900 bg-gray-50" />
// ✅ <div className="text-black-12 bg-solid-black-2" />

// AP-02 硬编码色值
// ❌ <div style={{ color: '#333' }} />
// ✅ <div className="text-black-12" />

// AP-03 圆角不对齐
// ❌ <div className="rounded-md" />
// ✅ <div className="rounded-[6px]" />

// AP-04 通用投影
// ❌ <div className="shadow-sm" />
// ✅ <div className="shadow-[var(--odn-shadow-1)]" />

// AP-05 无交互反馈
// ❌ <div className="cursor-pointer" />
// ✅ <div className="cursor-pointer hover:bg-solid-black-2 transition-colors duration-150" />

// AP-06 space 替代 gap
// ❌ <div className="flex flex-col space-y-4" />
// ✅ <div className="flex flex-col gap-4" />

// AP-07 cn() 替代 clsx()
// ❌ import { cn } from '@/lib/utils';
// ✅ import clsx from 'clsx';

// AP-08 缺少 data-odn-*
// ❌ <div className="rounded-[6px] bg-green-1" />
// ✅ <div data-odn-status-tag className="rounded-[6px] bg-green-1" />

// AP-09 药丸形 Tag
// ❌ <span className="rounded-full bg-green-100 px-2" />
// ✅ <span className="rounded-[6px] bg-green-1 px-2" />

// AP-10 嵌套卡片
// ❌ <Card><Card>内容</Card></Card>
// ✅ <Card><div className="border-b border-black-4 py-3">内容</div></Card>

// AP-11 外部图标库
// ❌ import { Check } from 'lucide-react';
// ✅ <Icon name="check" />

// AP-12 通用禁用态
// ❌ <div className="text-gray-400 cursor-default" />
// ✅ <div className="opacity-50 pointer-events-none" />

// AP-13 字号脱轨
// ❌ <span className="text-xs text-gray-500" />
// ✅ <span className="text-[length:var(--odn-font-size-comment)] text-black-9" />

// AP-14 AI 紫色审美
// ❌ <div className="bg-purple-50 text-purple-600" />
// ✅ <div className="bg-blue-1 text-blue-6" />

// AP-15 渐变背景
// ❌ <div className="bg-gradient-to-r from-purple-500 to-blue-500" />
// ✅ <div className="bg-brand-6" />

// AP-16 毛玻璃效果
// ❌ <div className="backdrop-blur-md bg-white/80" />
// ✅ <div className="bg-white shadow-[var(--odn-shadow-3)]" />

// AP-17 深色模式
// ❌ <div className="bg-gray-900 text-white" />
// ✅ <div className="bg-white text-black-12" />

// AP-18 装饰性动画
// ❌ <div className="animate-bounce" />
// ✅ <div />  (无装饰动画；仅 loading 态可用 animate-pulse/animate-spin)
```

### 延展模板

以下是库中没有但经常需要的 UI，按上述全部规则实现。每个模板已通过反模式清单检查。

#### 指标卡 MetricCard

设计锚点：Card（容器结构 + 投影）

```tsx
<div
  data-odn-metric-card
  className="rounded-[6px] bg-white p-4 shadow-[var(--odn-shadow-1)]"
>
  <div className="text-[length:var(--odn-font-size-text-sm)] text-black-9">
    总曝光量
  </div>
  <div className="mt-2 flex items-baseline gap-1">
    <span className="text-[length:var(--odn-font-size-headline-3)] font-semibold text-black-12">
      128,456
    </span>
    <span className="text-[length:var(--odn-font-size-comment)] text-black-9">
      次
    </span>
  </div>
  <div className="mt-1 flex items-center gap-1 text-[length:var(--odn-font-size-comment)]">
    <Icon name="up" size={12} />
    <span className="text-green-6">+12.5%</span>
    <span className="text-black-9">较昨日</span>
  </div>
</div>
```

#### 状态标签 StatusTag

设计锚点：Alert（语义色模式：背景 `-1`、文字 `-6`）

```tsx
<span
  data-odn-status-tag
  data-odn-status-tag-intent="success"
  className="inline-flex items-center gap-1 rounded-[6px] bg-green-1 px-2 py-0.5
    text-[length:var(--odn-font-size-comment)] text-green-6"
>
  <span className="h-1.5 w-1.5 rounded-full bg-green-6" />
  已完成
</span>
```

替换 `green` 为 `blue`(info)、`orange`(warning)、`red`(danger) 即可切换语义。

#### 步骤条 Steps

设计锚点：Tabs（激活态配色 `brand-6`）

```tsx
<div data-odn-steps className="flex items-center gap-2">
  {steps.map((step, i) => (
    <React.Fragment key={step.key}>
      <div className="flex items-center gap-2">
        <div
          data-odn-steps-dot
          className={clsx(
            'flex h-6 w-6 items-center justify-center rounded-full',
            'text-[length:var(--odn-font-size-comment)] font-medium',
            step.status === 'completed' && 'bg-brand-6 text-white',
            step.status === 'active' && 'border-2 border-brand-6 text-brand-6',
            step.status === 'pending' && 'bg-solid-black-3 text-black-9',
          )}
        >
          {step.status === 'completed' ? (
            <Icon name="check" size={14} />
          ) : (
            i + 1
          )}
        </div>
        <span
          className={clsx(
            'text-[length:var(--odn-font-size-text-md)]',
            step.status === 'active'
              ? 'font-medium text-black-12'
              : 'text-black-9',
          )}
        >
          {step.label}
        </span>
      </div>
      {i < steps.length - 1 && (
        <div
          className={clsx(
            'h-px w-8',
            step.status === 'completed' ? 'bg-brand-6' : 'bg-black-5',
          )}
        />
      )}
    </React.Fragment>
  ))}
</div>
```

#### 进度条 ProgressBar

设计锚点：Slider（轨道 + 填充双层结构）

```tsx
<div data-odn-progress className="flex items-center gap-3">
  <div className="h-2 flex-1 overflow-hidden rounded-full bg-solid-black-3">
    <div
      className="h-full rounded-full bg-brand-6 transition-all duration-300"
      style={{ width: `${percent}%` }}
    />
  </div>
  <span className="w-10 text-right text-[length:var(--odn-font-size-comment)] text-black-9">
    {percent}%
  </span>
</div>
```

#### 描述列表 DescriptionList

设计锚点：Form.Item（标签 + 值的水平布局）

```tsx
<div
  data-odn-description-list
  className="grid grid-cols-[auto_1fr] gap-x-6 gap-y-3"
>
  <dt className="text-[length:var(--odn-font-size-text-md)] text-black-9">
    创建时间
  </dt>
  <dd className="text-[length:var(--odn-font-size-text-md)] text-black-12">
    2025-01-15 14:30
  </dd>
  <dt className="text-[length:var(--odn-font-size-text-md)] text-black-9">
    状态
  </dt>
  <dd className="text-[length:var(--odn-font-size-text-md)] text-black-12">
    运行中
  </dd>
</div>
```

#### 统计列表 StatList

设计锚点：Table（行的分隔线 + 对齐方式）

```tsx
<div data-odn-stat-list>
  {items.map((item) => (
    <div
      key={item.label}
      className="flex items-center justify-between border-b border-black-4 px-4 py-3 last:border-b-0"
    >
      <span className="text-[length:var(--odn-font-size-text-md)] text-black-9">
        {item.label}
      </span>
      <span className="text-[length:var(--odn-font-size-text-md)] font-medium text-black-12">
        {item.value}
      </span>
    </div>
  ))}
</div>
```
