---
name: one-design
description: One Design Next 组件库知识包。包含 45+ 个组件的正确用法、--odn-* Design Token 规则、Icon 图标选择、间距排版规范，以及 Block 页面生成和 Skill 文件编写规范。当使用 one-design-next 组件库、开发腾讯广告如翼后台 UI 时自动触发。
queryable: true
query_topics:
  - 组件列表和用法
  - Design Token 和颜色规范
  - 图标名称查询
  - 间距排版规则
  - 组件代码模式
user-invocable: false
---

# One Design Next — 组件库知识包

基于腾讯广告如翼生态的中后台设计系统。组件通过 npm 包 `one-design-next` 分发，图标通过内置 `Icon` 组件渲染。

## 流程位置

```
PHASE 2 · 知识检索
角色：设计系统知识源（组件规范、Design Token、图标、编码模式）
被引用方：design-spec（生成设计 Prompt 时加载规则）、page-implement（代码生成时参考）、audit（审查时作为基准）、polish（精修时作为依据）
同层：business-knowledge（业务知识）
```

## 知识分层（外部平台适配）

本知识包的内容分为两层，外部平台打包时只需包含核心层：

### 核心层（随 skill 打包，始终可用）

| 文件                           | 说明                                                                                                                         |
| ------------------------------ | ---------------------------------------------------------------------------------------------------------------------------- |
| 本 `GUIDE.md`                  | 组件速查表、Design Token 映射、图标速查、工作流                                                                              |
| `rules/*.md`                   | 组件用法规则（forms / actions / overlays / data-display / navigation / icons / design-tokens / component-patterns / layout） |
| `references/component-list.md` | 完整组件导出列表                                                                                                             |
| `references/block-patterns.md` | Block demo 页面编码模式                                                                                                      |

### 项目层（依赖本项目文件系统，外部平台不可用）

| 文件                           | 说明               | 缺失时 fallback             |
| ------------------------------ | ------------------ | --------------------------- |
| `components/<name>/index.md`   | 组件详细文档和 API | 使用核心层的 rules 文件替代 |
| `components/<name>/demo/*.tsx` | 组件 demo 源码     | 使用核心层的代码模板替代    |

外部平台加载本知识包时，如果 `components/` 目录不存在，应仅使用核心层的 rules 文件指导组件用法，不报错。

---

## 核心设计哲学

> 每一次交互都要有**动效反馈**。组件库追求「跳跃」（clip-path 过渡）和「发芽」（Floating UI 浮层）的设计语言。

## 关键规则

以下规则**始终强制执行**。每条链接到详细的正确/错误代码对比文件，AI 按需加载。

### 视觉底线（零容忍） → [rules/design-paradigm.md](./rules/design-paradigm.md)

以下规则优先级最高，适用于所有场景（组件、区块、手写 div），不依赖按需加载：

- **实色填充。** 禁止 `linear-gradient`、`radial-gradient`、`bg-gradient-to-*`、`from-*`、`via-*`、`to-*`。ODN 是实色系统。
- **无 AI 审美。** 禁止毛玻璃 `backdrop-blur`、霓虹 `glow`/`neon`、大面积彩色背景。用投影层级 `shadow-1` ~ `shadow-4` 制造层次。
- **ODN 色板。** 禁止 Tailwind 默认色板（`blue-500`、`purple-600`、`indigo-*`）和硬编码 hex/rgb。一律用 ODN 语义色。
- **不是落地页。** 如果 UI 看起来像 SaaS 官网（渐变 Hero、全屏大图、紫蓝配色），就偏离了 ODN。ODN 是 B 端工具：白底、实色、方正、无装饰。

### 色彩与 Design Token → [rules/design-tokens.md](./rules/design-tokens.md)

- **使用 `--odn-*` CSS 变量。** 颜色/字号/圆角/阴影统一使用 `--odn-*` 前缀变量。
- **Tailwind 语义色。** 使用 `text-black-12`、`bg-blue-2` 等映射到 `var(--odn-*)` 的 Tailwind class。
- **禁止硬编码色值。** 不直接写 `#296BEF`，用 `var(--odn-color-brand-6)` 或 `text-brand-6`。
- **6 色色板体系。** brand（蓝）、black（透明灰阶）、solid-black（实色灰阶）、blue、green、orange、red，每色 10 级。
- **4 种语义色。** info=蓝、success=绿、warn=橙、error=红。
- **4 级投影。** `--odn-shadow-1` 到 `--odn-shadow-4`。

### 表单与输入 → [rules/forms.md](./rules/forms.md)

- **Form + Form.Item 布局。** 水平标签表单使用 `Form` + `Form.Item`。
- **Form.Item 的 `label` + `tooltip` + `required`。** 标准表单项三件套。
- **labelSize 自动对齐。** Form 的 `labelSize` 控制所有 Item 标签宽度，不设置则自动计算。

### 操作与触发 → [rules/actions.md](./rules/actions.md)

- **Button 的 `intent` 属性。** `normal` / `danger` / `primary`，不用 `variant`。
- **Button 的 `light` 布尔属性。** 轻量风格，自动使用 HoverFill。
- **Button 的 `icon` / `rightIcon`。** 传入 Icon name 字符串，不作为 children。
- **Button 的 `loading` 属性。** 加载态，自动显示 loading 图标。

### 浮层与弹窗 → [rules/overlays.md](./rules/overlays.md)

- **Dialog 的 `visible` + `onVisibleChange`。** 受控模式。
- **Dialog 的 `intent` 属性。** `info` / `success` / `warning` / `danger`。
- **Dialog 的 `title` / `desc`。** 标题和描述通过 props 传入。
- **Drawer / Popover / Tooltip 独立使用。** 选对浮层类型。

### 数据展示 → [rules/data-display.md](./rules/data-display.md)

- **Card + Card.Header 组合。** `title` / `subTitle` / `topContent` 通过 Header props 传入。
- **Card 的 `elevation` 属性。** 0-4 五级投影。
- **Table 使用 `columns` + `dataSource`。** `ColumnType` 定义列。

### 导航 → [rules/navigation.md](./rules/navigation.md)

- **Tabs 有 5 种变体。** `Tabs.Default` / `Tabs.ButtonGroup` / `Tabs.Vertical` / `Tabs.Divider` / `Tabs.Tag`。
- **Tabs 使用 `items` + `value` + `onChange`。** 数据驱动，非 children 模式。`onChange` 签名为 `(value, value_, e) => void`，第一个参数就是 value，可以直接写 `onChange={setState}`。
- **Pagination 独立组件。** `value` / `totalSize` / `onChange(e, value, pageSize)`。

### 图标 → [rules/icons.md](./rules/icons.md)

- **使用内置 `Icon` 组件。** `<Icon name="xxx" />`，不从外部包导入。
- **`name` 属性传入图标名。** 如 `plus`、`cancel`、`loading`、`right`、`help-circle` 等。
- **`size` 属性控制尺寸。** 默认 16px。
- **`spin` 属性控制旋转。** 用于 loading 图标。

### 设计范式 → [rules/design-paradigm.md](./rules/design-paradigm.md)

- **设计哲学**：朴素专业主义、动效即反馈、信息密度优先、Token 驱动一致性。
- **6 类设计范式**：从 45+ 组件和 26+ 区块中提炼的布局、数据展示、页面结构、交互反馈、色彩语义、图表可视化范式。
- **延展规范**：库中没有的 UI，按 ODN 设计语言延展，附带反模式清单和标准模板。

### 流畅界面 → [rules/fluid-interfaces.md](./rules/fluid-interfaces.md)

**触发时机**：涉及动画、过渡、easing、手势、入场/退场动效、交互反馈（:active/:hover）、性能优化时，必须加载此文件。

- **六维自检**：流畅、隐喻、编排、克制、简单、启发。
- **动画决策**：是否该动、easing 选择、时长参考、弹簧动画。
- **组件构建**：按压反馈、入场退场、Popover origin、性能优先 GPU。
- **品味**：构建的界面不是"能用"而是"感觉对"。

## 组件速查表

| 需求       | 使用组件           | 关键 Props                                                                          | Rules 文件      |
| ---------- | ------------------ | ----------------------------------------------------------------------------------- | --------------- |
| 按钮       | `Button`           | `intent`, `size`, `light`, `loading`, `icon`                                        | actions.md      |
| 图标       | `Icon`             | `name`, `size`, `spin`                                                              | icons.md        |
| 输入框     | `Input`            | `size`, `leftElement`, `rightElement`, `allowClear`, `count`, `onChange(e, value)`  | forms.md        |
| 多行输入   | `Input.Textarea`   | `autoSize`, `topElement`, `bottomElement`, `count`                                  | forms.md        |
| 数字输入   | `InputNumber`      | `min`, `max`, `step`                                                                | forms.md        |
| OTP 输入   | `InputOtp`         | `length`, `autoSubmit`, `onAutoSubmit`                                              | forms.md        |
| 下拉选择   | `Select`           | `options`, `value`, `onChange`, `mode`, `showInnerSearch`                           | forms.md        |
| 级联选择   | `Cascader`         | `options`, `value`, `onChange`                                                      | forms.md        |
| 树选择     | `TreeSelect`       | `treeData`, `value`, `onChange`                                                     | forms.md        |
| 自动补全   | `AutoComplete`     | `options`, `onSearch`, `inputProps`                                                 | forms.md        |
| 复选框     | `Checkbox`         | `checked`, `onChange`                                                               | forms.md        |
| 单选框     | `Radio`            | `checked`, `onChange`                                                               | forms.md        |
| 开关       | `Switch`           | `checked`, `onChange`                                                               | forms.md        |
| 滑块       | `Slider`           | `value`, `min`, `max`                                                               | forms.md        |
| 颜色选择   | `ColorPicker`      | `value`, `onChange`                                                                 | forms.md        |
| 日期选择   | `DatePicker`       | `value`, `onChange`, `mode`                                                         | forms.md        |
| 日期范围   | `DateRangePicker`  | `value`, `onChange`                                                                 | forms.md        |
| 时间选择   | `TimePicker`       | `value`, `onChange`                                                                 | forms.md        |
| 日历       | `Calendar`         | `lang`, `minDate`, `maxDate`, `disabledDays`                                        | data-display.md |
| 表单容器   | `Form`             | `labelSize`, `labelAlign`, `validationMode`                                         | forms.md        |
| 表单项     | `Form.Item`        | `label`, `required`, `tooltip`, `error`                                             | forms.md        |
| 卡片       | `Card`             | `elevation`, `interactive`                                                          | data-display.md |
| 卡片头部   | `Card.Header`      | `title`, `subTitle`, `topContent`, `size`                                           | data-display.md |
| 表格       | `Table`            | `columns`, `dataSource`, `bordered`, `striped`, `loading`, `rowSelection`           | data-display.md |
| 头像       | `Avatar`           | `src`, `fallback`, `icon`, `shape`, `size`, `badge`                                 | data-display.md |
| 头像组     | `Avatar.Group`     | `size`, `gap`, `tooltips`                                                           | data-display.md |
| 空状态     | `Empty`            | `type`(search/data/crowd/...), `title`, `description`, `extra`                      | data-display.md |
| 加载       | `Loading`          | `type`(ring/linear), `size`, `tip`                                                  | data-display.md |
| 文字省略   | `EllipsisText`     | `lines`                                                                             | data-display.md |
| 数字动画   | `NumberFlow`       | `value`, `format`                                                                   | data-display.md |
| 文字切换   | `TextSwap`         | `direction`                                                                         | data-display.md |
| Tab 导航   | `Tabs.Default`     | `items`, `value`, `onChange={setValue}`                                              | navigation.md   |
| 按钮组 Tab | `Tabs.ButtonGroup` | `items`, `value`, `onChange={setValue}`                                              | navigation.md   |
| 垂直 Tab   | `Tabs.Vertical`    | `items`, `value`, `onChange={setValue}`                                              | navigation.md   |
| 分隔 Tab   | `Tabs.Divider`     | `items`, `value`, `onChange={setValue}`                                              | navigation.md   |
| 标签 Tab   | `Tabs.Tag`         | `items`, `value`, `onChange={setValue}`                                              | navigation.md   |
| 分页       | `Pagination`       | `value`, `totalSize`, `onChange(e, value, pageSize)`                                | navigation.md   |
| 链接       | `Link`             | `href`, `target`                                                                    | navigation.md   |
| 对话框     | `Dialog`           | `visible`, `onVisibleChange`, `title`, `intent`                                     | overlays.md     |
| 抽屉       | `Drawer`           | `visible`, `onVisibleChange`, `title`, `placement`, `closable`                      | overlays.md     |
| 气泡卡片   | `Popover`          | `popup`, `placement`, `trigger`, `arrowed`                                          | overlays.md     |
| 文字提示   | `Tooltip`          | `popup`, `placement`, `trigger`                                                     | overlays.md     |
| 下拉菜单   | `Dropdown`         | `menu`, `trigger`, `selectable`, `multiple`, `value`, `onSelect`                    | overlays.md     |
| 全局消息   | `Message`          | `Message.info()`, `Message.success()`                                               | overlays.md     |
| 警告提示   | `Alert`            | `intent`(info/danger/success/warning), `title`, `message`, `closable`, `expandable` | overlays.md     |
| 折叠面板   | `Collapse`         | `items`, `activeKey`, `accordion`, `onChange`                                       | data-display.md |
| 可折叠     | `Collapsible`      | `open`, `onOpenChange`                                                              | data-display.md |
| 滚动区域   | `ScrollArea`       | `className`                                                                         | data-display.md |
| 图表       | `Chart`            | —                                                                                   | data-display.md |
| 虚拟列表   | `VirtualList`      | `data`, `children`, `itemKey`, `height`, `itemHeight`                               | data-display.md |
| 如翼布局   | `RuyiLayout`       | `menuItems`, `activeMenu`, `onMenuChange`                                           | layout.md       |
| 小程序布局 | `MpLayout`         | `menuItems`, `activeMenu`, `onMenuChange`, `pageTitle`                              | layout.md       |
| HoverFill  | `HoverFill`        | `disabled`                                                                          | actions.md      |
| 全局配置   | `ConfigProvider`   | `icons`, `hoverFill`                                                                | —               |

### GenUI · 消息

| 需求         | 使用组件          | 关键 Props                                                                          | Rules 文件 |
| ------------ | ----------------- | ----------------------------------------------------------------------------------- | ---------- |
| 流式文本     | `StreamText`      | `content`, `isStreaming`, `simulate`, `speed`, `typography`                          | genui.md   |
| 操作栏       | `ActionBar`       | `content`, `onRegenerate`, `onFeedback`, `versionCount`, `currentVersion`           | genui.md   |
| 思考         | `AgentThink`      | `content`, `isThinking`, `duration`, `variant`('block'\|'inline')                   | genui.md   |
| 分步         | `AgentStep`       | `tool: ToolCall`, `defaultOpen`, `onRetry`                                          | genui.md   |
| 代码块       | `CodeBlock`       | `code`, `language`                                                                  | genui.md   |
| 引用源       | `Sources`         | `sources: Source[]`, `defaultOpen`, `onUrlClick`                                    | genui.md   |
| 错误提示     | `ErrorBlock`      | `message`, `retryable`, `onRetry`                                                   | genui.md   |

### GenUI · 输入

| 需求         | 使用组件            | 关键 Props                                                          | Rules 文件 |
| ------------ | ------------------- | ------------------------------------------------------------------- | ---------- |
| 编排栏       | `Composer`          | `onSend(text, meta?)`, `onStop`, `isGenerating`, `placeholder`      | genui.md   |
| 附件         | `Attachments`       | `attachments: Attachment[]`, `onRemove`, `compact`                  | genui.md   |
| 建议         | `Suggestions`       | `suggestions: string[]`, `onSelect`                                 | genui.md   |
| 用户气泡     | `UserBubble`        | `message: ChatMessage`, `onFileClick`                               | genui.md   |

### GenUI · 会话

| 需求         | 使用组件            | 关键 Props                                                          | Rules 文件 |
| ------------ | ------------------- | ------------------------------------------------------------------- | ---------- |
| 对话项       | `ChatItem`          | `id`, `title`, `active`, `status`, `onClick`, `onRename`, `onDelete`| genui.md   |
| 内容预览面板 | `PreviewPanel`      | `tabs`, `activeTabId`, `onTabChange`, `onTabClose`, `onCloseAll`    | genui.md   |
| 欢迎         | `Welcome`           | `title`, `description`, `suggestions`, `onSelect`                   | genui.md   |

### GenUI 场景 → 组件组合

#### 基础对话界面

> 一问一答的 AI 聊天窗口，包含输入框和消息列表。

| 区域       | 组件                        | 说明                                 |
| ---------- | --------------------------- | ------------------------------------ |
| 欢迎屏     | `Welcome`                   | 标题、描述、建议列表                 |
| 技能选择   | `SkillSlot`                 | bar/menu/card 三种 variant，技能切换 |
| 输入区     | `Composer`                  | 文本输入 + 发送，可选附件/联网搜索   |
| 用户消息   | `UserBubble`                | 显示用户发出的文本和附件             |
| AI 回复    | `StreamText`                | 流式 Markdown 渲染                   |
| 操作栏     | `ActionBar`                 | 复制、重新生成、反馈                 |

#### Agent 工具调用对话

在基础对话之上增加：

| 区域       | 组件              | 说明                              |
| ---------- | ----------------- | --------------------------------- |
| 思考       | `AgentThink`      | 可折叠的思考内容 + 计时           |
| 分步       | `AgentStep`       | 工具名、参数、状态、结果          |
| 引用源     | `Sources`         | 搜索结果引用卡片                  |
| 代码块     | `CodeBlock`       | 代码执行结果高亮显示              |

#### 多轮对话管理 / 建议引导 / 附件 / 错误恢复

| 场景         | 核心组件                          |
| ------------ | --------------------------------- |
| 多轮对话管理 | `ChatItem` + `Welcome`            |
| 建议引导     | `Suggestions` + `Welcome`         |
| 附件         | `Attachments` + `Composer`        |
| 错误恢复     | `ErrorBlock` + `ActionBar`        |

#### 消息体组合模板

```
┌─ AgentThink (可选)
├─ AgentStep × N (可选)
├─ StreamText (主内容)
├─ CodeBlock × N (可选，内嵌于 StreamText)
├─ Sources (可选)
├─ Suggestions (可选)
├─ ActionBar
└─ SkillSlot (可选，通常放在 Composer 上方)
```

#### 类型依赖图

```
ChatMessage ─┬─ ToolCall[] ──→ AgentStep
             ├─ Attachment[] ─→ Attachments, UserBubble
             ├─ Source[] ─────→ Sources
             ├─ AgentEvent[] ─→ AgentThink, AgentStep
             └─ error ────────→ ErrorBlock

SkillItem ───→ SkillSlot
SendMeta ────→ Composer (onSend 第二参数)
Conversation ─→ ChatItem
```

> **上表中没有匹配的组件？** 参考 [rules/design-paradigm.md](./rules/design-paradigm.md) 的设计范式和延展规范，确保新 UI 的视觉语言与组件库一致。

## Design Token 语义映射

| CSS 变量                                | Tailwind Class                | 用途                  |
| --------------------------------------- | ----------------------------- | --------------------- |
| `--odn-color-brand-6`                   | `text-brand-6` / `bg-brand-6` | 主色 / 品牌蓝         |
| `--odn-color-black-12`                  | `text-black-12`               | 最深文字（95% 黑）    |
| `--odn-color-black-9`                   | `text-black-9`                | 占位符/辅助文字       |
| `--odn-color-black-6`                   | `border-black-6`              | 默认边框              |
| `--odn-color-solid-black-3`             | `bg-solid-black-3`            | 禁用背景              |
| `--odn-color-success`                   | —                             | 成功反馈绿 `#07C160`  |
| `--odn-color-warn`                      | —                             | 警示反馈橙 `#FA8E00`  |
| `--odn-color-error`                     | —                             | 错误反馈红 `#E63D2E`  |
| `--odn-color-info` / `--odn-color-link` | `text-link`                   | 信息蓝 / 链接色 `#576B95` |
| `--odn-shadow-1` ~ `--odn-shadow-4`     | —                             | 4 级投影体系          |

## 图标使用

图标通过内置 `Icon` 组件渲染，SVG 数据内嵌在组件库中：

```tsx
import { Icon } from 'one-design-next';

<Icon name="plus" />
<Icon name="cancel" size={24} />
<Icon name="loading" spin />
```

可通过 `ConfigProvider` 的 `icons` 属性注入自定义图标（path d 数组格式）。

常用图标名：

| 分类 | 图标 name                                                                                  | 使用场景           |
| ---- | ------------------------------------------------------------------------------------------ | ------------------ |
| 导航 | `left`, `right`, `up`, `down`                                                              | 箭头/展开          |
| 编辑 | `plus`, `cancel`, `search`, `edit`                                                         | 增删改查           |
| 反馈 | `info-circle-filled`, `check-circle-filled`, `alert-circle-filled`, `cancel-circle-filled` | Dialog intent 图标 |
| 工具 | `help-circle`, `loading`, `calendar`                                                       | 辅助功能           |

## 工作流

使用 One Design Next 组件时，按照以下步骤操作。

### 1. 导入组件

所有组件从 `one-design-next` 导入：

```tsx
import {
  Button,
  Card,
  Dialog,
  Form,
  Icon,
  Input,
  Table,
  Tabs,
} from 'one-design-next';
```

### 2. 使用 Tailwind 语义色

项目的 `tailwind.config.js` 将 Tailwind class 映射到 `--odn-*` CSS 变量：

```tsx
// 使用 Tailwind class（推荐在 block/demo 中使用）
<div className="text-black-12 bg-brand-1 border-black-6" />

// 使用 CSS 变量（推荐在组件 SCSS 中使用）
color: var(--odn-color-black-12);
```

### 3. 加载规则

根据要实现的 UI，加载对应的 rules 文件理解约束。

### 4. 生成代码

按组件速查表选择正确的组件，遵守 rules 中的 do/don't 规范。

### 5. 验证

- [ ] 所有组件从 `one-design-next` 导入
- [ ] 图标使用 `<Icon name="..." />`，不从外部包导入
- [ ] 颜色使用 `--odn-*` 变量或 Tailwind 语义色
- [ ] 无硬编码色值

## 从设计 Prompt 生成代码

当接收到 `design-spec` skill 输出的设计 Prompt 时：

### 协作流水线

```
design-analyst（需求分析）→ design-spec（设计 Prompt）→ page-implement（代码生成）← 本 skill（规则约束）
                                ↑                                                      ↑
                        business-knowledge（业务知识）                            one-design（设计系统知识）
```

### 执行步骤

1. **加载规则**：根据 Prompt 的「组件约束」加载对应 rules 文件
2. **确认组件可用**：所有组件在 `one-design-next` 中可用
3. **逐模块生成代码**：按 Prompt 的模块顺序实现
4. **模块自检**：对照 rules 逐项验证

### 设计 Prompt 协议

design-spec 输出的每个模块 Prompt 包含 8 个标准字段：

| 字段              | 说明                       | 本 skill 的用法                |
| ----------------- | -------------------------- | ------------------------------ |
| 业务上下文        | 模块业务目的               | 理解意图                       |
| 组件树            | 精确到 prop 的嵌套结构     | 直接转为 JSX                   |
| 图标清单          | Icon name 列表             | 写 `<Icon name="..." />`       |
| 组件约束          | 需遵守的组件规则           | 加载对应 rules 文件            |
| Design Token 约束 | 字号、颜色、间距           | 写 className / CSS 变量        |
| 状态处理          | normal/loading/empty/error | 实现条件渲染                   |
| 代码结构          | 文件路径、组件名、Props    | 创建文件和接口                 |
| 区块引用          | 复用/参考/新建已有区块     | 读取已有区块源码或从组件层搭建 |

## 详细参考

- [rules/design-tokens.md](./rules/design-tokens.md) — 色彩、间距、排版、阴影的完整变量体系
- [rules/forms.md](./rules/forms.md) — Form / Input / Select 等表单组件用法
- [rules/actions.md](./rules/actions.md) — Button 变体/尺寸/light/loading 用法
- [rules/overlays.md](./rules/overlays.md) — Dialog/Drawer/Popover/Tooltip 结构与选择
- [rules/data-display.md](./rules/data-display.md) — Card/Table/Avatar/Empty/Loading/Collapse/Calendar/VirtualList 用法
- [rules/navigation.md](./rules/navigation.md) — Tabs (5种变体)/Pagination/Link 用法
- [rules/layout.md](./rules/layout.md) — RuyiLayout/MpLayout 应用级布局
- [rules/icons.md](./rules/icons.md) — Icon 组件、name 命名、尺寸（含 genui- 前缀图标）
- [rules/genui.md](./rules/genui.md) — GenUI 对话组件用法规则与 do/don't
- [references/component-list.md](./references/component-list.md) — 完整组件导出列表（含 GenUI 组件）
- [references/block-patterns.md](./references/block-patterns.md) — Block demo 页面模式
- [rules/design-paradigm.md](./rules/design-paradigm.md) — 设计哲学、6 类设计范式、延展设计规范与模板
- [rules/fluid-interfaces.md](./rules/fluid-interfaces.md) — 流畅界面规范、动画决策、easing/时长、手势、性能
