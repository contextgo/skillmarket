---
name: wxad-one-design
description: >-
  用 one-design-next 组件库做如翼平台的页面。
  当用户说"做一个页面"、"做一个XX页面"、"搭建"、"生成"、"还原设计稿"、
  "审查代码"、"精修界面"、"查组件怎么用"、"创建项目"，
  或提到"如翼"、"人群资产"、"数据看板"、"仪表盘"、"列表页"、
  "one-design"、"odn"、"RuyiLayout"、"GenUI"、"AI对话"、"聊天界面"、
  "对话组件"、"流式文本"、"StreamText"、"Composer"、"PreviewPanel"、"预览面板" 等关键词时，必须使用本 skill。
  禁止用纯 HTML/CSS 或其他 UI 库替代 one-design-next 组件。 自动判断用户意图并路由到正确的子流程。
args:
  - name: input
    description: 用户的需求描述、截图、Figma 链接或代码片段
    required: true
  - name: mode
    description: full（完整模式，可修改知识库）/ readonly（只读模式，仅输出代码和建议，不修改组件库和区块目录）
    required: false
user-invocable: true
---

# One Design Next — 设计系统总入口

所有涉及 One Design Next 设计系统的用户请求都从这里进入。本 skill 负责：

1. 解析用户意图
2. **立即加载并执行**对应的子 skill（不是回答用户问题）
3. 在 readonly 模式下防止修改组件库和区块目录

## 语气

直接、具体。说文件名、组件名、命令。不说"让我们来看看"、"首先我需要"。
禁止 AI 式废话：不说"综合考虑"、"值得注意的是"、"需要指出"。
短段落。结尾给行动项。

## 强制路由规则

**当用户请求匹配任何子 skill 时，必须立即加载该 skill 的 GUIDE.md 并按其流程执行。
不要直接回答用户问题。不要跳过 skill 流程。子 skill 有结构化的多步工作流，
效果始终优于即兴回答。**

只有在没有任何 skill 匹配时，才直接回答。

## 整体架构

主流水线是横向的 5 个 skill 串联；p2 是一条并列的三层知识带，主流水线各阶段按需消费。

```
                     主流水线（PHASE 1 → PHASE 3 → PHASE 4）
    用户输入 → design-analyst → design-spec → page-implement → audit → polish
              （需求分析+提问）  （Prompt+区块匹配） （代码）     （审查） （精修）

        │             │               │                │          │        │
        ▼             ▼               ▼                ▼          ▼        ▼
    ┌────────────────────────────────────────────────────────────────────────────┐
    │                p2 知识层（三个并列知识包，按需加载）                          │
    ├───────────────────────┬──────────────────────┬─────────────────────────────┤
    │ p2-business-knowledge │ p2-block-catalog     │ p2-one-design               │
    │ 业务语境 / 站点地图     │ 区块清单 / rules /    │ 组件 / rules /               │
    │ 模块 / 页面知识         │ references（tsx）    │ references / design-tokens   │
    │                       │                      │                             │
    │ design-analyst 消费    │ design-spec 消费     │ design-spec / page-implement │
    │ design-spec 消费       │ page-implement 消费  │ / audit / polish 都消费      │
    └───────────────────────┴──────────────────────┴─────────────────────────────┘
```

**关键认知**：
- **主流水线**：5 个 skill 用 `next_skill` 前后咬合，自动接力
- **p2 知识层**：三个并列知识包，**不是一个大库**。做不同事情的 skill 只加载它需要的那部分
- 例如 `design-analyst` 只用 `business-knowledge`（+ 可选 `block-catalog` 作参考），不需要加载 `one-design`

## 路由规则

当你看到这些模式时，立即加载对应的 skill：

| 用户说了什么                                                        | 加载的 Skill      | 路径                         |
| ------------------------------------------------------------------- | ----------------- | ---------------------------- |
| 贴了截图/草稿图/线框图                                              | design-analyst    | `p1-design-analyst/GUIDE.md` |
| "做一个页面"、"搭建 XX"、"生成区块"、"开发 XX 功能"                 | design-analyst    | `p1-design-analyst/GUIDE.md` |
| "分析这个需求"、"分析一下"                                          | design-analyst    | `p1-design-analyst/GUIDE.md` |
| 给了结构化需求文档、设计 Prompt                                     | design-spec       | `p1-design-spec/GUIDE.md`    |
| "审查"、"检查"、"review"、"合规检查"                                | audit             | `p3-audit/GUIDE.md`          |
| "精修"、"polish"、"优化细节"、"发布前"                              | polish            | `p3-polish/GUIDE.md`         |
| "创建项目"、"新建项目"、"初始化"、"scaffold"、"template"、"starter" | 本 skill 直接处理 | 见下方「创建项目」           |
| "GenUI"、"AI对话页面"、"聊天界面"、"对话组件"                       | 本 skill 直接处理 | 见下方「知识查询」           |
| "有哪些组件"、"怎么用 XX"、"查一下"、"设计规范"                     | 本 skill 直接处理 | 见下方「知识查询」           |
| "实现页面"、"生成页面代码"、"把设计稿转成代码"                     | page-implement    | `p5-page-implement/GUIDE.md` |

> `page-implement` 处理页面级设计实现，用已有区块 + 设计系统拼装完整页面。design-spec 完成后默认接力到 page-implement。

### 路由消歧规则

当用户说的话同时匹配多个 skill 时，按以下优先级判断：

1. **"创建模板"/"直接用 workshop"/"不需要改动"** → 走「创建项目」（从 references/ 组装），不走设计流水线。用户要的是拿到一个可运行的项目，不是让 AI 生成代码。
2. **"做一个 XX 页面"但当前不在 ODN 项目中** → 先走「创建项目」scaffold，再进 design-analyst。
3. **"做一个 XX 页面"且已在 ODN 项目中** → 直接进 design-analyst。
4. **同时出现"创建"+"页面"但语义更像脚手架**（如"创建如翼首页的模板"） → 走「创建项目」。关键区分词：**"模板"、"template"、"starter"、"scaffold"、"直接用"** 指向创建项目；**"做"、"搭建"、"生成"、"开发"** 指向设计流水线。

**不确定分什么类？** 问用户，不猜。格式：
"您想要 (A) 创建新项目、(B) 创建页面/区块、(C) 审查已有代码、(D) 查询组件用法、(E) 其他？"

### 项目环境检查（前置步骤）

**在执行 design-analyst、design-spec、page-implement 之前，先检查当前是否在 ODN 项目中：**

1. 查看当前目录是否有 `package.json`，且 dependencies 中包含 `one-design-next`
2. **如果不在 ODN 项目中** → 先执行「创建项目」（从 references/ 组装），再继续原流程
3. **如果已在 ODN 项目中** → 直接进入对应 skill

这保证用户说"做一个数据看板"时，AI 会先 scaffold 项目、再进入设计流水线，而不是在一个空目录里生成代码。

#### 短路规则：空目录 + 无终端

如果以下条件**同时**满足，**直接输出组装步骤让用户手动执行**，不进入子 skill：

1. 当前目录为空 或 不含 `package.json`
2. **无终端执行能力**（无法运行 shell 命令）
3. 用户意图为「创建项目」或「直接使用模板」

输出「创建项目」章节中的完整组装步骤，让用户在终端中自行执行。所有文件都在 `references/` 目录下，不需要网络。

## 流水线

子 skill 之间有固定的接力关系。当一个 skill 执行完毕后，自动加载下一个：

```
[项目环境检查] → design-analyst → design-spec → page-implement → audit → polish
```

每个 skill 的 frontmatter 中声明了 `next_skill`，按此执行。
`mode` 参数沿流水线向下透传。

## mode 参数

### readonly 模式（外部平台默认）

当 `mode=readonly` 时：
- 不写入 `docs-pages/`、不更新 `block-catalog`、`business-knowledge` 等知识文件
- 不修改 `components/` 下的组件源码
- `page-implement` 输出代码到用户工作目录
- `polish` 输出修复建议但不自动修改
- `audit` 和知识查询正常工作

向下游传递时标注：`mode: readonly`

### full 模式（本项目内部默认）

完整功能，所有操作正常执行。

## 知识查询

当用户只是提问（不是要创建/审查/修复），本 skill 直接回答，不转发。

| 用户问题类型                        | 读取的文件                                                 |
| ----------------------------------- | ---------------------------------------------------------- |
| 组件用法（"Button 怎么用"）         | `p2-one-design/GUIDE.md` + `p2-one-design/rules/` 对应文件 |
| 组件列表                            | `p2-one-design/references/component-list.md`               |
| 设计规范（"颜色"、"间距"、"Token"） | `p2-one-design/rules/design-tokens.md`                     |
| 图标（"搜索图标叫什么"）            | `p2-one-design/rules/icons.md`                             |
| GenUI 组件（"对话组件怎么用"）      | `p2-one-design/rules/genui.md` + `GUIDE.md` GenUI 章节    |
| 区块（"有没有筛选区块"）            | `p2-block-catalog/GUIDE.md`                                |
| 业务知识（"5R 是什么"）             | `p2-business-knowledge/GUIDE.md` + `rules/`                |
| 页面类型（"仪表盘长什么样"）        | `p2-business-knowledge/GUIDE.md` 页面类型参考              |
| 已有 workshop 页（slug、改某页、和某页对齐） | `p2-page-catalog/GUIDE.md`（含 **`/<slug>`** 路由约定）+ `p2-page-catalog/rules.md` |

流程：识别问题类型 → 读取对应文件 → 提取信息 → 简洁回答。

### 已有 workshop 页面（与 `p2-page-catalog` 联跑时）

当用户要改**已实现**的如翼 workshop 页时：

1. **路由**：浏览器访问 **`/<slug>`** 直达该页，或打开 **`/catalog`** 浏览全部 slug；`slug` 与 `p2-page-catalog/rules.md` 中的章节标题一致。文件名与 slug 不一致时查 `references/workshop/workshopModules.ts` 的 `WORKSHOP_SLUG_TO_IMPORT`。
2. **文档站区别**：dumi 上为 **`/workshop/<slug>`**；模板独立跑时为 **`/<slug>`**。
3. **源码位置**：`references/workshop/<slug>.tsx`（skills 内自包含），详见 `p2-page-catalog/GUIDE.md`。

### 区块查询 · 按"想解决什么产品问题"路由

区块目录（`p2-block-catalog`）按 L1/L2/L3/L4 分层。当用户问"要做 XX 该用什么区块"时，按产品问题映射：

| 产品问题 | 优先考虑的区块 | 层级 |
| --- | --- | --- |
| 页面壳（复盘主从布局） | `review-master-detail-layout` | L1 |
| 页面头部/筛选栏/Tab | `page-header`（14 种模式） | L1 |
| 从候选池挑选人群 | `crowd-pick-card-grid` | L2 |
| 某维度的排位展示 | `ranking-list`（brand/share/hot/surge 4 变体） | L2 |
| 5R 人群资产指标 | `metric-card-group` | L2 |
| 品牌心智量 + 份额 + 趋势 | `metrics-overview` | L2 |
| 渗透率对比 + 榜单联动 | `penetration-analysis` | L2 |
| 多媒体触点对比 | `touchpoint-analysis` | L2 |
| 通用词云段落 | `wordcloud-section` | L2 |
| 本品 vs 参照系雷达对比 | `radar-with-metrics-panel` | L2 |
| 转化复盘的核心指标 | `conversion-metrics` / `conversion-trend` | L3 |
| 人群相似度涟漪 | `ripple-chart` | L3 |
| 资产流转桑基图 | `sankey-chart` | L3 |
| 心智图谱 TreeMap | `treemap-panel` | L3 |
| 四象限分布图（资产×R3 或心智双矩阵，同一 `quadrant-scatter`） | `quadrant-scatter` | L3 |
| 结构化"热词榜+多层词云" | `mindshare-dictionary` | L3 |

**选择准则**：
- 优先 L1（页面壳）和 L2（多页复用）。L3（场景专属）只在业务语境匹配时用，误用会引入不相关的 UI 复杂度
- L4 层级用于「交互模式」类知识；当前无独立区块 slug，复杂弹窗/表单在对应 workshop 页面内联实现
- 找不到匹配的区块 → 内联实现；判断是否应该纳入"候选区块"观察（见 `p2-block-catalog/GUIDE.md` 的候选区块小节）

## 创建项目

当用户意图为创建新项目时，从 `references/` 目录组装一个基于 one-design-next 的完整项目。

**强制规则：必须使用 Vite + React + TypeScript + Tailwind CSS + one-design-next 组件库。
禁止用纯 HTML/CSS、Material UI、Ant Design 或其他 UI 库替代。
所有如翼页面必须以 `RuyiLayout` 组件为页面壳。**

### 处理流程

1. **读取 MANIFEST**：先读 `references/MANIFEST.json`。它预计算了每个页面的文件、区块依赖和数据依赖，**不需要自行扫描 import**
2. **推断项目名称**：从用户描述中提取项目名（如"创建一个数据看板"→ `data-dashboard`），无法推断时用 `odn-app`
3. **判断复制范围**：
   - 用户要全部页面 → 复制全量 workshop + blocks（见「全量复制」）
   - 用户指定了具体页面（如"首页"）→ 按 MANIFEST 只复制该页面 + 依赖（见「按需复制」）
4. **创建项目目录**，组装 scaffold + 选定的 workshop/blocks
5. **安装依赖**：运行 `npm install`
6. **定制（可跳过）**：根据用户需求修改。**如果用户明确说"不需要改动"/"直接用"，跳过此步**
7. **告知用户**：
   - `npm run dev` 启动开发服务器
   - **如果用户提到了具体页面**（如"首页"对应 slug `home`）→ 告知 `http://localhost:5173/<slug>` 直达该页
   - `http://localhost:5173/catalog` 查看全部已有页面
   - `http://localhost:5173/` 是空壳起始页，用于从零搭新页面

### 降级策略

| 条件 | 行为 |
|------|------|
| 有终端 | 自动执行下方全部步骤 |
| 无终端 | 输出完整步骤让用户手动执行（包括文件列表和命令） |

**不存在"网络不通"的问题**——所有文件都在本地 `references/` 里，不需要 clone 或 degit。

### 组装步骤

#### 1. 创建 Vite + React + Tailwind 项目骨架

```bash
mkdir <项目名> && cd <项目名>
npm init -y
```

设置 `package.json`：

```json
{
  "name": "<项目名>",
  "private": true,
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "tsc && vite build",
    "preview": "vite preview"
  }
}
```

安装依赖：

```bash
npm install one-design-next react react-dom react-router-dom
npm install -D @tailwindcss/vite tailwindcss @vitejs/plugin-react vite typescript @types/react @types/react-dom
```

创建 `tsconfig.json`：

```json
{
  "compilerOptions": {
    "target": "ES2020",
    "useDefineForClassFields": true,
    "lib": ["ES2020", "DOM", "DOM.Iterable"],
    "module": "ESNext",
    "skipLibCheck": true,
    "moduleResolution": "bundler",
    "allowImportingTsExtensions": true,
    "isolatedModules": true,
    "moduleDetection": "force",
    "noEmit": true,
    "jsx": "react-jsx",
    "strict": true,
    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "noFallthroughCasesInSwitch": true,
    "resolveJsonModule": true
  },
  "include": ["src"]
}
```

创建 `index.html`：

```html
<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><项目名></title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
```

#### 2. 复制 scaffold 关键文件

从 `references/scaffold/` 复制到项目根目录和 `src/`：

| 来源 | 目标 | 说明 |
|------|------|------|
| [`references/scaffold/vite.config.ts`](references/scaffold/vite.config.ts) | `vite.config.ts` | React dedupe，**不可删减** |
| [`references/scaffold/main.tsx`](references/scaffold/main.tsx) | `src/main.tsx` | 全局 React 兼容，**不可删减** |
| [`references/scaffold/app.css`](references/scaffold/app.css) | `src/app.css` | ODN token → Tailwind 桥接，**不可删减** |
| [`references/scaffold/App.tsx`](references/scaffold/App.tsx) | `src/App.tsx` | 路由入口 |
| [`references/scaffold/vite-env.d.ts`](references/scaffold/vite-env.d.ts) | `src/vite-env.d.ts` | Vite 类型声明 |
| [`references/scaffold/pages/`](references/scaffold/pages/) | `src/pages/` | StarterShell、WorkshopPage、WorkshopCatalog、DefaultDashboard |
| [`references/scaffold/config/`](references/scaffold/config/) | `src/config/` | menuItems.ts |

#### 3. 复制 workshop 页面和区块

| 来源 | 目标 | 说明 |
|------|------|------|
| `references/workshop/*.tsx` | `src/workshop/` | 33 个完整页面 |
| `references/workshop/workshopModules.ts` | `src/workshop/` | 页面注册表 |
| `references/workshop/data/*.json` | `src/workshop/data/` | mock 数据（精简版） |
| `references/blocks/` | `src/blocks/` | 31 个可复用区块 |

#### 全量复制（快捷命令，有终端时一键执行）

```bash
# 假设 SKILLS_DIR 指向 skills/ 目录的绝对路径
SKILLS_DIR="<skills目录路径>"

cp "$SKILLS_DIR/references/scaffold/vite.config.ts" .
mkdir -p src/pages src/config src/workshop/data src/blocks

cp "$SKILLS_DIR/references/scaffold/main.tsx" src/
cp "$SKILLS_DIR/references/scaffold/app.css" src/
cp "$SKILLS_DIR/references/scaffold/App.tsx" src/
cp "$SKILLS_DIR/references/scaffold/vite-env.d.ts" src/
cp "$SKILLS_DIR/references/scaffold/pages/"*.tsx src/pages/
cp "$SKILLS_DIR/references/scaffold/config/"*.ts src/config/

cp "$SKILLS_DIR/references/workshop/"*.tsx src/workshop/
cp "$SKILLS_DIR/references/workshop/"*.ts src/workshop/
cp "$SKILLS_DIR/references/workshop/data/"*.json src/workshop/data/
cp -r "$SKILLS_DIR/references/blocks/"* src/blocks/
```

#### 按需复制（用户只要特定页面时）

当用户只要一个或几个页面（如"创建如翼首页的模板"）：

1. **读 MANIFEST**：`references/MANIFEST.json` → 找到 `pages.<slug>`
2. **scaffold 不变**：scaffold 全部复制（同上）
3. **只复制需要的页面 + 依赖**：

以 `home` 为例，MANIFEST 记录：
```json
{
  "file": "workshop/home.tsx",
  "blocks": ["blocks/ry-date-range-picker.tsx"],
  "data": [
    "workshop/data/home-trend-data.json",
    "workshop/data/home-view-data.json",
    "workshop/data/market-rank-config.json",
    "workshop/data/market-rank-data.json"
  ]
}
```

只需复制：
- `workshop/home.tsx` → `src/workshop/`
- `workshop/workshopModules.ts` → `src/workshop/`（**始终需要**，但只保留选中页面的注册条目）
- `workshop/data/home-*.json` + `workshop/data/market-rank-*.json` → `src/workshop/data/`
- `blocks/ry-date-range-picker.tsx` → `src/blocks/`
- 如果区块依赖 `_internal/*`，也一并复制 `blocks/_internal/`

**不需要逐个读 tsx 文件来分析 import——MANIFEST 已预计算。**

### 项目架构

组装后的项目使用 **React Router** 做 URL 路由，三条路由：

| 路由 | 组件 | 用途 |
|------|------|------|
| `/` | `StarterShell` | 空白 RuyiLayout 壳 + 默认仪表盘，用于「从零搭页」 |
| `/catalog` | `WorkshopCatalog` | 所有已有 workshop 页面的索引列表 |
| `/:slug` | `WorkshopPage` | 动态路由，从 `workshopModules.ts` 懒加载指定页面 |

每个 workshop 页面（`src/workshop/<slug>.tsx`）是**完全自包含的**——内置 RuyiLayout + 菜单 + 业务内容 + mock 数据，不依赖外部状态。

**页面注册表** `src/workshop/workshopModules.ts` 包含两个导出：
- `WORKSHOP_SLUG_TO_IMPORT`：slug → 懒加载 import 映射（`/:slug` 路由用）
- `WORKSHOP_INDEX`：`{ slug, title }[]` 数组（`/catalog` 展示用）

### 定制要点

| 修改项 | 位置 | 说明 |
|--------|------|------|
| 侧栏菜单 | `src/config/menuItems.ts` 的 `MENU_ITEMS` | 按业务需求设计导航层级，`icon` 使用 ODN 图标名 |
| 首页壳 | `src/pages/StarterShell.tsx` | 修改 `accountName`、`accountId`、默认内容 |
| 页面标题 | `index.html` 的 `<title>` | 修改为项目名称 |
| 新增业务页面 | `src/workshop/<slug>.tsx` | 创建页面文件（见下方流程） |

### 新增页面

1. **写页面文件**：`src/workshop/<slug>.tsx`（每个页面自包含 RuyiLayout + 菜单 + 内容）
2. **注册到 `workshopModules.ts`**：

```ts
// 在 WORKSHOP_SLUG_TO_IMPORT 中添加：
"<slug>": () => import("./<slug>"),

// 在 WORKSHOP_INDEX 中添加：
{ slug: "<slug>", title: "页面中文名" },
```

3. 注册后即可通过 `/<slug>` 路由访问

### 注意事项

- `app.css` 第一行必须是 **`@import 'tailwindcss' important;`**——末尾的 `important` 不可省略，否则 Tailwind utility class 无法覆盖 ODN 组件内部样式。如果不用 `references/scaffold/app.css` 而自行创建，务必确保这一行正确。
- `app.css` 中的 `@theme` 块是核心——它将 ODN CSS 变量桥接到 Tailwind 4 的工具类体系。**必须原样保留，不可删减。**
- `main.tsx` 中的 `globalThis.React = React` 是 one-design-next 兼容所需，**不可删除**。
- `vite.config.ts` 中的 `resolve.dedupe` + `resolve.alias` 防止 React 多副本，**不可删除**。

## 完成状态协议

每个 skill 完成后，报告以下状态之一：

| 状态                   | 含义                                         |
| ---------------------- | -------------------------------------------- |
| **DONE**               | 全部步骤完成。给出证据。                     |
| **DONE_WITH_CONCERNS** | 完成了，但有问题需要用户知道。列出每个问题。 |
| **BLOCKED**            | 无法继续。说明原因和已尝试的方法。           |
| **NEEDS_CONTEXT**      | 缺少信息。明确说需要什么。                   |

## 熔断机制

- 同一步骤尝试 **3 次**仍然失败 → 停止，报告 BLOCKED
- 对安全敏感的操作没有把握 → 停止，让用户决定
- 工作范围超出可验证的范围 → 停止，告知用户

熔断格式：

```
状态：BLOCKED
原因：[1-2 句]
已尝试：[做了什么]
建议：[用户下一步该做什么]
```

## 错误处理

| 场景                      | 处理                                                         |
| ------------------------- | ------------------------------------------------------------ |
| 无法判断意图              | 用上方选择题问用户                                           |
| readonly 模式下请求写操作 | "当前为只读模式，无法修改组件库。代码将输出到您的工作目录。" |
| 缺少必要输入              | 根据目标 skill 的 args 定义，提示补充                        |
| 子 skill 文件不存在       | 回退到 one-design 知识包直接回答                             |
| 知识文件缺失（外部平台）  | 使用核心层知识，不报错。见各知识包的「知识分层」章节         |
