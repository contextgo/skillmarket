# 区块规格总表

> 本文件合并了所有区块的规格文档。每个区块用二级标题 `## slug: <slug>` 分隔。

## slug: ai-brief-input

# AI Brief / 智选输入（`ai-brief-input`）

**实现口径：ODN `AutoComplete`**，对齐 **dmp-web `AIAutoComplete`**（`TadAutoComplete` + `inputProps.leftElement` / `rightElement`），**不是**独立 `Input` + 自定义下拉条（旧 Figma 稿 `AiBriefInput` 已废弃作规范来源）。

**真源代码**：`references/blocks/ai-brief-input.tsx`（导出 `AISearchBar`、`AISearchResultPanel`）；`create-audience.tsx` **import 复用**该文件。宿主布局示例：`PanelTags` 内 `flex-col` + `gap-[14px]`。

## 产品问题（何时用）

**解决什么**：在「从标签列表中选择」等人群构建场景，用自然语言描述目标人群；输入框左侧 AI 图标、右侧主色「搜索」按钮；下拉可承载历史检索词；提交/搜索后在下方展示 AI 推荐理由与推荐标签（与 dmp-web `AICreateAudience` 信息架构一致）。

**出现页面**：

- 如翼 > 人群策略 > 自定义人群 > **新建人群**（`/workshop/create-audience`，`PanelTags` 顶栏）

**典型信号**：需求写「AI 搜索」「智选」「对齐 dmp-web 新建人群顶栏」时使用本模式；slug 仍记为 `ai-brief-input` 时，**规则即本 AutoComplete 组合**，勿再按旧稿 864×56 + 箭头图标实现。

## 不要用本模式的场景（L3）

- 纯关键词过滤表格、无 AI 语义 → `Input` / `Select` 即可
- 候选人群卡片挑选 → `crowd-pick-card-grid`
- 多步表单壳 → `step-form-shell`（候选）

## 结构图（workshop 真布局）

```
┌───────────────────────────────────────────────────────────────┐
│  ● 从标签列表中选择    …    …                                  │  ← Tab 头（内联）
├───────────────────────────────────────────────────────────────┤
│  ┌─────────────────────────────────────────────────────────┐  │
│  │ [✨]  描述目标人群特征，为你推荐标签……      [ 搜索 ]    │  │  ← AutoComplete 单行
│  └─────────────────────────────────────────────────────────┘  │
│  ┌─────────────────────────────────────────────────────────┐  │
│  │  搜索  "关键词…"                              [×]       │  │  ← 可选：AISearchResultPanel
│  │  … 推荐理由 + 标签 chips …                               │  │
│  └─────────────────────────────────────────────────────────┘  │
│  [标签分组列表 …]                                              │
└───────────────────────────────────────────────────────────────┘
```

## 组件构成

| 元素 | 组件 | 说明 |
| ---- | ---- | ---- |
| 主控件 | `AutoComplete`（`one-design-next`） | `value` + `options` + `onSearch` 驱动文案（`onSearch` 内同步 `onChange` 到父级 state） |
| 左侧装饰 | `inputProps.leftElement` | AI 星形 SVG（16×16，与 dmp-web 一致），外包 `flex w-6 items-center` |
| 右侧操作 | `inputProps.rightElement` | `Button intent="primary" size="small"` 文案「**搜索**」；`value.trim() === ''` 时 `disabled`；可用 `className="relative -right-2"` 贴边对齐 |
| 下拉 | `AutoComplete` 内置面板 | `dropdownStyle={{ borderRadius: 12 }}`；`options` 为历史词 `{ value, label }[]`（真实项目接接口） |
| 结果区（可选） | 自定义 `div`（`AISearchResultPanel`） | 浅蓝底卡片、渐变「搜索」标题、关闭、理由段落、标签行、底部「添加全部」等——对齐 dmp-web `chatItemGroups` 式排版 |

## 样式 token（与真源一致）

宿主通过 `style` 注入 CSS 变量（便于与 dmp 50px 条高一致）：

| 变量 / 属性 | 用途 |
| ------------ | ---- |
| `--odn-control-height: 50px` | 控件整体高度 |
| `--odn-input-padding-block-medium: 8px` | 垂直内边距 |
| `--odn-input-padding-inline-medium: 17px` | 水平内边距 |
| `--odn-input-border-radius-medium: 12px` | 输入条圆角 |
| `className="w-full"` | 随容器全宽 |

占位文案默认：**「描述目标人群特征，为你推荐标签」**（可按产品改，但保持一句说清能力）。

## 交互要点

| 行为 | 说明 |
| ---- | ---- |
| 输入 | `onSearch` 收到值即写回受控 `value`，保证右侧「搜索」随输入启用/禁用 |
| 空串 | 右侧「搜索」`disabled`，避免空搜 |
| 历史下拉 | 用 `options` 展示；选中行为由 `AutoComplete` 默认或业务回调补充 |
| 结果面板 | 由宿主决定何时展示（workshop 示例：`showResult && searchText.trim() !== ''`） |

## 与页面其它部分的关系

| 关系 | 说明 |
| ---- | ---- |
| 位置 | 放在 **Tab 内容区顶部**，与下方标签树/表格间隔 `gap-[14px]`（示例 `px-6 pt-4`） |
| 数据 | 搜索词与「推荐标签」回填由业务串联；本规则只定 **壳层 UI** |

## Do / Don't

✅ **Do**

- 一律用 **`AutoComplete` + `inputProps.leftElement/rightElement`** 对齐 dmp-web，便于后续与设计系统统一迭代。
- 需要结果区时，复用或抽取 `AISearchResultPanel` 的版式（渐变标题、理由、标签块、底部操作栏）。

❌ **Don't**

- ❌ 不要用旧 reference **`AiBriefInput`**（`Input` + 自定义双段 Brief 下拉 + 箭头按钮）作为新建人群或本 slug 的实现标准。
- ❌ 不要把「搜索」改成仅图标箭头而脱离 dmp 文案，除非产品全局改版。
- ❌ 不要在每个子 Tab 内各放一套互不同步的搜索条（应保持单一受控 `searchText` 源）。

## `references/ai-brief-input.tsx` 说明

**唯一真源**：`AISearchBar`、`AISearchResultPanel` 及默认 mock 数据均在此文件导出；**`create-audience.tsx`** 通过 `import … from '../../references/blocks/ai-brief-input'` 复用，避免双份实现。

## Figma / 外部对齐（次要）

历史设计稿 node `5639:40764` 仅作产品讨论参考；**工程落地以 dmp-web + ODN `AutoComplete` 为准**。

## slug: conversion-metrics

# 转化概览 conversion-metrics

转化复盘概览面板，包含转化摘要行（数字高亮混排）、2×3 宫格指标卡和广告转化占比环形图。

## 产品问题（何时用）

**解决什么**：一屏把转化复盘的核心结论（触达 / 曝光 / 频次 / 花费 / 成本）、6 个关键指标、以及广告转化占比环形图组合呈现。用户不用滚动就能形成"这次投放效果怎么样"的初步判断。

**出现页面**：
- 如翼 > 全域度量 > [转化复盘 conversion-review](/workshop/conversion-review?fullscreen=1) · 概览

**典型信号**：需求里出现"转化概览"、"6 宫格指标"、"广告转化占比"、"环形图 + 指标卡"时使用。

## 不要用本区块的场景

- 转化的时间趋势 → 用 `conversion-trend`（L3）
- 频次分析（柱+折线双轴） → 用 `crowd-bar-chart`（L3）
- 5R 资产的指标卡组 → 用 `metric-card-group`（L2）

## 适用页面

- 营销复盘 · 转化复盘 · 概览 Tab

## 交互状态

| 状态 | 行为 |
| --- | --- |
| default | 展示完整面板：标题 + 参考系 Select + 摘要行 + 指标卡网格 + 环形图 |
| 参考系 change | Select 切换参考系（本品历史均值 / 行业均值 / 同品类均值），联动指标卡的同比文字 |
| hover 指标卡标签 | 虚线下划线提供可交互暗示 |

## 变体

| 变体 | 说明 | 适用场景 |
| --- | --- | --- |
| 完整版（默认） | 摘要行 + 6 宫格 + 环形图 | 转化复盘概览 Tab |
| 无摘要行 | 去掉顶部摘要行 | 空间受限时 |
| 无环形图 | 仅左侧指标卡网格 | 不需要转化占比可视化时 |

## 数据结构

```typescript
interface MetricCard {
  label: string;
  value: string;
  comparison?: string;
}

// 摘要行使用 segments 数组混排
interface SummarySegment {
  text: string;
  highlight?: boolean;
}

// 参考系选项
interface ReferenceOption {
  label: string;  // 本品历史均值 / 行业均值 / 同品类均值
  value: string;  // self / industry / category
}

// 环形图常量
const DONUT_PCT = 60.02;   // 广告转化占比
const DONUT_TOTAL = '8,080'; // 总转化人数
```

## 规则

- DO：容器使用 `Card elevation={0}` + 外层 `rounded-xl bg-[#f2f5fa] p-6` 灰底，形成前景/背景分离（与 metrics-overview 一致）
- DO：参考系使用 `Select size="small"`，不用 Button；选项文本本品历史均值 / 行业均值 / 同品类均值
- DO：环形图使用 ECharts（`echarts/core` + 按需 `PieChart/TitleComponent/TooltipComponent`，`CanvasRenderer`），颜色通过 `getComputedStyle` 读取 `--odn-color-*` CSS 变量，避免硬编码
- DO：ECharts pie 使用 `radius: ['62%','82%']` + `itemStyle.borderRadius: 16` 模拟手写 SVG 的 `strokeLinecap="round"` 圆角端点
- DO：ECharts 实例在 `useEffect` 中初始化，返回的清理函数里 `chart.dispose()`；配合 `ResizeObserver` 响应容器尺寸变化
- DO：摘要行使用 segments 数组遍历，根据 `highlight` 切换字号和颜色
- DO：指标卡标签使用 `width: fit-content` 限制虚线下划线宽度
- DO：数值使用 `tabular-nums` 确保等宽对齐
- DO：指标卡上下两行使用 `border-t border-black-4` 分割线分隔
- DON'T：不要给 Card 外再加边框或投影，elevation=0 已经给出合适层级
- DON'T：环形图区域宽度固定 `w-[424px]`，不要使用 flex 弹性分配
- DON'T：图例色块不要使用圆形，使用 `rounded-[2px]` 方块
- DON'T：不要退回用 Button 做参考系切换——设计稿是 Select 下拉样式
- DON'T：不要整包 `import * as echarts from 'echarts'` —— 必须按需注册以控制包体积

## 完整实现代码

生成代码时，**必读** [`../references/conversion-metrics.tsx`](../references/conversion-metrics.tsx)。该文件是本区块的完整参考实现，禁止凭本文的结构描述自行猜测实现，应以 references 中的代码为基准进行复用或裁剪。

## slug: conversion-trend

# 转化趋势图 conversion-trend

转化复盘趋势图区块，**堆叠柱状图（广告/其他转化人数）+ 折线图（转化占比，右 Y 轴）**，基于 ECharts。与 workshop `conversion-review` 同源。

## 产品问题（何时用）

**解决什么**：沿时间轴展示"广告转化 vs 其他转化"的每日堆叠柱状图，叠加转化占比折线，让用户看到趋势和广告贡献度的变化。

**出现页面**：
- 如翼 > 全域度量 > [转化复盘 conversion-review](/workshop/conversion-review?fullscreen=1) · 概览

**典型信号**：需求里出现"转化趋势"、"堆叠柱+折线双轴"、"每日转化对比"时使用。

## 不要用本区块的场景

- 宏观 KPI 概览 → 用 `conversion-metrics`（L3）
- 心智相关趋势（双指标双轴） → 用 `metrics-overview`（L2）

## 适用页面

- 营销复盘 · 转化复盘 · 概览 Tab

## API

```typescript
import {
  ConversionTrend,
  type ConversionTrendItem,
} from 'references/blocks/conversion-trend';

interface ConversionTrendProps {
  items: ConversionTrendItem[];
  title?: string;          // 默认"转化人数趋势"
  tips?: string;           // 副标题/说明（显示为虚线下划线 tips）
  height?: number;         // 自定义图表高度
  zoomThreshold?: number;  // > 该值时自动开启 dataZoom 滑块，默认 15
}

interface ConversionTrendItem {
  date: number | string;   // 时间戳（秒/毫秒）或已格式化字符串
  conv_uv: number;         // 广告转化人数
  other_conv_uv: number;   // 其他转化人数
}
```

## 交互状态

| 状态 | 行为 |
| --- | --- |
| default | 所有堆叠柱渲染 + 折线显示 |
| items > zoomThreshold | 底部出现 `dataZoom` 滑块，初始展示前 15 条 |
| hover 柱组 | ECharts 默认 axisPointer shadow 高亮整列 + Tooltip |

## 设计规格

| 属性 | 值 |
| --- | --- |
| 外壳 | `border border-[#edeef2] rounded-[12px] px-6 py-5 bg-white`（SectionCard 同源） |
| 柱色（广告） | `#4080FF` |
| 柱色（其他） | `#E2E5EA`，顶部圆角 4px |
| 折线色 | `#E37318`（广告转化占比） |
| 柱最大宽度 | 24px |
| 默认高度 | 320px（启用 zoom 时 370px） |
| 双 Y 轴 | 左：人数；右：百分比（`formatter: (v) => ${(v*100).toFixed(0)}%`） |

## Do / Don't

- ✅ 数据超 15 条自动 zoom，避免柱体挤成一片
- ✅ `tips` 显示为虚线下划线的 title 提示（workshop 里 SectionCard 风格）
- ✅ 数据归一化在组件内部（占比 = conv_uv / (conv_uv + other_conv_uv)），使用方只传原始值
- ❌ 不要把 `conv_uv` 和 `other_conv_uv` 的语义改成"今/昨"或"本品/竞品"——那是别的产品问题
- ❌ 不要改双 Y 轴方向（左人数右百分比是业务约定）
- ❌ 不要给柱体加入场动画

## 使用示例（workshop import）

```jsx | pure
import { ConversionTrend } from '../../references/blocks/conversion-trend';

// workshop 内直接传接口数据
<ConversionTrend items={cd?.daily_trend?.items ?? []} />
```

## 完整实现代码

生成代码时，**必读** [`../references/conversion-trend.tsx`](../references/conversion-trend.tsx)。workshop `conversion-review` 通过 `import { ConversionTrend }` 直接复用本区块。

## slug: crowd-bar-chart

# 人群渗透柱状图 crowd-bar-chart

单柱渗透率图表，每柱一个人群维度 + 品牌历史均值基准线，hover 柱体弹出对比详情卡片。

## 产品问题（何时用）

**解决什么**：以单柱形式展示每个人群维度的渗透率，配合"品牌历史均值"基准线，用户快速判断"当前投放在哪些人群上超/不及历史水平"。hover 柱体弹详情卡对比具体差值。

**出现页面**：
- 如翼 > 全域度量 > [转化复盘 conversion-review](/workshop/conversion-review?fullscreen=1) · 详情

**典型信号**：需求里出现"单柱渗透率"、"带基准线"、"每人群维度一柱"、"hover 对比历史均值"时使用。

## 不要用本区块的场景

- 人群排名 + 联动图 → 用 `crowd-table-view`（L3）
- 堆叠柱 + 折线双轴 → 用 `conversion-trend`（L3）

## 适用页面

- 如翼 > 策略应用 > 转化复盘 > 详情页 · 资产广度 Tab
- 如翼 > 人群策略 > 推荐人群 > 人群渗透分析

## 交互状态

| 状态 | 行为 |
| --- | --- |
| default | 所有柱体满透明度，基准线可见 |
| hover 柱体 | 当前柱满透明度，其余 `opacity-40`；弹出右侧详情卡 |
| Tooltip 内容 | 人群名 → 渗透率表头 → 本品历史均值 + 曝光渗透率 → 分割线 → 对比差值（绿高/红低） |

## 变体

| 变体 | 说明 | 适用场景 |
| --- | --- | --- |
| 默认 | 单柱 + 基准线 | 人群渗透率分析 |

## 数据结构

```typescript
interface BarItem {
  label: string;      // 人群名称（支持 \n 换行）
  value: number;      // 曝光人群渗透率
  benchmark: number;  // 品牌历史均值
}
```

## 规则

- DO：柱体 hover 时降低其他柱透明度至 40%，突出当前柱
- DO：Tooltip 从柱体右侧弹出（`placement="right-start"`）
- DO：数值保留两位小数（`.toFixed(2)`）
- DO：基准线用实色 2px 线（`border-t-2 border-black-12`），每柱独立
- DO：Popover 使用受控模式 `open={isHovered}` + 透明容器样式 `!p-0 !border-0 !shadow-none !bg-transparent`
- DO：Tooltip 底注使用 10px 小字标注与历史均值的对比差异
- DON'T：不要给柱体加入场动画（仅透明度过渡 `transition-opacity`）
- DON'T：不要在柱体上方显示数值标签
- DON'T：不要使用第三方图表库

## 完整实现代码

生成代码时，**必读** [`../references/crowd-bar-chart.tsx`](../references/crowd-bar-chart.tsx)。该文件是本区块的完整参考实现，禁止凭本文的结构描述自行猜测实现，应以 references 中的代码为基准进行复用或裁剪。

## slug: crowd-card-list

# 人群列表 crowd-card-list

推荐人群多视图列表，支持卡片视图（3列网格）和表格视图（多列排序+分页）。外层浅灰底承载的白色面板；工具栏分两层：第一层是分类 Tab + 搜索 + 视图切换；第二层是行业筛选 Chips + 排序选择器。

## 产品问题（何时用）

**解决什么**：在推荐人群市场场景下提供 **3 种视图模式** 的完整人群管理列表——卡片网格（3 列，结构化标签）/ 表格（排序 + 分页） / 简版卡片。用户在"探索 + 筛选 + 操作"之间自由切换。

**出现页面**：
- 如翼 > 人群策略 > [推荐人群市场 r0-audience-market](/workshop/r0-audience-market?fullscreen=1)

**典型信号**：需求里出现"多视图切换（卡片/表格）"、"人群市场"、"行业筛选 Chips + 排序 Select"时使用。

## 不要用本区块的场景（L3 强制）

- **候选池挑选场景**（4 列卡片，外层 Tab/分类/搜索/分页由使用方编排）→ 用 `crowd-pick-card-grid`（L2，3 个推荐人群页都用它）
  - 两者区别：`crowd-card-list` 是**管理视角**（多视图、行业筛选、排序），`crowd-pick-card-grid` 是**选择视角**（纯卡片网格，外层由业务自编排）
- 单列排名 → 用 `ranking-list`（L2）
- 右侧详情面板 → 用 `crowd-detail-panel`（L3）
- Master-Detail 左侧任务列表 → 用 `report-list`（L3）

## 适用页面

- 人群策略 > 推荐人群 > 推荐人群市场（卡片视图、表格视图）

## 交互状态

| 状态 | 行为 |
| --- | --- |
| default | 外层 `bg-[#f2f4f9] p-6`，内层 `rounded-[12px]` 白色面板 |
| 卡片 default | 白色卡片，`border-black-4` 边框 |
| hover（卡片） | 添加 `shadow-sm` 阴影 |
| 收藏激活 | 星标变为 `orange-6` 色 |
| 视图切换 | 当前视图按钮 `bg-black-4` 高亮 |
| 行业 Chip 选中 | `bg-blue-1 text-blue-6 font-semibold` |
| Tab 切换 | 切换分类筛选数据，"我的收藏"仅显示已收藏项 |
| 表格排序 | 点击表头切换排序列和升降序，蓝色箭头指示方向 |
| 搜索 | 实时过滤人群名称 |
| 行业筛选 | 点击 Chip 按行业标签过滤 |
| 排序预设 | 三种预设排序（覆盖重叠/规模/相似度） |
| 表格翻页 | `Pagination` 切换页码 |

## 变体

| 变体 | 说明 | 适用场景 |
| --- | --- | --- |
| 卡片视图 | 3 列网格，每张卡含名称、标签、R3 流入率、渗透率、规模、收藏 | 概览浏览 |
| 表格视图 | 8 列可排序数据表格 + 收藏 + 分页 | 精确数据对比 |

## 数据结构

```typescript
type TagType = 'hot' | 'view' | 'new' | 'industry';

interface CrowdItem {
  id: string;
  name: string;
  description?: string;
  tags: { label: string; type: TagType }[];
  coverageWan: number;
  penetration: number;
  r3Inflow: number;
  adCount: number;
  insightCount: number;
  updatedAt: string;
  launchedAt: string;
  starred: boolean;
}

type SortKey = 'name' | 'coverageWan' | 'penetration' | 'r3Inflow'
  | 'adCount' | 'insightCount' | 'updatedAt' | 'launchedAt';
type SortDir = 'asc' | 'desc';
type ViewMode = 'card' | 'table';
```

## 规则

- DO：外层使用 `bg-[#f2f4f9] p-6` 浅灰底承载，内层是 `rounded-[12px]` 的白色 Card 面板
- DO：工具栏分两层——第一层左分类 Tab / 右搜索 + 视图切换；第二层左行业 Chips / 右排序 Select
- DO：两种视图共享同一个工具栏，通过视图切换按钮切换
- DO：视图切换按钮两个一组（`menu`=表格, `card-distribute`=卡片），当前激活 `bg-black-4`
- DO：表格视图支持列排序（点击表头切换），排序箭头激活为蓝色
- DO：表格视图底部使用 `Pagination` 组件分页，`showTotal` 显示总数
- DO：收藏功能跨视图同步，使用 `Set<string>` 管理收藏 ID
- DO：标签使用 `TagBadge` 组件，四种颜色对应四种类型
- DO：排序预设和列排序互斥，列排序优先级更高
- DO：行业 Chips 平铺在第二层，选中态蓝色背景
- DON'T：不要再保留第三个简版（compact）视图切换按钮
- DON'T：不要把搜索和视图切换放到分类 Tab 的同一行下方——它们应该与 Tab 同处第一层
- DON'T：不要忘记"我的收藏"Tab 的过滤逻辑
- DON'T：不要混淆排序预设 Select 和表头列排序的优先级关系
- DON'T：不要在卡片视图中显示分页组件

## 完整实现代码

生成代码时，**必读** [`../references/crowd-card-list.tsx`](../references/crowd-card-list.tsx)。该文件是本区块的完整参考实现，禁止凭本文的结构描述自行猜测实现，应以 references 中的代码为基准进行复用或裁剪。

## slug: crowd-detail-panel

# 人群详情面板 crowd-detail-panel

展示单个人群包的完整详情信息，包含基本信息、属性标签、人群描述、人群规则和授权记录。

## 状态标注（L3，未在 workshop 复用）

> **本区块目前没有出现在任何已落地的 workshop 页面**。保留在 L3 层作为"人群详情侧边面板"的设计规格档案，用于未来右侧 Master-Detail 场景的参考。

## 产品问题（何时用）

**解决什么**：在 Master-Detail 布局中作为右侧详情面板，展示当前选中人群的基本信息、属性标签、规则、授权记录等结构化元数据。

**典型信号**：需求里出现"右侧详情面板"、"人群元数据"、"基本信息 + 属性标签 + 规则 Tab"时使用。

## 不要用本区块的场景

- 左侧方案列表 → 用 `report-list`（L3）
- 右侧的复盘多 Tab 内容 → 用 `review-master-detail-layout`（L1）的 children slot
- 卡片网格式的详情 → 用 `crowd-pick-card-grid`（L2）

## 适用页面

- 人群列表页（右侧详情面板）
- 人群详情弹窗
- 任何需要展示人群包信息的场景

## 交互状态

| 状态 | 标签文字 | 背景色 | 边框色 | 文字色 |
|------|---------|--------|--------|--------|
| online | 在线 | #f3fcf7 | #cdf3df | #07c160 |
| computing | 计算中 | blue-1 | blue-3 | blue-6 |
| offline | 离线 | black-2 | black-5 | black-9 |
| expired | 已过期 | red-1 | red-3 | red-6 |

## 数据结构

```typescript
interface CrowdRule {
  title: string;
  details: { label: string; value: string }[];
}

interface CrowdDetail {
  name: string;
  status: 'online' | 'computing' | 'offline' | 'expired';
  crowdId: string;
  createdAt: string;
  scale: number;
  tags: string[];
  description: string;
  rules: CrowdRule[];
}
```

## 完整实现代码

生成代码时，**必读** [`../references/crowd-detail-panel.tsx`](../references/crowd-detail-panel.tsx)。该文件是本区块的完整参考实现，禁止凭本文的结构描述自行猜测实现，应以 references 中的代码为基准进行复用或裁剪。

## slug: crowd-pick-card-grid

<!-- metadata
nav:
  title: 区块
  order: 3
group:
  title: 通用业务区块 (L2)
  order: 2
title: 人群精选卡片网格
subtitle: CrowdPickCardGrid
description: '在"从候选池挑选人群走下一步"的场景下使用的 4 列卡片网格，出现在行业优选/兴趣精选/主题甄选等推荐人群页。'
order: 1
prompt: '人群精选卡片网格区块。4 列卡片网格，每张卡片含名称+对比链接+热度火苗+描述+4 列指标(覆盖人数/R3流入率/人群渗透率/使用频次)+最后更新时间。外层的 Tab/分类筛选/搜索/分页由使用方编排。'
skill: crowd-pick-card-grid
-->

## 产品问题（何时用）

**解决什么**：平台预设了一组候选人群，用户通过某个维度筛出 N 个卡片从中挑选应用到投放。

**出现页面**：
- 如翼 > 人群策略 > [行业优选](/workshop/r-zero-crowd?fullscreen=1)
- 如翼 > 人群策略 > [兴趣精选](/workshop/interest-preference-crowd?fullscreen=1)
- 如翼 > 人群策略 > [主题甄选](/workshop/theme-selection-crowd?fullscreen=1)

**典型信号**：需求中出现"从候选池里挑"、"推荐列表"、"选人群用于投放"、"精选卡片"时，应优先考虑本区块。

## 变体决策（L2 强制）

本区块的"卡片本身"在三个页面中 100% 一致；**变体体现在外层编排**（Tab / 分类筛选 / 搜索 / 分页组合方式）：

| 变体 | 外层编排 | 出现页面 | 产品问题细化 |
|------|---------|---------|-------------|
| `行业 Tab + 行业分类` | 顶部 Tab（行业热门/跨行推荐）+ 行业分类筛选 + 分页 | 行业优选 | 按"行业"切入选择 |
| `搜索 + 分页` | 搜索框 + 分页（无 Tab / 无分类） | 兴趣精选 | 按"兴趣关键词"自由搜索 |
| `搜索 + 分页` | 搜索框 + 分页（结构同上，数据不同） | 主题甄选 | 按"主题营销场景"搜索 |

**选择准则**：
- 需求描述里强调"按行业/品类看" → 用 Tab + 分类筛选
- 需求描述里强调"关键词查找/自由浏览" → 用搜索 + 分页
- 需求描述里强调"有限的主题活动" → 搜索 + 分页（可选省略搜索改为纯分页）

**不要用本区块的场景**：
- 管理视角（增删改查） → 用 `crowd-card-list`（人群列表的 3 种视图模式）
- 对比分析视角 → 用 `crowd-table-view`（人群对比表格）
- 只显示 1-2 张卡片的摘要 → 直接用 Card 组件

## 预览

<code src="../../references/crowd-pick-card-grid.tsx"></code>

## API

```typescript
import { CrowdPickCardGrid, type CrowdPickCard } from 'references/blocks/crowd-pick-card-grid';

interface CrowdPickCardGridProps {
  cards: CrowdPickCard[];              // 卡片数据
  onCardClick?: (card) => void;        // 卡片点击
  onCompareClick?: (card, e) => void;  // 对比链接点击
  metricKeys?: Array<{ label; key }>;  // 指标列配置（默认 4 列）
  columns?: 2 | 3 | 4;                 // 栅格列数（默认 4）
  className?: string;
}

type CrowdPickCard = {
  name: string;        // 人群名称
  desc: string;        // 人群描述
  heat: number;        // 热度 1-3
  coverage: string;    // 覆盖人数（已格式化）
  r3Rate: string;      // R3 流入率
  penetration: string; // 人群渗透率
  frequency: string;   // 使用频次
  updatedAt: string;   // 最后更新时间
};
```

## 组件构成

| 元素 | 组件 | 说明 |
| ---- | ---- | ---- |
| 外层网格 | 原生 `<div>` + Tailwind grid | `grid-cols-4 gap-4`，也可 2/3 列 |
| 卡片 | 原生 `<div>` | `p-4 border border-black-6 rounded-xl` + hover/active 交互 |
| 名称 + 对比链接 | 原生 `<div>` + 文本 | 名称 14px semibold（truncate），对比链接 12px blue-6 |
| 热度火苗 | `Icon` | `name="flame"` size=14 `color="var(--odn-color-orange-6)"`，数量 = heat 值 |
| 描述 | 原生 `<div>` | 12px `text-black-10`，单行 truncate |
| 指标区 | 4 列 grid | 12px，上 label `text-black-9`、下 value `text-black-11`，全部 truncate |
| 更新时间 | 原生 `<div>` | 12px `text-black-9`，"最后更新时间：YYYY-MM-DD" |

## 设计规格

| 属性 | 值 |
| ------ | --------------------- |
| 卡片内边距 | `p-4` |
| 卡片圆角 | `rounded-xl`（12px） |
| 卡片边框 | `border border-black-6` |
| 卡片 hover | `hover:bg-black-1` |
| 卡片 active | `active:bg-black-2` |
| 网格间距 | `gap-4`（16px） |
| 名称字号 | `text-sm font-semibold`（14px） |
| 对比链接字号 | `text-xs text-blue-6`（12px） |
| 描述字号 | `text-xs text-black-10`（12px） |
| 火苗间距 | `gap-0.5 mr-2` |
| 指标区上下边距 | `my-2` |
| 指标列间距 | `gap-x-4 gap-y-1.5` |

## 交互状态

| 状态 | 行为 |
| ------- | ---- |
| default | 静态渲染 |
| hover | 整张卡片背景 `hover:bg-black-1` |
| active | 整张卡片背景 `active:bg-black-2` |
| 对比链接点击 | `stopPropagation` 阻止卡片点击，触发 `onCompareClick` |

## Do / Don't

- ✅ 可以通过 `metricKeys` 自定义指标列（默认 4 列，但在某些场景可换顺序或换字段）
- ✅ 可以降级为 2 列或 3 列（小容器内）
- ❌ 不要在卡片里加第 5 个指标列——会破坏节奏
- ❌ 不要把本区块用于"管理视角"（增删改查）——那是 `crowd-card-list` 的职责
- ❌ 不要改卡片的基础信息段（名称/对比/热度/描述）——三个 workshop 页面一致才是这个区块的价值

## 使用示例（workshop import）

```tsx
import {
  CrowdPickCardGrid,
  type CrowdPickCard,
} from '../../references/blocks/crowd-pick-card-grid';

// 在 workshop 内组织自己的 Tab / 搜索 / 分页逻辑
<CrowdPickCardGrid
  cards={pageCards}
  onCardClick={(card) => console.log('select', card.name)}
  onCompareClick={(card) => console.log('compare', card.name)}
/>
```

## slug: crowd-table-view

# 人群对比视图 crowd-table-view

左侧人群排名表格（含进度条和选中态），右侧按资源触点拆解的柱状图，点击左侧行联动右侧图表。

## 产品问题（何时用）

**解决什么**：左侧给出人群的排名表（进度条让对比一目了然），右侧把选中人群的"资源触点"拆解为柱状图。用户点击左侧行，右侧联动切换。

**出现页面**：
- 如翼 > 全域度量 > [转化复盘 conversion-review](/workshop/conversion-review?fullscreen=1) · 详情

**典型信号**：需求里出现"人群排名 + 联动柱状图"、"点击行切换右侧图"、"触点拆解"时使用。

## 不要用本区块的场景

- 纯排名（无联动图表） → 用 `ranking-list`（L2）或 `dual-ranking-list`（L3）
- 单柱渗透率分析 → 用 `crowd-bar-chart`（L3）
- 人群卡片网格 → 用 `crowd-pick-card-grid`（L2）

## 适用页面

- 如翼 > 策略应用 > 转化复盘 > 详情页 · 资产广度 Tab

## 交互状态

| 状态 | 行为 |
| --- | --- |
| default | 第一行选中 `bg-blue-1`，右侧展示对应人群的触点拆解 |
| click 行 | 切换选中行，右侧图表联动刷新 |
| hover 行 | 非选中行背景变 `bg-black-1` |
| hover 柱体 | 当前柱满透明度，其余 `opacity-40`，弹出 Popover（`open={isHovered}`） |
| leave 柱体 | 恢复全部满透明度，关闭 Popover |

## 变体

| 变体 | 说明 | 适用场景 |
| --- | --- | --- |
| 默认 | 左表右柱联动 | 转化复盘详情页 |

## 数据结构

```typescript
interface CrowdRow {
  name: string;     // 人群名称
  count: number;    // 未曝光人数
  ratio: number;    // 在 R0 中占比
}

interface TouchpointBar {
  label: string;    // 触点名称（支持 \n 换行）
  value: number;    // 人数
}
```

## 规则

- DO：左侧表格固定 304px，右侧图表 `flex-1` 自适应
- DO：进度条颜色 `#6997f4` 与柱状图颜色保持一致
- DO：Popover 使用 ODN `Popover` 组件，受控模式 `open={isHovered}`
- DO：Popover 弹出方向 `placement="right-start"`
- DO：Y 轴标签右对齐，X 轴标签居中于柱体
- DO：数值使用 `tabular-nums` 等宽数字
- DON'T：不要在左侧使用 ODN `Table` 组件
- DON'T：不要用第三方图表库
- DON'T：不要给柱体加入场动画（仅透明度过渡）

## 完整实现代码

生成代码时，**必读** [`../references/crowd-table-view.tsx`](../references/crowd-table-view.tsx)。该文件是本区块的完整参考实现，禁止凭本文的结构描述自行猜测实现，应以 references 中的代码为基准进行复用或裁剪。

## slug: crystal-ball

# 水晶球 · 人群洞察 crystal-ball

人群洞察水晶球同心圆放射图，6 个扇区维度展示 TA% 和 TOP 达人数据，底部洞察结论展示人群画像标签。

## 状态标注（L3，无 workshop 实现）

> **本区块目前没有出现在任何 workshop 页面**，是直接从 Figma 设计稿开发的独立实现。保留在 L3 层作为"设计规格档案"，第二个使用场景出现时再决定是否抽离 API。

## 产品问题（何时用）

**解决什么**：以同心圆放射图为主视觉的人群画像洞察区块。扇区按维度切片（如兴趣 / 消费力 / 地域），同心圆按深浅表示 TA% 密度。

**典型信号**：需求里明确提到"水晶球"、"同心圆放射图"、"人群画像 + 洞察结论卡"时使用。

## 不要用本区块的场景

- 四象限散点 → `quadrant-scatter`（资产变体或心智 `MatrixScatterChart` 变体）
- 普通人群列表 → 用 `crowd-card-list` / `crowd-pick-card-grid`

## 适用页面

- SPU 人群资产 · 人群洞察
- 如翼 > 洞察诊断 > 品牌心智度量
- 如翼 > 洞察诊断 > 心智详情 – 本品牌（✅ `mindshare-detail`）

## 交互状态

| 状态 | 行为 |
| --- | --- |
| 扇区 default | 所有数据点正常颜色 |
| 扇区 hover | 扇区背景高亮 `rgba(41,107,239,0.06)`，扇区名变蓝 `blue-6`，非活跃扇区数据点淡化；弹出 Popover |
| 数据点 hover | 数据点放大 r=6，同时触发对应扇区高亮 |
| Popover 高亮行 | hover 的数据点在 Popover 中对应行 `bg-blue-1 font-semibold` |
| Popover 离开 | 200ms 延迟关闭，支持鼠标移入 Popover 保持显示 |
| 添加人群 hover | 按钮背景 `bg-black-1 → bg-black-2` |
| 操作链接 hover | 显示下划线 |

## 变体

| 变体 | 说明 | 适用场景 |
| --- | --- | --- |
| 完整模式 | 水晶球 + 洞察结论卡片 | 人群洞察完整展示 |
| 仅水晶球 | 只有同心圆放射图 | 独立使用 |
| 仅洞察结论 | 只有结论卡片 | 搭配其他图表 |

## 数据结构

```typescript
interface SectorChild {
  name: string;
  ta: number;
}

interface TopIP {
  name: string;
  rank: number;
}

interface Sector {
  name: string;
  ctaLabel: string;
  children: SectorChild[];
  topIPs: TopIP[];
}

interface InsightRow {
  category: string;
  tags: string[];
}

interface ActionLink {
  label: string;
  href?: string;
}
```

## 规则

- DO：使用 SVG 绘制同心圆和扇区，数据点使用极坐标定位
- DO：扇区 hover 使用 200ms 延迟关闭，支持鼠标从扇区移动到 Popover
- DO：数据点 hover 时放大并联动扇区高亮
- DO：非活跃扇区的数据点颜色降至 `rgba(41,107,239,0.18)`
- DO：Popover 中高亮行用 `bg-blue-1 font-semibold` 标识
- DO：TOP IP 排名使用金/银/铜渐变文字
- DO：洞察结论左标签使用蓝色渐变背景 `from-[#e5eeff] to-[#f7f9fc]`
- DON'T：不要用 canvas 或第三方图表库画水晶球
- DON'T：不要把所有 Select 合并为一个复合筛选器
- DON'T：不要给 SVG 动画添加过重的 transition

## 完整实现代码

生成代码时，**必读** [`../references/crystal-ball.tsx`](../references/crystal-ball.tsx)。该文件是本区块的完整参考实现，禁止凭本文的结构描述自行猜测实现，应以 references 中的代码为基准进行复用或裁剪。

## slug: dual-ranking-list

# 双列排名榜 dual-ranking-list

品牌/行业维度左右对比排名，当前 SPU 蓝色高亮置顶，趋势用绿色↑/红色↓标记。

## 产品问题（何时用）

**解决什么**：把"本品牌"和"本行业"作为两个并列的榜单左右对比展示，让用户一眼看到自家 SPU 在两个维度下的相对排位与趋势。

**出现页面**：
- 如翼 > 洞察诊断 > [商品人群资产 spuAudienceAsset](/workshop/spuAudienceAsset?fullscreen=1)

**典型信号**：需求里出现"本品牌 vs 本行业"、"双列对比排名"、"SPU 高亮对比"时使用。

## 不要用本区块的场景

- 单列榜单 → 用 `ranking-list`（L2）的 `BrandRanking` 变体
- 横向的子弹图对比 → 用 `penetration-analysis`（L2）
- 榜单要带联动图表 → 用 `crowd-table-view`（L3）

## 适用页面

- SPU 人群资产（✅ `spu-crowd-asset`）（资产排名、渗透率排名、R3 流入率排名）

## 交互状态

| 状态 | 行为 |
| --- | --- |
| default | 当前 SPU 高亮置顶，其余按排名顺序排列 |
| 趋势上升 | 绿色 ↑ + 变化数值 |
| 趋势下降 | 红色 ↓ + 变化数值 |
| 趋势不变 | 不显示趋势标记（`trend === 0` 返回 null） |

## 变体

| 变体 | 说明 | 适用场景 |
| --- | --- | --- |
| 人群总资产榜 | 标题含「人群总资产」关键词 | 资产概览 |
| R1~R5 人群资产榜 | 标题含「R1 人群资产」等关键词 | 资产分析（按 5R 阶段） |
| 渗透率榜 | 标题含「渗透率」关键词 | 渗透分析 |
| R3 流入率榜 | 标题含「R3 流入率」关键词 | R3 流入分析 |

## 数据结构

```typescript
interface RankingItem {
  rank: number;
  name: string;
  trend: number;
  isCurrent?: boolean;
}

interface RankingListProps {
  title: React.ReactNode;
  items: RankingItem[];
}
```

## 规则

- DO：当前 SPU（`isCurrent: true`）始终置顶，蓝色背景 `bg-[#e8f4ff]` 高亮
- DO：高亮行下方有分隔线 `border-b border-solid border-[#f0f0f0]`，与普通行区分
- DO：趋势数字用 `tabular-nums`，正数绿 + ↑，负数红 + ↓，零值不显示
- DO：排名序号固定宽度 `w-5`、居中对齐
- DO：左右两列标题结构对称，仅「品牌/行业」关键字不同
- DON'T：不使用任何 ODN 组件，此区块为纯 HTML/CSS 实现
- DON'T：普通行只展示 TOP 3~5，不要展示过多行
- DON'T：标题中的动态关键词必须用 `font-medium text-[#1a1a1a]` 高亮，不可全部灰色

## 完整实现代码

生成代码时，**必读** [`../references/dual-ranking-list.tsx`](../references/dual-ranking-list.tsx)。该文件是本区块的完整参考实现，禁止凭本文的结构描述自行猜测实现，应以 references 中的代码为基准进行复用或裁剪。

## slug: metric-card-group

<!-- metadata
nav:
  title: 区块
  order: 3
group:
  title: 通用业务区块 (L2)
  order: 2
title: 资产指标卡组
subtitle: MetricCardGroup
description: '5R 人群资产指标（总资产+R1~R5+分布条+排名榜）与人群流转指标（拉新/蓄水/种草可选卡片）的组合面板。'
order: 4
prompt: '5R 人群资产指标卡组区块。上方 6 指标卡+分布条+双列排名；下方 3 张可选流转卡（拉新/蓄水/种草）。出现在品牌人群资产/SPU 人群资产页。'
skill: metric-card-group
-->

# 资产指标卡组 metric-card-group

## 产品问题（何时用）

**解决什么**：一眼看到品牌/SPU 的 5R 资产整体盘面 —— 总资产有多大、R1~R5 各阶段怎么分布、头部品牌/SPU 是谁。配合下方的"流转指标卡"，还能选择特定流转维度（拉新/蓄水/种草）联动下方分析。

**出现页面**：
- 如翼 > 洞察诊断 > [品牌人群资产 brand5r](/workshop/brand5r?fullscreen=1)
- 如翼 > 洞察诊断 > [商品人群资产 spuAudienceAsset](/workshop/spuAudienceAsset?fullscreen=1)

**典型信号**：需求中出现"5R 人群资产"、"指标总览卡组"、"R1~R5 分布"、"品牌/SPU 资产概览"时优先使用。

## 变体决策（L2）

| 变体 | 结构 | 产品问题 | 出现页面 |
|------|------|---------|---------|
| 5R 资产概览面板 | 6 指标卡 + 彩色分布条 + 双列排名 | 展示品牌/SPU 的 5R 盘面 | brand5r / spuAudienceAsset |
| 流转概览面板 | 3 张可选中流转卡（拉新/蓄水/种草）| 切换流转维度驱动下方分析 | brand5r / spuAudienceAsset |
| 组合使用 | 两面板纵向排列 | 完整指标区（带流转切换） | SPU 人群资产页 |

**选择准则**：
- 只需要"盘面一览" → 单用 5R 资产概览
- 需要切换流转维度驱动下方联动 → 加上流转概览
- 联动目标通常是：渗透分析 / 四象限散点 / 桑基图

**不要用本区块的场景**：
- 心智指标（心智量/心智份额）→ 用 `metrics-overview`（双指标卡 + 分布条 + 双轴趋势）
- 转化指标（广告转化/转化率）→ 用 `conversion-metrics`（6 宫格 + 环形图）
- 自定义 N 张并列指标卡 → 直接用 ODN Card 组件，不抽区块

## 适用页面

- 品牌人群资产（✅ `brand-crowd-asset`）
- SPU 人群资产（✅ `spu-crowd-asset`）

## 交互状态

| 状态 | 行为 |
| --- | --- |
| default | 上方 6 张 5R 指标卡 + 分布条 + 双列排名；下方 3 张流转卡，首个默认选中 |
| hover（分布条） | 显示浮层：5R 占比详情（白底圆角卡片，boxShadow 浮层） |
| hover（流转卡） | 未选中卡片背景变为 `bg-solid-black-2` |
| active/selected（流转卡） | `bg-blue-1` + `border-blue-6` 蓝色高亮 |
| hover（图标按钮） | 图标颜色从 `text-black-8` → `text-black-11` |

## 数据结构

```typescript
interface MetricItem {
  label: string;
  value: string;
  unit: string;
  colorVar: string;
  comparison: string;
  percentage: string;
}

interface RankItem {
  rank: number;
  name: string;
  trend: number;
  isCurrent?: boolean;
}

interface FlowMetric {
  key: string;
  label: string;
  subtitle: string;
  value: string;
  comparison: 'above' | 'below';
  comparisonLabel: string;
  percentage: string;
}

const R5_COLORS = {
  total: 'var(--odn-color-black-12)',
  r1: 'var(--odn-color-blue-5)',
  r2: '#35AFFF',
  r3: '#00C7BE',
  r4: '#95D609',
  r5: '#FFC300',
};
```

## Do / Don't

- ✅ 指标卡使用 `flex-1 min-w-0` 等宽均分
- ✅ 数字使用 `tabular-nums` 确保等宽对齐
- ✅ 大数字使用千分位格式（`89,267,538`）
- ✅ 分布条紧贴指标卡底部，每段使用对应 R5_COLORS 色值
- ✅ 分布条中小于 1% 的段设置 `minWidth: 4` 确保可见
- ✅ 排名当前项使用 `bg-blue-1` + `text-blue-6` 蓝色高亮并用分割线与其他项分隔
- ✅ 流转卡使用 `useState` 控制选中态，同时只高亮一张
- ❌ 不要给每个 5R 指标卡加独立边框，使用平铺布局
- ❌ 首张「人群总资产」卡不显示颜色圆点
- ❌ 趋势为 0 时不显示 TrendBadge

## 完整实现代码

生成代码时，**必读** [`../references/metric-card-group.tsx`](../references/metric-card-group.tsx)。该文件是本区块的完整参考实现，禁止凭本文的结构描述自行猜测实现，应以 references 中的代码为基准进行复用或裁剪。

## slug: metrics-overview

# 心智概览面板 metrics-overview

## 产品问题（何时用）

**解决什么**：品牌在行业里的"心智面"概览 —— 品牌心智量有多少、行业份额占多少，配合分布条看分类构成，配合双轴趋势看时间变化。

**出现页面**：
- 如翼 > 洞察诊断 > [品牌心智度量](/workshop/brand-mind-dashboard?fullscreen=1)
- 如翼 > 洞察诊断 > [心智详情 – 本品牌](/workshop/mindshare-detail?fullscreen=1)

**典型信号**：需求中出现"心智量"、"心智份额"、"双轴趋势"、"心智分布"时，应优先考虑本区块。

## 变体决策（L2）

| 变体 | 说明 | 产品问题细化 | 适用场景 |
|------|------|-------------|---------|
| 双指标（默认） | 品牌心智量 + 行业份额，竖分割线分隔 | 全面对比本品牌与行业份额 | 品牌心智度量主页 |
| 带排名 | 行业份额含排名 + 排名变化 + "查看榜单"链接 | 强调在行业里的排位 | 行业对比场景 |
| 单指标 | 仅品牌心智量，无竖分割线 | 只关心本品牌自己的量 | 心智详情页简化展示 |

**选择准则**：
- 关心行业对比 → 双指标 / 带排名
- 只看自己 → 单指标
- 需要明确排位 → 带排名

**不要用本区块的场景**：
- 转化/投放指标 → 用 `conversion-metrics`
- 5R 资产指标 → 用 `metric-card-group`
- 只是单个大数字 → 直接用 Card + 自定义 layout

## 适用页面

- 如翼 > 洞察诊断 > 品牌心智度量（✅ `brand-mind-dashboard`）
- 如翼 > 洞察诊断 > 心智详情 – 本品牌（✅ `mindshare-detail`）
- 如翼 > 洞察诊断 > 心智详情 – 本行业

## 交互状态

| 状态 | 行为 |
| --- | --- |
| default | 标题展示时间范围 "YYYY-MM-DD 至 YYYY-MM-DD 心智概览"，所有数据点显示 r=3 小圆点 |
| hover 趋势图数据点 | 垂直虚线 + 双圆点放大（r=4.5）+ Tooltip 浮层（日期+品牌心智量+行业份额） |
| mouseLeave 趋势图 | 标题恢复为时间范围，Tooltip 消失，圆点恢复 r=3 |
| 底部按钮 hover | 文字从 `text-blue-6` → `text-blue-7` |

## 变体

| 变体 | 说明 | 适用场景 |
| --- | --- | --- |
| 双指标（默认） | 品牌心智量 + 行业份额，竖分割线分隔 | 品牌心智度量主页 |
| 带排名 | 行业份额含排名 + 排名变化 + "查看榜单"链接 | 行业对比场景 |
| 单指标 | 仅品牌心智量，无竖分割线 | 心智详情页简化展示 |

## 数据结构

```typescript
interface MetricData {
  label: string;
  value: string;
  change: number;
  refLabel: string;
  refValue: string;
  rank?: number;
  rankChange?: number;
  dotColor: string; // Tailwind class，如 'bg-blue-6'
}

interface DistSegment {
  label: string;
  percent: number;
  color: string;   // Tailwind class，如 'bg-[#aade3a]'
  dotColor: string; // 图例色块 class
}

interface TrendPoint {
  date: string;
  value: number;
  share: number;
}
```

## 规则

- DO：使用 `Card elevation={0}` 组件包裹整个面板，设置 `[--odn-card-radius:12px]`
- DO：Card 外层使用 `bg-[#f2f5fa] rounded-xl p-6` 模拟页面底色，形成前景/背景分离
- DO：标题栏根据 `hoveredIdx` 是否为 null 切换显示时间范围或具体日期
- DO：指标数值使用 `tabular-nums` + 千分位格式
- DO：色点使用 `backgroundClip: 'content-box'` + `padding: '2px'` 实现中空效果
- DO：变化率正值用 green-7 + arrow-up，负值用 red-7 + arrow-down（中式涨跌色）
- DO：分布条各段使用 `width: ${percent}%` 按真实比例渲染
- DO：趋势图使用统一 SVG viewBox（756×192），`PAD_T=16` 预留轴标题空间
- DO：趋势图通过 `PAD_L=54, PAD_R=54, CHART_W=648, CHART_H=152` 精确定义绘图区边界
- DO：趋势折线使用 `strokeLinejoin="round"` + `strokeLinecap="round"` 实现圆润拐角
- DO：网格线颜色使用 `var(--odn-color-black-3)` / 底线使用 `var(--odn-color-black-5)`
- DO：网格线使用 `shapeRendering="crispEdges"` 实现像素锐利渲染
- DO：SVG 文字使用 `style={{ fontSize: N }}` 而非 Tailwind class，确保跨浏览器一致
- DO：Y 轴格式化使用「万」为单位（如"500万"），避免 `toLocaleString()` 的 locale 差异
- DO：所有数据点常态显示 r=3 小圆点，hover 时放大到 r=4.5，白色描边区分
- DO：hover 时显示 HTML Tooltip 浮层（日期 + 双指标数值 + 色点图例），跟随数据点位置
- DO：Tooltip 在图表右侧边缘时自动翻转方向，避免溢出
- DO：X 轴标签使用 `getVisibleXLabels()` 等间距策略（首尾 + step=3）
- DO：趋势图使用 SVG polyline，通过透明 rect 实现逐点 hover 检测
- DO：两个指标间使用 `w-px self-stretch bg-black-5` 竖分割线
- DON'T：不要在外容器加边框，只在内卡加 `border-black-6`
- DON'T：hover 圆点不能遮挡趋势线，使用白色描边区分
- DON'T：不要用 Tailwind className 设置 SVG text 字号（在部分浏览器不生效）
- DON'T：不要用 `toLocaleString()` 格式化 Y 轴数字（locale 不稳定）
- DON'T：不要用硬编码 rgba 颜色，网格线/轴标签色均使用 `var(--odn-color-*)` token

## 完整实现代码

生成代码时，**必读** [`../references/metrics-overview.tsx`](../references/metrics-overview.tsx)。该文件是本区块的完整参考实现，禁止凭本文的结构描述自行猜测实现，应以 references 中的代码为基准进行复用或裁剪。

## slug: mindshare-dictionary

# 心智词典 mindshare-dictionary

品牌心智词典面板，左右双栏展示热门搜索词排名（柱状图 + 数值）和多层级词云分布图。

## 产品问题（何时用）

**解决什么**：在品牌心智场景下同时呈现"结构化的热词榜"（左）和"权重分布式词云"（右）。一侧精确看数值和排名，另一侧直观看词汇的相对重要性与视觉分层。

**出现页面**：
- 如翼 > 洞察诊断 > [品牌心智度量 brand-mind-dashboard](/workshop/brand-mind-dashboard?fullscreen=1)
- 如翼 > 洞察诊断 > [心智详情 – 本品牌 mindshare-detail](/workshop/mindshare-detail?fullscreen=1)

**典型信号**：需求里出现"心智词典"、"热词榜 + 词云"、"搜索词多层级分布"、"品牌关键词"时使用。

## 不要用本区块的场景（L3 强制）

- **通用词云段落**（不是品牌心智专属） → 用 `wordcloud-section`（L2，出现在 mind / content-asset / outside 等页面）。两者的区别：
  - `mindshare-dictionary`：**结构化** 的"热词榜 + 多层词云"组合，含特定的 Tier 语义和品牌心智业务语境
  - `wordcloud-section`：通用词云段落，没有"热词榜"那一侧，视觉上更轻
- 单一榜单（无词云） → 用 `ranking-list`（L2）的 `HotRanking` 变体
- 三级心智的占比展示 → 用 `treemap-panel`（L3）

## 适用页面

- 如翼 > 洞察诊断 > 品牌心智 > 品牌心智度量（✅ `brand-mind-dashboard`）

## 交互状态

| 状态 | 行为 |
| --- | --- |
| default | 左侧热门词列表 + 右侧词云静态展示 |
| 行 hover | `hover:bg-solid-black-2 transition-colors duration-150` |

## 数据结构

```typescript
interface KeywordItem {
  keyword: string;
  index: number;
}

interface WordCloudItem {
  text: string;
  tier: 1 | 2 | 3 | 4 | 5 | 6;
  x: number;
  y: number;
}
```

## 规则

- DO：左栏固定 `w-[391px]`，右栏 `flex-1` 自适应
- DO：柱形条宽度按 `(index / maxIndex) * 120px` 比例缩放
- DO：词云层级严格按设计稿的 6 级字号和 5 种颜色分配
- DO：数值使用 `OD-number` 字体，保持数字等宽对齐
- DO：行 hover 使用 `bg-solid-black-2` + `transition-colors`
- DON'T：不要使用第三方词云库（如 `react-wordcloud`）
- DON'T：不要对词云做随机动画或旋转

## 完整实现代码

生成代码时，**必读** [`../references/mindshare-dictionary.tsx`](../references/mindshare-dictionary.tsx)。该文件是本区块的完整参考实现，禁止凭本文的结构描述自行猜测实现，应以 references 中的代码为基准进行复用或裁剪。

## slug: notification-popover

# 通知消息 notification-popover

顶栏消息铃铛的下拉 Popover 面板，包含重要通知/系统消息 Tab 切换和消息列表。

## 适用页面

- 全局顶栏 · 消息中心（所有如翼页面共用）

## 交互状态

| 状态 | 行为 |
| --- | --- |
| 默认 | 面板展示消息列表，行背景白色 |
| hover 消息行 | 行背景变为 `bg-[rgba(0,0,0,0.03)]` |
| 非链接默认 | 文字 `text-black-9` |
| 非链接 hover | 文字变为 `text-black-12` |
| 链接(DocLink)默认 | 文字 `text-black-12` |
| 链接(DocLink) hover | 文字变 `text-blue-6` + 出现 `arrow-forward` 箭头 18px |
| Action 默认 | 文字 `text-blue-6`，"立即体验" |
| Action hover | 文字变 `text-blue-7` + 出现 `arrow-forward` 箭头 18px |
| bell 激活（面板打开） | 按钮背景 `bg-[rgba(41,107,239,0.08)]`，图标 `text-blue-6`，徽章隐藏 |
| bell 未激活 hover | 按钮背景 `bg-black-2` |
| 点击消息 | 该消息标记已读，标签从蓝色变灰色 |
| 一键已读 | 当前 Tab 所有消息标为已读 |
| 收起 | 关闭面板 |
| 面板外点击 | 关闭面板（`mousedown` 事件检测） |
| 查看全部 hover | 文字从 `text-black-10` 变为 `text-blue-6` |
| 一键已读 hover | 文字从 `text-black-10` 变为 `text-blue-6` |

## 变体

| 变体 | 说明 | 适用场景 |
| --- | --- | --- |
| 无 Action（plain） | 标签 + 纯文本 + 时间 | 系统通知、计算完成提醒 |
| 可跳转文档（doc-link） | 标签 + 可点击文本(hover 变蓝+箭头) + 时间 | 产品更新公告、课程通知 |
| 立即体验（action） | 标签 + 文本 + "立即体验"按钮 + 时间 | 功能体验邀请 |
| DocLink + Action | 标签 + 可点击文本 + "立即体验"按钮 + 时间 | 迭代更新 + 体验入口 |

## 数据结构

```typescript
type NoticeItem = {
  id: string;
  tag: string;
  text: string;
  time: string;
  read: boolean;
  docLink?: boolean;
  actionLabel?: string;
};

type MessageType = 'plain' | 'doc-link' | 'action' | 'doc-link+action';
```

## 规则

- DO：消息标签用药丸形，未读/已读配色与 ODN token 一致
- DO：面板宽度固定 540px，Header 52px、Footer 44px、消息行 48px
- DO：未读数量徽章使用主色
- DON'T：不要用 border 风格做标签，应使用填充背景药丸形

## 完整实现代码

生成代码时，**必读** [`../references/notification-popover.tsx`](../references/notification-popover.tsx)。该文件是本区块的完整参考实现，禁止凭本文的结构描述自行猜测实现，应以 references 中的代码为基准进行复用或裁剪。

## slug: page-header

# 页面头部 page-header

页面顶部的标题 + 操作按钮 + 筛选栏区域，以及模块级标题切换、筛选、导航等 13 种模式。

## 适用页面

- 如翼 > 洞察诊断 > 品牌心智度量
- 如翼 > 洞察诊断 > 行业机会心智
- 如翼 > 洞察诊断 > 心智详情（本品牌/本行业）
- 如翼 > 洞察诊断 > 心智层级结构
- 如翼 > 人群资产 > SPU 人群资产
- 如翼 > 人群资产 > 品牌人群资产
- 如翼 > 策略应用 > 转化复盘详情
- 如翼 > 策略应用 > 门店客源分析
- 几乎所有如翼内容页

## 交互状态

| 状态                     | 行为                                                     |
| ------------------------ | -------------------------------------------------------- |
| 默认                     | 标题左对齐，操作按钮右对齐，`justify-between`            |
| hover 标题切换（模式 7） | 标题文字变为 `text-blue-6`，展开 `Dropdown` 菜单         |
| hover 视图切换           | 按钮背景变为 `bg-black-2`                                |
| 选中视图                 | 按钮背景 `bg-blue-2`，图标 `text-blue-6`                 |
| 选中 Tab 切换            | 背景 `bg-white`，文字加粗 `font-medium`，`shadow-1` 阴影 |
| 选中 Lite Tab            | 背景 `bg-blue-1`，文字 `text-blue-6`，加粗               |
| hover Lite Tab           | 背景 `bg-black-2`                                        |
| hover 帮助按钮           | 弹出 `Popover` 显示说明文字                              |
| hover 编辑图标           | 颜色变为 `text-blue-6`                                   |
| 展开更多（模式 12）      | 按钮文字在"展开更多"和"收起"之间切换                     |
| 完整配置信息（模式 10）  | 点击展示完整配置，`hover:text-blue-6`                    |

## 变体

### 页面头部（9 种）

| 变体                        | 说明                                                                                               | 适用场景               |
| --------------------------- | -------------------------------------------------------------------------------------------------- | ---------------------- |
| 品牌心智度量（模式 1）      | 标题 + 操作按钮 + `Select`(品牌) + `DateRangePicker` + `Select`(参考系)                            | 品牌心智度量页面       |
| 行业机会心智（模式 2）      | 标题 + 操作按钮 + `DateRangePicker` + `Select`(参考系)                                             | 行业机会心智页面       |
| 心智详情-简版（模式 3）     | 标题标签 + 添加人群 + Tab 切换 + `DateRangePicker` + `Select`(参考系)                              | 心智详情页（简版筛选） |
| 心智详情-完整（模式 4）     | 标题标签 + Tab 切换 + `Select`(品牌) + `DateRangePicker` + `Select`(参考系)                        | 心智详情页（完整筛选） |
| 商品人群资产（模式 5）      | `Card.Header` + `Button` + `Cascader`(商品) + `Select`(时间粒度) + `DatePicker` + `Select`(参考系) | SPU/品牌人群资产       |
| 级联选择面板（模式 5b）     | `Cascader(showInnerSearch)` 展开态，品类>子类>SPU 三级                                             | SPU 筛选栏的展开面板   |
| 转化复盘详情表头（模式 10） | 标题编辑 + 操作按钮组(竖线分隔) + 状态标签 + 元信息行                                              | 转化复盘详情页         |
| 营销复盘（模式 11）         | `Card.Header` + 主按钮 + 品牌条 + `Select` + 状态 + 切换 + 操作组 + 元信息 + `Tabs.Tag`            | 营销复盘 / 策略详情页  |
| 门店客源分析（模式 12）     | 标题+副标题 + 帮助按钮 + 复合门店选择器 + 推荐筛选 + 查询                                          | 门店客源分析页面       |

### 模块头部（3 种）

| 变体                        | 说明                                            | 适用场景       |
| --------------------------- | ----------------------------------------------- | -------------- |
| Tab 导航（模式 6）          | `Tabs` 多维度切换                               | 详情页内容切换 |
| 标题切换+视图切换（模式 7） | `Dropdown` 标题 + `Select` + 图表/表格切换      | 排行榜模块     |
| 模块级筛选器（模式 8）      | 标题 + 多个 `text-black-9` 标签 + `Select` 配对 | 筛选面板       |

### 辅助元素（1 种）

| 变体                       | 说明                                              | 适用场景         |
| -------------------------- | ------------------------------------------------- | ---------------- |
| 统计说明 Popover（模式 9） | `Button(type="light")` + `Popover` hover 弹出说明 | 所有页面操作按钮 |

## 数据结构

```typescript
// 模式 3/4：行业/品牌切换
type ScopeType = 'industry' | 'brand';

// 模式 5：时间粒度（SPU 筛选栏）
type Granularity = 'day' | 'week' | 'month';

// 模式 7：视图模式
type ViewMode = 'chart' | 'table';

// 模式 5：级联选择器选项
interface CascaderOption {
  label: string;
  value: string;
  children?: CascaderOption[];
}

// 模式 7：标题下拉选项
interface TitleOption {
  label: string;
  value: string;
}

// 模式 11：Lite Tab 选项
interface TabItem {
  key: string;
  label: string;
}

// 模式 11：Dropdown 菜单项
interface DropdownMenuItem {
  key: string;
  label: string;
  danger?: boolean;
}
```

## 规则

- DO：标题左对齐，操作按钮右对齐，使用 `flex justify-between`
- DO：操作按钮使用 `Button(type="light")`，避免视觉抢占内容
- DO：筛选项横向排列，间距 `gap-3`（标准）/ `gap-4`（详情页），垂直居中
- DO：筛选标签和选择器配对，`Select` 只要带 `prefix` 就用 `prefix={<span className="text-[var(--odn-color-black-9)]">...</span>}`
- DO：页面头部和筛选栏分两行，用 `border-t border-black-4` 分隔
- DO：详情页标题旁用 `rounded-full bg-black-3` 圆角标签显示心智路径
- DO：有独立操作时用竖线 `h-4/h-5 w-px bg-black-4/bg-black-5` 与帮助按钮分开
- DO：SPU 筛选栏时间粒度 `Select` 和 `DatePicker` 用 `-ml-px` 无缝拼接
- DO：超过 3 个操作按钮时用 `Dropdown` 收纳到"更多"菜单
- DON'T：不要在标题栏放超过 3 个直接操作按钮
- DON'T：不要超过一行筛选；超过 5 个筛选项时用「展开更多」收起
- DON'T：不要把标题栏和筛选栏合并为一行
- DON'T：不要在 Lite Tab 上使用下划线样式，应使用 `bg-blue-1 text-blue-6 rounded-[4px]` 填充样式

## 完整实现代码

生成代码时，**必读** [`../references/page-header.tsx`](../references/page-header.tsx)。该文件是本区块的完整参考实现，涵盖全部 13 种模式的 tsx 代码。禁止凭本文的结构描述自行猜测实现，应以 references 中的代码为基准进行复用或裁剪。

## slug: penetration-analysis

# 渗透分析面板 penetration-analysis

左侧子弹图（横向条形图对比）+ 右侧双列排名榜的复合分析区块，标题区下拉切换分析维度。

## 产品问题（何时用）

**解决什么**：在多维度（渗透率 / R3 流入率等）下快速看"本品牌 vs 行业基准"的差距，并列出 TOP 品牌对比。左侧子弹图看差距，右侧榜单看是谁。

**出现页面**：
- 如翼 > 洞察诊断 > [商品人群资产 spuAudienceAsset](/workshop/spuAudienceAsset?fullscreen=1)
- 如翼 > 洞察诊断 > [品牌人群资产 brand5r](/workshop/brand5r?fullscreen=1)

**典型信号**：需求中出现"渗透率分析"、"子弹图"、"TGI 对比"、"与行业基准对比"时优先使用。

## 变体决策（L2）

| 变体 | 维度切换 | 适用场景 |
|------|---------|---------|
| 推荐人群渗透率 | 渗透率 / 覆盖率 | SPU 人群资产 |
| R3 流入率 | R3 流入率 / R3 转化率 | SPU 人群资产（不同分析视角） |
| 品牌资产渗透 | 5R 各层渗透 | 品牌人群资产 |

**选择准则**：顶部 Select 切换分析维度，结构保持一致。

**不要用本区块的场景**：
- 只需要看排名（无子弹图对比） → 用 `ranking-list`（L2）的 `BrandRanking` 变体
- 需要 **资产×R3** 四象限（非本区块的子弹图渗透）→ 用 `quadrant-scatter`（L3）

## 适用页面

- SPU 人群资产（✅ `spu-crowd-asset`） · 推荐人群
- SPU 人群资产（✅ `spu-crowd-asset`）（推荐人群渗透分析、R3 流入率分析）
- 品牌人群资产（✅ `brand-crowd-asset`）

## 交互状态

| 状态 | 行为 |
| --- | --- |
| default | 首行（索引 0）选中高亮，右侧排名榜联动 |
| hover（子弹图行） | 行背景变 `rgba(49,50,51,0.05)`，弹出 Tooltip 显示渗透率详情，同时切换选中态 |
| 选中（子弹图行） | 行背景变 `rgba(41,107,239,0.05)`，文字变 `text-black-12` |
| hover + 选中叠加 | hover 样式仅在非选中行显示 |
| Tooltip 定位 | 绝对定位在行右侧，`left: 640px`，`top` 按行索引 × 40 + 8 计算 |
| 排名榜联动 | 标题中的人群名称随左侧选中行实时更新 |

## 变体

| 变体 | 说明 | 适用场景 |
| --- | --- | --- |
| 渗透分析 | 子弹图 + 排名榜，展示渗透率 | 查看 SPU 在推荐人群中的渗透表现 |
| R3 流入率分析 | 同结构，标题下拉切换维度 | 查看 SPU 在推荐人群中的 R3 流入率 |

## 数据结构

```typescript
type CrowdItem = {
  name: string;
  brandRate: number;
  benchmarkRate: number;
};

type RankItem = {
  rank: number;
  name: string;
  change?: number;
  isSelf?: boolean;
};
```

## 规则

- DO：Hover 子弹图行时同时切换选中态并弹出 Tooltip
- DO：排名榜标题中的人群名称必须随左侧选中行联动
- DO：当前 SPU 行（`isSelf: true`）置顶并使用高亮样式，与其他排名行视觉区分
- DO：子弹图品牌柱宽度必须根据 `brandRate / maxRate` 动态计算百分比
- DO：基准线位置必须根据 `benchmarkRate / maxRate` 动态计算百分比
- DO：排名升降使用 `text-green-7` / `text-red-7`（注意是 7 级，非 6 级）
- DON'T：不要硬编码柱宽，必须根据数据动态计算
- DON'T：不要遗漏排名无变化的行（无 `change` 属性时不显示 RankChange）
- DON'T：不要用 Table 组件，用自定义 div flex 布局

## 完整实现代码

生成代码时，**必读** [`../references/penetration-analysis.tsx`](../references/penetration-analysis.tsx)。该文件是本区块的完整参考实现，禁止凭本文的结构描述自行猜测实现，应以 references 中的代码为基准进行复用或裁剪。

## slug: quadrant-scatter

# 四象限分布图 quadrant-scatter

**统一 slug**：`quadrant-scatter`。`references/quadrant-scatter.tsx` 内包含两种产品变体——**资产×R3** 与 **品牌心智双矩阵**（`MatrixScatterChart`）。历史上「心智增长矩阵」单独成页/成 skill 的写法已**并入本区块**；检索「心智矩阵」时仍可用关键词 **心智增长矩阵**，实现上请只维护本文件。

## 产品问题（何时用）

**解决什么**：在二维象限上比较实体（品牌、心智词等）的相对位置，辅助看「潜力 / 机会 / 探索 / 突破或主力」等策略分区。

**出现页面**：
- 如翼 > 洞察诊断 > [商品人群资产 spuAudienceAsset](/workshop/spuAudienceAsset?fullscreen=1) — **变体 · 资产×R3**
- 如翼 > 洞察诊断 > [品牌心智度量 brand-mind-dashboard](/workshop/brand-mind-dashboard?fullscreen=1) — **变体 · 心智双矩阵**（`MatrixScatterChart` ×2）

**典型信号**：「四象限散点」「象限定位」且能明确 **两轴指标**（资产+R3 **或** 心智份额/环比/本品竞品心智）。

## 变体（同一 reference，勿拆第二个 slug）

| 变体 | 两轴 / 结构 |  workshop | 实现要点 |
| --- | --- | --- | --- |
| **资产×R3** | 资产占比 × R3 流入率；第四象限 **突破盘** | `spuAudienceAsset` | `AssetR3QuadrantScatter`：`BrandDot`、象限内 0–1 坐标、自定义 hover Tooltip |
| **心智双矩阵** | 左：行业心智份额×环比；右：本品×竞品心智量 | `brand-mind-dashboard` | `MatrixScatterChart` + `GROWTH_QUADRANTS` / `COMPETITOR_QUADRANTS`，轴上 0–100 归一化 + `getXY` |

## 不要用本区块的场景

- 第三维度用气泡大小表达 → `bubble-scatter-chart`（候选）
- 纯榜单 → `ranking-list`（L2）
- 纯 TreeMap 心智量占比 → `treemap-panel`（L3）

## 交互状态（资产变体）

| 状态 | 行为 |
| --- | --- |
| default | 散点正常显示 |
| hover | 当前点放大 + ring；其余 `opacity-30`；自定义 Tooltip（资产排名、R3 排名） |

## 交互状态（心智 `MatrixScatterChart`）

| 状态 | 行为 |
| --- | --- |
| default | 12px 圆点 + 标签；`ResizeObserver` 宽度 |
| hover | `Tooltip`：心智名 + `level1_mind`/`level2_mind` |

## 数据结构

**资产变体**：见下 `BrandDot`。

**心智变体**：由接口决定；`MatrixScatterChart` 使用 `getXY(d) => [x,y]`（0–100）与 `getLabel(d)`。如翼 CDN 常见字段：`industry_share_normalized`、`mind_ratio_normalized`、`brand_mind_normalized`、`competitor_mind_avg_normalized`、`level3_mind`、`level1_mind`、`level2_mind`。

```typescript
type BrandDot = {
  name: string;
  x: number;
  y: number;
  quadrant: 0 | 1 | 2 | 3;
  assetRank: number;
  r3Rank: number;
  labelSide?: 'left' | 'right';
};
```

## 规则

- DO：`brand-mind-dashboard` 从本文件 **import** `MatrixScatterChart`、`GROWTH_QUADRANTS`、`COMPETITOR_QUADRANTS`，禁止再复制矩阵实现
- DO：文档站默认导出同时展示 **两变体**（上下排列）
- DO：资产变体保持 CSS Grid 2×2 + 百分比定位；心智变体保持 dmp-web 对齐的 `PADDING` / 象限色
- DON'T：资产变体不要用 SVG 铺满整块图区；资产变体 Tooltip 为自定义 div（非 ODN `Tooltip`）；**心智变体**使用 ODN `Tooltip`（与 workshop 一致）

## 完整实现代码

必读 [`../references/quadrant-scatter.tsx`](../references/quadrant-scatter.tsx)。命名导出：`MatrixScatterChart`、`GROWTH_QUADRANTS`、`COMPETITOR_QUADRANTS`、`QuadrantConfig`、`MatrixQuadrants`。

## slug: radar-with-metrics-panel

<!-- metadata
nav:
  title: 区块
  order: 3
group:
  title: 通用业务区块 (L2)
  order: 2
title: 雷达 + 指标列
subtitle: RadarWithMetricsPanel
description: '左雷达对比 + 右 2-3 列指标卡的对比视角布局，出现在域内传播/域外扩散等页面。'
order: 6
prompt: '雷达 + 指标列布局区块（L2）。左侧雷达图 slot（本品 vs 参照系）+ 图例 + 右侧 2-3 列指标卡（含 label/本品值/对比值/增长率/排名）。出现在 content-asset（域内传播）、outside（域外扩散）。'
skill: radar-with-metrics-panel
-->

# 雷达 + 指标列 radar-with-metrics-panel

## 产品问题（何时用）

**解决什么**：本品牌在 N 个维度上与某参照系（竞品/行业均值/行业 top5）的对比视角。左侧雷达图给整体形态感，右侧 2-3 列指标卡把每个维度的数值、对比差值、增长率、排名展开。

**出现页面**：
- 如翼 > 洞察诊断 > [域内传播 content-asset](/workshop/content-asset?fullscreen=1)
- 如翼 > 洞察诊断 > [域外扩散 outside](/workshop/outside?fullscreen=1)

**典型信号**：需求里出现"雷达图 + 指标卡"、"本品 vs 参照系多维对比"、"域内/域外对比"时使用。

## 变体决策（L2 强制）

| 变体 | 雷达轴数 | 参照系 | 指标列数 | 出现页面 |
|------|---------|-------|---------|---------|
| 域内传播 | 4-5 轴 | 行业均值 / 竞品均值 / 行业 Top5 | 2-3 列 | content-asset |
| 域外扩散 | 3-4 轴 | 行业均值 / 行业 Top5 | 2 列 | outside |

**选择准则**：
- 维度多（4+） → 雷达更能体现"形状"，主数值用右侧指标卡精确
- 维度少（3） → 可降级为纯指标卡组 + 小雷达
- 参照系可切换 → 在区块外层提供 Select，切换时传入新的 `referenceName` + 指标数据

## 不要用本区块的场景

- 时间趋势 → 用折线图（非雷达）
- 单一维度的对比 → 用 `penetration-analysis`（L2，子弹图）
- 不是"本品 vs 外部基准"的场景 → 不要套本区块

## 预览

<code src="../../references/radar-with-metrics-panel.tsx"></code>

## API

```typescript
import { RadarWithMetricsPanel, type RadarMetricColumn } from 'references/blocks/radar-with-metrics-panel';

interface RadarWithMetricsPanelProps {
  radar: React.ReactNode;           // 左侧雷达图 slot（使用方接入 ECharts Radar）
  referenceName?: string;           // 参照系名称（默认"行业均值"）
  brandColor?: string;              // 图例色：本品
  referenceColor?: string;          // 图例色：参照系
  metrics: RadarMetricColumn[];     // 右侧 2-3 列指标
  className?: string;
}

interface RadarMetricColumn {
  title: string;                    // 列标题
  items: RadarMetricItem[];
}

interface RadarMetricItem {
  label: string;
  description?: string;             // hover tooltip
  value: string;                    // 本品数值（已格式化）
  compareValue?: string;            // 参照值（已格式化）
  referenceName?: string;           // 该项独立的参照系名（覆盖外层）
  growth?: number;                  // 增长率百分比
  rank?: number;                    // 本品排名
}
```

## 为什么 radar 是 slot 而不是内置

雷达图的实现方式跨页面差异较大（ECharts / D3 / 自绘），而且指标数量和数据格式各不相同。**本区块只负责"左雷达 + 右指标列"的布局壳 + 指标的统一展示规范**；雷达图本身由使用方按该页面已有实现接入。

## Do / Don't

- ✅ 指标值用 `tabular-nums` + 千分位格式
- ✅ 增长率正值用 `text-[#07C160]`（中式涨跌色），负值用 `text-[#E63D2E]`
- ✅ 指标名用 `underline decoration-dashed` 暗示可 hover 看描述
- ✅ 参照系名可每项独立覆盖（支持"A 比竞品均值 / B 比行业均值"的混合参照）
- ❌ 不要在 radar slot 内硬编码某个具体的 ECharts 配置——让使用方自由
- ❌ 不要去掉图例（本品/参照系的颜色对照是核心）
- ❌ 不要超过 3 列指标——会挤压雷达空间

## 使用示例（workshop import）

```tsx
import { RadarWithMetricsPanel } from '../../references/blocks/radar-with-metrics-panel';

// workshop 自己实现 ECharts 雷达图
function MyRadarChart() { ... }

<RadarWithMetricsPanel
  radar={<MyRadarChart report={report} />}
  referenceName="行业均值"
  metrics={[
    {
      title: '曝光',
      items: [
        { label: '曝光人数', value: fmt(report.exp.self_cnt), compareValue: fmt(report.exp.compare_cnt), growth: report.exp.growth, rank: report.exp.self_rank },
      ],
    },
    {
      title: '互动',
      items: [...],
    },
  ]}
/>
```

## slug: ranking-list

<!-- metadata
nav:
  title: 区块
  order: 3
group:
  title: 通用业务区块 (L2)
  order: 2
title: 排名榜（4 变体）
subtitle: RankingList
description: '在某维度上的排位展示，4 种变体：BrandRanking（品牌榜+bar 区间）、ShareRanking（份额榜）、HotRanking（热门榜）、SurgeRanking（飙升榜）。'
order: 2
prompt: '排名榜区块，4 种变体：BrandRanking（品牌排位+bar 区间，"有多高"）、ShareRanking（份额占比，"占了多少"）、HotRanking（关键词热度，"多热"）、SurgeRanking（快速上升，"涨了多少"）。'
skill: ranking-list
-->

## 产品问题（何时用）

**解决什么**：用户想在某维度上看"谁排前几"。根据关注点不同，选择不同的变体呈现形式。

**出现页面**：
- 如翼 > 洞察诊断 > [行业心智格局](/workshop/industry-opportunity-mind?fullscreen=1)（BrandRanking + HotRanking + SurgeRanking）
- 如翼 > 洞察诊断 > [品牌心智度量](/workshop/brand-mind-dashboard?fullscreen=1)（ShareRanking）
- 如翼 > 洞察诊断 > [心智详情 – 本品牌](/workshop/mindshare-detail?fullscreen=1)（BrandRanking，带 isCurrent 高亮）
- 如翼 > 洞察诊断 > [品牌竞争格局](/workshop/compete-analysis?fullscreen=1)（BrandRanking ×3）

**典型信号**：需求中出现"榜单"、"排行"、"TOP N"、"热度排名"、"飙升"、"份额"时，应优先考虑本区块。

## 变体决策（L2 强制）

| 变体 | 产品问题 | 视觉差异 | 最佳参考 workshop |
|------|---------|---------|------------------|
| `BrandRanking` | 品牌在某指标上的排位 + 区间范围。**有多高** | 左头像 + 中品牌名 + 右 bar 区间 + 百分比范围 | `mindshare-detail`（心智品牌榜，带 isCurrent 高亮） |
| `ShareRanking` | 品牌心智份额占比。**占了多少** | 前 3 名蓝色加粗；右侧：上总量 + 下百分比 | `brand-mind-dashboard`（本品牌 TOP 份额心智） |
| `HotRanking` | 关键词/话题热度。**多热** | 分类标签 + TOP3 品牌副文本 + 右侧大数值 | `industry-opportunity-mind`（热门心智榜） |
| `SurgeRanking` | 谁在快速上升。**涨了多少** | 增长心智量副文本 + 右侧绿色上升箭头 + 增长率 | `industry-opportunity-mind`（心智飙升榜） |

**选择准则**：
- 用户关心"绝对排名 + 区间对比" → `BrandRanking`
- 用户关心"份额构成" → `ShareRanking`
- 用户关心"热度/话题讨论" → `HotRanking`
- 用户关心"增长/快速上升" → `SurgeRanking`

**组合使用**（同一页面可多个变体并列）：
- 行业心智格局：BrandRanking + HotRanking + SurgeRanking（三榜横排）
- 竞争格局：BrandRanking ×3（不同维度的品牌排名）

**不要用本区块的场景**：
- 双列对比的排名 → 用 `dual-ranking-list`（本品牌 vs 本行业的左右对比）
- 榜单里要含"流转/转化" → 用 `crowd-table-view`（右侧联动柱状图）
- 只是普通列表（无排名语义） → 直接用 ODN Table 或 Card 列表

## 预览

<code src="../../references/ranking-list.tsx"></code>

## API

```typescript
// 所有 4 个变体都是命名导出，不是默认导出
import {
  BrandRanking,
  ShareRanking,
  HotRanking,
  SurgeRanking,
  type BrandRankItem,
  type ShareRankItem,
  type HotRankItem,
  type SurgeRankItem,
} from 'references/blocks/ranking-list';

interface BrandRankingProps {
  title?: string;
  items: BrandRankItem[];  // rank + name + avatar + trend + barMin/Max + isCurrent
  className?: string;
  showBar?: boolean;       // 是否显示 bar 区间（默认 true）
  barWidth?: number;       // Bar 宽度 px（默认 100）
}

interface ShareRankingProps {
  title?: string;
  tooltip?: React.ReactNode;
  items: ShareRankItem[];  // rank + level3_mind + level1/2 + mind_total + industry_share
  className?: string;
}

interface HotRankingProps {
  title?: string;
  items: HotRankItem[];    // rank + name + tag + subText + volume
  topContent?: React.ReactNode;  // 顶部右侧操作区（通常是 Select）
  className?: string;
}

interface SurgeRankingProps {
  title?: string;
  items: SurgeRankItem[];  // rank + name + tag + volume + value(增长率)
  topContent?: React.ReactNode;
  className?: string;
}
```

## 组件构成

| 变体 | Card 组件 | 行高/密度 | 右侧主数值 |
|------|----------|----------|-----------|
| BrandRanking | 自定义 Card（w-[380px]） | `py-2 gap-3` | Bar 区间（w-[100px]）+ 百分比范围 |
| ShareRanking | 自定义 div（w-[360px]） | `h-[50px]` 每行 | 双行（总量 + 百分比） |
| HotRanking | `Card + Card.Header` | `py-1` 紧凑 | 单数值（text-base） |
| SurgeRanking | `Card + Card.Header` | `py-1` 紧凑 | 绿色上升箭头 + 增长率 |

## 设计规格

所有变体共用：
- Card 圆角：`rounded-[12px]`（`[--odn-card-radius:12px]`）
- 标题字号：`text-base font-semibold`（16px）
- rank 列宽：w-[26px]（HotRanking / SurgeRanking）、w-5（BrandRanking / ShareRanking）
- 趋势色：上升 `text-green-6/7`、下降 `text-red-6/7`

## Do / Don't

- ✅ 用 `className` 覆盖 Card 尺寸（不要硬编码 w-[380px]）
- ✅ BrandRanking 可关 `showBar` 退化为纯名次榜
- ✅ HotRanking / SurgeRanking 的 `topContent` 可自由组合（Select / DateRangePicker 等）
- ❌ 不要把 4 个变体合并为 1 个超级组件——它们的数据结构差异大，合并会牺牲类型安全
- ❌ 不要在变体内部 fetch 数据——数据由使用方传入
- ❌ 不要改变各变体的"视觉焦点"（bar / 份额百分比 / 数值 / 箭头）——这是变体的核心区分

## 使用示例（workshop import）

```tsx
import {
  BrandRanking,
  HotRanking,
  SurgeRanking,
} from '../../references/blocks/ranking-list';

// 三榜并列（industry-opportunity-mind 场景）
<div className="grid grid-cols-3 gap-4 h-[656px]">
  <BrandRanking title="品牌心智榜" items={brandData} />
  <HotRanking
    title="热门心智榜"
    items={hotData}
    topContent={<RankingMindshareSelect />}
  />
  <SurgeRanking
    title="心智飙升榜"
    items={surgeData}
    topContent={<RankingMindshareSelect />}
  />
</div>
```

## slug: report-list

# 方案列表 report-list

## 产品问题（何时用）

**解决什么**：在 Master-Detail 布局中作为左侧方案/任务列表。用户在列表里挑一个方案，右侧详情区就切换到那个方案的内容。常配合 `review-master-detail-layout`（L1 壳）一起使用。

**出现页面**：
- 如翼 > 全域度量 > [营销复盘（报告详情）](/workshop/review?fullscreen=1) · 左侧
- 如翼 > 全域度量 > [转化复盘 conversion-review](/workshop/conversion-review?fullscreen=1) · 左侧
- 如翼 > 全域度量 > [招商复盘 merchant-review](/workshop/merchant-review?fullscreen=1) · 左侧
- 如翼 > 人群策略 > [人群画像 audience-profile](/workshop/audience-profile?fullscreen=1) · 左侧

**典型信号**：需求中出现"Master-Detail"、"左侧方案列表"、"报告列表"、"任务列表"时优先使用。

## 变体决策（L3 — 只在复盘类页面复用，视觉高度统一）

| 变体 | 差异点 | 适用场景 |
| ---- | ------ | -------- |
| 转化复盘列表 | 状态点 + 报告名 + ID/计算时间 | 转化复盘 |
| 营销复盘列表 | 同结构，timeLabel 改为"创建时间" | 营销复盘 / 招商复盘 |
| 通用任务列表 | 自定义按钮文案和列表字段 | 任意 Master-Detail 页面 |

**选择准则**：按业务场景填充顶部按钮文案（"新建转化复盘报告" / "新建营销复盘报告"）和列表行的次要字段。结构本身不变。

**不要用本区块的场景**：
- 详情面板（右侧）而非方案列表 → 用 `crowd-detail-panel`
- 人群卡片网格 → 用 `crowd-pick-card-grid`（L2）
- 数据表格 → 用 ODN Table

## 适用页面

- 如翼 > 策略应用 > [转化复盘](/workshop/conversion-review?fullscreen=1) > 左侧列表

## 交互状态

| 状态 | 含义 | 颜色 | className |
| ---- | ---- | ---- | --------- |
| success | 计算成功 | 绿色 | `bg-green-6` |
| computing | 计算中 | 蓝色 | `bg-blue-6` |
| failed | 计算失败 | 红色 | `bg-red-6` |
| expired | 已过期 | 灰色 | `bg-black-7` |

| 行为 | 说明 |
| ---- | ---- |
| 点击列表项 | 切换选中项，背景 `bg-blue-1`，标题 `text-blue-6 font-semibold` |
| hover 列表项 | 非选中项背景 `bg-black-1` |
| 搜索 | 输入关键词过滤列表 |
| 筛选 | 点击筛选按钮打开筛选面板 |
| 分页 | 底部分页器切换页码 |

## 变体

| 变体 | 差异点 | 适用场景 |
| ---- | ------ | -------- |
| 转化复盘列表 | 状态点 + 报告名 + ID/计算时间 | 转化复盘 |
| 营销复盘列表 | 同结构，timeLabel 改为"创建时间" | 营销复盘 |
| 通用任务列表 | 自定义按钮文案和列表字段 | 任意 Master-Detail 页面 |

## 规则

- DO：外层用 `bg-[#f2f4f9] p-6` 浅灰底承载（DemoShell），与页面头部预览一致
- DO：顶部主操作按钮 `w-full` 全宽主色，外层 `p-4`（与设计稿一致，无渐变背景）
- DO：使用 `STATUS_COLORS` 映射状态色
- DO：选中项用 `bg-blue-1`，标题 `text-blue-6 font-semibold`
- DO：副信息用 `text-xs text-black-9`
- DO：搜索栏用 `Input(light)` + 独立 `Button(light icon="filter")`（并排，**不**嵌套在 rightElement 里）
- DO：分页区分两行——上行是 "共 N 条记录，每页 [M▼] 条"（用 `Select` 拼装），下行是 `Pagination` 页码按钮，两行中间 `gap-2`
- DO：下行 `Pagination` 开启 `showFirstLast showPrevNext`，**不**开启 `showTotal` / `showSizeChanger`
- DON'T：不要硬编码颜色值
- DON'T：不要用 `bg-primary` 或其他自定义色做选中态
- DON'T：不要让副信息和标题同样式同色
- DON'T：不要使用 `Pagination` 的 `showSizeChanger` + `showTotal` 把"每页条数"和"页码"压到一行
- DON'T：不要把筛选按钮塞到 `Input` 的 `rightElement` 里面
- DON'T：不要给顶部按钮区加渐变背景（设计稿里是纯白）

## 完整实现代码

生成代码时，**必读** [`../references/report-list.tsx`](../references/report-list.tsx)。该文件是本区块的完整参考实现，禁止凭本文的结构描述自行猜测实现，应以 references 中的代码为基准进行复用或裁剪。

## slug: review-master-detail-layout

<!-- metadata
nav:
  title: 区块
  order: 3
group:
  title: 页面壳层 (L1)
  order: 1
title: 复盘页主从布局
subtitle: ReviewMasterDetailLayout
description: '已结束任务的多切面事后审查场景下使用的主从布局，出现在营销复盘/转化复盘/招商复盘等页面。'
order: 3
prompt: '复盘页主从布局区块（L1 页面壳）。左侧方案列表 slot + 右侧（标题栏 + 状态/日期任务信息条 + Tabs.Tag 多切面 + 切面内容插槽）。不负责顶栏/菜单，外层的 RuyiLayout 由使用方提供。'
skill: review-master-detail-layout
-->

## 产品问题（何时用）

**解决什么**：一个投放任务执行完了，从多个切面回看效果。用户在左侧选择具体方案，右侧按 Tab 切换不同视角（概览 / 资产广度 / 深度 / 偏好度 / 持久度 / 配置信息）。

**出现页面**：
- 如翼 > 全域度量 > [营销复盘（报告详情）](/workshop/review?fullscreen=1)
- 如翼 > 全域度量 > [转化复盘](/workshop/conversion-review?fullscreen=1)
- 如翼 > 全域度量 > [招商复盘](/workshop/merchant-review?fullscreen=1)

**典型信号**：需求中出现"复盘"、"结案"、"投放后分析"、"多 Tab 切面"、"左侧列表+右侧详情"时，应优先考虑本区块。

## 变体决策

| 变体 | 右侧 Tab 组 | 任务信息字段 | 出现页面 |
|------|-------------|-------------|---------|
| 营销复盘 | 概览 / 资产广度 / 资产深度 / 资产偏好度 / 资产持久度 / 配置信息 | 投放日期 / 转化时长 | 营销复盘 |
| 招商复盘 | 概览 / 资产广度 / 资产深度 / 资产偏好度 / 资产持久度 / 配置信息 | 投放日期 / 转化时长 / 视频 IP | 招商复盘 |
| 转化复盘（无 Tab） | 无 Tabs，直接垂直铺 5 张 SectionCard | 投放日期 / 转化周期 / 完整配置 | 转化复盘 |

**选择准则**：
- 结案信息展示面宽，需要多切面切换 → 有 Tabs（营销/招商）
- 内容是递进式分析（概览→趋势→触发→频次→人群） → 无 Tabs，垂直铺排
- 任务信息条字段按业务需要自定义

**不要用本区块的场景**：
- 页面是"配置/新建" → 用普通 `page-header`（与其它新建流程表单页一致）
- 页面是"实时监控" → 本区块不含实时刷新语义，考虑别的 Dashboard 壳
- 页面没有"左侧列表选中" → 只用 Tab 的页面直接用 `Tabs.Tag`，不要套本壳

## 预览

<code src="../../references/review-master-detail-layout.tsx"></code>

## API

```typescript
interface ReviewMasterDetailLayoutProps {
  /** 左侧插槽（通常为 ReportList） */
  left: React.ReactNode;
  /** 右侧区域标题 */
  title: React.ReactNode;
  /** 标题右侧操作按钮组 */
  titleActions?: React.ReactNode;
  titleEditable?: boolean;        // 是否显示铅笔图标
  onTitleEdit?: () => void;
  /** 状态标签 */
  statusTag?: { label; color; bgColor };
  /** 任务信息条 */
  infoItems?: Array<{ label?; value; raw? }>;
  /** Tab 配置。不传则无 Tabs，children 直接作为右侧内容 */
  tabs?: Array<{ label; value }>;
  activeTab?: string;
  onTabChange?: (value: string) => void;
  /** 右侧内容（根据 activeTab 决定渲染什么） */
  children: React.ReactNode;
  /** 右侧容器 className（覆盖默认） */
  contentClassName?: string;
}
```

## 组件构成

| 元素 | 组件 | 说明 |
| ---- | ---- | ---- |
| 外层 | flex 横向布局 | `gap-4 min-h-[calc(100vh-120px)]` |
| 左侧 | slot | 通常为 ReportList 区块，宽度 324px |
| 右侧容器 | 白色圆角 | `rounded-2xl bg-white py-3 px-6`，可覆盖 |
| 标题栏 | flex 横向 | 左：标题 + 编辑铅笔；右：操作按钮组 |
| 状态 Tag | `inline-flex + rounded` | `px-2 py-0.5 text-xs font-medium`，含 bgColor + color |
| 信息条 | flex 横向 | 状态 Tag + 字段，字段间用竖线分隔 |
| Tabs | `Tabs.Tag` | `gap={8}`，按需提供 |
| 内容 | children | 使用方根据 activeTab 渲染 |

## 设计规格

| 属性 | 值 |
| ------ | --------------------- |
| 外层 gap | `gap-4`（16px） |
| 外层高度 | `min-h-[calc(100vh-120px)]` |
| 右侧容器背景 | `bg-white` |
| 右侧容器圆角 | `rounded-2xl`（16px） |
| 右侧容器内边距 | `py-3 px-6` |
| 标题字号 | `text-base font-semibold`（16px semibold） |
| 信息条字号 | `text-sm`（14px） |
| 分隔线 | `h-3 border-r border-[#e9ebef]` |

## Do / Don't

- ✅ 可以不传 `tabs`——这样 children 直接作为右侧主体（转化复盘用法）
- ✅ `titleActions` 由使用方自由组合（营销复盘 5 按钮 vs 转化复盘 2 按钮）
- ✅ `infoItems` 可传任意数量字段
- ❌ 不要在本区块内硬编码"营销复盘报告"等业务字符串
- ❌ 不要在本区块内嵌 RuyiLayout——外层已经有了
- ❌ 不要让左侧列表的样式逻辑渗透进本区块——那是 `report-list` 的职责

## 使用示例（workshop import）

```tsx
import { ReviewMasterDetailLayout } from '../../references/blocks/review-master-detail-layout';

<ReviewMasterDetailLayout
  left={<ReportList ... />}
  title="2026Q1 营销复盘报告"
  titleActions={
    <>
      <Button light size="small" icon="users">添加人群</Button>
      <Button light size="small" icon="copy">复制创建</Button>
      ...
    </>
  }
  statusTag={{ label: '已完成', color: '#07C160', bgColor: '#e8f8ef' }}
  infoItems={[
    { label: '投放日期', value: '2025-10-01 ~ 2026-03-31' },
    { label: '转化时长', value: '30天' },
  ]}
  tabs={[
    { label: '概览', value: 'overview' },
    { label: '资产广度', value: 'R' },
    ...
  ]}
  activeTab={activeTab}
  onTabChange={setActiveTab}
>
  {activeTab === 'overview' && <OverviewTab view={view} />}
  {activeTab === 'R' && <PlaceholderTab title="资产广度" />}
  ...
</ReviewMasterDetailLayout>
```

## slug: ripple-chart

# 涟漪图 ripple-chart

以同心圆涟漪形态展示核心人群与相似人群的关系，圆点大小映射人群规模，颜色/透明度映射渗透率，距圆心远近映射相似度。支持涟漪图和列表两种视图。

## 产品问题（何时用）

**解决什么**：以核心人群为圆心，按相似度放射状展示周边人群。用"距离 = 相似度、大小 = 规模、颜色 = 渗透率"的三重编码，让用户从"相似人群发现"角度选择投放目标。

**出现页面**：
- 如翼 > 人群策略 > [推荐人群市场 r0-audience-market](/workshop/r0-audience-market?fullscreen=1)

**典型信号**：需求里出现"相似人群"、"涟漪图"、"相似度同心圆"、"以某人群为核心扩展"时使用。

## 不要用本区块的场景（L3 强制）

- 候选人群卡片挑选 → 用 `crowd-pick-card-grid`（L2，3 个推荐人群页都用它）
- 纯列表视图 → 用 `crowd-card-list`（L3）
- 四象限散点 → `quadrant-scatter`（L3）
- 不是"以某个人群为核心"的场景 → 不要用涟漪图

## 适用页面

- 人群策略 > 推荐人群 > 推荐人群市场

## 交互状态

| 状态 | 行为 |
| --- | --- |
| default | 所有散点正常显示，标签可见 |
| hover（散点） | 当前散点放大 `scale(1.15)`、标签 `font-semibold`；弹出详情弹窗（规模/相似度/渗透率）；其他散点淡化至 `opacity-[0.18]` |
| leave | 恢复 default |
| 视图切换 | 点击 `menu` 切换列表视图，点击 `grid` 切换涟漪图视图 |
| 列表排序 | 点击表头切换排序列和升降序，激活列标题 `text-blue-6` |
| 收藏切换 | 点击星标图标切换收藏状态（`star-filled` ↔ `star`） |
| 配置变更 | 实时重新计算布局并渲染 |

## 变体

| 变体 | 说明 | 适用场景 |
| --- | --- | --- |
| 涟漪图视图 | 同心圆散点图，默认视图 | 直观展示相似度和规模关系 |
| 列表视图 | 表格形式，7列可排序 + 收藏 | 精确数据查看和对比 |
| 单色方案 | 固定蓝色，透明度映射渗透率 | 默认渗透率可视化 |
| 多色方案 | 色相渐变映射渗透率（紫→蓝） | 需要更强区分度时 |

## 数据结构

```typescript
type AudienceItem = {
  name: string;
  size: number;
  similarity: number;   // 0-1
  penetration: number;  // 0-1
  deliveryCount: number;
  insightCount: number;
  tags: string[];
  starred: boolean;
};

type LayoutNode = AudienceItem & {
  x: number;
  y: number;
  side: 1 | -1;       // 1=右侧, -1=左侧
  dotSize: number;
  dotColor: string;
  dotOpacity: number;
};

type ViewMode = 'chart' | 'list';
type ColorMode = 'single' | 'multi';
type SimMapMode = 'rank' | 'value';
```

## 规则

- DO：布局算法必须包含碰撞检测，按 `dotSize` 降序依次放置，沿角度正负搜索无重叠位置
- DO：散点尺寸和颜色必须基于数据动态计算，不硬编码
- DO：Hover 时 dim 其他散点至 `opacity-[0.18]`
- DO：配置面板变更实时反映到可视化
- DO：种子圆始终居中，不参与碰撞检测
- DO：视图切换按钮 `menu`=列表, `grid`=涟漪图，当前激活态有 `bg-white` 背景
- DO：列表视图表头支持排序交互，覆盖量级为默认排序列且有蓝色渐变背景
- DO：列表视图的收藏星标支持点击切换
- DO：左侧散点使用 `flex-row-reverse` 实现"名称+点"反向排列
- DON'T：不要用固定坐标定位散点，必须用算法布局
- DON'T：不要遗漏 Hover 弹窗中的渗透率数据
- DON'T：不要忘记 `ResizeObserver` 监听容器宽度变化重新布局

## 完整实现代码

生成代码时，**必读** [`../references/ripple-chart.tsx`](../references/ripple-chart.tsx)。该文件是本区块的完整参考实现，禁止凭本文的结构描述自行猜测实现，应以 references 中的代码为基准进行复用或裁剪。

## slug: ry-date-range-picker

# 如翼日期范围选择器（`ry-date-range-picker`）

**实现口径：ODN `DatePicker`**（通过 `shortcuts` + `popupRender` + `components.DayButton` 自定义），对齐 **如翼平台**全站日期范围筛选交互。

**真源代码**：`references/blocks/ry-date-range-picker.tsx`（导出 `RyDateRangePicker`）；workshop 页面 **import 复用**该文件。

## 产品问题（何时用）

**解决什么**：在如翼平台页面筛选栏中，提供统一的日期范围选择体验——7/30/60/90 天快捷选择 + 自然周/月/季，hover 时实时预览范围，可手动切换"从开始日期选"或"从结束日期选"，max 截止至昨天。

**出现页面**：

- 如翼 > 域外洞察 > 域外概览（`/workshop/outside`）
- 如翼 > 洞察诊断 > 品牌心智度量看板（`/workshop/brand-mind-dashboard`）
- 如翼 > 洞察诊断 > 竞争分析（`/workshop/compete-analysis`）
- 如翼 > 首页（`/workshop/home`）核心指标概览 + 品牌资产趋势分析
- 如翼 > 洞察诊断 > 内容资产（`/workshop/content-asset`）
- 如翼 > 洞察诊断 > 心智详情（`/workshop/mindshare-detail`）
- 如翼 > 洞察诊断 > 行业机会心智（`/workshop/industry-opportunity-mind`）

**典型信号**：需求写「如翼日期筛选」「Ruyi DateRangePicker」「快捷 7/30/60/90」「日期范围选择器带快捷模式」时使用本区块。

## 不要用本模式的场景

- 单日期选择（非范围）→ 直接用 `DatePicker` + `prefix="日期"`
- SPU 页面按日/按周/按月粒度切换 + 拼接选择器 → 保持 `Select` + `DateRangePicker` + `-ml-px` 拼接模式（见 `spuAudienceAsset.tsx`）
- 仅需简单范围选择、无快捷模式 → 直接用 `DateRangePicker`

## 组件构成

| 元素 | 组件 | 说明 |
| ---- | ---- | ---- |
| 根 | `DatePicker`（`one-design-next`） | `picker` 根据 mode 动态切换 |
| 触发器 | 自定义 `triggerElement` | 36px、border、hover 态 |
| 快捷模式栏 | `shortcuts` prop | 7 个选项按钮 |
| 弹出头部 | `popupRender` | day 模式：可切换选中端 + 下划线动画；非 day 模式：静态范围显示 |
| 自定义日格子 | `components.DayButton` | hover 范围高亮、自定义光标、`data-ruyi-*` |

## 交互要点

| 行为 | 说明 |
| ---- | ---- |
| 切换模式 | 点击快捷按钮切换 mode，自动重置 hover 状态 |
| Hover 预览（day） | 鼠标进入日格子 → 根据当前模式天数计算范围 → 高亮显示 |
| 开始/结束切换 | 点击弹出头部的"开始日期"/"结束日期"可手动翻转选择方向 |
| 选择确认（day） | mouseDown 时设置 value 并关闭弹窗 |
| 选择确认（week/month/quarter） | onChange 回调，由 DatePicker 原生行为触发 |
| 自定义光标 | hover 日格子时显示方向箭头光标（右箭头=选择开始，左箭头=选择结束） |

## Do / Don't

**Do**

- 在如翼所有需要日期范围筛选的地方统一使用本区块
- 通过 `modes` prop 裁剪可用模式（如仅需 7/30/60/90 天可省略 week/month/quarter）
- 通过 `triggerLabel` / `triggerWidth` 自定义触发器外观

**Don't**

- 不要在需要与 Select 拼接（`-ml-px` + 自定义 border-radius）的场景用本区块——本区块自带完整触发器，无法无缝拼接
- 不要把本区块用于单日期选择——用 `DatePicker` + `prefix="日期"`
- 不要在外部包裹额外的 border 容器——触发器自带 border

## slug: sankey-chart

# 桑基图 sankey-chart

5R 人群资产流转桑基图，展示非 5R 到 R1-R5 的流入/流出/流转关系，支持拉新/蓄水/种草指标卡切换高亮。

## 产品问题（何时用）

**解决什么**：可视化 5R 人群在不同阶段间的流转（非 5R → R1 → R2 → ... → R5）。带宽=人数，配合顶部指标卡切换（拉新/蓄水/种草）高亮特定流向，让用户一眼看到人群是从哪里来、流向了哪里。

**出现页面**：
- 如翼 > 洞察诊断 > [资产流转 asset-flow](/workshop/asset-flow?fullscreen=1)

**典型信号**：需求里出现"资产流转"、"桑基图"、"sankey"、"流入/流出/流转"、"R1→R5 链路"时使用。

## 不要用本区块的场景

- 单一维度的对比 → 用 `ranking-list`（L2）或 `penetration-analysis`（L2）
- 多维度象限 → `quadrant-scatter`（L3，按变体选资产或心智轴）
- 时间趋势 → 用 `conversion-trend`（L3）

## 适用页面

- SPU 人群资产 · 资产流转
- 品牌人群资产 · 资产流转

## 交互状态

| 状态 | 行为 |
| --- | --- |
| default | 当前指标对应的流带高亮（蓝色 opacity 0.3），其他流带灰色（opacity 0.15） |
| hover（流带） | 被 hover 流带 opacity 提升至 0.5，出现 Tooltip 浮层显示流向和数值 |
| hover（右侧节点） | 节点卡出现蓝色背景 `bg-[rgba(41,107,239,0.05)]`，文字变 `text-blue-6`，复制图标带蓝色包裹；所有流入该节点的流带高亮 |
| click（指标卡） | 切换指标高亮，对应流带变蓝，其余变灰 |
| hover（指标卡） | 未选中卡片边框变 `border-blue-4`、背景变 `bg-blue-1/50` |

## 变体

| 变体 | 说明 | 适用场景 |
| --- | --- | --- |
| 拉新 | 高亮非5R→5R 的流带 | 查看拉新效果 |
| 蓄水 | 高亮非5R/R1→R1/R2 的流带 | 查看蓄水效果 |
| 种草 | 高亮向R3及以上流转的流带 | 查看种草效果 |

## 数据结构

```typescript
type SankeyNode = { label: string; value: string };

type StripDef = {
  from: number;
  to: number;
  thickness: number;
  metrics: string[];
  flowValue?: string;
};

type MetricKey = '拉新' | '蓄水' | '种草';

type MetricCard = {
  title: MetricKey;
  subtitle: string;
  value: string;
  comparison: string;
  comparisonValue: string;
  positive: boolean;
};
```

## 规则

- DO：指标卡选中时边框 `border-blue-6`、背景 `bg-blue-1`，标题和数值变 `text-blue-6`
- DO：右侧节点 hover 时出现蓝色背景和 V2 复制图标（`bg-[rgba(41,107,239,0.1)]` 包裹）
- DO：流带 hover 时 opacity 提升至 0.5，出现 Tooltip 显示 `{左节点} → {右节点}` 和流量值
- DO：流带 Tooltip 使用双层阴影 `0 10px 36px rgba(0,0,0,0.16), 0 6px 15px rgba(0,0,0,0.07)`
- DO：指标卡圆角 `rounded-[12px]`，节点卡圆角 `rounded-[8px]`
- DO：流带排序先渲染非活跃再渲染活跃，保证活跃流带在上层
- DO：配置面板支持 `activeMetric` 和 `compareRef` 切换
- DON'T：不要使用 `rounded-xl` 代替 `rounded-[12px]`
- DON'T：不要遗漏 V2 复制图标的蓝色背景包裹
- DON'T：不要在 Tooltip 中使用 `shadow-xl`，应使用设计稿指定的双层阴影
- DON'T：不要只展示单一指标，应支持拉新/蓄水/种草三选一

## 完整实现代码

生成代码时，**必读** [`../references/sankey-chart.tsx`](../references/sankey-chart.tsx)。该文件是本区块的完整参考实现，禁止凭本文的结构描述自行猜测实现，应以 references 中的代码为基准进行复用或裁剪。

## slug: section-block

# 可折叠内容区块 (Section Block)

带标题栏的白色内容区块，可选折叠/展开，是如翼数据分析页中最常见的内容容器。

## 适用页面

仪表盘页、数据分析页 — 用于组织页面内的各个功能模块。

## slug: store-insight-panel

# 门店洞察面板 store-insight-panel

区域洞察中的门店信息面板，左侧展示门店下钻后的高价值区域推荐列表，右侧为腾讯地图 API 占位区域。

## 产品问题（何时用）

**解决什么**：在"区域 + 地图"的复合视角里展示门店/区域的对比列表。左侧是结构化数据（带排名星级），右侧是地图（或地图静态图），用户能在坐标上定位与筛选。

**出现页面**：
- 如翼 > 洞察诊断 > [区域洞察 regional-insight](/workshop/regional-insight?fullscreen=1)

**典型信号**：需求里出现"门店洞察"、"区域洞察"、"地图 + 列表联动"、"高价值区域"时使用。

## 不要用本区块的场景（L3 强制）

- 没有地图维度的人群分析 → 用 `crowd-card-list`（L3）或 `crowd-pick-card-grid`（L2）
- 单一指标的排名 → 用 `ranking-list`（L2）
- 只是列表 + 详情面板（无地图）→ 用 `report-list`（L3）+ `crowd-detail-panel`（L3）

## 适用页面

- 区域洞察

## 交互状态

| 状态 | 行为 |
| --- | --- |
| 点击区域卡片 | 激活该卡片（`border-blue-5 bg-[rgba(41,107,239,0.03)]`），地图上弹出详情卡片 |
| hover 区域卡片 | 边框色变为 `border-blue-4` |
| 复选框勾选 | 独立于激活状态，可多选 |
| "全选" 按钮 | 切换全选/全不选 |
| "下载" 按钮 | 导出选中区域数据 |
| 返回箭头 | 回退到门店列表视图 |
| 门店列表点击 | 下钻进入推荐区域列表 |
| hover 门店卡片 | 边框变为 `border-blue-4` |

## 变体

| 变体 | 说明 | 适用场景 |
| --- | --- | --- |
| 门店列表 | 展示所有关联门店，显示名称和高价值区域数量 | 初始概览 |
| 推荐区域列表 | 展示选中门店的高价值区域，带排名、渗透率、地址、推荐等级 | 门店下钻详情 |

## 数据结构

```typescript
interface AreaItem {
  id: string;
  rank: number;
  name: string;
  penetration: number;
  address: string;
  stars: number;        // 1-5
  category?: string;
  distance?: number;    // 距离门店（米）
}

type ViewMode = 'store-list' | 'area-detail';
```

## 规则

- DO：排名徽章前 3 名必须使用差异化颜色（`#ed776d` → `#fa8e00` → `#ffc300`）
- DO：点击区域卡片时同步更新地图上的详情卡片
- DO：复选框独立于激活状态，支持多选（`Checkbox` 的 `onChange` 中 `e.stopPropagation()`）
- DO：门店名称超长时 `truncate`，不换行
- DO：地址过长时最多显示 2 行（`line-clamp-2`）
- DO：左侧面板区域列表使用 `overflow-y-auto` 支持滚动
- DO：星级评分根据 `stars` 字段动态渲染，不硬编码 5 星
- DON'T：不要在占位区域真实加载腾讯地图 API
- DON'T：不要将复选框状态和激活状态耦合
- DON'T：不要忽略门店列表视图，面板支持两种视图切换

## 完整实现代码

生成代码时，**必读** [`../references/store-insight-panel.tsx`](../references/store-insight-panel.tsx)。该文件是本区块的完整参考实现，禁止凭本文的结构描述自行猜测实现，应以 references 中的代码为基准进行复用或裁剪。

## slug: touchpoint-analysis

# 触点分析面板 touchpoint-analysis

左侧业绩大类指标卡组 + 右侧子弹图表格的复合分析区块，用于分析各触点媒体的人群覆盖度与 TGI。

## 产品问题（何时用）

**解决什么**：多触点媒体（视频、信息流、搜索等）的人群覆盖度与 TGI 综合对比。左侧看业绩大盘分组，右侧看媒体子弹图。

**出现页面**：
- 如翼 > 洞察诊断 > [品牌人群资产 brand5r](/workshop/brand5r?fullscreen=1)
- 如翼 > 洞察诊断 > [资产流转 asset-flow](/workshop/asset-flow?fullscreen=1)

**典型信号**：需求中出现"触点分析"、"媒体触达对比"、"多媒体 TGI"时优先使用。

## 变体决策（L2）

| 变体 | 左侧 | 右侧 | 出现页面 |
|------|------|------|---------|
| 带业绩大类 | 8 类业绩指标卡 | 媒体子弹图表格 | brand5r |
| 带 relationship 切换 | 同上 | 增加"关系维度"下拉切换 | asset-flow |

**选择准则**：
- 单视角触点对比 → 基础版
- 需切换不同关系维度 → 带 relationship 切换（asset-flow 版）

**不要用本区块的场景**：
- 单一维度的渗透率 → 用 `penetration-analysis`（L2）
- 触点的时间趋势 → 用 `conversion-trend`（L3）

## 适用页面

- 如翼 > 全域度量 > 触点分析
- 如翼 > 洞察诊断 > 品牌人群资产（✅ `brand-crowd-asset`）
- 如翼 > 洞察诊断 > 品牌资产流转（✅ `asset-flow`）

## 交互状态

| 状态 | 行为 |
| --- | --- |
| default | 所有指标卡未选中，等于全选，展示全部媒体数据 |
| 单选 | 选中 1 个指标卡，子弹图仅展示该业绩大类下的媒体，下拉标题切换为该大类名 |
| 多选 | 选中多个指标卡，子弹图展示已选大类下的媒体，下拉标题显示"已选 N 项" |
| 再次点击 | 取消选中该指标卡（toggle 逻辑） |
| hover 指标卡 | 背景变为 `bg-black-2` |
| 选中指标卡 | 背景 `bg-blue-2`，环形边框 `ring-1 ring-inset ring-blue-5`，文字 `text-blue-6` |
| hover 数据行 | 背景变为 `bg-black-2`，弹出 Popover 显示覆盖度/参考系/TGI |
| 排序 TGI | 点击表头 TGI 切换升序/降序，激活态图标 `text-blue-6` |
| 排序覆盖度 | 点击表头人群覆盖度切换升序/降序，激活态图标 `text-blue-6` |
| 排序非激活 | 排序图标为 `text-black-6` |
| 全选/多选时 | 媒体名格式为 `${category} > ${media}` |
| 单选时 | 媒体名仅显示 `${media}`，不带大类前缀 |

## 变体

| 变体 | 说明 | 适用场景 |
| --- | --- | --- |
| 全选模式 | 所有业绩大类数据聚合展示，媒体名带大类前缀 | 默认状态，全局概览 |
| 单选模式 | 仅显示单个业绩大类下的媒体，媒体名无前缀 | 查看单个业绩大类详情 |
| 多选模式 | 显示多个业绩大类的媒体，媒体名带大类前缀 | 跨类对比 |

## 数据结构

```typescript
interface MetricCardData {
  key: string;
  label: string;
  value: number;
  unit: string;
  tgi: number;
}

interface TouchpointRow {
  category: string;
  media: string;
  tgi: number;
  coverage: number;
  coverageRef: number;
}

type SortField = 'tgi' | 'coverage';
type SortOrder = 'asc' | 'desc';
```

## 规则

- DO：左侧指标卡组固定 `w-[224px]`，使用 `border-r border-black-4` 与右侧分隔
- DO：子弹图品牌柱使用 `bg-blue-5`，参考系竖线使用 `bg-black-10`
- DO：坐标轴网格线使用 `bg-black-3`，5 等分
- DO：选中态指标卡使用 `bg-blue-2 ring-1 ring-inset ring-blue-5`，文字 `text-blue-6`
- DO：hover 态数据行和指标卡使用 `bg-black-2`
- DO：全选/多选时媒体名格式为 `${category} > ${media}`，单选时仅 `${media}`
- DO：使用 `Popover` 组件（one-design-next）展示 hover 详情
- DO：排序激活态图标使用 `text-blue-6`，非激活态 `text-black-6`
- DON'T：不使用 Table 组件，用自定义 div flex 布局
- DON'T：指标卡不超过 8 个（对应 8 个业绩大类）
- DON'T：子弹图行不使用 `space-y-*`，使用固定 `h-10` 行高
- DON'T：不要用 `gap-*` 来排列数据行，每行固定高度靠 `h-10` 控制

## 完整实现代码

生成代码时，**必读** [`../references/touchpoint-analysis.tsx`](../references/touchpoint-analysis.tsx)。该文件是本区块的完整参考实现，禁止凭本文的结构描述自行猜测实现，应以 references 中的代码为基准进行复用或裁剪。

## slug: treemap-panel

# 矩形树图面板 treemap-panel

品牌心智图谱的矩形树图面板，以矩形面积表示心智量占比，支持树图和表格视图切换。

## 产品问题（何时用）

**解决什么**：一屏展示品牌所有心智的量级结构。矩形面积按心智量占比布局，用户能直观地看到"哪些心智最大、哪些是长尾"。配合表格视图，可切换到结构化数据查看。

**出现页面**：
- 如翼 > 洞察诊断 > [品牌心智度量 brand-mind-dashboard](/workshop/brand-mind-dashboard?fullscreen=1)

**典型信号**：需求里出现"心智图谱"、"矩形树图"、"心智量占比"、"treemap"、"图/表切换"时使用。

## 不要用本区块的场景

- 多维度象限定位（非纯量占比） → 用 `quadrant-scatter` 的心智变体（`MatrixScatterChart`，L3）
- 流转关系（进入/流出） → 用 `sankey-chart`（L3）
- 纯榜单 → 用 `ranking-list`（L2）的 `ShareRanking` 或 `HotRanking`

## 适用页面

- 如翼 > 洞察诊断 > 品牌心智度量（✅ `brand-mind-dashboard`）

## 交互状态

| 状态 | 行为 |
| --- | --- |
| 树图 default | 蓝色半透明矩形块，面积按 volume 排列 |
| 树图 hover | 叶子背景加深至 0.20，中央浮现半透明白底箭头 `bg-white/80 rounded-[6px] p-2`，弹出 Popover |
| Popover | 心智名 + pill 标签 + 分割线 + 心智量/环比值（含 arrow 图标）/行业份额 |
| 表格行 hover | `bg-black-2` |
| 表格排序 | 点击表头排序图标切换升序/降序（心智量/环比增长/行业份额） |
| 视图切换 | 树图/表格模式平滑切换 |
| 分页 | 极简分页器，`1/N` 页码 + 左右箭头，首尾页禁用 |

## 变体

| 变体 | 说明 | 适用场景 |
| --- | --- | --- |
| 树图模式 | 矩形面积可视化 | 快速浏览心智分布 |
| 表格模式 | 结构化数据 + 排序 | 精确数据查看 |

## 数据结构

```typescript
/** 如翼 mindMap.list 单项，与 `MindTreemapD3` 命名导出一致 */
interface MindTreemapInputRow {
  level3_mind: string;
  mind_total?: number | string;
  mind_ratio?: number | string;
  level1_mind?: string;
  level2_mind?: string;
  industry_share?: string;
}
```

文档站默认导出里的表格视图仍使用扁平 `TreemapItem`（name/tag/volume/change/share），由 API 行映射而来。

## 规则

- DO：树图布局使用 **`d3.hierarchy` + `d3.treemap`**，与 `components/chart/demo/treemap.tsx` 及 workshop **品牌心智度量** 同源；叶子为 d3 挂载的绝对定位 `div`
- DO：使用 `ResizeObserver` 获取容器宽度并重算布局；对极小格做数值抬升与迭代缩放，保证可读最小块尺寸
- DO：hover 时格子背景加深、正文隐藏、中央箭头浮现；详情用 `Popover` + `placement="topRight"` + `popupStyle` 偏移（与线上一致）
- DO：workshop 页面通过 `import { MindTreemapD3 } from '.../treemap-panel'` 传入 `mindMap.list`
- DO：表格列排序支持三列（心智量/环比增长/行业份额）（仅文档 demo 面板）
- DON'T：不要用与 d3 不等价的简化矩形切分冒充同一视觉规格
- DON'T：不要给叶子加入场动画

## 完整实现代码

生成代码时，**必读** [`../references/treemap-panel.tsx`](../references/treemap-panel.tsx)。该文件是本区块的完整参考实现，禁止凭本文的结构描述自行猜测实现，应以 references 中的代码为基准进行复用或裁剪。

## slug: wordcloud-section

<!-- metadata
nav:
  title: 区块
  order: 3
group:
  title: 通用业务区块 (L2)
  order: 2
title: 词云段落
subtitle: WordCloudSection
description: '通用词云段落，以文字权重可视化一组关键词。出现在搜索洞察/域内传播/域外扩散等洞察页。'
order: 5
prompt: '词云段落区块（L2）。react-d3-cloud + tier-based 配色/字号/权重（6 级）。输入 { text, value } 数组自动排序渲染。positive / negative 两种内置色板，也可传自定义 tier→颜色映射。'
skill: wordcloud-section
-->

# 词云段落 wordcloud-section

## 产品问题（何时用）

**解决什么**：用文字权重可视化一组关键词的热度/重要性。权重越高，字号越大、颜色越突出。适合在洞察类页面快速形成"这个领域在关注什么"的直觉。

**出现页面**：
- 如翼 > 洞察诊断 > [搜索洞察 mind](/workshop/mind?fullscreen=1)
- 如翼 > 洞察诊断 > [域内传播 content-asset](/workshop/content-asset?fullscreen=1)
- 如翼 > 洞察诊断 > [域外扩散 outside](/workshop/outside?fullscreen=1)

**典型信号**：需求里出现"词云"、"热词可视化"、"关键词权重展示"时使用。

## 变体决策（L2 强制）

| 变体 | 色板 | 适用场景 |
|------|------|---------|
| positive（默认） | 蓝 → 青 → 橙 → 紫 → 灰（暖降冷） | 正面词/中性话题/一般洞察 |
| negative | 红 → 橙 → 紫 → 灰 | 舆情负面/告警类词云 |
| 自定义 | 传入 `{ 1-6: color }` 对象 | 特定品牌主题色 |

**选择准则**：
- 默认洞察场景 → positive
- 需要区分情感/风险 → negative
- 有品牌主题色需求 → 自定义色板

**与 `mindshare-dictionary` 的边界**：
- `wordcloud-section`：**通用词云段落**（L2），只有词云本身，旁边没有热词榜。多场景复用
- `mindshare-dictionary`：**结构化组合**（L3），"热词榜 + 多层词云"，只在品牌心智度量/心智详情使用
- 需求明确提到"心智词典"、"品牌心智" → 用后者；其他场景 → 用前者

## 不要用本区块的场景

- 词数 > 50 → 降级成榜单（`ranking-list`/`HotRanking`），词云不是为大数据集设计
- 需要精确看数值排名 → 用 `ranking-list`（L2）的 `HotRanking`
- 结构化的"热词榜 + 词云"组合 → 用 `mindshare-dictionary`（L3）

## 预览

<code src="../../references/wordcloud-section.tsx"></code>

## API

```typescript
import { WordCloudSection, type WordCloudItem } from 'references/blocks/wordcloud-section';

interface WordCloudSectionProps {
  data: WordCloudItem[];              // { text, value }[]
  height?: number;                    // 默认 260
  colorScheme?: 'positive' | 'negative' | Record<number, string>;
  maxWords?: number;                  // 默认 40
  className?: string;
}

type WordCloudItem = { text: string; value: number };
```

## Do / Don't

- ✅ 输入数据按 `value` 自动降序排列
- ✅ 自动响应容器宽度变化（ResizeObserver）
- ✅ 支持 positive / negative 两种内置色板
- ✅ 可传自定义 tier 颜色映射
- ❌ 不要自己在外层写 ResizeObserver——本区块已内置
- ❌ 不要把词云容器高度设小于 200px，Tier 1 词字号 40px 会挤出
- ❌ 不要用于精确数值对比——词云是"感性"表达

## 使用示例（workshop import）

```tsx
import { WordCloudSection } from '../../references/blocks/wordcloud-section';

// 洞察页的词云段落
<div className="bg-white rounded-xl p-4">
  <div className="mb-3 text-sm font-semibold">搜索关键词</div>
  <WordCloudSection
    data={keywords.map(k => ({ text: k.keyword, value: Number(k.count) }))}
  />
</div>

// 正/负面切换
<WordCloudSection
  data={words}
  colorScheme={currentMetric === 'positive' ? 'positive' : 'negative'}
/>
```
