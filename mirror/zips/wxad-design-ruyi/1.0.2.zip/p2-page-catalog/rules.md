# 页面规格总表

> 本文件合并了所有 workshop 页面的规格文档。每个页面用二级标题 `## slug: <slug>` 分隔。

## slug: ai-smart-crowd

<!-- metadata
slug: ai-smart-crowd
title: AI 智选
group: 人群策略
references: references/workshop/ai-smart-crowd.tsx
workshop_entry: docs-pages/workshop/ai-smart-crowd.md
status: implemented
blocks_used: [page-header, notification-popover]
-->

# AI 智选 页面知识

## 业务目标

通过表格展示 AI 推荐人群列表，支持排序、筛选与分页；结合通知类 Popover 演示计算状态或操作反馈（BETA 能力入口）。

## 导航路径

如翼平台 → 人群策略 → 推荐人群 → AI 智选

## 页面类型

表格列表 + 辅助 Popover

## 区块组装

人群表格为 **内联 Table**；`notification-popover` 对应设计上的通知/说明浮层能力（当前通过 `NotificationPopoverTrigger` 演示组件接入）。

### 使用的区块

| 区块 | slug | 用法 |
|------|------|------|
| 页面头 | page-header | 标题与 BETA 标识 |
| 通知气泡 | notification-popover | 状态说明或轻量引导（与组件 demo 对齐） |

### 使用的组件

Button, Card, Icon, Input, Pagination, RuyiLayout, Select, Table、NotificationPopoverTrigger

## 数据模型

- 表格行：人群 ID、名称、规模、计算状态、时间等 mock 列

## 特殊交互与状态

- 排序、筛选与分页由 `Table` 受控状态驱动

## 设计决策

- 与行业/兴趣/主题三页共用侧边导航结构，突出「AI」差异化能力。

## slug: asset-flow

<!-- metadata
slug: asset-flow
title: 品牌资产流转
group: 洞察诊断 · 品牌资产
references: references/workshop/asset-flow.tsx
workshop_entry: docs-pages/workshop/asset-flow.md
status: implemented
blocks_used: [page-header, sankey-chart, touchpoint-analysis]
-->

# 品牌资产流转 页面知识

## 业务目标

展示品牌 5R 人群资产在不同时段的流转变化，帮助广告主理解拉新、蓄水、种草的效果，并分析各触点对流转指标的覆盖贡献。

## 导航路径

洞察诊断 > 品牌资产 > 品牌资产流转

## 页面类型

仪表盘页

## 区块组装

```
┌──────────────────────────────────────────────┐
│  Card: "品牌资产流转"                          │ ← 页面标题
│  日期: 2025-09-17  对比: 30天前  参照值: 行业均值│ ← 筛选栏
├──────────────────────────────────────────────┤
│  Card: "资产概览"                              │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐     │
│  │ 拉新      │ │ 蓄水      │ │ 种草      │     │ ← 三指标卡
│  │ 6,324,914│ │ 2,846,824│ │ 31,914   │     │
│  └──────────┘ └──────────┘ └──────────┘     │
├──────────────────────────────────────────────┤
│  Card: "流转关系"                              │
│  ┌──────────────────────────────────────┐    │
│  │ 25-08-18         桑基图         25-09-17│    │ ← SVG 桑基图
│  │ 非5R ════════════════════════ 非5R流失  │    │
│  │ R1  ════════════════════════ R1        │    │
│  │ R2  ════════════════════════ R2        │    │
│  │ ...                                    │    │
│  └──────────────────────────────────────┘    │
├──────────────────────────────────────────────┤
│  Card: "触点分析"  (拉新：非5R到5R)            │
│  ┌─────────┐ ┌──────────────────────────┐    │
│  │合约硬广  │ │ 类别>媒体  TGI  ████ 覆盖│    │ ← 左类别+右条形图
│  │品牌竞价  │ │ ...                      │    │
│  └─────────┘ └──────────────────────────┘    │
└──────────────────────────────────────────────┘
```

### 使用的区块

| 区块 | slug | 用法 |
|------|------|------|
| 日期筛选 | — | 内联实现，Select + DatePicker 组合 |
| 指标卡组 | — | 内联实现，3 张指标卡展示拉新/蓄水/种草 |
| 桑基图 | sankey-chart | SVG 自绘 5R 流转关系 |
| 触点分析面板 | touchpoint-analysis | 左类别卡片 + 右媒体条形图（与选中指标联动） |

### 使用的组件

Card, DatePicker, Icon, RuyiLayout, Select

## 数据模型

- **核心指标**：拉新（非5R→5R）、蓄水（非5R→R1/R2）、种草（非5R/R1/R2→R3），每项含数值 + 行业均值对比百分比
- **桑基图数据**：5R 各阶段（R1~R5）+ 非5R，阶段间的流转量
- **触点类别**：合约硬广、品牌竞价、互选、招商项目等 8 类，各含覆盖度和 TGI
- **触点媒体**：类别下的具体媒体渠道，含 TGI 和覆盖度
- **筛选维度**：日期 + 对比时段 + 参照值（行业均值/竞品均值/TOP5 均值）

## 特殊交互与状态

- 日期对比选择器：支持选择两个时段进行对比
- 指标卡点击切换：选中拉新/蓄水/种草，桑基图高亮对应流转路径
- 桑基图 band hover：显示流转路径 Tooltip（"源 → 目标 数值 [图标]"）
- 右侧 R 节点 hover：高亮所有流入该节点的 band，左侧和右侧同步显示对应流量值
- 触点分析与指标卡联动：标题显示当前选中指标及其定义
- 触点类别点击切换右侧媒体条形图

## 设计决策

- 桑基图采用 SVG 自绘而非图表库，因为需要精确控制 5R 节点的排列和流转连线样式
- 资产概览独立 Card，流转关系独立 Card，触点分析独立 Card，层次分明
- 触点分析跟随指标卡选中状态切换上下文（拉新/蓄水/种草）
- 侧栏菜单完整展开：市场洞察 5 项 + 品牌资产 6 项 + 品牌心智 2 项


## 关联区块

| 区块 | 知识文件 |
|------|---------|
| 触点分析 | [`touchpoint-analysis`](../../p2-block-catalog/rules/touchpoint-analysis.md) |
| 桑基图 | [`sankey-chart`](../../p2-block-catalog/rules/sankey-chart.md) |

## slug: audience-profile

<!-- metadata
slug: audience-profile
title: 人群画像
group: 人群策略
references: references/workshop/audience-profile.tsx
workshop_entry: docs-pages/workshop/audience-profile.md
status: implemented
blocks_used: [page-header, report-list]
-->

# 人群画像 页面知识

## 业务目标

针对选定人群展示画像报告列表与详情 Tab，结合图表刻画人群属性与行为，支撑自定义人群的分析与复用。

## 导航路径

如翼平台 → 人群策略 → 自定义人群 → 人群画像

## 页面类型

Master-Detail / 列表 + Tab + 图表

## 区块组装

左侧或上部 **报告列表** 与 **Tab 切换** 下的画像详情为组合布局；`report-list` 为与 block-catalog 对齐的列表区块语义，图表段落（ChartA/ChartB）当前 **内联**。

### 使用的区块

| 区块 | slug | 用法 |
|------|------|------|
| 页面头 | page-header | 人群上下文与操作入口 |
| 报告列表 | report-list | 可选报告条目与切换 |

### 使用的组件

Button, Card, HoverFill, Icon, Input, Pagination, RuyiLayout, ScrollArea, Select, Tabs、EChartsReact

## 数据模型

- 单 CDN JSON 驱动报告列表与画像指标

## 特殊交互与状态

- Tab 切换联动不同图表与指标卡
- 与推荐人群系列页共享侧边菜单结构范式

## 设计决策

- 画像图表与结案复盘类页面区分数据源与视觉权重，避免与全域度量混淆。

## slug: benchmark-dashboard

<!-- metadata
slug: benchmark-dashboard
title: 评测总览
group: 基础设施
references: references/workshop/benchmark-dashboard.tsx
workshop_entry: docs-pages/workshop/benchmark-dashboard.md
status: infrastructure
blocks_used: []
-->

# 评测总览 页面知识

## 业务目标

消费 `.dumi/data/benchmark.json` 等评测跑数结果，展示软维度得分、硬门禁通过与 verdict 分布，用于 **设计/实现回归评测** 的可视化总览（非如翼业务功能页）。

## 导航路径

文档站「评测」→ 评测总览（`/workshop/benchmark-dashboard`，`benchmark-dashboard.md`）

## 页面类型

数据看板（评测专用）

## 区块组装

无 `p2-block-catalog` 引用；图表与汇总卡片在单文件内用 React + 轻量可视化拼装。

### 使用的区块

| 区块 | slug | 用法 |
|------|------|------|
| — | — | 无区块 import |

### 使用的组件

以源码为准：评测结果表格、统计卡片、筛选状态等

## 数据模型

- `benchmark.json`：`RunResult`、`CaseResult`、软分 breakdown、hardGate 等结构

## 特殊交互与状态

- 可按 run / dataset / verdict 过滤与下钻（以实际实现为准）

## 设计决策

- 与业务 workshop 隔离，避免评测数据依赖混入如翼 mock CDN。

## slug: brand-mind-dashboard

<!-- metadata
slug: brand-mind-dashboard
title: 品牌心智度量
group: 洞察诊断 · 品牌心智
references: references/workshop/brand-mind-dashboard.tsx
workshop_entry: docs-pages/workshop/brand-mind-dashboard.md
status: implemented
blocks_used: [page-header, metrics-overview, ranking-list/share, treemap-panel, quadrant-scatter]
-->

# 品牌心智度量 页面知识

## 业务目标

展示品牌心智量及行业份额变化趋势，帮助广告主了解品牌心智在行业中的位置、心智词条分布和增长潜力。

## 导航路径

洞察诊断 > 品牌心智 > 品牌心智度量

## 页面类型

仪表盘页

## 区块组装

```
┌──────────────────────────────────────────────────────────┐
│  Card: "品牌心智度量" + [统计说明][产品手册]                │ ← 页面标题
│  日期范围: 2025-09-17 ~ 2025-10-17  参考系: 竞品均值       │ ← 筛选栏
├────────────────────────────────┬─────────────────────────┤
│  Card: 心智概览                 │  Card: 行业份额榜        │
│  品牌心智量: 3,945,516 ↑13.04% │  1. 杏仁酸  28.88%      │
│  品牌行业份额: 24.14% ↑13.04%  │  2. 抛光    27.77%      │
│  [触达5.63%][互动15.37%]...    │  3. 保湿    26.66%      │
│  ┌──────────────────────┐     │  ...                    │
│  │ SVG 折线趋势图        │     │                         │
│  └──────────────────────┘     │                         │
├────────────────────────────────┴─────────────────────────┤
│  Card: "本品牌心智图谱"                                    │
│  ┌──────────────────────────────────────────────────┐    │
│  │  矩形树图（面积=心智量，hover 高亮）               │    │
│  └──────────────────────────────────────────────────┘    │
├────────────────────────────┬─────────────────────────────┤
│  Card: 本品TOP20心智增长矩阵│  Card: 竞品TOP20竞争矩阵     │
│  ┌──────────────────┐     │  ┌──────────────────┐      │
│  │ 潜力盘 │ 机会盘  │     │  │ 本品劣势 │ 竞争激烈│      │
│  │────────┼────────│     │  │─────────┼────────│      │
│  │ 探索盘 │ 主力盘  │     │  │ 蓝海市场 │ 本品优势│      │
│  └──────────────────┘     │  └──────────────────┘      │
└────────────────────────────┴─────────────────────────────┘
```

### 使用的区块

| 区块 | slug | 用法 |
|------|------|------|
| 心智概览面板 | metrics-overview | 品牌心智量 + 行业份额 + 4 维心智分布 + SVG 折线图 |
| 心智榜单 | ranking-list | 行业份额榜变体 |
| 矩形树图面板 | treemap-panel | 本品牌心智图谱 |
| 心智增长矩阵（四象限） | quadrant-scatter | `MatrixScatterChart` 双矩阵（并入四象限分布图区块） |
| 四象限分布图 | quadrant-scatter | 竞品 TOP20 竞争矩阵（变体） |
| 心智词典 | mindshare-dictionary | 热门搜索词排名 + 词云分布图 |

### 使用的组件

Button, Card, DateRangePicker, Icon, Popover, RuyiLayout, Select

## 数据模型

- **心智量**: 品牌心智总量 + 同比/环比变化率
- **行业份额**: 品牌在行业中的心智占比 + 排名
- **四维心智**: 触达心智、互动心智、分享心智、搜索心智各占比
- **趋势数据**: 按日/周粒度的心智量 + 行业份额双轴折线
- **心智词条**: 各心智关键词的心智量、变化率、标签分类
- **矩阵坐标**: 增长率 vs 行业份额基础（本品）; 本品心智量 vs 竞品心智量（竞品）

## 特殊交互与状态

- 日期范围选择器 + 参考系下拉联动筛选
- SVG 折线趋势图 hover 显示辅助线和数据点
- 矩形树图 hover 高亮词条并显示详情
- 四象限散点 hover 弹出 Popover 显示增长率/份额/心智量

## 设计决策

- 心智概览与行业份额榜并排，形成「绝对量 + 相对排名」的双视角
- 四维心智分布用色彩编码条，一眼看出各维度占比
- 矩形树图面积编码心智量大小，直观展示词条重要性层级
- 增长矩阵与竞争矩阵并排，分别分析自身增长潜力和竞品对比


## 关联区块

| 区块 | 知识文件 |
|------|---------|
| 心智概览 | [`metrics-overview`](../../p2-block-catalog/rules/metrics-overview.md) |
| 心智榜单 | [`ranking-list`](../../p2-block-catalog/rules/ranking-list.md) |
| 矩形树图 | [`treemap-panel`](../../p2-block-catalog/rules/treemap-panel.md) |
| 心智增长矩阵 | [`quadrant-scatter`](../../p2-block-catalog/rules/quadrant-scatter.md) |
| 心智词典 | [`mindshare-dictionary`](../../p2-block-catalog/rules/mindshare-dictionary.md) |

## slug: brand5r

<!-- metadata
slug: brand5r
title: 品牌人群资产
group: 洞察诊断 · 品牌资产
references: references/workshop/brand5r.tsx
workshop_entry: docs-pages/workshop/brand5r.md
status: implemented
blocks_used: [page-header, metric-card-group, touchpoint-analysis, penetration-analysis]
-->

# 品牌人群资产 页面知识

## 业务目标

展示品牌维度的 5R 人群资产规模和结构，帮助广告主了解品牌在各阶段的人群分布、触点覆盖和推荐人群渗透情况。

## 导航路径

洞察诊断 > 品牌资产 > 品牌人群资产

## 页面类型

仪表盘页

## 区块组装

```
┌──────────────────────────────────────────────┐
│  Card: "品牌人群资产" + [添加人群][下载数据]    │ ← PageHeader
│  日期: 2025-02-01  对比基期: 行业均值           │ ← 筛选栏
├──────────────────────────────────────────────┤
│  Card: "资产概览"                              │
│  ┌──────┐┌──────┐┌──────┐┌──────┐┌──────┐┌──────┐│
│  │总资产 ││R1触达││R2回应││R3共鸣││R4行动││R5信赖││ ← 5R 指标卡
│  └──────┘└──────┘└──────┘└──────┘└──────┘└──────┘│
│  [████████████████████████████████████████████]  │ ← 5R 分布条
├──────────────────────────────────────────────┤
│  Card: "触点分析"                              │
│  ┌─────────┐ ┌──────────────────────────┐    │
│  │合约硬广  │ │ 类别>媒体  TGI  ████ 覆盖│    │ ← 左类别+右条形图
│  │品牌竞价  │ │ ...                      │    │
│  │互选      │ └──────────────────────────┘    │
│  └─────────┘                                  │
├──────────────────────────────────────────────┤
│  Card: "推荐人群渗透分析"                      │
│  ┌──────────────────────────────────────┐    │
│  │ 人群名称  ████本品牌  ██行业基准      │    │ ← 双条对比
│  └──────────────────────────────────────┘    │
├──────────────────────────────────────────────┤
│  Card: "近 3 个月趋势分析"                     │
│  ┌──────────────────────────────────────┐    │
│  │ 2024-12  ████ ████ ████ ████         │    │ ← 多维度条形图
│  │ 2025-01  ████ ████ ████ ████         │    │
│  │ 2025-02  ████ ████ ████ ████         │    │
│  └──────────────────────────────────────┘    │
└──────────────────────────────────────────────┘
```

### 使用的区块

| 区块 | slug | 用法 |
|------|------|------|
| 资产指标卡组 | metric-card-group | 5R 指标卡 + 分布条（直接引用模式） |
| 触点分析面板 | touchpoint-analysis | 左类别卡片 + 右媒体条形图（变体引用） |
| 渗透分析面板 | penetration-analysis | 本品牌 vs 行业基准双条对比（变体引用） |
| 趋势分析 | — | 内联实现，多维度月度条形图 |

### 使用的组件

Button, Card, DatePicker, Icon, RuyiLayout, Select

## 数据模型

- **5R 指标**: 人群总资产 + R1-R5 各阶段人数、对比行业均值的百分比
- **5R 分布**: 各阶段占比（R1 占 53.82%、R2 占 41.41% 等）
- **触点类别**: 合约硬广、品牌竞价、互选、招商项目等 8 类，各含覆盖度和 TGI
- **触点媒体**: 类别下的具体媒体渠道（微信朋友圈、微信视频号等），含 TGI 和覆盖度
- **推荐人群**: 各人群的本品牌渗透率 vs 行业基准渗透率
- **趋势数据**: 近 3 个月各 R 阶段人群规模变化

## 特殊交互与状态

- 日期选择器 + 对比基期下拉联动筛选
- 触点分析左侧类别点击切换右侧媒体条形图
- 5R 指标卡用色彩编码区分各阶段
- 渗透分析双条（本品牌 蓝色 vs 行业基准 灰色）直观对比

## 设计决策

- 5R 色彩体系贯穿全页：蓝(R1)→浅蓝(R2)→青(R3)→绿(R4)→黄(R5)
- 触点分析采用左右联动布局：左侧类别卡片选中高亮，右侧展示对应媒体数据
- 渗透分析用双条形图而非散点图，更直观展示品牌与基准的差距
- 页面头部用 Card.Header 内联模式而非独立 page-header 区块


## 关联区块

| 区块 | 知识文件 |
|------|---------|
| 指标卡片组 | [`metric-card-group`](../../p2-block-catalog/rules/metric-card-group.md) |
| 触点分析 | [`touchpoint-analysis`](../../p2-block-catalog/rules/touchpoint-analysis.md) |
| 渗透分析 | [`penetration-analysis`](../../p2-block-catalog/rules/penetration-analysis.md) |

## slug: color-token-drift

<!-- metadata
slug: color-token-drift
title: 色值 Token 漂移修复
group: 基础设施
references: references/workshop/color-token-drift.tsx
workshop_entry: docs-pages/workshop/color-token-drift.md
status: infrastructure
blocks_used: []
-->

# 色值 Token 漂移修复 页面知识

## 业务目标

**回归验证样本**：对照「工作台首页」类布局，检查 **色值是否统一走 ODN CSS 变量**（`var(--odn-color-*)`），避免硬编码色值漂移；用于 CI/人工走查前的可视化基线。

## 导航路径

文档站「评测」→ 回归验证 → 色值 Token 漂移修复

## 页面类型

示例仪表盘（评测）

## 区块组装

与 `home` 相近的 **KPI + 表格** 骨架，内联实现；源码与首页工作台部分结构相似，属刻意平行样本。

### 使用的区块

| 区块 | slug | 用法 |
|------|------|------|
| — | — | 无区块 import |

### 使用的组件

Card, RuyiLayout, Table

## 数据模型

- `KPI_DATA`、`RANK_DATA` 等本地常量

## 特殊交互与状态

- 侧栏菜单项较 `home` 略少，用于不同子集对比

## 设计决策

- 文档与 `home` 对照；修改 token 时建议 **两页联调** 看对比效果。

## slug: compete-analysis

<!-- metadata
slug: compete-analysis
title: 品牌竞争格局
group: 洞察诊断 · 市场洞察
references: references/workshop/compete-analysis.tsx
workshop_entry: docs-pages/workshop/compete-analysis.md
status: implemented
blocks_used: [page-header, ranking-list, bubble-scatter-chart]
-->

# 品牌竞争格局 页面知识

## 业务目标

从市场洞察视角展示品牌竞争态势：多组排行榜、气泡散点等，帮助对比本品与竞品在关键指标上的位置与差距。

## 导航路径

如翼平台 → 洞察诊断 → 市场洞察 → 品牌竞争格局

## 页面类型

排行 + 气泡图分析页

## 区块组装

排行榜与气泡图为 **内联 ECharts + 表格**；`bubble-scatter-chart` 为注册表中与 block-catalog 对齐的 **候选区块**命名。

### 使用的区块

| 区块 | slug | 用法 |
|------|------|------|
| 页面头 | page-header | 筛选、时间、说明 |
| 排行列表 | ranking-list | 多组榜单（实现为多段列表卡片） |
| 气泡散点 | bubble-scatter-chart | 竞争格局气泡图（候选区块） |

### 使用的组件

Button, Cascader, Checkbox, Collapsible, DateRangePicker, Icon, Input, RuyiLayout, Select, Tabs, Tooltip、EChartsReact

## 数据模型

- `rankConfig` / `rankData` / `bubbleData` 等 CDN JSON 组合加载

## 特殊交互与状态

- 可折叠区块、多 Tab 切换不同竞争视角
- 气泡与排行配置联动

## 设计决策

- 与首页等页复用同一套排行配置 JSON 形态，降低 mock 维护成本。

## slug: content-asset

<!-- metadata
slug: content-asset
title: 域内传播
group: 洞察诊断 · 品牌资产
references: references/workshop/content-asset.tsx
workshop_entry: docs-pages/workshop/content-asset.md
status: implemented
blocks_used: [page-header, radar-with-metrics-panel, ranking-list, quadrant-scatter, wordcloud-section]
-->

# 域内传播 页面知识

## 业务目标

在「品牌资产」下分析品牌在微信域内的传播表现：雷达综合指标、趋势、矩阵散点、品牌排名与关键词云，支撑内容资产运营决策。

## 导航路径

如翼平台 → 洞察诊断 → 品牌资产 → 域内传播

## 页面类型

多段仪表盘（雷达 + 趋势 + 散点 + 列表 + 词云）

## 区块组装

实现上为 **页面头 + 多段 ECharts / 表格 / 词云** 内联拼装；注册表中的 `radar-with-metrics-panel`、`wordcloud-section` 等对应 **建议抽离区块**（⚡），当前逻辑仍在 `content-asset.tsx` 内。

### 使用的区块

| 区块 | slug | 用法 |
|------|------|------|
| 页面头 | page-header | 标题、筛选、时间范围 |
| 雷达+指标 | radar-with-metrics-panel | 多指标雷达与侧栏指标（候选区块） |
| 排行列表 | ranking-list | 品牌排名与高亮当前品牌 |
| 矩阵散点 | quadrant-scatter | 四象限/散点矩阵 |
| 词云 | wordcloud-section | 品牌关键词云（候选区块） |

### 使用的组件

Button, DateRangePicker, RuyiLayout, Select, Tooltip、EChartsReact、WordCloud（react-d3-cloud）

## 数据模型

- 单 CDN JSON（见文件 `CDN_URL`）驱动雷达、趋势、散点、排行、词云等段落

## 特殊交互与状态

- 与 dmp-web `contentAsset` 模块字段与布局对齐（见源码分段注释）
- 词云与矩阵、排行共享同一套 mock 语义字段

## 设计决策

- 域内与域外（`outside`）对称拆分两个 workshop 文件，便于分别迭代与文档站入口。

## slug: conversion-review

<!-- metadata
slug: conversion-review
title: 转化复盘
group: 全域度量
references: references/workshop/conversion-review.tsx
workshop_entry: docs-pages/workshop/conversion-review.md
status: implemented
blocks_used: [review-master-detail-layout, report-list, conversion-metrics, conversion-trend, crowd-table-view, crowd-bar-chart]
-->

# 转化复盘页面知识

## 业务目标

展示广告投放的转化效果数据，帮助广告主进行投放结案复盘和效果评估。

## 导航路径

全域度量 > 结案复盘 > 转化复盘

## 页面类型

数据报表页（Master-Detail）

## 区块组装

```
RuyiLayout（全域度量导航）
└── 内容区
    ├── 左侧报告列表（ScrollArea + 搜索 + 报告项列表 + 分页）
    └── 右侧报告详情
        ├── 报告标题 + 状态标签 + 操作按钮（下载|复制创建|更多，竖线分隔）
        │   └── 「完整配置信息 >」链接 → 打开右侧 Drawer
        ├── Tab 切换（概览/资产广度/深度/偏好度/健康持久度/配置信息）
        ├── [概览Tab] 转化概览 ← Module 卡片（rounded-12px + Header）
        │   ├── Header（DashedLabel 标题 + Button light medium「参考系：本品历史均值」）
        │   ├── 摘要文本（触达人数/曝光次数/花费等关键数据）
        │   ├── 左栏：6个指标卡（DashedLabel + Tooltip 口径说明）
        │   │   ├── 广告转化人数 / 人群转化率 / 人均转化成本（元）
        │   │   └── 广告转化次数 / 转化率 / 广告转化频次
        │   └── 右栏：环形图（广告转化占比 + 单次/多次转化人数）
        ├── [概览Tab] 转化人数趋势 ← Module 卡片
        │   ├── Header（DashedLabel 标题 + chevron-down 下拉箭头）
        │   └── 柱线混合图（广告转化次数[蓝柱] + 其他转化次数[灰柱] + 转化率[橙线 #e37318]）
        ├── [概览Tab] 触点分析 ← Module 卡片
        │   ├── Header（DashedLabel 标题 + 3个 Button light 筛选 + 图表/表格切换）
        │   └── 水平条形图（触点名称 + 人群转化率% + 转化人数条）
        ├── [概览Tab] 曝光频次分析 ← Module 卡片
        │   ├── Header（DashedLabel 标题 + 2个 Button light 指标筛选）
        │   └── 柱线混合图（曝光人数[蓝柱] + 人群转化率[橙线 #e37318]）
        ├── [概览Tab] 人群分析 ← Module 卡片
        │   ├── Header（DashedLabel 标题 + 2个 Button light 指标筛选 + 图表/表格切换）
        │   └── 带条形的对比表格（人群名称 + 转化率 + 转化成本条形图）
        ├── [配置信息Tab] 报告配置详情（同 Drawer 内容）
        └── [Drawer] 报告配置信息（480px 右侧抽屉）
            ├── 基本信息（计算期/分析目标/报告名称）
            ├── 广告配置（合约/互选/竞价 Tab + 账户表格）
            ├── 转化配置（转化时长/转化来源）
            └── 人群配置（性别年龄/行业类目/预设人群）
```

### 使用的组件

Button, Drawer, Icon, Input, Pagination, RuyiLayout, ScrollArea, Table, Tabs, Tooltip

### 自定义组件模式

- **DashedLabel**：虚线下划线装饰组件，用于所有可交互/可解释的指标标签。支持 `tooltip` 参数，hover 时展示计算口径说明。在转化概览模块的标题、指标名称、环形图图例标签上统一使用。

## 数据模型

- **报告项 (ReportItem)**：id、title（报告名称）、reportId、computeTime（计算时间）
- **概览指标 (OverviewMetrics)**：label、value、sub（对比基准描述，可为空）
- **趋势数据 (TrendData)**：date、adConv（广告转化）、otherConv（其他转化）、rate（转化率%）
- **触点数据 (TouchpointData)**：name、rate（转化率%）、count（转化人数）
- **曝光频次 (ExposureData)**：freq（频次）、count（人数）、rate（转化率%）
- **人群数据 (CrowdData)**：name、count（人群转化率）、rate（人均转化成本）、cost
- **环形图**：总转化人数(8,080)、广告转化占比(60.02%)、单次转化(3,980人)、多次转化(870人)

## 特殊交互与状态

- 左右分栏：左侧报告列表（窄列320px），右侧报告详情（宽列flex-1）
- 左侧报告列表可搜索、筛选、分页
- 选中态：左侧当前选中的报告高亮（bg-blue-1 + text-blue-6）
- Tab 切换：概览Tab展示图表分析，配置信息Tab展示只读配置详情
- **「完整配置信息 >」**：信息行末尾的快捷入口，点击打开 Drawer 展示配置内容
- **Drawer（480px）**：右侧抽屉面板，复用 ConfigContent 组件
- 触点分析：Button light 筛选（层级/参考系/指标）+ 图表/表格视图切换
- 触点条形图行 hover 高亮（bg-blue-1）
- 曝光频次分析：Button light 筛选（指标1/指标2），折线色 #e37318
- 人群分析：Button light 筛选（指标1/指标2）+ 图表/表格视图切换
- **DashedLabel tooltip**：指标标签 hover 展示计算口径说明
- 环形图展示广告转化与非广告转化的占比
- **操作按钮竖线分隔**：「下载数据 | 复制创建 | 更多」之间用 1px 竖线分隔

## 设计决策

- 采用「主-详」（master-detail）布局，左侧窄列放报告列表，右侧宽列放详情
- 概览Tab优先展示，包含最关键的5个分析区块，从全局指标到细分维度逐层深入
- **统一 Module 卡片容器**：所有分析区块统一使用 `rounded-[12px] bg-white overflow-hidden` + 64px Header + DashedLabel 标题 + Button light 筛选
- **筛选控件从 Select 改为 Button light**：所有筛选器统一使用 `Button light size="medium"`，视觉更统一
- **转化概览用带 header 的卡片模块**：标题区（DashedLabel 装饰 + 参考系按钮 medium）+ 摘要行 + 左指标右环形图的双栏内容
- **DashedLabel 设计模式**：所有可交互标签统一使用虚线下划线（border-dashed border-black-8）替代传统的 help-circle 图标，减少视觉噪音的同时保留 tooltip 交互
- **操作按钮用竖线分隔**：w-px h-5 bg-black-4 mx-2，视觉上更紧凑
- **配置信息双入口**：Tab 内全量展示 + 信息行快捷 Drawer 入口
- 环形图放在指标卡右侧，使用 188×188 尺寸的 SVG，图例用方块（rounded-sm）而非圆点
- 趋势图使用柱线混合：柱形表示绝对量（广告/其他），折线表示转化率变化趋势
- 触点分析用水平条形图而非竖向柱图，因为触点名称较长需要水平空间
- 曝光频次分析揭示频次与转化率的关系，帮助优化频控策略
- 人群分析用紧凑行表格+内嵌条形，兼顾数据密度和可视化对比


## 关联区块

| 区块 | 知识文件 | 用途 |
|------|---------|------|
| 转化概览 | [`conversion-metrics`](../../p2-block-catalog/rules/conversion-metrics.md) | 转化指标摘要 + 环形图 + 6 宫格指标卡 |
| 转化趋势 | [`conversion-trend`](../../p2-block-catalog/rules/conversion-trend.md) | 转化人数/次数趋势堆叠柱线图 |
| 触点分析 | [`touchpoint-analysis`](../../p2-block-catalog/rules/touchpoint-analysis.md) | 触点横向条形图 |
| 方案列表 | [`report-list`](../../p2-block-catalog/rules/report-list.md) | Master-Detail 左侧列表面板 |

## slug: create-audience

<!-- metadata
slug: create-audience
title: 新建人群
group: 人群策略
references: references/workshop/create-audience.tsx
workshop_entry: docs-pages/workshop/create-audience.md
status: implemented
blocks_used: [page-header, ai-brief-input]
-->

# 新建人群页面知识

## 业务目标

从多种数据源（标签列表、人群夹、过往人群包）选择人群，设置组合规则（并集/交集），生成自定义人群包。

## 导航路径

人群策略 > 自定义人群 > 新建人群

## 页面类型

配置管理页

## 区块组装

```
RuyiLayout（人群策略导航 — 推荐人群/自定义人群/数据接入）
└── 内容区 (flex gap-4)
    ├── 左面板 (flex-1, 白色卡片)
    │   ├── 标题栏（返回按钮 + "新建人群"）
    │   ├── 源选择 Tab（从标签列表中选择 | 从人群夹中选择 | 从过往人群包中选择）
    │   ├── 筛选栏（人群来源 Dropdown + 添加时间 Dropdown）
    │   └── 人群列表（Checkbox + 人群来源 + 提取条件 + 添加时间）
    └── 右面板 (w-380px, 白色卡片)
        ├── 标题栏（"设置组合规则" + 预计覆盖人数）
        ├── 定向人群区
        │   ├── 组合规则卡片（组内并集/组内交集 切换）
        │   │   ├── 标签规则详情
        │   │   ├── 人群夹规则详情
        │   │   └── 人群包规则详情
        │   └── 添加组合按钮
        ├── 排除人群区（空态 + 添加排除人群链接）
        ├── 人群属性表单（名称 + 描述）
        └── 底部操作栏（预计覆盖人数 + 新建人群按钮）
```

### 使用的区块

| 区块 | slug | 用法 |
|------|------|------|
| AI 智选搜索条 + 结果面板 | `ai-brief-input` | `import { AISearchBar, AISearchResultPanel } from '../blocks/ai-brief-input'`（与 `create-audience.tsx` 同目录层级）；标签 Tab 顶栏 `PanelTags` 内 `flex-col gap-[14px]` 组合 |
| 源选择 Tab | — | 内联实现，三等分 Tab 按钮组 |
| 人群列表 | — | 内联实现，Checkbox 行列表 |
| 组合规则面板 | — | 内联实现，可堆叠的规则卡片 |

### 使用的组件

Button, Checkbox, Dialog, Dropdown, Icon, Input, Pagination, RuyiLayout, Select, Table, Tooltip；标签 Tab 顶栏 **AISearchBar**（内部为 ODN `AutoComplete`，见区块 `ai-brief-input` reference）

## 数据模型

- **人群条目 (CrowdItem)**：key、source（来源）、condition（提取条件）、date（添加时间）、checked
- **组合规则 (CombinationRule)**：id、mode（union/intersect）、label（标签名）、labelDetail、folder（人群夹名）、folderDetail、pack（人群包名）、packDetail
- **覆盖人数**：根据选中人群条目实时计算

## 特殊交互与状态

- 三种人群源 Tab 切换（标签列表/人群夹/过往人群包），人群夹默认选中
- 左侧列表全选 / 单选 Checkbox
- 选中行蓝色高亮
- 右侧组合规则：组内并集/组内交集模式切换按钮组
- 多个组合可堆叠，支持添加/删除
- 定向人群 + 排除人群分区
- 底部「新建人群」按钮触发 Dialog 弹窗
- Dialog 弹窗：人群名称（必填, maxLength 10）+ 人群描述（maxLength 30）+ 有效期（必填）

## 设计决策

- 左右双栏布局（选择 + 规则），实时联动
- 人群夹 Tab 默认选中，符合最高频使用场景
- 组合规则用蓝色边框卡片突出当前编辑状态
- 组内并集/交集用按钮组而非 Dropdown，减少操作步骤
- 空态用 inbox 图标 + 引导文案，降低认知成本
- 返回按钮在标题前方，维持页面层级感


## 关联区块

本页面由 ODN 基础组件从零搭建，未引用已注册区块。

## slug: custom-audience-list

<!-- metadata
slug: custom-audience-list
title: 自定义-人群列表
group: 人群策略
references: references/workshop/custom-audience-list.tsx
workshop_entry: docs-pages/workshop/custom-audience-list.md
status: implemented
blocks_used: [page-header]
-->

# 人群列表页面知识

## 业务目标

管理广告主已创建的人群包，支持按状态/类型筛选、搜索人群，点击查看人群详情面板（含人群规则、授权记录）。

## 导航路径

人群策略 > 自定义人群 > 人群列表

## 页面类型

列表页（Master-Detail）

## 区块组装

```
RuyiLayout（人群策略导航 — 推荐人群/自定义人群/数据接入）
└── 内容区 (flex gap-0)
    ├── 左面板 (flex-1)
    │   ├── 警告提示栏（有效期管理提醒）
    │   └── 白色卡片容器
    │       ├── Tab 栏（我的人群 / 待接收人群）+ 操作按钮
    │       ├── 筛选栏（状态 Dropdown + 类型 Dropdown + 搜索 Input）
    │       ├── Table（人群ID + 人群名称，行可点击）
    │       └── Pagination
    └── 右面板 (w-480px, 条件渲染)
        └── 人群详情面板
            ├── 头部：人群名 + 状态标签 + ID/创建时间 + 规模
            ├── 来源/类型/属性 标签行
            ├── 人群描述
            ├── Tabs（人群规则 / 授权记录）
            └── 规则卡片列表（按来源分组）
```

### 使用的区块

| 区块 | slug | 用法 |
|------|------|------|
| 警告提示栏 | — | 内联实现，orange 色系提示 |
| 数据表格 | — | Table + Pagination + 行点击 |
| 人群详情面板 | `crowd-detail-panel` | 右侧详情面板，展示人群完整信息 + 规则 + 授权记录 |

### 使用的组件

Button, Dropdown, Icon, Input, Pagination, RuyiLayout, ScrollArea, Table

## 数据模型

- **人群记录 (CrowdRecord)**：crowdId、name、status（在线/计算中/离线/已过期）、type（行为人群/标签人群/一方人群/AI智选/人群夹）、source（一方人群/DMP/Lookalike/人群夹）、scale、supportBid、selfBuilt、useQuota、createdAt、description、rules
- **人群规则 (CrowdRule)**：source（来源类型）、details（key-value 对列表）
- **状态颜色映射**：online=绿色、computing=蓝色、offline=灰色、expired=红色

## 特殊交互与状态

- 我的人群 / 待接收人群 Tab 切换
- 按状态/类型 Dropdown 筛选
- 点击行或人群名称打开右侧详情面板
- 详情面板内 Tab 切换人群规则 / 授权记录
- 人群规则按来源分组，卡片式展示
- 已选中行蓝色高亮

## 设计决策

- Master-Detail 布局：左列表 + 右详情面板，避免页面跳转
- 导航重构为推荐人群/自定义人群/数据接入三组
- 顶部 orange 色警告栏提示人群包有效期管理
- 表格极简两列（ID + 名称），详情全部在右面板展示
- 详情面板人群规则按来源分组，每组独立卡片


## 关联区块

| 区块 | 知识文件 |
|------|---------|
| 人群详情面板 | [`crowd-detail-panel`](../../p2-block-catalog/rules/crowd-detail-panel.md) |

## slug: home

<!-- metadata
slug: home
title: 首页
group: 首页 / 工作台
references: references/workshop/home.tsx
workshop_entry: docs-pages/workshop/home.md
status: implemented
blocks_used: []
-->

# 首页 页面知识

## 业务目标

如翼平台工作台入口：展示品牌资产与核心经营指标的摘要视图，含排行榜与趋势，帮助用户快速掌握整体态势并下钻到洞察诊断等模块。

## 导航路径

如翼平台 → 首页（顶栏高亮「首页」，无左侧菜单）

## 页面类型

仪表盘 / 工作台

## 区块组装

当前实现为 **全内联**：品牌资产雷达组、核心指标 6 宫格、趋势折线图、排行榜等均在 `home.tsx` 内用 ECharts 与 ODN 组件拼装，未引用 `p2-block-catalog` 区块。

### 使用的区块

| 区块 | slug | 用法 |
|------|------|------|
| — | — | 无独立区块 import，后续若抽离模块可登记到 block-catalog |

### 使用的组件

Button, Cascader, DatePicker, DateRangePicker, Icon, RuyiLayout, Select, Tabs, Tooltip、EChartsReact

## 数据模型

- CDN 聚合：`rankConfig` / `rankData` / `trendData` / `viewData`（见文件内 `CDN_URLS`）
- 排行榜、趋势、视图配置与业务侧 JSON 结构对齐

## 特殊交互与状态

- 日期与筛选维度联动图表与排行
- 与洞察诊断等模块的导航衔接由顶栏与业务入口承担

## 设计决策

- 保持 workshop 自包含：`NAV_ITEMS` / 布局不与其他 references 共享，便于单独演示首页体验。

## slug: icon-source-violation

<!-- metadata
slug: icon-source-violation
title: 图标来源违规修复
group: 基础设施
references: references/workshop/icon-source-violation.tsx
workshop_entry: docs-pages/workshop/icon-source-violation.md
status: infrastructure
blocks_used: []
-->

# 图标来源违规修复 页面知识

## 业务目标

**回归验证样本**：在如翼壳下复现「图标来源不合规」等场景，便于检查 Icon 使用规范、替换路径与表格/Tab 表现（与真实业务页解耦）。

## 导航路径

文档站「评测」→ 回归验证 → 图标来源违规修复

## 页面类型

回归用列表 / Tab 页

## 区块组装

内联 Table、Tabs、筛选与分页；不引用 block-catalog。

### 使用的区块

| 区块 | slug | 用法 |
|------|------|------|
| — | — | 无区块 import |

### 使用的组件

Button, Icon, Input, Pagination, RuyiLayout, Table, Tabs

## 数据模型

- 表格行 mock：用于触发图标展示与来源标注场景

## 特殊交互与状态

- 文档 frontmatter 的 `prompt` / `skill` 与回归用例对齐（现为多步骤投放配置），以 **本 rules + 源码行为** 为准

## 设计决策

- 保持最小业务语义，专注组件与资源路径审计。

## slug: industry-opportunity-mind

<!-- metadata
slug: industry-opportunity-mind
title: 行业心智格局
group: 洞察诊断 · 品牌心智
references: references/workshop/industry-opportunity-mind.tsx
workshop_entry: docs-pages/workshop/industry-opportunity-mind.md
status: implemented
blocks_used: [page-header, ranking-list/brand, ranking-list/hot, ranking-list/surge]
-->

# 行业心智格局 页面知识

## 业务目标

展示行业品牌心智排名和心智词条热度，帮助广告主了解行业竞争格局和热门心智趋势。

## 导航路径

洞察诊断 > 品牌心智 > 行业机会心智

## 页面类型

列表页

## 区块组装

```
┌──────────────────────────────────────────────────────┐
│  Card: "行业机会心智" + [统计说明][产品手册]             │
│  日期范围: 2025-09-17 ~ 2025-10-17                    │
├──────────────┬──────────────┬────────────────────────┤
│  品牌心智榜    │  热门心智榜    │  心智飙升榜              │
│  3 香奈儿 35% │  1 杏仁酸     │  1 清洁 ↑488.88%       │
│  1 资生堂 40% │  2 抛光       │  2 提亮 ↑388.88%       │
│  2 SKII  40% │  3 保湿       │  3 三修 ↑288.88%       │
│  ...         │  ...         │  ...                   │
└──────────────┴──────────────┴────────────────────────┘
```

### 使用的区块

| 区块     | slug         | 用法                              |
| -------- | ------------ | --------------------------------- |
| 心智榜单 | ranking-list | 品牌心智榜（品牌头像 + 份额范围） |
| 心智榜单 | ranking-list | 热门心智榜（心智词条 + 量级）     |
| 心智榜单 | ranking-list | 心智飙升榜（增长率百分比）        |

### 使用的组件

Button, Card, DateRangePicker, Icon, RuyiLayout

## 数据模型

- **品牌心智榜**: 品牌名 + 品牌 Logo + 排名趋势 + 行业份额范围
- **热门心智榜**: 心智词条 + 分类标签 + TOP3 品牌 + 心智量
- **心智飙升榜**: 心智词条 + 分类标签 + 增长心智量 + 增长率百分比

## 特殊交互与状态

- 日期范围筛选
- 各行 hover 高亮背景
- 热门/飙升榜支持全部心智下拉筛选

## 设计决策

- 三榜等宽并列，一屏展示行业全貌
- 品牌榜用品牌 Logo 增强品牌辨识度
- 飙升榜增长率用绿色 ↑ 突出视觉优先级
- 页面结构极简：标题 + 筛选 + 三榜，不添加多余分析模块

## 关联区块

| 区块     | 知识文件                                                       |
| -------- | -------------------------------------------------------------- |
| 心智榜单 | [`ranking-list`](../../p2-block-catalog/rules/ranking-list.md) |

## slug: influencer

<!-- metadata
slug: influencer
title: 翼红人
group: 策略应用
references: references/workshop/influencer.tsx
workshop_entry: docs-pages/workshop/influencer.md
status: implemented
blocks_used: [page-header]
-->

# 翼红人 页面知识

## 业务目标

达人营销场景：多 Tab、复杂筛选与达人表格，支持浏览、筛选与对比达人资源，服务投放前的达人选择流程。

## 导航路径

如翼平台 → 策略应用 → 翼红人

## 页面类型

多 Tab + 筛选条 + 大表格

## 区块组装

全页 **内联**：Tab、筛选器、达人表格与分页均在单文件维护；`page-header` 为顶栏语义。

### 使用的区块

| 区块 | slug | 用法 |
|------|------|------|
| 页面头 | page-header | 顶栏与页面标题 |

### 使用的组件

以源码为准：Tabs、Table、Input、Select、DatePicker、RuyiLayout 等高密度表单与表格组合

## 数据模型

- 达人维度：粉丝量、报价、领域标签、合作状态等 mock

## 特殊交互与状态

- 多条件筛选与 Tab 状态需同步表格数据源

## 设计决策

- 刻意做「重筛选 + 重表格」样本，用于压力测试布局与滚动区域。

## slug: insight-ip

<!-- metadata
slug: insight-ip
title: 钜如翼
group: 策略应用
references: references/workshop/insight-ip.tsx
workshop_entry: docs-pages/workshop/insight-ip.md
status: implemented
blocks_used: [page-header]
-->

# 钜如翼 页面知识

## 业务目标

为 IP 营销场景提供 **Insight 条 + IP 匹配推荐** 等能力入口，帮助在策略应用模块内完成内容与 IP 的匹配发现。

## 导航路径

如翼平台 → 策略应用 → 钜如翼

## 页面类型

配置 / 发现型业务页（内联 InsightBar + 表格）

## 区块组装

`InsightBar`、IP 推荐表格与筛选均为 **内联实现**，未拆到 block-catalog；注册表仅标 `page-header` 作为统一顶栏语义。

### 使用的区块

| 区块 | slug | 用法 |
|------|------|------|
| 页面头 | page-header | 返回、标题与顶栏上下文 |

### 使用的组件

以 `insight-ip.tsx` 为准：RuyiLayout、表格与表单相关 ODN 组件

## 数据模型

- IP 列表与匹配度等 mock 字段

## 特殊交互与状态

- Insight 条与下方推荐表格联动筛选

## 设计决策

- 保持单文件自包含，便于与真实 dmp-web 钜如翼模块对照迭代。

## slug: interest-preference-crowd

<!-- metadata
slug: interest-preference-crowd
title: 兴趣精选
group: 人群策略
references: references/workshop/interest-preference-crowd.tsx
workshop_entry: docs-pages/workshop/interest-preference-crowd.md
status: implemented
blocks_used: [page-header, crowd-pick-card-grid]
-->

# 兴趣精选 页面知识

## 业务目标

在推荐人群下按 **兴趣** 维度展示机会人群卡片，支持浏览、筛选与分页，与行业优选、主题甄选形成同一套推荐人群体验。

## 导航路径

如翼平台 → 人群策略 → 推荐人群 → 兴趣精选

## 页面类型

Tab + 卡片网格 + 筛选分页

## 区块组装

与 `r-zero-crowd` 同构：**内联卡片网格**；注册表统一记为 `crowd-pick-card-grid`（候选区块）。

### 使用的区块

| 区块 | slug | 用法 |
|------|------|------|
| 页面头 | page-header | 标题与上下文 |
| 人群精选卡片网格 | crowd-pick-card-grid | Tab + 卡片 + 分类筛选 + 分页（候选区块） |

### 使用的组件

与行业优选页同类：Button, Card, Icon, Input, Pagination, RuyiLayout, Tabs 等（以源码为准）

## 数据模型

- 兴趣维度 mock 人群列表与分页状态

## 特殊交互与状态

- 侧边菜单 key 与路由 slug 在本文件内独立维护

## 设计决策

- 三页（行业/兴趣/主题）代码结构刻意对齐，便于未来抽成单一区块 + 配置驱动。

## slug: merchant-review

<!-- metadata
slug: merchant-review
title: 招商复盘
group: 全域度量
references: references/workshop/merchant-review.tsx
workshop_entry: docs-pages/workshop/merchant-review.md
status: implemented
blocks_used: [review-master-detail-layout, report-list]
-->

# 招商复盘 页面知识

## 业务目标

结案复盘下的 **招商复盘**：较营销复盘更轻量，以报告列表 + 详情区为主，聚焦招商合作相关结案指标（mock）。

## 导航路径

如翼平台 → 全域度量 → 结案复盘 → 招商复盘

## 页面类型

Master-Detail（简版）

## 区块组装

与 `review`、`conversion-review` **同构左侧导航 + 主从布局**；详情区内联组件为主，`review-master-detail-layout` 为候选区块名。

### 使用的区块

| 区块 | slug | 用法 |
|------|------|------|
| 复盘主从布局 | review-master-detail-layout | 左列表右详情（候选区块） |
| 报告列表 | report-list | 招商结案报告列表 |

### 使用的组件

Button, Icon, Input, Pagination, RuyiLayout, ScrollArea, Tabs

## 数据模型

- 列表与详情字段以文件内 mock / 本地 state 为主（较营销复盘数据面更窄）

## 特殊交互与状态

- 与营销复盘、转化复盘共用菜单路由切换逻辑

## 设计决策

- 作为三件套中最简一页，用于验证「仅 report-list + 简单详情」仍保持布局一致。

## slug: mind

<!-- metadata
slug: mind
title: 搜索洞察
group: 洞察诊断 · 市场洞察
references: references/workshop/mind.tsx
workshop_entry: docs-pages/workshop/mind.md
status: implemented
blocks_used: [page-header, quadrant-scatter, ranking-list, wordcloud-section]
-->

# 搜索洞察 页面知识

## 业务目标

围绕搜索行为与心智份额，展示矩阵、排行、趋势与词云，支撑「搜一搜」相关心智与机会挖掘。

## 导航路径

如翼平台 → 洞察诊断 → 市场洞察 → 搜索洞察

## 页面类型

Sticky 顶栏 + 矩阵 + 排行 + 趋势 + 词云

## 区块组装

页面头支持 **sticky**；矩阵、排行、趋势、词云在单文件内联实现，`wordcloud-section` 等为注册表与 block-catalog 规划对齐的 slug。

### 使用的区块

| 区块 | slug | 用法 |
|------|------|------|
| 页面头 | page-header | 顶部筛选与标题区（sticky） |
| 心智矩阵 | quadrant-scatter | 搜索场景下的心智矩阵视图（`MatrixScatterChart` 变体） |
| 排行列表 | ranking-list | 搜索相关排行 |
| 词云 | wordcloud-section | 搜索词云（候选区块） |

### 使用的组件

Button, Checkbox, Dropdown, Icon, Input, Popover, RuyiLayout, Select, Tooltip、EChartsReact、WordCloud

## 数据模型

- `shareRank` / `trend` / `cloud` 等 CDN 分片加载

## 特殊交互与状态

- 词云与 `outside` 等页复用自定义 WordCloud 封装思路
- 多筛选与矩阵联动

## 设计决策

- 顶栏 sticky 保证长页滚动时上下文不丢失。

## slug: mindshare-detail

<!-- metadata
slug: mindshare-detail
title: 心智详情-本品牌
group: 洞察诊断 · 品牌心智
references: references/workshop/mindshare-detail.tsx
workshop_entry: docs-pages/workshop/mindshare-detail.md
status: implemented
blocks_used: [page-header, metrics-overview, ranking-list/brand, mindshare-dictionary]
-->

# 心智详情 – 本品牌 页面知识

## 业务目标

展示单个心智词条在本品牌视角下的详细分析，包括心智量趋势、品牌竞争排名、热词分布和人群画像洞察。

## 导航路径

如翼平台 → 洞察诊断 → 品牌心智 → 心智详情

## 页面类型

详情页（Detail）

## 区块组装

```
┌─────────────────────────────────────────────────────────┐
│  ← 返回  心智词条名  分类标签  │  页面人群  粉丝分析  内容分析  │
├─────────────────────────────────────────────────────────┤
│  全市场  品品牌  日期范围  周报表                           │
├──────────────────────────┬──────────────────────────────┤
│  心智概况                  │  心智品牌榜                    │
│  品牌心智量 3,945,516      │  品牌 + Logo + 趋势 + 进度条   │
│  四维心智分布条             │  9 项排名                      │
│  SVG 折线趋势图            │                                │
├──────────────────────────┴──────────────────────────────┤
│  心智词典                                                  │
│  ┌── 左：热词榜 ──────────┬── 右：词云图 ──────────────┐  │
│  │  序号 / 词条 / 渗透率    │  文字大小 ∝ 词频             │  │
│  └──────────────────────┴────────────────────────────┘  │
├─────────────────────────────────────────────────────────┤
│  心智人群洞察                                              │
│  AI 人群描述文本 + 核心关键词标签                            │
│  雷达图（12 维度兴趣分布）                                  │
│  Tab 切换面板：                                            │
│  人群基础属性 | 行业买方人群 | 品牌核心兴趣 | ...            │
│  多列 bar / line 图表                                     │
└─────────────────────────────────────────────────────────┘
```

## 数据模型

| 字段 | 类型 | 说明 |
|------|------|------|
| keyword | string | 当前心智词条名（如"清洗"）|
| category | string | 词条分类（如"大品牌心智/流量利用率"）|
| mindshareVolume | number | 品牌心智量 |
| trendData | TrendPoint[] | 心智量趋势数据 |
| distSegments | DistSegment[] | 四维心智分布（触达/互动/分享/搜索）|
| brandRanking | BrandRankItem[] | 心智品牌榜 |
| hotWords | WordItem[] | 热词榜数据 |
| wordCloud | WordCloudItem[] | 词云数据 |
| crowdInsight | CrowdInsightData | 人群画像洞察 |

## 特殊交互与状态

- 返回箭头导航回心智度量页
- SVG 折线图 hover 显示数据点 + 辅助线
- 品牌榜当前品牌蓝色高亮
- 词云 hover 放大效果
- 人群洞察底部 Tab 切换图表组
- 图表支持 bar / line 两种类型

## 设计决策

- 心智概况 + 品牌榜左右并排，快速对比竞争位置
- 词云与热词表左右对照，直觉化 + 结构化双视角
- 人群洞察三层递进：文本描述 → 雷达图 → 多维度 Tab 图表
- 雷达图中心标注人群核心标签（如"年轻科技爱好者"）


## 关联区块

| 区块 | 知识文件 | 用途 |
|------|---------|------|
| 心智概况 | [`metrics-overview`](../../p2-block-catalog/rules/metrics-overview.md)（变体） | 品牌心智量 + 四维分布 + 趋势图 |
| 心智品牌榜 | [`ranking-list`](../../p2-block-catalog/rules/ranking-list.md)（变体） | 品牌 Logo + 趋势 + 进度条排名 |
| 心智词典 | 内联实现 | 热词表格 + 词云图 |
| 心智人群洞察 | 内联实现 | 雷达图 + Tab 图表面板 |

## slug: multi-step-config

<!-- metadata
slug: multi-step-config
title: 多步骤投放配置
group: 策略应用
references: references/workshop/multi-step-config.tsx
workshop_entry: docs-pages/workshop/multi-step-config.md
status: implemented
blocks_used: [page-header]
-->

# 多步骤投放配置 页面知识

## 业务目标

分步完成投放配置：**目标与预算** → **定向与出价** → **预览确认**，步骤间可前进/后退且保留已填信息，降低复杂表单的认知负担。

## 导航路径

如翼平台 → 策略应用 → 多步骤投放配置（示例流）

## 页面类型

分步向导（Stepper + 分步表单）

## 区块组装

步骤指示器与各步表单 **内联**；注册表以 `page-header` 统一定位顶栏区块。

### 使用的区块

| 区块 | slug | 用法 |
|------|------|------|
| 页面头 | page-header | 顶栏与返回 |

### 使用的组件

Button, Card, Checkbox, DatePicker, Icon, Input, RuyiLayout, Select、步骤相关布局组件（以源码为准）

## 数据模型

- 每步表单字段聚合在 React state（mock）

## 特殊交互与状态

- 后退不丢已填字段；最后一步汇总展示

## 设计决策

- 作为高风险流程样本放在评测分组文档中，便于与其它表单类 workshop 页对照评审。

## slug: outside

<!-- metadata
slug: outside
title: 域外扩散
group: 洞察诊断 · 品牌资产
references: references/workshop/outside.tsx
workshop_entry: docs-pages/workshop/outside.md
status: implemented
blocks_used: [page-header, radar-with-metrics-panel, wordcloud-section]
-->

# 域外扩散 页面知识

## 业务目标

分析品牌在微信域外的扩散与口碑：雷达、趋势、口碑饼图、词云等，与「域内传播」形成域内/域外对照。

## 导航路径

如翼平台 → 洞察诊断 → 品牌资产 → 域外扩散

## 页面类型

多段分析页（雷达 + 折线 + 饼图 + 词云）

## 区块组装

与 `content-asset` 类似，核心可视化均为 **内联实现**；注册表中 `radar-with-metrics-panel`、`wordcloud-section` 为与 block-catalog 对齐的 **候选区块名**。

### 使用的区块

| 区块 | slug | 用法 |
|------|------|------|
| 页面头 | page-header | 标题与筛选 |
| 雷达+指标 | radar-with-metrics-panel | 域外雷达视图（候选区块） |
| 词云 | wordcloud-section | 域外关键词云（候选区块） |

### 使用的组件

Button, DateRangePicker, Icon, RuyiLayout, Select, Tooltip、ECharts、EChartsReact、WordCloud

## 数据模型

- 单 CDN JSON（`CDN_URL`）驱动全页段落

## 特殊交互与状态

- 口碑分布为独立饼图段落（内联）
- 增长率、洞察提示等辅助渲染与 dmp-web `outside` 对齐

## 设计决策

- 雷达轴标签采用 ECharts `indicator.name` 控制密度，减轻重叠。

## slug: r-zero-crowd

<!-- metadata
slug: r-zero-crowd
title: 行业优选
group: 人群策略
references: references/workshop/r-zero-crowd.tsx
workshop_entry: docs-pages/workshop/r-zero-crowd.md
status: implemented
blocks_used: [page-header, crowd-pick-card-grid]
-->

# 行业优选 页面知识

## 业务目标

在推荐人群下，按 **行业** 维度浏览与筛选系统优选人群卡片，支持分类、分页与搜索，为后续投放或人群包操作提供入口。

## 导航路径

如翼平台 → 人群策略 → 推荐人群 → 行业优选

## 页面类型

Tab + 卡片网格 + 筛选分页

## 区块组装

卡片网格、分类筛选与分页为 **内联实现**；`crowd-pick-card-grid` 为注册表规划的 **候选区块**（与兴趣精选、主题甄选、AI 智选页结构同类）。

### 使用的区块

| 区块 | slug | 用法 |
|------|------|------|
| 页面头 | page-header | 页面标题与说明 |
| 人群精选卡片网格 | crowd-pick-card-grid | Tab + 分类 + 卡片网格 + 分页（候选区块） |

### 使用的组件

Button, Card, Icon, Input, Link, Pagination, RuyiLayout, Tabs、NotificationPopoverTrigger（演示用）

## 数据模型

- 人群卡片：名称、标签、规模、渗透率等 mock 字段
- 分页与 Tab 驱动列表子集

## 特殊交互与状态

- 与 `interest-preference-crowd` / `theme-selection-crowd` 共享同类布局范式，菜单 key 独立维护

## 设计决策

- 使用 `clsx` 处理卡片网格与 Tab 的样式组合，保持与兄弟页视觉一致。

## slug: r0-audience-market

<!-- metadata
slug: r0-audience-market
title: 推荐人群市场
group: 人群策略
references: references/workshop/crowd-market.tsx
workshop_entry: docs-pages/workshop/r0-audience-market.md
status: implemented
blocks_used: [page-header, ripple-chart, crowd-card-list]
-->

# 推荐人群市场 页面知识

## 业务目标

在人群策略模块中，为广告主提供系统推荐的高价值机会人群市场。通过涟漪图可视化人群相似度关系，通过卡片列表按行业/兴趣/主题分类浏览和搜索推荐人群。

## 路由对齐（dmp-web）

线上如翼（dmp-web）页面路由为 **r0AudienceMarket**；本仓库 workshop 预览路径为 **`/workshop/r0-audience-market`**（kebab-case），与线上一致便于对照还原。

## 导航路径

人群策略 > 推荐人群 > 推荐人群市场

## 页面类型

涟漪图+双视图页

## 区块组装

```
┌──────────────────────────────────────────────┐
│  Card: "推荐人群市场" + 指引链接              │ ← PageHeader
├──────────────────────────────────────────────┤
│  Card: [品牌 R3 ▾] 的相似人群探索             │
│  ┌────────────────────────────────────┐      │
│  │        涟漪图 / 表格视图            │      │ ← RippleChart
│  └────────────────────────────────────┘      │
├──────────────────────────────────────────────┤
│  Card: [行业优选][兴趣精选][主题甄选][我的收藏] │
│  ┌─────┐ ┌─────┐ ┌─────┐                    │
│  │卡片 1│ │卡片 2│ │卡片 3│  ← 3 列网格       │ ← CrowdCardList
│  └─────┘ └─────┘ └─────┘                    │
│  [分页器]                                    │
└──────────────────────────────────────────────┘
```

### 使用的区块

| 区块 | slug | 用法 |
|------|------|------|
| 页面头部 | page-header | Card.Header 模式，"推荐人群市场" 标题 + 使用指引链接 |
| 涟漪图 | ripple-chart | 品牌人群源选择器 + 同心圆涟漪图 + 表格双视图 |
| 人群列表 | crowd-card-list | 分类 Tab + 筛选排序搜索 + 卡片/表格视图切换 |

### 使用的组件

Button, Card, Icon, Input, Pagination, RuyiLayout, Select, Tooltip

## 数据模型

- **核心人群**: 品牌 5R 模型的某个阶段（R1-R5 或自定义人群），含人群规模数值
- **相似人群**: 围绕核心人群散布的机会人群，包含人群名称、规模（大/中/小）、相似度（低/中/高）
- **人群卡片**: 包含人群名称、标签（热投/热览/最新/行业）、R3 流入率、人群渗透率、人群规模（万人）、收藏状态
- **自定义人群**: 人群ID、名称、量级、计算状态（成功/失败/计算中/未计算）、计算时间

## 特殊交互与状态

- 品牌人群源选择器：下拉面板含 品牌人群资产 / 自定义人群 两个 Tab，品牌人群直接选择 R1-R5，自定义人群通过表格选择（支持状态筛选和搜索）
- 涟漪图中的散点支持 hover 显示 Tooltip（含人群名、规模、投放次数、洞察次数、相似度、渗透率）
- 涟漪图 / 列表双视图切换（menu/grid 按钮组），列表模式含多列排序
- 卡片列表支持按行业优选/兴趣精选/主题甄选/我的收藏分类切换
- 支持行业筛选（Select prefix）、排序方式切换、人群名称搜索
- 卡片 / 表格视图切换 + 多列排序 + 分页 + 收藏（star 图标）

## 设计决策

- 涟漪图使用蓝色色阶（blue-4/5/6）同时编码相似度，圆点大小编码人群规模
- 同心圆提供视觉层次感，中心圆采用 blue-6 实心填充突出核心人群
- 卡片标签使用不同语义色区分类型：橙色=热投，浅蓝=热览，蓝色=最新，灰色=行业
- 页面整体采用 gap-4 间距分隔各区块
- 品牌人群源选择器用下拉面板而非 Select，因为自定义人群需要表格展示状态


## 关联区块

| 区块 | 知识文件 |
|------|---------|
| 涟漪图 | [`ripple-chart`](../../p2-block-catalog/rules/ripple-chart.md) |
| 人群列表 | [`crowd-card-list`](../../p2-block-catalog/rules/crowd-card-list.md) |

## slug: regional-insight

<!-- metadata
slug: regional-insight
title: 区域洞察
group: 洞察诊断 · 市场洞察
references: references/workshop/regional-insight.tsx
workshop_entry: docs-pages/workshop/regional-insight.md
status: implemented
blocks_used: [page-header, store-insight-panel]
-->

# 区域洞察 · 门店客源分析

## 页面定位

基于地图的门店客源分析工具，帮助广告主发现门店周边高价值区域并推荐最优投放位置。

## 区块组装

| 顺序 | 区块 | 组件 |
|------|------|------|
| 1 | 筛选面板（独立白色卡片 rounded-12px） | 纯文本标题切换 + Button light 操作 |
| 2 | 筛选区 | 一体式选择器（关联门店 flex-1）+ 自定义 border 选择器 + 展开/收起 |
| 3 | 展开筛选 | 渗透率趋势/职住模式/距离限制 border 选择器 |
| 4 | 内容面板（独立白色卡片 rounded-12px） | 左右分栏 |
| 5 | 左侧门店列表 | 门店卡片 rounded-8px（名称/类型/地址/高价值区域数量/Checkbox） |
| 6 | 左侧推荐区域列表（下钻） | 排名标记 + 渗透率 + 地址 + 星级 |
| 7 | 右侧地图区 | 地图底图 + 城市气泡标记 + 推荐等级图例(rgba色) + 比例尺 |
| 8 | 气泡详情卡 | 类目/地址/距离/推荐等级 + 渗透率趋势折线图 |

## 关键交互

- **门店列表**：Checkbox 多选，支持"全选"；点击门店卡片下钻到推荐区域
- **门店下钻**：切换左侧为该门店推荐的高价值区域列表（排名1-5），显示预估渗透率、地址、推荐等级
- **返回**：下钻状态下左上角返回箭头回到门店列表
- **地图气泡**：点击橙色城市气泡选中/取消，选中放大
- **详情卡片**：点击推荐区域在地图右上弹出详情卡（类目、地址、距离门店、推荐等级、渗透率趋势折线图）
- **渗透率趋势**：折线图展示近30天渗透率变化，hover 显示具体日期和数值
- **筛选展开**：点击"展开更多"显示渗透率趋势/职住模式/距离限制，"收起"折叠
- **推荐等级图例**：右下角显示1-5星的颜色映射

## 设计决策

- 双面板布局：筛选面板和内容面板为两个独立白色卡片（rounded-12px），gap-16px
- Tab 标题从 Tabs 组件改为纯文本标题 + font-weight 切换
- 筛选控件从 Select 组件改为自定义 border 选择器样式
- "关联门店" 选择器占满剩余宽度（flex-1），内联显示已选门店文本
- 左右分栏：左侧门店/区域列表（360px），右侧地图区（flex-1）
- 门店卡片使用 rounded-8px + border-black-6
- 推荐等级使用星级（1-5★）+ rgba 透明色块（紫/绿/黄/橙/红）双编码
- 详情卡片固定在地图右上角，包含渗透率趋势微型折线图


## 关联区块

| 区块 | 知识文件 | 用途 |
|------|---------|------|
| 门店洞察面板 | [`store-insight-panel`](../../p2-block-catalog/rules/store-insight-panel.md) | 门店客源分析面板 |

## slug: review

<!-- metadata
slug: review
title: 营销复盘
group: 全域度量
references: references/workshop/review.tsx
workshop_entry: docs-pages/workshop/review.md
status: implemented
blocks_used: [review-master-detail-layout, report-list]
-->

# 营销复盘 页面知识

## 业务目标

结案复盘下的 **营销复盘** Master-Detail：左侧报告列表，右侧多 Tab（概览、资产广度/深度、偏好度、持久度、配置信息等）展示结案数据，与招商复盘、转化复盘共享导航结构。

## 导航路径

如翼平台 → 全域度量 → 结案复盘 → 营销复盘

## 页面类型

Master-Detail + 多 Tab 详情

## 区块组装

布局与列表在实现上多为 **内联**；注册表使用 `review-master-detail-layout`（候选区块）与 `report-list` 描述与 `conversion-review` / `merchant-review` 一致的三件套结构。

### 使用的区块

| 区块 | slug | 用法 |
|------|------|------|
| 复盘主从布局 | review-master-detail-layout | 左列表右详情整体壳（候选区块） |
| 报告列表 | report-list | 结案报告条目与切换 |

### 使用的组件

Button, Card, Icon, Input, Pagination, RuyiLayout, ScrollArea, Tabs

## 数据模型

- 单 CDN JSON（`DATA_URL`）驱动报告列表与详情 Tab 内容

## 特殊交互与状态

- 子菜单在营销/招商/转化复盘间跳转（`MENU_ROUTES` 映射 slug）

## 设计决策

- 与 `merchant-review`、`conversion-review` 保持相同侧栏与主从比例，仅右侧 Tab 与指标不同。

## slug: spuAudienceAsset

<!-- metadata
slug: spuAudienceAsset
title: 商品人群资产
group: 洞察诊断 · 品牌资产
references: references/workshop/spuAudienceAsset.tsx
workshop_entry: docs-pages/workshop/spuAudienceAsset.md
status: implemented
blocks_used: [page-header, metric-card-group, dual-ranking-list, penetration-analysis, quadrant-scatter]
-->

# 商品人群资产（SPU人群资产）页面知识

## 业务目标

以 SPU（商品）为粒度，展示 5R 人群资产规模与结构，帮助广告主定位具体商品的人群渗透表现和竞争排名。

## 导航路径

如翼平台 → 洞察诊断 → 品牌资产 → 商品人群资产

## 页面类型

仪表盘页（Dashboard）

## 区块组装

```
┌─────────────────────────────────────────────────────┐
│  商品人群资产 标题 + 添加人群 + 下载数据               │
│  商品筛选 | 按月 | 日期 | 参考系                      │
├─────────────────────────────────────────────────────┤
│  资产概览 · 5R 指标卡组（总资产 + R1~R5）             │
│  5R 分布条                                           │
├──────────────────────┬──────────────────────────────┤
│  本品牌 同类目 SPU     │  本行业 同类目 SPU            │
│  人群总资产榜           │  人群总资产榜                 │
├──────────────────────┴──────────────────────────────┤
│  推荐人群 渗透分析                                    │
│  ┌── 左：子弹图 ──────┬── 右：品牌+行业排名 ──────┐  │
│  │  各人群渗透率       │  渗透率榜 × 2             │  │
│  └───────────────────┴──────────────────────────┘  │
├─────────────────────────────────────────────────────┤
│  品牌排名分布 · 四象限散点                             │
│  潜力盘 | 机会盘 | 探索盘 | 突破盘                    │
└─────────────────────────────────────────────────────┘
```

## 数据模型

| 字段 | 类型 | 说明 |
|------|------|------|
| spuId | string | 商品 SPU ID |
| 5R metrics | MetricItem[] | 总资产 + R1~R5 各阶段数值 |
| distribution | DistItem[] | 5R 分布占比 |
| brandRank | RankItem[] | 品牌同类目 SPU 排名 |
| industryRank | RankItem[] | 行业同类目 SPU 排名 |
| crowdPenetration | CrowdItem[] | 推荐人群渗透率数据 |
| scatterData | BrandDot[] | 四象限散点品牌坐标 |

## 特殊交互与状态

- 商品选择器支持分类搜索
- 渗透分析左侧人群行点击切换右侧排名榜
- 四象限散点 hover 高亮品牌点
- 双列排名当前 SPU 蓝色高亮行

## 设计决策

- 5R 色彩体系与品牌人群资产页完全一致
- 双列排名用品牌 vs 行业对比，当前 SPU 用蓝底高亮
- 渗透分析子弹图 + 基准线双编码
- 四象限以 R3 流入率 × 资产占比定位品牌位置


## 关联区块

| 区块 | 知识文件 | 用途 |
|------|---------|------|
| 资产指标卡组 | [`metric-card-group`](../../p2-block-catalog/rules/metric-card-group.md) | 5R 人群总资产 + 分布条 |
| 双列排名榜 | [`dual-ranking-list`](../../p2-block-catalog/rules/dual-ranking-list.md) | 品牌/行业 同类目 SPU 排名 |
| 渗透分析面板 | [`penetration-analysis`](../../p2-block-catalog/rules/penetration-analysis.md) | 推荐人群渗透率子弹图 + 排名 |
| 四象限散点 | [`quadrant-scatter`](../../p2-block-catalog/rules/quadrant-scatter.md) | 品牌排名分布 |

## slug: table-empty-state

<!-- metadata
slug: table-empty-state
title: 表格空状态修复
group: 基础设施
references: references/workshop/table-empty-state.tsx
workshop_entry: docs-pages/workshop/table-empty-state.md
status: infrastructure
blocks_used: []
-->

# 表格空状态修复 页面知识

## 业务目标

**回归验证样本**：模拟人群/计划类 **长表格 + 筛选 + 空数据** 场景，验证 `Empty`、分页与筛选联动在如翼布局下的表现，避免空状态错位或留白异常。

## 导航路径

文档站「评测」→ 回归验证 → 表格空状态修复

## 页面类型

表格列表（空状态重点）

## 区块组装

内联 `Table`、`Empty`、`Select`、分页；无 block-catalog。

### 使用的区块

| 区块 | slug | 用法 |
|------|------|------|
| — | — | 无区块 import |

### 使用的组件

Button, Empty, Input, Pagination, RuyiLayout, Select, Table

## 数据模型

- 支持切换「有数据 / 无数据」或筛选结果为空等状态（以源码为准）

## 特殊交互与状态

- 重点观察筛选后无行、首屏 Empty 与表头对齐

## 设计决策

- 与真实 `ai-smart-crowd` 等表格页共享视觉密度目标，但不耦合业务字段。

## slug: theme-selection-crowd

<!-- metadata
slug: theme-selection-crowd
title: 主题甄选
group: 人群策略
references: references/workshop/theme-selection-crowd.tsx
workshop_entry: docs-pages/workshop/theme-selection-crowd.md
status: implemented
blocks_used: [page-header, crowd-pick-card-grid]
-->

# 主题甄选 页面知识

## 业务目标

在推荐人群下按 **主题** 维度聚合机会人群，支持卡片浏览与分页，完成「行业 / 兴趣 / 主题」三件套中的主题侧。

## 导航路径

如翼平台 → 人群策略 → 推荐人群 → 主题甄选

## 页面类型

Tab + 卡片网格 + 筛选分页

## 区块组装

**内联** 实现，与 `r-zero-crowd`、`interest-preference-crowd` 共享 `crowd-pick-card-grid` 语义（候选区块）。

### 使用的区块

| 区块 | slug | 用法 |
|------|------|------|
| 页面头 | page-header | 标题与说明 |
| 人群精选卡片网格 | crowd-pick-card-grid | 主题 Tab + 卡片网格 + 分页（候选区块） |

### 使用的组件

以 `theme-selection-crowd.tsx` 实际 import 为准（Card、Pagination、RuyiLayout、Tabs 等）

## 数据模型

- 主题维度人群卡片 mock 数据

## 特殊交互与状态

- 菜单与「行业优选」「兴趣精选」并列，独立 `MENU_ITEMS`

## 设计决策

- 与兄弟页保持相同间距与卡片密度，降低用户跨 Tab 认知成本。
