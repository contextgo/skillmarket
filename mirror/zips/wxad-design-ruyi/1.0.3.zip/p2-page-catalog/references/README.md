# Workshop 页面源码

页面实现与 mock 数据位于 **`references/workshop/`**（skills 内自包含）。

- **依赖清单**：`references/MANIFEST.json`（预计算每个页面的区块 + 数据依赖，**先读这个，不需要扫描 import**）
- 页面源码：`references/workshop/<slug>.tsx`
- mock 数据：`references/workshop/data/<name>.json`（已裁剪为精简版，数组 ≤5 条）
- 页面注册表：`references/workshop/workshopModules.ts`
- 规格文档：`skills/p2-page-catalog/rules.md`
- 文档站入口：`docs-pages/workshop/<slug>.md`
