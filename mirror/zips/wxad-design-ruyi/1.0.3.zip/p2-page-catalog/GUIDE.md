---
name: page-catalog
description: >-
  页面目录知识包。记录所有已落地的如翼 workshop 完整页面的业务语境、区块组成、
  文件位置。供 page-extend（从页面出发改造）、design-analyst（识别参考页面）、
  design-spec（组装页面时参考已有页面）、page-implement（代码生成时参考完整实现）
  共享引用。与 p2-block-catalog 对称——区块是零件，页面是成品。
user-invocable: false
---

# 页面目录知识包

## 流程位置

```
PHASE 2 · 知识检索
角色：页面知识源（完整业务页面库）
被引用方：
  - page-extend（"从页面出发"模式的主要消费者，直接读 references 做增量改造）
  - design-analyst（识别需求是否对应已有页面 / 可参考页面）
  - design-spec（从已有页面中抽区块组合思路）
  - page-implement（代码生成时参考已有完整实现）
同层：one-design（组件知识）、block-catalog（区块知识）、business-knowledge（业务术语）
```

### 协作流水线

```
                        主流水线（模式 B · 从区块拼装）
用户输入 → design-analyst → design-spec → page-implement → audit → polish
              ↑                ↑              ↑
         one-design       block-catalog   page-catalog
         business-knowledge page-catalog   block-catalog
                           （本 skill）   （本 skill）

                        新增流水线（模式 A · 从页面出发）
用户输入 → page-extend（直接改各 rule `references`，即 `src/workshop/<slug>.tsx`）→ audit → polish
              ↑
         page-catalog（本 skill）
         block-catalog（查可新增的区块）
```

### 既有页面：推荐先做「拉项目 + 路由对照」

改**已实现**的 workshop 页时，不必从读文件开始猜 UI——优先在运行态对齐需求：

1. **工作区**：创建项目后在项目根目录打开工程（见 `SKILL.md`「创建项目」）。
2. **路由**：模板使用 React Router，页面路径为 **`/<slug>`**，与下方注册表、`rules.md` 的 `slug` 一致。本地开发服务由维护者自行启动后，在浏览器打开 `http://<host>:<port>/<slug>` 即可直达该页。
3. **slug ↔ 源码文件**：多数为 `<slug>.tsx`；若文件名与 slug 不一致，以 **`references/workshop/workshopModules.ts`** 里的 `WORKSHOP_SLUG_TO_IMPORT` 为准（例如 `r0-audience-market` → `crowd-market.tsx`，`spu-audience-asset` → `spuAudienceAsset.tsx`）。
4. **源码位置**：所有 workshop 页面源码的唯一真源在 **`references/workshop/<slug>.tsx`**（本 skills 目录内自包含）。
5. **与文档站区别**：dumi 文档站为 **`/workshop/<slug>`**，模板独立跑时为 **`/<slug>`**。

对照完界面与交互后，再读 `rules.md` 中对应 slug 章节 + `references` 指向的源码做 **page-extend**。

---

## 核心概念：页面 vs 区块 vs 组件

| 维度       | 组件 (Component)         | 区块 (Block)                                      | 页面 (Page)                                         |
| ---------- | ------------------------ | ------------------------------------------------- | --------------------------------------------------- |
| 粒度       | 原子级 UI 元素           | 由多个组件组合而成的业务模块                      | 由多个区块 + 业务语境组合而成的完整 UI              |
| 来源       | `one-design-next` npm 包 | `references/blocks/<slug>.tsx`（skills 内自包含） | `references/workshop/<slug>.tsx`（skills 内自包含） |
| 复用范围   | 全局通用                 | 特定业务场景，跨页面复用                          | 单一业务场景，不复用（但可作为参考 / 模板）         |
| 数据       | 无业务语义               | 包含 mock 数据和业务逻辑                          | 完整 mock 数据 + RuyiLayout + 导航                  |
| 文档站入口 | `docs-pages/components/` | `docs-pages/block/<slug>.md`                      | `docs-pages/workshop/<slug>.md`                     |
| 示例       | `Button`、`Table`        | `metrics-overview`、`sankey-chart`                | `brand-mind-dashboard`、`conversion-review`         |

**页面不复用代码**，但它是两种设计流程的**核心参考资产**：

- 模式 A：产品同学在现有页面上做 feature → 直接编辑 **`references/workshop/<slug>.tsx`**
- 模式 B：AI 做新页面 → 参考已有 workshop 里的"区块拼装方式"和"业务语境处理"

---

## 页面分组体系

35 个 workshop 页面按**业务上下文**聚成 7 组 + 1 组非业务页。组内页面共享模块，组间几乎不共享。

### 1. 首页 / 工作台

独立的品牌总览入口，无左侧菜单。

### 2. 洞察诊断 · 品牌资产

SPU / 品牌维度的人群资产分析，核心是 5R 模型。

### 3. 洞察诊断 · 品牌心智

品牌在行业中的心智量、心智份额、词频分析。

### 4. 洞察诊断 · 市场洞察

竞争格局、搜索洞察、区域洞察等外部视角。

### 5. 人群策略

人群精选（行业/兴趣/主题三件套）、推荐市场、新建/画像/AI 智选。

### 6. 策略应用

钜如翼、翼红人、广告计划、定向配置等投放前的准备。

### 7. 全域度量

营销复盘、转化复盘、招商复盘三件套（Master-Detail + Tab 结构一致）。

### 8. 基础设施 / 回归验证（非业务页）

账号设置、评测仪表盘、图标违规、色值漂移、表格空状态等。

---

## 页面注册表

所有已落地的 workshop 页面在此注册。每次新增页面后必须同步更新此表。

### 字段约定

- `slug`: 页面唯一标识，对应 `rules.md` 中的 `## slug: <slug>` 章节与 `references/workshop/<slug>.tsx`
- `页面名`: 中文标题（来自 workshop md frontmatter 的 `title`）
- `分组`: 上述 7 大分组之一
- `一级导航 / 二级菜单`: 如翼平台的导航位置
- `区块组成`: 页面引用的区块（`import` 或内联近似实现都算），用于反推区块复用度
- `references`：`rules.md` 各章节 metadata 中填写 `references/workshop/<slug>.tsx`，指向 skills 内自包含的源码
- `rules`: 页面规格文档（业务语境、交互说明、区块组合解释）

> **slug ↔ 文件名**：多数一致（`home` → `home.tsx`）。不一致时查 [`references/workshop/workshopModules.ts`](../references/workshop/workshopModules.ts) 的 `WORKSHOP_SLUG_TO_IMPORT`。

### 1 · 首页 / 工作台

| slug   | 页面名 | 一级导航 | 二级菜单 | 区块组成                                                                                   | workshop            | rules                |
| ------ | ------ | -------- | -------- | ------------------------------------------------------------------------------------------ | ------------------- | -------------------- |
| `home` | 首页   | 首页     | —        | （内联）首页-品牌资产雷达组、（内联）核心指标 6 宫格、（内联）趋势折线图、（内联）排行榜组 | `workshop/home.tsx` | `rules.md#slug-home` |

### 2 · 洞察诊断 · 品牌资产

| slug               | 页面名       | 一级导航 | 二级菜单 | 区块组成                                                                                                                    | workshop                        | rules                            |
| ------------------ | ------------ | -------- | -------- | --------------------------------------------------------------------------------------------------------------------------- | ------------------------------- | -------------------------------- |
| `brand5r`          | 品牌人群资产 | 洞察诊断 | 品牌资产 | `page-header` + `metric-card-group` + `touchpoint-analysis` + `penetration-analysis` + （内联）5R 结构条 + （内联）趋势分析 | `workshop/brand5r.tsx`          | `rules.md#slug-brand5r`          |
| `spuAudienceAsset` | 商品人群资产 | 洞察诊断 | 品牌资产 | `page-header` + `metric-card-group` + `dual-ranking-list` ×2 + `penetration-analysis` + `quadrant-scatter`                  | `workshop/spuAudienceAsset.tsx` | `rules.md#slug-spuAudienceAsset` |
| `asset-flow`       | 品牌资产流转 | 洞察诊断 | 品牌资产 | `page-header` + （内联）资产流转筛选卡 + `sankey-chart` + `touchpoint-analysis`                                             | `workshop/asset-flow.tsx`       | `rules.md#slug-asset-flow`       |
| `content-asset`    | 域内传播     | 洞察诊断 | 品牌资产 | `page-header` + `radar-with-metrics-panel`⚡ + `ranking-list` + `quadrant-scatter` + `wordcloud-section`⚡                  | `workshop/content-asset.tsx`    | `rules.md#slug-content-asset`    |
| `outside`          | 域外扩散     | 洞察诊断 | 品牌资产 | `page-header` + `radar-with-metrics-panel`⚡ + 趋势折线 + （内联）口碑分析饼图 + `wordcloud-section`⚡                      | `workshop/outside.tsx`          | `rules.md#slug-outside`          |

### 3 · 洞察诊断 · 品牌心智

| slug                        | 页面名          | 一级导航 | 二级菜单 | 区块组成                                                                                                        | workshop                                 | rules                                     |
| --------------------------- | --------------- | -------- | -------- | --------------------------------------------------------------------------------------------------------------- | ---------------------------------------- | ----------------------------------------- |
| `brand-mind-dashboard`      | 品牌心智度量    | 洞察诊断 | 品牌心智 | `page-header` + `metrics-overview` + `ranking-list/share` + `treemap-panel` + `quadrant-scatter`（心智矩阵 ×2） | `workshop/brand-mind-dashboard.tsx`      | `rules.md#slug-brand-mind-dashboard`      |
| `mindshare-detail`          | 心智详情-本品牌 | 洞察诊断 | 品牌心智 | `page-header` + `metrics-overview` + `ranking-list/brand` + `mindshare-dictionary` + （内联）心智人群洞察       | `workshop/mindshare-detail.tsx`          | `rules.md#slug-mindshare-detail`          |
| `industry-opportunity-mind` | 行业机会心智    | 洞察诊断 | 品牌心智 | `page-header` + `ranking-list/brand` + `ranking-list/hot` + `ranking-list/surge`                                | `workshop/industry-opportunity-mind.tsx` | `rules.md#slug-industry-opportunity-mind` |

### 4 · 洞察诊断 · 市场洞察

| slug               | 页面名       | 一级导航 | 二级菜单 | 区块组成                                                                                        | workshop                        | rules                            |
| ------------------ | ------------ | -------- | -------- | ----------------------------------------------------------------------------------------------- | ------------------------------- | -------------------------------- |
| `compete-analysis` | 品牌竞争格局 | 洞察诊断 | 市场洞察 | `page-header` + `ranking-list` ×3 + `bubble-scatter-chart`⚡                                    | `workshop/compete-analysis.tsx` | `rules.md#slug-compete-analysis` |
| `mind`             | 搜索洞察     | 洞察诊断 | 市场洞察 | `page-header`（sticky）+ `quadrant-scatter` + `ranking-list` + 趋势折线 + `wordcloud-section`⚡ | `workshop/mind.tsx`             | `rules.md#slug-mind`             |
| `regional-insight` | 区域洞察     | 洞察诊断 | 市场洞察 | `page-header`（Tab 模式）+ `store-insight-panel`                                                | `workshop/regional-insight.tsx` | `rules.md#slug-regional-insight` |

### 5 · 人群策略

| slug                        | 页面名          | 一级导航 | 二级菜单   | 区块组成                                                                                                | workshop                                 | rules                                     |
| --------------------------- | --------------- | -------- | ---------- | ------------------------------------------------------------------------------------------------------- | ---------------------------------------- | ----------------------------------------- |
| `r-zero-crowd`              | 行业优选        | 人群策略 | 推荐人群   | `page-header` + `crowd-pick-card-grid`⚡（Tab + 卡片网格 + 分类筛选 + 分页）                            | `workshop/r-zero-crowd.tsx`              | `rules.md#slug-r-zero-crowd`              |
| `interest-preference-crowd` | 兴趣精选        | 人群策略 | 推荐人群   | `page-header` + `crowd-pick-card-grid`⚡                                                                | `workshop/interest-preference-crowd.tsx` | `rules.md#slug-interest-preference-crowd` |
| `theme-selection-crowd`     | 主题甄选        | 人群策略 | 推荐人群   | `page-header` + `crowd-pick-card-grid`⚡                                                                | `workshop/theme-selection-crowd.tsx`     | `rules.md#slug-theme-selection-crowd`     |
| `ai-smart-crowd`            | AI 智选         | 人群策略 | 推荐人群   | `page-header` + 人群表格 + `notification-popover`                                                       | `workshop/ai-smart-crowd.tsx`            | `rules.md#slug-ai-smart-crowd`            |
| `r0-audience-market`        | 推荐人群市场    | 人群策略 | 推荐人群   | `page-header` + `ripple-chart` + `crowd-card-list`                                                      | `workshop/crowd-market.tsx`              | `rules.md#slug-r0-audience-market`        |
| `create-audience`           | 新建人群        | 人群策略 | 自定义人群 | `page-header` + `ai-brief-input`（`AISearchBar` / `AISearchResultPanel`）+ 标签面板 / 人群夹 / 组合规则 | `workshop/create-audience.tsx`           | `rules.md#slug-create-audience`           |
| `custom-audience-list`      | 自定义-人群列表 | 人群策略 | 自定义人群 | `page-header` + 人群表格 + Tab 筛选 + 分页                                                              | `workshop/custom-audience-list.tsx`      | `rules.md#slug-custom-audience-list`      |
| `audience-profile`          | 人群画像        | 人群策略 | 自定义人群 | `page-header` + `report-list` + Tab 切换 + （内联）ChartB / ChartA                                      | `workshop/audience-profile.tsx`          | `rules.md#slug-audience-profile`          |

### 6 · 策略应用

| slug                | 页面名         | 一级导航 | 二级菜单 | 区块组成                                             | workshop                         | rules                             |
| ------------------- | -------------- | -------- | -------- | ---------------------------------------------------- | -------------------------------- | --------------------------------- |
| `insight-ip`        | 钜如翼         | 策略应用 | —        | `page-header` + （内联）InsightBar + IP 匹配推荐表格 | `workshop/insight-ip.tsx`        | `rules.md#slug-insight-ip`        |
| `influencer`        | 翼红人         | 策略应用 | —        | `page-header` + 多 Tab + 复杂筛选条 + 达人表格       | `workshop/influencer.tsx`        | `rules.md#slug-influencer`        |
| `multi-step-config` | 多步骤投放配置 | 策略应用 | —        | `page-header` + 步骤指示器 + 分步表单                | `workshop/multi-step-config.tsx` | `rules.md#slug-multi-step-config` |

### 7 · 全域度量

| slug                | 页面名   | 一级导航 | 二级菜单 | 区块组成                                                                                                                             | workshop                         | rules                             |
| ------------------- | -------- | -------- | -------- | ------------------------------------------------------------------------------------------------------------------------------------ | -------------------------------- | --------------------------------- |
| `conversion-review` | 转化复盘 | 全域度量 | 结案复盘 | `review-master-detail-layout`⚡ + `report-list` + `conversion-metrics` + `conversion-trend` + `crowd-table-view` + `crowd-bar-chart` | `workshop/conversion-review.tsx` | `rules.md#slug-conversion-review` |
| `merchant-review`   | 招商复盘 | 全域度量 | 结案复盘 | `review-master-detail-layout`⚡ + `report-list`                                                                                      | `workshop/merchant-review.tsx`   | `rules.md#slug-merchant-review`   |
| `review`            | 营销复盘 | 全域度量 | 结案复盘 | `review-master-detail-layout`⚡ + `report-list`（与转化/招商复盘同构；顶栏跳转 slug `review`）                                       | `workshop/review.tsx`            | `rules.md#slug-review`            |

### 8 · 基础设施 / 回归验证（非业务页）

| slug                    | 页面名              | 用途           | workshop                             | rules                                 |
| ----------------------- | ------------------- | -------------- | ------------------------------------ | ------------------------------------- |
| `benchmark-dashboard`   | 评测总览            | 评测数据可视化 | `workshop/benchmark-dashboard.tsx`   | `rules.md#slug-benchmark-dashboard`   |
| `icon-source-violation` | 图标来源违规修复    | 回归验证样本   | `workshop/icon-source-violation.tsx` | `rules.md#slug-icon-source-violation` |
| `color-token-drift`     | 色值 Token 漂移修复 | 回归验证样本   | `workshop/color-token-drift.tsx`     | `rules.md#slug-color-token-drift`     |
| `table-empty-state`     | 表格空状态修复      | 回归验证样本   | `workshop/table-empty-state.tsx`     | `rules.md#slug-table-empty-state`     |

> 带 ⚡ 的区块为"建议新增"状态（见 `docs-pages/dev-diary/block-audit-and-skill-workflow.md`），在本轮盘点完成前写为候选占位，确认后再落地到 `p2-block-catalog`。

---

## 发现与查询

AI 需要定位某个参考页面时，按以下顺序查找：

1. **按 slug 直接命中**：用户明确提到 `mindshare-detail` / "心智详情" / 贴了 URL → 若项目已运行 dev server，浏览器打开 **`/<slug>`** 对照现状；再加载该页 `references` + `rules.md`。无运行环境时直接读文件即可。
2. **按业务分组浏览**：用户说"做一个品牌心智相关的页面" → 扫第 3 组（洞察诊断 · 品牌心智）下的 3 个页面
3. **按导航路径匹配**：用户说"洞察诊断 > 品牌资产下加一个页面" → 扫第 2 组
4. **按区块组成反查**：用户说"要一个包含桑基图和触点分析的页面" → 扫注册表的"区块组成"列

找到目标后：

- **模式 A**（改已有页面）：只需要读 `rules.md` 的 `references` 指向的 `src/workshop/...tsx`
- **模式 B**（参考已有页面拼新页面）：读 `rules.md` 理解业务语境和区块选择逻辑，再查 `p2-block-catalog` 找匹配区块

---

## 双模式工作流

### 模式 A · 从页面出发（page-extend）

**入口信号**：用户提到现有页面 slug / 中文名 / 在 workshop 目录下操作 / 说"在 XX 页上加功能"。

**流程**：

1. 定位目标页面 slug（必要时向用户确认）；在模板工程内对应路由为 **`/<slug>`**（见上文「既有页面：推荐先做拉项目 + 路由对照」）。
2. **对照 + 读规格**（推荐顺序）：维护者已启动本地 dev 时，浏览器打开 **`/<slug>`**（或先打开 **`/catalog`** 再进入目标页）对照当前 UI；并行阅读 `rules.md` 与 frontmatter **`references`** 指向的 workshop 源码。无运行环境则只读后两者。
3. 诊断改动类型：
   - 新增模块 → 优先查 `block-catalog` 有没有匹配区块可 import；没有就内联实现
   - 修改现有模块 → 定位到文件内对应 function 做局部编辑
   - 整体重排 → 只改主入口组件的 JSX
4. 直接修改 `src/workshop/<slug>.tsx`（或该页 `references` 所指路径），不新建文件
5. dumi 文档站会通过 `docs-pages/workshop/<slug>.md` 的 `<code src>` 自动反向引用，无需额外同步

### 模式 B · 从区块拼装（design-analyst → spec → implement）

**入口信号**：用户给出功能需求/截图/Figma 链接，但**没**指向现有页面。

**流程**：

1. `design-analyst`：参考本 skill 的页面分组，识别需求最接近哪一组；参考同组已有页面的"区块组成"列，提炼可复用结构
2. `design-spec`：从 `block-catalog` 选区块，标注"直接复用 / fork / 全新"
3. `page-implement`：生成页面到用户项目的 `src/workshop/<new-slug>.tsx`，同时在 `docs-pages/workshop/<new-slug>.md` 加入口；新建 `rules.md (新增章节)` 时 frontmatter `references` 写 `references/workshop/<new-slug>.tsx`；源码同步复制到 `skills/references/workshop/`
4. 执行完成后，**必须更新本 skill 的注册表**（见下方「新增页面流程」）

---

## 新增页面流程

每次新建页面后必须同步更新本目录：

### 1. 写入源码和规格

- 源码：`skills/references/workshop/<slug>.tsx`（唯一真源）
- 规格：`skills/p2-page-catalog/rules.md`（含业务语境、交互说明、区块组合理由）
- 文档站入口：`docs-pages/workshop/<slug>.md`

### 2. 注册到本 GUIDE

在「页面注册表」对应分组表格追加新行，按上方字段约定填写。若分组不匹配现有 8 组，补充新分组。

### 3. 检查是否触发新区块

- 如果页面里有 3 个以上 workshop 页面出现的**近乎相同**模块 → 抽为新区块注册到 `p2-block-catalog`
- 如果只在本页面出现 → 内联保留，可在 `rules.md` 标注"候选区块"

### 4. 同步业务知识

- 若涉及新业务模块/新菜单项 → 更新 `p2-business-knowledge/GUIDE.md` 的"站点地图"和"业务模块"
- 若涉及新术语 → 追加到 `p2-business-knowledge/GUIDE.md` 的"行业术语表"

---

## 代码约定

页面代码遵循与区块 references 相同的编码规范：

- 首行 `'use client';`
- 组件从 `one-design-next` 或相对路径（自 workshop 目录复用区块时 `import X from '../blocks/<slug>'`）导入
- 样式：Tailwind class + ODN token（`var(--odn-color-black-12)` 等），禁止硬编码未 token 化的色值（除非对齐 workshop 现有实现）
- 数据：全部 mock，推荐用 CDN（`https://wxa.wxs.qq.com/wxad-design/yijie/*.json`）或内联常量
- **顶栏 / 菜单 / 导航逻辑内联**：每个 workshop 文件保持完全自包含，不跨文件共享 `NAV_ITEMS` / `MENU_ITEMS`，这是 workshop 的样板属性
- `Select` 组件只要使用 `prefix`，统一写成 `prefix={<span className="text-[var(--odn-color-black-9)]">...</span>}`；不要用纯字符串 `prefix="..."`，也不要用 `text-black-9` 语义类。

### 页面的可参考性要求

一个好的页面应当：

- **业务完整**：顶栏、菜单、主内容、mock 数据齐全，能独立运行
- **区块清晰**：通过 import 或清晰的 section 注释标明每块是哪个区块 / 内联实现
- **结构扁平**：业务逻辑写在顶层组件或拆到 2-3 个子组件，不过度抽象
- **单一职责**：一个 `.tsx` 一个页面，不在同一文件放多个页面

---

## 与其他 p2 知识包的关系

| 知识包                                                       | 作用                           | 本 skill 与之的关系                                                    |
| ------------------------------------------------------------ | ------------------------------ | ---------------------------------------------------------------------- |
| [`p2-block-catalog`](../p2-block-catalog/GUIDE.md)           | 区块目录（零件库）             | 页面引用区块；新增页面时顺便检查是否触发新区块                         |
| [`p2-business-knowledge`](../p2-business-knowledge/GUIDE.md) | 业务术语 / 站点地图 / 模块概念 | 页面落入哪个一级导航 / 二级菜单 / 业务模块，以 business-knowledge 为准 |
| [`p2-one-design`](../p2-one-design/GUIDE.md)                 | 组件库知识                     | 页面和区块共同依赖，本 skill 不重复描述组件                            |

### 责任划分（避免重复）

- **业务维度描述**（站点地图、业务模块、行业术语、跨页面业务关系）→ [`p2-business-knowledge`](../p2-business-knowledge/GUIDE.md) 的 `GUIDE.md` 与 `rules/mod-*.md`；人群策略总览另见 `rules.md#slug-page-audience-strategy`（无对应单页 workshop，故仍留在 business-knowledge）。
- **实现维度描述**（区块组成、交互细节、mock 数据、文档站入口与复用参考）→ **`p2-page-catalog/rules.md`**（与注册表 `slug` 一一对应，共 35 页）。
- **完整源码** → `rules.md` 的 `references`（`references/workshop/<slug>.tsx`，skills 内自包含）

> 原 `p2-business-knowledge/rules/page-*.md` 中与 workshop 页面对应的**实现规格**已迁入本目录 `rules.md`；block 盘点与 ⚡ 候选区块流程见 `docs-pages/dev-diary/block-audit-and-skill-workflow.md`。
