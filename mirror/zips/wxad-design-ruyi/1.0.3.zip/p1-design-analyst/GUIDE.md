---
name: design-analyst
description: 需求分析 Skill — 接收草稿图或需求文档，通过问题补充需求信息，从设计师视角审查合理性，输出结构化需求文档交给 design-spec 生成设计 Prompt。不写代码、不生成 Prompt。当用户提供草稿图、线框图、设计稿或说"分析这个需求"时触发。
args:
  - name: input
    description: 需求文档文字、草稿图截图或两者混合
    required: true
  - name: scope
    description: full（完整页面）/ module（单个模块）
    required: false
  - name: mode
    description: full / readonly（透传给下游 skill）
    required: false
next_skill: design-spec
next_skill_input: 结构化需求文档
requires_knowledge:
  - business-knowledge
  - block-catalog
user-invocable: true
---

# Design Analyst — 需求分析

接收需求输入，**通过提问补充需求信息**，输出结构化需求文档交给 `design-spec` skill。

**核心原则：只分析、不写代码、不生成 Prompt。** 本 skill 的输出是结构化需求文档，不是设计 Prompt，也不是 `.tsx` 文件。

## 流程位置

```
PHASE 1 · 输入与分析（上半段）
上游：用户（需求输入 — 草稿图/需求文档/口述）
下游：design-spec（本 skill 的结构化需求文档 → 设计 Prompt 生成的输入）
知识依赖：business-knowledge（通用业务知识 + 模块/页面知识）、block-catalog（识别可复用区块）
```

### 协作关系

```
                            主流水线（PHASE 1 → PHASE 3）
  用户输入 → 本 Skill ─────→ design-spec ─────→ page-implement ─→ audit ─→ polish
           （需求分析+提问）  （Prompt+区块匹配）   （代码）

       │                          │                    │
       ▼                          ▼                    ▼
  ┌────────────────────────────────────────────────────────────────┐
  │                  p2 知识层（三个并列知识包，按需消费）           │
  ├─────────────────────┬──────────────────┬───────────────────────┤
  │ business-knowledge  │ block-catalog    │ one-design            │
  │ 业务语境/导航/       │ 区块清单/复用     │ 组件/Props/            │
  │ 模块页面知识         │ 参考/新建匹配     │ 设计 token/图标        │
  │                     │                  │                       │
  │ ← 本 skill 消费      │ ← 参考知道即可    │ ← 下游 skill 消费      │
  └─────────────────────┴──────────────────┴───────────────────────┘
```

---

## 2 阶段工作流

```
输入 → [1.输入解析] → [2.设计审查+提问] → 输出结构化需求文档
                                              ↓
                                    交给 design-spec 执行
```

### 阶段 1：输入解析

从草稿图/需求文档提取：

- **页面用途**：一句话
- **目标用户**：广告主 / 服务商 / 运营
- **页面类型**：参考 `business-knowledge` 的页面类型参考
- **导航归属**：属于哪个一级导航 + 二级菜单（参考 `business-knowledge` 站点地图，然后加载对应 `rules/mod-*.md` 获取详细导航结构）
- **已有页面参考**：如果目标模块中已有页面，加载对应 `skills/p2-page-catalog/rules.md` 参考同模块页面的设计风格和区块组装方式
- **UI 元素清单**：逐区域列出，每个元素必须记录 **5 个像素级视觉特征**（容器类型、标题位置、背景色、分隔方式、数值字号），用于防止模板套偏。详细表格和常见陷阱见 [analysis-checklist.md](references/analysis-checklist.md)「步骤 2」。

### 阶段 2：设计审查 + 主动提问

**在动手前像设计师一样思考。** 详见 [analysis-checklist.md](references/analysis-checklist.md)。

核心维度：
- 全局布局完整性、信息层次、数据展示选型、缺失状态补全、交互闭环、视觉保真度

**必须主动提问以补充信息。** 输出改进建议 → **等用户确认后才交接给 design-spec**。

---

## 表格需求提问策略

当用户需求中包含表格时，**必须在阶段 2 审查时主动提问以下 5 个维度**，然后输出 2-3 个方案版本供选择。

### 5 维度提问清单

1. **结构模式** — 数据的组织方式是哪种？
   - A: 基础数据表格（行 x 列的简单网格）
   - B: 分组合并表格（首列 rowSpan 分组）
   - C: 实验对比表格（基准/实验/效果固定行）
   - D: 转置表格（指标作行、时间周期作列）
   - E: 多级表头表格（跨列分组表头 colSpan）

2. **嵌入模式** — 表格在容器中的角色？
   - Full: 表格独占整个区块
   - Embedded: 表格只是区块的一部分
   - Flat: 表格在白色区块内，区块标题是独立标题

3. **工具栏组件** — 需要哪些顶部操作？
   - 搜索框（Input + Icon search）
   - 日期选择（DatePicker）
   - 下拉筛选（Select）
   - 操作按钮（Button）
   - Tab 切换（Tabs）

4. **横切特性** — 需要哪些附加功能？
   - 排序（TableSortOrder）
   - 操作列（行内 Button / Select）
   - 批量选择（Checkbox）
   - 分页（Pagination）
   - 搜索筛选

5. **数据量** — 预估行数？
   - < 20 行：不分页
   - 20-100 行：可选分页
   - > 100 行：必须分页

### 多版本方案输出

提问后输出 2-3 个方案版本：

- **精简版**：模式 A + 仅标题，适合数据预览
- **标准版**：模式 A/D + 工具栏 + 筛选 + 操作列，适合常规数据管理
- **完整版**：模式 E + 工具栏 + 筛选 + 分页 + 排序 + Tab，适合复杂数据场景

---

## 输出格式（结构化需求文档）

阶段 2 完成并获得用户确认后，输出以下格式的结构化需求文档：

```
## 结构化需求文档

### 基本信息
- 页面名称：[名称]
- 页面类型：[仪表盘/列表页/配置页/表单页/流程页/数据分析页/消息通知页]
- 目标用户：[广告主/服务商/运营]
- 导航归属：[一级导航] > [二级菜单组] > [菜单项]

### 全局布局
- 顶栏：[有/无] — 一级导航激活项
- 左侧菜单：[有/无] — 菜单分组和激活项
- 页面背景：bg-[#f2f5fa]

### UI 元素清单（按区域）
逐区域列出所有可见的 UI 元素，每个元素标注 5 维度特征

### 用户确认的设计决策
- 容器类型选择
- 数据展示方式
- 交互模式
- 状态处理

### 审查发现
- 改进建议（已确认）
- 补充的状态和交互
```

---

## 交接协议

输出结构化需求文档后，交给 `design-spec` skill（见 frontmatter 中 `next_skill: design-spec`）。

附上以下指令：

```
## 交接给 design-spec skill

mode: [从上游继承的 mode 参数，默认 full]

以上结构化需求文档已完成，请按以下步骤执行：

1. 加载 business-knowledge 理解业务语境
2. 加载 one-design 获取组件约束（组件选型参考本 skill 的选型指南，详细 Props 查阅 one-design rules）
3. 执行全局布局识别（阶段 0）
4. 执行模块拆解 + 区块匹配（阶段 1）
5. 为每个模块生成设计 Prompt（阶段 2）
6. 完成后交接给 page-implement（透传 mode 参数）
```

## 详细参考

- 设计审查清单：[references/analysis-checklist.md](references/analysis-checklist.md)
