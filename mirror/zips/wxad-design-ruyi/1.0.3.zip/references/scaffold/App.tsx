import { BrowserRouter, Route, Routes } from "react-router-dom"
import { WorkshopPage } from "./pages/WorkshopPage"

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/:slug" element={<WorkshopPage />} />
      </Routes>
    </BrowserRouter>
  )
}
