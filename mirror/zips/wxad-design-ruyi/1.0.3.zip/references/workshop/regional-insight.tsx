'use client';

import {
  Button,
  Cascader,
  Checkbox,
  Icon,
  Input,
  RuyiLayout,
  type RuyiMenuItem,
  ScrollArea,
  Select,
  Tabs,
  Tooltip,
} from 'one-design-next';
import { useCallback, useMemo, useState } from 'react';

import aoiRecmData from './data/regional-aoi-recm.json';
import audiencesData from './data/regional-audiences.json';
import storePackagesData from './data/regional-store-packages.json';
import storesData from './data/regional-stores.json';

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

interface AoiItem {
  aoi_int_id: string;
  title: string;
  category: string;
  address: string;
  province: string;
  city: string;
  district: string;
  lat: string;
  lng: string;
  rank: number;
  score: number;
  raw_score: number;
  user_cnt: number;
  distance: number;
}

interface PoiItem {
  id: string;
  name: string;
  address: string;
  category: string;
  latitude: number;
  longitude: number;
  recm_aoi_cnt: number;
  recm_rate: number;
  recm_user_cnt: number;
}

/* ------------------------------------------------------------------ */
/*  Constants                                                          */
/* ------------------------------------------------------------------ */

const MAX_RECOMMEND_COUNT = 500;
const CROWD_MAX_RECOMMEND_COUNT = 1000;

const RECOMMEND_MODE_OPTIONS = [
  { label: '常规推荐', value: 1 },
  { label: '多门店综合', value: 2 },
];

const WORK_RESIDENCE_OPTIONS = [
  { label: '全部', value: 'all' },
  { label: '工作地', value: 'work' },
  { label: '居住地', value: 'home' },
];

const DISTANCE_OPTIONS = [
  { label: '自适应', value: 1 },
  { label: '500 米', value: 500 },
  { label: '1 公里', value: 1000 },
  { label: '2 公里', value: 2000 },
  { label: '3 公里', value: 3000 },
  { label: '5 公里', value: 5000 },
  { label: '10 公里', value: 10000 },
  { label: '30 公里', value: 30000 },
  { label: '50 公里', value: 50000 },
];

const TIPS: Record<string, string> = {
  mode: '常规推荐：对所选的每个门店分别独立进行区域推荐，各门店结果互不影响。\n多门店综合：将所选门店视为整体，综合评估后给出区域推荐。',
  domain:
    '全部：统计所有到访用户。\n工作地：仅统计在该区域工作的用户。\n居住地：仅统计在该区域居住的用户。',
  distance: '设置推荐区域与门店之间的最大搜索距离上限。自适应则不设限，由算法根据数据分布自动确定搜索范围。',
  recommendCount: '指定推荐结果的数量上限。实际可推荐数量不足时，则返回全部可用推荐。',
  heatMapScale: '控制热力图的辐射半径（0~100 米）。数值越大，热力覆盖范围越大。',
  concept:
    '预估渗透率：推荐区域中，门店目标人群占该区域总人群的比例。\n推荐等级：综合距离、渗透率、人群规模等因素的星级评价（1~5 星）。\n一方人群浓度：一方人群在推荐区域中的集中程度。',
};

/* ------------------------------------------------------------------ */
/*  Mock data                                                          */
/* ------------------------------------------------------------------ */

const firstStoreId = Object.keys(aoiRecmData.aoi_list)[0];
const aoiItems: AoiItem[] = (aoiRecmData.aoi_list as Record<string, AoiItem[]>)[firstStoreId] ?? [];
const poiItems: PoiItem[] = aoiRecmData.poi_list.filter((p) => p.id !== 'total') as PoiItem[];

const storeOptions = storesData.list.slice(0, 20).map((s) => ({
  label: s.local_store_name,
  value: s.poi_id,
  province: s.local_store_province,
  city: s.local_store_city,
}));

const storePackageOptions = storePackagesData.list.map((p) => ({
  label: `${p.local_store_package_name}（${p.local_store_list.length} 个门店）`,
  value: p.local_store_package_id,
}));

const audienceOptions = audiencesData.items.map((a) => ({
  label: a.name,
  value: a.id,
  desc: `${Number(a.user_count).toLocaleString()} 人`,
}));

const AREA_TREE = [
  {
    label: '不限',
    value: '不限',
  },
  {
    label: '北京市',
    value: '北京市',
    children: [
      { label: '朝阳区', value: '朝阳区' },
      { label: '海淀区', value: '海淀区' },
      { label: '东城区', value: '东城区' },
    ],
  },
  {
    label: '上海市',
    value: '上海市',
    children: [
      { label: '浦东新区', value: '浦东新区' },
      { label: '黄浦区', value: '黄浦区' },
    ],
  },
  {
    label: '广东省',
    value: '广东省',
    children: [
      { label: '深圳市', value: '深圳市' },
      { label: '广州市', value: '广州市' },
      { label: '惠州市', value: '惠州市' },
    ],
  },
];

/* ------------------------------------------------------------------ */
/*  Navigation                                                         */
/* ------------------------------------------------------------------ */

const NAV_ITEMS = ['首页', '洞察诊断', '人群策略', '策略应用', '全域度量', '生意'];
const MENU_ITEMS: RuyiMenuItem[] = [
  {
    key: 'market',
    label: '市场洞察',
    icon: 'search',
    children: [
      { key: 'compete-analysis', label: '竞争格局' },
      { key: 'search-insight', label: '搜索洞察' },
      { key: 'regional-insight', label: '区域洞察' },
    ],
  },
  {
    key: 'brand-asset',
    label: '品牌资产',
    icon: 'shield',
    children: [
      { key: 'brand-crowd-asset', label: '品牌人群资产' },
      { key: 'spu-crowd-asset', label: '商品人群资产' },
      { key: 'brand-asset-flow', label: '品牌资产流转' },
      { key: 'inner-spread', label: '域内传播' },
      { key: 'outer-spread', label: '域外扩散' },
    ],
  },
  {
    key: 'brand-mind',
    label: '品牌心智',
    icon: 'star',
    children: [
      { key: 'brand-mind-dashboard', label: '品牌心智度量' },
      { key: 'industry-opportunity-mind', label: '行业机会心智' },
    ],
  },
];

const MENU_ROUTES: Record<string, string> = {
  'compete-analysis': 'compete-analysis',
  'search-insight': 'mind',
  'regional-insight': 'regional-insight',
  'brand-crowd-asset': 'brand5r',
  'spu-crowd-asset': 'spu-audience-asset',
  'brand-asset-flow': 'asset-flow',
  'inner-spread': 'content-asset',
  'outer-spread': 'outside',
  'brand-mind-dashboard': 'brand-mind-dashboard',
  'industry-opportunity-mind': 'industry-opportunity-mind',
};

const NAV_ROUTES: Record<string, string> = {
  首页: 'home',
  洞察诊断: 'compete-analysis',
  人群策略: 'r-zero-crowd',
  策略应用: 'insight-ip',
  全域度量: 'review',
  生意: 'store-asset-distribution',
};

function navigateToSlug(slug: string) {
  if (typeof window === 'undefined') return;
  const url = new URL(window.location.href);
  const segments = url.pathname.replace(/\/+$/, '').split('/');
  segments[segments.length - 1] = slug;
  url.pathname = segments.join('/');
  window.location.href = url.toString();
}

/* ------------------------------------------------------------------ */
/*  Rank Stars                                                         */
/* ------------------------------------------------------------------ */

function RankStars({ score }: { score: number }) {
  const stars = score >= 0.8 ? 5 : score >= 0.6 ? 4 : score >= 0.4 ? 3 : score >= 0.2 ? 2 : 1;
  return (
    <span className="inline-flex gap-px text-[13px] leading-none">
      {Array.from({ length: 5 }, (_, i) => (
        <Icon
          key={i}
          name="star-filled"
          className={i < stars ? 'text-[#FCB04C]' : 'text-[var(--odn-color-black-6)]'}
        />
      ))}
    </span>
  );
}

/* ------------------------------------------------------------------ */
/*  Rank Badge                                                         */
/* ------------------------------------------------------------------ */

const RANK_COLORS: Record<number, string> = {
  1: 'bg-[#FF4D4F] text-white',
  2: 'bg-[#FF7A45] text-white',
  3: 'bg-[#FFC53D] text-white',
};

function RankBadge({ rank }: { rank: number }) {
  const color = RANK_COLORS[rank] ?? 'bg-[var(--odn-color-black-6)] text-[var(--odn-color-black-9)]';
  return (
    <span
      className={`inline-flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-xs font-semibold ${color}`}
    >
      {rank}
    </span>
  );
}

/* ------------------------------------------------------------------ */
/*  AOI Card                                                           */
/* ------------------------------------------------------------------ */

function AoiCard({
  item,
  active,
  checked,
  onSelect,
  onCheck,
}: {
  item: AoiItem;
  active: boolean;
  checked: boolean;
  onSelect: () => void;
  onCheck: (v: boolean) => void;
}) {
  const distanceText =
    item.distance < 1
      ? `${Math.round(item.distance * 1000)} 米`
      : `${item.distance.toFixed(1)} 公里`;

  return (
    <div
      onClick={onSelect}
      className={`cursor-pointer rounded-lg border border-solid p-3 transition-colors ${
        active
          ? 'border-[var(--odn-color-blue-6)] bg-[#F5F8FF]'
          : 'border-transparent bg-white hover:bg-[#F9FBFF]'
      }`}
    >
      <div className="flex items-start gap-2">
        <Checkbox
          checked={checked}
          onChange={(v) => {
            onCheck(v as boolean);
          }}
          onClick={(e) => e.stopPropagation()}
        />
        <div className="min-w-0 flex-1">
          <div className="mb-1 flex items-center gap-2">
            <RankBadge rank={item.rank} />
            <span className="truncate text-sm font-medium text-[var(--odn-color-black-12)]">
              {item.title}
            </span>
            <RankStars score={item.score} />
          </div>
          <div className="space-y-0.5 text-xs text-[var(--odn-color-black-9)]">
            <p className="m-0 truncate">
              <span className="text-[var(--odn-color-black-36)]">类目：</span>
              {item.category}
            </p>
            <p className="m-0 truncate">
              <span className="text-[var(--odn-color-black-36)]">地址：</span>
              {item.address}
            </p>
            <div className="flex gap-4">
              <span>
                <span className="text-[var(--odn-color-black-36)]">距门店：</span>
                {distanceText}
              </span>
              <span>
                <span className="text-[var(--odn-color-black-36)]">用户数：</span>
                {item.user_cnt.toLocaleString()}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Map Placeholder                                                    */
/* ------------------------------------------------------------------ */

function MapPlaceholder({ aoiItems: items, poi }: { aoiItems: AoiItem[]; poi?: PoiItem }) {
  const viewBox = useMemo(() => {
    if (!items.length) return { cx: 116.454, cy: 39.938, w: 0.02, h: 0.015 };
    const lngs = items.map((a) => parseFloat(a.lng));
    const lats = items.map((a) => parseFloat(a.lat));
    const cx = (Math.min(...lngs) + Math.max(...lngs)) / 2;
    const cy = (Math.min(...lats) + Math.max(...lats)) / 2;
    const w = Math.max(Math.max(...lngs) - Math.min(...lngs), 0.01) * 1.6;
    const h = Math.max(Math.max(...lats) - Math.min(...lats), 0.008) * 1.6;
    return { cx, cy, w, h };
  }, [items]);

  const AOI_COLORS = ['#296BEF', '#33D2CB', '#FCB04C', '#FF7A45', '#8B5CF6'];

  return (
    <div className="relative h-full w-full overflow-hidden rounded-lg bg-[#F0F2F5]">
      {/* Grid background */}
      <svg className="absolute inset-0 h-full w-full opacity-[0.08]">
        <defs>
          <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
            <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#8899AA" strokeWidth="0.5" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#grid)" />
      </svg>

      {/* AOI blocks */}
      <svg
        className="absolute inset-0 h-full w-full"
        viewBox={`${viewBox.cx - viewBox.w / 2} ${viewBox.cy - viewBox.h / 2} ${viewBox.w} ${viewBox.h}`}
        preserveAspectRatio="xMidYMid meet"
      >
        {items.map((aoi, i) => {
          const lng = parseFloat(aoi.lng);
          const lat = parseFloat(aoi.lat);
          const r = 0.0008 + aoi.score * 0.0012;
          return (
            <g key={aoi.aoi_int_id}>
              <circle cx={lng} cy={lat} r={r} fill={AOI_COLORS[i % AOI_COLORS.length]} opacity={0.25} />
              <circle cx={lng} cy={lat} r={r * 0.4} fill={AOI_COLORS[i % AOI_COLORS.length]} opacity={0.5} />
            </g>
          );
        })}
        {poi && (
          <g>
            <circle cx={poi.longitude} cy={poi.latitude} r={0.0005} fill="#FF4D4F" opacity={0.9} />
            <circle cx={poi.longitude} cy={poi.latitude} r={0.002} fill="#FF4D4F" opacity={0.12} />
          </g>
        )}
      </svg>

      {/* Top-left label */}
      <div className="absolute left-3 top-3 flex items-center gap-1.5 rounded-md bg-white/80 px-2.5 py-1.5 text-xs text-[var(--odn-color-black-9)] shadow-sm backdrop-blur-sm">
        <Icon name="location" className="text-sm text-[var(--odn-color-blue-6)]" />
        腾讯地图 · 区域洞察
      </div>

      {/* Legend */}
      <div className="absolute bottom-3 left-3 flex items-center gap-3 rounded-md bg-white/80 px-2.5 py-1.5 text-[11px] text-[var(--odn-color-black-9)] shadow-sm backdrop-blur-sm">
        <span className="flex items-center gap-1">
          <span className="inline-block h-2.5 w-2.5 rounded-full bg-[#FF4D4F]" /> 门店
        </span>
        <span className="flex items-center gap-1">
          <span className="inline-block h-2.5 w-2.5 rounded-full bg-[#296BEF] opacity-60" /> 推荐区域
        </span>
      </div>

      {/* Zoom controls (decorative) */}
      <div className="absolute bottom-3 right-3 flex flex-col overflow-hidden rounded-md bg-white shadow-sm">
        <button className="flex h-7 w-7 items-center justify-center border-0 bg-white text-sm text-[var(--odn-color-black-9)] hover:bg-[var(--odn-color-black-4)]">
          +
        </button>
        <div className="h-px bg-[var(--odn-color-black-6)]" />
        <button className="flex h-7 w-7 items-center justify-center border-0 bg-white text-sm text-[var(--odn-color-black-9)] hover:bg-[var(--odn-color-black-4)]">
          −
        </button>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  AOI Result Panel (模拟 retail-ai-lib 的 AoiRecommendation 布局)      */
/* ------------------------------------------------------------------ */

function AoiResultPanel({
  items,
  poi,
  title,
  summaryLabel,
}: {
  items: AoiItem[];
  poi?: PoiItem;
  title: string;
  summaryLabel: string;
}) {
  const [activeId, setActiveId] = useState<string | null>(items[0]?.aoi_int_id ?? null);
  const [checkedIds, setCheckedIds] = useState<Set<string>>(new Set());

  const toggleCheck = useCallback((id: string, v: boolean) => {
    setCheckedIds((prev) => {
      const next = new Set(prev);
      v ? next.add(id) : next.delete(id);
      return next;
    });
  }, []);

  const allChecked = items.length > 0 && checkedIds.size === items.length;
  const toggleAll = () => {
    if (allChecked) {
      setCheckedIds(new Set());
    } else {
      setCheckedIds(new Set(items.map((a) => a.aoi_int_id)));
    }
  };

  const totalUsers = poi?.recm_user_cnt ?? items.reduce((s, a) => s + a.user_cnt, 0);

  return (
    <div
      className="flex min-h-[400px] overflow-hidden rounded-lg border border-solid border-[var(--odn-color-black-6)] bg-white"
      style={{ height: 'calc(100vh - 254px)' }}
    >
      {/* 左侧列表 */}
      <div className="flex w-[360px] shrink-0 flex-col border-r border-solid border-[var(--odn-color-black-6)]">
        {/* Header */}
        <div className="sticky top-0 z-10 border-b border-solid border-[var(--odn-color-black-6)] bg-white px-4 py-3">
          <div className="flex items-center justify-between">
            <span className="text-base font-semibold text-[var(--odn-color-black-12)]">
              {title}
            </span>
            <div className="flex gap-1">
              <Button light icon="download-1" size="small">
                下载
              </Button>
              <Button light icon="copy" size="small">
                批量提取
              </Button>
            </div>
          </div>
          <p className="m-0 mt-1 text-xs text-[var(--odn-color-black-36)]">
            共 {items.length} 个推荐区域，{summaryLabel} {totalUsers.toLocaleString()} 人
          </p>
        </div>

        {/* Select all bar */}
        {checkedIds.size > 0 && (
          <div className="flex items-center justify-between bg-[var(--odn-color-blue-1)] px-4 py-2 text-xs">
            <span className="text-[var(--odn-color-blue-7)]">已选 {checkedIds.size} 个</span>
            <button
              onClick={toggleAll}
              className="border-0 bg-transparent text-xs text-[var(--odn-color-blue-7)] underline"
            >
              {allChecked ? '取消全选' : '全选'}
            </button>
          </div>
        )}

        {/* Card list */}
        <ScrollArea className="flex-1">
          <div className="flex flex-col gap-2 p-3">
            {items.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-16 text-sm text-[var(--odn-color-black-36)]">
                <Icon name="empty" className="mb-2 text-3xl text-[var(--odn-color-black-6)]" />
                请先选择门店并点击"查询"
              </div>
            ) : (
              items.map((item) => (
                <AoiCard
                  key={item.aoi_int_id}
                  item={item}
                  active={activeId === item.aoi_int_id}
                  checked={checkedIds.has(item.aoi_int_id)}
                  onSelect={() => setActiveId(item.aoi_int_id)}
                  onCheck={(v) => toggleCheck(item.aoi_int_id, v)}
                />
              ))
            )}
          </div>
        </ScrollArea>
      </div>

      {/* 右侧地图 */}
      <div className="flex-1 p-2">
        <MapPlaceholder aoiItems={items} poi={poi} />
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Filter helpers                                                     */
/* ------------------------------------------------------------------ */

function TipIcon({ tipKey }: { tipKey: string }) {
  return (
    <Tooltip content={<span className="whitespace-pre-line text-xs">{TIPS[tipKey]}</span>}>
      <Icon name="info-circle" className="ml-1 cursor-help text-sm text-[var(--odn-color-black-9)]" />
    </Tooltip>
  );
}

/* ------------------------------------------------------------------ */
/*  Store Analysis Tab                                                 */
/* ------------------------------------------------------------------ */

function StoreAnalysis() {
  const [storeMode, setStoreMode] = useState<'store' | 'package'>('store');
  const [selectedStores, setSelectedStores] = useState<string[]>([storeOptions[0]?.value]);
  const [selectedPackage, setSelectedPackage] = useState<string | undefined>(undefined);
  const [recmMode, setRecmMode] = useState(1);
  const [recommendNum, setRecommendNum] = useState('50');
  const [domain, setDomain] = useState('all');
  const [distance, setDistance] = useState<number>(1);
  const [expand, setExpand] = useState(false);
  const [searched, setSearched] = useState(true);

  return (
    <div>
      {/* Filter bar */}
      <div className="flex flex-wrap items-center gap-x-3 gap-y-4 border-t border-solid border-[#E9EBEF] bg-white px-6 py-6">
        {/* Store select */}
        <div className="w-[426px]">
          <div className="mb-2 flex items-center gap-2 text-sm">
            <button
              onClick={() => setStoreMode('store')}
              className={`cursor-pointer border-0 bg-transparent px-0 text-sm ${
                storeMode === 'store'
                  ? 'font-medium text-[var(--odn-color-blue-7)]'
                  : 'text-[var(--odn-color-black-9)] hover:text-[var(--odn-color-blue-6)]'
              }`}
            >
              关联门店
            </button>
            <span className="text-[var(--odn-color-black-6)]">|</span>
            <button
              onClick={() => setStoreMode('package')}
              className={`cursor-pointer border-0 bg-transparent px-0 text-sm ${
                storeMode === 'package'
                  ? 'font-medium text-[var(--odn-color-blue-7)]'
                  : 'text-[var(--odn-color-black-9)] hover:text-[var(--odn-color-blue-6)]'
              }`}
            >
              关联门店包
            </button>
          </div>
          {storeMode === 'store' ? (
            <Select
              mode="multiple"
              value={selectedStores}
              onChange={(v) => setSelectedStores(v as string[])}
              options={storeOptions}
              placeholder="请选择门店（最多 100 个）"
              showSearch
              maxCount={100}
            />
          ) : (
            <Select
              value={selectedPackage}
              onChange={(v) => setSelectedPackage(v as string)}
              options={storePackageOptions}
              placeholder="请选择门店包"
            />
          )}
        </div>

        {/* Recommend mode */}
        <div className="w-[280px]">
          <div className="mb-2 flex items-center text-sm text-[var(--odn-color-black-9)]">
            推荐模式
            <TipIcon tipKey="mode" />
          </div>
          <Select value={recmMode} onChange={(v) => setRecmMode(v as number)} options={RECOMMEND_MODE_OPTIONS} />
        </div>

        {/* Recommend count */}
        <div className="w-[280px]">
          <div className="mb-2 flex items-center text-sm text-[var(--odn-color-black-9)]">
            期望推荐数量
            <TipIcon tipKey="recommendCount" />
          </div>
          <Input
            type="number"
            value={recommendNum}
            onChange={(e) => {
              const v = e.target.value;
              if (v === '' || (Number(v) >= 0 && Number(v) <= MAX_RECOMMEND_COUNT)) {
                setRecommendNum(v);
              }
            }}
            placeholder={`1 ~ ${MAX_RECOMMEND_COUNT}`}
          />
        </div>

        {/* Advanced settings */}
        {expand ? (
          <>
            <div className="w-[280px]">
              <div className="mb-2 flex items-center text-sm text-[var(--odn-color-black-9)]">
                职住模式
                <TipIcon tipKey="domain" />
              </div>
              <Select value={domain} onChange={(v) => setDomain(v as string)} options={WORK_RESIDENCE_OPTIONS} />
            </div>
            <div className="w-[280px]">
              <div className="mb-2 flex items-center text-sm text-[var(--odn-color-black-9)]">
                距离限制
                <TipIcon tipKey="distance" />
              </div>
              <Select value={distance} onChange={(v) => setDistance(v as number)} options={DISTANCE_OPTIONS} />
            </div>
            <Button light onClick={() => setExpand(false)} className="self-end">
              收起
            </Button>
          </>
        ) : (
          <Button light onClick={() => setExpand(true)} className="self-end">
            高级设置
          </Button>
        )}

        {/* Query button */}
        <Button intent="primary" onClick={() => setSearched(true)} className="self-end" style={{ minWidth: 80 }}>
          查询
        </Button>
      </div>

      {/* Results */}
      <div className="mt-5 px-6 pb-6">
        {searched ? (
          <AoiResultPanel items={aoiItems} poi={poiItems[0]} title="推荐区域" summaryLabel="覆盖用户" />
        ) : (
          <div
            className="flex min-h-[400px] items-center justify-center rounded-lg bg-white text-sm text-[var(--odn-color-black-36)]"
            style={{ height: 'calc(100vh - 254px)' }}
          >
            请选择门店并点击"查询"开始分析
          </div>
        )}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  One-Party Analysis Tab                                             */
/* ------------------------------------------------------------------ */

function OnePartyAnalysis() {
  const [audienceId, setAudienceId] = useState<string | undefined>(undefined);
  const [area, setArea] = useState<(string | number)[]>(['不限']);
  const [recommendNum, setRecommendNum] = useState('500');
  const [domain, setDomain] = useState('all');
  const [heatScale, setHeatScale] = useState('20');
  const [expand, setExpand] = useState(false);
  const [searched, setSearched] = useState(false);

  return (
    <div>
      {/* Filter bar */}
      <div className="flex flex-wrap items-center gap-x-3 gap-y-4 border-t border-solid border-[#E9EBEF] bg-white px-6 py-6">
        {/* Audience select */}
        <div className="w-[426px]">
          <div className="mb-2 text-sm text-[var(--odn-color-black-9)]">一方人群包</div>
          <Select
            value={audienceId}
            onChange={(v) => setAudienceId(v as string)}
            options={audienceOptions}
            placeholder="请选择人群包"
            showSearch
            optionRender={(option) => (
              <div className="flex items-center justify-between">
                <span className="truncate">{option.label}</span>
                <span className="ml-2 shrink-0 text-xs text-[var(--odn-color-black-36)]">
                  {(option.data as { desc?: string }).desc}
                </span>
              </div>
            )}
          />
        </div>

        {/* Area */}
        <div className="w-[280px]">
          <div className="mb-2 text-sm text-[var(--odn-color-black-9)]">区域范围</div>
          <Cascader
            value={area}
            onChange={(v) => setArea(v as (string | number)[])}
            options={AREA_TREE}
            placeholder="请选择区域"
          />
        </div>

        {/* Recommend count */}
        <div className="w-[280px]">
          <div className="mb-2 flex items-center text-sm text-[var(--odn-color-black-9)]">
            期望推荐数量
            <TipIcon tipKey="recommendCount" />
          </div>
          <Input
            type="number"
            value={recommendNum}
            onChange={(e) => {
              const v = e.target.value;
              if (v === '' || (Number(v) >= 0 && Number(v) <= CROWD_MAX_RECOMMEND_COUNT)) {
                setRecommendNum(v);
              }
            }}
            placeholder={`1 ~ ${CROWD_MAX_RECOMMEND_COUNT}`}
          />
        </div>

        {/* Advanced */}
        {expand ? (
          <>
            <div className="w-[280px]">
              <div className="mb-2 flex items-center text-sm text-[var(--odn-color-black-9)]">
                职住模式
                <TipIcon tipKey="domain" />
              </div>
              <Select value={domain} onChange={(v) => setDomain(v as string)} options={WORK_RESIDENCE_OPTIONS} />
            </div>
            <div className="w-[280px]">
              <div className="mb-2 flex items-center text-sm text-[var(--odn-color-black-9)]">
                热力图辐射半径（米）
                <TipIcon tipKey="heatMapScale" />
              </div>
              <Input
                type="number"
                value={heatScale}
                onChange={(e) => {
                  const v = e.target.value;
                  if (v === '' || (Number(v) >= 0 && Number(v) <= 100)) {
                    setHeatScale(v);
                  }
                }}
                placeholder="0 ~ 100"
              />
            </div>
            <Button light onClick={() => setExpand(false)} className="self-end">
              收起
            </Button>
          </>
        ) : (
          <Button light onClick={() => setExpand(true)} className="self-end">
            高级设置
          </Button>
        )}

        <Button intent="primary" onClick={() => setSearched(true)} className="self-end" style={{ minWidth: 80 }}>
          查询
        </Button>
      </div>

      {/* Results */}
      <div className="mt-5 px-6 pb-6">
        {searched ? (
          <AoiResultPanel items={aoiItems} poi={poiItems[0]} title="推荐区域" summaryLabel="一方人群浓度" />
        ) : (
          <div
            className="flex min-h-[400px] items-center justify-center rounded-lg bg-white text-sm text-[var(--odn-color-black-36)]"
            style={{ height: 'calc(100vh - 254px)' }}
          >
            请选择人群包并点击"查询"开始分析
          </div>
        )}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Main Page                                                          */
/* ------------------------------------------------------------------ */

export default function RegionalInsight() {
  const [activeNav, setActiveNav] = useState('洞察诊断');
  const [activeMenu, setActiveMenu] = useState('regional-insight');
  const [tab, setTab] = useState('storeAnalysis');

  const navigateMenu = (key: string) => {
    const slug = MENU_ROUTES[key];
    if (slug) navigateToSlug(slug);
  };

  const navigateNav = (label: string) => {
    const slug = NAV_ROUTES[label];
    if (slug) navigateToSlug(slug);
  };

  return (
    <RuyiLayout
      navItems={NAV_ITEMS}
      activeNav={activeNav}
      onNavChange={navigateNav}
      menuItems={MENU_ITEMS}
      activeMenu={activeMenu}
      onMenuChange={navigateMenu}
      collapsible
      accountName="香奈儿/Chanel – 美妆护肤"
      accountId="25610"
      className="h-screen"
    >
      <div className="relative pt-4 rounded-xl bg-white">
        {/* Tabs */}
        <Tabs.Default
          value={tab}
          onChange={setTab}
          items={[
            { label: '门店客源分析', value: 'storeAnalysis' },
            { label: '一方人群分析', value: 'onePartyAnalysis' },
          ]}
          className="rounded-t-xl bg-white mx-6 [&_[data-odn-tab-list]]:gap-6 [&_[data-odn-tab-trigger]]:px-0 [&_[data-odn-tab-trigger]]:pb-[18px] [&_[data-odn-tab-trigger]]:text-base"
        />

        {/* Top-right actions */}
        <div className="absolute right-6 top-3 z-10 flex items-center gap-1">
          <a
            href="#"
            className="flex items-center gap-0.5 rounded-md px-3 py-[7px] text-sm text-[var(--odn-color-black-9)] no-underline hover:bg-[rgba(63,91,128,0.05)]"
          >
            <Icon name="file-text" className="text-xl" />
            使用手册
          </a>
          <Tooltip content={<span className="whitespace-pre-line text-xs">{TIPS.concept}</span>}>
            <span className="flex cursor-pointer items-center gap-0.5 rounded-md px-3 py-[7px] text-sm text-[var(--odn-color-black-9)] hover:bg-[rgba(63,91,128,0.05)]">
              <Icon name="info-circle" className="text-xl" />
              概念说明
            </span>
          </Tooltip>
        </div>

        {/* Tab content */}
        <div className="bg-[#F6F7F8]">
          {tab === 'storeAnalysis' ? <StoreAnalysis /> : <OnePartyAnalysis />}
        </div>
      </div>
    </RuyiLayout>
  );
}
