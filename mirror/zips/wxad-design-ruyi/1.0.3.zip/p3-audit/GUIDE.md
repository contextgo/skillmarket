---
name: audit
description: One Design Next 审查 — 对界面进行全面的质量审查，检查组件用法、--odn-* Design Token、无障碍、性能和响应式设计。生成带严重等级的审查报告和修复建议，不直接修改代码。
args:
  - name: area
    description: 要审查的功能区域或文件路径（可选，不指定则审查当前页面/组件）
    required: false
  - name: mode
    description: full / readonly（从上游透传，readonly 下审查正常执行但不修改文件）
    required: false
next_skill: polish
next_skill_input: 审查报告（含严重等级和修复建议）
requires_knowledge:
  - one-design
user-invocable: true
---

## 流程位置

```
PHASE 3 · 生成与审查（审查阶段）
上游：page-implement（生成的代码 → 本 skill 审查）
下游：polish（本 skill 的审查报告 → 精修的输入）
知识依赖：one-design（审查基准）
```

### 协作流水线

```
page-implement（代码生成）→ 本 Skill（质量审查）→ polish（精修）
                                  ↑
                            one-design（规则基准）
```

---

对目标区域运行系统性质量检查，生成带优先级的审查报告。**只记录问题，不修复** — 修复交给 `/polish` 或开发者手动处理。

**前置**：使用 **one-design** Skill 中的规则文件作为审查基准。

## 诊断扫描

对以下 6 个维度逐项检查：

### 1. One Design Next 规范合规性（最高优先级）

对照 one-design Skill 的关键规则逐条检查：

**组件用法（actions.md / overlays.md / data-display.md / navigation.md）**

- 是否使用了 `one-design-next` 组件而非自建 HTML
- Button 是否正确使用 `intent`、`light`、`loading`、`icon`/`rightIcon` 属性
- 表单是否用 `Form` + `Form.Item` 包裹
- Dialog 是否有 `title` prop
- Card 是否用 `Card` + `Card.Header` 组合
- Tabs 是否使用数据驱动模式（`items` + `value` + `onChange`）
- Empty / Loading 组件是否正确使用

**Design Token（design-tokens.md）**

- 是否有硬编码色值（`#296BEF`、`rgb()`）
- 是否有 Tailwind 默认色板（`text-green-500`、`bg-blue-600`）
- 是否正确使用 `--odn-*` 变量或 Tailwind 语义色（`text-black-12`、`bg-brand-6`）
- 投影是否使用 `--odn-shadow-*` 而非手写 `box-shadow`
- 字号是否使用 `--odn-font-size-*` 变量

**图标（icons.md）**

- 是否使用内置 `<Icon name="..." />`
- 是否有 `lucide-react` 或其他外部图标库残留
- Icon 是否通过 `size` prop 控制尺寸，而非 className

**间距（design-tokens.md）**

- 是否使用 `gap-*` 而非 `space-y-*` / `space-x-*`
- 颜色是否使用 ODN 映射的 Tailwind class（`text-brand-6`）而非默认色板

### 2. 无障碍（A11y）

- **对比度**：文字对比度是否 < 4.5:1
- **ARIA**：交互元素是否缺少 role、label、state
- **键盘导航**：是否有缺失的 focus 指示器、不合理的 tab 顺序
- **语义 HTML**：标题层级是否正确、是否用 div 代替了 button
- **Alt 文字**：图片是否缺少描述
- **表单**：输入框是否缺少 label、错误提示是否清晰

### 3. 性能

- **渲染性能**：是否在循环中读写布局属性
- **动画性能**：是否动画了 layout 属性（width/height）而非 transform/opacity
- **优化缺失**：图片是否缺少 lazy loading
- **包体积**：是否有不必要的 import、未使用的依赖
- **React 性能**：是否有不必要的 re-render、缺少 memo

### 4. 响应式

- **固定宽度**：是否有硬编码宽度导致移动端溢出
- **触摸目标**：交互元素是否 < 44x44px
- **水平滚动**：内容是否在窄视口下溢出
- **文字缩放**：布局是否在文字放大时崩溃

### 5. 主题一致性

- **Token 混用**：是否混用了 `--odn-*` 变量和硬编码值
- **色板混用**：是否混用了 ODN Tailwind 语义色和默认 Tailwind 色板
- **投影混用**：是否混用了 `--odn-shadow-*` 和手写 shadow

### 6. 代码质量

- **调试代码**：console.log、debugger
- **死代码**：注释掉的代码块
- **类型安全**：TypeScript `any`、`@ts-ignore`
- **导入路径**：组件是否从 `one-design-next` 导入

## 审查报告格式

### One Design Next 合规判定

**首先给出总体判定：**

- ✅ **合规** — 符合 One Design Next 规范
- ⚠️ **基本合规** — 有少量问题需修复
- ❌ **不合规** — 存在系统性的规范违规

列出具体的违规项，引用对应的 rules 文件。

### 摘要

- 发现的问题总数（按严重等级统计）
- 最关键的 3-5 个问题
- 建议的修复优先级

### 详细发现（按严重等级）

每个问题记录：

```
[严重/高/中/低] 分类名
位置：文件路径:行号
问题：具体描述
影响：对用户的影响
规则：违反了哪条规则（引用 one-design/rules/ 文件）
建议：如何修复
```

#### 🔴 严重（阻塞发布）

功能性问题、WCAG A 级违规、核心规范违规（外部图标库、缺少 Form.Item）

#### 🟠 高（需尽快修复）

显著的可用性/无障碍影响、WCAG AA 违规、Design Token 滥用

#### 🟡 中（下个迭代修复）

质量问题、性能优化点、非核心的规范偏离

#### 🟢 低（有空修复）

细节优化、代码风格统一

### 系统性问题

识别反复出现的问题模式：

- "15 处使用了硬编码色值，应统一使用 --odn-\* Token 或 Tailwind 语义色"
- "所有表单都缺少 Form + Form.Item 包裹"
- "图标使用了 lucide-react，应替换为内置 Icon 组件"

### 正面发现

记录做得好的地方，作为最佳实践参考。

### 修复建议

按优先级排列可执行的修复计划：

1. **立即修复**：严重阻塞项
2. **本轮迭代**：高严重度问题
3. **下轮迭代**：中等质量改善
4. **长期优化**：低优先级的打磨项

如果问题较多，建议使用 `/polish` 进行系统性修复。

## 审查原则

- **只记录，不修复** — 审查和修复分开，保持报告客观性
- **有影响才记录** — 每个问题都要说清楚"对用户有什么影响"
- **严重等级一致** — 同类问题给同样的等级，不要一高一低
- **不要遗漏正面发现** — 好的做法值得记录和推广
- **不要虚报** — 确认是真正的问题才记录，不要为了凑数量
- **有意偏差豁免** — 若区块文档（`.md`）的「设计偏差」章节已记录某个非 token 值（如硬编码色值、非标准圆角），且代码中的使用位置与记录一致，视为设计稿还原的有意偏差，**不报违规**。仅当代码中的偏差值未在「设计偏差」表中登记时才报告
