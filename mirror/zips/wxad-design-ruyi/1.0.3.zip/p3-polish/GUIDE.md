---
name: polish
description: One Design Next 精修 — 发布前的最终质量检查。逐项修复间距、颜色、组件用法、交互状态等细节问题，让界面从"能用"变成"好用"。
args:
  - name: target
    description: 要精修的功能区域或文件路径（可选，不指定则精修当前页面/组件）
    required: false
  - name: mode
    description: full（直接修复代码）/ readonly（仅输出修复建议，不修改文件）
    required: false
next_skill: null
next_skill_input: null
requires_knowledge:
  - one-design
user-invocable: true
---

## 流程位置

```
PHASE 3 · 生成与审查（精修阶段）
上游：audit（审查报告 → 本 skill 的精修依据）
下游：无（精修完成即可发布）
知识依赖：one-design（精修依据）
```

### 协作流水线

```
audit（质量审查）→ 本 Skill（精修）→ 发布
                       ↑
                 one-design（规则依据）
```

---

## 前置条件

使用 **one-design** Skill 中的设计规则作为精修依据。精修前确保功能已完成——不要精修未完成的功能。

---

对目标区域进行系统性的最终精修，修复所有影响质量的细节问题。

## 精修前评估

1. **确认完成度**：功能是否已完整实现？有无已知的未完成项（标记 TODO）？
2. **确认质量标准**：MVP 级别还是旗舰级别？什么时候发布？
3. **识别精修区域**：通读代码，标记所有"感觉不太对"的地方。

## 系统性精修

按以下维度逐项检查和修复：

### 1. One Design Next 组件用法

**最高优先级 — 这是组件库特有的。**

- [ ] 所有组件从 `one-design-next` 导入
- [ ] 图标使用内置 `<Icon name="..." />`，无 `lucide-react` 或其他外部图标库残留
- [ ] Icon 通过 `size` prop 控制尺寸，不用 className 设置宽高
- [ ] Button 使用 `icon` / `rightIcon` 属性放图标，不作为 children
- [ ] Button 加载态使用 `loading` 属性，不手动组合 Icon + spin
- [ ] Button 轻量风格使用 `light` 布尔属性
- [ ] Button 语义通过 `intent` 控制（`normal` / `danger` / `primary`）
- [ ] 表单使用 `Form` + `Form.Item` 包裹，不是裸 `div` + 手动布局
- [ ] Form.Item 的 `label` / `tooltip` / `required` 正确设置
- [ ] Dialog 通过 `title` / `desc` prop 设置标题描述
- [ ] Dialog 使用 `visible` + `onVisibleChange` 受控模式
- [ ] Card 使用 `Card` + `Card.Header` 组合，`title` / `topContent` 通过 Header props 传入
- [ ] Card 投影使用 `elevation` 属性（0-4），不手写 shadow
- [ ] Tabs 使用数据驱动模式（`items` + `value` + `onChange`），不是 children 模式
- [ ] 选择正确的 Tabs 变体：`Tabs.Default` / `Tabs.ButtonGroup` / `Tabs.Vertical` / `Tabs.Divider` / `Tabs.Tag`
- [ ] Empty / Loading 组件替代自建的空状态和加载态

### 2. Design Token 与颜色

- [ ] 所有颜色使用 `--odn-*` CSS 变量或 Tailwind 语义色（`text-black-12`、`bg-brand-6`），无硬编码色值
- [ ] 无 Tailwind 默认色板（`text-green-500`、`bg-blue-600`），使用 ODN 映射色（`text-green-6`、`bg-blue-6`）
- [ ] 语义色正确：info/link=蓝 `--odn-color-info`、success=绿 `--odn-color-success`、warn=橙 `--odn-color-warn`、error=红 `--odn-color-error`
- [ ] 投影使用 `--odn-shadow-1` 到 `--odn-shadow-4`
- [ ] z-index 使用 `--odn-z-index-*` 变量

### 3. 间距与布局

- [ ] 间距使用 `gap-*`，无 `space-x-*` / `space-y-*`
- [ ] 浮层组件无手动 `z-index`
- [ ] 控件高度遵循 `--odn-control-height`（36px）
- [ ] 内边距遵循 `--odn-padding-xxs`（4px）/ `--odn-padding-xs`（8px）/ `--odn-control-padding-horizontal`（12px）

### 4. 排版

- [ ] 字号使用 `--odn-font-size-*` 变量体系内的标准值
- [ ] 行高与字号匹配（使用 `--odn-font-leading-*` 变量）
- [ ] 标题层级一致（同类元素使用相同的字号/字重）
- [ ] 字体使用 `--odn-font-family`

### 5. 交互状态

每个可交互元素都应有完整的状态：

- [ ] **默认态**：静止状态
- [ ] **悬停态**：hover 视觉反馈
- [ ] **聚焦态**：键盘 focus 指示器（不要移除）
- [ ] **按下态**：点击反馈
- [ ] **禁用态**：明确的不可交互外观
- [ ] **加载态**：异步操作的反馈
- [ ] **错误态**：校验错误

### 6. 动效

- [ ] 过渡时长合理（`--odn-motion-duration-slow`: 0.25s）
- [ ] 使用项目预定义的 keyframes（`odn-slide-up-in` / `odn-slide-down-in` 等）
- [ ] 尊重 `prefers-reduced-motion`

### 7. 无障碍

- [ ] 所有图片有 `alt` 文字
- [ ] 表单输入有正确的 `label`（通过 Form.Item 自动处理）
- [ ] 对比度满足 WCAG AA（4.5:1 正文，3:1 大文本）
- [ ] 键盘导航顺序合理
- [ ] ARIA 属性正确

### 8. 代码质量

- [ ] 无 `console.log` 调试代码
- [ ] 无注释掉的死代码
- [ ] 无未使用的 import
- [ ] 无 TypeScript `any` 类型
- [ ] 组件从 `one-design-next` 导入
- [ ] className 使用 `clsx` 合并，不是手动字符串拼接

### 9. 配置项与设计偏差（区块专项）

- [ ] 区块文档「配置项」表中的每个参数，在 Demo 中有对应的 `useState` 和控件
- [ ] Demo 中每个 `useState` 参数都通过 props 传入区块组件
- [ ] 「配置项」表的参数名、类型、默认值与代码实际一致（三线对齐）
- [ ] 区块文档「设计偏差」表完整覆盖代码中所有非 ODN token 值（硬编码色值、非标准圆角、非标准字号等）
- [ ] 「设计偏差」表中记录的值与代码中实际使用的值一致

## 精修原则

- **先系统后个体**：如果间距到处不对，先修间距系统，再修个别元素
- **一致性 > 完美性**：所有地方 80 分比一个地方 100 分其他 60 分更好
- **别引入新 bug**：每个修改后验证功能仍然正常
- **优先级排序**：时间有限时，先修影响用户体验的，再修代码质量的
