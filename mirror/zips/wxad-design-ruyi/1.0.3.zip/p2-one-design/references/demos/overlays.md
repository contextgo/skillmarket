## 提醒 Alert

## 基础用例 {#basic-usage}

**示例：基础用例** — 基础用例

```tsx
'use client';

import { Alert } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

const Demo = () => {
  const [params, setParams] = useState({
    size: 'medium' as 'small' | 'medium' | 'large',
    closable: true,
    title: true,
    expandable: false,
  });

  const alertRefs = useRef<HTMLDivElement[]>([]);

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'size', {
      options: {
        small: 'small',
        medium: 'medium',
        large: 'large',
      },
    });
    pane.addBinding(params, 'closable');
    pane.addBinding(params, 'title');
    pane.addBinding(params, 'expandable');

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 px-2 pb-8 gap-8">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <div className="flex flex-col w-[300px]">
          {(['info', 'danger', 'success', 'warning'] as const).map((intent) => (
            <Alert
              ref={(el) => {
                if (el) {
                  alertRefs.current.push(el);
                }
              }}
              key={intent}
              intent={intent}
              message={`This is one ${intent} alert.`}
              size={params.size}
              closable={params.closable}
              title={params.title ? 'Alert Title' : undefined}
              expandable={params.expandable}
              expandContent={<div>This is one expand content.</div>}
              className="[&:not(:last-child)]:mb-2"
            />
          ))}
        </div>
      </CodeBox>
      <CodeBlock>{`import { Alert } from 'one-design-next';`}</CodeBlock>
    </div>
  );
};

export default Demo;
```
## API {#api}

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| size | 尺寸 | `'small' \| 'medium' \| 'large'` | `'medium'` |
| intent | 类型 | `'info' \| 'danger' \| 'success' \| 'warning'` | `'info'` |
| title | 标题 | `React.ReactNode` | - |
| message | 内容 | `React.ReactNode` | - |
| closable | 是否可关闭 | `boolean` | `false` |
| onClose | 关闭回调 | `() => void` | - |
| afterClose | 关闭动画结束后回调 | `() => void` | - |
| expandable | 是否可展开（有 `title` 时展开与关闭可同时显示） | `boolean \| null` | `false` |
| defaultExpanded | 非受控默认是否展开 | `boolean` | `false` |
| expanded | 受控是否展开 | `boolean` | - |
| onExpandChange | 展开状态变化 | `(expanded: boolean) => void` | - |
| expandContent | 展开区域内容 | `React.ReactNode` | - |

继承 `Omit<React.ComponentProps<'div'>, 'title'>`，可使用 `className`、`style` 等；`ref` 上可调用 `close()`。

## 变量 {#variables}

<VariablesTable id="Alert"></VariablesTable>

---

## 对话框 Dialog

## 基础用例 {#basic-usage}

`Dialog` 支持 `title`、`description` 配置头部信息；在样式上使用 `bordered` 来添加分割线，`align` 来配置对齐方式；通过 `cancelText` 和 `confirmText` 来配置取消和确认按钮的文本，当 `cancelText` 为空时，则不显示取消按钮：

**示例：基础用例** — 基础用例

```tsx
'use client';

import { Dialog } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

import { Pane } from 'tweakpane';

const Basic = () => {
  const [visible, setVisible] = useState(false);

  const [params, setParams] = useState({
    bordered: false,
    align: 'default' as 'default' | 'center',
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'bordered', {
      type: 'boolean',
    });

    pane.addBinding(params, 'align', {
      options: {
        default: 'default',
        center: 'center',
      },
    });
    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => pane.dispose();
  }, []);

  return (
    <div>
      <CodeBox className="pt-[80px] gap-10 flex-wrap">
        <div
          ref={tweakpaneContainerRef}
          className="absolute top-2 right-2 opacity-90"
        />
        <button className="button" onClick={() => setVisible(true)}>
          打开对话框
        </button>
        <Dialog
          visible={visible}
          onVisibleChange={setVisible}
          bordered={params.bordered}
          align={params.align === 'default' ? undefined : params.align}
          onCancel={() => setVisible(false)}
          onConfirm={() => setVisible(false)}
          confirmText="确认"
          title="设置偏好"
          desc="配置你的应用程序偏好设置"
        >
          <div>
            <p>这里是对话框的内容区域。</p>
            <p>当 bordered 为 true 时，会在标题下方和按钮上方显示分割线，</p>
            <p>同时调整 header 和 footer 的间距。</p>
          </div>
        </Dialog>
      </CodeBox>
      <CodeBlock>{`import { Dialog } from 'one-design-next';

const [visible, setVisible] = useState(false);

<Dialog 
  visible={visible} 
  onVisibleChange={setVisible}
  bordered={${params.bordered}}${params.align !== 'default' ? `\n  align="${params.align}"` : ''}
  title="设置偏好"
  desc="配置你的应用程序偏好设置"
  onCancel={() => setVisible(false)}
  onConfirm={() => setVisible(false)}
>
  <div>对话框内容</div>
</Dialog>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 确认对话框类型 {#confirmation-dialog-types}

使用 `intent` 配置不同类型的 `Dialog`，支持 `info`、`success`、`warning`、`danger` 四种类型。当使用 intent 时，内容会自动居中对齐，并使用特定的布局展示图标、标题和描述。

**示例：意图类型** — 意图类型

```tsx
'use client';

import { Dialog } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Intent = () => {
  const [visible, setVisible] = useState(false);
  const [currentIntent, setCurrentIntent] = useState<
    'info' | 'success' | 'warning' | 'danger'
  >('info');

  const intentConfig = {
    info: {
      title: '信息提示',
      desc: '这是一条信息提示，用于告知用户一般性信息。',
      confirmText: '知道了',
      cancelText: null, // 隐藏取消按钮
    },
    success: {
      title: '操作成功',
      desc: '您的操作已成功完成，数据已保存。',
      confirmText: '确定',
      cancelText: null, // 隐藏取消按钮
    },
    warning: {
      title: '警告提示',
      desc: '请注意，此操作可能会影响系统稳定性，请谨慎操作。',
      confirmText: '我知道了',
      cancelText: null, // 隐藏取消按钮
    },
    danger: {
      title: '危险操作',
      desc: '此操作不可撤销，将永久删除所有数据，请确认是否继续。',
      confirmText: '确认删除',
      cancelText: '取消', // 危险操作保留取消按钮
    },
  };

  const handleOpenDialog = (
    intent: 'info' | 'success' | 'warning' | 'danger',
  ) => {
    setCurrentIntent(intent);
    setVisible(true);
  };

  const config = intentConfig[currentIntent];

  return (
    <div>
      <CodeBox className="gap-4 flex-wrap">
        <button className="button" onClick={() => handleOpenDialog('info')}>
          Info
        </button>
        <button className="button" onClick={() => handleOpenDialog('success')}>
          Success
        </button>
        <button className="button" onClick={() => handleOpenDialog('warning')}>
          Warning
        </button>
        <button className="button" onClick={() => handleOpenDialog('danger')}>
          Danger
        </button>

        <Dialog
          visible={visible}
          onVisibleChange={setVisible}
          intent={currentIntent}
          contentTitle={config.title}
          contentDesc={config.desc}
          onConfirm={() => setVisible(false)}
          onCancel={() => setVisible(false)}
          confirmText={config.confirmText}
          cancelText={config.cancelText}
        />
      </CodeBox>

      <CodeBlock>{`import { Dialog } from 'one-design-next';

const [visible, setVisible] = useState(false);

<Dialog 
  visible={visible} 
  onVisibleChange={setVisible}
  intent="${currentIntent}"
  contentTitle="${config.title}"
  contentDesc="${config.desc}"
  onConfirm={() => setVisible(false)}
  confirmText="${config.confirmText}"
/>`}</CodeBlock>
    </div>
  );
};

export default Intent;
```
## 遮罩自定义 {#mask-customization}

使用 `maskVisible` 来控制遮罩的显示，使用 `maskClosable` 来控制遮罩的点击关闭，使用 `maskStyle` 或 `maskClassName` 来控制遮罩的样式：

**示例：遮罩相关自定义** — 遮罩相关自定义

```tsx
'use client';

import { Dialog } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

import { Pane } from 'tweakpane';

const Mask = () => {
  const [visible, setVisible] = useState(false);

  const [params, setParams] = useState({
    maskVisible: true,
    maskClosable: true,
    maskStyle: true,
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'maskVisible', {
      type: 'boolean',
    });

    pane.addBinding(params, 'maskClosable', {
      type: 'boolean',
    });

    pane.addBinding(params, 'maskStyle', {
      type: 'boolean',
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => pane.dispose();
  }, []);

  const maskStyle = params.maskStyle
    ? {
        backdropFilter: 'blur(3px)',
      }
    : undefined;

  return (
    <div>
      <CodeBox className="pt-[80px] gap-10 flex-wrap">
        <div
          ref={tweakpaneContainerRef}
          className="absolute top-2 right-2 opacity-90"
        />
        <button className="button" onClick={() => setVisible(true)}>
          打开对话框
        </button>
        <Dialog
          visible={visible}
          onVisibleChange={setVisible}
          maskVisible={params.maskVisible}
          maskClosable={params.maskClosable}
          maskStyle={maskStyle}
          onCancel={() => setVisible(false)}
          onConfirm={() => setVisible(false)}
          title="遮罩设置"
          desc="演示遮罩的各种配置选项"
        >
          这是一个演示遮罩功能的对话框。
        </Dialog>
      </CodeBox>
      <CodeBlock>{`import { Dialog } from 'one-design-next';

const [visible, setVisible] = useState(false);

<Dialog 
  visible={visible} 
  onVisibleChange={setVisible}
  maskVisible={${params.maskVisible}}
  maskClosable={${params.maskClosable}}${
    params.maskStyle
      ? `
  maskStyle={{
    backdropFilter: 'blur(3px)',
  }}`
      : ''
  }
  title="遮罩设置"
  desc="演示遮罩的各种配置选项"
  onCancel={() => setVisible(false)}
  onConfirm={() => setVisible(false)}
>
  <div>对话框内容</div>
</Dialog>`}</CodeBlock>
    </div>
  );
};

export default Mask;
```
## 等比缩放 {#auto-scale}

使用 `autoScale` 来在窗口过小或过大时自动等比缩放，在更小的窗口中，则左右滚动展示。`autoScale` 是在滚动基础上的优化。

设置 `true` 来启用自动缩放，设置 `autoScaleRange` 来定义缩放范围，默认范围是 `[0.9, 1]`：

**示例：等比缩放** — 等比缩放

```tsx
'use client';

import { Dialog } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

import { Pane } from 'tweakpane';

const Basic = () => {
  const [visible, setVisible] = useState(false);

  const [params, setParams] = useState({
    autoScale: true,
    min: 0.9,
    max: 1,
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'autoScale', {
      type: 'boolean',
    });

    pane.addBinding(params, 'min', {
      type: 'slider',
      min: 0.5,
      max: 1,
      step: 0.1,
    });

    pane.addBinding(params, 'max', {
      type: 'number',
      min: 1,
      max: 1.5,
      step: 0.1,
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => pane.dispose();
  }, []);

  const autoScaleRange = [params.min, params.max] as [number, number];

  return (
    <div>
      <CodeBox className="pt-[80px]">
        <div
          ref={tweakpaneContainerRef}
          className="absolute top-2 right-2 opacity-90"
        />
        <button className="button" onClick={() => setVisible(true)}>
          {params.autoScale ? 'auto-scale' : 'fixed-size'}
        </button>
        <Dialog
          visible={visible}
          onVisibleChange={setVisible}
          autoScale={params.autoScale}
          autoScaleRange={autoScaleRange}
          cancelText={null}
          confirmText={null}
          bodyStyle={{ padding: 0 }}
        >
          <img
            src="https://wxa.wxs.qq.com/wxad-design/yijie/modal-example.webp"
            className="w-[1000px] h-[776px]"
            style={{
              maxWidth: '1000px',
              minWidth: '1000px',
              maxHeight: '776px',
              minHeight: '776px',
            }}
          />
        </Dialog>
      </CodeBox>
      <CodeBlock>{`import { Dialog } from 'one-design-next';

// ${visible}
const [visible, setVisible] = useState(false);

<Dialog visible={visible} onVisibleChange={setVisible} ${
        !params.autoScale ? 'autoScale={false}' : ''
      } />`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 容器挂载 {#container-mount}

使用 `container` 属性来指定挂载容器。默认情况下，`Dialog` 会挂载到 `document.body` 中。

另外，你可能不仅想要把 `Dialog` 挂载在某个容器中，还想让它显示在容器中，而 `position: fixed` 却直接定位到了视窗中。这时候你可以“取巧地”在指定的容器上加一条简单的 `transform: translateZ(0)` 即可（如果使用 tailwind，则可以添加 `transform-gpu` 类名），这将改变 `position: fixed` 的定位参考；同时你应该需要将 `originAware` 设置为 `false`。

**示例：容器挂载** — 容器挂载

```tsx
'use client';

import { Dialog } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

import { Pane } from 'tweakpane';

const Container = () => {
  const [visible, setVisible] = useState(false);

  const [params, setParams] = useState({
    useContainer: true,
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'useContainer', {
      type: 'boolean',
      label: '显示在容器中',
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => pane.dispose();
  }, []);

  return (
    <div>
      <CodeBox
        className="py-[180px] gap-10 flex-wrap transform-gpu"
        id="demo-dialog-container"
      >
        <div
          ref={tweakpaneContainerRef}
          className="absolute top-2 right-2 opacity-90"
        />

        <button className="button" onClick={() => setVisible(true)}>
          打开对话框
        </button>

        <Dialog
          visible={visible}
          onVisibleChange={setVisible}
          container={
            params.useContainer
              ? document.getElementById('demo-dialog-container')! || undefined
              : undefined
          }
          onCancel={() => setVisible(false)}
          onConfirm={() => setVisible(false)}
          title="容器演示"
          desc="演示 Dialog 在不同容器中的显示效果"
          originAware={false}
        >
          这个对话框可以显示在指定的容器中。
        </Dialog>
      </CodeBox>
      <CodeBlock>{`import { Dialog } from 'one-design-next';

const [visible, setVisible] = useState(false);

<div
  id="demo-dialog-container"
  // 如果你使用 tailwind
  className="transform-gpu"
  // 如果你使用 css
  style={{ transform: 'translateZ(0)' }}
/>

<Dialog 
  visible={visible} 
  onVisibleChange={setVisible}
  container={${params.useContainer ? "document.getElementById('demo-dialog-container')!" : 'undefined'}}
  originAware={false}
  title="容器演示"
  desc="演示 Dialog 在不同容器中的显示效果"
  onCancel={() => setVisible(false)}
  onConfirm={() => setVisible(false)}
>
  <div>对话框内容</div>
</Dialog>`}</CodeBlock>
    </div>
  );
};

export default Container;
```
## API {#api}

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| visible | 是否显示 | `boolean` | `false` |
| onVisibleChange | 显隐变化 | `(visible: boolean) => void` | - |
| className / style | 包裹层 | `string` / `CSSProperties` | - |
| bodyStyle | 内容区样式 | `CSSProperties` | - |
| zIndex | 层级 | `number \| string` | - |
| title / desc | 标题 / 描述 | `React.ReactNode` | - |
| children | 内容 | `React.ReactNode` | - |
| originAware | 是否从点击位置变换 | `boolean` | `true` |
| autoScale | 是否缩放内容 | `boolean` | `true` |
| autoScaleRange | 缩放范围 | `[number, number]` | `[0.9, 1]` |
| onCancel / onConfirm | 取消 / 确认 | `() => void` | - |
| cancelText / confirmText | 按钮文案，`null` 隐藏 | `string \| null` | `'取消'` / `'确认'` |
| bordered | 是否显示分割线 | `boolean` | `false` |
| align | 对齐 | `'center'` | - |
| intent | 意图样式 | `'info' \| 'success' \| 'warning' \| 'danger'` | - |
| contentTitle / contentDesc | 意图模式下的标题 / 描述 | `React.ReactNode` | - |
| maskVisible / maskClosable | 遮罩 | `boolean` | `true` |
| maskStyle / maskClassName | 遮罩 | `CSSProperties` / `string` | - |
| container | 挂载容器 | `HTMLElement` | - |
| closable | 是否显示关闭 | `boolean` | `true` |
| confirmProps / cancelProps | 按钮扩展（含 `popover`） | `ButtonProps` 扩展 | - |

## 变量 {#variables}

<VariablesTable id="Dialog"></VariablesTable>

---

## 抽屉 Drawer

## 基础用例 {#basic-usage}

可以使用 `padding` 来设置 `Drawer` 距离屏幕边缘的距离。随后 `border-radius` 会自动添加：

**示例：基础用例** — 基础用例

```tsx
'use client';

import { Drawer } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
import { Pane } from 'tweakpane';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basic = () => {
  const [visible, setVisible] = useState(false);

  const [params, setParams] = useState({
    placement: 'right' as 'right' | 'left' | 'top' | 'bottom',
    padding: 0,
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'placement', {
      options: {
        right: 'right',
        left: 'left',
        top: 'top',
        bottom: 'bottom',
      },
    });

    pane.addBinding(params, 'padding', {
      min: 0,
      max: 20,
      step: 4,
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => pane.dispose();
  }, []);

  return (
    <div>
      <CodeBox className="pt-[80px]">
        <div
          ref={tweakpaneContainerRef}
          className="absolute top-2 right-2 opacity-90"
        />
        <button className="button" onClick={() => setVisible(true)}>
          {params.placement} drawer
        </button>
        <Drawer
          visible={visible}
          onVisibleChange={setVisible}
          placement={params.placement}
          padding={params.padding}
          title="Move Goal"
          // desc="Set your daily activity goal."
          closable
        >
          <div className="max-w-[350px] mx-auto flex flex-col w-full h-full p-4">
            <div>
              <div className="p-4 pb-0">
                <div className="flex items-center justify-center space-x-2">
                  <div className="flex-1 text-center">
                    <div className="text-7xl font-bold tracking-tighter">
                      350
                    </div>
                    <div className="text-[0.70rem] uppercase text-muted-foreground">
                      Calories/day
                    </div>
                  </div>
                </div>
                <div className="mt-3 h-[120px]">
                  <div
                    className="recharts-responsive-container"
                    style={{ width: '100%', height: '100%', minWidth: '0px' }}
                  >
                    <div
                      className="recharts-wrapper"
                      style={{
                        position: 'relative',
                        cursor: 'default',
                        width: '100%',
                        height: '100%',
                        maxHeight: '120px',
                        maxWidth: '352px',
                      }}
                    >
                      <svg
                        className="recharts-surface"
                        width="352"
                        height="120"
                        viewBox="0 0 352 120"
                        style={{ width: '100%', height: '100%' }}
                      >
                        <title></title>
                        <desc></desc>
                        <defs>
                          <clipPath id="recharts20-clip">
                            <rect x="5" y="5" height="110" width="342"></rect>
                          </clipPath>
                        </defs>
                        <g className="recharts-layer recharts-bar">
                          <g className="recharts-layer recharts-bar-rectangles">
                            <g className="recharts-layer">
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="7.63076923076923"
                                  y="5"
                                  width="21"
                                  height="110"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 7.63076923076923,5 h 21 v 110 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="33.93846153846154"
                                  y="32.5"
                                  width="21"
                                  height="82.5"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 33.93846153846154,32.5 h 21 v 82.5 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="60.246153846153845"
                                  y="60"
                                  width="21"
                                  height="55"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 60.246153846153845,60 h 21 v 55 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="86.55384615384615"
                                  y="32.5"
                                  width="21"
                                  height="82.5"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 86.55384615384615,32.5 h 21 v 82.5 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="112.86153846153846"
                                  y="60"
                                  width="21"
                                  height="55"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 112.86153846153846,60 h 21 v 55 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="139.16923076923078"
                                  y="38.55000000000001"
                                  width="21"
                                  height="76.44999999999999"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 139.16923076923078,38.55000000000001 h 21 v 76.44999999999999 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="165.47692307692307"
                                  y="63.025000000000006"
                                  width="21"
                                  height="51.974999999999994"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 165.47692307692307,63.025000000000006 h 21 v 51.974999999999994 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="191.78461538461536"
                                  y="49.27499999999999"
                                  width="21"
                                  height="65.72500000000001"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 191.78461538461536,49.27499999999999 h 21 v 65.72500000000001 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="218.09230769230768"
                                  y="32.5"
                                  width="21"
                                  height="82.5"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 218.09230769230768,32.5 h 21 v 82.5 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="244.4"
                                  y="60"
                                  width="21"
                                  height="55"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 244.4,60 h 21 v 55 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="270.7076923076923"
                                  y="38.55000000000001"
                                  width="21"
                                  height="76.44999999999999"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 270.7076923076923,38.55000000000001 h 21 v 76.44999999999999 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="297.01538461538456"
                                  y="63.025000000000006"
                                  width="21"
                                  height="51.974999999999994"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 297.01538461538456,63.025000000000006 h 21 v 51.974999999999994 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="323.3230769230769"
                                  y="19.02499999999999"
                                  width="21"
                                  height="95.97500000000001"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 323.3230769230769,19.02499999999999 h 21 v 95.97500000000001 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                            </g>
                          </g>
                          <g className="recharts-layer"></g>
                        </g>
                      </svg>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="mt-auto flex flex-col gap-2 p-4">
              <button
                onClick={() => setVisible(false)}
                className="cursor-pointer bg-neutral-900 inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&amp;_svg]:pointer-events-none [&amp;_svg]:size-4 [&amp;_svg]:shrink-0 text-white shadow h-9 px-4 py-2"
              >
                Submit
              </button>
              <button
                className="cursor-pointer inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&amp;_svg]:pointer-events-none [&amp;_svg]:size-4 [&amp;_svg]:shrink-0 border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground h-9 px-4 py-2"
                type="button"
                onClick={() => setVisible(false)}
              >
                Cancel
              </button>
            </div>
          </div>
        </Drawer>
      </CodeBox>
      <CodeBlock>{`import { Drawer } from "one-design-next";

// ${visible}
const [visible, setVisible] = useState(false);

<Drawer
  visible={visible}
  onVisibleChange={setVisible}
  placement="${params.placement}"
  padding={${params.padding}}
  title="Move Goal"
  closable
/>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 步骤 {#steps}

使用 `steps` 来设置 `Drawer` 的步骤。通过 `stepTransitionType` 设置过渡的类型：

**示例：步骤** — 步骤

```tsx
'use client';

import { Drawer } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

const Basic = () => {
  const [visible, setVisible] = useState(false);
  const [step, setStep] = useState(0);
  const [params, setParams] = useState({
    placement: 'bottom' as 'right' | 'left' | 'top' | 'bottom',
    padding: 12,
    type: 'fade' as 'slide' | 'fade',
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'placement', {
      options: {
        right: 'right',
        left: 'left',
        top: 'top',
        bottom: 'bottom',
      },
    });

    pane.addBinding(params, 'type', {
      options: {
        slide: 'slide',
        fade: 'fade',
      },
    });

    pane.addBinding(params, 'padding', {
      min: 0,
      max: 20,
      step: 4,
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => pane.dispose();
  }, []);

  return (
    <div>
      <CodeBox className="pt-[120px]">
        <div
          ref={tweakpaneContainerRef}
          className="absolute top-2 right-2 opacity-90"
        />
        <button className="button" onClick={() => setVisible(true)}>
          steps
        </button>
        <Drawer
          visible={visible}
          onVisibleChange={setVisible}
          placement={params.placement}
          padding={params.padding}
          stepTransitionType={params.type}
          step={step}
          steps={[
            <div className="max-w-[350px] mx-auto flex flex-col w-full h-full p-4">
              <div>
                <div className="grid gap-1.5 p-4 text-center sm:text-left">
                  <h2
                    id="radix-:r5m:"
                    className="text-lg font-semibold leading-none tracking-tight"
                  >
                    Move Goal
                  </h2>
                  <p id="radix-:r5n:" className="text-sm text-muted-foreground">
                    Set your daily activity goal.
                  </p>
                </div>
                <div className="p-4 pb-0">
                  <div className="flex items-center justify-center space-x-2">
                    <div className="flex-1 text-center">
                      <div className="text-7xl font-bold tracking-tighter">
                        350
                      </div>
                      <div className="text-[0.70rem] uppercase text-muted-foreground">
                        Calories/day
                      </div>
                    </div>
                  </div>
                  <div className="mt-3 h-[120px]">
                    <div
                      className="recharts-responsive-container"
                      style={{ width: '100%', height: '100%', minWidth: '0px' }}
                    >
                      <div
                        className="recharts-wrapper"
                        style={{
                          position: 'relative',
                          cursor: 'default',
                          width: '100%',
                          height: '100%',
                          maxHeight: '120px',
                          maxWidth: '352px',
                        }}
                      >
                        <svg
                          className="recharts-surface"
                          width="352"
                          height="120"
                          viewBox="0 0 352 120"
                          style={{ width: '100%', height: '100%' }}
                        >
                          <title></title>
                          <desc></desc>
                          <defs>
                            <clipPath id="recharts20-clip">
                              <rect x="5" y="5" height="110" width="342"></rect>
                            </clipPath>
                          </defs>
                          <g className="recharts-layer recharts-bar">
                            <g className="recharts-layer recharts-bar-rectangles">
                              <g className="recharts-layer">
                                <g className="recharts-layer recharts-bar-rectangle">
                                  <path
                                    x="7.63076923076923"
                                    y="5"
                                    width="21"
                                    height="110"
                                    radius="0"
                                    className="recharts-rectangle"
                                    d="M 7.63076923076923,5 h 21 v 110 h -21 Z"
                                    style={{
                                      fill: 'hsl(var(--foreground))',
                                      opacity: 0.9,
                                    }}
                                  ></path>
                                </g>
                                <g className="recharts-layer recharts-bar-rectangle">
                                  <path
                                    x="33.93846153846154"
                                    y="32.5"
                                    width="21"
                                    height="82.5"
                                    radius="0"
                                    className="recharts-rectangle"
                                    d="M 33.93846153846154,32.5 h 21 v 82.5 h -21 Z"
                                    style={{
                                      fill: 'hsl(var(--foreground))',
                                      opacity: 0.9,
                                    }}
                                  ></path>
                                </g>
                                <g className="recharts-layer recharts-bar-rectangle">
                                  <path
                                    x="60.246153846153845"
                                    y="60"
                                    width="21"
                                    height="55"
                                    radius="0"
                                    className="recharts-rectangle"
                                    d="M 60.246153846153845,60 h 21 v 55 h -21 Z"
                                    style={{
                                      fill: 'hsl(var(--foreground))',
                                      opacity: 0.9,
                                    }}
                                  ></path>
                                </g>
                                <g className="recharts-layer recharts-bar-rectangle">
                                  <path
                                    x="86.55384615384615"
                                    y="32.5"
                                    width="21"
                                    height="82.5"
                                    radius="0"
                                    className="recharts-rectangle"
                                    d="M 86.55384615384615,32.5 h 21 v 82.5 h -21 Z"
                                    style={{
                                      fill: 'hsl(var(--foreground))',
                                      opacity: 0.9,
                                    }}
                                  ></path>
                                </g>
                                <g className="recharts-layer recharts-bar-rectangle">
                                  <path
                                    x="112.86153846153846"
                                    y="60"
                                    width="21"
                                    height="55"
                                    radius="0"
                                    className="recharts-rectangle"
                                    d="M 112.86153846153846,60 h 21 v 55 h -21 Z"
                                    style={{
                                      fill: 'hsl(var(--foreground))',
                                      opacity: 0.9,
                                    }}
                                  ></path>
                                </g>
                                <g className="recharts-layer recharts-bar-rectangle">
                                  <path
                                    x="139.16923076923078"
                                    y="38.55000000000001"
                                    width="21"
                                    height="76.44999999999999"
                                    radius="0"
                                    className="recharts-rectangle"
                                    d="M 139.16923076923078,38.55000000000001 h 21 v 76.44999999999999 h -21 Z"
                                    style={{
                                      fill: 'hsl(var(--foreground))',
                                      opacity: 0.9,
                                    }}
                                  ></path>
                                </g>
                                <g className="recharts-layer recharts-bar-rectangle">
                                  <path
                                    x="165.47692307692307"
                                    y="63.025000000000006"
                                    width="21"
                                    height="51.974999999999994"
                                    radius="0"
                                    className="recharts-rectangle"
                                    d="M 165.47692307692307,63.025000000000006 h 21 v 51.974999999999994 h -21 Z"
                                    style={{
                                      fill: 'hsl(var(--foreground))',
                                      opacity: 0.9,
                                    }}
                                  ></path>
                                </g>
                                <g className="recharts-layer recharts-bar-rectangle">
                                  <path
                                    x="191.78461538461536"
                                    y="49.27499999999999"
                                    width="21"
                                    height="65.72500000000001"
                                    radius="0"
                                    className="recharts-rectangle"
                                    d="M 191.78461538461536,49.27499999999999 h 21 v 65.72500000000001 h -21 Z"
                                    style={{
                                      fill: 'hsl(var(--foreground))',
                                      opacity: 0.9,
                                    }}
                                  ></path>
                                </g>
                                <g className="recharts-layer recharts-bar-rectangle">
                                  <path
                                    x="218.09230769230768"
                                    y="32.5"
                                    width="21"
                                    height="82.5"
                                    radius="0"
                                    className="recharts-rectangle"
                                    d="M 218.09230769230768,32.5 h 21 v 82.5 h -21 Z"
                                    style={{
                                      fill: 'hsl(var(--foreground))',
                                      opacity: 0.9,
                                    }}
                                  ></path>
                                </g>
                                <g className="recharts-layer recharts-bar-rectangle">
                                  <path
                                    x="244.4"
                                    y="60"
                                    width="21"
                                    height="55"
                                    radius="0"
                                    className="recharts-rectangle"
                                    d="M 244.4,60 h 21 v 55 h -21 Z"
                                    style={{
                                      fill: 'hsl(var(--foreground))',
                                      opacity: 0.9,
                                    }}
                                  ></path>
                                </g>
                                <g className="recharts-layer recharts-bar-rectangle">
                                  <path
                                    x="270.7076923076923"
                                    y="38.55000000000001"
                                    width="21"
                                    height="76.44999999999999"
                                    radius="0"
                                    className="recharts-rectangle"
                                    d="M 270.7076923076923,38.55000000000001 h 21 v 76.44999999999999 h -21 Z"
                                    style={{
                                      fill: 'hsl(var(--foreground))',
                                      opacity: 0.9,
                                    }}
                                  ></path>
                                </g>
                                <g className="recharts-layer recharts-bar-rectangle">
                                  <path
                                    x="297.01538461538456"
                                    y="63.025000000000006"
                                    width="21"
                                    height="51.974999999999994"
                                    radius="0"
                                    className="recharts-rectangle"
                                    d="M 297.01538461538456,63.025000000000006 h 21 v 51.974999999999994 h -21 Z"
                                    style={{
                                      fill: 'hsl(var(--foreground))',
                                      opacity: 0.9,
                                    }}
                                  ></path>
                                </g>
                                <g className="recharts-layer recharts-bar-rectangle">
                                  <path
                                    x="323.3230769230769"
                                    y="19.02499999999999"
                                    width="21"
                                    height="95.97500000000001"
                                    radius="0"
                                    className="recharts-rectangle"
                                    d="M 323.3230769230769,19.02499999999999 h 21 v 95.97500000000001 h -21 Z"
                                    style={{
                                      fill: 'hsl(var(--foreground))',
                                      opacity: 0.9,
                                    }}
                                  ></path>
                                </g>
                              </g>
                            </g>
                            <g className="recharts-layer"></g>
                          </g>
                        </svg>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="mt-auto flex flex-col gap-2 p-4">
                <button
                  onClick={() => setStep(step + 1)}
                  className="cursor-pointer bg-neutral-900 inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&amp;_svg]:pointer-events-none [&amp;_svg]:size-4 [&amp;_svg]:shrink-0 text-white shadow h-9 px-4 py-2"
                >
                  Next
                </button>
              </div>
            </div>,
            <div className="max-w-[350px] mx-auto flex flex-col w-full h-full p-4">
              <div>
                <div className="grid gap-1.5 p-4 text-center sm:text-left">
                  <h2
                    id="radix-:r5m:"
                    className="text-lg font-semibold leading-none tracking-tight"
                  >
                    Move Goal
                  </h2>
                  <p id="radix-:r5n:" className="text-sm text-muted-foreground">
                    Set your daily activity goal.
                  </p>
                </div>
                <div className="p-4 pb-0">
                  <div className="flex items-center justify-center space-x-2">
                    <div className="flex-1 text-center">
                      <div className="text-7xl font-bold tracking-tighter">
                        175
                      </div>
                      <div className="text-[0.70rem] uppercase text-muted-foreground">
                        Calories/day
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="mt-auto flex flex-col gap-2 p-4">
                <button
                  onClick={() => setStep(step - 1)}
                  className="cursor-pointer bg-neutral-900 inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&amp;_svg]:pointer-events-none [&amp;_svg]:size-4 [&amp;_svg]:shrink-0 text-white shadow h-9 px-4 py-2"
                >
                  Prev
                </button>
              </div>
            </div>,
          ]}
        />
      </CodeBox>
      <CodeBlock>{`import { Drawer } from 'one-design-next';

// ${visible}
const [visible, setVisible] = useState(false);
const [step, setStep] = useState(0);

<Drawer
  visible={visible}
  onVisibleChange={setVisible}
  placement="${params.placement}"
  padding={${params.padding}}
  stepTransitionType="${params.type}"
  step={step}
  steps={[<div>1</div>, <div>2</div>]}
/>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 遮罩自定义 {#mask-customization}

使用 `maskVisible` 来控制遮罩的显示，使用 `maskClosable` 来控制遮罩的点击关闭，使用 `maskStyle` 或 `maskClassName` 来控制遮罩的样式：

**示例：遮罩相关自定义** — 遮罩相关自定义

```tsx
'use client';

import { Drawer } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

import { Pane } from 'tweakpane';

const Mask = () => {
  const [visible, setVisible] = useState(false);

  const [params, setParams] = useState({
    maskVisible: true,
    maskClosable: true,
    customMaskStyle: false,
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'maskVisible', {
      type: 'boolean',
    });

    pane.addBinding(params, 'maskClosable', {
      type: 'boolean',
    });

    pane.addBinding(params, 'customMaskStyle', {
      type: 'boolean',
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => pane.dispose();
  }, []);

  const maskStyle = params.customMaskStyle
    ? {
        backgroundColor: 'rgba(0, 255, 0, 0.3)',
        backdropFilter: 'blur(3px)',
      }
    : undefined;

  return (
    <div>
      <CodeBox className="pt-[80px] gap-10 flex-wrap">
        <div
          ref={tweakpaneContainerRef}
          className="absolute top-2 right-2 w-[250px] opacity-90"
        />
        <button className="button" onClick={() => setVisible(true)}>
          打开抽屉
        </button>
        <Drawer
          visible={visible}
          onVisibleChange={setVisible}
          maskVisible={params.maskVisible}
          maskClosable={params.maskClosable}
          maskStyle={maskStyle}
        >
          <div className="max-w-[350px] mx-auto flex flex-col w-full h-full p-4">
            <div>
              <div className="grid gap-1.5 p-4 text-center sm:text-left">
                <h2
                  id="radix-:r5m:"
                  className="text-lg font-semibold leading-none tracking-tight"
                >
                  Move Goal
                </h2>
                <p id="radix-:r5n:" className="text-sm text-muted-foreground">
                  Set your daily activity goal.
                </p>
              </div>
              <div className="p-4 pb-0">
                <div className="flex items-center justify-center space-x-2">
                  <div className="flex-1 text-center">
                    <div className="text-7xl font-bold tracking-tighter">
                      350
                    </div>
                    <div className="text-[0.70rem] uppercase text-muted-foreground">
                      Calories/day
                    </div>
                  </div>
                </div>
                <div className="mt-3 h-[120px]">
                  <div
                    className="recharts-responsive-container"
                    style={{ width: '100%', height: '100%', minWidth: '0px' }}
                  >
                    <div
                      className="recharts-wrapper"
                      style={{
                        position: 'relative',
                        cursor: 'default',
                        width: '100%',
                        height: '100%',
                        maxHeight: '120px',
                        maxWidth: '352px',
                      }}
                    >
                      <svg
                        className="recharts-surface"
                        width="352"
                        height="120"
                        viewBox="0 0 352 120"
                        style={{ width: '100%', height: '100%' }}
                      >
                        <title></title>
                        <desc></desc>
                        <defs>
                          <clipPath id="recharts20-clip">
                            <rect x="5" y="5" height="110" width="342"></rect>
                          </clipPath>
                        </defs>
                        <g className="recharts-layer recharts-bar">
                          <g className="recharts-layer recharts-bar-rectangles">
                            <g className="recharts-layer">
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="7.63076923076923"
                                  y="5"
                                  width="21"
                                  height="110"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 7.63076923076923,5 h 21 v 110 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="33.93846153846154"
                                  y="32.5"
                                  width="21"
                                  height="82.5"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 33.93846153846154,32.5 h 21 v 82.5 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="60.246153846153845"
                                  y="60"
                                  width="21"
                                  height="55"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 60.246153846153845,60 h 21 v 55 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="86.55384615384615"
                                  y="32.5"
                                  width="21"
                                  height="82.5"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 86.55384615384615,32.5 h 21 v 82.5 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="112.86153846153846"
                                  y="60"
                                  width="21"
                                  height="55"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 112.86153846153846,60 h 21 v 55 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="139.16923076923078"
                                  y="38.55000000000001"
                                  width="21"
                                  height="76.44999999999999"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 139.16923076923078,38.55000000000001 h 21 v 76.44999999999999 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="165.47692307692307"
                                  y="63.025000000000006"
                                  width="21"
                                  height="51.974999999999994"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 165.47692307692307,63.025000000000006 h 21 v 51.974999999999994 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="191.78461538461536"
                                  y="49.27499999999999"
                                  width="21"
                                  height="65.72500000000001"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 191.78461538461536,49.27499999999999 h 21 v 65.72500000000001 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="218.09230769230768"
                                  y="32.5"
                                  width="21"
                                  height="82.5"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 218.09230769230768,32.5 h 21 v 82.5 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="244.4"
                                  y="60"
                                  width="21"
                                  height="55"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 244.4,60 h 21 v 55 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="270.7076923076923"
                                  y="38.55000000000001"
                                  width="21"
                                  height="76.44999999999999"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 270.7076923076923,38.55000000000001 h 21 v 76.44999999999999 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="297.01538461538456"
                                  y="63.025000000000006"
                                  width="21"
                                  height="51.974999999999994"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 297.01538461538456,63.025000000000006 h 21 v 51.974999999999994 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="323.3230769230769"
                                  y="19.02499999999999"
                                  width="21"
                                  height="95.97500000000001"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 323.3230769230769,19.02499999999999 h 21 v 95.97500000000001 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                            </g>
                          </g>
                          <g className="recharts-layer"></g>
                        </g>
                      </svg>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="mt-auto flex flex-col gap-2 p-4">
              <button
                onClick={() => setVisible(false)}
                className="cursor-pointer bg-neutral-900 inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 text-white shadow h-9 px-4 py-2"
              >
                Submit
              </button>
              <button
                className="cursor-pointer inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground h-9 px-4 py-2"
                type="button"
                onClick={() => setVisible(false)}
              >
                Cancel
              </button>
            </div>
          </div>
        </Drawer>
      </CodeBox>
      <CodeBlock>{`import { Drawer } from 'one-design-next';

const [visible, setVisible] = useState(false);

<Drawer 
  visible={visible} 
  onVisibleChange={setVisible}
  maskVisible={${params.maskVisible}}
  maskClosable={${params.maskClosable}}${
    params.customMaskStyle
      ? `
  maskStyle={{
    backgroundColor: 'rgba(0, 255, 0, 0.3)',
    backdropFilter: 'blur(8px)',
  }}`
      : ''
  }
>
  <div>抽屉内容</div>
</Drawer>`}</CodeBlock>
    </div>
  );
};

export default Mask;
```
## 层级提升 {#elevation}

使用 `elevated` 来提升 `Drawer` 的层级，这会使得 `data-odn-drawer-wrapper` 缩小。你需要手动地向页面的包裹层加上这个属性。

当 `elevated` 为 `true` 时，`padding` 会被忽略：

**示例：层级提升** — 层级提升

```tsx
'use client';

import { Drawer } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

const Basic = () => {
  const [visible, setVisible] = useState(false);

  const [params, setParams] = useState({
    placement: 'bottom' as 'right' | 'left' | 'top' | 'bottom',
    elevated: true,
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'placement', {
      options: {
        right: 'right',
        left: 'left',
        top: 'top',
        bottom: 'bottom',
      },
    });

    pane.addBinding(params, 'elevated', {
      type: 'boolean',
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => pane.dispose();
  }, []);

  return (
    <div>
      <CodeBox className="pt-[80px]">
        <div
          ref={tweakpaneContainerRef}
          className="absolute top-2 right-2 opacity-90"
        />
        <button className="button" onClick={() => setVisible(true)}>
          elevated: {params.elevated ? 'true' : 'false'}
        </button>
        <Drawer
          visible={visible}
          onVisibleChange={setVisible}
          placement={params.placement}
          elevated
        >
          <div className="max-w-[350px] mx-auto flex flex-col w-full h-full p-4">
            <div>
              <div className="grid gap-1.5 p-4 text-center sm:text-left">
                <h2
                  id="radix-:r5m:"
                  className="text-lg font-semibold leading-none tracking-tight"
                >
                  Move Goal
                </h2>
                <p id="radix-:r5n:" className="text-sm text-muted-foreground">
                  Set your daily activity goal.
                </p>
              </div>
              <div className="p-4 pb-0">
                <div className="flex items-center justify-center space-x-2">
                  <div className="flex-1 text-center">
                    <div className="text-7xl font-bold tracking-tighter">
                      350
                    </div>
                    <div className="text-[0.70rem] uppercase text-muted-foreground">
                      Calories/day
                    </div>
                  </div>
                </div>
                <div className="mt-3 h-[120px]">
                  <div
                    className="recharts-responsive-container"
                    style={{ width: '100%', height: '100%', minWidth: '0px' }}
                  >
                    <div
                      className="recharts-wrapper"
                      style={{
                        position: 'relative',
                        cursor: 'default',
                        width: '100%',
                        height: '100%',
                        maxHeight: '120px',
                        maxWidth: '352px',
                      }}
                    >
                      <svg
                        className="recharts-surface"
                        width="352"
                        height="120"
                        viewBox="0 0 352 120"
                        style={{ width: '100%', height: '100%' }}
                      >
                        <title></title>
                        <desc></desc>
                        <defs>
                          <clipPath id="recharts20-clip">
                            <rect x="5" y="5" height="110" width="342"></rect>
                          </clipPath>
                        </defs>
                        <g className="recharts-layer recharts-bar">
                          <g className="recharts-layer recharts-bar-rectangles">
                            <g className="recharts-layer">
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="7.63076923076923"
                                  y="5"
                                  width="21"
                                  height="110"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 7.63076923076923,5 h 21 v 110 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="33.93846153846154"
                                  y="32.5"
                                  width="21"
                                  height="82.5"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 33.93846153846154,32.5 h 21 v 82.5 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="60.246153846153845"
                                  y="60"
                                  width="21"
                                  height="55"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 60.246153846153845,60 h 21 v 55 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="86.55384615384615"
                                  y="32.5"
                                  width="21"
                                  height="82.5"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 86.55384615384615,32.5 h 21 v 82.5 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="112.86153846153846"
                                  y="60"
                                  width="21"
                                  height="55"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 112.86153846153846,60 h 21 v 55 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="139.16923076923078"
                                  y="38.55000000000001"
                                  width="21"
                                  height="76.44999999999999"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 139.16923076923078,38.55000000000001 h 21 v 76.44999999999999 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="165.47692307692307"
                                  y="63.025000000000006"
                                  width="21"
                                  height="51.974999999999994"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 165.47692307692307,63.025000000000006 h 21 v 51.974999999999994 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="191.78461538461536"
                                  y="49.27499999999999"
                                  width="21"
                                  height="65.72500000000001"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 191.78461538461536,49.27499999999999 h 21 v 65.72500000000001 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="218.09230769230768"
                                  y="32.5"
                                  width="21"
                                  height="82.5"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 218.09230769230768,32.5 h 21 v 82.5 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="244.4"
                                  y="60"
                                  width="21"
                                  height="55"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 244.4,60 h 21 v 55 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="270.7076923076923"
                                  y="38.55000000000001"
                                  width="21"
                                  height="76.44999999999999"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 270.7076923076923,38.55000000000001 h 21 v 76.44999999999999 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="297.01538461538456"
                                  y="63.025000000000006"
                                  width="21"
                                  height="51.974999999999994"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 297.01538461538456,63.025000000000006 h 21 v 51.974999999999994 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="323.3230769230769"
                                  y="19.02499999999999"
                                  width="21"
                                  height="95.97500000000001"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 323.3230769230769,19.02499999999999 h 21 v 95.97500000000001 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                            </g>
                          </g>
                          <g className="recharts-layer"></g>
                        </g>
                      </svg>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="mt-auto flex flex-col gap-2 p-4">
              <button
                onClick={() => setVisible(false)}
                className="cursor-pointer bg-neutral-900 inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&amp;_svg]:pointer-events-none [&amp;_svg]:size-4 [&amp;_svg]:shrink-0 text-white shadow h-9 px-4 py-2"
              >
                Submit
              </button>
              <button
                className="cursor-pointer inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&amp;_svg]:pointer-events-none [&amp;_svg]:size-4 [&amp;_svg]:shrink-0 border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground h-9 px-4 py-2"
                type="button"
                onClick={() => setVisible(false)}
              >
                Cancel
              </button>
            </div>
          </div>
        </Drawer>
      </CodeBox>
      <CodeBlock>{`import { Drawer } from 'one-design-next';

// ${visible}
const [visible, setVisible] = useState(false);

<Drawer
  visible={visible}
  onVisibleChange={setVisible}
  placement="${params.placement}"
  ${params.elevated ? 'elevated' : ''}
/>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 容器挂载 {#container-mount}

使用 `container` 属性来指定挂载容器。默认情况下，`Drawer` 会挂载到 `document.body` 中。

另外，你可能不仅想要把 `Drawer` 挂载在某个容器中，还想让它显示在容器中，而 `position: fixed` 却直接定位到了视窗中。这时候你可以“取巧地”在指定的容器上加一条简单的 `transform: translateZ(0)` 即可（如果使用 tailwind，则可以添加 `transform-gpu` 类名），这将改变 `position: fixed` 的定位参考。

**示例：容器挂载** — 容器挂载

```tsx
'use client';

import { Drawer } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
import { Pane } from 'tweakpane';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Container = () => {
  const [visible, setVisible] = useState(false);

  const [params, setParams] = useState({
    useContainer: true,
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'useContainer', {
      type: 'boolean',
      label: '显示在容器中',
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => pane.dispose();
  }, []);

  return (
    <div>
      <CodeBox
        className="py-[180px] gap-10 flex-wrap transform-gpu overflow-hidden"
        id="demo-drawer-container"
      >
        <div
          ref={tweakpaneContainerRef}
          className="absolute top-2 right-2 opacity-90"
        />

        <button className="button" onClick={() => setVisible(true)}>
          打开抽屉
        </button>

        <Drawer
          visible={visible}
          onVisibleChange={setVisible}
          placement="right"
          container={
            params.useContainer
              ? document.getElementById('demo-drawer-container')! || undefined
              : undefined
          }
        >
          <div className="max-w-[350px] mx-auto flex flex-col w-full h-full p-4">
            <div>
              <div className="grid gap-1.5 p-4 text-center sm:text-left">
                <h2
                  id="radix-:r5m:"
                  className="text-lg font-semibold leading-none tracking-tight"
                >
                  Move Goal
                </h2>
                <p id="radix-:r5n:" className="text-sm text-muted-foreground">
                  Set your daily activity goal.
                </p>
              </div>
              <div className="p-4 pb-0">
                <div className="flex items-center justify-center space-x-2">
                  <div className="flex-1 text-center">
                    <div className="text-7xl font-bold tracking-tighter">
                      350
                    </div>
                    <div className="text-[0.70rem] uppercase text-muted-foreground">
                      Calories/day
                    </div>
                  </div>
                </div>
                <div className="mt-3 h-[120px]">
                  <div
                    className="recharts-responsive-container"
                    style={{ width: '100%', height: '100%', minWidth: '0px' }}
                  >
                    <div
                      className="recharts-wrapper"
                      style={{
                        position: 'relative',
                        cursor: 'default',
                        width: '100%',
                        height: '100%',
                        maxHeight: '120px',
                        maxWidth: '352px',
                      }}
                    >
                      <svg
                        className="recharts-surface"
                        width="352"
                        height="120"
                        viewBox="0 0 352 120"
                        style={{ width: '100%', height: '100%' }}
                      >
                        <title></title>
                        <desc></desc>
                        <defs>
                          <clipPath id="recharts20-clip">
                            <rect x="5" y="5" height="110" width="342"></rect>
                          </clipPath>
                        </defs>
                        <g className="recharts-layer recharts-bar">
                          <g className="recharts-layer recharts-bar-rectangles">
                            <g className="recharts-layer">
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="7.63076923076923"
                                  y="5"
                                  width="21"
                                  height="110"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 7.63076923076923,5 h 21 v 110 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="33.93846153846154"
                                  y="32.5"
                                  width="21"
                                  height="82.5"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 33.93846153846154,32.5 h 21 v 82.5 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="60.246153846153845"
                                  y="60"
                                  width="21"
                                  height="55"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 60.246153846153845,60 h 21 v 55 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="86.55384615384615"
                                  y="32.5"
                                  width="21"
                                  height="82.5"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 86.55384615384615,32.5 h 21 v 82.5 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="112.86153846153846"
                                  y="60"
                                  width="21"
                                  height="55"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 112.86153846153846,60 h 21 v 55 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="139.16923076923078"
                                  y="38.55000000000001"
                                  width="21"
                                  height="76.44999999999999"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 139.16923076923078,38.55000000000001 h 21 v 76.44999999999999 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="165.47692307692307"
                                  y="63.025000000000006"
                                  width="21"
                                  height="51.974999999999994"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 165.47692307692307,63.025000000000006 h 21 v 51.974999999999994 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="191.78461538461536"
                                  y="49.27499999999999"
                                  width="21"
                                  height="65.72500000000001"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 191.78461538461536,49.27499999999999 h 21 v 65.72500000000001 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="218.09230769230768"
                                  y="32.5"
                                  width="21"
                                  height="82.5"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 218.09230769230768,32.5 h 21 v 82.5 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="244.4"
                                  y="60"
                                  width="21"
                                  height="55"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 244.4,60 h 21 v 55 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="270.7076923076923"
                                  y="38.55000000000001"
                                  width="21"
                                  height="76.44999999999999"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 270.7076923076923,38.55000000000001 h 21 v 76.44999999999999 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="297.01538461538456"
                                  y="63.025000000000006"
                                  width="21"
                                  height="51.974999999999994"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 297.01538461538456,63.025000000000006 h 21 v 51.974999999999994 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                              <g className="recharts-layer recharts-bar-rectangle">
                                <path
                                  x="323.3230769230769"
                                  y="19.02499999999999"
                                  width="21"
                                  height="95.97500000000001"
                                  radius="0"
                                  className="recharts-rectangle"
                                  d="M 323.3230769230769,19.02499999999999 h 21 v 95.97500000000001 h -21 Z"
                                  style={{
                                    fill: 'hsl(var(--foreground))',
                                    opacity: 0.9,
                                  }}
                                ></path>
                              </g>
                            </g>
                          </g>
                          <g className="recharts-layer"></g>
                        </g>
                      </svg>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="mt-auto flex flex-col gap-2 p-4">
              <button
                onClick={() => setVisible(false)}
                className="cursor-pointer bg-neutral-900 inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 text-white shadow h-9 px-4 py-2"
              >
                Submit
              </button>
              <button
                className="cursor-pointer inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground h-9 px-4 py-2"
                type="button"
                onClick={() => setVisible(false)}
              >
                Cancel
              </button>
            </div>
          </div>
        </Drawer>
      </CodeBox>
      <CodeBlock>{`import { Drawer } from 'one-design-next';

const [visible, setVisible] = useState(false);

<div
  id="demo-drawer-container"
  // 如果你使用 tailwind
  className="transform-gpu overflow-hidden"
  // 如果你使用 css
  style={{ transform: 'translateZ(0)', overflow: 'hidden' }}
/>

<Drawer
  visible={visible}
  onVisibleChange={setVisible}
  placement="right"
  padding={12}
  container={${params.useContainer ? "document.getElementById('demo-drawer-container')!" : 'undefined'}}
/>`}</CodeBlock>
    </div>
  );
};

export default Container;
```
## API {#api}

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| visible | 是否显示 | `boolean` | - |
| onVisibleChange | 显隐变化 | `(visible: boolean) => void` | - |
| className / style | 包裹层 | `string` / `CSSProperties` | - |
| container | 挂载容器 | `HTMLElement` | - |
| elevated | 是否提升层级 | `boolean` | `false` |
| maskVisible / maskClosable | 遮罩 | `boolean` | `true` |
| maskStyle / maskClassName | 遮罩 | `CSSProperties` / `string` | - |
| padding | 内边距（圆角等） | `number` | `0` |
| placement | 方位 | `'top' \| 'left' \| 'right' \| 'bottom'` | `'right'` |
| zIndex | 层级 | `number \| string` | - |
| steps | 步骤内容 | `React.ReactNode[]` | - |
| step | 当前步骤 | `number` | - |
| stepTransitionType | 步骤过渡 | `'slide' \| 'fade'` | `'slide'` |
| title / desc | 标题 / 描述 | `React.ReactNode` | - |
| closable | 是否显示关闭 | `boolean` | `false` |
| closePlacement | 关闭按钮位置 | `'start' \| 'end'` | `'start'` |
| children | 内容 | `React.ReactNode` | - |

## 变量 {#variables}

<VariablesTable id="Drawer"></VariablesTable>

---

## 全局提醒 Message

## 基础用例 {#basic-usage}

**示例：基础用例** — 基础用例

```tsx
'use client';

import { Message } from 'one-design-next';
import React from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basic = () => {
  return (
    <div>
      <CodeBox className="gap-2 flex-wrap">
        {(['info', 'success', 'warning', 'danger'] as const).map((intent) => (
          <button
            key={intent}
            className="button"
            onClick={() => {
              Message[intent](`This is a ${intent} message.`);
            }}
          >
            {intent}
          </button>
        ))}
      </CodeBox>
      <CodeBlock>{`import { Message } from 'one-design-next';

() => { Message.info('This is a info message.') }
() => { Message.success('This is a success message.') }
() => { Message.warning('This is a warning message.') }
() => { Message.danger('This is a danger message.') }`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 可折叠 {#collapsible}

当传入一次 `collapsible` 为 `true`时，往后的提醒都将会被折叠。

**示例：可折叠** — 可折叠

```tsx
'use client';

import { Message } from 'one-design-next';
import React from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basic = () => {
  return (
    <div>
      <CodeBox className="gap-2 flex-wrap">
        <button
          className="button"
          onClick={() => {
            Message.warning({
              content: 'This is a warning message.',
              collapsible: true,
              sameCollapsible: false,
            });
          }}
        >
          折叠所有
        </button>
        <button
          className="button"
          onClick={() => {
            Message.info({
              content: 'This is a info message.',
              collapsible: false,
              sameCollapsible: false,
            });
          }}
        >
          展开所有
        </button>
      </CodeBox>
      <CodeBlock>{`import {Message} from 'one-design-next';

() => {
  Message.warning({
    content: 'This is a warning message.',
    collapsible: true,
  });
}

() => {
  Message.info({
    content: 'This is a info message.',
    collapsible: false,
  });
}`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 相同类别折叠 {#same-category-collapsible}

当传入 `sameCollapsible` 为 `true`时，相同类别的提醒将会被折叠。

**示例：相同类别折叠** — 相同类别折叠

```tsx
'use client';

import { Message } from 'one-design-next';
import React from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basic = () => {
  return (
    <div>
      <CodeBox className="gap-2 flex-wrap">
        {(['info', 'success', 'warning', 'danger'] as const).map((intent) => (
          <button
            key={intent}
            className="button"
            onClick={() => {
              Message[intent]({
                content: `This is a ${intent} message.`,
                sameCollapsible: true,
                collapsible: false,
                duration: 5,
                closable: true,
              });
            }}
          >
            {intent}
          </button>
        ))}
        <i className="mx-2 w-px h-4 bg-neutral-200" />
        <button
          className="button"
          onClick={() => {
            Message.info({
              content: 'This is a info message.',
              sameCollapsible: false,
              collapsible: false,
            });
          }}
        >
          展开所有
        </button>
      </CodeBox>
      <CodeBlock>{`import {Message} from 'one-design-next';

() => {
  Message.info({
    content: 'This is a info message.',
    sameCollapsible: true,
    duration: 5,
    closable: true,
  });
}`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 业务定制 {#business-customization}

**示例：业务定制** — 业务定制

```tsx
'use client';

import { ConfigProvider, Message } from 'one-design-next';
import React from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basic = () => {
  return (
    <div>
      <ConfigProvider
        icons={{
          'check-circle-filled': [
            'M10.9584 5.51315C11.1479 5.32374 11.455 5.32374 11.6444 5.51315L11.8733 5.74128C12.0626 5.9306 12.0624 6.23781 11.8733 6.42721L7.4647 10.8358C7.46235 10.8383 7.4593 10.8404 7.45688 10.8428L7.22876 11.0718C7.03937 11.2611 6.73223 11.2611 6.54282 11.0718L3.83345 8.36234C3.64405 8.17298 3.64407 7.86584 3.83345 7.67643L4.06235 7.44753C4.25178 7.25837 4.55897 7.25821 4.74829 7.44753L6.88579 9.58578L10.9584 5.51315Z',
            'M13.6664 8C13.6664 4.87047 11.1295 2.33295 8 2.33281C4.87039 2.33281 2.33281 4.87039 2.33281 8C2.33295 11.1295 4.87047 13.6664 8 13.6664C11.1294 13.6663 13.6663 11.1294 13.6664 8ZM15 8C14.9999 11.8658 11.8658 14.9999 8 15C4.13409 15 1.00014 11.8659 1 8C1 4.134 4.134 1 8 1C11.8659 1.00014 15 4.13409 15 8Z',
          ],
        }}
      >
        <CodeBox className="gap-2 flex-wrap">
          {(['success'] as const).map((intent) => (
            <button
              key={intent}
              className="button"
              onClick={() => {
                const newStyles = {
                  '--odn-message-top': '50px',
                  '--odn-message-font-size': '14px',
                  '--odn-message-height': '40px',
                  '--odn-message-success-box-shadow': 'none',
                  '--odn-message-success-prefix-color': '#08C77B',
                  '--odn-message-success-bg': '#E6F5EF',
                };

                document.documentElement.style.cssText = Object.entries(
                  newStyles,
                )
                  .map(([key, value]) => `${key}: ${value}`)
                  .join(';');

                Message[intent]({
                  content: `This is a ${intent} message.`,
                  collapsible: false,
                });
              }}
            >
              {intent}
            </button>
          ))}
        </CodeBox>
      </ConfigProvider>
      <CodeBlock>{`import { Message } from 'one-design-next';

html {
  --odn-message-top: 50px;
  --odn-message-font-size: 14px;
  --odn-message-height: 40px;
  --odn-message-success-box-shadow: none;
  --odn-message-success-prefix-color: #08C77B;
  --odn-message-success-bg: #E6F5EF;
}

() => { Message.success('This is a success message.') }`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## API {#api}

### Message / Message.info 等

静态方法：`Message.info`、`success`、`warning`、`danger`、`error`（参数为 `MessageProps` 或字符串）。

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| content | 内容（必填） | `React.ReactNode` | - |
| className | 类名 | `string` | - |
| style | 样式 | `React.CSSProperties` | - |
| closable | 是否显示关闭（可配合 `duration: 0`） | `boolean` | - |
| duration | 自动关闭毫秒数 | `number` | - |
| getContainer | 挂载容器 | `() => HTMLElement` | `document.body` |
| intent | 类型 | `'info' \| 'success' \| 'warning' \| 'danger' \| 'error'` | - |
| onClose | 关闭回调 | `() => void` | - |
| onMouseEnter / onMouseLeave | 鼠标进入 / 离开 | `() => void` | - |
| collapsible | 是否可折叠 | `boolean` | - |
| sameCollapsible | 同组折叠联动 | `boolean` | - |

## 变量 {#variables}

<VariablesTable id="Message"></VariablesTable>

---

## 气泡提示 Popover

## 基础用例 {#basic-usage}

**示例：基础用例** — 基础用例

```tsx
'use client';

import { Popover } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
import { Pane } from 'tweakpane';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basics = () => {
  const [params, setParams] = useState({
    arrowed: true,
    trigger: 'hover' as 'hover' | 'click' | 'focus',
  });

  const [currentPosition, setCurrentPosition] = useState('topLeft');

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'arrowed');
    pane.addBinding(params, 'trigger', {
      options: {
        hover: 'hover',
        click: 'click',
        focus: 'focus',
      },
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => pane.dispose();
  }, []);

  return (
    <div>
      <CodeBox className="pt-[120px]">
        <div
          ref={tweakpaneContainerRef}
          className="absolute top-2 right-2 opacity-90"
        />
        <div className="grid grid-cols-5 gap-1 w-fit mx-auto">
          {(
            [
              ['topLeft', 'col-start-2 row-start-1'],
              ['top', 'col-start-3 row-start-1'],
              ['topRight', 'col-start-4 row-start-1'],
              ['leftTop', 'col-start-1 row-start-2'],
              ['rightTop', 'col-start-5 row-start-2'],
              ['left', 'col-start-1 row-start-3'],
              ['right', 'col-start-5 row-start-3'],
              ['leftBottom', 'col-start-1 row-start-4'],
              ['rightBottom', 'col-start-5 row-start-4'],
              ['bottomLeft', 'col-start-2 row-start-5'],
              ['bottom', 'col-start-3 row-start-5'],
              ['bottomRight', 'col-start-4 row-start-5'],
            ] as const
          ).map(([placement, position]) => (
            <Popover
              key={placement}
              popup="This is a popup."
              trigger={params.trigger}
              placement={placement}
              arrowed={params.arrowed}
              onVisibleChange={(visible) => {
                if (visible) {
                  setCurrentPosition(placement);
                }
              }}
            >
              <button className={`button ${position}`}>{placement}</button>
            </Popover>
          ))}
        </div>
      </CodeBox>
      <CodeBlock>{`import { Popover } from 'one-design-next'

<Popover popup="This is a popup." trigger="${
        params.trigger
      }" placement="${currentPosition}"${
        !params.arrowed ? ' arrowed={false}' : ''
      }>
  ${currentPosition}
</Popover>`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## 自动翻转与偏移 {#auto-flip-offset}

`Popover` 会根据屏幕或父容器尺寸自动调整位置。

当 `Popover` 在上方或下方时，上下翻转，左右偏移；当 `Popover` 在左侧或右侧时，左右翻转，上下偏移。

**示例：翻转与偏移** — 翻转与偏移

```tsx
'use client';

import { Popover } from 'one-design-next';
import React from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Flip = () => {
  return (
    <div>
      <CodeBox className="px-0 pb-0 pt-48 h-[240px] overflow-auto">
        <div className="flex-none flex flex-col gap-20 items-center justify-center w-[200%] pt-32 pb-40">
          <Popover
            visible
            popup="This is a popup.This is a popup."
            portal={false}
          >
            <button className="sticky left-1 button">↕️ flip + ↔️ shift</button>
          </Popover>
          <Popover
            visible
            popup={
              <div>
                This is a popup.
                <br />
                <br />
                This is a popup.
              </div>
            }
            placement="left"
            portal={false}
          >
            <button className="sticky bottom-1 button">
              ↔️ flip + ↕️ shift
            </button>
          </Popover>
        </div>
      </CodeBox>
    </div>
  );
};

export default Flip;
```
## 自适应高度 {#auto-height}

使用 `autoPlacements` 以最大化利用空间。当使用 `autoPlacements` 时，`flip` 将会被替代：

**示例：自适应高度** — 自适应高度

```tsx
'use client';

import { Popover } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Height = () => {
  const [maxHeight, setMaxHeight] = useState(0);

  return (
    <div>
      <CodeBox className="p-0 h-[300px] overflow-auto block">
        <div className="flex-none flex flex-col gap-20 items-center justify-center py-[250px]">
          <Popover
            visible
            arrowed={false}
            popupStyle={{ padding: 0 }}
            popup={
              <div
                className="w-[200px] overflow-auto scrollbar-custom"
                style={{ maxHeight }}
              >
                {Array.from({ length: 6 }).map((_, index) => (
                  <div key={index} className="flex items-center pl-2 h-9">
                    name {index + 1}
                  </div>
                ))}
              </div>
            }
            portal={false}
            autoPlacements={['topRight', 'bottomRight']}
            size={({ availableHeight }) => {
              setMaxHeight(availableHeight - 30);
            }}
          >
            <button className="button">list</button>
          </Popover>
        </div>
      </CodeBox>
      <CodeBlock>
        {`import { Popover } from "one-design-next";

const [maxHeight, setMaxHeight] = useState(0);

<Popover
  autoPlacements={['topRight', 'bottomRight']}
  size={({ availableHeight }) => {
    setMaxHeight(availableHeight - 30);
  }}
  popupStyle={{ padding: 0 }}
  popup={
    <div className="w-[200px] overflow-auto scrollbar-custom" style={{ maxHeight }}>
      {Array.from({ length: 6 }).map((_, index) => (
        <div key={index} className="flex items-center pl-2 h-9">
          name {index + 1}
        </div>
      ))}
    </div>
  }
/>`}
      </CodeBlock>
    </div>
  );
};

export default Height;
```
## 匹配宽度 {#match-width}

使用 `matchWidth` 以匹配宽度。

**示例：匹配宽度** — 匹配宽度

```tsx
'use client';

import { Popover } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basics = () => {
  const [visible, setVisible] = useState(false);

  return (
    <div>
      <CodeBox>
        <Popover
          visible={visible}
          popup="This is a popup."
          onVisibleChange={(visible) => {
            setVisible(visible);
          }}
          arrowed={false}
          placement="bottom"
          matchWidth
        >
          <button className="button w-[200px]">controlled</button>
        </Popover>
      </CodeBox>
      <CodeBlock>{`import { Popover } from "one-design-next";

// ${visible ? 'true' : 'false'}
const [visible, setVisible] = useState(true);

<Popover
  popup="This is a popup."
  arrowed={false}
  
  placement="bottom"
  matchWidth
  visible={visible}
  onVisibleChange={(bool, e, reason) => {
    setVisible(bool);
  }}
>
  controlled
</Popover>`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## 祖先滚动时隐藏 {#hide-on-ancestor-scroll}

使用 `hideOnAncestorScroll` 以在祖先滚动时隐藏：

**示例：祖先滚动时隐藏** — 祖先滚动时隐藏

```tsx
'use client';

import { Popover } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basics = () => {
  const [visible, setVisible] = useState(false);

  return (
    <div>
      <CodeBox className="pb-0 h-[300px] overflow-auto block">
        <div className="flex-none flex flex-col gap-20 items-center justify-center pb-[250px]">
          <Popover
            visible={visible}
            popup="This is a popup."
            onVisibleChange={(visible) => {
              setVisible(visible);
            }}
            trigger="click"
            arrowed={false}
            placement="bottom"
            matchWidth
            hideOnAncestorScroll
          >
            <button className="button w-[200px]">hideOnAncestorScroll</button>
          </Popover>
        </div>
      </CodeBox>
      <CodeBlock>{`import { Popover } from "one-design-next";

<Popover hideOnAncestorScroll />`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## 合并 Popover {#merge-popover}

当相近的、成组的元素都拥有 `Popover` 时，可以考虑使它们共享。

在设计上，这也是 `HoverFill` 的核心理念。多个互相重叠当然也不是什么大问题，它只是让过渡变得"脏"了一点，让层级、信息重叠。

目前不提供一个组件"方便地"实现这样的设计。考虑到场景间的差异，我推荐每一次都需仔细实现。

**示例：merged-vercel** — merged-vercel

```tsx
'use client';

import { HoverFill, Popover } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basics = () => {
  const [visible, setVisible] = useState(false);
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);
  const lastHoverIndex = useRef(hoverIndex);
  const [lastValidHoverIndex, setLastValidHoverIndex] = useState<
    number | undefined
  >(undefined);
  const hoverTimer = useRef(0);
  const popupRef = useRef<HTMLDivElement>(null);

  // demo 我就直接写定尺寸了
  const menus = [
    {
      label: 'Products',
      img: 'https://wxa.wxs.qq.com/wxad-design/yijie/vercel-menu-0.webp',
      width: 744,
      height: 290,
    },
    {
      label: 'Solutions',
      img: 'https://wxa.wxs.qq.com/wxad-design/yijie/vercel-menu-1.webp',
      width: 496,
      height: 344,
    },
  ];

  const handleMouseEnter = (index: number) => {
    clearTimeout(hoverTimer.current);
    setHoverIndex(index);
    setLastValidHoverIndex(index);
    setVisible(true);
  };

  const handleMouseLeave = () => {
    clearTimeout(hoverTimer.current);

    hoverTimer.current = window.setTimeout(() => {
      setHoverIndex(null);
      setVisible(false);
    }, 200);
  };

  useEffect(() => {
    return () => {
      clearTimeout(hoverTimer.current);
    };
  }, []);

  useEffect(() => {
    if (popupRef.current) {
      popupRef.current.style.transition =
        lastHoverIndex.current === null ? 'none' : 'all 200ms ease-in-out';
    }

    if (lastHoverIndex.current !== hoverIndex) {
      lastHoverIndex.current = hoverIndex;
    }
  }, [hoverIndex]);

  return (
    <div>
      <CodeBox className="p-0 h-16">
        <div className="flex-1 h-full">
          <div className="flex items-center px-6 h-full">
            <svg className="mr-8 h-[18px]" viewBox="0 0 262 52" fill="none">
              <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M59.8 52L29.9 0L0 52H59.8ZM89.9574 49.6328L114.945 2.36365H104.137L86.8999 36.6921L69.6628 2.36365H58.8545L83.8423 49.6328H89.9574ZM260.248 2.36365V49.6329H251.3V2.36365H260.248ZM210.441 31.99C210.441 28.3062 211.21 25.0661 212.747 22.2699C214.285 19.4737 216.429 17.321 219.179 15.812C221.928 14.3029 225.144 13.5484 228.826 13.5484C232.088 13.5484 235.024 14.2585 237.634 15.6788C240.244 17.0991 242.317 19.2074 243.855 22.0036C245.393 24.7998 246.185 28.2174 246.232 32.2564V34.3202H219.878C220.064 37.2496 220.926 39.5576 222.464 41.2442C224.049 42.8864 226.169 43.7075 228.826 43.7075C230.503 43.7075 232.041 43.2637 233.439 42.376C234.838 41.4883 235.886 40.2899 236.585 38.7808L245.743 39.4466C244.624 42.7754 242.527 45.4385 239.451 47.4358C236.375 49.4331 232.834 50.4317 228.826 50.4317C225.144 50.4317 221.928 49.6772 219.179 48.1681C216.429 46.6591 214.285 44.5064 212.747 41.7102C211.21 38.914 210.441 35.6739 210.441 31.99ZM237.005 28.6612C236.678 25.7762 235.77 23.668 234.278 22.3365C232.787 20.9606 230.969 20.2726 228.826 20.2726C226.356 20.2726 224.352 21.0049 222.814 22.4696C221.276 23.9343 220.321 25.9982 219.948 28.6612H237.005ZM195.345 22.3365C196.836 23.5348 197.768 25.1993 198.141 27.3297L207.369 26.8637C207.043 24.1562 206.087 21.8039 204.503 19.8066C202.918 17.8093 200.868 16.278 198.351 15.2128C195.881 14.1032 193.155 13.5484 190.172 13.5484C186.49 13.5484 183.275 14.3029 180.525 15.812C177.775 17.321 175.632 19.4737 174.094 22.2699C172.556 25.0661 171.787 28.3062 171.787 31.99C171.787 35.6739 172.556 38.914 174.094 41.7102C175.632 44.5064 177.775 46.6591 180.525 48.1681C183.275 49.6772 186.49 50.4317 190.172 50.4317C193.248 50.4317 196.044 49.8769 198.561 48.7673C201.077 47.6133 203.128 45.9933 204.712 43.9072C206.297 41.8212 207.252 39.38 207.578 36.5838L198.281 36.1844C197.955 38.5367 197.046 40.3565 195.555 41.6436C194.063 42.8864 192.269 43.5078 190.172 43.5078C187.283 43.5078 185.046 42.5091 183.461 40.5118C181.877 38.5145 181.084 35.6739 181.084 31.99C181.084 28.3062 181.877 25.4656 183.461 23.4683C185.046 21.471 187.283 20.4723 190.172 20.4723C192.176 20.4723 193.9 21.0937 195.345 22.3365ZM149.953 14.3457H158.28L158.52 21.137C159.111 19.2146 159.933 17.7218 160.986 16.6585C162.512 15.1166 164.64 14.3457 167.369 14.3457H170.769V21.6146H167.3C165.357 21.6146 163.761 21.8789 162.512 22.4075C161.309 22.9362 160.384 23.7732 159.737 24.9186C159.135 26.064 158.835 27.5178 158.835 29.2799V49.6328H149.953V14.3457ZM111.546 22.2699C110.008 25.0661 109.239 28.3062 109.239 31.99C109.239 35.6739 110.008 38.914 111.546 41.7102C113.084 44.5064 115.228 46.6591 117.977 48.1681C120.727 49.6772 123.942 50.4317 127.624 50.4317C131.632 50.4317 135.174 49.4331 138.25 47.4358C141.325 45.4385 143.423 42.7754 144.541 39.4466L135.384 38.7808C134.684 40.2899 133.636 41.4883 132.238 42.376C130.84 43.2637 129.302 43.7075 127.624 43.7075C124.968 43.7075 122.847 42.8864 121.263 41.2442C119.725 39.5576 118.863 37.2496 118.676 34.3202H145.03V32.2564C144.984 28.2174 144.192 24.7998 142.654 22.0036C141.116 19.2074 139.042 17.0991 136.432 15.6788C133.822 14.2585 130.886 13.5484 127.624 13.5484C123.942 13.5484 120.727 14.3029 117.977 15.812C115.228 17.321 113.084 19.4737 111.546 22.2699ZM133.077 22.3365C134.568 23.668 135.477 25.7762 135.803 28.6612H118.746C119.119 25.9982 120.074 23.9343 121.612 22.4696C123.15 21.0049 125.154 20.2726 127.624 20.2726C129.768 20.2726 131.585 20.9606 133.077 22.3365Z"
                fill="black"
              />
            </svg>
            <Popover
              visible={visible}
              offset={{
                crossAxis: -120,
              }}
              arrowOffset={{
                x: lastValidHoverIndex === 0 ? -48 : 48,
              }}
              placement="bottomLeft"
              shift={false}
              flip={false}
              autoPlacements={[]}
              popupStyle={{ maxWidth: 'initial', padding: '8px' }}
              popup={
                <div
                  className="relative transition-all duration-200 overflow-hidden"
                  style={{
                    width:
                      lastValidHoverIndex !== undefined
                        ? menus[lastValidHoverIndex].width
                        : 0,
                    height:
                      lastValidHoverIndex !== undefined
                        ? menus[lastValidHoverIndex].height
                        : 0,
                  }}
                  ref={popupRef}
                  onMouseEnter={() => {
                    clearTimeout(hoverTimer.current);
                  }}
                  onMouseLeave={handleMouseLeave}
                >
                  <img
                    className={`absolute top-0 left-0 transition-all duration-200 ${
                      lastValidHoverIndex === 0
                        ? 'opacity-100'
                        : 'opacity-0 -translate-x-12'
                    }`}
                    style={{
                      maxWidth: menus[0].width,
                      width: menus[0].width,
                      height: menus[0].height,
                    }}
                    src={menus[0].img}
                  />
                  <img
                    className={`absolute top-0 left-0 transition-all duration-200 ${
                      lastValidHoverIndex === 1
                        ? 'opacity-100'
                        : 'opacity-0 translate-x-12'
                    }`}
                    style={{
                      maxWidth: menus[1].width,
                      width: menus[1].width,
                      height: menus[1].height,
                    }}
                    src={menus[1].img}
                  />
                </div>
              }
            >
              <div className="flex items-center">
                {menus.map((menu, index) => (
                  <HoverFill bgClassName="rounded-[30px]" key={index}>
                    <div
                      className="group flex items-center justify-center gap-1 px-2 h-[30px] text-sm transition-all duration-200 text-neutral-500 hover:text-neutral-900"
                      onMouseEnter={() => {
                        handleMouseEnter(index);
                      }}
                      onMouseLeave={handleMouseLeave}
                    >
                      {menu.label}
                      <svg
                        className="size-4 transition-all duration-200 group-hover:rotate-180"
                        viewBox="0 0 16 16"
                      >
                        <path
                          fillRule="evenodd"
                          clipRule="evenodd"
                          d="M12.0607 6.74999L11.5303 7.28032L8.7071 10.1035C8.31657 10.4941 7.68341 10.4941 7.29288 10.1035L4.46966 7.28032L3.93933 6.74999L4.99999 5.68933L5.53032 6.21966L7.99999 8.68933L10.4697 6.21966L11 5.68933L12.0607 6.74999Z"
                          fill="currentColor"
                        />
                      </svg>
                    </div>
                  </HoverFill>
                ))}
              </div>
            </Popover>
          </div>
        </div>
      </CodeBox>
      <div className="flex justify-between items-center mb-6 pb-6 dotted-bottom" />
    </div>
  );
};

export default Basics;
```

**示例：merged-huxuan** — merged-huxuan

```tsx
'use client';

import { HoverFill, Popover } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basics = () => {
  const [visible, setVisible] = useState(false);
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);
  const lastHoverIndex = useRef(hoverIndex);
  const [lastValidHoverIndex, setLastValidHoverIndex] = useState<
    number | undefined
  >(undefined);
  const hoverTimer = useRef(0);
  const popupRef = useRef<HTMLDivElement>(null);

  // demo 我就直接写定尺寸了
  const menus = [
    {
      label: '创作者广场',
      list: [
        {
          label: '视频号',
          icon: (
            <svg className="size-6 mr-3" viewBox="0 0 16 16" fill="none">
              <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M2.60045 2.25C3.29833 2.25 3.90902 2.6364 4.40208 3.0815C4.90994 3.53996 5.40329 4.16132 5.87488 4.83968C6.59123 5.87012 7.32625 7.1371 8.02784 8.33073C8.73537 7.13993 9.46942 5.86659 10.1604 4.84702C10.6183 4.17136 11.0924 3.55173 11.5745 3.09421C12.0361 2.65616 12.6256 2.25 13.31 2.25C14.5482 2.25 14.9262 3.57642 14.9866 4.58262C15.0513 5.65825 14.875 7.03717 14.5814 8.3697C14.2863 9.70926 13.8588 11.0641 13.386 12.1004C13.0184 12.9061 12.409 14.1667 11.3628 14.1667C10.466 14.1667 9.74138 13.4715 9.19771 12.8331C8.80491 12.3719 8.40818 11.8077 8.01372 11.1964C7.60193 11.8137 7.18292 12.3837 6.76224 12.8495C6.1556 13.5213 5.38044 14.1667 4.4781 14.1667C3.4224 14.1667 2.86455 12.8928 2.51764 12.085C2.07319 11.0502 1.67329 9.69725 1.3966 8.36033C1.12111 7.02923 0.955766 5.6566 1.0104 4.58927C1.06004 3.61932 1.37845 2.25 2.60045 2.25ZM7.14315 9.78243C6.29449 8.35803 5.4676 6.88168 4.64325 5.6959C4.19593 5.05244 3.77911 4.53991 3.39696 4.19493C3.06548 3.89569 2.83008 3.78596 2.67969 3.7579C2.67751 3.76224 2.67521 3.76693 2.67278 3.77199C2.59994 3.92382 2.53159 4.21364 2.50844 4.66594C2.4631 5.55173 2.602 6.78327 2.86547 8.05634C3.12774 9.32358 3.50149 10.5748 3.8959 11.4931C4.0613 11.8782 4.25798 12.3557 4.56859 12.6566C4.78666 12.6114 5.14326 12.4042 5.64899 11.8442C6.12283 11.3195 6.62203 10.6053 7.14315 9.78243ZM8.90148 9.79122C9.41038 10.6166 9.89058 11.3332 10.3397 11.8605C10.585 12.1486 10.9071 12.5496 11.2939 12.6557C11.6345 12.3597 11.8394 11.8766 12.0213 11.4778C12.4396 10.5609 12.8379 9.31158 13.1165 8.04697C13.3967 6.77533 13.5421 5.55009 13.4893 4.67259C13.472 4.38457 13.4577 3.99902 13.2826 3.75174C13.1776 3.7642 12.958 3.84923 12.6071 4.18222C12.2426 4.52814 11.84 5.04241 11.4021 5.68856C10.5886 6.88898 9.77244 8.35606 8.90148 9.79122Z"
                fill="#FA9D3B"
              />
            </svg>
          ),
        },
        {
          label: '公众号',
          icon: (
            <svg className="size-6 mr-3" viewBox="0 0 18 18" fill="none">
              <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M13.8814 4.79098C13.1501 3.28732 11.3003 2.0003 9.20591 2C8.10694 1.99971 6.42804 2.37698 5.17344 3.89406C4.33562 4.90711 4.05354 6.09273 4.2301 7.27512C4.35139 8.08744 4.80383 9.15915 5.45124 9.83707C5.6953 8.11854 6.60047 6.76697 7.78728 5.77352C9.93011 4.13649 12.2178 4.22918 13.8814 4.79098ZM15.5532 7.36963C14.2422 5.6682 11.9758 5.19218 9.92999 5.95086L9.9468 5.95592C10.0072 5.9741 10.0675 5.99225 10.1276 6.01261C13.1566 7.04453 14.7937 10.3305 13.7841 13.352C13.5155 14.1558 13.0854 14.8588 12.5437 15.4399C13.1963 15.2592 13.8642 15.0008 14.4372 14.5593C16.744 12.7818 17.1981 9.5042 15.5532 7.36963ZM7.86661 12.6553C8.29547 12.7511 8.74128 12.804 9.20153 12.804C10.6028 12.804 11.7126 12.478 12.7609 11.7068C12.7338 12.143 12.6026 12.6681 12.4827 12.9773C11.496 15.5232 8.63959 16.6267 5.64612 15.6436C3.04319 14.7887 1.44815 11.7365 2.17692 9.18889C2.37234 8.5061 2.57203 8.03774 2.94695 7.44839C3.17184 9.09073 4.19433 10.6881 5.68502 11.7047C5.79835 11.7811 5.87587 11.9085 5.88221 12.0561C5.88427 12.1051 5.87573 12.1511 5.86482 12.1989L5.61458 13.3347C5.61166 13.3482 5.60822 13.3619 5.60474 13.3757C5.59454 13.4162 5.58408 13.4578 5.58584 13.4991C5.59115 13.6218 5.69431 13.7174 5.81648 13.7121C5.86453 13.71 5.90284 13.6903 5.94249 13.6651L7.35699 12.7583C7.46339 12.6901 7.57731 12.6461 7.70435 12.6407C7.76035 12.6382 7.81429 12.6445 7.86661 12.6553Z"
                fill="#07c160"
              />
            </svg>
          ),
        },
        {
          label: '小程序',
          icon: (
            <svg className="size-6 mr-3" viewBox="0 0 18 18" fill="none">
              <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M9.93333 3.56419C8.8145 4.21631 8.06667 5.36894 8.06667 6.68364V12.1497C8.06667 13.1341 7.12633 13.9321 5.96667 13.9321C4.80677 13.9321 3.86667 13.1341 3.86667 12.1497C3.86667 11.4491 4.34407 10.8447 5.03683 10.5534C5.08677 10.5325 5.1374 10.5125 5.18943 10.4949C5.62553 10.3167 5.99957 9.98205 6.1384 9.59348C6.3435 9.01978 5.96177 8.55493 5.28603 8.55493C5.11757 8.55493 4.94677 8.58393 4.78203 8.63621C3.80273 8.92258 2.98723 9.54904 2.4977 10.3673C2.18153 10.8961 2 11.5033 2 12.1497C2 14.1809 3.7794 15.8333 5.96667 15.8333C6.7383 15.8333 7.45673 15.6244 8.06667 15.2691C9.1855 14.617 9.93333 13.4644 9.93333 12.1497V6.68364C9.93333 5.69928 10.8734 4.90123 12.0333 4.90123C13.193 4.90123 14.1333 5.69928 14.1333 6.68364C14.1333 7.41419 13.6156 8.04207 12.8743 8.31728C12.3962 8.48055 12.0044 8.83299 11.8551 9.25055C11.6511 9.82139 12.031 10.2843 12.7037 10.2843C12.8561 10.2843 13.0101 10.2577 13.1601 10.2145C13.1846 10.2076 13.2089 10.2 13.2331 10.1926C14.2043 9.90528 15.0149 9.28073 15.5021 8.46605C15.8185 7.93751 16 7.33006 16 6.68364C16 4.65241 14.2206 3 12.0333 3C11.2617 3 10.5433 3.2089 9.93333 3.56419Z"
                fill="#605AB0"
              />
            </svg>
          ),
        },
        {
          label: 'QQ短视频',
          icon: (
            <svg className="size-6 mr-3" viewBox="0 0 32 32" fill="none">
              <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M24.4631 7.56752C26.7059 9.68039 28.106 12.6778 28.106 16.0022C28.106 22.4011 22.9187 27.5884 16.5198 27.5884C10.1209 27.5884 4.93359 22.4011 4.93359 16.0022C4.93359 9.60334 10.1209 4.41602 16.5198 4.41602C18.6717 4.41602 20.6866 5.00266 22.4132 6.02476C22.5 6.07079 22.5863 6.11856 22.6721 6.16807C23.3484 6.55856 23.9472 7.03176 24.4631 7.56752ZM13.0595 7.28186C9.59205 8.65894 7.14049 12.0443 7.14049 16.0022C7.14049 21.1823 11.3398 25.3815 16.5198 25.3815C21.4188 25.3815 25.4405 21.6256 25.8625 16.8363C25.7929 16.9744 25.719 17.1114 25.6406 17.247C23.401 21.1261 18.4408 22.4552 14.5617 20.2156C10.6826 17.976 9.35351 13.0158 11.5931 9.13666C11.9998 8.43228 12.4962 7.81198 13.0595 7.28186ZM21.3302 7.94873C18.5448 6.50462 15.089 7.49543 13.5043 10.2401C11.8742 13.0637 12.8416 16.6742 15.6652 18.3044C18.4887 19.9346 22.0992 18.9671 23.7294 16.1436C25.0676 13.8257 24.6554 10.9776 22.9029 9.12998C22.4228 8.68378 21.8958 8.28731 21.3302 7.94873Z"
                fill="#0099FF"
              />
            </svg>
          ),
        },
      ],
      width: 145,
      height: 54 * 4,
    },
    {
      label: '管理中心',
      list: [
        {
          label: '互选订单管理',
          icon: null,
        },
        {
          label: '互选结案报告管理',
          icon: null,
        },
      ],
      width: 152,
      height: 54 * 2,
    },
  ];

  const handleMouseEnter = (index: number) => {
    clearTimeout(hoverTimer.current);
    setHoverIndex(index);
    setLastValidHoverIndex(index);
    setVisible(true);
  };

  const handleMouseLeave = () => {
    clearTimeout(hoverTimer.current);

    hoverTimer.current = window.setTimeout(() => {
      setHoverIndex(null);
      setVisible(false);
    }, 200);
  };

  useEffect(() => {
    return () => {
      clearTimeout(hoverTimer.current);
    };
  }, []);

  useEffect(() => {
    if (popupRef.current) {
      popupRef.current.style.transition =
        lastHoverIndex.current === null ? 'none' : 'all 150ms ease-in-out';
    }

    if (lastHoverIndex.current !== hoverIndex) {
      lastHoverIndex.current = hoverIndex;
    }
  }, [hoverIndex]);

  return (
    <div>
      <CodeBox className="p-0 h-16 overflow-hidden">
        <div className="flex-1 h-full bg-white">
          <div className="flex items-center px-6 h-full">
            <svg className="mr-8 h-[30px]" viewBox="0 0 207 32" fill="none">
              <path
                d="M11.1802 28.874L5.55112 23.2449L10.6325 19.2288C11.906 18.2223 13.7294 18.3206 14.8874 19.458C16.0538 20.6036 16.177 22.4413 15.1741 23.7324L11.1802 28.874Z"
                fill="#A1E6C2"
              ></path>
              <path
                d="M26.6437 12.4547C25.3679 13.4852 23.5203 13.3872 22.3607 12.2276C21.2348 11.1017 21.1054 9.32028 22.0567 8.0435L25.4667 3.46693L31.3334 8.66693L26.6437 12.4547Z"
                fill="#A1E6C2"
              ></path>
              <path
                d="M11.2084 3.15234L5.55152 8.8092L10.7196 12.6306C11.997 13.5751 13.77 13.4574 14.9114 12.3523C16.1276 11.1747 16.2357 9.26056 15.1599 7.95345L11.2084 3.15234Z"
                fill="#FAD5AF"
              ></path>
              <path
                d="M26.3728 19.4619C25.0965 18.477 23.2846 18.6053 22.1599 19.7602C21.0698 20.8795 20.9563 22.6255 21.8924 23.8765L25.6769 28.9339L31.3906 23.3339L26.3728 19.4619Z"
                fill="#FAD5AF"
              ></path>
              <path
                d="M8.72608 18.3335C9.99568 18.1394 10.9334 17.0475 10.9334 15.7631C10.9334 14.4932 10.016 13.409 8.76357 13.1988L4.80008 12.5336L4.80008 18.9336L8.72608 18.3335Z"
                fill="#8ED2FF"
              ></path>
              <path
                d="M28.6074 18.3335C27.3378 18.1394 26.4 17.0475 26.4 15.7631C26.4 14.4932 27.3174 13.409 28.5699 13.1988L32.5334 12.5336V18.9336L28.6074 18.3335Z"
                fill="#8ED2FF"
              ></path>
              <circle cx="28.8" cy="5.60059" r="4" fill="#07C160"></circle>
              <circle cx="8.26672" cy="26.1338" r="4" fill="#07C160"></circle>
              <circle cx="8.26672" cy="5.86719" r="4" fill="#FA9D3B"></circle>
              <circle cx="28.8" cy="26.4004" r="4" fill="#FA9D3B"></circle>
              <circle cx="18.6667" cy="15.7342" r="3.2" fill="#296BEF"></circle>
              <circle cx="32.8" cy="15.7342" r="3.2" fill="#296BEF"></circle>
              <circle cx="4.53337" cy="15.7342" r="3.2" fill="#296BEF"></circle>
              <path
                d="M52.1745 7.29102H47.7819V17.1786C47.796 19.9123 47.647 22.6443 47.3356 25.3603H49.1814C49.3006 24.3615 49.5319 22.0535 49.595 18.8261H51.1932V25.3603H53.1395V8.27813C53.1396 8.02033 53.0387 7.77272 52.8583 7.58826C52.678 7.40379 52.4326 7.29711 52.1745 7.29102ZM50.9362 8.86154C50.9997 8.87004 51.0587 8.89903 51.1043 8.9441C51.1498 8.98916 51.1794 9.04785 51.1885 9.11124V12.25H49.6043V8.86154H50.9362ZM49.6067 17.2626V13.8228H51.1885V17.2649L49.6067 17.2626Z"
                fill="#333333"
              ></path>
              <path
                d="M71.5724 11.0642L70.056 6.73535H68.0723L69.5887 11.0642H71.5724Z"
                fill="#333333"
              ></path>
              <path
                d="M71.1939 12.1777H67.14L66.9203 13.7483H69.2475V25.3884L73.5958 23.1878V21.2602L71.1939 22.476V12.1777Z"
                fill="#333333"
              ></path>
              <path
                d="M83.6545 8.27813C83.6545 8.1485 83.629 8.02015 83.5793 7.90039C83.5296 7.78062 83.4568 7.6718 83.3651 7.58014C83.2733 7.48848 83.1643 7.41576 83.0444 7.36615C82.9245 7.31654 82.796 7.29102 82.6662 7.29102H72.6869L72.9533 8.86154H81.3484C81.4442 8.86338 81.5355 8.90287 81.6024 8.97144C81.6693 9.04002 81.7065 9.13217 81.7059 9.22792V14.1519H77.7852V10.2127L75.8389 9.88367V14.1519H72.9696V15.7224H75.8319V25.3603H77.7782V15.7224H81.6989V25.3603H85.185L85.449 23.7897H83.6475L83.6545 8.27813Z"
                fill="#333333"
              ></path>
              <path
                d="M62.6095 16.887V16.7563C63.0762 17.0788 63.5686 17.3629 64.0815 17.6057L64.9016 15.8905C63.8864 15.4166 62.9809 14.7372 62.2426 13.8952H64.6679V12.3224H59.3126C59.4609 11.9563 59.5888 11.5824 59.6958 11.2022H64.6679V9.62938H63.0955C63.5885 8.55825 64.0885 7.08806 64.0885 7.08806H61.9576C61.6843 7.9559 61.3541 8.80485 60.9692 9.62938H60.0346C60.1096 9.0881 60.1471 8.54229 60.1468 7.99584V6.72168H58.2448V7.99584C58.2443 8.54304 58.1997 9.08931 58.1117 9.62938H57.4621L56.4574 7.08806H54.3265L55.3312 9.62938H53.747V11.2022H57.7191C57.5851 11.5864 57.4243 11.9607 57.2378 12.3224H53.7354V13.8952H56.1607C55.4224 14.7372 54.5169 15.4166 53.5017 15.8905L54.3195 17.6057C54.7911 17.3845 55.2457 17.1287 55.6793 16.8403L55.649 16.887H60.6702V18.7935H57.4201L57.4855 17.9231L55.5368 17.5567L55.3546 20.3571H62.6328L62.4436 23.7805H59.787L60.0533 25.351H64.3034L64.6095 19.8647C64.6172 19.7257 64.5963 19.5866 64.5484 19.4559C64.5004 19.3253 64.4263 19.2057 64.3305 19.1046C64.2347 19.0035 64.1193 18.9229 63.9913 18.8679C63.8634 18.8128 63.7255 18.7843 63.5861 18.7842H62.6071V16.887H62.6095ZM59.8851 13.8952C60.2325 14.4561 60.6365 14.98 61.0907 15.4588H57.3149C57.7691 14.98 58.1731 14.4561 58.5206 13.8952H59.8851Z"
                fill="#333333"
              ></path>
              <path
                d="M97.6338 6.73535H95.5029L96.0964 8.42489H88.5565V15.8925C88.5565 22.0649 87.6896 24.9166 87.5447 25.3507H89.6476C89.9911 24.0509 90.5822 21.0685 90.5822 15.8925V10.1798H105.174V8.42489H98.2273L97.6338 6.73535Z"
                fill="#333333"
              ></path>
              <path
                d="M61.4481 21.3281H53.9199L54.1745 22.8263H61.378L61.4481 21.3281Z"
                fill="#333333"
              ></path>
              <path
                d="M121.695 17.795H108.405V25.3606H122.684V18.6677C122.656 18.426 122.54 18.2031 122.357 18.0419C122.175 17.8808 121.939 17.7928 121.695 17.795ZM110.354 23.7714V19.3935H120.452C120.528 19.3959 120.601 19.4276 120.654 19.482C120.707 19.5364 120.737 19.6092 120.737 19.6852V23.7714H110.354Z"
                fill="#333333"
              ></path>
              <path
                d="M116.592 14.2916V10.5578H123.308V8.98497H116.592V6.73535H114.644V8.99196H110.204C110.382 8.07485 110.464 7.39344 110.489 7.16241H108.62C108.378 9.08622 107.881 10.9695 107.144 12.7631H109.158C109.431 12.0413 109.665 11.3051 109.859 10.5578H114.646V14.2916H106.849V15.8622H124.242V14.2916H116.592Z"
                fill="#333333"
              ></path>
              <path
                d="M202.52 14.2415L202.519 14.2411L202.173 15.3391H187.681C189.791 12.9566 192.18 9.1437 193.741 6.71973H196.467C194.813 9.22657 193.096 12.2486 191.96 13.5331H201.97L201.842 13.363C200.902 12.1094 199.903 10.7454 199.047 9.49673H201.514C202.428 10.7274 203.602 12.1981 204.741 13.6263C205.405 14.4581 206.057 15.2755 206.64 16.0228H203.796C203.4 15.4428 202.96 14.8421 202.52 14.2415Z"
                fill="#333333"
              ></path>
              <path
                d="M148.081 6.74045C148.756 8.10782 149.642 9.64093 150.682 11.3812H148.212C147.963 10.8745 147.709 10.3701 147.452 9.85918C146.953 8.86625 146.441 7.84841 145.925 6.74045H148.081Z"
                fill="#333333"
              ></path>
              <path
                d="M164.323 13.9709V15.7319H161.187L161.104 20.4763H164.764L164.391 22.2787H159.059L159.179 15.7319H157.012C156.952 17.8244 156.262 20.0412 154.84 22.113H152.133C154.148 19.6476 154.903 17.7416 154.933 15.7319H151.778L151.778 13.9709H157.267V11.2983H154.495C153.91 12.1892 153.077 12.9558 151.917 13.4737L152.007 11.1997C152.966 10.4332 153.659 8.77079 153.72 7.42413H155.683C155.657 8.12854 155.527 8.83294 155.313 9.53734H157.267V6.74045H159.32V9.53734H163.571V11.2983H159.32V13.9709H164.323Z"
                fill="#333333"
              ></path>
              <path
                d="M150.503 20.3811C150.388 20.7179 150.269 21.0674 150.132 21.4086C152.562 23.066 156.23 23.5026 159.618 23.5026H165.013L164.621 25.3864H159.31C155.755 25.3864 152.562 24.9927 149.457 23.1489C149.112 23.9569 148.781 24.7234 148.456 25.3864H145.973C147.195 23.3768 148.151 21.1185 148.695 19.1918C148.728 18.0938 148.702 16.7264 148.636 15.6698C148.622 15.4212 148.568 15.3383 148.317 15.3383H146.053V13.598H149.404C150.219 13.598 150.506 13.8466 150.557 14.6546C150.655 16.0841 150.705 18.2181 150.701 19.8133C150.634 19.9956 150.569 20.1863 150.503 20.3811Z"
                fill="#333333"
              ></path>
              <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M143.092 7.5719V9.2363H131.768L131.329 12.2928H139.279C140.387 12.2928 140.768 12.7693 140.687 13.8259C140.466 16.7261 140.113 19.5965 139.704 23.5197H143.74V25.2931H125.253L125.253 23.5197H137.662C137.829 22.3341 137.955 21.1234 138.11 19.936H127.994C128.676 16.3311 129.323 12.8412 129.817 9.2363H125.484L125.484 7.5719H143.092ZM138.693 14.6132C138.721 14.2195 138.62 14.0952 138.327 14.0952H131.04C130.821 15.504 130.59 16.6976 130.329 18.1064H138.327C138.508 16.7183 138.607 15.6283 138.693 14.6132Z"
                fill="#333333"
              ></path>
              <path
                d="M184.445 7.36199H168.321V9.10228H175.093V16.4985H167.375V18.2388H175.093V25.3864H177.24V18.2388H185.422V16.4985H177.24V9.10228H184.445V7.36199Z"
                fill="#333333"
              ></path>
              <path
                d="M171.258 10.2003H169.02C169.83 12.2306 170.578 13.9709 171.243 15.4212H173.669C172.558 13.1837 171.768 11.4434 171.258 10.2003Z"
                fill="#333333"
              ></path>
              <path
                d="M181.326 15.4419C182.011 13.7845 182.539 12.0442 182.992 10.221H180.755C180.34 12.0235 179.708 13.7638 178.837 15.4419H181.326Z"
                fill="#333333"
              ></path>
              <path
                d="M202.943 17.7334H189.653V25.299H203.932V18.6062C203.904 18.3645 203.788 18.1416 203.605 17.9804C203.423 17.8193 203.187 17.7313 202.943 17.7334ZM191.602 23.7098V19.332H201.7C201.776 19.3344 201.849 19.3661 201.902 19.4205C201.955 19.4749 201.985 19.5477 201.985 19.6237V23.7098H191.602Z"
                fill="#333333"
              ></path>
            </svg>
            <Popover
              visible={visible}
              arrowed={false}
              placement="bottomLeft"
              shift={false}
              flip={false}
              autoPlacements={[]}
              popupStyle={{
                maxWidth: 'initial',
                padding: '12px 0',
                transform: `translateX(${
                  lastValidHoverIndex === 0 ? -18 : 78
                }px)`,
              }}
              popup={
                <div
                  className="relative transition-all duration-200 overflow-hidden"
                  style={{
                    width:
                      lastValidHoverIndex !== undefined
                        ? menus[lastValidHoverIndex].width
                        : 0,
                    height:
                      lastValidHoverIndex !== undefined
                        ? menus[lastValidHoverIndex].height
                        : 0,
                  }}
                  ref={popupRef}
                  onMouseEnter={() => {
                    clearTimeout(hoverTimer.current);
                  }}
                  onMouseLeave={handleMouseLeave}
                >
                  {menus.map((menu, index) => (
                    <div
                      key={index}
                      className={`absolute top-0 left-0 transition-all duration-200 ${
                        lastValidHoverIndex === index
                          ? 'opacity-100'
                          : 'opacity-0'
                      }`}
                      style={{
                        width: menu.width,
                        height: menu.height,
                      }}
                    >
                      {menu.list.map((list) => (
                        <HoverFill
                          key={list.label}
                          hoverColor="rgba(41, 107, 239, 0.05)"
                        >
                          <div className="flex items-center h-[54px] pl-3 text-[15px]">
                            {list.icon}
                            {list.label}
                          </div>
                        </HoverFill>
                      ))}
                    </div>
                  ))}
                </div>
              }
            >
              <div className="flex items-center">
                {menus.map((menu, index) => (
                  <HoverFill key={index} hoverColor="rgba(41, 107, 239, 0.05)">
                    <div
                      className="group flex items-center justify-cente…r gap-1 px-4 h-16 text-[15px] transition-all duration-200 text-neutral-900 hover:text-neutral-900"
                      onMouseEnter={() => {
                        handleMouseEnter(index);
                      }}
                      onMouseLeave={handleMouseLeave}
                    >
                      {menu.label}
                    </div>
                  </HoverFill>
                ))}
              </div>
            </Popover>
          </div>
        </div>
      </CodeBox>
      <div className="flex justify-between items-center mb-6 pb-6 dotted-bottom" />
    </div>
  );
};

export default Basics;
```

**示例：merged-button** — merged-button

```tsx
'use client';

import { Popover } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basics = () => {
  const [visible, setVisible] = useState(false);
  const [hoverIndex, setHoverIndex] = useState<number>(0);
  const lastHoverIndex = useRef(hoverIndex);
  const hoverTimer = useRef(0);

  const popovers = [
    {
      text: '平台基于达人近一年历史商单的R3人群增量相关数据进行智能推荐',
      offset: -88,
    },
    {
      text: '平台基于达人近一年历史商单的组件转化相关数据进行智能推荐',
      offset: 0,
    },
    {
      text: '平台基于达人的小店购物车权限及相关数据进行智能推荐',
      offset: 88,
    },
  ];

  const handleMouseEnter = (index: number) => {
    clearTimeout(hoverTimer.current);
    setHoverIndex(index);
    setVisible(true);
  };

  const handleMouseLeave = () => {
    clearTimeout(hoverTimer.current);

    hoverTimer.current = window.setTimeout(() => {
      setVisible(false);
    }, 100);
  };

  useEffect(() => {
    if (lastHoverIndex.current !== hoverIndex) {
      lastHoverIndex.current = hoverIndex;
    }
  }, [hoverIndex]);

  useEffect(() => {
    return () => {
      clearTimeout(hoverTimer.current);
    };
  }, []);

  return (
    <div>
      <CodeBox>
        <div>
          <div className="flex">
            <div className="w-[100px] text-neutral-500 text-sm leading-[36px]">
              营销目标
            </div>
            <div className="flex items-center gap-2 text-sm">
              <div className="flex items-center cursor-pointer h-9 px-3 text-[#296bef] font-semibold bg-[#2F6BEF1F] rounded-md">
                品牌曝光
              </div>
              <Popover
                visible={visible}
                placement="top"
                popup={
                  <div className="relative w-[210px] h-10">
                    {popovers.map((item, i) => (
                      <div
                        className={`absolute top-0 left-0 w-full h-full transition-all duration-100 ${
                          i === hoverIndex ? 'opacity-100' : 'opacity-0'
                        }`}
                        key={i}
                      >
                        {item.text}
                      </div>
                    ))}
                  </div>
                }
                popupStyle={{
                  transform: `translate3d(${
                    popovers[hoverIndex].offset
                  }px, 0, 0) scale(${visible ? 1 : 0.8})`,
                }}
              >
                <div className="flex gap-2">
                  <div
                    className="flex items-center cursor-pointer h-9 px-3 bg-[#49597A0D] hover:bg-[#f2f4f7] rounded-md"
                    onMouseEnter={() => handleMouseEnter(0)}
                    onMouseLeave={handleMouseLeave}
                  >
                    破圈种草
                  </div>
                  <div
                    className="flex items-center cursor-pointer h-9 px-3 bg-[#49597A0D] hover:bg-[#f2f4f7] rounded-md"
                    onMouseEnter={() => handleMouseEnter(1)}
                  >
                    行动转化
                  </div>
                  <div
                    className="flex items-center cursor-pointer h-9 px-3 bg-[#49597A0D] hover:bg-[#f2f4f7] rounded-md"
                    onMouseEnter={() => handleMouseEnter(2)}
                    onMouseLeave={handleMouseLeave}
                  >
                    商品推广
                  </div>
                </div>
              </Popover>
            </div>
          </div>
        </div>
      </CodeBox>
    </div>
  );
};

export default Basics;
```
## 外层控制显示 {#external-control}

使用 `visible` 属性来控制显示：

**示例：外部控制** — 外部控制

```tsx
'use client';

import React from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { NotificationPopoverTrigger } from './notification-popover-trigger';

const Basics = () => {
  return (
    <div>
      <CodeBox>
        <NotificationPopoverTrigger />
      </CodeBox>
      <CodeBlock>{`'use client';

import { NotificationPopoverTrigger } from './notification-popover-trigger';
// 消息行与面板样式见同目录 controlled.scss

/** 文档默认：先展开，点「收起」后才随鼠标移出关闭 */
export function DocExample() {
  return <NotificationPopoverTrigger />;
}

/** 顶栏：默认收起，移入移出即切换 */
export function HeaderExample() {
  return (
    <NotificationPopoverTrigger
      initialVisible={false}
      stickyUntilCollapsed={false}
    />
  );
}`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## API {#api}

与 `PopBase` 的 `PopoverProps` 一致（`type` 固定为 popover）。

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| children | 触发器 | `React.ReactNode` | - |
| popup | 浮层内容 | `React.ReactNode` | - |
| trigger | 触发方式 | `'hover' \| 'focus' \| 'click'` | `'hover'` |
| visible | 受控显隐 | `boolean` | - |
| onVisibleChange | 显隐变化 | `(visible, e?, reason?) => void` | - |
| placement | 方位 | 见源码（含 topLeft 等） | `'top'` |
| autoPlacements | 自动选位的候选 | `placement[]` | `[]` |
| arrowed | 是否箭头 | `boolean` | `true` |
| arrowOffset | 箭头偏移 | `{ x?, y? }` | `{ x:0, y:0 }` |
| offset | 浮层偏移 | `number \| { mainAxis?, crossAxis?, alignmentAxis? }` | - |
| flip | 是否翻转 | `boolean` | `true` |
| shift | 是否 shift | `boolean` | `true` |
| matchWidth | 与触发器同宽 | `boolean` | `false` |
| portal | 是否 Portal | `boolean` | `true` |
| destroyOnHidden | 关闭后是否销毁 | `boolean` | `true` |
| hideOnAncestorScroll | 祖先滚动时隐藏 | `boolean` | `false` |
| mouseEnterDelay | 进入延迟（秒） | `number` | `0` |
| mouseLeaveDelay | 离开延迟（秒） | `number` | `0` |
| popupClassName / popupStyle | 浮层类名 / 样式 | `string` / `CSSProperties` | - |
| popupRootClassName / popupRootStyle | 浮层根节点 | `string` / `CSSProperties` | - |
| zIndex | 层级 | `number \| string` | - |
| size | 可用空间回调 | `(params) => void` | - |
| onMouseEnter / onMouseLeave | 鼠标事件 | `HTMLDivElement` 事件 | - |

## 变量 {#variables}

<VariablesTable id="Popover"></VariablesTable>

---

## 工具提示 Tooltip

## 基础用例 {#basic-usage}

用例可参考 `Popover`，API 完全一致。`Tooltip` 的默认 `mouseEnterDelay` 为 0.15。

**示例：基础用例** — 基础用例

```tsx
'use client';

import { Tooltip } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
import { Pane } from 'tweakpane';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basics = () => {
  const [params, setParams] = useState({
    arrowed: false,
    trigger: 'hover' as 'hover' | 'click' | 'focus',
  });

  const [currentPosition, setCurrentPosition] = useState('topLeft');

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'arrowed');
    pane.addBinding(params, 'trigger', {
      options: {
        hover: 'hover',
        click: 'click',
        focus: 'focus',
      },
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => pane.dispose();
  }, []);

  return (
    <div>
      <CodeBox className="pt-[120px]">
        <div
          ref={tweakpaneContainerRef}
          className="absolute top-2 right-2 opacity-90"
        />
        <div className="grid grid-cols-5 gap-1 w-fit mx-auto">
          {(
            [
              ['topLeft', 'col-start-2 row-start-1'],
              ['top', 'col-start-3 row-start-1'],
              ['topRight', 'col-start-4 row-start-1'],
              ['leftTop', 'col-start-1 row-start-2'],
              ['rightTop', 'col-start-5 row-start-2'],
              ['left', 'col-start-1 row-start-3'],
              ['right', 'col-start-5 row-start-3'],
              ['leftBottom', 'col-start-1 row-start-4'],
              ['rightBottom', 'col-start-5 row-start-4'],
              ['bottomLeft', 'col-start-2 row-start-5'],
              ['bottom', 'col-start-3 row-start-5'],
              ['bottomRight', 'col-start-4 row-start-5'],
            ] as const
          ).map(([placement, position]) => (
            <Tooltip
              key={placement}
              popup="This is a popup."
              trigger={params.trigger}
              placement={placement}
              arrowed={params.arrowed}
              onVisibleChange={(visible) => {
                if (visible) {
                  setCurrentPosition(placement);
                }
              }}
            >
              <button className={`button ${position}`}>{placement}</button>
            </Tooltip>
          ))}
        </div>
      </CodeBox>
      <CodeBlock>{`import { Tooltip } from 'one-design-next'

<Tooltip popup="This is a popup." trigger="${
        params.trigger
      }" placement="${currentPosition}"${
        !params.arrowed ? ' arrowed={false}' : ''
      }>
  ${currentPosition}
</Tooltip>`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## 合并 Tooltip {#merge-tooltip}

当相近的、成组的元素都拥有 `Tooltip` 时，可以考虑使用 `Tooltip.Group` 使它们共享。

在设计上，这也是 `HoverFill` 的核心理念。多个互相重叠当然也不是什么大问题，它只是让过渡变得"脏"了一点，让层级、信息重叠。

因此你很可能不需要使用 `Tooltip.Group`，只在多个元素是相近、成组的场景下使用即可：

**示例：merged** — merged

```tsx
import { HoverFill, Tooltip } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
import { Pane } from 'tweakpane';

const Basic = () => {
  const operations = [
    {
      icon: (
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
          <rect
            x="2"
            y="13.6665"
            width="12"
            height="1.33333"
            rx="0.5"
            fill="#0A0A0A"
            fillOpacity="0.84"
          />
          <path
            d="M9.5 3.5L11.5 5.5"
            stroke="#0A0A0A"
            strokeOpacity="0.84"
            strokeWidth="1.33333"
            strokeLinecap="square"
          />
          <path
            fillRule="evenodd"
            clipRule="evenodd"
            d="M10.3143 1.87953C10.6779 1.51594 11.2674 1.51594 11.631 1.87953L12.9477 3.19619C13.3112 3.55978 13.3112 4.14927 12.9477 4.51286L5.9753 11.4852L2.72146 12.3329C2.58386 12.3687 2.45848 12.2433 2.49433 12.1057L3.34197 8.85188L10.3143 1.87953Z"
            stroke="#0A0A0A"
            strokeOpacity="0.84"
            strokeWidth="1.33333"
          />
        </svg>
      ),
      popup: 'Edit ad unit',
    },
    {
      icon: (
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
          <path
            d="M3 4.66699H10.333C10.5171 4.66699 10.667 4.8159 10.667 5V13.667C10.6668 13.8509 10.517 14 10.333 14H3C2.81601 14 2.66717 13.8509 2.66699 13.667V5C2.66699 4.8159 2.81591 4.66699 3 4.66699Z"
            stroke="#0A0A0A"
            strokeOpacity="0.84"
            strokeWidth="1.33333"
          />
          <rect
            x="4.66797"
            y="7.3335"
            width="4"
            height="1.33333"
            rx="0.25"
            fill="#0A0A0A"
            fillOpacity="0.84"
          />
          <rect
            x="4.66797"
            y="10"
            width="4"
            height="1.33333"
            rx="0.25"
            fill="#0A0A0A"
            fillOpacity="0.84"
          />
          <path
            d="M13.0996 1.33838C13.6037 1.38972 13.9971 1.81582 13.9971 2.3335V11.0005L13.9922 11.1021C13.9445 11.5727 13.5702 11.9467 13.0996 11.9946L12.9971 12.0005H11.3301V10.6665H12.6641V2.6665H5.99707V4.00049H4.66406V2.3335C4.66406 1.81582 5.05739 1.38971 5.56152 1.33838L5.66406 1.3335H12.9971L13.0996 1.33838Z"
            fill="#0A0A0A"
            fillOpacity="0.84"
          />
        </svg>
      ),
      popup: 'Copy ad unit',
    },
    {
      icon: (
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
          <circle
            cx="8"
            cy="8"
            r="6.33333"
            stroke="#0A0A0A"
            strokeOpacity="0.84"
            strokeWidth="1.33333"
          />
          <path
            fillRule="evenodd"
            clipRule="evenodd"
            d="M6.16536 5.3335C6.44151 5.3335 6.66536 5.55735 6.66536 5.8335V10.1668C6.66536 10.443 6.44151 10.6668 6.16536 10.6668H5.83203C5.55589 10.6668 5.33203 10.443 5.33203 10.1668V5.8335C5.33203 5.55735 5.55589 5.3335 5.83203 5.3335H6.16536Z"
            fill="#0A0A0A"
            fillOpacity="0.84"
          />
          <path
            fillRule="evenodd"
            clipRule="evenodd"
            d="M10.1654 5.3335C10.4415 5.3335 10.6654 5.55735 10.6654 5.8335V10.1668C10.6654 10.443 10.4415 10.6668 10.1654 10.6668H9.83203C9.55589 10.6668 9.33203 10.443 9.33203 10.1668V5.8335C9.33203 5.55735 9.55589 5.3335 9.83203 5.3335H10.1654Z"
            fill="#0A0A0A"
            fillOpacity="0.84"
          />
        </svg>
      ),
      popup: 'Pause ad unit',
    },
    {
      icon: (
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
          <rect
            x="2"
            y="3.3335"
            width="12"
            height="1.33333"
            rx="0.5"
            fill="#0A0A0A"
            fillOpacity="0.84"
          />
          <rect
            x="4.66797"
            y="1"
            width="6.66667"
            height="1.33333"
            rx="0.5"
            fill="#0A0A0A"
            fillOpacity="0.84"
          />
          <rect
            x="6"
            y="6"
            width="1.33333"
            height="5.33333"
            rx="0.5"
            fill="#0A0A0A"
            fillOpacity="0.84"
          />
          <rect
            x="8.66797"
            y="6"
            width="1.33333"
            height="5.33333"
            rx="0.5"
            fill="#0A0A0A"
            fillOpacity="0.84"
          />
          <path
            d="M13 13.6665C13 14.4028 12.4032 15.0003 11.667 15.0005H4.33301C3.64287 15.0003 3.07521 14.4754 3.00684 13.8032L3 13.6665H13Z"
            fill="#0A0A0A"
            fillOpacity="0.84"
          />
          <path
            d="M3 6.1665C3 5.89036 3.22386 5.6665 3.5 5.6665H3.83333C4.10948 5.6665 4.33333 5.89036 4.33333 6.1665V13.6665C4.33333 14.0347 4.03486 14.3332 3.66667 14.3332C3.29848 14.3332 3 14.0347 3 13.6665V6.1665Z"
            fill="#0A0A0A"
            fillOpacity="0.84"
          />
          <path
            d="M11.668 6.1665C11.668 5.89036 11.8918 5.6665 12.168 5.6665H12.5013C12.7774 5.6665 13.0013 5.89036 13.0013 6.1665V13.6665C13.0013 14.0347 12.7028 14.3332 12.3346 14.3332C11.9664 14.3332 11.668 14.0347 11.668 13.6665V6.1665Z"
            fill="#0A0A0A"
            fillOpacity="0.84"
          />
        </svg>
      ),
      popup: 'Delete ad unit',
    },
  ];

  const [params, setParams] = useState({
    vertical: false,
    placement: 'bottom',
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'vertical');
    pane.addBinding(params, 'placement', {
      options: {
        top: 'top',
        bottom: 'bottom',
        left: 'left',
        right: 'right',
      },
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  return (
    <div>
      <CodeBox className="flex flex-col my-[100px] pt-[20px] pr-2 pb-[70px] gap-16">
        <Tooltip.Group
          placement={params.placement as 'top' | 'bottom' | 'left' | 'right'}
          as="div"
          className={`flex gap-2 ${params.vertical ? 'flex-col' : 'flex-row'}`}
        >
          {operations.map((operation, index) => (
            <Tooltip popup={operation.popup} key={index}>
              <HoverFill bgClassName="rounded-lg">
                <div className="flex items-center justify-center size-8">
                  {operation.icon}
                </div>
              </HoverFill>
            </Tooltip>
          ))}
        </Tooltip.Group>
      </CodeBox>
      <CodeBlock>{`import { Tooltip } from "one-design-next";

<Tooltip.Group
  placement="${params.placement}"
  as="div"
  className="flex ${params.vertical ? 'flex-col' : 'flex-row'} gap-2"
>
  <Tooltip popup="Edit ad unit">
    <HoverFill bgClassName="rounded-lg" />
  </Tooltip>
  ...
</Tooltip.Group>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## Tooltip API {#tooltip-api}

与 [Popover](/components/popover) 相同（`PopoverProps`），默认 `mouseEnterDelay` 为 **0.1**（秒）。

## Tooltip.Group API {#tooltip-group-api}

继承 `Omit<PopoverProps, 'popup' \| 'onMouseEnter' \| 'onMouseLeave'>` 与 `React.HTMLAttributes<HTMLElement>`。

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| as | 外层标签 | `keyof JSX.IntrinsicElements` | `'div'` |
| children | 多个子 `Tooltip`（从子节点读取 `popup` 与触发内容） | `React.ReactNode` | - |
| placement | 共享浮层方位 | 同 Popover | `'top'` |
| arrowed / autoPlacements / offset / flip / matchWidth / portal / shift | 同 Popover | 同左 | - |
| mouseEnterDelay / mouseLeaveDelay | 延迟（秒） | `number` | `0.1` / 内部默认 |
| popupClassName / popupStyle | 浮层样式 | `string` / `CSSProperties` | - |

## 变量 {#variables}

<VariablesTable id="Tooltip"></VariablesTable>
