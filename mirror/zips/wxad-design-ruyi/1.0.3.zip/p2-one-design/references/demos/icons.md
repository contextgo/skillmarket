## 图标 Icon

> 内置图标集合包含 OD 与 Lucide 两类风格，并统一为扁平命名空间。两者视觉风格不同（OD 多为 16×16 填充、Lucide 为 24×24 描边），相同 `size` 下重量天然不同，混用同一区域时请注意视觉一致性。

## 图标列表 {#all-icons}

**示例：全部图标** — 所有内置图标，名字即调用 name。

```tsx
'use client';

import { HoverFill, Icon, iconNames } from 'one-design-next';
import React from 'react';

const AllIcons = () => {
  return (
    <div className="markdown">
      <div className="grid grid-cols-7 text-neutral-700 text-[12px] whitespace-nowrap">
        {iconNames.map((icon) => (
          <HoverFill key={icon} className="aspect-square" bgClassName="rounded">
            <div className="flex flex-col items-center justify-center gap-2 h-full">
              <Icon size={24} name={icon} />
              <span className="scale-[0.9]">{icon}</span>
            </div>
          </HoverFill>
        ))}
      </div>
    </div>
  );
};

export default AllIcons;
```
## 图标自定义-draft {#icon-customization}

通过 `ConfigProvider` 的 `icons` 属性增加图标。

注意保证 icon 的 viewBox 为 `0 0 16 16`，且传入的 `string[]` 代表的是 `path` 的 `d` 属性。

**示例：config** — config

```tsx
'use client';

import { ConfigProvider, Icon } from 'one-design-next';
import React from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';

const Demo = () => {
  return (
    <div className="markdown">
      <ConfigProvider
        icons={{
          add: [
            'M15 13H1V14H15V13Z',
            'M12.7 4.5C13.1 4.1 13.1 3.5 12.7 3.1L10.9 1.3C10.5 0.9 9.9 0.9 9.5 1.3L2 8.8V12H5.2L12.7 4.5ZM10.2 2L12 3.8L10.5 5.3L8.7 3.5L10.2 2ZM3 11V9.2L8 4.2L9.8 6L4.8 11H3Z',
          ],
          copy: [
            'M14 5V14H5V5H14ZM14 4H5C4.73478 4 4.48043 4.10536 4.29289 4.29289C4.10536 4.48043 4 4.73478 4 5V14C4 14.2652 4.10536 14.5196 4.29289 14.7071C4.48043 14.8946 4.73478 15 5 15H14C14.2652 15 14.5196 14.8946 14.7071 14.7071C14.8946 14.5196 15 14.2652 15 14V5C15 4.73478 14.8946 4.48043 14.7071 4.29289C14.5196 4.10536 14.2652 4 14 4Z',
            'M2 9H1V2C1 1.73478 1.10536 1.48043 1.29289 1.29289C1.48043 1.10536 1.73478 1 2 1H9V2H2V9Z',
          ],
        }}
      >
        <CodeBox>
          <div className="flex gap-4 text-neutral-700 text-[12px] whitespace-nowrap">
            <Icon name="add" />
            <Icon name="copy" />
          </div>
        </CodeBox>
        <CodeBlock>{`import { ConfigProvider, Icon } from "one-design-next";

<ConfigProvider
  icons={{
    add: [
      'M15 13H1V14H15V13Z',
      'M12.7 4.5C13.1 4.1 13.1 3.5 12.7 3.1L10.9 1.3C10.5 0.9 9.9 0.9 9.5 1.3L2 8.8V12H5.2L12.7 4.5ZM10.2 2L12 3.8L10.5 5.3L8.7 3.5L10.2 2ZM3 11V9.2L8 4.2L9.8 6L4.8 11H3Z',
    ],
    copy: [...],
  }}
>
  <Icon name="add" />
  <Icon name="copy" />
</ConfigProvider>
  `}</CodeBlock>
      </ConfigProvider>
    </div>
  );
};

export default Demo;
```
## API {#api}

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| name | 图标名称（内置 SVG 或 ConfigProvider 注入） | `IconName \| string` | - |
| size | 宽高（px） | `number` | `16` |
| spin | 是否旋转（如 loading） | `boolean` | - |

继承 `Omit<React.SVGProps<SVGSVGElement>, 'name'>`。

导出的图标名常量：

- `iconNames`：内置全部图标 name（OD + Lucide 合并）

## 变量 {#variables}

<VariablesTable id="Icon"></VariablesTable>
