## 按钮 Button

## 基础用例 {#basic-usage}

**示例：basic** — basic

```tsx
'use client';

import { Button } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

const Basics = () => {
  const [params, setParams] = useState({
    size: 'medium',
    intent: 'normal',
    light: false,
    disabled: false,
    loading: false,
    icon: true,
    rightIcon: false,
    children: true,
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'size', {
      options: {
        small: 'small',
        medium: 'medium',
        large: 'large',
      },
    });

    pane.addBinding(params, 'intent', {
      options: {
        normal: 'normal',
        danger: 'danger',
        primary: 'primary',
      },
    });

    pane.addBinding(params, 'light', {
      type: 'boolean',
    });

    pane.addBinding(params, 'disabled', {
      type: 'boolean',
    });

    pane.addBinding(params, 'loading', {
      type: 'boolean',
    });

    pane.addBinding(params, 'icon', {
      type: 'boolean',
    });

    pane.addBinding(params, 'rightIcon', {
      type: 'boolean',
    });

    pane.addBinding(params, 'children', {
      type: 'boolean',
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <Button
          size={params.size as 'small' | 'medium' | 'large'}
          intent={params.intent as 'normal' | 'danger' | 'primary'}
          light={params.light}
          disabled={params.disabled}
          loading={params.loading}
          icon={params.icon ? 'plus' : undefined}
          rightIcon={params.rightIcon ? 'right' : undefined}
        >
          {params.children ? '按钮' : undefined}
        </Button>
      </CodeBox>
      <CodeBlock>{`import { Button } from "one-design-next";

<Button
  size="${params.size}"
  intent="${params.intent}"
  light={${params.light}}
  disabled={${params.disabled}}
  loading={${params.loading}}
  icon={${params.icon ? 'plus' : undefined}}
  rightIcon={${params.rightIcon ? 'right' : undefined}}
>${params.children ? '按钮' : ''}</Button>`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## 轻量按钮 {#light-button}

`Button` 直接使用了 `HoverFill`，同组（同一父元素）的 `Button` 会共享背景：

**示例：light** — light

```tsx
'use client';

import { Button } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

const Basics = () => {
  const [params, setParams] = useState({
    intent: 'normal' as 'normal' | 'danger' | 'primary',
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'intent', {
      options: {
        normal: 'normal',
        danger: 'danger',
        primary: 'primary',
      },
    });
    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <div className="flex items-center">
          <div>
            <Button intent={params.intent} light>
              different parent
            </Button>
          </div>
          <i className="mx-2 w-px h-4 bg-neutral-300" />
          <Button intent={params.intent} light icon="plus">
            添加达人
          </Button>
          <Button intent={params.intent} light icon="userList">
            从名单添加
          </Button>
        </div>
      </CodeBox>
      <CodeBlock>{`import { Button } from "one-design-next";

<div>
  <Button intent="${params.intent}" light>different parent</Button>
</div>
<i className="mx-2 w-px h-4 bg-neutral-300" />
<Button intent="${params.intent}" light icon="plus">
  添加达人
</Button>
<Button intent="${params.intent}" light icon="userList">
  从名单添加
</Button>`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## 业务定制 {#business-customization}

`Button` 为 `size`、`intent`、`light` 提供了足够多的 变量用于业务定制。以下只演示部分自定义，变量确实搞得比较多：

**示例：自定义** — 自定义

```tsx
'use client';

import { Button } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

const Basics = () => {
  const [params, setParams] = useState({
    '--odn-button-large-padding-inline': 16,
    '--odn-button-large-height': 40,
    '--odn-button-large-font-size': 16,
    '--odn-button-large-icon-size': 20,
    '--odn-button-large-icon-gap': 4,
    '--odn-button-large-border-radius': 8,
    '--odn-button-primary-font-weight': 500,
    '--odn-button-primary-color': '#fff',
    '--odn-button-primary-bg': 'rgba(0, 0, 0, 0.96)',
    '--odn-button-primary-border-color': 'rgba(0, 0, 0, 0.96)',
    '--odn-button-primary-loading-icon-color': '#fff',
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, '--odn-button-large-padding-inline', {
      label: '内边距',
      min: 12,
      max: 20,
      step: 1,
    });

    pane.addBinding(params, '--odn-button-large-height', {
      label: '高度',
      min: 32,
      max: 44,
      step: 2,
    });

    pane.addBinding(params, '--odn-button-large-font-size', {
      label: '字号',
      min: 12,
      max: 18,
      step: 1,
    });

    pane.addBinding(params, '--odn-button-primary-font-weight', {
      label: '字重',
      min: 400,
      max: 600,
      step: 100,
    });

    pane.addBinding(params, '--odn-button-large-icon-size', {
      label: '图标大小',
      min: 16,
      max: 22,
      step: 2,
    });

    pane.addBinding(params, '--odn-button-large-icon-gap', {
      label: '图标间距',
      min: 2,
      max: 6,
      step: 2,
    });

    pane.addBinding(params, '--odn-button-large-border-radius', {
      label: '圆角',
      min: 4,
      max: 8,
      step: 2,
    });

    pane.addBinding(params, '--odn-button-primary-color', {
      label: '颜色',
      view: 'color',
      color: { alpha: true },
    });

    pane.addBinding(params, '--odn-button-primary-bg', {
      label: '背景色',
      view: 'color',
      color: { alpha: true },
    });

    pane.addBinding(params, '--odn-button-primary-border-color', {
      label: '边框色',
      view: 'color',
      color: { alpha: true },
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <Button
          intent="primary"
          size="large"
          key={JSON.stringify(params)}
          icon="plus"
          style={{
            '--odn-button-large-padding-inline': `${params['--odn-button-large-padding-inline']}px`,
            '--odn-button-large-height': `${params['--odn-button-large-height']}px`,
            '--odn-button-large-font-size': `${params['--odn-button-large-font-size']}px`,
            '--odn-button-large-icon-size': `${params['--odn-button-large-icon-size']}px`,
            '--odn-button-large-icon-gap': `${params['--odn-button-large-icon-gap']}px`,
            '--odn-button-large-border-radius': `${params['--odn-button-large-border-radius']}px`,
            '--odn-button-primary-font-weight':
              params['--odn-button-primary-font-weight'],
            '--odn-button-primary-color': params['--odn-button-primary-color'],
            '--odn-button-primary-bg': params['--odn-button-primary-bg'],
            '--odn-button-primary-border-color':
              params['--odn-button-primary-border-color'],
            '--odn-button-primary-loading-icon-color':
              params['--odn-button-primary-loading-icon-color'],
            '--odn-button-primary-bg-hover': params['--odn-button-primary-bg'],
            '--odn-button-primary-border-color-hover':
              params['--odn-button-primary-border-color'],
            '--odn-button-primary-bg-active': params['--odn-button-primary-bg'],
            '--odn-button-primary-border-color-active':
              params['--odn-button-primary-border-color'],
          }}
        >
          Create ad unit
        </Button>
      </CodeBox>
      <CodeBlock>{`import { Button } from 'one-design-next'

<Button
  style={{
    '--odn-button-large-padding-inline': '${params['--odn-button-large-padding-inline']}px',
    '--odn-button-large-height': '${params['--odn-button-large-height']}px',
    '--odn-button-large-font-size': '${params['--odn-button-large-font-size']}px',
    '--odn-button-large-icon-size': '${params['--odn-button-large-icon-size']}px',
    '--odn-button-large-icon-gap': '${params['--odn-button-large-icon-gap']}px',
    '--odn-button-large-border-radius': '${params['--odn-button-large-border-radius']}px',
    '--odn-button-primary-font-weight': ${params['--odn-button-primary-font-weight']},
    '--odn-button-primary-color': '${params['--odn-button-primary-color']}',
    '--odn-button-primary-bg': '${params['--odn-button-primary-bg']}',
    '--odn-button-primary-border-color': '${params['--odn-button-primary-border-color']}',
    '--odn-button-primary-loading-icon-color': '${params['--odn-button-primary-loading-icon-color']}',
    '--odn-button-primary-bg-hover': '${params['--odn-button-primary-bg']}',
    '--odn-button-primary-border-color-hover': '${params['--odn-button-primary-border-color']}',
    '--odn-button-primary-bg-active': '${params['--odn-button-primary-bg']}',
    '--odn-button-primary-border-color-active': '${params['--odn-button-primary-border-color']}',
  }}
/>

`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## API {#api}

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| asChild | 是否将子元素作为根节点渲染（Radix Slot） | `boolean` | `false` |
| size | 尺寸 | `'small' \| 'medium' \| 'large'` | `'medium'` |
| intent | 语义样式 | `'normal' \| 'danger' \| 'primary'` | `'normal'` |
| light | 是否使用轻量样式（HoverFill） | `boolean` | `false` |
| disabled | 是否禁用 | `boolean` | `false` |
| loading | 是否加载中 | `boolean` | `false` |
| icon | 左侧图标名称 | `IconProps['name']` | - |
| rightIcon | 右侧图标名称 | `IconProps['name']` | - |

此外继承 `React.ButtonHTMLAttributes<HTMLButtonElement>`（如 `onClick`、`type`、`className` 等）。

## 变量 {#variables}

<VariablesTable id="Button"></VariablesTable>

---

## 下拉菜单 Dropdown

## 基础用例 {#basic-usage}

通过 `trigger` 属性可以控制触发方式，支持 `click` 和 `hover` 两种方式；通过 `placement` 属性可以控制下拉菜单的弹出位置；通过 `matchWidth` 属性可以控制下拉菜单的宽度是否与触发元素的宽度一致，默认为 `false`：

**示例源码**（`components/dropdown/demo/basic.tsx`）

```tsx
'use client';

import { Dropdown, type DropdownProps } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
import { Pane } from 'tweakpane';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';

const Basic = () => {
  const [selectedValue, setSelectedValue] = useState<string>('');

  const [params, setParams] = useState({
    trigger: 'click' as 'click' | 'hover',
    placement: 'bottomLeft' as
      | 'top'
      | 'left'
      | 'right'
      | 'bottom'
      | 'topLeft'
      | 'topRight'
      | 'bottomLeft'
      | 'bottomRight'
      | 'leftTop'
      | 'leftBottom'
      | 'rightTop'
      | 'rightBottom',
    disabled: false,
    matchWidth: false,
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'trigger', {
      options: {
        click: 'click',
        hover: 'hover',
      },
    });

    pane.addBinding(params, 'placement', {
      options: {
        top: 'top',
        topLeft: 'topLeft',
        topRight: 'topRight',
        right: 'right',
        rightTop: 'rightTop',
        rightBottom: 'rightBottom',
        bottom: 'bottom',
        bottomLeft: 'bottomLeft',
        bottomRight: 'bottomRight',
        left: 'left',
        leftTop: 'leftTop',
        leftBottom: 'leftBottom',
      },
    });

    pane.addBinding(params, 'disabled');
    pane.addBinding(params, 'matchWidth');

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  const menuItems: DropdownProps['menu'] = [
    { value: 'option1', label: '选项一', icon: 'users' },
    {
      value: 'option2',
      label: '选项二',
      children: [
        { value: 'option2-1', label: '选项二-一' },
        { value: 'option2-2', label: '选项二-二' },
        { value: 'option2-3', label: '选项二-三' },
      ],
    },
    { value: 'option3', label: '选项三' },
  ];

  const handleSelect = (value: string) => {
    console.log('Selected:', value);
    setSelectedValue(value);
  };

  const dropdownProps: Partial<DropdownProps> = {
    menu: menuItems,
    onSelect: handleSelect,
    trigger: params.trigger,
    placement: params.placement,
    disabled: params.disabled,
    matchWidth: params.matchWidth,
    selectable: false,
  };

  return (
    <div>
      <CodeBox className="gap-2 flex-wrap pt-[100px]">
        <div
          ref={tweakpaneContainerRef}
          className="absolute top-2 right-2 opacity-90"
        />

        <div className="flex flex-col gap-4">
          <Dropdown {...dropdownProps}>
            <button className="button">
              {params.trigger === 'hover' ? '悬停展开' : '点击展开'}
            </button>
          </Dropdown>
        </div>
      </CodeBox>

      <CodeBlock>{`import { Dropdown } from 'one-design-next';

<Dropdown
  menu={[
    { value: 'option1', label: '选项一', icon: 'users' },
    {
      value: 'option2',
      label: '选项二',
      children: [
        { value: 'option2-1', label: '选项二-一' },
        { value: 'option2-2', label: '选项二-二' },
        { value: 'option2-3', label: '选项二-三' },
      ],
    },
    { value: 'option3', label: '选项三' },
  ]}
  onSelect={(value) => console.log('Selected:', value)}
  trigger="${params.trigger}"
  placement="${params.placement}"
  disabled={${params.disabled}}
>
  <button />
</Dropdown>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 复杂菜单 {#complex-menu}

支持丰富的菜单结构，包括标签、分组、分隔符、快捷键、子菜单和禁用项。在构建 menu 数组时，使用 `type` 属性来定义菜单项类型，支持 `item`（默认）、`label`、`separator`、`group` 四种类型。

利用 `Dropdown[menu]` 属性约束类型。

**示例源码**（`components/dropdown/demo/complex.tsx`）

```tsx
'use client';

import {
  Dropdown,
  type DropdownNormalProps,
  type DropdownProps,
} from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
import { Pane } from 'tweakpane';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';

const Complex = () => {
  const [selectedValue, setSelectedValue] = useState<string>('');

  const [params, setParams] = useState({
    trigger: 'click' as 'click' | 'hover',
    placement: 'bottomLeft' as
      | 'top'
      | 'left'
      | 'right'
      | 'bottom'
      | 'topLeft'
      | 'topRight'
      | 'bottomLeft'
      | 'bottomRight'
      | 'leftTop'
      | 'leftBottom'
      | 'rightTop'
      | 'rightBottom',
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'trigger', {
      options: {
        click: 'click',
        hover: 'hover',
      },
    });

    pane.addBinding(params, 'placement', {
      options: {
        top: 'top',
        topLeft: 'topLeft',
        topRight: 'topRight',
        right: 'right',
        rightTop: 'rightTop',
        rightBottom: 'rightBottom',
        bottom: 'bottom',
        bottomLeft: 'bottomLeft',
        bottomRight: 'bottomRight',
        left: 'left',
        leftTop: 'leftTop',
        leftBottom: 'leftBottom',
      },
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  // 复杂菜单结构
  const complexMenuItems: DropdownProps['menu'] = [
    { type: 'label', label: '我的账户' },
    {
      type: 'group',
      children: [
        { value: 'profile', label: '个人资料', shortcut: '⇧⌘P' },
        { value: 'billing', label: '账单管理', shortcut: '⌘B' },
        { value: 'settings', label: '系统设置', shortcut: '⌘S' },
        { value: 'shortcuts', label: '快捷键', shortcut: '⌘K' },
      ],
    },
    { type: 'separator' },
    {
      type: 'group',
      children: [
        { value: 'team', label: '团队管理', icon: 'users' },
        {
          value: 'invite',
          label: '邀请用户',
          children: [
            { value: 'email', label: '邮件邀请' },
            { value: 'message', label: '短信邀请' },
            { value: 'link', label: '链接邀请' },
            { type: 'separator' },
            { value: 'more', label: '更多方式...' },
          ],
        },
        { value: 'new-team', label: '创建团队', shortcut: '⌘+T' },
      ],
    },
    { type: 'separator' },
    {
      type: 'group',
      children: [
        { value: 'github', label: 'GitHub' },
        { value: 'support', label: '技术支持' },
        { value: 'api', label: 'API 文档', disabled: true },
        { value: 'feedback', label: '意见反馈' },
      ],
    },
    { type: 'separator' },
    { value: 'logout', label: '退出登录', shortcut: '⇧⌘Q' },
  ];

  const handleSelect = (value: string) => {
    console.log('Selected:', value);
    setSelectedValue(value);
  };

  const dropdownProps: Partial<DropdownNormalProps> = {
    menu: complexMenuItems,
    onSelect: handleSelect,
    trigger: params.trigger,
    placement: params.placement,
  };

  return (
    <div>
      <CodeBox className="gap-2 flex-wrap pt-[100px]">
        <div
          ref={tweakpaneContainerRef}
          className="absolute top-2 right-2 opacity-90"
        />

        <div className="flex flex-col gap-4">
          <Dropdown {...dropdownProps}>
            <button className="button">
              {params.trigger === 'hover'
                ? '悬停展开复杂菜单'
                : '点击展开复杂菜单'}
            </button>
          </Dropdown>
        </div>
      </CodeBox>

      <CodeBlock>{`import { Dropdown, type DropdownProps } from 'one-design-next';

const complexMenuItems: DropdownProps['menu'] = [
  { type: 'label', label: '我的账户' },
  {
    type: 'group',
    children: [
      { value: 'profile', label: '个人资料', shortcut: '⇧⌘P' },
      { value: 'billing', label: '账单管理', shortcut: '⌘B' },
      { value: 'settings', label: '系统设置', shortcut: '⌘S' },
      { value: 'shortcuts', label: '快捷键', shortcut: '⌘K' },
    ],
  },
  { type: 'separator' },
  {
    type: 'group',
    children: [
      { value: 'team', label: '团队管理', icon: 'users' },
      {
        value: 'invite',
        label: '邀请用户',
        children: [
          { value: 'email', label: '邮件邀请' },
          { value: 'message', label: '短信邀请' },
          { value: 'link', label: '链接邀请' },
          { type: 'separator' },
          { value: 'more', label: '更多方式...' },
        ],
      },
      { value: 'new-team', label: '创建团队', shortcut: '⌘+T' },
    ],
  },
  { type: 'separator' },
  {
    type: 'group',
    children: [
      { value: 'github', label: 'GitHub' },
      { value: 'support', label: '技术支持' },
      { value: 'api', label: 'API 文档', disabled: true },
      { value: 'feedback', label: '意见反馈' },
    ],
  },
  { type: 'separator' },
  { value: 'logout', label: '退出登录', shortcut: '⇧⌘Q' },
];

<Dropdown
  menu={complexMenuItems}
  onSelect={(value) => console.log('Selected:', value)}
  trigger="${params.trigger}"
  placement="${params.placement}"
>
  <button className="button">
    点击展开复杂菜单
  </button>
</Dropdown>`}</CodeBlock>
    </div>
  );
};

export default Complex;
```
## 单选功能 {#single-selection}

通过 `selectable` 开启选择功能，设置 `multiple={false}` 实现单选模式。此时 `value` 类型为 `string`，`onSelect` 回调参数类型为 `string`：

**示例源码**（`components/dropdown/demo/radio.tsx`）

```tsx
'use client';

import { Dropdown, type DropdownProps } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';

const Radio = () => {
  const [radioValue, setRadioValue] = useState<string>('option1');

  // 单选菜单项
  const radioMenuItems: DropdownProps['menu'] = [
    { type: 'label', label: '基础选项' },
    {
      type: 'group',
      children: [
        { value: 'option1', label: '选项一' },
        { value: 'option2', label: '选项二' },
        { value: 'option3', label: '选项三' },
      ],
    },
    { type: 'separator' },
    { type: 'label', label: '高级选项' },
    {
      type: 'group',
      children: [
        { value: 'advanced1', label: '高级选项A' },
        { value: 'advanced2', label: '高级选项B' },
      ],
    },
    { type: 'separator' },
    { type: 'label', label: '特殊选项' },
    {
      type: 'group',
      children: [
        { value: 'special1', label: '特殊选项X' },
        {
          value: 'submenu1',
          label: '子菜单选项',
          children: [
            { value: 'sub1', label: '子选项一' },
            { value: 'sub2', label: '子选项二' },
            {
              value: 'submenu2',
              label: '深层选项',
              children: [
                { value: 'deep1', label: '深层选项A' },
                { value: 'deep2', label: '深层选项B' },
                { value: 'deep3', label: '深层选项C' },
              ],
            },
            { value: 'sub3', label: '子选项三' },
          ],
        },
        { value: 'special3', label: '特殊选项Z' },
      ],
    },
  ];

  const handleRadioSelect = (value: string) => {
    console.log('Radio selected:', value);
    setRadioValue(value);
  };

  return (
    <div>
      <CodeBox className="gap-2 flex-wrap">
        <div className="flex flex-col gap-4">
          <Dropdown
            selectable
            multiple={false}
            value={radioValue}
            menu={radioMenuItems}
            onSelect={handleRadioSelect}
          >
            <button className="button">单选菜单</button>
          </Dropdown>
        </div>
      </CodeBox>

      <CodeBlock>
        {`import { Dropdown } from 'one-design-next';

// 单选值：${radioValue}
<Dropdown
  selectable
  multiple={false}
  value={selectedValue}
  menu={[
    { value: 'option1', label: '选项一' },
    { value: 'option2', label: '选项二' },
    { value: 'option3', label: '选项三' },
    { value: 'option4', label: '选项四' },
  ]}
  onSelect={handleRadioSelect}
>
  <button />
</Dropdown>`}
      </CodeBlock>
    </div>
  );
};

export default Radio;
```
## 多选功能 {#multiple-selection}

通过 `selectable` 开启选择功能，设置 `multiple` 实现多选模式。此时 `value` 类型为 `string[]`，`onSelect` 回调参数类型为 `string[]`。

通过 `allowSelectAll` 开启全选功能，开启后在菜单中的各级自动添加全选按钮：

**示例源码**（`components/dropdown/demo/checkbox.tsx`）

```tsx
'use client';

import { Dropdown, type DropdownProps } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
import { Pane } from 'tweakpane';

const Checkbox = () => {
  const [checkboxValues, setCheckboxValues] = useState<string[]>(['feature1']);
  const [allowSelectAll, setAllowSelectAll] = useState(true);
  const paneRef = useRef<HTMLDivElement>(null);

  // 多选菜单项
  const checkboxMenuItems: DropdownProps['menu'] = [
    { type: 'label', label: '基础功能' },
    {
      type: 'group',
      children: [
        { value: 'feature1', label: '功能一' },
        { value: 'feature2', label: '功能二' },
      ],
    },
    { type: 'separator' },
    { type: 'label', label: '实验性功能' },
    {
      type: 'group',
      children: [
        { value: 'beta1', label: '测试功能X' },
        {
          value: 'submenu1',
          label: '更多功能',
          children: [
            { value: 'sub1', label: '子功能A' },
            {
              value: 'submenu2',
              label: '深层功能',
              children: [
                { value: 'deep1', label: '深层功能X' },
                { value: 'deep2', label: '深层功能Y' },
                { value: 'deep3', label: '深层功能Z' },
              ],
            },
            { value: 'sub3', label: '子功能B' },
          ],
        },
        { value: 'beta2', label: '测试功能Y' },
      ],
    },
  ];

  const handleCheckboxSelect = (values: string[]) => {
    console.log('Checkbox selected:', values);
    setCheckboxValues(values);
  };

  useEffect(() => {
    if (!paneRef.current) return;

    const pane = new Pane({ container: paneRef.current });

    const params = {
      allowSelectAll,
    };

    pane
      .addBinding(params, 'allowSelectAll', {
        label: '支持全选',
      })
      .on('change', (ev) => {
        setAllowSelectAll(ev.value);
      });

    return () => {
      pane.dispose();
    };
  }, [allowSelectAll]);

  return (
    <div>
      <CodeBox className="gap-2 flex-wrap pt-[60px]">
        <div ref={paneRef} className="absolute top-2 right-2 opacity-90" />

        <div className="flex flex-col gap-4">
          <Dropdown
            selectable
            multiple={true}
            value={checkboxValues}
            menu={checkboxMenuItems}
            onSelect={handleCheckboxSelect}
            allowSelectAll={allowSelectAll}
          >
            <button className="button">多选菜单</button>
          </Dropdown>
        </div>
      </CodeBox>

      <CodeBlock>
        {`import { Dropdown } from 'one-design-next';

// 多选值：${checkboxValues.join(', ')}
<Dropdown
  selectable
  multiple={true}
  value={selectedValues}
  allowSelectAll={${allowSelectAll ? 'true' : 'false'}}
  menu={[]}
  onSelect={handleCheckboxSelect}
>
  <button />
</Dropdown>`}
      </CodeBlock>
    </div>
  );
};

export default Checkbox;
```
## API {#api}

`DropdownProps` 为联合类型：可选菜单选择（单选 `selectable: true, multiple?: false`；多选 `multiple: true`）或普通菜单（`selectable: false`）。

### 共有（BaseDropdownProps）

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| menu | 菜单数据 | `DropdownMenuItemData[]` | - |
| children | 触发器 | `React.ReactNode` | - |
| placement | 弹出方位 | 同 Popover | - |
| visible / onVisibleChange | 显隐 | `boolean` / `(v) => void` | - |
| trigger | 触发方式 | `'click' \| 'hover' \| 'contextMenu'` | - |
| disabled | 是否禁用 | `boolean` | - |
| allowSelectAll | 多选时是否注入「全选」 | `boolean` | - |
| matchWidth | 与触发器同宽 | `boolean` | - |
| popupClassName | 下拉弹层额外类名（作用于 content popup） | `string` | - |
| zIndex | 层级 | `number \| string` | - |

### 可选：单选（DropdownRadioProps）

| 属性 | 说明 | 类型 |
| --- | --- | --- |
| selectable | 必须为 `true` | `true` |
| multiple | `false` 或未设 | `false` |
| value | 当前选中值 | `string` |
| onSelect | 选择 | `(value: string) => void` |

### 可选：多选（DropdownCheckboxProps）

| 属性 | 说明 | 类型 |
| --- | --- | --- |
| selectable / multiple | 多选 | `true` / `true` |
| value | 选中列表 | `string[]` |
| onSelect | 选择 | `(values: string[]) => void` |

### 普通（DropdownNormalProps）

| 属性 | 说明 | 类型 |
| --- | --- | --- |
| selectable | `false` 或不选 | `false` |
| onSelect | 点击项 | `(value: string) => void` |

## 变量 {#variables}

<VariablesTable id="Dropdown"></VariablesTable>

---

## 悬浮按钮 Fab

## 基础用例 {#basic-usage}

**示例：基础用例** — 默认的 Floating Action Button，点击触发操作。

```tsx
import React from 'react'
import { Fab } from 'one-design-next'

export default function BasicDemo() {
  return (
    <div className="flex items-center justify-center gap-6 py-8" style={{ background: 'linear-gradient(135deg, #f0f4f8, #e8edf2)' }}>
      <Fab
        label="如翼 AI 营销官"
        onClick={() => alert('Fab clicked!')}
      />
    </div>
  )
}
```
## 光晕调试 {#glow-tuner}

**示例：光晕调试** — 通过滑块实时调整底部发光椭圆的尺寸、位置、亮度与模糊强度。

```tsx
'use client';

import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';
import { Fab } from 'one-design-next';

type TunerParams = {
  idleWidth: number;
  idleHeight: number;
  idleBottom: number;
  idleAlpha: number;
  idleBlur: number;
  idleSpeed: number;
  hoverWidth: number;
  hoverHeight: number;
  hoverBottom: number;
  hoverAlpha: number;
  hoverBlur: number;
  hoverSpeed: number;
  previewHover: boolean;
};

const initialParams: TunerParams = {
  idleWidth: 300,
  idleHeight: 33,
  idleBottom: -28,
  idleAlpha: 0.68,
  idleBlur: 28,
  idleSpeed: 1.49,
  hoverWidth: 313,
  hoverHeight: 65,
  hoverBottom: -28,
  hoverAlpha: 1,
  hoverBlur: 59,
  hoverSpeed: 4.52,
  previewHover: false,
};

const formatSnippet = (p: TunerParams) =>
  `/* SCSS – components/fab/style/index.scss */
.odn-fab-glow {
  bottom: var(--fab-glow-bottom, ${p.idleBottom}px);
  width: var(--fab-glow-width, ${p.idleWidth}px);
  height: var(--fab-glow-height, ${p.idleHeight}px);
  background: rgba(255, 255, 255, var(--fab-glow-alpha, ${p.idleAlpha}));
  background: color(display-p3 1 1 1 / var(--fab-glow-alpha, ${p.idleAlpha}));
  filter: blur(var(--fab-glow-blur, ${p.idleBlur}px));
}

[data-odn-fab]:hover .odn-fab-glow {
  bottom: var(--fab-glow-hover-bottom, ${p.hoverBottom}px);
  width: var(--fab-glow-hover-width, ${p.hoverWidth}px);
  height: var(--fab-glow-hover-height, ${p.hoverHeight}px);
  background: rgba(255, 255, 255, var(--fab-glow-hover-alpha, ${p.hoverAlpha}));
  background: color(display-p3 1 1 1 / var(--fab-glow-hover-alpha, ${p.hoverAlpha}));
  filter: blur(var(--fab-glow-hover-blur, ${p.hoverBlur}px));
}

/* TSX – components/fab/index.tsx props 默认值 */
speed = ${p.idleSpeed},
hoverSpeed = ${p.hoverSpeed},`;

const Demo = () => {
  const [params, setParams] = useState<TunerParams>(initialParams);
  const paramsRef = useRef<TunerParams>(initialParams);
  const paneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    paramsRef.current = params;
  }, [params]);

  useEffect(() => {
    const pane = new Pane({ container: paneContainerRef.current as HTMLElement });

    const f1 = pane.addFolder({ title: '默认状态', expanded: true });
    f1.addBinding(params, 'idleWidth', { label: '宽度 (px)', min: 40, max: 400, step: 1 });
    f1.addBinding(params, 'idleHeight', { label: '高度 (px)', min: 4, max: 120, step: 1 });
    f1.addBinding(params, 'idleBottom', { label: '底部偏移 (px)', min: -80, max: 40, step: 1 });
    f1.addBinding(params, 'idleAlpha', { label: '亮度 (alpha)', min: 0, max: 1, step: 0.01 });
    f1.addBinding(params, 'idleBlur', { label: '模糊 (px)', min: 0, max: 80, step: 1 });
    f1.addBinding(params, 'idleSpeed', { label: '流动速率', min: 0, max: 10, step: 0.01 });

    const f2 = pane.addFolder({ title: 'Hover 状态', expanded: true });
    f2.addBinding(params, 'hoverWidth', { label: '宽度 (px)', min: 40, max: 400, step: 1 });
    f2.addBinding(params, 'hoverHeight', { label: '高度 (px)', min: 4, max: 120, step: 1 });
    f2.addBinding(params, 'hoverBottom', { label: '底部偏移 (px)', min: -80, max: 40, step: 1 });
    f2.addBinding(params, 'hoverAlpha', { label: '亮度 (alpha)', min: 0, max: 1, step: 0.01 });
    f2.addBinding(params, 'hoverBlur', { label: '模糊 (px)', min: 0, max: 80, step: 1 });
    f2.addBinding(params, 'hoverSpeed', { label: '流动速率', min: 0, max: 10, step: 0.01 });

    const f3 = pane.addFolder({ title: '预览', expanded: true });
    f3.addBinding(params, 'previewHover', { label: '预览 Hover 状态' });

    const f4 = pane.addFolder({ title: '导出', expanded: true });
    f4.addButton({ title: '复制为默认值（含 SCSS + props）' }).on('click', () => {
      const snippet = formatSnippet(paramsRef.current);
      const done = () => {
        // eslint-disable-next-line no-console
        console.log('[Fab Glow Tuner] 当前参数：\n' + snippet);
        // eslint-disable-next-line no-alert
        window.alert('已复制当前参数到剪贴板，可直接粘贴给我或贴到代码中。');
      };
      if (navigator.clipboard?.writeText) {
        navigator.clipboard.writeText(snippet).then(done, done);
      } else {
        done();
      }
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => pane.dispose();
  }, []);

  const idleStyle = {
    '--fab-glow-width': `${params.idleWidth}px`,
    '--fab-glow-height': `${params.idleHeight}px`,
    '--fab-glow-bottom': `${params.idleBottom}px`,
    '--fab-glow-alpha': params.idleAlpha,
    '--fab-glow-blur': `${params.idleBlur}px`,
    '--fab-glow-hover-width': `${params.hoverWidth}px`,
    '--fab-glow-hover-height': `${params.hoverHeight}px`,
    '--fab-glow-hover-bottom': `${params.hoverBottom}px`,
    '--fab-glow-hover-alpha': params.hoverAlpha,
    '--fab-glow-hover-blur': `${params.hoverBlur}px`,
  } as React.CSSProperties;

  const previewStyle = params.previewHover
    ? ({
        '--fab-glow-width': `${params.hoverWidth}px`,
        '--fab-glow-height': `${params.hoverHeight}px`,
        '--fab-glow-bottom': `${params.hoverBottom}px`,
        '--fab-glow-alpha': params.hoverAlpha,
        '--fab-glow-blur': `${params.hoverBlur}px`,
      } as React.CSSProperties)
    : {};

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={paneContainerRef} className="opacity-90 self-end" />
        <div
          className="flex items-center justify-center"
          style={{ minHeight: 240 }}
        >
          <div style={{ ...idleStyle, ...previewStyle }}>
            <Fab
              onClick={() => {}}
              speed={params.idleSpeed}
              hoverSpeed={params.hoverSpeed}
            />
          </div>
        </div>
      </CodeBox>
    </div>
  );
};

export default Demo;
```
## API {#api}

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| label | 按钮文案 | `string` | `'如翼 AI 营销官'` |
| icon | 自定义图标，替换默认品牌图形 | `React.ReactNode` | 品牌图形 |
| onClick | 点击回调 | `() => void` | - |
| colors | 默认背景渐变色（三色） | `[string, string, string]` | `['#99E1FF', '#19BCFF', '#99E1FF']` |
| hoverColors | hover 时背景渐变色 | `[string, string, string]` | `['#93F2EF', '#1ABCFF', '#1ABCFF']` |
| bgOpacity | 背景透明度 | `number` | `0.8` |
| speed | 默认状态 shader 流动速率 | `number` | `1.49` |
| hoverSpeed | hover 时 shader 流动速率 | `number` | `4.52` |
| className | 自定义类名 | `string` | - |
| style | 自定义样式 | `React.CSSProperties` | - |

---

## 悬浮填充 HoverFill

细节上，会根据鼠标移入的方位加一点点缩放和中心偏移；以及相邻的元素会共享背景色。

`HoverFill` 是这些组件中我最喜欢的一个。它这么简单，却能扩展到许多组件，最终适用于许多场景。

## 作为轻量按钮 {#as-light-button}

最简单地，`HoverFill` 可以成为一个轻量按钮，你需要比较仔细才能看到缩放的中心偏移，这是有意弱化的：

**示例：button** — button

```tsx
'use client';

import { HoverFill } from 'one-design-next';
import React from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basics = () => {
  return (
    <div>
      <CodeBox>
        <HoverFill bgClassName="rounded-md">
          <button className="inline-flex items-center justify-center gap-0.5 h-9 px-3 text-sm">
            light-button
          </button>
        </HoverFill>
      </CodeBox>
      <CodeBlock>{`import { HoverFill } from 'one-design-next';

<Button light>
  light-button
</Button>

// 或者自己实现：
<HoverFill bgClassName="rounded-md">
  <button className="inline-flex items-center justify-center gap-0.5 h-9 px-3 text-sm">
    light-button
  </button>
</HoverFill>`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## 作为轻量输入框 {#as-light-input}

接着，`HoverFill` 当然可以成为一个轻量的其他表单元素：

**示例：input** — input

```tsx
'use client';

import { DateRangePicker } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
const Basic = () => {
  const today = new Date();
  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);
  const [value, setValue] = useState<[Date, Date] | undefined>([
    today,
    tomorrow,
  ]);

  return (
    <div>
      <CodeBox>
        <DateRangePicker
          light
          value={value}
          onChange={setValue}
          visible={false}
        />
      </CodeBox>
      <CodeBlock>{`import { DateRangePicker } from 'one-design-next';

<DateRangePicker light value={[today, tomorrow]} visible={false} />`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 作为轻量卡片 {#as-light-card}

除了表单，`HoverFill` 也可以成为一个轻量的卡片。在尺寸比较大的卡片上，缩放的起始值如果和按钮或输入框相同，那么就会更加明显。因此，`HoverFill` 内部会根据元素的尺寸自动计算缩放的起始值。

具体的方法是 `1 - 8 / 对角线长度`，对角线长度越长，缩放的起始值越大。下面的卡片初始值为 `0.978`：

**示例：card** — card

```tsx
'use client';

import { HoverFill } from 'one-design-next';
import React from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basics = () => {
  return (
    <div>
      <CodeBox className="gap-2 flex-wrap">
        <HoverFill bgClassName="rounded-lg">
          <div className="flex p-4 gap-3 w-[356px]">
            <img
              src="https://images.unsplash.com/photo-1744219792921-a74da6141822?q=80&w=2304&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
              className="size-[72px] object-cover rounded-full"
            />
            <div>
              <div className="mb-1 text-base font-semibold">隔壁大哥与小李</div>
              <div className="mb-1 text-xs text-neutral-500">北京</div>
              <div className="flex items-center gap-1 text-xs font-semibold text-[#FA9D3B]">
                <svg
                  width="12"
                  height="12"
                  viewBox="0 0 12 12"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    fillRule="evenodd"
                    clipRule="evenodd"
                    d="M1.95034 1.6875C2.47375 1.6875 2.93177 1.9773 3.30156 2.31113C3.68246 2.65497 4.05247 3.12099 4.40616 3.62976C4.94342 4.40259 5.49468 5.35282 6.02088 6.24805C6.55153 5.35495 7.10207 4.39995 7.62032 3.63526C7.96376 3.12852 8.31933 2.6638 8.68088 2.32066C9.02705 1.99212 9.46918 1.6875 9.98252 1.6875C10.9111 1.6875 11.1946 2.68232 11.24 3.43697C11.2884 4.24369 11.1562 5.27788 10.9361 6.27727C10.7147 7.28194 10.3941 8.2981 10.0395 9.07526C9.76384 9.67959 9.30679 10.625 8.52212 10.625C7.8495 10.625 7.30604 10.1036 6.89829 9.62485C6.60368 9.27893 6.30614 8.85579 6.01029 8.39727C5.70145 8.86029 5.38719 9.28774 5.07168 9.63712C4.6167 10.1409 4.03533 10.625 3.35858 10.625C2.5668 10.625 2.14842 9.66957 1.88823 9.06378C1.5549 8.28767 1.25496 7.27294 1.04745 6.27025C0.840836 5.27192 0.716824 4.24245 0.757797 3.44195C0.795031 2.71449 1.03384 1.6875 1.95034 1.6875ZM5.35736 7.33682C4.72087 6.26852 4.1007 5.16126 3.48244 4.27192C3.14695 3.78933 2.83433 3.40494 2.54772 3.1462C2.29911 2.92177 2.12256 2.83947 2.00977 2.81842C2.00814 2.82168 2.00641 2.8252 2.00459 2.82899C1.94996 2.94287 1.89869 3.16023 1.88133 3.49946C1.84732 4.1638 1.9515 5.08745 2.1491 6.04225C2.3458 6.99269 2.62612 7.93109 2.92193 8.61981C3.04598 8.90864 3.19348 9.26676 3.42645 9.49247C3.58999 9.45859 3.85745 9.30314 4.23674 8.88313C4.59212 8.4896 4.96652 7.95396 5.35736 7.33682ZM6.67611 7.34342C7.05778 7.96243 7.41793 8.49992 7.75476 8.89541C7.93874 9.11143 8.18034 9.4122 8.47042 9.49175C8.72587 9.26979 8.87955 8.90745 9.01601 8.60833C9.32973 7.92065 9.62845 6.98368 9.83741 6.03523C10.0475 5.0815 10.1565 4.16257 10.117 3.50444C10.104 3.28843 10.0933 2.99927 9.96195 2.8138C9.88317 2.82315 9.71847 2.88692 9.45533 3.13667C9.18196 3.39611 8.88003 3.78181 8.55159 4.26642C7.94142 5.16673 7.32933 6.26704 6.67611 7.34342Z"
                    fill="#FA9D3B"
                  />
                </svg>
                视频号特色
              </div>
            </div>
          </div>
        </HoverFill>
      </CodeBox>
      <CodeBlock>{`import { HoverFill } from 'one-design-next';

<HoverFill bgClassName="rounded-lg">
  <div className="flex p-4 gap-3 w-[356px]"></div>
</HoverFill>`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## 共享背景 {#shared-background}

`HoverFill` 最重要的特性：从一个 hover 到相邻的另一个时，它们会 **自动地** 共享同一个背景。

"相邻"不仅是指视觉上，在 DOM 上的判断为是否在同一个父元素下。因此你需要确保 `HoverFill` 不会被 `overflow: hidden` 的元素包裹。这种"自动"确实存在风险，但是刻意这样设计的。

我不想增加 `HoverFill.Group` 这样的设计，这会增加心智成本。如果场景特殊，可以考虑不使用，而是自己实现一个。

组件存在的意义不是为了约束开发者的实践，它只是设计语言的一种落地，而不是唯一的落地。不要本末倒置。

### 作为多个轻量按钮 {#as-multiple-light-buttons}

**示例：buttons** — buttons

```tsx
'use client';

import { HoverFill } from 'one-design-next';
import React from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basics = () => {
  return (
    <div>
      <CodeBox className="flex-wrap">
        <div>
          <HoverFill bgClassName="rounded-md">
            <div className="inline-flex items-center justify-center gap-0.5 h-9 px-3 text-sm">
              different parent
            </div>
          </HoverFill>
        </div>
        <i className="mx-2 w-px h-4 bg-neutral-300" />
        <HoverFill bgClassName="rounded-md">
          <div className="inline-flex items-center justify-center gap-0.5 h-9 px-3 text-sm">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <path
                d="M8.65 3C8.65 2.72386 8.42614 2.5 8.15 2.5H7.85C7.57386 2.5 7.35 2.72386 7.35 3V7.35H3C2.72386 7.35 2.5 7.57386 2.5 7.85V8.15C2.5 8.42614 2.72386 8.65 3 8.65H7.35V13C7.35 13.2761 7.57386 13.5 7.85 13.5H8.15C8.42614 13.5 8.65 13.2761 8.65 13V8.65H13C13.2761 8.65 13.5 8.42614 13.5 8.15V7.85C13.5 7.57386 13.2761 7.35 13 7.35H8.65V3Z"
                fill="#464749"
              />
            </svg>
            添加达人
          </div>
        </HoverFill>
        <HoverFill bgClassName="rounded-md">
          <div className="inline-flex items-center justify-center gap-0.5 h-9 px-3 text-sm">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <mask id="path-1-inside-1_1118_48610" fill="white">
                <rect x="2" y="2" width="11" height="12" rx="0.8" />
              </mask>
              <rect
                x="2"
                y="2"
                width="11"
                height="12"
                rx="0.8"
                stroke="black"
                strokeWidth="2"
                mask="url(#path-1-inside-1_1118_48610)"
              />
              <rect x="8" y="8" width="7" height="7" fill="#F7F7F7" />
              <path d="M4 5H11" stroke="black" />
              <path d="M4 7.5H11" stroke="black" />
              <path d="M4 10H8" stroke="black" />
              <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M11.5 12.5V15H12.5V12.5H15V11.5H12.5V9H11.5V11.5H9V12.5H11.5Z"
                fill="black"
              />
            </svg>
            从名单添加
          </div>
        </HoverFill>
      </CodeBox>
    </div>
  );
};

export default Basics;
```
### 作为多个轻量卡片 {#as-multiple-light-cards}

**示例：cards** — cards

```tsx
'use client';

import { HoverFill } from 'one-design-next';
import React from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basics = () => {
  return (
    <div>
      <CodeBox className="my-2 p-0">
        <div className="w-full">
          <svg className="block w-full" viewBox="0 0 793 68" fill="none">
            <mask id="path-1-inside-1_1021_77874" fill="white">
              <path d="M0 0H793V68H0V0Z" />
            </mask>
            <path
              d="M793 67H0V69H793V67Z"
              fill="#4A618F"
              fillOpacity="0.08"
              mask="url(#path-1-inside-1_1021_77874)"
            />
            <path
              d="M26.412 25.366C27.618 26.302 28.644 27.22 29.49 28.156L28.122 29.524C27.42 28.624 26.43 27.634 25.134 26.59L26.412 25.366ZM37.158 41.584C36.132 41.584 35.016 41.566 33.81 41.548C32.586 41.53 31.578 41.422 30.804 41.242C30.03 41.026 29.382 40.612 28.842 40C28.59 39.694 28.338 39.55 28.122 39.55C27.762 39.55 27.132 40.378 26.214 42.034L24.828 40.756C25.728 39.28 26.556 38.344 27.276 37.948V33.052H24.864V31.216H29.058V38.092C29.13 38.164 29.202 38.218 29.274 38.29C29.706 38.758 30.156 39.118 30.588 39.352C31.146 39.604 31.974 39.766 33.09 39.802C34.17 39.82 35.448 39.838 36.906 39.838C37.734 39.838 38.58 39.82 39.444 39.802C40.308 39.766 40.974 39.73 41.424 39.694L40.974 41.584H37.158ZM30.354 29.02H34.134C34.206 28.192 34.26 27.346 34.278 26.482V25.222H36.15V26.068C36.15 27.112 36.096 28.084 35.988 29.02H40.254V30.856H35.718C35.646 31.234 35.556 31.594 35.466 31.954C36.996 33.25 38.778 35.068 40.83 37.408L39.462 38.758C38.094 37.012 36.582 35.32 34.908 33.7C34.044 35.896 32.73 37.588 30.966 38.776L29.814 37.228C31.866 35.914 33.198 33.79 33.846 30.856H30.354V29.02ZM51.882 25.24C51.882 26.824 51.828 28.174 51.756 29.29C52.8 34.024 55.374 37.642 59.46 40.144L58.2 41.8C54.834 39.532 52.458 36.508 51.072 32.71C49.884 36.382 47.418 39.424 43.674 41.836L42.522 40.144C47.346 37.264 49.812 33.232 49.956 28.066C49.956 26.86 49.974 25.924 49.974 25.24H51.882ZM69.576 33.574V35.374H72.204V33.574H69.576ZM69.576 37.12V39.172H72.204V37.12H69.576ZM69.576 40.972V41.782H67.722V32.008C67.362 32.476 67.002 32.944 66.642 33.394L66.354 32.494V34.366C65.868 34.582 65.382 34.798 64.896 34.996V39.766C64.896 40.99 64.248 41.62 62.988 41.62H61.368L60.954 39.802C61.44 39.874 61.908 39.928 62.34 39.928C62.772 39.928 63.006 39.712 63.006 39.28V35.698C62.358 35.914 61.692 36.13 61.026 36.31L60.558 34.402C61.386 34.24 62.196 34.042 63.006 33.79V30.154H60.9V28.336H63.006V25.222H64.896V28.336H66.498V30.154H64.896V33.106C65.4 32.89 65.868 32.674 66.336 32.44L66.012 31.432C67.416 29.56 68.388 27.49 68.964 25.24L70.8 25.6C70.548 26.464 70.26 27.292 69.918 28.102H72.438C72.168 27.274 71.862 26.446 71.502 25.654L73.32 25.168C73.698 26.23 74.004 27.202 74.22 28.102H76.902V29.902H74.058V31.81H76.542V33.574H74.058V35.374H76.542V37.12H74.058V39.172H77.1V40.972H69.576ZM72.204 29.902H69.576V31.81H72.204V29.902ZM79.098 26.302H83.004V25.222H84.912V26.302H89.088V25.222H90.996V26.302H94.902V28.012H90.996V29.128H89.088V28.012H84.912V28.912L86.73 29.254C86.622 29.542 86.514 29.83 86.406 30.1H94.812V31.81H85.56C85.02 32.71 84.408 33.574 83.688 34.366V41.908H81.87V36.13C81.24 36.652 80.574 37.156 79.89 37.624L78.72 36.076C80.664 34.816 82.212 33.394 83.364 31.81H79.404V30.1H84.39C84.552 29.758 84.696 29.434 84.84 29.11H83.004V28.012H79.098V26.302ZM89.304 35.518C89.7 35.248 90.276 34.888 91.032 34.438H85.848V32.746H93.75V34.078C93.012 34.636 92.166 35.266 91.194 35.986V36.274H94.884V38.038H91.194V40.198C91.194 41.314 90.636 41.872 89.538 41.872H87.324L86.784 40.054C87.63 40.126 88.296 40.18 88.8 40.18C89.124 40.18 89.304 40 89.304 39.676V38.038H84.606V36.274H89.304V35.518Z"
              fill="#313233"
            />
            <path
              fillRule="evenodd"
              clipRule="evenodd"
              d="M707.156 35.1109C707.637 36.7795 709.176 37.9998 711 37.9998C711.917 37.9998 712.761 37.6914 713.436 37.1725L714.385 38.1214C713.464 38.8786 712.285 39.3332 711 39.3332C708.435 39.3332 706.293 37.5232 705.782 35.1109H704.562C704.308 35.1109 704.241 34.9575 704.401 34.7682L706.265 32.5648C706.424 32.3774 706.685 32.3755 706.845 32.5648L708.71 34.7682C708.868 34.9556 708.798 35.1109 708.548 35.1109H707.156ZM716.259 33.1109H717.437C717.687 33.1109 717.757 33.2663 717.599 33.4537L715.734 35.6571C715.574 35.8464 715.313 35.8445 715.154 35.6571L713.29 33.4537C713.129 33.2644 713.197 33.1109 713.451 33.1109H714.901C714.496 31.3296 712.903 29.9998 711 29.9998C709.856 29.9998 708.825 30.4796 708.096 31.2487L707.153 30.3056C708.123 29.2953 709.488 28.6665 711 28.6665C713.642 28.6665 715.836 30.5885 716.259 33.1109Z"
              fill="#33373D"
              fillOpacity="0.58"
            />
            <path
              d="M735.558 31.426V35.234H736.44V36.158H732.912C733.654 37.586 734.858 38.692 736.51 39.504L736.048 40.456C734.2 39.42 732.87 38.048 732.086 36.368C731.498 37.992 730.168 39.35 728.096 40.442L727.438 39.602C729.342 38.706 730.574 37.558 731.134 36.158H727.872V35.234H728.866V31.426H732.058C732.464 30.866 732.87 30.222 733.262 29.48H730.826C730.238 30.292 729.468 31.02 728.544 31.65L727.956 30.866C729.356 29.942 730.308 28.808 730.812 27.478L731.792 27.604C731.666 27.954 731.526 28.29 731.358 28.612H734.326V29.34C733.92 30.152 733.5 30.852 733.08 31.426H735.558ZM729.762 35.234H731.414C731.582 34.422 731.68 33.442 731.708 32.308H729.762V35.234ZM732.38 35.234H734.662V32.308H732.632C732.604 33.47 732.52 34.45 732.38 35.234ZM725.198 40.246H724.008L723.798 39.28C724.162 39.322 724.512 39.35 724.848 39.35C725.212 39.35 725.408 39.14 725.408 38.748V35.374C724.848 35.598 724.288 35.794 723.728 35.976L723.476 34.968C724.134 34.8 724.778 34.604 725.408 34.366V31.104H723.742V30.138H725.408V27.576H726.416V30.138H727.844V31.104H726.416V33.96C726.92 33.736 727.41 33.484 727.9 33.204V34.226C727.41 34.478 726.92 34.73 726.416 34.954V39C726.416 39.826 726.01 40.246 725.198 40.246ZM737.7 33.358H750.286V34.366H737.7V33.358ZM755.76 33.68V34.632C755.312 34.828 754.85 35.01 754.402 35.178V39.098C754.402 39.91 754.024 40.316 753.268 40.316H752.05L751.84 39.322C752.204 39.364 752.568 39.392 752.918 39.392C753.254 39.392 753.422 39.21 753.422 38.846V35.514C752.918 35.668 752.414 35.808 751.91 35.948L751.672 34.982C752.26 34.856 752.848 34.716 753.422 34.548V31.118H751.84V30.152H753.422V27.562H754.402V30.152H755.788V31.118H754.402V34.226C754.864 34.058 755.312 33.876 755.76 33.68ZM757.44 32.714V38.958C758.112 38.776 758.714 38.552 759.274 38.286L759.456 39.224C758.518 39.616 757.44 39.952 756.236 40.232L755.984 39.294C756.292 39.196 756.446 38.986 756.446 38.678V27.702H757.44V31.734H759.414V32.714H757.44ZM762.48 40.204H761.304C760.492 40.204 760.086 39.756 760.086 38.888V27.604H761.08V31.832C761.92 31.552 762.746 31.16 763.53 30.656L764.118 31.482C763.054 32.07 762.046 32.532 761.08 32.84V38.678C761.08 39.056 761.262 39.252 761.626 39.252H762.312C762.634 39.252 762.858 39.14 762.998 38.944C763.18 38.692 763.292 37.936 763.348 36.676L764.272 36.97C764.174 38.51 763.978 39.434 763.684 39.77C763.432 40.05 763.04 40.204 762.48 40.204Z"
              fill="#0D0D0D"
            />
          </svg>
          <div className="grid grid-cols-2 gap-2 pt-6 px-10 pb-10">
            {Array.from({ length: 6 }).map((_, index) => (
              <HoverFill
                key={index}
                className="flex-1"
                bgClassName="rounded-lg"
              >
                <div className="flex p-4 gap-3">
                  <img
                    src="https://images.unsplash.com/photo-1744219792921-a74da6141822?q=80&w=2304&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
                    className="size-[72px] object-cover rounded-full"
                  />
                  <div>
                    <div className="mb-1 text-base font-semibold">
                      隔壁大哥与小李
                    </div>
                    <div className="mb-1 text-xs text-neutral-500">北京</div>
                    <div className="flex items-center gap-1 text-xs font-semibold text-[#FA9D3B]">
                      <svg
                        width="12"
                        height="12"
                        viewBox="0 0 12 12"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          fillRule="evenodd"
                          clipRule="evenodd"
                          d="M1.95034 1.6875C2.47375 1.6875 2.93177 1.9773 3.30156 2.31113C3.68246 2.65497 4.05247 3.12099 4.40616 3.62976C4.94342 4.40259 5.49468 5.35282 6.02088 6.24805C6.55153 5.35495 7.10207 4.39995 7.62032 3.63526C7.96376 3.12852 8.31933 2.6638 8.68088 2.32066C9.02705 1.99212 9.46918 1.6875 9.98252 1.6875C10.9111 1.6875 11.1946 2.68232 11.24 3.43697C11.2884 4.24369 11.1562 5.27788 10.9361 6.27727C10.7147 7.28194 10.3941 8.2981 10.0395 9.07526C9.76384 9.67959 9.30679 10.625 8.52212 10.625C7.8495 10.625 7.30604 10.1036 6.89829 9.62485C6.60368 9.27893 6.30614 8.85579 6.01029 8.39727C5.70145 8.86029 5.38719 9.28774 5.07168 9.63712C4.6167 10.1409 4.03533 10.625 3.35858 10.625C2.5668 10.625 2.14842 9.66957 1.88823 9.06378C1.5549 8.28767 1.25496 7.27294 1.04745 6.27025C0.840836 5.27192 0.716824 4.24245 0.757797 3.44195C0.795031 2.71449 1.03384 1.6875 1.95034 1.6875ZM5.35736 7.33682C4.72087 6.26852 4.1007 5.16126 3.48244 4.27192C3.14695 3.78933 2.83433 3.40494 2.54772 3.1462C2.29911 2.92177 2.12256 2.83947 2.00977 2.81842C2.00814 2.82168 2.00641 2.8252 2.00459 2.82899C1.94996 2.94287 1.89869 3.16023 1.88133 3.49946C1.84732 4.1638 1.9515 5.08745 2.1491 6.04225C2.3458 6.99269 2.62612 7.93109 2.92193 8.61981C3.04598 8.90864 3.19348 9.26676 3.42645 9.49247C3.58999 9.45859 3.85745 9.30314 4.23674 8.88313C4.59212 8.4896 4.96652 7.95396 5.35736 7.33682ZM6.67611 7.34342C7.05778 7.96243 7.41793 8.49992 7.75476 8.89541C7.93874 9.11143 8.18034 9.4122 8.47042 9.49175C8.72587 9.26979 8.87955 8.90745 9.01601 8.60833C9.32973 7.92065 9.62845 6.98368 9.83741 6.03523C10.0475 5.0815 10.1565 4.16257 10.117 3.50444C10.104 3.28843 10.0933 2.99927 9.96195 2.8138C9.88317 2.82315 9.71847 2.88692 9.45533 3.13667C9.18196 3.39611 8.88003 3.78181 8.55159 4.26642C7.94142 5.16673 7.32933 6.26704 6.67611 7.34342Z"
                          fill="#FA9D3B"
                        />
                      </svg>
                      视频号特色
                    </div>
                  </div>
                </div>
              </HoverFill>
            ))}
          </div>
        </div>
      </CodeBox>
      <div className="flex justify-between items-center mb-6 pb-6 dotted-bottom" />
    </div>
  );
};

export default Basics;
```

**示例：cards-1** — cards-1

```tsx
'use client';

import React from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
import { motion, useSpring } from 'motion/react';

const Basics = () => {
  const cards = [
    {
      title: '文章底部广告',
      tags: ['收益稳定', '转化高效', '锚定完读人群'],
      img: 'https://wxa.wxs.qq.com/wxadtouch/upload/creator/e9p10xlx_59e3732fb9ea0a69a10339bb3f573029.png',
    },
    {
      title: '文章中部广告',
      tags: ['上下文场景', '视觉聚焦', '曝光显著'],
      img: 'https://wxa.wxs.qq.com/wxadtouch/upload/creator/h5ir0qvy_08defb7bb3c67431870c82747f0920e7.png',
    },
    {
      title: '评论区广告',
      tags: ['互动流量', '沉浸场景', '精准触达'],
      img: 'https://wxa.wxs.qq.com/wxadtouch/upload/creator/k3l0q7og_25c7643da1d54439b7ec9ede15a868eb.png',
    },
    {
      title: '关键词广告',
      tags: ['自动关联', '场景融合', '样式原生'],
      img: 'https://wxa.wxs.qq.com/wxadtouch/upload/creator/75fzbleg_3c15191e2f060b0bc7eb3592854ffa2a.png',
    },
    {
      title: '返佣商品广告',
      tags: ['位置灵活', '海量货池', '紧密结合内容'],
      img: 'https://wxa.wxs.qq.com/wxadtouch/upload/creator/uzromtd3_95d26d28d3f9d8dee356bfd91f2185bf.png',
    },
    {
      title: '互选广告',
      tags: ['内容定制', '细致解读', '传播力强'],
      img: 'https://wxa.wxs.qq.com/wxadtouch/upload/creator/2sx26vm9_4db5e7c169c9c3390fc397ac8fc91662.png',
    },
  ];

  const [hoverIndex, setHoverIndex] = React.useState(0);
  const indicatorX = useSpring(0, {
    // visualDuration: 0.2,
    // bounce: 0,
    stiffness: 685.389,
    damping: 52.36,
  });
  const indicatorY = useSpring(0, {
    // visualDuration: 0.2,
    // bounce: 0,
    stiffness: 685.389,
    damping: 52.36,
  });

  return (
    <div className="mb-3">
      <CodeBox className="mt-2 p-0" style={{ background: '#fff' }}>
        <div
          className="flex flex-none py-[60px] pl-[60px] pr-[80px] items-center justify-between w-[960px]"
          style={{
            zoom: 0.7,
          }}
        >
          <div className="relative grid gap-[18px] grid-cols-2">
            <motion.i
              className="absolute top-0 left-0 z-[1] w-[280px] h-[88px] bg-[#07c1600f] rounded-lg"
              style={{
                x: indicatorX,
                y: indicatorY,
              }}
            />
            {cards.map((card, index) => (
              <div
                key={card.title}
                className={`relative z-1 pl-[20px] flex flex-col justify-center w-[280px] h-[88px] transition-all ${
                  hoverIndex === index ? 'bg-white' : ''
                }`}
                onMouseEnter={(e) => {
                  const { offsetTop, offsetLeft } = e.currentTarget;
                  indicatorX.set(offsetLeft);
                  indicatorY.set(offsetTop);
                  setHoverIndex(index);
                }}
              >
                <div
                  className={`text-[18px] font-semibold transition-all ${
                    hoverIndex === index ? 'text-[#07c160]' : ''
                  }`}
                >
                  {card.title}
                </div>
                <div
                  className={`mt-1 flex items-center gap-2 text-sm transition-all ${
                    hoverIndex === index
                      ? 'text-[#07C160CC]'
                      : 'text-[#0000005c]'
                  }`}
                >
                  {card.tags.map((tag, index) => (
                    <React.Fragment key={tag}>
                      {tag}
                      {index !== card.tags.length - 1 && (
                        <i
                          className={`w-px h-3 transition-all ${
                            hoverIndex !== index
                              ? 'bg-[#e0e0e0]'
                              : 'bg-[#07C16026]'
                          }`}
                        />
                      )}
                    </React.Fragment>
                  ))}
                </div>
              </div>
            ))}
          </div>
          <div className="relative w-[200px] h-[430px]">
            {cards.map((card, index) => (
              <img
                key={index}
                src={card.img}
                className={`absolute top-0 left-0 w-full h-full ${
                  hoverIndex === index ? 'opacity-100' : 'opacity-0'
                }`}
              />
            ))}
          </div>
        </div>
      </CodeBox>
      <CodeBlock>
        {`import { motion, useSpring, useTransform } from 'motion/react';
const cards = [
  {
    title: '文章底部广告',
    tags: ['收益稳定', '转化高效', '锚定完读人群'],
    img: 'https://wxa.wxs.qq.com/wxadtouch/upload/creator/e9p10xlx_59e3732fb9ea0a69a10339bb3f573029.png',
  },
  {
    title: '文章中部广告',
    tags: ['上下文场景', '视觉聚焦', '曝光显著'],
    img: 'https://wxa.wxs.qq.com/wxadtouch/upload/creator/h5ir0qvy_08defb7bb3c67431870c82747f0920e7.png',
  },
  {
    title: '评论区广告',
    tags: ['互动流量', '沉浸场景', '精准触达'],
    img: 'https://wxa.wxs.qq.com/wxadtouch/upload/creator/k3l0q7og_25c7643da1d54439b7ec9ede15a868eb.png',
  },
  {
    title: '关键词广告',
    tags: ['自动关联', '场景融合', '样式原生'],
    img: 'https://wxa.wxs.qq.com/wxadtouch/upload/creator/h5ir0qvy_08defb7bb3c67431870c82747f0920e7.png',
  },
  {
    title: '返佣商品广告',
    tags: ['位置灵活', '海量货池', '紧密结合内容'],
    img: 'https://wxa.wxs.qq.com/wxadtouch/upload/creator/uzromtd3_95d26d28d3f9d8dee356bfd91f2185bf.png',
  },
  {
    title: '互选广告',
    tags: ['内容定制', '细致解读', '传播力强'],
    img: 'https://wxa.wxs.qq.com/wxadtouch/upload/creator/2sx26vm9_4db5e7c169c9c3390fc397ac8fc91662.png',
  },
];

const indicatorX = useSpring(0, {
  stiffness: 685.389,
  damping: 52.36,
});
const indicatorY = useSpring(0, {
  stiffness: 685.389,
  damping: 52.36,
}); 

return (
  <div className="relative grid gap-[18px] grid-cols-2">
    <motion.i
      className="absolute top-0 left-0 z-[1] w-[280px] h-[88px] bg-[#07c1600f] rounded-lg"
      style={{
        x: indicatorX,
        y: indicatorY,
      }}
    />
    {cards.map((card) => (
      <div
        key={card.title}
        className={\`relative z-1 pl-[20px] flex flex-col justify-center w-[280px] h-[88px] \${
          active ? 'bg-white' : ''
        }\`}
        onMouseEnter={(e) => {
          const { offsetTop, offsetLeft } = e.currentTarget;
          indicatorX.set(offsetLeft);
          indicatorY.set(offsetTop);
        }}
      >
        <div
          className={\`text-[18px] font-semibold \${
            active ? 'text-[#07c160]' : ''
          }\`}
        >
          {card.title}
        </div>
        <div
          className={\`mt-1 flex items-center gap-2 text-sm \${
            active ? 'text-[#07C160CC]' : 'text-[#0000005c]'
          }\`}
        >
          {card.tags.map((tag, index) => (
            <React.Fragment key={tag}>
              {tag}
              {index !== card.tags.length - 1 && (
                <i
                  className={\`w-px h-3 \${
                    !active ? 'bg-[#e0e0e0]' : 'bg-[#07C16026]'
                  }\`}
                />
              )}
            </React.Fragment>
          ))}
        </div>
      </div>
    ))}
  </div>
)`}
      </CodeBlock>
    </div>
  );
};

export default Basics;
```
### 作为表格内的轻量表单 {#as-light-form-in-table}

当被用在表格内时，每一个 `td` 是分隔的，所以 `HoverFill` 自然地被分开。而在最后一列中，两个轻量按钮的父级相同，则会自动共享背景：

**示例：table** — table

```tsx
'use client';

import { HoverFill } from 'one-design-next';
import React from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basics = () => {
  return (
    <div>
      <CodeBox className="mt-2 p-0">
        <div className="bg-white w-full">
          <div className="flex items-center justify-between pl-6 pr-4 h-[68px] border-b border-neutral-100">
            <div className="text-[18px] font-semibold">已选达人</div>
            <div className="flex">
              <HoverFill bgClassName="rounded-md">
                <div className="inline-flex items-center justify-center gap-0.5 h-9 px-3 text-sm">
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                    <path
                      d="M8.65 3C8.65 2.72386 8.42614 2.5 8.15 2.5H7.85C7.57386 2.5 7.35 2.72386 7.35 3V7.35H3C2.72386 7.35 2.5 7.57386 2.5 7.85V8.15C2.5 8.42614 2.72386 8.65 3 8.65H7.35V13C7.35 13.2761 7.57386 13.5 7.85 13.5H8.15C8.42614 13.5 8.65 13.2761 8.65 13V8.65H13C13.2761 8.65 13.5 8.42614 13.5 8.15V7.85C13.5 7.57386 13.2761 7.35 13 7.35H8.65V3Z"
                      fill="#464749"
                    />
                  </svg>
                  添加达人
                </div>
              </HoverFill>
              <HoverFill bgClassName="rounded-md">
                <div className="inline-flex items-center justify-center gap-0.5 h-9 px-3 text-sm">
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                    <mask id="path-1-inside-1_1118_48610" fill="white">
                      <rect x="2" y="2" width="11" height="12" rx="0.8" />
                    </mask>
                    <rect
                      x="2"
                      y="2"
                      width="11"
                      height="12"
                      rx="0.8"
                      stroke="black"
                      strokeWidth="2"
                      mask="url(#path-1-inside-1_1118_48610)"
                    />
                    <rect x="8" y="8" width="7" height="7" fill="#F7F7F7" />
                    <path d="M4 5H11" stroke="black" />
                    <path d="M4 7.5H11" stroke="black" />
                    <path d="M4 10H8" stroke="black" />
                    <path
                      fillRule="evenodd"
                      clipRule="evenodd"
                      d="M11.5 12.5V15H12.5V12.5H15V11.5H12.5V9H11.5V11.5H9V12.5H11.5Z"
                      fill="black"
                    />
                  </svg>
                  从名单添加
                </div>
              </HoverFill>
            </div>
          </div>
          <div className="flex items-center justify-between pl-6 pr-5 h-10 bg-neutral-50 border-b border-neutral-100">
            <div className="flex items-center gap-2">
              <img
                className="size-5 rounded-full"
                src="https://images.unsplash.com/photo-1744219792921-a74da6141822?q=80&w=2304&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
              />
              <div className="text-sm font-semibold">微品牌</div>
            </div>
            <HoverFill bgClassName="rounded-sm">
              <div className="flex items-center justify-center size-[26px]">
                <svg
                  width="18"
                  height="18"
                  viewBox="0 0 18 18"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    fillRule="evenodd"
                    clipRule="evenodd"
                    d="M14 5V15C14 15.5523 13.5523 16 13 16H5C4.44772 16 4 15.5523 4 15V5H2.5C2.22386 5 2 4.77614 2 4.5V4C2 3.72386 2.22386 3.5 2.5 3.5H6V2.5C6 2.22386 6.22386 2 6.5 2H11.5C11.7761 2 12 2.22386 12 2.5V3.5H15.5C15.7761 3.5 16 3.72386 16 4V4.5C16 4.77614 15.7761 5 15.5 5H14ZM5.5 5V14.5H12.5V5H5.5ZM7 6.5H8.5V13H7V6.5ZM9.5 6.5H11V13H9.5V6.5Z"
                    fill="#455066"
                    fillOpacity="0.25"
                  />
                </svg>
              </div>
            </HoverFill>
          </div>
          <div className="flex">
            <div className="w-[128px] border-r border-neutral-100">
              <div className="flex items-center pl-6 h-[44px] text-neutral-500 text-sm border-b border-neutral-100">
                视频时长
              </div>
              <div className="h-[44px] border-b border-neutral-100">
                <div className="ml-2 p-1">
                  <HoverFill bgClassName="rounded">
                    <div className="flex items-center px-3 h-9">
                      <div className="flex-1 text-sm">1至60秒</div>
                      <svg
                        width="16"
                        height="16"
                        viewBox="0 0 16 16"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          fillRule="evenodd"
                          clipRule="evenodd"
                          d="M12.9834 6.32322C13.081 6.42085 13.081 6.57915 12.9834 6.67678L8.17505 11.4851C8.07742 11.5827 7.91913 11.5827 7.8215 11.4851L3.01317 6.67678C2.91554 6.57915 2.91554 6.42086 3.01317 6.32322L3.57886 5.75754C3.67649 5.65991 3.83478 5.65991 3.93241 5.75754L7.99828 9.8234L12.0641 5.75754C12.1618 5.65991 12.3201 5.65991 12.4177 5.75754L12.9834 6.32322Z"
                          fill="#3E4552"
                          fillOpacity="0.36"
                        />
                      </svg>
                    </div>
                  </HoverFill>
                </div>
              </div>
              <div className="h-[44px]">
                <div className="ml-2 p-1">
                  <HoverFill bgClassName="rounded">
                    <div className="flex items-center px-3 h-9">
                      <div className="flex-1 text-sm">60秒以上</div>
                      <svg
                        width="16"
                        height="16"
                        viewBox="0 0 16 16"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          fillRule="evenodd"
                          clipRule="evenodd"
                          d="M12.9834 6.32322C13.081 6.42085 13.081 6.57915 12.9834 6.67678L8.17505 11.4851C8.07742 11.5827 7.91913 11.5827 7.8215 11.4851L3.01317 6.67678C2.91554 6.57915 2.91554 6.42086 3.01317 6.32322L3.57886 5.75754C3.67649 5.65991 3.83478 5.65991 3.93241 5.75754L7.99828 9.8234L12.0641 5.75754C12.1618 5.65991 12.3201 5.65991 12.4177 5.75754L12.9834 6.32322Z"
                          fill="#3E4552"
                          fillOpacity="0.36"
                        />
                      </svg>
                    </div>
                  </HoverFill>
                </div>
              </div>
            </div>
            <div className="flex-1 border-r border-neutral-100">
              <div className="flex items-center pl-4 h-[44px] text-neutral-500 text-sm border-b border-neutral-100">
                额外服务
              </div>
              <div className="h-[44px] border-b border-neutral-100">
                <div className="p-1">
                  <HoverFill bgClassName="rounded">
                    <div className="flex items-center px-3 h-9">
                      <div className="flex-1 text-sm text-neutral-500">
                        选填额外服务
                      </div>
                      <svg
                        width="16"
                        height="16"
                        viewBox="0 0 16 16"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          fillRule="evenodd"
                          clipRule="evenodd"
                          d="M12.9834 6.32322C13.081 6.42085 13.081 6.57915 12.9834 6.67678L8.17505 11.4851C8.07742 11.5827 7.91913 11.5827 7.8215 11.4851L3.01317 6.67678C2.91554 6.57915 2.91554 6.42086 3.01317 6.32322L3.57886 5.75754C3.67649 5.65991 3.83478 5.65991 3.93241 5.75754L7.99828 9.8234L12.0641 5.75754C12.1618 5.65991 12.3201 5.65991 12.4177 5.75754L12.9834 6.32322Z"
                          fill="#3E4552"
                          fillOpacity="0.36"
                        />
                      </svg>
                    </div>
                  </HoverFill>
                </div>
              </div>
              <div className="h-[44px]">
                <div className="p-1">
                  <HoverFill bgClassName="rounded">
                    <div className="flex items-center px-3 h-9">
                      <div className="flex-1 text-sm">出镜拍摄</div>
                      <svg
                        width="16"
                        height="16"
                        viewBox="0 0 16 16"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          fillRule="evenodd"
                          clipRule="evenodd"
                          d="M12.9834 6.32322C13.081 6.42085 13.081 6.57915 12.9834 6.67678L8.17505 11.4851C8.07742 11.5827 7.91913 11.5827 7.8215 11.4851L3.01317 6.67678C2.91554 6.57915 2.91554 6.42086 3.01317 6.32322L3.57886 5.75754C3.67649 5.65991 3.83478 5.65991 3.93241 5.75754L7.99828 9.8234L12.0641 5.75754C12.1618 5.65991 12.3201 5.65991 12.4177 5.75754L12.9834 6.32322Z"
                          fill="#3E4552"
                          fillOpacity="0.36"
                        />
                      </svg>
                    </div>
                  </HoverFill>
                </div>
              </div>
            </div>
            <div className="w-[240px] border-r border-neutral-100">
              <div className="flex items-center pl-4 h-[44px] text-neutral-500 text-sm border-b border-neutral-100">
                期望发表时间段
              </div>
              <div className="h-[44px] border-b border-neutral-100">
                <div className="p-1">
                  <HoverFill bgClassName="rounded">
                    <div className="flex items-center px-3 h-9">
                      <div className="flex-1 text-sm text-neutral-500">
                        请选择期望发表的时间段
                      </div>
                      <svg
                        width="16"
                        height="16"
                        viewBox="0 0 16 16"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          fillRule="evenodd"
                          clipRule="evenodd"
                          d="M2 1C1.44772 1 1 1.44772 1 2V14C1 14.5523 1.44772 15 2 15H14C14.5523 15 15 14.5523 15 14V2C15 1.44772 14.5523 1 14 1H2ZM14 2.07692H2V13.9231H14V2.07692Z"
                          fill="#33373D"
                          fillOpacity="0.58"
                        />
                        <path
                          d="M2 5H14V6H2V5Z"
                          fill="#33373D"
                          fillOpacity="0.58"
                        />
                        <path
                          d="M4.5 0C4.77614 1.20706e-08 5 0.223858 5 0.5L5 3.5C5 3.77614 4.77614 4 4.5 4C4.22386 4 4 3.77614 4 3.5V0.5C4 0.223858 4.22386 -1.20706e-08 4.5 0Z"
                          fill="#33373D"
                          fillOpacity="0.58"
                        />
                        <path
                          d="M11.5 0C11.7761 1.20706e-08 12 0.223858 12 0.5V3.5C12 3.77614 11.7761 4 11.5 4C11.2239 4 11 3.77614 11 3.5V0.5C11 0.223858 11.2239 -1.20706e-08 11.5 0Z"
                          fill="#33373D"
                          fillOpacity="0.58"
                        />
                        <path
                          d="M4 11.5C4 11.2239 4.22386 11 4.5 11H11.5C11.7761 11 12 11.2239 12 11.5C12 11.7761 11.7761 12 11.5 12H4.5C4.22386 12 4 11.7761 4 11.5Z"
                          fill="#33373D"
                          fillOpacity="0.58"
                        />
                        <path
                          d="M4 8.5C4 8.22386 4.22386 8 4.5 8H11.5C11.7761 8 12 8.22386 12 8.5C12 8.77614 11.7761 9 11.5 9H4.5C4.22386 9 4 8.77614 4 8.5Z"
                          fill="#33373D"
                          fillOpacity="0.58"
                        />
                      </svg>
                    </div>
                  </HoverFill>
                </div>
              </div>
              <div className="h-[44px]">
                <div className="p-1">
                  <HoverFill bgClassName="rounded">
                    <div className="flex items-center px-3 h-9">
                      <div className="flex-1 text-sm">
                        2025-03-11 ~ 2025-03-31
                      </div>
                      <svg
                        width="16"
                        height="16"
                        viewBox="0 0 16 16"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          fillRule="evenodd"
                          clipRule="evenodd"
                          d="M2 1C1.44772 1 1 1.44772 1 2V14C1 14.5523 1.44772 15 2 15H14C14.5523 15 15 14.5523 15 14V2C15 1.44772 14.5523 1 14 1H2ZM14 2.07692H2V13.9231H14V2.07692Z"
                          fill="#33373D"
                          fillOpacity="0.58"
                        />
                        <path
                          d="M2 5H14V6H2V5Z"
                          fill="#33373D"
                          fillOpacity="0.58"
                        />
                        <path
                          d="M4.5 0C4.77614 1.20706e-08 5 0.223858 5 0.5L5 3.5C5 3.77614 4.77614 4 4.5 4C4.22386 4 4 3.77614 4 3.5V0.5C4 0.223858 4.22386 -1.20706e-08 4.5 0Z"
                          fill="#33373D"
                          fillOpacity="0.58"
                        />
                        <path
                          d="M11.5 0C11.7761 1.20706e-08 12 0.223858 12 0.5V3.5C12 3.77614 11.7761 4 11.5 4C11.2239 4 11 3.77614 11 3.5V0.5C11 0.223858 11.2239 -1.20706e-08 11.5 0Z"
                          fill="#33373D"
                          fillOpacity="0.58"
                        />
                        <path
                          d="M4 11.5C4 11.2239 4.22386 11 4.5 11H11.5C11.7761 11 12 11.2239 12 11.5C12 11.7761 11.7761 12 11.5 12H4.5C4.22386 12 4 11.7761 4 11.5Z"
                          fill="#33373D"
                          fillOpacity="0.58"
                        />
                        <path
                          d="M4 8.5C4 8.22386 4.22386 8 4.5 8H11.5C11.7761 8 12 8.22386 12 8.5C12 8.77614 11.7761 9 11.5 9H4.5C4.22386 9 4 8.77614 4 8.5Z"
                          fill="#33373D"
                          fillOpacity="0.58"
                        />
                      </svg>
                    </div>
                  </HoverFill>
                </div>
              </div>
            </div>
            <div className="w-[120px] border-r border-neutral-100">
              <div className="flex items-center justify-end pl-4 pr-4 h-[44px] text-neutral-500 text-sm border-b border-neutral-100">
                合作报价
              </div>
              <div className="h-[44px] border-b border-neutral-100">
                <div className="flex items-center pr-4 justify-end h-[44px] text-sm">
                  ￥60,000
                </div>
              </div>
              <div className="h-[44px]">
                <div className="flex items-center pr-4 justify-end h-[44px] text-sm">
                  ￥8,888,888
                </div>
              </div>
            </div>
            <div className="w-[84px]">
              <div className="flex items-center pl-[30px] pr-4 h-[44px] text-neutral-500 text-sm border-b border-neutral-100">
                操作
              </div>
              <div className="flex items-center pl-3 h-[44px] border-b border-neutral-100">
                <HoverFill bgClassName="rounded-sm">
                  <div className="flex items-center justify-center size-[26px]">
                    <svg
                      width="18"
                      height="18"
                      viewBox="0 0 18 18"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        fillRule="evenodd"
                        clipRule="evenodd"
                        d="M9 16C5.13401 16 2 12.866 2 9C2 5.13401 5.13401 2 9 2C12.866 2 16 5.13401 16 9C16 12.866 12.866 16 9 16ZM5 8.25V9.75H13V8.25H5Z"
                        fill="#455066"
                        fillOpacity="0.25"
                      />
                    </svg>
                  </div>
                </HoverFill>
                <HoverFill bgClassName="rounded-sm">
                  <div className="flex items-center justify-center size-[26px]">
                    <svg
                      width="18"
                      height="18"
                      viewBox="0 0 18 18"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        fillRule="evenodd"
                        clipRule="evenodd"
                        d="M9 16C5.13401 16 2 12.866 2 9C2 5.13401 5.13401 2 9 2C12.866 2 16 5.13401 16 9C16 12.866 12.866 16 9 16ZM8.25 8.25H5V9.75H8.25V13H9.75V9.75H13V8.25H9.75V5H8.25V8.25Z"
                        fill="#455066"
                        fillOpacity="0.25"
                      />
                    </svg>
                  </div>
                </HoverFill>
              </div>
              <div className="flex items-center pl-3 h-[44px] border-b border-neutral-100">
                <HoverFill bgClassName="rounded-sm">
                  <div className="flex items-center justify-center size-[26px]">
                    <svg
                      width="18"
                      height="18"
                      viewBox="0 0 18 18"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        fillRule="evenodd"
                        clipRule="evenodd"
                        d="M9 16C5.13401 16 2 12.866 2 9C2 5.13401 5.13401 2 9 2C12.866 2 16 5.13401 16 9C16 12.866 12.866 16 9 16ZM5 8.25V9.75H13V8.25H5Z"
                        fill="#455066"
                        fillOpacity="0.25"
                      />
                    </svg>
                  </div>
                </HoverFill>
                <HoverFill bgClassName="rounded-sm">
                  <div className="flex items-center justify-center size-[26px]">
                    <svg
                      width="18"
                      height="18"
                      viewBox="0 0 18 18"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        fillRule="evenodd"
                        clipRule="evenodd"
                        d="M9 16C5.13401 16 2 12.866 2 9C2 5.13401 5.13401 2 9 2C12.866 2 16 5.13401 16 9C16 12.866 12.866 16 9 16ZM8.25 8.25H5V9.75H8.25V13H9.75V9.75H13V8.25H9.75V5H8.25V8.25Z"
                        fill="#455066"
                        fillOpacity="0.25"
                      />
                    </svg>
                  </div>
                </HoverFill>
              </div>
            </div>
          </div>
          <div className="flex items-center justify-between pl-6 pr-5 h-10 bg-neutral-50 border-b border-neutral-100">
            <div className="flex items-center gap-2">
              <img
                className="size-5 rounded-full"
                src="https://images.unsplash.com/photo-1744219792921-a74da6141822?q=80&w=2304&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
              />
              <div className="text-sm font-semibold">菜菜美食日记</div>
            </div>
            <HoverFill bgClassName="rounded-sm">
              <div className="flex items-center justify-center size-[26px]">
                <svg
                  width="18"
                  height="18"
                  viewBox="0 0 18 18"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    fillRule="evenodd"
                    clipRule="evenodd"
                    d="M14 5V15C14 15.5523 13.5523 16 13 16H5C4.44772 16 4 15.5523 4 15V5H2.5C2.22386 5 2 4.77614 2 4.5V4C2 3.72386 2.22386 3.5 2.5 3.5H6V2.5C6 2.22386 6.22386 2 6.5 2H11.5C11.7761 2 12 2.22386 12 2.5V3.5H15.5C15.7761 3.5 16 3.72386 16 4V4.5C16 4.77614 15.7761 5 15.5 5H14ZM5.5 5V14.5H12.5V5H5.5ZM7 6.5H8.5V13H7V6.5ZM9.5 6.5H11V13H9.5V6.5Z"
                    fill="#455066"
                    fillOpacity="0.25"
                  />
                </svg>
              </div>
            </HoverFill>
          </div>
          <div className="flex">
            <div className="w-[128px] border-r border-neutral-100">
              <div className="flex items-center pl-6 h-[44px] text-neutral-500 text-sm border-b border-neutral-100">
                视频时长
              </div>
              <div className="h-[44px]">
                <div className="ml-2 p-1">
                  <HoverFill bgClassName="rounded">
                    <div className="flex items-center px-3 h-9">
                      <div className="flex-1 text-sm">1至60秒</div>
                      <svg
                        width="16"
                        height="16"
                        viewBox="0 0 16 16"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          fillRule="evenodd"
                          clipRule="evenodd"
                          d="M12.9834 6.32322C13.081 6.42085 13.081 6.57915 12.9834 6.67678L8.17505 11.4851C8.07742 11.5827 7.91913 11.5827 7.8215 11.4851L3.01317 6.67678C2.91554 6.57915 2.91554 6.42086 3.01317 6.32322L3.57886 5.75754C3.67649 5.65991 3.83478 5.65991 3.93241 5.75754L7.99828 9.8234L12.0641 5.75754C12.1618 5.65991 12.3201 5.65991 12.4177 5.75754L12.9834 6.32322Z"
                          fill="#3E4552"
                          fillOpacity="0.36"
                        />
                      </svg>
                    </div>
                  </HoverFill>
                </div>
              </div>
            </div>
            <div className="flex-1 border-r border-neutral-100">
              <div className="flex items-center pl-4 h-[44px] text-neutral-500 text-sm border-b border-neutral-100">
                额外服务
              </div>
              <div className="h-[44px]">
                <div className="p-1">
                  <HoverFill bgClassName="rounded">
                    <div className="flex items-center px-3 h-9">
                      <div className="flex-1 text-sm text-neutral-500">
                        选填额外服务
                      </div>
                      <svg
                        width="16"
                        height="16"
                        viewBox="0 0 16 16"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          fillRule="evenodd"
                          clipRule="evenodd"
                          d="M12.9834 6.32322C13.081 6.42085 13.081 6.57915 12.9834 6.67678L8.17505 11.4851C8.07742 11.5827 7.91913 11.5827 7.8215 11.4851L3.01317 6.67678C2.91554 6.57915 2.91554 6.42086 3.01317 6.32322L3.57886 5.75754C3.67649 5.65991 3.83478 5.65991 3.93241 5.75754L7.99828 9.8234L12.0641 5.75754C12.1618 5.65991 12.3201 5.65991 12.4177 5.75754L12.9834 6.32322Z"
                          fill="#3E4552"
                          fillOpacity="0.36"
                        />
                      </svg>
                    </div>
                  </HoverFill>
                </div>
              </div>
            </div>
            <div className="w-[240px] border-r border-neutral-100">
              <div className="flex items-center pl-4 h-[44px] text-neutral-500 text-sm border-b border-neutral-100">
                期望发表时间段
              </div>
              <div className="h-[44px]">
                <div className="p-1">
                  <HoverFill bgClassName="rounded">
                    <div className="flex items-center px-3 h-9">
                      <div className="flex-1 text-sm text-neutral-500">
                        请选择期望发表的时间段
                      </div>
                      <svg
                        width="16"
                        height="16"
                        viewBox="0 0 16 16"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          fillRule="evenodd"
                          clipRule="evenodd"
                          d="M2 1C1.44772 1 1 1.44772 1 2V14C1 14.5523 1.44772 15 2 15H14C14.5523 15 15 14.5523 15 14V2C15 1.44772 14.5523 1 14 1H2ZM14 2.07692H2V13.9231H14V2.07692Z"
                          fill="#33373D"
                          fillOpacity="0.58"
                        />
                        <path
                          d="M2 5H14V6H2V5Z"
                          fill="#33373D"
                          fillOpacity="0.58"
                        />
                        <path
                          d="M4.5 0C4.77614 1.20706e-08 5 0.223858 5 0.5L5 3.5C5 3.77614 4.77614 4 4.5 4C4.22386 4 4 3.77614 4 3.5V0.5C4 0.223858 4.22386 -1.20706e-08 4.5 0Z"
                          fill="#33373D"
                          fillOpacity="0.58"
                        />
                        <path
                          d="M11.5 0C11.7761 1.20706e-08 12 0.223858 12 0.5V3.5C12 3.77614 11.7761 4 11.5 4C11.2239 4 11 3.77614 11 3.5V0.5C11 0.223858 11.2239 -1.20706e-08 11.5 0Z"
                          fill="#33373D"
                          fillOpacity="0.58"
                        />
                        <path
                          d="M4 11.5C4 11.2239 4.22386 11 4.5 11H11.5C11.7761 11 12 11.2239 12 11.5C12 11.7761 11.7761 12 11.5 12H4.5C4.22386 12 4 11.7761 4 11.5Z"
                          fill="#33373D"
                          fillOpacity="0.58"
                        />
                        <path
                          d="M4 8.5C4 8.22386 4.22386 8 4.5 8H11.5C11.7761 8 12 8.22386 12 8.5C12 8.77614 11.7761 9 11.5 9H4.5C4.22386 9 4 8.77614 4 8.5Z"
                          fill="#33373D"
                          fillOpacity="0.58"
                        />
                      </svg>
                    </div>
                  </HoverFill>
                </div>
              </div>
            </div>
            <div className="w-[120px] border-r border-neutral-100">
              <div className="flex items-center justify-end pl-4 pr-4 h-[44px] text-neutral-500 text-sm border-b border-neutral-100">
                合作报价
              </div>
              <div className="h-[44px]">
                <div className="flex items-center pr-4 justify-end h-[44px] text-sm">
                  ￥60,000
                </div>
              </div>
            </div>
            <div className="w-[84px]">
              <div className="flex items-center pl-[30px] pr-4 h-[44px] text-neutral-500 text-sm border-b border-neutral-100">
                操作
              </div>
              <div className="flex items-center pl-3 h-[44px]">
                <HoverFill bgClassName="rounded-sm">
                  <div className="flex items-center justify-center size-[26px]">
                    <svg
                      width="18"
                      height="18"
                      viewBox="0 0 18 18"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        fillRule="evenodd"
                        clipRule="evenodd"
                        d="M9 16C5.13401 16 2 12.866 2 9C2 5.13401 5.13401 2 9 2C12.866 2 16 5.13401 16 9C16 12.866 12.866 16 9 16ZM5 8.25V9.75H13V8.25H5Z"
                        fill="#455066"
                        fillOpacity="0.25"
                      />
                    </svg>
                  </div>
                </HoverFill>
                <HoverFill bgClassName="rounded-sm">
                  <div className="flex items-center justify-center size-[26px]">
                    <svg
                      width="18"
                      height="18"
                      viewBox="0 0 18 18"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        fillRule="evenodd"
                        clipRule="evenodd"
                        d="M9 16C5.13401 16 2 12.866 2 9C2 5.13401 5.13401 2 9 2C12.866 2 16 5.13401 16 9C16 12.866 12.866 16 9 16ZM8.25 8.25H5V9.75H8.25V13H9.75V9.75H13V8.25H9.75V5H8.25V8.25Z"
                        fill="#455066"
                        fillOpacity="0.25"
                      />
                    </svg>
                  </div>
                </HoverFill>
              </div>
            </div>
          </div>
        </div>
      </CodeBox>
    </div>
  );
};

export default Basics;
```
### 作为多行表格 {#as-multi-row-table}

如果表格的每行没有分隔，则可以考虑使用：

**示例：table-rows** — table-rows

```tsx
'use client';

import { HoverFill } from 'one-design-next';
import React from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basics = () => {
  return (
    <div>
      <CodeBox className="mt-2 p-0">
        <div className="bg-white flex items-center justify-center p-5 w-full">
          <div>
            <div className="flex h-11 text-xs text-neutral-500">
              <div className="flex items-center w-[78px] pl-2">指数名称</div>
              <div className="flex justify-center items-center w-[70px]">
                指数值
              </div>
              <div className="flex justify-center items-center w-[70px]">
                30天环比
              </div>
              <div className="flex justify-center items-center w-[70px]">
                行业均值
              </div>
              <div className="flex justify-end items-center pr-2 w-[77px]">
                行业排名
              </div>
            </div>
            <HoverFill bgClassName="rounded-sm">
              <div className="flex h-11 text-sm group">
                <div className="flex items-center w-[78px] pl-2 group-hover:text-[#296BEF] group-hover:font-semibold transition-colors duration-150">
                  社交指数
                </div>
                <div className="flex justify-center items-center w-[70px] group-hover:text-[#296BEF] group-hover:font-medium transition-colors duration-150">
                  92.5
                </div>
                <div className="flex justify-center items-center w-[70px]">
                  +0.5%
                </div>
                <div className="flex justify-center items-center w-[70px] group-hover:text-[#10AEFF] group-hover:font-semibold transition-colors duration-150">
                  80
                </div>
                <div className="flex justify-end items-center pr-2 w-[77px]">
                  前0.5%
                </div>
              </div>
            </HoverFill>
            <HoverFill bgClassName="rounded-sm">
              <div className="flex h-11 text-sm group">
                <div className="flex items-center w-[78px] pl-2 group-hover:text-[#296BEF] group-hover:font-semibold transition-colors duration-150">
                  互动指数
                </div>
                <div className="flex justify-center items-center w-[70px] group-hover:text-[#296BEF] group-hover:font-medium transition-colors duration-150">
                  84.2
                </div>
                <div className="flex justify-center items-center w-[70px]">
                  -1.1%
                </div>
                <div className="flex justify-center items-center w-[70px] group-hover:text-[#10AEFF] group-hover:font-semibold transition-colors duration-150">
                  80
                </div>
                <div className="flex justify-end items-center pr-2 w-[77px]">
                  前50%
                </div>
              </div>
            </HoverFill>
            <HoverFill bgClassName="rounded-sm">
              <div className="flex h-11 text-sm group">
                <div className="flex items-center w-[78px] pl-2 group-hover:text-[#296BEF] group-hover:font-semibold transition-colors duration-150">
                  合作指数
                </div>
                <div className="flex justify-center items-center w-[70px] group-hover:text-[#296BEF] group-hover:font-medium transition-colors duration-150">
                  80.2
                </div>
                <div className="flex justify-center items-center w-[70px]">
                  +3.4%
                </div>
                <div className="flex justify-center items-center w-[70px] group-hover:text-[#10AEFF] group-hover:font-semibold transition-colors duration-150">
                  70
                </div>
                <div className="flex justify-end items-center pr-2 w-[77px]">
                  前10%
                </div>
              </div>
            </HoverFill>
            <HoverFill bgClassName="rounded-sm">
              <div className="flex h-11 text-sm group">
                <div className="flex items-center w-[78px] pl-2 group-hover:text-[#296BEF] group-hover:font-semibold transition-colors duration-150">
                  性价比指数
                </div>
                <div className="flex justify-center items-center w-[70px] group-hover:text-[#296BEF] group-hover:font-medium transition-colors duration-150">
                  92.5
                </div>
                <div className="flex justify-center items-center w-[70px]">
                  +0.5%
                </div>
                <div className="flex justify-center items-center w-[70px] group-hover:text-[#10AEFF] group-hover:font-semibold transition-colors duration-150">
                  80
                </div>
                <div className="flex justify-end items-center pr-2 w-[77px]">
                  低于50%
                </div>
              </div>
            </HoverFill>
            <HoverFill bgClassName="rounded-sm">
              <div className="flex h-11 text-sm group">
                <div className="flex items-center w-[78px] pl-2 group-hover:text-[#296BEF] group-hover:font-semibold transition-colors duration-150">
                  成长指数
                </div>
                <div className="flex justify-center items-center w-[70px] group-hover:text-[#296BEF] group-hover:font-medium transition-colors duration-150">
                  92.5
                </div>
                <div className="flex justify-center items-center w-[70px]">
                  +0.5%
                </div>
                <div className="flex justify-center items-center w-[70px] group-hover:text-[#10AEFF] group-hover:font-semibold transition-colors duration-150">
                  80
                </div>
                <div className="flex justify-end items-center pr-2 w-[77px]">
                  低于50%
                </div>
              </div>
            </HoverFill>
          </div>
        </div>
      </CodeBox>
    </div>
  );
};

export default Basics;
```
### 作为分页器 {#as-pagination}

**示例：pagination** — pagination

```tsx
import { Pagination } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basic = () => {
  const [value, setValue] = useState(1);

  return (
    <div>
      <CodeBox>
        <Pagination
          showPrevNext
          totalSize={100}
          pageSize={10}
          value={value}
          onChange={(_, value) => setValue(value)}
        />
      </CodeBox>
    </div>
  );
};

export default Basic;
```
### 作为日历 {#as-calendar}

头部为一组 `HoverFill`，日期为一组 `HoverFill`：

**示例：calendar** — calendar

```tsx
import { Calendar } from 'one-design-next';
import React from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basic = () => {
  return (
    <div>
      <CodeBox>
        <Calendar mode="single" />
      </CodeBox>
    </div>
  );
};

export default Basic;
```
### 作为同级列表项 {#as-sibling-list-items}

**示例：list** — list

```tsx
'use client';

import { motion } from 'motion/react';
import { Button, HoverFill } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const items = [
  '人群包推荐：精致型男、成熟男性、节日送礼',
  '香水推广人群策略',
  '人群包推荐：精致型男、成熟男性、节日送礼',
  '人群包推荐：小馋猫薯条美味卖点',
  '人群包推荐：精致型男、成熟男性、节日送礼',
  '香水推广人群策略',
  '人群包推荐：精致型男、成熟男性、节日送礼',
  '人群包推荐：小馋猫薯条美味卖点',
  '香水推广人群策略',
];

const Basics = () => {
  const [hoveredIndex, setHoveredIndex] = useState(0);
  const [isHovered, setIsHovered] = useState(false);
  const wasHoveredRef = useRef(false);
  const isEntering = isHovered && !wasHoveredRef.current;

  useEffect(() => {
    wasHoveredRef.current = isHovered;
  }, [isHovered]);

  return (
    <CodeBox className="mt-2 flex gap-6 p-4">
      <div className="flex flex-col gap-1 items-start">
        <Button icon="time">近期探索人群</Button>
        <div
          className="relative py-1 w-[280px] text-sm bg-white border border-neutral-200 rounded-md shadow select-none"
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
        >
          <motion.div
            className="absolute top-0 left-0 w-full h-9 bg-neutral-100"
            animate={{ y: 4 + hoveredIndex * 36, opacity: isHovered ? 1 : 0 }}
            transition={{
              y: isEntering
                ? { duration: 0 }
                : { type: 'spring', bounce: 0, duration: 0.2 },
              opacity: { type: 'spring', bounce: 0, duration: 0.2 },
            }}
          />
          {items.map((item, index) => {
            const isActive = isHovered && hoveredIndex === index;
            return (
              <div
                className="relative px-3 h-9 cursor-pointer"
                key={index}
                onMouseEnter={() => setHoveredIndex(index)}
              >
                <div
                  className="leading-9 whitespace-nowrap overflow-hidden text-ellipsis transition-opacity duration-100"
                  style={{ opacity: isActive ? 0 : 1 }}
                >
                  {item}
                </div>
                <div
                  className="absolute top-0 left-0 w-full h-full pl-3 pr-16 leading-9 whitespace-nowrap overflow-hidden text-ellipsis transition-opacity duration-100"
                  style={{ opacity: isActive ? 1 : 0 }}
                >
                  {item}
                </div>
              </div>
            );
          })}
          <motion.div
            className="absolute top-0 right-1 flex items-center h-9"
            animate={{ y: 4 + hoveredIndex * 36, opacity: isHovered ? 1 : 0 }}
            transition={{
              y: isEntering
                ? { duration: 0 }
                : { type: 'spring', bounce: 0, duration: 0.2 },
              opacity: { type: 'spring', bounce: 0, duration: 0.2 },
            }}
          >
            <Button icon="edit" light size="small" />
            <Button icon="delete" light size="small" />
          </motion.div>
        </div>
      </div>
      <div className="w-[366px] max-w-[95%] bg-white border border-neutral-200 rounded-xl">
        <div className="flex items-center justify-between px-5 h-[62px]">
          <div className="flex items-center">
            <HoverFill bgClassName="rounded-sm">
              <div className="flex items-center justify-center size-[30px]">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                  <path
                    d="M7.38564 6.00727C7.09274 5.71437 6.61787 5.71437 6.32498 6.00727L6.00678 6.32547C5.71389 6.61836 5.71389 7.09323 6.00678 7.38613L10.6207 12L6.00678 16.6139C5.71389 16.9068 5.71389 17.3816 6.00678 17.6745L6.32498 17.9927C6.61787 18.2856 7.09274 18.2856 7.38564 17.9927L11.9995 13.3789L16.6134 17.9927C16.9063 18.2856 17.3811 18.2856 17.674 17.9927L17.9922 17.6745C18.2851 17.3816 18.2851 16.9068 17.9922 16.6139L13.3784 12L17.9922 7.38613C18.2851 7.09323 18.2851 6.61836 17.9922 6.32547L17.674 6.00727C17.3811 5.71437 16.9063 5.71437 16.6134 6.00727L11.9995 10.6211L7.38564 6.00727Z"
                    fill="#464749"
                  />
                </svg>
              </div>
            </HoverFill>
            <i className="ml-3 mr-4 w-px h-[26px] bg-neutral-200" />
            <div className="text-[18px] font-semibold">自定义列表</div>
          </div>
          <HoverFill bgClassName="rounded-sm">
            <div className="flex items-center justify-center w-[46px] h-[30px] font-medium text-[13px] text-neutral-500">
              重置
            </div>
          </HoverFill>
        </div>
        <div className="flex items-center pl-6 h-[54px] text-sm bg-neutral-100 border-y border-neutral-200">
          默认列：创作者、亮点视频、亮点标签
        </div>
        <div className="p-3">
          {[
            '粉丝量级',
            '粉丝增长量',
            '粉丝增长率',
            '平均播放量',
            '播放中位数',
          ].map((item) => (
            <HoverFill bgClassName="rounded-lg" key={item}>
              <div className="flex items-center justify-between pl-3 pr-2 h-12 text-sm">
                {item}
                <Button icon="delete" light />
              </div>
            </HoverFill>
          ))}
        </div>
      </div>
    </CodeBox>
  );
};

export default Basics;
```
### 作为树形列表项 {#as-tree-list-items}

**示例：tree** — tree

```tsx
'use client';

import { motion } from 'motion/react';
import { HoverFill } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basics = () => {
  const [isExpanded, setIsExpanded] = useState(true);

  const handleClick = () => {
    setIsExpanded(!isExpanded);
  };

  const variants = {
    expanded: {
      opacity: 1,
      height: 'auto',
      overflow: 'hidden',
    },
    collapsed: {
      opacity: 0,
      height: 0,
      overflow: 'hidden',
    },
  };

  return (
    <div>
      <CodeBox className="mt-2">
        <div className="w-[280px] text-sm">
          <HoverFill bgClassName="rounded">
            <div className="flex items-center px-2 gap-2 h-8">
              <svg width="16" height="16" viewBox="0 0 16 16">
                <path d="m1 9.5.826-3.717A1 1 0 0 1 2.802 5H13V4H7.125A1.125 1.125 0 0 1 6 2.875V2H1v7.5zm.247 3.5h11.95l1.556-7H2.803l-1.556 7zM13 14H1a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h5.25a.75.75 0 0 1 .75.75v1.125c0 .069.056.125.125.125H13a1 1 0 0 1 1 1v1h.753a1 1 0 0 1 .977 1.217l-1.556 7a1 1 0 0 1-.976.783H13z"></path>
              </svg>
              Item One
            </div>
          </HoverFill>
          <HoverFill className="ml-6" bgClassName="rounded">
            <div className="flex items-center px-2 gap-2 h-8">
              <svg width="16" height="16" viewBox="0 0 16 16">
                <path
                  fillRule="evenodd"
                  d="M3 2a1 1 0 0 1 1-1h4.707L13 5.293V14a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2Zm5 0H4v12h8V6H9a1 1 0 0 1-1-1V2Zm1 .707L11.293 5H9V2.707Z"
                  clipRule="evenodd"
                />
              </svg>
              Item A
            </div>
          </HoverFill>
          <HoverFill
            className="ml-6"
            bgClassName="rounded"
            // onClick={handleClick}
          >
            <div className="flex items-center px-2 gap-2 h-8">
              <motion.svg
                width="16"
                height="16"
                viewBox="0 0 16 16"
                animate={{ rotate: isExpanded ? 0 : -90 }}
                transition={{ duration: 0.3 }}
              >
                <path
                  fillRule="evenodd"
                  d="m8 10.293 5.646-5.647.708.708L8 11.707 1.646 5.354l.708-.708L8 10.293Z"
                  clipRule="evenodd"
                />
              </motion.svg>
              Item B
            </div>
          </HoverFill>
          <HoverFill className="ml-12" bgClassName="rounded">
            <motion.div
              initial="expanded"
              animate={isExpanded ? 'expanded' : 'collapsed'}
              variants={variants}
              transition={{ duration: 0.25, ease: 'easeInOut' }}
            >
              <div className="flex items-center px-2 gap-2 h-8">
                <svg width="16" height="16" viewBox="0 0 16 16">
                  <path
                    fillRule="evenodd"
                    d="M3 2a1 1 0 0 1 1-1h4.707L13 5.293V14a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2Zm5 0H4v12h8V6H9a1 1 0 0 1-1-1V2Zm1 .707L11.293 5H9V2.707Z"
                    clipRule="evenodd"
                  />
                </svg>
                Item B - 1
              </div>
            </motion.div>
          </HoverFill>
          <HoverFill className="ml-12" bgClassName="rounded">
            <motion.div
              initial="expanded"
              animate={isExpanded ? 'expanded' : 'collapsed'}
              variants={variants}
              transition={{ duration: 0.25, ease: 'easeInOut' }}
            >
              <div className="flex items-center px-2 gap-2 h-8">
                <svg width="16" height="16" viewBox="0 0 16 16">
                  <path
                    fillRule="evenodd"
                    d="M3 2a1 1 0 0 1 1-1h4.707L13 5.293V14a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2Zm5 0H4v12h8V6H9a1 1 0 0 1-1-1V2Zm1 .707L11.293 5H9V2.707Z"
                    clipRule="evenodd"
                  />
                </svg>
                Item B - 2
              </div>
            </motion.div>
          </HoverFill>
          <HoverFill bgClassName="rounded">
            <div className="flex items-center px-2 gap-2 h-8">Item Two</div>
          </HoverFill>
        </div>
      </CodeBox>
    </div>
  );
};

export default Basics;
```
### 气泡，日历与列表的组合 {#popover-calendar-list-combination}

**示例：combination** — combination

```tsx
import { Calendar, HoverFill, Popover } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const convertDateToString = (
  date?: Date | '' | null,
  locale: 'zhCN' | 'enUS' = 'zhCN',
) => {
  if (!date) {
    return '';
  }
  let year = '';
  let month = '';
  let day = '';
  try {
    if (locale === 'zhCN') {
      [year, month, day] = date.toLocaleDateString('zh-Hans-CN').split('/');
    } else {
      [month, day, year] = date.toLocaleDateString('en-US').split('/');
    }
  } catch (error) {
    [month, day, year] = date.toLocaleDateString('en-US').split('/');
  }

  const addZero = (s: string) => {
    if (parseInt(s, 10) < 10) {
      return `0${s}`;
    }
    return s;
  };
  return locale === 'zhCN'
    ? `${year}-${addZero(month)}-${addZero(day)}`
    : `${addZero(month)}/${addZero(day)}/${year}`;
};

const Basic = () => {
  let thisYear = new Date().getFullYear();
  const tm = new Date().getMonth() + 1;
  const thisMonth = tm < 10 ? `0${tm}` : `${tm}`;

  const infos = [
    {
      date: new Date(`${thisYear}-${thisMonth}-23`),
      broadcasts: [
        {
          startTime: '15:03',
        },
        {
          startTime: '00:16',
          endTime: '03:46',
        },
      ],
    },
    {
      date: new Date(`${thisYear}-${thisMonth}-22`),
      broadcasts: [
        {
          startTime: '15:03',
          endTime: '18:00',
        },
        {
          startTime: '10:54',
          endTime: '11:04',
        },
      ],
    },
    {
      date: new Date(`${thisYear}-${thisMonth}-18`),
      broadcasts: [
        {
          startTime: '15:03',
          endTime: '18:00',
        },
      ],
    },
    {
      date: new Date(`${thisYear}-${thisMonth}-17`),
      broadcasts: [
        {
          startTime: '15:03',
          endTime: '18:00',
        },
      ],
    },
    {
      date: new Date(`${thisYear}-${thisMonth}-12`),
      broadcasts: [
        {
          startTime: '15:03',
          endTime: '18:00',
        },
      ],
    },
  ];

  const [value, setValue] = useState<Date | undefined>(infos[0].date);
  const [visible, setVisible] = useState(false);

  return (
    <CodeBox>
      <Popover
        popup={
          <div className="flex">
            <Calendar mode="single" selected={value} onSelect={setValue} />
            <div className="flex-1 py-1.5 border-l border-neutral-200 h-[255px] overflow-y-auto scrollbar-custom">
              {infos.map((info, index) => (
                <React.Fragment key={index}>
                  <div className="flex items-center pl-4 h-8 text-neutral-400">
                    {convertDateToString(info.date)}
                  </div>
                  {info.broadcasts?.map((info, index) => (
                    <HoverFill key={index}>
                      <div className="flex items-center pl-4 h-9 text-sm">
                        {info.endTime ? (
                          <>
                            <span className="mr-0.5">{info.startTime}</span>至
                            <span className="mx-0.5">{info.endTime}</span>的直播
                          </>
                        ) : (
                          <>
                            <span className="mr-0.5">{info.startTime}</span>
                            开始的直播
                          </>
                        )}
                        {!info.endTime && (
                          <div className="ml-2 flex items-center px-1.5 h-[22px] text-[13px] text-[#FF6146] bg-[#ff6146]/[0.12] rounded">
                            进行中
                          </div>
                        )}
                      </div>
                    </HoverFill>
                  ))}
                </React.Fragment>
              ))}
            </div>
          </div>
        }
        popupStyle={{ padding: 0 }}
        arrowed={false}
        placement="bottom"
        matchWidth
        trigger="click"
        visible={visible}
        onVisibleChange={setVisible}
      >
        <HoverFill
          bgClassName="rounded-md"
          hoverColor="#f2f2f2"
          activeColor="#ebebeb"
        >
          <div
            className={`py-3 pl-6 pr-5 rounded-md ${
              visible ? 'bg-[#ebebeb]' : ''
            }`}
          >
            <div className="mb-1 text-base leading-7 font-semibold">
              直播场次
            </div>
            <div className="flex items-center">
              <div className="flex items-center mr-4 text-base leading-7">
                <div className="mr-2">开播时间</div>
                <div className="mr-5 text-black/[0.58]">
                  2024-12-17 15:03
                </div>
                <div className="mr-2">直播时长</div>
                <div className="w-[66px] whitespace-nowrap text-black/[0.58]">
                  03:48:08
                </div>
              </div>
              <div className="flex items-center mr-4 px-2 h-6 rounded text-sm text-[#FF6146] bg-[#ff6146]/[0.12]">
                进行中
              </div>
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                <path
                  fillRule="evenodd"
                  clipRule="evenodd"
                  d="M19.0707 8.93327L18.5993 8.46186C18.339 8.20151 17.9168 8.20151 17.6565 8.46186L12.0006 14.119L6.34279 8.46186C6.08244 8.20151 5.66033 8.20151 5.39998 8.46186L4.92858 8.93327C4.66823 9.19362 4.66823 9.61573 4.92858 9.87608L11.5282 16.4757C11.7886 16.7361 12.2107 16.7361 12.471 16.4757L19.0707 9.87608C19.3311 9.61573 19.3311 9.19362 19.0707 8.93327Z"
                  fill="black"
                  fillOpacity="0.58"
                />
              </svg>
            </div>
          </div>
        </HoverFill>
      </Popover>
    </CodeBox>
  );
};

export default Basic;
```
### 作为多个导航项 {#as-multiple-nav-items}

点击左上角按钮折叠或展开：

**示例：nav** — nav

```tsx
'use client';

import { HoverFill } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basics = () => {
  const [collapsed, setCollapsed] = useState(false);
  return (
    <div>
      <CodeBox className="mt-2 p-0">
        <div className="flex-1 bg-black/[0.03]">
          <div className="flex items-center mb-4 pl-6 h-[54px]">
            <HoverFill
              bgClassName="rounded-lg"
              hoverColor="rgba(0, 0, 0, 0.05)"
              activeColor="rgba(0, 0, 0, 0.08)"
            >
              <div
                className="flex items-center justify-center size-8"
                onClick={() => {
                  setCollapsed((bool) => !bool);
                }}
              >
                <div className="relative w-[18px] h-[15px] border-2 border-black rounded-[2px]">
                  <i
                    className={`absolute top-0 left-1 w-[2px] h-full bg-black transition-all duration-[400ms] ease-[cubic-bezier(0.32,0.72,0,1)] ${
                      collapsed && '-translate-x-0.5 scale-y-[0.7]'
                    }`}
                  />
                </div>
              </div>
            </HoverFill>
            <svg className="-ml-5.5 h-[22px]" viewBox="0 0 238 22">
              <path
                d="M28.656 10.384C28.656 9.47733 28.8053 8.656 29.104 7.92C29.4027 7.17333 29.8133 6.53867 30.336 6.016C30.8693 5.49333 31.4987 5.09333 32.224 4.816C32.96 4.528 33.7653 4.384 34.64 4.384C35.5253 4.37333 36.336 4.50667 37.072 4.784C37.808 5.05067 38.4427 5.44533 38.976 5.968C39.5093 6.49067 39.9253 7.12 40.224 7.856C40.5227 8.592 40.672 9.41333 40.672 10.32C40.672 11.2053 40.5227 12.0107 40.224 12.736C39.9253 13.4613 39.5093 14.0853 38.976 14.608C38.4427 15.1307 37.808 15.5413 37.072 15.84C36.336 16.128 35.5253 16.2773 34.64 16.288C33.7653 16.288 32.96 16.1493 32.224 15.872C31.4987 15.584 30.8693 15.184 30.336 14.672C29.8133 14.1493 29.4027 13.5253 29.104 12.8C28.8053 12.0747 28.656 11.2693 28.656 10.384ZM30.768 10.256C30.768 10.864 30.8587 11.424 31.04 11.936C31.232 12.448 31.4987 12.8907 31.84 13.264C32.1813 13.6373 32.5867 13.9307 33.056 14.144C33.536 14.3573 34.0693 14.464 34.656 14.464C35.2427 14.464 35.776 14.3573 36.256 14.144C36.736 13.9307 37.1467 13.6373 37.488 13.264C37.8293 12.8907 38.0907 12.448 38.272 11.936C38.464 11.424 38.56 10.864 38.56 10.256C38.56 9.69067 38.464 9.16267 38.272 8.672C38.0907 8.18133 37.8293 7.75467 37.488 7.392C37.1467 7.01867 36.736 6.73067 36.256 6.528C35.776 6.31467 35.2427 6.208 34.656 6.208C34.0693 6.208 33.536 6.31467 33.056 6.528C32.5867 6.73067 32.1813 7.01867 31.84 7.392C31.4987 7.75467 31.232 8.18133 31.04 8.672C30.8587 9.16267 30.768 9.69067 30.768 10.256ZM42.5921 4.672H47.0561C47.8028 4.672 48.5228 4.78933 49.2161 5.024C49.9095 5.248 50.5228 5.59467 51.0561 6.064C51.5895 6.53333 52.0161 7.12533 52.3361 7.84C52.6561 8.544 52.8161 9.376 52.8161 10.336C52.8161 11.3067 52.6295 12.1493 52.2561 12.864C51.8935 13.568 51.4188 14.1547 50.8321 14.624C50.2561 15.0827 49.6108 15.4293 48.8961 15.664C48.1921 15.888 47.4988 16 46.8161 16H42.5921V4.672ZM46.1121 14.176C46.7415 14.176 47.3335 14.1067 47.8881 13.968C48.4535 13.8187 48.9441 13.5947 49.3601 13.296C49.7761 12.9867 50.1015 12.592 50.3361 12.112C50.5815 11.6213 50.7041 11.0293 50.7041 10.336C50.7041 9.65333 50.5975 9.06667 50.3841 8.576C50.1708 8.08533 49.8721 7.69067 49.4881 7.392C49.1148 7.08267 48.6668 6.85867 48.1441 6.72C47.6321 6.57067 47.0668 6.496 46.4481 6.496H44.6081V14.176H46.1121ZM62.5087 7.328C62.0928 6.88 61.6874 6.58133 61.2928 6.432C60.9088 6.28267 60.5194 6.208 60.1248 6.208C59.5381 6.208 59.0048 6.31467 58.5248 6.528C58.0554 6.73067 57.6501 7.01867 57.3088 7.392C56.9674 7.75467 56.7008 8.18133 56.5088 8.672C56.3274 9.16267 56.2368 9.69067 56.2368 10.256C56.2368 10.864 56.3274 11.424 56.5088 11.936C56.7008 12.448 56.9674 12.8907 57.3088 13.264C57.6501 13.6373 58.0554 13.9307 58.5248 14.144C59.0048 14.3573 59.5381 14.464 60.1248 14.464C60.5834 14.464 61.0261 14.3573 61.4528 14.144C61.8901 13.92 62.2954 13.568 62.6688 13.088L64.3328 14.272C63.8208 14.976 63.1968 15.488 62.4608 15.808C61.7248 16.128 60.9408 16.288 60.1088 16.288C59.2341 16.288 58.4288 16.1493 57.6927 15.872C56.9674 15.584 56.3381 15.184 55.8048 14.672C55.2821 14.1493 54.8714 13.5253 54.5728 12.8C54.2741 12.0747 54.1248 11.2693 54.1248 10.384C54.1248 9.47733 54.2741 8.656 54.5728 7.92C54.8714 7.17333 55.2821 6.53867 55.8048 6.016C56.3381 5.49333 56.9674 5.09333 57.6927 4.816C58.4288 4.528 59.2341 4.384 60.1088 4.384C60.8768 4.384 61.5861 4.52267 62.2368 4.8C62.8981 5.06667 63.5114 5.52533 64.0768 6.176L62.5087 7.328ZM70.4683 4.672H73.5403L76.5643 12.608L79.6203 4.672H82.6603V16H80.7403V6.592H80.7083L77.2683 16H75.8603L72.4203 6.592H72.3883V16H70.4683V4.672ZM84.6728 12.16C84.6728 11.552 84.7794 11.0027 84.9928 10.512C85.2168 10.0107 85.5154 9.584 85.8888 9.232C86.2621 8.88 86.7048 8.608 87.2168 8.416C87.7288 8.224 88.2728 8.128 88.8488 8.128C89.4248 8.128 89.9688 8.224 90.4808 8.416C90.9928 8.608 91.4354 8.88 91.8088 9.232C92.1821 9.584 92.4754 10.0107 92.6888 10.512C92.9128 11.0027 93.0248 11.552 93.0248 12.16C93.0248 12.768 92.9128 13.3227 92.6888 13.824C92.4754 14.3147 92.1821 14.736 91.8088 15.088C91.4354 15.44 90.9928 15.712 90.4808 15.904C89.9688 16.096 89.4248 16.192 88.8488 16.192C88.2728 16.192 87.7288 16.096 87.2168 15.904C86.7048 15.712 86.2621 15.44 85.8888 15.088C85.5154 14.736 85.2168 14.3147 84.9928 13.824C84.7794 13.3227 84.6728 12.768 84.6728 12.16ZM86.5928 12.16C86.5928 12.4587 86.6408 12.7467 86.7368 13.024C86.8434 13.3013 86.9928 13.5467 87.1848 13.76C87.3874 13.9733 87.6274 14.144 87.9048 14.272C88.1821 14.4 88.4968 14.464 88.8488 14.464C89.2008 14.464 89.5154 14.4 89.7928 14.272C90.0701 14.144 90.3048 13.9733 90.4968 13.76C90.6994 13.5467 90.8488 13.3013 90.9448 13.024C91.0514 12.7467 91.1048 12.4587 91.1048 12.16C91.1048 11.8613 91.0514 11.5733 90.9448 11.296C90.8488 11.0187 90.6994 10.7733 90.4968 10.56C90.3048 10.3467 90.0701 10.176 89.7928 10.048C89.5154 9.92 89.2008 9.856 88.8488 9.856C88.4968 9.856 88.1821 9.92 87.9048 10.048C87.6274 10.176 87.3874 10.3467 87.1848 10.56C86.9928 10.7733 86.8434 11.0187 86.7368 11.296C86.6408 11.5733 86.5928 11.8613 86.5928 12.16ZM94.8224 8.32H96.6464V9.552H96.6784C96.8597 9.168 97.137 8.83733 97.5104 8.56C97.8837 8.272 98.3904 8.128 99.0304 8.128C99.5424 8.128 99.9744 8.21333 100.326 8.384C100.689 8.55467 100.982 8.77867 101.206 9.056C101.43 9.33333 101.59 9.65333 101.686 10.016C101.782 10.3787 101.83 10.7573 101.83 11.152V16H99.9104V12.112C99.9104 11.8987 99.8997 11.664 99.8784 11.408C99.857 11.1413 99.7984 10.896 99.7024 10.672C99.617 10.4373 99.4784 10.2453 99.2864 10.096C99.0944 9.936 98.833 9.856 98.5024 9.856C98.1824 9.856 97.9104 9.90933 97.6864 10.016C97.473 10.1227 97.2917 10.2667 97.1424 10.448C97.0037 10.6293 96.9024 10.8373 96.8384 11.072C96.7744 11.3067 96.7424 11.552 96.7424 11.808V16H94.8224V8.32ZM105.546 12.832C105.61 13.408 105.834 13.856 106.218 14.176C106.602 14.496 107.066 14.656 107.61 14.656C108.09 14.656 108.49 14.56 108.81 14.368C109.141 14.1653 109.429 13.9147 109.674 13.616L111.05 14.656C110.602 15.2107 110.101 15.6053 109.546 15.84C108.991 16.0747 108.41 16.192 107.802 16.192C107.226 16.192 106.682 16.096 106.17 15.904C105.658 15.712 105.215 15.44 104.842 15.088C104.469 14.736 104.17 14.3147 103.946 13.824C103.733 13.3227 103.626 12.768 103.626 12.16C103.626 11.552 103.733 11.0027 103.946 10.512C104.17 10.0107 104.469 9.584 104.842 9.232C105.215 8.88 105.658 8.608 106.17 8.416C106.682 8.224 107.226 8.128 107.802 8.128C108.335 8.128 108.821 8.224 109.258 8.416C109.706 8.59733 110.085 8.864 110.394 9.216C110.714 9.568 110.959 10.0053 111.13 10.528C111.311 11.04 111.402 11.632 111.402 12.304V12.832H105.546ZM109.482 11.392C109.471 10.8267 109.295 10.384 108.954 10.064C108.613 9.73333 108.138 9.568 107.53 9.568C106.954 9.568 106.495 9.73333 106.154 10.064C105.823 10.3947 105.621 10.8373 105.546 11.392H109.482ZM112.301 9.952V8.32H113.885V6.096H115.805V8.32H117.917V9.952H115.805V13.312C115.805 13.696 115.875 14 116.013 14.224C116.163 14.448 116.451 14.56 116.877 14.56C117.048 14.56 117.235 14.544 117.437 14.512C117.64 14.4693 117.8 14.4053 117.917 14.32V15.936C117.715 16.032 117.464 16.096 117.165 16.128C116.877 16.1707 116.621 16.192 116.397 16.192C115.885 16.192 115.464 16.1333 115.133 16.016C114.813 15.9093 114.557 15.744 114.365 15.52C114.184 15.2853 114.056 14.9973 113.981 14.656C113.917 14.3147 113.885 13.92 113.885 13.472V9.952H112.301ZM119.464 8.32H121.384V16H119.464V8.32ZM119.192 5.712C119.192 5.40267 119.304 5.136 119.528 4.912C119.762 4.67733 120.056 4.56 120.408 4.56C120.76 4.56 121.053 4.672 121.288 4.896C121.533 5.10933 121.656 5.38133 121.656 5.712C121.656 6.04267 121.533 6.32 121.288 6.544C121.053 6.75733 120.76 6.864 120.408 6.864C120.056 6.864 119.762 6.752 119.528 6.528C119.304 6.29333 119.192 6.02133 119.192 5.712ZM123.044 14.224L127.156 9.888V9.856H123.236V8.32H129.476V10.064L125.316 14.464H129.668V16H123.044V14.224ZM136.107 14.944H136.059C135.781 15.3813 135.429 15.7013 135.003 15.904C134.576 16.096 134.107 16.192 133.595 16.192C133.243 16.192 132.896 16.144 132.555 16.048C132.224 15.952 131.925 15.808 131.659 15.616C131.403 15.424 131.195 15.184 131.035 14.896C130.875 14.608 130.795 14.272 130.795 13.888C130.795 13.472 130.869 13.12 131.019 12.832C131.168 12.5333 131.365 12.288 131.611 12.096C131.867 11.8933 132.16 11.7333 132.491 11.616C132.821 11.4987 133.163 11.4133 133.515 11.36C133.877 11.296 134.24 11.2587 134.603 11.248C134.965 11.2267 135.307 11.216 135.627 11.216H136.107V11.008C136.107 10.528 135.941 10.1707 135.611 9.936C135.28 9.69067 134.859 9.568 134.347 9.568C133.941 9.568 133.563 9.64267 133.211 9.792C132.859 9.93067 132.555 10.1227 132.299 10.368L131.291 9.36C131.717 8.92267 132.213 8.608 132.779 8.416C133.355 8.224 133.947 8.128 134.555 8.128C135.099 8.128 135.557 8.192 135.931 8.32C136.304 8.43733 136.613 8.592 136.859 8.784C137.104 8.976 137.291 9.2 137.419 9.456C137.557 9.70133 137.653 9.952 137.707 10.208C137.771 10.464 137.808 10.7147 137.819 10.96C137.829 11.1947 137.835 11.4027 137.835 11.584V16H136.107V14.944ZM135.995 12.56H135.595C135.328 12.56 135.029 12.5707 134.699 12.592C134.368 12.6133 134.053 12.6667 133.755 12.752C133.467 12.8267 133.221 12.944 133.019 13.104C132.816 13.2533 132.715 13.4667 132.715 13.744C132.715 13.9253 132.752 14.08 132.827 14.208C132.912 14.3253 133.019 14.4267 133.147 14.512C133.275 14.5973 133.419 14.6613 133.579 14.704C133.739 14.736 133.899 14.752 134.059 14.752C134.72 14.752 135.205 14.5973 135.515 14.288C135.835 13.968 135.995 13.536 135.995 12.992V12.56ZM139.005 9.952V8.32H140.589V6.096H142.509V8.32H144.621V9.952H142.509V13.312C142.509 13.696 142.578 14 142.717 14.224C142.866 14.448 143.154 14.56 143.581 14.56C143.751 14.56 143.938 14.544 144.141 14.512C144.343 14.4693 144.503 14.4053 144.621 14.32V15.936C144.418 16.032 144.167 16.096 143.869 16.128C143.581 16.1707 143.325 16.192 143.101 16.192C142.589 16.192 142.167 16.1333 141.837 16.016C141.517 15.9093 141.261 15.744 141.069 15.52C140.887 15.2853 140.759 14.9973 140.685 14.656C140.621 14.3147 140.589 13.92 140.589 13.472V9.952H139.005ZM146.167 8.32H148.087V16H146.167V8.32ZM145.895 5.712C145.895 5.40267 146.007 5.136 146.231 4.912C146.466 4.67733 146.759 4.56 147.111 4.56C147.463 4.56 147.756 4.672 147.991 4.896C148.236 5.10933 148.359 5.38133 148.359 5.712C148.359 6.04267 148.236 6.32 147.991 6.544C147.756 6.75733 147.463 6.864 147.111 6.864C146.759 6.864 146.466 6.752 146.231 6.528C146.007 6.29333 145.895 6.02133 145.895 5.712ZM149.907 12.16C149.907 11.552 150.014 11.0027 150.227 10.512C150.451 10.0107 150.75 9.584 151.123 9.232C151.496 8.88 151.939 8.608 152.451 8.416C152.963 8.224 153.507 8.128 154.083 8.128C154.659 8.128 155.203 8.224 155.715 8.416C156.227 8.608 156.67 8.88 157.043 9.232C157.416 9.584 157.71 10.0107 157.923 10.512C158.147 11.0027 158.259 11.552 158.259 12.16C158.259 12.768 158.147 13.3227 157.923 13.824C157.71 14.3147 157.416 14.736 157.043 15.088C156.67 15.44 156.227 15.712 155.715 15.904C155.203 16.096 154.659 16.192 154.083 16.192C153.507 16.192 152.963 16.096 152.451 15.904C151.939 15.712 151.496 15.44 151.123 15.088C150.75 14.736 150.451 14.3147 150.227 13.824C150.014 13.3227 149.907 12.768 149.907 12.16ZM151.827 12.16C151.827 12.4587 151.875 12.7467 151.971 13.024C152.078 13.3013 152.227 13.5467 152.419 13.76C152.622 13.9733 152.862 14.144 153.139 14.272C153.416 14.4 153.731 14.464 154.083 14.464C154.435 14.464 154.75 14.4 155.027 14.272C155.304 14.144 155.539 13.9733 155.731 13.76C155.934 13.5467 156.083 13.3013 156.179 13.024C156.286 12.7467 156.339 12.4587 156.339 12.16C156.339 11.8613 156.286 11.5733 156.179 11.296C156.083 11.0187 155.934 10.7733 155.731 10.56C155.539 10.3467 155.304 10.176 155.027 10.048C154.75 9.92 154.435 9.856 154.083 9.856C153.731 9.856 153.416 9.92 153.139 10.048C152.862 10.176 152.622 10.3467 152.419 10.56C152.227 10.7733 152.078 11.0187 151.971 11.296C151.875 11.5733 151.827 11.8613 151.827 12.16ZM160.057 8.32H161.881V9.552H161.913C162.094 9.168 162.371 8.83733 162.745 8.56C163.118 8.272 163.625 8.128 164.265 8.128C164.777 8.128 165.209 8.21333 165.561 8.384C165.923 8.55467 166.217 8.77867 166.441 9.056C166.665 9.33333 166.825 9.65333 166.921 10.016C167.017 10.3787 167.065 10.7573 167.065 11.152V16H165.145V12.112C165.145 11.8987 165.134 11.664 165.113 11.408C165.091 11.1413 165.033 10.896 164.937 10.672C164.851 10.4373 164.713 10.2453 164.521 10.096C164.329 9.936 164.067 9.856 163.737 9.856C163.417 9.856 163.145 9.90933 162.921 10.016C162.707 10.1227 162.526 10.2667 162.377 10.448C162.238 10.6293 162.137 10.8373 162.073 11.072C162.009 11.3067 161.977 11.552 161.977 11.808V16H160.057V8.32ZM174.155 4.672H177.963C178.507 4.672 179.029 4.72533 179.531 4.832C180.043 4.93867 180.491 5.12 180.875 5.376C181.259 5.62133 181.563 5.95733 181.787 6.384C182.021 6.8 182.139 7.32267 182.139 7.952C182.139 8.66667 182.016 9.24267 181.771 9.68C181.525 10.1173 181.195 10.4587 180.779 10.704C180.363 10.9387 179.877 11.0987 179.323 11.184C178.779 11.2693 178.208 11.312 177.611 11.312H176.171V16H174.155V4.672ZM177.387 9.584C177.675 9.584 177.973 9.57333 178.283 9.552C178.592 9.53067 178.875 9.46667 179.131 9.36C179.397 9.25333 179.611 9.09333 179.771 8.88C179.941 8.66667 180.027 8.368 180.027 7.984C180.027 7.632 179.952 7.35467 179.803 7.152C179.653 6.93867 179.461 6.77867 179.227 6.672C178.992 6.55467 178.731 6.48 178.443 6.448C178.155 6.416 177.877 6.4 177.611 6.4H176.171V9.584H177.387ZM183.792 3.904H185.712V16H183.792V3.904ZM192.716 14.944H192.668C192.391 15.3813 192.039 15.7013 191.612 15.904C191.185 16.096 190.716 16.192 190.204 16.192C189.852 16.192 189.505 16.144 189.164 16.048C188.833 15.952 188.535 15.808 188.268 15.616C188.012 15.424 187.804 15.184 187.644 14.896C187.484 14.608 187.404 14.272 187.404 13.888C187.404 13.472 187.479 13.12 187.628 12.832C187.777 12.5333 187.975 12.288 188.22 12.096C188.476 11.8933 188.769 11.7333 189.1 11.616C189.431 11.4987 189.772 11.4133 190.124 11.36C190.487 11.296 190.849 11.2587 191.212 11.248C191.575 11.2267 191.916 11.216 192.236 11.216H192.716V11.008C192.716 10.528 192.551 10.1707 192.22 9.936C191.889 9.69067 191.468 9.568 190.956 9.568C190.551 9.568 190.172 9.64267 189.82 9.792C189.468 9.93067 189.164 10.1227 188.908 10.368L187.9 9.36C188.327 8.92267 188.823 8.608 189.388 8.416C189.964 8.224 190.556 8.128 191.164 8.128C191.708 8.128 192.167 8.192 192.54 8.32C192.913 8.43733 193.223 8.592 193.468 8.784C193.713 8.976 193.9 9.2 194.028 9.456C194.167 9.70133 194.263 9.952 194.316 10.208C194.38 10.464 194.417 10.7147 194.428 10.96C194.439 11.1947 194.444 11.4027 194.444 11.584V16H192.716V14.944ZM192.604 12.56H192.204C191.937 12.56 191.639 12.5707 191.308 12.592C190.977 12.6133 190.663 12.6667 190.364 12.752C190.076 12.8267 189.831 12.944 189.628 13.104C189.425 13.2533 189.324 13.4667 189.324 13.744C189.324 13.9253 189.361 14.08 189.436 14.208C189.521 14.3253 189.628 14.4267 189.756 14.512C189.884 14.5973 190.028 14.6613 190.188 14.704C190.348 14.736 190.508 14.752 190.668 14.752C191.329 14.752 191.815 14.5973 192.124 14.288C192.444 13.968 192.604 13.536 192.604 12.992V12.56ZM195.614 9.952V8.32H197.198V6.096H199.118V8.32H201.23V9.952H199.118V13.312C199.118 13.696 199.187 14 199.326 14.224C199.475 14.448 199.763 14.56 200.19 14.56C200.361 14.56 200.547 14.544 200.75 14.512C200.953 14.4693 201.113 14.4053 201.23 14.32V15.936C201.027 16.032 200.777 16.096 200.478 16.128C200.19 16.1707 199.934 16.192 199.71 16.192C199.198 16.192 198.777 16.1333 198.446 16.016C198.126 15.9093 197.87 15.744 197.678 15.52C197.497 15.2853 197.369 14.9973 197.294 14.656C197.23 14.3147 197.198 13.92 197.198 13.472V9.952H195.614ZM203.432 9.952H201.848V8.32H203.432V7.232C203.432 6.69867 203.47 6.21867 203.544 5.792C203.619 5.35467 203.758 4.98133 203.96 4.672C204.174 4.36267 204.467 4.128 204.84 3.968C205.214 3.79733 205.699 3.712 206.296 3.712C206.734 3.712 207.139 3.74933 207.512 3.824L207.384 5.456C207.246 5.424 207.112 5.39733 206.984 5.376C206.856 5.35467 206.723 5.344 206.584 5.344C206.318 5.344 206.104 5.38667 205.944 5.472C205.784 5.55733 205.656 5.67467 205.56 5.824C205.475 5.96267 205.416 6.128 205.384 6.32C205.363 6.512 205.352 6.71467 205.352 6.928V8.32H207.128V9.952H205.352V16H203.432V9.952ZM207.985 12.16C207.985 11.552 208.092 11.0027 208.305 10.512C208.529 10.0107 208.828 9.584 209.201 9.232C209.575 8.88 210.017 8.608 210.529 8.416C211.041 8.224 211.585 8.128 212.161 8.128C212.737 8.128 213.281 8.224 213.793 8.416C214.305 8.608 214.748 8.88 215.121 9.232C215.495 9.584 215.788 10.0107 216.001 10.512C216.225 11.0027 216.337 11.552 216.337 12.16C216.337 12.768 216.225 13.3227 216.001 13.824C215.788 14.3147 215.495 14.736 215.121 15.088C214.748 15.44 214.305 15.712 213.793 15.904C213.281 16.096 212.737 16.192 212.161 16.192C211.585 16.192 211.041 16.096 210.529 15.904C210.017 15.712 209.575 15.44 209.201 15.088C208.828 14.736 208.529 14.3147 208.305 13.824C208.092 13.3227 207.985 12.768 207.985 12.16ZM209.905 12.16C209.905 12.4587 209.953 12.7467 210.049 13.024C210.156 13.3013 210.305 13.5467 210.497 13.76C210.7 13.9733 210.94 14.144 211.217 14.272C211.495 14.4 211.809 14.464 212.161 14.464C212.513 14.464 212.828 14.4 213.105 14.272C213.383 14.144 213.617 13.9733 213.809 13.76C214.012 13.5467 214.161 13.3013 214.257 13.024C214.364 12.7467 214.417 12.4587 214.417 12.16C214.417 11.8613 214.364 11.5733 214.257 11.296C214.161 11.0187 214.012 10.7733 213.809 10.56C213.617 10.3467 213.383 10.176 213.105 10.048C212.828 9.92 212.513 9.856 212.161 9.856C211.809 9.856 211.495 9.92 211.217 10.048C210.94 10.176 210.7 10.3467 210.497 10.56C210.305 10.7733 210.156 11.0187 210.049 11.296C209.953 11.5733 209.905 11.8613 209.905 12.16ZM218.135 8.32H220.055V9.536H220.087C220.3 9.088 220.604 8.74133 220.999 8.496C221.394 8.25067 221.847 8.128 222.359 8.128C222.476 8.128 222.588 8.13867 222.695 8.16C222.812 8.18133 222.93 8.208 223.047 8.24V10.096C222.887 10.0533 222.727 10.0213 222.567 10C222.418 9.968 222.268 9.952 222.119 9.952C221.671 9.952 221.308 10.0373 221.031 10.208C220.764 10.368 220.556 10.5547 220.407 10.768C220.268 10.9813 220.172 11.1947 220.119 11.408C220.076 11.6213 220.055 11.7813 220.055 11.888V16H218.135V8.32ZM224.555 8.32H226.379V9.52H226.411C226.582 9.15733 226.854 8.83733 227.227 8.56C227.611 8.272 228.123 8.128 228.763 8.128C229.968 8.128 230.768 8.60267 231.163 9.552C231.44 9.06133 231.787 8.704 232.203 8.48C232.619 8.24533 233.115 8.128 233.691 8.128C234.203 8.128 234.635 8.21333 234.987 8.384C235.339 8.55467 235.622 8.78933 235.835 9.088C236.059 9.38667 236.219 9.73867 236.315 10.144C236.411 10.5387 236.459 10.9653 236.459 11.424V16H234.539V11.648C234.539 11.4133 234.518 11.1893 234.475 10.976C234.432 10.752 234.358 10.56 234.251 10.4C234.144 10.2293 234 10.096 233.819 10C233.638 9.904 233.403 9.856 233.115 9.856C232.816 9.856 232.56 9.91467 232.347 10.032C232.144 10.1387 231.974 10.288 231.835 10.48C231.707 10.6613 231.611 10.8747 231.547 11.12C231.494 11.3547 231.467 11.5947 231.467 11.84V16H229.547V11.424C229.547 10.944 229.446 10.5653 229.243 10.288C229.04 10 228.704 9.856 228.235 9.856C227.915 9.856 227.643 9.90933 227.419 10.016C227.206 10.1227 227.024 10.2667 226.875 10.448C226.736 10.6293 226.635 10.8373 226.571 11.072C226.507 11.3067 226.475 11.552 226.475 11.808V16H224.555V8.32Z"
                fill="black"
                fillOpacity="0.96"
              />
            </svg>
          </div>
          <div className="flex text-base text-black/60">
            <div
              className={`flex flex-col gap-3 ml-5 mr-14 transition-all duration-[400ms] ease-[cubic-bezier(0.32,0.72,0,1)] ${
                collapsed ? 'w-10' : 'w-[186px]'
              }`}
            >
              <HoverFill
                bgClassName="rounded-lg"
                hoverColor="rgba(0, 0, 0, 0.05)"
                activeColor="rgba(0, 0, 0, 0.08)"
              >
                <div className="relative flex items-center gap-2 h-10 overflow-hidden">
                  <svg
                    viewBox="0 0 20 20"
                    className={`absolute left-4 top-2.5 size-5 transition-all duration-[400ms] ease-[cubic-bezier(0.32,0.72,0,1)] ${
                      collapsed && '-translate-x-1.5'
                    }`}
                  >
                    <path
                      fillRule="evenodd"
                      clipRule="evenodd"
                      d="M9.41104 2.60111C9.73648 2.27568 10.2641 2.27568 10.5895 2.60111L15.8337 7.84523V15.8333C15.8337 16.2936 15.4606 16.6667 15.0003 16.6667H11.667V12.2917C11.667 11.9465 11.3872 11.6667 11.042 11.6667H8.95867C8.61349 11.6667 8.33367 11.9465 8.33367 12.2917V16.6667H5.00034C4.5401 16.6667 4.167 16.2936 4.167 15.8333V7.84515L9.41104 2.60111ZM2.50034 9.51182L2.28149 9.73066C2.03741 9.97474 1.64169 9.97474 1.39761 9.73066L1.10298 9.43603C0.858902 9.19195 0.858902 8.79623 1.10298 8.55215L8.23253 1.4226C9.20884 0.446291 10.7917 0.446291 11.7681 1.4226L18.4809 8.13548C18.725 8.37956 18.725 8.77529 18.4809 9.01937L18.1863 9.31399C18.0009 9.49945 17.7278 9.54399 17.5003 9.44762V15.8333C17.5003 17.2141 16.381 18.3333 15.0003 18.3333H11.042H8.95867H5.00034C3.61962 18.3333 2.50034 17.2141 2.50034 15.8333V9.51182Z"
                      fill="currentColor"
                    />
                  </svg>
                  <div
                    className={`absolute left-11 transition-all duration-[400ms] ease-[cubic-bezier(0.32,0.72,0,1)] ${
                      collapsed && 'opacity-0 -translate-x-1.5'
                    }`}
                  >
                    Home
                  </div>
                </div>
              </HoverFill>
              <HoverFill
                bgClassName="rounded-lg"
                hoverColor="rgba(0, 0, 0, 0.05)"
                activeColor="rgba(0, 0, 0, 0.08)"
              >
                <div className="relative flex items-center gap-2 h-10 overflow-hidden">
                  <svg
                    viewBox="0 0 20 20"
                    className={`absolute left-4 top-2.5 size-5 transition-all duration-[400ms] ease-[cubic-bezier(0.32,0.72,0,1)] ${
                      collapsed && '-translate-x-1.5'
                    }`}
                    fill="none"
                  >
                    <rect
                      x="2.50033"
                      y="2.50002"
                      width="5.83333"
                      height="5.83333"
                      rx="0.833333"
                      stroke="currentColor"
                      strokeWidth="1.66667"
                    />
                    <rect
                      x="11.6663"
                      y="2.50002"
                      width="5.83333"
                      height="5.83333"
                      rx="0.833333"
                      stroke="currentColor"
                      strokeWidth="1.66667"
                    />
                    <rect
                      x="2.50033"
                      y="11.6666"
                      width="5.83333"
                      height="5.83333"
                      rx="0.833333"
                      stroke="currentColor"
                      strokeWidth="1.66667"
                    />
                    <rect
                      x="11.6663"
                      y="11.6666"
                      width="5.83333"
                      height="5.83333"
                      rx="0.833333"
                      stroke="currentColor"
                      strokeWidth="1.66667"
                    />
                  </svg>
                  <div
                    className={`absolute left-11 transition-all duration-[400ms] ease-[cubic-bezier(0.32,0.72,0,1)] ${
                      collapsed && 'opacity-0 -translate-x-1.5'
                    }`}
                  >
                    Apps
                  </div>
                </div>
              </HoverFill>
              <HoverFill
                bgClassName="rounded-lg"
                hoverColor="rgba(0, 0, 0, 0.05)"
                activeColor="rgba(0, 0, 0, 0.08)"
              >
                <div className="relative flex items-center gap-2 h-10 overflow-hidden">
                  <svg
                    viewBox="0 0 20 20"
                    className={`absolute left-4 top-2.5 size-5 transition-all duration-[400ms] ease-[cubic-bezier(0.32,0.72,0,1)] ${
                      collapsed && '-translate-x-1.5'
                    }`}
                    fill="none"
                  >
                    <path
                      fillRule="evenodd"
                      clipRule="evenodd"
                      d="M4.16699 3.33335H15.8337C16.2939 3.33335 16.667 3.70645 16.667 4.16669V15.8334C16.667 16.2936 16.2939 16.6667 15.8337 16.6667H4.16699C3.70675 16.6667 3.33366 16.2936 3.33366 15.8334V4.16669C3.33366 3.70645 3.70675 3.33335 4.16699 3.33335ZM1.66699 4.16669C1.66699 2.78597 2.78628 1.66669 4.16699 1.66669H15.8337C17.2144 1.66669 18.3337 2.78598 18.3337 4.16669V15.8334C18.3337 17.2141 17.2144 18.3334 15.8337 18.3334H4.16699C2.78628 18.3334 1.66699 17.2141 1.66699 15.8334V4.16669ZM11.0192 7.64747C11.0192 8.10771 11.3923 8.48081 11.8525 8.48081H12.3365L10.4059 10.5768L9.20229 9.23946C8.67451 8.65303 7.75321 8.65859 7.23255 9.25135L4.44258 12.4276C4.13885 12.7734 4.17294 13.2999 4.51872 13.6037C4.86451 13.9074 5.39104 13.8733 5.69477 13.5275L8.22587 10.646L9.42337 11.9765C9.94285 12.5537 10.8462 12.5589 11.3723 11.9877L13.3336 9.8584V9.96184C13.3336 10.4221 13.7066 10.7952 14.1669 10.7952C14.6271 10.7952 15.0002 10.4221 15.0002 9.96184V7.85735C15.0002 7.2812 14.5332 6.81414 13.957 6.81414H11.8525C11.3923 6.81414 11.0192 7.18724 11.0192 7.64747Z"
                      fill="currentColor"
                    />
                  </svg>
                  <div
                    className={`absolute left-11 transition-all duration-[400ms] ease-[cubic-bezier(0.32,0.72,0,1)] ${
                      collapsed && 'opacity-0 -translate-x-1.5'
                    }`}
                  >
                    Performance
                  </div>
                </div>
              </HoverFill>
              <HoverFill
                bgClassName="rounded-lg"
                hoverColor="rgba(0, 0, 0, 0.05)"
                activeColor="rgba(0, 0, 0, 0.08)"
              >
                <div className="relative flex items-center gap-2 h-10 overflow-hidden">
                  <svg
                    viewBox="0 0 20 20"
                    className={`absolute left-4 top-2.5 size-5 transition-all duration-[400ms] ease-[cubic-bezier(0.32,0.72,0,1)] ${
                      collapsed && '-translate-x-1.5'
                    }`}
                    fill="currentColor"
                  >
                    <g clipPath="url(#clip0_966_1012)">
                      <g clipPath="url(#clip1_966_1012)">
                        <path d="M10 0.625C15.1777 0.625 19.375 4.82233 19.375 10C19.375 12.4979 18.3953 14.765 16.8027 16.4453C17.2261 17.3707 17.4638 18.3969 17.4639 19.4785L17.4531 19.6377C17.0074 22.8588 2.99659 22.8588 2.55078 19.6377L2.54004 19.4785C2.54009 18.3985 2.77705 17.3736 3.19922 16.4492C1.60493 14.7686 0.625 12.4994 0.625 10C0.625 4.82233 4.82233 0.625 10 0.625ZM15.4736 17.6084C13.9332 18.7186 12.0438 19.375 10 19.375C7.95666 19.375 6.06759 18.7191 4.52734 17.6094C4.34022 18.1408 4.22992 18.707 4.21094 19.2949L4.21289 19.2969C4.39306 19.439 4.75767 19.6315 5.36035 19.8164C6.54877 20.1809 8.23677 20.3867 10.002 20.3867C11.7669 20.3867 13.4542 20.1808 14.6426 19.8164C15.2451 19.6316 15.6098 19.439 15.79 19.2969L15.791 19.2949C15.772 18.7066 15.6609 18.1402 15.4736 17.6084ZM10.002 13.7715C8.06839 13.7715 6.3677 14.7004 5.31738 16.1211C6.61555 17.1157 8.2382 17.708 10 17.708C11.7623 17.708 13.3853 17.1152 14.6836 16.1201C13.6337 14.7002 11.9348 13.7715 10.002 13.7715ZM10 2.29199C5.74281 2.29199 2.29199 5.74281 2.29199 10C2.29199 11.8909 2.97369 13.6219 4.10352 14.9629C4.95765 13.8749 6.11224 13.0283 7.44531 12.5479C6.39023 11.7999 5.68213 10.5942 5.6123 9.21973L5.60645 8.99512C5.60672 6.59156 7.55541 4.64279 9.95898 4.64258L10.1836 4.64844C12.483 4.76525 14.3113 6.66672 14.3115 8.99512L14.3057 9.21973C14.2365 10.5819 13.5413 11.7789 12.502 12.5283C13.8575 13.0045 15.0315 13.8583 15.8975 14.96C17.0262 13.6193 17.708 11.8898 17.708 10C17.708 5.74281 14.2572 2.29199 10 2.29199ZM9.95898 6.30957C8.47589 6.30978 7.27371 7.51203 7.27344 8.99512C7.27344 10.4784 8.47572 11.6814 9.95898 11.6816C11.4424 11.6816 12.6455 10.4786 12.6455 8.99512C12.6452 7.51191 11.4423 6.30957 9.95898 6.30957Z"></path>
                      </g>
                    </g>
                    <defs>
                      <clipPath id="clip0_966_1012">
                        <rect width="20" height="20" fill="white"></rect>
                      </clipPath>
                      <clipPath id="clip1_966_1012">
                        <rect
                          x="0.625"
                          y="0.625"
                          width="18.75"
                          height="18.75"
                          rx="9.375"
                          fill="white"
                        ></rect>
                      </clipPath>
                    </defs>
                  </svg>
                  <div
                    className={`absolute left-11 transition-all duration-[400ms] ease-[cubic-bezier(0.32,0.72,0,1)] ${
                      collapsed && 'opacity-0 -translate-x-1.5'
                    }`}
                  >
                    Members
                  </div>
                </div>
              </HoverFill>
            </div>
            <div className="flex-1 mr-4 mb-4">
              <div className="mb-6 text-[36px] font-semibold text-black/[0.96]">
                Apps
              </div>
              <div className="h-[300px] bg-white rounded-[12px]" />
            </div>
          </div>
        </div>
      </CodeBox>
    </div>
  );
};

export default Basics;
```
## 设计语言扩展 {#design-language-extension}

`HoverFill` 共享了多个轻量元素的背景，以上的例子展示了它的通用性。

我们还可以在这之上继续扩展。不仅仅是背景，这样的行为还可以应用到弹出层的共享上，特别是当两个弹出层存在重叠时。在"流畅"、"连续"的感受之下，我们开始接近"跳跃"语言的本质 —— **共享，是为了减少层级数量，或让那些本就成组的元素更像一组**。

### 多个工具提示 {#multiple-tooltips}

当相近的、成组的元素都拥有 `Tooltip` 时，可以考虑使用 `Tooltip.Group` 使它们共享。

在设计上，这也是 `HoverFill` 的核心理念。多个互相重叠当然也不是什么大问题，它只是让过渡变得"脏"了一点，让层级、信息重叠。

因此你很可能不需要使用 `Tooltip.Group`，只在多个元素是相近、成组的场景下使用即可：

**示例：tooltips** — tooltips

```tsx
import { HoverFill, Tooltip } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basic = () => {
  const [visible, setVisible] = useState(false);
  const [hoverIndex, setHoverIndex] = useState<number>(0);
  const lastHoverIndex = useRef(hoverIndex);
  const hoverTimer = useRef(0);

  const operations = [
    {
      icon: (
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
          <rect
            x="2"
            y="13.6665"
            width="12"
            height="1.33333"
            rx="0.5"
            fill="#0A0A0A"
            fillOpacity="0.84"
          />
          <path
            d="M9.5 3.5L11.5 5.5"
            stroke="#0A0A0A"
            strokeOpacity="0.84"
            strokeWidth="1.33333"
            strokeLinecap="square"
          />
          <path
            fillRule="evenodd"
            clipRule="evenodd"
            d="M10.3143 1.87953C10.6779 1.51594 11.2674 1.51594 11.631 1.87953L12.9477 3.19619C13.3112 3.55978 13.3112 4.14927 12.9477 4.51286L5.9753 11.4852L2.72146 12.3329C2.58386 12.3687 2.45848 12.2433 2.49433 12.1057L3.34197 8.85188L10.3143 1.87953Z"
            stroke="#0A0A0A"
            strokeOpacity="0.84"
            strokeWidth="1.33333"
          />
        </svg>
      ),
      tip: 'Edit ad unit',
      offset: -26,
    },
    {
      icon: (
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
          <path
            d="M3 4.66699H10.333C10.5171 4.66699 10.667 4.8159 10.667 5V13.667C10.6668 13.8509 10.517 14 10.333 14H3C2.81601 14 2.66717 13.8509 2.66699 13.667V5C2.66699 4.8159 2.81591 4.66699 3 4.66699Z"
            stroke="#0A0A0A"
            strokeOpacity="0.84"
            strokeWidth="1.33333"
          />
          <rect
            x="4.66797"
            y="7.3335"
            width="4"
            height="1.33333"
            rx="0.25"
            fill="#0A0A0A"
            fillOpacity="0.84"
          />
          <rect
            x="4.66797"
            y="10"
            width="4"
            height="1.33333"
            rx="0.25"
            fill="#0A0A0A"
            fillOpacity="0.84"
          />
          <path
            d="M13.0996 1.33838C13.6037 1.38972 13.9971 1.81582 13.9971 2.3335V11.0005L13.9922 11.1021C13.9445 11.5727 13.5702 11.9467 13.0996 11.9946L12.9971 12.0005H11.3301V10.6665H12.6641V2.6665H5.99707V4.00049H4.66406V2.3335C4.66406 1.81582 5.05739 1.38971 5.56152 1.33838L5.66406 1.3335H12.9971L13.0996 1.33838Z"
            fill="#0A0A0A"
            fillOpacity="0.84"
          />
        </svg>
      ),
      tip: 'Copy ad unit',
      offset: 13,
    },
    {
      icon: (
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
          <circle
            cx="8"
            cy="8"
            r="6.33333"
            stroke="#0A0A0A"
            strokeOpacity="0.84"
            strokeWidth="1.33333"
          />
          <path
            fillRule="evenodd"
            clipRule="evenodd"
            d="M6.16536 5.3335C6.44151 5.3335 6.66536 5.55735 6.66536 5.8335V10.1668C6.66536 10.443 6.44151 10.6668 6.16536 10.6668H5.83203C5.55589 10.6668 5.33203 10.443 5.33203 10.1668V5.8335C5.33203 5.55735 5.55589 5.3335 5.83203 5.3335H6.16536Z"
            fill="#0A0A0A"
            fillOpacity="0.84"
          />
          <path
            fillRule="evenodd"
            clipRule="evenodd"
            d="M10.1654 5.3335C10.4415 5.3335 10.6654 5.55735 10.6654 5.8335V10.1668C10.6654 10.443 10.4415 10.6668 10.1654 10.6668H9.83203C9.55589 10.6668 9.33203 10.443 9.33203 10.1668V5.8335C9.33203 5.55735 9.55589 5.3335 9.83203 5.3335H10.1654Z"
            fill="#0A0A0A"
            fillOpacity="0.84"
          />
        </svg>
      ),
      tip: 'Pause ad unit',
      offset: 54,
    },
    {
      icon: (
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
          <rect
            x="2"
            y="3.3335"
            width="12"
            height="1.33333"
            rx="0.5"
            fill="#0A0A0A"
            fillOpacity="0.84"
          />
          <rect
            x="4.66797"
            y="1"
            width="6.66667"
            height="1.33333"
            rx="0.5"
            fill="#0A0A0A"
            fillOpacity="0.84"
          />
          <rect
            x="6"
            y="6"
            width="1.33333"
            height="5.33333"
            rx="0.5"
            fill="#0A0A0A"
            fillOpacity="0.84"
          />
          <rect
            x="8.66797"
            y="6"
            width="1.33333"
            height="5.33333"
            rx="0.5"
            fill="#0A0A0A"
            fillOpacity="0.84"
          />
          <path
            d="M13 13.6665C13 14.4028 12.4032 15.0003 11.667 15.0005H4.33301C3.64287 15.0003 3.07521 14.4754 3.00684 13.8032L3 13.6665H13Z"
            fill="#0A0A0A"
            fillOpacity="0.84"
          />
          <path
            d="M3 6.1665C3 5.89036 3.22386 5.6665 3.5 5.6665H3.83333C4.10948 5.6665 4.33333 5.89036 4.33333 6.1665V13.6665C4.33333 14.0347 4.03486 14.3332 3.66667 14.3332C3.29848 14.3332 3 14.0347 3 13.6665V6.1665Z"
            fill="#0A0A0A"
            fillOpacity="0.84"
          />
          <path
            d="M11.668 6.1665C11.668 5.89036 11.8918 5.6665 12.168 5.6665H12.5013C12.7774 5.6665 13.0013 5.89036 13.0013 6.1665V13.6665C13.0013 14.0347 12.7028 14.3332 12.3346 14.3332C11.9664 14.3332 11.668 14.0347 11.668 13.6665V6.1665Z"
            fill="#0A0A0A"
            fillOpacity="0.84"
          />
        </svg>
      ),
      tip: 'Delete ad unit',
      offset: 98,
    },
  ];

  const handleMouseEnter = (index: number) => {
    clearTimeout(hoverTimer.current);
    setHoverIndex(index);
    setVisible(true);
  };

  const handleMouseLeave = () => {
    clearTimeout(hoverTimer.current);

    hoverTimer.current = window.setTimeout(() => {
      setVisible(false);
    }, 200);
  };

  useEffect(() => {
    if (lastHoverIndex.current !== hoverIndex) {
      lastHoverIndex.current = hoverIndex;
    }
  }, [hoverIndex]);

  useEffect(() => {
    return () => {
      clearTimeout(hoverTimer.current);
    };
  }, []);

  return (
    <div>
      <CodeBox>
        <Tooltip
          visible={visible}
          arrowed={false}
          placement="bottomLeft"
          popup={operations[hoverIndex].tip}
          popupStyle={{
            padding: '4px 8px',
            transform: `translate3d(${operations[hoverIndex].offset}px, 0, 0)`,
          }}
        >
          <div className="flex gap-3">
            {operations.map((operation, index) => (
              <HoverFill
                bgClassName="rounded-lg"
                onMouseEnter={() => {
                  handleMouseEnter(index);
                }}
                onMouseLeave={handleMouseLeave}
                key={index}
              >
                <div className="flex items-center justify-center size-8">
                  {operation.icon}
                </div>
              </HoverFill>
            ))}
          </div>
        </Tooltip>
      </CodeBox>
      <div className="flex justify-between items-center mb-6 pb-6 dotted-bottom" />
    </div>
  );
};

export default Basic;
```

**示例：slider** — slider

```tsx
'use client';

import { Slider } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';

const Basics = () => {
  const [value, setValue] = useState<[number, number]>([22, 26]);

  return (
    <div>
      <CodeBox>
        <Slider
          tooltipVisible
          range
          unit="岁"
          className="flex-1"
          value={value}
          onChange={setValue}
          min={18}
          max={100}
        />
      </CodeBox>
      <CodeBlock>{`import { Slider } from "one-design-next";

const [value, setValue] = useState<[number, number]>([22, 26]);

<Slider
  range
  unit="岁"
  className="flex-1"
  value={value}
  onChange={setValue}
  min={18}
  max={100}
/>`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
### 多个气泡提示 {#multiple-popovers}

在上面 `Tooltip` 的例子中，我们改变的是偏移量。在下面 `Popover` 的例子中，我们还可以不改偏移量，而是改箭头的位置：

**示例：merged-vercel** — merged-vercel

```tsx
'use client';

import { HoverFill, Popover } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basics = () => {
  const [visible, setVisible] = useState(false);
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);
  const lastHoverIndex = useRef(hoverIndex);
  const [lastValidHoverIndex, setLastValidHoverIndex] = useState<
    number | undefined
  >(undefined);
  const hoverTimer = useRef(0);
  const popupRef = useRef<HTMLDivElement>(null);

  // demo 我就直接写定尺寸了
  const menus = [
    {
      label: 'Products',
      img: 'https://wxa.wxs.qq.com/wxad-design/yijie/vercel-menu-0.webp',
      width: 744,
      height: 290,
    },
    {
      label: 'Solutions',
      img: 'https://wxa.wxs.qq.com/wxad-design/yijie/vercel-menu-1.webp',
      width: 496,
      height: 344,
    },
  ];

  const handleMouseEnter = (index: number) => {
    clearTimeout(hoverTimer.current);
    setHoverIndex(index);
    setLastValidHoverIndex(index);
    setVisible(true);
  };

  const handleMouseLeave = () => {
    clearTimeout(hoverTimer.current);

    hoverTimer.current = window.setTimeout(() => {
      setHoverIndex(null);
      setVisible(false);
    }, 200);
  };

  useEffect(() => {
    return () => {
      clearTimeout(hoverTimer.current);
    };
  }, []);

  useEffect(() => {
    if (popupRef.current) {
      popupRef.current.style.transition =
        lastHoverIndex.current === null ? 'none' : 'all 200ms ease-in-out';
    }

    if (lastHoverIndex.current !== hoverIndex) {
      lastHoverIndex.current = hoverIndex;
    }
  }, [hoverIndex]);

  return (
    <div>
      <CodeBox className="p-0 h-16">
        <div className="flex-1 h-full">
          <div className="flex items-center px-6 h-full">
            <svg className="mr-8 h-[18px]" viewBox="0 0 262 52" fill="none">
              <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M59.8 52L29.9 0L0 52H59.8ZM89.9574 49.6328L114.945 2.36365H104.137L86.8999 36.6921L69.6628 2.36365H58.8545L83.8423 49.6328H89.9574ZM260.248 2.36365V49.6329H251.3V2.36365H260.248ZM210.441 31.99C210.441 28.3062 211.21 25.0661 212.747 22.2699C214.285 19.4737 216.429 17.321 219.179 15.812C221.928 14.3029 225.144 13.5484 228.826 13.5484C232.088 13.5484 235.024 14.2585 237.634 15.6788C240.244 17.0991 242.317 19.2074 243.855 22.0036C245.393 24.7998 246.185 28.2174 246.232 32.2564V34.3202H219.878C220.064 37.2496 220.926 39.5576 222.464 41.2442C224.049 42.8864 226.169 43.7075 228.826 43.7075C230.503 43.7075 232.041 43.2637 233.439 42.376C234.838 41.4883 235.886 40.2899 236.585 38.7808L245.743 39.4466C244.624 42.7754 242.527 45.4385 239.451 47.4358C236.375 49.4331 232.834 50.4317 228.826 50.4317C225.144 50.4317 221.928 49.6772 219.179 48.1681C216.429 46.6591 214.285 44.5064 212.747 41.7102C211.21 38.914 210.441 35.6739 210.441 31.99ZM237.005 28.6612C236.678 25.7762 235.77 23.668 234.278 22.3365C232.787 20.9606 230.969 20.2726 228.826 20.2726C226.356 20.2726 224.352 21.0049 222.814 22.4696C221.276 23.9343 220.321 25.9982 219.948 28.6612H237.005ZM195.345 22.3365C196.836 23.5348 197.768 25.1993 198.141 27.3297L207.369 26.8637C207.043 24.1562 206.087 21.8039 204.503 19.8066C202.918 17.8093 200.868 16.278 198.351 15.2128C195.881 14.1032 193.155 13.5484 190.172 13.5484C186.49 13.5484 183.275 14.3029 180.525 15.812C177.775 17.321 175.632 19.4737 174.094 22.2699C172.556 25.0661 171.787 28.3062 171.787 31.99C171.787 35.6739 172.556 38.914 174.094 41.7102C175.632 44.5064 177.775 46.6591 180.525 48.1681C183.275 49.6772 186.49 50.4317 190.172 50.4317C193.248 50.4317 196.044 49.8769 198.561 48.7673C201.077 47.6133 203.128 45.9933 204.712 43.9072C206.297 41.8212 207.252 39.38 207.578 36.5838L198.281 36.1844C197.955 38.5367 197.046 40.3565 195.555 41.6436C194.063 42.8864 192.269 43.5078 190.172 43.5078C187.283 43.5078 185.046 42.5091 183.461 40.5118C181.877 38.5145 181.084 35.6739 181.084 31.99C181.084 28.3062 181.877 25.4656 183.461 23.4683C185.046 21.471 187.283 20.4723 190.172 20.4723C192.176 20.4723 193.9 21.0937 195.345 22.3365ZM149.953 14.3457H158.28L158.52 21.137C159.111 19.2146 159.933 17.7218 160.986 16.6585C162.512 15.1166 164.64 14.3457 167.369 14.3457H170.769V21.6146H167.3C165.357 21.6146 163.761 21.8789 162.512 22.4075C161.309 22.9362 160.384 23.7732 159.737 24.9186C159.135 26.064 158.835 27.5178 158.835 29.2799V49.6328H149.953V14.3457ZM111.546 22.2699C110.008 25.0661 109.239 28.3062 109.239 31.99C109.239 35.6739 110.008 38.914 111.546 41.7102C113.084 44.5064 115.228 46.6591 117.977 48.1681C120.727 49.6772 123.942 50.4317 127.624 50.4317C131.632 50.4317 135.174 49.4331 138.25 47.4358C141.325 45.4385 143.423 42.7754 144.541 39.4466L135.384 38.7808C134.684 40.2899 133.636 41.4883 132.238 42.376C130.84 43.2637 129.302 43.7075 127.624 43.7075C124.968 43.7075 122.847 42.8864 121.263 41.2442C119.725 39.5576 118.863 37.2496 118.676 34.3202H145.03V32.2564C144.984 28.2174 144.192 24.7998 142.654 22.0036C141.116 19.2074 139.042 17.0991 136.432 15.6788C133.822 14.2585 130.886 13.5484 127.624 13.5484C123.942 13.5484 120.727 14.3029 117.977 15.812C115.228 17.321 113.084 19.4737 111.546 22.2699ZM133.077 22.3365C134.568 23.668 135.477 25.7762 135.803 28.6612H118.746C119.119 25.9982 120.074 23.9343 121.612 22.4696C123.15 21.0049 125.154 20.2726 127.624 20.2726C129.768 20.2726 131.585 20.9606 133.077 22.3365Z"
                fill="black"
              />
            </svg>
            <Popover
              visible={visible}
              offset={{
                crossAxis: -120,
              }}
              arrowOffset={{
                x: lastValidHoverIndex === 0 ? -48 : 48,
              }}
              placement="bottomLeft"
              shift={false}
              flip={false}
              autoPlacements={[]}
              popupStyle={{ maxWidth: 'initial', padding: '8px' }}
              popup={
                <div
                  className="relative transition-all duration-200 overflow-hidden"
                  style={{
                    width:
                      lastValidHoverIndex !== undefined
                        ? menus[lastValidHoverIndex].width
                        : 0,
                    height:
                      lastValidHoverIndex !== undefined
                        ? menus[lastValidHoverIndex].height
                        : 0,
                  }}
                  ref={popupRef}
                  onMouseEnter={() => {
                    clearTimeout(hoverTimer.current);
                  }}
                  onMouseLeave={handleMouseLeave}
                >
                  <img
                    className={`absolute top-0 left-0 transition-all duration-200 ${
                      lastValidHoverIndex === 0
                        ? 'opacity-100'
                        : 'opacity-0 -translate-x-12'
                    }`}
                    style={{
                      maxWidth: menus[0].width,
                      width: menus[0].width,
                      height: menus[0].height,
                    }}
                    src={menus[0].img}
                  />
                  <img
                    className={`absolute top-0 left-0 transition-all duration-200 ${
                      lastValidHoverIndex === 1
                        ? 'opacity-100'
                        : 'opacity-0 translate-x-12'
                    }`}
                    style={{
                      maxWidth: menus[1].width,
                      width: menus[1].width,
                      height: menus[1].height,
                    }}
                    src={menus[1].img}
                  />
                </div>
              }
            >
              <div className="flex items-center">
                {menus.map((menu, index) => (
                  <HoverFill bgClassName="rounded-[30px]" key={index}>
                    <div
                      className="group flex items-center justify-center gap-1 px-2 h-[30px] text-sm transition-all duration-200 text-neutral-500 hover:text-neutral-900"
                      onMouseEnter={() => {
                        handleMouseEnter(index);
                      }}
                      onMouseLeave={handleMouseLeave}
                    >
                      {menu.label}
                      <svg
                        className="size-4 transition-all duration-200 group-hover:rotate-180"
                        viewBox="0 0 16 16"
                      >
                        <path
                          fillRule="evenodd"
                          clipRule="evenodd"
                          d="M12.0607 6.74999L11.5303 7.28032L8.7071 10.1035C8.31657 10.4941 7.68341 10.4941 7.29288 10.1035L4.46966 7.28032L3.93933 6.74999L4.99999 5.68933L5.53032 6.21966L7.99999 8.68933L10.4697 6.21966L11 5.68933L12.0607 6.74999Z"
                          fill="currentColor"
                        />
                      </svg>
                    </div>
                  </HoverFill>
                ))}
              </div>
            </Popover>
          </div>
        </div>
      </CodeBox>
      <div className="flex justify-between items-center mb-6 pb-6 dotted-bottom" />
    </div>
  );
};

export default Basics;
```

**示例：merged-huxuan** — merged-huxuan

```tsx
'use client';

import { HoverFill, Popover } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basics = () => {
  const [visible, setVisible] = useState(false);
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);
  const lastHoverIndex = useRef(hoverIndex);
  const [lastValidHoverIndex, setLastValidHoverIndex] = useState<
    number | undefined
  >(undefined);
  const hoverTimer = useRef(0);
  const popupRef = useRef<HTMLDivElement>(null);

  // demo 我就直接写定尺寸了
  const menus = [
    {
      label: '创作者广场',
      list: [
        {
          label: '视频号',
          icon: (
            <svg className="size-6 mr-3" viewBox="0 0 16 16" fill="none">
              <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M2.60045 2.25C3.29833 2.25 3.90902 2.6364 4.40208 3.0815C4.90994 3.53996 5.40329 4.16132 5.87488 4.83968C6.59123 5.87012 7.32625 7.1371 8.02784 8.33073C8.73537 7.13993 9.46942 5.86659 10.1604 4.84702C10.6183 4.17136 11.0924 3.55173 11.5745 3.09421C12.0361 2.65616 12.6256 2.25 13.31 2.25C14.5482 2.25 14.9262 3.57642 14.9866 4.58262C15.0513 5.65825 14.875 7.03717 14.5814 8.3697C14.2863 9.70926 13.8588 11.0641 13.386 12.1004C13.0184 12.9061 12.409 14.1667 11.3628 14.1667C10.466 14.1667 9.74138 13.4715 9.19771 12.8331C8.80491 12.3719 8.40818 11.8077 8.01372 11.1964C7.60193 11.8137 7.18292 12.3837 6.76224 12.8495C6.1556 13.5213 5.38044 14.1667 4.4781 14.1667C3.4224 14.1667 2.86455 12.8928 2.51764 12.085C2.07319 11.0502 1.67329 9.69725 1.3966 8.36033C1.12111 7.02923 0.955766 5.6566 1.0104 4.58927C1.06004 3.61932 1.37845 2.25 2.60045 2.25ZM7.14315 9.78243C6.29449 8.35803 5.4676 6.88168 4.64325 5.6959C4.19593 5.05244 3.77911 4.53991 3.39696 4.19493C3.06548 3.89569 2.83008 3.78596 2.67969 3.7579C2.67751 3.76224 2.67521 3.76693 2.67278 3.77199C2.59994 3.92382 2.53159 4.21364 2.50844 4.66594C2.4631 5.55173 2.602 6.78327 2.86547 8.05634C3.12774 9.32358 3.50149 10.5748 3.8959 11.4931C4.0613 11.8782 4.25798 12.3557 4.56859 12.6566C4.78666 12.6114 5.14326 12.4042 5.64899 11.8442C6.12283 11.3195 6.62203 10.6053 7.14315 9.78243ZM8.90148 9.79122C9.41038 10.6166 9.89058 11.3332 10.3397 11.8605C10.585 12.1486 10.9071 12.5496 11.2939 12.6557C11.6345 12.3597 11.8394 11.8766 12.0213 11.4778C12.4396 10.5609 12.8379 9.31158 13.1165 8.04697C13.3967 6.77533 13.5421 5.55009 13.4893 4.67259C13.472 4.38457 13.4577 3.99902 13.2826 3.75174C13.1776 3.7642 12.958 3.84923 12.6071 4.18222C12.2426 4.52814 11.84 5.04241 11.4021 5.68856C10.5886 6.88898 9.77244 8.35606 8.90148 9.79122Z"
                fill="#FA9D3B"
              />
            </svg>
          ),
        },
        {
          label: '公众号',
          icon: (
            <svg className="size-6 mr-3" viewBox="0 0 18 18" fill="none">
              <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M13.8814 4.79098C13.1501 3.28732 11.3003 2.0003 9.20591 2C8.10694 1.99971 6.42804 2.37698 5.17344 3.89406C4.33562 4.90711 4.05354 6.09273 4.2301 7.27512C4.35139 8.08744 4.80383 9.15915 5.45124 9.83707C5.6953 8.11854 6.60047 6.76697 7.78728 5.77352C9.93011 4.13649 12.2178 4.22918 13.8814 4.79098ZM15.5532 7.36963C14.2422 5.6682 11.9758 5.19218 9.92999 5.95086L9.9468 5.95592C10.0072 5.9741 10.0675 5.99225 10.1276 6.01261C13.1566 7.04453 14.7937 10.3305 13.7841 13.352C13.5155 14.1558 13.0854 14.8588 12.5437 15.4399C13.1963 15.2592 13.8642 15.0008 14.4372 14.5593C16.744 12.7818 17.1981 9.5042 15.5532 7.36963ZM7.86661 12.6553C8.29547 12.7511 8.74128 12.804 9.20153 12.804C10.6028 12.804 11.7126 12.478 12.7609 11.7068C12.7338 12.143 12.6026 12.6681 12.4827 12.9773C11.496 15.5232 8.63959 16.6267 5.64612 15.6436C3.04319 14.7887 1.44815 11.7365 2.17692 9.18889C2.37234 8.5061 2.57203 8.03774 2.94695 7.44839C3.17184 9.09073 4.19433 10.6881 5.68502 11.7047C5.79835 11.7811 5.87587 11.9085 5.88221 12.0561C5.88427 12.1051 5.87573 12.1511 5.86482 12.1989L5.61458 13.3347C5.61166 13.3482 5.60822 13.3619 5.60474 13.3757C5.59454 13.4162 5.58408 13.4578 5.58584 13.4991C5.59115 13.6218 5.69431 13.7174 5.81648 13.7121C5.86453 13.71 5.90284 13.6903 5.94249 13.6651L7.35699 12.7583C7.46339 12.6901 7.57731 12.6461 7.70435 12.6407C7.76035 12.6382 7.81429 12.6445 7.86661 12.6553Z"
                fill="#07c160"
              />
            </svg>
          ),
        },
        {
          label: '小程序',
          icon: (
            <svg className="size-6 mr-3" viewBox="0 0 18 18" fill="none">
              <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M9.93333 3.56419C8.8145 4.21631 8.06667 5.36894 8.06667 6.68364V12.1497C8.06667 13.1341 7.12633 13.9321 5.96667 13.9321C4.80677 13.9321 3.86667 13.1341 3.86667 12.1497C3.86667 11.4491 4.34407 10.8447 5.03683 10.5534C5.08677 10.5325 5.1374 10.5125 5.18943 10.4949C5.62553 10.3167 5.99957 9.98205 6.1384 9.59348C6.3435 9.01978 5.96177 8.55493 5.28603 8.55493C5.11757 8.55493 4.94677 8.58393 4.78203 8.63621C3.80273 8.92258 2.98723 9.54904 2.4977 10.3673C2.18153 10.8961 2 11.5033 2 12.1497C2 14.1809 3.7794 15.8333 5.96667 15.8333C6.7383 15.8333 7.45673 15.6244 8.06667 15.2691C9.1855 14.617 9.93333 13.4644 9.93333 12.1497V6.68364C9.93333 5.69928 10.8734 4.90123 12.0333 4.90123C13.193 4.90123 14.1333 5.69928 14.1333 6.68364C14.1333 7.41419 13.6156 8.04207 12.8743 8.31728C12.3962 8.48055 12.0044 8.83299 11.8551 9.25055C11.6511 9.82139 12.031 10.2843 12.7037 10.2843C12.8561 10.2843 13.0101 10.2577 13.1601 10.2145C13.1846 10.2076 13.2089 10.2 13.2331 10.1926C14.2043 9.90528 15.0149 9.28073 15.5021 8.46605C15.8185 7.93751 16 7.33006 16 6.68364C16 4.65241 14.2206 3 12.0333 3C11.2617 3 10.5433 3.2089 9.93333 3.56419Z"
                fill="#605AB0"
              />
            </svg>
          ),
        },
        {
          label: 'QQ短视频',
          icon: (
            <svg className="size-6 mr-3" viewBox="0 0 32 32" fill="none">
              <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M24.4631 7.56752C26.7059 9.68039 28.106 12.6778 28.106 16.0022C28.106 22.4011 22.9187 27.5884 16.5198 27.5884C10.1209 27.5884 4.93359 22.4011 4.93359 16.0022C4.93359 9.60334 10.1209 4.41602 16.5198 4.41602C18.6717 4.41602 20.6866 5.00266 22.4132 6.02476C22.5 6.07079 22.5863 6.11856 22.6721 6.16807C23.3484 6.55856 23.9472 7.03176 24.4631 7.56752ZM13.0595 7.28186C9.59205 8.65894 7.14049 12.0443 7.14049 16.0022C7.14049 21.1823 11.3398 25.3815 16.5198 25.3815C21.4188 25.3815 25.4405 21.6256 25.8625 16.8363C25.7929 16.9744 25.719 17.1114 25.6406 17.247C23.401 21.1261 18.4408 22.4552 14.5617 20.2156C10.6826 17.976 9.35351 13.0158 11.5931 9.13666C11.9998 8.43228 12.4962 7.81198 13.0595 7.28186ZM21.3302 7.94873C18.5448 6.50462 15.089 7.49543 13.5043 10.2401C11.8742 13.0637 12.8416 16.6742 15.6652 18.3044C18.4887 19.9346 22.0992 18.9671 23.7294 16.1436C25.0676 13.8257 24.6554 10.9776 22.9029 9.12998C22.4228 8.68378 21.8958 8.28731 21.3302 7.94873Z"
                fill="#0099FF"
              />
            </svg>
          ),
        },
      ],
      width: 145,
      height: 54 * 4,
    },
    {
      label: '管理中心',
      list: [
        {
          label: '互选订单管理',
          icon: null,
        },
        {
          label: '互选结案报告管理',
          icon: null,
        },
      ],
      width: 152,
      height: 54 * 2,
    },
  ];

  const handleMouseEnter = (index: number) => {
    clearTimeout(hoverTimer.current);
    setHoverIndex(index);
    setLastValidHoverIndex(index);
    setVisible(true);
  };

  const handleMouseLeave = () => {
    clearTimeout(hoverTimer.current);

    hoverTimer.current = window.setTimeout(() => {
      setHoverIndex(null);
      setVisible(false);
    }, 200);
  };

  useEffect(() => {
    return () => {
      clearTimeout(hoverTimer.current);
    };
  }, []);

  useEffect(() => {
    if (popupRef.current) {
      popupRef.current.style.transition =
        lastHoverIndex.current === null ? 'none' : 'all 150ms ease-in-out';
    }

    if (lastHoverIndex.current !== hoverIndex) {
      lastHoverIndex.current = hoverIndex;
    }
  }, [hoverIndex]);

  return (
    <div>
      <CodeBox className="p-0 h-16 overflow-hidden">
        <div className="flex-1 h-full bg-white">
          <div className="flex items-center px-6 h-full">
            <svg className="mr-8 h-[30px]" viewBox="0 0 207 32" fill="none">
              <path
                d="M11.1802 28.874L5.55112 23.2449L10.6325 19.2288C11.906 18.2223 13.7294 18.3206 14.8874 19.458C16.0538 20.6036 16.177 22.4413 15.1741 23.7324L11.1802 28.874Z"
                fill="#A1E6C2"
              ></path>
              <path
                d="M26.6437 12.4547C25.3679 13.4852 23.5203 13.3872 22.3607 12.2276C21.2348 11.1017 21.1054 9.32028 22.0567 8.0435L25.4667 3.46693L31.3334 8.66693L26.6437 12.4547Z"
                fill="#A1E6C2"
              ></path>
              <path
                d="M11.2084 3.15234L5.55152 8.8092L10.7196 12.6306C11.997 13.5751 13.77 13.4574 14.9114 12.3523C16.1276 11.1747 16.2357 9.26056 15.1599 7.95345L11.2084 3.15234Z"
                fill="#FAD5AF"
              ></path>
              <path
                d="M26.3728 19.4619C25.0965 18.477 23.2846 18.6053 22.1599 19.7602C21.0698 20.8795 20.9563 22.6255 21.8924 23.8765L25.6769 28.9339L31.3906 23.3339L26.3728 19.4619Z"
                fill="#FAD5AF"
              ></path>
              <path
                d="M8.72608 18.3335C9.99568 18.1394 10.9334 17.0475 10.9334 15.7631C10.9334 14.4932 10.016 13.409 8.76357 13.1988L4.80008 12.5336L4.80008 18.9336L8.72608 18.3335Z"
                fill="#8ED2FF"
              ></path>
              <path
                d="M28.6074 18.3335C27.3378 18.1394 26.4 17.0475 26.4 15.7631C26.4 14.4932 27.3174 13.409 28.5699 13.1988L32.5334 12.5336V18.9336L28.6074 18.3335Z"
                fill="#8ED2FF"
              ></path>
              <circle cx="28.8" cy="5.60059" r="4" fill="#07C160"></circle>
              <circle cx="8.26672" cy="26.1338" r="4" fill="#07C160"></circle>
              <circle cx="8.26672" cy="5.86719" r="4" fill="#FA9D3B"></circle>
              <circle cx="28.8" cy="26.4004" r="4" fill="#FA9D3B"></circle>
              <circle cx="18.6667" cy="15.7342" r="3.2" fill="#296BEF"></circle>
              <circle cx="32.8" cy="15.7342" r="3.2" fill="#296BEF"></circle>
              <circle cx="4.53337" cy="15.7342" r="3.2" fill="#296BEF"></circle>
              <path
                d="M52.1745 7.29102H47.7819V17.1786C47.796 19.9123 47.647 22.6443 47.3356 25.3603H49.1814C49.3006 24.3615 49.5319 22.0535 49.595 18.8261H51.1932V25.3603H53.1395V8.27813C53.1396 8.02033 53.0387 7.77272 52.8583 7.58826C52.678 7.40379 52.4326 7.29711 52.1745 7.29102ZM50.9362 8.86154C50.9997 8.87004 51.0587 8.89903 51.1043 8.9441C51.1498 8.98916 51.1794 9.04785 51.1885 9.11124V12.25H49.6043V8.86154H50.9362ZM49.6067 17.2626V13.8228H51.1885V17.2649L49.6067 17.2626Z"
                fill="#333333"
              ></path>
              <path
                d="M71.5724 11.0642L70.056 6.73535H68.0723L69.5887 11.0642H71.5724Z"
                fill="#333333"
              ></path>
              <path
                d="M71.1939 12.1777H67.14L66.9203 13.7483H69.2475V25.3884L73.5958 23.1878V21.2602L71.1939 22.476V12.1777Z"
                fill="#333333"
              ></path>
              <path
                d="M83.6545 8.27813C83.6545 8.1485 83.629 8.02015 83.5793 7.90039C83.5296 7.78062 83.4568 7.6718 83.3651 7.58014C83.2733 7.48848 83.1643 7.41576 83.0444 7.36615C82.9245 7.31654 82.796 7.29102 82.6662 7.29102H72.6869L72.9533 8.86154H81.3484C81.4442 8.86338 81.5355 8.90287 81.6024 8.97144C81.6693 9.04002 81.7065 9.13217 81.7059 9.22792V14.1519H77.7852V10.2127L75.8389 9.88367V14.1519H72.9696V15.7224H75.8319V25.3603H77.7782V15.7224H81.6989V25.3603H85.185L85.449 23.7897H83.6475L83.6545 8.27813Z"
                fill="#333333"
              ></path>
              <path
                d="M62.6095 16.887V16.7563C63.0762 17.0788 63.5686 17.3629 64.0815 17.6057L64.9016 15.8905C63.8864 15.4166 62.9809 14.7372 62.2426 13.8952H64.6679V12.3224H59.3126C59.4609 11.9563 59.5888 11.5824 59.6958 11.2022H64.6679V9.62938H63.0955C63.5885 8.55825 64.0885 7.08806 64.0885 7.08806H61.9576C61.6843 7.9559 61.3541 8.80485 60.9692 9.62938H60.0346C60.1096 9.0881 60.1471 8.54229 60.1468 7.99584V6.72168H58.2448V7.99584C58.2443 8.54304 58.1997 9.08931 58.1117 9.62938H57.4621L56.4574 7.08806H54.3265L55.3312 9.62938H53.747V11.2022H57.7191C57.5851 11.5864 57.4243 11.9607 57.2378 12.3224H53.7354V13.8952H56.1607C55.4224 14.7372 54.5169 15.4166 53.5017 15.8905L54.3195 17.6057C54.7911 17.3845 55.2457 17.1287 55.6793 16.8403L55.649 16.887H60.6702V18.7935H57.4201L57.4855 17.9231L55.5368 17.5567L55.3546 20.3571H62.6328L62.4436 23.7805H59.787L60.0533 25.351H64.3034L64.6095 19.8647C64.6172 19.7257 64.5963 19.5866 64.5484 19.4559C64.5004 19.3253 64.4263 19.2057 64.3305 19.1046C64.2347 19.0035 64.1193 18.9229 63.9913 18.8679C63.8634 18.8128 63.7255 18.7843 63.5861 18.7842H62.6071V16.887H62.6095ZM59.8851 13.8952C60.2325 14.4561 60.6365 14.98 61.0907 15.4588H57.3149C57.7691 14.98 58.1731 14.4561 58.5206 13.8952H59.8851Z"
                fill="#333333"
              ></path>
              <path
                d="M97.6338 6.73535H95.5029L96.0964 8.42489H88.5565V15.8925C88.5565 22.0649 87.6896 24.9166 87.5447 25.3507H89.6476C89.9911 24.0509 90.5822 21.0685 90.5822 15.8925V10.1798H105.174V8.42489H98.2273L97.6338 6.73535Z"
                fill="#333333"
              ></path>
              <path
                d="M61.4481 21.3281H53.9199L54.1745 22.8263H61.378L61.4481 21.3281Z"
                fill="#333333"
              ></path>
              <path
                d="M121.695 17.795H108.405V25.3606H122.684V18.6677C122.656 18.426 122.54 18.2031 122.357 18.0419C122.175 17.8808 121.939 17.7928 121.695 17.795ZM110.354 23.7714V19.3935H120.452C120.528 19.3959 120.601 19.4276 120.654 19.482C120.707 19.5364 120.737 19.6092 120.737 19.6852V23.7714H110.354Z"
                fill="#333333"
              ></path>
              <path
                d="M116.592 14.2916V10.5578H123.308V8.98497H116.592V6.73535H114.644V8.99196H110.204C110.382 8.07485 110.464 7.39344 110.489 7.16241H108.62C108.378 9.08622 107.881 10.9695 107.144 12.7631H109.158C109.431 12.0413 109.665 11.3051 109.859 10.5578H114.646V14.2916H106.849V15.8622H124.242V14.2916H116.592Z"
                fill="#333333"
              ></path>
              <path
                d="M202.52 14.2415L202.519 14.2411L202.173 15.3391H187.681C189.791 12.9566 192.18 9.1437 193.741 6.71973H196.467C194.813 9.22657 193.096 12.2486 191.96 13.5331H201.97L201.842 13.363C200.902 12.1094 199.903 10.7454 199.047 9.49673H201.514C202.428 10.7274 203.602 12.1981 204.741 13.6263C205.405 14.4581 206.057 15.2755 206.64 16.0228H203.796C203.4 15.4428 202.96 14.8421 202.52 14.2415Z"
                fill="#333333"
              ></path>
              <path
                d="M148.081 6.74045C148.756 8.10782 149.642 9.64093 150.682 11.3812H148.212C147.963 10.8745 147.709 10.3701 147.452 9.85918C146.953 8.86625 146.441 7.84841 145.925 6.74045H148.081Z"
                fill="#333333"
              ></path>
              <path
                d="M164.323 13.9709V15.7319H161.187L161.104 20.4763H164.764L164.391 22.2787H159.059L159.179 15.7319H157.012C156.952 17.8244 156.262 20.0412 154.84 22.113H152.133C154.148 19.6476 154.903 17.7416 154.933 15.7319H151.778L151.778 13.9709H157.267V11.2983H154.495C153.91 12.1892 153.077 12.9558 151.917 13.4737L152.007 11.1997C152.966 10.4332 153.659 8.77079 153.72 7.42413H155.683C155.657 8.12854 155.527 8.83294 155.313 9.53734H157.267V6.74045H159.32V9.53734H163.571V11.2983H159.32V13.9709H164.323Z"
                fill="#333333"
              ></path>
              <path
                d="M150.503 20.3811C150.388 20.7179 150.269 21.0674 150.132 21.4086C152.562 23.066 156.23 23.5026 159.618 23.5026H165.013L164.621 25.3864H159.31C155.755 25.3864 152.562 24.9927 149.457 23.1489C149.112 23.9569 148.781 24.7234 148.456 25.3864H145.973C147.195 23.3768 148.151 21.1185 148.695 19.1918C148.728 18.0938 148.702 16.7264 148.636 15.6698C148.622 15.4212 148.568 15.3383 148.317 15.3383H146.053V13.598H149.404C150.219 13.598 150.506 13.8466 150.557 14.6546C150.655 16.0841 150.705 18.2181 150.701 19.8133C150.634 19.9956 150.569 20.1863 150.503 20.3811Z"
                fill="#333333"
              ></path>
              <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M143.092 7.5719V9.2363H131.768L131.329 12.2928H139.279C140.387 12.2928 140.768 12.7693 140.687 13.8259C140.466 16.7261 140.113 19.5965 139.704 23.5197H143.74V25.2931H125.253L125.253 23.5197H137.662C137.829 22.3341 137.955 21.1234 138.11 19.936H127.994C128.676 16.3311 129.323 12.8412 129.817 9.2363H125.484L125.484 7.5719H143.092ZM138.693 14.6132C138.721 14.2195 138.62 14.0952 138.327 14.0952H131.04C130.821 15.504 130.59 16.6976 130.329 18.1064H138.327C138.508 16.7183 138.607 15.6283 138.693 14.6132Z"
                fill="#333333"
              ></path>
              <path
                d="M184.445 7.36199H168.321V9.10228H175.093V16.4985H167.375V18.2388H175.093V25.3864H177.24V18.2388H185.422V16.4985H177.24V9.10228H184.445V7.36199Z"
                fill="#333333"
              ></path>
              <path
                d="M171.258 10.2003H169.02C169.83 12.2306 170.578 13.9709 171.243 15.4212H173.669C172.558 13.1837 171.768 11.4434 171.258 10.2003Z"
                fill="#333333"
              ></path>
              <path
                d="M181.326 15.4419C182.011 13.7845 182.539 12.0442 182.992 10.221H180.755C180.34 12.0235 179.708 13.7638 178.837 15.4419H181.326Z"
                fill="#333333"
              ></path>
              <path
                d="M202.943 17.7334H189.653V25.299H203.932V18.6062C203.904 18.3645 203.788 18.1416 203.605 17.9804C203.423 17.8193 203.187 17.7313 202.943 17.7334ZM191.602 23.7098V19.332H201.7C201.776 19.3344 201.849 19.3661 201.902 19.4205C201.955 19.4749 201.985 19.5477 201.985 19.6237V23.7098H191.602Z"
                fill="#333333"
              ></path>
            </svg>
            <Popover
              visible={visible}
              arrowed={false}
              placement="bottomLeft"
              shift={false}
              flip={false}
              autoPlacements={[]}
              popupStyle={{
                maxWidth: 'initial',
                padding: '12px 0',
                transform: `translateX(${
                  lastValidHoverIndex === 0 ? -18 : 78
                }px)`,
              }}
              popup={
                <div
                  className="relative transition-all duration-200 overflow-hidden"
                  style={{
                    width:
                      lastValidHoverIndex !== undefined
                        ? menus[lastValidHoverIndex].width
                        : 0,
                    height:
                      lastValidHoverIndex !== undefined
                        ? menus[lastValidHoverIndex].height
                        : 0,
                  }}
                  ref={popupRef}
                  onMouseEnter={() => {
                    clearTimeout(hoverTimer.current);
                  }}
                  onMouseLeave={handleMouseLeave}
                >
                  {menus.map((menu, index) => (
                    <div
                      key={index}
                      className={`absolute top-0 left-0 transition-all duration-200 ${
                        lastValidHoverIndex === index
                          ? 'opacity-100'
                          : 'opacity-0'
                      }`}
                      style={{
                        width: menu.width,
                        height: menu.height,
                      }}
                    >
                      {menu.list.map((list) => (
                        <HoverFill
                          key={list.label}
                          hoverColor="rgba(41, 107, 239, 0.05)"
                        >
                          <div className="flex items-center h-[54px] pl-3 text-[15px]">
                            {list.icon}
                            {list.label}
                          </div>
                        </HoverFill>
                      ))}
                    </div>
                  ))}
                </div>
              }
            >
              <div className="flex items-center">
                {menus.map((menu, index) => (
                  <HoverFill key={index} hoverColor="rgba(41, 107, 239, 0.05)">
                    <div
                      className="group flex items-center justify-cente…r gap-1 px-4 h-16 text-[15px] transition-all duration-200 text-neutral-900 hover:text-neutral-900"
                      onMouseEnter={() => {
                        handleMouseEnter(index);
                      }}
                      onMouseLeave={handleMouseLeave}
                    >
                      {menu.label}
                    </div>
                  </HoverFill>
                ))}
              </div>
            </Popover>
          </div>
        </div>
      </CodeBox>
      <div className="flex justify-between items-center mb-6 pb-6 dotted-bottom" />
    </div>
  );
};

export default Basics;
```

**示例：merged-button** — merged-button

```tsx
'use client';

import { Popover } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basics = () => {
  const [visible, setVisible] = useState(false);
  const [hoverIndex, setHoverIndex] = useState<number>(0);
  const lastHoverIndex = useRef(hoverIndex);
  const hoverTimer = useRef(0);

  const popovers = [
    {
      text: '平台基于达人近一年历史商单的R3人群增量相关数据进行智能推荐',
      offset: -88,
    },
    {
      text: '平台基于达人近一年历史商单的组件转化相关数据进行智能推荐',
      offset: 0,
    },
    {
      text: '平台基于达人的小店购物车权限及相关数据进行智能推荐',
      offset: 88,
    },
  ];

  const handleMouseEnter = (index: number) => {
    clearTimeout(hoverTimer.current);
    setHoverIndex(index);
    setVisible(true);
  };

  const handleMouseLeave = () => {
    clearTimeout(hoverTimer.current);

    hoverTimer.current = window.setTimeout(() => {
      setVisible(false);
    }, 100);
  };

  useEffect(() => {
    if (lastHoverIndex.current !== hoverIndex) {
      lastHoverIndex.current = hoverIndex;
    }
  }, [hoverIndex]);

  useEffect(() => {
    return () => {
      clearTimeout(hoverTimer.current);
    };
  }, []);

  return (
    <div>
      <CodeBox>
        <div>
          <div className="flex">
            <div className="w-[100px] text-neutral-500 text-sm leading-[36px]">
              营销目标
            </div>
            <div className="flex items-center gap-2 text-sm">
              <div className="flex items-center cursor-pointer h-9 px-3 text-[#296bef] font-semibold bg-[#2F6BEF1F] rounded-md">
                品牌曝光
              </div>
              <Popover
                visible={visible}
                placement="top"
                popup={
                  <div className="relative w-[210px] h-10">
                    {popovers.map((item, i) => (
                      <div
                        className={`absolute top-0 left-0 w-full h-full transition-all duration-100 ${
                          i === hoverIndex ? 'opacity-100' : 'opacity-0'
                        }`}
                        key={i}
                      >
                        {item.text}
                      </div>
                    ))}
                  </div>
                }
                popupStyle={{
                  transform: `translate3d(${
                    popovers[hoverIndex].offset
                  }px, 0, 0) scale(${visible ? 1 : 0.8})`,
                }}
              >
                <div className="flex gap-2">
                  <div
                    className="flex items-center cursor-pointer h-9 px-3 bg-[#49597A0D] hover:bg-[#f2f4f7] rounded-md"
                    onMouseEnter={() => handleMouseEnter(0)}
                    onMouseLeave={handleMouseLeave}
                  >
                    破圈种草
                  </div>
                  <div
                    className="flex items-center cursor-pointer h-9 px-3 bg-[#49597A0D] hover:bg-[#f2f4f7] rounded-md"
                    onMouseEnter={() => handleMouseEnter(1)}
                  >
                    行动转化
                  </div>
                  <div
                    className="flex items-center cursor-pointer h-9 px-3 bg-[#49597A0D] hover:bg-[#f2f4f7] rounded-md"
                    onMouseEnter={() => handleMouseEnter(2)}
                    onMouseLeave={handleMouseLeave}
                  >
                    商品推广
                  </div>
                </div>
              </Popover>
            </div>
          </div>
        </div>
      </CodeBox>
    </div>
  );
};

export default Basics;
```
## 业务配置 {#business-configuration}

根据业务需要配置不同程度的表现：

**示例：customize** — customize

```tsx
'use client';

import { Button, ConfigProvider, HoverFill } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
const Basic = () => {
  const today = new Date();
  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);
  const [value, setValue] = useState<[Date, Date] | undefined>([
    today,
    tomorrow,
  ]);

  return (
    <div>
      <CodeBox>
        <div
          className="flex items-center gap-2"
          style={{
            '--odn-hoverfill-duration': '0s',
          }}
        >
          <Button light>关闭过渡</Button>
          <Button light>关闭过渡</Button>
        </div>
      </CodeBox>
      <CodeBlock>{`html { --odn-hoverfill-duration: 0s; }`}</CodeBlock>
      <div className="flex justify-between items-center mb-6 pb-6 dotted-bottom" />
      <CodeBox>
        <ConfigProvider
          hoverFill={{
            sharable: false,
          }}
        >
          <div className="flex items-center gap-2">
            <HoverFill bgClassName="rounded-md">
              <button className="inline-flex items-center justify-center gap-0.5 h-9 px-3 text-sm">
                关闭共享
              </button>
            </HoverFill>
            <HoverFill
              bgClassName="rounded-md"
              hoverColor="#0D70FF0D"
              activeColor="#0D70FF1A"
            >
              <button className="inline-flex items-center justify-center gap-0.5 h-9 px-3 text-sm">
                关闭共享
              </button>
            </HoverFill>
          </div>
        </ConfigProvider>
      </CodeBox>
      <CodeBlock>{`<ConfigProvider hoverFill={{ sharable: false }} />`}</CodeBlock>
      {/* <div className="flex justify-between items-center mb-6 pb-6 dotted-bottom" />
      <CodeBox>
        <div
          className="flex items-center gap-2"
        >
          <HoverFill bgClassName="rounded-md">
            <button className="inline-flex items-center justify-center gap-0.5 h-9 px-3 text-sm">
              默认允许不同
            </button>
          </HoverFill>
          <HoverFill
            bgClassName="rounded-md"
            hoverColor="#0D70FF0D"
            activeColor="#0D70FF1A"
          >
            <button className="inline-flex items-center justify-center gap-0.5 h-9 px-3 text-sm">
              hover 色的共享
            </button>
          </HoverFill>
        </div>
      </CodeBox> */}
    </div>
  );
};

export default Basic;
```
## API {#api}

继承 `React.HTMLAttributes<HTMLDivElement>`。

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| hoverColor | 悬停背景色 | `string` | `rgba(33, 34, 38, 0.05)` |
| activeColor | 按下背景色 | `string` | `rgba(33, 34, 38, 0.08)` |
| bgClassName / bgStyle | 背景层圆角等 | `string` / `CSSProperties` | - |
| disabled | 是否禁用 | `boolean` | `false` |
| hoverCursor | 悬停鼠标样式 | `CSSProperties['cursor']` | `'pointer'` |
| children | 内容 | `React.ReactNode` | - |

## 变量 {#variables}

<VariablesTable id="HoverFill"></VariablesTable>
