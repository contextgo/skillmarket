## 自动完成 AutoComplete

## 基础用例 {#basic-usage}

组件内的默认筛选逻辑为： `option.value.toUpperCase().indexOf(inputValue.toUpperCase()) !== -1`。如果需要自定义过滤，可以传入自定义的 `filterOption` 属性：

**示例：基础用例** — 基础用例

```tsx
'use client';

import { AutoComplete } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
import { Pane } from 'tweakpane';

const Basic = () => {
  const [value, setValue] = useState('');
  const [params, setParams] = useState({
    disabled: false,
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'disabled', {
      type: 'boolean',
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  const handleChange = (selectedValue: string) => {
    console.log('✅ [onChange] 选择结果:', selectedValue);
    setValue(selectedValue);
  };

  const options = [
    { value: '朋友圈', label: '朋友圈' },
    { value: '视频号', label: '视频号' },
    { value: '订阅号', label: '订阅号' },
    { value: '小程序', label: '小程序' },
  ];

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <div className="flex items-center">
          <AutoComplete
            value={value}
            onChange={handleChange}
            className="w-[200px]"
            options={options}
            disabled={params.disabled}
          />
        </div>
      </CodeBox>
      <CodeBlock>{`import { AutoComplete } from 'one-design-next';

const [value, setValue] = useState('');

const handleChange = (selectedValue: string) => {
  console.log('✅ [onChange] 选择结果:', selectedValue);
  setValue(selectedValue);
};

const options = [
  { value: '朋友圈', label: '朋友圈' },
  { value: '视频号', label: '视频号' },
  { value: '订阅号', label: '订阅号' },
  { value: '小程序', label: '小程序' },
];      
      
<AutoComplete
  options={options}
  value={value}
  onChange={handleChange}
  disabled={${params.disabled}}
/>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 补全 {#completion}

通过 `onSearch` 监听输入框的输入变化，并根据输入变化动态更新 `options`：

**示例：补全** — 补全

```tsx
'use client';

import { AutoComplete } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';

const Basic = () => {
  const [value, setValue] = useState('');
  const [options, setOptions] = useState<{ label: string; value: string }[]>(
    [],
  );

  const handleSearch = (searchValue: string) => {
    console.log('🔍 [onSearch] 输入变化:', searchValue);
    if (searchValue.trim()) {
      setOptions([
        {
          label: `${searchValue}@gmail.com`,
          value: `${searchValue}@gmail.com`,
        },
        { label: `${searchValue}@163.com`, value: `${searchValue}@163.com` },
        { label: `${searchValue}@qq.com`, value: `${searchValue}@qq.com` },
      ]);
    } else {
      setOptions([]);
    }
  };

  const handleChange = (selectedValue: string) => {
    console.log('✅ [onChange] 选择结果:', selectedValue);
    setValue(selectedValue);
  };

  return (
    <div>
      <CodeBox className="gap-2 flex-wrap">
        <AutoComplete
          value={value}
          onSearch={handleSearch}
          onChange={handleChange}
          className="w-[200px]"
          options={options}
        />
      </CodeBox>
      <CodeBlock>{`import { AutoComplete } from 'one-design-next';
      
const [value, setValue] = useState('');
const [options, setOptions] = useState<{ label: string; value: string }[]>(
  [],
);

const handleSearch = (searchValue: string) => {
  console.log('🔍 [onSearch] 输入变化:', searchValue);
  if (searchValue.trim()) {
    setOptions([
      {
        label: \`\${searchValue}@gmail.com\`,
        value: \`\${searchValue}@gmail.com\`,
      },
      { label: \`\${searchValue}@163.com\`, value: \`\${searchValue}@163.com\` },
      { label: \`\${searchValue}@qq.com\`, value: \`\${searchValue}@qq.com\` },
    ]);
  } else {
    setOptions([]);
  }
};

const handleChange = (selectedValue: string) => {
  console.log('✅ [onChange] 选择结果:', selectedValue);
  setValue(selectedValue);
};

<AutoComplete
  options={options}
  value={value}
  onSearch={handleSearch}
  onChange={handleChange}
/>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 业务定制 {#business-customization}

通过 CSS Variables 定制样式，完整见页面底部的变量表格。

**示例：业务定制** — 业务定制

```tsx
'use client';

import { AnimatePresence, motion } from 'motion/react';
import { AutoComplete, Button, Icon, ScrollArea } from 'one-design-next';
import React, { useCallback, useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';

type EffectType = 'sweep' | 'fly' | 'deblur' | 'confirm';

const PULSE_DURATION = 0.4;
const PULSE_STAGGER = 0.04;
const PULSE_NEW_DELAY = 0.04;
const PULSE_HEIGHT_DELAY = 0.2;

interface TagDef {
  label: string;
  effect: EffectType;
}

interface ItemDef {
  title: string;
  desc: string;
  tags: TagDef[];
}

const ITEMS: ItemDef[] = [
  {
    title: '标签组一',
    desc: '锁定男性核心受众，匹配香奈儿蔚蓝男士香水的主要使用群体，同时覆盖男性送礼人群。',
    tags: [
      { label: '示例一: 简单扫光', effect: 'sweep' },
      { label: '示例二: 飞到右边', effect: 'fly' },
    ],
  },
  {
    title: '标签组二',
    desc: '覆盖高消费力女性群体，精准触达美妆护肤品类高频购买用户，提升转化效率。',
    tags: [
      { label: '示例三: 脉冲展开', effect: 'deblur' },
      { label: '示例四: 文字右移', effect: 'confirm' },
    ],
  },
  {
    title: '标签组三',
    desc: '聚焦年轻潮流人群，匹配运动健身与户外生活方式偏好，拓展品牌年轻化心智。',
    tags: [
      { label: '示例一: 简单扫光1', effect: 'sweep' },
      { label: '示例二: 飞到右边1', effect: 'fly' },
    ],
  },
];

function getEffect(label: string): EffectType {
  for (const item of ITEMS) {
    const tag = item.tags.find((t) => t.label === label);
    if (tag) return tag.effect;
  }
  return 'sweep';
}

// ── Flying element (offset-path arc animation) ──────────────────────

interface FlyData {
  id: string;
  tag: string;
  path: string;
  startW: number;
  startH: number;
  endW: number;
  endH: number;
}

const FlyingElement: React.FC<{
  data: FlyData;
  onDone: (id: string, tag: string) => void;
}> = ({ data, onDone }) => {
  const [started, setStarted] = useState(false);

  useEffect(() => {
    let raf2 = 0;
    const raf1 = requestAnimationFrame(() => {
      raf2 = requestAnimationFrame(() => setStarted(true));
    });
    return () => {
      cancelAnimationFrame(raf1);
      cancelAnimationFrame(raf2);
    };
  }, []);

  const active = started;

  return (
    <div
      style={{
        position: 'fixed',
        left: 0,
        top: 0,
        zIndex: 9999,
        pointerEvents: 'none',
        offsetPath: `path('${data.path}')`,
        offsetRotate: '0deg',
        offsetDistance: active ? '100%' : '0%',
        width: active ? data.endW : data.startW,
        height: active ? data.endH : data.startH,
        opacity: active ? 1 : 0,
        transition: active
          ? [
              'offset-distance 0.5s cubic-bezier(0.33,1,0.68,1)',
              'width 0.5s cubic-bezier(0.33,1,0.68,1)',
              'height 0.5s cubic-bezier(0.33,1,0.68,1)',
              'background-color 0.5s cubic-bezier(0.33,1,0.68,1)',
              'border-radius 0.5s cubic-bezier(0.33,1,0.68,1)',
              'opacity 0.15s ease-out',
            ].join(',')
          : 'none',
        overflow: 'hidden',
        borderRadius: active ? '0 0 12px 12px' : 6,
        backgroundColor: active ? '#F5F8FF' : '#fff',
      }}
      onTransitionEnd={(e) => {
        if (e.propertyName === 'offset-distance') {
          onDone(data.id, data.tag);
        }
      }}
    >
      <div style={{ padding: '8px 16px' }}>
        <div
          style={{
            fontSize: 14,
            lineHeight: '22px',
            marginBottom: 4,
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
          }}
        >
          {data.tag}
        </div>
        <div
          style={{
            fontSize: 12,
            lineHeight: '20px',
            color: '#898B8F',
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
          }}
        >
          时间范围：2025-10-16 ~ 2025-11-15；换机前：VIVO；换机后：苹果
        </div>
      </div>
    </div>
  );
};

const Basic = () => {
  const [value, setValue] = useState('');

  const handleChange = (selectedValue: string) => {
    console.log('✅ [onChange] 选择结果:', selectedValue);
    setValue(selectedValue);
  };

  const options = [
    { value: '朋友圈', label: '朋友圈' },
    { value: '视频号', label: '视频号' },
    { value: '订阅号', label: '订阅号' },
    { value: '小程序', label: '小程序' },
  ];

  const [addedTags, setAddedTags] = useState<string[]>([]);
  const [flying, setFlying] = useState<FlyData[]>([]);
  const [pending, setPending] = useState<Set<string>>(new Set());
  const [sweepingTags, setSweepingTags] = useState<Set<string>>(new Set());
  const [pulsingTag, setPulsingTag] = useState<string | null>(null);
  const [sweepKey, setSweepKey] = useState(0);
  const pulseTimerRef = useRef<ReturnType<typeof setTimeout>>();

  const srcRefs = useRef<Map<string, HTMLElement>>(new Map());
  const containerRef = useRef<HTMLDivElement>(null);
  const landingRef = useRef<HTMLDivElement>(null);

  const handleClick = useCallback(
    (label: string) => {
      // toggle off
      if (addedTags.includes(label)) {
        setAddedTags((p) => p.filter((t) => t !== label));
        setPending((p) => {
          const s = new Set(p);
          s.delete(label);
          return s;
        });
        setSweepingTags((p) => {
          const s = new Set(p);
          s.delete(label);
          return s;
        });
        setFlying((p) => p.filter((f) => f.tag !== label));
        return;
      }

      const effect = getEffect(label);

      if (effect === 'fly') {
        const srcEl = srcRefs.current.get(label);
        const cEl = containerRef.current;
        const lEl = landingRef.current;
        if (!srcEl || !cEl || !lEl) return;

        const sr = srcEl.getBoundingClientRect();
        const cr = cEl.getBoundingClientRect();
        const lr = lEl.getBoundingClientRect();

        const endW = cr.width;
        const endH = 62;

        // offset-anchor defaults to center, so use center coords
        const sx = sr.left + sr.width / 2;
        const sy = sr.top + sr.height / 2;
        const ex = cr.left + cr.width / 2;
        const ey = lr.top + endH / 2;

        // quadratic bezier control point — arc upward
        const cx = (sx + ex) / 2;
        const cy = Math.min(sy, ey) - 100 - Math.abs(ex - sx) * 0.15;

        const path = `M ${sx},${sy} Q ${cx},${cy} ${ex},${ey}`;

        setFlying((p) => [
          ...p,
          {
            id: `fly-${Date.now()}`,
            tag: label,
            path,
            startW: sr.width,
            startH: sr.height,
            endW,
            endH,
          },
        ]);
        setPending((p) => new Set(p).add(label));
        setAddedTags((p) => [...p, label]);
      } else if (effect === 'deblur') {
        setAddedTags((p) => [...p, label]);
        setPulsingTag(label);
        setSweepKey((k) => k + 1);
        clearTimeout(pulseTimerRef.current);
        pulseTimerRef.current = setTimeout(() => setPulsingTag(null), 1200);
      } else if (effect === 'confirm') {
        setAddedTags((p) => [...p, label]);
      } else {
        setAddedTags((p) => [...p, label]);
        setSweepingTags((p) => new Set(p).add(label));
      }
    },
    [addedTags],
  );

  const handleFlyDone = useCallback((id: string, tag: string) => {
    setFlying((p) => p.filter((f) => f.id !== id));
    setPending((p) => {
      const s = new Set(p);
      s.delete(tag);
      return s;
    });
  }, []);

  return (
    <div>
      <style>{`
        @keyframes rowPulse {
          0%, 100% { transform: scale(1); }
          40% { transform: scale(1.03); }
        }
      `}</style>
      <CodeBox className="flex p-4 gap-4" style={{ background: '#f2f5fa' }}>
        {/* ── Left panel ─────────────────────────────────────────── */}
        <ScrollArea className="flex-1 p-5 h-[600px] bg-white rounded-xl">
          <div className="p-1">
            <AutoComplete
              value={value}
              onChange={handleChange}
              className="mb-4 w-full"
              options={options}
              prefix={null}
              style={{
                '--odn-control-height': '64px',
                '--odn-input-padding-block-medium': '13px',
                '--odn-input-padding-inline-medium': '24px',
                '--odn-input-border-radius-medium': '16px',
              }}
              inputProps={{
                leftElement: null,
                rightElement: (
                  <div
                    className="relative -right-2 flex size-8 items-center justify-center rounded-full bg-[var(--odn-color-blue-6)] hover:bg-[var(--odn-color-blue-7)] active:bg-[var(--odn-color-blue-8)] cursor-pointer"
                    onPointerDown={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                    }}
                  >
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                      <g clipPath="url(#clip0_5388_18893)">
                        <path
                          d="M12 12L14.5 14.5"
                          stroke="white"
                          style={{ stroke: 'white', strokeOpacity: 1 }}
                          strokeWidth="1.5"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                        <path
                          d="M13.5 7.49999C13.5 10.8137 10.8137 13.5 7.5 13.5C4.18629 13.5 1.5 10.8137 1.5 7.49999C1.5 4.1863 4.18629 1.5 7.5 1.5"
                          stroke="white"
                          style={{ stroke: 'white', strokeOpacity: 1 }}
                          strokeWidth="1.5"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                        <path
                          d="M11 1L11.2211 1.59746C11.5109 2.38088 11.6559 2.7726 11.9417 3.05834C12.2274 3.3441 12.6191 3.48904 13.4026 3.77894L14 4.00001L13.4026 4.22109C12.6191 4.51098 12.2274 4.65594 11.9417 4.94168C11.6559 5.22743 11.5109 5.61915 11.2211 6.40257L11 7L10.7789 6.40257C10.4891 5.61915 10.3441 5.22743 10.0583 4.94168C9.77257 4.65594 9.38086 4.51098 8.59743 4.22109L8 4.00001L8.59743 3.77894C9.38086 3.48904 9.77257 3.3441 10.0583 3.05834C10.3441 2.7726 10.4891 2.38088 10.7789 1.59746L11 1Z"
                          stroke="white"
                          style={{ stroke: 'white', strokeOpacity: 1 }}
                          strokeWidth="1.5"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      </g>
                      <defs>
                        <clipPath id="clip0_5388_18893">
                          <rect
                            width="16"
                            height="16"
                            fill="white"
                            style={{ fill: 'white', fillOpacity: 1 }}
                          />
                        </clipPath>
                      </defs>
                    </svg>
                  </div>
                ),
              }}
            />
            <div className="pt-4 pr-4 pb-5 pl-5 bg-[#EFF6FF] border border-[#DBEAFE] rounded-2xl">
              <div className="mb-2 flex items-center justify-between">
                <div
                  className="text-[16px] leading-[24px] font-semibold bg-clip-text text-transparent"
                  style={{
                    backgroundImage:
                      'radial-gradient(100% 108.57% at 0% 0%, #628DFF 0%, #65B7FF 30%, #00A3EC 65%, #719BF1 100%)',
                  }}
                >
                  AI 推荐标签
                </div>
                <button className="flex items-center gap-1 px-3 h-[34px] text-[11px] bg-white border border-[#DBEAFE] rounded-xl">
                  全部添加
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                    <path
                      d="M8.65 3C8.65 2.72386 8.42614 2.5 8.15 2.5H7.85C7.57386 2.5 7.35 2.72386 7.35 3V7.35H3C2.72386 7.35 2.5 7.57386 2.5 7.85V8.15C2.5 8.42614 2.72386 8.65 3 8.65H7.35V13C7.35 13.2761 7.57386 13.5 7.85 13.5H8.15C8.42614 13.5 8.65 13.2761 8.65 13V8.65H13C13.2761 8.65 13.5 8.42614 13.5 8.15V7.85C13.5 7.57386 13.2761 7.35 13 7.35H8.65V3Z"
                      fill="#464749"
                    />
                  </svg>
                </button>
              </div>
              <div className="flex flex-col gap-8">
                {ITEMS.map((item, index) => (
                  <React.Fragment key={index}>
                    <div>
                      <div className="mb-2 text-[16px] leading-[24px] font-semibold text-[#1E3A8A]">
                        {item.title}
                      </div>
                      <div className="mb-2 text-[12px] leading-[20px] text-[#1E40AF]/70">
                        <span className="font-semibold">推荐理由：</span>
                        <span>{item.desc}</span>
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        {item.tags.map((tag) => {
                          const added = addedTags.includes(tag.label);
                          const isConfirm = tag.effect === 'confirm';

                          return isConfirm ? (
                            <motion.div
                              key={tag.label}
                              layout
                              ref={(el: HTMLElement | null) => {
                                if (el) srcRefs.current.set(tag.label, el);
                              }}
                              className="relative h-[30px] text-[11px] bg-white rounded-md cursor-pointer overflow-hidden"
                              transition={{
                                layout: {
                                  duration: 0.3,
                                  ease: [0.25, 1, 0.5, 1],
                                },
                              }}
                              onClick={() => handleClick(tag.label)}
                            >
                              {/* invisible sizer */}
                              <div
                                className="flex items-center gap-2 px-3 whitespace-nowrap"
                                style={{ height: 0, overflow: 'hidden' }}
                              >
                                {added ? '已添加至 定向组合 1' : tag.label}
                                <span className="flex-shrink-0 flex">
                                  <Icon
                                    name="check"
                                    size={14}
                                    color="transparent"
                                  />
                                </span>
                              </div>
                              {/* default layer */}
                              <div
                                className="absolute inset-0 flex items-center gap-2 px-3 whitespace-nowrap"
                                style={{
                                  color: added ? '#296BEF' : '#33373D',
                                  transition:
                                    'transform 0.3s cubic-bezier(0.25, 1, 0.5, 1), color 0.2s',
                                  transform: added
                                    ? 'translateX(100%)'
                                    : 'translateX(0)',
                                }}
                              >
                                {tag.label}
                                <span className="flex-shrink-0 flex">
                                  <Icon
                                    name="plus"
                                    size={14}
                                    color="rgba(51, 55, 61, 0.58)"
                                  />
                                </span>
                              </div>
                              {/* confirmation layer */}
                              <div
                                className="absolute inset-0 flex items-center gap-2 px-3 whitespace-nowrap"
                                style={{
                                  color: '#296BEF',
                                  transition:
                                    'all 0.3s cubic-bezier(0.25, 1, 0.5, 1)',
                                  opacity: added ? 1 : 0,
                                  transform: added
                                    ? 'translateX(0)'
                                    : 'translateX(-100%)',
                                }}
                              >
                                已添加至 定向组合 1
                                <span className="flex-shrink-0 flex">
                                  <Icon
                                    name="check"
                                    size={14}
                                    color="#296BEF"
                                  />
                                </span>
                              </div>
                            </motion.div>
                          ) : (
                            <motion.div
                              key={tag.label}
                              ref={(el: HTMLElement | null) => {
                                if (el) srcRefs.current.set(tag.label, el);
                              }}
                              className="relative flex items-center gap-2 h-[30px] px-3 text-[11px] bg-white rounded-md cursor-pointer overflow-hidden"
                              animate={{
                                color: added ? '#296BEF' : '#33373D',
                              }}
                              transition={{ duration: 0.2 }}
                              whileTap={{ scale: 0.96 }}
                              onClick={() => handleClick(tag.label)}
                            >
                              {tag.label}
                              <AnimatePresence mode="wait" initial={false}>
                                <motion.div
                                  key={added ? 'check' : 'plus'}
                                  initial={{
                                    scale: 0.5,
                                    opacity: 0,
                                  }}
                                  animate={{
                                    scale: 1,
                                    opacity: 1,
                                  }}
                                  exit={{
                                    scale: 0.5,
                                    opacity: 0,
                                  }}
                                  transition={{ duration: 0.1 }}
                                >
                                  <Icon
                                    name={added ? 'check' : 'plus'}
                                    size={14}
                                    color={
                                      added
                                        ? '#296BEF'
                                        : 'rgba(51, 55, 61, 0.58)'
                                    }
                                  />
                                </motion.div>
                              </AnimatePresence>
                              {sweepingTags.has(tag.label) && (
                                <motion.div
                                  className="pointer-events-none absolute inset-0"
                                  initial={{ x: '-100%' }}
                                  animate={{ x: '200%' }}
                                  transition={{
                                    duration: 0.6,
                                    ease: 'easeInOut',
                                    delay: 0,
                                  }}
                                  onAnimationComplete={() => {
                                    setSweepingTags((p) => {
                                      const s = new Set(p);
                                      s.delete(tag.label);
                                      return s;
                                    });
                                  }}
                                  style={{
                                    background:
                                      'linear-gradient(90deg, transparent 0%, rgba(255, 255, 255, 0.6) 50%, transparent 100%)',
                                  }}
                                />
                              )}
                            </motion.div>
                          );
                        })}
                      </div>
                    </div>
                    {index !== ITEMS.length - 1 && (
                      <div className="h-[1px] bg-[#DBEAFE]"></div>
                    )}
                  </React.Fragment>
                ))}
              </div>
            </div>
          </div>
        </ScrollArea>

        {/* ── Right panel ────────────────────────────────────────── */}
        <div className="flex-none w-[320px] h-[600px] bg-white rounded-xl">
          <div className="flex items-center justify-between pl-6 pr-3 h-[60px] border-b border-neutral-100">
            <div className="text-[16px] font-semibold">设置组合规则</div>
            <Button light icon="plus">
              添加组合
            </Button>
          </div>
          <ScrollArea className="h-[540px]">
            <div className="flex flex-col gap-4 p-6">
              <div
                className="relative overflow-hidden rounded-xl"
                ref={containerRef}
              >
                {/* sweep disabled for now */}
                <div
                  className="flex items-center justify-between pl-4 pr-1.5 h-[46px] bg-[#F5F8FF] rounded-t-xl"
                  style={
                    pulsingTag
                      ? {
                          animation: `rowPulse ${PULSE_DURATION}s ease-in-out both`,
                        }
                      : undefined
                  }
                >
                  <div className="flex items-center gap-2">
                    <div className="flex items-center justify-center size-4 bg-[#D4E1FC] rounded-full">
                      <div className="size-2 bg-[#296BEF] rounded-full" />
                    </div>
                    <div className="text-[14px] font-semibold">定向组合 1</div>
                  </div>
                  <Button light icon="delete" />
                </div>
                <div
                  className="px-4 py-2 bg-[#F5F8FF]"
                  style={{
                    borderRadius: addedTags.length > 0 ? 0 : '0 0 12px 12px',
                    transition: 'border-radius 0.25s ease-out',
                    ...(pulsingTag
                      ? {
                          animation: `rowPulse ${PULSE_DURATION}s ease-in-out ${PULSE_STAGGER}s both`,
                        }
                      : {}),
                  }}
                >
                  <div className="mb-1 text-[14px] leading-[22px] whitespace-nowrap overflow-hidden text-ellipsis">
                    标签：用户属性/设备信息/换机人群
                  </div>
                  <div className="text-[12px] leading-[20px] text-[#898B8F] whitespace-nowrap overflow-hidden text-ellipsis">
                    时间范围：2025-10-16 ~
                    2025-11-15；换机前：VIVO；换机后：苹果
                  </div>
                </div>
                <AnimatePresence initial={false}>
                  {addedTags.map((tag, index) => {
                    const effect = getEffect(tag);
                    const isFly = effect === 'fly';
                    const isDeblur = effect === 'deblur';
                    const isConfirm = effect === 'confirm';
                    const isFlying = isFly && pending.has(tag);
                    return (
                      <motion.div
                        key={tag}
                        initial={{
                          height: 0,
                          opacity: isDeblur ? 1 : isConfirm ? 1 : 0,
                        }}
                        animate={{
                          height: 'auto',
                          opacity: isFlying ? 0 : 1,
                          borderRadius:
                            index === addedTags.length - 1
                              ? '0 0 12px 12px'
                              : '0',
                        }}
                        exit={{
                          height: 0,
                          opacity: 0,
                          transition: {
                            height: { duration: 0.25, ease: 'easeOut' },
                            opacity: { duration: 0.15, ease: 'easeOut' },
                          },
                        }}
                        transition={{
                          height: {
                            duration: isDeblur
                              ? 0.65
                              : isConfirm
                                ? 0.35
                                : isFly
                                  ? 0.4
                                  : 0.25,
                            ease: isDeblur
                              ? [0.22, 1, 0.36, 1]
                              : [0.25, 1, 0.5, 1],
                            delay: isDeblur ? PULSE_HEIGHT_DELAY : 0,
                          },
                          opacity: { duration: 0 },
                          borderRadius: {
                            duration: 0.25,
                            ease: 'easeOut',
                          },
                        }}
                        className={`overflow-hidden select-none ${isConfirm ? '' : 'bg-[#F5F8FF]'}`}
                        style={
                          pulsingTag
                            ? {
                                animation: `rowPulse ${PULSE_DURATION}s ease-in-out ${
                                  tag === pulsingTag
                                    ? (2 + index) * PULSE_STAGGER +
                                      PULSE_NEW_DELAY
                                    : (2 + index) * PULSE_STAGGER
                                }s both`,
                              }
                            : undefined
                        }
                      >
                        {isConfirm ? (
                          <motion.div
                            className="relative px-4 py-2 overflow-hidden bg-[#F5F8FF]"
                            initial={{ x: '-100%' }}
                            animate={{ x: 0 }}
                            transition={{
                              duration: 0.3,
                              ease: [0.25, 1, 0.5, 1],
                              delay: 0.05,
                            }}
                          >
                            <div className="mb-1 text-[14px] leading-[22px] whitespace-nowrap overflow-hidden text-ellipsis">
                              {tag}
                            </div>
                            <div className="text-[12px] leading-[20px] text-[#898B8F] whitespace-nowrap overflow-hidden text-ellipsis">
                              时间范围：2025-10-16 ~
                              2025-11-15；换机前：VIVO；换机后：苹果
                            </div>
                          </motion.div>
                        ) : isDeblur && tag === pulsingTag ? (
                          <div className="relative px-4 py-2 overflow-hidden">
                            <div className="mb-1 text-[14px] leading-[22px] whitespace-nowrap overflow-hidden text-ellipsis">
                              {tag}
                            </div>
                            <div className="text-[12px] leading-[20px] text-[#898B8F] whitespace-nowrap overflow-hidden text-ellipsis">
                              时间范围：2025-10-16 ~
                              2025-11-15；换机前：VIVO；换机后：苹果
                            </div>
                            <motion.div
                              className="pointer-events-none absolute inset-0"
                              initial={{ x: '-100%' }}
                              animate={{ x: '200%' }}
                              transition={{
                                duration: 0.8,
                                ease: 'easeInOut',
                                delay: PULSE_HEIGHT_DELAY + 0.1,
                              }}
                              style={{
                                background:
                                  'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.3) 50%, transparent 100%)',
                              }}
                            />
                          </div>
                        ) : isDeblur ? (
                          <div className="px-4 py-2">
                            <div className="mb-1 text-[14px] leading-[22px] whitespace-nowrap overflow-hidden text-ellipsis">
                              {tag}
                            </div>
                            <div className="text-[12px] leading-[20px] text-[#898B8F] whitespace-nowrap overflow-hidden text-ellipsis">
                              时间范围：2025-10-16 ~
                              2025-11-15；换机前：VIVO；换机后：苹果
                            </div>
                          </div>
                        ) : (
                          <div className="relative px-4 py-2 overflow-hidden">
                            <div className="mb-1 text-[14px] leading-[22px] whitespace-nowrap overflow-hidden text-ellipsis">
                              {tag}
                            </div>
                            <div className="text-[12px] leading-[20px] text-[#898B8F] whitespace-nowrap overflow-hidden text-ellipsis">
                              时间范围：2025-10-16 ~
                              2025-11-15；换机前：VIVO；换机后：苹果
                            </div>
                            {!isFly && (
                              <motion.div
                                className="pointer-events-none absolute inset-0"
                                initial={{ x: '-100%' }}
                                animate={{ x: '200%' }}
                                transition={{
                                  duration: 0.6,
                                  ease: 'easeInOut',
                                  delay: 0.1,
                                }}
                                style={{
                                  background:
                                    'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.6) 50%, transparent 100%)',
                                }}
                              />
                            )}
                          </div>
                        )}
                      </motion.div>
                    );
                  })}
                </AnimatePresence>
                <div ref={landingRef} />
              </div>
              <div className="bg-[#F6F7F8] rounded-xl">
                <div className="flex items-center justify-between pl-4 pr-1.5 h-[46px]">
                  <div className="flex items-center gap-2">
                    <div className="text-[14px] font-semibold">定向组合 2</div>
                  </div>
                  <Button light icon="delete" />
                </div>
                <div className="px-4 py-2">
                  <div className="mb-1 text-[14px] leading-[22px] whitespace-nowrap overflow-hidden text-ellipsis">
                    标签：用户属性/设备信息/换机人群
                  </div>
                  <div className="text-[12px] leading-[20px] text-[#898B8F] whitespace-nowrap overflow-hidden text-ellipsis">
                    时间范围：2025-10-16 ~
                    2025-11-15；换机前：VIVO；换机后：苹果
                  </div>
                </div>
                <div className="px-4 py-2">
                  <div className="mb-1 text-[14px] leading-[22px] whitespace-nowrap overflow-hidden text-ellipsis">
                    标签：用户属性/设备信息/换机人群
                  </div>
                  <div className="text-[12px] leading-[20px] text-[#898B8F] whitespace-nowrap overflow-hidden text-ellipsis">
                    时间范围：2025-10-16 ~
                    2025-11-15；换机前：VIVO；换机后：苹果
                  </div>
                </div>
                <div className="px-4 py-2">
                  <div className="mb-1 text-[14px] leading-[22px] whitespace-nowrap overflow-hidden text-ellipsis">
                    标签：用户属性/设备信息/换机人群
                  </div>
                  <div className="text-[12px] leading-[20px] text-[#898B8F] whitespace-nowrap overflow-hidden text-ellipsis">
                    时间范围：2025-10-16 ~
                    2025-11-15；换机前：VIVO；换机后：苹果
                  </div>
                </div>
              </div>
              <div className="bg-[#F6F7F8] rounded-xl">
                <div className="flex items-center justify-between pl-4 pr-1.5 h-[46px]">
                  <div className="flex items-center gap-2">
                    <div className="text-[14px] font-semibold">定向组合 3</div>
                  </div>
                  <Button light icon="delete" />
                </div>
                <div className="px-4 py-2">
                  <div className="mb-1 text-[14px] leading-[22px] whitespace-nowrap overflow-hidden text-ellipsis">
                    标签：用户属性/设备信息/换机人群
                  </div>
                  <div className="text-[12px] leading-[20px] text-[#898B8F] whitespace-nowrap overflow-hidden text-ellipsis">
                    时间范围：2025-10-16 ~
                    2025-11-15；换机前：VIVO；换机后：苹果
                  </div>
                </div>
                <div className="px-4 py-2">
                  <div className="mb-1 text-[14px] leading-[22px] whitespace-nowrap overflow-hidden text-ellipsis">
                    标签：用户属性/设备信息/换机人群
                  </div>
                  <div className="text-[12px] leading-[20px] text-[#898B8F] whitespace-nowrap overflow-hidden text-ellipsis">
                    时间范围：2025-10-16 ~
                    2025-11-15；换机前：VIVO；换机后：苹果
                  </div>
                </div>
                <div className="px-4 py-2">
                  <div className="mb-1 text-[14px] leading-[22px] whitespace-nowrap overflow-hidden text-ellipsis">
                    标签：用户属性/设备信息/换机人群
                  </div>
                  <div className="text-[12px] leading-[20px] text-[#898B8F] whitespace-nowrap overflow-hidden text-ellipsis">
                    时间范围：2025-10-16 ~
                    2025-11-15；换机前：VIVO；换机后：苹果
                  </div>
                </div>
              </div>
            </div>
          </ScrollArea>
        </div>
      </CodeBox>

      {/* ── Flying elements (rendered outside CodeBox to avoid clipping) */}
      {flying.map((data) => (
        <FlyingElement key={data.id} data={data} onDone={handleFlyDone} />
      ))}
      <CodeBlock>{`import { AutoComplete } from 'one-design-next';

<AutoComplete
  options={options}
  prefix={null}
  style={{
    '--odn-control-height': '64px',
    '--odn-input-padding-block-medium': '13px',
    '--odn-input-padding-inline-medium': '24px',
    '--odn-input-border-radius-medium': '16px',
  }}
  inputProps={{
    leftElement: null,
    rightElement: (
      <div
        className="relative -right-2 flex size-8 items-center justify-center rounded-full bg-[var(--odn-color-blue-6)] hover:bg-[var(--odn-color-blue-7)] active:bg-[var(--odn-color-blue-8)]"
        onPointerDown={(e) => {
          e.preventDefault();
          e.stopPropagation();
        }}
      >
        <svg
          width="16"
          height="16"
          viewBox="0 0 16 16"
          fill="none"
        >
          <g clipPath="url(#clip0_5388_18893)">
            <path
              d="M12 12L14.5 14.5"
              stroke="white"
              style={{ stroke: 'white', strokeOpacity: 1 }}
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M13.5 7.49999C13.5 10.8137 10.8137 13.5 7.5 13.5C4.18629 13.5 1.5 10.8137 1.5 7.49999C1.5 4.1863 4.18629 1.5 7.5 1.5"
              stroke="white"
              style={{ stroke: 'white', strokeOpacity: 1 }}
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M11 1L11.2211 1.59746C11.5109 2.38088 11.6559 2.7726 11.9417 3.05834C12.2274 3.3441 12.6191 3.48904 13.4026 3.77894L14 4.00001L13.4026 4.22109C12.6191 4.51098 12.2274 4.65594 11.9417 4.94168C11.6559 5.22743 11.5109 5.61915 11.2211 6.40257L11 7L10.7789 6.40257C10.4891 5.61915 10.3441 5.22743 10.0583 4.94168C9.77257 4.65594 9.38086 4.51098 8.59743 4.22109L8 4.00001L8.59743 3.77894C9.38086 3.48904 9.77257 3.3441 10.0583 3.05834C10.3441 2.7726 10.4891 2.38088 10.7789 1.59746L11 1Z"
              stroke="white"
              style={{ stroke: 'white', strokeOpacity: 1 }}
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </g>
          <defs>
            <clipPath id="clip0_5388_18893">
              <rect
                width="16"
                height="16"
                fill="white"
                style={{ fill: 'white', fillOpacity: 1 }}
              />
            </clipPath>
          </defs>
        </svg>
      </div>
    ),
  }}
/>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## API {#api}

在 `rc-select`（无 `mode`）基础上封装，见类型 `AutoCompleteProps`。

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| options | 选项数据 | `DefaultOptionType[]` | - |
| placeholder | 占位 | `string` | `'请输入'` |
| getInputElement | 自定义输入框 | `() => ReactElement` | 内置 `Input` |
| inputProps | 透传 `Input`（不含 ref/value/onChange） | `Partial<InputProps>` | - |
| notFoundContent | 无数据展示 | `React.ReactNode` | `'无匹配结果'` |
| onSearch | 搜索回调 | `(value: string) => void` | - |
| visible | 下拉是否打开 | `RcSelect['open']` | - |
| onVisibleChange | 下拉显隐 | `RcSelect['onDropdownVisibleChange']` | - |
| prefix / suffixIcon | 前后缀 | `React.ReactNode` | - |
| size | 尺寸 | `'small' \| 'middle' \| 'large'` | `'middle'` |
| disabled | 是否禁用 | `boolean` | - |
| rootClassName | 根类名 | `string` | - |

另继承 `Omit<RcSelectProps, 'mode'>` 的其余属性（如 `value`、`onChange`、`filterOption` 等）。

## 变量 {#variables}

<VariablesTable id="AutoComplete"></VariablesTable>

---

## 级联选择 Cascader

## 基础用例 {#basic-usage}

通过 `expandTrigger` 控制展开方式；通过 `changeOnSelect` 开启父节点的选择。

通过 `separator` 自定义分隔符，会同时影响显示与搜索筛选的结果。

**示例：基础用例** — 基础用例

```tsx
'use client';

import { Cascader } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
import { Pane } from 'tweakpane';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';

const Basic = () => {
  const [value, setValue] = useState<string[] | null>([
    '计划1',
    '广告1',
    '创意1',
  ]);

  const [params, setParams] = useState({
    light: false,
    expandTrigger: 'click' as 'click' | 'hover',
    changeOnSelect: false,
    dropdownMatchSelectWidth: false,
    separator: '/',
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'light');
    pane.addBinding(params, 'expandTrigger', {
      options: {
        click: 'click',
        hover: 'hover',
      },
    });

    pane.addBinding(params, 'changeOnSelect');

    pane.addBinding(params, 'dropdownMatchSelectWidth');

    pane.addBinding(params, 'separator', {
      options: {
        '/': '/',
        '>': '>',
      },
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  const options = [
    {
      value: '计划1',
      label: '计划1',
      children: [
        {
          value: '全部广告',
          label: '全部广告',
        },
        {
          type: 'divider',
        },
        {
          value: '广告1',
          label: '广告1',
          children: [
            {
              value: '全部创意',
              label: '全部创意',
            },
            {
              type: 'divider',
            },
            {
              value: '创意1',
              label: '创意1',
            },
            {
              value: '创意2',
              label: '创意2',
            },
          ],
        },
        {
          value: '广告2',
          label: '广告2',
          children: [
            {
              value: '全部创意',
              label: '全部创意',
            },
            {
              type: 'divider',
            },
            {
              value: '创意3',
              label: '创意3',
            },
            {
              value: '创意4',
              label: '创意4',
            },
          ],
        },
      ],
    },
    {
      value: '计划2',
      label: '计划2',
      children: [
        {
          value: '广告2',
          label: '广告2',
          children: [
            {
              value: '创意2',
              label: '创意2',
            },
          ],
        },
      ],
    },
    {
      value: '计划3',
      label: '计划3',
    },
    {
      value: '计划4',
      label: '计划4',
    },
    {
      value: '计划5',
      label: '计划5',
    },
    {
      value: '计划6',
      label: '计划6',
    },
    {
      value: '计划7',
      label: '计划7',
    },
    {
      value: '计划8',
      label: '计划8',
    },
    {
      value: '计划9',
      label: '计划9',
    },
    {
      value: '计划10',
      label: '计划10',
    },
  ];

  return (
    <div>
      <CodeBox className="gap-2 flex-wrap pt-44">
        <div
          ref={tweakpaneContainerRef}
          className="absolute top-2 right-2 opacity-90"
        />
        <Cascader
          key={params.separator}
          getPopupContainer={(e) => e.parentElement}
          showInnerSearch
          separator={params.separator}
          className="w-80"
          options={options}
          placeholder="请选择创意"
          onChange={(v, options, e) => {
            setValue(v);
          }}
          value={value}
          light={params.light}
          expandTrigger={params.expandTrigger}
          changeOnSelect={params.changeOnSelect}
          dropdownMatchSelectWidth={params.dropdownMatchSelectWidth}
        />
      </CodeBox>
      <CodeBlock>{`import { Cascader } from 'one-design-next';
const [value, setValue] = useState<string[] | null>(['计划1', '广告1', '创意1']);

const options = [
  {
    value: '计划1',
    label: '计划1',
    children: [
      {
        value: '广告1',
        label: '广告1',
        children: [
          {
            value: '创意1',
            label: '创意1',
          },
        ],
      },
    ],
  }
];

<Cascader
  showInnerSearch
  separator="${params.separator}"
  options={options}
  placeholder="请选择创意"
  onChange={setValue}
  value={value}
  light={${params.light}}
  expandTrigger={${params.expandTrigger}}
  changeOnSelect={${params.changeOnSelect}}
  dropdownMatchSelectWidth={${params.dropdownMatchSelectWidth}}
/>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 自定义结果或触发元素 {#custom-trigger}

通过 `children` 自定义触发元素；通过 `optionRender` 自定义下拉每一项的渲染；通过 `displayRender` 自定义选择后输入框中的结果展示，其第一个参数 `labels` 为字符串数组，便于拼接或按需省略（例如最后一项含「全部」时省去展示）：

**示例：自定义结果或触发元素** — 自定义结果或触发元素

```tsx
'use client';

import { Cascader } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';

const options = [
  {
    value: '计划1',
    label: '计划1',
    children: [
      {
        value: '全部广告',
        label: '全部广告',
      },
      {
        type: 'divider',
      },
      {
        value: '广告1',
        label: '广告1',
        children: [{ value: '创意1', label: '创意1' }],
      },
      {
        value: '广告2',
        label: '广告2',
        children: [{ value: '创意2', label: '创意2' }],
      },
    ],
  },
  {
    value: '计划2',
    label: '计划2',
    children: [
      {
        value: '广告2',
        label: '广告2',
        children: [{ value: '创意2', label: '创意2' }],
      },
    ],
  },
];

const Demo = () => {
  const [value, setValue] = useState<string[] | null>([
    '计划1',
    '广告1',
    '创意1',
  ]);

  return (
    <div>
      <CodeBox>
        <div className="flex flex-col gap-6">
          <div>
            <div className="mb-2 text-sm text-neutral-600">
              自定义触发元素（children）：
            </div>
            <Cascader
              options={options}
              placeholder="请选择创意"
              onChange={setValue}
              value={value}
            >
              <button className="button">选择创意</button>
            </Cascader>
          </div>
          <div>
            <div className="mb-2 text-sm text-neutral-600">
              displayRender 自定义结果展示（最后一项含「全部」时省去）：
            </div>
            <Cascader
              options={options}
              placeholder="请选择"
              value={value}
              onChange={setValue}
              className="w-[200px]"
              displayRender={(labels) => {
                if (!labels?.length) return undefined;
                const last = String(labels[labels.length - 1] ?? '');
                const toShow = last.includes('全部')
                  ? labels.slice(0, -1)
                  : labels;
                return toShow.length ? toShow.join(' / ') : undefined;
              }}
            />
          </div>
        </div>
      </CodeBox>
      <CodeBlock>{`import { Cascader } from 'one-design-next';

// 自定义触发元素
<Cascader options={options} value={value} onChange={setValue}>
  <button className="button">选择创意</button>
</Cascader>

// displayRender 第一个参数 labels 为 string[]，可拼接或按需省略（如最后一项含「全部」时省去）
<Cascader
  options={options}
  value={value}
  onChange={setValue}
  displayRender={(labels) => {
    if (!labels?.length) return undefined;
    const last = String(labels[labels.length - 1] ?? '');
    const toShow = last.includes('全部') ? labels.slice(0, -1) : labels;
    return toShow.length ? toShow.join(' / ') : undefined;
  }}
/>`}</CodeBlock>
    </div>
  );
};

export default Demo;
```
## 多选 {#multiple-selection}

设置 `multiple` Prop 开启多选，多选时 `value` 与 `onChange` 的类型为 `string[][]`：

**示例：多选** — 多选

```tsx
'use client';

import { Cascader } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';

const Basic = () => {
  const [value, setValue] = useState<string[][] | null>([
    ['计划1', '广告1', '创意1'],
    ['计划2', '广告2', '创意2'],
  ]);

  const options = [
    {
      value: '计划1',
      label: '计划1',
      children: [
        {
          value: '广告1',
          label: '广告1',
          children: [
            {
              value: '创意1',
              label: '创意1',
            },
          ],
        },
      ],
    },
    {
      value: '计划2',
      label: '计划2',
      children: [
        {
          value: '广告2',
          label: '广告2',
          children: [
            {
              value: '创意2',
              label: '创意2',
            },
          ],
        },
      ],
    },
  ];

  return (
    <div>
      <CodeBox>
        <div className="flex flex-col gap-2">
          <Cascader
            mode="multiple"
            options={options}
            placeholder="请选择创意"
            onChange={setValue}
            value={value}
            className="w-[300px]"
            showInnerSearch
            onSearch={(value) => console.log(value)}
          />
        </div>
      </CodeBox>
      <CodeBlock>{`import { Cascader } from 'one-design-next';

const [value, setValue] = useState<string[][] | null>([
  ['计划1', '广告1', '创意1'],
  ['计划2', '广告2', '创意2'],
]);

<Cascader mode="multiple" value={value} />`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 搜索 {#search}

设置 `showInnerSearch` 开启搜索，搜索时会自动过滤 `options` 中的数据。

**示例：搜索** — 搜索

```tsx
'use client';

import { Cascader } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
import { Pane } from 'tweakpane';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';

const Search = () => {
  const [value, setValue] = useState<string[] | string[][] | null>(null);

  const [params, setParams] = useState({
    mode: 'single' as 'single' | 'multiple',
    autoClearSearchValue: true,
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'mode', {
      options: {
        single: 'single',
        multiple: 'multiple',
      },
    });
    pane.addBinding(params, 'autoClearSearchValue');

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  const options = [
    {
      value: 'beijing',
      label: '北京市',
      children: [
        {
          value: 'beijing-city',
          label: '北京市',
          children: [
            {
              value: 'dongcheng',
              label: '东城区',
            },
            {
              value: 'xicheng',
              label: '西城区',
            },
            {
              value: 'chaoyang',
              label: '朝阳区',
            },
          ],
        },
      ],
    },
    {
      value: 'shanghai',
      label: '上海市',
      children: [
        {
          value: 'shanghai-city',
          label: '上海市',
          children: [
            {
              value: 'huangpu',
              label: '黄浦区',
            },
            {
              value: 'xuhui',
              label: '徐汇区',
            },
            {
              value: 'changning',
              label: '长宁区',
            },
            {
              value: 'jingan',
              label: '静安区',
            },
          ],
        },
      ],
    },
    {
      value: 'guangdong',
      label: '广东省',
      children: [
        {
          value: 'guangzhou',
          label: '广州市',
          children: [
            {
              value: 'yuexiu',
              label: '越秀区',
            },
            {
              value: 'liwan',
              label: '荔湾区',
            },
            {
              value: 'haizhu',
              label: '海珠区',
            },
          ],
        },
        {
          value: 'shenzhen',
          label: '深圳市',
          children: [
            {
              value: 'futian',
              label: '福田区',
            },
            {
              value: 'luohu',
              label: '罗湖区',
            },
            {
              value: 'nanshan',
              label: '南山区',
            },
          ],
        },
      ],
    },
    {
      value: 'zhejiang',
      label: '浙江省',
      children: [
        {
          value: 'hangzhou',
          label: '杭州市',
          children: [
            {
              value: 'shangcheng',
              label: '上城区',
            },
            {
              value: 'xihu',
              label: '西湖区',
            },
            {
              value: 'binjiang',
              label: '滨江区',
            },
          ],
        },
        {
          value: 'ningbo',
          label: '宁波市',
          children: [
            {
              value: 'haishu',
              label: '海曙区',
            },
            {
              value: 'jiangdong',
              label: '江东区',
            },
            {
              value: 'jiangbei',
              label: '江北区',
            },
          ],
        },
      ],
    },
  ];

  return (
    <div>
      <CodeBox className="gap-2 flex-wrap pt-[120px]">
        <div
          ref={tweakpaneContainerRef}
          className="absolute top-2 right-2 opacity-90"
        />
        {params.mode === 'multiple' ? (
          <Cascader
            className="w-[320px]"
            mode="multiple"
            options={options}
            placeholder="请选择地区"
            onChange={setValue}
            value={value}
            showInnerSearch
            autoClearSearchValue={params.autoClearSearchValue}
          />
        ) : (
          <Cascader
            className="w-[320px]"
            options={options}
            placeholder="请选择地区"
            onChange={setValue}
            value={value}
            showInnerSearch
            autoClearSearchValue={params.autoClearSearchValue}
          />
        )}
      </CodeBox>
      <CodeBlock>{`import { Cascader } from 'one-design-next';
import { Pane } from 'tweakpane';

const [value, setValue] = useState<string[] | string[][] | null>(null)

const options = [
  {
    value: 'beijing',
    label: '北京市',
    children: [
      {
        value: 'beijing-city',
        label: '北京市',
        children: [
          { value: 'dongcheng', label: '东城区' },
          { value: 'xicheng', label: '西城区' },
          { value: 'chaoyang', label: '朝阳区' },
        ],
      },
    ],
  },
  // ... 更多省市区数据
];

<Cascader
  mode={${params.mode}}
  options={options}
  value={value}
  onChange={setValue}
  showInnerSearch
  autoClearSearchValue={${params.autoClearSearchValue}}
/>`}</CodeBlock>
    </div>
  );
};

export default Search;
```
## 添加 Popover {#add-popover}

为每一项 `option` 添加 `popover` 开启气泡提示。延迟时间 `mouseEnterDelay` 默认为 `0.3s`，可通过 `optionPopoverProps` 透传以修改包括延迟时间在内的 `Popover` 属性。

值得一提的是，每一项都会在字符显示不全时（即显示 `...` 时），自动添加 `Popover`。比如下方的 `计划2` 的 `label` 字符串过长，会自动添加 `Popover`：

**示例：添加 Popover** — 添加 Popover

```tsx
'use client';

import { Cascader } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';

const Basic = () => {
  const [value, setValue] = useState<string[][] | null>([
    ['计划1', '广告1', '创意1'],
  ]);

  const options = [
    {
      value: '计划1',
      label: '计划1',
      popover: '计划1的 Popover',
      children: [
        {
          value: '广告1',
          label: '广告1',
          popover: '广告1的 Popover',
          children: [
            {
              value: '创意1',
              label: '创意1',
              popover: '创意1的 Popover',
            },
          ],
        },
      ],
    },
    {
      value: '计划2',
      label: '计划2计划2计划2计划2计划2计划2计划2计划2',
      children: [
        {
          value: '广告2',
          label: '广告2',
          popover: '广告2的 Popover',
          children: [
            {
              value: '创意2',
              label: '创意2',
              popover: '创意2的 Popover',
            },
          ],
        },
      ],
    },
  ];

  return (
    <div>
      <CodeBox>
        <div className="flex flex-col gap-2">
          <Cascader
            mode="multiple"
            options={options}
            placeholder="请选择创意"
            onChange={setValue}
            value={value}
            className="w-[300px]"
          />
        </div>
      </CodeBox>
      <CodeBlock>{`import { Cascader } from 'one-design-next';

const options = [
  {
    value: '计划1',
    label: '计划1',
    popover: '计划1的 Popover',
  }
];

<Cascader options={options} />`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 自定义字段名 {#custom-field-names}

通过 `fieldNames` 改变默认的 `value`、`label`、`children` 字段映射：

**示例：自定义字段名** — 自定义字段名

```tsx
'use client';

import { Cascader } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';

const Basic = () => {
  const [value, setValue] = useState<string[][] | null>([
    ['计划1', '广告1', '创意1'],
    ['计划2', '广告2', '创意2'],
  ]);

  const options = [
    {
      value: '计划1',
      name: '计划1',
      options: [
        {
          value: '广告1',
          name: '广告1',
          options: [
            {
              value: '创意1',
              name: '创意1',
            },
          ],
        },
      ],
    },
    {
      value: '计划2',
      name: '计划2',
      options: [
        {
          value: '广告2',
          name: '广告2',
          options: [
            {
              value: '创意2',
              name: '创意2',
            },
          ],
        },
      ],
    },
  ];

  return (
    <div>
      <CodeBox>
        <div className="flex flex-col gap-2">
          <Cascader
            mode="multiple"
            options={options}
            placeholder="请选择创意"
            onChange={setValue}
            value={value}
            fieldNames={{
              value: 'value',
              label: 'name',
              children: 'options',
            }}
            className="w-[300px]"
          />
        </div>
      </CodeBox>
      <CodeBlock>{`import { Cascader } from 'one-design-next';

const options = [
  {
    value: '计划1',
    name: '计划1',
    options: [...],
  },
];

<Cascader
  options={options}
  fieldNames={{
    value: 'value',
    label: 'name',
    children: 'options',
  }}
/>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 自定义多选结果 {#custom-multiple-result}

通过 `maxTagCount={0}` 结合 `tagRender` 自定义多选结果的展示，还可通过 `showCheckedStrategy` 控制数据回填的策略，当其为 `child` 时，回填的数据为子节点的值，当其为 `parent` 时，回填的数据为父节点的值：

**示例：自定义标签** — 自定义标签

```tsx
'use client';

import { Cascader } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';

const Basic = () => {
  const [value, setValue] = useState<string[][] | null>();

  const options = [
    {
      value: '计划1',
      label: '计划1',
      children: [
        {
          value: '广告1',
          label: '广告1',
          children: [
            {
              value: '创意1',
              label: '创意1',
            },
            {
              value: '创意2',
              label: '创意2',
            },
          ],
        },
        {
          value: '广告2',
          label: '广告2',
          children: [
            {
              value: '创意3',
              label: '创意3',
            },
          ],
        },
      ],
    },
    {
      value: '计划2',
      label: '计划2',
      children: [
        {
          value: '广告3',
          label: '广告3',
          children: [
            {
              value: '创意4',
              label: '创意4',
            },
            {
              value: '创意5',
              label: '创意5',
            },
          ],
        },
        {
          value: '广告4',
          label: '广告4',
          children: [
            {
              value: '创意6',
              label: '创意6',
            },
            {
              value: '创意7',
              label: '创意7',
            },
            {
              value: '创意8',
              label: '创意8',
            },
          ],
        },
      ],
    },
    {
      value: '计划3',
      label: '计划3',
      children: [
        {
          value: '广告5',
          label: '广告5',
          children: [
            {
              value: '创意9',
              label: '创意9',
            },
          ],
        },
        {
          value: '广告6',
          label: '广告6',
          children: [
            {
              value: '创意10',
              label: '创意10',
            },
            {
              value: '创意11',
              label: '创意11',
            },
          ],
        },
        {
          value: '广告7',
          label: '广告7',
          children: [
            {
              value: '创意12',
              label: '创意12',
            },
          ],
        },
      ],
    },
    {
      value: '计划4',
      label: '计划4',
      children: [
        {
          value: '广告8',
          label: '广告8',
          children: [
            {
              value: '创意13',
              label: '创意13',
            },
            {
              value: '创意14',
              label: '创意14',
            },
            {
              value: '创意15',
              label: '创意15',
            },
            {
              value: '创意16',
              label: '创意16',
            },
            {
              value: '创意17',
              label: '创意17',
            },
          ],
        },
        {
          value: '广告9',
          label: '广告9',
          children: [
            {
              value: '创意18',
              label: '创意18',
            },
          ],
        },
      ],
    },
    {
      value: '计划5',
      label: '计划5',
      children: [
        {
          value: '广告10',
          label: '广告10',
          children: [
            {
              value: '创意19',
              label: '创意19',
            },
            {
              value: '创意20',
              label: '创意20',
            },
          ],
        },
        {
          value: '广告11',
          label: '广告11',
          children: [
            {
              value: '创意21',
              label: '创意21',
            },
            {
              value: '创意22',
              label: '创意22',
            },
            {
              value: '创意23',
              label: '创意23',
            },
          ],
        },
        {
          value: '广告12',
          label: '广告12',
          children: [
            {
              value: '创意24',
              label: '创意24',
            },
            {
              value: '创意25',
              label: '创意25',
            },
          ],
        },
        {
          value: '广告13',
          label: '广告13',
          children: [
            {
              value: '创意26',
              label: '创意26',
            },
          ],
        },
      ],
    },
  ];

  return (
    <div>
      <CodeBox>
        <div className="flex flex-col gap-2">
          <Cascader
            mode="multiple"
            options={options}
            placeholder="请选择创意"
            onChange={setValue}
            value={value}
            className="w-[300px]"
            maxTagCount={0}
            showCheckedStrategy="child"
            tagRender={() => {
              return (
                <div className="flex items-center gap-1">
                  <div className="flex-none">逗号隔开，单行省略:</div>
                  {value && value.length > 0 && (
                    <div className="whitespace-nowrap overflow-hidden text-ellipsis min-w-0">
                      {value.map((o) => o[o.length - 1]).join(', ')}
                    </div>
                  )}
                </div>
              );
            }}
          />
        </div>
      </CodeBox>
      <CodeBlock>{`import { Cascader } from 'one-design-next';

<Cascader
  maxTagCount={0}
  tagRender={() => {
    return (
      <div className="flex items-center gap-1">
        <div className="flex-none">逗号隔开，单行省略:</div>
        {value && value.length > 0 && (
          <div className="whitespace-nowrap overflow-hidden text-ellipsis min-w-0">
            {value.map((o) => o[0]).join(', ')}
          </div>
        )}
      </div>
    );
  }}    
/>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 全选 {#full-select}

`Cascader` 不支持全选。你可以加入一个名为全选的子节点，并加入 `{ type: 'divider'}` 来分隔选项：

**示例：全选** — 全选

```tsx
'use client';

import { Cascader } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';

const Basic = () => {
  const [value, setValue] = useState<string[][] | null>([
    ['计划1', '广告1', '创意1'],
  ]);

  const options = [
    {
      value: '计划1',
      label: '计划1',
      children: [
        {
          value: '全部广告',
          label: '全部广告',
        },
        {
          type: 'divider',
        },
        {
          value: '广告1',
          label: '广告1',
          children: [
            {
              value: '全部创意',
              label: '全部创意',
            },
            {
              type: 'divider',
            },
            {
              value: '创意1',
              label: '创意1',
            },
            {
              value: '创意2',
              label: '创意2',
            },
          ],
        },
        {
          value: '广告2',
          label: '广告2',
          children: [
            {
              value: '全部创意',
              label: '全部创意',
            },
            {
              type: 'divider',
            },
            {
              value: '创意3',
              label: '创意3',
            },
            {
              value: '创意4',
              label: '创意4',
            },
          ],
        },
      ],
    },
  ];

  return (
    <div>
      <CodeBox>
        <div className="flex flex-col gap-2">
          <Cascader
            mode="single"
            options={options}
            placeholder="请选择创意"
            onChange={setValue}
            value={value}
            className="w-[300px]"
            showInnerSearch
            onSearch={(value) => console.log(value)}
          />
        </div>
      </CodeBox>
      <CodeBlock>{`import { Cascader } from 'one-design-next';

const options = [
  {
    value: '计划1',
    label: '计划1',
    children: [
      {
        value: '全部广告',
        label: '全部广告',
      },
      {
        type: 'divider',
      },
      {
        value: '广告1',
        label: '广告1',
        children: [
          {
            value: '全部创意',
            label: '全部创意',
          },
          {
            type: 'divider',
          },
          {
            value: '创意1',
            label: '创意1',
          },
          {
            value: '创意2',
            label: '创意2',
          },
        ],
      },
      {
        value: '广告2',
        label: '广告2',
        children: [
          {
            value: '全部创意',
            label: '全部创意',
          },
          {
            type: 'divider',
          },
          {
            value: '创意3',
            label: '创意3',
          },
          {
            value: '创意4',
            label: '创意4',
          },
        ],
      },
    ],
  },
];

<Cascader mode="single" options={options} />`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 面板 {#panel}

`Cascader.Panel` 单独使用：

**示例：面板** — 面板

```tsx
'use client';

import { Cascader, Icon, Input } from 'one-design-next';
import type { DefaultOptionType } from 'rc-cascader';
import React, { useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';

const Basic = () => {
  const [value, setValue] = useState<string[] | null>([
    '计划1',
    '广告1',
    '创意1',
  ]);

  const [multipleValue, setMultipleValue] = useState<string[][] | null>(null);

  const options = [
    {
      value: '计划1',
      label: '计划1',
      children: [
        {
          value: '广告1',
          label: '广告1',
          children: [
            {
              value: '创意1',
              label: '创意1',
            },
          ],
        },
      ],
    },
    {
      value: '计划2',
      label: '计划2',
      children: [
        {
          value: '广告2',
          label: '广告2',
          children: [
            {
              value: '创意2',
              label: '创意2',
            },
            {
              value: '创意3',
              label: '创意3',
            },
          ],
        },
        {
          value: '广告3',
          label: '广告3',
          children: [
            {
              value: '创意4',
              label: '创意4',
            },
            {
              value: '创意5',
              label: '创意5',
            },
          ],
        },
        {
          value: '广告4',
          label: '广告4',
        },
      ],
    },
  ];

  const handleChange = (
    value: string[] | null,
    selectOptions: DefaultOptionType[],
  ) => {
    setValue(value);
  };

  const handleChangeMultiple = (
    value: string[][] | null,
    selectOptions: DefaultOptionType[],
  ) => {
    setMultipleValue(value);
  };

  return (
    <div>
      <CodeBox>
        <div className="flex flex-col gap-2 w-full">
          <div className="text-sm text-neutral-700">单选：</div>
          <Cascader.Panel
            options={options}
            onChange={handleChange}
            value={value}
          />
          <div className="text-sm text-neutral-700">多选：</div>
          <Cascader.Panel
            mode="multiple"
            options={options}
            onChange={handleChangeMultiple}
            value={multipleValue}
          />
          <div className="text-sm text-neutral-700">与输入框结合：</div>
          <div className="flex flex-col border border-[var(--odn-color-black-6)] rounded-md">
            <Input light leftElement={<Icon name="search" />} />
            <div className="border-t border-[var(--odn-color-black-6)]">
              <Cascader.Panel
                mode="multiple"
                options={options}
                onChange={handleChangeMultiple}
                value={multipleValue}
                className="w-full border-none"
              />
            </div>
          </div>
        </div>
      </CodeBox>
      <CodeBlock>{`import { Cascader } from 'one-design-next';

// value: ${value?.join(',')}
<Cascader.Panel />

// value: ${multipleValue?.map((item) => item.join(',')).join(',')}
<Cascader.Panel mode="multiple" />`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 面板在 Dialog 内的应用 {#panel-in-dialog}

如翼平台 Dialog 用例：

**示例：dialog** — dialog

```tsx
'use client';

import {
  AutoComplete,
  Button,
  Cascader,
  Dialog,
  ScrollArea,
} from 'one-design-next';
import { type DefaultOptionType } from 'rc-cascader';
import React, { useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
import { options } from './options';

const Basic = () => {
  const [selectOptions, setSelectOptions] = useState<
    DefaultOptionType[] | null
  >();
  const [value, setValue] = useState<number[][] | null>(null);
  const [visible, setVisible] = useState(false);

  return (
    <div>
      <CodeBox>
        <div className="flex flex-col gap-2">
          <button className="button" onClick={() => setVisible(true)}>
            打开 Dialog
          </button>
          <Dialog
            visible={visible}
            onCancel={() => setVisible(false)}
            onConfirm={() => setVisible(false)}
            onVisibleChange={setVisible}
            title="设备品牌型号"
            className="w-[960px] h-[672px]"
            bordered
            style={{
              '--odn-dialog-body-padding': '0',
            }}
          >
            <div className="flex h-full">
              <div className="flex-1 flex flex-col min-w-0">
                <div className="flex-none px-3 py-4">
                  <AutoComplete
                    // options={options}
                    placeholder="AutoComplete"
                    // onChange={setValue}
                    // value={value}
                    className="w-full"
                  />
                </div>
                <div className="flex-1 min-h-0 border-t border-neutral-200">
                  <Cascader.Panel
                    mode="multiple"
                    options={options}
                    placeholder="请选择创意"
                    onChange={(value, selectOptions) => {
                      setValue(value);
                      setSelectOptions(selectOptions);
                    }}
                    value={value}
                    fieldNames={{
                      value: 'value',
                      label: 'name',
                      children: 'options',
                      // popover: "fullName",
                    }}
                    className="w-full h-full"
                    style={{
                      '--odn-cascader-panel-border': 'none',
                    }}
                  />
                </div>
              </div>
              <div className="flex flex-col flex-none w-[320px] border-l border-neutral-200">
                <div className="flex-none px-6 pt-6 pb-3 flex items-center justify-between">
                  <div>已选 {value?.length || 0} 项</div>
                  <a
                    href="https://wxad.design/abc"
                    target="_blank"
                    className="text-link"
                    onClick={() => setValue(null)}
                  >
                    清空
                  </a>
                </div>
                <ScrollArea className="flex-1 pl-6 pr-4 min-h-0">
                  {selectOptions?.map((item, index) => {
                    const content = item[item.length - 1].name;
                    return (
                      <div
                        className="flex items-center justify-between h-9"
                        key={index}
                      >
                        <div className="text-ellipsis overflow-hidden whitespace-nowrap">
                          {content}
                        </div>
                        <Button
                          icon="delete"
                          light
                          onClick={() => {
                            setSelectOptions(
                              selectOptions?.filter((_, i) => i !== index),
                            );
                            setValue(
                              value?.filter((_, i) => i !== index) || null,
                            );
                          }}
                        />
                      </div>
                    );
                  })}
                </ScrollArea>
              </div>
            </div>
          </Dialog>
        </div>
      </CodeBox>
      <CodeBlock>
        {`import {
  AutoComplete,
  Button,
  Cascader,
  Dialog,
  ScrollArea,
} from 'one-design-next';
import { type DefaultOptionType } from 'rc-cascader';

<Dialog
  visible={visible}
  onCancel={() => setVisible(false)}
  onConfirm={() => setVisible(false)}
  onVisibleChange={setVisible}
  title="设备品牌型号"
  className="w-[960px] h-[672px]"
  bordered
  style={{
    '--odn-dialog-body-padding': '0',
  }}
>
  <div className="flex h-full">
    <div className="flex-1 flex flex-col min-w-0">
      <div className="flex-none px-3 py-4">
        <AutoComplete
          // options={options}
          placeholder="AutoComplete"
          // onChange={setValue}
          // value={value}
          className="w-full"
        />
      </div>
      <div className="flex-1 min-h-0 border-t border-neutral-200">
        <Cascader.Panel
          mode="multiple"
          options={options}
          placeholder="请选择创意"
          onChange={(value, selectOptions) => {
            setValue(value as number[][]);
            setSelectOptions(selectOptions);
          }}
          value={value}
          fieldNames={{
            value: 'value',
            label: 'name',
            children: 'options',
            // popover: "fullName",
          }}
          className="w-full h-full"
          style={{
            '--odn-cascader-panel-border': 'none',
          }}
        />
      </div>
    </div>
    <div className="flex flex-col flex-none w-[320px] border-l border-neutral-200">
      <div className="flex-none px-6 pt-6 pb-3 flex items-center justify-between">
        <div>已选 {value?.length || 0} 项</div>
        <a
          href="https://wxad.design/abc"
          target="_blank"
          className="text-link"
          onClick={() => setValue(null)}
        >
          清空
        </a>
      </div>
      <ScrollArea className="flex-1 pl-6 pr-4 min-h-0">
        {selectOptions?.map((item, index) => {
          const content = item[item.length - 1].name;
          return (
            <div
              className="flex items-center justify-between h-9"
              key={index}
            >
              <div className="text-ellipsis overflow-hidden whitespace-nowrap">
                {content}
              </div>
              <Button
                icon="delete"
                light
                onClick={() => {
                  setSelectOptions(
                    selectOptions?.filter((_, i) => i !== index),
                  );
                  setValue(
                    value?.filter((_, i) => i !== index) || null,
                  );
                }}
              />
            </div>
          );
        })}
      </ScrollArea>
    </div>
  </div>
</Dialog>`}
      </CodeBlock>
    </div>
  );
};

export default Basic;
```
## 面板的两种宽度模式 {#panel-width-modes}

开启 `autoMaxWidth` 后，`Cascader` 会根据 `options` 的 深度来设置 `Cascader.Panel` 的宽度。比如当深度为 2 时，每列最大宽度为 50%，当深度为 3 时，每列最大宽度为 33.3%，以此类推。

这样设计的目的，一是为了保证用户一开始就能清楚深度，二是保证每列的宽度不会跳动。你也可以设置 `autoMaxWidth` 为 `false` 来禁用这个设计：

**示例：面板的两种宽度模式** — 面板的两种宽度模式

```tsx
'use client';

import { Cascader } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';

const Basic = () => {
  const [multipleValue, setMultipleValue] = useState<string[][] | null>(null);

  const options = [
    {
      value: '计划1',
      label: '计划1',
      children: [
        {
          value: '广告1',
          label: '广告1',
          children: [
            {
              value: '创意1',
              label: '创意1',
            },
          ],
        },
      ],
    },
    {
      value: '计划2',
      label: '计划2',
      children: [
        {
          value: '广告2',
          label: '广告2',
          children: [
            {
              value: '创意2',
              label: '创意2',
            },
            {
              value: '创意3',
              label: '创意3',
            },
          ],
        },
        {
          value: '广告3',
          label: '广告3',
          children: [
            {
              value: '创意4',
              label: '创意4',
            },
            {
              value: '创意5',
              label: '创意5',
            },
          ],
        },
        {
          value: '广告4',
          label: '广告4',
        },
      ],
    },
  ];

  const handleChangeMultiple = (value: string[][] | null) => {
    setMultipleValue(value);
  };

  return (
    <div>
      <CodeBox>
        <div className="flex flex-col gap-2 w-full">
          <div className="text-sm text-neutral-700">autoMaxWidth: true</div>
          <Cascader.Panel
            mode="multiple"
            options={options}
            onChange={handleChangeMultiple}
            value={multipleValue}
            autoMaxWidth
          />
          <div className="text-sm text-neutral-700">autoMaxWidth: false</div>
          <Cascader.Panel
            mode="multiple"
            options={options}
            onChange={handleChangeMultiple}
            value={multipleValue}
            autoMaxWidth={false}
          />
        </div>
      </CodeBox>
      <CodeBlock>{`import { Cascader } from 'one-design-next';
      
<Cascader.Panel autoMaxWidth />`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 状态联动 {#state-linkage}

使用第一个的 `value` 来禁用第二个的 `options`。可为每一项添加 `disableCheckbox` 来禁用该项可选，但是仍可展开。

这样做的原因解释起来有些困难：`Cascader` 不会将 `disabled` 项算作可选择的叶节点。因此当 `iPhone` 项被禁用后，`iPad` 项成为了唯一可选择的叶节点，这时选择了 `iPad` 后，值就变成了 `苹果`，但这可能并不是业务期望的：

**示例：状态联动** — 状态联动

```tsx
'use client';

import { Cascader } from 'one-design-next';
import React, { useEffect, useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';

const options = [
  {
    value: 'apple',
    name: '苹果',
    options: [
      {
        value: 'iphone',
        name: 'iPhone',
        options: [
          {
            value: 'iphone-15',
            name: 'iPhone 15',
          },
          {
            value: 'iphone-14',
            name: 'iPhone 14',
          },
          {
            value: 'iphone-13',
            name: 'iPhone 13',
          },
        ],
      },
      {
        value: 'ipad',
        name: 'iPad',
        options: [
          {
            value: 'ipad-pro',
            name: 'iPad Pro',
          },
          {
            value: 'ipad-air',
            name: 'iPad Air',
          },
        ],
      },
    ],
  },
  {
    value: 'samsung',
    name: '三星',
    options: [
      {
        value: 'galaxy',
        name: 'Galaxy',
        options: [
          {
            value: 'galaxy-s24',
            name: 'Galaxy S24',
          },
          {
            value: 'galaxy-s23',
            name: 'Galaxy S23',
          },
        ],
      },
      {
        value: 'galaxy-tab',
        name: 'Galaxy Tab',
        options: [
          {
            value: 'galaxy-tab-s9',
            name: 'Galaxy Tab S9',
          },
        ],
      },
    ],
  },
  {
    value: 'xiaomi',
    name: '小米',
    options: [
      {
        value: 'mi',
        name: '小米手机',
        options: [
          {
            value: 'mi-14',
            name: '小米14',
          },
          {
            value: 'mi-13',
            name: '小米13',
          },
        ],
      },
    ],
  },
];

const StatusLinkage = () => {
  const [firstValue, setFirstValue] = useState<(string | number)[][] | null>([
    ['apple', 'iphone'],
  ]);
  const [secondValue, setSecondValue] = useState<(string | number)[][] | null>([
    ['apple', 'ipad'],
  ]);

  // 两个 Cascader 共用的选项
  const baseOptions = options;

  // 第一个 Cascader 的选项 - 根据第二个选择禁用对应选项
  const getFirstOptions = () => {
    if (!secondValue || secondValue.length === 0) {
      return baseOptions;
    }

    // 获取所有已选择的路径
    const selectedPaths = secondValue;

    // 递归禁用选中的选项
    const disableSelectedOption = (
      options: any[],
      selectedPaths: (string | number)[][],
      currentPath: (string | number)[] = [],
    ): any[] => {
      return options.map((option) => {
        const newPath = [...currentPath, option.value];

        // 检查当前路径是否完全匹配已选择的路径（叶子节点）
        const isExactMatch = selectedPaths.some((selectedPath) => {
          return (
            selectedPath.length === newPath.length &&
            selectedPath.every((value, index) => value === newPath[index])
          );
        });

        // 检查当前路径是否是已选择路径的前缀（父级节点）
        const isParentOfSelected = selectedPaths.some((selectedPath) => {
          return (
            selectedPath.length > newPath.length &&
            newPath.every((value, index) => value === selectedPath[index])
          );
        });

        return {
          ...option,
          disabled: isExactMatch, // 只有完全匹配的叶子节点才 disabled
          disableCheckbox: isParentOfSelected, // 父级节点 disableCheckbox
          options: option.options
            ? disableSelectedOption(option.options, selectedPaths, newPath)
            : undefined,
        };
      });
    };

    return disableSelectedOption(baseOptions, selectedPaths);
  };

  // 第二个 Cascader 的选项 - 根据第一个选择禁用对应选项
  const getSecondOptions = () => {
    if (!firstValue || firstValue.length === 0) {
      return baseOptions;
    }

    // 获取所有已选择的路径
    const selectedPaths = firstValue;

    // 递归禁用选中的选项
    const disableSelectedOption = (
      options: any[],
      selectedPaths: (string | number)[][],
      currentPath: (string | number)[] = [],
    ): any[] => {
      return options.map((option) => {
        const newPath = [...currentPath, option.value];

        // 检查当前路径是否完全匹配已选择的路径（叶子节点）
        const isExactMatch = selectedPaths.some((selectedPath) => {
          return (
            selectedPath.length === newPath.length &&
            selectedPath.every((value, index) => value === newPath[index])
          );
        });

        // 检查当前路径是否是已选择路径的前缀（父级节点）
        const isParentOfSelected = selectedPaths.some((selectedPath) => {
          return (
            selectedPath.length > newPath.length &&
            newPath.every((value, index) => value === selectedPath[index])
          );
        });

        return {
          ...option,
          disabled: isExactMatch, // 只有完全匹配的叶子节点才 disabled
          disableCheckbox: isParentOfSelected, // 父级节点 disableCheckbox
          options: option.options
            ? disableSelectedOption(option.options, selectedPaths, newPath)
            : undefined,
        };
      });
    };

    return disableSelectedOption(baseOptions, selectedPaths);
  };

  // 相互禁用：当任一选择改变时，清空另一个选择中冲突的项
  useEffect(() => {
    if (!firstValue || firstValue.length === 0) {
      return;
    }

    if (!secondValue || secondValue.length === 0) {
      return;
    }

    // 过滤掉与第一个选择冲突的第二个选择项
    const filteredSecondValue = secondValue.filter((secondPath) => {
      return !firstValue.some((firstPath) => {
        return (
          firstPath.length === secondPath.length &&
          firstPath.every((value, index) => value === secondPath[index])
        );
      });
    });

    // 过滤掉与第二个选择冲突的第一个选择项
    const filteredFirstValue = firstValue.filter((firstPath) => {
      return !secondValue.some((secondPath) => {
        return (
          firstPath.length === secondPath.length &&
          firstPath.every((value, index) => value === secondPath[index])
        );
      });
    });

    // 更新第二个选择
    if (filteredSecondValue.length !== secondValue.length) {
      setSecondValue(
        filteredSecondValue.length > 0 ? filteredSecondValue : null,
      );
    }

    // 更新第一个选择
    if (filteredFirstValue.length !== firstValue.length) {
      setFirstValue(filteredFirstValue.length > 0 ? filteredFirstValue : null);
    }
  }, [firstValue, secondValue]);

  return (
    <div>
      <CodeBox className="gap-4 flex-wrap">
        <div className="flex flex-col gap-4">
          <div>
            <div className="text-xs text-neutral-500">
              {firstValue?.join(' / ')}
            </div>
            <Cascader
              mode="multiple"
              options={getFirstOptions()}
              fieldNames={{
                value: 'value',
                label: 'name',
                children: 'options',
              }}
              placeholder="请选择设备型号"
              onChange={setFirstValue}
              value={firstValue as string[][] | null}
              className="w-[300px]"
              showInnerSearch
              autoClearSearchValue={false}
            >
              {/* <Button>
                <div className="w-[320px] flex items-center justify-between">
                  <span>从 品牌/系列/机型</span>
                  <Icon
                    style={{ color: 'var(--odn-select-arrow-color)' }}
                    name="down"
                  />
                </div>
              </Button> */}
            </Cascader>
          </div>
          <div>
            <div className="text-xs text-neutral-500">
              {secondValue?.join(' / ')}
            </div>
            <Cascader
              mode="multiple"
              options={getSecondOptions()}
              fieldNames={{
                value: 'value',
                label: 'name',
                children: 'options',
              }}
              placeholder="请选择设备型号"
              onChange={setSecondValue}
              value={secondValue as string[][] | null}
              className="w-[300px]"
              showInnerSearch
              autoClearSearchValue={false}
            >
              {/* <Button>
                <div className="w-[320px] flex items-center justify-between">
                  <span>换至 品牌/系列/机型</span>
                  <Icon
                    style={{ color: 'var(--odn-select-arrow-color)' }}
                    name="down"
                  />
                </div>
              </Button> */}
            </Cascader>
          </div>
        </div>
      </CodeBox>
      <CodeBlock>{`import { Button, Cascader, Icon } from 'one-design-next';

const options = [
  {
    value: 'apple',
    name: '苹果',
    options: [
      {
        value: 'iphone',
        name: 'iPhone',
        options: [
          { value: 'iphone-15', name: 'iPhone 15' },
          { value: 'iphone-14', name: 'iPhone 14' },
          { value: 'iphone-13', name: 'iPhone 13' },
        ],
      },
      {
        value: 'ipad',
        name: 'iPad',
        options: [
          { value: 'ipad-pro', name: 'iPad Pro' },
          { value: 'ipad-air', name: 'iPad Air' },
        ],
      },
    ],
  },
  {
    value: 'samsung',
    name: '三星',
    options: [
      {
        value: 'galaxy',
        name: 'Galaxy',
        options: [
          { value: 'galaxy-s24', name: 'Galaxy S24' },
          { value: 'galaxy-s23', name: 'Galaxy S23' },
        ],
      },
      {
        value: 'galaxy-tab',
        name: 'Galaxy Tab',
        options: [
          { value: 'galaxy-tab-s9', name: 'Galaxy Tab S9' },
        ],
      },
    ],
  },
  {
    value: 'xiaomi',
    name: '小米',
    options: [
      {
        value: 'mi',
        name: '小米手机',
        options: [
          { value: 'mi-14', name: '小米14' },
          { value: 'mi-13', name: '小米13' },
        ],
      },
    ],
  },
];

const [firstValue, setFirstValue] = useState<(string | number)[][] | null>(null);
const [secondValue, setSecondValue] = useState<(string | number)[][] | null>(null);

// 两个 Cascader 共用的选项
const baseOptions = options;

// 第一个 Cascader 的选项 - 根据第二个选择禁用对应选项
const getFirstOptions = () => {
  if (!secondValue || secondValue.length === 0) {
    return baseOptions;
  }

  // 获取所有已选择的路径
  const selectedPaths = secondValue;

  // 递归禁用选中的选项
  const disableSelectedOption = (options, selectedPaths, currentPath = []) => {
    return options.map((option) => {
      const newPath = [...currentPath, option.value];
      
      // 检查当前路径是否完全匹配已选择的路径（叶子节点）
      const isExactMatch = selectedPaths.some((selectedPath) => {
        return selectedPath.length === newPath.length && 
               selectedPath.every((value, index) => value === newPath[index]);
      });
      
      // 检查当前路径是否是已选择路径的前缀（父级节点）
      const isParentOfSelected = selectedPaths.some((selectedPath) => {
        return selectedPath.length > newPath.length &&
               newPath.every((value, index) => value === selectedPath[index]);
      });
      
      return {
        ...option,
        disabled: isExactMatch, // 只有完全匹配的叶子节点才 disabled
        disableCheckbox: isParentOfSelected, // 父级节点 disableCheckbox
        options: option.options ? disableSelectedOption(option.options, selectedPaths, newPath) : undefined,
      };
    });
  };

  return disableSelectedOption(baseOptions, selectedPaths);
};

// 第二个 Cascader 的选项 - 根据第一个选择禁用对应选项
const getSecondOptions = () => {
  if (!firstValue || firstValue.length === 0) {
    return baseOptions;
  }

  // 获取所有已选择的路径
  const selectedPaths = firstValue;

  // 递归禁用选中的选项
  const disableSelectedOption = (options, selectedPaths, currentPath = []) => {
    return options.map((option) => {
      const newPath = [...currentPath, option.value];
      
      // 检查当前路径是否完全匹配已选择的路径（叶子节点）
      const isExactMatch = selectedPaths.some((selectedPath) => {
        return selectedPath.length === newPath.length && 
               selectedPath.every((value, index) => value === newPath[index]);
      });
      
      // 检查当前路径是否是已选择路径的前缀（父级节点）
      const isParentOfSelected = selectedPaths.some((selectedPath) => {
        return selectedPath.length > newPath.length &&
               newPath.every((value, index) => value === selectedPath[index]);
      });
      
      return {
        ...option,
        disabled: isExactMatch, // 只有完全匹配的叶子节点才 disabled
        disableCheckbox: isParentOfSelected, // 父级节点 disableCheckbox
        options: option.options ? disableSelectedOption(option.options, selectedPaths, newPath) : undefined,
      };
    });
  };

  return disableSelectedOption(baseOptions, selectedPaths);
};

// 相互禁用：当任一选择改变时，清空另一个选择中冲突的项
useEffect(() => {
  if (!firstValue || firstValue.length === 0) {
    return;
  }

  if (!secondValue || secondValue.length === 0) {
    return;
  }

  // 过滤掉与第一个选择冲突的第二个选择项
  const filteredSecondValue = secondValue.filter((secondPath) => {
    return !firstValue.some((firstPath) => {
      return (
        firstPath.length === secondPath.length &&
        firstPath.every((value, index) => value === secondPath[index])
      );
    });
  });

  // 过滤掉与第二个选择冲突的第一个选择项
  const filteredFirstValue = firstValue.filter((firstPath) => {
    return !secondValue.some((secondPath) => {
      return (
        firstPath.length === secondPath.length &&
        firstPath.every((value, index) => value === secondPath[index])
      );
    });
  });

  // 更新第二个选择
  if (filteredSecondValue.length !== secondValue.length) {
    setSecondValue(
      filteredSecondValue.length > 0 ? filteredSecondValue : null,
    );
  }

  // 更新第一个选择
  if (filteredFirstValue.length !== firstValue.length) {
    setFirstValue(
      filteredFirstValue.length > 0 ? filteredFirstValue : null,
    );
  }
}, [firstValue, secondValue]);

<div className="flex flex-col gap-4">
  <Cascader
    mode="multiple"
    options={getFirstOptions()}
    fieldNames={{
      value: 'value',
      label: 'name',
      children: 'options',
    }}
    onChange={setFirstValue}
    value={firstValue as string[][] | null}
    className="w-[300px]"
    showInnerSearch
    autoClearSearchValue={false}
  >
    <Button>
      <div className="w-[320px] flex items-center justify-between">
        <span>从 品牌/系列/机型</span>
        <Icon
          style={{ color: 'var(--odn-select-arrow-color)' }}
          name="down"
        />
      </div>
    </Button>
  </Cascader>
  <Cascader
    mode="multiple"
    options={getSecondOptions()}
    fieldNames={{
      value: 'value',
      label: 'name',
      children: 'options',
    }}
    onChange={setSecondValue}
    value={secondValue as string[][] | null}
    className="w-[300px]"
    showInnerSearch
    autoClearSearchValue={false}
  >
    <Button>
      <div className="w-[320px] flex items-center justify-between">
        <span>换至 品牌/系列/机型</span>
        <Icon
          style={{ color: 'var(--odn-select-arrow-color)' }}
          name="down"
        />
      </div>
    </Button>
  </Cascader>
</div>`}</CodeBlock>
    </div>
  );
};

export default StatusLinkage;
```
## API {#api}

基于 `rc-cascader`，类型为 `CascaderProps`（`BaseCascaderProps` + `mode` / `value` / `onChange`）。

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| mode | 单选 / 多选 | `'single' \| 'multiple'` | - |
| value / defaultValue | 选中值 | 泛型 `V` | - |
| onChange | 变化 | `(value, selectOptions, e?) => void` | - |
| options | 数据 | `DefaultOptionType[]` | - |
| size | 尺寸 | `'small' \| 'medium' \| 'large'` | `'medium'` |
| disabled / placeholder / allowClear | 常见 | 见左 | `'请选择'` |
| showSearch | 是否搜索 | `boolean` | `false` |
| showInnerSearch | 下拉内搜索框 | `boolean` | `false` |
| searchValue / onSearch | 搜索受控 | `string` / `(v) => void` | - |
| autoClearSearchValue | 选后清空搜索 | `boolean` | - |
| searchFilter / searchRender / searchLimit | 搜索定制 | 见类型 | - |
| showCheckedStrategy | 多选回填策略 | `'child' \| 'parent'` | - |
| separator | 显示与搜索分隔符 | `string` | - |
| optionRender | 自定义选项 | `(option) => ReactNode` | - |
| optionPopoverProps | 选项级 Popover | `Record<string, unknown>` | - |
| visible / onVisibleChange | 下拉显隐 | 同 rc | - |
| light | 轻量样式 | `boolean` | `false` |
| dropdownClassName | 下拉类名 | `string` | - |

另继承 `Omit<RcCascaderProps, ...>` 中其余属性（如 `fieldNames`、`loadData` 等）。组件附带 `Cascader.Panel`。

## 变量 {#variables}

<VariablesTable id="Cascader"></VariablesTable>

---

## 勾选 Checkbox

## 基础用例 {#basic-usage}

通过 `helper` 属性可以设置是否启用问号气泡提示：

**示例：基础用例** — 基础用例

```tsx
'use client';

import { Checkbox } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

const Basic = () => {
  const [value, setValue] = useState(['default']);
  const [params, setParams] = useState({
    size: 'medium',
    layout: 'horizontal' as 'horizontal' | 'vertical' | 'grid',
    helper: true,
    helperIcon: false,
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'size', {
      options: {
        small: 'small',
        medium: 'medium',
        large: 'large',
      },
    });

    pane.addBinding(params, 'layout', {
      options: {
        horizontal: 'horizontal',
        vertical: 'vertical',
        grid: 'grid',
      },
    });

    pane.addBinding(params, 'helper', {
      type: 'boolean',
    });

    pane.addBinding(params, 'helperIcon', {
      type: 'boolean',
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <div className="flex flex-col gap-3">
          <Checkbox
            indeterminate={value.length > 0 && value.length < 3}
            checked={value.length === 3}
            size={params.size as 'small' | 'medium' | 'large'}
            onChange={(checked) => {
              setValue(checked ? ['default', 'comfortable', 'compact'] : []);
            }}
          >
            Select All
          </Checkbox>
          <Checkbox.Group
            layout={params.layout}
            onChange={(value) => setValue(value)}
            value={value}
            size={params.size as 'small' | 'medium' | 'large'}
            helperIcon={params.helperIcon ? 'help-circle' : undefined}
            options={[
              {
                label: 'Default',
                value: 'default',
                helper: params.helper ? 'This is a helper text' : undefined,
              },
              {
                label: 'Comfortable',
                value: 'comfortable',
                helper: params.helper ? 'This is a helper text' : undefined,
              },
              {
                label: 'Compact',
                value: 'compact',
                helper: params.helper ? 'This is a helper text' : undefined,
              },
            ]}
          />
        </div>
      </CodeBox>
      <CodeBlock>{`import { Checkbox } from 'one-design-next';

// value: ${value}
<Checkbox.Group
  onChange={(value) => setValue(value)}
  value={value}
  size="${params.size}"
  layout="${params.layout}"
  helperIcon=${params.helperIcon ? "'help-circle'" : 'undefined'}
  options={[
    {
      label: 'Default',
      value: 'default',
      disabled: true,
      helper: ${params.helper ? "'This is a helper text'" : 'undefined'},
    },
    {
      label: 'Comfortable',
      value: 'comfortable',
      helper: ${params.helper ? "'This is a helper text'" : 'undefined'},
    },
    {
      label: 'Compact',
      value: 'compact',
      helper: ${params.helper ? "'This is a helper text'" : 'undefined'},
    },
  ]}
/>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 栅格布局 {#grid-layout}

通过 `layout` 属性可以设置栅格布局方式，支持 `horizontal`、`vertical`、`grid` 三种方式。

通过 `ellipsis` 属性可以设置是否启用文本省略，通过 `ellipsisPopoverProps` 属性可以设置文本省略的弹出框的属性。

**示例：栅格布局** — 栅格布局

```tsx
'use client';

import { Checkbox } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

const Grid = () => {
  const [value, setValue] = useState<string[]>([]);
  const [params, setParams] = useState({
    size: 'medium' as 'small' | 'medium' | 'large',
    columns: 3,
    ellipsis: true,
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'size', {
      options: {
        small: 'small',
        medium: 'medium',
        large: 'large',
      },
    });

    pane.addBinding(params, 'ellipsis', {
      options: {
        true: true,
        false: false,
      },
    });

    pane.addBinding(params, 'columns', {
      min: 1,
      max: 6,
      step: 1,
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  const options = Array.from({ length: 12 }, (_, i) => ({
    label: `选项选项选项选项选项 ${i + 1}`,
    value: `option-${i + 1}`,
  }));

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <div className="flex flex-col gap-3 w-1/2">
          <Checkbox
            indeterminate={value.length > 0 && value.length < options.length}
            checked={value.length === options.length}
            size={params.size}
            onChange={(checked) => {
              setValue(checked ? options.map((opt) => opt.value) : []);
            }}
          >
            全选
          </Checkbox>
          <Checkbox.Group
            layout="grid"
            columns={params.columns}
            onChange={(val) => setValue(val)}
            value={value}
            size={params.size}
            options={options}
            ellipsis={params.ellipsis}
            ellipsisPopoverProps={{
              placement: 'top',
            }}
          />
        </div>
      </CodeBox>
      <CodeBlock>{`import { Checkbox } from 'one-design-next';

// value: ${JSON.stringify(value)}
<Checkbox.Group
  layout="grid"
  columns={${params.columns}}
  onChange={(value) => setValue(value)}
  value={value}
  size="${params.size}"
  ellipsis={${params.ellipsis}}
  options={[${options
    .map(
      (opt) => `    {
      label: '${opt.label}',
      value: '${opt.value}',
    }`,
    )
    .join(',\n')}
  ]}
/>`}</CodeBlock>
    </div>
  );
};

export default Grid;
```
## API {#api}

### Checkbox

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| checked | 是否选中（受控） | `boolean \| null` | `null` |
| children | 标签文案 | `React.ReactNode` | - |
| className | 类名 | `string` | - |
| disabled | 是否禁用 | `boolean` | `false` |
| helper | 问号气泡内容 | `React.ReactNode` | - |
| helperIcon | 问号图标 | `iconNames[number]` | - |
| helperProps | 透传给 Popover | `PopoverProps` | - |
| ellipsis | 是否对文案省略 | `boolean` | - |
| ellipsisPopoverProps | 透传给 EllipsisText | `Omit<PopoverProps, 'popup' \| 'children'>` | - |
| indeterminate | 半选样式（全选场景） | `boolean` | `false` |
| onChange | 选中变化 | `(checked, { e }) => void` | - |
| onClick | 点击 | `...` | - |
| onMouseDown | 鼠标按下 | `(e) => void` | - |
| size | 尺寸 | `'small' \| 'medium' \| 'large'` | - |
| value | 在 Group 中的取值 | `string \| number \| null` | - |

支持 `[key: string]: any` 及原生 `label` 属性。

### Checkbox.Group

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| children | 多个 Checkbox | `React.ReactNode` | - |
| className | 类名 | `string` | - |
| defaultValue | 默认选中值 | `T[] \| null` | `null` |
| disabled | 是否禁用 | `boolean` | `false` |
| onChange | 选中变化 | `(value: T[]) => void` | - |
| size | 尺寸 | `'small' \| 'medium' \| 'large'` | `'medium'` |
| value | 当前选中值 | `T[] \| null` | - |
| options | 数据驱动选项 | `{ label, value, disabled?, helper? }[]` | - |
| helperIcon | 问号图标 | `iconNames[number]` | - |
| layout | 布局 | `'horizontal' \| 'vertical' \| 'grid'` | `'horizontal'` |
| columns | grid 列数 | `number` | `3` |
| ellipsis | 是否省略 | `boolean` | - |
| ellipsisPopoverProps | 省略 Popover | `Omit<PopoverProps, 'popup' \| 'children'>` | - |

## 变量 {#variables}

<VariablesTable id="Checkbox"></VariablesTable>

---

## 颜色选择 ColorPicker

## 基础用例 {#basic-usage}

`ColorPicker`支持 3 位与 6 位 hex 颜色输入，以及 HSB 空间三滑块：

**示例：basic** — basic

```tsx
'use client';

import { ColorPicker } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basic = () => {
  const [color, setColor] = useState<string>('#07C160');

  return (
    <div>
      <CodeBox>
        <ColorPicker value={color} onChange={setColor} />
      </CodeBox>
      <CodeBlock>{`import { ColorPicker } from "one-design-next";

// ${color}
const [color, setColor] = useState('07C160');

<ColorPicker value={color} onChange={setColor} />`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 默认色板 {#default-palette}

通过 `palettes` Prop 添加预设的色板，组件内部将会添加 `Collapse` 组件来展示色板，原先的 UI 会被折叠到末尾的自定义面板中。

这是一个比较开放的功能，可以添加多种色板到 `Collapse` 中，比如可以结合 `storage` 展示“最近使用”过的颜色。

**示例：palette** — palette

```tsx
import { ColorPicker } from 'one-design-next';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import React, { useState } from 'react';

const Palette = () => {
  const [color, setColor] = useState<string>('#07C160');

  const palettes = [
    {
      title: '品牌色',
      colors: [
        '#07C160',
        '#07A156',
        '#058142',
        '#046239',
        '#034630',
        '#022B25',
        '#01191B',
        '#000F12',
      ],
    },
    {
      title: '中性色',
      colors: [
        '#000000',
        '#1A1A1A',
        '#333333',
        '#4D4D4D',
        '#666666',
        '#808080',
        '#999999',
        '#B3B3B3',
        '#CCCCCC',
        '#E6E6E6',
        '#F2F2F2',
        '#FFFFFF',
      ],
    },
    {
      title: '彩虹色',
      colors: [
        '#FF0000',
        '#FF8000',
        '#FFFF00',
        '#80FF00',
        '#00FF00',
        '#00FF80',
        '#00FFFF',
        '#0080FF',
        '#0000FF',
        '#8000FF',
        '#FF00FF',
        '#FF0080',
      ],
    },
  ];

  return (
    <div>
      <CodeBox>
        <div className="flex flex-col gap-4">
          <div>
            <ColorPicker
              value={color}
              onChange={setColor}
              palettes={palettes}
            />
          </div>
        </div>
      </CodeBox>
      <CodeBlock>{`import { ColorPicker } from "one-design-next";
import React, { useState } from 'react';

const Palette = () => {
  const [color, setColor] = useState('#07C160');

  const palettes = [
    {
      title: '品牌色',
      colors: [
        '#07C160', '#07A156', '#058142', '#046239',
        '#034630', '#022B25', '#01191B', '#000F12',
      ],
    },
    {
      title: '中性色',
      colors: [
        '#000000', '#1A1A1A', '#333333', '#4D4D4D',
        '#666666', '#808080', '#999999', '#B3B3B3',
        '#CCCCCC', '#E6E6E6', '#F2F2F2', '#FFFFFF',
      ],
    },
    {
      title: '彩虹色',
      colors: [
        '#FF0000', '#FF8000', '#FFFF00', '#80FF00',
        '#00FF00', '#00FF80', '#00FFFF', '#0080FF',
        '#0000FF', '#8000FF', '#FF00FF', '#FF0080',
      ],
    },
  ];

  return (
    <ColorPicker
      value={color}
      onChange={setColor}
      palettes={palettes}
    />
  );
};

export default Palette;`}</CodeBlock>
    </div>
  );
};

export default Palette;
```
## API {#api}

`ColorPickerProps` 为联合类型：`allowClear: true` 时 `value` / `onChange` 可为 `null`；`allowClear: false` 时 `value` 为 `string`。

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| defaultValue | 默认颜色（hex，不含 `#`） | `string` | 内置默认色 |
| placeholder | 占位 | `string` | `''` |
| disabled | 是否禁用 | `boolean` | `false` |
| allowClear | 是否可清空 | `boolean` | `false` |
| value | 当前颜色（hex，不含 `#`） | `string` 或 `string \| null`（`allowClear` 时） | - |
| onChange | 变化 | `(value: string \| null) => void` 或 `(value: string) => void` | - |
| palettes | 调色板分组 | `{ title, colors: string[] }[]` | - |

## 变量 {#variables}

<VariablesTable id="ColorPicker"></VariablesTable>

---

## 日期选择 DatePicker

## 基础用例 {#basic-usage}

当 `lang` 为 `zhCN` 时，每周从周一开始，格式为 `YYYY-MM-DD`；当 `lang` 为 `enUS` 时，每周从周日开始，格式为 `MM/DD/YYYY`：

**示例：基础用例** — 基础用例

```tsx
import { DatePicker } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
import { Pane } from 'tweakpane';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basic = () => {
  const [value, setValue] = useState<Date | null>(new Date());
  const [params, setParams] = useState({
    lang: 'zhCN' as 'zhCN' | 'enUS',
    light: false,
    disabled: false,
    format: false,
    prefix: '',
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'lang', {
      options: {
        zhCN: 'zhCN',
        enUS: 'enUS',
      },
    });

    pane.addBinding(params, 'light');
    pane.addBinding(params, 'disabled');
    pane.addBinding(params, 'format', {
      label: '自定义显示',
    });

    pane.addBinding(params, 'prefix', {
      label: '前缀',
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  return (
    <div>
      <CodeBox className="gap-2 flex-wrap pt-40">
        <div
          ref={tweakpaneContainerRef}
          className="absolute top-2 right-2 opacity-90"
        />
        <DatePicker
          className="w-60"
          value={value}
          onChange={setValue}
          disabled={params.disabled}
          lang={params.lang}
          key={params.lang}
          light={params.light}
          format={
            params.format
              ? (date, info) => {
                  return `日期：${date?.toLocaleDateString()}`;
                }
              : undefined
          }
          prefix={params.prefix}
        />
      </CodeBox>
      <CodeBlock>{`import { DatePicker } from 'one-design-next';

// ${value ? value.toLocaleDateString() : 'null'}
const [value, setValue] = useState<Date | null>(new Date());

<DatePicker 
  lang="${params.lang}" 
  value={value} 
  onChange={setValue} 
  disabled={${params.disabled}} 
  light={${params.light}}
  ${params.format ? 'format={(date, info) => `日期：${date?.toLocaleDateString()}`}' : 'format={undefined}'}
  prefix="${params.prefix}"
/>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 日/周/月/季度/年选择 {#date-week-month-quarter-year}

支持日、周、月、季度、年选择，通过 `picker` 来指定选择器类型；可通过 `format` 可以自定义日期格式。

**示例：日、周、月、季度、年选择** — 日、周、月、季度、年选择

```tsx
import {
  DatePicker,
  Select,
  convertDateRangeToString,
  convertDateToString,
} from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
import { Pane } from 'tweakpane';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basic = () => {
  const [value, setValue] = useState<Date | null>();
  const [weekValue, setWeekValue] = useState<[Date, Date] | null>();
  const [monthValue, setMonthValue] = useState<[Date, Date] | null>();
  const [quarterValue, setQuarterValue] = useState<[Date, Date] | null>();
  const [yearValue, setYearValue] = useState<[Date, Date] | null>();
  const [dateString, setDateString] = useState<string>('');

  const [selectValue, setSelectValue] = useState<
    'day' | 'week' | 'month' | 'quarter' | 'year'
  >('day');

  const [params, setParams] = useState({
    allowClear: true,
    format: false,
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'allowClear', {
      label: '可清空',
    });

    pane.addBinding(params, 'format', {
      label: '自定义显示',
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  return (
    <div>
      <CodeBox className="flex pt-[120px] pb-20">
        <div
          ref={tweakpaneContainerRef}
          className="absolute top-2 right-2 opacity-90"
        />
        <div className="flex items-center">
          <Select
            value={selectValue}
            className="w-[88px]"
            style={{
              '--odn-select-border-radius': '6px 0 0 6px',
            }}
            options={[
              { value: 'day', label: '按天' },
              { value: 'week', label: '按周' },
              { value: 'month', label: '按月' },
              { value: 'quarter', label: '按季度' },
              { value: 'year', label: '按年' },
            ]}
            onChange={(v) => {
              setSelectValue(v);
            }}
          />
          {/* @ts-ignore */}
          <DatePicker
            className={`-ml-px ${params.format ? 'w-[280px]' : ''}`}
            value={
              selectValue === 'day'
                ? value
                : selectValue === 'week'
                  ? weekValue
                  : selectValue === 'month'
                    ? monthValue
                    : selectValue === 'quarter'
                      ? quarterValue
                      : yearValue
            }
            // @ts-ignore
            onChange={(date, info) => {
              console.log(date, info);
              if (selectValue === 'day') {
                setValue(date);
              } else if (selectValue === 'week') {
                setWeekValue(date);
              } else if (selectValue === 'month') {
                setMonthValue(date);
              } else if (selectValue === 'quarter') {
                setQuarterValue(date);
              } else if (selectValue === 'year') {
                setYearValue(date);
              }

              setDateString(info.dateString);
            }}
            picker={selectValue}
            key={selectValue}
            allowClear={params.allowClear}
            style={{
              '--odn-dp-border-radius': '0 6px 6px 0',
            }}
            format={
              params.format
                ? // @ts-ignore
                  (date) => {
                    if (selectValue === 'day') {
                      return '日期：' + convertDateToString(date);
                    }
                    return '日期：' + convertDateRangeToString(date);
                  }
                : undefined
            }
          />
        </div>
      </CodeBox>
      <CodeBlock>{`import { DatePicker${
        params.format ? ', convertDateRangeToString, convertDateToString' : ''
      } } from 'one-design-next';

// ${dateString}
const [value, setValue] = useState<${
        selectValue === 'day' ? 'Date' : '[Date, Date]'
      } | null>();

<DatePicker
  picker="${selectValue}"
  allowClear={${params.allowClear}}
  format={${
    params.format
      ? selectValue === 'day'
        ? 'date => "日期：" + convertDateToString(date)'
        : 'date => "日期：" + convertDateRangeToString(date)'
      : 'undefined'
  }}
  value={value}
  onChange={(date, info) => {
    setValue(date);
  }}
/>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 禁用日期 {#disabled-dates}

使用 `minDate` 和 `maxDate` 定义日期范围。在这个基础上，日与周选择器可以结合 `disabledDays` 来禁用日期。

其他选择器可结合 `disabledMonths`、`disabledQuarters`、`disabledYears` 来禁用月、季度、年。

**示例：禁用日期** — 禁用日期

```tsx
'use client';

import { DatePicker } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basic = () => {
  const [value, setValue] = useState<Date | null>(new Date());
  const [monthValue, setMonthValue] = useState<[Date, Date] | null>(null);
  const [quarterValue, setQuarterValue] = useState<[Date, Date] | null>(null);
  const [yearValue, setYearValue] = useState<[Date, Date] | null>(null);
  const today = new Date();
  // 拿到今年 1 月
  const minDate = new Date(today.getFullYear(), 0, 1);
  // 拿到今年 12 月
  const maxDate = new Date(today.getFullYear(), 11, 31);
  // 拿到上个月的一天
  const lastMonth = new Date(today.getFullYear(), today.getMonth() - 1, 1);
  // 拿到上季度
  const lastSeason = new Date(today.getFullYear(), today.getMonth() - 3, 1);
  // 拿到去年
  const lastYear = new Date(today.getFullYear() - 1, 0, 1);

  return (
    <div>
      <CodeBox className="flex-col flex-wrap">
        <div className="flex flex-col gap-8">
          <div className="flex gap-2">
            <div className="flex items-center h-9 text-sm w-14">日选择</div>
            <div>
              <DatePicker
                value={value}
                onChange={setValue}
                lang="zhCN"
                minDate={minDate}
                maxDate={maxDate}
                disabledDays={(date) =>
                  date.getDay() === 0 || date.getDay() === 2
                }
              />
              <div className="mt-2 text-xs text-neutral-400">
                disabledDays 禁用周日和周二
              </div>
            </div>
          </div>
          <div className="flex gap-2">
            <div className="flex items-center h-9 text-sm w-14">月选择</div>
            <div>
              <DatePicker
                picker="month"
                value={monthValue}
                onChange={setMonthValue}
                lang="zhCN"
                minDate={minDate}
                maxDate={maxDate}
                disabledMonths={[lastMonth]}
              />
              <div className="mt-2 text-xs text-neutral-400">
                disabledMonths 禁用上个月
              </div>
            </div>
          </div>
          <div className="flex gap-2">
            <div className="flex items-center h-9 text-sm w-14">季度选择</div>
            <div>
              <DatePicker
                picker="quarter"
                value={quarterValue}
                onChange={setQuarterValue}
                lang="zhCN"
                minDate={minDate}
                maxDate={maxDate}
                disabledQuarters={[lastSeason]}
              />
            </div>
          </div>
          <div className="flex gap-2">
            <div className="flex items-center h-9 text-sm w-14">年选择</div>
            <div>
              <DatePicker
                picker="year"
                value={yearValue}
                onChange={setYearValue}
                lang="zhCN"
                disabledYears={[lastYear]}
              />
            </div>
          </div>
        </div>
      </CodeBox>
      <CodeBlock>{`import { DatePicker } from 'one-design-next';

const today = new Date();
const minDate = new Date(today.getFullYear(), 0, 1);
const maxDate = new Date(today.getFullYear(), 11, 31);
const lastMonth = new Date(today.getFullYear(), today.getMonth() - 1, 1);
const lastSeason = new Date(today.getFullYear(), today.getMonth() - 3, 1);
const lastYear = new Date(today.getFullYear() - 1, 0, 1);

<DatePicker minDate={minDate} maxDate={maxDate} disabledDays={(date) => date.getDay() === 0 || date.getDay() === 2} />

<DatePicker picker="month" minDate={minDate} maxDate={maxDate} disabledMonths={[lastMonth]} />

<DatePicker picker="quarter" minDate={minDate} maxDate={maxDate} disabledQuarters={[lastSeason]} />

<DatePicker picker="year" minDate={minDate} maxDate={maxDate} disabledYears={[lastYear]} />`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 自定义弹窗与快捷选项 {#custom-popup-shortcuts}

可以使用 `popupRender` 自定义弹窗内容，或使用 `shortcuts` 设置快捷选项：

**示例：自定义弹窗与快捷选项** — 自定义弹窗与快捷选项

```tsx
'use client';

import { Button, DatePicker } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Popup = () => {
  const [value, setValue] = useState<Date | null>(new Date());

  return (
    <div>
      <CodeBox className="gap-2 flex-wrap">
        <DatePicker
          value={value}
          onChange={setValue}
          lang="zhCN"
          shortcuts={[
            {
              label: '前天',
              value: new Date(new Date().getTime() - 2 * 24 * 60 * 60 * 1000),
            },
            {
              label: '昨天',
              value: new Date(new Date().getTime() - 24 * 60 * 60 * 1000),
            },
            { label: '今天', value: new Date() },
          ]}
          popupRender={(node) => (
            <>
              {node}
              <div className="flex items-center justify-center p-1.5 border-t border-neutral-200">
                <Button
                  light
                  onClick={() => {
                    setValue(new Date());
                  }}
                >
                  回到今天
                </Button>
              </div>
            </>
          )}
        />
      </CodeBox>
      <CodeBlock>{`import { DatePicker } from 'one-design-next';

// ${value?.toLocaleDateString()}
const [value, setValue] = useState<Date | null>(new Date());
<DatePicker
  value={value}
  onChange={setValue}
  shortcuts={[
    {
      label: '昨天',
      value: new Date(new Date().getTime() - 24 * 60 * 60 * 1000),
    },
    { label: '今天', value: new Date() },
    {
      label: '明天',
      value: new Date(new Date().getTime() + 24 * 60 * 60 * 1000),
    },
  ]}
  popupRender={(node) => (
    <>
      {node}
      <div className="flex items-center justify-center p-1.5 border-t border-neutral-200">
        <Button
          light
          onClick={() => {
            setValue(new Date());
          }}
        >
          回到今天
        </Button>
      </div>
    </>
  )}
/>`}</CodeBlock>
    </div>
  );
};

export default Popup;
```
## 用例：与 Select 结合 {#with-select}

**示例：与 Select 结合** — 与 Select 结合

```tsx
'use client';

import { DatePicker, Select } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basic = () => {
  const [value, setValue] = useState<Date | null>(new Date());

  return (
    <div>
      <CodeBox className="flex-col flex-wrap">
        <div className="flex">
          <DatePicker
            className="w-[160px]"
            style={
              {
                '--odn-dp-border-radius': '6px 0 0 6px',
              } as React.CSSProperties
            }
            allowClear={false}
            value={value}
            onChange={setValue}
          />
          <Select
            className="-ml-px w-[160px]"
            style={
              {
                '--odn-select-border-radius': '0 6px 6px 0',
              } as React.CSSProperties
            }
            allowClear={false}
            prefix={
              <div
                style={{
                  color: 'var(--odn-color-black-9)',
                }}
              >
                对比
              </div>
            }
            options={[
              {
                options: [
                  { value: '-1', label: '1 天前' },
                  { value: '-3', label: '3 天前' },
                  { value: '-7', label: '7 天前' },
                  { value: '-15', label: '15 天前' },
                  { value: '-30', label: '30 天前' },
                  { value: '-60', label: '60 天前' },
                  { value: '-90', label: '90 天前' },
                ],
              },
              {
                options: [
                  { value: '1', label: '1 天后' },
                  { value: '3', label: '3 天后', disabled: true },
                  { value: '7', label: '7 天后', disabled: true },
                  { value: '15', label: '15 天后', disabled: true },
                  { value: '30', label: '30 天后', disabled: true },
                  { value: '60', label: '60 天后', disabled: true },
                  { value: '90', label: '90 天后', disabled: true },
                ],
              },
            ]}
          />
        </div>
      </CodeBox>
      <CodeBlock>{`import { DatePicker, Select } from 'one-design-next';

const [value, setValue] = useState<Date | null>(new Date());

<div className="flex">
  <DatePicker
    className="w-[160px]"
    style={
      {
        '--odn-dp-border-radius': '6px 0 0 6px',
      } as React.CSSProperties
    }
    allowClear={false}
    value={value}
    onChange={setValue}
  />
  <Select
    className="-ml-px w-[160px]"
    style={
      {
        '--odn-select-border-radius': '0 6px 6px 0',
      } as React.CSSProperties
    }
    allowClear={false}
    prefix={
      <div
        style={{
          color: 'var(--odn-color-black-9)',
        }}
      >
        对比
      </div>
    }
    options={[
      {
        options: [
          { value: '-1', label: '1 天前' },
          { value: '-3', label: '3 天前' },
          { value: '-7', label: '7 天前' },
          { value: '-15', label: '15 天前' },
          { value: '-30', label: '30 天前' },
          { value: '-60', label: '60 天前' },
          { value: '-90', label: '90 天前' },
        ],
      },
      {
        options: [
          { value: '1', label: '1 天后' },
          { value: '3', label: '3 天后', disabled: true },
          { value: '7', label: '7 天后', disabled: true },
          { value: '15', label: '15 天后', disabled: true },
          { value: '30', label: '30 天后', disabled: true },
          { value: '60', label: '60 天后', disabled: true },
          { value: '90', label: '90 天后', disabled: true },
        ],
      },
    ]}
  />
</div>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 如翼业务定制 {#ry-business-customization}

**示例：如翼业务定制** — 如翼业务定制

```tsx
'use client';

import {
  convertDateRangeToString,
  convertDateToString,
  DatePicker,
  isDayAfter,
  isDayBefore,
  isSameDay,
} from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { cn } from '../../../.dumi/theme/_util';

const stylePack = {
  '--odn-dp-nav-shadow': 'none',
  '--odn-dp-padding-block-end': '8px',
  '--odn-dp-padding-inline': '8px',
  '--odn-dp-nav-padding-inline': '8px',
  '--odn-dp-month-margin-block-start': '0',
  '--odn-dp-shortcuts-width': '72px',
  '--odn-dp-grid-body-padding-block-start': '0',
  '--odn-dp-grid-body-padding-block-end': '8px',
  '--odn-dp-grid-body-padding-inline-start': '8px',
  '--odn-dp-grid-body-padding-inline-end': '8px',
  '--odn-dp-quarter-grid-columns': '1',
  '--odn-dp-month-grid-columns': '3',
  '--odn-dp-month-grid-item-width': '70px',
  '--odn-dp-month-grid-item-height': '32px',
  '--odn-dp-quarter-grid-item-width': '210px',
  '--odn-dp-quarter-grid-item-height': '32px',
  '--odn-dp-grid-popup-min-width': '210px',
};

const Basic = () => {
  const minDate = new Date('2025-01-01');
  const [visible, setVisible] = useState(false);
  const [value, setValue] = useState<[Date, Date]>([new Date(), new Date()]);
  const modes = [
    {
      label: '7 天',
      value: '7',
    },
    {
      label: '30 天',
      value: '30',
    },
    {
      label: '60 天',
      value: '60',
    },
    {
      label: '90 天',
      value: '90',
    },
    {
      label: '自然周',
      value: 'week',
    },
    {
      label: '自然月',
      value: 'month',
    },
    {
      label: '自然季',
      value: 'quarter',
    },
  ] as const;
  const [mode, setMode] = useState<(typeof modes)[number]['value']>(
    modes[0].value,
  );

  const [manualSelectingStartDate, setManualSelectingStartDate] = useState<
    'start' | 'end'
  >('start');

  const hoverTimer = useRef(0);
  const [hoverDate, setHoverDate] = useState<Date | null>(null);

  const DAY_MS = 24 * 60 * 60 * 1000;
  const yesterday = new Date(Date.now() - DAY_MS);
  // 根据 mode 计算出基准日期
  const modeDays = parseInt(mode);
  let baseDate = new Date(Date.now() - modeDays * DAY_MS);

  // 如果 mode 为 7 天，则判定 7 天前为基准日期，例如今天是 2025-12-30，则 7 天前为 2025-12-23
  // 在基准日期之后的： isSelectingStart = false
  // 在基准日期之前、包含基准日期的： isSelectingStart = true
  let isSelectingStart =
    !hoverDate || (hoverDate && isDayBefore(hoverDate, baseDate));

  if (manualSelectingStartDate === 'end') {
    // 如果默认从结束日期开始选择，baseDate 应为 minDate + (mode - 1) 天
    baseDate = new Date(minDate.getTime() + (modeDays - 1) * DAY_MS);
    isSelectingStart = !!hoverDate && isDayBefore(hoverDate, baseDate);
  }

  useEffect(() => {
    // 在这里做一次 hover 状态的重置保险
    if (visible) {
      setHoverDate(null);
      setSelectingDate(null);
    }
  }, [visible, mode]);

  // 自然周、自然月、自然季的 hover 状态处理
  const [selectingDate, setSelectingDate] = useState<[Date, Date] | null>(null);

  // 统一的鼠标进入事件处理
  const handleMouseEnter = (
    _: React.MouseEvent<HTMLButtonElement | HTMLDivElement>,
    info?: {
      startDate?: Date;
      endDate?: Date;
      [key: string]: unknown;
    },
  ) => {
    clearTimeout(hoverTimer.current);
    if (
      info?.startDate &&
      info?.endDate &&
      !isSameDay(info.startDate, selectingDate?.[0]) &&
      !isSameDay(info.endDate, selectingDate?.[1])
    ) {
      setSelectingDate([info.startDate, info.endDate]);
    }
  };

  // 统一的鼠标离开事件处理
  const handleMouseLeave = () => {
    clearTimeout(hoverTimer.current);
    hoverTimer.current = window.setTimeout(() => {
      setSelectingDate(null);
    }, 100);
  };

  let maxDate = yesterday;
  const isDefaultSelectingStart = manualSelectingStartDate === 'start';

  let selectingStartDate = null;
  let selectingEndDate = null;
  if (hoverDate) {
    if (isSelectingStart) {
      // 根据 mode 计算出选择中的结束日期
      selectingEndDate = new Date(
        hoverDate.getTime() + (modeDays - 1) * DAY_MS,
      );
    } else {
      // 根据 mode 计算出选择中的开始日期
      selectingStartDate = new Date(
        hoverDate.getTime() - (modeDays - 1) * DAY_MS,
      );
    }
  }

  selectingStartDate = selectingStartDate || hoverDate;
  selectingEndDate = selectingEndDate || hoverDate;

  return (
    <div>
      <CodeBox className="flex flex-col gap-16">
        <DatePicker
          allowClear={false}
          lang="zhCN"
          picker={
            ['week', 'month', 'quarter'].includes(mode)
              ? (mode as 'week' | 'month' | 'quarter')
              : 'day'
          }
          shortcuts={modes.map((m) => ({
            label: m.label,
            active: mode === m.value,
            onClick: () => setMode(m.value),
          }))}
          visible={visible}
          onVisibleChange={setVisible}
          triggerElement={
            <div
              className={cn(
                'flex h-[36px] w-[276px] cursor-pointer items-center gap-[12px] whitespace-nowrap rounded-[6px] border border-[var(--odn-color-black-6)] px-[12px] text-[14px] transition-all duration-200 hover:border-[var(--odn-color-black-7)]',
                visible &&
                  'border-[var(--odn-color-blue-6)] hover:border-[var(--odn-color-blue-6)]',
              )}
            >
              <span className="text-[var(--odn-color-black-9)]">日期范围</span>
              <div>{convertDateRangeToString(value, 'zhCN', '～')}</div>
            </div>
          }
          popupStyle={stylePack}
          popupRender={(node) => {
            return (
              <div
                className="select-none"
              >
                {['week', 'month', 'quarter'].includes(mode) ? (
                  <div className="relative flex h-[40px] items-center justify-between whitespace-nowrap border-b border-[#f0f0f0] px-[16px] text-[12px] text-[var(--odn-color-black-12)]">
                    <div
                      className={cn(
                        'flex h-full items-center justify-center',
                        mode === 'quarter'
                          ? 'w-[81px]'
                          : 'w-[96px]',
                      )}
                    >
                      {convertDateToString(selectingDate?.[0]) || '开始日期'}
                    </div>
                    <svg width="16" height="16" viewBox="0 0 16 16">
                      <path
                        d="M5.20022 6.5918C5.79222 6.5918 6.44822 6.7518 7.15222 7.1038C7.63222 7.3758 8.14422 7.6638 8.67222 7.9838C9.56822 8.4958 10.3202 8.7678 10.9282 8.7678C11.6642 8.7678 12.4642 8.1438 13.3282 6.9118L14.1762 7.6158C13.1522 9.1198 12.0642 9.8878 10.9282 9.8878C10.1922 9.8878 9.36022 9.6318 8.43222 9.1198C7.90422 8.7998 7.39222 8.4958 6.91222 8.2238C6.27222 7.8878 5.69622 7.7278 5.20022 7.7278C4.36822 7.7278 3.53622 8.3198 2.68822 9.5038L1.82422 8.8158C2.86422 7.3278 3.98422 6.5918 5.20022 6.5918Z"
                        fill="#0D0D0D"
                      />
                    </svg>
                    <div
                      className={cn(
                        'flex h-full items-center justify-center',
                        mode === 'quarter'
                          ? 'w-[81px]'
                          : 'w-[96px]',
                      )}
                    >
                      {convertDateToString(selectingDate?.[1]) || '结束日期'}
                    </div>
                  </div>
                ) : (
                  <div className="relative flex h-[40px] items-center justify-between whitespace-nowrap border-b border-[#f0f0f0] px-[16px] text-[12px] text-[var(--odn-color-black-12)]">
                    <div
                      className={cn(
                        "relative flex h-full w-[81px] cursor-pointer items-center justify-center after:absolute after:left-0 after:top-1/2 after:h-[30px] after:w-full after:-translate-y-1/2 after:rounded-[6px] after:bg-[var(--odn-color-black-1)] after:opacity-0 after:content-[''] hover:after:opacity-100",
                        isSelectingStart &&
                          'font-semibold text-[var(--odn-color-primary)]',
                      )}
                      onClick={() => {
                        setManualSelectingStartDate('start');
                      }}
                    >
                      {selectingStartDate
                        ? convertDateToString(selectingStartDate)
                        : '开始日期'}
                    </div>
                    <svg
                      width="16"
                      height="16"
                      viewBox="0 0 16 16"
                      fill="none"
                      className={cn(
                        'transition-all duration-200',
                        !isSelectingStart &&
                          'rotate-180',
                      )}
                    >
                      <path
                        fillRule="evenodd"
                        clipRule="evenodd"
                        d="M7.91637 3.22662C7.81874 3.12899 7.81874 2.9707 7.91637 2.87307L8.26992 2.51951C8.36755 2.42188 8.52585 2.42188 8.62348 2.51951L13.5732 7.46926L13.9268 7.82281C14.0244 7.92044 14.0244 8.07874 13.9268 8.17637L13.5732 8.52992L8.62348 13.4797C8.52584 13.5773 8.36755 13.5773 8.26992 13.4797L7.91637 13.1261C7.81874 13.0285 7.81874 12.8702 7.91637 12.7726L12.1893 8.49959H2.35357C2.2155 8.49959 2.10357 8.38766 2.10357 8.24959V7.74959C2.10357 7.61152 2.2155 7.49959 2.35357 7.49959H12.1893L7.91637 3.22662Z"
                        fill="var(--odn-color-black-11)"
                      />
                    </svg>
                    <div
                      className={cn(
                        "relative flex h-full w-[81px] cursor-pointer items-center justify-center after:absolute after:left-0 after:top-1/2 after:h-[30px] after:w-full after:-translate-y-1/2 after:rounded-[6px] after:bg-[var(--odn-color-black-1)] after:opacity-0 after:content-[''] hover:after:opacity-100",
                        !isSelectingStart &&
                          'font-semibold text-[var(--odn-color-primary)]',
                      )}
                      onClick={() => {
                        setManualSelectingStartDate('end');
                      }}
                    >
                      {selectingEndDate
                        ? convertDateToString(selectingEndDate)
                        : '结束日期'}
                    </div>
                    <div
                      className={cn(
                        'absolute bottom-[-1px] left-[16px] h-[1px] w-[81px] bg-[var(--odn-color-primary)] transition-all duration-200',
                        !isSelectingStart &&
                          'translate-x-[113px]',
                      )}
                    />
                  </div>
                )}
                {node}
              </div>
            );
          }}
          onDayMouseEnter={handleMouseEnter}
          onDayMouseLeave={handleMouseLeave}
          onMonthMouseEnter={handleMouseEnter}
          onMonthMouseLeave={handleMouseLeave}
          onQuarterMouseEnter={handleMouseEnter}
          onQuarterMouseLeave={handleMouseLeave}
          components={{
            DayButton: ['week', 'month', 'quarter'].includes(mode)
              ? undefined
              : ({ day, modifiers, className, ...props }) => {
                  const { today, disabled, outside } = modifiers;
                  const dateNumber = day.date.getDate();

                  return (
                    <button
                      {...props}
                      className={cn(
                        className,
                        "relative data-[ruyi-date-picker-day-selecting-start=true]:rounded-l-[8px] data-[ruyi-date-picker-day-selecting-start=true]:data-[ruyi-date-picker-day-hover=true]:bg-[var(--odn-color-blue-2)] data-[ruyi-date-picker-day-selecting-start=true]:data-[ruyi-date-picker-day-hover=false]:bg-[var(--odn-color-blue-1)] data-[ruyi-date-picker-day-selecting-end=true]:rounded-r-[8px] data-[ruyi-date-picker-day-selecting-end=true]:data-[ruyi-date-picker-day-hover=true]:bg-[var(--odn-color-blue-2)] data-[ruyi-date-picker-day-selecting-end=true]:data-[ruyi-date-picker-day-hover=false]:bg-[var(--odn-color-blue-1)] data-[ruyi-date-picker-day-selecting=true]:rounded-none data-[ruyi-date-picker-day-selecting=true]:bg-[var(--odn-color-blue-1)] data-[ruyi-date-picker-day-today=true]:after:absolute data-[ruyi-date-picker-day-today=true]:after:bottom-[5px] data-[ruyi-date-picker-day-today=true]:after:left-1/2 data-[ruyi-date-picker-day-today=true]:after:h-[3px] data-[ruyi-date-picker-day-today=true]:after:w-[3px] data-[ruyi-date-picker-day-today=true]:after:-translate-x-1/2 data-[ruyi-date-picker-day-today=true]:after:rounded-full data-[ruyi-date-picker-day-today=true]:after:bg-[var(--odn-color-black-12)] data-[ruyi-date-picker-day-today=true]:after:content-['']",
                      )}
                      style={{
                        cursor: isSameDay(day.date, hoverDate)
                          ? isSelectingStart
                            ? "url('https://wxa.wxs.qq.com/wxad-design/yijie/ry-cursor-right-32.png') 16 16, auto"
                            : "url('https://wxa.wxs.qq.com/wxad-design/yijie/ry-cursor-left-32.png') 16 16, auto"
                          : undefined,
                      }}
                      data-odn-date-picker-day
                      data-odn-date-picker-day-disabled={disabled}
                      data-odn-date-picker-day-outside={outside}
                      // ruyi 自定义样式
                      data-ruyi-date-picker-day-today={today}
                      data-ruyi-date-picker-day-hover={isSameDay(
                        day.date,
                        hoverDate,
                      )}
                      data-ruyi-date-picker-day-selecting-start={isSameDay(
                        day.date,
                        selectingStartDate,
                      )}
                      data-ruyi-date-picker-day-selecting-end={isSameDay(
                        day.date,
                        selectingEndDate,
                      )}
                      data-ruyi-date-picker-day-selecting={
                        isDayBefore(day.date, selectingEndDate) &&
                        isDayAfter(day.date, selectingStartDate)
                      }
                      onMouseEnter={(e) => {
                        if (visible) {
                          clearTimeout(hoverTimer.current);
                          if (!isSameDay(day.date, hoverDate)) {
                            setHoverDate(day.date);
                          }
                        }
                      }}
                      onMouseLeave={() => {
                        clearTimeout(hoverTimer.current);
                        hoverTimer.current = window.setTimeout(() => {
                          setHoverDate(null);
                        }, 100);
                      }}
                      onMouseDown={() => {
                        if (selectingStartDate && selectingEndDate) {
                          setValue([selectingStartDate, selectingEndDate]);
                          setVisible(false);
                          setTimeout(() => {
                            setHoverDate(null);
                          }, 150);
                        }
                      }}
                    >
                      {dateNumber}
                      <div className="absolute left-0 top-0 h-[34px] w-full" />
                    </button>
                  );
                },
          }}
          style={stylePack}
          value={null}
          onChange={(date: unknown) => {
            if (['week', 'month', 'quarter'].includes(mode) && date) {
              setValue(date as [Date, Date]);
            }
          }}
          renderQuarter={(quarter) =>
            `第${['一', '二', '三', '四'][quarter - 1]}季度`
          }
          maxDate={maxDate}
        />
      </CodeBox>
    </div>
  );
};

export default Basic;
```
## API {#api}

类型 `DatePickerProps` = `DatePickerCommonProps` + 随 `picker` 变化的 `value` / `onChange` / `shortcuts` / `format`（见下）。

### 公共属性（DatePickerCommonProps）

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| allowClear | 是否可清空 | `boolean` | `true` |
| minDate / maxDate | 可选范围 | `Date` | 工具默认 |
| visible | 受控显隐 | `boolean \| null` | `null` |
| onVisibleChange | 显隐 | `(visible: boolean) => void` | - |
| disabledDays | 禁用日/周选择中的日期 | `Date[] \| (date: Date) => boolean` | - |
| disabledMonths | 禁用月份 | `Date[]` | - |
| disabledQuarters | 禁用季度 | `Date[]` | - |
| disabledYears | 禁用年份 | `Date[]` | - |
| placeholder | 占位 | `string` | - |
| popupRender | 自定义弹层 | `(node: React.ReactNode) => React.ReactNode` | - |
| disabled | 是否禁用 | `boolean` | `false` |
| lang | 语言 | `'zhCN' \| 'enUS'` | `'zhCN'` |
| light | 轻量样式 | `boolean` | `false` |
| popupStyle | 弹层样式 | `React.CSSProperties` | - |
| captionLayout | 日历标题布局 | `DayPickerProps['captionLayout']` | `'dropdown'` |
| captionPrevIcon / captionNextIcon | 导航图标 | `React.ReactNode` | - |
| components / classNames | 透传 `DayPicker` | 同 react-day-picker | - |
| triggerElement | 自定义触发器 | `React.ReactNode` | - |
| closeOnSelect | 选后是否关闭 | `boolean` | `true` |
| icon / clearIcon | 前缀 / 清除图标 | `React.ReactNode \| null` | - |
| prefix | 前缀 | `React.ReactNode` | - |
| numberOfMonths | 显示月数 | `number` | `1` |
| popoverProps | 透传 Popover | `Omit<PopoverProps, 'popup' \| 'children'>` | - |
| onDayMouseEnter / onDayMouseLeave | 日格悬停 | 见类型定义 | - |
| renderQuarter | 自定义季度文案 | `(quarter: number) => React.ReactNode` | - |
| onMonthMouseEnter / onMonthMouseLeave | 月份格悬停 | 见类型定义 | - |
| onQuarterMouseEnter / onQuarterMouseLeave | 季度格悬停 | 见类型定义 | - |

继承 `Omit<React.HTMLAttributes<HTMLDivElement>, 'value' \| 'onChange' \| 'prefix'>`。

### 当 `picker` 为 `'day'` 或未指定

| 属性 | 说明 | 类型 |
| --- | --- | --- |
| picker | 选择器类型 | `'day'`（默认） |
| value | 当前日期 | `Date \| null` |
| onChange | 变化 | `(date: Date \| null, info: { dateString: string }) => void` |
| shortcuts | 快捷项 | `{ label, value?: Date, active?, onClick? }[]` |
| format | 自定义展示（不提供则可用输入） | `(date: Date \| null, info) => string` |

### 当 `picker` 为 `'week' \| 'month' \| 'quarter' \| 'year'`

| 属性 | 说明 | 类型 |
| --- | --- | --- |
| picker | 选择器类型 | `'week' \| 'month' \| 'quarter' \| 'year'` |
| value | 当前区间 | `[Date, Date] \| null` |
| onChange | 变化 | `(date: [Date, Date] \| null, info: { dateString: string }) => void` |
| shortcuts | 快捷项 | `{ label, value?: [Date, Date], ... }[]` |
| format | 自定义展示 | `(date: [Date, Date] \| null, info) => string` |

## 变量 {#variables}

<VariablesTable id="DatePicker"></VariablesTable>

---

## 日期范围选择 DateRangePicker

`DateRangePicker` 依赖于 `Popover`，基于 `react-day-picker@9` 与 `@floating-ui/react@0.27` 实现。

## 基础用例 {#basic-usage}

当 `lang` 为 `zhCN` 时，格式为 `YYYY-MM-DD - YYYY-MM-DD`，当 `lang` 为 `enUS` 时，格式为 `MM/DD/YYYY - MM/DD/YYYY`：

**示例：基础用例** — 基础用例

```tsx
'use client';

import { DateRangePicker } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
import { Pane } from 'tweakpane';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
const Basic = () => {
  const today = new Date();
  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);
  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);

  const [value, setValue] = useState<[Date, Date] | null>([yesterday, today]);
  const [params, setParams] = useState({
    lang: 'zhCN' as 'zhCN' | 'enUS',
    allowClear: true,
    disabled: false,
    light: false,
    format: false,
    prefix: '',
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'lang', {
      options: {
        zhCN: 'zhCN',
        enUS: 'enUS',
      },
    });

    pane.addBinding(params, 'light', {
      label: '轻量',
    });

    pane.addBinding(params, 'allowClear', {
      label: '可清空',
    });

    pane.addBinding(params, 'disabled', {
      label: '禁用',
    });

    pane.addBinding(params, 'format', {
      label: '自定义显示',
    });

    pane.addBinding(params, 'prefix', {
      label: '前缀',
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  return (
    <div>
      <CodeBox className="gap-2 flex-wrap pt-[200px] pb-20">
        <div
          ref={tweakpaneContainerRef}
          className="absolute top-2 right-2 opacity-90"
        />
        <DateRangePicker
          value={value}
          onChange={(date, info) => {
            setValue(date);
          }}
          lang={params.lang}
          key={params.lang}
          allowClear={params.allowClear}
          disabled={params.disabled}
          light={params.light}
          prefix={params.prefix}
          shortcuts={[
            {
              label: params.lang === 'zhCN' ? '最近 3 天' : 'Last 3 days',
              value: [
                new Date(today.getTime() - 2 * 24 * 60 * 60 * 1000),
                today,
              ],
            },
            {
              label: params.lang === 'zhCN' ? '最近 7 天' : 'Last 7 days',
              value: [
                new Date(today.getTime() - 6 * 24 * 60 * 60 * 1000),
                today,
              ],
            },
            {
              label: params.lang === 'zhCN' ? '最近 30 天' : 'Last 30 days',
              value: [
                new Date(today.getTime() - 29 * 24 * 60 * 60 * 1000),
                today,
              ],
            },
          ]}
          format={
            params.format
              ? (date, info) => {
                  return `日期：${date?.[0]?.toLocaleDateString()} - ${date?.[1]?.toLocaleDateString()}`;
                }
              : undefined
          }
        />
      </CodeBox>
      <CodeBlock>{`import { DateRangePicker } from 'one-design-next';

// ${value?.[0]?.toLocaleDateString()} - ${value?.[1]?.toLocaleDateString()}
const [value, setValue] = useState<[Date, Date] | null>([today, tomorrow]);

<DateRangePicker
  lang="${params.lang}"
  value={value}
  onChange={setValue}
  ${params.allowClear ? 'allowClear' : 'allowClear={false}'}
  ${params.disabled ? 'disabled' : 'disabled={false}'}
  ${params.light ? 'light' : 'light={false}'}
  ${params.format ? 'format={(date, info) => `日期：${date?.[0]?.toLocaleDateString()} - ${date?.[1]?.toLocaleDateString()}`}' : 'format={undefined}'}
  prefix="${params.prefix}"
  shortcuts={[
    {
      label: "${params.lang === 'zhCN' ? '最近 3 天' : 'Last 3 days'}",
      value: [
        new Date(today.getTime() - 2 * 24 * 60 * 60 * 1000),
        today,
      ],
    },
  ]}
/>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 禁用日期 {#disabled-dates}

可以结合 `disabledDays`、`minDate` 和 `maxDate` 来禁用日期：

**示例：禁用日期** — 禁用日期

```tsx
'use client';

import { DateRangePicker } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basic = () => {
  const today = new Date();
  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);
  const [value, setValue] = useState<[Date, Date] | undefined>();

  // 拿到今年 1 月
  const minDate = new Date(today.getFullYear(), 0, 1);
  // 拿到今年 12 月
  const maxDate = new Date(today.getFullYear(), 11, 31);

  return (
    <div>
      <CodeBox className="gap-2 flex-wrap">
        <DateRangePicker
          value={value}
          onChange={setValue}
          lang="zhCN"
          minDate={minDate}
          maxDate={maxDate}
          disabledDays={(date) => date.getDay() === 0 || date.getDay() === 2}
        />
      </CodeBox>
      <CodeBlock>{`import { DateRangePicker } from 'one-design-next';

// ${value?.[0]?.toLocaleDateString()} - ${value?.[1]?.toLocaleDateString()}
const [value, setValue] = useState<[Date, Date] | undefined>([today, tomorrow]);
const today = new Date();
const minDate = new Date(today.getFullYear(), 0, 1);
const maxDate = new Date(today.getFullYear(), 11, 31);

<DateRangePicker
  value={value}
  onChange={setValue}
  minDate={minDate}
  maxDate={maxDate}
  disabledDays={(date) => date.getDay() === 0 || date.getDay() === 2}
/>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 限制最少或最多选择天数 {#day-limit}

使用 `maxDays` 和 `minDays` 限制选择的天数：

**示例：天数限制** — 天数限制

```tsx
'use client';

import React, { useEffect, useRef, useState } from 'react';
import { Pane } from 'tweakpane';

import { DateRangePicker } from 'one-design-next';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basic = () => {
  const [value, setValue] = useState<[Date, Date] | null>();
  const [params, setParams] = useState({
    enableMinDays: true,
    enableMaxDays: true,
    minDays: 3,
    maxDays: 7,
  });
  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'enableMinDays', {
      label: '启用最少天数限制',
    });

    const minDaysBinding = pane.addBinding(params, 'minDays', {
      label: '最少天数',
      min: 1,
      max: 5,
      step: 1,
    });

    pane.addBinding(params, 'enableMaxDays', {
      label: '启用最多天数限制',
    });

    const maxDaysBinding = pane.addBinding(params, 'maxDays', {
      label: '最多天数',
      min: 7,
      max: 10,
      step: 1,
    });

    // 根据开关状态控制 slider 的显示/隐藏
    const updateVisibility = () => {
      minDaysBinding.hidden = !params.enableMinDays;
      maxDaysBinding.hidden = !params.enableMaxDays;
    };

    // 初始设置
    updateVisibility();

    pane.on('change', (ev) => {
      setParams((prev) => {
        const newParams = {
          ...prev,
          // @ts-ignore
          [ev.target.key]: ev.value,
        };

        // 更新可见性
        setTimeout(() => {
          minDaysBinding.hidden = !newParams.enableMinDays;
          maxDaysBinding.hidden = !newParams.enableMaxDays;
        }, 0);

        return newParams;
      });
    });

    return () => {
      pane.dispose();
    };
  }, []);

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <DateRangePicker
          value={value}
          onChange={setValue}
          lang="zhCN"
          minDays={params.enableMinDays ? params.minDays : undefined}
          maxDays={params.enableMaxDays ? params.maxDays : undefined}
          placeholder={
            params.enableMinDays && params.enableMaxDays
              ? `选择 ${params.minDays}-${params.maxDays} 天`
              : params.enableMinDays
                ? `最少选择 ${params.minDays} 天`
                : params.enableMaxDays
                  ? `最多选择 ${params.maxDays} 天`
                  : '选择日期范围'
          }
        />
      </CodeBox>
      <CodeBlock>{`import { DateRangePicker } from 'one-design-next';
      
// ${value?.[0]?.toLocaleDateString()} - ${value?.[1]?.toLocaleDateString()}
<DateRangePicker
  value={value}
  onChange={setValue}
  lang="zhCN"
  minDays={${params.enableMinDays ? params.minDays : 'undefined'}}
  maxDays={${params.enableMaxDays ? params.maxDays : 'undefined'}}
  placeholder="${
    params.enableMinDays && params.enableMaxDays
      ? `选择 ${params.minDays}-${params.maxDays} 天`
      : params.enableMinDays
        ? `最少选择 ${params.minDays} 天`
        : params.enableMaxDays
          ? `最多选择 ${params.maxDays} 天`
          : '选择日期范围'
  }"
/>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 选择日期时的回调 {#date-selection-callback}

通过 `onStartDaySelect` 与 `onEndDaySelect` 同样可以实现限制天数的功能，也可以实现一些更自由的控制逻辑：

**示例：限制** — 限制

```tsx
'use client';

import React, { useState } from 'react';

import { DateRangePicker } from 'one-design-next';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basic = () => {
  const [value, setValue] = useState<[Date, Date] | undefined>();

  const [startDay, setStartDay] = useState<Date | undefined>(undefined);
  let oneWeekBefore: Date | undefined = undefined;
  let oneWeekLater: Date | undefined = undefined;
  if (startDay) {
    oneWeekBefore = new Date(startDay.getTime() - 7 * 24 * 60 * 60 * 1000);
    oneWeekLater = new Date(startDay.getTime() + 7 * 24 * 60 * 60 * 1000);
  }

  return (
    <div>
      <CodeBox className="gap-2 flex-wrap">
        <DateRangePicker
          value={value}
          onChange={setValue}
          lang="zhCN"
          disabledDays={(day) =>
            !!startDay &&
            ((!!oneWeekBefore && day < oneWeekBefore) ||
              (!!oneWeekLater && day > oneWeekLater))
          }
          onStartDaySelect={(day) => setStartDay(day)}
          onEndDaySelect={() => setStartDay(undefined)}
        />
      </CodeBox>
      <CodeBlock>{`import { DateRangePicker } from 'one-design-next';

const [value, setValue] = useState<[Date, Date] | undefined>();

const [startDay, setStartDay] = useState<Date | undefined>(undefined);
let oneWeekBefore: Date | undefined = undefined;
let oneWeekLater: Date | undefined = undefined;
if (startDay) {
  oneWeekBefore = new Date(startDay.getTime() - 7 * 24 * 60 * 60 * 1000);
  oneWeekLater = new Date(startDay.getTime() + 7 * 24 * 60 * 60 * 1000);
}

<DateRangePicker
  value={value}
  onChange={setValue}
  disabledDays={(day) =>
  !!startDay && ((!!oneWeekBefore && day < oneWeekBefore) || (!!oneWeekLater && day > oneWeekLater))
}
  onStartDaySelect={(day) => setStartDay(day)}
  onEndDaySelect={() => setStartDay(undefined)}
/>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 自定义弹窗与快捷选项 {#custom-popup-shortcuts}

可以使用 `popupRender` 自定义弹窗内容，或使用 `shortcuts` 设置快捷选项：

**示例：自定义弹窗与快捷选项** — 自定义弹窗与快捷选项

```tsx
'use client';

import { DateRangePicker, HoverFill } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
import { Pane } from 'tweakpane';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
const Basic = () => {
  const today = new Date();
  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);

  const [value, setValue] = useState<[Date, Date] | undefined>();
  const [params, setParams] = useState({
    lang: 'enUS' as 'zhCN' | 'enUS',
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'lang', {
      options: {
        zhCN: 'zhCN',
        enUS: 'enUS',
      },
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  return (
    <div>
      <CodeBox className="gap-2 flex-wrap pt-[80px]">
        <div
          ref={tweakpaneContainerRef}
          className="absolute top-2 right-2 opacity-90"
        />
        <DateRangePicker
          value={value}
          onChange={setValue}
          lang={params.lang}
          key={params.lang}
          popupRender={(node) => (
            <>
              {node}
              <div className="flex items-center justify-center p-1.5 border-t border-neutral-200">
                <HoverFill bgClassName="rounded">
                  <div
                    className="px-4 py-2"
                    onClick={() => {
                      setValue([
                        new Date(today.getTime() - 2 * 24 * 60 * 60 * 1000),
                        today,
                      ]);
                    }}
                  >
                    {params.lang === 'zhCN' ? '最近 3 天' : 'Last 3 days'}
                  </div>
                </HoverFill>
              </div>
            </>
          )}
          shortcuts={[
            {
              label: params.lang === 'zhCN' ? '最近 3 天' : 'Last 3 days',
              value: [
                new Date(today.getTime() - 2 * 24 * 60 * 60 * 1000),
                today,
              ],
            },
            {
              label: params.lang === 'zhCN' ? '最近 7 天' : 'Last 7 days',
              value: [
                new Date(today.getTime() - 6 * 24 * 60 * 60 * 1000),
                today,
              ],
            },
            {
              label: params.lang === 'zhCN' ? '最近 30 天' : 'Last 30 days',
              value: [
                new Date(today.getTime() - 29 * 24 * 60 * 60 * 1000),
                today,
              ],
            },
          ]}
        />
      </CodeBox>
      <CodeBlock>{`import { DateRangePicker } from 'one-design-next';

// ${value?.[0]?.toLocaleDateString()} - ${value?.[1]?.toLocaleDateString()}
const [value, setValue] = useState<[Date, Date] | undefined>([today, tomorrow]);

<DateRangePicker lang="${params.lang}"
  value={value}
  onChange={setValue}
  popupRender={(node) => (
    <>
      {node}
      button
    </>
  )}
  shortcuts={[
    {
      label: "${params.lang === 'zhCN' ? '最近 3 天' : 'Last 3 days'}",
      value: [
        new Date(today.getTime() - 2 * 24 * 60 * 60 * 1000),
        today,
      ],
    },
  ]}
/>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## ODC 业务定制 {#business-customization}

**示例：业务定制** — 业务定制

```tsx
'use client';

import {
  Button,
  DateRangePicker,
  Input,
  InputRef,
  MONTHS,
  Popover,
  Radio,
  // 将日期对象转化为中或英的日期字符串
  convertDateToString,
  // 判断第一个日期参数是否在第二个日期参数之后
  isDayAfter,
  // 判断第一个日期参数是否在第二个日期参数之前
  isDayBefore,
  // 判断日期字符串是否合法，英的格式为 mm/dd/yyyy，我看到设计稿是 m/dd/yyyy，不管设计稿
  isLegalDateString as isLegalDateStringUtil,
  // 判断两个日期是否是同一天
  isSameDay,
} from 'one-design-next';
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Pane } from 'tweakpane';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
// 关于 tailwind 的推荐：
// 1. cn 方法是 tailwind 合并类名方法，这个建议各个业务都使用，封装自 twMerge 和 clsx
// 2. 注意：demo 中的 tailwind spacing 是 4px，这里可能和业务方不同。实际上我也是建议业务方直接用 1:1，省得各种换算。
// 3. 原子类中 text-[#0A0A0A99] 这些也需要修改，推荐业务方以 token 的方式重新规整一下颜色变量。
// 4. 推荐为原子类名加前缀 html .xxx {}，增加类名的优先级。one-design-next 的组件没有使用 @layer 来降低优先级，不敢用这种东西。
import { cn } from '../../../.dumi/theme/_util';

// 这里设置在 html:root{} 中，我这里是因为写在 demo 中，所以不得不用 style 设置
// 推荐以组件的形式对样式做完全的自定义。
// 变量设置的并不完全，仅是这里的 demo 展示
// 变量看着是有点吓人，但是为了保证样式完全自定义。目前变量的设计还没有太完善，这东西初期很难完善。未来需要以全局变量、组件变量，后者引用前者的方式整合。
// 先用着吧，目前具体变量去看 components/*/variables.scss 更快，我推荐用到 button 就花点时间把 button 的变量一次性整完。
const initialStylePack = {
  // button
  '--odn-button-medium-padding-inline': '16px',
  '--odn-button-medium-height': '32px',
  '--odn-button-medium-font-size': '14px',
  '--odn-button-medium-icon-size': '16px',
  '--odn-button-medium-icon-gap': '4px',
  '--odn-button-medium-border-radius': '8px',

  '--odn-button-primary-font-weight': '500',
  '--odn-button-primary-color': '#fff',
  '--odn-button-primary-bg': '#000000F5',
  '--odn-button-primary-border-color': 'transparent',
  '--odn-button-primary-loading-icon-color': '#fff',
  '--odn-button-primary-bg-hover': 'color-mix(in srgb, #000 96%, #fff 8%)',
  '--odn-button-primary-border-color-hover': 'transparent',
  '--odn-button-primary-bg-active': 'color-mix(in srgb, #000 96%, #0a0a0a 12%)',
  '--odn-button-primary-border-color-active': 'transparent',

  '--odn-button-normal-font-weight': '500',
  '--odn-button-normal-color': '#000000F5',
  '--odn-button-normal-bg': '#0A0A0A0D',
  '--odn-button-normal-border-color': 'transparent',
  '--odn-button-normal-loading-icon-color': '#000000F5',
  '--odn-button-normal-bg-hover': '#0A0A0A14',
  '--odn-button-normal-border-color-hover': 'transparent',
  '--odn-button-normal-bg-active': '#0A0A0A1F',
  '--odn-button-normal-border-color-active': 'transparent',

  // radio
  '--odn-radio-indicator-size-medium': '8px',
  '--odn-radio-indicator-bg': '#0A0A0AD6',
  '--odn-radio-indicator-scale-initial': '0',
  '--odn-radio-color': '#0A0A0A99',
  '--odn-radio-input-bg': '#fff',
  '--odn-radio-input-border': '1px solid #0A0A0A1F',
  '--odn-radio-input-bg-checked': '#fff',
  '--odn-radio-input-border-checked': '1px solid #0A0A0AD6',
  '--odn-radio-input-bg-checked-hover': '#fff',
  '--odn-radio-input-border-checked-hover': '1px solid #0A0A0AD6',
  '--odn-radio-input-bg-checked-focus': '#fff',
  '--odn-radio-input-border-checked-focus': '1px solid #0A0A0AD6',

  // input
  '--odn-input-padding-block-large': '7.5px',
  '--odn-input-padding-inline-large': '12px',
  '--odn-input-font-size-large': '14px',
  '--odn-input-line-height-large': '1.57142857',
  '--odn-input-border-radius-large': '8px',
  '--odn-input-icon-size-large': '16px',
  '--odn-input-icon-margin-inline-large': '8px',

  '--odn-input-padding-block-medium': '3.5px',
  '--odn-input-padding-inline-medium': '12px',
  '--odn-input-font-size-medium': '14px',
  '--odn-input-line-height-medium': '1.57142857',
  '--odn-input-border-radius-medium': '8px',
  '--odn-input-icon-size-medium': '16px',
  '--odn-input-icon-margin-inline-medium': '8px',

  '--odn-input-bg-normal': '#0A0A0A0D',
  '--odn-input-bg-normal-hover': '#0A0A0A14',
  '--odn-input-bg-normal-focus': '#fff',

  '--odn-input-color-normal': '#000000F5',
  '--odn-input-color-normal-hover': '#000000F5',
  '--odn-input-color-normal-focus': '#000000F5',

  '--odn-input-border-width': '1.5px',

  '--odn-input-border-normal': 'transparent',
  '--odn-input-border-normal-hover': 'transparent',
  '--odn-input-border-normal-focus': '#0A0A0AD6',

  '--odn-input-shadow-normal-focus': 'none',

  '--odn-input-border-danger': '#F04354',
  '--odn-input-border-danger-hover': '#F04354',
  '--odn-input-border-danger-focus': '#F04354',
  '--odn-input-shadow-danger-focus': 'none',

  // popover
  '--odn-popover-padding-block': '2px',
  '--odn-popover-padding-inline': '8px',
  '--odn-popover-font-size': '14px',
  '--odn-popover-line-height': '22px',
  '--odn-popup-border-radius': '12px',
  '--odn-popup-border': '1px solid rgba(10, 10, 10, 0.12)',
  '--odn-popup-box-shadow':
    '0px 2px 5px rgba(0, 0, 0, 0.05), 0px 6px 15px rgba(0, 0, 0, 0.05)',
  '--odn-popup-filter': 'none',

  // date-picker
  '--odn-dp-month-margin-block-start': '0px',
  '--odn-dp-nav-shadow': 'none',
  '--odn-dp-nav-padding-block-start': '20px',
  '--odn-dp-nav-padding-block-end': '8px',
  '--odn-dp-nav-padding-inline': '16px',
  '--odn-dp-nav-button-size': '24px',
  '--odn-dp-weekday-width': '32px',
  '--odn-dp-weekday-height': '32px',
  '--odn-dp-weekday-font-size': '12px',
  '--odn-dp-weekday-font-weight': '400',
  '--odn-dp-weekday-color': '#0A0A0A99',
  '--odn-dp-table-row-gap': '8px',
  '--odn-dp-day-size': '24px',
  // 这里是专为 odc 加的变量，因为 odc 的按钮和 td 的尺寸不一样，真麻烦。这个变量更是黑盒。
  '--odn-dp-td-hover-fill-offset-x': '4px',
  '--odn-dp-hover-fill-color': '#f3f3f3',
};

// 将日期字符串转换为显示格式，ODC 输入框在 focus 和 blur 需要相互转换
const convertDateStringToDisplay = (date: string) => {
  const [month, day, year] = date.split('/');
  const monthName = MONTHS[parseInt(month, 10) - 1].enUS;
  return `${monthName} ${day}, ${year}`;
};

// 判断日期字符串是否合法，基于 odn 提供的 util 方法 isLegalDateStringUtil，在此之上加入 min max 方法，暂时就不放 utils 里了
const isLegalDateString = (
  dateString: string,
  { minDate, maxDate }: { minDate: Date; maxDate: Date },
) =>
  isLegalDateStringUtil(dateString, 'enUS') &&
  !isDayBefore(new Date(dateString), minDate) &&
  !isDayAfter(new Date(dateString), maxDate);

// 判断日期范围是否是今天，更通用的方法可能是这个组件快捷 range 都是可以配置
const isRangeToday = (range: [Date, Date]) => {
  const now = new Date();
  return isSameDay(range[0], now) && isSameDay(range[1], now);
};

// 判断日期范围是否是昨天，更通用的方法可能是这个组件快捷 range 都是可以配置
const isRangeYesterday = (range: [Date, Date]) => {
  const now = new Date();
  const yesterday = new Date(now.getTime() - 24 * 60 * 60 * 1000);
  return isSameDay(range[0], yesterday) && isSameDay(range[1], yesterday);
};

// 判断日期范围是否是过去7天，更通用的方法可能是这个组件快捷 range 都是可以配置
const isRange7Days = (range: [Date, Date]) => {
  const now = new Date();
  const startOf7DaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
  return isSameDay(range[0], startOf7DaysAgo) && isSameDay(range[1], now);
};

// 判断日期范围是否是过去30天，更通用的方法可能是这个组件快捷 range 都是可以配置
const isRange30Days = (range: [Date, Date]) => {
  const now = new Date();
  const startOf30DaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
  return isSameDay(range[0], startOf30DaysAgo) && isSameDay(range[1], now);
};

// 判断两个日期之间的差是否超过 x 天
const isRangeOverDays = (range: [Date, Date], days: number) => {
  const date0 = new Date(range[0]);
  date0.setHours(0, 0, 0, 0);
  const date1 = new Date(range[1]);
  date1.setHours(0, 0, 0, 0);
  return date1.getTime() - date0.getTime() > days * 24 * 60 * 60 * 1000;
};

const DateRangePickerCustomize = ({
  value,
  onChange,
  minDate = new Date(new Date().getTime() - 30 * 12 * 24 * 60 * 60 * 1000),
  maxDate = new Date(),
  stylePack,
}: {
  value: [Date, Date];
  onChange: (value: [Date, Date]) => void;
  minDate?: Date;
  maxDate?: Date;
  stylePack?: typeof initialStylePack;
}) => {
  // 这里不做 value 的合法性判断，默认业务传入一定合法
  const getStateFromProps = (v: [Date, Date]) => {
    const tempValue = v;
    const startDateInputValue = convertDateStringToDisplay(
      convertDateToString(v[0], 'enUS'),
    );
    const endDateInputValue = convertDateStringToDisplay(
      convertDateToString(v[1], 'enUS'),
    );

    const isToday = isRangeToday(v);
    const isYesterday = isRangeYesterday(v);
    const is7Days = isRange7Days(v);
    const is30Days = isRange30Days(v);

    let radioValue = 'custom';
    if (isToday) {
      radioValue = 'today';
    } else if (isYesterday) {
      radioValue = 'yesterday';
    } else if (is7Days) {
      radioValue = '7days';
    } else if (is30Days) {
      radioValue = '30days';
    }

    return {
      tempValue,
      startDateInputValue,
      endDateInputValue,
      radioValue,
    };
  };

  const initialState = useMemo(() => getStateFromProps(value), []);

  const [tempValue, setTempValue] = useState(initialState.tempValue);
  const latestTempValue = useRef<[Date, Date]>(initialState.tempValue);
  useEffect(() => {
    latestTempValue.current = tempValue;
  }, [tempValue]);

  const [visible, setVisible] = useState(false);

  const startDateInputRef = useRef<InputRef>(null);
  const endDateInputRef = useRef<InputRef>(null);

  const [startDateInputValue, setStartDateInputValue] = useState(
    initialState.startDateInputValue,
  );

  const [endDateInputValue, setEndDateInputValue] = useState(
    initialState.endDateInputValue,
  );

  const [startDateError, setStartDateError] = useState('');
  const [endDateError, setEndDateError] = useState('');

  const [radioValue, setRadioValue] = useState(initialState.radioValue);

  // startDay 存在有两个功能：
  // 1. 限制用户最大只能选前后 6 个月，会结合 dateRangePicker 的 disabledDays 使用
  // 2. 当用户只选择了 startDay 但是没有选择 endDay 时，如果他关闭了弹窗，则将 startDay 作为 endDay 使用
  const [startDay, setStartDay] = useState<Date | undefined>(undefined);
  const latestStartDay = useRef<Date | undefined>(undefined);
  useEffect(() => {
    latestStartDay.current = startDay;
  }, [startDay]);

  let sixMonthsBefore: Date | undefined = undefined;
  let sixMonthsLater: Date | undefined = undefined;
  if (startDay) {
    sixMonthsBefore = new Date(
      startDay.getTime() - 6 * 30 * 24 * 60 * 60 * 1000,
    );
    sixMonthsLater = new Date(
      startDay.getTime() + 6 * 30 * 24 * 60 * 60 * 1000,
    );
  }

  // 整个组件只有这一处因外部控制而发生的 useEffect，其他地方都不采用。原因是这只会让状态追踪变得更复杂
  // 如 handleRadioChange 中的逻辑，会附带 setTempValue 和 setStartDateInputValue 和 setEndDateInputValue
  // 这看起来让逻辑出现了各种分支，但这些分支都归于 UI 需求而非因代码设计。这样会让 UI 的变化归因更简单
  useEffect(() => {
    const newState = getStateFromProps(value);
    setTempValue(newState.tempValue);
    setStartDateInputValue(newState.startDateInputValue);
    setEndDateInputValue(newState.endDateInputValue);
    setRadioValue(newState.radioValue);
    setStartDateError('');
    setEndDateError('');
  }, [value]);

  const handleRadioChange = (value: string) => {
    setRadioValue(value);
    setStartDay(undefined);
    setStartDateError('');
    setEndDateError('');
    if (value === 'custom') {
      return;
    }

    let newRange: [Date, Date] = [new Date(), new Date()];
    // 这里本来想用 useEffect，但其实只会让状态追踪变得更复杂
    if (value === 'today') {
      newRange = [new Date(), new Date()];
    } else if (value === 'yesterday') {
      newRange = [
        new Date(new Date().getTime() - 24 * 60 * 60 * 1000),
        new Date(new Date().getTime() - 24 * 60 * 60 * 1000),
      ];
    } else if (value === '7days') {
      newRange = [
        new Date(new Date().getTime() - 7 * 24 * 60 * 60 * 1000),
        new Date(),
      ];
    }
    if (value === '30days') {
      newRange = [
        new Date(new Date().getTime() - 30 * 24 * 60 * 60 * 1000),
        new Date(),
      ];
    }

    setTempValue(newRange);
    setStartDateInputValue(
      convertDateStringToDisplay(convertDateToString(newRange[0], 'enUS')),
    );
    setEndDateInputValue(
      convertDateStringToDisplay(convertDateToString(newRange[1], 'enUS')),
    );
  };

  const handleCancel = () => {
    setVisible(false);
    setStartDateError('');
    setEndDateError('');
    setTempValue(value);
    setStartDateInputValue(
      convertDateStringToDisplay(convertDateToString(value[0], 'enUS')),
    );
    setEndDateInputValue(
      convertDateStringToDisplay(convertDateToString(value[1], 'enUS')),
    );
  };

  const handleApply = () => {
    setVisible(false);
    // 这里的设计是 startDay 有值就代表用户只选了 startDay，没有选 endDay
    // 所以需要将 startDay 作为 endDay 使用
    if (latestStartDay.current) {
      onChange([latestStartDay.current, latestStartDay.current]);
    } else {
      onChange(
        latestTempValue.current.sort((a, b) => a.getTime() - b.getTime()),
      );
    }
  };

  const handleStartDateInputChange = (value: string) => {
    setStartDateInputValue(value);

    // 这里的报错判断想过放 useEffect，但是我还是觉得会让状态追踪变得复杂
    // 一个主要原因就是 inputValue 自身会在 focus 和 blur 的时候变化，也就是说再怎么抽到 useEffect 里，这两个事件回调是省去不了的
    // 因此感觉既然不能整合，就不要部分整合
    if (!isLegalDateStringUtil(value, 'enUS') || !value.trim()) {
      setStartDateError('Invalid date');
    } else if (isDayBefore(new Date(value), minDate)) {
      setStartDateError('Date must not be before min date');
    } else if (isDayAfter(new Date(value), maxDate)) {
      setStartDateError('Date must not be after today');
    } else if (isRangeOverDays([new Date(value), tempValue[1]], 180)) {
      setStartDateError('Maximum range: 6 months');
    } else {
      setTempValue([new Date(value), tempValue[1]]);
      setRadioValue('custom');
      setStartDateError('');
    }
  };

  const handleEndDateInputChange = (value: string) => {
    setEndDateInputValue(value);

    // 这里的报错判断想过放 useEffect，但是我还是觉得会让状态追踪变得复杂
    // 一个主要原因就是 inputValue 自身会在 focus 和 blur 的时候变化，也就是说再怎么抽到 useEffect 里，这两个事件回调是省去不了的
    // 因此感觉既然不能整合，就不要部分整合
    if (!isLegalDateStringUtil(value, 'enUS') || !value.trim()) {
      setEndDateError('Invalid date');
    } else if (isDayAfter(new Date(value), maxDate)) {
      setEndDateError('Date must not be after today');
    } else if (isDayBefore(new Date(value), minDate)) {
      setEndDateError('Date must not be before min date');
    } else if (isRangeOverDays([tempValue[0], new Date(value)], 180)) {
      setEndDateError('Maximum range: 6 months');
    } else {
      setTempValue([tempValue[0], new Date(value)]);
      setRadioValue('custom');
      setEndDateError('');
    }
  };

  const handleStartDateInputFocus = () => {
    if (!startDateError) {
      setStartDateInputValue(convertDateToString(tempValue[0], 'enUS'));
    }
  };

  // 判断只有两个输入框都没有报错时，才进行 swap
  const handleDateInputSwap = (type: 'start' | 'end') => {
    if (type === 'start') {
      const startDisplayString = convertDateStringToDisplay(
        convertDateToString(tempValue[0], 'enUS'),
      );

      if (!endDateError && isDayAfter(tempValue[0], tempValue[1])) {
        setStartDateInputValue(
          convertDateStringToDisplay(convertDateToString(tempValue[1], 'enUS')),
        );
        setEndDateInputValue(startDisplayString);
        setTempValue([tempValue[1], tempValue[0]]);
      } else {
        setStartDateInputValue(startDisplayString);
      }
    } else {
      const endDisplayString = convertDateStringToDisplay(
        convertDateToString(tempValue[1], 'enUS'),
      );

      if (!startDateError && isDayAfter(tempValue[0], tempValue[1])) {
        setStartDateInputValue(endDisplayString);
        setEndDateInputValue(
          convertDateStringToDisplay(convertDateToString(tempValue[0], 'enUS')),
        );
        setTempValue([tempValue[1], tempValue[0]]);
      } else {
        setEndDateInputValue(endDisplayString);
      }
    }
  };

  const handleStartDateInputBlur = () => {
    if (!startDateError) {
      handleDateInputSwap('start');
    }
  };

  const handleEndDateInputFocus = () => {
    if (!endDateError) {
      setEndDateInputValue(convertDateToString(tempValue[1], 'enUS'));
    }
  };

  const handleEndDateInputBlur = () => {
    if (!endDateError) {
      handleDateInputSwap('end');
    }
  };

  const handleDateRangeSelect = (range: [Date, Date] | null) => {
    if (range) {
      setTempValue(range);
      setRadioValue('custom');
      setStartDateError('');
      setEndDateError('');
      setStartDateInputValue(
        convertDateStringToDisplay(convertDateToString(range[0], 'enUS')),
      );
      setEndDateInputValue(
        convertDateStringToDisplay(convertDateToString(range[1], 'enUS')),
      );
    }
  };

  // 这里可能可以提一个通用方法得到最终的 buttonString
  const isToday = isRangeToday(value);
  const isYesterday = isRangeYesterday(value);
  const is7Days = isRange7Days(value);
  const is30Days = isRange30Days(value);
  const isRangeOnlyOneDay = isSameDay(value[0], value[1]);
  let buttonString = '';
  if (isToday) {
    buttonString = 'Today: ';
  } else if (is7Days) {
    buttonString = 'Last 7 days: ';
  } else if (is30Days) {
    buttonString = 'Last 30 days: ';
  } else if (isYesterday) {
    buttonString = 'Yesterday: ';
  }
  let startDateString = convertDateStringToDisplay(
    convertDateToString(value[0], 'enUS'),
  );
  const endDateString = convertDateStringToDisplay(
    convertDateToString(value[1], 'enUS'),
  );
  // 如果是同一年的则去除 startDateString 中的年份
  if (value[0].getFullYear() === value[1].getFullYear()) {
    startDateString = startDateString.replace(
      `, ${value[0].getFullYear()}`,
      '',
    );
  }
  if (isRangeOnlyOneDay) {
    buttonString = `${buttonString}${endDateString}`;
  } else {
    buttonString = `${buttonString}${startDateString} - ${endDateString}`;
  }

  return (
    <DateRangePicker
      closeOnSelect={false}
      lang="enUS"
      captionLayout="label"
      minDate={minDate}
      maxDate={maxDate}
      // visible={visible}
      visible
      // onVisibleChange 发生在用户点击 window 时，这里的决策是这种行为属于 apply 还是 cancel，我认为应该属于 apply，否则应有二次确认
      onVisibleChange={(visible) => {
        setVisible(visible);
        if (!visible) {
          handleApply();
        }
      }}
      // 这个 popupStyle 是 demo 展示需要，业务方删掉，将 stylePack 放到 html:root{} 中，
      popupStyle={stylePack}
      popupRender={(node) => {
        return (
          <div>
            <div className="flex items-center justify-between px-4 h-16">
              <div className="text-base font-medium">Date range</div>
              <div className="flex items-center gap-1">
                <Input
                  className="w-[160px]"
                  placeholder="Select date"
                  ref={startDateInputRef}
                  value={startDateInputValue}
                  onChange={(e) => {
                    handleStartDateInputChange(e.target.value);
                  }}
                  onFocus={handleStartDateInputFocus}
                  onBlur={handleStartDateInputBlur}
                  intent={startDateError ? 'danger' : 'normal'}
                  rightElement={
                    !!startDateError && (
                      <Popover
                        popup={startDateError}
                        arrowed={false}
                        placement="bottom"
                        popupStyle={{
                          padding: '2px 8px',
                        }}
                      >
                        <svg
                          className="-mr-1"
                          width="16"
                          height="16"
                          viewBox="0 0 16 16"
                          fill="none"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <circle
                            cx="8"
                            cy="8"
                            r="6.33333"
                            stroke="#F04354"
                            strokeWidth="1.33333"
                          />
                          <path
                            d="M7.71094 7.0127C7.43495 7.0127 7.21119 7.23677 7.21094 7.5127V11.25C7.21094 11.5261 7.4348 11.75 7.71094 11.75H8.29004C8.56611 11.7499 8.79004 11.5261 8.79004 11.25V7.5127C8.78979 7.23682 8.56596 7.01278 8.29004 7.0127H7.71094ZM7.71094 4.25C7.4348 4.25 7.21094 4.47386 7.21094 4.75V5.3291C7.21102 5.60517 7.43485 5.8291 7.71094 5.8291H8.29004C8.56606 5.82902 8.78996 5.60512 8.79004 5.3291V4.75C8.79004 4.47391 8.56611 4.25008 8.29004 4.25H7.71094Z"
                            fill="#F04354"
                          />
                        </svg>
                      </Popover>
                    )
                  }
                />
                <i className="w-3 h-0.5 bg-[#0A0A0A1F] rounded-sm" />
                <Input
                  className="w-[160px]"
                  placeholder="Select date"
                  ref={endDateInputRef}
                  value={endDateInputValue}
                  onChange={(e) => {
                    handleEndDateInputChange(e.target.value);
                  }}
                  onFocus={handleEndDateInputFocus}
                  onBlur={handleEndDateInputBlur}
                  intent={endDateError ? 'danger' : 'normal'}
                  rightElement={
                    !!endDateError && (
                      <Popover
                        popup={endDateError}
                        arrowed={false}
                        placement="bottom"
                        popupStyle={{
                          padding: '2px 8px',
                        }}
                      >
                        <svg
                          className="-mr-1"
                          width="16"
                          height="16"
                          viewBox="0 0 16 16"
                          fill="none"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <circle
                            cx="8"
                            cy="8"
                            r="6.33333"
                            stroke="#F04354"
                            strokeWidth="1.33333"
                          />
                          <path
                            d="M7.71094 7.0127C7.43495 7.0127 7.21119 7.23677 7.21094 7.5127V11.25C7.21094 11.5261 7.4348 11.75 7.71094 11.75H8.29004C8.56611 11.7499 8.79004 11.5261 8.79004 11.25V7.5127C8.78979 7.23682 8.56596 7.01278 8.29004 7.0127H7.71094ZM7.71094 4.25C7.4348 4.25 7.21094 4.47386 7.21094 4.75V5.3291C7.21102 5.60517 7.43485 5.8291 7.71094 5.8291H8.29004C8.56606 5.82902 8.78996 5.60512 8.79004 5.3291V4.75C8.79004 4.47391 8.56611 4.25008 8.29004 4.25H7.71094Z"
                            fill="#F04354"
                          />
                        </svg>
                      </Popover>
                    )
                  }
                />
              </div>
            </div>
            <div className="flex border-y border-[#0A0A0A0D]">
              <div className="px-4 border-r border-[#0A0A0A0D]">
                <Radio.Group
                  className="pt-5"
                  vertical
                  options={[
                    { label: 'Today', value: 'today' },
                    { label: 'Yesterday', value: 'yesterday' },
                    { label: 'Last 7 days', value: '7days' },
                    { label: 'Last 30 days', value: '30days' },
                    { label: 'Custom', value: 'custom' },
                  ]}
                  value={radioValue}
                  onChange={handleRadioChange}
                />
              </div>
              {node}
            </div>
            <div className="flex items-center justify-between px-4 h-16">
              <div className="text-[#0A0A0A99] text-sm">
                Dates are shown in London (UTC+00:00) time
              </div>
              <div className="flex items-center gap-4">
                <Button onClick={handleCancel}>Cancel</Button>
                <Button
                  intent="primary"
                  onClick={handleApply}
                  disabled={!!startDateError || !!endDateError}
                >
                  Apply
                </Button>
              </div>
            </div>
          </div>
        );
      }}
      triggerElement={
        <Button
          style={
            stylePack
              ? {
                  // 这应该是按钮，但是有一些不同？
                  '--odn-button-normal-font-weight': 400,
                  '--odn-button-medium-padding-inline': '12px',
                }
              : undefined
          }
        >
          <div className="flex items-center gap-2">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <g clipPath="url(#clip0_2396_34808)">
                <g clipPath="url(#clip1_2396_34808)">
                  <path
                    d="M14 1.33325C14.5523 1.33325 15 1.78097 15 2.33325V14.3333C15 14.8855 14.5523 15.3333 14 15.3333H2C1.44772 15.3333 1 14.8855 1 14.3333V2.33325C1 1.78097 1.44772 1.33325 2 1.33325H14ZM2.33301 2.66626V14.0002H13.667V2.66626H2.33301Z"
                    fill="#0A0A0A"
                    fillOpacity="0.84"
                  />
                  <rect
                    x="1.33398"
                    y="5.33325"
                    width="12.6667"
                    height="1.33333"
                    fill="#0A0A0A"
                    fillOpacity="0.84"
                  />
                  <rect
                    x="5.33398"
                    width="4"
                    height="1.33333"
                    rx="0.666667"
                    transform="rotate(90 5.33398 0)"
                    fill="#0A0A0A"
                    fillOpacity="0.84"
                  />
                  <rect
                    x="12"
                    width="4"
                    height="1.33333"
                    rx="0.666667"
                    transform="rotate(90 12 0)"
                    fill="#0A0A0A"
                    fillOpacity="0.84"
                  />
                  <rect
                    x="4"
                    y="11.3333"
                    width="8"
                    height="1.33333"
                    rx="0.666667"
                    fill="#0A0A0A"
                    fillOpacity="0.84"
                  />
                  <rect
                    x="4"
                    y="8.66675"
                    width="8"
                    height="1.33333"
                    rx="0.666667"
                    fill="#0A0A0A"
                    fillOpacity="0.84"
                  />
                </g>
              </g>
              <defs>
                <clipPath id="clip0_2396_34808">
                  <rect width="16" height="16" fill="white" />
                </clipPath>
                <clipPath id="clip1_2396_34808">
                  <rect width="16" height="16" fill="white" />
                </clipPath>
              </defs>
            </svg>
            {buttonString}
          </div>
        </Button>
      }
      value={tempValue}
      onChange={handleDateRangeSelect}
      {...(stylePack
        ? {
            captionPrevIcon: (
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                <path
                  fillRule="evenodd"
                  clipRule="evenodd"
                  d="M9.67651 12.9831C9.57888 13.0808 9.42059 13.0808 9.32296 12.9831L4.51463 8.1748C4.417 8.07717 4.417 7.91888 4.51463 7.82125L9.32296 3.01292C9.42059 2.91529 9.57888 2.91529 9.67651 3.01292L10.2422 3.57861C10.3398 3.67624 10.3398 3.83453 10.2422 3.93216L6.17633 7.99802L10.2422 12.0639C10.3398 12.1615 10.3398 12.3198 10.2422 12.4174L9.67651 12.9831Z"
                  fill="currentColor"
                />
              </svg>
            ),
            captionNextIcon: (
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                <path
                  fillRule="evenodd"
                  clipRule="evenodd"
                  d="M6.3225 3.01683C6.42013 2.9192 6.57843 2.9192 6.67606 3.01683L11.4844 7.82515C11.582 7.92278 11.582 8.08108 11.4844 8.17871L6.67606 12.987C6.57842 13.0847 6.42013 13.0847 6.3225 12.987L5.75682 12.4213C5.65919 12.3237 5.65919 12.1654 5.75682 12.0678L9.82268 8.00193L5.75682 3.93607C5.65919 3.83843 5.65919 3.68014 5.75682 3.58251L6.3225 3.01683Z"
                  fill="currentColor"
                />
              </svg>
            ),
            // DayButton 的 UI 设计看起来不复杂，但实际非常复杂，需要根据不同的状态来设置不同的样式。
            // 这里为了实现 dashed border 不得不采用切图的方式（没有用 svg 是因为 png3x 更安全，svg 复制出来有一些 clipPath id 的干扰），因为 dashed border 在 CSS 中无法调整 offset 或 dash 的值，这使得每个单元格无法相互连接
            // 为了实现此需求竟然切了 7 张图，不会有下次了[手动拳头]
            // 我也明白这里的逻辑交给业务方只会更痛苦。咋说呢，如果想自己研究，可以去看看 react day picker API。
            components: {
              DayButton: ({ day, modifiers, className, ...props }) => {
                const {
                  focus,
                  today,
                  disabled,
                  outside,
                  selected,
                  rangeStart,
                  rangeStartHover,
                  rangeEnd,
                  rangeEndHover,
                  selectedRange,
                  rangeStartSelecting,
                  rangeEndSelecting,
                  selectedRangeSelecting,
                } = modifiers;

                const date = day.date.getDate();
                const isRowStart = day.date.getDay() === 0;
                const isRowEnd = day.date.getDay() === 6;

                let bg = '';
                const baseUrl = 'https://wxa.wxs.qq.com/wxad-design/yijie/';

                if (rangeEndHover && !rangeStartHover) {
                  bg = `${baseUrl}selection-end-selecting-bg.png`;
                } else if (rangeStartHover && !rangeEndHover) {
                  bg = `${baseUrl}selection-start-selecting-bg.png`;
                } else if (selectedRangeSelecting) {
                  if (rangeStart) {
                    bg = `${baseUrl}selecting-start-bg.png`;
                  } else if (rangeEnd) {
                    bg = `${baseUrl}selecting-end-bg.png`;
                  } else if (isRowStart) {
                    bg = `${baseUrl}selecting-in-range-row-start-bg.png`;
                  } else if (isRowEnd) {
                    bg = `${baseUrl}selecting-in-range-row-end-bg.png`;
                  } else {
                    bg = `${baseUrl}selecting-in-range-bg.png`;
                  }
                }

                return (
                  <button
                    className={cn(
                      className,
                      'relative flex justify-center w-full h-6',
                      isRowStart && 'rounded-l',
                      isRowEnd && 'rounded-r',
                      selectedRange && 'bg-[#f3f3f3]',
                      rangeStart &&
                        !rangeEnd &&
                        !selectedRangeSelecting &&
                        `bg-gradient-to-r from-transparent to-[#f3f3f3] to-50%`,
                      rangeEnd &&
                        !rangeStart &&
                        !selectedRangeSelecting &&
                        `bg-gradient-to-r from-[#f3f3f3] to-transparent to-50%`,
                      selectedRangeSelecting && 'bg-transparent',
                    )}
                    {...props}
                  >
                    {!!bg && (
                      <div
                        className="absolute top-0 left-0 w-full h-full bg-cover"
                        style={{
                          backgroundImage: `url(${bg})`,
                        }}
                      />
                    )}
                    <span
                      className={cn(
                        'flex items-center justify-center text-black text-sm size-6 rounded',
                        disabled && 'text-[#0A0A0A29]',
                        (rangeStart || rangeEnd) &&
                          'text-[white] bg-[#0A0A0AF5]',
                      )}
                    >
                      {date}
                    </span>
                    {/* 这个绝对定位元素是为了增加 hover 区域，去掉你就知道 hover 区域没连上（即使设计稿上确实没连上）很难受了 */}
                    <div className="absolute top-0 left-0 w-full h-8" />
                  </button>
                );
              },
            },
          }
        : {})}
      // 最大跨度6个月是用户可选择的跨度为6个月，并非只可以选择过去6个月的日期
      onStartDaySelect={(day) => {
        setStartDay(day);
        startDateInputRef.current?.blur();
        endDateInputRef.current?.blur();
      }}
      onEndDaySelect={(day) => {
        setStartDay(undefined);
        startDateInputRef.current?.blur();
        endDateInputRef.current?.blur();
      }}
      disabledDays={(day) =>
        !!startDay &&
        ((!!sixMonthsBefore && day < sixMonthsBefore) ||
          (!!sixMonthsLater && day > sixMonthsLater))
      }
    />
  );
};

const Usage = () => {
  const [value, setValue] = useState<[Date, Date]>([
    new Date(new Date().getTime() - 7 * 24 * 60 * 60 * 1000),
    new Date(),
  ]);

  const [stylePack, setStylePack] = useState(initialStylePack);
  const [enableCustomStyle, setEnableCustomStyle] = useState(true);
  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);
  const enableParamsRef = useRef({ enableCustomStyle });

  useEffect(() => {
    enableParamsRef.current.enableCustomStyle = enableCustomStyle;
  }, [enableCustomStyle]);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    const params = { ...stylePack };

    pane.addBinding(enableParamsRef.current, 'enableCustomStyle', {
      label: '启用自定义样式',
    });

    // button
    const buttonFolder = pane.addFolder({ title: 'Button', expanded: false });
    buttonFolder.addBinding(params, '--odn-button-medium-padding-inline', {
      label: '内边距',
    });
    buttonFolder.addBinding(params, '--odn-button-medium-height', {
      label: '高度',
    });
    buttonFolder.addBinding(params, '--odn-button-medium-font-size', {
      label: '字号',
    });
    buttonFolder.addBinding(params, '--odn-button-medium-icon-size', {
      label: '图标尺寸',
    });
    buttonFolder.addBinding(params, '--odn-button-medium-icon-gap', {
      label: '图标间距',
    });
    buttonFolder.addBinding(params, '--odn-button-medium-border-radius', {
      label: '圆角',
    });

    const buttonPrimaryFolder = buttonFolder.addFolder({
      title: 'Primary',
      expanded: false,
    });
    buttonPrimaryFolder.addBinding(params, '--odn-button-primary-font-weight', {
      label: '字重',
    });
    buttonPrimaryFolder.addBinding(params, '--odn-button-primary-color', {
      label: '颜色',
    });
    buttonPrimaryFolder.addBinding(params, '--odn-button-primary-bg', {
      label: '背景',
    });
    buttonPrimaryFolder.addBinding(
      params,
      '--odn-button-primary-border-color',
      {
        label: '边框色',
      },
    );
    buttonPrimaryFolder.addBinding(
      params,
      '--odn-button-primary-loading-icon-color',
      {
        label: '加载图标色',
      },
    );
    buttonPrimaryFolder.addBinding(params, '--odn-button-primary-bg-hover', {
      label: '悬停背景',
    });
    buttonPrimaryFolder.addBinding(
      params,
      '--odn-button-primary-border-color-hover',
      {
        label: '悬停边框色',
      },
    );
    buttonPrimaryFolder.addBinding(params, '--odn-button-primary-bg-active', {
      label: '激活背景',
    });
    buttonPrimaryFolder.addBinding(
      params,
      '--odn-button-primary-border-color-active',
      {
        label: '激活边框色',
      },
    );

    const buttonNormalFolder = buttonFolder.addFolder({
      title: 'Normal',
      expanded: false,
    });
    buttonNormalFolder.addBinding(params, '--odn-button-normal-font-weight', {
      label: '字重',
    });
    buttonNormalFolder.addBinding(params, '--odn-button-normal-color', {
      label: '颜色',
    });
    buttonNormalFolder.addBinding(params, '--odn-button-normal-bg', {
      label: '背景',
    });
    buttonNormalFolder.addBinding(params, '--odn-button-normal-border-color', {
      label: '边框色',
    });
    buttonNormalFolder.addBinding(
      params,
      '--odn-button-normal-loading-icon-color',
      {
        label: '加载图标色',
      },
    );
    buttonNormalFolder.addBinding(params, '--odn-button-normal-bg-hover', {
      label: '悬停背景',
    });
    buttonNormalFolder.addBinding(
      params,
      '--odn-button-normal-border-color-hover',
      {
        label: '悬停边框色',
      },
    );
    buttonNormalFolder.addBinding(params, '--odn-button-normal-bg-active', {
      label: '激活背景',
    });
    buttonNormalFolder.addBinding(
      params,
      '--odn-button-normal-border-color-active',
      {
        label: '激活边框色',
      },
    );

    // radio
    const radioFolder = pane.addFolder({ title: 'Radio', expanded: false });
    radioFolder.addBinding(params, '--odn-radio-indicator-size-medium', {
      label: '指示器尺寸',
    });
    radioFolder.addBinding(params, '--odn-radio-indicator-bg', {
      label: '指示器背景',
    });
    radioFolder.addBinding(params, '--odn-radio-indicator-scale-initial', {
      label: '初始缩放',
    });
    radioFolder.addBinding(params, '--odn-radio-color', {
      label: '颜色',
    });
    radioFolder.addBinding(params, '--odn-radio-input-bg', {
      label: '输入背景',
    });
    radioFolder.addBinding(params, '--odn-radio-input-border', {
      label: '输入边框',
    });
    radioFolder.addBinding(params, '--odn-radio-input-bg-checked', {
      label: '选中背景',
    });
    radioFolder.addBinding(params, '--odn-radio-input-border-checked', {
      label: '选中边框',
    });
    radioFolder.addBinding(params, '--odn-radio-input-bg-checked-hover', {
      label: '选中悬停背景',
    });
    radioFolder.addBinding(params, '--odn-radio-input-border-checked-hover', {
      label: '选中悬停边框',
    });
    radioFolder.addBinding(params, '--odn-radio-input-bg-checked-focus', {
      label: '选中聚焦背景',
    });
    radioFolder.addBinding(params, '--odn-radio-input-border-checked-focus', {
      label: '选中聚焦边框',
    });

    // input
    const inputFolder = pane.addFolder({ title: 'Input', expanded: false });
    const inputLargeFolder = inputFolder.addFolder({
      title: 'Large',
      expanded: false,
    });
    inputLargeFolder.addBinding(params, '--odn-input-padding-block-large', {
      label: '垂直内边距',
    });
    inputLargeFolder.addBinding(params, '--odn-input-padding-inline-large', {
      label: '水平内边距',
    });
    inputLargeFolder.addBinding(params, '--odn-input-font-size-large', {
      label: '字号',
    });
    inputLargeFolder.addBinding(params, '--odn-input-line-height-large', {
      label: '行高',
    });
    inputLargeFolder.addBinding(params, '--odn-input-border-radius-large', {
      label: '圆角',
    });
    inputLargeFolder.addBinding(params, '--odn-input-icon-size-large', {
      label: '图标尺寸',
    });
    inputLargeFolder.addBinding(
      params,
      '--odn-input-icon-margin-inline-large',
      {
        label: '图标水平边距',
      },
    );

    const inputMediumFolder = inputFolder.addFolder({
      title: 'Medium',
      expanded: false,
    });
    inputMediumFolder.addBinding(params, '--odn-input-padding-block-medium', {
      label: '垂直内边距',
    });
    inputMediumFolder.addBinding(params, '--odn-input-padding-inline-medium', {
      label: '水平内边距',
    });
    inputMediumFolder.addBinding(params, '--odn-input-font-size-medium', {
      label: '字号',
    });
    inputMediumFolder.addBinding(params, '--odn-input-line-height-medium', {
      label: '行高',
    });
    inputMediumFolder.addBinding(params, '--odn-input-border-radius-medium', {
      label: '圆角',
    });
    inputMediumFolder.addBinding(params, '--odn-input-icon-size-medium', {
      label: '图标尺寸',
    });
    inputMediumFolder.addBinding(
      params,
      '--odn-input-icon-margin-inline-medium',
      {
        label: '图标水平边距',
      },
    );

    const inputNormalFolder = inputFolder.addFolder({
      title: 'Normal',
      expanded: false,
    });
    inputNormalFolder.addBinding(params, '--odn-input-bg-normal', {
      label: '背景',
    });
    inputNormalFolder.addBinding(params, '--odn-input-bg-normal-hover', {
      label: '悬停背景',
    });
    inputNormalFolder.addBinding(params, '--odn-input-bg-normal-focus', {
      label: '聚焦背景',
    });
    inputNormalFolder.addBinding(params, '--odn-input-color-normal', {
      label: '颜色',
    });
    inputNormalFolder.addBinding(params, '--odn-input-color-normal-hover', {
      label: '悬停颜色',
    });
    inputNormalFolder.addBinding(params, '--odn-input-color-normal-focus', {
      label: '聚焦颜色',
    });
    inputNormalFolder.addBinding(params, '--odn-input-border-width', {
      label: '边框宽度',
    });
    inputNormalFolder.addBinding(params, '--odn-input-border-normal', {
      label: '边框',
    });
    inputNormalFolder.addBinding(params, '--odn-input-border-normal-hover', {
      label: '悬停边框',
    });
    inputNormalFolder.addBinding(params, '--odn-input-border-normal-focus', {
      label: '聚焦边框',
    });
    inputNormalFolder.addBinding(params, '--odn-input-shadow-normal-focus', {
      label: '聚焦阴影',
    });

    const inputDangerFolder = inputFolder.addFolder({
      title: 'Danger',
      expanded: false,
    });
    inputDangerFolder.addBinding(params, '--odn-input-border-danger', {
      label: '边框',
    });
    inputDangerFolder.addBinding(params, '--odn-input-border-danger-hover', {
      label: '悬停边框',
    });
    inputDangerFolder.addBinding(params, '--odn-input-border-danger-focus', {
      label: '聚焦边框',
    });
    inputDangerFolder.addBinding(params, '--odn-input-shadow-danger-focus', {
      label: '聚焦阴影',
    });

    // popover
    const popoverFolder = pane.addFolder({ title: 'Popover', expanded: false });
    popoverFolder.addBinding(params, '--odn-popover-padding-block', {
      label: '垂直内边距',
    });
    popoverFolder.addBinding(params, '--odn-popover-padding-inline', {
      label: '水平内边距',
    });
    popoverFolder.addBinding(params, '--odn-popover-font-size', {
      label: '字号',
    });
    popoverFolder.addBinding(params, '--odn-popover-line-height', {
      label: '行高',
    });
    popoverFolder.addBinding(params, '--odn-popup-border-radius', {
      label: '圆角',
    });
    popoverFolder.addBinding(params, '--odn-popup-border', {
      label: '边框',
    });
    popoverFolder.addBinding(params, '--odn-popup-box-shadow', {
      label: '阴影',
    });
    popoverFolder.addBinding(params, '--odn-popup-filter', {
      label: '滤镜',
    });

    // date-picker
    const datePickerFolder = pane.addFolder({ title: 'Date Picker' });
    datePickerFolder.addBinding(params, '--odn-dp-month-margin-block-start', {
      label: '月份上边距',
    });
    datePickerFolder.addBinding(params, '--odn-dp-nav-shadow', {
      label: '导航阴影',
    });
    datePickerFolder.addBinding(params, '--odn-dp-nav-padding-block-start', {
      label: '导航上内边距',
    });
    datePickerFolder.addBinding(params, '--odn-dp-nav-padding-block-end', {
      label: '导航下内边距',
    });
    datePickerFolder.addBinding(params, '--odn-dp-nav-padding-inline', {
      label: '导航水平内边距',
    });
    datePickerFolder.addBinding(params, '--odn-dp-nav-button-size', {
      label: '导航按钮尺寸',
    });
    datePickerFolder.addBinding(params, '--odn-dp-weekday-width', {
      label: '星期宽度',
    });
    datePickerFolder.addBinding(params, '--odn-dp-weekday-height', {
      label: '星期高度',
    });
    datePickerFolder.addBinding(params, '--odn-dp-weekday-font-size', {
      label: '星期字号',
    });
    datePickerFolder.addBinding(params, '--odn-dp-weekday-font-weight', {
      label: '星期字重',
    });
    datePickerFolder.addBinding(params, '--odn-dp-weekday-color', {
      label: '星期颜色',
    });
    datePickerFolder.addBinding(params, '--odn-dp-table-row-gap', {
      label: '表格行间距',
    });
    datePickerFolder.addBinding(params, '--odn-dp-day-size', {
      label: '日期尺寸',
    });
    datePickerFolder.addBinding(params, '--odn-dp-td-hover-fill-offset-x', {
      label: '悬停填充偏移',
    });
    datePickerFolder.addBinding(params, '--odn-dp-hover-fill-color', {
      label: '悬停填充色',
    });

    pane.on('change', (ev) => {
      // @ts-ignore
      if (ev.target.key === 'enableCustomStyle') {
        setEnableCustomStyle(enableParamsRef.current.enableCustomStyle);
      } else {
        setStylePack({ ...params });
      }
    });

    return () => {
      pane.dispose();
    };
  }, []);

  return (
    <div>
      <CodeBox
        style={enableCustomStyle ? stylePack : undefined}
        className="flex flex-row-reverse p-2 justify-between gap-4"
      >
        <div ref={tweakpaneContainerRef} className="self-end opacity-90" />
        <div className="self-start sticky top-2">
          <DateRangePickerCustomize
            value={value}
            onChange={setValue}
            minDate={
              new Date(new Date().getTime() - 30 * 24 * 24 * 60 * 60 * 1000)
            }
            maxDate={new Date()}
            stylePack={enableCustomStyle ? stylePack : undefined}
          />
        </div>
      </CodeBox>
    </div>
  );
};

export default Usage;
```
## API {#api}

`DatePickerRangeProps` 继承 `DatePicker` 的 `DatePickerCommonProps`（与单日期选择器共享的公共项），并增加区间相关字段：

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| value | 区间值 | `[Date, Date] \| null` | - |
| onChange | 变化 | `(date: [Date, Date] \| null, info: { dateString: string }) => void` | - |
| onStartDaySelect / onEndDaySelect | 起止日选择 | `(date?: Date) => void` | - |
| shortcuts | 快捷区间 | `{ label, value?: [Date, Date], active?, onClick? }[]` | - |
| format | 自定义展示 | `(date, info) => string` | - |
| maxDays / minDays | 区间最长/最短天数 | `number` | - |
| numberOfMonths | 显示月数 | `number` | `2` |
| popoverProps | 透传 Popover | `Omit<PopoverProps, 'popup' \| 'children'>` | - |

## 变量 {#variables}

参考 `DatePicker` 变量。

---

## 表单 Form

## 常规形态

**示例：常规形态** — 支持左对齐和右对齐两种 Label 对齐方式，Form 会自动计算最长 label 的宽度统一对齐。也可通过 labelSize 手动指定 label 宽度（单位 em）

```tsx
'use client';

import { Button, Form, Input, Select } from 'one-design-next';
import React from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const FormItems = () => (
  <>
    <Form.Item label="名称" name="name">
      <Input placeholder="请输入" className="flex-1" />
    </Form.Item>
    <Form.Item label="城市" name="city" tooltip="请输入省份和城市">
      <Input placeholder="请输入" className="flex-1" />
      <Input placeholder="请输入" className="flex-1" />
    </Form.Item>
    <Form.Item label="移动电话" name="phone">
      <Select
        className="w-[72px]"
        value="+86"
        options={[
          { value: '+86', label: '+86' },
          { value: '+1', label: '+1' },
          { value: '+852', label: '+852' },
        ]}
      />
      <Input placeholder="请输入" className="flex-1" />
    </Form.Item>
    <Form.Item label="验证码" name="code" help="将以短信方式发送至你的手机号">
      <Input placeholder="请输入" className="w-[148px]" />
      <Button>获取验证码</Button>
    </Form.Item>
  </>
);

const Basic = () => {
  return (
    <div>
      <CodeBox className="flex flex-col pt-8 pr-8 pb-8 pl-8">
        <div className="flex gap-24">
          <div className="flex-1">
            <h4 className="font-semibold mb-4">左对齐</h4>
            <Form>
              <FormItems />
            </Form>
          </div>
          <div className="flex-1">
            <h4 className="font-semibold mb-4">右对齐</h4>
            <Form labelAlign="right">
              <FormItems />
            </Form>
          </div>
        </div>
      </CodeBox>
      <CodeBlock>{`import { Form, Input, Select, Button } from "one-design-next";

{/* 左对齐 - 自动计算 label 宽度 */}
<Form>
  <Form.Item label="名称" name="name">
    <Input placeholder="请输入" />
  </Form.Item>
  <Form.Item label="移动电话" name="phone">
    <Select value="+86" options={[...]} />
    <Input placeholder="请输入" />
  </Form.Item>
</Form>

{/* 右对齐 */}
<Form labelAlign="right">
  <Form.Item label="名称" name="name">
    <Input placeholder="请输入" />
  </Form.Item>
</Form>

{/* 手动指定 labelSize */}
<Form labelSize={5}>
  ...
</Form>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 错误提示

**示例：错误提示** — 通过 error 属性设置错误提示信息

```tsx
'use client';

import { Button, Form, Input, Select } from 'one-design-next';
import React from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Error = () => {
  return (
    <div>
      <CodeBox className="flex flex-col pt-8 pr-8 pb-8 pl-8">
        <Form>
          <Form.Item label="名称" name="name" error="请输入名称">
            <Input placeholder="请输入" intent="danger" className="w-60" />
          </Form.Item>
          <Form.Item label="城市" name="city" tooltip="请输入省份和城市">
            <Input placeholder="请输入" className="w-[116px]" />
            <Input placeholder="请输入" className="w-[116px]" />
          </Form.Item>
          <Form.Item label="移动电话" name="phone">
            <Select
              className="w-[72px]"
              value="+86"
              options={[
                { value: '+86', label: '+86' },
                { value: '+1', label: '+1' },
                { value: '+852', label: '+852' },
              ]}
            />
            <Input placeholder="请输入" className="flex-1" />
          </Form.Item>
          <Form.Item
            label="验证码"
            name="code"
            help="将以短信方式发送至你的手机号"
          >
            <Input placeholder="请输入" className="w-[148px]" />
            <Button>获取验证码</Button>
          </Form.Item>
        </Form>
      </CodeBox>
      <CodeBlock>{`import { Form, Input, Select, Button } from "one-design-next";

<Form>
  <Form.Item label="名称" name="name" error="请输入名称">
    <Input placeholder="请输入" intent="danger" />
  </Form.Item>
  <Form.Item label="城市" name="city" tooltip="请输入省份和城市">
    <Input placeholder="请输入" />
    <Input placeholder="请输入" />
  </Form.Item>
  <Form.Item label="移动电话" name="phone">
    <Select value="+86" options={[{ value: '+86', label: '+86' }]} />
    <Input placeholder="请输入" />
  </Form.Item>
  <Form.Item label="验证码" name="code" help="将以短信方式发送至你的手机号">
    <Input placeholder="请输入" />
    <Button>获取验证码</Button>
  </Form.Item>
</Form>`}</CodeBlock>
    </div>
  );
};

export default Error;
```
## 设置 Label 单行最大字符数

**示例：设置 Label 单行最大字符数** — 通过 labelMaxChars 限制标签单行最大字符数

```tsx
'use client';

import { Button, Form, Input, Select } from 'one-design-next';
import React from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const LabelMaxChars = () => {
  return (
    <div>
      <CodeBox className="flex flex-col pt-8 pr-8 pb-8 pl-8">
        <Form>
          <Form.Item label="单行最多七个字" name="name" labelMaxChars={7}>
            <Input placeholder="请输入" className="w-60" />
          </Form.Item>
          <Form.Item
            label="城市"
            name="city"
            labelMaxChars={7}
            tooltip="请输入省份和城市"
          >
            <Input placeholder="请输入" className="w-[116px]" />
            <Input placeholder="请输入" className="w-[116px]" />
          </Form.Item>
          <Form.Item label="移动电话" name="phone" labelMaxChars={7}>
            <Select
              className="w-[72px]"
              value="+86"
              options={[
                { value: '+86', label: '+86' },
                { value: '+1', label: '+1' },
                { value: '+852', label: '+852' },
              ]}
            />
            <Input placeholder="请输入" className="flex-1" />
          </Form.Item>
          <Form.Item
            label="验证码"
            name="code"
            labelMaxChars={7}
            help="将以短信方式发送至你的手机号"
          >
            <Input placeholder="请输入" className="w-[148px]" />
            <Button>获取验证码</Button>
          </Form.Item>
        </Form>
      </CodeBox>
      <CodeBlock>{`import { Form, Input, Select, Button } from "one-design-next";

<Form>
  <Form.Item label="单行最多七个字" name="name" labelMaxChars={7}>
    <Input placeholder="请输入" />
  </Form.Item>
  <Form.Item label="城市" name="city" labelMaxChars={7} tooltip="请输入省份和城市">
    <Input placeholder="请输入" />
    <Input placeholder="请输入" />
  </Form.Item>
  <Form.Item label="移动电话" name="phone" labelMaxChars={7}>
    <Select value="+86" options={[{ value: '+86', label: '+86' }]} />
    <Input placeholder="请输入" />
  </Form.Item>
  <Form.Item label="验证码" name="code" labelMaxChars={7} help="将以短信方式发送至你的手机号">
    <Input placeholder="请输入" />
    <Button>获取验证码</Button>
  </Form.Item>
</Form>`}</CodeBlock>
    </div>
  );
};

export default LabelMaxChars;
```
## 栅栏排布

**示例：栅栏排布** — 通过 CSS Grid 实现多列栅栏布局

```tsx
'use client';

import { Form, Input, Select } from 'one-design-next';
import React from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Grid = () => {
  return (
    <div>
      <CodeBox className="flex flex-col pt-8 pr-8 pb-8 pl-8">
        <Form>
          <div className="grid grid-cols-3 gap-x-16">
            <Form.Item label="城市" name="city1">
              <Input placeholder="搜索并选择城市" className="flex-1" />
            </Form.Item>
            <Form.Item label="联网环境" name="network1">
              <Select
                className="flex-1"
                placeholder="请选择"
                options={[
                  { value: 'wifi', label: 'WiFi' },
                  { value: '4g', label: '4G' },
                  { value: '5g', label: '5G' },
                ]}
              />
            </Form.Item>
            <Form.Item label="联网环境" name="network2">
              <Select
                className="flex-1"
                placeholder="请选择"
                options={[
                  { value: 'wifi', label: 'WiFi' },
                  { value: '4g', label: '4G' },
                  { value: '5g', label: '5G' },
                ]}
              />
            </Form.Item>
            <Form.Item label="兴趣" name="interest">
              <Input placeholder="搜索并选择城市" className="flex-1" />
            </Form.Item>
            <Form.Item label="手机型号" name="model1">
              <Select
                className="flex-1"
                placeholder="请选择"
                options={[
                  { value: 'iphone', label: 'iPhone' },
                  { value: 'android', label: 'Android' },
                ]}
              />
            </Form.Item>
            <Form.Item label="手机型号" name="model2">
              <Select
                className="flex-1"
                placeholder="请选择"
                options={[
                  { value: 'iphone', label: 'iPhone' },
                  { value: 'android', label: 'Android' },
                ]}
              />
            </Form.Item>
          </div>
        </Form>
      </CodeBox>
      <CodeBlock>{`import { Form, Input, Select } from "one-design-next";

<Form>
  <div className="grid grid-cols-3 gap-x-16">
    <Form.Item label="城市" name="city">
      <Input placeholder="搜索并选择城市" />
    </Form.Item>
    <Form.Item label="联网环境" name="network">
      <Select placeholder="请选择" options={[...]} />
    </Form.Item>
    <Form.Item label="联网环境" name="network2">
      <Select placeholder="请选择" options={[...]} />
    </Form.Item>
    <Form.Item label="兴趣" name="interest">
      <Input placeholder="搜索并选择城市" />
    </Form.Item>
    <Form.Item label="手机型号" name="model">
      <Select placeholder="请选择" options={[...]} />
    </Form.Item>
    <Form.Item label="手机型号" name="model2">
      <Select placeholder="请选择" options={[...]} />
    </Form.Item>
  </div>
</Form>`}</CodeBlock>
    </div>
  );
};

export default Grid;
```
## 纯数据展示类

**示例：纯数据展示类** — 通过 display 属性实现纯数据展示模式

```tsx
'use client';

import { Form } from 'one-design-next';
import React from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const DisplayItems = () => (
  <>
    <Form.Item label="名称" display>
      微信广告助手
    </Form.Item>
    <Form.Item label="城市" display>
      广东省，深圳市
    </Form.Item>
    <Form.Item label="移动电话" display>
      +86 133 1839 4353
    </Form.Item>
    <Form.Item label="账户类型" display>
      广告主
    </Form.Item>
  </>
);

const Display = () => {
  return (
    <div>
      <CodeBox className="flex flex-col pt-8 pr-8 pb-8 pl-8">
        <div className="flex gap-24">
          <div className="flex-1">
            <h4 className="font-semibold mb-4">左对齐</h4>
            <Form>
              <DisplayItems />
            </Form>
          </div>
          <div className="flex-1">
            <h4 className="font-semibold mb-4">右对齐</h4>
            <Form labelAlign="right">
              <DisplayItems />
            </Form>
          </div>
        </div>
      </CodeBox>
      <CodeBlock>{`import { Form } from "one-design-next";

{/* 左对齐 - 自动计算 label 宽度 */}
<Form>
  <Form.Item label="名称" display>微信广告助手</Form.Item>
  <Form.Item label="城市" display>广东省，深圳市</Form.Item>
  <Form.Item label="移动电话" display>+86 133 1839 4353</Form.Item>
  <Form.Item label="账户类型" display>广告主</Form.Item>
</Form>

{/* 右对齐 */}
<Form labelAlign="right">
  <Form.Item label="名称" display>微信广告助手</Form.Item>
  <Form.Item label="城市" display>广东省，深圳市</Form.Item>
  <Form.Item label="移动电话" display>+86 133 1839 4353</Form.Item>
  <Form.Item label="账户类型" display>广告主</Form.Item>
</Form>`}</CodeBlock>
    </div>
  );
};

export default Display;
```
## API

### Form

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| validationMode | 校验触发时机 | `'onSubmit' \| 'onBlur' \| 'onChange'` | `'onSubmit'` |
| errors | 外部错误信息（字段名 → 文案） | `Record<string, string \| string[]>` | - |
| onFormSubmit | 提交成功且校验通过时回调 | `(formValues: Record<string, any>, eventDetails: any) => void` | - |
| labelSize | 标签统一宽度（em） | `number` | 自动计算 |
| labelAlign | 标签对齐 | `'left' \| 'right'` | `'left'` |
| children | 子节点 | `React.ReactNode` | - |

继承 `Omit<React.FormHTMLAttributes<HTMLFormElement>, 'onSubmit'>`。

### Form.Item

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| name | 字段名 | `string` | - |
| label | 标签 | `React.ReactNode` | - |
| labelAlign | 标签对齐（优先级高于 Form） | `'left' \| 'right'` | - |
| labelWidth | 标签宽度（px 或 CSS 长度） | `number \| string` | - |
| labelMaxChars | 标签单行最大字符数（超出换行） | `number` | - |
| required | 是否必填 | `boolean` | `false` |
| tooltip | 问号提示（Tooltip） | `React.ReactNode` | - |
| help | 帮助文案（控件下方） | `React.ReactNode` | - |
| error | 错误信息（控件下方） | `React.ReactNode` | - |
| validate | 自定义校验 | `(value: unknown) => string \| string[] \| null \| Promise<...>` | - |
| validationMode | 校验模式（可覆盖 Form） | `'onSubmit' \| 'onBlur' \| 'onChange'` | - |
| disabled | 是否禁用 | `boolean` | `false` |
| display | 纯展示模式 | `boolean` | `false` |
| children | 控件 | `React.ReactNode` | - |

继承 `React.HTMLAttributes<HTMLDivElement>`。

### Form.Description

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| children | 描述 | `React.ReactNode` | - |

继承 `React.HTMLAttributes<HTMLParagraphElement>`（透传至 Base Field Description）。

## 变量

<VariablesTable id="Form"></VariablesTable>

---

## 数字输入 InputNumber

## 基础用例 {#basic-usage}

**示例：基础用例** — 支持步长、范围限制和上下按钮的数字输入框

```tsx
'use client';

import { InputNumber } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

const Basics = () => {
  const [value, setValue] = useState<number | null>(10);
  const [params, setParams] = useState({
    size: 'medium',
    intent: 'normal',
    light: false,
    disabled: false,
    min: 0,
    max: 100,
    step: 1,
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'size', {
      options: {
        small: 'small',
        medium: 'medium',
        large: 'large',
      },
    });

    pane.addBinding(params, 'intent', {
      options: {
        normal: 'normal',
        danger: 'danger',
      },
    });

    pane.addBinding(params, 'light', {
      type: 'boolean',
    });

    pane.addBinding(params, 'disabled', {
      type: 'boolean',
    });

    pane.addBinding(params, 'min', {
      min: -100,
      max: 100,
      step: 1,
    });

    pane.addBinding(params, 'max', {
      min: -100,
      max: 200,
      step: 1,
    });

    pane.addBinding(params, 'step', {
      min: 0.5,
      max: 10,
      step: 0.5,
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />

        <div className="flex flex-col gap-8">
          <div>
            <InputNumber
              value={value}
              onChange={setValue}
              min={params.min}
              max={params.max}
              step={params.step}
              size={params.size as any}
              intent={params.intent as any}
              light={params.light}
              disabled={params.disabled}
            />
          </div>
        </div>
      </CodeBox>

      <CodeBlock>{`import { InputNumber } from "one-design-next";

const [value, setValue] = useState<number | null>(10);

<InputNumber
  value={value}
  onChange={setValue}
  min={0}
  max={100}
  step={1}
  size="medium"
  intent="normal"
  light={false}
  disabled={false}
/>`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## API {#api}

在 `Input` 能力之外增加数值逻辑（继承 `Omit<InputProps, 'value' \| 'onChange'>`）。

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| value | 当前值 | `number \| null` | - |
| defaultValue | 默认值 | `number` | - |
| min | 最小值 | `number` | `0` |
| max | 最大值 | `number` | - |
| step | 步长 | `number` | `1` |
| onChange | 值变化 | `(value: number \| null) => void` | - |
| showButtons | 是否显示上下按钮 | `boolean` | `true` |

## 变量 {#variables}

<VariablesTable id="InputNumber"></VariablesTable>

---

## 验证码输入 InputOtp

## 动效示例 {#motion-example}

下面是一个应用动效的例子。你可以先后输入错误和正确的密码体验一下：

**示例：motion** — motion

```tsx
'use client';

import { animate, motion, useMotionValue } from 'motion/react';
import { InputOtp, InputOtpRef } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';

const Basics = () => {
  const inputRef = useRef<InputOtpRef>(null);
  const [value, setValue] = useState('');
  const validPassword = '123456';
  const blurTimer = useRef(0);
  const [focusIndex, setFocusIndex] = useState<number | null>(null);
  const prevFocusIndex = useRef(focusIndex);
  const indicatorX = useMotionValue(0);
  const indicatorOpacity = useMotionValue(0);
  const indicatorColor = useMotionValue('#000');
  const wrapperX = useMotionValue(0);
  const wrapperOpacity = useMotionValue(1);
  const errorOpacity = useMotionValue(0);
  const tipY = useMotionValue(0);

  useEffect(() => {
    if (value.length === validPassword.length) {
      if (value === validPassword) {
        animate(indicatorOpacity, 0, {
          duration: 0.2,
          ease: 'easeInOut',
        });
        animate(wrapperOpacity, 0, {
          delay: 0.15,
          duration: 0.5,
          ease: 'easeInOut',
          onComplete: () => {
            animate(wrapperOpacity, 1, {
              delay: 0.5,
              duration: 0.3,
              ease: 'easeInOut',
            });
            setFocusIndex(0);
            inputRef.current!.inputs[0]!.focus();
            setValue('');
          },
        });
      } else {
        animate(indicatorOpacity, 0, {
          duration: 0.2,
          ease: 'easeInOut',
          onComplete: () => {
            setTimeout(() => {
              animate(indicatorOpacity, 1, {
                duration: 0.1,
                ease: 'easeInOut',
              });
              animate(indicatorX, 0, {
                duration: 0.25,
                ease: 'easeInOut',
                onComplete: () => {
                  setFocusIndex(0);
                  inputRef.current!.inputs[0]!.focus();
                },
              });
              animate(indicatorColor, '#E63D2E', {
                duration: 0.15,
                ease: 'easeInOut',
              });
              setValue('');

              // 添加左右晃动的报错动画
              animate(wrapperX, [0, 7, -3.5, 3.5, 0], {
                duration: 0.4,
                ease: 'easeInOut',
                times: [0, 0.25, 0.5, 0.75, 1],
              });

              animate(errorOpacity, 1, {
                duration: 0.2,
                ease: 'easeInOut',
              });
              animate(tipY, 18, {
                duration: 0.2,
                ease: 'easeInOut',
              });
            }, 200);
          },
        });
      }
    }
  }, [value]);

  useEffect(() => {
    if (focusIndex !== null) {
      if (prevFocusIndex.current === null) {
        indicatorX.set(0);
      } else {
        animate(indicatorX, focusIndex * 38, {
          duration: 0.1,
          ease: 'easeInOut',
        });
      }

      animate(indicatorOpacity, 1, {
        duration: 0.1,
        ease: 'easeInOut',
      });
    } else {
    }
    prevFocusIndex.current = focusIndex;
  }, [focusIndex]);

  return (
    <div>
      <CodeBox
        className="pt-14 pb-24"
        style={
          {
            '--odn-otp-bg-normal': 'var(--odn-color-black-2)',
            '--odn-otp-bg-normal-hover': 'var(--odn-color-black-2)',
            '--odn-otp-bg-normal-focus': 'var(--odn-color-black-2)',
            '--odn-otp-border-normal': '1px solid transparent',
            '--odn-otp-border-normal-hover': '1px solid transparent',
            '--odn-otp-border-normal-focus': '1px solid transparent',
            '--odn-otp-shadow-normal-focus': 'none',
            '--odn-otp-bg-normal-selection': 'transparent',
            background: 'none',
            caretColor: 'transparent',
          } as React.CSSProperties
        }
      >
        <div className="absolute right-4 top-4 text-xs text-neutral-400">
          演示密码：123456
        </div>
        <motion.div
          className="relative"
          style={{ x: wrapperX, opacity: wrapperOpacity }}
        >
          <InputOtp
            ref={inputRef}
            placeholder="0"
            autoComplete="off"
            value={value}
            onChange={(val) => {
              animate(indicatorColor, '#000', {
                duration: 0.15,
                ease: 'easeInOut',
              });
              animate(errorOpacity, 0, {
                duration: 0.2,
                ease: 'easeInOut',
              });
              animate(tipY, 0, {
                duration: 0.2,
                ease: 'easeInOut',
              });
              setValue(val);
            }}
            onFocus={(_, index) => {
              clearTimeout(blurTimer.current);
              setFocusIndex(index);
            }}
            onBlur={() => {
              blurTimer.current = window.setTimeout(() => {
                setFocusIndex(null);
              }, 100);
            }}
          />
          <motion.div
            className="absolute top-0 left-0 w-[30px] h-9 border-2 border-solid border-current rounded-md pointer-events-none"
            style={{
              x: indicatorX,
              opacity: indicatorOpacity,
              color: indicatorColor,
            }}
          />
          <motion.div
            className="absolute -bottom-6 left-0 w-full text-center text-xs text-red-600"
            style={{
              opacity: errorOpacity,
            }}
          >
            输入有误，请重新输入
          </motion.div>
          <motion.div
            className="absolute -bottom-8 left-0 w-full text-center text-xs text-black-8"
            style={{
              y: tipY,
            }}
          >
            <span className="text-neutral-400">没有收到？</span>
            <span>再次发送</span>
          </motion.div>
        </motion.div>
      </CodeBox>
      <CodeBlock>{`import { InputOtp } from 'one-design-next';

// 以下仅样式定制，省略了动效逻辑
<InputOtp
  placeholder="0"
  autoComplete="off"
  onFocus={() => {}}
  onBlur={() => {}}
  style={
    {
      '--odn-otp-bg-normal': 'var(--odn-color-black-2)',
      '--odn-otp-bg-normal-hover': 'var(--odn-color-black-2)',
      '--odn-otp-bg-normal-focus': 'var(--odn-color-black-2)',
      '--odn-otp-border-normal': '1px solid transparent',
      '--odn-otp-border-normal-hover': '1px solid transparent',
      '--odn-otp-border-normal-focus': '1px solid transparent',
      '--odn-otp-shadow-normal-focus': 'none',
      '--odn-otp-bg-normal-selection': 'transparent',
      caretColor: 'transparent',
    } as React.CSSProperties
  }
/>`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## 基础用例 {#basic-usage}

**示例：basic** — basic

```tsx
'use client';

import { InputOtp } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

const Basics = () => {
  const [value, setValue] = useState('');
  const [params, setParams] = useState({
    size: 'medium',
    disabled: false,
    length: 6,
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'size', {
      options: {
        small: 'small',
        medium: 'medium',
        large: 'large',
      },
    });

    pane.addBinding(params, 'disabled', {
      type: 'boolean',
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <InputOtp
          value={value}
          onChange={(val) => setValue(val)}
          size={params.size as 'small' | 'medium' | 'large'}
          disabled={params.disabled}
        />
      </CodeBox>
      <CodeBlock>{`import { InputOtp } from "one-design-next";

// value: ${value}
const [value, setValue] = useState('');

<InputOtp
  value={value}
  onChange={(val) => setValue(val)}
  size={${params.size}}
  disabled={${params.disabled}}
/>`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## API {#api}

继承 `Omit<React.ComponentProps<'input'>, 'size' \| 'onChange' \| 'onFocus' \| 'onBlur'>`。

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| length | 格子数量 | `number` | `6` |
| size | 尺寸 | `'small' \| 'medium' \| 'large'` | `'medium'` |
| disabled | 是否禁用 | `boolean` | `false` |
| autoFocus | 是否自动聚焦 | `boolean` | `false` |
| value | 受控值 | `string` | `''` |
| defaultValue | 非受控默认值 | `string` | `''` |
| onChange | 值变化 | `(value: string) => void` | - |
| autoSubmit | 输满是否自动提交表单 | `boolean` | `false` |
| onAutoSubmit | 自动提交回调 | `(value: string) => void` | - |
| placeholder | 占位 | `string` | `''` |
| autoComplete | 自动完成策略 | `'off' \| 'one-time-code'` | `'one-time-code'` |
| onFocus | 聚焦（含格子下标） | `(e, index: number) => void` | - |
| onBlur | 失焦（含格子下标） | `(e, index: number) => void` | - |

`ref`：`focus()`、`inputs[]`。

## 变量 {#variables}

<VariablesTable id="InputOtp"></VariablesTable>

---

## 输入框 Input

## 基础用例 {#basic-usage}

通过 `leftElement` 和 `rightElement` 可以添加左侧和右侧元素；开启 `allowClear` 后，在有值时会显示清空按钮：

**示例：basic** — basic

```tsx
'use client';

import { Icon, Input } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

const Basics = () => {
  const [value, setValue] = useState('');
  const [params, setParams] = useState({
    size: 'medium',
    intent: 'normal',
    light: false,
    disabled: false,
    leftElement: '图标',
    rightElement: '无',
    allowClear: true,
    showCount: true,
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'size', {
      options: {
        small: 'small',
        medium: 'medium',
        large: 'large',
      },
    });

    pane.addBinding(params, 'intent', {
      options: {
        normal: 'normal',
        danger: 'danger',
      },
    });

    pane.addBinding(params, 'light', {
      type: 'boolean',
    });

    pane.addBinding(params, 'disabled', {
      type: 'boolean',
    });

    pane.addBinding(params, 'leftElement', {
      options: {
        图标: '图标',
        无: '无',
      },
    });

    pane.addBinding(params, 'rightElement', {
      options: {
        图标: '图标',
        无: '无',
      },
    });

    pane.addBinding(params, 'allowClear', {
      type: 'boolean',
    });

    pane.addBinding(params, 'showCount', {
      label: 'count',
      type: 'boolean',
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <Input
          className="w-60"
          value={value}
          onChange={(e) => setValue(e.target.value)}
          size={params.size as 'small' | 'medium' | 'large'}
          intent={params.intent as 'normal' | 'danger'}
          light={params.light}
          disabled={params.disabled}
          leftElement={
            params.leftElement === '图标' ? <Icon name="search" /> : undefined
          }
          rightElement={
            params.rightElement === '图标' ? <Icon name="right" /> : undefined
          }
          allowClear={params.allowClear}
          count={params.showCount ? { max: 5 } : undefined}
        />
      </CodeBox>
      <CodeBlock>{`import { Input, Icon } from "one-design-next";
import { useState } from "react";

const [value, setValue] = useState('');

<Input
  className="w-60"
  value={value}
  onChange={(e) => setValue(e.target.value)}
  size="${params.size}"
  intent="${params.intent}"
  light={${params.light}}
  disabled={${params.disabled}}
  leftElement={${params.leftElement === '图标' ? '<Icon name="search" />' : 'undefined'}}
  rightElement={${params.rightElement === '图标' ? '<Icon name="right" />' : 'undefined'}}
  allowClear={${params.allowClear}}
  count={${params.showCount ? '{ max: 5 }' : 'undefined'}}
  placeholder="请输入内容"
/>`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## 字数限制 {#character-limit}

通过 `count` 可以添加字数限制，通过 `count.strategy` 自定义计数策略；同时可通过 `count.formatter` 自定义文本显示：

**示例：input-count** — input-count

```tsx
'use client';

import { Input } from 'one-design-next';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import React, { useState } from 'react';

const InputCountDemo = () => {
  const [value, setValue] = useState('12345');

  // 自定义计数策略：ASCII 字符计为 0.5，其他字符计为 1
  const getFormatStrLeng = (str: string) => {
    const len = str.length;
    let realLength = 0;
    let charCode = -1;
    for (let i = 0; i < len; i += 1) {
      charCode = str.charCodeAt(i);
      if (charCode >= 0 && charCode <= 128) {
        realLength += 0.5;
      } else {
        realLength += 1;
      }
    }
    return Math.ceil(realLength);
  };

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 p-16 gap-16">
        <div className="space-y-2">
          <div className="text-xs text-neutral-500">字母数字 计为 1</div>
          <Input
            className="w-80"
            value={value}
            onChange={(e) => setValue(e.target.value)}
            count={{ max: 5 }}
          />
          <div className="text-xs text-neutral-500">字母数字 计为 0.5</div>
          <Input.Textarea
            className="w-80 h-20"
            value={value}
            onChange={(e) => setValue(e.target.value)}
            count={{ max: 5, strategy: getFormatStrLeng }}
          />
          <div className="text-xs text-neutral-500">自定义格式</div>
          <Input
            className="w-80"
            value={value}
            onChange={(e) => setValue(e.target.value)}
            count={{
              max: 5,
              strategy: (str) => 21,
              formatter: ({ count, max }) => `${count}条/${max}条`,
            }}
          />
        </div>
      </CodeBox>
      <CodeBlock>{`import { Input } from "one-design-next";
import { useState } from "react";

const [value, setValue] = useState('12345');

// 自定义计数策略：ASCII 字符计为 0.5，其他字符计为 1
const getFormatStrLeng = (str: string) => {
  const len = str.length;
  let realLength = 0;
  let charCode = -1;
  for (let i = 0; i < len; i += 1) {
    charCode = str.charCodeAt(i);
    if (charCode >= 0 && charCode <= 128) {
      realLength += 0.5;
    } else {
      realLength += 1;
    }
  }
  return Math.ceil(realLength);
};

// 字母数字 计为 1
<Input
  value={value}
  onChange={(e) => setValue(e.target.value)}
  count={{ max: 5 }}
/>

// 字母数字 计为 0.5
<Input
  value={value}
  onChange={(e) => setValue(e.target.value)}
  count={{ 
    max: 5, 
    strategy: getFormatStrLeng 
  }}
/>

// 自定义计数策略 + 自定义格式化
<Input
  value={value}
  onChange={(e) => setValue(e.target.value)}
  count={{
    max: 5,
    strategy: str => 21,
    formatter: ({ count, max }) => \`\${count}条/\${max}条\`,
  }}
/>`}</CodeBlock>
    </div>
  );
};

export default InputCountDemo;
```
## Textarea 自动高度调整 {#textarea-auto-size}

`autoSize` 属性适用于 `Input.Textarea`，并且只有高度会自动变化。其值可以是 `bool`, 也可以设定为对象，指定最小行数和最大行数：

**示例：textarea** — textarea

```tsx
'use client';

import { Input } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

const TextareaDemo = () => {
  const [value, setValue] = useState(
    'Hello World\nThis is a multi-line text\nfor testing autoSize functionality',
  );
  const [params, setParams] = useState({
    autoSize: true,
    minRows: 2,
    maxRows: 6,
    showCount: true,
    maxCount: 100,
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'autoSize', {
      type: 'boolean',
    });

    pane.addBinding(params, 'minRows', {
      min: 1,
      max: 3,
      step: 1,
    });

    pane.addBinding(params, 'maxRows', {
      min: 4,
      max: 6,
      step: 1,
    });

    pane.addBinding(params, 'showCount', {
      type: 'boolean',
    });

    pane.addBinding(params, 'maxCount', {
      min: 10,
      max: 500,
      step: 10,
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <Input.Textarea
          className="w-80"
          value={value}
          onChange={(e) => setValue(e.target.value)}
          autoSize={
            params.autoSize
              ? {
                  minRows: params.minRows,
                  maxRows: params.maxRows,
                }
              : false
          }
          count={params.showCount ? { max: params.maxCount } : undefined}
          placeholder="输入多行文本，观察自动高度调整..."
        />
      </CodeBox>
      <CodeBlock>{`import { Input } from "one-design-next";
import { useState } from "react";

const [value, setValue] = useState('Hello World\\nThis is a multi-line text\\nfor testing autoSize functionality');

<Input.Textarea
  className="w-80"
  value={value}
  onChange={(e) => setValue(e.target.value)}
  autoSize={{
    minRows: ${params.minRows},
    maxRows: ${params.maxRows},
  }}
  count={${params.showCount ? `{ max: ${params.maxCount} }` : 'undefined'}}
  placeholder="输入多行文本，观察自动高度调整..."
/>`}</CodeBlock>
    </div>
  );
};

export default TextareaDemo;
```
## Textarea 添加上下内容 {#textarea-top-bottom-content}

通过 `topContent` 和 `bottomContent` 可以添加上下内容：

**示例：textarea-top-bottom** — textarea-top-bottom

```tsx
'use client';

import { Button, Input } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const TextareaTopBottomDemo = () => {
  const [value, setValue] = useState('');

  return (
    <div>
      <CodeBox className="flex flex-col p-16 gap-16">
        <Input.Textarea
          className="w-full"
          value={value}
          onChange={(e) => setValue(e.target.value)}
          count={{
            max: 200,
            strategy: (str) => 0,
            formatter: (value) => `${value.count}条/${value.max}条`,
          }}
          autoSize={{
            minRows: 1,
            maxRows: 5,
          }}
          bottomElement={
            <div
              className="flex p-1"
              style={{
                borderTop:
                  'var(--odn-input-border-width) var(--odn-input-border-style) var(--odn-input-border-normal)',
              }}
            >
              <Button light>识别</Button>
              <Button light>清空</Button>
            </div>
          }
          placeholder="请填写推广计划 ID，多个账号用逗号分隔"
        />
      </CodeBox>
      <CodeBlock>{`import { Button, Input } from "one-design-next";
import { useState } from "react";

const [value, setValue] = useState('');

<Input.Textarea
  className="w-full"
  value={value}
  onChange={(e) => setValue(e.target.value)}
  // 如果需要自动高度调整，可开启 autoSize
  autoSize={{
    minRows: 1,
    maxRows: 5,
  }}
  // 自定义计数策略和格式化文本
  count={{
    max: 200,
    strategy: str => 0,
    formatter: (value) => \`\${value.count}条/\${value.max}条\`,
  }}
  bottomElement={
    <div
      className="flex p-1"
      style={{
        borderTop:
          'var(--odn-input-border-width) var(--odn-input-border-style) var(--odn-input-border-normal)',
      }}
    >
      <Button light>识别</Button>
      <Button light>清空</Button>
    </div>
  }
  placeholder="请填写推广计划 ID，多个账号用逗号分隔"
/>`}</CodeBlock>
    </div>
  );
};

export default TextareaTopBottomDemo;
```
## 业务定制 {#business-customization}

通过 CSS Variables 定制样式：

**示例：customize** — customize

```tsx
'use client';

import {
  Input,
  InputRef,
  isLegalDateString,
  MONTHS,
  Popover,
} from 'one-design-next';
import React, { useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
// import { Pane } from 'tweakpane';

const convertDateDisplayToString = (date: string) => {
  const [month, dayWithComma, year] = date.split(' ');
  const day = dayWithComma.replace(',', '');
  const monthIndex = MONTHS.findIndex((m) => m.enUS === month);
  return `${monthIndex + 1 < 10 ? '0' : ''}${monthIndex + 1}/${
    parseInt(day) < 10 ? '0' : ''
  }${day}/${year}`;
};

const convertDateStringToDisplay = (date: string) => {
  const [month, day, year] = date.split('/');
  const monthName = MONTHS[parseInt(month, 10) - 1].enUS;
  return `${monthName} ${day}, ${year}`;
};

const Basics = () => {
  const [value, setValue] = useState('Apr 23, 2025');
  const ref = useRef<InputRef>(null);
  const valueCached = useRef(value);

  const handleFocus = () => {
    setValue(convertDateDisplayToString(value));
    valueCached.current = value;
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setValue(e.target.value);
  };

  const handleBlur = () => {
    if (isLegalDateString(value, 'enUS')) {
      setValue(convertDateStringToDisplay(value));
    } else {
      setValue(valueCached.current);
    }
  };

  return (
    <div>
      <CodeBox
        className="flex-col gap-4"
        style={{
          '--odn-input-padding-block-large': '7.5px',
          '--odn-input-padding-inline-large': '12px',
          '--odn-input-font-size-large': '14px',
          '--odn-input-line-height-large': '1.57142857',
          '--odn-input-border-radius-large': '8px',
          '--odn-input-icon-size-large': '16px',
          '--odn-input-icon-margin-inline-large': '8px',

          '--odn-input-padding-block-medium': '3.5px',
          '--odn-input-padding-inline-medium': '12px',
          '--odn-input-font-size-medium': '14px',
          '--odn-input-line-height-medium': '1.57142857',
          '--odn-input-border-radius-medium': '8px',
          '--odn-input-icon-size-medium': '16px',
          '--odn-input-icon-margin-inline-medium': '8px',

          '--odn-input-bg-normal': '#0A0A0A0D',
          '--odn-input-bg-normal-hover': '#0A0A0A14',
          '--odn-input-bg-normal-focus': '#fff',

          '--odn-input-color-normal': '#000000F5',
          '--odn-input-color-normal-hover': '#000000F5',
          '--odn-input-color-normal-focus': '#000000F5',

          '--odn-input-border-width': '1.5px',

          '--odn-input-border-normal': 'transparent',
          '--odn-input-border-normal-hover': 'transparent',
          '--odn-input-border-normal-focus': '#0A0A0AD6',

          '--odn-input-shadow-normal-focus': 'none',

          '--odn-input-border-danger': '#F04354',
          '--odn-input-border-danger-hover': '#F04354',
          '--odn-input-border-danger-focus': '#F04354',
          '--odn-input-shadow-danger-focus': 'none',
        }}
      >
        <Input
          className="w-[410px] max-w-full"
          size="large"
          placeholder="Here is app name or ID, platform, status"
        />

        <Input
          className="w-[410px] max-w-full"
          placeholder="Here is app name or ID, platform, status"
        />

        <Input
          ref={ref}
          className="w-[160px] max-w-full"
          onFocus={handleFocus}
          onChange={handleChange}
          onBlur={handleBlur}
          value={value}
          placeholder="Select date"
        />

        <Input
          intent="danger"
          className="w-[160px] max-w-full"
          onFocus={handleFocus}
          onChange={handleChange}
          onBlur={handleBlur}
          value={value}
          placeholder="Select date"
          rightElement={
            <Popover
              popup="Maximum range: 6 month"
              arrowed={false}
              placement="bottom"
              popupStyle={{
                padding: '2px 8px',
              }}
            >
              <svg
                className="-mr-1"
                width="16"
                height="16"
                viewBox="0 0 16 16"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <circle
                  cx="8"
                  cy="8"
                  r="6.33333"
                  stroke="#F04354"
                  strokeWidth="1.33333"
                />
                <path
                  d="M7.71094 7.0127C7.43495 7.0127 7.21119 7.23677 7.21094 7.5127V11.25C7.21094 11.5261 7.4348 11.75 7.71094 11.75H8.29004C8.56611 11.7499 8.79004 11.5261 8.79004 11.25V7.5127C8.78979 7.23682 8.56596 7.01278 8.29004 7.0127H7.71094ZM7.71094 4.25C7.4348 4.25 7.21094 4.47386 7.21094 4.75V5.3291C7.21102 5.60517 7.43485 5.8291 7.71094 5.8291H8.29004C8.56606 5.82902 8.78996 5.60512 8.79004 5.3291V4.75C8.79004 4.47391 8.56611 4.25008 8.29004 4.25H7.71094Z"
                  fill="#F04354"
                />
              </svg>
            </Popover>
          }
        />
      </CodeBox>
      <CodeBlock>{`import { Input } from 'one-design-next'
      
<Input
  style={{
    '--odn-input-padding-block-large': '7.5px',
    '--odn-input-padding-inline-large': '12px',
    '--odn-input-font-size-large': '14px',
    '--odn-input-line-height-large': '1.57142857',
    '--odn-input-border-radius-large': '8px',
    '--odn-input-icon-size-large': '16px',
    '--odn-input-icon-margin-inline-large': '8px',

    '--odn-input-padding-block-medium': '3.5px',
    '--odn-input-padding-inline-medium': '12px',
    '--odn-input-font-size-medium': '14px',
    '--odn-input-line-height-medium': '1.57142857',
    '--odn-input-border-radius-medium': '8px',
    '--odn-input-icon-size-medium': '16px',
    '--odn-input-icon-margin-inline-medium': '8px',

    '--odn-input-bg-normal': '#0A0A0A0D',
    '--odn-input-bg-normal-hover': '#0A0A0A14',
    '--odn-input-bg-normal-focus': '#fff',

    '--odn-input-color-normal': '#000000F5',
    '--odn-input-color-normal-hover': '#000000F5',
    '--odn-input-color-normal-focus': '#000000F5',

    '--odn-input-border-width': '1.5px',

    '--odn-input-border-normal': 'transparent',
    '--odn-input-border-normal-hover': 'transparent',
    '--odn-input-border-normal-focus': '#0A0A0AD6',

    '--odn-input-shadow-normal-focus': 'none',

    '--odn-input-border-danger': '#F04354',
    '--odn-input-border-danger-hover': '#F04354',
    '--odn-input-border-danger-focus': '#F04354',
    '--odn-input-shadow-danger-focus': 'none'
  }}
/>      
`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## API {#api}

### Input

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| size | 尺寸 | `'small' \| 'medium' \| 'large'` | `'medium'` |
| intent | 状态样式 | `'normal' \| 'danger'` | `'normal'` |
| light | 轻量样式 | `boolean` | - |
| leftElement | 左侧插槽 | `React.ReactNode` | - |
| rightElement | 右侧插槽 | `React.ReactNode` | - |
| allowClear | 是否显示清空 | `boolean` | - |
| clearIconName | 清空图标名 | `string` | `'cancel-circle-filled'` |
| clearIcon | 自定义清空图标 | `React.ReactNode` | - |
| count | 字数统计（见类型 `InputCount`） | `InputCount` | - |
| onChange | 值变化 | `(e, value: string) => void` | - |
| onPressEnter | 回车 | `(e, value: string) => void` | - |
| onFocus / onBlur | 聚焦 / 失焦 | `React` 焦点事件 | - |

继承 `Omit<React.ComponentProps<'input'>, 'size' \| 'onChange'>`。`ref` 指向包裹层，可访问 `focus` / `blur` / `input`。

### Input.Textarea

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| size / intent / light | 同 Input | 同左 | - |
| allowClear / clearIcon / count | 同 Input（count 为 `TextareaCount`） | 同左 | - |
| autoSize | 自动高度 | `boolean \| { minRows?, maxRows? }` | `false` |
| topElement | 上方插槽 | `React.ReactNode` | - |
| bottomElement | 下方插槽 | `React.ReactNode` | - |
| onChange | 值变化 | `(e, value: string) => void` | - |
| onPressEnter | 回车 | `(e, value: string) => void` | - |

继承 `Omit<React.ComponentProps<'textarea'>, 'size' \| 'onChange'>`。`ref` 可访问 `textarea`。

## 变量 {#variables}

<VariablesTable id="Input"></VariablesTable>

---

## 单选 Radio

## 基础用例 {#basic-usage}

通过 `vertical` 属性可以设置单选框组的方向：

**示例：基础用例** — 基础用例

```tsx
'use client';

import { Radio } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

const Basic = () => {
  const [value, setValue] = useState('default');
  const [params, setParams] = useState({
    size: 'medium',
    vertical: false,
    helper: true,
    helperIcon: false,
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'size', {
      options: {
        small: 'small',
        medium: 'medium',
        large: 'large',
      },
    });

    pane.addBinding(params, 'vertical');

    pane.addBinding(params, 'helper', {
      type: 'boolean',
    });

    pane.addBinding(params, 'helperIcon', {
      type: 'boolean',
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <Radio.Group
          onChange={(value) => setValue(value)}
          value={value}
          size={params.size as 'small' | 'medium' | 'large'}
          vertical={params.vertical}
          helperIcon={params.helperIcon ? 'help-circle' : undefined}
          options={[
            {
              label: 'Default',
              value: 'default',
              disabled: true,
              helper: params.helper ? 'This is a helper text' : undefined,
            },
            {
              label: 'Comfortable',
              value: 'comfortable',
              helper: params.helper ? 'This is a helper text' : undefined,
            },
            {
              label: 'Compact',
              value: 'compact',
              helper: params.helper ? 'This is a helper text' : undefined,
            },
          ]}
        />
      </CodeBox>
      <CodeBlock>{`import { Radio } from 'one-design-next';

// value: ${value}
<Radio.Group
  onChange={(value) => setValue(value)}
  value={value}
  size="${params.size}"
  vertical={${params.vertical}}
  helperIcon=${params.helperIcon ? "'help-circle'" : 'undefined'}
  options={[
    {
      label: 'Default',
      value: 'default',
      disabled: true,
      helper: ${params.helper ? "'This is a helper text'" : 'undefined'},
    },
    {
      label: 'Comfortable',
      value: 'comfortable',
      helper: ${params.helper ? "'This is a helper text'" : 'undefined'},
    },
    {
      label: 'Compact',
      value: 'compact',
      helper: ${params.helper ? "'This is a helper text'" : 'undefined'},
    },
  ]}
/>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 业务定制 {#business-customization}

**示例：业务定制** — 业务定制

```tsx
'use client';

import { Radio } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basic = () => {
  const [value, setValue] = useState('default');

  return (
    <div>
      <CodeBox
        style={{
          '--odn-radio-indicator-size-medium': '8px',
          '--odn-radio-indicator-bg': '#0A0A0AD6',
          '--odn-radio-indicator-scale-initial': '0',
          '--odn-radio-color': '#0A0A0A99',
          '--odn-radio-input-bg': '#fff',
          '--odn-radio-input-border': '1px solid #0A0A0A1F',
          '--odn-radio-input-bg-checked': '#fff',
          '--odn-radio-input-border-checked': '1px solid #0A0A0AD6',
          '--odn-radio-input-bg-checked-hover': '#fff',
          '--odn-radio-input-border-checked-hover': '1px solid #0A0A0AD6',
          '--odn-radio-input-bg-checked-focus': '#fff',
          '--odn-radio-input-border-checked-focus': '1px solid #0A0A0AD6',
        }}
      >
        <Radio.Group
          onChange={(value) => setValue(value)}
          value={value}
          options={[
            {
              label: 'Default',
              value: 'default',
            },
            {
              label: 'Comfortable',
              value: 'comfortable',
            },
            {
              label: 'Compact',
              value: 'compact',
            },
          ]}
        />
      </CodeBox>
      <CodeBlock>{`import { Radio } from 'one-design-next';

// value: ${value}
<Radio.Group
  onChange={(value) => setValue(value)}
  value={value}
  options={[
    {
      label: 'Default',
      value: 'default',
    },
    {
      label: 'Comfortable',
      value: 'comfortable',
    },
    {
      label: 'Compact',
      value: 'compact',
      disabled: true,
    },
  ]}
/>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## API {#api}

### Radio.Group

实际使用的是 `Radio.Group`（`Radio` 单组件占位，请使用 Group）。

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| vertical | 是否纵向排列 | `boolean` | - |
| options | 选项列表 | `{ label?, value, disabled?, helper?, helperProps? }[]` | - |
| value | 当前值 | `T` | - |
| onChange | 变化回调 | `(value: T) => void` | - |
| size | 尺寸 | `'small' \| 'medium' \| 'large'` | `'medium'` |
| helperIcon | 选项中 helper 的问号图标 | `iconNames[number]` | - |

继承 `Omit<React.HTMLAttributes<HTMLDivElement>, 'onChange' \| 'defaultValue' \| 'dir'>`。

## 变量 {#variables}

<VariablesTable id="Radio"></VariablesTable>

---

## 选择器 Select

## 基础用例 {#basic-usage}

`allowClear`、`disabled`、`loading` Prop 的演示：

**示例：基础用例** — 基础用例

```tsx
'use client';

import { Select } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

const Basic = () => {
  const [value, setValue] = useState<string | string[]>('小程序');
  const [params, setParams] = useState({
    size: 'middle' as 'small' | 'middle' | 'large',
    light: false,
    disabled: false,
    allowClear: true,
    showInnerSearch: false,
    multiple: false,
    placeholder: '请选择',
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'size', {
      options: {
        small: 'small',
        middle: 'middle',
        large: 'large',
      },
    });

    pane.addBinding(params, 'light', {
      type: 'boolean',
    });

    pane.addBinding(params, 'disabled', {
      type: 'boolean',
    });

    pane.addBinding(params, 'allowClear', {
      type: 'boolean',
    });

    pane.addBinding(params, 'showInnerSearch', {
      type: 'boolean',
    });

    pane.addBinding(params, 'multiple', {
      type: 'boolean',
    });

    pane.addBinding(params, 'placeholder', {
      type: 'string',
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  const options = [
    { popover: '1', value: '朋友圈', label: '朋友圈' },
    { popover: '1', value: '视频号', label: '视频号' },
    { popover: '1', value: '订阅号', label: '订阅号' },
    { popover: '1', value: '小程序', label: '小程序', disabled: true },
  ];

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <div className="flex items-center">
          <Select
            size={params.size}
            light={params.light}
            disabled={params.disabled}
            allowClear={params.allowClear}
            showInnerSearch={params.showInnerSearch}
            mode={params.multiple ? 'multiple' : undefined}
            placeholder={params.placeholder}
            value={
              params.multiple ? (Array.isArray(value) ? value : [value]) : value
            }
            className="w-80"
            options={options}
            onChange={(newValue) => {
              if (params.multiple) {
                setValue(Array.isArray(newValue) ? newValue : []);
              } else {
                setValue(String(newValue || ''));
              }
            }}
          />
        </div>
      </CodeBox>
      <CodeBlock>{`import { Select } from 'one-design-next';

const [value, setValue] = useState<string | string[]>('小程序');

<Select
  size="${params.size}"
  light={${params.light}}
  disabled={${params.disabled}}
  allowClear={${params.allowClear}}
  showInnerSearch={${params.showInnerSearch}}
  ${params.multiple ? 'mode="multiple"' : ''}
  placeholder="${params.placeholder}"
  value={${params.multiple ? '(Array.isArray(value) ? value : [value])' : 'value'}}
  className="w-80"
  options={[
    { value: '朋友圈', label: '朋友圈' },
    { value: '视频号', label: '视频号' },
    { value: '订阅号', label: '订阅号' },
    { value: '小程序', label: '小程序', disabled: true },
  ]}
  onChange={(newValue) => {
    if (${params.multiple}) {
      setValue(Array.isArray(newValue) ? newValue : []);
    } else {
      setValue(String(newValue || ''));
    }
  }}
/>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 带搜索框 {#with-search}

开启 `showInnerSearch` 后将显示下拉框中的搜索框，默认对 `label` 进行筛选。可通过 `onSearch` 实现远程搜索。`autoClearSearchValue` 默认为 `true`，搜索框的值会自动清空。

如果需要自定义筛选的逻辑，可参考下面的自定义搜索筛选用例。

**示例：带搜索框** — 带搜索框

```tsx
'use client';

import { Select } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
import { Pane } from 'tweakpane';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basic = () => {
  const [value, setValue] = useState('朋友圈');
  const [params, setParams] = useState({
    autoClearSearchValue: true,
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'autoClearSearchValue', {
      type: 'boolean',
      label: '自动清空搜索值',
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <Select
          allowClear
          showInnerSearch
          autoClearSearchValue={params.autoClearSearchValue}
          style={{ width: 120 }}
          options={[
            { value: '朋友圈', label: '朋友圈' },
            { value: '视频号', label: '视频号' },
            { value: '订阅号', label: '订阅号' },
            { value: '小程序', label: '小程序' },
          ]}
          value={value}
          onChange={(value) => {
            setValue(value);
          }}
          onSearch={(value) => {
            console.log('onSearch:', value);
          }}
        />
      </CodeBox>
      <CodeBlock>{`import { Select } from 'one-design-next';
      
<Select 
  showInnerSearch 
  autoClearSearchValue={${params.autoClearSearchValue}}
/>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 自定义搜索筛选 {#custom-search}

通过 `filterOption` 可以自定义搜索筛选逻辑，根据搜索框的值对每一个 option 做判断，返回 `true` 则显示，返回 `false` 则隐藏：

**示例：自定义搜索筛选** — 自定义搜索筛选

```tsx
'use client';

import { Select } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basic = () => {
  const [value, setValue] = useState('朋友圈');

  return (
    <div>
      <CodeBox className="gap-2 flex-wrap">
        <Select
          allowClear
          showInnerSearch
          className="w-[120px]"
          filterOption={(input, option) => {
            return true;
          }}
          options={[
            { value: '朋友圈', label: '朋友圈' },
            { value: '视频号', label: '视频号' },
            { value: '订阅号', label: '订阅号' },
            { value: '小程序', label: '小程序' },
          ]}
          value={value}
          onChange={(value) => {
            setValue(value);
          }}
        />
      </CodeBox>
      <CodeBlock>{`import { Select } from 'one-design-next';
      
<Select
  showInnerSearch
  filterOption={(input, option) => {
    // 根据 input 对 每一个 option 做判断
    return true;
  }}
/>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 自定义下拉选项与结果展示 {#custom-option-render}

使用 `optionRender` 自定义下拉框中每一项的渲染；使用 `labelRender` 自定义选择后的结果展示：

**示例：自定义下拉选项** — 自定义下拉选项

```tsx
'use client';

import { Select } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basic = () => {
  const [value, setValue] = useState('小程序');

  return (
    <div>
      <CodeBox className="gap-2 flex-wrap">
        <Select
          allowClear
          placeholder="请选择"
          value={value}
          className="w-[200px]"
          options={[
            { value: '朋友圈', label: '朋友圈' },
            { value: '视频号', label: '视频号' },
            { value: '订阅号', label: '订阅号' },
            { value: '小程序', label: '小程序' },
          ]}
          dropdownStyle={{
            width: '300px',
          }}
          optionRender={(option, info) => {
            return (
              <div className="flex h-10 items-center">
                自定义渲染 {info.index}：{option.label}
              </div>
            );
          }}
          labelRender={(option) => {
            return <div>自定义结果展示：{option.label}</div>;
          }}
          onChange={(value, option) => {
            setValue(value);
          }}
        />
      </CodeBox>
      <CodeBlock>{`import { Select } from 'one-design-next';

const [value, setValue] = useState('小程序');

<Select
  optionRender={(option, info) => {
    return (
      <div className="flex h-10 items-center">
        自定义渲染 {info.index}：{option.label}
      </div>
    );
  }}
  labelRender={(option) => {
    return <div>自定义结果展示：{option.label}</div>;
  }}
/>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 自定义下拉框 {#custom-popup}

通过 `popupRender` 可以自定义下拉框的渲染，在上方或下方添加元素；或通过使用 `Select.Button` 结合自定义的 `Popover` 来实现完全自定义的下拉框：

**示例：自定义下拉框** — 自定义下拉框

```tsx
'use client';

import { Popover, Select, Table } from 'one-design-next';
import React, { useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basic = () => {
  const [value, setValue] = useState('朋友圈');
  const [visible, setVisible] = useState(false);
  const [sliderValue, setSliderValue] = useState(2.5);

  // 表格数据
  const tableData = [
    {
      key: '1',
      name: '张三',
      age: 28,
      department: '技术部技术部技术部技术部技术部技术部',
      status: '在职',
    },
    { key: '2', name: '李四', age: 32, department: '产品部', status: '在职' },
    { key: '3', name: '王五', age: 25, department: '设计部', status: '离职' },
    { key: '4', name: '赵六', age: 30, department: '运营部', status: '在职' },
    { key: '5', name: '钱七', age: 27, department: '技术部', status: '在职' },
  ];

  const tableColumns = [
    { title: '姓名', dataIndex: 'name', key: 'name', width: 100 },
    { title: '年龄', dataIndex: 'age', key: 'age', width: 80 },
    {
      title: '部门',
      dataIndex: 'department',
      key: 'department',
      width: 120,
      ellipsis: true,
    },
    { title: '状态', dataIndex: 'status', key: 'status', width: 80 },
  ];

  const divRef = useRef<HTMLDivElement>(null);

  return (
    <div>
      <CodeBox className="gap-2 flex-col flex-wrap">
        <div className="flex flex-col gap-2">
          <span className="text-xs text-neutral-500">popupRender: </span>
          <Select
            allowClear
            className="w-80"
            options={[
              { value: '朋友圈', label: '朋友圈' },
              { value: '视频号', label: '视频号' },
              { value: '订阅号', label: '订阅号' },
              { value: '小程序', label: '小程序' },
              { value: '朋友圈2', label: '朋友圈2' },
              { value: '视频号2', label: '视频号2' },
              { value: '订阅号2', label: '订阅号2' },
              { value: '小程序2', label: '小程序2' },
            ]}
            popupRender={(node) => (
              <>
                <div className="p-2">
                  <Table dataSource={tableData} columns={tableColumns} />
                </div>
              </>
            )}
          />
          <span className="text-xs text-neutral-500">
            Popover click + Select.Button
          </span>
          <Popover
            trigger="click"
            popup={
              <>
                <div className="p-2">
                  <Table dataSource={tableData} columns={tableColumns} />
                </div>
              </>
            }
            matchWidth
            placement="bottomLeft"
            arrowed={false}
            visible={visible}
            popupStyle={{ padding: 0 }}
            onVisibleChange={setVisible}
          >
            <Select.Button
              active={visible}
              className="w-80"
              value={`${sliderValue}km`}
              prefix={
                <div
                  style={{
                    color: 'var(--odn-color-black-9)',
                  }}
                >
                  半径
                </div>
              }
            />
          </Popover>
          <span className="text-xs text-neutral-500">
            Popover hover + Select.Button
          </span>
          <Popover
            popup={
              <div className="p-2">
                <Table dataSource={tableData} columns={tableColumns} />
              </div>
            }
            matchWidth
            placement="bottomLeft"
            arrowed={false}
            popupStyle={{ padding: 0 }}
          >
            <Select.Button
              allowClear
              className="w-80"
              value="Takuya"
              prefix={
                <div
                  style={{
                    color: 'var(--odn-color-black-9)',
                  }}
                >
                  员工
                </div>
              }
            />
          </Popover>
        </div>
      </CodeBox>
      <CodeBlock>{`import { Select, Popover, Slider, Table } from 'one-design-next';

// 基础用法：popupRender 在 Select 中添加额外内容
<Select
  allowClear
  className="w-80"
  options={[
    { value: '朋友圈', label: '朋友圈' },
    { value: '视频号', label: '视频号' },
    { value: '订阅号', label: '订阅号' },
    { value: '小程序', label: '小程序' },
  ]}
  popupRender={(node) => (
    <>
      <div className="px-3 border-b border-neutral-300">上方内容</div>
      {node}
      <div className="px-3 border-t border-neutral-300">下方内容</div>
    </>
  )}
/>

// Popover click + Select.Button：点击触发
<Popover
  trigger="click"
  popup={
    <div className="p-4">
      <Slider
        min={0.5}
        max={20}
        step={0.5}
        tooltipVisible={false}
        inputVisible
        value={sliderValue}
        onChange={setSliderValue}
      />
    </div>
  }
  matchWidth
  placement="bottomLeft"
  arrowed={false}
  visible={visible}
  popupStyle={{ padding: 0 }}
  onVisibleChange={setVisible}
>
  <Select.Button
    active={visible}
    className="w-80"
    value={\`\${sliderValue}km\`}
    prefix={
      <div style={{ color: 'var(--odn-color-black-9)' }}>
        半径
      </div>
    }
  />
</Popover>

// Popover hover + Select.Button：悬停触发
<Popover
  popup={
    <div className="p-2">
      <Table dataSource={tableData} columns={tableColumns} />
    </div>
  }
  matchWidth
  placement="bottomLeft"
  arrowed={false}
  popupStyle={{ padding: 0 }}
>
  <Select.Button
    allowClear
    className="w-80"
    value="Takuya"
    prefix={
      <div style={{ color: 'var(--odn-color-black-9)' }}>
        员工
      </div>
    }
  />
</Popover>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 标签多选 {#multiple-selection}

使用 `mode="multiple"` 开启多选模式，支持多种变体，结果默认展示为多个标签：

**示例：标签选择** — 标签选择

```tsx
'use client';

import { Select, SelectProps } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basic = () => {
  const options: SelectProps['options'] = [];

  for (let i = 10; i < 36; i++) {
    options.push({
      label: i.toString(36) + i,
      value: i.toString(36) + i,
    });
  }

  const [value, setValue] = useState<string[]>(['a10', 'c12']);

  const handleChange = (value: string[]) => {
    console.log(`selected ${value}`);
    setValue(value);
  };

  return (
    <div>
      <CodeBox className="gap-2 flex-col items-start">
        {/* <div className="text-xs text-neutral-500">外层输入框搜索</div>
        <Select
          mode="multiple"
          allowClear
          style={{ width: '100%' }}
          defaultValue={['a10', 'c12']}
          onChange={handleChange}
          options={options}
        /> */}
        <div className="text-xs text-neutral-500">按钮</div>
        <Select
          mode="multiple"
          showSearch={false}
          allowClear
          style={{ width: '100%' }}
          value={value}
          onChange={handleChange}
          options={options}
        />
        <div className="text-xs text-neutral-500">弹出层搜索</div>
        <Select
          mode="multiple"
          showSearch={false}
          showInnerSearch
          allowClear
          style={{ width: '100%' }}
          value={value}
          onChange={handleChange}
          options={options}
        />
        <div className="text-xs text-neutral-500">限制个数</div>
        <Select
          mode="multiple"
          showSearch={false}
          showInnerSearch
          maxCount={3}
          allowClear
          style={{ width: '100%' }}
          value={value}
          onChange={handleChange}
          options={options}
        />
        <div className="text-xs text-neutral-500">禁用</div>
        <Select
          mode="multiple"
          disabled
          style={{ width: '100%' }}
          value={value}
          onChange={handleChange}
          options={options}
        />
      </CodeBox>
      <CodeBlock>{`import { Select } from 'one-design-next';

<Select
  mode="multiple"
  // 允许清除
  allowClear
  // 开启外层输入框
  showSearch
  // 开启内层搜索
  showInnerSearch
  // 限制个数
  maxCount={3}
/>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 前缀与后缀 {#prefix-suffix}

通过 `prefix` 和 `suffixIcon` 可以添加前缀和后缀图标：

**示例：前缀与后缀** — 前缀与后缀

```tsx
'use client';

import { Icon, Select } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basic = () => {
  const [value, setValue] = useState('朋友圈');

  return (
    <div>
      <CodeBox className="gap-2 flex-wrap">
        <Select
          allowClear
          options={[
            { value: '朋友圈', label: '朋友圈' },
            { value: '视频号', label: '视频号' },
            { value: '订阅号', label: '订阅号' },
            { value: '小程序', label: '小程序' },
          ]}
          value={value}
          onChange={(value) => {
            setValue(value);
          }}
          prefix={
            <div style={{ color: 'var(--odn-color-text-placeholder)' }}>
              广告场景
            </div>
          }
          suffixIcon={<Icon name="arrowRight" />}
        />
      </CodeBox>
      <CodeBlock>{`import { Select } from 'one-design-next';
      
<Select
  prefix={<div style={{ color: 'var(--odn-color-text-placeholder)' }}>广告场景</div>}
  suffixIcon={<Icon name="arrowRight" />}
/>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 自定义多选结果 {#custom-multiple-result}

可分别通过使用 `labelRender`、`tagRender` 自定义每一个 tag 的展示。前者只对标签文本进行自定义，后者可以对整个 tag 进行自定义。

还可通过 `maxTagCount={0}` 结合 `tagRender` 的方式实现对整个多选结果的自定义。可参考下面的几个例子选用不同程度的自定义：

**示例：自定义多选结果** — 自定义多选结果

```tsx
'use client';

import { Select, SelectProps } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basic = () => {
  const options: SelectProps['options'] = [];

  for (let i = 10; i < 36; i++) {
    options.push({
      label: i.toString(36) + i,
      value: i.toString(36) + i,
    });
  }

  const [value, setValue] = useState<string[]>(['a10', 'c12']);

  const handleChange = (value: string[]) => {
    setValue(value);
  };
  return (
    <div>
      <CodeBox className="gap-2 flex-col items-start">
        <div className="text-xs text-neutral-500">labelRender</div>
        <Select
          mode="multiple"
          allowClear
          style={{ width: '100%' }}
          value={value}
          onChange={handleChange}
          options={options}
          placeholder="对比品牌筛选"
          labelRender={(props) => {
            return <div>labelRender: {props.label}</div>;
          }}
        />
        <div className="text-xs text-neutral-500">
          tagRender（如果自定义 tagRender 注意同时增加上下外边距 ）
        </div>
        <Select
          mode="multiple"
          allowClear
          style={{ width: '100%' }}
          value={value}
          onChange={handleChange}
          options={options}
          placeholder="对比品牌筛选"
          tagRender={(props) => {
            return (
              <div className="mr-2 my-0.5 bg-blue-100 rounded-md px-2">
                tagRender: {props.label}
              </div>
            );
          }}
        />
        <div className="text-xs text-neutral-500">maxTagCount</div>
        <Select
          mode="multiple"
          allowClear
          style={{ width: '100%' }}
          value={value}
          onChange={handleChange}
          options={options}
          placeholder="对比品牌筛选"
          tagRender={(props) => {
            return (
              <div className="flex items-center gap-1">
                <div>对比品牌筛选</div>
                {value.length > 0 && (
                  <div className="flex items-center justify-center size-2 font-semibold text-white text-xs bg-blue-600 rounded-full w-5 h-5">
                    {value.length}
                  </div>
                )}
              </div>
            );
          }}
          maxTagCount={0}
        />
        <div className="text-xs text-neutral-500">maxTagCount</div>
        <Select
          mode="multiple"
          allowClear
          style={{ width: '250px' }}
          value={value}
          onChange={handleChange}
          options={options}
          placeholder="对比品牌筛选"
          showSearch={false}
          tagRender={(props) => {
            return (
              <div className="flex items-center gap-1">
                <div className="flex-none">逗号隔开，单行省略: </div>
                {value.length > 0 && (
                  <div className="whitespace-nowrap overflow-hidden text-ellipsis min-w-0">
                    {value.join(', ')}
                  </div>
                )}
              </div>
            );
          }}
          maxTagCount={0}
        />
      </CodeBox>
      <CodeBlock>{`import { Select } from 'one-design-next';

// labelRender
<Select
  mode="multiple"
  labelRender={(props) => <div>labelRender: {props.label}</div>}
/>

// tagRender
<Select
  mode="multiple"
  tagRender={(props) => <div className="mr-2 bg-blue-100 rounded-md px-2">tagRender: {props.label}</div>}
/>

// maxTagCount
<Select
  mode="multiple"
  maxTagCount={0}
  tagRender={(props) => (
    <div className="flex items-center gap-1">
      <div>对比品牌筛选</div>
      {value.length > 0 && (
        <div className="flex items-center justify-center size-2 font-semibold text-white text-xs bg-blue-600 rounded-full">
          {value.length}
        </div>
      )}
    </div>
  )}
/>

// 逗号隔开，单行省略
<Select
  tagRender={(props) => {
    return (
      <div className="flex items-center gap-1">
        <div className="flex-none">逗号隔开，单行省略: </div>
        {value.length > 0 && (
          <div className="whitespace-nowrap overflow-hidden text-ellipsis min-w-0">
            {value.join(', ')}
          </div>
        )}
      </div>
    );
  }}
  maxTagCount={0}
/>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 分组 {#grouping}

给 `options` 每项增加 `options`，可以实现分组。可设置 `label` 与 `title` 展示分组标题，如果不设置则只会展示一条分割线：

**示例：分组** — 分组

```tsx
'use client';

import { Select } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
import { Pane } from 'tweakpane';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basic = () => {
  const [value, setValue] = useState('-1');
  const [params, setParams] = useState({
    groupTitle: false,
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'groupTitle', {
      type: 'boolean',
      label: '分组标题',
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  // 根据 groupTitle 参数动态生成 options
  const getOptions = () => {
    const baseOptions = [
      {
        ...(params.groupTitle && { label: '过去', title: '过去' }),
        options: [
          { value: '-1', label: '1 天前1 天前1 天前' },
          { value: '-3', label: '3 天前3 天前3 天前' },
          { value: '-7', label: '7 天前7 天前7 天前' },
        ],
      },
      {
        ...(params.groupTitle && { label: '未来', title: '未来' }),
        options: [
          { value: '1', label: '1 天后' },
          { value: '3', label: '3 天后', disabled: true },
          { value: '7', label: '7 天后', disabled: true },
        ],
      },
    ];
    return baseOptions;
  };

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <div className="flex flex-col gap-4">
          <Select
            prefix={
              <div style={{ color: 'var(--odn-color-text-placeholder)' }}>
                本品牌/本品牌系列
              </div>
            }
            className="w-[320px]"
            allowClear={false}
            optionRender={(option: IBaseObject) => {
              return (
                <div className="flex items-center gap-2">
                  {option.label}
                  {option.data.configured && (
                    <span className="text-xs text-[var(--odn-color-black-9)]">
                      已配置
                    </span>
                  )}
                </div>
              );
            }}
            options={[
              {
                options: [{ value: '-1', label: '小米汽车', configured: true }],
              },
              {
                options: [
                  {
                    value: '0',
                    label: '小米汽车/增程 SUV',
                    disabled: true,
                    popover: (
                      <div>
                        <div>最近配置时间：2025-11-20</div>
                        <div>下次可配置时间：2025-12-20</div>
                      </div>
                    ),
                    configured: true,
                  },
                  {
                    value: '1',
                    label: '小米汽车/YU7',
                    configured: false,
                  },
                  {
                    value: '2',
                    label: '小米汽车/SU7 Ultra',
                    configured: false,
                  },
                  {
                    value: '3',
                    label: '小米汽车/SU7',
                    configured: false,
                  },
                ],
              },
            ]}
            value="小米汽车"
            onChange={(value) => {
              setValue(value);
            }}
          />
          <Select
            className="w-[320px]"
            allowClear={false}
            options={getOptions()}
            value={value}
            onChange={(value) => {
              setValue(value);
            }}
            showInnerSearch
            dropdownMatchSelectWidth={false}
          />
        </div>
      </CodeBox>
      <CodeBlock>{`import { Select } from 'one-design-next';

<Select
  prefix={
    <div style={{ color: 'var(--odn-color-text-placeholder)' }}>
      本品牌/本品牌系列
    </div>
  }
  className="w-[320px]"
  allowClear={false}
  optionRender={(option: IBaseObject) => {
    return (
      <div className="flex items-center gap-2">
        {option.label}
        {option.data.configured && (
          <span className="text-xs text-[var(--odn-color-black-9)]">
            已配置
          </span>
        )}
      </div>
    );
  }}
  options={[
    {
      options: [{ value: '-1', label: '小米汽车', configured: true }],
    },
    {
      options: [
        {
          value: '0',
          label: '小米汽车/增程 SUV',
          disabled: true,
          popover: (
            <div>
              <div>最近配置时间：2025-11-20</div>
              <div>下次可配置时间：2025-12-20</div>
            </div>
          ),
          configured: true,
        },
        {
          value: '1',
          label: '小米汽车/YU7',
          configured: false,
        },
        {
          value: '2',
          label: '小米汽车/SU7 Ultra',
          configured: false,
        },
        {
          value: '3',
          label: '小米汽车/SU7',
          configured: false,
        },
      ],
    },
  ]}
  value="小米汽车"
  onChange={(value) => {
    setValue(value);
  }}
/>

<Select
  className="w-[120px]"
  allowClear={false}
  options={[
    {${
      params.groupTitle
        ? `
      label: '过去',
      title: '过去',`
        : ''
    }
      options: [
        { value: '-1', label: '1 天前' },
        { value: '-3', label: '3 天前' },
        { value: '-7', label: '7 天前' },
      ],
    },
    {${
      params.groupTitle
        ? `
      label: '未来',
      title: '未来',`
        : ''
    }
      options: [
        { value: '1', label: '1 天后' },
        { value: '3', label: '3 天后', disabled: true },
        { value: '7', label: '7 天后', disabled: true },
      ],
    },
  ]}
  value={value}
  onChange={(value) => {
    setValue(value);
  }}
/>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 虚拟滚动演示 {#virtual-scroll}

**示例：虚拟滚动** — 虚拟滚动

```tsx
'use client';

import { Select, SelectProps } from 'one-design-next';
import React from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basic = () => {
  const options: SelectProps['options'] = [];

  for (let i = 0; i < 100000; i++) {
    const value = `${i.toString(36)}${i}`;
    options.push({
      label: value,
      value,
      disabled: i === 10,
    });
  }

  const handleChange = (value: string[]) => {
    console.log(`selected ${value}`);
  };

  return (
    <div>
      <CodeBox className="gap-2 flex-wrap">
        <Select
          mode="multiple"
          style={{ width: '100%' }}
          placeholder="Please select"
          defaultValue={['a10', 'c12']}
          onChange={handleChange}
          options={options}
        />
      </CodeBox>
      <CodeBlock>{`import { Select } from 'one-design-next';`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## API {#api}

### Select

基于 `rc-select@14`，见 `SelectProps`（在 `InternalSelectProps` 上扩展）。

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| mode | 多选 / 标签 | `'multiple' \| 'tags'` | - |
| placement | 弹出方位 | `'bottomLeft' \| 'bottomRight' \| 'topLeft' \| 'topRight'` | - |
| status | 校验状态 | `'error' \| 'warning'` | - |
| popupClassName | 下拉类名 | `string` | - |
| popupMatchSelectWidth | 下拉与选择器同宽 | `boolean \| number` | - |
| popupRender | 自定义下拉 | `(menu: ReactElement) => ReactElement` | - |
| visible / onVisibleChange | 显隐 | 同 rc `open` | - |
| light | 轻量样式 | `boolean` | - |
| optionCheckPosition | 多选勾选位置 | `'left' \| 'right'` | - |
| showInnerSearch | 下拉内搜索 | `boolean` | `false` |
| optionRender | 选项渲染 | `RcSelectProps['optionRender']` | - |
| prefix / suffixIcon | 前后缀 | `React.ReactNode` | - |
| size | 尺寸 | `'small' \| 'middle' \| 'large'` | `'middle'` |
| styles / classNames | 语义化样式槽 | 见类型 | - |

另继承 `Omit<RcSelectProps, 'mode' | 'getInputElement' | ...>` 的常用项：`options`、`value`、`onChange`、`showSearch`、`filterOption`、`labelRender`、`tagRender`、`maxTagCount`、`maxCount` 等。

### Select.Button

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| showArrow | 是否显示箭头 | `boolean` | `true` |
| size | 尺寸 | `'small' \| 'middle' \| 'large'` | `'middle'` |
| disabled | 是否禁用 | `boolean` | `false` |
| prefix | 前缀 | `React.ReactNode` | - |
| placeholder | 占位 | `string` | `'请选择'` |
| value | 当前值 | `string \| number` | - |
| active | 是否展开态 | `boolean` | `false` |
| allowClear | 是否可清空 | `boolean` | `false` |
| onClick / onClear | 点击 / 清空 | `() => void` | - |
| className / style | 样式 | `string` / `CSSProperties` | - |

## 变量 {#variables}

<VariablesTable id="Select"></VariablesTable>

---

## 滑动条 Slider

## 基础用例 {#basic-usage}

使用 `marks` 展示标记：

**示例：基础用例** — 基础用例

```tsx
'use client';

import { Slider } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basics = () => {
  const [value, setValue] = useState<number | undefined>(50);

  return (
    <div>
      <CodeBox>
        <Slider
          className="flex-1"
          value={value}
          onChange={setValue}
          marks={{
            0: '0°C',
            26: '26°C',
            37: '37°C',
            100: {
              style: {
                color: '#f50',
              },
              label: <strong>100°C</strong>,
            },
          }}
        />
      </CodeBox>
      <CodeBlock>{`import { Slider } from "one-design-next";

const [value, setValue] = useState<number | undefined>(50);
<Slider
  value={value}
  onChange={setValue}
  marks={{
    0: '0°C',
    26: '26°C',
    37: '37°C',
    100: {
      style: {
        color: '#f50',
      },
      label: <strong>100°C</strong>,
    },
  }}
/>`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## 数字输入框 {#number-input}

开启 `inputVisible` Prop 以展示数字输入框 `InputNumber`，注意仅在 `range` 为 `false` 时生效，可通过 `inputProps` 透传 `InputNumber` 的 `props`。

**示例：数字输入框** — 数字输入框

```tsx
'use client';

import { Slider } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basics = () => {
  const [value, setValue] = useState<number | undefined>(1);

  return (
    <div>
      <CodeBox>
        <Slider
          className="flex-1"
          value={value}
          onChange={setValue}
          step={0.5}
          min={0.5}
          max={100}
          inputVisible
        />
      </CodeBox>
      <CodeBlock>{`import { Slider } from "one-design-next";

const [value, setValue] = useState<number | undefined>(50);
<Slider
  value={value}
  onChange={setValue}
  step={0.5}
  min={0.5}
  max={100}
  inputVisible
/>`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## 范围选择 {#range-selection}

使用 `range` 属性来开启范围选择。

当两个 `Tooltip` 彼此重叠时，会自动合并为一个 `Tooltip`：

**示例：范围选择** — 范围选择

```tsx
'use client';

import { Slider } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';

const Basics = () => {
  const [value, setValue] = useState<[number, number]>([22, 26]);

  return (
    <div>
      <CodeBox>
        <Slider
          tooltipVisible
          range
          unit="岁"
          className="flex-1"
          value={value}
          onChange={setValue}
          min={18}
          max={100}
        />
      </CodeBox>
      <CodeBlock>{`import { Slider } from "one-design-next";

const [value, setValue] = useState<[number, number]>([22, 26]);

<Slider
  range
  unit="岁"
  className="flex-1"
  value={value}
  onChange={setValue}
  min={18}
  max={100}
/>`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## 业务定制 {#style-customization}

通过 CSS Variables 定制样式，完整见页面底部的变量表格。

**示例：样式定制** — 样式定制

```tsx
'use client';

import { Slider } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
import { Pane } from 'tweakpane';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Customize = () => {
  const [trackHeight, setTrackHeight] = useState(12);
  const [borderRadius, setBorderRadius] = useState(4);
  const [handleWidth, setHandleWidth] = useState(8);
  const [handleHeight, setHandleHeight] = useState(14);
  const [handleBorderRadius, setHandleBorderRadius] = useState(4);
  const [tooltipPaddingBlock, setTooltipPaddingBlock] = useState(4);
  const [tooltipPaddingInline, setTooltipPaddingInline] = useState(8);
  const [tooltipFontSize, setTooltipFontSize] = useState(12);
  const [tooltipBorderRadius, setTooltipBorderRadius] = useState(6);
  const [value, setValue] = useState(30);
  const paneRef = useRef<HTMLDivElement>(null);
  const paneInstanceRef = useRef<Pane | null>(null);

  useEffect(() => {
    if (paneRef.current && !paneInstanceRef.current) {
      const pane = new Pane({
        container: paneRef.current,
        title: 'Slider Variables',
      });

      pane
        .addBinding({ trackHeight }, 'trackHeight', {
          min: 2,
          max: 12,
          step: 1,
          label: 'Track Height',
        })
        .on('change', (ev) => {
          setTrackHeight(ev.value);
        });

      pane
        .addBinding({ borderRadius }, 'borderRadius', {
          min: 0,
          max: 20,
          step: 1,
          label: 'Border Radius',
        })
        .on('change', (ev) => {
          setBorderRadius(ev.value);
        });

      pane
        .addBinding({ handleWidth }, 'handleWidth', {
          min: 8,
          max: 24,
          step: 1,
          label: 'Handle Width',
        })
        .on('change', (ev) => {
          setHandleWidth(ev.value);
        });

      pane
        .addBinding({ handleHeight }, 'handleHeight', {
          min: 8,
          max: 24,
          step: 1,
          label: 'Handle Height',
        })
        .on('change', (ev) => {
          setHandleHeight(ev.value);
        });

      pane
        .addBinding({ handleBorderRadius }, 'handleBorderRadius', {
          min: 0,
          max: 12,
          step: 1,
          label: 'Handle Radius',
        })
        .on('change', (ev) => {
          setHandleBorderRadius(ev.value);
        });

      pane
        .addBinding({ tooltipPaddingBlock }, 'tooltipPaddingBlock', {
          min: 4,
          max: 20,
          step: 1,
          label: 'Tooltip Padding V',
        })
        .on('change', (ev) => {
          setTooltipPaddingBlock(ev.value);
        });

      pane
        .addBinding({ tooltipPaddingInline }, 'tooltipPaddingInline', {
          min: 8,
          max: 24,
          step: 1,
          label: 'Tooltip Padding H',
        })
        .on('change', (ev) => {
          setTooltipPaddingInline(ev.value);
        });

      pane
        .addBinding({ tooltipFontSize }, 'tooltipFontSize', {
          min: 10,
          max: 18,
          step: 1,
          label: 'Tooltip Font Size',
        })
        .on('change', (ev) => {
          setTooltipFontSize(ev.value);
        });

      pane
        .addBinding({ tooltipBorderRadius }, 'tooltipBorderRadius', {
          min: 0,
          max: 12,
          step: 1,
          label: 'Tooltip Radius',
        })
        .on('change', (ev) => {
          setTooltipBorderRadius(ev.value);
        });

      paneInstanceRef.current = pane;
    }

    return () => {
      if (paneInstanceRef.current) {
        paneInstanceRef.current.dispose();
        paneInstanceRef.current = null;
      }
    };
  }, []);

  return (
    <div>
      <CodeBox
        className="flex flex-col pt-2 pr-2 pb-16 gap-16"
        style={{
          '--odn-slider-rail-background':
            'linear-gradient(to right, rgb(255, 0, 0) 0%, rgb(255, 255, 0) 17%, rgb(0, 255, 0) 33%, rgb(0, 255, 255) 50%, rgb(0, 0, 255) 67%, rgb(255, 0, 255) 83%, rgb(255, 0, 0) 100%)',
          '--odn-slider-track-height': `${trackHeight}px`,
          '--odn-slider-track-background': 'transparent',
          '--odn-slider-border-radius': `${borderRadius}px`,
          '--odn-slider-handle-width': `${handleWidth}px`,
          '--odn-slider-handle-height': `${handleHeight}px`,
          '--odn-slider-handle-border-radius': `${handleBorderRadius}px`,
          '--odn-slider-tooltip-padding-block': `${tooltipPaddingBlock}px`,
          '--odn-slider-tooltip-padding-inline': `${tooltipPaddingInline}px`,
          '--odn-slider-tooltip-font-size': `${tooltipFontSize}px`,
          '--odn-slider-tooltip-border-radius': `${tooltipBorderRadius}px`,
        }}
      >
        <div ref={paneRef} className="opacity-90 self-end" />

        <div className="w-[300px]">
          <Slider value={value} onChange={setValue} tooltipVisible={false} />
        </div>
      </CodeBox>

      <CodeBlock>{`import { Slider } from 'one-design-next';

  <div style={{ 
   '--odn-slider-rail-background': "linear-gradient(to right, rgb(255, 0, 0) 0%, rgb(255, 255, 0) 17%, rgb(0, 255, 0) 33%, rgb(0, 255, 255) 50%, rgb(0, 0, 255) 67%, rgb(255, 0, 255) 83%, rgb(255, 0, 0) 100%)",
  '--odn-slider-track-height': '${trackHeight}px',
  '--odn-slider-track-background': 'transparent',
  '--odn-slider-border-radius': '${borderRadius}px',
  '--odn-slider-handle-width': '${handleWidth}px',
  '--odn-slider-handle-height': '${handleHeight}px',
  '--odn-slider-handle-border-radius': '${handleBorderRadius}px',
  '--odn-slider-tooltip-padding-block': '${tooltipPaddingBlock}px',
  '--odn-slider-tooltip-padding-inline': '${tooltipPaddingInline}px',
  '--odn-slider-tooltip-font-size': '${tooltipFontSize}px',
  '--odn-slider-tooltip-border-radius': '${tooltipBorderRadius}px',
}}>
  <Slider value={value} onChange={setValue} tooltipVisible={false} />
</div>`}</CodeBlock>
    </div>
  );
};

export default Customize;
```
## API {#api}

继承 `Omit<React.HTMLAttributes<HTMLDivElement>, 'onChange' \| 'defaultValue'>`。

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| min / max | 最小 / 最大值 | `number` | `0` / `100` |
| step | 步长 | `number` | `1` |
| value | 当前值（单值或区间） | `number \| [number, number] \| null \| undefined` | - |
| onChange | 拖动过程 | `(value) => void` | - |
| onChangeComplete | 拖动结束 | `(value: SliderValue) => void` | - |
| range | 是否区间 | `boolean` | `false` |
| marks | 刻度 | `rc-slider` 的 `marks` | - |
| unit | 单位展示 | `React.ReactNode` | - |
| tooltipVisible | 是否显示滑块 Tooltip | `boolean` | `false` |
| onTooltipVisibleChange | Tooltip 显隐 | `(visible: boolean) => void` | - |
| inputVisible | 是否显示数字输入 | `boolean` | `false` |
| inputProps | 透传 `InputNumber` | `InputNumberProps` | - |

## 变量 {#variables}

<VariablesTable id="Slider"></VariablesTable>

---

## 开关 Switch

## 基础用例 {#basic-usage}

**示例：basic** — basic

```tsx
'use client';

import { Switch } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

const Basics = () => {
  const [params, setParams] = useState({
    size: 'medium',
    disabled: false,
    checked: false,
    showLabel: true,
    commonLabel: false, // 是否使用公共标签
    labelText: '已启用',
    uncheckedLabelText: '未启用',
    commonLabelText: '开关状态',
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'size', {
      options: {
        small: 'small',
        medium: 'medium',
        large: 'large',
      },
    });

    pane.addBinding(params, 'disabled', {
      type: 'boolean',
    });

    pane.addBinding(params, 'checked', {
      type: 'boolean',
    });

    pane.addBinding(params, 'showLabel', {
      type: 'boolean',
    });

    pane.addBinding(params, 'commonLabel', {
      type: 'boolean',
    });

    pane.addBinding(params, 'labelText', {
      type: 'string',
    });

    pane.addBinding(params, 'uncheckedLabelText', {
      type: 'string',
    });

    pane.addBinding(params, 'commonLabelText', {
      type: 'string',
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  // 根据配置动态生成 label props
  const getLabelProps = () => {
    if (!params.showLabel) return {};

    if (params.commonLabel) {
      return {
        commonLabel: params.commonLabelText,
      };
    } else {
      return {
        checkedLabel: params.labelText,
        uncheckedLabel: params.uncheckedLabelText,
      };
    }
  };

  const labelProps = getLabelProps();

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <Switch
          size={params.size as 'small' | 'medium' | 'large'}
          disabled={params.disabled}
          checked={params.checked}
          onChange={(checked) => setParams((prev) => ({ ...prev, checked }))}
          {...labelProps}
        />
      </CodeBox>

      <CodeBlock>{`import { Switch } from "one-design-next";

<Switch
  size="${params.size}"
  disabled={${params.disabled}}
  checked={${params.checked}}
  onChange={(checked) => setChecked(checked)}
  ${
    params.showLabel
      ? params.commonLabel
        ? `commonLabel="${params.commonLabelText}"`
        : `checkedLabel="${params.labelText}"
  uncheckedLabel="${params.uncheckedLabelText}"`
      : '// 无标签'
  }
/>`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## API {#api}

继承 `Omit<React.ComponentProps<typeof SwitchPrimitive.Root>, 'onChange'>`（Radix Switch）。

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| size | 尺寸 | `'small' \| 'medium' \| 'large'` | `'medium'` |
| checkedLabel / uncheckedLabel | 选/未选标签 | `React.ReactNode` | - |
| commonLabel | 统一标签（优先于上两者） | `React.ReactNode` | - |
| onChange | 状态变化 | `(checked: boolean) => void` | - |

## 变量 {#variables}

<VariablesTable id="Switch"></VariablesTable>

---

## 时间选择 TimePicker

## 基础用例 {#basic-usage}

通过 `picker` 属性来指定选择器类型：

**示例：basic** — basic

```tsx
'use client';

import { TimePicker } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
import { Pane } from 'tweakpane';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basic = () => {
  const [value, setValue] = useState<string | null>();
  const [params, setParams] = useState({
    picker: 'hour' as 'hour' | 'minute' | 'second',
    light: false,
    disabled: false,
    allowClear: true,
    minTime: '',
    maxTime: '',
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'picker', {
      options: {
        hour: 'hour',
        minute: 'minute',
        second: 'second',
      },
    });

    pane.addBinding(params, 'light');
    pane.addBinding(params, 'disabled');
    pane.addBinding(params, 'allowClear');

    pane.addBinding(params, 'minTime', {
      options: {
        '': '无',
        '06:27:27': '06:27:27',
        '09:00': '09:00',
        '12:00': '12:00',
      },
    });

    pane.addBinding(params, 'maxTime', {
      options: {
        '': '无',
        '15:00': '15:00',
        '18:45:45': '18:45:45',
        '23:00': '23:00',
        '23:00:00': '23:00:00',
        '22:59:59': '22:59:59',
      },
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  return (
    <div>
      <CodeBox className="gap-2 flex-wrap pt-[200px]">
        <div
          ref={tweakpaneContainerRef}
          className="absolute top-2 right-2 opacity-90"
        />
        <TimePicker
          value={value}
          onChange={setValue}
          picker={params.picker}
          disabled={params.disabled}
          light={params.light}
          allowClear={params.allowClear}
          minTime={params.minTime || undefined}
          maxTime={params.maxTime || undefined}
        />
      </CodeBox>
      <CodeBlock>{`import { TimePicker } from 'one-design-next';

// ${value || 'null'}
const [value, setValue] = useState<string | null>();

<TimePicker picker="${
        params.picker
      }" value={value} onChange={setValue} disabled={${
        params.disabled
      }} light={${params.light}} allowClear={${params.allowClear}}${
        params.minTime ? ` minTime="${params.minTime}"` : ''
      }${params.maxTime ? ` maxTime="${params.maxTime}"` : ''} />`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## API {#api}

继承 `Omit<React.HTMLAttributes<HTMLDivElement>, 'value' \| 'onChange'>`。

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| allowClear | 是否可清空 | `boolean` | `true` |
| visible | 受控显隐 | `boolean \| null` | `null` |
| onVisibleChange | 显隐回调 | `(visible: boolean) => void` | - |
| placeholder | 占位 | `string` | - |
| popupRender | 自定义弹层 | `(node: React.ReactNode) => React.ReactNode` | - |
| disabled | 是否禁用 | `boolean` | `false` |
| light | 轻量样式 | `boolean` | `false` |
| popupStyle | 弹层样式 | `React.CSSProperties` | - |
| triggerElement | 自定义触发器 | `React.ReactNode` | - |
| picker | 精度 | `'hour' \| 'minute' \| 'second'` | `'hour'` |
| value | 时间字符串如 `"15:00"` | `string \| null` | - |
| onChange | 变化 | `(time: string \| null) => void` | - |
| minTime / maxTime | 可选范围 | `string` | - |

## 变量 {#variables}

<VariablesTable id="TimePicker"></VariablesTable>

---

## 树选择器 TreeSelect

## 基础用例 {#basic-usage}

`TreeSelect` 支持单选和多选模式，通过 `multiple` 属性控制：

**示例：基础用例** — 基础用例

```tsx
'use client';

import { TreeSelect } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

const treeData = [
  {
    key: 'parent 1',
    value: 'parent 1',
    title: 'parent 1',
    children: [
      {
        key: 'parent 1-0',
        value: 'parent 1-0',
        title: 'parent 1-0',
        children: [
          {
            key: 'leaf1',
            value: 'leaf1',
            title: 'leaf1',
          },
          {
            key: 'leaf2',
            value: 'leaf2',
            title: 'leaf2',
          },
          {
            key: 'leaf3',
            value: 'leaf3',
            title: 'leaf3',
          },
        ],
      },
      {
        key: 'parent 1-1',
        value: 'parent 1-1',
        title: 'parent 1-1',
        children: [
          {
            key: 'leaf11',
            value: 'leaf11',
            title: <b style={{ color: '#08c' }}>leaf11</b>,
          },
        ],
      },
    ],
  },
  {
    key: 'parent 2',
    value: 'parent 2',
    title: 'parent 2',
    children: [
      {
        key: 'parent 2-0',
        value: 'parent 2-0',
        title: 'parent 2-0',
      },
      {
        key: 'parent 2-1',
        value: 'parent 2-1',
        title: 'parent 2-1',
      },
    ],
  },
];

const Basic = () => {
  const [value, setValue] = useState<string | number | (string | number)[]>();
  const [params, setParams] = useState({
    disabled: false,
    showInnerSearch: true,
    placeholder: '请选择',
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'disabled', {
      type: 'boolean',
    });

    pane.addBinding(params, 'showInnerSearch', {
      type: 'boolean',
    });

    pane.addBinding(params, 'placeholder', {
      type: 'string',
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <TreeSelect
          className="w-[320px]"
          disabled={params.disabled}
          mode="multiple"
          showInnerSearch={params.showInnerSearch}
          placeholder={params.placeholder}
          treeData={treeData}
          value={value}
          onChange={(val) => {
            console.log('onChange:', val);
            setValue(val as string | number | (string | number)[]);
          }}
          onSearch={(searchValue) => {
            console.log('onSearch:', searchValue);
          }}
        />
      </CodeBox>
      <CodeBlock>{`import { TreeSelect } from "one-design-next";

const treeData = [
  {
    value: 'parent 1',
    title: 'parent 1',
    children: [
      {
        value: 'parent 1-0',
        title: 'parent 1-0',
        children: [
          { value: 'leaf1', title: 'leaf1' },
          { value: 'leaf2', title: 'leaf2' },
          { value: 'leaf3', title: 'leaf3' },
        ],
      },
      {
        value: 'parent 1-1',
        title: 'parent 1-1',
        children: [
          { value: 'leaf11', title: 'leaf11' },
        ],
      },
    ],
  },
  {
    value: 'parent 2',
    title: 'parent 2',
    children: [
      { value: 'parent 2-0', title: 'parent 2-0' },
      { value: 'parent 2-1', title: 'parent 2-1' },
    ],
  },
];

<TreeSelect
  disabled={${params.disabled}}
  mode="multiple"
  showInnerSearch={${params.showInnerSearch}}
  placeholder="${params.placeholder}"
  treeData={treeData}
  value={value}
  onChange={(val) => {
    console.log('onChange:', val);
    setValue(val);
  }}
  onSearch={(searchValue) => {
    console.log('onSearch:', searchValue);
  }}
/>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 单选 {#single-selection}

**示例：单选** — 单选

```tsx
'use client';

import { TreeSelect } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

const treeData = [
  {
    key: 'parent 1',
    value: 'parent 1',
    title: 'parent 1',
    children: [
      {
        key: 'parent 1-0',
        value: 'parent 1-0',
        title: 'parent 1-0',
        children: [
          {
            key: 'leaf1',
            value: 'leaf1',
            title: 'leaf1',
          },
          {
            key: 'leaf2',
            value: 'leaf2',
            title: 'leaf2',
          },
          {
            key: 'leaf3',
            value: 'leaf3',
            title: 'leaf3',
          },
        ],
      },
      {
        key: 'parent 1-1',
        value: 'parent 1-1',
        title: 'parent 1-1',
        children: [
          {
            key: 'leaf11',
            value: 'leaf11',
            title: <b style={{ color: '#08c' }}>leaf11</b>,
          },
        ],
      },
    ],
  },
  {
    key: 'parent 2',
    value: 'parent 2',
    title: 'parent 2',
    children: [
      {
        key: 'parent 2-0',
        value: 'parent 2-0',
        title: 'parent 2-0',
      },
      {
        key: 'parent 2-1',
        value: 'parent 2-1',
        title: 'parent 2-1',
      },
    ],
  },
];

const Single = () => {
  const [value, setValue] = useState<string | number>();
  const [params, setParams] = useState({
    disabled: false,
    showInnerSearch: true,
    placeholder: '请选择',
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'disabled', {
      type: 'boolean',
    });

    pane.addBinding(params, 'showInnerSearch', {
      type: 'boolean',
    });

    pane.addBinding(params, 'placeholder', {
      type: 'string',
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <TreeSelect
          className="w-[320px]"
          disabled={params.disabled}
          showInnerSearch={params.showInnerSearch}
          placeholder={params.placeholder}
          treeData={treeData}
          value={value}
          onChange={(val) => {
            console.log('onChange:', val);
            setValue(val as string | number);
          }}
          onSearch={(searchValue) => {
            console.log('onSearch:', searchValue);
          }}
        />
      </CodeBox>
      <CodeBlock>{`import { TreeSelect } from "one-design-next";

const treeData = [
  {
    value: 'parent 1',
    title: 'parent 1',
    children: [
      {
        value: 'parent 1-0',
        title: 'parent 1-0',
        children: [
          { value: 'leaf1', title: 'leaf1' },
          { value: 'leaf2', title: 'leaf2' },
          { value: 'leaf3', title: 'leaf3' },
        ],
      },
      {
        value: 'parent 1-1',
        title: 'parent 1-1',
        children: [
          { value: 'leaf11', title: 'leaf11' },
        ],
      },
    ],
  },
  {
    value: 'parent 2',
    title: 'parent 2',
    children: [
      { value: 'parent 2-0', title: 'parent 2-0' },
      { value: 'parent 2-1', title: 'parent 2-1' },
    ],
  },
];

<TreeSelect
  disabled={${params.disabled}}
  showInnerSearch={${params.showInnerSearch}}
  placeholder="${params.placeholder}"
  treeData={treeData}
  value={value}
  onChange={(val) => {
    console.log('onChange:', val);
    setValue(val);
  }}
  onSearch={(searchValue) => {
    console.log('onSearch:', searchValue);
  }}
/>`}</CodeBlock>
    </div>
  );
};

export default Single;
```
## API {#api}

基于 `rc-tree-select`，`TreeSelectProps` 继承 `Omit<RcTreeSelectProps, 'treeData'>` 并扩展：

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| treeData | 树数据 | `TreeNodeData[]` | - |
| mode | 多选 | `'multiple'` | - |
| visible / onVisibleChange | 下拉显隐 | 同 rc | - |
| showInnerSearch | 下拉内搜索 | `boolean` | `false` |
| light | 轻量样式 | `boolean` | `false` |
| popupRender | 自定义下拉 | `(menu: ReactElement) => ReactElement` | - |

`TreeNodeData`：`key`、`title`、`value`、`children?`、`disabled?`、`checkable?`、`selectable?`、`isLeaf?`。

其余属性与 `rc-tree-select` 一致（如 `value`、`onChange`、`treeCheckable` 等）。

## 变量 {#variables}

<VariablesTable id="TreeSelect"></VariablesTable>
