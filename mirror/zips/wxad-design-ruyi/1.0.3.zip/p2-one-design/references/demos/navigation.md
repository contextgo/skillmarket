## 链接 Link

## 基础用例

**示例：basic** — basic

```tsx
'use client';

import { Link } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

const Basics = () => {
  const [params, setParams] = useState({
    disabled: false,
    hover: 'underline' as 'underline' | 'color',
    underline: false,
    prefixIcon: true,
    suffixIcon: false,
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'disabled', {
      type: 'boolean',
    });
    pane.addBinding(params, 'hover', {
      options: {
        underline: 'underline',
        color: 'color',
      },
    });
    pane.addBinding(params, 'underline', {
      type: 'boolean',
    });
    pane.addBinding(params, 'prefixIcon', {
      type: 'boolean',
    });
    pane.addBinding(params, 'suffixIcon', {
      type: 'boolean',
    });
    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  const props = {
    target: '_blank',
    disabled: params.disabled,
    hover: params.hover,
    underline: params.underline,
    prefixIcon: params.prefixIcon ? ('tag' as const) : undefined,
    suffixIcon: params.suffixIcon ? ('subdivide' as const) : undefined,
  };

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <div className="w-[500px]">
          Cursor 发布{' '}
          <Link
            href="https://cursor.com/cn/blog/browser-visual-editor"
            {...props}
          >
            可视化编辑器
          </Link>{' '}
          的两天后，linear 的 CEO Karri Saarinen 在 Twitter 分享了两篇{' '}
          <Link
            href="https://x.com/karrisaarinen/status/1999730838280503775"
            {...props}
          >
            关于设计师工作方式的思考
          </Link>
          。看起来，他对如今的“AI 设计时代”有一些意见。这也很正常 ——
          正如同今年他在{' '}
          <Link href="https://youtu.be/pCil7YNhNCU?t=316" {...props}>
            Figma Config
          </Link>{' '}
          上仍然不提 AI，而只说品质那样 —— 他始终以品质自居。我也在这篇《
          <Link href="https://wxad.design/abc/quality-of-ui" {...props}>
            用户界面的品质
          </Link>
          》 中分享了我对品质与 AI 的看法。
        </div>
      </CodeBox>
      <CodeBlock>{`import { Link } from "one-design-next";

<Link
  target="_blank"
  disabled={${params.disabled}}
  hover="${params.hover}"
  underline={${params.underline}}
  prefixIcon={${params.prefixIcon ? "'tag'" : undefined}}
  suffixIcon={${params.suffixIcon ? "'subdivide'" : undefined}}
/>`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## API

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| disabled | 是否禁用（禁用时不触发点击、无 `href`） | `boolean` | `false` |
| underline | 普通状态是否显示下划线 | `boolean` | `false` |
| onClick | 点击（禁用时不会触发） | `(e: React.MouseEvent<HTMLAnchorElement>) => void` | - |
| prefixIcon | 前缀图标 | `iconNames[number]` | - |
| suffixIcon | 后缀图标 | `iconNames[number]` | - |
| hover | 悬浮态样式 | `'underline' \| 'color'` | `'underline'` |

继承 `React.AnchorHTMLAttributes<HTMLAnchorElement>`。

## 变量

<VariablesTable id="Link"></VariablesTable>

---

## 分页器 Pagination

## 基础用例 {#basic-usage}

当 `type` 为 `simple` 时，分页器只显示页码和上下页按钮：

**示例：基础用例** — 基础用例

```tsx
'use client';

import { Pagination } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

const Basics = () => {
  const [value, setValue] = useState(1);
  const [params, setParams] = useState({
    totalSize: 100,
    pageSize: 10,
    showPrevNext: true,
    showFirstLast: false,
    showQuickJumper: true,
    showTotal: false,
    showSizeChanger: false,
    simple: false,
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'totalSize', {
      type: 'slider',
      min: 10,
      max: 200,
      step: 10,
    });

    pane.addBinding(params, 'pageSize', {
      type: 'slider',
      min: 10,
      max: 50,
      step: 1,
    });

    pane.addBinding(params, 'showPrevNext', {
      type: 'boolean',
    });

    pane.addBinding(params, 'showFirstLast', {
      type: 'boolean',
    });

    pane.addBinding(params, 'showQuickJumper', {
      type: 'boolean',
    });

    pane.addBinding(params, 'showTotal', {
      type: 'boolean',
    });

    pane.addBinding(params, 'showSizeChanger', {
      type: 'boolean',
    });

    pane.addBinding(params, 'simple', {
      type: 'boolean',
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  return (
    <div>
      <CodeBox className="pt-60">
        <div
          ref={tweakpaneContainerRef}
          className="absolute top-2 right-2 opacity-90"
        />
        <Pagination
          key={params.simple ? 'simple' : 'default'}
          type={params.simple ? 'simple' : 'default'}
          showPrevNext={params.showPrevNext}
          showFirstLast={params.showFirstLast}
          showQuickJumper={params.showQuickJumper}
          showTotal={params.showTotal}
          showSizeChanger={params.showSizeChanger}
          totalSize={params.totalSize}
          pageSize={params.pageSize}
          value={value}
          onChange={(_, value) => setValue(value)}
          onPageSizeChange={(newSize) => {
            setParams((prev) => ({ ...prev, pageSize: newSize }));
            setValue(1);
          }}
        />
      </CodeBox>
      <CodeBlock>{`import { Pagination } from 'one-design-next'

// value: ${value}
const [value, setValue] = useState(1);

<Pagination
  ${params.showPrevNext ? 'showPrevNext' : 'showPrevNext={false}'}
  ${params.showFirstLast ? 'showFirstLast' : 'showFirstLast={false}'}
  ${params.showQuickJumper ? 'showQuickJumper' : 'showQuickJumper={false}'}
  ${params.showTotal ? 'showTotal' : 'showTotal={false}'}
  ${params.showSizeChanger ? 'showSizeChanger' : 'showSizeChanger={false}'}
  totalSize={${params.totalSize}}
  pageSize={${params.pageSize}}
  value={value}
  onChange={(_, value) => setValue(value)}
  ${params.simple ? 'type="simple"' : ''}
/>`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## 业务定制 {#business-customization}

`Pagination` 提供以下 变量，用于业务定制：

**示例：自定义** — 自定义

```tsx
'use client';

import { Pagination } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

const Basics = () => {
  const [value, setValue] = useState(1);
  const [params, setParams] = useState({
    '--odn-pagination-gap': 8,
    '--odn-pagination-item-width': 24,
    '--odn-pagination-item-height': 24,
    '--odn-pagination-item-font-size': 12,
    '--odn-pagination-item-font-weight': 500,
    '--odn-pagination-item-color': 'rgba(10, 10, 10, 0.6)',
    '--odn-pagination-item-bg-hover': 'rgba(10, 10, 10, 0.04)',
    '--odn-pagination-item-bg-active': 'rgba(10, 10, 10, 0.08)',
    '--odn-pagination-item-font-weight-active': 500,
    '--odn-pagination-item-color-active': '#0A0A0A',
    '--odn-pagination-item-border-active': 'none',
    '--odn-pagination-item-border-radius': 4,
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, '--odn-pagination-gap', {
      label: '按钮间距',
      min: 0,
      max: 12,
      step: 1,
    });

    pane.addBinding(params, '--odn-pagination-item-width', {
      label: '按钮宽度',
      min: 16,
      max: 40,
      step: 1,
    });

    pane.addBinding(params, '--odn-pagination-item-height', {
      label: '按钮高度',
      min: 16,
      max: 40,
      step: 1,
    });

    pane.addBinding(params, '--odn-pagination-item-font-size', {
      label: '按钮字体大小',
      min: 12,
      max: 16,
      step: 1,
    });

    pane.addBinding(params, '--odn-pagination-item-font-weight', {
      label: '按钮字重',
      min: 400,
      max: 600,
      step: 100,
    });

    pane.addBinding(params, '--odn-pagination-item-color', {
      label: '按钮字体颜色',
      view: 'color',
      color: { alpha: true },
    });

    pane.addBinding(params, '--odn-pagination-item-bg-hover', {
      label: 'hover 背景颜色',
      view: 'color',
      color: { alpha: true },
    });

    pane.addBinding(params, '--odn-pagination-item-bg-active', {
      label: 'active 背景颜色',
      view: 'color',
      color: { alpha: true },
    });

    pane.addBinding(params, '--odn-pagination-item-color-active', {
      label: 'active 字体颜色',
      view: 'color',
      color: { alpha: true },
    });

    pane.addBinding(params, '--odn-pagination-item-font-weight-active', {
      label: 'active 字重',
      min: 400,
      max: 600,
      step: 100,
    });

    pane.addBinding(params, '--odn-pagination-item-border-active', {
      label: 'active 边框样式',
    });

    pane.addBinding(params, '--odn-pagination-item-border-radius', {
      label: '按钮圆角',
      min: 0,
      max: 10,
      step: 1,
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <Pagination
          key={JSON.stringify(params)}
          totalSize={100}
          pageSize={10}
          value={value}
          onChange={(_, value) => setValue(value)}
          style={{
            '--odn-pagination-gap': `${params['--odn-pagination-gap']}px`,
            '--odn-pagination-item-width': `${params['--odn-pagination-item-width']}px`,
            '--odn-pagination-item-height': `${params['--odn-pagination-item-height']}px`,
            '--odn-pagination-item-font-size': `${params['--odn-pagination-item-font-size']}px`,
            '--odn-pagination-item-font-weight':
              params['--odn-pagination-item-font-weight'],
            '--odn-pagination-item-color':
              params['--odn-pagination-item-color'],
            '--odn-pagination-item-bg-hover':
              params['--odn-pagination-item-bg-hover'],
            '--odn-pagination-item-bg-active':
              params['--odn-pagination-item-bg-active'],
            '--odn-pagination-item-font-weight-active':
              params['--odn-pagination-item-font-weight-active'],
            '--odn-pagination-item-color-active':
              params['--odn-pagination-item-color-active'],
            '--odn-pagination-item-border-active':
              params['--odn-pagination-item-border-active'],
            '--odn-pagination-item-border-radius': `${params['--odn-pagination-item-border-radius']}px`,
          }}
        />
      </CodeBox>
      <CodeBlock>{`import { Pagination } from 'one-design-next'

<Pagination
  style={{
    '--odn-pagination-gap': '${params['--odn-pagination-gap']}px',
    '--odn-pagination-item-width': '${params['--odn-pagination-item-width']}px',
    '--odn-pagination-item-height': '${params['--odn-pagination-item-height']}px',
    '--odn-pagination-item-font-size': '${params['--odn-pagination-item-font-size']}px',
    '--odn-pagination-item-font-weight': ${params['--odn-pagination-item-font-weight']},
    '--odn-pagination-item-color': '${params['--odn-pagination-item-color']}',
    '--odn-pagination-item-bg-hover': '${params['--odn-pagination-item-bg-hover']}',
    '--odn-pagination-item-bg-active': '${params['--odn-pagination-item-bg-active']}',
    '--odn-pagination-item-font-weight-active': ${params['--odn-pagination-item-font-weight-active']},
    '--odn-pagination-item-color-active': '${params['--odn-pagination-item-color-active']}',
    '--odn-pagination-item-border-active': '${params['--odn-pagination-item-border-active']}',
    '--odn-pagination-item-border-radius': '${params['--odn-pagination-item-border-radius']}px',
  }}
/>`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## API {#api}

继承 `Omit<React.HTMLAttributes<HTMLDivElement>, 'onChange'>`。

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| value | 当前页 | `number` | `1` |
| totalSize | 总条数 | `number` | - |
| pageSize | 每页条数 | `number` | `10` |
| onChange | 页码变化 | `(e, value: number, pageSize: number) => void` | - |
| onPageSizeChange | 每页条数变化 | `(newPageSize, pageSize) => void` | - |
| showPrevNext | 上一页 / 下一页 | `boolean` | `true` |
| showFirstLast | 首页 / 尾页 | `boolean` | `true` |
| showQuickJumper | 快速跳转 | `boolean` | `false` |
| showTotal | 显示总条数 | `boolean` | `false` |
| showSizeChanger | 显示每页条数选择器 | `boolean` | `false` |
| pageSizeOptions | 每页条数选项 | `number[]` | `[10, 20, 50]` |
| type | 样式类型 | `'default' \| 'simple'` | `'default'` |

## 变量 {#variables}

<VariablesTable id="Pagination"></VariablesTable>

---

## 标签栏 Tabs

## Default {#default}

**示例：Default** — Default

```tsx
'use client';

import { Tabs } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basics = () => {
  const [value, setValue] = useState('all');

  return (
    <div>
      <CodeBox>
        <Tabs.Default
          items={[
            { value: 'all', label: '全部视频' },
            { value: 'personal', label: '个人视频' },
            { value: 'mutual', label: '互选视频' },
          ]}
          value={value}
          onChange={setValue}
        />
      </CodeBox>
      <CodeBlock>{`import { Tabs } from 'one-design-next';

const [value, setValue] = useState('all');

<Tabs.Default
  items={[
    { value: 'all', label: '全部视频' },
    { value: 'personal', label: '个人视频' },
    { value: 'mutual', label: '互选视频' },
  ]}
  value={value}
  onChange={setValue}
/>`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## Default 定制样式 {#default-custom-styles}

使用 `itemClassName`, `itemStyle`, `activeItemClassName` & `activeItemStyle`定制样式：

**示例：Default定制样式** — Default定制样式

```tsx
'use client';

import { Tabs } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const DemoBox = () => {
  const [value, setValue] = useState('all');

  return (
    <div>
      <CodeBox>
        <Tabs.Default
          items={[
            { value: 'all', label: '全部视频' },
            { value: 'personal', label: '个人视频' },
            { value: 'mutual', label: '互选视频' },
          ]}
          value={value}
          onChange={setValue}
          gap={28}
          itemStyle={{
            paddingBottom: '15px',
            fontWeight: 400,
            fontSize: '13px',
            lineHeight: '20px',
          }}
          indicatorStyle={{ borderRadius: '0px' }}
        />
      </CodeBox>
      <CodeBlock>{`import { Tabs } from 'one-design-next';

const [value, setValue] = useState('all');

<Tabs.Default
  items={[
    { value: 'all', label: '全部视频' },
    { value: 'personal', label: '个人视频' },
    { value: 'mutual', label: '互选视频' },
  ]}
  value={value}
  onChange={setValue}
  gap={28}
  itemStyle={{ paddingBottom: '15px', fontWeight: 400, fontSize: '13px', lineHeight: '20px' }}
  indicatorStyle={{ borderRadius: '0px' }}
/>`}</CodeBlock>
    </div>
  );
};

export default DemoBox;
```
## ButtonGroup {#button-group}

**示例：ButtonGroup** — ButtonGroup

```tsx
'use client';

import { Tabs } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basics = () => {
  const [value, setValue] = useState('all');

  return (
    <div>
      <CodeBox>
        <Tabs.ButtonGroup
          items={[
            { value: 'all', label: '全部视频' },
            { value: 'personal', label: '个人视频' },
            { value: 'mutual', label: '互选视频' },
          ]}
          value={value}
          onChange={setValue}
        />
      </CodeBox>
      <CodeBlock>{`import { Tabs } from 'one-design-next';

const [value, setValue] = useState('all');

<Tabs.ButtonGroup
  items={[
    { value: 'all', label: '全部视频' },
    { value: 'personal', label: '个人视频' },
    { value: 'mutual', label: '互选视频' },
  ]}
  value={value}
  onChange={setValue}
/>`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## ButtonGroup 定制样式 {#button-group-custom-styles}

使用 `itemClassName`, `itemStyle`, `activeItemClassName`, `activeItemStyle`, `indicatorClassName` & `indicatorStyle`定制样式：

**示例：ButtonGroup定制样式** — ButtonGroup定制样式

```tsx
'use client';

import { Tabs } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const DemoBox = () => {
  const [value, setValue] = useState('all');
  const [value2, setValue2] = useState('广告效果');

  return (
    <div>
      <CodeBox className="flex flex-col gap-6">
        <Tabs.ButtonGroup
          items={[
            {
              value: 'all',
              label: (
                <>
                  <svg
                    width="16"
                    height="16"
                    viewBox="0 0 16 16"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      fillRule="evenodd"
                      clipRule="evenodd"
                      d="M7.50033 8.02652V4.66668H8.50033V8.03319L9.65333 6.88001L10.3603 7.58712L8.47503 9.4727C8.21466 9.73317 7.79255 9.73314 7.53222 9.47277L5.64699 7.58712L6.35399 6.88001L7.50033 8.02652ZM8.50033 4.66668H12.6677C13.0342 4.66668 13.3337 4.9639 13.3337 5.33055V14.0028C13.3337 14.3674 13.0364 14.6667 12.6698 14.6667H3.33086C2.96627 14.6667 2.66699 14.3695 2.66699 14.0028V5.33055C2.66699 4.96596 2.96516 4.66668 3.33296 4.66668H7.50033V1.33334H8.50033V4.66668Z"
                    />
                  </svg>
                  应用
                </>
              ),
            },
            {
              value: 'personal',
              label: (
                <>
                  <svg
                    width="16"
                    height="16"
                    viewBox="0 0 16 16"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      fillRule="evenodd"
                      clipRule="evenodd"
                      d="M10.0552 8.23791C9.60193 9.09045 8.4128 9.33646 7.39922 8.78745C6.38577 8.23843 5.9316 7.10193 6.38487 6.24952C6.83815 5.39673 8.02728 5.15072 9.04086 5.69999C10.0543 6.249 10.5085 7.38525 10.0552 8.23791ZM10.2137 5.09825C7.83684 2.91774 4.38916 2.83976 2.5128 4.92388C0.636309 7.00801 1.04197 10.4651 3.41858 12.6454C5.79557 14.8259 9.24324 14.9041 11.1196 12.8199C12.9961 10.7358 12.5904 7.27863 10.2137 5.09825Z"
                    />
                    <path
                      fillRule="evenodd"
                      clipRule="evenodd"
                      d="M12.379 1.71485C13.3065 1.47001 14.2942 2.18212 14.5851 3.30567C14.8761 4.42895 14.3602 5.53812 13.4329 5.78283C12.5057 6.02767 11.518 5.31556 11.2267 4.19215C10.9357 3.06873 11.4516 1.95982 12.379 1.71485Z"
                    />
                  </svg>
                  小游戏
                </>
              ),
            },
            { value: 'mutual', label: '不启用' },
          ]}
          value={value}
          onChange={setValue}
          gap={10}
          style={{ border: 'none' }}
          itemStyle={{
            padding: '0 12px 0 10px',
            fontSize: '13px',
            lineHeight: '32px',
            outline: '1px solid rgba(73, 90, 122, 0.1)',
            borderRadius: '4px',
          }}
          activeItemStyle={{ fontWeight: 600 }}
          indicatorStyle={{ borderRadius: '4px' }}
        />
        <div className="p-[3px] rounded-md bg-black/[0.02]">
          <Tabs.ButtonGroup
            style={{
              border: 'none',
            }}
            items={[
              { value: '广告效果', label: '广告效果' },
              { value: '观看', label: '观看' },
              { value: '互动', label: '互动' },
              { value: '交易', label: '交易' },
            ]}
            indicatorStyle={{
              backgroundColor: 'rgba(255, 97, 70, 0.12)',
              outline: 'none',
              borderRadius: '6px',
            }}
            itemStyle={{
              padding: '0 8px',
              height: '26px',
              fontSize: '12px',
              fontWeight: 600,
              color: 'rgba(0, 0, 0, 0.58)',
            }}
            activeItemStyle={{
              color: 'rgb(255, 97, 70)',
            }}
            gap={12}
            value={value2}
            onChange={setValue2}
          />
        </div>
      </CodeBox>
      <CodeBlock>{`import { Tabs } from 'one-design-next';

const [value, setValue] = useState('all');

<Tabs.ButtonGroup
  items={[
    {
      value: 'all',
      label: <><svg />应用</>,
    },
    {
      value: 'personal',
      label: <><svg />小游戏</>,
    },
    { value: 'mutual', label: '不启用' },
  ]}
  value={value}
  onChange={setValue}
  gap={10}
  style={{ border: 'none' }}
  itemStyle={{
    padding: '0 12px 0 10px',
    fontSize: '13px',
    lineHeight: '32px',
    outline: '1px solid rgba(73, 90, 122, 0.1)',
    borderRadius: '4px',
  }}
  activeItemStyle={{ fontWeight: 600 }}
  indicatorStyle={{ borderRadius: '4px' }}
/>`}</CodeBlock>
    </div>
  );
};

export default DemoBox;
```
## Vertical {#vertical}

**示例：Vertical** — Vertical

```tsx
'use client';

import { Tabs } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basics = () => {
  const [value, setValue] = useState('all');

  return (
    <div>
      <CodeBox>
        <Tabs.Vertical
          items={[
            { value: 'all', label: '全部视频' },
            { value: 'personal', label: '个人视频' },
            { value: 'mutual', label: '互选视频' },
          ]}
          value={value}
          onChange={setValue}
        />
      </CodeBox>
      <CodeBlock>{`import { Tabs } from 'one-design-next';

const [value, setValue] = useState('all');

<Tabs.Vertical
  items={[
    { value: 'all', label: '全部视频' },
    { value: 'personal', label: '个人视频' },
    { value: 'mutual', label: '互选视频' },
  ]}
  value={value}
  onChange={setValue}
/>`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## Vertical 定制样式 {#vertical-custom-styles}

使用 `itemClassName`, `itemStyle`, `activeItemClassName` & `activeItemStyle`定制样式：

**示例：Vertical定制样式** — Vertical定制样式

```tsx
'use client';

import { Tabs } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const DemoBox = () => {
  const [value, setValue] = useState('0');

  return (
    <div>
      <CodeBox>
        <Tabs.Vertical
          itemStyle={(_, index) => ({
            gap: '6px',
            marginBottom: index === 6 ? 0 : index < 2 ? '16px' : '12px',
            paddingLeft: '17px',
            height: index < 3 ? '28px' : '22px',
            fontSize: index < 3 ? '16px' : '14px',
          })}
          items={[
            {
              value: '0',
              label: (
                <>
                  <svg width="20" height="20" viewBox="0 0 20 20">
                    <circle cx="10" cy="10" r="9" />
                    <path
                      d="M10.3231 5.432H11.3791V14H9.97506V7.124C9.45906 7.592 8.81106 7.94 8.01906 8.168V6.776C8.40306 6.68 8.81106 6.512 9.24306 6.272C9.67506 6.008 10.0351 5.732 10.3231 5.432Z"
                      fill="white"
                    />
                  </svg>
                  创作者
                </>
              ),
            },
            {
              value: '1',
              label: (
                <>
                  <svg width="20" height="20" viewBox="0 0 20 20">
                    <circle cx="10" cy="10" r="9" />
                    <path
                      d="M10.1343 5.264C10.9623 5.264 11.6463 5.504 12.1863 5.984C12.7143 6.464 12.9783 7.076 12.9783 7.844C12.9783 8.588 12.6903 9.26 12.1383 9.872C11.8023 10.232 11.2023 10.688 10.3623 11.252C9.48634 11.828 8.95834 12.332 8.76634 12.764H12.9903V14H7.01434C7.01434 13.124 7.29034 12.368 7.86634 11.72C8.17834 11.36 8.83834 10.832 9.83434 10.148C10.3863 9.764 10.7703 9.44 11.0103 9.188C11.3823 8.768 11.5743 8.312 11.5743 7.832C11.5743 7.364 11.4423 7.016 11.2023 6.788C10.9503 6.56 10.5783 6.452 10.0863 6.452C9.55834 6.452 9.16234 6.632 8.89834 6.992C8.63434 7.328 8.49034 7.844 8.46634 8.516H7.06234C7.07434 7.556 7.35034 6.788 7.90234 6.2C8.46634 5.576 9.21034 5.264 10.1343 5.264Z"
                      fill="white"
                    />
                  </svg>
                  营销目标
                </>
              ),
            },
            {
              value: '2',
              label: (
                <>
                  <svg width="20" height="20" viewBox="0 0 20 20">
                    <circle cx="10" cy="10" r="9" />
                    <path
                      d="M10.0863 5.264C10.9503 5.264 11.6583 5.468 12.1863 5.888C12.7023 6.308 12.9663 6.884 12.9663 7.628C12.9663 8.564 12.4863 9.188 11.5383 9.5C12.0423 9.656 12.4383 9.884 12.7023 10.196C12.9903 10.52 13.1343 10.94 13.1343 11.444C13.1343 12.236 12.8583 12.884 12.3063 13.388C11.7303 13.904 10.9743 14.168 10.0383 14.168C9.15034 14.168 8.43034 13.94 7.89034 13.484C7.29034 12.98 6.95434 12.236 6.88234 11.276H8.31034C8.33434 11.828 8.50234 12.26 8.83834 12.56C9.13834 12.836 9.53434 12.98 10.0263 12.98C10.5663 12.98 10.9983 12.824 11.3103 12.524C11.5863 12.248 11.7303 11.912 11.7303 11.504C11.7303 11.012 11.5743 10.652 11.2863 10.424C10.9983 10.184 10.5783 10.076 10.0263 10.076H9.42634V9.02H10.0263C10.5303 9.02 10.9143 8.912 11.1783 8.696C11.4303 8.48 11.5623 8.156 11.5623 7.736C11.5623 7.316 11.4423 7.004 11.2143 6.788C10.9623 6.572 10.5903 6.464 10.0983 6.464C9.59434 6.464 9.21034 6.584 8.93434 6.836C8.64634 7.088 8.47834 7.472 8.43034 7.988H7.05034C7.12234 7.124 7.43434 6.452 8.01034 5.972C8.55034 5.492 9.24634 5.264 10.0863 5.264Z"
                      fill="white"
                    />
                  </svg>
                  合作需求
                </>
              ),
            },
            {
              value: '3',
              label: (
                <>
                  <svg width="20" height="20" viewBox="0 0 20 20">
                    <circle cx="10" cy="10" r="2" />
                  </svg>
                  推广产品信息
                </>
              ),
            },
            {
              value: '4',
              label: (
                <>
                  <svg width="20" height="20" viewBox="0 0 20 20">
                    <circle cx="10" cy="10" r="2" />
                  </svg>
                  履约联系方式
                </>
              ),
            },
            {
              value: '5',
              label: (
                <>
                  <svg width="20" height="20" viewBox="0 0 20 20">
                    <circle cx="10" cy="10" r="2" />
                  </svg>
                  内容制作要求
                </>
              ),
            },
            {
              value: '6',
              label: (
                <>
                  <svg width="20" height="20" viewBox="0 0 20 20">
                    <circle cx="10" cy="10" r="2" />
                  </svg>
                  营销组件配置
                </>
              ),
            },
          ]}
          value={value}
          onChange={setValue}
        />
      </CodeBox>
      <CodeBlock>{`import { Tabs } from 'one-design-next';

const [value, setValue] = useState('0');

<Tabs.Vertical
  itemStyle={(_, index) => ({
    gap: '6px',
    marginBottom: index === 6 ? 0 : index < 2 ? '16px' : '12px',
    paddingLeft: '17px',
    height: index < 3 ? '28px' : '22px',
    fontSize: index < 3 ? '16px' : '14px',
  })}
  items={[
    { value: '0', label: <><svg />创作者</> },
    { value: '1', label: <><svg />营销目标</> },
    { value: '2', label: <><svg />合作需求</> },
    { value: '3', label: <><svg />推广产品信息</> },
    { value: '4', label: <><svg />履约联系方式</> },
    { value: '5', label: <><svg />内容制作要求</> },
    { value: '6', label: <><svg />营销组件配置</> },
  ]}
  value={value}
  onChange={setValue}
/>`}</CodeBlock>
    </div>
  );
};

export default DemoBox;
```
## Divider {#divider}

**示例：Divider** — Divider

```tsx
'use client';

import { Tabs } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';

const Basics = () => {
  const [value, setValue] = useState('all');

  return (
    <div>
      <CodeBox>
        <Tabs.Divider
          items={[
            { value: 'all', label: '全部视频' },
            { value: 'personal', label: '个人视频' },
            { value: 'mutual', label: '互选视频' },
          ]}
          value={value}
          onChange={setValue}
        />
      </CodeBox>
      <CodeBlock>{`import { Tabs } from 'one-design-next';

const [value, setValue] = useState('all');

<Tabs.Divider
  items={[
    { value: 'all', label: '全部视频' },
    { value: 'personal', label: '个人视频' },
    { value: 'mutual', label: '互选视频' },
  ]}
  value={value}
  onChange={setValue}
/>`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## Divider 定制样式 {#divider-custom-styles}

使用 `itemClassName`, `itemStyle`, `activeItemClassName` & `activeItemStyle`定制样式：

**示例：Divider定制样式** — Divider定制样式

```tsx
'use client';

import { Tabs } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';

const DemoBox = () => {
  const [value, setValue] = useState('all');

  return (
    <div>
      <CodeBox>
        <Tabs.Divider
          items={[
            { value: 'all', label: '全部视频' },
            { value: 'personal', label: '个人视频' },
            { value: 'mutual', label: '互选视频' },
          ]}
          value={value}
          onChange={setValue}
          itemStyle={(_, index) => ({
            fontSize: 16 - index * 2,
          })}
          activeItemStyle={{
            textDecoration: 'underline',
            textUnderlineOffset: 2,
          }}
          dividerStyle={{ background: 'transparent' }}
        />
      </CodeBox>
      <CodeBlock>{`import { Tabs } from 'one-design-next';

const [value, setValue] = useState('all');

<Tabs.Divider
  items={[
    { value: 'all', label: '全部视频' },
    { value: 'personal', label: '个人视频' },
    { value: 'mutual', label: '互选视频' },
  ]}
  value={value}
  onChange={setValue}
  itemStyle={(_, index) => ({
    fontSize: 16 - index * 2,
  })}
  activeItemStyle={{
    textDecoration: 'underline',
    textUnderlineOffset: 2,
  }}
  dividerStyle={{ background: 'transparent' }}
/>`}</CodeBlock>
    </div>
  );
};

export default DemoBox;
```
## Tag {#tag}

**示例：Tag** — Tag

```tsx
'use client';

import { Tabs } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';

const Basics = () => {
  const [value, setValue] = useState('all');

  return (
    <div>
      <CodeBox>
        <Tabs.Tag
          items={[
            { value: 'all', label: '全部视频' },
            { value: 'personal', label: '个人视频' },
            { value: 'mutual', label: '互选视频' },
          ]}
          value={value}
          onChange={setValue}
        />
      </CodeBox>
      <CodeBlock>{`import { Tabs } from 'one-design-next';

const [value, setValue] = useState('all');

<Tabs.Tag
  items={[
    { value: 'all', label: '全部视频' },
    { value: 'personal', label: '个人视频' },
    { value: 'mutual', label: '互选视频' },
  ]}
  value={value}
  onChange={setValue}
/>`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## Tag 定制样式 {#tag-custom-styles}

使用 `itemClassName`, `itemStyle`, `activeItemClassName` & `activeItemStyle`定制样式：

**示例：Tag定制样式** — Tag定制样式

```tsx
'use client';

import { Tabs } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const DemoBox = () => {
  const [value, setValue] = useState('阅读量');
  const [value0, setValue0] = useState('分日数据');

  return (
    <div>
      <CodeBox className="flex-col items-baseline">
        <Tabs.Tag
          className="mb-6"
          value={value0}
          onChange={setValue0}
          items={[
            {
              value: '分日数据',
              label: '分日数据',
            },
            {
              value: '累计数据',
              label: '累计数据',
            },
          ]}
        />
        <Tabs.Tag
          style={{ width: '100%' }}
          items={[
            {
              value: '阅读量',
              label: (item, index, active) => (
                <>
                  <div
                    className={`text-sm leading-[22px] ${
                      active ? 'opacity-80 font-semibold' : 'text-[#33373D]/58'
                    }`}
                  >
                    阅读量
                  </div>
                  <div
                    className={`font-semibold text-[20px] leading-[28px] ${
                      active ? '' : 'text-[#000]'
                    }`}
                  >
                    532
                  </div>
                </>
              ),
            },
            {
              value: '点赞量',
              label: (item, index, active) => (
                <>
                  <div
                    className={`flex items-center gap-px text-sm leading-[22px] ${
                      active ? 'opacity-80 font-semibold' : 'text-[#33373D]/58'
                    }`}
                  >
                    <svg width="17" height="22" viewBox="0 0 17 22" fill="none">
                      <path
                        fillRule="evenodd"
                        clipRule="evenodd"
                        d="M10.6362 7.53148L10.5181 9.36977H13.1907C14.0886 9.36977 14.7636 10.2933 14.6278 11.212L14.6101 11.3104L13.6576 15.8063C13.5163 16.468 12.9775 16.9483 12.3397 16.9947L12.2382 16.9984L3.10002 16.995C2.73192 16.9946 2.4336 16.6961 2.43335 16.328V10.6079C2.43335 10.2397 2.73183 9.94122 3.10002 9.94122H4.72749L5.56878 9.9214L5.84687 9.90914L5.95873 9.89951L5.9776 9.89621C6.88105 9.68605 7.571 8.29192 7.69769 7.04528L7.70457 6.93863L7.71907 6.55702L7.73382 6.37364C7.78268 5.90172 7.93323 5.34695 8.45411 5.11832C9.82328 4.51737 10.7114 6.34155 10.6362 7.53148ZM8.77564 5.85086C8.66911 5.89762 8.58778 6.04726 8.54532 6.32682L8.53125 6.43779L8.51849 6.58739L8.50291 6.99011L8.49359 7.12616C8.32519 8.7832 7.4171 10.3827 6.15886 10.6754L6.094 10.6875L5.95855 10.7025L5.83752 10.7107L5.66668 10.7173V16.196L12.2092 16.1989L12.2817 16.1968C12.5363 16.1783 12.7627 15.9939 12.8523 15.724L12.8749 15.6405L13.8227 11.1688L13.8364 11.095C13.9022 10.6497 13.6003 10.223 13.2557 10.1744L13.1907 10.1698H9.66503L9.83781 7.48106C9.89879 6.51543 9.26246 5.63719 8.77564 5.85086ZM4.86668 10.738L4.72749 10.7412L3.23268 10.7407V16.1947L4.86668 16.1953V10.738Z"
                      />
                    </svg>
                    量
                  </div>
                  <div
                    className={`font-semibold text-[20px] leading-[28px] ${
                      active ? '' : 'text-[#000]'
                    }`}
                  >
                    532
                  </div>
                </>
              ),
            },
            {
              value: '转发量',
              label: (item, index, active) => (
                <>
                  <div
                    className={`flex items-center gap-px text-sm leading-[22px] ${
                      active ? 'opacity-80 font-semibold' : 'text-[#33373D]/58'
                    }`}
                  >
                    <svg width="17" height="22" viewBox="0 0 17 22">
                      <path
                        fillRule="evenodd"
                        clipRule="evenodd"
                        d="M9.06911 4.99866C9.24482 4.99866 9.41342 5.06803 9.53826 5.19168L14.3191 9.92717C14.5606 10.1663 14.5809 10.5444 14.3788 10.8069L14.3191 10.8745L9.53826 15.61C9.27667 15.8691 8.85457 15.8671 8.59546 15.6055C8.47181 15.4806 8.40244 15.312 8.40244 15.1363V12.9477C6.84336 13.073 4.56773 13.9942 3.38388 16.8812C3.1872 17.3608 2.70471 17.3567 2.59971 16.735C1.76872 11.8151 4.56773 8.4765 8.40244 7.87222V5.66532C8.40244 5.29713 8.70092 4.99866 9.06911 4.99866ZM9.20197 5.9853L9.20244 8.55603L8.52697 8.66247C5.30993 9.16942 3.20952 11.6756 3.25558 15.1685L3.25997 15.36C4.32251 13.618 6.1058 12.3933 8.14783 12.1684L9.20244 12.0808L9.20197 14.816L13.6606 10.4006L9.20197 5.9853Z"
                      />
                    </svg>
                    量
                  </div>
                  <div
                    className={`font-semibold text-[20px] leading-[28px] ${
                      active ? '' : 'text-[#000]'
                    }`}
                  >
                    532
                  </div>
                </>
              ),
            },
            {
              value: '爱心量',
              label: (item, index, active) => (
                <>
                  <div
                    className={`flex items-center gap-px text-sm leading-[22px] ${
                      active ? 'opacity-80 font-semibold' : 'text-[#33373D]/58'
                    }`}
                  >
                    <svg width="17" height="22" viewBox="0 0 17 22">
                      <path
                        fillRule="evenodd"
                        clipRule="evenodd"
                        d="M8.12716 7.17626L8.38461 7.42771L8.59856 7.63098L8.9068 7.33676L9.06997 7.17626C10.3717 5.87451 12.4823 5.87451 13.784 7.17626C15.0737 8.4659 15.0856 10.5494 13.82 11.8538L9.06994 16.6043C8.82966 16.8447 8.4515 16.8632 8.18997 16.6599L8.12716 16.6044L3.37685 11.854C2.11148 10.5494 2.12347 8.4659 3.41311 7.17626C4.71486 5.87451 6.82541 5.87451 8.12716 7.17626ZM7.56147 7.74195C6.57214 6.75262 4.96813 6.75262 3.9788 7.74195C3.03354 8.6872 2.99041 10.196 3.84729 11.1845L3.94254 11.2884L8.59743 15.9453L13.2458 11.2967C14.1754 10.3387 14.197 8.82948 13.3162 7.84533L13.2183 7.74195C12.229 6.75262 10.625 6.75262 9.63565 7.74195L9.36762 8.00378L8.59856 8.73013L7.73185 7.90956L7.56147 7.74195Z"
                      />
                    </svg>
                    量
                  </div>
                  <div
                    className={`font-semibold text-[20px] leading-[28px] ${
                      active ? '' : 'text-[#000]'
                    }`}
                  >
                    532
                  </div>
                </>
              ),
            },
            {
              value: '评论量',
              label: (item, index, active) => (
                <>
                  <div
                    className={`flex items-center gap-px text-sm leading-[22px] ${
                      active ? 'opacity-80 font-semibold' : 'text-[#33373D]/58'
                    }`}
                  >
                    <svg width="17" height="22" viewBox="0 0 17 22">
                      <path
                        fillRule="evenodd"
                        clipRule="evenodd"
                        d="M13.4666 6C14.387 6 15.1332 6.74619 15.1332 7.66667V13.3333C15.1332 14.2538 14.387 15 13.4666 15H8.46655L6.93796 16.5267C6.67761 16.787 6.2555 16.787 5.99515 16.5267C5.87012 16.4016 5.79989 16.2368 5.79989 16.06V15H4.13322C3.21274 15 2.46655 14.2538 2.46655 13.3333V7.66667C2.46655 6.74619 3.21274 6 4.13322 6H13.4666ZM13.4666 6.8H4.13322C3.68449 6.8 3.31541 7.14103 3.27103 7.57806L3.26655 7.66667V13.3333C3.26655 13.7821 3.60759 14.1511 4.04461 14.1955L4.13322 14.2H6.59989L6.59922 15.7333L8.13548 14.2H13.4666C13.9153 14.2 14.2844 13.859 14.3287 13.4219L14.3332 13.3333V7.66667C14.3332 7.21794 13.9922 6.84886 13.5552 6.80447L13.4666 6.8Z"
                      />
                    </svg>
                    量
                  </div>
                  <div
                    className={`font-semibold text-[20px] leading-[28px] ${
                      active ? '' : 'text-[#000]'
                    }`}
                  >
                    532
                  </div>
                </>
              ),
            },
          ]}
          value={value}
          onChange={setValue}
          itemStyle={{
            flex: 1,
            flexDirection: 'column',
            alignItems: 'flex-start',
            padding: '8px 12px',
            height: 'initial',
            borderRadius: '6px',
          }}
        />
      </CodeBox>
      <CodeBlock>{`import { Tabs } from 'one-design-next';

const [value, setValue] = useState('阅读量');

<Tabs.Tag
  style={{ width: '100%' }}
  items={[
    {
      value: '阅读量',
      label: (item, index, active) => (
        <>
          <div
            className={\`text-sm leading-[22px] \${active ? 'opacity-80 font-semibold' : 'text-[#33373D]/58'}\`}
          >
            阅读量
          </div>
          <div className={\`font-semibold text-[20px] leading-[28px] \${active ? '' : 'text-[#000]'}\`}>532</div>
        </>
      ),
    },
    {
      value: '点赞量',
      label: (item, index, active) => (
        <>
          <div
            className={\`flex items-center gap-px text-sm leading-[22px] \${
              active ? 'opacity-80 font-semibold' : 'text-[#33373D]/58'
            }\`}
          >
            <svg />量
          </div>
          <div className={\`font-semibold text-[20px] leading-[28px] \${active ? '' : 'text-[#000]'}\`}>532</div>
        </>
      ),
    },
    {
      value: '转发量',
      label: (item, index, active) => (
        <>
          <div
            className={\`flex items-center gap-px text-sm leading-[22px] \${
              active ? 'opacity-80 font-semibold' : 'text-[#33373D]/58'
            }\`}
          >
            <svg />量
          </div>
          <div className={\`font-semibold text-[20px] leading-[28px] \${active ? '' : 'text-[#000]'}\`}>532</div>
        </>
      ),
    },
    {
      value: '爱心量',
      label: (item, index, active) => (
        <>
          <div
            className={\`flex items-center gap-px text-sm leading-[22px] \${
              active ? 'opacity-80 font-semibold' : 'text-[#33373D]/58'
            }\`}
          >
            <svg />量
          </div>
          <div className={\`font-semibold text-[20px] leading-[28px] \${active ? '' : 'text-[#000]'}\`}>532</div>
        </>
      ),
    },
    {
      value: '评论量',
      label: (item, index, active) => (
        <>
          <div
            className={\`flex items-center gap-px text-sm leading-[22px] \${
              active ? 'opacity-80 font-semibold' : 'text-[#33373D]/58'
            }\`}
          >
            <svg />量
          </div>
          <div className={\`font-semibold text-[20px] leading-[28px] \${active ? '' : 'text-[#000]'}\`}>532</div>
        </>
      ),
    },
  ]}
  value={value}
  onChange={setValue}
  itemStyle={{
    flex: 1,
    flexDirection: 'column',
    alignItems: 'flex-start',
    padding: '8px 12px',
    height: 'initial',
    borderRadius: '6px',
  }}
/>`}</CodeBlock>
    </div>
  );
};

export default DemoBox;
```
## API {#api}

各变体（`Tabs` / `Tabs.Vertical` / `Tabs.Divider` / `Tabs.ButtonGroup` / `Tabs.Tag`）均在 `TabsBaseProps` 上增加少量样式相关字段。

### TabsBaseProps

| 属性                                  | 说明         | 类型                                                | 默认值 |
| ------------------------------------- | ------------ | --------------------------------------------------- | ------ |
| items                                 | 选项         | `TabItem<T>[]`                                      | -      |
| value                                 | 当前值       | `T`                                                 | -      |
| onChange                              | 切换         | `(value: T, value_: T, e: MouseEvent<HTMLDivElement>) => void` | -      |
| gap                                   | 项间距（px） | `number`                                            | -      |
| itemClassName / itemStyle             | 每一项       | `string` 或函数                                     | -      |
| activeItemClassName / activeItemStyle | 激活项       | `string` 或函数                                     | -      |

`TabItem`：`value`、`label`（或渲染函数）、`disabled?`。

继承 `Omit<React.HTMLAttributes<HTMLDivElement>, 'onChange' | ...>`（见源码）。

### 变体额外属性

| 组件                            | 额外属性                                                                                                 |
| ------------------------------- | -------------------------------------------------------------------------------------------------------- |
| Vertical                        | `indicatorWrapperClassName` / `indicatorWrapperStyle` / `indicatorClassName` / `indicatorStyle`          |
| Divider                         | `dividerClassName` / `dividerStyle`                                                                      |
| ButtonGroup / Tabs（默认）/ Tag | `indicatorClassName` / `indicatorStyle`（具体以导出类型 `TabsVerticalProps`、`TabsDividerProps` 等为准） |

## 变量 {#variables}

<VariablesTable id="Tabs"></VariablesTable>
