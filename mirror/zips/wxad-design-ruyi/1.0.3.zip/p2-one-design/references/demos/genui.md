## 操作栏 ActionBar

## 基础用例 {#basic-usage}

**示例：基础用例** — 基础用例

```tsx
'use client';

import { ActionBar } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

const Demo = () => {
  const [params, setParams] = useState({
    content: '这是一段示例文本，点击复制按钮可以复制到剪贴板。',
    showRegenerate: true,
    versionCount: 1,
    currentVersion: 0,
  });
  const [feedbackLog, setFeedbackLog] = useState('');

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  const safeCurrent = Math.min(
    params.currentVersion,
    Math.max(0, params.versionCount - 1),
  );

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'content', {
      label: 'content',
      multiline: true,
      rows: 3,
    });
    pane.addBinding(params, 'showRegenerate', { label: '显示重新生成' });
    pane.addBinding(params, 'versionCount', {
      label: '版本数',
      min: 1,
      max: 9,
      step: 1,
    });
    pane.addBinding(params, 'currentVersion', {
      label: '当前版本',
      min: 0,
      max: 8,
      step: 1,
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  const codeLines: string[] = [
    `import { ActionBar } from 'one-design-next';`,
    ``,
    `<ActionBar`,
    `  content={${JSON.stringify(params.content)}}`,
  ];
  if (params.showRegenerate) {
    codeLines.push(`  onRegenerate={() => {}}`);
  }
  if (params.versionCount > 1) {
    codeLines.push(`  versionCount={${params.versionCount}}`);
    codeLines.push(`  currentVersion={${safeCurrent}}`);
    codeLines.push(`  onVersionChange={(index) => {}}`);
  }
  codeLines.push(`  onFeedback={(type) => {}}`);
  codeLines.push(`/>`);

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <div
          className="space-y-4"
          style={{ minHeight: 160 }}
        >
          <div
            className="max-w-md text-center text-sm"
            style={{ color: 'var(--odn-color-black-10)' }}
          >
            {params.content}
          </div>
          <ActionBar
            content={params.content}
            onRegenerate={params.showRegenerate ? () => {} : undefined}
            onFeedback={(type) => {
              setFeedbackLog(type === null ? 'null' : type ?? '');
            }}
            versionCount={params.versionCount}
            currentVersion={safeCurrent}
            onVersionChange={(index) => {
              setParams((p) => ({ ...p, currentVersion: index }));
            }}
          />
          {feedbackLog !== '' && (
            <div
              className="text-xs"
              style={{ color: 'var(--odn-color-black-8)' }}
            >
              反馈: {feedbackLog}
            </div>
          )}
        </div>
      </CodeBox>
      <CodeBlock>{codeLines.join('\n')}</CodeBlock>
    </div>
  );
};

export default Demo;
```
## API {#api}

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| content | 可复制的文本内容 | `string` | - |
| onRegenerate | 重新生成回调 | `() => void` | - |
| feedback | 当前反馈状态（受控） | `'positive' \| 'negative' \| null` | - |
| onFeedback | 反馈回调 | `(type: 'positive' \| 'negative' \| null) => void` | - |
| versionCount | 版本总数 | `number` | `1` |
| currentVersion | 当前版本索引 | `number` | `0` |
| onVersionChange | 版本切换 | `(index: number) => void` | - |

---

## 分步 AgentStep

## 基础用例 {#basic-usage}

**示例：基础用例** — 基础用例

```tsx
'use client';

import { AgentStep, type ToolCall } from 'one-design-next';
import React, { useEffect, useMemo, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

type DemoStatus = ToolCall['status'];

const Demo = () => {
  const [params, setParams] = useState({
    status: 'success' as DemoStatus,
    defaultOpen: false,
    name: '读取文件',
    desc: 'src/App.tsx',
    includeParams: true,
    includeResult: true,
    includeError: true,
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  const tool: ToolCall = useMemo(() => {
    const t: ToolCall = {
      id: 'pg',
      name: params.name,
      description: params.desc,
      status: params.status,
    };
    if (params.includeParams) {
      t.params = { path: 'src/App.tsx' };
    }
    if (params.status === 'success' && params.includeResult) {
      t.result = 'export default fun\nction App() { ... }';
    }
    if (params.status === 'error' && params.includeError) {
      t.error = 'EACCES: permission denied';
    }
    return t;
  }, [
    params.desc,
    params.includeError,
    params.includeParams,
    params.includeResult,
    params.name,
    params.status,
  ]);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'status', {
      label: 'status',
      options: {
        pending: 'pending',
        running: 'running',
        success: 'success',
        error: 'error',
        cancelled: 'cancelled',
      },
    });
    pane.addBinding(params, 'defaultOpen', { label: 'defaultOpen' });
    pane.addBinding(params, 'name', { label: 'name' });
    pane.addBinding(params, 'desc', {
      label: 'description',
      multiline: true,
      rows: 2,
    });

    const toolFolder = pane.addFolder({ title: 'tool 数据' });
    toolFolder.addBinding(params, 'includeParams', { label: '含 params' });
    toolFolder.addBinding(params, 'includeResult', { label: '含 result（success）' });
    toolFolder.addBinding(params, 'includeError', { label: '含 error（error）' });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  const toolCodeLines = [
    `const tool: ToolCall = {`,
    `  id: 'pg',`,
    `  name: ${JSON.stringify(params.name)},`,
    `  description: ${JSON.stringify(params.desc)},`,
    `  status: '${params.status}',`,
  ];
  if (params.includeParams) {
    toolCodeLines.push(`  params: { path: 'src/App.tsx' },`);
  }
  if (params.status === 'success' && params.includeResult) {
    toolCodeLines.push(`  result: 'export default function App() { ... }',`);
  }
  if (params.status === 'error' && params.includeError) {
    toolCodeLines.push(`  error: 'EACCES: permission denied',`);
  }
  toolCodeLines.push(`};`);

  const codeLines = [
    `import { AgentStep, type ToolCall } from 'one-design-next';`,
    ``,
    ...toolCodeLines,
    ``,
    `<AgentStep tool={tool} defaultOpen={${params.defaultOpen}} />`,
  ];

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <div
          className=""
          style={{ minHeight: 200 }}
        >
          <AgentStep
            key={`${params.status}-${params.defaultOpen}-${params.includeParams}-${params.includeResult}-${params.includeError}`}
            tool={tool}
            defaultOpen={params.defaultOpen}
          />
        </div>
      </CodeBox>
      <CodeBlock>{codeLines.join('\n')}</CodeBlock>
    </div>
  );
};

export default Demo;
```
## 分组 {#group}

当多个工具快速调用并完成时，使用 `AgentStep.Group` 将它们合并为一个视觉块，避免逐条闪动。执行中显示「执行步骤中」+ 旋转图标，全部完成后显示「执行了 5 个步骤」，点击摘要可展开步骤列表。单条是否可再展开**仅由数据决定**：存在可展示的 `params` / `result` / `error` 时可展开，否则不出现展开（`cancelled` 始终不可展开）。

**示例：分组** — 多工具快速完成时的分组折叠

```tsx
'use client';

import { AgentStep, type ToolCall } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const TOOL_SEQUENCE: Omit<ToolCall, 'status'>[] = [
  { id: '1', name: '搜索代码', description: 'query="handleSubmit"', params: { query: 'handleSubmit' }, result: '找到 3 处匹配' },
  { id: '2', name: '读取文件', description: 'src/App.tsx', params: { path: 'src/App.tsx' }, result: 'export default function App() { ... }' },
  { id: '3', name: '读取文件', description: 'src/utils.ts', params: { path: 'src/utils.ts' }, result: 'export function validate() { ... }' },
  { id: '4', name: '检查类型', description: 'tsc --noEmit', params: { cmd: 'tsc --noEmit' }, result: '0 errors' },
  { id: '5', name: '运行测试', description: 'vitest run', params: { cmd: 'vitest run' }, result: 'Tests: 12 passed' },
];

function useSimulation() {
  const [tools, setTools] = useState<ToolCall[]>([]);
  const [started, setStarted] = useState(false);
  const timerRef = useRef<ReturnType<typeof setTimeout>>();
  const runningRef = useRef(false);

  const run = () => {
    if (runningRef.current) return;
    runningRef.current = true;
    setTools([]);
    setStarted(true);
    let i = 0;

    const next = () => {
      if (i >= TOOL_SEQUENCE.length) {
        runningRef.current = false;
        return;
      }
      const t = TOOL_SEQUENCE[i];
      setTools((prev) => [...prev, { ...t, status: 'running' }]);

      const delay = 200 + Math.random() * 400;
      timerRef.current = setTimeout(() => {
        setTools((prev) =>
          prev.map((p) => (p.id === t.id ? { ...p, status: 'success' } : p)),
        );
        i++;
        timerRef.current = setTimeout(next, 50 + Math.random() * 100);
      }, delay);
    };
    next();
  };

  const reset = () => {
    clearTimeout(timerRef.current);
    runningRef.current = false;
    setTools([]);
    setStarted(false);
  };

  useEffect(() => () => clearTimeout(timerRef.current), []);
  return { tools, started, run, reset };
}

const Demo = () => {
  const { tools, started, run, reset } = useSimulation();

  const code = `// expandWhileRunning: 执行中自动展开，完成后自动收起
// 用户手动点击后不再自动控制

<AgentStep.Group tools={tools} expandWhileRunning />`;

  return (
    <div>
      <CodeBox className="flex flex-col items-start gap-6 py-4 px-2">
        <div style={{ display: 'flex', gap: 8 }}>
          <button
            type="button"
            onClick={run}
            style={{
              padding: '4px 12px',
              fontSize: 13,
              borderRadius: 6,
              border: '1px solid var(--odn-color-black-4)',
              background: 'var(--odn-color-solid-black-1)',
              color: 'var(--odn-color-black-11)',
              cursor: 'pointer',
            }}
          >
            模拟 5 个工具快速调用
          </button>
          {started && (
            <button
              type="button"
              onClick={reset}
              style={{
                padding: '4px 12px',
                fontSize: 13,
                borderRadius: 6,
                border: '1px solid var(--odn-color-black-4)',
                background: 'var(--odn-color-solid-black-1)',
                color: 'var(--odn-color-black-9)',
                cursor: 'pointer',
              }}
            >
              重置
            </button>
          )}
        </div>
        <div style={{ minHeight: 40 }}>
          {started && <AgentStep.Group tools={tools} expandWhileRunning />}
        </div>
      </CodeBox>
      <CodeBlock>{code}</CodeBlock>
    </div>
  );
};

export default Demo;
```
## API {#api}

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| tool | 工具调用数据 | `ToolCall` | - |
| defaultOpen | 默认展开 | `boolean` | `false` |
| expandWhileRunning | 执行中自动展开、完成后自动收起 | `boolean` | `false` |
| onRetry | 重试回调 | `(toolId: string) => void` | - |
| isFirst | 是否第一步（隐藏上方连接线） | `boolean` | `true` |
| isLast | 是否最后一步（隐藏下方连接线） | `boolean` | `true` |

### AgentStep.Group {#group-api}

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| tools | 工具调用数据数组，可为空（Group 先于 tools 挂载） | `ToolCall[]` | - |
| runningLabel | 执行中显示的静态文案 | `ReactNode` | `执行步骤中` |
| doneLabel | 全部完成后的摘要文案 | `(count: number) => ReactNode` | `` `执行了 ${n} 个步骤` `` |
| collapse | 折叠模式：`auto` 全部完成后自动折叠；`always` 始终折叠；`never` 不折叠 | `'auto' \| 'always' \| 'never'` | `'auto'` |
| expandWhileRunning | 执行中自动展开、完成后自动收起（默认不自动） | `boolean` | `false` |
| onRetry | 重试回调 | `(toolId: string) => void` | - |

---

## 思考 AgentThink

## 基础用例 {#basic-usage}

**示例：基础用例** — 基础用例

```tsx
'use client';

import { AgentThink } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

const THINKING_CONTENTS: Record<string, string> = {
  short: '分析用户的问题。',
  medium:
    '用户想要优化项目目录结构。我需要先分析当前的结构，识别出潜在问题（如组件混放、缺少类型目录），然后给出分层建议。',
  long:
    '用户想要优化项目目录结构。我需要先分析当前的结构，识别出潜在问题（如组件混放、缺少类型目录），然后给出分层建议。\n\n首先看 src/ 下的文件分布：components/ 有 12 个文件，hooks/ 有 3 个，showcase/ 有 17 个。组件层偏平，没有按语义角色分组。\n\n建议分为三组：message/（StreamText、AgentStep、AgentThink）、input/（Composer、Suggestions）、session/（Welcome、ChatItem）。',
};

const Demo = () => {
  const [params, setParams] = useState({
    variant: 'block' as 'block' | 'inline',
    isThinking: false,
    defaultOpen: true,
    duration: 3200,
    preset: 'medium' as 'short' | 'medium' | 'long',
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  const content = THINKING_CONTENTS[params.preset];

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'variant', {
      label: 'variant',
      options: { block: 'block', inline: 'inline' },
    });
    pane.addBinding(params, 'isThinking', { label: 'isThinking' });
    pane.addBinding(params, 'defaultOpen', { label: 'defaultOpen' });
    pane.addBinding(params, 'duration', {
      label: 'duration (ms)',
      min: 500,
      max: 10000,
      step: 100,
    });
    pane.addBinding(params, 'preset', {
      label: '内容长度',
      options: { 短: 'short', 中: 'medium', 长: 'long' },
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  const codeLines: string[] = [
    `import { AgentThink } from 'one-design-next';`,
    ``,
    `<AgentThink`,
    `  content={${JSON.stringify(content)}}`,
  ];
  if (params.variant !== 'block') {
    codeLines.push(`  variant="${params.variant}"`);
  }
  if (params.variant === 'block') {
    codeLines.push(`  isThinking={${params.isThinking}}`);
    codeLines.push(`  duration={${params.duration}}`);
    codeLines.push(`  defaultOpen={${params.defaultOpen}}`);
  }
  codeLines.push(`/>`);

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <div
          className=""
          style={{ minHeight: 200 }}
        >
          <div className="w-full max-w-[400px]">
            {params.variant === 'inline' ? (
              <AgentThink
                key={`${params.variant}-${params.preset}`}
                variant="inline"
                content={content}
              />
            ) : (
              <AgentThink
                key={`${params.preset}-${params.isThinking}-${params.defaultOpen}`}
                content={content}
                isThinking={params.isThinking}
                duration={params.duration}
                defaultOpen={params.defaultOpen}
              />
            )}
          </div>
        </div>
      </CodeBox>
      <CodeBlock>{codeLines.join('\n')}</CodeBlock>
    </div>
  );
};

export default Demo;
```
## 动态思考过程 {#dynamic-thinking}

模拟真实场景下的思考过程：内容逐步流入、计时器实时计数、思考结束后自动折叠。

**示例：动态思考过程** — 模拟 AI 实时思考的完整 UI 流程

```tsx
'use client';

import { AgentThink } from 'one-design-next';
import React, { useCallback, useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';
import ThinkingIcon from '../ThinkingIcon';
import CircleIcon from '../CircleIcon';
import JellyTriangleIcon from '../JellyTriangleIcon';

const THINKING_SCRIPTS: Record<string, string[]> = {
  analysis: [
    '分析用户的问题…',
    '分析用户的问题…\n\n正在检查当前的项目结构和依赖关系。',
    '分析用户的问题…\n\n正在检查当前的项目结构和依赖关系。\n\nsrc/ 下有 12 个组件文件平铺在同一层级，缺少语义分组。',
    '分析用户的问题…\n\n正在检查当前的项目结构和依赖关系。\n\nsrc/ 下有 12 个组件文件平铺在同一层级，缺少语义分组。\n\n建议按角色分为三组：message/（StreamText、AgentStep）、input/（Composer、Suggestions）、session/（Welcome、ChatItem）。',
    '分析用户的问题…\n\n正在检查当前的项目结构和依赖关系。\n\nsrc/ 下有 12 个组件文件平铺在同一层级，缺少语义分组。\n\n建议按角色分为三组：message/（StreamText、AgentStep）、input/（Composer、Suggestions）、session/（Welcome、ChatItem）。\n\n检测到两处隐式耦合：CodeBlock 对 highlight.js 的全量引入，以及多个组件对 CSS 变量的直接引用。需要收敛到入口文件统一管理。',
  ],
  ad: [
    '正在加载投放数据…',
    '正在加载投放数据…\n\n读取 2026 Q1 三个版位的消耗和 eCPM 指标。',
    '正在加载投放数据…\n\n读取 2026 Q1 三个版位的消耗和 eCPM 指标。\n\n朋友圈信息流完成率 96.9%，视频号仅 63.0%，存在明显缺口。',
    '正在加载投放数据…\n\n读取 2026 Q1 三个版位的消耗和 eCPM 指标。\n\n朋友圈信息流完成率 96.9%，视频号仅 63.0%，存在明显缺口。\n\n定位到视频号消耗不足的三个原因：冷启动期过长（72h vs 24h）、出价模型偏保守、定向重叠率 87%。',
    '正在加载投放数据…\n\n读取 2026 Q1 三个版位的消耗和 eCPM 指标。\n\n朋友圈信息流完成率 96.9%，视频号仅 63.0%，存在明显缺口。\n\n定位到视频号消耗不足的三个原因：冷启动期过长（72h vs 24h）、出价模型偏保守、定向重叠率 87%。\n\n建议切换为 MAXIMIZE_CONVERSIONS 策略度过冷启动期，同时将 lookalike 扩展比例从 10% 降至 3%。预计 Q2 整体完成率可提升至 95% 以上。',
  ],
  short: [
    '让我想想…',
    '让我想想…\n\n好的，这个问题很简单。',
  ],
};

const ICON_MAP: Record<string, (size: number) => React.ReactNode> = {
  rays: (s) => <ThinkingIcon size={s} data-odn-agent-think-icon-active />,
  circle: (s) => <CircleIcon size={s} data-odn-agent-think-icon-active />,
  jelly: (s) => <JellyTriangleIcon size={s} speed={1.75} />,
};

type DemoParams = {
  preset: 'analysis' | 'ad' | 'short';
  speed: number;
  icon: string;
};

const Demo = () => {
  const [params, setParams] = useState<DemoParams>({
    preset: 'analysis',
    speed: 800,
    icon: 'rays',
  });

  const [isThinking, setIsThinking] = useState(false);
  const [content, setContent] = useState('');
  const [phase, setPhase] = useState<'idle' | 'thinking' | 'done'>('idle');
  const timerRef = useRef<ReturnType<typeof setTimeout>>();
  const stepRef = useRef(0);
  const paramsRef = useRef(params);
  paramsRef.current = params;

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  const stop = useCallback(() => {
    if (timerRef.current) clearTimeout(timerRef.current);
    setIsThinking(false);
    setPhase('done');
  }, []);

  const run = useCallback(() => {
    if (timerRef.current) clearTimeout(timerRef.current);
    stepRef.current = 0;
    const script = THINKING_SCRIPTS[paramsRef.current.preset];
    setContent(script[0]);
    setIsThinking(true);
    setPhase('thinking');

    const tick = () => {
      stepRef.current += 1;
      if (stepRef.current < script.length) {
        setContent(script[stepRef.current]);
        timerRef.current = setTimeout(tick, paramsRef.current.speed);
      } else {
        setIsThinking(false);
        setPhase('done');
      }
    };
    timerRef.current = setTimeout(tick, paramsRef.current.speed);
  }, []);

  useEffect(() => () => { if (timerRef.current) clearTimeout(timerRef.current) }, []);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'icon', {
      label: '动画图标',
      options: { '射线 Rays': 'rays', '圆环 Circle': 'circle', '果冻 Jelly': 'jelly' },
    });
    pane.addBinding(params, 'preset', {
      label: '场景',
      options: { '项目分析': 'analysis', '广告诊断': 'ad', '短思考': 'short' },
    });
    pane.addBinding(params, 'speed', {
      label: '步进间隔 (ms)',
      min: 200,
      max: 2000,
      step: 100,
    });

    const runBtn = pane.addButton({ title: '▶ 开始思考' });
    runBtn.on('click', run);

    const stopBtn = pane.addButton({ title: '⏹ 结束思考' });
    stopBtn.on('click', stop);

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => pane.dispose();
  }, []);

  const iconNode = ICON_MAP[params.icon]?.(14);

  const codeLines = [
    `import { AgentThink } from 'one-design-next';`,
    ``,
    `<AgentThink`,
    `  content={content}`,
    `  isThinking={isThinking}`,
    params.icon !== 'rays' ? `  icon={<${params.icon === 'circle' ? 'CircleIcon' : 'JellyTriangleIcon'} size={14} />}` : null,
    `/>`,
  ].filter(Boolean);

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <div className="w-full px-4" style={{ minHeight: 120 }}>
          {phase === 'idle' ? (
            <div
              className="py-8"
              style={{ color: 'var(--odn-color-black-6)', fontSize: 14 }}
            >
              点击「开始思考」查看动态效果
            </div>
          ) : (
            <AgentThink
              key={`${phase}-${params.icon}-${phase === 'done' ? content.length : ''}`}
              content={content}
              isThinking={isThinking}
              defaultOpen
              icon={iconNode}
            />
          )}
        </div>
      </CodeBox>
      <CodeBlock>{codeLines.join('\n')}</CodeBlock>
    </div>
  );
};

export default Demo;
```
## 图标动画调试 {#icon-tuner}

调整思考图标的 3D 旋转参数和时序参数，实时预览动画效果。

**示例：图标动画调试** — 通过滑块调整 X / Y / Z 轴旋转、周期、射线间隔等参数

```tsx
'use client';

import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';
import ThinkingIcon from '../ThinkingIcon';
import CircleIcon from '../CircleIcon';
import JellyTriangleIcon from '../JellyTriangleIcon';

type IconType = 'rays' | 'circle' | 'jelly';

type TunerParams = {
  icon: IconType;
  rotateX: number;
  rotateY: number;
  rotateZ: number;
  duration: number;
  stagger: number;
  iconSize: number;
  perspective: number;
  arcRatio: number;
  drawSpeed: number;
};

const Demo = () => {
  const [params, setParams] = useState<TunerParams>({
    icon: 'rays',
    rotateX: 0,
    rotateY: 0,
    rotateZ: 360,
    duration: 2.4,
    stagger: 0.1,
    iconSize: 120,
    perspective: 800,
    arcRatio: 0.7,
    drawSpeed: 1.5,
  });
  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'icon', {
      label: '图标',
      options: { '射线 Rays': 'rays', '圆环 Circle': 'circle', '果冻 Jelly': 'jelly' },
    });

    const f1 = pane.addFolder({ title: '旋转 (度/周期)' });
    f1.addBinding(params, 'rotateX', { label: 'X 轴', min: -720, max: 720, step: 5 });
    f1.addBinding(params, 'rotateY', { label: 'Y 轴', min: -720, max: 720, step: 5 });
    f1.addBinding(params, 'rotateZ', { label: 'Z 轴', min: -720, max: 720, step: 5 });
    f1.addBinding(params, 'perspective', { label: '透视距离', min: 100, max: 2000, step: 50 });

    const f2 = pane.addFolder({ title: '时序' });
    f2.addBinding(params, 'duration', { label: '周期 (s)', min: 0.5, max: 6, step: 0.1 });
    f2.addBinding(params, 'stagger', { label: '射线间隔 (s)', min: 0.02, max: 0.4, step: 0.01 });

    const f3 = pane.addFolder({ title: '圆环参数' });
    f3.addBinding(params, 'arcRatio', { label: '弧长比例', min: 0.05, max: 0.95, step: 0.05 });
    f3.addBinding(params, 'drawSpeed', { label: '描边速度 (s)', min: 0.3, max: 4, step: 0.1 });

    const f4 = pane.addFolder({ title: '显示' });
    f4.addBinding(params, 'iconSize', { label: '图标大小', min: 32, max: 240, step: 4 });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => pane.dispose();
  }, []);

  const circumference = 2 * Math.PI * 7;

  const style = {
    '--ti-rx': `${params.rotateX}deg`,
    '--ti-ry': `${params.rotateY}deg`,
    '--ti-rz': `${params.rotateZ}deg`,
    '--ti-duration': `${params.duration}s`,
    '--ti-stagger': `${params.stagger}s`,
    '--ti-perspective': `${params.perspective}px`,
    '--ti-circumference': circumference,
    '--ti-arc-offset': circumference * params.arcRatio,
    '--ti-draw-speed': `${params.drawSpeed}s`,
  } as React.CSSProperties;

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <div
          className="flex items-center justify-center"
          style={{ minHeight: 280, perspective: params.perspective }}
        >
          <div style={style} data-odn-thinking-tuner>
            {params.icon === 'rays' && (
              <ThinkingIcon size={params.iconSize} />
            )}
            {params.icon === 'circle' && (
              <CircleIcon size={params.iconSize} />
            )}
            {params.icon === 'jelly' && (
              <JellyTriangleIcon size={params.iconSize} speed={params.duration} />
            )}
          </div>
        </div>
      </CodeBox>
      <style>{`
        [data-odn-thinking-tuner] [data-odn-thinking-icon] {
          color: var(--odn-color-black-9);
        }
        ${Array.from({ length: 5 }, (_, i) => {
          const idx = i + 1
          const a0 = i * 4
          const a1 = a0 + 8
          const d0 = 50 + (5 - idx) * 4
          const d1 = d0 + 12
          return `
            @keyframes ti-tuner-ray-${idx} {
              0%      { opacity: 0; transform: scale(0); }
              ${a0}%  { opacity: 0; transform: scale(0); }
              ${a1}%  { opacity: 1; transform: scale(1); }
              ${d0}%  { opacity: 1; transform: scale(1); }
              ${d1}%  { opacity: 0; transform: scale(0); }
              100%    { opacity: 0; transform: scale(0); }
            }
            [data-odn-thinking-tuner] [data-odn-thinking-ray="${idx}"] {
              animation: ti-tuner-ray-${idx} var(--ti-duration) ease-out infinite !important;
            }
          `
        }).join('')}

        [data-odn-thinking-tuner] [data-odn-circle-icon] {
          animation: ti-tuner-spiral var(--ti-duration) linear infinite !important;
          color: var(--odn-color-black-9);
        }
        [data-odn-thinking-tuner] [data-odn-circle-track] {
          opacity: 0;
        }
        [data-odn-thinking-tuner] [data-odn-circle-arc] {
          stroke-dasharray: var(--ti-circumference);
          stroke-dashoffset: var(--ti-arc-offset);
          animation: ti-tuner-circle-draw var(--ti-draw-speed) ease-in-out infinite !important;
        }
        @keyframes ti-tuner-circle-draw {
          0% { stroke-dashoffset: var(--ti-circumference); }
          50% { stroke-dashoffset: var(--ti-arc-offset); }
          100% { stroke-dashoffset: var(--ti-circumference); }
        }
      `}</style>
    </div>
  );
};

export default Demo;
```
## API {#api}

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| content | 思考内容文本 | `string` | - |
| isThinking | 是否正在思考 | `boolean` | `false` |
| duration | 思考耗时（ms） | `number` | - |
| defaultOpen | 默认展开 | `boolean` | - |
| variant | 变体 | `'block' \| 'inline'` | `'block'` |
| icon | 自定义思考中图标（仅 block 变体生效） | `React.ReactNode` | - |

---

## 附件 Attachments

## 基础用例 {#basic-usage}

**示例：基础用例** — 基础用例

```tsx
'use client';

import {
  Attachments,
  type Attachment,
} from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

const ATTACHMENTS: Attachment[] = [
  {
    variant: 'report',
    name: 'Lululemon新年款男士夹克小红书种草文案',
    type: 'application/report',
    createdAt: '03-09 15:46',
  },
  {
    name: 'screenshot.png',
    type: 'image/png',
    url: 'https://placehold.co/200x150/f4f4f5/71717a?text=Screenshot',
  },
  { name: 'report.pdf', type: 'application/pdf', size: 245760 },
  { name: 'data.csv', type: 'text/csv', size: 12800 },
];

const Demo = () => {
  const [params, setParams] = useState({
    compact: false,
    showRemove: true,
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'compact', { label: 'compact' });
    pane.addBinding(params, 'showRemove', { label: 'onRemove' });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  const attachmentsJson = JSON.stringify(ATTACHMENTS, null, 2);

  const codeLines: string[] = [
    `import { Attachments, type Attachment } from 'one-design-next';`,
    ``,
    `const attachments: Attachment[] = ${attachmentsJson};`,
    ``,
    `<Attachments`,
    `  attachments={attachments}`,
    `  compact={${params.compact}}`,
  ];
  if (params.showRemove) {
    codeLines.push(`  onRemove={(index) => {}}`);
  }
  codeLines.push(`/>`);

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <div
          className=""
          style={{ minHeight: 200 }}
        >
          <Attachments
            attachments={ATTACHMENTS}
            compact={params.compact}
            onRemove={params.showRemove ? () => {} : undefined}
            onFileClick={() => {}}
            onDownload={() => {}}
          />
        </div>
      </CodeBox>
      <CodeBlock>{codeLines.join('\n')}</CodeBlock>
    </div>
  );
};

export default Demo;
```
## API {#api}

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| attachments | 附件列表 | `Attachment[]` | - |
| onRemove | 删除回调 | `(index: number) => void` | - |
| onFileClick | 点击文件回调 | `(attachment: Attachment) => void` | - |
| onDownload | 下载回调（`report` 变体 hover 时显示） | `(attachment: Attachment) => void` | - |
| compact | 紧凑模式（仅显示文件名） | `boolean` | `false` |

---

## 对话项 ChatItem

## 基础用例 {#basic-usage}

**示例：基础用例** — 基础用例

```tsx
'use client';

import { ChatItem } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

const Demo = () => {
  const [params, setParams] = useState({
    title: '项目架构设计',
    active: true,
    status: 'none' as 'none' | 'generating' | 'unread',
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'title', { label: 'title' });
    pane.addBinding(params, 'active', { label: 'active' });
    pane.addBinding(params, 'status', {
      label: 'status',
      options: { 无: 'none', generating: 'generating', unread: 'unread' },
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  const statusProp =
    params.status === 'none' ? undefined : params.status;

  const codeLines: string[] = [
    `import { ChatItem } from 'one-design-next';`,
    ``,
    `<ChatItem`,
    `  id="pg"`,
    `  title={${JSON.stringify(params.title)}}`,
    `  active={${params.active}}`,
  ];
  if (statusProp) {
    codeLines.push(`  status="${statusProp}"`);
  }
  codeLines.push(`  onClick={() => {}}`);
  codeLines.push(`  onRename={() => {}}`);
  codeLines.push(`  onDelete={() => {}}`);
  codeLines.push(`/>`);

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <div
          className=""
          style={{ minHeight: 160 }}
        >
          <div className="w-[280px]">
            <ChatItem
              id="pg"
              title={params.title}
              active={params.active}
              status={statusProp}
              onClick={() => {}}
              onRename={() => {}}
              onDelete={() => {}}
            />
          </div>
        </div>
      </CodeBox>
      <CodeBlock>{codeLines.join('\n')}</CodeBlock>
    </div>
  );
};

export default Demo;
```
## API {#api}

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| id | 唯一标识 | `string` | - |
| title | 标题 | `string` | - |
| active | 是否选中 | `boolean` | - |
| status | 状态指示 | `'generating' \| 'unread'` | - |
| onClick | 点击回调 | `(id: string) => void` | - |
| onRename | 重命名回调 | `(id: string, newTitle: string) => void` | - |
| onDelete | 删除回调 | `(id: string) => void` | - |
| actionMenuZIndex | 行内菜单层级（避免被父层遮挡） | `number \| string` | - |

---

## 编排栏 Composer

## 基础用例 {#basic-usage}

**示例：基础用例** — 基础用例

```tsx
'use client';

import type { SkillItem, ComposerRef } from 'one-design-next';
import { Composer } from 'one-design-next';
import React, { useEffect, useMemo, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

const SKILLS: SkillItem[] = [
  {
    id: 'code',
    label: '代码解释',
    icon: 'code',
    description: '逐行解读代码逻辑',
  },
  {
    id: 'summary',
    label: '内容总结',
    icon: 'file-text',
    description: '提炼长文关键信息',
  },
  {
    id: 'trans',
    label: '多语翻译',
    icon: 'languages',
    description: '在多种语言间互译',
  },
  {
    id: 'data',
    label: '数据分析',
    icon: 'layers',
    description: '解析数据趋势与洞察',
  },
];

const Demo = () => {
  const [params, setParams] = useState({
    variant: 'full' as 'full' | 'lite',
    toolsLabeled: true,
    attachment: true,
    webSearch: true,
    skill: true,
    isGenerating: false,
    submitType: 'enter' as 'enter' | 'shiftEnter',
    placeholder: '发送消息…',
    hint: true,
  });
  const [log, setLog] = useState<string[]>([]);
  const [inputValue, setInputValue] = useState('');

  const composerRef = useRef<ComposerRef>(null);
  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    const variantBinding = pane.addBinding(params, 'variant', {
      label: 'variant',
      options: { full: 'full', lite: 'lite' },
    });
    const toolsLabeledBinding = pane.addBinding(params, 'toolsLabeled', {
      label: 'toolsLabeled',
      disabled: params.variant === 'lite',
    });

    const toolsFolder = pane.addFolder({ title: 'tools', expanded: true });
    toolsFolder.addBinding(params, 'attachment', { label: 'attachment' });
    toolsFolder.addBinding(params, 'webSearch', { label: 'webSearch' });
    toolsFolder.addBinding(params, 'skill', { label: 'skill' });

    pane.addBinding(params, 'isGenerating', { label: 'isGenerating' });
    pane.addBinding(params, 'submitType', {
      label: 'submitType',
      options: { enter: 'enter', shiftEnter: 'shiftEnter' },
    });
    pane.addBinding(params, 'hint', { label: 'hint' });
    pane.addBinding(params, 'placeholder', {
      label: 'placeholder',
      multiline: true,
      rows: 2,
    });

    // variant 改变时同步 toolsLabeled 的禁用态
    variantBinding.on('change', (ev) => {
      toolsLabeledBinding.disabled = ev.value === 'lite';
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  const tools = useMemo(() => {
    const list: ('attachment' | 'webSearch' | 'skill')[] = [];
    if (params.attachment) list.push('attachment');
    if (params.webSearch) list.push('webSearch');
    if (params.skill) list.push('skill');
    return list;
  }, [params.attachment, params.webSearch, params.skill]);

  const codeLines: string[] = [
    `import { Composer } from 'one-design-next';`,
    ``,
    `<Composer`,
    `  variant="${params.variant}"`,
    `  tools={${JSON.stringify(tools)}}`,
    `  toolsLabeled={${params.toolsLabeled}}`,
    `  onSend={(text) => {}}`,
    `  onStop={() => {}}`,
    `  isGenerating={${params.isGenerating}}`,
    `  submitType="${params.submitType}"`,
    `  placeholder={${JSON.stringify(params.placeholder)}}`,
    `  hint={${params.hint}}`,
  ];
  if (params.skill) codeLines.push(`  skills={SKILLS}`);
  codeLines.push(`/>`);

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <Composer
          ref={composerRef}
          className="w-full max-w-[560px]"
          variant={params.variant}
          tools={tools}
          toolsLabeled={params.toolsLabeled}
          skills={params.skill ? SKILLS : undefined}
          value={inputValue}
          onChange={setInputValue}
          onSend={(t) => {
            console.log('[yijie] onSend', t);
            setLog((p) => [...p, t]);
            setInputValue('');
          }}
          onStop={() => {
            console.log('[yijie] onStop');
            setParams((p) => ({ ...p, isGenerating: false }));
          }}
          isGenerating={params.isGenerating}
          submitType={params.submitType}
          placeholder={params.placeholder}
          hint={params.hint}
        />
        {log.length > 0 && (
          <div
            className="flex w-full max-w-[560px] flex-col gap-1 text-xs"
            style={{ color: 'var(--odn-color-black-8)' }}
          >
            <span>最近发送（最多 5 条）</span>
            {log.slice(-5).map((t, i) => (
              <div key={i} className="truncate">
                {t}
              </div>
            ))}
          </div>
        )}
      </CodeBox>
      <CodeBlock>{codeLines.join('\n')}</CodeBlock>
    </div>
  );
};

export default Demo;
```
## API {#api}

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| value | 输入框受控值 | `string` | - |
| defaultValue | 输入框非受控默认值 | `string` | `''` |
| onChange | 输入框值变化回调 | `(value: string) => void` | - |
| onSend | 发送回调 | `(text: string, meta?: SendMeta) => void` | - |
| onStop | 停止生成回调 | `() => void` | - |
| isGenerating | 是否正在生成 | `boolean` | `false` |
| placeholder | 占位文本 | `string` | `'发送消息…'` |
| variant | 形态：`full` 常规两段式；`lite` 单行紧凑（多行自动升格，清空后复位） | `'full' \| 'lite'` | `'full'` |
| tools | 左下工具按钮集合，按数组顺序展示；`variant='lite'` 时仅取第一个（多余的会被忽略并在开发期 warn） | `Array<'attachment' \| 'webSearch' \| 'skill'>` | `['attachment', 'webSearch', 'skill']` |
| toolsLabeled | 工具按钮是否显示文字 label；`variant='lite'` 且未升格时强制仅图标 | `boolean` | `true` |
| skills | 技能列表，当 `tools` 包含 `'skill'` 时生效 | `SkillItem[]` | - |
| submitType | 提交模式：`enter` 为 Enter 发送，`shiftEnter` 为 Shift+Enter 发送 | `'enter' \| 'shiftEnter'` | `'enter'` |
| onEnter | 按下 Enter 时回调，返回 `false` 可阻止默认发送 | `(e: React.KeyboardEvent<HTMLTextAreaElement>) => void \| false` | - |
| hint | 是否显示底部快捷键提示 | `boolean` | `true` |
| spacing | 根节点外边距（drawer 模式内嵌用） | `'default' \| 'drawer'` | `'default'` |

---

## 预览面板 PreviewPanel

## 基础用例 {#basic-usage}

**示例：基础用例** — 多标签预览面板，支持 HTML 渲染和纯文本展示

```tsx
'use client';

import { PreviewPanel, type PreviewTab } from 'one-design-next';
import React, { useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const SAMPLE_HTML = `<!DOCTYPE html>
<html><head><style>
  body { font-family: system-ui; padding: 24px; color: #333; }
  h1 { color: #296bef; }
  .card { border: 1px solid #e5e7eb; border-radius: 8px; padding: 16px; margin: 12px 0; }
</style></head><body>
  <h1>分析报告</h1>
  <div class="card"><strong>指标 A</strong><p>同比增长 12.5%</p></div>
  <div class="card"><strong>指标 B</strong><p>环比下降 3.2%</p></div>
</body></html>`;

const SAMPLE_JSON = JSON.stringify(
  { model: 'gpt-4', tokens: 1024, temperature: 0.7, result: 'success' },
  null,
  2,
);

const SAMPLE_MD = `# README

## 安装

\`\`\`bash
npm install one-design-next
\`\`\`

## 使用

引入组件即可开始使用。
`;

const INIT_TABS: PreviewTab[] = [
  { id: 'report', name: 'report.html', content: SAMPLE_HTML, type: 'text/html' },
  { id: 'config', name: 'config.json', content: SAMPLE_JSON, type: 'application/json' },
  { id: 'readme', name: 'README.md', content: SAMPLE_MD, type: 'text/markdown' },
];

const Demo = () => {
  const [tabs, setTabs] = useState<PreviewTab[]>(INIT_TABS);
  const [activeTabId, setActiveTabId] = useState<string | null>('report');

  const handleTabClose = (id: string) => {
    const next = tabs.filter((t) => t.id !== id);
    setTabs(next);
    if (activeTabId === id) {
      setActiveTabId(next[0]?.id ?? null);
    }
  };

  const handleCloseAll = () => {
    setTabs([]);
    setActiveTabId(null);
  };

  const handleReset = () => {
    setTabs(INIT_TABS);
    setActiveTabId('report');
  };

  const handleDownload = (tab: PreviewTab) => {
    const blob = new Blob([tab.content], { type: tab.type || 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = tab.name;
    a.click();
    URL.revokeObjectURL(url);
  };

  const codeLines = [
    `import { PreviewPanel, type PreviewTab } from 'one-design-next';`,
    ``,
    `<PreviewPanel`,
    `  tabs={tabs}`,
    `  activeTabId={activeTabId}`,
    `  onTabChange={setActiveTabId}`,
    `  onTabClose={handleTabClose}`,
    `  onCloseAll={handleCloseAll}`,
    `  onDownload={handleDownload}`,
    `/>`,
  ];

  return (
    <div>
      <CodeBox className="flex flex-col" style={{ minHeight: 480 }}>
        <div className="flex flex-1 min-h-0" style={{ height: 440 }}>
          <div className="flex-1 min-w-0 flex flex-col justify-center gap-4 p-6 text-sm text-neutral-500">
            {tabs.length === 0 ? (
              <>
                所有标签已关闭
                <button
                  onClick={handleReset}
                  className="px-3 py-1 text-xs rounded border border-neutral-300 hover:border-neutral-400 transition-colors"
                >
                  重置
                </button>
              </>
            ) : (
              <span className="text-neutral-400">← 左侧主内容区</span>
            )}
          </div>
          <PreviewPanel
            tabs={tabs}
            activeTabId={activeTabId}
            onTabChange={setActiveTabId}
            onTabClose={handleTabClose}
            onCloseAll={handleCloseAll}
            onDownload={handleDownload}
          />
        </div>
      </CodeBox>
      <CodeBlock>{codeLines.join('\n')}</CodeBlock>
    </div>
  );
};

export default Demo;
```
## API {#api}

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| tabs | 标签页列表 | `PreviewTab[]` | - |
| activeTabId | 当前激活的标签 ID | `string \| null` | - |
| onTabChange | 切换标签回调 | `(id: string) => void` | - |
| onTabClose | 关闭标签回调 | `(id: string) => void` | - |
| onCloseAll | 关闭所有标签回调 | `() => void` | - |
| onDownload | 下载当前激活标签。传入时 header 右侧渲染下载按钮 | `(tab: PreviewTab) => void` | - |
| open | 是否展开。不传时默认按 `tabs.length > 0` 推断；显式传 `true` 且 tabs 为空时渲染空态 | `boolean` | - |
| emptyTitle | 空态标题（tabs 为空且 `open=true` 时展示） | `React.ReactNode` | `'暂无附件'` |
| emptyDescription | 空态说明文案 | `React.ReactNode` | `'对话生成的附件会显示在这里'` |
| widthMode | 宽度模式 | `'half' \| 'fill'` | `'half'` |

### PreviewTab

| 属性 | 说明 | 类型 |
| --- | --- | --- |
| id | 唯一标识 | `string` |
| name | 标签显示名称 | `string` |
| content | 内容字符串 | `string` |
| type | MIME 类型，`text/html` 时使用 iframe 渲染 | `string` |

---

## 技能位 SkillSlot

## 基础用例 {#basic-usage}

**示例：基础用例** — 切换 variant 查看三种形态

```tsx
'use client';

import { SkillSlot } from 'one-design-next';
import type { SkillItem } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

const SKILLS: SkillItem[] = [
  { id: 'code', label: '代码解释', icon: 'code', description: '逐行解读代码逻辑' },
  { id: 'summary', label: '内容总结', icon: 'file-text', description: '提炼长文关键信息' },
  { id: 'trans', label: '多语翻译', icon: 'languages', description: '在多种语言间互译' },
  { id: 'data', label: '数据分析', icon: 'layers', description: '解析数据趋势与洞察' },
];

const Demo = () => {
  const [params, setParams] = useState({ variant: 'bar' as 'menu' | 'bar' | 'card' });
  const [selected, setSelected] = useState<string | null>(null);

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'variant', {
      label: 'variant',
      options: { menu: 'menu', bar: 'bar', card: 'card' },
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  const codeLines: string[] = [
    `import { SkillSlot } from 'one-design-next';`,
    ``,
    `<SkillSlot`,
    `  variant="${params.variant}"`,
    `  skills={skills}`,
    `  value={selected}`,
    `  onSelect={(skill) => setSelected(skill.id)}`,
    `/>`,
  ];

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <div
          className="flex flex-col gap-4"
          style={{ minHeight: 200 }}
        >
          <div style={{ width: params.variant === 'card' ? 480 : undefined }}>
            <SkillSlot
              variant={params.variant}
              skills={SKILLS}
              value={selected}
              onSelect={(skill) => setSelected(prev => prev === skill.id ? null : skill.id)}
            />
          </div>
          {selected && (
            <div className="text-xs" style={{ color: 'var(--odn-color-black-8)' }}>
              选中: {SKILLS.find((s) => s.id === selected)?.label}
            </div>
          )}
        </div>
      </CodeBox>
      <CodeBlock>{codeLines.join('\n')}</CodeBlock>
    </div>
  );
};

export default Demo;
```
## API {#api}

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| skills | 技能列表 | `SkillItem[]` | - |
| variant | 展示形态 | `'menu' \| 'bar' \| 'card'` | `'bar'` |
| value | 当前选中的 skill id | `string \| null` | - |
| onSelect | 点击技能回调 | `(skill: SkillItem) => void` | - |
| className | 自定义类名 | `string` | - |
| style | 自定义样式 | `React.CSSProperties` | - |

### SkillItem

| 属性 | 说明 | 类型 |
| --- | --- | --- |
| id | 唯一标识 | `string` |
| label | 显示名称 | `string` |
| icon | 图标名称 | `string` |
| description | 描述文案（card 形态下显示） | `string` |

---

## 引用源 Sources

## 基础用例 {#basic-usage}

**示例：基础用例** — 基础用例

```tsx
'use client';

import { Sources, type Source } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

const ALL_SOURCES: Source[] = [
  {
    title: 'React 文档 — useEffect',
    url: 'https://react.dev/reference/react/useEffect',
    description: '官方文档中关于 useEffect 的完整指南',
  },
  {
    title: 'Tailwind CSS v4 迁移指南',
    url: 'https://tailwindcss.com/docs/upgrade-guide',
    description: '从 v3 迁移到 v4 的注意事项',
  },
  { title: 'MDN — CSS Cascade Layers', url: 'https://developer.mozilla.org/en-US/docs/Web/CSS/@layer' },
  { title: 'Vite 官方文档', url: 'https://vitejs.dev', description: '下一代前端构建工具' },
  {
    title: 'TypeScript Handbook',
    url: 'https://www.typescriptlang.org/docs/handbook/',
    description: 'TypeScript 完整手册',
  },
];

const Demo = () => {
  const [params, setParams] = useState({
    count: 3,
    defaultOpen: true,
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  const sources = ALL_SOURCES.slice(0, params.count);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'count', {
      label: '来源数量',
      min: 1,
      max: 5,
      step: 1,
    });
    pane.addBinding(params, 'defaultOpen', { label: 'defaultOpen' });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  const sourcesJson = JSON.stringify(sources, null, 2);

  const codeLines: string[] = [
    `import { Sources, type Source } from 'one-design-next';`,
    ``,
    `const sources: Source[] = ${sourcesJson};`,
    ``,
    `<Sources sources={sources} defaultOpen={${params.defaultOpen}} />`,
  ];

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <div
          className=""
          style={{ minHeight: 200 }}
        >
          <div className="w-full max-w-[400px]">
            <Sources
              key={`${params.count}-${params.defaultOpen}`}
              sources={sources}
              defaultOpen={params.defaultOpen}
            />
          </div>
        </div>
      </CodeBox>
      <CodeBlock>{codeLines.join('\n')}</CodeBlock>
    </div>
  );
};

export default Demo;
```
## API {#api}

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| sources | 来源列表 | `Source[]` | - |
| defaultOpen | 默认展开 | `boolean` | `false` |
| onUrlClick | 链接点击回调 | `(url: string, title?: string) => void` | - |

---

## 流式文本 StreamText

## 基础用例 {#basic-usage}

**示例：基础用例** — 基础用例

```tsx
'use client';

import { StreamText, Icon } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

/* ---- Preset contents ---- */

const MD_C1 = `# 项目结构审查报告

项目结构分析完成。我从**目录组织**、**依赖关系**、**组件分层**、**公共逻辑复用**和**构建产物**五个维度进行了完整审查，以下是详细的分析报告和优化建议。

## 1. 目录组织：从扁平到语义分组

当前 \`src/components/\` 下有 12 个文件平铺在同一层级。当组件数量超过 10 个时，**扁平结构的认知负担会急剧上升**——开发者需要在脑中对组件进行分类才能找到目标文件。

建议按**语义角色**重新分组：

\`\`\`
components/
├── message/     # 消息流相关：StreamText, AgentStep, AgentThink, ErrorBlock
├── input/       # 输入相关：Composer, Suggestions, Attachments
└── session/     # 会话管理：Welcome, ChatItem, ScrollToBottom
\`\`\`

分组的核心原则是**按用户心智模型划分，而非按技术实现**。用户感知到的是「消息」「输入」「会话」三个区域，目录结构应该映射这个心智模型。这样做的好处是：新成员加入时，**不需要阅读代码就能猜到每个组件的大致职责**。

## 2. 依赖关系：健康但存在隐式耦合

依赖分析显示**无循环依赖**，这是好消息。但有两处值得注意的**隐式耦合**：

- **类型穿透**：\`StreamText\` 直接导入了 \`CodeBlock\`，而 \`CodeBlock\` 只在消息渲染场景中使用
- **样式令牌泄露**：多个组件直接引用 CSS 变量（如 \`var(--color-accent)\`），但 \`atoms/\` 中的 \`CodeBlock\` 还额外依赖了 \`highlight.js\` 的主题样式表
- **隐式上下文依赖**：部分 hook 假设了特定的 Provider 包裹顺序，未做防御性检查

建议的修复优先级：

1. 将**外部样式依赖收敛到入口文件**，避免原子组件携带全局副作用
2. 通过 **slot 模式**将代码块渲染器作为 prop 传入，而非硬编码导入
3. 为 Context 消费添加 **fallback 默认值**，消除对 Provider 顺序的隐式假设

## 3. Headless + 皮肤：分层架构的关键决策

当前 \`hooks/\` 和 \`components/\` 的分离做得很好。7 个自定义 hook 封装了**完整的交互逻辑**（消息列表滚动、流式文本控制、工具调用状态机等），组件层只负责渲染。这种分离是渐进式的，不需要一步到位。

建议进一步明确这个分层的**契约边界**：

- \`hooks/\` → **核心逻辑层**，零 UI 依赖，接口稳定，可独立发包为 \`@genui/headless\`
- \`components/\` → **默认皮肤**，可被团队整体替换为自定义实现
  - 消息组件：\`StreamText\`、\`AgentStep\`、\`AgentThink\`
  - 输入组件：\`Composer\`、\`Suggestions\`
- \`atoms/\` → **私有原语**，不对外导出，仅服务于默认皮肤

这种分层的价值在于：当产品需要**深度定制 UI**（比如嵌入到不同的设计系统中）时，只需要替换皮肤层，逻辑层完全复用。**Headless 架构的核心承诺是：换皮不换脑**。更多信息参考 [Radix UI 设计理念](https://www.radix-ui.com/primitives) 和 [React Aria 文档](https://react-spectrum.adobe.com/react-aria/)。

### 契约边界的判定原则

#### 何时拆分为独立层

一个模块如果同时承担了**状态管理**和**视图渲染**两个职责，就应该拆分。判断标准：如果把 UI 框架从 React 换成 Vue，有多少代码可以直接复用——能复用的部分就是 headless 层。

#### 接口稳定性保障

headless 层的 API 变更必须遵循语义化版本，breaking change 需要提供 codemod 迁移脚本。皮肤层的变更则相对自由，因为它只影响视觉表现。

## 4. 公共逻辑复用：识别可提取的 Utilities

代码中有几处**重复模式**值得提取为公共工具函数：

| 模式 | 出现位置 | 建议 |
|------|----------|------|
| 文件类型格式化 | Attachments, FilePreview | 已有 \`formatType\`，✅ |
| 时间格式化（Xs, Xm） | AgentThink, AgentStep | 可提取为 \`formatDuration\` |
| CSS 变量读取 | 多个组件 | 考虑 \`useThemeToken\` hook |
| 条件 className 拼接 | 全局 | 已使用 \`clsx\`，✅ |

其中 **\`formatDuration\`** 的优先级最高——目前 AgentThink 和 AgentStep 各自维护了独立的秒数计算逻辑，存在**微妙的行为差异**（四舍五入策略不同）。统一后能确保用户在同一界面中看到的时间格式完全一致。

示例实现：

\`\`\`typescript
export function formatDuration(ms: number): string {
  const seconds = Math.round(ms / 1000)
  if (seconds < 60) return \`\${seconds}s\`
  return \`\${Math.floor(seconds / 60)}m \${seconds % 60}s\`
}
\`\`\`

配置文件示例：

\`\`\`json
{
  "compilerOptions": {
    "target": "ES2022",
    "module": "ESNext",
    "strict": true
  }
}
\`\`\`

## 5. 构建产物与 Tree-shaking

当前构建产物为 **1.3MB**（gzip 后约 400KB），对于一个组件库 demo 来说偏大。主要原因是：

1. **\`highlight.js\` 全量引入**：CodeBlock 加载了完整的语言包。建议改为**按需注册语言**（typescript、python、json 三种覆盖 90% 场景），预计可减少约 200KB
2. **\`react-markdown\` + \`remark-gfm\`**：这两个包合计约 80KB，是必要依赖，无法优化
3. **Radix UI 组件**：AlertDialog 等组件 tree-shaking 良好，无需额外处理

建议的优化目标是将 gzip 后体积控制在 **300KB 以内**，主要通过 highlight.js 的按需加载实现。

> **总结**：架构健康度 ★★★★☆。核心分层（headless + 皮肤）设计良好，主要改进方向是**目录语义分组**、**隐式耦合治理**和**构建体积优化**。建议按优先级排序：目录重组（低风险高收益）→ 公共工具提取（中风险中收益）→ 构建优化（高收益但需回归测试）。`

const MD_SHOWCASE = `## 标题层级演示

### 三级标题

#### 四级标题

正文段落。这是一段普通文本，包含**加粗**和\`行内代码\`。正文字号 14px，行高 24px，段间距 8px。

### 列表

无序列表：

- 第一项内容
- 第二项内容，包含\`代码\`和**加粗**
- 第三项内容
  - 嵌套子项 A
  - 嵌套子项 B

有序列表：

1. 第一步：初始化项目
2. 第二步：安装依赖
3. 第三步：启动开发服务器

### 代码

行内代码：使用 \`npm install\` 安装，配置 \`vite.config.ts\`。

代码块：

\`\`\`typescript
interface ChatMessage {
  id: string
  role: 'user' | 'assistant'
  content: string
  thinking?: string
  isStreaming?: boolean
}
\`\`\`

\`\`\`python
def stream_response(prompt: str):
    for chunk in model.generate(prompt, stream=True):
        yield chunk.text
\`\`\`

### 引用与链接

> 这是一段引用文字。设计不是让事物看起来更好，而是让事物更好地工作。

链接示例：[GenUI 文档](https://example.com) 和 [React 官方文档](https://react.dev)。

### 表格

| 组件 | 层级 | 用途 |
|------|------|------|
| StreamText | Components | 流式 Markdown 渲染 |
| AgentThink | Components | 思考过程展示 |
| AgentStep | Components | Agent 执行步骤 |
| Composer | Blocks | 输入框 |

### 混合内容

以下是一段真实的 AI 回复风格内容：

项目结构分析完成，整体架构清晰。建议按**语义角色**分为三组：

1. \`message/\` — StreamText、AgentStep、AgentThink
2. \`input/\` — Composer、Suggestions
3. \`session/\` — Welcome、ChatItem

> 总结：架构健康度 ★★★★☆，主要改进方向是组件分组和原语收敛。`

const MD_AD = `# 2026 Q1 投放效果诊断报告

本次诊断覆盖了**朋友圈信息流**、**公众号底部**和**视频号信息流**三个版位，时间范围为 2026-01-01 至 2026-03-31。以下是完整分析和优化建议。

## 1. 核心指标概览

整体消耗完成率 **87.3%**，低于 KPI 目标 95%。主要拖累来自视频号版位——该版位 Q1 新开放竞价模式，冷启动阶段的 eCPM 波动较大。

| 版位 | 消耗 (万) | 目标 (万) | 完成率 | eCPM | CTR |
|------|----------|----------|--------|------|-----|
| 朋友圈信息流 | 1,842 | 1,900 | 96.9% | 58.3 | 1.82% |
| 公众号底部 | 623 | 700 | 89.0% | 22.7 | 0.94% |
| 视频号信息流 | 315 | 500 | 63.0% | 31.5 | 2.15% |

> 视频号 CTR 最高但消耗最低，说明问题不在素材质量而在**流量分配和出价策略**。

## 2. 归因分析：视频号消耗不足

通过对 \`ad_delivery_log\` 的聚合分析，定位到三个主要原因：

- **冷启动期过长**：新计划平均需要 72 小时才能通过学习期，远超朋友圈的 24 小时基准
- **出价模型偏保守**：当前使用 \`TARGET_CPA\` 模式，系统倾向于降低曝光来保证成本，导致预算消耗不完
- **定向重叠率高**：87% 的视频号计划与朋友圈计划共享了超过 60% 的人群包，内部竞争严重

### 出价策略对比

#### 当前 vs 建议

当前的 \`TARGET_CPA\` 策略在成熟版位表现良好，但在视频号这类处于放量阶段的版位上，**过早优化成本会扼杀探索空间**。建议切换为 \`MAXIMIZE_CONVERSIONS\` 策略度过冷启动期，待积累 200+ 转化样本后再回切。

#### 灰度方案

\`\`\`json
{
  "experiment_id": "vch_bid_strategy_0401",
  "control": { "strategy": "TARGET_CPA", "ratio": 0.3 },
  "treatment": { "strategy": "MAXIMIZE_CONVERSIONS", "ratio": 0.7 },
  "duration_days": 14,
  "success_metric": "cost_per_conversion"
}
\`\`\`

## 3. 人群包优化建议

当前人群包的构建逻辑如下：

\`\`\`
audience/
├── seed/          # 种子人群：一方转化数据
├── lookalike/     # 扩展人群：基于种子的相似扩展
└── exclusion/     # 排除人群：已转化、竞品员工
\`\`\`

问题在于 **lookalike 扩展比例过高**（设置为 10%，实际覆盖约 2,800 万人），导致人群过于泛化。建议：

1. 将扩展比例从 10% 降至 **3%**，预计覆盖约 840 万人
2. 引入**行为时效性权重**——近 7 天活跃用户的权重设为远期用户的 3 倍
3. 为视频号单独构建种子人群，避免与朋友圈共用一套 seed——两个版位的用户行为模式差异显著

## 4. 素材效率分析

Q1 共投放 **342 条素材**，其中跑量素材（消耗 > 1 万）仅 58 条，跑量率 **17.0%**。

| 素材类型 | 数量 | 跑量数 | 跑量率 | 平均 CTR |
|---------|------|--------|--------|---------|
| 横版视频 15s | 89 | 22 | 24.7% | 2.31% |
| 竖版视频 30s | 64 | 18 | 28.1% | 2.58% |
| 三图轮播 | 112 | 11 | 9.8% | 0.87% |
| 单图大卡 | 77 | 7 | 9.1% | 1.12% |

竖版视频的跑量率和 CTR 均为最高，建议将 Q2 的素材产能从当前的**图片为主**调整为**视频为主**，目标比例 7:3。

> 注意：三图轮播的 CTR 偏低不代表该形式失效——公众号底部版位仅支持图片素材，该版位的 eCPM 天花板本身较低。需要**按版位分别评估素材效率**，而非全局混算。

## 5. 下一步行动

1. 本周内完成视频号出价策略灰度实验的配置，参考上方 JSON 配置
2. 下周一前完成人群包拆分——视频号与朋友圈分别维护独立 seed
3. 4 月 15 日前与创意团队对齐 Q2 素材产能规划，将竖版视频占比提升至 70%

> **总结**：Q1 消耗缺口主要由视频号版位贡献，根因是出价策略与版位成熟度不匹配。通过灰度切换出价模式 + 人群包去重 + 素材结构调整，预计 Q2 可将整体完成率提升至 **95%** 以上。`

const MD_MENU_RESTRUCTURE = `试一下这段：

"如翼平台 2025 年规划重构的菜单结构如下：

![菜单结构图](https://dmp.gdtimg.com/aigc/knowledge/images/2026/04/238090e1c52248308a7daf0b1f65d59b.png)

| 一级菜单 | 二级菜单 | 三级菜单 | 功能描述 |
|----------|----------|----------|----------|
| **首页** | 首页 | - | 旗舰版：资产四维诊断；基础版：资产分布展示 |
| **洞察诊断** | **市场洞察** | 竞争格局 | 品牌在 AMS 的营销驾驶舱 |
| | | 搜索洞察 | 自定义搜索标签洞察 |
| | | 区域洞察 | 客源分布热力图、高价值 AOI 推荐 |
| | | 心智洞察 | 本品牌、竞品、行业人群心智分析 |
| | **品牌资产** | 人群资产 | 资产总量、Rx 量级及 benchmark 对比 |
| | | 资产流转 | 营销活动前后人群资产流转分析 |
| | | 域内传播 | 从曝光-种草-转化的资产诊断追踪 |
| | | 域外传播 | 腾讯域外内容场品牌影响度量 |
| **人群策略** | **推荐人群** | 行业优选 | 高潜行业消费者人群 |
| | | 兴趣精选 | 内容互动行为识别的兴趣人群 |
| | | 主题甄选 | 特定生活场景触发的需求群体 |
| | | AI 智选 | 混元大模型+广告大模型智能选人群 |
| | **自定义人群** | 新建人群 | 标签组合生成投放人群包 |
| | | 人群列表 | 历史人群包管理 |
| | | 人群画像 | 人群属性洞察辅助投放策略 |
| | **数据接入** | 数据接入 | 跳转 DN 平台数据接入 |
| **策略应用** | **触点策略** | 钜如翼 | 基于目标人群推荐腾讯视频 IP |
| | | 翼红人 | 从人群出发的科学达人营销 |
| **全域度量** | **结案复盘** | 营销复盘 | 5R 人群资产流转复盘分析 |
| | | 招商复盘 | 招商广告营销活动价值衡量 |

---

**重构亮点**：
- 原「内容洞察」模块内容并入「市场洞察」和「品牌资产」
- 新增「心智洞察」模块（心智榜单、竞品矩阵等）
- 新增「域内传播」「域外传播」模块
- 「人群策略」整合推荐人群和自定义人群功能
- 「策略应用」聚焦触点策略（钜如翼、翼红人）
- 「全域度量」统一收口复盘功能"`

const CONTENT_PRESETS: { value: string; label: string; content: string }[] = [
  { value: 'menu', label: '菜单结构重构（图+表）', content: MD_MENU_RESTRUCTURE },
  { value: 'ad', label: '投放效果诊断 (广告)', content: MD_AD },
  { value: 'c1', label: '项目结构分析 (工程)', content: MD_C1 },
  { value: 'showcase', label: '排版 Showcase', content: MD_SHOWCASE },
  { value: 'short', label: '短文本', content: '你好！这是一段简短的 AI 回复，包含**加粗**和`代码`。' },
  { value: 'code', label: '代码块', content: '以下是一个 React 组件示例：\n\n```tsx\nexport function Hello({ name }: { name: string }) {\n  return <h1>Hello, {name}!</h1>\n}\n```\n\n可以直接在项目中使用。' },
  { value: 'list', label: '列表', content: '项目架构建议：\n\n1. **组件层** — UI 原子和组合组件\n2. **Hook 层** — 状态逻辑和副作用\n3. **服务层** — API 调用和数据转换\n\n> 遵循单一职责原则，每层只关注一件事。' },
  { value: 'table', label: '表格', content: '| 指标 | 优化前 | 优化后 |\n|------|--------|--------|\n| FCP | 2.4s | 0.8s |\n| LCP | 4.1s | 1.2s |\n| CLS | 0.25 | 0.02 |' },
]

const PRESET_TWEAK_OPTIONS = Object.fromEntries(
  CONTENT_PRESETS.map((x) => [x.label, x.value]),
);

type DemoParams = {
  preset: string;
  isStreaming: boolean;
  simulate: boolean;
  speed: number;
};

const Demo = () => {
  const [panelVisible, setPanelVisible] = useState(true);
  const [params, setParams] = useState<DemoParams>({
    preset: 'ad',
    isStreaming: false,
    simulate: false,
    speed: 18,
  });
  const [runKey, setRunKey] = useState(0);
  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  const content =
    CONTENT_PRESETS.find((p) => p.value === params.preset)?.content ||
    MD_SHOWCASE;

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });
    pane.addBinding(params, 'preset', {
      label: '内容',
      options: PRESET_TWEAK_OPTIONS,
    });
    pane.addBinding(params, 'isStreaming', { label: 'isStreaming' });
    pane.addBinding(params, 'simulate', { label: 'simulate' });
    pane.addBinding(params, 'speed', {
      label: 'speed (ms)',
      min: 1,
      max: 80,
      step: 1,
    });
    pane
      .addButton({ title: '▶ 重新播放' })
      .on('click', () => setRunKey((k) => k + 1));

    pane.on('change', (ev) => {
      const key = (ev.target as { key?: string }).key;
      setParams((prev) => ({
        ...prev,
        [key!]: ev.value,
      }));
      if (
        key === 'preset' ||
        key === 'isStreaming' ||
        key === 'simulate'
      ) {
        setRunKey((k) => k + 1);
      }
    });

    return () => pane.dispose();
  }, []);

  const codeLines = [
    `import { StreamText } from 'one-design-next';`,
    ``,
    `<StreamText`,
    `  content="…"`,
    `  isStreaming={${params.isStreaming && params.simulate}}`,
    `  simulate={${params.simulate}}`,
    `  speed={${params.speed}}`,
    `/>`,
  ];

  return (
    <div>
      <CodeBox className="group/st relative p-0 overflow-hidden items-stretch justify-start">
        <div
          className="h-[800px] overflow-auto px-8 py-8"
          style={{ background: 'var(--odn-color-white)' }}
        >
          <StreamText
            key={runKey}
            content={content}
            isStreaming={params.isStreaming && params.simulate}
            simulate={params.simulate}
            speed={params.speed}
          />
        </div>
        <button
          type="button"
          onClick={(e) => { e.stopPropagation(); setPanelVisible((v) => !v) }}
          className="absolute top-3 right-3 z-20 flex items-center justify-center w-7 h-7 rounded-md text-xs cursor-pointer border-0 opacity-0 group-hover/st:opacity-100 transition-opacity"
          style={{ background: 'var(--odn-color-black-3)', color: 'var(--odn-color-black-10)', boxShadow: '0 2px 8px rgba(0,0,0,0.06)' }}
          title={panelVisible ? '收起面板' : '展开调试面板'}
        >
          {panelVisible
            ? <Icon name="x" className="w-3.5 h-3.5" />
            : <Icon name="setting" className="w-3.5 h-3.5" />
          }
        </button>
        <div
          className="absolute top-12 right-3 z-10"
          style={{ display: panelVisible ? undefined : 'none' }}
        >
          <div
            ref={tweakpaneContainerRef}
            className="w-[280px] max-h-[calc(100vh-200px)] overflow-y-auto rounded-lg opacity-90"
            style={{ background: 'var(--odn-color-white)', boxShadow: '0 2px 12px rgba(0,0,0,0.08)' }}
          />
        </div>
      </CodeBox>
      <CodeBlock>{codeLines.join('\n')}</CodeBlock>
    </div>
  );
};

export default Demo;
```
## API {#api}

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| content | Markdown 文本内容 | `string` | - |
| isStreaming | 是否流式中 | `boolean` | `false` |
| simulate | 是否模拟逐字输出 | `boolean` | `false` |
| speed | 模拟输出速度（ms/字符） | `number` | `18` |
| onComplete | 模拟输出完成 | `() => void` | - |
| typography | 排版覆盖参数 | `TypographyOverrides` | - |

---

## 建议 Suggestions

## 基础用例 {#basic-usage}

**示例：基础用例** — 基础用例

```tsx
'use client';

import { Suggestions } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

const ALL_SUGGESTIONS = [
  '分析代码复杂度',
  '生成单元测试',
  '重构为 TypeScript',
  '解释这段代码',
  '优化性能',
  '添加错误处理',
];

const Demo = () => {
  const [params, setParams] = useState({ count: 4 });
  const [selected, setSelected] = useState('');

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  const suggestions = ALL_SUGGESTIONS.slice(0, params.count);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'count', {
      label: '数量',
      min: 2,
      max: 6,
      step: 1,
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  const codeLines: string[] = [
    `import { Suggestions } from 'one-design-next';`,
    ``,
    `const suggestions = ${JSON.stringify(suggestions)};`,
    ``,
    `<Suggestions suggestions={suggestions} onSelect={(text) => {}} />`,
  ];

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <div
          className="flex flex-col gap-3"
          style={{ minHeight: 200 }}
        >
          <Suggestions
            suggestions={suggestions}
            onSelect={setSelected}
          />
          {selected ? (
            <div
              className="text-xs"
              style={{ color: 'var(--odn-color-black-8)' }}
            >
              选中: {selected}
            </div>
          ) : null}
        </div>
      </CodeBox>
      <CodeBlock>{codeLines.join('\n')}</CodeBlock>
    </div>
  );
};

export default Demo;
```
## API {#api}

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| suggestions | 建议列表 | `string[]` | - |
| onSelect | 选中回调 | `(text: string) => void` | - |

---

## 用户气泡 UserBubble

## 基础用例 {#basic-usage}

**示例：基础用例** — 基础用例

```tsx
'use client';

import { UserBubble, type ChatMessage } from 'one-design-next';
import React, { useEffect, useMemo, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

const Demo = () => {
  const [params, setParams] = useState({
    content:
      '帮我把这个组件重构一下，使用 TypeScript 和更好的命名。',
    hasAttachments: false,
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  const message: ChatMessage = useMemo(
    () => ({
      id: 'pg',
      role: 'user',
      content: params.content,
      timestamp: Date.now(),
      ...(params.hasAttachments
        ? {
            attachments: [
              { name: 'OldComponent.jsx', type: 'text/javascript' },
              { name: 'screenshot.png', type: 'image/png' },
            ],
          }
        : {}),
    }),
    [params.content, params.hasAttachments],
  );

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'content', {
      label: 'content',
      multiline: true,
      rows: 3,
    });
    pane.addBinding(params, 'hasAttachments', { label: 'attachments' });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  const msgLines = [
    `const message: ChatMessage = {`,
    `  id: 'pg',`,
    `  role: 'user',`,
    `  content: ${JSON.stringify(params.content)},`,
    `  timestamp: Date.now(),`,
  ];
  if (params.hasAttachments) {
    msgLines.push(
      `  attachments: [`,
      `    { name: 'OldComponent.jsx', type: 'text/javascript' },`,
      `    { name: 'screenshot.png', type: 'image/png' },`,
      `  ],`,
    );
  }
  msgLines.push(`};`);

  const codeLines: string[] = [
    `import { UserBubble, type ChatMessage } from 'one-design-next';`,
    ``,
    ...msgLines,
    ``,
    `<UserBubble message={message} />`,
  ];

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <div
          className=""
          style={{ minHeight: 200 }}
        >
          <UserBubble message={message} />
        </div>
      </CodeBox>
      <CodeBlock>{codeLines.join('\n')}</CodeBlock>
    </div>
  );
};

export default Demo;
```
## API {#api}

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| message | 消息对象 | `ChatMessage` | - |
| onFileClick | 附件点击回调 | `(attachment: Attachment) => void` | - |

---

## 欢迎 Welcome

## 基础用例 {#basic-usage}

**示例：基础用例** — 基础用例

```tsx
'use client';

import { Welcome } from 'one-design-next';
import React, { useEffect, useMemo, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

const ALL_SUGGESTIONS = [
  '分析代码复杂度',
  '生成单元测试',
  '重构为 TypeScript',
  '解释这段代码',
  '优化性能',
];

const Demo = () => {
  const [params, setParams] = useState({
    title: 'GenUI Chat',
    description:
      '探索 AI 对话组件库。试试下面的快捷问题，或直接输入你的需求。',
    sugCount: 4,
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  const suggestions = useMemo(
    () => ALL_SUGGESTIONS.slice(0, params.sugCount),
    [params.sugCount],
  );

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'title', { label: 'title' });
    pane.addBinding(params, 'description', {
      label: 'description',
      multiline: true,
      rows: 3,
    });
    pane.addBinding(params, 'sugCount', {
      label: 'suggestions 数量',
      min: 0,
      max: 5,
      step: 1,
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  const codeLines: string[] = [
    `import { Welcome } from 'one-design-next';`,
    ``,
    `<Welcome`,
    `  title={${JSON.stringify(params.title)}}`,
    `  description={${JSON.stringify(params.description)}}`,
    `  suggestions={${JSON.stringify(suggestions)}}`,
    `  onSelect={() => {}}`,
    `/>`,
  ];

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <div
          className=""
          style={{ minHeight: 220 }}
        >
          <Welcome
            title={params.title}
            description={params.description}
            suggestions={suggestions}
            onSelect={() => {}}
          />
        </div>
      </CodeBox>
      <CodeBlock>{codeLines.join('\n')}</CodeBlock>
    </div>
  );
};

export default Demo;
```
## API {#api}

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| title | 标题 | `string` | `'GenUI Chat'` |
| description | 描述 | `string` | `'有什么可以帮你的？'` |
| suggestions | 建议列表 | `string[]` | `[]` |
| onSelect | 选中建议回调 | `(text: string) => void` | - |
| icon | 标题上方的品牌图形 / 图标（ReactNode）。不传时不展示 | `React.ReactNode` | - |
