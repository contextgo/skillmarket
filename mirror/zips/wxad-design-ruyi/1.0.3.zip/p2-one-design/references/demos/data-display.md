## 头像 Avatar

## 头像组 {#avatar-group}

`Avatar.Group` 用于显示多个头像，在鼠标 `hover` 时，会有一个类 Mac Dock 的表现，同时可以设置 `Tooltip`：

**示例：group** — group

```tsx
'use client';

import { Avatar } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

const Basics = () => {
  const [params, setParams] = useState({
    groupSize: 40,
    gap: -8,
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'groupSize', {
      min: 20,
      max: 64,
      step: 4,
    });
    pane.addBinding(params, 'gap', {
      min: -20,
      max: -4,
      step: 1,
    });
    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <Avatar.Group
          size={params.groupSize}
          gap={params.gap}
          tooltips={['Kimura', 'Takuya', 'Kimura', 'Takuya']}
        >
          <Avatar
            shape="circle"
            src="https://wxa.wxs.qq.com/wxad-design/yijie/gakey-tak0.jpg"
          />
          <Avatar
            shape="circle"
            src="https://wxa.wxs.qq.com/wxad-design/yijie/gakey-tak1.jpg"
          />
          <Avatar
            shape="circle"
            src="https://wxa.wxs.qq.com/wxad-design/yijie/gakey-tak2.jpg"
          />
          <Avatar
            shape="circle"
            src="https://wxa.wxs.qq.com/wxad-design/yijie/gakey-tak3.jpg"
          />
        </Avatar.Group>
      </CodeBox>
      <CodeBlock>{`import { Avatar } from "one-design-next";

<Avatar.Group
  size={${params.groupSize}}
  gap={${params.gap}}
  tooltips={['Kimura', 'Takuya', 'Kimura', 'Takuya']}
>
  <Avatar shape="circle" src="..." />
  <Avatar shape="circle" src="..." />
  <Avatar shape="circle" src="..." />
  <Avatar shape="circle" src="..." />
</Avatar.Group>`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## 基础用例 {#basic-usage}

`Avatar` 可显示图片、图标、备选文本：

**示例：basic** — basic

```tsx
'use client';

import { Avatar } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

const Basics = () => {
  const [params, setParams] = useState({
    shape: 'circle',
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'shape', {
      options: {
        circle: 'circle',
        square: 'square',
      },
    });
    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <div className="flex items-center gap-2">
          <Avatar
            shape={params.shape as 'circle' | 'square'}
            src="https://wxa.wxs.qq.com/wxad-design/yijie/gakey-tak0.jpg"
          />
          <Avatar
            shape={params.shape as 'circle' | 'square'}
            icon="sticker-filled"
          />
          <Avatar shape={params.shape as 'circle' | 'square'} fallback="TAK" />
        </div>
      </CodeBox>
      <CodeBlock>{`import { Avatar } from "one-design-next";

<Avatar shape={${params.shape}} src="..." />
<Avatar shape={${params.shape}} icon="sticker-filled" />
<Avatar shape={${params.shape}} fallback="TAK" />`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## 带徽标 {#with-badge}

`badge` Prop 可为 `node` 或 `bool`，当为 `bool` 时，会显示一个蓝点，可通过 `var(--odn-avatar-badge-bg)` 修改徽标背景色：

**示例：badge** — badge

```tsx
'use client';

import { Avatar } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

const Basics = () => {
  const [params, setParams] = useState({
    badge: '1',
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'badge', {
      type: 'string',
    });
    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <div className="flex items-center gap-4">
          <Avatar shape="square" icon="sticker-filled" badge />
          <Avatar
            shape="circle"
            src="https://wxa.wxs.qq.com/wxad-design/yijie/gakey-tak0.jpg"
            badge={params.badge}
          />
        </div>
      </CodeBox>
      <CodeBlock>{`import { Avatar } from "one-design-next";

<Avatar shape="square" icon="sticker-filled" badge />
<Avatar shape="circle" src="..." badge={${params.badge}} />`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## API {#api}

### Avatar

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| disabled | 是否禁用 | `boolean` | `false` |
| fallback | 无图时的备选 | `React.ReactNode` | - |
| src | 图片地址 | `string` | - |
| icon | 内置图标名 | `iconNames[number]` | - |
| shape | 形状 | `'circle' \| 'square'` | `'circle'` |
| badge | 徽标 | `boolean \| React.ReactNode` | `false` |
| size | 边长（px） | `number` | `32` |

继承 `React.HTMLAttributes<HTMLDivElement>`。

### Avatar.Group

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| size | 子头像边长 | `number` | `32` |
| gap | 重叠间距（常为负） | `number` | `-8` |
| tooltips | 每个头像的 Tooltip 文案 | `string[]` | `[]` |

继承 `React.HTMLAttributes<HTMLDivElement>`。

## 变量 {#variables}

<VariablesTable id="Avatar"></VariablesTable>

---

## 日历 Calendar

## 单选模式 {#single-mode}

**示例：单选模式** — 单选模式

```tsx
'use client';

import { Calendar } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
import { Pane } from 'tweakpane';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basics = () => {
  const [value, setValue] = useState<Date | undefined>(new Date());
  const [params, setParams] = useState({
    lang: 'enUS' as 'zhCN' | 'enUS',
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'lang', {
      options: {
        zhCN: 'zhCN',
        enUS: 'enUS',
      },
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  return (
    <div>
      <CodeBox className="gap-2 flex-wrap pt-[80px]">
        <div
          ref={tweakpaneContainerRef}
          className="absolute top-2 right-2 opacity-90"
        />
        <Calendar
          className="rounded-md border border-neutral-200"
          mode="single"
          selected={value}
          onSelect={setValue}
          lang={params.lang}
        />
      </CodeBox>
      <CodeBlock>{`import { Calendar } from "one-design-next";

const [value, setValue] = useState<Date | undefined>(new Date());

// ${value?.toLocaleDateString()}
<Calendar
  lang="${params.lang}"
  mode="single"
  selected={value}
  onSelect={setValue}
  className="rounded-md border border-neutral-200"
/>`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## 范围选择模式 {#range-mode}

这是 `react-day-picker` 自带的 range 模式：

**示例：范围选择模式** — 范围选择模式

```tsx
'use client';

import { Calendar } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
import { Pane } from 'tweakpane';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basics = () => {
  const [value, setValue] = useState<{ from: Date; to: Date }>({
    from: new Date(),
    to: new Date(new Date().getTime() + 1000 * 60 * 60 * 24 * 2),
  });
  const [params, setParams] = useState({
    lang: 'enUS' as 'zhCN' | 'enUS',
    numberOfMonths: 2,
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'lang', {
      options: {
        zhCN: 'zhCN',
        enUS: 'enUS',
      },
    });

    pane.addBinding(params, 'numberOfMonths', {
      min: 1,
      max: 2,
      step: 1,
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  return (
    <div>
      <CodeBox className="gap-2 flex-wrap pt-[80px]">
        <div
          ref={tweakpaneContainerRef}
          className="absolute top-2 right-2 opacity-90"
        />
        <Calendar
          className="rounded-md border border-neutral-200"
          mode="range"
          numberOfMonths={params.numberOfMonths}
          selected={value}
          onSelect={(v) => {
            setValue(v as { from: Date; to: Date });
          }}
          lang="zhCN"
        />
      </CodeBox>
      <CodeBlock>{`import { Calendar } from "one-design-next";

const [value, setValue] = useState<{ from: Date; to: Date }>({
  from: new Date(),
  to: new Date(new Date().getTime() + 1000 * 60 * 60 * 24 * 2),
});

<Calendar
  lang="${params.lang}"
  mode="range"
  numberOfMonths={${params.numberOfMonths}}
  selected={value}
  onSelect={setValue}
  className="rounded-md border border-neutral-200"
/>`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## API {#api}

类型为 `React.ComponentProps<typeof DayPicker>` 与本库扩展字段。

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| lang | 语言 | `'zhCN' \| 'enUS'` | `'zhCN'` |
| minDate | 最小日期 | `Date` | 工具默认 |
| maxDate | 最大日期 | `Date` | 工具默认 |
| disabledDays | 禁用规则 | `(date: Date) => boolean` | - |

其余属性与 [react-day-picker](https://react-day-picker.js.org/) 的 `DayPicker` 一致。

## 变量 {#variables}

<VariablesTable id="Calendar"></VariablesTable>

---

## 卡片 Card

## 基础用例

**示例：basic** — basic

```tsx
'use client';

import { Button, Card, type CardHeaderSize } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

const Basics = () => {
  const [params, setParams] = useState({
    elevation: 1 as 0 | 1 | 2 | 3 | 4,
    interactive: false,
    headerSize: 'small' as CardHeaderSize,
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'elevation', {
      min: 0,
      max: 4,
      step: 1,
    });
    pane.addBinding(params, 'interactive', {
      type: 'boolean',
    });
    pane.addBinding(params, 'headerSize', {
      options: {
        mini: 'mini',
        small: 'small',
        medium: 'medium',
        large: 'large',
      },
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <div className="max-w-lg">
          <Card elevation={params.elevation} interactive={params.interactive}>
            <Card.Header
              title="卡片标题"
              subTitle="副标题说明"
              size={params.headerSize}
              topContent={<Button size="small">操作</Button>}
            />
            <div className="px-6 pb-6 text-sm text-neutral-600">
              使用左侧面板调整 <code className="text-xs">elevation</code>、
              <code className="text-xs">interactive</code> 与{' '}
              <code className="text-xs">Card.Header</code> 的{' '}
              <code className="text-xs">size</code>。
            </div>
          </Card>
        </div>
      </CodeBox>
      <CodeBlock>{`import { Button, Card } from "one-design-next";

<Card elevation={${params.elevation}} interactive={${params.interactive}}>
  <Card.Header
    title="卡片标题"
    subTitle="副标题说明"
    size="${params.headerSize}"
    topContent={<Button size="small">操作</Button>}
  />
  <div className="px-6 pb-6">正文区域</div>
</Card>`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## API

### Card

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| elevation | 投影层级 | `0 \| 1 \| 2 \| 3 \| 4` | `1` |
| interactive | 是否可交互（手型 + 悬停/按下投影变化） | `boolean` | `false` |
| className | 附加类名 | `string` | - |

继承 `React.HTMLAttributes<HTMLDivElement>`（如 `onClick`、`style`）。

### Card.Header

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| title | 主标题（不填则不展示标题行） | `React.ReactNode` | - |
| subTitle | 副标题 | `React.ReactNode` | - |
| topContent | 头部右侧区域 | `React.ReactNode` | - |
| size | 标题区字号档位 | `'mini' \| 'small' \| 'medium' \| 'large'` | `'small'` |
| children | 标题区下方额外内容 | `React.ReactNode` | - |
| className | 附加类名 | `string` | - |

继承 `Omit<React.HTMLAttributes<HTMLDivElement>, 'title'>`。

## 变量

<VariablesTable id="Card"></VariablesTable>

---

## 图表 Chart

## 案例 1：达人收入分析 {#influencer-income-analysis}

随着自然播放量的变化，达人收入也随之变化。我们可以在静态图表的基础上，增加鼠标悬停的实时反馈。当鼠标在图表上移动时，会计算并显示出两个轴的关系。同时在达到封顶价或保底价时，也会进行优雅地展示：

**示例：basic** — basic

```tsx
'use client';

import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
import {
  AnimationPlaybackControls,
  animate,
  motion,
  useMotionValue,
  useSpring,
  useTransform,
} from 'motion/react';
import { Pane } from 'tweakpane';

const Basics = () => {
  const minPrice = 4500;
  const maxPrice = 6000;
  const minNumber = 225000;
  const maxNumber = 300000;

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);
  const timerRef = useRef<number>(0);

  const [params, setParams] = useState({
    visualDuration: 0.25,
    resetWhenMouseLeave: true,
    areaFilled: true,
    priceGap: 10,
    numberGap: 1000,
    labelTransitionType: 'fade' as 'fade' | 'move',
  });

  const isHovering = useRef(false);

  const currentPrice = useMotionValue(minPrice);
  const currentPriceText = useTransform(currentPrice, (v) =>
    v.toLocaleString(),
  );
  const animationRef = useRef<AnimationPlaybackControls | null>(null);

  const currentNumber = useMotionValue(minNumber);
  const currentNumberText = useTransform(currentNumber, (v) => {
    if (v <= minNumber) {
      return `<${minNumber.toLocaleString()}`;
    }
    if (v >= maxNumber) {
      return `>${maxNumber.toLocaleString()}`;
    }
    return v.toLocaleString();
  });

  const minNumberOpacity = useSpring(1, {
    visualDuration: 0.2,
    bounce: 0,
    restDelta: 0.001,
  });

  const minNumberY = useSpring(0, {
    visualDuration: 0.2,
    bounce: 0,
    restDelta: 0.001,
  });

  const maxNumberY = useSpring(0, {
    visualDuration: 0.2,
    bounce: 0,
    restDelta: 0.001,
  });

  const maxNumberOpacity = useSpring(1, {
    visualDuration: 0.2,
    bounce: 0,
    restDelta: 0.001,
  });

  const minNumberColor = useSpring(1, {
    visualDuration: 0.2,
    bounce: 0,
    restDelta: 0.001,
  });

  const maxNumberColor = useSpring(1, {
    visualDuration: 0.2,
    bounce: 0,
    restDelta: 0.001,
  });

  const minNumberColorValue = useTransform(
    minNumberColor,
    (v) => `rgba(0, 0, 0, ${v})`,
  );

  const maxNumberColorValue = useTransform(
    maxNumberColor,
    (v) => `rgba(0, 0, 0, ${v})`,
  );

  const maxPriceLabelOpacity = useSpring(1, {
    visualDuration: 0.2,
    bounce: 0,
    restDelta: 0.001,
  });

  const minPriceLabelOpacity = useSpring(1, {
    visualDuration: 0.2,
    bounce: 0,
    restDelta: 0.001,
  });

  const maxPriceLabelX = useSpring(0, {
    visualDuration: 0.2,
    bounce: 0,
    restDelta: 0.001,
  });

  const minPriceLabelX = useSpring(0, {
    visualDuration: 0.2,
    bounce: 0,
    restDelta: 0.001,
  });

  const minPriceLabelColorValue = useSpring(0, {
    visualDuration: 0.2,
    bounce: 0,
    restDelta: 0.001,
  });

  const minPriceLabelColor = useTransform(
    minPriceLabelColorValue,
    [0, 1],
    ['rgba(250, 157, 59, 1)', 'rgba(0, 0, 0, 0.3)'],
  );

  const minPriceLabelFontWeight = useTransform(
    minPriceLabelColorValue,
    [0, 1],
    [500, 400],
  );

  const currentPriceOpacity = useSpring(0, {
    visualDuration: 0.2,
    bounce: 0,
    restDelta: 0.001,
  });

  const maxPriceOpacity = useSpring(0.3, {
    visualDuration: 0.2,
    bounce: 0,
    restDelta: 0.001,
  });

  const minPriceOpacity = useSpring(0.3, {
    visualDuration: 0.2,
    bounce: 0,
    restDelta: 0.001,
  });

  const offsetInitial = 43;

  const offset = useSpring(offsetInitial, {
    stiffness: ((2 * Math.PI) / (Math.max(0.001, params.visualDuration))) ** 2,
    damping: (4 * Math.PI) / (Math.max(0.001, params.visualDuration)),
    mass: 1,
    restDelta: 0.001,
  });

  const chartSvgRef = useRef<SVGSVGElement>(null);

  const chartClipPath = useTransform(offset, (v) => `inset(0 ${100 - v}% 0 0)`);

  const yAxisClipPath = useTransform(offset, (v) => {
    if (v < 0) {
      return `inset(0 150px 0 0)`;
    } else if (v < 21.05) {
      // v 0 -> 21.05, yAxisClipPath 150 -> 102
      return `inset(0 ${150 - ((v - 0) * (150 - 102)) / (21.05 - 0)}px 0 0)`;
    } else if (v < 65.78) {
      // v 21.05 -> 65.78, yAxisClipPath 102 -> 0
      return `inset(0 ${
        102 - ((v - 21.05) * (102 - 0)) / (65.78 - 21.05)
      }px 0 0)`;
    }
    return `inset(0 0 0 0)`;
  });

  const xAxisClipPath = useTransform(offset, (v) => {
    if (v <= 0) {
      return `inset(125px 0 0 0)`;
    } else if (v < 21.05) {
      return `inset(78px 0 0 0)`;
    } else if (v < 65.78) {
      // v 21.05 -> 65.78, xAxisClipPath 78 -> 0
      return `inset(${78 - ((v - 21.05) * (78 - 0)) / (65.78 - 21.05)}px 0 0 0)`;
    }
    return `inset(0 0 0 0)`;
  });

  const xAxisX = useTransform(offset, (v) => {
    if (v < 0) {
      return -150;
    } else if (v < 21.05) {
      // v 0 -> 21.05, xAxisX -150 -> -102
      return -150 + ((-102 + 150) * (v - 0)) / (21.05 - 0);
    } else if (v < 65.78) {
      // v 21.05 -> 65.78, xAxisX -102 -> 0
      return -102 + ((0 + 102) * (v - 21.05)) / (65.78 - 21.05);
    }
    // v 65.78 -> 100, xAxisX 0 -> 78
    return 0 + ((78 - 0) * (v - 65.78)) / (100 - 65.78);
  });

  const yAxisY = useTransform(offset, (v) => {
    if (v < 21.05) {
      return 79.5;
    } else if (v < 65.78) {
      // v 21.05 -> 65.78, yAxisY 79.5 -> 0
      return 79.5 - ((v - 21.05) * (79.5 - 0)) / (65.78 - 21.05);
    }
    return 0;
  });

  const circleX = useTransform(offset, (v) => {
    if (v < 0) {
      return 0;
    } else if (v < 21.05) {
      // v 0 -> 21.05, circleX 0 -> 48
      return (48 * v) / 21.05;
    } else if (v < 65.78) {
      // v 21.05 -> 65.78, circleX 48 -> 149.5
      return 48 + ((149.5 - 48) * (v - 21.05)) / (65.78 - 21.05);
    } else if (v < 100) {
      // v 65.78 -> 100, circleX 149.5 -> 228
      return 149.5 + ((228 - 149.5) * (v - 65.78)) / (100 - 65.78);
    }
    return 228;
  });

  const circleY = useTransform(offset, (v) => {
    if (v < 21.05) {
      return 0;
    } else if (v < 65.78) {
      // v 21.05 -> 65.78, circleY 0 -> -79
      return (-79 * (v - 21.05)) / (65.78 - 21.05);
    }
    return -79;
  });

  const circleTransform = useTransform([circleX, circleY], (v) => {
    return `translate3d(${v[0]}px, ${v[1]}px, 0)`;
  });

  const currentPriceY = useTransform(offset, (v) => {
    if (v < 21.05) {
      return 66.5;
    } else if (v < 31) {
      // v 21.05 -> 31, currentPriceY 66.5 -> 52
      return 66.5 + ((52 - 66.5) * (v - 21.05)) / (31 - 21.05);
    } else if (v < 65.78) {
      // v 31 -> 65.78, currentPriceY 52 -> -13.5
      return 52 + ((-13.5 - 52) * (v - 31)) / (65.78 - 31);
    }
    return -13.5;
  });

  offset.on('change', (v) => {
    // 这里计算出当前价格
    let newPrice;

    if (v < 21.05) {
      // 第一段水平线：保持最低价格
      newPrice = minPrice;
    } else if (v < 65.78) {
      // 第二段斜线：价格从最低到最高线性变化
      const segmentProgress = (v - 21.05) / (65.78 - 21.05);
      const rawPrice = minPrice + (maxPrice - minPrice) * segmentProgress;
      // 根据 priceGap 取整
      newPrice = Math.round(rawPrice / params.priceGap) * params.priceGap;
    } else {
      // 第三段水平线：保持最高价格
      newPrice = maxPrice;
    }

    currentPrice.set(newPrice);

    // 这里计算出当前播放量
    let newNumber;

    if (v < 21.05) {
      // 第一段水平线：保持最低播放量
      newNumber = minNumber;
    } else if (v < 65.78) {
      // 第二段斜线：播放量从最低到最高线性变化
      const segmentProgress = (v - 21.05) / (65.78 - 21.05);
      const rawNumber = minNumber + (maxNumber - minNumber) * segmentProgress;
      // 根据 numberGap 取整
      newNumber = Math.round(rawNumber / params.numberGap) * params.numberGap;
    } else {
      // 第三段水平线：保持最高播放量
      newNumber = maxNumber;
    }

    currentNumber.set(newNumber);

    if (isHovering.current && newPrice < maxPrice) {
      maxPriceOpacity.set(0.3);
    } else {
      maxPriceOpacity.set(1);
    }

    if (isHovering.current && newPrice > minPrice) {
      minPriceOpacity.set(0.3);
    } else {
      minPriceOpacity.set(1);
    }

    if (params.labelTransitionType === 'move') {
      if (isHovering.current && v > 58) {
        maxPriceLabelX.set(-48);
      } else {
        maxPriceLabelX.set(0);
      }
      if (isHovering.current && v < 32) {
        minPriceLabelX.set(-48);
      } else {
        minPriceLabelX.set(0);
      }
    } else {
      if (isHovering.current && v > 58) {
        maxPriceLabelOpacity.set(0);
      } else {
        maxPriceLabelOpacity.set(1);
      }

      if (isHovering.current && v < 32) {
        minPriceLabelOpacity.set(0);
      } else {
        minPriceLabelOpacity.set(1);
      }
    }

    if (params.labelTransitionType === 'move') {
      if (isHovering.current && v < 42) {
        minNumberY.set(16);
      } else {
        minNumberY.set(0);
      }
      if (isHovering.current && v > 44 && v < 88) {
        maxNumberY.set(16);
      } else {
        maxNumberY.set(0);
      }
    } else {
      if (isHovering.current && v < 42) {
        minNumberOpacity.set(0);
      } else {
        minNumberOpacity.set(1);
      }

      if (isHovering.current && v > 44 && v < 88) {
        maxNumberOpacity.set(0);
      } else {
        maxNumberOpacity.set(1);
      }
    }
  });

  const handleMouseMove = (event: React.MouseEvent<HTMLDivElement>) => {
    clearTimeout(timerRef.current);

    if (!chartSvgRef.current) return;

    animationRef.current?.stop();

    isHovering.current = true;

    const rect = chartSvgRef.current.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const percentage = Math.max(0, Math.min(100, (x / rect.width) * 100));

    offset.set(percentage);

    minPriceLabelColorValue.set(1);
    currentPriceOpacity.set(1);
    minNumberColor.set(0.3);
    maxNumberColor.set(0.3);
  };

  const handleMouseLeave = () => {
    if (!params.resetWhenMouseLeave) return;

    timerRef.current = window.setTimeout(() => {
      isHovering.current = false;

      animationRef.current?.stop();
      animationRef.current = animate(offset.get(), offsetInitial, {
        type: 'spring',
        visualDuration: 0.35,
        bounce: 0,
        restDelta: 0.001,
        onUpdate: (v) => {
          offset.jump(v);
        },
      });

      maxPriceLabelOpacity.jump(1);
      minPriceLabelOpacity.jump(1);
      minNumberColor.jump(1);
      maxNumberColor.jump(1);
      minNumberOpacity.jump(1);
      maxNumberOpacity.jump(1);
      minNumberY.jump(0);
      maxNumberY.jump(0);
      minPriceLabelColorValue.jump(0);
      currentPriceOpacity.jump(0);
    }, 200);
  };

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    pane.addBinding(params, 'visualDuration', {
      label: '跟手速度',
      min: 0,
      max: 0.6,
      step: 0.05,
    });

    pane.addBinding(params, 'resetWhenMouseLeave', {
      label: '移出时归位',
    });

    pane.addBinding(params, 'areaFilled', {
      label: '填充色',
    });

    pane.addBinding(params, 'labelTransitionType', {
      label: '坐标重叠处理',
      options: {
        隐藏: 'fade',
        位移: 'move',
      },
    });

    pane.addBinding(params, 'priceGap', {
      label: '价格间隔',
      options: { '1': 1, '10': 10, '50': 50, '100': 100 },
    });

    pane.addBinding(params, 'numberGap', {
      label: '播放量间隔',
      options: { '1': 1, '1000': 1000 },
    });

    return () => {
      pane.dispose();
    };
  }, []);

  return (
    <div>
      <CodeBox className="flex justify-center items-center gap-4 p-10 pt-44 text-sm">
        <div
          ref={tweakpaneContainerRef}
          className="absolute top-2 right-2 opacity-90"
        />

        <motion.div
          className="relative -my-10 px-8 py-10 cursor-crosshair"
          onMouseMove={handleMouseMove}
          onMouseLeave={handleMouseLeave}
        >
          <div className="relative">
            <svg width="327" height="196" viewBox="0 0 327 196" fill="none">
              <path
                d="M70.8536 3.64645C70.6583 3.45118 70.3417 3.45118 70.1464 3.64645L66.9645 6.82843C66.7692 7.02369 66.7692 7.34027 66.9645 7.53553C67.1597 7.7308 67.4763 7.7308 67.6716 7.53553L70.5 4.70711L73.3284 7.53553C73.5237 7.7308 73.8403 7.7308 74.0355 7.53553C74.2308 7.34027 74.2308 7.02369 74.0355 6.82843L70.8536 3.64645ZM70.5 4L70 4L70 172L70.5 172L71 172L71 4L70.5 4Z"
                fill="black"
                fillOpacity="0.1"
              />
              <path
                d="M299.354 172.854C299.549 172.658 299.549 172.342 299.354 172.146L296.172 168.964C295.976 168.769 295.66 168.769 295.464 168.964C295.269 169.16 295.269 169.476 295.464 169.672L298.293 172.5L295.464 175.328C295.269 175.524 295.269 175.84 295.464 176.036C295.66 176.231 295.976 176.231 296.172 176.036L299.354 172.854ZM299 172.5V172L70 172V172.5V173L299 173V172.5Z"
                fill="black"
                fillOpacity="0.1"
              />
              <path
                d="M71 126H119L220.5 46.5H299"
                stroke="black"
                strokeOpacity="0.1"
              />
              <line
                x1="71"
                y1="46.5"
                x2="217"
                y2="46.5"
                stroke="black"
                strokeOpacity="0.1"
                strokeDasharray="4 4"
              />
              <line
                x1="119"
                y1="127"
                x2="119"
                y2="172"
                stroke="black"
                strokeOpacity="0.1"
                strokeDasharray="4 4"
              />
              <line
                x1="220.5"
                y1="47"
                x2="220.5"
                y2="172"
                stroke="black"
                strokeOpacity="0.1"
                strokeDasharray="4 4"
              />
            </svg>

            <div className="absolute top-0.5 left-20 text-xs text-black/30">
              达人收入
            </div>

            <div className="absolute bottom-4 -right-9 text-xs text-black/30">
              自然播放量
            </div>

            {params.areaFilled && (
              <motion.svg
                className="absolute left-[71px] bottom-6"
                width="228"
                height="126"
                viewBox="0 0 228 126"
                style={{
                  clipPath: chartClipPath,
                }}
              >
                <path
                  d="M48 80.0003L0 80V126H228V0.5H149.5L48 80.0003Z"
                  fill="url(#paint0_linear_1080_10663)"
                />
                <defs>
                  <linearGradient
                    id="paint0_linear_1080_10663"
                    x1="59.1196"
                    y1="125.479"
                    x2="59.1196"
                    y2="25.7907"
                    gradientUnits="userSpaceOnUse"
                  >
                    <stop stopColor="#FA9D3B" stopOpacity="0.05" />
                    <stop offset="1" stopColor="#FA9D3B" stopOpacity="0.4" />
                  </linearGradient>
                </defs>
              </motion.svg>
            )}

            <motion.svg
              width="228"
              height="83"
              viewBox="0 0 228 83"
              fill="none"
              className="absolute left-[71px] bottom-[68px]"
              ref={chartSvgRef}
              style={{
                clipPath: chartClipPath,
              }}
            >
              <path
                d="M0 81.0003H48L149.5 1.5H227.5"
                stroke="#FA9D3B"
                strokeWidth="3"
                strokeLinejoin="round"
              />
            </motion.svg>

            <motion.div className="absolute right-[264px] bottom-[140px] text-right">
              <motion.div
                className="text-xs text-black"
                style={{ opacity: maxPriceOpacity }}
              >
                封顶价
              </motion.div>
              <motion.div
                className="text-[#FA9D3B] text-sm leading-[20px]"
                style={{
                  fontFamily: 'WeChat Sans Std',
                  opacity: maxPriceLabelOpacity,
                  x: maxPriceLabelX,
                  color: minPriceLabelColor,
                  fontWeight: minPriceLabelFontWeight,
                }}
              >
                ￥{maxPrice.toLocaleString()}
              </motion.div>
            </motion.div>

            <motion.div className="absolute right-[264px] bottom-[44px] text-right">
              <motion.div
                className="text-sm leading-[20px]"
                style={{
                  fontFamily: 'WeChat Sans Std',
                  opacity: minPriceLabelOpacity,
                  x: minPriceLabelX,
                  color: minPriceLabelColor,
                  fontWeight: minPriceLabelFontWeight,
                }}
              >
                ￥{minPrice.toLocaleString()}
              </motion.div>
              <motion.div
                className="text-xs text-black"
                style={{ opacity: minPriceOpacity }}
              >
                保底价
              </motion.div>
            </motion.div>

            <motion.div
              className="absolute bottom-0 left-[96px] text-xs leading-[20px]"
              style={{
                fontFamily: 'WeChat Sans Std',
                opacity: minNumberOpacity,
                y: minNumberY,
                color: minNumberColorValue,
              }}
            >
              {minNumber.toLocaleString()}
            </motion.div>

            <motion.div
              className="absolute bottom-0 left-[197px] text-xs leading-[20px]"
              style={{
                fontFamily: 'WeChat Sans Std',
                opacity: maxNumberOpacity,
                color: maxNumberColorValue,
                y: maxNumberY,
              }}
            >
              {maxNumber.toLocaleString()}
            </motion.div>

            <motion.svg
              width="1"
              height="125"
              viewBox="0 0 1 125"
              fill="none"
              className="absolute left-[220px] bottom-[24px]"
              style={{
                clipPath: xAxisClipPath,
                x: xAxisX,
              }}
            >
              <line
                x1="0.5"
                y1="-2.18557e-08"
                x2="0.500005"
                y2="125"
                stroke="#FA9D3B"
                strokeDasharray="4 4"
              />
            </motion.svg>

            <motion.svg
              width="150"
              height="1"
              viewBox="0 0 150 1"
              fill="none"
              className="absolute left-[71px] bottom-[149px]"
              style={{
                clipPath: yAxisClipPath,
                y: yAxisY,
              }}
            >
              <line
                y1="0.5"
                x2="150"
                y2="0.5"
                stroke="#FA9D3B"
                strokeDasharray="4 4"
              />
            </motion.svg>

            <motion.svg
              className="absolute left-[65px] bottom-[64px]"
              width="12"
              height="12"
              viewBox="0 0 12 12"
              fill="none"
              style={{
                transform: circleTransform,
              }}
            >
              <circle
                cx="6"
                cy="6"
                r="4.5"
                fill="white"
                stroke="#FA9D3B"
                strokeWidth="3"
                strokeLinejoin="round"
              />
            </motion.svg>

            <motion.div
              className="absolute left-[19px] bottom-[129px] text-right"
              style={{ opacity: currentPriceOpacity, y: currentPriceY }}
            >
              <motion.div
                className="text-[#FA9D3B] text-sm leading-[15px]"
                style={{
                  fontFamily: 'WeChat Sans Std Medium',
                }}
              >
                ￥<motion.span>{currentPriceText}</motion.span>
              </motion.div>
            </motion.div>

            <motion.div
              className="absolute left-[220px] bottom-0 text-xs leading-[20px]"
              style={{
                fontFamily: 'WeChat Sans Std',
                x: xAxisX,
                opacity: currentPriceOpacity,
              }}
            >
              <motion.div className="-translate-x-1/2">
                {currentNumberText}
              </motion.div>
            </motion.div>

            <motion.div
              className="absolute left-[86px] bottom-[58px] w-[60px] h-6 flex items-center justify-center text-xs text-[#FA9D3B] font-semibold rounded"
              style={{
                transform: circleTransform,
                backgroundColor: 'rgba(250, 157, 59, 0.16)',
              }}
            >
              结算价格
              <svg
                className="absolute right-full top-1/2 -translate-y-1/2"
                width="4"
                height="10"
                viewBox="0 0 4 10"
                fill="none"
              >
                <path
                  d="M4 0.5L0.300442 4.26236C-0.100146 4.66975 -0.100147 5.33025 0.300442 5.73764L4 9.5L4 0.5Z"
                  fill="#FA9D3B"
                  fillOpacity="0.16"
                />
              </svg>
            </motion.div>
          </div>
        </motion.div>
      </CodeBox>

      <CodeBlock>{`import { motion, useTransform, useSpring, useMotionValue, animate } from 'motion/react';

const minPrice = 4500;
const maxPrice = 6000;
const minNumber = 225000;
const maxNumber = 300000;

// 1. 创建基础动画值
const offset = useSpring(43, {
  stiffness: 631.65,
  damping: 50.27,
  restDelta: 0.001,
});

const currentPrice = useMotionValue(minPrice);
const currentNumber = useMotionValue(minNumber);

// 2. 使用 useTransform 创建派生值
const currentPriceText = useTransform(currentPrice, (v) => v.toLocaleString());
const chartClipPath = useTransform(offset, (v) => \`inset(0 \${100 - v}% 0 0)\`);

const circleX = useTransform(offset, (v) => {
  if (v < 21.05) return (48 * v) / 21.05;
  if (v < 65.78) return 48 + ((149.5 - 48) * (v - 21.05)) / (65.78 - 21.05);
  return 149.5 + ((228 - 149.5) * (v - 65.78)) / (100 - 65.78);
});

const circleY = useTransform(offset, (v) => {
  if (v < 21.05) return 0;
  if (v < 65.78) return (-79 * (v - 21.05)) / (65.78 - 21.05);
  return -79;
});

const circleTransform = useTransform([circleX, circleY], (v) => 
  \`translate3d(\${v[0]}px, \${v[1]}px, 0)\`
);

// 3. 监听偏移量变化，计算当前价格和播放量
offset.on('change', (v) => {
  // 计算价格
  let newPrice;
  if (v < 21.05) {
    newPrice = minPrice;
  } else if (v < 65.78) {
    const progress = (v - 21.05) / (65.78 - 21.05);
    newPrice = minPrice + (maxPrice - minPrice) * progress;
  } else {
    newPrice = maxPrice;
  }
  currentPrice.set(newPrice);

  // 计算播放量
  let newNumber;
  if (v < 21.05) {
    newNumber = minNumber;
  } else if (v < 65.78) {
    const progress = (v - 21.05) / (65.78 - 21.05);
    newNumber = minNumber + (maxNumber - minNumber) * progress;
  } else {
    newNumber = maxNumber;
  }
  currentNumber.set(newNumber);
});

// 4. 鼠标交互处理
const handleMouseMove = (event) => {
  const rect = chartSvgRef.current.getBoundingClientRect();
  const x = event.clientX - rect.left;
  const percentage = Math.max(0, Math.min(100, (x / rect.width) * 100));
  offset.set(percentage);
};

const handleMouseLeave = () => {
  // 延迟后回到初始状态
  setTimeout(() => {
    animate(offset.get(), 43, {
      type: 'spring',
      visualDuration: 0.35,
      bounce: 0,
      onUpdate: (v) => offset.jump(v),
    });
  }, 200);
};

// 5. 渲染
<motion.div onMouseMove={handleMouseMove} onMouseLeave={handleMouseLeave}>
  {/* 图表 SVG */}
  <motion.svg ref={chartSvgRef} style={{ clipPath: chartClipPath }}>
    <path d="..." stroke="#FA9D3B" />
  </motion.svg>

  {/* 跟随鼠标的圆点 */}
  <motion.svg style={{ transform: circleTransform }}>
    <circle cx="6" cy="6" r="4.5" stroke="#FA9D3B" />
  </motion.svg>

  {/* 当前价格显示 */}
  <motion.div>
    ￥<motion.span>{currentPriceText}</motion.span>
  </motion.div>
</motion.div>`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## 案例 2：水晶球 {#crystal-ball-prediction}

人群洞察水晶球：同心圆分布六组人群标签，hover 扇区显示目标人群占比 Popover（含 TOP3 达人/IP 缩略图和下钻入口），点击标签下钻到气泡图分析：

**示例：crystal-ball** — crystal-ball

```tsx
'use client';

import clsx from 'clsx';
import * as d3 from 'd3';
import React, { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import {
  AnimationPlaybackControls,
  MotionValue,
  animate,
  motion,
  useMotionValue,
  useSpring,
  useTransform,
} from 'motion/react';
import { Pane } from 'tweakpane';
import {
  layer1,
  layer1Current,
  layer2,
  layer3,
  layer4,
  mockData,
  tagStyles,
  type TopIP,
} from './consts';

// 核心尺寸常量
const CONTAINER_SIZE = 800; // 主容器尺寸
const TAG_SIZE = 104; // 标签尺寸
const CENTER_CIRCLE_SIZE = 160; // 中心圆尺寸
const DOT_SIZE = 12; // 小圆点尺寸

// 计算值
const TAG_OFFSET = (CONTAINER_SIZE - TAG_SIZE) / 2; // 348

// 气泡配置
const BUBBLE_MIN_RADIUS = 56; // 气泡最小半径
const BUBBLE_MAX_RADIUS = 135; // 气泡最大半径

// 其他配置
const POPOVER_OFFSET = 24; // Popover 偏移量
const LAYER_TIMEOUT = 200; // 图层超时时间

// 根据 parentIndex, mockData 判断 Tag 是否是文字在下，圆点在上的排列，如果是则返回 true
const REVERSE_TAG_INDICES: Record<number, number[]> = {
  6: [2, 3, 4],
  5: [1, 2, 3],
  4: [2],
  3: [1],
};

const isReverseTag = ({
  parentIndex,
  totalLength,
}: {
  parentIndex: number;
  totalLength: number;
}) => {
  return REVERSE_TAG_INDICES[totalLength]?.includes(parentIndex) ?? false;
};

// 也是一个比较特殊的方法，根据 totalLength 计算出 sector 的 offset
const SECTOR_OFFSETS: Record<number, number> = {
  3: 60,
  4: 0,
  5: 36,
  6: 0,
};

const getSectorOffset = (totalLength: number) => {
  return SECTOR_OFFSETS[totalLength] ?? 0;
};

type TagMouseOptions = {
  parentIndex: number;
  index: number;
  el: HTMLDivElement | null;
  name: string;
};

interface BubbleNode {
  name: string;
  percent: number;
  r: number;
  x: number;
  y: number;
  rank: number;
}

interface BubbleDataItem {
  name: string;
  percent: number;
}

/**
 * 计算气泡布局
 * @param rawData 原始数据数组
 * @param containerSize 容器尺寸
 * @param centerCircleSize 中心圆尺寸
 * @param minRadius 气泡最小半径
 * @param maxRadius 气泡最大半径
 * @returns 布局计算完成的气泡节点数组
 */
const calculateBubbleLayout = (
  rawData: BubbleDataItem[],
  containerSize: number,
  centerCircleSize: number,
  minRadius: number,
  maxRadius: number,
): BubbleNode[] => {
  const width = containerSize;
  const height = containerSize;
  const centerX = width / 2;
  const centerY = height / 2;
  const centerRadius = centerCircleSize / 2;
  const containerRadius = containerSize / 2;

  const maxPercent = Math.max(...rawData.map((d) => d.percent));

  // 按 percent 降序排序并计算排名
  const sortedData = [...rawData].sort((a, b) => b.percent - a.percent);

  // 计算排名数组（相同 percent 的项具有相同排名）
  const ranks: number[] = [];
  sortedData.forEach((item, index) => {
    if (index > 0 && sortedData[index - 1].percent === item.percent) {
      ranks.push(ranks[index - 1]);
    } else {
      ranks.push(index + 1);
    }
  });

  const sortedDataWithRank = sortedData.map((item, index) => ({
    ...item,
    rank: ranks[index],
  }));

  interface SimulationNode extends d3.SimulationNodeDatum {
    name: string;
    percent: number;
    r: number;
    x: number;
    y: number;
    rank: number;
  }

  // 按比例计算所有圆的初始半径
  // 使用平方根尺度，因为圆的面积 ∝ r²，这样视觉上的面积与数据成正比
  const initialRadii = sortedDataWithRank.map((item) => {
    // 使用平方根映射，让面积与 percent 成正比
    const normalizedValue = Math.sqrt(item.percent / maxPercent);
    const radius = minRadius + normalizedValue * (maxRadius - minRadius);
    return radius;
  });

  // 估算可用空间
  const availableRadius = containerRadius - centerRadius - 20; // 留 20px 边距
  const maxInitialRadius = Math.max(...initialRadii);
  const totalArea = initialRadii.reduce((sum, r) => sum + Math.PI * r * r, 0);
  const availableArea = Math.PI * availableRadius * availableRadius * 0.7;

  // 计算缩放因子
  let scaleFactor = 1;
  if (totalArea > availableArea) {
    scaleFactor = Math.sqrt(availableArea / totalArea);
  }
  if (maxInitialRadius * scaleFactor > availableRadius * 0.45) {
    scaleFactor = (availableRadius * 0.45) / maxInitialRadius;
  }

  // 创建节点
  const nodes: SimulationNode[] = sortedDataWithRank.map((item, index) => {
    let radius = initialRadii[index] * scaleFactor;
    radius = Math.max(radius, minRadius);

    return {
      name: item.name,
      percent: item.percent,
      r: radius,
      x: centerX + (Math.random() - 0.5) * (containerSize / 2),
      y: centerY + (Math.random() - 0.5) * (containerSize / 2),
      rank: item.rank,
    };
  });

  // 创建力模拟
  const simulation = d3
    .forceSimulation(nodes)
    .force('charge', d3.forceManyBody().strength(5))
    .force(
      'collision',
      d3
        .forceCollide<SimulationNode>()
        .radius((d) => d.r + 4)
        .strength(1),
    )
    .force('x', d3.forceX(centerX).strength(0.02))
    .force('y', d3.forceY(centerY).strength(0.02))
    .force('center-avoid', () => {
      // 自定义力：避免覆盖中心圆
      nodes.forEach((node) => {
        const dx = node.x - centerX;
        const dy = node.y - centerY;
        const distance = Math.sqrt(dx * dx + dy * dy);
        const minDistance = centerRadius + node.r + 8;

        if (distance < minDistance) {
          const angle = Math.atan2(dy, dx);
          node.x = centerX + Math.cos(angle) * minDistance;
          node.y = centerY + Math.sin(angle) * minDistance;
        }
      });
    })
    .force('boundary', () => {
      // 自定义力：保持在容器边界内
      nodes.forEach((node) => {
        const dx = node.x - centerX;
        const dy = node.y - centerY;
        const distance = Math.sqrt(dx * dx + dy * dy);
        const maxDistance = containerRadius - node.r - 5;

        if (distance > maxDistance) {
          const angle = Math.atan2(dy, dx);
          node.x = centerX + Math.cos(angle) * maxDistance;
          node.y = centerY + Math.sin(angle) * maxDistance;
        }
      });
    })
    .stop();

  // 手动运行模拟直到稳定
  let maxIterations = 500;
  while (simulation.alpha() > 0.001 && maxIterations > 0) {
    simulation.tick();
    maxIterations--;
  }

  return nodes.map((node) => ({
    name: node.name,
    percent: node.percent,
    r: node.r,
    x: node.x,
    y: node.y,
    rank: node.rank,
  }));
};

/**
 * @param parentIndex 父级 index（目前只写了 6 个的情况，从正上方开始，顺时针方向为 0，1，2，3，4，5）
 * TODO: index 布局可能和现网不同
 * @param index 在父级下的第几个 index
 * @param onMouseEnter 主要做 hoverFill 跟随以及 Popover 设置
 * @param onMouseLeave 主要做 hoverFill 隐藏以及 Popover 设置
 * @param onClick 父组件统一处理状态
 * @param name
 * @param level0PointerEvents 用以控制是否能够交互，因在 level1 时禁用交互
 * @returns
 */
const Tag = ({
  parentIndex,
  index,
  onMouseEnter,
  onMouseLeave,
  onClick,
  name,
  params,
  level0PointerEvents,
  totalLength,
}: {
  parentIndex: number;
  index: number;
  onMouseEnter?: (
    e: React.MouseEvent<HTMLDivElement>,
    options: TagMouseOptions,
  ) => void;
  onMouseLeave?: (
    e: React.MouseEvent<HTMLDivElement>,
    options: TagMouseOptions,
  ) => void;
  onClick?: (
    e: React.MouseEvent<HTMLDivElement>,
    options: TagMouseOptions,
  ) => void;
  name: string;
  params: {
    hoverVisible: boolean;
  };
  level0PointerEvents: MotionValue<string>;
  totalLength: number;
}) => {
  const ref = useRef<HTMLDivElement>(null);

  const isReverse = isReverseTag({ parentIndex, totalLength });

  return (
    <div
      className="absolute flex flex-col text-center hover:z-10"
      style={{
        width: TAG_SIZE,
        height: TAG_SIZE,
        transform: `translate3d(${tagStyles[Number(totalLength) as keyof typeof tagStyles]?.[index]?.x}px, ${tagStyles[Number(totalLength) as keyof typeof tagStyles]?.[index]?.y}px, 0) rotate(calc(var(--sector-index) * var(--sector-angle) * -1deg + var(--sector-offset) * -1deg))`,
      }}
      ref={ref}
    >
      <div
        className="relative z-10 mx-auto w-fit min-w-[52px] max-w-[70%] select-none pb-4 pt-5 text-[13px] leading-[22px] text-black-11"
        style={{
          marginTop: isReverse ? 'auto' : undefined,
        }}
      >
        <div className="truncate">{name}</div>
        <motion.div
          className={clsx(
            'absolute left-0 z-10 h-full w-full cursor-pointer hover:left-1/2 hover:h-[104px] hover:w-[104px] hover:-translate-x-1/2 hover:rounded-full',
            !isReverse && 'top-0',
            isReverse && 'bottom-0',
          )}
          onMouseEnter={(e) =>
            onMouseEnter?.(e, { parentIndex, index, el: ref.current, name })
          }
          onMouseLeave={(e) =>
            onMouseLeave?.(e, { parentIndex, index, el: ref.current, name })
          }
          onClick={
            onClick
              ? (e) =>
                  onClick?.(e, { parentIndex, index, el: ref.current, name })
              : undefined
          }
          style={{
            pointerEvents: level0PointerEvents,
            background: params.hoverVisible
              ? 'rgba(0, 0, 0, 0.1)'
              : 'transparent',
          }}
        />
      </div>
      <div
        className="absolute left-1/2 top-1/2 z-10 -translate-x-1/2 -translate-y-1/2 rounded-full bg-[var(--odn-primary-color)] opacity-80"
        style={{ width: DOT_SIZE, height: DOT_SIZE }}
      />
    </div>
  );
};

const Basics = () => {
  const [params, setParams] = useState({
    useHoverFill: true,
    hoverVisible: false,
    transitionType: 'small',
    visualDuration: 0.4,
    bounce: 0.2,
    dataCount: 6,
    hasPopover: false,
  });
  const [currentHoverCategory, setCurrentHoverCategory] = useState<{
    parentIndex: number;
    childIndex?: number;
    data: (typeof mockData)[number];
  } | null>(null);
  const wrapperRef = useRef<HTMLDivElement>(null);
  const currentTagEl = useRef<HTMLDivElement | null>(null);
  const layerMouseLeaveTimer = useRef(0);
  const tagHoverFillTimer = useRef(0);
  const tagHoverFillVisible = useRef(false);
  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);
  const [popoverVisible, setPopoverVisible] = useState(false);
  const popoverX = useSpring(0, {
    visualDuration: 0.3,
    bounce: 0,
  });
  const popoverY = useSpring(0, {
    visualDuration: 0.3,
    bounce: 0,
  });
  const currentTagName = useMotionValue('');
  const currentTagMarginTop = useMotionValue('');
  const currentTagTextPlaceholderTransformOrigin = useMotionValue(
    '50% calc(100% + 16px)',
  );
  const tagHoverFillX = useSpring(0, {
    visualDuration: 0.15,
    bounce: 0,
  });
  const tagHoverFillY = useSpring(0, {
    visualDuration: 0.15,
    bounce: 0,
  });
  const tagHoverFillXSaved = useRef(0);
  const tagHoverFillYSaved = useRef(0);
  const tagHoverFillScale = useSpring(1, {
    visualDuration: params.visualDuration,
    bounce: params.bounce,
    restDelta: 0.001,
  });
  const tagHoverFillOpacity = useSpring(0, {
    visualDuration: 0.15,
    bounce: 0,
    restDelta: 0.001,
  });

  const animateRef = useRef<AnimationPlaybackControls | null>(null);

  // 0 表示第一层，1 表示第二层
  const viewLevel = useMotionValue(0);
  const [animating, setAnimating] = useState(false);
  const level0Opacity = useSpring(1, {
    visualDuration: 0.2,
    bounce: 0,
    restDelta: 0.001,
  });

  const level0Scale = useTransform(level0Opacity, [1, 0], [1, 0.95]);

  const level0Filter = useTransform(
    level0Opacity,
    [1, 0],
    ['blur(0px)', 'blur(3px)'],
  );

  const level0OpacityBig = useSpring(1, {
    visualDuration: params.visualDuration,
    bounce: params.bounce,
    restDelta: 0.001,
  });

  const level0ScaleBig = useTransform(
    level0OpacityBig,
    [1, 0],
    [1, CONTAINER_SIZE / TAG_SIZE],
    { clamp: false },
  );
  const level0TransformOriginBig = useMotionValue('');
  const level0XBig = useSpring(0, {
    visualDuration: params.visualDuration,
    bounce: params.bounce,
    restDelta: 0.001,
  });
  const level0YBig = useSpring(0, {
    visualDuration: params.visualDuration,
    bounce: params.bounce,
    restDelta: 0.001,
  });

  const level1Progress = useSpring(0, {
    visualDuration: params.visualDuration,
    bounce: params.bounce,
    restDelta: 0.001,
  });

  const tagHoverFillBg = useTransform(
    level1Progress,
    [0, 1],
    [
      'radial-gradient(50% 50% at 50% 50%, rgba(82, 137, 246, 0.2) 0%, rgba(82, 137, 246, 0.2) 100%)',
      'radial-gradient(50% 50% at 50% 50%, rgba(224, 234, 255, 1) 0%, rgba(251, 252, 255, 1) 100%)',
    ],
  );

  const level1Scale = useTransform(
    level1Progress,
    [0, 1],
    [TAG_SIZE / CONTAINER_SIZE, 1],
    {
      clamp: false,
    },
  );

  const level1TextPlaceholderScale = useTransform(
    level1Progress,
    [0, 1],
    [1, CONTAINER_SIZE / TAG_SIZE],
    {
      clamp: false,
    },
  );

  const level1TextPlaceholderOpacity = useSpring(0, {
    visualDuration: 0.15,
    bounce: 0,
    restDelta: 0.001,
  });

  const level1IndicatorScale = useTransform(
    level1Progress,
    [0, 1],
    [DOT_SIZE / CENTER_CIRCLE_SIZE, 1],
    {
      clamp: false,
    },
  );

  const level1Border = useTransform(
    level1Progress,
    [0.5, 1],
    ['1px solid rgba(225, 235, 255, 0)', '1px solid rgba(225, 235, 255, 1)'],
  );

  const level1Opacity = useMotionValue(0);
  const level0PointerEvents = useMotionValue('auto');
  const level1PointerEvents = useMotionValue('none');

  const level1BubbleOpacity = useSpring(0, {
    visualDuration: params.visualDuration,
    bounce: params.bounce,
    restDelta: 0.001,
  });
  const level1BubbleScale = useSpring(0, {
    visualDuration: params.visualDuration,
    bounce: params.bounce,
  });

  const [bubbles, setBubbles] = useState<BubbleNode[]>([]);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'useHoverFill', {
      label: 'hover背景共享',
      type: 'boolean',
    });

    pane.addBinding(params, 'hoverVisible', {
      label: 'hover区域可见',
      type: 'boolean',
    });

    pane.addBinding(params, 'transitionType', {
      label: '背景缩放',
      options: {
        放大: 'big',
        缩小: 'small',
      },
    });

    pane.addBinding(params, 'visualDuration', {
      label: '过渡时长',
      min: 0.2,
      max: 1,
      step: 0.1,
    });

    pane.addBinding(params, 'bounce', {
      label: '过渡弹性',
      min: 0,
      max: 0.4,
      step: 0.1,
    });

    pane.addBinding(params, 'dataCount', {
      label: '数据组数',
      min: 3,
      max: 6,
      step: 1,
    });

    pane.addBinding(params, 'hasPopover', {
      label: 'popover',
      type: 'boolean',
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  // 根据 dataCount 动态切片数据
  const displayData = mockData.slice(0, params.dataCount);

  const handleLayerMouseEnter = (
    e: React.MouseEvent<HTMLDivElement>,
    options: { parentIndex: number },
  ) => {
    const { parentIndex } = options;
    if (viewLevel.get() !== 0) return;
    setCurrentHoverCategory({
      parentIndex,
      childIndex: undefined,
      data: displayData[parentIndex],
    });
  };

  const handleLayerMouseLeave = (
    e: React.MouseEvent<HTMLDivElement>,
    options: { parentIndex: number },
  ) => {
    // setCurrentHoverCategory(null);
  };

  const handleTagMouseEnter = (
    e: React.MouseEvent<HTMLDivElement>,
    options: TagMouseOptions,
  ) => {
    if (viewLevel.get() !== 0) return;

    e.persist();
    clearTimeout(tagHoverFillTimer.current);

    const { el, parentIndex, index } = options;

    if (!el || !wrapperRef.current) {
      return;
    }

    setCurrentHoverCategory({
      parentIndex,
      childIndex: index,
      data: displayData[parentIndex],
    });

    const wrapper = wrapperRef.current.getBoundingClientRect();
    const target = el.getBoundingClientRect();

    const finalLeft =
      target.left - wrapper.left - wrapper.width / 2 + target.width / 2;
    const finalTop =
      target.top - wrapper.top - wrapper.height / 2 + target.height / 2;

    tagHoverFillXSaved.current = finalLeft;
    tagHoverFillYSaved.current = finalTop;

    setTimeout(() => {
      tagHoverFillOpacity.set(1);
    }, 0);

    if (!tagHoverFillVisible.current) {
      tagHoverFillVisible.current = true;
      setTimeout(() => {
        animateRef.current?.stop();
        tagHoverFillX.jump(finalLeft);
        tagHoverFillY.jump(finalTop);
      }, 0);
    } else {
      setTimeout(() => {
        animateRef.current?.stop();
        if (params.useHoverFill) {
          tagHoverFillX.set(finalLeft);
          tagHoverFillY.set(finalTop);
        } else {
          tagHoverFillX.jump(finalLeft);
          tagHoverFillY.jump(finalTop);
        }
      }, 0);
    }
  };
  const handleTagMouseLeave = (
    e: React.MouseEvent<HTMLDivElement>,
    options: TagMouseOptions,
  ) => {
    if (viewLevel.get() !== 0) return;

    e.persist();
    clearTimeout(tagHoverFillTimer.current);

    tagHoverFillTimer.current = window.setTimeout(async () => {
      tagHoverFillOpacity.set(0);
      await new Promise((resolve) => setTimeout(resolve, 200));
      tagHoverFillVisible.current = false;
    }, 200);
  };
  const handleTagClick = async (
    e: React.MouseEvent<HTMLDivElement>,
    options: TagMouseOptions,
  ) => {
    const { el, name, parentIndex, index } = options;

    setPopoverVisible(false);

    // 获取对应的数据
    const currentCategory = displayData[parentIndex]?.children[index];
    if (
      !currentCategory ||
      !currentCategory.children ||
      !wrapperRef.current ||
      !el
    ) {
      return;
    }

    setAnimating(true);

    setTimeout(() => {
      setAnimating(false);
    }, params.visualDuration * 1000);

    const rawData = currentCategory.children;

    // 计算气泡布局
    const bubbles = calculateBubbleLayout(
      rawData,
      CONTAINER_SIZE,
      CENTER_CIRCLE_SIZE,
      BUBBLE_MIN_RADIUS,
      BUBBLE_MAX_RADIUS,
    );

    // 更新气泡数据
    setBubbles(bubbles);

    if (params.transitionType === 'small') {
      if (el) {
        currentTagEl.current = el;
        el.style.opacity = '0';
      }
      level1TextPlaceholderOpacity.jump(1);
      currentTagName.set(name);
      if (isReverseTag({ parentIndex, totalLength: displayData.length })) {
        currentTagMarginTop.set('auto');
        currentTagTextPlaceholderTransformOrigin.set('50% 0');
      } else {
        currentTagMarginTop.set('');
        currentTagTextPlaceholderTransformOrigin.set('50% calc(100% + 16px)');
      }
      viewLevel.set(1);
      level0Opacity.set(0);
      animateRef.current?.stop();
      level1Opacity.set(1);
      await new Promise((resolve) => setTimeout(resolve, 30));
      level1TextPlaceholderOpacity.set(0);
      animateRef.current = animate(1, 0, {
        type: 'spring',
        stiffness: 170,
        damping: 26,
        restDelta: 0.001,
        onUpdate: (value: number) => {
          tagHoverFillX.jump(tagHoverFillXSaved.current * value);
          tagHoverFillY.jump(tagHoverFillYSaved.current * value);
        },
      });
      await new Promise((resolve) => setTimeout(resolve, 50));
      tagHoverFillScale.set(CONTAINER_SIZE / TAG_SIZE);
      level1Progress.set(1);
      level1PointerEvents.set('auto');
      level0PointerEvents.set('none');
      tagHoverFillOpacity.jump(1);

      await new Promise((resolve) => setTimeout(resolve, 40));
      level1BubbleOpacity.set(1);
      level1BubbleScale.set(1);
    } else {
      level0OpacityBig.set(0);
      const wrapperRect = wrapperRef.current.getBoundingClientRect();
      const elRect = el.getBoundingClientRect();
      // 计算出正确的 transformOrigin，从点击的 el 中心放大
      const elCenterX = elRect.left - wrapperRect.left + elRect.width / 2;
      const elCenterY = elRect.top - wrapperRect.top + elRect.height / 2;

      level0TransformOriginBig.set(`${elCenterX}px ${elCenterY}px`);

      level0XBig.set(
        wrapperRect.left +
          wrapperRect.width / 2 -
          elRect.left -
          elRect.width / 2,
      );
      level0YBig.set(
        wrapperRect.top +
          wrapperRect.height / 2 -
          elRect.top -
          elRect.height / 2,
      );

      if (el) {
        currentTagEl.current = el;
        el.style.opacity = '0';
      }
      level1TextPlaceholderOpacity.jump(1);
      currentTagName.set(name);
      if (isReverseTag({ parentIndex, totalLength: displayData.length })) {
        currentTagMarginTop.set('auto');
        currentTagTextPlaceholderTransformOrigin.set('50% 0');
      } else {
        currentTagMarginTop.set('');
        currentTagTextPlaceholderTransformOrigin.set('50% calc(100% + 16px)');
      }
      viewLevel.set(1);
      level0Opacity.set(0);
      level1Opacity.set(1);
      animateRef.current?.stop();

      await new Promise((resolve) => setTimeout(resolve, 0));
      level1TextPlaceholderOpacity.set(0);
      animateRef.current = animate(1, 0, {
        type: 'spring',
        visualDuration: params.visualDuration,
        bounce: params.bounce,
        restDelta: 0.001,
        onUpdate: (value: number) => {
          tagHoverFillX.jump(tagHoverFillXSaved.current * value);
          tagHoverFillY.jump(tagHoverFillYSaved.current * value);
        },
      });

      await new Promise((resolve) => setTimeout(resolve, 0));
      tagHoverFillScale.set(CONTAINER_SIZE / TAG_SIZE);
      level1Progress.set(1);
      level1PointerEvents.set('auto');
      level0PointerEvents.set('none');
      tagHoverFillOpacity.jump(1);

      await new Promise((resolve) => setTimeout(resolve, 40));
      level1BubbleOpacity.set(1);
      level1BubbleScale.set(1);
    }
  };

  const handleLevel1ToLevel0 = async () => {
    if (viewLevel.get() === 0 || animating) {
      return;
    }

    animateRef.current?.stop();

    setAnimating(true);
    viewLevel.set(0);
    level1BubbleOpacity.set(0);
    level1BubbleScale.set(0);

    tagHoverFillScale.set(1);
    level1Progress.set(0);

    if (params.transitionType === 'big') {
      level0OpacityBig.set(1);
      level0ScaleBig.set(1);
      level0XBig.set(0);
      level0YBig.set(0);
    }

    await new Promise((resolve) => setTimeout(resolve, 30));
    animateRef.current = animate(0, 1, {
      type: 'spring',
      stiffness: 170,
      damping: 26,
      restDelta: 0.001,
      onUpdate: (value: number) => {
        tagHoverFillX.jump(tagHoverFillXSaved.current * value);
        tagHoverFillY.jump(tagHoverFillYSaved.current * value);
      },
    });
    await new Promise((resolve) => setTimeout(resolve, 200));
    level1TextPlaceholderOpacity.set(1);
    level0Opacity.set(1);
    // 下面的这两个值保持之和 500，才能保证 500 之后的动画衔接
    const totalTimeout = 500;
    const firstTimeout = 100;
    await new Promise((resolve) => setTimeout(resolve, firstTimeout));
    tagHoverFillOpacity.set(0);
    await new Promise((resolve) =>
      setTimeout(resolve, totalTimeout - firstTimeout),
    );

    const onComplete = () => {
      setAnimating(false);
      currentTagName.set('');
      level1Opacity.set(0);
      if (currentTagEl.current) {
        currentTagEl.current.style.opacity = '1';
      }
      level1TextPlaceholderOpacity.set(0);
      tagHoverFillVisible.current = false;
      level1PointerEvents.set('none');
      level0PointerEvents.set('auto');
    };

    onComplete();
  };

  const handleWrapperMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!wrapperRef.current) return;
    clearTimeout(layerMouseLeaveTimer.current);
    if (viewLevel.get() === 0) {
      setPopoverVisible(true);
      const newX = e.clientX + POPOVER_OFFSET;
      const newY = e.clientY + POPOVER_OFFSET;
      if (!popoverVisible) {
        popoverX.jump(newX);
        popoverY.jump(newY);
      } else {
        popoverX.set(newX);
        popoverY.set(newY);
      }
    } else {
      setPopoverVisible(false);
    }
  };

  const handleWrapperMouseLeave = (e: React.MouseEvent<HTMLDivElement>) => {
    clearTimeout(layerMouseLeaveTimer.current);
    layerMouseLeaveTimer.current = window.setTimeout(() => {
      setPopoverVisible(false);
    }, LAYER_TIMEOUT);
  };

  const handlePopoverMouseEnter = (e: React.MouseEvent<HTMLDivElement>) => {
    clearTimeout(layerMouseLeaveTimer.current);
    if (viewLevel.get() === 0) {
      setPopoverVisible(true);
    }
  };

  const handlePopoverMouseLeave = (e: React.MouseEvent<HTMLDivElement>) => {
    clearTimeout(layerMouseLeaveTimer.current);
    layerMouseLeaveTimer.current = window.setTimeout(() => {
      setPopoverVisible(false);
    }, LAYER_TIMEOUT);
  };

  const currentHoverData = currentHoverCategory?.data;
  const currentHoverTopIPs = (currentHoverData as { topIPs?: TopIP[] } | undefined)
    ?.topIPs;

  return (
    <div>
      <CodeBox className="flex flex-col pt-36 px-2 gap-16">
        <div
          ref={tweakpaneContainerRef}
          className="absolute top-2 right-2 opacity-90 self-end z-20"
        />
        <div className="mx-auto flex w-full max-w-[800px] items-center justify-between p-0">
          <div className="text-lg font-semibold text-black-12">人群洞察</div>
          <a
            href="#"
            className="cursor-pointer text-[13px] text-black-9 no-underline hover:text-[var(--odn-primary-color)]"
          >
            ↓ 下载数据
          </a>
        </div>
        <div className="mx-auto -mt-12 mb-4 flex w-full max-w-[800px] flex-wrap items-center gap-2">
          <select className="h-9 w-[200px] shrink-0 cursor-pointer appearance-none rounded-md border border-black-4 bg-white px-3 pr-8 text-[13px] text-black-10 outline-none hover:border-blue-6">
            <option>达人偏好、行业RO人群、品...</option>
          </select>
          <select className="h-9 w-[140px] shrink-0 cursor-pointer appearance-none rounded-md border border-black-4 bg-white px-3 pr-8 text-[13px] text-black-10 outline-none hover:border-blue-6">
            <option>按TA%排序</option>
            <option>按TGI排序</option>
          </select>
          <select className="h-9 w-[140px] shrink-0 cursor-pointer appearance-none rounded-md border border-black-4 bg-white px-3 pr-8 text-[13px] text-black-10 outline-none hover:border-blue-6">
            <option>TA% 请选择</option>
          </select>
          <select className="h-9 w-[140px] shrink-0 cursor-pointer appearance-none rounded-md border border-black-4 bg-white px-3 pr-8 text-[13px] text-black-10 outline-none hover:border-blue-6">
            <option>TGI 请选择</option>
          </select>
        </div>
        <div
          ref={wrapperRef}
          className="relative mx-auto rounded-full"
          style={{
            width: CONTAINER_SIZE,
            height: CONTAINER_SIZE,
            overflow: params.transitionType === 'big' ? 'hidden' : '',
            boxShadow:
              params.transitionType === 'big' ? '0 0 0 1px #cddeff' : '',
          }}
        >
          <motion.div
            className="absolute inset-0 rounded-full"
            onMouseMove={handleWrapperMouseMove}
            onMouseLeave={handleWrapperMouseLeave}
          >
            <motion.div
              className="absolute inset-0 rounded-full [clip-path:circle(50%)]"
              style={{
                opacity:
                  params.transitionType === 'small'
                    ? level0Opacity
                    : level0OpacityBig,
                filter: params.transitionType === 'small' ? level0Filter : '',
                scale:
                  params.transitionType === 'small'
                    ? level0Scale
                    : level0ScaleBig,
                transformOrigin:
                  params.transitionType === 'small'
                    ? ''
                    : level0TransformOriginBig,
                x: level0XBig,
                y: level0YBig,
              }}
            >
              {displayData.map((_, i) => {
                const isCurrentLayer =
                  currentHoverCategory?.parentIndex === i && popoverVisible;
                const isBackLayer =
                  currentHoverCategory?.parentIndex !== i && popoverVisible;
                return (
                  <section
                    data-index={i}
                    key={i}
                    style={{
                      opacity: isBackLayer ? 0.5 : 1,
                      '--sector-index': i,
                      '--sector-angle': 360 / displayData.length,
                      '--sector-offset': getSectorOffset(displayData.length),
                      '--sector-path': [
                        '',
                        '',
                        'polygon(0% 0%, 100% 0%, 100% 42.26%, 50% 100%, 0% 42.26%)',
                        'polygon(0% 0%, 100% 0%, 50% 100%)',
                        'polygon(13.66% 0%, 86.34% 0%, 50% 100%)',
                        'polygon(21.13% 0%, 78.87% 0%, 50% 100%)',
                      ][displayData.length - 1],
                    }}
                    className="transition-opacity duration-200"
                  >
                    <motion.div className="pointer-events-none absolute inset-0 [transform:rotate(calc(var(--sector-index)*var(--sector-angle)*1deg+var(--sector-offset)*1deg))]">
                      <div
                        className="pointer-events-auto absolute bottom-1/2 left-1/2 h-[400px] w-[800px] -translate-x-1/2 [clip-path:var(--sector-path)]"
                        onMouseEnter={(e) =>
                          handleLayerMouseEnter(e, {
                            parentIndex: i,
                          })
                        }
                        onMouseLeave={(e) =>
                          handleLayerMouseLeave(e, {
                            parentIndex: i,
                          })
                        }
                      >
                        {layer4}
                      </div>
                      <div className="pointer-events-none absolute bottom-1/2 left-1/2 h-[320px] w-[640px] -translate-x-1/2 [clip-path:var(--sector-path)]">
                        {layer3}
                      </div>
                      <div className="pointer-events-none absolute bottom-1/2 left-1/2 h-[240px] w-[480px] -translate-x-1/2 [clip-path:var(--sector-path)]">
                        {layer2}
                      </div>
                      <div className="pointer-events-none absolute bottom-1/2 left-1/2 h-[160px] w-[320px] -translate-x-1/2 [clip-path:var(--sector-path)]">
                        {isCurrentLayer ? layer1Current : layer1}
                      </div>
                    </motion.div>
                    <div className="pointer-events-none absolute inset-0 z-10 [transform:rotate(calc(var(--sector-index)*var(--sector-angle)*1deg+var(--sector-offset)*1deg))]">
                      <div className="absolute bottom-1/2 left-1/2 h-1/2 w-full -translate-x-1/2">
                        <div className="absolute bottom-0 left-1/2 h-px w-1/2 origin-left bg-[#cddeff] [transform:rotate(calc((180-var(--sector-angle))/2*-1deg))]" />
                      </div>
                    </div>
                    <motion.div className="pointer-events-none absolute inset-0 z-10 [transform:rotate(calc(var(--sector-index)*var(--sector-angle)*1deg+var(--sector-offset)*1deg))]">
                      <div
                        className="absolute left-1/2 top-[248px] flex min-h-[72px] items-center justify-center whitespace-break-spaces text-center text-base font-semibold leading-6"
                        style={{
                          transform: `translate3d(-50%, 0, 0) rotate(${isReverseTag({ parentIndex: i, totalLength: displayData.length }) ? 180 : 0}deg)`,
                          color: isCurrentLayer ? '#fff' : '#296BEF',
                        }}
                      >
                        {displayData[i].name}
                      </div>
                      {displayData[i].children.map((_, j) => (
                        <Tag
                          key={j}
                          parentIndex={i}
                          index={j}
                          onMouseEnter={handleTagMouseEnter}
                          onMouseLeave={handleTagMouseLeave}
                          onClick={handleTagClick}
                          name={displayData[i].children[j].name}
                          params={params}
                          level0PointerEvents={level0PointerEvents}
                          totalLength={displayData.length}
                        />
                      ))}
                    </motion.div>
                  </section>
                );
              })}
              <motion.div
                className="absolute left-1/2 top-1/2 z-10 flex -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border border-[#93b7ff] bg-[var(--odn-primary-color)] text-xl font-semibold leading-8 text-white shadow-[inset_0_0_24px_-8px_rgba(255,255,255,0.5)]"
                style={{
                  width: CENTER_CIRCLE_SIZE,
                  height: CENTER_CIRCLE_SIZE,
                }}
              >
                <div className="max-w-[63%] text-center">
                  年轻科技
                  <br />
                  爱好者
                </div>
              </motion.div>
              {params.transitionType === 'small' && (
                <motion.div className="pointer-events-none absolute inset-0 rounded-full border border-[#cddeff]" />
              )}
            </motion.div>
            <motion.div
              className="pointer-events-none absolute z-20 rounded-full"
              style={{
                top: TAG_OFFSET,
                left: TAG_OFFSET,
                width: TAG_SIZE,
                height: TAG_SIZE,
                x: tagHoverFillX,
                y: tagHoverFillY,
              }}
            >
              <motion.div
                className="absolute inset-0 rounded-full"
                style={{
                  opacity: tagHoverFillOpacity,
                  scale: tagHoverFillScale,
                  background: tagHoverFillBg,
                }}
              />
            </motion.div>
            <motion.div
              className="absolute inset-0 z-20 rounded-full"
              style={{
                x: tagHoverFillX,
                y: tagHoverFillY,
                pointerEvents: level1PointerEvents,
              }}
            >
              <motion.div
                className="absolute inset-0 rounded-full"
                style={{
                  border: params.transitionType === 'small' ? level1Border : '',
                  opacity: level1Opacity,
                  scale: level1Scale,
                }}
              />
              {/* 气泡 */}
              {(() => {
                return bubbles.map((bubble, bubbleIndex) => {
                  let topMarginBottom = '8px';
                  let topFontSize = '20px';
                  let nameFontSize = '16px';
                  let nameLineHeight = '24px';
                  let percentFontSize = '18px';
                  let percentLineHeight = '26px';
                  if (bubble.r < 100) {
                    topMarginBottom = '0';
                    topFontSize = '16px';
                    nameFontSize = '14px';
                    nameLineHeight = '22px';
                    percentFontSize = '16px';
                    percentLineHeight = '24px';
                  }

                  return (
                    <motion.div
                      key={`${bubble.name}-${bubbleIndex}`}
                      className="pointer-events-none absolute flex select-none flex-col items-center justify-center rounded-full bg-[radial-gradient(50%_50%_at_50%_50%,rgba(255,255,255,0.4)_0%,#ffffff_100%)]"
                      style={{
                        opacity: level1BubbleOpacity,
                        scale: level1BubbleScale,
                        transformOrigin: `${CONTAINER_SIZE / 2 - bubble.x + bubble.r}px ${CONTAINER_SIZE / 2 - bubble.y + bubble.r}px`,
                        left: `${bubble.x - bubble.r}px`,
                        top: `${bubble.y - bubble.r}px`,
                        width: `${bubble.r * 2}px`,
                        height: `${bubble.r * 2}px`,
                      }}
                    >
                      <div
                        className="bg-clip-text font-semibold leading-6 [-webkit-background-clip:text] [-webkit-text-fill-color:transparent]"
                        style={{
                          marginBottom: topMarginBottom,
                          fontSize: topFontSize,
                          backgroundImage:
                            {
                              1: 'linear-gradient(180deg, #F9CF72 0%, #EEA33A 100%)',
                              2: 'linear-gradient(180deg, #D3DAF4 0%, #A6B1D6 100%)',
                              3: 'linear-gradient(180deg, #E3D1B7 0%, #CDAB8A 100%)',
                            }[bubble.rank] ||
                            'linear-gradient(180deg, #D9D9D9 0%, #D9D9D9 100%)',
                        }}
                      >
                        TOP {bubble.rank}
                      </div>
                      <div
                        className="max-w-[80%] truncate font-semibold text-black"
                        style={{
                          fontSize: nameFontSize,
                          lineHeight: nameLineHeight,
                        }}
                      >
                        {bubble.name}
                      </div>
                      <div
                        className="font-semibold text-black"
                        style={{
                          fontSize: percentFontSize,
                          lineHeight: percentLineHeight,
                        }}
                      >
                        {bubble.percent}%
                      </div>
                      {bubble.rank <= 3 && (
                        <div
                          className="flex h-[26px] items-center justify-center rounded-[26px] bg-[rgba(41,107,239,0.1)] px-3 text-xs"
                          style={{
                            marginTop: topMarginBottom,
                          }}
                        >
                          TGI 100
                        </div>
                      )}
                    </motion.div>
                  );
                });
              })()}
              <motion.div
                className={clsx(
                  'group/back absolute left-1/2 top-1/2 z-10 -translate-x-1/2 -translate-y-1/2 cursor-pointer rounded-full',
                  animating && 'pointer-events-none',
                )}
                onClick={handleLevel1ToLevel0}
                style={{
                  width: CENTER_CIRCLE_SIZE,
                  height: CENTER_CIRCLE_SIZE,
                }}
              >
                <motion.div
                  className="absolute inset-0 rounded-full bg-[rgba(41,107,239,0.8)]"
                  style={{
                    opacity: level1Opacity,
                    scale: level1IndicatorScale,
                  }}
                >
                  <motion.div
                    className="absolute inset-0 rounded-full"
                    style={{
                      opacity: level1Progress,
                    }}
                  >
                    <motion.div className="absolute inset-0 rounded-full border border-[#93b7ff] bg-[var(--odn-primary-color)] shadow-[inset_0_0_24px_-8px_rgba(255,255,255,0.5)]" />
                    <motion.svg
                      className={clsx(
                        'absolute left-[70px] top-5 size-5 transition-all',
                        !animating && 'group-hover/back:translate-y-[5px]',
                      )}
                      viewBox="0 0 20 20"
                      fill="none"
                    >
                      <path
                        fillRule="evenodd"
                        clipRule="evenodd"
                        d="M16.5817 7.90219C16.7037 8.02423 16.7037 8.22209 16.5817 8.34413L10.2177 14.7081C10.0957 14.8301 9.89784 14.8301 9.7758 14.7081L3.41184 8.34413C3.2898 8.22209 3.2898 8.02423 3.41184 7.90219L4.4725 6.84153C4.59454 6.71949 4.7924 6.71949 4.91444 6.84153L9.99677 11.9239L15.0791 6.84153C15.2011 6.71949 15.399 6.71949 15.521 6.84153L16.5817 7.90219Z"
                        fill="white"
                        fillOpacity="0.6"
                      />
                    </motion.svg>
                    <motion.svg
                      className={clsx(
                        'absolute bottom-5 left-[70px] size-5 transition-all',
                        !animating && 'group-hover/back:-translate-y-[5px]',
                      )}
                      viewBox="0 0 20 20"
                      fill="none"
                    >
                      <path
                        fillRule="evenodd"
                        clipRule="evenodd"
                        d="M3.41965 12.0967C3.29762 11.9746 3.29762 11.7767 3.41965 11.6547L9.78361 5.29075C9.90565 5.16871 10.1035 5.16871 10.2256 5.29075L16.5895 11.6547C16.7116 11.7767 16.7116 11.9746 16.5895 12.0967L15.5289 13.1573C15.4068 13.2793 15.209 13.2793 15.0869 13.1573L10.0046 8.07498L4.92226 13.1573C4.80022 13.2793 4.60235 13.2793 4.48031 13.1573L3.41965 12.0967Z"
                        fill="white"
                        fillOpacity="0.6"
                      />
                    </motion.svg>
                    <motion.div
                      className={clsx(
                        'absolute left-1/2 top-1/2 line-clamp-2 w-[100px] -translate-x-1/2 -translate-y-1/2 overflow-hidden text-center text-xl font-semibold leading-8 text-white transition-all',
                        !animating && 'group-hover/back:scale-90',
                      )}
                    >
                      {currentTagName}
                    </motion.div>
                  </motion.div>
                </motion.div>
              </motion.div>
            </motion.div>
            <motion.div
              className="pointer-events-none absolute z-20 flex flex-col rounded-full"
              style={{
                top: TAG_OFFSET,
                left: TAG_OFFSET,
                width: TAG_SIZE,
                height: TAG_SIZE,
                x: tagHoverFillX,
                y: tagHoverFillY,
              }}
            >
              <motion.div
                className="relative z-10 mx-auto w-fit min-w-[52px] max-w-[70%] select-none pb-4 pt-5 text-[13px] leading-[22px] text-black-11"
                style={{
                  marginTop: currentTagMarginTop,
                }}
              >
                <motion.div
                  className="truncate text-center"
                  style={{
                    transformOrigin: currentTagTextPlaceholderTransformOrigin,
                    scale: level1TextPlaceholderScale,
                    opacity: level1TextPlaceholderOpacity,
                  }}
                >
                  {currentTagName}
                </motion.div>
              </motion.div>
            </motion.div>
          </motion.div>
        </div>
        {createPortal(
          <motion.div
            className="absolute left-0 top-0 z-[1030] w-[290px] rounded-md bg-white p-4 text-xs shadow-[0_0_0_1px_rgba(0,0,0,0.06)] transition-[opacity,visibility] duration-150 ease-out [filter:drop-shadow(0_3px_5px_rgba(0,0,0,0.05))_drop-shadow(0_6px_15px_rgba(0,0,0,0.05))]"
            onMouseEnter={handlePopoverMouseEnter}
            onMouseLeave={handlePopoverMouseLeave}
            style={{
              opacity: params.hasPopover && popoverVisible ? 1 : 0,
              visibility: params.hasPopover && popoverVisible ? 'visible' : 'hidden',
              x: popoverX,
              y: popoverY,
            }}
          >
            <div className="flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <div className="font-semibold">
                  {currentHoverData?.name.replace('\n', '')}
                </div>
                <div className="text-xs text-black-8">目标人群占比</div>
              </div>
              {currentHoverData?.children.map((child, childIdx) => {
                const isHighlighted = currentHoverCategory?.childIndex === childIdx;
                return (
                  <div key={child.name} className="flex items-center justify-between">
                    <div
                      className={clsx(
                        'flex-1 truncate text-black-10',
                        isHighlighted && 'font-bold text-black-12',
                      )}
                    >
                      {child.name}
                    </div>
                    <div
                      className={clsx(
                        'shrink-0 font-semibold',
                        isHighlighted && 'font-bold text-black-12',
                      )}
                    >
                      {child.percent}%
                    </div>
                  </div>
                );
              })}
              {currentHoverTopIPs && (
                <>
                  <div className="my-1 h-px bg-black-4" />
                  <div className="flex justify-center gap-4 px-0 pb-1 pt-2">
                    {currentHoverTopIPs.slice(0, 3).map((ip, idx) => (
                      <div key={ip.name} className="flex w-[72px] flex-col items-center gap-1">
                        <div className="size-14 overflow-hidden rounded-lg">
                          <img src={ip.image} alt={ip.name} className="size-full object-cover" />
                        </div>
                        <div
                          className={clsx(
                            'text-[11px] font-semibold bg-clip-text [-webkit-background-clip:text] [-webkit-text-fill-color:transparent]',
                            idx === 0 && 'bg-gradient-to-b from-[#f9cf72] to-[#eea33a]',
                            idx === 1 && 'bg-gradient-to-b from-[#d3daf4] to-[#a6b1d6]',
                            idx === 2 && 'bg-gradient-to-b from-[#e3d1b7] to-[#cdab8a]',
                          )}
                        >
                          TOP{idx + 1}
                        </div>
                        <div className="max-w-full truncate text-center text-[11px] text-black-10">
                          {ip.name}
                        </div>
                      </div>
                    ))}
                  </div>
                  <a
                    href="#"
                    className="flex cursor-pointer items-center justify-center rounded-md bg-black-2 p-2 text-xs font-semibold text-blue-6 no-underline transition-colors hover:bg-black-3"
                  >
                    洞察更多{currentHoverData?.children[currentHoverCategory?.childIndex ?? 0]?.name ?? currentHoverData?.name.replace('\n', '')} IP →
                  </a>
                </>
              )}
            </div>
          </motion.div>,
          document.body,
        )}
      </CodeBox>
    </div>
  );
};

export default Basics;
```
## 案例 3：词云 {#word-cloud}

基于 `d3-cloud` 实现词云。为适配长文本，提供了双行展示的能力：

**示例：word-cloud** — word-cloud

```tsx
'use client';

import * as d3 from 'd3';
import cloud from 'd3-cloud';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';
import { words as data } from './words';

export interface WordCloudData {
  text: string;
  value: number;
}

interface CloudWord extends cloud.Word {
  text?: string;
  size?: number;
  x?: number;
  y?: number;
  rotate?: number;
  tier?: number;
  originalText?: string; // 原始完整文本
  lineCount?: number; // 行数
  realFontSize?: number; // 真实字号
}

const WordCloud = () => {
  const [width, setWidth] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);
  const svgRef = useRef<SVGSVGElement>(null);
  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);
  const [layoutWords, setLayoutWords] = useState<CloudWord[]>([]);

  const [params, setParams] = useState({
    tier1: 40,
    tier2: 32,
    tier3: 24,
    tier4: 16,
    tier5: 14,
    tier6: 12,
    padding: 2,
    enableWrapping: true, // 是否启用换行
    showVirtual: false,
    // 一级标题参数
    tier1MaxCharsPerLine: 8,
    tier1VerticalOffset: -16,
    tier1LineHeight: 1,
    tier1FontSizeMultiplier: 2.1,
    // 二级标题参数
    tier2MaxCharsPerLine: 6,
    tier2VerticalOffset: -14,
    tier2LineHeight: 1,
    tier2FontSizeMultiplier: 2.1,
    // 三级标题参数
    tier3MaxCharsPerLine: 8,
    tier3VerticalOffset: -9,
    tier3LineHeight: 1,
    tier3FontSizeMultiplier: 2.1,
    // 四级标题参数
    tier4MaxCharsPerLine: 8,
    tier4VerticalOffset: -7,
    tier4LineHeight: 1,
    tier4FontSizeMultiplier: 2.1,
    // 五级标题参数
    tier5MaxCharsPerLine: 8,
    tier5VerticalOffset: -6,
    tier5LineHeight: 1,
    tier5FontSizeMultiplier: 2.1,
    // 六级标题参数
    tier6MaxCharsPerLine: 8,
    tier6VerticalOffset: -5,
    tier6LineHeight: 1,
    tier6FontSizeMultiplier: 2.1,
  });

  useEffect(() => {
    if (containerRef.current) {
      const observer = new ResizeObserver((entries) => {
        for (const entry of entries) {
          setWidth(entry.contentRect.width);
        }
      });
      observer.observe(containerRef.current);
      return () => observer.disconnect();
    }
  }, []);

  // 词分级函数
  const getWordTier = (index: number): number => {
    if (index === 0) return 1; // 第1名：一级
    if (index <= 3) return 2; // 第2-4名：二级 (3个)
    if (index <= 8) return 3; // 第5-9名：三级 (5个)
    if (index <= 15) return 4; // 第10-16名：四级 (7个)
    if (index <= 24) return 5; // 第17-25名：五级 (9个)
    return 6; // 其余：六级
  };

  const getTierFontSize = (tier: number): number => {
    const tierSizes: Record<number, number> = {
      1: params.tier1,
      2: params.tier2,
      3: params.tier3,
      4: params.tier4,
      5: params.tier5,
      6: params.tier6,
    };
    return tierSizes[tier] || 12;
  };

  const getTierColor = (tier: number): string => {
    const tierColors: Record<number, string> = {
      1: '#296BEF', // 一级：蓝色
      2: '#6997F4', // 二级：浅蓝色
      3: '#33D2CB', // 三级：青色
      4: '#FCB04C', // 四级：橙色
      5: '#8B8DFB', // 五级：紫色
      6: '#BABCC1', // 六级：灰色
    };
    return tierColors[tier] || '#BABCC1';
  };

  const getTierFontWeight = (tier: number): number => {
    return tier <= 2 ? 600 : 400; // 一级和二级使用600，其他使用400
  };

  // 计算字符宽度（中文=1，英文/数字=0.5）
  const getCharWidth = (char: string): number => {
    const code = char.charCodeAt(0);
    // ASCII 字符（英文、数字、符号等）占 0.5 宽度
    if (code < 128) {
      return 0.5;
    }
    // 中文及其他宽字符占 1 宽度
    return 1;
  };

  // 计算文本总宽度
  const getTextWidth = (text: string): number => {
    let width = 0;
    for (let i = 0; i < text.length; i++) {
      width += getCharWidth(text[i]);
    }
    return width;
  };

  // 将文本按照宽度拆分成多行
  const splitTextByWidth = (text: string, maxWidth: number): string[] => {
    const lines: string[] = [];
    let currentLine = '';
    let currentWidth = 0;

    for (let i = 0; i < text.length; i++) {
      const char = text[i];
      const charWidth = getCharWidth(char);

      if (currentWidth + charWidth > maxWidth && currentLine.length > 0) {
        // 当前行已满，开始新行
        lines.push(currentLine);
        currentLine = char;
        currentWidth = charWidth;
      } else {
        currentLine += char;
        currentWidth += charWidth;
      }
    }

    if (currentLine.length > 0) {
      lines.push(currentLine);
    }

    return lines;
  };

  // 初始化 tweakpane
  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    pane.addBinding(params, 'padding', {
      label: '间距',
      min: 0,
      max: 10,
      step: 1,
    });

    pane.addBinding(params, 'enableWrapping', {
      label: '启用换行',
    });

    pane.addBinding(params, 'showVirtual', {
      label: '显示虚拟文本',
    });

    // 一级标题设置
    const tier1Folder = pane.addFolder({
      title: '一级标题',
      expanded: false,
    });

    tier1Folder.addBinding(params, 'tier1MaxCharsPerLine', {
      label: '每行字数',
      min: 6,
      max: 10,
      step: 1,
    });

    tier1Folder.addBinding(params, 'tier1FontSizeMultiplier', {
      label: '字号放大倍数',
      min: 1,
      max: 5,
      step: 0.1,
    });

    tier1Folder.addBinding(params, 'tier1VerticalOffset', {
      label: '垂直偏移',
      min: -20,
      max: 20,
      step: 1,
    });

    tier1Folder.addBinding(params, 'tier1LineHeight', {
      label: '行高',
      min: 1,
      max: 2,
      step: 0.05,
    });

    // 二级标题设置
    const tier2Folder = pane.addFolder({
      title: '二级标题',
      expanded: false,
    });

    tier2Folder.addBinding(params, 'tier2MaxCharsPerLine', {
      label: '每行字数',
      min: 4,
      max: 8,
      step: 1,
    });

    tier2Folder.addBinding(params, 'tier2FontSizeMultiplier', {
      label: '字号放大倍数',
      min: 1,
      max: 5,
      step: 0.1,
    });

    tier2Folder.addBinding(params, 'tier2VerticalOffset', {
      label: '垂直偏移',
      min: -20,
      max: 20,
      step: 1,
    });

    tier2Folder.addBinding(params, 'tier2LineHeight', {
      label: '行高',
      min: 1,
      max: 2,
      step: 0.05,
    });

    // 三级标题设置
    const tier3Folder = pane.addFolder({
      title: '三级标题',
      expanded: false,
    });

    tier3Folder.addBinding(params, 'tier3MaxCharsPerLine', {
      label: '每行字数',
      min: 4,
      max: 8,
      step: 1,
    });

    tier3Folder.addBinding(params, 'tier3FontSizeMultiplier', {
      label: '字号放大倍数',
      min: 1,
      max: 5,
      step: 0.1,
    });

    tier3Folder.addBinding(params, 'tier3VerticalOffset', {
      label: '垂直偏移',
      min: -20,
      max: 20,
      step: 1,
    });

    tier3Folder.addBinding(params, 'tier3LineHeight', {
      label: '行高',
      min: 1,
      max: 2,
      step: 0.05,
    });

    // 四级标题设置
    const tier4Folder = pane.addFolder({
      title: '四级标题',
      expanded: false,
    });

    tier4Folder.addBinding(params, 'tier4MaxCharsPerLine', {
      label: '每行字数',
      min: 4,
      max: 8,
      step: 1,
    });

    tier4Folder.addBinding(params, 'tier4FontSizeMultiplier', {
      label: '字号放大倍数',
      min: 1,
      max: 5,
      step: 0.1,
    });

    tier4Folder.addBinding(params, 'tier4VerticalOffset', {
      label: '垂直偏移',
      min: -20,
      max: 20,
      step: 1,
    });

    tier4Folder.addBinding(params, 'tier4LineHeight', {
      label: '行高',
      min: 1,
      max: 2,
      step: 0.05,
    });

    // 五级标题设置
    const tier5Folder = pane.addFolder({
      title: '五级标题',
      expanded: false,
    });

    tier5Folder.addBinding(params, 'tier5MaxCharsPerLine', {
      label: '每行字数',
      min: 4,
      max: 8,
      step: 1,
    });

    tier5Folder.addBinding(params, 'tier5FontSizeMultiplier', {
      label: '字号放大倍数',
      min: 1,
      max: 5,
      step: 0.1,
    });

    tier5Folder.addBinding(params, 'tier5VerticalOffset', {
      label: '垂直偏移',
      min: -20,
      max: 20,
      step: 1,
    });

    tier5Folder.addBinding(params, 'tier5LineHeight', {
      label: '行高',
      min: 1,
      max: 2,
      step: 0.05,
    });

    // 六级标题设置
    const tier6Folder = pane.addFolder({
      title: '六级标题',
      expanded: false,
    });

    tier6Folder.addBinding(params, 'tier6MaxCharsPerLine', {
      label: '每行字数',
      min: 4,
      max: 8,
      step: 1,
    });

    tier6Folder.addBinding(params, 'tier6FontSizeMultiplier', {
      label: '字号放大倍数',
      min: 1,
      max: 5,
      step: 0.1,
    });

    tier6Folder.addBinding(params, 'tier6VerticalOffset', {
      label: '垂直偏移',
      min: -20,
      max: 20,
      step: 1,
    });

    tier6Folder.addBinding(params, 'tier6LineHeight', {
      label: '行高',
      min: 1,
      max: 2,
      step: 0.05,
    });

    const folder = pane.addFolder({
      title: '字号设置',
      expanded: false,
    });

    folder.addBinding(params, 'tier1', {
      label: '一级',
      min: 12,
      max: 40,
      step: 1,
    });

    folder.addBinding(params, 'tier2', {
      label: '二级',
      min: 12,
      max: 40,
      step: 1,
    });

    folder.addBinding(params, 'tier3', {
      label: '三级',
      min: 12,
      max: 40,
      step: 1,
    });

    folder.addBinding(params, 'tier4', {
      label: '四级',
      min: 12,
      max: 40,
      step: 1,
    });

    folder.addBinding(params, 'tier5', {
      label: '五级',
      min: 12,
      max: 40,
      step: 1,
    });

    folder.addBinding(params, 'tier6', {
      label: '六级',
      min: 12,
      max: 40,
      step: 1,
    });

    return () => {
      pane.dispose();
    };
  }, []);

  // 计算词云布局（不依赖显示模式）
  useEffect(() => {
    if (width === 0) return;

    const height = 255;

    // 按 value 降序排序，并添加 tier 信息
    const sortedData = [...data].sort((a, b) => b.value - a.value);
    const wordsWithTier: CloudWord[] = sortedData.map((word, index) => {
      const tier = getWordTier(index);
      const originalText = word.text;
      const fontSize = getTierFontSize(tier);

      // 对所有 tier 处理换行（仅在启用换行时）
      if (params.enableWrapping && tier >= 1 && tier <= 6) {
        const maxCharsPerLine =
          tier === 1
            ? params.tier1MaxCharsPerLine
            : tier === 2
              ? params.tier2MaxCharsPerLine
              : tier === 3
                ? params.tier3MaxCharsPerLine
                : tier === 4
                  ? params.tier4MaxCharsPerLine
                  : tier === 5
                    ? params.tier5MaxCharsPerLine
                    : params.tier6MaxCharsPerLine;
        const fontSizeMultiplier =
          tier === 1
            ? params.tier1FontSizeMultiplier
            : tier === 2
              ? params.tier2FontSizeMultiplier
              : tier === 3
                ? params.tier3FontSizeMultiplier
                : tier === 4
                  ? params.tier4FontSizeMultiplier
                  : tier === 5
                    ? params.tier5FontSizeMultiplier
                    : params.tier6FontSizeMultiplier;

        // 计算行数（考虑中英文字符宽度）
        const textWidth = getTextWidth(originalText);
        const lineCount = Math.ceil(textWidth / maxCharsPerLine);

        // 只有当需要多行时才使用虚拟文本
        if (lineCount > 1) {
          // 虚拟字号：放大倍数可调，用于欺骗 d3-cloud 预留更多空间
          // 虚拟文本的字数要相应调整，保持宽度匹配
          const virtualFontSize = fontSize * fontSizeMultiplier;
          const virtualCharCount = Math.ceil(
            maxCharsPerLine / fontSizeMultiplier,
          );
          const virtualText = '测'.repeat(virtualCharCount);

          return {
            text: virtualText,
            originalText,
            size: virtualFontSize,
            tier,
            lineCount,
            realFontSize: fontSize, // 保存真实字号
          };
        }
        // 单行文本保持原样
      }

      // 其他标题保持原样
      return {
        text: originalText,
        originalText,
        size: fontSize,
        tier,
        lineCount: 1,
        realFontSize: fontSize,
      };
    });

    const layout = cloud<CloudWord>()
      .size([width, height])
      .words(wordsWithTier)
      .padding(params.padding)
      .rotate(0)
      .font('PingFang SC')
      .fontSize((d) => d.size || 12)
      .random(() => 0.5)
      .on('end', (words) => {
        setLayoutWords(words);
      });

    layout.start();
  }, [
    width,
    data,
    params.tier1,
    params.tier2,
    params.tier3,
    params.tier4,
    params.tier5,
    params.tier6,
    params.padding,
    params.enableWrapping,
    params.tier1MaxCharsPerLine,
    params.tier1FontSizeMultiplier,
    params.tier2MaxCharsPerLine,
    params.tier2FontSizeMultiplier,
    params.tier3MaxCharsPerLine,
    params.tier3FontSizeMultiplier,
    params.tier4MaxCharsPerLine,
    params.tier4FontSizeMultiplier,
    params.tier5MaxCharsPerLine,
    params.tier5FontSizeMultiplier,
    params.tier6MaxCharsPerLine,
    params.tier6FontSizeMultiplier,
  ]);

  // 渲染词云（依赖布局结果和显示模式）
  useEffect(() => {
    if (!svgRef.current || layoutWords.length === 0 || width === 0) return;

    const height = 255;

    // 清空之前的内容
    d3.select(svgRef.current).selectAll('*').remove();

    const svg = d3
      .select(svgRef.current)
      .attr('width', width)
      .attr('height', height)
      .append('g')
      .attr('transform', `translate(${width / 2},${height / 2})`);

    const textElements = svg
      .selectAll('text')
      .data(layoutWords)
      .enter()
      .append('text')
      .attr('text-anchor', 'middle')
      .attr('transform', (d) => `translate(${d.x},${d.y})rotate(${d.rotate})`);

    // 为每个文本元素添加内容
    textElements.each(function (d) {
      const text = d3.select(this);
      const tier = d.tier || 6;
      const lineCount = d.lineCount || 1;
      const originalText = d.originalText || '';

      // 调试模式：显示虚拟文本
      if (params.showVirtual && tier >= 1 && tier <= 6) {
        text
          .style('font-size', `${d.size}px`)
          .style('font-family', 'PingFang SC')
          .style('font-weight', getTierFontWeight(tier))
          .style('fill', getTierColor(tier))
          .text(d.text || '');
        return;
      }

      // 所有 tier：只有启用换行且多行时使用 tspan 分行
      if (params.enableWrapping && tier >= 1 && tier <= 6 && lineCount > 1) {
        const maxCharsPerLine =
          tier === 1
            ? params.tier1MaxCharsPerLine
            : tier === 2
              ? params.tier2MaxCharsPerLine
              : tier === 3
                ? params.tier3MaxCharsPerLine
                : tier === 4
                  ? params.tier4MaxCharsPerLine
                  : tier === 5
                    ? params.tier5MaxCharsPerLine
                    : params.tier6MaxCharsPerLine;
        const lineHeight =
          tier === 1
            ? params.tier1LineHeight
            : tier === 2
              ? params.tier2LineHeight
              : tier === 3
                ? params.tier3LineHeight
                : tier === 4
                  ? params.tier4LineHeight
                  : tier === 5
                    ? params.tier5LineHeight
                    : params.tier6LineHeight;
        const verticalOffset =
          tier === 1
            ? params.tier1VerticalOffset
            : tier === 2
              ? params.tier2VerticalOffset
              : tier === 3
                ? params.tier3VerticalOffset
                : tier === 4
                  ? params.tier4VerticalOffset
                  : tier === 5
                    ? params.tier5VerticalOffset
                    : params.tier6VerticalOffset;

        // 使用保存的真实字号
        const realFontSize = d.realFontSize || getTierFontSize(tier);

        // 按宽度拆分文本（考虑中英文字符宽度）
        const lines = splitTextByWidth(originalText, maxCharsPerLine);

        // 计算居中
        const totalHeight = lines.length * realFontSize * lineHeight;
        const startY = -totalHeight / 2 + realFontSize / 2 + verticalOffset;

        lines.forEach((line, i) => {
          text
            .append('tspan')
            .attr('x', 0)
            .attr('dy', i === 0 ? startY : realFontSize * lineHeight)
            .style('font-size', `${realFontSize}px`)
            .style('font-family', 'PingFang SC')
            .style('font-weight', getTierFontWeight(tier))
            .style('fill', getTierColor(tier))
            .text(line);
        });
      } else {
        // 单行显示（包括一级/二级的单行情况和其他标题）
        text
          .style('font-size', `${d.size}px`)
          .style('font-family', 'PingFang SC')
          .style('font-weight', getTierFontWeight(tier))
          .style('fill', getTierColor(tier))
          .text(originalText);
      }
    });
  }, [
    width,
    layoutWords,
    params.enableWrapping,
    params.showVirtual,
    params.tier1MaxCharsPerLine,
    params.tier1LineHeight,
    params.tier1VerticalOffset,
    params.tier2MaxCharsPerLine,
    params.tier2LineHeight,
    params.tier2VerticalOffset,
    params.tier3MaxCharsPerLine,
    params.tier3LineHeight,
    params.tier3VerticalOffset,
    params.tier4MaxCharsPerLine,
    params.tier4LineHeight,
    params.tier4VerticalOffset,
    params.tier5MaxCharsPerLine,
    params.tier5LineHeight,
    params.tier5VerticalOffset,
    params.tier6MaxCharsPerLine,
    params.tier6LineHeight,
    params.tier6VerticalOffset,
  ]);

  return (
    <div>
      <CodeBox className="flex flex-col justify-center items-center pt-2">
        <div
          ref={tweakpaneContainerRef}
          className="mb-10 self-end opacity-90 -mr-3"
        />
        <div className="w-full h-[255px]" ref={containerRef}>
          <svg ref={svgRef} />
        </div>
      </CodeBox>
    </div>
  );
};

export default WordCloud;
```
## 案例 4: 图谱 {#treemap}

基于 `d3` 的 `treemap` 实现图谱：

**示例：treemap** — treemap

```tsx
'use client';

import * as d3 from 'd3';
import { Popover } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import './treemap.css';

interface TreemapData {
  name: string;
  value: number;
  originalValue?: number; // 原始数值（用于显示）
  change?: number; // 百分比变化，正数表示上升，负数表示下降
}

type HierarchyData = { children: TreemapData[] } | TreemapData;

// 2组静态预设数据
const dataSet1: TreemapData[] = [
  { name: '行业地位', value: 18000000, change: 12.5 },
  { name: '专利保障', value: 17500000, change: -8.3 },
  { name: '科技领先', value: 16500000, change: 0 },
  { name: '设计领先', value: 15500000, change: 5.2 },
  { name: '国货品牌', value: 15000000, change: 0 },
  { name: '国际大牌', value: 14500000, change: -15.6 },
  { name: '品牌历史', value: 14000000, change: 0 },
  { name: '明星代言', value: 13500000, change: 22.1 },
  { name: 'IP联名', value: 13000000, change: 0 },
  { name: '品牌自有IP', value: 12500000, change: -3.4 },
  { name: '声量领先', value: 1500000, change: 0 },
  { name: '销量领先', value: 1400000, change: 18.7 },
  { name: '用户口碑', value: 1300000, change: 0 },
  { name: '国家认证', value: 1200000, change: -12.3 },
  { name: '政策权益', value: 1100000, change: 0 },
  { name: '企业权益', value: 1000000, change: 9.8 },
  { name: '线上权益', value: 950000, change: 0 },
  { name: '到店权益', value: 900000, change: -6.5 },
  { name: '退换维保', value: 850000, change: 0 },
  { name: '保价比价', value: 800000, change: 14.2 },
  { name: '售前试用', value: 750000, change: 0 },
  { name: '泛家用', value: 700000, change: 0 },
  { name: '高端品质', value: 650000, change: -4.1 },
  { name: '健康生活', value: 600000, change: 0 },
  { name: '刚需实用', value: 550000, change: 7.3 },
  { name: '美学追求', value: 500000, change: 0 },
  { name: '线下音乐活动冠名', value: 450000, change: -11.2 },
  { name: '赛事赞助', value: 500, change: 0 },
  { name: '剧综植入', value: 400, change: 16.8 },
  { name: '观影追剧娱乐', value: 300, change: 0 },
];

const Demo = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const wrapperRef = useRef<HTMLDivElement>(null);

  const [scale, setScale] = useState(1);

  const hoverTimer = useRef(0);
  const [currentHoverCellData, setCurrentHoverCellData] =
    useState<TreemapData | null>(null);
  const [offset, setOffset] = useState<[number, number]>([0, 0]);

  const onCellMouseEnter = (cellData: TreemapData, el: HTMLDivElement) => {
    clearTimeout(hoverTimer.current);
    const { right, top } = el.getBoundingClientRect();
    let offset: [number, number] = [0, 0];

    if (wrapperRef.current) {
      const { right: wrapperRight, top: wrapperTop } =
        wrapperRef.current.getBoundingClientRect();
      offset = [right - wrapperRight, top - wrapperTop];
    }

    setCurrentHoverCellData({ ...cellData });
    setOffset(offset);
  };

  const onCellMouseLeave = () => {
    clearTimeout(hoverTimer.current);
    hoverTimer.current = window.setTimeout(() => {
      setCurrentHoverCellData(null);
    }, 200);
  };

  const onCellClick = (cellData: TreemapData) => {
    console.log('Cell clicked:', cellData);
  };

  // ResizeObserver 监听容器尺寸变化，计算缩放比例
  useEffect(() => {
    if (!containerRef.current) return;

    const baseWidth = 1176;
    const baseHeight = 552;

    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width, height } = entry.contentRect;
        // 计算宽高比例，取较小值确保完全显示
        const scaleX = width / baseWidth;
        const scaleY = height / baseHeight;
        const newScale = Math.min(scaleX, scaleY);
        setScale(newScale);
      }
    });

    resizeObserver.observe(containerRef.current);

    return () => {
      resizeObserver.disconnect();
    };
  }, []);

  useEffect(() => {
    if (!containerRef.current || !wrapperRef.current) return;

    const width = 1176;
    const height = 552;

    const data = dataSet1;

    const targetMinWidth = 98;
    const targetMinHeight = 46;
    const targetMinArea = targetMinWidth * targetMinHeight;

    let finalTargetRatio = 0; // 自动计算

    // 自动计算最优值
    const minValue = Math.min(...data.map((d) => d.value));
    const maxValue = Math.max(...data.map((d) => d.value));

    // 先用原始数据测试最小块尺寸
    let testData = data.map((item) => ({
      ...item,
      originalValue: item.value,
      value: Math.max(0.001, item.value),
    }));

    let testRoot = d3
      .hierarchy({ children: testData } as HierarchyData)
      .sum((d) => {
        if ('children' in d) return 0;
        const val = d.value;
        return isFinite(val) && val > 0 ? val : 0.001;
      })
      .sort((a, b) => (b.value || 0) - (a.value || 0));

    const testTreemap = d3
      .treemap<HierarchyData>()
      .size([width, height])
      .padding(4)
      .round(true);

    testTreemap(testRoot);

    const testLeaves =
      testRoot.leaves() as d3.HierarchyRectangularNode<HierarchyData>[];
    let testMinWidth = Infinity;
    let testMinHeight = Infinity;

    testLeaves.forEach((node) => {
      const w = node.x1 - node.x0;
      const h = node.y1 - node.y0;
      if (w > 0 && w < testMinWidth) testMinWidth = w;
      if (h > 0 && h < testMinHeight) testMinHeight = h;
    });

    // 如果原始数据的最小块未达到目标,二分查找合适的 targetRatio
    if (
      !(
        testMinWidth >= targetMinWidth &&
        testMinHeight >= targetMinHeight &&
        isFinite(testMinWidth) &&
        isFinite(testMinHeight)
      )
    ) {
      let low = 0;
      let high = 0.95;
      finalTargetRatio = 0.5; // 初始值

      for (let searchIter = 0; searchIter < 10; searchIter++) {
        const testRatio = (low + high) / 2;
        const testBaseValue = Math.max(
          0,
          (testRatio * maxValue - minValue) / (1 - testRatio),
        );

        const testAdjustedData = data.map((item) => ({
          ...item,
          originalValue: item.value,
          value: Math.max(0.001, item.value + testBaseValue),
        }));

        testRoot = d3
          .hierarchy({ children: testAdjustedData } as HierarchyData)
          .sum((d) => {
            if ('children' in d) return 0;
            const val = d.value;
            return isFinite(val) && val > 0 ? val : 0.001;
          })
          .sort((a, b) => (b.value || 0) - (a.value || 0));

        testTreemap(testRoot);

        const testLeaves2 =
          testRoot.leaves() as d3.HierarchyRectangularNode<HierarchyData>[];
        let testMinWidth2 = Infinity;
        let testMinHeight2 = Infinity;

        testLeaves2.forEach((node) => {
          const w = node.x1 - node.x0;
          const h = node.y1 - node.y0;
          if (w > 0 && w < testMinWidth2) testMinWidth2 = w;
          if (h > 0 && h < testMinHeight2) testMinHeight2 = h;
        });

        if (
          testMinWidth2 >= targetMinWidth &&
          testMinHeight2 >= targetMinHeight &&
          isFinite(testMinWidth2) &&
          isFinite(testMinHeight2)
        ) {
          // 这个 ratio 可以,尝试更小的
          finalTargetRatio = testRatio;
          high = testRatio;
        } else {
          // 这个 ratio 不够,需要更大的
          low = testRatio;
        }

        if (high - low < 0.01) break; // 精度足够,退出
      }
    } else {
      // 原始数据已经满足要求，不需要压缩
      finalTargetRatio = 0;
    }

    // 根据计算出的 targetRatio 压缩差距
    let adjustedData = data.map((item) => ({
      ...item,
      originalValue: item.value,
      value: item.value,
    }));

    // 应用 targetRatio
    if (finalTargetRatio > 0 && finalTargetRatio < 1) {
      const baseValue = Math.max(
        0,
        (finalTargetRatio * maxValue - minValue) / (1 - finalTargetRatio),
      );

      adjustedData = adjustedData.map((item) => ({
        ...item,
        value: item.value + baseValue,
      }));
    }

    // 确保所有 value 都是有效的正数
    adjustedData = adjustedData.map((item) => ({
      ...item,
      value: Math.max(0.001, item.value || 0.001), // 确保至少有一个很小的正值
    }));

    let root = d3
      .hierarchy({ children: adjustedData } as HierarchyData)
      .sum((d) => {
        if ('children' in d) return 0;
        const val = d.value;
        return isFinite(val) && val > 0 ? val : 0.001;
      })
      .sort((a, b) => (b.value || 0) - (a.value || 0));

    const treemap = d3
      .treemap<HierarchyData>()
      .size([width, height])
      .padding(4)
      .round(true);

    // 迭代最多 5 次，找到最小块达到目标尺寸的数据
    for (let iter = 0; iter < 5; iter++) {
      treemap(root);

      const leaves =
        root.leaves() as d3.HierarchyRectangularNode<HierarchyData>[];

      // 找出最小块的宽高
      let minWidth = Infinity;
      let minHeight = Infinity;
      let minArea = Infinity;

      leaves.forEach((node) => {
        const w = node.x1 - node.x0;
        const h = node.y1 - node.y0;
        const area = w * h;
        if (w > 0 && w < minWidth) minWidth = w;
        if (h > 0 && h < minHeight) minHeight = h;
        if (area > 0 && area < minArea) minArea = area;
      });

      // 如果最小块已经达到目标，退出
      if (
        minWidth >= targetMinWidth &&
        minHeight >= targetMinHeight &&
        isFinite(minWidth) &&
        isFinite(minHeight)
      ) {
        break;
      }

      // 检查是否有有效的尺寸
      if (!isFinite(minWidth) || !isFinite(minHeight) || minArea <= 0) {
        break; // 无法继续调整，退出
      }

      // 计算需要的缩放因子（基于面积）
      const areaScale = targetMinArea / minArea;
      if (!isFinite(areaScale) || areaScale <= 0) {
        break; // 无效的缩放因子，退出
      }

      const scaleFactor = Math.sqrt(areaScale);
      if (!isFinite(scaleFactor) || scaleFactor <= 0) {
        break; // 无效的缩放因子，退出
      }

      // 使用乘法缩放所有数据的 value，保持比例不变
      // 这样可以保持 targetRatio 压缩后的比例关系
      adjustedData = adjustedData.map((item) => ({
        ...item,
        value: Math.max(0.001, (item.value || 0) * scaleFactor),
      }));

      // 重新创建 hierarchy
      root = d3
        .hierarchy({ children: adjustedData } as HierarchyData)
        .sum((d) => {
          if ('children' in d) return 0;
          const val = d.value;
          return isFinite(val) && val > 0 ? val : 0.001;
        })
        .sort((a, b) => (b.value || 0) - (a.value || 0));
    }

    // 最终生成 treemap
    treemap(root);

    // 清空容器
    const container = d3.select(wrapperRef.current);
    container.selectAll('*').remove();

    // 设置容器样式
    container
      .style('position', 'relative')
      .style('width', `${width}px`)
      .style('height', `${height}px`);

    const leaves =
      root.leaves() as d3.HierarchyRectangularNode<HierarchyData>[];

    // 创建单元格
    const cells = container
      .selectAll('div.xinzhi-cell')
      .data(leaves)
      .enter()
      .append('div')
      .attr('class', 'xinzhi-cell')
      .style('left', (d) => `${d.x0}px`)
      .style('top', (d) => `${d.y0}px`)
      .style('width', (d) => `${d.x1 - d.x0}px`)
      .style('height', (d) => `${d.y1 - d.y0}px`)
      .style('cursor', 'pointer')
      .on('click', function (event, d) {
        const node = d as d3.HierarchyRectangularNode<HierarchyData>;
        const cellData = node.data as TreemapData;
        onCellClick(cellData);
      })
      .on('mouseenter', function (event, d) {
        const node = d as d3.HierarchyRectangularNode<HierarchyData>;
        const cellData = node.data as TreemapData;
        const el = this as HTMLDivElement;
        onCellMouseEnter(cellData, el);
      })
      .on('mouseleave', function (event, d) {
        onCellMouseLeave();
      });

    // 添加文本内容
    cells.each(function (d) {
      const cell = d3.select(this);
      const node = d as d3.HierarchyRectangularNode<HierarchyData>;
      const cellData = node.data as TreemapData;

      // 创建内容容器
      const contentWrapper = cell
        .append('div')
        .attr('class', 'xinzhi-cell-content');

      // 名称（使用 CSS 截断）
      contentWrapper
        .append('div')
        .attr('class', 'xinzhi-cell-name')
        .text(cellData.name);

      // 数值和百分比变化在同一行
      const valueRow = contentWrapper
        .append('div')
        .attr('class', 'xinzhi-cell-value-wrapper');

      // 数值（如果显示）
      if (true) {
        valueRow
          .append('div')
          .attr('class', 'xinzhi-cell-value')
          .text((cellData.originalValue || cellData.value).toLocaleString());
      }

      // 百分比变化（所有数据都有 change，显示与否由边界检测控制）
      if (cellData.change !== undefined) {
        const isPositive = cellData.change > 0;
        const changeContainer = valueRow
          .append('div')
          .attr(
            'class',
            `xinzhi-cell-change ${isPositive ? 'xinzhi-cell-change-positive' : 'xinzhi-cell-change-negative'}`,
          );

        // 添加 SVG 图标
        const svg = changeContainer
          .append('svg')
          .attr('width', '14')
          .attr('height', '14')
          .attr('viewBox', '0 0 14 14');

        if (isPositive) {
          svg
            .append('path')
            .attr(
              'd',
              'M10.3721 5.81543L9.75293 6.43359L7.4375 4.11816V11.375H6.5625V4.11816L4.24707 6.43359L3.62793 5.81543L7 2.44336L10.3721 5.81543Z',
            )
            .attr('fill', 'currentColor');
        } else {
          svg
            .append('path')
            .attr(
              'd',
              'M7.4375 9.88086L9.75293 7.56543L10.3721 8.18457L7 11.5566L3.62793 8.18457L4.24707 7.56543L6.5625 9.88086V2.625H7.4375V9.88086Z',
            )
            .attr('fill', 'currentColor');
        }

        // 添加百分比文本
        changeContainer
          .append('span')
          .text(`${Math.abs(cellData.change).toFixed(2)}%`);
      }

      // 添加 hover 图标
      const hoverIcon = cell.append('div').attr('class', 'xinzhi-cell-hover');

      hoverIcon
        .append('svg')
        .attr('width', '16')
        .attr('height', '16')
        .attr('viewBox', '0 0 16 16')
        .attr('fill', 'none')
        .attr('xmlns', 'http://www.w3.org/2000/svg')
        .append('path')
        .attr('fill-rule', 'evenodd')
        .attr('clip-rule', 'evenodd')
        .attr(
          'd',
          'M7.91637 3.2276C7.81874 3.12996 7.81874 2.97167 7.91637 2.87404L8.26992 2.52049C8.36755 2.42286 8.52585 2.42286 8.62348 2.52049L13.5732 7.47024L13.9268 7.82379C14.0244 7.92142 14.0244 8.07971 13.9268 8.17734L13.5732 8.5309L8.62348 13.4806C8.52584 13.5783 8.36755 13.5783 8.26992 13.4806L7.91637 13.1271C7.81874 13.0295 7.81874 12.8712 7.91637 12.7735L12.1893 8.50057H2.35357C2.2155 8.50057 2.10357 8.38864 2.10357 8.25057V7.75057C2.10357 7.61249 2.2155 7.50057 2.35357 7.50057H12.1893L7.91637 3.2276Z',
        )
        .attr('fill', '#262729')
        .attr('fill-opacity', '0.85');
    });

    // 检测并隐藏超出 xinzhi-cell 边界的元素
    // 使用 requestAnimationFrame 确保 DOM 完全渲染后再检测
    requestAnimationFrame(() => {
      if (wrapperRef.current) {
        // 辅助函数：检查元素是否超出容器边界
        const checkElementBounds = (
          element: HTMLElement,
          cellContainer: HTMLElement,
        ) => {
          const elementRect = element.getBoundingClientRect();
          const cellRect = cellContainer.getBoundingClientRect();

          // 检查元素是否完全在 xinzhi-cell 容器内
          // 如果有任何部分超出容器边界，则隐藏
          const isFullyInside =
            elementRect.left >= cellRect.left &&
            elementRect.right <= cellRect.right &&
            elementRect.top >= cellRect.top &&
            elementRect.bottom <= cellRect.bottom;

          if (!isFullyInside) {
            element.style.display = 'none';
          } else {
            element.style.display = '';
          }
        };

        // 先检测 xinzhi-cell-change
        const changeElements = wrapperRef.current.querySelectorAll(
          '.xinzhi-cell-change',
        ) as NodeListOf<HTMLDivElement>;

        changeElements.forEach((element) => {
          const cellContainer = element.closest('.xinzhi-cell') as HTMLElement;
          if (cellContainer) {
            checkElementBounds(element, cellContainer);
          }
        });

        // 再检测 xinzhi-cell-value
        const valueElements = wrapperRef.current.querySelectorAll(
          '.xinzhi-cell-value',
        ) as NodeListOf<HTMLDivElement>;

        valueElements.forEach((element) => {
          const cellContainer = element.closest('.xinzhi-cell') as HTMLElement;
          if (cellContainer) {
            checkElementBounds(element, cellContainer);

            // 如果 xinzhi-cell-value 被隐藏了，则隐藏同 cell 内的 xinzhi-cell-change
            if (element.style.display === 'none') {
              const changeElement = cellContainer.querySelector(
                '.xinzhi-cell-change',
              ) as HTMLElement;
              if (changeElement) {
                changeElement.style.display = 'none';
              }
            }
          }
        });
      }
    });
  }, []);

  return (
    <CodeBox>
      <div className="relative w-full aspect-[1176/552]" ref={containerRef}>
        <div
          className="absolute top-1/2 left-1/2 w-[1176px] h-[552px] bg-white"
          style={{
            // transform: `translate(-50%, -50%) scale(${1})`,
            transform: `translate(-50%, -50%) scale(${scale})`,
          }}
        >
          <Popover
            popup={
              <div className="min-w-[208px]">
                <div className="flex item-center gap-2">
                  <div className="text-[14px] leading-[22px] font-semibold">
                    {currentHoverCellData?.name}
                  </div>
                  <div className="flex items-center px-2 h-5 text-[8px] text-[var(--odn-color-black-10)] bg-[var(--odn-color-black-2)] rounded-[20px]">
                    产品类心智/功效功能
                  </div>
                </div>
                <div className="my-4 h-px bg-[var(--odn-color-black-2)]" />
                <div className="flex flex-col gap-2">
                  <div className="flex items-center gap-2 justify-between text-[14px]">
                    <div className="text-ellipsis whitespace-nowrap overflow-hidden">
                      心智量心智量心智量心智量心智量心智量
                    </div>
                    <div className="flex-none">66.66%</div>
                  </div>
                  <div className="flex items-center gap-2 justify-between text-[14px]">
                    <div className="text-ellipsis whitespace-nowrap overflow-hidden">
                      环比值环比值环比值环比值环比值环比值环比值
                    </div>
                    <div className="flex-none flex items-center text-[var(--odn-color-green-7)]">
                      <svg width="16" height="16" viewBox="0 0 16 16">
                        <path
                          d="M11.8535 6.64648L11.1465 7.35352L8.5 4.70703V13H7.5V4.70703L4.85352 7.35352L4.14648 6.64648L8 2.79297L11.8535 6.64648Z"
                          fill="currentColor"
                        />
                      </svg>
                      13.04%
                    </div>
                  </div>
                  <div className="flex items-center gap-2 justify-between text-[14px]">
                    <div className="text-ellipsis whitespace-nowrap overflow-hidden">
                      行业份额
                    </div>
                    <div className="flex-none">2.56%</div>
                  </div>
                </div>
              </div>
            }
            popupRootStyle={{ pointerEvents: 'none' }}
            popupStyle={{
              transform: `translate3d(${offset?.[0] ?? 0}px, ${offset?.[1] ?? 0}px, 0)`,
            }}
            visible={!!currentHoverCellData}
            placement="topRight"
            arrowed={false}
            autoPlacements={[]}
            flip={false}
            shift={false}
          >
            <div ref={wrapperRef} />
          </Popover>
        </div>
      </div>
    </CodeBox>
  );
};

export default Demo;
```
## API {#api}

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| disabled | 是否禁用（占位） | `boolean` | `false` |

继承 `React.HTMLAttributes<HTMLDivElement>`。当前实现为占位组件，后续可替换为真实图表能力。

## 变量 {#variables}

<VariablesTable id="Chart"></VariablesTable>

---

## 折叠面板 Collapse

## 基础用例 {#basic-usage}

通过 `accordion` 属性可以设置是否为手风琴模式，默认为 `false`：

**示例：基础用例** — 基础用例

```tsx
'use client';

import { Collapse } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

const Basics = () => {
  const [params, setParams] = useState({
    accordion: false,
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'accordion', {
      type: 'boolean',
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  const text = `
    A dog is a type of domesticated animal.
    Known for its loyalty and faithfulness,
    it can be found as a welcome guest in many households across the world.
  `;

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <Collapse
          defaultActiveKey={['1']}
          accordion={params.accordion}
          items={[
            {
              key: '1',
              label: 'This is panel header 1',
              children: <p>{text}</p>,
            },
            {
              key: '2',
              label: 'This is panel header 2',
              children: <p>{text}</p>,
            },
            {
              key: '3',
              label: 'This is panel header 3',
              children: <p>{text}</p>,
              disabled: true,
            },
          ]}
        />
      </CodeBox>
      <CodeBlock>{`import { Collapse } from "one-design-next";

const text = \`
  A dog is a type of domesticated animal.
  Known for its loyalty and faithfulness,
  it can be found as a welcome guest in many households across the world.
\`;

return (
  <Collapse
    accordion={${params.accordion}}
    items={[
      {
        key: '1',
        label: 'This is panel header 1',
        children: <p>{text}</p>,
      },
      {
        key: '2',
        label: 'This is panel header 2',
        children: <p>{text}</p>,
      },
      {
        key: '3',
        label: 'This is panel header 3',
        children: <p>{text}</p>,
        disabled: true,
      },
    ]}
  />
);
`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## 动效示例 {#motion-example}

使用 `motion/react` 自定义 `Collapsible` primitives：

**示例：motion** — motion

```tsx
'use client';

import {
  ChevronUp,
  FerrisWheel,
  MousePointerClick,
  Sparkles,
  Sprout,
  Waves,
} from 'lucide-react';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from 'one-design-next';
import React, { useState } from 'react';
import { cn } from '../../../.dumi/theme/_util';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basics = () => {
  const text = `A collection of methods and ideas that bring clarity and emotion to complex interfaces.`;

  const dataSource = [
    {
      icon: <MousePointerClick className="text-neutral-400 size-5" />,
      title: 'What is interaction design?',
      content: text,
    },
    {
      icon: <Sparkles className="text-neutral-400 size-5" />,
      title: 'Why motion matters?',
      content: text,
    },
    {
      icon: <FerrisWheel className="text-neutral-400 size-5" />,
      title: 'Why we create?',
      content: text,
    },
    {
      icon: <Waves className="text-neutral-400 size-5" />,
      title: 'What drives interaction?',
      content: text,
    },
    {
      icon: <Sprout className="text-neutral-400 size-5" />,
      title: 'How ideas grow?',
      content: text,
    },
  ];

  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const handleOpenChange = (index: number, isOpen: boolean) => {
    setOpenIndex(isOpen ? index : null);
  };

  const getItemClassName = (index: number) => {
    const isFirst = index === 0;
    const isLast = index === dataSource.length - 1;
    const isActive = openIndex === index;
    const isBeforeActive = openIndex !== null && openIndex - 1 === index;
    const isAfterActive = openIndex !== null && openIndex + 1 === index;

    return cn(
      'w-[400px] bg-white hover:bg-neutral-50 border-0 border-x border-neutral-200 overflow-hidden transition-all',
      // 背景色
      isActive && 'bg-neutral-50',
      // 圆角
      {
        'rounded-t-2xl': isFirst || isAfterActive,
        'rounded-b-2xl': isLast || isBeforeActive,
        'rounded-2xl': isActive,
      },
      // 边框
      {
        'border-t': isFirst || isAfterActive,
        'border-b': isLast || isBeforeActive,
        border: isActive,
      },
      // 间距
      isActive && {
        'mb-4': isFirst,
        'mt-4': isLast,
        'my-4': !isFirst && !isLast,
      },
    );
  };

  return (
    <div>
      <CodeBox className="flex flex-col p-16">
        {dataSource.map((item, index) => (
          <Collapsible
            className={getItemClassName(index)}
            key={index}
            open={openIndex === index}
            onOpenChange={(isOpen) => handleOpenChange(index, isOpen)}
          >
            <CollapsibleTrigger asChild>
              {({ isOpen }) => (
                <div className="px-5 py-4 cursor-pointer font-medium flex items-center justify-between transition-all">
                  <div className="flex items-center gap-2">
                    {item.icon}
                    {item.title}
                  </div>
                  <ChevronUp
                    className={cn(
                      'size-5 text-neutral-400 transition-transform',
                      !isOpen && 'rotate-180',
                    )}
                  />
                </div>
              )}
            </CollapsibleTrigger>
            <CollapsibleContent>
              <div className="px-5 pb-4">
                <p className="m-0 text-gray-700">{item.content}</p>
              </div>
            </CollapsibleContent>
          </Collapsible>
        ))}
      </CodeBox>
      <CodeBlock>{`import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from 'one-design-next';
import { ChevronUp } from 'lucide-react';
import { useState } from 'react';

const [openIndex, setOpenIndex] = useState<number | null>(null);

const getItemClassName = (index: number) => {
  const isFirst = index === 0;
  const isLast = index === dataSource.length - 1;
  const isActive = openIndex === index;
  const isBeforeActive = openIndex !== null && openIndex - 1 === index;
  const isAfterActive = openIndex !== null && openIndex + 1 === index;

  return cn(
    'w-[400px] bg-white hover:bg-neutral-50 border-0 border-x border-neutral-200 overflow-hidden transition-all',
    isActive && 'bg-neutral-50',
    {
      'rounded-t-2xl': isFirst || isAfterActive,
      'rounded-b-2xl': isLast || isBeforeActive,
      'rounded-2xl': isActive,
    },
    {
      'border-t': isFirst || isAfterActive,
      'border-b': isLast || isBeforeActive,
      border: isActive,
    },
    isActive && {
      'mb-4': isFirst,
      'mt-4': isLast,
      'my-4': !isFirst && !isLast,
    },
  );
};

<Collapsible
  className={getItemClassName(index)}
  open={openIndex === index}
  onOpenChange={(isOpen) => setOpenIndex(isOpen ? index : null)}
>
  <CollapsibleTrigger asChild>
    {({ isOpen }) => (
      <div className="px-5 py-4 cursor-pointer font-medium flex items-center justify-between">
        <div className="flex items-center gap-2">
          {item.icon}
          {item.title}
        </div>
        <ChevronUp
          className={cn(
            'text-neutral-400 transition-transform',
            !isOpen && 'rotate-180',
          )}
        />
      </div>
    )}
  </CollapsibleTrigger>
  <CollapsibleContent>
    <div className="px-5 pb-4">
      <p className="m-0 text-gray-700">{item.content}</p>
    </div>
  </CollapsibleContent>
</Collapsible>`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## 使用 Primitives {#using-primitives}

如果需要更高的自定义度，可以直接使用底层的 `Collapsible` primitives：

**示例：Primitives 用法** — 使用底层 primitives 实现完全自定义的折叠面板

```tsx
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from 'one-design-next';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import React from 'react';

const Primitives = () => {
  const text = `
  A dog is a type of domesticated animal.
  Known for its loyalty and faithfulness,
  it can be found as a welcome guest in many households across the world.
`;

  return (
    <div>
      <CodeBox>
        <div className="max-w-xl">
          {/* 自定义样式的 Collapse */}
          <div className="overflow-hidden">
            <Collapsible>
              <CollapsibleTrigger asChild>
                {({ isOpen }) => (
                  <div className="px-5 py-4 bg-gray-50 cursor-pointer font-medium flex items-center justify-between hover:bg-gray-100 transition-colors">
                    <span>📄 自定义样式面板 1</span>
                    <span className="text-xs text-gray-500">
                      {isOpen ? '点击收起' : '点击展开'}
                    </span>
                  </div>
                )}
              </CollapsibleTrigger>
              <CollapsibleContent>
                <div className="px-5 py-4 bg-white">
                  <p className="m-0 text-gray-700">{text}</p>
                </div>
              </CollapsibleContent>
            </Collapsible>

            <Collapsible>
              <CollapsibleTrigger asChild>
                {({ isOpen }) => (
                  <div className="px-5 py-4 bg-gray-50 cursor-pointer font-medium flex items-center justify-between hover:bg-gray-100 transition-colors">
                    <span>🎨 自定义样式面板 2</span>
                    <span className="text-xs text-gray-500">
                      {isOpen ? '点击收起' : '点击展开'}
                    </span>
                  </div>
                )}
              </CollapsibleTrigger>
              <CollapsibleContent>
                <div className="px-5 py-4 bg-yellow-100">
                  <p className="m-0 text-yellow-800">
                    这个面板有黄色背景，展示了 primitives 的灵活性。
                  </p>
                </div>
              </CollapsibleContent>
            </Collapsible>

            <Collapsible defaultOpen>
              <CollapsibleTrigger asChild>
                {({ isOpen }) => (
                  <div className="px-5 py-4 bg-gray-50 cursor-pointer font-medium flex items-center justify-between hover:bg-gray-100 transition-colors">
                    <span>⚡ 默认展开的面板</span>
                    <span className="text-xs text-gray-500">
                      {isOpen ? '点击收起' : '点击展开'}
                    </span>
                  </div>
                )}
              </CollapsibleTrigger>
              <CollapsibleContent>
                <div className="px-5 py-4 bg-green-50">
                  <p className="m-0 text-green-800">
                    这个面板默认是展开的，并且有绿色背景。
                  </p>
                </div>
              </CollapsibleContent>
            </Collapsible>
          </div>
        </div>
      </CodeBox>
      <CodeBlock>{`import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "one-design-next";
import React from 'react';

const Primitives = () => {
  return (
    <div className="overflow-hidden">
      <Collapsible>
        <CollapsibleTrigger>
          {({ isOpen }) => (
            <div className="px-5 py-4 bg-gray-50 cursor-pointer font-medium flex items-center justify-between hover:bg-gray-100 transition-colors">
              <span>📄 自定义样式面板 1</span>
              <span className="text-xs text-gray-500">
                {isOpen ? '点击收起' : '点击展开'}
              </span>
            </div>
          )}
        </CollapsibleTrigger>
        <CollapsibleContent>
          <div className="px-5 py-4 bg-white">
            <p className="m-0 text-gray-700">面板内容...</p>
          </div>
        </CollapsibleContent>
      </Collapsible>
      
      <Collapsible>
        <CollapsibleTrigger>
          {({ isOpen }) => (
            <div className="px-5 py-4 bg-gray-50 cursor-pointer font-medium flex items-center justify-between hover:bg-gray-100 transition-colors">
              <span>🎨 自定义样式面板 2</span>
              <span className="text-xs text-gray-500">
                {isOpen ? '点击收起' : '点击展开'}
              </span>
            </div>
          )}
        </CollapsibleTrigger>
        <CollapsibleContent>
          <div className="px-5 py-4 bg-yellow-100">
            <p className="m-0 text-yellow-800">黄色背景面板内容...</p>
          </div>
        </CollapsibleContent>
      </Collapsible>
      
      <Collapsible defaultOpen>
        <CollapsibleTrigger>
          {({ isOpen }) => (
            <div className="px-5 py-4 bg-gray-50 cursor-pointer font-medium flex items-center justify-between hover:bg-gray-100 transition-colors">
              <span>⚡ 默认展开的面板</span>
              <span className="text-xs text-gray-500">
                {isOpen ? '点击收起' : '点击展开'}
              </span>
            </div>
          )}
        </CollapsibleTrigger>
        <CollapsibleContent>
          <div className="px-5 py-4 bg-green-50">
            <p className="m-0 text-green-800">绿色背景面板内容...</p>
          </div>
        </CollapsibleContent>
      </Collapsible>
    </div>
  );
};

export default Primitives;`}</CodeBlock>
    </div>
  );
};

export default Primitives;
```
## API {#api}

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| items | 面板项 | `{ key, label, children, disabled? }[]` | - |
| defaultActiveKey | 默认展开 | `string \| string[]` | `[]` |
| activeKey | 受控展开 | `string \| string[]` | - |
| onChange | 展开变化 | `(activeKeys: string[]) => void` | - |
| accordion | 手风琴（仅一项） | `boolean` | `false` |
| className | 类名 | `string` | - |
| style | 样式 | `React.CSSProperties` | - |

## 变量 {#variables}

<VariablesTable id="Collapse"></VariablesTable>

---

## 文字省略 EllipsisText

## 基础用例 {#basic-usage}

通过 `popoverProps` 属性可以设置悬浮框的属性，通过 `lineClamp` 属性可以设置省略的行数：

**示例：基础用例** — 基础用例

```tsx
'use client';

import { EllipsisText } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

const Basics = () => {
  const [params, setParams] = useState({
    width: 200,
    lineClamp: 2,
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'width', {
      min: 100,
      max: 500,
      step: 10,
    });

    pane.addBinding(params, 'lineClamp', {
      min: 0,
      max: 5,
      step: 1,
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  const longText =
    '这是一段很长的文本内容，用来演示文字省略功能。当文本内容超过指定的行数时，会自动显示省略号，并且只有在文本被截断时才会显示 Popover 悬浮框。';

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <div className="flex flex-col gap-4">
          <div>
            <div className="flex items-center gap-1">
              <div className="flex-none p-1 bg-neutral-200 rounded">
                前后元素占位
              </div>
              <EllipsisText
                lineClamp={params.lineClamp || undefined}
                popoverProps={{ placement: 'right' }}
                style={{ width: params.width }}
              >
                {longText}
              </EllipsisText>
              <div className="flex-none p-1 bg-neutral-200 rounded">
                前后元素占位
              </div>
            </div>
          </div>
        </div>
      </CodeBox>
      <CodeBlock>{`import { EllipsisText } from "one-design-next";

// 单行省略
<EllipsisText popoverProps={{ placement: 'right' }}>
  "${longText}"
</EllipsisText>

// 多行省略
<EllipsisText 
  lineClamp={2}
  popoverProps={{ placement: 'right' }}
>
  "${longText}"
</EllipsisText>`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## API {#api}

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| children | 展示内容 | `string \| number \| React.ReactNode` | - |
| popoverProps | 透传给 Popover | `Omit<PopoverProps, 'popup' \| 'children'>` | - |
| lineClamp | 最大行数（多行省略） | `number` | - |

继承 `Omit<React.HTMLAttributes<HTMLDivElement>, 'children'>`。

## 变量 {#variables}

<VariablesTable id="EllipsisText"></VariablesTable>

---

## 空状态 Empty

## 基础用例 {#basic-usage}

**示例：basic** — basic

```tsx
'use client';

import { Button, Empty } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

const Basics = () => {
  const [params, setParams] = useState({
    type: 'search' as
      | 'search'
      | 'data'
      | 'crowd'
      | 'address'
      | 'message'
      | 'image'
      | 'image-error',
    size: 'medium' as 'small' | 'medium' | 'large',
    showTitle: true,
    showDescription: true,
    showExtra: true,
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'type', {
      options: {
        '搜索为空 search': 'search',
        '数据为空 data': 'data',
        '人群为空 crowd': 'crowd',
        '地址为空 address': 'address',
        '消息为空 message': 'message',
        '图片为空 image': 'image',
        '图片加载失败 image-error': 'image-error',
      },
    });

    pane.addBinding(params, 'size', {
      options: { large: 'large', medium: 'medium', small: 'small' },
    });

    pane.addBinding(params, 'showTitle', { label: '显示标题' });
    pane.addBinding(params, 'showDescription', { label: '显示描述' });
    pane.addBinding(params, 'showExtra', { label: '显示操作按钮' });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  const title = params.showTitle ? '这是标题文字' : undefined;
  const description = params.showDescription
    ? '这是一句详细描述适性的文案，如无需要请删除'
    : undefined;
  const extra = params.showExtra ? (
    <Button size="small" type="primary">
      立即创建
    </Button>
  ) : undefined;

  const codeLines: string[] = [
    `<Empty`,
    `  type="${params.type}"`,
    `  size="${params.size}"`,
  ];
  if (title) codeLines.push(`  title="这是标题文字"`);
  if (description)
    codeLines.push(
      `  description="这是一句详细描述适性的文案，如无需要请删除"`,
    );
  if (extra)
    codeLines.push(
      `  extra={<Button size="small" type="primary">立即创建</Button>}`,
    );
  codeLines.push(`/>`);

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <div
          className="flex items-center justify-center"
          style={{ minHeight: 160 }}
        >
          <Empty
            type={params.type}
            size={params.size}
            title={title}
            description={description}
            extra={extra}
          />
        </div>
      </CodeBox>

      <CodeBlock>{`import { Empty } from "one-design-next";

${codeLines.join('\n')}`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## API {#api}

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| type | 空状态类型 | `'search' \| 'data' \| 'crowd' \| 'address' \| 'message' \| 'image' \| 'image-error'` | `'search'` |
| size | 尺寸 | `'large' \| 'medium' \| 'small'` | `'medium'` |
| title | 标题 | `React.ReactNode` | - |
| description | 描述文字 | `React.ReactNode` | - |
| extra | 操作区（如按钮） | `React.ReactNode` | - |
| image | 自定义图示，会完全替代内置图示 | `React.ReactNode` | - |

此外继承 `React.HTMLAttributes<HTMLDivElement>`（如 `className`、`style` 等）。

## 变量 {#variables}

<VariablesTable id="Empty"></VariablesTable>

---

## 加载中 Loading

## 基础用例 {#basic-usage}

**示例：basic** — basic

```tsx
'use client';

import { Loading } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

const Basics = () => {
  const [params, setParams] = useState({
    theme: 'light' as 'light' | 'dark',
    size: 'medium' as 'small' | 'medium' | 'large',
    showTip: true,
    tipText: '正在加载...',
    tipPosition: 'bottom' as 'bottom' | 'right',
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'theme', {
      options: { light: 'light', dark: 'dark' },
    });

    pane.addBinding(params, 'size', {
      options: { small: 'small', medium: 'medium', large: 'large' },
    });

    pane.addBinding(params, 'showTip');

    pane.addBinding(params, 'tipText');

    pane.addBinding(params, 'tipPosition', {
      options: { bottom: 'bottom', right: 'right' },
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  const tip = params.showTip ? params.tipText : undefined;
  const sharedProps = {
    theme: params.theme,
    size: params.size,
    tip,
    tipPosition: params.tipPosition,
  };

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <div
          className="flex items-center justify-center gap-16"
          style={{ minHeight: 80 }}
        >
          <Loading type="ring" {...sharedProps} />
          <Loading type="linear" {...sharedProps} />
        </div>
      </CodeBox>

      <CodeBlock>{`import { Loading } from "one-design-next";

// 环形
<Loading
  type="ring"
  theme="${params.theme}"
  size="${params.size}"${tip ? `\n  tip="${tip}"\n  tipPosition="${params.tipPosition}"` : ''}
/>

// 线形
<Loading
  type="linear"
  theme="${params.theme}"
  size="${params.size}"${tip ? `\n  tip="${tip}"\n  tipPosition="${params.tipPosition}"` : ''}
/>`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## API {#api}

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| type | 类型 | `'ring' \| 'linear'` | `'ring'` |
| theme | 样式主题 | `'light' \| 'dark'` | `'light'` |
| size | 尺寸 | `'small' \| 'medium' \| 'large'` | `'medium'` |
| tip | 辅助文字 | `React.ReactNode` | - |
| tipPosition | 辅助文字位置 | `'bottom' \| 'right'` | `'bottom'` |

此外继承 `React.HTMLAttributes<HTMLDivElement>`（如 `className`、`style` 等）。

## 变量 {#variables}

<VariablesTable id="Loading"></VariablesTable>

---

## 数字滚动 NumberFlow

## 基础用例 {#basic-usage}

**示例：基础用例** — 基础用例

```tsx
'use client';

import { NumberFlow } from 'one-design-next';
import React, { useEffect, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basic = () => {
  const [seconds, setSeconds] = useState(60 * 60 * 24);

  useEffect(() => {
    const timer = setInterval(() => {
      setSeconds(seconds - 1);
    }, 1000);
    return () => clearInterval(timer);
  }, [seconds]);

  const hh = Math.floor(seconds / 3600);
  const mm = Math.floor((seconds % 3600) / 60);
  const ss = seconds % 60;

  return (
    <div>
      <CodeBox className="gap-2 flex-wrap">
        <NumberFlow.NumberFlowGroup>
          <div
            style={{
              fontVariantNumeric: 'tabular-nums',
              '--number-flow-char-height': '0.85em',
            }}
            className="text-2xl flex items-baseline font-semibold"
          >
            <NumberFlow
              trend={-1}
              value={hh}
              format={{ minimumIntegerDigits: 2 }}
            />
            <NumberFlow
              prefix=":"
              trend={-1}
              value={mm}
              digits={{ 1: { max: 5 } }}
              format={{ minimumIntegerDigits: 2 }}
            />
            <NumberFlow
              prefix=":"
              trend={-1}
              value={ss}
              digits={{ 1: { max: 5 } }}
              format={{ minimumIntegerDigits: 2 }}
            />
          </div>
        </NumberFlow.NumberFlowGroup>
      </CodeBox>
      <CodeBlock>{`import { NumberFlow } from 'one-design-next';

<NumberFlow.NumberFlowGroup>
  <div
    style={{
      fontVariantNumeric: 'tabular-nums',
      '--number-flow-char-height': '0.85em',
    }}
    className="text-2xl flex items-baseline font-semibold"
  >
    <NumberFlow
      trend={-1}
      value={hh}
      format={{ minimumIntegerDigits: 2 }}
    />
    <NumberFlow
      prefix=":"
      trend={-1}
      value={mm}
      digits={{ 1: { max: 5 } }}
      format={{ minimumIntegerDigits: 2 }}
    />
    <NumberFlow
      prefix=":"
      trend={-1}
      value={ss}
      digits={{ 1: { max: 5 } }}
      format={{ minimumIntegerDigits: 2 }}
    />
  </div>
</NumberFlow.NumberFlowGroup>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 表达动态变化 {#express-dynamic-changes}

当一个数字发生变化、尤其不是由用户操作触发时，我们可以使用 `NumberFlow` 来表达这种动态变化，否则用户不知道发生了什么。

比如随着直播时长的变化，观看人数、花费等指标会在某个时间点发生变化：

**示例：直播间数据** — 直播间数据

```tsx
'use client';

import React, { useEffect, useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basic = () => {
  const [value, setValue] = useState(1000000);

  useEffect(() => {
    const timer = setInterval(() => {
      setValue(value + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, [value]);

  return (
    <div>
      <CodeBox className="p-1 gap-2 flex-wrap">
        <video
          src="https://wxa.wxs.qq.com/wxad-design/yijie/numberflow-in-b.mp4"
          autoPlay
          loop
          muted
          playsInline
          className="w-full h-auto rounded-md"
        />
      </CodeBox>
    </div>
  );
};

export default Basic;
```
<div className="flex justify-between items-center mb-6 pb-6 dotted-bottom"></div>

比如随着时间的变化，点赞、转发等指标也会发生变化：

**示例：活动数据** — 活动数据

```tsx
'use client';

import { Icon, NumberFlow } from 'one-design-next';
import React, { useEffect, useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basic = () => {
  const [views, setViews] = useState(1000);

  useEffect(() => {
    const timer = setInterval(() => {
      setViews(views + 100);
    }, 2000);
    return () => clearInterval(timer);
  }, [views]);

  return (
    <div>
      <CodeBox>
        <div className="flex w-full justify-center items-center font-medium text-base text-neutral-800 gap-12">
          <div className="flex items-center gap-2">
            <Icon name="compare" size={22} />
            <NumberFlow
              willChange
              plugins={[NumberFlow.continuous]}
              value={views}
              locales="en-US"
              format={{
                style: 'decimal',
                minimumFractionDigits: 0,
                maximumFractionDigits: 1,
                notation: 'compact',
              }}
            />
          </div>
          <div className="flex items-center gap-2">
            <Icon name="thumbUp" size={22} />
            <NumberFlow willChange value={views} locales="en-US" />
          </div>
          <div className="flex items-center gap-2">
            <Icon name="share" size={22} />
            <NumberFlow willChange value={views} locales="en-US" />
          </div>
        </div>
      </CodeBox>
    </div>
  );
};

export default Basic;
```
<div className="flex justify-between items-center mb-6 pb-6 dotted-bottom"></div>

我们还可以动态地调整小数点后的位数，使其仅在必要的时候展示：

**示例：小数点后位数** — 小数点后位数

```tsx
'use client';

import { NumberFlow } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';

const Basic = () => {
  const [numbers, setNumbers] = useState([1, 2, 30000]);
  const timerCount = useRef(0);

  useEffect(() => {
    const timer = setInterval(() => {
      if (timerCount.current % 2 === 0) {
        setNumbers([2, 3, 36685]);
      } else {
        setNumbers([1, 2, 30000]);
      }
      timerCount.current++;
    }, 3000);
    return () => clearInterval(timer);
  }, [numbers]);

  return (
    <div>
      <CodeBox className="">
        <div className="w-[350px] h-[285px] rounded-xl bg-white ring-1 ring-neutral-100 shadow">
          <div className="pl-6 h-[68px] flex items-center text-[18px] font-semibold border-b border-neutral-100">
            费用明细（元）
          </div>
          <div className="p-8">
            <div className="flex items-center mb-5 text-[14px] text-[#296BEF]">
              <NumberFlow
                willChange
                value={numbers[0]}
                prefix="已选"
                suffix="个达人，共"
                className="number-flow-decimal-text-demo"
              />
              <NumberFlow
                willChange
                value={numbers[1]}
                suffix="个视频"
                className="number-flow-decimal-text-demo"
              />
            </div>
            <div className="flex items-center justify-between mb-1">
              <div className="text-[14px] text-neutral-500 flex items-center gap-0.5">
                合作价格
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                  <path
                    fillRule="evenodd"
                    clipRule="evenodd"
                    d="M7.99957 14.2218C4.56313 14.2218 1.77734 11.436 1.77734 7.99957C1.77734 4.56313 4.56313 1.77734 7.99957 1.77734C11.436 1.77734 14.2218 4.56313 14.2218 7.99957C14.2218 11.436 11.436 14.2218 7.99957 14.2218ZM7.11068 11.9996H8.44401V10.6662H7.11068V11.9996ZM8.44709 9.3329C8.44709 9.15157 8.63553 9.00934 9.33597 8.44401C9.97597 7.92757 10.6693 7.51334 10.6693 6.44401C10.6693 5.65734 10.384 5.04134 9.88798 4.64045C9.38309 4.23157 8.79998 3.99957 8.00264 3.99957C7.06131 3.99957 6.33775 4.31068 5.83731 4.83423C5.2622 5.43512 5.33598 6.07779 5.33598 6.66623H6.66931V6.41823C6.66931 6.16757 6.71909 5.7889 7.11375 5.52934C7.30398 5.40401 7.65153 5.33645 8.00353 5.3329C8.3422 5.32934 8.68353 5.38623 8.89153 5.52934C9.30931 5.81823 9.33597 6.12845 9.33597 6.44401C9.33597 6.7889 9.03731 7.12223 8.44709 7.55512C7.55286 8.21112 7.11375 8.46001 7.11375 8.88845V9.77734H8.44886C8.44886 9.56045 8.44709 9.5569 8.44709 9.3329Z"
                    fill="#495A7A"
                    fillOpacity="0.16"
                  />
                </svg>
              </div>
              <div
                className="text-[16px]"
                style={{
                  fontFamily: 'WeChat Sans Std Medium',
                }}
              >
                <NumberFlow
                  willChange
                  value={numbers[2]}
                  prefix="¥"
                  className="number-flow-decimal-demo"
                  format={{
                    style: 'decimal',
                    minimumFractionDigits:
                      (numbers[2] * 0.05).toString().split('.')[1]?.length || 0,
                  }}
                />
              </div>
            </div>
            <div className="flex items-center justify-between mb-1">
              <div className="text-[14px] text-neutral-500 flex items-center gap-1">
                平台服务费
                <div className="text-neutral-400">(5%)</div>
              </div>
              <div
                className="text-[16px]"
                style={{
                  fontFamily: 'WeChat Sans Std Medium',
                }}
              >
                <NumberFlow
                  willChange
                  value={numbers[2] * 0.05}
                  prefix="¥"
                  className="number-flow-decimal-demo"
                />
              </div>
            </div>
            <div className="h-[1px] bg-neutral-100 my-5" />
            <div className="flex items-center justify-between">
              <div className="text-[14px] text-neutral-500 flex items-center gap-1">
                总价
              </div>
              <div
                className="text-[16px] text-[#296BEF]"
                style={{
                  fontFamily: 'WeChat Sans Std Medium',
                }}
              >
                <NumberFlow
                  willChange
                  value={numbers[2] * 1.05}
                  prefix="¥"
                  className="number-flow-decimal-demo"
                />
              </div>
            </div>
          </div>
        </div>
        <style>
          {`
            .number-flow-decimal-text-demo::part(number) {
              font-size: 16px;
              padding: 0 4px;
            }
            .number-flow-decimal-text-demo::part(prefix),
            .number-flow-decimal-text-demo::part(suffix) {
              position: relative;
              top: -0.5px;
              font-size: 14px;
              color: #000;
            }
            .number-flow-decimal-demo::part(fraction) {
              font-size: 12px;
            }
          `}
        </style>
      </CodeBox>
      <CodeBlock>{`import { NumberFlow } from 'one-design-next';

<NumberFlow
  willChange
  value={numbers[0]}
  prefix="已选"
  suffix="个达人，共"
  className="number-flow-decimal-text-demo"
/>

...

<NumberFlow
  willChange
  value={numbers[2]}
  prefix="¥"
  className="number-flow-decimal-demo"
  format={{
    style: 'decimal',
    minimumFractionDigits:
      (numbers[2] * 0.05).toString().split('.')[1]?.length || 0,
  }}
/>

<style>
  .number-flow-decimal-text-demo::part(number) {
    font-size: 16px;
    padding: 0 4px;
  }
  .number-flow-decimal-text-demo::part(prefix),
  .number-flow-decimal-text-demo::part(suffix) {
    position: relative;
    top: -0.5px;
    font-size: 14px;
    color: #000;
  }
  .number-flow-decimal-demo::part(fraction) {
    font-size: 12px;
  }
</style>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 增强表现力 {#enhance-expressiveness}

数字滚动在 [C 端](https://wxad.design/abc/making-fluid-interfaces/carousel-velocity.mp4) 可以是表现力的体现，但 B 端大多不需要。这就是为什么当我们考虑滑动条 `Slider`，或是数字输入框 `InputNumber` 组件时，它们也存在数字的动态变化，却一般不适合使用 `NumberFlow` 的原因。

第一，它们的动态变化本就是由用户操作触发的，不需要被额外表达；第二，它们作为基础组件的表现力也不需要被增强。

所以我们可以仔细看回上面直播间的例子，会发现头部有个“直播时长”的计时，但我并没有使用 `NumberFlow` 来抢夺注意力 —— 指标变化才需要。

<div className="flex justify-between items-center -mt-4 mb-6 pb-6 dotted-bottom"></div>

同样是计时，下面的例子却适合。因为文字是静态的，倒计时作为唯一的变化可以被强调：

**示例：倒计时** — 倒计时

```tsx
'use client';

import { NumberFlow } from 'one-design-next';
import React, { useEffect, useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basic = () => {
  const [seconds, setSeconds] = useState(60 * 60 * 24);

  useEffect(() => {
    const timer = setInterval(() => {
      setSeconds(seconds - 1);
    }, 1000);
    return () => clearInterval(timer);
  }, [seconds]);

  const hh = Math.floor(seconds / 3600);
  const mm = Math.floor((seconds % 3600) / 60);
  const ss = seconds % 60;

  return (
    <div className="mb-6 text-sm">
      <CodeBox className="px-5 gap-2 flex-wrap">
        <div>
          <div className="flex items-center mb-1 text-base font-semibold">
            <div className="bg-green-500 size-4 rounded-full mr-1.5" />
            <span className="mr-1">剩余时间</span>
            <NumberFlow.NumberFlowGroup>
              <div
                style={{
                  fontVariantNumeric: 'tabular-nums',
                  '--number-flow-char-height': '0.85em',
                }}
              >
                <NumberFlow
                  trend={-1}
                  value={hh}
                  format={{ minimumIntegerDigits: 2 }}
                />
                <NumberFlow
                  prefix=":"
                  trend={-1}
                  value={mm}
                  digits={{ 1: { max: 5 } }}
                  format={{ minimumIntegerDigits: 2 }}
                />
                <NumberFlow
                  prefix=":"
                  trend={-1}
                  value={ss}
                  digits={{ 1: { max: 5 } }}
                  format={{ minimumIntegerDigits: 2 }}
                />
              </div>
            </NumberFlow.NumberFlowGroup>
          </div>
          <div className="mb-2 ml-6">
            注册开放至 7 月 23 日。注册后，您将立即获得以下访问权限：
          </div>
          <div className="flex items-center gap-1.5 mb-1">
            <svg viewBox="0 0 16 16" className="size-4 fill-green-500">
              <path d="M14.9053 3.63086C11.0505 6.10896 8.76163 9.37676 7.50586 11.7324C7.05833 12.5718 6.19389 13.0189 5.36621 13.0859C4.53482 13.1531 3.60011 12.843 3.07715 11.9932L1.23438 9H2.99609L4.35449 11.207C4.51505 11.4679 4.83761 11.6239 5.24609 11.5908C5.65815 11.5573 6.01658 11.3378 6.18262 11.0264C7.51839 8.52073 9.96203 5.02587 14.0947 2.36914L14.9053 3.63086Z" />
            </svg>
            <div>20 个章节，包含 20 个组件的源代码；</div>
          </div>
          <div className="flex items-center gap-1.5 mb-1">
            <svg viewBox="0 0 16 16" className="size-4 fill-green-500">
              <path d="M14.9053 3.63086C11.0505 6.10896 8.76163 9.37676 7.50586 11.7324C7.05833 12.5718 6.19389 13.0189 5.36621 13.0859C4.53482 13.1531 3.60011 12.843 3.07715 11.9932L1.23438 9H2.99609L4.35449 11.207C4.51505 11.4679 4.83761 11.6239 5.24609 11.5908C5.65815 11.5573 6.01658 11.3378 6.18262 11.0264C7.51839 8.52073 9.96203 5.02587 14.0947 2.36914L14.9053 3.63086Z" />
            </svg>
            <div>原则、原型和学习资源的未来更新；</div>
          </div>
          <div className="flex items-center gap-1.5 mb-1">
            <svg viewBox="0 0 16 16" className="size-4 fill-green-500">
              <path d="M14.9053 3.63086C11.0505 6.10896 8.76163 9.37676 7.50586 11.7324C7.05833 12.5718 6.19389 13.0189 5.36621 13.0859C4.53482 13.1531 3.60011 12.843 3.07715 11.9932L1.23438 9H2.99609L4.35449 11.207C4.51505 11.4679 4.83761 11.6239 5.24609 11.5908C5.65815 11.5573 6.01658 11.3378 6.18262 11.0264C7.51839 8.52073 9.96203 5.02587 14.0947 2.36914L14.9053 3.63086Z" />
            </svg>
            <div>私人社区，向我提问并接收反馈；</div>
          </div>
          <div className="flex items-center gap-1.5">
            <svg viewBox="0 0 16 16" className="size-4 fill-green-500">
              <path d="M14.9053 3.63086C11.0505 6.10896 8.76163 9.37676 7.50586 11.7324C7.05833 12.5718 6.19389 13.0189 5.36621 13.0859C4.53482 13.1531 3.60011 12.843 3.07715 11.9932L1.23438 9H2.99609L4.35449 11.207C4.51505 11.4679 4.83761 11.6239 5.24609 11.5908C5.65815 11.5573 6.01658 11.3378 6.18262 11.0264C7.51839 8.52073 9.96203 5.02587 14.0947 2.36914L14.9053 3.63086Z" />
            </svg>
            <div>我正在做的幕后工作。</div>
          </div>
        </div>
      </CodeBox>
    </div>
  );
};

export default Basic;
```
同理，当一个滑动条或数字输入框并不作为一个基础表单元素存在，而是需要一定表现力时，我们也可以使用 `NumberFlow`。总之，小心地使用 `NumberFlow`。

## API {#api}

参考 [@number-flow/react](https://number-flow.barvian.me/) 文档。

## 变量 {#variables}

<VariablesTable id="NumberFlow"></VariablesTable>

---

## 滚动区域 ScrollArea

## 基础用例 {#basic-usage}

`ScrollArea` 在 `TimePicker`、`Dropdown` 等组件中都被使用。它最重要的表现就是不占用额外的空间，其次还能够统一各浏览器下的滚动条样式。

可通过 `onScroll` 属性监听滚动事件，也可通过 `ref` 获取滚动区域的 `scrollTop` 值：

**示例：基础用例** — 基础用例

```tsx
'use client';

import { ScrollArea } from 'one-design-next';
import React, { useRef } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basics = () => {
  const tags = Array.from({ length: 50 }).map(
    (_, i, a) => `v1.2.0-beta.${a.length - i}`,
  );

  const scrollAreaRef = useRef<HTMLDivElement>(null);

  return (
    <div>
      <CodeBox>
        <ScrollArea
          className="h-72 w-56 border text-neutral-500"
          ref={scrollAreaRef}
          onScroll={(e) => {
            console.log('outer', e.currentTarget.scrollTop);
          }}
        >
          <div className="p-4">
            <h4 className="mb-3 text-sm leading-none font-medium">外层滚动</h4>
            <p className="mb-3 text-xs text-neutral-400">
              下方为嵌套的内层 ScrollArea，可分别滚动验证事件与滚动条。
            </p>
            <ScrollArea
              className="h-36 w-full rounded border border-dashed border-neutral-300"
              onScroll={(e) => {
                console.log('inner', e.currentTarget.scrollTop);
              }}
            >
              <div className="p-3">
                <h4 className="mb-2 text-xs font-medium text-neutral-600">
                  内层 Tags
                </h4>
                {tags.map((tag) => (
                  <React.Fragment key={tag}>
                    <div className="text-xs">{tag}</div>
                    <div className="my-1 bg-neutral-200 h-px" />
                  </React.Fragment>
                ))}
              </div>
            </ScrollArea>
            <div className="mt-4 space-y-2 text-xs">
              {Array.from({ length: 12 }).map((_, i) => (
                <div key={i} className="text-neutral-400">
                  外层底部内容块 {i + 1}
                </div>
              ))}
            </div>
          </div>
        </ScrollArea>
      </CodeBox>
      <CodeBlock>{`import { ScrollArea } from "one-design-next";

<ScrollArea className="h-72 w-56 border" ref={scrollAreaRef}>
  <div className="p-4">
    <ScrollArea className="h-36 w-full border border-dashed">...</ScrollArea>
    {/* 外层还有更多可滚动内容 */}
  </div>
</ScrollArea>`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## 阴影 {#shadow}

开启 `insetShadow="start"`，为滚动区域增加上方的内阴影，适用场景如卡片标题 + 内部滚动的组合：

**示例：阴影** — 阴影

```tsx
'use client';

import { ScrollArea } from 'one-design-next';
import React from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const InsetShadow = () => {
  const tags = Array.from({ length: 50 }).map(
    (_, i, a) => `v1.2.0-beta.${a.length - i}`,
  );
  return (
    <div>
      <CodeBox className="flex gap-16">
        <div className="w-[320px] bg-white rounded shadow">
          <div className="flex items-center pl-4 h-12 font-semibold text-sm">
            卡片标题
          </div>
          <ScrollArea className="h-72 text-neutral-500" insetShadow="start">
            <div className="p-4">
              {tags.map((tag) => (
                <React.Fragment key={tag}>
                  <div className="text-sm">{tag}</div>
                  <div className="my-1.5 bg-neutral-200 h-px" />
                </React.Fragment>
              ))}
            </div>
          </ScrollArea>
        </div>
      </CodeBox>
      <CodeBlock>{`import { ScrollArea } from "one-design-next";

<div className="w-[320px] bg-white rounded shadow">
  <div className="flex items-center pl-4 h-12 font-semibold text-sm">
    卡片标题
  </div>
  <ScrollArea className="h-72" insetShadow="start">
    <div className="p-4">
      ...
    </div>
  </ScrollArea>
</div>`}</CodeBlock>
    </div>
  );
};

export default InsetShadow;
```
## 遮罩 {#mask}

开启 `progressiveBlur`，为滚动区域增加渐进模糊遮罩：

**示例：遮罩** — 遮罩

```tsx
'use client';

import { ScrollArea } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
import { Pane } from 'tweakpane';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basics = () => {
  const tags = Array.from({ length: 50 }).map(
    (_, i, a) => `v1.2.0-beta.${a.length - i}`,
  );

  const [params, setParams] = useState({
    progressBlur: 'true' as 'true' | 'false' | 'start' | 'end',
    coverSize: 40, // px
    coverBlur: 2, // px
    coverBgOffset: 25, // %
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'progressBlur', {
      options: {
        true: 'true',
        false: 'false',
        start: 'start',
        end: 'end',
      },
    });

    pane.addBinding(params, 'coverSize', {
      min: 10,
      max: 100,
      step: 1,
      label: 'Cover Size (px)',
    });

    pane.addBinding(params, 'coverBlur', {
      min: 0,
      max: 10,
      step: 0.1,
      label: 'Cover Blur (px)',
    });

    pane.addBinding(params, 'coverBgOffset', {
      min: 0,
      max: 100,
      step: 1,
      label: 'Cover Offset (%)',
    });

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <ScrollArea
          className="h-72 w-48 border text-neutral-500"
          progressiveBlur={
            params.progressBlur === 'true'
              ? true
              : params.progressBlur === 'false'
                ? false
                : params.progressBlur
          }
          style={{
            '--odn-scroll-area-cover-size': `${params.coverSize}px`,
            '--odn-scroll-area-cover-blur': `${params.coverBlur}px`,
            '--odn-scroll-area-cover-bg-offset': `${params.coverBgOffset}%`,
          }}
        >
          <div className="p-4">
            <h4 className="mb-4 text-sm leading-none font-medium">Tags</h4>
            {tags.map((tag) => (
              <React.Fragment key={tag}>
                <div className="text-sm">{tag}</div>
                <div className="my-1.5 bg-neutral-200 h-px" />
              </React.Fragment>
            ))}
          </div>
        </ScrollArea>
      </CodeBox>
      <CodeBlock>{`import { ScrollArea } from "one-design-next";

<ScrollArea
  className="h-72 w-48 border"
  progressiveBlur={${params.progressBlur === 'true' ? 'true' : params.progressBlur === 'false' ? 'false' : `"${params.progressBlur}"`}}
  style={{
    '--odn-scroll-area-cover-size': '${params.coverSize}px',
    '--odn-scroll-area-cover-blur': '${params.coverBlur}px',
    '--odn-scroll-area-cover-bg-offset': '${params.coverBgOffset}%',
  }}
>
  <div className="p-4">
    ...
  </div>
</ScrollArea>`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## 自定义滚动条 {#custom-scrollbar}

通过 CSS 变量自定义滚动条的样式，包括宽度、高度、内边距、背景色和鼠标样式等：

**示例：自定义滚动条** — 自定义滚动条

```tsx
'use client';

import { ScrollArea } from 'one-design-next';
import React from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const CustomScrollbar = () => {
  const tags = Array.from({ length: 50 }).map(
    (_, i, a) => `v1.2.0-beta.${a.length - i}`,
  );

  return (
    <div>
      <CodeBox>
        <ScrollArea
          className="h-72 w-48 border text-neutral-500"
          style={{
            ['--odn-scrollbar-end-padding']: '0',
            ['--odn-scrollbar-side-padding']: '3px',
            ['--odn-scrollbar-side-hover-padding']: '1px',
            ['--odn-scrollbar-hover-cursor']: 'pointer',
            ['--odn-scrollbar-thickness']: '12px',
            ['--odn-scrollbar-background-color']: 'rgba(73, 90, 122, 0.16)',
            ['--odn-scrollbar-hover-background-color']:
              'rgba(73, 90, 122, 0.32)',
          }}
        >
          <div className="p-4">
            <h4 className="mb-4 text-sm leading-none font-medium">Tags</h4>
            {tags.map((tag) => (
              <React.Fragment key={tag}>
                <div className="text-sm">{tag}</div>
                <div className="my-1.5 bg-neutral-200 h-px" />
              </React.Fragment>
            ))}
          </div>
        </ScrollArea>
      </CodeBox>
      <CodeBlock>{`import { ScrollArea } from "one-design-next";

<ScrollArea
  className="h-72 w-48 border"
  style={{
    ['--odn-scrollbar-end-padding']: '0', // 滚动条两端的padding
    ['--odn-scrollbar-side-padding']: '3px', // 滚动条两侧的padding，滑块宽度即 thickness - edge-padding * 2
    ['--odn-scrollbar-side-hover-padding']: '1px',
    ['--odn-scrollbar-hover-cursor']: 'pointer',
    ['--odn-scrollbar-thickness']: '12px',
    ['--odn-scrollbar-background-color']: 'rgba(73, 90, 122, 0.16)',
    ['--odn-scrollbar-hover-background-color']:
      'rgba(73, 90, 122, 0.32)',
  }}
>
  <div className="p-4">
    ...
  </div>
</ScrollArea>`}</CodeBlock>
    </div>
  );
};

export default CustomScrollbar;
```
## API {#api}

继承 `@base-ui/react/scroll-area` 的 `Root` 属性。

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| onScroll | 滚动回调 | `(e: UIEvent<HTMLDivElement>) => void` | - |
| progressiveBlur | 渐进模糊（起/止） | `boolean \| 'start' \| 'end'` | `false` |
| insetShadow | 内阴影（起/止） | `boolean \| 'start' \| 'end'` | `false` |
| className / children | 类名与子节点 | 同 Base UI `ScrollArea.Root` | - |

## 变量 {#variables}

<VariablesTable id="ScrollArea"></VariablesTable>

---

## 表格 Table

## 基础用例 {#basic-usage}

推荐对 `dataSource` 和 `columns` 分别进行类型约束：`dataSource: Person[]`，`columns: TableProps<Person>['columns']`。或者在 `Table` 上添加类型约束：`<Table<Person> />`，以在所有 Props 中获得明确的类型。

**示例：basic** — basic

```tsx
'use client';

import { Dropdown, Icon, Table, type TableProps } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

type Person = {
  key: string;
  name: string;
  age: number;
  address: string;
};

const Basic = () => {
  const [params, setParams] = useState({
    striped: false,
    align: 'left' as 'left' | 'center' | 'right',
    bordered: false,
    rowHoverable: true,
  });

  const dataSource: Person[] = [
    {
      key: '1',
      name: 'Takuya',
      age: 32,
      address: '闵行区沪闵公路 1 号',
    },
    {
      key: '2',
      name: 'Kimura',
      age: 42,
      address: '闵行区沪闵公路 1 号',
    },
  ];

  const columns: TableProps<Person>['columns'] = [
    {
      title: '姓名',
      dataIndex: 'name',
      key: 'name',
      align: params.align,
    },
    {
      title: '年龄',
      dataIndex: 'age',
      key: 'age',
      align: params.align,
    },
    {
      title: '住址',
      dataIndex: 'address',
      key: 'address',
      align: params.align,
    },
    {
      title: '操作',
      dataIndex: 'action',
      key: 'action',
      align: params.align,
      render: ({ row, col, rowIndex, colIndex }) => {
        return (
          <div className="flex items-center gap-4">
            <a
              href="https://wxad.design/abc"
              target="_blank"
              className="flex items-center h-[30px] text-link"
            >
              操作
            </a>
            <a
              href="https://wxad.design/abc"
              target="_blank"
              className="flex items-center h-[30px] text-link"
            >
              操作
            </a>
            <Dropdown
              menu={[
                { label: '操作', value: 'action1' },
                { label: '操作', value: 'action2' },
              ]}
            >
              <Icon
                name="more-vertical"
                color="var(--odn-color-blue-5)"
                className="cursor-pointer"
              />
            </Dropdown>
          </div>
        );
      },
    },
  ];

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });
    pane.addBinding(params, 'striped', { type: 'boolean' });
    pane.addBinding(params, 'align', {
      options: {
        left: 'left',
        center: 'center',
        right: 'right',
      },
    });
    pane.addBinding(params, 'bordered');
    pane.addBinding(params, 'rowHoverable');
    pane.on('change', (ev) =>
      // @ts-ignore
      setParams((prev) => ({ ...prev, [ev.target.key]: ev.value })),
    );
    return () => pane.dispose();
  }, []);

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <Table<Person>
          dataSource={dataSource}
          columns={columns}
          striped={params.striped}
          bordered={params.bordered}
          rowHoverable={params.rowHoverable}
        />
      </CodeBox>
      <CodeBlock>{`import { Table, TableProps } from "one-design-next";

type Person = {
  key: string;
  name: string;
  age: number;
  address: string;
};

const dataSource: Person[] = [
  {
    key: '1',
    name: 'Takuya',
    age: 32,
    address: '闵行区沪闵公路 1 号',
  },
];

const columns: TableProps<Person>['columns'] = [
  {
    title: '姓名',
    dataIndex: 'name',
    key: 'name',
    align: ${params.align},
  },
  {
    title: '年龄',
    dataIndex: 'age',
    key: 'age',
    align: ${params.align},
  },
  {
    title: '住址',
    dataIndex: 'address',
    key: 'address',
    align: ${params.align},
  },
];

<Table<Person>
  dataSource={dataSource}
  columns={columns}
  striped={${params.striped}}
  bordered={${params.bordered}}
  rowHoverable={${params.rowHoverable}}
/>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 行选择 {#row-selection}

与行选择相关的 Props 都放在 `rowSelection` 中。支持单选与多选，同时支持对列宽、对齐等自定义。

通过 `getCheckboxProps` 和 `getRadioProps` 可以自定义 `Checkbox` 和 `Radio` 的属性，常用于设置 `disabled`；配合设置 `popover` 可以自定义提示文字。

还可以通过 `render` 完全自定义单元格，在 `column` 的 `render` 的基础上增加了 `node` 参数。它是内部的默认 `Checkbox` 或 `Radio`，可以在此基础上封装使用：

**示例：rowSelection** — rowSelection

```tsx
'use client';

import { Table, type TableProps } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

type Person = {
  key: string;
  name: string;
  age: number;
  address: string;
};

const Basic = () => {
  const [selectedRowKeys, setSelectedRowKeys] = useState<string[]>(['2']);
  const [params, setParams] = useState({
    selectionType: 'checkbox' as 'checkbox' | 'radio',
    selectAll: true,
    width: false,
    align: 'left' as 'left' | 'center' | 'right',
    selectOnRowClick: false,
    customRender: false,
  });

  const dataSource: Person[] = [
    {
      key: '1',
      name: 'Takuya',
      age: 32,
      address: '闵行区沪闵公路 1 号',
    },
    {
      key: '2',
      name: 'Kimura',
      age: 42,
      address: '闵行区沪闵公路 1 号',
    },
    {
      key: '3',
      name: 'Disabled User',
      age: 28,
      address: '西湖区湖底公园2号',
    },
    {
      key: '4',
      name: '亦亦',
      age: 35,
      address: '西湖区湖底公园3号',
    },
  ];

  const columns: TableProps<Person>['columns'] = [
    {
      title: '姓名',
      dataIndex: 'name',
      key: 'name',
    },
    {
      title: '年龄',
      dataIndex: 'age',
      key: 'age',
    },
    {
      title: '住址',
      dataIndex: 'address',
      key: 'address',
    },
  ];

  const rowSelection: TableProps<Person>['rowSelection'] = {
    type: params.selectionType,
    selectAll: params.selectAll,
    width: params.width ? 60 : undefined,
    align: params.align,
    selectOnRowClick: params.selectOnRowClick,
    selectedRowKeys,
    onChange: (selectedRowKeys, { selectedRows }) => {
      console.log(
        `selectedRowKeys: ${selectedRowKeys}`,
        'selectedRows: ',
        selectedRows,
      );
      setSelectedRowKeys(selectedRowKeys);
    },
    getCheckboxProps: (record) => ({
      disabled: record.name === 'Disabled User', // Column configuration not to be checked
      popover: record.name === 'Disabled User' ? 'Disabled User' : undefined,
      popoverProps: {},
      name: record.name,
    }),
    getRadioProps: (record) => ({
      disabled: record.name === 'Disabled User', // 禁用特定行
      popover: record.name === 'Disabled User' ? 'Disabled User' : undefined,
      popoverProps: {},
    }),
    render: params.customRender
      ? ({ row, rowIndex, node }) => (
          <div className="flex items-center gap-2 text-xs">
            {node}
            {row.age} {rowIndex + 1}
          </div>
        )
      : undefined,
  };

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });
    pane.addBinding(params, 'selectionType', {
      options: {
        checkbox: 'checkbox',
        radio: 'radio',
      },
    });
    pane.addBinding(params, 'selectAll', { type: 'boolean' });
    pane.addBinding(params, 'align', {
      options: {
        left: 'left',
        center: 'center',
        right: 'right',
      },
    });
    pane.addBinding(params, 'selectOnRowClick', { type: 'boolean' });
    pane.addBinding(params, 'width', { type: 'boolean', label: '自定义列宽' });
    pane.addBinding(params, 'customRender', {
      type: 'boolean',
      label: '自定义渲染',
    });
    pane.on('change', (ev) => {
      // @ts-ignore
      setParams((prev) => ({ ...prev, [ev.target.key]: ev.value }));
      // 切换模式时清空选择
      // @ts-ignore
      if (ev.target.key === 'selectionType') {
        setSelectedRowKeys([]);
      }
    });
    return () => pane.dispose();
  }, []);

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <Table
          dataSource={dataSource}
          columns={columns}
          rowSelection={rowSelection}
        />
      </CodeBox>
      <CodeBlock>{`import { Table } from "one-design-next";

const rowSelection = {
  type: "${params.selectionType}",
  selectAll: ${params.selectAll},
  width: ${params.width ? 60 : undefined},
  align: "${params.align}",
  selectedRowKeys,
  onChange: (selectedRowKeys, { selectedRows }) => {
    setSelectedRowKeys(selectedRowKeys);
  },
  getCheckboxProps: (record) => ({
    disabled: record.name === 'Disabled User',
    popover: record.name === 'Disabled User' ? 'Disabled User' : undefined,
    popoverProps: {},
  }),
  getRadioProps: (record) => ({
    disabled: record.name === 'Disabled User',
    popover: record.name === 'Disabled User' ? 'Disabled User' : undefined,
    popoverProps: {},
  }),
  render: ${
    params.customRender
      ? `({ row, rowIndex, node }) => (
    <div className="flex items-center gap-2 text-xs">
      {node}
      Row {rowIndex + 1}
    </div>
  )`
      : 'undefined'
  }
};

<Table<Person> rowSelection={rowSelection} />`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 行开关 {#row-switch}

行开关可以理解为是行选择的扩展，通过上面例子的 `rowSelection.render` 来实现。并且你还可以通过 `type` 设置为 `checkbox` 或 `radio` 来实现单选开关或者多选开关：

**示例：rowSwitch** — rowSwitch

```tsx
'use client';

import { Switch, Table, type TableProps } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

type Person = {
  key: string;
  name: string;
  age: number;
  address: string;
};

const Basic = () => {
  const [params, setParams] = useState({
    multiple: true,
  });

  const [selectedRowKeys, setSelectedRowKeys] = useState<string[]>(['1']);

  const dataSource: Person[] = [
    {
      key: '1',
      name: 'Takuya',
      age: 32,
      address: '闵行区沪闵公路 1 号',
    },
    {
      key: '2',
      name: 'Kimura',
      age: 42,
      address: '闵行区沪闵公路 1 号',
    },
    {
      key: '3',
      name: '李雷',
      age: 28,
      address: '西湖区湖底公园2号',
    },
    {
      key: '4',
      name: '韩梅梅',
      age: 25,
      address: '西湖区湖底公园3号',
    },
  ];

  const columns: TableProps<Person>['columns'] = [
    {
      title: '姓名',
      dataIndex: 'name',
      key: 'name',
    },
    {
      title: '年龄',
      dataIndex: 'age',
      key: 'age',
    },
    {
      title: '住址',
      dataIndex: 'address',
      key: 'address',
    },
  ];

  const rowSelection: TableProps<Person>['rowSelection'] = {
    type: params.multiple ? 'checkbox' : 'radio',
    selectAll: false,
    selectOnRowClick: true,
    selectedRowKeys,
    onChange: (selectedRowKeys, { selectedRows }) => {
      console.log('选中的行:', selectedRowKeys, selectedRows);
      setSelectedRowKeys(selectedRowKeys);
    },
    render: ({ row }) => (
      <Switch
        size="small"
        checked={selectedRowKeys.includes(row.key)}
        onChange={(checked) => {
          if (checked) {
            if (!params.multiple) {
              setSelectedRowKeys([row.key]);
            } else {
              setSelectedRowKeys([...selectedRowKeys, row.key]);
            }
          } else {
            setSelectedRowKeys(
              selectedRowKeys.filter((key) => key !== row.key),
            );
          }
        }}
      />
    ),
  };

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });
    pane.addBinding(params, 'multiple', {
      type: 'boolean',
      label: '多选',
    });
    pane.on('change', (ev) => {
      // @ts-ignore
      setParams((prev) => ({ ...prev, [ev.target.key]: ev.value }));
      // 切换模式时清空选择
      // @ts-ignore
      if (ev.target.key === 'multiple') {
        setSelectedRowKeys([]);
      }
    });
    return () => pane.dispose();
  }, []);

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <Table
          dataSource={dataSource}
          columns={columns}
          rowSelection={rowSelection}
        />
      </CodeBox>
      <CodeBlock>
        {`import { Table, Switch } from "one-design-next";

const rowSelection = {
  type: "${params.multiple ? 'checkbox' : 'radio'}",
  // 隐藏多选按钮
  selectAll: false,
  // 支持点击行选中
  selectOnRowClick: true,
  selectedRowKeys,
  onChange: setSelectedRowKeys,
  render: ({ row }) => (
    <Switch 
      size="small"
      checked={selectedRowKeys.includes(row.key)}
      onChange={(checked) => {
        // 处理开关逻辑
      }}
    />
  ),
};

<Table 
  dataSource={dataSource} 
  columns={columns}
  rowSelection={rowSelection}
/>
`}
      </CodeBlock>
    </div>
  );
};

export default Basic;
```
## 行展开 {#row-expansion}

与行展开相关的 Props 都放在 `rowExpansion` 中。支持外部控制的 `expandedRowKeys` 或内部驱动的 `defaultExpandedRowKeys`。

如果需要自定义样式或逻辑，可设置 `showExpandColumn` 为 `false` 来隐藏默认的展开列，结合 `expandedRowKeys` 完全自定义 UI 和展开的逻辑。

**示例：expand** — expand

```tsx
'use client';

import { Dropdown, Icon, Table, type TableProps } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

type Person = {
  key: string;
  name: string;
  age: number;
  address: string;
};

const Basic = () => {
  const [expandedRowKeys, setExpandedRowKeys] = useState<string[]>(['1']);
  const [params, setParams] = useState({
    expandOnRowClick: false,
    showExpandIcon: true,
  });

  const dataSource: Person[] = [
    {
      key: '1',
      name: 'Takuya',
      age: 32,
      address: '闵行区沪闵公路 1 号',
    },
    {
      key: '2',
      name: 'Kimura',
      age: 42,
      address: '闵行区沪闵公路 1 号',
    },
  ];

  const columns: TableProps<Person>['columns'] = [
    {
      title: '姓名',
      dataIndex: 'name',
      key: 'name',
      align: 'center',
    },
    {
      title: '年龄',
      dataIndex: 'age',
      key: 'age',
      align: 'center',
    },
    {
      title: '住址',
      dataIndex: 'address',
      key: 'address',
    },
    {
      title: '操作',
      dataIndex: 'action',
      key: 'action',
      render: ({ row, col, rowIndex, colIndex }) => {
        return (
          <div className="flex items-center gap-4">
            <a
              href="https://wxad.design/abc"
              target="_blank"
              className="flex items-center h-[30px] text-link"
            >
              操作
            </a>
            <a
              href="https://wxad.design/abc"
              target="_blank"
              className="flex items-center h-[30px] text-link"
            >
              操作
            </a>
            <Dropdown
              menu={[
                { label: '操作', value: 'action1' },
                { label: '操作', value: 'action2' },
              ]}
            >
              <Icon
                name="more-vertical"
                color="var(--odn-color-blue-5)"
                className="cursor-pointer"
              />
            </Dropdown>
          </div>
        );
      },
    },
  ];

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });
    pane.addBinding(params, 'expandOnRowClick', {
      type: 'boolean',
      label: '点击行展开',
    });
    pane.addBinding(params, 'showExpandIcon', {
      type: 'boolean',
      label: '显示展开列',
    });
    pane.on('change', (ev) => {
      // @ts-ignore
      setParams((prev) => ({ ...prev, [ev.target.key]: ev.value }));
    });
    return () => pane.dispose();
  }, []);

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <Table
          dataSource={dataSource}
          columns={columns}
          rowExpansion={{
            expandedRowKeys,
            expandOnRowClick: params.expandOnRowClick,
            onExpandedRowsChange: (expandedRowKeys) => {
              setExpandedRowKeys(expandedRowKeys);
            },
            expandedRowRender: (row: Person) => (
              <p style={{ margin: 0 }}>{row.address}</p>
            ),
            rowExpandable: (row: Person) => row.name !== 'Not Expandable',
            showExpandColumn: params.showExpandIcon,
          }}
        />
      </CodeBox>
      <CodeBlock>{`import { Table } from "one-design-next";

const rowExpansion = {
  expandedRowKeys,
  expandOnRowClick: ${params.expandOnRowClick},
  showExpandColumn: ${params.showExpandIcon},
  onExpandedRowsChange: (expandedRowKeys) => {
    setExpandedRowKeys(expandedRowKeys);
  },
  expandedRowRender: (row) => (
    <p style={{ margin: 0 }}>{row.address}</p>
  ),
  rowExpandable: (row) => row.name !== 'Not Expandable',
};

<Table<Person> rowExpansion={rowExpansion} />`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 排序 {#sorting}

为 `column` 添加 `onSort` 和 `sortOrder` 属性，可以实现排序。考虑到使用场景，没有实现组件内排序的安排，需业务方自行实现。

在设计上，组件会增加一个根据主题色 `--odn-color-primary` 生成的渐变背景，以显示当前列的排序状态。它看起来像是一层完整的过渡，实际上是通过每个单元格的背景合并而来的。你可以在 `Table` 上设置 `sortBgVisible` 为 `false` 来隐藏此设计。

**示例：sort** — sort

```tsx
'use client';

import {
  Dropdown,
  Icon,
  Table,
  type TableProps,
  type TableSortOrder,
} from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
// @ts-ignore
import { Pane } from 'tweakpane';

type Person = {
  key: string;
  name: string;
  age: number;
  address: string;
};

const Basic = () => {
  const [sortStates, setSortStates] = useState<{
    age?: TableSortOrder;
    color?: string;
  }>({
    age: 'descend',
    color: '#296bef',
  });

  const [params, setParams] = useState({
    sortBgVisible: true,
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  // 原始数据
  const originalDataSource: Person[] = [
    {
      key: '1',
      name: 'Takuya',
      age: 32,
      address: '闵行区沪闵公路 1 号',
    },
    {
      key: '2',
      name: 'Kimura',
      age: 42,
      address: '闵行区沪闵公路 1 号',
    },
    {
      key: '3',
      name: '亦亦',
      age: 28,
      address: '西湖区湖底公园2号',
    },
    {
      key: '4',
      name: '李四',
      age: 35,
      address: '西湖区湖底公园3号',
    },
    {
      key: '5',
      name: '张三',
      age: 24,
      address: '浦东新区陆家嘴环路 1 号',
    },
    {
      key: '6',
      name: '王五',
      age: 51,
      address: '徐汇区漕溪北路 398 号',
    },
    {
      key: '7',
      name: 'Satoshi',
      age: 19,
      address: '黄浦区南京东路 800 号',
    },
    {
      key: '8',
      name: '赵六',
      age: 45,
      address: '长宁区延安西路 1882 号',
    },
    {
      key: '9',
      name: 'Yuki',
      age: 37,
      address: '静安区南京西路 1515 号',
    },
    {
      key: '10',
      name: '孙七',
      age: 29,
      address: '普陀区中山北路 2000 号',
    },
    {
      key: '11',
      name: 'Haruto',
      age: 22,
      address: '虹口区四川北路 1688 号',
    },
    {
      key: '12',
      name: '周八',
      age: 56,
      address: '杨浦区国定路 400 号',
    },
    {
      key: '13',
      name: 'Aoi',
      age: 31,
      address: '宝山区牡丹江路 1500 号',
    },
    {
      key: '14',
      name: '吴九',
      age: 48,
      address: '闸北区共和新路 912 号',
    },
    {
      key: '15',
      name: 'Ren',
      age: 26,
      address: '松江区人民北路 1 号',
    },
    {
      key: '16',
      name: '郑十',
      age: 39,
      address: '嘉定区博乐南路 1 号',
    },
    {
      key: '17',
      name: 'Mei',
      age: 33,
      address: '奉贤区南桥镇解放路 600 号',
    },
    {
      key: '18',
      name: '冯一一',
      age: 41,
      address: '青浦区公园路 100 号',
    },
    {
      key: '19',
      name: 'Kenji',
      age: 27,
      address: '崇明区城桥镇人民路 28 号',
    },
    {
      key: '20',
      name: '陈二二',
      age: 53,
      address: '金山区蒙山北路 900 号',
    },
  ];

  const [dataSource, setDataSource] = useState<Person[]>(originalDataSource);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });
    pane.addBinding(params, 'sortBgVisible', { type: 'boolean' });
    pane.addBinding(sortStates, 'color', { type: 'color' });
    pane.on('change', (ev) =>
      // @ts-ignore
      setParams((prev) => ({ ...prev, [ev.target.key]: ev.value })),
    );
    return () => pane.dispose();
  }, []);

  // 排序处理函数
  const handleSort = (field: keyof Person, sortOrder: TableSortOrder) => {
    setSortStates((prev) => ({
      ...prev,
      [field]: sortOrder,
    }));

    // 如果排序为 null，恢复原始数据
    if (sortOrder === null) {
      setDataSource(originalDataSource);
      return;
    }

    // 执行排序
    const sortedData = [...originalDataSource].sort((a, b) => {
      const aValue = a[field];
      const bValue = b[field];

      if (typeof aValue === 'string' && typeof bValue === 'string') {
        return sortOrder === 'ascend'
          ? aValue.localeCompare(bValue)
          : bValue.localeCompare(aValue);
      }

      if (typeof aValue === 'number' && typeof bValue === 'number') {
        return sortOrder === 'ascend' ? aValue - bValue : bValue - aValue;
      }

      return 0;
    });

    setDataSource(sortedData);
  };

  const columns: TableProps<Person>['columns'] = [
    {
      title: '姓名',
      dataIndex: 'name',
      key: 'name',
      align: 'center',
    },
    {
      title: '年龄',
      dataIndex: 'age',
      key: 'age',
      align: 'center',
      sortOrder: sortStates.age,
      onSort: (sortOrder) => handleSort('age', sortOrder),
    },
    {
      title: '住址',
      dataIndex: 'address',
      key: 'address',
    },
    {
      title: '操作',
      dataIndex: 'action',
      key: 'action',
      render: ({ row, col, rowIndex, colIndex }) => {
        return (
          <div className="flex items-center gap-4">
            <a
              href="https://wxad.design/abc"
              target="_blank"
              className="flex items-center h-[30px] text-link"
            >
              操作
            </a>
            <a
              href="https://wxad.design/abc"
              target="_blank"
              className="flex items-center h-[30px] text-link"
            >
              操作
            </a>
            <Dropdown
              menu={[
                { label: '操作', value: 'action1' },
                { label: '操作', value: 'action2' },
              ]}
            >
              <Icon
                name="more-vertical"
                color="var(--odn-color-blue-5)"
                className="cursor-pointer"
              />
            </Dropdown>
          </div>
        );
      },
    },
  ];

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <Table
          dataSource={dataSource}
          columns={columns}
          sortBgVisible={params.sortBgVisible}
          scroll={{ x: 'max-content', y: 300 }}
          style={
            {
              '--odn-color-primary': sortStates.color,
            } as React.CSSProperties
          }
        />
      </CodeBox>
      <CodeBlock>{`import { Table, TableSortOrder } from "one-design-next";

const columns: TableProps<Person>['columns'] = [
  {
    title: '年龄',
    dataIndex: 'age',
    key: 'age',
    align: 'center',
    sortOrder: sortStates.age,
    // 在这里处理 dataSource 的排序
    onSort: (sortOrder) => {},
  },
];

<Table<Person> 
  dataSource={dataSource} 
  columns={columns} 
  sortBgVisible={true}
/>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 过滤 {#filtering}

为 `column` 添加 `filters`、`filteredValue`、`filterMultiple`、`onFilter`、`onFilterChange` 属性，可以实现过滤。

**示例：filter** — filter

```tsx
'use client';

import { Table, type TableProps } from 'one-design-next';
import React, { useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
// @ts-ignore

type Person = {
  key: string;
  name: string;
  age: number;
  address: string;
  category: number;
  status: string;
};

const Basic = () => {
  const [filteredValues, setFilteredValues] = useState<{
    category?: number[];
    status?: string[];
  }>({
    category: [1], // 默认选中分类 A
    status: [], // 默认无状态过滤
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  // 原始数据
  const originalDataSource: Person[] = [
    {
      key: '1',
      name: 'Takuya',
      age: 32,
      address: '闵行区沪闵公路 1 号',
      category: 1,
      status: 'active',
    },
    {
      key: '2',
      name: 'Kimura',
      age: 42,
      address: '闵行区沪闵公路 1 号',
      category: 2,
      status: 'inactive',
    },
    {
      key: '3',
      name: '李大嘴',
      age: 32,
      address: '闵行区沪闵公路 1 号',
      category: 1,
      status: 'active',
    },
    {
      key: '4',
      name: '王五',
      age: 28,
      address: '西湖区湖底公园2号',
      category: 3,
      status: 'pending',
    },
    {
      key: '5',
      name: '赵六',
      age: 35,
      address: '西湖区湖底公园3号',
      category: 2,
      status: 'active',
    },
    {
      key: '6',
      name: '钱七',
      age: 29,
      address: '西湖区湖底公园4号',
      category: 1,
      status: 'inactive',
    },
  ];

  // 过滤数据
  const getFilteredDataSource = () => {
    let filtered = [...originalDataSource];

    // 分类过滤
    if (filteredValues.category && filteredValues.category.length > 0) {
      filtered = filtered.filter((item) =>
        filteredValues.category!.includes(item.category),
      );
    }

    // 状态过滤
    if (filteredValues.status && filteredValues.status.length > 0) {
      filtered = filtered.filter((item) =>
        filteredValues.status!.includes(item.status),
      );
    }

    return filtered;
  };

  const columns: TableProps<Person>['columns'] = [
    {
      title: '姓名',
      dataIndex: 'name',
      key: 'name',
    },
    {
      title: '年龄',
      dataIndex: 'age',
      key: 'age',
    },
    {
      title: '住址',
      dataIndex: 'address',
      key: 'address',
    },
    {
      title: '分类',
      dataIndex: 'category',
      key: 'category',
      filters: [
        { text: '分类 A', value: 1 },
        { text: '分类 B', value: 2 },
        { text: '分类 C', value: 3 },
      ],
      filteredValue: filteredValues.category,
      filterMultiple: false, // 单选过滤
      onFilterChange: (values) => {
        setFilteredValues((prev) => ({
          ...prev,
          category: values as number[],
        }));
      },
      render: ({ row }) => {
        const categoryMap: Record<number, string> = {
          1: '分类 A',
          2: '分类 B',
          3: '分类 C',
        };
        return categoryMap[row.category] || '未知';
      },
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      filters: [
        { text: '激活', value: 'active' },
        { text: '非激活', value: 'inactive' },
        { text: '待处理', value: 'pending' },
      ],
      filteredValue: filteredValues.status,
      filterMultiple: true, // 多选过滤
      onFilterChange: (values) => {
        setFilteredValues((prev) => ({
          ...prev,
          status: values as string[],
        }));
      },
      render: ({ row }) => {
        const statusMap: Record<string, string> = {
          active: '激活',
          inactive: '非激活',
          pending: '待处理',
        };
        return statusMap[row.status] || '未知';
      },
    },
  ];

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <Table<Person> dataSource={getFilteredDataSource()} columns={columns} />
      </CodeBox>

      <CodeBlock>{`import { Table, TableProps } from "one-design-next";

const columns: TableProps<Person>['columns'] = [
  {
    title: '分类',
    dataIndex: 'category',
    key: 'category',
    filters: [
      { text: '分类 A', value: 1 },
      { text: '分类 B', value: 2 },
      { text: '分类 C', value: 3 },
    ],
    filteredValue: filteredValues.category,
    filterMultiple: false, // 单选过滤
    onFilterChange: (values) => {
      // 处理过滤值变化
    },
  },
  {
    title: '状态',
    dataIndex: 'status',
    key: 'status',
    filters: [
      { text: '激活', value: 'active' },
      { text: '非激活', value: 'inactive' },
      { text: '待处理', value: 'pending' },
    ],
    filteredValue: filteredValues.status,
    filterMultiple: true, // 多选过滤
    onFilterChange: (values) => {
      // 处理过滤值变化
    },
  },
];

<Table<Person> 
  dataSource={filteredDataSource} 
  columns={columns} 
/>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 内滚动 {#internal-scroll}

设置 `scroll` 属性，可以实现内滚动，如 `scroll={{ x: 'max-content', y: 300 }}`，一般 `x` 设置为 `max-content` 即可（如果列需要 `ellipsis` 则设置为 `fit-content`），`y` 设置为需要滚动的最大高度。可通过 `onScroll` 监听滚动事件。

在横向滚动时，配合 `column` 的 `fixed` 属性，可以实现固定列：

**示例：scroll** — scroll

```tsx
'use client';

import { Dropdown, Icon, Table, type TableProps } from 'one-design-next';
import React from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

type Person = {
  key: string;
  name: string;
  age: number;
  address: string;
  email: string;
  phone: string;
  card: string;
};

const Basic = () => {
  const dataSource: Person[] = [
    {
      key: '1',
      name: 'Takuya',
      age: 32,
      address: '闵行区沪闵公路 1 号闵行区沪闵公路 1 号闵行区沪闵公路 1 号',
      email: '1234567890@qq.com',
      phone: '1234567890',
      card: '12345678901234567890',
    },
    {
      key: '2',
      name: 'Kimura',
      age: 42,
      address: '闵行区沪闵公路 1 号闵行区沪闵公路 1 号闵行区沪闵公路 1 号',
      email: '1234567890@qq.com',
      phone: '1234567890',
      card: '12345678901234567890',
    },
    {
      key: '3',
      name: 'Takuya',
      age: 32,
      address: '闵行区沪闵公路 1 号闵行区沪闵公路 1 号闵行区沪闵公路 1 号',
      email: '1234567890@qq.com',
      phone: '1234567890',
      card: '12345678901234567890',
    },
    {
      key: '4',
      name: 'Takuya',
      age: 32,
      address: '闵行区沪闵公路 1 号闵行区沪闵公路 1 号闵行区沪闵公路 1 号',
      email: '1234567890@qq.com',
      phone: '1234567890',
      card: '12345678901234567890',
    },
    {
      key: '5',
      name: 'Takuya',
      age: 32,
      address: '闵行区沪闵公路 1 号闵行区沪闵公路 1 号闵行区沪闵公路 1 号',
      email: '1234567890@qq.com',
      phone: '1234567890',
      card: '12345678901234567890',
    },
    {
      key: '6',
      name: 'Takuya',
      age: 32,
      address: '闵行区沪闵公路 1 号闵行区沪闵公路 1 号闵行区沪闵公路 1 号',
      email: '1234567890@qq.com',
      phone: '1234567890',
      card: '12345678901234567890',
    },
    {
      key: '7',
      name: 'Takuya',
      age: 32,
      address: '闵行区沪闵公路 1 号闵行区沪闵公路 1 号闵行区沪闵公路 1 号',
      email: '1234567890@qq.com',
      phone: '1234567890',
      card: '12345678901234567890',
    },
  ];

  const columns: TableProps<Person>['columns'] = [
    {
      title: '姓名',
      dataIndex: 'name',
      key: 'name',
      align: 'center',
      minWidth: 100,
      fixed: true,
    },
    {
      title: '年龄',
      dataIndex: 'age',
      key: 'age',
      align: 'center',
      minWidth: 100,
      fixed: true,
    },
    {
      title: '住址',
      dataIndex: 'address',
      key: 'address',
      minWidth: 300,
      width: 300,
    },
    {
      title: '邮箱',
      dataIndex: 'email',
      key: 'email',
      minWidth: 100,
    },
    {
      title: '电话',
      dataIndex: 'phone',
      key: 'phone',
      minWidth: 100,
    },
    {
      title: '卡号',
      dataIndex: 'card',
      key: 'card',
      minWidth: 100,
    },
    {
      title: '操作',
      dataIndex: 'action',
      key: 'action',
      render: ({ row, col, rowIndex, colIndex }) => {
        return (
          <div className="flex items-center gap-4">
            <a
              href="https://wxad.design/abc"
              target="_blank"
              className="flex items-center h-[30px] text-link"
            >
              操作
            </a>
            <a
              href="https://wxad.design/abc"
              target="_blank"
              className="flex items-center h-[30px] text-link"
            >
              操作
            </a>
            <Dropdown
              menu={[
                { label: '操作', value: 'action1' },
                { label: '操作', value: 'action2' },
              ]}
            >
              <Icon
                name="more-vertical"
                color="var(--odn-color-blue-5)"
                className="cursor-pointer"
              />
            </Dropdown>
          </div>
        );
      },
      minWidth: 100,
      fixed: 'right',
    },
  ];

  return (
    <div>
      <CodeBox className="flex flex-col">
        <Table
          dataSource={dataSource}
          columns={columns}
          scroll={{ x: 'max-content', y: 300 }}
        />
      </CodeBox>
      <CodeBlock>{`import { Table } from "one-design-next";

<Table<Person>
  dataSource={dataSource}
  columns={columns}
  scroll={{ x: 'max-content', y: 300 }}
/>;`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 表头 sticky {#sticky-header}

和上面内滚动不同的是，有时我们希望表格充分利用窗口高度，让表头固定在页面的顶部，此时可以设置 `sticky` 属性实现。还可以设置 `sticky.offsetHeader` 和 `sticky.offsetScroll` 来设置顶部表头和底部滚动条的偏移量：

**示例：sticky** — sticky

```tsx
'use client';

import { Dropdown, Icon, Table, type TableProps } from 'one-design-next';
import React from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

type Person = {
  key: string;
  name: string;
  age: number;
  address: string;
  email: string;
  phone: string;
  card: string;
};

const Basic = () => {
  const dataSource: Person[] = [
    {
      key: '1',
      name: 'Takuya',
      age: 32,
      address: '闵行区沪闵公路 1 号闵行区沪闵公路 1 号闵行区沪闵公路 1 号',
      email: '1234567890@qq.com',
      phone: '1234567890',
      card: '12345678901234567890',
    },
    {
      key: '2',
      name: 'Kimura',
      age: 42,
      address: '闵行区沪闵公路 1 号闵行区沪闵公路 1 号闵行区沪闵公路 1 号',
      email: '1234567890@qq.com',
      phone: '1234567890',
      card: '12345678901234567890',
    },
    {
      key: '3',
      name: 'Takuya',
      age: 32,
      address: '闵行区沪闵公路 1 号闵行区沪闵公路 1 号闵行区沪闵公路 1 号',
      email: '1234567890@qq.com',
      phone: '1234567890',
      card: '12345678901234567890',
    },
    {
      key: '4',
      name: 'Takuya',
      age: 32,
      address: '闵行区沪闵公路 1 号闵行区沪闵公路 1 号闵行区沪闵公路 1 号',
      email: '1234567890@qq.com',
      phone: '1234567890',
      card: '12345678901234567890',
    },
    {
      key: '5',
      name: 'Takuya',
      age: 32,
      address: '闵行区沪闵公路 1 号闵行区沪闵公路 1 号闵行区沪闵公路 1 号',
      email: '1234567890@qq.com',
      phone: '1234567890',
      card: '12345678901234567890',
    },
    {
      key: '6',
      name: 'Takuya',
      age: 32,
      address: '闵行区沪闵公路 1 号闵行区沪闵公路 1 号闵行区沪闵公路 1 号',
      email: '1234567890@qq.com',
      phone: '1234567890',
      card: '12345678901234567890',
    },
    {
      key: '7',
      name: 'Takuya',
      age: 32,
      address: '闵行区沪闵公路 1 号闵行区沪闵公路 1 号闵行区沪闵公路 1 号',
      email: '1234567890@qq.com',
      phone: '1234567890',
      card: '12345678901234567890',
    },
  ];

  const columns: TableProps<Person>['columns'] = [
    {
      title: '姓名',
      dataIndex: 'name',
      key: 'name',
      align: 'center',
      minWidth: 100,
      fixed: true,
    },
    {
      title: '年龄',
      dataIndex: 'age',
      key: 'age',
      align: 'center',
      minWidth: 100,
      fixed: true,
    },
    {
      title: '住址',
      dataIndex: 'address',
      key: 'address',
      minWidth: 300,
      width: 300,
    },
    {
      title: '邮箱',
      dataIndex: 'email',
      key: 'email',
      minWidth: 100,
    },
    {
      title: '电话',
      dataIndex: 'phone',
      key: 'phone',
      minWidth: 100,
    },
    {
      title: '卡号',
      dataIndex: 'card',
      key: 'card',
      minWidth: 100,
    },
    {
      title: '操作',
      dataIndex: 'action',
      key: 'action',
      render: ({ row, col, rowIndex, colIndex }) => {
        return (
          <div className="flex items-center gap-4">
            <a
              href="https://wxad.design/abc"
              target="_blank"
              className="flex items-center h-[30px] text-link"
            >
              操作
            </a>
            <a
              href="https://wxad.design/abc"
              target="_blank"
              className="flex items-center h-[30px] text-link"
            >
              操作
            </a>
            <Dropdown
              menu={[
                { label: '操作', value: 'action1' },
                { label: '操作', value: 'action2' },
              ]}
            >
              <Icon
                name="more-vertical"
                color="var(--odn-color-blue-5)"
                className="cursor-pointer"
              />
            </Dropdown>
          </div>
        );
      },
      minWidth: 100,
      fixed: 'right',
    },
  ];

  return (
    <div>
      <CodeBox className="flex flex-col">
        <Table
          dataSource={dataSource}
          columns={columns}
          scroll={{ x: 'max-content' }}
          sticky={{
            offsetHeader: 0,
            offsetScroll: 0,
          }}
        />
      </CodeBox>
      <CodeBlock>{`import { Table } from "one-design-next";

<Table<Person>
  dataSource={dataSource}
  columns={columns}
  scroll={{ x: 'max-content' }}
  sticky={{
    offsetHeader: 0,
    offsetScroll: 0,
  }}
/>;`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 表头组与提示文字 {#header-groups-tooltips}

对 `column` 对象添加 `children` 属性，可以实现表头组。推荐配合 `bordered` 使用。

对 `column` 对象添加 `popover` 属性，可以设置表头提示文字，可通过 `popoverProps` 透传 `Popover` 的属性。样式上，默认为下划线样式，如果想要一个独立的 icon，可在 `Table` 上或 `column` 中设置 `popoverIcon` 来添加后缀 icon：

**示例：column-group** — column-group

```tsx
'use client';

import { Dropdown, Icon, Table, type TableProps } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

type Person = {
  key: string;
  name: string;
  age: number;
  address: string;
};

const Basic = () => {
  const [params, setParams] = useState({
    popover: true,
    popoverIcon: false,
  });

  const dataSource: Person[] = [
    {
      key: '1',
      name: 'Takuya',
      age: 32,
      address: '闵行区沪闵公路 1 号',
    },
    {
      key: '2',
      name: 'Kimura',
      age: 42,
      address: '闵行区沪闵公路 1 号',
    },
  ];

  const columns: TableProps<Person>['columns'] = [
    {
      title: '表头组配合 bordered 使用',
      align: 'center',
      popover: params.popover
        ? '这是一个表头组，包含姓名和年龄字段'
        : undefined,
      children: [
        {
          title: '姓名',
          dataIndex: 'name',
          key: 'name',
          align: 'center',
          popover: params.popover ? '用户的真实姓名' : undefined,
        },
        {
          title: '年龄',
          dataIndex: 'age',
          key: 'age',
          align: 'center',
          popover: params.popover ? '用户的年龄（单位：岁）' : undefined,
        },
      ],
    },
    {
      title: '住址',
      dataIndex: 'address',
      key: 'address',
      popover: params.popover ? '用户的居住地址信息' : undefined,
    },
    {
      title: '操作',
      dataIndex: 'action',
      key: 'action',
      render: ({ row, col, rowIndex, colIndex }) => {
        return (
          <div className="flex items-center gap-4">
            <a
              href="https://wxad.design/abc"
              target="_blank"
              className="flex items-center h-[30px] text-link"
            >
              操作
            </a>
            <a
              href="https://wxad.design/abc"
              target="_blank"
              className="flex items-center h-[30px] text-link"
            >
              操作
            </a>
            <Dropdown
              menu={[
                { label: '操作', value: 'action1' },
                { label: '操作', value: 'action2' },
              ]}
            >
              <Icon
                name="more-vertical"
                color="var(--odn-color-blue-5)"
                className="cursor-pointer"
              />
            </Dropdown>
          </div>
        );
      },
    },
  ];

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });
    pane.addBinding(params, 'popover', {
      type: 'boolean',
    });
    pane.addBinding(params, 'popoverIcon', {
      type: 'boolean',
      label: '独立图标',
    });
    pane.on('change', (ev) => {
      // @ts-ignore
      setParams((prev) => ({ ...prev, [ev.target.key]: ev.value }));
    });
    return () => pane.dispose();
  }, []);

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <Table
          dataSource={dataSource}
          columns={columns}
          bordered
          popoverIcon={params.popoverIcon ? 'help-circle' : undefined}
        />
      </CodeBox>
      <CodeBlock>{`import { Table } from "one-design-next";

const columns: TableProps<Person>['columns'] = [
  {
    title: '表头组配合 bordered 使用',
    align: 'center',
    children: [
      {
        title: '姓名',
        dataIndex: 'name',
        key: 'name',
        align: 'center',
        ${params.popover ? `popover: '用户的真实姓名',` : '// popover: "提示文字",'}
      },
      {
        title: '年龄',
        dataIndex: 'age',
        key: 'age',
        align: 'center',
        ${params.popover ? `popover: '用户的年龄（单位：岁）',` : ''}
      },
    ],
  },
];

<Table 
  dataSource={dataSource} 
  columns={columns} 
  bordered
  popoverIcon="${params.popoverIcon ? 'help-circle' : ''}"
/>
`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 文本省略 {#text-ellipsis}

为 `column` 添加 `ellipsis` 属性，可以实现文本省略。当渲染内容为 `string` 时，`Table` 会以 `Popover` 的方式显示完整内容：

**示例：ellipsis** — ellipsis

```tsx
'use client';

import { Table, type TableProps } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

type Person = {
  key: string;
  name: string;
  age: number;
  address: string;
  description: string;
  email: string;
};

const Ellipsis = () => {
  const [selectedRowKeys, setSelectedRowKeys] = useState<string[]>([]);
  const [params, setParams] = useState({
    ellipsis: true,
    width: 200,
    placement: 'top' as 'top' | 'right',
  });

  const dataSource: Person[] = [
    {
      key: '1',
      name: 'Takuya',
      age: 32,
      address:
        '闵行区沪闵公路 1 号闵行区沪闵公路 1 号闵行区沪闵公路 1 号闵行区沪闵公路 1 号',
      description:
        '这是一段很长的描述文字，用来测试省略号功能。当文字超出容器宽度时，会自动显示省略号，并且鼠标悬停时会显示完整内容的 Popover。',
      email: 'huyanbin@example.com',
    },
    {
      key: '2',
      name: 'Kimura',
      age: 42,
      address: '闵行区沪闵公路 1 号',
      description: '短描述',
      email: 'huyanzu@example.com',
    },
    {
      key: '3',
      name: '亦亦',
      age: 28,
      address:
        '闵行区沪闵公路 1 号闵行区沪闵公路 1 号闵行区沪闵公路 1 号闵行区沪闵公路 1 号',
      description: '这是一个中等长度的描述，用来测试不同长度文本的省略效果。',
      email: 'zhangsan@example.com',
    },
    {
      key: '4',
      name: '张三',
      age: 25,
      address: '上海市浦东新区陆家嘴金融贸易区世纪大道 1000 号上海环球金融中心',
      description:
        '这是一个非常长的描述文字，用来测试表格的省略号功能。当文字内容超出列宽时，应该显示省略号，并且可以通过鼠标悬停查看完整内容。这个功能对于处理长文本非常有用。',
      email: 'zhangsan@company.com',
    },
    {
      key: '5',
      name: '李四',
      age: 30,
      address: '北京市朝阳区建国门外大街 1 号国贸大厦',
      description: '短文本测试',
      email: 'lisi@company.com',
    },
    {
      key: '6',
      name: '王五',
      age: 35,
      address: '广州市天河区珠江新城花城大道 85 号高德置地广场',
      description:
        '中等长度的描述文本，用于测试省略号在不同长度文本下的表现效果。',
      email: 'wangwu@company.com',
    },
    {
      key: '7',
      name: '赵六',
      age: 28,
      address: '深圳市南山区科技园南区深南大道 9988 号大族激光科技中心',
      description:
        '这是一个超长的描述文字，用来充分测试表格的省略号功能。当文字内容远远超出列宽时，应该正确显示省略号，并且用户可以通过鼠标悬停来查看完整的内容。这个功能在处理大量数据时非常重要，能够保持界面的整洁性。',
      email: 'zhaoliu@company.com',
    },
    {
      key: '8',
      name: '钱七',
      age: 33,
      address: '杭州市西湖区文三路 259 号昌地火炬大厦',
      description: '测试文本',
      email: 'qianqi@company.com',
    },
    {
      key: '9',
      name: '孙八',
      age: 29,
      address: '成都市锦江区红星路三段 1 号国际金融中心',
      description:
        '这是一个用于测试省略号功能的中等长度描述文本，包含了中文和英文混合内容。',
      email: 'sunba@company.com',
    },
    {
      key: '10',
      name: '周九',
      age: 31,
      address: '武汉市江汉区中山大道 818 号佳丽广场',
      description:
        '很长的描述文字，用来测试表格省略号功能。当文本超出容器宽度时，应该显示省略号，并且支持鼠标悬停查看完整内容。这个功能对于数据展示非常重要。',
      email: 'zhoujiu@company.com',
    },
    {
      key: '11',
      name: '吴十',
      age: 27,
      address: '南京市鼓楼区中山路 321 号南京国际金融中心',
      description: '短描述',
      email: 'wushi@company.com',
    },
    {
      key: '12',
      name: '郑十一',
      age: 34,
      address: '西安市雁塔区高新路 52 号高科大厦',
      description:
        '这是一个中等长度的描述文本，用于测试表格的省略号功能在不同文本长度下的表现。',
      email: 'zhengshiyi@company.com',
    },
    {
      key: '13',
      name: '王十二',
      age: 26,
      address: '重庆市渝中区解放碑步行街 88 号重庆环球金融中心',
      description:
        '超长描述文字测试，用来验证表格省略号功能在处理极长文本时的表现。当文本内容远超列宽时，应该正确显示省略号，并提供悬停查看完整内容的功能。',
      email: 'wangshier@company.com',
    },
    {
      key: '14',
      name: '李十三',
      age: 32,
      address: '天津市和平区南京路 219 号天津中心',
      description: '测试文本内容',
      email: 'lishisan@company.com',
    },
    {
      key: '15',
      name: '张十四',
      age: 29,
      address: '青岛市市南区香港中路 76 号青岛国际金融中心',
      description:
        '这是一个用于测试省略号功能的中等长度描述文本，包含了各种字符和标点符号。',
      email: 'zhangshisi@company.com',
    },
    {
      key: '16',
      name: '刘十五',
      age: 35,
      address: '大连市中山区人民路 9 号大连友谊商城',
      description:
        '很长的描述文字，用来测试表格省略号功能。当文本超出容器宽度时，应该显示省略号，并且支持鼠标悬停查看完整内容。这个功能对于数据展示非常重要，能够保持界面的整洁性。',
      email: 'liushiwu@company.com',
    },
    {
      key: '17',
      name: '陈十六',
      age: 28,
      address: '厦门市思明区鹭江道 8 号厦门国际银行大厦',
      description: '短文本',
      email: 'chenshiliu@company.com',
    },
    {
      key: '18',
      name: '杨十七',
      age: 31,
      address: '福州市鼓楼区五四路 111 号宜发大厦',
      description:
        '中等长度的描述文本，用于测试省略号在不同长度文本下的表现效果和用户体验。',
      email: 'yangshiqi@company.com',
    },
    {
      key: '19',
      name: '黄十八',
      age: 33,
      address: '长沙市芙蓉区五一大道 389 号华美欧大厦',
      description:
        '这是一个超长的描述文字，用来充分测试表格的省略号功能。当文字内容远远超出列宽时，应该正确显示省略号，并且用户可以通过鼠标悬停来查看完整的内容。这个功能在处理大量数据时非常重要。',
      email: 'huangshiba@company.com',
    },
    {
      key: '20',
      name: '赵十九',
      age: 27,
      address: '郑州市金水区花园路 27 号河南省科技馆',
      description: '测试内容',
      email: 'zhaoshijiu@company.com',
    },
    {
      key: '21',
      name: '周二十',
      age: 30,
      address: '石家庄市长安区中山东路 216 号石家庄国际大厦',
      description:
        '这是一个用于测试省略号功能的中等长度描述文本，包含了中文和英文混合内容以及各种标点符号。',
      email: 'zhoushier@company.com',
    },
    {
      key: '22',
      name: '吴二一',
      age: 34,
      address: '太原市迎泽区迎泽大街 69 号太原国际金融中心',
      description:
        '很长的描述文字，用来测试表格省略号功能。当文本超出容器宽度时，应该显示省略号，并且支持鼠标悬停查看完整内容。这个功能对于数据展示非常重要，能够保持界面的整洁性和用户体验。',
      email: 'wushiyi@company.com',
    },
    {
      key: '23',
      name: '郑二二',
      age: 26,
      address: '呼和浩特市新城区新华大街 1 号内蒙古国际金融中心',
      description: '短描述文本',
      email: 'zhengshier@company.com',
    },
    {
      key: '24',
      name: '王二三',
      age: 32,
      address: '沈阳市和平区南京北街 208 号沈阳国际金融中心',
      description:
        '中等长度的描述文本，用于测试表格的省略号功能在不同文本长度下的表现和用户体验。',
      email: 'wangshisan@company.com',
    },
    {
      key: '25',
      name: '李二四',
      age: 29,
      address: '长春市朝阳区人民大街 5688 号长春国际金融中心',
      description:
        '超长描述文字测试，用来验证表格省略号功能在处理极长文本时的表现。当文本内容远超列宽时，应该正确显示省略号，并提供悬停查看完整内容的功能。',
      email: 'lishisi@company.com',
    },
    {
      key: '26',
      name: '张二五',
      age: 35,
      address: '哈尔滨市道里区中央大街 1 号哈尔滨国际金融中心',
      description: '测试文本',
      email: 'zhangshiwu@company.com',
    },
    {
      key: '27',
      name: '刘二六',
      age: 28,
      address: '济南市历下区经十路 17703 号济南国际金融中心',
      description:
        '这是一个用于测试省略号功能的中等长度描述文本，包含了各种字符和标点符号以及中英文混合内容。',
      email: 'liushiliu@company.com',
    },
    {
      key: '28',
      name: '陈二七',
      age: 31,
      address: '合肥市蜀山区长江西路 200 号合肥国际金融中心',
      description:
        '很长的描述文字，用来测试表格省略号功能。当文本超出容器宽度时，应该显示省略号，并且支持鼠标悬停查看完整内容。这个功能对于数据展示非常重要，能够保持界面的整洁性。',
      email: 'chenshiq@company.com',
    },
    {
      key: '29',
      name: '杨二八',
      age: 33,
      address: '南昌市东湖区八一大道 357 号南昌国际金融中心',
      description: '短文本测试',
      email: 'yangshiba@company.com',
    },
    {
      key: '30',
      name: '黄二九',
      age: 27,
      address: '福州市台江区江滨中大道 116 号福州国际金融中心',
      description:
        '中等长度的描述文本，用于测试省略号在不同长度文本下的表现效果和用户体验。',
      email: 'huangshijiu@company.com',
    },
    {
      key: '31',
      name: '赵三十',
      age: 30,
      address: '南宁市青秀区民族大道 136 号南宁国际金融中心',
      description:
        '这是一个超长的描述文字，用来充分测试表格的省略号功能。当文字内容远远超出列宽时，应该正确显示省略号，并且用户可以通过鼠标悬停来查看完整的内容。',
      email: 'zhaosanshi@company.com',
    },
    {
      key: '32',
      name: '周三一',
      age: 34,
      address: '海口市龙华区国贸路 26 号海口国际金融中心',
      description: '测试内容描述',
      email: 'zhousanyi@company.com',
    },
    {
      key: '33',
      name: '吴三二',
      age: 26,
      address: '昆明市五华区东风西路 1 号昆明国际金融中心',
      description:
        '这是一个用于测试省略号功能的中等长度描述文本，包含了中文和英文混合内容以及各种标点符号。',
      email: 'wushier@company.com',
    },
    {
      key: '34',
      name: '郑三三',
      age: 32,
      address: '贵阳市南明区中华南路 1 号贵阳国际金融中心',
      description:
        '很长的描述文字，用来测试表格省略号功能。当文本超出容器宽度时，应该显示省略号，并且支持鼠标悬停查看完整内容。这个功能对于数据展示非常重要。',
      email: 'zhengshisan@company.com',
    },
    {
      key: '35',
      name: '王三四',
      age: 29,
      address: '拉萨市城关区北京中路 1 号拉萨国际金融中心',
      description: '短描述',
      email: 'wangshisi@company.com',
    },
    {
      key: '36',
      name: '李三五',
      age: 35,
      address: '西安市雁塔区高新路 52 号高科大厦',
      description:
        '中等长度的描述文本，用于测试表格的省略号功能在不同文本长度下的表现和用户体验。',
      email: 'lishiwu@company.com',
    },
    {
      key: '37',
      name: '张三六',
      age: 28,
      address: '兰州市城关区天水路 1 号兰州国际金融中心',
      description:
        '超长描述文字测试，用来验证表格省略号功能在处理极长文本时的表现。当文本内容远超列宽时，应该正确显示省略号。',
      email: 'zhangshiliu@company.com',
    },
    {
      key: '38',
      name: '刘三七',
      age: 31,
      address: '西宁市城东区八一路 1 号西宁国际金融中心',
      description: '测试文本内容',
      email: 'liushiq@company.com',
    },
    {
      key: '39',
      name: '陈三八',
      age: 33,
      address: '银川市兴庆区解放东街 1 号银川国际金融中心',
      description:
        '这是一个用于测试省略号功能的中等长度描述文本，包含了各种字符和标点符号。',
      email: 'chenshiba@company.com',
    },
    {
      key: '40',
      name: '杨三九',
      age: 27,
      address: '乌鲁木齐市天山区人民路 1 号乌鲁木齐国际金融中心',
      description:
        '很长的描述文字，用来测试表格省略号功能。当文本超出容器宽度时，应该显示省略号，并且支持鼠标悬停查看完整内容。',
      email: 'yangshijiu@company.com',
    },
    {
      key: '41',
      name: '黄四十',
      age: 30,
      address: '台北市信义区信义路五段 7 号台北 101',
      description: '短文本测试',
      email: 'huangsishi@company.com',
    },
    {
      key: '42',
      name: '赵四一',
      age: 34,
      address: '高雄市前金区中正四路 211 号高雄国际金融中心',
      description:
        '中等长度的描述文本，用于测试省略号在不同长度文本下的表现效果和用户体验。',
      email: 'zhaosiyi@company.com',
    },
    {
      key: '43',
      name: '周四二',
      age: 26,
      address: '台中市西区台湾大道二段 2 号台中国际金融中心',
      description:
        '这是一个超长的描述文字，用来充分测试表格的省略号功能。当文字内容远远超出列宽时，应该正确显示省略号。',
      email: 'zhousier@company.com',
    },
    {
      key: '44',
      name: '吴四三',
      age: 32,
      address: '台南市中西区中正路 1 号台南国际金融中心',
      description: '测试内容描述',
      email: 'wushisan@company.com',
    },
    {
      key: '45',
      name: '郑四四',
      age: 29,
      address: '新北市板桥区文化路一段 188 号新北国际金融中心',
      description:
        '这是一个用于测试省略号功能的中等长度描述文本，包含了中文和英文混合内容。',
      email: 'zhengshisi@company.com',
    },
    {
      key: '46',
      name: '王四五',
      age: 35,
      address: '桃园市中坜区中正路 1 号桃园国际金融中心',
      description:
        '很长的描述文字，用来测试表格省略号功能。当文本超出容器宽度时，应该显示省略号，并且支持鼠标悬停查看完整内容。',
      email: 'wangshiwu@company.com',
    },
    {
      key: '47',
      name: '李四六',
      age: 28,
      address: '新竹市东区光复路二段 101 号新竹国际金融中心',
      description: '短描述文本',
      email: 'lishiliu@company.com',
    },
    {
      key: '48',
      name: '张四七',
      age: 31,
      address: '基隆市仁爱区仁二路 1 号基隆国际金融中心',
      description:
        '中等长度的描述文本，用于测试表格的省略号功能在不同文本长度下的表现。',
      email: 'zhangshiq@company.com',
    },
    {
      key: '49',
      name: '刘四八',
      age: 33,
      address: '嘉义市东区民族路 1 号嘉义国际金融中心',
      description:
        '超长描述文字测试，用来验证表格省略号功能在处理极长文本时的表现。当文本内容远超列宽时，应该正确显示省略号。',
      email: 'liushiba@company.com',
    },
    {
      key: '50',
      name: '陈四九',
      age: 27,
      address: '彰化县彰化市中正路二段 1 号彰化国际金融中心',
      description: '测试文本',
      email: 'chenshijiu@company.com',
    },
    {
      key: '51',
      name: '杨五十',
      age: 30,
      address: '南投县南投市中兴路 1 号南投国际金融中心',
      description:
        '这是一个用于测试省略号功能的中等长度描述文本，包含了各种字符和标点符号。',
      email: 'yangshiwu@company.com',
    },
    {
      key: '52',
      name: '黄五一',
      age: 34,
      address: '云林县斗六市大学路三段 123 号云林国际金融中心',
      description:
        '很长的描述文字，用来测试表格省略号功能。当文本超出容器宽度时，应该显示省略号，并且支持鼠标悬停查看完整内容。',
      email: 'huangshiyi@company.com',
    },
    {
      key: '53',
      name: '赵五二',
      age: 26,
      address: '屏东县屏东市中正路 1 号屏东国际金融中心',
      description: '短文本测试',
      email: 'zhaoshier@company.com',
    },
    {
      key: '54',
      name: '周五三',
      age: 32,
      address: '宜兰县宜兰市中山路二段 1 号宜兰国际金融中心',
      description:
        '中等长度的描述文本，用于测试省略号在不同长度文本下的表现效果。',
      email: 'zhoushisan@company.com',
    },
    {
      key: '55',
      name: '吴五四',
      age: 29,
      address: '花莲县花莲市中正路 1 号花莲国际金融中心',
      description:
        '这是一个超长的描述文字，用来充分测试表格的省略号功能。当文字内容远远超出列宽时，应该正确显示省略号。',
      email: 'wushisi@company.com',
    },
    {
      key: '56',
      name: '郑五五',
      age: 35,
      address: '台东县台东市中山路 1 号台东国际金融中心',
      description: '测试内容',
      email: 'zhengshiwu@company.com',
    },
    {
      key: '57',
      name: '王五六',
      age: 28,
      address: '澎湖县马公市中正路 1 号澎湖国际金融中心',
      description:
        '这是一个用于测试省略号功能的中等长度描述文本，包含了中文和英文混合内容。',
      email: 'wangshiliu@company.com',
    },
    {
      key: '58',
      name: '李五七',
      age: 31,
      address: '金门县金城镇民生路 1 号金门国际金融中心',
      description:
        '很长的描述文字，用来测试表格省略号功能。当文本超出容器宽度时，应该显示省略号，并且支持鼠标悬停查看完整内容。',
      email: 'lishiq@company.com',
    },
    {
      key: '59',
      name: '张五八',
      age: 33,
      address: '连江县南竿乡介寿村 1 号连江国际金融中心',
      description: '短描述',
      email: 'zhangshiba@company.com',
    },
    {
      key: '60',
      name: '刘五九',
      age: 27,
      address: '香港中环金融街 8 号国际金融中心',
      description:
        '中等长度的描述文本，用于测试表格的省略号功能在不同文本长度下的表现。',
      email: 'liushijiu@company.com',
    },
    {
      key: '61',
      name: '陈六十',
      age: 30,
      address: '澳门新口岸友谊大马路 555 号澳门国际金融中心',
      description:
        '这是一个超长的描述文字，用来充分测试表格的省略号功能。当文字内容远远超出列宽时，应该正确显示省略号。',
      email: 'chenshiliu@company.com',
    },
    {
      key: '62',
      name: '杨六一',
      age: 34,
      address: '新加坡滨海湾金融中心 1 号新加坡国际金融中心',
      description: '测试文本内容',
      email: 'yangshiyi@company.com',
    },
    {
      key: '63',
      name: '黄六二',
      age: 26,
      address: '吉隆坡双子塔 1 号吉隆坡国际金融中心',
      description:
        '这是一个用于测试省略号功能的中等长度描述文本，包含了各种字符和标点符号。',
      email: 'huangshier@company.com',
    },
    {
      key: '64',
      name: '赵六三',
      age: 32,
      address: '曼谷是隆路 1 号曼谷国际金融中心',
      description:
        '很长的描述文字，用来测试表格省略号功能。当文本超出容器宽度时，应该显示省略号，并且支持鼠标悬停查看完整内容。',
      email: 'zhaoshisan@company.com',
    },
    {
      key: '65',
      name: '周六四',
      age: 29,
      address: '雅加达苏迪曼大街 1 号雅加达国际金融中心',
      description: '短文本测试',
      email: 'zhoushisi@company.com',
    },
    {
      key: '66',
      name: '吴六五',
      age: 35,
      address: '马尼拉马卡蒂大道 1 号马尼拉国际金融中心',
      description:
        '中等长度的描述文本，用于测试省略号在不同长度文本下的表现效果。',
      email: 'wushiwu@company.com',
    },
    {
      key: '67',
      name: '郑六六',
      age: 28,
      address: '胡志明市第一郡阮惠街 1 号胡志明市国际金融中心',
      description:
        '这是一个超长的描述文字，用来充分测试表格的省略号功能。当文字内容远远超出列宽时，应该正确显示省略号。',
      email: 'zhengshiliu@company.com',
    },
    {
      key: '68',
      name: '王六七',
      age: 31,
      address: '河内还剑郡李太祖街 1 号河内国际金融中心',
      description: '测试内容描述',
      email: 'wangshiq@company.com',
    },
    {
      key: '69',
      name: '李六八',
      age: 33,
      address: '金边中央市场 1 号金边国际金融中心',
      description:
        '这是一个用于测试省略号功能的中等长度描述文本，包含了中文和英文混合内容。',
      email: 'lishiba@company.com',
    },
    {
      key: '70',
      name: '张六九',
      age: 27,
      address: '万象塔銮大道 1 号万象国际金融中心',
      description:
        '很长的描述文字，用来测试表格省略号功能。当文本超出容器宽度时，应该显示省略号，并且支持鼠标悬停查看完整内容。',
      email: 'zhangshijiu@company.com',
    },
    {
      key: '71',
      name: '刘七十',
      age: 30,
      address: '仰光苏雷宝塔路 1 号仰光国际金融中心',
      description: '短文本',
      email: 'liushishi@company.com',
    },
    {
      key: '72',
      name: '陈七一',
      age: 34,
      address: '达卡莫蒂吉海尔大道 1 号达卡国际金融中心',
      description:
        '中等长度的描述文本，用于测试表格的省略号功能在不同文本长度下的表现。',
      email: 'chenshiyi@company.com',
    },
    {
      key: '73',
      name: '杨七二',
      age: 26,
      address: '加德满都杜巴广场 1 号加德满都国际金融中心',
      description:
        '这是一个超长的描述文字，用来充分测试表格的省略号功能。当文字内容远远超出列宽时，应该正确显示省略号。',
      email: 'yangshier@company.com',
    },
    {
      key: '74',
      name: '黄七三',
      age: 32,
      address: '科伦坡加勒菲斯绿地 1 号科伦坡国际金融中心',
      description: '测试文本内容',
      email: 'huangshisan@company.com',
    },
    {
      key: '75',
      name: '赵七四',
      age: 29,
      address: '伊斯兰堡宪法大道 1 号伊斯兰堡国际金融中心',
      description:
        '这是一个用于测试省略号功能的中等长度描述文本，包含了各种字符和标点符号。',
      email: 'zhaoshisi@company.com',
    },
    {
      key: '76',
      name: '周七五',
      age: 35,
      address: '卡拉奇沙阿拉赫费萨尔路 1 号卡拉奇国际金融中心',
      description:
        '很长的描述文字，用来测试表格省略号功能。当文本超出容器宽度时，应该显示省略号，并且支持鼠标悬停查看完整内容。',
      email: 'zhoushiwu@company.com',
    },
    {
      key: '77',
      name: '吴七六',
      age: 28,
      address: '拉合尔马洛路 1 号拉合尔国际金融中心',
      description: '短描述文本',
      email: 'wushiliu@company.com',
    },
    {
      key: '78',
      name: '郑七七',
      age: 31,
      address: '白沙瓦大学路 1 号白沙瓦国际金融中心',
      description:
        '中等长度的描述文本，用于测试省略号在不同长度文本下的表现效果。',
      email: 'zhengshiq@company.com',
    },
    {
      key: '79',
      name: '王七八',
      age: 33,
      address: '奎达萨达尔路 1 号奎达国际金融中心',
      description:
        '这是一个超长的描述文字，用来充分测试表格的省略号功能。当文字内容远远超出列宽时，应该正确显示省略号。',
      email: 'wangshiba@company.com',
    },
    {
      key: '80',
      name: '李七九',
      age: 27,
      address: '费萨拉巴德费萨拉巴德路 1 号费萨拉巴德国际金融中心',
      description: '测试文本',
      email: 'lishijiu@company.com',
    },
    {
      key: '81',
      name: '张八十',
      age: 30,
      address: '拉瓦尔品第穆里路 1 号拉瓦尔品第国际金融中心',
      description:
        '这是一个用于测试省略号功能的中等长度描述文本，包含了中文和英文混合内容。',
      email: 'zhangshiba@company.com',
    },
    {
      key: '82',
      name: '刘八一',
      age: 34,
      address: '木尔坦尼萨尔路 1 号木尔坦国际金融中心',
      description:
        '很长的描述文字，用来测试表格省略号功能。当文本超出容器宽度时，应该显示省略号，并且支持鼠标悬停查看完整内容。',
      email: 'liushiyi@company.com',
    },
    {
      key: '83',
      name: '陈八二',
      age: 26,
      address: '海得拉巴尼扎姆路 1 号海得拉巴国际金融中心',
      description: '短文本测试',
      email: 'chenshier@company.com',
    },
    {
      key: '84',
      name: '杨八三',
      age: 32,
      address: '班加罗尔 MG 路 1 号班加罗尔国际金融中心',
      description:
        '中等长度的描述文本，用于测试表格的省略号功能在不同文本长度下的表现。',
      email: 'yangshisan@company.com',
    },
    {
      key: '85',
      name: '黄八四',
      age: 29,
      address: '孟买海洋大道 1 号孟买国际金融中心',
      description:
        '这是一个超长的描述文字，用来充分测试表格的省略号功能。当文字内容远远超出列宽时，应该正确显示省略号。',
      email: 'huangshisi@company.com',
    },
    {
      key: '86',
      name: '赵八五',
      age: 35,
      address: '新德里康诺特广场 1 号新德里国际金融中心',
      description: '测试内容描述',
      email: 'zhaoshiwu@company.com',
    },
    {
      key: '87',
      name: '周八六',
      age: 28,
      address: '加尔各答公园街 1 号加尔各答国际金融中心',
      description:
        '这是一个用于测试省略号功能的中等长度描述文本，包含了各种字符和标点符号。',
      email: 'zhoushiliu@company.com',
    },
    {
      key: '88',
      name: '吴八七',
      age: 31,
      address: '钦奈安娜萨莱 1 号钦奈国际金融中心',
      description:
        '很长的描述文字，用来测试表格省略号功能。当文本超出容器宽度时，应该显示省略号，并且支持鼠标悬停查看完整内容。',
      email: 'wushiq@company.com',
    },
    {
      key: '89',
      name: '郑八八',
      age: 33,
      address: '艾哈迈达巴德 CG 路 1 号艾哈迈达巴德国际金融中心',
      description: '短描述',
      email: 'zhengshiba@company.com',
    },
    {
      key: '90',
      name: '王八九',
      age: 27,
      address: '浦那大学路 1 号浦那国际金融中心',
      description:
        '中等长度的描述文本，用于测试省略号在不同长度文本下的表现效果。',
      email: 'wangshijiu@company.com',
    },
    {
      key: '91',
      name: '李九十',
      age: 30,
      address: '苏拉特钻石市场 1 号苏拉特国际金融中心',
      description:
        '这是一个超长的描述文字，用来充分测试表格的省略号功能。当文字内容远远超出列宽时，应该正确显示省略号。',
      email: 'lishijiu@company.com',
    },
    {
      key: '92',
      name: '张九一',
      age: 34,
      address: '斋浦尔 MI 路 1 号斋浦尔国际金融中心',
      description: '测试文本内容',
      email: 'zhangshiyi@company.com',
    },
    {
      key: '93',
      name: '刘九二',
      age: 26,
      address: '勒克瑙哈兹拉特甘吉 1 号勒克瑙国际金融中心',
      description:
        '这是一个用于测试省略号功能的中等长度描述文本，包含了中文和英文混合内容。',
      email: 'liushier@company.com',
    },
    {
      key: '94',
      name: '陈九三',
      age: 32,
      address: '坎普尔纳纳拉奥公园 1 号坎普尔国际金融中心',
      description:
        '很长的描述文字，用来测试表格省略号功能。当文本超出容器宽度时，应该显示省略号，并且支持鼠标悬停查看完整内容。',
      email: 'chenshisan@company.com',
    },
    {
      key: '95',
      name: '杨九四',
      age: 29,
      address: '那格浦尔西塔布尔迪 1 号那格浦尔国际金融中心',
      description: '短文本测试',
      email: 'yangshisi@company.com',
    },
    {
      key: '96',
      name: '黄九五',
      age: 35,
      address: '印多尔拉吉瓦达 1 号印多尔国际金融中心',
      description:
        '中等长度的描述文本，用于测试表格的省略号功能在不同文本长度下的表现。',
      email: 'huangshiwu@company.com',
    },
    {
      key: '97',
      name: '赵九六',
      age: 28,
      address: '博帕尔阿伦杰姆路 1 号博帕尔国际金融中心',
      description:
        '这是一个超长的描述文字，用来充分测试表格的省略号功能。当文字内容远远超出列宽时，应该正确显示省略号。',
      email: 'zhaoshiliu@company.com',
    },
    {
      key: '98',
      name: '周九七',
      age: 31,
      address: '巴特那甘地广场 1 号巴特那国际金融中心',
      description: '测试内容描述',
      email: 'zhoushiq@company.com',
    },
    {
      key: '99',
      name: '吴九八',
      age: 33,
      address: '巴特那甘地广场 1 号巴特那国际金融中心',
      description:
        '这是一个用于测试省略号功能的中等长度描述文本，包含了各种字符和标点符号。',
      email: 'wushiba@company.com',
    },
    {
      key: '100',
      name: '郑九九',
      age: 27,
      address: '巴特那甘地广场 1 号巴特那国际金融中心',
      description:
        '很长的描述文字，用来测试表格省略号功能。当文本超出容器宽度时，应该显示省略号，并且支持鼠标悬停查看完整内容。',
      email: 'zhengshijiu@company.com',
    },
  ];

  const columns: TableProps<Person>['columns'] = [
    {
      title: '姓名',
      dataIndex: 'name',
      key: 'name',
      width: 120,
      ellipsis: params.ellipsis,
      fixed: true,
      ellipsisPopoverProps: {
        placement: params.placement,
      },
    },
    {
      title: '年龄',
      dataIndex: 'age',
      key: 'age',
      width: 80,
      ellipsis: params.ellipsis,
      ellipsisPopoverProps: {
        placement: params.placement,
      },
    },
    {
      title: '住址',
      dataIndex: 'address',
      key: 'address',
      width: params.width,
      ellipsis: params.ellipsis,
      ellipsisPopoverProps: {
        placement: params.placement,
      },
    },
    {
      title: '描述',
      dataIndex: 'description',
      key: 'description',
      width: 200,
      ellipsis: params.ellipsis,
      ellipsisPopoverProps: {
        placement: params.placement,
      },
    },
    {
      title: '邮箱',
      dataIndex: 'email',
      key: 'email',
      width: 180,
      ellipsis: params.ellipsis,
      ellipsisPopoverProps: {
        placement: params.placement,
      },
    },
    {
      title: '自定义渲染',
      dataIndex: 'custom',
      key: 'custom',
      width: 150,
      ellipsis: params.ellipsis,
      ellipsisPopoverProps: {
        placement: params.placement,
      },
      render: ({ row }) => {
        return `用户: ${row.name} (${row.age}岁)`;
      },
    },
  ];

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });
    pane.addBinding(params, 'ellipsis', { type: 'boolean' });
    pane.addBinding(params, 'width', {
      min: 100,
      max: 400,
      step: 10,
    });
    pane.addBinding(params, 'placement', {
      options: {
        top: 'top',
        right: 'right',
      },
    });
    pane.on('change', (ev) =>
      // @ts-ignore
      setParams((prev) => ({ ...prev, [ev.target.key]: ev.value })),
    );
    return () => pane.dispose();
  }, []);

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <Table<Person>
          dataSource={dataSource}
          columns={columns}
          scroll={{ x: 'fit-content', y: 300 }}
          rowSelection={{
            selectedRowKeys,
            onChange: setSelectedRowKeys,
            fixed: true,
          }}
        />
      </CodeBox>
      <CodeBlock>{`import { Table, TableProps } from "one-design-next";

type Person = {
  key: string;
  name: string;
  age: number;
  address: string;
  description: string;
  email: string;
};

const dataSource: Person[] = [
  {
    key: '1',
    name: 'Takuya',
    age: 32,
    address: '闵行区沪闵公路 1 号闵行区沪闵公路 1 号闵行区沪闵公路 1 号闵行区沪闵公路 1 号',
    description: '这是一段很长的描述文字，用来测试省略号功能。当文字超出容器宽度时，会自动显示省略号，并且鼠标悬停时会显示完整内容的 Popover。',
    email: 'huyanbin@example.com',
  },
];

const columns: TableProps<Person>['columns'] = [
  {
    title: '姓名',
    dataIndex: 'name',
    key: 'name',
    width: 120,
    ellipsis: ${params.ellipsis},
    ellipsisPopoverProps: {
      placement: '${params.placement}',
    },
  },
  {
    title: '住址',
    dataIndex: 'address',
    key: 'address',
    width: ${params.width},
    ellipsis: ${params.ellipsis},
    ellipsisPopoverProps: {
      placement: '${params.placement}',
    },
  },
  {
    title: '描述',
    dataIndex: 'description',
    key: 'description',
    width: 200,
    ellipsis: ${params.ellipsis},
    ellipsisPopoverProps: {
      placement: '${params.placement}',
    },
  },
  {
    title: '邮箱',
    dataIndex: 'email',
    key: 'email',
    width: 180,
    ellipsis: ${params.ellipsis},
    ellipsisPopoverProps: {
      placement: '${params.placement}',
    },
  },
  {
    title: '自定义渲染',
    dataIndex: 'custom',
    key: 'custom',
    width: 150,
    ellipsis: ${params.ellipsis},
    ellipsisPopoverProps: {
      placement: '${params.placement}',
    },
    render: ({ row }) => {
      return \`用户: \${row.name} (\${row.age}岁)\`;
    },
  },
];

<Table<Person>
  dataSource={dataSource}
  columns={columns}
/>`}</CodeBlock>
    </div>
  );
};

export default Ellipsis;
```
## 合并单元格 {#merge-cells}

在 `column` 或 `Table` 的 `getCellProps` 中找到需要的单元格，在其中返回 `colSpan` 或 `rowSpan` 属性，可以实现合并单元格：

**示例：colspan** — colspan

```tsx
'use client';

import { Table, type TableProps } from 'one-design-next';
import React from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

type Person = {
  key: string;
  name: string;
  age: number;
  address: string;
  email: string;
  phone: string;
  card: string;
};

const Basic = () => {
  const dataSource: Person[] = [
    {
      key: '1',
      name: 'Takuya',
      age: 32,
      address: '闵行区沪闵公路 1 号闵行区沪闵公路 1 号闵行区沪闵公路 1 号',
      email: '1234567890@qq.com',
      phone: '1234567890',
      card: '12345678901234567890',
    },
    {
      key: '2',
      name: 'Kimura',
      age: 42,
      address: '闵行区沪闵公路 1 号闵行区沪闵公路 1 号闵行区沪闵公路 1 号',
      email: '1234567890@qq.com',
      phone: '1234567890',
      card: '12345678901234567890',
    },
    {
      key: '3',
      name: 'Takuya',
      age: 32,
      address: '闵行区沪闵公路 1 号闵行区沪闵公路 1 号闵行区沪闵公路 1 号',
      email: '1234567890@qq.com',
      phone: '1234567890',
      card: '12345678901234567890',
    },
  ];

  const columns: TableProps<Person>['columns'] = [
    {
      title: '姓名',
      dataIndex: 'name',
      key: 'name',
      align: 'center',
      minWidth: 100,
    },
    {
      title: '住址',
      dataIndex: 'address',
      key: 'address',
      getCellProps: ({ rowIndex }) => {
        if (rowIndex === 1) {
          return {
            colSpan: 2,
            style: {
              background: 'var(--odn-color-blue-1)',
            },
          };
        }
      },
    },
    {
      title: '邮箱',
      dataIndex: 'email',
      key: 'email',
      minWidth: 100,
      getCellProps: ({ rowIndex }) => {
        if (rowIndex === 1) {
          return {
            colSpan: 0,
          };
        }
      },
    },
  ];

  return (
    <div>
      <CodeBox className="flex flex-col">
        <Table
          dataSource={dataSource}
          columns={columns}
          scroll={{ x: 'max-content' }}
          sticky={{
            offsetHeader: 0,
            offsetScroll: 0,
          }}
        />
      </CodeBox>
      <CodeBlock>{`import { Table } from "one-design-next";

const columns: TableProps<Person>['columns'] = [
  {
    title: '姓名',
    dataIndex: 'name',
    key: 'name',
    align: 'center',
    minWidth: 100,
  },
  {
    title: '住址',
    dataIndex: 'address',
    key: 'address',
    getCellProps: ({ rowIndex }) => {
      if (rowIndex === 1) {
        return {
          colSpan: 2,
          style: {
            background: 'var(--odn-color-blue-1)',
          },
        };
      }
    },
  },
  {
    title: '邮箱',
    dataIndex: 'email',
    key: 'email',
    minWidth: 100,
    getCellProps: ({ rowIndex }) => {
      if (rowIndex === 1) {
        return {
          colSpan: 0,
        };
      }
    },
  },
];`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 自定义单元格事件与样式 {#custom-cell-events-styles}

为 `column` 添加 `getCellProps` 和 `getHeaderCellProps` 属性，可以自定义该列的单元格属性。在其中返回 `className` 或 `style` 自定义样式，也可以传入其他更多的 `HTMLDivElement` 的属性，除了原生属性以外，还提供了双击 `onDoubleClick`、右键 `onContextMenu` 这样的事件属性。

如果是想自定义所有的单元格，则可以在 `Table` 上添加 `getCellProps` 和 `getHeaderCellProps` 属性。具体的参数差异见下方用例：

**示例：customCell** — customCell

```tsx
'use client';

import { Dropdown, Icon, Table, type TableProps } from 'one-design-next';
import React from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

type Person = {
  key: string;
  name: string;
  age: number;
  address: string;
};

const Basic = () => {
  const dataSource: Person[] = [
    {
      key: '1',
      name: 'Takuya',
      age: 32,
      address: '闵行区沪闵公路 1 号',
    },
    {
      key: '2',
      name: 'Kimura',
      age: 42,
      address: '闵行区沪闵公路 1 号',
    },
  ];

  const columns: TableProps<Person>['columns'] = [
    {
      title: '姓名',
      dataIndex: 'name',
      key: 'name',
      align: 'center',
      getCellProps: ({ row, rowIndex }) => {
        return {
          style: {
            background: 'var(--odn-color-blue-1)',
          },
        };
      },
      getHeaderCellProps: () => {
        return {
          style: {
            background: 'var(--odn-color-blue-2)',
          },
        };
      },
    },
    {
      title: '年龄',
      dataIndex: 'age',
      key: 'age',
      align: 'center',
    },
    {
      title: '住址',
      dataIndex: 'address',
      key: 'address',
    },
    {
      title: '操作',
      dataIndex: 'action',
      key: 'action',
      render: ({ row, col, rowIndex, colIndex }) => {
        return (
          <div className="flex items-center gap-4">
            <a
              href="https://wxad.design/abc"
              target="_blank"
              className="flex items-center h-[30px] text-link"
            >
              操作
            </a>
            <a
              href="https://wxad.design/abc"
              target="_blank"
              className="flex items-center h-[30px] text-link"
            >
              操作
            </a>
            <Dropdown
              menu={[
                { label: '操作', value: 'action1' },
                { label: '操作', value: 'action2' },
              ]}
            >
              <Icon
                name="more-vertical"
                color="var(--odn-color-blue-5)"
                className="cursor-pointer"
              />
            </Dropdown>
          </div>
        );
      },
    },
  ];

  return (
    <div>
      <CodeBox className="flex flex-col">
        <Table
          dataSource={dataSource}
          columns={columns}
          bordered
          getCellProps={({ row, rowIndex, col, colIndex }) => {
            if (rowIndex === 1 && colIndex === 2) {
              return {
                style: {
                  background: 'var(--odn-color-green-1)',
                },
              };
            }
          }}
          getHeaderCellProps={({ col, colIndex }) => {
            if (colIndex === 3) {
              return {
                style: {
                  background: 'var(--odn-color-blue-2)',
                },
              };
            }
          }}
        />
      </CodeBox>
      <CodeBlock>{`import { Table } from "one-design-next";

const columns: TableProps<Person>['columns'] = [
  {
    title: '姓名',
    dataIndex: 'name',
    key: 'name',
    getCellProps: ({ row, rowIndex }) => {
      return {
        style: {
          background: 'var(--odn-color-blue-1)',
        },
        onClick: () => {
          console.log('row', row, rowIndex);
        },
      };
    },
    getHeaderCellProps: () => {
      return {
        style: {
          background: 'var(--odn-color-blue-2)',
        },
      };
    },
  },
];

<Table<Person>
  getCellProps={({ row, rowIndex, col, colIndex }) => {
    if (rowIndex === 1 && colIndex === 2) {
      return {
        style: {
          background: 'var(--odn-color-green-1)',
        },
      };
    }
  }}
  getHeaderCellProps={({ col, colIndex }) => {
    if (colIndex === 3) {
      return {
        style: {
          background: 'var(--odn-color-blue-2)',
        },
      };
    }
  }}
/>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## 空状态与 loading {#empty-state-loading}

设置 `emptyText` Prop，以自定义空状态的文案；设置 `loading` Prop，以显示加载状态：

**示例：empty** — empty

```tsx
'use client';

import { Icon, Table, type TableProps } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

type Person = {
  key: string;
  name: string;
  age: number;
  address: string;
};

const Basic = () => {
  const [params, setParams] = useState({
    showEmpty: true,
    customEmpty: false,
    loading: false,
  });

  const dataSource: Person[] = params.showEmpty
    ? []
    : [
        {
          key: '1',
          name: 'Takuya',
          age: 32,
          address: '闵行区沪闵公路 1 号',
        },
        {
          key: '2',
          name: 'Kimura',
          age: 42,
          address: '闵行区沪闵公路 1 号',
        },
      ];

  const customEmptyText = (
    <div className="flex flex-col items-center justify-center py-12 text-gray-500">
      <Icon name="inbox" size={48} className="mb-4" />
      <p className="text-lg font-medium mb-2">暂无数据</p>
      <p className="text-sm">请检查筛选条件或稍后再试</p>
    </div>
  );

  const columns: TableProps<Person>['columns'] = [
    {
      title: '姓名',
      dataIndex: 'name',
      key: 'name',
      align: 'center',
    },
    {
      title: '年龄',
      dataIndex: 'age',
      key: 'age',
      align: 'center',
    },
    {
      title: '住址',
      dataIndex: 'address',
      key: 'address',
    },
    {
      title: '操作',
      dataIndex: 'action',
      key: 'action',
    },
  ];

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });
    pane.addBinding(params, 'showEmpty', {
      type: 'boolean',
      label: '空状态',
    });
    pane.addBinding(params, 'customEmpty', {
      type: 'boolean',
      label: '自定义空状态',
    });
    pane.addBinding(params, 'loading', {
      type: 'boolean',
      label: '加载',
    });
    pane.on('change', (ev) => {
      // @ts-ignore
      setParams((prev) => ({ ...prev, [ev.target.key]: ev.value }));
    });
    return () => pane.dispose();
  }, []);

  // 根据参数决定显示内容
  const getEmptyText = () => {
    if (params.customEmpty) {
      return customEmptyText;
    }
    return undefined; // 使用默认空状态
  };

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <Table
          className="w-full"
          dataSource={dataSource}
          columns={columns}
          loading={params.loading}
          emptyText={getEmptyText()}
        />
      </CodeBox>
      <CodeBlock>{`import { Table, Icon } from "one-design-next";

// 自定义空状态
const customEmptyText = (
  <div className="flex flex-col items-center justify-center py-12 text-gray-500">
    <Icon name="inbox" size={48} className="mb-4" />
    <p className="text-lg font-medium mb-2">暂无数据</p>
    <p className="text-sm">请检查筛选条件或稍后再试</p>
  </div>
);

<Table 
  dataSource={${params.showEmpty ? '[]' : 'dataSource'}}
  columns={columns}
  loading={${params.loading}}
  emptyText={${params.customEmpty ? 'customEmptyText' : 'undefined // 默认空状态'}}
/>`}</CodeBlock>
    </div>
  );
};

export default Basic;
```
## API {#api}

基于 `rc-table`，`TableProps` 在 `Omit<RcTableProps, 'columns' | 'expandable'>` 上扩展。

### Table

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| dataSource | 数据 | `T[]` | - |
| columns | 列配置 | `ColumnsType<T>` | - |
| bordered | 是否带边框 | `boolean` | `false` |
| striped | 是否斑马纹 | `boolean` | `false` |
| loading | 加载态 | `boolean` | `false` |
| rowExpansion | 行展开（封装 expandable） | `TableRowExpansion<T>` | - |
| rowSelection | 行选择 | `TableRowSelection<T>` | - |
| sortBgVisible | 排序列背景 | `boolean` | `false` |
| getCellProps | 合并单元格 props | `(params) => ...` | - |
| getHeaderCellProps | 表头单元格 props | `(params) => ...` | - |
| popoverIcon | 全局表头 Popover 图标 | `iconNames[number]` | - |

列类型 `ColumnType<T>` 在 `rc-table` 基础上增加：`sortOrder`、`onSort`、`filters`、`filteredValue`、`filterMultiple`、`onFilter`、`onFilterChange`、`popover`、`popoverProps`、`popoverIcon`、`ellipsisPopoverProps` 及结构化 `render(params)` 等（见 `components/table/index.tsx`）。

`TableRowSelection`：`type`、`selectedRowKeys`、`onChange`、`getCheckboxProps`、`getRadioProps`、`selectAll`、`width`、`align`、`selectOnRowClick`、`render` 等。

另支持 `rc-table` 其余 props（如 `scroll`、`emptyText` 等）。

## 变量 {#variables}

<VariablesTable id="Table"></VariablesTable>

---

## 文本替换 TextSwap

## 基础用例 {#basic-usage}

数字滚动 `NumberFlow` 应用于数字，而 `TextSwap` 更为通用地应用于所有文本类型：

**示例：basic** — basic

```tsx
'use client';

import { TextSwap } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';

const Demo = () => {
  const today = new Date();
  const yesterday = new Date(today.getTime() - 24 * 60 * 60 * 1000);
  const tomorrow = new Date(today.getTime() + 24 * 60 * 60 * 1000);
  const [text, setText] = useState('yesterday');
  const [date, setDate] = useState(yesterday.toLocaleDateString());
  const timerCount = useRef(0);

  useEffect(() => {
    const timer = setInterval(() => {
      if (timerCount.current % 3 === 0) {
        setText('today');
        setDate(today.toLocaleDateString());
      } else if (timerCount.current % 3 === 1) {
        setText('tomorrow');
        setDate(tomorrow.toLocaleDateString());
      } else {
        setText('yesterday');
        setDate(yesterday.toLocaleDateString());
      }
      timerCount.current++;
    }, 2000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div>
      <CodeBox className="">
        <div className="flex flex-col items-center">
          <TextSwap className="text-xl font-semibold">{date}</TextSwap>
          <TextSwap className="text-base text-neutral-400">{text}</TextSwap>
        </div>
      </CodeBox>
      <CodeBlock>{`import { TextSwap } from 'one-design-next';

const [text, setText] = useState('today');
const [date, setDate] = useState(new Date().toLocaleDateString());

<TextSwap>{text}</TextSwap>
<TextSwap>{date}</TextSwap>
`}</CodeBlock>
    </div>
  );
};

export default Demo;
```
## 隐藏与展示 {#hide-show}

`TextSwap` 可以用于隐藏与展示密码、金额等敏感信息：

**示例：password** — password

```tsx
'use client';

import { TextSwap } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Eye, EyeClosed } from 'lucide-react';
// @ts-ignore

const Demo = () => {
  const [isVisible, setIsVisible] = useState(false);
  const lastClickTime = useRef(0);
  const timerRef = useRef(0);
  const password = '123456';

  useEffect(() => {
    const timer = setInterval(() => {
      // 如果距离上次点击不到 4 秒，跳过自动切换
      if (Date.now() - lastClickTime.current > 4000) {
        setIsVisible((prev) => !prev);
        timerRef.current++;
      }
    }, 2000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div>
      <CodeBox className="">
        <div className="relative flex items-center gap-2 pl-2 pr-14 py-2 border border-neutral-300 rounded-lg font-mono">
          <div>4485</div>
          <TextSwap>{isVisible ? '1234' : 'xxxx'}</TextSwap>
          <TextSwap>{isVisible ? '5678' : 'xxxx'}</TextSwap>
          <div>7516</div>
          <div
            className="absolute right-1.5 top-1/2 -translate-y-1/2 size-7 text-neutral-500 hover:bg-neutral-100 active:bg-neutral-200 rounded-md cursor-pointer"
            onClick={() => {
              lastClickTime.current = Date.now();
              setIsVisible(!isVisible);
            }}
          >
            <Eye
              className={`absolute inset-0 m-auto size-4 transition-all duration-200 ${
                !isVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-90'
              }`}
            />
            <EyeClosed
              className={`absolute inset-0 m-auto size-4 transition-all duration-200 ${
                isVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-90'
              }`}
            />
          </div>
        </div>
      </CodeBox>
    </div>
  );
};

export default Demo;
```
## 轻量变化 {#lightweight-changes}

在表现上相比数字滚动 `NumberFlow`，`TextSwap` 更为轻量。因为文本替换只发生于前后两个字符之间，不会像数字滚动那样保持一个连续的变化。我认为 `TextSwap` 更简洁明确，你可以对比下方感受一下：

**示例：swap-decimal** — swap-decimal

```tsx
'use client';

import { TextSwap } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Demo = () => {
  const [numbers, setNumbers] = useState([
    '1',
    '2',
    '30,000',
    '1,500',
    '31,500',
    '',
    '',
  ]);
  const timerCount = useRef(0);

  useEffect(() => {
    const timer = setInterval(() => {
      if (timerCount.current % 2 === 0) {
        setNumbers(['2', '3', '36,685', '1,834', '38,519', '.00', '.25']);
      } else {
        setNumbers(['1', '2', '30,000', '1,500', '31,500', '', '']);
      }
      timerCount.current++;
    }, 3000);
    return () => clearInterval(timer);
  }, [numbers]);

  return (
    <div>
      <CodeBox
        className={`${
          numbers[0] === '1' ? 'swap-decimal-demo-1' : 'swap-decimal-demo-2'
        }`}
      >
        <div className="w-[350px] h-[285px] rounded-xl bg-white ring-1 ring-neutral-100 shadow">
          <div className="pl-6 h-[68px] flex items-center text-[18px] font-semibold border-b border-neutral-100">
            费用明细（元）
          </div>
          <div className="p-8">
            <div className="flex items-center gap-1 mb-5 text-[14px]">
              <span>已选</span>
              <TextSwap className="text-[#296BEF] text-[16px]">
                {numbers[0]}
              </TextSwap>
              <span>个达人，共</span>
              <TextSwap className="text-[#296BEF] text-[16px]">
                {numbers[1]}
              </TextSwap>
              <span>个视频</span>
            </div>
            <div className="flex items-center justify-between mb-1">
              <div className="text-[14px] text-neutral-500 flex items-center gap-0.5">
                合作价格
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                  <path
                    fillRule="evenodd"
                    clipRule="evenodd"
                    d="M7.99957 14.2218C4.56313 14.2218 1.77734 11.436 1.77734 7.99957C1.77734 4.56313 4.56313 1.77734 7.99957 1.77734C11.436 1.77734 14.2218 4.56313 14.2218 7.99957C14.2218 11.436 11.436 14.2218 7.99957 14.2218ZM7.11068 11.9996H8.44401V10.6662H7.11068V11.9996ZM8.44709 9.3329C8.44709 9.15157 8.63553 9.00934 9.33597 8.44401C9.97597 7.92757 10.6693 7.51334 10.6693 6.44401C10.6693 5.65734 10.384 5.04134 9.88798 4.64045C9.38309 4.23157 8.79998 3.99957 8.00264 3.99957C7.06131 3.99957 6.33775 4.31068 5.83731 4.83423C5.2622 5.43512 5.33598 6.07779 5.33598 6.66623H6.66931V6.41823C6.66931 6.16757 6.71909 5.7889 7.11375 5.52934C7.30398 5.40401 7.65153 5.33645 8.00353 5.3329C8.3422 5.32934 8.68353 5.38623 8.89153 5.52934C9.30931 5.81823 9.33597 6.12845 9.33597 6.44401C9.33597 6.7889 9.03731 7.12223 8.44709 7.55512C7.55286 8.21112 7.11375 8.46001 7.11375 8.88845V9.77734H8.44886C8.44886 9.56045 8.44709 9.5569 8.44709 9.3329Z"
                    fill="#495A7A"
                    fillOpacity="0.16"
                  />
                </svg>
              </div>
              <div
                className="flex items-center text-[16px]"
                style={{
                  fontFamily: 'WeChat Sans Std Medium',
                }}
              >
                ¥<TextSwap>{numbers[2]}</TextSwap>
                <TextSwap className="top-[1px] text-[12px]">
                  {numbers[5]}
                </TextSwap>
              </div>
            </div>
            <div className="flex items-center justify-between mb-1">
              <div className="text-[14px] text-neutral-500 flex items-center gap-1">
                平台服务费
                <div className="text-neutral-400">(5%)</div>
              </div>
              <div
                className="flex items-center text-[16px]"
                style={{
                  fontFamily: 'WeChat Sans Std Medium',
                }}
              >
                ¥<TextSwap>{numbers[3]}</TextSwap>
                <TextSwap className="top-[1px] text-[12px]">
                  {numbers[6]}
                </TextSwap>
              </div>
            </div>
            <div className="h-[1px] bg-neutral-100 my-5" />
            <div className="flex items-center justify-between">
              <div className="text-[14px] text-neutral-500 flex items-center gap-1">
                总价
              </div>
              <div
                className="flex items-center text-[16px] text-[#296BEF]"
                style={{
                  fontFamily: 'WeChat Sans Std Medium',
                }}
              >
                ¥<TextSwap>{numbers[4]}</TextSwap>
                <TextSwap className="top-[1px] text-[12px]">
                  {numbers[6]}
                </TextSwap>
              </div>
            </div>
          </div>
        </div>
      </CodeBox>
      <div className="flex justify-between items-center mb-6 pb-6 dotted-bottom" />
    </div>
  );
};

export default Demo;
```

**示例：flow-decimal** — flow-decimal

```tsx
'use client';

import { NumberFlow } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';

const Basic = () => {
  const [numbers, setNumbers] = useState([1, 2, 30000]);
  const timerCount = useRef(0);

  useEffect(() => {
    const timer = setInterval(() => {
      if (timerCount.current % 2 === 0) {
        setNumbers([2, 3, 36685]);
      } else {
        setNumbers([1, 2, 30000]);
      }
      timerCount.current++;
    }, 3000);
    return () => clearInterval(timer);
  }, [numbers]);

  return (
    <div>
      <CodeBox className="">
        <div className="w-[350px] h-[285px] rounded-xl bg-white ring-1 ring-neutral-100 shadow">
          <div className="pl-6 h-[68px] flex items-center text-[18px] font-semibold border-b border-neutral-100">
            费用明细（元）
          </div>
          <div className="p-8">
            <div className="flex items-center mb-5 text-[14px] text-[#296BEF]">
              <NumberFlow
                willChange
                value={numbers[0]}
                prefix="已选"
                suffix="个达人，共"
                className="number-flow-decimal-text-demo"
              />
              <NumberFlow
                willChange
                value={numbers[1]}
                suffix="个视频"
                className="number-flow-decimal-text-demo"
              />
            </div>
            <div className="flex items-center justify-between mb-1">
              <div className="text-[14px] text-neutral-500 flex items-center gap-0.5">
                合作价格
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                  <path
                    fillRule="evenodd"
                    clipRule="evenodd"
                    d="M7.99957 14.2218C4.56313 14.2218 1.77734 11.436 1.77734 7.99957C1.77734 4.56313 4.56313 1.77734 7.99957 1.77734C11.436 1.77734 14.2218 4.56313 14.2218 7.99957C14.2218 11.436 11.436 14.2218 7.99957 14.2218ZM7.11068 11.9996H8.44401V10.6662H7.11068V11.9996ZM8.44709 9.3329C8.44709 9.15157 8.63553 9.00934 9.33597 8.44401C9.97597 7.92757 10.6693 7.51334 10.6693 6.44401C10.6693 5.65734 10.384 5.04134 9.88798 4.64045C9.38309 4.23157 8.79998 3.99957 8.00264 3.99957C7.06131 3.99957 6.33775 4.31068 5.83731 4.83423C5.2622 5.43512 5.33598 6.07779 5.33598 6.66623H6.66931V6.41823C6.66931 6.16757 6.71909 5.7889 7.11375 5.52934C7.30398 5.40401 7.65153 5.33645 8.00353 5.3329C8.3422 5.32934 8.68353 5.38623 8.89153 5.52934C9.30931 5.81823 9.33597 6.12845 9.33597 6.44401C9.33597 6.7889 9.03731 7.12223 8.44709 7.55512C7.55286 8.21112 7.11375 8.46001 7.11375 8.88845V9.77734H8.44886C8.44886 9.56045 8.44709 9.5569 8.44709 9.3329Z"
                    fill="#495A7A"
                    fillOpacity="0.16"
                  />
                </svg>
              </div>
              <div
                className="text-[16px]"
                style={{
                  fontFamily: 'WeChat Sans Std Medium',
                }}
              >
                <NumberFlow
                  willChange
                  value={numbers[2]}
                  prefix="¥"
                  className="number-flow-decimal-demo"
                  format={{
                    style: 'decimal',
                    minimumFractionDigits:
                      (numbers[2] * 0.05).toString().split('.')[1]?.length || 0,
                  }}
                />
              </div>
            </div>
            <div className="flex items-center justify-between mb-1">
              <div className="text-[14px] text-neutral-500 flex items-center gap-1">
                平台服务费
                <div className="text-neutral-400">(5%)</div>
              </div>
              <div
                className="text-[16px]"
                style={{
                  fontFamily: 'WeChat Sans Std Medium',
                }}
              >
                <NumberFlow
                  willChange
                  value={numbers[2] * 0.05}
                  prefix="¥"
                  className="number-flow-decimal-demo"
                />
              </div>
            </div>
            <div className="h-[1px] bg-neutral-100 my-5" />
            <div className="flex items-center justify-between">
              <div className="text-[14px] text-neutral-500 flex items-center gap-1">
                总价
              </div>
              <div
                className="text-[16px] text-[#296BEF]"
                style={{
                  fontFamily: 'WeChat Sans Std Medium',
                }}
              >
                <NumberFlow
                  willChange
                  value={numbers[2] * 1.05}
                  prefix="¥"
                  className="number-flow-decimal-demo"
                />
              </div>
            </div>
          </div>
        </div>
        <style>
          {`
            .number-flow-decimal-text-demo::part(number) {
              font-size: 16px;
              padding: 0 4px;
            }
            .number-flow-decimal-text-demo::part(prefix),
            .number-flow-decimal-text-demo::part(suffix) {
              position: relative;
              top: -0.5px;
              font-size: 14px;
              color: #000;
            }
            .number-flow-decimal-demo::part(fraction) {
              font-size: 12px;
            }
          `}
        </style>
      </CodeBox>
    </div>
  );
};

export default Basic;
```
## 翻转效果 {#flip-effect}

使用 `TextSwap.Flip` 组件实现翻转的展示效果。可通过下方参数调整这种固定的展示效果：

**示例：flip** — flip

```tsx
'use client';

import { ArrowRight } from 'lucide-react';
import { TextSwap } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
import { Pane } from 'tweakpane';

const Demo = () => {
  const [flipped, setFlipped] = useState(false);
  const [params, setParams] = useState({
    delay: 30,
    duration: 700,
    reversed: true,
    blur: 3,
    y: 13,
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const interval = setInterval(() => {
      setFlipped((prev) => !prev);
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'delay', {
      min: 0,
      max: 100,
      step: 10,
    });

    pane.addBinding(params, 'duration', {
      min: 100,
      max: 1000,
      step: 100,
    });

    pane.addBinding(params, 'blur', {
      min: 0,
      max: 10,
      step: 1,
    });

    pane.addBinding(params, 'y', {
      min: 0,
      max: 30,
      step: 1,
    });

    pane.addBinding(params, 'reversed');

    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 px-2 pb-12 gap-12">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <div className="flex flex-col gap-2 items-center">
          <TextSwap.Flip
            className="text-xl font-semibold"
            flipped={flipped}
            originalText="轻量变化"
            swappedText="翻转效果"
            {...params}
          />
          <TextSwap.Flip
            className="text-xl font-semibold"
            flipped={flipped}
            originalText="TextSwap.Flip"
            swappedText="TextSwap.Flip"
            {...params}
          />
        </div>
      </CodeBox>
      <CodeBlock>{`import { TextSwap } from "one-design-next";

<TextSwap.Flip
  // flipped: ${flipped ? 'true' : 'false'}
  flipped={flipped}
  className="text-xl font-semibold"
  originalText="数字滚动 NumberFlow"
  swappedText="文本替换 TextSwap"
  delay={${params.delay}}
  duration={${params.duration}}
  blur={${params.blur}}
  y={${params.y}}
  reversed={${params.reversed ? 'true' : 'false'}}
/>`}</CodeBlock>
      <div className="flex justify-between items-center mb-6 pb-6 dotted-bottom" />
      <CodeBox className="flex flex-col">
        <div className="flex items-center justify-between px-3 w-[260px] h-12 border border-neutral-200 rounded-full">
          <TextSwap.Flip
            className="text-xl font-semibold"
            flipped={flipped}
            originalText="Start Deploying"
            swappedText="Start Deploying"
          />
          <div className="flex items-center justify-center size-7 rounded-full bg-black">
            <ArrowRight className="text-white size-5" />
          </div>
        </div>
      </CodeBox>
    </div>
  );
};

export default Demo;
```
## TextSwap API {#textswap-api}

继承 `Omit<React.HTMLAttributes<HTMLDivElement>, 'onDrag' | 'onDragStart' | 'onDragEnd' | 'onDragCapture' | 'onDragStartCapture' | 'onDragEndCapture' | 'onAnimationStart' | 'onAnimationStartCapture'>`。

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| children | 展示文本 | `string \| number` | - |
| direction | 滚动方向 | `'up' \| 'down'` | `'up'` |

## TextSwap.Flip API {#textswap-flip-api}

继承 `React.HTMLAttributes<HTMLDivElement>`。

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| originalText | 原始文字 | `string` | - |
| swappedText | 替换文字 | `string` | - |
| delay | 字符间延迟（ms） | `number` | `30` |
| duration | 动画时长（ms） | `number` | `700` |
| flipped | 是否处于替换态 | `boolean` | `false` |
| reversed | 是否反向 | `boolean` | `false` |
| blur | 模糊程度 | `number` | `3` |
| y | 垂直偏移 | `number` | `13` |

## 变量 {#variables}

<VariablesTable id="TextSwap"></VariablesTable>

---

## 虚拟列表 VirtualList

## 基础用例

设置 `showScrollBar` 为 `true`，滚动条始终显示；设置为 `optional`，则仅会在滚动过程中时显示滚动条。

通过 `onVirtualScroll` `onVisibleChange` 可获取更多信息。

**示例：basic** — basic

```tsx
'use client';

import { VirtualList } from 'one-design-next';
import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import CodeBlock from 'dumi/theme/builtins/CodeBlock';
// @ts-ignore
import CodeBox from 'dumi/theme/builtins/CodeBox';
import { Pane } from 'tweakpane';

const Basics = () => {
  const [params, setParams] = useState({
    showScrollBar: true as true | false | 'optional',
  });

  const tweakpaneContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const pane = new Pane({
      container: tweakpaneContainerRef.current as HTMLElement,
    });

    pane.addBinding(params, 'showScrollBar', {
      options: {
        true: true,
        false: false,
        optional: 'optional',
      },
    });
    pane.on('change', (ev) => {
      setParams((prev) => ({
        ...prev,
        // @ts-ignore
        [ev.target.key]: ev.value,
      }));
    });

    return () => {
      pane.dispose();
    };
  }, []);

  const tags = Array.from({ length: 50 }).map(
    (_, i, a) => `v1.2.0-beta.${a.length - i}`,
  );

  const data = tags.map((tag, index) => ({
    id: index,
    title: tag,
  }));

  return (
    <div>
      <CodeBox className="flex flex-col pt-2 pr-2 pb-16 gap-16">
        <div ref={tweakpaneContainerRef} className="opacity-90 self-end" />
        <VirtualList
          className="h-72 w-48 border"
          data={data}
          height={288}
          itemHeight={36}
          itemKey={(item) => item.id}
          showScrollBar={params.showScrollBar}
          key={JSON.stringify(params)}
          onVirtualScroll={(info) => {
            console.log('[yijie]', info);
          }}
        >
          {(item, index, props) => (
            <div
              style={{
                ...props.style,
                padding: '8px 16px',
                borderBottom:
                  index === data.length - 1
                    ? 'none'
                    : '1px solid var(--odn-color-black-2)',
              }}
            >
              <div className="text-sm text-neutral-500">{item.title}</div>
            </div>
          )}
        </VirtualList>
      </CodeBox>
      <CodeBlock>{`import { VirtualList } from "one-design-next";

const tags = Array.from({ length: 50 }).map(
  (_, i, a) => \`v1.2.0-beta.\${a.length - i}\`,
);

const data = tags.map((tag, index) => ({
  id: index,
  title: tag,
}));

<VirtualList
  className="h-72 w-48 border"
  data={data}
  height={288}
  itemHeight={36}
  itemKey={(item) => item.id}
  showScrollBar={${typeof params.showScrollBar === 'string' ? `'${params.showScrollBar}'` : params.showScrollBar}}
>
  {(item, index, props) => (
    <div
      style={{
        ...props.style,
        padding: '8px 16px',
        borderBottom: index === data.length - 1 ? 'none' : '1px solid var(--odn-color-black-2)',
      }}
    >
      <div className="text-sm text-neutral-500">{item.title}</div>
    </div>
  )}
</VirtualList>`}</CodeBlock>
    </div>
  );
};

export default Basics;
```
## API

继承 `Omit<React.HTMLAttributes<HTMLElement>, 'children'>`，底层为 `rc-virtual-list`。

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| data | 数据 | `T[]` | - |
| itemKey | 行 key | `React.Key \| (item: T) => React.Key` | - |
| children | 行渲染 | `(item, index, { style, offsetX }) => ReactNode` | - |
| height | 列表高度 | `number` | - |
| itemHeight | 行最小高度 | `number` | - |
| fullHeight | 非虚拟时是否仍占满高度 | `boolean` | `false` |
| component | 列表根标签 | `string \| ComponentType` | `'div'` |
| virtual | 是否启用虚拟滚动 | `boolean` | `true` |
| scrollWidth | 水平滚动内容宽度 | `number` | - |
| styles | 滚动条样式 | `{ horizontalScrollBar?, ... }` | 内置默认 |
| showScrollBar | 是否显示滚动条 | `boolean \| 'optional'` | `true` |
| onScroll | 滚动 | `React.UIEventHandler<HTMLElement>` | - |
| onVirtualScroll | 虚拟偏移 | `(info: { x, y }) => void` | - |
| onVisibleChange | 可见行变化 | `(visibleList, fullList) => void` | - |
| innerProps | 注入内部容器 | `Record<string, unknown>` | - |
| extraRender | 额外渲染（Filler） | `(info) => ReactNode` | - |

## 变量

<VariablesTable id="VirtualList"></VariablesTable>
