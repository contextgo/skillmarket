## 布局 Layout

## 如翼布局 {#ruyi-layout}

**示例：如翼布局** — 如翼系统的标准页面布局

```tsx
'use client';

import { Card, RuyiLayout, type RuyiMenuItem } from 'one-design-next';
import React, { useState } from 'react';

const MENU_ITEMS: RuyiMenuItem[] = [
  {
    key: 'recommend',
    label: '推荐人群',
    icon: 'users',
    children: [
      { key: 'industry', label: '行业优选' },
      { key: 'interest', label: '兴趣精选' },
      { key: 'theme', label: '主题甄选' },
    ],
  },
  {
    key: 'custom',
    label: '自定义人群',
    icon: 'user-edit',
    children: [
      { key: 'create', label: '新建人群' },
      { key: 'list', label: '人群列表' },
    ],
  },
];

const BasicDemo = () => {
  const [activeNav, setActiveNav] = useState('人群策略');
  const [activeMenu, setActiveMenu] = useState('industry');

  return (
    <RuyiLayout
      activeNav={activeNav}
      onNavChange={setActiveNav}
      menuItems={MENU_ITEMS}
      activeMenu={activeMenu}
      onMenuChange={setActiveMenu}
      navItems={['首页', '洞察诊断']}
      collapsible
      className="h-[600px]"
    >
      <Card className="p-6 rounded-xl" elevation={0}>
        <div className="text-lg font-semibold mb-2">内容区域</div>
        <div className="text-sm text-black-10">
          这里是页面的主要内容区域。RuyiLayout 提供了标准的顶部导航 + 侧边菜单 +
          内容区三栏布局。
        </div>
      </Card>
    </RuyiLayout>
  );
};

export default BasicDemo;
```
## RuyiLayout API {#ruyi-api}

| 属性             | 说明                   | 类型                    | 默认值                      |
| ---------------- | ---------------------- | ----------------------- | --------------------------- |
| navItems         | 顶栏导航项             | `string[]`              | `['首页', '洞察诊断', ...]` |
| activeNav        | 当前激活的导航项       | `string`                | -                           |
| onNavChange      | 导航切换回调           | `(nav: string) => void` | -                           |
| menuItems        | 侧边栏菜单项；**空数组时不渲染侧栏** | `RuyiMenuItem[]`        | `[]`                        |
| activeMenu       | 有侧栏时当前激活的菜单项 key | `string`                | `''`                        |
| onMenuChange     | 有侧栏时菜单切换回调   | `(key: string) => void` | 空函数                      |
| headerRight      | 顶栏右侧自定义内容     | `ReactNode`             | 标准按钮组                  |
| accountName      | 账号名称               | `string`                | `'品牌名 – 行业'`           |
| accountId        | 账号 ID                | `string`                | `'00000'`                   |
| collapsible      | 是否显示侧边栏收起按钮 | `boolean`               | `false`                     |
| className        | 外层容器 className     | `string`                | -                           |
| bodyClassName    | body 区域 className    | `string`                | -                           |
| contentClassName | 内容区 className       | `string`                | -                           |

### RuyiMenuItem

| 属性     | 说明     | 类型             |
| -------- | -------- | ---------------- |
| key      | 唯一标识 | `string`         |
| label    | 显示文本 | `string`         |
| icon     | 图标名称 | `string`         |
| badge    | 角标文字 | `string`         |
| children | 子菜单项 | `RuyiMenuItem[]` |

## MpLayout API {#mp-api}

| 属性             | 说明                   | 类型                                                          | 默认值     |
| ---------------- | ---------------------- | ------------------------------------------------------------- | ---------- |
| logo             | 产品 logo              | `ReactNode`                                                   | 小程序图标 |
| productName      | 产品名称               | `string`                                                      | `'小程序'` |
| navLinks         | 顶栏右侧导航链接       | `{ label: string; href?: string; onClick?: () => void }[]`    | 文档/社区/工具 |
| menuItems        | 侧边栏菜单项           | `MpMenuItem[]`                                                | -          |
| activeMenu       | 当前激活的菜单项 key   | `string`                                                      | -          |
| onMenuChange     | 菜单切换回调           | `(key: string) => void`                                       | -          |
| headerRight      | 顶栏右侧自定义操作区   | `ReactNode`                                                   | -          |
| className        | 外层容器 className     | `string`                                                      | -          |
| sidebarClassName | 侧边栏 className       | `string`                                                      | -          |
| contentClassName | 内容区 className       | `string`                                                      | -          |

### MpMenuItem

| 属性     | 说明                         | 类型                                           |
| -------- | ---------------------------- | ---------------------------------------------- |
| key      | 唯一标识                     | `string`                                       |
| label    | 显示文本                     | `string`                                       |
| icon     | 图标名称                     | `string`                                       |
| children | 子菜单项（无 children 则为独立可点击项） | `Omit<MpMenuItem, 'icon' \| 'children'>[]` |
