# 组件完整导出列表

以下是 `one-design-next` 的完整导出，来源于 `components/index.ts`。

## 默认导出组件

| 组件名            | 目录                           | Props 类型                                                                                                 | 分类     |
| ----------------- | ------------------------------ | ---------------------------------------------------------------------------------------------------------- | -------- |
| `Alert`           | `components/alert`             | `AlertProps`, `AlertRef`                                                                                   | 反馈     |
| `AutoComplete`    | `components/auto-complete`     | `AutoCompleteProps`                                                                                        | 数据录入 |
| `Avatar`          | `components/avatar`            | `AvatarProps`                                                                                              | 数据展示 |
| `Button`          | `components/button`            | `ButtonProps`                                                                                              | 通用     |
| `Calendar`        | `components/calendar`          | `CalendarProps`                                                                                            | 数据录入 |
| `Card`            | `components/card`              | `CardProps`, `CardElevation`, `CardHeaderProps`, `CardHeaderSize`                                          | 数据展示 |
| `Cascader`        | `components/cascader`          | `CascaderProps`                                                                                            | 数据录入 |
| `Chart`           | `components/chart`             | —                                                                                                          | 数据展示 |
| `Checkbox`        | `components/checkbox`          | `CheckboxProps`, `CheckboxGroupProps`                                                                      | 数据录入 |
| `Collapse`        | `components/collapse`          | `CollapseProps`, `CollapseItem`                                                                            | 数据展示 |
| `ColorPicker`     | `components/color-picker`      | `ColorPickerProps`                                                                                         | 数据录入 |
| `ConfigProvider`  | `components/config-provider`   | `ConfigProviderProps`, `ConfigConsumerProps`                                                               | 其他     |
| `DatePicker`      | `components/date-picker`       | `DatePickerProps`                                                                                          | 数据录入 |
| `DateRangePicker` | `components/date-range-picker` | `DatePickerRangeProps`                                                                                     | 数据录入 |
| `Dialog`          | `components/dialog`            | `DialogProps`                                                                                              | 反馈     |
| `Drawer`          | `components/drawer`            | `DrawerProps`                                                                                              | 反馈     |
| `Dropdown`        | `components/dropdown`          | `DropdownProps`                                                                                            | 导航     |
| `EllipsisText`    | `components/ellipsis-text`     | `EllipsisTextProps`                                                                                        | 数据展示 |
| `Empty`           | `components/empty`             | `EmptyProps`, `EmptyType`, `EmptySize`                                                                     | 数据展示 |
| `Form`            | `components/form`              | `FormProps`, `FormItemProps`                                                                               | 数据录入 |
| `HoverFill`       | `components/hover-fill`        | `HoverFillProps`, `HoverFillState`                                                                         | 通用     |
| `Icon`            | `components/icon`              | `IconProps`                                                                                                | 通用     |
| `Input`           | `components/input`             | `InputProps`, `InputRef`                                                                                   | 数据录入 |
| `InputNumber`     | `components/input-number`      | —                                                                                                          | 数据录入 |
| `InputOtp`        | `components/input-otp`         | `InputOtpProps`, `InputOtpRef`                                                                             | 数据录入 |
| `Link`            | `components/link`              | `LinkProps`                                                                                                | 通用     |
| `Loading`         | `components/loading`           | `LoadingProps`                                                                                             | 反馈     |
| `NumberFlow`      | `components/number-flow`       | `NumberFlowProps`, `Format`                                                                                | 数据展示 |
| `Pagination`      | `components/pagination`        | `PaginationProps`                                                                                          | 导航     |
| `Popover`         | `components/popover`           | —                                                                                                          | 反馈     |
| `Radio`           | `components/radio`             | `RadioProps`, `RadioGroupProps`                                                                            | 数据录入 |
| `ScrollArea`      | `components/scroll-area`       | `ScrollAreaProps`                                                                                          | 数据展示 |
| `Select`          | `components/select`            | `SelectProps`                                                                                              | 数据录入 |
| `Slider`          | `components/slider`            | `SliderProps`                                                                                              | 数据录入 |
| `Switch`          | `components/switch`            | `SwitchProps`                                                                                              | 数据录入 |
| `Table`           | `components/table`             | `TableProps`, `ColumnType`, `TableSortOrder`, `RowSelectionType`, `TableRowSelection`, `TableRowExpansion` | 数据展示 |
| `Tabs`            | `components/tabs`              | —                                                                                                          | 导航     |
| `TextSwap`        | `components/text-swap`         | `TextSwapProps`, `TextSwapFlipProps`                                                                       | 数据展示 |
| `TimePicker`      | `components/time-picker`       | `TimePickerProps`                                                                                          | 数据录入 |
| `Tooltip`         | `components/tooltip`           | —                                                                                                          | 反馈     |
| `TreeSelect`      | `components/tree-select`       | `TreeSelectProps`, `TreeNodeData`                                                                          | 数据录入 |
| `VirtualList`     | `components/virtual-list`      | `VirtualListProps`                                                                                         | 数据展示 |

## 具名导出（非默认）

| 导出名                                                                                                                                                   | 来源                    | 说明               |
| -------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------- | ------------------ |
| `Collapsible`, `CollapsibleContent`, `CollapsibleTrigger`                                                                                                | `components/collapse`   | 可折叠基础组件     |
| `iconNames`                                                                                                                                              | `components/icon`       | 所有内置图标名数组 |
| `Message`, `MessageReact16`, `MessageProps`, `MessageIntent`, `odnMessageState`                                                                          | `components/message`    | 全局消息           |
| `ModalRoot`, `ModalContent`, `ModalHeader`, `ModalTitle`, `ModalDescription`, `ModalFooter`, `ModalOverlay`, `ModalPortal`, `ModalClose`, `ModalTrigger` | `components/modal-base` | Modal 基础组件     |
| `PopoverProps`                                                                                                                                           | `components/pop-base`   | Popover Props 类型 |

## GenUI 组件

AI 对话场景专用组件，分为消息、输入、会话三组。

### GenUI · 消息

| 组件名            | 目录                            | Props 类型                                                            | 说明                                           |
| ----------------- | ------------------------------- | --------------------------------------------------------------------- | ---------------------------------------------- |
| `ActionBar`       | `components/action-bar`         | `ActionBarProps`                                                      | 消息底部操作栏：复制、重新生成、反馈、版本切换 |
| `AgentStep`       | `components/agent-step`         | `AgentStepProps`                                                      | 分步：展开折叠、状态、重试                     |
| `AgentThink`      | `components/agent-think`        | `AgentThinkProps`                                                     | 思考：展开折叠、实时计时                       |
| `CodeBlock`       | `components/code-block`         | `CodeBlockProps`                                                      | 代码高亮块：语言标签、复制                     |
| `ErrorBlock`      | `components/error-block`        | `ErrorBlockProps`                                                     | 错误提示块：消息文本、可重试                   |
| `Sources`         | `components/sources`            | `SourcesProps`                                                        | 引用源：可折叠来源列表                         |
| `StreamText`      | `components/stream-text`        | `StreamTextProps`, `TypographyOverrides`                              | 流式 Markdown 渲染：逐字动画、排版可调         |

### GenUI · 输入

| 组件名              | 目录                              | Props 类型              | 说明                                       |
| -------------------- | --------------------------------- | ----------------------- | ------------------------------------------ |
| `Attachments`        | `components/attachments`          | `AttachmentsProps`      | 附件：图片、文件类型识别、删除             |
| `Composer`           | `components/composer`             | `ComposerProps`         | 编排栏：文本输入、文件上传、联网搜索、工具调用 |
| `SkillSlot`          | `components/skill-slot`           | `SkillSlotProps`        | 技能选择器：bar/menu/card 三种 variant     |
| `Suggestions`        | `components/suggestions`          | `SuggestionsProps`      | 建议：点击即发送                           |
| `UserBubble`         | `components/user-bubble`          | `UserBubbleProps`       | 用户消息气泡：文本与附件                   |

### GenUI · 会话

| 组件名             | 目录                             | Props 类型               | 说明                                           |
| ------------------ | -------------------------------- | ------------------------ | ---------------------------------------------- |
| `ChatItem`         | `components/chat-item`           | `ChatItemProps`          | 对话项：选中、重命名、删除                     |
| `PreviewPanel`     | `components/preview-panel`       | `PreviewPanelProps`, `PreviewTab` | 右侧多标签预览面板：HTML iframe / 文本预览、Tab 切换、Drawer 标题栏规格 |
| `Welcome`          | `components/welcome`             | `WelcomeProps`           | 欢迎：标题、描述、建议列表                     |

### GenUI 共享类型

| 导出名                                                                                                     | 来源                  | 说明                       |
| ---------------------------------------------------------------------------------------------------------- | --------------------- | -------------------------- |
| `ToolCall`, `ToolStatus`, `Source`, `Attachment`, `PreviewTarget`, `PreviewTab`, `SendMeta`, `SkillItem`, `AgentEvent`, `Conversation`, `MessageSnapshot`, `ChatMessage` | `components/_genui-types` | GenUI 领域类型 |

## 工具函数导出

| 导出名   | 来源                    | 说明                                                                          |
| -------- | ----------------------- | ----------------------------------------------------------------------------- |
| 日期相关 | `components/_util/date` | `convertDateToString`, `isDayAfter`, `isSameDay`, `parseWeekStringToRange` 等 |
| 时间相关 | `components/_util/time` | `isLegalTimeString`, `isTimeAfter`, `timeToSeconds`, `secondsToTime` 等       |

## 复合组件子组件

| 组件   | 子组件                                                                          | 用法                                                  |
| ------ | ------------------------------------------------------------------------------- | ----------------------------------------------------- |
| `Form` | `Form.Item`, `Form.Description`                                                 | `<Form><Form.Item label="...">...</Form.Item></Form>` |
| `Card` | `Card.Header`                                                                   | `<Card><Card.Header title="..." /></Card>`            |
| `Tabs` | `Tabs.Default`, `Tabs.ButtonGroup`, `Tabs.Vertical`, `Tabs.Divider`, `Tabs.Tag` | `<Tabs.Default items={...} />`                        |
