# Block Demo 页面模式

Block 是 `docs-pages/block/` 下的整页 demo，展示组件在实际业务场景中的使用方式。

## 文件结构

```
docs-pages/block/
├── <slug>.md                    # Markdown 文档（Dumi 路由入口）
└── demo/
    ├── <slug>.tsx               # 页面 demo 组件
    └── _components/
        └── ruyi-layout.tsx      # 共享布局组件（如翼页面）
```

## 创建顺序

**必须先创建 `.tsx` 再创建 `.md`。** Dumi 的 watcher 在 `.md` 出现时立即解析 `<code src="...">` 引用，如果 `.tsx` 不存在会编译崩溃。

## Markdown 文件格式

```markdown
---
nav:
  title: 区块
  order: 3
group:
  title: 如翼 # 分组名
  order: 0
title: 页面标题
order: 1
prompt: '一句话描述页面的场景和功能'
skill: <slug>
---

# 页面标题

<code src="./demo/<slug>.tsx"></code>
```

### Frontmatter 字段

| 字段          | 说明                       | 示例                    |
| ------------- | -------------------------- | ----------------------- |
| `nav.title`   | 侧栏分类名                 | `"区块"`                |
| `nav.order`   | 分类排序                   | `3`                     |
| `group.title` | 组名                       | `"如翼"`                |
| `group.order` | 组排序                     | `0`                     |
| `title`       | 页面标题                   | `"账号设置"`            |
| `order`       | 组内排序                   | `1`                     |
| `prompt`      | AI 生成描述                | `"做一个如翼风格的..."` |
| `skill`       | Skill 标识（与 slug 一致） | `"home"`                |

## 如翼页面模板

如翼（Ruyi）页面使用 `RuyiLayout` 共享布局组件：

```tsx
'use client';

import { Card, Button, Table, Tabs } from 'one-design-next';
import type { ColumnType } from 'one-design-next';
import React, { useState } from 'react';
import { RuyiLayout, type RuyiMenuItem } from './_components/ruyi-layout';

const MENU_ITEMS: RuyiMenuItem[] = [
  {
    key: 'group-key',
    label: '菜单组',
    icon: 'icon-name',
    children: [
      { key: 'item-key', label: '菜单项' },
      { key: 'item-key-2', label: '菜单项 2', badge: '3' },
    ],
  },
];

const PageName = () => {
  const [activeNav, setActiveNav] = useState('人群策略');
  const [activeMenu, setActiveMenu] = useState('item-key');

  return (
    <RuyiLayout
      activeNav={activeNav}
      onNavChange={setActiveNav}
      menuItems={MENU_ITEMS}
      activeMenu={activeMenu}
      onMenuChange={setActiveMenu}
      accountName="品牌名 - 行业"
      accountId="12345"
    >
      <div className="space-y-4">
        {/* 内容区 */}
      </div>
    </RuyiLayout>
  );
};

export default PageName;
```

### RuyiLayout Props

| 属性                                         | 说明           | 类型                      | 默认值       |
| -------------------------------------------- | -------------- | ------------------------- | ------------ |
| navItems                                     | 顶栏导航项     | `string[]`                | 6 个如翼模块 |
| activeNav / onNavChange                      | 导航选中态     | `string`, `(val) => void` | —            |
| menuItems                                    | 侧边栏菜单数据 | `RuyiMenuItem[]`          | —            |
| activeMenu / onMenuChange                    | 菜单选中态     | `string`, `(val) => void` | —            |
| headerRight                                  | 自定义顶栏右侧 | `ReactNode`               | 默认图标组   |
| accountName / accountId                      | 右上角账号信息 | `string`                  | —            |
| collapsible                                  | 侧边栏可收起   | `boolean`                 | `false`      |
| className / bodyClassName / contentClassName | 自定义样式     | `string`                  | —            |

### RuyiMenuItem 类型

```tsx
interface RuyiMenuItem {
  key: string;
  label: string;
  icon?: string;
  badge?: string;
  children?: RuyiMenuItem[];
}
```

## 非如翼页面模板

```tsx
'use client';

import { Button, Card, Icon } from 'one-design-next';
import React, { useState } from 'react';
import { cn } from '../../../.dumi/theme/_util';

const PageName = () => {
  return (
    <div className="min-w-[1200px] rounded-xl bg-[#f2f5fa]">
      {/* 整页布局 */}
    </div>
  );
};

export default PageName;
```

## 编码约定

| 约定        | 规范                                |
| ----------- | ----------------------------------- |
| 组件导入    | `from 'one-design-next'`            |
| 如翼布局    | `from './_components/ruyi-layout'`  |
| 工具函数 cn | `from '../../../.dumi/theme/_util'` |
| 额外工具    | 可 `import clsx from 'clsx'`        |
| 样式方式    | Tailwind class，颜色用 ODN token    |
| 数据        | 全部 mock，不做真实请求             |
| 导出        | `export default`                    |
| 首行        | `'use client';`                     |

## 如翼页面判断依据

满足任一即为如翼：

- 有如翼 logo
- 有「顶栏导航 + 左侧菜单树 + 右侧内容区」三栏布局
- 导航项包含如翼模块名（洞察诊断、人群策略、策略应用、全域度量等）
- 用户明确说是如翼页面
