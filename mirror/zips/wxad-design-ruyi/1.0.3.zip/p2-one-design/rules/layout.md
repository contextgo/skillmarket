# 布局

One Design Next 提供两种应用级布局组件：**RuyiLayout**（如翼平台）和 **MpLayout**（小程序平台）。

## RuyiLayout

如翼平台标准布局：顶栏导航 + 侧边菜单 + 内容区。

```tsx
import { RuyiLayout } from 'one-design-next';

const menuItems = [
  {
    key: 'insight',
    label: '洞察',
    icon: 'search',
    children: [
      { key: 'overview', label: '概览' },
      { key: 'report', label: '报告' },
    ],
  },
  { key: 'setting', label: '设置', icon: 'setting' },
];

<RuyiLayout
  menuItems={menuItems}
  activeMenu="overview"
  onMenuChange={(key) => navigate(key)}
>
  <div>页面内容</div>
</RuyiLayout>;
```

### RuyiLayout Props

| 属性             | 说明                | 类型                    | 默认值                    |
| ---------------- | ------------------- | ----------------------- | ------------------------- |
| menuItems        | 侧边菜单数据        | `RuyiMenuItem[]`        | **必填**                  |
| activeMenu       | 当前选中菜单 key    | `string`                | **必填**                  |
| onMenuChange     | 菜单切换回调        | `(key: string) => void` | **必填**                  |
| children         | 内容区              | `ReactNode`             | **必填**                  |
| navItems         | 顶栏导航项          | `string[]`              | `['首页','洞察诊断',...]` |
| activeNav        | 当前导航项          | `string`                | —                         |
| onNavChange      | 导航切换回调        | `(nav: string) => void` | —                         |
| headerRight      | 顶栏右侧自定义      | `ReactNode`             | 默认按钮组                |
| accountName      | 账号名称            | `string`                | `'品牌名 – 行业'`         |
| accountId        | 账号 ID             | `string`                | `'00000'`                 |
| collapsible      | 侧边栏可收起        | `boolean`               | `false`                   |
| className        | 外层 className      | `string`                | —                         |
| bodyClassName    | body 区域 className | `string`                | —                         |
| contentClassName | 内容区 className    | `string`                | —                         |

### RuyiMenuItem 数据结构

```tsx
type RuyiMenuItem = {
  key: string;
  label: string;
  icon?: string; // Icon name
  badge?: string; // 徽标文字
  children?: RuyiMenuItem[]; // 子菜单
};
```

## MpLayout

小程序管理平台布局：顶栏 + 侧边菜单 + 内容区（支持 Tab）。

```tsx
import { MpLayout } from 'one-design-next';

<MpLayout
  menuItems={menuItems}
  activeMenu="dashboard"
  onMenuChange={(key) => navigate(key)}
  pageTitle="数据概览"
>
  <div>页面内容</div>
</MpLayout>;
```

### MpLayout Props

| 属性           | 说明             | 类型                          | 默认值          |
| -------------- | ---------------- | ----------------------------- | --------------- |
| menuItems      | 侧边菜单数据     | `MpMenuItem[]`                | **必填**        |
| activeMenu     | 当前选中菜单 key | `string`                      | **必填**        |
| onMenuChange   | 菜单切换回调     | `(key: string) => void`       | **必填**        |
| children       | 内容区           | `ReactNode`                   | **必填**        |
| logo           | Logo 自定义      | `ReactNode`                   | 内置小程序 Logo |
| pageTitle      | 页面标题         | `string`                      | —               |
| tabs           | 页面级 Tab       | `MpTabItem[]`                 | —               |
| activeTab      | 当前 Tab         | `string`                      | —               |
| onTabChange    | Tab 切换回调     | `(value: string) => void`     | —               |
| subTabs        | 子 Tab           | `MpSubTab[]`                  | —               |
| activeSubTab   | 当前子 Tab       | `string`                      | —               |
| onSubTabChange | 子 Tab 切换回调  | `(key: string) => void`       | —               |
| userName       | 用户名           | `string`                      | `'账号名称'`    |
| avatarUrl      | 头像 URL         | `string`                      | —               |
| onLogout       | 退出回调         | `() => void`                  | —               |
| headerRight    | 顶栏右侧自定义   | `ReactNode`                   | —               |
| navLinks       | 顶栏链接         | `{ label, href?, active? }[]` | —               |
| toolItems      | 工具链接         | `{ label, href? }[]`          | —               |

## 组件 Demo

- [Layout 组件 Demo](../references/demos/layout.md)
