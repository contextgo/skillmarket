# 导航

## Tabs

Tabs 提供 5 种变体，全部使用**数据驱动**模式（`items` + `value` + `onChange`），不使用 children 模式。

### 5 种变体

| 变体       | 组件               | 外观                  | 适用场景              |
| ---------- | ------------------ | --------------------- | --------------------- |
| 下划线 Tab | `Tabs.Default`     | 文字 + 底部指示条     | 页面级 Tab 切换       |
| 按钮组     | `Tabs.ButtonGroup` | 方块按钮，激活态高亮  | 视图切换（列表/网格） |
| 垂直 Tab   | `Tabs.Vertical`    | 纵向排列 + 侧边指示条 | 侧边栏导航            |
| 分隔 Tab   | `Tabs.Divider`     | 文字间有竖线分隔      | 紧凑的状态筛选        |
| 标签 Tab   | `Tabs.Tag`         | 类似标签的圆角块      | 标签筛选              |

### 基础用法

```tsx
import { Tabs } from 'one-design-next';

const items = [
  { value: 'overview', label: '概览' },
  { value: 'data', label: '数据统计' },
  { value: 'manage', label: '广告管理' },
];

// 下划线 Tab — onChange 可直接传 setState
<Tabs.Default items={items} value={activeTab} onChange={setActiveTab} />

// 按钮组
<Tabs.ButtonGroup items={items} value={activeTab} onChange={setActiveTab} />

// 垂直 Tab
<Tabs.Vertical items={items} value={activeTab} onChange={setActiveTab} />

// 分隔 Tab
<Tabs.Divider items={items} value={activeTab} onChange={setActiveTab} />

// 标签 Tab
<Tabs.Tag items={items} value={activeTab} onChange={setActiveTab} />
```

### TabItem 数据结构

```tsx
interface TabItem<T = string | number> {
  value: T;
  label: ReactNode | ((item, index, active) => ReactNode);
  disabled?: boolean;
}
```

### 通用 Props

| 属性                | 说明             | 类型                                | 默认值   |
| ------------------- | ---------------- | ----------------------------------- | -------- |
| items               | Tab 数据         | `TabItem[]`                         | `[]`     |
| value               | 当前选中值       | `string \| number`                  | —        |
| onChange            | 切换回调         | `(value, value_, e) => void`        | —        |
| gap                 | 间距             | `number`                            | 变体不同 |
| itemClassName       | 项目 className   | `string \| (item, index) => string` | —        |
| activeItemClassName | 选中项 className | `string \| (item, index) => string` | —        |

### do / don't

```tsx
// ✅ 正确 — 数据驱动，直接传 setState
<Tabs.Default
  items={[
    { value: 'a', label: '标签 A' },
    { value: 'b', label: '标签 B' },
  ]}
  value={active}
  onChange={setActive}
/>

// ❌ 错误 — children 模式（不支持）
<Tabs>
  <TabPane tab="标签 A" key="a">内容 A</TabPane>
  <TabPane tab="标签 B" key="b">内容 B</TabPane>
</Tabs>
```

```tsx
// ✅ 正确 — 直接传 setState（第一个参数就是 value）
<Tabs.ButtonGroup items={items} value={val} onChange={setVal} />

// ✅ 也正确 — 解构写法
<Tabs.ButtonGroup items={items} value={val} onChange={(val) => setVal(val)} />
```

```tsx
// ✅ 正确 — 自定义 label 渲染
const items = [
  {
    value: 'pending',
    label: (item, index, active) => (
      <span>
        待处理 <span className="text-brand-6">(12)</span>
      </span>
    ),
  },
];
```

## Pagination

```tsx
import { Pagination } from 'one-design-next';

<Pagination
  value={page}
  totalSize={100}
  onChange={(e, value, pageSize) => setPage(value)}
/>;
```

### Props

| 属性             | 说明               | 类型                              | 默认值         |
| ---------------- | ------------------ | --------------------------------- | -------------- |
| value            | 当前页码           | `number`                          | `1`            |
| totalSize        | 总条数             | `number`                          | **必填**       |
| pageSize         | 每页条数           | `number`                          | `10`           |
| onChange         | 页码变化回调       | `(e, value, pageSize) => void`    | —              |
| onPageSizeChange | 每页条数变化回调   | `(newPageSize, pageSize) => void` | —              |
| showSizeChanger  | 显示每页条数选择器 | `boolean`                         | `false`        |
| pageSizeOptions  | 每页条数选项       | `number[]`                        | `[10, 20, 50]` |
| showTotal        | 显示总条数         | `boolean`                         | `false`        |
| showQuickJumper  | 显示快速跳转       | `boolean`                         | `false`        |
| showPrevNext     | 显示上一页/下一页  | `boolean`                         | `true`         |
| showFirstLast    | 显示首页/末页      | `boolean`                         | `false`        |
| type             | 类型               | `'default' \| 'simple'`           | `'default'`    |

### do / don't

```tsx
// ✅ 正确 — value + totalSize + onChange(e, value, pageSize)
<Pagination value={page} totalSize={100} onChange={(e, val) => setPage(val)} />

// ❌ 错误 — 使用 current / total（不存在的 prop 名）
<Pagination current={page} total={100} onChange={(page) => setPage(page)} />
```

## Link

```tsx
import { Link } from 'one-design-next';

<Link href="/path">查看详情</Link>
<Link href="https://example.com" target="_blank">外部链接</Link>
```

## 组件 Demo

- [全部导航组件 Demo](../references/demos/navigation.md)
