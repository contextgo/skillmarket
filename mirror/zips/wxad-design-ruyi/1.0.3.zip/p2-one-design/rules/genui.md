# GenUI 组件规则

AI 对话场景组件的用法约束。所有组件从 `one-design-next` 导入。

## 组件分组

| 分组         | 组件                                                                                       |
| ------------ | ------------------------------------------------------------------------------------------ |
| 消息 Message | `ActionBar`, `AgentStep`, `AgentThink`, `CodeBlock`, `ErrorBlock`, `Sources`, `StreamText` |
| 输入 Input   | `Attachments`, `Composer`, `SkillSlot`, `Suggestions`, `UserBubble`                        |
| 会话 Session | `ChatItem`, `PreviewPanel`, `Welcome`                                                      |

## do / don't

### 导入

```tsx
// ✅ 正确 — 从 one-design-next 统一导入
import { StreamText, Composer, ActionBar } from 'one-design-next';

// ❌ 错误 — 从子路径导入
import StreamText from 'one-design-next/components/stream-text';
```

### 类型

```tsx
// ✅ 正确 — 类型从同一包导入
import type { ChatMessage, ToolCall, Source } from 'one-design-next';

// ❌ 错误 — 手动定义重复类型
interface MyMessage { id: string; role: string; content: string; }
```

### StreamText 排版

```tsx
// ✅ 正确 — 通过 typography prop 覆盖排版
<StreamText
  content={msg.content}
  isStreaming={msg.isStreaming}
  typography={{ bodyFontSize: 15, bodyLineHeight: 1.75 }}
/>

// ❌ 错误 — 用外部 CSS 覆盖 StreamText 内部排版
<div style={{ fontSize: 15 }}>
  <StreamText content={msg.content} />
</div>
```

### Composer

```tsx
// ✅ 正确 — onSend 处理文本和元信息
<Composer
  onSend={(text, meta) => sendMessage(text, meta)}
  isGenerating={isGenerating}
  onStop={handleStop}
/>

// ❌ 错误 — 用 Input + Button 手动拼装输入框
<Input value={text} onChange={setText} />
<Button onClick={() => send(text)}>发送</Button>
```

### ActionBar 位置

```tsx
// ✅ 正确 — ActionBar 紧跟在 StreamText 之后
<StreamText content={msg.content} />
<ActionBar content={msg.content} onRegenerate={handleRegen} />

// ❌ 错误 — ActionBar 放在消息体外部
<div className="message"><StreamText content={msg.content} /></div>
<ActionBar content={msg.content} />
```

### AgentThink + AgentStep 组合

```tsx
// ✅ 正确 — 思考过程和步骤按时间顺序排列在消息体顶部
{msg.thinking && <AgentThink content={msg.thinking} isThinking={msg.isStreaming} />}
{msg.steps?.map((step, i) =>
  step.kind === 'tool' && (
    <AgentStep key={step.tool.id} tool={step.tool} isFirst={i === 0} isLast={i === steps.length - 1} />
  )
)}
<StreamText content={msg.content} />

// ❌ 错误 — 将思考过程放在消息体下方
<StreamText content={msg.content} />
<AgentThink content={msg.thinking} />
```

### 图标

```tsx
// ✅ 正确 — GenUI 组件内部已使用 Lucide 图标集，无需手动指定
<ActionBar content={msg.content} />

// ❌ 错误 — 试图覆盖组件内部图标
<ActionBar content={msg.content} copyIcon="copy" />
```

```tsx
// ✅ 正确 — GenUI 场景与其他场景统一，直接写 name
<Icon name="sparkle" size={20} />
```

详见 [rules/icons.md](./icons.md)。

### PreviewPanel

```tsx
// ✅ 正确 — 受控模式，状态由父组件管理
const [tabs, setTabs] = useState<PreviewTab[]>([])
const [activeTabId, setActiveTabId] = useState<string | null>(null)
<PreviewPanel tabs={tabs} activeTabId={activeTabId} onTabChange={setActiveTabId} onTabClose={closeTab} onCloseAll={closeAllTabs} />

// ❌ 错误 — 用 Drawer 实现内联预览面板
<Drawer visible={showPreview} placement="right">
  <iframe srcDoc={html} />
</Drawer>
```

```tsx
// ✅ 正确 — PreviewTab 使用 text/html 类型，iframe 渲染
{ id: 'report', name: '报告.html', content: htmlString, type: 'text/html' }

// ❌ 错误 — 将 HTML 内容用 dangerouslySetInnerHTML 渲染
<div dangerouslySetInnerHTML={{ __html: htmlString }} />
```

### 错误处理

```tsx
// ✅ 正确 — 使用 ErrorBlock 展示错误
{msg.error && <ErrorBlock message={msg.error.message} retryable={msg.error.retryable} onRetry={handleRetry} />}

// ❌ 错误 — 用 Alert 替代 ErrorBlock
<Alert intent="danger" title={msg.error.message} />
```

### SkillSlot

```tsx
// ✅ 正确 — 用 SkillSlot 展示技能选择
import { SkillSlot, type SkillItem } from 'one-design-next';

<SkillSlot
  skills={skills}
  variant="bar"
  value={selectedSkill}
  onSelect={(skill) => setSelectedSkill(skill.id)}
/>

// ❌ 错误 — 手动用 Button 列表拼装技能选择
{skills.map(s => <Button key={s.id} onClick={() => select(s)}>{s.label}</Button>)}
```

SkillSlot 三种 `variant`：
- `bar`（默认）：横向标签栏，仅 icon + label，hover 显示 description tooltip
- `menu`：纵向菜单，展示 icon + label + description
- `card`：双列卡片网格，展示 icon + label + description

### Composer + SkillSlot 联动

```tsx
// ✅ 正确 — SkillSlot 放在 Composer 上方或内部，通过 skill 字段传入 SendMeta
<SkillSlot skills={skills} value={activeSkill} onSelect={(s) => setActiveSkill(s.id)} />
<Composer onSend={(text, meta) => sendMessage(text, { ...meta, skill: activeSkill })} />

// ❌ 错误 — 在 Composer 外部用独立 Select 组件做技能选择
<Select options={skills.map(s => ({ label: s.label, value: s.id }))} />
```

## 非公开组件

以下组件**不**从 `one-design-next` 导出，仅在文档站内部使用：

| 组件          | 用途               | 引用方式                      |
| ------------- | ------------------ | ----------------------------- |
| `Provenance`  | 内容来源标记       | `import { Provenance } from '../../../components/provenance'` |

## 消息体渲染顺序

一条 AI 助手消息的推荐渲染顺序：

1. `AgentThink` — 思考（可选）
2. `AgentStep` × N — 分步（可选）
3. `StreamText` — 主内容
4. `Sources` — 引用源（可选）
5. `Suggestions` — 建议（可选）
6. `ActionBar` — 操作栏

## 场景参考

详细的场景 → 组件组合映射见 [GUIDE.md](../GUIDE.md) 的「GenUI 场景 → 组件组合」章节。

## 组件 Demo

- [全部 GenUI 组件 Demo](../references/demos/genui.md)
