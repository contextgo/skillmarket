# Design Token 规范

One Design Next 的 Design Token 系统基于 CSS 自定义属性，前缀统一为 `--odn-*`，定义在 `components/style/base.css` 的 `html` 选择器上。

## 色彩体系

### 色板（每色 10 级）

| 色板 | 变量前缀 | Tailwind 前缀 | 说明 |
|------|---------|-------------|------|
| 品牌色（蓝） | `--odn-color-brand-*` | `brand-*` | 主色，与 blue 相同 |
| 透明灰阶 | `--odn-color-black-*` | `black-*` | 带透明度的灰色，用于边框、分隔线 |
| 实色灰阶 | `--odn-color-solid-black-*` | `solid-black-*` | 不透明灰色，用于文字、背景 |
| 蓝 | `--odn-color-blue-*` | `blue-*` | 与 brand 相同 |
| 绿 | `--odn-color-green-*` | `green-*` | 成功态 |
| 橙 | `--odn-color-orange-*` | `orange-*` | 警告态 |
| 红 | `--odn-color-red-*` | `red-*` | 错误/危险态 |

### 语义色

| 变量 | 值 | 用途 |
|------|---|------|
| `--odn-color-primary` | `var(--odn-color-brand-6)` 蓝 | 主操作 CTA |
| `--odn-color-primary-hover` | `var(--odn-color-brand-7)` | 主色悬停 |
| `--odn-color-primary-active` | `var(--odn-color-brand-8)` | 主色按下 |
| `--odn-color-info` / `--odn-color-link` | `#296BEF` | 信息提示/链接 |
| `--odn-color-success` | `#07C160` | 成功反馈 |
| `--odn-color-warn` | `#FA8E00` | 警示反馈 |
| `--odn-color-error` | `#E63D2E` | 错误/危险 |

### 文字色

| 变量 | 值 | 用途 |
|------|---|------|
| `--odn-color-text` | `var(--odn-color-solid-black-12)` | 主文字 |
| `--odn-color-text-placeholder` | `var(--odn-color-solid-black-9)` | 占位符 |
| `--odn-color-text-disabled` | `var(--odn-color-solid-black-8)` | 禁用文字 |

### 边框色

| 变量 | 值 | 用途 |
|------|---|------|
| `--odn-color-border` | `var(--odn-color-black-6)` | 默认边框 |
| `--odn-color-border-hover` | `var(--odn-color-black-7)` | 悬停边框 |
| `--odn-color-border-active` | `var(--odn-color-primary)` | 激活边框（蓝色） |

### 背景色

| 变量 | 值 | 用途 |
|------|---|------|
| `--odn-color-bg-elevated` | `#fff` | 弹出层背景 |
| `--odn-color-bg-container-disabled` | `var(--odn-color-solid-black-3)` | 禁用控件背景 |

## do / don't

```tsx
// ✅ 使用 Tailwind 语义色
<div className="text-black-12 bg-brand-1 border-black-6" />

// ❌ 硬编码色值
<div className="text-[#0D0D0D]" style={{ background: '#F5F8FF' }} />
```

```tsx
// ✅ 使用 CSS 变量
color: var(--odn-color-text);
border-color: var(--odn-color-border);

// ❌ 硬编码
color: rgba(13, 13, 13, 1);
border-color: rgba(73, 90, 122, 16%);
```

```tsx
// ✅ 使用 Tailwind 映射的 ODN 色名
<div className="text-brand-6 bg-green-1 border-red-6" />

// ❌ 使用 Tailwind 默认色板
<div className="text-blue-500 bg-emerald-50 border-rose-500" />
```

## 排版

| 层级 | CSS 变量 | 字号 | 行高 |
|------|---------|------|------|
| 注释 | `--odn-font-size-comment` | 12px | 20px |
| 正文迷你 | `--odn-font-size-text-mn` | 12px | 20px |
| 正文小 | `--odn-font-size-text-sm` | 13px | 22px |
| 正文中 | `--odn-font-size-text-md` | 14px | 22px |
| 正文大 | `--odn-font-size-text-lg` | 16px | 24px |
| 标题 6 | `--odn-font-size-headline-6` | 14px | 22px |
| 标题 5 | `--odn-font-size-headline-5` | 16px | 24px |
| 标题 4 | `--odn-font-size-headline-4` | 18px | 26px |
| 标题 3 | `--odn-font-size-headline-3` | 24px | 32px |
| 标题 2 | `--odn-font-size-headline-2` | 30px | 38px |
| 标题 1 | `--odn-font-size-headline-1` | 36px | 44px |

## 间距

| 变量 | 值 | 用途 |
|------|---|------|
| `--odn-padding-xxs` | 4px | 最小间距 |
| `--odn-padding-xs` | 8px | 小间距 |
| `--odn-control-padding-horizontal` | 12px | 控件水平内边距 |
| `--odn-control-height` | 36px | 标准控件高度 |

## 圆角

| 变量 | 值 |
|------|----|
| `--odn-border-radius` | 4px |
| `--odn-popup-border-radius` | 6px |

## 投影

| 变量 | 效果 | 用途 |
|------|------|------|
| `--odn-shadow-1` | 微弱 | 卡片默认 |
| `--odn-shadow-2` | 轻柔 | 悬停态/浮动卡片 |
| `--odn-shadow-3` | 中等 | 下拉面板 |
| `--odn-shadow-4` | 强烈 | 弹窗 |

## z-index 分层

| 变量 | 值 | 用途 |
|------|---|------|
| `--odn-z-index-modal` | 1040 | Modal/Dialog |
| `--odn-z-index-popup` | 1050 | Popover/Dropdown |
| `--odn-z-index-select` | 1060 | Select 下拉 |
| `--odn-z-index-message` | 1070 | Message 全局提示 |

## 动画

| keyframe | 用途 |
|----------|------|
| `odn-slide-up-in` / `odn-slide-up-out` | 向上滑入/滑出 |
| `odn-slide-down-in` / `odn-slide-down-out` | 向下滑入/滑出 |
