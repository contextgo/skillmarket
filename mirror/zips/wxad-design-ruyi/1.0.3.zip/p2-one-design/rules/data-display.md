# 数据展示

## Card

卡片用于承载一组相关联内容。

### 基础用法

```tsx
import { Card } from 'one-design-next';

<Card elevation={1}>
  <Card.Header
    title="卡片标题"
    subTitle="副标题"
    topContent={<Button light>操作</Button>}
  />
  <div style={{ padding: '0 16px 16px' }}>卡片内容</div>
</Card>;
```

### Card Props

| 属性        | 说明                      | 类型                    | 默认值  |
| ----------- | ------------------------- | ----------------------- | ------- |
| elevation   | 投影层级（0-4）           | `0 \| 1 \| 2 \| 3 \| 4` | `1`     |
| interactive | 可交互态（手型+投影变化） | `boolean`               | `false` |

### Card.Header Props

| 属性       | 说明           | 类型                                       | 默认值    |
| ---------- | -------------- | ------------------------------------------ | --------- |
| title      | 主标题         | `ReactNode`                                | —         |
| subTitle   | 副标题         | `ReactNode`                                | —         |
| topContent | 右侧操作区     | `ReactNode`                                | —         |
| size       | 排版尺寸       | `'mini' \| 'small' \| 'medium' \| 'large'` | `'small'` |
| children   | 标题区下方内容 | `ReactNode`                                | —         |

### do / don't

```tsx
// ✅ 正确 — Card + Card.Header
<Card elevation={1}>
  <Card.Header title="数据概览" topContent={<Button light>更多</Button>} />
  <div>内容</div>
</Card>

// ❌ 错误 — 不用 Card.Header 自己拼
<Card>
  <div className="flex justify-between p-4">
    <h3>数据概览</h3>
    <Button>更多</Button>
  </div>
</Card>
```

```tsx
// ✅ 正确 — elevation 控制投影
<Card elevation={0}>无阴影</Card>
<Card elevation={2}>中等阴影</Card>

// ❌ 错误 — 手写 shadow
<Card className="shadow-lg">自定义阴影</Card>
```

## Table

表格使用 `columns` + `dataSource` 数据驱动模式。

### 基础用法

```tsx
import { Table } from 'one-design-next';
import type { ColumnType } from 'one-design-next';

const columns: ColumnType[] = [
  { title: '名称', dataIndex: 'name', key: 'name' },
  { title: '金额', dataIndex: 'amount', key: 'amount', align: 'right' },
  {
    title: '操作',
    key: 'action',
    render: ({ row }) => (
      <Button light size="small">
        编辑
      </Button>
    ),
  },
];

const dataSource = [{ key: '1', name: '项目 A', amount: '¥10,000' }];

<Table columns={columns} dataSource={dataSource} />;
```

### Table Props

| 属性               | 说明             | 类型                                          | 默认值  |
| ------------------ | ---------------- | --------------------------------------------- | ------- |
| columns            | 列定义           | `ColumnsType`                                 | —       |
| dataSource         | 数据源           | `object[]`                                    | —       |
| bordered           | 显示边框         | `boolean`                                     | `false` |
| striped            | 斑马纹           | `boolean`                                     | `false` |
| loading            | 加载状态         | `boolean`                                     | `false` |
| rowSelection       | 行选择           | `TableRowSelection`                           | —       |
| rowExpansion       | 行展开           | `TableRowExpansion`                           | —       |
| sortBgVisible      | 排序列高亮背景   | `boolean`                                     | —       |
| getCellProps       | 全局单元格属性   | `({ row, rowIndex, col, colIndex }) => props` | —       |
| getHeaderCellProps | 全局表头属性     | `({ col, colIndex }) => props`                | —       |
| popoverIcon        | 全局表头提示图标 | `string`                                      | —       |
| scroll             | 固定列/滚动      | `{ x?, y? }`                                  | —       |
| sticky             | 粘性表头         | `boolean \| { offsetHeader }`                 | —       |

### ColumnType 关键属性

| 属性           | 说明           | 类型                                              |
| -------------- | -------------- | ------------------------------------------------- |
| title          | 列标题         | `ReactNode`                                       |
| dataIndex      | 数据字段       | `string`                                          |
| key            | 列 key         | `string`                                          |
| render         | 自定义渲染     | `({ row, col, rowIndex, colIndex }) => ReactNode` |
| align          | 对齐           | `'left' \| 'center' \| 'right'`                   |
| width          | 列宽           | `number \| string`                                |
| fixed          | 固定列         | `'left' \| 'right'`                               |
| ellipsis       | 文字省略       | `boolean`                                         |
| sortOrder      | 排序状态       | `'ascend' \| 'descend' \| null`                   |
| onSort         | 排序回调       | `(sortOrder) => void`                             |
| filters        | 过滤选项       | `{ text, value }[]`                               |
| filteredValue  | 过滤值         | `(string \| number)[]`                            |
| onFilterChange | 过滤回调       | `(filteredValue) => void`                         |
| popover        | 表头提示文字   | `ReactNode`                                       |
| getCellProps   | 列级单元格属性 | `({ row, rowIndex }) => props`                    |

### do / don't

```tsx
// ✅ 正确 — render 使用解构参数
render: ({ row, rowIndex }) => <span>{row.name}</span>;

// ❌ 错误 — render 使用 Ant Design 风格 (text, record, index)
render: (text, record) => <span>{record.name}</span>;
```

## Avatar

```tsx
import { Avatar } from 'one-design-next';

<Avatar src="https://example.com/avatar.jpg" />
<Avatar fallback="YZ" />
<Avatar icon="setting" shape="square" size={40} />
<Avatar badge src="/avatar.jpg" />
```

### Avatar Props

| 属性     | 说明          | 类型                   | 默认值     |
| -------- | ------------- | ---------------------- | ---------- |
| src      | 图像源        | `string`               | —          |
| fallback | 备选文本/元素 | `ReactNode`            | —          |
| icon     | 内置图标名    | `string`               | —          |
| shape    | 形状          | `'circle' \| 'square'` | `'circle'` |
| size     | 尺寸（px）    | `number`               | `32`       |
| badge    | 徽标          | `boolean \| ReactNode` | `false`    |
| disabled | 禁用          | `boolean`              | `false`    |

### Avatar.Group

```tsx
<Avatar.Group gap={-8} size={32} tooltips={['用户A', '用户B']}>
  <Avatar src="/a.jpg" />
  <Avatar src="/b.jpg" />
</Avatar.Group>
```

| 属性     | 说明             | 类型       | 默认值 |
| -------- | ---------------- | ---------- | ------ |
| size     | 统一尺寸         | `number`   | `32`   |
| gap      | 间距（负数重叠） | `number`   | `-8`   |
| tooltips | 悬停提示         | `string[]` | —      |

## Empty

空状态占位：

```tsx
import { Empty } from 'one-design-next';

<Empty type="search" size="medium" />
<Empty type="data" title="暂无数据" description="请先创建数据" />
<Empty type="crowd" title="暂无人群" extra={<Button intent="primary">新建人群</Button>} />
```

### Empty Props

| 属性        | 说明                       | 类型                                                                                  | 默认值     |
| ----------- | -------------------------- | ------------------------------------------------------------------------------------- | ---------- |
| type        | 空状态类型                 | `'search' \| 'data' \| 'crowd' \| 'address' \| 'message' \| 'image' \| 'image-error'` | `'search'` |
| size        | 尺寸                       | `'large' \| 'medium' \| 'small'`                                                      | `'medium'` |
| title       | 标题文字                   | `ReactNode`                                                                           | —          |
| description | 描述文字                   | `ReactNode`                                                                           | —          |
| extra       | 操作区（如按钮）           | `ReactNode`                                                                           | —          |
| image       | 自定义图示（替代内置 SVG） | `ReactNode`                                                                           | —          |

### do / don't

```tsx
// ✅ 正确 — type 为具体场景名
<Empty type="search" />
<Empty type="data" title="暂无数据" />

// ❌ 错误 — type="default"（不存在）
<Empty type="default" />
```

## Loading

Loading 是**纯展示**组件（不包裹子内容），用于显示加载指示器：

```tsx
import { Loading } from 'one-design-next';

<Loading />
<Loading type="ring" size="large" tip="加载中..." />
<Loading type="linear" />
```

### Loading Props

| 属性        | 说明         | 类型                             | 默认值     |
| ----------- | ------------ | -------------------------------- | ---------- |
| type        | 类型         | `'ring' \| 'linear'`             | `'ring'`   |
| theme       | 主题         | `'light' \| 'dark'`              | `'light'`  |
| size        | 尺寸         | `'small' \| 'medium' \| 'large'` | `'medium'` |
| tip         | 提示文字     | `ReactNode`                      | —          |
| tipPosition | 提示文字位置 | `'bottom' \| 'right'`            | `'bottom'` |

### do / don't

```tsx
// ✅ 正确 — 纯展示，不包裹内容
<Loading type="ring" tip="加载中..." />

// ❌ 错误 — 包裹子内容（Loading 不支持 loading prop）
<Loading loading={isLoading}><div>内容</div></Loading>
```

## Collapse / Collapsible

```tsx
import { Collapse, Collapsible, CollapsibleContent, CollapsibleTrigger } from 'one-design-next';

// Collapse 面板
<Collapse items={[{ key: '1', label: '面板标题', children: <div>内容</div> }]} />

// 手风琴模式（同时只展开一个）
<Collapse accordion items={items} />

// 受控模式
<Collapse activeKey={activeKeys} onChange={setActiveKeys} items={items} />

// Collapsible 基础
<Collapsible>
  <CollapsibleTrigger>展开</CollapsibleTrigger>
  <CollapsibleContent>隐藏内容</CollapsibleContent>
</Collapsible>
```

### Collapse Props

| 属性             | 说明             | 类型                                    | 默认值  |
| ---------------- | ---------------- | --------------------------------------- | ------- |
| items            | 面板项           | `{ key, label, children, disabled? }[]` | —       |
| defaultActiveKey | 默认展开         | `string \| string[]`                    | `[]`    |
| activeKey        | 展开面板（受控） | `string \| string[]`                    | —       |
| onChange         | 展开变化回调     | `(activeKeys: string[]) => void`        | —       |
| accordion        | 手风琴模式       | `boolean`                               | `false` |

## EllipsisText

文字超出省略：

```tsx
import { EllipsisText } from 'one-design-next';

<EllipsisText lines={2}>很长很长的文字...</EllipsisText>;
```

## NumberFlow

数字动画组件：

```tsx
import { NumberFlow } from 'one-design-next';

<NumberFlow value={12345} format={{ notation: 'compact' }} />;
```

## ScrollArea

自定义滚动区域：

```tsx
import { ScrollArea } from 'one-design-next';

<ScrollArea className="h-[300px]">长内容...</ScrollArea>;
```

## Calendar

日历组件，基于 react-day-picker 封装：

```tsx
import { Calendar } from 'one-design-next';

// 单选
<Calendar mode="single" selected={date} onSelect={setDate} />

// 范围选择
<Calendar mode="range" selected={range} onSelect={setRange} />
```

### Calendar Props

继承 react-day-picker 的 `DayPicker` 全量 Props，额外扩展：

| 属性         | 说明           | 类型                      | 默认值   |
| ------------ | -------------- | ------------------------- | -------- |
| lang         | 语言           | `'zhCN' \| 'enUS'`        | `'zhCN'` |
| minDate      | 最小可选日期   | `Date`                    | —        |
| maxDate      | 最大可选日期   | `Date`                    | —        |
| disabledDays | 自定义禁用日期 | `(date: Date) => boolean` | —        |

## TextSwap

文字切换动画组件：

```tsx
import { TextSwap } from 'one-design-next';

// 基础 — 文字变化时逐字过渡动画
<TextSwap>{count}</TextSwap>
<TextSwap direction="down">{text}</TextSwap>
```

### TextSwap Props

| 属性      | 说明     | 类型               | 默认值   |
| --------- | -------- | ------------------ | -------- |
| children  | 文字内容 | `string \| number` | **必填** |
| direction | 动画方向 | `'up' \| 'down'`   | `'up'`   |

### TextSwap.Flip

3D 翻转动画子组件：

```tsx
<TextSwap.Flip
  originalText="原始文字"
  swappedText="翻转后文字"
  flipped={isFlipped}
  duration={700}
/>
```

| 属性         | 说明          | 类型      | 默认值  |
| ------------ | ------------- | --------- | ------- |
| originalText | 原始文字      | `string`  | —       |
| swappedText  | 翻转后文字    | `string`  | —       |
| flipped      | 是否翻转      | `boolean` | `false` |
| delay        | 逐字延迟 (ms) | `number`  | `30`    |
| duration     | 动画时长 (ms) | `number`  | `700`   |

## VirtualList

虚拟滚动列表，基于 rc-virtual-list 封装：

```tsx
import { VirtualList } from 'one-design-next';

<VirtualList data={items} itemKey="id" height={400} itemHeight={48}>
  {(item, index) => <div key={item.id}>{item.name}</div>}
</VirtualList>;
```

### VirtualList Props

| 属性          | 说明             | 类型                                    | 默认值   |
| ------------- | ---------------- | --------------------------------------- | -------- |
| data          | 数据数组         | `T[]`                                   | **必填** |
| children      | 渲染函数         | `(item, index, { style }) => ReactNode` | **必填** |
| itemKey       | 每项唯一 key     | `Key \| (item) => Key`                  | **必填** |
| height        | 容器高度         | `number`                                | —        |
| itemHeight    | 每项高度         | `number`                                | —        |
| virtual       | 是否启用虚拟滚动 | `boolean`                               | `true`   |
| fullHeight    | 占满剩余高度     | `boolean`                               | `false`  |
| showScrollBar | 显示滚动条       | `boolean \| 'optional'`                 | `true`   |

## Chart

所有图表**必须使用 ECharts** 实现。禁止使用 recharts、visx、nivo、Chart.js 等其他图表库。

```tsx
import * as echarts from 'echarts';
import { useEffect, useRef } from 'react';

const ChartDemo = () => {
  const chartRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const chart = echarts.init(chartRef.current!);
    chart.setOption({
      // ECharts 配置
    });
    return () => chart.dispose();
  }, []);

  return <div ref={chartRef} style={{ width: '100%', height: 400 }} />;
};
```

图表颜色必须使用 ODN Token（通过 CSS 变量取值），不用 ECharts 默认色板：

- 主指标线：`var(--odn-color-brand-6)`
- 辅助线/面积：`var(--odn-color-brand-2)`
- 多系列依次使用 `brand-6` → `green-6` → `orange-6` → `blue-6`

轻量的装饰性图表（如 sparkline、进度条段）可用内联 SVG，无需引入 ECharts。

## 组件 Demo

- [全部数据展示组件 Demo](../references/demos/data-display.md)
