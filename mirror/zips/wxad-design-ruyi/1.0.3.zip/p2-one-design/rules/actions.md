# 操作与触发

## Button

按钮用于触发一个新任务、新流程等的即时行动。

### 基础用法

```tsx
import { Button } from 'one-design-next';

<Button>默认按钮</Button>
<Button intent="primary">主要按钮</Button>
<Button intent="danger">危险按钮</Button>
```

### Props

| 属性      | 说明                         | 类型                                | 默认值     |
| --------- | ---------------------------- | ----------------------------------- | ---------- |
| intent    | 语义样式                     | `'normal' \| 'danger' \| 'primary'` | `'normal'` |
| size      | 尺寸                         | `'small' \| 'medium' \| 'large'`    | `'medium'` |
| light     | 轻量风格（HoverFill）        | `boolean`                           | `false`    |
| loading   | 加载中                       | `boolean`                           | `false`    |
| disabled  | 禁用                         | `boolean`                           | `false`    |
| icon      | 左侧图标 name                | `string`                            | —          |
| rightIcon | 右侧图标 name                | `string`                            | —          |
| asChild   | 子元素作根节点（Radix Slot） | `boolean`                           | `false`    |

### 变体说明

- **`intent="normal"`**：灰色背景，默认操作
- **`intent="primary"`**：品牌蓝背景，主要操作（每个视图最多 1 个 primary）
- **`intent="danger"`**：红色背景，危险/删除操作

### 轻量风格 (light)

`light` 按钮使用 `HoverFill` 组件包裹，同组（同一父元素下的多个 light Button）共享悬停背景：

```tsx
// ✅ 正确 — light 按钮组
<div>
  <Button light icon="edit">
    编辑
  </Button>
  <Button light icon="cancel" intent="danger">
    删除
  </Button>
</div>
```

### 图标按钮

```tsx
// ✅ 正确 — 通过 icon prop 传入图标 name
<Button icon="plus">新建</Button>
<Button icon="search" rightIcon="down">搜索</Button>

// ❌ 错误 — 图标作为 children
<Button><Icon name="plus" /> 新建</Button>
```

### 加载态

```tsx
// ✅ 正确 — loading prop
<Button loading>提交中...</Button>

// ❌ 错误 — 手动组合
<Button disabled><Icon name="loading" spin /> 提交中...</Button>
```

### 尺寸

| size     | 适用场景               |
| -------- | ---------------------- |
| `small`  | 表格行内操作、紧凑区域 |
| `medium` | 默认，大多数场景       |
| `large`  | 表单提交、沉浸式流程   |

## do / don't

```tsx
// ✅ 正确 — intent 控制语义
<Button intent="primary">确认</Button>
<Button intent="danger">删除</Button>

// ❌ 错误 — 使用 variant（这不是 shadcn）
<Button variant="destructive">删除</Button>
```

```tsx
// ✅ 正确 — 同尺寸按钮组
<div className="flex gap-2">
  <Button>取消</Button>
  <Button intent="primary">确认</Button>
</div>

// ❌ 错误 — 混合尺寸
<div>
  <Button size="small">取消</Button>
  <Button size="large" intent="primary">确认</Button>
</div>
```

## HoverFill

`HoverFill` 是一个特殊的交互组件，同组元素共享悬停背景效果。Button 的 `light` 模式内部使用了它。

```tsx
import { HoverFill } from 'one-design-next';

<HoverFill>
  <span>操作 A</span>
</HoverFill>;
```

## Dropdown

下拉菜单用于收纳多个操作（详见 [overlays.md](./overlays.md#dropdown)）：

```tsx
import { Dropdown } from 'one-design-next';

<Dropdown
  menu={[
    { label: '编辑', value: 'edit' },
    { type: 'separator' },
    { label: '删除', value: 'delete', danger: true },
  ]}
>
  <Button icon="more" light />
</Dropdown>;
```

菜单项使用 `value`（非 `key`），分隔线类型为 `'separator'`（非 `'divider'`）。

## 组件 Demo

- [全部操作组件 Demo](../references/demos/actions.md)
