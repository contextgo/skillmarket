# 图标

## 核心设计：扁平命名空间

`Icon` 组件内置图标来自 OD 与 Lucide 两套风格，当前直接维护在 `components/icon/svg-data.tsx` 扁平表中。**调用方只写 `name`，不区分来源**，也没有 `source` prop。

| 来源 | 存储位置 | 风格特征 |
| --- | --- | --- |
| OD | `components/icon/svg-data.tsx`（扁平 key） | 混合 filled / outlined，主流 16×16 画布 |
| Lucide | `components/icon/svg-data.tsx`（扁平 key） | 24×24 描边（stroke-width=2） |

> OD 与 Lucide 在同一扁平命名空间中**不允许同名**。若同一组件/页面内需要同时用到两种视觉风格，请评估设计一致性。

## 基础用法

```tsx
import { Icon } from 'one-design-next';

<Icon name="plus" />
<Icon name="cancel" size={24} />
<Icon name="loading" spin />
<Icon name="sparkle" size={24} />
<Icon name="paperclip" size={16} />
```

## Props

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| name | 图标名称 | `IconName \| string` | — |
| size | 尺寸（px） | `number` | `16` |
| spin | 旋转动画 | `boolean` | `false` |

继承 `Omit<React.SVGProps<SVGSVGElement>, 'name'>`。

> 渲染时**不做风格改写**：根 `<svg>` 不强加 `fill` / `stroke` / `strokeWidth`，完全遵循源 svg 自带属性。OD 多为填充、Lucide 为描边，相同 `size` 下视觉重量会天然不同——这是两套源的设计差异，不是 bug。

## do / don't

```tsx
// ✅ 正确 — 使用内置 Icon
import { Icon } from 'one-design-next';
<Icon name="search" />;

// ❌ 错误 — 直接用 lucide-react
import { SearchIcon } from 'lucide-react';
<SearchIcon />;
```

```tsx
// ✅ 正确 — size prop 控制尺寸
<Icon name="plus" size={20} />

// ❌ 错误 — 用 className 控制尺寸
<Icon name="plus" className="w-5 h-5" />
```

```tsx
// ✅ 正确 — 颜色通过 CSS color 继承
<span className="text-brand-6"><Icon name="info-circle-filled" /></span>

// ❌ 错误 — 给 Icon 设置 fill
<Icon name="info-circle-filled" fill="#296BEF" />
```

## 查图标

**不要凭记忆写图标名**。所有可用图标以代码为准：

- 文档站 `Icon` 页（`components/icon/index.md`）展示全部图标。
- 程序化读取：`iconNames`。

```tsx
import { iconNames, type IconName } from 'one-design-next';
// iconNames: IconName[]
```

## ConfigProvider 自定义图标

通过 `ConfigProvider` 的 `icons` 属性可以注入业务侧自定义图标（`path d` 数组格式，viewBox 固定 `0 0 16 16`）：

```tsx
<ConfigProvider icons={{ 'custom-icon': ['M10 10...'] }}>
  <Icon name="custom-icon" />
</ConfigProvider>
```

## 组件 Demo

- [Icon 组件 Demo](../references/demos/icons.md)
