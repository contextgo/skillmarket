# 浮层与弹窗

## 浮层类型选择

| 类型   | 组件       | 触发方式     | 适用场景             |
| ------ | ---------- | ------------ | -------------------- |
| 对话框 | `Dialog`   | 用户操作触发 | 确认、表单、重要信息 |
| 抽屉   | `Drawer`   | 用户操作触发 | 侧栏详情、表单       |
| 气泡   | `Popover`  | 点击触发     | 轻量操作、预览       |
| 提示   | `Tooltip`  | 悬停触发     | 文字解释             |
| 下拉   | `Dropdown` | 点击触发     | 操作菜单             |
| 消息   | `Message`  | 程序触发     | 操作反馈             |
| 警告   | `Alert`    | 始终可见     | 页面级提示           |

## Dialog

### 基础用法

```tsx
import { Dialog } from 'one-design-next';

<Dialog
  visible={visible}
  onVisibleChange={setVisible}
  title="确认删除"
  desc="删除后无法恢复"
  onCancel={() => setVisible(false)}
  onConfirm={handleDelete}
/>;
```

### Intent 模式

```tsx
<Dialog
  visible={visible}
  onVisibleChange={setVisible}
  intent="warning"
  contentTitle="确认操作"
  contentDesc="此操作不可撤销"
  onConfirm={handleConfirm}
/>
```

intent 会自动设置对应图标：

- `info` → `info-circle-filled`
- `success` → `check-circle-filled`
- `warning` → `alert-circle-filled`
- `danger` → `cancel-circle-filled`

### Props

| 属性            | 说明                    | 类型                                           | 默认值   |
| --------------- | ----------------------- | ---------------------------------------------- | -------- |
| visible         | 是否显示                | `boolean`                                      | `false`  |
| onVisibleChange | 显示状态回调            | `(visible) => void`                            | —        |
| title           | 标题                    | `ReactNode`                                    | —        |
| desc            | 描述                    | `ReactNode`                                    | —        |
| intent          | 语义类型                | `'info' \| 'success' \| 'warning' \| 'danger'` | —        |
| contentTitle    | intent 模式标题         | `ReactNode`                                    | —        |
| contentDesc     | intent 模式描述         | `ReactNode`                                    | —        |
| onCancel        | 取消回调                | `() => void`                                   | —        |
| onConfirm       | 确认回调                | `() => void`                                   | —        |
| cancelText      | 取消按钮文字，null 隐藏 | `string \| null`                               | `'取消'` |
| confirmText     | 确认按钮文字，null 隐藏 | `string \| null`                               | `'确认'` |
| bordered        | 显示分割线              | `boolean`                                      | `false`  |
| align           | 对齐方式                | `'center'`                                     | —        |
| closable        | 显示关闭按钮            | `boolean`                                      | `true`   |
| originAware     | 从点击位置变换          | `boolean`                                      | `true`   |
| autoScale       | 自动缩放                | `boolean`                                      | `true`   |
| maskClosable    | 点击遮罩关闭            | `boolean`                                      | `true`   |

### do / don't

```tsx
// ✅ 正确 — 受控模式
<Dialog
  visible={visible}
  onVisibleChange={setVisible}
  title="标题"
  onCancel={() => setVisible(false)}
  onConfirm={handleConfirm}
>
  表单内容
</Dialog>

// ❌ 错误 — 非受控/没有 title
<Dialog open={open} onClose={onClose}>
  <DialogHeader>标题</DialogHeader>
  <DialogBody>内容</DialogBody>
</Dialog>
```

## Drawer

```tsx
import { Drawer } from 'one-design-next';

<Drawer visible={visible} onVisibleChange={setVisible} title="详情" closable>
  抽屉内容
</Drawer>;
```

### Drawer Props

| 属性               | 说明         | 类型                                     | 默认值      |
| ------------------ | ------------ | ---------------------------------------- | ----------- |
| visible            | 是否显示     | `boolean`                                | —           |
| onVisibleChange    | 显示状态回调 | `(visible) => void`                      | —           |
| title              | 标题         | `ReactNode`                              | —           |
| desc               | 描述         | `ReactNode`                              | —           |
| placement          | 弹出方向     | `'top' \| 'left' \| 'right' \| 'bottom'` | `'right'`   |
| closable           | 显示关闭按钮 | `boolean`                                | **`false`** |
| closePlacement     | 关闭按钮位置 | `'start' \| 'end'`                       | `'start'`   |
| padding            | 内边距       | `number`                                 | `0`         |
| elevated           | 层级提升     | `boolean`                                | `false`     |
| maskVisible        | 显示遮罩     | `boolean`                                | `true`      |
| maskClosable       | 点击遮罩关闭 | `boolean`                                | `true`      |
| steps              | 步骤内容数组 | `ReactNode[]`                            | —           |
| step               | 当前步骤索引 | `number`                                 | —           |
| stepTransitionType | 步骤过渡动画 | `'slide' \| 'fade'`                      | `'slide'`   |
| container          | 挂载容器     | `HTMLElement`                            | —           |
| zIndex             | 层级         | `number \| string`                       | —           |

### do / don't

```tsx
// ✅ 正确 — closable 默认 false，需要显式开启
<Drawer visible={visible} onVisibleChange={setVisible} title="详情" closable>
  内容
</Drawer>

// ❌ 错误 — 忘记设置 closable，用户无法关闭（除非点遮罩）
<Drawer visible={visible} onVisibleChange={setVisible} title="详情">
  内容
</Drawer>
```

## Popover

点击触发的气泡卡片：

```tsx
import { Popover } from 'one-design-next';

<Popover popup={<div>气泡内容</div>} placement="bottom">
  <Button>点击查看</Button>
</Popover>;
```

### Popover / Tooltip 通用 Props

Popover 和 Tooltip 共享同一套底层 Props（基于 Floating UI）：

| 属性                 | 说明               | 类型                                                                          | 默认值                                |
| -------------------- | ------------------ | ----------------------------------------------------------------------------- | ------------------------------------- |
| popup                | 弹窗内容           | `ReactNode`                                                                   | **必填**                              |
| placement            | 弹出位置           | `'top' \| 'bottom' \| 'left' \| 'right' \| 'topLeft' \| 'bottomRight' \| ...` | `'top'`                               |
| trigger              | 触发方式           | `'hover' \| 'click' \| 'focus'`                                               | Popover `'click'` / Tooltip `'hover'` |
| visible              | 是否显示（受控）   | `boolean`                                                                     | —                                     |
| onVisibleChange      | 显示变化           | `(visible, e?, reason?) => void`                                              | —                                     |
| offset               | 偏移量             | `number \| { mainAxis, crossAxis }`                                           | —                                     |
| arrowed              | 显示箭头           | `boolean`                                                                     | `true`                                |
| arrowOffset          | 箭头偏移           | `{ x?, y? }`                                                                  | `{ x: 0, y: 0 }`                      |
| matchWidth           | 与触发元素等宽     | `boolean`                                                                     | `false`                               |
| destroyOnHidden      | 关闭后销毁 DOM     | `boolean`                                                                     | `true`                                |
| hideOnAncestorScroll | 祖先滚动时隐藏     | `boolean`                                                                     | —                                     |
| mouseEnterDelay      | 鼠标进入延迟（秒） | `number`                                                                      | `0`                                   |
| mouseLeaveDelay      | 鼠标离开延迟（秒） | `number`                                                                      | `0`                                   |
| flip                 | 是否翻转           | `boolean`                                                                     | `true`                                |
| shift                | 是否偏移           | `boolean`                                                                     | `true`                                |
| portal               | 使用 Portal 渲染   | `boolean`                                                                     | `true`                                |
| popupClassName       | 弹窗 className     | `string`                                                                      | —                                     |
| popupStyle           | 弹窗 style         | `CSSProperties`                                                               | —                                     |
| zIndex               | 层级               | `number \| string`                                                            | —                                     |

## Tooltip

悬停触发的文字提示：

```tsx
import { Tooltip } from 'one-design-next';

<Tooltip popup="这是提示文字" placement="top">
  <span>悬停查看</span>
</Tooltip>;
```

## Dropdown

下拉菜单：

```tsx
import { Dropdown } from 'one-design-next';

<Dropdown
  menu={[
    { label: '编辑', value: 'edit' },
    { label: '复制', value: 'copy' },
    { type: 'separator' },
    { label: '删除', value: 'delete', danger: true },
  ]}
>
  <Button icon="more" light />
</Dropdown>;
```

### Dropdown Props

| 属性            | 说明                        | 类型                                                        | 默认值    |
| --------------- | --------------------------- | ----------------------------------------------------------- | --------- |
| menu            | 菜单数据                    | `DropdownMenuItemData[]`                                    | —         |
| children        | 触发元素                    | `ReactNode`                                                 | —         |
| placement       | 弹出位置                    | `'bottom' \| 'top' \| 'bottomLeft' \| 'bottomRight' \| ...` | —         |
| trigger         | 触发方式                    | `'click' \| 'hover' \| 'contextMenu'`                       | `'click'` |
| visible         | 是否展开（受控）            | `boolean`                                                   | —         |
| onVisibleChange | 展开变化                    | `(visible) => void`                                         | —         |
| selectable      | 可选择模式                  | `boolean`                                                   | `false`   |
| multiple        | 多选模式（需 `selectable`） | `boolean`                                                   | `false`   |
| value           | 选中值                      | `string \| string[]`                                        | —         |
| onSelect        | 选中回调                    | `(value) => void`                                           | —         |
| allowSelectAll  | 显示全选按钮（多选）        | `boolean`                                                   | `false`   |
| matchWidth      | 下拉与触发元素等宽          | `boolean`                                                   | `false`   |
| disabled        | 禁用                        | `boolean`                                                   | `false`   |

### 菜单项类型 (DropdownMenuItemData)

| type             | 说明       | 关键字段                                                                    |
| ---------------- | ---------- | --------------------------------------------------------------------------- |
| `'item'`（默认） | 普通菜单项 | `label`, `value`, `icon?`, `shortcut?`, `danger?`, `disabled?`, `children?` |
| `'label'`        | 分组标题   | `label`                                                                     |
| `'separator'`    | 分隔线     | —                                                                           |
| `'group'`        | 分组容器   | `children`                                                                  |

### do / don't

```tsx
// ✅ 正确 — 使用 value + type: 'separator'
<Dropdown menu={[
  { label: '编辑', value: 'edit' },
  { type: 'separator' },
  { label: '删除', value: 'delete', danger: true },
]}>

// ❌ 错误 — 使用 key + type: 'divider'（不存在）
<Dropdown menu={[
  { label: '编辑', key: 'edit' },
  { type: 'divider' },
]}>
```

## Message

全局消息反馈（命令式调用）：

```tsx
import { Message } from 'one-design-next';

Message.info('提示信息');
Message.success('操作成功');
Message.warning('警告信息');
Message.error('操作失败');
```

## Alert

页面内的警告提示：

```tsx
import { Alert } from 'one-design-next';

<Alert intent="info" title="提示" message="这是一条信息提示" />
<Alert intent="warning" title="警告" />
<Alert intent="danger" title="错误" message="操作失败，请重试" />
<Alert intent="success" title="成功" />
```

### Alert Props

| 属性            | 说明               | 类型                                           | 默认值     |
| --------------- | ------------------ | ---------------------------------------------- | ---------- |
| intent          | 语义类型           | `'info' \| 'success' \| 'warning' \| 'danger'` | `'info'`   |
| size            | 尺寸               | `'small' \| 'medium' \| 'large'`               | `'medium'` |
| title           | 标题               | `ReactNode`                                    | —          |
| message         | 内容描述           | `ReactNode`                                    | —          |
| closable        | 是否可关闭         | `boolean`                                      | `false`    |
| onClose         | 关闭回调           | `() => void`                                   | —          |
| afterClose      | 关闭动画结束后回调 | `() => void`                                   | —          |
| expandable      | 是否可展开         | `boolean \| null`                              | `false`    |
| expanded        | 是否展开（受控）   | `boolean`                                      | —          |
| defaultExpanded | 默认是否展开       | `boolean`                                      | `false`    |
| onExpandChange  | 展开状态变化回调   | `(expanded) => void`                           | —          |
| expandContent   | 展开内容           | `ReactNode`                                    | —          |

### do / don't

```tsx
// ✅ 正确 — intent + message
<Alert intent="info" title="提示" message="这是一条信息" />

// ❌ 错误 — 使用 type / description（不存在的 prop 名）
<Alert type="info" title="提示" description="这是一条信息" />
```

```tsx
// ✅ 正确 — 可关闭 + 可展开
<Alert
  intent="warning"
  title="注意"
  closable
  expandable
  expandContent={<div>详细信息...</div>}
/>
```

## 组件 Demo

- [全部浮层组件 Demo](../references/demos/overlays.md)
