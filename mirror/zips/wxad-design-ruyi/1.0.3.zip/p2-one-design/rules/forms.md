# 表单与输入

## Form + Form.Item

表单使用 `Form` 包裹 `Form.Item`，实现水平标签 + 右侧控件的标准布局。

### 基础用法

```tsx
import { Form, Input, Select, Button } from 'one-design-next';

<Form labelSize={5} onFormSubmit={(values) => console.log(values)}>
  <Form.Item label="用户名" name="username" required>
    <Input placeholder="请输入用户名" />
  </Form.Item>
  <Form.Item label="角色" name="role">
    <Select options={[{ label: '管理员', value: 'admin' }]} />
  </Form.Item>
  <Form.Item>
    <Button intent="primary" type="submit">
      提交
    </Button>
  </Form.Item>
</Form>;
```

### Form Props

| 属性           | 说明                           | 类型                                   | 默认值       |
| -------------- | ------------------------------ | -------------------------------------- | ------------ |
| labelSize      | 标签宽度（em），不设则自动计算 | `number`                               | auto         |
| labelAlign     | 标签对齐                       | `'left' \| 'right'`                    | `'left'`     |
| validationMode | 校验触发方式                   | `'onSubmit' \| 'onBlur' \| 'onChange'` | `'onSubmit'` |
| errors         | 外部错误                       | `Record<string, string \| string[]>`   | —            |
| onFormSubmit   | 提交回调                       | `(values, details) => void`            | —            |

### Form.Item Props

| 属性       | 说明                 | 类型                        | 默认值  |
| ---------- | -------------------- | --------------------------- | ------- |
| label      | 标签文本             | `ReactNode`                 | —       |
| name       | 字段名               | `string`                    | —       |
| required   | 是否必填（显示红星） | `boolean`                   | `false` |
| tooltip    | 问号 Tooltip 提示    | `ReactNode`                 | —       |
| help       | 控件下方帮助文字     | `ReactNode`                 | —       |
| error      | 错误信息             | `ReactNode`                 | —       |
| disabled   | 禁用                 | `boolean`                   | `false` |
| display    | 纯展示模式           | `boolean`                   | `false` |
| validate   | 自定义校验           | `(value) => string \| null` | —       |
| labelWidth | 覆盖 Form 的标签宽度 | `number \| string`          | —       |

## do / don't

```tsx
// ✅ 正确 — Form + Form.Item
<Form labelSize={4}>
  <Form.Item label="邮箱" required>
    <Input />
  </Form.Item>
</Form>

// ❌ 错误 — 裸 div + 手动布局
<div className="space-y-4">
  <label>邮箱</label>
  <Input />
</div>
```

```tsx
// ✅ 正确 — 带 tooltip 的表单项
<Form.Item label="结算周期" tooltip="每月 15 日结算上月收益">
  <Select options={options} />
</Form.Item>

// ❌ 错误 — 手动实现 tooltip
<div>
  <label>结算周期 <Tooltip popup="..."><Icon name="help-circle" /></Tooltip></label>
  <Select options={options} />
</div>
```

## Input

```tsx
import { Input } from 'one-design-next';

<Input placeholder="请输入" />
<Input type="password" />
<Input leftElement={<Icon name="search" />} allowClear />
<Input count={{ max: 100 }} />
```

### Input Props

| 属性         | 说明     | 类型                             | 默认值     |
| ------------ | -------- | -------------------------------- | ---------- |
| size         | 尺寸     | `'small' \| 'medium' \| 'large'` | `'medium'` |
| intent       | 语义样式 | `'normal' \| 'danger'`           | `'normal'` |
| light        | 轻量风格 | `boolean`                        | `false`    |
| leftElement  | 左侧插槽 | `ReactNode`                      | —          |
| rightElement | 右侧插槽 | `ReactNode`                      | —          |
| allowClear   | 允许清空 | `boolean`                        | `false`    |
| count        | 字数统计 | `{ max, strategy?, formatter? }` | —          |
| onChange     | 变化回调 | `(e, value: string) => void`     | —          |
| onPressEnter | 回车回调 | `(e, value: string) => void`     | —          |

### do / don't

```tsx
// ✅ 正确 — leftElement / rightElement
<Input leftElement={<Icon name="search" />} rightElement={<span>次</span>} />

// ❌ 错误 — prefix / suffix（不存在）
<Input prefix={<Icon name="search" />} suffix={<span>次</span>} />
```

```tsx
// ✅ 正确 — onChange 带 value 参数
<Input onChange={(e, value) => console.log(value)} />

// ❌ 错误 — 只取 e.target.value（可以但不推荐）
<Input onChange={(e) => console.log(e.target.value)} />
```

### Textarea

```tsx
import { Input } from 'one-design-next';
const { Textarea } = Input;

<Textarea autoSize={{ minRows: 3, maxRows: 6 }} />
<Textarea topElement={<div>顶部工具栏</div>} bottomElement={<div>底部统计</div>} />
```

| 属性          | 说明       | 类型                              | 默认值  |
| ------------- | ---------- | --------------------------------- | ------- |
| autoSize      | 自适应高度 | `boolean \| { minRows, maxRows }` | —       |
| topElement    | 顶部插槽   | `ReactNode`                       | —       |
| bottomElement | 底部插槽   | `ReactNode`                       | —       |
| allowClear    | 允许清空   | `boolean`                         | `false` |
| count         | 字数统计   | `{ max, strategy?, formatter? }`  | —       |
| onChange      | 变化回调   | `(e, value: string) => void`      | —       |

## Select

```tsx
import { Select } from 'one-design-next';

<Select
  options={[
    { label: '选项 A', value: 'a' },
    { label: '选项 B', value: 'b' },
  ]}
  value={value}
  onChange={setValue}
  placeholder="请选择"
/>;
```

### Select Props

| 属性                  | 说明                 | 类型                                       | 默认值     |
| --------------------- | -------------------- | ------------------------------------------ | ---------- |
| options               | 选项数据             | `{ label, value }[]`                       | `[]`       |
| value                 | 当前值               | `string \| number \| string[] \| number[]` | —          |
| onChange              | 变化回调             | `(value) => void`                          | —          |
| mode                  | 多选/标签模式        | `'multiple' \| 'tags'`                     | —          |
| showSearch            | 是否可搜索           | `boolean`                                  | —          |
| showInnerSearch       | 下拉内搜索框         | `boolean`                                  | —          |
| filterOption          | 自定义筛选           | `boolean \| (input, option) => boolean`    | —          |
| onSearch              | 搜索回调             | `(value) => void`                          | —          |
| allowClear            | 允许清空             | `boolean`                                  | —          |
| placeholder           | 占位文字             | `string`                                   | —          |
| size                  | 尺寸                 | `'small' \| 'middle' \| 'large'`           | `'middle'` |
| light                 | 轻量风格             | `boolean`                                  | `false`    |
| disabled              | 禁用                 | `boolean`                                  | `false`    |
| visible               | 下拉是否展开（受控） | `boolean`                                  | —          |
| onVisibleChange       | 下拉展开变化         | `(visible) => void`                        | —          |
| popupMatchSelectWidth | 下拉宽度匹配         | `boolean \| number`                        | —          |
| optionCheckPosition   | 选中标记位置         | `'left' \| 'right'`                        | —          |

### 多选用法

```tsx
// ✅ 正确 — mode="multiple"
<Select mode="multiple" options={options} value={selected} onChange={setSelected} />

// ❌ 错误 — 使用 multiple 布尔属性（不支持）
<Select multiple options={options} />
```

### 下拉搜索

```tsx
// 下拉面板内搜索框
<Select showInnerSearch options={options} />

// 输入框直接搜索
<Select showSearch filterOption={(input, option) =>
  (option?.label ?? '').toLowerCase().includes(input.toLowerCase())
} />
```

## Checkbox

```tsx
import { Checkbox } from 'one-design-next';

// 单个
<Checkbox checked={checked} onChange={setChecked}>记住我</Checkbox>

// 组（通过 Checkbox 的 Group 用法）
<Checkbox.Group
  options={['选项A', '选项B', '选项C']}
  value={selected}
  onChange={setSelected}
/>
```

## Radio

```tsx
import { Radio } from 'one-design-next';

<Radio.Group value={value} onChange={setValue}>
  <Radio value="a">选项 A</Radio>
  <Radio value="b">选项 B</Radio>
</Radio.Group>;
```

## Switch

```tsx
import { Switch } from 'one-design-next';

<Switch checked={checked} onChange={setChecked} />;
```

## DatePicker / DateRangePicker / TimePicker

```tsx
import { DatePicker, DateRangePicker, TimePicker } from 'one-design-next';

<DatePicker value={date} onChange={setDate} />
<DateRangePicker value={range} onChange={setRange} />
<TimePicker value={time} onChange={setTime} />
```

## Cascader / TreeSelect

```tsx
import { Cascader, TreeSelect } from 'one-design-next';

<Cascader options={cascaderOptions} value={value} onChange={setValue} />
<TreeSelect treeData={treeData} value={value} onChange={setValue} />
```

## InputNumber / Slider / ColorPicker

```tsx
import { InputNumber, Slider, ColorPicker } from 'one-design-next';

<InputNumber value={num} onChange={setNum} min={0} max={100} />
<Slider value={val} onChange={setVal} min={0} max={100} />
<ColorPicker value={color} onChange={setColor} />
```

## AutoComplete

带自动补全功能的输入框，基于 rc-select 封装：

```tsx
import { AutoComplete } from 'one-design-next';

const [options, setOptions] = useState([]);

<AutoComplete
  options={options}
  onSearch={(value) => {
    setOptions(
      value
        ? [
            { label: value, value },
            { label: value + '2', value: value + '2' },
          ]
        : [],
    );
  }}
  placeholder="搜索..."
/>;
```

### AutoComplete Props

| 属性            | 说明             | 类型                             | 默认值     |
| --------------- | ---------------- | -------------------------------- | ---------- |
| options         | 选项数据         | `{ label, value }[]`             | `[]`       |
| value           | 当前值           | `string`                         | —          |
| onChange        | 变化回调         | `(value) => void`                | —          |
| onSearch        | 搜索输入回调     | `(value: string) => void`        | —          |
| placeholder     | 占位文字         | `string`                         | `'请输入'` |
| size            | 尺寸             | `'small' \| 'middle' \| 'large'` | `'middle'` |
| disabled        | 禁用             | `boolean`                        | `false`    |
| allowClear      | 允许清空         | `boolean`                        | —          |
| inputProps      | 透传给内部 Input | `Partial<InputProps>`            | —          |
| visible         | 下拉展开（受控） | `boolean`                        | —          |
| onVisibleChange | 下拉展开变化     | `(visible) => void`              | —          |

## InputOtp

验证码 / OTP 输入框：

```tsx
import { InputOtp } from 'one-design-next';

<InputOtp length={6} onChange={(value) => console.log(value)} />
<InputOtp length={4} autoSubmit onAutoSubmit={(value) => verify(value)} />
```

### InputOtp Props

| 属性         | 说明         | 类型                             | 默认值     |
| ------------ | ------------ | -------------------------------- | ---------- |
| length       | 输入格数     | `number`                         | `6`        |
| value        | 当前值       | `string`                         | `''`       |
| defaultValue | 默认值       | `string`                         | `''`       |
| onChange     | 变化回调     | `(value: string) => void`        | —          |
| size         | 尺寸         | `'small' \| 'medium' \| 'large'` | `'medium'` |
| autoFocus    | 自动聚焦     | `boolean`                        | `false`    |
| autoSubmit   | 填满自动提交 | `boolean`                        | `false`    |
| onAutoSubmit | 自动提交回调 | `(value: string) => void`        | —          |
| disabled     | 禁用         | `boolean`                        | `false`    |
| placeholder  | 占位符       | `string`                         | `''`       |

## 组件 Demo

- [全部表单组件 Demo](../references/demos/forms.md)
