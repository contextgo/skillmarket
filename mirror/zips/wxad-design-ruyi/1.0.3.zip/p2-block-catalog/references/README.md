# 区块源码

区块实现文件位于 **`references/blocks/<slug>.tsx`**（skills 内自包含）。

- 规格文档：`skills/p2-block-catalog/rules.md`
- 文档站入口：`docs-pages/block/<slug>.md`
