---
name: block-catalog
description: >-
  区块目录知识包。区块是基于 one-design-next 组件和设计规范组合而成的业务模块，
  用于回答"在什么产品场景下、以什么结构、用什么组件解决什么问题"。
  供 design-analyst、design-spec、page-implement、page-extend 等 skill 共享引用。
user-invocable: false
---

# 区块目录知识包

## 流程位置

```
PHASE 2 · 知识检索
角色：区块知识源（业务模块库 + 设计决策字典）
被引用方：design-analyst（识别可复用区块）、design-spec（组装设计 Prompt 时引用区块）、
        page-implement（代码生成时参考已有实现）、page-extend（在现有页面上加模块时查区块）
同层：one-design（设计系统知识）、business-knowledge（业务知识）、page-catalog（页面知识）
```

### 协作流水线

```
design-analyst → design-spec → page-implement → audit → polish
                    ↑                ↑
              one-design        本 skill（区块目录）
              business-knowledge page-catalog
```

---

## 核心认知：区块不是页面的碎片

```
组件：我提供什么能力（Button 能被点击）
区块：在什么业务场景下，用哪些组件回答什么产品问题
页面：把区块按业务语境编排成完整流程
```

**区块的核心价值不在于代码复用，而在于沉淀"设计决策"**——回答"什么时候该用什么模式"、"同一产品问题的不同变体如何选"。这也是本 skill 的主要知识输出。

### 组件 vs 区块 vs 页面

| 维度       | 组件 (Component)         | 区块 (Block)                                    | 页面 (Page)                                    |
| ---------- | ------------------------ | ----------------------------------------------- | ---------------------------------------------- |
| 粒度       | 原子级 UI 元素           | 由多个组件组合而成的业务模块                    | 由多个区块组合 + 业务语境的完整 UI             |
| 来源       | `one-design-next` npm 包 | [`references/blocks/<slug>.tsx`](../references/blocks/)（skills 内自包含，**唯一源码**） | [`references/workshop/<slug>.tsx`](../references/workshop/) |
| 复用范围   | 全局通用                 | 特定业务场景，跨页面复用                        | 单一业务场景，不复用（但可作为参考）           |
| 数据       | 无业务语义               | 包含 mock 数据和业务逻辑                        | 完整 mock + 顶栏 + 菜单 + 导航                 |
| 文档站入口 | `docs-pages/components/` | `docs-pages/block/<slug>.md`                    | `docs-pages/workshop/<slug>.md`                |

**区块源码的唯一真源**：`references/blocks/<slug>.tsx`（skills 内自包含）。
`docs-pages/block/<slug>.md` 通过 `<code src>` 引用上述路径；workshop 页面通过 `import '../blocks/...'` 复用；**workshop 之间禁止相互 import**（每个 workshop 保持自包含）。

---

## 区块层级体系（L1–L4）

按 **复用半径 + 业务耦合度** 分 4 层，替代原按 UI 形式的 7 类分法。层级决定 rules md 的写作侧重。

### L1 · 页面壳层（Page Shell）

**定义**：定义"这是什么类型的页面"的骨架层。
**rules 侧重**：讲清楚这个壳适合什么业务流程（如"主从阅读式复盘"、"全屏工作台"）。

| slug                             | 适用页面类型                | 产品问题                   |
| -------------------------------- | --------------------------- | -------------------------- |
| `page-header`                    | 几乎所有内容页（14 种模式） | 标题/筛选/Tab/操作的组合   |
| `notification-popover`           | 全局顶栏                    | 重要通知消息面板           |
| `review-master-detail-layout` ⭐ | 全域度量 · 三种复盘         | 已结束任务的多切面事后审查 |

### L2 · 通用业务区块（Cross-Page Blocks）

**定义**：同一个产品问题在 3+ 页面反复出现的解法。
**rules 侧重**：**强制写"变体决策"表**——这层区块的复用价值完全取决于能不能讲清楚"什么时候用哪种变体"。

| slug                          | 使用页面                                                                                  | 产品问题                        |
| ----------------------------- | ----------------------------------------------------------------------------------------- | ------------------------------- |
| `metric-card-group`           | brand5r, spuAudienceAsset, home                                                           | 5R 指标卡组 + 分布条 + 流转指标 |
| `metrics-overview`            | brand-mind-dashboard, mindshare-detail                                                    | 核心指标 + 分布条 + 双轴趋势    |
| `ranking-list`（4 变体）      | industry-opportunity-mind, brand-mind-dashboard, mindshare-detail, compete-analysis, mind | 在某维度上的排位展示            |
| `penetration-analysis`        | spuAudienceAsset, brand5r                                                                 | 维度切换的渗透率分析            |
| `touchpoint-analysis`         | brand5r, asset-flow                                                                       | 触点类别卡 + 子弹图             |
| `crowd-pick-card-grid` ⭐     | r-zero-crowd, interest-preference-crowd, theme-selection-crowd                            | 从候选池挑选人群投放            |
| `wordcloud-section` ⭐        | mind, content-asset, outside                                                              | 通用词云段落（权重可视化）      |
| `radar-with-metrics-panel` ⭐ | content-asset, outside                                                                    | 雷达对比 + 指标列的对比视角     |

### L3 · 场景专属区块（Scenario Blocks）

**定义**：1-2 个页面使用，但内部设计逻辑复杂到值得单独沉淀。
**rules 侧重**：**强制写"何时用 / 不要用的场景"**——避免 AI 误用。

| slug                   | 使用页面                                   | 产品问题                               |
| ---------------------- | ------------------------------------------ | -------------------------------------- |
| `dual-ranking-list`    | spuAudienceAsset                           | 本品牌 vs 本行业双列对比排名           |
| `quadrant-scatter`     | spuAudienceAsset, brand-mind-dashboard     | **四象限分布图**：资产×R3 单卡 + `MatrixScatterChart` 心智双矩阵（同一 `blocks/quadrant-scatter.tsx`） |
| `mindshare-dictionary` | brand-mind-dashboard, mindshare-detail     | 热词榜 + 多层级词云（品牌心智专属）    |
| `treemap-panel`        | brand-mind-dashboard                       | 心智量占比矩形树图                     |
| `crystal-ball`         | （Figma 直接开发）                         | 同心圆放射图 + 洞察结论                |
| `conversion-metrics`   | conversion-review                          | 摘要行 + 6 宫格指标 + 广告转化占比环形 |
| `conversion-trend`     | conversion-review                          | 堆叠柱 + 折线双轴                      |
| `crowd-table-view`     | conversion-review                          | 左人群排名表 + 右触点柱状图联动        |
| `crowd-bar-chart`      | conversion-review                          | 单柱渗透率 + 基准线                    |
| `sankey-chart`         | asset-flow                                 | 5R 资产流转桑基图                      |
| `ripple-chart`         | r0-audience-market                         | 人群相似度涟漪图                       |
| `store-insight-panel`  | regional-insight                           | 门店/区域列表 + 地图 + 详情卡          |
| `report-list`          | review, conversion-review, merchant-review | Master-Detail 左侧方案列表             |
| `crowd-card-list`      | r0-audience-market                         | 人群列表（3 种视图模式）               |
| `crowd-detail-panel`   | （未在 workshop 复用）                     | 人群详情面板                           |
| `ai-brief-input`       | create-audience（标签 Tab 顶栏）            | `AISearchBar` + `AISearchResultPanel`（ODN `AutoComplete`） |

### L4 · 交互/表单模式（Interaction Patterns）

**定义**：不是独立的视觉区块，而是"怎么做"的范式。
**rules 侧重**：列出样例代码 + Do/Don't，不输出独立 demo 页。

**当前注册**：无独立 slug。广告多选/穿梭弹窗等见各业务页 workshop references 内联实现；满足多页复用后再考虑升为 L4 或纳入候选（如 `influencer-filter-bar`）。

---

## 候选区块（不单独新建，标注观察）

以下模式目前**只在 1 个 workshop 页面**出现，暂不抽区块；等第二个场景出现再提升为 L2/L3：

| 候选名                        | 仅出现在                            | 理由                                                        |
| ----------------------------- | ----------------------------------- | ----------------------------------------------------------- |
| `home-brand-asset-radar-grid` | home                                | 4 雷达 + 排行榜网格，首页独有                               |
| `bubble-scatter-chart`        | compete-analysis                    | 三维散点（气泡=第三指标），可能作为 `quadrant-scatter` 心智变体的扩展 |
| `influencer-filter-bar`       | influencer                          | 复杂筛选条 → 可进 L4                                      |
| `targeting-config-panel`      | multi-step-config                   | 分步表单内含定向/出价等（原独立定向页已下线）              |
| `step-form-shell`             | multi-step-config                    | 步骤指示器 + 分步表单壳 → 可进 L1                           |

---

## 区块 rules md 模板

新模板在原模板前追加两段（**产品问题** + **变体决策**），让 AI 能判断"何时用哪个区块"。

```markdown
---
nav: ...
title: <区块名>
description: <一句话描述>
prompt: <区块描述，用于检索>
skill: <slug>
---

## 产品问题（何时用）

**解决什么**：一句话讲用户/产品问题。
**出现页面**：列出 workshop 中的 slug + 中文名。
**典型信号**：当需求描述中出现 {关键词 1 / 关键词 2} 时，应优先考虑本区块。

## 变体决策（L2 必写；L3 可选）

| 变体 | 产品问题细化 | 视觉差异 | 出现页面 |
| ---- | ------------ | -------- | -------- |
| ...  | ...          | ...      | ...      |

**选择准则**：

- 用户关心 A → 变体 1
- 用户关心 B → 变体 2

**不要用本区块的场景**（L3 必写）：

- 场景 X → 用 `<其他区块>`
- 场景 Y → 直接内联，不抽区块

## 预览

<code src="../../skills/references/blocks/<slug>.tsx"></code>

## 组件构成

（表格：元素 | 组件 | 说明）

## 设计规格

（表格：属性 | 值）

## 交互状态

（表格：状态 | 行为）

## 数据结构

（TypeScript interface）

## 设计偏差

（记录未 token 化的设计值，便于后续收敛）
```

### 各层级的写作强度

| 层级 | 产品问题         | 变体决策      | 不要用的场景 | 设计规格 |
| ---- | ---------------- | ------------- | ------------ | -------- |
| L1   | 必写             | 选写          | 选写         | 必写     |
| L2   | 必写             | **强制**      | 选写         | 必写     |
| L3   | 必写             | 选写          | **强制**     | 必写     |
| L4   | 必写（模式描述） | Do/Don't 形式 | —            | 代码片段 |

---

## 发现与查询

AI 在设计新页面或扩展现有页面时，按以下优先级查找可用区块：

1. **按产品问题匹配**：需求说"看榜单" → 查 L2 的 `ranking-list`；说"三个复盘页长一样" → 查 L1 的 `review-master-detail-layout`
2. **按使用页面反查**：需求接近现有页面类型 → 看该页面的区块组成
3. **按层级优先级**：L1（页面壳）> L2（通用区块）> L3（场景区块）。L3 只在业务语境匹配时才用
4. **没匹配**：判断是否"3+ 页面会用" → 新建 L2；否则内联或加到候选名单

---

## 新增区块流程

### 1. 判断层级

- **2+ 业务域的 3+ 页面会复用** → L2
- **1 个业务域内的 1-2 页面，但结构复杂** → L3
- **只在 1 页出现** → 不新建，在本 GUIDE 的"候选区块"小节标注
- **是交互模式而非视觉区块** → L4

### 2. 写入源码和规格

- 源码：`skills/references/blocks/<slug>.tsx`（唯一真源）
- 规格：`skills/p2-block-catalog/rules.md (对应 slug 章节)`（按新模板）
- 文档站入口：`docs-pages/block/<slug>.md`（frontmatter + `<code src="../../skills/references/blocks/<slug>.tsx"></code>`）

### 3. 更新本 GUIDE

- 在对应层级的注册表追加新行（slug / 使用页面 / 产品问题）
- 若触发了新层级或新变体，补充说明

### 4. workshop 改为 import

- 若该区块从 workshop 抽出，对应 workshop 把内联实现改为 `import '../blocks/<slug>'`
- 保留 workshop 的业务语境（顶栏/菜单/mock 数据自包含）

---

## 代码约定

- 首行 `'use client'`
- 组件从 `one-design-next` 导入
- 样式用 Tailwind class + ODN token（`var(--odn-color-*)`）
- 数据全部 mock（推荐 CDN JSON 或内联常量）
- 组件自包含，导出 default
- **Props 驱动**：关键数据和配置通过 Props 传入，不硬编码业务字符串

### 如翼平台组件 Do / Don't

以下规范适用于所有如翼 workshop 页面和区块：
规则冲突时按以下优先级执行：组件专用规则 > 场景规则 > 通用规则。

**Don't**

- **不要用 `size="small"`**。如翼平台所有控件使用默认尺寸，不缩小。
- **不要在非图表场景给 Select / Dropdown 加 `light`**。`light` 样式仅用于图表（ECharts / D3）上方的操作栏控件，其他位置的筛选栏、表单等一律使用默认样式。
- **不要直接使用 `DatePicker`（range 模式）或 `DateRangePicker` 做日期范围选择**。如翼的日期范围统一使用 `RyDateRangePicker` 区块，它自带触发器和快捷模式，不需要也不支持 `light` 等外观 prop。
- **`light` 组件不加 `prefix`**。`light` 是轻量内联样式，不搭配 prefix 标签使用。
- **不要给 `Select` / `Cascader` 设置固定宽度（`w-[120px]` 等）**。Select 应自适应内容宽度，如需限制可用 `max-w-[250px]`。
- **不要用 `TreeSelect`**。所有树形选择场景统一使用 `Cascader` 代替。
- **不要自己手写完整的表单控件**（如自己拼 `<input>` + `<div>` 模拟下拉、自己画日期面板等）。`one-design-next` 已提供 Input、Select、Cascader、DatePicker、Checkbox、Radio、Switch、AutoComplete、Form 等全套表单组件——当你发现自己在用原生标签拼一个完整的交互控件时，说明方向已经走偏了，应该回头查组件库。

**Do**

- `prefix` 在如翼里承担字段标签角色（类似 Form.Label）：用于声明控件语义、统一筛选口径、提升截图与复盘场景的可读性。
- **页面头部筛选栏、表格上方、卡片开头处的 `Select`、`Cascader`、`DatePicker` 一律加 `prefix`**，让用户无需展开下拉就能理解该控件的含义。`prefix` 文字必须设为灰色以区分值文字，写法：`prefix={<span className="text-[var(--odn-color-black-9)]">标签</span>}`。例如 `<Select prefix={<span className="text-[var(--odn-color-black-9)]">参照系</span>} ...>`、`<Cascader prefix={<span className="text-[var(--odn-color-black-9)]">品牌</span>} ...>`。
- 图表上方控件遵循场景规则：默认加 `prefix`；若使用 `light` 样式（如图表操作栏），则不加 `prefix`。
- 日期范围选择统一使用 `RyDateRangePicker` 区块（`blocks/ry-date-range-picker.tsx`）。仅与 Select 拼接（`-ml-px` + 自定义 border-radius）的复合控件场景允许例外；除该白名单外，一律不使用 `DatePicker`（range）/`DateRangePicker`。
- 单日期选择使用 `DatePicker` + `prefix="日期"` + `className="w-[200px]"`。

### 区块的可复用性要求

- 独立渲染：不依赖外部状态管理
- Mock 完备：提供符合业务语境的默认 mock 数据
- 文档齐全：frontmatter 的 `prompt` 字段清晰描述使用场景
- **业务锚点可替换**：品牌名/SPU 名等业务字符串通过 Props 传入，不硬编码

---

## 详细参考

| 层级 | 规则文件                                                                        | 覆盖区块                 |
| ---- | ------------------------------------------------------------------------------- | ------------------------ |
| L1   | [rules.md#page-header](rules.md#slug-page-header)                                    | 页面头部（14 种模式）    |
| L1   | [rules.md#notification-popover](rules.md#slug-notification-popover)                  | 通知消息                 |
| L1   | [rules.md#review-master-detail-layout](rules.md#slug-review-master-detail-layout) ⭐ | 复盘页主从布局           |
| L1   | [rules.md#section-block](rules.md#slug-section-block)                                | 可折叠内容区块（模式）   |
| L2   | [rules.md#metric-card-group](rules.md#slug-metric-card-group)                        | 资产指标卡组             |
| L2   | [rules.md#metrics-overview](rules.md#slug-metrics-overview)                          | 心智概览面板             |
| L2   | [rules.md#ranking-list](rules.md#slug-ranking-list)                                  | 排名榜（4 变体）         |
| L2   | [rules.md#penetration-analysis](rules.md#slug-penetration-analysis)                  | 渗透分析面板             |
| L2   | [rules.md#touchpoint-analysis](rules.md#slug-touchpoint-analysis)                    | 触点分析面板             |
| L2   | [rules.md#crowd-pick-card-grid](rules.md#slug-crowd-pick-card-grid) ⭐               | 人群精选卡片网格         |
| L2   | [rules.md#wordcloud-section](rules.md#slug-wordcloud-section) ⭐                     | 词云段落                 |
| L2   | [rules.md#radar-with-metrics-panel](rules.md#slug-radar-with-metrics-panel) ⭐       | 雷达 + 指标列            |
| L3   | [rules.md#dual-ranking-list](rules.md#slug-dual-ranking-list)                        | 双列排名榜               |
| L3   | [rules.md#quadrant-scatter](rules.md#slug-quadrant-scatter)                          | 四象限分布图（资产×R3 + 心智双矩阵） |
| L3   | [rules.md#mindshare-dictionary](rules.md#slug-mindshare-dictionary)                  | 心智词典                 |
| L3   | [rules.md#treemap-panel](rules.md#slug-treemap-panel)                                | 矩形树图面板             |
| L3   | [rules.md#crystal-ball](rules.md#slug-crystal-ball)                                  | 水晶球 · 人群洞察        |
| L3   | [rules.md#conversion-metrics](rules.md#slug-conversion-metrics)                      | 转化概览                 |
| L3   | [rules.md#conversion-trend](rules.md#slug-conversion-trend)                          | 转化趋势图               |
| L3   | [rules.md#crowd-table-view](rules.md#slug-crowd-table-view)                          | 人群对比视图             |
| L3   | [rules.md#crowd-bar-chart](rules.md#slug-crowd-bar-chart)                            | 人群渗透柱状图           |
| L3   | [rules.md#sankey-chart](rules.md#slug-sankey-chart)                                  | 桑基图                   |
| L3   | [rules.md#ripple-chart](rules.md#slug-ripple-chart)                                  | 涟漪图                   |
| L3   | [rules.md#store-insight-panel](rules.md#slug-store-insight-panel)                    | 门店洞察面板             |
| L3   | [rules.md#report-list](rules.md#slug-report-list)                                    | 方案列表                 |
| L3   | [rules.md#crowd-card-list](rules.md#slug-crowd-card-list)                            | 人群列表（3 种视图）     |
| L3   | [rules.md#crowd-detail-panel](rules.md#slug-crowd-detail-panel)                      | 人群详情面板             |
| L3   | [rules.md#ai-brief-input](rules.md#slug-ai-brief-input)                              | AI Brief / 智选搜索条（AutoComplete） |

### 设计稿来源

- SPU 人群资产页：[Figma 设计稿](https://www.figma.com/design/HL9gBM5zwcWwxlA1OKBPu1?node-id=2448-16960)
- 智选人群 × AI 标签：[Figma 设计稿](https://www.figma.com/design/m9b6QtKqfQECFfTUq8tXi9?node-id=5639-36348)

---

## 设计引用协议

### design-analyst 如何使用本 skill

在阶段 1（输入解析）时：

1. 加载本 skill，浏览 L1/L2 层的注册表
2. 按用户需求识别命中的"产品问题"
3. 在结构化需求文档中标注「**可复用区块**」和「**需新建区块**」

### design-spec 如何使用本 skill

在阶段 1（模块拆解）时：

1. 对每个模块判断：是复用已有区块、fork 修改、还是新建区块
2. 在设计 Prompt 的「区块引用」字段中注明层级和来源

模块 Prompt 中的「区块引用」字段：

```
### 8. 区块引用
- 复用（L1）：page-header、review-master-detail-layout
- 复用（L2）：metrics-overview、ranking-list/share
- fork 修改（L3）：crystal-ball（只改配色）
- 全新开发：触点趋势热力图（无匹配区块；考虑纳入候选）
```

### page-implement 如何使用本 skill

在 Step 4（查询组件库）之后：

1. 检查设计 Prompt 中的区块引用
2. 读取已有区块的源码作为参考
3. 复用区块时直接 `import`；参考区块时内联 fork 修改
4. 生成完成后更新本 skill 的注册表

### page-extend 如何使用本 skill

在"从页面出发"改造现有 workshop 时：

1. 定位目标 workshop 页面，确认要加的模块
2. 先查本 skill 是否有匹配区块可直接 `import`
3. 无匹配则内联实现；判断是否纳入候选区块观察列表

---

## 与其他 p2 知识包的关系

| 知识包                                                       | 作用                           | 本 skill 与之的关系                                           |
| ------------------------------------------------------------ | ------------------------------ | ------------------------------------------------------------- |
| [`p2-page-catalog`](../p2-page-catalog/GUIDE.md)             | 页面目录（成品库）             | 页面由区块拼成；本 skill 提供区块清单，页面目录提供完整上下文 |
| [`p2-business-knowledge`](../p2-business-knowledge/GUIDE.md) | 业务术语 / 站点地图 / 模块概念 | 区块的"产品问题"引用业务术语                                  |
| [`p2-one-design`](../p2-one-design/GUIDE.md)                 | 组件库知识                     | 区块由组件搭成；本 skill 不重复描述组件                       |

### 责任划分（避免重复）

- **组件粒度**（Button / Table 等原子能力）→ `p2-one-design`
- **区块粒度**（产品问题 + 变体决策 + 设计规格）→ 本 skill
- **页面粒度**（完整业务页面 + 上下文）→ `p2-page-catalog`
- **业务概念**（站点地图、5R、心智量等术语）→ `p2-business-knowledge`

---

## 相关 dev-diary

- [区块层盘点与 skill 双模式工作流](../../docs-pages/dev-diary/block-audit-and-skill-workflow.md)：初版盘点 + L1-L4 分类 + 双模式工作流
- [从 workshop 反向归纳区块](../../docs-pages/dev-diary/block-redesign-from-workshop.md)：设计决策字典化 + 4 个新区块定稿 + 新 rules 模板
