# 模块 Prompt 模板（腾讯广告如翼）

为阶段 2（设计 Prompt 生成）提供常见模块类型的结构化模板。每个模板严格映射到 One Design Next 组件。

---

## 模板 0：页面框架模块（必须作为第一个模块输出）

适用于：所有如翼平台页面。

> **原则：截图中看得到的全局元素必须还原。**
> 只有用户明确说"只关注内容区"时才可省略此模块。

```
## 模块：页面框架

### 1. 业务上下文
[页面名] 的全局布局框架，包含顶部一级导航和左侧二级菜单，为内容区提供标准化容器。
属于腾讯广告如翼平台的 [一级导航] > [二级菜单] 模块。

### 2. 组件树

RuyiLayout(
  navItems: ["首页", "洞察诊断", "人群策略", "策略应用", "全域度量", "数据工厂"],
  activeNav: "[当前一级导航]",
  menuItems: [...],
  activeMenu: "[当前激活菜单key]",
  accountName: "品牌名 – 行业",
  accountId: "00000"
)
├── 顶栏
│   ├── div(mx-6 w-[144px] h-5) — 如翼 Logo
│   ├── div(flex items-center px-3) — 一级导航项
│   │   └── HoverFill(bgClassName: "rounded-lg") × N
│   │       └── div(h-10 flex items-center text-base px-3)
│   │           └── 激活态: text-black-12 + textShadow 加粗效果
│   │           └── 默认态: text-black-10
│   └── div(flex items-center px-4) — 右侧工具区
│       ├── Button(light, icon: "code")
│       ├── Button(light, icon: "user-pack")
│       ├── Button(light, icon: "bell")
│       ├── Button(light, icon: "help-circle")
│       ├── Button(light, icon: "setting")
│       ├── div(mx-4 w-px h-5 bg-black-5) — 分隔线
│       └── HoverFill(bgClassName: "rounded-lg")
│           └── div(flex items-center px-3 h-12 gap-2) — 账号信息
│               ├── div > 品牌名-行业 + ID
│               └── Icon(name: "down-filled")
├── 左侧菜单 — div(space-y-1 w-[168px])
│   └── Collapsible × N（每个菜单分组）
│       ├── CollapsibleTrigger > HoverFill(bgClassName: "rounded-[36px]")
│       │   └── div(flex items-center justify-between px-4 h-9)
│       │       ├── Icon(name: "[图标]") + span(ml-2 text-sm) — 分组标题
│       │       └── Icon(name: "up") — 展开/收起箭头
│       │       └── 激活态（折叠且子菜单激活）: font-semibold text-blue-6 bg-blue-2
│       └── CollapsibleContent > div(space-y-0.5 pt-1)
│           └── HoverFill(className: "ml-6", bgClassName: "rounded-[30px]") × N
│               └── div(flex items-center px-4 h-[30px] text-xs)
│                   └── 激活态: font-semibold text-blue-6 bg-blue-2
│                   └── 可选 badge: div(w-7 h-4 text-[7.5px] bg-black-7 text-white rounded-lg)
└── 内容区 — div(flex-1 min-w-0 pl-6)
    └── [各内容模块]

### 3. 图标清单（from one-design-next Icon）
从截图中识别的图标：
- Icon name="chart" — 数据分析菜单
- Icon name="users" — 人群相关菜单
- Icon name="shield" — 品牌资产菜单
- Icon name="search" — 搜索/市场洞察菜单
- Icon name="setting" — 设置菜单
- Icon name="bell" — 顶栏通知
- ... (逐项列出)

### 4. 组件约束
- 使用 RuyiLayout 组件作为页面框架
- 一级导航用 HoverFill 包裹实现悬停效果
- 左侧菜单用 Collapsible + HoverFill 组合
- 菜单激活态使用 text-blue-6 bg-blue-2（蓝色系）
- 顶栏工具按钮使用 Button(light) 变体

### 5. Design Token 约束
- 页面背景：bg-[#f2f5fa]
- 内容区域容器：flex px-5 pb-5
- 左侧菜单宽度：w-[168px]
- 菜单分组高度：h-9
- 子菜单项高度：h-[30px]
- 一级导航项高度：h-10
- 顶栏高度：h-16
- 导航文字（默认）：text-base text-black-10
- 导航文字（激活）：text-base text-black-12 + textShadow 模拟加粗
- 菜单文字（默认）：text-sm
- 子菜单文字：text-xs
- 菜单激活态：font-semibold text-blue-6 bg-blue-2
- 分隔线：w-px h-5 bg-black-5
- 账号名称：text-xs
- 账号 ID：text-xs text-black-9

### 6. 状态处理
- 菜单分组展开/收起：Collapsible 组件控制
- 子菜单激活态：当前页面的菜单项高亮
- 分组折叠且子菜单激活时：分组标题显示激活态
- 侧边栏收起（可选）：collapsible prop 控制

### 7. 代码结构
- 文件路径：`src/workshop/<slug>.tsx`（注册到 `workshopModules.ts`，见 page-implement Step 5）
- 组件名：[PageName]Page（函数式组件，export default）
- 依赖：`import { RuyiLayout } from 'one-design-next'`
- Props: 无（页面级组件，内部管理状态）
```

---

## 模板 1：数据表格模块

适用于：人群列表、转化复盘报告、角色管理等表格为主的页面。

**先确认 5 维度**：结构模式(A-E) / 嵌入模式(Full/Embedded/Flat) / 工具栏组件 / 横切特性 / 数据量

```
## 模块：[表格模块名]

### 1. 业务上下文
展示 [业务实体] 的 [数据维度] 明细，结构模式 [A/B/C/D/E]，[Full/Embedded/Flat] 模式。

### 2. 组件树

--- 标准表格页（参考 audience-list.tsx / conversion-review.tsx）---
div(bg-white rounded-xl p-5)
├── div(flex items-center justify-between mb-4) — 工具栏
│   ├── div(flex items-center gap-3) — 左侧
│   │   ├── Input(leftElement: Icon("search"), placeholder: "搜索...") — 搜索框
│   │   └── Select / Dropdown — 筛选条件（可选）
│   └── div(flex items-center gap-2) — 右侧
│       ├── Button(type: "primary") — 主操作
│       └── Button / Dropdown — 次要操作
├── Table(columns, dataSource)
│   ├── columns: ColumnsType<DataItem>
│   │   ├── { title, dataIndex, key } — 基础列
│   │   ├── { title, dataIndex, sorter: true, sortOrder } — 可排序列
│   │   ├── { title, render: () => Button/Dropdown } — 操作列
│   │   └── 数值列: text-right + tabular-nums
│   └── TableBody — 数据行
└── div(flex justify-end mt-4) — 分页区
    └── Pagination(current, total, pageSize, onChange)

### 3. 图标清单（from one-design-next Icon）
- Icon name="search" — 搜索框前缀
- Icon name="more" — 更多操作
- Icon name="delete" — 删除操作
- Icon name="edit" — 编辑操作

### 4. 组件约束
- Table 使用 columns + dataSource 模式
- 列定义使用 ColumnsType<T> 类型
- 排序使用 sortOrder + onSortChange 回调
- 操作列放在最后一列，使用 render 自定义
- 分页组件独立于表格，放在表格下方

### 5. Design Token 约束
- 表格容器：bg-white rounded-xl p-5
- 工具栏间距：mb-4
- 搜索框样式：带 Icon prefix
- 分页区：flex justify-end mt-4
- 数值列：tabular-nums text-right
- 操作按钮：Button(light) 或 Button(ghost)

### 6. 状态处理
- normal: 有数据的正常展示
- loading: 表格区域骨架屏
- empty: 居中 "暂无数据" + 引导操作
- error: 错误提示 + 重试按钮

### 7. 代码结构
- 文件路径：由 mode 参数决定
- 组件名：默认导出函数式组件
- 数据类型：type [Item] = { ... }
- Mock 数据：const [DATA]: [Item][] = [...]
```

---

## 模板 2：指标卡 + 仪表盘模块

适用于：资产流转、数据概览、KPI 展示等。

**先判断容器类型**：截图中指标卡是独立卡片还是白色区块内的网格？

```
## 模块：[仪表盘模块名]

### 1. 业务上下文
展示 [业务领域] 的 [N] 个核心指标，帮助用户快速了解 [整体状况]。

### 2. 组件树

--- 参考 asset-flow.tsx 的指标卡模式 ---
div(grid grid-cols-4 gap-4) — 指标卡网格
├── Card × N（或 div(bg-white rounded-xl p-5) × N）
│   └── div(flex flex-col)
│       ├── div(flex items-center gap-1)
│       │   ├── span(text-xs text-black-9) — 指标名称
│       │   └── span(text-[10px] text-black-7) — 副标题（可选）
│       ├── div(text-2xl font-semibold tabular-nums mt-2) — 指标值
│       └── div(flex items-center gap-1 mt-1) — 趋势（可选）
│           ├── span(text-xs) — "较上周期"
│           └── span(text-xs text-green-6 或 text-red-6) — "+XX.X%" / "-XX.X%"

--- 图表区域 ---
div(bg-white rounded-xl p-5 mt-4)
├── div(flex items-center justify-between mb-4) — 标题+筛选
│   ├── span(text-sm font-semibold) — "图表标题"
│   └── Select / DatePicker — 时间范围筛选
└── div(h-60 to h-80)
    └── 图表（recharts 或 ECharts 等）

--- 底部数据表格 ---
div(bg-white rounded-xl p-5 mt-4)
├── div(flex items-center justify-between mb-4)
│   ├── span(text-sm font-semibold) — "表格标题"
│   └── Button(ghost) — "查看更多"
└── Table(columns, dataSource)

### 3. 图标清单
- Icon name="up" — 趋势上升
- Icon name="down" — 趋势下降
- Icon name="help-circle" — 指标说明 Tooltip

### 4. 组件约束
- 指标卡使用 Card 组件或白色 div，根据截图判断
- 图表部分需根据实际业务选择合适图表库
- 表格复用模板 1 的表格组件规范
- 筛选控件使用 Select / DatePicker

### 5. Design Token 约束
- 指标卡网格：grid grid-cols-4 gap-4（响应式降级到 2 列/1 列）
- 指标名称：text-xs text-black-9
- 指标值：text-2xl font-semibold tabular-nums
- 趋势上升：text-green-6
- 趋势下降：text-red-6
- 区块间距：mt-4
- 区块内边距：p-5
- 区块圆角：rounded-xl

### 6. 状态处理
- normal: 显示完整仪表盘
- loading: 指标卡骨架屏 + 图表骨架屏 + 表格骨架屏
- empty: 指标值显示 "—"
- error: 错误提示 + 重试

### 7. 代码结构
- 文件路径：由 mode 参数决定
- 组件名：默认导出函数式组件
- 数据类型：type MetricCard = { title; subtitle?; value; comparison?; positive? }
- Mock 数据：const METRIC_CARDS: MetricCard[] = [...]
```

---

## 模板 3：消息通知 / 卡片列表模块

适用于：人群策略消息、系统通知、任务列表等。

```
## 模块：[消息/卡片列表模块名]

### 1. 业务上下文
以 [卡片/消息] 形式展示 [业务实体] 的信息，支持 [操作]。

### 2. 组件树

--- 参考 audience-strategy.tsx ---
div(flex flex-col gap-4)
├── div(flex items-center justify-between) — 工具栏
│   ├── Tabs(items: [...], activeKey, onChange) — 分类 Tab
│   └── div(flex items-center gap-2) — 操作区
│       ├── Input(prefix: Icon("search")) — 搜索
│       └── Button — 操作按钮
├── ScrollArea — 可滚动内容区
│   └── div(flex flex-col gap-3)
│       └── 自定义 MessageItem 卡片（用 div + ODN 样式自实现，ODN 库未提供该组件）× N
│           ├── div(flex items-center gap-2) — 标签行
│           │   └── span(text-xs bg-xxx rounded px-1.5 py-0.5) — 类型标签
│           ├── div(text-sm) — 主要内容
│           ├── div(text-xs text-black-9 mt-1) — 时间/辅助信息
│           └── div(flex items-center gap-2 mt-2) — 操作区（可选）
│               ├── Link — 查看详情
│               └── Button(size: "sm") — 操作按钮
└── div(flex justify-center mt-4)
    └── Pagination — 分页

### 3. 图标清单
- Icon name="search" — 搜索
- Icon name="bell" — 通知图标

### 4. 组件约束
- Tab 使用 Tabs 组件切换分类
- 消息/卡片可使用 Card 或自定义 div
- 滚动区域使用 ScrollArea
- 未读/已读状态通过样式区分

### 5. Design Token 约束
- 消息卡片：bg-white rounded-lg p-4 hover:bg-gray-50（或 HoverFill）
- 类型标签：text-xs rounded px-1.5 py-0.5 + 语义背景色
- 主要内容：text-sm text-black-12
- 辅助信息：text-xs text-black-9
- 卡片间距：gap-3

### 6. 状态处理
- normal: 显示消息列表
- loading: 骨架屏卡片
- empty: "暂无消息" + 引导
- 未读态: 左侧蓝色圆点或字重加粗

### 7. 代码结构
- 文件路径：由 mode 参数决定
- 组件名：默认导出函数式组件
- 数据类型：interface MessageItem { type; text; publishedAt; read?; ... }
```

---

## 模板 4：配置管理模块

适用于：权限设置、账号管理、功能配置等。

```
## 模块：[配置模块名]

### 1. 业务上下文
管理 [配置对象] 的 [配置内容]，支持 [增删改] 操作。

### 2. 组件树

--- 参考 multi-step-config.tsx（配置类 Tab + 表格骨架）---
div(flex flex-col gap-4)
├── div(bg-white rounded-xl p-5) — 主配置区
│   ├── div(flex items-center justify-between mb-4) — 标题+操作
│   │   ├── div
│   │   │   ├── div(text-base font-semibold) — "配置区标题"
│   │   │   └── div(text-xs text-black-9 mt-1) — "配置说明"
│   │   └── Button(type: "primary") — "新建/添加"
│   ├── Tabs(items: [...]) — 子分类（可选）
│   └── Table(columns, dataSource)
│       └── 操作列: Button(light) / Dropdown
│           ├── "编辑"
│           └── "删除"
└── div(bg-white rounded-xl p-5) — 次要配置区（可选）

### 3. 图标清单
- Icon name="edit" — 编辑操作
- Icon name="delete" — 删除操作
- Icon name="plus" — 新增操作

### 4. 组件约束
- 配置区使用白色 div 容器
- 操作按钮 primary 用于主操作（新建），light/ghost 用于行内操作
- 危险操作（删除）需要二次确认
- Tab 可用于子分类切换

### 5. Design Token 约束
- 配置区：bg-white rounded-xl p-5
- 标题：text-base font-semibold
- 说明：text-xs text-black-9
- 操作按钮间距：gap-2
- Tab 间距：mb-4

### 6. 状态处理
- normal: 配置列表
- loading: 表格骨架屏
- empty: "暂无配置" + "立即创建" 按钮
- 操作反馈: 成功/失败提示

### 7. 代码结构
- 文件路径：由 mode 参数决定
- 组件名：默认导出函数式组件
- 数据类型：type [ConfigItem] = { ... }
```

---

## 模板 5：图表分析模块

适用于：趋势分析、数据对比、分布展示。

```
## 模块：[图表模块名]

### 1. 业务上下文
展示 [数据指标] 在 [时间维度] 上的 [趋势/对比/分布]。

### 2. 组件树

div(bg-white rounded-xl p-5)
├── div(flex items-center justify-between mb-4) — 标题+控制区
│   ├── span(text-sm font-semibold) — "图表标题"
│   └── div(flex items-center gap-2)
│       ├── Select — 指标切换（可选）
│       └── DatePicker — 时间范围
├── div(flex items-center gap-4 mb-4) — 图例/指标选择（可选）
│   └── Tabs / Checkbox 组 — 指标勾选
└── div(h-60 to h-80)
    └── recharts.ResponsiveContainer(width: "100%", height: "100%")
        └── LineChart / BarChart / PieChart
            ├── CartesianGrid(strokeDasharray: "3 3")
            ├── XAxis
            ├── YAxis
            ├── recharts.Tooltip
            └── Line / Bar

### 3. 图标清单
- 通常无需额外图标

### 4. 组件约束
- 筛选控件使用 Select / DatePicker
- 图表使用 recharts 或业务需要的图表库
- 图表容器固定高度 h-60 至 h-80

### 5. Design Token 约束
- 图表容器：bg-white rounded-xl p-5
- 图表标题：text-sm font-semibold
- 图表高度：h-60 至 h-80
- 如翼品牌蓝：var(--odn-color-blue-6)
- 辅助色：根据业务需求选择

### 6. 状态处理
- normal: 图表正常渲染
- loading: 图表区域骨架屏
- empty: 居中 "暂无数据"
- error: 错误提示 + 重试

### 7. 代码结构
- 文件路径：由 mode 参数决定
- 组件名：图表可作为页面子组件
```

---

## 通用规则

### 所有模板的共同要求

1. **输出位置**：由 mode 参数决定（full 写入项目内部页面目录，readonly 输出到用户工作目录）
2. **共享布局**：所有页面使用 `RuyiLayout` 组件
3. **组件来源**：只从 `one-design-next` 导入组件
4. **图标使用**：使用 `<Icon name="xxx" />` 组件
5. **类型定义**：使用 TypeScript interface/type，并 export
6. **Mock 数据**：每个模块自带 mock 数据常量
7. **工具函数**：样式合并用 `clsx`（`import clsx from 'clsx'`）
8. **响应式**：最小宽度 `min-w-[1200px]`（如翼为桌面端产品）
9. **颜色系统**：使用如翼的 `text-black-{n}` / `bg-blue-{n}` 等 token
10. **背景色**：页面 `bg-[#f2f5fa]`，内容区块 `bg-white rounded-xl`
11. **激活态**：菜单/Tab 激活使用蓝色系 `text-blue-6 bg-blue-2`
12. **容器选择**：有 shadow/border → Card 组件；仅白色背景 → `div.bg-white.rounded-xl`
