---
name: design-spec
description: 设计 Skill — 将结构化需求转化为精确到 One Design Next 组件级别的设计 Prompt。加载设计系统知识和业务知识，输出模块化的设计 Prompt 交给 page-implement 生成代码。当 design-analyst 完成需求分析后，自动接力执行。
args:
  - name: input
    description: design-analyst 输出的结构化需求文档，或用户直接提供的设计说明
    required: true
  - name: scope
    description: full（完整页面）/ module（单个模块）/ prompt-only（只输出 Prompt 不触发代码生成）
    required: false
  - name: mode
    description: full / readonly（透传给下游 page-implement）
    required: false
next_skill: page-implement
next_skill_input: 模块化设计 Prompt
requires_knowledge:
  - one-design
  - business-knowledge
  - block-catalog
user-invocable: true
---

# Design Spec — 设计 Prompt 生成

将结构化需求转化为**精确到 One Design Next 组件级别的设计 Prompt**，交给 `page-implement` skill 生成代码。

**核心原则：只输出设计 Prompt，不写代码。** 本 skill 的输出是结构化的设计规格文档，不是 `.tsx` 文件。

## 流程位置

```
PHASE 1 · 输入与分析（下半段）
上游：design-analyst（输出结构化需求文档 → 本 skill 的输入）
下游：page-implement（本 skill 的设计 Prompt → 代码生成的输入）
知识依赖：one-design（设计系统知识）、business-knowledge（业务知识）、block-catalog（区块知识）
```

---

## 知识加载协议

在开始工作前，根据需求加载对应的知识文件：

### 必须加载

| 知识源             | 文件       | 加载时机                 |
| ------------------ | ---------- | ------------------------ |
| business-knowledge | `GUIDE.md` | 始终加载，理解业务语境   |
| one-design         | `GUIDE.md` | 始终加载，获取组件速查表 |
| block-catalog      | `GUIDE.md` | 始终加载，查询可复用区块 |

### 按需加载 — 业务与页面知识

| 场景             | 加载的文件                                                                 |
| ---------------- | -------------------------------------------------------------------------- |
| 设计某模块的页面 | `skills/p2-business-knowledge/rules.md`（模块业务目标、导航结构、页面清单） |
| 修改已有页面     | `skills/p2-page-catalog/rules.md`（页面区块组装、数据模型、设计决策） |
| 设计新页面       | 对应 `skills/p2-business-knowledge/rules.md` + 同模块已有 `skills/p2-page-catalog/rules.md`（参考同模块页面风格） |

> **外部平台 fallback**：上述 rules 文件属于核心层知识，随 skill 打包，在所有平台均可加载。
> 如果对应的 rules 文件不存在（如新模块尚未编写知识文件），使用 `business-knowledge` GUIDE.md 中的站点地图概览作为替代。

### 按需加载 — 组件规范

| 需求类型        | 加载的 one-design rules 文件 |
| --------------- | ---------------------------- |
| 有表单          | `rules/forms.md`             |
| 有按钮/操作     | `rules/actions.md`           |
| 有表格/卡片     | `rules/data-display.md`      |
| 有 Tab/分页     | `rules/navigation.md`        |
| 有弹窗/浮层     | `rules/overlays.md`          |
| 需确认图标      | `rules/icons.md`             |
| 需确认颜色      | `rules/design-tokens.md`     |
| 有页面框架/布局 | `rules/layout.md`            |
| 有库中没有的 UI 元素 | `rules/design-paradigm.md` |

---

## 3 阶段工作流

```
输入（结构化需求） → [0.全局布局识别] → [1.模块拆解] → [2.设计 Prompt 生成]
                                                              ↓
                                                   交给 page-implement 执行
```

### 阶段 0：全局布局识别（必须执行）

**默认还原截图中所有可见元素。** 除非用户明确说"只关注内容区"或"不需要导航"，否则必须包含：

1. **识别页面框架结构**：
   - 顶部导航栏：Logo + 一级导航标签 + 工具按钮 + 账号信息
   - 左侧菜单：二级菜单分组（可折叠） + 当前激活菜单
   - 页面背景色：`bg-[#f2f5fa]`

2. **提取一级导航**：
   - 识别当前激活的一级导航（首页/洞察诊断/人群策略/策略应用/全域度量/数据工厂）
   - 参考 `business-knowledge` 的站点地图确认归属
   - 加载对应 `business-knowledge/rules/mod-*.md` 获取详细导航结构

3. **提取左侧菜单**：
   - 菜单分组（图标 + 标题），每组可展开/收起（详见对应 `mod-*.md` 的导航结构表）
   - 子菜单项（文字 + 可选 badge）
   - 当前激活的菜单项

4. **提取顶栏右侧**：
   - 工具按钮：code、user-pack、bell、help-circle、setting
   - 账号信息：品牌名-行业 + ID

**输出**：一个"页面框架"模块的设计 Prompt，作为模块 0。

### 阶段 1：模块拆解 + 区块匹配

按视觉区块 + 数据源 + 复用性拆分为独立模块，评估复杂度和执行顺序。

**拆解后必须执行区块匹配**：查询 `block-catalog` 的区块注册表和分类体系，对每个模块判断：

- **复用**：与已有区块完全匹配，直接使用
- **参考**：与已有区块结构相似，在其基础上调整
- **新建**：无可复用区块，用组件从零搭建

**必须包含模块 0（页面框架）**：

```
模块 0: 页面框架（RuyiLayout — 顶栏 + 左侧菜单 + 内容区）          [复用: 如翼页面框架]
模块 1: [筛选/导航区]                                                [参考: 筛选工具栏]
模块 2: [内容区模块 A]                                               [新建]
模块 3: [内容区模块 B]                                               [复用: crowd-card-list]
...
模块 N: 页面容器（组装所有模块 + 状态管理）
```

### 阶段 2：设计 Prompt 生成（核心输出）

**为每个模块输出严格格式的设计 Prompt，精确映射到 One Design Next 组件。**

---

## 设计 Prompt 格式（必须严格遵守）

每个模块的 Prompt 必须包含以下 8 个字段：

```
## 模块：[名称]

### 1. 业务上下文
[一句话描述模块的业务目的]

### 2. 组件树
用缩进表示组件嵌套关系，精确到 variant 和 props：

RuyiLayout(navItems, activeNav, menuItems, activeMenu, accountName, accountId)
├── 顶栏: Logo + 一级导航 + 工具按钮 + 账号信息
├── 左侧菜单: 分组菜单（Collapsible）
└── 内容区 — div(bg-[#f2f5fa])
    └── [各内容模块]

### 3. 图标清单（from one-design-next Icon）
- Icon name="chart" — 菜单图标
- Icon name="bell" — 通知图标
- ...

### 4. 组件约束
列出本模块使用的 one-design-next 组件及关键用法

### 5. Design Token 约束
- 页面背景：bg-[#f2f5fa]
- 内容区块：bg-white rounded-xl
- 激活态文字：text-blue-6 bg-blue-2
- ...

### 6. 状态处理
- normal / loading / empty / error

### 7. 代码结构
- 文件路径
- 组件名
- Props

### 8. 区块引用
标注本模块与已有区块的关系：
- 复用区块：`<slug>` — 直接使用，无需修改
- 参考区块：`<slug>` — 在此基础上调整（列出差异点）
- 新建区块：无可复用区块，从组件层搭建
```

---

## 组件选型指南（用于阶段 2）

写设计 Prompt 时，根据设计需求选择正确的组件。**组件的详细 Props 和用法规范统一参考 `one-design` skill**：

- 完整组件速查表：`one-design` GUIDE.md「组件速查表」
- 组件详细用法：`one-design/rules/*.md`（forms / actions / overlays / data-display / navigation / icons）
- 完整图标列表：`one-design/rules/icons.md`

### 页面框架组件（阶段 0 使用）

如翼页面使用 `RuyiLayout` 组件，它封装了顶栏 + 侧边菜单 + 内容区的完整布局。
详细 Props 见 `one-design/rules/layout.md`。

| 设计需求                 | 选择组件        |
| ------------------------ | --------------- |
| 如翼标准页面（三栏布局） | `RuyiLayout`    |
| 小程序管理页面           | `MpLayout`      |
| 非如翼页面               | 自定义 div 布局 |

### 内容区选型速查

| 设计需求       | 推荐组件                                                            | 详细规范                |
| -------------- | ------------------------------------------------------------------- | ----------------------- |
| 卡片容器       | `Card` + `Card.Header`                                              | `rules/data-display.md` |
| 无边框白色区块 | `div(bg-white rounded-xl)`                                          | —                       |
| 数据表格       | `Table` + `Pagination`                                              | `rules/data-display.md` |
| Tab 切换       | `Tabs.Default` / `.ButtonGroup` / `.Vertical` / `.Divider` / `.Tag` | `rules/navigation.md`   |
| 搜索/筛选      | `Input` + `Select` + `DatePicker`                                   | `rules/forms.md`        |
| 操作按钮       | `Button`                                                            | `rules/actions.md`      |
| 弹窗确认       | `Dialog`                                                            | `rules/overlays.md`     |
| 侧边抽屉       | `Drawer`                                                            | `rules/overlays.md`     |
| 气泡提示       | `Popover` / `Tooltip`                                               | `rules/overlays.md`     |
| 下拉菜单       | `Dropdown`                                                          | `rules/overlays.md`     |
| 图标           | `Icon`                                                              | `rules/icons.md`        |
| 空状态         | `Empty`                                                             | `rules/data-display.md` |
| 加载态         | `Loading`                                                           | `rules/data-display.md` |

---

## 交接协议

阶段 2 完成后，将设计 Prompt 交给 `page-implement` skill（见 frontmatter 中 `next_skill: page-implement`）。

交接时输出以下指令：

```
## 交接给 page-implement skill

mode: [从上游继承的 mode 参数，默认 full]

以上设计 Prompt 已完成，请按以下步骤执行：

1. 确认 RuyiLayout 组件可用（从 one-design-next 导入）
2. 确认使用 one-design-next 组件库
3. 加载 one-design rules 获取组件详细用法（本 skill 的选型指南仅提供方向）
4. 按模块顺序逐个生成代码（从模块 0 页面框架开始）
5. 输出到 `src/workshop/<slug>.tsx` 并注册到 `workshopModules.ts`（见 page-implement Step 5）
6. 每个模块完成后对比设计稿检查
7. 全部模块组装后整体审查
```

---

## 详细参考

- 模块 Prompt 模板：[references/module-templates.md](references/module-templates.md)
- 设计师思维指南：[references/design-thinking.md](references/design-thinking.md)
