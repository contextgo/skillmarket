---
name: ant-design-vue-adapter
description: Ant Design Vue 组件映射与具体用法。当项目配置 ui_library 为 ant-design-vue 时，由本 adapter 填充 domain 层生成的所有 [PLACEHOLDER] 占位。
---

# Ant Design Vue Adapter

> 本文件定义所有 `[PLACEHOLDER]` 的 Ant Design Vue 实现。  
> 与 element-plus.md 结构完全对称，保证 domain 层骨架代码不变，只换 adapter 即可切换 UI 库。

---

## 组件映射总表

| FormItemType     | Ant Design Vue 组件          |
| ---------------- | ---------------------------- |
| `input`          | `<a-input>`                  |
| `textarea`       | `<a-textarea>`               |
| `inputNumber`    | `<a-input-number>`           |
| `select`         | `<a-select>`                 |
| `multiSelect`    | `<a-select mode="multiple">` |
| `radio`          | `<a-radio-group>`            |
| `checkbox`       | `<a-checkbox-group>`         |
| `datePicker`     | `<a-date-picker>`            |
| `dateTimePicker` | `<a-date-picker show-time>`  |
| `dateRange`      | `<a-range-picker>`           |
| `dateTimeRange`  | `<a-range-picker show-time>` |
| `switch`         | `<a-switch>`                 |
| `upload`         | `<a-upload>`                 |

---

## 导入声明

```typescript
import { message, Modal } from "ant-design-vue";
import dayjs from "dayjs";

// 注意：Ant Design Vue 日期组件使用 dayjs 对象
// 与 Element Plus 使用字符串不同，需要在 composable 中做转换
```

---

## 关键差异说明（与 Element Plus 的不同点）

| 场景       | Element Plus             | Ant Design Vue                         |
| ---------- | ------------------------ | -------------------------------------- |
| 日期值格式 | 字符串 `'2024-01-01'`    | dayjs 对象，提交前需 `.format()`       |
| 表单绑定   | `:model="formData"`      | `:model="formData"`（一致）            |
| 表单验证   | `:rules="rules"`         | `:rules="rules"`（一致）               |
| 加载状态   | `v-loading="loading"`    | `:loading="loading"`（在 spin 组件上） |
| 弹窗       | `el-dialog`              | `a-modal`                              |
| 分页       | `el-pagination`          | `a-pagination`                         |
| 消息提示   | `ElMessage.success()`    | `message.success()`                    |
| 确认弹窗   | `ElMessageBox.confirm()` | `Modal.confirm()`                      |
| tag/badge  | `el-tag`                 | `a-tag`                                |

---

## 各占位符的具体实现

### [INPUT_COMPONENT]

```vue
<a-input
  v-model:value="queryForm.{fieldName}"
  placeholder="请输入{fieldLabel}"
  allow-clear
/>
```

> 注意：Ant Design Vue 使用 `v-model:value`，不是 `v-model`

### [TEXTAREA_COMPONENT]

```vue
<a-textarea
  v-model:value="formData.{fieldName}"
  :rows="4"
  placeholder="请输入{fieldLabel}"
  :maxlength="{ maxLength }"
  show-count
/>
```

### [INPUT_NUMBER_COMPONENT]

```vue
<a-input-number
  v-model:value="formData.{fieldName}"
  :min="0"
  :precision="0"
  style="width: 100%"
/>
```

### [SELECT_COMPONENT]

```vue
<a-select
  v-model:value="queryForm.{fieldName}"
  placeholder="请选择{fieldLabel}"
  allow-clear
  style="width: 100%"
  :options="{fieldName}Options"
/>
```

> 注意：Ant Design Vue 的 options 格式为 `{ label, value }`，与 Element Plus 一致，可直接复用。

### [MULTI_SELECT_COMPONENT]

```vue
<a-select
  v-model:value="formData.{fieldName}"
  mode="multiple"
  placeholder="请选择{fieldLabel}"
  allow-clear
  :max-tag-count="2"
  style="width: 100%"
  :options="{fieldName}Options"
/>
```

### [RADIO_COMPONENT]

```vue
<a-radio-group v-model:value="formData.{fieldName}" button-style="solid">
  <a-radio-button
    v-for="item in {fieldName}Options"
    :key="item.value"
    :value="item.value"
  >
    {{ item.label }}
  </a-radio-button>
</a-radio-group>
```

### [DATE_PICKER_COMPONENT]

```vue
<a-date-picker
  v-model:value="queryForm.{fieldName}"
  format="YYYY-MM-DD"
  value-format="YYYY-MM-DD"
  placeholder="请选择{fieldLabel}"
  allow-clear
  style="width: 100%"
/>
```

### [DATETIME_PICKER_COMPONENT]

```vue
<a-date-picker
  v-model:value="formData.{fieldName}"
  show-time
  format="YYYY-MM-DD HH:mm:ss"
  value-format="YYYY-MM-DD HH:mm:ss"
  placeholder="请选择{fieldLabel}"
  allow-clear
  style="width: 100%"
/>
```

### [DATE_RANGE_COMPONENT]（查询区双日历）

```vue
<a-range-picker
  v-model:value="queryForm.{fieldName}Range"
  format="YYYY-MM-DD"
  value-format="YYYY-MM-DD"
  :placeholder="['开始日期', '结束日期']"
  allow-clear
/>
```

> Ant Design Vue 的 range-picker 返回 `[string, string]` 数组（使用 value-format 后）  
> 提交前处理同 Element Plus，拆分为两个字段。

### [SWITCH_COMPONENT]

```vue
<a-switch
  v-model:checked="formData.{fieldName}"
  :checked-value="1"
  :un-checked-value="0"
  checked-children="启用"
  un-checked-children="禁用"
/>
```

---

## 表格相关组件

### [DATA_TABLE] 完整写法

Ant Design Vue 表格使用 `columns` 配置式写法，与 Element Plus slot 写法不同：

```typescript
// 在 script setup 中定义 columns 配置
import type { TableColumnsType } from "ant-design-vue";

const columns: TableColumnsType = [
  {
    title: "#",
    key: "index",
    width: 60,
    align: "center",
    customRender: ({ index }) =>
      (pagination.currentPage - 1) * pagination.pageSize + index + 1,
  },
  // 普通列
  {
    title: "{columnLabel}",
    dataIndex: "{columnName}",
    align: "{align}",
    ellipsis: { showTooltip }, // showTooltip: true 时开启
  },
  // 枚举列
  {
    title: "状态",
    dataIndex: "status",
    align: "center",
    customRender: ({ record }) => {
      const item = STATUS_OPTIONS.find((o) => o.value === record.status);
      return h(
        ATag,
        { color: STATUS_COLOR[record.status] },
        () => item?.label ?? "-"
      );
    },
  },
  // 操作列
  {
    title: "操作",
    key: "action",
    width: 160,
    align: "center",
    fixed: "right",
  },
];
```

```vue
<a-table
  :columns="columns"
  :data-source="tableData"
  :loading="loading"
  :pagination="false"
  :scroll="{ x: 'max-content' }"
  row-key="id"
  bordered
  size="middle"
>
  <template #bodyCell="{ column, record }">
    <template v-if="column.key === 'action'">
      <a-button type="link" @click="handleEdit(record)">编辑</a-button>
      <a-divider type="vertical" />
      <a-button type="link" danger @click="handleDelete(record.id)">删除</a-button>
    </template>
  </template>
</a-table>
```

### [PAGINATION] 写法

```vue
<a-pagination
  v-model:current="pagination.currentPage"
  v-model:page-size="pagination.pageSize"
  :total="pagination.total"
  :page-size-options="['10', '20', '50', '100']"
  show-size-changer
  show-quick-jumper
  show-total="(total) => `共 ${total} 条`"
  @change="handlePageChange"
  @show-size-change="handleSizeChange"
/>
```

---

## 表单容器与弹窗

### [DIALOG_OR_PAGE_WRAPPER]（dialog 模式）

```vue
<a-modal
  :open="visible"
  :title="id ? '编辑{moduleNameCn}' : '新增{moduleNameCn}'"
  width="600px"
  :mask-closable="false"
  :confirm-loading="submitLoading"
  destroy-on-close
  @ok="handleSubmit"
  @cancel="handleCancel"
>
  <!-- 表单内容 -->
</a-modal>
```

### [FORM_COMPONENT] 写法

```vue
<a-form
  ref="formRef"
  :model="formData"
  :rules="rules"
  :label-col="{ span: 6 }"
  :wrapper-col="{ span: 16 }"
>
  <a-row :gutter="16">
    <a-col :span="12">
      <a-form-item label="{fieldLabel}" name="{fieldName}">
        <!-- [具体组件] -->
      </a-form-item>
    </a-col>
    
    <!-- textarea 独占一行 -->
    <a-col :span="24">
      <a-form-item label="{fieldLabel}" name="{fieldName}"
        :label-col="{ span: 3 }" :wrapper-col="{ span: 20 }">
        <!-- [TEXTAREA_COMPONENT] -->
      </a-form-item>
    </a-col>
  </a-row>
</a-form>
```

> Ant Design Vue 表单验证用 `name` 属性，Element Plus 用 `prop` 属性。

---

## 消息提示与确认弹窗

### [SUCCESS_MESSAGE]

```typescript
message.success("操作成功");
```

### [CONFIRM_DELETE]

```typescript
await new Promise<void>((resolve, reject) => {
  Modal.confirm({
    title: "警告",
    content: "确认删除该条数据？删除后不可恢复。",
    okText: "确认删除",
    okType: "danger",
    cancelText: "取消",
    onOk: resolve,
    onCancel: reject,
  });
});
```

---

## 查询区布局

### [SEARCH_FORM] 完整写法

```vue
<a-form layout="inline" :model="queryForm">
  <a-form-item label="{fieldLabel}" name="{fieldName}">
    <!-- [具体组件] -->
  </a-form-item>
  
  <a-form-item>
    <a-space>
      <a-button type="primary" @click="handleSearch">
        <template #icon><SearchOutlined /></template>查询
      </a-button>
      <a-button @click="handleReset">
        <template #icon><ReloadOutlined /></template>重置
      </a-button>
    </a-space>
  </a-form-item>
</a-form>
```

---

## 工具栏

### [TOOLBAR] 写法

```vue
<div class="toolbar">
  <a-button type="primary" @click="handleCreate">
    <template #icon><PlusOutlined /></template>新增
  </a-button>
</div>
```

> 注意：Ant Design Vue 使用 `#icon` slot 方式，图标需从 `@ant-design/icons-vue` 导入

### 图标导入

```typescript
import {
  PlusOutlined,
  SearchOutlined,
  ReloadOutlined,
  EditOutlined,
  DeleteOutlined,
} from "@ant-design/icons-vue";
```

---

## 加载状态

Ant Design Vue 的表格有内置 loading，但整页加载需要使用 `a-spin`：

```vue
<a-spin :spinning="loading">
  <!-- 页面内容 -->
</a-spin>
```

---

## 枚举列辅助函数

```typescript
import { h } from "vue";
import { Tag as ATag } from "ant-design-vue";

const STATUS_COLOR: Record<number, string> = { 1: "green", 0: "red" };
const getStatusLabel = (val: number) =>
  STATUS_OPTIONS.find((o) => o.value === val)?.label ?? "-";
```

---

## [IMPORT_MESSAGE]

```typescript
import { message } from "ant-design-vue";
```

## [IMPORT_CONFIRM]

```typescript
import { Modal } from "ant-design-vue";
```

---

## 列表页样式（写入 {moduleName}-list.vue 的 style 块）

```scss
/* 由 adapter 提供，写入 <style scoped lang="scss"> */
.{moduleName}-list {
  /* 查询区下边距 */
  .ant-form {
    margin-bottom: 12px;
  }

  /* 工具栏 */
  .toolbar {
    display: flex;
    justify-content: flex-end;
    margin-bottom: 12px;
  }

  /* 分页 */
  :deep(.ant-pagination) {
    margin-top: 16px;
    text-align: right;
  }
}
```

---

## [DETAIL_CONTAINER]

```vue
<a-card :bordered="false" class="detail-card">
  <!-- 内容区 -->
</a-card>
```

```scss
/* 写入 {moduleName}-detail.vue 的 style 块 */
.detail-card {
  margin: 16px;
}
```

## [BACK_BUTTON]

```vue
<a-button @click="router.back()">
  <template #icon><ArrowLeftOutlined /></template>返回
</a-button>
```

```typescript
// script setup 中导入
import { ArrowLeftOutlined } from "@ant-design/icons-vue";
```

## [EDIT_BUTTON]

```vue
<a-button type="primary" @click="handleEdit">
  <template #icon><EditOutlined /></template>编辑
</a-button>
```

```typescript
import { EditOutlined } from "@ant-design/icons-vue";
```

## [DESCRIPTIONS_COMPONENT]

```vue
<a-descriptions :column="2" bordered style="margin-top: 16px">
  <a-descriptions-item
    v-for="field in detailFields"
    :key="field.name"
    :label="field.label"
    :span="field.span ?? 1"
  >
    {{ formatDetailValue(field, detail?.[field.name]) }}
  </a-descriptions-item>
</a-descriptions>
```

> `detailFields` 是从 `PageSchema.detailFields` 导入的静态数组（在 script setup 中直接声明），
> `formatDetailValue` 由 `crud-detail.md` 的值格式化函数提供，与本 adapter 无关。
