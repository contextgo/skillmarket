---
name: element-plus-adapter
description: Element Plus 组件映射与具体用法。当项目配置 ui_library 为 element-plus 时，由本 adapter 填充 domain 层生成的所有 [PLACEHOLDER] 占位。
---

# Element Plus Adapter

> 本文件定义所有 `[PLACEHOLDER]` 的 Element Plus 实现。  
> Domain 层生成骨架代码后，读取本文件完成 UI 组件的填充。

---

## 组件映射总表

| FormItemType     | Element Plus 组件                        | 导入方式                     |
| ---------------- | ---------------------------------------- | ---------------------------- |
| `input`          | `<el-input>`                             | 自动全局注册（无需单独导入） |
| `textarea`       | `<el-input type="textarea">`             | —                            |
| `inputNumber`    | `<el-input-number>`                      | —                            |
| `select`         | `<el-select>` + `<el-option>`            | —                            |
| `multiSelect`    | `<el-select multiple>` + `<el-option>`   | —                            |
| `radio`          | `<el-radio-group>` + `<el-radio-button>` | —                            |
| `checkbox`       | `<el-checkbox-group>` + `<el-checkbox>`  | —                            |
| `datePicker`     | `<el-date-picker type="date">`           | —                            |
| `dateTimePicker` | `<el-date-picker type="datetime">`       | —                            |
| `dateRange`      | `<el-date-picker type="daterange">`      | —                            |
| `dateTimeRange`  | `<el-date-picker type="datetimerange">`  | —                            |
| `switch`         | `<el-switch>`                            | —                            |
| `upload`         | `<el-upload>`                            | —                            |

---

## 导入声明（script setup 顶部）

```typescript
// Element Plus 消息/弹窗（需要手动导入）
import { ElMessage, ElMessageBox } from "element-plus";
```

> 其余 el-\* 组件通过 unplugin-vue-components 自动导入，无需手动 import。

---

## 各占位符的具体实现

### [INPUT_COMPONENT]

```vue
<el-input
  v-model="queryForm.{fieldName}"
  placeholder="请输入{fieldLabel}"
  clearable
/>
```

### [TEXTAREA_COMPONENT]

```vue
<el-input
  v-model="formData.{fieldName}"
  type="textarea"
  :rows="4"
  placeholder="请输入{fieldLabel}"
  maxlength="{maxLength}"
  show-word-limit
/>
```

### [INPUT_NUMBER_COMPONENT]

```vue
<el-input-number
  v-model="formData.{fieldName}"
  :min="0"
  :precision="0"
  controls-position="right"
  style="width: 100%"
/>
```

### [SELECT_COMPONENT]（单选）

```vue
<el-select
  v-model="queryForm.{fieldName}"
  placeholder="请选择{fieldLabel}"
  clearable
  style="width: 100%"
>
  <el-option
    v-for="item in {fieldName}Options"
    :key="item.value"
    :label="item.label"
    :value="item.value"
  />
</el-select>
```

> options 数据：若为静态枚举，直接从 `types/{module}.ts` 中导入对应的 `XXX_OPTIONS` 数组；若为动态接口，添加 TODO 注释。

### [MULTI_SELECT_COMPONENT]（多选）

```vue
<el-select
  v-model="formData.{fieldName}"
  placeholder="请选择{fieldLabel}"
  multiple
  collapse-tags
  collapse-tags-tooltip
  clearable
  style="width: 100%"
>
  <el-option
    v-for="item in {fieldName}Options"
    :key="item.value"
    :label="item.label"
    :value="item.value"
  />
</el-select>
```

### [RADIO_COMPONENT]

```vue
<el-radio-group v-model="formData.{fieldName}">
  <el-radio-button
    v-for="item in {fieldName}Options"
    :key="item.value"
    :label="item.value"
  >
    {{ item.label }}
  </el-radio-button>
</el-radio-group>
```

### [DATE_PICKER_COMPONENT]

```vue
<el-date-picker
  v-model="queryForm.{fieldName}"
  type="date"
  placeholder="请选择{fieldLabel}"
  format="YYYY-MM-DD"
  value-format="YYYY-MM-DD"
  clearable
  style="width: 100%"
/>
```

### [DATETIME_PICKER_COMPONENT]

```vue
<el-date-picker
  v-model="formData.{fieldName}"
  type="datetime"
  placeholder="请选择{fieldLabel}"
  format="YYYY-MM-DD HH:mm:ss"
  value-format="YYYY-MM-DD HH:mm:ss"
  clearable
  style="width: 100%"
/>
```

### [DATE_RANGE_COMPONENT]（双日历，用于查询区）

```vue
<el-date-picker
  v-model="queryForm.{fieldName}Range"
  type="daterange"
  range-separator="至"
  start-placeholder="开始日期"
  end-placeholder="结束日期"
  format="YYYY-MM-DD"
  value-format="YYYY-MM-DD"
  clearable
/>
```

> 提交时需在 composable 中拆分：
>
> ```typescript
> const handleSearch = () => {
>   const [startDate, endDate] = queryForm.{fieldName}Range ?? [null, null]
>   // 实际请求参数使用 startDate / endDate
>   fetchList({ ...queryForm, startDate, endDate })
> }
> ```

### [SWITCH_COMPONENT]

```vue
<el-switch
  v-model="formData.{fieldName}"
  :active-value="1"
  :inactive-value="0"
  active-text="启用"
  inactive-text="禁用"
/>
```

---

## 表格相关组件

### [DATA_TABLE] 完整写法

```vue
<el-table
  v-loading="loading"
  :data="tableData"
  border
  stripe
  style="width: 100%"
  @selection-change="handleSelectionChange"
>
  <!-- 序号列 -->
  <el-table-column type="index" label="#" width="60" align="center" />
  
  <!-- 数据列（由 tableColumns 生成）-->
  <el-table-column
    prop="{columnName}"
    label="{columnLabel}"
    align="{align}"
    min-width="{minWidth}"
    :show-overflow-tooltip="{showTooltip}"
  >
    <!-- 枚举列使用 slot -->
    <template v-if="{isEnum}" #default="{ row }">
      <el-tag :type="get{FieldName}TagType(row.{fieldName})">
        {{ get{FieldName}Label(row.{fieldName}) }}
      </el-tag>
    </template>
  </el-table-column>
  
  <!-- 操作列 -->
  <el-table-column label="操作" width="160" align="center" fixed="right">
    <template #default="{ row }">
      <el-button type="primary" link @click="handleEdit(row)">编辑</el-button>
      <el-button type="danger" link @click="handleDelete(row.id)">删除</el-button>
    </template>
  </el-table-column>
</el-table>
```

### [PAGINATION] 写法

```vue
<el-pagination
  v-model:current-page="pagination.currentPage"
  v-model:page-size="pagination.pageSize"
  :total="pagination.total"
  :page-sizes="[10, 20, 50, 100]"
  layout="total, sizes, prev, pager, next, jumper"
  background
  @current-change="handlePageChange"
  @size-change="handleSizeChange"
/>
```

---

## 表单容器与弹窗

### [DIALOG_OR_PAGE_WRAPPER]（dialog 模式）

```vue
<el-dialog
  :model-value="visible"
  :title="id ? '编辑{moduleNameCn}' : '新增{moduleNameCn}'"
  width="600px"
  :close-on-click-modal="false"
  destroy-on-close
  @close="handleCancel"
>
  <!-- 表单内容 -->
  <template #footer>
    <el-button @click="handleCancel">取消</el-button>
    <el-button type="primary" :loading="submitLoading" @click="handleSubmit">
      确定
    </el-button>
  </template>
</el-dialog>
```

### [FORM_COMPONENT] 写法

```vue
<el-form
  ref="formRef"
  :model="formData"
  :rules="rules"
  label-width="auto"
  label-position="right"
>
  <el-row :gutter="16">
    <!-- 表单项 -->
    <el-col :span="12">
      <el-form-item label="{fieldLabel}" prop="{fieldName}">
        <!-- [FORM_ITEM_{fieldName}] -->
      </el-form-item>
    </el-col>
    
    <!-- textarea/upload 独占一行 -->
    <el-col :span="24">
      <el-form-item label="{fieldLabel}" prop="{fieldName}">
        <!-- [TEXTAREA_COMPONENT] -->
      </el-form-item>
    </el-col>
  </el-row>
</el-form>
```

---

## 消息提示与确认弹窗

### [SUCCESS_MESSAGE]

```typescript
ElMessage.success("操作成功");
```

### [CONFIRM_DELETE]

```typescript
await ElMessageBox.confirm("确认删除该条数据？删除后不可恢复。", "警告", {
  confirmButtonText: "确认删除",
  cancelButtonText: "取消",
  type: "warning",
  confirmButtonClass: "el-button--danger",
});
```

---

## 查询区布局

### [SEARCH_FORM] 完整写法

```vue
<el-form ref="queryFormRef" :model="queryForm" inline>
  <el-form-item label="{fieldLabel}" prop="{fieldName}">
    <!-- [具体组件] -->
  </el-form-item>
  
  <!-- 最多4个条件一行，超出折叠 -->
  
  <el-form-item>
    <el-button type="primary" @click="handleSearch">
      <el-icon><Search /></el-icon>查询
    </el-button>
    <el-button @click="handleReset">
      <el-icon><Refresh /></el-icon>重置
    </el-button>
  </el-form-item>
</el-form>
```

---

## 枚举列辅助函数（生成在 script setup 中）

```typescript
// 状态枚举的标签转换（以 status 字段为例）
const STATUS_TAG_TYPE: Record<number, string> = { 1: "success", 0: "danger" };
const getStatusLabel = (val: number) =>
  USER_STATUS_OPTIONS.find((o) => o.value === val)?.label ?? "-";
const getStatusTagType = (val: number) => STATUS_TAG_TYPE[val] ?? "info";
```

---

## 工具栏

### [TOOLBAR] 写法

```vue
<div class="toolbar">
  <el-button type="primary" @click="handleCreate">
    <el-icon><Plus /></el-icon>新增
  </el-button>
  <!-- 扩展按钮占位 -->
  <!-- <el-button @click="handleExport">导出</el-button> -->
</div>
```

---

## 样式补充

```scss
/* 建议在 views/{moduleName}-page/{moduleName}-list.vue 中添加 */
<style scoped lang="scss">
.{moduleName}-list {
  padding: 16px;

  .el-form {
    margin-bottom: 16px;
  }

  .toolbar {
    display: flex;
    justify-content: flex-end;
    margin-bottom: 12px;
  }

  .el-pagination {
    margin-top: 16px;
    justify-content: flex-end;
  }
}
</style>
```

---

## [IMPORT_MESSAGE]

```typescript
import { ElMessage } from "element-plus";
```

## [IMPORT_CONFIRM]

```typescript
import { ElMessageBox } from "element-plus";
```

---

## 列表页样式（写入 {moduleName}-list.vue 的 style 块）

```scss
/* 由 adapter 提供，写入 <style scoped lang="scss"> */
.{moduleName}-list {
  /* 查询区下边距 */
  :deep(.el-form--inline) {
    margin-bottom: 12px;
  }

  /* 工具栏 */
  .toolbar {
    display: flex;
    justify-content: flex-end;
    margin-bottom: 12px;
  }

  /* 分页 */
  :deep(.el-pagination) {
    margin-top: 16px;
    justify-content: flex-end;
  }
}
```

---

## [DETAIL_CONTAINER]

```vue
<el-card shadow="never" class="detail-card">
  <!-- 内容区 -->
</el-card>
```

```scss
/* 写入 {moduleName}-detail.vue 的 style 块 */
.detail-card {
  margin: 16px;
}
```

## [BACK_BUTTON]

```vue
<el-button :icon="ArrowLeft" @click="router.back()">返回</el-button>
```

```typescript
// script setup 中导入
import { ArrowLeft } from "@element-plus/icons-vue";
```

## [EDIT_BUTTON]

```vue
<el-button type="primary" @click="handleEdit">编辑</el-button>
```

## [DESCRIPTIONS_COMPONENT]

```vue
<el-descriptions :column="2" border style="margin-top: 16px">
  <el-descriptions-item
    v-for="field in detailFields"
    :key="field.name"
    :label="field.label"
    :span="field.span ?? 1"
  >
    {{ formatDetailValue(field, detail?.[field.name]) }}
  </el-descriptions-item>
</el-descriptions>
```

> `detailFields` 是从 `PageSchema.detailFields` 导入的静态数组（在 script setup 中直接声明），
> `formatDetailValue` 由 `crud-detail.md` 的值格式化函数提供，与本 adapter 无关。
