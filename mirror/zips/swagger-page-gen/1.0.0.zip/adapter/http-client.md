# HTTP Client (请求适配器规则)

无论使用哪种 UI 框架，生成 API 请求代码时都必须遵循本适配器规范。

## 1. 拦截器抽象与依赖
所有的 API 文件统一引入项目中已配置好的 `request.ts`。
```typescript
// 示例：/src/api/user.ts
import request from '@/utils/request';

// 如果项目中没有 @/utils/request，可退而求其次使用基础的 axios 实例
// import axios from 'axios';
```

## 2. 请求参数处理规则
- **GET 请求 (查询)**: 参数应作为 `params` 传递。
  ```typescript
  export const fetchList = (params: any) => request.get('/api/xxx', { params });
  ```
- **POST/PUT 请求 (提交)**: 参数应作为 `data` (请求体) 传递。
  ```typescript
  export const createItem = (data: any) => request.post('/api/xxx', data);
  export const updateItem = (id: string, data: any) => request.put(`/api/xxx/${id}`, data);
  ```
- **DELETE 请求**:
  ```typescript
  export const deleteItem = (id: string) => request.delete(`/api/xxx/${id}`);
  ```

## 3. 返回类型
- 不要假设全局的 `Result` 泛型包裹（除非项目明确提供了 `types/request.d.ts`）。
- 默认返回 `Promise<any>`，并要求用户在使用时根据实际业务调整。