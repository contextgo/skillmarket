---
name: crud-list
description: 基于 PageSchema 生成列表页的抽象结构和逻辑。与 UI 库无关，输出完整的列表页代码框架，由 adapter 层填充具体组件。
---

# CRUD 列表页模式（Domain Layer）

> 输入：PageSchema（来自 swagger-analyzer 输出）  
> 输出：完整的列表页 .vue 文件 + composable + service + types  
> UI 组件：所有 [PLACEHOLDER] 由对应 adapter 文件中的同名锚点填充

---

## 列表页标准结构

```
列表页 = [SEARCH_FORM] + [TOOLBAR] + [DATA_TABLE] + [PAGINATION] + [FORM_DIALOG]
```

### 完整文件清单

```
src/
├── views/{moduleName}-page/
│   └── {moduleName}-list.vue          # 列表页主文件
├── composables/
│   └── use-{moduleName}-list.ts       # 列表业务逻辑
├── api/
│   └── {moduleName}.ts                # API 函数（增量）
└── types/
    └── {moduleName}.ts                # 类型定义（增量）
```

---

## Adapter 填充点

| 占位标记            | 说明                                 | 在 adapter 中的锚点    |
| ------------------- | ------------------------------------ | ---------------------- |
| `[SEARCH_FORM]`     | 查询表单区域（含查询/重置按钮）      | `## [SEARCH_FORM]`     |
| `[TOOLBAR]`         | 工具栏（新增等操作按钮）             | `## [TOOLBAR]`         |
| `[DATA_TABLE]`      | 数据表格（含序号列、数据列、操作列） | `## [DATA_TABLE]`      |
| `[PAGINATION]`      | 分页组件                             | `## [PAGINATION]`      |
| `[IMPORT_MESSAGE]`  | 消息提示组件的 import 语句           | `## [IMPORT_MESSAGE]`  |
| `[IMPORT_CONFIRM]`  | 确认弹窗组件的 import 语句           | `## [IMPORT_CONFIRM]`  |
| `[CONFIRM_DELETE]`  | 删除前的确认弹窗调用                 | `## [CONFIRM_DELETE]`  |
| `[SUCCESS_MESSAGE]` | 操作成功提示调用                     | `## [SUCCESS_MESSAGE]` |

查询区内各字段的组件占位（input/select/dateRange 等）同样由 adapter 对应锚点填充，
具体映射见 `crud-form.md` 中的「FormItemType → 占位标记对照」。

---

## 生成规则

### 1. 查询区（Search Form）

- 遍历 `PageSchema.searchFields`，按顺序渲染表单项
- 每行最多 **4** 个查询条件（超出部分折叠）
- 最后一个位置放【查询】【重置】按钮
- `dateRange` 类型占 **2** 格宽度

**queryForm 初始值规则：**

| 字段类型            | 初始值                                     |
| ------------------- | ------------------------------------------ |
| string              | `''`                                       |
| enum（select 类型） | `null`                                     |
| integer/number      | `null`                                     |
| dateRange           | `[null, null]`（提交时拆分为两个独立参数） |

### 2. 工具栏（Toolbar）

- `meta.createApi` 存在 → 生成【新增】按钮（primary 类型）
- 批量删除、导出等扩展按钮：不默认生成，添加注释占位

**位置**：查询区下方、表格上方，右对齐

### 3. 数据表格（Table）

**列渲染规则：**

| 列特征                     | 处理方式                                |
| -------------------------- | --------------------------------------- |
| `isShow: false`            | 跳过，不渲染                            |
| `isEnum: true`             | 渲染为 tag/badge，用 options 转换 label |
| `isDate: true`             | 格式化显示，格式来自 `dateFormat`       |
| `showTooltip: true`        | 开启内容溢出气泡                        |
| `dataType: integer/number` | align 居中                              |

**固定列：**

- 第一列：序号列（宽 60px，值 = `(currentPage-1) × pageSize + index + 1`）
- 最后列：操作列（固定右侧）

**操作列按钮：**

```
meta.updateApi 存在          → 【编辑】按钮（打开 form 弹窗）
meta.deleteApi 存在          → 【删除】按钮（danger，需确认）
meta.detailApi 存在 或 有详情页 → 【详情】按钮
```

### 4. 分页（Pagination）

固定配置（由 adapter 的 `[PAGINATION]` 锚点渲染）：

```
pageSizes: [10, 20, 50, 100]
默认 pageSize: 20
显示：总条数 + 每页条数选择 + 页码 + 跳转
```

---

## 完整骨架

### `{moduleName}-list.vue`

```vue
<template>
  <div class="list-container">
    <!-- [SEARCH_FORM] -->

    <!-- [TOOLBAR] -->

    <!-- [DATA_TABLE] -->

    <!-- [PAGINATION] -->

    <!-- 表单弹窗（有增删改接口时生成）-->
    <{ModuleNamePascal}Form v-model:visible="formVisible" :id="currentEditId"
    @success="handleFormSuccess" />
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
// [IMPORT_MESSAGE] — 见 adapter 同名锚点
// [IMPORT_CONFIRM] — 见 adapter 同名锚点
import { use{ModuleNamePascal}List } from '@/composables/use-{moduleName}-list'
import {ModuleNamePascal}Form from './{moduleName}-form.vue'
import type { {ModuleNamePascal}ListItem } from '@/types/{moduleName}'

const {
  loading,
  tableData,
  pagination,
  queryForm,
  queryFormRef,
  handleSearch,
  handleReset,
  handlePageChange,
  handleSizeChange,
  handleDelete,
} = use{ModuleNamePascal}List()

const formVisible = ref(false)
const currentEditId = ref<number | null>(null)

const handleCreate = () => {
  currentEditId.value = null
  formVisible.value = true
}

const handleEdit = (row: {ModuleNamePascal}ListItem) => {
  currentEditId.value = row.id
  formVisible.value = true
}

const handleFormSuccess = () => {
  formVisible.value = false
  handleSearch()
}
</script>

<style scoped lang="scss">
.list-container {
  padding: 16px;
  background-color: #ffffff;
  border-radius: 8px;
}
</style>
```

> 注意：`<style>` 块中**只写与模块名相关的容器样式**，不出现任何 UI 库类名（`.el-form`、`.el-pagination` 等）。
> 内部组件的样式间距由 adapter 的各锚点负责。

### `use-{moduleName}-list.ts`

```typescript
import { ref, reactive, onMounted } from 'vue'
// [IMPORT_MESSAGE] — 见 adapter 同名锚点
// [IMPORT_CONFIRM] — 见 adapter 同名锚点
import {
  get{ModuleNamePascal}List,
  delete{ModuleNamePascal},
} from '@/api/{moduleName}'
import type { {ModuleNamePascal}ListItem, {ModuleNamePascal}Query } from '@/types/{moduleName}'

export function use{ModuleNamePascal}List() {
  const loading = ref(false)
  const tableData = ref<{ModuleNamePascal}ListItem[]>([])
  const queryFormRef = ref()

  const pagination = reactive({
    currentPage: 1,
    pageSize: 20,
    total: 0,
  })

  // [QUERY_FORM_INIT] — 由 swagger-analyzer 根据 searchFields 生成字段和初始值
  const queryForm = reactive<{ModuleNamePascal}Query>({})

  const fetchList = async () => {
    loading.value = true
    try {
      const res = await get{ModuleNamePascal}List({
        ...queryForm,
        currentPage: pagination.currentPage,
        pageSize: pagination.pageSize,
      })
      // response_unwrapped: true  → res 直接是 PageResult，用 res.list / res.totalCount
      // response_unwrapped: false → res 是 ApiResponse<PageResult>，用 res.data.list / res.data.totalCount
      // 根据 .page-gen.yml 中 request.response_unwrapped 配置决定
      tableData.value = res.list ?? []
      pagination.total = res.totalCount ?? 0
    } catch (e) {
      console.error(e)
    } finally {
      loading.value = false
    }
  }

  const handleSearch = () => {
    pagination.currentPage = 1
    fetchList()
  }

  const handleReset = () => {
    queryFormRef.value?.resetFields()
    handleSearch()
  }

  const handlePageChange = (page: number) => {
    pagination.currentPage = page
    fetchList()
  }

  const handleSizeChange = (size: number) => {
    pagination.pageSize = size
    pagination.currentPage = 1
    fetchList()
  }

  const handleDelete = async (id: number) => {
    // [CONFIRM_DELETE] — 见 adapter 同名锚点（await 确认后再删除）
    await delete{ModuleNamePascal}(id)
    // [SUCCESS_MESSAGE] — 见 adapter 同名锚点
    fetchList()
  }

  onMounted(fetchList)

  return {
    loading,
    tableData,
    pagination,
    queryForm,
    queryFormRef,
    handleSearch,
    handleReset,
    handlePageChange,
    handleSizeChange,
    handleDelete,
  }
}
```

---

## 注意事项

- 所有 `// [PLACEHOLDER]` 处的内容由 adapter 提供，**骨架代码中禁止出现任何 UI 组件名**
- dateRange 字段提交前须拆分为两个独立参数，处理逻辑在 `handleSearch` 内
- 删除操作必须经过 `[CONFIRM_DELETE]` 确认，不可直接调用删除接口
- `<style scoped>` 中**禁止写** `.el-*`、`.a-*` 等 UI 库类名
