---
name: swagger-analyzer
description: 解析 Swagger/OpenAPI JSON，提取接口信息，推断字段类型和表单组件，输出标准 PageSchema。这是所有页面生成任务的第一步。
---

# Swagger Analyzer（Domain Layer）

> 职责：将 Swagger 原始数据转换为标准 PageSchema。  
> 输出的 PageSchema 必须完全符合 `foundation/page-schema.md` 中定义的结构。

---

## 执行步骤

```
Step 1: 接收输入
Step 2: 识别目标接口
Step 3: 提取字段信息
Step 4: 推断字段类型和表单组件
Step 5: 识别接口组合（list/create/update/delete/detail）
Step 6: 构造 PageSchema
Step 7: 输出确认摘要，等待用户确认
```

---

## Step 1 — 接收输入

支持以下输入格式：

**格式A：完整 swagger JSON**
```json
{
  "swagger": "2.0",
  "paths": { ... },
  "definitions": { ... }
}
```

**格式B：OpenAPI 3.0 JSON**
```json
{
  "openapi": "3.0.0",
  "paths": { ... },
  "components": { "schemas": { ... } }
}
```

**格式C：单个路径片段（用户只粘贴部分）**
```json
{
  "/api/user/list": {
    "get": { "parameters": [...], "responses": {...} }
  }
}
```

**格式D：用户自然语言描述**（当无法提供JSON时）
```
接口：GET /api/user/list
字段：username(用户名), email(邮箱), status(状态:1启用0禁用), createdAt(创建时间)
```

---

## Step 2 — 识别目标接口

从路径中识别 CRUD 接口组合。识别规则：

| 接口特征 | 判断为 |
|---------|-------|
| 包含 `list`、`page`、`query` 或 GET 且返回数组 | listApi |
| POST 且路径不含 ID 占位符 | createApi |
| PUT / PATCH | updateApi |
| DELETE | deleteApi |
| GET 且路径含 `/{id}` 或 `/detail` | detailApi |

**同 tag 下的接口自动关联**，如用户提供列表接口，自动在同 tag 下查找对应的增删改接口。

---

## Step 3 — 字段提取

### 从 swagger parameters 提取查询字段（searchFields）

```
parameters（in: query）→ searchFields
parameters（in: body / requestBody）→ formFields（新增/编辑）
responses[200].schema / content 中的 list[] 的属性 → tableColumns + detailFields
```

### 字段信息提取清单

对每个字段提取：
- `name`：字段名，原样保留
- `label`：优先使用 `description`，其次使用字段名转中文（见下方规则）
- `dataType`：来自 swagger `type` 字段
- `required`：来自 `required` 数组或字段的 `required` 属性
- `enum`：若有 `enum` 数组，提取为 options

### 字段名转中文规则（无 description 时的 fallback）

| 字段名模式 | 推断中文 |
|-----------|---------|
| `id` | ID |
| `name` / `title` | 名称 |
| `username` / `userName` | 用户名 |
| `email` | 邮箱 |
| `phone` / `mobile` | 手机号 |
| `status` | 状态 |
| `type` | 类型 |
| `remark` / `desc` / `description` | 备注 |
| `createdAt` / `createTime` / `gmtCreate` | 创建时间 |
| `updatedAt` / `updateTime` | 更新时间 |
| `sort` / `order` | 排序 |
| `code` | 编码 |
| `address` | 地址 |
| **无法推断** | 保留英文字段名，生成后提示用户补充 |

---

## Step 4 — 字段类型与表单组件推断

### DataType 推断规则

| Swagger type | 字段名特征 | 推断 DataType |
|-------------|-----------|--------------|
| `integer` / `number` | — | `integer` / `number` |
| `boolean` | — | `boolean` |
| `string` | 含 `date`（不含time）| `date` |
| `string` | 含 `datetime`、`time`、`At` | `datetime` |
| `string` | 有 `enum` 数组 | `enum` |
| `array` | — | `array` |
| `string` | 其他 | `string` |

### FormItemType 推断规则

| DataType | 字段名特征 | 推断 FormItemType |
|---------|-----------|------------------|
| `string` | 含 `remark`、`desc`、`content`、`detail` | `textarea` |
| `string` | 无特殊特征 | `input` |
| `integer` / `number` | — | `inputNumber` |
| `boolean` | — | `switch` |
| `enum` | 选项 ≤ 4 个 | `radio`（表单）/ `select`（查询） |
| `enum` | 选项 > 4 个 | `select` |
| `array` | 有枚举选项 | `checkbox`（表单）/ `multiSelect`（查询） |
| `date` | — | `datePicker` |
| `datetime` | — | `dateTimePicker` |
| `string` | 含 `image`、`avatar`、`logo`、`file`、`attachment` | `upload` |

### 双日历复合组件识别规则

当同时存在以下两个字段时，自动识别为 dateRange：

```
匹配模式（不区分大小写）：
- start/begin/from + end/to 前缀或后缀
- 例如：startDate + endDate，beginTime + endTime，dateFrom + dateTo

识别后：
- 两个字段合并为一个 dateRange 类型的 searchField
- isStart: true 标记起始字段
- partnerField 指向对应字段名
- 实际提交时，拆开为两个独立参数
```

---

## Step 5 — 接口组合识别

自动在同 swagger tag 下查找配套接口，填充 PageSchema.meta：

```
listApi    → 必须找到，否则中止并提示用户
createApi  → 尝试查找，找不到则置 null（列表页仍可生成，但无新增按钮）
updateApi  → 尝试查找
deleteApi  → 尝试查找
detailApi  → 尝试查找（找不到则详情页使用列表数据回显）
```

---

## Step 6 — 构造 PageSchema

按照 `foundation/page-schema.md` 中定义的结构组装，注意：

- `moduleName`：从 tag 或路径第一段推断，转为 kebab-case
- `tableColumns` 的 `align`：数字类型居中，其他居左
- `tableColumns` 的 `showTooltip`：string 类型默认 true，其他 false
- 分页参数（pageSize、currentPage、pageNum 等）**不进入** searchFields

---

## Step 7 — 输出确认摘要

构造完 PageSchema 后，**不要直接开始生成代码**，先输出确认摘要：

```markdown
## 📋 解析结果确认

**模块**：用户管理（user）

**识别到的接口：**
- ✅ 列表：GET /api/user/list
- ✅ 新增：POST /api/user/create
- ✅ 编辑：PUT /api/user/update  
- ✅ 删除：DELETE /api/user/{id}
- ❌ 详情：未找到（将用列表数据回显）

**查询字段（5个）：**
| 字段 | 中文 | 类型 | 组件 |
|------|------|------|------|
| username | 用户名 | string | input |
| status | 状态 | enum | select |
| startDate~endDate | 创建时间 | dateRange | dateRange |

**表格列（6列）：**
| 字段 | 中文 | 对齐 |
|------|------|------|
| id | ID | 居中 |
| username | 用户名 | 居左 |
| ... | ... | ... |

**表单字段（3个，新增/编辑）：**
| 字段 | 中文 | 必填 | 组件 |
|------|------|------|------|
| username | 用户名 | ✅ | input |
| email | 邮箱 | ✅ | input |
| roleId | 角色 | ✅ | select |

**需要您确认：**
1. `roleId` 的选项数据来源？（接口还是本地枚举）
2. `status` 的枚举值：1=启用, 0=禁用，是否正确？

确认后输入"开始生成"，或直接修改上述信息。
```

---

## 异常处理

| 情况 | 处理方式 |
|------|---------|
| swagger 格式无法解析 | 提示用户检查格式，提供支持的格式示例 |
| 找不到列表接口 | 中止，请用户明确指定哪个接口是列表接口 |
| 字段无法推断中文 | 保留英文，在确认摘要中标红提示补充 |
| 接口参数中有嵌套对象 | 展开一层，嵌套超过两层提示用户手动处理 |
| 同名字段在 query 和 body 中都有 | searchFields 和 formFields 各保留一份 |
