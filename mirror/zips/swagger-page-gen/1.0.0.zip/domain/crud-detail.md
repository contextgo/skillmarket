---
name: crud-detail
description: 基于 PageSchema 生成详情页。渲染为描述列表（只读）形式，支持 1列/2列布局。
---

# CRUD 详情页模式（Domain Layer）

> 输入：PageSchema.detailFields  
> 输出：详情页 .vue（只读展示，无编辑功能）  
> UI 组件：所有 [PLACEHOLDER] 由对应 adapter 文件中的同名锚点填充

---

## 详情页结构

```
详情页 = [DETAIL_CONTAINER 开始] + [BACK_BUTTON] + [DESCRIPTIONS_COMPONENT] + [DETAIL_CONTAINER 结束]
```

---

## 渲染规则

- 遍历 `PageSchema.detailFields`，按 `span` 决定占 1 格还是 2 格
- 默认 2 列布局（每行两个字段）
- `span: 2` 的字段独占一行
- enum 类型：显示 label 而非 value（通过 formatDetailValue 处理）
- date/datetime 类型：格式化显示（通过 formatDetailValue 处理）
- 空值显示 `—`

---

## Adapter 填充点

| 占位标记                   | 说明                            | 在 adapter 中的锚点           |
| -------------------------- | ------------------------------- | ----------------------------- |
| `[DETAIL_CONTAINER]`       | 卡片容器（el-card / a-card）    | `## [DETAIL_CONTAINER]`       |
| `[BACK_BUTTON]`            | 返回上一页按钮                  | `## [BACK_BUTTON]`            |
| `[EDIT_BUTTON]`            | 编辑按钮（有 updateApi 时生成） | `## [EDIT_BUTTON]`            |
| `[DESCRIPTIONS_COMPONENT]` | 描述列表，遍历 detailFields     | `## [DESCRIPTIONS_COMPONENT]` |

具体写法见对应 adapter 文件中同名锚点。

---

## 完整骨架

### `{moduleName}-detail.vue`

```vue
<template>
  <!-- [DETAIL_CONTAINER] -->
  <div class="detail-container">
    <div class="detail-header">
      <!-- [BACK_BUTTON] -->
      <!-- [EDIT_BUTTON]（仅当 meta.updateApi 存在时生成）-->
    </div>

    <!-- [DESCRIPTIONS_COMPONENT] -->
  </div>

  <!-- [/DETAIL_CONTAINER] -->
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { get{ModuleNamePascal}Detail } from '@/api/{moduleName}'
import type { {ModuleNamePascal}ListItem } from '@/types/{moduleName}'


const route = useRoute()
const router = useRouter()
const loading = ref(false)
const detail = ref<{ModuleNamePascal}ListItem | null>(null)

const fetchDetail = async () => {
  const id = Number(route.params.id)
  if (!id) return
  loading.value = true
  try {
    // response_unwrapped: true  → detail.value = res
    // response_unwrapped: false → detail.value = res.data
    // 根据 .page-gen.yml 中 request.response_unwrapped 配置决定
    const res = await get{ModuleNamePascal}Detail(id)
    detail.value = res
  } finally {
    loading.value = false
  }
}

onMounted(fetchDetail)
</script>

<style scoped lang="scss">
.detail-container {
  padding: 16px;
  background-color: #ffffff;
  border-radius: 8px;
  .detail-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 16px;
  }
}
</style>
```

---

## 值格式化函数（domain 层，与 UI 库无关，两个 adapter 共用）

以下函数直接写入 `<script setup>`，不属于任何 UI 库，不需要从 adapter 填充：

```typescript
const formatDetailValue = (field: any, value: unknown): string => {
  if (value === null || value === undefined || value === "") return "—";
  if (field.isEnum && field.options) {
    return field.options.find((o) => o.value === value)?.label ?? String(value);
  }
  return String(value);
};
```
