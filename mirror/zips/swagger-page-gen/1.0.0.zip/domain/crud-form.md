---
name: crud-form
description: 基于 PageSchema 生成新增/编辑表单页（弹窗或整页）。支持新增、编辑共用一个组件，由 id 是否存在区分模式。
---

# CRUD 表单页模式（Domain Layer）

> 输入：PageSchema  
> 输出：表单组件（默认为弹窗，可切换为整页）  
> UI 组件：所有 [PLACEHOLDER] 由对应 adapter 文件中的同名锚点填充

---

## 表单组件模式

| 模式     | 场景                  | 默认 |
| -------- | --------------------- | ---- |
| `dialog` | 新增/编辑在弹窗中完成 | ✅   |
| `page`   | 新增/编辑跳转独立页面 | —    |

弹窗模式（dialog）是默认模式，在 workflow 中用户可指定。

---

## 生成的文件清单

```
src/
├── views/{moduleName}-page/
│   └── {moduleName}-form.vue      # 表单组件（弹窗 or 整页）
└── composables/
    └── use-{moduleName}-form.ts   # 表单业务逻辑
```

---

## Adapter 填充点

| 占位标记                      | 说明                                           | 在 adapter 中的锚点              |
| ----------------------------- | ---------------------------------------------- | -------------------------------- |
| `[DIALOG_OR_PAGE_WRAPPER]`    | 弹窗容器（dialog 模式）或页面容器（page 模式） | `## [DIALOG_OR_PAGE_WRAPPER]`    |
| `[FORM_COMPONENT]`            | 表单容器及 el-row/a-row 布局                   | `## [FORM_COMPONENT]`            |
| `[INPUT_COMPONENT]`           | 单行文本输入框                                 | `## [INPUT_COMPONENT]`           |
| `[TEXTAREA_COMPONENT]`        | 多行文本（独占一行）                           | `## [TEXTAREA_COMPONENT]`        |
| `[INPUT_NUMBER_COMPONENT]`    | 数字输入框                                     | `## [INPUT_NUMBER_COMPONENT]`    |
| `[SELECT_COMPONENT]`          | 下拉单选                                       | `## [SELECT_COMPONENT]`          |
| `[MULTI_SELECT_COMPONENT]`    | 下拉多选                                       | `## [MULTI_SELECT_COMPONENT]`    |
| `[RADIO_COMPONENT]`           | 单选框组                                       | `## [RADIO_COMPONENT]`           |
| `[CHECKBOX_COMPONENT]`        | 多选框组                                       | `## [CHECKBOX_COMPONENT]`        |
| `[DATE_PICKER_COMPONENT]`     | 日期选择器                                     | `## [DATE_PICKER_COMPONENT]`     |
| `[DATETIME_PICKER_COMPONENT]` | 日期时间选择器                                 | `## [DATETIME_PICKER_COMPONENT]` |
| `[DATE_RANGE_COMPONENT]`      | 日期范围（双日历）                             | `## [DATE_RANGE_COMPONENT]`      |
| `[SWITCH_COMPONENT]`          | 开关                                           | `## [SWITCH_COMPONENT]`          |
| `[UPLOAD_COMPONENT]`          | 文件上传（独占一行）                           | `## [UPLOAD_COMPONENT]`          |
| `[SUCCESS_MESSAGE]`           | 提交成功提示                                   | `## [SUCCESS_MESSAGE]`           |
| `[IMPORT_MESSAGE]`            | 消息组件的 import 语句                         | `## [IMPORT_MESSAGE]`            |

具体写法见对应 adapter 文件中同名锚点。

---

## 表单渲染规则

### 字段布局

- 默认一行 **2** 列
- `textarea`、`upload` 类型独占一行（span=24）
- `dateRange` 独占一行
- 表单项顺序与 `PageSchema.formFields` 顺序一致

### FormItemType → 占位标记对照

```
'input'          → [INPUT_COMPONENT]
'textarea'       → [TEXTAREA_COMPONENT]（独占一行）
'inputNumber'    → [INPUT_NUMBER_COMPONENT]
'select'         → [SELECT_COMPONENT]（options 来自 field.options）
'multiSelect'    → [MULTI_SELECT_COMPONENT]
'radio'          → [RADIO_COMPONENT]
'checkbox'       → [CHECKBOX_COMPONENT]
'datePicker'     → [DATE_PICKER_COMPONENT]
'dateTimePicker' → [DATETIME_PICKER_COMPONENT]
'dateRange'      → [DATE_RANGE_COMPONENT]（独占一行，提交时拆分）
'switch'         → [SWITCH_COMPONENT]
'upload'         → [UPLOAD_COMPONENT]（独占一行）
```

### 表单验证规则生成（domain 逻辑，与 UI 库无关）

基于 `field.validation` 自动生成，写入 composable 的 `rules` 对象：

```typescript
const rules = {
  username: [
    { required: true, message: "请输入用户名", trigger: "blur" },
    { min: 2, max: 20, message: "长度在 2 到 20 个字符", trigger: "blur" },
  ],
  email: [
    { required: true, message: "请输入邮箱", trigger: "blur" },
    { type: "email", message: "请输入正确的邮箱格式", trigger: "blur" },
  ],
  roleId: [{ required: true, message: "请选择角色", trigger: "change" }],
};
```

**特殊 pattern 映射：**

| pattern     | 生成规则                                                      |
| ----------- | ------------------------------------------------------------- |
| `'email'`   | `{ type: 'email' }`                                           |
| `'phone'`   | `{ pattern: /^1[3-9]\d{9}$/, message: '请输入正确的手机号' }` |
| `'url'`     | `{ type: 'url' }`                                             |
| `'integer'` | `{ type: 'integer', message: '请输入整数' }`                  |

> 注意：Element Plus 表单验证用 `prop` 属性绑定字段名，Ant Design Vue 用 `name` 属性。
> 这一差异由 adapter 中的 `[FORM_COMPONENT]` 锚点处理，rules 对象本身两者通用。

---

## 完整骨架

### `{moduleName}-form.vue`

```vue
<template>
  <!-- [DIALOG_OR_PAGE_WRAPPER] -->
  <div class="form-container">
    <!-- [FORM_COMPONENT] 开始 -->

    <!-- 遍历 PageSchema.formFields，按 formItemType 插入对应占位 -->
    <!-- 示例（username 字段，formItemType: 'input'）：-->
    <!-- 表单项容器由 adapter [FORM_COMPONENT] 提供，内部插入具体组件 -->
    <!-- [INPUT_COMPONENT] for username -->
    <!-- [SELECT_COMPONENT] for roleId -->
    <!-- [TEXTAREA_COMPONENT] for remark（独占一行）-->
    <!-- ...其余字段同理 -->

    <!-- [FORM_COMPONENT] 结束 -->
  </div>

  <!-- [/DIALOG_OR_PAGE_WRAPPER] -->
</template>

<script setup lang="ts">
// [IMPORT_MESSAGE] — 见 adapter 同名锚点
import { use{ModuleNamePascal}Form } from '@/composables/use-{moduleName}-form'

const props = defineProps<{
  id?: number | null
  visible: boolean
}>()

const emit = defineEmits<{
  (e: 'success'): void
  (e: 'update:visible', val: boolean): void
}>()

const {
  formRef,
  formData,
  rules,
  loading,
  submitLoading,
  handleSubmit,
  handleCancel,
} = use{ModuleNamePascal}Form(props, emit)
</script>
```

### `use-{moduleName}-form.ts`

```typescript
import { ref, reactive, watch } from 'vue'
// [IMPORT_MESSAGE] — 见 adapter 同名锚点
import {
  get{ModuleNamePascal}Detail,
  create{ModuleNamePascal},
  update{ModuleNamePascal},
} from '@/api/{moduleName}'
import type { {ModuleNamePascal}FormData } from '@/types/{moduleName}'

export function use{ModuleNamePascal}Form(props: any, emit: any) {
  const formRef = ref()
  const loading = ref(false)
  const submitLoading = ref(false)

  // 由 PageSchema.formFields 生成初始值：
  // string        → ''
  // number/integer → null
  // boolean       → false
  // array         → []
  const formData = reactive<{ModuleNamePascal}FormData>({
    // [FORM_DATA_INIT]
  })

  // 验证规则（domain 层生成，与 UI 库无关）
  const rules = {
    // [VALIDATION_RULES] — 由 swagger-analyzer 根据 field.validation 生成
  }

  const resetForm = () => {
    formRef.value?.resetFields()
    Object.assign(formData, {
      // 重置为上方 formData 的初始值
    })
  }

  // 编辑模式：watch id 变化自动回填
  watch(
    () => props.id,
    async (id) => {
      if (!props.visible) return
      if (id) {
        loading.value = true
        try {
          const res = await get{ModuleNamePascal}Detail(id)
          // response_unwrapped: true  → Object.assign(formData, res)
          // response_unwrapped: false → Object.assign(formData, res.data)
          // 根据 .page-gen.yml 中 request.response_unwrapped 配置决定
          Object.assign(formData, res)
        } finally {
          loading.value = false
        }
      } else {
        resetForm()
      }
    },
    { immediate: true }
  )

  // 弹窗关闭时重置
  watch(
    () => props.visible,
    (val) => { if (!val) resetForm() }
  )

  const handleSubmit = async () => {
    await formRef.value?.validate()
    submitLoading.value = true
    try {
      if (props.id) {
        await update{ModuleNamePascal}(props.id, formData)
      } else {
        await create{ModuleNamePascal}(formData)
      }
      // [SUCCESS_MESSAGE] — 见 adapter 同名锚点
      emit('success')
    } catch (e) {
      console.error(e)
    } finally {
      submitLoading.value = false
    }
  }

  const handleCancel = () => {
    emit('update:visible', false)
  }

  return {
    formRef,
    formData,
    rules,
    loading,
    submitLoading,
    handleSubmit,
    handleCancel,
  }
}

<style scoped lang="scss">
.form-container {
  padding: 16px;
  background-color: #ffffff;
  border-radius: 8px;
}
</style>
```

---

## 联动逻辑处理

若表单中字段存在联动（一个字段变化影响另一个字段的选项），无法从 Swagger 自动推断，生成占位注释并在确认摘要中提示用户：

```typescript
// TODO: 联动处理 — provinceId 变化时清空并重新加载 cityId 选项
// watch(() => formData.provinceId, (val) => {
//   formData.cityId = null
//   if (val) loadCityOptions(val)
// })
```
