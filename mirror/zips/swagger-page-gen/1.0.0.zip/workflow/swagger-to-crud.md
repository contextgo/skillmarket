---
name: swagger-to-crud
description: 主工作流：从 Swagger 接口一键生成完整 CRUD 页面套件（视图/composable/service/types/路由片段）。当用户说"根据swagger生成"、"生成完整的CRUD"、"生成列表页+表单页"时，使用此工作流。自动编排所有子 skill，用户只需确认一次 PageSchema 即可完成全部生成。
---

# Swagger to CRUD — 主工作流

> 本工作流是整个技能体系的**总调度器**。  
> 它按正确顺序调用各层 skill，将用户从"提供 swagger"带到"得到完整代码"。

---

## 执行前准备

在开始任何生成前，**必须**按顺序完成以下步骤：

```
☐ 1. 读取 foundation/page-schema.md          — 了解 PageSchema 结构
☐ 2. 读取 foundation/coding-conventions.md   — 了解编码规范
☐ 3. 读取 foundation/api-contract.md         — 了解 API 层规范
☐ 4. 读取项目根目录 .page-gen.yml            — 获取项目原始配置
☐ 5. 执行 foundation/config-validator.md     — 校验配置，生成 .page-gen.lock.yml
☐ 6. 根据 lock 文件 verified.tech.ui_library  — 加载对应 adapter
```

> **步骤 5 必须在步骤 4 之后、步骤 6 之前执行。**  
> 步骤 6 起的所有配置，**统一读取 `.page-gen.lock.yml` 的 `verified` 节**，  
> 不再直接引用 `.page-gen.yml` 中的任何值。

---

## 工作流执行顺序

```
Phase 0: 配置校验（新增）
  └── config-validator → 输出 .page-gen.lock.yml + 校验摘要

Phase 1: 解析
  └── swagger-analyzer → 输出 PageSchema（草稿）

Phase 2: 用户确认
  └── 输出确认摘要 → 等待用户确认或修改

Phase 3: 并行生成（基于 lock 文件配置）
  ├── types/{module}.ts
  ├── api/{module}.ts
  ├── composables/use-{module}-list.ts
  ├── composables/use-{module}-form.ts
  ├── views/{module}-page/{module}-list.vue
  ├── views/{module}-page/{module}-form.vue
  └── views/{module}-page/{module}-detail.vue（可选）

Phase 4: 路由片段
  └── 输出路由配置片段（不直接写入，由用户手动或 incremental-update 处理）

Phase 5: 完成报告 + QA 质量检查 + 配置同步建议
  └── 文件清单 + QA 报告 + 是否同步配置询问
```

---

## Phase 0 — 配置校验阶段（必须优先执行）

调用 `foundation/config-validator.md` 完整流程：

1. 检查 `.page-gen.lock.yml` 是否存在且指纹有效

   - 有效 → 告知用户跳过校验，直接使用 lock 文件
   - 无效或不存在 → 执行完整校验流程

2. 扫描项目实际（package.json、src/ 目录结构、request 封装文件）

3. 与 `.page-gen.yml` 逐项 diff，分级处理：

   - 🔴 阻断级 → **停止，展示冲突，等待用户确认**
   - 🟡 警告级 → 自动采用实际值，汇总展示
   - 🟢 静默级 → 自动处理，写入日志

4. 落盘 `.page-gen.lock.yml`

5. 输出校验摘要后，等待用户输入 swagger 内容，继续 Phase 1

---

## Phase 1 — 解析阶段

调用 `domain/swagger-analyzer.md` 的逻辑处理用户提供的 swagger 数据。

**触发方式：**

```
用户提供的内容可以是：
A. swagger JSON（完整文档或单个路径）
B. swagger URL（如 http://xxx/v2/api-docs）
C. 自然语言描述的接口
```

若用户提供 URL，先提示：

```
请确认 swagger JSON 可以直接访问（无需登录），或将 JSON 内容直接粘贴给我。
```

---

## Phase 2 — 确认阶段

输出 PageSchema 确认摘要（格式见 `domain/swagger-analyzer.md` Step 7）。

**等待用户输入，支持以下操作：**

| 用户输入                   | 处理方式                       |
| -------------------------- | ------------------------------ |
| "确认" / "ok" / "开始生成" | 进入 Phase 3                   |
| 修改某个字段的中文标签     | 更新 PageSchema 后重新显示摘要 |
| "不需要详情页"             | 从生成列表中移除 detail        |
| "表单用整页，不用弹窗"     | 修改 formMode 为 'page'        |
| "只生成列表页"             | 仅生成 list 相关文件           |
| 添加某字段的 options       | 更新对应 field.options         |

**常见需要用户补充的信息：**

1. 动态枚举字段的选项来源（接口 or 本地常量）
2. upload 字段的上传接口地址
3. 外键关联字段的选项接口
4. 字段验证规则（min/max/pattern）

---

## Phase 3 — 代码生成阶段

> **本阶段所有路径、函数名、组件来源，必须来自 `.page-gen.lock.yml` 的 `verified` 节，不得直接读取 `.page-gen.yml`。**

按以下顺序生成文件，**每个文件生成后立即输出**，不要等全部完成再显示：

### 文件 1：类型定义

调用规则：基于 PageSchema 生成，参考 `foundation/coding-conventions.md` 中的类型规范。

```typescript
// src/types/{moduleName}.ts  ← 路径来自 lock.verified.paths.types
// 生成内容：
// - {ModuleNamePascal}ListItem  （来自 tableColumns）
// - {ModuleNamePascal}Query     （来自 searchFields）
// - {ModuleNamePascal}FormData  （来自 formFields）
// - {ModuleNamePascal}Detail    （来自 detailFields，如有）
// - 枚举 OPTIONS 数组            （来自所有 enum 类型字段）
```

### 文件 2：API Service

调用规则：基于 PageSchema.meta 中的接口定义，参考 `foundation/api-contract.md`。

```typescript
// src/api/{moduleName}.ts  ← 路径来自 lock.verified.paths.api
// import 路径来自 lock.verified.paths.request
// 函数名来自 lock.verified.request.method_names
// 生成：list / create / update / delete / detail 函数
```

### 文件 3：列表 Composable

调用规则：`domain/crud-list.md` 的 composable 骨架 + 对应 adapter 的消息/确认组件。

```typescript
// src/composables/use-{moduleName}-list.ts  ← 路径来自 lock.verified.paths.composables
```

### 文件 4：表单 Composable

调用规则：`domain/crud-form.md` 的 composable 骨架。

```typescript
// src/composables/use-{moduleName}-form.ts  ← 路径来自 lock.verified.paths.composables
```

### 文件 5：列表页视图

调用规则：`domain/crud-list.md` 的 .vue 骨架 + 对应 adapter 填充所有 UI 组件。

```vue
<!-- src/views/{moduleName}-page/{moduleName}-list.vue  ← 路径来自 lock.verified.paths.views -->
<!-- UI 组件来自 lock.verified.tech.ui_library 对应的 adapter -->
```

### 文件 6：表单弹窗视图

```vue
<!-- src/views/{moduleName}-page/{moduleName}-form.vue -->
```

### 文件 7：详情页视图（如 PageSchema 包含 detailFields）

```vue
<!-- src/views/{moduleName}-page/{moduleName}-detail.vue -->
```

---

## Phase 4 — 路由片段

生成路由配置，**不直接写入文件**，以代码块形式输出供用户手动添加，或调用 `incremental-update` 自动合并：

```typescript
// 路由配置片段（添加到 lock.verified.paths.router 对应文件）
{
  path: '/{moduleName}',
  component: Layout,
  name: '{ModuleNamePascal}Menu',   // ← 后缀来自 lock.verified.router.level1_suffix
  meta: {
    title: '{moduleNameCn}管理',
    icon: '',
  },
  children: [
    {
      path: 'list',
      component: () => import('@/views/{moduleName}-page/{moduleName}-list.vue'),
      name: '{ModuleNamePascal}PageList',  // ← 后缀来自 lock.verified.router.level2_suffix
      meta: { title: '{moduleNameCn}列表' },
    },
  ],
}
```

---

## Phase 5 — 完成报告 + QA + 配置同步建议

### 5.1 生成完成报告

```markdown
## ✅ 生成完成

### 已生成文件（共 N 个）

| 文件                              | 状态    |
| --------------------------------- | ------- |
| src/types/user.ts                 | ✅ 新建 |
| src/api/user.ts                   | ✅ 新建 |
| src/composables/use-user-list.ts  | ✅ 新建 |
| src/composables/use-user-form.ts  | ✅ 新建 |
| src/views/user-page/user-list.vue | ✅ 新建 |
| src/views/user-page/user-form.vue | ✅ 新建 |

### ⚠️ 需要手动处理

1. **路由** — 将上方路由片段添加到 `src/router/index.ts`
2. **roleId 选项** — `user-form.vue` 中角色下拉框的 options 需要接口加载，已留 TODO 注释
3. **权限码** — 路由的 `meta.code` 需要根据实际权限系统填写
```

### 5.2 QA 质量检查（基于 .page-gen.lock.yml）

代码生成完成后，以 `.page-gen.lock.yml` 的 `verified` 节为唯一依据，执行以下检查：

**检查项：**

| 检查项      | 校验规则                                                       |
| ----------- | -------------------------------------------------------------- |
| Import 路径 | 所有 import 路径必须与 `verified.paths.*` 一致                 |
| 请求函数名  | 必须使用 `verified.request.method_names` 中定义的函数名        |
| 导出方式    | 与 `verified.request.export_style` 一致（named/default）       |
| 响应处理    | `response_unwrapped: true` 时返回类型不含包装层                |
| UI 组件来源 | 所有 UI 组件 import 必须来自 `verified.tech.ui_library` 对应包 |
| 文件命名    | 符合 `verified.codegen.page_suffix` 和 `dir_suffix`            |
| 目录存在性  | 引用 `path_existence` 中为 false 的路径时，标注警告            |

**QA 报告输出格式（追加在完成报告后）：**

```markdown
### 🔍 QA 质量检查（基于 .page-gen.lock.yml）

| 检查项         | 结果                                              |
| -------------- | ------------------------------------------------- |
| Import 路径    | ✅ 全部与 lock 文件一致                           |
| 请求函数名     | ✅ 使用 get/post/put/del，符合配置                |
| 响应处理方式   | ✅ response_unwrapped=true，返回类型正确          |
| UI 组件来源    | ✅ 全部来自 element-plus                          |
| 文件路径规范   | ✅ 符合 paths.\* 配置                             |
| 目标目录存在性 | ⚠️ src/composables 目录尚未创建，请手动创建后运行 |
```

### 5.3 配置同步建议

若 `.page-gen.lock.yml` 的 `diff_log.warning_conflicts` 不为空，追加询问：

```markdown
### 📋 配置文件同步建议

.page-gen.lock.yml 与 .page-gen.yml 存在差异，建议更新配置文件以保持一致：

· request.method*names.delete：del → delete*

[输入"同步配置"自动更新 .page-gen.yml | 输入"跳过"保留原配置]
```

### 5.4 下一步提示

```markdown
### 下一步

- 输入"自动合并路由"可调用 incremental-update 工作流
- 输入"生成详情页"可单独补充详情页
- 输入"生成 xxx 模块"继续生成下一个模块
```

---

## 错误处理与回退

| 错误情况                         | 处理方式                                     |
| -------------------------------- | -------------------------------------------- |
| .page-gen.yml 不存在             | 提示用户创建配置文件，提供模板，终止流程     |
| 配置校验发现阻断级冲突           | 停在 Phase 0，等用户确认后再继续             |
| swagger 无法解析                 | 停在 Phase 1，请用户检查格式                 |
| 某个文件已存在且 overwrite=false | 跳过该文件，在报告中标注                     |
| 字段类型无法推断                 | 默认为 input，在 TODO 中标注                 |
| 接口超过 30 个字段               | 提示用户确认是否全部纳入，建议按使用频率筛选 |

---

## 使用示例

### 最简使用

```
用户：请根据以下接口生成用户管理的CRUD页面

{swagger JSON 内容}
```

### 指定选项

```
用户：根据下面的 swagger 生成用户管理页面，表单用整页而不是弹窗，不需要详情页

{swagger JSON}
```

### 分模块批量生成

```
用户：这是整个 swagger 文档，请生成"用户管理"和"角色管理"两个模块

{完整 swagger JSON}
```

> 批量时，每个模块独立走一遍完整 workflow，分别确认，分别生成。不要把多个模块混在一个 PageSchema 中。
