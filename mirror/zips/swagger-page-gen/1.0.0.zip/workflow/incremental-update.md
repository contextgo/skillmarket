---
name: incremental-update
description: 增量更新工作流：将生成的路由片段合并到现有路由文件，将新增 API 函数追加到现有 service 文件，避免覆盖手动修改的代码。当用户说"自动合并路由"、"更新路由文件"、"追加API"时使用。
---

# 增量更新工作流（Workflow Layer）

> 职责：在不破坏现有代码的前提下，将新生成的内容合并到已有文件。  
> 这是替代原项目"路由合并"和"API 增量更新"功能的 AI 版本。

---

## 路由文件增量合并

### 分析现有路由文件

读取 `.page-gen.yml` 中的 `paths.router`，分析现有路由文件结构：

```typescript
// 识别以下内容：
// 1. 一级路由列表（已有哪些一级路由）
// 2. 各一级路由下的子路由列表
// 3. 路由文件的导入方式（动态 import 还是静态）
// 4. 路由数组的插入位置（append 还是按字母序）
```

### 合并规则

| 情况                                  | 处理方式                                                  |
| ------------------------------------- | --------------------------------------------------------- |
| 同名一级路由已存在                    | 仅在其 children 中追加新的子路由                          |
| 同名子路由已存在                      | **跳过**，不覆盖，在报告中标注                            |
| 一级路由不存在                        | 在路由数组末尾追加完整的路由对象                          |
| 路由文件包含 router.group_by_tag=true | 生成子路由文件（`src/router/{tag}.ts`），并在主路由中引入 |

### 合并示例

**现有路由文件片段：**

```typescript
const routes: RouteRecordRaw[] = [
  {
    path: "/system",
    name: "SystemMenu",
    component: Layout,
    children: [
      {
        path: "user",
        name: "SystemPageUser",
        component: () => import("@/views/user-page/user-list.vue"),
      },
    ],
  },
];
```

**新生成的路由片段（角色管理）：**

```typescript
{
  path: 'role',
  name: 'SystemPageRole',
  component: () => import('@/views/role-page/role-list.vue'),
  meta: { title: '角色管理' }
}
```

**合并结果：**

```typescript
const routes: RouteRecordRaw[] = [
  {
    path: "/system",
    name: "SystemMenu",
    component: Layout,
    children: [
      {
        path: "user",
        name: "SystemPageUser",
        component: () => import("@/views/user-page/user-list.vue"),
      },
      // ↓ 新增 — 由 incremental-update 追加
      {
        path: "role",
        name: "SystemPageRole",
        component: () => import("@/views/role-page/role-list.vue"),
        meta: { title: "角色管理" },
      },
    ],
  },
];
```

---

## Service 文件增量追加

### 分析现有 service 文件

```typescript
// 1. 提取已有的函数名列表
// 2. 识别最后一个函数的结束位置（追加点）
// 3. 检查现有导入（避免重复导入类型）
```

### 追加规则

- **同名函数存在** → 跳过，报告中标注 `⚠️ 已跳过：getUserList 函数已存在`
- **新函数** → 追加到文件末尾，带 JSDoc 注释
- **类型导入** → 检查是否已导入，避免重复

### 追加示例

**现有 `src/api/user.ts`：**

```typescript
import request from "@/utils/request";
import type { UserListItem, UserQuery } from "@/types/user";

export function getUserList(params: UserQuery) {
  return request.get("/api/user/list", { params });
}
```

**需要追加：**

```typescript
// 新增：createUser、updateUser、deleteUser
```

**追加后：**

```typescript
import request from "@/utils/request";
import type { UserListItem, UserQuery, UserFormData } from "@/types/user"; // ← 类型导入更新

export function getUserList(params: UserQuery) {
  return request.get("/api/user/list", { params });
}

// ↓ 以下由 incremental-update 追加 ——————————————
/**
 * 创建用户
 */
export function createUser(data: UserFormData) {
  return request.post("/api/user/create", data);
}

/**
 * 更新用户
 */
export function updateUser(id: number, data: UserFormData) {
  return request.put(`/api/user/${id}`, data);
}

/**
 * 删除用户
 */
export function deleteUser(id: number) {
  return request.delete(`/api/user/${id}`);
}
```

---

## 输出报告

```markdown
## 🔄 增量更新完成

### 路由合并

- ✅ `/system` 一级路由已存在，在其 children 中追加了 `role` 子路由
- ⚠️ `/system/user` 子路由已存在，已跳过

### Service 追加（src/api/user.ts）

- ✅ 追加 createUser
- ✅ 追加 updateUser
- ✅ 追加 deleteUser
- ⚠️ getUserList 已存在，已跳过

### 类型更新（src/types/user.ts）

- ✅ 追加 UserFormData 接口
- ⚠️ UserListItem 已存在，已跳过
```
