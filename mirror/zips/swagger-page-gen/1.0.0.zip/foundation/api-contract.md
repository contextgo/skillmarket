---
name: api-contract
description: API 服务层封装规范。定义 service 文件结构、请求函数写法、响应类型处理。所有生成的 service 文件必须遵守本规范。生成前必须读取 .page-gen.yml 中的 request 配置块。
---

# API 契约规范（Foundation Layer）

> 生成任何 service 文件前，**必须先读取** `.page-gen.yml` 中的 `request` 配置块，  
> 根据 `response_unwrapped`、`export_style`、`method_names` 决定生成代码的形态。

---

## 1. 响应解包模式（最关键配置）

### 模式 A：`response_unwrapped: true`（推荐，拦截器已剥离包装体）

拦截器在响应成功时已自动执行 `return res.data`，service 层拿到的**直接是业务数据**，
无需再 `.data` 取值。

```typescript
// service 函数 —— 返回类型直接写业务类型
export const getUserList = (params: UserListQuery) =>
  get<PageResult<UserListItem>>("/api/user/list", params);

// composable 中使用 —— 直接解构，无包装层
const res = await getUserList(params);
tableData.value = res.list; // ✅ 直接是 PageResult<UserListItem>
total.value = res.total;
```

**类型辅助（src/types/common.ts）：**

```typescript
// 分页结果（业务数据层，不含 code/message 包装）
export interface PageResult<T = unknown> {
  list: T[];
  total: number;
  currentPage?: number;
  pageSize?: number;
}

// 操作类接口的返回（新增/编辑/删除，data 通常为 null 或 id）
export type ActionResult = null | number | string;
```

---

### 模式 B：`response_unwrapped: false`（拦截器未处理，返回完整包装体）

service 层拿到的是 `{ code, message, data }`，composable 中需要 `.data` 取值。

```typescript
// service 函数 —— 返回类型需包含包装层
export const getUserList = (params: UserListQuery) =>
  get<ApiResponse<PageResult<UserListItem>>>("/api/user/list", params);

// composable 中使用
const res = await getUserList(params);
tableData.value = res.data.list; // ✅ 需要 .data 才能拿到业务数据
total.value = res.data.total;
```

**类型辅助（src/types/common.ts）：**

```typescript
export interface ApiResponse<T = unknown> {
  code: number;
  message: string;
  data: T;
}

export interface PageResult<T = unknown> {
  list: T[];
  total: number;
}
```

---

## 2. 请求函数导出方式

根据 `.page-gen.yml` 中的 `export_style` 决定 import 写法：

### `export_style: named`（具名导出，如本项目）

```typescript
// 导入
import { get, post, put, del } from "@/utils/request";

// 使用（注意：method_names.delete 配置为 del）
export const getUserList = (params: UserListQuery) =>
  get<PageResult<UserListItem>>("/api/user/list", params);

export const createUser = (data: UserFormData) =>
  post<ActionResult>("/api/user/create", data);

export const updateUser = (id: number, data: UserFormData) =>
  put<ActionResult>(`/api/user/${id}`, data);

export const deleteUser = (id: number) => del<ActionResult>(`/api/user/${id}`);
```

### `export_style: default`（默认导出）

```typescript
// 导入
import request from "@/utils/request";

// 使用
export const getUserList = (params: UserListQuery) =>
  request.get<PageResult<UserListItem>>("/api/user/list", { params });

export const createUser = (data: UserFormData) =>
  request.post<ActionResult>("/api/user/create", data);
```

---

## 3. 特殊场景配置项透传

当接口需要覆盖拦截器默认行为时，通过第三个 config 参数透传。  
**以下配置项的字段名来自 `.page-gen.yml` 中的对应配置，若为 null 则不生成相关代码。**

### 获取完整响应体（showAllRes）

> 适用场景：需要读取 `code` 或 `message` 字段，而不只是 `data`

```typescript
// response_unwrapped: true 时，默认拿到的是 data
// 若某个接口需要完整的 { code, message, data }，透传 showAllRes: true
export const getUserListWithMeta = (params: UserListQuery) =>
  get<ApiResponse<PageResult<UserListItem>>>(
    "/api/user/list",
    params,
    { showAllRes: true } // ← showAllRes 来自配置 show_all_res_option
  );
```

### 完全绕过拦截器（returnRaw）

> 适用场景：文件下载、需要读取响应头等特殊接口

```typescript
export const downloadUserExport = (params: UserListQuery) =>
  get<Blob>(
    "/api/user/export",
    params,
    { returnRaw: true, responseType: "blob" } // ← returnRaw 来自配置 return_raw_option
  );
```

### 静默错误（hideGlobalMsg）

> 适用场景：后台轮询、不希望弹出全局错误提示的接口

```typescript
export const checkTaskStatus = (taskId: string) =>
  get<TaskStatus>(
    `/api/task/${taskId}/status`,
    {},
    { hideGlobalMsg: true } // ← hideGlobalMsg 来自配置 hide_global_msg_option
  );
```

---

## 4. 完整 Service 文件示例

以用户模块为例，`response_unwrapped: true` + `export_style: named`：

```typescript
// src/api/user.ts
import { get, post, put, del } from "@/utils/request";
import type { PageResult, ActionResult } from "@/types/common";
import type { UserListItem, UserListQuery, UserFormData } from "@/types/user";

/**
 * 获取用户列表
 */
export const getUserList = (
  params: UserListQuery & { currentPage: number; pageSize: number }
) => get<PageResult<UserListItem>>("/api/user/list", params);

/**
 * 获取用户详情
 */
export const getUserDetail = (id: number) =>
  get<UserListItem>(`/api/user/${id}`);

/**
 * 创建用户
 */
export const createUser = (data: UserFormData) =>
  post<ActionResult>("/api/user/create", data);

/**
 * 更新用户
 */
export const updateUser = (id: number, data: UserFormData) =>
  put<ActionResult>(`/api/user/${id}`, data);

/**
 * 删除用户
 */
export const deleteUser = (id: number) => del<ActionResult>(`/api/user/${id}`);
```

---

## 5. Composable 中的调用方式

根据 `response_unwrapped` 决定取值方式，**生成 composable 时必须对应**：

```typescript
// response_unwrapped: true ——— 直接取业务数据
const fetchList = async () => {
  loading.value = true;
  try {
    const res = await getUserList({ ...queryForm, ...pagination });
    tableData.value = res.list ?? []; // ✅ res 就是 PageResult<UserListItem>
    pagination.total = res.total ?? 0;
  } finally {
    loading.value = false;
  }
};

// response_unwrapped: false ——— 需要 .data 取值
const fetchList = async () => {
  loading.value = true;
  try {
    const res = await getUserList({ ...queryForm, ...pagination });
    tableData.value = res.data.list ?? []; // ✅ res 是 ApiResponse<PageResult<...>>
    pagination.total = res.data.total ?? 0;
  } finally {
    loading.value = false;
  }
};
```

---

## 6. 生成规则

生成 service 文件时，按以下顺序决策：

1. 读取 `.page-gen.yml` → `request` 配置块
2. 根据 `export_style` 决定 import 语句
3. 根据 `method_names` 决定函数调用名（`get`/`post`/`put`/`del` 或其他）
4. 根据 `response_unwrapped` 决定返回类型泛型（直接业务类型 or 包一层 ApiResponse）
5. 从 PageSchema.meta 中读取所有 `*Api` 字段，逐一生成函数
6. 每个函数上方必须有 JSDoc（接口描述来自 swagger desc）

**增量更新规则：**

- 同名函数已存在 → **跳过**，报告中标注
- 新函数 → 追加到文件末尾
- 文件不存在 → 创建新文件
