---
name: config-validator
description: 配置文件校验模块。在读取 .page-gen.yml 后、代码生成前必须执行。负责扫描项目实际情况、与配置进行分级 diff、生成 .page-gen.lock.yml 落盘文件，作为后续代码生成和 QA 质量检查的可信依据。
---

# Config Validator — 配置校验与落盘

> 职责：以项目实际为 Ground Truth，校验 `.page-gen.yml` 配置的准确性，  
> 将校验结论落盘到 `.page-gen.lock.yml`，供代码生成和 QA 全程引用。

---

## 执行时机

在 `workflow/swagger-to-crud.md` 的执行前准备阶段，读取 `.page-gen.yml` 后**立即执行**本模块，所有代码生成步骤均使用 `.page-gen.lock.yml` 而非原始配置。

---

## Step 0 — 检查 .page-gen.yml 是否存在

.page-gen.yml 存在 → 进入 Step 1（指纹校验）

.page-gen.yml 不存在 → 执行"首次配置引导"流程：

1. 扫描项目实际（同 Step 2 逻辑）
2. 预填可自动确定的字段
3. 向用户询问无法自动确定的字段（至少 response_unwrapped）
4. 写入 .page-gen.yml
5. 直接写入 .page-gen.lock.yml（标记 diff_log 为空，全部字段来自扫描）
6. 告知用户两个文件均已生成，继续流程

## Step 1 — 检查 .page-gen.lock.yml 是否有效

读取 `.page-gen.lock.yml`（如存在），校验其中的项目指纹：

```
指纹计算来源：
  - package.json 内容 hash（SHA-256）
  - package.json 文件修改时间（mtime）
  - src/ 目录一级结构 hash（各子目录名列表排序后 hash）
```

**判断逻辑：**

```
lock 文件不存在
  → 走完整校验流程（Step 2 开始）

lock 文件存在，重新计算当前指纹：
  ├─ 指纹完全一致
  │     → ✅ 跳过校验，直接使用 lock 文件
  │        告知用户："使用已验证的项目快照，跳过配置校验。"
  │
  ├─ 仅 mtime 变化，内容 hash 不变
  │     → 更新 lock 文件中的 mtime，其余不变，跳过校验
  │
  ├─ 少量文件变化（src/ 结构未变，仅 package.json hash 变）
  │     → 增量校验：仅重新校验 tech / request 相关字段
  │        更新 lock 文件对应字段和指纹
  │
  └─ 结构性变化（src/ 目录结构 hash 变化）
        → 走完整校验流程（Step 2 开始）
```

---

## Step 2 — 独立扫描项目实际（Ground Truth）

**在读取 `.page-gen.yml` 内容之前，先独立完成以下扫描，避免配置污染判断基准。**

### 2.1 扫描 package.json

提取以下信息作为 Ground Truth：

```
- vue 版本（dependencies 或 devDependencies）
- typescript 是否存在（devDependencies）
- UI 库：检测 element-plus / ant-design-vue / naive-ui 等
- axios 版本
- vite / webpack 构建工具
```

### 2.2 扫描 src/ 目录实际结构

检测以下路径是否实际存在：

```
src/views/        ← paths.views
src/api/          ← paths.api
src/router/       ← paths.router 父目录
src/composables/  ← paths.composables
src/types/        ← paths.types
src/utils/        ← paths.request 父目录
```

对于 `paths.router` 和 `paths.request`，检测具体文件是否存在：

```
paths.router  → 检测配置值对应文件是否存在（如 src/router/index.ts）
paths.request → 检测配置值对应文件是否存在（如 src/utils/request.ts 或 .js）
```

### 2.3 扫描 request 封装文件（如路径存在）

读取 `paths.request` 指向的文件，分析：

```
- 导出方式：是 named export（export function get...）还是 default export（export default ...）
- 实际导出的函数名（get/post/put/del/delete 等）
- 是否有 response_unwrapped 相关的拦截器逻辑（res.data 返回模式）
```

---

## Step 3 — 与 .page-gen.yml 逐项对比，分级分类

读取 `.page-gen.yml` 后，逐项与 Step 2 的 Ground Truth 对比，按以下规则分级：

### 🔴 阻断级（Blocking）

**必须停止，等待用户确认后才能继续。**

| 冲突项                 | 判断条件                                              |
| ---------------------- | ----------------------------------------------------- |
| `tech.ui_library`      | 配置的 UI 库在 package.json 中完全不存在              |
| `paths.request`        | 配置路径对应的文件不存在（无法 import）               |
| `paths.router`         | 配置路径对应的文件不存在                              |
| `tech.vue_version`     | 配置为 3，但实际检测到 Vue 2                          |
| `request.export_style` | 配置为 named，但实际文件只有 default export（或反之） |

**阻断时的输出格式：**

```
🔴 发现阻断级配置冲突，无法继续生成，请先确认：

  1. [ui_library] 配置值：ant-design-vue
               实际情况：package.json 中未找到 ant-design-vue
               建议处置：确认实际使用的 UI 库并更新配置

  2. [paths.request] 配置值：src/utils/request
                   实际情况：src/utils/request.ts 和 src/utils/request.js 均不存在
                   建议处置：确认 request 封装文件的实际路径

请修正 .page-gen.yml 后回复"继续"，或告知实际情况由我协助修正。
```

### 🟡 警告级（Warning）

**自动采用 Ground Truth 继续，但明确告知用户。**

| 冲突项                              | 判断条件                                       |
| ----------------------------------- | ---------------------------------------------- |
| `request.method_names`              | 配置的函数名（如 del）与实际导出名不符         |
| `paths.views/api/composables/types` | 配置路径不存在，但父目录存在（可能是尚未创建） |
| `tech.language`                     | 配置为 typescript，但未检测到 tsconfig.json    |
| `request.response_unwrapped`        | 与拦截器逻辑分析不符                           |

**警告时的输出格式（汇总展示，不阻断）：**

```
🟡 发现 2 处配置偏差，已自动采用项目实际值，建议更新 .page-gen.yml：

  1. [request.method_names.delete] 配置值：del
                                  实际导出：delete_
                                  已采用：delete_

  2. [request.response_unwrapped]  配置值：true
                                  实际分析：拦截器未检测到明确的 res.data 返回
                                  已采用：false（保守处理）
```

### 🟢 静默级（Info）

**自动处理，仅写入 lock 文件日志，不向用户展示。**

| 冲突项                    | 判断条件            |
| ------------------------- | ------------------- |
| 配置中存在冗余字段        | lock 文件中忽略即可 |
| 路径末尾多余的 `/`        | 自动标准化          |
| `codegen.author` 为默认值 | 保留，不影响生成    |

---

## Step 4 — 生成并落盘 .page-gen.lock.yml

完成 diff 后，将以下内容写入项目根目录 `.page-gen.lock.yml`：

```yaml
# .page-gen.lock.yml
# ⚠️ 此文件由 AI 自动生成，请勿手动编辑
# 它是 .page-gen.yml 经过项目实际校验后的可信快照
# 代码生成和 QA 质量检查均以此文件为准

_meta:
  generated_at: "2026-04-25T10:30:00+09:00"
  generator: "swagger-page-gen / config-validator"
  source_config: ".page-gen.yml"

  # 项目指纹（用于判断 lock 是否仍然有效）
  project_fingerprint:
    package_json_hash: "sha256:a3f9c2d1..." # package.json 内容 hash
    package_json_mtime: "2026-04-20T08:12:00Z" # package.json 修改时间
    src_structure_hash: "sha256:b7e2a1f4..." # src/ 一级目录结构 hash

# ── 校验结论（代码生成使用此节，忽略原始配置）─────────────────────────────

verified:
  project:
    name: my-admin
    root: /path/to/project

  tech:
    ui_library: element-plus # ✅ 与 package.json 一致
    vue_version: 3 # ✅ 一致
    language: typescript # ✅ 一致
    request_lib: axios # ✅ 一致

  paths:
    views: src/views
    api: src/api
    router: src/router/index.ts
    composables: src/composables
    types: src/types
    request: src/utils/request

  request:
    response_unwrapped: true
    export_style: named
    method_names:
      get: get
      post: post
      put: put
      delete: del
    show_all_res_option: showAllRes
    return_raw_option: returnRaw
    hide_global_msg_option: hideGlobalMsg

  codegen:
    author: your-name
    overwrite_view: true
    overwrite_api: false
    page_suffix:
      list: -list
      form: -form
      detail: -detail
    dir_suffix: -page

  pagination:
    exclude_params:
      - pageSize
      - currentPage
      - pageNum

  router:
    group_by_tag: true
    level1_suffix: Menu
    level2_suffix: Page

# ── Diff 记录（供用户审查，建议同步修正 .page-gen.yml）────────────────────

diff_log:
  validated_at: "2026-04-25T10:30:00+09:00"
  blocking_conflicts: [] # 🔴 阻断级（需用户确认才能继续）
  warning_conflicts: # 🟡 警告级（已自动采用实际值）
    - field: "request.method_names.delete"
      config_value: "del"
      actual_value: "delete_"
      resolution: "adopted_actual"
      suggestion: "将 .page-gen.yml 中 method_names.delete 改为 delete_"
  info_conflicts: [] # 🟢 静默级（自动处理，无需关注）

# ── 已验证的路径存在性（QA 使用）──────────────────────────────────────────

path_existence:
  src/views: true
  src/api: true
  src/router/index.ts: true
  src/composables: true
  src/types: true
  src/utils/request.ts: true
```

---

## Step 5 — 向用户展示校验摘要

校验完成后（无阻断级冲突的情况下），输出简洁摘要：

```
✅ 配置校验完成，已生成 .page-gen.lock.yml

  项目：my-admin  |  Vue 3 + TypeScript + Element Plus
  校验结果：1 处警告（已自动修正），0 处阻断冲突

  ⚠️ 建议更新 .page-gen.yml：
     · request.method_names.delete：del → delete_

  后续代码生成和 QA 检查将以 .page-gen.lock.yml 为准。
  继续？[直接输入 swagger 即可]
```

---

## Step 6 — 任务结束后询问是否同步回配置

在 `workflow/swagger-to-crud.md` 的 Phase 5 完成报告末尾追加：

```
📋 配置文件同步建议

  .page-gen.lock.yml 与 .page-gen.yml 存在 1 处差异。
  是否将校验结果同步回 .page-gen.yml？

  差异内容：
  · request.method_names.delete：del → delete_

  [输入"同步配置"自动更新 | 输入"保留原配置"跳过]
```

---

## QA 质量检查使用说明

代码生成完成后，QA 检查阶段**以 `.page-gen.lock.yml` 的 `verified` 节为唯一可信依据**，具体检查点：

### 基于 lock 文件的强制校验项

```
1. Import 路径校验
   ─ request 导入路径必须与 verified.paths.request 一致
   ─ 类型导入路径必须与 verified.paths.types 一致

2. 请求函数调用校验
   ─ 使用的函数名必须在 verified.request.method_names 中存在
   ─ export_style 为 named 时，不允许出现 request.get() 调用方式

3. 响应处理校验
   ─ response_unwrapped: true 时，service 函数返回类型应直接为业务类型，不含 code/message/data 包装

4. UI 组件来源校验
   ─ 所有 UI 组件 import 必须来自 verified.tech.ui_library 对应的包

5. 路径规范校验
   ─ 生成文件路径必须与 verified.paths.* 对应目录一致
   ─ 文件命名后缀必须符合 verified.codegen.page_suffix / dir_suffix

6. 路径存在性校验
   ─ 引用 path_existence 中 false 的路径时，标注 ⚠️ 目标目录尚未创建
```

### QA 报告输出格式

在 Phase 5 完成报告后追加：

```markdown
### 🔍 QA 质量检查（基于 .page-gen.lock.yml）

| 检查项         | 结果                                        |
| -------------- | ------------------------------------------- |
| Import 路径    | ✅ 全部与 lock 文件一致                     |
| 请求函数名     | ✅ 使用 get/post/put/del，符合配置          |
| 响应处理方式   | ✅ response_unwrapped=true，返回类型正确    |
| UI 组件来源    | ✅ 全部来自 element-plus                    |
| 文件路径规范   | ✅ 符合 paths.\* 配置                       |
| 目标目录存在性 | ⚠️ src/composables 目录尚未创建，请手动创建 |
```
