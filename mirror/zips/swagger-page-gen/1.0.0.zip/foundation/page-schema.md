---
name: page-schema
description: PageSchema 数据契约定义。这是各层之间通信的唯一接口标准。swagger-analyzer 负责输出 PageSchema，crud-list/crud-form/crud-detail 负责消费它。
---

# PageSchema — 层间数据契约

> PageSchema 是本技能体系的核心数据结构。  
> **Domain 层**（swagger-analyzer）输出它，**Domain 页面层**和 **Adapter 层**消费它。  
> 每次生成任务开始前，必须先在内部构造出完整的 PageSchema，再进行代码生成。

---

## 完整 PageSchema 结构

```typescript
interface PageSchema {
  // ── 元信息 ──────────────────────────────────────────────
  meta: {
    moduleName: string; // 模块名（kebab-case），例：'user', 'order-item'
    moduleNamePascal: string; // 模块名（PascalCase），例：'User', 'OrderItem'
    moduleNameCn: string; // 模块中文名，例：'用户', '订单明细'

    listApi: ApiDef; // 列表接口
    createApi?: ApiDef; // 新增接口（可选）
    updateApi?: ApiDef; // 编辑接口（可选）
    deleteApi?: ApiDef; // 删除接口（可选）
    detailApi?: ApiDef; // 详情接口（可选）

    tag: string; // swagger tag，用于路由分组
    author: string; // 来自 .page-gen.yml
  };

  // ── 字段定义 ────────────────────────────────────────────
  searchFields: FieldDef[]; // 列表页查询条件区字段
  tableColumns: ColumnDef[]; // 列表页表格列
  formFields: FieldDef[]; // 新增/编辑表单字段
  detailFields: DetailFieldDef[]; // 详情页展示字段

  // ── 项目配置（来自 .page-gen.yml）──────────────────────
  projectConfig: ProjectConfig;
}

// ── 接口定义 ─────────────────────────────────────────────
interface ApiDef {
  name: string; // 函数名（camelCase），例：'getUserList'
  method: "get" | "post" | "put" | "delete";
  uri: string; // 接口路径，例：'/api/user/list'
  desc: string; // 接口描述
  tag: string; // swagger 分组 tag
}

// ── 字段定义（用于 searchFields 和 formFields）──────────
interface FieldDef {
  name: string; // 字段名（camelCase），例：'userName'
  label: string; // 中文标签，例：'用户名'
  labelDesc?: string; // 字段详细描述（来自 swagger description）

  dataType: DataType; // 数据类型
  formItemType: FormItemType; // 表单组件类型

  required?: boolean; // 是否必填（表单用）
  disabled?: boolean; // 是否禁用
  isShow: boolean; // 是否显示

  // 表单验证
  validation?: {
    trigger: "blur" | "change";
    type?: "string" | "number" | "date" | "array";
    min?: number;
    max?: number;
    pattern?: string;
    message?: string;
  };

  // 下拉/单选/多选的选项
  options?: Array<{ label: string; value: string | number }>;

  // 复合组件（双日历）配置
  dateRange?: {
    isRange: true;
    isStart: boolean; // true=开始, false=结束
    partnerField: string; // 关联字段名，例：endDate
  };

  // 组件额外属性（直接透传到 UI 组件）
  componentProps?: Record<string, unknown>;
}

// ── 表格列定义 ────────────────────────────────────────────
interface ColumnDef {
  name: string; // 字段名
  label: string; // 列标题
  dataType: DataType;

  isShow: boolean; // 是否显示此列
  width?: number; // 列宽（px）
  minWidth?: number;
  align: "left" | "center" | "right";
  showTooltip: boolean; // 内容溢出时是否气泡显示

  // 特殊列类型
  isEnum?: boolean; // 是否枚举值（需要字典转换）
  options?: Array<{ label: string; value: string | number }>;
  isDate?: boolean; // 是否日期（格式化显示）
  dateFormat?: string; // 日期格式，例：'YYYY-MM-DD'
}

// ── 详情字段定义 ──────────────────────────────────────────
interface DetailFieldDef {
  name: string;
  label: string;
  dataType: DataType;
  isEnum?: boolean;
  options?: Array<{ label: string; value: string | number }>;
  span?: 1 | 2; // 占几列（描述列表用）
}

// ── 数据类型枚举 ──────────────────────────────────────────
type DataType =
  | "string" // 字符串
  | "integer" // 整数
  | "number" // 浮点数
  | "boolean" // 布尔
  | "array" // 数组
  | "date" // 日期
  | "datetime" // 日期时间
  | "enum"; // 枚举（有固定选项）

// ── 表单组件类型 ──────────────────────────────────────────
type FormItemType =
  | "input" // 单行文本
  | "textarea" // 多行文本
  | "inputNumber" // 数字输入
  | "select" // 下拉单选
  | "multiSelect" // 下拉多选
  | "radio" // 单选框组
  | "checkbox" // 多选框组
  | "datePicker" // 日期选择器
  | "dateTimePicker" // 日期时间选择器
  | "dateRange" // 日期范围（双日历）
  | "dateTimeRange" // 日期时间范围
  | "switch" // 开关
  | "upload" // 文件上传
  | "custom"; // 自定义组件

// ── 项目配置 ──────────────────────────────────────────────
interface ProjectConfig {
  uiLibrary: "element-plus" | "ant-design-vue";
  language: "typescript" | "javascript";
  paths: {
    views: string;
    api: string;
    router: string;
    composables: string;
    types: string;
  };
  codegen: {
    author: string;
    overwriteView: boolean;
    overwriteApi: boolean;
    pageSuffix: { list: string; form: string; detail: string };
    dirSuffix: string;
  };
}
```

---

## PageSchema 构造示例

以用户管理模块（`/api/user/list` 接口）为例，swagger-analyzer 应输出：

```json
{
  "meta": {
    "moduleName": "user",
    "moduleNamePascal": "User",
    "moduleNameCn": "用户",
    "listApi": {
      "name": "getUserList",
      "method": "get",
      "uri": "/api/user/list",
      "desc": "获取用户列表",
      "tag": "用户管理"
    },
    "createApi": {
      "name": "createUser",
      "method": "post",
      "uri": "/api/user/create",
      "desc": "创建用户",
      "tag": "用户管理"
    },
    "updateApi": {
      "name": "updateUser",
      "method": "put",
      "uri": "/api/user/update",
      "desc": "更新用户",
      "tag": "用户管理"
    },
    "deleteApi": {
      "name": "deleteUser",
      "method": "delete",
      "uri": "/api/user/{id}",
      "desc": "删除用户",
      "tag": "用户管理"
    },
    "tag": "用户管理",
    "author": "developer"
  },

  "searchFields": [
    {
      "name": "username",
      "label": "用户名",
      "dataType": "string",
      "formItemType": "input",
      "isShow": true,
      "validation": { "trigger": "blur" }
    },
    {
      "name": "status",
      "label": "状态",
      "dataType": "enum",
      "formItemType": "select",
      "isShow": true,
      "options": [
        { "label": "全部", "value": null },
        { "label": "启用", "value": 1 },
        { "label": "禁用", "value": 0 }
      ]
    },
    {
      "name": "startDate",
      "label": "创建时间",
      "dataType": "date",
      "formItemType": "dateRange",
      "isShow": true,
      "dateRange": {
        "isRange": true,
        "isStart": true,
        "partnerField": "endDate"
      }
    }
  ],

  "tableColumns": [
    {
      "name": "id",
      "label": "ID",
      "dataType": "integer",
      "isShow": true,
      "align": "center",
      "showTooltip": false
    },
    {
      "name": "username",
      "label": "用户名",
      "dataType": "string",
      "isShow": true,
      "align": "left",
      "showTooltip": true
    },
    {
      "name": "email",
      "label": "邮箱",
      "dataType": "string",
      "isShow": true,
      "align": "left",
      "showTooltip": true
    },
    {
      "name": "status",
      "label": "状态",
      "dataType": "enum",
      "isShow": true,
      "align": "center",
      "showTooltip": false,
      "isEnum": true,
      "options": [
        { "label": "启用", "value": 1 },
        { "label": "禁用", "value": 0 }
      ]
    },
    {
      "name": "createdAt",
      "label": "创建时间",
      "dataType": "datetime",
      "isShow": true,
      "align": "center",
      "showTooltip": false,
      "isDate": true,
      "dateFormat": "YYYY-MM-DD HH:mm"
    }
  ],

  "formFields": [
    {
      "name": "username",
      "label": "用户名",
      "dataType": "string",
      "formItemType": "input",
      "required": true,
      "isShow": true,
      "validation": { "trigger": "blur", "min": 2, "max": 20 }
    },
    {
      "name": "email",
      "label": "邮箱",
      "dataType": "string",
      "formItemType": "input",
      "required": true,
      "isShow": true,
      "validation": { "trigger": "blur", "pattern": "email" }
    },
    {
      "name": "roleId",
      "label": "角色",
      "dataType": "integer",
      "formItemType": "select",
      "required": true,
      "isShow": true,
      "validation": { "trigger": "change", "type": "number" }
    }
  ],

  "detailFields": [
    { "name": "id", "label": "用户ID", "dataType": "integer" },
    { "name": "username", "label": "用户名", "dataType": "string" },
    { "name": "email", "label": "邮箱", "dataType": "string", "span": 2 },
    {
      "name": "status",
      "label": "状态",
      "dataType": "enum",
      "isEnum": true,
      "options": [
        { "label": "启用", "value": 1 },
        { "label": "禁用", "value": 0 }
      ]
    },
    { "name": "createdAt", "label": "创建时间", "dataType": "datetime" }
  ]
}
```

---

## 传递规则

- swagger-analyzer → 输出 PageSchema（JSON 格式，在内部维护，不需要写文件）
- crud-list / crud-form / crud-detail → 读取 PageSchema 生成对应代码
- adapter → 读取 PageSchema 中的 `formItemType` 映射到具体组件
- 若 PageSchema 构造过程中有不确定字段，**先输出 PageSchema 让用户确认，再生成代码**
