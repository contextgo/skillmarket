---
name: coding-conventions
description: Vue3 + TypeScript 编码规范基础层。所有页面生成任务必须先读取本文件，确保生成代码符合规范。
---

# 编码规范（Foundation Layer）

> 本层规则是全局约束，所有生成代码必须遵守，无论 UI 库是哪个。

---

## 1. 文件组织规范

### 目录结构（以 user 模块为例）

```
src/
├── views/
│   └── user-page/
│       ├── user-list.vue          # 列表页
│       ├── user-form.vue          # 新增/编辑表单（对话框组件）
│       └── user-detail.vue        # 详情页
├── api/
│   └── user.ts                    # API 服务层
├── composables/
│   └── useUserList.ts             # 列表页业务逻辑
│   └── useUserForm.ts             # 表单业务逻辑
└── types/
    └── user.ts                    # 类型定义
```

### 命名规则

- 文件名：`kebab-case`，例：`user-list.vue`、`use-user-list.ts`
- 组件名（export default name）：`PascalCase`，例：`UserList`
- composable：`use` 前缀 + 模块名 + 功能，例：`useUserList`
- 类型：`PascalCase`，例：`UserListItem`、`UserFormData`

---

## 2. Vue3 SFC 规范

### 基础模板结构

```vue
<template>
  <!-- 模板内容 -->
</template>

<script setup lang="ts">
// 1. 框架/第三方 imports
import { ref, reactive, computed, onMounted } from "vue";
import { useRouter } from "vue-router";

// 2. 内部 imports（api、composables、types）
import { getUserList, deleteUser } from "@/api/user";
import { useUserList } from "@/composables/useUserList";
import type { UserListItem, UserListQuery } from "@/types/user";

// 3. Props / Emits 定义
const props = defineProps<{
  mode?: "dialog" | "page";
}>();

const emit = defineEmits<{
  (e: "success"): void;
  (e: "cancel"): void;
}>();

// 4. composable 调用（业务逻辑在 composable 中）
const {
  loading,
  tableData,
  pagination,
  queryForm,
  handleSearch,
  handleReset,
  handlePageChange,
  handleDelete,
} = useUserList();

// 5. 仅限于视图层的局部状态（不含业务逻辑）
const formVisible = ref(false);
const currentId = ref<number | null>(null);
</script>

<style scoped lang="scss">
/* 仅写本组件特有样式，通用样式走全局 */
</style>
```

### 强制规则

- **必须**使用 `<script setup lang="ts">`，禁止 Options API
- **禁止**在 `<script setup>` 中直接写 API 调用，必须通过 composable 或 service
- 页面组件代码超过 **200 行**时，必须将业务逻辑提取到 composable
- 模板中禁止写复杂逻辑，用 `computed` 替代

---

## 3. Composable 规范

### 标准 composable 结构

```typescript
// src/composables/useUserList.ts
import { ref, reactive } from "vue";
import { ElMessage, ElMessageBox } from "element-plus"; // 根据实际UI库调整
import { getUserList, deleteUser } from "@/api/user";
import type {
  UserListItem,
  UserListQuery,
  PaginationState,
} from "@/types/user";

export function useUserList() {
  // --- 状态定义 ---
  const loading = ref(false);
  const tableData = ref<UserListItem[]>([]);

  const pagination = reactive<PaginationState>({
    currentPage: 1,
    pageSize: 20,
    total: 0,
  });

  const queryForm = reactive<UserListQuery>({
    // 查询字段由 swagger-analyzer 解析后填充
  });

  // --- 核心方法 ---
  const fetchList = async () => {
    loading.value = true;
    try {
      const { data } = await getUserList({
        ...queryForm,
        currentPage: pagination.currentPage,
        pageSize: pagination.pageSize,
      });
      tableData.value = data.list ?? [];
      pagination.total = data.total ?? 0;
    } catch (error) {
      console.error("获取列表失败", error);
    } finally {
      loading.value = false;
    }
  };

  const handleSearch = () => {
    pagination.currentPage = 1;
    fetchList();
  };

  const handleReset = (formRef: any) => {
    formRef?.resetFields();
    handleSearch();
  };

  const handlePageChange = (page: number) => {
    pagination.currentPage = page;
    fetchList();
  };

  const handleDelete = async (id: number) => {
    await ElMessageBox.confirm("确认删除该条数据？", "提示", {
      type: "warning",
    });
    await deleteUser(id);
    ElMessage.success("删除成功");
    fetchList();
  };

  // --- 初始化 ---
  onMounted(fetchList);

  return {
    loading,
    tableData,
    pagination,
    queryForm,
    handleSearch,
    handleReset,
    handlePageChange,
    handleDelete,
  };
}
```

---

## 4. TypeScript 规范

### 类型文件结构

```typescript
// src/types/user.ts

// 列表项类型（对应接口返回的单条数据）
export interface UserListItem {
  id: number;
  username: string;
  email: string;
  status: number;
  createdAt: string;
}

// 列表查询参数
export interface UserListQuery {
  username?: string;
  status?: number | null;
  startDate?: string;
  endDate?: string;
}

// 表单数据（新增/编辑）
export interface UserFormData {
  id?: number;
  username: string;
  email: string;
  roleId: number;
}

// 分页状态（通用）
export interface PaginationState {
  currentPage: number;
  pageSize: number;
  total: number;
}

// 枚举（字典数据）
export enum UserStatus {
  Active = 1,
  Disabled = 0,
}

export const USER_STATUS_OPTIONS = [
  { label: "启用", value: UserStatus.Active },
  { label: "禁用", value: UserStatus.Disabled },
];
```

### 强制规则

- 所有 API 入参、出参**必须**定义 interface
- **禁止**使用 `any`，用 `unknown` + 类型守卫代替
- 枚举值同时导出对应的 `OPTIONS` 数组，供下拉框使用
- API 响应用泛型包装：`Promise<ApiResponse<T>>`

---

## 5. 文件超过阈值的拆分规则

| 场景            | 阈值                          | 拆分方式                  |
| --------------- | ----------------------------- | ------------------------- |
| 页面组件 script | 200 行                        | 提取到 composable         |
| 单个 composable | 150 行                        | 按功能拆分多个 composable |
| 类型文件        | 100 行                        | 按模块拆分                |
| service 文件    | 按接口分组，同 tag 放一个文件 | —                         |

---

## 6. 注释规范（全局强制）

> 注释的目标读者是**接手这份代码的开发者**，而不是 AI 自己。
> 注释要回答"为什么"和"是什么"，而不是重复代码本身在做什么。

### 6.1 函数注释 — 必须使用 JSDoc 格式

**适用范围：所有导出函数、composable 内的方法、service 函数**

#### Service 函数

```typescript
/**
 * 删除用户
 *
 * @param id - 用户 ID
 * @throws 当用户不存在或无权限时，接口返回业务错误，由拦截器统一处理
 */
export const deleteUser = (id: number) => del<ActionResult>(`/api/user/${id}`);
```

#### Composable 导出函数（标注作用和副作用）

```typescript
/**
 * 触发列表查询
 * 会将分页重置到第 1 页后再请求，避免查询条件变更后停留在末页
 */
const handleSearch = () => {
  pagination.currentPage = 1
  fetchList()
}

/**
 * 重置查询条件并重新查询
 * @param formRef - 表单组件实例引用，用于调用 resetFields()
 */
const handleReset = (formRef: any) => {
  formRef?.resetFields()
  handleSearch()
}

/**
 * 删除指定记录
 * 删除前会弹出确认对话框，用户取消则中止删除
 * @param id - 要删除的记录 ID
 */
const handleDelete = async (id: number) => { ... }
```

#### Composable 函数本身

```typescript
/**
 * 用户列表页逻辑
 *
 * 封装列表查询、分页、删除等交互逻辑，供 user-list.vue 使用。
 * 不包含表单相关逻辑（见 useUserForm）。
 *
 * @returns 列表状态与操作方法
 */
export function useUserList() { ... }
```

### 6.2 变量注释 — 说明用途和取值含义

**规则：变量名无法自解释时，必须加注释；枚举值、魔法数字必须加注释。**

#### ✅ 正确示范

```typescript
/** 控制新增/编辑弹窗的显示状态 */
const formVisible = ref(false);

/** 当前正在编辑的记录 ID；null 表示新增模式 */
const currentEditId = ref<number | null>(null);

/** 列表加载状态，为 true 时表格显示 loading 遮罩 */
const loading = ref(false);

const pagination = reactive({
  currentPage: 1, // 当前页码，从 1 开始
  pageSize: 20, // 每页条数，与后端约定默认值一致
  total: 0, // 总记录数，由接口返回
});

/** 查询表单绑定数据，字段与接口参数一一对应 */
const queryForm = reactive<UserListQuery>({
  username: "", // 用户名，支持模糊匹配
  status: null, // 状态筛选：null=全部 1=启用 0=禁用
  dateRange: [null, null], // 创建时间范围，提交前拆分为 startDate/endDate
});
```

#### ✅ 枚举和常量必须说明每个值

```typescript
/** 用户状态枚举 */
export enum UserStatus {
  Active = 1, // 启用：正常使用
  Disabled = 0, // 禁用：无法登录，数据保留
}

/**
 * 用户状态下拉选项
 * 用于查询表单的状态筛选 select 和表格枚举列的 label 转换
 */
export const USER_STATUS_OPTIONS = [
  { label: "启用", value: UserStatus.Active },
  { label: "禁用", value: UserStatus.Disabled },
];

/** 状态值对应的 Element Plus tag 类型（用于表格枚举列着色）*/
const STATUS_TAG_TYPE: Record<number, string> = {
  1: "success", // 启用 → 绿色
  0: "danger", // 禁用 → 红色
};
```

#### ❌ 不需要注释的情况（自解释变量，加了反而噪音）

```typescript
// ❌ 多余，变量名已经说明了一切
/** 用户名 */
const username = ref("");

// ❌ 多余，代码就是注释
// 将页码重置为 1
pagination.currentPage = 1;
```

### 6.3 区块注释 — 用于分隔 composable 内的逻辑段落

**规则：composable 内的逻辑按「状态定义 → 内部方法 → 对外方法 → 初始化」四段组织，每段前加区块注释。**

```typescript
export function useUserList() {
  // ── 状态 ──────────────────────────────────────────────────
  const loading = ref(false)
  const tableData = ref<UserListItem[]>([])
  const pagination = reactive({ currentPage: 1, pageSize: 20, total: 0 })
  const queryForm = reactive<UserListQuery>({ username: '', status: null })

  // ── 内部方法（不对外暴露）──────────────────────────────────
  const fetchList = async () => { ... }

  // ── 对外方法 ───────────────────────────────────────────────
  /**
   * 触发查询（重置页码到第 1 页）
   */
  const handleSearch = () => { ... }

  /**
   * 重置查询条件
   */
  const handleReset = () => { ... }

  // ── 初始化 ─────────────────────────────────────────────────
  onMounted(fetchList)

  return { loading, tableData, pagination, queryForm, handleSearch, handleReset }
}
```

### 6.4 类型注释 — interface 每个字段必须说明

```typescript
/** 用户列表查询参数 */
export interface UserListQuery {
  /** 用户名，支持模糊匹配，不传则不过滤 */
  username?: string;
  /** 用户状态：1=启用 0=禁用，null 或不传表示查全部 */
  status?: number | null;
  /** 创建时间起始，格式 YYYY-MM-DD */
  startDate?: string;
  /** 创建时间结束，格式 YYYY-MM-DD，与 startDate 配对使用 */
  endDate?: string;
}

/** 用户列表单条数据（对应接口 /api/user/list 的 list[] 元素）*/
export interface UserListItem {
  /** 用户唯一 ID */
  id: number;
  /** 登录用户名 */
  username: string;
  /** 注册邮箱 */
  email: string;
  /** 用户状态：1=启用 0=禁用 */
  status: number;
  /** 账号创建时间，ISO 8601 格式 */
  createdAt: string;
}
```

### 6.5 Vue 模板注释 — 标注区块用途

```vue
<template>
  <div class="user-list">
    <!-- 查询区：条件筛选表单 -->
    <!-- ... -->

    <!-- 工具栏：新增等全局操作按钮 -->
    <!-- ... -->

    <!-- 数据表格：展示列表数据，含操作列 -->
    <!-- ... -->

    <!-- 分页：与 pagination 状态双向绑定 -->
    <!-- ... -->

    <!-- 表单弹窗：新增/编辑共用，通过 currentEditId 区分模式 -->
    <UserForm
      v-model:visible="formVisible"
      :id="currentEditId"
      @success="handleFormSuccess"
    />
  </div>
</template>
```

### 6.6 TODO 注释规范

需要后续处理的事项必须用标准格式，方便 IDE 高亮和搜索：

```typescript
// TODO: [作用域] 说明 — 例如：
// TODO: [roleId] 角色选项需从接口 /api/role/list 动态加载，当前为空数组占位
// TODO: [upload] 上传接口地址待确认，当前使用 /api/upload/file
// TODO: [联动] province 变更时需联动清空并重载 city 选项
// FIXME: status 字段后端返回 string 类型，与前端 number 类型不一致，需确认
```

---

## 7. 禁止事项（生成代码红线）

- ❌ 禁止在 `<template>` 中写业务逻辑（如直接调用 API）
- ❌ 禁止硬编码接口地址，必须走 service 层
- ❌ 禁止 `var`，只用 `const` / `let`
- ❌ 禁止省略 TypeScript 类型声明
- ❌ 禁止使用 `Options API`（data/methods/computed 写法）
- ❌ 禁止在 composable 中直接操作 DOM
- ❌ 禁止 `console.log` 进入生产代码（可留 `console.error`）
- ❌ 禁止导出函数没有 JSDoc 注释
- ❌ 禁止枚举值、魔法数字没有说明注释
- ❌ 禁止写重复代码本身含义的无效注释（如 `// 将 loading 设为 true` 对应 `loading.value = true`）
