#!/usr/bin/env python3
"""
parse_requirements.py - 从商务要求 .docx 文件中提取结构化商务条件

用法:
    python parse_requirements.py "商务要求.docx" -o requirements.json

输出 JSON 格式:
[
  {
    "index": 1,
    "content": "质保期不低于3年",
    "has_star": true,
    "source": "table|paragraph",
    "section": "商务要求"
  },
  ...
]
"""

import argparse
import json
import re
import sys
import zipfile
import xml.etree.ElementTree as ET

NS = {
    'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
    'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
}


def extract_text_from_run(run):
    """从 w:r 元素中提取文本"""
    texts = []
    for t in run.findall('.//w:t', NS):
        if t.text:
            texts.append(t.text)
    return ''.join(texts)


def extract_paragraph_text(para):
    """从 w:p 元素中提取完整段落文本"""
    texts = []
    for run in para.findall('.//w:r', NS):
        texts.append(extract_text_from_run(run))
    return ''.join(texts).strip()


def extract_table_rows(table):
    """从 w:tbl 元素中提取所有行的文本"""
    rows = []
    for tr in table.findall('.//w:tr', NS):
        cells = []
        for tc in tr.findall('.//w:tc', NS):
            cell_texts = []
            for para in tc.findall('.//w:p', NS):
                text = extract_paragraph_text(para)
                if text:
                    cell_texts.append(text)
            cells.append('\n'.join(cell_texts))
        rows.append(cells)
    return rows


def is_section_header(text):
    """判断文本是否为章节标题"""
    patterns = [
        r'^[一二三四五六七八九十]+[、.．]',
        r'^\d+[、.．]\d*',
        r'^第[一二三四五六七八九十\d]+[章节条款]',
        r'^[\(（]\d+[\)）]',
    ]
    for p in patterns:
        if re.match(p, text):
            return True
    return False


def parse_docx(filepath):
    """解析 docx 文件，提取商务条件"""
    requirements = []
    index = 0

    with zipfile.ZipFile(filepath, 'r') as z:
        if 'word/document.xml' not in z.namelist():
            print("错误: 文件不包含 word/document.xml", file=sys.stderr)
            sys.exit(1)

        with z.open('word/document.xml') as f:
            tree = ET.parse(f)
            root = tree.getroot()

    body = root.find('.//w:body', NS)
    if body is None:
        print("错误: 无法找到文档正文", file=sys.stderr)
        sys.exit(1)

    current_section = ""

    for elem in body:
        tag = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag

        # 处理表格 - 优先提取
        if tag == 'tbl':
            rows = extract_table_rows(elem)
            if not rows:
                continue

            # 检测表头行（通常第一行）
            header_row = rows[0] if rows else []
            has_header = any(
                kw in ''.join(header_row)
                for kw in ['要求', '条件', '条款', '内容', '说明', '序号', '编号']
            )

            data_rows = rows[1:] if has_header else rows

            for row in data_rows:
                # 跳过空行
                row_text = ''.join(cell.strip() for cell in row)
                if not row_text:
                    continue

                # 找到包含实质内容的单元格（通常是最长的那个，或排除纯数字的）
                content_cells = []
                for cell in row:
                    cell_stripped = cell.strip()
                    if cell_stripped and not re.match(r'^\d+[-.]?\d*$', cell_stripped):
                        content_cells.append(cell_stripped)

                if content_cells:
                    content = ' | '.join(content_cells) if len(content_cells) > 1 else content_cells[0]
                    index += 1
                    requirements.append({
                        'index': index,
                        'content': content,
                        'has_star': '★' in content or '☆' in content,
                        'source': 'table',
                        'section': current_section or '商务要求',
                    })

        # 处理段落
        elif tag == 'p':
            text = extract_paragraph_text(elem)
            if not text:
                continue

            # 更新当前章节
            if is_section_header(text) or '商务要求' in text or '商务条件' in text:
                current_section = text
                continue

            # 跳过纯标题性文字
            if len(text) < 4 and not any(c in text for c in '★☆'):
                continue

            # 作为独立条目
            index += 1
            requirements.append({
                'index': index,
                'content': text,
                'has_star': '★' in text or '☆' in text,
                'source': 'paragraph',
                'section': current_section or '商务要求',
            })

    return requirements


def main():
    parser = argparse.ArgumentParser(description='从商务要求 docx 文件中提取结构化条目')
    parser.add_argument('input', help='商务要求 .docx 文件路径')
    parser.add_argument('-o', '--output', default='requirements.json', help='输出 JSON 文件路径')
    args = parser.parse_args()

    reqs = parse_docx(args.input)

    if not reqs:
        print("警告: 未提取到任何商务条件，请确认文件内容是否正确", file=sys.stderr)

    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(reqs, f, ensure_ascii=False, indent=2)

    print(f"已提取 {len(reqs)} 条商务条件 -> {args.output}")


if __name__ == '__main__':
    main()
