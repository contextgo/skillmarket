#!/usr/bin/env python3
"""
fill_response_table.py - 将商务条件响应填入模板 docx 表格

用法:
    python fill_response_table.py "商务条件响应表.docx" requirements.json -o "商务条件响应表_已填充.docx"

依赖: python-docx (pip install python-docx)

功能:
1. 读取模板 docx 中的表格
2. 自动识别列映射（通过关键词匹配）
3. 根据 requirements.json 生成响应并填入
"""

import argparse
import json
import re
import sys

try:
    from docx import Document
    from docx.shared import Pt
except ImportError:
    print("错误: 需要安装 python-docx 库", file=sys.stderr)
    print("请运行: pip install python-docx", file=sys.stderr)
    sys.exit(1)


# 列映射关键词配置（优先级从高到低）
COLUMN_KEYWORDS = {
    'package': ['包号', '包组', '分包', '采购包', '合同包'],
    'item_no': ['品目编号', '序号', '品目号', '品目'],
    'condition': ['招标要求', '商务要求', '条款内容', '商务条件', '要求', '招标文件要求'],
    'response': ['响应内容', '应答', '投标响应', '应答情况'],
    'deviation': ['偏离', '偏离情况', '偏离说明', '供应商的承诺或说明', '响应结论', '是否偏离'],
}

# 正偏离判断规则
POSITIVE_DEVIATION_RULES = [
    {
        'pattern': r'质保[期限].*?(\d+)\s*年',
        'threshold': 3,
        'compare': 'greater',
        'response_template': '我公司优于响应，提供{value}年质保期，优于招标要求的{threshold}年',
        'value_override': 4,
    },
    {
        'pattern': r'响应时间.*?(\d+)\s*小时',
        'threshold': 4,
        'compare': 'less',
        'response_template': '我公司优于响应，响应时间为{value}小时，优于招标要求的{threshold}小时',
        'value_override': 2,
    },
    {
        'pattern': r'上门.*?(\d+)\s*小时',
        'threshold': 24,
        'compare': 'less',
        'response_template': '我公司优于响应，上门时间为{value}小时，优于招标要求的{threshold}小时',
        'value_override': 12,
    },
]


def match_column(header_text, column_type):
    """检查表头文本是否匹配指定列类型"""
    keywords = COLUMN_KEYWORDS.get(column_type, [])
    header_clean = header_text.strip().replace(' ', '')
    for kw in keywords:
        if kw in header_clean:
            return True
    return False


def detect_column_mapping(table):
    """自动检测表格列映射关系，返回 {列类型: 列索引}"""
    if not table.rows:
        return {}

    header_row = table.rows[0]
    mapping = {}

    for idx, cell in enumerate(header_row.cells):
        cell_text = cell.text.strip()
        if not cell_text:
            continue
        for col_type in COLUMN_KEYWORDS:
            if col_type not in mapping and match_column(cell_text, col_type):
                mapping[col_type] = idx
                break

    return mapping


def check_positive_deviation(content):
    """检查商务条件是否可以标注正偏离，返回 (is_positive, response_text)"""
    for rule in POSITIVE_DEVIATION_RULES:
        match = re.search(rule['pattern'], content)
        if match:
            value = int(match.group(1))
            threshold = rule['threshold']

            is_positive = (
                (rule['compare'] == 'greater' and value <= threshold) or
                (rule['compare'] == 'less' and value >= threshold)
            )

            if is_positive:
                resp = rule['response_template'].format(
                    value=rule['value_override'],
                    threshold=value,
                )
                return True, resp

    return False, None


def generate_response(content):
    """为单条商务条件生成投标响应"""
    is_positive, positive_response = check_positive_deviation(content)

    if is_positive:
        return {
            'response': positive_response,
            'deviation': '正偏离',
        }

    # 默认无偏离
    # 生成概括性响应
    summary = content
    if len(summary) > 80:
        summary = summary[:77] + '...'

    return {
        'response': f'我公司完全响应，{summary}',
        'deviation': '无偏离',
    }


def set_cell_text(cell, text, font_size=None):
    """设置单元格文本，保留原有格式"""
    # 清空现有内容
    for paragraph in cell.paragraphs:
        for run in paragraph.runs:
            run.text = ''

    if cell.paragraphs:
        paragraph = cell.paragraphs[0]
        if paragraph.runs:
            paragraph.runs[0].text = text
            if font_size:
                paragraph.runs[0].font.size = Pt(font_size)
        else:
            run = paragraph.add_run(text)
            if font_size:
                run.font.size = Pt(font_size)
    else:
        paragraph = cell.add_paragraph()
        run = paragraph.add_run(text)
        if font_size:
            run.font.size = Pt(font_size)


def fill_table(template_path, requirements, output_path):
    """填充响应表模板"""
    doc = Document(template_path)

    if not doc.tables:
        print("错误: 模板文件中未找到表格", file=sys.stderr)
        sys.exit(1)

    # 使用第一个表格
    table = doc.tables[0]
    mapping = detect_column_mapping(table)

    if not mapping:
        print("错误: 无法自动识别表头映射关系", file=sys.stderr)
        print("请确认模板表头包含以下关键词之一:", file=sys.stderr)
        for col_type, keywords in COLUMN_KEYWORDS.items():
            print(f"  {col_type}: {', '.join(keywords)}", file=sys.stderr)
        sys.exit(1)

    print("列映射关系:")
    unmapped = []
    for col_type, keywords in COLUMN_KEYWORDS.items():
        if col_type in mapping:
            header_text = table.rows[0].cells[mapping[col_type]].text.strip()
            print(f"  {col_type} -> 第{mapping[col_type]+1}列 [{header_text}]")
        else:
            unmapped.append(col_type)
            print(f"  {col_type} -> 未匹配（将跳过）")

    if 'condition' not in mapping or 'response' not in mapping:
        print("\n警告: '商务条件'或'投标响应'列未匹配，结果可能不完整", file=sys.stderr)

    # 确定已有数据行数（排除表头）
    existing_data_rows = len(table.rows) - 1

    # 如果需要更多行，添加行
    rows_needed = len(requirements) - existing_data_rows
    if rows_needed > 0:
        for _ in range(rows_needed):
            # 复制最后一行的格式来添加新行
            row = table.add_row()
            # 尝试复制格式
            if len(table.rows) > 2:
                template_row = table.rows[1]
                for idx, cell in enumerate(row.cells):
                    if idx < len(template_row.cells):
                        # 复制单元格段落格式
                        src_para = template_row.cells[idx].paragraphs[0] if template_row.cells[idx].paragraphs else None
                        if src_para and cell.paragraphs:
                            cell.paragraphs[0].paragraph_format.alignment = src_para.paragraph_format.alignment

    # 填充数据
    for i, req in enumerate(requirements):
        row_idx = i + 1  # 跳过表头
        if row_idx >= len(table.rows):
            break

        row = table.rows[row_idx]
        resp = generate_response(req['content'])

        # 填写各列
        if 'package' in mapping:
            col_idx = mapping['package']
            if col_idx < len(row.cells):
                set_cell_text(row.cells[col_idx], '1')

        if 'item_no' in mapping:
            col_idx = mapping['item_no']
            if col_idx < len(row.cells):
                set_cell_text(row.cells[col_idx], '1-1')

        if 'condition' in mapping:
            col_idx = mapping['condition']
            if col_idx < len(row.cells):
                set_cell_text(row.cells[col_idx], req['content'])

        if 'response' in mapping:
            col_idx = mapping['response']
            if col_idx < len(row.cells):
                set_cell_text(row.cells[col_idx], resp['response'])

        if 'deviation' in mapping:
            col_idx = mapping['deviation']
            if col_idx < len(row.cells):
                set_cell_text(row.cells[col_idx], resp['deviation'])

    doc.save(output_path)
    print(f"\n已填充 {len(requirements)} 条响应 -> {output_path}")

    # 统计
    positive_count = sum(
        1 for req in requirements
        if check_positive_deviation(req['content'])[0]
    )
    print(f"  无偏离: {len(requirements) - positive_count} 条")
    print(f"  正偏离: {positive_count} 条")

    if unmapped:
        print(f"\n提示: 以下列未匹配，已跳过: {', '.join(unmapped)}")


def main():
    parser = argparse.ArgumentParser(description='将商务条件响应填入模板表格')
    parser.add_argument('template', help='响应表模板 .docx 文件路径')
    parser.add_argument('requirements', help='requirements.json 文件路径')
    parser.add_argument('-o', '--output', default='商务条件响应表_已填充.docx', help='输出文件路径')
    parser.add_argument('--package', default='1', help='采购包编号（默认: 1）')
    parser.add_argument('--item-no', default='1-1', help='品目号（默认: 1-1）')
    args = parser.parse_args()

    with open(args.requirements, 'r', encoding='utf-8') as f:
        requirements = json.load(f)

    if not requirements:
        print("错误: requirements.json 中没有商务条件", file=sys.stderr)
        sys.exit(1)

    print(f"读取到 {len(requirements)} 条商务条件")
    fill_table(args.template, requirements, args.output)


if __name__ == '__main__':
    main()
