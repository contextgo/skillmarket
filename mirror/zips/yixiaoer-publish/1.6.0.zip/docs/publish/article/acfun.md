# AcFun文章发布参数 (AcFun Article)

本平台文章发布通过 `contentPublishForm` 承载以下参数。

## 1. contentPublishForm 参数定义

| 字段名 | 类型 | 必填 | 说明 | 默认值 |
| :--- | :--- | :--- | :--- | :--- |
| `formType` | `string` | **是** | 固定值: `task` | `task` |
| `title` | `string` | **是** | 文章标题 | - |
| `desc` | `string` | 否 | 文章摘要/描述 | - |
| `covers` | `Array` | **是** | 文章封面列表 (`OldCover[]`) | - |
| `tags` | `string[]` | **是** | 文章标签 | - |
| `category` | `Array` | **是** | 文章分类 (`Category[]`) | - |
| `type` | `number` | **是** | 创作类型: 0-不申明, 1-申明原创 | - |
| `contentSourceUrl` | `string` | 否 | 原文链接 (转载时必填) | - |

## 2. Payload 完整示例

```json
{
  "action": "publish",
  "publishType": "article",
  "platforms": ["AcFun"],
  "publishArgs": {
    "content": "<h1>文章标题</h1><p>正文内容...</p>",
    "accountForms": [
      {
        "platformAccountId": "acc_ac_001",
        "coverKey": "article_cover_key",
        "cover": { "key": "article_cover_key", "size": 102400, "width": 800, "height": 600 },
        "contentPublishForm": {
          "formType": "task",
          "title": "这是文章标题",
          "covers": [
            { "key": "article_cover_key", "size": 102400, "width": 800, "height": 600 }
          ],
          "tags": ["综合", "生活"],
          "type": 1,
          "category": [
            { "yixiaoerId": "cat_001", "yixiaoerName": "综合", "yixiaoerImageUrl": "", "yixiaoerDesc": "", "viewNum": "0", "raw": {} }
          ]
        }
      }
    ]
  }
}
```

## 3. 复杂对象结构

### 3.1 OldCover (封面对象)
| 字段名 | 类型 | 说明 |
| :--- | :--- | :--- |
| `key` | `string` | OSS 资源 Key |
| `size` | `number` | 文件大小 (bytes) |
| `width` | `number` | 宽度 |
| `height` | `number` | 高度 |

### 3.2 Category (分类对象)
| 字段名 | 类型 | 说明 |
| :--- | :--- | :--- |
| `yixiaoerId` | `string` | ID |
| `yixiaoerName` | `string` | 名称 |
| `raw` | `Object` | 原始对象 |

## 4. DTO 参考
- 后端类: `AcFunArticleForm`
- 文件路径: `apps/server-api/packages/yxr-open-platform/src/models/platform/acfun.dto.ts`
