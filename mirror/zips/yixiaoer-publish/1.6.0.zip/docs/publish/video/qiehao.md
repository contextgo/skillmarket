# 企鹅号 视频发布

## 1. contentPublishForm 数据结构

| 字段名 | 类型 | 必填 | 说明 | 默认值 |
| :--- | :--- | :--- | :--- | :--- |
| formType | string | 是 | 固定为 `task` | `task` |
| title | string | 是 | 视频标题 | - |
| description | string | 是 | 视频描述 | - |
| tags | string[] | 是 | 视频标签 | - |
| category | object[] | 是 | 视频分类，使用 `CascadingPlatformDataItem[]` 结构 | - |
| declaration | number | 否 | 创作申明：0-暂不申明, 1-该内容由AI生成, 2-个人观点仅供参考, 3-剧情演绎仅供娱乐, 4-取材网络谨慎甄别, 5-旧闻 | 0 |
| scheduledTime | number | 否 | 定时发布时间戳（单位：秒） | - |

## 2. 复杂对象结构

### CascadingPlatformDataItem
| 字段名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| id | string | 是 | 选项ID |
| text | string | 是 | 选项文本 |
| children | object[] | 否 | 子级选项列表 (CascadingPlatformDataItem[]) |
| raw | object | 是 | 平台原始数据 |

## 3. JSON 示例

```json
{
  "publishType": "video",
  "platforms": ["Qiehao"],
  "publishArgs": {
    "accountForms": [
      {
        "platformAccountId": "QIEHAO_ACC_ID",
        "video": {
          "key": "v_key",
          "size": 1024000,
          "width": 1920,
          "height": 1080,
          "duration": 60
        },
        "contentPublishForm": {
          "formType": "task",
          "title": "企鹅号视频标题示例",
          "description": "这是关于企鹅号内容的详细描述文字。",
          "tags": ["综合", "生活"],
          "category": [
            {
              "id": "1",
              "text": "生活",
              "raw": {}
            }
          ],
          "declaration": 0
        }
      }
    ]
  }
}
```
