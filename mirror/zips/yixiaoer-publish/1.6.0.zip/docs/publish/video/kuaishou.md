# 快手 视频发布

## 1. contentPublishForm 数据结构

| 字段名 | 类型 | 必填 | 说明 | 默认值 |
| :--- | :--- | :--- | :--- | :--- |
| formType | string | 是 | 固定为 `task` | `task` |
| title | string | 否 | 快手标题 | - |
| description | string | 否 | 快手描述 | - |
| declaration | number | 否 | 快手视频声明：1-内容为 AI 生成, 2-演绎情节仅供娱乐, 3-个人观点仅供参考 | - |
| location | object | 否 | 快手视频位置，使用 `PlatformDataItem` 结构 | - |
| visibleType | number | 是 | 可见类型：0-公开, 1-私密, 3-好友可见 | 0 |
| scheduledTime | number | 否 | 定时发布时间戳（单位：秒） | - |
| shopping_cart | object | 否 | 关联商品信息 | - |
| collection | object | 否 | 合集信息，使用 `Category` 结构 | - |
| mini_app | object | 否 | 挂载小程序（与购物车互斥） | - |
| nearby_show | boolean | 否 | 是否同城展示 | `true` |
| allow_same_frame | boolean | 否 | 是否允许同框 | `false` |
| allow_download | boolean | 否 | 是否允许下载 | `false` |

## 2. 复杂对象结构

### Category
| 字段名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| yixiaoerId | string | 是 | 蚁小二ID |
| yixiaoerName | string | 是 | 蚁小二名称 |
| raw | object | 是 | 平台原始数据 |

### PlatformDataItem
| 字段名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| id | string | 是 | ID |
| text | string | 是 | 文本内容 |
| raw | object | 是 | 平台原始数据 |

## 3. JSON 示例

```json
{
  "publishType": "video",
  "platforms": ["Kuaishou"],
  "publishArgs": {
    "accountForms": [
      {
        "platformAccountId": "KS_ACC_ID",
        "video": {
          "key": "v_key",
          "size": 1024000,
          "width": 1080,
          "height": 1920,
          "duration": 15
        },
        "contentPublishForm": {
          "formType": "task",
          "title": "快手视频标题",
          "description": "这是大快手的一条视频动态 #生活 #正能量",
          "visibleType": 0,
          "declaration": 3,
          "nearby_show": true,
          "allow_same_frame": false,
          "allow_download": false
        }
      }
    ]
  }
}
```
