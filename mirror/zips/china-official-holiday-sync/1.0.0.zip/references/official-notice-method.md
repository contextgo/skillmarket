# Official Notice Method

## Source Priority

1. `notice_urls` in local config — always check here first.
2. Official China government policy search:
   - `https://sousuo.www.gov.cn/sousuo/search.shtml?code=17da70961a7&dataTypeId=107&searchWord=<query>`
3. Public-search fallback only if the official search channel is temporarily unavailable.

Accept any candidate URL that matches the general gov.cn policy-content pattern:

```text
https://www.gov.cn/zhengce/content/<path>/content_<id>.htm
```

`<path>` may be a year-month segment (`202511`), a multi-level path, or omitted entirely in older notices — do not hard-code a single format. After fetching the candidate, validate it:

- `og:title` or `<title>` contains the expected notice title for the requested year, **or**
- the main content block contains that same title text.

---

## Query Strategy

Build queries from the canonical notice title template:

```
国务院办公厅关于<year>年部分节假日安排的通知
```

Generate variants automatically by progressively relaxing constraints:

| Priority | Query form |
|----------|-----------|
| 1 (exact) | full title string verbatim |
| 2 (loose) | `<year>年 部分节假日安排 通知` |
| 3 (broad) | `<year>年 节假日安排 国务院办公厅` |

Stop at the first variant that returns a validatable candidate. Add further variants only if all three fail and a retry is warranted.

---

## Parsing Rules

Holiday notice paragraphs typically look like:

```text
一、元旦：1月1日（周四）至3日（周六）放假调休，共3天。1月4日（周日）上班。
```

Apply these patterns in order:

| What to extract | Pattern |
|----------------|---------|
| Holiday section header | `^[一二三四五六七八九十]+、([^：]+)：(.+)$` |
| Date range | `(?P<start_month>\d{1,2})月(?P<start_day>\d{1,2})日.*?至(?:(?P<end_month>\d{1,2})月)?(?P<end_day>\d{1,2})日` |
| Single date | `(?P<month>\d{1,2})月(?P<day>\d{1,2})日` |
| Adjusted workday | `(?P<month>\d{1,2})月(?P<day>\d{1,2})日（周[一二三四五六日天]）上班` |

Mapping rules:

- Expand date ranges into one row per calendar day with `is_holiday=true`.
- Each adjusted workday becomes one row with `is_workday=true`.
- Name adjusted workdays as `<holiday_name>调休上班`.
- When `end_month` is absent in a range, inherit `start_month`.

---

## Discovery Frequency Rules

Discovery frequency depends on whether the requested year's notice is expected to exist yet.

**General principle:** notices for year *Y* are typically published in **November or December of year *Y-1***. Use this expectation to decide how aggressively to probe:

| Scenario | Behaviour |
|----------|-----------|
| Year < current year | Notice should exist. Discover immediately; treat a miss as a data problem worth retrying soon. |
| Year = current year | Notice should exist (published late previous year). Discover immediately on first request. |
| Year = current year + 1 | Notice may not be out yet. Apply a **probe delay**: do not attempt discovery before a configurable calendar day (default: the **15th of the current month**). |
| Year >= current year + 2 | Almost certainly unpublished. Skip discovery entirely; return no URL without caching a negative. |

The probe-delay threshold (default day **15**) is a tuneable parameter. Callers may override it by passing a `probe_after_day` value. Lower values probe more eagerly; higher values are more conservative.

Cache **negative** results at month granularity: if year *Y* was checked in month *M* and no notice was found, skip all further checks within the same calendar month. Retry once the next month begins.

---

## Local Caching Pattern

Maintain two separate stores.

### `notice_urls`

Long-lived, authoritative. Write once a URL is confirmed; never overwrite unless the caller explicitly requests a refresh.

```json
{
  "notice_urls": {
    "2025": "https://www.gov.cn/zhengce/content/202411/content_6986382.htm",
    "2026": "https://www.gov.cn/zhengce/content/202511/content_7047090.htm"
  }
}
```

### `discovery_cache`

Short-lived probe history, keyed by year. Records the **calendar month** of the last check and its outcome, so the probe-frequency rules can be enforced without querying the remote source again within the same month.

```json
{
  "discovery_cache": {
    "2027": {
      "last_checked_month": "2026-04",
      "url": null,
      "found": false
    },
    "2026": {
      "last_checked_month": "2025-11",
      "url": "https://www.gov.cn/zhengce/content/202511/content_7047090.htm",
      "found": true
    }
  }
}
```

`last_checked_month` uses `YYYY-MM` format. Compare only the year-month portion when deciding whether to re-probe.

---

## Scheduling Use

After holiday rows are in storage:

- Determine `is_workday(date)` — returns true for normal weekdays that are not holidays, and for adjusted workdays.
- Compute `first_workday_of_week(reference_day)` — walk forward from Monday of that week until `is_workday` returns true.
- Use that date to gate time-sensitive operations (e.g. weekly digest sends) instead of plain weekday logic.
