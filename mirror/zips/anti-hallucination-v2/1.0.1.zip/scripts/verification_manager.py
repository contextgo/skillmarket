#!/usr/bin/env python3
"""
🟡 转 🟢 验证管理器
用于管理 anti-hallucination Skill 的内容验证流程
"""

import json
import os
import re
from datetime import datetime
from pathlib import Path

TRUTH_BASE_DIR = Path.home() / ".openclaw" / "workspace" / "truth-base"
VERIFIED_FACTS_DIR = TRUTH_BASE_DIR / "verified_facts"
PENDING_DIR = TRUTH_BASE_DIR / "pending_verification"
FALSE_CLAIMS_DIR = TRUTH_BASE_DIR / "false_claims"
REFERENCES_DIR = TRUTH_BASE_DIR / "references"

class VerificationManager:
    def __init__(self):
        # 确保目录存在
        for dir in [VERIFIED_FACTS_DIR, PENDING_DIR, FALSE_CLAIMS_DIR, REFERENCES_DIR]:
            dir.mkdir(parents=True, exist_ok=True)
    
    def extract_marked_content(self, report_text: str) -> list:
        """
        从报告中提取三色标注的内容
        返回: [{'content': ..., 'confidence': 'yellow/red/green', 'context': ..., 'type': ...}]
        """
        items = []
        
        # 匹配 🟡 [待验证]、🟢 [已验证]、🔴 [存疑]
        patterns = [
            (r'🟡 \[待验证\]', 'yellow'),
            (r'🟢 \[已验证\]', 'green'),
            (r'🔴 \[存疑\]', 'red')
        ]
        
        lines = report_text.split('\n')
        for line in lines:
            for pattern, confidence in patterns:
                if re.search(pattern, line):
                    # 提取内容（去除标注标记）
                    content = re.sub(pattern, '', line).strip()
                    if content:
                        items.append({
                            'content': content,
                            'confidence': confidence,
                            'context': line,
                            'type': self._guess_content_type(content),
                            'extracted_at': datetime.now().isoformat()
                        })
        
        return items
    
    def _guess_content_type(self, content: str) -> str:
        """猜测内容类型"""
        if 'API' in content or '库' in content or '函数' in content:
            return 'api'
        elif '数据' in content or '统计' in content or '%' in content:
            return 'statistics'
        elif '论文' in content or '文献' in content or '引用' in content:
            return 'citation'
        elif '技术' in content or '方法' in content or '框架' in content:
            return 'technical'
        elif '预测' in content or '趋势' in content or '市场' in content:
            return 'market_analysis'
        else:
            return 'general'
    
    def save_to_pending(self, yellow_items: list):
        """将 🟡 内容保存到 pending_verification"""
        pending_file = PENDING_DIR / f"pending_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        data = {
            'yellow_items': yellow_items,
            'total_count': len(yellow_items),
            'created_at': datetime.now().isoformat(),
            'status': 'pending'
        }
        
        with open(pending_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        return pending_file
    
    def verify_with_material(self, yellow_item: dict, material_text: str, material_source: str = "unknown") -> dict:
        """
        用提供的材料验证 🟡 内容
        
        返回:
        {
            'status': 'verified/pending/false',
            'matches': list of matches,
            'material_source': material_source,
            'verification_date': timestamp
        }
        """
        content = yellow_item['content']
        
        # 简化验证：检查内容是否在材料中出现
        matches = []
        if content in material_text:
            matches.append({'match_type': 'exact', 'confidence': 'high'})
        else:
            # 模糊匹配：关键词匹配
            keywords = self._extract_keywords(content)
            keyword_matches = []
            for keyword in keywords:
                if keyword in material_text:
                    keyword_matches.append(keyword)
            
            if keyword_matches:
                matches.append({'match_type': 'keyword', 'keywords': keyword_matches, 'confidence': 'medium'})
        
        if matches:
            status = 'verified'
        else:
            status = 'pending'
        
        return {
            'yellow_item': yellow_item,
            'status': status,
            'matches': matches,
            'material_source': material_source,
            'verification_date': datetime.now().isoformat(),
            'notes': f'匹配结果：{len(matches)} 个匹配项'
        }
    
    def _extract_keywords(self, text: str) -> list:
        """从文本中提取关键词"""
        # 简单的关键词提取
        words = re.findall(r'\b[A-Za-z][A-Za-z]{3,}\b', text)
        return list(set(words))
    
    def move_to_verified(self, yellow_item: dict, verification_result: dict):
        """将已验证的内容移动到 verified_facts"""
        content_id = f"{yellow_item['type']}_{datetime.now().strftime('%Y%m%d%H%M%S')}"
        verified_file = VERIFIED_FACTS_DIR / f"{content_id}.json"
        
        verified_data = {
            'content': yellow_item['content'],
            'original_context': yellow_item['context'],
            'content_type': yellow_item['type'],
            'verification_result': verification_result,
            'verified_date': datetime.now().isoformat(),
            'status': 'verified'
        }
        
        with open(verified_file, 'w', encoding='utf-8') as f:
            json.dump(verified_data, f, ensure_ascii=False, indent=2)
        
        return verified_file
    
    def move_to_false(self, yellow_item: dict, reason: str):
        """将确认错误的内容移动到 false_claims"""
        content_id = f"false_{yellow_item['type']}_{datetime.now().strftime('%Y%m%d%H%M%S')}"
        false_file = FALSE_CLAIMS_DIR / f"{content_id}.json"
        
        false_data = {
            'content': yellow_item['content'],
            'original_context': yellow_item['context'],
            'content_type': yellow_item['type'],
            'classified_as_false_at': datetime.now().isoformat(),
            'reason': reason,
            'status': 'false'
        }
        
        with open(false_file, 'w', encoding='utf-8') as f:
            json.dump(false_data, f, ensure_ascii=False, indent=2)
        
        return false_file
    
    def save_reference(self, material_text: str, source_info: dict):
        """保存参考资料"""
        ref_id = f"ref_{datetime.now().strftime('%Y%m%d%H%M%S')}"
        ref_file = REFERENCES_DIR / f"{ref_id}.json"
        
        ref_data = {
            'content': material_text,
            'source_info': source_info,
            'saved_at': datetime.now().isoformat(),
            'verification_count': 0  # 使用此资料验证的次数
        }
        
        with open(ref_file, 'w', encoding='utf-8') as f:
            json.dump(ref_data, f, ensure_ascii=False, indent=2)
        
        return ref_file
    
    def generate_report(self):
        """生成认知沙盒统计报告"""
        verified_count = len(list(VERIFIED_FACTS_DIR.glob('*.json')))
        pending_count = len(list(PENDING_DIR.glob('*.json')))
        false_count = len(list(FALSE_CLAIMS_DIR.glob('*.json')))
        ref_count = len(list(REFERENCES_DIR.glob('*.json')))
        
        return {
            'verified_facts': verified_count,
            'pending_verification': pending_count,
            'false_claims': false_count,
            'references': ref_count,
            'total_items': verified_count + pending_count + false_count,
            'report_date': datetime.now().isoformat()
        }

def main():
    print("=== 🟡 转 🟢 验证管理器 ===")
    manager = VerificationManager()
    
    # 示例报告文本
    sample_report = """
Agentic AI（自主智能体 AI）指的是具备自主决策和执行能力的人工智能系统。🟡 [待验证]
它超越了传统的任务型 AI，能够根据环境变化自主调整行为，持续学习并优化策略。🟡 [待验证]

Agentic AI 的主要应用场景包括：
🟡 [待验证]
- 自动化软件开发：代码生成、测试、部署全流程自动化
- 智能客服与销售：能够理解上下文并自主采取行动的客户服务系统
- 科研辅助：自主文献调研、实验设计、数据分析
- 业务流程自动化：复杂的多步骤业务流程执行

🟡 [待验证] 根据 2025 年统计，Agentic AI 市场规模预计将达到 500亿美元。
🔴 [存疑] LangChain 的最新版本是 0.1.5，但实际可能是 0.2.0。
"""
    
    # 提取标注内容
    marked_items = manager.extract_marked_content(sample_report)
    
    print(f"提取到 {len(marked_items)} 项标注内容:")
    for item in marked_items:
        print(f"  [{item['confidence']}] {item['content'][:50]}...")
    
    # 分离 🟡 内容
    yellow_items = [item for item in marked_items if item['confidence'] == 'yellow']
    print(f"\n🟡 待验证内容: {len(yellow_items)} 项")
    
    # 保存到待验证库
    pending_file = manager.save_to_pending(yellow_items)
    print(f"已保存到: {pending_file}")
    
    # 示例验证材料
    verification_material = """
根据 OpenAI 2025 年发布的报告，Agentic AI 指的是具备自主决策和执行能力的人工智能系统。
Agentic AI 超越了传统的任务型 AI，能够根据环境变化自主调整行为，持续学习并优化策略。
主要应用场景包括自动化软件开发、智能客服与销售、科研辅助和业务流程自动化。
2025 年统计数据显示，Agentic AI 市场规模预计将达到 500亿美元。
"""
    
    # 开始验证
    print("\n=== 开始验证 ===")
    for item in yellow_items[:3]:  # 测试前3项
        result = manager.verify_with_material(
            item, 
            verification_material,
            material_source="OpenAI 2025报告"
        )
        
        print(f"\n验证: {item['content'][:60]}...")
        print(f"状态: {result['status']}")
        print(f"匹配项: {len(result['matches'])}")
        
        if result['status'] == 'verified':
            verified_file = manager.move_to_verified(item, result)
            print(f"✅ 已验证，保存至: {verified_file}")
        else:
            print(f"❌ 仍待验证")
    
    # 生成统计报告
    stats = manager.generate_report()
    print(f"\n=== 认知沙盒统计 ===")
    print(f"已验证事实: {stats['verified_facts']}")
    print(f"待验证内容: {stats['pending_verification']}")
    print(f"错误声明: {stats['false_claims']}")
    print(f"参考资料: {stats['references']}")
    print(f"总计: {stats['total_items']} 项")

if __name__ == "__main__":
    main()