#!/usr/bin/env python3
"""
verify_fact.py
--------------
将待验证内容（🟡）升级为已验证（🟢），并积累到认知沙盒。

Usage:
  python verify_fact.py add --fact "<待验证内容>" --source "<权威来源>" [--confidence high|medium] [--notes "<备注>"]
  python verify_fact.py query --fact "<查询内容>"
  python verify_fact.py list [--limit N] [--verified-only]
  python verify_fact.py upgrade --fact-id <ID>
  python verify_fact.py stats

Examples:
  # 添加一条已验证的事实
  python verify_fact.py add \
    --fact "Python 3.12 于 2023年10月发布" \
    --source "https://www.python.org/downloads/release/python-3120/" \
    --confidence high \
    --notes "官方发布页面确认"

  # 查询认知沙盒是否包含某条事实
  python verify_fact.py query --fact "Python 3.12 发布时间"

  # 将日志中的 🟡 记录升级为 🟢
  python verify_fact.py upgrade --fact-id 5
"""

import argparse
import json
import os
import sys
import re
from datetime import datetime, timezone
from pathlib import Path
from difflib import SequenceMatcher

DEFAULT_KB_DIR = Path.home() / ".openclaw" / "workspace" / "hallucination_logs"
KB_FILE_NAME = "verified_knowledge.json"
LOG_FILE_NAME = "hallucination_history.jsonl"


def get_kb_path(kb_dir: Path) -> Path:
    kb_dir.mkdir(parents=True, exist_ok=True)
    return kb_dir / KB_FILE_NAME


def get_log_path(kb_dir: Path) -> Path:
    return kb_dir / LOG_FILE_NAME


def load_knowledge_base(kb_dir: Path) -> dict:
    kb_path = get_kb_path(kb_dir)
    if kb_path.exists():
        with open(kb_path, "r", encoding="utf-8") as f:
            return json.load(f)
    return {
        "version": "1.0",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "entries": [],
        "stats": {
            "total": 0,
            "verified": 0,
            "pending": 0,
            "by_category": {}
        }
    }


def save_knowledge_base(kb_dir: Path, kb: dict):
    kb_path = get_kb_path(kb_dir)
    kb["updated_at"] = datetime.now(timezone.utc).isoformat()
    with open(kb_path, "w", encoding="utf-8") as f:
        json.dump(kb, f, ensure_ascii=False, indent=2)


def similarity(a: str, b: str) -> float:
    """计算两个字符串的相似度（0-1）"""
    return SequenceMatcher(None, a.lower(), b.lower()).ratio()


def categorize_fact(fact: str) -> str:
    """根据内容自动分类"""
    fact_lower = fact.lower()
    if any(k in fact_lower for k in ["api", "函数", "方法", "库", "import", "class", "def "]):
        return "code"
    elif any(k in fact_lower for k in ["日期", "时间", "年", "月", "日", "version", "版本"]):
        return "temporal"
    elif any(k in fact_lower for k in ["人名", "人物", "作者", "博士", "教授"]):
        return "person"
    elif any(k in fact_lower for k in ["公司", "组织", "机构", "大学", "研究院"]):
        return "organization"
    elif re.search(r'\d+', fact):
        return "numerical"
    else:
        return "general"


def cmd_add(args):
    """添加一条验证后的事实到认知沙盒"""
    kb_dir = Path(args.kb_dir) if args.kb_dir else DEFAULT_KB_DIR
    kb = load_knowledge_base(kb_dir)
    
    # 检查是否已存在相似条目
    for entry in kb["entries"]:
        if similarity(entry["fact"], args.fact) > 0.85:
            print(f"[WARNING] Similar fact already exists (ID: {entry['id']})")
            print(f"  Existing: {entry['fact'][:80]}...")
            print(f"  Status: {'🟢 VERIFIED' if entry['verified'] else '🟡 PENDING'}")
            confirm = input("Add anyway? (y/N): ")
            if confirm.lower() != 'y':
                print("Aborted.")
                return
    
    entry_id = len(kb["entries"]) + 1
    category = categorize_fact(args.fact)
    
    entry = {
        "id": entry_id,
        "fact": args.fact,
        "source": args.source,
        "confidence": args.confidence or "high",
        "verified": args.confidence == "high",
        "status": "verified" if args.confidence == "high" else "pending",
        "category": category,
        "notes": args.notes or "",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "verification_count": 1 if args.confidence == "high" else 0
    }
    
    kb["entries"].append(entry)
    kb["stats"]["total"] += 1
    if entry["verified"]:
        kb["stats"]["verified"] += 1
    else:
        kb["stats"]["pending"] += 1
    
    kb["stats"]["by_category"][category] = kb["stats"]["by_category"].get(category, 0) + 1
    
    save_knowledge_base(kb_dir, kb)
    
    status_emoji = "🟢" if entry["verified"] else "🟡"
    print(f"[ADDED] {status_emoji} ID:{entry_id} | {category}")
    print(f"        {args.fact[:80]}{'...' if len(args.fact) > 80 else ''}")
    print(f"        Source: {args.source[:60]}{'...' if len(args.source) > 60 else ''}")


def cmd_query(args):
    """查询认知沙盒是否包含某条事实"""
    kb_dir = Path(args.kb_dir) if args.kb_dir else DEFAULT_KB_DIR
    kb = load_knowledge_base(kb_dir)
    
    if not kb["entries"]:
        print("Knowledge base is empty.")
        return
    
    query = args.fact
    results = []
    
    for entry in kb["entries"]:
        sim = similarity(entry["fact"], query)
        if sim > 0.6:  # 相似度阈值
            results.append((sim, entry))
    
    results.sort(key=lambda x: -x[0])
    
    if not results:
        print(f"No matching facts found for: {query[:80]}...")
        print("\nSuggestion: This fact is not in the verified knowledge base.")
        print("            Consider adding it with: verify_fact.py add")
        return
    
    print(f"Found {len(results)} matching fact(s) for query:")
    print(f"  \"{query[:80]}{'...' if len(query) > 80 else ''}\"")
    print("-" * 60)
    
    for sim, entry in results[:5]:  # 最多显示5条
        status = "🟢 VERIFIED" if entry["verified"] else "🟡 PENDING"
        confidence = entry.get("confidence", "unknown")
        print(f"\n[Match: {sim:.0%}] ID:{entry['id']} | {status} | {confidence}")
        print(f"  Fact: {entry['fact'][:100]}{'...' if len(entry['fact']) > 100 else ''}")
        print(f"  Source: {entry['source'][:70]}{'...' if len(entry['source']) > 70 else ''}")


def cmd_list(args):
    """列出现有认知沙盒条目"""
    kb_dir = Path(args.kb_dir) if args.kb_dir else DEFAULT_KB_DIR
    kb = load_knowledge_base(kb_dir)
    
    entries = kb["entries"]
    if args.verified_only:
        entries = [e for e in entries if e["verified"]]
    
    if not entries:
        print("No entries found.")
        return
    
    limit = args.limit or 20
    entries = entries[-limit:]
    
    print(f"Showing last {len(entries)} entries from knowledge base:")
    print("-" * 70)
    
    for entry in entries:
        status = "🟢" if entry["verified"] else "🟡"
        ts = entry.get("updated_at", "?")[:10]
        cat = entry.get("category", "general")
        print(f"{status} [{entry['id']:>3}] [{cat:<10}] {ts}")
        print(f"    {entry['fact'][:80]}{'...' if len(entry['fact']) > 80 else ''}")
        print(f"    Source: {entry['source'][:60]}{'...' if len(entry['source']) > 60 else ''}")
        print()


def cmd_upgrade(args):
    """将日志中的 🟡 记录升级为 🟢 并加入认知沙盒"""
    kb_dir = Path(args.kb_dir) if args.kb_dir else DEFAULT_KB_DIR
    log_path = get_log_path(kb_dir)
    
    if not log_path.exists():
        print("No hallucination log found.")
        return
    
    # 读取日志
    entries = []
    with open(log_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    entries.append(json.loads(line))
                except json.JSONDecodeError:
                    pass
    
    if not entries:
        print("Log is empty.")
        return
    
    # 找到对应 ID 的条目
    target_idx = args.fact_id - 1
    if target_idx < 0 or target_idx >= len(entries):
        print(f"Invalid fact ID: {args.fact_id}")
        print(f"Valid range: 1-{len(entries)}")
        return
    
    target = entries[target_idx]
    
    print(f"Upgrading entry #{args.fact_id}:")
    print(f"  Type: {target.get('type', 'unknown')}")
    print(f"  Content: {target.get('content', '')[:80]}...")
    print(f"  Session: {target.get('session', 'unknown')}")
    print()
    
    # 交互式收集验证信息
    print("Please provide verification details:")
    source = input("  Authoritative source (URL or reference): ").strip()
    if not source:
        print("Source is required. Aborted.")
        return
    
    confidence = input("  Confidence level [high/medium]: ").strip().lower()
    if confidence not in ["high", "medium"]:
        confidence = "medium"
    
    notes = input("  Additional notes (optional): ").strip()
    
    # 添加到认知沙盒
    kb = load_knowledge_base(kb_dir)
    entry_id = len(kb["entries"]) + 1
    category = categorize_fact(target.get("content", ""))
    
    entry = {
        "id": entry_id,
        "fact": target.get("content", ""),
        "source": source,
        "confidence": confidence,
        "verified": confidence == "high",
        "status": "verified" if confidence == "high" else "pending",
        "category": category,
        "notes": notes,
        "original_log_id": args.fact_id,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "verification_count": 1
    }
    
    kb["entries"].append(entry)
    kb["stats"]["total"] += 1
    if entry["verified"]:
        kb["stats"]["verified"] += 1
    else:
        kb["stats"]["pending"] += 1
    kb["stats"]["by_category"][category] = kb["stats"]["by_category"].get(category, 0) + 1
    
    save_knowledge_base(kb_dir, kb)
    
    status_emoji = "🟢" if entry["verified"] else "🟡"
    print(f"\n[UPGRADED] {status_emoji} ID:{entry_id} | {category}")
    print(f"           Successfully upgraded from log entry #{args.fact_id}")


def cmd_stats(args):
    """显示认知沙盒统计"""
    kb_dir = Path(args.kb_dir) if args.kb_dir else DEFAULT_KB_DIR
    kb = load_knowledge_base(kb_dir)
    stats = kb["stats"]
    
    print("=" * 55)
    print("  认知沙盒统计")
    print("=" * 55)
    print(f"  Total entries         : {stats['total']}")
    print(f"  🟢 Verified (high)    : {stats['verified']}")
    print(f"  🟡 Pending (medium)   : {stats['pending']}")
    print()
    
    if stats["by_category"]:
        print("  By Category:")
        for cat, count in sorted(stats["by_category"].items(), key=lambda x: -x[1]):
            bar = "█" * min(count, 30)
            print(f"    {cat:<15} {count:>4}  {bar}")
        print()
    
    print(f"  KB file location:")
    print(f"    {get_kb_path(kb_dir)}")
    print("=" * 55)


def main():
    parser = argparse.ArgumentParser(
        description="Verify facts and build verified knowledge base"
    )
    parser.add_argument("--kb-dir", default=None, help="Knowledge base directory")
    subparsers = parser.add_subparsers(dest="command")
    
    # add
    p_add = subparsers.add_parser("add", help="Add a verified fact to KB")
    p_add.add_argument("--fact", required=True, help="The fact to verify")
    p_add.add_argument("--source", required=True, help="Authoritative source")
    p_add.add_argument("--confidence", choices=["high", "medium"], default="high")
    p_add.add_argument("--notes", default="", help="Additional notes")
    
    # query
    p_query = subparsers.add_parser("query", help="Query KB for a fact")
    p_query.add_argument("--fact", required=True, help="Fact to search for")
    
    # list
    p_list = subparsers.add_parser("list", help="List KB entries")
    p_list.add_argument("--limit", type=int, default=20)
    p_list.add_argument("--verified-only", action="store_true")
    
    # upgrade
    p_upgrade = subparsers.add_parser("upgrade", help="Upgrade log entry to verified")
    p_upgrade.add_argument("--fact-id", type=int, required=True, help="Log entry ID to upgrade")
    
    # stats
    p_stats = subparsers.add_parser("stats", help="Show KB statistics")
    
    args = parser.parse_args()
    
    if args.command == "add":
        cmd_add(args)
    elif args.command == "query":
        cmd_query(args)
    elif args.command == "list":
        cmd_list(args)
    elif args.command == "upgrade":
        cmd_upgrade(args)
    elif args.command == "stats":
        cmd_stats(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
