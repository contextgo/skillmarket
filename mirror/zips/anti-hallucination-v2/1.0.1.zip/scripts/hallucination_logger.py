#!/usr/bin/env python3
"""
hallucination_logger.py
-----------------------
Record and track AI hallucination-risk events across sessions.

Usage:
  python hallucination_logger.py log    --type <type> --content <text> [--session <id>] [--log-dir <dir>]
  python hallucination_logger.py stats  [--log-dir <dir>]
  python hallucination_logger.py list   [--limit N] [--type <type>] [--log-dir <dir>]
  python hallucination_logger.py clear  [--log-dir <dir>]
  python hallucination_logger.py verify --id <log_entry_id> [--log-dir <dir>]

Types:
  fabricated_citation   - Cited a non-existent paper, URL, or source
  invented_api          - Used a non-existent function, method, or library
  false_fact            - Stated a verifiable fact that is likely wrong
  overconfident         - Gave a confident answer without sufficient grounding
  date_error            - Wrong date, version, or numerical value
  other                 - Other hallucination-risk event
"""

import argparse
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

DEFAULT_LOG_DIR = Path.home() / ".openclaw" / "workspace" / "hallucination_logs"
LOG_FILE_NAME = "hallucination_history.jsonl"
STATS_FILE_NAME = "hallucination_stats.json"

VALID_TYPES = [
    "fabricated_citation",
    "invented_api",
    "false_fact",
    "overconfident",
    "date_error",
    "other",
]


def get_log_path(log_dir: Path) -> Path:
    log_dir.mkdir(parents=True, exist_ok=True)
    return log_dir / LOG_FILE_NAME


def get_stats_path(log_dir: Path) -> Path:
    return log_dir / STATS_FILE_NAME


def load_stats(log_dir: Path) -> dict:
    stats_path = get_stats_path(log_dir)
    if stats_path.exists():
        with open(stats_path, "r", encoding="utf-8") as f:
            return json.load(f)
    return {
        "total": 0,
        "by_type": {t: 0 for t in VALID_TYPES},
        "sessions": {},
        "first_recorded": None,
        "last_recorded": None,
    }


def save_stats(log_dir: Path, stats: dict):
    stats_path = get_stats_path(log_dir)
    with open(stats_path, "w", encoding="utf-8") as f:
        json.dump(stats, f, ensure_ascii=False, indent=2)


def cmd_log(args):
    log_dir = Path(args.log_dir) if args.log_dir else DEFAULT_LOG_DIR
    event_type = args.type
    content = args.content
    session = args.session or "unknown"

    if event_type not in VALID_TYPES:
        print(f"[ERROR] Invalid type '{event_type}'. Valid types: {', '.join(VALID_TYPES)}")
        sys.exit(1)

    now = datetime.now(timezone.utc).isoformat()
    entry = {
        "timestamp": now,
        "session": session,
        "type": event_type,
        "content": content,
    }

    log_path = get_log_path(log_dir)
    with open(log_path, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")

    # Update stats
    stats = load_stats(log_dir)
    stats["total"] += 1
    stats["by_type"][event_type] = stats["by_type"].get(event_type, 0) + 1
    stats["sessions"][session] = stats["sessions"].get(session, 0) + 1
    if not stats["first_recorded"]:
        stats["first_recorded"] = now
    stats["last_recorded"] = now
    save_stats(log_dir, stats)

    print(f"[LOGGED] #{stats['total']} | {event_type} | session={session}")
    print(f"         {content[:120]}{'...' if len(content) > 120 else ''}")


def cmd_stats(args):
    log_dir = Path(args.log_dir) if args.log_dir else DEFAULT_LOG_DIR
    stats = load_stats(log_dir)

    if stats["total"] == 0:
        print("No hallucination events recorded yet.")
        return

    print("=" * 55)
    print("  AI Hallucination Risk Event Statistics")
    print("=" * 55)
    print(f"  Total events recorded : {stats['total']}")
    print(f"  First recorded        : {stats['first_recorded']}")
    print(f"  Last recorded         : {stats['last_recorded']}")
    print()
    print("  By Type:")
    for t, count in sorted(stats["by_type"].items(), key=lambda x: -x[1]):
        if count > 0:
            bar = "█" * min(count, 30)
            print(f"    {t:<25} {count:>4}  {bar}")
    print()
    print("  By Session (top 10):")
    top_sessions = sorted(stats["sessions"].items(), key=lambda x: -x[1])[:10]
    for sid, count in top_sessions:
        print(f"    {sid:<35} {count:>4}")
    print("=" * 55)


def cmd_list(args):
    log_dir = Path(args.log_dir) if args.log_dir else DEFAULT_LOG_DIR
    log_path = get_log_path(log_dir)

    if not log_path.exists():
        print("No hallucination events recorded yet.")
        return

    limit = args.limit or 20
    filter_type = args.type

    entries = []
    with open(log_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    entries.append(json.loads(line))
                except json.JSONDecodeError:
                    pass

    if filter_type:
        entries = [e for e in entries if e.get("type") == filter_type]

    entries = entries[-limit:]

    print(f"Showing last {len(entries)} events{f' of type [{filter_type}]' if filter_type else ''}:")
    print("-" * 60)
    for i, e in enumerate(entries, 1):
        ts = e.get("timestamp", "?")[:19].replace("T", " ")
        etype = e.get("type", "?")
        session = e.get("session", "?")
        content = e.get("content", "")
        print(f"[{i:>3}] {ts}  [{etype}]  session={session}")
        print(f"       {content[:100]}{'...' if len(content) > 100 else ''}")
        print()


def cmd_clear(args):
    log_dir = Path(args.log_dir) if args.log_dir else DEFAULT_LOG_DIR
    log_path = get_log_path(log_dir)
    stats_path = get_stats_path(log_dir)

    confirm = input("This will permanently delete all hallucination records. Type YES to confirm: ")
    if confirm.strip() == "YES":
        if log_path.exists():
            log_path.unlink()
        if stats_path.exists():
            stats_path.unlink()
        print("All records cleared.")
    else:
        print("Aborted.")


def cmd_verify(args):
    """将日志条目标记为已验证（🟡转🟢），并调用 verify_fact.py 升级"""
    import subprocess
    
    log_dir = Path(args.log_dir) if args.log_dir else DEFAULT_LOG_DIR
    log_path = get_log_path(log_dir)
    
    if not log_path.exists():
        print("No hallucination log found.")
        return
    
    # 读取日志
    entries = []
    with open(log_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    entries.append(json.loads(line))
                except json.JSONDecodeError:
                    pass
    
    if not entries:
        print("Log is empty.")
        return
    
    # 找到对应 ID 的条目
    target_idx = args.id - 1
    if target_idx < 0 or target_idx >= len(entries):
        print(f"Invalid log ID: {args.id}")
        print(f"Valid range: 1-{len(entries)}")
        return
    
    target = entries[target_idx]
    
    print(f"Preparing to verify entry #{args.id}:")
    print(f"  Type: {target.get('type', 'unknown')}")
    print(f"  Content: {target.get('content', '')[:80]}...")
    print()
    
    # 调用 verify_fact.py upgrade
    script_path = Path(__file__).parent / "verify_fact.py"
    try:
        result = subprocess.run(
            [sys.executable, str(script_path), "upgrade", "--fact-id", str(args.id)],
            capture_output=False,
            text=True
        )
        if result.returncode == 0:
            print(f"\n✅ Entry #{args.id} successfully upgraded to verified knowledge base.")
        else:
            print(f"\n❌ Upgrade failed.")
    except Exception as e:
        print(f"Error calling verify_fact.py: {e}")
        print("You can manually upgrade using: verify_fact.py upgrade --fact-id <id>")


def main():
    parser = argparse.ArgumentParser(description="AI Hallucination Risk Event Logger")
    subparsers = parser.add_subparsers(dest="command")

    # log
    p_log = subparsers.add_parser("log", help="Record a hallucination-risk event")
    p_log.add_argument("--type", required=True, choices=VALID_TYPES)
    p_log.add_argument("--content", required=True)
    p_log.add_argument("--session", default=None)
    p_log.add_argument("--log-dir", default=None)

    # stats
    p_stats = subparsers.add_parser("stats", help="Show cumulative statistics")
    p_stats.add_argument("--log-dir", default=None)

    # list
    p_list = subparsers.add_parser("list", help="List recent events")
    p_list.add_argument("--limit", type=int, default=20)
    p_list.add_argument("--type", choices=VALID_TYPES, default=None)
    p_list.add_argument("--log-dir", default=None)

    # clear
    p_clear = subparsers.add_parser("clear", help="Clear all records")
    p_clear.add_argument("--log-dir", default=None)

    # verify (upgrade to knowledge base)
    p_verify = subparsers.add_parser("verify", help="Verify a log entry and upgrade to knowledge base (🟡→🟢)")
    p_verify.add_argument("--id", type=int, required=True, help="Log entry ID to verify")
    p_verify.add_argument("--log-dir", default=None)

    args = parser.parse_args()

    if args.command == "log":
        cmd_log(args)
    elif args.command == "stats":
        cmd_stats(args)
    elif args.command == "list":
        cmd_list(args)
    elif args.command == "clear":
        cmd_clear(args)
    elif args.command == "verify":
        cmd_verify(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
