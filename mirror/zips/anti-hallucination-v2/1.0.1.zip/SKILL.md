---
name: anti-hallucination-v2
description: >
  AI幻觉风险控制 Skill（v2认知沙盒版），适用于研究写作和代码生成两大场景。
  当用户需要进行事实性研究、撰写报告、生成代码，或明确要求降低AI幻觉风险时使用本 Skill。
  提供强制引用校验、API 存在性核查、置信度标注、自我校验链、跨会话幻觉事件累计日志，
  以及认知沙盒积累与🟡转🟢验证机制。
  This skill should be used when the user asks for research writing, fact-checking, code generation,
  or explicitly requests reducing hallucination risk. It enforces citation verification, API existence
  checks, confidence labeling, self-verification chains, persistent hallucination event logging,
  and cognitive sandbox (verified knowledge base) with upgrade workflow (🟡→🟢).
version: 2.0.0
updated: 2026-04-19
---

# Anti-Hallucination Skill v2 (认知沙盒版)

## 更新说明

本版本将术语"真伪库"统一改为"认知沙盒"，避免"真伪"一词可能引起的不适感。

## 目的

在研究写作和代码生成任务中，最大限度降低 AI 幻觉风险，并通过持久化日志跨会话累计追踪幻觉事件。

> ⚠️ 重要前提：AI 幻觉**无法被彻底消除**，本 Skill 的目标是**检测、标注、记录并最小化**幻觉风险。

## 核心机制

### 认知沙盒（Verified Knowledge Base）

通过积累已验证的事实，形成可靠的知识库，支持 🟡 待验证内容升级为 🟢 已验证状态。

**工作流程：**
1. 输出内容时自动标注置信度（🟢🟡🔴）
2. 用户或自我校验发现 🟡/🔴 内容后，记录到幻觉日志
3. 用户提供权威资料后，通过验证流程将内容升级入库
4. 后续输出时优先查询认知沙盒，命中则直接标注 🟢

---

## 触发场景

- 用户要求撰写报告、调研文章、技术文档（研究写作场景）
- 用户要求生成代码、调用第三方库、实现功能（代码生成场景）
- 用户明确要求「减少幻觉」「校验内容」「核实事实」
- 用户要求查看累计幻觉统计数据

---

## 核心工作流

### 所有场景：开始前必做

1. 读取 `references/anti-hallucination-protocols.md` 中的完整协议
2. 在内部确定本次任务属于哪个场景（研究写作 / 代码生成 / 两者都有）
3. 确认知识来源类型（用户提供的文档 / 训练数据 / 截止后信息）
4. **查询认知沙盒**：对待输出的事实，先查询 `verify_fact.py query`，若命中且已验证则直接标注 🟢

### 研究写作场景工作流

1. **引用约束**：只引用用户提供材料中存在的来源；无来源时使用「建议查找」模板
2. **事实标注**：对所有数字、日期、人名、机构名使用三色置信度标注（🟢🟡🔴）
3. **写作前核查**：执行 `references/anti-hallucination-protocols.md` 第 2.2 节的写作核查清单
4. **不确定内容**：使用第 2.3 节的不确定性模板替代凭空生成
5. **输出后自我校验**：执行第 5 节的四轮自我校验流程

### 代码生成场景工作流

1. **API 核查**：对所有非标准库函数标注置信度，不确定时使用第 3.4 节模板
2. **代码风险注释**：在代码块后附加 `⚠️ API 风险注释`（格式见 `references` 第 3.2 节）
3. **代码前核查**：执行第 3.3 节的代码生成前检查清单
4. **输出后自我校验**：执行第 5 节四轮自我校验流程，重点执行第二轮 API 核查

---

## 幻觉事件日志记录

### 何时记录

在完成自我校验后，若发现以下任一情况，**必须**调用日志脚本记录：

- 发现自己使用了无法确认的 API 或函数
- 引用了无法在用户文档中找到的来源
- 输出了置信度为 🔴 的内容
- 被用户指出某处信息有误

### 记录方式

使用脚本 `scripts/hallucination_logger.py`：

```bash
# 记录一次事件
python ~/.openclaw/workspace/skills/anti-hallucination/scripts/hallucination_logger.py log \
  --type <事件类型> \
  --content "<简短描述发生了什么>" \
  --session "<任务名称或会话描述>"
```

事件类型（--type 可选值）：
- `fabricated_citation` — 引用了不存在的文献/URL
- `invented_api` — 使用了不存在的函数/方法
- `false_fact` — 陈述了错误的可验证事实
- `overconfident` — 用确定语气表述了不确定信息
- `date_error` — 日期、版本号、数字错误
- `other` — 其他类型

### 查看统计

```bash
# 查看跨会话累计统计
python ~/.openclaw/workspace/skills/anti-hallucination/scripts/hallucination_logger.py stats

# 查看最近记录
python ~/.openclaw/workspace/skills/anti-hallucination/scripts/hallucination_logger.py list --limit 20
```

日志文件存储位置：`~/.openclaw/workspace/hallucination_logs/`（跨所有项目持久化）

---

## 🟡 转 🟢 验证流程

### 何时使用

当用户提供了权威资料，要求验证之前标注为 🟡 或 🔴 的内容时，执行以下流程：

### 验证步骤

1. **查询认知沙盒**：先运行 `verify_fact.py query` 检查是否已存在
2. **提取关键事实**：从用户提供的资料中提取可验证的陈述
3. **添加到认知沙盒**：使用 `verify_fact.py add` 入库
4. **更新输出**：重新生成内容，将对应事实标注为 🟢

### 命令参考

```bash
# 1. 查询认知沙盒是否已包含某事实
python ~/.openclaw/workspace/skills/anti-hallucination/scripts/verify_fact.py query \
  --fact "Python 3.12 于 2023年10月发布"

# 2. 添加新的已验证事实
python ~/.openclaw/workspace/skills/anti-hallucination/scripts/verify_fact.py add \
  --fact "Python 3.12 于 2023年10月2日发布" \
  --source "https://www.python.org/downloads/release/python-3120/" \
  --confidence high \
  --notes "官方发布页面确认"

# 3. 将日志中的 🟡 记录升级为 🟢
python ~/.openclaw/workspace/skills/anti-hallucination/scripts/hallucination_logger.py verify \
  --id 5

# 4. 查看认知沙盒统计
python ~/.openclaw/workspace/skills/anti-hallucination/scripts/verify_fact.py stats

# 5. 列出所有已验证事实
python ~/.openclaw/workspace/skills/anti-hallucination/scripts/verify_fact.py list --verified-only
```

### 认知沙盒结构

- **存储位置**：`~/.openclaw/workspace/hallucination_logs/verified_knowledge.json`
- **自动分类**：code / temporal / person / organization / numerical / general
- **相似度检测**：添加时自动检测重复（阈值 85%）

---

## 置信度标注格式（快速参考）

| 标记 | 含义 | 使用场景 |
|------|------|----------|
| 🟢 [已验证] | 来自用户材料或认知沙盒，可核实 | 直接引用文档内容，或认知沙盒命中 |
| 🟡 [待验证] | 来自训练数据，建议确认 | 常见知识但无法即时核实，未在认知沙盒中 |
| 🔴 [存疑] | 不确定，可能错误 | 应避免输出，若输出必须标注 |

**认知沙盒查询优先级：**
1. 输出前查询认知沙盒 `verify_fact.py query`
2. 若命中且 `verified=true`，直接标注 🟢
3. 若命中但 `verified=false`（待验证），标注 🟡并引用来源
4. 若未命中，按原流程判断置信度

---

## 用户请求统计时的输出格式

当用户请求查看幻觉记录时，运行 `stats` 命令并以如下格式汇报：

```
📊 AI 幻觉风险事件累计记录
━━━━━━━━━━━━━━━━━━━━━━━━
总计事件数：X 次
首次记录：YYYY-MM-DD
最近记录：YYYY-MM-DD

按类型分布：
  invented_api          X 次  ████
  false_fact            X 次  ██
  ...

[详细列表见日志文件]
```
