# Check-in Report Skill

打卡活动报告生成技能，配合 `check-in-manager-skill` 使用，负责统计分析和报告生成。

---

## 🎯 核心功能

- 📊 **进度排名**：查看当前周期打卡排名
- 🎉 **周期结算**：生成周/月结算战报，明确达标/未达标
- 📈 **跨周期对比**：同比/环比分析，展示进步或退步
- ⏰ **催办提醒**：周期未结束时，提醒落后成员

---

## 📂 目录结构

```
check-in-report-skill/
├── SKILL.md                    # Skill 主文件（Agent 执行逻辑）
├── README.md                   # 本文件
├── scripts/                    # 数据处理脚本
│   ├── load_records.py         # 加载打卡记录
│   ├── calc_stats.py           # 统计计算
│   ├── compare_periods.py      # 跨周期对比
│   └── rank_and_qualify.py     # 排名和达标判定
├── references/                 # 参考资料
│   └── report-templates.md     # 报告模板（4种类型）
└── docs/                       # 文档
    └── ADAPTATION.md           # 适配说明（v2.0）
```

---

## 🔗 与 check-in-manager-skill 的关系

```
check-in-manager-skill（数据生产者）
    ├── 创建活动配置（activities/*.txt）
    ├── 记录打卡数据（records/{activity_id}/*.json）
    └── 校验规则（AI）
         ↓
    数据存储
         ↓
check-in-report-skill（数据消费者）
    ├── 读取活动规则（TXT 文件）
    ├── 加载打卡记录（JSON 文件）
    ├── 统计分析（4 个脚本）
    └── 生成报告（4 种模板）
```

---

## 📋 4 种报告类型

### A 类 - 简单进度排名

**适用场景**：日常查询当前周期进度，无结算，无惩罚

**触发词**：
- "查看本周打卡排名"
- "本月进度怎么样"

**报告示例**：
```
📊 周跑步打卡 · 本周进度排名

🏅 排名榜
1. 🥇 ceceilyqi — 已打卡 2 次 ✅
2. 🥈 张总 — 已打卡 1 次 ✅
3. 🥉 老王 — 已打卡 1 次 ✅

📅 统计周期：2026-04-07 ~ 2026-04-08
💪 继续加油，每一次打卡都是进步！
```

---

### B 类 - 周期结算战报

**适用场景**：周/月结束，需要明确达标/未达标，含激励或惩罚提醒

**触发词**：
- "生成本周结算战报"
- "4月打卡结算"

**报告示例**：
```
🎉 周跑步打卡 · 第15期结算战报
📅 统计周期：2026-04-01 ~ 2026-04-07

🏆 本期排行榜
1. 🥇 ceceilyqi — 已打卡 2 次 ✅
2. 🥈 张总 — 已打卡 1 次 ✅
3. 🥉 李明 — 已打卡 0 次 ❌

✅ 达标成员（共 2 人）
- ceceilyqi
- 张总

❌ 未达标成员（共 1 人）
- 李明

⚠️ 提醒：
根据群规则，未完成打卡的成员请发2000元红包（26个，全员有奖）。
连续3周未达标将强制退群。

🌟 恭喜达标成员，继续保持！未达标成员下周加油！
```

---

### C 类 - 跨周期对比

**适用场景**：与上一周期对比，展示进步或退步

**触发词**：
- "对比上月打卡情况"
- "本周比上周怎么样"

**报告示例**：
```
📈 月慢跑打卡 · 周期对比报告
📅 本期：2026-04-01 ~ 2026-04-08  |  上期：2026-03-01 ~ 2026-03-31

📊 成员对比
1. ceceilyqi — 25km ↑ (+5km，进步 25%)
2. 张总 — 30km ↓ (-5km，退步 14%)
3. 老王 — 10km → (持平)

🏆 进步最大：ceceilyqi（+5km）
📉 退步最多：张总（-5km）

💡 坚持是最好的策略，下期继续！
```

---

### D 类 - 催办提醒

**适用场景**：周期未结束，但已有成员明显落后，主动提醒

**触发词**：
- "提醒未完成打卡的成员"
- "催办本周打卡"

**报告示例**：
```
⏰ 周跑步打卡 · 打卡提醒

📅 当前周期剩余 2 天

⚠️ 以下成员还未完成本周打卡，加油冲刺！
- 李明（还差 1 次）
- 王五（还差 1 次）

✅ 已达标成员：ceceilyqi、张总、老王

🔥 时间有限，快去打卡！
```

---

## 🔧 脚本说明

### 1. `load_records.py`

**功能**：按日期范围加载打卡记录

**命令**：
```bash
python3 scripts/load_records.py \
  <records_dir> \
  <start_date> \
  <end_date>
```

**示例**：
```bash
python3 scripts/load_records.py \
  ~/.openclaw/workspace/skills/check-in-manager-skill/records/group-075a2475_ceceilyqi_running_1775643955 \
  2026-04-01 \
  2026-04-08
```

**输出**：
```json
[
  {
    "user": "ceceilyqi",
    "date": "2026-04-08",
    "data": {"distance": 14, "pace": 8}
  }
]
```

---

### 2. `calc_stats.py`

**功能**：按人归集统计

**命令**：
```bash
python3 scripts/calc_stats.py \
  '<records_json>' \
  '<members_json>' \
  [--metric <field>] \
  [--mode count|sum|last_minus_first]
```

**统计模式**：

| 模式 | 说明 | 示例 |
|------|------|------|
| `count` | 统计打卡次数 | 已打卡 5 次 |
| `sum` | 累加指标值 | 累计 120.5 公里 |
| `last_minus_first` | 计算进步值 | 进步 +23 分钟 |

**示例**：
```bash
# 统计打卡次数
python3 scripts/calc_stats.py \
  '[{"user":"alice","date":"2026-04-08"}]' \
  '["alice","bob"]' \
  --mode count

# 输出
{
  "alice": {"value": 1, "count": 1},
  "bob": {"value": 0, "count": 0}
}
```

---

### 3. `compare_periods.py`

**功能**：跨周期对比计算

**命令**：
```bash
python3 scripts/compare_periods.py \
  '<current_stats_json>' \
  '<previous_stats_json>' \
  [--direction asc|desc]
```

**示例**：
```bash
python3 scripts/compare_periods.py \
  '{"alice":{"value":25},"bob":{"value":30}}' \
  '{"alice":{"value":20},"bob":{"value":35}}' \
  --direction desc

# 输出
{
  "alice": {"current": 25, "previous": 20, "delta": 5, "trend": "↑"},
  "bob": {"current": 30, "previous": 35, "delta": -5, "trend": "↓"}
}
```

---

### 4. `rank_and_qualify.py`

**功能**：排名 + 达标判定

**命令**：
```bash
python3 scripts/rank_and_qualify.py \
  '<stats_json>' \
  <target> \
  [--direction asc|desc]
```

**参数**：
- `target`：达标线（如 10 公里、1 次）
- `direction`：
  - `desc`：越大越好（距离、次数）
  - `asc`：越小越好（配速、时间）

**示例**：
```bash
python3 scripts/rank_and_qualify.py \
  '{"alice":{"value":1},"bob":{"value":0}}' \
  1 \
  --direction desc

# 输出
[
  {"rank": 1, "user": "alice", "value": 1, "qualified": true},
  {"rank": 2, "user": "bob", "value": 0, "qualified": false}
]
```

---

## 🔄 工作流程

### 生成报告完整流程

```
用户：查看本周跑步打卡排名

Agent 执行：
  ↓
[1] 意图解析
  - 报告类型：A（简单进度排名）
  - 时间周期：本周
  - 目标活动：周跑步打卡
  ↓
[2] 定位活动
  - 扫描 check-in-manager-skill/activities/*.txt
  - 找到对应活动配置
  ↓
[3] AI 读取活动规则
  - 提取：达标线、核心指标、排序方向
  ↓
[4] 加载打卡记录
  - 调用 load_records.py
  ↓
[5] 统计计算
  - 调用 calc_stats.py
  ↓
[6] 排名判定
  - 调用 rank_and_qualify.py
  ↓
[7] 生成报告
  - 使用对应模板
  ↓
[8] 回复用户
```

---

## 📊 数据来源

### 活动配置（TXT 文件）

**路径**：`check-in-manager-skill/activities/{activity_id}.txt`

**示例**：
```txt
活动名称: 周跑步打卡
活动ID: group-075a2475_ceceilyqi_running_1775643955

【规则详情】
规则1: 距离不少于10公里
规则2: 配速不超过10分钟/公里
规则3: 60岁以上可以豁免配速

【惩罚机制】
连续3周未完成打卡，强制退群
```

**AI 提取的信息**：
- 活动显示名："周跑步打卡"
- 达标线：10 公里
- 核心指标：distance
- 排序方向：desc（越大越好）
- 惩罚机制："连续3周退群"

---

### 打卡记录（JSON 文件）

**路径**：`check-in-manager-skill/records/{activity_id}/YYYY-MM-DD.json`

**示例**：
```json
[
  {
    "user": "ceceilyqi",
    "time": "2026-04-08T18:30:00+08:00",
    "data": {
      "distance": 14,
      "pace": 8,
      "duration": 112
    },
    "content": "周二完成14公里，配速8分钟",
    "valid": true
  }
]
```

---

## ⚠️ 核心原则

1. **绝对客观**：仅使用真实记录数据，严禁捏造
2. **全员覆盖**：无打卡记录的成员也必须出现在报告中
3. **规则至上**：达标线、排序方向 100% 来自活动规则
4. **AI 理解规则**：从 TXT 文件中准确提取关键信息

---

## 🚀 使用示例

### 示例1：查看本周排名

**用户**：查看本周跑步打卡排名

**生成报告**：
```
📊 周跑步打卡 · 本周进度排名

🏅 排名榜
1. 🥇 ceceilyqi — 已打卡 2 次 ✅
2. 🥈 张总 — 已打卡 1 次 ✅
3. 🥉 老王 — 已打卡 1 次 ✅

📅 统计周期：2026-04-07 ~ 2026-04-08
💪 继续加油，每一次打卡都是进步！
```

---

### 示例2：生成月度战报

**用户**：生成4月慢跑战报

**生成报告**：
```
🎉 月慢跑打卡 · 第4期结算战报
📅 统计周期：2026-04-01 ~ 2026-04-30

🏆 本期排行榜
1. 🥇 ceceilyqi — 累计 125km ✅
2. 🥈 张总 — 累计 60km ✅
3. 🥉 李明 — 累计 30km ❌

✅ 达标成员（共 2 人，目标 100km）
- ceceilyqi（超额 25km）
- 张总

❌ 未达标成员（共 1 人）
- 李明（还差 70km）

🌟 恭喜达标成员！李明下月加油！
```

---

## 📖 相关文档

- `SKILL.md`：主文件（Agent 执行逻辑）
- `docs/ADAPTATION.md`：适配说明（v2.0）
- `references/report-templates.md`：报告模板详细说明
- `check-in-manager-skill/README.md`：数据生产者的完整说明

---

## 🔄 版本历史

### v2.0（2026-04-08）
- ✅ 适配 check-in-manager-skill v2.0
- ✅ 支持 TXT 配置文件
- ✅ 更新路径约定
- ✅ 新增 AI 理解规则约束

### v1.0
- ✅ 基础功能：4 种报告类型
- ✅ 4 个统计脚本
- ✅ 报告模板

---

**最后更新**：2026-04-08 21:47  
**版本**：v2.0（适配 check-in-manager-skill v2.0）
