#!/usr/bin/env python3
"""
utils.py - 工具函数

提供路径自动发现功能，帮助脚本定位 check-in-manager-skill 目录。
"""
import os
from pathlib import Path


def find_manager_skill_dir():
    """
    自动定位 check-in-manager-skill 目录
    
    使用相对路径查找（假设两个 skill 在同一 skills/ 目录下）：
    
    check-in-report-skill/scripts/utils.py  (当前文件)
         ↓
    check-in-report-skill/scripts/           (parent)
         ↓
    check-in-report-skill/                   (parent.parent)
         ↓
    skills/                                  (parent.parent.parent)
         ↓
    skills/check-in-manager-skill/           (目标)
    
    Returns:
        Path: check-in-manager-skill 的绝对路径
    
    Raises:
        FileNotFoundError: 如果找不到目录
    """
    # 当前文件路径
    current_file = Path(__file__).resolve()
    
    # check-in-report-skill/scripts/utils.py
    # → check-in-report-skill/scripts/
    scripts_dir = current_file.parent
    
    # → check-in-report-skill/
    skill_dir = scripts_dir.parent
    
    # → skills/
    skills_dir = skill_dir.parent
    
    # → skills/check-in-manager-skill/
    manager_dir = skills_dir / "check-in-manager-skill"
    
    # 验证路径是否存在
    if not manager_dir.exists():
        raise FileNotFoundError(
            f"找不到 check-in-manager-skill 目录\n"
            f"当前文件：{current_file}\n"
            f"向上查找：{skills_dir}\n"
            f"期望路径：{manager_dir}\n"
            f"请确认 check-in-manager-skill 与本 skill 在同一 skills/ 目录下"
        )
    
    return manager_dir


def get_activities_dir():
    """
    获取活动配置目录
    
    Returns:
        Path: activities/ 目录的绝对路径
    """
    return find_manager_skill_dir() / "activities"


def get_records_dir():
    """
    获取打卡记录目录
    
    Returns:
        Path: records/ 目录的绝对路径
    """
    return find_manager_skill_dir() / "records"


def get_activity_config(activity_id: str) -> Path:
    """
    获取活动配置文件路径
    
    Args:
        activity_id: 活动ID（如 group-xxx_running_xxx）
    
    Returns:
        Path: 活动配置文件的绝对路径
    """
    config_file = get_activities_dir() / f"{activity_id}.txt"
    
    if not config_file.exists():
        raise FileNotFoundError(
            f"找不到活动配置文件：{config_file}\n"
            f"Activity ID: {activity_id}"
        )
    
    return config_file


def get_activity_records_dir(activity_id: str) -> Path:
    """
    获取活动打卡记录目录
    
    Args:
        activity_id: 活动ID
    
    Returns:
        Path: 活动记录目录的绝对路径
    """
    records_dir = get_records_dir() / activity_id
    
    if not records_dir.exists():
        raise FileNotFoundError(
            f"找不到活动记录目录：{records_dir}\n"
            f"Activity ID: {activity_id}"
        )
    
    return records_dir


if __name__ == "__main__":
    """测试工具函数"""
    print("🔍 测试路径自动发现\n")
    
    try:
        # 测试1: 查找 manager skill 目录
        manager_dir = find_manager_skill_dir()
        print(f"✅ 找到 check-in-manager-skill:")
        print(f"   {manager_dir}\n")
        
        # 测试2: 获取子目录
        activities_dir = get_activities_dir()
        records_dir = get_records_dir()
        print(f"✅ 活动配置目录:")
        print(f"   {activities_dir}")
        print(f"✅ 打卡记录目录:")
        print(f"   {records_dir}\n")
        
        # 测试3: 列出活动
        if activities_dir.exists():
            activity_files = list(activities_dir.glob("*.txt"))
            print(f"📋 可用活动（共 {len(activity_files)} 个）:")
            for f in activity_files:
                print(f"   - {f.name}")
        
    except FileNotFoundError as e:
        print(f"❌ 错误：{e}")
