#!/usr/bin/env python3
"""
format_values.py - 数值格式化工具（单位转换）

职责：将 calc_stats.py 输出的原始数值转换为可读格式
分工：calc_stats.py 只做数学运算，本脚本只做格式化

用法:
    python3 format_values.py <value> <type>

参数:
    value - 原始数值（浮点数或整数）
    type  - 转换类型：
            pace       - 配速（分钟/公里 → 分'秒"/km）
            duration   - 时长（分钟 → 可读格式）
            distance   - 距离（公里，调整精度）
            count      - 次数（整数）
            weight     - 体重变化（保留1位小数，带符号）

示例:
    # 配速转换
    python3 format_values.py 3.95 pace
    # 输出: 3'57"/km
    
    # 时长转换
    python3 format_values.py 120.5 duration
    # 输出: 2小时
    
    # 距离转换
    python3 format_values.py 21.5 distance
    # 输出: 21.5公里
"""

import sys
import math


def format_pace(value: float) -> str:
    """
    配速转换：小数分钟 → 分'秒" 格式
    
    公式：
        分钟部分 = ⌊value⌋
        秒数部分 = (value - 分钟部分) × 60
    
    示例：
        3.95 → 3'57"/km
        8.5  → 8'30"/km
        10.0 → 10'00"/km
    """
    minutes = int(value)
    seconds = int((value - minutes) * 60)
    return f"{minutes}'{seconds:02d}\"/km"


def format_duration(value: float) -> str:
    """
    时长转换：分钟 → 可读格式
    
    规则：
        - 整数小时优先显示小时
        - 否则显示分钟
    
    示例：
        120.5 → 2小时
        85.0  → 85分钟
        90.0  → 1.5小时
    """
    hours = value / 60
    if value % 60 == 0 and hours >= 1:
        return f"{int(hours)}小时"
    elif hours >= 1:
        return f"{hours:.1f}小时"
    else:
        return f"{value:.1f}分钟" if value % 1 != 0 else f"{int(value)}分钟"


def format_distance(value: float) -> str:
    """
    距离转换：公里（调整精度）
    
    规则：
        - 整数时省略小数点
        - 否则保留1位小数
    
    示例：
        21.5  → 21.5公里
        10.0  → 10公里
    """
    if value % 1 == 0:
        return f"{int(value)}公里"
    else:
        return f"{value:.1f}公里"


def format_count(value: int) -> str:
    """
    次数转换：整数
    
    示例：
        5 → 5次
    """
    return f"{int(value)}次"


def format_weight(value: float) -> str:
    """
    体重变化：保留1位小数，带符号
    
    示例：
        -2.5 → -2.5kg
        +1.2 → +1.2kg
    """
    sign = "+" if value > 0 else ""
    return f"{sign}{value:.1f}kg"


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("用法: python3 format_values.py <value> <type>")
        print("类型: pace, duration, distance, count, weight")
        sys.exit(1)
    
    value_str = sys.argv[1]
    format_type = sys.argv[2]
    
    try:
        value = float(value_str)
    except ValueError:
        print(f"错误：无法解析数值 '{value_str}'")
        sys.exit(1)
    
    if format_type == "pace":
        result = format_pace(value)
    elif format_type == "duration":
        result = format_duration(value)
    elif format_type == "distance":
        result = format_distance(value)
    elif format_type == "count":
        result = format_count(int(value))
    elif format_type == "weight":
        result = format_weight(value)
    else:
        print(f"错误：未知的转换类型 '{format_type}'")
        sys.exit(1)
    
    print(result)
