#!/usr/bin/env python3
"""
calc_stats.py (v3 - 支持四则运算)
对打卡记录进行统计计算，支持：计数、累计值、平均值、最大最小值、四则运算。

v3 更新：
- 新增 avg 模式（平均值）
- 新增 max/min 模式（最大最小值）
- 新增 divide_sum 模式（两字段累加后相除，用于计算平均配速等）
- 新增 multiply_sum 模式（乘以系数后累加，用于计算卡路里等）

v2 更新：
- 支持从嵌套的 data 对象中提取字段
- 兼容 v5 的 user_id 字段
- 向后兼容扁平结构

用法:
    python3 calc_stats.py <records_json> <members_json> [OPTIONS]

参数:
    records_json  - 打卡记录 JSON 字符串（load_records.py 的输出）
    members_json  - 成员列表 JSON 字符串，如 '["Alice","Bob","Carol"]'
    --metric      - 主要统计字段，如 "distance"、"duration"
    --metric2     - 次要统计字段（divide_sum 模式使用）
    --factor      - 乘法系数（multiply_sum 模式使用，默认 1.0）
    --mode        - 统计模式（默认 count）：
                    count            - 统计打卡次数
                    sum              - 累计数值字段
                    avg              - 平均值
                    max              - 最大值
                    min              - 最小值
                    divide_sum       - 两字段累加后相除（如：总时长÷总距离=平均配速）
                    multiply_sum     - 乘以系数后累加（如：总距离×60=总卡路里）
                    last_minus_first - 期末值 - 期初值（差值）

输出:
    JSON 对象，每个成员的统计结果：
    {
      "Alice": { "count": 5, "value": 120.5, "records": [...] },
      "Bob":   { "count": 0, "value": 0,     "records": [] },
      ...
    }

示例:
    # 统计打卡次数
    python3 calc_stats.py '[...]' '["Alice"]' --mode count
    
    # 累计距离
    python3 calc_stats.py '[...]' '["Alice"]' --mode sum --metric distance
    
    # 平均距离
    python3 calc_stats.py '[...]' '["Alice"]' --mode avg --metric distance
    
    # 最远距离
    python3 calc_stats.py '[...]' '["Alice"]' --mode max --metric distance
    
    # 平均配速（总时长÷总距离）
    python3 calc_stats.py '[...]' '["Alice"]' --mode divide_sum --metric duration --metric2 distance
    
    # 总卡路里（总距离×60）
    python3 calc_stats.py '[...]' '["Alice"]' --mode multiply_sum --metric distance --factor 60
"""

import sys
import json
import argparse
from collections import defaultdict


def get_field_value(record, field):
    """
    从记录中提取字段值，支持嵌套路径
    
    查找优先级：
    1. 顶层字段：record[field]
    2. data 子对象：record["data"][field]
    
    Args:
        record: 打卡记录字典
        field: 字段名
    
    Returns:
        字段值或 None
    
    Examples:
        # 扁平结构
        r = {"user": "张三", "distance": 10}
        get_field_value(r, "distance")  # 返回 10
        
        # 嵌套结构
        r = {"user": "张三", "data": {"distance": 10}}
        get_field_value(r, "distance")  # 返回 10
    """
    # 优先从顶层获取（扁平结构）
    if field in record:
        return record[field]
    
    # 回退到 data 子对象（嵌套结构）
    if 'data' in record and isinstance(record['data'], dict):
        if field in record['data']:
            return record['data'][field]
    
    return None


def calc_stats(records: list, members: list, metric: str = None, metric2: str = None, factor: float = 1.0, mode: str = "count") -> dict:
    result = {m: {"count": 0, "value": 0, "records": []} for m in members}

    # 收集每人记录（兼容 v5 的 user_id 字段）
    by_user = defaultdict(list)
    for r in records:
        # 优先使用 user_id（v5），回退到 user（旧版）
        user = r.get("user_id") or r.get("user", "")
        by_user[user].append(r)

    for member in members:
        recs = by_user.get(member, [])
        result[member]["count"] = len(recs)
        result[member]["records"] = recs

        if mode == "count":
            result[member]["value"] = len(recs)
        elif mode == "sum" and metric:
            # 使用 get_field_value 支持嵌套字段
            total = sum(
                float(get_field_value(r, metric) or 0) 
                for r in recs 
                if get_field_value(r, metric) is not None
            )
            result[member]["value"] = round(total, 4)
        elif mode == "avg" and metric:
            # 平均值：Σ value / count
            values = [
                float(get_field_value(r, metric)) 
                for r in recs 
                if get_field_value(r, metric) is not None
            ]
            if values:
                result[member]["value"] = round(sum(values) / len(values), 4)
            else:
                result[member]["value"] = 0
        elif mode == "max" and metric:
            # 最大值
            values = [
                float(get_field_value(r, metric)) 
                for r in recs 
                if get_field_value(r, metric) is not None
            ]
            result[member]["value"] = round(max(values), 4) if values else 0
        elif mode == "min" and metric:
            # 最小值
            values = [
                float(get_field_value(r, metric)) 
                for r in recs 
                if get_field_value(r, metric) is not None
            ]
            result[member]["value"] = round(min(values), 4) if values else 0
        elif mode == "last_minus_first" and metric:
            # 使用 get_field_value 支持嵌套字段
            values = [
                float(get_field_value(r, metric)) 
                for r in recs 
                if get_field_value(r, metric) is not None
            ]
            if len(values) >= 2:
                result[member]["value"] = round(values[-1] - values[0], 4)
            elif len(values) == 1:
                result[member]["value"] = 0
            else:
                result[member]["value"] = 0
        elif mode == "divide_sum" and metric and metric2:
            # 两字段累加后相除：Σ(metric1) / Σ(metric2)
            sum1 = sum(
                float(get_field_value(r, metric) or 0) 
                for r in recs 
                if get_field_value(r, metric) is not None
            )
            sum2 = sum(
                float(get_field_value(r, metric2) or 0) 
                for r in recs 
                if get_field_value(r, metric2) is not None
            )
            if sum2 != 0:
                result[member]["value"] = round(sum1 / sum2, 4)
            else:
                result[member]["value"] = 0
        elif mode == "multiply_sum" and metric:
            # 乘以系数后累加：Σ(value × factor)
            total = sum(
                float(get_field_value(r, metric) or 0) * factor
                for r in recs 
                if get_field_value(r, metric) is not None
            )
            result[member]["value"] = round(total, 4)
        else:
            result[member]["value"] = len(recs)

    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("records_json")
    parser.add_argument("members_json")
    parser.add_argument("--metric", default=None, help="Primary metric field (e.g., distance, duration)")
    parser.add_argument("--metric2", default=None, help="Secondary metric for divide_sum mode")
    parser.add_argument("--factor", type=float, default=1.0, help="Multiplication factor for multiply_sum mode")
    parser.add_argument("--mode", default="count", 
                        choices=["count", "sum", "avg", "max", "min", "divide_sum", "multiply_sum", "last_minus_first"],
                        help="Statistics mode")
    args = parser.parse_args()

    records = json.loads(args.records_json)
    members = json.loads(args.members_json)
    stats = calc_stats(records, members, metric=args.metric, metric2=args.metric2, factor=args.factor, mode=args.mode)
    print(json.dumps(stats, ensure_ascii=False, indent=2))
