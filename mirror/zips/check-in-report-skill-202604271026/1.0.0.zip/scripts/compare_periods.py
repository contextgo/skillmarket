#!/usr/bin/env python3
"""
compare_periods.py
计算两个周期的同比或环比变化。

用法:
    python3 compare_periods.py <current_stats_json> <previous_stats_json> [--direction asc|desc]

参数:
    current_stats_json   - 当前周期 calc_stats.py 输出的 JSON 字符串
    previous_stats_json  - 上一周期 calc_stats.py 输出的 JSON 字符串
    --direction          - 排序方向：asc（越小越好），desc（越大越好，默认）

输出:
    JSON 对象，每人新增 delta（变化量）、delta_pct（变化率%）、rank（当前排名）字段：
    {
      "Alice": { "value": 120, "prev_value": 100, "delta": 20, "delta_pct": 20.0, "rank": 1 },
      ...
    }

示例:
    python3 compare_periods.py '{"Alice":{"value":120},"Bob":{"value":90}}' \
                               '{"Alice":{"value":100},"Bob":{"value":95}}'
"""

import sys
import json
import argparse


def compare(current: dict, previous: dict, direction: str = "desc") -> dict:
    result = {}
    for member, cur_data in current.items():
        cur_val = cur_data.get("value", 0)
        prev_val = previous.get(member, {}).get("value", 0)
        delta = round(cur_val - prev_val, 4)
        if prev_val != 0:
            delta_pct = round((delta / abs(prev_val)) * 100, 2)
        else:
            delta_pct = None

        result[member] = {
            **cur_data,
            "prev_value": prev_val,
            "delta": delta,
            "delta_pct": delta_pct,
        }

    # 排名
    reverse = (direction == "desc")
    ranked = sorted(result.keys(), key=lambda m: result[m].get("value", 0), reverse=reverse)
    for i, member in enumerate(ranked, 1):
        result[member]["rank"] = i

    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("current_json")
    parser.add_argument("previous_json")
    parser.add_argument("--direction", default="desc", choices=["asc", "desc"])
    args = parser.parse_args()

    current = json.loads(args.current_json)
    previous = json.loads(args.previous_json)
    result = compare(current, previous, direction=args.direction)
    print(json.dumps(result, ensure_ascii=False, indent=2))
