#!/usr/bin/env python3
"""
load_records.py
从打卡活动的 records/ 目录中读取指定时间周期内的打卡记录。

用法:
    python3 load_records.py <records_dir> <start_date> <end_date>

参数:
    records_dir  - 打卡活动的 records/ 目录路径（如 /root/.openclaw/workspace/skills/paper-reading-check-in-active-20260403/records）
    start_date   - 开始日期（含），格式 YYYY-MM-DD
    end_date     - 结束日期（含），格式 YYYY-MM-DD

输出:
    JSON 数组，包含该周期内所有有效打卡记录（valid=true）

示例:
    python3 load_records.py ./records 2026-03-31 2026-04-06
"""

import os
import sys
import json
from datetime import date, timedelta


def daterange(start: date, end: date):
    cur = start
    while cur <= end:
        yield cur
        cur += timedelta(days=1)


def load_records(records_dir: str, start_date: str, end_date: str) -> list:
    start = date.fromisoformat(start_date)
    end = date.fromisoformat(end_date)

    all_records = []
    for d in daterange(start, end):
        filepath = os.path.join(records_dir, f"{d.isoformat()}.json")
        if not os.path.exists(filepath):
            continue
        with open(filepath, "r", encoding="utf-8") as f:
            try:
                records = json.load(f)
            except json.JSONDecodeError:
                continue
        # 只保留 valid=true 的记录
        valid = [r for r in records if r.get("valid", True)]
        all_records.extend(valid)

    return all_records


if __name__ == "__main__":
    if len(sys.argv) < 4:
        print("Usage: load_records.py <records_dir> <start_date> <end_date>")
        sys.exit(1)
    records_dir = sys.argv[1]
    start_date = sys.argv[2]
    end_date = sys.argv[3]
    records = load_records(records_dir, start_date, end_date)
    print(json.dumps(records, ensure_ascii=False, indent=2))
