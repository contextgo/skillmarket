#!/usr/bin/env python3
"""
rank_and_qualify.py
对统计结果进行排名与达标判定。

用法:
    python3 rank_and_qualify.py <stats_json> <target> [--direction asc|desc] [--metric value]

参数:
    stats_json   - calc_stats.py 或 compare_periods.py 输出的 JSON 字符串
    target       - 达标线（数值），如 5（打卡5次）或 30（30分钟）
    --direction  - 排序方向：asc（越小越好），desc（越大越好，默认）
    --metric     - 用于比较的字段（默认 value）

输出:
    JSON 数组（按排名升序），每项包含 rank、member、value、qualified（是否达标）字段：
    [
      { "rank": 1, "member": "Alice", "value": 7, "qualified": true },
      { "rank": 2, "member": "Bob",   "value": 3, "qualified": false },
      ...
    ]

示例:
    python3 rank_and_qualify.py '{"Alice":{"value":7},"Bob":{"value":3}}' 5
    python3 rank_and_qualify.py '{"Alice":{"value":7},"Bob":{"value":3}}' 5 --direction desc
"""

import sys
import json
import argparse


def rank_and_qualify(stats: dict, target: float, direction: str = "desc", metric: str = "value") -> list:
    reverse = (direction == "desc")
    items = [(member, data.get(metric, 0)) for member, data in stats.items()]
    items.sort(key=lambda x: x[1], reverse=reverse)

    result = []
    for i, (member, val) in enumerate(items, 1):
        if direction == "desc":
            qualified = val >= target
        else:
            qualified = val <= target

        entry = {
            "rank": i,
            "member": member,
            "value": val,
            "qualified": qualified,
        }
        # 附带原始记录数量
        if "count" in stats.get(member, {}):
            entry["count"] = stats[member]["count"]
        result.append(entry)

    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("stats_json")
    parser.add_argument("target", type=float)
    parser.add_argument("--direction", default="desc", choices=["asc", "desc"])
    parser.add_argument("--metric", default="value")
    args = parser.parse_args()

    stats = json.loads(args.stats_json)
    result = rank_and_qualify(stats, args.target, direction=args.direction, metric=args.metric)
    print(json.dumps(result, ensure_ascii=False, indent=2))
