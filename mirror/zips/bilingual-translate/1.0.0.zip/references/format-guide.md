# 术语文档格式说明

## 支持格式

### 1. Excel 格式（推荐）

文件扩展名：`.xlsx`、`.xls`

列结构：
- A 列：中文术语
- B 列：英文术语

示例：

| A 列 | B 列 |
|------|------|
| 人工智能 | Artificial Intelligence |
| 机器学习 | Machine Learning |
| 深度学习 | Deep Learning |

### 2. CSV 格式

文件扩展名：`.csv`

格式：`中文术语,英文术语`

示例：
```csv
人工智能,Artificial Intelligence
机器学习,Machine Learning
```

### 3. TXT 格式

文件扩展名：`.txt`

每行一个术语对，分隔符支持：
- 逗号：`人工智能,Artificial Intelligence`
- 竖线：`人工智能 | Artificial Intelligence`
- Tab：`人工智能\tArtificial Intelligence`

示例：
```
人工智能,Artificial Intelligence
机器学习,Machine Learning
深度学习,Deep Learning
```

## 术语优先级

1. 术语表中的术语 → 直接替换，不翻译
2. 术语表之外的词汇 → 由翻译引擎判断

## 注意事项

- 术语表区分大小写（英文部分）
- 术语表中的空格会被精确匹配，确保证确对应
- 重复术语以首次出现为准
