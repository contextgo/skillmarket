# Examples

规范来源：`embedded-hk-card-api-spec.md`（无需外部接口文档 URL）。

## Example 1

`语言=Java；包根=com.example.integration.gcp.hkcard；签名底座已按 gcp-api-quick-integration 就绪。请根据内嵌规范生成跨境香港发卡全部出站接口的模型、Service、回调 Handler 骨架，以及每个出站接口的真实 HTTP 集成测试。`

## Example 2

`在当前 Spring Boot 工程中增加 hk-card 模块：仅生成卡管理 3000～3014、卡交易 4000～4006 相关 DTO 与 Service；回调仅 3005、4002；测试仍要求真实 HTTP。`

预期行为：

1. 自动检查签名底座；缺失则先引导或生成 **`gcp-api-quick-integration`**，并满足 **`signing-and-verify-spec.md`** 与 **`implementation-pitfalls.md`**。
2. 仅依据 **`embedded-hk-card-api-spec.md`** 生成业务代码；**不**重复生成签名/验签实现。
3. 所有请求/响应/回调模型 **逐字段中文注释**（与内嵌规范表一致）；公共 query、公共响应字段与特殊接口（如 7000 上传）行为与文档一致。
4. 每个 **出站** 接口有对应 **真实 HTTP 集成测试**（`@SpringBootTest(classes=启动类)`，禁止 Mock HTTP 客户端）；交付说明含 `application-local.properties`（或等价）、CI 跳过策略及 Java 8 限制说明。
