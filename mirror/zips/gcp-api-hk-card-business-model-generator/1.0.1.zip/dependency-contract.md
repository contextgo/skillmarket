# Dependency Contract With Signing Foundation

## Principle

本 Skill 仅生成业务模型、业务服务、回调 Handler，不生成签名/验签算法实现细节。
签名与验签规则统一复用 **`gcp-api-quick-integration`**（`signing-and-verify-spec.md`、`implementation-pitfalls.md`）。

## Specification Source

接口字段、path、方向、公共参数与附录引用真源：**`embedded-hk-card-api-spec.md`**。

## Outbound Calls

- 业务 Service 仅调用既有签名 HTTP 客户端（如 `signedPost`、`postJson`、文件上传专用方法等）。
- 禁止在业务层拼接待签名串或计算签名。
- **公共 query**：`authcus`、`merid`、`reqid` 由底座或统一装配层附加到 URL，与内嵌规范一致。

## Inbound Callbacks

通联 → 合作方的通知类接口路径由内嵌规范与合作方在门户配置的 **根 URL + 相对 path** 组成。文档中出现的回调相对路径包括但不限于（以 `embedded-hk-card-api-spec.md` 为准，生成时须为每一类回调实现 Handler 骨架）：

- `acctbalauditrst`（入账通知 6003）
- `applynotify`（支付类申请单状态通知 2004）
- `bnfauditrst`（银行账户状态通知 8006）
- `vpaauditrst`（卡申请单状态通知 3005）
- `cardchangenotify`（卡状态变更通知 3207）
- `cardtrxrst`（授权交易通知 4002）
- `cusauditrst`（子商户审核通知 5002）
- `optresultnotify`（3DS 验证码发送结果通知 4006）

回调统一 **先验签再解析**；验签实现须与 **`gcp-api-quick-integration/signing-and-verify-spec.md`** 一致：**响应/回调侧签名为 hex**，`hexDecode` 后再验签。

## Implementation Notes（避免客户重复踩坑）

1. **业务 Service** 只负责组装 DTO 并调用底座 HTTP 客户端；**不得**自行改 `X-AGCP-Date` / `Send` / `Auth` / `Crdt` 的生成规则。
2. 若底座由本仓库 Skill 生成，生成后应让客户对照 **`implementation-pitfalls.md`** 做一次头字段与 hex 签名自检。
3. **测试（Java/Spring 出站）**：须生成 **真实 HTTP 集成测试**，**禁止** Mock 签名 HTTP 客户端；交付说明中须写明 `base-url`、密钥与本地配置文件、`@SpringBootTest(classes=…)` 及无密钥时跳过整类的策略。
4. **Java 8**：业务测试与公共代码避免 `isBlank`、`Path.of`、`Files.readString`。
5. **可观测性**：由底座或客户端统一记录请求 URL、body、响应状态与 body；请求头日志应对签名与 keyid **脱敏**。
6. **DTO 形态（Java）**：业务请求/响应须为 **独立源文件 + JavaBean**；**每个字段须有中文注释**（JavaDoc），释义来自内嵌规范表「中文名称」「备注」等。
7. **请求 JSON**：**`null` 字段不上送**（`NON_NULL` 或等价），**摘要与 HTTP body 字节一致**（见 `implementation-pitfalls.md` 第 2.1 节）。
8. **7000 文件上传**：`Content-Type` 为 `application/octet-stream`；签名 payload 为 **原始文件字节**（非 Base64 字符串）；与内嵌规范及底座实现保持一致。
