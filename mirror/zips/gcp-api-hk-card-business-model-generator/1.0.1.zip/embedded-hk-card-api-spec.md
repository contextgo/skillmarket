# 跨境香港发卡API文档（脱敏）

| 版本 | 日期 | 作者 | 说明 | 上线日期 |
| --- | --- | --- | --- | --- |
| 1.0 | 2024-03 | 跨境开发团队 |  | 2024-07-24 |
| 2.0 | 2024-07-15 | 跨境开发团队 | *   新增接口<br>    <br>    *   3007 查询卡支付信息<br>        <br>    <br>    *   4000 授权交易明细查询<br>        <br>    *   4001 已入账交易明细查询<br>        <br>    *   4002 授权交易通知<br>        <br>*   修改接口<br>    <br>    *   3100缴纳保证金：字段交易对手/采购内容/保证金对应合同协议不强制必填 | 2024-07-24 |
| 3.0 | 2024-07-24 | 跨境开发团队 | *   新增接口<br>    <br>    *   3002 新增通华金服共享卡场景<br>        <br>    *   3004 申请通华金服共享卡子卡<br>        <br>*   修改接口<br>    <br>    *   3006 卡申请单查询：新增响应信息：担保金额、担保金币种<br>        <br>    *   3005 卡申请单状态通知：同3006<br>        <br>*   以及一些字段信息描述完善 | 2024-07-24 |
| 4.0 | 2024-08 | 跨境开发团队 | *   新增：<br>    <br>    *   3103-卡保证金存提记录查询接口<br>        <br>    *   3005-卡申请单状态通知、3006卡申请单通知接口，新增卡类型字段<br>        <br>    *   3008-变更通华金服共享卡子卡场景接口<br>        <br>    *   1001-VA入金信息查询新增字段银行编号，分行编号<br>        <br>    *   新增【4.伞型账户入账相关】章节<br>        <br>    *   新增3103-卡保证金存提记录查询<br>        <br>    *   2003-支付类申请单查询，2004-支付类申请单状态通知接口新增.stateexplain字段<br>        <br>*   修改：<br>    <br>    *   6003-入账通知-新增账户币种字段；<br>        <br>    *   2001锁汇询价接口： 修改url及字段名（结算金额、结算币种、手续费币种）<br>        <br>    *   2002-支付类申请单查询、2003支付类申请单状态通知，新增手续费币种字段，删除备注字段。<br>        <br>    *   2000-离岸换汇申请接口删除【~~到账商户号~~】请求字段，换汇默认为同一商户不同币种账户换汇。<br>        <br>    *   调整10.9交易申请单状态<br>        <br>*   对1.9基本对接流程章节介绍细化 | 2024-08-28 |
| 4.1 | 2024-09 | 跨境开发团队 | *   新增<br>    <br>    *   新增3208-查询卡状态<br>        <br>    *   新增附录1116-对接demo<br>        <br>    *   新增接口7005-通华金服共享卡子卡信息下载(加密文件)<br>        <br>    *   新增附录1106-卡状态中的实体卡状态<br>        <br>*   修改<br>    <br>    *   附录1108-支付类交易申请单状态描述做了调整，01，05，12，16状态定义为处理中<br>        <br>    *   8005-银行账户查询接口新增账户+币种查询条件<br>        <br>    *   2000-离岸换汇申请支持输入兑入或者兑出金额<br>        <br>    *   3000主卡申请证件2 描述，港澳台通行证->港澳台身份证 ，新增证件2正反面附件<br>        <br>    *   3000主卡申请新增交易对手方、采购内容、交易对手合同或协议等，3个字段，仅在通华金服共享卡电子卡产品申请时必填<br>        <br>    *   3001子卡申请新增证件2类型和证件2号码，以及证件2附件正反面信息的收集<br>        <br>    *   4000授权交易明细查询新增记账金额和记账币种字段<br>        <br>    *   3002-新增通华金服共享卡场景，币种字段由必填更新为选填，币种字段为空默认全币种，场景为期限和周期的授权笔数，为0时默认不限制；<br>        <br>    *   3004-申请通华金服共享卡子卡，接受卡片邮箱字段由必填更新成选填，接受卡片邮箱为空则不发送邮箱通知<br>        <br>    *   3007-查卡支付信息支持通华金服共享卡子卡查询<br>        <br>    *   3008变更通华金服共享卡子卡场景新增最大授权笔数，最大授权金额，币种信息更新，默认在原场景基础上更新<br>        <br>    *   2.快速开始章节，调用流程图优化 | 2024-09-24 |
| 4.2 | 2024-10 | 跨境开发团队 | *   修改<br>    <br>    *   4002-授权交易通知新增记账金额、记账币种字段<br>        <br>    *   6003-入账通知，新增入金申请的申请单号字段响应<br>        <br>    *   2000-离岸换汇申请，对支付交易申请新增流程状态图<br>        <br>    *   8000-入金申请，新增流程状态图<br>        <br>    *   全文把【通华VPA电子卡】更名为【通华金服共享卡】，把【VPA子卡】更名为【通华金服共享卡子卡】，把【虚实同发】更名为【实体卡】，把【电子卡状态】更名为【卡状态】<br>        <br>    *   3004-申请共享卡子卡接口新增卡有效期字段<br>        <br>    *   3005-卡申请单状态通知接口新增到账金额、到账币种<br>        <br>    *   3006-卡申请单查询接口新增到账金额、到账币种<br>        <br>    *   2002-支付类申请单确认新增字段锁汇超时执行模式<br>        <br>    *   2001-锁汇询价，锁汇有效期调整为3分钟<br>        <br>    *   8001-入金申请确认接口，其他材料由必填更改为非必填<br>        <br>    *   3102-卡余额查询接口，支持共享子卡余额和授权总额度查询<br>        <br>    *   4000-授权交易明细查询接口，新增交易响应码、交易响应描述字段<br>        <br>    *   4002-授权交易通知接口，新增交易响应码、交易响应描述字段<br>        <br>    *   1104-授权交易类型枚举，新增【账户验证】、【保证金缴纳】、【保证金提现】<br>        <br>    *   5001-子商户创建接口-字段顺序整理排列<br>        <br>    *   3208-查卡状态接口，新增实体卡状态<br>        <br>    *   3206-解除销卡新增描述，共享卡子卡不支持解除销卡<br>        <br>    *   3203-卡挂失新增描述，虚拟卡（包括主卡和子卡）不支持挂失操作。<br>        <br>    *   附录1102-支付交易类型，细化详细描述<br>        <br>    *   附录1103-卡申请交易类型，细化详细描述<br>        <br>    *   7005-通华金服共享卡子卡信息下载、7004-通华金服共享卡子卡信息下载接口，新增说明【仅可下载申请单7天内文件，逾期不可下载】<br>        <br>*   新增<br>    <br>    *   8000-入金申请，新增状态时序图 <br>        <br>    *   2000-离岸换汇申请，新增状态时序图<br>        <br>    *   6.1卡片申请，新增卡状态时序图<br>        <br>    *   新增2005-汇率查询接口<br>        <br>    *   新增3009-共享卡子卡支付信息批量查询接口<br>        <br>    *   新增4003-授权交易历史明细查询<br>        <br>    *   新增4004-已入账交易历史明细查询接口 | 2024-10-30晚 |
| 4.3 | 2024-11 | 跨境开发团队 | *   修改<br>    <br>    *   3004申请通华金服共享卡子卡新增申请单流水字段<br>        <br>    *   8000-入金申请接口新增商户号字段，兼容子商户独立账户场景，入金到指定商户账户<br>        <br>    *   8003-银行账户新增接口新增归属商户号字段，指定银行账户归属于指定商户<br>        <br>    *   8005-银行账户查询接口新增归属商户号字段响应<br>        <br>    *   3002-新增共享卡场景接口新增MCC/商户号黑白名单要素设置<br>        <br>    *   3003-共享卡场景查询接口新增MCC/商户号黑白名单要素信息<br>        <br>    *   1112-地区代码附录更新<br>        <br>*   新增<br>    <br>    *   新增3010-申请共享卡子卡（同步设置卡场景）接口<br>        <br>    *   新增3011-查看共享卡子卡场景接口 | 2024-11-27晚 |
| 4.4 | 2024-11 | 跨境开发团队 | **从该版本开始，对接口卡号做脱敏处理，对以往接口进行改造，新旧版本兼容，V4.3版本请点击下面链接跳转**<br>[https://alidocs.dingtalk.com/i/nodes/dpYLaezmVNLRlAXgfzZgwaA68rMqPxX6?utm\_scene=team\_space: https://alidocs.dingtalk.com/i/nodes/dpYLaezmVNLRlAXgfzZgwaA68rMqPxX6?utm\_scene=team\_space](https://alidocs.dingtalk.com/i/nodes/dpYLaezmVNLRlAXgfzZgwaA68rMqPxX6?utm_scene=team_space)<br>*   涉及脱敏处理接口：<br>    <br>    *   3001-子卡申请<br>        <br>    *   3004-申请通华金服共享卡子卡<br>        <br>    *   3010-申请共享卡子卡（同步设置卡场景）<br>        <br>    *   3005-卡申请单状态通知<br>        <br>    *   3006-卡申请单查询<br>        <br>    *   3007-查询卡支付信息<br>        <br>    *   3008-变更通华金服共享卡子卡场景信息<br>        <br>    *   3100-缴纳保证金<br>        <br>    *   3101-提取保证金<br>        <br>    *   3102-卡余额查询<br>        <br>    *   3103-卡保证金存提记录查询<br>        <br>    *   3200-卡片激活<br>        <br>    *   3201-卡止付<br>        <br>    *   3202-解除卡止付<br>        <br>    *   3203-卡挂失<br>        <br>    *   3204-解除卡挂失<br>        <br>    *   3205-销卡<br>        <br>    *   3206-解除销卡<br>        <br>    *   3207-卡状态变更通知<br>        <br>    *   3208-查询卡状态<br>        <br>    *   4000-授权交易明细查询<br>        <br>    *   4001-已入账交易明细查询<br>        <br>    *   4002-授权交易通知<br>        <br>    *   4003-授权交易历史明细查询<br>        <br>    *   4004-已入账交易历史明细查询<br>        <br>    *   7005-共享卡子卡信息下载<br>        <br>*   修改<br>    <br>    *   3100-缴纳保证金接口支持费用外扣，缴纳保证金全额到账<br>        <br>*   删除<br>    <br>    *   删除7004-通华金服共享卡子卡信息下载（免密）接口<br>        <br>*   新增<br>    <br>    *   新增3012-查询支持卡产品类型接口 | 2024-12-25晚 |
| 4.4 | 2024-12 | 跨境开发团队 | *   修改<br>    <br>    *   3100-缴纳保证金接口支持费用外扣，缴纳保证金全额到账 |  |
| 4.5 | 2025-02 | 跨境开发团队 | *   修改<br>    <br>    *   3000-主卡申请接口修改字段【出生日期,性别,手机号码所属地区,手机号码】为非必填<br>        <br>*   新增<br>    <br>    *   4005-授权+入账交易信息查询 |  |
| 4.6 | 2025-04 | 跨境开发团队 | 新增卡产品：<br>4010-通华金服VISA虚拟卡-HKD<br>4011-通华金服VISA虚拟卡-USD | 2025-04-23晚 |
| 4.7 | 2025-04 | 跨境开发团队 | 新增卡产品：<br>4001-通华金服VISA虚拟卡-USD<br>4002-通华金服VISA虚拟卡-USD<br>4003-通华金服VISA虚拟卡-USD<br>4004-通华金服VISA虚拟卡-HKD<br>删除卡产品：<br>4010-通华金服VISA虚拟卡-HKD<br>4011-通华金服VISA虚拟卡-USD | 2025-05-16 |
| 4.8 | 2025-09 | 跨境开发团队 | 添加字段：is3ds（交易是否3DS验证）涉及接口：4000-授权交易明细查询、4002-授权交易通知、4003-授权交易历史明细查询、4005-授权+入账交易信息查询； | 2025-09-10 |
| 4.9 | 2025-10 | 跨境开发团队 | 新增2006-生态圈转账接口<br>新增2007-同名转账接口<br>4000-授权交易明细查询、4002-授权交易通知、4003-授权交易历史明细查询三个接口，加入“受理机构所属国家”【acqcountry】 | 2025-10-15 |
| 4.10 | 2025-11 | 跨境开发团队 | *   新增【6.4卡共享资金管理】模块<br>    <br>       3301-新增共享资金账户<br>       3302-共享资金追加<br>       3303-共享资金释放<br>       3304-共享资金账户查询<br>       3012-设置资金共享卡额度<br>*   3000-主卡申请接口新增字段：卡账户模式【accountmode】和共享资金账户【sharefundid】<br>    <br>*   新增1109-卡产品类型-【4020-自建卡账户虚拟卡】 | 2025-11-26 |
| 4.11 | 2025-12 | 跨境开发团队 | *   调整【3000-主卡申请】接口，针对4020卡产品放开可选择卡激活模式<br>    <br>*   调整【3001-子卡申请】接口，针对主卡4020卡产品放开可选择卡激活模式<br>    <br>*   新增【3013-虚拟卡激活】接口，针对4020卡产品的主卡和子卡，在待激活状态下激活卡  <br>    <br>*   附录1106-卡状态：新增卡状态码：14-待激活<br>    <br>*   新增1109-卡产品类型-【4020-自建卡账户虚拟卡】 | 2025-12-18 |
| 4.1.1 | 2026-01 | 跨境开发团队 | *   新增【4006-3DS验证码发送结果通知】接口 | 2026-1-14 |
| 4.1.2 | 2026-02 | 跨境开发团队 | *   新增【3014-修改持卡人邮箱】接口<br>    <br>*   新增字段【对卡收取手续费】【对卡收取手续费币种】，涉及接口：4000-授权交易明细查询、4002-授权交易通知、4003-授权交易历史明细查询、4005-授权+入账交易查询<br>    <br>*   3000-主卡申请接口新增【交易相关手续费扣收方式】字段 | 2026-2-05 |
| 4.1.3 | 2026-04 | 跨境开发团队 | 业务名称更改：保证金缴纳（原）改成 卡充值<br>                        保证金提现（原）改成 卡提现 |  |

# 基本约定

## 通讯方式

使用HTTPS通讯，统一使用POST方式。

## 数据格式

1.    HTTP请求和响应报文体格式使用JSON格式，字符编码统一使用UTF-8，文件上传下载请求除外。

2.    请求体大小限制20M；注意文件上传时单文件控制在合适大小（因为Base64编码之后数据量会增加）。

3.    时间格式：报文体内时间格式如无特殊说明，统一严格使用ISO格式\[yyyy-MM-dd'T'HH:mm:ssZ\]，该格式带有时区。

4.    接口说明表格内必输列字母意义：Y是必填；C是某些情况必填；O是选填；A是多选一；

## 公共HTTP头

所有接口的请求及响应包含的HTTP头

特别说明：HTTP头两个时间必须使用UTC时间,并且使用指定格式而非ISO格式。

例子：Headers={

“Content-Type”:”application/json”,

"X-AGCP-Auth":"GCP1-RSA-SHA512:33acb1c1e54565c31509e1cd26542e7ecda89ab1144ad8c61a414d7a5b72acc9",

"X-AGCP-Crdt":"HDXxxxxx:20200220:gcpservice",

"X-AGCP-Date":"20200220041455",

"X-AGCP-Send":"20200220041455795"

}

| HTTP头名称 | 取值说明 | 请求 | 响应 | 备注 |
| --- | --- | --- | --- | --- |
| Content-Type | application/json;charset=UTF-8 | Y | Y | 文件上传及下载除外,文件上传下载为application/octet-stream |
| X-AGCP-Crdt | 签名密钥ID:UTC日期:范围【固定gcpservice】 | Y | Y | 秘钥ID需要商户登陆门户端，设置-秘钥设置界面，选择对应加密方式，点击“生成”获取秘钥ID。最后要确保点击提交生效。 |
| X-AGCP-Date | UTC时间戳，YYYYMMDDHHmmss | Y | Y | 参与签名及超时校验 |
| X-AGCP-Send | 发送报文的UTC时间，YYYYMMDDHHmmssSSS | Y | Y | 用于评估网络传输时延 |
| X-AGCP-Auth | 签名算法:签名值，仅请求包含 | Y | Y | 签名算法取值GCP1-RSA-SHA512 |

## 公共请求参数

说明：公共参数需放在url以查询字符串形式上送，不可放在报文体中。这样方便安全校验和业务处理分开，同时也方便再各节点追踪请求。

例子：[https://xxx.yyy.com/gcpapi/aaa/bbb?authcus=665000000000000&merid=668000000000000&reqid=1231231](https://xxx.yyy.com/gcpapi/aaa/bbb?authcus=665000000000000&merid=668000000000000&reqid=1231231)

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 客户号 | authcus | String | 15 | Y | 所属或受托客户号 |
| 商户号 | merid | String | 15 | C | 开展业务的商户号（merid） |
| 请求流水号 | reqid | String | 32 | Y | 请求方对每个请求生成唯一流水号，用于标识请求 |

## 公共响应字段

说明：公共响应字段在报文体中，与特定业务额外的响应字段在同一个json结构体内。

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 响应码 | rspcode | String | 8 | Y | 0000表示成功，响应码参考附录【1101-跨境平台API响应码】 |
| 响应信息 | rspinfo | String | 300 | Y | 响应结果描述 |
| 客户号 | authcus | String | 15 | C | 非成功响应可能不存在 |
| 商户号 | merid | String | 15 | O | 非成功响应可能不存在 |
| 请求流水号 | reqid | String | 32 | C | 非成功响应可能不存在 |

## 客户端健壮性

本文档内任何接口在将来都可能增加新的元素或字段或取值，客户端应用程序应基于未来可能有变化的假设进行设计，不应假定报文内仅仅包含已经定义的元素或字段或取值。

## 请求结果处理※

_**当一个请求发生超时或网络错误或者HTTP响应码不在预期内时，客户端应该发起相应的查询交易进行结果确认，以避免双方结果的不一致。如果客户端无法自动处理返回的结果，应通知运营人员联系通联运营人员进行确认处理。**_

## 请求频率限制

为避免不必要的资源浪费，请务必尽量减少不必要的客户端请求，尤其是查询请求的频率。通联根据一定的策略对请求频率过高的客户端进行限制。

##  基本对接流程

域名

测试环境用卡平台地址：https://global-test.allinpay.com/chargecard/dist/#/login

测试环境API Base URL：https://global-test.allinpay.com/gcpapi

生产环境API Base URL：https://global.allinpay.com/gcpapi

生产环境用卡平台地址：https://cards.allinpayfs.com/#/login

流程：

1.  对接方应联系通联客户经理协助开通测试环境测试客户号并初始化门户登录密码。该环节对接方需获得：商户管理员登录账号、商户管理员登录密码，客户号，商户号。用商户管理员登录账号和商户管理员登录密码，登录用卡平台系统；（首次登录默认密码：P2DQAu3q）

2.  对接方根据账号、密码登录门户端，第一次登录需要重置登录密码（测试环境短信验证码默认为000000）。修改成功后重新登录。

3.  进入用卡平台首页。设置API接入秘钥信息，获取通联公钥信息、配置商户公钥信息、设置通知地址及敏感数据加密密钥。

商户RSA密钥对生成可参考以下方式：

1.  利用openssl工具：openssl genpkey -algorithm RSA -out private\_key.pem -pkeyopt rsa\_keygen\_bits:1024  
                               openssl rsa -pubout -in private\_key.pem -out public\_key.pem
    
2.  利用在线生成RSA密钥对工具或其他生成方式；
    

![image](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/QvjnAAwy51J4nXo5/img/4a4e5ffd-3f80-4b0a-82f2-90ac49357c1d.png)

![image](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/QvjnAAwy51J4nXo5/img/92aa1757-2d40-4c94-88c2-42cdb1acb5e4.png)

注：配置通知路径使用场景在于通联平台方主动向对接客户发的通知接口所使用的请求地址，如入账通知，支付类申请单状态通知等。

配置路径只需配置请求根地址即可；

例如：配置通知路径为：https://www.abc.com/api/contr

   入账通知接口发起通知为：https://www.abc.com/api/contr/acctbalauditrst

   卡申请单状态通知通知接口发起通知为：https://www.abc.com/api/contr/vpaauditrst

等等；

## 安全签名

**可以参考附录【1116-对接demo】**

**签名算法：**

RSA2：签名算法：SHA256WithRSA。

1、 对请求报文计算摘要Hash（散列算法SHA256）

如果请求报文为空，则使用空字符串作为哈希函数的输入

如JAVA:

MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");

messageDigest.update(body);

messageDigest.digest();

2、 待签名符串

| StringBuilder signstr = new StringBuilder();<br>signstr.append(algo).append("\n") //签名算法，固定值：GCP1-RSA-SHA512<br>.append(date).append("\n")  // 请求时间yyyyMMddHHmmss ，与报文头中X-AGCP-Date保持一致<br>.append(uri).append("\n")  // URI的绝对路径部分，从HTTP主机到开始查询字符串参数（如果有）的问号字符（“?”）<br>                                                                              如：/gcpapi/info/getexrate<br>.append(queryStr).append("\n")  // 本次请求url中get参数，<br>                                                                            1、按字符代码点以升序顺序对参数名称进行排序。具有重复名称的参数应按值进行排序。<br>                                                                            2、将参数与其对应值,组合成“参数=参数值”的格式，并且把这些参数用&字符连接起来<br>.append(encodeHex(digest));           // 将步骤1中计算的摘要结果转16进制字符串<br>StringToSign 实例：<br>GCP1-RSA-SHA512<br>20200116063600<br>/gcpapi/info/getexrate<br>authcus=665000000000107&merid=668000000000176&reqid=202001160635599700<br>8063559bb22c9e3efc3f8e56aaad264d35524f8527f002a111f0a79de8d5230d |
| --- |
|  |

3、计算签名

| HexEncode(sha512withrsa(StringToSign))<br>签名过程除了说明参数要Hex转换为16进制字符串，其余过程都是字节码内容。<br>商户自己使用RSA算法生产的秘钥对，用私钥签名StringToSign，然后转换成十六进制字符串 |
| --- |

## 敏感数据解密

 解密方式：AES加密

对响应敏感数据的密文解密，如3007-查询卡支付信息中的cvv等信息

"cvv":"nYy7gMyV6l6C5MadMjp80w=="

需对密文做AES解密，密钥为在“API管理”-“敏感信息密钥设置”中所设置的密钥。

敏感数据解密，可以参考附录【1116-对接demo】;

## 响应报文的验签过程

验签算法为商户在门户端设置验签算法

以RSA验签为例：

商户根据API文档规则对响应报文组串，获取响应报文X-AGCP-Auth的值取后半段签名值，

使用门户端设置验签算法页面的通联公钥，用RSA算法对响应报文组串和签名值进行验签。

其中需要注意：

请求报文对应待签名串

StringToSign =

  SignAlgorithm+'\n' +

  ValueOf(X-AGCP-Date)+'\n' +

  CanonicalURI + '\n' +

  CanonicalQueryString + '\n' +                   // 说明：CanonicalQueryString在响应验签时为空，保留换行符即可

HexEncode(Hash(RequestPayload))

响应报文对应待签名串

StringToSign =

  SignAlgorithm+'\n' +

  ValueOf(X-AGCP-Date)+'\n' +

  CanonicalURI + '\n' +

  '\n' +                   // 说明：CanonicalQueryString在响应验签时为空，保留换行符即可

HexEncode(Hash(RequestPayload))

请求示例：

url：[https://test.allinpaygd.com/gcpapi/info/getexratenew?reqid=202108200923423360&authcus=665000000000154&merid=668000000000252](https://test.allinpaygd.com/gcpapi/info/getexratenew?reqid=202108200923423360&authcus=665000000000154&merid=668000000000252)

body：{"currency":"USD","direction":"S"}

请求待签名串示例：

GCP1-RSA-SHA512

20210820092342

/gcpapi/info/getexratenew

authcus=665000000000154&merid=668000000000252&reqid=202108200923423360

eb4dc6003020f4bdb43b691963bbca96daa3587f3dd0effddc5c329bd977918f

响应示例：

body：{"authcus":"665000000000154","merid":"668000000000252","reqid":"202108200923423360","rspcode":"1050","rspinfo":"验签不匹配"}

响应待签名串示例：

GCP1-RSA-SHA512

20210820092341

/gcpapi/info/getexratenew

ccd005864bde22add9f19ce7cd1c06414cb53424b356e59ee72efe9e2fe7f263

# 快速开始

```mermaid
sequenceDiagram

Note left of Partner: 卡片申请
autonumber
Partner->>+Allinpay: 1001:VA账户列表查询
Allinpay-->>-Partner: 申请费用扣款账户
Partner->>+Allinpay: 3000:主卡申请
Allinpay-->>-Partner: applyid
Allinpay->>+Partner: 3005:主卡申请状态通知
Partner->>+Allinpay: 3007: 卡片信息查询
Allinpay-->>-Partner: CVV2、有效期

Note left of Partner: VAP子卡申请
autonumber
Partner->>+Allinpay: 3002: 新增VPA支持场景控制模板
Allinpay-->>-Partner: 场景ID
Partner->>+Allinpay: 3004:VPA子卡申请（场景ID）
Allinpay-->>-Partner: applyid
Partner->>Allinpay用卡平台:VPA子卡申请审核
Allinpay->>+Partner: 3005：VPA子卡申请状态通知
Partner->>+Allinpay: 7004: VPA子卡信息查询
Allinpay-->>-Partner: 卡号、CVV2、有效期

Note left of Partner: 实体卡激活
Partner->>+Allinpay: 3200:卡片激活
Allinpay-->>-Partner: 成功

Note left of Partner: 保证金缴纳
Partner->>+Allinpay: 3100：缴纳保证金
Allinpay-->>-Partner: applyid
Allinpay->>+Partner: 3005:申请状态通知

Note left of Partner: 保证金提现
Partner->>+Allinpay: 3101：提取保证金
Allinpay-->>-Partner: applyid
Allinpay->>+Partner: 3005:申请状态通知


```

# 账户管理

## 6004-VA账户列表查询

接口：/gcpapi/va/search 方向：合作方->通联

说明：用于查询收款账户信息列表；

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 收款账户号 | vaaccountno | String | 30 | O |  |
| 币种 | currency | String | 3 | O |  |

响应报文

| 中文名称 |  | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- | --- |
| accts | 账户唯一标识 | id | String | 15 | Y |  |
|  | 通联内部虚拟账号 | accountno | String | 120 | Y |  |
|  | 币种 | currency | String | 3 | Y |  |
|  | 收款户余额 | amount | Number | 18,2 | Y |  |
|  | 收款账户号 | vaaccountno | String | 30 | O |  |

## 6000-历史余额查询

接口：/gcpapi/acctinfo/histbal 方向：合作方->通联

说明：设置时间区间，以“一天”作为时间维度，查询所有账户的历史余额。

请求报文: 

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 通联内部虚拟账号 | acctno | String | 32 | O | 通联内部账户账号，账号：“800\*\*\*\*\*” |
| 币种 | currency | String | 3 | O | 币种 |
| 记账起始日期 | begday | String | 8 | Y | yyyyMMdd 固定+8时区的日期 |
| 记账结束日期 | endday | String | 8 | Y | yyyyMMdd 固定+8时区的日期 |

响应报文

| 数组名称 | 字段名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- | --- |
| details数组 | 户名 | memacctname | String | 100 | Y | 账户名称 |
|  | 账号 | memacct | String | 22 | Y | 充值到账账户账号 |
|  | 通联内部虚拟账号 | acctno | String | 32 | O | 通联内部账户账号，账号：“800\*\*\*\*\*” |
|  | 币种 | currency | String | 3 | Y | 币种 |
|  | 期初余额 | openingbal | Number | 18,2 | Y | 日期当天0点账户余额 |
|  | 期末余额 | closingbal | Number | 18,2 | Y | 日期当天24点账户余额 |
|  | 期间发生额 | gmv | Number | 18,2 | Y | 日期当天0点至24点该账户变更总额 |
|  | 日期 | periodday | String | 10 | Y | yyyyMMdd 固定+8时区的日期 |

## 6001-账务明细查询

接口：/gcpapi/acctinfo/acctsdtl 方向：合作方->通联

说明： 查询客户在时间段内的账务明细。使用分页查询，默认一页数据50条。如果存在下一页，则在响应报文的下页标识字段内提示。如要查询下一页内容，只需在下次调用接口时将下页标识传入页标识字段内即可。

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 开始时间 | begdate | String | 25 | Y | ISO格式\[yyyy-MM-dd'T'HH:mm:ssZ\] |
| 结束时间 | enddate | String | 25 | Y | ISO格式\[yyyy-MM-dd'T'HH:mm:ssZ\] |
| 充值账号 | memacct | String | 22 | O | 充值到账账户账号 |
| 通联内部虚拟账号 | acctno | String | 22 | O | 通联内部虚拟账号 |
| 系统流水号 | trxid | String | 32 | O | 可指定系统流水号查询相关明细 |
| 页标识 | curpag | String | 10 | O | 为空时表示第1页，下一页的标识从响应获取。 |

响应报文

| 数组名称 | 字段名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- | --- |
| details数组 | 下页标识 | nextpag | String | 10 | C | 下一页查询的页标识。为空时表示没有下页 |
|  | 系统流水号 | trxid | String | 100 | Y |  |
|  | 充值账号 | memacct | String | 22 | Y | 充值到账账户账号 |
|  | 通联内部虚拟账号 | acctno | String | 22 | Y | 通联内部虚拟账号 |
|  | 账户名 | memacctname | String | 90 | Y | 账户名 |
|  | 交易类型 | trxcode | String | 20 | Y |  |
|  | 余额方向 | direction | String | 1 | Y | 1-借 2-贷 |
|  | 金额 | amount | Number | 18,2 | Y |  |
|  | 币种 | currency | String | 3 | Y |  |
|  | 记账时间 | registtime | String | 25 | Y | ISO格式\[yyyy-MM-dd'T'HH:mm:ssZ\] |
|  | 备注 | remark | String | 100 | O |  |

## 6002-账户余额查询

接口：/gcpapi/acctinfo/getacctbal 方向：合作方->通联

说明： 获取通联内部账户余额。

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 通联内部账号 | acctno | String | 22 | O | 如果为空则返回全部账户余额，该账户为通联内部虚拟账户和冻结账户。 |

响应报文

| 数组名称 | 字段名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- | --- |
| details数组 | 通联内部账号 | acctno | String | 22 | Y | 通联内部账号。 |
|  | 币种 | currency | String | 3 | Y |  |
|  | 余额 | balance | Number | 18,2 | Y |  |
|  | 类型 | type | Number | 1 | Y | 0-虚拟户 1-冻结户 |

## 6003-入账通知

接口：合作方定义/acctbalauditrst 方向：通联->合作方

说明：本通知在客户账户余额发生变动后发出。

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 通知id | nid | String | 32 | Y | 相同id表示同一个通知 |
| 申请单号 | applyid | String | 32 | Y | 对应接口8000-入金申请响应的申请单号 |
| 业务关联id | bid | String | 18 | Y | 业务关联id：通联内部交易流水，方便交易核实。 |
| 通联内部虚拟账号 | acctno | String | 15 | Y |  |
| 入账币种 | currency | String | 3 | Y |  |
| 入账金额 | amount | Number | 18,2 | Y | 入账金额 |
| 交易类型 | trxcod | String | 10 | Y | 见附录【1102-支付交易类型】 |
| 入账时间 | time | String | 25 | Y | ISO格式\[yyyy-MM-dd'T'HH:mm:ssZ\] |
| 入账VA账号 | payeeaccountno | String | 45 | O | 如果是VA入账，收款款方VA账户号 |
| 打款方姓名 | payeraccountname | String | 120 | O | 付款方账户名称 |
| 打款方银行账号 | payeraccountno | String | 45 | O | 付款方账户号 |
| 打款方银行号 | payeraccountbank | String | 30 | O |  |
| 打款方国家 | payeraccountcountry | String | 3 | O |  |
| 附言 | ps | String | 200 | O |  |

## 6004-交易查询

接口：/gcpapi/trx/query  方向：合作方->通联

说明：查询交易结果状态。

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 商户交易流水 | mertrxid | String | 32 | A | 商户交易流水或通联交易流水二选一 |
| 通联交易流水 | trxid | String | 32 | A | 商户交易流水或通联交易流水二选一 |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 商户交易流水 | mertrxid | String | 32 |  |  |
| 交易类型 | trxcode | String | 8 |  |  |
| 账户号 | acctno | String | 15 |  | 对于提现，账户号就是客户账户号；对于本地付款则是受益人ID |
| 账户名 | acctname | String | 15 |  |  |
| 状态 | state | String | 2 |  | 详细参考“附录——交易状态” |
| 状态描述 | stateExplain | String | 300 |  | 状态描述 |
| 金额 | amount | Number | 18,6 |  |  |
| 币种 | currency | String | 3 |  |  |
| 申请单号 | trxid | String | 32 |  |  |
| 完成日期 | payTime | String | 15 |  | 格式：YYYYMMDDHHmmss |

# 伞形账户入账相关

## 8000-入金申请

接口：/gcpapi/card/vadepositapply 方向：合作方->通联

说明：伞形账户入金申请。

![image](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/a/6El9x9XgJiVevw0D/35985d88c9684a2dbf894cb7ca6943153079.png)

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单流水 | meraplid | String | 32 | Y | 客户自己生成，保持唯一 |
| 商户号 | cusid | String | 15 | O | 默认为主商户；指定入账到子商户，需与客户经理确认子商户是否为独立账户；填入子商户号，5002接口中的cusid； |
| 币种 | currency | String | 3 | Y | 收款户币种 |
| 银行账户 | id | String | 30 | Y | 付款银行账户id，新增银行账户成功后响应 |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单号 | applyid | String | 32 | Y |  |
| 打款附言 | referencecode | String | 20 | Y | Reference Code |

## 8001-入金申请确认

接口：/gcpapi/card/vadepositconfirm 方向：合作方->通联

说明：伞形账户入金申请。

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单号 | applyid | String | 32 | Y |  |
| 金额 | amount | Number | 18,2 | Y |  |
| 转账凭证 | transferfid | String | 100 | Y | 多份材料打包zip上传，文件上传的fid |
| 其他材料 | otherfid | String | 100 | O | 多份材料打包zip上传，文件上传的fid |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 响应公共接口 |  |  |  |  |  |

## 8002-补充材料

接口：/gcpapi/card/submitmaterial 方向：合作方->通联

说明：伞形账户入金申请被退回，重新补充材料。

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单号 | applyid | String | 32 | Y | 入金申请单号 |
| 转账凭证 | transferfid | String | 100 | C | 多份材料打包zip上传，文件上传的fid |
| 其他材料 | otherfid | String | 100 | C | 多份材料打包zip上传，文件上传的fid |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 响应公共参数 |  |  |  |  |  |

## 8003-银行账户新增

接口：/gcpapi/card/addcardinfo 方向：合作方->通联

说明：根据卡号更新持卡人信息。

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 账户信息 |  |  |  |  |  |
| 归属商户号 | cusid | String | 15 | O | 默认归属主商户；指定归属到子商户；填入子商户号，5002接口中的cusid； |
| 账户类型 | flag | String | 1 | Y | 0:个人，1：企业 |
| 币种 | currency | String | 3 | Y | 支持多币种，逗号（,）隔开 |
| 注册国家/地区（国籍） | country | String | 3 | Y | 参考附录【1111-国别信息】<br>账户类型为个人填写国籍<br>账户类型为企业填写注册国家/地区 |
| 证件类型 | idtype | String | 2 | C | 账户类型为个人时必填：<br>注册国家/地区为中国时<br>*   01-居民身份证或临时身份证<br>    <br>    注册国家/地区为香港、澳门、台湾时<br>    <br>*   01-居民身份证或临时身份证<br>    <br>*   04-护照<br>    <br>    其他国家/地区<br>    <br>*   04-护照 |
| 证件号码 | idno | String | 30 | C | 账户类型为个人时必填 |
| 账户号码 | cardno | String | 30 | Y | 银行卡号 |
| 账户名称 | cardname | String | 50 | Y |  |
| 联系人联系电话 | tel | String | 20 | Y |  |
| 联系人邮箱 | email | String | 50 | Y |  |
| 联系人详细地址 | accountaddr | String | 100 | Y |  |
| 银行信息 |  |  |  |  |  |
| 银行名称 | bankname | String | 16 | Y |  |
| 开户行详情地址 | bankaddr | String | 200 | Y |  |
| 中转行swiftCode | interbankmsg | String | 10 | O |  |
| swiftCode | swiftcode | String | 20 | C | 银行所在国家/地区除了HKG以外，其他都必填 |
| 银行所在国家/地区 | depositcountry | String | 3 | Y | 参考附录【1111-国别信息】 |
| 银行所在国家/地区：中国 |  |  |  |  |  |
| 银行代码 | biccode | String | 30 | Y |  |
| 支付行号 | branchcode | String | 20 | Y |  |
| 银行所在国家/地区：中国香港 |  |  |  |  |  |
| 银行编号 | biccode | String | 30 | Y |  |
| 分行编号 | branchcode | String | 20 | Y |  |
| 银行所在国家/地区：美国 |  |  |  |  |  |
| Routing Number | biccode | String | 30 | Y |  |
| 银行所在国家/地区：英国 |  |  |  |  |  |
| SORT CODE | biccode | String | 30 | Y |  |
| 银行所在国家/地区：加拿大 |  |  |  |  |  |
| TRANSIT NO | biccode | String | 30 | Y |  |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 银行账户ID | id | String | 15 | Y |  |

## 8004-银行账户修改

接口：/gcpapi/card/uptcardinfo 方向：合作方->通联

说明：根据银行账户ID更新持卡人信息。

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 银行账户ID | id | String | 15 | Y |  |
| 账户信息 |  |  |  |  |  |
| 账户类型 | flag | String | 1 | Y | 0:个人，1：企业 |
| 币种 | currency | String | 3 | Y | 支持多币种，逗号（,）隔开 |
| 注册国家/地区（国籍） | country | String | 3 | Y | 参考附录【1111-国别信息】<br>账户类型为个人填写国籍<br>账户类型为企业填写注册国家/地区 |
| 证件类型 | idtype | String | 2 | C | 账户类型为个人时必填：<br>注册国家/地区为中国时<br>*   01-居民身份证或临时身份证<br>    <br>    注册国家/地区为香港、澳门、台湾时<br>    <br>*   01-居民身份证或临时身份证<br>    <br>*   04-护照<br>    <br>    其他国家/地区<br>    <br>*   04-护照 |
| 证件号码 | idno | String | 30 | C | 账户类型为个人时必填 |
| 账户号码 | cardno | String | 30 | Y | 不能被修改，如果填写有误请重新新增 |
| 账户名称 | cardname | String | 50 | Y |  |
| 联系人联系电话 | tel | String | 20 | Y |  |
| 联系人邮箱 | email | String | 50 | Y |  |
| 联系人详细地址 | accountaddr | String | 100 | Y |  |
| 银行信息 |  |  |  |  |  |
| 银行名称 | bankname | String | 16 | Y |  |
| 开户行详情地址 | bankaddr | String | 200 | Y |  |
| 中转行swiftCode | interbankmsg | String | 10 | O |  |
| swiftCode | swiftcode | String | 20 | C | 银行所在国家/地区除了HKG以外，其他都必填 |
| 银行所在国家/地区 | depositcountry | String | 3 | Y | 参考附录【1111-国别信息】 |
| 银行所在国家/地区：中国 |  |  |  |  |  |
| 银行代码 | biccode | String | 30 | Y |  |
| 支付行号 | branchcode | String | 20 | Y |  |
| 银行所在国家/地区：中国香港 |  |  |  |  |  |
| 银行编号 | biccode | String | 30 | Y |  |
| 分行编号 | branchcode | String | 20 | Y |  |
| 银行所在国家/地区：美国 |  |  |  |  |  |
| Routing Number | biccode | String | 30 | Y |  |
| 银行所在国家/地区：英国 |  |  |  |  |  |
| SORT CODE | biccode | String | 30 | Y |  |
| 银行所在国家/地区：加拿大 |  |  |  |  |  |
| TRANSIT NO | biccode | String | 30 | Y |  |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 公共响应参数 |  |  |  |  |  |

## 8005-银行账户查询

接口：/gcpapi/card/qrycardinfo 方向：合作方->通联

说明：根据卡号查看持卡人信息。

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 银行账户ID | id | String | 15 | A | 银行账户ID和（账户号码+币种）必选一种查询条件；两种查询条件同时存在首选使用银行账户ID查询 |
| 账户号码 | cardno | String | 30 | A | 使用账户号码查询必需带币种 |
| 币种 | currency | String | 3 | A |  |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 归属商户号 | cusid | String | 15 | Y |  |
| 银行账户ID | id | String | 15 | Y |  |
| 账户类型 | flag | String | 1 | Y | 0:个人，1：企业 |
| 币种 | currency | String | 3 | Y | 支持多币种，逗号（,）隔开 |
| 注册国家/地区（国籍） | country | String | 3 | Y | 参考附录【1111-国别信息】<br>账户类型为个人填写国籍<br>账户类型为企业填写注册国家/地区 |
| 证件类型 | idtype | String | 2 | C | 账户类型为个人时必填：<br>注册国家/地区为中国时<br>*   01-居民身份证或临时身份证<br>    <br>    注册国家/地区为香港、澳门、台湾时<br>    <br>*   01-居民身份证或临时身份证<br>    <br>*   04-护照<br>    <br>    其他国家/地区<br>    <br>*   04-护照 |
| 证件号码 | idno | String | 30 | C | 账户类型为个人时必填 |
| 账户号码 | cardno | String | 30 | Y | 银行卡号 |
| 账户名称 | cardname | String | 16 | Y |  |
| 联系人联系电话 | tel | String | 20 | Y |  |
| 联系人邮箱 | email | String | 50 | Y |  |
| 联系人详细地址 | accountaddr | String | 100 | Y |  |
| 银行信息 |  |  |  |  |  |
| 银行名称 | bankname | String | 16 | Y |  |
| 开户行详情地址 | bankaddr | String | 200 | Y |  |
| 中转行swiftCode | interbankmsg | String | 10 | O |  |
| swiftCode | swiftcode | String | 20 | C | 银行所在国家/地区除了HKG以外，其他都必填 |
| 银行所在国家/地区 | depositcountry | String | 3 | Y | 参考附录【1111-国别信息】 |
| 银行所在国家/地区：中国 |  |  |  |  |  |
| 银行代码 | biccode | String | 30 | Y |  |
| 支付行号 | branchcode | String | 20 | Y |  |
| 银行所在国家/地区：中国香港 |  |  |  |  |  |
| 银行编号 | biccode | String | 30 | Y |  |
| 分行编号 | branchcode | String | 20 | Y |  |
| 银行所在国家/地区：美国 |  |  |  |  |  |
| Routing Number | biccode | String | 30 | Y |  |
| 银行所在国家/地区：英国 |  |  |  |  |  |
| SORT CODE | biccode | String | 30 | Y |  |
| 银行所在国家/地区：加拿大 |  |  |  |  |  |
| TRANSIT NO | biccode | String | 30 | Y |  |
| 状态信息 |  |  |  |  |  |
| 状态 | state | String | 2 | Y | 0-待审核；<br>1-审核通过；<br>2-审核不通过；<br>4-冻结；<br>5-关闭；<br>6-待复审 |
| 状态描述 | stateexplain | String | 100 | O | 状态的描述 |

## 8006-银行账户状态通知

接口：合作方自定义/bnfauditrst  方向：通联->合作方

说明：银行账户添加申请被审核后，会触发该通知。如果审核不通过，可以从通知的状态描述

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 账户号码 | cardno | String | 30 | Y | 银行卡号 |
| 币种 | currency | String | 3 | Y |  |
| 银行账户ID | id | String | 15 | Y |  |
| 状态 | state | String | 2 | Y | 0-待审核；<br>1-审核通过；<br>2-审核不通过；<br>4-冻结；<br>5-关闭；<br>6-待复审 |
| 状态描述 | stateexplain | String | 100 | O | 状态的描述 |

## 1001-VA入金信息查询

接口：/gcpapi/va/accountdetail 方向：合作方->通联

说明：用于查询收款账户入金信息；

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 收款账户号 | vaaccountno | String | 30 | Y |  |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 账户名称 | accountname | String | 120 | Y |  |
| SWIFT代码 | swiftcode | String | 10 | Y |  |
| 银行编号 | biccode | String | 20 | Y |  |
| 分行编号 | branchcode | String | 20 | O |  |
| 银行名称 | bankname | String | 200 | Y |  |
| 银行地址 | bankaddr | String | 300 | Y |  |
| 银行账号 | vaaccountno | String | 30 | Y |  |

# 支付交易

## 2000-离岸换汇申请

接口：/gcpapi/card/exchangeoff/apply 方向：合作方->通联

说明：用于VA账户不同币种账户之间换汇。提交此申请后，执行【支付类申请单确认】接口；

![image](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/a/6El9x9XgJiVevw0D/28731d1cd73e4786815918d9c25815b93079.png)

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单流水 | meraplid | String | 32 | Y | 客户自己生成，保持唯一 |
| 到账币种 | payeeccy | String | 3 | Y | 见附录【1115-币种类型】 |
| 卖出币种 | payerccy | String | 3 | Y | 见附录【1115-币种类型】 |
| 锁定方 | lockamountflag | String | 1 | O | S：锁定卖出方<br>B：锁定买入方<br>为空默认锁定卖出方 |
| 交易金额 | amount | Number | 18,2 | Y | 锁定方为卖出方，金额为卖出金额<br>锁定方为买入方，金额为买入金额 |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单号 | applyid | String | 32 | Y |  |

## 2001-锁汇询价

接口：/gcpapi/apply/lockfx  方向：合作方->通联

说明：执行离岸换汇申请后，可执行此接口查询交易汇率，申请单确认成交方式为LK（锁汇成交）时，使用是此结果汇率，查询结果有效期为3分钟，逾期按申请单确认时的最新汇率。

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单号 | applyid | String | 32 | A | 两者必选其一 |
| 申请单流水 | meraplid | String | 32 | A |  |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单号 | applyid | String | 32 | Y |  |
| 交易金额 | amount | Number | 18,2 | Y |  |
| 手续费 | fee | Number | 18,2 | Y |  |
| 手续费币种 | feecurrency | String | 3 | Y |  |
| 结算金额 | settleamount | Number | 18,2 | Y |  |
| 结算币种 | settlecurrency | String | 3 | Y |  |
| 汇率 | fxrate | Number | 18,9 | Y |  |

## 2002-支付类申请单确认

接口：/gcpapi/b2bwithdraw/confirm 方向：合作方->通联

说明：对支付类申请进行确认，处理成功后进入申请换汇环节。

1、成交方式为锁汇成交：需要在申请单确认之前执行2001-锁汇询价接口，并在锁汇有效期内调用此申请单确认接口，此申请单使用汇率即时2001-锁汇询价接口响应结果的汇率。（若执行2001-锁汇询价接口超过有效期后或者未执行2001-锁汇询价接口，系统默认选择当前最新汇率）。

2、成交方式为现价锁汇成交，则此申请单直接使用当前最新汇率执行此申请单。

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单流水 | meraplid | String | 32 | A | meraplid和applyid两者必选其一 |
| 申请单号 | applyid | String | 32 | A |  |
| 成交方式 | extype | String | 2 | Y | LK:锁汇成交 MT：现价锁汇成交 |
| 锁汇超时执行模式 | exmode | String | 1 | O | 1：锁汇超时拒绝交易<br>0：超时按现价锁汇成交（默认）<br>成交方式为:LK（锁汇成交）且锁汇结果超时，该字段生效； |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 仅返回公共响应参数 |  |  |  |  |  |

## 2003-支付类申请单查询

接口：/gcpapi/apply/query方向：合作方->通联

说明：长时间无法收到申请单状态通知时，可以主动触发该接口查询申请单当前处理进度。

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单流水 | meraplid | String | 32 | A |  |
| 申请单号 | applyid | String | 32 | A | 两者必选其一 |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单流水 | meraplid | String | 32 | Y |  |
| 申请单号 | applyid | String | 32 | Y |  |
| 受益人账号 | acctno | String | 30 | O | 买入方账户 |
| 锁定方 | lockflg | String | 1 | O | S：锁定卖方<br>B：锁定买方 |
| 支付币种 | payccy | String | 3 | Y | 卖出币种 |
| 支付金额 | payamount | Number | 20 | Y | 卖出金额 |
| 结算金额 | stlamount | Number | 18,2 | C | 买入金额，确认申请单后才有 |
| 结算币种 | stlccy | String | 3 | C | 买入币种，确认申请单后才有 |
| 交易手续费 | fee | Number | 18,2 | O |  |
| 交易手续费币种 | feeccy | String | 3 | O |  |
| 汇率 | fxrate | Number | 18,9 | O |  |
| 附言 | ps | String | 200 | O |  |
| 汇款用途 | purpose | String | 200 | O |  |
| 状态 | state | String | 2 | Y | 详细参考“附录-1108-支付类申请单状态” |
| 状态描述 | stateexplain | String | 300 | O | 在申请单审核过程，申请单的审核意见描述或申请单交易被渠道拒绝的原因 |
| 交易类型 | trxcode | String | 10 | Y | 详细参考“附录-1102-支付交易类型” |

## 2004-支付类申请单状态通知

接口：合作方url/applynotify 方向：通联->合作方

说明：该通知需要商户登陆门户页面，去设置页面配置通知路径。添加申请被审核后，会触发该通知。如果审核不通过，可以从通知的状态描述中查看。

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单流水 | meraplid | String | 32 | Y |  |
| 受益人账号 | acctno | String | 30 | O |  |
| 锁定方 | lockflg | String | 1 | O | S：锁定卖方<br>B：锁定买方 |
| 支付金额 | payamount | Number | 18,2 | Y | 卖出金额 |
| 支付币种 | payccy | String | 3 | Y | 卖出币种 |
| 结算金额 | stlamount | Number | 18,2 | O | 买入金额，确认申请单后才有 |
| 结算币种 | stlccy | String | 3 | O | 买入币种，确认申请单后才有 |
| 手续费 | fee | Number | 18,2 | O | 当前交易手续费 |
| 手续费币种 | feeccy | String | 3 | O |  |
| 汇率 | fxrate | Number | 18,9 | O |  |
| 附言 | ps | String | 200 | O |  |
| 汇款用途 | purpose | String | 200 | O |  |
| 申请单号 | applyid | String | 32 | Y |  |
| 状态 | state | String | 2 | Y | 详细参考“附录-1108-支付类申请单状态” |
| 状态描述 | stateexplain | String | 300 | O | 在申请单审核过程，申请单的审核意见描述或申请单交易被渠道拒绝的原因 |
| 交易类型 | trxcode | String | 10 | Y | 详细参考“附录1102-支付交易类型” |
| 通知时间 | time | String | 25 | Y | ISO格式\[yyyy-MM-dd'T'HH:mm:ssZ\] |

## 5.6 2005-汇率查询

接口：/gcpapi/card/getexrate  方向：合作方->通联

说明：通过该接口，可查询到当前参考汇率。

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 交易币种 | currency | String | 3 | Y | 源币种，待换汇币种 |
| 结算币种 | settlecurrency | String | 3 | Y | 目标币种 |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 交易币种 | currency | String | 3 | Y |  |
| 结算币种 | settlecurrency | String | 3 | Y |  |
| 汇率 | fxrate | Number | 18,9 | Y |  |

## 5.7. 2006-生态圈转账

接口：/gcpapi/ecosphereTransfer/apply 方向：合作方->通联

说明：卖出账户为报文头中merid对应的收款户，用于不同客户间同岸同币种账户转账。提交此申请后，执行【2002-支付类申请单确认】接口；

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单流水 | meraplid | String | 32 | Y | 客户自己生成，保持唯一 |
| 到账收款账户号 | payeeaccountno | String | 32 | A | 到账方收款账户号，与payeemerid二者必选其一 |
| 到账方商户号 | payeemerid | String | 32 | A | 到账方商户号，在没有收款账户情况下，转到对方商户的所在的通联虚拟账户，与payeeaccountno二者必选其一 |
| 币种 | currency | String | 3 | O | 见附录【币种类型】 |
| 金额 | amount | Number | 18,2 | Y |  |
| 是否全额到账 | islockamount | String | 1 | O | 枚举值（1:是；0:否）默认为0；  <br>1：手续费在拨出账户余额中扣减  <br>0：手续费在拨入账户余额中扣减 |
| 贸易协议或发票文件 | agrefid | String | 80 | Y | 使用上传文件的fid字段 |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单号 | applyid | String | 32 | Y |  |

## 5.8. 2007-同名转账

接口：/gcpapi/fundmerge/apply 方向：合作方->通联

说明：卖出账户为报文头中merid对应的收款户，用于同一客户下的同岸且同币种账户之间资金划拨。提交此申请后，执行【2002-支付类申请单确认】接口；

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单流水 | meraplid | String | 32 | Y | 客户自己生成，保持唯一 |
| 付款方虚拟账户 | payeraccountno | String | 32 | O | 付款方虚拟账户，通联内部虚拟账户号；若上送该账户，该账户为卖出账户，为空卖出账户为报文头中merid对应的收款户 |
| 到账商户号 | payeemerid | String | 32 | A | 收款户添加完成审批通过后，通过收款户查询接口，结果中获取指定收款户的商户ID（merid）,若没有收款户则转入至改商户下的通联虚拟账户下。与_到账收款账户号两者必填其一_ |
| _到账收款账户号_ | _payeeaccountno_ | _String_ | _32_ | _A_ | _到账方收款账户号或__通联内部虚拟账户号__，_与_到_到账商户号_两者必填其一_ |
| 币种 | currency | String | 3 | O | 见附录【币种类型】 |
| 金额 | amount | Number | 18,2 | Y |  |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单号 | applyid | String | 32 | Y |  |

# 卡管理接口

## 卡片申请

![image](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/a/6El9x9XgJiVevw0D/ab4a52de417d444eb45ebaadfc322b233079.png)

### 3012-查询支持卡产品类型

接口：/gcpapi/card/getcardproduct 方向：合作方->通联

说明：用于查询客户支持的所有卡产品类型；

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 无 |  |  |  |  |  |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 卡产品类型 | cardproducts | String\[\] | 50 | Y | 如："cardproducts":\["001201","001001","011001","021201"\] |

### 3000-主卡申请

接口：/gcpapi/card/open 方向：合作方->通联

说明：用于创建主卡申请；

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单流水 | meraplid | String | 32 | Y | 客户自己生成，保持唯一 |
| 卡产品类型 | producttype | String | 6 | Y | 见附录【1109-卡产品类型】中的卡产品类型代码 |
| 卡片种类 | cardtype | String | 2 | Y | 1：虚拟卡，（产品类型为：通华金服VISA虚拟卡、通华金服共享卡、通华金服VISA虚拟卡-USD）<br>4：实体卡，（产品类型为：通华金服VISA公务卡、万商义乌VISA商务卡） |
| 持卡人身份 | cardholdertype | String | 2 | O | 1：法人持有<br>0：其他管理员 |
| 国籍 | nationality | String | 3 | O | 见附录【1111-国别信息】中的CODE,如中国：CHN |
| 公司职位 | companyposition | String | 50 | O | 1：法人代表<br>2：董事<br>3：高级管理员<br>4：经理<br>5：职员 |
| 姓氏 | surname | String | 20 | Y | 仅支持英文 |
| 名字 | name | String | 30 | Y | 仅支持英文 |
| 出生日期 | birthday | String | 10 | O | YYYYMMDD |
| 证件1类型 | idtype | String | 2 | Y | 01：居民身份证（国籍为中国）<br>04：护照（国籍为非中国） |
| 证件1号码 | idnumber | String | 30 | Y |  |
| 证件2类型 | idtype2 | String | 2 | C | 国籍不为中国时必填<br>国籍为中国香港、台湾、澳门：<br>1.  03：港澳台身份证<br>    <br>2.  06：其他类个人有效证件<br>    <br>非中国大陆和香港、台湾、澳门：<br>1.  06：其他类个人有效证件 |
| 证件2号码 | idnumber2 | String | 30 | C | 国籍不为中国时必填，填证件2类型号码 |
| 居住国家/地区 | country | String | 3 | O | 见附录【1111-国别信息】中的CODE,如中国：CHN |
| 省份 | province | String | 6 | C | 居住国家/地区为CHN时必填，见附录【1112-地区代码】 |
| 城市 | city | String | 6 | C | 居住国家/地区为CHN时必填，见附录【1112-地区代码】 |
| 详细地址 | address | String | 200 | O |  |
| 邮箱 | email | String | 50 | Y |  |
| 性别 | gender | String | 2 | O | 1：男<br>0：女 |
| 手机号码所属地区 | mobilecountry | String | 10 | O | 见附录【1111-国别信息】中的CODE |
| 手机号码 | mobilenumber | String | 20 | O |  |
| 证件1正面照片 | photofront | String | 100 | O | 通过文件上传接口上传后，这里上送文件的fid |
| 证件1反面照片 | photoback | String | 100 | O | 通过文件上传接口上传后，这里上送文件的fid |
| 证件2正面照片 | photofront2 | String | 100 | C | 通过文件上传接口上传后，这里上送文件的fid |
| 证件2反面照片 | photoback2 | String | 100 | C | 通过文件上传接口上传后，这里上送文件的fid |
| 申请费用扣款账户 | payerid | String | 15 | Y | 【VA账户列表查询】响应报文中的账户唯一标识id或者填入通联内部虚拟账户号 |
| 邮寄国家/地区 | deliverycountry | String | 10 | C | 卡片类型为实体卡时必填，见附录【1111-国别信息】中的CODE |
| 邮寄省份 | deliveryprovince | String | 6 | C | 邮寄国家/地区为CHN时必填，见附录【1112-地区代码】 |
| 邮寄城市 | deliverycity | String | 6 | C | 邮寄国家/地区为CHN时必填，见附录【1112-地区代码】 |
| 邮寄地址 | deliveryaddress | String | 200 | C | 卡片类型为实体卡时必填 |
| 交易对手 | payeeaccount | String | 30 | O |  |
| 采购内容 | procurecontent | String | 100 |  |  |
| 交易对手合同或协议 | agmfid | String | 100 | C | 卡产品类型为：021201-通华金服共享卡时必填，通过文件上传接口上传协议后，上送协议fid |
| 卡账户模式 | accountmode | String | 1 | O | 卡产品为4020/4023时生效<br>1：常规卡模式（为空时，默认）<br>2：共享资金账户卡模式 |
| 交易相关手续费扣收方式 | feepayertype | String | 1 | O | 卡账户模式为，常规卡时生效<br>1：从VA账户扣除<br>2：从卡账户余额扣除 |
| 共享资金账户 | sharefundid | String | 20 | C | 卡账户模式为共享资金账户时，必填；<br>取值来自3301-新增共享资金账户接口响应结果applyid |
| 卡激活模式 | manualatiave | String | 1 | C | 卡产品为4020时生效<br>Y：手工激活<br>N：自动激活（默认）<br>手工激活模式下，卡申请成功后，卡状态为待激活（state=14）,需要调用卡激活接口激活后卡状态为正常方可使用；自动激活模式下，卡申请成功后卡状态即为正常；<br>激活虚拟卡接口：3013-虚拟卡激活 |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单号 | applyid | String | 32 | Y |  |

### 3001-子卡申请

接口：/gcpapi/card/v2/subopen 方向：合作方->通联

说明：用于创建子卡申请；

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单流水 | meraplid | String | 32 | Y | 客户自己生成，保持唯一 |
| 主卡ID | maincardid | String | 10 | Y |  |
| 卡片种类 | cardtype | String | 2 | Y | 1：虚拟卡，（主卡产品类型为：通华金服VISA虚拟卡、通华金服VISA虚拟卡-USD）<br>4：实体卡，（主卡产品类型为：通华金服VISA公务卡、万商义乌VISA商务卡） |
| 主体类型 | belongtype | String | 2 | Y | 1：员工<br>2：合作企业 |
| 子商户号 | cusid | String | 30 | C | 主体类型为合作企业时必填，【子商户创建】结果返回的cusid |
| 持卡人身份 | cardholdertype | String | 3 | O | 1：法人持有<br>0：其他管理员 |
| 国籍 | nationality | String | 50 | O | 见附录【1111-国别信息】中的CODE,如中国：CHN |
| 公司职位 | companyposition | String | 50 | O | 1：法人代表<br>2：董事<br>3：高级管理员<br>4：经理<br>5：职员 |
| 姓氏 | surname | String | 20 | Y | 仅支持英文 |
| 名字 | name | String | 30 | Y | 仅支持英文 |
| 出生日期 | birthday | String | 10 | O | YYYYMMDD |
| 证件1类型 | idtype | String | 2 | Y | 注册国家/地区为中国时<br>*   01-居民身份证或临时身份证<br>    <br>    注册国家/地区为香港、澳门、台湾时<br>    <br>*   01-居民身份证或临时身份证<br>    <br>*   04-护照<br>    <br>    其他国家/地区<br>    <br>*   04-护照 |
| 证件1号码 | idnumber | String | 30 | Y |  |
| 证件2类型 | idtype2 | String | 2 | C | 国籍不为中国时必填<br>国籍为中国香港、台湾、澳门：<br>1.  03：港澳台身份证<br>    <br>2.  06：其他类个人有效证件<br>    <br>非中国大陆和香港、台湾、澳门：<br>1.  06：其他类个人有效证件 |
| 证件2号码 | idnumber2 | String | 30 | C | 国籍不为中国时必填 |
| 性别 | gender | String | 2 | O | 1：男<br>0：女 |
| 国家/地区 | country | String | 3 | O | 见附录【1111-国别信息】中的CODE,如中国：CHN |
| 详情地址 | address | String | 200 | O |  |
| 邮箱 | email | String | 50 | Y |  |
| 手机号码所属地区 | mobilecountry | String | 10 | O | 见附录【1111-国别信息】中的PHONE\_CODE |
| 手机号码 | mobilenumber | String | 20 | O |  |
| 邮政编码 | deliverypostcode | String | 20 | O |  |
| 证件1正面照片 | photofront | String | 100 | O | 通过文件上传接口上传后，这里上送文件的fid |
| 证件1反面照片 | photoback | String | 100 | O | 通过文件上传接口上传后，这里上送文件的fid |
| 证件2正面照片 | photofront2 | String | 100 | C | 通过文件上传接口上传后，这里上送文件的fid |
| 证件2反面照片 | photoback2 | String | 100 | C | 通过文件上传接口上传后，这里上送文件的fid |
| 申请费用扣款账户 | payerid | String | 15 | Y | 【VA账户列表查询】响应报文中的账户唯一标识id或者填入通联内部虚拟账户号 |
| 邮寄国家/地区 | deliverycountry | String | 10 | C | 卡片类型为实体卡时必填，见附录【1111-国别信息】中的CODE |
| 邮寄省份 | deliveryprovince | String | 6 | C | 邮寄国家/地区为CHN时必填，见附录【1112-地区代码】 |
| 邮寄城市 | deliverycity | String | 6 | C | 邮寄国家/地区为CHN时必填，见附录【1112-地区代码】 |
| 邮寄地址 | deliveryaddress | String | 200 | C | 卡片类型为实体卡时必填 |
| 卡激活模式 | manualatiave | String | 1 | C | 主卡产品为4020时生效<br>Y：手工激活<br>N：自动激活（默认）<br>手工激活模式下，卡申请成功后，卡状态为待激活（state=14）,需要调用卡激活接口激活后卡状态为正常方可使用；自动激活模式下，卡申请成功后卡状态即为正常；<br>激活虚拟卡接口：3013-虚拟卡激活 |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单号 | applyid | String | 32 | Y |  |

### 3002-新增通华金服共享卡场景

接口：/gcpapi/card/addcardscene 方向：合作方->通联

说明：新增通华金服共享卡使用规则场景；

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 场景名称 | scenename | String | 50 | Y | 保证唯一 |
| 使用场景 | cycle | String | 1 | Y | 1:期限，2:周期，3:单次 |
| 允许交易币种 | currency | String | 100 | O | 支持多币种，多币种时以逗号(,)隔开；为空时，默认全币种 ；见附录【1115-币种信息】 |
| ~~是否仅支持香港地区交易~~ | ~~onlhkflag~~ | ~~String~~ | ~~1~~ | ~~O~~ | ~~Y:是，N：否~~ |
| MCC黑名单 | mccblacklist | String | 4000 | O | 三项最多输入一项；<br>MCC黑名单最多可以设置15段，例如：<br>3008,4000-5000,5002<br>商户号黑/白名单最多可以设置200个，例如：AAAAAAAAAAA,BBBBBBBBBBBB,CCCCCCCC |
| 商户号白名单 | merwhitelist | String | 4000 | O |
| 商户号黑名单 | merblacklist | String | 4000 | O |
| 以下字段使用场景为期限时填入 |  |  |  |  |  |
| 使用期限起始 | begindate | String | 10 | C | 使用场景为期限时填入，YYYY-MM-DD，UTC时间 |
| 使用期限结束 | enddate | String | 10 | C | 使用场景为期限时填入，YYYY-MM-DD，UTC时间 |
| 最大消费笔数 | authmaxcount | String | 10 | C | 使用场景为期限时填入，填入数字字符串，为“0”时默认不限制 |
| 卡片额度 | authmaxamount | String | 10 | C | 使用场景为期限时填入，填入数字字符串，保留2位小数点 |
| 以下字段使用场景为周期时填入 |  |  |  |  |  |
| 周期设置-自然月 | naturalmonthflag | String | 1 | C | 使用场景为周期时填入,Y:是，N：否 |
| 周期设置-自然日设置 | naturalmonthstartday | String | 2 | C | 周期设置-自然月为否是填入，1-28之间 |
| 最大消费笔数 | authmaxcount | String | 10 | C | 使用场景为周期时填入，填入数字字符串，为“0”时默认不限制 |
| 卡片额度 | authmaxamount | String | 10 | C | 使用场景为周期时填入，填入数字字符串，保留2为小数点 |
| 以下字段使用场景为单次时填入 |  |  |  |  |  |
| 是否固定消费金额 | fixedamountflag | String | 1 | C | 使用场景为单次时填入,Y:是，N：否 |
| 消费金额 | authmaxamount | String | 10 | C | 是否固定消费金额为是时填入固定消费金额<br>是否固定消费金额为否时填入最大消费金额<br>填入数字字符串，保留2为小数点 |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 场景ID | sceneid | String | 30 | Y | 成功时响应 |

### 3003-通华金服共享卡场景查询

接口：/gcpapi/card/qrycardscene 方向：合作方->通联

说明：查询vpa卡使用规则场景；

请求报文：

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 场景ID | sceneid | String | 30 | Y |  |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 场景名称 | scenename | String | 50 | Y | 保证唯一 |
| 使用场景 | cycle | String | 1 | Y | 1:期限，2:周期，3:单次 |
| 允许交易币种 | currency | String | 100 | Y | 见附录【1115-币种信息】 |
| 是否仅支持香港地区交易 | onlhkflag | String | 1 | O | Y:是，N：否 |
| 最大消费笔数 | authmaxcount | String | 10 | O |  |
| 卡片额度/固定消费金额 | authmaxamoun | String | 10 | O | 在固定消费金额时，代表固定消费金额 |
| 是否固定消费金额 | fixedamountflag | String | 1 | O | 使用场景为仅单次时填入,Y:是，N：否 |
| 使用期限起始日期 | begindate | String | 10 | C | 使用场景仅为期限时响应，YYYY-MM-DD，UTC时间 |
| 使用期限结束日期 | enddate | String | 10 | C | 使用场景仅为期限时响应，YYYY-MM-DD，UTC时间 |
| 周期设置-自然月 | naturalmonthflag | String | 1 | C | 使用场景仅为周期时填入,Y:是，N：否 |
| 周期设置-自然日设置 | naturalmonthstartday | String | 2 | C | 周期设置-自然月为否是填入，1-28之间 |
| MCC黑名单 | mccblacklist | String | 4000 | O |  |
| 商户号白名单 | merwhitelist | String | 4000 | O |  |
| 商户号黑名单 | merblacklist | String | 4000 | O |  |
| 创建时间 | createtime | String | 20 | Y | yyyy-mm-dd hh:mi:ss |

### 3004-申请通华金服共享卡子卡

接口：/gcpapi/card/v2/vpaopen 方向：合作方->通联

说明：申请通华金服共享卡子卡；

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单流水 | meraplid | String | 32 | O | 客户自己生成，保持唯一，为空默认同申请单号 |
| 场景ID | sceneid | String | 30 | Y |  |
| 主卡卡ID | maincardid | String | 10 | Y | 主卡产品类型为：021201:通华金服VISA共享卡的主卡卡号 |
| 申请数量 | num | String | 6 | O | 为空，默认申请1张，一次申请最大数量为10万 |
| 接受卡片邮箱 | email | String | 50 | O | 为空，不发送通华金服共享卡子卡信息，需自行到用卡平台下载，或通过7005接口下载 |
| 卡片有效期 | cardexpiredate | String | 10 | O | 格式：YYYY-MM-DD<br>为空情况卡片有效期默认沿用主卡有效期；子卡有效期不得超过主卡有效期；若使用场景为期限类型，则有效期必须超过场景的结束期限； |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单号 | applyid | String | 32 | Y |  |

###  3010-申请通华金服共享卡子卡（同步设置卡场景）

接口：/gcpapi/card/v2/vpaopenofscene 方向：合作方->通联

说明：申请共享卡子卡同时设置卡场景；

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单流水 | meraplid | String | 32 | O | 客户自己生成，保持唯一，为空默认同申请单号 |
| 主卡卡ID | maincardid | String | 10 | Y | 主卡产品类型为：021201:通华金服VISA共享卡的主卡卡号 |
| 申请数量 | num | String | 6 | O | 为空，默认申请1张，一次申请最大数量为10万 |
| 接受卡片邮箱 | email | String | 50 | O |  |
| 卡片有效期 | cardexpiredate | String | 10 | O | 格式：YYYY-MM-DD，UTC时间<br>为空情况卡片有效期默认沿用主卡有效期；子卡有效期不得超过主卡有效期；若使用场景为期限类型，则有效期必须超过场景的结束期限； |
| 以下为卡场景相关设置 |  |  |  |  |  |
| 使用场景 | cycle | String | 1 | Y | 1:期限，2:周期，3:单次 |
| 允许交易币种 | currency | String | 100 | O | 支持多币种，多币种时以逗号(,)隔开；为空时，默认全币种 ；固定金额消费时，币种单选；<br>见附录【1115-币种信息】 |
| MCC黑名单 | mccblacklist | String | 4000 | O | 三项最多输入一项；<br>MCC黑名单最多可以设置15段，例如：<br>3008,4000-5000,5002<br>商户号黑/白名单最多可以设置200个，例如：AAAAAAAAAAA,BBBBBBBBBBBB,CCCCCCCC |
| 商户号白名单 | merwhitelist | String | 4000 | O |
| 商户号黑名单 | merblacklist | String | 4000 | O |
| 以下字段使用场景为期限时填入 |  |  |  |  |  |
| 使用期限起始 | begindate | String | 10 | C | 使用场景为期限时填入，YYYY-MM-DD，UTC时间 |
| 使用期限结束 | enddate | String | 10 | C | 使用场景为期限时填入，YYYY-MM-DD，UTC时间 |
| 最大消费笔数 | authmaxcount | String | 10 | C | 使用场景为期限时填入，填入数字字符串，为“0”时默认不限制 |
| 卡片额度 | authmaxamount | String | 10 | C | 使用场景为期限时填入，填入数字（正整数）字符串，保留2位小数点，默认币种为HKD |
| 以下字段使用场景为周期时填入 |  |  |  |  |  |
| 周期设置-自然月 | naturalmonthflag | String | 1 | C | 使用场景为周期时填入,Y:是，N：否 |
| 周期设置-自然日设置 | naturalmonthstartday | String | 2 | C | 周期设置-自然月为否是填入，1-28之间 |
| 最大消费笔数 | authmaxcount | String | 10 | O | 使用场景为周期时填入，填入数字字符串，为“0”时默认不限制 |
| 卡片额度 | authmaxamount | String | 10 | C | 使用场景为周期时填入，填入数字（正整数）字符串，保留2为小数点 |
| 以下字段使用场景为单次时填入 |  |  |  |  |  |
| 是否固定消费金额 | fixedamountflag | String | 1 | C | 使用场景为单次时填入,Y:是，N：否 |
| 消费金额 | authmaxamount | String | 10 | C | 是否固定消费金额为是时填入固定消费金额<br>是否固定消费金额为否时填入最大消费金额<br>填入数字字符串，保留2为小数点 |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单号 | applyid | String | 32 | Y |  |

### 3005-卡申请单状态通知

接口：合作方url/vpaauditrst 方向: 通联 -> 合作方

说明：用以在主卡/子卡申请、卡充值（缴纳保证金）、卡提现（提取保证金）、卡注销申请单状态变化时通知合作方。

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单号 | applyid | String | 32 | Y |  |
| 申请单流水 | meraplid | String | 32 | Y |  |
| 申请时间 | createtime | String | 20 | Y | 格式YYYY-MM-DD hh:mm:ss |
| 申请费用 | fee | Number | 18,2 | O |  |
| 申请费用币种 | feecurrency | String | 3 | O |  |
| 卡ID | cardid | String | 10 | O |  |
| 卡号 | cardno | String | 30 | O | 卡号为脱敏状态：358433\*\*\*\*2343<br>1、对于开卡申请的申请单，仅在申请成功的状态后返回；<br>2、通华金服共享卡子卡开卡不返回，需根据申请单号去下载（接口7005）。 |
| 申请金额 | amount | Number | 18,2 | O |  |
| 申请币种 | currency | String | 3 | O |  |
| 申请单状态 | state | String | 2 | Y | 详细参考“附录——1107-卡申请单状态” |
| 状态说明 | stateexplain | String | 200 | O |  |
| 交易类型 | trxcode | String | 10 | Y | 详细参考“附录——1103-卡申请交易类型” |
| 卡类型 | cardbusinesstype | String | 1 | Y | 1：主卡<br>2：子卡 |
| 担保金额 | securityamount | Number | 18,2 | O |  |
| 担保金币种 | securitycurrency | String | 3 | O |  |
| 到账金额 | settleamount | Number | 18,2 | O | 卡提现或卡充值申请，实际到账金额 |
| 到账币种 | settlecurrency | String | 3 | O | 卡提现或卡充值申请，实际到账币种 |

### 3006-卡申请单查询

接口：/gcpapi/card/v2/applyquery方向：合作方->通联

说明：用以查询主卡/子卡申请、卡充值（缴纳保证金）、卡提现（提取保证金）、卡注销申请单当前处理进度。

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单流水 | meraplid | String | 32 | A |  |
| 申请单号 | applyid | String | 32 | A | 两者必选其一 |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单流水 | meraplid | String | 32 | Y |  |
| 申请单号 | applyid | String | 32 | Y |  |
| 申请时间 | createtime | String | 20 | Y | 格式YYYY-MM-DD hh:mm:ss |
| 申请费用 | fee | Number | 18,2 | O |  |
| 申请费用币种 | feecurrency | String | 3 | O |  |
| 卡ID | cardid | String | 10 | O |  |
| 卡号 | cardno | String | 30 | O | 卡号为脱敏状态：358433\*\*\*\*2343<br>1、对于开卡申请的申请单，仅在申请成功的状态后返回；<br>2、通华金服共享卡子卡开卡不返回，需根据申请单号去下载（接口7005）。 |
| 申请金额 | amount | Number | 18,2 | O |  |
| 申请币种 | currency | String | 3 | O |  |
| 申请单状态 | state | String | 2 | Y | 详细参考“附录——1107-卡申请单状态” |
| 状态说明 | stateexplain | String | 200 | O | 在申请失败或审核不通过情况，响应相应原因描述 |
| 交易类型 | trxcode | String | 10 | Y | 详细参考“附录——1103-卡申请交易类型” |
| 卡类型 | cardbusinesstype | String | 1 | Y | 1：主卡<br>2：子卡 |
| 担保金额 | securityamount | Number | 18,2 | O |  |
| 担保金币种 | securitycurrency | String | 3 | O |  |
| 到账金额 | settleamount | Number | 18,2 | O | 卡充值（缴纳保证金）、卡提现（提取保证金）申请，实际到账金额 |
| 到账币种 | settlecurrency | String | 3 | O | 卡充值（缴纳保证金）、卡提现（提取保证金）申请，实际到账币种 |

### 3007-查询卡支付信息

接口：/gcpapi/card/v2/getpayinfo 方向：合作方->通联

说明：根据卡号查询指定卡的支付信息。

响应字段内的cvv、expiredate采用对称加密。配置秘钥见【1.9基本对接流程】；解密可以参考附录【1116-对接demo】

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 卡ID | cardid | String | 10 | Y |  |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 卡ID | cardid | String | 10 | Y |  |
| 卡号 | cardno | String | 30 | Y | 加密字段 |
| CVV2 | cvv | String | 3 | Y | 加密字段 |
| 有效期 | expiredate | String | 4 | Y | 加密字段，YYMM |

### 3008-变更通华金服共享卡子卡场景信息

接口：/gcpapi/card/v2/cardupdatescene 方向：合作方->通联

说明：对通华金服共享卡子卡变更使用场景,在原场景的基础上直接覆盖场景模板中的取值；

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 卡ID | cardid | String | 10 | Y |  |
| 最大授权笔数 | authmaxcount | String | 10 | O |  |
| 最大交易授权金额 | authmaxamount | String | 10 | O | 设置该最大交易授权金额时，需指定币种 |
| 允许交易币种 | currency | String | 100 | O | 支持多币种，多币种时以逗号(,)隔开 |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 响应公共参数 |  |  |  |  |  |

###  3009-共享卡子卡支付信息批量查询

接口：/gcpapi/card/vpacardinfoqry 方向：合作方->通联

说明：共享卡子卡以申请单维度查询子卡支付信息；响应字段内的cvv、expiredate采用对称加密。 仅可查询7天内申请单；

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单号 | applyid | String | 32 | Y |  |
| 页码数 | pageindex | Number | 10 | O | 表示第几页，默认1 |
| 分页数 | pagesize | Number | 10 | O | 每页显示记录数，默认100，不得大于500 |

响应报文

| 中文名称 |  | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- | --- |
| datalist | 卡号 | cardno | String | 30 | Y |  |
|  | CVV2 | cvv | String | 3 | Y | 加密字段 |
|  | 有效期 | expiredate | String | 4 | Y | 加密字段，YYMM |
|  | 卡ID | cardid | String | 10 | Y |  |
| 总记录数 |  | total | Number | 10 | Y |  |
| 页码数 |  | pageindex | Number | 10 | Y | 表示第几页 |
| 分页数 |  | pagesize | Number | 10 | Y | 每页显示记录数 |

###  3011-查看共享卡子卡场景

接口：/gcpapi/card/v2/getcardscene 方向：合作方->通联

说明：查看卡当前场景设置；

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 卡ID | cardid | String | 10 | Y |  |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 场景名称 | scenename | String | 50 | Y | 保证唯一 |
| 场景名称 | scenename | String | 50 | Y | 保证唯一 |
| 使用场景 | cycle | String | 1 | Y | 1:期限，2:周期，3:单次 |
| 允许交易币种 | currency | String | 100 | Y | 见附录【1115-币种信息】 |
| 是否仅支持香港地区交易 | onlhkflag | String | 1 | O | Y:是，N：否 |
| 最大消费笔数 | authmaxcount | String | 10 | O |  |
| 卡片额度/固定消费金额 | authmaxamoun | String | 10 | O | 在固定消费金额时，代表固定消费金额 |
| 是否固定消费金额 | fixedamountflag | String | 1 | O | 使用场景为仅单次时填入,Y:是，N：否 |
| 使用期限起始日期 | begindate | String | 10 | O | 使用场景仅为期限时响应，YYYY-MM-DD |
| 使用期限结束日期 | enddate | String | 10 | O | 使用场景仅为期限时响应，YYYY-MM-DD |
| 周期设置-自然月 | naturalmonthflag | String | 1 | O | 使用场景仅为周期时填入,Y:是，N：否 |
| 周期设置-自然日设置 | naturalmonthstartday | String | 2 | O | 周期设置-自然月为否是填入，1-28之间 |
| MCC黑名单 | mccblacklist | String | 4000 | O |  |
| 商户号白名单 | merwhitelist | String | 4000 | O |  |
| 商户号黑名单 | merblacklist | String | 4000 | O |  |
| 创建时间 | createtime | String | 20 | Y | yyyy-mm-dd hh:mi:ss |

###  3012-设置资金共享卡额度

接口：/gcpapi/sharefund/adjustquota 方向：合作方->通联

说明：设置资金共享卡消费额度；

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 卡ID | cardid | String | 10 | Y |  |
| 账单币种 | currency | String | 100 | Y |  |
| 额度 | amount | Number | 18,2 | Y |  |
| 单笔最大限额 | singlemaxamount | Number | 18,2 | O |  |
| 单日最大限额 | daymaxamount | Number | 18,2 | O |  |
| 单月最大限额 | monthmaxamount | Number | 18,2 | O |  |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 响应公共参数 |  |  |  |  |  |

###  3013-虚拟卡激活

接口：/gcpapi/card/v2/virtualcardactive 方向：合作方->通联

说明：正对虚拟卡在待激活状态下激活使用；

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 卡ID | cardid | String | 10 | Y |  |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 响应公共参数 |  |  |  |  |  |

###  3014-修改持卡人邮箱

接口：/gcpapi/card/editcardholder 方向：合作方->通联

说明：修改持卡人邮箱，同步接口响应成功即说明修改成功；

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 卡ID | cardid | String | 10 | Y |  |
| 邮箱 | email | String | 50 | Y |  |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 响应公共参数 |  |  |  |  |  |

## 卡余额充提（原卡保证金充提）

### 3100-卡充值（原 缴纳保证金）

接口：/gcpapi/card/v2/deposit 方向：合作方->通联

说明：用于发起缴纳卡充值申请；申请状态变更通过3005-卡申请单状态通知接口进行通知；

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单流水 | meraplid | String | 32 | Y | 客户自己生成，保持唯一 |
| 卡ID | cardid | String | 10 | Y |  |
| 出账账户-VA账户 | payerid | String | 30 | A | 【VA账户列表查询】响应报文的账户唯一标识id,与payeraccount必选其一 |
| 出账账户-通联虚拟账户 | payeraccount | String | 30 | A | 通联内部分配记账户，与payerid必选其一 |
| 缴纳金额 | amount | Number | 18,2 | Y |  |
| 交易对手 | payeeaccount | String | 30 | O |  |
| 采购内容 | procurecontent | String | 100 | O |  |
| 卡资金对应合同协议 | agmfid | String | 100 | O | 通过文件上传接口上传协议后，上送协议fid |
| 卡资金到账模式 | fullpaymentmode | String | 1 | O | F：卡资金全额到账（手续费及其他费用外扣VA账户）<br>其他或者为空时，手续费及其他费用在缴纳卡资金额中扣减 |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单号 | applyid | String | 32 | Y |  |

### 3101卡提现（原提取保证金）

接口：/gcpapi/card/v2/withdraw 方向：合作方->通联

说明：用于发起提现卡余额（保证金）申请；；申请状态变更通过3005-卡申请单状态通知接口进行通知；

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单流水 | meraplid | String | 32 | Y | 客户自己生成，保持唯一 |
| 卡ID | cardid | String | 10 | Y |  |
| 卡提现账户-VA账户 | payeeid | String | 30 | A | 【VA账户列表查询】响应报文的账户唯一标识id,与payeeaccount必选其一 |
| 卡提现账户-通联虚拟账户 | payeeaccount | String | 30 | A | 通联内部分配记账户，与payeeid必选其一 |
| 卡提现金额 | amount | Number | 18,2 | Y |  |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单号 | applyid | String | 32 | Y |  |

### 3102-卡余额查询

接口：/gcpapi/card/v2/querybalance 方向：合作方->通联

说明：用于查询卡余额；

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 卡ID | cardid | String | 10 | Y |  |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 卡ID | cardid | String | 10 | Y |  |
| 币种 | currency | String | 3 | Y |  |
| 余额 | balance | Number | 18,2 | Y |  |
| 卡总额度 | authamount | Number | 18,2 | O | 仅共享子卡响应 |

### 3103-卡余额（原卡保证金）存提记录查询

接口：/gcpapi/card/v2/querybond 方向：合作方->通联

说明：用于查询卡余额（原卡保证金）缴存申请；

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 卡ID | cardid | String | 10 | Y |  |
| 交易类型 | trxcode | String | 10 | O | CP451：卡充值<br>CP452：卡提现 |
| 申请时间-起始 | createtimebegin | String | 8 | O | YYYYMMDD |
| 申请时间-截止 | createtimeend | String | 8 | O | YYYYMMDD |

响应报文

| 中文名称 |  | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- | --- |
| applylist数组 | 申请单流水 | meraplid | String | 32 | Y |  |
|  | 申请单号 | applyid | String | 32 | Y |  |
|  | 卡ID | cardid | String | 10 | Y |  |
|  | 交易类型 | trxcode | String | 10 | Y | CP451：卡充值<br>CP452：卡提现 |
|  | 申请单状态 | state | String | 2 | Y | 详细参考“附录——1107-卡申请单状态” |
|  | 申请金额 | amount | Number | 18,2 | Y |  |
|  | 入账金额 | entryamount | Number | 18,2 | Y |  |
|  | 币种 | currency | String | 3 | Y |  |
|  | 手续费 | fee | Number | 18,2 | O |  |
|  | 手续费币种 | feecurrency | String | 3 | O |  |
|  | 担保金金额 | securityamount | Number | 18,2 | O |  |
|  | 担保金币种 | securitycurrency | String | 3 | O |  |
|  | 申请时间 | createtime | String | 20 | Y | 格式YYYY-MM-DD hh:mm:ss |

## 卡片状态操作

### 3200-卡片激活

接口：/gcpapi/card/v2/active 方向：合作方->通联

说明：签收实体卡后，调用该接口激活实体卡（虚拟卡自动激活，无需调用接口激活）；

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 卡ID | cardid | String | 10 | Y |  |
| CVV2 | cvv | String | 3 | Y |  |
| 有效期 | expiredate | String | 4 | Y |  |
| 证件号码 | idnumber | String | 30 | Y |  |
| 出生日期 | birthday | String | 8 | Y | YYYYMMDD |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 响应公共参数 |  |  |  |  |  |

### 3201-卡止付

接口：/gcpapi/card/v2/freeze 方向：合作方->通联

说明：用于卡止付申请；

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单流水 | meraplid | String | 32 | Y | 客户自己生成，保持唯一 |
| 卡ID | cardid | String | 10 | Y |  |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 仅返回公共响应参数 |  |  |  |  |  |

### 3202-解除卡止付

接口：/gcpapi/card/v2/unfreeze 方向：合作方->通联

说明：用于解除卡止付申请；

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单流水 | meraplid | String | 32 | Y | 客户自己生成，保持唯一 |
| 卡ID | cardid | String | 10 | Y |  |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 仅返回公共响应参数 |  |  |  |  |  |

### 3203-卡挂失

接口：/gcpapi/card/v2/loss 方向：合作方->通联

说明：用于卡挂失申请；虚拟卡（包括主卡和子卡）不支持挂失操作。

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单流水 | meraplid | String | 32 | Y | 客户自己生成，保持唯一 |
| 卡ID | cardid | String | 10 | Y |  |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 仅返回公共响应参数 |  |  |  |  |  |

### 3204-解除卡挂失

接口：/gcpapi/card/v2/unloss 方向：合作方->通联

说明：用于卡挂失申请；

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单流水 | meraplid | String | 32 | Y | 客户自己生成，保持唯一 |
| 卡ID | cardid | String | 10 | Y |  |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 仅返回公共响应参数 |  |  |  |  |  |

### 3205-销卡

接口：/gcpapi/card/v2/cancel 方向：合作方->通联

说明：用于卡注销申请，需提现卡余额（原卡保证金），存在卡余额（原卡保证金）余额不能销卡，销卡操作需经过平台方审核，审核通过即可完成销卡，可通过申请单号查询3006-卡申请单查询接口查询结果；

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单流水 | meraplid | String | 32 | Y | 客户自己生成，保持唯一 |
| 卡ID | cardid | String | 10 | Y |  |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单号 | applyid | String | 32 | Y |  |

### 3206-解除销卡

接口：/gcpapi/card/v2/uncancel 方向：合作方->通联

说明：用于解除卡注销申请；通华金服共享卡子卡不支持解除销卡。

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单流水 | meraplid | String | 32 | Y | 客户自己生成，保持唯一 |
| 卡ID | cardid | String | 10 | Y |  |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 仅返回公共响应参数 |  |  |  |  |  |

### 3207-卡状态变更通知

接口：合作方域名url/cardchangenotify 方向：通联->合作方

说明：卡状态变更，主动发起通知合作方，涉及的状态变更的功能接口（卡挂失、解除卡挂失、卡止付、解除卡止付、销卡、解除销卡）。

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 卡ID | cardid | String | 10 | C | 卡片申请审核通过后生成的卡ID |
| 卡号 | cardno | String | 30 | C | 卡片申请审核通过后生成的卡号,脱敏状态 |
| 币种 | currency | String | 3 | Y |  |
| 卡形式 | cardtype | String | 1 | Y | 0：虚拟卡，1：实体卡 |
| 卡状态 | cardstate | String | 2 | Y | 参考附录：1106-卡状态 |

### 3208-查询卡状态

接口：/gcpapi/card/v2/querycardstate 方向：合作方->通联

说明：用于查询卡状态；

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 卡ID | cardid | String | 10 | Y |  |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 卡ID | cardid | String | 10 | Y |  |
| 卡号 | cardno | String | 30 | Y |  |
| 卡状态 | cardstate | String | 2 | Y | 参考附录：1106-卡状态 |
| 实体卡状态 | physstate | String | 2 | Y | 卡片为实体卡时，响应实体卡状态，该状态反应实体卡从制卡到激活过程；<br>00：未启动制卡（非实体卡时固定为该值；若申请实体卡，在虚拟卡发卡成功前为该值）<br>12：待制卡<br>13：待寄出<br>14：待激活<br>03：已激活（终态） |

## 6.4 卡共享资金管理

### 6.4.1 3301-新增共享资金账户

接口：/gcpapi/sharefund/create 方向：合作方->通联

说明：用于卡申请共享资金账户，新增成功响应applyid为共享资金账户唯一标识；共享资金账户既是从客户在通联虚拟户中创建一个子账户，用于卡消费，资金来源通联虚拟户，资金可以追加和释放;

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 资金账户名称 | fundname | String | 50 | Y |  |
| 金额 | amount | Number | 18,2 | Y |  |
| 币种 | currency | String | 3 | Y |  |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 资金账户申请号 | applyid | String | 32 | Y |  |

### 6.4.2 3302-共享资金追加

接口：/gcpapi/sharefund/transferin 方向：合作方->通联

说明：用于卡共享资金账户追加，资金从通联虚拟户到共享资金账户;

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 资金账户申请号 | applyid | String | 32 | Y |  |
| 金额 | amount | Number | 18,2 | Y |  |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 仅返回公共响应参数 |  |  |  |  |  |

### 6.4.3 3303-共享资金释放

接口：/gcpapi/sharefund/transferout 方向：合作方->通联

说明：用于卡共享资金账户追加，资金从共享资金账户到通联虚拟户;

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 资金账户申请号 | applyid | String | 32 | Y |  |
| 金额 | amount | Number | 18,2 | Y |  |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 仅返回公共响应参数 |  |  |  |  |  |

### 6.4.4 3304-共享资金账户查询

接口：/gcpapi/sharefund/query 方向：合作方->通联

说明：用于卡申请共享资金账户信息查询;

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 资金账户申请号 | applyid | String | 32 | Y |  |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 资金账户申请号 | applyid | String | 32 | Y |  |
| 资金账户名称 | fundname | String | 50 | Y |  |
| 账户余额 | balance | Number | 18,2 | Y |  |
| 币种 | currency | String | 3 | Y |  |
| 创建时间 | createtime | String | 20 | Y | 格式：yyyy-MM-dd HH:mm:ss |

# 卡交易信息接口

## 4000-授权交易明细查询

接口：/gcpapi/card/v2/qryauthtrans 方向：合作方->通联

说明：查询未入账交易明细信息。

请求报文：

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 卡ID | cardid | String | 10 | O |  |
| 交易状态 | state | String | 10 | O | 见附录【1105-授权交易状态】 |
| 交易类型 | trxcode | String | 25 | O | 见附录【1104-授权交易类型】 |
| 交易日期 | trxdate | String | 8 | Y | YYYYMMDD |
| 页码数 | pageindex | Number | 3 | O | 表示第几页，默认1 |
| 分页数 | pagesize | Number | 4 | O | 每页显示记录数，默认20，不得大于100 |

响应报文：

| 中文名称 |  | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- | --- |
| datalist | 卡ID | cardid | String | 10 | Y |  |
|  | 卡号 | cardno | String | 30 | Y |  |
|  | 流水号 | logkv | String | 50 | Y | 唯一主键 |
|  | 交易类型 | trxcode | String | 25 | Y | 见附录【1104-授权交易类型】 |
|  | 交易方向 | trxdir | String | 6 | O | 付款：101014<br>收款：101013 |
|  | 交易状态 | state | String | 10 | O | 见附录【1105-授权交易状态】 |
|  | 交易金额 | amount | Number | 18,2 | Y |  |
|  | 交易币种 | currency | String | 3 | Y |  |
|  | 预账单金额 | settleamount | Number | 18,2 | Y | 授权的冻结的金额， |
|  | 预账单币种 | settlecurrency | String | 3 | Y | 与卡账单币种一致 |
|  | 交易时间 | trxtime | string | 20 | Y | YYYY-MM-DD HH:mm:ss |
|  | 商户类别代码 | mcc | String | 20 | O |  |
|  | 受理机构名址 | trxaddr | String | 160 | O |  |
|  | 受理机构所属国家 | acqcountry | String | 3 | Y | 见附录【1111-国别信息】code |
|  | 交易响应码 | respcode | String | 4 | Y |  |
|  | 交易响应描述 | respmsg | String | 80 | O |  |
|  | 交易3DS验证标识 | dsflag | String | 1 | O | 交易是否3DS验证：1-是、0-否 |
|  | 授权码 | authcode | String | 50 | O |  |
|  | 对卡收取手续费 | fee | Number | 18,2 | O |  |
|  | 对卡收取手续费币种 | feecurrency | String | 3 | O |  |
| 总记录数 |  | total | Number | 10 | Y |  |
| 页码数 |  | pageindex | Number | 10 | Y | 表示第几页 |
| 分页数 |  | pagesize | Number | 10 | Y | 每页显示记录数 |

## 4001-已入账交易明细查询

接口：/gcpapi/card/v2/qrytrans 方向：合作方->通联

说明：查询已入账交易明细信息。

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 卡ID | cardid | String | 10 | O |  |
| 交易状态 | state | String | 10 | O | 见附录【1105-授权交易状态】 |
| 授权码 | authcode | String | 50 | O |  |
| 交易类型 | trxcode | String | 25 | O | 见附录【1104-授权交易类型】 |
| 交易日期 | trxdate | String | 8 | A | YYYYMMDD，交易日期&入账日期：必填其一 |
| 入账日期 | entrydate | String | 8 | A | YYYYMMDD，交易日期&入账日期：必填其一 |
| 页码数 | pageindex | Number | 3 | O | 表示第几页，默认1 |
| 分页数 | pagesize | Number | 4 | O | 每页显示记录数，默认20，不得大于100 |

响应报文

| 中文名称 |  | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- | --- |
| datalist | 卡ID | cardid | String | 10 | Y |  |
|  | 卡号 | cardno | String | 30 | Y |  |
|  | 入账流水号 | chnltrxseq | String | 50 | Y | 唯一主键 |
|  | 交易类型 | trxcode | String | 25 | Y | 见附录【1104-授权交易类型】 |
|  | 交易方向 | trxdir | String | 6 | O | 付款：101014<br>收款：101013 |
|  | 交易状态 | state | String | 10 | O | 见附录【1105-授权交易状态】 |
|  | 交易金额 | amount | Number | 18,2 | Y |  |
|  | 交易币种 | currency | String | 3 | Y |  |
|  | 入账金额 | entryamount | Number | 18,2 | Y | 清算时发卡行收到的资金动账数据 |
|  | 入账币种 | entrycurrency | String | 3 | Y | 与卡账单币种一致 |
|  | 交易时间 | trxtime | String | 20 | Y | YYYY-MM-DD HH:mm:ss |
|  | 入账日期 | entrydate | String | 8 | O | YYYYMMDD |
|  | 受理机构地址 | trxaddr | String | 160 | O |  |
|  | 授权码 | authcode | String | 50 | O |  |
|  | 流水号 | logkv | String | 50 | O | 非联机交易中，可能为空值 |
|  | 商户类别代码 | mcc | String | 20 | O |  |
| 总记录数 |  | total | Number | 10 | Y |  |
| 页码数 |  | pageindex | Number | 10 | Y | 表示第几页 |
| 分页数 |  | pagesize | Number | 10 | Y | 每页显示记录数 |

## 4002-授权交易通知

接口：合作方定义/cardtrxrst  方向： 通联->合作方

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 流水号 | logkv | String | 50 | Y | 唯一主键 |
| 交易类型 | trxcode | String | 25 | Y | 见附录【1104-授权交易类型】 |
| 卡ID | cardid | String | 10 | Y |  |
| 卡号 | cardno | String | 30 | Y |  |
| 状态 | state | String | 2 | Y | 见附录【1105-授权交易状态】 |
| 状态说明 | stateexplain | String | 200 | O |  |
| 交易金额 | amount | Number | 18,2 | Y |  |
| 交易币种 | currency | String | 3 | Y |  |
| 预账单金额 | settleamount | Number | 18,2 | Y | 授权的冻结的金额， |
| 预账单币种 | settlecurrency | String | 3 | Y | 与卡账单币种一致 |
| 交易时间 | trxtime | String | 20 | Y | YYYY-MM-DD HH:mm:ss |
| 交易方向 | trxdir | String | 6 | O | 付款：101014<br>收款：101013 |
| 受理机构名址 | trxaddr | String | 160 | O |  |
| 受理机构所属国家 | acqcountry | String | 3 | Y | 见附录【1111-国别信息】code |
| 授权码 | authcode | String | 50 | O |  |
| 商户类别代码 | mcc | String | 20 | O |  |
| 交易3DS验证标识 | is3ds | String | 1 | O | 交易是否3DS验证：1-是、0-否 |
| 对卡收取手续费 | fee | Number | 18,2 | O |  |
| 对卡收取手续费币种 | feecurrency | String | 3 | O |  |
| 交易响应码 | respcode | String | 4 | Y |  |
| 交易响应描述 | respmsg | String | 80 | O |  |
| 通知时间 | time | String | 25 | Y | 格式：YYYY-MM-DD HH:mm:ss |

## 7.4 4003-授权交易历史明细查询

接口：/gcpapi/card/v2/qryhisauthtrans 方向：合作方->通联

说明：查询未入账交易明细信息。

请求报文：

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 卡ID | cardid | String | 10 | A | 卡号或交易日期（起始、截止），二选一必填 |
| 交易日期起始 | trxdatestart | String | 8 | A | YYYYMMDD，时间间隔7日内 |
| 交易日期截止 | trxdateend | String | 8 | A |
| 交易状态 | state | String | 10 | O | 见附录【1105-授权交易状态】 |
| 交易类型 | trxcode | String | 25 | O | 见附录【1104-授权交易类型】 |
| 页码数 | pageindex | Number | 3 | O | 表示第几页，默认1 |
| 分页数 | pagesize | Number | 4 | O | 每页显示记录数，默认20，不得大于100 |

响应报文：

| 中文名称 |  | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- | --- |
| datalist | 卡ID | cardid | String | 10 | Y |  |
|  | 卡号 | cardno | String | 30 | Y |  |
|  | 流水号 | logkv | String | 50 | Y | 唯一主键 |
|  | 交易类型 | trxcode | String | 25 | Y | 见附录【1104-授权交易类型】 |
|  | 交易方向 | trxdir | String | 6 | O | 付款：101014<br>收款：101013 |
|  | 交易状态 | state | String | 10 | O | 见附录【1105-授权交易状态】 |
|  | 交易金额 | amount | Number | 18,2 | Y |  |
|  | 交易币种 | currency | String | 3 | Y |  |
|  | 交易时间 | trxtime | string | 20 | Y | YYYY-MM-DD HH:mm:ss |
|  | 预账单金额 | settleamount | Number | 18,2 | Y | 授权的冻结的金额， |
|  | 预账单币种 | settlecurrency | String | 3 | Y | 与卡账单币种一致 |
|  | 商户类别代码 | mcc | String | 20 | O |  |
|  | 受理机构地址 | trxaddr | String | 160 | O |  |
|  | 受理机构所属国家 | acqcountry | String | 3 | Y | 见附录【1111-国别信息】code |
|  | 授权码 | authcode | String | 50 | O |  |
|  | 交易3DS验证标识 | dsflag | String | 1 | O | 交易是否3DS验证：1-是、0-否 |
|  | 交易响应码 | respcode | String | 4 | Y |  |
|  | 交易响应描述 | respmsg | String | 80 | O |  |
|  | 对卡收取手续费 | fee | Number | 18,2 | O |  |
|  | 对卡收取手续费币种 | feecurrency | String | 3 | O |  |
| 总记录数 |  | total | Number | 10 | Y |  |
| 页码数 |  | pageindex | Number | 10 | Y | 表示第几页 |
| 分页数 |  | pagesize | Number | 10 | Y | 每页显示记录数 |

## 7.5 4004-已入账交易历史明细查询

接口：/gcpapi/card/v2/qryhistrans 方向：合作方->通联

说明：查询已入账交易明细信息。

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 卡ID | cardid | String | 10 | A | 卡号或交易日期（起始、截止），二选一必填 |
| 交易日期起始 | trxdatestart | String | 8 | A | YYYYMMDD，时间间隔7日内 |
| 交易日期截止 | trxdateend | String | 8 | A |
| 授权码 | authcode | String | 50 | O |  |
| 交易类型 | trxcode | String | 25 | O | 见附录【1104-授权交易类型】 |
| 入账日期 | entrydate | String | 8 | O | YYYYMMDD，交易日期&入账日期：必填其一 |
| 页码数 | pageindex | Number | 3 | O | 表示第几页，默认1 |
| 分页数 | pagesize | Number | 4 | O | 每页显示记录数，默认20，不得大于100 |

响应报文

| 中文名称 |  | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- | --- |
| datalist | 卡ID | cardid | String | 10 | Y |  |
|  | 卡号 | cardno | String | 30 | Y |  |
|  | 入账流水号 | chnltrxseq | String | 50 | Y | 唯一主键 |
|  | 交易类型 | trxcode | String | 25 | Y | 见附录【1104-授权交易类型】 |
|  | 交易方向 | trxdir | String | 6 | O | 付款：101014<br>收款：101013 |
|  | 交易状态 | state | String | 10 | O | 见附录【1105-授权交易状态】 |
|  | 交易金额 | amount | Number | 18,2 | Y |  |
|  | 交易币种 | currency | String | 3 | Y |  |
|  | 入账金额 | entryamount | Number | 18,2 | Y | 清算时发卡行收到的资金动账数据 |
|  | 入账币种 | entrycurrency | String | 3 | Y | 与卡账单币种一致 |
|  | 交易时间 | trxtime | String | 20 | Y | YYYY-MM-DD HH:mm:ss |
|  | 入账日期 | entrydate | String | 8 | O | YYYYMMDD |
|  | 受理机构地址 | trxaddr | String | 160 | O |  |
|  | 授权码 | authcode | String | 50 | O |  |
|  | 流水号 | logkv | String | 50 | O | 非联机交易中，可能为空值 |
|  | 商户类别代码 | mcc | String | 20 | O |  |
| 总记录数 |  | total | Number | 10 | Y |  |
| 页码数 |  | pageindex | Number | 10 | Y | 表示第几页 |
| 分页数 |  | pagesize | Number | 10 | Y | 每页显示记录数 |

## 7.6 4005-授权+入账交易信息查询

接口：/gcpapi/card/v2/qryauthposttrans 方向：合作方->通联

说明：查询交易明细信息，未入账交易，入账信息（入账金额、入账时间）为空。

请求报文：

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 卡ID | cardid | String | 10 | O |  |
| 交易状态 | state | String | 10 | O | 见附录【1105-授权交易状态】 |
| 交易类型 | trxcode | String | 25 | O | 见附录【1104-授权交易类型】 |
| 交易日期开始 | trxdatestart | String | 8 | A | YYYYMMDD |
| 交易日期截至 | trxdateend | String | 8 | A | YYYYMMDD |
| 入账日期开始 | postdatestart | String | 8 | A | YYYYMMDD |
| 入账日期截至 | postdateend | String | 8 | A | YYYYMMDD |
| 页码数 | pageindex | Number | 3 | O | 表示第几页，默认1 |
| 分页数 | pagesize | Number | 4 | O | 每页显示记录数，默认20，不得大于100 |

响应报文：

| 中文名称 |  | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- | --- |
| datalist | 卡号 | cardno | String | 30 | Y | 脱敏，前6后4 |
|  | 卡ID | cardid | String | 10 | Y |  |
|  | 流水号 | logkv | String | 50 | Y | 唯一主键 |
|  | 交易类型 | trxcode | String | 25 | Y | 见附录【1104-授权交易类型】 |
|  | 交易方向 | trxdir | String | 6 | O | 付款：101014<br>收款：101013 |
|  | 交易状态 | state | String | 10 | O | 见附录【1105-授权交易状态】 |
|  | 交易金额 | amount | Number | 18,2 | Y |  |
|  | 交易币种 | currency | String | 3 | Y |  |
|  | 预账单金额 | settleamount | Number | 18,2 | Y |  |
|  | 预账单币种 | settlecurrency | String | 3 | Y |  |
|  | 交易时间 | trxtime | string | 20 | Y | YYYY-MM-DD HH:mm:ss |
|  | 商户类别代码 | mcc | String | 20 | O |  |
|  | 受理机构地址 | trxaddr | String | 160 | O |  |
|  | 交易响应码 | respcode | String | 4 | Y |  |
|  | 交易响应描述 | respmsg | String | 80 | O |  |
|  | 授权码 | authcode | String | 50 | O |  |
|  | 交易3DS验证标识 | dsflag | String | 1 | O | 交易是否3DS验证：1-是、0-否 |
|  | 入账日期 | postdate | String | 8 | O | YYYYMMDD |
|  | 入账金额 | postamount | Number | 18,2 | O | 清算时发卡行收到的资金动账数据 |
|  | 入账币种 | postcurrency | String | 3 | O | 与卡账单币种一致 |
|  | 对卡收取手续费 | fee | Number | 18,2 | O |  |
|  | 对卡收取手续费币种 | feecurrency | String | 3 | O |  |
| 总记录数 |  | total | Number | 10 | Y |  |
| 页码数 |  | pageindex | Number | 10 | Y | 表示第几页 |
| 分页数 |  | pagesize | Number | 10 | Y | 每页显示记录数 |

## 7.7 4006-3DS验证码发送结果通知

接口：合作方定义/optresultnotify  方向： 通联->合作方

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 卡ID | cardid | String | 10 | Y |  |
| 状态 | resultflag | String | 2 | Y | 1:成功<br>0:失败 |
| 通知时间 | sendtime | String | 25 | Y | 格式：YYYY-MM-DD HH:mm:ss |

# 子商户管理接口

## 5000-子商户状态查询

接口：/gcpapi/card/mermanage/detail 方向：合作方->通联

说明：用于查询子商户信息和状态；

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 跟踪号 | meraplid | String | 32 | Y | 与原创建请求一致。 |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 跟踪号 | ctid | String | 15 | Y | 相同注册的唯一标识 |
| 客户号 | cusid | String | 15 | Y |  |
| 客户名 | cusname | String | 100 | Y |  |
| 状态 | state | String | 2 | Y | 00：审核中; 01：已注册;05：审核失败 |

## 5001-子商户创建

接口：/gcpapi/card/mermanage/create 方向：合作方->通联

说明：用于创建子商户；

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 跟踪号 | meraplid | String | 32 | Y | 客户自己生成，保持唯一 |
| 商户名称 | cusname | String | 30 | Y |  |
| 商户性质 | flag | String | 3 | Y | 1: 合资、股份制、民营<br>2: 世界500强或国有<br>3:个体户<br>4: 个人 |
| 营业执照名称 | buslicensename | String | 100 | Y |  |
| 注册国家/地区 | areacode | String | 10 | Y | 见附录【1111-国别信息】中的CODE,如中国：CHN |
| 注册（联系）地址 | address | String | 100 | Y |  |
| 客户英文名称 | cusengname | String | 100 | Y |  |
| 联系电话 | tel | String | 30 | Y |  |
| 邮箱 | legalemail | String | 30 | Y |  |
| 法人姓名 | legal | String | 30 | Y |  |
| 法人国籍 | legalarea | String | 10 | Y | 见附录【1111-国别信息】中的CODE,如中国：CHN |
| 法人证件类型 | legalidtype | String | 10 | Y | 01：居民身份证<br>02：军人或武警身份证<br>03：港澳台通行证<br>04：护照<br>05：其他有效旅行证件<br>06：其他类个人有效证件 |
| 法人证件号 | legalidno | String | 30 | Y |  |
| 法人证件有效期 | legalidexpire | String | 30 | Y | YYYYMMDD |
| 法人代表住址 | legaladdress | String | 200 | Y |  |
| 法人代表职业 | legaloccop | String | 30 | O |  |
| 法人代表手机号码 | legaltel | String | 30 | O |  |
| 控股股东或实际控制人姓名 | holdername | String | 30 | O |  |
| 控股股东或实际控制人证件号 | holderidno | String | 30 | O |  |
| 控股股东或实际控制人证件有效期 | holderexpire | String | 30 | O | YYYYMMDD |
| 法人身份证正面 | legalphotofrontfid | String | 200 | Y | 附件fid |
| 法人身份证正面 | legalphotobackfid | String | 200 | Y | 附件fid |
| 子卡商户合作协议 | agreementfid | String | 200 | Y | 附件fid |
| 注册国家/地区areacode为中国（CHN）时 |  |  |  |  |  |
| 所在省份 | province | String | 10 | Y | 见附件【1112-地区代码】 |
| 所在城市 | city | String | 10 | Y | 见附件【1112-地区代码】 |
| 是否三证合一 | threcertflag | String | 2 | Y | 0-否、1-是 |
| 三证合一（threcertflag=1）时 |  |  |  |  |  |
| 统一社会信用证代码 | creditcode | String | 30 | Y | 统一社会信用证代码 |
| 统一社会信用证代码有效期 | creditcodeexpire | String | 30 | Y | YYYYMMDD，统一社会信用证代码有效期 |
| 统一社会信用证及影印件 | credifid | String | 200 | Y | 填入统一社会信用证及影印件上传文件fid |
| 三证不合一（threcertflag=0）时 |  |  |  |  |  |
| 统一社会信用证代码 | creditcode | String | 30 | Y | 统一社会信用证代码 |
| 统一社会信用证代码有效期 | creditcodeexpire | String | 30 | Y | YYYYMMDD，统一社会信用证代码有效期 |
| 统一社会信用证及影印件 | credifid | String | 200 | Y | 填入统一社会信用证及影印件上传文件fid |
| 组织机构代码 | organcode | String | 30 | Y | 填入组织机构代码； |
| 组织机构代码 | organcodeexpire | String | 30 | Y | YYYYMMDD，填入组织机构代码有效期 |
| 组织机构代码及影印件 | organfid | String | 200 | Y | 填入组织机构代码及影印件上传文件fid |
| 营业执照代码 | buslicense | String | 10 | Y | 填营业执照代码 |
| 营业执照有效期 | buslicenseexpire | String | 30 | Y | YYYYMMDD，填营业执照有效期 |
| 营业执照 | buslicensefid | String | 200 | Y | 填入营业执照上传文件fid |
| 注册国家/地区areacode为香港（HKG）时 |  |  |  |  |  |
| 组织机构代码 | organcode | String | 30 | Y | 填入组织机构代码； |
| 组织机构代码 | organcodeexpire | String | 30 | Y | YYYYMMDD，填入组织机构代码有效期 |
| 商业登记证BR | organfid | String | 200 | Y | 填入商业登记证BR上传文件fid |
| 营业执照代码 | buslicense | String | 10 | Y | 填营业执照代码 |
| 营业执照有效期 | buslicenseexpire | String | 30 | Y | YYYYMMDD，填营业执照有效期 |
| 公司注册证书CR | buslicensefid | String | 200 | Y | 填入公司注册证书CR传文件fid |
| 注册国家/地区areacode为其他（非中国、香港）时 |  |  |  |  |  |
| 营业执照代码 | buslicense | String | 10 | Y | 填营业执照代码 |
| 营业执照有效期 | buslicenseexpire | String | 30 | Y | YYYYMMDD，填营业执照有效期 |
| 营业执照 | buslicensefid | String | 200 | Y | 填入营业执照上传文件fid |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 子商户编号 | cusid | String | 30 | C | 成功时响应 |

## 5002-子商户审核通知

接口：合作方定义/cusauditrst  方向：通联->合作方

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 跟踪号 | meraplid | String | 32 | Y | 相同注册的唯一标识 |
| 子商户号 | cusid | String | 15 | C | 状态为审核成功时返回 |
| 状态 | state | String | 2 | Y | 04：审核成功; 05：审核失败; |

# 文件

## 7000-文件上传

接口：/gcpapi/file/upload?fid=fileid&spos=position&zip=$iszip 方向：合作方->通联

注意：**HTTP头Content-Type必须使用application/octet-stream**

请求报文为文件内容字节码经过**BASE64 RFC4648\_URLSAFE**格式编码后的内容（Java参考使用Base64. getUrlEncoder()对象进行编码），单文件上传限制20M以内。

文件上传时，安全签名的签名子串内RequestPayload为源文件未Base64编码的字节内容。

请求参数

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 文件ID | fid | String | 80 | Y | 同一客户内文件唯一标识，包含原文件格式后缀。<br>eg: 39s20s.png |
| 压缩文件 | zip | boolean | 10 | C | 是否压缩文件，true/false |
| 开始字节 | spos | long |  | C | 上传开始的字节位置，用于续传，默认：0 |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 响应公共参数 |  |  |  |  |  |

## 7001-文件上传查询

接口：/gcpapi/file/upquery 方向：合作方->通联

说明：该接口为上传中断后，可以查询上次传输的文件大小。达到续传目的。

请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 文件ID | fid | String | 80 | Y | 同一客户内文件唯一标识 |

响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| fsize | 当前文件大小 | long |  | C | 当前文件大小，可以用于续上传的fpos |

## 7002-对账单下载

接口：/gcpapi/file/downdailyreport  方向：合作方->通联

说明： 下载商户当天的对账单信息。

文件zip格式。

请求报文: 

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 账单日期 | date | String | 25 | Y | yyyy-MM-dd |

响应文件

[请至钉钉文档查看附件《对账单样表.xlsx》](https://alidocs.dingtalk.com/i/nodes/93NwLYZXWygxG9obTnZwZv0eJkyEqBQm?iframeQuery=anchorId%3DX02m0bt9k2lgogy5awbz4n)

## 7005-通华金服共享卡子卡信息下载(加密文件)

接口：/gcpapi/file/v2/downvapinfoaes  方向：合作方->通联

说明： 下载通华金服共享卡子卡申请成功的子卡信息。申请后7天内有效，7天后逾期不可下载；

请求报文: 

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 申请单号 | applyid | String | 32 | Y |  |

响应报文

响应报文为.csv文件，使用敏感数据加密秘钥对文件流做AES对称加密，接收后需对文件进行解密，可参考附件demo；

csv文件表头：

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 卡号 | cardno | String | 30 | Y |  |
| 有效期 | expiredate | String | 4 | Y | YYMM |
| CVV | cvv | String | 3 | Y |  |
| 卡ID | cardid | String | 10 | Y |  |

# 附录

## 1101-跨境平台API响应码

对于响应码该版本仍未细分，后续版本会完善细分各类情况。

| **响应码** | **响应信息** | **说明** |
| --- | --- | --- |
| 0000 | 请求处理成功 |  |
| A999 | 系统内部异常，请联系管理员排查 |  |
| 0999 | 部分原因导致结果未知 | 后续结果可查询或咨询相关人员得知 |
| 1010 | reqid请求参数为空 |  |
| 1011 | cusid请求参数为空 |  |
| 1012 | merid请求参数为空或不存在 |  |
| 1013 | X-AGCP-Crdtl有误 |  |
| 1014 | X-AGCP-Auth有误 |  |
| 1015 | 密钥ID错误 |  |
| 1016 | 文件ID包含非法字符 |  |
| 1017 | cusid与用户所属客户号不一致 |  |
| 1018 | 客户间不存在授权关系 |  |
| 1019 | 文件spos有误 |  |
| 1020 | X-AGCP-Date有误 |  |
| 1021 | X-AGCP-Date时间与本系统时间相差超过30000毫秒 |  |
| 1050 | 签名不匹配 |  |
| 1051 | 验签错误 |  |
| 1052 | BASE64解码错误 |  |
| 1053 | 密钥ID不存在 |  |
| 1054 | 签名算法不匹配 |  |
| 1024 | 客户状态异常 |  |
| 1040 | 商户未开通产品类型 |  |
| 1030 | 数据不存在 | 修改类和查询类接口查询失败 |
| 1032 | 数据重复/主键冲突 |  |
| 1022 | 请求参数不规范 |  |
| 1023 | 请求参数缺失 |  |
| 1025 | 原交易被冲正或取消 |  |
| 1026 | 交易被冲正或取消 |  |
| 2020 | 状态错误 |  |
| 1200 | 不支持的交易币种 |  |
| 1070 | 客户账户不存在 |  |
| 1500 | RPC服务调用失败 |  |
| 1031 | 申请单不匹配 | 申请单的商户号和调用方merid不匹配 |
| 1036 | 申请单号错误 |  |
| 1041 | 汇率异常 |  |
| 1045 | 申报明细金额不足 |  |
| 1070 | 提现客户账户不存在 |  |
| 1071 | 非交易时间 |  |
| 1072 | 交易明细不存在 |  |
| 1073 | 对账明细/网银明细状态错 |  |
| 2200 | 账户错误 |  |
| 2201 | 无效卡号 |  |
| 1039 | 余额不足 |  |
| 2205 | 金额错误 |  |
| 2202 | 过期卡 |  |
| 2203 | 密码错误 |  |
| 2204 | 卡状态异常，咨询发卡行 |  |
| 2206 | 手机号错误 | 非预留手机号 |
| 2209 | 该卡片不支持该功能 |  |
| 2010 | 受益实体状态异常 |  |
| 2011 | 请求未发生变更 |  |
| 2012 | 受益实体统一信用代码重复 |  |
| 1060 | 收款人账户不存在 |  |
| 3000 | 渠道方异常，查发卡行 |  |
| 3001 | 渠道请求超时 |  |
| 5000 | 有风险的 |  |
| 5001 | 超过上限 |  |
| 5002 | 未过下限 |  |
| 1500 | 内部服务异常 |  |

## 1102-支付交易类型

| 编码 | 说明 | 备注 | 存在申请单 | 动账通知 | 申请通知 |
| --- | --- | --- | --- | --- | --- |
| CP201 | 汇款充值 | 外部资金汇入 |  | 6003 |  |
| CP213 | 伞形账户入账 |  | √ | 6003 | 2004 |
| CP109 | 离岸下发 | 资金提现 | √：当前不支持接口发起 |  | 2004 |
| CP110 | 离岸换汇 |  | √ |  | 2004 |
| CP462 | 释放担保金 |  | √：不需要客户主动发起 |  | 2004 |

## 1108-支付类申请单状态

| state | 状态名 | 说明 |
| --- | --- | --- |
| 中间态： |  |  |
| 01 | 处理中 | 提交申报明细成功后的状态，此时需要运营人员初审通过。 |
| 05 |  | 交易处理渠道处理中间过程。 |
| 16 |  | 初审通过后的状态，此时需要运营人员复审通过。 |
| 12 |  | 入金待收款环节。 |
| 17 |  | 重发渠道；渠道处理失败后，由运营人员重发重试 |
| 40 |  | 入金退款处理中。入金失败后进入退款过程 |
| 02 |  | 通联方运营人员审核申请单不通过。 |
| 需要操作的状态: |  |  |
| 13 | 待确认 | 提交申请单后，未确认。 |
| 38 | 待补充材料 |  |
| 终止态： |  |  |
| 06 | 处理成功 |  |
| 07 | 处理失败 | 申请单处理失败，具体原因根据提示了解。 |
| 11 | 交易已关闭 | 申请单流程中登录商户平台手动关闭，或由运营人员手动关闭申请单。 |
| 23 | 已退款 |  |

## 1103-卡申请交易类型

| 编码 | 说明 | 备注 | 申请单创建 | 申请单通知 | 卡状态通知 | 卡内资金通知 |
| --- | --- | --- | --- | --- | --- | --- |
| CP450 | 开卡 | 申请开卡(主卡和子卡) | 主卡：3000<br>子卡：3001 | 3005 |  |  |
| CP453 | 注销 | 卡的注销/撤回注销 | 3205 | 3005 | 3207 |  |
| CP458 | 注销撤回 |  | 3206 | 3005 | 3207 |  |
| CP451 | 卡充值 | 卡片资金充值 | 3100 | 2004 |  | 4002 |
| CP452 | 卡提现 | 卡片资金提现 | 3101 | 2004 |  | 4002 |
| CP460 | 通华金服共享卡子卡开卡 | 申请开卡(通华金服共享卡子卡) | 3004 | 3005 |  |  |

## 1107-卡申请单状态

| state | 状态名 |
| --- | --- |
| 01 | 待审核 |
| 02 | 审核不通过 |
| 03 | 处理中 |
| 04 | 处理成功 |
| 05 | 处理失败 |
| 06 | 退卡处理中 |
| 07 | 已关闭 |
| 08 | 待复核 |

## 1104-授权交易类型

| 交易类型 | 描述 |
| --- | --- |
| Auth | 消费 |
| ReturnOL | 联机退货 |
| Credit | 卡充值（原保证金充值） |
| Cash | 卡提现（原保证金提现） |
| AcctVerfication | 账户验证 |
| AuthCancel | 消费撤销 |
| AuthIncremental | 追加消费 |
| PreAuth | 预授权 |
| PAComp | 授权完成 |

## 1105-授权交易状态

| 交易状态 | 描述 |
| --- | --- |
| 00 | 成功 |
| 01 | 失败 |
| 02 | 被冲正 |

## 1106-卡状态

| state | 状态名 | 说明 |
| --- | --- | --- |
| 01 | 待审核 |  |
| 02 | 申请处理中 |  |
| 03 | 申请成功（正常） |  |
| 04 | 申请失败 |  |
| 05 | 已销卡 |  |
| 06 | 止付（冻结） |  |
| 07 | 运营冻结 |  |
| 08 | 销卡处理中 |  |
| 09 | 挂失 |  |
| 10 | 失效 |  |
| 11 | 销卡中（待审核） |  |
| 14 | 待激活 |  |

## 1109-卡产品类型

| 卡产品类型代码 | 卡产品类型名称 | 备注 |
| --- | --- | --- |
| 001001 | 通华金服VISA公务卡 | *   同时发行实体卡和虚拟卡。主要针对有实体卡需求的客户，不能共享额度，每次申请都需要填写持卡人的基本信息。<br>    <br>*   适用场景：商贸采购类 |
| 011001 | 万商义乌VISA商务卡 | *   与万商汇合作的的通华金服VISA公务卡。<br>    <br>*   适用场景：商贸采购类，不适用其他机构。 |
| 001201 | 通华金服VISA虚拟卡 | *   普通的虚拟卡片，不能共享额度，每次申请都需要填写持卡人的基本信息（包括姓名，身份证件,通华金服VISA虚拟卡,等)<br>    <br>*   适用场景：付广告费、OTA采购、物流费 |
| 021201 | 通华金服共享卡 | *   虚拟卡，但可以共享额度。且子卡非真正虚拟卡，都是token形式。可以批量申请，无需填写持卡人KYC身份信息，可以做交易规则的控制，比如消费次数、消费金额、消费币种等<br>    <br>*   适用场景：付广告费、OTA采购、物流费。此外VPA电子卡的BIN号会与主卡BIN号不一致。 |
| 4001 | 通华金服VISA虚拟卡-USD | 同上【通华金服VISA虚拟卡】用途 |
| 4002 | 通华金服VISA虚拟卡-USD | 同上【通华金服VISA虚拟卡】用途 |
| 4003 | 通华金服VISA虚拟卡-USD | 同上【通华金服VISA虚拟卡】用途 |
| 4004 | 通华金服VISA虚拟卡-HKD | 同上【通华金服VISA虚拟卡】用途 |
| 4020 | 自建卡账户虚拟卡-USD |  |

## 1110-证件类型

| **ftype** | **说明** |
| --- | --- |
| 01 | 居民身份证或临时身份证 |
| 02 | 军人或武警身份证件 |
| 03 | 港澳台通行证 |
| 04 | 外国公民护照 |
| 05 | 其他有效旅行证件 |
| 06 | 其他类个人身份有效证件 |
| 20 | 营业执照 |
| 99 | 其他 |

## 1111-国别信息

[请至钉钉文档查看附件《国别信息 .xlsx》](https://alidocs.dingtalk.com/i/nodes/93NwLYZXWygxG9obTnZwZv0eJkyEqBQm?iframeQuery=anchorId%3DX02m03h3lcooxrgtaryd1)

## 1112-地区代码

[请至钉钉文档查看附件《地区代码（更新20241129）.xlsx》](https://alidocs.dingtalk.com/i/nodes/93NwLYZXWygxG9obTnZwZv0eJkyEqBQm?iframeQuery=anchorId%3DX02m423ro4lyxn6939fja)

## 1114-地区银行识别码

[请至钉钉文档查看附件《地区银行识别码 .xlsx》](https://alidocs.dingtalk.com/i/nodes/93NwLYZXWygxG9obTnZwZv0eJkyEqBQm?iframeQuery=anchorId%3DX02m03h2e49lorzq0apdm)

## 1115-币种信息

[请至钉钉文档查看附件《币种信息 .xlsx》](https://alidocs.dingtalk.com/i/nodes/93NwLYZXWygxG9obTnZwZv0eJkyEqBQm?iframeQuery=anchorId%3DX02m1eerljs2hqqrmnx3ak)

## 1116-对接demo

[请至钉钉文档查看附件《gcppdemo-java.zip》](https://alidocs.dingtalk.com/i/nodes/93NwLYZXWygxG9obTnZwZv0eJkyEqBQm?iframeQuery=anchorId%3DX02mhmqs9yfia9da94j3ms)

[请至钉钉文档查看附件《gcpdemo-php.zip》](https://alidocs.dingtalk.com/i/nodes/93NwLYZXWygxG9obTnZwZv0eJkyEqBQm?iframeQuery=anchorId%3DX02mhmqjjos32sz305tp3q)

[请至钉钉文档查看附件《gcpdemo-go.zip》](https://alidocs.dingtalk.com/i/nodes/93NwLYZXWygxG9obTnZwZv0eJkyEqBQm?iframeQuery=anchorId%3DX02mhmqtn0s18q39hctl5qi)

# 帮助中心

**Q1、API对接第一步需要作什么？需要哪些对接参数？**

           1、需要找到客户经理，做客户信息录入、客户入网；客户入网后，会分配客户号（authcus）和商户号（authcus）以及默认的通联用卡平台的账户号（一般是客户号后加04，具体客户经理会提供）和通联用卡平台的URL（ 本文档1.9 基本对接流程）；

           2、需要自备一份RSA密钥，例如：使用在线平台生成：[https://www.toolscat.com/decode/rsa-publicKey-privateKey](https://www.toolscat.com/decode/rsa-publicKey-privateKey)

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/AJdl64AL3jrKqke1/img/c4b22b0f-db30-4424-819d-1bc66ac6c90f.png)

注：上面为私钥，下面为公钥

3、在登录用卡平台，与通联交换公钥，配置通知根地址和配置敏感信息密钥【1.9基本对接流程】

3.1，登录通联用卡平台，进行密钥配置(把自己的公钥粘贴在【商户公钥明文文本】文本框中)和获取通联公钥（通联公钥明文文本），保存后拿到密钥ID【1.3公共HTTP头】中使用；

3.2，在通用路径中配置通知根地址，该地址通用于所用通知接口，不同通知接口在该根接口后面追加。

例如：配置通知路径为：https://www.abc.com/api/contr

   入账通知接口发起通知为：https://www.abc.com/api/contr/acctbalauditrst

   卡申请单状态通知通知接口发起通知为：https://www.abc.com/api/contr/vpaauditrst

    其他：https://www.abc.com/api/contr/xx通知路径    等等；

3.3，敏感信息密钥配置，敏感信息密钥应用于【3007-查询卡支付信息】等有敏感数据加密；加密方式为AES对称加密，配置密钥后，客户端需做好保存以及防止泄露。涉及敏感数据查询结果为密文，需要用密钥解密方可查看；

**Q2、有关签名**

       对API请求及响应报文采用RSA非对称加密，私钥加签，公钥解签；对接方需自备一对RSA密钥（建议2048位），通联方也有一对RSA密钥；双方将交换公钥（登录通联商户平台，）；请求方用己方私钥加签，服务端用对方公钥验签；

**Q3、有没有快速对接方式，参考demo**

       为了提供对接效率，针对基础对接功能（签名、验签、报文组建、请求响应处理）等，在【本文10.附录 1116-对接demo】中提供了demo，仅供方便快速基础对接参考，实际功能实现以各自业务为准；