#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
A股资讯抓取辅助脚本
功能：验证股票代码、生成各渠道 URL、输出搜索词
用法：python fetch_news.py 600519 [贵州茅台]
"""
import sys, re
from datetime import datetime, timedelta

def validate_code(code):
    code = code.strip()
    if not re.match(r'^\d{6}$', code):
        return False, ""
    if code[:2] in ('60','68'):
        return True, "沪市"
    elif code[:2] in ('00','30'):
        return True, "深市"
    elif code[:2] in ('43','83','87'):
        return True, "北交所"
    return False, f"未知前缀{code[:2]}"

def get_prefix(code):
    if code[:2] in ('60','68'):
        return {'em':'sh','xq':'SH','name':'沪市'}
    elif code[:2] in ('00','30'):
        return {'em':'sz','xq':'SZ','name':'深市'}
    return {'em':'bj','xq':'BJ','name':'北交所'}

def main():
    if len(sys.argv) < 2:
        print("用法: python fetch_news.py <6位股票代码> [公司名称]")
        sys.exit(1)
    code = sys.argv[1].strip()
    name = sys.argv[2] if len(sys.argv) > 2 else ""
    valid, market = validate_code(code)
    if not valid:
        print(f"❌ 代码格式错误: {code}（需6位数字，以00/30/43/60/68/83/87开头）")
        sys.exit(1)
    p = get_prefix(code)
    today = datetime.now()
    week_ago = (today - timedelta(days=7)).strftime('%Y-%m-%d')
    print(f"\n{'='*55}")
    print(f"代码: {code} | 市场: {market}({p['name']}) | 公司: {name or '未知'}")
    print(f"资讯范围: {week_ago} ~ {today.strftime('%Y-%m-%d')}")
    print(f"{'='*55}")
    print("\n📌 各渠道访问 URL：")
    urls = {
        "东方财富行情": f"https://quote.eastmoney.com/{p['em']}{code}.html",
        "东方财富新闻": f"https://finance.eastmoney.com/a/c{code}.html",
        "雪球页面":    f"https://xueqiu.com/S/{p['xq']}{code}",
        "同花顺":      f"https://stockpage.10jqka.com.cn/{code}/",
        "巨潮公告":    f"http://www.cninfo.com.cn/new/disclosure/stock?stockCode={code}",
    }
    for k, v in urls.items():
        print(f"  [{k}] {v}")
    print("\n🔍 推荐搜索词：")
    queries = [f"{code} 最新公告", f"{code} 重大事项"]
    if name:
        queries += [
            f"{name} 最新消息 {today.strftime('%Y')}",
            f"{name} 研报 评级",
            f"site:eastmoney.com {name}",
            f"site:xueqiu.com {code}",
            f"{name} after:{week_ago}",
        ]
    for i, q in enumerate(queries, 1):
        print(f"  {i}. {q}")

if __name__ == "__main__":
    main()
