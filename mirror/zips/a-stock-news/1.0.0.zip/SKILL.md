---
name: a-stock-news
description: |
  A股资讯抓取技能。当用户输入A股股票代码（如600519、000858）或公司名称，自动从东方财富、
  新浪财经、雪球、同花顺、巨潮资讯等多渠道抓取最近一周资讯，生成含公告/新闻/研报/热议的报告。
  触发词：查资讯、查新闻、最近新闻、最近消息、近期动态、股票资讯、近况怎么样、有什么新闻、
         fetch news、stock news、资讯抓取、查一查这只股票。
version: 1.0.0
allowed-tools: Read, Write, Bash, WebSearch, WebFetch
---

# A股资讯抓取

## 概述

针对A股股票代码或公司名称，从多个公开渠道抓取**最近7天**资讯，生成结构化报告：
- 官方公告（巨潮资讯、上交所/深交所）
- 重要新闻（东方财富、新浪财经）
- 机构研报与评级变动（同花顺）
- 投资者热议（雪球社区）
- 聚合新闻（百度财经）

## 触发条件

满足以下任意一条即触发本 Skill：

1. 用户输入6位A股代码 + 资讯/新闻/消息/近况/动态等意图词
2. 用户提及"查资讯"、"查新闻"、"最近消息"、"近期动态"、"股票资讯"
3. 用户说"XXX 最近怎么样"、"帮我查 XXX 的消息"、"XXX 有没有什么大新闻"
4. 用户说"fetch news"、"stock news"、"资讯抓取"

## 执行流程

### Step 1：识别股票代码

从用户输入中提取6位数字代码：
- 60xxxx / 68xxxx → 沪市（URL前缀 sh，雪球前缀 SH）
- 00xxxx / 30xxxx → 深市（URL前缀 sz，雪球前缀 SZ）
- 43xxxx / 83xxxx / 87xxxx → 北交所（前缀 bj，雪球前缀 BJ）

若用户给公司名（如"茅台"、"比亚迪"），先用 web_search 查：
`"{公司名} 股票代码 A股"` → 确认6位代码后继续

运行辅助脚本校验并获取 URL 列表：
```bash
python scripts/fetch_news.py {code} {公司名}
```

### Step 2：获取公司基本信息

用 web_fetch 或 web_search 获取公司全称、行业、最新价格：
- 沪市行情页：https://quote.eastmoney.com/sh{code}.html
- 深市行情页：https://quote.eastmoney.com/sz{code}.html

### Step 3：多渠道并行抓取（时间范围：最近7天）

**渠道1 — 官方公告（⭐⭐⭐ 最高优先级）**
- web_search：`{公司名} 公告 site:cninfo.com.cn`
- web_fetch：`http://www.cninfo.com.cn/new/disclosure/stock?stockCode={code}`

**渠道2 — 东方财富（⭐⭐⭐）**
- web_search：`{公司名} 最新消息 site:eastmoney.com`
- web_fetch：`https://finance.eastmoney.com/a/c{code}.html`

**渠道3 — 新浪财经（⭐⭐）**
- web_search：`{公司名} site:finance.sina.com.cn`

**渠道4 — 雪球（⭐⭐）**
- web_search：`{code} site:xueqiu.com`
- 沪市页面：https://xueqiu.com/S/SH{code}
- 深市页面：https://xueqiu.com/S/SZ{code}

**渠道5 — 同花顺（⭐⭐）**
- web_search：`{公司名} 研报 site:10jqka.com.cn`
- web_fetch：`https://stockpage.10jqka.com.cn/{code}/`

**渠道6 — 百度新闻（⭐）**
- web_search：`{公司名} {code} after:{7天前的日期YYYY-MM-DD}`

### Step 4：内容筛选与整理

- 按时间倒序排列（最新在前）
- 同一事件多篇报道：保留最详细的，其余合并为摘要
- 重要度分级：官方公告 > 重大新闻 > 机构研报 > 一般资讯 > 社区讨论
- 每条资讯标注：来源名称 + 发布日期 + 原始链接（可获取时）
- 过滤明显广告和无关内容

### Step 5：生成结构化报告

参考 references/data_sources.md 中的"报告输出模板"生成 Markdown 报告。

## 注意事项

1. 不对资讯做投资价值判断，不给出买卖建议
2. 若某渠道无法访问，标注"该渠道暂无数据"后继续
3. 重大利好/利空事件加粗标注，保持客观中立
4. 若股票代码不存在，提示用户确认后退出

## 参考资料

- `references/data_sources.md`：各渠道详细 URL 模板与报告模板
- `scripts/fetch_news.py`：代码验证与搜索 URL 生成工具
