# A股资讯数据源手册

## 渠道优先级

| 优先级 | 渠道 | 类型 | 说明 |
|--------|------|------|------|
| ⭐⭐⭐ | 巨潮资讯 cninfo.com.cn | 官方公告 | 最权威，必查 |
| ⭐⭐⭐ | 东方财富 eastmoney.com | 综合新闻 | 覆盖最广 |
| ⭐⭐  | 新浪财经 finance.sina.com.cn | 快讯 | 更新快 |
| ⭐⭐  | 同花顺 10jqka.com.cn | 研报 | 机构评级 |
| ⭐⭐  | 雪球 xueqiu.com | 社区 | 投资者视角 |
| ⭐   | 百度财经 | 聚合 | 备用 |

## URL 模板

### 东方财富
- 沪市行情：https://quote.eastmoney.com/sh{code}.html
- 深市行情：https://quote.eastmoney.com/sz{code}.html
- 公司新闻：https://finance.eastmoney.com/a/c{code}.html

### 雪球
- 沪市：https://xueqiu.com/S/SH{code}
- 深市：https://xueqiu.com/S/SZ{code}
- 北交所：https://xueqiu.com/S/BJ{code}

### 同花顺
- 股票页：https://stockpage.10jqka.com.cn/{code}/

### 巨潮资讯（官方公告）
- 公告页：http://www.cninfo.com.cn/new/disclosure/stock?stockCode={code}

## 市场前缀对照

| 代码开头 | 市场 | EM前缀 | 雪球前缀 |
|---------|------|--------|---------|
| 60xxxx  | 沪市主板 | sh | SH |
| 68xxxx  | 科创板   | sh | SH |
| 00xxxx  | 深市主板 | sz | SZ |
| 30xxxx  | 创业板   | sz | SZ |
| 43/83/87xxxx | 北交所 | bj | BJ |

## 报告输出模板

```markdown
# {公司全称}（{code}）最近一周资讯报告
生成时间：{datetime}  |  资讯范围：{start} ~ {end}

## 📊 公司概览
- 股票代码：{code} | 公司名称：{name}
- 所属行业：{industry} | 最新价格：{price}

## 📢 重要公告 ⭐⭐⭐
| 日期 | 标题 | 来源 |
|------|------|------|

## 📰 重要新闻 ⭐⭐
1. **{title}** — {source} {date}
   > {summary}

## 📈 机构动态
- {研报/评级变化}

## 💬 市场热议
- {雪球/论坛热门观点}

## ⚠️ 免责声明
本报告仅汇总公开信息，不构成任何投资建议。
```

## 注意事项

1. 雪球内容需要登录，优先用 web_search 获取摘要
2. 巨潮公告 API 有时需要 POST，改用 web_search 代替
3. 若 web_fetch 失败，改用 web_search 搜索相同关键词
4. 时间过滤：Google 用 `after:YYYY-MM-DD`，百度用时间筛选
