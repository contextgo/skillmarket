# -*- coding: utf-8 -*-
"""
商圈竞品分析 v4（保留全部商品 + 配送价/竞价/毛利率）
修复：保留所有行（含无竞品商品），竞品售价为NaN的行竞品字段填'—'
"""
import pandas as pd
import os
from openpyxl import Workbook
from openpyxl.styles import PatternFill, Font, Border, Side, Alignment

# ══════════════════════════════════════════════════════════
# 1. 配置
# ══════════════════════════════════════════════════════════
DOWNLOADS   = r'C:\Users\33613\Downloads'
PRICE_FILE  = r'C:\Users\33613\Desktop\O2O商品价格表.xlsx'
OUTPUT_DIR   = r'C:\Users\33613\WorkBuddy\阿品-Claw\01_商圈竞品分析'

# 门店 → 竞品文件名（竞品名从文件名提取）
STORE_MAP = {
    '仰易':     ['正大康荣店', '一正仰义加盟'],
    '信一':     ['康佰家吾悦店', '布衣吾悦店', '延生堂吾悦店', '一正阳光店'],
    '同强':     ['康佰家罗阳店', '康佰家虹桥店', '延生堂新桥店'],
    '塘口':     ['康佰家虹桥店', '康佰家莘塍店', '张和堂莘塍店'],
    '安阳':     ['康佰家罗阳店', '张和堂安阳四店', '延生堂蕙兰苑店', '一正安阳店'],
    '广邻':     ['长生堂府东店', '延生堂楠溪江店', '龙湾永加店', '老百姓括苍西路店', '一正澜悦府'],
    '心桥':     ['长生堂心桥店', '老百姓新桥店', '布衣大药房瑞鸿锦园店', '延生堂新桥店', '一正国鼎店'],
    '新万春':   ['康佰家虹桥店', '一正万松店'],
    '济周堂':   ['康佰家莘塍店', '张和堂莘塍店', '一正汀田店'],
    '济民':     ['一正城北店', '一正城西店'],
    '潘桥':     ['长生堂上汇店', '张和堂潘桥店', '一正潘凤店'],
    '瓯北汇恩堂': ['一正龙桥店', '一正堡一店'],
    '瓯岐堂':   ['延生堂瞿溪店', '张和堂潘桥店'],
    '葆济':     ['张和堂飞云店', '康佰家飞云店', '一正飞云店'],
    '郭溪':     ['正大郭溪店', '延生堂瞿溪店', '宁丰堂三溪店', '一正塘下店'],
    '金海':     ['张和堂福荣店', '一正金海店'],
    '钱库':     ['康佰家吾悦店', '康佰家莘塍店'],
    '顺泰':     ['修正堂万茂店'],
    '罗凤':     ['一正仙岩店'],
}

# ══════════════════════════════════════════════════════════
# 2. 价格表加载
# ══════════════════════════════════════════════════════════
print('加载价格表...')
df_price = pd.read_excel(PRICE_FILE)
df_price.columns = df_price.columns.str.strip()

# 只用饿了么UPC匹配（数据来自饿了么后台）
df_price['UPC_match'] = df_price['饿了么UPC'].astype(str).str.replace(r'\.0+$', '', regex=True)
# 只保留有配送价的行
df_price = df_price[df_price['配送价'].notna()].copy()
upc_cost = dict(zip(df_price['UPC_match'], df_price['配送价']))
print(f'  价格表: {len(upc_cost)} 个UPC配送价')

# ══════════════════════════════════════════════════════════
# 3. 竞价策略函数
# ══════════════════════════════════════════════════════════
def calc_price(comp_price, cost):
    """返回 (竞价, 毛利率, 策略)
    竞价逻辑：竞品售价 - 0.01（元），统一策略
    """
    if pd.isna(comp_price):
        return ('—', '—', '无竞品')
    try:
        cp = float(comp_price)
    except:
        return ('—', '—', '—')
    try:
        c = float(cost) if pd.notna(cost) else 0
    except:
        c = 0

    # 确认竞价 = 竞品售价 - 0.01
    price = round(cp - 0.01, 2)
    strategy = '竞价低0.01'
    margin = round((price - c) / price * 100, 1) if price > 0 and c > 0 else 0
    return (price, margin, strategy)


def get_store_display(store):
    names = {
        '仰易': '仰易店', '信一': '信一店', '同强': '同强店',
        '塘口': '塘口店', '安阳': '安阳店', '广邻': '广邻店',
        '心桥': '心桥店', '新万春': '新万春店', '济周堂': '济周堂店',
        '济民': '济民大药房', '潘桥': '潘桥店', '瓯北汇恩堂': '瓯北汇恩堂',
        '瓯岐堂': '瓯岐堂', '葆济': '葆济店', '郭溪': '郭溪店',
        '金海': '金海店', '钱库': '钱库店', '顺泰': '顺泰店', '罗凤': '罗凤店',
    }
    return names.get(store, store + '店')


# ══════════════════════════════════════════════════════════
# 4. Excel 样式
# ══════════════════════════════════════════════════════════
BLUE_HDR  = PatternFill('solid', fgColor='3B82F6')
GREEN_BG  = PatternFill('solid', fgColor='D1FAE5')
RED_BG    = PatternFill('solid', fgColor='FEE2E2')
YELL_BG   = PatternFill('solid', fgColor='FEF9C3')
GRAY_BG   = PatternFill('solid', fgColor='F3F4F6')
WHITE_BG  = PatternFill('solid', fgColor='FFFFFF')
PURPLE_BG = PatternFill('solid', fgColor='EDE9FE')
FONT_W    = Font(bold=True, color='FFFFFF', size=10)
FONT_B    = Font(bold=True, size=10)
BORDER    = Border(
    left=Side(style='thin', color='E5E7EB'),
    right=Side(style='thin', color='E5E7EB'),
    top=Side(style='thin', color='E5E7EB'),
    bottom=Side(style='thin', color='E5E7EB'),
)
ALIGN_C   = Alignment(horizontal='center', vertical='center', wrap_text=True)
ALIGN_L   = Alignment(horizontal='left', vertical='center')


def safe_val(val):
    """处理NaN → 空字符串"""
    if val is None:
        return ''
    try:
        if str(val) == 'nan':
            return ''
    except:
        pass
    return val


def write_sheet(ws, df, cols):
    """写数据Sheet（所有列固定宽度）"""
    widths = {
        '商品名称': 32, 'UPC码': 16, '一级类目': 14, '二级类目': 12,
        '本店售价': 10, '竞品售价': 10, '价差': 9, '竞品名称': 20,
        '竞品月销量': 10, '月销量': 9, '配送价': 9, '确认竞价': 10,
        '毛利率': 9, '策略': 10,
    }
    for col, h in enumerate(cols, 1):
        ws.column_dimensions[chr(64 + col)].width = widths.get(h, 12)

    # 表头
    for col, h in enumerate(cols, 1):
        c = ws.cell(1, col, h)
        c.font = FONT_W
        c.fill = BLUE_HDR
        c.alignment = ALIGN_C
        c.border = BORDER
    ws.row_dimensions[1].height = 22

    # 数据
    for ri, (_, row) in enumerate(df.iterrows(), 2):
        bg = 'F0FDF4' if ri % 2 == 0 else 'FFFFFF'
        for col, field in enumerate(cols, 1):
            raw = row.get(field, '')
            val = safe_val(raw)
            c = ws.cell(ri, col, val)
            c.fill = PatternFill('solid', fgColor=bg)
            c.alignment = ALIGN_C
            c.border = BORDER
            c.font = Font(size=10)
            # 毛利率着色
            if field == '毛利率' and isinstance(val, (int, float)):
                if val >= 30:
                    c.fill = GREEN_BG
                    c.font = Font(bold=True, size=10, color='166534')
                elif val >= 15:
                    c.fill = YELL_BG
                    c.font = Font(bold=True, size=10, color='92400E')
                elif val > 0:
                    c.fill = RED_BG
                    c.font = Font(bold=True, size=10, color='991B1B')
            # 竞价着色（仅竞品有售价时）
            if field == '确认竞价':
                try:
                    v = float(val)
                    cp_raw = row.get('竞品售价', None)
                    if not isinstance(cp_raw, str):
                        cost = row.get('配送价', 0)
                        try:
                            c_val = float(cost)
                        except:
                            c_val = 0
                        margin = (v - c_val) / v * 100 if v > 0 and c_val > 0 else 0
                        try:
                            cp_v = float(cp_raw)
                            if v < cp_v:
                                c.fill = PatternFill('solid', fgColor='DCFCE7')
                            elif margin < 5:
                                c.fill = YELL_BG
                        except:
                            pass
                except:
                    pass
            # 策略标签
            if field == '策略':
                if val == '竞价低0.01':
                    c.fill = PatternFill('solid', fgColor='DCFCE7')
                    c.font = Font(bold=True, color='166534', size=10)
                elif val == '无竞品':
                    c.fill = PURPLE_BG
                    c.font = Font(color='6D28D9', size=10)
            # 价差
            if field == '价差':
                try:
                    v = float(val)
                    c.font = Font(bold=True, size=10,
                                  color='16A34A' if v < 0 else 'DC2626' if v > 0 else '6B7280')
                except:
                    pass
        ws.row_dimensions[ri].height = 18


# ══════════════════════════════════════════════════════════
# 5. 主循环
# ══════════════════════════════════════════════════════════
print('='*55)
print('商圈竞品分析 v4（全部商品 + 竞价版）')
print('='*55)

for store, comps in STORE_MAP.items():
    print(f'\n[{store}]')
    all_data = []

    for comp in comps:
        fname = f'比价数据2026-04-16{comp}.xlsx'
        fpath = os.path.join(DOWNLOADS, fname)
        if not os.path.exists(fpath):
            print(f'  [跳过] 文件不存在: {fname}')
            continue
        try:
            df = pd.read_excel(fpath)
            df.columns = df.columns.str.strip()
            df['竞品名称_file'] = comp  # 从文件名提取真实竞品名
            # 价差：竞品有售价时才有意义
            cp = pd.to_numeric(df['对比商品售价'], errors='coerce')
            sp = pd.to_numeric(df['售价'], errors='coerce')
            df['价差'] = sp - cp
            all_data.append(df)
            print(f'  {comp}: {len(df)}条（含{cp.notna().sum()}条有竞品价）')
        except Exception as e:
            print(f'  [错误] {comp}: {e}')
            continue

    if not all_data:
        print('  [跳过] 无数据')
        continue

    df_all = pd.concat(all_data, ignore_index=True)

    # ── 匹配配送价（所有行都要匹配）─────────────────────
    df_all['UPC_clean'] = df_all['条形码（69码）'].astype(str).str.replace(r'\.0+$', '', regex=True)
    df_all['配送价'] = df_all['UPC_clean'].map(upc_cost)

    # ── 计算竞价和毛利率（仅竞品有售价的行）─────────────
    # 无竞品行：竞价/毛利率/策略/竞品售价/竞品月销量/竞品名称/价差 填 '—'
    results = df_all.apply(
        lambda r: pd.Series(calc_price(
            r['对比商品售价'],
            r['配送价']
        ), index=['确认竞价', '毛利率', '策略']),
        axis=1
    )
    df_all['确认竞价'] = results['确认竞价']
    df_all['毛利率']  = results['毛利率']
    df_all['策略']     = results['策略']

    # 无竞品行填 '—'（先转object类型，否则数值列无法填字符串）
    no_comp_mask = df_all['对比商品售价'].isna()
    for col in ['竞品售价', '竞品月销量', '价差', '竞品名称']:
        if col in df_all.columns:
            df_all[col] = df_all[col].astype(object)
            df_all.loc[no_comp_mask, col] = '—'

    # ── 列重命名（合并的列）────────────────────────────
    df_all = df_all.rename(columns={
        '售价': '本店售价',
        '对比商品售价': '竞品售价',
        '对比商品月销量': '竞品月销量',
        '对比门店名称': '竞品名称',
        '条形码（69码）': 'UPC码',
    })

    total = len(df_all)
    matched = int(df_all['配送价'].notna().sum())
    no_comp_count = int(no_comp_mask.sum())

    def safe_lt(v, t): return float(v) < t if v != '—' else False
    def safe_gt(v, t): return float(v) > t if v != '—' else False
    adv_count  = sum(safe_lt(v, 0) for v in df_all['价差'])
    dis_count  = sum(safe_gt(v, 0) for v in df_all['价差'])
    eq_count   = total - adv_count - dis_count - no_comp_count

    print(f'  总: {total}条 | 有竞品: {total-no_comp_count}条 | 无竞品: {no_comp_count}条 | 价格表匹配: {matched}条')

    # ════════════════════════════════════════════════════
    # 新建 Workbook
    # ════════════════════════════════════════════════════
    store_display = get_store_display(store)
    wb = Workbook()
    wb.remove(wb.active)

    # ===== Sheet1: 总览 =====
    ws1 = wb.create_sheet('总览')
    ws1.column_dimensions['A'].width = 22
    ws1.column_dimensions['B'].width = 28

    t = ws1.cell(1, 1, f'{store_display} 商圈竞品价格分析')
    t.font = Font(size=16, bold=True, color='1F3864')
    ws1.merge_cells('A1:B1')
    ws1.row_dimensions[1].height = 36

    src = ws1.cell(2, 1, '数据来源：美团商家版 App → 竞品价格监控 | 配送价来源：国信O2O商品价格体系表')
    src.font = Font(size=9, italic=True, color='9CA3AF')
    ws1.row_dimensions[2].height = 18

    kpis = [
        ('本店',              store_display,        None),
        ('竞品数量',          f'{len(comps)} 个',    None),
        ('总比价商品',        f'{total} 条',         None),
        ('价格表匹配',        f'{matched} 条 ({matched/total*100:.1f}%)', 'FEF9C3'),
        ('低价优势(我方低)',   f'{adv_count} 条 ({adv_count/(total-no_comp_count)*100:.1f}%）', 'D1FAE5'),
        ('高价劣势(我方高)',   f'{dis_count} 条 ({dis_count/(total-no_comp_count)*100:.1f}%)', 'FEE2E2'),
        ('价格持平',          f'{eq_count} 条',     None),
        ('无竞品商品',         f'{no_comp_count} 条（竞品无此商品）', 'EDE9FE'),
    ]
    for i, (k, v, bg) in enumerate(kpis, 4):
        kc = ws1.cell(i, 1, k)
        vc = ws1.cell(i, 2, v)
        kc.font = Font(bold=True, size=11)
        vc.font = Font(size=11)
        kc.alignment = Alignment(horizontal='left', vertical='center')
        vc.alignment = Alignment(horizontal='center', vertical='center')
        if bg:
            vc.fill = PatternFill('solid', fgColor=bg)
            vc.font = Font(bold=True, size=11)
        ws1.row_dimensions[i].height = 24

    # ===== Sheet2: 调价建议（只看有竞品的商品）=====
    df_have = df_all[df_all['策略'] != '无竞品'].copy()
    if len(df_have) > 0:
        ws2 = wb.create_sheet('调价建议')
        write_sheet(ws2, df_have, [
            '商品名称', 'UPC码', '一级类目', '本店售价',
            '竞品售价', '竞品月销量', '价差', '配送价',
            '确认竞价', '毛利率', '策略', '竞品名称',
        ])

    # ===== Sheet3: 低价优势 =====
    df_low = df_all[df_all['价差'].apply(lambda v: safe_lt(v, 0))].copy()
    if len(df_low) > 0:
        ws3 = wb.create_sheet('低价优势')
        write_sheet(ws3, df_low, [
            '商品名称', 'UPC码', '一级类目', '本店售价',
            '竞品售价', '竞品月销量', '价差', '配送价',
            '确认竞价', '毛利率', '策略', '竞品名称',
        ])

    # ===== Sheet4: 高价劣势 =====
    df_high = df_all[df_all['价差'].apply(lambda v: safe_gt(v, 0))].copy()
    if len(df_high) > 0:
        ws4 = wb.create_sheet('高价劣势')
        write_sheet(ws4, df_high, [
            '商品名称', 'UPC码', '一级类目', '本店售价',
            '竞品售价', '竞品月销量', '价差', '配送价',
            '确认竞价', '毛利率', '策略', '竞品名称',
        ])

    # ===== Sheet5: 全部明细 =====
    ws5 = wb.create_sheet('全部明细')
    write_sheet(ws5, df_all, [
        '商品名称', 'UPC码', '一级类目', '二级类目', '本店售价',
        '竞品售价', '竞品月销量', '价差', '配送价',
        '确认竞价', '毛利率', '策略', '竞品名称', '月销量',
    ])

    # ════════════════════════════════════════════════════
    # 保存
    # ════════════════════════════════════════════════════
    out_name = f'商圈竞品分析_{store_display}_v4竞价.xlsx'
    out_path = os.path.join(OUTPUT_DIR, out_name)
    try:
        wb.save(out_path)
        print(f'  -> {out_name}')
    except PermissionError:
        print(f'  -> [跳过] 被占用: {out_name}')

print('\n全部完成！')
