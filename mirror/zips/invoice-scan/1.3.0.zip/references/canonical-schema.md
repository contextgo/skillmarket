# Canonical Invoice Schema v1.0.0

Every scan produces this structure regardless of AI provider.

## Top-Level

```
{ schemaVersion, header, referencedDocuments[], lineItems[], totals, metadata, fields[], validation, exceptions }
```

## header

invoiceNumber, invoiceDate (YYYY-MM-DD), dueDate, currency (ISO 4217), supplierName, supplierAddress, supplierVatNumber, buyerName, buyerAddress, buyerVatNumber, paymentTerms, paymentReference, bankDetails: { iban, bic, accountNumber, sortCode }

## lineItems[]

description, quantity, unitOfMeasure, unitPrice, lineTotal, vatRate (percentage), sku, discount

## referencedDocuments[]

type (PO|contract|GRN|inspection|timesheet|project|proforma|other), reference

## totals

netTotal, vatBreakdown[]: { rate, amount }, vatTotal, grossTotal

## metadata

confidence (0.0–1.0), language (ISO 639-1), pageCount, processingDurationMs, provider, extractionTimestamp (ISO 8601), documentType

## fields[]

Per-field detail: name, value, confidence, boundingBox ({ x, y, width, height, page } or null), extractionMethod (ocr|icr|stamp|inferred), failureReason

## validation

arithmeticValid (boolean), errors[]: { field, message }, warnings[]: { field, message }, documentQuality: { score, presentFields, totalChecked, rating (good|partial|poor) }

## exceptions

overallStatus (success|partial|failed|rejected), failedFields[], processingAttempts, rejectionReason
