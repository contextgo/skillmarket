/**
 * Excel (XLSX) Output Formatter
 * 
 * Produces a structured workbook with:
 * - Header sheet: invoice metadata
 * - Line Items sheet: line item details
 * - Validation sheet: confidence scores, flags, errors
 */

let XLSX;
try {
  XLSX = require('xlsx');
} catch (e) {
  XLSX = null;
}

/**
 * Convert canonical invoice to XLSX buffer.
 * @param {object} invoice
 * @returns {Buffer}
 */
function toExcel(invoice) {
  if (!XLSX) {
    throw new Error('xlsx package not installed. Run: npm install xlsx');
  }

  const wb = XLSX.utils.book_new();

  // --- Header Sheet ---
  const h = invoice.header;
  const headerData = [
    ['Field', 'Value'],
    ['Invoice Number', h.invoiceNumber],
    ['Invoice Date', h.invoiceDate],
    ['Due Date', h.dueDate],
    ['Currency', h.currency],
    ['Supplier Name', h.supplierName],
    ['Supplier Address', h.supplierAddress],
    ['Supplier VAT', h.supplierVatNumber],
    ['Buyer Name', h.buyerName],
    ['Buyer Address', h.buyerAddress],
    ['Buyer VAT', h.buyerVatNumber],
    ['Payment Terms', h.paymentTerms],
    ['Payment Reference', h.paymentReference],
    ['IBAN', h.bankDetails?.iban],
    ['BIC', h.bankDetails?.bic],
    ['Account Number', h.bankDetails?.accountNumber],
    ['Sort Code', h.bankDetails?.sortCode],
    ['', ''],
    ['Net Total', invoice.totals.netTotal],
    ['VAT Total', invoice.totals.vatTotal],
    ['Gross Total', invoice.totals.grossTotal],
    ['', ''],
    ['Confidence', invoice.metadata.confidence],
    ['Language', invoice.metadata.language],
    ['Provider', invoice.metadata.provider],
    ['Extracted At', invoice.metadata.extractionTimestamp],
  ];

  // Add referenced documents
  if (invoice.referencedDocuments.length > 0) {
    headerData.push(['', '']);
    headerData.push(['Referenced Documents', '']);
    for (const rd of invoice.referencedDocuments) {
      headerData.push([rd.type, rd.reference]);
    }
  }

  const headerSheet = XLSX.utils.aoa_to_sheet(headerData);
  headerSheet['!cols'] = [{ wch: 20 }, { wch: 50 }];
  XLSX.utils.book_append_sheet(wb, headerSheet, 'Header');

  // --- Line Items Sheet ---
  const lineItemHeaders = [
    'Description', 'Quantity', 'Unit', 'Unit Price',
    'Line Total', 'VAT Rate %', 'SKU', 'Discount',
  ];
  const lineItemRows = invoice.lineItems.map(li => [
    li.description, li.quantity, li.unitOfMeasure,
    li.unitPrice, li.lineTotal, li.vatRate, li.sku, li.discount,
  ]);
  const lineSheet = XLSX.utils.aoa_to_sheet([lineItemHeaders, ...lineItemRows]);
  lineSheet['!cols'] = [
    { wch: 40 }, { wch: 10 }, { wch: 10 }, { wch: 12 },
    { wch: 12 }, { wch: 12 }, { wch: 15 }, { wch: 12 },
  ];
  XLSX.utils.book_append_sheet(wb, lineSheet, 'Line Items');

  // --- Validation Sheet ---
  const valData = [
    ['Arithmetic Valid', invoice.validation.arithmeticValid ? 'YES' : 'NO'],
    ['', ''],
    ['Errors', ''],
  ];
  for (const err of invoice.validation.errors) {
    valData.push([err.field, err.message]);
  }
  if (invoice.validation.errors.length === 0) {
    valData.push(['(none)', '']);
  }
  valData.push(['', '']);
  valData.push(['Warnings', '']);
  for (const warn of invoice.validation.warnings) {
    valData.push([warn.field, warn.message]);
  }
  if (invoice.validation.warnings.length === 0) {
    valData.push(['(none)', '']);
  }

  // Add field confidence scores
  if (invoice.fields.length > 0) {
    valData.push(['', '']);
    valData.push(['Field Confidence', '']);
    valData.push(['Field', 'Confidence', 'Method']);
    for (const f of invoice.fields) {
      valData.push([f.name, f.confidence, f.extractionMethod]);
    }
  }

  const valSheet = XLSX.utils.aoa_to_sheet(valData);
  valSheet['!cols'] = [{ wch: 30 }, { wch: 60 }, { wch: 15 }];
  XLSX.utils.book_append_sheet(wb, valSheet, 'Validation');

  return XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
}

module.exports = { toExcel };
