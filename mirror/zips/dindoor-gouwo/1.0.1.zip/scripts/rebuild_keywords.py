#!/usr/bin/env python3
"""
重新生成所有条目的关键词，使用优化后的分词方法（jieba）
"""

import sqlite3
import os
from pathlib import Path

# 导入原gouwo模块的函数
import sys
sys.path.append(os.path.dirname(__file__))
from gouwo import extract_keywords, init_db, DB_PATH

def rebuild_all_keywords():
    """重新生成所有条目的关键词"""
    init_db()
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # 获取所有条目
    cursor.execute('SELECT id, content FROM knowledge')
    all_items = cursor.fetchall()
    
    if not all_items:
        print("🔍 没有找到任何条目")
        return
    
    print(f"🔍 开始重新生成 {len(all_items)} 个条目的关键词...\n")
    
    updated = 0
    for item_id, content in all_items:
        new_keywords = extract_keywords(content)
        cursor.execute(
            'UPDATE knowledge SET keywords = ? WHERE id = ?',
            (new_keywords, item_id)
        )
        updated += 1
        print(f"✓ ID {item_id}: {new_keywords}")
    
    conn.commit()
    conn.close()
    
    print(f"\n✅ 完成！共更新 {updated} 个条目的关键词")

if __name__ == '__main__':
    rebuild_all_keywords()
