from __future__ import annotations

from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "common"))

from base import print_chanjing_access_token_cli, resolve_chanjing_access_token  # noqa: E402


if __name__ == "__main__":
    print_chanjing_access_token_cli()
