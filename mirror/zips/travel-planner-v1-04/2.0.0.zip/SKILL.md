# Travel Planner Skill v2.0

AI 智能旅行规划系统，完全重写版，支持多平台真实数据抓取、GLM智能分析、完整比价和高质量文档输出。

---

## 功能模块

- **Intent Understanding** - 解析用户输入：目的地、天数、人数、预算、旅行模式（A/B/C/D）
- **Data Scraping** - 小红书/抖音真实搜索（浏览器自动化优先）+ GLM智能景点提取 + 本地兜底
- **Transportation** - 12306官网查询（仅查询不购票）+ 携程/去哪儿机票 + 多平台比价
- **Accommodation** - 携程/美团/去哪儿/小猪/木鸟多平台酒店比价
- **Mapping** - 高德地图地理编码/路线规划/周边搜索
- **Planning Engine** - 基于模式（A/B/C/D）优化行程，预算分配，超支检测
- **Excel Output** - 7个Sheet完整方案：总览/每日行程/景点/住宿比价/交通比价/费用明细
- **Word Document** - 完整旅游手册：封面/目录/每日行程/景点/美食/住宿/交通/费用/注意事项

## 比价分析

- 交通比价：火车（12306）x 飞机（携程/去哪儿）
- 住宿比价：携程 x 去哪儿 x 美团 x 小猪 x 木鸟民宿
- 费用总表：预算 vs 预估，实际超支检测

---

## 快速开始

### 1. 安装依赖
```bash
pip install -r requirements.txt
```

### 2. 运行
```bash
python main.py "去兰州玩7天，2个人，预算8000元"
```

### 3. 可选参数
```
--from FROM      出发站（默认北京 BPM/北京站）
--checkin DATE   入住日期 YYYY-MM-DD
--no-word        不输出Word文档
--output DIR     输出目录
--no-api-check   跳过 API 配置检查（不推荐）
```

---

## API 配置说明（重要）

**首次使用强烈建议配置 API Key**，否则部分功能将使用内置兜底数据，无法获取真实景点/酒店/交通信息。

运行程序后会自动检测 API 配置状态，未配置时会显示详细提示。

### 需要配置的 API

#### 1. GLM 智谱大模型 API（推荐，核心功能）

**作用**：智能提取景点和美食推荐，是 scraper 模块的核心依赖。

**获取步骤**：
1. 访问 **https://open.bigmodel.cn/**
2. 注册并登录（支持微信/手机号）
3. 进入「控制台」→「API Keys」→「创建 API Key」
4. 复制生成的 Key（格式：`sk-xxxxxxxx`）
5. 填入 `config.yaml` 中的 `glm_api_key` 字段

**免费额度**：GLM-4-Flash 每月有免费 token，个人旅行规划完全够用。详见：https://open.bigmodel.cn/pricing

**配置示例**：
```yaml
glm_api_key: "sk-a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6"
```

---

#### 2. 高德地图 Web API（可选，增强功能）

**作用**：地理编码（地址→经纬度）、路线规划、周边搜索。

**获取步骤**：
1. 访问 **https://lbs.amap.com/**
2. 注册并登录开发者账号
3. 进入「控制台」→「应用管理」→「创建应用」
4. 添加 Key，选择服务类型：**Web服务**
5. 复制生成的 Key，填入 `config.yaml` 中的 `amap_api_key` 字段

**免费额度**：每日有免费调用次数，个人使用足够。详见：https://lbs.amap.com/api/webservice/guide/api/newpoi

**配置示例**：
```yaml
amap_api_key: "1234567890abcdef1234567890abcdef"
```

---

#### 3. 浏览器自动化（无需配置，自动连接）

**作用**：通过 CDP 连接 AutoClaw Edge 浏览器，抓取小红书/抖音/12306/携程/去哪儿等平台真实数据。

**前置条件**：
1. 已安装 `autoglm-browser-agent` skill
2. AutoClaw Edge 浏览器已启动并开启 CDP 连接（默认端口 18800）
3. 无需手动配置 Key，browser_connector.py 会自动连接

---

### 配置文件

复制 `config.yaml.example` 为 `config.yaml`，填入 API Key：

```bash
cp config.yaml.example config.yaml
```

编辑 `config.yaml`：
```yaml
glm_api_key: "sk-your-key-here"
amap_api_key: "your-amap-key-here"
```

---

## 数据策略（3层降级）

当某一层数据获取失败时，自动降级到下一层：
1. **浏览器自动化**（autoglm-browser-agent）→ 真实平台数据
2. **API请求**（GLM/高德）→ 智能数据
3. **本地兜底** → 兰州本地真实数据，保证总有输出

---

## 旅行模式

| 模式 | 名称 | 日均预算/人 | 酒店标准 | 交通方式 |
|------|------|------------|----------|----------|
| A | 精选推荐 | 800元 | 四星 | 高铁/飞机 |
| B | 经济实惠 | 400元 | 三星 | 火车/大巴 |
| C | 尊享豪华 | 2000元 | 五星 | 飞机/专车 |
| D | 穷游背包 | 200元 | 青旅 | 火车/搭车 |

---

## 注意事项

- 12306 仅支持查询，不支持购票
- 小红书/抖音 需安装 `autoglm-browser-agent` skill 才有真实数据
- 预算模式：A=精选(800元/天) B=省钱(400元/天) C=豪华(2000元/天) D=穷游(200元/天)
- 未配置 API Key 时，程序会显示详细配置提示，按说明配置后重新运行即可
