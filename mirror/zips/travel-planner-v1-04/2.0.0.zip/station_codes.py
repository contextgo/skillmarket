﻿# station_codes.py - 12306 站点电报码映射
STATION_CODES = {
    # 直辖市
    "北京": "BJP", "北京南": "VNP", "北京西": "BXP",
    "上海": "SHH", "上海虹桥": "AOH", "上海南": "SNH",
    "天津": "TJP", "天津西": "TXP",
    "重庆": "CQW", "重庆北": "CUW",
    # 省会
    "广州": "GZQ", "深圳": "SZQ", "成都": "CDW", "成都东": "ICW",
    "杭州": "HZH", "杭州东": "HGH", "南京": "NJH", "南京南": "NKH",
    "武汉": "WHN", "长沙": "CSQ", "长沙南": "CWQ",
    "西安": "XAY", "郑州": "ZZF", "济南": "JNK", "青岛": "QDK",
    "昆明": "KMM", "贵阳": "GIW", "福州": "FZS", "厦门": "XMS",
    "哈尔滨": "HBB", "长春": "CCT", "沈阳": "SYT", "大连": "DFT",
    "太原": "TYV", "石家庄": "SJP", "合肥": "HFH", "南昌": "NCG",
    "南宁": "NNZ", "海口": "HKQ", "兰州": "LZJ", "兰州西": "LAJ",
    "西宁": "XNO", "银川": "YJW", "呼和浩特": "HHC", "乌鲁木齐": "WMR",
    "拉萨": "LSO",
    # 热门旅游城市
    "苏州": "SZH", "无锡": "WXH", "宁波": "NGH", "温州": "WZH",
    "大理": "DLF", "丽江": "LJX", "桂林": "GLZ", "三亚": "SYQ",
    "秦皇岛": "ODP", "承德": "CDP", "洛阳": "LYF", "敦煌": "DHR",
    "黄山": "HKH", "张家界": "ZOQ", "九寨沟": "JIW", "峨眉山": "EMW",
    "秦皇岛": "ODP", "珠海": "ZUQ", "惠州": "HUQ",
}

def get_station_code(city_name):
    """获取站点代码，支持模糊匹配"""
    if city_name in STATION_CODES:
        return STATION_CODES[city_name]
    # 模糊匹配
    for name, code in STATION_CODES.items():
        if city_name in name or name in city_name:
            return code
    return None
