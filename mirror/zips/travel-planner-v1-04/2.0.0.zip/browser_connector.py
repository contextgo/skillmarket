﻿"""
browser_connector.py
=====================
CDP Browser Connector - connect to AutoClaw Edge via CDP
"""

import threading
from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout

CDP_URL = "http://127.0.0.1:18800"


class BrowserConnector:
    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super().__new__(cls)
                cls._instance._pw = None
                cls._instance._browser = None
                cls._instance._context = None
            return cls._instance

    @property
    def connected(self):
        return self._browser is not None and self._browser.is_connected()

    def connect(self):
        if self.connected:
            return
        try:
            self._pw = sync_playwright().start()
            self._browser = self._pw.chromium.connect_over_cdp(CDP_URL)
            contexts = self._browser.contexts
            if contexts:
                self._context = contexts[0]
            else:
                self._context = self._browser.new_context(
                    viewport={"width": 1280, "height": 800},
                    user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0",
                )
            print("[Browser] CDP connected: " + CDP_URL)
        except Exception as e:
            print("[Browser] CDP connect failed: " + str(e))

    def new_page(self, url=None, wait_seconds=3):
        if not self.connected:
            self.connect()
        if not self.connected:
            return None
        page = self._context.new_page()
        if url:
            try:
                page.goto(url, timeout=30000, wait_until="domcontentloaded")
                page.wait_for_timeout(wait_seconds * 1000)
            except PWTimeout:
                print("[Browser] Timeout: " + url)
            except Exception as e:
                print("[Browser] Error: " + str(e))
        return page

    def close_page(self, page):
        try:
            if page:
                page.close()
        except Exception:
            pass

    def close(self):
        try:
            if self._pw:
                self._pw.stop()
        except Exception:
            pass
        self._pw = None
        self._browser = None
        self._context = None

    def fetch_page_html(self, url, wait_seconds=3, selector_wait=None):
        page = self.new_page(url, wait_seconds=wait_seconds)
        if not page:
            return ""
        try:
            if selector_wait:
                page.wait_for_selector(selector_wait, timeout=15000)
                page.wait_for_timeout(1000)
            return page.content()
        except Exception as e:
            return page.content() if page else ""
        finally:
            self.close_page(page)


_browser = None

def get_browser():
    global _browser
    if _browser is None:
        _browser = BrowserConnector()
        _browser.connect()
    return _browser