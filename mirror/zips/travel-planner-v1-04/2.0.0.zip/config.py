"""config.py - 内置默认配置（优先读取 config.yaml）"""
import os, yaml

class Config:
    def __init__(self, config_path=None):
        if config_path is None:
            config_path = os.path.join(os.path.dirname(__file__), "config.yaml")
        self.config_path = config_path
        self._cfg = {}
        if os.path.exists(config_path):
            try:
                with open(config_path, "r", encoding="utf-8") as f:
                    self._cfg = yaml.safe_load(f) or {}
            except Exception:
                pass

    def get(self, key, default=None):
        keys = key.split(".")
        val = self._cfg
        for k in keys:
            if isinstance(val, dict):
                val = val.get(k)
            else:
                return default
            if val is None:
                return default
        return val

    @property
    def glm_api_key(self):
        return self.get("glm_api_key", "")

    @property
    def amap_api_key(self):
        return self.get("amap_api_key", "")

    @property
    def is_configured(self):
        return bool(self.glm_api_key and self.glm_api_key != "YOUR_GLM_API_KEY")

    def to_dict(self):
        return self._cfg
