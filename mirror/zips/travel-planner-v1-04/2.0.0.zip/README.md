# AutoClaw Travel Planning System

This is an AI-powered travel planning system that scrapes data from multiple platforms, integrates transportation and accommodation APIs, and generates optimized trip plans with Excel output.

## Modules

- **Intent Understanding**: Parses user input for destination, days, people, budget, and mode.
- **Data Scraping**: Scrapes travel guides from Xiaohongshu, Douyin, etc.
- **Transportation**: Integrates train and flight APIs from 12306, Ctrip, etc.
- **Accommodation**: Aggregates hotel data from multiple platforms.
- **Mapping**: Uses Gaode API for routes and maps.
- **Planning Engine**: Optimizes itinerary based on mode (A/B/C/D).
- **Excel Output**: Generates detailed trip plan in Excel format.
- **Publishing**: Publishes as an agent on Qingliu platform.

## Installation

pip install -r requirements.txt

## Usage

python main.py

## Note

This is a basic implementation. Actual APIs require keys and may have restrictions.