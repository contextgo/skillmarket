"""
config_checker.py
=================
API 配置检查器 - 在运行前检查各 API 的配置状态，
未配置时提供详细的配置说明和指引。
"""

import os


# ============================================================
#  API 配置说明（供检查器和提示语使用）
# ============================================================

API_DOCS = {
    "glm": {
        "name": "GLM 智谱大模型 API",
        "key_name": "glm_api_key",
        "description": "用于智能提取景点和美食推荐，是 scraper 模块的核心依赖。",
        "how_to_get": {
            "title": "如何获取 GLM API Key：",
            "steps": [
                "1. 访问智谱 AI 开放平台：https://open.bigmodel.cn/",
                "2. 注册并登录账号（支持微信/手机号注册）",
                "3. 进入「控制台」→「API Keys」→「创建 API Key」",
                "4. 复制生成的 API Key（格式：sk-xxxxxxxx）",
                "5. 将 API Key 填入 config.yaml 中的 glm_api_key 字段",
            ],
            "note": "智谱提供免费试用额度（GLM-4-Flash 每月有免费 token），完全足够个人旅行规划使用。",
            "free_tier": "https://open.bigmodel.cn/pricing",
        },
        "status_meaning": {
            "configured": "已配置 ✓  —— 将使用 GLM-4-Flash 智能提取景点和美食推荐",
            "not_configed": "未配置 ✗  —— 将跳过 GLM 智能推荐，仅使用本地兜底数据",
        },
    },
    "amap": {
        "name": "高德地图 Web API",
        "key_name": "amap_api_key",
        "description": "用于地理编码（地址→经纬度）、路线规划和周边搜索。",
        "how_to_get": {
            "title": "如何获取高德地图 API Key：",
            "steps": [
                "1. 访问高德开放平台：https://lbs.amap.com/",
                "2. 注册并登录开发者账号",
                "3. 进入「控制台」→「应用管理」→「创建应用」",
                "4. 添加 Key，选择服务类型：Web端（JS API） 或 Web服务",
                "5. 复制生成的 Key，填入 config.yaml 中的 amap_api_key 字段",
            ],
            "note": "高德地图 API 有免费调用额度（地理编码/路线规划每日有限免费次数），个人使用足够。",
            "free_tier": "https://lbs.amap.com/api/webservice/guide/api/newpoi",
        },
        "status_meaning": {
            "configured": "已配置 ✓  —— 将使用高德 API 进行地理编码和路线规划",
            "not_configed": "未配置 ✗  —— 将使用浏览器版高德地图兜底（功能受限）",
        },
    },
    "browser": {
        "name": "AutoClaw 浏览器连接",
        "key_name": "无（通过 browser_connector.py 自动连接）",
        "description": "通过 CDP 协议连接 AutoClaw Edge 浏览器，抓取小红书/抖音/携程/去哪儿/12306 等平台的真实数据。",
        "how_to_get": {
            "title": "如何启用浏览器自动化：",
            "steps": [
                "1. 确保已安装 autoglm-browser-agent skill",
                "2. 确保 AutoClaw Edge 浏览器已启动并开启 CDP 连接（默认端口 18800）",
                "3. 在 OpenClaw 配置中启用 browser 功能",
                "4. 运行时确保浏览器标签页已打开目标网站",
            ],
            "note": "无需手动配置 Key，browser_connector.py 会自动连接本地 AutoClaw Edge。",
        },
        "status_meaning": {
            "configured": "已连接 ✓  —— 将通过浏览器自动化抓取小红书/抖音/12306/携程等真实数据",
            "not_configed": "未连接 ✗  —— 将跳过浏览器自动化，仅使用 API 和本地数据",
        },
    },
}


class ConfigChecker:
    """API 配置检查器"""

    def __init__(self, config):
        self.config = config

    def check_all(self):
        """
        检查所有 API 配置状态
        返回：{
            "glm": {"configured": bool, "key": str},
            "amap": {"configured": bool, "key": str},
            "browser": {"configured": bool},
        }
        """
        glm_key = getattr(self.config, "glm_api_key", "") or ""
        amap_key = getattr(self.config, "amap_api_key", "") or ""

        # 检查 browser 是否可用
        browser_ok = False
        try:
            from browser_connector import get_browser
            browser = get_browser()
            browser_ok = browser is not None and browser.connected
        except Exception:
            pass

        return {
            "glm": {
                "configured": bool(glm_key and glm_key != "YOUR_GLM_API_KEY"),
                "key": glm_key[:6] + "****" if glm_key else "",
            },
            "amap": {
                "configured": bool(amap_key and amap_key != "YOUR_AMAP_KEY"),
                "key": amap_key[:6] + "****" if amap_key else "",
            },
            "browser": {
                "configured": browser_ok,
            },
        }

    def get_unconfigured(self):
        """返回未配置的 API 列表"""
        status = self.check_all()
        unconfigured = []
        for api_name, info in status.items():
            if not info["configured"]:
                unconfigured.append(api_name)
        return unconfigured

    def get_missing_apis(self):
        """返回缺失 API 的详细信息（用于生成提示）"""
        status = self.check_all()
        missing = []
        for api_name, info in status.items():
            if not info["configured"]:
                doc = API_DOCS.get(api_name, {})
                missing.append({
                    "name": doc.get("name", api_name),
                    "key_name": doc.get("key_name", ""),
                    "description": doc.get("description", ""),
                    "how_to_get": doc.get("how_to_get", {}),
                    "status_meaning": doc.get("status_meaning", {}).get("not_configed", ""),
                })
        return missing

    def print_banner(self):
        """打印醒目的 API 配置状态横幅"""
        status = self.check_all()
        unconfigured = self.get_unconfigured()

        print()
        print("=" * 60)
        print("  [API 配置检查]  Travel Planner v2.0")
        print("=" * 60)

        for api_name, info in status.items():
            doc = API_DOCS.get(api_name, {})
            label = doc.get("name", api_name)
            meaning = (
                doc.get("status_meaning", {}).get("configured", "已配置")
                if info["configured"]
                else doc.get("status_meaning", {}).get("not_configed", "未配置")
            )
            key_hint = ""
            if api_name in ("glm", "amap") and not info["configured"]:
                key_hint = f"（当前: {info['key'] or '空'}）"

            status_icon = "✅" if info["configured"] else "⚠️ "
            print(f"  {status_icon} {label}: {meaning} {key_hint}")

        print("-" * 60)

        if unconfigured:
            print(f"  ⚠️  有 {len(unconfigured)} 个 API 未配置，部分功能将使用兜底数据")
        else:
            print("  ✅ 所有 API 均已配置，功能完整可用")

        print("=" * 60)
        print()

        return unconfigured

    def print_missing_detail(self):
        """打印未配置 API 的详细配置说明"""
        missing = self.get_missing_apis()
        if not missing:
            return

        print()
        print("=" * 60)
        print("  📋 API 配置详细说明")
        print("=" * 60)

        for i, api in enumerate(missing, 1):
            print()
            print(f"  【{i}. {api['name']}】")
            print(f"      配置字段: {api['key_name']}")
            print(f"      功能说明: {api['description']}")
            print()

            how_to = api["how_to_get"]
            print(f"      {how_to.get('title', '')}")
            for step in how_to.get("steps", []):
                print(f"        {step}")
            if how_to.get("note"):
                print(f"      💡 注意: {how_to.get('note', '')}")
            if how_to.get("free_tier"):
                print(f"      🔗 免费额度: {how_to.get('free_tier', '')}")

        print()
        print("-" * 60)
        print("  📁 配置文件位置: config.yaml（与 main.py 同目录）")
        print("  📝 配置示例文件: config.yaml.example")
        print()
        print("  ⚡ 快速配置方法：")
        print("    1. 复制 config.yaml.example 为 config.yaml")
        print("    2. 填入你的 API Key")
        print("    3. 重新运行即可")
        print("=" * 60)
        print()

    def should_continue(self):
        """
        询问用户是否在未配置 API 的情况下继续
        返回 True 表示继续执行，False 表示退出
        """
        unconfigured = self.get_unconfigured()
        if not unconfigured:
            return True

        self.print_missing_detail()

        print()
        print("  ⚠️  未配置 API 的模块将使用内置兜底数据，功能受限：")
        missing = self.get_missing_apis()
        for api in missing:
            print(f"     - {api['name']}: {api['description']}")

        print()
        while True:
            try:
                choice = input("  是否继续运行？（输入 y 继续，n 退出）: ").strip().lower()
                if choice in ("y", "yes", "是", ""):
                    return True
                elif choice in ("n", "no", "否"):
                    return False
                else:
                    print("  请输入 y 或 n")
            except EOFError:
                # 非交互环境（程序化调用），默认继续
                print("  [自动模式] 检测到非交互环境，默认继续运行...")
                return True

    def get_config_report(self):
        """
        获取完整的配置报告（用于日志/返回）
        """
        status = self.check_all()
        unconfigured = self.get_unconfigured()
        missing = self.get_missing_apis()

        report_lines = []
        report_lines.append("=" * 60)
        report_lines.append("  [API 配置报告] Travel Planner v2.0")
        report_lines.append("=" * 60)

        for api_name, info in status.items():
            doc = API_DOCS.get(api_name, {})
            label = doc.get("name", api_name)
            meaning = (
                doc.get("status_meaning", {}).get("configured", "已配置")
                if info["configured"]
                else doc.get("status_meaning", {}).get("not_configed", "未配置")
            )
            key_hint = ""
            if api_name in ("glm", "amap") and info["configured"]:
                key_hint = f"（{info['key']}）"

            status_icon = "✅" if info["configured"] else "⚠️ "
            report_lines.append(f"  {status_icon} {label}: {meaning} {key_hint}")

        report_lines.append("-" * 60)

        if unconfigured:
            report_lines.append(f"  ⚠️  未配置 API: {', '.join([API_DOCS.get(u, {}).get('name', u) for u in unconfigured])}")
            report_lines.append(f"     将使用兜底数据继续运行，功能可能受限")
        else:
            report_lines.append("  ✅ 所有 API 均已配置，功能完整可用")

        report_lines.append("=" * 60)

        if missing:
            report_lines.append("")
            report_lines.append("  📋 未配置 API 详情：")
            for i, api in enumerate(missing, 1):
                report_lines.append(f"    {i}. {api['name']}")
                report_lines.append(f"       字段: {api['key_name']}")
                report_lines.append(f"       说明: {api['description']}")
                how_to = api["how_to_get"]
                for step in how_to.get("steps", []):
                    report_lines.append(f"       {step}")
                if how_to.get("note"):
                    report_lines.append(f"       💡 {how_to.get('note', '')}")

        report_lines.append("")
        report_lines.append("  📁 配置文件: config.yaml")
        report_lines.append("  📝 配置模板: config.yaml.example")
        report_lines.append("=" * 60)

        return "\n".join(report_lines)


def check_and_warn(config):
    """
    快捷函数：检查配置，未配置时打印警告
    返回 (unconfigured_list, should_proceed)
    """
    checker = ConfigChecker(config)
    unconfigured = checker.print_banner()

    if unconfigured:
        checker.print_missing_detail()

    return unconfigured, True  # 默认继续，除非用户主动退出
