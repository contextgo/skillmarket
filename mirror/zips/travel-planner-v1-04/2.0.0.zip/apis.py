﻿"""
accommodation/apis.py - 真实数据抓取版
通过 CDP 浏览器自动化绕过反爬，多平台酒店比价
"""

import os, sys, re, json
from bs4 import BeautifulSoup

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from browser_connector import get_browser
except ImportError:
    get_browser = None


class AccommodationAPI:
    def __init__(self, config=None):
        self.config = config

    def search_all(self, city, checkin, checkout, person=2, price_range=None):
        print(f"[Hotel] Searching: {city} {checkin} -> {checkout} ({person}p)")
        all_hotels = []

        # 携程
        ctrip = self._search_ctrip_browser(city, checkin, checkout)
        all_hotels.extend(ctrip)

        # 去哪儿
        qunar = self._search_qunar_browser(city, checkin, checkout)
        all_hotels.extend(qunar)

        # 去重
        seen = set()
        unique = []
        for h in all_hotels:
            key = h["name"] + h["platform"]
            if key not in seen:
                seen.add(key)
                unique.append(h)

        if price_range:
            min_p, max_p = price_range
            unique = [h for h in unique if min_p <= h.get("price", 0) <= max_p]

        sorted_hotels = sorted(unique, key=lambda x: x.get("price", 99999))
        print(f"  -> Got {len(sorted_hotels)} hotels")
        return sorted_hotels

    def _search_ctrip_browser(self, city, checkin, checkout):
        """携程酒店浏览器搜索"""
        if not get_browser:
            return []
        browser = get_browser()
        page = browser.new_page()
        if not page:
            return []
        try:
            url = f"https://hotels.ctrip.com/hotels/list?countryId=1&city={self._city_to_ctrip_id(city)}&checkin={checkin}&checkout={checkout}"
            print(f"[携程酒店] Opening: {url}")
            page.goto(url, timeout=25000, wait_until="domcontentloaded")
            page.wait_for_timeout(5000)

            try:
                page.wait_for_selector("[class*='hotel'], [class*='hotel_item'], .hotel-item", timeout=10000)
                page.wait_for_timeout(2000)
            except Exception:
                pass

            results = page.evaluate("""() => {
                const hotels = [];
                const text = document.body.innerText;
                // 尝试从结构化数据提取
                const items = document.querySelectorAll(
                    '[class*="hotel-name"], [class*="hotel_name"], h2, h3, h4'
                );
                if (items.length > 0) {
                    const seen = new Set();
                    items.forEach(el => {
                        const name = el.textContent.trim();
                        if (name.length > 2 && name.length < 50 && !seen.has(name)) {
                            seen.add(name);
                            const parent = el.closest('[class*="hotel"]') || el.parentElement?.parentElement || el.parentElement;
                            const parentText = parent ? parent.innerText : '';
                            const priceMatch = parentText.match(/[¥￥](\\d+)/);
                            const scoreMatch = parentText.match(/(\\d\\.\\d)分/);
                            const starMatch = parentText.match(/(\\d)星/);
                            hotels.push({
                                platform: '携程',
                                name: name,
                                star: starMatch ? starMatch[1] + '星' : '',
                                score: scoreMatch ? parseFloat(scoreMatch[1]) : 0,
                                price: priceMatch ? parseFloat(priceMatch[1]) : 0,
                                address: '',
                                amenities: [],
                            });
                        }
                    });
                }
                // 备选：正则提取
                if (hotels.length === 0) {
                    const lines = text.split('\\n');
                    for (const line of lines) {
                        const priceMatch = line.match(/[¥￥](\\d+)/);
                        const scoreMatch = line.match(/(\\d\\.\\d)分/);
                        if (priceMatch) {
                            const name = line.replace(/[¥￥]\\d+.*$/, '').replace(/\\d\\.\\d分.*$/, '').trim();
                            if (name.length > 2 && name.length < 50) {
                                hotels.push({
                                    platform: '携程',
                                    name: name.substring(0, 30),
                                    star: '',
                                    score: scoreMatch ? parseFloat(scoreMatch[1]) : 0,
                                    price: parseFloat(priceMatch[1]),
                                    address: '',
                                    amenities: [],
                                });
                            }
                        }
                    }
                }
                return hotels.slice(0, 20);
            }""")

            return results or []

        except Exception as e:
            print(f"[携程酒店] Error: {e}")
            return []
        finally:
            browser.close_page(page)

    def _search_qunar_browser(self, city, checkin, checkout):
        """去哪儿酒店浏览器搜索"""
        if not get_browser:
            return []
        browser = get_browser()
        page = browser.new_page()
        if not page:
            return []
        try:
            url = f"https://hotel.qunar.com/city/{city}/?checkin={checkin}&checkout={checkout}"
            print(f"[去哪儿酒店] Opening: {url}")
            page.goto(url, timeout=25000, wait_until="domcontentloaded")
            page.wait_for_timeout(5000)

            results = page.evaluate("""() => {
                const hotels = [];
                const text = document.body.innerText;
                const lines = text.split('\\n');
                for (const line of lines) {
                    const priceMatch = line.match(/[¥￥](\\d+)/);
                    const scoreMatch = line.match(/(\\d\\.\\d)分/);
                    if (priceMatch) {
                        const name = line.replace(/[¥￥]\\d+.*$/, '').replace(/\\d\\.\\d分.*$/, '').trim();
                        if (name.length > 2 && name.length < 50) {
                            hotels.push({
                                platform: '去哪儿',
                                name: name.substring(0, 30),
                                star: '',
                                score: scoreMatch ? parseFloat(scoreMatch[1]) : 0,
                                price: parseFloat(priceMatch[1]),
                                address: '',
                                amenities: [],
                            });
                        }
                    }
                }
                return hotels.slice(0, 20);
            }""")

            return results or []

        except Exception as e:
            print(f"[去哪儿酒店] Error: {e}")
            return []
        finally:
            browser.close_page(page)

    def compare_prices(self, hotels_list):
        if not hotels_list:
            return {"cheapest": None, "best_value": None, "top_rated": None, "summary": "未查询到住宿数据"}
        by_platform = {}
        for h in hotels_list:
            p = h["platform"]
            if p not in by_platform:
                by_platform[p] = []
            by_platform[p].append(h)
        avg_prices = {p: sum(x["price"] for x in items) / len(items) for p, items in by_platform.items()}
        cheapest_platform = min(avg_prices, key=avg_prices.get) if avg_prices else "未知"
        with_score = [h for h in hotels_list if h.get("score", 0) > 0]
        best_value = min(with_score, key=lambda x: x["price"] / max(x["score"], 1)) if with_score else hotels_list[0]
        top_rated = max(with_score, key=lambda x: x["score"]) if with_score else None
        return {
            "cheapest": min(hotels_list, key=lambda x: x["price"]),
            "best_value": best_value,
            "top_rated": top_rated,
            "platform_summary": {p: {"count": len(items), "avg_price": avg_prices[p]} for p, items in by_platform.items()},
            "cheapest_platform": cheapest_platform,
            "recommendation": self._make_recommendation(best_value, top_rated, cheapest_platform),
        }

    def _make_recommendation(self, best_value, top_rated, cheapest_platform):
        recs = []
        if best_value:
            recs.append(f"性价比之选: {best_value['name']} ({best_value['platform']}, ¥{best_value['price']}/晚)")
        if top_rated:
            recs.append(f"评分最高: {top_rated['name']} (评分{top_rated['score']})")
        if cheapest_platform:
            recs.append(f"最实惠平台: {cheapest_platform}")
        return "; ".join(recs) if recs else "数据不足，请手动比价"

    def _city_to_ctrip_id(self, city):
        cid_map = {
            "兰州": 58, "北京": 1, "上海": 2, "广州": 5, "深圳": 6,
            "成都": 7, "重庆": 15, "西安": 10, "杭州": 17, "南京": 12,
            "昆明": 34, "厦门": 38, "青岛": 39, "乌鲁木齐": 62,
            "三亚": 140, "大连": 3, "哈尔滨": 42, "长沙": 32,
        }
        return cid_map.get(city, 58)
