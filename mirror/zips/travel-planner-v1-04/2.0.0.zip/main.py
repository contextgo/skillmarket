"""AutoClaw Travel Planner - main.py (CDP Browser Edition)"""
import os, sys

_SKILL_DIR = os.path.dirname(os.path.abspath(__file__))
if _SKILL_DIR not in sys.path:
    sys.path.insert(0, _SKILL_DIR)

from intent_understanding.parser import IntentParser
from data_scraping.scraper import AutoClawScraper
from transportation.apis import TransportationAPI
from accommodation.apis import AccommodationAPI
from mapping.api import MappingAPI
from planning_engine.engine import PlanningEngine
from excel_output.generator import ExcelGenerator
from word_output.generator import WordGenerator

try:
    from config import Config
except ImportError:
    Config = None

try:
    from config_checker import ConfigChecker
except ImportError:
    ConfigChecker = None


class AutoClaw:
    def __init__(self, config=None):
        self.config = config or (Config() if Config else None)
        self.parser = IntentParser(self.config)
        self.scraper = AutoClawScraper(self.config)
        self.transport = TransportationAPI(self.config)
        self.accommodation = AccommodationAPI(self.config)
        self.mapping = MappingAPI(config=self.config)
        self.engine = PlanningEngine(self.config)
        self.excel_gen = ExcelGenerator()
        self.word_gen = WordGenerator()

    def plan_trip(self, user_input,
                  from_station=None, checkin_date=None,
                  output_excel=True, output_word=True, output_dir=None,
                  check_api=True):
        """
        规划旅行行程

        Args:
            user_input: 用户输入，如 "去兰州玩7天，2个人，预算8000元"
            from_station: 出发站（如 "北京"、"BJP"）
            checkin_date: 入住日期（YYYY-MM-DD）
            output_excel: 是否输出 Excel
            output_word: 是否输出 Word 文档
            output_dir: 输出目录
            check_api: 是否在运行前检查 API 配置（默认 True）
        """
        print("=" * 60)
        print("[AutoClaw] Starting trip planning...")
        print("[AutoClaw] Input: " + user_input)
        print("=" * 60)

        # ── API 配置检查 ──────────────────────────────
        if check_api and ConfigChecker:
            checker = ConfigChecker(self.config)
            unconfigured = checker.print_banner()

            if unconfigured:
                checker.print_missing_detail()

                # 检查是否有非交互环境标志
                non_interactive = (
                    not sys.stdin.isatty()
                    or os.environ.get("TRAVEL_PLANNER_NONINTERACTIVE", "") == "1"
                )

                if non_interactive:
                    print("  [自动模式] 非交互环境，默认继续运行...")
                else:
                    print()
                    print("  ⚠️  提示：未配置 API 的模块将使用内置兜底数据继续运行。")
                    print("  💡 建议：按上方说明配置 API Key 以获得完整功能和真实数据。")
                    print()
                    while True:
                        try:
                            choice = input("  是否继续运行？（直接回车继续，Ctrl+C 退出）: ").strip().lower()
                            if choice in ("", "y", "yes", "是"):
                                break
                            elif choice in ("n", "no", "否", "q", "quit", "exit"):
                                print("  已退出。配置好 API Key 后再运行即可。")
                                return None
                            else:
                                print("  请直接回车继续，或 Ctrl+C 退出")
                        except (EOFError, KeyboardInterrupt):
                            print("\n  已退出。")
                            return None

        # ── 解析用户意图 ────────────────────────────
        intent = self.parser.parse(user_input)
        print("[1/6] Intent parsed: " + str(intent))

        # ── 抓取景点和美食 ──────────────────────────
        print("[2/6] Scraping data for " + intent["destination"] + "...")
        attractions = self._scrape_attractions(intent)
        food_data = self._scrape_food(intent)
        print("  -> Attractions: " + str(len(attractions)) + ", Food: " + str(len(food_data)))

        # ── 查询交通 ────────────────────────────────
        from_st = from_station or "BJP"
        checkin = checkin_date or self._default_date(7)
        print("[3/6] Querying transport: " + from_st + " -> " + intent["destination"])
        transport_data = self.transport.compare_all(from_st, intent["destination"], checkin)
        print("  -> Trains: " + str(len(transport_data.get("trains", []))) + ", Flights: " + str(len(transport_data.get("flights", []))))

        # ── 查询住宿 ───────────────────────────────
        nights = intent.get("nights", intent["days"] - 1)
        checkout = self._default_date(7 + nights)
        print("[4/6] Querying hotels...")
        hotel_data = self.accommodation.search_all(intent["destination"], checkin, checkout, intent["people"])
        hotel_summary = self.accommodation.compare_prices(hotel_data)
        print("  -> Hotels: " + str(len(hotel_data)))

        # ── 生成行程 ────────────────────────────────
        print("[5/6] Generating itinerary...")
        budget = intent.get("budget") or 5000
        plan_data = self.engine.optimize_itinerary(
            attractions=attractions, days=intent["days"],
            total_budget=budget, mode=intent["mode"],
            food_data=food_data, transport_data=transport_data,
            hotel_data=hotel_data,
        )
        print("  -> Generated " + str(intent["days"]) + " days")

        # ── 输出文件 ───────────────────────────────
        print("[6/6] Generating output files...")
        out_dir = output_dir or os.path.join(_SKILL_DIR, "output")
        os.makedirs(out_dir, exist_ok=True)

        if output_excel:
            path = os.path.join(out_dir, "travel_plan.xlsx")
            self.excel_gen.create_overview(intent, plan_data, food_data, transport_data, hotel_summary)
            self.excel_gen.create_daily_itinerary(intent, plan_data)
            self.excel_gen.create_attractions_sheet(attractions)
            self.excel_gen.create_hotel_comparison(hotel_data, hotel_summary, nights)
            self.excel_gen.create_transport_comparison(transport_data)
            self.excel_gen.create_cost_summary(intent, plan_data, hotel_summary)
            self.excel_gen.save(path)
            print("[Excel] Saved: " + path)

        if output_word:
            path = os.path.join(out_dir, "travel_plan.docx")
            self.word_gen.generate(
                intent=intent, plan_data=plan_data,
                attractions_data=attractions, food_data=food_data,
                hotel_data=hotel_data, hotel_summary=hotel_summary,
                transport_data=transport_data, output_path=path,
            )
            print("[Word] Saved: " + path)

        # ── 最终 API 配置报告 ───────────────────────
        if check_api and ConfigChecker:
            print()
            print("=" * 60)
            print("  📊 API 配置状态报告")
            print("=" * 60)
            checker = ConfigChecker(self.config)
            print(checker.get_config_report())

        print()
        print("=" * 60)
        print("[AutoClaw] Done! Output in: " + out_dir)
        print("=" * 60)
        return {"intent": intent, "plan": plan_data, "excel": output_excel, "word": output_word}

    def _scrape_attractions(self, intent):
        dest = intent["destination"]
        xhs = self.scraper.scrape_xiaohongshu(dest + "旅游攻略")
        if xhs and len(xhs) >= 3:
            return xhs
        glm = self.scraper.extract_glm(dest, intent["days"], intent.get("budget", 0), intent["mode"])
        if glm and glm.get("attractions"):
            return glm["attractions"]
        return xhs if xhs else []

    def _scrape_food(self, intent):
        glm = self.scraper.extract_glm(intent["destination"], intent["days"],
                                       intent.get("budget", 0), intent["mode"])
        food = glm.get("food", []) if glm else []
        if food:
            return food
        return [
            {"name": "马子禄牛肉面", "address": "城关区大众巷", "price_range": "15-25元"},
            {"name": "正宁路夜市", "address": "城关区正宁路", "price_range": "30-60元"},
            {"name": "鸡蛋醪糟", "address": "正宁路夜市", "price_range": "8-15元"},
        ]

    def _default_date(self, days_from_now=0):
        from datetime import datetime, timedelta
        d = datetime.now() + timedelta(days=days_from_now)
        return d.strftime("%Y-%m-%d")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="AutoClaw Travel Planner - AI 智能旅行规划")
    parser.add_argument("input", nargs="?", default="去兰州玩7天，2个人，预算8000元",
                        help="旅行描述，如：去兰州玩7天，2个人，预算8000元")
    parser.add_argument("--from", dest="from_station",
                        help="出发站（默认北京 BPM/北京站）")
    parser.add_argument("--checkin", dest="checkin",
                        help="入住日期（YYYY-MM-DD 格式）")
    parser.add_argument("--no-word", dest="no_word", action="store_true",
                        help="不输出 Word 文档")
    parser.add_argument("--output", dest="output",
                        help="输出目录")
    parser.add_argument("--no-api-check", dest="no_api_check", action="store_true",
                        help="跳过 API 配置检查（不推荐）")
    args = parser.parse_args()

    config = Config() if Config else None

    # 打印欢迎和配置状态
    print()
    print("=" * 60)
    print("  🚀 AutoClaw Travel Planner v2.0")
    print("  AI 智能旅行规划系统")
    print("=" * 60)

    autoclaw = AutoClaw(config=config)

    result = autoclaw.plan_trip(
        user_input=args.input,
        from_station=getattr(args, "from_station"),
        checkin_date=args.checkin,
        output_word=not args.no_word,
        output_dir=args.output,
        check_api=not args.no_api_check,
    )

    if result is None:
        sys.exit(0)
