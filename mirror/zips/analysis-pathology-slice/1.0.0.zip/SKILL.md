---
name: analysis-pathology-slice
description: Submit a pathology slice, initiate analysis request, and retrieve the AI diagnosis result via a 6-step API workflow. Use when users need to run pathology slice analysis, including login/auth, COS credential retrieval, file upload, record creation, and result polling.
---

# 病理切片分析

## 概述

执行病理切片分析的六步流程。每一步都会打印一行机器可读的状态信息。

## 状态输出规范

每一步必须打印一行以下格式的状态信息：

`STEP_STATUS|step=<n>|name=<step_name>|status=<success|error|pending>|message=<详情>`

## 工作流程（六步）

1. **登录认证**（已实现）— 需要提供用户名和密码
2. **获取临时 COS 上传凭据**（已实现）
3. **上传 WSI 文件到 COS**（已实现）
4. **创建 WSI 文件记录回调**（已实现）
5. **创建 WSI 记录**（已实现）
6. **获取 AI 诊断结果**（已实现）

## 第一步：登录认证

> **首次使用需要提供用户名和密码**，通过环境变量传入：
> ```bash
> $env:PATHOLOGY_USERNAME = "你的用户名"
> $env:PATHOLOGY_PASSWORD = "你的密码"
> python scripts/step1_login_auth.py
> ```
>
>（环境变量已设置时自动跳过，无需重复输入）

## 第二步：获取 COS 凭据

```bash
python scripts/step2_get_cos_credentials.py [--credentials-url <url>] [--token-file <token_json_path>] [--output-file <credentials_json_path>]
```

## 第三步：上传 WSI 文件到 COS

```bash
python scripts/step3_upload_wsi_to_cos.py [--credentials-file <cos_credentials_json>] [--local-file <wsi_file>] [--organization <org_name>] [--date <YYYYMMDD>]
```

COS 路径格式（严格）：

`SLIDES/chunked_uploads/{YYYYMMDD}/{机构名称}/{文件 MD5}/{文件名}{扩展名}`

## 第四步：创建 WSI 文件记录回调

```bash
python scripts/step4_create_wsi_file_record.py [--callback-url <url>] [--token-file <token_store_json>] [--upload-result-file <cos_upload_result_json>] [--disease <id>]
```

回调 `path` 格式（严格，默认行为）：

`chunked_uploads/{YYYYMMDD}/{机构名称}/{文件 MD5}/{文件名}{扩展名}`

注意：

- 默认自动去除 `SLIDES/` 前缀
- 始终发送不带 `SLIDES/` 前缀的 `path`

## 第五步：创建 WSI 记录

```bash
python scripts/step5_create_wsi_record.py [--create-url <url>] [--token-file <token_store_json>] [--upload-result-file <cos_upload_result_json>] [--disease <id>] [--source <org_id>] [--is-run]
```

可选参数：

- `--create-url`（默认：`http://10.5.16.108/api/v1/image/create/`）
- `--token-file`（默认：`scripts/data/token_store.json`）
- `--upload-result-file`（默认：`scripts/data/cos_upload_result.json`）
- `--disease`（必填）
  - `6`：通用组织切片
  - `14`：消化道活检AI
- `--source`（默认：`3696`）
- `--is-run`（默认 true）
- `--no-is-run`（可选，显式设为 false）
- `--output-file`（默认：`scripts/data/wsi_record_result.json`）

第五步请求体字段：

- `filename`：来自第三步上传的文件名
- `total_md5`：来自第三步的 `file_md5`
- `disease`：传入的疾病类型
- `source`：来源机构 ID
- `is_run`：是否立即运行

## 第六步：获取 AI 诊断结果

```bash
python scripts/step6_get_ai_diagnosis_result.py [--list-url <url>] [--token-file <token_store_json>] [--wsi-record-file <wsi_record_result_json>] [--slide-id <id>] [--wait-seconds <seconds>] [--no-wait]
```

默认行为：

- 请求前等待 30 秒（AI 诊断需要时间）
- `slide_id` 来自第五步输出的 `response.id`
- 查询接口：`GET http://10.5.16.108/api/v1/embed/image/list/?id=<slide_id>`
- 如果状态不是成功，提醒用户 1 分钟后再试
- 最终输出必须包含 `modified_ai_diagnosis_result_map.value`

`ai_diagnosis_status` 状态码说明：

- `0`：未知
- `1`：排队中
- `2`：队列中
- `3`：分析中
- `4`：分析成功
- `5`：分析失败

## 注意事项

- **第一步凭据提供方式**：优先读取环境变量 `PATHOLOGY_USERNAME` 和 `PATHOLOGY_PASSWORD`；如未设置，脚本报错退出并提示需要设置这两个环境变量。
- 第五步诊断类型确认：如用户未明确指定诊断类型，先询问并等待选择：
  - `6` — 通用组织切片
  - `14` — 消化道活检AI
- 第一步自动跳过：如 `scripts/data/token_store.json` 已包含有效（未过期）的 token，第一步打印 `skipped`
- 第二步自动跳过：如 `scripts/data/cos_credentials.json` 存在且 `expired_time` 未过期，第二步打印 `skipped`
- 第六步提醒规则：当 `ai_diagnosis_status` 不为 `4` 时，提醒用户 1 分钟后再试
- 任何一步返回 `401`，重新运行第一步刷新 token
