#!/usr/bin/env python3
"""Step 3: upload local WSI file to COS using temporary credentials from step 2."""

import argparse
import hashlib
import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path

try:
    from qcloud_cos import CosConfig, CosS3Client
except ImportError as exc:  # pragma: no cover
    CosConfig = None
    CosS3Client = None
    IMPORT_ERROR = exc
else:
    IMPORT_ERROR = None


DEFAULT_CREDENTIALS_FILE = Path(__file__).resolve().parent / "data" / "cos_credentials.json"
DEFAULT_OUTPUT_FILE = Path(__file__).resolve().parent / "data" / "cos_upload_result.json"
DEFAULT_LOCAL_FILE = Path(r"C:\Users\HYK\Desktop\chunk_1.svs")


def print_status(step: int, name: str, status: str, message: str) -> None:
    safe_message = str(message).replace("\n", " ").replace("\r", " ")
    print(f"STEP_STATUS|step={step}|name={name}|status={status}|message={safe_message}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Step 3 upload WSI file to COS")
    parser.add_argument("--credentials-file", default=str(DEFAULT_CREDENTIALS_FILE), help="COS credentials file from step2")
    parser.add_argument("--local-file", default=str(DEFAULT_LOCAL_FILE), help="Local file path to upload")
    parser.add_argument("--organization", default=os.environ.get("PATHOLOGY_ORGANIZATION", "openclaw"), help="Organization name in COS key path")
    parser.add_argument("--date", default=datetime.now().strftime("%Y%m%d"), help="Date segment YYYYMMDD")
    parser.add_argument("--scheme", default="https", choices=["http", "https"], help="COS request scheme")
    parser.add_argument("--part-size", type=int, default=8, help="Multipart chunk size in MB")
    parser.add_argument("--max-thread", type=int, default=4, help="Upload thread count")
    parser.add_argument("--output-file", default=str(DEFAULT_OUTPUT_FILE), help="Where to save upload metadata")
    return parser.parse_args()


def load_credentials(path: Path) -> dict:
    if not path.exists():
        raise FileNotFoundError(f"credentials file not found: {path}")
    data = json.loads(path.read_text(encoding="utf-8"))
    required = ["secret_id", "secret_key", "session_token", "bucket", "region_id"]
    missing = [k for k in required if not data.get(k)]
    if missing:
        raise ValueError(f"credentials missing fields: {', '.join(missing)}")
    return data


def md5_of_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.md5()
    with path.open("rb") as f:
        while True:
            block = f.read(chunk_size)
            if not block:
                break
            digest.update(block)
    return digest.hexdigest()


def build_cos_key(date_str: str, organization: str, file_md5: str, filename: str) -> str:
    if "/" in organization or "\\" in organization:
        raise ValueError("organization cannot contain '/' or '\\'")
    return f"SLIDES/chunked_uploads/{date_str}/{organization}/{file_md5}/{filename}"


def save_upload_result(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def main() -> int:
    step_name = "upload_wsi_to_cos"
    args = parse_args()

    if IMPORT_ERROR is not None:
        print_status(3, step_name, "error", f"qcloud_cos import failed: {IMPORT_ERROR}")
        return 1

    local_file = Path(args.local_file)
    if not local_file.exists() or not local_file.is_file():
        print_status(3, step_name, "error", f"local file not found: {local_file}")
        return 1

    try:
        creds = load_credentials(Path(args.credentials_file))
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print_status(3, step_name, "error", f"load credentials failed: {exc}")
        return 1

    try:
        file_size = local_file.stat().st_size
        file_md5 = md5_of_file(local_file)
        key = build_cos_key(args.date, args.organization, file_md5, local_file.name)
    except (OSError, ValueError) as exc:
        print_status(3, step_name, "error", f"build key failed: {exc}")
        return 1

    try:
        config = CosConfig(
            Region=creds["region_id"],
            SecretId=creds["secret_id"],
            SecretKey=creds["secret_key"],
            Token=creds["session_token"],
            Scheme=args.scheme,
        )
        client = CosS3Client(config)
        start = time.perf_counter()
        response = client.upload_file(
            Bucket=creds["bucket"],
            LocalFilePath=str(local_file),
            Key=key,
            PartSize=args.part_size,
            MAXThread=args.max_thread,
            EnableMD5=False,
        )
        duration_seconds = max(1, int(round(time.perf_counter() - start)))
    except Exception as exc:  # SDK errors are runtime-specific
        print_status(3, step_name, "error", f"upload failed: {exc}")
        return 1

    result = {
        "source": "step3_upload_wsi_to_cos",
        "saved_at_utc": datetime.now(timezone.utc).isoformat(),
        "local_file": str(local_file),
        "filename": local_file.name,
        "size": file_size,
        "organization": args.organization,
        "date": args.date,
        "file_md5": file_md5,
        "upload_duration_seconds": duration_seconds,
        "bucket": creds["bucket"],
        "region_id": creds["region_id"],
        "key": key,
        "etag": response.get("ETag"),
        "raw_response": response,
    }

    try:
        save_upload_result(Path(args.output_file), result)
    except OSError as exc:
        print_status(3, step_name, "error", f"save upload result failed: {exc}")
        return 1

    print_status(3, step_name, "success", f"uploaded to cos://{creds['bucket']}/{key}; result saved to {args.output_file}")
    print_status(4, "step4_record_callback", "pending", "implemented separately; run step4 script")
    print_status(5, "step5_placeholder", "pending", "not implemented yet")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
