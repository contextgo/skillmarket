#!/usr/bin/env python3
"""Step 5: create WSI record from uploaded file metadata."""

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

import requests

DEFAULT_CREATE_URL = "http://10.5.16.108//api/v1/image/create/"
DEFAULT_TOKEN_FILE = Path(__file__).resolve().parent / "data" / "token_store.json"
DEFAULT_UPLOAD_FILE = Path(__file__).resolve().parent / "data" / "cos_upload_result.json"
DEFAULT_OUTPUT_FILE = Path(__file__).resolve().parent / "data" / "wsi_record_result.json"


def print_status(step: int, name: str, status: str, message: str) -> None:
    safe_message = str(message).replace("\n", " ").replace("\r", " ")
    print(f"STEP_STATUS|step={step}|name={name}|status={status}|message={safe_message}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Step 5 create WSI record")
    parser.add_argument("--create-url", default=DEFAULT_CREATE_URL, help="Create WSI record API URL")
    parser.add_argument("--token-file", default=str(DEFAULT_TOKEN_FILE), help="Token file from step1")
    parser.add_argument("--upload-result-file", default=str(DEFAULT_UPLOAD_FILE), help="Upload result from step3")
    parser.add_argument("--disease", type=int, default=None, help="Diagnosis type ID (required: 6 or 14)")
    parser.add_argument("--source", type=int, default=3696, help="Organization ID")
    parser.add_argument("--is-run", dest="is_run", action="store_true", help="Set is_run=true (default true)")
    parser.add_argument("--no-is-run", dest="is_run", action="store_false", help="Set is_run=false")
    parser.set_defaults(is_run=True)
    parser.add_argument("--timeout", type=float, default=30.0, help="HTTP timeout seconds")
    parser.add_argument("--output-file", default=str(DEFAULT_OUTPUT_FILE), help="Where to save API response")
    return parser.parse_args()


def load_json(path: Path) -> dict:
    if not path.exists():
        raise FileNotFoundError(f"file not found: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def load_auth_header(token_file: Path) -> str:
    data = load_json(token_file)
    auth_header = data.get("authorization_header")
    if auth_header:
        return auth_header
    token = data.get("token")
    if not token:
        raise ValueError("token file missing 'token' and 'authorization_header'")
    token_type = data.get("token_type", "FQ")
    return f"{token_type} {token}".strip()


def build_body(upload: dict, disease: int, source: int, is_run: bool) -> dict:
    filename = upload.get("filename")
    if not filename:
        local_file = upload.get("local_file")
        if local_file:
            filename = Path(local_file).name
    if not filename:
        raise ValueError("missing filename in upload result")

    total_md5 = upload.get("file_md5")
    if not total_md5:
        raise ValueError("missing file_md5 in upload result")

    return {
        "filename": filename,
        "disease": disease,
        "source": source,
        "total_md5": total_md5,
        "is_run": bool(is_run),
    }


def save_result(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def main() -> int:
    step_name = "create_wsi_record"
    args = parse_args()

    if args.disease is None:
        print_status(5, step_name, "error", "missing disease; choose 6 (通用组织切片) or 14 (消化道活检AI)")
        return 1
    if args.disease not in (6, 14):
        print_status(5, step_name, "error", "invalid disease; only 6 (通用组织切片) or 14 (消化道活检AI) is allowed")
        return 1

    try:
        auth_header = load_auth_header(Path(args.token_file))
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print_status(5, step_name, "error", f"load token failed: {exc}")
        return 1

    try:
        upload = load_json(Path(args.upload_result_file))
        body = build_body(upload, args.disease, args.source, args.is_run)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print_status(5, step_name, "error", f"build request failed: {exc}")
        return 1

    headers = {
        "Authorization": auth_header,
        "Content-Type": "application/json",
        "Accept": "application/json",
    }

    try:
        resp = requests.post(args.create_url, headers=headers, json=body, timeout=args.timeout)
    except requests.RequestException as exc:
        print_status(5, step_name, "error", f"request failed: {exc}")
        return 1

    if resp.status_code != 200:
        snippet = (resp.text or "")[:500]
        print_status(5, step_name, "error", f"http={resp.status_code}, body={snippet}")
        return 1

    try:
        data = resp.json()
    except ValueError as exc:
        print_status(5, step_name, "error", f"invalid json response: {exc}")
        return 1

    result = {
        "source": "step5_create_wsi_record",
        "saved_at_utc": datetime.now(timezone.utc).isoformat(),
        "create_url": args.create_url,
        "request_body": body,
        "response": data,
    }

    try:
        save_result(Path(args.output_file), result)
    except OSError as exc:
        print_status(5, step_name, "error", f"save response failed: {exc}")
        return 1

    print_status(5, step_name, "success", f"wsi record created; result saved to {args.output_file}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
