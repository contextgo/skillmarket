#!/usr/bin/env python3
"""Step 6: query AI diagnosis result by slide ID from step 5 output."""

import argparse
import json
import time
from datetime import datetime, timezone
from pathlib import Path

import requests

DEFAULT_LIST_URL = "http://10.5.16.108/api/v1/embed/image/list/"
DEFAULT_TOKEN_FILE = Path(__file__).resolve().parent / "data" / "token_store.json"
DEFAULT_WSI_RECORD_FILE = Path(__file__).resolve().parent / "data" / "wsi_record_result.json"
DEFAULT_OUTPUT_FILE = Path(__file__).resolve().parent / "data" / "ai_diagnosis_result.json"

AI_STATUS_TEXT = {
    0: "未知",
    1: "排队中",
    2: "队列中",
    3: "分析中",
    4: "分析成功",
    5: "分析失败",
}


def print_status(step: int, name: str, status: str, message: str) -> None:
    safe_message = str(message).replace("\n", " ").replace("\r", " ")
    print(f"STEP_STATUS|step={step}|name={name}|status={status}|message={safe_message}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Step 6 query AI diagnosis result")
    parser.add_argument("--list-url", default=DEFAULT_LIST_URL, help="AI diagnosis query API URL")
    parser.add_argument("--token-file", default=str(DEFAULT_TOKEN_FILE), help="Token file from step1")
    parser.add_argument(
        "--wsi-record-file",
        default=str(DEFAULT_WSI_RECORD_FILE),
        help="WSI record result file from step5",
    )
    parser.add_argument("--slide-id", type=int, default=None, help="Explicit slide ID; overrides step5 output")
    parser.add_argument("--wait-seconds", type=float, default=30.0, help="Wait before querying (default: 30s)")
    parser.add_argument("--no-wait", action="store_true", help="Query immediately without waiting")
    parser.add_argument("--timeout", type=float, default=30.0, help="HTTP timeout seconds")
    parser.add_argument("--output-file", default=str(DEFAULT_OUTPUT_FILE), help="Where to save query response")
    return parser.parse_args()


def load_json(path: Path) -> dict:
    if not path.exists():
        raise FileNotFoundError(f"file not found: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def load_auth_header(token_file: Path) -> str:
    data = load_json(token_file)
    auth_header = data.get("authorization_header")
    if auth_header:
        return auth_header
    token = data.get("token")
    if not token:
        raise ValueError("token file missing 'token' and 'authorization_header'")
    token_type = data.get("token_type", "FQ")
    return f"{token_type} {token}".strip()


def resolve_slide_id(wsi_record_file: Path, explicit_id):
    if explicit_id is not None:
        return int(explicit_id)
    data = load_json(wsi_record_file)
    slide_id = (((data or {}).get("response") or {}).get("id"))
    if not slide_id:
        raise ValueError("missing response.id in step5 output")
    return int(slide_id)


def extract_ai_status(payload):
    if isinstance(payload, dict):
        if "ai_diagnosis_status" in payload and payload.get("ai_diagnosis_status") is not None:
            return int(payload["ai_diagnosis_status"])
        for value in payload.values():
            status = extract_ai_status(value)
            if status is not None:
                return status
    if isinstance(payload, list):
        for item in payload:
            status = extract_ai_status(item)
            if status is not None:
                return status
    return None


def extract_modified_value(payload):
    if isinstance(payload, dict):
        modified_map = payload.get("modified_ai_diagnosis_result_map")
        if isinstance(modified_map, dict) and "value" in modified_map:
            return modified_map.get("value")
        for value in payload.values():
            result = extract_modified_value(value)
            if result is not None:
                return result
    if isinstance(payload, list):
        for item in payload:
            result = extract_modified_value(item)
            if result is not None:
                return result
    return None


def save_result(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def main() -> int:
    step_name = "get_ai_diagnosis_result"
    args = parse_args()

    try:
        auth_header = load_auth_header(Path(args.token_file))
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print_status(6, step_name, "error", f"load token failed: {exc}")
        return 1

    try:
        slide_id = resolve_slide_id(Path(args.wsi_record_file), args.slide_id)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print_status(6, step_name, "error", f"resolve slide id failed: {exc}")
        return 1

    if not args.no_wait and args.wait_seconds > 0:
        time.sleep(args.wait_seconds)

    headers = {
        "Authorization": auth_header,
        "Accept": "application/json",
    }

    try:
        resp = requests.get(args.list_url, headers=headers, params={"id": slide_id}, timeout=args.timeout)
    except requests.RequestException as exc:
        print_status(6, step_name, "error", f"request failed: {exc}")
        return 1

    if resp.status_code != 200:
        snippet = (resp.text or "")[:500]
        print_status(6, step_name, "error", f"http={resp.status_code}, body={snippet}")
        return 1

    try:
        data = resp.json()
    except ValueError as exc:
        print_status(6, step_name, "error", f"invalid json response: {exc}")
        return 1

    ai_status = extract_ai_status(data)
    status_text = AI_STATUS_TEXT.get(ai_status, f"未知状态({ai_status})")
    modified_value = extract_modified_value(data)

    result = {
        "source": "step6_get_ai_diagnosis_result",
        "saved_at_utc": datetime.now(timezone.utc).isoformat(),
        "list_url": args.list_url,
        "slide_id": slide_id,
        "ai_diagnosis_status": ai_status,
        "ai_diagnosis_status_text": status_text,
        "modified_ai_diagnosis_result_map_value": modified_value,
        "response": data,
    }

    try:
        save_result(Path(args.output_file), result)
    except OSError as exc:
        print_status(6, step_name, "error", f"save response failed: {exc}")
        return 1

    value_text = modified_value
    if isinstance(modified_value, list):
        value_text = ",".join(str(item) for item in modified_value)
    if value_text is None:
        value_text = "N/A"

    if ai_status == 4:
        print_status(
            6,
            step_name,
            "success",
            f"ai_diagnosis_status=4({status_text}); modified_ai_diagnosis_result_map.value={value_text}; result saved to {args.output_file}",
        )
        return 0

    message = (
        f"ai_diagnosis_status={ai_status}({status_text}); "
        f"modified_ai_diagnosis_result_map.value={value_text}; "
        "not successful yet, please retry after 1 minute"
    )
    if ai_status == 5:
        print_status(6, step_name, "error", f"{message}; result saved to {args.output_file}")
        return 1
    print_status(6, step_name, "pending", f"{message}; result saved to {args.output_file}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
