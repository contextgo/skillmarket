#!/usr/bin/env python3
"""Step 1: login/auth and save token locally with explicit step status output."""

import argparse
import json
import os
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import requests

DEFAULT_LOGIN_URL = "http://10.5.16.108/api/v1/user/login/"
DEFAULT_TOKEN_FILE = Path(__file__).resolve().parent / "data" / "token_store.json"



def print_status(step: int, name: str, status: str, message: str) -> None:
    safe_message = str(message).replace("\n", " ").replace("\r", " ")
    print(f"STEP_STATUS|step={step}|name={name}|status={status}|message={safe_message}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Step 1 login/auth for analysis pathology workflow")
    parser.add_argument("--login-url", default=DEFAULT_LOGIN_URL, help="Login endpoint URL")
    parser.add_argument(
        "--token-file",
        default=str(DEFAULT_TOKEN_FILE),
        help="Local token file path",
    )
    parser.add_argument("--timeout", type=float, default=30.0, help="HTTP timeout in seconds")
    return parser.parse_args()


def save_token(token_file: Path, token: str, login_url: str, username: str) -> None:
    token_file.parent.mkdir(parents=True, exist_ok=True)
    now = datetime.now(timezone.utc)
    expires_at = now + timedelta(days=3)
    payload = {
        "token": token,
        "token_type": "FQ",
        "authorization_header": f"FQ {token}",
        "source": "step1_login_auth",
        "login_url": login_url,
        "username": username,
        "saved_at_utc": now.isoformat(),
        "expires_at_utc": expires_at.isoformat(),
        "validity_hint": "3 days (from API documentation)",
    }
    token_file.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def has_reusable_token(token_file: Path) -> bool:
    if not token_file.exists():
        return False
    data = json.loads(token_file.read_text(encoding="utf-8"))
    return bool(data.get("authorization_header") or data.get("token"))


def main() -> int:
    args = parse_args()
    step_name = "login_auth"
    token_file = Path(args.token_file)

    try:
        if has_reusable_token(token_file):
            print_status(1, step_name, "success", f"skipped: existing token found in {args.token_file}")
            print_status(2, "step2_placeholder", "pending", "not implemented yet")
            print_status(3, "step3_placeholder", "pending", "not implemented yet")
            print_status(4, "step4_placeholder", "pending", "not implemented yet")
            print_status(5, "step5_placeholder", "pending", "not implemented yet")
            return 0
    except (OSError, ValueError, json.JSONDecodeError):
        # Token file is broken/unreadable; continue with fresh login.
        pass

    username = os.environ.get("PATHOLOGY_USERNAME")
    password = os.environ.get("PATHOLOGY_PASSWORD")

    if not username or not password:
        print_status(1, step_name, "error", "username and password must be set via PATHOLOGY_USERNAME and PATHOLOGY_PASSWORD environment variables")
        return 1

    body = {"username": username, "password": password}
    headers = {"Content-Type": "application/json", "Accept": "application/json"}

    try:
        resp = requests.post(args.login_url, json=body, headers=headers, timeout=args.timeout)
    except requests.RequestException as exc:
        print_status(1, step_name, "error", f"request failed: {exc}")
        return 1

    if resp.status_code != 200:
        snippet = (resp.text or "")[:400]
        print_status(1, step_name, "error", f"http={resp.status_code}, body={snippet}")
        return 1

    try:
        data = resp.json()
    except ValueError as exc:
        print_status(1, step_name, "error", f"invalid json response: {exc}")
        return 1

    token = data.get("token")
    if not token:
        print_status(1, step_name, "error", "response json missing 'token'")
        return 1

    try:
        save_token(token_file, token, args.login_url, username)
    except OSError as exc:
        print_status(1, step_name, "error", f"save token failed: {exc}")
        return 1

    print_status(1, step_name, "success", f"token saved to {args.token_file}")

    # Keep placeholders visible for the full 5-step contract.
    print_status(2, "step2_placeholder", "pending", "not implemented yet")
    print_status(3, "step3_placeholder", "pending", "not implemented yet")
    print_status(4, "step4_placeholder", "pending", "not implemented yet")
    print_status(5, "step5_placeholder", "pending", "not implemented yet")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
