#!/usr/bin/env python3
"""Step 2: get temporary COS credentials using token from step 1."""

import argparse
import json
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import requests

DEFAULT_CREDENTIALS_URL = "http://10.5.16.108/api/v1/cos/credentials/"
DEFAULT_TOKEN_FILE = Path(__file__).resolve().parent / "data" / "token_store.json"
DEFAULT_OUTPUT_FILE = Path(__file__).resolve().parent / "data" / "cos_credentials.json"


def print_status(step: int, name: str, status: str, message: str) -> None:
    safe_message = str(message).replace("\n", " ").replace("\r", " ")
    print(f"STEP_STATUS|step={step}|name={name}|status={status}|message={safe_message}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Step 2 get temporary COS credentials")
    parser.add_argument("--credentials-url", default=DEFAULT_CREDENTIALS_URL, help="COS credentials endpoint URL")
    parser.add_argument("--token-file", default=str(DEFAULT_TOKEN_FILE), help="Token file path from step1")
    parser.add_argument("--output-file", default=str(DEFAULT_OUTPUT_FILE), help="Where to store COS credentials")
    parser.add_argument("--timeout", type=float, default=30.0, help="HTTP timeout in seconds")
    return parser.parse_args()


def load_auth_header(token_file: Path) -> str:
    if not token_file.exists():
        raise FileNotFoundError(f"token file not found: {token_file}")

    data = json.loads(token_file.read_text(encoding="utf-8"))
    auth_header = data.get("authorization_header")
    if auth_header:
        return auth_header

    token = data.get("token")
    if not token:
        raise ValueError("token file missing 'token' and 'authorization_header'")

    token_type = data.get("token_type", "FQ")
    return f"{token_type} {token}".strip()


def save_credentials(output_file: Path, response_data: dict, source_url: str) -> None:
    output_file.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "source": "step2_get_cos_credentials",
        "credentials_url": source_url,
        "saved_at_utc": datetime.now(timezone.utc).isoformat(),
        "secret_id": response_data.get("secret_id"),
        "secret_key": response_data.get("secret_key"),
        "session_token": response_data.get("session_token"),
        "expired_time": response_data.get("expired_time"),
        "bucket": response_data.get("bucket"),
        "region_id": response_data.get("region_id"),
        "durations": response_data.get("durations"),
        "raw_response": response_data,
    }
    output_file.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def _parse_expired_time_local(expired_time: str):
    try:
        return datetime.strptime(expired_time, "%Y-%m-%d %H:%M:%S")
    except (TypeError, ValueError):
        return None


def has_valid_cached_credentials(output_file: Path) -> bool:
    if not output_file.exists():
        return False
    data = json.loads(output_file.read_text(encoding="utf-8"))

    required = ["secret_id", "secret_key", "session_token", "bucket", "region_id"]
    if any(not data.get(k) for k in required):
        return False

    # Prefer API-provided expired_time string.
    expired_time = _parse_expired_time_local(data.get("expired_time"))
    if expired_time is not None:
        return datetime.now() + timedelta(seconds=30) < expired_time

    # Fallback: estimate using saved_at_utc + durations.
    saved_at = data.get("saved_at_utc")
    durations = data.get("durations")
    if saved_at and durations:
        try:
            saved_dt = datetime.fromisoformat(str(saved_at))
            if saved_dt.tzinfo is None:
                saved_dt = saved_dt.replace(tzinfo=timezone.utc)
            expire_dt = saved_dt + timedelta(seconds=int(durations))
            return datetime.now(timezone.utc) + timedelta(seconds=30) < expire_dt
        except (TypeError, ValueError):
            return False
    return False


def main() -> int:
    args = parse_args()
    step_name = "get_cos_credentials"
    output_file = Path(args.output_file)

    try:
        if has_valid_cached_credentials(output_file):
            print_status(2, step_name, "success", f"skipped: cached credentials still valid in {args.output_file}")
            print_status(3, "step3_placeholder", "pending", "not implemented yet")
            print_status(4, "step4_placeholder", "pending", "not implemented yet")
            print_status(5, "step5_placeholder", "pending", "not implemented yet")
            return 0
    except (OSError, ValueError, json.JSONDecodeError):
        # Cached file is broken/unreadable; continue with fresh credential request.
        pass

    try:
        authorization = load_auth_header(Path(args.token_file))
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print_status(2, step_name, "error", f"load token failed: {exc}")
        return 1

    headers = {
        "Authorization": authorization,
        "Accept": "application/json",
    }

    try:
        resp = requests.get(args.credentials_url, headers=headers, timeout=args.timeout)
    except requests.RequestException as exc:
        print_status(2, step_name, "error", f"request failed: {exc}")
        return 1

    if resp.status_code != 200:
        snippet = (resp.text or "")[:400]
        print_status(2, step_name, "error", f"http={resp.status_code}, body={snippet}")
        return 1

    try:
        data = resp.json()
    except ValueError as exc:
        print_status(2, step_name, "error", f"invalid json response: {exc}")
        return 1

    required = [
        "secret_id",
        "secret_key",
        "session_token",
        "expired_time",
        "bucket",
        "region_id",
        "durations",
    ]
    missing = [k for k in required if not data.get(k)]
    if missing:
        print_status(2, step_name, "error", f"response missing fields: {', '.join(missing)}")
        return 1

    try:
        save_credentials(output_file, data, args.credentials_url)
    except OSError as exc:
        print_status(2, step_name, "error", f"save credentials failed: {exc}")
        return 1

    print_status(2, step_name, "success", f"credentials saved to {args.output_file}")
    print_status(3, "step3_placeholder", "pending", "not implemented yet")
    print_status(4, "step4_placeholder", "pending", "not implemented yet")
    print_status(5, "step5_placeholder", "pending", "not implemented yet")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
