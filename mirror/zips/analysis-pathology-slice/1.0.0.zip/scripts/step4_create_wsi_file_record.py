#!/usr/bin/env python3
"""Step 4: create WSI file record via callback after COS upload."""

import argparse
import json
import re
from datetime import datetime, timezone
from pathlib import Path

import requests

DEFAULT_CALLBACK_URL = "http://10.5.16.108//api/v1/file_record/callback/"
DEFAULT_TOKEN_FILE = Path(__file__).resolve().parent / "data" / "token_store.json"
DEFAULT_UPLOAD_FILE = Path(__file__).resolve().parent / "data" / "cos_upload_result.json"
DEFAULT_OUTPUT_FILE = Path(__file__).resolve().parent / "data" / "file_record_result.json"


def print_status(step: int, name: str, status: str, message: str) -> None:
    safe_message = str(message).replace("\n", " ").replace("\r", " ")
    print(f"STEP_STATUS|step={step}|name={name}|status={status}|message={safe_message}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Step 4 create WSI file record callback")
    parser.add_argument("--callback-url", default=DEFAULT_CALLBACK_URL, help="File record callback URL")
    parser.add_argument("--token-file", default=str(DEFAULT_TOKEN_FILE), help="Token file from step1")
    parser.add_argument("--upload-result-file", default=str(DEFAULT_UPLOAD_FILE), help="Upload result file from step3")
    parser.add_argument("--disease", type=int, default=6, help="Diagnosis type ID")
    parser.add_argument("--upload-type", type=int, default=3, help="Upload type: 1 normal, 2 auto, 3 COS")
    parser.add_argument("--timeout", type=float, default=30.0, help="HTTP timeout seconds")
    parser.add_argument("--output-file", default=str(DEFAULT_OUTPUT_FILE), help="Where to save callback response")
    return parser.parse_args()


def load_json(path: Path) -> dict:
    if not path.exists():
        raise FileNotFoundError(f"file not found: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def load_auth_header(token_file: Path) -> str:
    data = load_json(token_file)
    auth_header = data.get("authorization_header")
    if auth_header:
        return auth_header
    token = data.get("token")
    if not token:
        raise ValueError("token file missing 'token' and 'authorization_header'")
    token_type = data.get("token_type", "FQ")
    return f"{token_type} {token}".strip()


PATH_PATTERN = re.compile(
    r"^chunked_uploads/\d{8}/[^/]+/[0-9a-fA-F]{32}/[^/]+$"
)


def callback_path_from_key(key: str) -> str:
    key = (key or "").strip().lstrip("/")
    if not key:
        raise ValueError("upload key is empty")
    if key.startswith("SLIDES/"):
        return key[len("SLIDES/"):]
    return key


def validate_callback_path(path: str) -> None:
    if not PATH_PATTERN.match(path):
        raise ValueError(
            "invalid path format; expected "
            "chunked_uploads/{YYYYMMDD}/{Organization Name}/{File MD5}/{File Name}{File Extension}"
        )


def save_result(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def main() -> int:
    step_name = "create_wsi_file_record"
    args = parse_args()

    try:
        auth_header = load_auth_header(Path(args.token_file))
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print_status(4, step_name, "error", f"load token failed: {exc}")
        return 1

    try:
        upload = load_json(Path(args.upload_result_file))
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print_status(4, step_name, "error", f"load upload result failed: {exc}")
        return 1

    try:
        filename = upload.get("filename") or Path(upload["local_file"]).name
        total_md5 = upload["file_md5"]
        local_path = upload.get("local_file")
        if upload.get("size") is not None:
            size = int(upload["size"])
        elif local_path and Path(local_path).exists():
            size = int(Path(local_path).stat().st_size)
        else:
            raise KeyError("size")
        duration = int(upload.get("upload_duration_seconds", 1))
        raw_path = callback_path_from_key(upload["key"])
        validate_callback_path(raw_path)
    except (KeyError, ValueError, TypeError, OSError) as exc:
        print_status(4, step_name, "error", f"invalid upload metadata: {exc}")
        return 1

    body = {
        "filename": filename,
        "total_md5": total_md5,
        "size": size,
        "duration": max(1, duration),
        "upload_type": args.upload_type,
        "disease": args.disease,
        "path": raw_path,
    }

    headers = {
        "Authorization": auth_header,
        "Content-Type": "application/json",
        "Accept": "application/json",
    }

    try:
        resp = requests.post(args.callback_url, headers=headers, json=body, timeout=args.timeout)
    except requests.RequestException as exc:
        print_status(4, step_name, "error", f"request failed: {exc}")
        return 1

    if resp.status_code != 200:
        snippet = (resp.text or "")[:500]
        print_status(4, step_name, "error", f"http={resp.status_code}, body={snippet}")
        return 1

    try:
        data = resp.json()
    except ValueError as exc:
        print_status(4, step_name, "error", f"invalid json response: {exc}")
        return 1

    result = {
        "source": "step4_create_wsi_file_record",
        "saved_at_utc": datetime.now(timezone.utc).isoformat(),
        "callback_url": args.callback_url,
        "request_body": body,
        "response": data,
    }

    try:
        save_result(Path(args.output_file), result)
    except OSError as exc:
        print_status(4, step_name, "error", f"save callback result failed: {exc}")
        return 1

    print_status(4, step_name, "success", f"file record created; result saved to {args.output_file}")
    print_status(5, "step5_placeholder", "pending", "not implemented yet")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
