# file_parser.py - CSV/Excel File Parser
"""Parse CSV and Excel files with pandas, generate data overview."""

import pandas as pd
import os
from typing import Dict, Any, Tuple, Optional

from .config import PREVIEW_ROWS, ROW_LIMITS


class FileParser:
    """Parse CSV/Excel files and generate data overview."""

    def __init__(self, max_rows: int = ROW_LIMITS["FREE"]):
        self.max_rows = max_rows
        self.df: Optional[pd.DataFrame] = None
        self.file_path: Optional[str] = None
        self.file_name: Optional[str] = None

    def parse(self, file_path: str) -> Dict[str, Any]:
        """Parse file and return data overview."""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")

        self.file_path = file_path
        self.file_name = os.path.basename(file_path)

        ext = os.path.splitext(file_path)[1].lower()

        if ext == ".csv":
            self.df = pd.read_csv(file_path)
        elif ext in [".xlsx", ".xls"]:
            self.df = pd.read_excel(file_path)
        else:
            raise ValueError(f"Unsupported file type: {ext}")

        # Enforce row limit
        original_rows = len(self.df)
        if original_rows > self.max_rows:
            self.df = self.df.head(self.max_rows)

        return self.get_overview(original_rows)

    def get_overview(self, original_rows: Optional[int] = None) -> Dict[str, Any]:
        """Generate data overview from parsed DataFrame."""
        if self.df is None:
            raise ValueError("No file parsed. Call parse() first.")

        rows, cols = self.df.shape
        column_info = []

        for col in self.df.columns:
            dtype = str(self.df[col].dtype)
            null_count = int(self.df[col].isnull().sum())
            unique_count = int(self.df[col].nunique())

            # Infer semantic type
            if pd.api.types.is_numeric_dtype(self.df[col]):
                semantic_type = "numeric"
            elif pd.api.types.is_datetime64_any_dtype(self.df[col]):
                semantic_type = "datetime"
            elif pd.api.types.is_bool_dtype(self.df[col]):
                semantic_type = "boolean"
            else:
                semantic_type = "categorical"

            column_info.append({
                "name": str(col),
                "dtype": dtype,
                "semantic_type": semantic_type,
                "null_count": null_count,
                "unique_count": unique_count,
            })

        return {
            "file_name": self.file_name,
            "total_rows": rows,
            "total_columns": cols,
            "original_rows": original_rows or rows,
            "truncated": original_rows > rows if original_rows else False,
            "columns": column_info,
            "preview": self.df.head(PREVIEW_ROWS).to_dict(orient="records"),
        }

    def get_column_names(self) -> list:
        """Return list of column names."""
        if self.df is None:
            return []
        return list(self.df.columns)

    def get_numeric_columns(self) -> list:
        """Return list of numeric column names."""
        if self.df is None:
            return []
        return list(self.df.select_dtypes(include=["number"]).columns)

    def get_data_for_chart(self, x_col: str, y_cols: list) -> Dict[str, Any]:
        """Extract data for chart rendering."""
        if self.df is None:
            raise ValueError("No file parsed. Call parse() first.")

        if x_col not in self.df.columns:
            raise ValueError(f"Column not found: {x_col}")

        result = {
            "x": self.df[x_col].tolist(),
        }

        for y_col in y_cols:
            if y_col in self.df.columns:
                result[y_col] = self.df[y_col].tolist()

        return result


def parse_file(file_path: str, max_rows: int = ROW_LIMITS["FREE"]) -> Dict[str, Any]:
    """Convenience function to parse a file and return overview."""
    parser = FileParser(max_rows=max_rows)
    return parser.parse(file_path)
