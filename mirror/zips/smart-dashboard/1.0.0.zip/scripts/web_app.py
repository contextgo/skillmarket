#!/usr/bin/env python3
# web_app.py - Web interface for Smart Dashboard Generator
"""Simple web interface for Smart Dashboard Generator.

This provides a web UI that handles:
1. File upload (CSV/Excel)
2. AI chart recommendation
3. Chart rendering to PNG
4. Download

Usage:
    python -m smart_dashboard.src.web_app [--port PORT]
"""

import argparse
import base64
import io
import json
import os
import sys
import uuid
import webbrowser
from http.server import HTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from threading import Thread
from typing import Optional

# Add src to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.file_parser import FileParser, parse_file
from src.chart_recommender import recommend_chart
from src.chart_renderer import render_chart, ChartRenderer
from src.config import BASE_DIR, OUTPUT_DIR, FREE_USES_LIMIT, ROW_LIMITS

# Import billing
try:
    from tencent.billing import get_tier, get_usage_limit, check_access
    BILLING_AVAILABLE = True
except ImportError:
    try:
        from clawhub.billing import checkAndDeduct, getBalance, DEV_MODE
        BILLING_AVAILABLE = True
    except ImportError:
        BILLING_AVAILABLE = False


HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Dashboard Generator</title>
    <script src="https://cdn.jsdelivr.net/npm/echarts@5.4.3/dist/echarts.min.js"></script>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f5f7fa; color: #333; min-height: 100vh; }
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px 20px; border-radius: 0 0 20px 20px; text-align: center; margin-bottom: 30px; }
        header h1 { font-size: 2em; margin-bottom: 10px; }
        header p { opacity: 0.9; font-size: 1.1em; }
        .card { background: white; border-radius: 12px; padding: 24px; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
        .card h2 { font-size: 1.3em; margin-bottom: 16px; color: #444; border-bottom: 2px solid #667eea; padding-bottom: 8px; }
        .upload-zone { border: 2px dashed #ddd; border-radius: 12px; padding: 40px; text-align: center; transition: all 0.3s; cursor: pointer; }
        .upload-zone:hover { border-color: #667eea; background: #f8f9ff; }
        .upload-zone.dragover { border-color: #667eea; background: #f0f2ff; }
        .upload-zone input[type="file"] { display: none; }
        .upload-icon { font-size: 48px; margin-bottom: 16px; }
        .btn { background: #667eea; color: white; border: none; padding: 12px 24px; border-radius: 8px; cursor: pointer; font-size: 1em; transition: background 0.2s; }
        .btn:hover { background: #5568d3; }
        .btn:disabled { background: #ccc; cursor: not-allowed; }
        .btn-secondary { background: #6c757d; }
        .btn-secondary:hover { background: #5a6268; }
        .form-group { margin-bottom: 16px; }
        .form-group label { display: block; margin-bottom: 6px; font-weight: 500; }
        .form-group input, .form-group select { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px; font-size: 1em; }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
        @media (max-width: 768px) { .form-row { grid-template-columns: 1fr; } }
        .preview-table { width: 100%; border-collapse: collapse; margin-top: 16px; overflow-x: auto; display: block; }
        .preview-table th, .preview-table td { padding: 10px; text-align: left; border-bottom: 1px solid #eee; white-space: nowrap; }
        .preview-table th { background: #f8f9fa; font-weight: 600; }
        .preview-table tr:hover { background: #f8f9ff; }
        .chart-container { background: white; border-radius: 12px; padding: 20px; margin: 20px 0; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
        .chart-wrapper { width: 100%; height: 400px; }
        .charts-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(500px, 1fr)); gap: 20px; }
        @media (max-width: 768px) { .charts-grid { grid-template-columns: 1fr; } }
        .status { padding: 12px 16px; border-radius: 8px; margin-bottom: 16px; }
        .status.info { background: #e7f3ff; color: #0066cc; border: 1px solid #b3d9ff; }
        .status.error { background: #ffe7e7; color: #cc0000; border: 1px solid #ffb3b3; }
        .status.success { background: #e7ffe7; color: #006600; border: 1px solid #b3ffb3; }
        .usage-info { background: #f8f9fa; padding: 12px; border-radius: 8px; margin-top: 16px; font-size: 0.9em; color: #666; }
        .loading { display: inline-block; width: 20px; height: 20px; border: 3px solid #f3f3f3; border-top: 3px solid #667eea; border-radius: 50%; animation: spin 1s linear infinite; }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        .hidden { display: none; }
        .footer { text-align: center; padding: 20px; color: #888; font-size: 0.9em; }
    </style>
</head>
<body>
    <header>
        <h1>Smart Dashboard Generator</h1>
        <p>Upload data, describe what you want, get professional charts instantly</p>
    </header>

    <div class="container">
        <div id="status-area"></div>

        <!-- Upload Section -->
        <div class="card" id="upload-section">
            <h2>Step 1: Upload Data File</h2>
            <div class="upload-zone" id="drop-zone">
                <div class="upload-icon">📁</div>
                <p><strong>Drop CSV or Excel file here</strong></p>
                <p style="color: #888; margin-top: 8px;">or click to browse</p>
                <input type="file" id="file-input" accept=".csv,.xlsx,.xls">
            </div>
            <div id="file-info" class="hidden">
                <p><strong>File:</strong> <span id="file-name"></span></p>
                <p><strong>Size:</strong> <span id="file-size"></span></p>
            </div>
        </div>

        <!-- Data Preview Section -->
        <div class="card hidden" id="preview-section">
            <h2>Step 2: Data Overview</h2>
            <div id="data-overview"></div>
            <h3 style="margin: 16px 0 8px; font-size: 1.1em;">Preview (first 10 rows)</h3>
            <div style="overflow-x: auto;">
                <table class="preview-table" id="preview-table"></table>
            </div>
        </div>

        <!-- AI Request Section -->
        <div class="card hidden" id="request-section">
            <h2>Step 3: Describe Your Chart</h2>
            <div class="form-row">
                <div class="form-group">
                    <label>AI Provider</label>
                    <select id="ai-provider">
                        <option value="openai">OpenAI (GPT-4o)</option>
                        <option value="claude">Claude</option>
                        <option value="zhipu">Zhipu GLM</option>
                        <option value="minimax">MiniMax</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Chart Title (optional)</label>
                    <input type="text" id="chart-title" placeholder="e.g., Monthly Sales Report">
                </div>
            </div>
            <div class="form-group">
                <label>Your Request (natural language)</label>
                <input type="text" id="user-request" placeholder="e.g., Show sales trends over time, compare categories">
            </div>
            <button class="btn" id="generate-btn" onclick="generateCharts()">Generate Charts</button>
        </div>

        <!-- Charts Section -->
        <div class="card hidden" id="charts-section">
            <h2>Generated Charts</h2>
            <div class="charts-grid" id="charts-container"></div>
            <div style="margin-top: 20px;">
                <button class="btn btn-secondary" onclick="downloadAllCharts()">Download All as PNG</button>
            </div>
        </div>

        <!-- Usage Info -->
        <div class="usage-info" id="usage-info"></div>
    </div>

    <div class="footer">
        <p>Smart Dashboard Generator &bull; All data processed locally</p>
    </div>

    <script>
        let currentData = null;
        let currentCharts = [];

        // File upload handling
        const dropZone = document.getElementById('drop-zone');
        const fileInput = document.getElementById('file-input');

        dropZone.addEventListener('click', () => fileInput.click());

        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.classList.add('dragover');
        });

        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('dragover');
        });

        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropZone.classList.remove('dragover');
            const file = e.dataTransfer.files[0];
            if (file) handleFile(file);
        });

        fileInput.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) handleFile(file);
        });

        async function handleFile(file) {
            const validTypes = ['.csv', '.xlsx', '.xls'];
            const ext = '.' + file.name.split('.').pop().toLowerCase();
            if (!validTypes.includes(ext)) {
                showStatus('Please upload a CSV or Excel file', 'error');
                return;
            }

            showStatus('Parsing file...', 'info');

            const formData = new FormData();
            formData.append('file', file);
            formData.append('command', 'parse');

            try {
                const resp = await fetch('/api', {
                    method: 'POST',
                    body: formData
                });
                const data = await resp.json();

                if (data.error) {
                    showStatus(data.error, 'error');
                    return;
                }

                currentData = data;
                document.getElementById('file-name').textContent = data.file_name;
                document.getElementById('file-size').textContent = formatBytes(file.size);
                document.getElementById('file-info').classList.remove('hidden');
                document.getElementById('preview-section').classList.remove('hidden');
                document.getElementById('request-section').classList.remove('hidden');

                // Show data overview
                const overview = document.getElementById('data-overview');
                overview.innerHTML = `
                    <p><strong>Rows:</strong> ${data.total_rows}${data.truncated ? ` (of ${data.original_rows})` : ''}</p>
                    <p><strong>Columns:</strong> ${data.total_columns}</p>
                    <p><strong>Column Types:</strong></p>
                    <ul style="margin-left: 20px; margin-top: 8px;">
                        ${data.columns.map(c => `<li>${c.name}: ${c.semantic_type} (${c.dtype})</li>`).join('')}
                    </ul>
                `;

                // Show preview table
                const previewTable = document.getElementById('preview-table');
                const preview = data.preview.slice(0, 10);
                const cols = data.columns.map(c => c.name);
                previewTable.innerHTML = `
                    <thead><tr>${cols.map(c => `<th>${c}</th>`).join('')}</tr></thead>
                    <tbody>
                        ${preview.map(row => `<tr>${cols.map(c => `<td>${row[c] ?? ''}</td>`).join('')}</tr>`).join('')}
                    </tbody>
                `;

                // Update usage info
                updateUsageInfo(data.remaining_uses);
                showStatus('File parsed successfully', 'success');

            } catch (err) {
                showStatus('Error parsing file: ' + err.message, 'error');
            }
        }

        async function generateCharts() {
            const request = document.getElementById('user-request').value.trim();
            if (!request) {
                showStatus('Please enter your chart request', 'error');
                return;
            }

            if (!currentData) {
                showStatus('Please upload a file first', 'error');
                return;
            }

            const btn = document.getElementById('generate-btn');
            btn.disabled = true;
            btn.innerHTML = '<span class="loading"></span> Generating...';
            showStatus('Generating charts with AI...', 'info');

            try {
                const resp = await fetch('/api', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        command: 'generate',
                        file_name: currentData.file_name,
                        data_overview: currentData,
                        request: request,
                        provider: document.getElementById('ai-provider').value,
                        chart_title: document.getElementById('chart-title').value
                    })
                });

                const data = await resp.json();

                if (data.error) {
                    showStatus(data.error, 'error');
                    btn.disabled = false;
                    btn.textContent = 'Generate Charts';
                    return;
                }

                // Render charts
                currentCharts = data.charts || [];
                renderCharts(data.charts);

                document.getElementById('charts-section').classList.remove('hidden');
                updateUsageInfo(data.remaining_uses);
                showStatus(`Generated ${currentCharts.length} chart(s)`, 'success');

            } catch (err) {
                showStatus('Error generating charts: ' + err.message, 'error');
            } finally {
                btn.disabled = false;
                btn.textContent = 'Generate Charts';
            }
        }

        function renderCharts(charts) {
            const container = document.getElementById('charts-container');
            container.innerHTML = '';

            charts.forEach((chart, i) => {
                if (!chart.success) return;

                const div = document.createElement('div');
                div.className = 'chart-container';
                div.innerHTML = `
                    <h3 style="margin-bottom: 12px;">${chart.title || 'Chart ' + (i+1)}</h3>
                    <div class="chart-wrapper" id="chart-${i}"></div>
                    <button class="btn btn-secondary" style="margin-top: 12px;" onclick="downloadChart(${i})">Download PNG</button>
                `;
                container.appendChild(div);

                // Initialize ECharts
                const chartDom = document.getElementById(`chart-${i}`);
                const myChart = echarts.init(chartDom);

                try {
                    const chartData = typeof chart.chart_data === 'string' ? JSON.parse(chart.chart_data) : chart.chart_data;
                    myChart.setOption(chartData);
                    chart._echarts = myChart;
                } catch (err) {
                    chartDom.innerHTML = `<p style="color: red;">Error rendering chart: ${err.message}</p>`;
                }
            });
        }

        function downloadChart(index) {
            const chart = currentCharts[index];
            if (!chart || !chart.success) return;

            const a = document.createElement('a');
            a.href = chart.png_data;
            a.download = `chart_${index + 1}.png`;
            a.click();
        }

        function downloadAllCharts() {
            currentCharts.forEach((chart, i) => {
                if (chart.success) {
                    setTimeout(() => downloadChart(i), i * 200);
                }
            });
        }

        function showStatus(message, type) {
            const statusArea = document.getElementById('status-area');
            statusArea.innerHTML = `<div class="status ${type}">${message}</div>`;
            setTimeout(() => { if (statusArea) statusArea.innerHTML = ''; }, 5000);
        }

        function updateUsageInfo(remaining) {
            const info = document.getElementById('usage-info');
            if (info && remaining !== undefined) {
                info.innerHTML = `<strong>Remaining uses:</strong> ${remaining} / ${remaining > 0 ? 10 : 0} FREE uses`;
            }
        }

        function formatBytes(bytes) {
            if (bytes === 0) return '0 Bytes';
            const k = 1024;
            const sizes = ['Bytes', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
        }

        // Initialize
        updateUsageInfo(10);
    </script>
</body>
</html>
"""


class DashboardHandler(SimpleHTTPRequestHandler):
    """HTTP handler for dashboard web app."""

    def do_GET(self):
        """Serve the web app."""
        if self.path == '/' or self.path == '/index.html':
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            self.wfile.write(HTML_TEMPLATE.encode())
        else:
            super().do_GET()

    def do_POST(self):
        """Handle API requests."""
        if self.path == '/api':
            content_length = int(self.headers.get('Content-Length', 0))
            content_type = self.headers.get('Content-Type', '')

            if 'multipart/form-data' in content_type:
                # File upload - parse
                body = self.rfile.read(content_length)
                import cgi
                fields = cgi.parse_multipart(io.BytesIO(body), self.headers)
                file_data = fields.get('file')[0] if fields.get('file') else None
                command = fields.get('command', [''])[0]

                if file_data and command == 'parse':
                    # Save temp file
                    file_name = file_data.filename if hasattr(file_data, 'filename') else 'uploaded_file'
                    import tempfile
                    with tempfile.NamedTemporaryFile(mode='wb', suffix=os.path.splitext(file_name)[1], delete=False) as f:
                        f.write(file_data)
                        temp_path = f.name

                    try:
                        tracker = UsageTracker()
                        if not tracker.check_and_increment():
                            self.send_json({"error": "FREE tier exhausted", "remaining": 0})
                            return

                        parser = FileParser(max_rows=ROW_LIMITS["FREE"])
                        overview = parser.parse(temp_path)
                        overview["remaining_uses"] = tracker.get_remaining()
                        self.send_json(overview)
                    except Exception as e:
                        self.send_json({"error": str(e)})
                    finally:
                        os.unlink(temp_path)
                else:
                    self.send_json({"error": "Invalid request"})
            else:
                # JSON request
                body = self.rfile.read(content_length)
                data = json.loads(body)
                command = data.get('command', '')

                if command == 'generate':
                    self.handle_generate(data)
                else:
                    self.send_json({"error": "Unknown command"})
        else:
            self.send_json({"error": "Not found"})

    def handle_generate(self, data):
        """Handle generate command."""
        try:
            tracker = UsageTracker()
            if not tracker.check_and_increment():
                self.send_json({"error": "FREE tier exhausted", "remaining": 0})
                return

            data_overview = data.get('data_overview', {})
            user_request = data.get('request', '')
            provider = data.get('provider', 'openai')
            chart_title = data.get('chart_title', '')

            # Get AI recommendation
            api_key = os.environ.get('AI_API_KEY', '')
            if not api_key:
                # Return demo recommendation
                charts = self._demo_charts(data_overview, chart_title)
                result = {
                    "charts": charts,
                    "remaining_uses": tracker.get_remaining(),
                }
                self.send_json(result)
                return

            recommendation = recommend_chart(
                data_overview=data_overview,
                user_request=user_request,
                api_key=api_key,
                provider=provider,
            )

            charts = []
            recommended = recommendation.get('recommended_charts', [])

            for i, chart_config in enumerate(recommended):
                try:
                    chart_data = self._generate_chart_data(chart_config, data_overview)
                    charts.append({
                        "chart_type": chart_config.get('chart_type', 'bar'),
                        "title": chart_config.get('title', f'Chart {i+1}'),
                        "chart_data": chart_data,
                        "png_data": None,
                        "success": True,
                    })
                except Exception as e:
                    charts.append({
                        "chart_type": chart_config.get('chart_type', 'unknown'),
                        "title": chart_config.get('title', f'Chart {i+1}'),
                        "success": False,
                        "error": str(e),
                    })

            result = {
                "charts": charts,
                "remaining_uses": tracker.get_remaining(),
            }
            self.send_json(result)

        except Exception as e:
            self.send_json({"error": str(e)})

    def _demo_charts(self, data_overview, chart_title):
        """Generate demo charts without AI."""
        cols = data_overview.get('columns', [])
        numeric_cols = [c['name'] for c in cols if c['semantic_type'] == 'numeric']
        cat_cols = [c['name'] for c in cols if c['semantic_type'] == 'categorical']
        x_col = cat_cols[0] if cat_cols else (cols[0]['name'] if cols else 'x')
        y_col = numeric_cols[0] if numeric_cols else 'value'

        # Demo bar chart
        bar_data = {
            "xAxis": {"type": "category", "data": ["Jan", "Feb", "Mar", "Apr", "May"]},
            "yAxis": {"type": "value"},
            "series": [{
                "data": [120, 200, 150, 80, 70],
                "type": "bar",
                "itemStyle": {"color": "#5470c6"}
            }],
            "title": {"text": chart_title or f'{y_col} by {x_col}'},
            "tooltip": {},
        }

        return [{
            "chart_type": "bar",
            "title": chart_title or f'{y_col} by {x_col}',
            "chart_data": bar_data,
            "png_data": None,
            "success": True,
        }]

    def _generate_chart_data(self, chart_config, data_overview):
        """Generate ECharts config from chart recommendation."""
        chart_type = chart_config.get('chart_type', 'bar')
        title_text = chart_config.get('title', 'Chart')
        x_col = chart_config.get('x_axis', '')
        y_cols = chart_config.get('y_axis', [])

        cols = data_overview.get('columns', [])
        preview = data_overview.get('preview', [])

        x_data = [row.get(x_col, '') for row in preview[:10]]
        y_data = [[i, row.get(y_cols[0], 0) if y_cols else 0] for i, row in enumerate(preview[:10])]

        if chart_type == 'bar':
            return {
                "xAxis": {"type": "category", "data": x_data, "name": x_col},
                "yAxis": {"type": "value"},
                "series": [{
                    "data": y_data,
                    "type": "bar",
                    "itemStyle": {"color": "#5470c6"}
                }],
                "title": {"text": title_text},
                "tooltip": {},
            }
        elif chart_type == 'line':
            return {
                "xAxis": {"type": "category", "data": x_data, "name": x_col},
                "yAxis": {"type": "value"},
                "series": [{
                    "data": y_data,
                    "type": "line",
                    "lineStyle": {"color": "#5470c6", "width": 3},
                    "itemStyle": {"color": "#5470c6"},
                }],
                "title": {"text": title_text},
                "tooltip": {},
            }
        elif chart_type == 'pie':
            pie_data = [[str(row.get(x_col, '')), row.get(y_cols[0], 0) if y_cols else 0] for row in preview[:10]]
            return {
                "series": [{
                    "type": "pie",
                    "radius": ["30%", "70%"],
                    "data": pie_data,
                    "label": {"formatter": "{b}: {d}%"},
                }],
                "title": {"text": title_text},
                "tooltip": {},
            }
        else:
            return {
                "xAxis": {"type": "category", "data": x_data},
                "yAxis": {"type": "value"},
                "series": [{"data": y_data, "type": chart_type}],
                "title": {"text": title_text},
            }

    def send_json(self, data):
        """Send JSON response."""
        body = json.dumps(data, ensure_ascii=False).encode()
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', len(body))
        self.end_headers()
        self.wfile.write(body)


class UsageTracker:
    """Track usage for FREE tier."""

    def __init__(self, storage_path: str = os.path.join(BASE_DIR, "usage.json")):
        self.storage_path = storage_path
        os.makedirs(os.path.dirname(storage_path), exist_ok=True)
        self._load()

    def _load(self):
        if os.path.exists(self.storage_path):
            with open(self.storage_path, "r") as f:
                self.data = json.load(f)
        else:
            self.data = {"used": 0, "total": FREE_USES_LIMIT}

    def _save(self):
        with open(self.storage_path, "w") as f:
            json.dump(self.data, f)

    def check_and_increment(self) -> bool:
        if self.data["used"] >= self.data["total"]:
            return False
        self.data["used"] += 1
        self._save()
        return True

    def get_remaining(self) -> int:
        return max(0, self.data["total"] - self.data["used"])


def run_server(port: int = 8080):
    """Run the web server."""
    os.makedirs(BASE_DIR, exist_ok=True)
    handler = DashboardHandler
    server = HTTPServer(('0.0.0.0', port), handler)
    print(f"Smart Dashboard Generator running at http://localhost:{port}")
    print("Press Ctrl+C to stop")
    server.serve_forever()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8080)
    args = parser.parse_args()
    run_server(args.port)
