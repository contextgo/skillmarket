# chart_renderer.py - Chart Renderer using pyecharts
"""Render charts to PNG using pyecharts + screenshot."""

import os
import subprocess
from typing import Dict, Any, List, Optional

from pyecharts import options as opts
from pyecharts.charts import Bar, Line, Pie, Scatter, HeatMap, Radar, Gauge, Funnel
from pyecharts.globals import ThemeType

from .config import OUTPUT_DIR, DEFAULT_COLORS


class ChartRenderer:
    """Render chart configurations to PNG images."""

    def __init__(self, output_dir: str = OUTPUT_DIR):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)

    def _load_data(self, data_mapping: Dict[str, Any], file_path: str) -> Dict[str, Any]:
        """Load actual data for chart rendering."""
        from .file_parser import FileParser
        parser = FileParser()
        parser.parse(file_path)

        x_col = data_mapping.get("x_column", "")
        y_cols = data_mapping.get("y_columns", [])

        return parser.get_data_for_chart(x_col, y_cols)

    def render(
        self,
        chart_config: Dict[str, Any],
        data_overview: Dict[str, Any],
        file_path: str,
        output_name: str,
    ) -> str:
        """Render a single chart to PNG."""
        chart_type = chart_config.get("chart_type", "bar")
        title = chart_config.get("title", "Chart")
        style = chart_config.get("style", {})

        # Build data_mapping from chart_config (handles both formats)
        data_mapping = chart_config.get("data_mapping", {})
        if not data_mapping:
            # Fallback: use x_axis and y_axis directly
            x_col = chart_config.get("x_axis", "")
            y_cols = chart_config.get("y_axis", [])
            data_mapping = {"x_column": x_col, "y_columns": y_cols}

        # Load actual data
        data = self._load_data(data_mapping, file_path)

        # Render based on chart type
        if chart_type == "bar":
            chart = self._render_bar(title, data, data_mapping, style)
        elif chart_type == "line":
            chart = self._render_line(title, data, data_mapping, style)
        elif chart_type == "pie":
            chart = self._render_pie(title, data, data_mapping, style)
        elif chart_type == "scatter":
            chart = self._render_scatter(title, data, data_mapping, style)
        elif chart_type == "heatmap":
            chart = self._render_heatmap(title, data, data_mapping, style)
        elif chart_type == "radar":
            chart = self._render_radar(title, data, data_mapping, style)
        elif chart_type == "gauge":
            chart = self._render_gauge(title, data, data_mapping, style)
        elif chart_type == "funnel":
            chart = self._render_funnel(title, data, data_mapping, style)
        else:
            chart = self._render_bar(title, data, data_mapping, style)

        # Save HTML
        html_path = os.path.join(self.output_dir, f"{output_name}.html")
        chart.render(html_path)

        # Convert to PNG using screenshot
        png_path = os.path.join(self.output_dir, f"{output_name}.png")
        png_created = self._html_to_png(html_path, png_path)

        if png_created:
            return png_path
        else:
            return html_path

    def _html_to_png(self, html_path: str, png_path: str):
        """Convert HTML to PNG using puppeteer or chromium."""
        try:
            # Try using puppeteer
            script = f"""
const {{ chromium }} = require('puppeteer');
(async () => {{
  const browser = await chromium.launch();
  const page = await browser.newPage();
  await page.setViewport({{ width: 1200, height: 800 }});
  await page.goto('file://{html_path}', {{ waitUntil: 'networkidle0' }});
  await page.screenshot({{ path: '{png_path}', fullPage: true }});
  await browser.close();
}})();
"""
            script_path = os.path.join(self.output_dir, "_screenshot.js")
            with open(script_path, "w") as f:
                f.write(script)
            subprocess.run(["node", script_path], check=True, capture_output=True, timeout=60)
            os.remove(script_path)
        except (subprocess.CalledProcessError, FileNotFoundError):
            # PNG conversion failed
            return False
        return True

    def _render_bar(
        self,
        title: str,
        data: Dict[str, Any],
        data_mapping: Dict[str, Any],
        style: Dict[str, Any],
    ) -> Bar:
        """Render bar chart."""
        x_data = data.get("x", [])
        y_keys = [k for k in data.keys() if k != "x"]

        chart = Bar(init_opts=opts.InitOpts(theme=ThemeType.LIGHT, width="1200px", height="800px"))
        chart.add_xaxis(x_data)

        colors = style.get("color", DEFAULT_COLORS[0])
        for i, y_key in enumerate(y_keys):
            color = DEFAULT_COLORS[i % len(DEFAULT_COLORS)] if isinstance(colors, list) else colors
            chart.add_yaxis(
                y_key,
                data.get(y_key, []),
                itemstyle_opts=opts.ItemStyleOpts(color=color),
            )

        chart.set_global_opts(
            title_opts=opts.TitleOpts(title=title),
            legend_opts=opts.LegendOpts(is_show=True),
            tooltip_opts=opts.TooltipOpts(trigger="axis"),
            xaxis_opts=opts.AxisOpts(name=data_mapping.get("x_column", "")),
            yaxis_opts=opts.AxisOpts(name=""),
        )

        return chart

    def _render_line(
        self,
        title: str,
        data: Dict[str, Any],
        data_mapping: Dict[str, Any],
        style: Dict[str, Any],
    ) -> Line:
        """Render line chart."""
        x_data = data.get("x", [])
        y_keys = [k for k in data.keys() if k != "x"]

        chart = Line(init_opts=opts.InitOpts(theme=ThemeType.LIGHT, width="1200px", height="800px"))
        chart.add_xaxis(x_data)

        for i, y_key in enumerate(y_keys):
            color = DEFAULT_COLORS[i % len(DEFAULT_COLORS)]
            chart.add_yaxis(
                y_key,
                data.get(y_key, []),
                linestyle_opts=opts.LineStyleOpts(color=color, width=3),
                itemstyle_opts=opts.ItemStyleOpts(color=color),
            )

        chart.set_global_opts(
            title_opts=opts.TitleOpts(title=title),
            legend_opts=opts.LegendOpts(is_show=True),
            tooltip_opts=opts.TooltipOpts(trigger="axis"),
            xaxis_opts=opts.AxisOpts(name=data_mapping.get("x_column", "")),
            yaxis_opts=opts.AxisOpts(name=""),
            datazoom_opts=opts.DataZoomOpts(),
        )

        return chart

    def _render_pie(
        self,
        title: str,
        data: Dict[str, Any],
        data_mapping: Dict[str, Any],
        style: Dict[str, Any],
    ) -> Pie:
        """Render pie chart."""
        # For pie, use first numeric column
        y_keys = [k for k in data.keys() if k != "x"]
        if not y_keys:
            y_keys = list(data.keys())

        values = data.get(y_keys[0], []) if y_keys else []
        x_data = data.get("x", [])

        pairs = list(zip(x_data, values))
        pairs = [(str(k), v) for k, v in pairs if v is not None and str(v) != "nan"]

        chart = Pie(init_opts=opts.InitOpts(theme=ThemeType.LIGHT, width="1200px", height="800px"))
        chart.add(
            series_name="",
            data_pair=pairs,
            radius=["30%", "70%"],
            label_opts=opts.LabelOpts(formatter="{b}: {d}%"),
        )
        chart.set_colors(DEFAULT_COLORS)

        chart.set_global_opts(
            title_opts=opts.TitleOpts(title=title),
            legend_opts=opts.LegendOpts(is_show=True, orient="vertical", pos_left="left"),
        )

        return chart

    def _render_scatter(
        self,
        title: str,
        data: Dict[str, Any],
        data_mapping: Dict[str, Any],
        style: Dict[str, Any],
    ) -> Scatter:
        """Render scatter chart."""
        y_keys = [k for k in data.keys() if k != "x"]
        x_data = data.get("x", [])
        y_data = data.get(y_keys[0], []) if y_keys else []

        # Pair x and y
        scatter_data = [[x_data[i], y_data[i]] for i in range(len(x_data)) if i < len(y_data)]

        chart = Scatter(init_opts=opts.InitOpts(theme=ThemeType.LIGHT, width="1200px", height="800px"))
        chart.add_xaxis(x_data)
        chart.add_yaxis(
            y_keys[0] if y_keys else "value",
            scatter_data,
            itemstyle_opts=opts.ItemStyleOpts(color=DEFAULT_COLORS[0]),
        )

        chart.set_global_opts(
            title_opts=opts.TitleOpts(title=title),
            legend_opts=opts.LegendOpts(is_show=True),
            tooltip_opts=opts.TooltipOpts(formatter="{c}"),
            xaxis_opts=opts.AxisOpts(name=data_mapping.get("x_column", "")),
            yaxis_opts=opts.AxisOpts(name=y_keys[0] if y_keys else ""),
        )

        return chart

    def _render_heatmap(
        self,
        title: str,
        data: Dict[str, Any],
        data_mapping: Dict[str, Any],
        style: Dict[str, Any],
    ) -> HeatMap:
        """Render heatmap chart."""
        # Simplified heatmap: use numeric columns as dimensions
        x_data = data.get("x", [])
        y_keys = [k for k in data.keys() if k != "x"]

        heatmap_data = []
        for i, y_key in enumerate(y_keys):
            y_values = data.get(y_key, [])
            for j, val in enumerate(y_values):
                if j < len(x_data):
                    heatmap_data.append([j, i, val])

        chart = HeatMap(init_opts=opts.InitOpts(theme=ThemeType.LIGHT, width="1200px", height="800px"))
        chart.add_xaxis(x_data)
        chart.add_yaxis("value", y_keys, heatmap_data)

        chart.set_global_opts(
            title_opts=opts.TitleOpts(title=title),
            visualmap_opts=opts.VisualMapOpts(),
            xaxis_opts=opts.AxisOpts(name=data_mapping.get("x_column", ""), type="category"),
            yaxis_opts=opts.AxisOpts(type="category"),
        )

        return chart

    def _render_radar(
        self,
        title: str,
        data: Dict[str, Any],
        data_mapping: Dict[str, Any],
        style: Dict[str, Any],
    ) -> Radar:
        """Render radar chart."""
        y_keys = [k for k in data.keys() if k != "x"]
        if not y_keys:
            return self._render_bar(title, data, data_mapping, style)

        # Average values for each dimension
        x_data = data.get("x", [])
        values = []
        for y_key in y_keys:
            y_values = data.get(y_key, [])
            valid = [v for v in y_values if v is not None and str(v) != "nan"]
            values.append(sum(valid) / len(valid) if valid else 0)

        chart = Radar(init_opts=opts.InitOpts(theme=ThemeType.LIGHT, width="1200px", height="800px"))
        chart.add_schema(schema=[
            opts.RadarIndicatorItem(name=n, max_=max(values) * 1.2 if max(values) > 0 else 100)
            for n in x_data
        ])
        chart.add("value", [values], areastyle_opts=opts.AreaStyleOpts(opacity=0.3))

        chart.set_global_opts(
            title_opts=opts.TitleOpts(title=title),
            legend_opts=opts.LegendOpts(is_show=True),
        )

        return chart

    def _render_gauge(
        self,
        title: str,
        data: Dict[str, Any],
        data_mapping: Dict[str, Any],
        style: Dict[str, Any],
    ) -> Gauge:
        """Render gauge chart."""
        y_keys = [k for k in data.keys() if k != "x"]
        y_values = data.get(y_keys[0], []) if y_keys else []
        value = y_values[0] if y_values else 0

        chart = Gauge(init_opts=opts.InitOpts(theme=ThemeType.LIGHT, width="1200px", height="800px"))
        chart.add(
            series_name=title,
            data_pair=[["value", value]],
            detail_label_opts=opts.GaugeDetailOpts(formatter="{value}"),
        )

        chart.set_global_opts(
            title_opts=opts.TitleOpts(title=title),
        )

        return chart

    def _render_funnel(
        self,
        title: str,
        data: Dict[str, Any],
        data_mapping: Dict[str, Any],
        style: Dict[str, Any],
    ) -> Funnel:
        """Render funnel chart."""
        x_data = data.get("x", [])
        y_keys = [k for k in data.keys() if k != "x"]
        values = data.get(y_keys[0], []) if y_keys else []

        pairs = list(zip([str(x) for x in x_data], values))
        pairs = [(k, v) for k, v in pairs if v is not None and str(v) != "nan"]

        chart = Funnel(init_opts=opts.InitOpts(theme=ThemeType.LIGHT, width="1200px", height="800px"))
        chart.add(
            series_name=title,
            data_pair=pairs,
            label_opts=opts.LabelOpts(formatter="{b}: {c}"),
        )
        chart.set_colors(DEFAULT_COLORS)

        chart.set_global_opts(
            title_opts=opts.TitleOpts(title=title),
            legend_opts=opts.LegendOpts(is_show=True),
        )

        return chart


def render_chart(
    chart_config: Dict[str, Any],
    data_overview: Dict[str, Any],
    file_path: str,
    output_name: str,
) -> str:
    """Convenience function to render a chart to PNG."""
    renderer = ChartRenderer()
    return renderer.render(chart_config, data_overview, file_path, output_name)
