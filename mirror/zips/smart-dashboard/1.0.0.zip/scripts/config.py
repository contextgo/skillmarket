# config.py - Smart Dashboard Generator Configuration
"""Configuration for Smart Dashboard Generator."""

import os

# Base paths - all file operations use /tmp/ only
BASE_DIR = "/tmp/smart-dashboard"
DATA_DIR = os.path.join(BASE_DIR, "data")
OUTPUT_DIR = os.path.join(BASE_DIR, "output")

# Ensure directories exist
for d in [BASE_DIR, DATA_DIR, OUTPUT_DIR]:
    os.makedirs(d, exist_ok=True)

# Row limits per tier
ROW_LIMITS = {
    "FREE": 500,
    "STANDARD": 10_000,
    "PRO": 100_000,
    "ENTERPRISE": float("inf"),
}

# Chart types supported
CHART_TYPES = [
    "bar",
    "line",
    "pie",
    "scatter",
    "heatmap",
    "radar",
    "gauge",
    "funnel",
]

# AI API endpoint mappings
AI_PROVIDERS = {
    "openai": "https://api.openai.com/v1/chat/completions",
    "claude": "https://api.anthropic.com/v1/messages",
    "zhipu": "https://open.bigmodel.cn/api/paas/v4/chat/completions",
    "minimax": "https://api.minimax.chat/v1/text/chatcompletion_v2",
}

# Default chart colors
DEFAULT_COLORS = [
    "#5470c6", "#91cc75", "#fac858", "#ee6666", "#73c0de",
    "#3ba272", "#fc8452", "#9a60b4", "#ea7ccc",
]

# Preview rows for data
PREVIEW_ROWS = 20

# Usage limits
FREE_USES_LIMIT = 10
