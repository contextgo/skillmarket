# main.py - Smart Dashboard Generator CLI Entry Point
"""Main CLI for Smart Dashboard Generator."""

import argparse
import json
import os
import sys
import uuid
from typing import Optional, Dict, Any

from .file_parser import parse_file, FileParser
from .chart_recommender import recommend_chart
from .chart_renderer import render_chart
from .config import BASE_DIR, DATA_DIR, OUTPUT_DIR, FREE_USES_LIMIT, ROW_LIMITS


class UsageTracker:
    """Track usage count for FREE tier."""

    def __init__(self, storage_path: str = os.path.join(BASE_DIR, "usage.json")):
        self.storage_path = storage_path
        os.makedirs(os.path.dirname(storage_path), exist_ok=True)
        self._load()

    def _load(self):
        """Load usage data."""
        if os.path.exists(self.storage_path):
            with open(self.storage_path, "r") as f:
                self.data = json.load(f)
        else:
            self.data = {"used": 0, "total": FREE_USES_LIMIT}

    def _save(self):
        """Save usage data."""
        with open(self.storage_path, "w") as f:
            json.dump(self.data, f)

    def check_and_increment(self) -> bool:
        """Check if usage available, increment if so. Returns True if allowed."""
        if self.data["used"] >= self.data["total"]:
            return False
        self.data["used"] += 1
        self._save()
        return True

    def get_remaining(self) -> int:
        """Get remaining uses."""
        return max(0, self.data["total"] - self.data["used"])

    def reset(self):
        """Reset usage (for testing)."""
        self.data["used"] = 0
        self._save()


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(description="Smart Dashboard Generator")
    subparsers = parser.add_subparsers(dest="command", help="Commands")

    # Parse command
    parse_sp = subparsers.add_parser("parse", help="Parse a data file")
    parse_sp.add_argument("file", help="Path to CSV or Excel file")
    parse_sp.add_argument("--max-rows", type=int, default=ROW_LIMITS["FREE"], help="Max rows to process")

    # Recommend command
    recommend_sp = subparsers.add_parser("recommend", help="Get AI chart recommendation")
    recommend_sp.add_argument("file", help="Path to CSV or Excel file")
    recommend_sp.add_argument("--request", "-r", required=True, help="User request in natural language")
    recommend_sp.add_argument("--api-key", "-k", required=True, help="AI API Key")
    recommend_sp.add_argument("--provider", "-p", default="openai", help="AI provider (openai/claude/zhipu/minimax)")
    recommend_sp.add_argument("--model", "-m", help="Specific model to use")

    # Render command
    render_sp = subparsers.add_parser("render", help="Render chart to PNG")
    render_sp.add_argument("file", help="Path to CSV or Excel file")
    render_sp.add_argument("--config", "-c", required=True, help="Chart config JSON file")
    render_sp.add_argument("--output", "-o", help="Output PNG path")

    # Full pipeline
    pipeline_sp = subparsers.add_parser("generate", help="Full pipeline: parse + recommend + render")
    pipeline_sp.add_argument("file", help="Path to CSV or Excel file")
    pipeline_sp.add_argument("--request", "-r", required=True, help="User request in natural language")
    pipeline_sp.add_argument("--api-key", "-k", default=None, help="AI API Key (optional, uses fallback if not provided)")
    pipeline_sp.add_argument("--provider", "-p", default="openai", help="AI provider")
    pipeline_sp.add_argument("--model", "-m", help="Specific model")
    pipeline_sp.add_argument("--tier", "-t", default="FREE", help="Tier (FREE/STANDARD/PRO/ENTERPRISE)")
    pipeline_sp.add_argument("--output-dir", "-d", help="Output directory")

    args = parser.parse_args()

    if args.command == "parse":
        handle_parse(args)
    elif args.command == "recommend":
        handle_recommend(args)
    elif args.command == "render":
        handle_render(args)
    elif args.command == "generate":
        handle_generate(args)
    else:
        parser.print_help()
        sys.exit(1)


def handle_parse(args):
    """Handle parse command."""
    try:
        tracker = UsageTracker()
        if not tracker.check_and_increment():
            print(json.dumps({
                "error": "FREE tier exhausted",
                "remaining": 0,
                "limit": FREE_USES_LIMIT,
            }))
            sys.exit(1)

        parser = FileParser(max_rows=args.max_rows)
        overview = parser.parse(args.file)
        overview["remaining_uses"] = tracker.get_remaining()

        print(json.dumps(overview, ensure_ascii=False, indent=2))
    except Exception as e:
        print(json.dumps({"error": str(e)}))
        sys.exit(1)


def handle_recommend(args):
    """Handle recommend command."""
    try:
        tracker = UsageTracker()
        if not tracker.check_and_increment():
            print(json.dumps({
                "error": "FREE tier exhausted",
                "remaining": 0,
            }))
            sys.exit(1)

        parser = FileParser()
        overview = parser.parse(args.file)

        recommendation = recommend_chart(
            data_overview=overview,
            user_request=args.request,
            api_key=args.api_key,
            provider=args.provider,
            model=args.model,
        )

        result = {
            "recommendation": recommendation,
            "remaining_uses": tracker.get_remaining(),
        }

        print(json.dumps(result, ensure_ascii=False, indent=2))
    except Exception as e:
        print(json.dumps({"error": str(e)}))
        sys.exit(1)


def handle_render(args):
    """Handle render command."""
    try:
        tracker = UsageTracker()
        if not tracker.check_and_increment():
            print(json.dumps({
                "error": "FREE tier exhausted",
                "remaining": 0,
            }))
            sys.exit(1)

        with open(args.config, "r") as f:
            config = json.load(f)

        parser = FileParser()
        overview = parser.parse(args.file)

        output_name = args.output or f"chart_{uuid.uuid4().hex[:8]}"
        png_path = render_chart(
            chart_config=config,
            data_overview=overview,
            file_path=args.file,
            output_name=output_name,
        )

        result = {
            "png_path": png_path,
            "remaining_uses": tracker.get_remaining(),
        }

        print(json.dumps(result, ensure_ascii=False, indent=2))
    except Exception as e:
        print(json.dumps({"error": str(e)}))
        sys.exit(1)


def handle_generate(args):
    """Handle full pipeline: parse + recommend + render."""
    try:
        tracker = UsageTracker()
        if not tracker.check_and_increment():
            print(json.dumps({
                "error": "FREE tier exhausted",
                "remaining": 0,
                "limit": FREE_USES_LIMIT,
            }))
            sys.exit(1)

        tier_limit = ROW_LIMITS.get(args.tier.upper(), ROW_LIMITS["FREE"])
        parser = FileParser(max_rows=tier_limit)
        overview = parser.parse(args.file)

        # Use AI recommendation if API key provided, otherwise use fallback
        if args.api_key:
            recommendation = recommend_chart(
                data_overview=overview,
                user_request=args.request,
                api_key=args.api_key,
                provider=args.provider,
                model=args.model,
            )
        else:
            # Use fallback recommendation (no AI)
            from .chart_recommender import ChartRecommender
            recommender = ChartRecommender("", "openai")
            recommendation = recommender.recommend(overview, args.request)

        output_dir = args.output_dir or OUTPUT_DIR
        os.makedirs(output_dir, exist_ok=True)

        charts = []
        recommended = recommendation.get("recommended_charts", [])

        for i, chart_config in enumerate(recommended):
            output_name = f"chart_{uuid.uuid4().hex[:8]}_{i}"
            try:
                png_path = render_chart(
                    chart_config=chart_config,
                    data_overview=overview,
                    file_path=args.file,
                    output_name=output_name,
                )
                charts.append({
                    "chart_type": chart_config.get("chart_type", "unknown"),
                    "title": chart_config.get("title", ""),
                    "png_path": png_path,
                    "success": True,
                })
            except Exception as e:
                charts.append({
                    "chart_type": chart_config.get("chart_type", "unknown"),
                    "title": chart_config.get("title", ""),
                    "png_path": None,
                    "success": False,
                    "error": str(e),
                })

        result = {
            "data_overview": {
                "file_name": overview["file_name"],
                "total_rows": overview["total_rows"],
                "total_columns": overview["total_columns"],
            },
            "recommendation": recommendation,
            "charts": charts,
            "remaining_uses": tracker.get_remaining(),
        }

        print(json.dumps(result, ensure_ascii=False, indent=2))
    except Exception as e:
        print(json.dumps({"error": str(e)}))
        sys.exit(1)


if __name__ == "__main__":
    main()
