# chart_recommender.py - AI Chart Type Recommender
"""Use AI to recommend best chart types based on data structure."""

import json
import requests
from typing import Dict, Any, List, Optional

from .config import AI_PROVIDERS, CHART_TYPES


class ChartRecommender:
    """AI-powered chart type recommendation."""

    def __init__(self, api_key: str, provider: str = "openai", model: Optional[str] = None):
        self.api_key = api_key
        self.provider = provider.lower()
        self.model = model or self._default_model()
        self.base_url = AI_PROVIDERS.get(self.provider, AI_PROVIDERS["openai"])

    def _default_model(self) -> str:
        """Get default model for provider."""
        defaults = {
            "openai": "gpt-4o",
            "claude": "claude-3-5-sonnet-20241022",
            "zhipu": "glm-4-flash",
            "minimax": "MiniMax-Text-01",
        }
        return defaults.get(self.provider, "gpt-4o")

    def _build_prompt(self, data_overview: Dict[str, Any], user_request: str) -> str:
        """Build prompt for chart recommendation."""
        columns = data_overview.get("columns", [])
        preview = data_overview.get("preview", [])

        col_desc = "\n".join([
            f"- {c['name']}: {c['semantic_type']} ({c['dtype']})"
            for c in columns
        ])

        preview_sample = json.dumps(preview[:3], ensure_ascii=False, indent=2)

        return (
            "You are a data visualization expert. Given a dataset and a user's request, recommend the best chart types.\n\n"
            f"Dataset Overview:\n"
            f"- Total rows: {data_overview['total_rows']}\n"
            f"- Columns ({len(columns)}):\n"
            f"{col_desc}\n\n"
            "Preview data (first 3 rows):\n"
            f"{preview_sample}\n\n"
            "User request: \"" + user_request + "\"\n\n"
            "Available chart types: " + ", ".join(CHART_TYPES) + "\n\n"
            "Respond with a JSON object:\n"
            "{{\n"
            '  "recommended_charts": [\n'
            '    {{\n'
            '      "chart_type": "bar|line|pie|scatter|heatmap|radar|gauge|funnel",\n'
            '      "title": "Chart title in English",\n'
            '      "x_axis": "column name for x-axis",\n'
            '      "y_axis": ["list of column names for y-axis"],\n'
            '      "reason": "why this chart type is recommended",\n'
            '      "style": {{"color": "#5470c6", ...}}\n'
            '    }}\n'
            '  ],\n'
            '  "data_mapping": {{\n'
            '    "x_column": "column name",\n'
            '    "y_columns": ["list of columns"]\n'
            '  }}\n'
            "}}\n\n"
            "Rules:\n"
            "- Return 1-3 chart recommendations\n"
            "- For trend/time data, prefer line chart\n"
            "- For category comparisons, prefer bar chart\n"
            "- For composition/proportion, prefer pie chart\n"
            "- For relationships between two numeric variables, prefer scatter\n"
            "- Output valid JSON only, no markdown code blocks\n"
        )

    def _call_ai(self, prompt: str) -> str:
        """Call AI API and return response text."""
        if self.provider == "openai":
            return self._call_openai(prompt)
        elif self.provider == "claude":
            return self._call_claude(prompt)
        elif self.provider == "zhipu":
            return self._call_zhipu(prompt)
        elif self.provider == "minimax":
            return self._call_minimax(prompt)
        else:
            raise ValueError(f"Unsupported provider: {self.provider}")

    def _call_openai(self, prompt: str) -> str:
        """Call OpenAI API."""
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": self.model,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.3,
        }
        resp = requests.post(
            f"{self.base_url}",
            headers=headers,
            json=payload,
            timeout=30,
        )
        resp.raise_for_status()
        return resp.json()["choices"][0]["message"]["content"]

    def _call_claude(self, prompt: str) -> str:
        """Call Claude API."""
        headers = {
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
            "Content-Type": "application/json",
        }
        payload = {
            "model": self.model,
            "max_tokens": 1024,
            "messages": [{"role": "user", "content": prompt}],
        }
        resp = requests.post(
            f"{self.base_url}",
            headers=headers,
            json=payload,
            timeout=30,
        )
        resp.raise_for_status()
        return resp.json()["content"][0]["text"]

    def _call_zhipu(self, prompt: str) -> str:
        """Call Zhipu (GLM) API."""
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": self.model,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.3,
        }
        resp = requests.post(
            f"{self.base_url}",
            headers=headers,
            json=payload,
            timeout=30,
        )
        resp.raise_for_status()
        return resp.json()["choices"][0]["message"]["content"]

    def _call_minimax(self, prompt: str) -> str:
        """Call MiniMax API."""
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": self.model,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.3,
        }
        resp = requests.post(
            f"{self.base_url}",
            headers=headers,
            json=payload,
            timeout=30,
        )
        resp.raise_for_status()
        data = resp.json()
        return data["choices"][0]["text"] if "text" in data["choices"][0] else data["choices"][0]["message"]["content"]

    def recommend(
        self,
        data_overview: Dict[str, Any],
        user_request: str,
    ) -> Dict[str, Any]:
        """Get chart recommendation from AI."""
        # If no API key, use fallback
        if not self.api_key:
            return self._fallback_recommendation(data_overview)

        prompt = self._build_prompt(data_overview, user_request)
        response = self._call_ai(prompt)

        # Parse JSON from response
        try:
            # Try to extract JSON from response
            json_str = response.strip()
            if json_str.startswith("```"):
                json_str = json_str.split("```")[1]
                if json_str.startswith("json"):
                    json_str = json_str[4:]
            return json.loads(json_str)
        except json.JSONDecodeError:
            # Return fallback
            return self._fallback_recommendation(data_overview)

    def _fallback_recommendation(self, data_overview: Dict[str, Any]) -> Dict[str, Any]:
        """Fallback recommendation when AI parsing fails."""
        columns = data_overview.get("columns", [])
        numeric_cols = [c["name"] for c in columns if c["semantic_type"] == "numeric"]
        categorical_cols = [c["name"] for c in columns if c["semantic_type"] == "categorical"]
        datetime_cols = [c["name"] for c in columns if c["semantic_type"] == "datetime"]

        x_col = datetime_cols[0] if datetime_cols else (categorical_cols[0] if categorical_cols else columns[0]["name"] if columns else "")
        y_col = numeric_cols[:3] if numeric_cols else []

        chart_type = "line" if datetime_cols else "bar"

        return {
            "recommended_charts": [{
                "chart_type": chart_type,
                "title": f"{y_col[0] if y_col else 'Data'} by {x_col}",
                "x_axis": x_col,
                "y_axis": y_col,
                "reason": "Auto-selected based on data structure",
            }],
            "data_mapping": {
                "x_column": x_col,
                "y_columns": y_col,
            },
        }


def recommend_chart(
    data_overview: Dict[str, Any],
    user_request: str,
    api_key: str,
    provider: str = "openai",
    model: Optional[str] = None,
) -> Dict[str, Any]:
    """Convenience function for chart recommendation."""
    recommender = ChartRecommender(api_key, provider, model)
    return recommender.recommend(data_overview, user_request)
