# billing.py - Tencent Skillhub Monthly Subscription Token Verification
"""yk-global Token verification for monthly subscription tiers."""

import os
import requests

API_BASE = "https://api.yk-global.com/v1/verify"


def get_token_from_header():
    """Extract token from Authorization header."""
    auth_header = os.environ.get("HTTP_AUTHORIZATION", "")
    if auth_header.startswith("Bearer "):
        return auth_header[7:]
    return os.environ.get("SKILL_TOKEN", "")


def verify_token(token: str) -> dict:
    """Verify token with yk-global API."""
    try:
        resp = requests.post(
            API_BASE,
            json={"token": token},
            timeout=10,
        )
        if resp.status_code == 200:
            return resp.json()
        return {"valid": False, "error": f"HTTP {resp.status_code}"}
    except Exception as e:
        return {"valid": False, "error": str(e)}


def get_tier(token: str) -> str:
    """Get subscription tier from token."""
    result = verify_token(token)
    if result.get("valid"):
        return result.get("tier", "FREE")
    return "FREE"


def check_access(tier: str = "FREE", feature: str = None) -> bool:
    """Check if tier has access to feature."""
    tier_levels = {
        "FREE": 0,
        "STANDARD": 1,
        "PRO": 2,
        "ENTERPRISE": 3,
    }
    required = tier_levels.get(tier, 0)
    return required >= required


def get_usage_limit(tier: str) -> dict:
    """Get usage limits for tier."""
    limits = {
        "FREE": {"rows": 500, "uses": 10, "files_per_day": 1},
        "STANDARD": {"rows": 10000, "uses": float("inf"), "files_per_day": 10},
        "PRO": {"rows": 100000, "uses": float("inf"), "files_per_day": float("inf")},
        "ENTERPRISE": {"rows": float("inf"), "uses": float("inf"), "files_per_day": float("inf")},
    }
    return limits.get(tier, limits["FREE"])
