# Smart Dashboard Generator 智能仪表盘生成器

## 一句话简介

上传 CSV/Excel，用自然语言描述需求，AI 自动生成专业图表。

## 功能清单

### 核心功能
- 📁 文件上传：支持 CSV、Excel（.xlsx/.xls）自动解析
- 🤖 AI 图表推荐：根据数据特征自动推荐最佳图表类型
- 🎨 多图表生成：单次请求生成多个相关图表
- 📥 PNG 导出：下载高清图表图片
- 📊 数据概览：显示行列数、列名、数据类型

### 支持图表类型
- 柱状图 (Bar) - 分类对比
- 折线图 (Line) - 趋势变化
- 饼图 (Pie) - 占比构成
- 散点图 (Scatter) - 关联关系
- 热力图 (HeatMap) - 密度分布
- 雷达图 (Radar) - 多维对比
- 仪表盘 (Gauge) - 指标展示
- 漏斗图 (Funnel) - 转化漏斗

## 使用流程

1. **上传数据文件** → CSV 或 Excel 文件
2. **描述需求** → 用自然语言描述想要的图表
3. **AI 推荐** → 获取最佳图表类型推荐
4. **下载图表** → 导出 PNG 格式图片

## 示例命令

```bash
# 解析文件
python main.py parse data.csv

# 获取 AI 推荐
python main.py recommend data.csv --request "显示每月销售额趋势" --api-key YOUR_KEY

# 完整流程
python main.py generate data.csv --request "显示每月销售额趋势" --api-key YOUR_KEY
```

## 套餐说明

| 套餐 | 价格 | 数据行数 | 图表类型 |
|------|------|---------|---------|
| FREE | 免费 | 500行 | 5种基础 |
| Standard | ¥29/月 | 10,000行 | 全部 |
| Pro | ¥99/月 | 100,000行 | 全部 + 多图表 |
| Enterprise | ¥299/月 | 无限制 | 全功能 + API |

**FREE 套餐共 10 次体验（非每月），适合初次体验。**

## 技术栈

- 数据解析：pandas
- 图表渲染：Apache ECharts (pyecharts)
- AI 推荐：用户自带 API Key（支持 OpenAI/Claude/GLM/MiniMax）

## 适用人群

- 运营/市场人员：定期制作数据报告
- 财务/行政人员：月报/年报可视化
- 中小微企业主：快速生成汇报图表
- 销售团队：业绩数据可视化展示
- 数据爱好者：探索数据规律

## 注意事项

- 所有数据仅在本地处理，不上传服务器
- 建议数据文件小于 10MB
- AI 功能需要用户提供自己的 API Key
- FREE 套餐限制 500 行数据
