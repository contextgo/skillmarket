---
name: MBTI 人格探索
version: 2.1.0
description: 基于 MBTI 93题完整版的专业人格测评 Skill，支持翻页式自助测验和对话式引导双模式，生成包含四维度分析、雷达图、认知功能栈和深度解读的可视化 HTML 报告。
author: SelfDiscovery Team
license: MIT
tags: [MBTI, personality, psychology, self-discovery, assessment, 93-questions]
trigger:
  keywords:
    - "测一下我的MBTI"
    - "做个MBTI测试"
    - "MBTI测评"
    - "人格测试"
    - "性格测试"
    - "我是什么人格"
    - "MBTI人格探索"
    - "性格分析"
    - "人格类型"
    - "我是哪种MBTI"
    - "帮我测MBTI"
    - "MBTI 93题"
---

# MBTI 人格探索

> **这不是一场考试，而是一次了解自己的机会。**
>
> 基于 MBTI-M 量表 **93 题完整版**，支持**翻页式自助测验**和**对话式引导**双模式，
> 最终产出专业级可视化 HTML 报告 + Agent 个性化解读。

## 📁 文件结构

```
mbti-assessment/
├── SKILL.md                    ← 你正在看的文件（Skill 定义入口）
├── _meta.json                  ← Skill 元数据（名称/版本/标签等）
├── README.md                   ← 安装与使用说明
├── scripts/                    ← ★ 核心运行文件（全部必需）
│   ├── SKILL.md                ← 完整 SOP + 话术 + 技术文档
│   ├── mbti_quiz.html          ← ⭐ 翻页式自助测验页面（内嵌93题+计分+报告）
│   ├── mbti_93_questions.json  ← 93道纯题目（供 Agent 展示）
│   ├── mbti_93_full.json       ← 题目+计分规则合一（v2已修正）
│   ├── mbti_93_scoring_rules.json ← 独立计分规则（v2已修正）
│   ├── mbti_16_types.json      ← 16种人格详细描述（9字段×16种）
│   ├── mbti_scoring_engine.js  ← Node.js 计分引擎
│   ├── mbti_report_generator.js← HTML 报告生成器（独立输出）
│   ├── mbti_report.html        ← 内嵌预览模板（备用）
│   └── package.json            ← Node.js 项目配置
└── references/                 ← 参考资料（非运行必需）
    ├── 三方对比分析.md         ← 与现有两个MBTI Skill的对比报告
    ├── 16种汇总.pdf            ← 原始资料：16种人格汇总
    └── MBTI测评－Excel M量表－93题自测版-Final.xls ← 原始量表
```

## 🎯 核心特性

| 特性 | 说明 |
|------|------|
| **双模式交互** | 翻页式自助测验页面（推荐）+ Agent 对话式引导 |
| **93题完整版** | 比市面上常见简化版多3-4倍题目量，结果更精准 |
| **翻页式页面** | 每页10题、导航回退、进度条、状态记忆、即时报告 |
| **可视化HTML报告** | 四维度条形图 + 八维雷达图 + 认知功能栈 + 深度解读 |
| **个性化Agent解读** | 结合用户实际答题数据给出定制化分析 |
| **交叉验证通过** | 计分规则经独立验证（全A→ISFJ / 全B→ESTJ） |

## 🚀 快速开始

1. 将 `scripts/` 目录下的所有文件部署到 Skill 运行环境
2. 确保 Node.js 环境可用（用于对话模式的计分和报告生成）
3. 当用户说"测一下我的MBTI"时，加载 `scripts/SKILL.md` 并按 SOP 执行
4. **推荐**：优先使用 `mbti_quiz.html` 翻页式页面（模式 A），用户自主完成更流畅

详细操作流程请查看 `scripts/SKILL.md` 中的「完整 SOP」章节。

## ⚠️ 重要说明

- **SKILL.md 是核心**：所有交互逻辑、话术模板、技术细节都在其中
- **scripts/ 是运行时依赖**：缺一不可
- **mbti_quiz.html 是推荐入口**：翻页式页面内嵌全部93题+计分+报告生成，无需 Node.js
- **references/ 是辅助材料**：上传审核时可附上作为佐证，但不影响运行
- 本 Skill 不涉及任何外部 API 调用，所有计算本地完成
- 报告生成的 HTML 文件无外部依赖，可直接用浏览器打开

## 📋 版本信息

- **当前版本**: v2.1.0
- **发布日期**: 2026-04-04
- **协议**: MIT License

### 更新日志

- **v2.1.0**: 新增 `mbti_quiz.html` 翻页式自助测验页面（内嵌93题+计分+报告），支持双模式交互
- **v2.0.0**: 完整93题MBTI测评 Skill，对话式引导 + HTML可视化报告
