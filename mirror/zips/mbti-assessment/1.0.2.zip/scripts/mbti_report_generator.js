/**
 * MBTI 报告生成器
 * 将计分结果 + 16种人格数据打包成独立的 HTML 报告文件
 * 
 * 用法：node mbti_report_generator.js [答案JSON文件路径]
 * 
 * 输入格式（JSON文件）：
 * { "1": "A", "2": "B", "3": "A", ... }
 * 
 * 也支持直接传入分数：
 * { "type": "INTJ", "percentages": {...}, "tendencies": {...}, "rawScores": {...} }
 */

const fs = require('fs');
const path = require('path');

// 加载计分引擎
const { calculateScore } = require('./mbti_scoring_engine');

// 加载16种人格数据
const typeData = JSON.parse(fs.readFileSync(path.join(__dirname, 'mbti_16_types.json'), 'utf-8'));
const typeMap = {};
typeData.types.forEach(t => { typeMap[t.code] = t; });

const TYPE_NICKNAMES = {
  ISTJ: "检查员", ISFJ: "保护者", INFJ: "提倡者", INTJ: "建筑师",
  ISTP: "鉴赏家", ISFP: "探险家", INFP: "调停者", INTP: "逻辑学家",
  ESTP: "企业家", ESFP: "表演者", ENFP: "竞选者", ENTP: "辩论家",
  ESTJ: "总经理", ESFJ: "执政官", ENFJ: "主人公", ENTJ: "指挥官"
};

const TYPE_GROUPS = {
  分析家: ['INTJ','INTP','ENTJ','ENTP'],
  外交家: ['INFJ','INFP','ENFJ','ENFP'],
  守护者: ['ISTJ','ISFJ','ESTJ','ESFJ'],
  探险家: ['ISTP','ISFP','ESTP','ESFP']
};

function getTypeGroup(type) {
  for (const [group, types] of Object.entries(TYPE_GROUPS)) {
    if (types.includes(type)) return group;
  }
  return '';
}

const DIMENSION_INFO = {
  EI: {
    left: "E", right: "I",
    leftLabel: "外向 Extraversion", rightLabel: "内向 Introversion",
    leftDesc: "关注外部世界\n与人互动获得能量",
    rightDesc: "关注内心世界\n独处思考获得能量"
  },
  SN: {
    left: "S", right: "N",
    leftLabel: "感觉 Sensing", rightLabel: "直觉 Intuition",
    leftDesc: "关注具体事实\n注重实际经验",
    rightDesc: "关注可能性\n注重抽象思考"
  },
  TF: {
    left: "T", right: "F",
    leftLabel: "思考 Thinking", rightLabel: "情感 Feeling",
    leftDesc: "逻辑分析决策\n注重客观公正",
    rightDesc: "价值判断决策\n注重和谐共情"
  },
  JP: {
    left: "J", right: "P",
    leftLabel: "判断 Judging", rightLabel: "感知 Perceiving",
    leftDesc: "计划有序执行\n注重目标达成",
    rightDesc: "灵活随性应变\n注重过程体验"
  }
};

const DIMENSION_COLORS = {
  EI: { left: '#6366F1', right: '#818CF8' },
  SN: { left: '#EC4899', right: '#F472B6' },
  TF: { left: '#F59E0B', right: '#FBBF24' },
  JP: { left: '#10B981', right: '#34D399' }
};

const FUNC_LABELS = {
  primary: "主导功能", auxiliary: "辅助功能",
  tertiary: "第三功能", inferior: "第四功能"
};

function escapeHtml(str) {
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function generateReportHTML(scores, info) {
  const type = scores.type;
  const nickname = TYPE_NICKNAMES[type] || '';
  const groupName = getTypeGroup(type);

  // 维度条形图 HTML
  const dims = ['EI', 'SN', 'TF', 'JP'];
  let barsHTML = dims.map(dim => {
    const d = DIMENSION_INFO[dim];
    const leftPct = scores.percentages[d.left];
    const rightPct = scores.percentages[d.right];
    const tendVal = parseFloat(scores.tendencies[dim]);
    return `
      <div class="dimension-row">
        <div class="dimension-label" style="color: ${DIMENSION_COLORS[dim].left}">${d.left}</div>
        <div class="dimension-bar-container">
          <div class="dimension-bar-track">
            <div class="dimension-bar-left" data-width="${leftPct}" style="background: ${DIMENSION_COLORS[dim].left}; width: 0%">${leftPct}%</div>
            <div class="dimension-bar-right" data-width="${rightPct}" style="background: ${DIMENSION_COLORS[dim].right}; width: 0%">${rightPct}%</div>
          </div>
        </div>
        <div class="dimension-label" style="color: ${DIMENSION_COLORS[dim].right}">${d.right}</div>
      </div>
      <div class="dimension-score-detail">倾向分数：<strong>${tendVal > 0 ? '+' : ''}${tendVal}</strong>（偏向 ${tendVal >= 0 ? d.leftLabel : d.rightLabel}）</div>`;
  }).join('\n');

  // 维度解释
  let explainHTML = dims.map(dim => {
    const d = DIMENSION_INFO[dim];
    return `
      <div class="dim-explain-item">
        <span class="dim-tag" style="background: ${DIMENSION_COLORS[dim].left}">${d.left}</span>
        <p>${d.leftDesc.replace('\n', '<br>')}</p>
      </div>
      <div class="dim-explain-item">
        <span class="dim-tag" style="background: ${DIMENSION_COLORS[dim].right}">${d.right}</span>
        <p>${d.rightDesc.replace('\n', '<br>')}</p>
      </div>`;
  }).join('\n');

  // 功能栈
  const funcs = [
    { key: 'primary', value: info.dominant },
    { key: 'auxiliary', value: info.auxiliary },
    { key: 'tertiary', value: info.tertiary },
    { key: 'inferior', value: info.inferior }
  ];
  let funcHTML = funcs.map(f => `
    <div class="func-item ${f.key}">
      <div class="func-label">${FUNC_LABELS[f.key]}</div>
      <div class="func-value">${escapeHtml(f.value)}</div>
    </div>`).join('\n');

  // 摘要
  const summaryDims = [
    { left: 'E', right: 'I', key: 'EI', leftName: '外向', rightName: '内向' },
    { left: 'S', right: 'N', key: 'SN', leftName: '感觉', rightName: '直觉' },
    { left: 'T', right: 'F', key: 'TF', leftName: '思考', rightName: '情感' },
    { left: 'J', right: 'P', key: 'JP', leftName: '判断', rightName: '感知' }
  ];
  let summaryHTML = summaryDims.map(d => {
    const tend = parseFloat(scores.tendencies[d.key]);
    const dominant = tend >= 0 ? d.left : d.right;
    const name = tend >= 0 ? d.leftName : d.rightName;
    const pct = tend >= 0 ? scores.percentages[d.left] : scores.percentages[d.right];
    const color = DIMENSION_COLORS[d.key][tend >= 0 ? 'left' : 'right'];
    return `
      <div class="summary-item">
        <div class="letter" style="color: ${color}">${dominant}</div>
        <div class="info">
          <div class="label">${name} (${pct}%)</div>
          <div class="value">倾向分数 ${tend > 0 ? '+' : ''}${tend}</div>
        </div>
      </div>`;
  }).join('\n');

  // 详细描述
  const detailSections = [
    { title: '最佳表现', content: info.bestPerformance },
    { title: '核心特征', content: info.characteristics },
    { title: '他人眼中的你', content: info.othersView },
    { title: '潜在发展领域', content: info.growthAreas }
  ];
  let detailsHTML = detailSections.map(s => `
    <div class="detail-section">
      <h3>${s.title}</h3>
      <p>${s.content.replace(/\n/g, '<br>')}</p>
    </div>`).join('\n');

  // 雷达图数据（内嵌JSON）
  const radarAxes = [
    { label: 'E 外向', value: scores.percentages.E / 100, color: '#6366F1' },
    { label: 'S 感觉', value: scores.percentages.S / 100, color: '#EC4899' },
    { label: 'T 思考', value: scores.percentages.T / 100, color: '#F59E0B' },
    { label: 'J 判断', value: scores.percentages.J / 100, color: '#10B981' },
    { label: 'I 内向', value: scores.percentages.I / 100, color: '#818CF8' },
    { label: 'N 直觉', value: scores.percentages.N / 100, color: '#F472B6' },
    { label: 'F 情感', value: scores.percentages.F / 100, color: '#FBBF24' },
    { label: 'P 感知', value: scores.percentages.P / 100, color: '#34D399' }
  ];

  return `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>MBTI ${type} 人格测评报告</title>
<style>
:root{--primary:#4A6CF7;--bg:#F8FAFC;--card:#FFFFFF;--text:#1E293B;--text-muted:#64748B;--border:#E2E8F0}
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','PingFang SC','Hiragino Sans GB','Microsoft YaHei',sans-serif;background:var(--bg);color:var(--text);line-height:1.6;min-height:100vh}
.container{max-width:900px;margin:0 auto;padding:40px 24px}
.report-header{text-align:center;margin-bottom:48px;padding:48px 32px;background:linear-gradient(135deg,#4A6CF7 0%,#7C3AED 100%);border-radius:20px;color:white;position:relative;overflow:hidden}
.report-header::before{content:'';position:absolute;top:-50%;left:-50%;width:200%;height:200%;background:radial-gradient(circle,rgba(255,255,255,0.1) 0%,transparent 60%);animation:shimmer 8s ease-in-out infinite}
@keyframes shimmer{0%,100%{transform:translate(0,0)}50%{transform:translate(30px,30px)}}
.report-header h1{font-size:16px;font-weight:500;opacity:0.85;letter-spacing:4px;text-transform:uppercase;position:relative}
.report-header .type-badge{font-size:72px;font-weight:800;letter-spacing:8px;margin:16px 0 8px;position:relative;text-shadow:0 4px 24px rgba(0,0,0,0.2)}
.report-header .type-name{font-size:22px;font-weight:400;opacity:0.9;position:relative}
.report-header .type-nickname{font-size:15px;opacity:0.7;margin-top:8px;position:relative}
.card{background:var(--card);border-radius:16px;padding:32px;margin-bottom:24px;box-shadow:0 1px 3px rgba(0,0,0,0.06),0 4px 16px rgba(0,0,0,0.04);border:1px solid var(--border);opacity:0;transform:translateY(20px);animation:fadeInUp 0.6s ease forwards}
.card:nth-child(2){animation-delay:0.1s}.card:nth-child(3){animation-delay:0.2s}.card:nth-child(4){animation-delay:0.3s}.card:nth-child(5){animation-delay:0.4s}
@keyframes fadeInUp{to{opacity:1;transform:translateY(0)}}
.card-title{font-size:18px;font-weight:700;margin-bottom:24px;padding-bottom:12px;border-bottom:2px solid var(--border);display:flex;align-items:center;gap:8px}
.card-title .icon{width:28px;height:28px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:14px;color:white;flex-shrink:0}
.dimension-row{display:flex;align-items:center;margin-bottom:28px;gap:12px}
.dimension-row:last-child{margin-bottom:0}
.dimension-label{width:80px;font-size:14px;font-weight:700;text-align:center;flex-shrink:0}
.dimension-bar-container{flex:1;display:flex;align-items:center;gap:4px;position:relative}
.dimension-bar-track{flex:1;height:32px;background:#F1F5F9;border-radius:16px;display:flex;overflow:hidden;position:relative}
.dimension-bar-left{height:100%;border-radius:16px 0 0 16px;transition:width 1.2s cubic-bezier(0.22,1,0.36,1);display:flex;align-items:center;justify-content:flex-end;padding-right:12px;min-width:36px;color:white;font-size:13px;font-weight:600}
.dimension-bar-right{height:100%;border-radius:0 16px 16px 0;transition:width 1.2s cubic-bezier(0.22,1,0.36,1);display:flex;align-items:center;padding-left:12px;min-width:36px;color:white;font-size:13px;font-weight:600}
.dimension-score-detail{text-align:center;margin-top:6px;font-size:12px;color:var(--text-muted)}
.dimension-explanation{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:24px;padding-top:20px;border-top:1px solid var(--border)}
.dim-explain-item{padding:16px;border-radius:12px;background:#F8FAFC;border:1px solid var(--border)}
.dim-explain-item .dim-tag{display:inline-block;padding:2px 10px;border-radius:6px;font-size:12px;font-weight:700;color:white;margin-bottom:8px}
.dim-explain-item p{font-size:13px;color:var(--text-muted);line-height:1.5}
.radar-section{display:flex;flex-direction:column;align-items:center}
.radar-canvas-wrap{width:320px;height:320px;margin:0 auto}
.radar-canvas-wrap canvas{width:100%;height:100%}
.detail-section{margin-bottom:24px}
.detail-section h3{font-size:16px;font-weight:700;margin-bottom:12px;color:var(--primary);display:flex;align-items:center;gap:8px}
.detail-section h3::before{content:'';width:4px;height:18px;background:var(--primary);border-radius:2px;flex-shrink:0}
.detail-section p{font-size:15px;line-height:1.8;color:#374151;text-align:justify}
.function-stack{display:flex;gap:12px;flex-wrap:wrap;margin-bottom:20px}
.func-item{flex:1;min-width:120px;padding:16px;border-radius:12px;text-align:center;border:1px solid var(--border)}
.func-item.primary{background:#EEF2FF;border-color:#6366F1}
.func-item.auxiliary{background:#FDF2F8;border-color:#EC4899}
.func-item.tertiary{background:#FFFBEB;border-color:#F59E0B}
.func-item.inferior{background:#ECFDF5;border-color:#10B981}
.func-item .func-label{font-size:11px;color:var(--text-muted);margin-bottom:4px}
.func-item .func-value{font-size:24px;font-weight:700}
.summary-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:24px}
.summary-item{display:flex;align-items:center;gap:12px;padding:16px;background:#F8FAFC;border-radius:12px;border:1px solid var(--border)}
.summary-item .letter{font-size:28px;font-weight:800;width:48px;text-align:center}
.summary-item .info{flex:1}
.summary-item .info .label{font-size:13px;color:var(--text-muted)}
.summary-item .info .value{font-size:16px;font-weight:600}
.report-footer{text-align:center;padding:24px;font-size:13px;color:var(--text-muted);border-top:1px solid var(--border);margin-top:16px}
@media(max-width:640px){.container{padding:16px 12px}.report-header{padding:32px 20px}.report-header .type-badge{font-size:48px;letter-spacing:4px}.card{padding:20px 16px}.dimension-explanation{grid-template-columns:1fr}.summary-grid{grid-template-columns:1fr}.function-stack{flex-direction:column}.func-item{min-width:100%}.dimension-label{width:48px;font-size:12px}}
@media print{body{background:white}.card{box-shadow:none;border:1px solid #ddd}.report-header{-webkit-print-color-adjust:exact;print-color-adjust:exact}}
</style>
</head>
<body>
<div class="container">
  <div class="report-header">
    <h1>MBTI 人格测评报告</h1>
    <div class="type-badge">${type}</div>
    <div class="type-name">${escapeHtml(info.name)}</div>
    <div class="type-nickname">${nickname} · ${groupName}</div>
  </div>

  <div class="card">
    <div class="card-title"><span class="icon" style="background:#6366F1">📊</span>四维度分析</div>
    ${barsHTML}
    <div class="dimension-explanation">${explainHTML}</div>
  </div>

  <div class="card">
    <div class="card-title"><span class="icon" style="background:#EC4899">🕸️</span>人格轮廓雷达图</div>
    <div class="radar-section"><div class="radar-canvas-wrap"><canvas id="radarCanvas" width="640" height="640"></canvas></div></div>
  </div>

  <div class="card">
    <div class="card-title"><span class="icon" style="background:#F59E0B">🧠</span>认知功能栈</div>
    <div class="function-stack">${funcHTML}</div>
  </div>

  <div class="card">
    <div class="card-title"><span class="icon" style="background:#10B981">📋</span>测评摘要</div>
    <div class="summary-grid">${summaryHTML}</div>
  </div>

  <div class="card">
    <div class="card-title"><span class="icon" style="background:#7C3AED">📝</span>人格深度解读</div>
    ${detailsHTML}
  </div>

  <div class="report-footer">
    MBTI 93题完整版测评报告 · 仅供参考，不构成专业心理评估<br>
    生成时间：${new Date().toLocaleString('zh-CN')}
  </div>
</div>
<script>
(function(){
  var axes = ${JSON.stringify(radarAxes)};
  var canvas = document.getElementById('radarCanvas');
  var ctx = canvas.getContext('2d');
  var W = canvas.width, H = canvas.height, cx = W/2, cy = H/2, R = Math.min(W,H)*0.38;
  var n = axes.length, step = Math.PI*2/n, progress = 0;

  function draw(){
    progress = Math.min(1, progress + 0.03);
    var ease = 1 - Math.pow(1-progress, 3);
    ctx.clearRect(0,0,W,H);
    for(var lv=1;lv<=5;lv++){
      var r=R*(lv/5);ctx.beginPath();
      for(var i=0;i<=n;i++){var a=i*step-Math.PI/2;var x=cx+r*Math.cos(a);var y=cy+r*Math.sin(a);i===0?ctx.moveTo(x,y):ctx.lineTo(x,y);}
      ctx.closePath();ctx.strokeStyle=lv===5?'#CBD5E1':'#E2E8F0';ctx.lineWidth=lv===5?2:1;ctx.stroke();
      if(lv%2===0){ctx.fillStyle='#94A3B8';ctx.font='20px sans-serif';ctx.textAlign='right';ctx.fillText((lv*20)+'%',cx-8,cy-r+6);}
    }
    for(var i=0;i<n;i++){var a=i*step-Math.PI/2;ctx.beginPath();ctx.moveTo(cx,cy);ctx.lineTo(cx+R*Math.cos(a),cy+R*Math.sin(a));ctx.strokeStyle='#E2E8F0';ctx.lineWidth=1;ctx.stroke();}
    ctx.beginPath();
    for(var i=0;i<=n;i++){var idx=i%n;var a=idx*step-Math.PI/2;var r=R*axes[idx].value*ease;var x=cx+r*Math.cos(a);var y=cy+r*Math.sin(a);i===0?ctx.moveTo(x,y):ctx.lineTo(x,y);}
    ctx.closePath();ctx.fillStyle='rgba(99,102,241,0.15)';ctx.fill();ctx.strokeStyle='rgba(99,102,241,0.8)';ctx.lineWidth=3;ctx.stroke();
    for(var i=0;i<n;i++){var a=i*step-Math.PI/2;var r=R*axes[i].value*ease;var x=cx+r*Math.cos(a);var y=cy+r*Math.sin(a);ctx.beginPath();ctx.arc(x,y,6,0,Math.PI*2);ctx.fillStyle=axes[i].color;ctx.fill();ctx.strokeStyle='white';ctx.lineWidth=2;ctx.stroke();}
    ctx.textAlign='center';ctx.textBaseline='middle';
    for(var i=0;i<n;i++){var a=i*step-Math.PI/2;var lr=R+40;var x=cx+lr*Math.cos(a);var y=cy+lr*Math.sin(a);ctx.fillStyle=axes[i].color;ctx.font='bold 20px sans-serif';ctx.fillText(axes[i].label,x,y-10);ctx.fillStyle='#64748B';ctx.font='18px sans-serif';ctx.fillText(Math.round(axes[i].value*100)+'%',x,y+14);}
    if(progress<1)requestAnimationFrame(draw);
  }

  // 条形图动画
  document.querySelectorAll('[data-width]').forEach(function(el){setTimeout(function(){el.style.width=el.dataset.width+'%';},100);});

  draw();
})();
</script>
</body>
</html>`;
}

// 导出模块（供其他脚本调用）
module.exports = {
  generateReportHTML,
  TYPE_NICKNAMES,
  TYPE_GROUPS
};

// ===== 命令行入口 =====
if (require.main === module) {
  const args = process.argv.slice(2);

  if (args.length === 0) {
    // 无参数：随机生成一个示例报告
    console.log('未指定输入文件，使用随机答题生成示例报告...\n');
    const { generateRandomAnswers } = require('./mbti_scoring_engine');
    const scores = calculateScore(generateRandomAnswers());
    const info = typeMap[scores.type];
    if (!info) { console.error('未找到类型描述:', scores.type); process.exit(1); }

    const html = generateReportHTML(scores, info);
    const outPath = path.join(__dirname, `MBTI_${scores.type}_report.html`);
    fs.writeFileSync(outPath, html, 'utf-8');
    console.log(`✅ 报告已生成: ${outPath}`);
    console.log(`   人格类型: ${scores.type}`);
    console.log(`   倾向分数: E/I=${scores.tendencies.EI}, S/N=${scores.tendencies.SN}, T/F=${scores.tendencies.TF}, J/P=${scores.tendencies.JP}`);
    return;
  }

  // 有参数：读取答案文件
  const inputPath = path.resolve(args[0]);
  if (!fs.existsSync(inputPath)) {
    console.error('文件不存在:', inputPath);
    process.exit(1);
  }

  const input = JSON.parse(fs.readFileSync(inputPath, 'utf-8'));

  let scores, info;

  if (input.type && input.percentages) {
    // 直接传入分数
    scores = input;
    info = typeMap[scores.type];
  } else {
    // 传入答案
    scores = calculateScore(input);
    info = typeMap[scores.type];
  }

  if (!info) { console.error('未找到类型描述:', scores.type); process.exit(1); }

  const html = generateReportHTML(scores, info);
  const outPath = args[1] ? path.resolve(args[1]) : path.join(__dirname, `MBTI_${scores.type}_report.html`);
  fs.writeFileSync(outPath, html, 'utf-8');
  console.log(`✅ 报告已生成: ${outPath}`);
  console.log(`   人格类型: ${scores.type}`);
  console.log(`   倾向分数: E/I=${scores.tendencies.EI}, S/N=${scores.tendencies.SN}, T/F=${scores.tendencies.TF}, J/P=${scores.tendencies.JP}`);
}
