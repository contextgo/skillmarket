/**
 * MBTI 93题计分引擎
 * 根据答题结果计算各维度得分和人格类型
 */

const fs = require('fs');

// 加载题目和计分规则
const questionsData = JSON.parse(fs.readFileSync('mbti_93_questions.json', 'utf-8'));
const scoringData = JSON.parse(fs.readFileSync('mbti_93_scoring_rules.json', 'utf-8'));

// 构建快速查找表
const scoringMap = {};
scoringData.rules.forEach(rule => {
    scoringMap[rule.id] = rule;
});

/**
 * 计算MBTI得分
 * @param {Object} answers - 答题结果 {题号: 'A'或'B'}
 * @returns {Object} 计分结果
 */
function calculateScore(answers) {
    // 初始化各维度计数
    const dimensions = {
        E: 0, I: 0,
        S: 0, N: 0,
        T: 0, F: 0,
        J: 0, P: 0
    };

    // 遍历每道题的答题结果
    for (let qid in answers) {
        const answer = answers[qid]; // 'A' 或 'B'
        const rule = scoringMap[qid];
        
        if (!rule) {
            console.warn(`警告: 题${qid}没有计分规则`);
            continue;
        }

        // 根据选项增加对应维度计数
        const dimension = answer === 'A' ? rule.optionA : rule.optionB;
        if (dimension && dimensions.hasOwnProperty(dimension)) {
            dimensions[dimension]++;
        }
    }

    // 计算各维度倾向（百分比）
    const eiTotal = dimensions.E + dimensions.I;
    const snTotal = dimensions.S + dimensions.N;
    const tfTotal = dimensions.T + dimensions.F;
    const jpTotal = dimensions.J + dimensions.P;

    const result = {
        rawScores: { ...dimensions },
        percentages: {
            E: eiTotal > 0 ? Math.round((dimensions.E / eiTotal) * 100) : 50,
            I: eiTotal > 0 ? Math.round((dimensions.I / eiTotal) * 100) : 50,
            S: snTotal > 0 ? Math.round((dimensions.S / snTotal) * 100) : 50,
            N: snTotal > 0 ? Math.round((dimensions.N / snTotal) * 100) : 50,
            T: tfTotal > 0 ? Math.round((dimensions.T / tfTotal) * 100) : 50,
            F: tfTotal > 0 ? Math.round((dimensions.F / tfTotal) * 100) : 50,
            J: jpTotal > 0 ? Math.round((dimensions.J / jpTotal) * 100) : 50,
            P: jpTotal > 0 ? Math.round((dimensions.P / jpTotal) * 100) : 50
        },
        // 倾向分数 (-10 到 +10)
        tendencies: {
            EI: eiTotal > 0 ? ((dimensions.E - dimensions.I) / eiTotal * 10).toFixed(1) : 0,
            SN: snTotal > 0 ? ((dimensions.S - dimensions.N) / snTotal * 10).toFixed(1) : 0,
            TF: tfTotal > 0 ? ((dimensions.T - dimensions.F) / tfTotal * 10).toFixed(1) : 0,
            JP: jpTotal > 0 ? ((dimensions.J - dimensions.P) / jpTotal * 10).toFixed(1) : 0
        }
    };

    // 确定人格类型
    result.type = '';
    result.type += dimensions.E >= dimensions.I ? 'E' : 'I';
    result.type += dimensions.S >= dimensions.N ? 'S' : 'N';
    result.type += dimensions.T >= dimensions.F ? 'T' : 'F';
    result.type += dimensions.J >= dimensions.P ? 'J' : 'P';

    // 确定主导维度（最显著的倾向）
    const tendenciesAbs = {
        EI: Math.abs(parseFloat(result.tendencies.EI)),
        SN: Math.abs(parseFloat(result.tendencies.SN)),
        TF: Math.abs(parseFloat(result.tendencies.TF)),
        JP: Math.abs(parseFloat(result.tendencies.JP))
    };
    
    const dominantDimension = Object.keys(tendenciesAbs).reduce((a, b) => 
        tendenciesAbs[a] > tendenciesAbs[b] ? a : b
    );
    result.dominantDimension = dominantDimension;

    return result;
}

/**
 * 生成答题模板（用于测试）
 */
function generateRandomAnswers() {
    const answers = {};
    for (let i = 1; i <= 93; i++) {
        answers[i] = Math.random() > 0.5 ? 'A' : 'B';
    }
    return answers;
}

/**
 * 生成示例答题（所有选A）
 */
function generateAllA() {
    const answers = {};
    for (let i = 1; i <= 93; i++) {
        answers[i] = 'A';
    }
    return answers;
}

/**
 * 生成示例答题（所有选B）
 */
function generateAllB() {
    const answers = {};
    for (let i = 1; i <= 93; i++) {
        answers[i] = 'B';
    }
    return answers;
}

// 导出模块
module.exports = {
    calculateScore,
    generateRandomAnswers,
    generateAllA,
    generateAllB,
    questionsData,
    scoringData
};

// 如果是直接运行此文件，执行测试
if (require.main === module) {
    console.log('=== MBTI 93题计分引擎测试 ===\n');

    // 测试1: 全选A
    console.log('测试1: 全选A');
    const resultA = calculateScore(generateAllA());
    console.log('人格类型:', resultA.type);
    console.log('原始分数:', resultA.rawScores);
    console.log('倾向分数:', resultA.tendencies);
    console.log();

    // 测试2: 全选B
    console.log('测试2: 全选B');
    const resultB = calculateScore(generateAllB());
    console.log('人格类型:', resultB.type);
    console.log('原始分数:', resultB.rawScores);
    console.log('倾向分数:', resultB.tendencies);
    console.log();

    // 测试3: 随机答题
    console.log('测试3: 随机答题');
    const resultRandom = calculateScore(generateRandomAnswers());
    console.log('人格类型:', resultRandom.type);
    console.log('原始分数:', resultRandom.rawScores);
    console.log('百分比:', resultRandom.percentages);
    console.log('倾向分数:', resultRandom.tendencies);
    console.log('主导维度:', resultRandom.dominantDimension);
}
