# MBTI 人格探索 — Skill 安装与使用指南

## 这是什么？

一个**专业级 MBTI 93 题自测 Skill**，专为 WorkBuddy Agent 设计。用户通过和 Agent 对话的方式完成 93 道题，最终获得一份精美的可视化人格报告。

## 文件清单

| 文件/目录 | 必需 | 说明 |
|-----------|:----:|------|
| `SKILL.md` | ✅ | Skill 定义入口（本文件） |
| `_meta.json` | ✅ | 元数据（版本/标签/依赖等） |
| `scripts/SKILL.md` | ✅ | **核心文件**：完整 SOP + 话术 + 技术文档 |
| `scripts/mbti_93_questions.json` | ✅ | 93道纯题目 |
| `scripts/mbti_93_full.json` | ✅ | 题目+计分规则（v2已修正） |
| `scripts/mbti_93_scoring_rules.json` | ✅ | 独立计分规则 |
| `scripts/mbti_16_types.json` | ✅ | 16种人格描述 |
| `scripts/mbti_scoring_engine.js` | ✅ | 计分引擎 |
| `scripts/mbti_report_generator.js` | ✅ | HTML 报告生成器 |
| `scripts/package.json` | ✅ | Node.js 依赖声明 |
| `scripts/mbti_report.html` | ⬜ | 内嵌预览模板（可选） |
| `references/` | ⬜ | 参考资料（审核佐证材料） |

## 安装步骤

1. 将整个 `mbti-assessment` 文件夹复制到 Skill 运行目录
2. 确保 Node.js ≥ 14.0.0 可用
3. （可选）运行一次验证：`cd scripts && node -e "const {calculateScore, generateAllA} = require('./mbti_scoring_engine'); console.log(calculateScore(generateAllA()).type)"`
   - 应输出：`ISFJ`

## 使用方式

用户触发关键词（如"测一下MBTI"）→ Agent 加载 `scripts/SKILL.md` → 按 SOP 引导对话 → 收集93道答案 → 调用计分引擎 → 生成HTML报告 → 展示+个性化解读

详细流程见 `scripts/SKILL.md` 的「完整 SOP」章节。

## 技术要求

- **运行时**: Node.js ≥ 14.0.0
- **外部依赖**: 无（所有计算本地完成）
- **网络访问**: 不需要
- **输出**: 独立 HTML 文件（~20KB，无外部资源引用）

## 已知限制

- 当前仅支持完整版93题，无快速版选项
- 报告语言固定为中文
- 计分引擎为同步执行，93题计算时间 < 100ms

## 许可证

MIT License — 自由使用、修改和分发。
