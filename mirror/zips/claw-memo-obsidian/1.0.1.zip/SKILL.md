# claw-memo-obsidian Skill

**版本**：2.1.0  
**创建时间**：2026-04-02  
**改进时间**：2026-04-02（使用 skill-evolve 改进）  
**多智能体支持**：2026-04-02（v2.0.0）  
**文件夹隔离**：2026-04-02（v2.1.0）  
**作者**：木流 2 号 🌲

---

## 📋 技能描述

将智能体核心配置文件同步到 Obsidian 知识库，支持多智能体、配置文件、按日期归档、动态 Frontmatter。

**版本**：2.0.0（支持多智能体）  
**技能名称**：claw-memo-obsidian（Claw + Memo + Obsidian）

**适用场景**：
- 备份 OpenClaw/Claude Code/Codex 等智能体配置文件到 Obsidian
- 多智能体共享同一个同步工具
- 按日期归档助手身份、记忆、用户信息等文件
- 为同步文件添加 Obsidian 友好的 Frontmatter 元数据
- 定期同步保持 Obsidian 与智能体配置一致

---

## 🎯 触发条件

当用户表达以下**意图**时触发（支持多种表达方式）：

### 核心意图：同步/备份 OpenClaw 文件到 Obsidian

**支持的说法**：
- "同步到 Obsidian" / "同步配置文件到 Obsidian"
- "备份到 Obsidian" / "备份核心文件"
- "把 AGENTS.md、MEMORY.md 等存到 Obsidian"
- "同步今天的工作记录" / "同步记忆文件"
- "claw-memo-obsidian" / "claw memo"
- "memo sync" / "memo-sync"（兼容旧称）

**不支持的说法**（避免误触发）：
- ❌ "创建 claw-memo-obsidian"（这是创建技能，不是使用技能）
- ❌ "帮我写一个同步工具"（这是技能开发需求）

### 参数识别

当用户提到以下参数时，需要识别并传递给脚本：

| 参数类型 | 用户说法示例 | 识别方法 |
|----------|-------------|---------|
| **日期** | "同步到昨天的文件夹"、"同步到 2026-04-01" | 识别日期关键词（今天/昨天/前天/N 天前）或 YYYY-MM-DD 格式 |
| **文件** | "只同步 MEMORY.md"、"同步 AGENTS.md 和 USER.md" | 识别 `.md` 结尾的文件名 |
| **Vault 路径** | "同步到我的 Vault"、"同步到 ~/MyVault" | 识别路径格式（~/开头或绝对路径） |

---

## 📁 同步文件清单

默认同步以下 5 个核心文件：

| 文件 | 说明 | 目标文件名 |
|------|------|-----------|
| `AGENTS.md` | 助手工作区配置 | `01-AGENTS.md` |
| `IDENTITY.md` | 助手身份信息 | `02-IDENTITY.md` |
| `MEMORY.md` | 长期记忆 | `03-MEMORY.md` |
| `SOUL.md` | 助手灵魂/人格 | `04-SOUL.md` |
| `USER.md` | 用户信息 | `05-USER.md` |

---

## 🛠️ 使用方法

### 基础用法

```
同步核心文件到 Obsidian
使用 claw-memo-obsidian 同步
```

### 指定日期文件夹

```
# 使用具体日期
同步配置文件到 2026-04-02 文件夹

# 使用自然语言日期
同步到昨天的文件夹
同步到前天的文件夹
同步到 3 天前的文件夹
```

### 同步单个文件

```
只同步 MEMORY.md 到 Obsidian
同步 AGENTS.md 和 USER.md
```

### 组合参数

```
把 MEMORY.md 同步到昨天的文件夹
只同步配置文件到 ~/MyVault
```

---

## 📝 执行流程

### 步骤 1：识别用户意图和参数

**自然语言参数解析**：

```python
# 日期解析
def parse_date(date_str):
    """
    支持：
    - "今天" → 2026-04-02
    - "昨天" → 2026-04-01
    - "前天" → 2026-03-31
    - "3 天前" → 2026-03-30
    - "2026-04-01" → 2026-04-01
    """
    if date_str in ["今天", "今日"]:
        return datetime.now().strftime("%Y-%m-%d")
    elif date_str == "昨天":
        return (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
    elif date_str == "前天":
        return (datetime.now() - timedelta(days=2)).strftime("%Y-%m-%d")
    elif "天前" in date_str:
        days = int(date_str.replace("天前", ""))
        return (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")
    else:
        # 尝试解析 YYYY-MM-DD 格式
        return date_str
```

**文件列表解析**：

```python
# 从自然语言中提取文件名
def parse_files(user_input):
    """
    支持：
    - "只同步 MEMORY.md" → ["MEMORY.md"]
    - "同步 AGENTS.md 和 USER.md" → ["AGENTS.md", "USER.md"]
    - "同步 AGENTS.md, MEMORY.md" → ["AGENTS.md", "MEMORY.md"]
    """
    import re
    # 匹配所有 .md 结尾的文件名
    files = re.findall(r'([A-Z_]+\.md)', user_input)
    return files if files else None
```

### 步骤 2：确认 Obsidian Vault 位置

```bash
# 默认 Vault 位置
VAULT_PATH="/home/jasoncool/Obs_Openclaw_mem/OpenClaw 记忆"

# 支持用户指定
VAULT_PATH="~/MyVault"  # 或用户提供的路径
```

### 步骤 3：创建目标文件夹

```bash
# 创建日期文件夹（支持自然语言日期）
TARGET_DATE=$(parse_date "昨天")  # 或用户指定的日期
TARGET_DIR="$VAULT_PATH/muliu_memo/$TARGET_DATE"
mkdir -p "$TARGET_DIR"
```

### 步骤 4：读取并转换文件

为每个文件添加 Frontmatter 元数据：

```yaml
---
created: 2026-04-02 14:15
source: OpenClaw Workspace
type: 助手配置
tags: [agents, workspace, memory, workflow]
---
```

### 步骤 5：写入目标文件

将转换后的内容写入 Obsidian 目标文件夹。

**冲突处理**（可选）：
- 如果文件已存在，询问用户是否覆盖
- 或自动备份旧版本（添加 `.bak` 后缀）

### 步骤 6：验证并反馈

确认所有文件成功写入，返回文件清单和统计信息。

**可选**：如果检测到 obsidian-cli，询问是否打开文件夹。

---

## 🔧 配置选项

### 智能体文件夹隔离（重要！）

**不同智能体同步到不同的 Obsidian 文件夹**：

| 智能体 | 默认文件夹 | 说明 |
|--------|-----------|------|
| OpenClaw | `muliu_memo` | 木流 2 号的配置文件 |
| Claude Code | `claude_memo` | Claude Code 的项目配置 |
| Codex | `codex_memo` | Codex 的配置 |
| 其他 | `memo` | 默认文件夹 |

**自定义文件夹**：
```json
{
  "agents": {
    "openclaw": {
      "sync_folder": "muliu_memo"  // 可以自定义
    },
    "claude-code": {
      "sync_folder": "my_claude_notes"  // 自定义文件夹名
    }
  }
}
```

**输出结构**：
```
Obsidian Vault/
├── muliu_memo/        ← OpenClaw
│   └── 2026-04-02/
├── claude_memo/       ← Claude Code
│   └── 2026-04-02/
└── codex_memo/        ← Codex
    └── 2026-04-02/
```

---

### 环境变量（可选）

| 变量 | 默认值 | 说明 |
|------|--------|------|
| `OBSIDIAN_VAULT_PATH` | `/home/jasoncool/Obs_Openclaw_mem/OpenClaw 记忆` | Obsidian Vault 根路径 |
| `MEMO_SYNC_FOLDER` | `muliu_memo` | 全局 fallback 文件夹（当智能体未配置时使用） |
| `MEMO_SYNC_FILES` | `AGENTS.md,IDENTITY.md,MEMORY.md,SOUL.md,USER.md` | 同步文件列表 |

### Frontmatter 模板

```yaml
---
created: {{timestamp}}
source: OpenClaw Workspace
type: {{file_type}}
tags: [{{tags}}]
---
```

---

## 📊 文件类型映射

| 源文件 | type | tags |
|--------|------|------|
| AGENTS.md | 助手配置 | agents, workspace, memory, workflow |
| IDENTITY.md | 助手身份 | identity, soul, assistant |
| MEMORY.md | 长期记忆 | memory, user-info, skills, rules, important |
| SOUL.md | 助手灵魂 | soul, persona, behavior, philosophy |
| USER.md | 用户信息 | user, profile, context, preferences |

---

## ⚠️ 注意事项

### 1. Vault 路径
确保 Obsidian Vault 路径存在且可写

### 2. 文件编码
使用 UTF-8 编码，确保中文正常显示

### 3. Frontmatter
添加标准 YAML Frontmatter 以便 Obsidian 识别

### 4. 版本控制
建议定期提交到 Git 进行版本管理

### 5. 冲突处理
如果目标文件已存在，覆盖前询问用户

### 6. 🔴 删除操作（重要！）

**任何删除操作前必须二次确认！**

**触发场景**：
- 用户说"清理测试文件夹"
- 用户说"删除同步的文件"
- 用户说"移除某个日期的文件夹"

**确认流程**：
```
步骤 1：列出待删除的文件/文件夹清单
步骤 2：显示影响范围（文件大小、数量）
步骤 3：询问用户"是否确认删除？请回复'确认删除'或'是的'"
步骤 4：用户明确确认后，才执行删除
```

**禁止行为**：
- ❌ 未经确认直接删除
- ❌ 使用模糊的确认（如"好的"、"可以"）
- ❌ 批量删除时不显示清单

**示例对话**：

**用户**：清理测试文件夹

**助手**：
```
⚠️ 二次确认

操作：清理 memo-sync 的测试文件夹

待删除：
- /home/jasoncool/Obs_Openclaw_mem/OpenClaw 记忆/muliu_memo/2026-04-01/ (24KB)
- /home/jasoncool/Obs_Openclaw_mem/OpenClaw 记忆/muliu_memo/2026-03-30/ (24KB)

影响：2 个文件夹，共约 48KB

是否确认删除？请回复"确认删除"或"是的"，我才会执行。
```

---

## 🔄 扩展功能（未来）

- [ ] 支持增量同步（只同步变更的文件）
- [ ] 支持自定义文件列表
- [ ] 支持同步 memory/ 文件夹下的每日笔记
- [ ] 支持同步 self-improving/ 文件夹
- [ ] 添加 Git 自动提交功能
- [ ] 支持双向同步（Obsidian → OpenClaw）

---

## 📝 使用示例

### 示例 1：完整同步

**用户**：把核心文件同步到 Obsidian

**助手**：
```
好的！正在同步 5 个核心文件到 Obsidian...

✅ 创建今日文件夹：2026-04-02
✅ 同步 AGENTS.md → 01-AGENTS.md (12K)
✅ 同步 IDENTITY.md → 02-IDENTITY.md (813B)
✅ 同步 MEMORY.md → 03-MEMORY.md (9.5K)
✅ 同步 SOUL.md → 04-SOUL.md (2.5K)
✅ 同步 USER.md → 05-USER.md (1.5K)

完成！文件位置：
/home/jasoncool/Obs_Openclaw_mem/OpenClaw 记忆/muliu_memo/2026-04-02/
```

### 示例 2：指定日期

**用户**：同步配置文件到 2026-04-01 文件夹

**助手**：
```
好的！正在同步到指定日期文件夹：2026-04-01

[执行同步流程...]
```

### 示例 3：单个文件

**用户**：只同步 MEMORY.md

**助手**：
```
好的！只同步 MEMORY.md 到 Obsidian...

✅ 同步完成：03-MEMORY.md (9.5K)
```

---

## 🐛 故障排查

### 问题 1：Vault 路径不存在

**错误**：`无法访问 Vault 路径`

**解决**：
```bash
# 检查路径
ls -la /home/jasoncool/Obs_Openclaw_mem/

# 如果不存在，创建或使用其他路径
mkdir -p ~/ObsidianVault
```

### 问题 2：文件写入失败

**错误**：`Permission denied`

**解决**：
```bash
# 检查权限
ls -ld "$TARGET_DIR"

# 修复权限
chmod u+w "$TARGET_DIR"
```

### 问题 3：中文乱码

**错误**：同步后中文显示为乱码

**解决**：
- 确保使用 UTF-8 编码写入文件
- 在 Obsidian 中设置默认编码为 UTF-8

---

## 📚 相关文件

- `skills/claw-memo-obsidian/SKILL.md` - 本文件
- `skills/obsidian-cli/SKILL.md` - Obsidian CLI 技能
- `skills/feishu-create-doc/SKILL.md` - 飞书文档创建技能

---

## 🌲 更新日志

### v2.1.0 (2026-04-02 - 智能体文件夹隔离)

**核心改进**：
- ✅ 不同智能体同步到不同文件夹（openclaw→muliu_memo, claude-code→claude_memo）
- ✅ 智能体级别 `sync_folder` 配置
- ✅ 默认文件夹映射表（AGENT_DEFAULT_FOLDERS）
- ✅ 配置优先级：智能体配置 > 默认映射 > 全局配置

**配置示例**：
```json
{
  "agents": {
    "openclaw": {
      "sync_folder": "muliu_memo"
    },
    "claude-code": {
      "sync_folder": "claude_memo"
    }
  }
}
```

**输出结构**：
```
Obsidian Vault/
├── muliu_memo/      ← OpenClaw
├── claude_memo/     ← Claude Code
└── codex_memo/      ← Codex
```

---

### v2.0.0 (2026-04-02 - 多智能体支持)

**核心改进**：
- ✅ 支持配置文件（`~/.claw-memo-config.json`）
- ✅ 支持多智能体自动识别（OpenClaw/Claude Code/Codex）
- ✅ 动态 Frontmatter 生成（根据智能体调整）
- ✅ 多级配置查找（工作目录 > 主目录 > 默认）
- ✅ 智能体特定配置（不同智能体不同文件列表）
- ✅ 技能重命名为 `claw-memo-obsidian`

**新增命令行参数**：
- ✅ `--agent` 指定智能体
- ✅ `--config` 指定配置文件路径

**使用示例**：
```bash
# OpenClaw 使用
python3 claw-memo-obsidian.py --agent openclaw

# Claude Code 使用
python3 claw-memo-obsidian.py --agent claude-code

# 使用自定义配置
python3 claw-memo-obsidian.py --config ~/.my-config.json
```

---

### v1.2.0 (2026-04-02 - 安全增强)

**新增功能**：
- ✅ 删除前二次确认机制（安全保护）
- ✅ `--clean` 参数（清理模式）
- ✅ `--confirmed` 参数（跳过确认，用于自动化）
- ✅ `confirm_deletion()` 函数（显示待删除清单和影响）

**SKILL.md 增强**：
- ✅ 添加"删除操作"注意事项章节
- ✅ 明确确认流程（4 步）
- ✅ 列出禁止行为
- ✅ 提供示例对话

**使用示例**：
```bash
# 清理测试文件夹（需要确认）
python3 memo-sync.py --clean -d "昨天"

# 跳过确认（自动化脚本）
python3 memo-sync.py --clean -d "昨天" --confirmed
```

---

### v1.1.0 (2026-04-02 - skill-evolve 改进)

**改进内容**：
- ✅ 支持自然语言日期解析（"昨天"、"前天"、"3 天前"）
- ✅ 优化触发条件，增加同义词（备份=同步，配置文件=核心文件）
- ✅ 移除模糊触发词（"创建 memo-sync"改为"使用 memo-sync"）
- ✅ 增加参数识别指导（日期、文件、Vault 路径）
- ✅ Python 脚本增加 `parse_natural_date()` 函数
- ✅ Python 脚本增加 `parse_files_from_input()` 函数

**问题修复**：
- 🐛 修复触发词过于具体的问题
- 🐛 修复日期解析不友好的问题

**待改进**（下一轮）：
- ⏳ obsidian-cli 集成
- ⏳ 文件冲突处理
- ⏳ 中文错误消息优化

---

### v1.0.0 (2026-04-02)

- ✅ 初始版本发布
- ✅ 支持 5 个核心文件同步
- ✅ 添加 Frontmatter 元数据
- ✅ 支持按日期归档
- ✅ 完整的错误处理和用户反馈

### v2.2.0 (2026-04-02 - 强制按工作区名称推导)

**核心改进**（用户需求：「优先检查自己的工作空间名称，当备份的时候优先备份到自己的工作空间名称所演化的记忆文件夹下」）：
- ✅ **新增向上查找最近工作区**：不管脚本在哪个目录被调用，都会自动向上查找最近的 `AGENTS.md` 确定工作区
- ✅ **强制推导规则**：只要工作区名称格式规范（`ai-write` 这种），**总是**使用推导出来的 `工作区名称 + _memo` 作为备份文件夹
- ✅ **完全自动**：不需要每个智能体修改配置，克隆完工作区直接就能用，自动备份到对应文件夹
- ✅ **彻底解决**：再也不会出现"这个智能体备份到那个智能体文件夹"的问题

**修复的问题**：
- 🐛 解决了"把技能发给其他智能体，还是备份到原目录"的问题
- 🐛 现在每个智能体不管怎么调用，都会自动备份到**自己工作区名称对应的文件夹**

### v2.1.0 (2026-04-02 - 自动工作区检测改进)

**核心改进**：
- ✅ 新增**自动工作区检测**：如果当前目录有 `AGENTS.md`，优先使用当前目录作为工作区
- ✅ 新增**智能推导同步文件夹**：从工作区路径名称自动推导出 `sync_folder`（例如 `ai-write` → `ai_write_memo`）
- ✅ 解决了"多个智能体共享同一配置但备份到错误文件夹"的问题
- ✅ 向后兼容：原有配置依然有效，新功能是增量改进

---

> 此技能由木流 2 号创建，用于自动化 OpenClaw 配置文件的 Obsidian 归档。
