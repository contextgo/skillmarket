#!/bin/bash

# memo-sync.sh - OpenClaw 核心文件同步到 Obsidian 脚本
# 版本：1.0.0
# 创建时间：2026-04-02

set -e

# ==================== 配置 ====================

# OpenClaw 工作区路径
OPENCLAW_WORKSPACE="/home/jasoncool/.openclaw/workspace"

# Obsidian Vault 路径（可通过环境变量覆盖）
OBSIDIAN_VAULT_PATH="${OBSIDIAN_VAULT_PATH:-/home/jasoncool/Obs_Openclaw_mem/OpenClaw 记忆}"

# 同步目标文件夹
MEMO_SYNC_FOLDER="${MEMO_SYNC_FOLDER:-muliu_memo}"

# 要同步的文件列表
SYNC_FILES=("AGENTS.md" "IDENTITY.md" "MEMORY.md" "SOUL.md" "USER.md")

# 文件类型和标签映射
declare -A FILE_TYPES=(
    ["AGENTS.md"]="助手配置"
    ["IDENTITY.md"]="助手身份"
    ["MEMORY.md"]="长期记忆"
    ["SOUL.md"]="助手灵魂"
    ["USER.md"]="用户信息"
)

declare -A FILE_TAGS=(
    ["AGENTS.md"]="agents, workspace, memory, workflow"
    ["IDENTITY.md"]="identity, soul, assistant"
    ["MEMORY.md"]="memory, user-info, skills, rules, important"
    ["SOUL.md"]="soul, persona, behavior, philosophy"
    ["USER.md"]="user, profile, context, preferences"
)

# ==================== 函数 ====================

# 打印带颜色的消息
print_info() {
    echo -e "\033[0;34m[INFO]\033[0m $1"
}

print_success() {
    echo -e "\033[0;32m[SUCCESS]\033[0m $1"
}

print_error() {
    echo -e "\033[0;31m[ERROR]\033[0m $1"
}

# 生成 Frontmatter
generate_frontmatter() {
    local filename="$1"
    local filetype="$2"
    local tags="$3"
    local timestamp=$(date +"%Y-%m-%d %H:%M")
    
    cat << EOF
---
created: $timestamp
source: OpenClaw Workspace
type: $filetype
tags: [$tags]
---

EOF
}

# 同步单个文件
sync_file() {
    local filename="$1"
    local source_path="$OPENCLAW_WORKSPACE/$filename"
    local target_filename="$2"
    local target_path="$TARGET_DIR/$target_filename"
    
    # 检查源文件是否存在
    if [ ! -f "$source_path" ]; then
        print_error "源文件不存在：$source_path"
        return 1
    fi
    
    # 获取文件类型和标签
    local filetype="${FILE_TYPES[$filename]}"
    local tags="${FILE_TAGS[$filename]}"
    
    # 生成 Frontmatter
    local frontmatter=$(generate_frontmatter "$filename" "$filetype" "$tags")
    
    # 读取源文件内容
    local content=$(cat "$source_path")
    
    # 写入目标文件（Frontmatter + 原内容）
    echo "$frontmatter" > "$target_path"
    echo "$content" >> "$target_path"
    
    # 获取文件大小
    local filesize=$(ls -lh "$target_path" | awk '{print $5}')
    
    print_success "同步 $filename → $target_filename ($filesize)"
}

# ==================== 主流程 ====================

main() {
    print_info "=== memo-sync - OpenClaw 配置文件同步工具 ==="
    print_info "版本：1.0.0"
    
    # 1. 确定目标文件夹
    if [ -n "$1" ]; then
        # 用户指定了日期
        TARGET_DATE="$1"
    else
        # 使用今日日期
        TARGET_DATE=$(date +%Y-%m-%d)
    fi
    
    TARGET_DIR="$OBSIDIAN_VAULT_PATH/$MEMO_SYNC_FOLDER/$TARGET_DATE"
    
    print_info "目标文件夹：$TARGET_DIR"
    
    # 2. 检查 Vault 路径
    if [ ! -d "$OBSIDIAN_VAULT_PATH" ]; then
        print_error "Obsidian Vault 路径不存在：$OBSIDIAN_VAULT_PATH"
        print_info "请检查 OBSIDIAN_VAULT_PATH 环境变量或创建该目录"
        exit 1
    fi
    
    # 3. 创建目标文件夹
    print_info "创建目标文件夹..."
    mkdir -p "$TARGET_DIR"
    print_success "文件夹已准备：$TARGET_DIR"
    
    # 4. 同步文件
    print_info "开始同步文件..."
    echo ""
    
    local file_number=1
    for filename in "${SYNC_FILES[@]}"; do
        # 生成带编号的目标文件名
        target_filename=$(printf "%02d-%s" $file_number "$filename")
        
        # 同步文件
        sync_file "$filename" "$target_filename"
        
        ((file_number++))
    done
    
    echo ""
    
    # 5. 统计信息
    print_info "=== 同步完成 ==="
    print_success "同步文件数：${#SYNC_FILES[@]}"
    print_info "存储位置：$TARGET_DIR"
    echo ""
    
    # 列出所有文件
    print_info "文件清单："
    ls -lh "$TARGET_DIR" | tail -n +2 | awk '{print "  " $9 " - " $5}'
    
    echo ""
    print_success "✅ 所有文件已成功同步到 Obsidian！"
}

# 显示帮助
show_help() {
    cat << EOF
memo-sync - OpenClaw 配置文件同步工具

用法：
  $0 [日期]

参数：
  日期    可选，目标日期文件夹（格式：YYYY-MM-DD）
          默认为今日日期

示例：
  $0                    # 同步到今日文件夹（2026-04-02）
  $0 2026-04-01        # 同步到指定日期文件夹

环境变量：
  OBSIDIAN_VAULT_PATH   Obsidian Vault 路径（默认：/home/jasoncool/Obs_Openclaw_mem/OpenClaw 记忆）
  MEMO_SYNC_FOLDER      同步目标文件夹（默认：muliu_memo）

EOF
}

# 处理参数
if [ "$1" == "-h" ] || [ "$1" == "--help" ]; then
    show_help
    exit 0
fi

# 执行主流程
main "$@"
