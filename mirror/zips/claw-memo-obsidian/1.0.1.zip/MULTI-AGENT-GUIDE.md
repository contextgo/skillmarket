# memo-sync v2.0.0 多智能体使用指南

**发布时间**：2026-04-02  
**版本**：2.0.0（支持多智能体）

---

## 🎉 新功能亮点

### 1. 配置文件支持

**位置**：`~/.memo-sync-config.json`

**作用**：
- 不同智能体有自己的配置
- 用户可自定义，不需要改代码
- 支持多 Vault、多工作区

**示例配置**：
```json
{
  "agents": {
    "openclaw": {
      "workspace": "/home/jasoncool/.openclaw/workspace",
      "files": ["AGENTS.md", "MEMORY.md"],
      "frontmatter": {"source": "OpenClaw Workspace"}
    },
    "claude-code": {
      "workspace": "/home/jasoncool/claude-projects",
      "files": ["CLAUDE.md", "PROJECT.md"],
      "frontmatter": {"source": "Claude Code Workspace"}
    }
  }
}
```

---

### 2. 智能体自动识别

**支持的平台**：
- ✅ OpenClaw
- ✅ Claude Code
- ✅ Codex
- ✅ 自定义智能体

**识别方式**：
1. 环境变量检测
2. 工作区特征文件
3. 手动指定（`--agent`）

---

### 3. 动态 Frontmatter

**根据智能体自动调整**：

**OpenClaw**：
```yaml
---
created: 2026-04-02 15:41
source: OpenClaw Workspace
type: 助手配置
tags: [openclaw, assistant]
agent: 木流 2 号
---
```

**Claude Code**：
```yaml
---
created: 2026-04-02 15:41
source: Claude Code Workspace
type: 项目文档
tags: [claude, project]
agent: claude-code
---
```

---

## 🚀 快速开始

### 安装

配置文件已创建：
```bash
~/.memo-sync-config.json
```

技能位置：
```bash
/home/jasoncool/.openclaw/workspace/skills/memo-sync/
```

---

### 基础用法

```bash
# 自动检测智能体并同步
python3 memo-sync.py

# 指定智能体
python3 memo-sync.py --agent openclaw

# 指定日期
python3 memo-sync.py -d "昨天"

# 只同步部分文件
python3 memo-sync.py -f AGENTS.md MEMORY.md
```

---

### 多智能体使用

#### OpenClaw

```bash
# 自动检测
python3 memo-sync.py

# 或手动指定
python3 memo-sync.py --agent openclaw
```

**同步内容**：
- AGENTS.md, IDENTITY.md, MEMORY.md, SOUL.md, USER.md
- Frontmatter: `source: OpenClaw Workspace`

---

#### Claude Code

```bash
# 手动指定
python3 memo-sync.py --agent claude-code
```

**同步内容**：
- CLAUDE.md, PROJECT.md, NOTES.md
- Frontmatter: `source: Claude Code Workspace`

---

#### Codex

```bash
# 手动指定
python3 memo-sync.py --agent codex
```

**同步内容**：
- CODEX.md, CONFIG.md
- Frontmatter: `source: Codex Workspace`

---

## ⚙️ 配置详解

### 配置文件结构

```json
{
  "workspace": "/home/jasoncool/.openclaw/workspace",
  "obsidian_vault": "/home/jasoncool/Obs_Openclaw_mem/OpenClaw 记忆",
  "sync_folder": "muliu_memo",
  
  "files": ["AGENTS.md", "IDENTITY.md", "MEMORY.md", "SOUL.md", "USER.md"],
  
  "frontmatter": {
    "source": "OpenClaw Workspace",
    "default_tags": ["openclaw", "assistant", "config"],
    "custom_fields": {
      "agent": "木流 2 号",
      "platform": "feishu"
    }
  },
  
  "agents": {
    "openclaw": { ... },
    "claude-code": { ... },
    "codex": { ... }
  },
  
  "targets": [ ... ],
  
  "options": {
    "auto_detect_agent": true,
    "confirm_before_delete": true
  }
}
```

---

### 配置文件查找顺序

1. **当前工作目录** `.memo-sync-config.json`
2. **用户主目录** `~/.memo-sync-config.json`
3. **系统级** `/etc/memo-sync/config.json`
4. **默认配置**（硬编码）

---

### 智能体配置示例

```json
{
  "agents": {
    "openclaw": {
      "workspace": "/home/jasoncool/.openclaw/workspace",
      "files": ["AGENTS.md", "IDENTITY.md", "MEMORY.md", "SOUL.md", "USER.md"],
      "frontmatter": {
        "source": "OpenClaw Workspace",
        "tags": ["openclaw", "assistant"],
        "custom_fields": {
          "agent": "木流 2 号"
        }
      }
    },
    "claude-code": {
      "workspace": "/home/jasoncool/claude-projects/my-project",
      "files": ["CLAUDE.md", "PROJECT.md", "NOTES.md"],
      "frontmatter": {
        "source": "Claude Code Workspace",
        "tags": ["claude", "project"],
        "custom_fields": {}
      }
    },
    "codex": {
      "workspace": "/home/jasoncool/codex-projects/agent",
      "files": ["CODEX.md", "CONFIG.md"],
      "frontmatter": {
        "source": "Codex Workspace",
        "tags": ["codex", "agent"]
      }
    }
  }
}
```

---

## 📊 命令行参数

```bash
python3 memo-sync.py [选项]

基本选项:
  -d, --date DATE       目标日期（YYYY-MM-DD 或自然语言）
  -f, --files FILE [...] 要同步的文件列表
  --natural-date DATE   自然语言日期（如"昨天"）
  --vault PATH          Obsidian Vault 路径
  --workspace PATH      工作区路径
  --folder NAME         同步文件夹名称

多智能体选项:
  --agent NAME          指定智能体（openclaw/claude-code/codex）
  --config PATH         配置文件路径

清理选项:
  --clean               清理模式（删除指定日期文件夹）
  --confirmed           跳过二次确认

其他:
  -v, --version         显示版本号
  -h, --help            显示帮助
```

---

## 🔧 高级用法

### 1. 项目级配置

在项目根目录创建 `.memo-sync-config.json`：

```json
{
  "workspace": "/home/jasoncool/my-project",
  "files": ["README.md", "NOTES.md"],
  "frontmatter": {
    "source": "My Project"
  }
}
```

然后在项目中运行：
```bash
cd /home/jasoncool/my-project
python3 memo-sync.py
```

会自动使用项目级配置！

---

### 2. 多 Vault 同步

配置多个同步目标：

```json
{
  "targets": [
    {
      "name": "主 Vault",
      "path": "/home/jasoncool/Obs_Openclaw_mem/OpenClaw 记忆",
      "folder": "muliu_memo",
      "enabled": true
    },
    {
      "name": "备份 Vault",
      "path": "~/Dropbox/Obsidian",
      "folder": "openclaw-backup",
      "enabled": true
    }
  ]
}
```

---

### 3. 自定义 Frontmatter 字段

```json
{
  "frontmatter": {
    "source": "My Workspace",
    "default_tags": ["custom", "tags"],
    "custom_fields": {
      "alias": "我的别名",
      "cssclasses": "custom-class",
      "published": true
    }
  }
}
```

---

## 🐛 故障排查

### 问题 1：找不到配置文件

**错误**：`未找到配置文件，使用默认配置`

**解决**：
```bash
# 检查配置文件是否存在
ls -la ~/.memo-sync-config.json

# 如果不存在，创建模板
cp /home/jasoncool/.memo-sync-config.json.example ~/.memo-sync-config.json
```

---

### 问题 2：智能体识别错误

**错误**：`智能体：unknown`

**解决**：
```bash
# 手动指定智能体
python3 memo-sync.py --agent openclaw

# 或设置环境变量
export OPENCLAW_WORKSPACE=/home/jasoncool/.openclaw/workspace
```

---

### 问题 3：Frontmatter 不符合预期

**解决**：
1. 检查配置文件中的 `frontmatter` 部分
2. 检查智能体特定配置中的 `frontmatter`
3. 智能体配置会覆盖全局配置

---

## 📚 相关文档

- `SKILL.md` - 技能主文档
- `README.md` - 完整使用文档
- `QUICKSTART.md` - 快速开始指南
- `~/.memo-sync-config.json` - 配置文件模板

---

## 🌲 版本历史

| 版本 | 日期 | 核心功能 |
|------|------|---------|
| v1.0.0 | 2026-04-02 | 初始版本 |
| v1.1.0 | 2026-04-02 | 自然语言日期解析 |
| v1.2.0 | 2026-04-02 | 删除前二次确认 |
| v2.0.0 | 2026-04-02 | 多智能体支持 🎉 |

---

> **提示**：v2.0.0 是重大更新，配置文件格式可能变化，请检查 `~/.memo-sync-config.json` 是否为最新版本。
