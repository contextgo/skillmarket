# memo-sync 快速使用指南

## 🚀 三种使用方法

### 方法 1：自然语言（最简单）

在飞书中直接对木流 2 号说：

```
同步核心文件到 Obsidian
```

或

```
把 AGENTS.md、MEMORY.md 等文件备份到 Obsidian
```

**优点**：无需记忆命令，自动处理所有细节

---

### 方法 2：Python 脚本（最灵活）

```bash
# 基础用法 - 同步到今日文件夹
python3 ~/.openclaw/workspace/skills/memo-sync/memo-sync.py

# 指定日期
python3 ~/.openclaw/workspace/skills/memo-sync/memo-sync.py -d 2026-04-02

# 只同步部分文件
python3 ~/.openclaw/workspace/skills/memo-sync/memo-sync.py -f AGENTS.md MEMORY.md

# 查看帮助
python3 ~/.openclaw/workspace/skills/memo-sync/memo-sync.py --help
```

**优点**：支持自定义参数，适合高级用户

---

### 方法 3：Bash 脚本（最简洁）

```bash
# 同步到今日
~/.openclaw/workspace/skills/memo-sync/memo-sync.sh

# 同步到指定日期
~/.openclaw/workspace/skills/memo-sync/memo-sync.sh 2026-04-02
```

**优点**：命令简短，易于记忆

---

## 📁 输出位置

同步的文件保存在：

```
~/Obs_Openclaw_mem/OpenClaw 记忆/muliu_memo/日期/
```

例如：
```
/home/jasoncool/Obs_Openclaw_mem/OpenClaw 记忆/muliu_memo/2026-04-02/
├── 01-AGENTS.md
├── 02-IDENTITY.md
├── 03-MEMORY.md
├── 04-SOUL.md
└── 05-USER.md
```

---

## ✅ 使用场景

### 场景 1：每日备份

每天工作结束时同步一次：

```bash
# 添加到每日例行工作
python3 memo-sync.py
```

### 场景 2：重大变更后

修改了 AGENTS.md 或 MEMORY.md 后立即同步：

```
（在飞书中）同步最新配置到 Obsidian
```

### 场景 3：定期归档

每周或每月同步一次，保留历史版本：

```bash
# 每周一上午 9 点同步
crontab -e
# 添加：0 9 * * 1 python3 ~/.openclaw/workspace/skills/memo-sync/memo-sync.py
```

---

## 🔧 常见问题

### Q1: 如何修改同步的文件夹名称？

**答**：使用环境变量或参数：

```bash
# 方法 1：环境变量
export MEMO_SYNC_FOLDER="my-memos"
python3 memo-sync.py

# 方法 2：命令行参数
python3 memo-sync.py --folder my-memos
```

### Q2: 如何同步到不同的 Obsidian Vault？

**答**：指定 Vault 路径：

```bash
python3 memo-sync.py --vault ~/MyVault
```

### Q3: 可以只同步 MEMORY.md 吗？

**答**：可以，使用 `-f` 参数：

```bash
python3 memo-sync.py -f MEMORY.md
```

### Q4: 同步后文件在哪里查看？

**答**：在 Obsidian 中打开 Vault，导航到 `muliu_memo/日期/` 文件夹。

---

## 📊 输出示例

```
[INFO] === memo-sync - OpenClaw 配置文件同步工具 ===
[INFO] 版本：1.0.0
[INFO] 目标文件夹：/home/jasoncool/Obs_Openclaw_mem/OpenClaw 记忆/muliu_memo/2026-04-02
[INFO] 创建目标文件夹...
[SUCCESS] 文件夹已准备
[INFO] 开始同步文件...

[SUCCESS] 同步 AGENTS.md → 01-AGENTS.md (11.1K)
[SUCCESS] 同步 IDENTITY.md → 02-IDENTITY.md (308.0B)
[SUCCESS] 同步 MEMORY.md → 03-MEMORY.md (9.4K)
[SUCCESS] 同步 SOUL.md → 04-SOUL.md (2.2K)
[SUCCESS] 同步 USER.md → 05-USER.md (446.0B)

[SUCCESS] ✅ 所有文件已成功同步到 Obsidian！
```

---

## 🌲 更多信息

- 完整文档：`skills/memo-sync/README.md`
- 技能说明：`skills/memo-sync/SKILL.md`
- 作者：木流 2 号 🌲

---

> **提示**：推荐使用自然语言方式，木流 2 号会自动处理所有细节！
