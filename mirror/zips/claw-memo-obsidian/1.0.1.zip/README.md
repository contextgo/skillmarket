# memo-sync

**OpenClaw 核心配置文件同步工具** - 将 OpenClaw 的 AGENTS.md、MEMORY.md 等核心文件自动同步到 Obsidian 知识库。

---

## 🚀 快速开始

### 安装

技能已位于：
```
/home/jasoncool/.openclaw/workspace/skills/memo-sync/
```

### 使用方法

#### 方法 1：通过自然语言（推荐）

在飞书对话中直接说：
```
同步核心文件到 Obsidian
```

#### 方法 2：使用 Python 脚本

```bash
# 同步到今日文件夹
python3 ~/.openclaw/workspace/skills/memo-sync/memo-sync.py

# 同步到指定日期
python3 ~/.openclaw/workspace/skills/memo-sync/memo-sync.py -d 2026-04-02

# 只同步指定文件
python3 ~/.openclaw/workspace/skills/memo-sync/memo-sync.py -f AGENTS.md MEMORY.md

# 指定 Obsidian Vault 路径
python3 ~/.openclaw/workspace/skills/memo-sync/memo-sync.py --vault ~/MyVault
```

#### 方法 3：使用 Bash 脚本

```bash
# 同步到今日文件夹
~/.openclaw/workspace/skills/memo-sync/memo-sync.sh

# 同步到指定日期
~/.openclaw/workspace/skills/memo-sync/memo-sync.sh 2026-04-02
```

---

## 📁 同步的文件

默认同步以下 5 个核心文件：

| 源文件 | 目标文件 | 说明 | Frontmatter 标签 |
|--------|---------|------|-----------------|
| `AGENTS.md` | `01-AGENTS.md` | 助手工作区配置 | `#agents #workspace #memory` |
| `IDENTITY.md` | `02-IDENTITY.md` | 助手身份信息 | `#identity #soul #assistant` |
| `MEMORY.md` | `03-MEMORY.md` | 长期记忆 | `#memory #user-info #skills` |
| `SOUL.md` | `04-SOUL.md` | 助手灵魂/人格 | `#soul #persona #behavior` |
| `USER.md` | `05-USER.md` | 用户信息 | `#user #profile #context` |

---

## 📂 输出结构

```
Obsidian Vault/
└── muliu_memo/
    └── 2026-04-02/          # 日期文件夹
        ├── 01-AGENTS.md     # 带 Frontmatter
        ├── 02-IDENTITY.md   # 带 Frontmatter
        ├── 03-MEMORY.md     # 带 Frontmatter
        ├── 04-SOUL.md       # 带 Frontmatter
        └── 05-USER.md       # 带 Frontmatter
```

### Frontmatter 示例

```yaml
---
created: 2026-04-02 14:15
source: OpenClaw Workspace
type: 助手配置
tags: [agents, workspace, memory, workflow]
---

# 原始文件内容...
```

---

## ⚙️ 配置选项

### 环境变量

| 变量 | 默认值 | 说明 |
|------|--------|------|
| `OBSIDIAN_VAULT_PATH` | `/home/jasoncool/Obs_Openclaw_mem/OpenClaw 记忆` | Obsidian Vault 根路径 |
| `MEMO_SYNC_FOLDER` | `muliu_memo` | 同步目标文件夹名称 |
| `OPENCLAW_WORKSPACE` | `/home/jasoncool/.openclaw/workspace` | OpenClaw 工作区路径 |

### 命令行参数

```bash
python3 memo-sync.py [选项]

选项:
  -d, --date DATE       目标日期文件夹（YYYY-MM-DD）
  -f, --files FILE [...] 要同步的文件列表
  --vault PATH          Obsidian Vault 路径
  --workspace PATH      OpenClaw 工作区路径
  --folder NAME         同步目标文件夹名称
  -v, --version         显示版本号
  -h, --help            显示帮助信息
```

---

## 🔧 高级用法

### 1. 定期同步（Cron）

添加定时任务，每天自动同步：

```bash
# 编辑 crontab
crontab -e

# 添加每天凌晨 2 点同步
0 2 * * * python3 /home/jasoncool/.openclaw/workspace/skills/memo-sync/memo-sync.py
```

### 2. Git 版本控制

在 Obsidian Vault 中启用 Git：

```bash
cd ~/Obs_Openclaw_mem/OpenClaw\ 记忆
git init
git add muliu_memo/
git commit -m "Initial memo-sync backup"

# 后续同步后自动提交
python3 memo-sync.py && git add muliu_memo/ && git commit -m "Daily sync $(date +%Y-%m-%d)"
```

### 3. 自定义文件列表

创建自定义配置文件 `~/.memo-sync-config.json`：

```json
{
  "files": ["AGENTS.md", "MEMORY.md"],
  "folder": "my-memos",
  "vault": "~/MyVault"
}
```

---

## 🐛 故障排查

### 问题 1：Vault 路径不存在

**错误**：`Obsidian Vault 路径不存在`

**解决**：
```bash
# 检查路径
ls -la ~/Obs_Openclaw_mem/

# 或指定正确的路径
python3 memo-sync.py --vault ~/MyVault
```

### 问题 2：权限错误

**错误**：`Permission denied`

**解决**：
```bash
# 修复权限
chmod u+w ~/Obs_Openclaw_mem/OpenClaw\ 记忆/muliu_memo
```

### 问题 3：中文乱码

**解决**：
- 确保脚本使用 UTF-8 编码
- 在 Obsidian 中设置默认编码为 UTF-8

---

## 📊 同步示例

### 完整同步

```bash
$ python3 memo-sync.py

[INFO] === memo-sync - OpenClaw 配置文件同步工具 ===
[INFO] 版本：1.0.0
[INFO] 目标文件夹：/home/jasoncool/Obs_Openclaw_mem/OpenClaw 记忆/muliu_memo/2026-04-02
[INFO] 创建目标文件夹...
[SUCCESS] 文件夹已准备：/home/jasoncool/Obs_Openclaw_mem/OpenClaw 记忆/muliu_memo/2026-04-02
[INFO] 开始同步文件...

[SUCCESS] 同步 AGENTS.md → 01-AGENTS.md (11.1K)
[SUCCESS] 同步 IDENTITY.md → 02-IDENTITY.md (308.0B)
[SUCCESS] 同步 MEMORY.md → 03-MEMORY.md (9.4K)
[SUCCESS] 同步 SOUL.md → 04-SOUL.md (2.2K)
[SUCCESS] 同步 USER.md → 05-USER.md (446.0B)

[INFO] === 同步完成 ===
[SUCCESS] 同步文件数：5/5
[INFO] 存储位置：/home/jasoncool/Obs_Openclaw_mem/OpenClaw 记忆/muliu_memo/2026-04-02

[INFO] 文件清单：
  01-AGENTS.md - 11.1K
  02-IDENTITY.md - 308.0B
  03-MEMORY.md - 9.4K
  04-SOUL.md - 2.2K
  05-USER.md - 446.0B

[SUCCESS] ✅ 所有文件已成功同步到 Obsidian！
```

---

## 🔄 更新日志

### v1.0.0 (2026-04-02)

- ✅ 初始版本发布
- ✅ 支持 5 个核心文件同步
- ✅ 自动添加 Frontmatter 元数据
- ✅ 支持按日期归档
- ✅ Python 和 Bash 双版本
- ✅ 完整的错误处理和用户反馈
- ✅ 支持命令行参数和环境变量配置

---

## 📚 相关技能

- [obsidian-cli](../obsidian-cli/) - Obsidian CLI 集成
- [feishu-create-doc](../feishu-create-doc/) - 飞书文档创建
- [skill-creator](../skill-creator/) - 技能创建工具

---

## 🌲 作者

**木流 2 号** 🌲

- 平台：OpenClaw + 飞书
- 风格：专业 + 温暖
- 创建时间：2026-04-02

---

## 📄 许可证

本技能作为 OpenClaw Workspace 的一部分，遵循相同的许可条款。

---

> **提示**：在 Obsidian 中打开同步的文件夹，可以查看带 Frontmatter 的 Markdown 文件，支持标签搜索和双向链接。
