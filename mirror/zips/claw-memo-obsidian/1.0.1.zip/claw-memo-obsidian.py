#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
claw-memo-obsidian.py - OpenClaw 核心文件同步到 Obsidian 工具

版本：2.0.0
创建时间：2026-04-02
改进时间：2026-04-02（支持多智能体）
作者：木流 2 号 🌲

功能：
- 同步 OpenClaw 核心配置文件到 Obsidian
- 自动添加 Frontmatter 元数据
- 支持按日期归档
- 支持自定义文件列表
- 🆕 支持配置文件（~/.memo-sync-config.json）
- 🆕 支持多智能体自动识别
- 🆕 支持动态 Frontmatter 生成
- 🆕 支持多级配置查找
"""

import os
import sys
import shutil
import re
import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Any

# ==================== 配置 ====================

# 默认配置（fallback）
DEFAULT_CONFIG = {
    "workspace": str(Path.home() / ".openclaw" / "workspace"),
    "obsidian_vault": str(Path.home() / "Obs_Openclaw_mem" / "OpenClaw 记忆"),
    "sync_folder": "muliu_memo",  # 全局 fallback
    "files": ["AGENTS.md", "IDENTITY.md", "MEMORY.md", "SOUL.md", "USER.md"],
    "frontmatter": {
        "source": "OpenClaw Workspace",
        "default_tags": ["openclaw", "assistant"],
    },
    "agents": {},
    "targets": [],
    "options": {
        "auto_detect_agent": True,
        "confirm_before_delete": True,
    }
}

# 智能体默认文件夹映射（当智能体配置中没有指定 sync_folder 时使用）
AGENT_DEFAULT_FOLDERS = {
    "openclaw": "muliu_memo",
    "claude-code": "claude_memo",
    "codex": "codex_memo",
    "unknown": "memo",
}

# 配置文件查找路径（优先级从高到低）
CONFIG_PATHS = [
    Path.cwd() / ".memo-sync-config.json",  # 当前工作目录
    Path.home() / ".memo-sync-config.json",  # 用户主目录
    Path("/etc/memo-sync/config.json"),  # 系统级配置
]

# ==================== 工具函数 ====================


def load_config(config_path: Optional[Path] = None) -> dict:
    """
    加载配置文件

    查找顺序：
    1. 用户指定的配置文件
    2. 当前工作目录
    3. 用户主目录
    4. 默认配置

    Args:
        config_path: 指定的配置文件路径

    Returns:
        配置字典
    """
    config = DEFAULT_CONFIG.copy()

    # 确定配置文件路径
    if config_path:
        paths_to_check = [config_path]
    else:
        paths_to_check = CONFIG_PATHS

    # 查找并加载第一个存在的配置文件
    for path in paths_to_check:
        if path.exists():
            try:
                with open(path, "r", encoding="utf-8") as f:
                    file_config = json.load(f)
                    # 深度合并配置
                    config = deep_merge(config, file_config)
                    print(f"\033[0;32m[SUCCESS]\033[0m 加载配置文件：{path}")
                    return config
            except Exception as e:
                print(f"\033[0;33m[WARNING]\033[0m 配置文件加载失败：{path} - {str(e)}")

    # 没有配置文件，使用默认配置
    print("\033[0;34m[INFO]\033[0m 未找到配置文件，使用默认配置")
    return config


def deep_merge(base: dict, override: dict) -> dict:
    """
    深度合并两个字典

    Args:
        base: 基础字典
        override: 覆盖字典

    Returns:
        合并后的字典
    """
    result = base.copy()
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def detect_agent() -> str:
    """
    检测当前运行的智能体

    检测顺序：
    1. 环境变量
    2. 工作区特征文件
    3. 进程名（未来扩展）

    Returns:
        智能体名称（openclaw/claude-code/codex/unknown）
    """
    # 1. 检查环境变量
    if os.getenv("OPENCLAW_SESSION") or os.getenv("OPENCLAW_WORKSPACE"):
        return "openclaw"
    elif os.getenv("CODEX_SESSION") or os.getenv("CODEX_WORKSPACE"):
        return "codex"
    elif os.getenv("CLAUDE_CODE_SESSION"):
        return "claude-code"

    # 2. 检查工作区特征文件（如果已经加载了配置）
    # 这一步在 load_config 之后进行

    return "unknown"


def get_agent_config(config: dict, agent: str) -> dict:
    """
    获取指定智能体的配置

    Args:
        config: 完整配置
        agent: 智能体名称

    Returns:
        智能体配置（如果没有则返回基础配置）
    """
    agents = config.get("agents", {})
    if agent in agents:
        return agents[agent]
    return {}


def parse_natural_date(date_str: str) -> str:
    """
    解析自然语言日期

    支持：
    - "今天" → 2026-04-02
    - "昨天" → 2026-04-01
    - "前天" → 2026-03-31
    - "3 天前" → 2026-03-30
    - "2026-04-01" → 2026-04-01

    Args:
        date_str: 日期字符串（自然语言或 YYYY-MM-DD 格式）

    Returns:
        YYYY-MM-DD 格式的日期字符串
    """
    if not date_str:
        return datetime.now().strftime("%Y-%m-%d")

    # 去除空格
    date_str = date_str.strip()

    # 中文日期关键词
    if date_str in ["今天", "今日", "today"]:
        return datetime.now().strftime("%Y-%m-%d")
    elif date_str in ["昨天", "昨日", "yesterday"]:
        return (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
    elif date_str in ["前天", "the day before yesterday"]:
        return (datetime.now() - timedelta(days=2)).strftime("%Y-%m-%d")
    elif "天前" in date_str or "days ago" in date_str.lower():
        # 提取数字
        match = re.search(r'(\d+)', date_str)
        if match:
            days = int(match.group(1))
            return (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")

    # 尝试解析 YYYY-MM-DD 格式
    try:
        datetime.strptime(date_str, "%Y-%m-%d")
        return date_str
    except ValueError:
        # 如果解析失败，返回今日日期
        print(f"\033[0;33m[WARNING]\033[0m 无法解析日期 '{date_str}'，使用今日日期")
        return datetime.now().strftime("%Y-%m-%d")


def parse_files_from_input(user_input: str) -> Optional[List[str]]:
    """
    从用户输入中提取文件名列表

    支持：
    - "只同步 MEMORY.md" → ["MEMORY.md"]
    - "同步 AGENTS.md 和 USER.md" → ["AGENTS.md", "USER.md"]
    - "同步 AGENTS.md, MEMORY.md" → ["AGENTS.md", "MEMORY.md"]

    Args:
        user_input: 用户输入字符串

    Returns:
        文件名列表，如果没有找到则返回 None
    """
    # 匹配所有 .md 结尾的文件名（大写字母 + 下划线）
    files = re.findall(r'([A-Z_]+\.md)', user_input)
    return files if files else None


def format_filesize(size_bytes: int) -> str:
    """格式化文件大小"""
    for unit in ["B", "K", "M", "G"]:
        if size_bytes < 1024.0:
            return f"{size_bytes:.1f}{unit}"
        size_bytes /= 1024.0
    return f"{size_bytes:.1f}T"


def generate_frontmatter(filename: str, file_config: dict, agent: str, config: dict) -> str:
    """
    动态生成 Frontmatter 元数据

    Args:
        filename: 源文件名
        file_config: 文件配置（包含 type 和 tags）
        agent: 当前智能体名称
        config: 完整配置

    Returns:
        YAML Frontmatter 字符串
    """
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")

    # 获取 Frontmatter 配置
    fm_config = config.get("frontmatter", {})
    agent_config = get_agent_config(config, agent)
    agent_fm = agent_config.get("frontmatter", {})

    # 合并配置（智能体配置优先）
    source = agent_fm.get("source", fm_config.get("source", f"{agent.title()} Workspace"))
    tags = agent_fm.get("tags", fm_config.get("default_tags", []))
    custom_fields = agent_fm.get("custom_fields", fm_config.get("custom_fields", {}))

    # 构建 Frontmatter 字段
    fields = {
        "created": timestamp,
        "source": source,
        "type": file_config.get("type", "配置文件"),
        "tags": tags,
        "agent": agent if agent != "unknown" else "auto",
    }

    # 添加自定义字段
    for key, value in custom_fields.items():
        fields[key] = value

    # 生成 YAML
    yaml_str = "---\n"
    for key, value in fields.items():
        if isinstance(value, list):
            yaml_str += f"{key}: [{', '.join(value)}]\n"
        elif isinstance(value, str):
            yaml_str += f"{key}: {value}\n"
        else:
            yaml_str += f"{key}: {value}\n"
    yaml_str += "---\n\n"

    return yaml_str


def confirm_deletion(items: List[dict]) -> bool:
    """
    删除前的二次确认

    Args:
        items: 待删除项目列表，每项包含 path 和 size

    Returns:
        用户是否确认删除
    """
    print("\n\033[0;33m⚠️  二次确认\033[0m")
    print("\n\033[0;31m操作：\033[0m 删除以下文件夹")
    print()

    def format_size(size_bytes: int) -> str:
        """格式化文件大小"""
        for unit in ["B", "K", "M", "G"]:
            if size_bytes < 1024.0:
                return f"{size_bytes:.1f}{unit}"
            size_bytes /= 1024.0
        return f"{size_bytes:.1f}T"

    total_size = 0
    for item in items:
        path = item['path']
        size = item.get('size', 0)
        total_size += size
        size_str = format_size(size) if size else "未知"
        print(f"  - {path} ({size_str})")

    print()
    print(f"\033[0;33m影响：\033[0m {len(items)} 个文件夹，共约 {format_size(total_size)}")
    print()

    # 注意：实际确认由 AI 在对话中完成，这里只打印提示
    print('\033[0;33m是否确认删除？请回复"确认删除"或"是的"，我才会执行。\033[0m')

    return True  # 实际确认由 AI 处理，这里返回 True 继续流程


# ==================== 类定义 ====================


class MemoSync:
    """OpenClaw 配置文件同步器（支持多智能体）"""

    def __init__(
        self,
        config: Optional[dict] = None,
        agent: Optional[str] = None,
    ):
        """初始化同步器

        Args:
            config: 配置字典（默认从配置文件加载）
            agent: 智能体名称（默认自动检测）
        """
        # 加载配置
        self.config = config if config else load_config()

        # 检测智能体
        if agent:
            self.agent = agent
        elif self.config.get("options", {}).get("auto_detect_agent", True):
            self.agent = detect_agent()
        else:
            self.agent = "unknown"

        # 获取智能体特定配置
        agent_config = get_agent_config(self.config, self.agent)

        # 🎯 强制规则：不管从哪里调用，优先检查向上查找最近的 AGENTS.md
        # 这样技能本身在 skills/ 文件夹，调用时从工作区目录运行，就能找到正确的工作区
        def find_nearest_agencies(start_dir: Path) -> Optional[Path]:
            """从当前目录向上查找最近的 AGENTS.md"""
            current = start_dir
            while current != current.parent:  # 还没到根目录
                if (current / "AGENTS.md").exists():
                    return current
                current = current.parent
            return None
        
        found_workspace = find_nearest_agencies(Path.cwd())
        if found_workspace:
            # 找到了最近的 AGENTS.md，这个就是当前智能体的工作区
            self.workspace = found_workspace
            self.print_info(f"✅ 自动检测到智能体工作区: {self.workspace}")
        else:
            # 没找到，回退到配置
            self.workspace = Path(agent_config.get("workspace", self.config["workspace"]))
            self.print_info(f"ℹ️  使用配置中的工作区: {self.workspace}")
        
        self.vault = Path(self.config["obsidian_vault"])
        
        # 🔴 强制规则：总是从工作区路径推导 sync_folder，除非用户明确强制指定
        # 你的要求："优先检查自己的工作空间名称，当备份的时候优先备份到自己的工作空间名称所演化的记忆文件夹下"
        # 所以：只要工作区名称格式规范，**总是**使用推导出来的文件夹，忽略配置中的 sync_folder
        workspace_name = self.workspace.name
        if workspace_name.replace('-', '_').isidentifier():
            # 转换为 snake_case 并加 _memo 后缀
            derived_folder = re.sub(r'[-\s]', '_', workspace_name).lower() + '_memo'
            self.sync_folder = derived_folder
            self.print_info(f"✅ 强制推导同步文件夹: {workspace_name} → {self.sync_folder}")
        else:
            # 工作区名称不规范，才回退到配置
            if "sync_folder" in agent_config:
                self.sync_folder = agent_config["sync_folder"]
                self.print_info(f"⚠️ 工作区名称不规范，使用配置指定: {self.sync_folder}")
            else:
                self.sync_folder = AGENT_DEFAULT_FOLDERS.get(
                    self.agent, 
                    self.config.get("sync_folder", "memo")
                )
                self.print_info(f"ℹ️ 使用默认同步文件夹: {self.sync_folder}")
        
        self.files = agent_config.get("files", self.config["files"])

        # 构建文件配置
        self.files_config = self._build_files_config()

    def _build_files_config(self) -> dict:
        """
        构建文件配置

        Returns:
            文件配置字典
        """
        # 默认文件类型映射
        type_mapping = {
            "AGENTS.md": "助手配置",
            "IDENTITY.md": "助手身份",
            "MEMORY.md": "长期记忆",
            "SOUL.md": "助手灵魂",
            "USER.md": "用户信息",
            "CLAUDE.md": "Claude 配置",
            "PROJECT.md": "项目文档",
            "NOTES.md": "笔记",
            "CODEX.md": "Codex 配置",
            "CONFIG.md": "配置文件",
        }

        files_config = {}
        for filename in self.files:
            files_config[filename] = {
                "target": filename,  # 默认保持原名
                "type": type_mapping.get(filename, "配置文件"),
                "tags": [],
            }
        return files_config

    def print_info(self, message: str):
        """打印信息消息"""
        print(f"\033[0;34m[INFO]\033[0m {message}")

    def print_success(self, message: str):
        """打印成功消息"""
        print(f"\033[0;32m[SUCCESS]\033[0m {message}")

    def print_error(self, message: str):
        """打印错误消息"""
        print(f"\033[0;31m[ERROR]\033[0m {message}")

    def print_warning(self, message: str):
        """打印警告消息"""
        print(f"\033[0;33m[WARNING]\033[0m {message}")

    def sync_file(
        self, filename: str, file_config: dict, target_dir: Path
    ) -> bool:
        """同步单个文件

        Args:
            filename: 源文件名
            file_config: 文件配置
            target_dir: 目标目录

        Returns:
            是否成功
        """
        source_path = self.workspace / filename
        target_path = target_dir / file_config["target"]

        # 检查源文件是否存在
        if not source_path.exists():
            self.print_error(f"源文件不存在：{source_path}")
            return False

        # 读取源文件内容
        try:
            with open(source_path, "r", encoding="utf-8") as f:
                content = f.read()
        except Exception as e:
            self.print_error(f"读取文件失败：{filename} - {str(e)}")
            return False

        # 生成 Frontmatter（动态）
        frontmatter = generate_frontmatter(
            filename, file_config, self.agent, self.config
        )

        # 写入目标文件
        try:
            with open(target_path, "w", encoding="utf-8") as f:
                f.write(frontmatter)
                f.write(content)
        except Exception as e:
            self.print_error(f"写入文件失败：{target_path} - {str(e)}")
            return False

        # 获取文件大小
        filesize = target_path.stat().st_size
        filesize_str = format_filesize(filesize)

        self.print_success(
            f"同步 {filename} → {file_config['target']} ({filesize_str})"
        )
        return True

    def sync(
        self,
        date_folder: Optional[str] = None,
        files: Optional[List[str]] = None,
        natural_date: Optional[str] = None,
    ) -> bool:
        """执行同步

        Args:
            date_folder: 日期文件夹（默认今日，支持 YYYY-MM-DD 格式）
            files: 要同步的文件列表（默认使用配置中的列表）
            natural_date: 自然语言日期（如"昨天"、"3 天前"）

        Returns:
            是否成功
        """
        self.print_info("=== claw-memo-obsidian - OpenClaw 配置文件同步工具 ===")
        self.print_info(f"版本：2.0.0")
        self.print_info(f"智能体：{self.agent}")

        # 1. 确定目标文件夹（支持自然语言日期）
        if natural_date:
            target_date = parse_natural_date(natural_date)
            self.print_info(f"自然语言日期：'{natural_date}' → {target_date}")
        elif date_folder:
            # 也支持从 date_folder 解析自然语言
            target_date = parse_natural_date(date_folder)
            if date_folder != target_date:
                self.print_info(f"日期解析：'{date_folder}' → {target_date}")
        else:
            target_date = datetime.now().strftime("%Y-%m-%d")

        target_dir = self.vault / self.sync_folder / target_date

        self.print_info(f"目标文件夹：{target_dir}")

        # 2. 检查 Vault 路径
        if not self.vault.exists():
            self.print_error(f"Obsidian Vault 路径不存在：{self.vault}")
            self.print_info("请检查 OBSIDIAN_VAULT_PATH 环境变量或创建该目录")
            return False

        # 3. 创建目标文件夹
        self.print_info("创建目标文件夹...")
        target_dir.mkdir(parents=True, exist_ok=True)
        self.print_success(f"文件夹已准备：{target_dir}")

        # 4. 确定要同步的文件
        if files:
            sync_files = {k: v for k, v in self.files_config.items() if k in files}
        else:
            sync_files = self.files_config

        # 5. 同步文件
        self.print_info(f"开始同步文件（共 {len(sync_files)} 个）...")
        print()

        success_count = 0
        for filename, file_config in sync_files.items():
            if self.sync_file(filename, file_config, target_dir):
                success_count += 1

        print()

        # 6. 统计信息
        self.print_info("=== 同步完成 ===")
        self.print_success(f"同步文件数：{success_count}/{len(sync_files)}")
        self.print_info(f"存储位置：{target_dir}")
        print()

        # 列出所有文件
        self.print_info("文件清单：")
        for file_path in sorted(target_dir.glob("*.md")):
            filesize_str = format_filesize(file_path.stat().st_size)
            print(f"  {file_path.name} - {filesize_str}")

        print()
        self.print_success("✅ 所有文件已成功同步到 Obsidian！")

        return success_count == len(sync_files)


# ==================== 命令行接口 ====================


def main():
    """主函数"""
    import argparse

    parser = argparse.ArgumentParser(
        description="claw-memo-obsidian - OpenClaw 配置文件同步工具（支持多智能体）",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  %(prog)s                      # 同步到今日文件夹
  %(prog)s -d 2026-04-01       # 同步到指定日期文件夹
  %(prog)s -f AGENTS.md MEMORY.md  # 只同步指定文件
  %(prog)s --vault ~/MyVault   # 指定 Obsidian Vault 路径
  %(prog)s --agent claude-code # 使用 Claude Code 配置
  %(prog)s --config ~/.my-config.json  # 使用自定义配置文件

多智能体支持:
  --agent openclaw     # 使用 OpenClaw 配置
  --agent claude-code  # 使用 Claude Code 配置
  --agent codex        # 使用 Codex 配置
        """,
    )

    parser.add_argument(
        "-d",
        "--date",
        type=str,
        help="目标日期文件夹（格式：YYYY-MM-DD 或自然语言如'昨天'、'3 天前'），默认为今日",
    )

    parser.add_argument(
        "-f",
        "--files",
        type=str,
        nargs="+",
        help="要同步的文件列表，默认使用配置文件中的列表",
    )

    parser.add_argument(
        "--natural-date",
        type=str,
        help="自然语言日期（如'昨天'、'3 天前'），与 --date 功能相同，保留用于兼容",
    )

    parser.add_argument(
        "--vault",
        type=str,
        help="Obsidian Vault 路径",
    )

    parser.add_argument(
        "--workspace",
        type=str,
        help="工作区路径",
    )

    parser.add_argument(
        "--folder",
        type=str,
        help="同步目标文件夹名称（默认：muliu_memo）",
    )

    parser.add_argument(
        "--agent",
        type=str,
        choices=["openclaw", "claude-code", "codex", "unknown"],
        help="指定智能体（默认自动检测）",
    )

    parser.add_argument(
        "--config",
        type=Path,
        help="配置文件路径（默认：~/.memo-sync-config.json）",
    )

    parser.add_argument(
        "--clean",
        action="store_true",
        help="清理模式：删除指定的日期文件夹（需要二次确认）",
    )

    parser.add_argument(
        "--confirmed",
        action="store_true",
        help="跳过二次确认（仅用于脚本自动化）",
    )

    parser.add_argument(
        "-v",
        "--version",
        action="version",
        version="claw-memo-obsidian 2.0.0",
    )

    args = parser.parse_args()

    # 加载配置
    config = load_config(args.config)

    # 允许命令行参数覆盖配置
    if args.vault:
        config["obsidian_vault"] = args.vault
    if args.workspace:
        config["workspace"] = args.workspace
    if args.folder:
        config["sync_folder"] = args.folder

    # 创建同步器
    syncer = MemoSync(
        config=config,
        agent=args.agent,
    )

    # 清理模式
    if args.clean and args.date:
        # 计算待删除文件夹的大小
        target_date = parse_natural_date(args.date)
        target_dir = syncer.vault / syncer.sync_folder / target_date

        if not target_dir.exists():
            syncer.print_error(f"文件夹不存在：{target_dir}")
            sys.exit(1)

        # 计算文件夹大小
        total_size = sum(f.stat().st_size for f in target_dir.rglob('*') if f.is_file())

        # 二次确认
        if not args.confirmed:
            confirm_deletion([{'path': str(target_dir), 'size': total_size}])
            print()
            syncer.print_info("等待用户确认...")
            print("(在实际使用中，AI 会等待用户回复'确认删除'后才继续)")
            print()
            # 这里不自动删除，由 AI 在对话中处理
            sys.exit(0)

        # 用户已确认，执行删除
        try:
            shutil.rmtree(target_dir)
            syncer.print_success(f"已删除：{target_dir}")
        except Exception as e:
            syncer.print_error(f"删除失败：{str(e)}")
            sys.exit(1)

    # 执行同步（支持自然语言日期）
    success = syncer.sync(
        date_folder=args.date,
        files=args.files,
        natural_date=args.natural_date,
    )

    # 退出码
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
