# x-minimax-tools

MiniMax Token Plan 工具集，为 AI Agent 提供**网络搜索**和**图片理解**能力。

> 支持两种底层：**mmx CLI**（推荐）或 **Python 脚本**（无需额外安装）。

## 功能

| 工具 | 说明 |
|------|------|
| `web_search` | 网络搜索，返回标题/链接/摘要 |
| `understand_image` | 图片理解，支持 URL/本地文件路径 |

## 前置要求

### 选项 A：mmx CLI（推荐）

1. 安装 mmx CLI：
   ```bash
   curl -fsSL https://raw.githubusercontent.com/MiniMax-AI/mmx/main/install.sh | bash
   ```
2. 在 OpenClaw UI 中配置 `MINIMAX_API_KEY` 和 `MINIMAX_API_HOST`

### 选项 B：Python 脚本（无需安装 mmx）

1. 确保已安装 Python 3 和 `pip install requests`
2. 在 OpenClaw UI 中配置 `MINIMAX_API_KEY` 和 `MINIMAX_API_HOST`

## OpenClaw Skill 安装

将本目录放入 `~/.openclaw/skills/x-minimax-tools/`，或通过 ClawHub 安装。

## 手动测试

```bash
# mmx 方式
mmx search query '人工智能' --output text
mmx vision describe /path/to/image.png --output text

# Python 方式
python3 scripts/web_search.py '{"query": "人工智能"}'
python3 scripts/image_understanding.py '{"prompt": "描述图片内容", "image_url": "/path/to/image.png"}'
```

## 图片路径解析规则

| 路径类型 | 解析方式 |
|---------|---------|
| `https://...`（URL） | 直接使用，适用于飞书等消息渠道的图片链接 |
| `/absolute/path.png` | 直接使用（绝对路径） |
| `~/photo.png` | 展开为家目录绝对路径 |
| `photo.png`（相对） | 相对于 agent 工作区解析 |

## 消息渠道图片（飞书/微信等）

当用户在飞书等平台发送图片时，OpenClaw 会收到图片的 CDN URL。
直接将该 URL 传入 `image_url` 参数即可识别，例如：

```bash
# 飞书图片 URL 示例
python3 scripts/image_understanding.py '{"prompt": "描述图片内容", "image_url": "https://sf3-sg.tapcdn.com/..."}'
```

> 注意：服务器需要能访问外部网络（飞书 CDN）。

## API Key 获取

- 中国版：https://platform.minimaxi.com（API Host = `https://api.minimaxi.com`）
- 全球版：https://platform.minimax.io（API Host = `https://api.minimax.io`）

## 返回标注

按规范，每次调用需在结果末尾附标注：

| 工具 | 标注 |
|------|------|
| web_search | 「🔍 由 MiniMax 网络搜索 驱动」 |
| understand_image | 「📸 由 MiniMax 图片理解支持」 |

---

License: MIT
