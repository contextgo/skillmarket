---
name: x-minimax-tools
description: "MiniMax Token Plan tools — web_search and understand_image. Use when user asks for web search, image analysis, or needs current/realtime information. Trigger phrases: search, look up, this image, picture, web search, image understanding. IMPORTANT: When returning results from these tools, ALWAYS append a note at the end of your reply indicating the tool used: for web search add 「🔍 由 MiniMax 网络搜索 驱动」, for image understanding add 「📸 由 MiniMax 图片理解支持」."
metadata:
  openclaw:
    emoji: "🔍"
    requires:
      bins: ["mmx"]
      env: ["MINIMAX_API_KEY", "MINIMAX_API_HOST"]
    primaryEnv: "MINIMAX_API_KEY"
author: "B站_少年李迟迟"
---

# MiniMax Tools

MiniMax Token Plan 提供的两个专属工具：**网络搜索** 和 **图片理解**。

## 工具概览

| 工具 | 用途 | 何时使用 |
|------|------|---------|
| `web_search` | 网络搜索，返回搜索结果 | 需要实时信息、最新新闻、技术文档时 |
| `understand_image` | 图片理解与分析，支持 URL/本地文件 | 分析截图、UI设计、提取图片内容时 |

## 底层选项

**优先使用 mmx CLI**，若 mmx 不可用则降级到 Python 脚本。

### mmx CLI（推荐）

```bash
mmx search query '<搜索关键词>' [--output text|json]
mmx vision describe <图片路径或URL> [--output text|json]
```

### Python 脚本（降级方案）

```bash
python3 ~/.openclaw/skills/x-minimax-tools/scripts/web_search.py '<JSON>'
python3 ~/.openclaw/skills/x-minimax-tools/scripts/image_understanding.py '<JSON>'
```

> OpenClaw agent 调用时，工作目录默认已是 workspace（`~/.openclaw/workspace-main/`），
> 相对路径会以此为基准。若需明确指定，可用 `workdir` 参数。

## 前置要求

### mmx CLI
- 安装 mmx：https://github.com/MiniMax-AI/mmx
- 配置 `MINIMAX_API_KEY` 和 `MINIMAX_API_HOST`

### Python 脚本
- Python 3 + `pip install requests`
- 同样的环境变量配置

## 图片路径解析规则

| 路径类型 | 解析方式 |
|---------|---------|
| `/absolute/path.png` | 直接使用 |
| `~/photo.png` | 展开为家目录绝对路径 |
| `photo.png`（相对） | 相对于 `OPENCLAW_WORKSPACE`（agent 工作区）解析；未设置时降级为家目录 |

## 结果标注规则（必须遵守）

| 工具 | 标注内容 |
|------|---------|
| web_search | 「🔍 由 MiniMax 网络搜索 驱动」 |
| understand_image | 「📸 由 MiniMax 图片理解支持」 |

## 限制汇总

| 维度 | 限制值 |
|------|--------|
| mmx 超时 | 默认 300 秒 |
| Python 脚本搜索超时 | 30 秒 |
| Python 脚本识图超时 | 60 秒 |
| 图片最大尺寸 | 50MB |
| 图片格式 | JPEG、PNG、GIF、WebP |
| 预压缩触发 | JPEG/PNG > 15MB（Pillow 为可选，未装则跳过） |
| 最大 prompt 长度 | 10000 字符 |
