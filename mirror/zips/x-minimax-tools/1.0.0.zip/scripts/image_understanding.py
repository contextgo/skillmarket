#!/usr/bin/env python3
"""
MiniMax Image Understanding Tool
调用 MiniMax Token Plan API 进行图片理解

Endpoint: POST {api_host}/v1/coding_plan/vlm

安全措施：
- 仅允许 http/https URL，禁用 file:// 等危险协议
- 本地文件限制大小（最大 50MB）和类型（仅图片）
- 请求超时保护
- 路径遍历防护
- 自动预压缩（大图优化）
- 重试 + 退避
"""

import sys
import json
import os
import base64
import time
import requests
from urllib.parse import urlparse

# 安全配置
MAX_FILE_SIZE = 50 * 1024 * 1024  # 50MB
ALLOWED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".gif", ".webp"}
REQUEST_TIMEOUT = 60

# 预压缩配置
COMPRESS_THRESHOLD = 15 * 1024 * 1024  # 15MB 以上才压缩
COMPRESS_QUALITY = 85                  # JPEG 质量

# 重试配置
MAX_RETRIES = 3
RETRY_BACKOFF = [1, 3, 10]  # 秒


def is_safe_url(url: str) -> bool:
    """校验 URL 安全性：仅允许 http/https"""
    if url.startswith("data:"):
        return True
    try:
        parsed = urlparse(url)
        return parsed.scheme in ("http", "https")
    except Exception:
        return False


def is_safe_local_path(path: str) -> bool:
    """校验本地路径：禁止 ../ 等路径遍历"""
    normalized = os.path.normpath(path)
    if ".." in normalized:
        return False
    restricted = [
        "/etc/", "/root/", "/.ssh/", "/.config/",
        "/.git/", "/proc/", "/sys/", "/boot/",
        "/var/", "/usr/", "/bin/", "/sbin/",
    ]
    for r in restricted:
        if r in normalized:
            return False
    return True


def get_file_extension(path: str) -> str:
    """从路径或 URL 中提取扩展名"""
    parsed = urlparse(path)
    return os.path.splitext(parsed.path)[1].lower()


def try_compress_image(data: bytes, ext: str) -> bytes:
    """尝试压缩 JPEG/PNG 图片（超过阈值时触发）"""
    if len(data) < COMPRESS_THRESHOLD:
        return data
    if ext not in (".jpg", ".jpeg", ".png"):
        return data
    try:
        from io import BytesIO
        from PIL import Image
        img = Image.open(BytesIO(data))
        if img.mode in ("RGBA", "LA", "P"):
            out = BytesIO()
            img.save(out, format="JPEG", quality=COMPRESS_QUALITY)
        else:
            out = BytesIO()
            img.convert("RGB").save(out, format="JPEG", quality=COMPRESS_QUALITY)
        compressed = out.getvalue()
        return compressed if len(compressed) < len(data) else data
    except Exception:
        return data


def load_image_as_base64(image_url: str) -> str:
    """安全地加载图片并转为 base64"""
    if image_url.startswith("data:"):
        return image_url.split(",", 1)[1]

    if image_url.startswith("http://") or image_url.startswith("https://"):
        if not is_safe_url(image_url):
            raise ValueError(f"Disallowed URL scheme: {image_url}")
        ext = get_file_extension(image_url)
        if ext and ext not in ALLOWED_EXTENSIONS:
            raise ValueError(f"Disallowed file extension: {ext}")
        response = requests.get(image_url, timeout=REQUEST_TIMEOUT, stream=True)
        response.raise_for_status()
        chunks = []
        total = 0
        for chunk in response.iter_content(chunk_size=8192):
            total += len(chunk)
            if total > MAX_FILE_SIZE:
                raise ValueError(f"File too large: exceeded {MAX_FILE_SIZE} bytes")
            chunks.append(chunk)
        raw_data = b"".join(chunks)
        compressed = try_compress_image(raw_data, ext)
        return base64.b64encode(compressed).decode("utf-8")

    if image_url.startswith("~"):
        image_url = os.path.expanduser(image_url)

    # 相对路径：以 OPENCLAW_WORKSPACE（agent 工作区）为基准
    # 未设置时降级为家目录（兼容纯 Python 场景）
    if not os.path.isabs(image_url):
        base = os.environ.get("OPENCLAW_WORKSPACE", os.path.expanduser("~"))
        image_url = os.path.normpath(os.path.join(base, image_url))

    if not is_safe_local_path(image_url):
        raise ValueError(f"Restricted path: {image_url}")
    if not os.path.isfile(image_url):
        raise ValueError(f"File not found: {image_url}")

    ext = get_file_extension(image_url)
    if ext and ext not in ALLOWED_EXTENSIONS:
        raise ValueError(f"Disallowed file extension: {ext}")
    if os.path.getsize(image_url) > MAX_FILE_SIZE:
        raise ValueError(f"File too large: {MAX_FILE_SIZE} bytes limit")

    with open(image_url, "rb") as f:
        raw_data = f.read()
    compressed = try_compress_image(raw_data, ext)
    return base64.b64encode(compressed).decode("utf-8")


def minimax_image_understand(api_key: str, api_host: str, prompt: str, image_url: str):
    """执行 MiniMax 图片理解（带重试 + 429 处理）"""
    url = f"{api_host}/v1/coding_plan/vlm"

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }

    image_data = load_image_as_base64(image_url)

    payload = {
        "prompt": prompt,
        "image_url": f"data:image/jpeg;base64,{image_data}"
    }

    last_err = None
    for attempt in range(MAX_RETRIES):
        try:
            response = requests.post(url, json=payload, headers=headers, timeout=REQUEST_TIMEOUT)

            if response.status_code == 429:
                if attempt < MAX_RETRIES - 1:
                    time.sleep(RETRY_BACKOFF[attempt])
                    continue
                raise Exception("Rate limited (HTTP 429).")

            response.raise_for_status()
            results = response.json()

            base_resp = results.get("base_resp", {})
            if base_resp.get("status_code") != 0:
                raise Exception(f"API Error: {base_resp.get('status_msg')}")

            return {"content": results.get("content", "")}

        except (requests.exceptions.Timeout, requests.exceptions.ConnectionError) as e:
            last_err = e
            if attempt < MAX_RETRIES - 1:
                time.sleep(RETRY_BACKOFF[attempt])
            continue
        except Exception as e:
            if "429" in str(e) and attempt < MAX_RETRIES - 1:
                time.sleep(RETRY_BACKOFF[attempt])
                continue
            raise

    raise Exception(f"Request failed after {MAX_RETRIES} attempts: {last_err}")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python image_understanding.py '<JSON>'")
        sys.exit(1)

    try:
        parse_data = json.loads(sys.argv[1])
    except json.JSONDecodeError as e:
        print(f"JSON parse error: {e}")
        sys.exit(1)

    prompt = parse_data.get("prompt", "")
    image_url = parse_data.get("image_url", "")

    if not prompt:
        print("Error: 'prompt' is required")
        sys.exit(1)
    if not image_url:
        print("Error: 'image_url' is required")
        sys.exit(1)
    if len(prompt) > 10000:
        print("Error: 'prompt' too long (max 10000 characters)")
        sys.exit(1)

    api_key = os.getenv("MINIMAX_API_KEY")
    api_host = os.getenv("MINIMAX_API_HOST", "https://api.minimaxi.com")

    if not api_key:
        print("Error: MINIMAX_API_KEY is not configured.")
        sys.exit(1)
    if not api_host.startswith("https://"):
        print("Error: api_host must use https://")
        sys.exit(1)

    try:
        results = minimax_image_understand(api_key, api_host, prompt, image_url)
        print(json.dumps(results, indent=2, ensure_ascii=False))
    except ValueError:
        print("Error: Invalid request")
        sys.exit(1)
    except requests.exceptions.Timeout:
        print("Error: Request timed out")
        sys.exit(1)
    except requests.exceptions.SSLError:
        print("Error: SSL error")
        sys.exit(1)
    except requests.exceptions.HTTPError as e:
        print(f"Error: HTTP {e.response.status_code}")
        sys.exit(1)
    except Exception as e:
        print(f"Error: {str(e)}")
        sys.exit(1)
