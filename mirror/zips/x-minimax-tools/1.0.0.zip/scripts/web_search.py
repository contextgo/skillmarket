#!/usr/bin/env python3
"""
MiniMax Web Search Tool
调用 MiniMax Token Plan API 进行网络搜索

Endpoint: POST {api_host}/v1/coding_plan/search

安全措施：
- 请求超时保护
- 重试 + 退避（网络瞬时故障）
- 429 限流友好提示
"""

import sys
import json
import os
import time
import requests

# 请求超时（秒）
REQUEST_TIMEOUT = 30

# 重试配置
MAX_RETRIES = 3
RETRY_BACKOFF = [1, 3, 10]  # 秒


def minimax_web_search(api_key: str, api_host: str, query: str, simple: bool = False):
    """执行 MiniMax 网络搜索（带重试 + 429 处理）"""
    url = f"{api_host}/v1/coding_plan/search"

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }

    payload = {"q": query}

    last_err = None
    for attempt in range(MAX_RETRIES):
        try:
            response = requests.post(url, json=payload, headers=headers, timeout=REQUEST_TIMEOUT)

            if response.status_code == 429:
                if attempt < MAX_RETRIES - 1:
                    time.sleep(RETRY_BACKOFF[attempt])
                    continue
                raise Exception("Rate limited (HTTP 429). Please try again later.")

            response.raise_for_status()
            results = response.json()

            base_resp = results.get("base_resp", {})
            if base_resp.get("status_code") != 0:
                raise Exception(f"API Error: {base_resp.get('status_msg')}")

            if simple:
                organic = results.get("organic", [])
                output = []
                for item in organic[:5]:
                    output.append({
                        "title": item.get("title", ""),
                        "link": item.get("link", ""),
                        "snippet": item.get("snippet", "")[:200]
                    })
                return {"results": output, "count": len(output)}

            return results

        except (requests.exceptions.Timeout, requests.exceptions.ConnectionError) as e:
            last_err = e
            if attempt < MAX_RETRIES - 1:
                time.sleep(RETRY_BACKOFF[attempt])
            continue
        except Exception as e:
            if "429" in str(e) and attempt < MAX_RETRIES - 1:
                time.sleep(RETRY_BACKOFF[attempt])
                continue
            raise

    raise Exception(f"Request failed after {MAX_RETRIES} attempts: {last_err}")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python web_search.py '<JSON>'")
        print("Example: python web_search.py '{\"query\": \"人工智能\"}'")
        sys.exit(1)

    try:
        parse_data = json.loads(sys.argv[1])
    except json.JSONDecodeError as e:
        print(f"JSON parse error: {e}")
        sys.exit(1)

    query = parse_data.get("query", "")
    if not query:
        print("Error: 'query' is required")
        sys.exit(1)

    simple = parse_data.get("simple", False)

    api_key = os.getenv("MINIMAX_API_KEY")
    api_host = os.getenv("MINIMAX_API_HOST", "https://api.minimaxi.com")

    if not api_key:
        print("Error: MINIMAX_API_KEY is not configured.")
        sys.exit(1)

    if not api_host.startswith("https://"):
        print("Error: api_host must use https://")
        sys.exit(1)

    try:
        results = minimax_web_search(api_key, api_host, query, simple)
        print(json.dumps(results, indent=2, ensure_ascii=False))
    except requests.exceptions.Timeout:
        print("Error: Request timed out")
        sys.exit(1)
    except requests.exceptions.SSLError:
        print("Error: SSL error")
        sys.exit(1)
    except requests.exceptions.HTTPError as e:
        print(f"Error: HTTP {e.response.status_code}")
        sys.exit(1)
    except Exception as e:
        print(f"Error: {str(e)}")
        sys.exit(1)
