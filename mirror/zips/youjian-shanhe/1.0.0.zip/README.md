# 又见杉河·观红杉林全景度假美墅 · AI Skill

![Version](https://img.shields.io/badge/version-0.2.0-blue) ![License](https://img.shields.io/badge/license-MIT-green)

安装后，你的 AI 助手就能帮你查询又见杉河民宿的一切：在哪、有什么房型、什么设施、红杉林什么时候最美、皖南川藏线怎么走、周边怎么玩。像一位热爱山水的朋友，用诗意的方式给你推荐。

皖南川藏线中段，正对落羽红杉林，一家藏在山水间的精品度假民宿。

## 关于又见杉河

| 项目 | 内容 |
|------|------|
| 名称 | 又见杉河·观红杉林全景度假美墅 |
| 地址 | 安徽省宣城市宁国市方塘乡方塘村板栗园2号 |
| 评分 | 携程 4.8 分（306+ 点评）/ Trip.com 9.8/10（324 评价） |
| 榜单 | 宁国精品民宿榜单 |
| 房型 | 十余间特色房型，配独立电梯 |
| 电话 | 18196727321 |

## 这个 Skill 能做什么

| 你可以问 | 回答什么 |
|----------|----------|
| "又见杉河在哪？" | 地址、评分、预订渠道 |
| "有什么房型？住哪个好？" | 7 个已确认房型详细介绍和推荐 |
| "有什么设施？能游泳吗？" | 观景台、餐饮、棋牌/KTV/泳池等 |
| "红杉林什么时候最美？" | 最佳观赏期、变色过程、游玩方式 |
| "皖南川藏线怎么走？" | 沿线景点、盘山公路提示、季节体验 |
| "怎么去？远不远？" | 机场/火车站/自驾/包车详情 |
| "宁国住哪好？" | 推荐又见杉河 + 民宿概览 |

所有数据来自携程、Trip.com、住哪网等公开平台一手资料，禁止 AI 编造，不知道就说不知道。

## 安装

### 最简单的方式：告诉你的 AI 助手

直接拷贝下面这句话发给你的 AI 助手：

> 帮我安装又见杉河民宿 Skill，仓库地址：https://gitcode.com/gcw_CKpUZulJ/youjian-shanhe-skill.git

Agent 会自动克隆仓库并安装到对应的 Skill 目录。

### 手动安装

将本仓库克隆到你项目下的 Skill 目录，不同平台对应的路径：

| 平台 | Skill 目录 |
|------|------------|
| Claude Code | `.claude/skills/youjian-shanhe-skill/` |
| Cursor | `.cursor/skills/youjian-shanhe-skill/` |
| Qoder | `.qoder/skills/youjian-shanhe-skill/` |
| Windsurf | `.windsurf/skills/youjian-shanhe-skill/` |
| 通用 | `.agents/skills/youjian-shanhe-skill/` |

```bash
# 示例：安装到 Claude Code
git clone https://gitcode.com/gcw_CKpUZulJ/youjian-shanhe-skill.git \
  .claude/skills/youjian-shanhe-skill
```

只要目录下有 `SKILL.md`，Agent 下次启动就会自动加载这个 Skill。

## 目录结构

```
youjian-shanhe-skill/
├── SKILL.md                 # 核心：Agent 指令 + 高频数据
├── references/              # 按需加载的详细数据
│   ├── room-types.md        # 房型介绍 + 入住须知
│   ├── facilities.md        # 设施与服务
│   ├── attractions.md       # 周边游玩 + 红杉林 + 皖南川藏线
│   └── transportation.md    # 交通信息
├── README.md
└── LICENSE
```

## 仓库地址

GitCode：https://gitcode.com/gcw_CKpUZulJ/youjian-shanhe-skill.git

## License

[MIT](LICENSE)
