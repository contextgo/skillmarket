---
name: memory-evolution
description: |
  Self-learning memory system with evolution engine, decay-based forgetting, and multi-trigger reflection.
  Builds a persistent knowledge base from user corrections, self-reflection, and automated pattern detection.
  Trigger when: user corrects you, says "reflect"/"回顾"/"反思"/"做梦", asks "what do you know about X"/"你学到了什么", says "forget X"/"记住这个", significant task completed, heartbeat/scheduled task runs.
  Do NOT trigger for: simple Q&A, greetings, one-time instructions.
---

# Memory Evolution

Self-learning memory with evolution engine, decay-based forgetting, and multi-trigger reflection.

## Quick Start

No setup required. The AI automatically creates the data directory on first use.

Data is stored in `~/memory-evolution/`. See Architecture below for the directory structure.

## Architecture

```
~/memory-evolution/
├── hot/                    # Always loaded (<=100 lines each)
│   ├── memory.md           # Confirmed rules & preferences
│   └── corrections.md      # User corrections
├── warm/                   # Load on demand
│   ├── projects/           # Per-project learnings
│   └── domains/            # Domain-specific patterns
├── cold/                   # Explicit query only
│   └── archive/            # Decayed patterns
├── engine/                 # Evolution engine data (auto-managed)
│   ├── sensor.json         # Task outcome records
│   ├── world_model.json    # Success pattern predictions
│   ├── evo_devo.json       # Generated strategies
│   └── decay-scores.json   # Decay tracking
├── proposals/              # Engine-generated strategies
│   └── pending.md
├── reflections/            # Reflection outputs
│   └── log.md              # Summaries (newest first)
└── meta.json               # Version info
```

## Three Reflection Triggers

### 1. Auto (task completion)

"Significant work" = any task that took 5+ tool calls or modified 2+ files.

Steps:
1. Ask: "Did something go wrong? Did I learn something non-obvious?"
2. If yes → write to `reflections/log.md`
3. If same pattern appears 3x in 7 days → promote to `hot/memory.md`

Reflection format:
```
CONTEXT: [task type, e.g. "Electron packaging"]
REFLECTION: [what I noticed, e.g. "adm-zip needs separate include"]
LESSON: [what to do differently, e.g. "Always check asarUnpack for renderer files"]
```

Correction format (when user corrects you):
```markdown
## YYYY-MM-DD — [topic]
**What I did wrong**: [specific mistake]
**What I should do**: [correct approach]
**Context**: [when this applies]
```
Write to `hot/corrections.md`.

### 2. Manual (user says "reflect/回顾/反思/做梦")

Steps:
1. Read `hot/memory.md` + `hot/corrections.md` (current state)
2. Read `reflections/log.md` (recent reflections)
3. Read recent conversation context or daily logs (last 7 days)
4. Identify 2-4 patterns or lessons worth recording
5. For each: check if it already exists in HOT → skip if duplicate
6. Write new entries to `reflections/log.md`
7. If any lesson is critical (would prevent real damage) → also write to `hot/memory.md`

Output format:
```markdown
## YYYY-MM-DD — [topic]

**Context**: [what triggered this]
**Findings**: [2-4 observations]
**Actions**: [what to change/remember]
```

**Stop and confirm** before writing to `hot/memory.md`. Tell user what you plan to add.

### 3. Dream (scheduled/heartbeat)

Runs during scheduled tasks (e.g. heartbeat automation, cron):
1. Read `engine/decay-scores.json`
2. Recalculate all decay scores using formula
3. If any score dropped below 0.2 → demote to WARM, log to `reflections/log.md`
4. If any score dropped below 0.05 → auto-move to `cold/archive/`
5. Read `proposals/pending.md` → if any pending, include in report
6. Extract 1-2 patterns from recent activity → append to `reflections/log.md`

**Safety**: Before archiving to COLD, log the action with reason. Never delete — only archive.

## Decay Model

```
relevance(t) = base * e^(-0.03 * days_since_access) * log2(access_count + 1) * type_weight
```

| Score | Status | Behavior |
|-------|--------|----------|
| 1.0-0.5 | Active | Fully searchable, in context |
| 0.5-0.2 | Fading | Load on demand |
| 0.2-0.05 | Dormant | Explicit search only |
| < 0.05 | Archived | Move to COLD |

Type weights: hot=1.5, warm=0.8, correction=1.2, engine_strategy=1.0

See `references/decay.md` for detailed implementation.

## Learning Signals

### Record (automatic)
- Task success/failure → `engine/sensor.json`
- User correction → `hot/corrections.md`
- Pattern confirmed → `hot/memory.md`

### Ignore (do not record)
- One-time instructions
- Context-specific commands
- Hypotheticals

## Tiered Storage

| Tier | Location | Limit | Behavior |
|------|----------|-------|----------|
| HOT | `hot/*.md` | 100 lines each | Always in context |
| WARM | `warm/projects/`, `warm/domains/` | 200 lines each | Load on demand |
| COLD | `cold/archive/` | Unlimited | Explicit query |

### Promotion / Demotion
- Used 3x in 7 days → promote to HOT
- Unused 30 days → demote to WARM
- Decay < 0.05 → auto-archive to COLD
- Engine strategy approved → promote to HOT
- Engine strategy rejected → auto-cull

## Evolution Engine

The engine operates on `~/memory-evolution/engine/*.json`:
- **sensor** — Records task outcomes (success/failure with context)
- **world_model** — Predicts which approaches succeed
- **evo_devo** — Generates new strategies via pattern evolution
- **covenant** — Safety guard (rejects dangerous strategies)

See `references/engine.md` for module details, data formats, and interaction flow.

### Engine Lifecycle
1. Engine accumulates records passively (sensor)
2. When enough data collected → evolve() generates strategy proposals
3. Proposals land in `proposals/pending.md`
4. AI or user reviews → approve / reject / modify
5. Approved → `hot/memory.md` + engine records success
6. Rejected → engine records failure, auto-adjusts weights

### Proposal Workflow
1. Engine generates strategy → `proposals/pending.md`
2. AI or user reviews → approve / reject / modify
3. Approved → `hot/memory.md` + engine records success
4. Rejected → mark rejected + engine records failure

## Quick Queries

| User says | Action |
|-----------|--------|
| "What do you know about X?" | Search `hot/memory.md` → `warm/` → `engine/` concepts |
| "What have you learned?" | Show last 10 corrections + pending proposals |
| "Show my patterns" | List HOT memory + active engine strategies |
| "Memory stats" | Count lines in hot/*.md + files in warm/ + engine entries |
| "Evolution status" | Read engine stage + sensor record count |
| "Forget X" | Search all tiers → list matches → confirm → remove |
| "Remember X" | Write to `hot/memory.md`. Compact if >100 lines. |
| "Reflect / 做梦" | Run manual reflection cycle (Trigger 2) |

## Edge Cases

| Scenario | What to do |
|----------|------------|
| `hot/memory.md` exceeds 100 lines | Compact: merge related entries, move oldest to `warm/` |
| Data directory missing | AI recreates the directory structure automatically |
| `engine/*.json` corrupted | Rename to `.bak`, re-init empty, log warning |
| `forget X` finds nothing | Tell user "X not found in any tier" |
| `remember X` is duplicate | Tell user "Already known: [existing entry]" |
| Decay score NaN/invalid | Reset to base=0.8, log warning |
| User contradicts existing rule | New rule replaces old. Log in `reflections/log.md`. |

## Conflict Resolution

- Most specific wins (project > domain > global)
- Most recent wins (same tier)
- Engine proposal vs manual rule → manual wins
- User correction vs everything → user wins
- Ambiguous → ask user

## Scope

ONLY:
- Learns from corrections, reflection, engine proposals
- Stores in `~/memory-evolution/`
- Runs decay calculations
- Integrates with scheduled tasks / heartbeat

NEVER:
- Accesses calendar, email, contacts
- Makes network requests
- Infers preferences from silence
- Deletes memory without confirmation
- Modifies its own SKILL.md
