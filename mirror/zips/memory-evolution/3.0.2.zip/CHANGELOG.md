# Changelog

## 3.0.0 (2026-05-01)

Initial public release. Merged from three separate skills into one unified system.

**What's new**:
- Three-layer storage: HOT (always loaded) / WARM (on demand) / COLD (archive)
- Decay-based forgetting with configurable formula
- Three reflection triggers: auto (task completion), manual (user request), dream (scheduled)
- Evolution engine with sensor, world model, strategy generator, and safety guard
- Cross-platform init script with `--path` support
- MIT license

**Merged from**:
- `self-improving` v2.0 — Evolution engine, HOT/WARM/COLD tiers, heartbeat integration
- `cognitive-memory` v1.0 — Decay model, reflection engine, multi-store architecture
- `ontology` v1.0 — Entity type system (archived, not included in v3.0)

**Breaking changes from predecessors**:
- Data directory moved from `~/self-improving/` to `~/memory-evolution/`
- Reflection engine simplified (removed token reward and philosophical monologue)
- Knowledge graph removed (ontology features not carried forward)
