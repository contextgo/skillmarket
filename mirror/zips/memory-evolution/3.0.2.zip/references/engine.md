# Evolution Engine Reference

## Overview

The evolution engine is a self-improving system that learns from task outcomes and generates strategy proposals. It operates entirely on local JSON files — no network, no API calls.

## Modules

### sensor.py — Task Outcome Recorder

Records every task result (success/failure) with context.

**Data**: `engine/sensor.json`
```json
{
  "records": [
    {
      "timestamp": "2026-05-01T14:30:00",
      "task_type": "bug_fix",
      "result": "success",
      "context": {"language": "python", "framework": "fastapi"},
      "lessons": ["Always check env vars before import"]
    }
  ]
}
```

**When it records**:
- After any task the AI considers "done" (success or failure)
- AI calls `record(task_type, result, context)` conceptually — actual write is a JSON append

### world_model.py — Success Pattern Predictor

Analyzes sensor records to predict which approaches work in which contexts.

**Data**: `engine/world_model.json`
```json
{
  "patterns": [
    {
      "condition": {"language": "python", "task": "packaging"},
      "prediction": "Use venv + requirements.txt over poetry for simple projects",
      "confidence": 0.85,
      "evidence_count": 5
    }
  ]
}
```

**How it works**: Correlation analysis on sensor records. Higher confidence = more evidence.

### evo_devo.py — Strategy Generator

Uses genetic algorithm concepts to propose new strategies from accumulated patterns.

**Data**: `engine/evo_devo.json`
```json
{
  "stage": "juvenile",
  "strategies": [
    {
      "id": "s001",
      "rule": "For Electron packaging, always set asarUnpack for renderer files",
      "origin": ["sensor_record_14", "sensor_record_23"],
      "fitness": 0.9,
      "status": "approved"
    }
  ],
  "generation": 3
}
```

**Evolution stages**:
| Stage | Records needed | Behavior |
|-------|----------------|----------|
| embryonic | 0-10 | Passive recording only |
| juvenile | 10-30 | Start generating proposals |
| mature | 30-100 | Active strategy evolution |
| expert | 100+ | High-confidence predictions |

### covenant.py — Safety Guard

Validates engine proposals against safety rules before presenting to user.

**Data**: `engine/covenant.json`
```json
{
  "rules": [
    "Never propose strategies that bypass security checks",
    "Never auto-approve strategies affecting user data"
  ],
  "rejected": [
    {
      "proposal": "Auto-delete old files without asking",
      "reason": "Violates user confirmation requirement",
      "timestamp": "2026-04-28T10:00:00"
    }
  ]
}
```

## Module Interaction Flow

```
Task completes
    │
    ▼
sensor.py records outcome
    │
    ▼
world_model.py updates patterns
    │
    ▼ (when enough data)
evo_devo.py generates strategy
    │
    ▼
covenant.py validates safety
    │
    ├── REJECTED → logged, auto-cull
    │
    └── APPROVED → proposals/pending.md
                    │
                    ▼
              User/AI reviews
                    │
              ├── Approved → hot/memory.md
              └── Rejected → feedback to evo_devo
```

## Engine Without Python Scripts

The engine's Python modules are optional enhancements. The core system works purely through:

1. **AI reads/writes JSON directly** — All engine files are simple JSON, readable without scripts
2. **AI applies the decay formula** — Math is in `references/decay.md`
3. **AI follows the proposal workflow** — Defined in SKILL.md

The Python scripts add:
- Deterministic decay calculation (vs AI mental math)
- Automated pattern detection (vs AI manual review)
- Genetic algorithm strategy generation (vs AI intuition)

All optional. The system degrades gracefully.

## Creating the Python Engine Scripts (Optional)

If you want the full engine with deterministic Python scripts, create these files in `~/memory-evolution/engine/`:

### sensor.py — Record task outcomes

```python
"""Append a task outcome record to engine/sensor.json"""
import json, sys
from pathlib import Path
from datetime import datetime

ENGINE_DIR = Path.home() / "memory-evolution" / "engine"

def record(task_type: str, result: str, context: dict = None):
    sensor_path = ENGINE_DIR / "sensor.json"
    data = json.loads(sensor_path.read_text(encoding="utf-8")) if sensor_path.exists() else {"records": []}
    data["records"].append({
        "timestamp": datetime.now().isoformat(),
        "task_type": task_type,
        "result": result,
        "context": context or {}
    })
    sensor_path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

if __name__ == "__main__":
    # Usage: python sensor.py <task_type> <success|failure> [context_json]
    record(sys.argv[1], sys.argv[2], json.loads(sys.argv[3]) if len(sys.argv) > 3 else {})
    print(f"Recorded: {sys.argv[1]} -> {sys.argv[2]}")
```

### decay.py — Calculate decay scores

```python
"""Recalculate decay scores for all tracked entries"""
import json, math
from pathlib import Path
from datetime import datetime

ENGINE_DIR = Path.home() / "memory-evolution" / "engine"
LAMBDA = 0.03
TYPE_WEIGHTS = {"hot": 1.5, "warm": 0.8, "correction": 1.2, "engine_strategy": 1.0}

def calc_decay(base: float, days: float, access_count: int, type_weight: float) -> float:
    return base * math.exp(-LAMBDA * days) * math.log2(access_count + 1) * type_weight

def recalculate():
    scores_path = ENGINE_DIR / "decay-scores.json"
    scores = json.loads(scores_path.read_text(encoding="utf-8")) if scores_path.exists() else {}
    today = datetime.now().toordinal()
    changes = []
    for entry_id, info in scores.items():
        days = today - datetime.fromisoformat(info.get("last_access", info.get("created", datetime.now().isoformat()))).toordinal()
        new_score = calc_decay(info.get("base", 0.8), days, info.get("access_count", 0), TYPE_WEIGHTS.get(info.get("type", "warm"), 1.0))
        info["current_score"] = round(new_score, 4)
        changes.append((entry_id, round(new_score, 4)))
    scores_path.write_text(json.dumps(scores, indent=2, ensure_ascii=False), encoding="utf-8")
    return changes

if __name__ == "__main__":
    for entry_id, score in recalculate():
        status = "Active" if score >= 0.5 else "Fading" if score >= 0.2 else "Dormant" if score >= 0.05 else "Archive"
        print(f"  {entry_id}: {score} ({status})")
```

### Setup command

After creating the scripts, make them executable:

```bash
cd ~/memory-evolution/engine
python sensor.py init success  # Test recording
python decay.py                # Test decay calculation
```

Or simply let the AI manage the JSON files directly — the scripts are a convenience, not a requirement.
