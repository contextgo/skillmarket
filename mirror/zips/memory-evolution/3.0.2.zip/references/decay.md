# Decay Model Details

## Formula

```
relevance(t) = base * e^(-0.03 * days_since_access) * log2(access_count + 1) * type_weight
```

### Parameters

| Parameter | Description | Typical Value |
|-----------|-------------|---------------|
| base | Initial relevance (0.5-1.0) | 0.8 |
| lambda | Decay rate | 0.03 (half-life ~23 days) |
| days_since_access | Days since last read/write | Auto-tracked |
| access_count | Times this entry was accessed | Auto-tracked |
| type_weight | Importance modifier by type | See table below |

### Type Weights

| Type | Weight | Reason |
|------|--------|--------|
| hot (memory.md) | 1.5 | Core rules, always relevant |
| hot (corrections.md) | 1.2 | User corrections are high-value |
| warm (projects/) | 0.8 | Project-specific, narrow scope |
| warm (domains/) | 1.0 | Domain knowledge, medium scope |
| cold (archive/) | 0.3 | Only for historical reference |
| engine_strategy | 1.0 | Neutral until proven |

## Score Thresholds

| Score Range | Status | Action |
|-------------|--------|--------|
| 1.0 - 0.5 | Active | Keep in HOT, fully searchable |
| 0.5 - 0.2 | Fading | Move to WARM if in HOT, load on demand |
| 0.2 - 0.05 | Dormant | Keep in WARM but deprioritize |
| < 0.05 | Archived | Move to COLD/archive |

## Implementation

Decay scores are tracked in `~/memory-evolution/engine/decay-scores.json`:

```json
{
  "entry_id_or_path": {
    "base": 0.8,
    "type_weight": 1.5,
    "access_count": 5,
    "last_access": "2026-05-01",
    "created": "2026-04-15",
    "current_score": 0.72
  }
}
```

### When to Update

1. **Access**: Every time an entry is read → increment access_count, update last_access
2. **Dream cycle** (heartbeat): Recalculate all scores, demote/promote as needed
3. **Manual reflection**: Recalculate affected entries

### Promotion Fast Track

These skip the normal decay:
- User says "remember this" → base=1.0, type_weight=1.5, goes to HOT
- Engine strategy approved → base=0.9, type_weight=1.0, goes to HOT
- Correction logged → base=0.8, type_weight=1.2, goes to HOT corrections

### Archive Compression

When moving entries to COLD:
1. Keep: entry ID, summary (1-2 lines), creation date, final score
2. Discard: full content, access history
3. Log the archive event in reflections/log.md
