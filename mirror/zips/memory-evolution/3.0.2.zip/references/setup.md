# Setup & Initialization

## Quick Start

The AI will automatically create the data directory on first use. No manual setup required.

If you prefer to set up manually, follow the steps below.

## Manual Setup

Create the directory structure:

```
~/memory-evolution/
├── hot/memory.md
├── hot/corrections.md
├── warm/projects/
├── warm/domains/
├── cold/archive/
├── engine/
├── proposals/pending.md
├── reflections/log.md
└── meta.json
```

### Init Script

Save the following as `init.py` and run with `python init.py` or `python init.py --path /custom/dir`:

```python
#!/usr/bin/env python3
"""
memory-evolution initializer
- Creates ~/memory-evolution/ data directory structure
- Initializes all required files
- Idempotent: safe to re-run

Usage:
  python init.py                    # Default: ~/memory-evolution/
  python init.py --path /custom/dir # Custom data directory
"""

import argparse
import json
from datetime import datetime
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description="Initialize memory-evolution data directory")
    parser.add_argument("--path", type=str, default=None, help="Custom data directory path (default: ~/memory-evolution/)")
    args = parser.parse_args()

    home = Path.home()
    data_dir = Path(args.path) if args.path else home / "memory-evolution"

    print(f"Initializing memory-evolution at {data_dir}")

    # 1. Create directory structure
    dirs = [
        data_dir,
        data_dir / "hot",
        data_dir / "warm" / "projects",
        data_dir / "warm" / "domains",
        data_dir / "cold" / "archive",
        data_dir / "engine",
        data_dir / "proposals",
        data_dir / "reflections",
    ]
    for d in dirs:
        d.mkdir(parents=True, exist_ok=True)
        print(f"  Created: {d.relative_to(data_dir)}")

    # 2. Initialize engine data files
    engine_files = {
        "sensor.json": {"records": []},
        "world_model.json": {"patterns": []},
        "evo_devo.json": {"stage": "embryonic", "strategies": [], "generation": 0},
        "covenant.json": {"rules": [], "rejected": []},
        "decay-scores.json": {},
    }
    for name, default in engine_files.items():
        fpath = data_dir / "engine" / name
        if not fpath.exists():
            fpath.write_text(json.dumps(default, indent=2, ensure_ascii=False), encoding="utf-8")
            print(f"  Created: engine/{name}")

    # 3. Initialize markdown files
    md_files = {
        "hot/memory.md": "# HOT Memory\n\n> Always loaded. Max 100 lines. Confirmed rules & preferences.\n\n",
        "hot/corrections.md": "# Corrections\n\n> User corrections, sorted by date. Max 100 lines.\n\n",
        "proposals/pending.md": "# Pending Proposals\n\n> Engine-generated strategies awaiting review.\n\n",
        "reflections/log.md": "# Reflection Log\n\n> Summaries of reflections, newest first.\n\n",
    }
    for rel, content in md_files.items():
        fpath = data_dir / rel
        if not fpath.exists():
            fpath.write_text(content, encoding="utf-8")
            print(f"  Created: {rel}")

    # 4. Write meta
    meta = {
        "initialized": datetime.now().isoformat(),
        "version": "3.0.0",
    }
    meta_path = data_dir / "meta.json"
    if not meta_path.exists():
        meta_path.write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"  Created: meta.json")
    else:
        existing = json.loads(meta_path.read_text(encoding="utf-8"))
        existing["last_init"] = datetime.now().isoformat()
        existing["version"] = "3.0.0"
        meta_path.write_text(json.dumps(existing, indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"  Updated: meta.json")

    print(f"\nDone! memory-evolution ready at {data_dir}")


if __name__ == "__main__":
    main()
```

## What It Creates

```
~/memory-evolution/
├── hot/memory.md           # Confirmed rules (≤100 lines)
├── hot/corrections.md      # User corrections
├── warm/projects/           # Per-project learnings
├── warm/domains/            # Domain patterns
├── cold/archive/            # Decayed entries
├── engine/sensor.json       # Task outcome records
├── engine/world_model.json  # Success predictions
├── engine/evo_devo.json     # Strategy proposals
├── engine/covenant.json     # Safety guard
├── engine/decay-scores.json # Decay tracking
├── proposals/pending.md     # Awaiting review
├── reflections/log.md       # Reflection history
└── meta.json                # Version info
```

Safe to re-run — only creates files that don't exist yet.
