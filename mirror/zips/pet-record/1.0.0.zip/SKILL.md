---
name: pet-record
description: >
  宠物日常健康记录工具。用户发送宠物相关图片（病历截图、聊天记录、喂食照片等）或文字描述，
  自动识别并提取结构化信息，存储为长期健康记录。支持查询历史记录和健康趋势分析。
  触发词：宠物记录、记录一下、帮我记、狗狗/猫咪怎么样、健康记录、pet、pet record。
---

# 宠物记录 Skill

本 Skill 将 WorkBuddy 变成一个「宠物健康记录终端」。用户只需发送图片或描述，即可完成记录。

## 核心流程

### 1. 识别并记录（主要入口）

当用户发送图片或文字描述宠物相关事件时：

1. **提取信息**：调用 Qwen VL AI（`references/ai_prompt.md`）从图片/文字中提取结构化数据
2. **展示确认**：向用户展示识别结果，等待确认
3. **存储记录**：确认后存入 `~/.workbuddy/skills/pet-record/data/records.json`
4. **提示日程**：若识别结果包含 `schedules`，提示用户是否创建提醒

### 2. 查询记录

当用户询问宠物健康状况时：

1. 读取 `data/records.json`
2. 使用 AI 分析趋势、异常、总结
3. 返回自然语言报告

### 3. 数据存储格式

每条记录存储为 JSON 对象，schema 见 `references/schema.md`。

## 文件结构

```
~/.workbuddy/skills/pet-record/
├── SKILL.md              # 本文件
├── scripts/
│   └── recognize.py     # 调用 Qwen API 进行图片/文字识别
├── references/
│   ├── schema.md        # 数据 schema 定义
│   ├── ai_prompt.md     # AI 识别 prompt 模板
│   └── api_config.md    # API 配置说明
└── data/
    └── records.json     # 记录存储（运行时生成）
```

## 使用说明

### 首次使用

需要配置 Qwen API Key：
- 让用户提供 API Key（从阿里云 DashScope 获取）
- 存入 `~/.workbuddy/skills/pet-record/data/config.json`：`{"api_key": "sk-..."}`

### 记录新事件

用户发送图片或说「帮我记录一下，今天狗狗吐了」：

1. 读取 `scripts/recognize.py` 了解调用方式
2. 调用脚本进行识别
3. 向用户展示结果并确认
4. 确认后追加到 `data/records.json`

### 查询健康记录

用户问「狗狗最近怎么样」或「上次驱虫是什么时候」：

1. 读取 `data/records.json`
2. 用 AI 分析并回答

## 注意事项

- API Key 是敏感信息，不要输出到日志或用户消息中
- 识别结果必须让用户确认后再存储
- `records.json` 是不断增长的文件，注意文件大小（超过 1MB 时提示用户归档）
- 图片识别前先将图片保存到 `data/images/` 目录（base64 或文件路径）
