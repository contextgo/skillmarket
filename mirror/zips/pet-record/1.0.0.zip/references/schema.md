# 数据 Schema 定义

## Record（单条记录）

```json
{
  "_id": "字符串，唯一 ID（timestamp + random）",
  "petName": "宠物名字，如：土豆、Cookie",
  "type": "medical | diet | growth | grooming",
  "title": "简短标题，不超过 20 字",
  "content": "详细内容描述",
  "eventDate": "YYYY-MM-DD",
  "imagePath": "图片存储路径（可选）",
  "confidence": 0.0-1.0,
  "schedules": [
    {
      "title": "日程标题",
      "date": "YYYY-MM-DD",
      "time": "HH:mm（可选）",
      "done": false
    }
  ],
  "createdAt": "ISO 8601 时间戳"
}
```

## 字段说明

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `_id` | string | ✅ | 唯一标识，格式：`{timestamp}_{random}` |
| `petName` | string | ✅ | 宠物名字，支持多宠物 |
| `type` | string | ✅ | 记录类型 |
| `title` | string | ✅ | 简短标题 |
| `content` | string | ✅ | 详细内容 |
| `eventDate` | string | ✅ | 事件发生日期 |
| `imagePath` | string | ❌ | 图片相对路径，如 `data/images/2026-05-01_abc.png` |
| `confidence` | number | ✅ | AI 识别置信度 |
| `schedules` | array | ❌ | 关联日程提醒 |
| `createdAt` | string | ✅ | 记录创建时间（ISO 8601） |

## records.json 文件结构

```json
{
  "pets": ["土豆", "Cookie"],
  "records": [
    { "_id": "...", "petName": "土豆", "type": "medical", ... },
    { "_id": "...", "petName": "土豆", "type": "diet", ... }
  ]
}
```

## 查询示例

### 获取某宠物所有记录
```js
records.filter(r => r.petName === "土豆")
```

### 获取某类型记录
```js
records.filter(r => r.type === "medical")
```

### 获取某日期记录
```js
records.filter(r => r.eventDate === "2026-05-01")
```

### 获取最近 N 条记录
```js
records.sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, N)
```
