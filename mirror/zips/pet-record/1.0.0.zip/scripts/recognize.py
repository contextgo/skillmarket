#!/usr/bin/env python3
"""
pet-record: AI recognition script (fixed version)
Usage:
  python3 recognize.py --image <image_path> [--api-key <key>] [--pet-name <name>]
  python3 recognize.py --text <text_description> [--api-key <key>] [--pet-name <name>]
"""

import argparse
import base64
import json
import sys
import urllib.request
import urllib.error
from datetime import date
from pathlib import Path

SCRIPT_DIR = Path(__file__).parent
CONFIG_PATH = SCRIPT_DIR.parent / "data" / "config.json"
API_URL = "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions"
MODEL = "qwen-vl-plus"

TODAY = date.today().isoformat()


def load_config():
    if CONFIG_PATH.exists():
        with open(CONFIG_PATH, "r") as f:
            return json.load(f)
    return {}


def image_to_base64(image_path: str) -> str:
    with open(image_path, "rb") as f:
        return base64.b64encode(f.read()).decode("utf-8")


def build_prompt(is_image: bool) -> str:
    today_note = (
        "\n\nIMPORTANT: Today is {}. If user says 'today' or does not specify a date, "
        "use {} as eventDate."
    ).format(TODAY, TODAY)

    base_rules = """
Type classification rules:
- medical: health-related events (checkups, vaccines, deworming, vet visits, medication, vomiting, diarrhea, injury)
- diet: feeding, food changes, water intake, nutrition supplements
- growth: weight, height, behavioral changes
- grooming: bathing, hair cutting, nail trimming, ear cleaning, brushing

Rules:
1. eventDate: if user says 'today', use TODAY; if uncertain, use TODAY
2. type: health issues (vomiting, diarrhea, injury) should be classified as medical
3. confidence: 0.9+ clear info, 0.7-0.9 somewhat clear, 0.4-0.7 uncertain, 0.0-0.4 unrecognizable
4. Return ONLY the JSON object, no other text
"""

    if is_image:
        return (
            "You are a pet health record assistant. Analyze the uploaded image "
            "(chat screenshot, medical report, feeding photo, etc.) and extract "
            "structured pet-related information.\n\n"
            "Return strictly in this JSON format:\n"
            '{"type":"medical"|"diet"|"growth"|"grooming",'
            '"title":"short title, max 20 chars",'
            '"content":"detailed description, max 100 chars",'
            '"eventDate":"YYYY-MM-DD",'
            '"confidence":0.0-1.0,'
            '"schedules":[]}\n\n' + base_rules + today_note
        )
    else:
        return (
            "You are a pet health record assistant. Extract structured information "
            "from the user's text description.\n\n"
            "Return strictly in this JSON format:\n"
            '{"type":"medical"|"diet"|"growth"|"grooming",'
            '"title":"short title, max 20 chars",'
            '"content":"detailed description, max 100 chars",'
            '"eventDate":"YYYY-MM-DD",'
            '"confidence":0.0-1.0,'
            '"schedules":[]}\n\n' + base_rules + today_note
        )


def call_qwen(api_key: str, messages: list) -> dict:
    payload = {
        "model": MODEL,
        "messages": messages,
        "max_tokens": 500,
        "temperature": 0.3
    }
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        API_URL,
        data=data,
        headers={
            "Content-Type": "application/json",
            "Authorization": "Bearer {}".format(api_key)
        },
        method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8")
        raise RuntimeError("API error {}: {}".format(e.code, body))
    except urllib.error.URLError as e:
        raise RuntimeError("Network error: {}".format(e.reason))


def extract_json(text: str) -> dict:
    import re
    match = re.search(r"\{[\s\S]*\}", text)
    if not match:
        raise ValueError("Cannot extract JSON from response: {}".format(text))
    return json.loads(match.group())


def recognize_image(api_key: str, image_path: str, text_hint: str = "") -> dict:
    base64_image = image_to_base64(image_path)
    content = [
        {"type": "image_url", "image_url": {"url": "data:image/jpeg;base64,{}".format(base64_image)}},
        {"type": "text", "text": text_hint or "Please analyze pet-related information in this image."}
    ]
    messages = [
        {"role": "system", "content": build_prompt(is_image=True)},
        {"role": "user", "content": content}
    ]
    result = call_qwen(api_key, messages)
    text = result["choices"][0]["message"]["content"]
    return extract_json(text)


def recognize_text(api_key: str, text: str) -> dict:
    messages = [
        {"role": "system", "content": build_prompt(is_image=False)},
        {"role": "user", "content": "User input: {}".format(text)}
    ]
    result = call_qwen(api_key, messages)
    text = result["choices"][0]["message"]["content"]
    return extract_json(text)


def main():
    parser = argparse.ArgumentParser(description="Pet Record AI Recognition")
    parser.add_argument("--image", help="Image file path")
    parser.add_argument("--text", help="Text description")
    parser.add_argument("--api-key", help="Qwen API Key")
    parser.add_argument("--pet-name", help="Pet name")
    args = parser.parse_args()

    if not args.image and not args.text:
        print(json.dumps({"error": "Please provide --image or --text"}))
        sys.exit(1)

    api_key = args.api_key
    if not api_key:
        config = load_config()
        api_key = config.get("api_key", "")
    if not api_key:
        print(json.dumps({"error": "API Key not configured"}))
        sys.exit(1)

    try:
        if args.image:
            result = recognize_image(api_key, args.image, args.text or "")
        else:
            result = recognize_text(api_key, args.text)

        if args.pet_name:
            result["petName"] = args.pet_name

        # Fallback: fix obviously wrong dates
        event_date = result.get("eventDate", "")
        if event_date < "2024-01-01" or event_date > TODAY:
            result["eventDate"] = TODAY

        print(json.dumps(result, ensure_ascii=False))
    except Exception as e:
        print(json.dumps({"error": str(e)}))
        sys.exit(1)


if __name__ == "__main__":
    main()
