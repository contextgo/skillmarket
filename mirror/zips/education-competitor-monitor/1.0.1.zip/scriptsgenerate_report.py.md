#!/usr/bin/env python3
"""
竞品雷达 - 周报生成脚本
将 Agent 抓取的结构化数据转换为 Markdown 格式的竞品周报
"""

import argparse
import json
import os
from datetime import datetime, timedelta


def parse_args():
    parser = argparse.ArgumentParser(description="生成竞品周报")
    parser.add_argument("--output", required=True, help="输出文件路径")
    parser.add_argument("--date", required=True, help="报告日期 (YYYY-MM-DD)")
    parser.add_argument("--raw-data", help="原始数据JSON文件路径（可选）")
    return parser.parse_args()


def build_report_header(date_str):
    """生成报告头部"""
    date_obj = datetime.strptime(date_str, "%Y-%m-%d")
    week_start = date_obj - timedelta(days=date_obj.weekday())  # 本周一
    week_end = week_start + timedelta(days=6)  # 本周日
    
    return f"""# 🕵️ 竞品雷达周报 | {week_start.strftime('%Y年%m月%d日')} - {week_end.strftime('%Y年%m月%d日')}

## 一、本周概览
| 赛道          | 新增动态数 | 高相关动态数 | 需重点关注 |
| ------------- | ---------- | ------------ | ---------- |
| 脑机接口(BCI) | -          | -            | -          |
| 编程教育      | -          | -            | -          |
| 其他相关      | -          | -            | -          |

"""


def build_bci_section(raw_data=None):
    """生成脑机接口赛道章节"""
    return """## 二、重点动态详情

### 🔴 脑机接口(BCI)
| 公司/产品                     | 动态类型 | 核心信息 | 可信度 | 与我们的相关性 | 信息来源 |
| ----------------------------- | -------- | -------- | ------ | -------------- | -------- |
| （本周动态将由Agent自动填充） | -        | -        | -      | -              | -        |

"""


def build_coding_edu_section(raw_data=None):
    """生成编程教育赛道章节"""
    return """### 🟡 编程教育
| 公司/产品                     | 动态类型 | 核心信息 | 可信度 | 与我们的相关性 | 信息来源 |
| ----------------------------- | -------- | -------- | ------ | -------------- | -------- |
| （本周动态将由Agent自动填充） | -        | -        | -      | -              | -        |

"""


def build_other_section():
    """生成其他相关章节"""
    return """### 🟢 其他相关
| 公司/产品      | 动态类型 | 核心信息 | 可信度 | 与我们的相关性 | 信息来源 |
| -------------- | -------- | -------- | ------ | -------------- | -------- |
| （本周无数据） | -        | -        | -      | -              | -        |

"""


def build_deep_analysis_section():
    """生成深度竞品分析章节"""
    return """## 三、深度竞品分析（仅高相关条目）
> 此章节由Agent在运行时根据高相关动态自动生成，
> 包含SWOT矩阵、定价对比、用户痛点识别。

"""


def build_trends_section():
    """生成市场趋势章节"""
    return """## 四、市场趋势与信号
1. **趋势洞察将由Agent根据本周数据自动提炼**

"""


def build_diff_section():
    """生成差异对比章节"""
    return """## 五、本周对比上周（差异清单）
| 状态                   | 赛道 | 公司/产品 | 动态描述 | 上周状态 | 本周变化 |
| ---------------------- | ---- | --------- | -------- | -------- | -------- |
| （本周无历史数据对比） | -    | -         | -        | -        | -        |

"""


def build_action_section():
    """生成行动建议章节"""
    return """## 六、行动建议（面向我方产品团队）
1. **立即关注**：（Agent将根据高相关性动态自动生成）
2. **本周跟进**：（Agent将根据中等相关性动态自动生成）
3. **持续监测**：（Agent将根据低相关性但高潜力动态自动生成）

"""


def build_source_section(raw_data=None):
    """生成信源链接章节"""
    return """## 七、信源链接汇总
- Product Hunt: https://www.producthunt.com
- Hacker News: https://news.ycombinator.com
- TechCrunch: https://techcrunch.com
- Kickstarter: https://www.kickstarter.com
- Indiegogo: https://www.indiegogo.com

---
> 报告由 OpenClaw 竞品雷达 Skill 自动生成
> 下次扫描时间：下周一 08:00 (北京时间)
> """


def main():
    args = parse_args()
    
    # 构建报告各部分
    report = ""
    report += build_report_header(args.date)
    report += build_bci_section()
    report += build_coding_edu_section()
    report += build_other_section()
    report += build_deep_analysis_section()
    report += build_trends_section()
    report += build_diff_section()
    report += build_action_section()
    report += build_source_section()
    
    # 写入文件
    os.makedirs(os.path.dirname(args.output), exist_ok=True)
    with open(args.output, "w", encoding="utf-8") as f:
        f.write(report)
    
    print(f"✅ 周报已生成：{args.output}")
    print(f"📄 报告大小：{len(report)} 字符")
    print(f"ℹ️ 提示：报告中的动态数据将由OpenClaw Agent在执行时填充")


if __name__ == "__main__":
    main()