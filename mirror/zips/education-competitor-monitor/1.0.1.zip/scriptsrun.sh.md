#!/bin/bash
# ==========================================
# 竞品雷达 - 主执行脚本 v1.1
# 新增：网络预检 + Tavily 兜底逻辑
# ==========================================

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SKILL_DIR="$(dirname "$SCRIPT_DIR")"
REPORT_DIR="${HOME}/reports/competitor-monitor"
LOG_DIR="${SKILL_DIR}/logs"
TIMESTAMP=$(date +"%Y-%m-%d_%H-%M-%S")
WEEK_TAG=$(date +"%Y-%m-%d")

mkdir -p "${REPORT_DIR}"
mkdir -p "${LOG_DIR}"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "${LOG_DIR}/run_${TIMESTAMP}.log"
}

log "🚀 竞品雷达启动 (v1.1)"

# 步骤0：网络预检
log "🌐 步骤0：网络预检"

# 检测海外 RSS 源是否可达
OVERSEAS_SOURCES=(
    "https://www.producthunt.com/feed"
    "https://techcrunch.com/feed/"
    "https://www.theverge.com/rss/index.xml"
)

OVERSEAS_REACHABLE=true
for source in "${OVERSEAS_SOURCES[@]}"; do
    if curl -s --connect-timeout 10 --max-time 15 -o /dev/null -w "%{http_code}" "$source" | grep -q "200\|301\|302"; then
        log "  ✅ 可达: $source"
    else
        log "  ❌ 不可达: $source"
        OVERSEAS_REACHABLE=false
    fi
done

if [ "$OVERSEAS_REACHABLE" = false ]; then
    log "⚠️ 部分海外源不可达，将启用 Tavily 兜底"
fi

# 检查 Tavily API Key 是否已配置
if [ -z "${TAVILY_API_KEY}" ]; then
    log "⚠️ 未检测到 TAVILY_API_KEY 环境变量，Tavily 兜底将不可用"
    log "💡 请在腾讯云环境变量中配置 TAVILY_API_KEY"
fi

# 步骤1：环境检查
log "📋 步骤1：环境检查"
if ! command -v python3 &> /dev/null; then
    log "❌ 未找到 python3"
    exit 1
fi
log "✅ Python3 就绪"

# 步骤2：执行抓取与分析
log "🔍 步骤2：开始执行竞品扫描与分析"
log "抓取策略：海外源优先 RSS，不可达则 Tavily；国内源直连"
log "开始时间：$(date '+%Y-%m-%d %H:%M:%S')"

# 此处由 OpenClaw Agent 运行时注入抓取结果

# 步骤3：生成周报
log "📝 步骤3：生成竞品周报"
REPORT_PATH="${REPORT_DIR}/竞品周报-${WEEK_TAG}.md"

python3 "${SCRIPT_DIR}/generate_report.py" \
    --output "${REPORT_PATH}" \
    --date "${WEEK_TAG}" \
    --raw-data "${LOG_DIR}/raw_data_${TIMESTAMP}.json" \
    2>&1 | tee -a "${LOG_DIR}/run_${TIMESTAMP}.log"

if [ -f "${REPORT_PATH}" ]; then
    log "✅ 周报已生成：${REPORT_PATH}"
else
    log "❌ 周报生成失败"
    exit 1
fi

# 步骤4：通知推送
log "📢 步骤4：通知推送（如已配置）"
# Agent 根据 config.yaml 执行通知

log "🏁 竞品雷达执行完毕"
log "📄 周报位置：${REPORT_PATH}"
log "📋 执行日志：${LOG_DIR}/run_${TIMESTAMP}.log"

exit 0