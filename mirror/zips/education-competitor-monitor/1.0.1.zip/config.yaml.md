# ==========================================
# 竞品雷达 Skill 配置文件
# ==========================================

skill:
  name: "competitor-monitor"
  version: "1.1.0"
  author: "产品团队"
  description: "每周自动扫描BCI和编程教育赛道竞品动态，生成结构化周报"

# 定时任务配置（云端部署时生效）
schedule:
  cron: "0 8 * * 1"
  timezone: "Asia/Shanghai"

# 报告输出配置
report:
  output_dir: "~/reports/competitor-monitor"
  filename_format: "竞品周报-{date}.md"
  keep_history: 12

# 网络与抓取策略
network:
  preflight_check: true              # 抓取前先检测目标是否可达
  fallback_to_tavily: true           # 不可达时自动切换 Tavily
  overseas_sources: "rss_or_tavily"  # 海外源优先 RSS，不可用则 Tavily
  domestic_sources: "direct"         # 国内源直连
  timeout_seconds: 30

# Tavily Search API（兜底搜索引擎）
tavily:
  enabled: true
  api_key_env: "TAVILY_API_KEY"      # 在腾讯云环境变量里配置
  max_results: 10
  include_answer: true

# 重试与容错
retry:
  max_attempts: 3
  backoff_seconds: 30
  timeout_seconds: 60

# 通知配置（可选）
notifications:
  wecom:
    enabled: false
    webhook_url: ""
  feishu:
    enabled: false
    webhook_url: ""
  email:
    enabled: false
    smtp_host: ""
    smtp_port: 587
    sender: ""
    recipients: []
    credentials:
      username: ""
      password_env: ""

# 监测目标配置
targets:
  bci:
    enabled: true
    keywords:
      - "brain computer interface"
      - "BCI"
      - "脑机接口"
      - "脑机"
      - "neurotechnology"
      - "脑电"
      - "EEG"
      - "SSVEP"
      - "运动想象"

  coding_education:
    enabled: true
    keywords:
      - "编程教育"
      - "少儿编程"
      - "编程赛事"
      - "机器人编程"
      - "coding education"
      - "STEM"
      - "block coding"
    competitors:
      - name: "编程猫"
        url: "https://www.codemao.cn"
        type: "direct"
      - name: "鲸鱼机器人"
        url: "https://www.whalesbot.com"
        type: "direct"
      - name: "小码王"
        url: "https://www.xiaomawang.com"
        type: "direct"
      - name: "童程童美"
        type: "search"
      - name: "Tynker"
        url: "https://www.tynker.com"
        type: "indirect"
      - name: "Lego Education"
        url: "https://education.lego.com/en-us"
        type: "indirect"
      - name: "VEX Robotics"
        url: "https://www.vexrobotics.com"
        type: "indirect"
      - name: "Makeblock"
        url: "https://www.makeblock.com"
        type: "indirect"

# 调试模式
debug:
  enabled: false
  save_raw_data: false