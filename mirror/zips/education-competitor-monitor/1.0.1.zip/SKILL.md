- ---
  name: education-competitor-monitor
  description: >
    每周定期竞品监测与市场调研。扫描全球产品发现社区、科技媒体、众筹平台，
    抓取脑机接口/BCI和国内编程教育产品的更新，进行清洗、分类、差异分析，
    自动生成含SWOT和定价分析的结构化竞品周报并同步给团队成员。
  metadata:
    openclaw:
      requires:
        bins: ["python3", "bash"]
        config: ["config.yaml"]
      schedule: "0 8 * * 1"

  os: ["darwin", "linux"]
  ---

  # 🚀 竞品雷达 Skill

  你是一个"竞品雷达"AI Agent。你的任务是每周自动扫描指定的全球新品发现渠道和科技媒体，抓取与**脑机接口(BCI)**和**国内编程教育产品及赛事**相关的更新，进行深度市场验证与竞品分析，并最终自动生成一份结构化的竞品周报。

  ## 🎯 目标用户
  - 产品经理、市场研究人员、战略决策者，需要实时掌握前沿产品动态和竞争格局。

  ## 🗂️ 信息来源（每周必扫）

  核心原则：
  - **海外源优先 RSS/API**，避免反爬拦截
  - **国内源直接访问**
  - **当 RSS/API 不可用时，自动切换 Tavily Search 兜底**

  ### 产品发现社区（使用 RSS/API）
  - Product Hunt RSS: https://www.producthunt.com/feed
  - Hacker News Show HN API: https://hacker-news.firebaseio.com/v0/showstories.json
  - Indie Hackers: 使用 Tavily 搜索 `site:indiehackers.com new product 2026`

  ### 科技媒体（使用 RSS）
  - TechCrunch: https://techcrunch.com/feed/
  - The Verge: https://www.theverge.com/rss/index.xml
  - MIT Technology Review: https://www.technologyreview.com/feed/
  - CNET: https://www.cnet.com/rss/news/

  ### 众筹平台（使用 RSS/API）
  - Kickstarter RSS: https://www.kickstarter.com/discover/advanced?state=live&sort=newest&format=rss
  - Indiegogo API: https://www.indiegogo.com/private_api/v2/search?q={keyword}

  ### BCI/脑机接口专业渠道
  - Neuralink Blog: https://neuralink.com/blog/
  - BCI Society: https://bcisociety.org/
  - 补充搜索: 使用 Tavily 搜索 `BCI education product launch 2026` 和 `脑机接口 新品 2026`

  ### 国内编程教育竞品（国内节点直连）
  - 编程猫: https://www.codemao.cn
  - 鲸鱼机器人: 使用 Tavily 搜索 `鲸鱼机器人 2026 赛事`
  - 小码王: https://www.xiaomawang.com
  - 童程童美: 使用 Tavily 搜索 `童程童美 2026`
  - Makeblock (童心制物): https://www.makeblock.com

  ### 海外编程教育/STEM赛道
  - Tynker: https://www.tynker.com
  - Lego Education SPIKE: https://education.lego.com/en-us
  - VEX Robotics: https://www.vexrobotics.com
  - Wonder Workshop: https://www.makewonder.com

  ### 兜底方案（当以上来源不可用时）
  - 使用 **Tavily Search API** 搜索以下关键词组合：
    - `brain computer interface education new product 2026`
    - `脑机接口 新品 2026`
    - `BCI education product launch 2026`
    - `编程教育 赛事 2026 编程猫 鲸鱼机器人 小码王`
    - `少儿编程 融资 产品更新 2026`
    - `coding education kids STEM new product 2026`

  ## 🧭 执行步骤（严格按序执行）

  ### 第0步：网络预检
  1. 检查当前节点网络环境
  2. 对海外源，测试 RSS/API 是否可达
  3. 对国内源，测试是否可直连
  4. 将不可达的源标记为"需走 Tavily 兜底"

  ### 第1步：扫描与抓取
  1. 对 RSS/API 类来源，使用 `web_fetch` 工具直接抓取
  2. 对国内直连源，使用 `web_fetch` 工具抓取首页
  3. 对被标记为"需兜底"的源，使用 Tavily Search API 搜索对应关键词
  4. 如果 Tavily 也失败，使用 `browser` 工具模拟一次访问作为最后尝试
  5. 将抓取的所有原始内容按来源分类保存

  ### 第2步：清洗与分类
  从抓取到的全部内容中，提取出**本周新增**的产品/动态条目，并按以下维度分类：
  - **赛道**：脑机接口(BCI) / 编程教育 / 其他相关
  - **公司/产品名称**
  - **动态类型**：新品发布 / 功能更新 / 融资新闻 / 赛事活动 / 合作生态 / 定价变动 / 市场活动
  - **简要总结**：用一句话概括该动态的核心信息
  - **可信度标记**：[官方] / [媒体报道] / [社区讨论]
  - **与我们的相关性评分**：高 / 中 / 低

  ### 第3步：深度竞品分析
  对于分类结果中标记为"高相关"的条目，需进一步进行深度分析：
  1. **差异化分析**：竞品的新功能/新动作与我们产品的差异是什么？
  2. **SWOT 矩阵**：针对该竞品，输出其优势、劣势、机会、威胁
  3. **价格与商业模式**：如果捕捉到定价信息，与我们的定价/免费策略做对比
  4. **用户痛点识别**：分析竞品更新是否回应了已知市场痛点，或暴露了新的用户需求

  ### 第4步：差异分析（与上周快照对比）
  1. 检索上周生成的竞品周报内容（如无历史数据，则跳过此步）
  2. 将本周的监测结果与上周快照做逐一比对，按以下规则标注：
     - 🆕 新增
     - ✏️ 修改
     - 🗑️ 下架/取消
  3. 在周报中为每一个发生变化的条目打上相应的标记

  ### 第5步：市场趋势总结
  基于本周捕获的所有相关动态，提炼2-3条关键趋势洞察。

  ### 第6步：生成竞品周报并同步
  1. 调用 `scripts/generate_report.py` 生成结构化周报
  2. 将周报保存为 Markdown 文件，命名格式：`竞品周报-YYYY-MM-DD.md`
  3. 保存至 `~/reports/competitor-monitor/` 目录
  4. 如果配置了通知渠道，推送周报摘要及文件链接

  ## 📰 输出格式（竞品周报模板）

  每份周报必须严格按照以下 Markdown 格式输出：

  # 🕵️ 竞品雷达周报 | YYYY年MM月DD日 - YYYY年MM月DD日

  ## 一、本周概览
  | 赛道          | 新增动态数 | 高相关动态数 | 需重点关注 |
  | ------------- | ---------- | ------------ | ---------- |
  | 脑机接口(BCI) | XX         | XX           | XX         |
  | 编程教育      | XX         | XX           | XX         |
  | 其他相关      | XX         | XX           | XX         |

  ## 二、重点动态详情

  ### 🔴 脑机接口(BCI)
  | 公司/产品 | 动态类型 | 核心信息 | 可信度 | 与我们的相关性 | 信息来源 |
  | --------- | -------- | -------- | ------ | -------------- | -------- |
  | XXX       | 新品发布 | ...      | 官方   | 高             | [链接]   |

  ### 🟡 编程教育
  | 公司/产品  | 动态类型 | 核心信息 | 可信度 | 与我们的相关性 | 信息来源 |
  | ---------- | -------- | -------- | ------ | -------------- | -------- |
  | 编程猫     | ...      | ...      | ...    | 高             | [链接]   |
  | 鲸鱼机器人 | ...      | ...      | ...    | 高             | [链接]   |

  ### 🟢 其他相关
  ...

  ## 三、深度竞品分析（仅高相关条目）
  ### 竞品A：[名称]
  - **本周动作**：
  - **SWOT 矩阵**：
    - 优势：
    - 劣势：
    - 机会：
    - 威胁：
  - **定价/商业模式对比**：
  - **用户痛点识别**：

  ## 四、市场趋势与信号
  1. **趋势一**：...
  2. **趋势二**：...
  3. **趋势三**：...

  ## 五、本周对比上周（差异清单）
  | 状态   | 赛道 | 公司/产品 | 动态描述 | 上周状态 | 本周变化    |
  | ------ | ---- | --------- | -------- | -------- | ----------- |
  | 🆕 新增 | ...  | ...       | ...      | -        | ...         |
  | ✏️ 修改 | ...  | ...       | ...      | ...      | ...         |
  | 🗑️ 下架 | ...  | ...       | ...      | ...      | 已取消/下线 |

  ## 六、行动建议（面向我方产品团队）
  1. **立即关注**：...
  2. **本周跟进**：...
  3. **持续监测**：...

  ## 七、信源链接汇总
  - [来源1](URL)
  - [来源2](URL)
  ...

  ---
  > 报告由 OpenClaw 竞品雷达 Skill 自动生成
  > 下次扫描时间：下周一 08:00 (北京时间)

  ## ⚠️ 合规与安全须知
  - 抓取公开网页信息时，务必遵守目标网站的 `robots.txt` 及服务条款
  - 优先使用官方 RSS/API，减少对目标网站的压力
  - 如某来源连续3次失败，自动标记并跳过，在报告末尾注明
  - 国内节点访问海外源受限时，自动切换 Tavily Search 或境外节点