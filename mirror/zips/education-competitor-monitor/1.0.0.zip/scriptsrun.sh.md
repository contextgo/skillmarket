#!/bin/bash
# ==========================================
# 竞品雷达 - 主执行脚本
# 用途：串联整个扫描→分析→报告流程
# ==========================================

set -e  # 遇到错误立即退出

# 配置
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SKILL_DIR="$(dirname "$SCRIPT_DIR")"
REPORT_DIR="${HOME}/reports/competitor-monitor"
LOG_DIR="${SKILL_DIR}/logs"
TIMESTAMP=$(date +"%Y-%m-%d_%H-%M-%S")
WEEK_TAG=$(date +"%Y-%m-%d")

# 创建必要目录
mkdir -p "${REPORT_DIR}"
mkdir -p "${LOG_DIR}"

# 日志函数
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "${LOG_DIR}/run_${TIMESTAMP}.log"
}

log "🚀 竞品雷达启动"

# 步骤1：环境检查
log "📋 步骤1：环境检查"
if ! command -v python3 &> /dev/null; then
    log "❌ 错误：未找到 python3，请先安装 Python 3"
    exit 1
fi
log "✅ Python3 环境就绪"

# 步骤2：执行抓取与分析（由 OpenClaw Agent 驱动）
log "🔍 步骤2：开始执行竞品扫描与分析"
log "此步骤由 OpenClaw Agent 通过 web_fetch/browser/search 工具执行"
log "监测范围：BCI赛道 + 编程教育赛道"
log "开始时间：$(date '+%Y-%m-%d %H:%M:%S')"

# 此处由 OpenClaw Agent 在运行时注入抓取结果
# Agent 会将抓取结果以 JSON 格式传递给下一步的报告生成脚本

# 步骤3：生成周报
log "📝 步骤3：生成竞品周报"
REPORT_PATH="${REPORT_DIR}/竞品周报-${WEEK_TAG}.md"

# Agent 会在此步骤调用 Python 脚本生成报告
python3 "${SCRIPT_DIR}/generate_report.py" \
    --output "${REPORT_PATH}" \
    --date "${WEEK_TAG}" \
    --raw-data "${LOG_DIR}/raw_data_${TIMESTAMP}.json" \
    2>&1 | tee -a "${LOG_DIR}/run_${TIMESTAMP}.log"

if [ -f "${REPORT_PATH}" ]; then
    log "✅ 周报已生成：${REPORT_PATH}"
else
    log "❌ 错误：周报生成失败"
    exit 1
fi

# 步骤4：通知推送
log "📢 步骤4：通知推送"

# 检查是否配置了微信通知
if grep -q "enabled: true" "${SKILL_DIR}/config.yaml" 2>/dev/null; then
    log "📱 检测到通知配置，尝试推送周报..."
    # 此处由 Agent 根据 config.yaml 的配置执行推送
else
    log "ℹ️ 未配置通知渠道，跳过推送"
fi

log "🏁 竞品雷达执行完毕"
log "📄 周报位置：${REPORT_PATH}"
log "📋 执行日志：${LOG_DIR}/run_${TIMESTAMP}.log"

exit 0