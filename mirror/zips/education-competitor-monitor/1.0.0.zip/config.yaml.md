# ==========================================
# 竞品雷达 Skill 配置文件
# 修改此文件后无需重启，下次执行时自动生效
# ==========================================

# 基础信息
skill:
  name: "competitor-monitor"
  version: "1.0.0"
  author: "产品团队"
  description: "每周自动扫描BCI和编程教育赛道竞品动态，生成结构化周报"

# 定时任务配置（云端部署时生效）
schedule:
  cron: "0 8 * * 1"           # 每周一早8点
  timezone: "Asia/Shanghai"    # 北京时间

# 报告输出配置
report:
  output_dir: "~/reports/competitor-monitor"  # 报告保存目录
  filename_format: "竞品周报-{date}.md"        # 文件名格式
  keep_history: 12                            # 保留最近几期周报（按月算）

# 通知配置（可选，按需填写）
notifications:
  # 企业微信机器人
  wecom:
    enabled: false
    webhook_url: ""           # 填入企业微信机器人 Webhook 地址

  # 飞书机器人
  feishu:
    enabled: false
    webhook_url: ""           # 填入飞书机器人 Webhook 地址

  # 邮件通知
  email:
    enabled: false
    smtp_host: ""             # SMTP 服务器地址
    smtp_port: 587
    sender: ""                # 发件人邮箱
    recipients:               # 收件人列表
      - ""
    credentials:
      username: ""            # 邮箱账号
      password_env: ""        # 邮箱密码（建议用环境变量）

# 监测目标配置
targets:
  # 脑机接口赛道
  bci:
    enabled: true
    keywords:
      - "brain computer interface"
      - "BCI"
      - "脑机接口"
      - "脑机"
      - "neurotechnology"
      - "脑电"
      - "EEG"
      - "SSVEP"
      - "运动想象"
    sources:
      product_hunt: true
      hacker_news: true
      techcrunch: true
      kickstarter: true
      indiegogo: true
      bci_society: true

  # 编程教育赛道
  coding_education:
    enabled: true
    keywords:
      - "编程教育"
      - "少儿编程"
      - "编程赛事"
      - "机器人编程"
      - "coding education"
      - "STEM"
      - "block coding"
    sources:
      product_hunt: true
      hacker_news: true
      techcrunch: true
    competitors:
      - name: "编程猫"
        url: "https://www.codemao.cn"
        type: "direct"
      - name: "鲸鱼机器人"
        url: "https://www.whalesbot.com"
        type: "direct"
      - name: "小码王"
        url: "https://www.xiaomawang.com"
        type: "direct"
      - name: "童程童美"
        type: "search"
      - name: "Tynker"
        url: "https://www.tynker.com"
        type: "indirect"
      - name: "Lego Education"
        url: "https://education.lego.com/en-us"
        type: "indirect"
      - name: "VEX Robotics"
        url: "https://www.vexrobotics.com"
        type: "indirect"
      - name: "Makeblock"
        url: "https://www.makeblock.com"
        type: "indirect"

# 重试与容错
retry:
  max_attempts: 3             # 单源最大重试次数
  backoff_seconds: 30         # 重试间隔秒数
  timeout_seconds: 60         # 单次请求超时

# 调试模式（本地测试时可开启）
debug:
  enabled: false              # 开启后输出详细日志
  save_raw_data: false        # 是否保存抓取到的原始HTML