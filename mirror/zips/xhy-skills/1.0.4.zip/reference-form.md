# 指南：表单（`open/ai/form/`）

路径：`{BASE}/open/ai/form/...`。用于按 JSON **创建整张表单**并得到 **`formId`**（以及读表、改字段等）。

**龙虾机器人**：`addForm` 使用 **`POST` + `Content-Type: application/json`**；**`paramType`** 须是**协会易表单接口认可的类型代码**（见本文「常用类型」「按需」「其余类型」），**禁止自造字符串**。**优先**只用「常用类型」即可覆盖多数登记表 / 问卷 / 打分表；需要本文未写明的能力时，**先向用户或技术对接确认可用的 `paramType` 再写**，不要凭猜测拼类型名。开放平台**不再提供** `GET .../supportFieldType`。

## 创建前与用户确认（强制）

**在未与用户就表单结构达成一致前，禁止调用 `addForm`。**

「结构」至少包括：**表单名称**（`formName`）、**是否打分表**（`useTo`）、**各 Tab**（`pageName` / `multiAble`）、**字段清单**（字段名、`paramType`、选项与说明等）、以及 **`subForm` / 嵌套子字段**的层次。若材料解析存在歧义（合并单元格、多表头、扫描误差等），应先向用户说明假设并请其拍板，**不得**自作主张直接落库。

解析并组装好**待提交的 JSON** 之后，**在调用 `addForm` 之前**，应把结构**以人类可读方式「渲染」给客户核对**，确认无误或按反馈改完 JSON 后再提交 API。开放平台**没有**「仅预览、不落库」的单独接口，因此预览完全在对话侧完成。

**建议的渲染方式（任选其一或组合，以用户能一眼核对为准）：**

1. **分级列表**：按 `pageInfos` → `pageName`，下列 `fieldInfos`：`fieldName`、**控件类型**（`paramType` + 常用表中的中文说明）、`tipMsg`、下拉 `options` 摘要等；`subForm` 下缩进列出 `nestedFields`。  
2. **Markdown 表格**：每个 Tab 一个小表，列为「字段名 | 类型 | 说明 | 选项」。  
3. **结构总览 + 原始 JSON**：核对篇幅长时，可总览 + 附加完整 JSON 代码块（提醒用户重点看总览）；用户明确要求别看 JSON 时以总览为准。

用户**明确确认**（例如「可以按这个建表」「没问题提交」）后，再执行 **`POST addForm`**。用户要求修改时，只改本地 JSON，**重新渲染 diff 或全量**后再征得确认。

## 接口列表

| 方法 | 路径 | 说明 |
|------|------|------|
| `POST` | `.../addForm` | `appKey` + JSON body；`data` 为 **`formId`** |

**推荐顺序**：对照本文 **「常用类型」** → **判断文档用途、确定 `useTo`**（见下文）→ 组装 JSON → **向用户渲染结构并征得确认**（见上文「创建前与用户确认」）→ **`POST addForm`**。

**效果概要**：创建主表单、各 Tab 及字段；**`subForm`** 且带 **`nestedFields`** 时一并建子表列。

## 表单 JSON 的常见来源（指南）

接口只认 **`addForm`** 的请求体；下面的结构一般要由**调用方、脚本或模型**先从材料里整理出来，再按本文 JSON 模型组装。

| 来源类型 | 说明 |
|----------|------|
| **Excel / WPS 表格等** | 表头、列名、下拉选项等容易对应到 `fieldName`、`paramType`、`options`；多 Sheet 可对应多个 `pageInfos`。合并单元格、复杂表头需人工或规则归一。 |
| **Word / 富文本文档** | 从标题层级、编号列表、表格行推导语义；版式乱或扫描件建议先清洗再映射。 |
| **PDF** | 可分两类：① 文本型 PDF，按段落/表格抽取；② 扫描件，需 OCR 后再抽取。识别误差要在提交前核对选项与必填含义。 |
| **网络资源** | 在**许可与合规**（版权、隐私、网站条款）前提下，从公开网页、附件下载页、在线表单说明里提取「字段清单」；勿对受保护或未授权数据做批量抓取。 |

**无论来源哪种材料**，在调 **`addForm` 之前**都应：

1. **`paramType`** 须合法（见下文「`paramType` 说明」）；**默认只从「常用类型」里选**，禁止自造 **`code`**。  
2. 按下文 **「是否打分表」** 判断 **`useTo`**（打分类务必标成打分类，避免误为普通登记表）。  
3. 子表、重复明细行优先用 **`subForm` + `nestedFields`** 表达，不要把「示例数据行」当成字段定义。  
4. **完成用户可见的渲染并与用户确认**（见「创建前与用户确认」）；未确认不调 `addForm`。

## 从各类材料整理出来时：是否「打分表」

在把 Excel / Word / PDF / 网页提取结果**落成 JSON 之前**，先判断是否**打分 / 评分**用途，以填写根字段 **`useTo`**：

- 文头 / 标题：评分、打分、评审、得分、权重等；
- 表格：评分标准、分值、满分、评委签字等；
- 说明：档级、加权汇总等。

**取值**：

- 明确打分场景 → **`useTo` 必须为 `3`**（打分表单）；
- 普通登记、非打分问卷 → 一般 **`useTo` 为 `1`**（常规表单）。

不确定时：以委托方为准；特征不足时默认 **`1`**，避免误标打分表。

## 请求体校验（`addForm`）

| 字段 | 要求 | 典型失败提示 |
|------|------|----------------|
| `formName` | 必填非空 | `formName can't be blank!` |
| `useTo` | 必填整数 | `useTo can't be blank!` |
| `pageInfos` | 必填且至少一项 | `pageInfos can't be empty!` |

## 表单名称重复（同协会下同 `title` 已存在）

同一 **`appKey` 对应 `shId`** 下，**`formName` 与库中已有表单标题相同**时，`addForm` **不会**再建新表，接口失败，**典型语义**为：表单已存在，并**在错误信息里带上已有表单的 `formId`**（文案以服务端返回为准，例如含 `formId:` 与数字）。

**必须遵守：**

- **禁止**为通过校验而**改掉 `formName` 再调一次 `addForm`** 当作「重新创建」——绕行会产生**另一张表**，与「沿用同名已有表」的预期不一致，易造成重复表单与绑定错表。
- **应**从本次失败的 **`errmsg` 中解析出已有 `formId`**，后续 **绑定问卷 / 项目申报** 等步骤**直接使用该 `formId`**（仍算**接口返回**来源，非用户手填）。
- 若业务上确实要**修改字段结构**，应在**该 `formId` 所指表单**上通过 **`getFormInfo` 对照结构**、**`updateField`** 等能力增量修改，而不是换名重建。

**通用 `formId` 使用规则**（与问卷/申报绑定一致）见总览 [`SKILL.md`](SKILL.md) 及 [`reference-declare.md`](reference-declare.md)。

## JSON 模型

### 根对象

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `formName` | string | 是 | 表单名称 |
| `useTo` | number | 是 | `1` 常规，`3` 打分 |
| `pageInfos` | array | 是 | Tab 列表 |

### `pageInfos` 每项

| 字段 | 类型 | 说明 |
|------|------|------|
| `pageName` | string | Tab 名 |
| `multiAble` | boolean \| null | 该 Tab 是否可提交多份 |
| `fieldInfos` | array | 字段列表 |

多层章节无嵌套 Tab：请拆成多个顶层 `pageInfos` 或同一页内排序。

### `fieldInfos` 每项

| 字段 | 类型 | 说明 |
|------|------|------|
| `fieldName` | string | 展示名 |
| `paramType` | string | 见下文「常用类型」「按需」「其余类型」；**仅**使用本文已列或委托方确认的 **`code`** |
| `options` | string[] \| null | `radio` / `select` / `selectMore` 等 |
| `tipMsg` | string \| null | 选填，短提示 |
| `fullTips` | string \| null | 选填，详细说明（可 HTML）；非空时多由服务端单独存储后再引用 |
| `nestedFields` | array \| null | **`subForm`** 时的列定义，结构同本表（**不得**再含嵌套 `subForm`，见下文） |

子表单：只描述**列结构**，勿把示例数据行当字段；**`nestedFields` 内不要**再放 `paramType: subForm`。打分表若无特别说明，末级字段常为数字类控件。

## `paramType` 说明（常用即可）

**`paramType` 必须是协会易接口能识别的类型代码**（本文已列出常用与部分扩展；服务端会校验，不认识的值会失败），**禁止自造字符串**。机器人 / 开放调用方**只依赖本文即可**，无需也不应引用工程源码。搭建登记表、问卷、打分表时**优先只用下面「常用类型」**；确需联动、数据源、统计、手签、视频等时，先用本文「其余类型」里是否已有对应 **`code`**，没有则**向委托方或技术对接确认**后再写入。

### 常用类型（优先）

| code | 说明 |
|------|------|
| `input` | 单行填空 |
| `textarea` | 多行文本 |
| `inputNum` | 数字（打分、数量、金额等） |
| `date` | 日期 / 时间选择 |
| `radio` | 单项选择（配 `options`） |
| `select` | 下拉单选（配 `options`） |
| `selectMore` | 多项选择（配 `options`） |
| `selectMoreTile` | 复选框平铺（配 `options`） |
| `region` | 省市区 |
| `address` | 详细地址 |
| `imgUpload` | 单图上传 |
| `multiUpload` | 多图上传 |
| `fileUpload` | 单文件上传 |
| `multiFileUpload` | 多文件上传 |
| `subForm` | 子表单（配 `nestedFields`）；场景见下 |
| `inputMore` | 多个短输入并排一格 |

**`subForm` 何时用**：① **重复明细**——同一类信息允许多条、多行填报（如多名联系人、多笔费用行）。② **结构比同级字段复杂**——同一 Tab 里其它字段多为单个控件，而某一整块需要**多列组合**成一组语义（像「一小块表格」），又不适合硬拆成多个互无关连的顶层字段时，可用子表单把这一块**收口成一个区域**。**不支持嵌套**：`nestedFields` 里只能是普通字段类型，**不能再出现** `paramType: subForm`；更深层级请用**多列平铺**、**拆成多个 Tab**，或拆分业务为多次填报 / 多张表。

### 按需（材料里出现长文排版、富文本时再考虑）

| code | 说明 |
|------|------|
| `fullInput` | 富文本 |

### 其余类型

如 `location`、`handSign`、`video`、`selectWithDataSource`、`secondaryLinkage`、`autoCalc`、`statistics`、`delimiter`、`displayFile` 等：**非业务明确要求不要轻易选用**，避免与数据源、后台配置不一致；本文未逐条展开的能力，**须经委托方或技术对接确认 `paramType` 后再用**。

（**维护本技能时**：可在工程内对照 `com.shy.common.enums.FormFieldTypeEnum` 增删改上表，保持与线上一致；**对外集成与龙虾机器人仅以本文为准**。）

## 请求示例

```http
POST {BASE}/open/ai/form/addForm?appKey=YOUR_APP_KEY
Content-Type: application/json
```

```json
{
  "formName": "会员单位登记表",
  "useTo": 1,
  "pageInfos": [
    {
      "pageName": "基本信息",
      "multiAble": false,
      "fieldInfos": [
        {
          "fieldName": "单位名称",
          "paramType": "input",
          "tipMsg": "须与营业执照一致"
        },
        {
          "fieldName": "单位类型",
          "paramType": "radio",
          "options": ["企业", "事业单位", "社会团体"],
          "fullTips": "<p>请按主体类型选择。</p>"
        },
        { "fieldName": "成立日期", "paramType": "date" }
      ]
    },
    {
      "pageName": "联系人",
      "multiAble": true,
      "fieldInfos": [
        {
          "fieldName": "联系人明细",
          "paramType": "subForm",
          "nestedFields": [
            { "fieldName": "姓名", "paramType": "input", "tipMsg": "实名" },
            { "fieldName": "手机", "paramType": "input" }
          ]
        }
      ]
    }
  ]
}
```

成功：`data` 为 **`formId`**。

---

**响应体通用约定**见 [`SKILL.md`](SKILL.md)。
