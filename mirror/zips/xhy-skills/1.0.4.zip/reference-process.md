# 指南：流程待办（`open/ai/process/`）

路径：`{BASE}/open/ai/process/...`。覆盖**待办列表**、**单条详情（申请摘要）**、**简易审批**。

**龙虾机器人**：**`audit` 为不可逆操作**；除非用户明确指令且业务允许，否则只读待办、展示摘要，**不调审批接口**。

## 接口列表

| 方法 | 路径 | 说明 |
|------|------|------|
| `GET` | `.../getMyTodo` | Query：`appKey`；`data` 为待办列表（条数为服务端分页策略，非全量） |
| `GET` | `.../processDetail` | Query：`appKey`，`processId`（流程实例 ID，与待办项 `id` 相同） |
| `POST` | `.../audit` | Query / form：`appKey`，`processId`，`remark`，`auditStatus` |

---

## `getMyTodo`：列表里每一条有哪些字段

字段含义与常见后台「待处理」列表相近；**手机号多已脱敏**。

| 字段 | 类型 | 说明 |
|------|------|------|
| **`id`** | Long | **流程实例 ID** → 作为 **`processId`** 调 `processDetail` 与 `audit` |
| **`processType`** | Integer | 类型码（见下文「按类型详述」） |
| **`processTypeShow`** | String | 类型中文（如「入会申请」） |
| **`applyUser`** | Long | 申请人用户 ID |
| **`applyUserName`** | String | 申请人姓名 |
| **`applyUserJobName`** | String | 申请人职务 |
| **`applyUserMobile`** | String | 申请人手机（脱敏后） |
| **`applyUserCompany`** | String | 申请人单位 |
| **`applySubject`** | String | 申请事项（一句话摘要）；**卡片 / 对话主标题一律用本字段**（详情 `applyDigest` 无此字段） |
| **`createTime`** | Date | 申请/流程创建时间 |
| **`nodeName`** | String | 当前节点名称 |
| **`processStatus`** | Integer | 流程状态码 |
| **`processStatusShow`** | String | 流程状态中文 |
| **`canRollback`** | Boolean | 是否允许回退上一节点 |

列表**不含**申请表正文；`processDetail` **也不返回**审批轨迹，仅申请摘要 **`applyDigest`**。

---

## `processDetail`：详情顶层结构

| 字段 | 类型 | 说明 |
|------|------|------|
| **`processId`** | Long | 流程实例 ID |
| **`processType`** | Integer | 类型码 |
| **`processTypeShow`** | String | 类型中文 |
| **`applyDigest`** | Object | 申请侧摘要，见下文 |

---

## 申请摘要 `applyDigest`：长什么样

**卡片/对话主标题**：优先用列表同一单对应的 **`getMyTodo.applySubject`**；若只有详情没有列表，可用 **`processTypeShow` + `processId`** 兜底。摘要块 **`applyDigest` 里通常不再重复**那句「申请事项」标题。

| 字段 | 类型 | 说明 |
|------|------|------|
| **`formAnswer`** | Object / null | **动态表单**树：多页、多字段；无表或没填时多为 `null` |
| **`extra`** | Map\<String, String\> | **键多为中文标签**的补充信息（非整张表或摘要表格式） |

### `formAnswer` 的树形大致结构

```text
formAnswer.pages[]:
  pageName          — 页名称（作分组标题）
  fields[]:
    fieldName       — 字段名（或题目名）
    answerItems[]   — 展示用答案条目（见下）
    subFields[]     — 子表/嵌套，结构同 fields（递归，层级过深时可能被限制）
```

部分场景下 **`fieldName`** 可能是内部存储 key，可结合 **`processType`** 与上级 **`pageName`** 理解含义。

### `answerItems[]` 里常见字段

序列化时**空字段可能被省略**，以实际响应为准。

| 字段 | 说明 |
|------|------|
| **`answer`** | 展示用文案（选项 label、拼接后的可读值、文件名字符串等，以实际类型为准） |
| **`bizValue`** | 选项或业务侧编码；`answer` 为空时可作补充 |
| **`otherOption`** | 「其他」类手填补充 |

**读数建议**：向用户或模型展示时，优先用 **`answer`**；若 `answer` 空再辅以 **`bizValue` / `otherOption`**。同一字段多条 `answerItems` 时，用 **`；` 或换行** 拼接为多行可读文本，避免只展示数组原样。

### 如何把「详情」连成一块直观可读（龙虾机器人 / 聊天）

按下面顺序渲染，可与控制台「看申请表」的阅读顺序接近：

1. **标题行**：使用待办 **`getMyTodo.applySubject`**（与当前 `processId` 同一条待办）；若无列表上下文（仅调了 `processDetail`），用详情顶层 **`processTypeShow` + `processId`** 作标题。
2. **元信息**（可选一行）：`nodeName`、`applyUserName`、`applyUserCompany`、`createTime`（来自待办项）。
3. **结构化摘要表**：若 **`applyDigest.extra`** 非空，用**两列表格**展示——左列键（中文标签）、右列值；键值顺序**按 JSON 出现顺序**读即可。
4. **动态表单**：若 **`applyDigest.formAnswer`** 非空且 `pages` 非空：
   - 每个 **`pageName`** 作为**二级标题**（如 `## 基本信息`）。
   - 每个 **`fieldName`** 作为**问题行**；其 **`formatFieldValue(field)`** 规则：
     - 递归处理 `subFields`：在展示缩进上增加一级（如 Markdown 子列表或 `└─`），表示子表/重复组。
     - 叶子字段：拼接 `answerItems` 为展示字符串（见上节）。
5. **仅有 extra、无 formAnswer** 的类型（如部分证书、积分、会员变更）：整块内容就是 **extra 表格**，不要留空白「表单区」。

**敏感信息**：部分字段在服务端已按字段属性做脱敏（与列表手机号类似）；展示时仍须遵守对接系统的隐私策略，勿写入公开日志。

**Markdown 示意**（结构与真实数据字段对应，便于复制到对话里）：

```markdown
## 【待办】入会申请 — 张三 / 某某公司
当前节点：秘书处审核

### 摘要
| 项 | 内容 |
|----|------|
| 支付审核状态 | 已通过 |

### 申请表 · 第一页名称
- **姓名**：张三
- **手机**：138****0000
- **附件材料**：登记表.pdf（以 answer 实际为准）

### 申请表 · 第二页名称
- **子表** 成员信息
  - **成员1 · 姓名**：李四
```

（上表仅为排版示例；真实 `fieldName`、分页以接口返回为准。）

---

## 按 `processType`：`applyDigest` 里常见有什么

以下为**常见形态**，随产品迭代可能变化，**以实际返回 JSON 为准**。列表里的一句话摘要始终在 **`getMyTodo.applySubject`**；下表只帮助理解详情里的 **`formAnswer`** 与 **`extra`**。

| `processType` | `processTypeShow` | `formAnswer` | `extra` 常见键（中文键名） |
|----------------|-------------------|--------------|---------------------------|
| **0** | 入会申请 | 有入会表单时：多页字段树 | **`支付审核状态`**（存在缴费审核信息时出现） |
| **1** | 项目申报 | 有申报表单页时：自 `formPages` 转换 | **`申报标题`**、**`项目名称`** |
| **2** | oa流程 | 有答案 map 时：单页合成（页名为表单标题或「OA表单」） | **`表单标题`** |
| **3** | 文章审核 | **null** | **`标题`**、**`内容`**（当前为 `contentUrl`，即正文/资源地址类字段） |
| **4** | 证书审核 | **null** | 许可字段答题展开：**`变更前·` + 字段名**（编辑类且有旧值时）、**`变更后·` + 字段名** |
| **5** | 专家申请 | 专家申请表：多页字段树 | **无固定键**（仅表单树） |
| **6** | 专家信息修改 | **null** | **`修改字段`**、**`原答案`**、**`新答案`** |
| **8** | 任职申请 | 同 **0**（`UserApplyProcess` / `OfferApplyProcess`） | 同 **0** |
| **9** | 积分申请 | **null** | **`申请积分`**、**`事项说明`**、**`事件发生时间`**、**`证明材料`** |
| **10** | 会员变更申请 | **null** | **`变更类型`**（「变更负责人」/「变更分支机构」）、**`变更前-{k}`** / **`变更后-{k}`**（`k` 来自配置项键）、**`附件`** |

---

## 列表 vs 详情：摘要字段怎么对齐

- **主标题**：只用 **`getMyTodo.applySubject`**；详情里 **`formAnswer` / `extra`** 作正文。
- **审批轨迹**：开放接口 `processDetail` 与公共 **`ProcessDetail`** 均不携带；需在控制台或其它内部接口查看。

---

## 审批 `audit`

| 参数 | 说明 |
|------|------|
| `processId` | 流程实例 ID |
| `remark` | 说明；驳回建议写原因 |
| `auditStatus` | 常见 **`1`** 通过，**`-1`** 驳回 |

本接口为**简化入参**；**不接**控制台那种「整份审批页字段 / 手签 / 评分」载荷。当前节点若强依赖这些能力，自动或开放接口可能报业务错，需改走控制台。

---

## 自动审批（须自备规则 / Runbook）

开放平台**不内置**「机器人代审」策略。若要让自动化在拿到 `appKey` 后代替人工调 **`audit`**，应由**使用方**单独写清**允许自动通过/驳回的规则**（例如团队自己的 Playbook / 内部文档），避免未命中规则仍批量批单。

### 与人协作时的说法示例

例如：

- 「只自动处理 `processType` 为 9 的积分待办，材料齐全则通过。」
- 「拉 `getMyTodo`，标题含某关键词的单子统一驳回并写明 `remark`。」

Agent 或脚本应 **先加载用户提供的规则文档**，再执行 API；若无规则，应 **确认人工策略**，而不是默认全自动通过。

### 规则文档里建议写清的内容

1. **适用范围**：允许的 `processType`、标题/关键字白名单或黑名单、单日最多处理条数。
2. **前置条件**：是否必须先 `processDetail`；是否要求 `formAnswer` / `extra` 中某项非空才允许通过。
3. **默认动作**：未命中规则时 **不调** `audit`，只列举待办交给人工。
4. **备注格式**：`remark` 是否加固定前缀（便于事后筛查）。
5. **风险类型**：涉及资金、敏感资质等是否在规则里写明 **禁止自动通过**；`appKey` 视同审批权限，勿泄露。

### 推荐调用顺序（可写进自家 Runbook）

`getMyTodo` → 按规则筛选 `id` → 对每条 `processDetail` → 按 `applyDigest`（本节「直观可读」）做判断 → 满足条件再 `POST .../audit`。

表单字段语义若需对齐协会定义，可交叉阅读同目录 [`reference-form.md`](reference-form.md)（`paramType`、字段类型等）。

---

## 请求示例

```http
GET {BASE}/open/ai/process/getMyTodo?appKey=...
GET {BASE}/open/ai/process/processDetail?appKey=...&processId=123456789
POST {BASE}/open/ai/process/audit?appKey=...&processId=123456789&remark=同意&auditStatus=1
```

详情响应形态示意：

```json
{
  "errno": 0,
  "errmsg": "成功",
  "data": {
    "processId": 0,
    "processType": 0,
    "processTypeShow": "入会申请",
    "applyDigest": {
      "formAnswer": null,
      "extra": { "支付审核状态": "1" }
    }
  }
}
```

**推荐顺序**：`getMyTodo` → `processDetail` → `audit`。

---

**响应体通用约定**见 [`SKILL.md`](SKILL.md)。
