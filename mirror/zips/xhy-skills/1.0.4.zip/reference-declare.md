# 指南：项目申报表单绑定（`open/ai/declare/`）

完整路径形如：`{BASE}/open/ai/declare/...`（`{BASE}` 见总览）。

用于把**已通过表单接口建好的表**挂到**已有项目申报活动**上：

- **主申报表单**：申报人填报时使用的项目表单（对应后台项目申报里的主 `formId`）。
- **专家评审表单**：流程中**指定名称**的**专家评审类节点**所使用的评分/评审表（`expertComment` / `expertSign` / `expertAudit`）。

## `formId` 来源（强制）

绑定用的 **`formId`** 必须来自**服务端**本次流水线中的表单接口结果，只能是：

1. **`addForm` 成功**：响应 **`data`** 中的编号；或  
2. **`addForm` 失败（同协会下 `formName` 已存在）**：从 **`errmsg`** 中解析出的已有 **`formId`**（与 **reference-form**「表单名称重复」一致）。

**不得**把终端用户口述、聊天里手填、从别处抄来的数字当作 `formId` 传入。  
**不得**在名称重复时**修改 `formName` 再调 `addForm`** 当作解决办法——应使用 **`errmsg` 中的已有 `formId`** 继续绑定或在该表上用 **`updateField`** 等修改结构。  
**不得**在未拿到上述任一来源的 `formId` 时调用绑定。

> **不要与问卷混淆**：问卷侧的 **`open/ai/questionnaire/bindingForm`** 绑定的是**问卷 `id` + 表单**；本页的绑定针对**项目申报**，参数是 **`decTitle`（申报标题）**，见 [`reference-questionnaire.md`](reference-questionnaire.md)。问卷绑定里的 **`formId` 同样遵守上一段规则**。

## 接口速查

| 方法 | 路径片段 | 用途 |
|------|----------|------|
| `POST` | `bindingForm` | 绑定项目申报的**主填报表单** |
| `POST` | `bindingExpertCommonForm` | 绑定**指定评审节点**上的专家评审表单 |

**Query**：均需 **`appKey`**；两个接口均为 **`POST`，参数全部在 Query，无 JSON body**。

| 参数 | `bindingForm` | `bindingExpertCommonForm` |
|------|-----------------|---------------------------|
| `appKey` | 是 | 是 |
| `decTitle` | 是，申报活动标题（与后台一致） | 同左 |
| `formId` | 是，**仅限** `open/ai/form/addForm`（等表单接口）**成功响应的 `data`** | 同左 |
| `nodeName` | — | **是**，流程里专家评审节点的**名称**，须与流程配置完全一致 |

## 响应里常用到什么

- 成功时 **`data` 常为空或非关键**，以 **`errno === 0`** 为准。
- 失败时读 **`errmsg`**（如未找到该标题的申报、未配置流程模板、节点名称不匹配等）。

## 推荐流程（主表单）

1. 按 [`reference-form.md`](reference-form.md) 准备 **`addForm` JSON**，**用户确认结构后再调用 `addForm`**，记下 **`formId`**（成功 **`data`** 或重名 **`errmsg`**）。
2. 确保目标**项目申报**已在协会后台存在，且 **`decTitle`** 与其**标题**一致（服务端会对标题做 **`trim`**，**中间空格仍须一致**）。
3. 调 **`bindingForm`**：`appKey`、`decTitle`、`formId`。

## 推荐流程（专家评审节点表单）

1. 同上得到 **`formId`**（**`addForm` 前须完成用户确认**，见 **reference-form**）。
2. 在后台流程配置中确认专家评审类节点的**显示名称**（例如「专家评审」），作为 **`nodeName`**（**完全一致**；服务端会对 `nodeName` **`trim`**）。
3. 调 **`bindingExpertCommonForm`**：`appKey`、`decTitle`、`nodeName`、`formId`。

## 调用注意

- **`decTitle` / `nodeName`** 与系统配置不一致会直接失败，无法在开放接口里「模糊匹配」。
- **`formId`**：须为**本流水线中表单接口返回的值**，且与当前 **`appKey` 所属 `shId`** 下创建的表单一致；**不接受用户输入代填**。
- **`appKey` 错误**与其它开放接口表现一致；**不要把完整密钥复述进聊天记录**。

**通用响应约定**见总览 [`SKILL.md`](SKILL.md)。
