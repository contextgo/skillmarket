# 指南：问卷与信息收集（`open/ai/questionnaire/`）

完整路径形如：`{BASE}/open/ai/questionnaire/...`（`{BASE}` 见总览）。

用于**新建**「问卷调查」或「信息收集」活动；也可把**已通过表单接口建好的表**挂到某个问卷上，作为填报内容结构。

**`bindingForm` 的 `formId`**：**必须**是 **`open/ai/form/addForm`（等）成功响应的 `data`**，**禁止**使用用户口述/手填的编号。细节见 [`reference-declare.md`](reference-declare.md) 中「`formId` 来源（强制）」（问卷与申报绑定同一原则）。

**龙虾机器人**：创建类接口为 **`POST` + JSON body**；若走「表单 + 绑定」，务必**留好 `formId` 与问卷 `id`**，最后一步 **`bindingForm` 只有 Query、无 body**（见下文）。

## 接口速查

| 方法 | 路径片段 | 用途 |
|------|----------|------|
| `POST` | `addQuestionnaire` | 新建**问卷调查** |
| `POST` | `addInfoCollect` | 新建**信息收集** |
| `POST` | `bindingForm` | 把指定**问卷**与**表单**关联（**`formId` 仅为** `addForm` 等**接口返回的 `data`**，见上文） |

**Query**：以上均需 **`appKey`**。  
**`bindingForm`** 另需 **`id`**（创建问卷接口返回的问卷编号）、**`formId`**（表单编号）。**`bindingForm` 为 `POST`，参数全部在 Query，无 JSON body**（与带 body's 的创建接口不同）。

> **项目申报**另有路径 **`open/ai/declare/bindingForm`**（参数为 **`decTitle`**，不是问卷 **`id`**），见 [`reference-declare.md`](reference-declare.md)。

## 响应里常用到什么

- **`addQuestionnaire` / `addInfoCollect`** 成功时，**`data`** 一般为新建的**问卷 `id`**（整数），后续 **`bindingForm` 的 `id` 用它**。
- **`bindingForm`** 成功时，**`data` 常为空**，只要 **`errno === 0`** 即可。

新建问卷时，平台通常会顺带准备一个**可再替换的**默认表单；若你走了 **`bindingForm`**，填报将**以绑定的 `formId` 为准**。

## 创建问卷时的请求体（JSON）

两则创建接口**共用**下列字段；差异仅在于接口路径（问卷 vs 信息收集），平台会按接口区分活动类型。

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `title` | string | **是** | 标题；也会参与默认表单的命名 |
| `thumbImg` | string | 否 | 封面图 URL |
| `endTime` | 日期时间 | 否 | 截止时间（如 ISO-8601，以网关/服务端解析为准） |
| `partakeRole` | number | 否 | 谁可填：`0` 所有人，`1` 仅会员，`3` 登录用户 |
| `commitLimit` | number | 否 | 每人可提交次数；`-1` 常表示不限制 |
| `introduction` | string | 否 | 开篇说明（如小程序展示） |
| `conclusion` | string | 否 | 结束语 |
| `announcement` | string | 否 | 提交后提示，可为富文本 |
| `hideUserInfo` | boolean | 否 | 是否匿名填报 |


## 推荐流程：表单 API + 绑定

适合「题目用表单 JSON 一次性建好」的场景（该 JSON 常见于 **Excel / Word / PDF 解析**或**合规前提下**自**网络资源**提取后再映射，见 **reference-form** 的「表单 JSON 的常见来源」）：

1. 按 [`reference-form.md`](reference-form.md) 组装 **`addForm` JSON**，**向用户渲染结构并确认无误后**再调 **`open/ai/form/addForm`**，从响应 **`data`**（或重名时的 **`errmsg`**）得到 **`formId`**。
2. 调 **`addQuestionnaire`** 或 **`addInfoCollect`**，从 **`data`** 得到问卷 **`id`**。
3. 调 **`bindingForm`**：`appKey`、`id`（问卷）、`formId`（步骤 1）。会覆盖步骤 2 产生时的默认表单关联。（若步骤 1 因**表单重名**失败，**勿**换 `formName` 重试；应从 **`errmsg` 取已有 `formId`**，见 **reference-form**。）


## 只做「最小创建」

也可以**只调用**步骤 2，用平台生成的默认表单，再在管理端或其它入口维护题目——不强制使用 **`bindingForm`**。

## 调用注意

- **`bindingForm` 的 `formId`**：须为先前 **`addForm`** 等**成功返回**；**不可**代为采纳用户提供的任意数字。
- **`title` 为空**一般会校验失败。
- **`appKey` 错误**与其它开放接口表现一致。
- 富文本、长文注意请求体大小与日志脱敏。

**通用响应约定**见总览 [`SKILL.md`](SKILL.md)。
