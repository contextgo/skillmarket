# 指南：新闻（`open/ai/article/`）

路径：`{BASE}/open/ai/article/...`。用于拉**栏目树**、**按源站 ID 判断是否已存在**、**推送新闻**、**编辑已推送的新闻**（修正上一步 `pushArticle` 的正文或元数据）。

**龙虾机器人**：推送前**必须先 `categories`**，从返回树里选 **`id` 写入 `categoryIds`**，不可凭空编造栏目编号。

**正文完整性**：`pushArticle` 的 **`content` 必须全文原样推送**，与来源稿件一致；**禁止**因模型上下文、话术长度或「摘要」习惯对正文做**截断、删节或只传片段**。若原文过长导致单次请求困难，应在技术侧分段组包或加大超时，**不得**用不完整内容代替**完整** `content` 调用接口。

## 接口列表

| 方法 | 路径 | Query / Body |
|------|------|----------------|
| `GET` | `.../categories` | `appKey` |
| `GET` | `.../getArticleByOldHtmlId` | `appKey`，`oldHtmlId` |
| `POST` | `.../pushArticle` | `appKey` + JSON body |
| `POST` | `.../updateArticle` | `appKey` + JSON body |

## 栏目树 `data`

根栏目组成的数组，可带多级子节点。每项：

| 字段 | 类型 | 说明 |
|------|------|------|
| `id` | number | **`categoryIds`** 用此 ID |
| `categoryName` | string | 栏目名 |
| `list` | array \| null | 子节点，结构递归 |

## `getArticleByOldHtmlId` 的 `data`

布尔值：**`true`** = 该 `oldHtmlId` 已存在（已推送 / 已抓取）；**`false`** = 可继续推送。

## `pushArticle`

- Header：`Content-Type: application/json`
- 成功：**`errno === 0`**，**`data` 为新建文章的整数 `id`**（后续 **`updateArticle`** 要用此 **`id`**）
- **`content` 非空**时一般由服务端落存储并生成 **`contentUrl`**；调用方通常不传 `contentUrl`
- 组织与 **`appKey`** 绑定即可；**勿依赖**在 body 里自行传组织类字段来「切换主体」

### Body 字段

| 字段 | 必填 | 说明 |
|------|------|------|
| `title` | 是 | 标题 |
| `content` | 是 | 正文（HTML 等）；**须完整，不得截取**（见文首「正文完整性」） |
| `categoryIds` | 是 | 至少一个栏目 ID |
| `thumbImg` | 否 | 缩略图 URL |
| `publishTime` | 否 | **`yyyy-MM-dd HH:mm:ss`**，如 `2026-04-01 10:00:00` |
| `oldHtmlId` | 否 | 源站 ID，去重 |
| `openOuterLink` | 否 | 默认 `false` |
| `remoteUrl` | 否 | 原文链接 |
| `contentUrl` | 否 | 一般勿传 |

典型校验提示：`文章标题不能为空！`、`文章内容不能为空！`、`文章栏目不能为空！`

**内容质量（约定）**：除上述校验外，业务上要求推送的正文与所选素材**一一对应、无遗漏段落**；机器人侧不得自行省略中间章节或仅传开篇。

**推荐顺序**：`categories` →（可选）`getArticleByOldHtmlId` → `pushArticle`。

## `updateArticle`（编辑已推送文章）

用于**在用户要求改稿**时，基于**同一次自动化里**上一步 **`pushArticle` 返回的 `data`（文章 `id`）** 更新正文或栏目等。与 **`pushArticle` 一样**：正文内图片会走 COS 替换；**`content` 会重新上传并生成 `contentUrl`**（调用方勿依赖自填 `contentUrl`）。

- Header：`Content-Type: application/json`
- Query：**`appKey`**（必填）
- 开放层校验：**`id`、`content` 均不能为空**（`content` 不得空白字符串）。
- **权限**（info 服务）：文章须已存在，且 **`commitUser` 须与创建该文时一致**。创建时的提交人来自 **`appKey` 对应管理员**，因此**只有用同一个 `appKey`（同一集成 identity）推送的文**才能用该接口修改；否则会报业务错误（如「非文章创建人，无法修改！」）。
- 成功：**`errno === 0`**，**`data` 为文章 `id`**（通常与请求的 **`id`** 相同）。

### Body 字段

| 字段 | 必填 | 说明 |
|------|------|------|
| `id` | **是** | **`pushArticle` 成功响应里 `data` 的文章编号** |
| `content` | **是** | 正文；**须完整，规则同「正文完整性」**，禁止截取 |
| `title` | 建议 | 若改标题则传入新标题 |
| `categoryIds` | 建议 | 若改栏目则传入（仍须为有效栏目 ID，可先 `categories`） |
| `thumbImg` | 否 | 缩略图 URL |
| `publishTime` | 否 | **`yyyy-MM-dd HH:mm:ss`** |
| `oldHtmlId` / `openOuterLink` / `remoteUrl` | 否 | 与 `pushArticle` 含义一致，按需要携带 |

**勿传**：`shId`、`commitUser`（由服务端按 **`appKey`** 解析后写入/校验）。

典型错误提示：`id/内容不能为空！`、文章不存在、非创建人无法修改（以实际 **`errmsg`** 为准）。

**推荐顺序**：`pushArticle` 记下 **`data` → `id`** → 用户确认需修改 → **`updateArticle`**（同一 **`appKey`**）。

## 请求示例

```http
GET {BASE}/open/ai/article/getArticleByOldHtmlId?appKey=...&oldHtmlId=site-123
```

```http
POST {BASE}/open/ai/article/pushArticle?appKey=...
Content-Type: application/json
```

```json
{
  "title": "协会动态标题",
  "content": "<p>正文 HTML</p>",
  "categoryIds": [101, 102],
  "oldHtmlId": "site-123",
  "publishTime": "2026-04-01 10:00:00",
  "thumbImg": "https://example.com/cover.jpg",
  "openOuterLink": false
}
```

**推送成功**示例（`data` 为新建文章 id）：

```json
{
  "errno": 0,
  "errmsg": "成功",
  "data": 12345
}
```

**编辑成功**示例：

```http
POST {BASE}/open/ai/article/updateArticle?appKey=...
Content-Type: application/json
```

```json
{
  "id": 12345,
  "title": "调整后的标题",
  "content": "<p>全文 HTML（与同 push 规则，禁止截断）</p>",
  "categoryIds": [101, 102]
}
```

```json
{
  "errno": 0,
  "errmsg": "成功",
  "data": 12345
}
```

---

**响应体通用约定**见 [`SKILL.md`](SKILL.md)。
