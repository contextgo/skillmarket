---
name: openclaw-ai-xhy-open-api
description: >-
  Guide for 协会易 open HTTP APIs used by 龙虾机器人 and similar agents: form,
  questionnaire, article, process, project declare (binding forms). Read
  matching reference-*.md in this folder before calling; stresses errno, appKey
  safety, multi-step id handoff, and binding formId only from form API responses
  (never end-user-supplied ids). Confirm parsed form structure with the user
  (human-readable render) before calling addForm. Article pushArticle content
  must be full body, never truncated for convenience. Use updateArticle with the
  article id returned by pushArticle to edit that article (same appKey/commit
  user constraints as the backend).
---

# 协会易开放接口 — 集成指南（总览）

面向**龙虾机器人**等对话式自动化：如何用同一套 HTTP 约定拉栏目、建表单、建问卷、推新闻、读待办与简易审批、为**项目申报**绑定表单。具体路径、请求体、字段含义在**同目录** `reference-*.md` 中按任务打开。

## 能力一览

| 主题 | URL 前缀（接在 `{BASE}` 后） | 典型用途      | 展开文档 |
|------|------------------------------|-----------|----------|
| 表单 | `open/ai/form/` | 创建表单      | [`reference-form.md`](reference-form.md) |
| 问卷 / 信息收集 | `open/ai/questionnaire/` | 新建问卷、绑定表单 | [`reference-questionnaire.md`](reference-questionnaire.md) |
| 项目申报 | `open/ai/declare/` | 绑定申报主表、绑定评审节点表单 | [`reference-declare.md`](reference-declare.md) |
| 新闻 | `open/ai/article/` | 栏目、去重、推送、**编辑已推送文**  | [`reference-article.md`](reference-article.md) |
| 流程待办 | `open/ai/process/` | 待办、摘要、审批  | [`reference-process.md`](reference-process.md) |

## 通用约定

- **`{BASE}`**：部署根地址，**`https://www.shanghuiyi.com`**。
- **鉴权**：接口通常把 **`appKey`** 放在 **Query**（`?appKey=...`）；密钥无效时请求失败，**不要把完整密钥复述进聊天记录**。
- **成功与否**：**只看 `errno === 0`**；否则视为失败，**用 `errmsg` 向用户说明**，不得假定已创建成功。
- **POST JSON**：`Content-Type: application/json`，body 为 UTF-8 JSON；**GET** 一般无 body。
- **拼 URL**：`{BASE}` 与路径段之间一条斜杠即可，例如 `{BASE}/open/ai/form/addForm?appKey=...`，避免重复 `//`。
- **绑定用 `formId`**：凡 **问卷 `bindingForm`、项目申报 `bindingForm` / `bindingExpertCommonForm`** 等需要 **`formId`** 的调用，**只能**使用① **`addForm` 成功**时响应的 **`data`**，或② **`addForm` 因同名表单已存在而失败**时，**`errmsg` 中给出的已有 `formId`**（均由服务端返回）。**禁止**用户口述、手填或外部猜测的编号；**禁止**在「名称重复」时**改 `formName` 再 `addForm`** 规避（见 **reference-form**「表单名称重复」）。无可用 `formId` 则不调绑定。
- **`addForm` 前必须与人确认结构**：解析/拼装出待提交的表单 JSON 后，须**按 JSON 做可读渲染**（分级列表、按 Tab 的表格等），**经用户确认无误后再调 `addForm`**；未对齐结构不得调用（见 **reference-form**「创建前与用户确认」）。

## 龙虾机器人执行要点

1. **多步要把上一步的返回值记下来**：例如 **`addForm` → `data` 为 `formId`**；**创建问卷 → `data` 为问卷 `id`**；**问卷侧 `open/ai/questionnaire/bindingForm`** 需要问卷 **`id` + `formId`**（见 **reference-questionnaire**）。**项目申报侧**另有 **`open/ai/declare/bindingForm`**，参数是 **`decTitle` + `formId`**，不要把问卷的 `bindingForm` 与申报的混用（见 **reference-declare**）。中途丢了 id 只能让用户重试或去后台查。
2. **按文档常用类型造表单**：**`paramType`** 须为协会易认可的类型代码（**reference-form** 已汇总），**优先**仅用「常用类型」；禁止自造 **`code`**；**不再**提供 `GET supportFieldType`。**表结构须先与用户确认并渲染预览后再 `addForm`**。**`addForm` 若报表单名称已存在**：从 **`errmsg` 取已有 `formId` 继续绑定**；**不要**改 `formName` 再建一张新表。
3. **推新闻前先拉栏目**：用 **`categories`** 里的 **`id`** 填 **`categoryIds`**，不要猜数字（见 **reference-article**）。**`pushArticle` 的 `content` 须完整正文**，禁止为省 token 或图方便截取、只发摘要（见 **reference-article**「正文完整性」）。**修正已推送稿件**时调 **`updateArticle`**：body 里带 **`pushArticle` 成功响应 `data` 中的文章 `id`** + 完整 **`content`**（及需改的标题、栏目等），**须同一 `appKey` 对应账号创建该文**（见 **reference-article**「`updateArticle`」）。
4. **待办话术**：列表短标题只用 **`applySubject`**；展开详情再拼 **`formAnswer` / `extra`**（见 **reference-process**）。**不要默认替用户点审批**；用户明确说「通过/驳回」且业务允许时，再调 **`audit`**。
5. **项目申报绑定**：**`decTitle`、`nodeName`** 须与后台配置**一致**（见 **reference-declare**）；评审节点绑定需要流程里已有对应名称的专家评审类节点。**`formId` 规则见上文「绑定用 formId」**，不接受用户当字段输入。
6. **网络与合规**：抓网页、下附件、解析 PDF 等须满足许可与用户授权；说不清时先问用户，不要硬抓。

## 使用这些文档的方式

1. 按用户意图对上表**打开对应 reference 全文**，再组请求与解析 JSON。
2. **问卷 + 自建表**：顺序见 **reference-questionnaire**「推荐流程」（可先表单后问卷再绑定，顺序不要颠倒）。
3. **项目申报 + 自建表**：主表或专家评审表绑定见 **reference-declare**；**`formId` 仍来自表单 API**。
4. **表单**：材料来自 Excel / Word / PDF / 合规网络提取时，按 **reference-form**「常见来源」「是否打分表」定 **`useTo`**，**`paramType` 优先常用类型、须合法**；**解析完成后先渲染给用户确认再 `addForm`**。
5. **流程**：按 **reference-process** 的类型表理解摘要；回复用户时按该文档「连成可读」的顺序组织话术。

## 集成时注意

- **表单**：注意材料体积与超时；**`paramType`** **优先** **reference-form**「常用类型」，且须为该文档/对接方确认的合法 **`code`**；**未与用户确认结构不调 `addForm`**；解析后**宜做可读渲染**再请用户拍板（见 **reference-form**）；**名称重复**时勿换名重试 **`addForm`**，按 **reference-form** 使用 **`errmsg` 中的 `formId`**。
- **问卷**：**`title` 必填**；**`open/ai/questionnaire/bindingForm`** 仅传 Query（`appKey`、问卷 **`id`**、`formId`），无 JSON body；其中 **`formId` 须来自表单 API 返回值**，见上文「绑定用 formId」。
- **项目申报**：**`open/ai/declare/bindingForm`** / **`bindingExpertCommonForm`** 仅传 Query，无 JSON body；与问卷 **`bindingForm` 路径与参数均不同**；**`formId` 同上，不可由用户直输**，见 **reference-declare**。
- **新闻**：`publishTime` 格式见 **reference-article**；**`content` 必须完整、不可截取**；体量大时预留超时或采用合规的分段/技术方案，不得用不完整正文代替。**改稿**用 **`updateArticle`**，**`id`** 取自 **`pushArticle` 的 `data`**，详见 **reference-article**。
- **流程**：摘要可能含隐私；开放接口**不含**完整审批轨迹；**审批不可逆**，操作前先向用户确认。
