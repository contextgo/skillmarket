---
name: byteplan-api
description: BytePlan 数据平台 API 封装。提供登录认证、模型查询、数据获取等接口。可被 byteplan-analysis、byteplan-excel、byteplan-html、byteplan-ppt、byteplan-video、byteplan-word 等技能依赖使用。
---

# BytePlan API Skill

## 概述

提供 BytePlan 数据平台的 JavaScript API 封装，支持：
- 登录认证（UAT 环境）
- 用户与租户管理
- 模型查询与数据获取
- 字段类型值获取（DIM/LIST/LOV/LEVEL）

## CLI 模式

本 skill 支持两种调用模式：

1. **CLI 模式（默认）**：优先使用 `byteplan-cli` 命令行工具
2. **直接 API 模式**：当 CLI 未安装或执行失败时，自动回退到直接 API 调用

### CLI 自动安装

使用 API 前，系统会自动检测用户是否安装了 `byteplan-cli`：
- 如果未安装，会自动执行 `npm i -g byteplan-cli` 进行安装
- 安装成功后，后续操作优先使用 CLI 模式

### CLI 命令帮助

如果不知道 CLI 命令的参数和用法，可以使用 `-h` 或 `--help` 查看帮助信息：

```bash
byteplan --help
byteplan login --help
byteplan model --help
byteplan data --help
```

## 依赖此 Skill 的其他 Skill

- [byteplan-analysis](../byteplan-analysis/SKILL.md) - 从 BytePlan 平台查询数据并生成分析报告
- [byteplan-excel](../byteplan-excel/SKILL.md) - 数据分析 Excel 报告生成
- [byteplan-html](../byteplan-html/SKILL.md) - 数据分析网页报告生成
- [byteplan-ppt](../byteplan-ppt/SKILL.md) - 数据分析 PPT 报告生成
- [byteplan-video](../byteplan-video/SKILL.md) - 数据可视化视频生成
- [byteplan-word](../byteplan-word/SKILL.md) - 数据分析 Word 文档报告生成

## 环境配置

**凭证存储路径**：`~/.byteplan/.env`

登录成功后自动创建 `.env` 文件：

```env
BP_ENV=uat
BP_USER=你的手机号
BP_PASSWORD="你的密码"
ACCESS_TOKEN=              # 自动管理
REFRESH_TOKEN=             # 自动管理
TOKEN_EXPIRES_IN=          # 自动管理
```

**注意**：
- 密码包含特殊字符时用引号包裹
- Token 由系统自动管理，无需手动修改

### 首次使用流程

如果没有 `.env` 文件或 token 无效，**必须询问用户输入**：
1. 询问用户名（手机号）
2. 询问密码
3. 使用凭证登录
4. 登录成功后显示当前租户信息

## API 详细文档

需要深入了解 api.js 的函数接口时，请阅读 [API_REFERENCE.md](./API_REFERENCE.md)。

## 快速开始

```javascript
import { loginWithEnv, getUserInfo, queryModels } from './scripts/api.js';

// 自动登录（使用缓存的 token 或重新登录）
const result = await loginWithEnv();
const token = result.access_token;

// 获取用户信息
const userInfo = await getUserInfo(token);
console.log(`当前租户: ${userInfo.user?.tenantName}`);

// 查询模型列表
const models = await queryModels(token);
console.log(`可用模型: ${models.length} 个`);
```