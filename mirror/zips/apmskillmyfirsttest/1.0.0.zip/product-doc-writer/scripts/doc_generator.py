{\rtf1\ansi\ansicpg936\cocoartf2821
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fnil\fcharset0 Menlo-Regular;}
{\colortbl;\red255\green255\blue255;\red144\green1\blue18;\red255\green255\blue255;\red45\green45\blue45;
\red135\green44\blue160;\red19\green118\blue70;}
{\*\expandedcolortbl;;\cssrgb\c63922\c8235\c8235;\cssrgb\c100000\c100000\c100000;\cssrgb\c23137\c23137\c23137;
\cssrgb\c60784\c27451\c69020;\cssrgb\c3529\c52549\c34510;}
\paperw11900\paperh16840\margl1440\margr1440\vieww12100\viewh23600\viewkind0
\deftab720
\pard\pardeftab720\partightenfactor0

\f0\fs26 \cf2 \cb3 \expnd0\expndtw0\kerning0
\outl0\strokewidth0 \strokec2 #!/usr/bin/env python3\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2 """\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2 \uc0\u20135 \u21697 \u38656 \u27714 \u25991 \u26723 \u29983 \u25104 \u22120 \cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2 \uc0\u26681 \u25454 \u29992 \u25143 \u36755 \u20837 \u30340 \u38656 \u27714 \u25551 \u36848 \u65292 \u29983 \u25104 \u32467 \u26500 \u21270 \u30340 PRD\u25991 \u26723 \cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2 """\cf4 \cb1 \strokec4 \
\
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 import \cf5 \strokec5 json\cf4 \cb1 \strokec4 \
\cb3 from \cf5 \strokec5 datetime\cf4 \strokec4  import \cf5 \strokec5 datetime\cf4 \cb1 \strokec4 \
\cb3 from \cf5 \strokec5 typing\cf4 \strokec4  import \cf5 \strokec5 Dict\cf4 \strokec4 , \cf5 \strokec5 List\cf4 \strokec4 , \cf5 \strokec5 Optional\cf4 \cb1 \strokec4 \
\
\
\cb3 def \cf5 \strokec5 generate_doc_id\cf4 \strokec4 () -> str:\cb1 \
\cb3     \cf2 \strokec2 """\uc0\u29983 \u25104 \u25991 \u26723 \u32534 \u21495 """\cf4 \cb1 \strokec4 \
\cb3     \cf5 \strokec5 date_str\cf4 \strokec4  = \cf5 \strokec5 datetime\cf4 \strokec4 .\cf5 \strokec5 now\cf4 \strokec4 ().\cf5 \strokec5 strftime\cf4 \strokec4 (\cf2 \strokec2 "%Y%m%d"\cf4 \strokec4 )\cb1 \
\cb3     return \cf2 \strokec2 f"PRD-\cf5 \strokec5 \{date_str\}\cf2 \strokec2 -001"\cf4 \cb1 \strokec4 \
\
\
\cb3 def \cf5 \strokec5 create_prd_structure\cf4 \strokec4 (\cb1 \
\cb3     \cf5 \strokec5 title\cf4 \strokec4 : str,\cb1 \
\cb3     \cf5 \strokec5 background\cf4 \strokec4 : \cf5 \strokec5 Dict\cf4 \strokec4 ,\cb1 \
\cb3     \cf5 \strokec5 data_architecture\cf4 \strokec4 : \cf5 \strokec5 Dict\cf4 \strokec4 ,\cb1 \
\cb3     \cf5 \strokec5 objectives\cf4 \strokec4 : \cf5 \strokec5 Dict\cf4 \strokec4 ,\cb1 \
\cb3     \cf5 \strokec5 user_scenarios\cf4 \strokec4 : \cf5 \strokec5 Dict\cf4 \strokec4 ,\cb1 \
\cb3     \cf5 \strokec5 features\cf4 \strokec4 : \cf5 \strokec5 List\cf4 \strokec4 [\cf5 \strokec5 Dict\cf4 \strokec4 ],\cb1 \
\cb3     \cf5 \strokec5 detailed_design\cf4 \strokec4 : \cf5 \strokec5 Dict\cf4 \strokec4 ,\cb1 \
\cb3     \cf5 \strokec5 flow_diagram\cf4 \strokec4 : str,\cb1 \
\cb3     \cf5 \strokec5 prototype\cf4 \strokec4 : \cf5 \strokec5 Dict\cf4 \strokec4 ,\cb1 \
\cb3     \cf5 \strokec5 api_design\cf4 \strokec4 : \cf5 \strokec5 List\cf4 \strokec4 [\cf5 \strokec5 Dict\cf4 \strokec4 ],\cb1 \
\cb3     \cf5 \strokec5 exceptions\cf4 \strokec4 : \cf5 \strokec5 List\cf4 \strokec4 [\cf5 \strokec5 Dict\cf4 \strokec4 ],\cb1 \
\cb3     \cf5 \strokec5 tracking\cf4 \strokec4 : \cf5 \strokec5 List\cf4 \strokec4 [\cf5 \strokec5 Dict\cf4 \strokec4 ],\cb1 \
\cb3 ) -> str:\cb1 \
\cb3     \cf2 \strokec2 """\cf4 \cb1 \strokec4 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2     \uc0\u29983 \u25104 \u23436 \u25972 \u30340 PRD\u25991 \u26723 \cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     \cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     Args:\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2         title: \uc0\u25991 \u26723 \u26631 \u39064 \cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2         background: \uc0\u38656 \u27714 \u32972 \u26223 \u20449 \u24687 \cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2         data_architecture: \uc0\u25968 \u25454 \u26550 \u26500 \u35828 \u26126 \cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2         objectives: \uc0\u38656 \u27714 \u30446 \u26631 \cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2         user_scenarios: \uc0\u29992 \u25143 \u19982 \u20351 \u29992 \u22330 \u26223 \cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2         features: \uc0\u38656 \u27714 \u21151 \u33021 \u28165 \u21333 \cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2         detailed_design: \uc0\u35814 \u32454 \u26041 \u26696 \cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2         flow_diagram: \uc0\u19994 \u21153 \u27969 \u31243 \u22270 \u25551 \u36848 \cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2         prototype: \uc0\u21407 \u22411 \u22270 \u25551 \u36848 \cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2         api_design: \uc0\u25509 \u21475 \u35774 \u35745 \cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2         exceptions: \uc0\u24322 \u24120 \u19982 \u36793 \u30028 \u22788 \u29702 \cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2         tracking: \uc0\u25968 \u25454 \u22475 \u28857 \cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     \cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     Returns:\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2         \uc0\u26684 \u24335 \u21270 \u30340 Markdown\u25991 \u26723 \cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     """\cf4 \cb1 \strokec4 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3     \cf5 \strokec5 doc_id\cf4 \strokec4  = \cf5 \strokec5 generate_doc_id\cf4 \strokec4 ()\cb1 \
\cb3     \cf5 \strokec5 date_str\cf4 \strokec4  = \cf5 \strokec5 datetime\cf4 \strokec4 .\cf5 \strokec5 now\cf4 \strokec4 ().\cf5 \strokec5 strftime\cf4 \strokec4 (\cf2 \strokec2 "%Y-%m-%d"\cf4 \strokec4 )\cb1 \
\cb3     \cb1 \
\cb3     \cf5 \strokec5 document\cf4 \strokec4  = \cf2 \strokec2 f"""# \cf5 \strokec5 \{title\}\cf2 \strokec2 \uc0\u20135 \u21697 \u38656 \u27714 \u25991 \u26723 \cf4 \cb1 \strokec4 \
\
\cb3 **\uc0\u25991 \u26723 \u32534 \u21495 **\u65306 \{\cf5 \strokec5 doc_id\cf4 \strokec4 \}  \cb1 \
\cb3 **\uc0\u29256 \u26412 \u21495 **\u65306 \cf5 \strokec5 v1\cf6 \strokec6 .0\cf4 \strokec4   \cb1 \
\cb3 **\uc0\u21019 \u24314 \u26085 \u26399 **\u65306 \{\cf5 \strokec5 date_str\cf4 \strokec4 \}  \cb1 \
\cb3 **\uc0\u29366 \u24577 **\u65306 \u24453 \u35780 \u23457 \cb1 \
\
\cb3 ---\cb1 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 ## \uc0\u19968 \u12289 \u38656 \u27714 \u32972 \u26223 \cf4 \cb1 \strokec4 \
\
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \{\cf5 \strokec5 format_background\cf4 \strokec4 (\cf5 \strokec5 background\cf4 \strokec4 )\}\cb1 \
\
\cb3 ---\cb1 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 ## \uc0\u20108 \u12289 \u25968 \u25454 \u26550 \u26500 \u35828 \u26126 \cf4 \cb1 \strokec4 \
\
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \{\cf5 \strokec5 format_data_architecture\cf4 \strokec4 (\cf5 \strokec5 data_architecture\cf4 \strokec4 )\}\cb1 \
\
\cb3 ---\cb1 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 ## \uc0\u19977 \u12289 \u38656 \u27714 \u30446 \u26631 \cf4 \cb1 \strokec4 \
\
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \{\cf5 \strokec5 format_objectives\cf4 \strokec4 (\cf5 \strokec5 objectives\cf4 \strokec4 )\}\cb1 \
\
\cb3 ---\cb1 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 ## \uc0\u22235 \u12289 \u29992 \u25143 \u19982 \u20351 \u29992 \u22330 \u26223 \cf4 \cb1 \strokec4 \
\
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \{\cf5 \strokec5 format_user_scenarios\cf4 \strokec4 (\cf5 \strokec5 user_scenarios\cf4 \strokec4 )\}\cb1 \
\
\cb3 ---\cb1 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 ## \uc0\u20116 \u12289 \u38656 \u27714 \u21151 \u33021 \u28165 \u21333 \cf4 \cb1 \strokec4 \
\
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \{\cf5 \strokec5 format_features\cf4 \strokec4 (\cf5 \strokec5 features\cf4 \strokec4 )\}\cb1 \
\
\cb3 ---\cb1 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 ## \uc0\u20845 \u12289 \u35814 \u32454 \u26041 \u26696 \cf4 \cb1 \strokec4 \
\
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \{\cf5 \strokec5 format_detailed_design\cf4 \strokec4 (\cf5 \strokec5 detailed_design\cf4 \strokec4 )\}\cb1 \
\
\cb3 ---\cb1 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 ## \uc0\u19971 \u12289 \u19994 \u21153 \u27969 \u31243 \u22270 \cf4 \cb1 \strokec4 \
\
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \{\cf5 \strokec5 flow_diagram\cf4 \strokec4 \}\cb1 \
\
\cb3 ---\cb1 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 ## \uc0\u20843 \u12289 \u39640 \u20445 \u30495 \u21407 \u22411 \u22270 \cf4 \cb1 \strokec4 \
\
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \{\cf5 \strokec5 format_prototype\cf4 \strokec4 (\cf5 \strokec5 prototype\cf4 \strokec4 )\}\cb1 \
\
\cb3 ---\cb1 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 ## \uc0\u20061 \u12289 \u25509 \u21475 \u35774 \u35745 \cf4 \cb1 \strokec4 \
\
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \{\cf5 \strokec5 format_api_design\cf4 \strokec4 (\cf5 \strokec5 api_design\cf4 \strokec4 )\}\cb1 \
\
\cb3 ---\cb1 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 ## \uc0\u21313 \u12289 \u24322 \u24120 \u19982 \u36793 \u30028 \u22788 \u29702 \cf4 \cb1 \strokec4 \
\
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \{\cf5 \strokec5 format_exceptions\cf4 \strokec4 (\cf5 \strokec5 exceptions\cf4 \strokec4 )\}\cb1 \
\
\cb3 ---\cb1 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 ## \uc0\u21313 \u19968 \u12289 \u25968 \u25454 \u22475 \u28857 \cf4 \cb1 \strokec4 \
\
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \{\cf5 \strokec5 format_tracking\cf4 \strokec4 (\cf5 \strokec5 tracking\cf4 \strokec4 )\}\cb1 \
\
\cb3 ---\cb1 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 ## \uc0\u21464 \u26356 \u35760 \u24405 \cf4 \cb1 \strokec4 \
\
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 | \uc0\u29256 \u26412  | \u26085 \u26399  | \u20462 \u25913 \u20154  | \u20462 \u25913 \u20869 \u23481  |\cb1 \
\cb3 |-----|------|-------|---------|\cb1 \
\cb3 | \cf5 \strokec5 v1\cf6 \strokec6 .0\cf4 \strokec4  | \{\cf5 \strokec5 date_str\cf4 \strokec4 \} | - | \uc0\u21021 \u29256 \u21019 \u24314  |\cb1 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 """\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     return document\cf4 \cb1 \strokec4 \
\
\
\cf2 \cb3 \strokec2 def format_background(bg: Dict) -> str:\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     """\cf4 \strokec4 \uc0\u26684 \u24335 \u21270 \u38656 \u27714 \u32972 \u26223 \cf2 \strokec2 """\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     return f"""### 1.1 \uc0\u19994 \u21153 \u29616 \u29366 \cf4 \cb1 \strokec4 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \{\cf5 \strokec5 bg\cf4 \strokec4 .\cf5 \strokec5 get\cf4 \strokec4 (\cf2 \strokec2 'current_status'\cf4 \strokec4 , \cf2 \strokec2 '\uc0\u24453 \u34917 \u20805 '\cf4 \strokec4 )\}\cb1 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 ### 1.2 \uc0\u24066 \u22330 \u20998 \u26512 \cf4 \cb1 \strokec4 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \{\cf5 \strokec5 bg\cf4 \strokec4 .\cf5 \strokec5 get\cf4 \strokec4 (\cf2 \strokec2 'market_analysis'\cf4 \strokec4 , \cf2 \strokec2 '\uc0\u24453 \u34917 \u20805 '\cf4 \strokec4 )\}\cb1 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 ### 1.3 \uc0\u38656 \u27714 \u26469 \u28304 \cf4 \cb1 \strokec4 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \{\cf5 \strokec5 bg\cf4 \strokec4 .\cf5 \strokec5 get\cf4 \strokec4 (\cf2 \strokec2 'source'\cf4 \strokec4 , \cf2 \strokec2 '\uc0\u24453 \u34917 \u20805 '\cf4 \strokec4 )\}\cb1 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 ### 1.4 \uc0\u38382 \u39064 \u23450 \u20041 \cf4 \cb1 \strokec4 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \{\cf5 \strokec5 bg\cf4 \strokec4 .\cf5 \strokec5 get\cf4 \strokec4 (\cf2 \strokec2 'problem_definition'\cf4 \strokec4 , \cf2 \strokec2 '\uc0\u24453 \u34917 \u20805 '\cf4 \strokec4 )\}\cf2 \strokec2 """\cf4 \cb1 \strokec4 \
\
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 def format_data_architecture(data: Dict) -> str:\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     """\cf4 \strokec4 \uc0\u26684 \u24335 \u21270 \u25968 \u25454 \u26550 \u26500 \cf2 \strokec2 """\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     entities = data.get('entities', [])\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     entities_str = ""\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     for entity in entities:\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2         entities_str += f"| \{entity.get('name', '')\} | \{entity.get('desc', '')\} | \{entity.get('fields', '')\} |\\n"\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     \cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     return f"""### 2.1 \uc0\u26680 \u24515 \u25968 \u25454 \u23454 \u20307 \cf4 \cb1 \strokec4 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 | \uc0\u23454 \u20307 \u21517 \u31216  | \u35828 \u26126  | \u20851 \u38190 \u23383 \u27573  |\cb1 \
\cb3 |---------|------|---------|\cb1 \
\cb3 \{\cf5 \strokec5 entities_str\cf4 \strokec4  if \cf5 \strokec5 entities_str\cf4 \strokec4  else \cf2 \strokec2 '| - | - | - |'\cf4 \strokec4 \}\cb1 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 ### 2.2 \uc0\u25968 \u25454 \u27969 \u36716 \u22270 \cf4 \cb1 \strokec4 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \{\cf5 \strokec5 data\cf4 \strokec4 .\cf5 \strokec5 get\cf4 \strokec4 (\cf2 \strokec2 'flow'\cf4 \strokec4 , \cf2 \strokec2 '\uc0\u24453 \u34917 \u20805 '\cf4 \strokec4 )\}\cb1 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 ### 2.3 \uc0\u25968 \u25454 \u23384 \u20648 \cf4 \cb1 \strokec4 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \{\cf5 \strokec5 data\cf4 \strokec4 .\cf5 \strokec5 get\cf4 \strokec4 (\cf2 \strokec2 'storage'\cf4 \strokec4 , \cf2 \strokec2 '\uc0\u24453 \u34917 \u20805 '\cf4 \strokec4 )\}\cb1 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 ### 2.4 \uc0\u25968 \u25454 \u23433 \u20840 \cf4 \cb1 \strokec4 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \{\cf5 \strokec5 data\cf4 \strokec4 .\cf5 \strokec5 get\cf4 \strokec4 (\cf2 \strokec2 'security'\cf4 \strokec4 , \cf2 \strokec2 '\uc0\u24453 \u34917 \u20805 '\cf4 \strokec4 )\}\cf2 \strokec2 """\cf4 \cb1 \strokec4 \
\
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 def format_objectives(obj: Dict) -> str:\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     """\cf4 \strokec4 \uc0\u26684 \u24335 \u21270 \u38656 \u27714 \u30446 \u26631 \cf2 \strokec2 """\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     goals = obj.get('goals', [])\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     goals_str = ""\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     for goal in goals:\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2         goals_str += f"| \{goal.get('type', '')\} | \{goal.get('desc', '')\} | \{goal.get('metric', '')\} | \{goal.get('value', '')\} |\\n"\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     \cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     return f"""### 3.1 \uc0\u19994 \u21153 \u30446 \u26631 \cf4 \cb1 \strokec4 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 | \uc0\u30446 \u26631 \u31867 \u22411  | \u30446 \u26631 \u25551 \u36848  | \u34913 \u37327 \u25351 \u26631  | \u30446 \u26631 \u20540  |\cb1 \
\cb3 |---------|---------|---------|-------|\cb1 \
\cb3 \{\cf5 \strokec5 goals_str\cf4 \strokec4  if \cf5 \strokec5 goals_str\cf4 \strokec4  else \cf2 \strokec2 '| - | - | - | - |'\cf4 \strokec4 \}\cb1 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 ### 3.2 \uc0\u20135 \u21697 \u30446 \u26631 \cf4 \cb1 \strokec4 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \{\cf5 \strokec5 obj\cf4 \strokec4 .\cf5 \strokec5 get\cf4 \strokec4 (\cf2 \strokec2 'product_goals'\cf4 \strokec4 , \cf2 \strokec2 '\uc0\u24453 \u34917 \u20805 '\cf4 \strokec4 )\}\cb1 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 ### 3.3 \uc0\u25104 \u21151 \u26631 \u20934 \cf4 \cb1 \strokec4 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \{\cf5 \strokec5 obj\cf4 \strokec4 .\cf5 \strokec5 get\cf4 \strokec4 (\cf2 \strokec2 'success_criteria'\cf4 \strokec4 , \cf2 \strokec2 '\uc0\u24453 \u34917 \u20805 '\cf4 \strokec4 )\}\cf2 \strokec2 """\cf4 \cb1 \strokec4 \
\
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 def format_user_scenarios(user: Dict) -> str:\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     """\cf4 \strokec4 \uc0\u26684 \u24335 \u21270 \u29992 \u25143 \u19982 \u20351 \u29992 \u22330 \u26223 \cf2 \strokec2 """\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     return f"""### 4.1 \uc0\u29992 \u25143 \u30011 \u20687 \cf4 \cb1 \strokec4 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \{\cf5 \strokec5 user\cf4 \strokec4 .\cf5 \strokec5 get\cf4 \strokec4 (\cf2 \strokec2 'persona'\cf4 \strokec4 , \cf2 \strokec2 '\uc0\u24453 \u34917 \u20805 '\cf4 \strokec4 )\}\cb1 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 ### 4.2 \uc0\u29992 \u25143 \u35282 \u33394 \u30697 \u38453 \cf4 \cb1 \strokec4 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \{\cf5 \strokec5 user\cf4 \strokec4 .\cf5 \strokec5 get\cf4 \strokec4 (\cf2 \strokec2 'roles'\cf4 \strokec4 , \cf2 \strokec2 '\uc0\u24453 \u34917 \u20805 '\cf4 \strokec4 )\}\cb1 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 ### 4.3 \uc0\u20351 \u29992 \u22330 \u26223 \cf4 \cb1 \strokec4 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \{\cf5 \strokec5 user\cf4 \strokec4 .\cf5 \strokec5 get\cf4 \strokec4 (\cf2 \strokec2 'scenarios'\cf4 \strokec4 , \cf2 \strokec2 '\uc0\u24453 \u34917 \u20805 '\cf4 \strokec4 )\}\cb1 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 ### 4.4 \uc0\u29992 \u25143 \u26053 \u31243 \u22270 \cf4 \cb1 \strokec4 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \{\cf5 \strokec5 user\cf4 \strokec4 .\cf5 \strokec5 get\cf4 \strokec4 (\cf2 \strokec2 'journey'\cf4 \strokec4 , \cf2 \strokec2 '\uc0\u24453 \u34917 \u20805 '\cf4 \strokec4 )\}\cf2 \strokec2 """\cf4 \cb1 \strokec4 \
\
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 def format_features(features: List[Dict]) -> str:\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     """\cf4 \strokec4 \uc0\u26684 \u24335 \u21270 \u21151 \u33021 \u28165 \u21333 \cf2 \strokec2 """\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     features_str = ""\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     for i, f in enumerate(features, 1):\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2         features_str += f"| F\{i:03d\} | \{f.get('module', '')\} | \{f.get('name', '')\} | \{f.get('priority', 'P1')\} | \uc0\u24453 \u24320 \u21457  | - |\\n"\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     \cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     return f"""### \uc0\u21151 \u33021 \u27010 \u35272 \u34920 \cf4 \cb1 \strokec4 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 | \uc0\u32534 \u21495  | \u27169 \u22359  | \u21151 \u33021 \u28857  | \u20248 \u20808 \u32423  | \u29366 \u24577  | \u36127 \u36131 \u20154  |\cb1 \
\cb3 |-----|------|-------|-------|------|-------|\cb1 \
\cb3 \{\cf5 \strokec5 features_str\cf4 \strokec4  if \cf5 \strokec5 features_str\cf4 \strokec4  else \cf2 \strokec2 '| - | - | - | - | - | - |'\cf4 \strokec4 \}\cf2 \strokec2 """\cf4 \cb1 \strokec4 \
\
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 def format_detailed_design(design: Dict) -> str:\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     """\cf4 \strokec4 \uc0\u26684 \u24335 \u21270 \u35814 \u32454 \u26041 \u26696 \cf2 \strokec2 """\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     return design.get('content', '\uc0\u24453 \u34917 \u20805 \u35814 \u32454 \u35774 \u35745 \u26041 \u26696 ')\cf4 \cb1 \strokec4 \
\
\
\cf2 \cb3 \strokec2 def format_prototype(proto: Dict) -> str:\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     """\cf4 \strokec4 \uc0\u26684 \u24335 \u21270 \u21407 \u22411 \u22270 \u25551 \u36848 \cf2 \strokec2 """\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     return proto.get('description', '\uc0\u24453 \u34917 \u20805 \u21407 \u22411 \u22270 \u25551 \u36848 ')\cf4 \cb1 \strokec4 \
\
\
\cf2 \cb3 \strokec2 def format_api_design(apis: List[Dict]) -> str:\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     """\cf4 \strokec4 \uc0\u26684 \u24335 \u21270 \u25509 \u21475 \u35774 \u35745 \cf2 \strokec2 """\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     apis_str = ""\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     for i, api in enumerate(apis, 1):\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2         apis_str += f"| API-\{i:03d\} | \{api.get('name', '')\} | \{api.get('method', 'POST')\} | \{api.get('path', '')\} | \{api.get('desc', '')\} |\\n"\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     \cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     return f"""### 9.1 \uc0\u25509 \u21475 \u21015 \u34920 \cf4 \cb1 \strokec4 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 | \uc0\u32534 \u21495  | \u25509 \u21475 \u21517 \u31216  | \u35831 \u27714 \u26041 \u24335  | \u25509 \u21475 \u22320 \u22336  | \u35828 \u26126  |\cb1 \
\cb3 |-----|---------|---------|---------|------|\cb1 \
\cb3 \{\cf5 \strokec5 apis_str\cf4 \strokec4  if \cf5 \strokec5 apis_str\cf4 \strokec4  else \cf2 \strokec2 '| - | - | - | - | - |'\cf4 \strokec4 \}\cf2 \strokec2 """\cf4 \cb1 \strokec4 \
\
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 def format_exceptions(exceptions: List[Dict]) -> str:\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     """\cf4 \strokec4 \uc0\u26684 \u24335 \u21270 \u24322 \u24120 \u22788 \u29702 \cf2 \strokec2 """\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     exc_str = ""\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     for i, exc in enumerate(exceptions, 1):\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2         exc_str += f"| E\{i:03d\} | \{exc.get('type', '')\} | \{exc.get('scenario', '')\} | \{exc.get('message', '')\} | \{exc.get('solution', '')\} |\\n"\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     \cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     return f"""### 10.1 \uc0\u24322 \u24120 \u22330 \u26223 \u22788 \u29702 \cf4 \cb1 \strokec4 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 | \uc0\u38169 \u35823 \u30721  | \u24322 \u24120 \u31867 \u22411  | \u35302 \u21457 \u22330 \u26223  | \u29992 \u25143 \u25552 \u31034  | \u22788 \u29702 \u26041 \u26696  |\cb1 \
\cb3 |-------|---------|---------|---------|---------|\cb1 \
\cb3 \{\cf5 \strokec5 exc_str\cf4 \strokec4  if \cf5 \strokec5 exc_str\cf4 \strokec4  else \cf2 \strokec2 '| - | - | - | - | - |'\cf4 \strokec4 \}\cb1 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 ### 10.2 \uc0\u36793 \u30028 \u26465 \u20214 \cf4 \cb1 \strokec4 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \uc0\u24453 \u34917 \u20805 \u36793 \u30028 \u26465 \u20214 \u35828 \u26126 \cf2 \strokec2 """\cf4 \cb1 \strokec4 \
\
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 def format_tracking(tracking: List[Dict]) -> str:\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     """\cf4 \strokec4 \uc0\u26684 \u24335 \u21270 \u25968 \u25454 \u22475 \u28857 \cf2 \strokec2 """\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     track_str = ""\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     for i, t in enumerate(tracking, 1):\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2         track_str += f"| EVT\{i:03d\} | \{t.get('name', '')\} | \{t.get('type', '\uc0\u33258 \u23450 \u20041 ')\} | \{t.get('trigger', '')\} | P1 |\\n"\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     \cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     return f"""### 11.1 \uc0\u22475 \u28857 \u28165 \u21333 \cf4 \cb1 \strokec4 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 | \uc0\u20107 \u20214 \u32534 \u21495  | \u20107 \u20214 \u21517 \u31216  | \u20107 \u20214 \u31867 \u22411  | \u35302 \u21457 \u26102 \u26426  | \u20248 \u20808 \u32423  |\cb1 \
\cb3 |---------|---------|---------|---------|-------|\cb1 \
\cb3 \{\cf5 \strokec5 track_str\cf4 \strokec4  if \cf5 \strokec5 track_str\cf4 \strokec4  else \cf2 \strokec2 '| - | - | - | - | - |'\cf4 \strokec4 \}\cb1 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 ### 11.2 \uc0\u26680 \u24515 \u25351 \u26631 \cf4 \cb1 \strokec4 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \uc0\u24453 \u34917 \u20805 \u26680 \u24515 \u25351 \u26631 \u23450 \u20041 \cf2 \strokec2 """\cf4 \cb1 \strokec4 \
\
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 if __name__ == "__main__":\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     # \uc0\u31034 \u20363 \u20351 \u29992 \cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     print("Product Doc Writer - \uc0\u20135 \u21697 \u38656 \u27714 \u25991 \u26723 \u29983 \u25104 \u22120 ")\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     print("=" * 50)\cf4 \cb1 \strokec4 \
\cf2 \cb3 \strokec2     print("\uc0\u26412 \u27169 \u22359 \u20026 skill\u36741 \u21161 \u24037 \u20855 \u65292 \u36890 \u36807 AI\u23545 \u35805 \u26041 \u24335 \u35843 \u29992 ")\cf4 \cb1 \strokec4 \
\
}