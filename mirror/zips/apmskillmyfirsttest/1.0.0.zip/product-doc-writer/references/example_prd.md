{\rtf1\ansi\ansicpg936\cocoartf2821
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fnil\fcharset0 Menlo-Regular;\f1\fnil\fcharset0 Menlo-Bold;}
{\colortbl;\red255\green255\blue255;\red45\green45\blue45;\red255\green255\blue255;\red144\green1\blue18;
\red135\green44\blue160;}
{\*\expandedcolortbl;;\cssrgb\c23137\c23137\c23137;\cssrgb\c100000\c100000\c100000;\cssrgb\c63922\c8235\c8235;
\cssrgb\c60784\c27451\c69020;}
\paperw11900\paperh16840\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\deftab720
\pard\pardeftab720\partightenfactor0

\f0\fs26 \cf2 \cb3 \expnd0\expndtw0\kerning0
\outl0\strokewidth0 \strokec2 # \uc0\u20135 \u21697 \u38656 \u27714 \u25991 \u26723 \u31034 \u20363  - \u29992 \u25143 \u30331 \u24405 \u21151 \u33021 \cb1 \
\
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 >\cf2 \strokec2  \uc0\u26412 \u25991 \u26723 \u20026 \u29992 \u25143 \u30331 \u24405 \u21151 \u33021 \u30340 \u23436 \u25972 PRD\u31034 \u20363 \u65292 \u20379 \u21442 \u32771 \u12290 \cb1 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 ---\cb1 \
\
\cb3 # \uc0\u29992 \u25143 \u30331 \u24405 \u21151 \u33021 \u20135 \u21697 \u38656 \u27714 \u25991 \u26723 \cb1 \
\
\pard\pardeftab720\partightenfactor0

\f1\b \cf2 \cb3 **\uc0\u25991 \u26723 \u32534 \u21495 **
\f0\b0 \uc0\u65306 PRD-2024-001  \cb1 \

\f1\b \cb3 **\uc0\u29256 \u26412 \u21495 **
\f0\b0 \uc0\u65306 v1.0  \cb1 \

\f1\b \cb3 **\uc0\u21019 \u24314 \u26085 \u26399 **
\f0\b0 \uc0\u65306 2024-01-15  \cb1 \

\f1\b \cb3 **\uc0\u36127 \u36131 \u20154 **
\f0\b0 \uc0\u65306 \u24352 \u19977   \cb1 \

\f1\b \cb3 **\uc0\u29366 \u24577 **
\f0\b0 \uc0\u65306 \u24453 \u35780 \u23457 \cb1 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 ---\cb1 \
\
\cb3 ## \uc0\u19968 \u12289 \u38656 \u27714 \u32972 \u26223 \cb1 \
\
\cb3 ### 1.1 \uc0\u19994 \u21153 \u29616 \u29366 \cb1 \
\cb3 \uc0\u24403 \u21069 \u31995 \u32479 \u26410 \u25552 \u20379 \u32479 \u19968 \u30340 \u30331 \u24405 \u20837 \u21475 \u65292 \u29992 \u25143 \u26080 \u27861 \u36827 \u34892 \u36523 \u20221 \u35748 \u35777 \u65292 \u23548 \u33268 \u65306 \cb1 \
\cb3 - \uc0\u29992 \u25143 \u25968 \u25454 \u26080 \u27861 \u20851 \u32852 \u65292 \u26080 \u27861 \u25552 \u20379 \u20010 \u24615 \u21270 \u26381 \u21153 \cb1 \
\cb3 - \uc0\u26080 \u27861 \u36827 \u34892 \u29992 \u25143 \u34892 \u20026 \u36861 \u36394 \u21644 \u20998 \u26512 \cb1 \
\cb3 - \uc0\u25935 \u24863 \u25805 \u20316 \u26080 \u27861 \u36827 \u34892 \u26435 \u38480 \u26657 \u39564 \cb1 \
\cb3 - \uc0\u23458 \u26381 \u26080 \u27861 \u24555 \u36895 \u23450 \u20301 \u29992 \u25143 \u38382 \u39064 \cb1 \
\
\cb3 ### 1.2 \uc0\u24066 \u22330 \u20998 \u26512 \cb1 \
\cb3 \uc0\u31454 \u21697 \u20998 \u26512 \u26174 \u31034 \u65292 \u20027 \u27969 \u20135 \u21697 \u22343 \u24050 \u25903 \u25345 \u22810 \u31181 \u30331 \u24405 \u26041 \u24335 \u65306 \cb1 \
\cb3 | \uc0\u31454 \u21697  | \u30331 \u24405 \u26041 \u24335  | \u29305 \u28857  |\cb1 \
\cb3 |-----|---------|------|\cb1 \
\cb3 | \uc0\u20135 \u21697 A | \u25163 \u26426 \u21495 +\u39564 \u35777 \u30721  | \u26080 \u38656 \u35760 \u23494 \u30721 \u65292 \u20307 \u39564 \u27969 \u30021  |\cb1 \
\cb3 | \uc0\u20135 \u21697 B | \u36134 \u21495 \u23494 \u30721 +\u31532 \u19977 \u26041  | \u20256 \u32479 \u26041 \u24335 \u65292 \u35206 \u30422 \u38754 \u24191  |\cb1 \
\cb3 | \uc0\u20135 \u21697 C | \u19968 \u38190 \u30331 \u24405  | \u36816 \u33829 \u21830 \u25480 \u26435 \u65292 \u26497 \u31616 \u20307 \u39564  |\cb1 \
\
\cb3 ### 1.3 \uc0\u38656 \u27714 \u26469 \u28304 \cb1 \
\cb3 - \uc0\u20135 \u21697 \u35268 \u21010 \u65306 \u29992 \u25143 \u20307 \u31995 \u22522 \u30784 \u24314 \u35774 \cb1 \
\cb3 - \uc0\u25552 \u20986 \u20154 \u65306 \u20135 \u21697 \u22242 \u38431 \cb1 \
\cb3 - \uc0\u25552 \u20986 \u26102 \u38388 \u65306 2024-01-10\cb1 \
\
\cb3 ### 1.4 \uc0\u38382 \u39064 \u23450 \u20041 \cb1 \
\cb3 \uc0\u38656 \u35201 \u26500 \u24314 \u19968 \u22871 \u23436 \u25972 \u30340 \u29992 \u25143 \u30331 \u24405 \u20307 \u31995 \u65292 \u25903 \u25345 \u22810 \u31181 \u30331 \u24405 \u26041 \u24335 \u65292 \u22312 \u20445 \u38556 \u23433 \u20840 \u24615 \u30340 \u21069 \u25552 \u19979 \u65292 \u25552 \u20379 \u20415 \u25463 \u30340 \u30331 \u24405 \u20307 \u39564 \u12290 \cb1 \
\
\cb3 ---\cb1 \
\
\cb3 ## \uc0\u20108 \u12289 \u25968 \u25454 \u26550 \u26500 \u35828 \u26126 \cb1 \
\
\cb3 ### 2.1 \uc0\u26680 \u24515 \u25968 \u25454 \u23454 \u20307 \cb1 \
\cb3 | \uc0\u23454 \u20307 \u21517 \u31216  | \u35828 \u26126  | \u20851 \u38190 \u23383 \u27573  |\cb1 \
\cb3 |---------|------|---------|\cb1 \
\cb3 | \uc0\u29992 \u25143 (user) | \u29992 \u25143 \u22522 \u30784 \u20449 \u24687  | user_id, phone, nickname, avatar, status |\cb1 \
\cb3 | \uc0\u30331 \u24405 \u35760 \u24405 (login_log) | \u30331 \u24405 \u34892 \u20026 \u26085 \u24535  | log_id, user_id, login_type, ip, device, login_time |\cb1 \
\cb3 | \uc0\u31532 \u19977 \u26041 \u36134 \u21495 (third_account) | \u31532 \u19977 \u26041 \u24179 \u21488 \u32465 \u23450  | id, user_id, platform, openid, unionid |\cb1 \
\
\cb3 ### 2.2 \uc0\u25968 \u25454 \u27969 \u36716 \u22270 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 ```\cf2 \cb1 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf5 \cb3 \strokec5 \uc0\u29992 \u25143 \u36755 \u20837  \u8594  \u21069 \u31471 \u26657 \u39564  \u8594  \u21518 \u31471 \u39564 \u35777  \u8594  \u29992 \u25143 \u20013 \u24515  \u8594  \u36820 \u22238 Token\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5                           \uc0\u8595 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5                     \uc0\u35760 \u24405 \u30331 \u24405 \u26085 \u24535 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5                           \uc0\u8595 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5                     \uc0\u26356 \u26032 \u29992 \u25143 \u29366 \u24577 \cf2 \cb1 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 ```\cf2 \cb1 \strokec2 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 ### 2.3 \uc0\u25968 \u25454 \u23384 \u20648 \cb1 \
\cb3 - \uc0\u29992 \u25143 \u34920 \u65306 MySQL\u20027 \u24211 \u65292 \u25353 user_id\u20998 \u34920 \cb1 \
\cb3 - \uc0\u30331 \u24405 \u26085 \u24535 \u65306 ES\u38598 \u32676 \u65292 \u20445 \u30041 180\u22825 \cb1 \
\cb3 - Token\uc0\u65306 Redis\u38598 \u32676 \u65292 \u26377 \u25928 \u26399 7\u22825 \cb1 \
\
\cb3 ### 2.4 \uc0\u25968 \u25454 \u23433 \u20840 \cb1 \
\cb3 - \uc0\u23494 \u30721 \u65306 BCrypt\u21152 \u23494 \u23384 \u20648 \cb1 \
\cb3 - Token\uc0\u65306 JWT\u26684 \u24335 \u65292 \u21547 \u35774 \u22791 \u25351 \u32441 \cb1 \
\cb3 - \uc0\u25935 \u24863 \u25805 \u20316 \u65306 \u20108 \u27425 \u39564 \u35777 \cb1 \
\cb3 - \uc0\u30331 \u24405 \u24322 \u24120 \u65306 \u39118 \u25511 \u39044 \u35686 \cb1 \
\
\cb3 ---\cb1 \
\
\cb3 ## \uc0\u19977 \u12289 \u38656 \u27714 \u30446 \u26631 \cb1 \
\
\cb3 ### 3.1 \uc0\u19994 \u21153 \u30446 \u26631 \cb1 \
\cb3 | \uc0\u30446 \u26631 \u31867 \u22411  | \u30446 \u26631 \u25551 \u36848  | \u34913 \u37327 \u25351 \u26631  | \u30446 \u26631 \u20540  |\cb1 \
\cb3 |---------|---------|---------|-------|\cb1 \
\cb3 | \uc0\u26680 \u24515 \u30446 \u26631  | \u24314 \u31435 \u29992 \u25143 \u36134 \u21495 \u20307 \u31995  | \u27880 \u20876 \u29992 \u25143 \u25968  | 10\u19975 + |\cb1 \
\cb3 | \uc0\u20307 \u39564 \u30446 \u26631  | \u38477 \u20302 \u30331 \u24405 \u38376 \u27099  | \u30331 \u24405 \u25104 \u21151 \u29575  | 95%+ |\cb1 \
\cb3 | \uc0\u23433 \u20840 \u30446 \u26631  | \u20445 \u38556 \u36134 \u21495 \u23433 \u20840  | \u24322 \u24120 \u30331 \u24405 \u25318 \u25130 \u29575  | 99%+ |\cb1 \
\
\cb3 ### 3.2 \uc0\u20135 \u21697 \u30446 \u26631 \cb1 \
\cb3 - 
\f1\b **\uc0\u20307 \u39564 \u30446 \u26631 **
\f0\b0 \uc0\u65306 \u30331 \u24405 \u27969 \u31243 3\u27493 \u20869 \u23436 \u25104 \u65292 \u32791 \u26102 \u23567 \u20110 10\u31186 \cb1 \
\cb3 - 
\f1\b **\uc0\u25928 \u29575 \u30446 \u26631 **
\f0\b0 \uc0\u65306 \u25903 \u25345 \u22810 \u31181 \u30331 \u24405 \u26041 \u24335 \u65292 \u29992 \u25143 \u21487 \u33258 \u20027 \u36873 \u25321 \cb1 \
\cb3 - 
\f1\b **\uc0\u36136 \u37327 \u30446 \u26631 **
\f0\b0 \uc0\u65306 \u30331 \u24405 \u25509 \u21475 \u21487 \u29992 \u24615 99.9%\u65292 \u21709 \u24212 \u26102 \u38388 <500ms\cb1 \
\
\cb3 ### \cf5 \strokec5 3\cf2 \strokec2 .\cf5 \strokec5 3\cf2 \strokec2  \uc0\u25104 \u21151 \u26631 \u20934 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf5 \cb3 \strokec5 1\cf2 \strokec2 . \uc0\u30331 \u24405 \u25104 \u21151 \u29575  \u8805  \cf5 \strokec5 95\cf2 \strokec2 %\cb1 \
\cf5 \cb3 \strokec5 2\cf2 \strokec2 . \uc0\u30331 \u24405 \u32791 \u26102 \u20013 \u20301 \u25968  < \cf5 \strokec5 10\cf2 \strokec2 \uc0\u31186 \cb1 \
\cf5 \cb3 \strokec5 3\cf2 \strokec2 . \uc0\u29992 \u25143 \u30331 \u24405 \u30456 \u20851 \u25237 \u35785  < \cf5 \strokec5 5\cf2 \strokec2 \uc0\u20214 /\u26376 \cb1 \
\cf5 \cb3 \strokec5 4\cf2 \strokec2 . \uc0\u30331 \u24405 \u25509 \u21475 \cf5 \strokec5 P99\cf2 \strokec2 \uc0\u24310 \u36831  < \cf5 \strokec5 1\cf2 \strokec2 \uc0\u31186 \cb1 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 ---\cb1 \
\
\cb3 ## \uc0\u22235 \u12289 \u29992 \u25143 \u19982 \u20351 \u29992 \u22330 \u26223 \cb1 \
\
\cb3 ### \cf5 \strokec5 4\cf2 \strokec2 .\cf5 \strokec5 1\cf2 \strokec2  \uc0\u29992 \u25143 \u30011 \u20687 \cb1 \
\cb3 | \uc0\u32500 \u24230  | \u25551 \u36848  |\cb1 \
\cb3 |-----|------|\cb1 \
\cb3 | \uc0\u30446 \u26631 \u29992 \u25143  | \u25152 \u26377 \u38656 \u35201 \u20351 \u29992 \u31995 \u32479 \u26680 \u24515 \u21151 \u33021 \u30340 \u29992 \u25143  |\cb1 \
\cb3 | \uc0\u29992 \u25143 \u29305 \u24449  | \u24180 \u40836 \cf5 \strokec5 18\cf2 \strokec2 -\cf5 \strokec5 45\cf2 \strokec2 \uc0\u23681 \u65292 \u20855 \u22791 \u22522 \u26412 \u20114 \u32852 \u32593 \u25805 \u20316 \u33021 \u21147  |\cb1 \
\cb3 | \uc0\u26680 \u24515 \u38656 \u27714  | \u24555 \u36895 \u12289 \u23433 \u20840 \u22320 \u23436 \u25104 \u36523 \u20221 \u35748 \u35777 \u65292 \u36827 \u20837 \u31995 \u32479  |\cb1 \
\
\cb3 ### \cf5 \strokec5 4\cf2 \strokec2 .\cf5 \strokec5 2\cf2 \strokec2  \uc0\u29992 \u25143 \u35282 \u33394 \u30697 \u38453 \cb1 \
\cb3 | \uc0\u35282 \u33394  | \u32844 \u36131  | \u26435 \u38480 \u33539 \u22260  | \u20351 \u29992 \u39057 \u29575  |\cb1 \
\cb3 |-----|------|---------|---------|\cb1 \
\cb3 | \uc0\u26222 \u36890 \u29992 \u25143  | \u27983 \u35272 \u20869 \u23481 \u12289 \u19979 \u21333 \u36141 \u20080  | \u22522 \u30784 \u26435 \u38480  | \u27599 \u26085 \u22810 \u27425  |\cb1 \
\cb3 | \uc0\u20250 \u21592 \u29992 \u25143  | \u20139 \u21463 \u20250 \u21592 \u26435 \u30410  | \u20250 \u21592 \u19987 \u23646 \u26435 \u38480  | \u27599 \u26085 \u22810 \u27425  |\cb1 \
\cb3 | \uc0\u31649 \u29702 \u21592  | \u21518 \u21488 \u31649 \u29702  | \u31649 \u29702 \u26435 \u38480  | \u25353 \u38656  |\cb1 \
\
\cb3 ### \cf5 \strokec5 4\cf2 \strokec2 .\cf5 \strokec5 3\cf2 \strokec2  \uc0\u20351 \u29992 \u22330 \u26223 \cb1 \
\
\cb3 #### \uc0\u22330 \u26223 \u19968 \u65306 \u39318 \u27425 \u20351 \u29992 \cf5 \strokec5 App\cf2 \cb1 \strokec2 \
\cb3 - **\uc0\u35302 \u21457 \u26465 \u20214 **\u65306 \u29992 \u25143 \u19979 \u36733 \cf5 \strokec5 App\cf2 \strokec2 \uc0\u21518 \u39318 \u27425 \u25171 \u24320 \cb1 \
\cb3 - **\uc0\u29992 \u25143 \u30446 \u26631 **\u65306 \u24555 \u36895 \u27880 \u20876 \u36134 \u21495 \u24320 \u22987 \u20351 \u29992 \cb1 \
\cb3 - **\uc0\u25805 \u20316 \u36335 \u24452 **\u65306 \u25171 \u24320 \cf5 \strokec5 App\cf2 \strokec2  \uc0\u8594  \u27426 \u36814 \u39029  \u8594  \u27880 \u20876 \u30331 \u24405 \u39029  \u8594  \u25163 \u26426 \u21495 \u39564 \u35777 \u30721 \u30331 \u24405  \u8594  \u23436 \u25104 \u27880 \u20876 \cb1 \
\cb3 - **\uc0\u39044 \u26399 \u32467 \u26524 **\u65306 \cf5 \strokec5 10\cf2 \strokec2 \uc0\u31186 \u20869 \u23436 \u25104 \u27880 \u20876 \u65292 \u36827 \u20837 \u39318 \u39029 \cb1 \
\
\cb3 #### \uc0\u22330 \u26223 \u20108 \u65306 \u24050 \u30331 \u24405 \u29992 \u25143 \u20877 \u27425 \u20351 \u29992 \cb1 \
\cb3 - **\uc0\u35302 \u21457 \u26465 \u20214 **\u65306 \cf5 \strokec5 Token\cf2 \strokec2 \uc0\u36807 \u26399 \u25110 \u29992 \u25143 \u20027 \u21160 \u36864 \u20986 \u30331 \u24405 \cb1 \
\cb3 - **\uc0\u29992 \u25143 \u30446 \u26631 **\u65306 \u24555 \u36895 \u24674 \u22797 \u30331 \u24405 \u29366 \u24577 \cb1 \
\cb3 - **\uc0\u25805 \u20316 \u36335 \u24452 **\u65306 \u25171 \u24320 \cf5 \strokec5 App\cf2 \strokec2  \uc0\u8594  \u26816 \u27979 \u30331 \u24405 \u24577  \u8594  \u33258 \u21160 \u21047 \u26032 \cf5 \strokec5 Token\cf2 \strokec2 \uc0\u25110 \u24341 \u23548 \u37325 \u26032 \u30331 \u24405 \cb1 \
\cb3 - **\uc0\u39044 \u26399 \u32467 \u26524 **\u65306 \u26080 \u24863 \u21047 \u26032 \u25110 \u24555 \u36895 \u23436 \u25104 \u30331 \u24405 \cb1 \
\
\cb3 #### \uc0\u22330 \u26223 \u19977 \u65306 \u26032 \u35774 \u22791 \u30331 \u24405 \cb1 \
\cb3 - **\uc0\u35302 \u21457 \u26465 \u20214 **\u65306 \u29992 \u25143 \u22312 \u26032 \u35774 \u22791 \u19978 \u25171 \u24320 \cf5 \strokec5 App\cf2 \cb1 \strokec2 \
\cb3 - **\uc0\u29992 \u25143 \u30446 \u26631 **\u65306 \u23433 \u20840 \u30331 \u24405 \u36134 \u21495 \cb1 \
\cb3 - **\uc0\u25805 \u20316 \u36335 \u24452 **\u65306 \u36755 \u20837 \u25163 \u26426 \u21495  \u8594  \u39564 \u35777 \u30721  \u8594  \u35774 \u22791 \u39564 \u35777 \u65288 \u21487 \u36873 \u65289 \u8594  \u30331 \u24405 \u25104 \u21151 \cb1 \
\cb3 - **\uc0\u39044 \u26399 \u32467 \u26524 **\u65306 \u23436 \u25104 \u30331 \u24405 \u65292 \u26377 \u23433 \u20840 \u25552 \u31034 \cb1 \
\
\cb3 ### \cf5 \strokec5 4\cf2 \strokec2 .\cf5 \strokec5 4\cf2 \strokec2  \uc0\u29992 \u25143 \u26053 \u31243 \u22270 \cb1 \
\cb3 ```\cb1 \
\cb3 \uc0\u21457 \u29616  \u8594  \u32771 \u34385  \u8594  \u20351 \u29992  \u8594  \u24544 \u35802 \cb1 \
\cb3  \uc0\u8595        \u8595        \u8595        \u8595 \cb1 \
\cb3 \uc0\u19979 \u36733     \u27880 \u20876     \u30331 \u24405     \u32465 \u23450 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf5 \cb3 \strokec5 App\cf2 \strokec2      \uc0\u36134 \u21495     \u20351 \u29992    \u31532 \u19977 \u26041 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 ```\cb1 \
\
\cb3 ---\cb1 \
\
\cb3 ## \uc0\u20116 \u12289 \u38656 \u27714 \u21151 \u33021 \u28165 \u21333 \cb1 \
\
\cb3 ### \uc0\u21151 \u33021 \u27010 \u35272 \u34920 \cb1 \
\cb3 | \uc0\u32534 \u21495  | \u27169 \u22359  | \u21151 \u33021 \u28857  | \u20248 \u20808 \u32423  | \u29366 \u24577  | \u36127 \u36131 \u20154  |\cb1 \
\cb3 |-----|------|-------|-------|------|-------|\cb1 \
\cb3 | \cf5 \strokec5 F001\cf2 \strokec2  | \uc0\u30331 \u24405 \u26041 \u24335  | \u25163 \u26426 \u21495 +\u39564 \u35777 \u30721 \u30331 \u24405  | \cf5 \strokec5 P0\cf2 \strokec2  | \uc0\u24453 \u24320 \u21457  | \u26446 \u22235  |\cb1 \
\cb3 | \cf5 \strokec5 F002\cf2 \strokec2  | \uc0\u30331 \u24405 \u26041 \u24335  | \u36134 \u21495 \u23494 \u30721 \u30331 \u24405  | \cf5 \strokec5 P0\cf2 \strokec2  | \uc0\u24453 \u24320 \u21457  | \u26446 \u22235  |\cb1 \
\cb3 | \cf5 \strokec5 F003\cf2 \strokec2  | \uc0\u30331 \u24405 \u26041 \u24335  | \u31532 \u19977 \u26041 \u30331 \u24405 \u65288 \u24494 \u20449 \u65289  | \cf5 \strokec5 P1\cf2 \strokec2  | \uc0\u24453 \u24320 \u21457  | \u29579 \u20116  |\cb1 \
\cb3 | \cf5 \strokec5 F004\cf2 \strokec2  | \uc0\u30331 \u24405 \u26041 \u24335  | \u31532 \u19977 \u26041 \u30331 \u24405 \u65288 \cf5 \strokec5 Apple\cf2 \strokec2  \cf5 \strokec5 ID\cf2 \strokec2 \uc0\u65289  | \cf5 \strokec5 P1\cf2 \strokec2  | \uc0\u24453 \u24320 \u21457  | \u29579 \u20116  |\cb1 \
\cb3 | \cf5 \strokec5 F005\cf2 \strokec2  | \uc0\u23433 \u20840 \u21151 \u33021  | \u30331 \u24405 \u24322 \u24120 \u26816 \u27979  | \cf5 \strokec5 P0\cf2 \strokec2  | \uc0\u24453 \u24320 \u21457  | \u36213 \u20845  |\cb1 \
\cb3 | \cf5 \strokec5 F006\cf2 \strokec2  | \uc0\u23433 \u20840 \u21151 \u33021  | \u35774 \u22791 \u31649 \u29702  | \cf5 \strokec5 P1\cf2 \strokec2  | \uc0\u24453 \u24320 \u21457  | \u36213 \u20845  |\cb1 \
\cb3 | \cf5 \strokec5 F007\cf2 \strokec2  | \uc0\u36134 \u21495 \u31649 \u29702  | \u25214 \u22238 \u23494 \u30721  | \cf5 \strokec5 P1\cf2 \strokec2  | \uc0\u24453 \u24320 \u21457  | \u26446 \u22235  |\cb1 \
\cb3 | \cf5 \strokec5 F008\cf2 \strokec2  | \uc0\u36134 \u21495 \u31649 \u29702  | \u20462 \u25913 \u23494 \u30721  | \cf5 \strokec5 P2\cf2 \strokec2  | \uc0\u24453 \u24320 \u21457  | \u26446 \u22235  |\cb1 \
\
\cb3 ### \cf5 \strokec5 5\cf2 \strokec2 .\cf5 \strokec5 1\cf2 \strokec2  \uc0\u30331 \u24405 \u26041 \u24335 \u27169 \u22359 \cb1 \
\
\cb3 #### \cf5 \strokec5 F001\cf2 \strokec2  - \uc0\u25163 \u26426 \u21495 +\u39564 \u35777 \u30721 \u30331 \u24405 \cb1 \
\cb3 - **\uc0\u21151 \u33021 \u25551 \u36848 **\u65306 \u29992 \u25143 \u36755 \u20837 \u25163 \u26426 \u21495 \u65292 \u33719 \u21462 \u24182 \u36755 \u20837 \u39564 \u35777 \u30721 \u23436 \u25104 \u30331 \u24405 \cb1 \
\cb3 - **\uc0\u36755 \u20837 **\u65306 \u25163 \u26426 \u21495 \u65288 \cf5 \strokec5 11\cf2 \strokec2 \uc0\u20301 \u65289 \u12289 \u39564 \u35777 \u30721 \u65288 \cf5 \strokec5 6\cf2 \strokec2 \uc0\u20301 \u65289 \cb1 \
\cb3 - **\uc0\u36755 \u20986 **\u65306 \u30331 \u24405 \u25104 \u21151 /\u22833 \u36133 \u25552 \u31034 \cb1 \
\cb3 - **\uc0\u35268 \u21017 **\u65306 \cb1 \
\cb3   - \uc0\u25163 \u26426 \u21495 \u26684 \u24335 \u26657 \u39564 \u65306 \cf5 \strokec5 1\cf2 \strokec2 \uc0\u24320 \u22836 \u65292 \cf5 \strokec5 11\cf2 \strokec2 \uc0\u20301 \u25968 \u23383 \cb1 \
\cb3   - \uc0\u39564 \u35777 \u30721 \u26377 \u25928 \u26399 \cf5 \strokec5 5\cf2 \strokec2 \uc0\u20998 \u38047 \cb1 \
\cb3   - \uc0\u21516 \u19968 \u25163 \u26426 \u21495 \cf5 \strokec5 60\cf2 \strokec2 \uc0\u31186 \u20869 \u21482 \u33021 \u21457 \u36865 \u19968 \u27425 \u39564 \u35777 \u30721 \cb1 \
\cb3   - \uc0\u39564 \u35777 \u30721 \u38169 \u35823 \u27425 \u25968 \u38480 \u21046 \cf5 \strokec5 5\cf2 \strokec2 \uc0\u27425 \cb1 \
\
\cb3 ---\cb1 \
\
\cb3 ## \uc0\u20845 \u12289 \u35814 \u32454 \u26041 \u26696 \cb1 \
\
\cb3 ### \cf5 \strokec5 6\cf2 \strokec2 .\cf5 \strokec5 1\cf2 \strokec2  \uc0\u25163 \u26426 \u21495 +\u39564 \u35777 \u30721 \u30331 \u24405 \u35814 \u32454 \u35774 \u35745 \cb1 \
\
\cb3 #### \cf5 \strokec5 6\cf2 \strokec2 .\cf5 \strokec5 1\cf2 \strokec2 .\cf5 \strokec5 1\cf2 \strokec2  \uc0\u21151 \u33021 \u20837 \u21475 \cb1 \
\cb3 - **\uc0\u20837 \u21475 \u20301 \u32622 **\u65306 \u21551 \u21160 \u39029 \u12289 \u25105 \u30340 \u39029 \u38754 \u65288 \u26410 \u30331 \u24405 \u24577 \u65289 \cb1 \
\cb3 - **\uc0\u35302 \u21457 \u26041 \u24335 **\u65306 \u28857 \u20987 \u12300 \u30331 \u24405 /\u27880 \u20876 \u12301 \u25353 \u38062 \cb1 \
\cb3 - **\uc0\u21069 \u32622 \u26465 \u20214 **\u65306 \u29992 \u25143 \u26410 \u30331 \u24405 \u25110 \cf5 \strokec5 Token\cf2 \strokec2 \uc0\u24050 \u36807 \u26399 \cb1 \
\
\cb3 #### \cf5 \strokec5 6\cf2 \strokec2 .\cf5 \strokec5 1\cf2 \strokec2 .\cf5 \strokec5 2\cf2 \strokec2  \uc0\u20132 \u20114 \u36923 \u36753 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf5 \cb3 \strokec5 1\cf2 \strokec2 . \uc0\u23637 \u31034 \u30331 \u24405 \u39029 \u38754 \u65292 \u40664 \u35748 \u36873 \u20013 \u12300 \u39564 \u35777 \u30721 \u30331 \u24405 \u12301 \cf5 \strokec5 Tab\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 2\cf2 \strokec2 . \uc0\u29992 \u25143 \u36755 \u20837 \u25163 \u26426 \u21495 \cb1 \
\cf5 \cb3 \strokec5 3\cf2 \strokec2 . \uc0\u28857 \u20987 \u12300 \u33719 \u21462 \u39564 \u35777 \u30721 \u12301 \u25353 \u38062 \cb1 \
\cf5 \cb3 \strokec5 4\cf2 \strokec2 . \uc0\u31995 \u32479 \u21457 \u36865 \u39564 \u35777 \u30721 \u65292 \u25353 \u38062 \u36827 \u20837 \cf5 \strokec5 60\cf2 \strokec2 \uc0\u31186 \u20498 \u35745 \u26102 \cb1 \
\cf5 \cb3 \strokec5 5\cf2 \strokec2 . \uc0\u29992 \u25143 \u36755 \u20837 \u39564 \u35777 \u30721 \cb1 \
\cf5 \cb3 \strokec5 6\cf2 \strokec2 . \uc0\u28857 \u20987 \u12300 \u30331 \u24405 \u12301 \u25353 \u38062 \cb1 \
\cf5 \cb3 \strokec5 7\cf2 \strokec2 . \uc0\u31995 \u32479 \u39564 \u35777 \u36890 \u36807 \u65292 \u36339 \u36716 \u33267 \u39318 \u39029 \cb1 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 #### \cf5 \strokec5 6\cf2 \strokec2 .\cf5 \strokec5 1\cf2 \strokec2 .\cf5 \strokec5 3\cf2 \strokec2  \uc0\u23637 \u31034 \u35268 \u21017 \cb1 \
\cb3 | \uc0\u23637 \u31034 \u39033  | \u35268 \u21017 \u35828 \u26126  |\cb1 \
\cb3 |-------|---------|\cb1 \
\cb3 | \cf5 \strokec5 Logo\cf2 \strokec2  | \uc0\u23621 \u20013 \u23637 \u31034 \u65292 \u39640 \u24230 \cf5 \strokec5 80px\cf2 \strokec2  |\cb1 \
\cb3 | \uc0\u25163 \u26426 \u21495 \u36755 \u20837 \u26694  | \u40664 \u35748 \u25552 \u31034 \u12300 \u35831 \u36755 \u20837 \u25163 \u26426 \u21495 \u12301 \u65292 \u26368 \u22823 \cf5 \strokec5 11\cf2 \strokec2 \uc0\u20301  |\cb1 \
\cb3 | \uc0\u39564 \u35777 \u30721 \u36755 \u20837 \u26694  | \u40664 \u35748 \u25552 \u31034 \u12300 \u35831 \u36755 \u20837 \u39564 \u35777 \u30721 \u12301 \u65292 \u26368 \u22823 \cf5 \strokec5 6\cf2 \strokec2 \uc0\u20301  |\cb1 \
\cb3 | \uc0\u33719 \u21462 \u39564 \u35777 \u30721 \u25353 \u38062  | \u40664 \u35748 \u29366 \u24577 \u12300 \u33719 \u21462 \u39564 \u35777 \u30721 \u12301 \u65292 \u20498 \u35745 \u26102 \u26174 \u31034 \u12300 \cf5 \strokec5 60s\cf2 \strokec2 \uc0\u21518 \u37325 \u35797 \u12301  |\cb1 \
\cb3 | \uc0\u30331 \u24405 \u25353 \u38062  | \u39564 \u35777 \u30721 \u36755 \u20837 \u21518 \u20142 \u36215  |\cb1 \
\
\cb3 #### \cf5 \strokec5 6\cf2 \strokec2 .\cf5 \strokec5 1\cf2 \strokec2 .\cf5 \strokec5 4\cf2 \strokec2  \uc0\u25805 \u20316 \u35268 \u21017 \cb1 \
\cb3 | \uc0\u25805 \u20316  | \u35268 \u21017 \u35828 \u26126  |\cb1 \
\cb3 |-----|---------|\cb1 \
\cb3 | \uc0\u36755 \u20837 \u25163 \u26426 \u21495  | \u23454 \u26102 \u26657 \u39564 \u26684 \u24335 \u65292 \u19981 \u31526 \u21512 \u21017 \u36793 \u26694 \u21464 \u32418  |\cb1 \
\cb3 | \uc0\u28857 \u20987 \u33719 \u21462 \u39564 \u35777 \u30721  | \u25163 \u26426 \u21495 \u26684 \u24335 \u27491 \u30830 \u25165 \u33021 \u28857 \u20987 \u65292 \u21542 \u21017 \u25552 \u31034  |\cb1 \
\cb3 | \uc0\u36755 \u20837 \u39564 \u35777 \u30721  | \u32431 \u25968 \u23383 \u65292 \u33258 \u21160 \u24377 \u20986 \u25968 \u23383 \u38190 \u30424  |\cb1 \
\cb3 | \uc0\u28857 \u20987 \u30331 \u24405  | \u25163 \u26426 \u21495 \u21644 \u39564 \u35777 \u30721 \u37117 \u22635 \u20889 \u25165 \u33021 \u28857 \u20987  |\cb1 \
\
\cb3 #### \cf5 \strokec5 6\cf2 \strokec2 .\cf5 \strokec5 1\cf2 \strokec2 .\cf5 \strokec5 5\cf2 \strokec2  \uc0\u36793 \u30028 \u24773 \u20917 \cb1 \
\cb3 - **\uc0\u25163 \u26426 \u21495 \u24050 \u27880 \u20876 **\u65306 \u30452 \u25509 \u30331 \u24405 \u65292 \u26080 \u29305 \u27530 \u25552 \u31034 \cb1 \
\cb3 - **\uc0\u25163 \u26426 \u21495 \u26410 \u27880 \u20876 **\u65306 \u33258 \u21160 \u23436 \u25104 \u27880 \u20876 \u24182 \u30331 \u24405 \cb1 \
\cb3 - **\uc0\u39564 \u35777 \u30721 \u36807 \u26399 **\u65306 \u25552 \u31034 \u12300 \u39564 \u35777 \u30721 \u24050 \u36807 \u26399 \u65292 \u35831 \u37325 \u26032 \u33719 \u21462 \u12301 \cb1 \
\cb3 - **\uc0\u39564 \u35777 \u30721 \u38169 \u35823 **\u65306 \u25552 \u31034 \u12300 \u39564 \u35777 \u30721 \u38169 \u35823 \u65292 \u35831 \u37325 \u26032 \u36755 \u20837 \u12301 \u65292 \u26174 \u31034 \u21097 \u20313 \u27425 \u25968 \cb1 \
\cb3 - **\uc0\u38169 \u35823 \u36229 \u38480 **\u65306 \u25552 \u31034 \u12300 \u39564 \u35777 \u30721 \u36755 \u20837 \u38169 \u35823 \u27425 \u25968 \u36807 \u22810 \u65292 \u35831 \u37325 \u26032 \u33719 \u21462 \u12301 \cb1 \
\
\cb3 ---\cb1 \
\
\cb3 ## \uc0\u19971 \u12289 \u19994 \u21153 \u27969 \u31243 \u22270 \cb1 \
\
\cb3 ### \cf5 \strokec5 7\cf2 \strokec2 .\cf5 \strokec5 1\cf2 \strokec2  \uc0\u25163 \u26426 \u21495 \u30331 \u24405 \u20027 \u27969 \u31243 \cb1 \
\cb3 ```\cf5 \strokec5 mermaid\cf2 \cb1 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf5 \cb3 \strokec5 flowchart\cf2 \strokec2  \cf5 \strokec5 TD\cf2 \cb1 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3     \cf5 \strokec5 A\cf2 \strokec2 [\uc0\u24320 \u22987 ] --> B\cf4 \strokec4 [\uc0\u36827 \u20837 \u30331 \u24405 \u39029 ]\cf2 \cb1 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4     B --> C[\uc0\u36755 \u20837 \u25163 \u26426 \u21495 ]\cf2 \cb1 \strokec2 \
\cf4 \cb3 \strokec4     C --> D\{\uc0\u25163 \u26426 \u21495 \u26684 \u24335 \u26657 \u39564 \}\cf2 \cb1 \strokec2 \
\cf4 \cb3 \strokec4     D -->|\uc0\u22833 \u36133 | E[\u25552 \u31034 \u26684 \u24335 \u38169 \u35823 ]\cf2 \cb1 \strokec2 \
\cf4 \cb3 \strokec4     E --> C\cf2 \cb1 \strokec2 \
\cf4 \cb3 \strokec4     D -->|\uc0\u36890 \u36807 | F[\u28857 \u20987 \u33719 \u21462 \u39564 \u35777 \u30721 ]\cf2 \cb1 \strokec2 \
\cf4 \cb3 \strokec4     F --> G\{60\uc0\u31186 \u38480 \u21046 \u26657 \u39564 \}\cf2 \cb1 \strokec2 \
\cf4 \cb3 \strokec4     G -->|\uc0\u38480 \u21046 \u20013 | H[\u26174 \u31034 \u20498 \u35745 \u26102 ]\cf2 \cb1 \strokec2 \
\cf4 \cb3 \strokec4     G -->|\uc0\u21487 \u21457 \u36865 | I[\u21457 \u36865 \u39564 \u35777 \u30721 ]\cf2 \cb1 \strokec2 \
\cf4 \cb3 \strokec4     I --> J[\uc0\u24320 \u22987 60\u31186 \u20498 \u35745 \u26102 ]\cf2 \cb1 \strokec2 \
\cf4 \cb3 \strokec4     J --> K[\uc0\u36755 \u20837 \u39564 \u35777 \u30721 ]\cf2 \cb1 \strokec2 \
\cf4 \cb3 \strokec4     K --> L[\uc0\u28857 \u20987 \u30331 \u24405 ]\cf2 \cb1 \strokec2 \
\cf4 \cb3 \strokec4     L --> M\{\uc0\u39564 \u35777 \u30721 \u26657 \u39564 \}\cf2 \cb1 \strokec2 \
\cf4 \cb3 \strokec4     M -->|\uc0\u22833 \u36133 | N\{\u38169 \u35823 \u27425 \u25968 <5?\}\cf2 \cb1 \strokec2 \
\cf4 \cb3 \strokec4     N -->|\uc0\u26159 | O[\u25552 \u31034 \u38169 \u35823 ]\cf2 \cb1 \strokec2 \
\cf4 \cb3 \strokec4     O --> K\cf2 \cb1 \strokec2 \
\cf4 \cb3 \strokec4     N -->|\uc0\u21542 | P[\u38145 \u23450 \u65292 \u37325 \u26032 \u33719 \u21462 ]\cf2 \cb1 \strokec2 \
\cf4 \cb3 \strokec4     P --> F\cf2 \cb1 \strokec2 \
\cf4 \cb3 \strokec4     M -->|\uc0\u36890 \u36807 | Q\{\u29992 \u25143 \u26159 \u21542 \u23384 \u22312 ?\}\cf2 \cb1 \strokec2 \
\cf4 \cb3 \strokec4     Q -->|\uc0\u21542 | R[\u33258 \u21160 \u27880 \u20876 ]\cf2 \cb1 \strokec2 \
\cf4 \cb3 \strokec4     Q -->|\uc0\u26159 | S[\u26356 \u26032 \u30331 \u24405 \u20449 \u24687 ]\cf2 \cb1 \strokec2 \
\cf4 \cb3 \strokec4     R --> S\cf2 \cb1 \strokec2 \
\cf4 \cb3 \strokec4     S --> T[\uc0\u29983 \u25104 Token]\cf2 \cb1 \strokec2 \
\cf4 \cb3 \strokec4     T --> U[\uc0\u36339 \u36716 \u39318 \u39029 ]\cf2 \cb1 \strokec2 \
\cf4 \cb3 \strokec4     U --> V[\uc0\u32467 \u26463 ]\cf2 \cb1 \strokec2 \
\cf4 \cb3 \strokec4 ```\cf2 \cb1 \strokec2 \
\
\pard\pardeftab720\partightenfactor0
\cf5 \cb3 \strokec5 ### 7.2 \uc0\u24322 \u24120 \u27969 \u31243 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 - \uc0\u32593 \u32476 \u24322 \u24120 \u65306 \u25552 \u31034 \u12300 \u32593 \u32476 \u24322 \u24120 \u65292 \u35831 \u26816 \u26597 \u32593 \u32476 \u21518 \u37325 \u35797 \u12301 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 - \uc0\u26381 \u21153 \u24322 \u24120 \u65306 \u25552 \u31034 \u12300 \u31995 \u32479 \u32321 \u24537 \u65292 \u35831 \u31245 \u21518 \u37325 \u35797 \u12301 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 - \uc0\u36134 \u21495 \u24322 \u24120 \u65306 \u25552 \u31034 \u12300 \u36134 \u21495 \u24322 \u24120 \u65292 \u35831 \u32852 \u31995 \u23458 \u26381 \u12301 \cf2 \cb1 \strokec2 \
\
\cf5 \cb3 \strokec5 ---\cf2 \cb1 \strokec2 \
\
\cf5 \cb3 \strokec5 ## \uc0\u20843 \u12289 \u39640 \u20445 \u30495 \u21407 \u22411 \u22270 \cf2 \cb1 \strokec2 \
\
\cf5 \cb3 \strokec5 ### 8.1 \uc0\u39029 \u38754 \u21015 \u34920 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 | \uc0\u39029 \u38754 \u32534 \u21495  | \u39029 \u38754 \u21517 \u31216  | \u21151 \u33021 \u25551 \u36848  |\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 |---------|---------|---------|\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 | P001 | \uc0\u30331 \u24405 \u39029  | \u30331 \u24405 \u20837 \u21475 \u65292 \u25903 \u25345 \u22810 \u31181 \u30331 \u24405 \u26041 \u24335  |\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 | P002 | \uc0\u39564 \u35777 \u30721 \u36755 \u20837 \u39029  | \u30701 \u20449 \u39564 \u35777 \u30721 \u36755 \u20837  |\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 | P003 | \uc0\u23494 \u30721 \u30331 \u24405 \u39029  | \u36134 \u21495 \u23494 \u30721 \u30331 \u24405  |\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 | P004 | \uc0\u25214 \u22238 \u23494 \u30721 \u39029  | \u23494 \u30721 \u37325 \u32622 \u27969 \u31243  |\cf2 \cb1 \strokec2 \
\
\cf5 \cb3 \strokec5 ### 8.2 \uc0\u39029 \u38754 \u35814 \u32454 \u35774 \u35745 \cf2 \cb1 \strokec2 \
\
\cf5 \cb3 \strokec5 #### P001 - \uc0\u30331 \u24405 \u39029 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 **\uc0\u39029 \u38754 \u24067 \u23616 \u65306 **\cf2 \cb1 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 ```\cf2 \cb1 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 +------------------------------------------+\cb1 \
\cb3 |              [\uc0\u20851 \u38381 \u25353 \u38062 ]                    |\cb1 \
\cb3 +------------------------------------------+\cb1 \
\cb3 |                                          |\cb1 \
\cb3 |              [App Logo]                   |\cb1 \
\cb3 |           \uc0\u27426 \u36814 \u20351 \u29992 App                      |\cb1 \
\cb3 |                                          |\cb1 \
\cb3 +------------------------------------------+\cb1 \
\cb3 |    [\uc0\u39564 \u35777 \u30721 \u30331 \u24405 ]    |    [\u23494 \u30721 \u30331 \u24405 ]         |\cb1 \
\cb3 +------------------------------------------+\cb1 \
\cb3 |   +----------------------------------+   |\cb1 \
\cb3 |   | \uc0\u35831 \u36755 \u20837 \u25163 \u26426 \u21495                       |   |\cb1 \
\cb3 |   +----------------------------------+   |\cb1 \
\cb3 |   +----------------------------------+   |\cb1 \
\cb3 |   | \uc0\u35831 \u36755 \u20837 \u39564 \u35777 \u30721     [\u33719 \u21462 \u39564 \u35777 \u30721 ]      |   |\cb1 \
\cb3 |   +----------------------------------+   |\cb1 \
\cb3 |                                          |\cb1 \
\cb3 |   +----------------------------------+   |\cb1 \
\cb3 |   |             \uc0\u30331  \u24405                  |   |\cb1 \
\cb3 |   +----------------------------------+   |\cb1 \
\cb3 |                                          |\cb1 \
\cb3 |   \uc0\u9472 \u9472 \u9472 \u9472 \u9472 \u9472 \u9472 \u9472  \u20854 \u20182 \u30331 \u24405 \u26041 \u24335  \u9472 \u9472 \u9472 \u9472 \u9472 \u9472 \u9472 \u9472           |\cb1 \
\cb3 |   [\uc0\u24494 \u20449 ]  [Apple]  [QQ]                  |\cb1 \
\cb3 |                                          |\cb1 \
\cb3 +------------------------------------------+\cb1 \
\cb3 |         \uc0\u30331 \u24405 \u21363 \u34920 \u31034 \u21516 \u24847 \u12298 \u29992 \u25143 \u21327 \u35758 \u12299           |\cb1 \
\cb3 |              \uc0\u21644 \u12298 \u38544 \u31169 \u25919 \u31574 \u12299                  |\cb1 \
\cb3 +------------------------------------------+\cb1 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 ```\cf2 \cb1 \strokec2 \
\
\pard\pardeftab720\partightenfactor0
\cf5 \cb3 \strokec5 **\uc0\u20132 \u20114 \u35828 \u26126 \u65306 **\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 - Tab\uc0\u20999 \u25442 \u65306 \u28857 \u20987 \u20999 \u25442 \u39564 \u35777 \u30721 /\u23494 \u30721 \u30331 \u24405 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 - \uc0\u33719 \u21462 \u39564 \u35777 \u30721 \u65306 \u28857 \u20987 \u21518 60\u31186 \u20498 \u35745 \u26102 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 - \uc0\u30331 \u24405 \u25353 \u38062 \u65306 \u36755 \u20837 \u23436 \u25104 \u21518 \u21487 \u28857 \u20987 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 - \uc0\u31532 \u19977 \u26041 \u22270 \u26631 \u65306 \u28857 \u20987 \u36339 \u36716 \u23545 \u24212 \u25480 \u26435 \u39029 \cf2 \cb1 \strokec2 \
\
\cf5 \cb3 \strokec5 **\uc0\u29366 \u24577 \u35828 \u26126 \u65306 **\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 | \uc0\u29366 \u24577  | \u23637 \u31034 \u20869 \u23481  | \u35302 \u21457 \u26465 \u20214  |\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 |-----|---------|---------|\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 | \uc0\u40664 \u35748 \u24577  | \u31354 \u36755 \u20837 \u26694  | \u39029 \u38754 \u21021 \u22987 \u21152 \u36733  |\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 | \uc0\u36755 \u20837 \u24577  | \u36755 \u20837 \u26694 \u26377 \u20869 \u23481  | \u29992 \u25143 \u27491 \u22312 \u36755 \u20837  |\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 | \uc0\u38169 \u35823 \u24577  | \u36755 \u20837 \u26694 \u32418 \u33394 \u36793 \u26694  + \u38169 \u35823 \u25552 \u31034  | \u26684 \u24335 \u26657 \u39564 \u22833 \u36133  |\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 | \uc0\u21152 \u36733 \u24577  | \u30331 \u24405 \u25353 \u38062 \u26174 \u31034 Loading | \u27491 \u22312 \u30331 \u24405 \u20013  |\cf2 \cb1 \strokec2 \
\
\cf5 \cb3 \strokec5 ---\cf2 \cb1 \strokec2 \
\
\cf5 \cb3 \strokec5 ## \uc0\u20061 \u12289 \u25509 \u21475 \u35774 \u35745 \cf2 \cb1 \strokec2 \
\
\cf5 \cb3 \strokec5 ### 9.1 \uc0\u25509 \u21475 \u21015 \u34920 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 | \uc0\u32534 \u21495  | \u25509 \u21475 \u21517 \u31216  | \u35831 \u27714 \u26041 \u24335  | \u25509 \u21475 \u22320 \u22336  | \u35828 \u26126  |\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 |-----|---------|---------|---------|------|\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 | API-001 | \uc0\u21457 \u36865 \u39564 \u35777 \u30721  | POST | /api/v1/auth/sms-code | \u21457 \u36865 \u30331 \u24405 \u39564 \u35777 \u30721  |\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 | API-002 | \uc0\u39564 \u35777 \u30721 \u30331 \u24405  | POST | /api/v1/auth/login/sms | \u25163 \u26426 \u21495 +\u39564 \u35777 \u30721 \u30331 \u24405  |\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 | API-003 | \uc0\u23494 \u30721 \u30331 \u24405  | POST | /api/v1/auth/login/password | \u36134 \u21495 \u23494 \u30721 \u30331 \u24405  |\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 | API-004 | \uc0\u36864 \u20986 \u30331 \u24405  | POST | /api/v1/auth/logout | \u36864 \u20986 \u30331 \u24405  |\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 | API-005 | \uc0\u21047 \u26032 Token | POST | /api/v1/auth/refresh | \u21047 \u26032 \u35775 \u38382 \u20196 \u29260  |\cf2 \cb1 \strokec2 \
\
\cf5 \cb3 \strokec5 ### 9.2 \uc0\u25509 \u21475 \u35814 \u32454 \u35774 \u35745 \cf2 \cb1 \strokec2 \
\
\cf5 \cb3 \strokec5 #### API-001 \uc0\u21457 \u36865 \u39564 \u35777 \u30721 \cf2 \cb1 \strokec2 \
\
\cf5 \cb3 \strokec5 **\uc0\u22522 \u26412 \u20449 \u24687 **\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 - **\uc0\u25509 \u21475 \u22320 \u22336 **\u65306 `POST /api/v1/auth/sms-code`\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 - **\uc0\u21151 \u33021 \u35828 \u26126 **\u65306 \u21457 \u36865 \u30331 \u24405 \u39564 \u35777 \u30721 \u30701 \u20449 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 - **\uc0\u35843 \u29992 \u26041 **\u65306 App\u23458 \u25143 \u31471 \cf2 \cb1 \strokec2 \
\
\cf5 \cb3 \strokec5 **\uc0\u35831 \u27714 \u21442 \u25968 **\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 | \uc0\u21442 \u25968 \u21517  | \u31867 \u22411  | \u24517 \u22635  | \u35828 \u26126  | \u31034 \u20363 \u20540  |\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 |-------|------|-----|------|-------|\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 | phone | String | \uc0\u26159  | \u25163 \u26426 \u21495 \u65292 11\u20301  | 13800138000 |\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 | type | String | \uc0\u26159  | \u39564 \u35777 \u30721 \u31867 \u22411 \u65306 login/register/reset | login |\cf2 \cb1 \strokec2 \
\
\cf5 \cb3 \strokec5 **\uc0\u35831 \u27714 \u31034 \u20363 **\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 ```json\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 \{\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5   "phone": "13800138000",\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5   "type": "login"\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 \}\cf2 \cb1 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 ```\cf2 \cb1 \strokec2 \
\
\pard\pardeftab720\partightenfactor0

\f1\b \cf2 \cb3 **\uc0\u21709 \u24212 \u21442 \u25968 **
\f0\b0 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 | \uc0\u21442 \u25968 \u21517  | \u31867 \u22411  | \u35828 \u26126  |\cb1 \
\cb3 |-------|------|------|\cb1 \
\cb3 | code | Integer | \uc0\u21709 \u24212 \u30721 \u65292 200\u25104 \u21151  |\cb1 \
\cb3 | message | String | \uc0\u21709 \u24212 \u28040 \u24687  |\cb1 \
\cb3 | data | Object | \uc0\u21709 \u24212 \u25968 \u25454  |\cb1 \
\
\pard\pardeftab720\partightenfactor0

\f1\b \cf2 \cb3 **\uc0\u21709 \u24212 \u31034 \u20363 **
\f0\b0 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 ```json\cf2 \cb1 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \{\cb1 \
\cb3   "code": 200,\cb1 \
\cb3   "message": "\uc0\u21457 \u36865 \u25104 \u21151 ",\cb1 \
\cb3   "data": \{\cb1 \
\cb3     "expire_in": 300,\cb1 \
\cb3     "cooldown": 60\cb1 \
\cb3   \}\cb1 \
\cb3 \}\cb1 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 ```\cf2 \cb1 \strokec2 \
\
\pard\pardeftab720\partightenfactor0

\f1\b \cf2 \cb3 **\uc0\u38169 \u35823 \u30721 **
\f0\b0 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 | \uc0\u38169 \u35823 \u30721  | \u35828 \u26126  |\cb1 \
\cb3 |-------|------|\cb1 \
\cb3 | 10001 | \uc0\u25163 \u26426 \u21495 \u26684 \u24335 \u38169 \u35823  |\cb1 \
\cb3 | 10002 | \uc0\u21457 \u36865 \u36807 \u20110 \u39057 \u32321  |\cb1 \
\cb3 | 10003 | \uc0\u25163 \u26426 \u21495 \u34987 \u38480 \u21046  |\cb1 \
\
\cb3 ---\cb1 \
\
\cb3 #### API-002 \uc0\u39564 \u35777 \u30721 \u30331 \u24405 \cb1 \
\
\pard\pardeftab720\partightenfactor0

\f1\b \cf2 \cb3 **\uc0\u22522 \u26412 \u20449 \u24687 **
\f0\b0 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 - 
\f1\b **\uc0\u25509 \u21475 \u22320 \u22336 **
\f0\b0 \uc0\u65306 \cf5 \strokec5 `POST /api/v1/auth/login/sms`\cf2 \cb1 \strokec2 \
\cb3 - 
\f1\b **\uc0\u21151 \u33021 \u35828 \u26126 **
\f0\b0 \uc0\u65306 \u36890 \u36807 \u25163 \u26426 \u21495 \u21644 \u39564 \u35777 \u30721 \u30331 \u24405 \cb1 \
\cb3 - 
\f1\b **\uc0\u35843 \u29992 \u26041 **
\f0\b0 \uc0\u65306 App\u23458 \u25143 \u31471 \cb1 \
\
\pard\pardeftab720\partightenfactor0

\f1\b \cf2 \cb3 **\uc0\u35831 \u27714 \u21442 \u25968 **
\f0\b0 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 | \uc0\u21442 \u25968 \u21517  | \u31867 \u22411  | \u24517 \u22635  | \u35828 \u26126  | \u31034 \u20363 \u20540  |\cb1 \
\cb3 |-------|------|-----|------|-------|\cb1 \
\cb3 | phone | String | \uc0\u26159  | \u25163 \u26426 \u21495  | 13800138000 |\cb1 \
\cb3 | code | String | \uc0\u26159  | \u39564 \u35777 \u30721 \u65292 6\u20301  | 123456 |\cb1 \
\cb3 | device_id | String | \uc0\u21542  | \u35774 \u22791 ID | abc123 |\cb1 \
\
\pard\pardeftab720\partightenfactor0

\f1\b \cf2 \cb3 **\uc0\u21709 \u24212 \u31034 \u20363 **
\f0\b0 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 ```json\cf2 \cb1 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \{\cb1 \
\cb3   "code": 200,\cb1 \
\cb3   "message": "\uc0\u30331 \u24405 \u25104 \u21151 ",\cb1 \
\cb3   "data": \{\cb1 \
\cb3     "user_id": "10001",\cb1 \
\cb3     "nickname": "\uc0\u29992 \u25143 xxx",\cb1 \
\cb3     "avatar": "https://xxx.com/avatar.jpg",\cb1 \
\cb3     "token": "eyJhbGciOiJIUzI1NiIs...",\cb1 \
\cb3     "refresh_token": "eyJhbGciOiJIUzI1NiIs...",\cb1 \
\cb3     "expire_in": 604800\cb1 \
\cb3   \}\cb1 \
\cb3 \}\cb1 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 ```\cf2 \cb1 \strokec2 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 ---\cb1 \
\
\cb3 ## \uc0\u21313 \u12289 \u24322 \u24120 \u19982 \u36793 \u30028 \u22788 \u29702 \cb1 \
\
\cb3 ### 10.1 \uc0\u24322 \u24120 \u22330 \u26223 \u22788 \u29702 \cb1 \
\cb3 | \uc0\u38169 \u35823 \u30721  | \u24322 \u24120 \u31867 \u22411  | \u35302 \u21457 \u22330 \u26223  | \u29992 \u25143 \u25552 \u31034  | \u22788 \u29702 \u26041 \u26696  |\cb1 \
\cb3 |-------|---------|---------|---------|---------|\cb1 \
\cb3 | E001 | \uc0\u21442 \u25968 \u38169 \u35823  | \u25163 \u26426 \u21495 \u26684 \u24335 \u19981 \u23545  | \u35831 \u36755 \u20837 \u27491 \u30830 \u30340 \u25163 \u26426 \u21495  | \u21069 \u31471 \u25318 \u25130 +\u21518 \u31471 \u26657 \u39564  |\cb1 \
\cb3 | E002 | \uc0\u39564 \u35777 \u30721 \u38169 \u35823  | \u39564 \u35777 \u30721 \u19981 \u21305 \u37197  | \u39564 \u35777 \u30721 \u38169 \u35823 \u65292 \u35831 \u37325 \u26032 \u36755 \u20837  | \u35760 \u24405 \u38169 \u35823 \u27425 \u25968  |\cb1 \
\cb3 | E003 | \uc0\u39564 \u35777 \u30721 \u36807 \u26399  | \u36229 \u36807 5\u20998 \u38047  | \u39564 \u35777 \u30721 \u24050 \u36807 \u26399 \u65292 \u35831 \u37325 \u26032 \u33719 \u21462  | \u38656 \u37325 \u26032 \u33719 \u21462 \u39564 \u35777 \u30721  |\cb1 \
\cb3 | E004 | \uc0\u27425 \u25968 \u36229 \u38480  | \u38169 \u35823 \u36229 5\u27425  | \u39564 \u35777 \u30721 \u38169 \u35823 \u27425 \u25968 \u36807 \u22810  | \u38145 \u23450 5\u20998 \u38047  |\cb1 \
\cb3 | E005 | \uc0\u25163 \u26426 \u21495 \u23553 \u31105  | \u39118 \u25511 \u40657 \u21517 \u21333  | \u36134 \u21495 \u24322 \u24120 \u65292 \u35831 \u32852 \u31995 \u23458 \u26381  | \u24341 \u23548 \u23458 \u26381  |\cb1 \
\
\cb3 ### 10.2 \uc0\u36793 \u30028 \u26465 \u20214 \cb1 \
\cb3 | \uc0\u36793 \u30028 \u22330 \u26223  | \u38480 \u21046 \u26465 \u20214  | \u22788 \u29702 \u26041 \u24335  |\cb1 \
\cb3 |---------|---------|---------|\cb1 \
\cb3 | \uc0\u25163 \u26426 \u21495 \u38271 \u24230  | \u22266 \u23450 11\u20301  | \u36229 \u20986 \u33258 \u21160 \u25130 \u26029  |\cb1 \
\cb3 | \uc0\u39564 \u35777 \u30721 \u38271 \u24230  | \u22266 \u23450 6\u20301  | \u36229 \u20986 \u33258 \u21160 \u25130 \u26029  |\cb1 \
\cb3 | \uc0\u39564 \u35777 \u30721 \u38169 \u35823 \u27425 \u25968  | \u26368 \u22810 5\u27425  | \u36229 \u20986 \u38145 \u23450 5\u20998 \u38047  |\cb1 \
\cb3 | \uc0\u21333 \u26085 \u21457 \u36865 \u27425 \u25968  | \u21516 \u21495 \u30721 \u26368 \u22810 10\u26465  | \u36229 \u20986 \u25552 \u31034 \u27425 \u26085 \u20877 \u35797  |\cb1 \
\cb3 | Token\uc0\u26377 \u25928 \u26399  | 7\u22825  | \u36807 \u26399 \u33258 \u21160 \u21047 \u26032 \u25110 \u37325 \u26032 \u30331 \u24405  |\cb1 \
\
\cb3 ### 10.3 \uc0\u38477 \u32423 \u26041 \u26696 \cb1 \
\cb3 | \uc0\u22330 \u26223  | \u35302 \u21457 \u26465 \u20214  | \u38477 \u32423 \u31574 \u30053  |\cb1 \
\cb3 |-----|---------|---------|\cb1 \
\cb3 | \uc0\u30701 \u20449 \u26381 \u21153 \u19981 \u21487 \u29992  | \u30701 \u20449 \u32593 \u20851 \u36229 \u26102  | \u25552 \u31034 \u31245 \u21518 \u37325 \u35797 \u65292 \u35760 \u24405 \u26085 \u24535 \u21578 \u35686  |\cb1 \
\cb3 | Token\uc0\u26381 \u21153 \u19981 \u21487 \u29992  | Redis\u19981 \u21487 \u29992  | \u20020 \u26102 \u20351 \u29992 JWT\u26080 \u29366 \u24577 Token |\cb1 \
\cb3 | \uc0\u39564 \u35777 \u30721 \u26381 \u21153 \u19981 \u21487 \u29992  | \u39564 \u35777 \u30721 \u26381 \u21153 \u36229 \u26102  | \u38477 \u32423 \u20026 \u23494 \u30721 \u30331 \u24405  |\cb1 \
\
\cb3 ---\cb1 \
\
\cb3 ## \uc0\u21313 \u19968 \u12289 \u25968 \u25454 \u22475 \u28857 \cb1 \
\
\cb3 ### 11.1 \uc0\u22475 \u28857 \u28165 \u21333 \cb1 \
\cb3 | \uc0\u20107 \u20214 \u32534 \u21495  | \u20107 \u20214 \u21517 \u31216  | \u20107 \u20214 \u31867 \u22411  | \u35302 \u21457 \u26102 \u26426  | \u20248 \u20808 \u32423  |\cb1 \
\cb3 |---------|---------|---------|---------|-------|\cb1 \
\cb3 | EVT001 | login_page_view | \uc0\u26333 \u20809  | \u30331 \u24405 \u39029 \u26333 \u20809  | P0 |\cb1 \
\cb3 | EVT002 | login_tab_click | \uc0\u28857 \u20987  | \u20999 \u25442 \u30331 \u24405 \u26041 \u24335 Tab | P1 |\cb1 \
\cb3 | EVT003 | sms_code_click | \uc0\u28857 \u20987  | \u28857 \u20987 \u33719 \u21462 \u39564 \u35777 \u30721  | P0 |\cb1 \
\cb3 | EVT004 | login_submit_click | \uc0\u28857 \u20987  | \u28857 \u20987 \u30331 \u24405 \u25353 \u38062  | P0 |\cb1 \
\cb3 | EVT005 | login_success | \uc0\u33258 \u23450 \u20041  | \u30331 \u24405 \u25104 \u21151  | P0 |\cb1 \
\cb3 | EVT006 | login_fail | \uc0\u33258 \u23450 \u20041  | \u30331 \u24405 \u22833 \u36133  | P0 |\cb1 \
\cb3 | EVT007 | third_party_click | \uc0\u28857 \u20987  | \u28857 \u20987 \u31532 \u19977 \u26041 \u30331 \u24405  | P1 |\cb1 \
\
\cb3 ### 11.2 \uc0\u22475 \u28857 \u35814 \u32454 \u35774 \u35745 \cb1 \
\
\cb3 #### EVT005 - \uc0\u30331 \u24405 \u25104 \u21151 \cb1 \
\cb3 - 
\f1\b **\uc0\u20107 \u20214 \u35828 \u26126 **
\f0\b0 \uc0\u65306 \u29992 \u25143 \u25104 \u21151 \u23436 \u25104 \u30331 \u24405 \cb1 \
\cb3 - 
\f1\b **\uc0\u35302 \u21457 \u26465 \u20214 **
\f0\b0 \uc0\u65306 \u21518 \u31471 \u36820 \u22238 \u30331 \u24405 \u25104 \u21151 \cb1 \
\cb3 - 
\f1\b **\uc0\u19978 \u25253 \u26102 \u26426 **
\f0\b0 \uc0\u65306 \u31435 \u21363 \u19978 \u25253 \cb1 \
\
\pard\pardeftab720\partightenfactor0

\f1\b \cf2 \cb3 **\uc0\u20107 \u20214 \u21442 \u25968 **
\f0\b0 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 | \uc0\u21442 \u25968 \u21517  | \u31867 \u22411  | \u24517 \u20256  | \u35828 \u26126  | \u21462 \u20540 \u33539 \u22260  |\cb1 \
\cb3 |-------|------|-----|------|---------|\cb1 \
\cb3 | login_type | String | \uc0\u26159  | \u30331 \u24405 \u26041 \u24335  | sms/password/wechat/apple |\cb1 \
\cb3 | user_id | String | \uc0\u26159  | \u29992 \u25143 ID | \u25968 \u23383 \u23383 \u31526 \u20018  |\cb1 \
\cb3 | is_new_user | Boolean | \uc0\u26159  | \u26159 \u21542 \u26032 \u29992 \u25143  | true/false |\cb1 \
\cb3 | device_id | String | \uc0\u26159  | \u35774 \u22791 ID | \u35774 \u22791 \u21807 \u19968 \u26631 \u35782  |\cb1 \
\cb3 | login_time | Long | \uc0\u26159  | \u30331 \u24405 \u26102 \u38388 \u25139  | \u27627 \u31186 \u26102 \u38388 \u25139  |\cb1 \
\cb3 | login_cost | Integer | \uc0\u26159  | \u30331 \u24405 \u32791 \u26102  | \u27627 \u31186  |\cb1 \
\
\pard\pardeftab720\partightenfactor0

\f1\b \cf2 \cb3 **\uc0\u19978 \u25253 \u31034 \u20363 **
\f0\b0 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 ```json\cf2 \cb1 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \{\cb1 \
\cb3   "event": "login_success",\cb1 \
\cb3   "params": \{\cb1 \
\cb3     "login_type": "sms",\cb1 \
\cb3     "user_id": "10001",\cb1 \
\cb3     "is_new_user": false,\cb1 \
\cb3     "device_id": "abc123",\cb1 \
\cb3     "login_time": 1705286400000,\cb1 \
\cb3     "login_cost": 3500\cb1 \
\cb3   \}\cb1 \
\cb3 \}\cb1 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 ```\cf2 \cb1 \strokec2 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 ### 11.3 \uc0\u26680 \u24515 \u25351 \u26631 \cb1 \
\cb3 | \uc0\u25351 \u26631 \u21517 \u31216  | \u35745 \u31639 \u20844 \u24335  | \u25968 \u25454 \u26469 \u28304  | \u35828 \u26126  |\cb1 \
\cb3 |---------|---------|---------|------|\cb1 \
\cb3 | \uc0\u30331 \u24405 \u36716 \u21270 \u29575  | \u30331 \u24405 \u25104 \u21151 \u25968 /\u30331 \u24405 \u39029 \u35775 \u38382 \u25968  | \u22475 \u28857 \u25968 \u25454  | \u34913 \u37327 \u30331 \u24405 \u27969 \u31243 \u25928 \u29575  |\cb1 \
\cb3 | \uc0\u39564 \u35777 \u30721 \u21457 \u36865 \u25104 \u21151 \u29575  | \u21457 \u36865 \u25104 \u21151 \u25968 /\u21457 \u36865 \u35831 \u27714 \u25968  | \u25509 \u21475 \u26085 \u24535  | \u34913 \u37327 \u30701 \u20449 \u26381 \u21153 \u31283 \u23450 \u24615  |\cb1 \
\cb3 | \uc0\u30331 \u24405 \u24179 \u22343 \u32791 \u26102  | avg(login_cost) | \u22475 \u28857 \u25968 \u25454  | \u34913 \u37327 \u29992 \u25143 \u20307 \u39564  |\cb1 \
\cb3 | \uc0\u26032 \u29992 \u25143 \u27880 \u20876 \u29575  | \u26032 \u29992 \u25143 \u25968 /\u30331 \u24405 \u25104 \u21151 \u25968  | \u22475 \u28857 \u25968 \u25454  | \u34913 \u37327 \u29992 \u25143 \u22686 \u38271  |\cb1 \
\
\cb3 ---\cb1 \
\
\cb3 ## \uc0\u21464 \u26356 \u35760 \u24405 \cb1 \
\
\cb3 | \uc0\u29256 \u26412  | \u26085 \u26399  | \u20462 \u25913 \u20154  | \u20462 \u25913 \u20869 \u23481  |\cb1 \
\cb3 |-----|------|-------|---------|\cb1 \
\cb3 | v1.0 | 2024-01-15 | \uc0\u24352 \u19977  | \u21021 \u29256 \u21019 \u24314  |\cb1 \
\
}