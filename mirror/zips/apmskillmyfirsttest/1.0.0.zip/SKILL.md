{\rtf1\ansi\ansicpg936\cocoartf2821
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fnil\fcharset0 Menlo-Regular;\f1\fnil\fcharset0 Menlo-Bold;}
{\colortbl;\red255\green255\blue255;\red45\green45\blue45;\red255\green255\blue255;\red144\green1\blue18;
\red135\green44\blue160;}
{\*\expandedcolortbl;;\cssrgb\c23137\c23137\c23137;\cssrgb\c100000\c100000\c100000;\cssrgb\c63922\c8235\c8235;
\cssrgb\c60784\c27451\c69020;}
\paperw11900\paperh16840\margl1440\margr1440\vieww10440\viewh19380\viewkind0
\deftab720
\pard\pardeftab720\partightenfactor0

\f0\fs26 \cf2 \cb3 \expnd0\expndtw0\kerning0
\outl0\strokewidth0 \strokec2 ---\cb1 \
\cb3 name: product-doc-writer\cb1 \
\cb3 description: \uc0\u20135 \u21697 \u38656 \u27714 \u25991 \u26723 (PRD)\u33258 \u21160 \u29983 \u25104 \u24037 \u20855 \u12290 \u20174 \u36164 \u28145 \u20135 \u21697 \u32463 \u29702 \u35270 \u35282 \u20986 \u21457 \u65292 \u29983 \u25104 \u35268 \u33539 \u23436 \u25972 \u30340 \u20135 \u21697 \u38656 \u27714 \u25991 \u26723 \u12290 \u36866 \u29992 \u22330 \u26223 \u65306 \u29992 \u25143 \u38656 \u35201 \u25776 \u20889 \u20135 \u21697 \u38656 \u27714 \u25991 \u26723 \u12289 \u21151 \u33021 \u35268 \u21010 \u25991 \u26723 \u12289 \u38656 \u27714 \u20998 \u26512 \u25991 \u26723 \u26102 \u12290 \u35302 \u21457 \u35789 \u65306 \u20135 \u21697 \u25991 \u26723 \u12289 PRD\u12289 \u38656 \u27714 \u25991 \u26723 \u12289 \u21151 \u33021 \u35774 \u35745 \u25991 \u26723 \u12289 \u20135 \u21697 \u35268 \u21010 \u25991 \u26723 \u12290 \cb1 \
\cb3 ---\cb1 \
\
\cb3 # Product Doc Writer - \uc0\u20135 \u21697 \u38656 \u27714 \u25991 \u26723 \u29983 \u25104 \u22120 \cb1 \
\
\cb3 ## \uc0\u27010 \u36848 \cb1 \
\
\cb3 \uc0\u26412 skill\u24110 \u21161 \u29992 \u25143 \u20174 \u36164 \u28145 \u20135 \u21697 \u32463 \u29702 \u30340 \u35282 \u24230 \u65292 \u33258 \u21160 \u29983 \u25104 \u19987 \u19994 \u12289 \u35268 \u33539 \u30340 \u20135 \u21697 \u38656 \u27714 \u25991 \u26723 (PRD)\u12290 \u25991 \u26723 \u28085 \u30422 \u20174 \u38656 \u27714 \u32972 \u26223 \u21040 \u25968 \u25454 \u22475 \u28857 \u30340 \u23436 \u25972 \u20869 \u23481 \u65292 \u30830 \u20445 \u20135 \u21697 \u35774 \u35745 \u30340 \u20840 \u38754 \u24615 \u21644 \u21487 \u33853 \u22320 \u24615 \u12290 \cb1 \
\
\cb3 ## \uc0\u25991 \u26723 \u29983 \u25104 \u27969 \u31243 \cb1 \
\
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 ```\cf2 \cb1 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf5 \cb3 \strokec5 \uc0\u29992 \u25143 \u36755 \u20837 \u38656 \u27714  \u8594  \u20449 \u24687 \u28548 \u28165 (\u21487 \u36873 ) \u8594  \u32467 \u26500 \u21270 \u20998 \u26512  \u8594  \u29983 \u25104 \u23436 \u25972 \u25991 \u26723  \u8594  \u29992 \u25143 \u30830 \u35748 \u35843 \u25972 \cf2 \cb1 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 ```\cf2 \cb1 \strokec2 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 ### \uc0\u27493 \u39588 \u19968 \u65306 \u20449 \u24687 \u25910 \u38598 \u19982 \u28548 \u28165 \cb1 \
\
\cb3 \uc0\u22312 \u29983 \u25104 \u25991 \u26723 \u21069 \u65292 \u38656 \u35201 \u21521 \u29992 \u25143 \u30830 \u35748 \u20197 \u19979 \u20851 \u38190 \u20449 \u24687 \u65288 \u22914 \u26377 \u19981 \u26126 \u65289 \u65306 \cb1 \
\
\cb3 | \uc0\u24517 \u35201 \u20449 \u24687  | \u35828 \u26126  |\cb1 \
\cb3 |---------|------|\cb1 \
\cb3 | \uc0\u20135 \u21697 /\u21151 \u33021 \u21517 \u31216  | \u38656 \u35201 \u25991 \u26723 \u21270 \u30340 \u20855 \u20307 \u20135 \u21697 \u25110 \u21151 \u33021  |\cb1 \
\cb3 | \uc0\u19994 \u21153 \u39046 \u22495  | \u25152 \u23646 \u34892 \u19994 \u21644 \u19994 \u21153 \u31867 \u22411  |\cb1 \
\cb3 | \uc0\u30446 \u26631 \u29992 \u25143  | \u20027 \u35201 \u26381 \u21153 \u23545 \u35937 \u26159 \u35841  |\cb1 \
\cb3 | \uc0\u26680 \u24515 \u30171 \u28857  | \u38656 \u35201 \u35299 \u20915 \u30340 \u20027 \u35201 \u38382 \u39064  |\cb1 \
\
\cb3 ### \uc0\u27493 \u39588 \u20108 \u65306 \u29983 \u25104 \u25991 \u26723 \u32467 \u26500 \cb1 \
\
\cb3 \uc0\u25353 \u29031 \u20197 \u19979 \u26631 \u20934 \u32467 \u26500 \u29983 \u25104 \u20135 \u21697 \u38656 \u27714 \u25991 \u26723 \u65306 \cb1 \
\
\cb3 ---\cb1 \
\
\cb3 ## \uc0\u25991 \u26723 \u27169 \u26495 \cb1 \
\
\cb3 ### \uc0\u19968 \u12289 \u38656 \u27714 \u32972 \u26223 \cb1 \
\
\pard\pardeftab720\partightenfactor0

\f1\b \cf2 \cb3 **\uc0\u32534 \u20889 \u35201 \u28857 \u65306 **
\f0\b0 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 - \uc0\u35828 \u26126 \u24403 \u21069 \u19994 \u21153 \u29616 \u29366 \u21644 \u23384 \u22312 \u30340 \u38382 \u39064 \cb1 \
\cb3 - \uc0\u20998 \u26512 \u24066 \u22330 \u36235 \u21183 \u21644 \u31454 \u21697 \u24773 \u20917 \cb1 \
\cb3 - \uc0\u38416 \u36848 \u38656 \u27714 \u26469 \u28304 \u21644 \u39537 \u21160 \u21147 \cb1 \
\cb3 - \uc0\u26126 \u30830 \u35299 \u20915 \u30340 \u24517 \u35201 \u24615 \u21644 \u32039 \u36843 \u24615 \cb1 \
\
\pard\pardeftab720\partightenfactor0

\f1\b \cf2 \cb3 **\uc0\u27169 \u26495 \u32467 \u26500 \u65306 **
\f0\b0 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 ```markdown\cf2 \cb1 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 ## \uc0\u19968 \u12289 \u38656 \u27714 \u32972 \u26223 \cb1 \
\
\cb3 ### 1.1 \uc0\u19994 \u21153 \u29616 \u29366 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 [\uc0\u25551 \u36848 \u24403 \u21069 \u19994 \u21153 \u36816 \u20316 \u26041 \u24335 \u12289 \u23384 \u22312 \u30340 \u38382 \u39064 \u21644 \u30171 \u28857 ]\cf2 \cb1 \strokec2 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 ### 1.2 \uc0\u24066 \u22330 \u20998 \u26512 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 [\uc0\u34892 \u19994 \u36235 \u21183 \u12289 \u31454 \u21697 \u20998 \u26512 \u12289 \u24066 \u22330 \u26426 \u20250 ]\cf2 \cb1 \strokec2 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 ### 1.3 \uc0\u38656 \u27714 \u26469 \u28304 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 [\uc0\u38656 \u27714 \u25552 \u20986 \u26041 \u12289 \u25552 \u20986 \u26102 \u38388 \u12289 \u38656 \u27714 \u32534 \u21495 ]\cf2 \cb1 \strokec2 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 ### 1.4 \uc0\u38382 \u39064 \u23450 \u20041 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 [\uc0\u26680 \u24515 \u38382 \u39064 \u38472 \u36848 \u65292 \u29992 \u25968 \u25454 \u25903 \u25745 ]\cf2 \cb1 \strokec2 \
\cf4 \cb3 \strokec4 ```\cf2 \cb1 \strokec2 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 ---\cb1 \
\
\cb3 ### \uc0\u20108 \u12289 \u25968 \u25454 \u26550 \u26500 \u35828 \u26126 \cb1 \
\
\pard\pardeftab720\partightenfactor0

\f1\b \cf2 \cb3 **\uc0\u32534 \u20889 \u35201 \u28857 \u65306 **
\f0\b0 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 - \uc0\u25551 \u36848 \u28041 \u21450 \u30340 \u25968 \u25454 \u23454 \u20307 \u21450 \u20854 \u20851 \u31995 \cb1 \
\cb3 - \uc0\u35828 \u26126 \u25968 \u25454 \u27969 \u36716 \u21644 \u23384 \u20648 \u26041 \u24335 \cb1 \
\cb3 - \uc0\u26631 \u27880 \u25935 \u24863 \u25968 \u25454 \u21644 \u25968 \u25454 \u23433 \u20840 \u35201 \u27714 \cb1 \
\
\pard\pardeftab720\partightenfactor0

\f1\b \cf2 \cb3 **\uc0\u27169 \u26495 \u32467 \u26500 \u65306 **
\f0\b0 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 ```markdown\cf2 \cb1 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 ## \uc0\u20108 \u12289 \u25968 \u25454 \u26550 \u26500 \u35828 \u26126 \cb1 \
\
\cb3 ### 2.1 \uc0\u26680 \u24515 \u25968 \u25454 \u23454 \u20307 \cb1 \
\cb3 | \uc0\u23454 \u20307 \u21517 \u31216  | \u35828 \u26126  | \u20851 \u38190 \u23383 \u27573  |\cb1 \
\cb3 |---------|------|---------|\cb1 \
\cb3 | \cf4 \strokec4 [\uc0\u23454 \u20307 1]\cf2 \strokec2  | \cf4 \strokec4 [\uc0\u25551 \u36848 ]\cf2 \strokec2  | \cf4 \strokec4 [\uc0\u23383 \u27573 \u21015 \u34920 ]\cf2 \strokec2  |\cb1 \
\
\cb3 ### 2.2 \uc0\u25968 \u25454 \u27969 \u36716 \u22270 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 [\uc0\u25551 \u36848 \u25968 \u25454 \u22312 \u21508 \u31995 \u32479 \u38388 \u30340 \u27969 \u36716 \u36335 \u24452 ]\cf2 \cb1 \strokec2 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 ### 2.3 \uc0\u25968 \u25454 \u23384 \u20648 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 [\uc0\u25968 \u25454 \u23384 \u20648 \u26041 \u26696 \u12289 \u23384 \u20648 \u21608 \u26399 \u12289 \u24402 \u26723 \u31574 \u30053 ]\cf2 \cb1 \strokec2 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 ### 2.4 \uc0\u25968 \u25454 \u23433 \u20840 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 [\uc0\u25935 \u24863 \u25968 \u25454 \u35782 \u21035 \u12289 \u21152 \u23494 \u35201 \u27714 \u12289 \u26435 \u38480 \u25511 \u21046 ]\cf2 \cb1 \strokec2 \
\cf4 \cb3 \strokec4 ```\cf2 \cb1 \strokec2 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 ---\cb1 \
\
\cb3 ### \uc0\u19977 \u12289 \u38656 \u27714 \u30446 \u26631 \cb1 \
\
\pard\pardeftab720\partightenfactor0

\f1\b \cf2 \cb3 **\uc0\u32534 \u20889 \u35201 \u28857 \u65306 **
\f0\b0 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 - \uc0\u21306 \u20998 \u19994 \u21153 \u30446 \u26631 \u21644 \u20135 \u21697 \u30446 \u26631 \cb1 \
\cb3 - \uc0\u30446 \u26631 \u38656 SMART\u21270 \u65288 \u20855 \u20307 \u12289 \u21487 \u34913 \u37327 \u12289 \u21487 \u36798 \u25104 \u12289 \u30456 \u20851 \u12289 \u26377 \u26102 \u38480 \u65289 \cb1 \
\cb3 - \uc0\u35774 \u23450 \u26680 \u24515 \u25351 \u26631 \u21644 \u21271 \u26497 \u26143 \u25351 \u26631 \cb1 \
\
\pard\pardeftab720\partightenfactor0

\f1\b \cf2 \cb3 **\uc0\u27169 \u26495 \u32467 \u26500 \u65306 **
\f0\b0 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 ```markdown\cf2 \cb1 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 ## \uc0\u19977 \u12289 \u38656 \u27714 \u30446 \u26631 \cb1 \
\
\cb3 ### 3.1 \uc0\u19994 \u21153 \u30446 \u26631 \cb1 \
\cb3 | \uc0\u30446 \u26631 \u31867 \u22411  | \u30446 \u26631 \u25551 \u36848  | \u34913 \u37327 \u25351 \u26631  | \u30446 \u26631 \u20540  |\cb1 \
\cb3 |---------|---------|---------|-------|\cb1 \
\cb3 | \uc0\u26680 \u24515 \u30446 \u26631  | \cf4 \strokec4 [\uc0\u25551 \u36848 ]\cf2 \strokec2  | \cf4 \strokec4 [KPI]\cf2 \strokec2  | \cf4 \strokec4 [\uc0\u25968 \u20540 ]\cf2 \strokec2  |\cb1 \
\
\cb3 ### 3.2 \uc0\u20135 \u21697 \u30446 \u26631 \cb1 \
\cb3 - 
\f1\b **\uc0\u20307 \u39564 \u30446 \u26631 **
\f0\b0 \uc0\u65306 \cf4 \strokec4 [\uc0\u29992 \u25143 \u20307 \u39564 \u25913 \u21892 \u30446 \u26631 ]\cf2 \cb1 \strokec2 \
\cb3 - 
\f1\b **\uc0\u25928 \u29575 \u30446 \u26631 **
\f0\b0 \uc0\u65306 \cf4 \strokec4 [\uc0\u36816 \u33829 \u25928 \u29575 \u25552 \u21319 \u30446 \u26631 ]\cf2 \cb1 \strokec2 \
\cb3 - 
\f1\b **\uc0\u36136 \u37327 \u30446 \u26631 **
\f0\b0 \uc0\u65306 \cf4 \strokec4 [\uc0\u20135 \u21697 \u31283 \u23450 \u24615 \u30446 \u26631 ]\cf2 \cb1 \strokec2 \
\
\cb3 ### 3.3 \uc0\u25104 \u21151 \u26631 \u20934 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 [\uc0\u23450 \u20041 \u38656 \u27714 \u36798 \u25104 \u30340 \u39564 \u25910 \u26631 \u20934 ]\cf2 \cb1 \strokec2 \
\cf4 \cb3 \strokec4 ```\cf2 \cb1 \strokec2 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 ---\cb1 \
\
\cb3 ### \uc0\u22235 \u12289 \u29992 \u25143 \u19982 \u20351 \u29992 \u22330 \u26223 \cb1 \
\
\pard\pardeftab720\partightenfactor0

\f1\b \cf2 \cb3 **\uc0\u32534 \u20889 \u35201 \u28857 \u65306 **
\f0\b0 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 - \uc0\u23450 \u20041 \u29992 \u25143 \u30011 \u20687 \u21644 \u29992 \u25143 \u35282 \u33394 \cb1 \
\cb3 - \uc0\u25551 \u36848 \u20856 \u22411 \u20351 \u29992 \u22330 \u26223 \u21644 \u29992 \u25143 \u26053 \u31243 \cb1 \
\cb3 - \uc0\u20998 \u26512 \u29992 \u25143 \u34892 \u20026 \u36335 \u24452 \u21644 \u20915 \u31574 \u28857 \cb1 \
\
\pard\pardeftab720\partightenfactor0

\f1\b \cf2 \cb3 **\uc0\u27169 \u26495 \u32467 \u26500 \u65306 **
\f0\b0 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 ```markdown\cf2 \cb1 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 ## \uc0\u22235 \u12289 \u29992 \u25143 \u19982 \u20351 \u29992 \u22330 \u26223 \cb1 \
\
\cb3 ### 4.1 \uc0\u29992 \u25143 \u30011 \u20687 \cb1 \
\cb3 | \uc0\u32500 \u24230  | \u25551 \u36848  |\cb1 \
\cb3 |-----|------|\cb1 \
\cb3 | \uc0\u30446 \u26631 \u29992 \u25143  | \cf4 \strokec4 [\uc0\u29992 \u25143 \u32676 \u20307 \u25551 \u36848 ]\cf2 \strokec2  |\cb1 \
\cb3 | \uc0\u29992 \u25143 \u29305 \u24449  | \cf4 \strokec4 [\uc0\u24180 \u40836 \u12289 \u32844 \u19994 \u12289 \u20064 \u24815 \u31561 ]\cf2 \strokec2  |\cb1 \
\cb3 | \uc0\u26680 \u24515 \u38656 \u27714  | \cf4 \strokec4 [\uc0\u20027 \u35201 \u38656 \u27714 \u28857 ]\cf2 \strokec2  |\cb1 \
\
\cb3 ### 4.2 \uc0\u29992 \u25143 \u35282 \u33394 \u30697 \u38453 \cb1 \
\cb3 | \uc0\u35282 \u33394  | \u32844 \u36131  | \u26435 \u38480 \u33539 \u22260  | \u20351 \u29992 \u39057 \u29575  |\cb1 \
\cb3 |-----|------|---------|---------|\cb1 \
\cb3 | \cf4 \strokec4 [\uc0\u35282 \u33394 1]\cf2 \strokec2  | \cf4 \strokec4 [\uc0\u32844 \u36131 ]\cf2 \strokec2  | \cf4 \strokec4 [\uc0\u26435 \u38480 ]\cf2 \strokec2  | \cf4 \strokec4 [\uc0\u39057 \u29575 ]\cf2 \strokec2  |\cb1 \
\
\cb3 ### 4.3 \uc0\u20351 \u29992 \u22330 \u26223 \cb1 \
\cb3 #### \uc0\u22330 \u26223 \u19968 \u65306 [\u22330 \u26223 \u21517 \u31216 ]\cb1 \
\cb3 - 
\f1\b **\uc0\u35302 \u21457 \u26465 \u20214 **
\f0\b0 \uc0\u65306 \cf4 \strokec4 [\uc0\u20160 \u20040 \u24773 \u20917 \u19979 \u35302 \u21457 ]\cf2 \cb1 \strokec2 \
\cb3 - 
\f1\b **\uc0\u29992 \u25143 \u30446 \u26631 **
\f0\b0 \uc0\u65306 \cf4 \strokec4 [\uc0\u29992 \u25143 \u24819 \u35201 \u36798 \u25104 \u20160 \u20040 ]\cf2 \cb1 \strokec2 \
\cb3 - 
\f1\b **\uc0\u25805 \u20316 \u36335 \u24452 **
\f0\b0 \uc0\u65306 \cf4 \strokec4 [\uc0\u29992 \u25143 \u25805 \u20316 \u27493 \u39588 ]\cf2 \cb1 \strokec2 \
\cb3 - 
\f1\b **\uc0\u39044 \u26399 \u32467 \u26524 **
\f0\b0 \uc0\u65306 \cf4 \strokec4 [\uc0\u29992 \u25143 \u26399 \u26395 \u30340 \u32467 \u26524 ]\cf2 \cb1 \strokec2 \
\
\cb3 ### 4.4 \uc0\u29992 \u25143 \u26053 \u31243 \u22270 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 [\uc0\u25551 \u36848 \u29992 \u25143 \u20174 \u24320 \u22987 \u21040 \u23436 \u25104 \u20219 \u21153 \u30340 \u23436 \u25972 \u36335 \u24452 ]\cf2 \cb1 \strokec2 \
\cf4 \cb3 \strokec4 ```\cf2 \cb1 \strokec2 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 ---\cb1 \
\
\cb3 ### \uc0\u20116 \u12289 \u38656 \u27714 \u21151 \u33021 \u28165 \u21333 \cb1 \
\
\pard\pardeftab720\partightenfactor0

\f1\b \cf2 \cb3 **\uc0\u32534 \u20889 \u35201 \u28857 \u65306 **
\f0\b0 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 - \uc0\u25353 \u21151 \u33021 \u27169 \u22359 \u20998 \u32452 \u21015 \u20986 \cb1 \
\cb3 - \uc0\u26631 \u27880 \u20248 \u20808 \u32423 \u12289 \u29366 \u24577 \u12289 \u36127 \u36131 \u20154 \cb1 \
\cb3 - \uc0\u20351 \u29992 \u21151 \u33021 \u28857 \u25551 \u36848 \u32780 \u38750 \u35299 \u20915 \u26041 \u26696 \cb1 \
\
\pard\pardeftab720\partightenfactor0

\f1\b \cf2 \cb3 **\uc0\u27169 \u26495 \u32467 \u26500 \u65306 **
\f0\b0 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 ```markdown\cf2 \cb1 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 ## \uc0\u20116 \u12289 \u38656 \u27714 \u21151 \u33021 \u28165 \u21333 \cb1 \
\
\cb3 ### \uc0\u21151 \u33021 \u27010 \u35272 \u34920 \cb1 \
\cb3 | \uc0\u32534 \u21495  | \u27169 \u22359  | \u21151 \u33021 \u28857  | \u20248 \u20808 \u32423  | \u29366 \u24577  | \u36127 \u36131 \u20154  |\cb1 \
\cb3 |-----|------|-------|-------|------|-------|\cb1 \
\cb3 | F001 | \cf4 \strokec4 [\uc0\u27169 \u22359 \u21517 ]\cf2 \strokec2  | \cf4 \strokec4 [\uc0\u21151 \u33021 \u25551 \u36848 ]\cf2 \strokec2  | P0/P1/P2 | \uc0\u24453 \u24320 \u21457 /\u24320 \u21457 \u20013 /\u24050 \u23436 \u25104  | \cf4 \strokec4 [\uc0\u22995 \u21517 ]\cf2 \strokec2  |\cb1 \
\
\cb3 ### 5.1 [\uc0\u27169 \u22359 \u21517 \u31216 ]\cb1 \
\cb3 #### F001 - [\uc0\u21151 \u33021 \u21517 \u31216 ]\cb1 \
\cb3 - 
\f1\b **\uc0\u21151 \u33021 \u25551 \u36848 **
\f0\b0 \uc0\u65306 \cf4 \strokec4 [\uc0\u35814 \u32454 \u25551 \u36848 \u21151 \u33021 \u20869 \u23481 ]\cf2 \cb1 \strokec2 \
\cb3 - 
\f1\b **\uc0\u36755 \u20837 **
\f0\b0 \uc0\u65306 \cf4 \strokec4 [\uc0\u29992 \u25143 \u36755 \u20837 \u20160 \u20040 ]\cf2 \cb1 \strokec2 \
\cb3 - 
\f1\b **\uc0\u36755 \u20986 **
\f0\b0 \uc0\u65306 \cf4 \strokec4 [\uc0\u31995 \u32479 \u36820 \u22238 \u20160 \u20040 ]\cf2 \cb1 \strokec2 \
\cb3 - 
\f1\b **\uc0\u35268 \u21017 **
\f0\b0 \uc0\u65306 \cf4 \strokec4 [\uc0\u19994 \u21153 \u35268 \u21017 \u21644 \u38480 \u21046 ]\cf2 \cb1 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 ```\cf2 \cb1 \strokec2 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 ---\cb1 \
\
\cb3 ### \uc0\u20845 \u12289 \u35814 \u32454 \u26041 \u26696 \cb1 \
\
\pard\pardeftab720\partightenfactor0

\f1\b \cf2 \cb3 **\uc0\u32534 \u20889 \u35201 \u28857 \u65306 **
\f0\b0 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 - \uc0\u35814 \u32454 \u25551 \u36848 \u27599 \u20010 \u21151 \u33021 \u30340 \u23454 \u29616 \u36923 \u36753 \cb1 \
\cb3 - \uc0\u21253 \u21547 \u30028 \u38754 \u20132 \u20114 \u35828 \u26126 \cb1 \
\cb3 - \uc0\u35828 \u26126 \u29305 \u27530 \u22330 \u26223 \u22788 \u29702 \cb1 \
\
\pard\pardeftab720\partightenfactor0

\f1\b \cf2 \cb3 **\uc0\u27169 \u26495 \u32467 \u26500 \u65306 **
\f0\b0 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 ```markdown\cf2 \cb1 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 ## \uc0\u20845 \u12289 \u35814 \u32454 \u26041 \u26696 \cb1 \
\
\cb3 ### 6.1 [\uc0\u21151 \u33021 \u27169 \u22359 1]\u35814 \u32454 \u35774 \u35745 \cb1 \
\
\cb3 #### 6.1.1 \uc0\u21151 \u33021 \u20837 \u21475 \cb1 \
\cb3 - 
\f1\b **\uc0\u20837 \u21475 \u20301 \u32622 **
\f0\b0 \uc0\u65306 \cf4 \strokec4 [\uc0\u22312 \u21738 \u20010 \u39029 \u38754 \u12289 \u21738 \u20010 \u20301 \u32622 ]\cf2 \cb1 \strokec2 \
\cb3 - 
\f1\b **\uc0\u35302 \u21457 \u26041 \u24335 **
\f0\b0 \uc0\u65306 \cf4 \strokec4 [\uc0\u28857 \u20987 /\u25163 \u21183 /\u35821 \u38899 \u31561 ]\cf2 \cb1 \strokec2 \
\cb3 - 
\f1\b **\uc0\u21069 \u32622 \u26465 \u20214 **
\f0\b0 \uc0\u65306 \cf4 \strokec4 [\uc0\u38656 \u35201 \u28385 \u36275 \u20160 \u20040 \u26465 \u20214 ]\cf2 \cb1 \strokec2 \
\
\cb3 #### 6.1.2 \uc0\u20132 \u20114 \u36923 \u36753 \cb1 \
\cb3 1. \cf4 \strokec4 [\uc0\u31532 \u19968 \u27493 \u25805 \u20316 \u21450 \u21709 \u24212 ]\cf2 \cb1 \strokec2 \
\cb3 2. \cf4 \strokec4 [\uc0\u31532 \u20108 \u27493 \u25805 \u20316 \u21450 \u21709 \u24212 ]\cf2 \cb1 \strokec2 \
\cb3 ...\cb1 \
\
\cb3 #### 6.1.3 \uc0\u23637 \u31034 \u35268 \u21017 \cb1 \
\cb3 | \uc0\u23637 \u31034 \u39033  | \u35268 \u21017 \u35828 \u26126  |\cb1 \
\cb3 |-------|---------|\cb1 \
\cb3 | \cf4 \strokec4 [\uc0\u23383 \u27573 \u21517 ]\cf2 \strokec2  | \cf4 \strokec4 [\uc0\u23637 \u31034 \u35268 \u21017 ]\cf2 \strokec2  |\cb1 \
\
\cb3 #### 6.1.4 \uc0\u25805 \u20316 \u35268 \u21017 \cb1 \
\cb3 | \uc0\u25805 \u20316  | \u35268 \u21017 \u35828 \u26126  |\cb1 \
\cb3 |-----|---------|\cb1 \
\cb3 | \cf4 \strokec4 [\uc0\u25805 \u20316 \u21517 ]\cf2 \strokec2  | \cf4 \strokec4 [\uc0\u35268 \u21017 \u25551 \u36848 ]\cf2 \strokec2  |\cb1 \
\
\cb3 #### 6.1.5 \uc0\u36793 \u30028 \u24773 \u20917 \cb1 \
\cb3 - 
\f1\b **\uc0\u24773 \u20917 1**
\f0\b0 \uc0\u65306 \cf4 \strokec4 [\uc0\u25551 \u36848 ]\cf2 \strokec2  \uc0\u8594  
\f1\b **\uc0\u22788 \u29702 **
\f0\b0 \uc0\u65306 \cf4 \strokec4 [\uc0\u35299 \u20915 \u26041 \u26696 ]\cf2 \cb1 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 ```\cf2 \cb1 \strokec2 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 ---\cb1 \
\
\cb3 ### \uc0\u19971 \u12289 \u19994 \u21153 \u27969 \u31243 \u22270 \cb1 \
\
\pard\pardeftab720\partightenfactor0

\f1\b \cf2 \cb3 **\uc0\u32534 \u20889 \u35201 \u28857 \u65306 **
\f0\b0 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 - \uc0\u20351 \u29992 \u26631 \u20934 \u27969 \u31243 \u22270 \u31526 \u21495 \cb1 \
\cb3 - \uc0\u26631 \u27880 \u20851 \u38190 \u33410 \u28857 \u21644 \u20915 \u31574 \u28857 \cb1 \
\cb3 - \uc0\u21253 \u21547 \u27491 \u24120 \u27969 \u31243 \u21644 \u24322 \u24120 \u27969 \u31243 \cb1 \
\
\pard\pardeftab720\partightenfactor0

\f1\b \cf2 \cb3 **\uc0\u27969 \u31243 \u22270 \u35821 \u27861 \u65288 Mermaid\u65289 \u65306 **
\f0\b0 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 ```markdown\cf2 \cb1 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 ## \uc0\u19971 \u12289 \u19994 \u21153 \u27969 \u31243 \u22270 \cb1 \
\
\cb3 ### 7.1 \uc0\u20027 \u27969 \u31243 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 ```mermaid\cf2 \cb1 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 flowchart TD\cb1 \
\cb3     A[\uc0\u24320 \u22987 ] --> B[\u29992 \u25143 \u36827 \u20837 \u39029 \u38754 ]\cb1 \
\cb3     B --> C\{\uc0\u26159 \u21542 \u30331 \u24405 ?\}\cb1 \
\cb3     C -->|\uc0\u26159 | D[\u23637 \u31034 \u21151 \u33021 \u20837 \u21475 ]\cb1 \
\cb3     C -->|\uc0\u21542 | E[\u24341 \u23548 \u30331 \u24405 ]\cb1 \
\cb3     E --> D\cb1 \
\cb3     D --> F[\uc0\u29992 \u25143 \u25805 \u20316 ]\cb1 \
\cb3     F --> G\{\uc0\u25805 \u20316 \u26657 \u39564 \}\cb1 \
\cb3     G -->|\uc0\u36890 \u36807 | H[\u25191 \u34892 \u19994 \u21153 \u36923 \u36753 ]\cb1 \
\cb3     G -->|\uc0\u22833 \u36133 | I[\u25552 \u31034 \u38169 \u35823 \u20449 \u24687 ]\cb1 \
\cb3     H --> J[\uc0\u36820 \u22238 \u32467 \u26524 ]\cb1 \
\cb3     J --> K[\uc0\u32467 \u26463 ]\cb1 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 ```\cf2 \cb1 \strokec2 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 ### 7.2 \uc0\u24322 \u24120 \u27969 \u31243 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 [\uc0\u25551 \u36848 \u21508 \u31181 \u24322 \u24120 \u24773 \u20917 \u30340 \u22788 \u29702 \u27969 \u31243 ]\cf2 \cb1 \strokec2 \
\cf4 \cb3 \strokec4 ```\cf2 \cb1 \strokec2 \
\
\pard\pardeftab720\partightenfactor0
\cf5 \cb3 \strokec5 ---\cf2 \cb1 \strokec2 \
\
\cf5 \cb3 \strokec5 ### \uc0\u20843 \u12289 \u39640 \u20445 \u30495 \u21407 \u22411 \u22270 \cf2 \cb1 \strokec2 \
\
\cf5 \cb3 \strokec5 **\uc0\u32534 \u20889 \u35201 \u28857 \u65306 **\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 - \uc0\u25551 \u36848 \u20027 \u35201 \u39029 \u38754 \u24067 \u23616 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 - \uc0\u26631 \u27880 \u20132 \u20114 \u20803 \u32032 \u21644 \u29366 \u24577 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 - \uc0\u35828 \u26126 \u21709 \u24212 \u24335 \u36866 \u37197 \u35201 \u27714 \cf2 \cb1 \strokec2 \
\
\cf5 \cb3 \strokec5 **\uc0\u27169 \u26495 \u32467 \u26500 \u65306 **\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 ```markdown\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 ## \uc0\u20843 \u12289 \u39640 \u20445 \u30495 \u21407 \u22411 \u22270 \cf2 \cb1 \strokec2 \
\
\cf5 \cb3 \strokec5 ### 8.1 \uc0\u39029 \u38754 \u21015 \u34920 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 | \uc0\u39029 \u38754 \u32534 \u21495  | \u39029 \u38754 \u21517 \u31216  | \u21151 \u33021 \u25551 \u36848  | \u21407 \u22411 \u38142 \u25509  |\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 |---------|---------|---------|---------|\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 | P001 | [\uc0\u39029 \u38754 \u21517 ] | [\u25551 \u36848 ] | [\u38142 \u25509 ] |\cf2 \cb1 \strokec2 \
\
\cf5 \cb3 \strokec5 ### 8.2 \uc0\u39029 \u38754 \u35814 \u32454 \u35774 \u35745 \cf2 \cb1 \strokec2 \
\
\cf5 \cb3 \strokec5 #### P001 - [\uc0\u39029 \u38754 \u21517 \u31216 ]\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 **\uc0\u39029 \u38754 \u24067 \u23616 \u65306 **\cf2 \cb1 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 ```\cf2 \cb1 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 +------------------------------------------+\cb1 \
\cb3 |               \uc0\u23548 \u33322 \u26639                       |\cb1 \
\cb3 +------------------------------------------+\cb1 \
\cb3 |  [\uc0\u21151 \u33021 \u20837 \u21475 1]    [\u21151 \u33021 \u20837 \u21475 2]    [\u21151 \u33021 \u20837 \u21475 3]  |\cb1 \
\cb3 +------------------------------------------+\cb1 \
\cb3 |                                          |\cb1 \
\cb3 |              \uc0\u20027 \u20869 \u23481 \u21306 \u22495                     |\cb1 \
\cb3 |                                          |\cb1 \
\cb3 +------------------------------------------+\cb1 \
\cb3 |               \uc0\u24213 \u37096 \u25805 \u20316 \u26639                    |\cb1 \
\cb3 +------------------------------------------+\cb1 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 ```\cf2 \cb1 \strokec2 \
\
\pard\pardeftab720\partightenfactor0
\cf5 \cb3 \strokec5 **\uc0\u20132 \u20114 \u35828 \u26126 \u65306 **\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 - \uc0\u20803 \u32032 1\u65306 \u28857 \u20987 \u36339 \u36716 \u33267 xxx\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 - \uc0\u20803 \u32032 2\u65306 \u38271 \u25353 \u26174 \u31034 xxx\u33756 \u21333 \cf2 \cb1 \strokec2 \
\
\cf5 \cb3 \strokec5 **\uc0\u29366 \u24577 \u35828 \u26126 \u65306 **\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 | \uc0\u29366 \u24577  | \u23637 \u31034 \u20869 \u23481  | \u35302 \u21457 \u26465 \u20214  |\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 |-----|---------|---------|\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 | \uc0\u40664 \u35748 \u24577  | [\u20869 \u23481 ] | [\u26465 \u20214 ] |\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 | \uc0\u21152 \u36733 \u24577  | [\u20869 \u23481 ] | [\u26465 \u20214 ] |\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 | \uc0\u31354 \u29366 \u24577  | [\u20869 \u23481 ] | [\u26465 \u20214 ] |\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 | \uc0\u38169 \u35823 \u24577  | [\u20869 \u23481 ] | [\u26465 \u20214 ] |\cf2 \cb1 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 ```\cf2 \cb1 \strokec2 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 ---\cb1 \
\
\cb3 ### \uc0\u20061 \u12289 \u25509 \u21475 \u35774 \u35745 \cb1 \
\
\pard\pardeftab720\partightenfactor0

\f1\b \cf2 \cb3 **\uc0\u32534 \u20889 \u35201 \u28857 \u65306 **
\f0\b0 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 - \uc0\u23450 \u20041 \u25509 \u21475 \u35268 \u33539 \u21644 \u25968 \u25454 \u26684 \u24335 \cb1 \
\cb3 - \uc0\u35828 \u26126 \u35831 \u27714 \u21442 \u25968 \u21644 \u21709 \u24212 \u32467 \u26500 \cb1 \
\cb3 - \uc0\u26631 \u27880 \u24517 \u22635 \u39033 \u21644 \u26657 \u39564 \u35268 \u21017 \cb1 \
\
\pard\pardeftab720\partightenfactor0

\f1\b \cf2 \cb3 **\uc0\u27169 \u26495 \u32467 \u26500 \u65306 **
\f0\b0 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 ```markdown\cf2 \cb1 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 ## \uc0\u20061 \u12289 \u25509 \u21475 \u35774 \u35745 \cb1 \
\
\cb3 ### 9.1 \uc0\u25509 \u21475 \u21015 \u34920 \cb1 \
\cb3 | \uc0\u32534 \u21495  | \u25509 \u21475 \u21517 \u31216  | \u35831 \u27714 \u26041 \u24335  | \u25509 \u21475 \u22320 \u22336  | \u35828 \u26126  |\cb1 \
\cb3 |-----|---------|---------|---------|------|\cb1 \
\cb3 | API-001 | \cf4 \strokec4 [\uc0\u25509 \u21475 \u21517 ]\cf2 \strokec2  | POST/GET | /api/v1/xxx | \cf4 \strokec4 [\uc0\u25551 \u36848 ]\cf2 \strokec2  |\cb1 \
\
\cb3 ### 9.2 \uc0\u25509 \u21475 \u35814 \u32454 \u35774 \u35745 \cb1 \
\
\cb3 #### API-001 [\uc0\u25509 \u21475 \u21517 \u31216 ]\cb1 \
\
\pard\pardeftab720\partightenfactor0

\f1\b \cf2 \cb3 **\uc0\u22522 \u26412 \u20449 \u24687 **
\f0\b0 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 - 
\f1\b **\uc0\u25509 \u21475 \u22320 \u22336 **
\f0\b0 \uc0\u65306 \cf5 \strokec5 `POST /api/v1/xxx`\cf2 \cb1 \strokec2 \
\cb3 - 
\f1\b **\uc0\u21151 \u33021 \u35828 \u26126 **
\f0\b0 \uc0\u65306 \cf4 \strokec4 [\uc0\u25509 \u21475 \u21151 \u33021 \u25551 \u36848 ]\cf2 \cb1 \strokec2 \
\cb3 - 
\f1\b **\uc0\u35843 \u29992 \u26041 **
\f0\b0 \uc0\u65306 \cf4 \strokec4 [\uc0\u21738 \u20010 \u31471 \u35843 \u29992 ]\cf2 \cb1 \strokec2 \
\
\pard\pardeftab720\partightenfactor0

\f1\b \cf2 \cb3 **\uc0\u35831 \u27714 \u21442 \u25968 **
\f0\b0 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 | \uc0\u21442 \u25968 \u21517  | \u31867 \u22411  | \u24517 \u22635  | \u35828 \u26126  | \u31034 \u20363 \u20540  |\cb1 \
\cb3 |-------|------|-----|------|-------|\cb1 \
\cb3 | param1 | String | \uc0\u26159  | \cf4 \strokec4 [\uc0\u35828 \u26126 ]\cf2 \strokec2  | \cf4 \strokec4 [\uc0\u31034 \u20363 ]\cf2 \strokec2  |\cb1 \
\
\pard\pardeftab720\partightenfactor0

\f1\b \cf2 \cb3 **\uc0\u35831 \u27714 \u31034 \u20363 **
\f0\b0 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 ```json\cf2 \cb1 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \{\cb1 \
\cb3   "param1": "value1",\cb1 \
\cb3   "param2": "value2"\cb1 \
\cb3 \}\cb1 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 ```\cf2 \cb1 \strokec2 \
\
\pard\pardeftab720\partightenfactor0

\f1\b \cf2 \cb3 **\uc0\u21709 \u24212 \u21442 \u25968 **
\f0\b0 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 | \uc0\u21442 \u25968 \u21517  | \u31867 \u22411  | \u35828 \u26126  |\cb1 \
\cb3 |-------|------|------|\cb1 \
\cb3 | code | Integer | \uc0\u21709 \u24212 \u30721 \u65292 200\u25104 \u21151  |\cb1 \
\cb3 | message | String | \uc0\u21709 \u24212 \u28040 \u24687  |\cb1 \
\cb3 | data | Object | \uc0\u21709 \u24212 \u25968 \u25454  |\cb1 \
\
\pard\pardeftab720\partightenfactor0

\f1\b \cf2 \cb3 **\uc0\u21709 \u24212 \u31034 \u20363 **
\f0\b0 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 ```json\cf2 \cb1 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \{\cb1 \
\cb3   "code": 200,\cb1 \
\cb3   "message": "success",\cb1 \
\cb3   "data": \{\cb1 \
\cb3     "result": "xxx"\cb1 \
\cb3   \}\cb1 \
\cb3 \}\cb1 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 ```\cf2 \cb1 \strokec2 \
\cf4 \cb3 \strokec4 ```\cf2 \cb1 \strokec2 \
\
\pard\pardeftab720\partightenfactor0
\cf5 \cb3 \strokec5 ---\cf2 \cb1 \strokec2 \
\
\cf5 \cb3 \strokec5 ### \uc0\u21313 \u12289 \u24322 \u24120 \u19982 \u36793 \u30028 \u22788 \u29702 \cf2 \cb1 \strokec2 \
\
\cf5 \cb3 \strokec5 **\uc0\u32534 \u20889 \u35201 \u28857 \u65306 **\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 - \uc0\u21015 \u20986 \u25152 \u26377 \u21487 \u33021 \u30340 \u24322 \u24120 \u22330 \u26223 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 - \uc0\u23450 \u20041 \u38169 \u35823 \u30721 \u21644 \u25552 \u31034 \u35821 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 - \uc0\u35828 \u26126 \u36793 \u30028 \u26465 \u20214 \u21644 \u38480 \u21046 \cf2 \cb1 \strokec2 \
\
\cf5 \cb3 \strokec5 **\uc0\u27169 \u26495 \u32467 \u26500 \u65306 **\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 ```markdown\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 ## \uc0\u21313 \u12289 \u24322 \u24120 \u19982 \u36793 \u30028 \u22788 \u29702 \cf2 \cb1 \strokec2 \
\
\cf5 \cb3 \strokec5 ### 10.1 \uc0\u24322 \u24120 \u22330 \u26223 \u22788 \u29702 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 | \uc0\u38169 \u35823 \u30721  | \u24322 \u24120 \u31867 \u22411  | \u35302 \u21457 \u22330 \u26223  | \u29992 \u25143 \u25552 \u31034  | \u22788 \u29702 \u26041 \u26696  |\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 |-------|---------|---------|---------|---------|\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 | E001 | [\uc0\u31867 \u22411 ] | [\u22330 \u26223 ] | [\u25552 \u31034 \u35821 ] | [\u22788 \u29702 ] |\cf2 \cb1 \strokec2 \
\
\cf5 \cb3 \strokec5 ### 10.2 \uc0\u36793 \u30028 \u26465 \u20214 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 | \uc0\u36793 \u30028 \u22330 \u26223  | \u38480 \u21046 \u26465 \u20214  | \u22788 \u29702 \u26041 \u24335  |\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 |---------|---------|---------|\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 | \uc0\u36755 \u20837 \u38271 \u24230  | \u26368 \u22823 xx\u23383 \u31526  | \u25130 \u26029 /\u25552 \u31034  |\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 | \uc0\u25968 \u20540 \u33539 \u22260  | 1-100 | \u36229 \u20986 \u33539 \u22260 \u25552 \u31034  |\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 | \uc0\u24182 \u21457 \u38480 \u21046  | \u21516 \u26102 xx\u20154  | \u25490 \u38431 \u26426 \u21046  |\cf2 \cb1 \strokec2 \
\
\cf5 \cb3 \strokec5 ### 10.3 \uc0\u38477 \u32423 \u26041 \u26696 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 | \uc0\u22330 \u26223  | \u35302 \u21457 \u26465 \u20214  | \u38477 \u32423 \u31574 \u30053  |\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 |-----|---------|---------|\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 | [\uc0\u22330 \u26223 ] | [\u26465 \u20214 ] | [\u31574 \u30053 ] |\cf2 \cb1 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 ```\cf2 \cb1 \strokec2 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 ---\cb1 \
\
\cb3 ### \uc0\u21313 \u19968 \u12289 \u25968 \u25454 \u22475 \u28857 \cb1 \
\
\pard\pardeftab720\partightenfactor0

\f1\b \cf2 \cb3 **\uc0\u32534 \u20889 \u35201 \u28857 \u65306 **
\f0\b0 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 - \uc0\u23450 \u20041 \u20851 \u38190 \u19994 \u21153 \u20107 \u20214 \u30340 \u22475 \u28857 \cb1 \
\cb3 - \uc0\u35828 \u26126 \u22475 \u28857 \u35302 \u21457 \u26102 \u26426 \u21644 \u21442 \u25968 \cb1 \
\cb3 - \uc0\u21306 \u20998 \u24517 \u22475 \u28857 \u21644 \u21487 \u36873 \u22475 \u28857 \cb1 \
\
\pard\pardeftab720\partightenfactor0

\f1\b \cf2 \cb3 **\uc0\u27169 \u26495 \u32467 \u26500 \u65306 **
\f0\b0 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 ```markdown\cf2 \cb1 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 ## \uc0\u21313 \u19968 \u12289 \u25968 \u25454 \u22475 \u28857 \cb1 \
\
\cb3 ### 11.1 \uc0\u22475 \u28857 \u28165 \u21333 \cb1 \
\cb3 | \uc0\u20107 \u20214 \u32534 \u21495  | \u20107 \u20214 \u21517 \u31216  | \u20107 \u20214 \u31867 \u22411  | \u35302 \u21457 \u26102 \u26426  | \u20248 \u20808 \u32423  |\cb1 \
\cb3 |---------|---------|---------|---------|-------|\cb1 \
\cb3 | EVT001 | \cf4 \strokec4 [\uc0\u20107 \u20214 \u21517 ]\cf2 \strokec2  | \uc0\u26333 \u20809 /\u28857 \u20987 /\u33258 \u23450 \u20041  | \cf4 \strokec4 [\uc0\u26102 \u26426 ]\cf2 \strokec2  | P0/P1/P2 |\cb1 \
\
\cb3 ### 11.2 \uc0\u22475 \u28857 \u35814 \u32454 \u35774 \u35745 \cb1 \
\
\cb3 #### EVT001 - [\uc0\u20107 \u20214 \u21517 \u31216 ]\cb1 \
\cb3 - 
\f1\b **\uc0\u20107 \u20214 \u35828 \u26126 **
\f0\b0 \uc0\u65306 \cf4 \strokec4 [\uc0\u20107 \u20214 \u25551 \u36848 ]\cf2 \cb1 \strokec2 \
\cb3 - 
\f1\b **\uc0\u35302 \u21457 \u26465 \u20214 **
\f0\b0 \uc0\u65306 \cf4 \strokec4 [\uc0\u20160 \u20040 \u24773 \u20917 \u19979 \u35302 \u21457 ]\cf2 \cb1 \strokec2 \
\cb3 - 
\f1\b **\uc0\u19978 \u25253 \u26102 \u26426 **
\f0\b0 \uc0\u65306 \cf4 \strokec4 [\uc0\u31435 \u21363 \u19978 \u25253 /\u24310 \u36831 \u19978 \u25253 /\u25209 \u37327 \u19978 \u25253 ]\cf2 \cb1 \strokec2 \
\
\pard\pardeftab720\partightenfactor0

\f1\b \cf2 \cb3 **\uc0\u20107 \u20214 \u21442 \u25968 **
\f0\b0 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 | \uc0\u21442 \u25968 \u21517  | \u31867 \u22411  | \u24517 \u20256  | \u35828 \u26126  | \u21462 \u20540 \u33539 \u22260  |\cb1 \
\cb3 |-------|------|-----|------|---------|\cb1 \
\cb3 | param1 | String | \uc0\u26159  | \cf4 \strokec4 [\uc0\u35828 \u26126 ]\cf2 \strokec2  | \cf4 \strokec4 [\uc0\u21462 \u20540 ]\cf2 \strokec2  |\cb1 \
\
\pard\pardeftab720\partightenfactor0

\f1\b \cf2 \cb3 **\uc0\u19978 \u25253 \u31034 \u20363 **
\f0\b0 \cb1 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 ```json\cf2 \cb1 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \{\cb1 \
\cb3   "event": "click_button",\cb1 \
\cb3   "params": \{\cb1 \
\cb3     "button_name": "submit",\cb1 \
\cb3     "page_id": "home"\cb1 \
\cb3   \},\cb1 \
\cb3   "timestamp": 1699999999999\cb1 \
\cb3 \}\cb1 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 ```\cf2 \cb1 \strokec2 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 ### 11.3 \uc0\u26680 \u24515 \u25351 \u26631 \cb1 \
\cb3 | \uc0\u25351 \u26631 \u21517 \u31216  | \u35745 \u31639 \u20844 \u24335  | \u25968 \u25454 \u26469 \u28304  | \u35828 \u26126  |\cb1 \
\cb3 |---------|---------|---------|------|\cb1 \
\cb3 | \cf4 \strokec4 [\uc0\u25351 \u26631 \u21517 ]\cf2 \strokec2  | \cf4 \strokec4 [\uc0\u20844 \u24335 ]\cf2 \strokec2  | \cf4 \strokec4 [\uc0\u26469 \u28304 ]\cf2 \strokec2  | \cf4 \strokec4 [\uc0\u25551 \u36848 ]\cf2 \strokec2  |\cb1 \
\pard\pardeftab720\partightenfactor0
\cf4 \cb3 \strokec4 ```\cf2 \cb1 \strokec2 \
\
\pard\pardeftab720\partightenfactor0
\cf5 \cb3 \strokec5 ---\cf2 \cb1 \strokec2 \
\
\cf5 \cb3 \strokec5 ## \uc0\u25991 \u26723 \u36755 \u20986 \u35268 \u33539 \cf2 \cb1 \strokec2 \
\
\cf5 \cb3 \strokec5 ### \uc0\u26684 \u24335 \u35201 \u27714 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 - \uc0\u20351 \u29992 Markdown\u26684 \u24335 \u36755 \u20986 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 - \uc0\u26631 \u39064 \u23618 \u32423 \u28165 \u26224 \u65288 \u26368 \u22810 \u22235 \u32423 \u65289 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 - \uc0\u34920 \u26684 \u29992 \u20110 \u32467 \u26500 \u21270 \u20449 \u24687 \u23637 \u31034 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 - \uc0\u20195 \u30721 \u22359 \u29992 \u20110 \u25509 \u21475 \u31034 \u20363 \u21644 \u25968 \u25454 \u26684 \u24335 \cf2 \cb1 \strokec2 \
\
\cf5 \cb3 \strokec5 ### \uc0\u36136 \u37327 \u26816 \u26597 \u28165 \u21333 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 - [ ] \uc0\u38656 \u27714 \u32972 \u26223 \u26159 \u21542 \u26377 \u25968 \u25454 \u25903 \u25745 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 - [ ] \uc0\u30446 \u26631 \u26159 \u21542 \u21487 \u37327 \u21270 \u34913 \u37327 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 - [ ] \uc0\u21151 \u33021 \u28165 \u21333 \u26159 \u21542 \u23436 \u25972 \u19988 \u20248 \u20808 \u32423 \u26126 \u30830 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 - [ ] \uc0\u27969 \u31243 \u22270 \u26159 \u21542 \u35206 \u30422 \u25152 \u26377 \u20998 \u25903 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 - [ ] \uc0\u25509 \u21475 \u35774 \u35745 \u26159 \u21542 \u31526 \u21512 RESTful\u35268 \u33539 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 - [ ] \uc0\u24322 \u24120 \u22330 \u26223 \u26159 \u21542 \u32771 \u34385 \u20840 \u38754 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 - [ ] \uc0\u22475 \u28857 \u26159 \u21542 \u35206 \u30422 \u20851 \u38190 \u19994 \u21153 \u33410 \u28857 \cf2 \cb1 \strokec2 \
\
\cf5 \cb3 \strokec5 ## \uc0\u20351 \u29992 \u31034 \u20363 \cf2 \cb1 \strokec2 \
\
\cf5 \cb3 \strokec5 **\uc0\u29992 \u25143 \u36755 \u20837 \u65306 **\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 > \uc0\u24110 \u25105 \u20889 \u19968 \u20010 \u29992 \u25143 \u27880 \u20876 \u21151 \u33021 \u30340 PRD\cf2 \cb1 \strokec2 \
\
\cf5 \cb3 \strokec5 **\uc0\u29983 \u25104 \u36755 \u20986 \u65306 **\cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 \uc0\u25353 \u29031 \u19978 \u36848 \u27169 \u26495 \u32467 \u26500 \u65292 \u29983 \u25104 \u23436 \u25972 \u30340 \u29992 \u25143 \u27880 \u20876 \u21151 \u33021 \u20135 \u21697 \u38656 \u27714 \u25991 \u26723 \u65292 \u21253 \u21547 \u65306 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 1. \uc0\u27880 \u20876 \u32972 \u26223 \u65288 \u36134 \u21495 \u20307 \u31995 \u24517 \u35201 \u24615 \u65289 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 2. \uc0\u29992 \u25143 \u25968 \u25454 \u26550 \u26500 \u35774 \u35745 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 3. \uc0\u27880 \u20876 \u36716 \u21270 \u29575 \u31561 \u30446 \u26631 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 4. \uc0\u26032 \u29992 \u25143 \u27880 \u20876 \u22330 \u26223 \u20998 \u26512 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 5. \uc0\u27880 \u20876 \u21151 \u33021 \u28165 \u21333 \u65288 \u25163 \u26426 \u21495 \u27880 \u20876 \u12289 \u37038 \u31665 \u27880 \u20876 \u31561 \u65289 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 6. \uc0\u21508 \u27880 \u20876 \u26041 \u24335 \u35814 \u32454 \u26041 \u26696 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 7. \uc0\u27880 \u20876 \u27969 \u31243 \u22270 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 8. \uc0\u27880 \u20876 \u39029 \u38754 \u21407 \u22411 \u25551 \u36848 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 9. \uc0\u27880 \u20876 \u30456 \u20851 \u25509 \u21475 \u35774 \u35745 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 10. \uc0\u32593 \u32476 \u24322 \u24120 \u12289 \u21495 \u30721 \u24050 \u27880 \u20876 \u31561 \u36793 \u30028 \u22788 \u29702 \cf2 \cb1 \strokec2 \
\cf5 \cb3 \strokec5 11. \uc0\u27880 \u20876 \u21508 \u29615 \u33410 \u22475 \u28857 \u35774 \u35745 \cf2 \cb1 \strokec2 \
\
}