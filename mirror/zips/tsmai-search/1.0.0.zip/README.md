# TSMAI Search - 腾讯云联网搜索

基于腾讯云 [SearchPro API](https://cloud.tencent.com/document/product/1806/121811) 的联网搜索工具，支持实时网页搜索、站内搜索、时间过滤等功能。

---

## 📋 功能特性

- **实时联网搜索**：调用腾讯云 SearchPro API 获取最新搜索结果
- **多种搜索模式**：自然检索、多模态VR、混合模式
- **站内搜索**：指定域名进行站内搜索
- **时间过滤**：按起止时间筛选结果
- **行业筛选**：支持党政、媒体、学术、金融（尊享版）
- **TC3-HMAC-SHA256**：标准腾讯云 API 3.0 签名认证
- **双格式输出**：Markdown 可读格式 / JSON 结构化格式

---

## 🚀 快速开始

### 1. 配置 API 密钥

前往 [腾讯云控制台](https://console.cloud.tencent.com/cam/capi) 获取 SecretId 和 SecretKey。

```bash
export TENCENT_SECRET_ID='your_secret_id'
export TENCENT_SECRET_KEY='your_secret_key'
```

### 2. 开通联网搜索服务

前往 [联网搜索控制台](https://console.cloud.tencent.com/hunyuan/search) 开通服务。

### 3. 运行搜索

```bash
# 基本搜索
node tsmai-search/scripts/search.mjs "今天的科技新闻"

# 站内搜索知乎
node tsmai-search/scripts/search.mjs "AI大模型" --site zhihu.com

# 混合模式搜索
node tsmai-search/scripts/search.mjs "三星堆的由来" --mode 2

# JSON 格式输出
node tsmai-search/scripts/search.mjs "腾讯云最新动态" --json
```

---

## ⚙️ 命令行参数

| 参数 | 说明 | 示例 |
|------|------|------|
| `"搜索词"` | 搜索关键词（必填） | `"今天北京的天气"` |
| `--mode <0\|1\|2>` | 搜索模式：0=自然检索，1=多模态VR，2=混合 | `--mode 2` |
| `--site <domain>` | 站内搜索，指定域名 | `--site zhihu.com` |
| `--from <timestamp>` | 起始时间（秒级时间戳） | `--from 1745498501` |
| `--to <timestamp>` | 结束时间（秒级时间戳） | `--to 1745598501` |
| `--cnt <10\|20\|30\|40\|50>` | 返回条数（尊享版） | `--cnt 20` |
| `--industry <类型>` | 行业：gov/news/acad/finance（尊享版） | `--industry news` |
| `--json` | 以 JSON 格式输出 | `--json` |
| `-h, --help` | 显示帮助信息 | `-h` |

---

## 📁 目录结构

```
tsmai-search/
├── README.md              # 本文件
├── SKILL.md               # Skill 元信息
└── scripts/
    └── search.mjs         # 联网搜索脚本
```

---

## ⚠️ 注意事项

1. **API 配额**：联网搜索 API 有调用频率限制，请注意用量
2. **密钥安全**：SecretId/SecretKey 通过环境变量传递，不要硬编码
3. **尊享版功能**：`--cnt` 和 `--industry` 参数仅限尊享版用户使用
4. **Node.js 版本**：需要 Node.js 18+ （原生 fetch 支持）

---

## 📄 License

MIT
