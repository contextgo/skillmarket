#!/usr/bin/env node
/**
 * 腾讯云联网搜索脚本 - 基于 SearchPro API
 * 使用 TC3-HMAC-SHA256 签名认证
 *
 * 用法: node search.mjs "搜索词" [--mode 0|1|2] [--site domain] [--from ts] [--to ts] [--cnt 10]
 */

import { createHmac, createHash } from 'crypto';
import { readFileSync } from 'fs';
import { resolve, dirname } from 'path';
import { fileURLToPath } from 'url';

// ============ 加载 .env 文件 ============

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

function loadEnv() {
  const envPaths = [
    resolve(__dirname, '..', '.env'),
    resolve(__dirname, '..', '..', '.env'),
  ];
  for (const envPath of envPaths) {
    try {
      const content = readFileSync(envPath, 'utf-8');
      for (const line of content.split('\n')) {
        const trimmed = line.trim();
        if (!trimmed || trimmed.startsWith('#')) continue;
        const eqIndex = trimmed.indexOf('=');
        if (eqIndex === -1) continue;
        const key = trimmed.slice(0, eqIndex).trim();
        let value = trimmed.slice(eqIndex + 1).trim();
        // 去除引号
        if ((value.startsWith("'") && value.endsWith("'")) ||
            (value.startsWith('"') && value.endsWith('"'))) {
          value = value.slice(1, -1);
        }
        if (!process.env[key]) {
          process.env[key] = value;
        }
      }
    } catch {
      // 文件不存在，跳过
    }
  }
}

loadEnv();

// ============ 配置 ============

const SECRET_ID = process.env.TENCENT_SECRET_ID || '';
const SECRET_KEY = process.env.TENCENT_SECRET_KEY || '';
const SERVICE = 'wsa';
const HOST = 'wsa.tencentcloudapi.com';
const ACTION = 'SearchPro';
const VERSION = '2025-05-08';

// ============ TC3-HMAC-SHA256 签名 ============

function sha256Hex(message) {
  return createHash('sha256').update(message, 'utf-8').digest('hex');
}

function hmacSHA256(key, message) {
  return createHmac('sha256', key).update(message, 'utf-8').digest();
}

function buildAuthorization(secretId, secretKey, service, payload) {
  const now = new Date();
  const timestamp = Math.floor(now.getTime() / 1000);
  const dateStr = now.toISOString().slice(0, 10); // YYYY-MM-DD

  const httpRequestMethod = 'POST';
  const canonicalUri = '/';
  const canonicalQueryString = '';
  const contentType = 'application/json; charset=utf-8';
  const canonicalHeaders =
    `content-type:${contentType}\n` +
    `host:${HOST}\n` +
    `x-tc-action:${ACTION.toLowerCase()}\n`;
  const signedHeaders = 'content-type;host;x-tc-action';
  const hashedPayload = sha256Hex(payload);

  const canonicalRequest = [
    httpRequestMethod,
    canonicalUri,
    canonicalQueryString,
    canonicalHeaders,
    signedHeaders,
    hashedPayload,
  ].join('\n');

  const credentialScope = `${dateStr}/${service}/tc3_request`;
  const stringToSign = [
    'TC3-HMAC-SHA256',
    timestamp,
    credentialScope,
    sha256Hex(canonicalRequest),
  ].join('\n');

  const secretDate = hmacSHA256(`TC3${secretKey}`, dateStr);
  const secretService = hmacSHA256(secretDate, service);
  const secretSigning = hmacSHA256(secretService, 'tc3_request');
  const signature = createHmac('sha256', secretSigning)
    .update(stringToSign, 'utf-8')
    .digest('hex');

  const authorization =
    `TC3-HMAC-SHA256 Credential=${secretId}/${credentialScope}, ` +
    `SignedHeaders=${signedHeaders}, ` +
    `Signature=${signature}`;

  return { authorization, timestamp };
}

// ============ 搜索接口 ============

async function searchPro(query, options = {}) {
  if (!SECRET_ID || !SECRET_KEY) {
    console.error(
      '❌ 错误: 请设置环境变量 TENCENT_SECRET_ID 和 TENCENT_SECRET_KEY\n' +
      '  export TENCENT_SECRET_ID="your_secret_id"\n' +
      '  export TENCENT_SECRET_KEY="your_secret_key"'
    );
    process.exit(1);
  }

  const body = { Query: query };
  if (options.mode !== undefined) body.Mode = options.mode;
  if (options.site) body.Site = options.site;
  if (options.fromTime) body.FromTime = options.fromTime;
  if (options.toTime) body.ToTime = options.toTime;
  if (options.cnt) body.Cnt = options.cnt;
  if (options.industry) body.Industry = options.industry;

  const payload = JSON.stringify(body);
  const { authorization, timestamp } = buildAuthorization(
    SECRET_ID,
    SECRET_KEY,
    SERVICE,
    payload
  );

  const headers = {
    'Content-Type': 'application/json; charset=utf-8',
    Host: HOST,
    'X-TC-Action': ACTION,
    'X-TC-Version': VERSION,
    'X-TC-Timestamp': String(timestamp),
    Authorization: authorization,
  };

  const response = await fetch(`https://${HOST}`, {
    method: 'POST',
    headers,
    body: payload,
  });

  if (!response.ok) {
    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
  }

  const data = await response.json();

  if (data.Response?.Error) {
    const err = data.Response.Error;
    throw new Error(`API Error [${err.Code}]: ${err.Message}`);
  }

  return data.Response;
}

// ============ 解析结果 ============

function parsePages(pages) {
  if (!pages || !Array.isArray(pages)) return [];

  return pages.map((pageStr) => {
    try {
      const page = typeof pageStr === 'string' ? JSON.parse(pageStr) : pageStr;
      return {
        title: page.title || '无标题',
        url: page.url || '',
        passage: page.passage || '',
        content: page.content || '',
        date: page.date || '',
        site: page.site || '',
        score: page.score || 0,
        images: page.images || [],
        favicon: page.favicon || '',
      };
    } catch {
      return null;
    }
  }).filter(Boolean);
}

// ============ 格式化输出 ============

function formatResults(query, results, version) {
  const lines = [];
  lines.push(`🔍 搜索: ${query}`);
  if (version) lines.push(`📋 版本: ${version}`);
  lines.push(`📊 结果: ${results.length} 条\n`);

  results.forEach((r, i) => {
    lines.push(`${i + 1}. [${r.title}](${r.url})`);
    const meta = [];
    if (r.site) meta.push(`来源: ${r.site}`);
    if (r.date) meta.push(`日期: ${r.date}`);
    if (r.score) meta.push(`相关度: ${r.score.toFixed(2)}`);
    if (meta.length) lines.push(`   ${meta.join(' | ')}`);

    const summary = r.content || r.passage || '';
    if (summary) {
      lines.push(`   ${summary.substring(0, 200)}${summary.length > 200 ? '...' : ''}`);
    }
    lines.push('');
  });

  return lines.join('\n');
}

// ============ JSON 输出 ============

function formatJSON(query, results, version) {
  return JSON.stringify(
    {
      query,
      version,
      count: results.length,
      results: results.map((r) => ({
        title: r.title,
        url: r.url,
        summary: r.content || r.passage,
        date: r.date,
        site: r.site,
        score: r.score,
      })),
    },
    null,
    2
  );
}

// ============ CLI 参数解析 ============

function parseArgs(argv) {
  const args = argv.slice(2);
  const options = { query: '', mode: undefined, site: '', fromTime: 0, toTime: 0, cnt: 0, industry: '', json: false };

  let i = 0;
  while (i < args.length) {
    switch (args[i]) {
      case '--mode':
        options.mode = parseInt(args[++i], 10);
        break;
      case '--site':
        options.site = args[++i];
        break;
      case '--from':
        options.fromTime = parseInt(args[++i], 10);
        break;
      case '--to':
        options.toTime = parseInt(args[++i], 10);
        break;
      case '--cnt':
        options.cnt = parseInt(args[++i], 10);
        break;
      case '--industry':
        options.industry = args[++i];
        break;
      case '--json':
        options.json = true;
        break;
      case '--help':
      case '-h':
        console.log(`
腾讯云联网搜索 (SearchPro)

用法: node search.mjs "搜索词" [选项]

选项:
  --mode <0|1|2>    搜索模式 (0=自然检索, 1=多模态VR, 2=混合)
  --site <domain>   站内搜索，指定域名
  --from <timestamp> 起始时间 (秒级时间戳)
  --to <timestamp>   结束时间 (秒级时间戳)
  --cnt <10|20|30|40|50> 返回条数 (尊享版)
  --industry <gov|news|acad|finance> 行业筛选 (尊享版)
  --json            以 JSON 格式输出
  -h, --help        显示帮助

环境变量:
  TENCENT_SECRET_ID   腾讯云 SecretId
  TENCENT_SECRET_KEY  腾讯云 SecretKey
`);
        process.exit(0);
        break;
      default:
        if (!options.query && !args[i].startsWith('--')) {
          options.query = args[i];
        }
        break;
    }
    i++;
  }

  return options;
}

// ============ 主函数 ============

async function main() {
  const options = parseArgs(process.argv);

  if (!options.query) {
    console.error('❌ 请提供搜索关键词\n用法: node search.mjs "搜索词" [--mode 0] [--site domain]');
    process.exit(1);
  }

  try {
    const response = await searchPro(options.query, {
      mode: options.mode,
      site: options.site || undefined,
      fromTime: options.fromTime || undefined,
      toTime: options.toTime || undefined,
      cnt: options.cnt || undefined,
      industry: options.industry || undefined,
    });

    const results = parsePages(response.Pages);
    const version = response.Version || '';

    if (options.json) {
      console.log(formatJSON(options.query, results, version));
    } else {
      console.log(formatResults(options.query, results, version));
    }
  } catch (err) {
    console.error(`❌ 搜索失败: ${err.message}`);
    process.exit(1);
  }
}

main();
