---
name: tsmai-search
description: >
  腾讯云联网搜索工具，基于腾讯混元 SearchPro API 实现实时联网搜索。
  支持自然检索、多模态VR结果、站内搜索、时间范围过滤等功能。
  Use when the user wants to: (1) Search the web for real-time information,
  (2) Find latest news or articles, (3) Get search results with titles, URLs, and summaries,
  (4) Perform site-specific searches. Trigger phrases include "搜索", "联网搜索", "查一下", "search", "web search", "find information".
---

# 腾讯云联网搜索 (TSMAI Search)

基于腾讯云 SearchPro API 的联网搜索工具。

## 使用方式

运行搜索脚本：
```bash
node tsmai-search/scripts/search.mjs "搜索关键词"
```

### 可选参数

```bash
# 指定搜索模式 (0=自然检索, 1=多模态VR, 2=混合)
node tsmai-search/scripts/search.mjs "关键词" --mode 2

# 指定站内搜索
node tsmai-search/scripts/search.mjs "关键词" --site zhihu.com

# 指定时间范围（时间戳）
node tsmai-search/scripts/search.mjs "关键词" --from 1745498501 --to 1745598501

# 指定返回数量 (10/20/30/40/50, 尊享版)
node tsmai-search/scripts/search.mjs "关键词" --cnt 20
```

## 环境变量

需要设置腾讯云 API 密钥：
```bash
export TENCENT_SECRET_ID='your_secret_id'
export TENCENT_SECRET_KEY='your_secret_key'
```

## 输出格式

搜索结果以 Markdown 格式输出：

```
🔍 搜索: 关键词

1. [标题](URL)
   来源: 网站名 | 日期: 2025-01-01 | 相关度: 0.89
   摘要内容...

2. [标题](URL)
   来源: 网站名 | 日期: 2025-01-02 | 相关度: 0.85
   摘要内容...
```
