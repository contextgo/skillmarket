"""VideoARM shared library."""
