#!/usr/bin/env python3
"""客户主体竞价消耗精确查询工具。仅支持主体名称全称精确匹配。支持 CSV 和 XLSX 格式。"""

import argparse
import csv
import json
import sys
import os


def load_csv(db_path: str) -> dict:
    """从 CSV 加载数据。"""
    data = {}
    with open(db_path, "r", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["客户主体名称(OPS)"].strip()
            y2025 = float(row.get("2025年全年竞价消耗(元)", "0") or "0")
            q1_2026 = float(row.get("2026年Q1竞价消耗(元)", "0") or "0")
            data[name] = {"y2025": y2025, "q1_2026": q1_2026}
    return data


def load_xlsx(db_path: str) -> dict:
    """从 XLSX 加载数据。"""
    try:
        import openpyxl
    except ImportError:
        print(json.dumps({"error": "缺少 openpyxl 库，请运行: pip install openpyxl"}, ensure_ascii=False))
        sys.exit(1)

    wb = openpyxl.load_workbook(db_path, data_only=True)
    ws = wb.active
    data = {}
    rows = list(ws.iter_rows(values_only=True))
    header = rows[0]

    # 找到对应列的索引
    col_map = {}
    for i, h in enumerate(header):
        if h is None:
            continue
        h_str = str(h).strip()
        if "主体名称" in h_str or "OPS" in h_str:
            col_map["name"] = i
        elif "2025" in h_str and "消耗" in h_str:
            col_map["y2025"] = i
        elif "2026" in h_str and "Q1" in h_str and "消耗" in h_str:
            col_map["q1_2026"] = i
        elif "总消耗" in h_str:
            col_map["total"] = i

    if "name" not in col_map:
        print(json.dumps({"error": "未找到客户主体名称列"}, ensure_ascii=False))
        sys.exit(1)

    for row in rows[1:]:
        if len(row) <= col_map["name"]:
            continue
        name_val = row[col_map["name"]]
        if name_val is None:
            continue
        name = str(name_val).strip()
        if not name:
            continue
        y2025 = float(row[col_map["y2025"]] if col_map.get("y2025") is not None and len(row) > col_map["y2025"] and row[col_map["y2025"]] else 0)
        q1_2026 = float(row[col_map["q1_2026"]] if col_map.get("q1_2026") is not None and len(row) > col_map["q1_2026"] and row[col_map["q1_2026"]] else 0)
        data[name] = {"y2025": y2025, "q1_2026": q1_2026}

    wb.close()
    return data


def load_database(db_path: str) -> dict:
    """根据文件扩展名选择加载方式。"""
    ext = os.path.splitext(db_path)[1].lower()
    if ext in (".xlsx", ".xlsm"):
        return load_xlsx(db_path)
    else:
        return load_csv(db_path)


def check_conditions(amount: float, thresholds: list) -> list:
    """根据阈值列表判断是否达标。"""
    results = [amount > 0]  # 有消耗
    for t in thresholds:
        results.append(amount >= t)
    return results


def query(names: list, db_path: str) -> list:
    """查询多个主体名称，返回结果列表。"""
    database = load_database(db_path)
    results = []

    for name in names:
        name = name.strip()
        if not name:
            continue

        record = database.get(name)
        if record is None:
            results.append({
                "name": name,
                "found": False,
                "y2025_has": None,
                "y2025_over_10w": None,
                "y2025_over_800w": None,
                "q1_has": None,
                "q1_over_10w": None,
                "q1_over_100w": None,
                "q1_over_800w": None,
            })
        else:
            y25 = check_conditions(record["y2025"], [100000, 8000000])
            q1 = check_conditions(record["q1_2026"], [100000, 1000000, 8000000])
            results.append({
                "name": name,
                "found": True,
                "y2025_has": y25[0],
                "y2025_over_10w": y25[1],
                "y2025_over_800w": y25[2],
                "q1_has": q1[0],
                "q1_over_10w": q1[1],
                "q1_over_100w": q1[2],
                "q1_over_800w": q1[3],
            })

    return results


def main():
    parser = argparse.ArgumentParser(description="客户主体竞价消耗查询")
    parser.add_argument("--names", nargs="+", required=True, help="客户主体名称列表（全称精确匹配）")
    parser.add_argument("--db", required=True, help="数据库文件路径（CSV 或 XLSX）")
    args = parser.parse_args()

    if not os.path.exists(args.db):
        print(json.dumps({"error": f"数据库文件不存在: {args.db}"}, ensure_ascii=False))
        sys.exit(1)

    results = query(args.names, args.db)
    print(json.dumps(results, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
