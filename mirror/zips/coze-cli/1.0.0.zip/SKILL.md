---
name: coze-cli
description: Coze CLI 命令行工具，用于图片生成、音频生成、视频生成、聊天、工作流执行等。使用场景：用户要求生成AI图片/音频/视频、使用Coze工作流、聊天对话、认证管理时触发。
agent_created: true
version: 1.0.0
tags: [coze, cli, image-generation, audio, video, workflow]
---

# Coze CLI 技能

Coze CLI 是字节跳动 Coze 平台的命令行工具，提供图片生成、音频生成、视频生成、聊天对话、工作流执行等功能。

## 基础认证

### 登录认证
```bash
# 推荐：浏览器OAuth登录
coze auth login --oauth

# 检查登录状态
coze auth status

# 登出
coze auth logout
```

### 组织和工作空间管理
```bash
# 列出所有可访问的组织
coze organization list
coze org list

# 设置默认组织
coze organization use <org_id>
coze org use <org_id>

# 切换到个人账号
coze organization use

# 列出所有可用工作空间
coze space list

# 设置默认工作空间
coze space use <space_id>
```

## 图片生成 (generate image)

### 基础用法
```bash
# 生成图片（默认带水印）
coze generate image "A cat"

# 生成无水印图片
coze generate image "A cat" --no-watermark
```

### 常用参数
| 参数 | 说明 | 示例 |
|------|------|------|
| `--no-watermark` | 禁用水印 | `coze generate image "cat" --no-watermark` |
| `--size <size>` | 图片尺寸 | `--size 1024x1024` 或 `--size 2K` / `--size 4K` |
| `--output-path <path>` | 保存路径 | `--output-path ./output.png` |
| `--response-format <fmt>` | 输出格式 | `url`（默认）或 `b64_json` |
| `--optimize-prompt-mode <mode>` | 提示词优化模式 | `standard`（默认） |
| `--max-images <n>` | 最大生图数量 | `--max-images 5`（1-15） |
| `--sequential <mode>` | 分组生成模式 | `auto` 或 `disabled`（默认） |
| `--image <url>` | 参考图片URL | `--image https://example.com/ref.png` |

### 保存到文件
```bash
# 保存到指定路径
coze generate image "A cat" --no-watermark --output-path ./cat.png

# 保存到目录（会自动生成文件名）
coze generate image "A sunset" --no-watermark --output-path ./
```

**注意**: `--output-path` 参数会自动创建目录，文件名格式为 `image_YYYYMMDD_HHMMSS_N.jpeg`

## 音频生成 (generate audio)

```bash
# 文字转语音
coze generate audio "Hello world"

# 保存到文件
coze generate audio "你好，世界" --output-path ./hello.mp3
```

## 视频生成 (generate video)

```bash
# 生成视频
coze generate video create "A dancing dog"

# 保存到文件
coze generate video create "A cat playing piano" --output-path ./piano_cat.mp4
```

## 聊天对话 (chat)

```bash
# 与Bot对话
coze chat <bot_id> "你好"

# 使用工作流
coze chat <workflow_id> "我的问题"
```

## 工作流执行 (workflow)

```bash
# 运行工作流
coze workflow run <workflow_id> --input '{"key": "value"}'
```

## 全局选项

| 选项 | 说明 |
|------|------|
| `--format <fmt>` | 输出格式：`json` 或 `text`（默认） |
| `--config <path>` | 指定配置文件路径 |
| `--org-id <id>` | 覆盖组织ID |
| `--space-id <id>` | 覆盖工作空间ID |
| `--log-file <path>` | 输出日志到文件 |

## 常见错误

| 错误码 | 说明 | 解决方案 |
|--------|------|----------|
| E1000 | 无效参数或缺少prompt | 提供prompt参数 |
| E1001 | 缺少计费项目ID | 配置计费项目ID |
| E1100 | 未知选项 | 检查参数拼写，使用 `-h` 查看帮助 |
| E1101 | 未知命令 | 检查命令拼写 |
| E5001 | 网络错误 | 检查网络连接 |
| E5002 | 服务器错误 | 重试 |

## 查看帮助

```bash
# 查看主帮助
coze --help

# 查看子命令帮助
coze generate --help
coze generate image --help
coze auth --help
coze organization --help
coze space --help
```
