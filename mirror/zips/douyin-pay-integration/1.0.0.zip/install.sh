#!/bin/bash
# 抖音支付集成 Skill 安装脚本
# Copyright: ByteDance Ltd. (Douyin Pay)

set -e

SKILL_NAME="douyin-pay-integration"
SKILL_DIR="$HOME/.openclaw/workspace/skills/$SKILL_NAME"

echo ""
echo "═══════════════════════════════════════════════════"
echo "  抖音支付集成 Skill"
echo "  Douyin Pay Integration"
echo "═══════════════════════════════════════════════════"
echo ""
echo "  内容版权：字节跳动（抖音支付）"
echo ""
echo "═══════════════════════════════════════════════════"
echo ""

# 检查目录是否存在
if [ -d "$SKILL_DIR" ]; then
  echo "📁 Skill 目录已存在，正在更新..."
else
  echo "📁 创建 Skill 目录..."
  mkdir -p "$SKILL_DIR"
fi

# 复制文件
echo "📄 安装 SKILL.md..."
cat > "$SKILL_DIR/SKILL.md" << 'SKILL_EOF'
---
name: douyin-pay-integration
display_name: 抖音支付集成
description: 抖音支付商户平台接入最佳实践。涵盖App支付、H5支付、JSAPI支付、Native支付等全场景产品选型与集成指导。
version: 1.0.0
author: 整合者：叶建国 | 内容版权：抖音（字节跳动）
homepage: https://pay.douyinpay.com/
tags:
  - 抖音支付
  - 支付集成
  - App支付
license: MIT
compatibility:
  - openclaw
  - skillhub
---

# 抖音支付集成

> **版权声明**：本 Skill 内容来源于抖音支付官方文档，版权归属字节跳动所有

## 简介

抖音支付商户平台接入最佳实践。

## 支付产品

| 产品 | 场景 |
|------|------|
| App支付 | 原生iOS/Android/鸿蒙App |
| H5支付 | 手机浏览器H5 |
| JSAPI支付 | 抖音小程序 |
| Native支付 | 商家二维码 |

## 快速决策树

```
用户咨询抖音支付
        |
        +-- App支付？ --> App支付
        +-- H5支付？ --> H5支付
        +-- 小程序？ --> JSAPI支付
        +-- 扫码？ --> Native支付
```

## 版权声明

- **版权归属**：字节跳动有限公司
- **商户平台**：https://pay.douyinpay.com
- **开放平台**：https://open.douyin.com

SKILL_EOF

echo ""
echo "═══════════════════════════════════════════════════"
echo "  ✅ 安装完成！"
echo "═══════════════════════════════════════════════════"
echo ""
echo "📚 使用说明："
echo ""
echo "  当用户提到以下关键词时自动触发："
echo "    - 接入抖音支付、集成抖音支付"
echo "    - App支付、H5支付"
echo "    - 抖音小程序支付、Native支付"
echo ""
echo "📖 完整文档请阅读："
echo "    $SKILL_DIR/SKILL.md"
echo ""
echo "═══════════════════════════════════════════════════"
