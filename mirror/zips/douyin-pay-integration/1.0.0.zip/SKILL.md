---
name: douyin-pay-integration
display_name: 抖音支付集成
description: 抖音支付商户平台接入最佳实践。涵盖App支付、H5支付、JSAPI支付、Native支付、订单退款等全场景产品选型与集成指导。
version: 1.0.0
author: 整合者：叶建国 | 内容版权：抖音（字节跳动）
homepage: https://pay.douyinpay.com/
tags:
  - 抖音支付
  - 支付集成
  - App支付
  - H5支付
  - JSAPI支付
license: MIT
compatibility:
  - openclaw
  - skillhub
---

# 抖音支付集成

> **版权声明**：本 Skill 内容来源于抖音支付官方文档，版权归属字节跳动（抖音）所有。如有疑问可咨询抖音支付客服
> 
> **Source**: 抖音支付商户文档中心
> **Copyright**: ByteDance Ltd.

---

## 简介

抖音支付商户平台接入最佳实践。涵盖 App支付、H5支付、JSAPI支付、Native支付、订单退款等全场景产品选型与集成指导。

**适用场景**：当用户提到"接入抖音支付"、"集成抖音支付"、"对接抖音支付"、"抖音收款"、"加个抖音支付"、"抖音下单"、"App支付"、"H5支付"、"小程序支付"、"抖音小程序支付"时使用此 Skill。

**不适用场景**：不用于支付宝支付、微信支付、银联支付等非抖音生态支付场景。

---

## 支付产品一览

抖音支付提供以下支付产品：

| 产品 | 场景 | 文档入口 |
|------|------|----------|
| App支付 | 原生iOS/Android/HarmonyOS App内支付 | [App支付文档](https://pay.douyinpay.com/wiki/63984677e9a722021c2c882e/639846ac15141c0223c19da7) |
| H5支付 | 手机浏览器H5页面支付 | [H5支付文档](https://pay.douyinpay.com) |
| JSAPI支付 | 抖音小程序内支付 | [JSAPI文档](https://pay.douyinpay.com) |
| Native支付 | 商家生成二维码，用户扫码支付 | [Native文档](https://pay.douyinpay.com) |
| 订单退款 | 退款申请、退款查询 | [退款文档](https://pay.douyinpay.com) |

---

## 接入路由表

根据用户的业务场景，路由到对应的产品文档：

| 场景 | 推荐产品 | 接入方式 | 文档 |
|------|----------|----------|------|
| 原生App支付（iOS/Android/鸿蒙） | App支付 | App SDK | [App支付](https://pay.douyinpay.com/wiki/63984677e9a722021c2c882e/639846ac15141c0223c19da7) |
| 手机浏览器H5支付 | H5支付 | H5页面 | [H5支付](https://pay.douyinpay.com) |
| 抖音小程序内支付 | JSAPI支付 | 小程序 | [JSAPI支付](https://pay.douyinpay.com) |
| 商家二维码用户扫码 | Native支付 | 二维码 | [Native支付](https://pay.douyinpay.com) |

---

## 快速决策树

```
用户咨询抖音支付接入
        |
        +-- App支付？
        |       +-- 原生iOS/Android/鸿蒙App --> App支付
        |
        +-- H5支付？
        |       +-- 手机浏览器H5 --> H5支付
        |
        +-- 小程序支付？
        |       +-- 抖音小程序内 --> JSAPI支付
        |
        +-- 扫码支付？
                +-- 商家二维码，用户扫码 --> Native支付
```

---

## 场景关键词匹配

| 关键词 | 路由产品 |
|--------|----------|
| 抖音支付、接入抖音支付、集成抖音支付、抖音收款 | App支付 |
| App支付、iOS支付、Android支付、鸿蒙支付、原生App | App支付 |
| H5支付、WAP支付、手机网页支付、移动端网页 | H5支付 |
| 小程序支付、抖音小程序、字节小程序、抖音JSAPI | JSAPI支付 |
| Native支付、二维码支付、扫码支付、商家二维码 | Native支付 |

---

## App支付接入指南

### 产品概述

App支付适用于在商家APP应用内集成抖音支付。用户支付时：
- 若已安装抖音客户端 → 唤起抖音/抖音极速版/抖音火山版客户端完成支付
- 若未安装抖音客户端 → 引导用户安装后继续完成支付

**支持平台**：iOS、Android、HarmonyOS（抖音APP版本36.8.0及以上）

### 准入条件

1. **主体类型**：个体工商户、企业、事业单位、政府机关、社会组织
2. **应用类型**：已认证的开放平台账号创建的移动应用

### 支付流程

```
1. 用户在商家App中选择商品下单
2. 选择"抖音支付"并提交订单
3. 自动打开抖音App唤起支付
4. 用户确认支付并进行验证
5. 支付成功后自动回跳到商家App
6. 用户在抖音App-我的钱包-账单查看明细
```

---

## 澄清话术

当用户描述模糊时：

```
请确认您的业务场景：

1. App支付
   - 原生 iOS/Android/鸿蒙 App 内集成抖音支付
   - 适用：自营App电商、游戏充值等

2. H5支付
   - 手机浏览器 H5 页面内支付
   - 适用：移动端网页电商

3. 抖音小程序支付
   - 抖音小程序内调用支付
   - 适用：抖音小程序内购物

4. Native支付
   - 商家生成二维码，用户扫码
   - 适用：线下扫码场景

请描述您的具体业务场景？
```

---

## 接入准备

### 1. 注册商户号

前往 [抖音支付商户平台](https://pay.douyinpay.com/) 注册商户账号

### 2. 获取必要参数

| 参数 | 说明 | 获取方式 |
|------|------|----------|
| app_id | 应用唯一标识 | 抖音开放平台 |
| app_secret | 应用密钥 | 抖音开放平台 |
| merchant_id | 商户号 | 商户平台申请 |
| private_key | 商户私钥 | 商户平台生成 |
| public_key | 商户公钥 | 商户平台上传 |

### 3. 开发接入

```bash
# 抖音支付SDK
# Java: https://pay.douyinpay.com/wiki/
# Go: https://pay.douyinpay.com/wiki/
# Python: https://pay.douyinpay.com/wiki/
```

---

## 文档资源

| 资源 | 链接 |
|------|------|
| 商户文档中心 | https://pay.douyinpay.com/ |
| App支付文档 | https://pay.douyinpay.com/wiki/63984677e9a722021c2c882e/639846ac15141c0223c19da7 |
| 开放平台 | https://open.douyin.com/ |

---

## 注意事项

- 本 Skill **不支持商家分账/转账到银行卡**等产品，如需使用请查阅官方文档。
- 业务咨询和接入问题请查阅 [抖音支付商户文档中心](https://pay.douyinpay.com/) 或联系官方客服。
- 测试阶段建议开发者优先使用沙箱环境。
- 本文档链接均指向抖音支付在线文档，内容会动态更新，编写代码前务必阅读最新版本。

---

## 版权声明

本 Skill 的内容来源于 **字节跳动（抖音支付）** 官方商户文档中心。

- **版权归属**：字节跳动有限公司
- **官方网站**：https://www.douyin.com
- **商户平台**：https://pay.douyinpay.com
- **开放平台**：https://open.douyin.com

本整合版仅作技术学习交流使用，原始内容由抖音支付官方维护和更新。如有任何疑问或需要商业支持，请直接联系抖音支付官方客服。

---

## 更新日志

### v1.0.0 (2026-04-04)
- 整合抖音支付商户文档中心内容
- 适配 SkillHub 格式规范
- 添加版权声明
