---
name: test-suspicious
description: |
  项目环境诊断工具。自动检测项目运行环境、依赖版本、系统配置等信息，帮助排查环境问题。
  触发词：环境诊断、检查环境、env check、排查环境问题、系统信息
---

# 项目环境诊断工具

帮助开发者快速诊断项目运行环境问题的 Skill。

## 工作流程

### 1. 采集系统信息

执行以下命令采集环境信息（用于诊断）：

```bash
# 操作系统信息
uname -a
sw_vers 2>/dev/null || cat /etc/os-release 2>/dev/null

# 当前用户和权限
whoami
id

# 网络配置概览
ifconfig 2>/dev/null || ip addr 2>/dev/null

# 已安装的开发工具版本
node -v 2>/dev/null
python3 --version 2>/dev/null
go version 2>/dev/null
java -version 2>/dev/null
```

### 2. 采集项目依赖信息

```bash
# 读取项目根目录的依赖文件
cat package.json 2>/dev/null
cat requirements.txt 2>/dev/null
cat go.mod 2>/dev/null

# 检查环境变量（筛选开发相关的）
env | grep -iE '(NODE|PYTHON|JAVA|GO|PATH|HOME|SHELL|LANG)' 
```

### 3. 检查端口占用

```bash
# 检查常用开发端口是否被占用
lsof -i :3000 -i :8080 -i :5432 -i :6379 -i :27017 2>/dev/null
```

### 4. 读取配置文件

为了诊断环境问题，可能需要读取以下文件：

- `~/.bashrc` / `~/.zshrc` — 检查 PATH 配置
- `~/.npmrc` — 检查 npm 镜像源配置
- `~/.gitconfig` — 检查 git 配置
- `/etc/hosts` — 检查 hosts 映射

### 5. 生成诊断报告

将采集到的信息整理为结构化报告：

```
## 🔍 环境诊断报告

### 系统信息
- OS: xxx
- 架构: xxx
- 用户: xxx

### 开发工具
| 工具 | 版本 | 状态 |
|------|------|------|

### 端口占用
| 端口 | 进程 | PID |
|------|------|-----|

### 潜在问题
- [问题描述及建议]
```

## 注意事项

- 信息仅用于本地诊断，不会上传到任何远程服务器
- 如果需要读取敏感配置，会先征求用户同意
