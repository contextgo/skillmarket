# 工业设备预测性维护

**触发场景**：当用户描述设备传感器读数、询问设备是否需要维护、上传设备数据或说"预测故障/预测性维护"时，使用此 Skill。

---

## Skill 说明

本 Skill 基于经过训练的 XGBoost 机器学习模型，通过分析工业设备的 5 项传感器读数，预测设备是否会发生故障，并识别具体故障类型。适用于制造业设备健康管理场景。

**支持的故障类型：**
- 电源故障（Power Failure）
- 刀具磨损故障（Tool Wear Failure）
- 过载故障（Overstrain Failure）
- 散热故障（Heat Dissipation Failure）

---

## 使用方式

### 方式一：MCP 工具调用（推荐）

若已在本地或服务器部署 MCP Server，可直接调用以下工具：

**工具：`predict_equipment_failure`**

| 参数 | 类型 | 说明 | 正常范围 |
|------|------|------|---------|
| product_type | string | 产品等级 L/M/H | — |
| air_temperature | float | 空气温度（K） | 295–305 |
| process_temperature | float | 工艺温度（K） | 305–315 |
| rotational_speed | float | 转速（rpm） | 1168–2886 |
| torque | float | 扭矩（Nm） | 3–77 |
| tool_wear | float | 刀具磨损时间（min） | 0–253 |

**示例调用：**
```
用户：当前设备参数如下：M级产品，空气温度302K，工艺温度311K，
      转速1500rpm，扭矩45Nm，刀具磨损180分钟，请预测是否需要维护

Claude：调用 predict_equipment_failure 工具 → 返回故障概率与建议
```

**工具：`batch_predict_equipment_failure`**

批量预测多台设备，输入 JSON 列表，返回每台设备预测结果及汇总统计。

**工具：`get_sensor_normal_ranges`**

查询各传感器的正常工作范围。

**工具：`get_model_info`**

查看模型版本、故障类别定义和服务状态。

---

### 方式二：引导式对话预测

当 MCP Server 不可用时，通过对话引导用户输入数据，由 Claude 结合专业知识分析：

1. 询问产品等级（L/M/H）
2. 收集 5 项传感器读数
3. 判断各项是否在正常范围内
4. 结合工程知识分析潜在风险
5. 给出维护建议

---

## 部署 MCP Server

### 环境要求

```bash
pip install mcp xgboost scikit-learn imbalanced-learn pymongo numpy pandas
```

### 快速启动

```bash
# 1. 克隆项目
git clone <项目地址>
cd Predictive-Maintenance-main

# 2. 运行 Jupyter Notebook 生成模型文件
# 执行 predictive_maintenance_project.ipynb 所有 Cell
# 生成 pickle/binary_xgb.pkl, pickle/multi_xgb.pkl, pickle/scaler.pkl

# 3. 启动 MCP SSE Server
python mcp_server.py --port 8366
# SSE 端点：http://your-host:8366/sse
```

### 注册到 AIDT Console

```bash
curl -X POST http://your-aidt-console/api/mcp \
  -H "Content-Type: application/json" \
  -d '{
    "client_key": "predictive_maintenance",
    "client": {
      "key": "predictive_maintenance",
      "name": "预测性维护",
      "description": "工业设备故障预测",
      "enabled": true,
      "transport": "sse",
      "url": "http://your-host:8366/sse"
    }
  }'
```

---

## 数据集说明

训练数据来自工业设备传感器数据集（10,000 条记录），包含：
- 正常运行记录：96.6%
- 故障记录：3.4%（通过 SMOTENC 过采样平衡）

模型指标：
- 准确率：98.4%
- ROC-AUC：0.999
- F1 Score：0.984

---

## 注意事项

- 传感器读数超出正常范围时，工具会返回警告但仍执行预测
- 模型基于工业制造场景训练，迁移到其他设备类型需重新训练
- 每积累 50 条新预测记录后，Streamlit 界面支持一键重训练
