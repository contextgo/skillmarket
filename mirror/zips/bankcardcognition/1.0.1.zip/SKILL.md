---
name: jisu-bankcardcognition
description: 使用极速数据银行卡识别 API，对银行卡图片进行 OCR 识别，返回卡号、卡类型、银行名称等信息。
metadata: { "openclaw": { "emoji": "💳", "requires": { "bins": ["python3"], "env": ["JISU_API_KEY"] }, "primaryEnv": "JISU_API_KEY" } }
---

## 极速数据银行卡识别（Jisu BankCardCognition）

基于 [银行卡识别 API](https://www.jisuapi.com/api/bankcardcognition/) 的 OpenClaw 技能，可对银行卡照片进行 OCR 识别，返回：

- `number`：银行卡号
- `type`：银行卡类型（借记卡/信用卡等）
- `bankname`：银行名称
- `bankno`：银行编号

使用前需要在极速数据官网申请服务，文档见：[https://www.jisuapi.com/api/bankcardcognition/](https://www.jisuapi.com/api/bankcardcognition/)

## 环境变量配置

```bash
# Linux / macOS
export JISU_API_KEY="your_appkey_here"

# Windows PowerShell
$env:JISU_API_KEY="your_appkey_here"
```

## 脚本路径

脚本文件：`skills/bankcardcognition/bankcardcognition.py`

## 使用方式与请求参数

当前脚本封装了 `/bankcardcognition/recognize` 接口，统一通过一段 JSON 调用。

### 1. 从本地图片识别银行卡（推荐）

```bash
python3 skills/bankcardcognition/bankcardcognition.py '{"path":"bankcard.jpg"}'
```

- `path`：本地银行卡图片路径（脚本会读取并转为 base64），建议使用较清晰的 JPG/PNG，大小不超过 500K。

### 2. 直接传 base64 图片内容

如果前置流程已经将图片转为 base64，可以直接传 `pic` 字段：

```bash
python3 skills/bankcardcognition/bankcardcognition.py '{
  "pic": "<base64_string>"
}'
```

> 注意：`pic` 只需要纯 base64 内容，不要带 `data:image/...;base64,` 前缀。

### 3. 请求参数说明

| 字段名 | 类型   | 必填 | 说明 |
|--------|--------|------|------|
| path   | string | 二选一 | 本地图片路径，脚本会自动读取并转为 base64 |
| image  | string | 二选一 | `path` 的别名 |
| file   | string | 二选一 | `path` 的别名 |
| pic    | string | 二选一 | 已是 base64 的图片内容（不带前缀） |

`path/image/file` 与 `pic` 至少提供一个，同时存在时优先使用 `pic`。

## 返回结果说明

原始接口返回结构示例（参考官网文档）：

```json
{
  "status": 0,
  "msg": "ok",
  "result": {
    "number": "9559980210010631815",
    "type": "借记卡",
    "bankname": "农业银行",
    "bankno": "01030000"
  }
}
```

本技能会直接输出 `result` 对象，例如：

```json
{
  "number": "9559980210010631815",
  "type": "借记卡",
  "bankname": "农业银行",
  "bankno": "01030000"
}
```

当出现业务错误（如图片为空、格式错误、大小超限等）时，统一包装为：

```json
{
  "error": "api_error",
  "code": 201,
  "message": "图片为空"
}
```

网络或解析错误则返回：

```json
{
  "error": "request_failed" | "http_error" | "invalid_json",
  "message": "...",
  "status_code": 500
}
```

## 常见错误码

来源于 [银行卡识别文档](https://www.jisuapi.com/api/bankcardcognition/)：

| 代号 | 说明               |
|------|--------------------|
| 201  | 图片为空           |
| 202  | 图片格式错误       |
| 204  | 图片大小超过限制   |
| 208  | 识别失败           |
| 210  | 没有信息           |

系统错误码 101–108 与其它极速数据接口一致。

## 在 OpenClaw 中的推荐用法

1. 用户上传一张银行卡照片，希望确认卡号、银行名称或卡类型。  
2. 代理将图片保存为本地文件或转为 base64，调用：`python3 skills/bankcardcognition/bankcardcognition.py '{"path":"bankcard.jpg"}'`。  
3. 从返回结果中读取 `number/type/bankname/bankno` 字段，用自然语言总结，并根据场景提醒注意隐私和安全，仅在安全环境下展示或存储卡号信息。  

