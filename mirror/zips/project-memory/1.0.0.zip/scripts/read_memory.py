#!/usr/bin/env python3
import os
import re
import sys


def read_file(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return f.read()
    except FileNotFoundError:
        return None
    except Exception as e:
        print(f"读取错误: {e}")
        return None


def read_main_memory(project_root="."):
    memory_file = os.path.join(project_root, ".memory", "project-memory.md")
    return read_file(memory_file)

def read_sub_file(project_root, filename):
    sub_file = os.path.join(project_root, ".memory", filename)
    return read_file(sub_file)

def read_archive(project_root, archive_name):
    archive_path = os.path.join(project_root, ".memory", "archive", archive_name)
    return read_file(archive_path)

def list_sub_files(project_root):
    memory_dir = os.path.join(project_root, ".memory")
    
    if not os.path.exists(memory_dir):
        return []
    
    sub_files = []
    for f in os.listdir(memory_dir):
        if f.endswith('.md') and f != 'project-memory.md':
            sub_files.append(f)
    
    return sorted(sub_files)

def list_archives(project_root):
    archive_dir = os.path.join(project_root, ".memory", "archive")
    
    if not os.path.exists(archive_dir):
        return []
    
    return sorted([f for f in os.listdir(archive_dir) if f.endswith('.md')])

def extract_summary(content):
    summary = {}
    
    title_match = re.search(r'^# (.+)$', content, re.MULTILINE)
    if title_match:
        summary['项目名称'] = title_match.group(1).strip()
    
    current_phase_match = re.search(r'\*\*阶段 \d+:[^\*]+\*\*\s*\[([^\]]+)\]', content)
    if current_phase_match:
        summary['当前阶段状态'] = current_phase_match.group(1)
    
    plan_section = re.search(r'## 当前阶段\n(.*?)(?=## |\Z)', content, re.DOTALL)
    if plan_section:
        plan_content = plan_section.group(1)
        completed = len(re.findall(r'- \[x\]', plan_content))
        in_progress = len(re.findall(r'- \[-\]', plan_content))
        pending = len(re.findall(r'- \[ \]', plan_content))
        summary['当前进度'] = f"已完成: {completed}, 进行中: {in_progress}, 待开始: {pending}"
        
        current_tasks = re.findall(r'- \[([ x\-])\] ([^\n]+)', plan_content)
        summary['当前任务'] = current_tasks[:5]
    
    history_section = re.search(r'## 阶段历史\n(.*?)(?=## |\Z)', content, re.DOTALL)
    if history_section:
        archived = len(re.findall(r'\[已完成\]', history_section.group(1)))
        if archived > 0:
            summary['已完成阶段'] = archived
    
    updates_section = re.search(r'## 最近更新\n(.*?)(?=## |\Z)', content, re.DOTALL)
    if updates_section:
        recent_updates = re.findall(r'- \*\*(.+?)\*\*:\s*(.+)', updates_section.group(1))
        summary['最近更新'] = recent_updates[:3]
    
    return summary

def print_summary(summary, project_root="."):
    if not summary:
        return
    
    print("=" * 50)
    print(f"📁 项目：{summary.get('项目名称', '未知')}")
    print("=" * 50)
    
    if '当前阶段状态' in summary:
        print(f"📍 当前阶段：{summary['当前阶段状态']}")
    
    if '当前进度' in summary:
        print(f"📊 {summary['当前进度']}")
    
    if '已完成阶段' in summary:
        print(f"📦 已完成阶段：{summary['已完成阶段']} 个")
    
    if '当前任务' in summary and summary['当前任务']:
        print("\n当前任务：")
        for status, task in summary['当前任务']:
            status_icon = "✅" if status == "x" else "🔄" if status == "-" else "⏳"
            print(f"   {status_icon} {task}")
    
    if '最近更新' in summary and summary['最近更新']:
        print("\n📝 最近更新：")
        for date, desc in summary['最近更新']:
            print(f"   {date}: {desc}")
    
    sub_files = list_sub_files(project_root)
    if sub_files:
        print(f"\n📄 详细文档（按需读取）：")
        for sf in sub_files:
            print(f"   - {sf}")
    
    archives = list_archives(project_root)
    if archives:
        print(f"\n📂 归档文件（{len(archives)} 个）：")
        for archive in archives[:3]:
            print(f"   - {archive}")
        if len(archives) > 3:
            print(f"   ... 还有 {len(archives) - 3} 个")
    
    print("\n" + "=" * 50)
    print("💡 提示：如需查看详细文档，请告诉我具体需求")
    print("=" * 50)

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="读取模块化项目记忆")
    parser.add_argument("--root", "-r", default=".", help="项目根目录")
    parser.add_argument("--format", "-f", choices=["full", "summary"], 
                        default="full", help="输出格式")
    parser.add_argument("--file", help="读取特定子文件（如：project-background.md）")
    parser.add_argument("--archive", "-a", help="读取指定归档文件")
    parser.add_argument("--list", "-l", action="store_true",
                        help="列出所有可用文件")
    
    args = parser.parse_args()
    
    if args.list:
        print("主文件：")
        print("  - project-memory.md")
        print("\n详细文档：")
        for sf in list_sub_files(args.root):
            print(f"  - {sf}")
        print("\n归档文件：")
        archives = list_archives(args.root)
        if archives:
            for archive in archives:
                print(f"  - {archive}")
        else:
            print("  （暂无）")
        sys.exit(0)
    
    if args.file:
        result = read_sub_file(args.root, args.file)
        if result:
            print(result)
        else:
            print(f"错误：文件不存在：{args.file}")
            sys.exit(1)
    elif args.archive:
        result = read_archive(args.root, args.archive)
        if result:
            print(result)
        else:
            print(f"错误：归档不存在：{args.archive}")
            sys.exit(1)
    else:
        result = read_main_memory(args.root)
        
        if result is None:
            print("错误：项目记忆不存在")
            sys.exit(1)
        
        if args.format == "summary":
            summary = extract_summary(result)
            print_summary(summary, args.root)
        else:
            print(result)
    
    sys.exit(0)
