#!/usr/bin/env python3
import os
import re
import sys
from datetime import datetime

def archive_phase(project_root, phase_number, phase_name, summary=""):
    memory_file = os.path.join(project_root, ".memory", "project-memory.md")
    dev_docs_dir = os.path.join(project_root, ".memory", "dev-docs")
    archive_dir = os.path.join(project_root, ".memory", "archive")
    
    if not os.path.exists(memory_file):
        print(f"错误：项目记忆文件不存在：{memory_file}")
        return False
    
    with open(memory_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    phase_pattern = rf'(?:###|\*\*)\s*阶段\s*{phase_number}:[^\n]*\n(.*?)(?=(?:###|\*\*)\s*阶段|\n## |\Z)'
    match = re.search(phase_pattern, content, re.DOTALL)
    
    if not match:
        print(f"错误：未找到阶段 {phase_number}")
        return False
    
    phase_content = match.group(0)
    os.makedirs(archive_dir, exist_ok=True)
    
    archive_filename = f"phase-{phase_number}-{phase_name}.md"
    archive_path = os.path.join(archive_dir, archive_filename)
    
    today = datetime.now().strftime("%Y-%m-%d")
    
    components = collect_dev_docs(dev_docs_dir, "components")
    hooks = collect_dev_docs(dev_docs_dir, "hooks")
    utils = collect_dev_docs(dev_docs_dir, "utils")
    apis = collect_dev_docs(dev_docs_dir, "api")
    databases = collect_dev_docs(dev_docs_dir, "database")
    
    archive_content = f"""# 阶段 {phase_number}: {phase_name} [归档]

## 基本信息
- **归档时间**: {today}
- **阶段名称**: {phase_name}
- **阶段周期**: （待补充）

## 阶段总结
{summary if summary else "（请补充本阶段完成的主要工作和目标达成情况）"}

## 任务完成情况
{phase_content}

## 技术决策记录
（记录本阶段做出的重要技术决策和原因）

## 遇到的问题与解决方案
（记录开发中遇到的问题和解决方法）

## 代码统计
- 新增文件: （待统计）
- 代码行数: （待统计）
- 测试覆盖率: （待统计）

## 开发文档清单

### 公共组件 ({len(components)}个)
{format_doc_list(components) if components else "（本阶段无新增组件）"}

### 自定义 Hooks ({len(hooks)}个)
{format_doc_list(hooks) if hooks else "（本阶段无新增Hooks）"}

### 工具函数 ({len(utils)}个)
{format_doc_list(utils) if utils else "（本阶段无新增工具函数）"}

### API接口 ({len(apis)}个)
{format_doc_list(apis) if apis else "（本阶段无新增API）"}

### 数据库表 ({len(databases)}个)
{format_doc_list(databases) if databases else "（本阶段无新增数据库表）"}

## 接口变更记录
（记录API接口的增删改）

## 数据库变更记录
（记录数据库schema的变更）

## 依赖变更
（记录新增或升级的依赖包）

## 性能优化记录
（记录性能优化措施和效果）

## 下阶段准备
（为下阶段工作做的准备和注意事项）

---
**注意**: 此归档文件包含详细的阶段总结和组件清单。开发文档(dev-docs/)中的内容会保留，请确保在更新代码时同步更新相关文档。
"""
    
    with open(archive_path, 'w', encoding='utf-8') as f:
        f.write(archive_content)
    
    print(f"成功创建归档文件：{archive_path}")
    
    completed_tasks = re.findall(r'- \[x\] (.+)', phase_content)
    summary_tasks = completed_tasks[:3] if completed_tasks else ["阶段任务"]
    
    simple_phase = f"""### 阶段 {phase_number}: {phase_name} [已完成]
- **完成时间**: {today}
- **主要成果**: {', '.join(summary_tasks)}...
- **归档文件**: [{archive_filename}](archive/{archive_filename})

"""
    
    new_content = content.replace(phase_content, simple_phase)
    update_log = f"- **{today}**: 归档阶段 {phase_number} ({phase_name})\n"
    
    updates_match = re.search(r'(## 最近更新\n)', new_content)
    if updates_match:
        insert_pos = updates_match.end()
        new_content = new_content[:insert_pos] + update_log + new_content[insert_pos:]
    
    with open(memory_file, 'w', encoding='utf-8') as f:
        f.write(new_content)
    
    print(f"成功更新主文件，阶段 {phase_number} 已归档")
    return True

def collect_dev_docs(dev_docs_dir, category):
    category_dir = os.path.join(dev_docs_dir, category)
    if not os.path.exists(category_dir):
        return []
    
    files = [f for f in os.listdir(category_dir) if f.endswith('.md')]
    return sorted(files)

def format_doc_list(files):
    if not files:
        return ""
    
    lines = []
    for f in files:
        name = f.replace('.md', '')
        lines.append(f"- [{name}](../dev-docs/{f})")
    return '\n'.join(lines)

def list_archives(project_root):
    archive_dir = os.path.join(project_root, ".memory", "archive")
    
    if not os.path.exists(archive_dir):
        print("暂无归档文件")
        return []
    
    archives = sorted([f for f in os.listdir(archive_dir) if f.endswith('.md')])
    
    if not archives:
        print("暂无归档文件")
        return []
    
    print(f"\n发现 {len(archives)} 个归档文件：\n")
    for i, archive in enumerate(archives, 1):
        print(f"  {i}. {archive}")
    
    return archives

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="归档项目阶段（增强版）")
    parser.add_argument("--root", "-r", default=".", help="项目根目录")
    
    subparsers = parser.add_subparsers(dest="command", help="子命令")
    
    archive_parser = subparsers.add_parser("archive", help="归档一个阶段")
    archive_parser.add_argument("--phase", "-p", type=int, required=True, help="阶段编号")
    archive_parser.add_argument("--name", "-n", required=True, help="阶段名称")
    archive_parser.add_argument("--summary", "-s", default="", help="阶段总结")
    
    list_parser = subparsers.add_parser("list", help="列出所有归档")
    
    args = parser.parse_args()
    
    if args.command == "archive":
        success = archive_phase(args.root, args.phase, args.name, args.summary)
    elif args.command == "list":
        list_archives(args.root)
        success = True
    else:
        parser.print_help()
        sys.exit(1)
    
    sys.exit(0 if success else 1)
