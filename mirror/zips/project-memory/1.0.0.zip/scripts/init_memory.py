#!/usr/bin/env python3
import os
import sys
from datetime import datetime

MAIN_TEMPLATE = """# {project_name}

## 项目索引
- **文件导航**: [查看详情](00-index.md)
- **项目背景**: [查看详情](01-project-background.md)
- **需求方案**: [查看详情](02-requirements.md)
- **开发规范**: [查看详情](03-dev-specs.md)
- **技术栈**: [查看详情](04-tech-stack.md)
- **数据库定义**: [查看详情](05-database-schema.md)
- **项目结构**: [查看详情](06-project-structure.md)
- **开发文档**: [查看 dev-docs/](dev-docs/)

## 当前阶段
**阶段 1: 初始化** [进行中]
- [ ] 搭建项目框架
- [ ] 配置开发环境
- [ ] 建立基础规范

## 阶段历史
（暂无已完成阶段）

## 最近更新
- **{created_date}**: 初始化项目记忆
"""

INDEX_TEMPLATE = """# 文件索引

## 必读文件
- **project-memory.md** - 主文件，项目概览和当前进度

## 开发文档（上下文必读）
- **dev-docs/README.md** - 开发文档说明
- **dev-docs/index.md** - 组件/工具/API索引

## 详细文档（按需读取）
- **01-project-background.md** - 项目背景、目标、相关链接
- **02-requirements.md** - 需求方案、功能需求、用户故事
- **03-dev-specs.md** - 代码规范、提交规范、分支策略
- **04-tech-stack.md** - 前端、后端、基础设施技术栈
- **05-database-schema.md** - 数据库表定义、字段、关系
- **06-project-structure.md** - 目录结构说明

## 归档历史
- **archive/** - 已完成阶段的详细记录
"""

BACKGROUND_TEMPLATE = """# 项目背景

## 基本信息
- **创建时间**: {created_date}
- **项目目标**: {project_goal}
- **目标用户**: （待补充）
- **预期成果**: （待补充）

## 相关链接
- 设计稿: （待补充）
- 原型: （待补充）
- API文档: （待补充）
- 其他资源: （待补充）
"""

REQUIREMENTS_TEMPLATE = """# 需求方案

## 功能需求
（待补充）

## 非功能需求
- 性能: （待补充）
- 安全: （待补充）
- 兼容性: （待补充）

## 用户故事
（待补充）
"""

DEV_SPECS_TEMPLATE = """# 开发规范

## 代码风格
（待补充）

## 提交规范
（待补充）

## 分支策略
（待补充）

## 命名约定
- 组件: （待补充）
- 函数: （待补充）
- 变量: （待补充）
- 常量: （待补充）
"""

TECH_STACK_TEMPLATE = """# 技术栈

## 前端
- **框架**: （待补充）
- **语言**: （待补充）
- **状态管理**: （待补充）
- **UI库**: （待补充）

## 后端
- **框架**: （待补充）
- **语言**: （待补充）
- **数据库**: （待补充）
- **缓存**: （待补充）

## 基础设施
- **部署**: （待补充）
- **CI/CD**: （待补充）
- **监控**: （待补充）
"""

DATABASE_TEMPLATE = """# 数据库定义

## 表清单
（待补充）

## 关系图
（待补充）

## 详细定义
每个表单独文件存放在 dev-docs/database/ 目录
"""

STRUCTURE_TEMPLATE = """# 项目结构

```
{project_root}/
├── src/           # 源代码
├── docs/          # 文档
├── tests/         # 测试
└── ...
```

## 目录说明
（待补充）
"""

DEV_DOCS_README = """# 开发文档

## 说明
本文档记录项目中所有的公共组件、工具函数、API接口和数据库定义。

**重要**：更新代码时，请同步更新本文档，防止重复定义。

## 目录结构
- **components/** - 公共组件文档
- **hooks/** - 自定义 Hooks 文档
- **utils/** - 工具函数文档
- **api/** - API接口文档
- **database/** - 数据库表定义

## 文档格式
每个文档应包含：
1. 功能说明
2. 代码定义
3. 调用示例
4. 参数说明
5. 注意事项
"""

DEV_DOCS_INDEX = """# 开发文档索引

## 加载说明
- **此文件为精简索引**，每项一行描述
- **加载策略**：新会话默认加载此文件（<30行）
- **按需加载**：需要某项完整定义时，读取对应 md 文件

## 公共组件
- Button: 通用按钮组件，支持 primary/secondary/ghost 变体
- Card: 卡片容器组件，支持标题和描述
- Modal: 模态框组件，支持自定义内容和底部按钮
- Table: 表格组件，支持列配置和排序

## 自定义 Hooks
- useAuth: 认证状态管理，返回 user, login, logout
- useFetch: 数据获取 hook，支持 loading 和 error 状态
- useModal: 模态框状态管理

## 工具函数
- formatDate: 日期格式化，支持自定义格式
- debounce: 防抖函数，用于高频事件处理
- validate: 表单验证函数集合

## API 接口
- /api/auth/login: 用户登录
- /api/auth/logout: 用户登出
- /api/users: 用户 CRUD

## 数据库表
- users: 用户表，含 username, email, password_hash
- products: 商品表，含 name, price, stock
- orders: 订单表，含 user_id, total, status
"""

def init_memory(project_name, project_goal="", project_root="."):
    memory_dir = os.path.join(project_root, ".memory")
    
    if os.path.exists(os.path.join(memory_dir, "project-memory.md")):
        print(f"错误：项目记忆已存在：{memory_dir}/project-memory.md")
        return False
    
    os.makedirs(memory_dir, exist_ok=True)
    
    created_date = datetime.now().strftime("%Y-%m-%d")
    project_root_name = os.path.basename(os.path.abspath(project_root))
    
    files = {
        "project-memory.md": MAIN_TEMPLATE.format(
            project_name=project_name,
            created_date=created_date
        ),
        "00-index.md": INDEX_TEMPLATE,
        "01-project-background.md": BACKGROUND_TEMPLATE.format(
            created_date=created_date,
            project_goal=project_goal or "（待补充）"
        ),
        "02-requirements.md": REQUIREMENTS_TEMPLATE,
        "03-dev-specs.md": DEV_SPECS_TEMPLATE,
        "04-tech-stack.md": TECH_STACK_TEMPLATE,
        "05-database-schema.md": DATABASE_TEMPLATE,
        "06-project-structure.md": STRUCTURE_TEMPLATE.format(
            project_root=project_root_name
        ),
    }
    
    for filename, content in files.items():
        filepath = os.path.join(memory_dir, filename)
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"  创建: {filename}")
    
    dev_docs_dir = os.path.join(memory_dir, "dev-docs")
    os.makedirs(dev_docs_dir, exist_ok=True)
    os.makedirs(os.path.join(dev_docs_dir, "components"), exist_ok=True)
    os.makedirs(os.path.join(dev_docs_dir, "hooks"), exist_ok=True)
    os.makedirs(os.path.join(dev_docs_dir, "utils"), exist_ok=True)
    os.makedirs(os.path.join(dev_docs_dir, "api"), exist_ok=True)
    os.makedirs(os.path.join(dev_docs_dir, "database"), exist_ok=True)
    
    with open(os.path.join(dev_docs_dir, "README.md"), 'w', encoding='utf-8') as f:
        f.write(DEV_DOCS_README)
    print(f"  创建: dev-docs/README.md")
    
    with open(os.path.join(dev_docs_dir, "index.md"), 'w', encoding='utf-8') as f:
        f.write(DEV_DOCS_INDEX)
    print(f"  创建: dev-docs/index.md")
    
    archive_dir = os.path.join(memory_dir, "archive")
    os.makedirs(archive_dir, exist_ok=True)
    print(f"  创建: archive/")
    
    print(f"\n成功创建项目记忆（{len(files)+3}个文件 + 5个目录）:")
    print(f"  位置: {memory_dir}/")
    print(f"  主文件: project-memory.md（轻量级，<30行）")
    print(f"  索引文件: 00-index.md（文件导航）")
    print(f"  详细文档: 6个（按需读取）")
    print(f"  开发文档: dev-docs/（上下文必读）")
    print(f"  归档目录: archive/（阶段历史）")
    return True

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="初始化增强版项目记忆")
    parser.add_argument("project_name", help="项目名称")
    parser.add_argument("--goal", "-g", default="", help="项目目标")
    parser.add_argument("--root", "-r", default=".", help="项目根目录")
    
    args = parser.parse_args()
    
    success = init_memory(
        project_name=args.project_name,
        project_goal=args.goal,
        project_root=args.root
    )
    
    sys.exit(0 if success else 1)
