#!/usr/bin/env python3
import os
import re
import sys
from datetime import datetime

def update_section(project_root, section_name, new_content, mode="replace"):
    memory_file = os.path.join(project_root, ".memory", "project-memory.md")
    
    if not os.path.exists(memory_file):
        print(f"错误：项目记忆文件不存在：{memory_file}")
        return False
    
    with open(memory_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    section_pattern = rf'(## {section_name}\n)(.*?)(?=\n## |\Z)'
    match = re.search(section_pattern, content, re.DOTALL)
    if not match:
        print(f"错误：未找到章节 '{section_name}'")
        return False
    
    old_section = match.group(0)
    
    if mode == "append":
        updated_section = old_section.rstrip() + "\n" + new_content + "\n"
    else:
        updated_section = f"## {section_name}\n{new_content}\n"
    
    new_content_full = content.replace(old_section, updated_section)
    
    with open(memory_file, 'w', encoding='utf-8') as f:
        f.write(new_content_full)
    
    print(f"成功更新章节：{section_name}")
    return True

def add_update_log(project_root, message):
    memory_file = os.path.join(project_root, ".memory", "project-memory.md")
    
    if not os.path.exists(memory_file):
        print(f"错误：项目记忆文件不存在：{memory_file}")
        return False
    
    with open(memory_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    section_pattern = r'(## 最近更新\n)'
    match = re.search(section_pattern, content)
    
    if not match:
        print("错误：未找到'最近更新'章节")
        return False
    
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    new_log = f"- **{now}**: {message}\n"
    
    insert_pos = match.end()
    new_content = content[:insert_pos] + new_log + content[insert_pos:]
    
    with open(memory_file, 'w', encoding='utf-8') as f:
        f.write(new_content)
    
    print(f"成功添加更新记录：{message}")
    return True

def update_dev_docs_index(project_root):
    dev_docs_dir = os.path.join(project_root, ".memory", "dev-docs")
    index_file = os.path.join(dev_docs_dir, "index.md")
    
    if not os.path.exists(dev_docs_dir):
        print("错误：dev-docs 目录不存在")
        return False
    
    def scan_directory(dir_path):
        items = []
        if not os.path.exists(dir_path):
            return items
        
        for filename in sorted(os.listdir(dir_path)):
            if not filename.endswith('.md') or filename == 'index.md':
                continue
            
            filepath = os.path.join(dir_path, filename)
            name = filename[:-3]
            description = ""
            
            try:
                with open(filepath, 'r', encoding='utf-8') as f:
                    content = f.read()
                    lines = content.split('\n')
                    for line in lines:
                        line = line.strip()
                        if line.startswith('# '):
                            continue
                        if line and not line.startswith('##'):
                            description = line
                            break
                    
                    if not description:
                        description = f"{name} 组件/工具"
            except Exception:
                description = f"{name} 组件/工具"
            
            items.append((name, description))
        
        return items
    
    components = scan_directory(os.path.join(dev_docs_dir, "components"))
    hooks = scan_directory(os.path.join(dev_docs_dir, "hooks"))
    utils = scan_directory(os.path.join(dev_docs_dir, "utils"))
    apis = scan_directory(os.path.join(dev_docs_dir, "api"))
    database = scan_directory(os.path.join(dev_docs_dir, "database"))
    
    new_index = """# 开发文档索引

## 加载说明
- **此文件为精简索引**，每项一行描述
- **加载策略**：新会话默认加载此文件（<30行）
- **按需加载**：需要某项完整定义时，读取对应 md 文件

## 公共组件
"""
    
    if components:
        for name, desc in components:
            new_index += f"- [{name}](components/{name}.md): {desc}\n"
    else:
        new_index += "（暂无组件）\n"
    
    new_index += "\n## 自定义 Hooks\n"
    if hooks:
        for name, desc in hooks:
            new_index += f"- [{name}](hooks/{name}.md): {desc}\n"
    else:
        new_index += "（暂无 Hooks）\n"
    
    new_index += "\n## 工具函数\n"
    if utils:
        for name, desc in utils:
            new_index += f"- [{name}](utils/{name}.md): {desc}\n"
    else:
        new_index += "（暂无工具函数）\n"
    
    new_index += "\n## API 接口\n"
    if apis:
        for name, desc in apis:
            new_index += f"- [{name}](api/{name}.md): {desc}\n"
    else:
        new_index += "（暂无 API）\n"
    
    new_index += "\n## 数据库表\n"
    if database:
        for name, desc in database:
            new_index += f"- [{name}](database/{name}.md): {desc}\n"
    else:
        new_index += "（暂无数据库表）\n"
    
    with open(index_file, 'w', encoding='utf-8') as f:
        f.write(new_index)
    
    total = len(components) + len(hooks) + len(utils) + len(apis) + len(database)
    print(f"成功更新索引：{total} 个条目")
    if components:
        print(f"  - 组件: {len(components)} 个")
    if hooks:
        print(f"  - Hooks: {len(hooks)} 个")
    if utils:
        print(f"  - 工具: {len(utils)} 个")
    if apis:
        print(f"  - API: {len(apis)} 个")
    if database:
        print(f"  - 数据库: {len(database)} 个")
    
    return True

def update_plan_progress(project_root, task_name, status="completed"):
    memory_file = os.path.join(project_root, ".memory", "project-memory.md")
    
    if not os.path.exists(memory_file):
        print(f"错误：项目记忆文件不存在：{memory_file}")
        return False
    
    with open(memory_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    pattern = rf'(- \[ \]) ({re.escape(task_name)})'
    if status == "completed":
        new_content = re.sub(pattern, r'- [x] \2', content)
    elif status == "in_progress":
        new_content = re.sub(pattern, r'- [-] \2', content)
    else:
        new_content = re.sub(pattern, r'- [ ] \2', content)
    
    if new_content == content:
        print(f"警告：未找到任务 '{task_name}' 或未发生变化")
        return False
    
    with open(memory_file, 'w', encoding='utf-8') as f:
        f.write(new_content)
    
    print(f"成功更新任务状态：{task_name} -> {status}")
    return True

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="更新项目记忆文件")
    parser.add_argument("--root", "-r", default=".", help="项目根目录")
    
    subparsers = parser.add_subparsers(dest="command", help="子命令")
    
    section_parser = subparsers.add_parser("section", help="更新章节")
    section_parser.add_argument("name", help="章节名称")
    section_parser.add_argument("content", help="新内容")
    section_parser.add_argument("--mode", choices=["replace", "append"], 
                                default="replace", help="更新模式")
    
    log_parser = subparsers.add_parser("log", help="添加更新记录")
    log_parser.add_argument("message", help="更新消息")
    
    plan_parser = subparsers.add_parser("plan", help="更新任务状态")
    plan_parser.add_argument("task", help="任务名称")
    plan_parser.add_argument("--status", choices=["completed", "in_progress", "pending"],
                            default="completed", help="新状态")
    
    index_parser = subparsers.add_parser("index", help="更新 dev-docs 索引")
    
    args = parser.parse_args()
    
    if args.command == "section":
        success = update_section(args.root, args.name, args.content, args.mode)
    elif args.command == "log":
        success = add_update_log(args.root, args.message)
    elif args.command == "plan":
        success = update_plan_progress(args.root, args.task, args.status)
    elif args.command == "index":
        success = update_dev_docs_index(args.root)
    else:
        parser.print_help()
        sys.exit(1)
    
    sys.exit(0 if success else 1)