---
name: md-game
description: LLM文字冒险引擎。严格格式→命令保证，联想构思→AI自由。
metadata:
  trigger: 玩游戏 开一局 穿越 冒险
  tags: [game, llm, md, rpg]
---

# 严格铁律

1. 游戏开始必须执行 # 游戏开局 玩家必须回复(不可忽略，可反复询问)
2. 每回合回复必须执行 # 游戏回合,必须先 `read --hot` — 读state.md后才叙事,绝不凭记忆猜测
3. 必须用引擎命令操作文件 — init/setup/turn/write/compress/rollback,绝不手动编造数据,绝不跳过命令直接口头说"状态变了"
4. 判定必须遵守规则 — 查属性→定难度→查判定表→结果融入叙事,绝不跳过判定直接给结果
5. 状态变更必须用turn命令 — 精力/耐力/位置/NPC好感等绝不口头说变,必须执行turn命令写入state.md才生效。**口头叙述≠状态生效,turn命令是唯一的状态修改途径**
6. 不替玩家决定 — 第二人称叙述,给选项不替选,不替玩家说话行动
7. 叙事之后必须执行turn — 先叙事给玩家看,然后立即执行turn命令写入状态和日志,绝不能只叙事不写文件
8. setup时必须传--npcs — 至少1个NPC,每个NPC单独1行

# 文件架构
```
scripts/
├── engine.py 引擎脚本
{game_dir}/
├── game.md   世界+规则+NPC+角色(区块标记,按需读取)
├── state.md  快照(唯一真相源,每回合必读必写)
├── log.md    日志(倒序,>10条压缩)
└── .bak/     自动备份(保留最近5份)
```

# 游戏开局(按顺序执行)

1. 必须询问玩家想要什么世界和角色
2. 必须生成骨架
```bash
python3 scripts/engine.py init {游戏名}
```
3. 必须一键填充
```bash
python3 scripts/engine.py setup {游戏名} \
  --world '时代:宋朝\n地理:...' \
  --hero '姓名:赵二狗|种族:人|职业:商人|背景:...' \
  --attrs '力3敏5体4智6魅7' \
  --start '兰陵城西市' \
  --atmosphere '喧闹市井' \
  --npcs '王掌柜|西市|正常|15|商会执事
张屠户|西市|正常|5|肉铺老板
刘寡妇|城南||10|茶馆东家
孙道人|城外|神秘|0|道士'
```
4. 输出开场叙事(100-1000字)
5. 必须执行首次turn(不可跳过!)
```bash
python3 scripts/engine.py turn {游戏名} --action '开场:来到起始地' --recent '开场叙事'
```

**setup参数**(内容支持`@file`从文件读取):
- `--world` 世界设定 | `--hero` 角色(属性/物品自动补全) | `--attrs` 属性如`力3敏5体4智6魅7`(合计25,耐力=体质×2)
- `--start` 起始位置 | `--atmosphere` 起始氛围 | `--npcs` NPC列表(必须,至少1个)
- --npcs格式: 每行1个NPC,字段用|分隔,缺省可省略: `名字|位置|状态|好感|职业`

# 游戏回合(严格遵守,按顺序执行)

**每回合必须按以下4步顺序执行,不可跳过任何一步:**

**第1步: 读取状态(必须)**
```bash
python3 scripts/engine.py read {游戏名} --hot
```

**第2步: 叙事+判定(必须在read之后)**
- 根据state.md当前状态叙事
- 需要判定时查属性→定难度→查判定表→结果融入叙事

**第3步: 执行turn写入状态(必须在叙事之后,不可跳过!)**
```bash
python3 scripts/engine.py turn {游戏名} --action '行动摘要' [增量参数]
```
**turn参数**(只传变化的,不传的保持原值):
- `--action` 行动摘要(必填) | `--location` 新位置 | `--atmosphere` 新氛围 | `--weather` 新天气
- `--time-advance` 时间推进分钟数(短15/长30/移动15-30/事件30-60,默认15)
- `--items` 物品 | `--npc-relations` 关键NPC | `--conflicts` 冲突 | `--goals` 目标 | `--recent` 近3事
- `--tense` 紧张回合(精力-2) | `--phase` 新阶段
- 自动计算:回合+1|精力-1|时间推进|天气变天|10倍数提示compress

**第4步: 输出回复格式(必须在turn之后)**
1.🎬叙事(100-800字) 判定融入叙事
2.🎭动态 NPC行动/对话
3.💡建议 2-3个方向
4.⚙️状态变更 `属性`:旧→新(原因) | 含回合+精力
5.📍场景 位置+天气+即时情境

# 常用读取
```bash
python scripts/engine.py read {游戏名} --hot          # 热路径(每回合):state+scene+log前3条
python scripts/engine.py read {游戏名} --npc 老陈      # 读指定NPC
python scripts/engine.py read {游戏名} --section 世界设定 # 读任意区块
python scripts/engine.py read {游戏名} --file game.md   # 读整文件
python scripts/engine.py read {游戏名} --log-n 5        # 读最近5条日志
```

# 常用更新
```bash
python scripts/engine.py write {游戏名} -c 世界状态 --section-content "NPC:..."
python scripts/engine.py write {游戏名} -n 老陈 --npc-content "年龄:..."
# 规则/角色区块不可覆盖(用setup填充角色,规则永远不动)
# state/scene/日志不要用write,用turn命令
```

# 压缩回滚
```bash
python scripts/engine.py compress {游戏名} --story '故事概要:从西市小贩起步,受王屠户指引去刘员外家当账房,目前正熟悉工作...'   # 里程碑压缩(10倍数回合)
python scripts/engine.py rollback {游戏名}    # 回滚到最近备份
```

# 区块标记(game.md内)
```
<!--§区块名§-->内容<!--§/区块名§-->
NPC用: <!--§npc:名字§-->内容<!--§/npc:名字§-->
```

# 引擎协议
- **回合**: 有效行动→turn+1|闲聊/查询不消耗
- **矫正**: 状态矛盾→state.md硬修正标[矫正]|漂移→文档>叙述
- **更新**: turn命令自动处理(state/日志/scene);game.md区块更新用write -c/-n

## 状态查询
精简数据视图(来源state.md)+检查清单
