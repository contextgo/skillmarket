#!/usr/bin/env python3
"""md-game 引擎：严格格式交给命令，联想构思交给AI
核心命令:
  init    初始化(生成骨架)
  setup   一键填充开局
  turn    推进回合(自动计算精力/耐力/日志/scene)
  read    读取状态
  write   更新区块/NPC内容
  compress 里程碑压缩
"""
import argparse
import os
import random
import re
import shutil
import sys

GAMES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'games')
ALLOWED_FILES = {'game.md', 'state.md', 'log.md'}

def find_game(name):
    os.makedirs(GAMES_DIR, exist_ok=True)
    d = os.path.join(GAMES_DIR, name)
    if os.path.isdir(d):
        return d
    matches = [x for x in os.listdir(GAMES_DIR) if name in x]
    if len(matches) == 1:
        return os.path.join(GAMES_DIR, matches[0])
    if len(matches) > 1:
        die(f"游戏名 '{name}' 匹配到多个目录: {', '.join(sorted(matches))}")
    die(f"找不到游戏 '{name}'")

def die(msg):
    print(f"错误: {msg}", file=sys.stderr)
    sys.exit(1)

def fread(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return f.read()
    except FileNotFoundError:
        die(f"文件不存在: {path}")
    except OSError as exc:
        die(f"读取失败: {path} ({exc})")

def fwrite(path, content):
    try:
        with open(path, 'w', encoding='utf-8') as f:
            f.write(content)
    except OSError as exc:
        die(f"写入失败: {path} ({exc})")

def resolve_content(value):
    """解析内容参数: @filepath 从文件读取, - 从stdin读取, 其余原样返回"""
    if value is None:
        return None
    if value == '-':
        return sys.stdin.read()
    if value.startswith('@'):
        path = value[1:]
        if not os.path.isfile(path):
            die(f"引用文件不存在: {path}")
        return fread(path)
    return value

def extract(content, name):
    s = f"<!--§{name}§-->"
    e = f"<!--§/{name}§-->"
    si = content.find(s)
    if si == -1:
        return None
    si += len(s)
    ei = content.find(e, si)
    if ei == -1:
        return None
    return content[si:ei].strip()

def replace_section(content, name, new):
    s = f"<!--§{name}§-->"
    e = f"<!--§/{name}§-->"
    si = content.find(s)
    if si == -1:
        die(f"区块 '{name}' 开标记缺失")
    ei = content.find(e, si + len(s))
    if ei == -1:
        die(f"区块 '{name}' 闭标记缺失")
    ei += len(e)
    return content[:si] + f"{s}\n{new}\n{e}" + content[ei:]

def get_log_entries(content, n=3):
    entries = get_all_log_entries(content)
    return '\n'.join(entries[:n])

def get_all_log_entries(content):
    content_no_comments = re.sub(r'<!--.*?-->', '', content, flags=re.DOTALL)
    return [l.strip() for l in content_no_comments.split('\n')
            if l.strip()
            and not l.strip().startswith('#')
            and not l.strip().startswith('---')
            and not re.match(r'^\[系统:第[^\d]', l.strip())]  # 过滤模板残留如[系统:第X回合...]

def prepend_log(content, line):
    marker = "- 回合"
    pos = content.find(marker)
    if pos == -1:
        pos = content.find("- ")
    if pos == -1:
        hdr = content.find("\n")
        pos = hdr + 1 if hdr != -1 else len(content)
    return content[:pos] + f"- {line}\n" + content[pos:]

def find_npc(game_md, name):
    """模糊匹配NPC区块"""
    matches = re.findall(r'<!--§npc:(.+?)§-->(.*?)<!--§/npc:\1§-->', game_md, re.DOTALL)
    for n, c in matches:
        if name == n:
            return n, c.strip()
    for n, c in matches:
        if name in n:
            return n, c.strip()
    return None, None

def extract_turn(state):
    m = re.search(r'回合:\s*(\d+)', state)
    return int(m.group(1)) if m else 0

def advance_time(cur_time, minutes):
    """推进游戏时间,格式HH:MM,返回新时间和时段"""
    if not cur_time or ':' not in cur_time:
        return '06:00', '清晨'
    try:
        h, m = cur_time.split('(')[0].split(':')
        h, m = int(h), int(m)
    except ValueError:
        return '06:00', '清晨'
    total = h * 60 + m + minutes
    total = total % (24 * 60)  # 环绕
    new_h, new_m = divmod(total, 60)
    return f'{new_h:02d}:{new_m:02d}', get_period(new_h)

def get_period(hour):
    """根据小时返回时段名"""
    if 5 <= hour < 8: return '清晨'
    if 8 <= hour < 11: return '上午'
    if 11 <= hour < 13: return '午间'
    if 13 <= hour < 17: return '下午'
    if 17 <= hour < 19: return '傍晚'
    if 19 <= hour < 22: return '夜晚'
    return '深夜'

def roll_weather(cur_weather=None):
    """天气变天:30%概率变天,返回新天气"""
    weathers = ['晴', '多云', '阴', '小雨', '大雨', '雷暴', '雾', '风', '雪']
    if cur_weather and cur_weather in weathers:
        # 60%保持不变,30%变天,10%极端
        r = random.random()
        if r < 0.6:
            return cur_weather
        if r < 0.9:
            candidates = [w for w in weathers if w != cur_weather and w not in ('雷暴', '雪')]
            return random.choice(candidates) if candidates else cur_weather
        # 极端天气
        return random.choice(['雷暴', '大雨', '雪'])
    return random.choice(weathers[:6])

def check_game(gd):
    """校验游戏文件格式，返回 (ok, errors)"""
    errors = []
    # === game.md ===
    game_path = os.path.join(gd, 'game.md')
    if not os.path.isfile(game_path):
        errors.append("game.md 不存在")
    else:
        game = fread(game_path)
        required_sections = ['世界设定', '规则', '角色', '世界状态', 'scene']
        for sec in required_sections:
            open_tag = f"<!--§{sec}§-->"
            close_tag = f"<!--§/{sec}§-->"
            if open_tag not in game:
                errors.append(f"game.md 缺少区块开标记: {open_tag}")
            elif close_tag not in game:
                errors.append(f"game.md 缺少区块闭标记: {close_tag}")
        npc_blocks = re.findall(r'<!--§(npc:.+?)§-->', game)
        for tag in npc_blocks:
            close = f"<!--§/{tag}§-->"
            if close not in game:
                errors.append(f"game.md NPC区块缺少闭标记: {close}")
        malformed = re.findall(r'<!--§§.*?-->', game)
        if malformed:
            errors.append(f"game.md 存在畸形标记: {malformed}")
    # === state.md ===
    state_path = os.path.join(gd, 'state.md')
    if not os.path.isfile(state_path):
        errors.append("state.md 不存在")
    else:
        state = fread(state_path)
        if '回合:' not in state and '回合：' not in state:
            errors.append("state.md 缺少'回合:'字段(注意不能用'turn:')")
        for field in ['耐力', '精力', '位置', '阶段']:
            if field not in state:
                errors.append(f"state.md 缺少字段: {field}")
        m = re.search(r'精力[:：]\s*(\d+)/(\d+)', state)
        if not m:
            errors.append("state.md 精力格式错误,应为'精力:当前/最大'(如 90/100)")
        m = re.search(r'耐力[:：]\s*(\d+)/(\d+)', state)
        if not m:
            errors.append("state.md 耐力格式错误,应为'耐力:当前/最大'(如 6/6)")
    # === log.md ===
    log_path = os.path.join(gd, 'log.md')
    if not os.path.isfile(log_path):
        errors.append("log.md 不存在")
    else:
        log = fread(log_path)
        if '# 日志' not in log:
            errors.append("log.md 缺少标题行'# 日志...'")
        entries = get_all_log_entries(log)
        bad_entries = [e for e in entries if not e.startswith('- ') and not e.startswith('[系统')]
        if bad_entries:
            errors.append(f"log.md 存在格式不合规的条目(应以'- '或'[系统'开头): {bad_entries[:3]}")
    return len(errors) == 0, errors

# === 备份与回滚 ===

def bak_dir(gd):
    """获取备份目录路径"""
    d = os.path.join(gd, '.bak')
    os.makedirs(d, exist_ok=True)
    return d

def backup(gd, label='write'):
    """备份当前三个游戏文件到 .bak/目录,用时间戳+label命名"""
    bd = bak_dir(gd)
    import time
    ts = time.strftime('%Y%m%d_%H%M%S')
    bak_name = f"{ts}_{label}"
    bak_path = os.path.join(bd, bak_name)
    os.makedirs(bak_path, exist_ok=True)
    for fname in ['game.md', 'state.md', 'log.md']:
        src = os.path.join(gd, fname)
        if os.path.isfile(src):
            shutil.copy2(src, os.path.join(bak_path, fname))
    # 只保留最近5个备份
    backups = sorted(os.listdir(bd))
    if len(backups) > 5:
        for old in backups[:-5]:
            shutil.rmtree(os.path.join(bd, old))
    return bak_name

def rollback_count_path(gd):
    return os.path.join(bak_dir(gd), 'rollback_count')

def incr_rollback(gd):
    """回滚计数+1,超过5次强制结束游戏"""
    p = rollback_count_path(gd)
    count = 0
    if os.path.isfile(p):
        try:
            count = int(fread(p).strip())
        except ValueError:
            count = 0
    count += 1
    fwrite(p, str(count))
    if count >= 5:
        # 强制结束游戏
        state_path = os.path.join(gd, 'state.md')
        if os.path.isfile(state_path):
            state = fread(state_path)
            state = re.sub(r'阶段:.*', '阶段:`ended`', state)
            fwrite(state_path, state)
        print(f"\033[91m🚨 连续回滚{count}次! 文件结构严重损坏,游戏已强制终止!\033[0m", file=sys.stderr)
        print(f"\033[91m   请手动检查游戏文件,修复后修改state.md阶段为`playing`\033[0m", file=sys.stderr)
        sys.exit(2)
    return count

def clear_rollback(gd):
    """操作成功,清零回滚计数"""
    p = rollback_count_path(gd)
    if os.path.isfile(p):
        os.remove(p)

def restore(gd, bak_name):
    """从备份恢复文件"""
    bd = bak_dir(gd)
    bak_path = os.path.join(bd, bak_name)
    if not os.path.isdir(bak_path):
        die(f"备份不存在: {bak_name}")
    for fname in ['game.md', 'state.md', 'log.md']:
        src = os.path.join(bak_path, fname)
        dst = os.path.join(gd, fname)
        if os.path.isfile(src):
            shutil.copy2(src, dst)
    count = incr_rollback(gd)
    print(f"已回滚到备份: {bak_name} (连续回滚{count}/5)")

def list_backups(gd):
    """列出所有备份"""
    bd = bak_dir(gd)
    backups = sorted(os.listdir(bd))
    if not backups:
        print("无备份")
        return []
    for b in backups:
        print(f"  {b}")
    return backups

# === 命令 ===

def cmd_read(args):
    gd = find_game(args.game)

    # 热路径: snapshot + scene + log
    if args.hot:
        state = fread(os.path.join(gd, 'state.md'))
        game = fread(os.path.join(gd, 'game.md'))
        log = fread(os.path.join(gd, 'log.md'))
        scene = extract(game, 'scene') or ''
        log_entries = get_log_entries(log, args.log_n)
        print(f"[SNAPSHOT]\n{state}")
        print(f"\n[SCENE]\n{scene}")
        print(f"\n[LOG]\n{log_entries}")
        # 状态警告
        phase_m = re.search(r'阶段[:：]\s*`?(\w+)`?', state)
        turn_m = re.search(r'回合[:：]\s*(\d+)', state)
        phase = phase_m.group(1) if phase_m else ''
        turn = int(turn_m.group(1)) if turn_m else 0
        if phase == 'setup' and turn == 0:
            print(f"\n⚠️ 阶段为setup,回合为0! 玩家已行动后必须执行turn命令推进回合,否则状态不更新!")
            print(f"   命令: python3 scripts/engine.py turn {args.game} --action '开场叙事' --recent '开场'")
        # NPC区块检查
        npc_count = len(re.findall(r'<!--§npc:.+?§-->', game))
        if npc_count == 0:
            print(f"\n⚠️ 没有NPC区块! 请用write -n添加NPC,或重新setup并传--npcs参数")
        elif npc_count < 5:
            print(f"\n⚠️ NPC数量不足({npc_count}个),建议至少5个")
        return

    if args.file:
        if args.file not in ALLOWED_FILES:
            die(f"--file 仅支持: {', '.join(sorted(ALLOWED_FILES))}")
        print(fread(os.path.join(gd, args.file)))
        return

    if args.npc:
        game = fread(os.path.join(gd, 'game.md'))
        key, content = find_npc(game, args.npc)
        if content is None: die(f"找不到NPC '{args.npc}'")
        print(f"[NPC:{key}]\n{content}")
        return

    if args.section:
        game = fread(os.path.join(gd, 'game.md'))
        r = extract(game, args.section)
        if r is None: die(f"找不到区块 '{args.section}'")
        print(r)
        return

    if args.log or args.log_n is not None:
        log = fread(os.path.join(gd, 'log.md'))
        print(get_log_entries(log, args.log_n or 3))
        return

    die("请指定: --hot/--file/--npc/--section/--log")

def cmd_write(args):
    """写入区块/NPC内容(严格格式场景已由setup/turn覆盖)"""
    gd = find_game(args.game)
    game_path = os.path.join(gd, 'game.md')

    npc_val = args.npc
    npc_content_val = resolve_content(args.npc_content)
    section_val = args.section
    section_content_val = resolve_content(args.section_content)

    # 骨架保护: 禁止覆盖规则/角色区块(角色用setup,规则永远不动)
    IMMUTABLE_SECTIONS = {'规则', '角色'}
    if section_val and section_val in IMMUTABLE_SECTIONS:
        die(f"区块 '{section_val}' 不可覆盖(用setup填充角色,规则保持模板原样)")

    if not any([npc_val, section_val]):
        die("请指定写入目标: -n(NPC) / -c(区块)")
    if npc_val and npc_content_val is None:
        die("使用 -n 时必须同时提供 --npc-content")
    if section_val and section_content_val is None:
        die("使用 -c 时必须同时提供 --section-content")

    bak_name = backup(gd, label='write')
    print(f"[备份] {bak_name}")

    try:
        if npc_val:
            game = fread(game_path)
            key, _ = find_npc(game, npc_val)
            if key is None: die(f"找不到NPC '{npc_val}'")
            fwrite(game_path, replace_section(game, f'npc:{key}', npc_content_val))

        if section_val:
            game = fread(game_path)
            fwrite(game_path, replace_section(game, section_val, section_content_val))

        if not args.skip_check:
            ok, errors = check_game(gd)
            if not ok:
                print(f"[校验失败] 发现 {len(errors)} 个问题,自动回滚:", file=sys.stderr)
                for i, e in enumerate(errors, 1):
                    print(f"  {i}. {e}", file=sys.stderr)
                restore(gd, bak_name)
                die("写入已回滚,请修正后重试")
            else:
                print("[校验通过]")
                clear_rollback(gd)
        else:
            print("[跳过校验]")

    except SystemExit:
        raise
    except Exception as exc:
        print(f"[写入异常] {exc},自动回滚", file=sys.stderr)
        restore(gd, bak_name)
        die("写入异常已回滚")

def cmd_init(args):
    """初始化游戏:从模板生成完整骨架文件,LLM只需用write -c填充内容"""
    gd = os.path.join(GAMES_DIR, args.game)
    if os.path.isdir(gd) and any(os.path.isfile(os.path.join(gd, f)) for f in ['game.md', 'state.md', 'log.md']):
        existing = [f for f in ['game.md', 'state.md', 'log.md'] if os.path.isfile(os.path.join(gd, f))]
        die(f"游戏 '{args.game}' 已存在文件: {', '.join(existing)}。如需重建请先删除。")
    os.makedirs(gd, exist_ok=True)

    # 读取模板
    tpl_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'templates')

    # --- game.md: 从模板生成,保留所有区块标记和规则原文 ---
    game_tpl = fread(os.path.join(tpl_dir, 'game-template.md'))
    # 替换yaml头中的占位符
    game_content = game_tpl.replace('{游戏名}', args.game)
    fwrite(os.path.join(gd, 'game.md'), game_content)

    # --- state.md: 从模板生成 ---
    state_tpl = fread(os.path.join(tpl_dir, 'state-template.md'))
    fwrite(os.path.join(gd, 'state.md'), state_tpl)

    # --- log.md: 从模板生成 ---
    log_tpl = fread(os.path.join(tpl_dir, 'log-template.md'))
    fwrite(os.path.join(gd, 'log.md'), log_tpl)

    # 自动校验
    ok, errors = check_game(gd)
    if ok:
        print(f"[OK] 已创建: {gd}/ (校验通过)")
        print(f"下一步: python scripts/engine.py setup {args.game} --world '...' --hero '...' --attrs '力X敏X体X智X魅X' --start '起始地'")
    else:
        print(f"[WARN] 已创建但模板有问题:")
        for i, e in enumerate(errors, 1):
            print(f"  {i}. {e}")

def cmd_setup(args):
    """一键填充开局: 世界/角色/场景/世界状态/state.md, 保证格式合规"""
    gd = find_game(args.game)
    game_path = os.path.join(gd, 'game.md')
    state_path = os.path.join(gd, 'state.md')

    game = fread(game_path)

    # 预解析参数(避免重复调用)
    world_val = resolve_content(args.world) if args.world else None
    hero_val = resolve_content(args.hero) if args.hero else None
    npcs_val = resolve_content(args.npcs) if args.npcs else None
    attrs_val = resolve_content(args.attrs) if args.attrs else None
    start_loc = args.start or '起始地'
    atmo = args.atmosphere or '未知'

    # 解析属性
    attr_map = {}
    if attrs_val:
        for m in re.finditer(r'([力敏体智魅])(\d+)', attrs_val):
            attr_map[m.group(1)] = int(m.group(2))
        total = sum(attr_map.values())
        if total > 25:
            die(f"属性总和{total}>25(力敏体智魅各1-10,合计25)")
        for k in ['力', '敏', '体', '智', '魅']:
            if k not in attr_map:
                attr_map[k] = 1
    else:
        attr_map = {k: 1 for k in '力敏体智魅'}

    # --- 1. 世界设定 ---
    if world_val:
        game = replace_section(game, '世界设定', world_val)

    # --- 2. 角色 ---
    if hero_val:
        attrs_line = f"属性(25点1-10):力{attr_map['力']}敏{attr_map['敏']}体{attr_map['体']}智{attr_map['智']}魅{attr_map['魅']}"
        hero_content = hero_val
        if '属性' not in hero_content:
            hero_content = hero_content.rstrip() + '\n' + attrs_line
        if '物品' not in hero_content:
            hero_content = hero_content.rstrip() + '\n物品:[]|货币:10|技能:[]'
        game = replace_section(game, '角色', hero_content)

    # --- 3. NPC区块 + 世界状态 ---
    # 构建NPC区块
    npc_blocks = ''
    npc_parsed = []  # 解析后用于世界状态表格的行
    if npcs_val:
        # 每行一个NPC,字段用|分隔,跳过表头行(含"位置""状态""好感""备注"等关键词)
        header_kw = ['NPC', '位置', '状态', '好感', '备注']
        npc_lines = [l.strip() for l in npcs_val.split('\n')
                     if l.strip() and not any(f'{kw}|' in l or f'|{kw}' in l or f'|{kw}|' in l for kw in header_kw)]
        for line in npc_lines:
            parts = [p.strip() for p in line.split('|') if p.strip()]
            if not parts:
                continue
            npc_name = parts[0]
            if re.match(r'^\d+$', npc_name):
                print(f"[WARN] NPC名字为纯数字,疑似格式错误,跳过: {line}", file=sys.stderr)
                continue
            # 校验: 位置字段(parts[1])是否看起来像NPC名字而非地名
            # 典型错误: "王屠户|李药铺掌柜|刘员外|张秀才|陈酒家"
            # 特征: 多个短词用|分隔,位置字段像人名而非地名
            if len(parts) >= 3:
                loc_val = parts[1]
                status_val = parts[2]
                # 地名通常包含: 市/街/巷/铺/楼/馆/城/镇/村/院/府/衙/门/桥/渡/口/山/河/湖/海/港/码头/东西南北/上中下
                location_kw = ['市', '街', '巷', '铺', '楼', '馆', '城', '镇', '村', '院', '府', '衙', '门',
                               '桥', '渡', '口', '山', '河', '湖', '海', '港', '码头', '东', '西', '南', '北',
                               '上', '中', '下', '里', '外', '内', '前', '后', '左', '右']
                # 状态通常为: 正常/受伤/生病/死亡/愤怒/友好/敌对/友好/中立/友好/可疑/神秘/友好/友好/友好
                status_kw = ['正常', '受伤', '生病', '死亡', '愤怒', '友好', '敌对', '中立', '可疑', '神秘',
                             '友善', '冷漠', '警惕', '醉酒', '失踪', '昏迷', '被抓', '逃跑']
                loc_looks_like_name = not any(kw in loc_val for kw in location_kw) and len(loc_val) <= 4
                status_looks_like_name = status_val not in status_kw
                if loc_looks_like_name and status_looks_like_name:
                    print(f"[WARN] 疑似多NPC拼在1行(位置'{loc_val}'和状态'{status_val}'不像正常值),请每个NPC单独1行(名字|位置|状态|好感|备注,缺省可省略): {line}", file=sys.stderr)
                    continue
            npc_loc = parts[1] if len(parts) > 1 else ''
            npc_status = parts[2] if len(parts) > 2 else ''
            npc_favor = parts[3] if len(parts) > 3 else '0'
            npc_note = parts[4] if len(parts) > 4 else ''
            npc_tag = f'npc:{npc_name}'
            # 构建NPC区块: 只写有值的字段,不填?占位
            npc_fields = []
            if npc_note and npc_note != '?':
                npc_fields.append(f'职业:{npc_note}')
            if npc_loc:
                npc_fields.append(f'常驻:{npc_loc}')
            npc_fields.append(f'好感:{npc_favor}')
            npc_header = '|'.join(npc_fields)
            npc_block_lines = [f'<!--§{npc_tag}§-->', npc_header]
            if npc_status:
                npc_block_lines.append(f'状态:{npc_status}')
            npc_block_lines.append(f'<!--§/{npc_tag}§-->')
            npc_block = '\n'.join(npc_block_lines)
            npc_blocks += npc_block + '\n'
            # 世界状态表格行: 标准markdown表格需5列对齐
            ws_parts = [npc_name]
            ws_parts.append(npc_loc if npc_loc else '')
            ws_parts.append(npc_status if npc_status else '')
            ws_parts.append(npc_favor)
            ws_parts.append(npc_note if npc_note else '')
            npc_parsed.append('|' + '|'.join(ws_parts) + '|')

        if not npc_parsed:
            print("[WARN] 未解析到任何有效NPC! 请确保--npcs参数格式: 每行一个NPC,字段用|分隔(名字|位置|状态|好感|备注)", file=sys.stderr)
    else:
        print("[WARN] setup未传--npcs参数! NPC区块将为空,建议至少提供5个NPC(格式: 名字|位置|状态|好感|备注)", file=sys.stderr)

    # 世界状态表格: 标准markdown表格格式
    if npc_parsed:
        ws_table = "|NPC|位置|状态|好感|备注|\n|---|---|---|---|---|\n" + "\n".join(npc_parsed)
    else:
        ws_table = "|NPC|位置|状态|好感|备注|\n|---|---|---|---|---|"
    ws_content = f"{ws_table}\n已触发:[]|势力动态:[]|已探索:[{start_loc}]|未探索:[东:荒野村落|西:深山古道|北:河流渡口]"

    # 插入NPC区块: 替换模板占位标记
    insert_marker = '<!--NPC_INSERT_POINT-->'
    if insert_marker in game:
        game = game.replace(insert_marker, npc_blocks.rstrip('\n'))
    elif npc_blocks:
        # 兼容旧模板: 无标记时插到世界状态前
        ws_pos = game.find('<!--§世界状态§-->')
        if ws_pos != -1:
            game = game[:ws_pos] + npc_blocks + game[ws_pos:]

    # 清理模板示例NPC区块(名字为"名字"的占位NPC)
    template_npc = '<!--§npc:名字§-->'
    if template_npc in game:
        s_tag = '<!--§npc:名字§-->'
        e_tag = '<!--§/npc:名字§-->'
        si = game.find(s_tag)
        if si != -1:
            ei = game.find(e_tag, si)
            if ei != -1:
                ei += len(e_tag)
                # 清除该区块及前后空行
                before = game[:si].rstrip('\n')
                after = game[ei:].lstrip('\n')
                game = before + '\n' + after

    # 清理模板注释行
    game = re.sub(r'<!--每NPC[^>]*-->\n?', '', game)

    game = replace_section(game, '世界状态', ws_content)

    # --- 4. scene ---
    game = replace_section(game, 'scene', f"位置:{start_loc}|氛围:{atmo}|感知:[]")

    # --- 4.5 YAML头占位符替换 ---
    if world_val:
        # 从世界设定提取时代/地理关键词作为world名
        world_short = world_val.split('\n')[0].strip()
        game = re.sub(r'world:"\{世界名\}"', f'world:"{world_short}"', game)
    if hero_val:
        hero_name_m = re.search(r'姓名[:：]([^|\n]+)', hero_val)
        if hero_name_m:
            hero_name = hero_name_m.group(1).strip()
            game = re.sub(r'user:"\{名\}"', f'user:"{hero_name}"', game)

    # 写入game.md
    fwrite(game_path, game)

    # --- 5. state.md ---
    state = fread(state_path)
    state = re.sub(r'回合:\s*\d+', '回合:0', state)
    state = re.sub(r'阶段:.*', '阶段:`setup`', state)
    state = re.sub(r'位置:[^|\n]*', f'位置:{start_loc}', state)
    stamina = attr_map.get('体', 1) * 2
    state = re.sub(r'耐力:\s*\d+/\d+', f'耐力:{stamina}/{stamina}', state)
    attrs_str = f"力{attr_map['力']}敏{attr_map['敏']}体{attr_map['体']}智{attr_map['智']}魅{attr_map['魅']}"
    state = re.sub(r'属性:[^|\n]*', f'属性:{attrs_str}(精力惩罚已含)', state)
    # 初始化天气(随机)和时间(06:00清晨)
    init_weather = roll_weather()
    state = re.sub(r'天气:[^|\n]*', f'天气:{init_weather}', state)
    state = re.sub(r'时间:[^|\n]*', '时间:06:00(清晨)', state)
    fwrite(state_path, state)

    # --- 6. 校验 ---
    ok, errors = check_game(gd)
    if ok:
        print(f"[OK] {args.game} 开局完成,校验通过")
        clear_rollback(gd)
        print(f"  世界设定/角色/场景/世界状态/state.md 已填充")
        print(f"  天气:{init_weather} | 时间:06:00(清晨)")
        print(f"  下一步: 输出开场叙事(100-1000字),然后开始第一回合")
    else:
        print(f"[FAIL] 填充后校验发现问题:")
        for i, e in enumerate(errors, 1):
            print(f"  {i}. {e}")
        sys.exit(1)

def cmd_turn(args):
    """推进回合: 自动+1/扣精力/更新state/日志/scene"""
    gd = find_game(args.game)
    game_path = os.path.join(gd, 'game.md')
    state_path = os.path.join(gd, 'state.md')
    log_path = os.path.join(gd, 'log.md')

    state = fread(state_path)
    game = fread(game_path)

    cur_turn = extract_turn(state)
    new_turn = cur_turn + 1

    # 精力
    m = re.search(r'精力[:：]\s*(\d+)/(\d+)', state)
    if not m: die("state.md 精力格式错误")
    cur_energy, max_energy = int(m.group(1)), int(m.group(2))
    energy_cost = 2 if args.tense else 1
    new_energy = max(0, cur_energy - energy_cost)

    # 耐力(精力<=10时-2/回合)
    m = re.search(r'耐力[:：]\s*(\d+)/(\d+)', state)
    if not m: die("state.md 耐力格式错误")
    cur_stamina, max_stamina = int(m.group(1)), int(m.group(2))
    new_stamina = max(0, cur_stamina - 2) if new_energy <= 10 else cur_stamina

    bak_name = backup(gd, label=f'turn{new_turn}')
    print(f"[备份] {bak_name}")

    # 更新 state.md
    state = re.sub(r'回合:\s*\d+', f'回合:{new_turn}', state)
    if new_turn == 1:
        state = re.sub(r'阶段:.*', '阶段:`playing`', state)
    elif args.phase:
        state = re.sub(r'阶段:.*', f'阶段:`{args.phase}`', state)
    state = re.sub(r'精力[:：]\s*\d+/\d+', f'精力:{new_energy}/{max_energy}', state)
    state = re.sub(r'耐力[:：]\s*\d+/\d+', f'耐力:{new_stamina}/{max_stamina}', state)
    if args.location:
        state = re.sub(r'位置:[^|\n]*', f'位置:{args.location}', state)
    # 天气: 手动指定 或 每4-6回合30%变天
    if args.weather:
        state = re.sub(r'天气:[^|\n]*', f'天气:{args.weather}', state)
    else:
        cur_weather_m = re.search(r'天气[:：]([^|\n]+)', state)
        cur_weather = cur_weather_m.group(1).strip() if cur_weather_m else '晴'
        # 每4-6回合可能变天
        cycle = 4 + (new_turn % 3)  # 4,5,6循环
        if new_turn % cycle == 0 and random.random() < 0.3:
            new_weather = roll_weather(cur_weather)
            state = re.sub(r'天气:[^|\n]*', f'天气:{new_weather}', state)
    # 时间: 手动指定 或 自动推进
    if args.time:
        state = re.sub(r'时间:[^|\n]*', f'时间:{args.time}', state)
    else:
        cur_time_m = re.search(r'时间[:：]([^|\n]+)', state)
        cur_time = cur_time_m.group(1).strip() if cur_time_m else '06:00'
        # 短+15m/长+30m/移动+15~30m/事件+30~60m, 默认短行动+15
        advance = args.time_advance or 15
        new_time, period = advance_time(cur_time, advance)
        state = re.sub(r'时间:[^|\n]*', f'时间:{new_time}({period})', state)
    if args.items is not None:
        state = re.sub(r'物品:\[.*?\]', f'物品:[{resolve_content(args.items)}]', state)
    if args.skills is not None:
        state = re.sub(r'技能:\[.*?\]', f'技能:[{resolve_content(args.skills)}]', state)
    if args.npc_relations is not None:
        state = re.sub(r'关键NPC:\[.*?\]', f'关键NPC:[{resolve_content(args.npc_relations)}]', state)
    if args.conflicts is not None:
        state = re.sub(r'冲突:\[.*?\]', f'冲突:[{resolve_content(args.conflicts)}]', state)
    if args.goals is not None:
        state = re.sub(r'目标:\[.*?\]', f'目标:[{resolve_content(args.goals)}]', state)
    if args.recent is not None:
        state = re.sub(r'近3事:\[.*?\]', f'近3事:[{resolve_content(args.recent)}]', state)

    # 精力惩罚标注
    m_attr = re.search(r'属性:([^(\n]+)', state)
    if m_attr:
        attr_map = {}
        for m2 in re.finditer(r'([力敏体智魅])(\d+)', m_attr.group(1)):
            attr_map[m2.group(1)] = int(m2.group(2))
        penalty = '(精力惩罚-2)' if new_energy <= 10 else '(精力惩罚-1)' if new_energy <= 30 else '(精力惩罚已含)'
        new_attr = f"力{attr_map.get('力',1)}敏{attr_map.get('敏',1)}体{attr_map.get('体',1)}智{attr_map.get('智',1)}魅{attr_map.get('魅',1)}{penalty}"
        state = re.sub(r'属性:[^|\n]*', f'属性:{new_attr}', state)

    fwrite(state_path, state)

    # 同步更新game.md YAML头(turn/phase)
    game = re.sub(r'turn:\d+', f'turn:{new_turn}', game)
    if new_turn == 1:
        game = re.sub(r'phase:"setup"', 'phase:"playing"', game)
    elif args.phase:
        game = re.sub(r'phase:"\w+"', f'phase:"{args.phase}"', game)

    # 更新 scene
    if args.location or args.atmosphere:
        cur_scene = extract(game, 'scene') or '位置:|氛围:|感知:[]'
        loc = args.location or (lambda m: m.group(1).strip() if m else '')(re.search(r'位置[:：]([^|\n]+)', cur_scene))
        atmo = args.atmosphere or (lambda m: m.group(1).strip() if m else '')(re.search(r'氛围[:：]([^|\n]+)', cur_scene))
        game = replace_section(game, 'scene', f"位置:{loc}|氛围:{atmo}|感知:[]")

    # 写入game.md(YAML头+scene可能已变更)
    fwrite(game_path, game)

    # 追加日志
    log = fread(log_path)
    fwrite(log_path, prepend_log(log, f"回合{new_turn}:{args.action or '行动'}"))

    # 校验
    ok, errors = check_game(gd)
    if not ok:
        print(f"[校验失败] 自动回滚:", file=sys.stderr)
        for i, e in enumerate(errors, 1):
            print(f"  {i}. {e}", file=sys.stderr)
        restore(gd, bak_name)
        die("回合推进已回滚")
    # 输出状态
    new_time_m = re.search(r'时间[:：]([^|\n]+)', state)
    new_weather_m = re.search(r'天气[:：]([^|\n]+)', state)
    time_str = new_time_m.group(1).strip() if new_time_m else ''
    weather_str = new_weather_m.group(1).strip() if new_weather_m else ''
    print(f"[OK] 回合{new_turn} | 精力{cur_energy}→{new_energy} | 耐力{cur_stamina}→{new_stamina} | {time_str} | {weather_str}")
    clear_rollback(gd)
    if new_energy <= 10:
        print(f"⚠️ 精力严重不足! 耐力每回合-2,行动受限")
    elif new_energy <= 30:
        print(f"⚠️ 精力偏低,力体-1")
    if new_turn > 0 and new_turn % 10 == 0:
        print(f"🔔 10倍数回合,需执行: python scripts/engine.py compress {args.game}")

def cmd_check(args):
    gd = find_game(args.game)
    ok, errors = check_game(gd)
    if ok:
        print("[OK] 格式校验通过")
    else:
        print(f"[FAIL] 发现 {len(errors)} 个问题:")
        for i, e in enumerate(errors, 1):
            print(f"  {i}. {e}")
        sys.exit(1)

def cmd_rollback(args):
    gd = find_game(args.game)
    if args.list:
        list_backups(gd)
        return
    if args.to:
        restore(gd, args.to)
    else:
        # 默认回滚到最近备份
        bd = bak_dir(gd)
        backups = sorted(os.listdir(bd))
        if not backups:
            die("无可用备份")
        restore(gd, backups[-1])

def cmd_compress(args):
    """里程碑压缩:回合10倍数时调用"""
    gd = find_game(args.game)
    game_path = os.path.join(gd, 'game.md')
    state_path = os.path.join(gd, 'state.md')
    log_path = os.path.join(gd, 'log.md')

    state = fread(state_path)
    game = fread(game_path)
    log = fread(log_path)

    # 从state中提取当前回合
    turn = extract_turn(state)
    if turn == 0:
        die("回合为0,无需压缩")

    # 防重复: 如果该回合的里程碑已存在则拒绝
    if f'<!-- 里程碑:回合{turn}存档 -->' in log:
        die(f"回合{turn}的里程碑已存在,不可重复压缩")

    # 故事概要(必填)
    story = resolve_content(args.story) if args.story else None
    if not story:
        die("请用 --story 提供故事概要(描述至今剧情走向、关键事件、人物关系变化)")

    # 压缩前备份
    bak_name = backup(gd, label=f'compress-turn{turn}')
    print(f"[备份] {bak_name}")

    # 1. 构建里程碑
    # 提取旧里程碑(整组保留: 里程碑+故事概要+存档)
    old_milestone_blocks = re.findall(
        r'(<!-- 里程碑:.*?-->\n(?:<!-- (?:故事概要|存档(?:快照)?):.*?-->\n)*)',
        log, re.DOTALL)

    log_entries = get_all_log_entries(log)
    recent_lines = log_entries[:5]

    # 从state提取核心3字段
    snap_turn = turn
    snap_loc = (lambda m: m.group(1).strip() if m else '?')(re.search(r'位置[:：]([^|\n]+)', state))
    snap_npc = (lambda m: m.group(1).strip() if m else '[]')(re.search(r'关键NPC:\[([^\]]*)\]', state))
    snapshot_line = f"回合:{snap_turn}|位置:{snap_loc}|关键NPC:[{snap_npc}]"

    new_log = f"# 日志(倒序,有效行动追加,>10条压缩)\n"
    # 保留旧里程碑(整组)
    for block in old_milestone_blocks:
        new_log += block
    # 当前里程碑: 故事概要(主体) + 精简快照(定位用)
    new_log += f"<!-- 里程碑:回合{turn} -->\n"
    new_log += f"<!-- 故事概要:\n{story}\n-->\n"
    new_log += f"<!-- 存档:{snapshot_line} -->\n"
    new_log += "---\n"
    for line in recent_lines:
        new_log += f"{line}\n"
    new_log += f"[系统:第{turn}回合存档完成]\n"

    fwrite(log_path, new_log)

    # 2. 清理低好感NPC(好感为0/0/-且不在关键NPC列表)
    key_npc_match = re.search(r'关键NPC:\[([^\]]*)\]', state)
    key_npc_names = set()
    if key_npc_match:
        key_npc_names = {n.strip() for n in key_npc_match.group(1).split(',') if n.strip()}

    ws = extract(game, '世界状态')
    pruned_names = []
    if ws:
        ws_lines = ws.split('\n')
        new_ws_lines = []
        for line in ws_lines:
            stripped = line.strip()
            if not stripped or stripped.startswith('NPC:') or stripped.startswith('已触发:') or stripped.startswith('势力动态:') or stripped.startswith('已探索:') or stripped.startswith('未探索:'):
                new_ws_lines.append(line)
                continue
            # 跳过markdown表头行和分隔行
            if stripped.startswith('|NPC|') or re.match(r'^\|[-:]+\|', stripped):
                new_ws_lines.append(line)
                continue
            parts = [p.strip() for p in stripped.split('|') if p.strip()]
            # 格式: 名字|位置|状态|好感|备注
            if len(parts) >= 4:
                npc_name = parts[0]
                favor = parts[3]
                # 好感为0、-或空，且不在关键NPC → 清理
                if npc_name not in key_npc_names and favor in ('0', '-', '0初始', ''):
                    pruned_names.append(npc_name)
                    continue
            new_ws_lines.append(line)
        if pruned_names:
            ws = '\n'.join(new_ws_lines)
            game = replace_section(game, '世界状态', ws)
            # 同步删除NPC区块
            for name in pruned_names:
                npc_tag = f'npc:{name}'
                s = f'<!--§{npc_tag}§-->'
                e = f'<!--§/{npc_tag}§-->'
                si = game.find(s)
                if si != -1:
                    ei = game.find(e, si)
                    if ei != -1:
                        ei += len(e)
                        # 清除该行及前后空行
                        before = game[:si].rstrip('\n')
                        after = game[ei:].lstrip('\n')
                        game = before + '\n' + after

    # 3. game.md精简
    world = extract(game, '世界设定')
    if world and len(world) > 300:
        compact_world = ' '.join(line.strip() for line in world.split('\n') if line.strip())
        cut = compact_world[:300]
        last_period = max(cut.rfind('。'), cut.rfind('！'), cut.rfind('？'), cut.rfind('.'))
        if last_period > 200:
            short_world = compact_world[:last_period + 1]
        else:
            short_world = compact_world[:297].rstrip() + '...'
        game = replace_section(game, '世界设定', short_world)

    if ws and f"[系统:第{turn}回合压缩]" not in ws:
        game = replace_section(game, '世界状态', f"{ws}\n[系统:第{turn}回合压缩]")

    fwrite(game_path, game)

    # 压缩后校验
    ok, errors = check_game(gd)
    if not ok:
        print(f"[校验失败] 压缩后格式异常,回滚:", file=sys.stderr)
        for i, e in enumerate(errors, 1):
            print(f"  {i}. {e}", file=sys.stderr)
        restore(gd, bak_name)
        die("压缩已回滚")
    print(f"[校验通过]")
    clear_rollback(gd)
    print(f"[系统:第{turn}回合存档完成]")
    print(f"log.md已压缩(保留近5条+存档快照)")
    print(f"game.md已精简")
    if pruned_names:
        print(f"NPC已清理(好感0且非关键): {', '.join(pruned_names)}")

def main():
    p = argparse.ArgumentParser(description='md-game 引擎')
    sub = p.add_subparsers(dest='cmd')

    # read
    pr = sub.add_parser('read')
    pr.add_argument('game')
    pr.add_argument('--hot', action='store_true', help='热路径:state+scene+log')
    pr.add_argument('--npc', type=str, help='读指定NPC')
    pr.add_argument('--section', type=str, help='读任意区块')
    pr.add_argument('--file', type=str, help='读整文件(game.md/state.md/log.md)')
    pr.add_argument('--log', action='store_true', help='读日志(默认3条)')
    pr.add_argument('--log-n', type=int, default=None, help='读指定条数日志')

    # write
    pw = sub.add_parser('write', help='更新区块/NPC内容(state/scene/日志用setup/turn)')
    pw.add_argument('game')
    pw.add_argument('-n', '--npc', type=str, help='NPC名(模糊匹配)')
    pw.add_argument('--npc-content', type=str, help='NPC新内容(支持@file/-)')
    pw.add_argument('-c', '--section', type=str, help='区块名(规则/角色不可覆盖)')
    pw.add_argument('--section-content', type=str, help='区块内容(支持@file/-)')
    pw.add_argument('--skip-check', action='store_true', help='跳过校验(仅修复格式问题时用)')

    # init
    pi = sub.add_parser('init')
    pi.add_argument('game')

    # setup
    ps = sub.add_parser('setup', help='一键填充开局(世界/角色/场景/state)')
    ps.add_argument('game')
    ps.add_argument('--world', type=str, help='世界设定内容(支持@file/-)')
    ps.add_argument('--hero', type=str, help='角色内容(支持@file/-)')
    ps.add_argument('--attrs', type=str, help='属性 如"力3敏4体5智6魅7"(合计25)')
    ps.add_argument('--start', type=str, help='起始位置')
    ps.add_argument('--atmosphere', type=str, help='起始氛围')
    ps.add_argument('--npcs', type=str, help='NPC表格行(支持@file/-)')

    # turn
    pt = sub.add_parser('turn', help='推进回合(自动+1/扣精力/更新state/日志)')
    pt.add_argument('game')
    pt.add_argument('--action', type=str, help='行动摘要(描述做了什么及结果,写入日志)')
    pt.add_argument('--location', type=str, help='新位置')
    pt.add_argument('--atmosphere', type=str, help='新氛围')
    pt.add_argument('--weather', type=str, help='新天气(不指定则按规则变天)')
    pt.add_argument('--time', type=str, help='新时间(如"14:30(下午)",不指定则自动推进)')
    pt.add_argument('--time-advance', type=int, default=None, help='时间推进分钟数(短15/长30/移动15-30/事件30-60,默认15)')
    pt.add_argument('--items', type=str, help='物品列表(支持@file/-)')
    pt.add_argument('--skills', type=str, help='技能列表(支持@file/-)')
    pt.add_argument('--npc-relations', type=str, help='关键NPC列表(支持@file/-)')
    pt.add_argument('--conflicts', type=str, help='冲突列表(支持@file/-)')
    pt.add_argument('--goals', type=str, help='目标列表(支持@file/-)')
    pt.add_argument('--recent', type=str, help='近3事(支持@file/-)')
    pt.add_argument('--phase', type=str, help='新阶段(如"第二章")')
    pt.add_argument('--tense', action='store_true', help='紧张回合(精力-2而非-1)')

    # check
    pk = sub.add_parser('check', help='校验游戏文件格式')
    pk.add_argument('game')

    # rollback
    prl = sub.add_parser('rollback', help='回滚到最近备份')
    prl.add_argument('game')
    prl.add_argument('--to', type=str, help='回滚到指定备份名')
    prl.add_argument('--list', action='store_true', help='列出所有备份')

    # compress
    pc = sub.add_parser('compress', help='里程碑压缩(回合10倍数时)')
    pc.add_argument('game')
    pc.add_argument('--story', type=str, help='故事概要(必填,描述剧情走向/关键事件/人物关系变化,支持@file/-)')

    args = p.parse_args()
    if args.cmd == 'read':
        cmd_read(args)
    elif args.cmd == 'write':
        cmd_write(args)
    elif args.cmd == 'init':
        cmd_init(args)
    elif args.cmd == 'setup':
        cmd_setup(args)
    elif args.cmd == 'turn':
        cmd_turn(args)
    elif args.cmd == 'check':
        cmd_check(args)
    elif args.cmd == 'rollback':
        cmd_rollback(args)
    elif args.cmd == 'compress':
        cmd_compress(args)
    else:
        p.print_help()

if __name__ == '__main__':
    main()
