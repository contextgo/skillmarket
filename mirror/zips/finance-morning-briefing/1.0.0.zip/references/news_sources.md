# 新闻数据源与接口说明

本文档说明 `finance-morning-briefing` Skill 可调用的新闻数据接口，
供 AI 在 Phase 1 数据采集时参考选择。

---

## 第一优先：neodata-financial-search（自然语言查询）

**调用方式**：直接用自然语言向 neodata-financial-search Skill 提问。

### 推荐查询语句模板

```
# 宏观政策
"过去24小时内国内宏观经济政策 央行 财政部 发改委 新闻动态"

# 行业动态
"过去24小时 新能源 半导体 消费 医药 军工 房地产 行业重要新闻"

# 外盘
"昨夜美股三大指数涨跌 纳斯达克 道琼斯 标普500 隔夜表现"

# 大宗商品
"原油黄金铜最新价格 隔夜大宗商品涨跌"

# 上市公司公告
"今日A股上市公司重大公告 业绩预告 重组 停复牌"
```

---

## 第二优先：finance-data-retrieval（结构化接口）

当 neodata 返回内容不足或需要按时间筛选时，调用以下接口：

### 1. `news_vip` — 新闻资讯

**用途**：获取指定时间范围内的财经新闻

**关键参数**：
```json
{
  "api_name": "news_vip",
  "params": {
    "start_date": "YYYY-MM-DD HH:MM:SS",  // 昨日15:00
    "end_date":   "YYYY-MM-DD HH:MM:SS",  // 今日09:25
    "src": ""   // 可选：sina（新浪）, wallstreetcn（华尔街见闻）, eastmoney（东方财富）, cls（财联社）, caixin（财新）, 10jqka（同花顺）
  },
  "fields": "datetime,title,content,channels,score"
}
```

**返回字段说明**：
| 字段 | 说明 |
|---|---|
| datetime | 新闻发布时间 |
| title | 新闻标题 |
| content | 新闻正文（摘要） |
| channels | 新闻分类标签（宏观/行业/公司等）|
| score | 重要性评分（越高越重要，优先展示高分新闻）|

**推荐来源优先级**：
1. `cls`（财联社）：A 股盘前最权威，实时性最强
2. `wallstreetcn`（华尔街见闻）：外盘、宏观覆盖好
3. `eastmoney`（东方财富）：行业和公司新闻丰富
4. `sina`（新浪财经）：综合性强

---

### 2. `major_news` — 重大新闻

**用途**：获取影响市场的重大事件（监管公告、重要政策等）

**关键参数**：
```json
{
  "api_name": "major_news",
  "params": {
    "start_date": "YYYY-MM-DD",
    "end_date": "YYYY-MM-DD"
  },
  "fields": "title,content,pub_time,src"
}
```

---

### 3. `anns_d` — 上市公司公告

**用途**：获取 A 股上市公司当日公告

**关键参数**：
```json
{
  "api_name": "anns_d",
  "params": {
    "trade_date": "YYYYMMDD",  // 今日日期
    "ann_type": ""  // DR:定期报告, RE:重大事项, DF:公司信息, 空=全部
  },
  "fields": "ts_code,name,title,ann_date,pub_time,ann_type"
}
```

---

### 4. 外盘数据接口

#### 美股指数（history_us_daily）
```json
{
  "api_name": "us_daily",
  "params": {
    "trade_date": "YYYYMMDD"
  },
  "fields": "ts_code,trade_date,close,pct_chg"
}
```
- 道指：ts_code = `DJI`
- 标普500：ts_code = `SPX`
- 纳指：ts_code = `NDX`

#### 大宗商品期货收盘
```json
{
  "api_name": "fut_daily",
  "params": {
    "trade_date": "YYYYMMDD",
    "exchange": "NYMEX"
  },
  "fields": "ts_code,trade_date,close,pct_chg,settle"
}
```

#### 美元指数（宏观数据）
```json
{
  "api_name": "index_daily",
  "params": {
    "ts_code": "DXY.OTC",
    "start_date": "YYYYMMDD",
    "end_date": "YYYYMMDD"
  }
}
```

---

## 第三优先：公开信息搜索

当以上两种方式均无法获取完整信息时：
- 使用 WebSearch 检索"财联社今日早报 site:cls.cn"
- 搜索"华尔街见闻 隔夜要闻"
- 明确标注"以下为网络公开信息，非实时结构化数据"

---

## 时间窗口计算规则

```python
# 伪代码：确定采集时间范围
from datetime import datetime, timedelta

now = datetime.now()
today = now.date()
weekday = today.weekday()  # 0=周一, 6=周日

if weekday == 0:  # 周一
    start = datetime(today.year, today.month, today.day) - timedelta(days=3)
    start = start.replace(hour=15, minute=0)  # 上周五15:00
elif weekday >= 5:  # 周末（理论上不触发，但做容错）
    # 找到最近的周五
    days_back = weekday - 4
    friday = today - timedelta(days=days_back)
    start = datetime(friday.year, friday.month, friday.day, 15, 0)
else:  # 普通交易日
    yesterday = today - timedelta(days=1)
    start = datetime(yesterday.year, yesterday.month, yesterday.day, 15, 0)

end = datetime(today.year, today.month, today.day, 9, 25)
```

---

## 新闻去重策略

1. **标题相似度 > 80%** → 视为同一事件，保留最早来源
2. **同一公司同一事件**（如"XX公司发布业绩预告"）→ 合并展示
3. **按 score 降序**排列，优先展示高重要性新闻
4. **过滤条件**：
   - 时间不在采集窗口内 → 丢弃
   - 标题含"广告"、"推广"、"赞助" → 丢弃
   - 仅有标题无内容且无 channels 标签 → 降权显示
