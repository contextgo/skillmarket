#!/usr/bin/env python3
"""
简单API测试示例
这是一个通用的API测试模板，你可以根据自己的业务需求修改使用
"""

import requests
import json

def test_api_endpoint():
    """测试API端点示例"""
    
    print("="*60)
    print("🔧 简单API测试示例")
    print("="*60)
    
    # 配置你的API信息
    base_url = "https://your-api-domain.com"  # 替换为你的API域名
    endpoint = "/api/v1/test"                  # 替换为你的接口路径
    url = f"{base_url}{endpoint}"
    
    # 请求头
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer YOUR_TOKEN_HERE"  # 如果需要认证
    }
    
    # 请求体（示例）
    payload = {
        "param1": "value1",
        "param2": 123
    }
    
    print(f"\n📤 发送请求到: {url}")
    print(f"请求体: {json.dumps(payload, ensure_ascii=False, indent=2)}")
    
    try:
        response = requests.post(url, headers=headers, json=payload, timeout=10)
        
        print(f"\n📥 响应状态码: {response.status_code}")
        print(f"⏱️  响应时间: {response.elapsed.total_seconds()*1000:.0f}ms")
        
        try:
            resp_json = response.json()
            print(f"\n📊 响应内容:")
            print(json.dumps(resp_json, ensure_ascii=False, indent=2))
            
            # 简单断言
            if response.status_code == 200:
                print(f"\n✅ 测试通过！")
                return True
            else:
                print(f"\n❌ 测试失败！")
                return False
                
        except Exception as e:
            print(f"⚠️  响应解析失败: {e}")
            print(f"响应内容: {response.text[:500]}")
            return False
            
    except Exception as e:
        print(f"\n❌ 请求异常: {e}")
        return False

if __name__ == "__main__":
    test_api_endpoint()
