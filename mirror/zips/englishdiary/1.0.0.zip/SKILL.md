---
name: english-diary
description: "Helps users learn English writing through diary entries. Accepts mixed Chinese-English input, auto-generates date/location/weather headers, analyzes grammar and word choice errors, rewrites in standard English, provides Chinese translation, and syncs to IMA notes. Triggered by English diary, diary writing practice, English learning."
---

# English Diary — 英语日记学习助手

> **触发词**：英语日记、写日记、diary、English diary、日记练习、英语练习、日记改错、帮我写日记、日记翻译、英语学习日记

这个 skill 帮助用户通过日记形式学习英语写作。用户可以用中英文混写输入日记，skill 自动完成五项任务：添加日期/地点/天气头部信息、分析语法与用词错误、重写标准英文版本、**附带中文翻译对照**、将全部内容同步到 IMA 笔记知识库。

---

## 使用前提

1. **IMA 凭证**：必须已配置 IMA OpenAPI 凭证（见 ima-skill 的 Setup 步骤）。
   凭证存储路径：`~/.config/ima/client_id` 和 `~/.config/ima/api_key`

---

## 五部分输出规范

### Part 1 — 日记头部（自动生成）

在用户日记正文之前，自动生成以下三行元信息：

```
Date: [英文格式日期，如 Sunday, April 19, 2026]
Location: [自动获取电脑地理位置；无法获取则留空]
Weather: [根据地点调用天气接口；无法获取则留空]
```

**地点获取方法**（依次尝试，取第一个成功的结果）：
1. 通过 Python 调用免费 IP 定位 API：`https://ipapi.co/json/` — 取 `city` 字段
2. 调用备用：`https://ip-api.com/json/?lang=en` — 取 `city` 字段
3. 若均失败，Location 留空

**天气获取方法**（获取到地点后执行）：
- 调用 `https://wttr.in/{city}?format=%C+%t` 获取天气描述（如 `Sunny +28°C`）
- 若失败，Weather 留空

> ⚠️ **踩坑经验**：Windows PowerShell 的 `Invoke-RestMethod` 对某些 API 返回 CLIXML 垃圾导致解析失败。**必须使用 Python (`python` / `python3`) 的 `urllib.request` 来获取 IP 定位和天气数据**，不要用 PowerShell。

---

### Part 2 — 错误分析（AI 分析）

逐条列出用户日记中存在的问题，格式如下：

```
## ✏️ Writing Analysis

### Grammar Errors（语法错误）
1. ❌ 原文："..." → ✅ 建议："..."
   📝 说明：[中文解释错误原因]

### Word Choice（用词问题）
1. ❌ 原文："..." → ✅ 建议："..."
   📝 说明：[中文解释，包括更自然的表达方式]

### Chinese → English（中文词汇对照）
| 你写的中文 | 对应英文表达 | 例句 |
|-----------|------------|------|
| ...       | ...        | ...  |

### 🌟 Strengths（写得好的地方）
- [正面反馈，鼓励用户]
```

分析原则：
- 态度友好积极，先肯定优点再指出问题
- 解释用中文，便于理解
- 中文词汇转换部分要覆盖所有夹杂的中文词/句
- 如有地道表达建议，也一并给出

---

### Part 3 — 标准英文重写

```
## 📖 Standard English Version

[完整的英文日记，包含 Part 1 的头部信息]

---
*Rewritten for clarity and natural expression.*
```

重写原则：
- 保留用户原意和情感，不要过度改写
- 使用自然、地道的英语表达
- 语气与用户原文保持一致（正式/休闲）
- 保留所有事件、细节、感受
- 长度和原文大致相当，不宜过度扩展或精简

---

### Part 3.5 — 🆕 中文翻译对照（新增！）

在标准英文重写之后，附上对应的完整中文翻译。这是帮助用户理解 AI 重写内容的关键环节。

```
## 🔄 Chinese Translation (中文翻译)

[将 Part 3 的英文日记逐段翻译成通顺的中文]

---
*翻译说明：以上为英文版的标准中文翻译，方便对照学习。*
```

翻译原则：
- 忠实还原 Part 3 英文的含义和语气
- 使用自然的中文表达，不是逐词硬翻
- 段落结构要与 Part 3 一一对应
- 如果英文中有地道表达或习语，在翻译后可加注解释

**展示格式建议（段落对照）：**

```markdown
| 📖 English | 📝 中文 |
|-----------|--------|
| [英文段落1] | [对应中文] |
| [英文段落2] | [对应中文] |
| ... | ... |
```

---

### Part 4 — 自动存入 IMA 笔记

将所有四部分内容合并（Part 1 头部 + 原始日记 + 错误分析 + 英文重写 + 中文翻译），自动调用 IMA API 创建一篇新笔记。

**笔记标题格式**：`English Diary - [英文日期，如 April 19, 2026]`

**笔记内容结构**（Markdown 格式）：

```markdown
# English Diary - [日期]

---

## 📅 Diary Entry (原始日记)

**Date:** [日期]
**Location:** [地点或空]
**Weather:** [天气或空]

[用户原始日记内容（保留原文，中英混杂）]

---

## ✏️ Writing Analysis (错误分析)

[Part 2 的错误分析内容]

---

## 📖 Standard English Version (标准英文重写)

[Part 3 的标准英文重写]

---

## 🔄 Chinese Translation (中文翻译)

[Part 3.5 的中文翻译对照]

---

*Created by English Diary Skill · [日期]*
```

---

## 执行流程

当用户输入日记内容后，按以下步骤执行：

### Step 1：获取地点和天气

使用 Python 调用 API（不要用 PowerShell）：

```bash
# 获取城市名
python -c "import urllib.request,json; r=urllib.request.urlopen('https://ipapi.co/json/',timeout=10); print(json.loads(r.read())['city'])"

# 获取天气
python -c "import urllib.request; r=urllib.request.urlopen('https://wttr.in/Shenzhen?format=%%C+%%t',timeout=10); print(r.read().decode())"
```

如果 `ipapi.co` 超时或失败，尝试备用 `ip-api.com`。

### Step 2：AI 分析日记（自行推理）

直接在对话中完成：
- 解析用户日记中的语法错误
- 识别用词不当之处
- 提取所有中文词汇并给出对应英文
- 给出正面鼓励反馈

### Step 3：重写标准英文版本（自行推理）

直接在对话中完成标准英文重写。

### Step 3.5：生成中文翻译对照（自行推理）

基于 Part 3 的英文内容，生成对应的中文翻译。

### Step 4：调用 IMA API 创建笔记

读取 IMA 凭证并调用 `import_doc` 接口：

**⚠️ 关键注意事项（Windows 环境）：**

1. **必须使用 Python 脚本**调用 IMA API（PowerShell 5.1 有 UTF-8 乱码问题）
2. **文件编码**：读取凭证时使用 `encoding='utf-8-sig'` 自动去除 BOM
3. **stdout 输出**：结果必须用 `sys.stdout.buffer.write()` 写入，避免 latin-1 编码错误
4. **JSON 序列化**：`json.dumps()` 必须加 `ensure_ascii=False` 参数

推荐执行方式：先将笔记内容写入临时 `.txt` 文件，再用 Python 脚本读取并调用 API。

```bash
# 1. 将笔记内容写入临时文件 note_content.txt（UTF-8 无 BOM）

# 2. 用 Python 调用 IMA API
python sync_ima.py
```

Python 同步脚本模板：

```python
import urllib.request, json, sys, os

# 读取凭证（utf-8-sig 自动去除 BOM）
cred_path = os.path.expanduser("~/.config/ima")
with open(os.path.join(cred_path, "client_id"), "r", encoding="utf-8-sig") as f:
    cid = f.read().strip()
with open(os.path.join(cred_path, "api_key"), "r", encoding="utf-8-sig") as f:
    key = f.read().strip()

# 读取笔记内容
with open("note_content.txt", "r", encoding="utf-8-sig") as f:
    content = f.read()

# 构造请求并发送
body = json.dumps({"content_format": 1, "content": content}, ensure_ascii=False).encode("utf-8")
req = urllib.request.Request(
    "https://ima.qq.com/openapi/note/v1/import_doc",
    data=body, method="POST"
)
req.add_header("ima-openapi-clientid", cid)
req.add_header("ima-openapi-apikey", key)  # "apikey" here is the IMA API's official header name, NOT a real API key value
req.add_header("Content-Type", "application/json; charset=utf-8")

resp = urllib.request.urlopen(req, timeout=15)
result = json.loads(resp.read().decode("utf-8"))
sys.stdout.buffer.write(json.dumps(result).encode("utf-8"))
```

---

## 输出格式（对话中展示）

在对话中，按顺序展示所有内容，最后告知 IMA 笔记创建结果：

```
📅 **Part 1 — Diary Header**
[头部信息]

---

[用户原始日记]

---

✏️ **Part 2 — Writing Analysis**
[错误分析]

---

📖 **Part 3 — Standard English Version**
[英文重写]

---

🔄 **Part 3.5 — Chinese Translation**
[中文翻译对照]

---

✅ **已同步到 IMA 笔记**
笔记标题：English Diary - [日期]
笔记 ID：[doc_id]
```

---

## 注意事项

1. **IMA 凭证缺失**：若凭证为空，完成前三部分后告知用户：
   > "✅ 英语分析已完成！但 IMA 笔记同步失败：未找到 IMA 凭证。请前往 https://ima.qq.com/agent-interface 获取 Client ID 和 API Key，并按 ima-skill Setup 步骤配置。"

2. **地点/天气获取失败**：不影响主流程，对应字段留空即可，不报错。

3. **笔记内容过长**：若单次 `import_doc` 返回 100009 错误，将内容拆分为多次写入（先 `import_doc`，再 `append_doc`）。

4. **鼓励为主**：错误分析部分始终保持积极、鼓励的语气，帮助用户建立英语学习信心。

5. **Windows 环境踩坑**：IP 定位、天气获取、IMA API 调用均需通过 Python 执行，避免 PowerShell 5.1 的编码问题。
