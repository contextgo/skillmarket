# 案例导航

本文件只作为案例导航页，详细案例已拆分到更小的参考文件，避免单文件过长导致 embedding 失败。

## 何时读哪份案例

- 产品重打光、场景合成、角度变换、材质替换、精修：
  读 `references/case-products.md`
- 模特图、内衣图、男士内裤、成熟时尚风格：
  读 `references/case-models.md`
- 场景、海报、电商固定交付格式、品牌语气层：
  读 `references/case-scenes-design.md`
- 标签控制、文案添加、换脸合规写法、多图融合、视角转换：
  读 `references/case-advanced.md`

## 推荐读取顺序

1. 先看 `SKILL.md` 判断任务模式
2. 再按任务类型读 1 份主案例文件
3. 必要时再补读 `spatial-control.md`、`brand-tone-map.md`、`ecommerce-deliverables.md`
