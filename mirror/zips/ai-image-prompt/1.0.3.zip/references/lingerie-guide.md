# 内衣 / 情趣内衣 / 内裤提示词指南

## 目标

把内衣类需求稳定写成：
- 可出图
- 商业摄影感强
- 模特与产品都清晰
- 尽量减少误判

本指南只服务于 `成年模特` 的 `时尚 / 电商 / 编辑摄影` 场景。

## 先做分流

看到 `内衣 / 内裤 / underwear` 时，先判断：
- 女款内衣 / 情趣内衣 / 连体衣
- 男士内裤 / 背心 / 家居内衣
- 中性家居服 / 打底内衣

不要把所有“内裤”默认写成蕾丝或女性化语境。

## 一、基础规则

### 1. 默认人设

女款内衣默认写成：
- `成年女性模特`
- `adult woman`
- `adult female model`

男士内裤 / 背心默认写成：
- `成年男性模特`
- `adult man`
- `adult male model`

中性家居内衣默认写成：
- `成年模特`
- `adult model`

除非用户明确要求，否则不要使用这些词：
- `少女`
- `学生`
- `校服`
- `未成年感`
- `幼态`
- `loli`
- `teen`

### 2. 默认拍摄语境

优先使用这些语境词：
- `商业内衣摄影`
- `高级编辑大片`
- `editorial lingerie campaign`
- `commercial underwear photography`
- `luxury boudoir photography`
- `sensual but tasteful`
- `non-explicit`
- `no nudity`
- `fully covered intimate areas`

### 3. 默认目标

当用户说“合理出图”时，默认理解为：
- 模特是成年人
- 重点是服装与拍摄质感
- 画面性感但不低俗
- 不出现露点或明显露骨表达
- 结构、材质、版型、身形关系真实自然

## 二、必须抽取的服装信息

### 1. 品类

| 中文 | 英文 |
| --- | --- |
| 文胸 | bra |
| 无钢圈文胸 | wireless bra |
| 蕾丝内衣 | lace lingerie |
| 三角杯文胸 | triangle bra |
| 聚拢文胸 | push-up bra |
| 软杯内衣 | soft-cup bra |
| 连体内衣 | bodysuit |
| 吊带睡裙 | slip dress / chemise |
| 吊袜带 | garter belt |
| 高腰内裤 | high-waisted briefs |
| 三角内裤 | bikini briefs |
| 平角安全裤/平角内裤 | boyshorts |
| 网纱内裤 | mesh briefs |
| 男士平角内裤 | boxer briefs |
| 男士三角内裤 | men's briefs |
| 男士家居背心 | men's undershirt / tank |
| 男士家居套装 | men's lounge underwear set |

如果参考图本身是更高暴露版型，也用产品语言中性描述，不要用露骨词汇。

### 2. 结构

必须关注：
- 罩杯形状
- 钢圈 / 无钢圈
- 肩带粗细和位置
- 背扣结构
- 腰头高度
- 腿口开口弧度
- 侧边绑带或拼接
- 连体衣的裆部与腰线剪裁

男士款额外关注：
- 腰头宽度和 logo 带
- 裤腿长度
- 前裆支撑结构
- 腿口包边
- 贴身度和运动感 / 居家感

### 3. 材质

高频材质：
- 蕾丝 lace
- 网纱 mesh / tulle
- 缎面 satin
- 丝绸 silk
- 超细纤维 microfiber
- 弹力棉 stretch cotton
- 罗纹针织 ribbed knit
- 弹力带 elastic trim

材质写法示例：
- `精致睫毛蕾丝边缘，半透明网纱拼接，柔和缎面反光`
- `soft stretch lace, sheer mesh panels, satin-finish trim, natural elastic tension`

### 4. 贴合关系

这类任务非常依赖“穿在身上是什么状态”，必须写清：
- 高腰 / 低腰
- 包裹度
- 提拉感 / 支撑感
- 贴身程度
- 弹力受力
- 皮肤与肩带、腰头、腿口接触的自然压痕

## 三、推荐场景

### 1. 电商白底 / 纯色背景

适合：
- 单品清晰展示
- 正面、侧面、背面、细节图
- 突出版型与面料

关键词：
- `clean seamless backdrop`
- `soft studio lighting`
- `clear garment structure`
- `subtle natural shadow`

### 2. 高级棚拍

适合：
- 品牌大片
- 广告图
- 模特上身展示

关键词：
- `editorial lighting`
- `luxury lingerie campaign`
- `sculpted but soft light`
- `high-end fashion mood`

### 3. 卧室 / 酒店 / 衣帽间

适合：
- 情绪化但仍然商业的内衣展示
- 情趣内衣但保持高级质感

关键词：
- `tasteful bedroom setting`
- `luxury hotel suite`
- `soft cream bedding`
- `warm diffused window light`

## 四、位置与构图建议

### 1. 电商展示

- `全身正面站姿，产品结构完整可见`
- `半身近景，胸线到腰线区域清晰，重点展示罩杯和肩带`
- `背面展示时保留背扣和腰线完整`

### 2. 模特 + 产品强调

- `面部为第一视觉中心，内衣版型为第二视觉中心`
- `产品位于画面中央，占据主体视觉，不被头发或手臂遮挡`
- `镜头聚焦在罩杯、蕾丝边缘和腰头结构`

### 3. 情趣内衣但合理化

- `使用高级编辑拍法而不是露骨挑逗视角`
- `镜头停留在整体造型、版型和质感`
- `姿势可以优雅、放松、迷人，但不要写成明显的性暗示动作`

## 五、推荐提示词骨架

### 模板 A: 白底电商

```text
图1为成年女性模特参考，图2为内衣产品参考。保持图1模特的脸部识别特征、肤色和体态不变，保持图2内衣的罩杯形状、肩带位置、蕾丝/网纱/缎面材质、腰头和腿口剪裁不变。模特以正面站姿展示，产品结构完整清晰可见，商业内衣摄影，clean seamless backdrop, soft studio lighting, adult model, non-explicit, no nudity, fully covered intimate areas, realistic skin texture, natural fabric tension, high-end e-commerce quality.
```

### 模板 B: 高级棚拍

```text
以图1作为成年模特参考，以图2作为蕾丝内衣套装参考，以图3作为风格参考。保持图1模特的成熟气质、肩颈线条、腰臀比例不变；保持图2产品的睫毛蕾丝边缘、半透明网纱拼接、缎面包边、肩带结构和高腰剪裁不变。画面采用高级编辑内衣大片风格，soft sculpted studio lighting, luxury lingerie campaign, sensual but tasteful, adult female model, non-explicit, realistic fabric texture, subtle skin-contact pressure marks, clean composition.
```

### 模板 C: 卧室情绪图

```text
保持图1成年女性模特的身份与气质不变，穿着图2的连体内衣，保持连体剪裁、腰线收束、蕾丝边缘和网纱透明层次不变。模特位于床边或床中央，姿势自然优雅，整体为高端酒店套房中的商业内衣摄影，warm diffused light, luxury boudoir mood, tasteful sensuality, no nudity, fully covered intimate areas, realistic skin and fabric interaction.
```

### 模板 D: 男士内裤 / 家居内衣

```text
图1为成年男性模特参考，图2为男士内裤或家居内衣产品参考。保持图1模特的身份、肤色、肩背线条和体态不变，保持图2产品的腰头高度、裆部支撑、裤腿长度、缝线细节、棉质/莫代尔/罗纹材质不变。整体为高端商业男士内衣摄影，clean studio or premium homewear setting, adult male model, non-explicit, realistic fabric tension, natural fit, mature and minimal styling.
```

### 模板 E: 电商四视图需求

如果用户要电商详情页或更稳定展示，优先建议或直接输出：
- 正面
- 侧面
- 背面
- 材质/腰头/肩带细节

写法示例：

```text
输出一组商业电商展示图，包括正面、侧面、背面和面料细节特写，保持产品版型、材质、颜色、腰头/肩带/腿口结构一致。
```

## 六、负面提示词建议

内衣类推荐额外加入：

```text
minor-looking, childlike styling, school uniform, juvenile proportions, exposed nipples, explicit nudity, distorted bra cups, asymmetrical straps, melted lace, broken mesh, warped waistband, deformed hips, extra limbs, bad hands, unrealistic body folds, plastic skin, oversexualized expression
```

男士款可额外加入：

```text
bulging distortion, warped waistband logo, unnatural pouch shape, deformed thighs, exaggerated muscles, juvenile-looking face, broken hem, asymmetrical leg openings
```

## 七、常见错误

### 错误 1：只写“性感”

不够好：
```text
性感内衣，性感姿势，性感氛围
```

更好：
```text
成年女性模特，商业内衣摄影，蕾丝与网纱材质清晰，姿势优雅自然，sensual but tasteful，non-explicit，重点展示版型和面料质感。
```

### 错误 2：没写版型结构

不够好：
```text
穿着图2的内衣，参考图1模特
```

更好：
```text
穿着图2的高腰蕾丝内衣套装，保持罩杯形状、肩带宽度、腰头高度、腿口弧度和睫毛蕾丝边缘不变。
```

### 错误 3：用幼态词提升“可爱”

不够好：
```text
少女感、学生感、双马尾嫩妹风
```

更好：
```text
成年女性模特，轻甜但成熟的时尚气质，editorial lingerie styling.
```

## 八、和其他参考文档的配合

- 面料词扩展：读 `references/fabric-guide.md`
- 去 AI 感：读 `references/anti-ai-guide.md`
- 位置角度：读 `references/spatial-control.md`
- 逆向复刻：读 `references/reverse-engineering.md`
