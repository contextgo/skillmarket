# 模板导航

本文件只作为模板导航页，详细模板已拆分到更小的文件，避免单文件过长导致 embedding 失败。

## 何时读哪份模板

- 人像、模特、日韩风格、欧美腿部特写：
  读 `references/patterns-portraits.md`
- 产品重打光、场景合成、角度变换、材质替换、精修：
  读 `references/patterns-products.md`
- 海报、详情页、Logo、图像编辑、多图融合、九宫格：
  读 `references/patterns-design-editing.md`

## 高优先级规则

- 先做参考图角色分配，再写 prompt
- 位置、比例、角度、镜头必须写进最终提示词
- 内衣 / 内裤任务先读 `lingerie-guide.md`
- 电商固定格式先读 `ecommerce-deliverables.md`
- 品牌感先读 `brand-tone-map.md`
