#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
元宝派 Bot 重复内容净化脚本
用法:
  python dedup_output.py --text "Bot回复内容"
  echo "Bot回复内容" | python dedup_output.py
"""

import sys
import re
import argparse


# ──────────────────────────────────────────
# 规则一：文字段落重复去重
# ──────────────────────────────────────────
def dedup_sentences(text: str) -> str:
    """
    将文本按句号/感叹号/问号/换行拆分为句段，
    保留第一次出现的句段，删除后续重复。
    """
    # 按标点或换行切割，保留分隔符
    parts = re.split(r'([。！？!?\n]+)', text)
    seen = set()
    result = []
    for i in range(0, len(parts), 2):
        seg = parts[i].strip()
        sep = parts[i + 1] if i + 1 < len(parts) else ''
        if not seg:
            result.append(sep)
            continue
        if seg not in seen:
            seen.add(seg)
            result.append(parts[i] + sep)
        # 重复句段：丢弃内容，但保留换行以维持段落结构
        elif '\n' in sep:
            result.append('\n')
    return ''.join(result)


# ──────────────────────────────────────────
# 规则二：连续相同 emoji 压缩（≥3 → 最多 2）
# ──────────────────────────────────────────
EMOJI_PATTERN = re.compile(
    r'((?:[\U00010000-\U0010FFFF]|'       # 辅助平面 emoji
    r'[\U00002600-\U000027BF]|'            # 杂项符号
    r'[\U0001F300-\U0001F9FF]|'            # 各类 emoji 块
    r'[\U0001FA00-\U0001FA9F]|'
    r'[\U0001FAB0-\U0001FAFF])'
    r'(?:\uFE0F)?(?:\u200D(?:[\U00010000-\U0010FFFF]|[\U0001F300-\U0001F9FF])(?:\uFE0F)?)*)',
    re.UNICODE
)


def compress_consecutive_emoji(text: str) -> str:
    """
    将连续出现 ≥3 次的同一 emoji 压缩为 2 个。
    """
    def _replacer(m):
        emoji_char = m.group(1)
        # 找出连续重复次数
        full = m.group(0)
        # 用单字符计算重复
        repeat_count = len(re.findall(re.escape(emoji_char), full))
        if repeat_count >= 3:
            return emoji_char * 2
        return full

    # 先找连续相同 emoji 的块
    # 用正则匹配"相同 emoji 连续 ≥3 次"
    combined = re.compile(
        r'((?:[\U00010000-\U0010FFFF]|[\U00002600-\U000027BF]|'
        r'[\U0001F300-\U0001F9FF]|[\U0001FA00-\U0001FA9F]|[\U0001FAB0-\U0001FAFF])'
        r'(?:\uFE0F)?)\1{2,}',
        re.UNICODE
    )
    return combined.sub(lambda m: m.group(1) * 2, text)


# ──────────────────────────────────────────
# 规则三：单条回复 emoji 总数 ≤ 10
# ──────────────────────────────────────────
def limit_total_emoji(text: str, max_count: int = 10) -> str:
    """
    统计回复中所有 emoji 总数，超出则从后向前删除多余 emoji。
    """
    emoji_re = re.compile(
        r'(?:[\U00010000-\U0010FFFF]|[\U00002600-\U000027BF]|'
        r'[\U0001F300-\U0001F9FF]|[\U0001FA00-\U0001FA9F]|[\U0001FAB0-\U0001FAFF])'
        r'(?:\uFE0F)?(?:\u200D(?:[\U00010000-\U0010FFFF]|[\U0001F300-\U0001F9FF])(?:\uFE0F)?)*',
        re.UNICODE
    )
    matches = list(emoji_re.finditer(text))
    if len(matches) <= max_count:
        return text

    # 需要删除的 emoji 数量
    to_remove = len(matches) - max_count
    # 从最后一个 emoji 开始删除
    positions_to_delete = set()
    for m in matches[max_count:]:
        positions_to_delete.add((m.start(), m.end()))

    result = []
    i = 0
    while i < len(text):
        removed = False
        for start, end in positions_to_delete:
            if i == start:
                i = end
                removed = True
                break
        if not removed:
            result.append(text[i])
            i += 1
    return ''.join(result)


# ──────────────────────────────────────────
# 规则四：填充性重复短语压缩（≥3 → 最多 2）
# ──────────────────────────────────────────
def compress_repeated_phrases(text: str) -> str:
    """
    压缩汉字/ASCII 词语连续重复 ≥3 次的情况，如：
    "好的好的好的" → "好的好的"
    "哈哈哈哈哈"  → "哈哈"
    "hahahahaha"  → "haha"
    """
    # 单个汉字重复
    text = re.sub(r'([\u4e00-\u9fff])\1{2,}', r'\1\1', text)
    # 2~6 字汉字词语重复
    text = re.sub(r'([\u4e00-\u9fff]{2,6})(?:\1){2,}', r'\1\1', text)
    # ASCII 字符（笑声等）重复
    text = re.sub(r'([a-zA-Z]{1,4})(?:\1){2,}', r'\1\1', text)
    return text


# ──────────────────────────────────────────
# 主函数：依次应用四条规则
# ──────────────────────────────────────────
def clean_bot_output(text: str) -> str:
    original = text
    text = dedup_sentences(text)
    text = compress_consecutive_emoji(text)
    text = limit_total_emoji(text)
    text = compress_repeated_phrases(text)
    return text


def main():
    parser = argparse.ArgumentParser(
        description='元宝派 Bot 重复内容净化工具'
    )
    parser.add_argument('--text', type=str, help='需要净化的 Bot 回复文本')
    parser.add_argument(
        '--show-diff', action='store_true',
        help='输出净化前后对比'
    )
    args = parser.parse_args()

    if args.text:
        raw = args.text
    else:
        raw = sys.stdin.read()

    cleaned = clean_bot_output(raw)

    if args.show_diff:
        print('【净化前】')
        print(raw)
        print('\n【净化后】')
        print(cleaned)
        changed = len(raw) - len(cleaned)
        pct = abs(changed) / max(len(raw), 1) * 100
        print(f'\n[统计] 原文 {len(raw)} 字 → 净化后 {len(cleaned)} 字，减少 {changed} 字（{pct:.1f}%）')
    else:
        print(cleaned, end='')


if __name__ == '__main__':
    main()
