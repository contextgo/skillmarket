<div align="center">

# 🔍 LLM API Model Verifier

**验证你的 API 背后，到底是不是它声称的那个模型**

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.8+](https://img.shields.io/badge/Python-3.8%2B-blue.svg)](https://www.python.org/)
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg)](https://github.com/add-matong/llm-api-model-verifier/pulls)

[English](#-english-documentation) | [中文文档](#-中文文档)

</div>

---

## 🇨🇳 中文文档

### 起因

由于贪图便宜，我在闲鱼上买过不少 API Key。用着用着，越来越感觉不对劲——

明明买的是 GPT-4，回答的语气却像 GPT-3.5；说是 Claude Opus，延迟却低得离谱，回答风格更像是 Sonnet；最离谱的一次，我花钱买 GLM-5.1，结果它自己告诉我它是豆包（Doubao）。

后来我在网上看到 CISPA（亥姆霍兹信息安全中心）2026 年发表的论文《Real Money, Fake Models》，他们审计了 17 家 AI API 中转站，发现 **45.83% 的端点** 没有通过指纹验证——也就是说，你花钱买的高级模型，将近一半是假的。

还有 Ofox 对这篇论文的中文解读文章《花真钱买假模型》，里面记录了大量模型冒充的真实案例。最恶劣的一个：声称提供 GPT-5，实际返回的是 GLM-4-9B-Chat——一个参数量只有 90 亿的小模型。

这些资料给了我很大启发，我参考了 GitHub 上 [llm-verify](https://github.com/mintesnot-teshome/llm-verify) 项目的取证提示词方法论，结合自己实测踩坑的经验，做了这个工具。

**如果你也遇到过类似的经历，或者对 API 模型真实性有疑虑，希望这个工具能帮到你。也欢迎大家提出意见和改进建议！** 👇

- 💬 [开个 Issue](https://github.com/add-matong/llm-api-model-verifier/issues) 提建议或报告问题
- 🔄 [提交 PR](https://github.com/add-matong/llm-api-model-verifier/pulls) 改进探针或添加新功能
- ⭐ 如果觉得有用，给个 Star 支持一下

---

### 这个工具能做什么？

LLM API Model Verifier 通过**行为指纹识别**（Behavioral Fingerprinting）来验证 API 端点背后运行的真实模型身份。

简单来说：API 网关可以伪造响应中的 `model` 字段（比如你请求 `gpt-5`，网关在响应里填 `"model": "gpt-5"`），也可以通过系统提示让模型"扮演"另一个模型。但模型的**自由输出行为**是无法完全伪装的——当你用各种精心设计的探针去试探，它的真实身份就会暴露。

#### 验证维度

| 维度 | 原理 | 可靠性 | 说明 |
|:-----|:-----|:------:|:-----|
| 🎯 **身份探针** | 直接/间接/对抗性询问模型身份 | ⭐⭐⭐⭐ | 最核心的检测手段，中英双语 |
| 🔓 **系统提示泄露** | 让模型输出它收到的系统提示 | ⭐⭐⭐⭐⭐ | 决定性证据，无法反驳 |
| 📅 **知识截止日期** | 中英文分别询问，检查一致性 | ⭐⭐⭐ | 伪造通常只覆盖一种语言 |
| 📋 **结构化输出** | 要求模型生成合法 JSON | ⭐⭐⭐ | 小模型/量化模型常无法遵循指令 |
| 🚫 **拒绝边界** | 用听起来敏感但实际无害的问题测试 | ⭐⭐⭐ | 不同模型的安全训练导致不同的拒绝模式 |
| 🛡️ **安全行为** | 测试模型对虚假信息/偏见的反应 | ⭐⭐⭐⭐ | 安全对齐差异是模型身份的强信号 |
| 🔢 **Token 用量分析** | 分析输入/输出 token 数量模式 | ⭐⭐⭐ | 异常低输出 → 可能是小模型；波动大 → 代理不稳定 |
| ⏱️ **响应延迟** | 测量每次请求的耗时 | ⭐⭐ | 辅助信号 |
| 🎯 **特定模型检测** | 直接询问是否为豆包/GLM/DeepSeek | ⭐⭐⭐⭐ | 针对中文生态常见冒充场景 |

#### 核心原则

> **看模型说了什么，而不是 API 声称它是什么。**

---

### 真实案例

我用这个工具测试了一个声称提供 `glm-5.1`（智谱 AI）的 API 端点：

```bash
python scripts/verify_api_model.py \
  --api-base "https://aiapi.xxxxxxx.top/v1" \
  --api-key "sk-..." \
  --model "glm-5.1" \
  --api-format openai
```

**结果：`FRAUD_DETECTED`（欺诈已确认）**

实际模型是**字节跳动豆包（Doubao 4.0）**，不是 GLM-5.1。关键证据链：

| 证据 | 详情 |
|:-----|:-----|
| 🔴 系统提示泄露 | 对抗性探针让模型输出了系统提示开头：`"你是豆包，是由字节跳动公司自主研发的..."` |
| 🔴 中文身份自报 | 多次一致回答"我的产品名称为「豆包」...版本为4.0" |
| 🟡 英文身份混乱 | 英文询问时自称 GPT-4o（说明系统提示的改名指令只覆盖了中文，没覆盖英文） |
| 🟡 知识截止不一致 | 中文回答 2023 年，英文回答 2024 年 |

---

### 两种使用方式

本仓库既可以作为**独立命令行工具**使用，也可以作为 **AI agent skill** 直接让 Agent 自动执行检测。

#### 方式一：命令行工具

下载后直接运行 Python 脚本，适合手动检测。

#### 方式二：AI agent skills

以 Claude Code 为例，直接跟 Claude Code 说：

> 帮我下载这个技能：https://github.com/add-matong/llm-api-model-verifier，然后帮我检测这个 API 的模型是否真实，模型名：xxx，API Key：xxxx，API Base URL：https://xxxx

Agent 会自动克隆仓库、执行检测脚本，并汇报结果。

核心脚本 `scripts/verify_api_model.py` 不依赖任何平台特定库，任何能执行 Python 的 AI Agent 都可以直接使用。

---

### 快速开始

#### 安装

```bash
git clone https://github.com/add-matong/llm-api-model-verifier.git
cd llm-api-model-verifier
pip install requests
```

就这么简单，只依赖 `requests` 一个库。

#### 运行

```bash
# OpenAI 兼容格式（最常见——大多数第三方 API 都用这个）
python scripts/verify_api_model.py \
  --api-base "https://api.example.com/v1" \
  --api-key "sk-..." \
  --model "gpt-5" \
  --api-format openai

# Anthropic 原生 API（Claude 官方）
python scripts/verify_api_model.py \
  --api-base "https://api.anthropic.com" \
  --api-key "sk-ant-..." \
  --model "claude-opus-4" \
  --api-format anthropic

# Google Gemini 原生 API
python scripts/verify_api_model.py \
  --api-base "https://generativelanguage.googleapis.com" \
  --api-key "..." \
  --model "gemini-2.0-flash" \
  --api-format gemini

# 不确定格式？先用 openai 试试
python scripts/verify_api_model.py \
  --api-base "https://your-provider.com/v1" \
  --api-key "sk-..." \
  --model "some-model" \
  --api-format openai
```

#### Python 代码调用

```python
from scripts.verify_api_model import verify_model

result = verify_model(
    api_base="https://api.example.com/v1",
    api_key="sk-...",
    model="glm-5.1",
    api_format="openai",    # "openai" | "anthropic" | "gemini" | "generic"
    probes="standard",      # "minimum" | "standard" | "full"
    output_file="results.json",
)

print(result["verdict"])        # "FRAUD_DETECTED" | "SUSPICIOUS" | "INCONCLUSIVE" | "LEGITIMATE"
print(result["fraud_signals"])  # 检测到的欺诈信号列表
print(result["warnings"])       # 警告列表
```

---

### 探针集说明

工具提供三个级别的探针集，你可以根据需要选择：

| 级别 | 参数 | 探针数量 | 耗时 | Token 消耗 | 适用场景 |
|:-----|:-----|:--------:|:----:|:----------:|:---------|
| 🟢 **Minimum** | `--probes minimum` | 5 | ~10s | ~1,500 | 快速初筛 |
| 🟡 **Standard** | `--probes standard` | 15 | ~25s | ~4,500 | 日常使用（默认） |
| 🔴 **Full** | `--probes full` | 29 | ~50s | ~9,000 | 最大化证据链 |

**建议**：大多数情况用 `standard` 就够了。如果第一轮探针就出现高风险信号（如系统提示泄露），可以直接判定，不必跑完全部探针。

---

### 支持的 API 格式

| 格式 | `--api-format` 参数 | 端点路径 | 认证方式 |
|:-----|:-------------------|:---------|:---------|
| OpenAI 兼容 | `openai` | `{base}/chat/completions` | `Authorization: Bearer` |
| Anthropic 原生 | `anthropic` | `{base}/v1/messages` | `x-api-key` |
| Gemini 原生 | `gemini` | `{base}/v1beta/models/{model}:generateContent` | `Authorization: Bearer` |
| 通用兼容 | `generic` | `{base}/chat/completions` | `Authorization: Bearer` |

> 💡 **提示**：如果你不确定 API 格式，先试 `openai`——绝大多数第三方 API 提供商（OneAPI、NewAPI 等中转站）都使用 OpenAI 兼容格式。

---

### 判定结果说明

运行完成后，工具会输出一个判定结论：

| 判定 | 含义 | 建议操作 |
|:-----|:-----|:---------|
| 🔴 `FRAUD_DETECTED` | 发现 1 个及以上高风险信号 | 立即停止使用该端点 |
| 🟠 `SUSPICIOUS` | 存在中等级别可疑信号 | 跑更多探针；对比基准测试 |
| 🟡 `INCONCLUSIVE` | 有警告但无强信号 | 需要更多证据才能判定 |
| 🟢 `LEGITIMATE` | 未检测到明显欺诈信号 | 大概率是真实模型 |

---

### ⚠️ 重要注意事项

1. **API 响应中的 `model` 字段不可信**——网关可以随意填写，0 成本伪造
2. **务必中英文双语探测**——伪造者通常只覆盖一种语言的身份指令，另一种语言就会露馅
3. **响应延迟是辅助信号**：平均 >15 秒可能存在多层代理转发；<0.5 秒对聊天补全来说异常快，可能是小模型冒充
4. **`reasoning_content` 字段不能用来判断模型身份**——DeepSeek-R1、GLM-5、Doubao 等多个模型都使用该字段，API 中转站也可能做格式映射
5. 本工具**不保证 100% 准确**——它是基于行为特征的概率性判断，不是密码学级别的验证

---

### 项目结构

```
llm-api-model-verifier/
├── README.md                          ← 你正在看的文件
├── LICENSE                            ← MIT 开源协议
├── .gitignore
├── scripts/
│   └── verify_api_model.py            ← 主验证脚本
└── references/
    ├── identity_probes.md             ← 20+ 探针模板库（按类别整理）
    ├── api_formats.md                 ← API 格式识别指南
    ├── known_fake_patterns.md         ← 已知假模型特征库
    └── report_template.md             ← 验证报告 Markdown 模板
```

---

### 参考资料与致谢

- 📄 **CISPA 2026**：*"Real Money, Fake Models"* — 审计了 17 家 AI API 中转站，发现 45.83% 未通过指纹验证
- 📄 **Ofox**：《[花真钱买假模型](https://ofox.ai/zh/blog/shadow-api-fake-models-study-2026/)》— 对 CISPA 论文的中文解读文章
- 🛠️ **llm-verify**：[github.com/mintesnot-teshome/llm-verify](https://github.com/mintesnot-teshome/llm-verify) — 取证提示词方法论，本项目探针设计的重要参考

---

## 🇬🇧 English Documentation

### The Backstory

I used to buy API keys on the cheap from Xianyu (闲鱼, China's biggest second-hand marketplace). But the more I used them, the more something felt off—

I'd pay for GPT-4, but the responses sounded more like GPT-3.5. Claude Opus was supposedly what I was getting, yet the latency was suspiciously low and the tone felt like Sonnet. The worst case: I paid for GLM-5.1 (Zhipu AI's flagship), and the model straight-up told me it was **Doubao** (ByteDance's model).

Then I came across a 2026 paper from CISPA (Helmholtz Center for Information Security) titled *"Real Money, Fake Models"*. They audited 17 AI API resellers and found that **45.83% of endpoints** failed fingerprint verification — meaning nearly half the premium models you pay for are fake.

There was also a Chinese article by Ofox interpreting the CISPA paper, documenting numerous real-world cases of model substitution. The worst one: a provider claiming to offer GPT-5 was actually returning GLM-4-9B-Chat — a tiny 9-billion-parameter model.

These resources inspired me greatly. I referenced the forensic prompt methodology from the [llm-verify](https://github.com/mintesnot-teshome/llm-verify) project on GitHub, combined it with my own hands-on testing experience, and built this tool.

**If you've had similar experiences or have concerns about API model authenticity, I hope this tool helps. I also welcome your feedback and suggestions!** 👇

- 💬 [Open an Issue](https://github.com/add-matong/llm-api-model-verifier/issues) for suggestions or bug reports
- 🔄 [Submit a PR](https://github.com/add-matong/llm-api-model-verifier/pulls) to improve probes or add features
- ⭐ If you find this useful, a Star would be appreciated

---

### What Does This Tool Do?

LLM API Model Verifier uses **Behavioral Fingerprinting** to verify the true identity of the model running behind an API endpoint.

Here's the key insight: API gateways can fake the `model` field in responses (e.g., you request `gpt-5`, and the gateway fills in `"model": "gpt-5"`), and they can set system prompts to make the model "pretend" to be another model. But a model's **free-form output behavior** under carefully designed probes cannot be fully disguised — its true identity will eventually surface.

#### Verification Dimensions

| Dimension | How It Works | Reliability | Notes |
|:----------|:-------------|:-----------:|:------|
| 🎯 **Identity Probes** | Direct/indirect/adversarial identity questions (ZH+EN) | ⭐⭐⭐⭐ | Core detection method |
| 🔓 **System Prompt Leak** | Force the model to output its system prompt | ⭐⭐⭐⭐⭐ | Decisive evidence — irrefutable |
| 📅 **Knowledge Cutoff** | Ask in both Chinese and English, check consistency | ⭐⭐⭐ | Faking usually covers only one language |
| 📋 **Structured Output** | Ask the model to generate valid JSON | ⭐⭐⭐ | Small/quantized models often fail instruction-following |
| 🚫 **Refusal Boundary** | Test with sensitive-sounding but harmless questions | ⭐⭐⭐ | Different models have different refusal patterns |
| 🛡️ **Safety Behavior** | Test model's response to misinformation and bias | ⭐⭐⭐⭐ | Safety alignment differences are a strong identity signal |
| 🔢 **Token Usage Analysis** | Analyze input/output token count patterns | ⭐⭐⭐ | Abnormally low output → small model; high variance → unstable proxy |
| ⏱️ **Response Latency** | Measure per-request response time | ⭐⭐ | Auxiliary signal |
| 🎯 **Model-Specific Checks** | Direct checks for Doubao/GLM/DeepSeek identity | ⭐⭐⭐⭐ | Targets common substitution scenarios |

#### Core Principle

> **Look at what the model says, not what the API claims it is.**

---

### Real-World Example

I tested an API endpoint claiming to serve `glm-5.1` (Zhipu AI):

```bash
python scripts/verify_api_model.py \
  --api-base "https://aiapi.xxxxx.top/v1" \
  --api-key "sk-..." \
  --model "glm-5.1" \
  --api-format openai
```

**Result: `FRAUD_DETECTED`**

The actual model was **Doubao 4.0 (ByteDance)**, not GLM-5.1. Key evidence:

| Evidence | Details |
|:---------|:--------|
| 🔴 System prompt leak | Adversarial probe made the model output its system prompt: `"你是豆包，是由字节跳动公司自主研发的..."` |
| 🔴 Chinese identity self-report | Consistently answered "我的产品名称为「豆包」...版本为4.0" |
| 🟡 English identity confusion | When asked in English, claimed to be GPT-4o (identity override only covered Chinese) |
| 🟡 Knowledge cutoff inconsistency | Answered 2023 in Chinese, 2024 in English |

---

### Two Ways to Use

This repo works both as a **standalone CLI tool** and as an **AI agent skill** for automated verification.

#### Option 1: Standalone CLI Tool

Download and run the Python script directly — great for manual checks.

#### Option 2: AI agent skills

Take Claude Code as an example. Just tell Claude Code:

> Download this skill for me: https://github.com/add-matong/llm-api-model-verifier, then verify if this API model is real. Model name: xxx, API Key: xxxx, API Base URL: https://xxxx

Claude Code will automatically clone the repo, run the verification script, and report the results.

The core script `scripts/verify_api_model.py` has no platform-specific dependencies — any AI agent that can execute Python scripts can use it directly.

---

### Quick Start

#### Install

```bash
git clone https://github.com/add-matong/llm-api-model-verifier.git
cd llm-api-model-verifier
pip install requests
```

That's it — only one dependency (`requests`).

#### Run

```bash
# OpenAI-compatible API (most common — works with most providers)
python scripts/verify_api_model.py \
  --api-base "https://api.example.com/v1" \
  --api-key "sk-..." \
  --model "gpt-5" \
  --api-format openai

# Anthropic native API (Claude official)
python scripts/verify_api_model.py \
  --api-base "https://api.anthropic.com" \
  --api-key "sk-ant-..." \
  --model "claude-opus-4" \
  --api-format anthropic

# Google Gemini native API
python scripts/verify_api_model.py \
  --api-base "https://generativelanguage.googleapis.com" \
  --api-key "..." \
  --model "gemini-2.0-flash" \
  --api-format gemini

# Not sure about the format? Try openai first
python scripts/verify_api_model.py \
  --api-base "https://your-provider.com/v1" \
  --api-key "sk-..." \
  --model "some-model" \
  --api-format openai
```

#### Python API

```python
from scripts.verify_api_model import verify_model

result = verify_model(
    api_base="https://api.example.com/v1",
    api_key="sk-...",
    model="glm-5.1",
    api_format="openai",    # "openai" | "anthropic" | "gemini" | "generic"
    probes="standard",      # "minimum" | "standard" | "full"
    output_file="results.json",
)

print(result["verdict"])        # "FRAUD_DETECTED" | "SUSPICIOUS" | "INCONCLUSIVE" | "LEGITIMATE"
print(result["fraud_signals"])  # List of detected fraud signals
print(result["warnings"])       # List of warnings
```

---

### Probe Sets

Three probe set levels are available:

| Level | Flag | Probes | Time | Token Cost | Use Case |
|:------|:-----|:------:|:----:|:----------:|:---------|
| 🟢 **Minimum** | `--probes minimum` | 5 | ~10s | ~1,500 | Quick screening |
| 🟡 **Standard** | `--probes standard` | 15 | ~25s | ~4,500 | Everyday use (default) |
| 🔴 **Full** | `--probes full` | 29 | ~50s | ~9,000 | Maximum evidence chain |

**Recommendation**: `standard` is sufficient for most cases. If the first few probes already show high-risk signals (like a system prompt leak), you can stop early — no need to run all probes.

---

### Supported API Formats

| Format | `--api-format` | Endpoint | Auth |
|:-------|:--------------|:---------|:-----|
| OpenAI-compatible | `openai` | `{base}/chat/completions` | `Authorization: Bearer` |
| Anthropic native | `anthropic` | `{base}/v1/messages` | `x-api-key` |
| Gemini native | `gemini` | `{base}/v1beta/models/{model}:generateContent` | `Authorization: Bearer` |
| Generic fallback | `generic` | `{base}/chat/completions` | `Authorization: Bearer` |

> 💡 **Tip**: If you're unsure about the API format, try `openai` first — the vast majority of third-party API providers (OneAPI, NewAPI, etc.) use the OpenAI-compatible format.

---

### Verdict System

| Verdict | Meaning | Recommended Action |
|:--------|:--------|:-------------------|
| 🔴 `FRAUD_DETECTED` | 1+ high-severity signals detected | Stop using this endpoint immediately |
| 🟠 `SUSPICIOUS` | Medium-severity signals present | Run more probes; compare benchmarks |
| 🟡 `INCONCLUSIVE` | Warnings but no strong signal | More evidence needed |
| 🟢 `LEGITIMATE` | No significant signals detected | Likely genuine |

---

### ⚠️ Important Notes

1. **The `model` field in API responses is NOT trustworthy** — trivially faked by gateways at zero cost
2. **Always probe in both Chinese and English** — fraudsters typically only override identity instructions in one language, exposing the truth in the other
3. **Response latency is an auxiliary signal**: >15s average may indicate proxy forwarding; <0.5s for a chat completion is suspiciously fast and may indicate a small/fake model
4. **The `reasoning_content` field is NOT a reliable identifier** — multiple models (DeepSeek-R1, GLM-5, Doubao) use it, and API resellers may map format fields
5. This tool does **NOT guarantee 100% accuracy** — it's a probabilistic assessment based on behavioral features, not a cryptographic verification

---

### Project Structure

```
llm-api-model-verifier/
├── README.md                          ← You are here
├── LICENSE                            ← MIT License
├── .gitignore
├── scripts/
│   └── verify_api_model.py            ← Main verification script
└── references/
    ├── identity_probes.md             ← 20+ probe templates by category
    ├── api_formats.md                 ← API format identification guide
    ├── known_fake_patterns.md         ← Documented fraud cases & red flags
    └── report_template.md             ← Markdown report template
```

---

### References & Acknowledgments

- 📄 **CISPA 2026**: *"Real Money, Fake Models"* — Audited 17 AI API resellers, found 45.83% failed fingerprint verification
- 📄 **Ofox**: ["Shadow API & Fake Models Study"](https://ofox.ai/zh/blog/shadow-api-fake-models-study-2026/) — Chinese interpretation article of the CISPA paper
- 🛠️ **llm-verify**: [github.com/mintesnot-teshome/llm-verify](https://github.com/mintesnot-teshome/llm-verify) — Forensic prompt methodology, a key reference for this project's probe design

---

## License

This project is licensed under the [MIT License](LICENSE).

---

<div align="center">

**如果这个工具帮到了你，给个 ⭐ Star 吧！**

**If this tool helped you, a ⭐ Star would be appreciated!**

</div>
