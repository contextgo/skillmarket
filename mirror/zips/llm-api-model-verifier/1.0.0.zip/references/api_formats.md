# API Format Reference

How to identify which API format a provider uses, and the correct
endpoint URL for each format.

## Format 1: OpenAI-Compatible (most common)

**How to recognize:**
- API docs mention `/v1/chat/completions`
- Request body uses `{"model": "...", "messages": [...]}`
- Auth header: `Authorization: Bearer sk-...`

**Endpoint:**
```
POST {base}/v1/chat/completions
```

**Example providers:**
- OpenAI official: `https://api.openai.com/v1`
- Most third-party resellers (OneAPI/NewAPI-based)
- Together AI, Replicate (chat endpoint)

**CLI flag:** `--api-format openai`

---

## Format 2: Anthropic Native (Claude)

**How to recognize:**
- API docs mention `/v1/messages`
- Request body uses `{"model": "...", "messages": [...], "max_tokens": N}`
- Auth header: `x-api-key: sk-ant-...`
- Response has `{"content": [{"type": "text", "text": "..."}]}`

**Endpoint:**
```
POST {base}/v1/messages
```

**Example providers:**
- Anthropic official: `https://api.anthropic.com`
- AWS Bedrock (different auth)
- Google Cloud Vertex AI (different auth)

**CLI flag:** `--api-format anthropic`

---

## Format 3: Gemini Native (Google)

**How to recognize:**
- API docs mention `:generateContent`
- URL contains model name: `/v1beta/models/{model}:generateContent?key=...`
- Request body uses `{"contents": [{"role": "user", "parts": [{"text": "..."}]}]}`
- Auth: API key in URL query param `?key=` or `Authorization: Bearer`

**Endpoint:**
```
POST {base}/v1beta/models/{model}:generateContent
```

**Example providers:**
- Google AI Studio: `https://generativelanguage.googleapis.com`
- Vertex AI (different auth)

**CLI flag:** `--api-format gemini`

---

## Format 4: Generic OpenAI-Compatible (fallback)

Use when the provider claims OpenAI compatibility but the endpoint
is slightly non-standard (e.g., no `/v1/` prefix).

**When to use:**
- Provider says "OpenAI compatible" but `/v1/chat/completions` returns 404
- Try `generic` first, then adjust the `--api-base` manually

**CLI flag:** `--api-format generic`

---

## How to Determine the Correct Format

### Step 1: Check Provider Documentation
Look for example `curl` commands in their API docs:
- `curl https://api.example.com/v1/chat/completions` → `openai`
- `curl https://api.example.com/v1/messages` → `anthropic`
- `:generateContent` in URL → `gemini`

### Step 2: Try the Most Likely Format
Most third-party providers (resellers) use **OpenAI-compatible** format.
Start with `--api-format openai`.

### Step 3: Check the Error Message
If the format is wrong, the API usually returns a distinctive error:
- `404 Not Found` on `/v1/chat/completions` → try `generic` (may not have `/v1/`)
- `401 Unauthorized` with `Authorization` header → may need `anthropic` format (`x-api-key`)
- Response is not JSON → check if URL is correct

---

## Common Mistakes

| Mistake | Symptom | Fix |
|---------|----------|-----|
| Missing `/v1/` prefix | 404 error | Use `--api-format openai` (adds `/v1/`) |
| Using `Authorization` for Anthropic | 401 error | Use `--api-format anthropic` |
| Model in URL (Gemini) | 404 or "model not found" | Use `--api-format gemini` |
| Wrong port (e.g., `:8080`) | Connection timeout | Check provider's exact base URL |

---

## Provider-Specific Notes

### OneAPI / NewAPI (common reseller stack)
- Format: `openai`
- Base URL: usually `https://{domain}/v1` (may include port)
- Model field: often faked (returns requested model name)

### OpenRouter
- Format: `openai`
- Base URL: `https://openrouter.ai/api/v1`
- Model field: truthful (returns actual model used)

### Azure OpenAI
- Format: `openai` (but URL structure differs)
- Base URL: `https://{resource}.openai.azure.com/openai/deployments/{deployment}/chat/completions?api-version=2024-02-15-preview`
- Note: Azure uses deployment name, not model name, in the URL

### Together AI
- Format: `openai`
- Base URL: `https://api.together.xyz/v1`

### Replicate
- Format: `openai` (chat endpoint)
- Base URL: `https://api.replicate.com/v1`
