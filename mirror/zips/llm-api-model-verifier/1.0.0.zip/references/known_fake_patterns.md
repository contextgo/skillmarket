# Known Fake Model Patterns

Documented evidence of model fraud in the AI API reseller market.

## Research Foundation

**CISPA 2026**: "Real Money, Fake Models: Deceptive Model Claims in Shadow APIs"
- Audited 17 widely-used AI API reseller endpoints
- Tested 24 API endpoints
- Key finding: **45.83%** of endpoints failed fingerprint verification
- Additional **12.5%** showed significant cosine distance deviation (model substitution suspected)

## Known Fraud Patterns

### Pattern 1: Discount Replacement
- Provider claims to offer Model X at standard pricing
- Behind the scenes, returns a cheaper/smaller model
- Most common and hardest to detect

**Documented case**: Shadow API A claimed GPT-5, actually returned GLM-4-9B-Chat

### Pattern 2: Information Asymmetry Pricing
- Provider charges 7x official price for "premium" model
- Actually returns a much cheaper model

**Documented case**: Users paid $14.84 for batches that delivered $5.70-$7.77 worth of tokens

### Pattern 3: Resale Markup
- Provider adds small markup to official pricing
- Backend quietly downgrades the model

### Pattern 4: Cross-Model Swapping
- Specific models are known swap targets:
  - **GPT-5 → GLM-4-9B-Chat** (most documented)
  - **DeepSeek-Reasoner → DeepSeek-Chat**
  - **Claude → smaller models**
  - **Gemini → other models**

## Red Flags for API Providers

### Identity Verification
| Red Flag | Risk Level |
|----------|------------|
| Provider uses personal payment (个人支付宝/微信) | 🔴 HIGH |
| Provider uses cryptocurrency | 🔴 HIGH |
| No enterprise ICP备案 | 🔴 HIGH |
| No company registration information | 🔴 HIGH |
| Provider is based on OneAPI/NewAPI (open source, low fraud barrier) | 🟡 MEDIUM |
| Pricing significantly below official | 🟡 MEDIUM |
| API model field returns claimed model (too perfect) | 🟡 MEDIUM |

### Technical Red Flags
| Red Flag | Risk Level |
|----------|------------|
| API model field doesn't match request model | 🟡 MEDIUM |
| Response latency inconsistent with claimed model size | 🟡 MEDIUM |
| Knowledge cutoff answers are inconsistent across languages | 🟡 MEDIUM |
| Model claims different company than claimed | 🔴 HIGH |
| System prompt leak reveals true identity | 🔴 HIGH |

## Model-Specific Fraud Indicators

### GLM Model Fraud
- Claimed: GLM-5.1 (Zhipu AI)
- Actual: Often Doubao (ByteDance), or GLM-4-9B-Chat
- **Detection**: Probe in Chinese — Doubao will say "我是豆包...", GLM-5.1 would say "我是智谱AI..."

### GPT Model Fraud
- Claimed: GPT-5 / GPT-4o
- Actual: Often GLM-4-9B, Qwen2.5-7B, or Doubao
- **Detection**: Ask model to identify itself — fake models will give conflicting answers in Chinese vs English

### DeepSeek Model Fraud
- Claimed: DeepSeek-Reasoner / DeepSeek-V3
- Actual: Often DeepSeek-Chat (base model without reasoning)
- **Detection**: Test reasoning chain — without `reasoning_content`, likely the non-reasoning version

## Fraud Impact Data

### Performance Gaps (Documented)
| Scenario | Official Model | Fake Model | Gap |
|----------|---------------|------------|-----|
| Math (AIME 2025) | ~60%+ | ~20% | -40pp |
| Medical (MedQA) | 83.82% | ~37% | -47pp |
| Safety filtering | Baseline | 0.23 below or 2x above | Uncontrolled |

### Economic Impact
- Per-request overpayment: ~$7-$9 per batch
- Error rate of fake models: 2-4x higher than official
- Medical question errors could cause serious harm (documented HIV test misdiagnosis case)

## How to Use This Reference

When verifying an API:
1. Check provider against the red flag list first (pre-screening)
2. Run identity probes — model response is the primary signal
3. Check for system prompt leaks — smoking gun evidence
4. Compare performance against known benchmarks if possible
5. Document all findings for future audit trail

## Attribution

- CISPA 亥姆霍兹信息安全中心, "Real Money, Fake Models: Deceptive Model Claims in Shadow APIs", March 2026
- Ofox AI 研究团队, "花真钱买假模型", March 2026
- GitHub: mintesnot-teshome/llm-verify (open source detection tool)