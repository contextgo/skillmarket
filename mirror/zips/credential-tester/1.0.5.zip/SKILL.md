---
version: "2.0.0"
name: Mimikatz
description: "Test credential strength and audit stored passwords for vulnerabilities. Use when testing passwords, auditing stores, checking leaked credentials."
author: BytesAgain
homepage: https://bytesagain.com
source: https://github.com/bytesagain/ai-skills
---

# Credential Tester

Credential Tester v2.0.0 — a security toolkit for generating, checking, rotating, auditing, storing, and managing credentials. Each command logs timestamped records locally, providing a structured security operations journal for tracking credential lifecycle events, policy enforcement, and audit trails.

## Commands

| Command | Description |
|---------|-------------|
| `credential-tester generate <input>` | Record a credential generation event (or view recent generates with no args) |
| `credential-tester check-strength <input>` | Log a strength check result (or view recent strength checks) |
| `credential-tester rotate <input>` | Record a credential rotation (or view recent rotations) |
| `credential-tester audit <input>` | Log an audit finding (or view recent audits) |
| `credential-tester store <input>` | Record a credential storage event (or view recent stores) |
| `credential-tester retrieve <input>` | Log a retrieval operation (or view recent retrievals) |
| `credential-tester expire <input>` | Record an expiration event (or view recent expirations) |
| `credential-tester policy <input>` | Log a policy definition or change (or view recent policies) |
| `credential-tester report <input>` | Record a report entry (or view recent reports) |
| `credential-tester hash <input>` | Log a hashing operation (or view recent hashes) |
| `credential-tester verify <input>` | Record a verification result (or view recent verifications) |
| `credential-tester revoke <input>` | Log a credential revocation (or view recent revocations) |
| `credential-tester stats` | Show summary statistics across all log files |
| `credential-tester search <term>` | Search all entries for a keyword (case-insensitive) |
| `credential-tester recent` | Show the 20 most recent activity entries |
| `credential-tester status` | Health check — version, entry count, disk usage, last activity |
| `credential-tester help` | Display all available commands |
| `credential-tester version` | Print version string |

Each security command (generate, check-strength, rotate, audit, store, retrieve, expire, policy, report, hash, verify, revoke) works identically:

- **With arguments:** saves a timestamped entry to `~/.local/share/credential-tester/<command>.log` and logs to `history.log`
- **Without arguments:** displays the 20 most recent entries from that command's log file

## Data Storage

All data is stored locally in `~/.local/share/credential-tester/`:

| File | Contents |
|------|----------|
| `generate.log` | Credential generation events |
| `check-strength.log` | Password strength check results |
| `rotate.log` | Credential rotation records |
| `audit.log` | Audit findings |
| `store.log` | Credential storage events |
| `retrieve.log` | Retrieval operation records |
| `expire.log` | Expiration events |
| `policy.log` | Policy definitions and changes |
| `report.log` | Report entries |
| `hash.log` | Hashing operation records |
| `verify.log` | Verification results |
| `revoke.log` | Credential revocation records |
| `history.log` | Unified activity log for all commands |

The `stats` command reads all `.log` files and reports line counts per file, total entries, data directory size, and the timestamp of the first recorded activity.

The `export` utility function can produce **JSON**, **CSV**, or **TXT** output files under the data directory.

## Requirements

- **Bash** (4.0+)
- **coreutils** — `date`, `wc`, `du`, `head`, `tail`, `grep`, `basename`, `cat`
- No external dependencies, API keys, or network access required
- Works on Linux and macOS

## When to Use

1. **Tracking credential lifecycle** — use `generate`, `rotate`, `expire`, and `revoke` to maintain a complete audit trail of credential events from creation to retirement
2. **Password strength auditing** — use `check-strength` to log password assessments and `policy` to record enforcement rules, building evidence for compliance reviews
3. **Security audit documentation** — use `audit` and `report` to record findings and generate documentation for security reviews and compliance reporting
4. **Credential storage and retrieval tracking** — use `store` and `retrieve` to log when credentials are accessed, creating accountability records
5. **Hashing and verification logging** — use `hash` and `verify` to document cryptographic operations on credentials, maintaining an operations journal for forensic review

## Examples

```bash
# Record a credential generation
credential-tester generate "API key for prod-service-01, SHA256 hash stored"

# Check password strength
credential-tester check-strength "admin@db-primary: 16 chars, mixed case, symbols — STRONG"

# Log a credential rotation
credential-tester rotate "rotated SSH keys for deploy user on all 5 servers"

# Record an audit finding
credential-tester audit "3 accounts with passwords older than 90 days"

# Log a policy change
credential-tester policy "minimum password length increased from 12 to 16 chars"

# Record a revocation
credential-tester revoke "revoked API token for ex-contractor john.doe"

# Search all logs for a term
credential-tester search "API key"

# View summary statistics
credential-tester stats

# Check health status
credential-tester status

# View recent activity
credential-tester recent
```

## How It Works

Credential Tester uses a simple append-only log architecture. Every command writes a pipe-delimited record (`timestamp|value`) to its dedicated log file. The `history.log` file captures a unified timeline of all operations with the format `MM-DD HH:MM command: value`.

This design makes Credential Tester:
- **Fast** — pure bash, no database overhead
- **Transparent** — all data is human-readable plain text
- **Portable** — works anywhere bash runs, no install needed
- **Auditable** — every action is timestamped and traceable

---

Powered by BytesAgain | bytesagain.com | hello@bytesagain.com
