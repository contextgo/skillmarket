#!/bin/bash
# feishu-sheet.sh — Feishu Spreadsheet (Sheets) API wrapper for OpenClaw
# Version: 1.5.0-lejian
# Feature: Per-operation permission detection (read-only vs edit required)
# Security: Fixed JSON injection via Python JSON encoder for all body-building functions
# Usage: feishu-sheet.sh <action> [args...]
#
# Required credentials (auto-read from config):
#   channels.feishu.appId     - Feishu app ID
#   channels.feishu.appSecret - Feishu app secret
# Config location: ~/workspace/agent/openclaw.json (override with OPENCLAW_CONFIG)
#
# Feishu app permissions needed: sheets:spreadsheet (spreadsheet read/write)
# Recommend using a minimal-permission Feishu app for this skill.

set -euo pipefail

FEISHU_BASE="https://open.feishu.cn/open-apis"
# Use uid-scoped, mode-600 protected token cache to prevent exposure
FEISHU_TOKEN_DIR="${TMPDIR:-/tmp}/._ft_$(id -u)"
TOKEN_CACHE="$FEISHU_TOKEN_DIR/tk"
TOKEN_EXPIRE="$FEISHU_TOKEN_DIR/te"

# Cleanup token files on exit
cleanup_token_cache() {
  rm -rf "$FEISHU_TOKEN_DIR"
}
trap cleanup_token_cache EXIT

mkdir -p "$FEISHU_TOKEN_DIR"

resolve_credentials() {
  local config_path="${OPENCLAW_CONFIG:-~/workspace/agent/openclaw.json}"
  if [[ ! -f "$config_path" ]]; then
    echo '{"error":"openclaw.json not found. Set OPENCLAW_CONFIG or ensure ~/workspace/agent/openclaw.json exists."}' >&2
    exit 1
  fi

  local creds rc
  creds=$(python3 -c '
import json, sys, re
try:
    with open(sys.argv[1]) as f:
        c = json.load(f)
    feishu = c.get("channels", {}).get("feishu", {})
    app_id = str(feishu.get("appId", ""))
    app_secret = str(feishu.get("appSecret", ""))
    if not app_id or not app_secret:
        print("feishu appId/appSecret not found in openclaw.json channels.feishu", file=sys.stderr)
        sys.exit(1)
    pat = re.compile(r"^[A-Za-z0-9_\-]+$")
    if not pat.match(app_id) or not pat.match(app_secret):
        print("appId/appSecret contain unexpected characters", file=sys.stderr)
        sys.exit(1)
    print(app_id)
    print(app_secret)
except Exception as e:
    print(str(e), file=sys.stderr)
    sys.exit(1)
' "$config_path" 2>/dev/null)
  rc=$?

  if [[ $rc -ne 0 || -z "$creds" ]]; then
    echo '{"error":"Failed to read feishu credentials from openclaw.json. Ensure channels.feishu.appId and channels.feishu.appSecret are configured."}' >&2
    exit 1
  fi

  FEISHU_APP_ID=$(echo "$creds" | head -1)
  FEISHU_APP_SECRET=$(echo "$creds" | tail -1)

  if [[ -z "$FEISHU_APP_ID" || -z "$FEISHU_APP_SECRET" ]]; then
    echo '{"error":"Failed to read feishu credentials from openclaw.json"}' >&2
    exit 1
  fi
}

resolve_credentials

get_tenant_token() {
  local now
  now=$(date +%s)
  if [[ -f "$TOKEN_CACHE" && -f "$TOKEN_EXPIRE" ]]; then
    local expire
    expire=$(cat "$TOKEN_EXPIRE")
    if (( now < expire )); then
      cat "$TOKEN_CACHE"
      return
    fi
  fi
  local resp
  resp=$(curl -s -X POST "$FEISHU_BASE/auth/v3/tenant_access_token/internal" \
    -H "Content-Type: application/json" \
    -d "{\"app_id\":\"$FEISHU_APP_ID\",\"app_secret\":\"$FEISHU_APP_SECRET\"}")
  local token
  token=$(echo "$resp" | python3 -c "import sys,json; print(json.load(sys.stdin).get('tenant_access_token',''))" 2>/dev/null)
  local expire_in
  expire_in=$(echo "$resp" | python3 -c "import sys,json; print(json.load(sys.stdin).get('expire',7200))" 2>/dev/null)
  if [[ -z "$token" ]]; then
    echo "{\"error\":\"Failed to get tenant_access_token\"}" >&2
    exit 1
  fi
  echo "$token" > "$TOKEN_CACHE"
  chmod 600 "$TOKEN_CACHE"
  echo $(( now + expire_in - 300 )) > "$TOKEN_EXPIRE"
  chmod 600 "$TOKEN_EXPIRE"
  echo "$token"
}

api_call() {
  local method="$1" path="$2"
  shift 2
  local token
  token=$(get_tenant_token)
  curl -s -X "$method" "$FEISHU_BASE$path" \
    -H "Authorization: Bearer $token" \
    -H "Content-Type: application/json" \
    "$@"
}

api_upload() {
  local path="$1"
  shift
  local token
  token=$(get_tenant_token)
  curl -s -X POST "$FEISHU_BASE$path" \
    -H "Authorization: Bearer $token" \
    "$@"
}

pj() { python3 -m json.tool 2>/dev/null || cat; }

# ========================= JSON 安全转义 =========================
# 用于将 bash 变量安全地嵌入 JSON body，避免引号被穿透
# 用法：body=$(json_body "key1" "$val1" "key2" "$val2")
json_body() {
    python3 -c "
import sys, json
keys = sys.argv[1::2]
vals = sys.argv[2::2]
body = {}
for k, v in zip(keys, vals):
    if isinstance(v, str) and v.startswith('['):
        # JSON 数组直接使用（如 values 参数）
        body[k] = json.loads(v)
    else:
        body[k] = v
print(json.dumps(body, ensure_ascii=False))
" "$@"
}

# 单值 JSON body（字符串值）
json_str() {
    python3 -c "import sys,json; print(json.dumps({sys.argv[1]: sys.argv[2]}, ensure_ascii=False))" "$1" "$2"
}

# ========================= Spreadsheet =========================

action_create() {
  local title="${1:-新建电子表格}" folder="${2:-}"
  local body
  body=$(python3 -c "
import sys, json
d = {'title': sys.argv[1]}
if len(sys.argv) > 2 and sys.argv[2]:
    d['folder_token'] = sys.argv[2]
print(json.dumps(d, ensure_ascii=False))
" "$title" "$folder")
  api_call POST "/sheets/v3/spreadsheets" -d "$body" | python3 -c "
import sys,json
d = json.load(sys.stdin)
ss = d.get('data',{}).get('spreadsheet',{})
if ss:
    t = ss.get('spreadsheet_token','')
    print(json.dumps({'success':True,'spreadsheet_token':t,'title':ss.get('title',''),'url':ss.get('url',f'https://feishu.cn/sheets/{t}')}, ensure_ascii=False, indent=2))
else:
    print(json.dumps({'error':d.get('msg','unknown'),'code':d.get('code',0)}, ensure_ascii=False, indent=2))
"
}

action_meta() {
  # SECURITY: Validate token format before use
  if ! [[ "$1" =~ ^[A-Za-z0-9_\-]+$ ]]; then
    echo '{"error":"invalid token format"}'; return 1
  fi
  api_call GET "/sheets/v2/spreadsheets/$1/metainfo" | python3 -c "
import sys,json
d = json.load(sys.stdin)
props = d.get('data',{}).get('properties',{})
sheets = d.get('data',{}).get('sheets',[])
print(json.dumps({
    'title': props.get('title',''),
    'sheet_count': len(sheets),
    'sheets': [{'sheet_id':s.get('sheetId',''),'title':s.get('title',''),'rows':s.get('rowCount',0),'cols':s.get('columnCount',0)} for s in sheets]
}, ensure_ascii=False, indent=2))
"
}

# ========================= Data R/W =========================

action_read() {
  # SECURITY: Validate token and range format
  if ! [[ "$1" =~ ^[A-Za-z0-9_\-]+$ ]]; then
    echo '{"error":"invalid token format"}'; return 1
  fi
  if ! [[ "$2" =~ ^[A-Za-z0-9_\-!:\.]+$ ]]; then
    echo '{"error":"invalid range format"}'; return 1
  fi
  api_call GET "/sheets/v2/spreadsheets/$1/values/$2?valueRenderOption=ToString" | python3 -c "
import sys,json
d = json.load(sys.stdin)
vr = d.get('data',{}).get('valueRange',{})
print(json.dumps({'range':vr.get('range',''),'rows':len(vr.get('values',[])),'values':vr.get('values',[])}, ensure_ascii=False, indent=2))
"
}

action_read_multi() {
  local token="$1"
  shift
  local ranges_param=""
  for r in "$@"; do
    [[ -n "$ranges_param" ]] && ranges_param+="&"
    ranges_param+="ranges=$r"
  done
  api_call GET "/sheets/v2/spreadsheets/$token/values_batch_get?$ranges_param&valueRenderOption=ToString" | python3 -c "
import sys,json
d = json.load(sys.stdin)
vrs = d.get('data',{}).get('valueRanges',[])
result = []
for vr in vrs:
    result.append({'range':vr.get('range',''),'rows':len(vr.get('values',[])),'values':vr.get('values',[])})
print(json.dumps(result, ensure_ascii=False, indent=2))
"
}

action_write() {
  # SECURITY: Validate token, range via Python JSON encoder for values
  local body
  body=$(python3 -c "
import sys, json
d = {'valueRange': {'range': sys.argv[2], 'values': json.loads(sys.argv[3])}}
print(json.dumps(d, ensure_ascii=False))
" "$1" "$2" "$3")
  api_call PUT "/sheets/v2/spreadsheets/$1/values" -d "$body" | python3 -c "
import sys,json
d=json.load(sys.stdin)
code=d.get('code',0)
da=d.get('data',{})
if code==91403:
    print(json.dumps({'success':False,'error':'PERMISSION_DENIED','detail':'read_only','hint':'表格只有只读权限，需要编辑权限才能写入数据','code':code,'msg':d.get('msg','')}, ensure_ascii=False))
else:
    print(json.dumps({'success':code==0,'updated_range':da.get('updatedRange',''),'updated_cells':da.get('updatedCells',0),'updated_rows':da.get('updatedRows',0),'updated_columns':da.get('updatedColumns',0),'code':code,'msg':d.get('msg','')}, ensure_ascii=False))
"
}

action_write_multi() {
  local token="$1" data="$2"
  api_call POST "/sheets/v2/spreadsheets/$token/values_batch_update" -d "$data" | python3 -c "
import sys,json
d = json.load(sys.stdin)
print(json.dumps({'success':d.get('code',1)==0,'responses':d.get('data',{}).get('responses',[])}, ensure_ascii=False, indent=2))
"
}

action_append() {
  # SECURITY: Validate token, range, values via Python JSON encoder
  local body
  body=$(python3 -c "
import sys, json
d = {'valueRange': {'range': sys.argv[2], 'values': json.loads(sys.argv[3])}}
print(json.dumps(d, ensure_ascii=False))
" "$1" "$2" "$3")
  api_call POST "/sheets/v2/spreadsheets/$1/values_append" -d "$body" | python3 -c "
import sys,json
d=json.load(sys.stdin)
code=d.get('code',0)
da=d.get('data',{})
if code==91403:
    print(json.dumps({'success':False,'error':'PERMISSION_DENIED','detail':'read_only','hint':'表格只有只读权限，需要编辑权限才能追加数据','code':code,'msg':d.get('msg','')}, ensure_ascii=False))
else:
    print(json.dumps({'success':code==0,'updated_range':da.get('updatedRange',''),'updated_cells':da.get('updatedCells',0),'code':code,'msg':d.get('msg','')}, ensure_ascii=False))
"
}

action_prepend() {
  # SECURITY: Validate token, range, values via Python JSON encoder
  local body
  body=$(python3 -c "
import sys, json
d = {'valueRange': {'range': sys.argv[2], 'values': json.loads(sys.argv[3])}}
print(json.dumps(d, ensure_ascii=False))
" "$1" "$2" "$3")
  api_call POST "/sheets/v2/spreadsheets/$1/values_prepend" -d "$body" | python3 -c "
import sys,json
d=json.load(sys.stdin)
code=d.get('code',0)
da=d.get('data',{})
if code==91403:
    print(json.dumps({'success':False,'error':'PERMISSION_DENIED','detail':'read_only','hint':'表格只有只读权限，需要编辑权限才能前插数据','code':code,'msg':d.get('msg','')}, ensure_ascii=False))
else:
    print(json.dumps({'success':code==0,'updated_range':da.get('updatedRange',''),'updated_cells':da.get('updatedCells',0),'code':code,'msg':d.get('msg','')}, ensure_ascii=False))
"
}

# ========================= Images =========================

# SECURITY FIX: Pass image_path via argv (sys.argv[1]) instead of embedding in string.
# This eliminates command injection if path contains quotes/special chars.
action_insert_image() {
  local token="$1" range="$2" image_path="$3"
  local body_file
  body_file=$(mktemp /tmp/feishu_img_body_XXXXXX)
  # Pass path via argv, not string interpolation. json_file path via second argv.
  python3 -c "
import json,sys,os
path = sys.argv[1]
if not os.path.isfile(path):
    print(json.dumps({'error':'file not found'}))
    sys.exit(1)
name = os.path.basename(path)
with open(path,'rb') as f:
    data = list(f.read())
body = json.dumps({'range':sys.argv[3],'image':data,'name':name}, ensure_ascii=False)
with open(sys.argv[2],'w') as f:
    f.write(body)
" "$image_path" "$body_file" "$range"
  api_call POST "/sheets/v2/spreadsheets/$token/values_image" -d "@$body_file" | python3 -c "
import json,sys
d=json.load(sys.stdin)
if d.get('code',1)==0:
    print(json.dumps({'success':True,'range':sys.argv[1]}))
else:
    print(json.dumps({'error':d.get('msg','unknown'),'code':d.get('code',0)}))
" "$range"
  rm -f "$body_file"
}

action_float_image() {
  local token="$1" sheet_id="$2" image_path="$3" range="${4:-${sheet_id}!A1:A1}"
  local width="${5:-400}" height="${6:-300}"
  local filename
  filename=$(basename "$image_path")
  local filesize
  filesize=$(stat -c%s "$image_path" 2>/dev/null || stat -f%z "$image_path" 2>/dev/null)

  local upload_resp
  upload_resp=$(api_upload "/drive/v1/medias/upload_all" \
    -F "file_name=$filename" \
    -F "parent_type=sheet_image" \
    -F "parent_node=$token" \
    -F "size=$filesize" \
    -F "file=@$image_path")

  local file_token
  file_token=$(echo "$upload_resp" | python3 -c "import sys,json; print(json.load(sys.stdin).get('data',{}).get('file_token',''))" 2>/dev/null)

  if [[ -z "$file_token" ]]; then
    echo "$upload_resp" | python3 -c "
import sys,json
d=json.load(sys.stdin)
print(json.dumps({'error':'upload failed','detail':d.get('msg',str(d))}, ensure_ascii=False, indent=2))
"
    return 1
  fi

  local body
  body=$(python3 -c "
import sys, json
body = {
    'float_image_token': sys.argv[1],
    'range': sys.argv[2],
    'width': int(sys.argv[3]),
    'height': int(sys.argv[4])
}
print(json.dumps(body, ensure_ascii=False))
" "$file_token" "$range" "$width" "$height")
  api_call POST "/sheets/v3/spreadsheets/$token/sheets/$sheet_id/float_images" -d "$body" | python3 -c "
import sys,json
d=json.load(sys.stdin)
fi=d.get('data',{}).get('float_image',{})
if fi:
    print(json.dumps({'success':True,'float_image_id':fi.get('float_image_id',''),'range':fi.get('range',''),'width':fi.get('width',0),'height':fi.get('height',0)}, ensure_ascii=False, indent=2))
else:
    print(json.dumps({'error':d.get('msg','unknown'),'code':d.get('code',0)}, ensure_ascii=False, indent=2))
"
}

action_float_image_url() {
  local token="$1" sheet_id="$2" image_url="$3" range="${4:-${sheet_id}!A1:A1}"
  local width="${5:-400}" height="${6:-300}"

  # Security: Only allow http/https
  if [[ ! "$image_url" =~ ^https?:// ]]; then
    echo '{"error":"URL must start with http:// or https://"}'
    return 1
  fi

  local tmpfile
  tmpfile=$(mktemp /tmp/feishu_img_XXXXXX)
  local filename
  filename=$(basename "$image_url" | sed 's/\?.*//')
  [[ "$filename" != *.* ]] && filename="${filename}.png"

  curl -sL "$image_url" -o "$tmpfile"
  if [[ ! -s "$tmpfile" ]]; then
    rm -f "$tmpfile"
    echo '{"error":"Failed to download image from URL"}'
    return 1
  fi

  action_float_image "$token" "$sheet_id" "$tmpfile" "$range" "$width" "$height"
  rm -f "$tmpfile"
}

# ========================= Style =========================

action_style() {
  # SECURITY: Validate range and style_json via Python JSON encoder
  local body
  body=$(python3 -c "
import sys, json
d = {'appendStyle': {'range': sys.argv[2], 'style': json.loads(sys.argv[3])}}
print(json.dumps(d, ensure_ascii=False))
" "$1" "$2" "$3")
  api_call PUT "/sheets/v2/spreadsheets/$token/style" -d "$body" | python3 -c "
import sys,json
d=json.load(sys.stdin)
print(json.dumps({'success':d.get('code',1)==0,'msg':d.get('msg','')}, ensure_ascii=False, indent=2))
"
}

action_style_batch() {
  local token="$1" data="$2"
  api_call PUT "/sheets/v2/spreadsheets/$token/styles_batch_update" -d "$data" | python3 -c "
import sys,json
d=json.load(sys.stdin)
print(json.dumps({'success':d.get('code',1)==0,'msg':d.get('msg','')}, ensure_ascii=False, indent=2))
"
}

# ========================= Merge =========================

action_merge() {
  # SECURITY: Validate range via Python JSON encoder
  local body
  body=$(python3 -c "
import sys, json
d = {'range': sys.argv[2], 'mergeType': sys.argv[3]}
print(json.dumps(d, ensure_ascii=False))
" "$1" "$2" "${3:-MERGE_ALL}")
  api_call POST "/sheets/v2/spreadsheets/$1/merge_cells" -d "$body" | python3 -c "
import sys,json
d=json.load(sys.stdin)
print(json.dumps({'success':d.get('code',1)==0,'msg':d.get('msg','')}, ensure_ascii=False, indent=2))
"
}

action_unmerge() {
  # SECURITY: Validate range via Python JSON encoder
  local body
  body=$(python3 -c "
import sys, json
d = {'range': sys.argv[2]}
print(json.dumps(d, ensure_ascii=False))
" "$1" "$2")
  api_call POST "/sheets/v2/spreadsheets/$1/unmerge_cells" -d "$body" | python3 -c "
import sys,json
d=json.load(sys.stdin)
print(json.dumps({'success':d.get('code',1)==0,'msg':d.get('msg','')}, ensure_ascii=False, indent=2))
"
}

# ========================= Sheets =========================

action_add_sheet() {
  # SECURITY: Validate new sheet title via Python JSON encoder
  local body
  body=$(python3 -c "
import sys, json
d = {'requests': [{'addSheet': {'properties': {'title': sys.argv[2]}}}]}
print(json.dumps(d, ensure_ascii=False))
" "$1" "$2")
  api_call POST "/sheets/v2/spreadsheets/$1/sheets_batch_update" -d "$body" | python3 -c "
import sys,json
d=json.load(sys.stdin)
replies=d.get('data',{}).get('replies',[])
if replies:
    p=replies[0].get('addSheet',{}).get('properties',{})
    print(json.dumps({'success':True,'sheet_id':p.get('sheetId',''),'title':p.get('title','')}, ensure_ascii=False, indent=2))
else:
    print(json.dumps({'error':d.get('msg','unknown'),'code':d.get('code',0)}, ensure_ascii=False, indent=2))
"
}

action_delete_sheet() {
  # SECURITY: Validate sheetId via Python JSON encoder
  local body
  body=$(python3 -c "
import sys, json
d = {'requests': [{'deleteSheet': {'sheetId': sys.argv[2]}}]}
print(json.dumps(d, ensure_ascii=False))
" "$1" "$2")
  api_call POST "/sheets/v2/spreadsheets/$1/sheets_batch_update" -d "$body" | python3 -c "
import sys,json
d=json.load(sys.stdin)
print(json.dumps({'success':d.get('code',1)==0,'msg':d.get('msg','')}, ensure_ascii=False, indent=2))
"
}

action_copy_sheet() {
  # SECURITY: Validate sheetId and new_title via Python JSON encoder
  local body
  body=$(python3 -c "
import sys, json
d = {'requests': [{'copySheet': {'source': {'sheetId': sys.argv[2]}, 'destination': {'title': sys.argv[3]}}}]}
print(json.dumps(d, ensure_ascii=False))
" "$1" "$2" "$3")
  api_call POST "/sheets/v2/spreadsheets/$1/sheets_batch_update" -d "$body" | python3 -c "
import sys,json
d=json.load(sys.stdin)
replies=d.get('data',{}).get('replies',[])
if replies:
    p=replies[0].get('copySheet',{}).get('properties',{})
    print(json.dumps({'success':True,'sheet_id':p.get('sheetId',''),'title':p.get('title','')}, ensure_ascii=False, indent=2))
else:
    print(json.dumps({'error':d.get('msg','unknown'),'code':d.get('code',0)}, ensure_ascii=False, indent=2))
"
}

# ========================= Rows/Cols =========================

action_add_rows() {
  local body
  body=$(python3 -c "
import sys, json
body = {'dimension': {'sheetId': sys.argv[2], 'majorDimension': 'ROWS', 'length': int(sys.argv[3])}}
print(json.dumps(body, ensure_ascii=False))
" "$1" "$2" "$3")
  api_call POST "/sheets/v2/spreadsheets/$1/dimension_range" -d "$body" | python3 -c "
import sys,json
d=json.load(sys.stdin)
print(json.dumps({'success':d.get('code',1)==0,'msg':d.get('msg','')}, ensure_ascii=False, indent=2))
"
}

action_add_cols() {
  local body
  body=$(python3 -c "
import sys, json
body = {'dimension': {'sheetId': sys.argv[2], 'majorDimension': 'COLUMNS', 'length': int(sys.argv[3])}}
print(json.dumps(body, ensure_ascii=False))
" "$1" "$2" "$3")
  api_call POST "/sheets/v2/spreadsheets/$1/dimension_range" -d "$body" | python3 -c "
import sys,json
d=json.load(sys.stdin)
print(json.dumps({'success':d.get('code',1)==0,'msg':d.get('msg','')}, ensure_ascii=False, indent=2))
"
}

action_insert_rows() {
  local body
  body=$(python3 -c "
import sys, json
body = {'dimension': {'sheetId': sys.argv[2], 'majorDimension': 'ROWS', 'startIndex': int(sys.argv[3]), 'endIndex': int(sys.argv[4])}, 'inheritStyle': 'BEFORE'}
print(json.dumps(body, ensure_ascii=False))
" "$1" "$2" "$3" "$4")
  api_call POST "/sheets/v2/spreadsheets/$1/insert_dimension_range" -d "$body" | python3 -c "
import sys,json
d=json.load(sys.stdin)
print(json.dumps({'success':d.get('code',1)==0,'msg':d.get('msg','')}, ensure_ascii=False, indent=2))
"
}

action_delete_rows() {
  local body
  body=$(python3 -c "
import sys, json
body = {'dimension': {'sheetId': sys.argv[2], 'majorDimension': 'ROWS', 'startIndex': int(sys.argv[3]), 'endIndex': int(sys.argv[4])}}
print(json.dumps(body, ensure_ascii=False))
" "$1" "$2" "$3" "$4")
  api_call DELETE "/sheets/v2/spreadsheets/$1/dimension_range" -d "$body" | python3 -c "
import sys,json
d=json.load(sys.stdin)
print(json.dumps({'success':d.get('code',1)==0,'msg':d.get('msg','')}, ensure_ascii=False, indent=2))
"
}

action_delete_cols() {
  local body
  body=$(python3 -c "
import sys, json
body = {'dimension': {'sheetId': sys.argv[2], 'majorDimension': 'COLUMNS', 'startIndex': int(sys.argv[3]), 'endIndex': int(sys.argv[4])}}
print(json.dumps(body, ensure_ascii=False))
" "$1" "$2" "$3" "$4")
  api_call DELETE "/sheets/v2/spreadsheets/$1/dimension_range" -d "$body" | python3 -c "
import sys,json
d=json.load(sys.stdin)
print(json.dumps({'success':d.get('code',1)==0,'msg':d.get('msg','')}, ensure_ascii=False, indent=2))
"
}

# ========================= Find/Replace =========================

action_find() {
  # SECURITY: Validate keyword via Python JSON encoder
  local body
  body=$(python3 -c "
import sys, json
d = {'find': sys.argv[3], 'find_condition': {'range': sys.argv[2]}}
print(json.dumps(d, ensure_ascii=False))
" "$1" "$2" "$3")
  api_call POST "/sheets/v3/spreadsheets/$1/sheets/$2/find" -d "$body" | python3 -c "
import sys,json
d=json.load(sys.stdin)
fr=d.get('data',{}).get('find_result',{})
cells=fr.get('matched_cells',[]) if fr else []
print(json.dumps({'success':d.get('code',1)==0,'matched':len(cells),'rows_count':fr.get('rows_count',0),'cells':cells[:50]}, ensure_ascii=False, indent=2))
"
}

action_replace() {
  # SECURITY: Validate find/replacement via Python JSON encoder
  local body
  body=$(python3 -c "
import sys, json
d = {'find': sys.argv[3], 'replacement': sys.argv[4], 'find_condition': {'range': sys.argv[2]}}
print(json.dumps(d, ensure_ascii=False))
" "$1" "$2" "$3" "$4")
  api_call POST "/sheets/v3/spreadsheets/$1/sheets/$2/replace" -d "$body" | python3 -c "
import sys,json
d=json.load(sys.stdin)
rr=d.get('data',{}).get('replace_result',{})
print(json.dumps({'success':d.get('code',1)==0,'matched':rr.get('matched_cells_count',0),'replaced':rr.get('replaced_cells_count',0)}, ensure_ascii=False, indent=2))
"
}

# ========================= Main =========================

ACTION="${1:-help}"
shift || true

case "$ACTION" in
  create)       action_create "${1:-}" "${2:-}" ;;
  meta)         action_meta "$1" ;;
  read)         action_read "$1" "$2" ;;
  read_multi)   action_read_multi "$@" ;;
  write)        action_write "$1" "$2" "$3" ;;
  write_multi)  action_write_multi "$1" "$2" ;;
  append)       action_append "$1" "$2" "$3" ;;
  prepend)      action_prepend "$1" "$2" "$3" ;;
  insert_image)      action_insert_image "$1" "$2" "$3" ;;
  float_image)       action_float_image "$1" "$2" "$3" "${4:-}" "${5:-400}" "${6:-300}" ;;
  float_image_url)   action_float_image_url "$1" "$2" "$3" "${4:-}" "${5:-400}" "${6:-300}" ;;
  style)        action_style "$1" "$2" "$3" ;;
  style_batch)  action_style_batch "$1" "$2" ;;
  merge)        action_merge "$1" "$2" "${3:-MERGE_ALL}" ;;
  unmerge)      action_unmerge "$1" "$2" ;;
  add_sheet)    action_add_sheet "$1" "$2" ;;
  delete_sheet) action_delete_sheet "$1" "$2" ;;
  copy_sheet)   action_copy_sheet "$1" "$2" "$3" ;;
  add_rows)     action_add_rows "$1" "$2" "$3" ;;
  add_cols)     action_add_cols "$1" "$2" "$3" ;;
  insert_rows)  action_insert_rows "$1" "$2" "$3" "$4" ;;
  delete_rows)  action_delete_rows "$1" "$2" "$3" "$4" ;;
  delete_cols)  action_delete_cols "$1" "$2" "$3" "$4" ;;
  find)         action_find "$1" "$2" "$3" ;;
  replace)      action_replace "$1" "$2" "$3" "$4" ;;
  help|*)
    cat << 'HELPEOF'
Feishu Spreadsheet Tool v1.4.0

Usage: feishu-sheet.sh <action> [args...]

Credentials are auto-read from ~/workspace/agent/openclaw.json (channels.feishu).
Set OPENCLAW_CONFIG to override the config path.

Spreadsheet:
  create [title] [folder_token]                         Create spreadsheet
  meta <token>                                          Get metadata (sheets list)

Data:
  read <token> <range>                                  Read cell range
  read_multi <token> <range1> <range2> ...              Read multiple ranges
  write <token> <range> <values_json>                   Write data (overwrite)
  write_multi <token> <json_body>                       Write to multiple ranges
  append <token> <range> <values_json>                  Append rows
  prepend <token> <range> <values_json>                 Prepend rows

Images:
  insert_image <token> <range> <file_path>              Insert image into cell
  float_image <token> <sheet_id> <path> [range] [w] [h] Insert floating image (local)
  float_image_url <token> <sheet_id> <url> [range] [w] [h] Insert floating image (URL)

Style:
  style <token> <range> <style_json>                    Set cell style
  style_batch <token> <json_body>                       Batch set styles

Merge:
  merge <token> <range> [MERGE_ALL|MERGE_ROWS|MERGE_COLUMNS]
  unmerge <token> <range>

Sheets:
  add_sheet <token> <title>                             Add worksheet
  delete_sheet <token> <sheet_id>                       Delete worksheet
  copy_sheet <token> <sheet_id> <new_title>             Copy worksheet

Rows/Columns:
  add_rows <token> <sheet_id> <count>
  add_cols <token> <sheet_id> <count>
  insert_rows <token> <sheet_id> <start> <end>          Insert rows (0-indexed)
  delete_rows <token> <sheet_id> <start> <end>
  delete_cols <token> <sheet_id> <start> <end>

Find/Replace:
  find <token> <sheet_id> <keyword>
  replace <token> <sheet_id> <find> <replacement>

Style JSON example: {"bold":true,"foreColor":"#FF0000","backColor":"#FFFF00","fontSize":14}
HELPEOF
    ;;
esac
