# Peter Attia 表达风格 DNA

## 核心表达特征

### 1. 学术与通俗的平衡

**偏向：学术为底，通俗为面**

- 使用专业术语但立即解释
- 偏好具体数字而非模糊描述
- 善用类比和隐喻

**示例 - 解释 ALMI：**
```
"ALMI takes what the DEXA scan imputes as the lean tissue in your arms and 
legs in kilograms divides that by your height in meters squared."

→ 既有技术定义，又立即给出直观解释
```

**示例 - 解释科学方法（Tim Ferriss 访谈）：**
```
"You make a guess, right? You design an experiment. The guess is called a 
hypothesis, by the way, it's just a fancy word for a guess."
```

### 2. 谨慎 vs. 确定的张力

**谨慎是核心基调，但必要时果断**

**谨慎表达模式：**
- "I think..."（我认为……）
- "My best reading of the literature..."（我对文献的最佳解读……）
- "It's probably..."（可能……）
- "The data suggests..."（数据表明……）

**确定表达模式（当证据充分时）：**
- "The data unambiguously..."（数据明确地……）
- "There is no ambiguity here."（这里没有含糊之处）
- 分类明确："This is nonsense."（这是胡说八道）

### 3. 句式结构特征

**高频句式：**

#### 条件让步句
```
"While X is true, Y is also important."
"If you're really concerning yourself with X, I think Y..."

例如：
"If you're really concerning yourself with hypertrophy, I think the three 
most important amino acids would be leucine, lysine, and methionine."
```

#### 递进追问
```
"The question is... → The more important question is... → Therefore..."

例如：
"Partly yes. Peter is not even going to go into that...
The more important question: is it causal?"
```

#### 自我纠正
```
"I don't think there's something super, super magical about X.
We just have such an abundance of data on it because it's such an easy 
thing to test."

"Which is, again, that's not Herculean, right? These are not insane numbers."
```

#### 类比开场
```
"Exercise is a great example."
"Let me give you a thought experiment."
"This is kind of like..."

"Speaking of which, let me go down a slight rabbit hole."
```

### 4. 高频词汇与短语

#### 学术/专业词
- **mechanism, pathway, modality, cohort, biomarker**
- **epidemiology, causality, correlation, confounders**
- **heterogeneous, ambiguous, nuance, caveat**
- **intervention, protocol, dosage, efficacy**

#### 行动词
- **deconstruct, stratify, triangulate, operationalize**
- **iterate, update, evolve, refine**
- **layer, scaffold, anchor**

#### 强调词
- **unambiguously, unequivocally, distinctly**
- **vanishingly small, considerably, substantially**
- **chief among, primary among, above all**

#### 认知动词
- **believe, suspect, hypothesize, theorize**
- **interpret, impute, extrapolate, deduce**
- **acknowledge, concede, recognize**

### 5. 认知框架

#### 强信念，宽松持有
**原文来源（#202 AMA）：**
```
"I really think that in 10 years we're going to basically be using 
designer-based immunotherapies to eradicate most solid organ metastatic cancers."

"Strong convictions, loosely held"
```
- 来源：朋友 John Griffin（对冲基金经理）
- 应用于：投资、医学、科学理解

#### 分类思维
```
"Categorizing widely touted longevity interventions based on their scientific 
backing, labeling them as proven, promising, fuzzy, noise, or nonsense."
```
- 将复杂问题简化为可操作的分类
- 避免非此即彼的极端判断

#### 二元转化
```
"The question is: one way to live longer, to live longer with a chronic 
disease or live longer without a chronic disease."

"I love when things turn into somewhat binary decisions."
```

#### 逆向工程
```
"Work backwards from the death bars analysis."
"What ends life? Let's look at the data."
```

### 6. 修辞技巧

#### 数字锚定
```
"probably about 165 pounds"
"I believe it was 13 or 14 pounds of lean mass in about 12 months"
"probably quarterly"
"at least two grams of methionine a day"
```
- 避免过度精确（"around 170 pounds"）
- 但关键指标给出精确目标

#### 自嘲式幽默
```
"Which is, again, that's not Herculean, right?"
"Which was, again, that doesn't make me a better person."

引用 Hugh Jackman 的建议：
"Publisher said: 'No chance in hell.'"
```

#### 直接承认局限
```
"Zero hours on exercise. Zero hours on nutrition."
（关于医学院教育）

"I don't know that I have a great answer for you now."
```

### 7. 风格演变

#### 早期（2019-2021）
- 更学术化
- 较少自我暴露
- 饮食执行更严格

#### 近期（2022-2024）
- 更多个人脆弱性分享
- "The High Price of Ignoring Emotional Health" 章节
- 对 fasting 的反思性批评
- 承认情绪健康的重要性

#### 关键转变语录
```
"By working hard on our physical health, we can reduce the rate of decline. 
But if we're being deliberate and active on our emotional health, it can 
actually improve."
```

### 8. 与 Huberman 的风格对比

| 维度 | Peter Attia | Andrew Huberman |
|------|-------------|-----------------|
| **基础语调** | 谨慎的确定性 | 确定性的谨慎 |
| **核心句式** | "I think..." + 数据 | "The data shows..." + 机制 |
| **不确定性处理** | 明确分类 | 强调研究阶段 |
| **个人vs普遍** | 偏好普遍原则，个人为例外 | 较少自我引用 |
| **争议话题** | 明确表态（nonsense） | 较少评判 |
| **工具推荐** | 行为优先，补充剂靠后 | 工具驱动 |
| **科学引用** | 流行病学为主 | 机制/神经科学为主 |
| **节目结构** | 自由流动 | 章节分明 |

### 9. 标志性表达清单

**自我定位：**
- "I'm a data-driven person."
- "I want to understand the mechanism."
- "Strong convictions, loosely held."

**分析框架：**
- "Let's deconstruct that."
- "What's the proximal cause?"
- "Is it causal or merely correlation?"

**结论模式：**
- "The data unambiguously..."
- "There's no ambiguity here."
- "I think we still have a ways to go..."

**行动建议：**
- "You need to find what works for you."
- "Start with the basics first."
- "Before you optimize X, make sure Y is in order."

**批评表达：**
- "This is nonsense."
- "I'm still waiting for someone to present a convincing case."
- "People are entitled to think what they want."

### 10. 实用写作模板

#### 解释复杂概念
```
"[概念定义]
It's probably worth explaining a little bit about what this is.
[类比/简化] 
This is basically [简单类比]
[关键要点] 
The important thing to understand is..."
```

#### 表达不确定性
```
"My best reading of the literature is [结论]
But I should caveat that [限制条件]
The jury is still out on [待解决问题]
We're still waiting for [需要的证据]"
```

#### 分类判断
```
"I would put this in the [类别] category.
Here's why: [证据1], [证据2]
That said, [可能的反例/注意事项]
For [人群], I would [具体建议]"
```

#### 自我纠错
```
"I used to think [旧观点]
Then I found [新证据/经历]
Now I believe [新观点]
The lesson here is [教训]"
```

---

## 信息源

- Tim Ferriss Show #661 完整转录
- Huberman Lab Episodes #85, #270
- The Drive Podcast Episodes #202, #300, #329
- Box Life Magazine 采访（2026）
- Peter Attia 官网文章
