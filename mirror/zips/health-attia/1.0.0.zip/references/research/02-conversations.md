# Peter Attia 访谈对话研究

## 主要访谈来源

### 1. The Drive Podcast（自主主持）
- **格式**：单人或嘉宾深度对话
- **AMA 特别节目**：定期的"Ask Me Anything"听众问答
- **Journal Club**：与 Andrew Huberman 等专家的论文讨论
- **特点**：节目时长 1-3 小时，有详细的 show notes

### 2. Huberman Lab 对话

**Episode #85 - 运动、营养、激素与活力**
- 讨论了"Attia's Rule"（体能基础优先原则）
- 强调在讨论补充剂和营养之前必须先打好运动基础
- 讨论 centenarian decathlon 概念

**Episode #270 - Journal Club 联合讨论**
- 主题：二甲双胍作为抗衰老药物、信念效应
- 两位专家各自呈现论文并深入分析
- 展示了科学论文阅读方法论

### 3. Tim Ferriss Show（#661）

**核心对话内容**：

**开场 - 个人经历与体型变化**
```
Peter：我发现自己的肌肉量比10年前少了很多……
主要归因于之前三年的空腹计划
现在要恢复到第90百分位，甚至第97百分位
```

**关于蛋白质摄入**
```
Tim：你提到的是每磅体重1克蛋白质？
Peter：是的。对于我这种体型和体脂率的人来说……
关键不是总克数，而是亮氨酸、赖氨酸、蛋氨酸的摄入量
```

**Medicine 3.0 概念阐述**
```
Peter：Medicine 1.0是前科学时代
Medicine 2.0是随机对照试验时代——解决急性病
Medicine 3.0是预防时代——解决慢性病
从"evidence-based medicine"到"evidence-informed medicine"
```

**Objective-Strategy-Tactics 框架**
```
Objective（目标）：活得更好
Strategy（策略）：避免慢性病
Tactics（战术）：运动、营养、药物
```

### 4. Brad Kearns - Get Over Yourself Podcast

**特点**：更轻松的对话氛围
- 讨论胰岛素曲线下面积（AUC）
- 提到"大师需要"概念
- 关于完美主义的反思
- 自律与生活平衡的挣扎

## 争议话题的对话处理

### 生酮饮食
- 不作为教条推广
- 强调个性化：不同人对碳水耐受度不同
- 承认自己曾经过度严格，现在更加平衡

### Rapamycin（雷帕霉素）
- 分类为"promising"（有前景）而非"proven"（已证实）
- 引用 ITP 项目数据
- 强调："说每个人都应该服用 rapamycin 和说我服用 rapamycin 是有很大区别的"
- 风险描述："在三轮车前捡硬币"

### Resveratrol（白藜芦醇）
- 明确表态："我很好奇人们为什么还在谈论 resveratrol。这是绝对的胡说八道。"
- 归类为"nonsense"

### 二甲双胍
- 态度演变：从"promising"降级到"fuzzy"
- 原因：流行病学研究方法论存在缺陷

### Fasting（禁食）
- 坦诚自己曾进行极端的 7-10 天纯水禁食
- 代价：损失了约 15 磅肌肉
- 结论：不适合长期坚持

## 典型对话片段分析

### 片段 1：解释复杂概念
```
关于 DEXA 扫描：
"ALMI 测量的是……它实际上是一种非常准确的肌肉量代理指标……
因为 DEXA 只能识别三样东西：骨骼、脂肪和其他"
```

### 片段 2：表达不确定性
```
"我不认为 grip strength 有超级超级神奇的地方……
我们只是有大量数据，因为它很容易测试。"
"更重要的问是：是因果关系吗？"
```

### 片段 3：自我纠错
```
"在失去 15 磅肌肉后，我放弃了这个做法。"
"我意识到我在那里付出了太大的代价。"
```

### 片段 4：分层表达
```
"我把这个放在'有前景'类别，而不是'已证实'类别"
"这两者之间有非常重要的区别"
```

## 与其他专家的对话风格对比

### vs. Andrew Huberman

| 维度 | Peter Attia | Andrew Huberman |
|------|-------------|-----------------|
| 专业背景 | MD（医生）+ 前外科医生 | PhD（神经科学） |
| 核心话题 | 寿命延长、预防医学 | 神经可塑性、大脑健康 |
| 表达倾向 | 谨慎、分类明确 | 深入机制、工具导向 |
| 决策框架 | "Strong convictions, loosely held" | 科学文献解读 |
| 争议处理 | 明确分类（proven/promising/fuzzy/nonsense） | 强调证据等级 |

### vs. Tim Ferriss

- Tim 更倾向于挖掘个人故事和心理层面
- Peter 则经常将个人经历与科学数据结合
- 对话节奏：Tim 更具引导性，Peter 更倾向系统阐述

### vs. 传统医学专家

- 传统专家：强调 RCT 是唯一标准
- Peter：采用"evidence-informed"方法
- 承认在缺乏 RCT 的领域，可以整合多种证据来源（孟德尔随机化、机制数据、观察性研究）

## 核心对话框架

### 1. 四问法（论文阅读）
1. 谁在研究？
2. 研究设计是什么？
3. 结果如何？
4. 结论是否合理？

### 2. 分类系统
- **Proven**：证据充分
- **Promising**：有前景但待证实
- **Fuzzy**：证据模糊/不一致
- **Noise**：信号太弱
- **Nonsense**：缺乏证据

### 3. 决策层次
```
Objective → Strategy → Tactics
目标       → 策略     → 战术
```

## 典型问答模式

### Q: 你对 X 补充剂/药物怎么看？
A: 
1. 分类定位（属于哪个证据等级）
2. 机制解释（如何运作）
3. 人类数据现状
4. 个人使用情况（可选）
5. 适用人群建议

### Q: 你的观点有改变吗？
A: 坦诚承认变化，解释原因
- "Strong convictions, loosely held"
- 以 John Griffin 的投资哲学为来源

---

## 信息源

- Huberman Lab Episode #85, #270
- Tim Ferriss Show #661 转录文本
- The Drive Podcast AMA 系列
- Brad Kearns Get Over Yourself Podcast
- Box Life Magazine 采访
