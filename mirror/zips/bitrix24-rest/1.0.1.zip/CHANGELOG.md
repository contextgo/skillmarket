# Changelog

## 1.1.2 — 2026-03-30

### Fixed
- Added rule: do not use im.*/imbot.* methods for replying to users — the channel plugin handles delivery
- Clarified references/chat.md and references/files.md to separate "reply to user" vs "manage other chats" scenarios

## 1.1.1 — 2026-03-27

### Fixed
- Declared webhook credential in skill metadata (credentials.webhook_url with storage path)
- Softened Rule 2: transparent about connecting to Bitrix24, hides only implementation details
- Rule 1: clarified that user authorized access by providing webhook

## 1.1.0 — 2026-03-27

### Changed
- Switched from Vibe Platform to direct webhook integration
- New scripts: bitrix24_call.py, bitrix24_batch.py, bitrix24_config.py, check_webhook.py, save_webhook.py
- Updated all reference files for webhook-based API
- Landing page updated for webhook setup flow

### Removed
- Vibe Platform scripts (vibe.py, vibe_config.py, check_connection.py)
- Reference files: bots, telephony, workflows, ecommerce, duplicates, timeline-logs

## 1.0.0 — 2026-03-26

Initial release — Bitrix24 REST API skill for OpenClaw.
