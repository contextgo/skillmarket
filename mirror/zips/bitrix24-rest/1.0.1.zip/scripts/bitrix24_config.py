#!/usr/bin/env python3
"""Shared helpers for Bitrix24 skill scripts."""

from __future__ import annotations

import base64
import json
import os
import re
import stat
from pathlib import Path

WEBHOOK_RE = re.compile(r"^https://(?P<host>[^/]+)/rest/(?P<user_id>\d+)/(?P<secret>[^/]+)/?$")
DEFAULT_CONFIG_PATH = Path.home() / ".config" / "bitrix24-skill" / "config.json"
_KEY_FILENAME = ".key"
_KEY_LENGTH = 64


def normalize_url(value: str) -> str:
    return value.strip().strip('"').strip("'").rstrip("/") + "/"


def validate_url(value: str) -> str:
    normalized = normalize_url(value)
    if not WEBHOOK_RE.match(normalized):
        raise ValueError("Webhook format is invalid. Expected https://<host>/rest/<user_id>/<secret>/")
    return normalized


def mask_url(value: str) -> str:
    match = WEBHOOK_RE.match(value)
    if not match:
        return value
    secret = match.group("secret")
    if len(secret) <= 4:
        masked = "*" * len(secret)
    else:
        masked = f"{secret[:2]}***{secret[-2:]}"
    return f"https://{match.group('host')}/rest/{match.group('user_id')}/{masked}/"


def _key_path(config_path: Path) -> Path:
    """Return the path to the encryption key file next to the config."""
    return config_path.parent / _KEY_FILENAME


def _set_owner_only(path: Path) -> None:
    """Set file permissions to owner-only read/write (600)."""
    try:
        path.chmod(stat.S_IRUSR | stat.S_IWUSR)
    except OSError:
        pass


def _get_or_create_key(config_path: Path) -> bytes:
    """Load encryption key from disk, or generate and save a new one."""
    kp = _key_path(config_path)
    if kp.is_file():
        key = kp.read_bytes()
        if len(key) >= _KEY_LENGTH:
            return key[:_KEY_LENGTH]
    # Generate new key
    config_path.parent.mkdir(parents=True, exist_ok=True)
    key = os.urandom(_KEY_LENGTH)
    kp.write_bytes(key)
    _set_owner_only(kp)
    return key


def _xor_bytes(data: bytes, key: bytes) -> bytes:
    """XOR data with key (cycling key if shorter)."""
    klen = len(key)
    return bytes(b ^ key[i % klen] for i, b in enumerate(data))


def encrypt_value(plaintext: str, key: bytes) -> str:
    """Encrypt a string: XOR with key, return base64."""
    return base64.b64encode(_xor_bytes(plaintext.encode("utf-8"), key)).decode("ascii")


def decrypt_value(ciphertext: str, key: bytes) -> str:
    """Decrypt a base64-encoded XOR-encrypted string."""
    return _xor_bytes(base64.b64decode(ciphertext), key).decode("utf-8")


def load_config(path: Path) -> dict:
    if not path.is_file():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}
    if not isinstance(data, dict):
        return {}

    # Decrypt webhook if stored encrypted
    if "webhook_url_encrypted" in data and "webhook_url" not in data:
        try:
            key = _get_or_create_key(path)
            data["webhook_url"] = decrypt_value(data["webhook_url_encrypted"], key)
        except Exception:
            # Key mismatch (new machine/container) — treat as missing
            pass

    # Auto-migrate: plaintext → encrypted
    if "webhook_url" in data and "webhook_url_encrypted" not in data:
        url = data["webhook_url"]
        if isinstance(url, str) and url.strip():
            try:
                key = _get_or_create_key(path)
                data["webhook_url_encrypted"] = encrypt_value(url, key)
                _save_config_raw(path, {k: v for k, v in data.items() if k != "webhook_url"})
            except Exception:
                pass

    return data


def _save_config_raw(path: Path, data: dict) -> None:
    """Write config dict to disk with restricted permissions."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=True, indent=2) + "\n", encoding="utf-8")
    _set_owner_only(path)


def save_config(path: Path, data: dict) -> None:
    # Encrypt webhook before saving
    if "webhook_url" in data:
        url = data["webhook_url"]
        if isinstance(url, str) and url.strip():
            try:
                key = _get_or_create_key(path)
                data = dict(data)  # shallow copy
                data["webhook_url_encrypted"] = encrypt_value(url, key)
                del data["webhook_url"]
            except Exception:
                pass  # fallback: save plaintext
    _save_config_raw(path, data)


def persist_url_to_config(url: str, config_file: str | None = None) -> Path:
    config_path = Path(config_file).expanduser() if config_file else DEFAULT_CONFIG_PATH
    config = load_config(config_path)
    config["webhook_url"] = validate_url(url)
    save_config(config_path, config)
    return config_path


def load_url(
    *,
    cli_url: str | None,
    config_file: str | None = None,
) -> tuple[str | None, str]:
    if cli_url:
        return cli_url, "arg:url"

    config_path = Path(config_file).expanduser() if config_file else DEFAULT_CONFIG_PATH
    config = load_config(config_path)
    config_url = config.get("webhook_url")
    if isinstance(config_url, str) and config_url.strip():
        return config_url, f"config:{config_path}"

    return None, "missing"


def get_cached_user(config_file: str | None = None) -> dict | None:
    """Return cached user data (user_id, timezone) or None."""
    config_path = Path(config_file).expanduser() if config_file else DEFAULT_CONFIG_PATH
    config = load_config(config_path)
    user_id = config.get("user_id")
    if user_id is not None:
        return {"user_id": user_id, "timezone": config.get("timezone", "")}
    return None


def cache_user_data(user_id: int, timezone: str = "", config_file: str | None = None) -> None:
    """Save user_id and timezone to config for reuse."""
    config_path = Path(config_file).expanduser() if config_file else DEFAULT_CONFIG_PATH
    config = load_config(config_path)
    config["user_id"] = user_id
    if timezone:
        config["timezone"] = timezone
    save_config(config_path, config)
