package com.zhen.demo.ystpay;

import okhttp3.*;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

public class HttpClient {
    private static final MediaType MEDIA_TYPE_JSON =
            Objects.requireNonNull(MediaType.parse("application/json; charset=utf-8"));

    private static final MediaType MEDIA_TYPE_FORM =
            Objects.requireNonNull(MediaType.parse("application/x-www-form-urlencoded; charset=utf-8"));

    private static final OkHttpClient OK_CLIENT = new OkHttpClient.Builder()
            .connectionPool(new ConnectionPool(20, 5, TimeUnit.MINUTES))
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build();

    public String postWithJSON(String url, String reqBody) {
        Request.Builder reqBuilder = new Request.Builder()
                .url(url)
                .addHeader("Accept", "application/json");

        if (reqBody != null) {
            reqBuilder.post(RequestBody.create(MEDIA_TYPE_JSON, reqBody));
        } else {
            reqBuilder.post(RequestBody.create(MEDIA_TYPE_JSON, ""));
        }

        try (Response httpResponse = OK_CLIENT.newCall(reqBuilder.build()).execute()) {
            ResponseBody responseBody = httpResponse.body();
            if (responseBody == null) {
                return null;
            }
            String respBody = responseBody.string();
            if (httpResponse.isSuccessful()) {
                return respBody;
            }
            throw new RuntimeException("HTTP " + httpResponse.code() + " 响应异常: " + respBody);
        } catch (IOException e) {
            throw new RuntimeException("网络通讯失败：" + url, e);
        }
    }

    /**
     * @param url       请求地址
     * @param form      form 表单参数
     * @param localPath 下载文件保存目录
     * @return 成功返回 null；失败返回 "错误码|错误信息"
     */
    public String download(String url, Map<String, Object> form, String localPath) {
        StringBuilder sb = new StringBuilder();
        if (form != null) {
            for (Map.Entry<String, Object> entry : form.entrySet()) {
                if (sb.length() > 0) {
                    sb.append('&');
                }
                try {
                    sb.append(URLEncoder.encode(entry.getKey(), "UTF-8"))
                      .append('=')
                      .append(URLEncoder.encode(String.valueOf(entry.getValue()), "UTF-8"));
                } catch (UnsupportedEncodingException e) {
                    throw new RuntimeException("表单参数编码失败", e);
                }
            }
        }

        Request request = new Request.Builder()
                .url(url)
                .post(RequestBody.create(MEDIA_TYPE_FORM, sb.toString()))
                .build();

        try (Response response = OK_CLIENT.newCall(request).execute()) {
            if (response.body() == null) {
                return "9999|响应体为空";
            }

            String contentType = response.header("Content-Type", "");

            if ("text/html;charset=UTF-8".equals(contentType)) {
                String res = response.body().source().readUtf8();
                if (res.contains("|")) {
                    return res;
                } else {
                    return "99999|" + res;
                }
            }

            String fileName = extractFileName(response);
            if (fileName == null || fileName.isEmpty()) {
                fileName = "download_" + System.currentTimeMillis();
            }
            // 防路径穿越：只保留文件名本身，去掉任何目录分隔符
            fileName = new File(fileName).getName();

            File targetFile = new File(localPath, fileName);
            File tmpFile = new File(localPath, fileName + ".tmp");

            File parentFile = tmpFile.getParentFile();
            if (parentFile != null && !parentFile.exists()) {
                parentFile.mkdirs();
            }

            try (InputStream inputStream = response.body().byteStream();
                 FileOutputStream fileOutputStream = new FileOutputStream(tmpFile)) {
                byte[] buffer = new byte[8192];
                int ch;
                while ((ch = inputStream.read(buffer)) != -1) {
                    fileOutputStream.write(buffer, 0, ch);
                }
                // 强制刷入磁盘，确保文件完整落盘后再执行 rename
                fileOutputStream.getFD().sync();
            } catch (IOException e) {
                // 下载失败删除残留临时文件
                if (tmpFile.exists()) {
                    tmpFile.delete();
                }
                throw new RuntimeException("文件写入失败：" + tmpFile.getAbsolutePath(), e);
            }

            // 原子重命名：写完临时文件后再覆盖目标文件
            if (targetFile.exists()) {
                targetFile.delete();
            }
            if (!tmpFile.renameTo(targetFile)) {
                tmpFile.delete();
                throw new RuntimeException("文件重命名失败：" + targetFile.getAbsolutePath());
            }

            return null;

        } catch (IOException e) {
            throw new RuntimeException("文件下载失败：" + url, e);
        }
    }

    private static String extractFileName(Response response) {
        String disposition = response.header("Content-Disposition");
        if (disposition == null) {
            return null;
        }
        // 优先处理 RFC 5987: filename*=UTF-8''encoded
        for (String part : disposition.split(";")) {
            part = part.trim();
            if (part.toLowerCase().startsWith("filename*=")) {
                String value = part.substring("filename*=".length()).trim();
                int quoteIdx = value.indexOf("''");
                if (quoteIdx >= 0) {
                    try {
                        return java.net.URLDecoder.decode(value.substring(quoteIdx + 2), "UTF-8");
                    } catch (UnsupportedEncodingException ignored) {
                    }
                }
            }
        }
        // 降级处理普通 filename=
        for (String part : disposition.split(";")) {
            part = part.trim();
            if (part.toLowerCase().startsWith("filename=")) {
                return part.substring("filename=".length()).trim().replace("\"", "");
            }
        }
        return null;
    }
}
