package com.zhen.demo.ystpay;

public class YstpayApiProperties {
    public final String appId;
    public final String merPrivateKey;
    public final String allinpayPublicKey;
    public final String merSecretKey;
    public final String apiBaseUrl;

    public YstpayApiProperties(String appId, String merPrivateKey, String allinpayPublicKey, String merSecretKey, String apiBaseUrl) {
        this.appId = appId;
        this.merPrivateKey = merPrivateKey;
        this.allinpayPublicKey = allinpayPublicKey;
        this.merSecretKey = merSecretKey;
        this.apiBaseUrl = apiBaseUrl;
    }

    public String getAppId() {
        return appId;
    }

    public String getMerPrivateKey() {
        return merPrivateKey;
    }

    public String getAllinpayPublicKey() {
        return allinpayPublicKey;
    }

    public String getMerSecretKey() {
        return merSecretKey;
    }

    public String getApiBaseUrl() {
        return apiBaseUrl;
    }
}
