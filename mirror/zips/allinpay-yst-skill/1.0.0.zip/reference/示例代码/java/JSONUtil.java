package com.zhen.demo.ystpay;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.Map;

public class JSONUtil {
    private static final ObjectMapper objectMapper;

    static {
        objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    private JSONUtil() {
        throw new UnsupportedOperationException("工具类不能实例化");
    }

    public static String toJSONString(Object object) {
        if (null == object) {
            return null;
        }

        try {
            return objectMapper.writeValueAsString(object);

        } catch (JsonProcessingException e) {
            // 日志输出
        }

        return null;
    }

    public static <T> T toObj(String json, Class<T> clazz) {
        if (null == json || isBlank(json)) {
            return null;
        }

        try {
            return objectMapper.readValue(json, clazz);
        } catch (JsonProcessingException e) {
            // 日志输出
        }

        return null;
    }

    public static <T> T toObj(String json, TypeReference<T> typeReference) {
        if (null == json || isBlank(json) || typeReference == null) {
            return null;
        }

        try {
            return objectMapper.readValue(json, typeReference);
        } catch (JsonProcessingException e) {
            // 日志输出
        }

        return null;
    }

    /** 不产生临时 String 副本地检查字符串是否为空白 */
    private static boolean isBlank(String s) {
        int len = s.length();
        for (int i = 0; i < len; i++) {
            if (!Character.isWhitespace(s.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    public static Map<String, Object> objToMap(Object obj) {
        if (obj == null) {
            return null;
        }

        try {
            return objectMapper.convertValue(obj, new TypeReference<Map<String, Object>>() {});
        } catch (Exception e) {
            // 日志输出
        }

        return null;
    }
}
