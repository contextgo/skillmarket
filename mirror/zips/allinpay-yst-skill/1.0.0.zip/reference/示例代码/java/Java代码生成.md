# Java 代码生成



## 一、云商通2.0接口调用客户端

### Java 语言版本

使用以下步骤确认：

1. 用户明确指定版本

2. 用户工程使用版本

3. 以上步骤未确认版本，使用默认版本 Java 8

   

### 第三方依赖

```xml
<dependency>
    <groupId>com.fasterxml.jackson.core</groupId>
    <artifactId>jackson-databind</artifactId>
    <version>2.15.2</version>
</dependency>

<dependency>
    <groupId>org.bouncycastle</groupId>
    <artifactId>bcprov-jdk15on</artifactId>
    <version>1.67</version>
</dependency>

<dependency>
    <groupId>com.squareup.okhttp3</groupId>
    <artifactId>okhttp</artifactId>
    <version>3.14.9</version>
</dependency>
```



### 导入实例代码

将 `reference/示例代码/java` 文件下所有代码复制到工程中，在一个单独的包里。例： xxx.xxx.ystclient

| 代码文件             | 说明                    | 备注                               |
| -------------------- | ----------------------- | ---------------------------------- |
| YstpayApiClient      | 云商通2.0服务调用客户端 |                                    |
| NotifyMessageService | 异步通知处理服务        | 改代码不完整，提示用户补充业务处理 |
| ApiException         | 客户端内部异常          |                                    |
| ApiRequest           | 接口请求实体类          |                                    |
| ApiResponse          | 接口响应实体类          |                                    |
| HttpClient           | HTTP 请求客户端         |                                    |
| YstpayApiProperties  | 公共参数配置类          |                                    |
| SecurityUtil         | 内部工具                | 加签、验签、加密、解密             |
| JSONUtil             | 内部工具                |                                    |



### 公共参数配置

`application-xxx.yml` 中配置

```xml
allinpay:
	yunpro:
		api_base_url: ${API_BASE_URL}
		app_id: ${APP_ID}
		mer_privatekey: ${MER_PRIVATEKEY}
    allinpay_public_key: ${ALLINPAY_PUBLIC_KEY}
 		mer_sercret_key: ${MER_SECRET_KEY}
```

在应用运行后，将配置参数值注入 `YstpayApiProperties` 类，供后续使用



## 二、服务端应用对外业务接口

### 阅读接口文档

> **重要：接口地段类型中遇到 JSONObject类型，检查是否有详情链接有的话进一步阅读，并构建对应的实体类，没有构建Map类型**

阅读 `reference/接口索引` 中需要接入的云商通2.0接口对应文档



### 编写对外接口

1. 根据接口业务参数，针对请求、响应建立对应的实体类（DTO）
1. 建立 Controller、Service 层
1. Controller 附件交易请求参数值合法性校验（是否必填、数据类型、枚举值范围）
1. Service 层复杂具体的业务逻辑、数据库访问、云商通2.0接口客户端调用

