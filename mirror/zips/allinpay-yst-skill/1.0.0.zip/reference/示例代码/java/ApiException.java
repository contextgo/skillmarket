package com.zhen.demo.ystpay;

public class ApiException extends RuntimeException {
    private final String code;

    public ApiException(String code, String message) {
        super("[" + code + "] " + message);
        this.code = code;
    }

    public String getCode() {
        return code;
    }
}
