package com.zhen.demo.ystpay;

import com.fasterxml.jackson.core.type.TypeReference;

import java.util.Map;

public class NotifyMessageService {
    private final YstpayApiProperties properties;

    public NotifyMessageService(YstpayApiProperties properties) {
        this.properties = properties;
    }

    public String notify(String notifyBody) {
        try {
            Map<String, Object> notifyObj = JSONUtil.toObj(notifyBody, new TypeReference<Map<String, Object>>() {});
            if (notifyObj != null) {
                String signSource = SecurityUtil.buildSignString(notifyObj);
                String sign = notifyObj.get("sign").toString();
                String transCode = notifyObj.get("transCode").toString();

                if (SecurityUtil.verifySign(properties.allinpayPublicKey, signSource, sign)) {
                    processNotify(transCode, notifyObj);
                    return "success";
                }
            }

        } catch (Exception e) {
            // 日志输出
            return "fail";
        }

        return "fail";
    }

    private void processNotify(String transCode, Map<String, Object> data) {
        System.out.println("回调处理");
    }
}
