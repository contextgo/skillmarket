package com.zhen.demo.ystpay;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

public class SecurityUtil {
    private static final String BC_PROVIDER = "BC";
    private static final String ALGORITHM = "SM4";
    private static final String TRANSFORMATION = "SM4/ECB/PKCS5Padding";

    /** hex 转换查表，避免 String.format 开销 */
    private static final char[] HEX_CHARS = "0123456789ABCDEF".toCharArray();

    /**
     * 私钥缓存：base64 → PrivateKey。限制上限防止多租户场景 OOM，
     * 超过阈值时清空（实际部署通常只有 1 个私钥，清空代价极小）。
     */
    private static final int KEY_CACHE_MAX = 100;
    private static final ConcurrentHashMap<String, PrivateKey> PRIVATE_KEY_CACHE = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<String, PublicKey>  PUBLIC_KEY_CACHE  = new ConcurrentHashMap<>();

    /** SM4 Cipher 每线程复用，避免每次 Cipher.getInstance 查找 Provider 注册表 */
    private static final ThreadLocal<Cipher> SM4_CIPHER = ThreadLocal.withInitial(() -> {
        try {
            return Cipher.getInstance(TRANSFORMATION, BC_PROVIDER);
        } catch (Exception e) {
            throw new RuntimeException("SM4 Cipher 初始化失败", e);
        }
    });

    static {
        if (Security.getProvider(BC_PROVIDER) == null) {
            Security.addProvider(new BouncyCastleProvider());
        }
    }

    private SecurityUtil() {
        throw new UnsupportedOperationException("工具类不能实例化");
    }

    /**
     * SM2 签名
     *
     * @param privateKeyBase64 商户 SM2 私钥（Base64编码）
     * @param source    待签名字符串
     * @return Base64 编码的签名值
     */
    public static String sign(String privateKeyBase64, String source) {
        try {
            PrivateKey privateKey = getOrParsePrivateKey(privateKeyBase64);

            Signature signature = Signature.getInstance("SM3withSM2", BC_PROVIDER);
            signature.initSign(privateKey);
            signature.update(source.getBytes(StandardCharsets.UTF_8));
            byte[] signBytes = signature.sign();

            return Base64.getEncoder().encodeToString(signBytes);
        } catch (Exception e) {
            throw new RuntimeException("SM2签名失败: " + e.getMessage(), e);
        }
    }

    /**
     * SM2 验签
     *
     * @param publicKeyBase64 通联 SM2 公钥（Base64编码）
     * @param source         待验签字符串
     * @param sign       签名值（Base64编码）
     * @return 验签是否通过
     */
    public static boolean verifySign(String publicKeyBase64, String source, String sign) {
        try {
            PublicKey publicKey = getOrParsePublicKey(publicKeyBase64);

            Signature signature = Signature.getInstance("SM3withSM2", BC_PROVIDER);
            signature.initVerify(publicKey);
            signature.update(source.getBytes(StandardCharsets.UTF_8));

            return signature.verify(Base64.getDecoder().decode(sign));
        } catch (Exception e) {
            throw new RuntimeException("SM2验签失败: " + e.getMessage(), e);
        }
    }

    /**
     * SM4 加密
     *
     * @param secretKey 商户SM4密钥（MER_SECRET_KEY）
     * @param plaintext 明文
     * @return 16进制大写密文
     */
    public static String encrypt(String secretKey, String plaintext) {
        try {
            SecretKeySpec keySpec = generateKey(secretKey);
            Cipher cipher = SM4_CIPHER.get();
            cipher.init(Cipher.ENCRYPT_MODE, keySpec);
            byte[] encrypted = cipher.doFinal(plaintext.getBytes(StandardCharsets.UTF_8));
            return bytesToHexUpper(encrypted);
        } catch (Exception e) {
            throw new RuntimeException("SM4加密失败: " + e.getMessage(), e);
        }
    }

    /**
     * SM4 解密
     *
     * @param secretKey  商户SM4密钥
     * @param ciphertext 16进制密文
     * @return 明文
     */
    public static String decrypt(String secretKey, String ciphertext) {
        try {
            SecretKeySpec keySpec = generateKey(secretKey);
            Cipher cipher = SM4_CIPHER.get();
            cipher.init(Cipher.DECRYPT_MODE, keySpec);
            byte[] decrypted = cipher.doFinal(hexToBytes(ciphertext));
            return new String(decrypted, StandardCharsets.UTF_8);
        } catch (Exception e) {
            throw new RuntimeException("SM4解密失败: " + e.getMessage(), e);
        }
    }

    /**
     * 构造待签名字符串
     *
     * @param map  参数
     * @return 待签名字符串
     */
    public static String buildSignString(Map<String, Object> map) {
        if (map == null || map.isEmpty()) {
            return null;
        }

        TreeMap<String, Object> sortedMap = new TreeMap<>();

        for (Map.Entry<String, Object> entry : map.entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();

            if ("sign".equals(key) || "signType".equals(key)) {
                continue;
            }

            if (value == null) {
                continue;
            }

            if ("".equals(value)) {
                continue;
            }

            if (value instanceof byte[]) {
                continue;
            }

            sortedMap.put(key, value);
        }

        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, Object> entry : sortedMap.entrySet()) {
            sb.append(entry.getKey())
                    .append("=")
                    .append(entry.getValue())
                    .append("&");
        }

        if (sb.length() > 0) {
            sb.deleteCharAt(sb.length() - 1);
        }

        return sb.toString();
    }


    private static SecretKeySpec generateKey(String secretKey) {
        byte[] keyBytes = hexToBytes(secretKey);
        return new SecretKeySpec(keyBytes, ALGORITHM);
    }

    private static String bytesToHexUpper(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) {
            sb.append(HEX_CHARS[(b >> 4) & 0xF]);
            sb.append(HEX_CHARS[b & 0xF]);
        }
        return sb.toString();
    }

    private static byte[] hexToBytes(String hex) {
        int len = hex.length();
        byte[] bytes = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            bytes[i / 2] = (byte) ((Character.digit(hex.charAt(i), 16) << 4)
                    + Character.digit(hex.charAt(i + 1), 16));
        }
        return bytes;
    }

    private static PublicKey getOrParsePublicKey(String base64) {
        if (PUBLIC_KEY_CACHE.size() >= KEY_CACHE_MAX) {
            PUBLIC_KEY_CACHE.clear();
        }
        return PUBLIC_KEY_CACHE.computeIfAbsent(base64, k -> {
            try {
                byte[] keyBytes = Base64.getDecoder().decode(k);
                KeyFactory keyFactory = KeyFactory.getInstance("EC", BC_PROVIDER);
                return keyFactory.generatePublic(new X509EncodedKeySpec(keyBytes));
            } catch (Exception e) {
                throw new RuntimeException("SM2公钥解析失败: " + e.getMessage(), e);
            }
        });
    }

    private static PrivateKey getOrParsePrivateKey(String base64) {
        if (PRIVATE_KEY_CACHE.size() >= KEY_CACHE_MAX) {
            PRIVATE_KEY_CACHE.clear();
        }
        return PRIVATE_KEY_CACHE.computeIfAbsent(base64, k -> {
            try {
                byte[] keyBytes = Base64.getDecoder().decode(k);
                KeyFactory keyFactory = KeyFactory.getInstance("EC", BC_PROVIDER);
                return keyFactory.generatePrivate(new PKCS8EncodedKeySpec(keyBytes));
            } catch (Exception e) {
                throw new RuntimeException("SM2私钥解析失败: " + e.getMessage(), e);
            }
        });
    }
}
