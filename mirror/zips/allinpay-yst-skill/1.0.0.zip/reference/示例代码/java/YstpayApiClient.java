package com.zhen.demo.ystpay;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;

public class YstpayApiClient {
    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("yyyyMMdd");
    private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("HHmmss");

    private final YstpayApiProperties properties;
    public final HttpClient httpClient;
    /** baseUrl 去除尾部斜杠后的结果，构造时缓存，避免每次请求重复正则替换 */
    private final String cleanBaseUrl;

    public YstpayApiClient(YstpayApiProperties properties, HttpClient httpClient) {
        this.properties = properties;
        this.httpClient = httpClient;
        this.cleanBaseUrl = properties.apiBaseUrl != null
                ? properties.apiBaseUrl.replaceAll("/+$", "")
                : null;
    }

    public ApiResponse callApi(String apiPath, String transCode, Map<String, Object> bizData) {
        String url = getUrl(apiPath);
        ApiRequest apiRequest = generateRequest(transCode, bizData);
        String reqBody = JSONUtil.toJSONString(apiRequest);
        String resBody = httpClient.postWithJSON(url, reqBody);

        ApiResponse apiResponse = JSONUtil.toObj(resBody, ApiResponse.class);

        if (null == apiResponse || null == apiResponse.getCode()) {
            throw new RuntimeException("响应解析异常");
        }

        if (!verifySign(apiResponse)) {
            throw new RuntimeException("响应验签失败");
        }

        if (!apiResponse.getCode().equals("00000")) {
            throw new ApiException(apiResponse.getCode(), apiResponse.getMsg());
        }

        return apiResponse;
    }

    public void download(String apiPath, Map<String, Object> reqBody, String localPath) {
        if (reqBody == null) {
            throw new RuntimeException("请求参数为空");
        }

        String url = getUrl(apiPath);
        StringBuilder signSource = new StringBuilder();

        if (reqBody.get("spAppId") != null) {
            signSource.append(reqBody.get("spAppId"));
        }

        if (reqBody.get("appId") != null) {
            signSource.append(reqBody.get("appId"));
        }

        if (reqBody.get("fileType") != null) {
            signSource.append(reqBody.get("fileType"));
        }

        if (reqBody.get("fileDate") != null) {
            signSource.append(reqBody.get("fileDate"));
        }

        String sign = SecurityUtil.sign(properties.merPrivateKey, signSource.toString());
        reqBody.put("sign", sign);

        String res = httpClient.download(url, reqBody, localPath);
        if (res != null) {
            String[] resArray = res.split("\\|", 2);
            throw new ApiException(resArray[0], resArray.length > 1 ? resArray[1] : res);
        }
    }

    private ApiRequest generateRequest(String transCode, Map<String, Object> params) {
        ApiRequest apiRequest = new ApiRequest();
        apiRequest.setAppId(properties.getAppId());
        apiRequest.setSpAppId(null);
        apiRequest.setTransCode(transCode);
        apiRequest.setFormat("json");
        apiRequest.setCharset("UTF-8");
        apiRequest.setSignType("SM3withSM2");
        LocalDateTime now = LocalDateTime.now();
        apiRequest.setTransDate(DATE_FMT.format(now));
        apiRequest.setTransTime(TIME_FMT.format(now));
        apiRequest.setVersion("1.0");
        apiRequest.setBizData(JSONUtil.toJSONString(params));

        String sign = sign(apiRequest);
        apiRequest.setSign(sign);

        return apiRequest;
    }

    private String sign(ApiRequest apiRequest) {
        Map<String, Object> reqMap = JSONUtil.objToMap(apiRequest);
        String signSource =SecurityUtil.buildSignString(reqMap);
        return SecurityUtil.sign(properties.merPrivateKey, signSource);
    }

    private boolean verifySign(ApiResponse apiResponse) {
        if (null == apiResponse.getSign()) {
            return false;
        }
        Map<String, Object> resMap = JSONUtil.objToMap(apiResponse);
        String signSource = SecurityUtil.buildSignString(resMap);
        return SecurityUtil.verifySign(properties.allinpayPublicKey, signSource, apiResponse.getSign());
    }

    private String getUrl(String path) {
        if (null == cleanBaseUrl) {
            throw new RuntimeException("接口服务地址未配置，请检查配置参数");
        }
        if (null == path) {
            throw new RuntimeException("接口请求路径未指定");
        }
        String cleanPath = path.replaceAll("^/+", "");
        return cleanBaseUrl + "/" + cleanPath;
    }
}
