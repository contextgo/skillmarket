---
name: uk8s-list
description: 查询 UCloud UK8S Kubernetes 集群列表。Use when user asks to "查看 UK8S 集群", "list UK8S clusters", "查询集群状态", "看看有哪些集群".
argument-hint: "[cluster-id]"
allowed-tools: Bash(ucloud *), Bash(which *), Read, AskUserQuestion
---

# 查询 UK8S 集群列表

通过 `ucloud-cli` 查询 UK8S 集群列表，可按 ClusterId 过滤单个集群。

- 若 `$ARGUMENTS` 非空，作为 `ClusterId` 过滤条件，仅返回该集群

---

## Step 1：检查 ucloud-cli 环境

按 [`references/check-ucloud-cli.md`](references/check-ucloud-cli.md) 执行环境检查。

---

## Step 2：查询集群列表

读取 [`references/ListUK8sClusterV2.md`](references/ListUK8sClusterV2.md) 了解响应结构。

**若 `$ARGUMENTS` 非空（指定了 ClusterId）：**

```bash
ucloud api --Action ListUK8SClusterV2 --Region <Region> --ProjectId <ProjectId> --ClusterId <ClusterId>
```

**若 `$ARGUMENTS` 为空（列出所有集群）：**

```bash
ucloud api --Action ListUK8SClusterV2 --Region <Region> --ProjectId <ProjectId>
```

| RetCode | 处理 |
|---------|------|
| 0 | 进入 Step 3 |
| 非 0 | 输出完整 RetCode + Message，终止流程 |

---

## Step 3：展示结果

将 `ClusterSet` 格式化为表格展示，每行一个集群：

```
共找到 N 个集群（Region: cn-sh2）

集群 ID              名称          版本     状态      Master  Node  创建时间
uk8s-xxxxxxxxxx     my-cluster   1.32.8   RUNNING   3       2     2025-01-01
uk8s-yyyyyyyyyy     test-k8s     1.30.10  STARTING  3       0     2025-03-15
```

**状态说明：**

| 状态值 | 含义 |
|--------|------|
| `RUNNING` | 正常运行 |
| `INITIALIZING` / `STARTING` | 初始化/启动中 |
| `CREATEFAILED` / `DELETEFAILED` | 创建/删除失败 |
| `DELETING` | 删除中 |
| `UPGRADING` | 升级集群中 |
| `ABNORMAL` / `ERROR` | 异常 |

若 `ClusterSet` 为空，提示：`当前 Region 下没有 UK8S 集群。`

若查询的是单个集群，额外展示详细信息：

```
集群详情：
  集群 ID:      uk8s-xxxxxxxxxx
  名称:         my-cluster
  K8s 版本:     1.32.8
  状态:         RUNNING
  VPC/Subnet:   uvnet-xxx / subnet-xxx
  ApiServer:    https://xxx.xxx.xxx.xxx:6443
  外网 API:     https://xxx.xxx.xxx.xxx:6443
  Pod CIDR:     172.16.0.0/16
  Service CIDR: 192.168.0.0/16
  Master 数:    3
  Node 数:      2
  创建时间:     2025-01-01 12:00:00
```

---

## 错误处理原则

- 不允许吞错误，必须输出 RetCode + Message
- RetCode 非 0 时给出可能原因（权限、Region 填写错误等）
