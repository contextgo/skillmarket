# 获取UK8S集群信息-ListUK8SClusterV2

获取UK8S集群列表信息

# Request Parameters
|Parameter name|Type|Description|Required|
|---|---|---|---|
|Region|string|地域。 参见 [地域和可用区列表](https://docs.ucloud.cn/api/summary/regionlist)|**Yes**|
|ProjectId|string|项目ID。不填写为默认项目，子帐号必须填写。 请参考[GetProjectList接口](https://docs.ucloud.cn/api/summary/get_project_list)|No|
|Offset|int|列表起始位置偏移量，默认为0。|No|
|Limit|int|返回数据长度，默认为20。|No|
|ClusterId|string|UK8S集群ID|No|

# Response Elements
|Parameter name|Type|Description|Required|
|---|---|---|---|
|RetCode|int|返回码|**Yes**|
|Action|string|操作名称|**Yes**|
|ClusterCount|int|满足条件的集群数量|**Yes**|
|ClusterSet|array|集群信息，具体参考ClusterSet|No|

## ClusterSet
|Parameter name|Type|Description|Required|
|---|---|---|---|
|ClusterName|string|资源名字|**Yes**|
|ClusterId|string|集群ID|**Yes**|
|VPCId|string|所属VPC|**Yes**|
|SubnetId|string|所属子网|**Yes**|
|PodCIDR|string|Pod网段|**Yes**|
|ServiceCIDR|string|服务网段|**Yes**|
|CNIMode|string|CNI网络模式|**Yes**|
|MasterCount|int|Master 节点数量|**Yes**|
|ApiServer|string|集群apiserver地址|**Yes**|
|K8sVersion|string|集群版本|**Yes**|
|DeleteProtection|int|删除保护开关。0表示不开启，1表示开启。默认不开启|**Yes**|
|ClusterLogInfo|string|创建集群时判断如果为NORESOURCE则为没资源，否则为空|No|
|CreateTime|int|创建时间|No|
|NodeCount|int|Node节点数量|No|
|ExternalApiServer|string|集群外部apiserver地址	|No|
|Status|string|集群状态，枚举值：初始化："INITIALIZING"；启动中："STARTING"；创建失败："CREATEFAILED"；正常运行："RUNNING"；添加节点："ADDNODE"；删除节点："DELNODE"；删除中："DELETING"；删除失败："DELETEFAILED"；错误："ERROR"；升级插件："UPDATE_PLUGIN"；更新插件信息："UPDATE_PLUGIN_INFO"；异常："ABNORMAL"；升级集群中："UPGRADING"；容器运行时切换："CONVERTING"|No|

# Request Example
```
https://api.ucloud.cn/?Action=ListUK8SClusterV2
&Region=cn-zj
&Zone=cn-zj-01
&ProjectId=jrVZnyEh
&Offset=5
&Limit=4
&ClusterId=DiFSEdqw
```

# Response Example
```
{
    "Action": "ListUK8SClusterV2Response", 
    "ClusterSet": [
        {
            "Status": "cbTawLFM", 
            "ApiServer": "lCABdaWT", 
            "VPCId": "tkoNZSem", 
            "ServiceCIDR": "yURWbTOO", 
            "K8sVersion": "KuiydQsJ", 
            "ClusterName": "qsKUTmxo", 
            "ClusterId": "SciLLuOV", 
            "ExternalApiServer": "vZfLtCWo", 
            "PodCIDR": "NtUEVnsd", 
            "NodeCount": 1, 
            "SubnetId": "qizOyyNS", 
            "MasterCount": 2, 
            "CreateTime": 2
        }
    ], 
    "RetCode": 0, 
    "ClusterCount": 7
}
```