---
name: skill-creator-guide
description: |
  Guides Agents on how to create robust, error-free SKILLs. Invoke when user asks to create a skill or when Agent needs to write/edit a SKILL.md file.
---

# Skill Creator Guide - SKILL 编写指南

本 skill 为 Agent 创建新 skill 时提供编写规范和最佳实践，确保产出的 SKILL.md 清晰、无歧义、不易被 LLM 误解或误执行。

## 核心原则

SKILL.md 是 LLM 执行任务时的**唯一指令来源**。LLM 没有上下文补充、没有隐含常识、没有"应该知道"的假设。因此 SKILL.md 必须做到：

1. **显式优于隐式**：每一条规则都必须明确写出，不能依赖 LLM 的"常识"
2. **无歧义**：LLM 对模糊指令的解读可能与人类预期不同，必须消除歧义
3. **防错设计**：预判 LLM 可能犯的错误，在指令中设置防护栏
4. **可验证**：提供验证手段，让 LLM 能自行检查执行结果是否正确
5. **脚本化优于内联代码**：将复杂逻辑封装为脚本文件，LLM 只需调用脚本，不要让 LLM 在终端中输入多行代码

---

## 编写规范

### 一、路径规范：必须使用绝对路径变量

**问题来源**：docx_typo_checker.skill 使用相对路径（如 `docx_typo_check_<timestamp>/unpacked`），LLM 执行不同命令时当前工作目录（cwd）可能不同，导致在错误位置创建了同名文件夹。

**规范**：

1. 在工作流第一步定义绝对路径变量，后续所有步骤统一使用该变量
2. 明确指定工作文件夹的创建位置（通常是输入文件所在目录）
3. 禁止使用相对路径

**正确示例**：

```markdown
### 第一步：定义路径变量

- `<input_dir>` = 输入文件所在的目录的绝对路径（如 `D:\Projects\my_project`）
- `<work_dir>` = `<input_dir>\work_<timestamp>`（如 `D:\Projects\my_project\work_20260424_153025`）

> ⛔ 禁止在 skill 目录内创建工作文件夹。所有路径必须使用 `<work_dir>` 绝对路径前缀，禁止使用相对路径。

创建工作文件夹：

\```bash
mkdir "<work_dir>"
\```
```

**错误示例**：

```markdown
创建工作文件夹 `work_<timestamp>/`，后续文件放在此文件夹下。
```
↑ 未指定绝对路径，LLM 可能在任何 cwd 下创建文件夹。

### 二、禁止事项：前置且醒目

**问题来源**：docx_typo_checker.skill 的禁止事项分散在正文和规则列表中，LLM 未注意到或未遵守。

**规范**：

1. 在 SKILL.md 开头（frontmatter 之后、工作流之前）设置"⛔ 关键禁止事项"专区
2. 每条禁止事项必须说明**后果**（为什么禁止）和**替代方案**（应该怎么做）
3. 在工作流中涉及禁止事项的步骤处，再次用 ⛔ 标记提醒

**正确示例**：

```markdown
## ⛔ 关键禁止事项（开始前必读）

1. **⛔ 禁止自行编写修正脚本**：必须使用本 skill 提供的 `typo_fixer.py`。自行编写脚本调用 `get_node` + `replace_node` 会导致整个 `w:r` 节点被替换，丢失节点中除错别字外的所有文本。
2. **⛔ 禁止跳过验证步骤**：第五步的内容完整性验证是强制性的，未通过验证的文档禁止输出给用户。
```

**错误示例**：

```markdown
## 重要规则

9. 必须使用 typo_fixer.py 进行修正
10. 验证步骤不得跳过
```
↑ 禁止事项混在普通规则中，不够醒目；未说明后果和替代方案。

### 三、示例代码：只提供正确用法，禁止提供有缺陷的"参考代码"

**问题来源**：docx_typo_checker.skill 旧版 4.2 节提供了 `get_node` + `replace_node` 的示例代码，LLM 直接复制该代码导致内容丢失。

**规范**：

1. **只提供推荐用法的示例代码**，不要提供"替代方案"或"参考实现"
2. 如果某个 API 有已知缺陷，**不要**在示例中展示该 API 的用法（即使标注了"不推荐"），因为 LLM 可能忽略标注
3. 如果需要解释某个 API 的缺陷，只在禁止事项中用文字说明，**不附代码**
4. 提供的示例代码必须是可直接复制执行的完整命令

**正确示例**：

```markdown
#### 4.2 使用 typo_fixer.py 修正错别字（唯一正确方式）

\```bash
python "<skill_root>\scripts\typo_fixer.py" "输入文件.docx" "输出.docx" --typos-file "<work_dir>\typos_<timestamp>.json"
\```
```

**错误示例**：

```markdown
#### 4.2 修正错别字

推荐使用 typo_fixer.py：

\```bash
python "<skill_root>\scripts\typo_fixer.py" ...
\```

或者也可以手动调用 Document 类：

\```python
doc = Document(unpacked_dir, track_revisions=True)
node = doc["word/document.xml"].get_node(tag="w:r", contains=wrong)
doc["word/document.xml"].replace_node(node, replacement)
\```
```
↑ 即使标注"不推荐"，LLM 仍可能复制此代码。有缺陷的代码不应出现在 SKILL.md 中。

### 四、脚本化工作流：禁止提供需要 LLM 在终端中输入的多行代码

**问题来源**：docx_typo_checker.skill 旧版在第二步（文本提取）和第五步（验证）中提供了多行 Python 代码块，要求 LLM "在终端中直接执行"。实际测试中出现了以下问题：

1. **`python -c` 无法执行多行代码**：PowerShell 的 `python -c` 不支持 for 循环、if 语句、函数定义等需要缩进的多行 Python 代码。分号分隔的 for/if 语句在单行中会导致 `SyntaxError`
2. **LLM 被迫创建中间脚本文件**：由于 `python -c` 不可行，LLM 只能将代码保存为 `.py` 文件，这又违反了"禁止保存中间脚本"的规则——两条规则互相矛盾
3. **Windows 路径转义错误**：LLM 在编写脚本时，Python 字符串中的 `\u` 被解释为 Unicode 转义序列，`\T` 触发 SyntaxWarning，导致脚本无法运行

**规范**：

1. **将复杂逻辑封装为脚本文件**：skill 中所有需要 LLM 执行的多行代码逻辑，都必须预先编写为 `.py` 脚本文件，放在 skill 的 `scripts/` 目录下，作为 skill 的一部分提供
2. **SKILL.md 中只提供脚本调用命令**：工作流步骤中只写 `python "<skill_root>\scripts\脚本名.py" <参数>` 这样的单行命令，不提供需要 LLM 输入的多行代码块
3. **脚本必须自包含**：脚本内部必须自行处理 `sys.path`、import、路径拼接等，LLM 不需要设置 PYTHONPATH 或其他环境变量
4. **脚本内部使用 pathlib 处理路径**：禁止在脚本中使用字符串拼接路径（如 `f"{work_dir}\unpacked"`），必须使用 `pathlib.Path` 或 `os.path.join`，避免 Windows 路径转义问题
5. **充分利用现有脚本的隐藏功能**：编写 SKILL.md 前必须仔细检查 skill 中已有脚本的所有功能（如 `--extract-only`、`--verify` 等参数），避免在 SKILL.md 中重复提供已有脚本已实现的功能

**正确示例**：

```markdown
### 第二步：提取文档文本

使用本 skill 提供的 `typo_fixer.py` 脚本提取文本：

\```bash
python "<skill_root>\scripts\typo_fixer.py" "<input_docx>" --extract-only > "<work_dir>\extracted_text.txt"
\```

> ⚠️ 禁止使用 `python -c` 执行多行 Python 代码来提取文本。`typo_fixer.py` 已内置 `--extract-only` 参数，直接调用即可。
```

**错误示例**：

```markdown
### 第二步：提取文档文本

在终端中直接执行以下 python-docx 代码（不要保存为 .py 文件）：

\```python
from docx import Document

doc = Document("输入文件.docx")
paragraphs = []

for para in doc.paragraphs:
    text = para.text.strip()
    if text:
        paragraphs.append(text)

with open("<work_dir>\\extracted_text.txt", "w", encoding="utf-8") as f:
    f.write("\n".join(paragraphs))
print("文本提取完成")
\```
```
↑ 多行 Python 代码无法通过 `python -c` 在 PowerShell 中执行，LLM 被迫创建 `.py` 文件，违反其他规则。应封装为脚本文件。

### 五、跨平台命令兼容性：禁止使用 bash 专属语法

**问题来源**：docx_typo_checker.skill 旧版使用 `PYTHONPATH=<skill_root> python -m scripts.typo_fixer` 设置环境变量，这是 bash 语法。在 Windows PowerShell 中，该语法被解释为命令名而非环境变量赋值，导致 `CommandNotFoundException`。

**规范**：

1. **禁止使用 bash 专属的环境变量设置语法**：`PYTHONPATH=xxx python -m ...`、`VAR=xxx command` 等语法在 PowerShell 中无效
2. **使用直接脚本调用代替 `python -m`**：`python "<skill_root>\scripts\script.py"` 比 `python -m package.module` 更可靠，因为脚本可以自行处理 `sys.path`
3. **脚本必须自行处理 import 路径**：脚本内部通过 `Path(__file__).parent` 等方式定位 skill 根目录并添加到 `sys.path`，LLM 不需要手动设置 PYTHONPATH
4. **如果必须设置环境变量，提供 PowerShell 语法**：`$env:PYTHONPATH="xxx"; python -m ...`，但同时应提供 bash 语法作为替代，或直接避免使用环境变量

**正确示例**：

```markdown
\```bash
python "<skill_root>\scripts\typo_fixer.py" "<input_docx>" "<output_docx>" --typos-file "<work_dir>\typos_<timestamp>.json"
\```
```
↑ 直接调用脚本，脚本内部已处理 `sys.path`，无需设置 PYTHONPATH。

**错误示例**：

```markdown
\```bash
PYTHONPATH=<skill_root> python -m scripts.typo_fixer "输入文件.docx" "输出.docx" --typos-file "<work_dir>\typos.json"
\```
```
↑ bash 语法，PowerShell 中报 `CommandNotFoundException`。

### 六、中间产物管理：明确存放位置和命名规则

**问题来源**：
- LLM 将中间脚本（`extract_text.py`、`fix_typos.py`）保存为项目根目录下的独立文件
- LLM 使用无时间戳的文件名（如 `typos.json`）

**规范**：

1. 明确指定所有中间产物的存放目录（使用绝对路径变量 `<work_dir>`）
2. 明确指定文件命名规则（含时间戳）
3. 区分"skill 自带的脚本文件"和"运行时产生的中间文件"：skill 的 `scripts/` 目录下的 `.py` 文件是 skill 的一部分，不属于"中间脚本"；运行时由 LLM 创建的 `.py` 文件才是需要禁止的中间脚本
4. 明确最终输出文件的存放位置（与工作文件夹的关系）

**正确示例**：

```markdown
> ⚠️ 文件命名规则（必须严格遵守）：
> - 错别字 JSON 文件必须放在 `<work_dir>` 下，命名为 `typos_<timestamp>.json`
> - 禁止使用 `typos.json` 等无时间戳的文件名
> - 禁止在项目目录中创建 `extract_text.py`、`verify.py` 等运行时脚本文件（应使用 skill 提供的脚本）
> - 最终修正版 docx 文件放在输入文件同目录下，不放入工作文件夹
```

**错误示例**：

```markdown
> 禁止将代码保存为独立脚本文件。
```
↑ 未区分"skill 自带脚本"和"运行时中间脚本"，与"在终端中执行多行代码"的要求矛盾。

### 七、验证步骤：强制且脚本化

**问题来源**：
1. LLM 跳过验证步骤，直接输出有内容缺失的文档
2. 验证代码是多行 Python 代码，LLM 在 PowerShell 中无法通过 `python -c` 执行，被迫创建 `.py` 文件

**规范**：

1. 验证步骤标记为"强制性"，使用 ⛔ 符号
2. **将验证逻辑封装为脚本文件**，放在 skill 的 `scripts/` 目录下，LLM 只需一行命令调用
3. 明确验证失败的后果（禁止输出、必须修正）
4. 验证脚本内部使用 `pathlib.Path` 或 `os.path.join` 处理路径，避免转义问题
5. 验证脚本应自动处理前置步骤（如解压文件），LLM 不需要手动执行解压命令

**正确示例**：

```markdown
### 第五步：内容完整性验证（强制性）

> ⛔ 本步骤为强制性步骤，不得跳过。未通过验证的文档禁止输出给用户。

\```bash
python "<skill_root>\scripts\verify.py" "<input_docx>" "<output_docx>" "<work_dir>"
\```

> ⛔ 如果任何验证项未通过（输出 ❌），必须排查原因并修正后再继续，不得向用户输出有内容缺失的文档。
```

**错误示例**：

```markdown
### 第五步：内容完整性验证（强制性）

> ⛔ 本步骤为强制性步骤，不得跳过。

对比原始文档与修正文档的段落数量：

\```python
import sys
sys.path.insert(0, '<skill_root>')
from defusedxml import minidom

def count_paragraphs(xml_path):
    with open(xml_path, 'r', encoding='utf-8') as f:
        dom = minidom.parse(f)
    return len(dom.getElementsByTagName('w:p'))

orig_count = count_paragraphs('<work_dir>\\unpacked_original\\word\\document.xml')
corr_count = count_paragraphs('<work_dir>\\unpacked\\word\\document.xml')
\```
```
↑ 多行 Python 代码无法在 PowerShell 中通过 `python -c` 执行；路径中的 `\\` 转义容易出错；LLM 还需手动执行解压等前置步骤。

### 八、动态值：必须要求实际执行命令获取

**问题来源**：LLM 自行编造时间戳（如 `20260424_120000`），而非执行命令获取真实值。

**规范**：

1. 所有动态值（时间戳、随机数、文件哈希等）必须要求 LLM 执行命令获取
2. 提供获取命令，并明确标注"必须实际执行"
3. 禁止使用占位值

**正确示例**：

```markdown
在开始任何操作之前，必须先执行以下命令获取当前本地时间戳：

\```bash
python -c "from datetime import datetime; print(datetime.now().astimezone().strftime('%Y%m%d_%H%M%S'))"
\```

> ⚠️ 必须实际执行此命令，不得自行编造或猜测时间戳。禁止使用 `20260424_120000` 等占位时间戳。
```

### 九、工作流步骤：编号且有序，每步有明确输入输出

**规范**：

1. 使用编号步骤（第一步、第二步……），不要用无编号的段落
2. 每个步骤明确说明输入（需要什么）和输出（产出什么）
3. 步骤之间的依赖关系要清晰
4. 涉及文件操作的步骤，必须使用绝对路径变量
5. **每个步骤的命令必须是单行可执行的**，不要提供需要 LLM 在终端中输入的多行代码块

### 十、路径变量集中定义

**问题来源**：docx_typo_checker.skill 旧版的路径变量散落在各步骤中，LLM 容易混淆或遗漏。

**规范**：

1. 在工作流之前设置"路径变量说明"专区，用表格列出所有路径变量
2. 每个变量明确含义和示例值
3. 特别说明 Windows 路径中反斜杠的处理方式

**正确示例**：

```markdown
## 路径变量说明

| 变量 | 含义 | 示例 |
|:---|:---|:---|
| `<skill_root>` | 本 skill 的根目录 | `D:\path\to\.trae\skills\my_skill` |
| `<input_docx>` | 输入文件的绝对路径 | `D:\docs\测试文件.docx` |
| `<input_dir>` | 输入文件所在目录的绝对路径 | `D:\docs` |
| `<timestamp>` | 第一步获取的本地时间戳 | `20260424_153025` |
| `<work_dir>` | 工作文件夹的绝对路径 | `D:\docs\work_20260424_153025` |

> ⚠️ 所有路径必须使用绝对路径。Windows 路径中的反斜杠 `\` 在命令行参数中直接使用即可，不要手动添加额外转义。
```

---

## SKILL.md 模板

```markdown
---
name: "<skill-name>"
description: "<功能描述>。Invoke when <触发条件>。"
---

# <Skill 标题>

<一句话功能概述>

## 功能特性

| 功能 | 说明 |
|:---|:---|
| **<功能1>** | <说明> |
| **<功能2>** | <说明> |

## ⛔ 关键禁止事项（开始前必读）

> **以下行为会导致 <具体后果>，严格禁止：**

1. **⛔ 禁止 <行为>**：<原因/后果>。必须 <替代方案>。
2. **⛔ 禁止 <行为>**：<原因/后果>。<替代方案>。
3. **⛔ 禁止在终端中直接执行多行代码**：本 skill 已提供脚本文件（见 scripts/ 目录），必须直接调用脚本，禁止使用 `python -c` 执行多行 Python 代码。

## 路径变量说明

| 变量 | 含义 | 示例 |
|:---|:---|:---|
| `<skill_root>` | 本 skill 的根目录 | `D:\path\to\.trae\skills\<skill-name>` |
| `<input_file>` | 输入文件的绝对路径 | `D:\docs\file.ext` |
| `<input_dir>` | 输入文件所在目录的绝对路径 | `D:\docs` |
| `<timestamp>` | 第一步获取的本地时间戳 | `20260424_153025` |
| `<work_dir>` | 工作文件夹的绝对路径 | `D:\docs\<skill-name>_<timestamp>` |

> ⚠️ 所有路径必须使用绝对路径。Windows 路径中的反斜杠 `\` 在命令行参数中直接使用即可，不要手动添加额外转义。

## 工作流程

### 第一步：获取时间戳并创建工作文件夹

获取时间戳：

\```bash
python -c "from datetime import datetime; print(datetime.now().astimezone().strftime('%Y%m%d_%H%M%S'))"
\```

> ⚠️ 必须实际执行此命令，不得自行编造时间戳。

创建工作文件夹：

\```bash
mkdir "<work_dir>"
\```

> ⛔ 禁止在 skill 目录内创建工作文件夹。所有路径必须使用 `<work_dir>` 绝对路径前缀。

### 第二步：<步骤名称>

<说明>

\```bash
python "<skill_root>\scripts\<script_name>.py" "<input_file>" <其他参数>
\```

> ⚠️ 禁止使用 `python -c` 执行多行 Python 代码。必须使用 skill 提供的脚本。

### 第 N 步：验证（强制性）

> ⛔ 本步骤为强制性步骤，不得跳过。未通过验证的结果禁止输出给用户。

\```bash
python "<skill_root>\scripts\verify.py" "<input_file>" "<output_file>" "<work_dir>"
\```

> ⛔ 如果验证未通过，必须排查原因并修正后再继续。

### 最终步：输出结果

<输出格式模板>

## 重要规则

1. <规则>
2. <规则>
3. **禁止在终端中直接执行多行 Python 代码**：必须使用 skill 提供的脚本（`scripts/` 目录下），禁止使用 `python -c` 执行含 for 循环、if 语句等的多行代码
4. **Windows PowerShell 兼容性**：禁止使用 `PYTHONPATH=xxx python -m ...` 等 bash 语法，使用 `python "<skill_root>\scripts\脚本名.py"` 直接调用

## 技术架构

\```
<skill-name>/
├── SKILL.md                          # 本文件
├── scripts/
│   ├── <main_script>.py              # 主功能脚本
│   ├── verify.py                     # 验证脚本
│   └── ...                           # 其他辅助脚本
├── <其他目录>/
└── requirements.txt
\```

## 依赖

- <依赖项>
```

---

## 自检清单

创建 SKILL.md 后，逐项检查：

| # | 检查项 | 通过标准 |
|:--|:-------|:---------|
| 1 | 路径 | 所有文件操作路径都使用绝对路径变量（如 `<work_dir>`），无相对路径 |
| 2 | 工作文件夹位置 | 明确指定工作文件夹创建在输入文件所在目录下，禁止在 skill 目录内创建 |
| 3 | 禁止事项 | 在 SKILL.md 开头有醒目的禁止事项专区，每条说明后果和替代方案 |
| 4 | 示例代码 | 只提供推荐用法的代码，不展示有缺陷的 API 用法 |
| 5 | 脚本化工作流 | 所有复杂逻辑封装为 `scripts/` 目录下的 `.py` 脚本文件，SKILL.md 中只提供单行脚本调用命令，不提供需要 LLM 在终端中输入的多行代码块 |
| 6 | 跨平台兼容 | 不使用 bash 专属语法（如 `PYTHONPATH=xxx`），脚本内部自行处理 `sys.path`，LLM 无需设置环境变量 |
| 7 | 中间产物 | 明确指定存放目录和命名规则，区分"skill 自带脚本"和"运行时中间文件" |
| 8 | 验证步骤 | 标记为强制性，封装为脚本文件（`verify.py`），LLM 只需一行命令调用 |
| 9 | 动态值 | 要求实际执行命令获取，禁止编造或使用占位值 |
| 10 | 步骤编号 | 使用编号步骤，每步有明确输入输出，每步的命令为单行可执行 |
| 11 | 禁止事项重复提醒 | 在工作流中涉及禁止事项的步骤处，再次用 ⛔ 标记提醒 |
| 12 | 无歧义 | 每条指令只有一种解读方式，不存在"可能是 A 也可能是 B"的情况 |
| 13 | 路径变量集中定义 | 在工作流之前有"路径变量说明"专区，用表格列出所有路径变量 |
| 14 | 脚本自包含 | 所有脚本内部自行处理 `sys.path`、import、路径拼接，使用 `pathlib.Path` 处理路径 |
| 15 | 无矛盾规则 | 禁止事项之间、禁止事项与工作流步骤之间不存在逻辑矛盾（如"禁止创建脚本文件"与"执行多行代码"矛盾） |
