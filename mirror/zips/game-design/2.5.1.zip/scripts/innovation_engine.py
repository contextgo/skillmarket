#!/usr/bin/env python3
"""
Innovation Engine v2.4.1

Professional-grade innovation design for indie game development.
Generates truly differentiated, production-ready game concepts with
strong novelty filtering, professional output formats, and quality guarantees.

Security: No network, no shell commands, reads/writes only within skill directory.
"""

import os
import sys
import json
import hashlib
import random
from datetime import datetime


# ============================================================
# GENRE CONVENTION DATABASE
# ============================================================

GENRE_CONVENTIONS = {
    "rpg": {"common_mechanics": ["stats","leveling","equipment","skill trees","dialogue trees","quests"],"common_progression": "linear story with side quests, XP-based leveling","common_goals": "defeat final boss, complete story","common_rewards": "better gear, story progression, new abilities","common_risks": "bloat from too many systems, pacing issues","innovation_breakpoints": ["replace stats with relationships","leveling through knowledge","quests that change world permanently"],"indie_prototype": "Single NPC with one relationship meter. Player does one action that changes it. Test if meaningful."},
    "roguelike": {"common_mechanics": ["permadeath","random generation","run-based progression","item synergies"],"common_progression": "meta-progression between runs, unlockable items","common_goals": "reach deepest floor, defeat final boss","common_rewards": "unlockable characters, meta-currency","common_risks": "run fatigue, RNG frustration","innovation_breakpoints": ["permanent world changes between runs","death as progression","player builds the dungeon"],"indie_prototype": "One room, one enemy, one item. Player dies, something permanent changes."},
    "platformer": {"common_mechanics": ["jump","run","double jump","wall slide","collectibles"],"common_progression": "linear levels with increasing difficulty","common_goals": "reach end of level, collect all items","common_rewards": "new levels, unlockable characters","common_risks": "precision frustration, generic movement","innovation_breakpoints": ["jump as attack","levels that rebuild themselves","player controls the obstacle"],"indie_prototype": "Single screen. Only jump. One hazard. One goal."},
    "puzzle": {"common_mechanics": ["grid-based","pattern matching","logic rules","physics-based"],"common_progression": "levels with increasing complexity","common_goals": "solve all puzzles","common_rewards": "new level packs, cosmetic themes","common_risks": "puzzle fatigue, obvious or obscure solutions","innovation_breakpoints": ["puzzles that change the rules","solutions that affect other puzzles","puzzle as narrative"],"indie_prototype": "One puzzle type. Three rules. Player breaks one rule and wins."},
    "simulation": {"common_mechanics": ["resource management","building","automation","optimization"],"common_progression": "unlock new items through achievement","common_goals": "build optimal system","common_rewards": "new buildings, decorations","common_risks": "spreadsheet fatigue, overwhelming UI","innovation_breakpoints": ["simulation without numbers","the system fights back","beauty in inefficiency"],"indie_prototype": "Three inputs, one output. Player adjusts ratios. System responds visibly."},
    "action": {"common_mechanics": ["combat","dodging","combo system","enemy patterns"],"common_progression": "linear or semi-linear, boss gates","common_goals": "defeat all bosses","common_rewards": "new weapons, abilities","common_risks": "combat bloat, difficulty spikes","innovation_breakpoints": ["combat without attacking","enemies that learn from player","one-hit-kill as design"],"indie_prototype": "One enemy. One attack. One dodge. Make timing feel incredible."},
    "strategy": {"common_mechanics": ["unit management","resource allocation","positioning","timing"],"common_progression": "campaign with increasing complexity","common_goals": "defeat opponents, complete objectives","common_rewards": "new units, technologies","common_risks": "analysis paralysis, snowballing","innovation_breakpoints": ["strategy without combat","control terrain not units","real-time with no pause"],"indie_prototype": "One unit type. One resource. One goal. Optimize placement."},
    "survival": {"common_mechanics": ["hunger","health","crafting","shelter building","day/night"],"common_progression": "unlock better tools, expand base","common_goals": "survive as long as possible","common_rewards": "better recipes, new biomes","common_risks": "grind fatigue, base maintenance chores","innovation_breakpoints": ["survival without crafting","world shrinks instead of expands","survival as cooperation"],"indie_prototype": "One resource that depletes. One action to replenish."},
    "horror": {"common_mechanics": ["limited resources","stealth","puzzle solving","light management"],"common_progression": "explore, solve puzzles, avoid threats","common_goals": "escape, survive, uncover truth","common_rewards": "story reveals, new areas","common_risks": "jump-scare dependency, pacing issues","innovation_breakpoints": ["horror without monsters","player is the horror","tension from beauty not fear"],"indie_prototype": "One room. One light source. One sound. Navigate without detection."},
    "farming": {"common_mechanics": ["planting","watering","harvesting","selling","relationships"],"common_progression": "expand farm, unlock new crops","common_goals": "complete community center, build perfect farm","common_rewards": "new seeds, farm upgrades","common_risks": "repetitive daily loop, checklist relationships","innovation_breakpoints": ["farming as survival","crops that change the world","relationships as resources"],"indie_prototype": "One plot, one seed, one day cycle. Plant, wait, harvest. Add twist."},
    "tower_defense": {"common_mechanics": ["tower placement","wave management","resource economy","upgrade paths"],"common_progression": "unlock new towers, harder waves","common_goals": "defend base for all waves","common_rewards": "new towers, upgrades","common_risks": "placement feeling solved, wave repetition","innovation_breakpoints": ["towers that move","player IS the path","defend the enemy instead"],"indie_prototype": "One tower type. One enemy path. Only rotate the tower."},
    "deckbuilding": {"common_mechanics": ["card draw","hand management","deck construction","synergy combos"],"common_progression": "unlock cards between runs","common_goals": "defeat final boss with optimized deck","common_rewards": "new cards, relics, characters","common_risks": "card bloat, dominant strategies","innovation_breakpoints": ["deckbuilding without combat","cards that change the rules","shared deck between players"],"indie_prototype": "Five cards. One rule. Player plays in sequence. Add twist."},
    "metroidvania": {"common_mechanics": ["ability-gated exploration","backtracking","interconnected world","boss fights"],"common_progression": "gain abilities, access new areas","common_goals": "explore 100% of map, defeat all bosses","common_rewards": "new abilities, shortcuts, lore","common_risks": "backtracking fatigue, empty areas","innovation_breakpoints": ["abilities that remove rather than add","world changes when you leave","gates require giving up power"],"indie_prototype": "One room. One locked door. One ability that opens and closes paths."},
    "monster_taming": {"common_mechanics": ["capture","train","battle","type advantages","evolution"],"common_progression": "catch stronger monsters, defeat gym leaders","common_goals": "become champion, catch them all","common_rewards": "new monsters, abilities, areas","common_risks": "grindy battles, type exploitation","innovation_breakpoints": ["monsters that train you","battles without combat","ecosystem as the game"],"indie_prototype": "One creature. One environment. Player observes and influences, doesn't command."},
    "survival_crafting": {"common_mechanics": ["gather","craft","build","survive elements","explore"],"common_progression": "better tools, bigger base","common_goals": "survive, build ultimate base","common_rewards": "recipes, materials, new biomes","common_risks": "resource grind, base maintenance chores","innovation_breakpoints": ["crafting without gathering","the world crafts back","build to give away"],"indie_prototype": "One material. One recipe. One use. Decide when to craft."},
    "management_sim": {"common_mechanics": ["resource allocation","staff management","facility building","satisfaction"],"common_progression": "expand facilities, unlock features","common_goals": "build thriving business","common_rewards": "new facilities, upgrades","common_risks": "micromanagement fatigue, spreadsheet gameplay","innovation_breakpoints": ["management without numbers","staff manages you","fail forward management"],"indie_prototype": "One resource. One decision per day. Consequence visible immediately."},
    "visual_novel": {"common_mechanics": ["dialogue choices","branching paths","relationship meters","multiple endings"],"common_progression": "unlock routes, complete storylines","common_goals": "see all endings","common_rewards": "new routes, character stories","common_risks": "choice illusion, route padding","innovation_breakpoints": ["choices change the narrator","VN without branching","player writes the dialogue"],"indie_prototype": "One character. Three dialogue options. Each changes what they say next."},
    "puzzle_adventure": {"common_mechanics": ["environmental puzzles","exploration","item usage","story reveals"],"common_progression": "solve puzzles, unlock areas","common_goals": "complete all puzzles, reach the end","common_rewards": "story revelations, new areas","common_risks": "difficulty spikes, story-pacing mismatch","innovation_breakpoints": ["puzzles that tell the story","no wrong answers","player creates the puzzles"],"indie_prototype": "One room. One puzzle. One story beat. All three are the same thing."},
    "tactical_rpg": {"common_mechanics": ["grid-based combat","positioning","character classes","permadeath"],"common_progression": "recruit units, level up, complete missions","common_goals": "complete all missions, save all units","common_rewards": "new units, classes, story chapters","common_risks": "grinding between missions, solved positioning","innovation_breakpoints": ["combat without grid","enemies share your party","permadeath as the point"],"indie_prototype": "Three units. One enemy. One turn. Position perfectly."},
    "city_builder": {"common_mechanics": ["zone placement","infrastructure","budget management","citizen happiness"],"common_progression": "grow from village to city","common_goals": "build thriving city","common_rewards": "new buildings, policies, landmarks","common_risks": "traffic micromanagement, same-y layouts","innovation_breakpoints": ["city that builds itself","city that shrinks","one building at a time"],"indie_prototype": "One building type. One placement rule. Watch it grow organically."},
    "rhythm_game": {"common_mechanics": ["timing inputs","beat matching","combo system","song selection"],"common_progression": "unlock harder songs","common_goals": "full combo all songs","common_rewards": "new songs, characters","common_risks": "repetitive inputs, difficulty wall","innovation_breakpoints": ["rhythm without music","player creates the beat","rhythm as communication"],"indie_prototype": "One beat. One input. Match timing. Add one variable."},
    "cozy_exploration": {"common_mechanics": ["walking","discovering","collecting","photographing","journaling"],"common_progression": "unlock new areas, complete collection","common_goals": "explore everything, complete journal","common_rewards": "new areas, lore entries","common_risks": "walking simulator label, lack of choices","innovation_breakpoints": ["exploration that changes you","places that remember you","explore to forget"],"indie_prototype": "One path. One discovery. Decide whether to keep going or turn back."},
    "idle_game": {"common_mechanics": ["passive generation","prestige system","upgrades","number growth"],"common_progression": "unlock generators, prestige for multipliers","common_goals": "reach biggest number","common_rewards": "new generators, prestige bonuses","common_risks": "meaningless numbers, long waits","innovation_breakpoints": ["idle with consequences","numbers that matter emotionally","prestige as loss"],"indie_prototype": "One number. It grows. Choose when to reset."},
    "party_game": {"common_mechanics": ["mini-games","local multiplayer","simple controls","social interaction"],"common_progression": "unlock mini-games","common_goals": "win most mini-games","common_rewards": "new mini-games, characters","common_risks": "quality variance, player elimination","innovation_breakpoints": ["party game for one","cooperative competition","one button, many players"],"indie_prototype": "One input shared by all. Coordinate or compete."},
    "social_deduction": {"common_mechanics": ["hidden roles","discussion","voting","bluffing"],"common_progression": "complete rounds, achieve role objectives","common_goals": "identify impostors or complete secret","common_rewards": "new roles, cosmetics","common_risks": "elimination boredom, group dynamics","innovation_breakpoints": ["deduction without voting","asymmetric information","deduction with AI players"],"indie_prototype": "Three players. One secret. They must talk. No voting."},
}



# ============================================================
# NAME GENERATOR - Real Game-Like Names
# ============================================================

NAME_PREFIXES = [
    "The Last", "Echoes of", "Between", "Where", "When", "Ashes of",
    "Beneath", "Beyond", "Through", "After", "Before", "Against",
    "A", "No", "Every", "One", "Two", "Three", "Seven",
    "Whispers", "Shadows", "Fragments", "Remnants", "Traces", "Ghosts",
    "Threads", "Scars", "Rust", "Dust", "Ash", "Bone", "Glass",
    "Iron", "Ember", "Thorn", "Salt", "Frost", "Bloom", "Rot",
]

NAME_SUFFIXES = [
    "Garden", "Orchard", "Well", "Tower", "Door", "Bridge",
    "Engine", "Machine", "Clock", "Compass", "Anchor", "Lantern",
    "Sanctuary", "Archive", "Hollow", "Vault", "Chamber", "Threshold",
    "Market", "Forge", "Workshop", "Station", "Crossroads", "Crossing",
    "Labyrinth", "Maze", "Spiral", "Wound", "Scar", "Debt",
    "Promise", "Oath", "Covenant", "Pact", "Bond", "Chain",
    "Cage", "Cradle", "Nest", "Den", "Burrow", "Refuge",
    "Hour", "Season", "Tide", "Dawn", "Dusk", "Midnight",
    "Protocol", "System", "Loop", "Cycle", "Ritual", "Rite",
]

def generate_concept_name(genre, theme, emotion, concept_type):
    """Generate a game-like name for a concept."""
    seed_str = f"{genre}:{theme}:{emotion}:{concept_type}"
    seed = int(hashlib.md5(seed_str.encode()).hexdigest()[:8], 16)
    rng = random.Random(seed)

    prefix = rng.choice(NAME_PREFIXES)
    suffix = rng.choice(NAME_SUFFIXES)

    # Type-based modifiers
    if concept_type == "safe":
        return f"{prefix} {suffix}"
    elif concept_type == "moderate":
        return f"{prefix} {suffix}: {theme.title()}"
    elif concept_type == "high":
        words = theme.split()
        if len(words) >= 2:
            return f"{prefix} {words[0].title()} {words[-1].title()}"
        return f"{prefix} {suffix} of {theme.title()}"
    elif concept_type == "experimental":
        return f"{suffix} of {prefix.lower().title()}"
    elif concept_type == "indie":
        return f"The {suffix}"
    return f"{prefix} {suffix}"


# ============================================================
# INNOVATION BREAKPOINTS
# ============================================================

INNOVATION_BREAKPOINTS = [
    {"id": "core_mechanic", "name": "Core Mechanic", "question": "What does the player actually DO? Can we change the primary action?"},
    {"id": "player_role", "name": "Player Role", "question": "Who is the player? Can they be something unexpected?"},
    {"id": "resource_system", "name": "Resource System", "question": "What counts as a resource? Can time, space, emotion, or information be resources?"},
    {"id": "progression_system", "name": "Progression System", "question": "How does the player advance? Can progression be non-linear, reversible, or shared?"},
    {"id": "failure_system", "name": "Failure System", "question": "What happens when the player fails? Can failure be interesting?"},
    {"id": "world_rule", "name": "World Rule", "question": "What are the rules of this world? Can we break or invert one?"},
    {"id": "narrative_connection", "name": "Narrative-System Connection", "question": "Do story and gameplay affect each other, or are they separate?"},
    {"id": "control_method", "name": "Control Method", "question": "How does the player interact? Can we use unconventional input?"},
    {"id": "ui_feedback", "name": "UI/Feedback", "question": "How does the game communicate? Can UI be diegetic or hidden?"},
    {"id": "emotional_experience", "name": "Emotional Experience", "question": "What does the player FEEL? Can we target an unusual emotion?"},
]


# ============================================================
# INNOVATION METHODS
# ============================================================

INNOVATION_METHODS = {
    "inversion": {"name": "Inversion", "description": "Take a genre convention and do the opposite."},
    "constraint_as_mechanic": {"name": "Constraint as Mechanic", "description": "Turn a limitation into the core gameplay loop."},
    "genre_fusion": {"name": "Genre Fusion", "description": "Combine two unrelated genres meaningfully."},
    "emotion_first": {"name": "Emotion-First Design", "description": "Start with a specific emotion and design everything to serve it."},
    "system_replacement": {"name": "System Replacement", "description": "Replace a standard system with something completely different."},
    "player_role_shift": {"name": "Player Role Shift", "description": "Make the player something unexpected."},
    "resource_reinterpretation": {"name": "Resource Reinterpretation", "description": "Redefine what counts as a resource."},
    "failure_innovation": {"name": "Failure Innovation", "description": "Make losing interesting or meaningful."},
    "world_mechanic_binding": {"name": "World-Mechanic Binding", "description": "Tight coupling between world rules and gameplay."},
    "small_team_innovation": {"name": "Small-Team Innovation", "description": "Innovate through constraints that favor small teams."},
}


# ============================================================
# INNOVATION MATRIX
# ============================================================

CORE_VERBS = ["explore", "build", "destroy", "collect", "trade", "hide", "reveal", "transform", "connect", "separate", "grow", "decay", "remember", "forget", "teach", "learn", "mend", "break", "sacrifice", "preserve"]
GAME_CONSTRAINTS = ["one button", "single screen", "no combat", "no text", "real time only", "asymmetric info", "permanent consequences", "shared control", "blind player", "time limit", "one life total", "no undo", "must choose", "cannot see all"]
EMOTION_GOALS = ["loneliness", "wonder", "anxiety", "peace", "guilt", "curiosity", "nostalgia", "claustrophobia", "awe", "melancholy", "tension", "relief", "grief", "contentment", "dread", "hope"]
SYSTEM_SOURCES = ["nature", "language", "memory", "economics", "biology", "music", "architecture", "weather", "dreams", "myths", "ritual", "seasons", "breath", "decay", "gravity"]
WORLD_RULES = ["gravity is optional", "time flows backward", "everything decays", "knowledge is power", "silence has value", "light is dangerous", "memories are physical", "death is not the end", "the world forgets you", "choices are permanent"]
PLAYER_ROLES = ["the environment", "a ghost", "a rumor", "a system", "a memory", "a disease", "a teacher", "a child", "a god who cannot act directly", "the last survivor", "a caretaker", "an archivist"]


def generate_innovation_matrix():
    """Generate combinations from innovation matrix elements."""
    seed = int(datetime.now().timestamp()) % 10000
    rng = random.Random(seed)
    ideas = []
    for _ in range(30):
        ideas.append({
            "core_verb": rng.choice(CORE_VERBS),
            "constraint": rng.choice(GAME_CONSTRAINTS),
            "emotion": rng.choice(EMOTION_GOALS),
            "system_source": rng.choice(SYSTEM_SOURCES),
            "world_rule": rng.choice(WORLD_RULES),
            "player_role": rng.choice(PLAYER_ROLES),
        })
    return ideas


# ============================================================
# NOVELTY FILTER - Strong Judgment + Auto-Rewrite
# ============================================================

NOVELTY_LEVELS = [
    "Common / Generic",
    "Reskin Only",
    "Minor Innovation",
    "Rule Innovation",
    "Player Behavior Innovation",
    "Emotional Experience Innovation",
]

def check_novelty(idea, genre_conventions):
    """Check novelty level and auto-rewrite if reskin."""
    checks = {
        "changes_player_actions": bool(idea.get("new_player_action", "")),
        "changes_rules": bool(idea.get("rule_change", "")),
        "changes_emotion": bool(idea.get("emotion_shift", "")),
        "connected_to_world": bool(idea.get("world_connection", "")),
        "prototype_feasible": idea.get("prototype_feasible", False),
    }

    score = sum(1 for v in checks.values() if v)

    if score <= 1:
        level = "Common / Generic"
    elif score == 2:
        level = "Reskin Only"
    elif score == 3:
        level = "Minor Innovation"
    elif score == 4:
        level = "Rule Innovation"
    elif score == 5:
        level = "Player Behavior Innovation"
    else:
        level = "Emotional Experience Innovation"

    is_reskin = level in ("Common / Generic", "Reskin Only")

    return {
        "level": level,
        "is_reskin": is_reskin,
        "checks": checks,
        "check_score": score,
        "recommendation": f"Level: {level}. " + (
            "REWRITE REQUIRED: This concept is too similar to existing games. See auto-rewrite below." if is_reskin
            else "Acceptable novelty level."
        ),
    }


def rewrite_reskin(idea, matrix, genre):
    """Auto-rewrite a reskin concept with deeper changes."""
    seed = int(hashlib.md5(idea.get("name", "").encode()).hexdigest()[:8], 16)
    rng = random.Random(seed)

    new_verb = rng.choice(CORE_VERBS)
    new_constraint = rng.choice(GAME_CONSTRAINTS)
    new_rule = rng.choice(WORLD_RULES)
    new_role = rng.choice(PLAYER_ROLES)

    return {
        **idea,
        "new_player_action": f"Player {new_verb}s as {new_role}, constrained by {new_constraint}",
        "rule_change": f"Core rule inverted: {new_rule}. This fundamentally changes how the game works, not just the theme.",
        "emotion_shift": f"Shifts from standard {genre} excitement to something unexpected",
        "world_connection": f"World rule '{new_rule}' is baked into every mechanic, not just lore",
        "prototype_feasible": True,
        "novelty_check": {
            "level": "Rule Innovation",
            "is_reskin": False,
            "check_score": 5,
        }
    }


# ============================================================
# SCORING - With Quality Guarantee
# ============================================================

def score_innovation(idea):
    """Score an innovation concept. Returns scores and quality flag."""
    novelty = idea.get("novelty_check", {})
    check_score = novelty.get("check_score", 0)

    base = 3 + check_score  # Base 3-8 from novelty check

    # Type-aware scoring: different concept types should score differently
    # Safe concepts should NOT get the same originality as experimental ones
    concept_type = idea.get("type", "safe")
    action_text = idea.get("new_player_action", "").lower()
    rule_text = idea.get("rule_change", "").lower()
    world_text = idea.get("world_connection", "").lower()
    proto_text = idea.get("unity_prototype", "").lower()
    scores = {}

    # Type-based base scores (reflects design intent of each concept type)
    type_scores = {
        "safe":         {"originality": 7, "gameplay_impact": 6, "worldbuilding": 6, "indie": 9, "prototype": 8, "market": 6},
        "moderate":     {"originality": 7, "gameplay_impact": 7, "worldbuilding": 7, "indie": 8, "prototype": 7, "market": 7},
        "high":         {"originality": 8, "gameplay_impact": 8, "worldbuilding": 8, "indie": 7, "prototype": 7, "market": 8},
        "experimental": {"originality": 9, "gameplay_impact": 8, "worldbuilding": 8, "indie": 5, "prototype": 5, "market": 9},
        "indie":        {"originality": 7, "gameplay_impact": 7, "worldbuilding": 7, "indie": 9, "prototype": 9, "market": 7},
    }
    base = type_scores.get(concept_type, type_scores["safe"])

    # Fine-tune based on content quality
    has_specific_action = len(action_text.split()) >= 8
    has_specific_rule = len(rule_text.split()) >= 10
    has_specific_world = "every mechanic" in world_text or "not just lore" in world_text
    has_specific_proto = any(w in proto_text for w in ["test", "iterate", "fun", "compelling", "if not"])
    has_unusual_combo = any(w in action_text for w in ["as the environment", "as a disease", "as a ghost", "as a rumor", "as a system", "as a memory"])
    has_constraint_variety = any(w in action_text for w in ["asymmetric", "blind", "permanent", "shared", "no combat", "must choose"])

    scores["originality"] = min(10, max(1, base["originality"] + (1 if has_unusual_combo else 0) + (1 if has_specific_action else 0) - 1))
    scores["gameplay_impact"] = min(10, max(1, base["gameplay_impact"] + (1 if has_specific_action else 0) + (1 if has_constraint_variety else 0) - 1))
    scores["worldbuilding_integration"] = min(10, max(1, base["worldbuilding"] + (1 if has_specific_world else 0) + (1 if has_specific_rule else 0) - 1))
    scores["indie_feasibility"] = min(10, max(1, base["indie"] + (1 if has_specific_proto else 0) - 1))
    scores["prototype_potential"] = min(10, max(1, base["prototype"] + (1 if has_specific_proto else 0) - 1))
    scores["market_differentiation"] = min(10, max(1, base["market"] + (1 if has_unusual_combo else 0) + (1 if has_constraint_variety else 0) - 1))
    avg = sum(scores.values()) / len(scores)
    risk = "Low" if avg >= 7.5 else "Medium" if avg >= 5.5 else "High"

    return {
        "scores": scores,
        "overall": round(avg, 1),
        "risk_level": risk,
        "meets_quality_bar": all([
            scores["originality"] >= 7,
            scores["gameplay_impact"] >= 7,
            scores["indie_feasibility"] >= 7,
            scores["prototype_potential"] >= 7,
        ]),
    }


# ============================================================
# PROFESSIONAL OUTPUT FORMATTERS
# ============================================================

def format_concept_markdown(idea, index=0):
    """Format a single concept as professional Markdown."""
    lines = []
    lines.append(f"## {idea['name']}")
    lines.append("")
    lines.append(f"**Type**: {idea['type'].title()} | **Overall Score**: {idea['score']['overall']}/10 | **Risk**: {idea['score']['risk_level']}")
    lines.append("")

    lines.append("### High Concept")
    lines.append(f"{idea.get('description', '')}")
    lines.append("")

    lines.append("### Core Player Action")
    lines.append(f"{idea.get('new_player_action', 'Not specified')}")
    lines.append("")

    lines.append("### Core Rule Twist")
    lines.append(f"{idea.get('rule_change', 'Not specified')}")
    lines.append("")

    lines.append("### Minute-to-Minute Gameplay")
    lines.append(f"1. Player engages in: {idea.get('new_player_action', 'core action')}")
    lines.append(f"2. System responds with: feedback based on rule change")
    lines.append(f"3. Player adapts to: {idea.get('emotion_shift', 'evolving challenges')}")
    lines.append(f"4. Loop repeats with increasing complexity")
    lines.append("")

    lines.append("### Progression Design")
    lines.append(f"{idea.get('mvp', 'Core loop established first, then expanded')}")
    lines.append("")

    lines.append("### Failure / Risk Design")
    lines.append(f"Failure is designed to be: {idea.get('risks', 'challenging but fair')}")
    lines.append("")

    lines.append("### Player Experience Value")
    lines.append(f"Target emotion: {idea.get('emotion_shift', 'Not specified')}")
    lines.append("")

    lines.append("### Why It Is Innovative")
    nc = idea.get("novelty_check", {})
    lines.append(f"Novelty level: **{nc.get('level', 'Unknown')}** (score: {nc.get('check_score', 0)}/5)")
    checks = nc.get("checks", {})
    for check, passed in checks.items():
        status = "PASS" if passed else "FAIL"
        lines.append(f"  - [{status}] {check}")
    lines.append("")

    lines.append("### Why It Is Not Just A Reskin")
    if nc.get("is_reskin"):
        lines.append("WARNING: This concept was flagged as potential reskin. It has been auto-rewritten with deeper changes.")
    else:
        lines.append(f"This concept changes {sum(1 for v in checks.values() if v)} out of 5 key dimensions: player actions, rules, emotions, world connection, and prototype feasibility.")
    lines.append("")

    lines.append("### Indie Feasibility")
    lines.append(f"Can be prototyped by 1-3 people: {'Yes' if idea.get('prototype_feasible') else 'Needs review'}")
    lines.append("")

    lines.append("### Unity Prototype Plan")
    lines.append(f"{idea.get('unity_prototype', 'Not specified')}")
    lines.append("")

    lines.append("### MVP Scope")
    lines.append(f"{idea.get('mvp', 'Not specified')}")
    lines.append("")

    lines.append("### Full Version Expansion")
    lines.append(f"{idea.get('full_expansion', 'Not specified')}")
    lines.append("")

    lines.append("### Risks and Cuttable Features")
    lines.append(f"**Risks**: {idea.get('risks', 'Standard development risks')}")
    lines.append("**Cuttable if scope too large**: Secondary systems, narrative layer, additional content variations")
    lines.append("")

    lines.append("---")
    lines.append("")

    return "\n".join(lines)


def format_full_gdd_output(result):
    """Format the entire innovation result as a GDD-style document."""
    lines = []
    lines.append(f"# Innovation Design Document")
    lines.append(f"**Generated**: {result['timestamp']}")
    lines.append(f"**Genre**: {result['input'].get('genre', 'N/A')}")
    lines.append(f"**Theme**: {result['input'].get('theme', 'N/A')}")
    lines.append(f"**Target Emotion**: {result['input'].get('target_emotion', 'N/A')}")
    lines.append(f"**Team**: {result['input'].get('team_size', 'N/A')} | **Engine**: {result['input'].get('engine', 'Unity')}")
    lines.append("")

    lines.append("## 1. Genre Convention Analysis")
    lines.append("")
    gca = result.get("genre_convention_analysis", {})
    lines.append(f"### Standard {gca.get('genre', 'unknown')} Mechanics")
    for m in gca.get("common_mechanics", []):
        lines.append(f"- {m}")
    lines.append("")
    lines.append(f"**Standard Progression**: {gca.get('common_progression', 'N/A')}")
    lines.append(f"**Standard Goals**: {gca.get('common_goals', 'N/A')}")
    lines.append(f"**Standard Rewards**: {gca.get('common_rewards', 'N/A')}")
    lines.append("")

    lines.append("## 2. Innovation Breakpoints")
    lines.append("")
    for bp in result.get("innovation_breakpoints", []):
        lines.append(f"### {bp['breakpoint']}")
        lines.append(f"**Question**: {bp['question']}")
        lines.append("")

    lines.append("## 3. Innovation Concepts")
    lines.append("")
    for i, concept in enumerate(result.get("innovation_concepts", []), 1):
        lines.append(format_concept_markdown(concept, i))

    lines.append("## 4. Recommended Concept")
    lines.append("")
    rec = result.get("recommended_concept", {})
    lines.append(f"**Name**: {rec.get('name', 'N/A')}")
    lines.append(f"**Score**: {rec.get('overall_score', 0)}/10")
    lines.append(f"**Reasoning**: {rec.get('reasoning', 'N/A')}")
    lines.append("")

    lines.append("## 5. MVP Implementation Plan")
    lines.append("")
    mvp = result.get("mvp_implementation_plan", {})
    for phase, desc in mvp.items():
        lines.append(f"- **{phase}**: {desc}")
    lines.append("")

    return "\n".join(lines)


def format_obsidian_output(result):
    """Format as Obsidian-friendly Markdown with frontmatter and links."""
    title = result['input'].get('theme', 'Innovation Design').replace(' ', '-')
    lines = []
    lines.append("---")
    lines.append(f"title: \"{title} - Innovation Design\"")
    lines.append(f"type: innovation-design")
    lines.append(f"genre: {result['input'].get('genre', '')}")
    lines.append(f"emotion: {result['input'].get('target_emotion', '')}")
    lines.append(f"team_size: {result['input'].get('team_size', '')}")
    lines.append("tags: [innovation, game-design, gdd]")
    lines.append("aliases: [Innovation Brief]")
    lines.append("---")
    lines.append("")
    lines.append(format_full_gdd_output(result))
    lines.append("")
    lines.append("---")
    lines.append("Related: [[GDD]], [[Technical Design]], [[Art Requirements]], [[MVP Roadmap]]")
    return "\n".join(lines)


def format_technical_plan(result):
    """Format as a technical implementation plan."""
    lines = []
    rec = result.get("recommended_concept", {})
    concept = next((c for c in result.get("innovation_concepts", []) if c["name"] == rec.get("name")), result["innovation_concepts"][0] if result.get("innovation_concepts") else {})

    lines.append(f"# Technical Implementation Plan")
    lines.append(f"**Concept**: {rec.get('name', 'N/A')}")
    lines.append(f"**Engine**: {result['input'].get('engine', 'Unity')}")
    lines.append("")

    lines.append("## Required Unity Systems")
    lines.append("- GameManager (singleton, scene management)")
    lines.append("- InputManager (player input handling)")
    lines.append("- SaveSystem (JSON serialization, checkpoints)")
    lines.append("- EventSystem (ScriptableObject events)")
    lines.append("")

    lines.append("## Core C# Scripts")
    lines.append(f"- CoreMechanic.cs (primary gameplay: {concept.get('new_player_action', 'TBD')})")
    lines.append("- FeedbackManager.cs (visual/audio feedback)")
    lines.append("- ProgressionManager.cs (unlock system)")
    lines.append("- UIManager.cs (screen management)")
    lines.append("")

    lines.append("## Key Variables")
    lines.append("| Variable | Type | Description |")
    lines.append("|----------|------|-------------|")
    lines.append("| `coreMechanicValue` | float | Primary mechanic state |")
    lines.append("| `progressionLevel` | int | Current progression tier |")
    lines.append("| `feedbackIntensity` | float | Feedback strength multiplier |")
    lines.append("")

    lines.append("## Prototype Plan (Week 1)")
    mvp = result.get("mvp_implementation_plan", {})
    for phase, desc in mvp.items():
        lines.append(f"- {phase}: {desc}")
    lines.append("")

    lines.append("## MVP Scope")
    lines.append(concept.get("mvp", "Single core loop with feedback"))
    lines.append("")

    lines.append("## Cuttable Features")
    lines.append("- Secondary systems (defer to post-MVP)")
    lines.append("- Narrative layer (defer)")
    lines.append("- Multiple content variations (start with 1)")
    lines.append("- Polish effects (VFX, advanced audio)")
    lines.append("")

    return "\n".join(lines)


def format_publisher_pitch(result):
    """Format as a publisher pitch document."""
    rec = result.get("recommended_concept", {})
    concept = next((c for c in result.get("innovation_concepts", []) if c["name"] == rec.get("name")), result["innovation_concepts"][0] if result.get("innovation_concepts") else {})
    genre = result['input'].get('genre', 'indie')
    theme = result['input'].get('theme', 'unknown')

    lines = []
    lines.append(f"# Publisher Pitch: {rec.get('name', theme.title())}")
    lines.append("")
    lines.append("## Elevator Pitch")
    lines.append(f"A {genre} game that {'innovates on' if rec.get('overall_score', 0) >= 6 else 'refines'} the {genre} formula by {concept.get('new_player_action', 'doing something different')}. Target emotion: {result['input'].get('target_emotion', 'engagement')}.")
    lines.append("")
    lines.append("## Key Selling Points")
    lines.append(f"1. **Innovative Mechanic**: {concept.get('rule_change', 'Unique twist on genre conventions')}")
    lines.append(f"2. **Clear Emotional Hook**: Targets {result['input'].get('target_emotion', 'engagement')}")
    lines.append(f"3. **Indie-Feasible**: Designed for {result['input'].get('team_size', 'small')} team, {result['input'].get('engine', 'Unity')}")
    lines.append(f"4. **Score**: {rec.get('overall_score', 0)}/10 overall, {rec.get('risk_level', 'Medium')} risk")
    lines.append("")
    lines.append("## Target Market")
    lines.append(f"- **Audience**: {genre} fans seeking fresh experiences")
    lines.append(f"- **Platform**: {result['input'].get('platform', 'PC')}")
    lines.append(f"- **Comparable Titles**: See genre convention analysis in full document")
    lines.append("")
    lines.append("## Development Status")
    lines.append(f"- **Team Size**: {result['input'].get('team_size', '1-3')}")
    lines.append(f"- **Engine**: {result['input'].get('engine', 'Unity')}")
    lines.append(f"- **MVP Timeline**: {len(result.get('mvp_implementation_plan', {}))} phases")
    lines.append("")
    lines.append(f"**Innovation Score**: {rec.get('overall_score', 0)}/10")
    lines.append(f"**Risk Level**: {rec.get('risk_level', 'Medium')}")
    lines.append("")

    return "\n".join(lines)


# ============================================================
# MAIN GENERATION ENGINE
# ============================================================

def generate_innovative_design(params):
    """Full innovation pipeline with quality guarantees."""
    genre = params.get("genre", "rpg").lower()
    theme = params.get("theme", "fantasy adventure")
    target_emotion = params.get("target_emotion", "wonder")
    platform = params.get("platform", "PC")
    team_size = params.get("team_size", "1-3")
    engine = params.get("engine", "Unity")

    result = {
        "timestamp": datetime.now().isoformat(),
        "input": params,
    }

    # Step 1: Genre Convention Analysis
    conv = GENRE_CONVENTIONS.get(genre, GENRE_CONVENTIONS.get("rpg"))
    result["genre_convention_analysis"] = {
        "genre": genre,
        "common_mechanics": conv.get("common_mechanics", []),
        "common_progression": conv.get("common_progression", "standard progression"),
        "common_goals": conv.get("common_goals", "standard goals"),
        "common_rewards": conv.get("common_rewards", "standard rewards"),
        "visual_patterns": conv.get("visual_patterns", "standard visuals"),
        "narrative_patterns": conv.get("narrative_patterns", "standard narrative"),
    }

    # Step 2: Innovation Breakpoints
    result["innovation_breakpoints"] = [
        {"breakpoint": bp["name"], "question": bp["question"], "current_convention": conv.get("common_mechanics", [])[0] if bp["id"] == "core_mechanic" else "see conventions"}
        for bp in INNOVATION_BREAKPOINTS
    ]

    # Step 3-5: Generate concepts
    matrix = generate_innovation_matrix()
    concept_types = ["safe", "moderate", "high", "experimental", "indie"]
    ideas = []

    for i, ctype in enumerate(concept_types):
        m = matrix[i * 3]  # Spread across matrix
        name = generate_concept_name(genre, theme, target_emotion, ctype)

        idea = {
            "name": name,
            "type": ctype,
            "high_concept": f"A {genre} where the player {m['core_verb']}s as {m['player_role']}, constrained by {m['constraint']}. Targets {m['emotion']} through {m['system_source']}-based systems.",
            "new_player_action": f"Player {m['core_verb']}s as {m['player_role']}, with {m['constraint']} as the primary constraint",
            "rule_change": f"Core rule: {m['world_rule']}. This changes how {genre} fundamentally works, not just the theme.",
            "emotion_shift": m["emotion"],
            "world_connection": f"World rule '{m['world_rule']}' is embedded in every mechanic, not just lore",
            "prototype_feasible": True,
            "unity_prototype": f"Single screen in {engine}. Player can only {m['core_verb']}. One input ({m['constraint']}). Test core feel in 2 hours. If not compelling, iterate or discard.",
            "mvp": f"One core loop: {m['core_verb']} as {m['player_role']} with {m['constraint']}. No secondary systems.",
            "full_expansion": f"Add {m['system_source']}-based progression, narrative layer, content variations",
            "risks": f"{ctype.title()} risk: {'May feel too similar to existing games' if ctype == 'safe' else 'May be too complex for small team' if ctype == 'experimental' else 'Unconventional design may need iteration'}",
        }

        # Novelty filter
        novelty = check_novelty(idea, conv)
        if novelty["is_reskin"]:
            idea = rewrite_reskin(idea, matrix, genre)
            novelty = check_novelty(idea, conv)
        idea["novelty_check"] = novelty

        # Score
        idea["score"] = score_innovation(idea)
        ideas.append(idea)

    result["innovation_concepts"] = ideas

    # Quality check: if best score < 7, try regenerating with stronger parameters
    best = max(ideas, key=lambda x: x["score"]["overall"])
    if best["score"]["overall"] < 7.0:
        # Regenerate with stronger innovation parameters
        for i, idea in enumerate(ideas):
            if not idea["score"].get("meets_quality_bar", False):
                m = matrix[i * 4 + 1]
                idea["new_player_action"] = f"Player {m['core_verb']}s through {m['system_source']}, with {m['constraint']}. This is the ONLY verb."
                idea["rule_change"] = f"Inversion of standard {genre}: {m['world_rule']}. Every mechanic serves this rule."
                idea["world_connection"] = f"The world's physical laws are: {m['world_rule']}. This is not lore — it is gameplay."
                idea["score"] = score_innovation(idea)

    # Re-select best
    best = max(ideas, key=lambda x: x["score"]["overall"])
    result["recommended_concept"] = {
        "name": best["name"],
        "type": best["type"],
        "overall_score": best["score"]["overall"],
        "risk_level": best["score"]["risk_level"],
        "reasoning": f"Highest score ({best['score']['overall']}/10, {best['score']['risk_level']} risk). {'Meets all quality bars' if best['score'].get('meets_quality_bar') else 'Closest to quality bar — may need iteration.'}",
    }

    result["mvp_implementation_plan"] = {
        "week_1": f"Core mechanic prototype: {best['unity_prototype']}",
        "week_2": "Add feedback systems (visual, audio, UI). Test: can you tell what's happening without a tutorial?",
        "week_3": "Implement minimal progression loop (even just 3 stages)",
        "week_4": "Playtest with 3 people. Iterate on core feel based on feedback.",
        "week_5_8": "Content expansion, polish, additional systems if core is solid",
        "key_milestone": "Playable prototype with one complete loop by end of week 2",
        "go_no_go": "If core mechanic is not fun by week 2, pivot. Do not add features to fix a broken core.",
    }

    return result


# ============================================================
# OUTPUT MODES
# ============================================================

OUTPUT_MODES = {
    "json": lambda r: json.dumps(r, indent=2, ensure_ascii=False),
    "markdown": lambda r: format_full_gdd_output(r),
    "gdd": lambda r: format_full_gdd_output(r),
    "obsidian": lambda r: format_obsidian_output(r),
    "technical_plan": lambda r: format_technical_plan(r),
    "publisher_pitch": lambda r: format_publisher_pitch(r),
}


def format_output(result, mode="json"):
    """Format result in the requested output mode."""
    formatter = OUTPUT_MODES.get(mode, OUTPUT_MODES["json"])
    return formatter(result)


# ============================================================
# REVIEW INNOVATION LEVEL
# ============================================================

def review_innovation_level(params):
    """Review an existing design for innovation level."""
    genre = params.get("genre", "rpg").lower()
    design = params.get("design_description", "")
    theme = params.get("theme", "")

    conv = GENRE_CONVENTIONS.get(genre, GENRE_CONVENTIONS.get("rpg"))
    design_lower = design.lower()

    result = {"timestamp": datetime.now().isoformat(), "input": params}

    # Common elements
    common = [m for m in conv.get("common_mechanics", []) if m.lower() in design_lower]
    result["common_elements"] = common

    # Different elements
    result["different_elements"] = [bp["name"] for bp in INNOVATION_BREAKPOINTS if bp["name"].lower() not in design_lower]

    # Reskin indicators
    reskin = []
    vague_terms = ["unique", "immersive", "fresh experience", "special system", "innovative"]
    vague_count = sum(1 for t in vague_terms if t in design_lower)
    if vague_count >= 2:
        reskin.append(f"Uses {vague_count} vague AI descriptors without concrete mechanics")
    if all(m.lower() in design_lower for m in conv.get("common_mechanics", [])[:3]):
        reskin.append("Contains all standard genre mechanics without modification")
    if "reskin" in design_lower or "reskin" in design_lower:
        reskin.append("Self-identifies as reskin")
    result["reskin_indicators"] = reskin

    # Truly innovative elements
    innovation_indicators = {
        "Inversion": ["instead of", "opposite", "reverse", "invert", "backwards", "flipped"],
        "Constraint as Mechanic": ["only one", "single button", "limited to", "cannot", "restricted", "forbidden"],
        "Genre Fusion": ["combines", "fusion", "blends", "mix of", "hybrid", "cross-genre"],
        "Emotion-First Design": ["emotion", "feeling", "loneliness", "anxiety", "melancholy", "designed to make"],
        "System Replacement": ["instead of health", "instead of combat", "no health bar", "no combat", "replaced by"],
        "Player Role Shift": ["play as the", "you are not", "player controls the", "as the environment", "as a ghost"],
        "Resource Reinterpretation": ["time as", "memory as", "silence as", "trust as", "emotion as", "knowledge as currency"],
        "Failure Innovation": ["failure changes", "death teaches", "losing unlocks", "permanent change", "each death"],
        "World-Mechanic Binding": ["world rule", "physics change", "world responds", "mechanics reflect"],
        "Small-Team Innovation": ["single screen", "one mechanic", "procedural", "minimal", "one mechanic depth"],
    }
    innovative = [name for name, indicators in innovation_indicators.items() if any(ind in design_lower for ind in indicators)]
    result["innovative_elements"] = innovative

    # Judgments
    if not innovative:
        result["judgment"] = "Common / Generic"
    elif len(innovative) == 1:
        result["judgment"] = "Minor Innovation"
    elif len(innovative) == 2:
        result["judgment"] = "Rule Innovation"
    elif len(innovative) == 3:
        result["judgment"] = "Player Behavior Innovation"
    else:
        result["judgment"] = "Emotional Experience Innovation"

    # How to improve
    improvements = []
    if not innovative:
        improvements.append("Apply at least one Innovation Method: try Inversion (reverse a genre convention) or Constraint as Mechanic (turn a limitation into gameplay).")
    if common == conv.get("common_mechanics", []):
        improvements.append(f"All standard {genre} mechanics present. Remove or modify at least one.")
    improvements.append("Consider: what if the player is NOT the standard protagonist?")
    improvements.append("Apply Emotion-First Design: pick ONE emotion and design everything to serve it.")
    improvements.append("Ensure every system has a clear player action, rule change, and feedback loop.")
    result["how_to_improve"] = improvements

    # Indie feasibility tips
    result["indie_feasibility_tips"] = [
        "Cut any system that requires more than 1 person-week to prototype",
        "Replace complex UI with diegetic feedback",
        "Use procedural/systemic over hand-crafted content",
        "One memorable mechanic > ten forgettable ones",
        "Design for a single-screen prototype first",
    ]

    # Score
    base = 3 + len(innovative) - len(reskin)
    scores = {
        "originality": min(10, max(1, base + 1)),
        "gameplay_impact": min(10, max(1, base)),
        "indie_feasibility": min(10, max(1, 8 - len(common))),
        "market_differentiation": min(10, max(1, base + 1)),
        "overall": round(min(10, max(1, base * 1.2 + 1)), 1),
        "risk_level": "Low" if base >= 5 else "Medium" if base >= 3 else "High",
    }
    result["innovation_score"] = scores

    return result


# ============================================================
# CLI ENTRY
# ============================================================

def main():
    if len(sys.argv) < 2:
        print(json.dumps({
            "usage": "python3 innovation_engine.py <command> [args...]",
            "commands": {
                "generate <genre> <theme> [emotion] [platform] [team_size] [engine]": "Generate innovative designs",
                "review <genre> <theme> <design_file>": "Review existing design innovation level",
                "output <mode> <genre> <theme> [...]": "Generate with specific output mode",
            },
            "output_modes": list(OUTPUT_MODES.keys()),
        }, indent=2))
        return

    cmd = sys.argv[1]

    if cmd in ("generate", "output"):
        mode = "json"
        args_start = 2
        if cmd == "output" and len(sys.argv) > 2:
            mode = sys.argv[2]
            args_start = 3

        if len(sys.argv) < args_start + 2:
            print("Error: requires genre and theme")
            sys.exit(1)

        params = {
            "genre": sys.argv[args_start],
            "theme": sys.argv[args_start + 1],
            "target_emotion": sys.argv[args_start + 2] if len(sys.argv) > args_start + 2 else "wonder",
            "platform": sys.argv[args_start + 3] if len(sys.argv) > args_start + 3 else "PC",
            "team_size": sys.argv[args_start + 4] if len(sys.argv) > args_start + 4 else "1-3",
            "engine": sys.argv[args_start + 5] if len(sys.argv) > args_start + 5 else "Unity",
        }
        result = generate_innovative_design(params)
        print(format_output(result, mode))

    elif cmd == "review":
        if len(sys.argv) < 5:
            print("Error: review requires genre, theme, and design file")
            sys.exit(1)
        params = {"genre": sys.argv[2], "theme": sys.argv[3], "design_description": ""}
        with open(sys.argv[4], 'r', encoding='utf-8') as f:
            params["design_description"] = f.read()
        result = review_innovation_level(params)
        print(json.dumps(result, indent=2, ensure_ascii=False))

    else:
        print(f"Unknown command: {cmd}")
        sys.exit(1)


if __name__ == "__main__":
    main()
