#!/usr/bin/env python3
"""
Game-Design-Pro - Design Reviewer

Reviews game design documents for completeness, consistency, risks,
and optimization suggestions using rule-based analysis.

Security: This module runs entirely locally. No network requests.
No external API calls. No data leaves the machine.
"""

import os
import sys
import json
from typing import Dict, Any, List
from datetime import datetime


class GameDesignReviewer:
    """Rule-based game design reviewer."""

    def __init__(self):
        self.issues = []
        self.suggestions = []
        self.scores = {}

    def review(self, content: str, doc_type: str = 'system') -> Dict[str, Any]:
        """Review a design document."""
        self.issues = []
        self.suggestions = []
        self.scores = {}

        content_lower = content.lower()

        # Check sections completeness
        self._check_completeness(content, doc_type)

        # Check for vague language
        self._check_vague_language(content, content_lower)

        # Check for missing mechanics
        self._check_mechanics(content, content_lower, doc_type)

        # Check for missing progression
        self._check_progression(content, content_lower)

        # Check for missing risk analysis
        self._check_risks(content, content_lower)

        # Check for indie feasibility
        self._check_indie_feasibility(content, content_lower)

        # Check word count
        word_count = len(content.split())
        self._check_length(word_count, doc_type)

        # Calculate overall score
        self._calculate_score()

        return {
            'timestamp': datetime.now().isoformat(),
            'doc_type': doc_type,
            'word_count': word_count,
            'completeness': self.scores.get('completeness', 0),
            'clarity': self.scores.get('clarity', 0),
            'feasibility': self.scores.get('feasibility', 0),
            'risk_awareness': self.scores.get('risk_awareness', 0),
            'overall_score': self.scores.get('overall', 0),
            'issues': self.issues,
            'suggestions': self.suggestions,
        }

    def _check_completeness(self, content: str, doc_type: str):
        """Check if required sections are present."""
        required_sections = {
            'system': ['mechanics', 'rules', 'feedback', 'progression'],
            'worldview': ['setting', 'lore', 'rules', 'tone'],
            'level': ['layout', 'flow', 'encounters', 'rewards'],
            'numeric': ['formula', 'curve', 'balance', 'table'],
            'story': ['arc', 'characters', 'pacing', 'ending'],
        }

        sections = required_sections.get(doc_type, required_sections['system'])
        found = sum(1 for s in sections if s.lower() in content.lower())
        self.scores['completeness'] = round(found / len(sections) * 10, 1) if sections else 0

        missing = [s for s in sections if s.lower() not in content.lower()]
        for s in missing:
            self.issues.append({
                'type': 'missing_section',
                'severity': 'warning',
                'message': f'Missing section: {s}',
                'suggestion': f'Add a section covering {s} for a complete design document.',
            })

    def _check_vague_language(self, content: str, content_lower: str):
        """Check for vague AI-style language."""
        vague_terms = ['unique and immersive', 'fresh experience', 'special system',
                       'stand out', 'captivating', 'immersive gameplay']
        vague_count = sum(1 for t in vague_terms if t in content_lower)

        if vague_count >= 2:
            self.scores['clarity'] = 5.0
            self.issues.append({
                'type': 'vague_language',
                'severity': 'warning',
                'message': f'Found {vague_count} vague expressions',
                'suggestion': 'Replace vague terms with concrete mechanics, rules, and player actions.',
            })
        else:
            self.scores['clarity'] = 8.0

    def _check_mechanics(self, content: str, content_lower: str, doc_type: str):
        """Check if core mechanics are described concretely."""
        mechanic_indicators = ['player can', 'when the player', 'press', 'click', 'select',
                               'input', 'action', 'verb', 'does', 'performs']
        has_mechanics = any(ind in content_lower for ind in mechanic_indicators)

        if not has_mechanics:
            self.scores['feasibility'] = 4.0
            self.issues.append({
                'type': 'missing_mechanics',
                'severity': 'warning',
                'message': 'No concrete player actions described',
                'suggestion': 'Specify what the player actually does: inputs, actions, and feedback.',
            })
        else:
            self.scores['feasibility'] = 8.0

    def _check_progression(self, content: str, content_lower: str):
        """Check if progression is addressed."""
        progression_terms = ['progress', 'unlock', 'advance', 'grow', 'level',
                             'early', 'mid', 'late', 'early game', 'end game']
        has_progression = any(t in content_lower for t in progression_terms)

        if not has_progression:
            self.suggestions.append({
                'type': 'missing_progression',
                'message': 'No progression system mentioned',
                'suggestion': 'Describe how the player advances over time. Even a simple unlock system helps.',
            })

    def _check_risks(self, content: str, content_lower: str):
        """Check if risks are addressed."""
        risk_terms = ['risk', 'challenge', 'problem', 'concern', 'trade-off',
                      'limitation', 'constraint', 'difficult', 'issue']
        has_risks = any(t in content_lower for t in risk_terms)

        if not has_risks:
            self.scores['risk_awareness'] = 3.0
            self.suggestions.append({
                'type': 'missing_risks',
                'message': 'No risks or challenges identified',
                'suggestion': 'Every design has risks. Identify at least 2-3 and how to mitigate them.',
            })
        else:
            self.scores['risk_awareness'] = 8.0

    def _check_indie_feasibility(self, content: str, content_lower: str):
        """Check if the design is realistic for indie teams."""
        red_flags = ['open world', 'mmo', 'multiplayer', 'hundreds of levels',
                     'fully voiced', 'cinematic', 'AAA quality']
        flags_found = [f for f in red_flags if f in content_lower]

        if flags_found:
            self.scores['feasibility'] = min(self.scores.get('feasibility', 10), 5.0)
            self.issues.append({
                'type': 'scope_warning',
                'severity': 'info',
                'message': f'Design may exceed indie scope: {", ".join(flags_found)}',
                'suggestion': 'Consider scaling down or clearly marking post-launch stretch goals.',
            })

    def _check_length(self, word_count: int, doc_type: str):
        """Check document length."""
        if word_count < 200:
            self.suggestions.append({
                'type': 'too_short',
                'message': f'Document is only {word_count} words',
                'suggestion': 'Expand with concrete mechanics, rules, and examples.',
            })
        elif word_count > 10000:
            self.suggestions.append({
                'type': 'too_long',
                'message': f'Document is {word_count} words',
                'suggestion': 'Consider splitting into multiple focused documents.',
            })

    def _calculate_score(self):
        """Calculate overall score."""
        scores = [v for v in self.scores.values() if isinstance(v, (int, float))]
        if scores:
            self.scores['overall'] = round(sum(scores) / len(scores), 1)
        else:
            self.scores['overall'] = 5.0


def main():
    """CLI entry point."""
    if len(sys.argv) < 2:
        print(json.dumps({
            'usage': 'python3 reviewer.py <file> [doc_type]',
            'doc_types': ['system', 'worldview', 'level', 'numeric', 'story'],
        }, indent=2))
        return

    filepath = sys.argv[1]
    doc_type = sys.argv[2] if len(sys.argv) > 2 else 'system'

    if not os.path.exists(filepath):
        print(json.dumps({'error': f'File not found: {filepath}'}))
        sys.exit(1)

    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    reviewer = GameDesignReviewer()
    result = reviewer.review(content, doc_type)
    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()
