#!/usr/bin/env python3
"""
Professional Game Design Generator v2.3.0

Generates professional-grade, production-ready game design documents.
Modes: Professional, Innovation, Production-Ready, Templates.

Security: No network, no shell commands, reads/writes only within skill directory.
"""

import os
import sys
import json
from datetime import datetime

# Output directory
OUTPUT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data', 'professional')
os.makedirs(OUTPUT_DIR, exist_ok=True)


# ============================================================
# PROFESSIONAL MODE - Structured GDD Output
# ============================================================

PROFESSIONAL_SECTIONS = [
    "Design Objective",
    "Target Player Experience",
    "Core Gameplay Loop",
    "Key Mechanics",
    "System Rules",
    "Player Interaction Flow",
    "Progression Design",
    "Reward Structure",
    "UI / UX Requirements",
    "Art Direction Requirements",
    "Audio Requirements",
    "Technical Implementation Notes",
    "Balance Considerations",
    "Edge Cases",
    "Risks and Limitations",
    "MVP Version",
    "Full Version Expansion"
]


def generate_professional_prompt(topic, genre=None, details=None):
    """Generate a professional mode prompt for LLM consumption."""
    genre_line = f"Genre: {genre}" if genre else ""
    details_line = f"Additional requirements: {details}" if details else ""

    sections_list = "\n".join(f"- {s}" for s in PROFESSIONAL_SECTIONS)

    return f"""You are a senior game design director with 10+ years of commercial and indie game experience. Write a professional game design document section.

Topic: {topic}
{genre_line}
{details_line}

Output Requirements:
1. Use the following section structure (skip sections that are not relevant, but include most):

{sections_list}

2. Writing Standards:
- Use professional but clear English
- Avoid empty words ("unique", "interesting", "immersive") unless followed by concrete explanation
- Every system must describe: how the player interacts, how the system responds, what value it adds to the experience
- Output must be directly copyable into a GDD or technical design document
- Use tables, bullet lists, and numbered steps where appropriate
- Include specific numbers, formulas, or thresholds where relevant

3. Quality Rules:
- Clear heading hierarchy (## for sections, ### for subsections)
- Actual gameplay rules, not vague descriptions
- Player experience goals stated explicitly
- Development implementation suggestions included
- MVP simplification provided
- Risk analysis included
- Cuttable features listed
- No AI filler tone
- Prioritize indie-scale development over AAA scope

4. If information is insufficient, add an Assumptions section at the top and proceed with reasonable assumptions.

Output in Markdown format."""


# ============================================================
# INNOVATION MODE
# ============================================================

INNOVATION_DIMENSIONS = [
    "Mechanic Innovation",
    "System Innovation",
    "Narrative-System Integration",
    "Player Emotion Innovation",
    "Visual-Gameplay Connection",
    "Indie Feasibility",
    "Market Differentiation"
]


def generate_innovation_prompt(topic, genre=None, details=None):
    """Generate an innovation mode prompt."""
    dims = "\n".join(f"### {i+1}. {d}" for i, d in enumerate(INNOVATION_DIMENSIONS))

    return f"""You are a game design innovator specializing in indie game innovation. Generate a truly differentiated game design concept.

Topic: {topic}
{"Genre: " + genre if genre else ""}
{"Details: " + details if details else ""}

Analyze the design through these innovation dimensions:

{dims}

For each dimension, answer:
- What is the innovative angle?
- How does it work in actual gameplay (specific rules, player actions)?
- What player experience does it create?

Output must include:
- Original Idea (clear, specific concept)
- Why It Is Innovative (what existing games do NOT do)
- How It Works In Gameplay (specific mechanics, rules, feedback loops)
- Player Experience Value (what the player feels and why it matters)
- Development Difficulty (scale 1-10 with reasoning)
- MVP Implementation (what to build first, what to cut)
- Possible Risks (what could fail and how to mitigate)
- How To Make It More Unique (suggestions to push it further)

Writing Standards:
- Do NOT stack concepts without explaining mechanics
- Every innovation point must include: specific gameplay rules, player behavior description, and implementation approach
- Avoid "what if" vagueness - give concrete examples
- Prioritize ideas that a 1-3 person team can actually build

Output in Markdown format."""


# ============================================================
# PRODUCTION-READY MODE
# ============================================================

PRODUCTION_SECTIONS = {
    "unity_systems": "Required Unity Systems",
    "csharp_scripts": "Required C# Scripts",
    "variables": "Important Variables",
    "data_structure": "Data Structure",
    "ui_screens": "UI Screens",
    "art_assets": "Art Assets",
    "animation": "Animation Requirements",
    "audio": "Audio Requirements",
    "testing": "Testing Checklist",
    "priority": "Development Priority",
    "difficulty": "Estimated Difficulty",
    "cuttable": "Cuttable Features",
    "mvp_scope": "MVP Scope",
    "full_scope": "Full Version Scope"
}


def generate_production_prompt(topic, genre=None, details=None):
    """Generate a production-ready mode prompt."""
    sections = "\n".join(f"- {v}" for v in PRODUCTION_SECTIONS.values())

    return f"""You are a technical game designer who creates production-ready design documents that can be directly handed to programmers, artists, UI designers, and audio engineers.

Topic: {topic}
{"Genre: " + genre if genre else ""}
{"Details: " + details if details else ""}

After the design description, generate a production specification with these sections:

{sections}

For each section:
- Be specific. Name actual Unity systems, actual C# script names, actual variable names and types.
- Include data structures as tables or code-like blocks.
- List art assets by type, count, and priority (MVP / Post-MVP).
- Provide a testing checklist with specific test cases.
- Give a development priority with phases (Phase 1, Phase 2, etc.).
- Identify which features can be cut if the team runs out of time.

Writing Standards:
- Script names should follow C# PascalCase convention (e.g., NPCRelationshipManager.cs)
- Variables should specify type (int, float, bool, enum, etc.)
- Art assets should specify type (Sprite, 3D Model, Animation, VFX, etc.)
- UI screens should describe layout and key elements
- Audio should specify type (BGM, SFX, Ambient, UI Sound)

Output in Markdown format."""


# ============================================================
# PROFESSIONAL REVIEW SCORE
# ============================================================

def generate_review_prompt(content):
    """Generate a professional review prompt."""
    return f"""You are a senior game design reviewer. Review the following game design document and provide a professional assessment.

Design Content:
{content[:4000]}

Provide scores and analysis:

## Review Scores

| Metric | Score (/10) | Notes |
|--------|-------------|-------|
| Innovation Potential | /10 | |
| Gameplay Clarity | /10 | |
| Indie Feasibility | /10 | |
| Production Readiness | /10 | |
| Market Differentiation | /10 | |
| Risk Level | Low/Medium/High | |

## Analysis

### Strongest Part
What works best in this design and why.

### Weakest Part
What needs the most improvement and why.

### Recommended Improvement
Top 3 specific, actionable improvements.

### What To Cut For MVP
Features that should be deferred to post-launch for indie development.

### What To Expand For Full Version
Areas that have strong potential and deserve more detail in the final product.

Writing Standards:
- Be specific and constructive
- Reference actual parts of the design
- Provide concrete suggestions, not vague criticism
- Consider indie team constraints (1-5 people, limited budget)

Output in Markdown format."""


# ============================================================
# PROFESSIONAL TEMPLATES
# ============================================================

TEMPLATES = {
    "full_gdd": {
        "name": "Full GDD Template",
        "sections": [
            ("# Game Design Document", "Complete game design document."),
            ("## 1. Game Overview", "Title, genre,platform,target audience,elevator pitch,USP"),
            ("## 2. Core Gameplay", "Core loop,primary mechanics,controls,game flow"),
            ("## 3. Game World", "Setting,level design,exploration,narrative structure"),
            ("## 4. Characters & NPCs", "Player characters,NPCs,enemies,relationships"),
            ("## 5. Systems", "Progression,economy,combat,puzzles,crafting,social"),
            ("## 6. UI/UX", "HUD,menus,controls,accessibility"),
            ("## 7. Art Direction", "Visual style,concept art references,animation style"),
            ("## 8. Audio", "Music style,sound effects,voice over,ambient"),
            ("## 9. Technical", "Engine,platforms,performance targets,networking"),
            ("## 10. Production", "Team roles,milestones,risk assessment,MVP scope"),
        ]
    },
    "system_design": {
        "name": "System Design Document Template",
        "sections": [
            ("# System Design: [System Name]", "Detailed system specification."),
            ("## Overview", "Purpose,scope,related systems"),
            ("## Core Mechanics", "Rules,formulas,conditions,triggers"),
            ("## Player Interaction", "Input methods,feedback loops,state changes"),
            ("## Data Model", "Data structures,save format,configuration"),
            ("## UI Requirements", "Screens,elements,transitions"),
            ("## Technical Implementation", "Unity components,script architecture,events"),
            ("## Balance", "Tuning parameters,progression curves,difficulty scaling"),
            ("## Edge Cases", "Error handling,exploit prevention,recovery"),
            ("## MVP vs Full", "Minimum viable version,post-launch additions"),
            ("## Testing", "Test cases,metrics,debug tools"),
        ]
    },
    "technical_design": {
        "name": "Technical Design Document Template",
        "sections": [
            ("# Technical Design: [Feature Name]", "Technical specification for developers."),
            ("## Architecture", "System diagram,component relationships,data flow"),
            ("## Required Scripts", "C# script names,responsibilities,dependencies"),
            ("## Data Structures", "Classes,ScriptableObjects,JSON schemas"),
            ("## Events & Signals", "Event definitions,subscribers,publisher patterns"),
            ("## Performance", "Optimization targets,memory budget,object pooling"),
            ("## Integration Points", "APIs,external systems,third-party SDKs"),
            ("## Configuration", "Tunable parameters,difficulty settings,balance tables"),
            ("## Error Handling", "Fallback behavior,crash recovery,logging"),
            ("## Testing Strategy", "Unit tests,integration tests,automated testing"),
            ("## Implementation Timeline", "Phases,dependencies,risk mitigation"),
        ]
    },
    "level_design": {
        "name": "Level Design Document Template",
        "sections": [
            ("# Level Design: [Level Name]", "Level specification."),
            ("## Level Overview", "Purpose,difficulty,estimated playtime,theme"),
            ("## Layout", "Map description,key areas,flow,pacing"),
            ("## Encounters", "Enemy placement,combat scenarios,puzzles"),
            ("## Progression", "Gating,unlock conditions,rewards"),
            ("## Visual Landmarks", "Key art points,waypoints,atmosphere"),
            ("## Audio Design", "BGM,ambient sounds,cues"),
            ("## Technical Notes", "Performance budget,lighting,occlusion,streaming"),
            ("## Playtesting Goals", "What to test,success metrics,common issues"),
        ]
    },
    "character_design": {
        "name": "Character Design Brief Template",
        "sections": [
            ("# Character Design: [Character Name]", "Character specification."),
            ("## Concept", "Role,archetype,personality,backstory"),
            ("## Visual Design", "Appearance,color palette,costume,expression range"),
            ("## Abilities", "Skills,stats,growth curve,unlocks"),
            ("## Animation Requirements", "Idle,walk,run,attack,hit,death,emotes"),
            ("## Voice & Audio", "Voice type,catchphrases,SFX"),
            ("## AI Behavior", "Patrol patterns,combat AI,dialogue triggers"),
            ("## Technical Specs", "Polygon budget,bone count,texture size"),
        ]
    },
    "worldbuilding": {
        "name": "Worldbuilding Bible Template",
        "sections": [
            ("# Worldbuilding Bible: [World Name]", "Complete world reference."),
            ("## Geography", "Regions,climate,landmarks,travel"),
            ("## History & Lore", "Timeline,key events,myths,factions"),
            ("## Factions & Politics", "Organizations,relationships,power structure"),
            ("## Culture & Society", "Customs,economy,technology level,daily life"),
            ("## Magic & Technology", "Rules,limitations,costs,sources"),
            ("## Flora & Fauna", "Creatures,plants,ecosystem,threats"),
            ("## Gameplay Impact", "How worldbuilding affects mechanics,narrative,exploration"),
        ]
    },
    "art_requirements": {
        "name": "Art Requirement Document Template",
        "sections": [
            ("# Art Requirement Document", "Art production specification."),
            ("## Art Direction", "Overall style,references,mood,color palette"),
            ("## Character Art", "Models/sprites,animations,textures,VFX"),
            ("## Environment Art", "Tiles,props,lighting,skybox,weather"),
            ("## UI Art", "Icons,buttons,panels,transitions,typography"),
            ("## VFX", "Particle systems,shaders,screen effects"),
            ("## Asset List", "Complete list with count,type,priority,status"),
            ("## Technical Constraints", "Resolution limits,poly budgets,texture sizes,draw calls"),
            ("## Pipeline", "Tools,workflow,version control,review process"),
        ]
    },
    "ui_ux_flow": {
        "name": "UI/UX Flow Document Template",
        "sections": [
            ("# UI/UX Flow Document", "User interface specification."),
            ("## Design Principles", "UX goals,accessibility,consistency rules"),
            ("## Screen Map", "All screens and their connections"),
            ("## HUD Layout", "In-game UI elements,positioning,priority"),
            ("## Menu Structure", "Main menu,settings,inventory,skill tree,etc."),
            ("## Input Mapping", "Keyboard,mouse,controller,touch"),
            ("## Feedback Systems", "Visual,audio,haptic feedback for player actions"),
            ("## Wireframes", "Key screen layouts (text descriptions)"),
            ("## Animation Specs", "Transition types,duration,easing"),
            ("## Accessibility", "Color blind support,text size,control remapping"),
        ]
    },
    "mvp_roadmap": {
        "name": "Indie MVP Roadmap Template",
        "sections": [
            ("# Indie MVP Roadmap", "Minimum viable product development plan."),
            ("## Vision", "Core experience,USP,target audience,scope boundaries"),
            ("## MVP Core (Weeks 1-4)", "Absolute minimum to prove the game is fun"),
            ("## MVP Extended (Weeks 5-8)", "Core loop complete,first playable"),
            ("## Demo (Weeks 9-12)", "Polished vertical slice for sharing"),
            ("## Early Access (Weeks 13-20)", "Content expansion,balance,bug fixes"),
            ("## Launch (Weeks 21-24)", "Polish,marketing assets,store pages"),
            ("## Risk Mitigation", "What could go wrong,plan B,scope reduction triggers"),
            ("## Team Allocation", "Who does what,parallel work streams"),
        ]
    },
    "pitch_design": {
        "name": "Publisher Pitch Design Summary Template",
        "sections": [
            ("# Publisher Pitch: [Game Title]", "One-page pitch document."),
            ("## Elevator Pitch", "One sentence: what is this game?"),
            ("## Key Selling Points", "3-5 unique features that make this game stand out"),
            ("## Target Market", "Audience,platform,price point,comparable titles"),
            ("## Core Loop Diagram", "Text description of the core gameplay loop"),
            ("## Art Style", "Visual direction with reference descriptions"),
            ("## Development Status", "Current progress,timeline to launch,team size"),
            ("## Funding Needs", "Budget range,what the funding covers,expected ROI"),
            ("## Why This Team", "Relevant experience,previous work,unique capability"),
        ]
    },
}


def get_template_content(template_key):
    """Generate a professional template document."""
    if template_key not in TEMPLATES:
        return json.dumps({
            'error': f'Unknown template: {template_key}',
            'available': list(TEMPLATES.keys())
        })

    tmpl = TEMPLATES[template_key]
    lines = []
    lines.append(f"# {tmpl['name']}")
    lines.append("")
    lines.append("> Generated by Arshis-Game-Design-Pro v2.3.0")
    lines.append(f"> Date: {datetime.now().strftime('%Y-%m-%d')}")
    lines.append("")

    for heading, desc in tmpl["sections"]:
        lines.append(heading)
        lines.append("")
        lines.append(f"*{desc}*")
        lines.append("")
        lines.append("---")
        lines.append("")

    lines.append("")
    lines.append("*Fill in each section with your game-specific content.*")
    lines.append("*Each section should contain concrete details, not placeholder text.*")

    return "\n".join(lines)


# ============================================================
# COMBINED PROFESSIONAL OUTPUT (Full doc with all modes)
# ============================================================

def generate_combined_prompt(topic, genre=None, details=None, modes=None):
    """Generate a combined prompt for multiple modes."""
    if modes is None:
        modes = ["professional"]

    parts = []

    if "professional" in modes:
        parts.append(generate_professional_prompt(topic, genre, details))

    if "innovation" in modes:
        parts.append("\n---\n\nADDITIONALLY, analyze this design through the Innovation Framework:\n")
        dims = "\n".join(f"- {d}" for d in INNOVATION_DIMENSIONS)
        parts.append(f"Evaluate each dimension:\n{dims}")
        parts.append("\nFor each: what makes it innovative, how it works in gameplay, MVP feasibility.")

    if "production" in modes:
        parts.append("\n---\n\nPRODUCTION SPECIFICATION:\n")
        parts.append(generate_production_prompt(topic, genre, details))

    if "review" in modes:
        parts.append("\n---\n\nREVIEW SCORE:\n")
        parts.append(generate_review_prompt(f"Topic: {topic}\n{details or ''}"))

    return "\n\n".join(parts)


# ============================================================
# CLI ENTRY
# ============================================================

def main():
    if len(sys.argv) < 2:
        print(json.dumps({
            "usage": "python3 professional_generator.py <command> [args...]",
            "commands": {
                "prompt-professional <topic> [genre] [details]": "Generate professional mode prompt",
                "prompt-innovation <topic> [genre] [details]": "Generate innovation mode prompt",
                "prompt-production <topic> [genre] [details]": "Generate production-ready prompt",
                "prompt-review <content_file>": "Generate review prompt from content file",
                "prompt-combined <topic> [genre] [details] [--modes prof,innov,prod,review]": "Combined modes",
                "template <template_key>": "Get a professional template",
                "list-templates": "List all available templates",
            },
            "templates": list(TEMPLATES.keys()),
        }, indent=2))
        return

    cmd = sys.argv[1]

    if cmd == "prompt-professional":
        topic = sys.argv[2] if len(sys.argv) > 2 else ""
        genre = sys.argv[3] if len(sys.argv) > 3 else None
        details = sys.argv[4] if len(sys.argv) > 4 else None
        print(generate_professional_prompt(topic, genre, details))

    elif cmd == "prompt-innovation":
        topic = sys.argv[2] if len(sys.argv) > 2 else ""
        genre = sys.argv[3] if len(sys.argv) > 3 else None
        details = sys.argv[4] if len(sys.argv) > 4 else None
        print(generate_innovation_prompt(topic, genre, details))

    elif cmd == "prompt-production":
        topic = sys.argv[2] if len(sys.argv) > 2 else ""
        genre = sys.argv[3] if len(sys.argv) > 3 else None
        details = sys.argv[4] if len(sys.argv) > 4 else None
        print(generate_production_prompt(topic, genre, details))

    elif cmd == "prompt-review":
        if len(sys.argv) < 3:
            print("Error: prompt-review requires content file")
            sys.exit(1)
        with open(sys.argv[2], 'r', encoding='utf-8') as f:
            content = f.read()
        print(generate_review_prompt(content))

    elif cmd == "prompt-combined":
        topic = sys.argv[2] if len(sys.argv) > 2 else ""
        genre = sys.argv[3] if len(sys.argv) > 3 else None
        details = sys.argv[4] if len(sys.argv) > 4 else None
        modes_str = None
        for arg in sys.argv[5:]:
            if arg.startswith("--modes="):
                modes_str = arg.split("=", 1)[1]
        modes = modes_str.split(",") if modes_str else ["professional"]
        print(generate_combined_prompt(topic, genre, details, modes))

    elif cmd == "template":
        if len(sys.argv) < 3:
            print("Error: template requires template_key")
            print(f"Available: {', '.join(TEMPLATES.keys())}")
            sys.exit(1)
        print(get_template_content(sys.argv[2]))

    elif cmd == "list-templates":
        print(json.dumps({
            "templates": {k: v["name"] for k, v in TEMPLATES.items()}
        }, indent=2))

    else:
        print(f"Unknown command: {cmd}")
        sys.exit(1)


if __name__ == "__main__":
    main()
