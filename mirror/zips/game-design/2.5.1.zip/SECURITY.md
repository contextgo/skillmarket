# Security Policy

## Supported Versions

| Version | Supported |
|---------|-----------|
| 2.1.x   |  Yes    |
| 2.0.x   |  Yes    |
| < 2.0   |  No     |

## Security Model

### File Access
- **Reads**: Only its own script files within the skill directory
- **Writes**: Only to the `data/` subdirectory within the skill directory
- **Does NOT read**: User files, system directories, or any path outside the skill

### Child Process
This skill uses Node.js `child_process.spawn()` to run local Python scripts:
- Only spawns scripts from the skill's own `scripts/` directory (hardcoded paths)
- User input is passed as arguments, never interpolated into shell commands
- No `exec()`, `eval()`, or shell string concatenation
- Temporary files use `.temp_*.md` naming and are cleaned up after use

### Network
- No module makes outbound network requests.
- API key is read from `SILICONFLOW_API_KEY` environment variable
- No other network activity
- No data collection or telemetry

### Input Handling
- All user-provided content is passed to Python scripts as arguments or temporary files
- No shell escaping needed — input is never executed as commands
- No access to user files outside the skill directory

## Reporting a Vulnerability

Report via GitHub Issues: https://github.com/TaylliSun/Arshis-Game-Design-Pro/issues

## Known Limitations

- The `review_design` feature sends document content to SiliconFlow API
- If you do not want external data transmission, do not set `SILICONFLOW_API_KEY`

