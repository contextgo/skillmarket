# ClawHub Publish Description

## Short Description (for listing)
Professional game design workflow assistant for indie developers. Generate GDDs, review designs, plan Unity specs, and explore innovative concepts — all offline, no API key required.

## Full Description (for detail page)

Arshis-Game-Design-Pro helps indie developers and small teams go from game idea to production-ready design documents.

### Core Capabilities

**Game Design Documents** — Generate structured GDDs with clear sections, not walls of text. Professional 17-section format covering mechanics, systems, progression, UI, art direction, audio, technical implementation, and risk analysis.

**Innovation Engine** — Explore differentiated game concepts through a structured pipeline: genre convention analysis → 10 innovation breakpoints → 5 concept types (Safe/Moderate/High/Experimental/Indie) → novelty filter → 6-metric scoring → MVP planning. Each concept includes specific player actions, rule changes, and Unity prototype plans.

**Technical Planning** — Convert design ideas into Unity-ready specifications: C# script names, variable tables, data structures, event systems, UI requirements, art/audio asset lists, and development phases with timeline.

**Design Review** — Check existing designs for completeness, consistency, and innovation level. Get specific improvement suggestions, not generic feedback.

**10 Professional Templates** — Full GDD, System Design, Technical Design, Level Design, Character Design, Worldbuilding Bible, Art Requirements, UI/UX Flow, MVP Roadmap, Publisher Pitch.

### Key Features

- 25 genre conventions database with innovation breakpoints
- Novelty Filter: 6-level judgment from Common to Emotional Experience Innovation
- Auto-rewrite for concepts flagged as reskin
- 6 output modes: json, markdown, gdd, obsidian, technical_plan, publisher_pitch
- Indie-first: all designs consider 1-5 person teams, Unity-friendly implementation

### Privacy & Security

- No outbound network requests
- No data collection or upload
- No API keys required
- All outputs remain local

### What This Is NOT

- Not a memory plugin
- Not a replacement for professional game designers
- Not a game engine or code generator

### Requirements

- OpenClaw 2026.4.0+
- Python 3.9+

---
*Arshis-Game-Design-Pro v2.4.3*
*MIT License*
