/**
 * Arshis-Game-Design-Pro - OpenClaw Plugin
 * 
 * Commercial-grade game design tool for generating, reviewing, and organizing
 * game design documents (GDDs), worldbuilding, gameplay systems, numeric balance,
 * level design, UI/UX suggestions, technical design, and art/engineering requirements.
 * 
 * @version 2.1.0
 * @author TaylliSun (Arshis)
 * @license MIT
 */

import { spawn } from 'child_process';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Script paths - only fixed, local paths (no user input)
const SCRIPTS_DIR = path.join(__dirname, 'scripts');
const GENERATOR = path.join(SCRIPTS_DIR, 'generator.py');
const REVIEWER = path.join(SCRIPTS_DIR, 'reviewer.py');
const WORLDVIEW = path.join(SCRIPTS_DIR, 'worldview_manager.py');
const VERSION_MANAGER = path.join(SCRIPTS_DIR, 'version_manager.py');
const TEMPLATES = path.join(SCRIPTS_DIR, 'templates.py');
const CONSISTENCY_CHECKER = path.join(SCRIPTS_DIR, 'consistency_checker.py');
const WORKFLOW = path.join(SCRIPTS_DIR, 'workflow_assistant.py');
const PROFESSIONAL = path.join(SCRIPTS_DIR, 'professional_generator.py');
const INNOVATION = path.join(SCRIPTS_DIR, 'innovation_engine.py');

/**
 * Execute a Python script safely.
 * 
 * Security: Only spawns fixed, local script paths. User input is passed
 * as arguments but never interpolated into shell commands. The spawned
 * process is limited to the project's own scripts directory.
 * 
 * @param {string} script - Absolute path to a Python script within this skill
 * @param {string[]} args - Array of string arguments
 * @returns {Promise<object>} Parsed JSON output or raw stdout
 */
function runPythonScript(script, args = []) {
  return new Promise((resolve, reject) => {
    const proc = spawn('python3', [script, ...args]);
    let stdout = '';
    let stderr = '';

    proc.stdout.on('data', (data) => { stdout += data.toString(); });
    proc.stderr.on('data', (data) => { stderr += data.toString(); });

    proc.on('close', (code) => {
      if (code === 0) {
        try {
          resolve(JSON.parse(stdout));
        } catch {
          resolve({ output: stdout.trim() });
        }
      } else {
        reject(new Error(`Script exited with code ${code}: ${stderr.trim()}`));
      }
    });

    proc.on('error', (err) => {
      reject(new Error(`Failed to spawn process: ${err.message}`));
    });
  });
}

/**
 * Build a design document generation prompt.
 */
function buildDesignPrompt(doc_type, topic, details, word_count) {
  const templates = {
    worldview: 'Worldview Design Document',
    system: 'System Design Document',
    numeric: 'Numeric Balance Document',
    level: 'Level Design Document',
    story: 'Narrative Design Document'
  };

  const label = templates[doc_type] || 'Game Design Document';

  return `You are a senior game design director with 10 years of commercial game experience.

Please write a complete "${label}" for the topic: ${topic}

Requirements:
1. Professional: Use commercial project standard format
2. Complete: Cover all necessary chapters
3. Detailed: At least ${word_count} words
4. Practical: Include configuration tables, formulas, flowcharts

Additional info: ${details || 'No special requirements'}

Output in Markdown format.`;
}

// ==================== Tool: generate_design ====================
// Generate a game design document (worldview/system/numeric/level/story)

export async function generate_design(args, context) {
  try {
    const { doc_type, topic, details = '', word_count = 5000 } = args;
    if (!doc_type || !topic) {
      return { error: 'doc_type and topic are required' };
    }
    const prompt = buildDesignPrompt(doc_type, topic, details, word_count);
    const result = await runPythonScript(GENERATOR, ['--llm-prompt', prompt]);
    return result;
  } catch (error) {
    return { error: error.message };
  }
}

// ==================== Tool: modify_design_section ====================
// Modify a specific chapter with version management

export async function modify_design_section(args, context) {
  try {
    const { version, section, content, change_log = '' } = args;
    if (!section || !content) {
      return { error: 'section and content are required' };
    }
    const fs = await import('fs');
    const tempFile = path.join(SCRIPTS_DIR, '.temp_section.md');
    fs.writeFileSync(tempFile, content, 'utf-8');
    const result = await runPythonScript(VERSION_MANAGER, [
      'modify', version || 'v1.0', section, tempFile
    ]);
    fs.unlinkSync(tempFile);
    return result;
  } catch (error) {
    return { error: error.message };
  }
}

// ==================== Tool: save_version ====================
// Save a design document version

export async function save_version(args, context) {
  try {
    const { content, version, change_log = '', project = 'default' } = args;
    if (!content || !version) {
      return { error: 'content and version are required' };
    }
    const fs = await import('fs');
    const tempFile = path.join(SCRIPTS_DIR, '.temp_design.md');
    fs.writeFileSync(tempFile, content, 'utf-8');
    const result = await runPythonScript(VERSION_MANAGER, [
      'save', version, tempFile
    ]);
    fs.unlinkSync(tempFile);
    return result;
  } catch (error) {
    return { error: error.message };
  }
}

// ==================== Tool: compare_versions ====================
// Compare two design document versions

export async function compare_versions(args, context) {
  try {
    const { version1, version2, project = 'default' } = args;
    if (!version1 || !version2) {
      return { error: 'version1 and version2 are required' };
    }
    return await runPythonScript(VERSION_MANAGER, ['compare', version1, version2]);
  } catch (error) {
    return { error: error.message };
  }
}

// ==================== Tool: list_versions ====================
// List all saved design document versions

export async function list_versions(args, context) {
  try {
    return await runPythonScript(VERSION_MANAGER, ['list']);
  } catch (error) {
    return { error: error.message };
  }
}

// ==================== Tool: get_template ====================
// Get a design document template by type

export async function get_template(args, context) {
  try {
    const { template_type } = args;
    if (!template_type) {
      return { error: 'template_type is required' };
    }
    return await runPythonScript(TEMPLATES, ['get', template_type]);
  } catch (error) {
    return { error: error.message };
  }
}

// ==================== Tool: list_templates ====================
// List all available design document templates

export async function list_templates(args, context) {
  try {
    return await runPythonScript(TEMPLATES, ['list']);
  } catch (error) {
    return { error: error.message };
  }
}

// ==================== Tool: generate_from_template ====================
// Generate a design document from a template with data filling

export async function generate_from_template(args, context) {
  try {
    const { template_type, fill_data = {} } = args;
    if (!template_type) {
      return { error: 'template_type is required' };
    }
    const cmdArgs = ['generate', template_type];
    if (Object.keys(fill_data).length > 0) {
      cmdArgs.push(JSON.stringify(fill_data));
    }
    return await runPythonScript(TEMPLATES, cmdArgs);
  } catch (error) {
    return { error: error.message };
  }
}

// ==================== Tool: check_consistency ====================
// Check content consistency (worldview/character/system conflicts)

export async function check_consistency(args, context) {
  try {
    const { content_type, content_data } = args;
    if (!content_type || !content_data) {
      return { error: 'content_type and content_data are required' };
    }
    const fs = await import('fs');
    const tempFile = path.join(SCRIPTS_DIR, '.temp_check.json');
    fs.writeFileSync(tempFile, JSON.stringify(content_data, null, 2), 'utf-8');
    const checkType = `check-${content_type}`;
    const result = await runPythonScript(CONSISTENCY_CHECKER, [checkType, tempFile]);
    fs.unlinkSync(tempFile);
    return result;
  } catch (error) {
    return { error: error.message };
  }
}

// ==================== Tool: review_design ====================
// Review a game design document for completeness, risks, and optimizations

export async function review_design(args, context) {
  try {
    const { content, doc_type = 'system' } = args;
    if (!content) {
      return { error: 'content is required' };
    }
    const fs = await import('fs');
    const tempFile = path.join(SCRIPTS_DIR, '.temp_review.md');
    fs.writeFileSync(tempFile, content, 'utf-8');
    const result = await runPythonScript(REVIEWER, [tempFile, doc_type]);
    fs.unlinkSync(tempFile);
    return result;
  } catch (error) {
    return { error: error.message };
  }
}

// ==================== Tool: store_worldview ====================
// Store worldview settings to memory (permanent)

export async function store_worldview(args, context) {
  try {
    const { category, content, importance = 0.9 } = args;
    if (!content) {
      return { error: 'content is required' };
    }
    return await runPythonScript(WORLDVIEW, [
      'store', category, content, importance.toString()
    ]);
  } catch (error) {
    return { error: error.message };
  }
}

// ==================== Tool: query_worldview ====================
// Query worldview settings by keyword

export async function query_worldview(args, context) {
  try {
    const { query, limit = 10 } = args;
    if (!query) {
      return { error: 'query is required' };
    }
    return await runPythonScript(WORLDVIEW, ['query', query, limit.toString()]);
  } catch (error) {
    return { error: error.message };
  }
}


// ==================== Tool: create_project_profile ====================
// Create a project profile from game concept parameters

export async function create_project_profile(args, context) {
  try {
    const {
      game_title, genre, platform, target_audience,
      core_loop, visual_style, engine, team_size,
      scope, reference_games
    } = args;

    if (!game_title || !genre) {
      return { error: 'game_title and genre are required' };
    }

    const refGames = Array.isArray(reference_games)
      ? reference_games.join(',')
      : String(reference_games || '');

    const result = await runPythonScript(WORKFLOW, [
      'profile-create',
      game_title,
      genre || '',
      platform || 'PC',
      target_audience || '',
      core_loop || '',
      visual_style || '',
      engine || 'Unity',
      team_size || '1-3',
      scope || 'small',
      refGames
    ]);
    return result;
  } catch (error) {
    return { error: error.message };
  }
}

// ==================== Tool: list_profiles ====================
// List all saved project profiles

export async function list_profiles(args, context) {
  try {
    return await runPythonScript(WORKFLOW, ['profile-list']);
  } catch (error) {
    return { error: error.message };
  }
}

// ==================== Tool: show_profile ====================
// Show a project profile (with optional obsidian export)

export async function show_profile(args, context) {
  try {
    const { filename, obsidian = false } = args;
    if (!filename) {
      return { error: 'filename is required' };
    }
    const cmdArgs = ['profile-show', filename];
    if (obsidian) cmdArgs.push('--obsidian');
    const result = await runPythonScript(WORKFLOW, cmdArgs);
    return result;
  } catch (error) {
    return { error: error.message };
  }
}

// ==================== Tool: gdd_to_tech ====================
// Convert a GDD description into a technical design document

export async function gdd_to_tech(args, context) {
  try {
    const { gdd_text, profile_file, obsidian = false } = args;
    if (!gdd_text) {
      return { error: 'gdd_text is required' };
    }
    const fs = await import('fs');
    const tempFile = path.join(SCRIPTS_DIR, '.temp_gdd.txt');
    fs.writeFileSync(tempFile, gdd_text, 'utf-8');

    const cmdArgs = ['tech-convert', profile_file || 'default', tempFile];
    if (obsidian) cmdArgs.push('--obsidian');

    const result = await runPythonScript(WORKFLOW, cmdArgs);
    fs.unlinkSync(tempFile);
    return result;
  } catch (error) {
    return { error: error.message };
  }
}

// ==================== Tool: consistency_review ====================
// Run a consistency check on a design document

export async function consistency_review(args, context) {
  try {
    const { design_json, profile_file, obsidian = false } = args;
    if (!design_json) {
      return { error: 'design_json (object) is required' };
    }
    const fs = await import('fs');
    const tempFile = path.join(SCRIPTS_DIR, '.temp_design_check.json');
    fs.writeFileSync(tempFile, JSON.stringify(design_json, null, 2), 'utf-8');

    const pf = profile_file || 'default';
    const cmdArgs = ['consistency-check', pf, tempFile];
    if (obsidian) cmdArgs.push('--obsidian');

    const result = await runPythonScript(WORKFLOW, cmdArgs);
    fs.unlinkSync(tempFile);
    return result;
  } catch (error) {
    return { error: error.message };
  }
}

// ==================== Tool: review_score ====================
// Score a design document on key metrics

export async function review_score(args, context) {
  try {
    const { design_text, profile_file, obsidian = false } = args;
    if (!design_text) {
      return { error: 'design_text is required' };
    }
    const fs = await import('fs');
    const tempFile = path.join(SCRIPTS_DIR, '.temp_design_score.txt');
    fs.writeFileSync(tempFile, design_text, 'utf-8');

    const cmdArgs = ['review-score', tempFile];
    if (profile_file) cmdArgs.push(profile_file);
    if (obsidian) cmdArgs.push('--obsidian');

    const result = await runPythonScript(WORKFLOW, cmdArgs);
    fs.unlinkSync(tempFile);
    return result;
  } catch (error) {
    return { error: error.message };
  }
}

// ==================== Tool: obsidian_export ====================
// Export a project profile as Obsidian-ready Markdown

export async function obsidian_export(args, context) {
  try {
    const { profile_file } = args;
    if (!profile_file) {
      return { error: 'profile_file is required' };
    }
    return await runPythonScript(WORKFLOW, ['obsidian-export', profile_file]);
  } catch (error) {
    return { error: error.message };
  }
}


// ==================== Tool: professional_design ====================
// Generate a professional-grade game design document section

export async function professional_design(args, context) {
  try {
    const { topic, genre = '', details = '', obsidian = false } = args;
    if (!topic) return { error: 'topic is required' };
    const result = await runPythonScript(PROFESSIONAL, [
      'prompt-professional', topic, genre, details
    ]);
    return result;
  } catch (error) {
    return { error: error.message };
  }
}

// ==================== Tool: innovation_design ====================
// Generate an innovative game design concept

export async function innovation_design(args, context) {
  try {
    const { topic, genre = '', details = '', obsidian = false } = args;
    if (!topic) return { error: 'topic is required' };
    const result = await runPythonScript(PROFESSIONAL, [
      'prompt-innovation', topic, genre, details
    ]);
    return result;
  } catch (error) {
    return { error: error.message };
  }
}

// ==================== Tool: production_spec ====================
// Generate a production-ready specification

export async function production_spec(args, context) {
  try {
    const { topic, genre = '', details = '', obsidian = false } = args;
    if (!topic) return { error: 'topic is required' };
    const result = await runPythonScript(PROFESSIONAL, [
      'prompt-production', topic, genre, details
    ]);
    return result;
  } catch (error) {
    return { error: error.message };
  }
}

// ==================== Tool: design_review ====================
// Generate a professional review of a design document

export async function design_review(args, context) {
  try {
    const { content } = args;
    if (!content) return { error: 'content is required' };
    const fs = await import('fs');
    const tempFile = path.join(SCRIPTS_DIR, '.temp_review_content.txt');
    fs.writeFileSync(tempFile, content, 'utf-8');
    const result = await runPythonScript(PROFESSIONAL, ['prompt-review', tempFile]);
    fs.unlinkSync(tempFile);
    return result;
  } catch (error) {
    return { error: error.message };
  }
}

// ==================== Tool: combined_design ====================
// Generate a combined design with multiple modes

export async function combined_design(args, context) {
  try {
    const { topic, genre = '', details = '', modes = 'professional' } = args;
    if (!topic) return { error: 'topic is required' };
    const result = await runPythonScript(PROFESSIONAL, [
      'prompt-combined', topic, genre, details, '--modes=' + modes
    ]);
    return result;
  } catch (error) {
    return { error: error.message };
  }
}

// ==================== Tool: get_template_doc ====================
// Get a professional template document

export async function get_template_doc(args, context) {
  try {
    const { template_key } = args;
    if (!template_key) return { error: 'template_key is required' };
    return await runPythonScript(PROFESSIONAL, ['template', template_key]);
  } catch (error) {
    return { error: error.message };
  }
}

// ==================== Tool: list_template_docs ====================
// List all available professional templates

export async function list_template_docs(args, context) {
  try {
    return await runPythonScript(PROFESSIONAL, ['list-templates']);
  } catch (error) {
    return { error: error.message };
  }
}


// ==================== Tool: generate_innovative_design ====================
// Generate innovative game design with full innovation pipeline

export async function generate_innovative_design(args, context) {
  try {
    const {
      genre, theme, target_emotion = 'wonder',
      platform = 'PC', team_size = '1-3',
      engine = 'Unity', reference_games = '', scope = 'small'
    } = args;
    if (!genre || !theme) {
      return { error: 'genre and theme are required' };
    }
    const result = await runPythonScript(INNOVATION, [
      'generate', genre, theme,
      target_emotion, platform, team_size, engine
    ]);
    return result;
  } catch (error) {
    return { error: error.message };
  }
}

// ==================== Tool: review_innovation_level ====================
// Review existing design for innovation level

export async function review_innovation_level(args, context) {
  try {
    const { genre, theme, design_content } = args;
    if (!genre || !design_content) {
      return { error: 'genre and design_content are required' };
    }
    const fs = await import('fs');
    const tempFile = path.join(SCRIPTS_DIR, '.temp_innovation_review.txt');
    fs.writeFileSync(tempFile, design_content, 'utf-8');
    const result = await runPythonScript(INNOVATION, [
      'review', genre, theme || '', tempFile
    ]);
    fs.unlinkSync(tempFile);
    return result;
  } catch (error) {
    return { error: error.message };
  }
}

// ==================== Tool Export ====================

export default {
  // Core design tools
  generate_design,
  modify_design_section,
  save_version,
  compare_versions,
  list_versions,
  get_template,
  list_templates,
  generate_from_template,
  check_consistency,
  review_design,
  store_worldview,
  query_worldview,
  // Workflow tools (v2.2.0)
  create_project_profile,
  list_profiles,
  show_profile,
  gdd_to_tech,
  consistency_review,
  review_score,
  obsidian_export,
  // Professional tools (v2.3.0)
  professional_design,
  innovation_design,
  production_spec,
  design_review,
  combined_design,
  get_template_doc,
  list_template_docs,
  // Innovation Engine (v2.4.0)
  generate_innovative_design,
  review_innovation_level,
};
