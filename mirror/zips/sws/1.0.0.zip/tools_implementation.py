#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
战国策虾配套工具集 - 主程序
Tools Implementation for 战国策虾

功能：
1. 原文库管理（导入、切片、查询、异文标注）
2. 版本标注管理（版本对照、异文处理）
3. 解读角度库管理（角度模板、自动匹配）
4. 古今关联库管理（关联映射、质量评估）
"""

import json
import os
import re
from pathlib import Path
from typing import Dict, List, Optional, Any
import argparse
from datetime import datetime

# ============================
# 配置部分
# ============================

class Config:
    """全局配置类"""
    # 路径配置
    BASE_DIR = Path("C:/Workbuddy/skills/国学经典")
    DATA_DIR = BASE_DIR / "data"
    ORIGINAL_DIR = DATA_DIR / "原文库"
    ANGLE_DIR = DATA_DIR / "角度库"
    CONNECTION_DIR = DATA_DIR / "关联库"
    VERSION_DIR = DATA_DIR / "版本对照"
    REPORTS_DIR = BASE_DIR / "reports"
    
    # 默认配置
    DEFAULT_VERSION = "中华书局三全本"
    BACKUP_VERSION = "上海古籍出版社标点本"
    SLICE_LENGTH_RANGE = (300, 800)
    
    # 数据库文件
    ORIGINAL_DB = ORIGINAL_DIR / "original_texts.json"
    ANGLE_DB = ANGLE_DIR / "angles.json"
    CONNECTION_DB = CONNECTION_DIR / "connections.json"
    VERSION_DB = VERSION_DIR / "versions.json"
    VARIANTS_DB = VERSION_DIR / "variants.json"

# ============================
# 工具1：原文库管理
# ============================

class OriginalTextManager:
    """原文库管理类"""
    
    def __init__(self):
        self.db_path = Config.ORIGINAL_DB
        self.data = self._load_db()
    
    def _load_db(self) -> Dict:
        """加载数据库"""
        if self.db_path.exists():
            with open(self.db_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {"texts": [], "index": {"theme": {}, "person": {}, "keyword": {}}}
    
    def _save_db(self):
        """保存数据库"""
        Config.ORIGINAL_DIR.mkdir(parents=True, exist_ok=True)
        with open(self.db_path, 'w', encoding='utf-8') as f:
            json.dump(self.data, f, ensure_ascii=False, indent=2)
    
    def import_text(self, version: str, file_path: str) -> bool:
        """
        导入原文
        
        Args:
            version: 版本名称（如"中华书局三全本"）
            file_path: 原文文件路径
        
        Returns:
            bool: 是否成功
        """
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # 解析原文（按卷次、篇名分割）
            texts = self._parse_text(content, version)
            
            # 添加到数据库
            self.data["texts"].extend(texts)
            
            # 更新索引
            self._update_index()
            
            # 保存
            self._save_db()
            
            print(f"✅ 成功导入 {len(texts)} 个原文切片")
            return True
            
        except Exception as e:
            print(f"❌ 导入失败：{e}")
            return False
    
    def _parse_text(self, content: str, version: str) -> List[Dict]:
        """解析原文，生成切片"""
        texts = []
        
        # 简单分割逻辑（实际使用时需要根据具体格式调整）
        # 这里假设原文格式为：卷次 + 篇名 + 正文
        pattern = r"（卷[一二三四五六七八九十]+[·・]?.+?）\n+（.+?）\n+([\s\S]+?）（?=卷[一二三四五六七八九十]+|$）"
        
        matches = re.findall(pattern, content)
        
        for i, (juan, pian, zhengwen) in enumerate(matches):
            # 切片（按300-800字切片）
            slices = self._slice_text(zhengwen, Config.SLICE_LENGTH_RANGE)
            
            for j, slice_text in enumerate(slices):
                text_id = f"{juan}_{pian}_{i:03d}_{j:03d}"
                
                texts.append({
                    "id": text_id,
                    "来源": f"《战国策·{juan}》",
                    "篇名": pian,
                    "版本": version,
                    "原文": slice_text,
                    "切片起始": j * len(slice_text),
                    "切片结束": (j + 1) * len(slice_text),
                    "字数": len(slice_text),
                    "主题标签": [],  # 需要后续标注
                    "难度标签": "入门",  # 需要后续标注
                    "人物": [],  # 需要后续提取
                    "异文标注": [],
                    "注疏引用": [],
                    "解读状态": "未解读"
                })
        
        return texts
    
    def _slice_text(self, text: str, length_range: tuple) -> List[str]:
        """将长文切片"""
        min_len, max_len = length_range
        slices = []
        
        current_slice = ""
        sentences = re.split(r"（[。！？]）", text)
        
        for sentence in sentences:
            if len(current_slice) + len(sentence) <= max_len:
                current_slice += sentence
            else:
                if len(current_slice) >= min_len:
                    slices.append(current_slice)
                    current_slice = sentence
                else:
                    current_slice += sentence
        
        if current_slice:
            slices.append(current_slice)
        
        return slices
    
    def _update_index(self):
        """更新索引"""
        index = {"theme": {}, "person": {}, "keyword": {}}
        
        for text in self.data["texts"]:
            # 主题索引
            for theme in text.get("主题标签", []):
                if theme not in index["theme"]:
                    index["theme"][theme] = []
                index["theme"][theme].append(text["id"])
            
            # 人物索引
            for person in text.get("人物", []):
                if person not in index["person"]:
                    index["person"][person] = []
                index["person"][person].append(text["id"])
        
        self.data["index"] = index
    
    def query_text(self, 
                  chapter: Optional[str] = None,
                  theme: Optional[str] = None,
                  person: Optional[str] = None,
                  keyword: Optional[str] = None) -> List[Dict]:
        """
        查询原文
        
        Args:
            chapter: 篇名（如"冯谖客孟尝君"）
            theme: 主题（如"谋略"）
            person: 人物（如"孟尝君"）
            keyword: 关键词（如"千金买骨"）
        
        Returns:
            List[Dict]: 匹配的原文切片列表
        """
        results = []
        
        for text in self.data["texts"]:
            match = True
            
            if chapter and chapter not in text.get("篇名", ""):
                match = False
            
            if theme and theme not in text.get("主题标签", []):
                match = False
            
            if person and person not in text.get("人物", []):
                match = False
            
            if keyword and keyword not in text.get("原文", ""):
                match = False
            
            if match:
                results.append(text)
        
        return results
    
    def get_slice(self, 
                  slice_id: str,
                  include_variants: bool = False,
                  include_angles: bool = False,
                  include_connections: bool = False) -> Optional[Dict]:
        """
        获取切片详情
        
        Args:
            slice_id: 切片ID
            include_variants: 是否包含异文信息
            include_angles: 是否包含角度建议
            include_connections: 是否包含关联建议
        
        Returns:
            Optional[Dict]: 切片详情
        """
        # 查找切片
        text = None
        for t in self.data["texts"]:
            if t["id"] == slice_id:
                text = t.copy()
                break
        
        if not text:
            print(f"❌ 未找到切片：{slice_id}")
            return None
        
        # 包含异文信息
        if include_variants:
            # TODO: 从异文数据库加载异文
            pass
        
        # 包含角度建议
        if include_angles:
            angle_manager = AngleManager()
            text["建议解读角度"] = angle_manager.match_angles(text)
        
        # 包含关联建议
        if include_connections:
            connection_manager = ConnectionManager()
            text["古今关联"] = connection_manager.recommend_connections(text)
        
        return text

# ============================
# 工具2：版本标注管理
# ============================

class VersionManager:
    """版本标注管理类"""
    
    def __init__(self):
        self.version_db_path = Config.VERSION_DB
        self.variants_db_path = Config.VARIANTS_DB
        self.version_data = self._load_db(self.version_db_path)
        self.variants_data = self._load_db(self.variants_db_path)
    
    def _load_db(self, path: Path) -> Dict:
        """加载数据库"""
        if path.exists():
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {}
    
    def _save_db(self):
        """保存数据库"""
        Config.VERSION_DIR.mkdir(parents=True, exist_ok=True)
        
        with open(self.version_db_path, 'w', encoding='utf-8') as f:
            json.dump(self.version_data, f, ensure_ascii=False, indent=2)
        
        with open(self.variants_db_path, 'w', encoding='utf-8') as f:
            json.dump(self.variants_data, f, ensure_ascii=False, indent=2)
    
    def add_version(self, version_name: str, full_name: str, publisher: str, year: str, reliability: str):
        """添加版本信息"""
        self.version_data[version_name] = {
            "全称": full_name,
            "出版社": publisher,
            "出版年": year,
            "可靠性": reliability,
            "特点": ""
        }
        self._save_db()
        print(f"✅ 成功添加版本：{version_name}")
    
    def generate_variant_table(self, chapter: str) -> Dict:
        """
        生成版本对照表
        
        Args:
            chapter: 篇名
        
        Returns:
            Dict: 版本对照表
        """
        # TODO: 实际实现需要从多个版本的原文中提取异文
        table = {
            "篇名": chapter,
            "异文记录": []
        }
        
        # 示例异文
        if chapter == "冯谖客孟尝君":
            table["异文记录"] = [
                {
                    "位置": "第15字",
                    "中华书局三全本": "弹其铗",
                    "上海古籍标点本": "弹铗",
                    "决策": "采用'弹其铗'，'其'为助词"
                }
            ]
        
        return table
    
    def annotate_variant(self, chapter: str, position: int, variants: List[Dict]):
        """
        标注异文
        
        Args:
            chapter: 篇名
            position: 位置（第几字）
            variants: 异文列表 [{"版本": "xx", "文字": "yy"}, ...]
        """
        if chapter not in self.variants_data:
            self.variants_data[chapter] = []
        
        self.variants_data[chapter].append({
            "位置": position,
            "异文": variants,
            "决策": "",
            "置信度": "中"
        })
        
        self._save_db()
        print(f"✅ 成功标注异文：{chapter} 第{position}字")

# ============================
# 工具3：解读角度库管理
# ============================

class AngleManager:
    """解读角度库管理类"""
    
    def __init__(self):
        self.db_path = Config.ANGLE_DB
        self.data = self._load_db()
    
    def _load_db(self) -> Dict:
        """加载数据库"""
        if self.db_path.exists():
            with open(self.db_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {"angles": []}
    
    def _save_db(self):
        """保存数据库"""
        Config.ANGLE_DIR.mkdir(parents=True, exist_ok=True)
        with open(self.db_path, 'w', encoding='utf-8') as f:
            json.dump(self.data, f, ensure_ascii=False, indent=2)
    
    def add_angle(self, 
                  name: str, 
                  category: str, 
                  applicable_themes: List[str],
                  template: Dict) -> bool:
        """
        添加角度
        
        Args:
            name: 角度名称
            category: 分类（义理/考据/辞章/经世/人性）
            applicable_themes: 适用主题列表
            template: 角度模板
        
        Returns:
            bool: 是否成功
        """
        angle_id = f"angle_{len(self.data['angles']) + 1:03d}"
        
        self.data["angles"].append({
            "id": angle_id,
            "名称": name,
            "分类": category,
            "适用主题": applicable_themes,
            "适用难度": ["进阶", "深度"],
            "模板结构": template,
            "示例篇章": [],
            "使用次数": 0,
            "成功率": "0%",
            "最后使用": ""
        })
        
        self._save_db()
        print(f"✅ 成功添加角度：{name}（ID: {angle_id}）")
        return True
    
    def match_angles(self, text: Dict, limit: int = 5) -> List[Dict]:
        """
        匹配角度
        
        Args:
            text: 原文切片
            limit: 返回数量限制
        
        Returns:
            List[Dict]: 匹配的角度列表
        """
        matches = []
        
        for angle in self.data["angles"]:
            # 计算匹配度
            score = 0
            
            # 主题匹配（权重0.4）
            for theme in text.get("主题标签", []):
                if theme in angle.get("适用主题", []):
                    score += 0.4
            
            # 可以根据其他维度计算分数...
            
            if score > 0:
                matches.append({
                    "angle_id": angle["id"],
                    "名称": angle["名称"],
                    "分类": angle["分类"],
                    "匹配度": f"{score:.0%}",
                    "使用次数": angle["使用次数"],
                    "成功率": angle["成功率"]
                })
        
        # 按匹配度排序
        matches.sort(key=lambda x: float(x["匹配度"].strip('%')) / 100, reverse=True)
        
        return matches[:limit]
    
    def update_angle_usage(self, angle_id: str, success: bool, platform: str):
        """
        更新角度使用数据
        
        Args:
            angle_id: 角度ID
            success: 是否成功（用户反馈）
            platform: 发布平台
        """
        for angle in self.data["angles"]:
            if angle["id"] == angle_id:
                angle["使用次数"] += 1
                
                # 更新成功率（简单移动平均）
                old_rate = int(angle["成功率"].strip('%')) / 100
                new_success = 1 if success else 0
                new_rate = (old_rate * (angle["使用次数"] - 1) + new_success) / angle["使用次数"]
                angle["成功率"] = f"{new_rate:.0%}"
                
                angle["最后使用"] = datetime.now().strftime("%Y-%m-%d")
                
                self._save_db()
                print(f"✅ 成功更新角度使用数据：{angle['名称']}")
                return
        
        print(f"❌ 未找到角度：{angle_id}")

# ============================
# 工具4：古今关联库管理
# ============================

class ConnectionManager:
    """古今关联库管理类"""
    
    def __init__(self):
        self.db_path = Config.CONNECTION_DB
        self.data = self._load_db()
    
    def _load_db(self) -> Dict:
        """加载数据库"""
        if self.db_path.exists():
            with open(self.db_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {"connections": []}
    
    def _save_db(self):
        """保存数据库"""
        Config.CONNECTION_DIR.mkdir(parents=True, exist_ok=True)
        with open(self.db_path, 'w', encoding='utf-8') as f:
            json.dump(self.data, f, ensure_ascii=False, indent=2)
    
    def add_connection(self, 
                      ancient: str, 
                      modern: str, 
                      connection_type: str,
                      scene: str,
                      insight: str) -> bool:
        """
        添加古今关联
        
        Args:
            ancient: 古代母题
            modern: 现代映射
            connection_type: 关联类型（结构类比/人性共通/问题同构/反常识对照）
            scene: 具体场景
            insight: 反常识洞察
        
        Returns:
            bool: 是否成功
        """
        connection_id = f"connect_{len(self.data['connections']) + 1:03d}"
        
        self.data["connections"].append({
            "id": connection_id,
            "古代母题": ancient,
            "现代映射": modern,
            "关联类型": connection_type,
            "关联质量": "",  # 需要评估
            "结构相似性": 0,
            "人性共通性": 0,
            "问题同构性": 0,
            "反常识性": 0,
            "具体场景": scene,
            "反常识洞察": insight,
            "王立群式表达": "",
            "使用次数": 0,
            "成功率": "0%",
            "最后使用": ""
        })
        
        self._save_db()
        print(f"✅ 成功添加古今关联：{ancient} → {modern}（ID: {connection_id}）")
        return True
    
    def recommend_connections(self, text: Dict, limit: int = 5) -> List[Dict]:
        """
        推荐古今关联
        
        Args:
            text: 原文切片
            limit: 返回数量限制
        
        Returns:
            List[Dict]: 推荐的关联列表
        """
        recommendations = []
        
        for conn in self.data["connections"]:
            # 简单匹配：检查古代母题是否在原文或篇名中出现
            if (conn["古代母题"] in text.get("原文", "") or 
                conn["古代母题"] in text.get("篇名", "")):
                
                recommendations.append({
                    "connection_id": conn["id"],
                    "古代": conn["古代母题"],
                    "现代": conn["现代映射"],
                    "类型": conn["关联类型"],
                    "质量": conn["关联质量"],
                    "使用次数": conn["使用次数"],
                    "成功率": conn["成功率"]
                })
        
        # 按质量排序
        quality_order = {"S级": 0, "A级": 1, "B级": 2, "C级": 3, "D级": 4}
        recommendations.sort(key=lambda x: quality_order.get(x["质量"], 5))
        
        return recommendations[:limit]
    
    def evaluate_connection(self, connection_id: str) -> Dict:
        """
        评估古今关联质量
        
        Args:
            connection_id: 关联ID
        
        Returns:
            Dict: 评估结果
        """
        for conn in self.data["connections"]:
            if conn["id"] == connection_id:
                # 计算加权总分
                total_score = (
                    conn["结构相似性"] * 0.4 +
                    conn["人性共通性"] * 0.3 +
                    conn["问题同构性"] * 0.2 +
                    conn["反常识性"] * 0.1
                )
                
                # 评定质量等级
                if total_score >= 4.5:
                    quality = "S级"
                elif total_score >= 3.5:
                    quality = "A级"
                elif total_score >= 2.5:
                    quality = "B级"
                elif total_score >= 1.5:
                    quality = "C级"
                else:
                    quality = "D级"
                
                # 更新质量等级
                conn["关联质量"] = quality
                self._save_db()
                
                return {
                    "connection_id": connection_id,
                    "总分": f"{total_score:.1f} / 5.0",
                    "质量等级": quality,
                    "详细评分": {
                        "结构相似性": f"{conn['结构相似性']}/5",
                        "人性共通性": f"{conn['人性共通性']}/5",
                        "问题同构性": f"{conn['问题同构性']}/5",
                        "反常识性": f"{conn['反常识性']}/5"
                    }
                }
        
        return {"error": f"未找到关联：{connection_id}"}

# ============================
# 命令行接口
# ============================

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description="战国策虾配套工具集")
    
    subparsers = parser.add_subparsers(dest="command", help="子命令")
    
    # 1. 导入原文
    import_parser = subparsers.add_parser("import-text", help="导入原文")
    import_parser.add_argument("--version", required=True, help="版本名称")
    import_parser.add_argument("--file", required=True, help="原文文件路径")
    
    # 2. 查询原文
    query_parser = subparsers.add_parser("query-text", help="查询原文")
    query_parser.add_argument("--chapter", help="篇名")
    query_parser.add_argument("--theme", help="主题")
    query_parser.add_argument("--person", help="人物")
    query_parser.add_argument("--keyword", help="关键词")
    
    # 3. 获取切片
    get_parser = subparsers.add_parser("get-slice", help="获取切片详情")
    get_parser.add_argument("--id", required=True, help="切片ID")
    get_parser.add_argument("--include-variants", action="store_true", help="包含异文信息")
    get_parser.add_argument("--include-angles", action="store_true", help="包含角度建议")
    get_parser.add_argument("--include-connections", action="store_true", help="包含关联建议")
    
    # 4. 添加角度
    add_angle_parser = subparsers.add_parser("add-angle", help="添加解读角度")
    add_angle_parser.add_argument("--name", required=True, help="角度名称")
    add_angle_parser.add_argument("--category", required=True, help="分类")
    add_angle_parser.add_argument("--themes", nargs="+", required=True, help="适用主题")
    
    # 5. 推荐关联
    recommend_parser = subparsers.add_parser("recommend-connections", help="推荐古今关联")
    recommend_parser.add_argument("--chapter", required=True, help="篇名")
    
    # 解析参数
    args = parser.parse_args()
    
    # 执行命令
    if args.command == "import-text":
        manager = OriginalTextManager()
        manager.import_text(args.version, args.file)
    
    elif args.command == "query-text":
        manager = OriginalTextManager()
        results = manager.query_text(
            chapter=args.chapter,
            theme=args.theme,
            person=args.person,
            keyword=args.keyword
        )
        print(f"找到 {len(results)} 个匹配切片：")
        for r in results[:10]:  # 只显示前10个
            print(f"  - {r['id']}: {r['篇名']} ({r['字数']}字)")
    
    elif args.command == "get-slice":
        manager = OriginalTextManager()
        slice_data = manager.get_slice(
            slice_id=args.id,
            include_variants=args.include_variants,
            include_angles=args.include_angles,
            include_connections=args.include_connections
        )
        if slice_data:
            print(json.dumps(slice_data, ensure_ascii=False, indent=2))
    
    elif args.command == "add-angle":
        manager = AngleManager()
        manager.add_angle(
            name=args.name,
            category=args.category,
            applicable_themes=args.themes,
            template={}
        )
    
    elif args.command == "recommend-connections":
        # 先查询原文
        text_manager = OriginalTextManager()
        texts = text_manager.query_text(chapter=args.chapter)
        
        if texts:
            conn_manager = ConnectionManager()
            recommendations = conn_manager.recommend_connections(texts[0])
            
            print(f"为'{args.chapter}'推荐古今关联：")
            for r in recommendations:
                print(f"  - {r['古代']} → {r['现代']} ({r['类型']}, {r['质量']})")
    
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
