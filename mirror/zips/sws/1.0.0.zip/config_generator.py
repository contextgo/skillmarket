#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
配置文件生成器
为战国策虾配套工具生成各种配置文件
"""

import json
from pathlib import Path

class ConfigGenerator:
    """配置文件生成器类"""
    
    def __init__(self, base_dir: str = "C:/Workbuddy/skills/国学经典"):
        self.base_dir = Path(base_dir)
        self.config_dir = self.base_dir / "config"
        self.config_dir.mkdir(exist_ok=True)
    
    def generate_main_config(self) -> dict:
        """
        生成主配置文件 config.json
        
        Returns:
            dict: 配置字典
        """
        config = {
            "数据库路径": {
                "原文库": str(self.base_dir / "data/原文库"),
                "角度库": str(self.base_dir / "data/角度库"),
                "关联库": str(self.base_dir / "data/关联库"),
                "版本对照": str(self.base_dir / "data/版本对照")
            },
            "默认版本": "中华书局三全本",
            "备用版本": "上海古籍出版社标点本",
            "切片长度范围": [300, 800],
            "异文处理策略": "正文用通行本，异文注脚注",
            "置信度阈值": {
                "高": "有明确版本依据和注疏支持",
                "中": "有注疏支持但存在争议",
                "低": "仅凭推测或单一来源"
            },
            "自动标注": {
                "主题标签": True,
                "人物提取": True,
                "难度评估": True
            },
            "标注格式": {
                "公众号长文": "脚注式",
                "知乎": "括号式",
                "今日头条": "括号式",
                "初稿": "独立标注式"
            },
            "角度分类权重": {
                "义理角度": 0.9,
                "考据角度": 0.85,
                "辞章角度": 0.8,
                "经世角度": 0.95,
                "人性角度": 0.9
            },
            "关联类型权重": {
                "结构类比": 0.4,
                "人性共通": 0.3,
                "问题同构": 0.2,
                "反常识对照": 0.1
            },
            "质量评级标准": {
                "S级": "总分≥4.5",
                "A级": "总分≥3.5 且 <4.5",
                "B级": "总分≥2.5 且 <3.5",
                "C级": "总分≥1.5 且 <2.5",
                "D级": "总分<1.5"
            },
            "推荐数量": {
                "角度": 5,
                "关联": 5
            }
        }
        
        # 保存配置
        config_path = self.config_dir / "config.json"
        with open(config_path, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        
        print(f"✅ 成功生成主配置文件：{config_path}")
        return config
    
    def generate_version_config(self) -> dict:
        """
        生成版本配置文件 version_config.json
        
        Returns:
            dict: 版本配置字典
        """
        config = {
            "主要版本": {
                "中华书局三全本": {
                    "全称": "《战国策》（全三册）中华书局",
                    "出版社": "中华书局",
                    "出版年": "2012年",
                    "可靠性": "高",
                    "特点": "有原文、注释、白话翻译，便于对照",
                    "推荐使用场景": "主要参考版本"
                },
                "上海古籍标点本": {
                    "全称": "《战国策》上海古籍出版社标点本",
                    "出版社": "上海古籍出版社",
                    "出版年": "1985年",
                    "可靠性": "高",
                    "特点": "标点准确，校勘精良",
                    "推荐使用场景": "对照参考版本"
                },
                "四库全书本": {
                    "全称": "《钦定四库全书》本《战国策》",
                    "出版社": "上海古籍出版社（影印）",
                    "出版年": "1987年",
                    "可靠性": "中",
                    "特点": "接近古本面貌，但有清代篡改风险",
                    "推荐使用场景": "学术研究参考"
                },
                "姚宏本": {
                    "全称": "姚宏校正本《战国策》",
                    "出版社": "（古籍刻本）",
                    "出版年": "南宋",
                    "可靠性": "高",
                    "特点": "现存较早的完整本子",
                    "推荐使用场景": "学术研究参考"
                },
                "鲍彪本": {
                    "全称": "鲍彪注本《战国策》",
                    "出版社": "（古籍刻本）",
                    "出版年": "南宋",
                    "可靠性": "中",
                    "特点": "有系统注释，但改动较大",
                    "推荐使用场景": "需谨慎使用"
                }
            },
            "异文处理策略": {
                "默认策略": "正文用通行本，异文注脚注",
                "置信度阈值": {
                    "高": "有明确版本依据和注疏支持",
                    "中": "有注疏支持但存在争议",
                    "低": "仅凭推测或单一来源"
                }
            },
            "标注格式": {
                "公众号长文": "脚注式",
                "知乎": "括号式",
                "今日头条": "括号式",
                "初稿": "独立标注式"
            }
        }
        
        # 保存配置
        config_path = self.config_dir / "version_config.json"
        with open(config_path, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        
        print(f"✅ 成功生成版本配置文件：{config_path}")
        return config
    
    def generate_angle_config(self) -> dict:
        """
        生成角度配置文件 angle_config.json
        
        Returns:
            dict: 角度配置字典
        """
        config = {
            "角度分类": {
                "义理角度": {
                    "权重": 0.9,
                    "适用平台": ["公众号长文", "知乎"],
                    "最小字数": 1500,
                    "描述": "原文蕴含的哲学道理、价值观"
                },
                "考据角度": {
                    "权重": 0.85,
                    "适用平台": ["知乎"],
                    "最小字数": 800,
                    "描述": "历史背景、人物关系、事件真伪"
                },
                "辞章角度": {
                    "权重": 0.8,
                    "适用平台": ["公众号长文"],
                    "最小字数": 1200,
                    "描述": "修辞艺术、论辩技巧、语言之美"
                },
                "经世角度": {
                    "权重": 0.95,
                    "适用平台": ["公众号长文", "今日头条"],
                    "最小字数": 500,
                    "描述": "对现代管理/职场/人际的启示"
                },
                "人性角度": {
                    "权重": 0.9,
                    "适用平台": ["公众号长文", "今日头条"],
                    "最小字数": 800,
                    "描述": "人物心理、动机分析、权力博弈"
                }
            },
            "匹配规则": {
                "主题匹配权重": 0.4,
                "难度匹配权重": 0.3,
                "历史数据权重": 0.3
            },
            "自动推荐数量": 5
        }
        
        # 保存配置
        config_path = self.config_dir / "angle_config.json"
        with open(config_path, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        
        print(f"✅ 成功生成角度配置文件：{config_path}")
        return config
    
    def generate_connection_config(self) -> dict:
        """
        生成关联配置文件 connection_config.json
        
        Returns:
            dict: 关联配置字典
        """
        config = {
            "关联类型权重": {
                "结构类比": 0.4,
                "人性共通": 0.3,
                "问题同构": 0.2,
                "反常识对照": 0.1
            },
            "质量评级标准": {
                "S级": "总分≥4.5",
                "A级": "总分≥3.5 且 <4.5",
                "B级": "总分≥2.5 且 <3.5",
                "C级": "总分≥1.5 且 <2.5",
                "D级": "总分<1.5"
            },
            "伪关联检测规则": {
                "表面相似陷阱": True,
                "强行附会陷阱": True,
                "时代错误陷阱": True
            },
            "推荐数量": 5,
            "质量检测维度": {
                "结构相似性": {
                    "权重": 0.4,
                    "描述": "古代和现代的结构是否相同？"
                },
                "人性共通性": {
                    "权重": 0.3,
                    "描述": "人性反应是否相同？"
                },
                "问题同构性": {
                    "权重": 0.2,
                    "描述": "问题结构是否相同？"
                },
                "反常识性": {
                    "权重": 0.1,
                    "描述": "是否有反常识洞察？"
                }
            }
        }
        
        # 保存配置
        config_path = self.config_dir / "connection_config.json"
        with open(config_path, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        
        print(f"✅ 成功生成关联配置文件：{config_path}")
        return config
    
    def generate_all_configs(self) -> dict:
        """
        生成所有配置文件
        
        Returns:
            dict: 所有配置的字典
        """
        print("开始生成所有配置文件...")
        
        configs = {
            "config.json": self.generate_main_config(),
            "version_config.json": self.generate_version_config(),
            "angle_config.json": self.generate_angle_config(),
            "connection_config.json": self.generate_connection_config()
        }
        
        print("✅ 所有配置文件生成完成！")
        return configs


def main():
    """主函数"""
    generator = ConfigGenerator()
    generator.generate_all_configs()


if __name__ == "__main__":
    main()
