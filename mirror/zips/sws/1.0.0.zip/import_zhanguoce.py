"""
《战国策》原文导入脚本
支持多种格式的文本文件，自动解析并导入数据库
"""

import json
import re
import os
from pathlib import Path

class ZhanGuoCeImporter:
    """《战国策》原文导入器"""
    
    def __init__(self, db_path: str = "data/原文库/original_texts.json"):
        self.db_path = db_path
        self.texts = []
        self.index = {
            "theme": {},
            "person": {},
            "keyword": {}
        }
        
        # 尝试加载现有数据
        self.load_existing()
    
    def load_existing(self):
        """加载现有数据库"""
        if os.path.exists(self.db_path):
            with open(self.db_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                self.texts = data.get('texts', [])
                self.index = data.get('index', {"theme": {}, "person": {}, "keyword": {}})
            print(f"✓ 已加载现有数据库，包含 {len(self.texts)} 个切片")
        else:
            print("⚠ 数据库文件不存在，将创建新数据库")
    
    def parse_text_file(self, file_path: str) -> list:
        """
        解析文本文件
        支持格式：
        1. 标准格式：包含篇名、原文、注释等
        2. 简单格式：每行一段原文
        3. 中华书局三全本格式
        """
        print(f"📖 正在解析文件：{file_path}")
        
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # 尝试检测格式
        if "战国策卷" in content or "卷一" in content:
            return self._parse_volume_format(content)
        else:
            return self._parse_simple_format(content)
    
    def _parse_volume_format(self, content: str) -> list:
        """解析分卷格式（中华书局等）"""
        slices = []
        
        # 使用正则表达式分割章节
        # 匹配模式：卷号 + 篇名
        pattern = r'(战国策卷[一二三四五六七八九十]+|卷[一二三四五六七八九十]+)\s*([^\n]+)'
        
        chapters = re.split(pattern, content)
        
        print(f"  检测到分卷格式，找到 {len(chapters)//3} 个章节")
        
        # 这里需要根据实际格式调整解析逻辑
        # 这是一个示例实现
        
        return slices
    
    def _parse_simple_format(self, content: str) -> list:
        """解析简单格式（每行一段或按空行分割）"""
        slices = []
        
        # 按双换行分割段落
        paragraphs = content.split('\n\n')
        
        for i, para in enumerate(paragraphs):
            para = para.strip()
            if not para:
                continue
            
            # 尝试提取篇名（如果有的话）
            lines = para.split('\n')
            if len(lines) > 0 and ("战国策" in lines[0] or "卷" in lines[0]):
                # 第一行可能是篇名
                chapter_name = lines[0]
                text = '\n'.join(lines[1:])
            else:
                chapter_name = f"未命名章节_{i+1}"
                text = para
            
            slices.append({
                'chapter': chapter_name,
                'text': text,
                'index': i
            })
        
        print(f"  检测到简单格式，找到 {len(slices)} 个段落")
        return slices
    
    def create_slices(self, parsed_data: list, source: str = "《战国策》", 
                      version: str = "中华书局三全本") -> int:
        """
        根据解析的数据创建切片
        返回创建的切片数量
        """
        count = 0
        
        for item in parsed_data:
            # 生成切片ID
            slice_id = f"zsce_auto_{len(self.texts) + 1:04d}"
            
            # 创建切片对象
            text_slice = {
                "id": slice_id,
                "来源": source,
                "篇名": item.get('chapter', '未知篇章'),
                "版本": version,
                "原文": item.get('text', ''),
                "切片起始": item.get('index', 0) * 100,  # 估算位置
                "切片结束": (item.get('index', 0) + 1) * 100,
                "字数": len(item.get('text', '')),
                "主题标签": self._extract_themes(item.get('text', '')),
                "难度标签": "入门",
                "人物": self._extract_persons(item.get('text', '')),
                "异文标注": [],
                "注疏引用": [],
                "解读状态": "未解读"
            }
            
            self.texts.append(text_slice)
            self._update_index(slice_id, text_slice)
            count += 1
        
        print(f"✓ 成功创建 {count} 个切片")
        return count
    
    def _extract_themes(self, text: str) -> list:
        """从文本中提取主题标签（简单关键词匹配）"""
        themes = []
        
        keywords = {
            "谋略": ["谋", "策", "计", "策士"],
            "外交": ["使", "聘", "盟", "约"],
            "战争": ["兵", "战", "攻", "伐"],
            "人性": ["王", "君", "臣", "相"],
            "危机处理": ["患", "危", "急", "困"]
        }
        
        for theme, words in keywords.items():
            if any(word in text for word in words):
                themes.append(theme)
        
        return themes if themes else ["未分类"]
    
    def _extract_persons(self, text: str) -> list:
        """从文本中提取人名（简单正则匹配）"""
        # 匹配常见古人名格式
        pattern = r'([A-Za-z\u4e00-\u9fa5]{2,3}(?:王|君|相|臣|子))'
        matches = re.findall(pattern, text)
        
        # 去重并返回
        return list(set(matches))[:5]  # 最多返回5个人名
    
    def _update_index(self, slice_id: str, slice_data: dict):
        """更新索引"""
        # 主题索引
        for theme in slice_data.get("主题标签", []):
            if theme not in self.index["theme"]:
                self.index["theme"][theme] = []
            if slice_id not in self.index["theme"][theme]:
                self.index["theme"][theme].append(slice_id)
        
        # 人物索引
        for person in slice_data.get("人物", []):
            if person not in self.index["person"]:
                self.index["person"][person] = []
            if slice_id not in self.index["person"][person]:
                self.index["person"][person].append(slice_id)
    
    def save(self):
        """保存到数据库"""
        data = {
            "texts": self.texts,
            "index": self.index
        }
        
        # 确保目录存在
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        
        with open(self.db_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        print(f"✓ 数据库已保存：{self.db_path}")
        print(f"  总计 {len(self.texts)} 个切片")
    
    def print_stats(self):
        """打印统计信息"""
        print("\n📊 数据库统计：")
        print(f"  总切片数：{len(self.texts)}")
        print(f"  主题分类：{len(self.index['theme'])} 个")
        print(f"  人物索引：{len(self.index['person'])} 个")
        
        # 按来源统计
        sources = {}
        for text in self.texts:
            source = text.get("来源", "未知")
            sources[source] = sources.get(source, 0) + 1
        
        print("\n  按来源统计：")
        for source, count in sources.items():
            print(f"    {source}: {count} 个切片")


def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description='导入《战国策》原文到数据库')
    parser.add_argument('--file', '-f', help='文本文件路径', required=True)
    parser.add_argument('--source', '-s', help='来源名称', default='《战国策》')
    parser.add_argument('--version', '-v', help='版本信息', default='中华书局三全本')
    parser.add_argument('--db', '-d', help='数据库路径', default='data/原文库/original_texts.json')
    
    args = parser.parse_args()
    
    # 检查文件是否存在
    if not os.path.exists(args.file):
        print(f"❌ 错误：文件不存在 - {args.file}")
        return
    
    # 创建导入器
    importer = ZhanGuoCeImporter(args.db)
    
    # 解析文件
    parsed_data = importer.parse_text_file(args.file)
    
    if not parsed_data:
        print("⚠ 警告：没有解析到任何内容")
        return
    
    # 创建切片
    count = importer.create_slices(parsed_data, args.source, args.version)
    
    # 保存
    importer.save()
    
    # 打印统计
    importer.print_stats()


if __name__ == "__main__":
    main()
