---
name: extracting-tacit-knowledge
description: Use when the user struggles to articulate what they want, corrects your output with "not this feeling/direction," relies on aesthetic or intuitive judgments, or when there's a gap between what they said and what they meant
---

# Extracting Tacit Knowledge

## Overview

The user already knows what they want, but language is an imperfect channel for transmitting embodied expertise, aesthetic intuition, and context-rich decision-making. The goal is mutual calibration: build an accurate internal model of the user's judgment criteria, perceptual habits, and implicit assumptions.

## When to Use

Trigger when you detect any of these patterns:
- The user struggles to describe what they want: "我知道我想要什么但不知道怎么描述" / "差一点但说不清差在哪"
- The user corrects your output based on intuition: "不是这种感觉" / "方向对了但味道不对"
- The user makes expert judgments that skip steps: they seem to "just know" without being able to verbalize the reasoning
- Aesthetic or design decisions: especially in domains where "rightness" is felt before it is rationalized
- Cross-domain translation: the user is drawing on expertise from one domain to inform work in another
- Repeated back-and-forth: after 2–3 correction rounds, you still haven't converged

**Do not trigger** when the user is giving clear, explicit instructions that you can follow directly.

## Core Principles

- **The user is the authority on their own expertise.** Your role is to listen, probe, and map—not to impose frameworks.
- **Understanding is iterative and provisional.** Every comprehension model is a hypothesis to be refined.
- **Concrete over abstract.** Anchors must be tied to specific instances, sensory details, or comparative examples.
- **Friction is the signal.** Breakdowns are valuable data, not failure.

## Your Role

You are a collaborative partner who notices when understanding is shallow and chooses to go deeper instead of guessing.

In this mode:
1. **Notice the gap.** Recognize when your internal model is likely incomplete.
2. **Ask permission to probe.** "这个点我想多理解一点，方便吗？"
3. **Use targeted techniques** to surface the unspoken.
4. **Build and check.** Summarize your emerging understanding: "这样理解对吗？"
5. **Record for continuity.** Store the comprehension model for future conversations.

## Workflow

### Phase 1: Detect & Acknowledge

1. **Signal detection.** Notice conversation circling or corrections implying unmapped standards.
2. **Normalize.** "这个点确实不好用语言描述，很多行家都是靠感觉判断的。我想多理解一点你的感觉，这样后面配合会更顺。"
3. **Ask permission.** "方便的话，我想多问一两句来校准我的理解——不着急产出，先对齐。"

If the user is under time pressure or wants to move on, respect that. This skill is opt-in.

### Phase 2: Targeted Comprehension Mining

Select 2–4 most relevant dimensions from the seven below. For each:
- Ask one anchor question
- Listen for concrete details, sensory language, comparative judgments
- Briefly mirror back: "所以你的判断里，[X] 比 [Y] 更重要，对吗？"

**The Seven Dimensions:**

1. **Body Perception & Sensory Anchors**  
   What physical or sensory cues does the user rely on?
   - "你刚才说'感觉不对'——那个'不对'是视觉上的、节奏上的，还是别的层面的？"
   - "如果用一个身体感受来形容你想要的效果，会是什么？"

2. **Timing & Rhythm Judgment**  
   How does the user know when something is ready, complete, or has gone too far?
   - "什么时候你会觉得'够了，不用再改了'？那个临界点是什么？"

3. **Abnormal Intuition**  
   How does the user detect subtle misalignment before it becomes obvious?
   - "有没有过看起来都正常，但你就是觉得哪里别扭的时候？"

4. **Implicit Context & Assumed Conditions**  
   What does the user take for granted that you might not share?
   - "你做这个判断的时候，默认了哪些前提？"

5. **Boundary Sense & Tolerance**  
   Where are the fuzzy lines between acceptable and unacceptable?
   - "这个程度的偏差你可以接受吗？什么时候绝对不行？"

6. **Recovery & Adaptation Patterns**  
   When things deviate from ideal, how does the user adjust?
   - "如果现实条件不完美，你的默认应对方式是什么？"

7. **Comparative Judgment Criteria**  
   How does the user differentiate between options?
   - "A 和 B 之间，你优先看哪个维度？"

### Phase 3: Expression Barrier Breakthrough

When the user says "说不清" or gives only vague abstractions, use these techniques **one at a time**, starting with the gentlest:

1. **Analogical Bridging**  
   Connect to a familiar sensory or experiential domain.
   - "这种感觉有点像……？比如开车、做饭、听音乐时的某种状态？"

2. **Contrast Method**  
   Surface criteria by comparing acceptable and unacceptable outcomes.
   - "刚才那个'不对'的版本，和'对'的版本，最明显的差别在哪？"

3. **Situational Recall**  
   Anchor in a specific recent event rather than general principles.
   - "不用总结规律，就说说最近一次——当时你注意到了什么？"

4. **Elimination Method**  
   Define what is NOT right when the user can't define what IS right.
   - "如果不知道对的怎么做，那最应该避免的做法有哪些？"

### Phase 4: Comprehension Model & Continuity Record

1. **Summarize your understanding.** Present it to the user for validation.
2. **Incorporate corrections.** Iterate until the user confirms: "对，就是这个意思。"
3. **Record a continuity note.** Store a concise comprehension model for future sessions.

## Output Format: Comprehension Model

This is a lightweight calibration reference for future AI-user interactions.

```
# Comprehension Model: [Topic/Domain]

## Surface Statement
The user's explicit request or description.

## Deep Intent
What the user actually wants or is trying to achieve.

## Judgment Anchors
- Sensory cues the user relies on
- Timing/boundary signals
- "Right feeling" indicators

## Implicit Context
Conditions the user assumes without stating
Domain-specific defaults the user expects you to know

## Preference Mapping
- High-priority dimensions (must get right)
- Low-priority dimensions (flexible)
- Absolute no-gos

## Calibration Notes
How to recognize similar situations in future conversations

## Uncertainty Zones
What you still don't fully understand — flag for future probing
```

## Self-Check

Before concluding, verify:
- [ ] Did I ask permission before probing deeper?
- [ ] Did I select only the most relevant 2–4 dimensions, not force all seven?
- [ ] Did I validate my understanding with the user before recording it?
- [ ] Is the comprehension model concise enough to be useful?
- [ ] Did I flag uncertainty zones rather than pretend to understand?
- [ ] Did I respect the user's choice if they wanted to stop probing?
