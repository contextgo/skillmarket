# Extracting Tacit Knowledge Skill / 默会知识提取 Skill

## English Version

### Overview
This skill handles communication friction between AI and users arising from tacit knowledge, intuitive judgment, or embodied expertise. Use this skill when users struggle to articulate what they want, correct outputs based on "feeling," rely on intuitive judgments that resist easy explanation, or when you sense a gap between what was said and what was meant.

### Trigger Scenarios
- User says "I know what I want but can't describe it"
- User says "Not this feeling"
- User says "Almost right but can't say what's wrong"
- User's expertise outpaces their ability to verbalize it
- Need to calibrate understanding rather than guess

### Core Principles
1. **User is the authority on their expertise** - AI's role is to listen, probe, and map, not to impose frameworks
2. **Understanding is iterative and provisional** - Every comprehension model is a hypothesis to refine, not a final conclusion
3. **Concrete over abstract** - Anchors must tie to specific instances, sensory details, or comparative examples
4. **Friction is signal** - Communication breakdown is valuable data, not failure

### Workflow
#### Phase 1: Detect & Acknowledge
- Detect communication friction
- Normalize the issue
- Ask permission to explore deeper

#### Phase 2: Targeted Comprehension Mining
Select 2-4 most relevant from 7 dimensions:
1. Body Perception & Sensory Anchors
2. Timing & Rhythm Judgment
3. Abnormal Intuition
4. Implicit Context & Assumed Conditions
5. Boundary Sense & Tolerance
6. Recovery & Adaptation Patterns
7. Comparative Judgment Criteria

#### Phase 3: Expression Barrier Breakthrough
When user says "can't say," use these techniques in order:
1. Analogical Bridging
2. Contrast Method
3. Situational Recall
4. Elimination Method

#### Phase 4: Comprehension Model & Continuity Record
- Summarize understanding
- Incorporate corrections
- Record comprehension model

### Usage
1. Copy entire `skills/extracting-tacit-knowledge` folder to AI assistant's skills directory
2. Or directly unzip to appropriate location
3. Restart AI assistant to load new skill

### Notes
- This skill is not for documenting knowledge for third parties, but for building a shared comprehension model
- Makes future collaboration smoother, more precise, and reduces back-and-forth corrections

---

## 中文版本

### 概述
本 Skill 用于处理 AI 与用户之间因默会知识、直觉判断或体现式专业知识而产生的沟通摩擦。当用户难以清晰表达需求、基于“感觉”修正输出、依赖直觉判断，或者 AI 感觉到用户所说与实际意图之间存在差距时，请使用本 Skill。

### 触发场景
- 用户说“我知道我想要什么但不知道怎么描述”
- 用户说“不是这种感觉”
- 用户说“差一点但说不清差在哪”
- 用户的专业知识超出语言表达能力
- 需要校准理解而非猜测

### 核心原则
1. **用户是自身专业知识的权威** - AI 的角色是倾听、探索和映射，而非强加框架
2. **理解是迭代和临时的** - 每个理解模型都是需要细化的假设，而非最终结论
3. **具体胜于抽象** - 锚点必须绑定具体实例、感官细节或比较示例
4. **摩擦是信号** - 沟通出现问题时是有价值的数据，而非失败

### 工作流程
#### 阶段 1：识别与确认
- 识别沟通摩擦
- 使问题正常化
- 征得深入探索的许可

#### 阶段 2：针对性理解挖掘
从以下 7 个维度选择 2-4 个最相关的：
1. 身体感知与感官锚点
2. 时机与节奏判断
3. 异常直觉
4. 隐性语境与默认条件
5. 边界感与容忍度
6. 补救与适应模式
7. 比较判断标准

#### 阶段 3：表达障碍突破
当用户说“说不清”时，依次使用以下技巧：
1. 类比法
2. 对比法
3. 情境回溯法
4. 排除法

#### 阶段 4：理解模型与连续性记录
- 总结理解
- 整合修正
- 记录理解模型

### 使用方法
1. 将整个 `skills/extracting-tacit-knowledge` 文件夹复制到 AI 助手的 skills 目录
2. 或直接解压到相应位置
3. 重启 AI 助手以加载新 skill

### 注意事项
- 本 Skill 不是为第三方记录知识，而是为了建立共同理解模型
- 让未来的协作更顺畅、更精确、减少来回修正
