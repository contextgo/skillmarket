---
version: "2.0.0"
name: podcast-notes
description: "播客大纲、Show Notes生成、开场白、嘉宾问题、变现策略、分发渠道。Podcast assistant with outlines, show notes, intro scripts, guest questions, monetization strategies, distribution channels. Use when you need podcast notes capabilities. Triggers on: podcast notes."
author: BytesAgain
---
# podcast-notes

播客大纲、Show Notes生成、开场白、嘉宾问题、变现策略、分发渠道。Podcast assistant with outlines, show notes, intro scripts, guest questions, monetization strategies, distribution channels.

## 与手动操作对比

| | 手动 | 使用本工具 |
|---|---|---|
| 时间 | 数小时 | 几分钟 |
| 专业度 | 取决于经验 | 专业级输出 |
| 一致性 | 易遗漏 | 标准化模板 |

## 命令列表

| 命令 | 功能 |
|------|------|
| `brief` | brief |
| `detailed` | detailed |
| `blog-style` | blog style |
| `conversational` | conversational |
| `professional` | professional |
| `storytelling` | storytelling |
| `energetic` | energetic |
| `outline` | outline |

## 专业建议

- Audio quality** is non-negotiable — invest in a decent mic (Blue Yeti, ATR2100x, SM7B)
- Room treatment**: Record in a quiet, carpeted room. Closets work surprisingly well
- Record at 44.1kHz/16-bit** minimum (standard for podcast hosting platforms)
- Leave 2-3 seconds of silence** at the start for noise floor sampling
- Always have a backup recording** (record locally AND in the cloud)

---
*podcast-notes by BytesAgain*
---
💬 Feedback & Feature Requests: https://bytesagain.com/feedback
Powered by BytesAgain | bytesagain.com

## Examples

```bash
# Show help
podcast-notes help

# Run
podcast-notes run
```

## Commands

Run `podcast-notes help` to see all available commands.
