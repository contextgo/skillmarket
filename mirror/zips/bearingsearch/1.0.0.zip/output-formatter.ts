import type { Bearing, PagedResult } from '../../api/types'

function padCell(text: string, width: number): string {
  const len = getTextWidth(text)
  if (len >= width) return text
  return text + ' '.repeat(width - len)
}

function getTextWidth(text: string): number {
  let width = 0
  for (const char of text) {
    width += char.charCodeAt(0) > 0x7f ? 2 : 1
  }
  return width
}

const COLUMNS = [
  { key: 'partNumber' as const, header: '型号', width: 14 },
  { key: 'brandName' as const, header: '品牌', width: 12 },
  { key: 'innerDiameter' as const, header: '内径', width: 8 },
  { key: 'outerDiameter' as const, header: '外径', width: 8 },
  { key: 'width' as const, header: '宽度', width: 8 },
  { key: 'bearingTypeName' as const, header: '类型', width: 12 }
]

function formatValue(bearing: Bearing, key: keyof Bearing): string {
  const value = bearing[key]
  if (typeof value === 'number') return String(value)
  return value ? String(value) : '-'
}

export function formatBearingTable(result: PagedResult<Bearing>): string {
  if (result.items.length === 0) {
    return '未找到匹配的轴承，请尝试调整搜索条件。'
  }

  const headerLine = '| ' + COLUMNS.map(c => padCell(c.header, c.width)).join(' | ') + ' |'
  const separator = '| ' + COLUMNS.map(c => '-'.repeat(c.width)).join(' | ') + ' |'
  const dataLines = result.items.map(bearing =>
    '| ' + COLUMNS.map(c => padCell(formatValue(bearing, c.key), c.width)).join(' | ') + ' |'
  )

  const totalLine = `找到 ${result.total} 条结果（第 ${result.page} 页）：`

  return [totalLine, '', headerLine, separator, ...dataLines].join('\n')
}
