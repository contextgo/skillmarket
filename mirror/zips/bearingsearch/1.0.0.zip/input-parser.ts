import type { SearchParams } from '../../api/types'

interface ParsedInput {
  params: SearchParams
  isExactPartNumber: boolean
  partNumber?: string
}

const PART_NUMBER_PATTERN = /^[0-9]{4,}[A-Z]?$/i
const SIZE_PATTERN = /(?:内径|ID|inner\s*diameter)\s*[:：]?\s*(\d+(?:\.\d+)?)/i
const SIZE_OD_PATTERN = /(?:外径|OD|outer\s*diameter)\s*[:：]?\s*(\d+(?:\.\d+)?)/i
const SIZE_RANGE_PATTERN = /(\d+(?:\.\d+)?)\s*[x×*]\s*(\d+(?:\.\d+)?)\s*[x×*]\s*(\d+(?:\.\d+)?)/
const BRAND_PATTERN = /(?:品牌|brand)\s*[:：]?\s*(.+)/i
const TYPE_PATTERN = /(?:类型|type)\s*[:：]?\s*(.+)/i

export function parseBearingInput(input: string): ParsedInput {
  const trimmed = input.trim()

  const rangeMatch = trimmed.match(SIZE_RANGE_PATTERN)
  if (rangeMatch) {
    const inner = parseFloat(rangeMatch[1])
    const outer = parseFloat(rangeMatch[2])
    const width = parseFloat(rangeMatch[3])
    return {
      params: {
        minInnerDiameter: inner,
        maxInnerDiameter: inner,
        minOuterDiameter: outer,
        maxOuterDiameter: outer,
        minWidth: width,
        maxWidth: width
      },
      isExactPartNumber: false
    }
  }

  if (PART_NUMBER_PATTERN.test(trimmed)) {
    return {
      params: { partNumber: trimmed.toUpperCase() },
      isExactPartNumber: true,
      partNumber: trimmed.toUpperCase()
    }
  }

  const params: SearchParams = {}

  const idMatch = trimmed.match(SIZE_PATTERN)
  if (idMatch) {
    params.minInnerDiameter = parseFloat(idMatch[1])
    params.maxInnerDiameter = parseFloat(idMatch[1])
  }

  const odMatch = trimmed.match(SIZE_OD_PATTERN)
  if (odMatch) {
    params.minOuterDiameter = parseFloat(odMatch[1])
    params.maxOuterDiameter = parseFloat(odMatch[1])
  }

  const brandMatch = trimmed.match(BRAND_PATTERN)
  if (brandMatch) {
    params.keyword = brandMatch[1].trim()
  }

  const typeMatch = trimmed.match(TYPE_PATTERN)
  if (typeMatch) {
    params.bearingTypeId = typeMatch[1].trim()
  }

  const hasStructuredParams = idMatch || odMatch || brandMatch || typeMatch
  if (!hasStructuredParams) {
    params.keyword = trimmed
  }

  return {
    params,
    isExactPartNumber: false
  }
}
