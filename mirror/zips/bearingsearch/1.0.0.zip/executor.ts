import { createApiClient } from '../../api/client.js'
import { createBearingEndpoints } from '../../api/endpoints/index.js'
import type { SkillResult } from '../executor.js'
import { parseSkillFrontmatter, type SkillDefinition } from '../loader.js'
import { parseBearingInput } from './input-parser.js'
import { formatBearingTable } from './output-formatter.js'

const SKILL_MARKDOWN = `---
name: bearing-search
description: 根据型号、品牌、尺寸参数搜索轴承产品
triggers:
  - search
  - find
  - bearing
  - 轴承
  - 搜索
---`

export class BearingSearchExecutor {
  definition: SkillDefinition

  constructor() {
    const parsed = parseSkillFrontmatter(SKILL_MARKDOWN)
    if (!parsed) {
      throw new Error('Failed to parse bearing-search skill definition')
    }
    this.definition = parsed
  }

  async execute(input: string, context: { apiBaseUrl?: string; timeout?: number; getToken?: () => string | null }): Promise<SkillResult> {
    const client = createApiClient({
      baseURL: context.apiBaseUrl,
      timeout: context.timeout,
      getToken: context.getToken
    })
    const bearings = createBearingEndpoints(client)

    const parsed = parseBearingInput(input)

    try {
      if (parsed.isExactPartNumber && parsed.partNumber) {
        const bearing = await bearings.getByPartNumber(parsed.partNumber)
        if (bearing) {
          return {
            success: true,
            output: formatBearingTable({
              items: [bearing],
              total: 1,
              page: 1,
              pageSize: 1
            }),
            data: bearing
          }
        }
      }

      const result = await bearings.search(parsed.params)
      return {
        success: result.items.length > 0,
        output: formatBearingTable(result),
        data: result
      }
    } catch (error) {
      const message = error instanceof Error ? error.message : '搜索轴承时发生错误'
      return {
        success: false,
        output: `搜索失败：${message}`
      }
    }
  }
}
