---
name: bearing-search
description: 根据型号、品牌、尺寸参数搜索轴承产品
triggers:
  - search
  - find
  - bearing
  - 轴承
  - 搜索
---

# Bearing Search Skill

根据用户输入搜索轴承产品数据库。

## 输入参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| keyword | string | 否 | 型号或品牌关键词 |
| partNumber | string | 否 | 精确型号 |
| minInnerDiameter | number | 否 | 最小内径 (mm) |
| maxInnerDiameter | number | 否 | 最大内径 (mm) |
| minOuterDiameter | number | 否 | 最小外径 (mm) |
| maxOuterDiameter | number | 否 | 最大外径 (mm) |
| brandId | string | 否 | 品牌 ID |
| bearingTypeId | string | 否 | 轴承类型 ID |
| page | number | 否 | 页码，默认 1 |
| pageSize | number | 否 | 每页数量，默认 20 |

## 调用的 API

- `GET /api/bearings/search` — 搜索轴承列表
- `GET /api/bearings/by-part/:partNumber` — 按精确型号查询
- `GET /api/bearings/hot` — 热门轴承推荐
- `GET /api/brands` — 品牌列表
- `GET /api/bearing-types` — 轴承类型列表

## 工作流

1. 解析用户输入，提取搜索参数（型号、尺寸范围、品牌等）
2. 调用 `GET /api/bearings/search` 执行搜索
3. 将结果格式化为用户友好的表格或列表
4. 如结果为空，提示用户调整搜索条件

## 输出格式

```
找到 N 条结果（第 X 页）：

| 型号 | 品牌 | 内径 | 外径 | 宽度 | 类型 |
|------|------|------|------|------|------|
| ... | ... | ... | ... | ... | ... |
```
