"""
DeepSeek V4 Pro 一键深度思考工具

双击运行，点击按钮即可启动/停止代理并自动切换 models.json。
"""

import json
import os
import sys
import socket
import subprocess
import threading
import tkinter as tk
from tkinter import ttk
from pathlib import Path

# 路径
MODELS_JSON = os.path.expanduser(r"~\.workbuddy\models.json")
PROXY_SCRIPT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "deepseek_proxy.py")

# 两种配置（端口动态生成）
DIRECT_CONFIG = {
    "url": "https://api.deepseek.com/chat/completions",
    "name": "DeepSeek-V4 Pro",
    "supportsReasoning": False,
}


def find_free_port(start=8900, end=9000):
    """找一个可用端口"""
    for port in range(start, end + 1):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    return 8899  # 兜底


PROXY_PORT = find_free_port()


class DeepSeekTool:
    def __init__(self, root):
        self.root = root
        self.root.title("DeepSeek V4 Pro 深度思考")
        self.root.geometry("480x280")
        self.root.resizable(False, False)

        # 代理进程
        self.proxy_process = None

        # 样式
        self.root.configure(bg="#f5f5f5")
        style = ttk.Style()
        style.theme_use("clam")

        # 状态
        self.status_var = tk.StringVar(value="检测中...")
        self.model_var = tk.StringVar(value="")

        self._build_ui()
        self._check_status()

    def _build_ui(self):
        # 标题
        title = tk.Label(
            self.root, text="DeepSeek V4 Pro 深度思考",
            font=("Microsoft YaHei", 16, "bold"),
            bg="#f5f5f5", fg="#333"
        )
        title.pack(pady=(20, 5))

        desc = tk.Label(
            self.root, text="启动代理后，WorkBuddy 中 DeepSeek V4 Pro 将启用深度思考模式",
            font=("Microsoft YaHei", 9),
            bg="#f5f5f5", fg="#666", wraplength=440
        )
        desc.pack(pady=(0, 15))

        # 状态框
        status_frame = tk.Frame(self.root, bg="#f5f5f5")
        status_frame.pack(fill="x", padx=40, pady=5)

        tk.Label(status_frame, text="代理状态：", font=("Microsoft YaHei", 10),
                 bg="#f5f5f5", fg="#555").pack(side="left")

        self.status_label = tk.Label(status_frame, textvariable=self.status_var,
                                      font=("Microsoft YaHei", 10, "bold"),
                                      bg="#f5f5f5", fg="#999")
        self.status_label.pack(side="left")

        # 模型配置状态
        model_frame = tk.Frame(self.root, bg="#f5f5f5")
        model_frame.pack(fill="x", padx=40, pady=5)

        tk.Label(model_frame, text="当前配置：", font=("Microsoft YaHei", 10),
                 bg="#f5f5f5", fg="#555").pack(side="left")

        self.model_label = tk.Label(model_frame, textvariable=self.model_var,
                                     font=("Microsoft YaHei", 10),
                                     bg="#f5f5f5", fg="#555")
        self.model_label.pack(side="left")

        # 按钮
        btn_frame = tk.Frame(self.root, bg="#f5f5f5")
        btn_frame.pack(pady=(20, 10))

        self.toggle_btn = tk.Button(
            btn_frame, text="启动深度思考", width=18, height=2,
            font=("Microsoft YaHei", 11, "bold"),
            bg="#4a90d9", fg="white", activebackground="#357abd",
            activeforeground="white", relief="flat", cursor="hand2",
            command=self._toggle_proxy,
        )
        self.toggle_btn.pack()

        # 提示
        tip = tk.Label(
            self.root,
            text="启动后重启 WorkBuddy 即可使用深度思考模式\n关闭代理后自动恢复普通模式",
            font=("Microsoft YaHei", 8),
            bg="#f5f5f5", fg="#999", justify="center"
        )
        tip.pack(pady=(5, 0))

        # 关闭时清理
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

    def _check_status(self):
        """检查代理运行状态和 models.json 配置"""
        # 检查代理进程
        if self.proxy_process and self.proxy_process.poll() is None:
            self.status_var.set("● 运行中")
            self.status_label.config(fg="#27ae60")
            self.toggle_btn.config(text="停止深度思考", bg="#e74c3c", activebackground="#c0392b")
        else:
            self.status_var.set("○ 已停止")
            self.status_label.config(fg="#999")
            self.toggle_btn.config(text="启动深度思考", bg="#4a90d9", activebackground="#357abd")

        # 检查 models.json 配置
        try:
            with open(MODELS_JSON, "r", encoding="utf-8") as f:
                models = json.load(f)
            for m in models.get("models", []):
                if m.get("id") == "deepseek-v4-pro":
                    reasoning = m.get("supportsReasoning", False)
                    self.model_var.set(f"{'深度思考' if reasoning else '普通模式'}")
                    break
        except Exception:
            self.model_var.set("未知")

        self.root.after(2000, self._check_status)

    def _toggle_proxy(self):
        if self.proxy_process and self.proxy_process.poll() is None:
            self._stop_proxy()
        else:
            self._start_proxy()

    def _start_proxy(self):
        def run():
            try:
                port = PROXY_PORT
                proxy_config = {
                    "url": f"http://127.0.0.1:{port}/v1/chat/completions",
                    "name": "DeepSeek-V4 Pro (代理)",
                    "supportsReasoning": True,
                }

                # 1. 切换 models.json
                self._switch_config(proxy_config)

                # 2. 启动代理
                self.proxy_process = subprocess.Popen(
                    [sys.executable, PROXY_SCRIPT, "--port", str(port)],
                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    creationflags=subprocess.CREATE_NO_WINDOW,
                )

                # 等待几秒确认启动
                import time
                time.sleep(2)

                if self.proxy_process.poll() is None:
                    self.root.after(0, lambda p=port: self._show_msg(f"深度思考已启动 (端口 {p})\n请重启 WorkBuddy 后选择「DeepSeek-V4 Pro (代理)」"))
                else:
                    self.root.after(0, lambda: self._show_msg("代理启动失败\n请检查是否有其他程序占用了端口"))
            except Exception as e:
                self.root.after(0, lambda e=e: self._show_msg(f"启动失败：{str(e)}"))

        threading.Thread(target=run, daemon=True).start()

    def _stop_proxy(self):
        def run():
            try:
                # 1. 终止代理进程
                if self.proxy_process:
                    self.proxy_process.terminate()
                    self.proxy_process.wait(timeout=5)
                    self.proxy_process = None

                # 2. 切换回直接连接
                self._switch_config(DIRECT_CONFIG)

                self.root.after(0, lambda: self._show_msg("深度思考已关闭\n已恢复普通模式，请重启 WorkBuddy"))
            except Exception as e:
                self.root.after(0, lambda e=e: self._show_msg(f"关闭失败：{str(e)}"))

        threading.Thread(target=run, daemon=True).start()

    def _switch_config(self, target_config):
        """切换 models.json 中 deepseek-v4-pro 的配置"""
        with open(MODELS_JSON, "r", encoding="utf-8") as f:
            models = json.load(f)

        for m in models.get("models", []):
            if m.get("id") == "deepseek-v4-pro":
                m["url"] = target_config["url"]
                m["name"] = target_config["name"]
                m["supportsReasoning"] = target_config["supportsReasoning"]
                break

        with open(MODELS_JSON, "w", encoding="utf-8") as f:
            json.dump(models, f, indent=2, ensure_ascii=False)

    def _show_msg(self, msg):
        """弹出提示窗口"""
        win = tk.Toplevel(self.root)
        win.title("提示")
        win.geometry("380x160")
        win.resizable(False, False)
        win.transient(self.root)
        win.grab_set()

        # 居中
        win.update_idletasks()
        x = self.root.winfo_x() + (self.root.winfo_width() - 380) // 2
        y = self.root.winfo_y() + (self.root.winfo_height() - 160) // 2
        win.geometry(f"+{x}+{y}")

        tk.Label(win, text=msg, font=("Microsoft YaHei", 10),
                 wraplength=340, justify="center").pack(expand=True, pady=20)

        tk.Button(win, text="知道了", width=12,
                  command=win.destroy).pack(pady=10)

    def _on_close(self):
        """关闭窗口时清理"""
        if self.proxy_process and self.proxy_process.poll() is None:
            self.proxy_process.terminate()
            self._switch_config(DIRECT_CONFIG)
        self.root.destroy()


def main():
    root = tk.Tk()
    DeepSeekTool(root)
    root.mainloop()


if __name__ == "__main__":
    main()
