"""
DeepSeek Reasoning Proxy v7
================================================================
v7 关键修复：
1. 占位符策略改变：找不到 hash 匹配时，注入 store 里的一条「真实历史 reasoning」
   作为兜底，而不是 v6 的英文占位字符串（DeepSeek 会拒绝占位符）。
   真实 reasoning 是模型自己生成过的合法 thinking 输出，DeepSeek 一定接受。
2. 日志去重：同一个 key 短时间内重复"无匹配"时折叠成一行，避免刷屏。
3. ConnectionAborted (10053) 降级为 DEBUG —— 这是客户端主动断开（如取消请求），
   不是错误。
4. 极端情况下（store 为空）才退回到一段中文兜底文本。

兼容性：API 与 v5/v6 一致，deepseek_tool.py 不需改。
"""

import argparse
import hashlib
import json
import logging
import logging.handlers
import os
import sys
import threading
import time
import traceback
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

# ---------- 配置 ----------
UPSTREAM_URL = "https://api.deepseek.com/chat/completions"
STORE_DIR = Path.home() / ".workbuddy"
STORE_DIR.mkdir(parents=True, exist_ok=True)
STORE_FILE = STORE_DIR / "deepseek_reasoning_store.json"
LOG_FILE = STORE_DIR / "deepseek_proxy.log"
MAX_STORE_ENTRIES = 500
DEBUG = os.environ.get("DEEPSEEK_PROXY_DEBUG") == "1"

# 极端兜底：store 完全为空时使用，看起来像合法 thinking 输出
GENERIC_FALLBACK = (
    "根据上下文，需要继续执行下一步操作以完成用户的请求。"
    "我将基于当前已有信息调用合适的工具。"
)

# ---------- 日志 ----------
log = logging.getLogger("deepseek_proxy")
log.setLevel(logging.DEBUG if DEBUG else logging.INFO)
_log_fmt = logging.Formatter(
    "%(asctime)s [%(levelname)s] %(message)s", datefmt="%H:%M:%S"
)
_fh = logging.handlers.RotatingFileHandler(
    LOG_FILE, maxBytes=5 * 1024 * 1024, backupCount=3, encoding="utf-8"
)
_fh.setFormatter(_log_fmt)
log.addHandler(_fh)
_sh = logging.StreamHandler(sys.stderr)
_sh.setFormatter(_log_fmt)
log.addHandler(_sh)


# ---------- 全局状态 ----------
reasoning_store: dict = {}      # key -> reasoning_content
last_real_reasoning: str = ""   # 最近一次成功响应的 reasoning（兜底用）
store_lock = threading.Lock()

# 日志去重（key+消息位置 -> 上次报告时间）
_logged_misses: dict = {}
_LOG_DEDUP_WINDOW = 30.0  # 30 秒内同一 key+pos 只打一次


# ---------- 持久化 ----------
def load_store():
    global reasoning_store, last_real_reasoning
    try:
        if STORE_FILE.exists():
            with open(STORE_FILE, "r", encoding="utf-8") as f:
                reasoning_store = json.load(f)
            log.info(f"加载 {len(reasoning_store)} 条 reasoning <- {STORE_FILE}")
            # 找最长的一条作为初始兜底
            if reasoning_store:
                last_real_reasoning = max(reasoning_store.values(), key=len)
                log.info(f"初始兜底 reasoning 长度: {len(last_real_reasoning)} 字符")
    except Exception as e:
        log.warning(f"加载 store 失败: {e}")
        reasoning_store = {}


def save_store():
    try:
        with store_lock:
            if len(reasoning_store) > MAX_STORE_ENTRIES:
                items = list(reasoning_store.items())[-MAX_STORE_ENTRIES:]
                reasoning_store.clear()
                reasoning_store.update(items)
            snapshot = dict(reasoning_store)
        tmp = STORE_FILE.with_suffix(".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(snapshot, f, ensure_ascii=False)
        os.replace(tmp, STORE_FILE)
    except Exception as e:
        log.warning(f"保存 store 失败: {e}")


# ---------- Hash ----------
def _normalize_arguments(args):
    if isinstance(args, dict):
        return args
    if isinstance(args, str):
        try:
            return json.loads(args)
        except json.JSONDecodeError:
            return args
    return args


def assistant_key(msg: dict) -> str:
    content = msg.get("content") or ""
    raw_calls = msg.get("tool_calls") or []
    stable_calls = []
    for tc in raw_calls:
        if not isinstance(tc, dict):
            continue
        fn = tc.get("function", {}) or {}
        stable_calls.append({
            "name": fn.get("name", ""),
            "arguments": _normalize_arguments(fn.get("arguments", "")),
        })
    payload = json.dumps(
        {"content": content, "tool_calls": stable_calls},
        ensure_ascii=False, sort_keys=True,
    )
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:16]


def must_have_reasoning(msg: dict) -> bool:
    return bool(msg.get("tool_calls"))


def get_fallback_reasoning() -> str:
    """获取兜底用的真实 reasoning（DeepSeek 一定接受）"""
    if last_real_reasoning:
        return last_real_reasoning
    # 尝试从 store 取
    with store_lock:
        if reasoning_store:
            return next(iter(reasoning_store.values()))
    # 极端兜底
    return GENERIC_FALLBACK


def _should_log_miss(key: str, pos: int) -> bool:
    """日志去重：同一 (key, pos) 在窗口内只打一次"""
    now = time.time()
    fingerprint = f"{key}:{pos}"
    last = _logged_misses.get(fingerprint, 0)
    if now - last < _LOG_DEDUP_WINDOW:
        return False
    _logged_misses[fingerprint] = now
    # 顺便清理过期项，避免无限增长
    if len(_logged_misses) > 1000:
        cutoff = now - _LOG_DEDUP_WINDOW * 2
        for k in list(_logged_misses.keys()):
            if _logged_misses[k] < cutoff:
                del _logged_misses[k]
    return True


# ---------- 注入 / 存储 ----------
def inject_reasoning(messages: list) -> dict:
    injected = fallback_used = skipped = 0
    detail_lines = []

    fallback = get_fallback_reasoning()

    with store_lock:
        for i, msg in enumerate(messages):
            if msg.get("role") != "assistant":
                continue

            existing = msg.get("reasoning_content")
            if existing:
                # 已有 reasoning：刷新到 store
                reasoning_store[assistant_key(msg)] = existing
                continue

            if not must_have_reasoning(msg):
                skipped += 1
                continue

            key = assistant_key(msg)
            if key in reasoning_store:
                msg["reasoning_content"] = reasoning_store[key]
                injected += 1
                detail_lines.append(
                    f"  ✓ msg[{i}] 命中 hash, 注入 {len(reasoning_store[key])} 字符"
                )
            else:
                # 兜底：用一段真实历史 reasoning
                msg["reasoning_content"] = fallback
                fallback_used += 1
                if _should_log_miss(key, i):
                    tools = [
                        (tc.get("function") or {}).get("name")
                        for tc in (msg.get("tool_calls") or [])
                    ]
                    detail_lines.append(
                        f"  ⚠ msg[{i}] hash 未命中, 用兜底 reasoning  "
                        f"key={key} tools={tools}"
                    )

    return {
        "injected": injected,
        "fallback_used": fallback_used,
        "skipped": skipped,
        "details": detail_lines,
    }


def store_response(response_msg: dict):
    global last_real_reasoning
    if not response_msg:
        return
    reasoning = response_msg.get("reasoning_content") or ""
    if not reasoning:
        return
    key = assistant_key(response_msg)
    with store_lock:
        reasoning_store[key] = reasoning
        # 更新兜底（用足够长的，避免太短的"嗯"之类）
        if len(reasoning) >= 50:
            last_real_reasoning = reasoning
    save_store()
    has_tools = bool(response_msg.get("tool_calls"))
    log.info(f"存储 key={key} reasoning={len(reasoning)} 字符 tool_calls={has_tools}")


# ---------- HTTP ----------
def is_streaming(body: dict) -> bool:
    return bool(body.get("stream"))


class ProxyHandler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass

    def do_GET(self):
        path = self.path.split("?")[0]
        if path == "/debug":
            with store_lock:
                payload = {
                    "stored": len(reasoning_store),
                    "keys_tail": list(reasoning_store.keys())[-20:],
                    "fallback_len": len(last_real_reasoning),
                    "log_file": str(LOG_FILE),
                    "store_file": str(STORE_FILE),
                }
            self._send_json(200, payload)
            return
        with store_lock:
            count = len(reasoning_store)
        self._send_json(200, {
            "status": "ok",
            "service": "DeepSeek Reasoning Proxy v7",
            "stored": count,
            "fallback_ready": bool(last_real_reasoning),
            "log_file": str(LOG_FILE),
            "store_file": str(STORE_FILE),
            "debug_mode": DEBUG,
        })

    def do_POST(self):
        try:
            length = int(self.headers.get("Content-Length", 0))
            body_bytes = self.rfile.read(length)
            body = json.loads(body_bytes)
        except Exception as e:
            log.warning(f"请求体解析失败: {e}")
            self._send_json(400, {"error": f"invalid request body: {e}"})
            return

        if DEBUG:
            self._dump_request(body)

        result = inject_reasoning(body.get("messages", []))
        if result["injected"] or result["fallback_used"]:
            log.info(
                f"注入: 命中={result['injected']} 兜底={result['fallback_used']} "
                f"普通={result['skipped']}"
            )
            for line in result["details"]:
                log.info(line)
        else:
            log.debug(f"注入: 普通={result['skipped']}")

        modified_body = json.dumps(body, ensure_ascii=False).encode("utf-8")
        req_headers = {
            "Content-Type": "application/json",
            "Authorization": self.headers.get("Authorization", ""),
            "Accept": "text/event-stream" if is_streaming(body) else "application/json",
        }
        req = Request(UPSTREAM_URL, data=modified_body, headers=req_headers, method="POST")

        try:
            with urlopen(req, timeout=300) as upstream:
                resp_bytes = upstream.read()
                resp_status = upstream.status

                if not is_streaming(body):
                    self._store_from_full_response(resp_bytes)
                else:
                    self._store_from_stream_response(resp_bytes)

                self.send_response(resp_status)
                for k, v in upstream.headers.items():
                    if k.lower() in ("transfer-encoding", "connection",
                                     "content-encoding", "content-length"):
                        continue
                    self.send_header(k, v)
                self.send_header("Content-Length", str(len(resp_bytes)))
                self.end_headers()
                try:
                    self.wfile.write(resp_bytes)
                except (ConnectionAbortedError, ConnectionResetError, BrokenPipeError) as e:
                    # 客户端主动断开（用户取消请求），不是错误
                    log.debug(f"客户端断开: {e}")
                log.debug(f"上游 {resp_status} ({len(resp_bytes)} bytes) 已透传")

        except HTTPError as e:
            err_body = e.read().decode("utf-8", errors="replace")
            log.error(f"上游 HTTP {e.code}: {err_body}")
            self._dump_request_on_error(body)
            try:
                self.send_response(e.code)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(err_body.encode("utf-8"))
            except (ConnectionAbortedError, ConnectionResetError, BrokenPipeError):
                pass
        except URLError as e:
            log.error(f"连接错误: {e.reason}")
            self._send_json(502, {"error": f"代理无法连接上游: {e.reason}"})
        except (ConnectionAbortedError, ConnectionResetError, BrokenPipeError) as e:
            log.debug(f"客户端断开（请求处理中）: {e}")
        except Exception as e:
            log.error(f"代理异常: {e}\n{traceback.format_exc()}")
            try:
                self._send_json(500, {"error": str(e)})
            except (ConnectionAbortedError, ConnectionResetError, BrokenPipeError):
                pass

    # ---------- helpers ----------
    def _send_json(self, code: int, payload: dict):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _store_from_full_response(self, resp_bytes: bytes):
        try:
            resp = json.loads(resp_bytes)
            msg = resp.get("choices", [{}])[0].get("message", {})
            if msg:
                store_response(msg)
        except Exception as e:
            log.warning(f"解析非流式响应失败: {e}")

    def _store_from_stream_response(self, resp_bytes: bytes):
        try:
            text = resp_bytes.decode("utf-8", errors="replace")
            content_parts, reasoning_parts = [], []
            tool_acc: dict = {}

            for line in text.split("\n"):
                if not line.startswith("data: ") or line.strip() == "data: [DONE]":
                    continue
                try:
                    chunk = json.loads(line[6:])
                except json.JSONDecodeError:
                    continue
                delta = chunk.get("choices", [{}])[0].get("delta", {}) or {}
                if delta.get("reasoning_content"):
                    reasoning_parts.append(delta["reasoning_content"])
                if delta.get("content"):
                    content_parts.append(delta["content"])
                for tc in (delta.get("tool_calls") or []):
                    idx = tc.get("index", 0)
                    slot = tool_acc.setdefault(idx, {"function": {"name": "", "arguments": ""}})
                    fn = tc.get("function") or {}
                    if fn.get("name"):
                        slot["function"]["name"] = fn["name"]
                    if fn.get("arguments"):
                        slot["function"]["arguments"] += fn["arguments"]

            virtual_msg = {
                "content": "".join(content_parts),
                "tool_calls": [tool_acc[i] for i in sorted(tool_acc)] if tool_acc else None,
                "reasoning_content": "".join(reasoning_parts),
            }
            store_response(virtual_msg)
        except Exception as e:
            log.warning(f"流式存储异常: {e}")

    def _dump_request(self, body: dict):
        msgs = body.get("messages", [])
        log.debug(f"请求 messages 数={len(msgs)} stream={body.get('stream')}")
        for i, m in enumerate(msgs):
            role = m.get("role")
            tc = m.get("tool_calls")
            rc = m.get("reasoning_content")
            tag = []
            if tc:
                tag.append(f"tool_calls={len(tc)}")
            if rc is not None:
                tag.append(f"rc_len={len(rc)}")
            content = m.get("content") or ""
            preview = (content[:60] + "...") if len(content) > 60 else content
            log.debug(f"  [{i}] {role} {' '.join(tag)} content={preview!r}")

    def _dump_request_on_error(self, body: dict):
        try:
            msgs = body.get("messages", [])
            log.error(f"--- 出错请求 messages 概要 (共 {len(msgs)} 条) ---")
            for i, m in enumerate(msgs):
                role = m.get("role")
                tc = m.get("tool_calls")
                rc = m.get("reasoning_content")
                content = m.get("content") or ""
                preview = (content[:80] + "...") if len(content) > 80 else content
                log.error(
                    f"  [{i}] {role} "
                    f"tool_calls={len(tc) if tc else 0} "
                    f"rc_len={len(rc) if rc is not None else 'MISSING'} "
                    f"content={preview!r}"
                )
            log.error("--- end ---")
        except Exception as e:
            log.error(f"dump 请求失败: {e}")


def main():
    parser = argparse.ArgumentParser(description="DeepSeek Reasoning Proxy v7")
    parser.add_argument("--port", type=int, default=8899)
    args = parser.parse_args()

    load_store()
    server = HTTPServer(("127.0.0.1", args.port), ProxyHandler)
    log.info(f"DeepSeek Reasoning Proxy v7 启动")
    log.info(f"  监听: http://127.0.0.1:{args.port}/v1/chat/completions")
    log.info(f"  上游: {UPSTREAM_URL}")
    log.info(f"  Store: {STORE_FILE} (已加载 {len(reasoning_store)} 条)")
    log.info(f"  Log:   {LOG_FILE}")
    log.info(f"  Debug: {DEBUG}")
    log.info(f"  兜底 reasoning: {len(last_real_reasoning)} 字符")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        save_store()
        log.info("已保存并退出")
        server.shutdown()


if __name__ == "__main__":
    main()
