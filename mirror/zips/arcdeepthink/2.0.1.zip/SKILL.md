---
name: deepseek-reasoning-proxy
description: 为 WorkBuddy 启用 DeepSeek 深度思考（reasoning）模式的本地代理工具。当用户在 WorkBuddy 中使用 DeepSeek 模型并需要开启深度思考/推理能力时使用此 skill。包含一键启动 GUI 工具和纯终端两种方式。触发词：深度思考、推理、reasoning、DeepSeek 深度思考、一键深度思考、开启推理模式。
---

# DeepSeek Reasoning Proxy v7

## Overview

DeepSeek 的深度思考（reasoning）模式需要在多轮对话中回传 `reasoning_content` 字段，但 WorkBuddy 的 Agentic 模式在 spawning sub-agent 时会丢失这个字段，导致 DeepSeek API 报错 `"The reasoning_content in the thinking mode must be passed back to the API"`。

这个 skill 提供一个本地 HTTP 代理，拦截 WorkBuddy → DeepSeek 的请求，自动缓存并回注 `reasoning_content`，让深度思考在 WorkBuddy 中正常工作。

**v7 关键改进**：
- **稳定性提升**：找不到 hash 匹配时，注入 store 里的一条「真实历史 reasoning」作为兜底，而不是英文占位字符串（DeepSeek 会拒绝占位符）。真实 reasoning 是模型自己生成过的合法 thinking 输出，DeepSeek 一定接受。
- **日志去重**：同一个 key 短时间内重复"无匹配"时折叠成一行，避免刷屏。
- **错误处理优化**：ConnectionAborted (10053) 降级为 DEBUG —— 这是客户端主动断开（如取消请求），不是错误。
- **极端兜底**：极端情况下（store 为空）才退回到一段中文兜底文本。

## Quick Start

### 方式一：双击 GUI（推荐）

1. **删除 .txt 扩展名**：将 `scripts/start_deepthinking.bat.txt` 重命名为 `start_deepthinking.bat`（删除 `.txt` 扩展名）。
2. **双击启动**：双击 `scripts/start_deepthinking.bat`，会弹出一个小窗口：
   - **点击「启动深度思考」** → 启动本地代理 + 自动修改 `~/.workbuddy/models.json` 把 DeepSeek 的 URL 指向代理
   - **点击「停止深度思考」** → 关闭代理 + 恢复直连
3. **重启 WorkBuddy**，在模型选择中选 `DeepSeek-V4 Pro (代理)` 即可使用深度思考。

**注意**：此版本以略微降低深度思考能力为代价，换取整体代理稳定性。若需恢复原版性能，可回退至 v6 或更早版本。

### 方式二：终端手动启动

```bash
python scripts/deepseek_proxy.py --port 8899
```

然后在 `~/.workbuddy/models.json` 中手动修改对应 model 的配置：
- `url` 改为 `http://127.0.0.1:8899/v1/chat/completions`
- `supportsReasoning` 设为 `true`

## 前置条件

1. 在 `~/.workbuddy/models.json` 中已有 DeepSeek 模型的配置（model id 为 `deepseek-v4-pro`）
2. 配置了有效的 DeepSeek API Key
3. Python 3.7+（标准库，无需额外依赖）

## 文件说明

| 文件 | 说明 |
|------|------|
| `scripts/deepseek_proxy.py` | 核心代理脚本 v7，拦截请求并缓存/回注 reasoning_content |
| `scripts/deepseek_tool.py` | GUI 工具，提供一键启动/停止代理并自动切换 models.json |
| `scripts/start_deepthinking.bat` | Windows 快捷方式，双击打开 GUI 工具（需删除 .txt 扩展名） |

## 工作原理

1. WorkBuddy 发送请求到本地代理（`http://127.0.0.1:PORT`）
2. 代理检查请求中的 assistant messages，若缺少 `reasoning_content`，从缓存中按索引位置回注
3. 代理转发请求到 `https://api.deepseek.com/chat/completions`
4. 收到响应后，提取 `reasoning_content` 按 assistant 消息索引缓存，供后续轮次使用
5. 支持流式（SSE）和非流式两种响应模式

## 故障排除

- **代理启动失败**：检查端口是否被占用（默认 8899），可手动指定 `--port` 参数。
- **深度思考未生效**：确认 `models.json` 中对应模型的 `supportsReasoning` 为 `true`，且 URL 指向代理地址。
- **日志查看**：代理日志位于 `~/.workbuddy/deepseek_proxy.log`，可查看详细运行状态。
- **恢复原版**：如需恢复原版深度思考能力，可替换 `deepseek_proxy.py` 为 v6 版本。