---
name: lead-generator
description: 潜客挖掘 - 自动搜索潜在客户，生成线索列表。支持行业、关键词搜索，导出联系方式。适用于销售、市场人员。
---

# 潜客挖掘 (Lead Generator)

## 功能

- 按行业/关键词搜索潜在客户
- 抓取联系信息
- 生成潜客列表
- 导出 CSV/Excel

## 使用方式

```bash
lead-generator "AI 初创公司" --location China
```

## 价格

- 免费版：10条/次
- 专业版：¥199/月：无限制
- 企业版：¥599/月：API接入
