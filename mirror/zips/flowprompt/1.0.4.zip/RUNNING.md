# FlowPrompt Studio 技能运行描述与工作流

## 技能概述

FlowPrompt Studio 技能集是一个工程化问题描述和 Prompt 生成工具，旨在帮助用户创建高质量的 AI 提示词。该技能集包含 5 个核心技能，协同工作以提供完整的 Prompt 生成流程。

## 技能运行环境

### 系统要求
- **运行环境**: SOLO 平台沙箱环境
- **工作目录**: /data/user/work（临时文件）、/workspace（最终交付物）
- **技能存放**: /data/user/skills/（用户技能）或 /data/user/builtin/（内置技能）
- **依赖**: 可选依赖 `node-fetch@^3.3.2`（用于网络请求）

### 可用工具
- 文件操作：Read、Write、SearchReplace、Glob、Grep、LS、DeleteFile
- 命令执行：RunCommand（Bash）
- 网络：WebSearch、WebFetch
- 浏览器：MCP Browser 工具
- 技能调用：Skill 工具
- 子代理：Task（Explore / Plan / general_purpose_task）
- 图片生成：GenerateImage

## 核心技能运行描述

### 1. FlowPrompt-Form 技能

**功能**: 管理结构化表单数据，提供项目类型和 AI 助手选项，验证表单数据

**运行流程**:
1. **获取空表单**: 调用 `getEmptyForm` 操作获取默认表单结构
2. **获取选项**: 调用 `getProjectTypeOptions` 和 `getTargetAIOptions` 获取可用选项
3. **验证表单**: 调用 `validateForm` 验证表单数据完整性
4. **更新表单**: 调用 `updateForm` 更新表单数据
5. **添加试错记录**: 调用 `addAttempt` 添加试错记录
6. **添加验收标准**: 调用 `addCriteria` 添加验收标准

### 2. FlowPrompt-Validator 技能

**功能**: 验证表单数据完整性，计算质量评分，生成验证摘要

**运行流程**:
1. **验证表单**: 调用 `validate` 操作验证表单数据并计算质量评分
2. **生成摘要**: 调用 `generateSummary` 生成验证摘要
3. **检查生成条件**: 调用 `canGeneratePrompt` 检查是否满足生成 Prompt 的条件

### 3. FlowPrompt-Generator 技能

**功能**: 生成标准化的 Prompt，生成 Prompt 摘要，优化 Prompt 格式

**运行流程**:
1. **生成 Prompt**: 调用 `generate` 操作根据表单数据生成标准化 Prompt
2. **生成摘要**: 调用 `generateSummary` 生成 Prompt 摘要
3. **优化 Prompt**: 调用 `optimizePrompt` 优化 Prompt 格式

### 4. FlowPrompt-Draft 技能

**功能**: 保存和管理草稿，获取草稿列表，获取最新草稿，删除草稿

**运行流程**:
1. **保存草稿**: 调用 `saveDraft` 保存表单数据为草稿
2. **获取草稿列表**: 调用 `getDraftList` 获取所有草稿
3. **获取单个草稿**: 调用 `getDraft` 获取指定 ID 的草稿
4. **获取最新草稿**: 调用 `getLatestDraft` 获取最新保存的草稿
5. **更新草稿**: 调用 `updateDraft` 更新草稿内容
6. **删除草稿**: 调用 `deleteDraft` 删除指定草稿
7. **清空草稿**: 调用 `clearAllDrafts` 清空所有草稿

### 5. FlowPrompt-Connector 技能

**功能**: 连接不同的 AI 助手，检查连接状态，发送 Prompt 到 AI 助手

**运行流程**:
1. **发送 Prompt**: 调用 `sendPrompt` 发送 Prompt 到指定的 AI 助手
2. **检查连接状态**: 调用 `checkConnection` 检查 AI 助手的连接状态
3. **获取 AI 列表**: 调用 `getSupportedAIList` 获取支持的 AI 助手列表
4. **获取配置建议**: 调用 `getAIConfigSuggestion` 获取 AI 助手的配置建议

## 完整工作流

### 标准工作流

1. **表单初始化**
   - 调用 FlowPrompt-Form 技能获取空表单
   - 获取项目类型和 AI 助手选项

2. **表单填写**
   - 用户填写表单数据
   - 添加试错记录和验收标准
   - 验证表单数据完整性

3. **质量验证**
   - 调用 FlowPrompt-Validator 技能验证表单
   - 计算质量评分
   - 检查是否满足生成条件

4. **Prompt 生成**
   - 调用 FlowPrompt-Generator 技能生成标准化 Prompt
   - 优化 Prompt 格式
   - 生成 Prompt 摘要

5. **草稿管理**
   - 调用 FlowPrompt-Draft 技能保存草稿
   - 管理草稿版本

6. **AI 交互**
   - 调用 FlowPrompt-Connector 技能发送 Prompt 到 AI 助手
   - 检查 AI 助手连接状态

### 工作流示例

```javascript
// 1. 初始化表单
const emptyForm = await flowprompt.callSkill('form', 'getEmptyForm');
const projectTypes = await flowprompt.callSkill('form', 'getProjectTypeOptions');
const aiOptions = await flowprompt.callSkill('form', 'getTargetAIOptions');

// 2. 填写表单
const updatedForm = await flowprompt.callSkill('form', 'updateForm', {
  currentData: emptyForm.data,
  updates: {
    targetAI: 'Trae CN',
    step1: {
      projectType: 'web-frontend',
      techStack: ['React', 'TypeScript', 'Vite'],
      problemDescription: '如何实现一个响应式的导航栏组件'
    },
    // 其他步骤数据...
  }
});

// 3. 验证表单
const validation = await flowprompt.callSkill('validator', 'validate', updatedForm.data);
const canGenerate = await flowprompt.callSkill('validator', 'canGeneratePrompt', validation.data);

// 4. 生成 Prompt
if (canGenerate.data.canGenerate) {
  const prompt = await flowprompt.callSkill('generator', 'generate', updatedForm.data);
  const optimizedPrompt = await flowprompt.callSkill('generator', 'optimizePrompt', prompt.data);
  
  // 5. 保存草稿
  await flowprompt.callSkill('draft', 'saveDraft', {
    name: '响应式导航栏组件',
    formData: updatedForm.data
  });
  
  // 6. 发送到 AI
  const result = await flowprompt.callSkill('connector', 'sendPrompt', {
    aiType: 'trae-cn',
    prompt: optimizedPrompt.data
  });
  
  console.log('AI 响应:', result.data.response);
}
```

## 技能调用方式

### 通过 SOLO 平台调用

在 SOLO 平台中，可以通过以下方式调用技能：

```javascript
const flowprompt = new Skill('flowprompt');
const result = await flowprompt.run('form', {
  action: 'getEmptyForm'
});
```

### 直接调用技能模块

也可以直接调用各个技能模块：

```javascript
const FlowPromptForm = require('./skills/flowprompt-form');
const formSkill = new FlowPromptForm();
const result = await formSkill.run({ action: 'getEmptyForm' });
```

## 配置选项

### 全局配置
- **default_ai**: 默认 AI 助手（默认：trae-cn）
- **max_drafts**: 最大草稿数（默认：100）
- **prompt_timeout**: Prompt 超时时间（默认：30000ms）

### 环境变量
- **NODE_ENV**: 运行环境（development/production）
- **FLOWPROMPT_DEBUG**: 是否启用调试模式（true/false）

## 错误处理

所有技能操作都会返回标准的响应格式：

```javascript
{
  success: boolean,        // 操作是否成功
  message: string,         // 操作结果消息
  data: any,              // 操作返回的数据
  error: string           // 错误信息（如果失败）
}
```

## 性能优化

1. **缓存机制**: 技能会缓存常用数据，减少重复计算
2. **异步操作**: 网络请求和耗时操作都使用异步处理
3. **资源管理**: 草稿存储使用文件系统，避免内存溢出
4. **错误重试**: 网络请求失败时会自动重试

## 安全注意事项

1. **数据安全**: 草稿数据存储在本地文件系统，不会上传到服务器
2. **网络安全**: 所有网络请求都使用 HTTPS
3. **权限控制**: 技能操作需要适当的权限才能执行
4. **输入验证**: 所有用户输入都会经过验证，防止注入攻击

## 平台兼容性

- **SOLO 平台**: 完全支持
- **龙虾平台**: 完全支持
- **其他平台**: 可通过适配器实现兼容

## 版本历史

- **v1.0.0** (2026-04-09): 初始版本
  - 实现 5 个核心技能
  - 支持完整的 Prompt 生成流程
  - 兼容 SOLO 和龙虾平台
