---
name: flowprompt
description: 全链路工程化AI开发体系 — 需求收敛·7表单·评分·Prompt生成
version: "3.1.0"
author: FlowPrompt Studio Team
license: "AGPL-3.0"
allowed-tools:
  - Read
  - Write
  - SearchReplace
  - Glob
  - Grep
  - LS
  - DeleteFile
  - RunCommand
---

# FlowPrompt Studio v3.1

> 基于"6表单全链路工程化AI开发体系"的 AI 辅助开发技能集。
> 从模糊想法到结构化 Prompt，6 个子技能协同工作。

## 核心流程

```
模糊想法 → [收敛引擎] → 7表单数据 → [评分引擎] → 结构化Prompt → [连接器] → AI助手
              ↑              ↑              ↑              ↑
         flowprompt-    flowprompt-    flowprompt-    flowprompt-
         converge        form+validator  generator      connector
```

## 技能列表（6个子技能）

### 1. FlowPrompt-Converge（需求收敛引擎）🆕
- **ID**: flowprompt-converge
- **描述**: 将模糊想法收敛为7表单可用的结构化数据。支持两种模式：一键收敛（quickConverge）和5轮交互式收敛（start→answer×5）
- **入口**: skills/flowprompt-converge/index.js
- **Actions**: `start`, `answer`, `quickConverge`, `getNextQuestion`, `validateDraft`
- **标签**: convergence, nlp, extraction

### 2. FlowPrompt-Form（7表单管理）
- **ID**: flowprompt-form
- **描述**: 管理7表单结构化数据（表单0-6），提供74个核心字段，覆盖项目定义、PRD需求、TDD测试、模块开发、风险管控、验收标准、输出配置
- **入口**: skills/flowprompt-form/index.js
- **Actions**: `getEmptyForm`, `getProjectTypeOptions`, `getTargetAIOptions`, `getRequiredFields`, `validateForm`, `updateForm`
- **标签**: form, data-management

### 3. FlowPrompt-Validator（评分引擎）
- **ID**: flowprompt-validator
- **描述**: 6阶段权重评分（30+25+15+10+10+10=100分）+ 6项一票否决（硬约束红线）+ 阶段上限截断
- **入口**: skills/flowprompt-validator/index.js
- **Actions**: `validate`, `generateSummary`, `canGeneratePrompt`
- **标签**: validation, scoring, quality-assurance

### 4. FlowPrompt-Generator（Prompt生成器）
- **ID**: flowprompt-generator
- **描述**: 基于7表单数据生成结构化Prompt，包含`<form-0>`到`<form-6>`标签、硬约束红线、风险矩阵、验收标准
- **入口**: skills/flowprompt-generator/index.js
- **Actions**: `generate`, `generateSummary`, `optimizePrompt`
- **标签**: prompt, generator

### 5. FlowPrompt-Draft（草稿管理）
- **ID**: flowprompt-draft
- **描述**: 草稿的CRUD操作，存储路径支持`$FLOWPROMPT_HOME`环境变量
- **入口**: skills/flowprompt-draft/index.js
- **Actions**: `save`, `read`, `update`, `delete`, `list`, `getLatest`, `clear`
- **标签**: draft, persistence

### 6. FlowPrompt-Connector（AI连接器）
- **ID**: flowprompt-connector
- **描述**: 连接AI助手（Trae CN/豆包/DeepSeek/GPT/Claude/Cursor/Copilot），⚠️ 当前为Mock实现
- **入口**: skills/flowprompt-connector/index.js
- **Actions**: `sendToAI`（兼容`sendPrompt`）, `checkConnection`, `getSupportedAIList`
- **标签**: ai, connector

## 7表单结构

| 表单 | 定位 | 核心字段数 | 评分权重 |
|------|------|:---------:|:-------:|
| 表单0 | 核心基础信息（全链路唯一主键） | 22 | 30分 |
| 表单1 | PRD需求定义（第一阶段·需求收敛） | 16 | 25分 |
| 表单2 | TDD测试定义（第二阶段·标准前置） | 12 | 15分 |
| 表单3 | 模块开发要求（第三阶段·执行落地） | 12 | 10分 |
| 表单4 | 风险矩阵管控（全环节通用） | 11 | 10分 |
| 表单5 | 验收标准（全环节闭环校验） | 10 | 10分 |
| 表单6 | 输出配置（全环节通用） | 9 | 额外+5分 |

## 一票否决项（6项硬约束红线）

1. 项目名称未填写
2. 核心目标未定义
3. 技术栈硬约束未设定
4. 目标宿主环境未指定
5. 合规域要求未明确
6. 数据主权策略未设定

## 评分体系

```
满分 = 100分（6阶段权重）
  表单0·核心基础信息: 30分
  表单1·PRD需求定义:   25分
  表单2·TDD测试定义:   15分
  表单3·模块开发要求:   10分
  表单4·风险矩阵管控:   10分
  表单5·验收标准:       10分
  + 表单6·输出配置:     +5分（额外加分，总分不超过100）

一票否决: 触发任一项 → 直接判定不可生成
阶段上限: 每阶段得分不超过满分（防止超额）
```

## 性能基准（1000次迭代）

| 操作 | 单次耗时 |
|------|:-------:|
| Form加载 | 0.007ms |
| Validator评分 | 0.006ms |
| Generator生成 | 0.042ms |
| 完整流程 | 0.045ms |

## 版本历史

- **v1.0.0**: 初始版本，5步表单，五步均分评分
- **v3.0.0**: 重构为7表单全链路体系，6阶段权重评分，一票否决
- **v3.1.0**: 新增需求收敛引擎（converge），支持模糊输入→结构化Prompt

## 许可证

[AGPL-3.0](https://www.gnu.org/licenses/agpl-3.0.html) — GNU Affero General Public License v3.0

> 使用本项目的任何衍生作品（包括通过网络提供服务）也必须以 AGPL-3.0 开源。
