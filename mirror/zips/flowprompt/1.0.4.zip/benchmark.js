/**
 * FlowPrompt Studio - 全链路工程化AI开发技能集
 * Copyright (C) 2026 FlowPrompt Studio Team
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

const F = require('./index');
const fp = new F();

(async()=>{
  const userPrompt = '帮我做一个VS Code插件，用TypeScript写，能帮开发者生成高质量的Prompt，要有表单、评分、生成功能';

  const v1Prompt = `# 工程化问题请求
**目标 AI 助手**: Trae CN
**FlowPrompt Studio 版本**: 1.0.0

## 1. 问题上下文
**项目类型**: vscode-extension
**技术栈**: TypeScript, React, Node.js
**问题描述**: 如何实现一个VS Code插件，帮助开发者通过结构化表单生成高质量Prompt

## 2. 试错记录
暂无试错记录

## 3. 核心问题定义
**核心问题**: 如何设计一个可扩展的VS Code插件架构
**约束条件**: 使用TypeScript

## 4. 验收标准
暂无量化验收标准

## 5. 功能/技术边界
**功能边界**: 未指定
**技术边界**: 未指定`;

  const v3Data = {
    form0:{projectName:'FlowPrompt Studio',projectId:'PROJ-20260411-001',coreGoal:'构建全链路工程化AI开发辅助工具，通过7表单体系引导用户生成高质量Prompt',coreValue:['提升AI输出质量','降低返工率','标准化开发流程'],targetUsers:'使用AI辅助开发的工程师',deliverables:['VS Code插件','Web管理后台','使用文档'],hostEnv:'VS Code Extension + Web',techStackConstraint:'TypeScript + React + Node.js（禁止使用Python）',complianceDomain:'无特殊合规要求',dataPolicy:'用户数据本地存储，不上传第三方服务器',licenseReq:'MIT开源',perfBaseline:'Prompt生成<100ms，表单加载<200ms',startDate:'2026-04-01',launchDate:'2026-06-30',milestones:'M1:核心表单(4月) M2:评分引擎(5月) M3:连接器(6月)',productOwner:'产品团队',techOwner:'技术团队',testOwner:'测试团队',changeApproval:'需技术负责人+产品负责人双签'},
    form1:{userRoles:[{name:'初级开发者',painPoints:'不知道如何向AI描述需求',needs:'结构化引导'}],scenarios:[{name:'新功能开发',priority:'P0',flow:'填写表单→评分→生成Prompt→发送AI→获取代码'}],modules:[{name:'表单引擎',priority:'P0',desc:'7表单数据采集与管理'},{name:'评分引擎',priority:'P0',desc:'6阶段权重+一票否决'}],features:[{name:'空表单生成',priority:'P0',desc:'一键获取7表单空结构'}],nonFunctional:{performance:'所有操作<200ms',security:'数据本地存储',compatibility:'支持VS Code 1.80+'}},
    form2:{testCases:[{name:'空表单加载',priority:'P0',expected:'返回完整7表单结构，74个字段'},{name:'一票否决触发',priority:'P0',expected:'空表单触发6项否决'}],defectRules:{grading:'P0:功能不可用 P1:数据丢失 P2:体验问题',commitGate:'P0必须修复才能提交'}},
    form4:{risks:[{desc:'AI助手API变更导致连接失败',probability:'中',impact:'高',level:'高'}],riskRules:{high:'24小时内响应'}},
    form5:{phaseAcceptance:[{phase:'表单引擎',item:'7表单结构完整性',passCriteria:'所有字段可正确读写',status:'待检',priority:'P0'}],defectRules:{vetoItems:'1.表单数据丢失 2.评分计算错误 3.Prompt生成失败'}}
  };
  const v3Result = await fp.callSkill('generator','generate',v3Data);
  const v3Prompt = v3Result.data;

  const dims = [
    { name:'信息密度', checks: [
      ['项目名称', p=>p.includes('项目名称')],
      ['核心目标', p=>p.includes('核心目标')],
      ['目标用户', p=>p.includes('目标用户')],
      ['技术栈', p=>p.includes('技术栈')],
      ['已有资产/交付物', p=>p.includes('交付物')||p.includes('已有代码')],
      ['性能要求', p=>p.includes('性能')||p.includes('200ms')||p.includes('100ms')],
      ['合规要求', p=>p.includes('合规')||p.includes('数据主权')],
      ['许可证', p=>p.includes('MIT')||p.includes('许可')],
      ['项目周期', p=>p.includes('启动')||p.includes('上线')||p.includes('里程碑')],
      ['责任主体', p=>p.includes('负责人')]
    ]},
    { name:'约束明确度', checks: [
      ['技术栈硬约束', p=>p.includes('硬约束')||p.includes('红线')],
      ['排除技术/功能', p=>p.includes('排除')||p.includes('禁止')],
      ['数据策略', p=>(p.includes('数据')&&p.includes('本地存储'))],
      ['边界声明', p=>p.includes('不得突破')||p.includes('不要超越')],
      ['变更审批', p=>p.includes('变更审批')||p.includes('双签')]
    ]},
    { name:'验收可量化性', checks: [
      ['量化验收标准', p=>p.includes('验收标准')||p.includes('passCriteria')],
      ['测试用例', p=>p.includes('测试用例')||p.includes('TestCase')],
      ['缺陷分级', p=>p.includes('P0')||p.includes('致命')],
      ['提交准入规则', p=>p.includes('准入')||p.includes('commitGate')],
      ['一票否决项', p=>p.includes('一票否决')||p.includes('veto')]
    ]},
    { name:'风险意识', checks: [
      ['已识别风险', p=>p.includes('风险')||p.includes('Risk')],
      ['风险分级', p=>p.includes('高')&&p.includes('中')],
      ['缓解策略', p=>p.includes('缓解')||p.includes('响应')||p.includes('解决')],
      ['应急预案', p=>p.includes('应急')||p.includes('预案')]
    ]},
    { name:'结构化程度', checks: [
      ['XML/HTML标签', p=>p.includes('<form-')],
      ['分层结构', p=>p.includes('表单0')&&p.includes('表单1')],
      ['优先级标注', p=>p.includes('P0')||p.includes('P1')],
      ['角色分离', p=>p.includes('产品负责人')&&p.includes('技术负责人')]
    ]}
  ];

  console.log('═══════════════════════════════════════════════════════════════');
  console.log('  三种Prompt对AI助手的实际效果对比');
  console.log('═══════════════════════════════════════════════════════════════');

  const prompts = [
    { label:'用户手写', text:userPrompt },
    { label:'v1.0生成', text:v1Prompt },
    { label:'v3.0生成', text:v3Prompt }
  ];

  for (const dim of dims) {
    console.log('\n【'+dim.name+'】');
    for (const p of prompts) {
      const scores = dim.checks.map(([name,fn])=>[name, fn(p.text)?1:0]);
      const score = scores.reduce((a,[,v])=>a+v,0);
      const total = scores.length;
      const bar = '\u2588'.repeat(score) + '\u2591'.repeat(total-score);
      console.log('  '+p.label.padEnd(10)+' '+bar+' '+score+'/'+total);
    }
  }

  console.log('\n═══════════════════════════════════════════════════════════════');
  console.log('  总分汇总');
  console.log('═══════════════════════════════════════════════════════════════');
  const totals = prompts.map(p=>{
    let score=0, total=0;
    for (const dim of dims) {
      score += dim.checks.reduce((a,[,fn])=>a+(fn(p.text)?1:0),0);
      total += dim.checks.length;
    }
    return {label:p.label, score, total};
  });
  for (const t of totals) {
    const pct = Math.round(t.score/t.total*100);
    const bar = '\u2588'.repeat(Math.round(pct/5)) + '\u2591'.repeat(20-Math.round(pct/5));
    console.log('  '+t.label.padEnd(10)+' '+bar+' '+t.score+'/'+t.total+' ('+pct+'%)');
  }
  console.log('\n  Prompt长度: 用户手写='+userPrompt.length+' v1.0='+v1Prompt.length+' v3.0='+v3Prompt.length);
})().catch(console.error);
