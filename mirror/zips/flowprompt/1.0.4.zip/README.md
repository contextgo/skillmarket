# FlowPrompt Studio v3.1

> 基于"6表单全链路工程化AI开发体系"的 AI 辅助开发技能集。
> 从模糊想法到结构化 Prompt，6 个子技能协同工作。

## 它解决什么问题

```
问题：80%的AI用户不知道怎么向AI描述需求，导致AI输出质量差、反复返工。

传统方式：
  用户："帮我做个AI工具" → AI猜 → 猜错 → 返工 → 再猜 → 再错 → 放弃

FlowPrompt方式：
  用户："帮我做个AI工具" → 收敛引擎5轮提问 → 7表单结构化数据
  → 评分引擎校验 → 生成带硬约束红线的Prompt → AI精准输出 → 一次通过
```

## 核心流程

```
模糊想法 → [收敛引擎] → 7表单数据 → [评分引擎] → 结构化Prompt → [连接器] → AI助手
              ↑              ↑              ↑              ↑
         flowprompt-    flowprompt-    flowprompt-    flowprompt-
         converge        form+validator  generator      connector
```

## 6个子技能

| # | 技能 | 功能 | 核心能力 |
|---|------|------|---------|
| 1 | **Converge** 需求收敛引擎 | 模糊想法→结构化数据 | 一键收敛 + 5轮交互式收敛 |
| 2 | **Form** 7表单管理 | 74个字段的数据采集 | 表单0-6全链路覆盖 |
| 3 | **Validator** 评分引擎 | 质量把关 | 6阶段权重 + 6项一票否决 |
| 4 | **Generator** Prompt生成器 | 生成结构化Prompt | 7标签 + 硬约束红线 |
| 5 | **Draft** 草稿管理 | 持久化存储 | CRUD + 环境变量路径 |
| 6 | **Connector** AI连接器 | 对接AI助手 | 8种AI（当前Mock） |

## 快速开始

### 一键收敛（适合有初步想法的用户）

```javascript
const FlowPromptSkills = require('./index');
const fp = new FlowPromptSkills();

// 一句话输入，自动提取所有可识别信息
const result = await fp.callSkill('converge', 'quickConverge', {
  userInput: '我想做一个VS Code插件，用TypeScript写，帮前端开发者写代码时少走弯路，不能用Python，响应要快，数据不能丢'
});

console.log('置信度:', result.data.confidence + '%');
console.log('提取字段:', result.data.extractedFields.join(', '));
console.log('缺失字段:', result.data.missingFields.join(', ') || '无');

// 直接用收敛结果生成Prompt
const prompt = await fp.callSkill('generator', 'generate', result.data.formDraft);
console.log(prompt.data);
```

### 交互式收敛（适合想法很模糊的用户）

```javascript
// 第1轮：启动
const r1 = await fp.callSkill('converge', 'start', { userInput: '做个工具' });
console.log(r1.data.question.text);  // "你想做什么？用一句话描述你的核心目标"

// 第2-5轮：逐步回答
const r2 = await fp.callSkill('converge', 'answer', {
  context: r1.data.context,
  userAnswer: '帮前端开发者用AI写代码时少走弯路'
});
// ... 重复直到第5轮

// 第6轮：完成
const r6 = await fp.callSkill('converge', 'answer', {
  context: r5.data.context,
  userAnswer: '没有了'
});
console.log('收敛完成，置信度:', r6.data.confidence + '%');
```

### 完整流程（收敛→评分→生成→发送）

```javascript
const result = await fp.runFlow({
  form0: {
    projectName: 'FlowPrompt Studio',
    coreGoal: '构建全链路工程化AI开发辅助工具',
    techStackConstraint: 'TypeScript + React + Node.js',
    hostEnv: 'VS Code Extension',
    complianceDomain: '无特殊合规要求',
    dataPolicy: '本地存储，不上传第三方',
    // ... 更多字段
  },
  form1: { userRoles: [...], scenarios: [...], modules: [...] },
  form5: { defectRules: { vetoItems: '数据不能丢失' } }
});
```

## 7表单结构

| 表单 | 定位 | 字段数 | 评分权重 |
|------|------|:------:|:-------:|
| **表单0** | 核心基础信息（全链路唯一主键） | 22 | 30分 |
| **表单1** | PRD需求定义（第一阶段·需求收敛） | 16 | 25分 |
| **表单2** | TDD测试定义（第二阶段·标准前置） | 12 | 15分 |
| **表单3** | 模块开发要求（第三阶段·执行落地） | 12 | 10分 |
| **表单4** | 风险矩阵管控（全环节通用） | 11 | 10分 |
| **表单5** | 验收标准（全环节闭环校验） | 10 | 10分 |
| **表单6** | 输出配置（全环节通用） | 9 | +5分 |

## 评分体系

```
满分 = 100分
  表单0·核心基础信息: 30分（项目定义+硬约束+周期+责任人）
  表单1·PRD需求定义:   25分（用户角色+场景+功能模块+非功能需求）
  表单2·TDD测试定义:   15分（验收标准+测试用例+缺陷分级）
  表单3·模块开发要求:   10分（功能点规格+技术约束）
  表单4·风险矩阵管控:   10分（风险识别+缓解策略+分级规则）
  表单5·验收标准:       10分（阶段验收+专项验收+一票否决）
  + 表单6·输出配置:     +5分（额外加分）

一票否决（触发任一项→直接阻断）：
  ❌ 项目名称未填写
  ❌ 核心目标未定义
  ❌ 技术栈硬约束未设定
  ❌ 目标宿主环境未指定
  ❌ 合规域要求未明确
  ❌ 数据主权策略未设定
```

## 效果数据

### 对AI助手的实际帮助（28项指标对比）

| Prompt来源 | 信息覆盖率 | AI可直接干活 |
|-----------|:---------:|:----------:|
| 用户手写 | 0/28 (0%) | ❌ 需反问10+轮 |
| v1.0生成 | 2/28 (7%) | ❌ 仍需反问9轮 |
| **v3.1生成** | **27/28 (96%)** | **✅ 直接干活** |

### 性能基准（1000次迭代）

| 操作 | 单次耗时 |
|------|:-------:|
| Form加载（74字段） | 0.007ms |
| Validator评分（6阶段+一票否决） | 0.006ms |
| Generator生成（7标签Prompt） | 0.042ms |
| Converge一键收敛 | 0.015ms |
| **完整流程** | **0.045ms** |

## 目录结构

```
flowprompt-skills/
├── index.js                              # 主入口（6技能注册）
├── SKILL.md                              # 技能元数据
├── package.json                          # 项目配置
├── test.js                               # 测试脚本（5项）
├── benchmark.js                          # 性能基准脚本
└── skills/
    ├── flowprompt-converge/              # 需求收敛引擎
    │   ├── index.js
    │   └── src/convergeSkill.js
    ├── flowprompt-form/                  # 7表单管理
    │   ├── index.js
    │   └── src/formSkill.js
    ├── flowprompt-validator/             # 评分引擎
    │   ├── index.js
    │   └── src/validatorSkill.js
    ├── flowprompt-generator/             # Prompt生成器
    │   ├── index.js
    │   └── src/generatorSkill.js
    ├── flowprompt-draft/                 # 草稿管理
    │   ├── index.js
    │   └── src/draftSkill.js
    └── flowprompt-connector/             # AI连接器
        ├── index.js
        └── src/connectorSkill.js
```

## 版本历史

| 版本 | 变化 |
|------|------|
| **v1.0.0** | 初始版本：5步表单，五步均分评分（满分125截断到100） |
| **v3.0.0** | 重构：7表单全链路体系，6阶段权重评分，6项一票否决，74字段 |
| **v3.1.0** | 新增：需求收敛引擎（一键收敛+5轮交互式），模糊想法→结构化Prompt |

## 许可证

[AGPL-3.0](https://www.gnu.org/licenses/agpl-3.0.html) — GNU Affero General Public License v3.0

> 使用本项目的任何衍生作品（包括通过网络提供服务）也必须以 AGPL-3.0 开源。
