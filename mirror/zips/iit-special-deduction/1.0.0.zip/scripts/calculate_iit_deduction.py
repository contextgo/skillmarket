#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
个人所得税专项附加扣除计算器
根据用户输入计算年度可扣除总额
"""

import json
from typing import Dict, List, Tuple

class IITCalculator:
    """个税专项附加扣除计算器"""
    
    # 扣除标准（2025年）
    DEDUCTION_RATES = {
        "子女教育": 2000,  # 元/月/每个子女
        "婴幼儿照护": 2000,  # 元/月/每个婴幼儿
        "继续教育_学历": 400,  # 元/月
        "继续教育_证书": 3600,  # 元/年
        "住房贷款利息": 1000,  # 元/月
        "住房租金_一档": 1500,  # 元/月（直辖市、省会等）
        "住房租金_二档": 1100,  # 元/月（市辖区人口>100万）
        "住房租金_三档": 800,  # 元/月（市辖区人口<=100万）
        "赡养老人_独生": 3000,  # 元/月
        "赡养老人_非独生": 3000,  # 元/月（分摊总额）
        "大病医疗起付": 15000,  # 元/年
        "大病医疗上限": 80000,  # 元/年
    }
    
    def __init__(self):
        self.result = {
            "月度扣除项": {},
            "年度扣除项": {},
            "月度扣除总额": 0,
            "年度扣除总额": 0,
            "备注": []
        }
    
    def calc_children_education(self, count: int, ratio: float = 1.0, months: int = 12) -> int:
        """计算子女教育扣除"""
        if count <= 0:
            return 0
        monthly = self.DEDUCTION_RATES["子女教育"] * count * ratio
        annual = int(monthly * months)
        self.result["月度扣除项"]["子女教育"] = int(monthly)
        return annual
    
    def calc_infant_care(self, count: int, ratio: float = 1.0, months: int = 12) -> int:
        """计算婴幼儿照护扣除"""
        if count <= 0:
            return 0
        monthly = self.DEDUCTION_RATES["婴幼儿照护"] * count * ratio
        annual = int(monthly * months)
        self.result["月度扣除项"]["3岁以下婴幼儿照护"] = int(monthly)
        return annual
    
    def calc_continuing_edu(self, is_degree: bool = False, is_cert: bool = False, 
                           months: int = 12) -> Tuple[int, int]:
        """计算继续教育扣除，返回(月度, 年度)"""
        monthly = 0
        annual = 0
        if is_degree:
            monthly = self.DEDUCTION_RATES["继续教育_学历"]
        if is_cert:
            annual = self.DEDUCTION_RATES["继续教育_证书"]
        
        if monthly > 0:
            self.result["月度扣除项"]["继续教育(学历)"] = monthly
        if annual > 0:
            self.result["年度扣除项"]["继续教育(证书)"] = annual
        
        return monthly, annual
    
    def calc_housing_loan(self, has_loan: bool, ratio: float = 1.0, months: int = 12) -> int:
        """计算住房贷款利息扣除"""
        if not has_loan:
            return 0
        monthly = self.DEDUCTION_RATES["住房贷款利息"] * ratio
        annual = int(monthly * months)
        self.result["月度扣除项"]["住房贷款利息"] = int(monthly)
        return annual
    
    def calc_housing_rent(self, city_tier: int = 0, months: int = 12) -> int:
        """计算住房租金扣除
city_tier: 1=一档城市, 2=二档城市, 3=三档城市
"""
        if city_tier == 1:
            monthly = self.DEDUCTION_RATES["住房租金_一档"]
        elif city_tier == 2:
            monthly = self.DEDUCTION_RATES["住房租金_二档"]
        elif city_tier == 3:
            monthly = self.DEDUCTION_RATES["住房租金_三档"]
        else:
            return 0
        
        annual = int(monthly * months)
        self.result["月度扣除项"]["住房租金"] = int(monthly)
        return annual
    
    def calc_elderly_support(self, is_only_child: bool = True, 
                            sibling_count: int = 1, 
                            self_ratio: float = 1.0) -> int:
        """计算赡养老人扣除"""
        if is_only_child:
            monthly = self.DEDUCTION_RATES["赡养老人_独生"]
        else:
            max_per_person = 1500  # 非独生子女每人最高1500
            total = self.DEDUCTION_RATES["赡养老人_非独生"]
            monthly = min(total * self_ratio, max_per_person)
        
        annual = int(monthly * 12)
        self.result["月度扣除项"]["赡养老人"] = int(monthly)
        return annual
    
    def calc_medical_expense(self, actual_expense: int = 0) -> int:
        """计算大病医疗扣除"""
        if actual_expense <= self.DEDUCTION_RATES["大病医疗起付"]:
            deductible = 0
        else:
            deductible = min(actual_expense - self.DEDUCTION_RATES["大病医疗起付"],
                           self.DEDUCTION_RATES["大病医疗上限"])
        
        if deductible > 0:
            self.result["年度扣除项"]["大病医疗"] = int(deductible)
        return int(deductible)
    
    def calculate_total(self, params: Dict) -> Dict:
        """根据参数计算总扣除额"""
        total_monthly = 0
        total_annual = 0
        
        # 子女教育
        if params.get("子女数量", 0) > 0:
            months = params.get("子女教育_享受月数", 12)
            ratio = params.get("子女教育_扣除比例", 1.0)
            total_annual += self.calc_children_education(
                params["子女数量"], ratio, months)
            total_monthly += self.result["月度扣除项"].get("子女教育", 0)
        
        # 婴幼儿照护
        if params.get("婴幼儿数量", 0) > 0:
            months = params.get("婴幼儿照护_享受月数", 12)
            ratio = params.get("婴幼儿照护_扣除比例", 1.0)
            total_annual += self.calc_infant_care(
                params["婴幼儿数量"], ratio, months)
            total_monthly += self.result["月度扣除项"].get("3岁以下婴幼儿照护", 0)
        
        # 继续教育
        cont_monthly, cont_annual = self.calc_continuing_edu(
            params.get("继续教育_学历", False),
            params.get("继续教育_证书", False),
            params.get("继续教育_享受月数", 12)
        )
        total_monthly += cont_monthly
        total_annual += cont_annual
        
        # 住房相关（二选一）
        has_loan = params.get("有房贷", False)
        rent_tier = params.get("租房城市档次", 0)
        
        if has_loan and rent_tier > 0:
            # 两者都有，选择金额高的
            loan_monthly = self.DEDUCTION_RATES["住房贷款利息"]
            if rent_tier == 1:
                rent_monthly = self.DEDUCTION_RATES["住房租金_一档"]
            elif rent_tier == 2:
                rent_monthly = self.DEDUCTION_RATES["住房租金_二档"]
            else:
                rent_monthly = self.DEDUCTION_RATES["住房租金_三档"]
            
            if rent_monthly > loan_monthly:
                self.result["备注"].append(f"提示：住房租金({rent_monthly}元/月) > 房贷利息({loan_monthly}元/月)，建议选择租金扣除")
                total_annual += self.calc_housing_rent(rent_tier, 12)
            else:
                self.result["备注"].append(f"提示：房贷利息({loan_monthly}元/月) >= 住房租金({rent_monthly}元/月)，建议选择房贷扣除")
                ratio = params.get("房贷_扣除比例", 1.0)
                total_annual += self.calc_housing_loan(True, ratio, 12)
            total_monthly += self.result["月度扣除项"].get("住房贷款利息", 0) or self.result["月度扣除项"].get("住房租金", 0)
        elif has_loan:
            ratio = params.get("房贷_扣除比例", 1.0)
            total_annual += self.calc_housing_loan(True, ratio, 12)
            total_monthly += self.result["月度扣除项"].get("住房贷款利息", 0)
        elif rent_tier > 0:
            total_annual += self.calc_housing_rent(rent_tier, 12)
            total_monthly += self.result["月度扣除项"].get("住房租金", 0)
        
        # 赡养老人
        if params.get("有赡养老人", False):
            is_only = params.get("独生子女", True)
            siblings = params.get("兄弟姐妹数", 1)
            ratio = params.get("赡养分摊比例", 1.0 / siblings if siblings > 0 else 1.0)
            total_annual += self.calc_elderly_support(is_only, siblings, ratio)
            total_monthly += self.result["月度扣除项"].get("赡养老人", 0)
        
        # 大病医疗
        if params.get("大病医疗支出", 0) > 0:
            total_annual += self.calc_medical_expense(params["大病医疗支出"])
        
        self.result["月度扣除总额"] = total_monthly
        self.result["年度扣除总额"] = total_annual
        
        return self.result


def format_result(result: Dict) -> str:
    """格式化输出结果"""
    output = []
    output.append("=" * 50)
    output.append("【个税专项附加扣除计算结果】")
    output.append("=" * 50)
    
    output.append("\n一、月度扣除项目明细")
    output.append("-" * 40)
    if result["月度扣除项"]:
        for item, amount in result["月度扣除项"].items():
            output.append(f"  {item}: {amount}元/月")
    else:
        output.append("  无月度扣除项")
    
    output.append("\n二、年度扣除项目明细")
    output.append("-" * 40)
    if result["年度扣除项"]:
        for item, amount in result["年度扣除项"].items():
            output.append(f"  {item}: {amount}元/年")
    else:
        output.append("  无年度扣除项")
    
    output.append("\n三、扣除总额汇总")
    output.append("-" * 40)
    output.append(f"  每月可扣除: {result['月度扣除总额']}元")
    output.append(f"  年度可扣除: {result['年度扣除总额']}元")
    
    if result["备注"]:
        output.append("\n四、提示与建议")
        output.append("-" * 40)
        for note in result["备注"]:
            output.append(f"  • {note}")
    
    output.append("\n" + "=" * 50)
    return "\n".join(output)


# 示例用法
if __name__ == "__main__":
    # 示例参数
    sample_params = {
        "子女数量": 1,
        "子女教育_享受月数": 12,
        "子女教育_扣除比例": 1.0,
        "婴幼儿数量": 0,
        "继续教育_学历": False,
        "继续教育_证书": True,
        "有房贷": True,
        "房贷_扣除比例": 1.0,
        "租房城市档次": 0,
        "有赡养老人": True,
        "独生子女": False,
        "兄弟姐妹数": 2,
        "赡养分摊比例": 0.5,
        "大病医疗支出": 0
    }
    
    calc = IITCalculator()
    result = calc.calculate_total(sample_params)
    print(format_result(result))
