# videojs-contrib-hls Compatibility Guide

## What is videojs-contrib-hls?

videojs-contrib-hls is a Video.js plugin that enables HLS (HTTP Live Streaming) playback in browsers. It's commonly used for streaming video content over HTTP.

## Why Videos Fail with videojs-contrib-hls

### 1. MOOV Atom Position

The most common issue is the MOOV atom (movie header) being at the end of the file instead of the beginning.

**Problem**: 
- Browser must download entire file before playback starts
- Video appears to "not load" or takes very long to start

**Solution**: 
- Re-mux video with MOOV atom at beginning using `-movflags +faststart`

### 2. Codec Incompatibility

**Video Codecs**:
- ✅ H.264 (AVC) - Best compatibility
- ⚠️ HEVC (H.265) - Limited browser support
- ⚠️ VP9 - Chrome/Firefox only
- ⚠️ AV1 - Limited support

**Audio Codecs**:
- ✅ AAC - Best compatibility
- ⚠️ MP3 - Good support but AAC preferred
- ⚠️ Opus - Limited support

### 3. Container Format Issues

**Best for HLS**:
- MP4 with H.264/AAC
- fMP4 (fragmented MP4) for DASH/HLS hybrid

**Avoid**:
- MKV (Matroska) - not widely supported for streaming
- AVI - outdated, poor streaming support
- WMV - Windows-only

### 4. B-Frames

B-frames (bidirectional predicted frames) can cause seeking issues in some HLS implementations.

**Symptoms**:
- Video freezes when seeking
- Audio/video sync issues after seeking

**Solution**:
- Re-encode without B-frames: `-bf 0`

## FFmpeg Commands for Fixing Videos

### Basic Fix (Re-mux Only)

```bash
ffmpeg -i input.mp4 -movflags +faststart -c copy output.mp4
```

Fast, no quality loss. Fixes MOOV atom position only.

### Full Compatibility Fix

```bash
ffmpeg -i input.mp4 \
  -movflags +faststart \
  -c:v libx264 -preset fast -crf 23 -profile:v baseline -level 3.0 \
  -c:a aac -b:a 128k \
  -bf 0 \
  output.mp4
```

Parameters:
- `-movflags +faststart`: MOOV atom at beginning
- `-profile:v baseline`: Maximum compatibility
- `-level 3.0`: H.264 level for broad device support
- `-bf 0`: Disable B-frames

### For HLS Segmentation

```bash
ffmpeg -i input.mp4 \
  -codec: copy \
  -start_number 0 \
  -hls_time 10 \
  -hls_list_size 0 \
  -f hls \
  playlist.m3u8
```

## Testing Video Compatibility

### Check MOOV Atom Position

```bash
ffmpeg -v trace -i input.mp4 2>&1 | grep -i "type:'moov'"
```

Or use the tool in this skill:
```bash
python scripts/video_hls_checker.py input.mp4
```

### Check Video Codecs

```bash
ffprobe -v error -select_streams v:0 -show_entries stream=codec_name -of default=noprint_wrappers=1 input.mp4
```

### Check Complete Format

```bash
ffprobe -v error -show_format -show_streams input.mp4
```

## Browser Compatibility Matrix

| Feature | Chrome | Firefox | Safari | Edge |
|---------|--------|---------|--------|------|
| HLS Native | ✅ | ❌ | ✅ | ✅ |
| HLS via videojs-contrib-hls | ✅ | ✅ | ✅ | ✅ |
| H.264 | ✅ | ✅ | ✅ | ✅ |
| HEVC | ⚠️ | ❌ | ✅ | ⚠️ |
| AAC Audio | ✅ | ✅ | ✅ | ✅ |

## Common Error Messages

### "The media could not be loaded"

- Check MOOV atom position
- Verify codec compatibility
- Check CORS headers if loading from different domain

### "Network error"

- Check file is accessible
- Verify server supports range requests (for MP4)
- Check CORS configuration

### "Playback cannot continue"

- Incompatible codec
- Corrupted file
- Encryption/key issues

## Best Practices

1. **Always use `-movflags +faststart`** when encoding for web
2. **Use H.264 + AAC** for maximum compatibility
3. **Test on multiple browsers** before deployment
4. **Use adaptive bitrate** (multiple quality levels) for best user experience
5. **Consider using HLS.js** as alternative to videojs-contrib-hls

## References

- [Video.js Documentation](https://docs.videojs.com/)
- [videojs-contrib-hls GitHub](https://github.com/videojs/videojs-contrib-hls)
- [HLS Specification](https://datatracker.ietf.org/doc/html/draft-pantos-hls-rfc8216bis-11)
- [FFmpeg HLS Guide](https://ffmpeg.org/ffmpeg-formats.html#hls-1)
