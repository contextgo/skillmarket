---
name: video-hls-checker
description: 检测并修复视频文件的 videojs-contrib-hls 兼容性问题。当需要验证视频是否支持 HLS 流媒体播放、检查 MOOV 原子位置、或修复无法在 videojs-contrib-hls 播放器中正常播放的视频时使用。触发关键词：视频格式检测、HLS 兼容性验证、FFmpeg 视频修复、videojs 流媒体问题。
---

# Video HLS 检测器

检测并修复视频文件，使其兼容 videojs-contrib-hls 流媒体播放。

## 功能概述

本技能提供以下功能：
1. **检测**视频文件的 HLS 流媒体兼容性问题
2. **识别** MOOV 原子位置问题（videojs-contrib-hls 失败的常见原因）
3. **修复**视频文件，使用 FFmpeg 使其支持流媒体播放

## 常见问题检测

- **MOOV 原子在文件末尾**：导致视频需完全下载后才能播放
- **不兼容的编码格式**：浏览器不支持的编解码器
- **B-帧**：在某些播放器中可能导致进度条拖动问题
- **过高码率**：可能导致缓冲问题

## 快速开始

### 检测视频文件

```bash
python scripts/video_hls_checker.py <视频文件>
```

### 检测并自动修复

```bash
python scripts/video_hls_checker.py <视频文件> --fix
```

### 指定输出路径

```bash
python scripts/video_hls_checker.py <视频文件> --fix --output <修复后的视频.mp4>
```

## Python API 使用方式

```python
from scripts.video_hls_checker import VideoHLSChecker

# 创建检测器实例
checker = VideoHLSChecker(verbose=True)

# 检测视频
results = checker.check_video("path/to/video.mp4")

# 检查是否需要修复
if results['needs_fix']:
    print("视频需要修复：")
    for issue in results['issues']:
        print(f"  - {issue}")
    
    # 修复视频
    fixed_path = checker.fix_video("path/to/video.mp4")
    print(f"修复后的视频保存至：{fixed_path}")
else:
    print("视频兼容 videojs-contrib-hls")
```

## 理解检测结果

### MOOV 原子检测

MOOV 原子包含视频的元数据信息。对于流媒体播放：
- ✅ **通过**：MOOV 原子位于文件开头
- ❌ **失败**：MOOV 原子位于文件末尾（需完全下载后才能播放）

**修复方法**：使用 `-movflags +faststart` 重新封装

### 视频/音频流检测

验证编解码器兼容性：
- **视频编码**：h264、hevc、vp9、av1（推荐 h264 以获得最佳兼容性）
- **音频编码**：aac、mp3、opus（推荐 aac）

### HLS 分段兼容性

检测内容：
- 视频时长
- 码率（超过 20 Mbps 会警告）
- 容器格式

## FFmpeg 修复流程

修复视频时，工具会执行以下步骤：

1. **首次尝试**：仅重新封装（快速，无质量损失）
   ```
   ffmpeg -i input.mp4 -movflags +faststart -c copy output.mp4
   ```

2. **第二次尝试**（如需要）：使用兼容设置重新编码
   ```
   ffmpeg -i input.mp4 -movflags +faststart -c:v libx264 -c:a aac output.mp4
   ```

## 退出代码

- `0`：视频兼容 / 修复成功
- `1`：视频存在兼容性问题
- `2`：工具错误（未找到 FFmpeg 等）
- `3`：意外错误

## 前置要求

- 已安装 FFmpeg 并添加到 PATH
- Python 3.7+

## 参考资料

- [references/videojs_contrib_hls.md](references/videojs_contrib_hls.md) - videojs-contrib-hls 文档
