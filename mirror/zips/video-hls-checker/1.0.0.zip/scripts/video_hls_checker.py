#!/usr/bin/env python3
"""
Video HLS Format Checker and Fixer

Checks if a video file has videojs-contrib-hls format issues and fixes them using FFmpeg.

Usage:
    python video_hls_checker.py <video_file> [--fix] [--output <output_file>]

Arguments:
    video_file          Path to the video file to check
    --fix               Automatically fix the video if issues are found
    --output            Output path for fixed video (default: <original>_fixed.<ext>)
    --verbose           Show detailed output
"""

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple


class VideoHLSError(Exception):
    """Custom exception for video HLS errors."""
    pass


class VideoHLSChecker:
    """Checks and fixes video files for videojs-contrib-hls compatibility issues."""
    
    def __init__(self, verbose: bool = False):
        self.verbose = verbose
        self.ffmpeg_path = self._find_ffmpeg()
        self.ffprobe_path = self._find_ffprobe()
    
    def _log(self, message: str):
        """Print verbose messages."""
        if self.verbose:
            print(f"[INFO] {message}")
    
    def _find_ffmpeg(self) -> str:
        """Find FFmpeg executable."""
        for cmd in ['ffmpeg', 'ffmpeg.exe']:
            result = subprocess.run(['where', cmd], capture_output=True, text=True)
            if result.returncode == 0:
                return cmd
        raise VideoHLSError("FFmpeg not found. Please install FFmpeg and add it to PATH.")
    
    def _find_ffprobe(self) -> str:
        """Find FFprobe executable."""
        for cmd in ['ffprobe', 'ffprobe.exe']:
            result = subprocess.run(['where', cmd], capture_output=True, text=True)
            if result.returncode == 0:
                return cmd
        raise VideoHLSError("FFprobe not found. Please install FFmpeg and add it to PATH.")
    
    def _run_ffprobe(self, video_path: str) -> Dict:
        """Run ffprobe to get video information."""
        cmd = [
            self.ffprobe_path,
            '-v', 'error',
            '-print_format', 'json',
            '-show_format',
            '-show_streams',
            video_path
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            raise VideoHLSError(f"FFprobe failed: {result.stderr}")
        
        return json.loads(result.stdout)
    
    def _check_moov_atom(self, video_path: str) -> Tuple[bool, str]:
        """
        Check if MOOV atom is at the beginning of the file.
        videojs-contrib-hls requires MOOV atom at the start for proper streaming.
        """
        self._log("Checking MOOV atom position...")
        
        try:
            with open(video_path, 'rb') as f:
                # Read first 1MB to check for MOOV atom
                data = f.read(1024 * 1024)
                
                # Check for ftyp (file type box) - should be at start
                ftyp_pos = data.find(b'ftyp')
                if ftyp_pos == -1:
                    return False, "No ftyp box found - may not be a valid MP4/MOV file"
                
                # Check for MOOV atom in first chunk
                moov_pos = data.find(b'moov')
                mdat_pos = data.find(b'mdat')
                
                if moov_pos == -1:
                    # MOOV not in first MB, check if it's at the end
                    return False, "MOOV atom not found at beginning - likely at end of file (unsuitable for streaming)"
                
                if mdat_pos != -1 and moov_pos > mdat_pos:
                    return False, "MOOV atom is after MDAT - video needs re-muxing for streaming"
                
                self._log(f"MOOV atom found at position {moov_pos}")
                return True, "MOOV atom is correctly positioned"
                
        except Exception as e:
            return False, f"Error checking MOOV atom: {str(e)}"
    
    def _check_video_streams(self, probe_data: Dict) -> Tuple[bool, List[str]]:
        """
        Check video streams for HLS compatibility issues.
        """
        self._log("Checking video streams...")
        issues = []
        
        if 'streams' not in probe_data:
            return False, ["No streams found in video file"]
        
        video_streams = [s for s in probe_data['streams'] if s.get('codec_type') == 'video']
        audio_streams = [s for s in probe_data['streams'] if s.get('codec_type') == 'audio']
        
        if not video_streams:
            issues.append("No video stream found")
        
        for stream in video_streams:
            codec_name = stream.get('codec_name', 'unknown')
            
            # Check codec compatibility
            if codec_name not in ['h264', 'hevc', 'vp9', 'av1']:
                issues.append(f"Video codec '{codec_name}' may not be fully compatible with videojs-contrib-hls")
            
            # Check for B-frames which can cause issues
            if 'has_b_frames' in stream and stream['has_b_frames'] > 0:
                issues.append(f"Video has {stream['has_b_frames']} B-frames which may cause seeking issues")
            
            # Check pixel format
            pix_fmt = stream.get('pix_fmt', '')
            if pix_fmt and pix_fmt not in ['yuv420p', 'yuvj420p']:
                issues.append(f"Pixel format '{pix_fmt}' may not be compatible with all browsers")
        
        if not audio_streams:
            issues.append("No audio stream found (may be intentional)")
        else:
            for stream in audio_streams:
                codec_name = stream.get('codec_name', 'unknown')
                if codec_name not in ['aac', 'mp3', 'opus']:
                    issues.append(f"Audio codec '{codec_name}' may not be compatible with all browsers")
        
        return len(issues) == 0, issues
    
    def _check_segment_compatibility(self, probe_data: Dict) -> Tuple[bool, List[str]]:
        """
        Check if video is suitable for HLS segmentation.
        """
        self._log("Checking HLS segment compatibility...")
        issues = []
        
        format_info = probe_data.get('format', {})
        
        # Check duration
        duration = float(format_info.get('duration', 0))
        if duration == 0:
            issues.append("Cannot determine video duration")
        
        # Check bitrate
        bit_rate = format_info.get('bit_rate')
        if bit_rate:
            bit_rate_mbps = int(bit_rate) / 1000000
            if bit_rate_mbps > 20:
                issues.append(f"Very high bitrate ({bit_rate_mbps:.1f} Mbps) may cause buffering issues")
        
        # Check format name
        format_name = format_info.get('format_name', '')
        if 'mp4' not in format_name and 'mov' not in format_name and 'matroska' not in format_name:
            issues.append(f"Format '{format_name}' may not be ideal for HLS streaming")
        
        return len(issues) == 0, issues
    
    def check_video(self, video_path: str) -> Dict:
        """
        Perform full video check for videojs-contrib-hls compatibility.
        
        Returns:
            Dictionary with check results
        """
        if not os.path.exists(video_path):
            raise VideoHLSError(f"Video file not found: {video_path}")
        
        self._log(f"Checking video: {video_path}")
        
        results = {
            'file': video_path,
            'is_valid': True,
            'needs_fix': False,
            'checks': {},
            'issues': [],
            'recommendations': []
        }
        
        # Run ffprobe
        try:
            probe_data = self._run_ffprobe(video_path)
            results['probe_data'] = probe_data
        except VideoHLSError as e:
            results['is_valid'] = False
            results['issues'].append(str(e))
            return results
        
        # Check 1: MOOV atom position
        moov_ok, moov_msg = self._check_moov_atom(video_path)
        results['checks']['moov_atom'] = {'passed': moov_ok, 'message': moov_msg}
        if not moov_ok:
            results['needs_fix'] = True
            results['issues'].append(moov_msg)
            results['recommendations'].append("Re-mux video with MOOV atom at beginning using FFmpeg")
        
        # Check 2: Video streams
        streams_ok, stream_issues = self._check_video_streams(probe_data)
        results['checks']['video_streams'] = {'passed': streams_ok, 'issues': stream_issues}
        if not streams_ok:
            results['needs_fix'] = True
            results['issues'].extend(stream_issues)
        
        # Check 3: Segment compatibility
        segment_ok, segment_issues = self._check_segment_compatibility(probe_data)
        results['checks']['segment_compatibility'] = {'passed': segment_ok, 'issues': segment_issues}
        if not segment_ok:
            results['needs_fix'] = True
            results['issues'].extend(segment_issues)
        
        # Overall result
        results['is_valid'] = moov_ok and streams_ok and segment_ok
        
        return results
    
    def fix_video(self, input_path: str, output_path: Optional[str] = None) -> str:
        """
        Fix video for videojs-contrib-hls compatibility using FFmpeg.
        
        Args:
            input_path: Path to input video
            output_path: Path for output video (default: <input>_fixed.<ext>)
            
        Returns:
            Path to fixed video
        """
        if not output_path:
            input_path_obj = Path(input_path)
            output_path = str(input_path_obj.parent / f"{input_path_obj.stem}_fixed{input_path_obj.suffix}")
        
        self._log(f"Fixing video: {input_path} -> {output_path}")
        
        # FFmpeg command to re-mux with MOOV atom at beginning
        # -movflags +faststart: Move MOOV atom to beginning
        # -c copy: Copy streams without re-encoding (fast)
        cmd = [
            self.ffmpeg_path,
            '-i', input_path,
            '-movflags', '+faststart',
            '-c', 'copy',
            '-y',  # Overwrite output
            output_path
        ]
        
        self._log(f"Running: {' '.join(cmd)}")
        
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True
        )
        
        if result.returncode != 0:
            raise VideoHLSError(f"FFmpeg failed: {result.stderr}")
        
        # Verify the fix
        self._log("Verifying fixed video...")
        check_results = self.check_video(output_path)
        
        if check_results['needs_fix']:
            # Try with re-encoding if simple re-mux didn't work
            self._log("Simple re-mux didn't fix all issues, trying with re-encoding...")
            
            cmd = [
                self.ffmpeg_path,
                '-i', input_path,
                '-movflags', '+faststart',
                '-c:v', 'libx264',
                '-preset', 'fast',
                '-crf', '23',
                '-c:a', 'aac',
                '-b:a', '128k',
                '-y',
                output_path
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            if result.returncode != 0:
                raise VideoHLSError(f"FFmpeg re-encoding failed: {result.stderr}")
        
        return output_path


def print_results(results: Dict):
    """Print check results in a readable format."""
    print("\n" + "="*60)
    print(f"Video Check Results: {results['file']}")
    print("="*60)
    
    if results['is_valid']:
        print("✅ Video is compatible with videojs-contrib-hls")
    else:
        print("❌ Video has compatibility issues")
    
    if results['needs_fix']:
        print("\n⚠️  Video needs to be fixed for proper HLS streaming")
    
    print("\n--- Check Details ---")
    
    # MOOV atom check
    moov = results['checks'].get('moov_atom', {})
    status = "✅" if moov.get('passed') else "❌"
    print(f"\n{status} MOOV Atom Position:")
    print(f"   {moov.get('message', 'Unknown')}")
    
    # Video streams check
    streams = results['checks'].get('video_streams', {})
    status = "✅" if streams.get('passed') else "❌"
    print(f"\n{status} Video/Audio Streams:")
    stream_issues = streams.get('issues', [])
    if stream_issues:
        for issue in stream_issues:
            print(f"   - {issue}")
    else:
        print("   All streams compatible")
    
    # Segment compatibility
    segment = results['checks'].get('segment_compatibility', {})
    status = "✅" if segment.get('passed') else "⚠️"
    print(f"\n{status} HLS Segment Compatibility:")
    segment_issues = segment.get('issues', [])
    if segment_issues:
        for issue in segment_issues:
            print(f"   - {issue}")
    else:
        print("   Compatible with HLS segmentation")
    
    if results['recommendations']:
        print("\n--- Recommendations ---")
        for rec in results['recommendations']:
            print(f"   • {rec}")
    
    print("\n" + "="*60)


def main():
    parser = argparse.ArgumentParser(
        description='Check and fix video files for videojs-contrib-hls compatibility'
    )
    parser.add_argument('video_file', help='Path to video file to check')
    parser.add_argument('--fix', action='store_true', help='Automatically fix video if issues found')
    parser.add_argument('--output', help='Output path for fixed video')
    parser.add_argument('--verbose', '-v', action='store_true', help='Show detailed output')
    
    args = parser.parse_args()
    
    try:
        checker = VideoHLSChecker(verbose=args.verbose)
        
        # Check video
        results = checker.check_video(args.video_file)
        print_results(results)
        
        # Fix if requested and needed
        if args.fix and results['needs_fix']:
            print("\n🔧 Fixing video...")
            output_path = checker.fix_video(args.video_file, args.output)
            print(f"✅ Fixed video saved to: {output_path}")
            
            # Re-check
            print("\nRe-checking fixed video...")
            new_results = checker.check_video(output_path)
            print_results(new_results)
        
        # Exit with appropriate code
        sys.exit(0 if results['is_valid'] else 1)
        
    except VideoHLSError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)
    except Exception as e:
        print(f"Unexpected error: {e}", file=sys.stderr)
        sys.exit(3)


if __name__ == '__main__':
    main()
