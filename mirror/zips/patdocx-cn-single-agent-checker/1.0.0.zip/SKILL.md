***

name: patdocx\_cn\_single-agent\_checker
description: |
检查中国专利申请文件(.docx)中的撰写问题，按照专利法、专利法实施细则和专利审查指南的规则审查摘要、权利要求书、说明书等章节，在修订模式下执行替换、删除和添加批注说明。Invoke when user asks to check, review, or audit a Chinese patent application document.

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# CNIPA Patent Application Checker - 中国专利申请文件质检员

AI 辅助审查中国专利申请文件（.docx），按照专利法、专利法实施细则和专利审查指南的规则，对摘要、权利要求书、说明书等章节进行多维度审查，生成在修订模式下执行替换、删除、批注的docx副本，同时生成审查意见汇总报告.md。

## 功能特性

| 功能               | 说明                                                 |
|:---------------- |:-------------------------------------------------- |
| **专利文本提取与章节分割**  | 自动提取 docx 文本并分割为摘要、摘要附图、权利要求书、说明书、说明书附图 5 个章节      |
| **多维度审查规则（13条）** | 涵盖摘要检查（2条）、权利要求书审查（6条）、说明书审查（2条）、全文审查（2条）、整理汇总（1条） |
| **修订模式操作**       | 对于明确了具体操作的修改建议，在修订模式下执行字词替换或删除，同时添加批注说明            |
| **批注标记问题位置**     | 对于无法明确具体操作的修改建议，在 docx 文档中添加批注标记问题位置               |
| **审查意见汇总报告**     | 按章节整理所有审查意见，生成结构化 markdown 报告                      |

## ⛔ 关键禁止事项（开始前必读）

> **以下行为会导致输出文档内容丢失或审查结果不可靠，严格禁止：**

1. **⛔ 禁止自行编写修正脚本**：必须使用本 skill 提供的 `review_adder.py` 添加批注和修订操作（见第六步）。自行编写脚本调用 `Document` 类的 `get_node` + `replace_node` 会导致**严重内容丢失**——`replace_node` 会替换整个 `w:r` 节点，如果该节点包含除目标文本外的其他文本，这些文本将全部丢失。`review_adder.py` 内部已正确处理了文本拆分逻辑，不会丢失任何内容。
2. **⛔ 禁止跳过验证步骤**：第七步的内容完整性验证是**强制性的**，不得跳过。未通过验证的文档**禁止**输出给用户。
3. **⛔ 禁止在终端中直接执行多行 Python 代码**：本 skill 已提供 `patent_extractor.py`（文本提取与章节分割）、`review_adder.py`（批注添加）和 `verify.py`（验证功能），**必须直接调用这些脚本**，禁止将多行 Python 代码粘贴到终端执行。多行 Python 代码在 PowerShell 的 `python -c` 中极易因引号嵌套、分号分隔、for/if 语句等导致语法错误。
4. **⛔ 禁止在 skill 目录内创建工作文件夹**：工作文件夹**必须**创建在输入 docx 文件所在目录下，**禁止**在 `.trae/skills/patdocx_cn_single-agent_checker/` 目录内创建。所有路径**必须**使用绝对路径 `<work_dir>`，**禁止**使用相对路径，因为不同命令的当前工作目录（cwd）可能不同，相对路径会导致在错误位置创建文件夹。
5. **⛔ 禁止自行编造时间戳**：时间戳**必须**通过执行命令获取真实值（见第二步），禁止使用 `20260424_120000` 等占位时间戳。

## 路径变量说明

本工作流程使用以下路径变量，请在开始前明确它们的值：

| 变量             | 含义                                                 | 示例                                                        |
|:-------------- |:-------------------------------------------------- |:--------------------------------------------------------- |
| `<skill_root>` | 本 skill 的根目录（包含 `scripts/`、`ooxml/` 和 `审查规则/` 的目录） | `D:\path\to\.trae\skills\patdocx_cn_single-agent_checker` |
| `<input_docx>` | 输入 docx 文件的**绝对路径**                                | `D:\docs\专利申请文件.docx`                                     |
| `<input_dir>`  | 输入 docx 文件所在目录的**绝对路径**                            | `D:\docs`                                                 |
| `<input_stem>` | 输入 docx 文件名（不含扩展名）                                 | `专利申请文件`                                                  |
| `<timestamp>`  | 第二步获取的本地时间戳                                        | `20260424_153025`                                         |
| `<work_dir>`   | 工作文件夹的**绝对路径**                                     | `D:\docs\patdocx_cn_single-agent_checker_20260424_153025` |

> ⚠️ **所有路径必须使用绝对路径**。Windows 路径中的反斜杠 `\` 在 Python 中是转义字符，在命令行参数中直接使用原始路径即可（如 `D:\docs\file.docx`），**不要**手动添加额外转义。

## 工作流程

### 第一步：判断文件类型

检查用户输入的文件是否为 `.docx` 格式：

1. 获取用户输入的文件路径，检查文件扩展名是否为 `.docx`（不区分大小写）
2. 如果文件扩展名**不是** `.docx`（如 `.doc`、`.pdf`、`.txt` 等），**直接告知用户**：

```
⚠️ 目前本 skill 只支持解析 .docx 格式的专利申请文件，不支持 .doc、.pdf 等其他类型文件。
请将文件转换为 .docx 格式后重试。
```

并**终止工作流程**，不继续执行后续步骤。

1. 如果文件扩展名是 `.docx`，继续执行第二步

> ⚠️ 此步骤仅需检查文件扩展名，无需验证文件内部结构。即使扩展名为 `.docx` 但文件损坏，后续步骤中的脚本会自然报错。

### 第二步：获取时间戳并创建工作文件夹

在开始任何操作之前，**必须先执行以下命令**获取当前本地时间戳：

```bash
python -c "from datetime import datetime; print(datetime.now().astimezone().strftime('%Y%m%d_%H%M%S'))"
```

将输出的时间戳记为 `<timestamp>`（例如输出 `20260424_153025`，则 `<timestamp>` = `20260424_153025`）。

> ⚠️ **必须实际执行此命令**，不得自行编造或猜测时间戳。禁止使用 `20260424_120000` 等占位时间戳。

然后定义工作文件夹路径。工作文件夹**必须**创建在输入 docx 文件所在目录下，使用**绝对路径**：

- `<work_dir>` = `<input_dir>\patdocx_cn_single-agent_checker_<timestamp>`（如 `D:\docs\patdocx_cn_single-agent_checker_20260424_153025`）

> ⛔ **工作文件夹位置禁止事项**：
> 
> - **禁止**在 skill 目录（`.trae/skills/patdocx_cn_single-agent_checker/`）内创建工作文件夹
> - **禁止**使用相对路径（如 `patdocx_cn_single-agent_checker_<timestamp>`），必须使用绝对路径（如 `<work_dir>`）
> - 后续所有步骤中的路径**必须**使用 `<work_dir>` 绝对路径前缀

创建工作文件夹：

```bash
mkdir "<work_dir>"
```

后续步骤中的中间产物都放在 `<work_dir>` 下。

### 第三步：提取文档文本并分割章节

#### 3.1 提取完整文本

使用本 skill 提供的 `patent_extractor.py` 脚本提取 docx 文件的完整文本内容：

```bash
python "<skill_root>\scripts\patent_extractor.py" "<input_docx>" --extract-only > "<work_dir>\extracted_text_<timestamp>.txt"
```

> ⚠️ **禁止**使用 `python -c` 执行多行 Python 代码来提取文本，也**禁止**将提取代码保存为独立的 `.py` 文件。`patent_extractor.py` 已内置 `--extract-only` 参数，直接调用即可。

> ⚠️ **文本提取完整性注意**：python-docx 的 `doc.paragraphs` 和 `doc.tables` 只能提取正文内容，**无法提取**文本框、形状、脚注、尾注中的文字。如果文档包含这些元素，应提醒用户可能存在未检查到的区域。

#### 3.2 分割为章节

使用 `patent_extractor.py` 的 `--output-json` 参数将文本分割为 5 个章节：

```bash
python "<skill_root>\scripts\patent_extractor.py" "<input_docx>" --output-json "<work_dir>\sections_<timestamp>.json"
```

该命令会输出一个 JSON 文件，包含以下 5 个章节的文本：

| 字段                 | 章节    |
|:------------------ |:----- |
| `abstract_text`    | 摘要    |
| `abstract_fig`     | 摘要附图  |
| `claims`           | 权利要求书 |
| `description`      | 说明书   |
| `description_figs` | 说明书附图 |

> ⚠️ **文件命名规则（必须严格遵守）**：提取的文本文件命名为 `extracted_text_<timestamp>.txt`，章节 JSON 文件命名为 `sections_<timestamp>.json`，均放在 `<work_dir>` 下。**禁止自行编造时间戳**，**禁止使用**无时间戳的文件名。

### 第四步：AI 按审查规则逐章审查

> ⚠️ 这是核心审查步骤。AI 必须逐一读取审查规则文件，将规则内容作为审查提示词（prompt），结合对应章节的文本进行审查。

#### 4.1 读取审查规则

审查规则文件位于 `<skill_root>\审查规则\` 目录下，共 13 个 .txt 文件。AI 必须**逐一读取**每个规则文件的完整内容，作为审查对应章节时的提示词。

#### 4.2 按章节应用审查规则

各章节对应的审查规则如下：

| 章节               | 审查规则文件                       | 说明                       |
|:---------------- |:---------------------------- |:------------------------ |
| 摘要               | `11-摘要-简单检查1.txt`            | 字数、段落、商业用语、附图标记等         |
| 摘要               | `12-摘要-复杂检查1.txt`            | 摘要表述完整性、各要素一致性           |
| 权利要求书            | `31-权利要求书-简单审查1-格式检查1.txt`   | 序号格式、编号、句号使用等            |
| 权利要求书            | `31-权利要求书-简单审查2-格式检查2.txt`   | 附图标记、模糊词、绝对化词等           |
| 权利要求书            | `31-权利要求书-简单审查3-所述的引用基础.txt` | "所述"引用基础、应加"所述"等         |
| 权利要求书            | `31-权利要求书-简单审查4-引用与主题.txt`   | 从属权利要求引用关系、多引多、单一性等      |
| 权利要求书            | `32-权利要求书-复杂审查1.txt`         | 保护范围不清楚、权利要求不简要          |
| 权利要求书            | `32-权利要求书-复杂审查2-单一性.txt`     | 独立权利要求之间的单一性             |
| 说明书              | `41-说明书-简单审查1.txt`           | 发明名称、技术领域、背景技术、发明内容等     |
| 说明书              | `42-说明书-复杂审查1-说明书公开是否充分.txt` | 说明书公开充分性                 |
| 全文（摘要+权利要求书+说明书） | `61-全文-简单审查1.txt`            | 错别字、术语一致性、附图标记一致性等       |
| 全文（摘要+权利要求书+说明书） | `62-全文-复杂审查1.txt`            | 权利要求书是否得到说明书支持、摘要与说明书一致性 |

#### 4.3 执行审查

对每个章节，按以下流程执行审查：

1. 读取该章节对应的审查规则 .txt 文件的**完整内容**
2. 将规则内容作为审查提示词，结合第三步提取的章节文本，逐条检查是否存在问题
3. 对于权利要求书的审查规则，需要结合权利要求之间的引用关系进行分析
4. 对于全文审查规则（61、62），需要同时参考摘要、权利要求书和说明书的文本
5. 收集所有发现的问题

#### 4.4 输出审查意见 JSON

将所有审查发现的问题整理为以下 JSON 格式，保存为 `<work_dir>\reviews_<timestamp>.json`：

```json
[
  {
    "section": "摘要",
    "claim_number": null,
    "issue": "摘要字数超过300字",
    "context": "摘要中包含问题原文的上下文片段",
    "suggestion": "建议删减字词，使摘要不超过300字",
    "action_type": "comment",
    "old_text": null,
    "new_text": null
  },
  {
    "section": "权利要求书",
    "claim_number": 1,
    "issue": "附图标记未加括号",
    "context": "第一箍套1",
    "suggestion": "建议将'第一箍套1'修改为'第一箍套（1）'",
    "action_type": "replace",
    "old_text": "第一箍套1",
    "new_text": "第一箍套（1）"
  },
  {
    "section": "权利要求书",
    "claim_number": 2,
    "issue": "使用了具体数值限定权利要求",
    "context": "所述进气口之间的夹角呈60°或120°",
    "suggestion": "建议使用数值范围限定，如'所述进气口之间的夹角呈60°至120°'",
    "action_type": "replace",
    "old_text": "所述进气口之间的夹角呈60°或120°",
    "new_text": "所述进气口之间的夹角呈60°至120°"
  },
  {
    "section": "说明书",
    "claim_number": null,
    "issue": "包含商业性宣传用语",
    "context": "本卡箍压榨出的山茶油味道香、口感棒。",
    "suggestion": "建议删除商业性宣传用语",
    "action_type": "delete",
    "old_text": "本卡箍压榨出的山茶油味道香、口感棒。",
    "new_text": null
  },
  {
    "section": "说明书",
    "claim_number": null,
    "issue": "发明名称超过25个字",
    "context": "一种用于……的装置",
    "suggestion": "建议精简发明名称至25字以内",
    "action_type": "comment",
    "old_text": null,
    "new_text": null
  }
]
```

JSON 字段说明：

| 字段             | 类型            | 说明                                                                               |
|:-------------- |:------------- |:-------------------------------------------------------------------------------- |
| `section`      | string        | 问题所属章节：`"摘要"`、`"权利要求书"`、`"说明书"`                                                  |
| `claim_number` | number 或 null | 如果问题属于某项权利要求，填写权利要求序号；否则为 null                                                   |
| `issue`        | string        | 问题描述                                                                             |
| `context`      | string        | 问题原文上下文（用于在文档中定位并添加批注）                                                           |
| `suggestion`   | string        | 修改建议                                                                             |
| `action_type`  | string        | 操作类型：`"comment"`（仅添加批注）、`"replace"`（修订模式下替换字词）、`"delete"`（修订模式下删除字词）             |
| `old_text`     | string 或 null | 需要被替换或删除的原文文本。`action_type` 为 `"replace"` 或 `"delete"` 时必填，为 `"comment"` 时为 null |
| `new_text`     | string 或 null | 替换后的新文本。`action_type` 为 `"replace"` 时必填，为 `"delete"` 或 `"comment"` 时为 null       |

> ⚠️ **审查意见要求**：
> 
> - 审查意见必须基于审查规则，不得随意添加规则外的意见
> - 每条审查意见必须有明确的 `context`（原文上下文），`context` 必须是文档中实际存在的文本片段，用于 `review_adder.py` 在文档中定位并添加批注
> - `context` 应尽量精确定位到包含问题的最小文本片段
> - **`action_type`** **判定规则**：如果修改建议中明确指出了需要删除或替换的具体字词（如"建议将'X'修改为'Y'"或"建议删除'X'"），则 `action_type` 应为 `"replace"` 或 `"delete"`，并填写 `old_text`/`new_text`；如果修改建议无法明确具体操作（如"建议删减字词"），则 `action_type` 应为 `"comment"`
> - `action_type` 为 `"replace"` 或 `"delete"` 时，`old_text` 必须是文档中实际存在的文本，且必须是 `context` 的子串或等于 `context`

> ⚠️ **文件命名规则（必须严格遵守）**：审查意见 JSON 文件必须放在 `<work_dir>` 下，命名为 `reviews_<timestamp>.json`。**禁止自行编造时间戳**，**禁止使用** `reviews.json` 等无时间戳的文件名。

### 第五步：整理汇总审查意见

使用审查规则 `71-整理汇总输出.txt` 中的模板，将第四步的所有审查意见整理为一份结构化的 markdown 报告。

1. 读取 `<skill_root>\审查规则\71-整理汇总输出.txt` 的内容，按照其中的模板格式组织审查意见
2. 将审查意见按章节分类：摘要、摘要附图、权利要求书、说明书、说明书附图、无法归类的问题
3. 权利要求书部分按权利要求序号分组列出问题
4. 保存为 `<input_dir>\<input_stem>_review_report_<timestamp>.md`

> ⚠️ **审查意见汇总报告文件位置**：报告文件放在**输入文件同目录下**，**不放入**工作文件夹 `<work_dir>` 下。

> ⚠️ **文件命名规则（必须严格遵守）**：报告文件命名为 `<input_stem>_review_report_<timestamp>.md`（如 `专利申请文件_review_report_20260424_153025.md`）。**禁止自行编造时间戳**，**禁止使用**无时间戳的文件名。

报告结构如下：

```markdown
# 问题
## 摘要一章存在的问题：
1. ……
2. ……

## 摘要附图一章存在的问题：
1. ……

## 权利要求书一章存在的问题：
本权利要求书共有N项权利要求。
独立权利要求：……

本权利要求书存在的问题有：
### 权利要求1：
1. ……

### 权利要求2：
1. ……

### 对单一性的判断
……

## 说明书一章存在的问题：
1. ……

## 说明书附图一章存在的问题：
1. ……

## 无法归类到上述章节中的问题：
1. ……
```

> ⚠️ 报告中每一段的段落末尾应当使用"。"结束。使用"1. "等带有阿拉伯数字的有序列表，禁止使用"\* "等无序列表。

### 第六步：添加批注和修订到 docx

使用本 skill 提供的 `review_adder.py` 脚本将审查意见添加到 docx 文档中。根据审查意见的 `action_type` 字段，脚本会执行不同操作：

| `action_type` | 操作           | 说明                                                     |
|:------------- |:------------ |:------------------------------------------------------ |
| `"comment"`   | 仅添加批注        | 不修改原文，仅在目标位置添加批注标记                                     |
| `"replace"`   | 修订模式下替换 + 批注 | 在修订模式下将 `old_text` 替换为 `new_text`（删除标记 + 插入标记），并添加批注说明 |
| `"delete"`    | 修订模式下删除 + 批注 | 在修订模式下将 `old_text` 标记为删除，并添加批注说明                       |

> ⛔ **再次强调：必须使用** **`review_adder.py`，禁止自行编写批注/修订脚本。** 自行编写脚本调用 `Document` 类的 `get_node` + `replace_node` 会导致严重内容丢失，因为 `replace_node` 会替换整个 `w:r` 节点，而一个 `w:r` 节点可能包含除目标文本外的其他文本，这些文本会随节点替换而丢失。`review_adder.py` 内部已正确处理了文本拆分逻辑（将 `w:r` 中的文本拆分为"目标文本前文本 + 删除标记 + 插入标记 + 目标文本后文本"），不会丢失任何内容。

> ℹ️ **跨** **`w:r`** **元素文本定位**：Word 文档中的文本经常被拆分到多个 `w:r`（run）元素中（例如因格式变化、拼写检查标记等原因）。`review_adder.py` 已内置跨 run 文本映射功能（`_map_text_to_runs`），能够自动将 `context` 和 `old_text` 映射到跨越多个 run 的文本位置，无需担心文本被拆分导致定位失败。批注范围会精确覆盖从第一个到最后一个包含目标文本的 run，替换/删除操作也会正确拆分每个 run 并应用修订标记。

```bash
python "<skill_root>\scripts\review_adder.py" "<input_docx>" "<input_dir>\<input_stem>_ReviewOut_<timestamp>.docx" --reviews-file "<work_dir>\reviews_<timestamp>.json"
```

> ⚠️ **Windows PowerShell 环境注意事项**：
> 
> - **禁止**使用 `PYTHONPATH=<skill_root> python -m ...` 的 bash 语法设置环境变量，PowerShell 不支持此语法
> - **必须**使用 `python "<skill_root>\scripts\review_adder.py"` 直接调用脚本，脚本内部已自动处理 `sys.path`

脚本执行后会输出处理统计信息，包括成功和跳过的数量。请关注输出中的 `⚠ 未找到文本` 和 `⚠ 未找到待替换文本`/`⚠ 未找到待删除文本` 条目，这些表示在文档中未找到对应的文本。对于 `action_type` 为 `"replace"` 或 `"delete"` 的条目，如果修订操作失败，脚本会自动降级为仅添加批注。

> ⚠️ **如果跳过数量大于 0**，需要检查原因：可能是 `context` 或 `old_text` 在文档中不存在（AI 审查误判）。跨 `w:r` 元素的文本已由 `_map_text_to_runs` 自动处理，不再因此导致跳过。

> ⚠️ **输出文件命名规则（必须严格遵守）**：输出 docx 文件名必须为 `<input_stem>_ReviewOut_<timestamp>.docx`，其中 `<timestamp>` 为第二步中实际执行命令获取的本地时间戳。此文件放在输入文件同目录下，**不放入**工作文件夹。**禁止自行编造时间戳**，**禁止使用** `原文件名_ReviewOut.docx` 等无时间戳的文件名。

### 第七步：内容完整性验证（强制性）

> ⛔ **本步骤为强制性步骤，不得跳过。** 未通过验证的文档**禁止**输出给用户。如果验证失败，必须排查原因并修正后重新执行第六步和第七步。

使用本 skill 提供的 `verify.py` 脚本进行验证：

```bash
python "<skill_root>\scripts\verify.py" "<input_docx>" "<input_dir>\<input_stem>_ReviewOut_<timestamp>.docx" "<work_dir>"
```

该脚本会自动执行以下三项验证：

1. **段落数量验证**：对比原始文档与审查文档的段落数量，确保一致
2. **模拟接受修订验证**：模拟"接受所有修订"，确认只有预期的字词被修改，没有其他内容丢失
3. **文件结构验证**：确保审查文档保留了原始文档的所有文件，仅新增批注相关文件

> ⚠️ **禁止**使用 `python -c` 执行多行 Python 代码来验证，也**禁止**将验证代码保存为独立的 `.py` 文件。`verify.py` 已封装全部验证逻辑，直接调用即可。

> ⛔ **如果任何验证项未通过（输出 ❌），必须排查原因并修正后再继续**，不得向用户输出有内容缺失的文档。常见原因：使用了自行编写的批注添加脚本而非 `review_adder.py`，导致 `w:r` 节点被整体替换而丢失非目标文本。

## 最终输出结果

向用户报告审查结果：

```
📋 专利申请文件审查完成

审查文件：xxx.docx
发现问题：N 处

【审查摘要】
- 摘要：X 处问题
- 权利要求书：Y 处问题（涉及 Z 项权利要求）
- 说明书：W 处问题
- 全文一致性：V 处问题

已生成审查版文档：xxx_ReviewOut_<timestamp>.docx
- 明确了具体操作的修改建议已在修订模式下执行替换或删除，可在 Word 中逐一接受/拒绝
- 无法明确具体操作的修改建议以批注标记，可在 Word 中查看
- 批注第一行为问题描述，换行后为修改建议

审查意见汇总报告：<input_dir>\<input_stem>_review_report_<timestamp>.md
中间文件保存在：<work_dir>
```

## 重要规则

1. **审查意见必须基于审查规则**：所有审查意见必须来源于 `<skill_root>\审查规则\` 目录下的 13 条规则，不得随意添加规则外的意见
2. **每条审查意见必须有明确的 context**：`context` 字段必须是文档中实际存在的文本片段，用于 `review_adder.py` 在文档中定位并添加批注。没有 `context` 的审查意见无法添加批注，将被跳过
3. **区分修改建议类型，执行不同操作**：
   - **明确了具体操作的修改建议**（`action_type` 为 `"replace"` 或 `"delete"`）：在修订模式下执行对该字词的删除或替换操作，同时添加批注说明。例如：
     - 替换：修改建议"建议将'第一箍套1'修改为'第一箍套（1）'"→ 在修订模式下将"第一箍套1"替换为"第一箍套（1）"（`action_type: "replace"`，`old_text: "第一箍套1"`，`new_text: "第一箍套（1）"`）
     - 删除：修改建议"建议删除商业性宣传用语"→ 在修订模式下删除句子"本卡箍压榨出的山茶油味道香、口感棒。"（`action_type: "delete"`，`old_text: "本卡箍压榨出的山茶油味道香、口感棒。"`，`new_text: null`）
   - **无法明确具体操作的修改建议**（`action_type` 为 `"comment"`）：仅在 docx 文档中针对目标字词或句子添加批注标记，不修改原文。例如：
     - 修改建议"建议删减字词，使摘要不超过300字"→ 仅添加批注（`action_type: "comment"`，`old_text: null`，`new_text: null`）
4. **⚠️ 文件命名必须带本地时间戳（严格遵守）**：
   - 在工作流开始前，**必须先执行** `python -c "from datetime import datetime; print(datetime.now().astimezone().strftime('%Y%m%d_%H%M%S'))"` 获取真实本地时间戳，记为 `<timestamp>`
   - 工作文件夹**必须**命名为 `<input_dir>\patdocx_cn_single-agent_checker_<timestamp>`（如 `D:\docs\patdocx_cn_single-agent_checker_20260424_153025`），使用绝对路径 `<work_dir>`
   - 中间产出的文件**必须**放在 `<work_dir>` 下，命名包含 `<timestamp>`：`extracted_text_<timestamp>.txt`、`sections_<timestamp>.json`、`reviews_<timestamp>.json`。**禁止自行编造时间戳**，**禁止**使用无时间戳的文件名
   - 审查意见汇总报告**必须**命名为 `<input_stem>_review_report_<timestamp>.md`，放在**输入文件同目录下**，**不放入**工作文件夹。**禁止自行编造时间戳**，**禁止**使用无时间戳的文件名
   - 最终产出的审查版 docx 文件**必须**命名为 `<input_stem>_ReviewOut_<timestamp>.docx`，放在输入文件同目录下，**不放入**工作文件夹。**禁止自行编造时间戳**，**禁止**使用 `原文件名_ReviewOut.docx` 等无时间戳的文件名
5. **⚠️ 工作文件夹管理**：
   - 所有中间产物（提取的文本、章节 JSON、审查意见 JSON 等）**必须**放在 `<work_dir>` 下
   - 审查意见汇总报告和最终审查版 docx 文件**不放入**工作文件夹，放在输入文件同目录下
   - **⛔ 工作文件夹必须创建在输入 docx 文件所在目录下**，命名格式为 `patdocx_cn_single-agent_checker_<timestamp>`，**禁止**在 skill 目录（`.trae/skills/patdocx_cn_single-agent_checker/`）内创建工作文件夹
   - **⛔ 所有路径必须使用绝对路径**（基于 `<work_dir>`），**禁止**使用相对路径（如 `patdocx_cn_single-agent_checker_<timestamp>`），因为相对路径依赖于当前工作目录，不同命令的 cwd 可能不同，会导致在错误位置创建文件夹
6. **⛔ 禁止在终端中直接执行多行 Python 代码**：
   - 本 skill 已提供 `patent_extractor.py`（文本提取与章节分割）、`review_adder.py`（批注添加）和 `verify.py`（验证功能），**必须直接调用这些脚本**
   - **禁止**使用 `python -c` 执行多行 Python 代码（含 for 循环、if 语句、函数定义等），PowerShell 的引号嵌套和语句分隔规则与 bash 不同，极易导致语法错误
   - **禁止**将多行 Python 代码保存为独立的 `.py` 文件放在项目目录中
   - 所有功能应通过调用 skill 提供的脚本实现
7. **⚠️ Windows PowerShell 环境兼容性**：
   - **禁止**使用 bash 语法 `PYTHONPATH=xxx python -m ...` 设置环境变量，PowerShell 不支持此语法
   - **必须**使用 `python "<skill_root>\scripts\脚本名.py"` 直接调用脚本，脚本内部已自动处理 `sys.path`
   - Windows 路径中的反斜杠 `\` 在命令行参数中直接使用即可，**不要**手动添加额外转义
8. **⛔ 验证步骤为强制性**：
   - 必须使用 `verify.py` 脚本执行第七步的三项验证（段落数量、模拟接受修订、文件结构）
   - 任何验证项未通过时，**禁止**向用户输出文档，必须排查原因并修正
9. **修订追踪规范**：
   - 替换文本使用 `<w:del>` + `<w:delText>`（标记删除旧文本）+ `<w:ins>` + `<w:t>`（标记插入新文本）
   - 删除文本使用 `<w:del>` + `<w:delText>`（标记删除文本）
   - 替换文本时必须保留原 run 的 rPr（格式属性）
   - 最小化修改：只标记实际更改的文本，未更改的文本不要放入 `<w:del>`/`<w:ins>` 标签
10. **⚠️ 文件类型限制**：
- 本 skill 仅支持 `.docx` 格式的文件，不支持 `.doc`、`.pdf`、`.txt` 等其他格式
- 第一步必须先检查文件类型，非 `.docx` 文件直接告知用户不支持并终止流程

## 技术架构

```
patdocx_cn_single-agent_checker/
├── SKILL.md                          # 本文件
├── scripts/
│   ├── __init__.py
│   ├── document.py                   # Document 类（OOXML 编辑）
│   ├── utilities.py                  # XMLEditor 基类
│   ├── patent_extractor.py           # 专利文本提取与章节分割脚本
│   │                                 #   --extract-only: 提取完整文本（第三步 3.1）
│   │                                 #   --output-json: 分割为5个章节JSON（第三步 3.2）
│   ├── review_adder.py               # 审查意见批注添加脚本（第六步，必须使用此脚本）
│   │                                 #   --reviews-file: 通过 JSON 文件添加批注
│   │                                 #   --author: 批注作者名称
│   ├── verify.py                     # 内容完整性验证脚本（第七步）
│   └── templates/                    # 批注相关 XML 模板
│       ├── comments.xml
│       ├── commentsExtended.xml
│       ├── commentsIds.xml
│       ├── commentsExtensible.xml
│       └── people.xml
├── ooxml/
│   └── scripts/
│       ├── unpack.py                 # docx 解压
│       ├── pack.py                   # docx 打包
│       └── validation/              # 验证工具
│           ├── __init__.py
│           ├── base.py
│           ├── docx.py
│           └── redlining.py
├── 审查规则/
│   ├── 11-摘要-简单检查1.txt
│   ├── 12-摘要-复杂检查1.txt
│   ├── 31-权利要求书-简单审查1-格式检查1.txt
│   ├── 31-权利要求书-简单审查2-格式检查2.txt
│   ├── 31-权利要求书-简单审查3-所述的引用基础.txt
│   ├── 31-权利要求书-简单审查4-引用与主题.txt
│   ├── 32-权利要求书-复杂审查1.txt
│   ├── 32-权利要求书-复杂审查2-单一性.txt
│   ├── 41-说明书-简单审查1.txt
│   ├── 42-说明书-复杂审查1-说明书公开是否充分.txt
│   ├── 61-全文-简单审查1.txt
│   ├── 62-全文-复杂审查1.txt
│   └── 71-整理汇总输出.txt
└── requirements.txt
```

## 依赖

- Python 3.10+
- defusedxml
- lxml
- python-docx



## ISSUE反馈

https://cnb.cool/toddzi/skills_public/-/issues
