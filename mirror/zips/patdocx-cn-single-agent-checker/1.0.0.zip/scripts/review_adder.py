#!/usr/bin/env python3
import argparse
import json
import re
import sys
import tempfile
from pathlib import Path

SKILL_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(SKILL_ROOT))

from ooxml.scripts.unpack import unpack_document
from ooxml.scripts.pack import pack_document
from scripts.document import Document


def _is_in_deletion(elem):
    parent = elem.parentNode
    while parent:
        if parent.nodeType == parent.ELEMENT_NODE and parent.tagName == "w:del":
            return True
        parent = parent.parentNode
    return False


def _get_text_from_element(elem):
    texts = []
    for t_elem in elem.getElementsByTagName("w:t"):
        for child in t_elem.childNodes:
            if child.nodeType == child.TEXT_NODE and child.data:
                texts.append(child.data)
    return "".join(texts)


def _get_direct_run_children(para_elem):
    runs = []
    for child in para_elem.childNodes:
        if child.nodeType == child.ELEMENT_NODE and child.tagName == "w:r":
            if not _is_in_deletion(child) and not child.getElementsByTagName("w:delText"):
                runs.append(child)
    return runs


def _get_rpr_xml(run):
    rpr_nodes = run.getElementsByTagName("w:rPr")
    if rpr_nodes:
        return rpr_nodes[0].toxml()
    return ""


def _map_text_to_runs(runs, target_text):
    """
    Map target text to runs, handling text that spans multiple runs.

    Returns:
        List of (run, start_in_run, end_in_run, run_text) tuples, or None if not found.
        start_in_run and end_in_run are character offsets within the run's text.
    """
    run_text_map = []
    concat_text = ""

    for run in runs:
        run_text = _get_text_from_element(run)
        start = len(concat_text)
        end = start + len(run_text)
        run_text_map.append((run, start, end, run_text))
        concat_text += run_text

    idx = concat_text.find(target_text)
    if idx == -1:
        return None

    target_start = idx
    target_end = idx + len(target_text)

    result = []
    for run, run_start, run_end, run_text in run_text_map:
        overlap_start = max(target_start, run_start)
        overlap_end = min(target_end, run_end)

        if overlap_start < overlap_end:
            start_in_run = overlap_start - run_start
            end_in_run = overlap_end - run_start
            result.append((run, start_in_run, end_in_run, run_text))

    return result if result else None


def _find_context_range(runs, context):
    """
    Find the range of runs that contain the context text.

    Returns:
        (first_run, last_run) or (None, None) if not found.
    """
    mapping = _map_text_to_runs(runs, context)
    if mapping:
        return mapping[0][0], mapping[-1][0]
    return None, None


def _detect_section(para_text, para_index, total_paragraphs):
    stripped = para_text.strip()

    if re.search(r'说\s*明\s*书\s*摘\s*要', stripped):
        return "摘要"
    if re.search(r'摘\s*要\s*附\s*图', stripped):
        return "摘要附图"
    if re.search(r'权\s*利\s*要\s*求\s*书', stripped):
        return "权利要求书"
    if stripped in ('技术领域', '背景技术', '发明内容', '实用新型内容', '附图说明', '具体实施方式'):
        return "说明书"
    if re.search(r'说\s*明\s*书\s*附\s*图', stripped):
        return "说明书附图"

    if re.match(r'^1\s*[.、]\s*', stripped):
        return "权利要求书"

    return None


def _find_section_boundaries(paragraphs):
    section_starts = {}
    for i, para in enumerate(paragraphs):
        para_text = _get_text_from_element(para)
        section = _detect_section(para_text, i, len(paragraphs))
        if section and section not in section_starts:
            section_starts[section] = i

    ordered = sorted(section_starts.items(), key=lambda x: x[1])

    section_ranges = {}
    for idx, (name, start) in enumerate(ordered):
        if idx + 1 < len(ordered):
            end = ordered[idx + 1][1]
        else:
            end = len(paragraphs)
        section_ranges[name] = (start, end)

    if not section_ranges:
        section_ranges["全文"] = (0, len(paragraphs))
        return section_ranges

    first_section_start = ordered[0][1]
    if first_section_start > 0:
        if "摘要" not in section_ranges:
            section_ranges["摘要"] = (0, first_section_start)

    if "权利要求书" not in section_ranges and "摘要" in section_ranges:
        abstract_end = section_ranges["摘要"][1]
        for i in range(abstract_end, len(paragraphs)):
            para_text = _get_text_from_element(paragraphs[i]).strip()
            if re.match(r'^\d+\s*[.、]\s*', para_text):
                section_ranges["权利要求书"] = (i, section_ranges.get("说明书", (len(paragraphs),))[0])
                break

    if "摘要附图" not in section_ranges and "摘要" in section_ranges and "权利要求书" in section_ranges:
        abstract_end = section_ranges["摘要"][1]
        claims_start = section_ranges["权利要求书"][0]
        for i in range(abstract_end, claims_start):
            para_text = _get_text_from_element(paragraphs[i]).strip()
            if re.match(r'^图\s*\d', para_text) or re.search(r'摘\s*要\s*附\s*图', para_text):
                section_ranges["摘要附图"] = (i, claims_start)
                break

    return section_ranges


def _find_context_in_section(context, section_name, section_ranges, paragraphs):
    if section_name in section_ranges:
        start_idx, end_idx = section_ranges[section_name]
        search_paragraphs = list(paragraphs[start_idx:end_idx])
    else:
        search_paragraphs = list(paragraphs)

    for para in search_paragraphs:
        if _is_in_deletion(para):
            continue
        runs = _get_direct_run_children(para)
        first_run, last_run = _find_context_range(runs, context)
        if first_run is not None:
            return first_run, last_run

    return None, None


def _find_context_anywhere(context, paragraphs):
    for para in paragraphs:
        if _is_in_deletion(para):
            continue
        runs = _get_direct_run_children(para)
        first_run, last_run = _find_context_range(runs, context)
        if first_run is not None:
            return first_run, last_run

    return None, None


def _escape_xml(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _apply_replace_in_revision_mode(doc, old_text, new_text):
    dom = doc["word/document.xml"].dom
    paragraphs = list(dom.getElementsByTagName("w:p"))

    for para in paragraphs:
        if _is_in_deletion(para):
            continue
        runs = _get_direct_run_children(para)
        mapping = _map_text_to_runs(runs, old_text)
        if mapping is None:
            continue

        parts = []
        for i, (run, start_in_run, end_in_run, run_text) in enumerate(mapping):
            rpr = _get_rpr_xml(run)

            before_text = run_text[:start_in_run]
            target_part = run_text[start_in_run:end_in_run]
            after_text = run_text[end_in_run:]

            if i == 0 and before_text:
                parts.append(f'<w:r>{rpr}<w:t xml:space="preserve">{_escape_xml(before_text)}</w:t></w:r>')

            parts.append(f'<w:del><w:r>{rpr}<w:delText>{_escape_xml(target_part)}</w:delText></w:r></w:del>')

            if i == len(mapping) - 1:
                parts.append(f'<w:ins><w:r>{rpr}<w:t>{_escape_xml(new_text)}</w:t></w:r></w:ins>')
                if after_text:
                    parts.append(f'<w:r>{rpr}<w:t xml:space="preserve">{_escape_xml(after_text)}</w:t></w:r>')

        replacement = "".join(parts)

        first_run = mapping[0][0]
        new_nodes = doc["word/document.xml"].replace_node(first_run, replacement)

        runs_to_remove = set()
        first_idx = None
        last_idx = None
        for idx, run in enumerate(runs):
            if run is mapping[0][0]:
                first_idx = idx
            if run is mapping[-1][0]:
                last_idx = idx

        if first_idx is not None and last_idx is not None:
            for idx in range(first_idx + 1, last_idx + 1):
                runs_to_remove.add(runs[idx])

        for run in runs_to_remove:
            if run.parentNode:
                run.parentNode.removeChild(run)

        return new_nodes

    return None


def _apply_delete_in_revision_mode(doc, old_text):
    dom = doc["word/document.xml"].dom
    paragraphs = list(dom.getElementsByTagName("w:p"))

    for para in paragraphs:
        if _is_in_deletion(para):
            continue
        runs = _get_direct_run_children(para)
        mapping = _map_text_to_runs(runs, old_text)
        if mapping is None:
            continue

        parts = []
        for i, (run, start_in_run, end_in_run, run_text) in enumerate(mapping):
            rpr = _get_rpr_xml(run)

            before_text = run_text[:start_in_run]
            target_part = run_text[start_in_run:end_in_run]
            after_text = run_text[end_in_run:]

            if i == 0 and before_text:
                parts.append(f'<w:r>{rpr}<w:t xml:space="preserve">{_escape_xml(before_text)}</w:t></w:r>')

            parts.append(f'<w:del><w:r>{rpr}<w:delText>{_escape_xml(target_part)}</w:delText></w:r></w:del>')

            if i == len(mapping) - 1 and after_text:
                parts.append(f'<w:r>{rpr}<w:t xml:space="preserve">{_escape_xml(after_text)}</w:t></w:r>')

        replacement = "".join(parts)

        first_run = mapping[0][0]
        new_nodes = doc["word/document.xml"].replace_node(first_run, replacement)

        runs_to_remove = set()
        first_idx = None
        last_idx = None
        for idx, run in enumerate(runs):
            if run is mapping[0][0]:
                first_idx = idx
            if run is mapping[-1][0]:
                last_idx = idx

        if first_idx is not None and last_idx is not None:
            for idx in range(first_idx + 1, last_idx + 1):
                runs_to_remove.add(runs[idx])

        for run in runs_to_remove:
            if run.parentNode:
                run.parentNode.removeChild(run)

        return new_nodes

    return None


def add_reviews(input_path: str, output_path: str, reviews: list, author: str = "patdocx_cn_single-agent_checker"):
    input_path = Path(input_path)
    output_path = Path(output_path)

    if not input_path.exists():
        raise FileNotFoundError(f"输入文件不存在: {input_path}")

    with tempfile.TemporaryDirectory(prefix="review_add_") as temp_dir:
        unpacked_dir = Path(temp_dir) / "unpacked"

        print(f"正在解压 {input_path.name} ...")
        unpack_document(str(input_path), str(unpacked_dir))

        print(f"正在初始化文档编辑器 ...")
        doc = Document(
            str(unpacked_dir),
            track_revisions=True,
            author=author,
            initials="SA"
        )

        dom = doc["word/document.xml"].dom
        paragraphs = list(dom.getElementsByTagName("w:p"))
        section_ranges = _find_section_boundaries(paragraphs)
        print(f"已识别章节范围: {[(k, v) for k, v in section_ranges.items()]}")

        success_count = 0
        skip_count = 0

        for i, review in enumerate(reviews):
            section = review.get("section", "")
            claim_number = review.get("claim_number")
            issue = review.get("issue", "")
            context = review.get("context", "")
            suggestion = review.get("suggestion", "")
            action_type = review.get("action_type", "comment")
            old_text = review.get("old_text")
            new_text = review.get("new_text")

            if not context:
                print(f"  跳过无效条目 #{i+1}: context 为空")
                skip_count += 1
                continue

            print(f'  处理 #{i+1}: [{section}] action_type={action_type} "{context}"')

            comment_text = ""
            if section == "权利要求书" and claim_number is not None:
                comment_text = f"权利要求{claim_number}: "
            comment_text += f"{issue}\n修改建议：{suggestion}"

            if action_type == "replace":
                if not old_text or not new_text:
                    print(f"    ⚠ action_type=replace 但 old_text 或 new_text 为空，降级为仅添加批注")
                    first_run, last_run = _find_context_in_section(context, section, section_ranges, paragraphs)
                    if first_run is None:
                        print(f"    在章节 \"{section}\" 中未找到，尝试全文搜索...")
                        first_run, last_run = _find_context_anywhere(context, paragraphs)
                    if first_run is None:
                        print(f"    ⚠ 未找到文本: \"{context}\"")
                        skip_count += 1
                        continue
                    doc.add_comment(start=first_run, end=last_run, text=comment_text)
                    success_count += 1
                    print(f"    ✓ 已添加批注（降级）")
                    continue

                new_nodes = _apply_replace_in_revision_mode(doc, old_text, new_text)
                if new_nodes is None:
                    print(f"    ⚠ 未找到待替换文本: \"{old_text}\"，降级为仅添加批注")
                    first_run, last_run = _find_context_in_section(context, section, section_ranges, paragraphs)
                    if first_run is None:
                        first_run, last_run = _find_context_anywhere(context, paragraphs)
                    if first_run is None:
                        print(f"    ⚠ 未找到上下文文本: \"{context}\"")
                        skip_count += 1
                        continue
                    doc.add_comment(start=first_run, end=last_run, text=comment_text)
                    success_count += 1
                    print(f"    ✓ 已添加批注（降级）")
                    continue

                doc.add_comment(start=new_nodes[0], end=new_nodes[-1], text=comment_text)
                success_count += 1
                print(f"    ✓ 已在修订模式下替换并添加批注")

            elif action_type == "delete":
                if not old_text:
                    print(f"    ⚠ action_type=delete 但 old_text 为空，降级为仅添加批注")
                    first_run, last_run = _find_context_in_section(context, section, section_ranges, paragraphs)
                    if first_run is None:
                        print(f"    在章节 \"{section}\" 中未找到，尝试全文搜索...")
                        first_run, last_run = _find_context_anywhere(context, paragraphs)
                    if first_run is None:
                        print(f"    ⚠ 未找到文本: \"{context}\"")
                        skip_count += 1
                        continue
                    doc.add_comment(start=first_run, end=last_run, text=comment_text)
                    success_count += 1
                    print(f"    ✓ 已添加批注（降级）")
                    continue

                new_nodes = _apply_delete_in_revision_mode(doc, old_text)
                if new_nodes is None:
                    print(f"    ⚠ 未找到待删除文本: \"{old_text}\"，降级为仅添加批注")
                    first_run, last_run = _find_context_in_section(context, section, section_ranges, paragraphs)
                    if first_run is None:
                        first_run, last_run = _find_context_anywhere(context, paragraphs)
                    if first_run is None:
                        print(f"    ⚠ 未找到上下文文本: \"{context}\"")
                        skip_count += 1
                        continue
                    doc.add_comment(start=first_run, end=last_run, text=comment_text)
                    success_count += 1
                    print(f"    ✓ 已添加批注（降级）")
                    continue

                doc.add_comment(start=new_nodes[0], end=new_nodes[-1], text=comment_text)
                success_count += 1
                print(f"    ✓ 已在修订模式下删除并添加批注")

            else:
                first_run, last_run = _find_context_in_section(context, section, section_ranges, paragraphs)

                if first_run is None:
                    print(f"    在章节 \"{section}\" 中未找到，尝试全文搜索...")
                    first_run, last_run = _find_context_anywhere(context, paragraphs)

                if first_run is None:
                    print(f"    ⚠ 未找到文本: \"{context}\"")
                    skip_count += 1
                    continue

                doc.add_comment(
                    start=first_run,
                    end=last_run,
                    text=comment_text
                )

                success_count += 1
                print(f"    ✓ 已添加批注")

        print(f"正在保存修改 ...")
        doc.save()

        print(f"正在打包为 {output_path.name} ...")
        output_path.parent.mkdir(parents=True, exist_ok=True)
        pack_document(str(unpacked_dir), str(output_path), validate=False)

    print(f"\n处理完成：共 {len(reviews)} 处，成功 {success_count} 处，跳过 {skip_count} 处")
    return {"total": len(reviews), "success": success_count, "skip": skip_count}


def main():
    parser = argparse.ArgumentParser(description="审查意见批注添加工具")
    parser.add_argument("input", help="输入 docx 文件路径")
    parser.add_argument("output", help="输出 docx 文件路径")
    parser.add_argument("--reviews-file", required=True, help="审查意见 JSON 文件路径")
    parser.add_argument("--author", default="patdocx_cn_single-agent_checker", help="批注作者名称")

    args = parser.parse_args()

    reviews_path = Path(args.reviews_file)
    if not reviews_path.exists():
        print(f"错误：审查意见文件不存在: {reviews_path}")
        sys.exit(1)

    with open(reviews_path, "r", encoding="utf-8") as f:
        reviews = json.load(f)

    add_reviews(args.input, args.output, reviews, args.author)


if __name__ == "__main__":
    main()
