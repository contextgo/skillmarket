#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
百度热搜抓取脚本
从 top.baidu.com 抓取当日实时热搜榜单
"""

import json
import sys
from datetime import datetime
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

def fetch_baidu_hot():
    """
    抓取百度热搜榜单
    返回：热搜列表（包含标题、热度、摘要）
    """
    
    # 百度热搜API（官方接口）
    api_url = "https://top.baidu.com/api/board?apiType=1&ent=1&cate=1&tab=realtime"
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
        'Referer': 'https://top.baidu.com/',
    }
    
    try:
        request = Request(api_url, headers=headers)
        response = urlopen(request, timeout=10)
        data = json.loads(response.read().decode('utf-8'))
        
        # 解析热搜数据
        if data.get('data') and data['data'].get('realtime'):
            hot_list = []
            for idx, item in enumerate(data['data']['realtime'], 1):
                hot_item = {
                    'rank': idx,
                    'title': item.get('word', ''),
                    'hot_score': item.get('hotScore', 0),
                    'desc': item.get('wordDesc', ''),
                    'url': item.get('url', ''),
                }
                hot_list.append(hot_item)
            
            return hot_list
        else:
            print("错误：无法解析API返回数据", file=sys.stderr)
            return None
            
    except HTTPError as e:
        print(f"HTTP错误：{e.code} - {e.reason}", file=sys.stderr)
        return None
    except URLError as e:
        print(f"网络错误：{e.reason}", file=sys.stderr)
        return None
    except Exception as e:
        print(f"未知错误：{str(e)}", file=sys.stderr)
        return None

def format_output(hot_list):
    """
    格式化输出热搜榜单
    """
    if not hot_list:
        return "无数据"
    
    output = []
    output.append("=" * 70)
    output.append(f"百度热搜榜单 - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    output.append("=" * 70)
    output.append("")
    
    for item in hot_list:
        output.append(f"【{item['rank']:02d}】{item['title']}")
        output.append(f"     热度：{item['hot_score']:,}")
        if item['desc']:
            output.append(f"     简介：{item['desc']}")
        output.append("")
    
    output.append("=" * 70)
    output.append(f"共 {len(hot_list)} 条热搜")
    output.append("=" * 70)
    
    return "\n".join(output)

def save_to_file(hot_list, filename=None):
    """
    保存热搜数据到JSON文件
    """
    if not filename:
        filename = f"baidu_hot_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    
    with open(filename, 'w', encoding='utf-8') as f:
        json.dump({
            'timestamp': datetime.now().isoformat(),
            'count': len(hot_list),
            'data': hot_list
        }, f, ensure_ascii=False, indent=2)
    
    return filename

def main():
    """主函数"""
    print("正在抓取百度热搜...")
    print()
    
    hot_list = fetch_baidu_hot()
    
    if hot_list:
        # 输出格式化榜单
        print(format_output(hot_list))
        print()
        
        # 保存到文件
        saved_file = save_to_file(hot_list)
        print(f"数据已保存到：{saved_file}")
        print()
        
        # 返回JSON格式（供其他程序调用）
        print("JSON输出：")
        print(json.dumps(hot_list, ensure_ascii=False, indent=2))
    else:
        print("抓取失败，请检查网络连接或稍后重试")
        print()
        print("备选方案：使用 xbrowser skill 访问 https://top.baidu.com/board?tab=realtime")

if __name__ == "__main__":
    main()
