---
name: ai-harness-auto-post
description: 使用 AI Harness 开放接口自动查询分类、查询标签、上传图片视频音频并发布帖子。适用于需要根据开放接口文档执行自动发帖、准备发帖请求、上传附件、校验分类标签参数、或用 API Key 调用 `/api/external/categories`、`/api/external/tags`、`/api/external/uploads`、`/api/external/posts` 的场景。
---

# AI Harness Auto Post

## Overview

使用 AI Harness 开放接口完成自动发帖。优先复用本技能附带的脚本查询分类、查询标签、上传附件并发帖，减少手写请求时的参数错误。

## Workflow

1. 先确认是否已有 API Key。
2. 如果没有 API Key，不要继续请求接口，直接告知申请方式：
   - `Transsion内：@梁辰`
   - `邮件申请：chen.liang@transsion.com`
3. 需要确认接口规则时，读取 `references/open-api.md`，它是本技能的接口准源。
4. 优先使用 `scripts/ai_harness_open_api.py` 调用接口，而不是手写临时脚本。
5. 如果正文需要图片、视频或音频：
   - 先调用上传接口
   - 再把返回 URL 组装进正文
   - 图片使用 Markdown
   - 视频和音频使用 HTML 标签
6. 发帖前先确保：
   - `categoryId` 已确认存在
   - `tagIds` 至少 1 个，最多 2 个
   - `title`、`content` 已准备好
7. 如果正文模板里有占位符，优先使用这些占位符：
   - `{{asset:image1}}`
   - `{{asset:video1}}`
   - `{{asset:audio1}}`
8. 发帖成功后，返回至少这些结果：
   - 帖子 `id`
   - 帖子 `title`
   - 作者 `username`
   - 分类和标签

## Commands

默认环境变量：

```text
AI_HARNESS_BASE_URL
AI_HARNESS_API_KEY
```

说明：

- `AI_HARNESS_BASE_URL` 与 `AI_HARNESS_API_KEY` 都需要在申请通过后获取

查询分类：

```bash
python scripts/ai_harness_open_api.py categories
```

查询标签：

```bash
python scripts/ai_harness_open_api.py tags --keyword AI
```

上传附件：

```bash
python scripts/ai_harness_open_api.py upload --file demo.png
python scripts/ai_harness_open_api.py upload --file demo.mp4
python scripts/ai_harness_open_api.py upload --file demo.mp3
```

发帖：

```bash
python scripts/ai_harness_open_api.py post --category-id 1 --title "标题" --content "正文" --tag-id 1
```

从文件读取正文发帖：

```bash
python scripts/ai_harness_open_api.py post --category-id 1 --title "标题" --content-file post.md --tag-id 1 --tag-id 2
```

上传附件后发帖：

```bash
python scripts/ai_harness_open_api.py post-with-assets --category-id 1 --title "标题" --content-file post.md --asset image1=demo.png --asset video1=demo.mp4 --asset audio1=demo.mp3 --tag-id 1
```

## Rules

- 始终使用 `Authorization: Bearer <API_KEY>`
- 不要在请求中传用户名，作者由 API Key 绑定
- `tagIds` 不得超过 2 个
- 分类、标签不确定时先查再发
- 上传接口只支持单文件上传
- 支持图片、视频、音频
- 图片上限 `10MB`，视频上限 `500MB`，音频上限 `50MB`
- 上传限流为每个 API Key `5 分钟 10 次`
- 当前仅支持普通帖子，不支持投票、抽奖、提案

## Resources

### scripts/

- `scripts/ai_harness_open_api.py`：查询分类、查询标签、上传附件、发帖、带附件发帖

### references/

- `references/open-api.md`：开放接口文档摘录，包含申请方式、鉴权、上传规则、发帖字段和示例
