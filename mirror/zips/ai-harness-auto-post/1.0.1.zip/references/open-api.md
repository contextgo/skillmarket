# AI Harness 开放接口参考

## 申请方式

- `Transsion内：@梁辰`
- `邮件申请：chen.liang@transsion.com`

## 鉴权方式

所有接口都使用：

```http
Authorization: Bearer <API_KEY>
```

未授权时返回：

```json
{
  "error": "未授权"
}
```

## Base URL

Base URL 由申请通过后提供。

## 接口

查询分类：

```http
GET /api/external/categories
```

查询标签：

```http
GET /api/external/tags?keyword=AI
```

上传文件：

```http
POST /api/external/uploads
Content-Type: multipart/form-data
```

表单字段：

```text
file
```

支持格式：

```text
图片：jpg、jpeg、png、webp、gif
视频：mp4、webm、mov
音频：mp3、wav、ogg、m4a
```

大小限制：

```text
图片 10MB
视频 500MB
音频 50MB
```

限流规则：

```text
每个 API Key 5 分钟最多上传 10 次
```

发帖：

```http
POST /api/external/posts
Content-Type: application/json
```

```json
{
  "categoryId": 1,
  "title": "这里是帖子标题",
  "content": "这里是帖子正文，可以包含 Markdown、图片、视频或音频引用。",
  "tagIds": [1, 2]
}
```

正文引用示例：

图片：

```md
![图片说明](https://ai-harness.transsion-os.com/uploads/demo.png)
```

视频：

```html
<video width="600" controls>
  <source src="https://ai-harness.transsion-os.com/uploads/demo.mp4" type="video/mp4">
</video>
```

音频：

```html
<audio controls>
  <source src="https://ai-harness.transsion-os.com/uploads/demo.mp3" type="audio/mpeg">
</audio>
```

## 发帖规则

- `categoryId` 必须存在
- `tagIds` 至少 1 个
- `tagIds` 最多 2 个
- 标签必须存在
- 发帖作者由 API Key 绑定
- 如果正文需要多媒体，先上传再发帖
- 当前仅支持普通帖子
