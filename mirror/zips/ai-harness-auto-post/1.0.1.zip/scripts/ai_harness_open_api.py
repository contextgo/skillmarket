#!/usr/bin/env python3
"""AI Harness 开放接口脚本。"""

from __future__ import annotations

import argparse
import json
import mimetypes
import os
import sys
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from uuid import uuid4

IMAGE_EXTENSIONS = {"jpg", "jpeg", "png", "webp", "gif"}
VIDEO_EXTENSIONS = {"mp4", "webm", "mov"}
AUDIO_EXTENSIONS = {"mp3", "wav", "ogg", "m4a"}


def normalize_base_url(raw: str | None) -> str:
    value = (raw or os.environ.get("AI_HARNESS_BASE_URL", "")).strip()
    if not value:
        raise SystemExit(
            "缺少 Base URL。请通过参数 --base-url 或环境变量 AI_HARNESS_BASE_URL 提供。\n"
            "Base URL 需要在申请开放接口后获取。"
        )
    return value.rstrip("/") + "/"


def build_json_headers(api_key: str) -> dict[str, str]:
    return {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }


def build_auth_headers(api_key: str) -> dict[str, str]:
    return {
        "Authorization": f"Bearer {api_key}",
    }


def request_json(method: str, url: str, api_key: str, payload: dict | None = None) -> tuple[int, object]:
    data = None
    if payload is not None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(url=url, data=data, method=method, headers=build_json_headers(api_key))
    try:
        with urllib.request.urlopen(req) as resp:
            charset = resp.headers.get_content_charset() or "utf-8"
            body = resp.read().decode(charset)
            return resp.status, json.loads(body) if body else {}
    except urllib.error.HTTPError as exc:
        charset = exc.headers.get_content_charset() or "utf-8"
        body = exc.read().decode(charset)
        try:
            parsed = json.loads(body) if body else {}
        except json.JSONDecodeError:
            parsed = {"error": body}
        return exc.code, parsed


def request_multipart(url: str, api_key: str, file_path: Path) -> tuple[int, object]:
    boundary = f"----AIHarnessBoundary{uuid4().hex}"
    content_type = guess_content_type(file_path)
    filename = file_path.name
    payload = file_path.read_bytes()

    body = []
    body.append(f"--{boundary}\r\n".encode("utf-8"))
    body.append(
        (
            f'Content-Disposition: form-data; name="file"; filename="{filename}"\r\n'
            f"Content-Type: {content_type}\r\n\r\n"
        ).encode("utf-8")
    )
    body.append(payload)
    body.append(f"\r\n--{boundary}--\r\n".encode("utf-8"))

    req = urllib.request.Request(
        url=url,
        data=b"".join(body),
        method="POST",
        headers={
            **build_auth_headers(api_key),
            "Content-Type": f"multipart/form-data; boundary={boundary}",
        },
    )

    try:
        with urllib.request.urlopen(req) as resp:
            charset = resp.headers.get_content_charset() or "utf-8"
            body_text = resp.read().decode(charset)
            return resp.status, json.loads(body_text) if body_text else {}
    except urllib.error.HTTPError as exc:
        charset = exc.headers.get_content_charset() or "utf-8"
        body_text = exc.read().decode(charset)
        try:
            parsed = json.loads(body_text) if body_text else {}
        except json.JSONDecodeError:
            parsed = {"error": body_text}
        return exc.code, parsed


def resolve_api_key(cli_value: str | None) -> str:
    api_key = (cli_value or os.environ.get("AI_HARNESS_API_KEY", "")).strip()
    if not api_key:
        raise SystemExit(
            "缺少 API Key。请通过参数 --api-key 或环境变量 AI_HARNESS_API_KEY 提供。\n"
            "申请方式：Transsion内：@梁辰；邮件申请：chen.liang@transsion.com"
        )
    return api_key


def load_content(args: argparse.Namespace) -> str:
    if args.content_file:
        return Path(args.content_file).read_text(encoding="utf-8")
    return args.content


def parse_asset(text: str) -> tuple[str, Path]:
    if "=" not in text:
        raise SystemExit("asset 参数格式必须为 名称=文件路径，例如 image1=demo.png")
    name, raw_path = text.split("=", 1)
    asset_name = name.strip()
    path = Path(raw_path.strip())
    if not asset_name:
        raise SystemExit("asset 名称不能为空")
    if not path.exists() or not path.is_file():
        raise SystemExit(f"附件文件不存在：{path}")
    return asset_name, path


def guess_content_type(path: Path) -> str:
    guessed, _ = mimetypes.guess_type(path.name)
    return guessed or "application/octet-stream"


def detect_media_type(path: Path) -> str:
    ext = path.suffix.lower().lstrip(".")
    if ext in IMAGE_EXTENSIONS:
        return "image"
    if ext in VIDEO_EXTENSIONS:
        return "video"
    if ext in AUDIO_EXTENSIONS:
        return "audio"
    raise SystemExit(f"不支持的附件类型：{path.name}")


def build_asset_snippet(asset_name: str, path: Path, url: str) -> str:
    media_type = detect_media_type(path)
    escaped_name = asset_name.replace('"', "")
    content_type = guess_content_type(path)
    if media_type == "image":
        return f"![{escaped_name}]({url})"
    if media_type == "video":
        return (
            '<video width="600" controls>\n'
            f'  <source src="{url}" type="{content_type}">\n'
            "</video>"
        )
    return (
        "<audio controls>\n"
        f'  <source src="{url}" type="{content_type}">\n'
        "</audio>"
    )


def inject_assets(content: str, assets: list[tuple[str, str]]) -> str:
    updated = content
    appended: list[str] = []
    for asset_name, snippet in assets:
        placeholder = f"{{{{asset:{asset_name}}}}}"
        if placeholder in updated:
          updated = updated.replace(placeholder, snippet)
        else:
          appended.append(snippet)
    if appended:
        if updated and not updated.endswith("\n"):
            updated += "\n"
        updated += "\n" + "\n\n".join(appended)
    return updated


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="调用 AI Harness 开放接口")
    parser.add_argument("--base-url", default=None)
    parser.add_argument("--api-key", default=None)

    subparsers = parser.add_subparsers(dest="command", required=True)

    subparsers.add_parser("categories", help="查询分类")

    tags_parser = subparsers.add_parser("tags", help="查询标签")
    tags_parser.add_argument("--keyword", default="", help="标签关键字")

    upload_parser = subparsers.add_parser("upload", help="上传图片、视频或音频")
    upload_parser.add_argument("--file", required=True, help="文件路径")

    post_parser = subparsers.add_parser("post", help="发帖")
    post_parser.add_argument("--category-id", type=int, required=True, help="分类 ID")
    post_parser.add_argument("--title", required=True, help="标题")
    content_group = post_parser.add_mutually_exclusive_group(required=True)
    content_group.add_argument("--content", help="正文内容")
    content_group.add_argument("--content-file", help="正文文件路径")
    post_parser.add_argument("--tag-id", type=int, action="append", required=True, help="标签 ID，可传 1-2 次")

    asset_post_parser = subparsers.add_parser("post-with-assets", help="上传附件后发帖")
    asset_post_parser.add_argument("--category-id", type=int, required=True, help="分类 ID")
    asset_post_parser.add_argument("--title", required=True, help="标题")
    asset_content_group = asset_post_parser.add_mutually_exclusive_group(required=True)
    asset_content_group.add_argument("--content", help="正文内容")
    asset_content_group.add_argument("--content-file", help="正文文件路径")
    asset_post_parser.add_argument("--tag-id", type=int, action="append", required=True, help="标签 ID，可传 1-2 次")
    asset_post_parser.add_argument(
        "--asset",
        action="append",
        default=[],
        help="附件定义，格式为 名称=文件路径，例如 image1=demo.png",
    )

    return parser.parse_args()


def run_categories(base_url: str, api_key: str) -> int:
    status, data = request_json("GET", urllib.parse.urljoin(base_url, "api/external/categories"), api_key)
    print(json.dumps(data, ensure_ascii=False, indent=2))
    return 0 if status < 400 else 1


def run_tags(base_url: str, api_key: str, keyword: str) -> int:
    url = urllib.parse.urljoin(base_url, "api/external/tags")
    if keyword:
        url = f"{url}?{urllib.parse.urlencode({'keyword': keyword})}"
    status, data = request_json("GET", url, api_key)
    print(json.dumps(data, ensure_ascii=False, indent=2))
    return 0 if status < 400 else 1


def run_upload(base_url: str, api_key: str, file_value: str) -> int:
    file_path = Path(file_value)
    if not file_path.exists() or not file_path.is_file():
        raise SystemExit(f"文件不存在：{file_path}")
    status, data = request_multipart(urllib.parse.urljoin(base_url, "api/external/uploads"), api_key, file_path)
    print(json.dumps(data, ensure_ascii=False, indent=2))
    return 0 if status < 400 else 1


def run_post(base_url: str, api_key: str, args: argparse.Namespace, content: str | None = None) -> int:
    tag_ids = args.tag_id or []
    if len(tag_ids) < 1 or len(tag_ids) > 2:
        raise SystemExit("tag-id 必须传 1 到 2 个。")
    payload = {
        "categoryId": args.category_id,
        "title": args.title,
        "content": content if content is not None else load_content(args),
        "tagIds": tag_ids,
    }
    status, data = request_json("POST", urllib.parse.urljoin(base_url, "api/external/posts"), api_key, payload)
    print(json.dumps(data, ensure_ascii=False, indent=2))
    return 0 if status < 400 else 1


def run_post_with_assets(base_url: str, api_key: str, args: argparse.Namespace) -> int:
    content = load_content(args)
    uploaded_assets: list[tuple[str, str]] = []
    for asset_definition in args.asset:
        asset_name, path = parse_asset(asset_definition)
        status, data = request_multipart(
            urllib.parse.urljoin(base_url, "api/external/uploads"),
            api_key,
            path,
        )
        if status >= 400:
            print(json.dumps(data, ensure_ascii=False, indent=2))
            return 1
        if not isinstance(data, dict) or "url" not in data:
            print(json.dumps({"error": "上传接口返回异常", "response": data}, ensure_ascii=False, indent=2))
            return 1
        uploaded_assets.append((asset_name, build_asset_snippet(asset_name, path, str(data["url"]))))

    return run_post(base_url, api_key, args, inject_assets(content, uploaded_assets))


def main() -> int:
    args = parse_args()
    base_url = normalize_base_url(args.base_url)
    api_key = resolve_api_key(args.api_key)

    if args.command == "categories":
        return run_categories(base_url, api_key)
    if args.command == "tags":
        return run_tags(base_url, api_key, args.keyword)
    if args.command == "upload":
        return run_upload(base_url, api_key, args.file)
    if args.command == "post":
        return run_post(base_url, api_key, args)
    if args.command == "post-with-assets":
        return run_post_with_assets(base_url, api_key, args)
    raise SystemExit(f"未知命令: {args.command}")


if __name__ == "__main__":
    sys.exit(main())
