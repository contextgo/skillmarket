package com.allinpay.cus.sdk.sft.example;

import com.allinpay.cus.sdk.sft.SftClient;
import com.allinpay.cus.sdk.sft.SftConfig;
import com.allinpay.cus.sdk.sft.request.TrxQueryRequest;
import com.allinpay.cus.sdk.sft.response.TrxQueryResponse;
import com.allinpay.cus.sdk.sft.response.TrxQueryResponse.QueryDetail;

/**
 * 交易结果查询示例（交易码：200004）
 *
 * ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 * 【适用场景】
 * - 协议支付(310011)返回处理中状态，需确认最终结果
 * - 退款(REFUND)返回处理中状态，需确认最终结果
 * - HTTPS超时后必须发起查询确认交易状态
 * - 定期核对交易状态，确保数据一致性
 *
 * 【前置条件】
 * - 已发起支付或退款请求，保存了REQ_SN流水号
 * - 支付请求：建议处理中状态时轮询查询
 * - 退款请求：建议处理中状态时轮询查询
 *
 * 【业务流程位置】
 * - 支付流程 → 310011(支付) → 200004(查询确认)
 * - 退款流程 → REFUND(退款) → 200004(查询确认)
 *
 * 【关键输出】
 * - DETAIL.RET_CODE：交易最终状态码（0000/4000成功）
 * - DETAIL.AMOUNT：交易金额
 * - DETAIL.SETT_DAY：清算日期
 * - DETAIL.VOUCHER_NO：银行流水号
 *
 * 【注意事项】
 * - 返回码1002表示"无此交易"，10分钟后查询，30分钟无记录判失败
 * - 返回码2000/2007/2008仍为处理中，需继续查询
 * - 使用isNoTransaction()判断1002状态
 * - 使用isTrxSuccess()判断交易成功（0000或4000）
 * ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 *
 * @author DONHU
 */
public class TrxQueryExample {

    public static void main(String[] args) {
        // 1. 创建配置（推荐使用Builder模式）
        SftConfig config = SftConfig.builder()
                .merchantId("您的商户号")
                .userName("您的用户名")
                .gatewayUrl("https://tlt.allinpay.com/aipg/ProcessServlet")
                .privateKeyPath("/path/to/private.p12")
                .privateKeyPassword("您的私钥密码")
                .allinpayPublicKeyPath("/path/to/allinpay-public.cer")
                .signType("SM2")
                .encoding("GBK")
                .build();

        // 2. 创建客户端
        SftClient client = new SftClient(config);

        // 3. 构建请求
        TrxQueryRequest request = new TrxQueryRequest();
        request.setMerchantId("您的商户号");
        request.setQuerySn("原交易的REQ_SN");  // 要查询的交易流水号

        // 4. 发送请求
        try {
            TrxQueryResponse response = client.trxQuery(request);

            // 5. 处理响应
            System.out.println("返回码：" + response.getRetCode());
            System.out.println("返回信息：" + response.getRetMsg());

            // 【推荐方式】使用SDK提供的状态判断方法
            if (response.isTrxSuccess()) {
                System.out.println("查询成功，交易已成功！");
                // 获取交易明细
                if (response.getDetails() != null && !response.getDetails().isEmpty()) {
                    QueryDetail detail = response.getDetails().get(0);
                    System.out.println("交易状态：" + detail.getRetCode());
                    System.out.println("交易金额：" + detail.getAmount() + " 分");
                    System.out.println("清算日期：" + detail.getSettDay());
                    System.out.println("银行流水：" + detail.getVoucherNo());
                }
            } else if (response.isNoTransaction()) {
                // 1002 - 无此交易（特殊处理）
                System.out.println("无此交易记录（1002状态）");
                System.out.println("交易发起后10分钟内可能返回此状态");
                System.out.println("建议：10分钟后查询，30分钟仍无记录判失败");
            } else if (response.isTrxProcessing()) {
                System.out.println("交易仍在处理中，建议继续轮询查询");
            } else if (response.isTrxFailed()) {
                System.out.println("交易失败：" + response.getRetMsg());
                if (response.getDetails() != null && !response.getDetails().isEmpty()) {
                    QueryDetail detail = response.getDetails().get(0);
                    System.out.println("失败原因：" + detail.getErrMsg());
                }
            } else {
                System.out.println("查询失败：" + response.getRetMsg());
            }

        } catch (Exception e) {
            System.err.println("请求异常：" + e.getMessage());
            e.printStackTrace();
        }
    }
}