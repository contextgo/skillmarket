package com.allinpay.cus.sdk.sft.example;

import com.allinpay.cus.sdk.sft.SftClient;
import com.allinpay.cus.sdk.sft.SftConfig;
import com.allinpay.cus.sdk.sft.request.RefundRequest;
import com.allinpay.cus.sdk.sft.response.RefundResponse;
import com.allinpay.cus.sdk.sft.exception.HttpTimeoutException;
import com.allinpay.cus.sdk.sft.exception.SftException;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 退款示例（交易码：REFUND）
 *
 * ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 * 【适用场景】
 * - 用户申请退款，需要将已支付款项退还到用户银行卡
 * - 商户主动发起退款（如订单取消、服务退款）
 * - 支持全额退款和部分退款
 *
 * 【前置条件】
 * - 原支付交易已成功（状态为0000或4000）
 * - 已通过200004查询确认原交易状态
 * - 保存了原支付的REQ_SN流水号
 * - 商户已开通退款业务代码（如09200）
 *
 * 【业务流程位置】
 * 退款流程 → REFUND(退款) → 200004(查询确认)
 *
 * 【关键输出】
 * - REQ_SN：退款流水号，查询退款状态使用
 * - SETTLE_DAY：清算日期
 *
 * 【注意事项】
 * - 业务代码(09200)与协议支付(09100)独立，不能混用
 * - 退款金额不能超过原支付金额
 * - 原交易已全额退款后不能再次退款
 * - HTTPS超时必须发起查询，不能直接判定失败
 * - 退款返回码3999表示"其它错误"，需查看ERR_MSG详情
 * - orgBatchId填原支付的REQ_SN，orgBatchSn单笔交易填0
 * ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 *
 * @author DONHU
 */
public class RefundExample {

    public static void main(String[] args) {
        // 1. 创建配置（推荐使用Builder模式）
        SftConfig config = SftConfig.builder()
                .merchantId("您的商户号")
                .userName("您的用户名")
                .gatewayUrl("https://tlt.allinpay.com/aipg/ProcessServlet")
                .privateKeyPath("/path/to/private.p12")
                .privateKeyPassword("您的私钥密码")
                .allinpayPublicKeyPath("/path/to/allinpay-public.cer")
                .signType("SM2")
                .encoding("GBK")
                .build();

        // 2. 创建客户端
        SftClient client = new SftClient(config);

        // 3. 构建退款请求
        RefundRequest request = new RefundRequest();
        request.setMerchantId("您的商户号");

        // 必填参数
        request.setBusinessCode("09200");              // 业务代码（通联分配，退款专用）
        request.setOrgBatchId("原交易的REQ_SN");        // 原支付交易流水号（必须是成功的交易）
        request.setOrgBatchSn("0");                    // 单笔交易填0
        request.setAmount("10000");                    // 退款金额，单位分（100元）

        // 可选参数
        request.setSubmitTime(new SimpleDateFormat("yyyyMMddHHmmss").format(new Date())); // 提交时间
        request.setRemark("用户申请退款");
        request.setNotifyUrl("https://your-server/refund-notify");  // 退款结果通知地址

        // 4. 发送请求
        try {
            RefundResponse response = client.refund(request);

            // 5. 处理响应
            String reqSn = response.getReqSn();
            System.out.println("返回码：" + response.getRetCode());
            System.out.println("返回信息：" + response.getRetMsg());
            System.out.println("退款流水号：" + reqSn);

            // 【推荐方式】使用SDK状态判断方法
            if (response.isTrxSuccess()) {
                System.out.println("退款请求成功！");
                System.out.println("清算日期：" + response.getSettleDay());
                System.out.println("建议：调用200004查询接口确认最终退款状态");
            } else if (response.isTrxProcessing()) {
                System.out.println("退款处理中，必须发起交易查询(200004)");
                System.out.println("查询流水号：" + reqSn);
            } else if (response.isTrxFailed()) {
                String errMsg = response.getDetailErrMsg();
                if (errMsg != null && !errMsg.isEmpty()) {
                    System.out.println("退款失败：" + errMsg);
                } else {
                    System.out.println("退款失败：" + response.getRetMsg());
                }
                System.out.println("建议：检查原交易是否成功、退款金额是否超限");
            } else {
                System.out.println("其他状态：" + response.getRetMsg());
            }

        } catch (HttpTimeoutException e) {
            System.err.println("HTTP超时，必须发起交易查询(200004)确认状态！");
            System.err.println("超时类型: " + (e.isConnectTimeout() ? "连接超时" : "读取超时"));
            if (e.getReqSn() != null) {
                System.err.println("建议查询流水号: " + e.getReqSn());
            }
        } catch (SftException e) {
            System.err.println("SDK异常: " + e.getErrorMessage());
        } catch (Exception e) {
            System.err.println("请求异常，必须发起交易查询(200004)确认状态！");
            e.printStackTrace();
        }
    }
}