package com.allinpay.cus.sdk.sft.example;

import com.allinpay.cus.sdk.sft.SftClient;
import com.allinpay.cus.sdk.sft.SftConfig;
import com.allinpay.cus.sdk.sft.request.AgreementSignSmsRequest;
import com.allinpay.cus.sdk.sft.response.AgreementSignSmsResponse;

/**
 * 协议支付签约短信触发示例（交易码：310001）
 *
 * ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 * 【适用场景】
 * - 用户首次使用协议支付功能，需要完成银行卡签约
 * - 发送短信验证码到用户预留手机号，验证用户身份
 * - 签约成功后可获得协议号，用于后续代扣支付
 *
 * 【前置条件】
 * - 用户已提供银行卡号、持卡人姓名、身份证号、手机号等信息
 * - 商户已开通协议支付业务权限
 * - SDK已正确配置商户私钥和通联公钥
 *
 * 【业务流程位置】
 * 签约流程第一步 → 310001(短信) → 310002(确认) → 获取协议号
 *
 * 【关键输出】
 * - REQ_SN：请求流水号，签约确认时必须传入此流水号
 * - 短信验证码发送到用户手机（有效期5分钟）
 *
 * 【注意事项】
 * - 测试环境验证码固定为"111111"
 * - 生产环境验证码由用户手机接收
 * - REQ_SN必须保存，用于后续310002签约确认
 * ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 *
 * @author DONHU
 */
public class AgreementSignSmsExample {

    public static void main(String[] args) {
        // 1. 创建配置（推荐使用Builder模式）
        SftConfig config = SftConfig.builder()
                .merchantId("您的商户号")
                .userName("您的用户名")
                .gatewayUrl("https://tlt.allinpay.com/aipg/ProcessServlet")
                .privateKeyPath("/path/to/private.p12")
                .privateKeyPassword("您的私钥密码")
                .allinpayPublicKeyPath("/path/to/allinpay-public.cer")
                .signType("SM2")  // 或 RSA
                .encoding("GBK")  // 或 UTF-8
                .build();

        // 2. 创建客户端
        SftClient client = new SftClient(config);

        // 3. 构建请求
        AgreementSignSmsRequest request = new AgreementSignSmsRequest();
        request.setMerchantId("您的商户号");

        // 必填参数
        request.setAccountNo("6225881234567890");     // 银行卡号
        request.setAccountName("张三");               // 持卡人姓名
        request.setAccountProp("0");                  // 0-私人 1-公司
        request.setIdType("0");                       // 0-身份证
        request.setId("110101199001011234");          // 身份证号
        request.setTel("13800138000");                // 手机号（接收验证码）

        // 可选参数
        request.setAccountType("00");                 // 00-银行卡 02-信用卡
        request.setBankCode("0308");                  // 银行代码
        request.setRemark("签约测试");

        // 4. 发送请求
        try {
            AgreementSignSmsResponse response = client.agreementSignSms(request);

            // 5. 处理响应（推荐使用SDK状态判断方法）
            System.out.println("返回码：" + response.getRetCode());
            System.out.println("返回信息：" + response.getRetMsg());

            if (response.isTrxSuccess()) {
                // 成功：保存REQ_SN，签约确认时需要用到
                String srcReqSn = response.getReqSn();
                System.out.println("短信发送成功，流水号：" + srcReqSn);
                System.out.println("请用户输入收到的验证码");
                System.out.println("下一步：调用310002签约确认接口");
            } else if (response.isTrxFailed()) {
                System.out.println("短信发送失败：" + response.getRetMsg());
                System.out.println("建议：检查用户信息是否正确");
            } else {
                System.out.println("其他状态：" + response.getRetMsg());
            }

        } catch (Exception e) {
            System.err.println("请求异常：" + e.getMessage());
            e.printStackTrace();
        }
    }
}