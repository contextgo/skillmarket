package com.allinpay.cus.sdk.sft.example;

import com.allinpay.cus.sdk.sft.SftClient;
import com.allinpay.cus.sdk.sft.SftConfig;
import com.allinpay.cus.sdk.sft.request.AgreementSignRequest;
import com.allinpay.cus.sdk.sft.response.AgreementSignResponse;

/**
 * 协议支付签约确认示例（交易码：310002）
 *
 * ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 * 【适用场景】
 * - 用户已收到签约短信验证码，需要验证并完成签约
 * - 验证通过后生成协议号，建立银行卡与商户的支付协议
 * - 协议号是后续代扣支付的唯一凭证
 *
 * 【前置条件】
 * - 已成功调用310001签约短信接口
 * - 用户已收到短信验证码（有效期5分钟）
 * - 保存了310001返回的REQ_SN流水号
 *
 * 【业务流程位置】
 * 签约流程第二步 → 310001(短信) → 310002(确认) → 获取协议号
 *
 * 【关键输出】
 * - AGRMNO：协议号，签约成功后返回的唯一标识
 * - 协议号必须持久化保存到数据库，用于后续支付
 *
 * 【注意事项】
 * - 测试环境验证码固定为"111111"
 * - 验证码错误返回码为3998，需重新发送短信
 * - 协议号永久有效，除非用户主动解约
 * - 一个银行卡可签约多个协议（不同商户）
 * ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 *
 * @author DONHU
 */
public class AgreementSignExample {

    public static void main(String[] args) {
        // 1. 创建配置（推荐使用Builder模式）
        SftConfig config = SftConfig.builder()
                .merchantId("您的商户号")
                .userName("您的用户名")
                .gatewayUrl("https://tlt.allinpay.com/aipg/ProcessServlet")
                .privateKeyPath("/path/to/private.p12")
                .privateKeyPassword("您的私钥密码")
                .allinpayPublicKeyPath("/path/to/allinpay-public.cer")
                .signType("SM2")
                .encoding("GBK")
                .build();

        // 2. 创建客户端
        SftClient client = new SftClient(config);

        // 3. 构建请求
        AgreementSignRequest request = new AgreementSignRequest();
        request.setMerchantId("您的商户号");

        // 必填参数
        request.setSrcReqSn("310001返回的REQ_SN");  // 来自签约短信接口的流水号
        request.setVerCode("111111");               // 用户输入的验证码

        // 4. 发送请求
        try {
            AgreementSignResponse response = client.agreementSign(request);

            // 5. 处理响应
            System.out.println("返回码：" + response.getRetCode());
            System.out.println("返回信息：" + response.getRetMsg());

            // 【推荐方式】使用SDK状态判断方法
            if (response.isTrxSuccess()) {
                // 成功：保存协议号
                String agrmNo = response.getAgrmNo();
                System.out.println("签约成功！");
                System.out.println("协议号：" + agrmNo);
                System.out.println("★★★ 重要：将协议号保存到数据库，后续支付使用 ★★★");
                System.out.println("下一步：可调用310011协议支付接口发起代扣");
            } else if (response.isTrxFailed()) {
                String detailRetCode = response.getDetailRetCode();
                if ("3998".equals(detailRetCode)) {
                    System.out.println("验证码错误或已过期，请重新发送短信(310001)");
                } else {
                    System.out.println("签约失败：" + response.getRetMsg());
                }
            } else {
                System.out.println("其他状态：" + response.getRetMsg());
            }

        } catch (Exception e) {
            System.err.println("请求异常：" + e.getMessage());
            e.printStackTrace();
        }
    }
}