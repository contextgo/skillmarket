package com.allinpay.cus.sdk.sft.example;

import com.allinpay.cus.sdk.sft.SftClient;
import com.allinpay.cus.sdk.sft.SftConfig;
import com.allinpay.cus.sdk.sft.request.AgreementPayRequest;
import com.allinpay.cus.sdk.sft.response.AgreementPayResponse;
import com.allinpay.cus.sdk.sft.exception.HttpTimeoutException;
import com.allinpay.cus.sdk.sft.exception.SftException;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 协议支付示例（交易码：310011）
 *
 * ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 * 【适用场景】
 * - 用户已完成签约，持有有效协议号
 * - 需要从用户签约银行卡代扣款项（如定期扣款、订单支付）
 * - 代扣成功后资金从用户银行卡转入商户账户
 *
 * 【前置条件】
 * - 已通过310001/310002完成签约，获取协议号(AGRMNO)
 * - 协议号已保存到数据库并可查询
 * - 商户已开通协议支付业务代码（如09100）
 *
 * 【业务流程位置】
 * 支付流程 → 310011(支付) → 200004(查询确认)
 *
 * 【关键输出】
 * - REQ_SN：交易流水号，查询和退款必须使用
 * - SETTLE_DAY：清算日期
 * - VOUCHER_NO：银行流水号
 *
 * 【注意事项】
 * - 业务代码(09100)与退款业务代码(09200)独立，不能混用
 * - submitTime填写当前请求时间（防重校验）
 * - 金额单位为分，100元=10000分
 * - HTTPS超时必须发起查询，不能直接判定失败
 * - 返回码2000/2007/2008为处理中，需调用200004查询
 * ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 *
 * @author DONHU
 */
public class AgreementPayExample {

    public static void main(String[] args) {
        // 1. 创建配置（推荐使用Builder模式）
        SftConfig config = SftConfig.builder()
                .merchantId("您的商户号")
                .userName("您的用户名")
                .gatewayUrl("https://tlt.allinpay.com/aipg/ProcessServlet")
                .privateKeyPath("/path/to/private.p12")
                .privateKeyPassword("您的私钥密码")
                .allinpayPublicKeyPath("/path/to/allinpay-public.cer")
                .signType("SM2")
                .encoding("GBK")
                .build();

        // 2. 创建客户端
        SftClient client = new SftClient(config);

        // 3. 构建请求
        AgreementPayRequest request = new AgreementPayRequest();
        request.setMerchantId("您的商户号");

        // 必填参数
        request.setAgrmNo("签约时返回的协议号");      // 来自310002签约确认
        request.setAmount("10000");                  // 金额，单位分（100元）
        request.setBusinessCode("09100");            // 业务代码（通联分配，协议支付专用）
        request.setSubmitTime(new SimpleDateFormat("yyyyMMddHHmmss").format(new Date())); // 提交时间（当前请求时间）
        request.setAccountName("张三");               // 持卡人姓名

        // 可选参数
        request.setRemark("订单备注");
        request.setSummary("订单摘要");
        request.setNotifyUrl("https://your-server/notify");  // 异步通知地址

        // 4. 发送请求
        try {
            AgreementPayResponse response = client.agreementPay(request);
            String reqSn = response.getReqSn();  // 保存流水号

            // 5. 处理响应
            System.out.println("返回码：" + response.getRetCode());
            System.out.println("返回信息：" + response.getRetMsg());
            System.out.println("请求流水号：" + reqSn);

            // 【推荐方式】使用SDK提供的状态判断方法
            if (response.isTrxSuccess()) {
                System.out.println("支付成功！");
                System.out.println("清算日期：" + response.getSettleDay());
                System.out.println("卡号后4位：" + response.getAcctSuffix());
                System.out.println("银行流水号：" + response.getVoucherNo());
            } else if (response.isTrxFailed()) {
                System.out.println("支付失败：" + response.getErrMsg());
                System.out.println("建议：检查协议号是否有效、业务代码是否正确");
            } else if (response.isTrxProcessing()) {
                System.out.println("处理中，必须调用200004查询确认最终状态");
                System.out.println("查询流水号：" + reqSn);
            } else {
                // 兜底处理：无法确定状态时发起查询
                String errMsg = response.getErrMsg();
                if (errMsg != null && !errMsg.isEmpty()) {
                    System.out.println("支付失败：" + errMsg);
                } else {
                    System.out.println("无法确定状态，必须调用200004查询确认");
                }
            }

        } catch (HttpTimeoutException e) {
            // HTTP超时 - 必须发起查询
            System.err.println("HTTP超时，必须发起交易查询(200004)确认状态！");
            System.err.println("超时类型: " + (e.isConnectTimeout() ? "连接超时" : "读取超时"));
            if (e.getReqSn() != null) {
                System.err.println("建议查询流水号: " + e.getReqSn());
            }
        } catch (SftException e) {
            System.err.println("SDK异常: " + e.getErrorMessage());
        } catch (Exception e) {
            System.err.println("请求异常，必须发起交易查询(200004)确认状态！");
            e.printStackTrace();
        }
    }
}