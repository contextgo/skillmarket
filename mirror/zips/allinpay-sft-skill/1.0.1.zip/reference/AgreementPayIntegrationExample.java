package com.allinpay.cus.sdk.sft.example;

import com.allinpay.cus.sdk.sft.SftClient;
import com.allinpay.cus.sdk.sft.SftConfig;
import com.allinpay.cus.sdk.sft.request.AgreementPayRequest;
import com.allinpay.cus.sdk.sft.request.AgreementSignRequest;
import com.allinpay.cus.sdk.sft.request.AgreementSignSmsRequest;
import com.allinpay.cus.sdk.sft.request.RefundRequest;
import com.allinpay.cus.sdk.sft.request.TrxQueryRequest;
import com.allinpay.cus.sdk.sft.response.*;
import com.allinpay.cus.sdk.sft.response.TrxQueryResponse.QueryDetail;
import com.allinpay.cus.sdk.sft.exception.HttpTimeoutException;
import com.allinpay.cus.sdk.sft.exception.SftException;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 协议支付完整集成流程示例
 *
 * ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 * 【适用场景】
 * - 快速验证协议支付完整流程（签约→支付→查询→退款）
 * - 作为集成参考，理解各接口调用顺序和数据流转
 * - 测试环境验证（使用固定验证码111111）
 *
 * 【完整流程】
 * 步骤1: 310001 签约短信触发 → 发送验证码，获取REQ_SN
 * 步骤2: 310002 签约确认     → 验证验证码，获取协议号(AGRMNO)
 * 步骤3: 310011 协议支付     → 使用协议号代扣，获取支付REQ_SN
 * 步骤4: 200004 交易查询     → 查询支付结果，确认交易状态
 * 步骤5: REFUND  交易退款    → 发起退款，获取退款REQ_SN
 * 步骤6: 200004 退款查询     → 查询退款结果，确认退款状态
 *
 * 【数据流转】
 * 310001.REQ_SN → 310002.SRC_REQ_SN
 * 310002.AGRMNO → 310011.AGRM_NO
 * 310011.REQ_SN → 200004.QUERY_SN (支付查询)
 * 310011.REQ_SN → REFUND.ORG_BATCH_ID (退款)
 * REFUND.REQ_SN → 200004.QUERY_SN (退款查询)
 *
 * 【关键保存字段】
 * - REQ_SN：所有请求的流水号（查询、退款必需）
 * - AGRMNO：协议号（后续支付必需，永久有效）
 *
 * 【注意事项】
 * - 测试环境验证码固定为"111111"
 * - HTTPS超时必须发起查询，不能判定失败
 * - 业务代码不能混用：支付用09100，退款用09200
 * - 金额单位为分，100元=10000分
 * ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 *
 * @author DONHU
 */
public class AgreementPayIntegrationExample {

    public static void main(String[] args) throws Exception {
        // 初始化配置（推荐使用Builder模式）
        SftConfig config = SftConfig.builder()
                .merchantId("您的商户号")
                .userName("您的用户名")
                .gatewayUrl("https://tlt.allinpay.com/aipg/ProcessServlet")
                .privateKeyPath("/path/to/private.p12")
                .privateKeyPassword("您的私钥密码")
                .allinpayPublicKeyPath("/path/to/allinpay-public.cer")
                .signType("SM2")
                .encoding("GBK")
                .build();

        SftClient client = new SftClient(config);

        System.out.println("========================================");
        System.out.println("    通联收付通协议支付集成演示");
        System.out.println("========================================");

        // ====== 步骤1：协议签约短信触发（310001）======
        System.out.println("\n【步骤1】发送签约短信（310001）");
        System.out.println("----------------------------------------");

        AgreementSignSmsRequest smsRequest = new AgreementSignSmsRequest();
        smsRequest.setAccountNo("6225881234567890");
        smsRequest.setAccountName("张三");
        smsRequest.setAccountProp("0");
        smsRequest.setIdType("0");
        smsRequest.setId("110101199001011234");
        smsRequest.setTel("13800138000");
        smsRequest.setBankCode("0308");

        AgreementSignSmsResponse smsResponse = client.agreementSignSms(smsRequest);

        String srcReqSn = null;
        if (smsResponse.isTrxSuccess()) {
            srcReqSn = smsResponse.getReqSn();
            System.out.println("短信发送成功，流水号: " + srcReqSn);
            System.out.println("★★★ 保存REQ_SN，步骤2签约确认需要使用 ★★★");
        } else {
            System.out.println("短信发送失败: " + smsResponse.getRetMsg());
            return;
        }

        // ====== 步骤2：协议签约确认（310002）======
        System.out.println("\n【步骤2】签约确认（310002）");
        System.out.println("----------------------------------------");

        // 模拟用户输入验证码（测试环境固定为111111）
        String verCode = "111111";

        AgreementSignRequest signRequest = new AgreementSignRequest();
        signRequest.setSrcReqSn(srcReqSn);  // 使用步骤1的流水号
        signRequest.setVerCode(verCode);

        AgreementSignResponse signResponse = client.agreementSign(signRequest);

        String agrmNo = null;
        if (signResponse.isTrxSuccess()) {
            agrmNo = signResponse.getAgrmNo();
            System.out.println("签约成功，协议号: " + agrmNo);
            System.out.println("★★★ 保存协议号到数据库，后续支付使用 ★★★");
        } else if (signResponse.isTrxFailed()) {
            String detailRetCode = signResponse.getDetailRetCode();
            if ("3998".equals(detailRetCode)) {
                System.out.println("验证码错误，请重新发送短信(310001)");
            } else {
                System.out.println("签约失败: " + signResponse.getRetMsg());
            }
            return;
        } else {
            System.out.println("签约失败: " + signResponse.getRetMsg());
            return;
        }

        // ====== 步骤3：协议支付（310011）======
        System.out.println("\n【步骤3】发起协议支付（310011）");
        System.out.println("----------------------------------------");

        AgreementPayRequest payRequest = new AgreementPayRequest();
        payRequest.setAgrmNo(agrmNo);  // 使用步骤2获取的协议号
        payRequest.setAmount("10000");  // 100元
        payRequest.setBusinessCode("09100");  // 业务代码（协议支付专用）
        payRequest.setSubmitTime(new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()));
        payRequest.setAccountName("张三");
        payRequest.setRemark("测试订单");

        String payReqSn = null;
        boolean paySuccess = false;
        try {
            AgreementPayResponse payResponse = client.agreementPay(payRequest);

            payReqSn = payResponse.getReqSn();
            System.out.println("支付请求流水号: " + payReqSn);

            // 推荐方式：使用SDK提供的状态判断方法
            if (payResponse.isTrxSuccess()) {
                paySuccess = true;
                System.out.println("支付成功！");
                System.out.println("清算日期: " + payResponse.getSettleDay());
            } else if (payResponse.isTrxFailed()) {
                System.out.println("支付失败，银行返回: " + payResponse.getErrMsg());
                return;
            } else if (payResponse.isTrxProcessing()) {
                System.out.println("系统处理中，必须发起交易查询(200004)");
                System.out.println("★★★ 保存支付REQ_SN用于查询和退款 ★★★");
            } else {
                String errMsg = payResponse.getErrMsg();
                if (errMsg != null && !errMsg.isEmpty()) {
                    System.out.println("支付失败: " + errMsg);
                    return;
                }
                System.out.println("无法确定状态，必须发起交易查询(200004)");
            }

        } catch (HttpTimeoutException e) {
            System.err.println("HTTP超时，必须发起交易查询(200004)确认状态！");
            System.err.println("超时类型: " + (e.isConnectTimeout() ? "连接超时" : "读取超时"));
            if (e.getReqSn() != null) {
                payReqSn = e.getReqSn();
                System.err.println("流水号: " + payReqSn);
            }
        } catch (SftException e) {
            System.err.println("SDK异常: " + e.getErrorMessage());
            return;
        } catch (Exception e) {
            System.err.println("请求异常，必须发起交易查询(200004)确认状态！");
            e.printStackTrace();
            return;
        }

        // ====== 步骤4：交易查询（200004）======
        if (!paySuccess && payReqSn != null) {
            System.out.println("\n【步骤4】查询交易结果（200004）");
            System.out.println("----------------------------------------");

            TrxQueryRequest queryRequest = new TrxQueryRequest();
            queryRequest.setQuerySn(payReqSn);

            TrxQueryResponse queryResponse = client.trxQuery(queryRequest);

            if (queryResponse.isTrxSuccess()) {
                paySuccess = true;
                if (queryResponse.getDetails() != null && !queryResponse.getDetails().isEmpty()) {
                    QueryDetail detail = queryResponse.getDetails().get(0);
                    System.out.println("查询成功，交易已成功");
                    System.out.println("交易状态: " + detail.getRetCode());
                    System.out.println("交易金额: " + detail.getAmount() + " 分");
                    System.out.println("清算日期: " + detail.getSettDay());
                    System.out.println("银行流水: " + detail.getVoucherNo());
                }
            } else if (queryResponse.isNoTransaction()) {
                System.out.println("无此交易记录（交易发起后10分钟内可能返回此状态）");
                return;
            } else if (queryResponse.isTrxProcessing()) {
                System.out.println("交易仍在处理中，建议继续查询");
                return;
            } else if (queryResponse.isTrxFailed()) {
                System.out.println("交易失败");
                if (queryResponse.getDetails() != null && !queryResponse.getDetails().isEmpty()) {
                    QueryDetail detail = queryResponse.getDetails().get(0);
                    System.out.println("失败原因: " + detail.getErrMsg());
                }
                return;
            } else {
                System.out.println("查询失败: " + queryResponse.getRetMsg());
                return;
            }
        }

        if (!paySuccess) {
            System.out.println("支付未成功，流程结束");
            return;
        }

        // ====== 步骤5：发起退款（REFUND）======
        System.out.println("\n【步骤5】发起退款（REFUND）");
        System.out.println("----------------------------------------");

        RefundRequest refundRequest = new RefundRequest();
        refundRequest.setBusinessCode("09200");      // 业务代码（退款专用）
        refundRequest.setOrgBatchId(payReqSn);       // 使用步骤3的支付流水号
        refundRequest.setOrgBatchSn("0");
        refundRequest.setAmount("10000");            // 全额退款
        refundRequest.setSubmitTime(new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()));
        refundRequest.setRemark("测试退款");

        String refundReqSn = null;
        try {
            RefundResponse refundResponse = client.refund(refundRequest);

            refundReqSn = refundResponse.getReqSn();
            System.out.println("退款请求流水号: " + refundReqSn);

            if (refundResponse.isTrxSuccess()) {
                System.out.println("退款请求成功");
                System.out.println("清算日期: " + refundResponse.getSettleDay());
            } else if (refundResponse.isTrxProcessing()) {
                System.out.println("退款处理中，必须发起交易查询(200004)");
            } else if (refundResponse.isTrxFailed()) {
                String errMsg = refundResponse.getDetailErrMsg();
                if (errMsg != null && !errMsg.isEmpty()) {
                    System.out.println("退款请求失败: " + errMsg);
                } else {
                    System.out.println("退款请求失败: " + refundResponse.getRetMsg());
                }
                return;
            } else {
                System.out.println("退款请求失败: " + refundResponse.getRetMsg());
                return;
            }

        } catch (HttpTimeoutException e) {
            System.err.println("HTTP超时，必须发起交易查询(200004)确认状态！");
            System.err.println("超时类型: " + (e.isConnectTimeout() ? "连接超时" : "读取超时"));
            if (e.getReqSn() != null) {
                refundReqSn = e.getReqSn();
                System.err.println("流水号: " + refundReqSn);
            }
        } catch (SftException e) {
            System.err.println("SDK异常: " + e.getErrorMessage());
            return;
        } catch (Exception e) {
            System.err.println("请求异常，必须发起交易查询(200004)确认状态！");
            e.printStackTrace();
            return;
        }

        // ====== 步骤6：查询退款结果（200004）======
        if (refundReqSn != null) {
            System.out.println("\n【步骤6】查询退款结果（200004）");
            System.out.println("----------------------------------------");

            TrxQueryRequest refundQuery = new TrxQueryRequest();
            refundQuery.setQuerySn(refundReqSn);

            TrxQueryResponse refundResult = client.trxQuery(refundQuery);

            if (refundResult.isTrxSuccess()) {
                if (refundResult.getDetails() != null && !refundResult.getDetails().isEmpty()) {
                    QueryDetail refundDetail = refundResult.getDetails().get(0);
                    String refundStatus = refundDetail.getRetCode();

                    System.out.println("退款查询成功");
                    System.out.println("退款状态: " + refundStatus);
                    System.out.println("退款金额: " + refundDetail.getAmount() + " 分");

                    if ("0000".equals(refundStatus) || "4000".equals(refundStatus)) {
                        System.out.println("\n*** 退款成功！***");
                    }
                }
            } else if (refundResult.isNoTransaction()) {
                System.out.println("无此退款记录，建议稍后查询");
            } else if (refundResult.isTrxProcessing()) {
                System.out.println("退款仍在处理中，建议继续查询");
            } else if (refundResult.isTrxFailed()) {
                System.out.println("退款失败");
                if (refundResult.getDetails() != null && !refundResult.getDetails().isEmpty()) {
                    QueryDetail refundDetail = refundResult.getDetails().get(0);
                    System.out.println("失败原因: " + refundDetail.getErrMsg());
                }
            } else {
                System.out.println("退款查询失败: " + refundResult.getRetMsg());
            }
        }

        System.out.println("\n========================================");
        System.out.println("    演示完成");
        System.out.println("========================================");
    }
}