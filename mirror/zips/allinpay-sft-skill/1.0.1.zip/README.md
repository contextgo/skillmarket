# 通联收付通协议支付完整流程技能包

本技能包包含通联收付通协议支付完整流程的AI代码生成技能，覆盖从签约到退款的全部业务环节。

## 技能包概述

| 技能包 | 适用场景 | 技术栈 |
|--------|----------|--------|
| allinpay-sft-agreement-pay | 协议支付完整流程（签约→支付→查询→退款） | Java |

## 流程概览

### 完整流程链路

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        通联协议支付完整流程                                    │
└─────────────────────────────────────────────────────────────────────────────┘

  ┌─────────────┐     ┌─────────────┐     ┌─────────────┐     ┌─────────────┐
  │  310001     │     │  310002     │     │  310011     │     │  200004     │
  │ 签约短信触发 │ ──► │ 签约确认    │ ──► │ 协议支付    │ ──► │ 交易查询    │
  │             │     │ (验证码)    │     │             │     │ (处理中时)  │
  └─────────────┘     └─────────────┘     └─────────────┘     └─────────────┘
       ▼                   ▼                   ▼                   ▼
   发送验证码         返回协议号          返回交易流水          确认交易结果
   保存REQ_SN         保存AGRMNO         保存REQ_SN           0000/4000成功
                                                                ↓
  ┌─────────────┐     ┌─────────────┐                          │
  │  REFUND     │ ──► │  200004     │◄─────────────────────────┘
  │ 交易退款    │     │ 退款查询    │         需要退款时
  │             │     │ (处理中时)  │
  └─────────────┘     └─────────────┘
       ▼                   ▼
   返回退款流水         确认退款结果
   保存REQ_SN           0000/4000成功
```

### 流程步骤说明

| 步骤 | 接口 | 交易码 | 功能 | 关键输出 |
|------|------|--------|------|----------|
| 1 | 签约短信触发 | 310001 | 发送短信验证码到用户手机 | REQ_SN（流水号） |
| 2 | 签约确认 | 310002 | 验证短信验证码，完成签约 | AGRMNO（协议号） |
| 3 | 协议支付 | 310011 | 使用协议号发起代扣支付 | REQ_SN（交易流水） |
| 4 | 交易查询 | 200004 | 查询支付交易结果 | TRX_STATUS |
| 5 | 交易退款 | REFUND | 对已成功的交易发起退款 | REQ_SN（退款流水） |
| 6 | 退款查询 | 200004 | 查询退款交易结果 | TRX_STATUS |

## 安装方式

将技能包目录复制到AI工具的技能目录：

| AI 工具 | 安装路径 |
|---------|----------|
| Claude Code | ~/.claude/skills/ |
| ClawHub | ~/.clawhub/skills/ |
| Cursor | ~/.cursor/skills/ |
| Trae | ~/.trae/skills/ |

```bash
# 示例：将技能包复制到 Claude Code
cp -r allinpay-sft-skills ~/.claude/skills/
```

## 验证安装

安装完成后，在AI对话中输入以下关键词验证技能已被识别：
- `协议支付`
- `收付通`
- `310001`
- `协议签约`

## 前置依赖

使用本技能前需要确认项目已引入收付通SDK依赖：

```xml
<!-- pom.xml -->
<dependency>
    <groupId>com.allinpay.cus.sdk</groupId>
    <artifactId>allinpay-sft-sdk-java</artifactId>
    <version>1.0.1</version>
</dependency>
```

### SDK核心类说明

| 类名 | 说明 |
|------|------|
| SftConfig | SDK配置类，包含商户号、网关地址、密钥路径等 |
| SftClient | SDK客户端类，封装所有接口调用方法 |
| AgreementSignSmsRequest | 协议签约短信请求（310001） |
| AgreementSignRequest | 协议签约确认请求（310002） |
| AgreementPayRequest | 协议支付请求（310011） |
| TrxQueryRequest | 交易查询请求（200004） |
| RefundRequest | 退款请求（REFUND） |

### SDK响应状态判断方法（推荐）

| 方法 | 返回值 | 说明 |
|------|--------|------|
| `isTrxSuccess()` | boolean | 交易是否成功（SDK内部判断） |
| `isTrxFailed()` | boolean | 交易是否失败（SDK内部判断） |
| `isTrxProcessing()` | boolean | 交易是否处理中 |
| `getErrMsg()` | String | 获取交易错误信息（推荐） |
| `getDetailRetCode()` | String | 明细返回码（可能返回null） |

**重要提示**：推荐使用 `isTrxSuccess()`, `isTrxFailed()`, `getErrMsg()` 方法判断交易状态，避免 `getDetailRetCode()` 返回null的问题。

### SDK初始化配置

```java
// 推荐方式：Builder模式
SftConfig config = SftConfig.builder()
        .merchantId("商户号")              // 通联分配的商户号
        .userName("用户名")                // 通联分配的用户名
        .gatewayUrl("网关地址")            // 生产/测试环境网关
        .privateKeyPath("私钥路径")        // 商户私钥文件路径（p12格式）
        .privateKeyPassword("私钥密码")    // p12私钥文件密码
        .allinpayPublicKeyPath("通联公钥路径") // 通联公钥文件路径
        .signType("SM2")                   // 签名类型：SM2/RSA
        .encoding("GBK")                   // 编码：GBK/UTF-8
        .build();

SftClient client = new SftClient(config);    // 创建客户端

// 传统方式：Setter模式
SftConfig config = new SftConfig();
config.setMerchantId("商户号");
config.setUserName("用户名");
config.setGatewayUrl("网关地址");
config.setPrivateKeyPath("私钥路径");
config.setPrivateKeyPassword("私钥密码");
config.setAllinpayPublicKeyPath("通联公钥路径");
config.setSignType("SM2");
config.setEncoding("GBK");

SftClient client = new SftClient(config);
```

### 网关地址

| 环境 | 地址 |
|------|------|
| 生产环境 | https://tlt.allinpay.com/aipg/ProcessServlet |
| 测试环境 | https://tlt-test.allinpay.com/aipg/ProcessServlet |

## 使用示例

### 快速开始

在AI对话中输入以下关键词即可触发技能：

```
我需要对接通联收付通协议支付
```

或指定具体步骤：

```
我需要对接通联收付通协议支付签约短信接口
我需要对接通联收付通协议支付签约确认接口
我需要对接通联收付通协议支付扣款接口
我需要查询通联收付通的交易结果
我需要对通联收付通的订单发起退款
```

AI将自动根据项目实际情况生成适配代码。

## 触发关键词

本技能支持以下触发关键词：

| 关键词类型 | 触发关键词 |
|------------|------------|
| 接口交易码 | 310001、310002、310011、200004、REFUND |
| 接口名称 | AGREEMENT_SIGN_SMS、AGREEMENT_SIGN、AGREEMENT_PAY、TRX_QUERY |
| 业务术语 | 协议支付、协议签约、协议代扣、签约短信、签约确认、交易查询、交易退款 |
| 产品名称 | 收付通、通联支付、通联代扣、通联退款 |

## 目录结构

```
allinpay-sft-skills/
├── README.md                              # 本文件
├── SKILL.md                               # 技能定义文件（完整流程）
└── reference/                             # 参考文档和示例
    ├── RETURN_CODES.md                    # 返回码说明文档
    ├── AgreementSignSmsExample.java       # 签约短信触发示例（310001）
    ├── AgreementSignExample.java          # 签约确认示例（310002）
    ├── AgreementPayExample.java           # 协议支付示例（310011）
    ├── AgreementPayIntegrationExample.java # 完整流程示例（推荐参考）
    ├── TrxQueryExample.java               # 交易查询示例（200004）
    └── RefundExample.java                 # 退款示例（REFUND）
```

每个示例文件包含：适用场景、前置条件、关键输出、注意事项等详细注释。

## 核心参数说明

### 证件类型（ID_TYPE）

| 代码 | 说明 |
|------|------|
| 0 | 身份证 |
| 1 | 户口簿 |
| 2 | 护照 |
| 3 | 军官证 |
| 4 | 士兵证 |
| 5 | 港澳通行证 |
| 6 | 台湾通行证 |
| 7 | 其他 |

### 账号类型（ACCOUNT_TYPE）

| 代码 | 说明 |
|------|------|
| 00 | 银行卡 |
| 02 | 信用卡 |
| 06 | 银联token |

### 账号属性（ACCOUNT_PROP）

| 代码 | 说明 |
|------|------|
| 0 | 私人账户 |
| 1 | 公司账户 |

## 响应码处理规则（核心规则）

### 成功状态判定

| 返回码 | 含义 | 处理方式 |
|--------|------|----------|
| 0000 | 处理成功 | 成功，停止查询 |
| 4000 | 已发送银行（默认成功） | 成功，关注退票通知 |

**核心规则：0000和4000都视为成功状态！**

### 处理中状态（必须查询）

| 返回码 | 含义 | 处理方式 |
|--------|------|----------|
| 2000 | 系统处理数据中 | 发起交易查询 |
| 2007 | 提交银行处理中 | 发起交易查询 |
| 2008 | 交易返回结果超时 | 发起交易查询 |
| 1108 | 批次号重复 | 发起交易查询 |
| 1000 | 报文处理中 | 发起交易查询 |

**核心规则：以上返回码必须发起交易查询确认最终状态！**

### HTTPS异常处理

**HTTPS异常（读取超时、连接超时等）必须发起交易查询，不能直接判定失败！**

这是通联收付通的核心规则，所有接口都需遵守。

### 1002特殊处理

| 时间 | 处理方式 |
|------|----------|
| 交易发起后10分钟内 | 不查询，等待 |
| 10分钟后 | 开始查询 |
| 30分钟后仍返回1002 | 停止查询，判定交易失败 |

### 返回码详细说明

详见 [reference/RETURN_CODES.md](reference/RETURN_CODES.md) 或官方文档：https://prodoc.allinpay.com/doc/83/

## 官方资源

- 通联支付官网：https://www.allinpay.com/
- 收付通开放平台：https://sft.allinpay.com/
- 技术文档：https://prodoc.allinpay.com/
- 技术支持：联系通联支付技术支持团队

## 注意事项

1. 签约短信验证码有效期通常为5分钟，**测试环境验证码固定为"111111"**
2. 协议号（AGRMNO）是签约成功后的唯一标识，需妥善保存到数据库
3. 交易金额单位为分（整数），100元=10000分
4. SDK签名类型必须与密钥格式匹配：SM2使用国密密钥，RSA使用RSA密钥（如p12）
5. p12格式私钥文件必须通过 `setPrivateKeyPassword()` 配置密码
6. 编码默认为GBK，部分接口支持UTF-8（通过Builder.encoding("UTF-8")配置）
7. **推荐使用 `isTrxSuccess()`, `isTrxFailed()`, `isTrxProcessing()` 判断交易状态**
8. **推荐使用 `isNoTransaction()` 判断1002状态（无此交易记录）**
9. **推荐使用 Builder 模式初始化 SftConfig**
10. **所有交易发起后建议调用查询接口确认最终状态**
11. **HTTPS超时必须发起交易查询，不能直接判定失败**
12. **退款必须基于已成功的支付交易（状态为0000或4000）**
13. submitTime应填写当前请求时间（yyyyMMddHHmmss格式），是必填参数
14. 退款返回码3999表示"其它错误"，具体原因需查看ERR_MSG
15. **业务代码由通联分配，协议支付和退款使用独立的业务代码，不能混用**
16. 退款请求也有可选的submitTime、remark、notifyUrl参数

## 使用优势

- 完整流程覆盖 - 从签约到退款的全流程技能
- 智能适配 - AI根据项目实际情况调整代码
- 降低心智负担 - 无需阅读复杂的接口文档
- 快速上手 - 只需替换关键业务参数即可使用
- 响应码处理规范 - 内置完整的返回码处理逻辑