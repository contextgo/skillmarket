---
name: skills-sync
description: Sync skills across AI coding tools at global or project level. Use when the user mentions syncing skills, pulling skills, pushing skills, or keeping skills consistent across tools.
---

# Skills Sync

Sync skills across AI coding tools via **symlinks** -- edit once, visible everywhere.

Current version: `1.0`

Use this skill when the user wants to sync, pull, push, inspect, or clean up skills across tools such as `claude`, `codex`, `qoder`, or the shared `agents` repo.

The script path is not fixed to `qoder`. It should be resolved from the current runtime's mapped canonical tool name.

## What This Skill Does

This skill helps the AI:

- Inspect current skill layout across tools
- Pull missing skills into a target tool
- Push skills from one tool to others
- Remove symlinks without deleting real files
- Explain the current `skills-sync` version and supported commands

The script works by creating and maintaining **symlinks**. It does not overwrite real skill directories.

## Trigger Guidance

Use this skill when the user says things like:

- "sync my skills"
- "pull skills from qoder to codex"
- "push this skill to other tools"
- "keep Claude/Codex/Qoder skills in sync"
- "show me which skills are linked"
- "unlink this skill"

Do not use this skill when:

- The user wants to edit the contents of a specific skill itself
- The user wants to create a brand new skill from scratch
- The user is asking about general shell symlink behavior unrelated to skills

## Default Operating Rules

- Always check whether the config exists before doing anything else
- If the config file is missing, run `config` and let the user choose tools; do not auto-fill a default config
- Prefer inspecting before mutating
- Prefer `--dry-run` before real `pull`, `push`, or `unlink`
- Prefer `status` for a quick overview
- Prefer `list` when you need per-tool ownership details
- Never assume `agents` can be used as a target; it is a read-only source
- Never claim a real file was synced if the script only created a symlink
- If the user does not specify `scope`, default to `both`
- If the user does not specify `--from` for `pull`, let the script default to `all`
- If the user does not specify `--to` for `push` or `unlink`, let the script default to `all`
- Treat the current AI tool as the default tool context when the user does not name a tool explicitly
- Always map the current runtime or product name to a canonical tool name from the Tools table before building commands
- Never pass a UI label, brand name, or runtime name directly unless it already matches a canonical tool name
- If the task is project-specific and the current working directory may not be the right repo root, use `--project-dir`

## Standard Execution Flow

Follow this order unless the user explicitly asks for something narrower:

1. Check whether `~/.agents/sync-skills.json` exists or run `config --show` to confirm config is available.
2. If config is missing, run `config` and stop there so the user can choose tools interactively.
3. Decide whether the user needs `pull`, `push`, `unlink`, `status`, `list`, or `version`.
4. If the command changes anything, prefer `status` first when context is unclear.
5. Run the mutation command with `--dry-run` first unless the user clearly wants immediate execution.
6. If the dry run matches the user's goal, run the real command.
7. Summarize what changed, including source, target, scope, and whether anything was skipped.

## How To Decide The Command

- Use `sync` language such as "同步 skills" to mean both `pull` and `push`, unless the user clearly says only pull or only push.
- Use `pull` when the user wants one tool to receive missing skills from other tools.
- Use `push` when the user has a source tool they want to distribute from.
- Use `unlink` when the user wants to remove symlinks but keep real files untouched.
- Use `status` when the user asks what is synced or where skills exist.
- Use `list` when the user asks for detailed inventory or symlink ownership.
- Use `version` when the user asks for the current version.

## Current Tool Defaults

Interpret vague sync requests relative to the **current runtime context**, then map that runtime to a canonical tool name from the Tools table before generating commands.

Examples of runtime-to-tool mapping:

- `Claude Code` -> `claude`
- `Codex` / `Codex desktop` / `Codex CLI` -> `codex`
- `Qoder` -> `qoder`

The mapped canonical tool name is the value that should be used in `--to` or `--from`.

Use the same mapped canonical tool name to locate the script:

- `claude` -> `~/.claude/skills/skills-sync/scripts/sync-skills.sh`
- `codex` -> `~/.codex/skills/skills-sync/scripts/sync-skills.sh`
- `qoder` -> `~/.qoder/skills/skills-sync/scripts/sync-skills.sh`

If the current tool is `codex`, then:

- "帮我同步 skills"
- "sync skills"

should default to this sequence:

```bash
bash ~/.codex/skills/skills-sync/scripts/sync-skills.sh pull --to codex
bash ~/.codex/skills/skills-sync/scripts/sync-skills.sh push --from codex
```

Then:

- "帮我拉取 skills"
- "pull skills"

should default to:

```bash
bash ~/.codex/skills/skills-sync/scripts/sync-skills.sh pull --to codex
```

and:

- "帮我推送 skills"
- "push skills"

should default to:

```bash
bash ~/.codex/skills/skills-sync/scripts/sync-skills.sh push --from codex
```

Apply the same rule for other tools:

- current tool is `claude` -> "同步" means `pull --to claude` then `push --from claude`
- current tool is `qoder` -> "同步" means `pull --to qoder` then `push --from qoder`
- current tool is `claude` -> "拉取" means `pull --to claude`, "推送" means `push --from claude`
- current tool is `qoder` -> "拉取" means `pull --to qoder`, "推送" means `push --from qoder`

If the user also provides extra intent, convert it into command flags:

- source tool -> `--from`
- target tool -> `--to`
- scope like global/project/both -> `--scope`
- one specific skill -> `--skill`
- preview only -> `--dry-run`
- explicit repo path -> `--project-dir`

When both the current-tool default and the user's explicit tool conflict, always follow the user's explicit tool.

If the current runtime name is not identical to a canonical tool name, convert it first and only then build the command.

## Quick Start

```bash
# First time: let the user choose tools interactively
bash ~/.<mapped-tool>/skills/skills-sync/scripts/sync-skills.sh config

# Only use --set when the user explicitly gives the tool list
bash ~/.<mapped-tool>/skills/skills-sync/scripts/sync-skills.sh config --set claude,codex
```

Config file: `~/.agents/sync-skills.json`
Script path: `~/.<mapped-tool>/skills/skills-sync/scripts/sync-skills.sh`

## Tools

| Tool | Global | Project |
|------|--------|--------|
| agents | `~/.agents/skills/` | -- |
| cline | `~/.cline/skills/` | `.cline/skills/` |
| codebuddy | `~/.codebuddy/skills/` | `.codebuddy/skills/` |
| cursor | `~/.cursor/skills/` | `.cursor/skills/` |
| gemini | `~/.gemini/skills/` | `.gemini/skills/` |
| github | `~/.github/skills/` | `.github/skills/` |
| lingma | `~/.lingma/skills/` | `.lingma/skills/` |
| opencode | `~/.opencode/skills/` | `.opencode/skills/` |
| qwen | `~/.qwen/skills/` | `.qwen/skills/` |
| trae | `~/.trae/skills/` | `.trae/skills/` |
| claude | `~/.claude/skills/` | `.claude/skills/` |
| codex | `~/.codex/skills/` | `.codex/skills/` |
| qoder | `~/.qoder/skills/` | `.qoder/skills/` |

- Only tools configured in `sync-skills.json` are considered at runtime
- `agents` is auto-detected from `~/.agents/skills/` and is global-only
- `agents` is treated as a shared, read-only source and cannot be a push or pull target

## Config

```bash
bash ~/.<mapped-tool>/skills/skills-sync/scripts/sync-skills.sh config
bash ~/.<mapped-tool>/skills/skills-sync/scripts/sync-skills.sh config --set claude,codex   # only when user explicitly names tools
bash ~/.<mapped-tool>/skills/skills-sync/scripts/sync-skills.sh config --show
bash ~/.<mapped-tool>/skills/skills-sync/scripts/sync-skills.sh config --add codebuddy
bash ~/.<mapped-tool>/skills/skills-sync/scripts/sync-skills.sh config --remove codebuddy
```

Running any command without a config file will show setup instructions.

## Commands

### pull -- bring missing skills in

```bash
# Pull all missing skills into claude from all tools
bash ~/.<mapped-tool>/skills/skills-sync/scripts/sync-skills.sh pull --to claude --scope global

# Pull only from agents
bash ~/.<mapped-tool>/skills/skills-sync/scripts/sync-skills.sh pull --to claude --from agents --scope global

# Pull a specific skill
bash ~/.<mapped-tool>/skills/skills-sync/scripts/sync-skills.sh pull --to claude --from qoder --scope global --skill find-skills

# Preview changes without writing
bash ~/.<mapped-tool>/skills/skills-sync/scripts/sync-skills.sh pull --to claude --scope both --dry-run
```

### push -- send skills out

```bash
# Push claude's skills to all other tools
bash ~/.<mapped-tool>/skills/skills-sync/scripts/sync-skills.sh push --from claude --scope global

# Push to a specific tool
bash ~/.<mapped-tool>/skills/skills-sync/scripts/sync-skills.sh push --from claude --to codex --scope global

# Push a specific skill
bash ~/.<mapped-tool>/skills/skills-sync/scripts/sync-skills.sh push --from claude --to codex --scope global --skill ddd-java
```

### unlink -- remove symlinks

```bash
bash ~/.<mapped-tool>/skills/skills-sync/scripts/sync-skills.sh unlink --from claude --to codex,qoder --scope global
```

### status -- see what's where

```bash
bash ~/.<mapped-tool>/skills/skills-sync/scripts/sync-skills.sh status
```

### list -- detailed inventory

```bash
bash ~/.<mapped-tool>/skills/skills-sync/scripts/sync-skills.sh list
```

### version -- show current version

```bash
bash ~/.<mapped-tool>/skills/skills-sync/scripts/sync-skills.sh version
```

## Safe Response Pattern For AI

When using this skill, the AI should usually report results in this shape:

- Goal: what the user asked to sync or inspect
- Command: the exact command that was run
- Scope: `global`, `project`, or `both`
- Result: what changed, what was skipped, and why
- Notes: whether symlinks were created, updated, removed, or left untouched

Example:

```text
Goal: push claude skills to codex
Command: bash ~/.<mapped-tool>/skills/skills-sync/scripts/sync-skills.sh push --from claude --to codex --scope global
Scope: global
Result: 3 symlinks created, 2 already correct, 1 real file skipped
Notes: no real files were overwritten
```

## Behavior

| Target status | Action |
|---------------|--------|
| Doesn't exist | Create symlink |
| Correct symlink | Skip |
| Wrong symlink | Update to correct source |
| Real file | **Skip** (never overwrite) |

`pull` defaults `--from` to `all`.

`push` and `unlink` default `--to` to `all`.

`status`, `list`, and `version` are read-only commands.

Project scope defaults to the current git root, or the current working directory if not in a git repo. Use `--project-dir <path>` to override it.

## Decision Notes And Edge Cases

- `agents` may be used as a source for `pull`, but not as a target for `pull`, `push`, or `unlink`
- Check config before `status`, `list`, `pull`, `push`, or `unlink`
- If a target already has the correct symlink, the script skips it
- If a target has the wrong symlink, the script updates it
- If a target has a real directory or file, the script skips it and does not overwrite it
- `unlink` only removes matching symlinks; it does not delete real files
- `project` scope only applies to tools that support project-level skill directories
- The script auto-detects the project root using `git rev-parse --show-toplevel`, then falls back to the current working directory

## Required First Step

Before running operational commands, confirm config is present:

```bash
bash ~/.<mapped-tool>/skills/skills-sync/scripts/sync-skills.sh config --show
```

If config is missing, do this instead:

```bash
bash ~/.<mapped-tool>/skills/skills-sync/scripts/sync-skills.sh config
```

Let the user choose tools interactively. Do not auto-configure a default tool list such as `claude,codex,qoder`.

## Command Reference

```
bash ~/.<mapped-tool>/skills/skills-sync/scripts/sync-skills.sh config [--set|--add|--remove|--show]
bash ~/.<mapped-tool>/skills/skills-sync/scripts/sync-skills.sh pull   --to <tool> [--from <tool|all>] [--scope global|project|both] [--skill <name>] [--dry-run] [--project-dir <path>]
bash ~/.<mapped-tool>/skills/skills-sync/scripts/sync-skills.sh push   --from <tool> [--to <tool|all>] [--scope global|project|both] [--skill <name>] [--dry-run] [--project-dir <path>]
bash ~/.<mapped-tool>/skills/skills-sync/scripts/sync-skills.sh unlink --from <tool> [--to <tool|all>] [--scope global|project|both] [--skill <name>] [--dry-run] [--project-dir <path>]
bash ~/.<mapped-tool>/skills/skills-sync/scripts/sync-skills.sh status [--scope global|project|both] [--project-dir <path>]
bash ~/.<mapped-tool>/skills/skills-sync/scripts/sync-skills.sh list   [--scope global|project|both] [--tool <tool|all>] [--project-dir <path>]
bash ~/.<mapped-tool>/skills/skills-sync/scripts/sync-skills.sh version
```

## Recommended Workflow

1. Run `config --show` first to confirm the tool configuration exists.
2. If config is missing, run `config` and let the user pick tools interactively.
3. Resolve the current tool and map vague user language:
   `同步` -> run both `pull --to <current-tool>` and `push --from <current-tool>`
   `拉取` -> run `pull --to <current-tool>`
   `推送` -> run `push --from <current-tool>`
4. Run `status` if you need to inspect the current state first.
5. Run `pull`, `push`, or `unlink` with `--dry-run` first unless the user explicitly wants direct execution.
6. If the user asked to `同步`, do `pull` first and `push` second.
7. Run the real command once the planned changes look right.
8. Use `unlink` only when you want to remove symlinks without touching real files.

## If The User Is Ambiguous

Ask a short follow-up question only when the choice changes behavior in a meaningful way, for example:

- Which tool should be the source of truth?
- Do you want `global`, `project`, or `both` scope?
- Should I only preview with `--dry-run`, or apply the change too?

If the user is not specific and the risk is low, prefer:

- config check first
- interactive config if missing
- inspect second
- dry-run third
- apply fourth
