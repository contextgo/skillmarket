#!/usr/bin/env bash
#
# skills-sync - Sync skills across AI coding tools via symlinks
#
# Commands:
#   sync    Sync skills bidirectionally (pull + push in one pass)
#   pull    Pull skills that target tool is missing from other tools
#   push    Push skills from source tool to other tools
#   unlink  Remove symlinks pointing from source to targets
#   status  Show symlink & presence status across tools
#   list    List skills with symlink indicators
#
# Compatible with bash 3.x (macOS default). ASCII-only.
#

set -euo pipefail

# --- Constants -----------------------------------------------------------

# Config file path
CONFIG_FILE="$HOME/.agents/sync-skills.json"
VERSION="1.1"

# All known tool names (for validation and config prompts only)
KNOWN_TOOLS="cline codebuddy cursor gemini github lingma opencode qwen trae claude codex qoder"
# Known tools that have project-level skills (agents does not)
KNOWN_PROJECT_TOOLS="cline codebuddy cursor gemini github lingma opencode qwen trae claude codex qoder"

# Runtime tool lists - populated by load_config()
TOOLS=""
PROJECT_TOOLS=""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
NC='\033[0m'
BOLD='\033[1m'

# --- Helper Functions ----------------------------------------------------

log_info()    { printf "${BLUE}[INFO]${NC}    %s\n" "$*"; }
log_ok()      { printf "${GREEN}[OK]${NC}      %s\n" "$*"; }
log_warn()    { printf "${YELLOW}[WARN]${NC}    %s\n" "$*"; }
log_error()   { printf "${RED}[ERROR]${NC}   %s\n" "$*"; }
log_pull()    { printf "${CYAN}[PULL]${NC}    %s\n" "$*"; }
log_push()    { printf "${CYAN}[PUSH]${NC}    %s\n" "$*"; }
log_unlink()  { printf "${MAGENTA}[UNLINK]${NC}  %s\n" "$*"; }

print_separator() {
    printf "${BOLD}=================================================${NC}\n"
}

print_scope_header() {
    printf "${BOLD}-- Scope: %s --${NC}\n" "$1"
}

validate_tool() {
    local tool="$1"
    for t in $KNOWN_TOOLS; do
        [[ "$t" == "$tool" ]] && return 0
    done
    log_error "Unknown tool: '$tool'. Known: $KNOWN_TOOLS"
    return 1
}

validate_tool_runtime() {
    local tool="$1"
    for t in $TOOLS; do
        [[ "$t" == "$tool" ]] && return 0
    done
    log_error "Tool '$tool' not in your config. Run: $(basename "$0") config --add $tool"
    return 1
}

has_project_scope() {
    local tool="$1"
    for t in $PROJECT_TOOLS; do
        [[ "$t" == "$tool" ]] && return 0
    done
    return 1
}

# --- Config Functions ----------------------------------------------------

# Read tools list from config file
# Returns space-separated tool names (without agents)
read_config_tools() {
    if [[ ! -f "$CONFIG_FILE" ]]; then
        echo ""
        return
    fi
    # Simple JSON parse for multi-line array (bash 3.x compatible)
    # Extract lines between [ and ], remove quotes/commas/whitespace
    local in_array=false
    local result=""
    while IFS= read -r line; do
        case "$line" in
            *"[")
                in_array=true
                continue
                ;;
            *"]")
                break
                ;;
        esac
        if [[ "$in_array" == true ]]; then
            # Extract quoted string value
            local val
            val="$(echo "$line" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//' | sed 's/"//g' | sed 's/,//')"
            if [[ -n "$val" ]]; then
                result="$result $val"
            fi
        fi
    done < "$CONFIG_FILE"
    echo "$(echo $result)"
}

# Write tools list to config file
write_config_tools() {
    local tools_csv="$1"  # comma-separated
    mkdir -p "$(dirname "$CONFIG_FILE")"
    # Build JSON array
    local json_tools=""
    local first=true
    for t in $(echo "$tools_csv" | tr ',' ' '); do
        [[ -z "$t" ]] && continue
        if [[ "$first" == true ]]; then
            json_tools="    \"$t\""
            first=false
        else
            json_tools="${json_tools},
    \"$t\""
        fi
    done
    cat > "$CONFIG_FILE" <<CONFEOF
{
  "tools": [
${json_tools}
  ]
}
CONFEOF
}

# Load config into TOOLS and PROJECT_TOOLS globals
# Also auto-adds 'agents' if ~/.agents/skills/ exists
load_config() {
    local config_tools
    config_tools="$(read_config_tools)"
    
    # Build TOOLS: configured tools + agents (if dir exists)
    TOOLS=""
    PROJECT_TOOLS=""

    # Auto-detect agents
    if [[ -d "$HOME/.agents/skills" ]]; then
        TOOLS="agents"
    fi

    for t in $config_tools; do
        [[ -z "$t" ]] && continue
        TOOLS="$TOOLS $t"
        # Check if this tool supports project scope
        local is_project=false
        for pt in $KNOWN_PROJECT_TOOLS; do
            [[ "$pt" == "$t" ]] && is_project=true && break
        done
        if [[ "$is_project" == true ]]; then
            PROJECT_TOOLS="$PROJECT_TOOLS $t"
        fi
    done

    # Trim leading spaces
    TOOLS="$(echo $TOOLS)"
    PROJECT_TOOLS="$(echo $PROJECT_TOOLS)"
}

# Check if config exists, prompt user if not
require_config() {
    if [[ ! -f "$CONFIG_FILE" ]]; then
        log_error "Config file not found: $CONFIG_FILE"
        echo ""
        printf "${YELLOW}Please configure your tools first:${NC}\n"
        echo "  $(basename "$0") config          # Interactive setup"
        echo "  $(basename "$0") config --set claude,codex,qoder  # Quick setup"
        echo ""
        exit 1
    fi
    load_config
}

# Interactive config: scan for tools and let user choose
cmd_config() {
    local action="$1"
    local value="$2"

    case "$action" in
        --show)
            if [[ ! -f "$CONFIG_FILE" ]]; then
                printf "${YELLOW}No config file found at %s${NC}\n" "$CONFIG_FILE"
            else
                printf "${BOLD}Config file:${NC} %s\n" "$CONFIG_FILE"
                cat "$CONFIG_FILE"
                echo ""
                load_config
                printf "${BOLD}Active tools:${NC} %s\n" "$TOOLS"
                printf "${BOLD}Project-scope tools:${NC} %s\n" "$PROJECT_TOOLS"
            fi
            return 0
            ;;
        --set)
            if [[ -z "$value" ]]; then
                log_error "--set requires a comma-separated tool list"
                echo "  Example: $(basename "$0") config --set claude,codex,qoder"
                return 1
            fi
            # Validate each tool
            for t in $(echo "$value" | tr ',' ' '); do
                if ! validate_tool "$t"; then
                    return 1
                fi
            done
            write_config_tools "$value"
            load_config
            log_ok "Config saved. Active tools: $TOOLS"
            return 0
            ;;
        --add)
            if [[ -z "$value" ]]; then
                log_error "--add requires a tool name"
                echo "  Example: $(basename "$0") config --add codebuddy"
                return 1
            fi
            if ! validate_tool "$value"; then
                return 1
            fi
            local current_tools
            current_tools="$(read_config_tools | tr ' ' ',')"
            # Check if already configured
            for t in $(read_config_tools); do
                if [[ "$t" == "$value" ]]; then
                    log_warn "Tool '$value' is already in config"
                    return 0
                fi
            done
            if [[ -n "$current_tools" ]]; then
                write_config_tools "${current_tools},${value}"
            else
                write_config_tools "$value"
            fi
            load_config
            log_ok "Added '$value'. Active tools: $TOOLS"
            return 0
            ;;
        --remove)
            if [[ -z "$value" ]]; then
                log_error "--remove requires a tool name"
                echo "  Example: $(basename "$0") config --remove codebuddy"
                return 1
            fi
            local current_tools
            current_tools="$(read_config_tools)"
            local new_tools=""
            local found=false
            for t in $current_tools; do
                if [[ "$t" == "$value" ]]; then
                    found=true
                    continue
                fi
                new_tools="$new_tools $t"
            done
            if [[ "$found" == false ]]; then
                log_warn "Tool '$value' is not in config"
                return 0
            fi
            new_tools="$(echo $new_tools | tr ' ' ',')"
            write_config_tools "$new_tools"
            load_config
            log_ok "Removed '$value'. Active tools: $TOOLS"
            return 0
            ;;
        ""|interactive)
            # Interactive mode: show all known tools, pre-select installed ones
            echo ""
            print_separator
            printf "${BOLD}  Skills-Sync Configuration${NC}\n"
            print_separator
            echo ""

            # Show current config if exists
            if [[ -f "$CONFIG_FILE" ]]; then
                local current_tools
                current_tools="$(read_config_tools)"
                printf "  Current config: %s\n" "$current_tools"
                echo ""
            fi

            # Check agents
            if [[ -d "$HOME/.agents/skills" ]]; then
                printf "  ${BOLD}Shared repo:${NC}\n"
                printf "    ${GREEN}*${NC} %-15s %s  ${CYAN}(auto-detected, read-only)${NC}\n" "agents" "$HOME/.agents/skills"
                echo ""
            fi

            # Show all known tools with install status
            printf "  ${BOLD}Available tools:${NC}\n"
            local default_selected=""
            local num=1
            for t in $KNOWN_TOOLS; do
                local tool_dir="$HOME/.${t}/skills"
                if [[ -d "$tool_dir" ]]; then
                    printf "    ${GREEN}[x]${NC} %-3d %-15s %s\n" "$num" "$t" "$tool_dir"
                    default_selected="$default_selected,$t"
                else
                    printf "    ${RED}[ ]${NC} %-3d %-15s %s\n" "$num" "$t" "(not installed)"
                fi
                num=$((num + 1))
            done
            echo ""

            # Build default value (installed tools)
            default_selected="$(echo "$default_selected" | sed 's/^,//')"

            # Prompt user
            printf "  Enter tools to sync (comma-separated, or number list):\n"
            printf "  Default [%s]: " "$default_selected"
            read -r user_input

            # Use default if empty
            if [[ -z "$user_input" ]]; then
                user_input="$default_selected"
            fi

            # Handle number input: convert numbers to tool names
            # First check if input is all numbers and commas
            local is_num_input=true
            for word in $(echo "$user_input" | tr ',' ' '); do
                case "$word" in
                    ''|*[!0-9]*) is_num_input=false; break ;;
                esac
            done

            if [[ "$is_num_input" == true ]]; then
                local resolved=""
                for n in $(echo "$user_input" | tr ',' ' '); do
                    [[ -z "$n" ]] && continue
                    local pos=1
                    for t in $KNOWN_TOOLS; do
                        if [[ "$pos" -eq "$n" ]]; then
                            if [[ -n "$resolved" ]]; then
                                resolved="$resolved,$t"
                            else
                                resolved="$t"
                            fi
                            break
                        fi
                        pos=$((pos + 1))
                    done
                done
                user_input="$resolved"
            fi

            # Validate
            for t in $(echo "$user_input" | tr ',' ' '); do
                if ! validate_tool "$t"; then
                    return 1
                fi
            done

            write_config_tools "$user_input"
            load_config
            echo ""
            log_ok "Config saved to $CONFIG_FILE"
            printf "  Active tools: ${GREEN}%s${NC}\n" "$TOOLS"
            return 0
            ;;
        *)
            log_error "Unknown config action: '$action'"
            echo "  Valid: --set, --show, --add, --remove, (interactive)"
            return 1
            ;;
    esac
}

# Check if a tool's skills directory exists for a given scope
tool_dir_exists() {
    local tool="$1"
    local scope="$2"
    local project_dir="$3"
    local dir
    dir="$(get_skills_dir "$tool" "$scope" "$project_dir")"
    [[ -d "$dir" ]]
}

# Get list of tools for a given scope (all configured tools, no directory filter)
# For display in status/list; directory check happens at skill level
get_active_tools() {
    local scope="$1"
    local project_dir="$2"
    local result=""
    for t in $TOOLS; do
        # Skip tools that don't support this scope
        [[ "$scope" == "project" ]] && ! has_project_scope "$t" && continue
        result="$result $t"
    done
    echo "$result"
}

get_skills_dir() {
    local tool="$1"
    local scope="$2"
    local project_dir="$3"

    if [[ "$tool" == "agents" ]]; then
        # agents only has global scope
        echo "$HOME/.agents/skills"
        return
    fi

    case "$scope" in
        global)  echo "$HOME/.${tool}/skills" ;;
        project) echo "${project_dir}/.${tool}/skills" ;;
        *) log_error "Invalid scope: '$scope'"; return 1 ;;
    esac
}

list_skill_names() {
    local dir="$1"
    if [[ -d "$dir" ]]; then
        for d in "$dir"/*/; do
            [[ -d "$d" ]] || continue
            local name
            name="$(basename "$d")"
            [[ "$name" == .* || "$name" == ".system" ]] && continue
            echo "$name"
        done
    fi
}

skill_exists() {
    local dir="$1"
    local skill_name="$2"
    [[ -e "${dir}/${skill_name}" ]] || [[ -L "${dir}/${skill_name}" ]]
}

is_symlink() {
    local path="$1"
    [[ -L "$path" ]]
}

resolve_link() {
    local path="$1"
    local target
    target="$(readlink "$path" 2>/dev/null || echo "")"
    if [[ -z "$target" ]]; then
        echo "$path"
        return
    fi
    if [[ "$target" != /* ]]; then
        local link_dir
        link_dir="$(cd "$(dirname "$path")" && pwd)"
        target="${link_dir}/${target}"
    fi
    # Normalize path: resolve .. and . components
    local norm_dir
    norm_dir="$(cd "$(dirname "$target")" 2>/dev/null && pwd)" || {
        # Parent dir doesn't exist, return as-is
        echo "$target"
        return
    }
    target="${norm_dir}/$(basename "$target")"

    if [[ -L "$target" ]]; then
        resolve_link "$target"
    else
        echo "$target"
    fi
}

# Find which tool owns a skill's real files
find_real_owner() {
    local skill_path="$1"
    local scope="$2"
    local project_dir="$3"

    local resolved="$skill_path"
    if is_symlink "$resolved"; then
        resolved="$(resolve_link "$resolved")"
    fi

    for t in $TOOLS; do
        local t_dir
        t_dir="$(get_skills_dir "$t" "$scope" "$project_dir")"
        if [[ "$resolved" == "${t_dir}"/* ]]; then
            echo "$t"
            return
        fi
    done
    echo ""
}

# Get the real directory path for a skill in a given tool
get_real_skill_dir() {
    local tool="$1"
    local skill="$2"
    local scope="$3"
    local project_dir="$4"

    local base_dir
    base_dir="$(get_skills_dir "$tool" "$scope" "$project_dir")"
    local skill_path="${base_dir}/${skill}"

    if [[ ! -e "$skill_path" ]] && [[ ! -L "$skill_path" ]]; then
        echo ""
        return
    fi

    if is_symlink "$skill_path"; then
        resolve_link "$skill_path"
    else
        echo "$skill_path"
    fi
}

# Parse comma-separated tools, expand "all" if needed
# For pull: all = agents + configured tools (agents is source)
# For push/unlink: all = configured tools minus agents (agents is read-only)
parse_tool_list() {
    local tools_str="$1"
    local exclude_tool="$2"
    local scope="$3"
    local project_dir="$4"
    local mode="$5"  # "source" for pull, "target" for push/unlink

    local candidates=""
    if [[ "$tools_str" == "all" ]]; then
        if [[ "$mode" == "source" ]]; then
            # pull --from all: agents + configured tools
            candidates="$TOOLS"
        else
            # push/unlink --to all: configured tools minus agents
            for t in $TOOLS; do
                [[ "$t" == "agents" ]] && continue
                candidates="$candidates $t"
            done
            candidates="$(echo $candidates)"
        fi
    else
        candidates="$(echo $tools_str | tr ',' ' ')"
    fi

    local result=""
    for t in $candidates; do
        [[ "$t" == "$exclude_tool" ]] && continue
        result="$result $t"
    done
    echo "$result"
}

# Expand scopes based on tool capabilities
expand_scopes() {
    local scope="$1"
    local tool="$2"

    # agents only has global
    if [[ "$tool" == "agents" && "$scope" == "project" ]]; then
        echo ""
        return
    fi

    case "$scope" in
        global|project) echo "$scope" ;;
        both) echo "global project" ;;
        *) log_error "Invalid scope: '$scope'"; echo "" ;;
    esac
}

# --- Commands ------------------------------------------------------------

cmd_status() {
    local scope="$1"
    local project_dir="$2"

    echo ""
    print_separator
    printf "${BOLD}  Skills Status${NC}\n"
    print_separator

    for s in global project; do
        # Skip project scope if scope is global-only
        [[ "$scope" == "global" && "$s" == "project" ]] && continue
        [[ "$scope" == "project" && "$s" == "global" ]] && continue

        echo ""
        print_scope_header "$s"

        # Collect all unique skill names across active tools
        local active_tools
        active_tools="$(get_active_tools "$s" "$project_dir")"

        local all_skills=""
        for t in $active_tools; do
            local dir
            dir="$(get_skills_dir "$t" "$s" "$project_dir")"
            for skill in $(list_skill_names "$dir"); do
                [[ -z "$skill" ]] && continue
                if echo " $all_skills " | grep -q " $skill "; then continue; fi
                all_skills="$all_skills $skill"
            done
        done

        if [[ -z "$(echo $all_skills)" ]]; then
            echo "  [no skills found]"
            continue
        fi

        # Header row
        printf "  %-30s" "Skill"
        for t in $active_tools; do
            printf "%-12s" "$t"
        done
        echo ""

        # Data rows
        for skill in $(echo $all_skills | tr ' ' '\n' | sort); do
            [[ -z "$skill" ]] && continue
            printf "  %-30s" "$skill"
            for t in $active_tools; do
                local dir
                dir="$(get_skills_dir "$t" "$s" "$project_dir")"
                local skill_path="${dir}/${skill}"
                if [[ ! -e "$skill_path" ]] && [[ ! -L "$skill_path" ]]; then
                    printf "${RED}%-12s${NC}" "x"
                elif is_symlink "$skill_path"; then
                    local owner
                    owner="$(find_real_owner "$skill_path" "$s" "$project_dir")"
                    if [[ -n "$owner" ]]; then
                        printf "${CYAN}%-12s${NC}" "-> $owner"
                    else
                        printf "${CYAN}%-12s${NC}" "-> ?"
                    fi
                else
                    printf "${GREEN}%-12s${NC}" "v real"
                fi
            done
            echo ""
        done
    done
    echo ""
}

# pull: Bring skills that target tool is missing from other tools
cmd_pull() {
    local to_tool="$1"
    local from_tools_str="$2"
    local scope="$3"
    local skill_filter="$4"
    local dry_run="$5"
    local project_dir="$6"

    validate_tool_runtime "$to_tool" || exit 1

    # agents is read-only source, cannot be target
    if [[ "$to_tool" == "agents" ]]; then
        log_error "'agents' is a read-only shared repo. Cannot pull into it."
        exit 1
    fi

    local from_tools
    from_tools="$(parse_tool_list "$from_tools_str" "$to_tool" "$scope" "$project_dir" "source")"
    for f in $from_tools; do
        validate_tool_runtime "$f" || exit 1
    done

    echo ""
    print_separator
    printf "${BOLD}  Skills Pull${NC}\n"
    print_separator
    printf "  Target:  ${GREEN}%s${NC}  [receive symlinks]\n" "$to_tool"
    printf "  From:    ${CYAN}%s${NC}\n" "$from_tools"
    printf "  Scope:   %s\n" "$scope"
    [[ -n "$skill_filter" ]] && printf "  Skill:   %s\n" "$skill_filter"
    [[ "$dry_run" == true ]] && printf "  ${YELLOW}[DRY RUN]${NC} No changes\n"
    echo ""

    local pulled=0
    local skipped=0
    local updated=0
    local failed=0

    for s in global project; do
        # Scope filtering
        [[ "$scope" == "global" && "$s" == "project" ]] && continue
        [[ "$scope" == "project" && "$s" == "global" ]] && continue

        # Skip if target tool doesn't support this scope
        [[ "$s" == "project" ]] && ! has_project_scope "$to_tool" && continue

        print_scope_header "$s"

        local to_dir
        to_dir="$(get_skills_dir "$to_tool" "$s" "$project_dir")"

        for f in $from_tools; do
            # Skip if from tool doesn't support this scope
            [[ "$s" == "project" ]] && ! has_project_scope "$f" && continue

            local from_dir
            from_dir="$(get_skills_dir "$f" "$s" "$project_dir")"
            if [[ ! -d "$from_dir" ]]; then continue; fi

            # Get skills to pull
            local skills=""
            if [[ -n "$skill_filter" ]]; then
                if skill_exists "$from_dir" "$skill_filter"; then
                    skills="$skill_filter"
                else
                    continue
                fi
            else
                skills="$(list_skill_names "$from_dir" | tr '\n' ' ')"
            fi

            for skill in $skills; do
                [[ -z "$skill" ]] && continue

                # Get real file location from source
                local real_src
                real_src="$(get_real_skill_dir "$f" "$skill" "$s" "$project_dir")"
                if [[ -z "$real_src" ]]; then
                    log_warn "$skill @ $f [$s]: cannot resolve real path, skip"
                    skipped=$((skipped + 1))
                    continue
                fi

                local to_skill_path="${to_dir}/${skill}"

                # Target doesn't exist -> create symlink
                if [[ ! -e "$to_skill_path" ]] && [[ ! -L "$to_skill_path" ]]; then
                    if [[ "$dry_run" == true ]]; then
                        log_pull "$skill <- $f [$s]: would create symlink"
                        pulled=$((pulled + 1))
                    else
                        mkdir -p "$to_dir"
                        if ln -s "$real_src" "$to_skill_path"; then
                            log_pull "$skill <- $f [$s]: symlink created"
                            pulled=$((pulled + 1))
                        else
                            log_error "$skill <- $f [$s]: failed"
                            failed=$((failed + 1))
                        fi
                    fi
                    continue
                fi

                # Target is a correct symlink -> skip
                if is_symlink "$to_skill_path"; then
                    local resolved
                    resolved="$(resolve_link "$to_skill_path")"
                    if [[ "$resolved" == "$real_src" ]]; then
                        log_ok "$skill @ $to_tool [$s]: already linked to $f"
                        skipped=$((skipped + 1))
                        continue
                    fi
                    # Wrong symlink -> update
                    if [[ "$dry_run" == true ]]; then
                        log_pull "$skill <- $f [$s]: would update symlink"
                        updated=$((updated + 1))
                    else
                        rm "$to_skill_path"
                        if ln -s "$real_src" "$to_skill_path"; then
                            log_pull "$skill <- $f [$s]: symlink updated"
                            updated=$((updated + 1))
                        else
                            log_error "$skill <- $f [$s]: update failed"
                            failed=$((failed + 1))
                        fi
                    fi
                    continue
                fi

                # Target is a real file -> skip, do not touch
                log_ok "$skill @ $to_tool [$s]: real file exists, skip"
                skipped=$((skipped + 1))
            done
        done
    done

    echo ""
    print_separator
    printf "  Pulled:   ${CYAN}%d${NC}\n" "$pulled"
    printf "  Updated:  ${MAGENTA}%d${NC}\n" "$updated"
    printf "  Skipped:  ${YELLOW}%d${NC}\n" "$skipped"
    printf "  Failed:   ${RED}%d${NC}\n" "$failed"
    print_separator
    echo ""

    [[ $failed -gt 0 ]] && return 1 || return 0
}

# push: Push skills from source tool to other tools
cmd_push() {
    local from_tool="$1"
    local to_tools_str="$2"
    local scope="$3"
    local skill_filter="$4"
    local dry_run="$5"
    local project_dir="$6"

    validate_tool_runtime "$from_tool" || exit 1

    local to_tools
    to_tools="$(parse_tool_list "$to_tools_str" "$from_tool" "$scope" "$project_dir" "target")"
    for t in $to_tools; do
        validate_tool_runtime "$t" || exit 1
    done

    # Filter out agents from push targets (read-only source)
    local filtered_to_tools=""
    for t in $to_tools; do
        if [[ "$t" == "agents" ]]; then
            log_warn "'agents' is read-only, skipping as push target"
            continue
        fi
        filtered_to_tools="$filtered_to_tools $t"
    done
    to_tools="$(echo $filtered_to_tools)"

    echo ""
    print_separator
    printf "${BOLD}  Skills Push${NC}\n"
    print_separator
    printf "  Source:  ${GREEN}%s${NC}  [has real files]\n" "$from_tool"
    printf "  To:      ${CYAN}%s${NC}  [receive symlinks]\n" "$to_tools"
    printf "  Scope:   %s\n" "$scope"
    [[ -n "$skill_filter" ]] && printf "  Skill:   %s\n" "$skill_filter"
    [[ "$dry_run" == true ]] && printf "  ${YELLOW}[DRY RUN]${NC} No changes\n"
    echo ""

    local pushed=0
    local skipped=0
    local updated=0
    local failed=0

    for s in global project; do
        [[ "$scope" == "global" && "$s" == "project" ]] && continue
        [[ "$scope" == "project" && "$s" == "global" ]] && continue

        # Skip if from tool doesn't support this scope
        [[ "$s" == "project" ]] && ! has_project_scope "$from_tool" && continue

        local from_dir
        from_dir="$(get_skills_dir "$from_tool" "$s" "$project_dir")"

        if [[ ! -d "$from_dir" ]]; then continue; fi

        print_scope_header "$s"

        # Get skills to push
        local skills=""
        if [[ -n "$skill_filter" ]]; then
            if skill_exists "$from_dir" "$skill_filter"; then
                skills="$skill_filter"
            else
                log_warn "Skill '$skill_filter' not found in $from_tool [$s]"
                continue
            fi
        else
            skills="$(list_skill_names "$from_dir" | tr '\n' ' ')"
        fi

        if [[ -z "$(echo $skills)" ]]; then
            log_warn "No skills found in $from_tool [$s]"
            continue
        fi

        for skill in $skills; do
            [[ -z "$skill" ]] && continue

            # Get real file location from source
            local real_src
            real_src="$(get_real_skill_dir "$from_tool" "$skill" "$s" "$project_dir")"
            if [[ -z "$real_src" ]]; then
                log_warn "$skill @ $from_tool [$s]: cannot resolve real path, skip"
                skipped=$((skipped + 1))
                continue
            fi

            for t in $to_tools; do
                # Skip if target doesn't support this scope
                [[ "$s" == "project" ]] && ! has_project_scope "$t" && continue

                local target_dir
                target_dir="$(get_skills_dir "$t" "$s" "$project_dir")"
                local target_skill_path="${target_dir}/${skill}"

                # Target doesn't exist -> create symlink
                if [[ ! -e "$target_skill_path" ]] && [[ ! -L "$target_skill_path" ]]; then
                    if [[ "$dry_run" == true ]]; then
                        log_push "$skill -> $t [$s]: would create symlink"
                        pushed=$((pushed + 1))
                    else
                        mkdir -p "$target_dir"
                        if ln -s "$real_src" "$target_skill_path"; then
                            log_push "$skill -> $t [$s]: symlink created"
                            pushed=$((pushed + 1))
                        else
                            log_error "$skill -> $t [$s]: failed"
                            failed=$((failed + 1))
                        fi
                    fi
                    continue
                fi

                # Target is a correct symlink -> skip
                if is_symlink "$target_skill_path"; then
                    local resolved
                    resolved="$(resolve_link "$target_skill_path")"
                    if [[ "$resolved" == "$real_src" ]]; then
                        log_ok "$skill @ $t [$s]: already linked"
                        skipped=$((skipped + 1))
                        continue
                    fi
                    # Wrong symlink -> update
                    if [[ "$dry_run" == true ]]; then
                        log_push "$skill -> $t [$s]: would update symlink"
                        updated=$((updated + 1))
                    else
                        rm "$target_skill_path"
                        if ln -s "$real_src" "$target_skill_path"; then
                            log_push "$skill -> $t [$s]: symlink updated"
                            updated=$((updated + 1))
                        else
                            log_error "$skill -> $t [$s]: update failed"
                            failed=$((failed + 1))
                        fi
                    fi
                    continue
                fi

                # Target is a real file -> skip, do not touch
                log_ok "$skill @ $t [$s]: real file exists, skip"
                skipped=$((skipped + 1))
            done
        done
    done

    echo ""
    print_separator
    printf "  Pushed:   ${CYAN}%d${NC}\n" "$pushed"
    printf "  Updated:  ${MAGENTA}%d${NC}\n" "$updated"
    printf "  Skipped:  ${YELLOW}%d${NC}\n" "$skipped"
    printf "  Failed:   ${RED}%d${NC}\n" "$failed"
    print_separator
    echo ""

    [[ $failed -gt 0 ]] && return 1 || return 0
}

# unlink: Remove symlinks from targets that point to source
cmd_unlink() {
    local from_tool="$1"
    local to_tools_str="$2"
    local scope="$3"
    local skill_filter="$4"
    local dry_run="$5"
    local project_dir="$6"

    validate_tool_runtime "$from_tool" || exit 1

    local to_tools
    to_tools="$(parse_tool_list "$to_tools_str" "$from_tool" "$scope" "$project_dir" "target")"
    for t in $to_tools; do
        validate_tool_runtime "$t" || exit 1
        # agents is read-only, skip as unlink target
        if [[ "$t" == "agents" ]]; then
            log_warn "'agents' is read-only, skipping as unlink target"
            continue
        fi
    done

    # Filter out agents from to_tools
    local filtered_to_tools=""
    for t in $to_tools; do
        [[ "$t" == "agents" ]] && continue
        filtered_to_tools="$filtered_to_tools $t"
    done
    to_tools="$(echo $filtered_to_tools)"

    echo ""
    print_separator
    printf "  Remove symlinks in: ${CYAN}%s${NC}\n" "$to_tools"
    printf "  Pointing from:      ${GREEN}%s${NC}\n" "$from_tool"
    printf "  Scope:              %s\n" "$scope"
    [[ -n "$skill_filter" ]] && printf "  Skill:              %s\n" "$skill_filter"
    [[ "$dry_run" == true ]] && printf "  ${YELLOW}[DRY RUN]${NC} No changes\n"
    echo ""

    local unlinked=0
    local skipped=0
    local failed=0

    for s in global project; do
        [[ "$scope" == "global" && "$s" == "project" ]] && continue
        [[ "$scope" == "project" && "$s" == "global" ]] && continue

        [[ "$s" == "project" ]] && ! has_project_scope "$from_tool" && continue

        local from_dir
        from_dir="$(get_skills_dir "$from_tool" "$s" "$project_dir")"

        print_scope_header "$s"

        local skills=""
        if [[ -n "$skill_filter" ]]; then
            skills="$skill_filter"
        else
            skills="$(list_skill_names "$from_dir" | tr '\n' ' ')"
        fi

        for skill in $skills; do
            [[ -z "$skill" ]] && continue

            # The direct path in from_tool's directory (may itself be a symlink)
            # We only remove symlinks in to_tools that point HERE (to from_dir/skill)
            # Do NOT follow from_tool's own symlink - that would cause over-deletion
            local from_skill_path="${from_dir}/${skill}"
            # Normalize the from path (resolve .. etc but NOT symlinks)
            local from_skill_norm
            from_skill_norm="$(cd "$from_dir" 2>/dev/null && pwd)/${skill}"

            for t in $to_tools; do
                [[ "$s" == "project" ]] && ! has_project_scope "$t" && continue

                local target_dir
                target_dir="$(get_skills_dir "$t" "$s" "$project_dir")"
                local target_skill_path="${target_dir}/${skill}"

                if ! is_symlink "$target_skill_path"; then
                    skipped=$((skipped + 1))
                    continue
                fi

                # Check if symlink points DIRECTLY to from_tool's skill path
                local link_target
                link_target="$(readlink "$target_skill_path" 2>/dev/null)"
                # Resolve to absolute normalized path
                local resolved_target
                if [[ "$link_target" == /* ]]; then
                    resolved_target="$link_target"
                else
                    local t_link_dir
                    t_link_dir="$(cd "$target_dir" 2>/dev/null && pwd)"
                    resolved_target="${t_link_dir}/${link_target}"
                fi
                # Normalize (remove ..)
                local rt_dir rt_base
                rt_dir="$(cd "$(dirname "$resolved_target")" 2>/dev/null && pwd)"
                rt_base="$(basename "$resolved_target")"
                resolved_target="${rt_dir}/${rt_base}"

                if [[ "$resolved_target" != "$from_skill_norm" ]]; then
                    log_warn "$skill @ $t [$s]: symlink points to $resolved_target, not $from_skill_norm, skip"
                    skipped=$((skipped + 1))
                    continue
                fi

                if [[ "$dry_run" == true ]]; then
                    log_unlink "$skill @ $t [$s]: would remove symlink"
                    unlinked=$((unlinked + 1))
                else
                    if rm "$target_skill_path"; then
                        log_unlink "$skill @ $t [$s]: symlink removed"
                        unlinked=$((unlinked + 1))
                    else
                        log_error "$skill @ $t [$s]: failed"
                        failed=$((failed + 1))
                    fi
                fi
            done
        done
    done

    echo ""
    print_separator
    printf "  Unlinked: ${MAGENTA}%d${NC}\n" "$unlinked"
    printf "  Skipped:  ${YELLOW}%d${NC}\n" "$skipped"
    printf "  Failed:   ${RED}%d${NC}\n" "$failed"
    print_separator
    echo ""

    [[ $failed -gt 0 ]] && return 1 || return 0
}

cmd_list() {
    local scope="$1"
    local tool_filter="$2"
    local project_dir="$3"

    echo ""
    print_separator
    printf "${BOLD}  Skills Inventory${NC}\n"
    print_separator

    for s in global project; do
        [[ "$scope" == "global" && "$s" == "project" ]] && continue
        [[ "$scope" == "project" && "$s" == "global" ]] && continue

        echo ""
        print_scope_header "$s"

        local tools=""
        if [[ "$tool_filter" == "all" ]]; then
            tools="$(get_active_tools "$s" "$project_dir")"
        else
            tools="$(echo $tool_filter | tr ',' ' ')"
        fi

        for t in $tools; do
            validate_tool_runtime "$t" || exit 1

            local dir
            dir="$(get_skills_dir "$t" "$s" "$project_dir")"
            printf "  ${CYAN}%s${NC} [%s]\n" "$t" "$dir"
            if [[ -d "$dir" ]]; then
                local count=0
                for skill in $(list_skill_names "$dir" | sort); do
                    [[ -z "$skill" ]] && continue
                    local skill_path="${dir}/${skill}"
                    if is_symlink "$skill_path"; then
                        local owner
                        owner="$(find_real_owner "$skill_path" "$s" "$project_dir")"
                        if [[ -n "$owner" ]]; then
                            printf "    |-- %s ${CYAN}[-> %s]${NC}\n" "$skill" "$owner"
                        else
                            printf "    |-- %s ${CYAN}[-> ?]${NC}\n" "$skill"
                        fi
                    else
                        printf "    |-- %s ${GREEN}[real]${NC}\n" "$skill"
                    fi
                    count=$((count + 1))
                done
                if [[ $count -eq 0 ]]; then
                    echo "    |-- [empty]"
                fi
            else
                echo "    |-- [not found]"
            fi
        done
    done
    echo ""
}

# sync: Bidirectional sync — pull into center tool, then push from center tool
cmd_sync() {
    local center_tool="$1"
    local scope="$2"
    local skill_filter="$3"
    local dry_run="$4"
    local project_dir="$5"

    validate_tool_runtime "$center_tool" || exit 1

    # agents is read-only, cannot be sync center
    if [[ "$center_tool" == "agents" ]]; then
        log_error "'agents' is a read-only shared repo. Cannot sync into it."
        exit 1
    fi

    # Build source list (all tools except center) and target list (all non-agents except center)
    local source_tools=""
    local target_tools=""
    for t in $TOOLS; do
        [[ "$t" == "$center_tool" ]] && continue
        source_tools="$source_tools $t"
        if [[ "$t" != "agents" ]]; then
            target_tools="$target_tools $t"
        fi
    done
    source_tools="$(echo $source_tools)"
    target_tools="$(echo $target_tools)"

    echo ""
    print_separator
    printf "${BOLD}  Skills Sync (bidirectional)${NC}\n"
    print_separator
    printf "  Center:  ${GREEN}%s${NC}\n" "$center_tool"
    printf "  Pull from: ${CYAN}%s${NC}\n" "$source_tools"
    printf "  Push to:   ${CYAN}%s${NC}\n" "$target_tools"
    printf "  Scope:   %s\n" "$scope"
    [[ -n "$skill_filter" ]] && printf "  Skill:   %s\n" "$skill_filter"
    [[ "$dry_run" == true ]] && printf "  ${YELLOW}[DRY RUN]${NC} No changes\n"
    echo ""

    local pulled=0
    local pushed=0
    local updated=0
    local skipped=0
    local failed=0

    for s in global project; do
        [[ "$scope" == "global" && "$s" == "project" ]] && continue
        [[ "$scope" == "project" && "$s" == "global" ]] && continue

        [[ "$s" == "project" ]] && ! has_project_scope "$center_tool" && continue

        print_scope_header "$s"

        local center_dir
        center_dir="$(get_skills_dir "$center_tool" "$s" "$project_dir")"

        # --- Phase 1: Pull — bring skills into center that center is missing ---
        for f in $source_tools; do
            [[ "$s" == "project" ]] && ! has_project_scope "$f" && continue

            local from_dir
            from_dir="$(get_skills_dir "$f" "$s" "$project_dir")"
            [[ ! -d "$from_dir" ]] && continue

            local skills=""
            if [[ -n "$skill_filter" ]]; then
                skill_exists "$from_dir" "$skill_filter" && skills="$skill_filter" || continue
            else
                skills="$(list_skill_names "$from_dir" | tr '\n' ' ')"
            fi

            for skill in $skills; do
                [[ -z "$skill" ]] && continue

                local real_src
                real_src="$(get_real_skill_dir "$f" "$skill" "$s" "$project_dir")"
                [[ -z "$real_src" ]] && { skipped=$((skipped + 1)); continue; }

                local center_skill_path="${center_dir}/${skill}"

                # Center doesn't have it -> create symlink
                if [[ ! -e "$center_skill_path" ]] && [[ ! -L "$center_skill_path" ]]; then
                    if [[ "$dry_run" == true ]]; then
                        log_pull "$skill <- $f [$s]: would create symlink"
                        pulled=$((pulled + 1))
                    else
                        mkdir -p "$center_dir"
                        if ln -s "$real_src" "$center_skill_path"; then
                            log_pull "$skill <- $f [$s]: symlink created"
                            pulled=$((pulled + 1))
                        else
                            log_error "$skill <- $f [$s]: failed"
                            failed=$((failed + 1))
                        fi
                    fi
                    continue
                fi

                # Center has wrong symlink -> update
                if is_symlink "$center_skill_path"; then
                    local resolved
                    resolved="$(resolve_link "$center_skill_path")"
                    if [[ "$resolved" != "$real_src" ]]; then
                        if [[ "$dry_run" == true ]]; then
                            log_pull "$skill <- $f [$s]: would update symlink"
                            updated=$((updated + 1))
                        else
                            rm "$center_skill_path"
                            if ln -s "$real_src" "$center_skill_path"; then
                                log_pull "$skill <- $f [$s]: symlink updated"
                                updated=$((updated + 1))
                            else
                                log_error "$skill <- $f [$s]: update failed"
                                failed=$((failed + 1))
                            fi
                        fi
                        continue
                    fi
                fi

                # Center has correct symlink or real file -> skip
                skipped=$((skipped + 1))
            done
        done

        # --- Phase 2: Push — push center's skills to all other tools ---
        if [[ ! -d "$center_dir" ]]; then continue; fi

        local center_skills=""
        if [[ -n "$skill_filter" ]]; then
            skill_exists "$center_dir" "$skill_filter" && center_skills="$skill_filter" || center_skills=""
        else
            center_skills="$(list_skill_names "$center_dir" | tr '\n' ' ')"
        fi

        for skill in $center_skills; do
            [[ -z "$skill" ]] && continue

            local real_src
            real_src="$(get_real_skill_dir "$center_tool" "$skill" "$s" "$project_dir")"
            [[ -z "$real_src" ]] && { skipped=$((skipped + 1)); continue; }

            for t in $target_tools; do
                [[ "$s" == "project" ]] && ! has_project_scope "$t" && continue

                local target_dir
                target_dir="$(get_skills_dir "$t" "$s" "$project_dir")"
                local target_skill_path="${target_dir}/${skill}"

                # Target doesn't have it -> create symlink
                if [[ ! -e "$target_skill_path" ]] && [[ ! -L "$target_skill_path" ]]; then
                    if [[ "$dry_run" == true ]]; then
                        log_push "$skill -> $t [$s]: would create symlink"
                        pushed=$((pushed + 1))
                    else
                        mkdir -p "$target_dir"
                        if ln -s "$real_src" "$target_skill_path"; then
                            log_push "$skill -> $t [$s]: symlink created"
                            pushed=$((pushed + 1))
                        else
                            log_error "$skill -> $t [$s]: failed"
                            failed=$((failed + 1))
                        fi
                    fi
                    continue
                fi

                # Target has wrong symlink -> update
                if is_symlink "$target_skill_path"; then
                    local resolved
                    resolved="$(resolve_link "$target_skill_path")"
                    if [[ "$resolved" != "$real_src" ]]; then
                        if [[ "$dry_run" == true ]]; then
                            log_push "$skill -> $t [$s]: would update symlink"
                            updated=$((updated + 1))
                        else
                            rm "$target_skill_path"
                            if ln -s "$real_src" "$target_skill_path"; then
                                log_push "$skill -> $t [$s]: symlink updated"
                                updated=$((updated + 1))
                            else
                                log_error "$skill -> $t [$s]: update failed"
                                failed=$((failed + 1))
                            fi
                        fi
                        continue
                    fi
                fi

                # Target has correct symlink or real file -> skip
                skipped=$((skipped + 1))
            done
        done
    done

    echo ""
    print_separator
    printf "  Pulled:   ${CYAN}%d${NC}\n" "$pulled"
    printf "  Pushed:   ${CYAN}%d${NC}\n" "$pushed"
    printf "  Updated:  ${MAGENTA}%d${NC}\n" "$updated"
    printf "  Skipped:  ${YELLOW}%d${NC}\n" "$skipped"
    printf "  Failed:   ${RED}%d${NC}\n" "$failed"
    print_separator
    echo ""

    [[ $failed -gt 0 ]] && return 1 || return 0
}

cmd_version() {
    printf "%s\n" "$VERSION"
}

# --- Main ----------------------------------------------------------------

usage() {
    cat <<EOF
skills-sync - Sync skills across AI coding tools via symlinks

Commands:
  config    Configure which tools to sync (required first run)
  sync      Bidirectional sync: pull into center + push from center
  pull      Pull missing skills into target tool from others
  push      Push skills from source tool to others
  unlink    Remove symlinks pointing from source to targets
  status    Show symlink & presence status across tools
  list      List skills with symlink indicators
  version   Show skills-sync version

Config:
  $(basename "$0") config                        # Interactive setup
  $(basename "$0") config --set claude,codex     # Quick setup
  $(basename "$0") config --show                 # Show current config
  $(basename "$0") config --add codebuddy        # Add a tool
  $(basename "$0") config --remove codebuddy     # Remove a tool

  Config file: ~/.agents/sync-skills.json
  'agents' is auto-detected from ~/.agents/skills/ (global only)

Known tools: cline, codebuddy, cursor, gemini, github, lingma,
             opencode, qwen, trae, claude, codex, qoder

Scopes:
  global   User-level skills
  project  Project-level skills
  both     Both levels (default)

Usage:
  sync-skills.sh sync   --tool <center> [--scope ...] [--skill <name>] [--dry-run]
  sync-skills.sh pull   --to <tool> [--from <tool|all>] [--scope ...] [--skill <name>] [--dry-run]
  sync-skills.sh push   --from <tool> [--to <tool|all>] [--scope ...] [--skill <name>] [--dry-run]
  sync-skills.sh unlink --from <tool> [--to <tool|all>] [--scope ...] [--skill <name>] [--dry-run]
  sync-skills.sh status [--scope global|project|both]
  sync-skills.sh list   [--scope global|project|both] [--tool <tool|all>]
  sync-skills.sh version

Behavior:
  - Target has real file  -> SKIP (never overwrite)
  - Target is correct symlink -> SKIP (already good)
  - Target is wrong symlink -> UPDATE to correct source
  - Target doesn't exist -> CREATE symlink

Examples:
  # First time setup
  $(basename "$0") config --set claude,codex,qoder

  # Bidirectional sync with claude as center
  $(basename "$0") sync --tool claude

  # Pull all missing skills into claude
  $(basename "$0") pull --to claude --scope global

  # Pull only from agents
  $(basename "$0") pull --to claude --from agents --scope global

  # Push claude's skills to all others
  $(basename "$0") push --from claude --scope global

  # Check status
  $(basename "$0") status
EOF
}

# Parse arguments
COMMAND=""
CONFIG_ACTION=""
CONFIG_VALUE=""
FROM=""
TO=""
SCOPE="both"
SKILL=""
DRY_RUN=false
LIST_TOOL="all"
SYNC_TOOL=""
PROJECT_DIR=""

while [[ $# -gt 0 ]]; do
    case "$1" in
        config|sync|pull|push|unlink|status|list|version)
            COMMAND="$1"
            shift
            ;;
        --set|--add|--remove|--show)
            # Config sub-args: attach to COMMAND as config action
            if [[ -z "$COMMAND" || "$COMMAND" == "config" ]]; then
                COMMAND="config"
                CONFIG_ACTION="$1"
                shift
                # Get value for --set/--add/--remove
                if [[ "$CONFIG_ACTION" != "--show" && $# -gt 0 && "$1" != -* ]]; then
                    CONFIG_VALUE="$1"
                    shift
                fi
            else
                log_error "Unexpected $1 for command '$COMMAND'"
                exit 1
            fi
            ;;
        --from)
            FROM="$2"
            shift 2
            ;;
        --to)
            TO="$2"
            shift 2
            ;;
        --scope)
            SCOPE="$2"
            shift 2
            ;;
        --skill)
            SKILL="$2"
            shift 2
            ;;
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --tool)
            if [[ "$COMMAND" == "list" ]]; then
                LIST_TOOL="$2"
            else
                SYNC_TOOL="$2"
            fi
            shift 2
            ;;
        --project-dir)
            PROJECT_DIR="$2"
            shift 2
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            usage
            exit 1
            ;;
    esac
done

# Auto-detect project directory
if [[ -z "$PROJECT_DIR" ]]; then
    PROJECT_DIR="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
fi

case "$COMMAND" in
    config)
        cmd_config "$CONFIG_ACTION" "$CONFIG_VALUE"
        ;;
    sync)
        require_config
        if [[ -z "$SYNC_TOOL" ]]; then log_error "--tool is required for sync"; exit 1; fi
        cmd_sync "$SYNC_TOOL" "$SCOPE" "$SKILL" "$DRY_RUN" "$PROJECT_DIR"
        ;;
    pull)
        require_config
        if [[ -z "$TO" ]]; then log_error "--to is required for pull"; exit 1; fi
        FROM="${FROM:-all}"
        cmd_pull "$TO" "$FROM" "$SCOPE" "$SKILL" "$DRY_RUN" "$PROJECT_DIR"
        ;;
    push)
        require_config
        if [[ -z "$FROM" ]]; then log_error "--from is required for push"; exit 1; fi
        TO="${TO:-all}"
        cmd_push "$FROM" "$TO" "$SCOPE" "$SKILL" "$DRY_RUN" "$PROJECT_DIR"
        ;;
    unlink)
        require_config
        if [[ -z "$FROM" ]]; then log_error "--from is required for unlink"; exit 1; fi
        TO="${TO:-all}"
        cmd_unlink "$FROM" "$TO" "$SCOPE" "$SKILL" "$DRY_RUN" "$PROJECT_DIR"
        ;;
    status)
        require_config
        cmd_status "$SCOPE" "$PROJECT_DIR"
        ;;
    list)
        require_config
        cmd_list "$SCOPE" "$LIST_TOOL" "$PROJECT_DIR"
        ;;
    version)
        cmd_version
        ;;
    *)
        usage
        exit 1
        ;;
esac
