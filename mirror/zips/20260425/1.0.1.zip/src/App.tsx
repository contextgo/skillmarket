import { RenewalDashboard } from './components/RenewalDashboard'

function App() {
  return <RenewalDashboard />
}

export default App
