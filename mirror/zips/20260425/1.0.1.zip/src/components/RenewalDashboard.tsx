import { useState, useEffect } from 'react';

export interface RenewalRecord {
  id: string;
  长编码: string;
  月份: number;
  机构: string;
  分区: string;
  客户编号: string;
  客户名称: string;
  年总应续金额: number;
  客户规模分段: string;
  客户成功经理: string;
  客户成功经理部门: string;
  销售人员: string;
  销售部门: string;
  产品线: string;
  续签状态: string;
  应签时间: string;
  应续金额: number;
  续约意向: string;
  预计基础续费金额: number | null;
  缩减延期流失原因: string;
  跟进时间: string;
}

interface EditModalProps {
  record: RenewalRecord;
  onSave: (record: RenewalRecord) => void;
  onClose: () => void;
}

export function EditModal({ record, onSave, onClose }: EditModalProps) {
  const [formData, setFormData] = useState<RenewalRecord>(record);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-gradient-to-r from-blue-600 to-blue-700 text-white px-6 py-4 flex justify-between items-center">
          <h2 className="text-xl font-bold">编辑客户信息</h2>
          <button onClick={onClose} className="text-white/80 hover:text-white transition-colors">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="bg-blue-50 rounded-lg p-4 mb-4">
            <p className="font-semibold text-blue-900">{record.客户名称}</p>
            <p className="text-sm text-blue-600">客户编号: {record.客户编号}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">产品线（可自定义）</label>
              <input
                type="text"
                value={formData.产品线}
                onChange={(e) => setFormData({...formData, 产品线: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="请输入产品线名称"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">月份</label>
              <select
                value={formData.月份}
                onChange={(e) => setFormData({...formData, 月份: parseInt(e.target.value)})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                {[3,4,5,6,7,8,9,10,11,12].map(m => (
                  <option key={m} value={m}>{m}月</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">续签状态</label>
              <select
                value={formData.续签状态}
                onChange={(e) => setFormData({...formData, 续签状态: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="已续费">已续费</option>
                <option value="待续签">待续签</option>
                <option value="续签中">续签中</option>
                <option value="已流失">已流失</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">预计基础续费金额</label>
              <input
                type="number"
                step="0.01"
                value={formData.预计基础续费金额 ?? ''}
                onChange={(e) => setFormData({...formData, 预计基础续费金额: e.target.value ? parseFloat(e.target.value) : null})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="请输入金额"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">跟进时间</label>
              <input
                type="date"
                value={formData.跟进时间}
                onChange={(e) => setFormData({...formData, 跟进时间: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">续约意向</label>
              <select
                value={formData.续约意向}
                onChange={(e) => setFormData({...formData, 续约意向: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="预计按时续费">预计按时续费</option>
                <option value="续约存疑">续约存疑</option>
                <option value="预计流失">预计流失</option>
                <option value="已流失">已流失</option>
              </select>
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">缩减/延期/流失原因</label>
              <textarea
                value={formData.缩减延期流失原因}
                onChange={(e) => setFormData({...formData, 缩减延期流失原因: e.target.value})}
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="请输入原因..."
              />
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
            >
              取消
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              保存
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

const productLineColors: Record<string, string> = {};

// 动态生成产品线颜色
const colorPalette = [
  'from-purple-500 to-purple-700',
  'from-blue-500 to-blue-700',
  'from-cyan-500 to-cyan-700',
  'from-orange-500 to-orange-700',
  'from-green-500 to-green-700',
  'from-pink-500 to-pink-700',
  'from-indigo-500 to-indigo-700',
  'from-teal-500 to-teal-700',
  'from-red-500 to-red-700',
  'from-yellow-500 to-yellow-700',
];

const colorBgPalette = [
  'bg-purple-100 text-purple-800',
  'bg-blue-100 text-blue-800',
  'bg-cyan-100 text-cyan-800',
  'bg-orange-100 text-orange-800',
  'bg-green-100 text-green-800',
  'bg-pink-100 text-pink-800',
  'bg-indigo-100 text-indigo-800',
  'bg-teal-100 text-teal-800',
  'bg-red-100 text-red-800',
  'bg-yellow-100 text-yellow-800',
];

// 根据产品线名称生成一致的颜色索引
const getColorIndex = (name: string): number => {
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = ((hash << 5) - hash) + name.charCodeAt(i);
    hash = hash & hash;
  }
  return Math.abs(hash) % colorPalette.length;
};

export function RenewalDashboard() {
  const [data, setData] = useState<RenewalRecord[]>([]);
  const [editingRecord, setEditingRecord] = useState<RenewalRecord | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [intentionFilter, setIntentionFilter] = useState('all');
  const [productLineFilter, setProductLineFilter] = useState('all');
  const [monthFilter, setMonthFilter] = useState('all');
  const [selectedProductLine, setSelectedProductLine] = useState<string | null>(null);

  useEffect(() => {
    const stored = localStorage.getItem('renewalData');
    if (stored) {
      setData(JSON.parse(stored));
    } else {
      const initialData: RenewalRecord[] = [
  { id: '1', 长编码: '大连KH-20210304-000333', 月份: 3, 机构: '大连', 分区: '北2区', 客户编号: 'KH-20210304-000333', 客户名称: '亚惠美食有限公司', 年总应续金额: 308000, 客户规模分段: '30~100万', 客户成功经理: '田旭财', 客户成功经理部门: '客户成功业务部', 销售人员: '沈友军', 销售部门: '大连分公司', 产品线: '金蝶云星瀚', 续签状态: '已续费', 应签时间: '2026-03-30', 应续金额: 256256, 续约意向: '预计按时续费', 预计基础续费金额: 256256, 缩减延期流失原因: '', 跟进时间: '' },
  { id: '2', 长编码: '大连KH-20210304-000333', 月份: 3, 机构: '大连', 分区: '北2区', 客户编号: 'KH-20210304-000333', 客户名称: '亚惠美食有限公司', 年总应续金额: 308000, 客户规模分段: '30~100万', 客户成功经理: '田旭财', 客户成功经理部门: '客户成功业务部', 销售人员: '沈友军', 销售部门: '大连分公司', 产品线: '金蝶云苍穹', 续签状态: '已续费', 应签时间: '2026-03-30', 应续金额: 51744, 续约意向: '预计按时续费', 预计基础续费金额: 51744, 缩减延期流失原因: '', 跟进时间: '' },
  { id: '3', 长编码: '大连KH-20210122-092017', 月份: 4, 机构: '大连', 分区: '北2区', 客户编号: 'KH-20210122-092017', 客户名称: '冰山松洋压缩机（大连）有限公司', 年总应续金额: 365465, 客户规模分段: '30~100万', 客户成功经理: '于德鹏', 客户成功经理部门: '客户成功业务部', 销售人员: '陈立鹏', 销售部门: '国资与行业客户部', 产品线: 'EAS Cloud', 续签状态: '已续费', 应签时间: '2026-04-11', 应续金额: 5829.25, 续约意向: '预计按时续费', 预计基础续费金额: 5829.25, 缩减延期流失原因: '', 跟进时间: '' },
  { id: '4', 长编码: '大连KH-20210122-092017', 月份: 4, 机构: '大连', 分区: '北2区', 客户编号: 'KH-20210122-092017', 客户名称: '冰山松洋压缩机（大连）有限公司', 年总应续金额: 365465, 客户规模分段: '30~100万', 客户成功经理: '于德鹏', 客户成功经理部门: '客户成功业务部', 销售人员: '陈立鹏', 销售部门: '国资与行业客户部', 产品线: 's-HR', 续签状态: '已续费', 应签时间: '2026-04-11', 应续金额: 63580.75, 续约意向: '预计按时续费', 预计基础续费金额: 63580.75, 缩减延期流失原因: '', 跟进时间: '' },
  { id: '5', 长编码: '大连KH-20210122-092017', 月份: 4, 机构: '大连', 分区: '北2区', 客户编号: 'KH-20210122-092017', 客户名称: '冰山松洋压缩机（大连）有限公司', 年总应续金额: 365465, 客户规模分段: '30~100万', 客户成功经理: '于德鹏', 客户成功经理部门: '客户成功业务部', 销售人员: '陈立鹏', 销售部门: '国资与行业客户部', 产品线: '金蝶云星空', 续签状态: '已续费', 应签时间: '2026-04-11', 应续金额: 296055, 续约意向: '预计按时续费', 预计基础续费金额: 296055, 缩减延期流失原因: '', 跟进时间: '' },
  { id: '6', 长编码: '大连KH-20220610-000247', 月份: 4, 机构: '大连', 分区: '北2区', 客户编号: 'KH-20220610-000247', 客户名称: '冰山松洋制冷（大连）有限公司', 年总应续金额: 422044.58, 客户规模分段: '30~100万', 客户成功经理: '于德鹏', 客户成功经理部门: '客户成功业务部', 销售人员: '王健', 销售部门: '客户销售部', 产品线: '金蝶云星空', 续签状态: '已续费', 应签时间: '2026-04-09', 应续金额: 422044.58, 续约意向: '预计按时续费', 预计基础续费金额: 422044.58, 缩减延期流失原因: '', 跟进时间: '' },
  { id: '7', 长编码: '大连KH-20210205-000056', 月份: 5, 机构: '大连', 分区: '北2区', 客户编号: 'KH-20210205-000056', 客户名称: '大连农渔产业集团有限公司', 年总应续金额: 761986.79, 客户规模分段: '30~100万', 客户成功经理: '文德超', 客户成功经理部门: '客户成功业务部', 销售人员: '毕小萍', 销售部门: '国资与行业客户部', 产品线: '金蝶云星瀚', 续签状态: '待续签', 应签时间: '2026-05-10', 应续金额: 665560.77, 续约意向: '预计按时续费', 预计基础续费金额: 665560.77, 缩减延期流失原因: '', 跟进时间: '' },
  { id: '8', 长编码: '大连KH-20210122-076959', 月份: 5, 机构: '大连', 分区: '北2区', 客户编号: 'KH-20210122-076959', 客户名称: '大连连城数控机器股份有限公司', 年总应续金额: 650280.12, 客户规模分段: '30~100万', 客户成功经理: '田旭财', 客户成功经理部门: '客户成功业务部', 销售人员: '李永刚', 销售部门: '客户成功业务部', 产品线: '金蝶云星空', 续签状态: '待续签', 应签时间: '2026-05-16', 应续金额: 423480.12, 续约意向: '预计按时续费', 预计基础续费金额: 423480.12, 缩减延期流失原因: '', 跟进时间: '' },
  { id: '9', 长编码: '大连KH-20210122-075768', 月份: 5, 机构: '大连', 分区: '北2区', 客户编号: 'KH-20210122-075768', 客户名称: '中升（大连）集团有限公司', 年总应续金额: 553540, 客户规模分段: '30~100万', 客户成功经理: '文德超', 客户成功经理部门: '客户成功业务部', 销售人员: '吕友', 销售部门: '国资与行业客户部', 产品线: '金蝶云苍穹', 续签状态: '待续签', 应签时间: '2026-05-13', 应续金额: 73740, 续约意向: '预计流失', 预计基础续费金额: null, 缩减延期流失原因: '', 跟进时间: '' },
  { id: '10', 长编码: '大连KH-20210205-000056', 月份: 5, 机构: '大连', 分区: '北2区', 客户编号: 'KH-20210205-000056', 客户名称: '大连农渔产业集团有限公司', 年总应续金额: 761986.79, 客户规模分段: '30~100万', 客户成功经理: '文德超', 客户成功经理部门: '客户成功业务部', 销售人员: '毕小萍', 销售部门: '国资与行业客户部', 产品线: '金蝶云苍穹', 续签状态: '待续签', 应签时间: '2026-05-10', 应续金额: 96426.02, 续约意向: '预计按时续费', 预计基础续费金额: 96426.02, 缩减延期流失原因: '', 跟进时间: '' },
  { id: '11', 长编码: '大连KH-20210122-075768', 月份: 7, 机构: '大连', 分区: '北2区', 客户编号: 'KH-20210122-075768', 客户名称: '中升（大连）集团有限公司', 年总应续金额: 553540, 客户规模分段: '30~100万', 客户成功经理: '文德超', 客户成功经理部门: '客户成功业务部', 销售人员: '吕友', 销售部门: '国资与行业客户部', 产品线: '金蝶云星瀚', 续签状态: '待续签', 应签时间: '2026-07-14', 应续金额: 79800, 续约意向: '预计流失', 预计基础续费金额: null, 缩减延期流失原因: '', 跟进时间: '' },
  { id: '12', 长编码: '大连KH-20210122-076959', 月份: 8, 机构: '大连', 分区: '北2区', 客户编号: 'KH-20210122-076959', 客户名称: '大连连城数控机器股份有限公司', 年总应续金额: 650280.12, 客户规模分段: '30~100万', 客户成功经理: '田旭财', 客户成功经理部门: '客户成功业务部', 销售人员: '李永刚', 销售部门: '客户成功业务部', 产品线: '金蝶云星瀚', 续签状态: '待续签', 应签时间: '2026-08-29', 应续金额: 73200, 续约意向: '预计按时续费', 预计基础续费金额: 73200, 缩减延期流失原因: '', 跟进时间: '' },
  { id: '13', 长编码: '大连KH-20210122-076959', 月份: 8, 机构: '大连', 分区: '北2区', 客户编号: 'KH-20210122-076959', 客户名称: '大连连城数控机器股份有限公司', 年总应续金额: 650280.12, 客户规模分段: '30~100万', 客户成功经理: '田旭财', 客户成功经理部门: '客户成功业务部', 销售人员: '李永刚', 销售部门: '大连客户销售一部', 产品线: '金蝶云苍穹', 续签状态: '待续签', 应签时间: '2026-08-29', 应续金额: 153600, 续约意向: '预计按时续费', 预计基础续费金额: 153600, 缩减延期流失原因: '', 跟进时间: '' },
  { id: '14', 长编码: '大连KH-20210122-075768', 月份: 9, 机构: '大连', 分区: '北2区', 客户编号: 'KH-20210122-075768', 客户名称: '中升（大连）集团有限公司', 年总应续金额: 553540, 客户规模分段: '30~100万', 客户成功经理: '文德超', 客户成功经理部门: '客户成功业务部', 销售人员: '吕友', 销售部门: '国资与行业客户部', 产品线: 's-HR', 续签状态: '应签已签', 应签时间: '2026-09-03', 应续金额: 400000, 续约意向: '预计按时续费', 预计基础续费金额: 200000, 缩减延期流失原因: '', 跟进时间: '' },
  { id: '15', 长编码: '大连KH-20210122-078046', 月份: 9, 机构: '大连', 分区: '北2区', 客户编号: 'KH-20210122-078046', 客户名称: '大连远东工具有限公司', 年总应续金额: 313090.21, 客户规模分段: '30~100万', 客户成功经理: '田旭财', 客户成功经理部门: '客户成功业务部', 销售人员: '毕小萍', 销售部门: '国资与行业客户部', 产品线: '金蝶云星空', 续签状态: '待续签', 应签时间: '2026-09-06', 应续金额: 313090.21, 续约意向: '预计按时续费', 预计基础续费金额: 313090.21, 缩减延期流失原因: '', 跟进时间: '' },
  { id: '16', 长编码: '大连KH-20230301-000039', 月份: 11, 机构: '大连', 分区: '北2区', 客户编号: 'KH-20230301-000039', 客户名称: '上海铭行汽车服务有限公司', 年总应续金额: 653069.02, 客户规模分段: '30~100万', 客户成功经理: '杨洋', 客户成功经理部门: '客户成功业务部', 销售人员: '秦港', 销售部门: '国资与行业客户部', 产品线: '金蝶云星瀚', 续签状态: '待续签', 应签时间: '2026-11-03', 应续金额: 450169.02, 续约意向: '预计按时续费', 预计基础续费金额: 450169.02, 缩减延期流失原因: '', 跟进时间: '' },
  { id: '17', 长编码: '大连KH-20230301-000039', 月份: 11, 机构: '大连', 分区: '北2区', 客户编号: 'KH-20230301-000039', 客户名称: '上海铭行汽车服务有限公司', 年总应续金额: 653069.02, 客户规模分段: '30~100万', 客户成功经理: '杨洋', 客户成功经理部门: '客户成功业务部', 销售人员: '秦港', 销售部门: '国资与行业客户部', 产品线: '金蝶云星瀚HR', 续签状态: '待续签', 应签时间: '2026-11-03', 应续金额: 133000, 续约意向: '预计按时续费', 预计基础续费金额: 133000, 缩减延期流失原因: '', 跟进时间: '' },
  { id: '18', 长编码: '大连KH-20230301-000039', 月份: 11, 机构: '大连', 分区: '北2区', 客户编号: 'KH-20230301-000039', 客户名称: '上海铭行汽车服务有限公司', 年总应续金额: 653069.02, 客户规模分段: '30~100万', 客户成功经理: '杨洋', 客户成功经理部门: '客户成功业务部', 销售人员: '秦港', 销售部门: '国资与行业客户部', 产品线: '金蝶云苍穹', 续签状态: '待续签', 应签时间: '2026-11-03', 应续金额: 69900, 续约意向: '预计按时续费', 预计基础续费金额: 69900, 缩减延期流失原因: '', 跟进时间: '' },
  { id: '19', 长编码: '大连KH-20210416-000231', 月份: 12, 机构: '大连', 分区: '北2区', 客户编号: 'KH-20210416-000231', 客户名称: '大连板桥医疗器械有限公司', 年总应续金额: 755162.37, 客户规模分段: '30~100万', 客户成功经理: '田旭财', 客户成功经理部门: '客户成功业务部', 销售人员: '李永刚', 销售部门: '客户成功业务部', 产品线: 'EAS Cloud', 续签状态: '待续签', 应签时间: '2026-12-31', 应续金额: 5599.97, 续约意向: '预计按时续费', 预计基础续费金额: 5599.97, 缩减延期流失原因: '', 跟进时间: '' },
  { id: '20', 长编码: '大连KH-20210416-000231', 月份: 12, 机构: '大连', 分区: '北2区', 客户编号: 'KH-20210416-000231', 客户名称: '大连板桥医疗器械有限公司', 年总应续金额: 755162.37, 客户规模分段: '30~100万', 客户成功经理: '田旭财', 客户成功经理部门: '客户成功业务部', 销售人员: '李永刚', 销售部门: '客户成功业务部', 产品线: 's-HR', 续签状态: '待续签', 应签时间: '2026-12-31', 应续金额: 58999.62, 续约意向: '预计按时续费', 预计基础续费金额: 58999.62, 缩减延期流失原因: '', 跟进时间: '' },
  { id: '21', 长编码: '大连KH-20210416-000231', 月份: 12, 机构: '大连', 分区: '北2区', 客户编号: 'KH-20210416-000231', 客户名称: '大连板桥医疗器械有限公司', 年总应续金额: 755162.37, 客户规模分段: '30~100万', 客户成功经理: '田旭财', 客户成功经理部门: '客户成功业务部', 销售人员: '李永刚', 销售部门: '客户成功业务部', 产品线: '金蝶云星瀚', 续签状态: '待续签', 应签时间: '2026-12-31', 应续金额: 457654.27, 续约意向: '预计按时续费', 预计基础续费金额: 457654.27, 缩减延期流失原因: '', 跟进时间: '' },
  { id: '22', 长编码: '大连KH-20210122-088443', 月份: 12, 机构: '大连', 分区: '北2区', 客户编号: 'KH-20210122-088443', 客户名称: '大连电瓷集团输变电材料有限公司', 年总应续金额: 316700, 客户规模分段: '30~100万', 客户成功经理: '田旭财', 客户成功经理部门: '客户成功业务部', 销售人员: '田旭财', 销售部门: '客户成功业务部', 产品线: '金蝶云星空', 续签状态: '待续签', 应签时间: '2026-12-31', 应续金额: 316700, 续约意向: '预计按时续费', 预计基础续费金额: 316700, 缩减延期流失原因: '', 跟进时间: '' },
  { id: '23', 长编码: '大连KH-20210416-000231', 月份: 12, 机构: '大连', 分区: '北2区', 客户编号: 'KH-20210416-000231', 客户名称: '大连板桥医疗器械有限公司', 年总应续金额: 755162.37, 客户规模分段: '30~100万', 客户成功经理: '田旭财', 客户成功经理部门: '客户成功业务部', 销售人员: '李永刚', 销售部门: '客户成功业务部', 产品线: '金蝶云星空', 续签状态: '待续签', 应签时间: '2026-12-31', 应续金额: 163908.95, 续约意向: '预计按时续费', 预计基础续费金额: 163908.95, 缩减延期流失原因: '', 跟进时间: '' },
  { id: '24', 长编码: '大连KH-20210416-000231', 月份: 12, 机构: '大连', 分区: '北2区', 客户编号: 'KH-20210416-000231', 客户名称: '大连板桥医疗器械有限公司', 年总应续金额: 755162.37, 客户规模分段: '30~100万', 客户成功经理: '田旭财', 客户成功经理部门: '客户成功业务部', 销售人员: '李永刚', 销售部门: '客户成功业务部', 产品线: '金蝶云苍穹', 续签状态: '待续签', 应签时间: '2026-12-31', 应续金额: 68999.56, 续约意向: '预计按时续费', 预计基础续费金额: 68999.56, 缩减延期流失原因: '', 跟进时间: '' },
];
      setData(initialData);
      localStorage.setItem('renewalData', JSON.stringify(initialData));
    }
  }, []);

  const handleSave = (updatedRecord: RenewalRecord) => {
    const newData = data.map(r => r.id === updatedRecord.id ? updatedRecord : r);
    setData(newData);
    localStorage.setItem('renewalData', JSON.stringify(newData));
    setEditingRecord(null);
  };

  const handleProductLineClick = (productLine: string) => {
    setSelectedProductLine(productLine);
    setProductLineFilter(productLine);
    setSearchTerm('');
    setStatusFilter('all');
    setIntentionFilter('all');
    setMonthFilter('all');
  };

  const handleBackToOverview = () => {
    setSelectedProductLine(null);
    setProductLineFilter('all');
  };

  const filteredData = data.filter(item => {
    const matchesSearch = item.客户名称.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.客户编号.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || item.续签状态 === statusFilter;
    const matchesIntention = intentionFilter === 'all' || item.续约意向 === intentionFilter;
    const matchesProductLine = productLineFilter === 'all' || item.产品线 === productLineFilter;
    const matchesMonth = monthFilter === 'all' || item.月份 === parseInt(monthFilter);
    return matchesSearch && matchesStatus && matchesIntention && matchesProductLine && matchesMonth;
  });

  const stats = {
    total: data.length,
    renewed: data.filter(d => d.续签状态 === '已续费').length,
    pending: data.filter(d => d.续签状态 === '待续签').length,
    atRisk: data.filter(d => d.续约意向 === '预计流失').length,
    totalAmount: data.reduce((sum, d) => sum + (d.预计基础续费金额 || 0), 0),
  };

  const productLineStats = data.reduce((acc, item) => {
    const line = item.产品线;
    if (!acc[line]) {
      acc[line] = { count: 0, renewed: 0, pending: 0, amount: 0 };
    }
    acc[line].count++;
    acc[line].renewed += item.续签状态 === '已续费' ? 1 : 0;
    acc[line].pending += item.续签状态 === '待续签' ? 1 : 0;
    acc[line].amount += item.预计基础续费金额 || 0;
    return acc;
  }, {} as Record<string, { count: number; renewed: number; pending: number; amount: number }>);

  const uniqueProductLines = [...new Set(data.map(d => d.产品线))];
  const uniqueMonths = [...new Set(data.map(d => d.月份))].sort((a, b) => a - b);

  const getStatusColor = (status: string) => {
    switch (status) {
      case '已续费': return 'bg-green-100 text-green-800';
      case '待续签': return 'bg-yellow-100 text-yellow-800';
      case '续签中': return 'bg-blue-100 text-blue-800';
      case '已流失': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getIntentionColor = (intention: string) => {
    switch (intention) {
      case '预计按时续费': return 'text-green-600';
      case '续约存疑': return 'text-yellow-600';
      case '预计流失': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-gradient-to-r from-blue-600 to-blue-800 text-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <h1 className="text-2xl font-bold">客户续签风险盘点看板</h1>
          <p className="text-blue-100 mt-1">大连2026年30万及以上客户续签管理</p>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6">
        {/* 概览统计 */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-white rounded-xl shadow p-5 border-l-4 border-blue-500">
            <p className="text-gray-500 text-sm">总客户数</p>
            <p className="text-3xl font-bold text-gray-800">{stats.total}</p>
          </div>
          <div className="bg-white rounded-xl shadow p-5 border-l-4 border-green-500">
            <p className="text-gray-500 text-sm">已续费</p>
            <p className="text-3xl font-bold text-green-600">{stats.renewed}</p>
          </div>
          <div className="bg-white rounded-xl shadow p-5 border-l-4 border-yellow-500">
            <p className="text-gray-500 text-sm">待续签</p>
            <p className="text-3xl font-bold text-yellow-600">{stats.pending}</p>
          </div>
          <div className="bg-white rounded-xl shadow p-5 border-l-4 border-red-500">
            <p className="text-gray-500 text-sm">预计流失</p>
            <p className="text-3xl font-bold text-red-600">{stats.atRisk}</p>
          </div>
        </div>

        {/* 产品线分析 - 点击穿透 */}
        <div className="mb-6">
          <h2 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
            <svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
            </svg>
            产品线分析（点击产品线查看明细）
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            {uniqueProductLines.map(line => {
              const stat = productLineStats[line] || { count: 0, renewed: 0, pending: 0, amount: 0 };
              const colorIndex = getColorIndex(line);
              const colors = colorPalette[colorIndex];
              const isSelected = selectedProductLine === line;
              return (
                <button
                  key={line}
                  onClick={() => handleProductLineClick(line)}
                  className={`bg-gradient-to-br ${colors} rounded-xl shadow-lg p-4 text-white text-left transition-all hover:scale-105 hover:shadow-xl ${isSelected ? 'ring-4 ring-white ring-offset-2' : ''}`}
                >
                  <p className="text-sm opacity-90">{line}</p>
                  <p className="text-2xl font-bold mt-1">{stat.count}</p>
                  <div className="flex justify-between text-xs mt-2 opacity-90">
                    <span>已续费: {stat.renewed}</span>
                    <span>待续签: {stat.pending}</span>
                  </div>
                  <p className="text-sm mt-2 font-medium">¥{stat.amount.toLocaleString()}</p>
                  <p className="text-xs mt-1 opacity-70">点击查看明细 →</p>
                </button>
              );
            })}
          </div>
        </div>

        {/* 明细表头 - 当选中产品线时显示 */}
        {selectedProductLine && (
          <div className="bg-gradient-to-r from-purple-600 to-blue-600 rounded-xl shadow p-4 mb-6 text-white flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button onClick={handleBackToOverview} className="p-1 hover:bg-white/20 rounded transition-colors">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              <div>
                <h3 className="text-xl font-bold">{selectedProductLine} 明细表</h3>
                <p className="text-sm opacity-80">共 {productLineStats[selectedProductLine]?.count || 0} 条记录</p>
              </div>
            </div>
            <button
              onClick={handleBackToOverview}
              className="px-4 py-2 bg-white/20 hover:bg-white/30 rounded-lg transition-colors text-sm"
            >
              返回概览
            </button>
          </div>
        )}

        {/* 筛选区域 */}
        <div className="bg-white rounded-xl shadow p-4 mb-6">
          <div className="flex flex-wrap gap-4">
            <div className="flex-1 min-w-[200px]">
              <input
                type="text"
                placeholder="搜索客户名称或编号..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
            <select
              value={productLineFilter}
              onChange={(e) => setProductLineFilter(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">全部产品线</option>
              {uniqueProductLines.map(line => (
                <option key={line} value={line}>{line}</option>
              ))}
            </select>
            <select
              value={monthFilter}
              onChange={(e) => setMonthFilter(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">全部月份</option>
              {uniqueMonths.map(m => (
                <option key={m} value={m}>{m}月</option>
              ))}
            </select>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">全部状态</option>
              <option value="已续费">已续费</option>
              <option value="待续签">待续签</option>
              <option value="续签中">续签中</option>
              <option value="已流失">已流失</option>
            </select>
            <select
              value={intentionFilter}
              onChange={(e) => setIntentionFilter(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">全部意向</option>
              <option value="预计按时续费">预计按时续费</option>
              <option value="续约存疑">续约存疑</option>
              <option value="预计流失">预计流失</option>
            </select>
          </div>
        </div>

        {/* 数据表格 */}
        <div className="bg-white rounded-xl shadow overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-100">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">客户名称</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">产品线</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">月份</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">续签状态</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">预计基础续费金额</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">跟进时间</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">续约意向</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">缩减/延期/流失原因</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">操作</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredData.map((item) => (
                  <tr key={item.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-4 py-3">
                      <p className="font-medium text-gray-900">{item.客户名称}</p>
                      <p className="text-xs text-gray-500">{item.客户编号}</p>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 rounded text-xs font-medium text-white ${colorBgPalette[getColorIndex(item.产品线)]}`}
                        style={{ backgroundColor: colorPalette[getColorIndex(item.产品线)].includes('purple') ? '#8B5CF6' :
                          colorPalette[getColorIndex(item.产品线)].includes('blue') ? '#3B82F6' :
                          colorPalette[getColorIndex(item.产品线)].includes('cyan') ? '#06B6D4' :
                          colorPalette[getColorIndex(item.产品线)].includes('orange') ? '#F97316' :
                          colorPalette[getColorIndex(item.产品线)].includes('green') ? '#22C55E' :
                          colorPalette[getColorIndex(item.产品线)].includes('pink') ? '#EC4899' :
                          colorPalette[getColorIndex(item.产品线)].includes('indigo') ? '#6366F1' :
                          colorPalette[getColorIndex(item.产品线)].includes('teal') ? '#14B8A6' :
                          colorPalette[getColorIndex(item.产品线)].includes('red') ? '#EF4444' : '#EAB308' }}>
                        {item.产品线}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-gray-600">{item.月份}月</td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(item.续签状态)}`}>
                        {item.续签状态}
                      </span>
                    </td>
                    <td className="px-4 py-3 font-medium text-gray-900">
                      {item.预计基础续费金额 ? `¥${item.预计基础续费金额.toLocaleString()}` : '-'}
                    </td>
                    <td className="px-4 py-3 text-gray-600">
                      {item.跟进时间 || '-'}
                    </td>
                    <td className="px-4 py-3">
                      <span className={`font-medium ${getIntentionColor(item.续约意向)}`}>
                        {item.续约意向}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-gray-600 text-sm max-w-xs truncate">
                      {item.缩减延期流失原因 || '-'}
                    </td>
                    <td className="px-4 py-3">
                      <button
                        onClick={() => setEditingRecord(item)}
                        className="text-blue-600 hover:text-blue-800 font-medium text-sm flex items-center gap-1"
                      >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                        </svg>
                        编辑
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {filteredData.length === 0 && (
            <div className="p-8 text-center text-gray-500">
              没有找到匹配的客户记录
            </div>
          )}
        </div>
      </main>

      {editingRecord && (
        <EditModal
          record={editingRecord}
          onSave={handleSave}
          onClose={() => setEditingRecord(null)}
        />
      )}
    </div>
  );
}
