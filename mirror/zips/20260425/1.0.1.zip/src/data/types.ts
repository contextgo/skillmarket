export interface RenewalRecord {
  id: string;
  longCode: string;
  month: number;
  institution: string;
  district: string;
  customerCode: string;
  customerName: string;
  annualRenewalAmount: number;
  customerSizeSegment: string;
  customerSuccessManager: string;
  customerSuccessDept: string;
  salesPerson: string;
  salesDept: string;
  productLine: string;
  renewalStatus: '已续费' | '待续签' | '已流失' | '已延期' | '续签中';
  dueDate: string;
  renewalAmount: number;
  renewalIntention: '预计按时续费' | '预计流失' | '预计延期' | '预计缩减' | '待确认';
  estimatedBaseRenewalAmount: number;
  reason: string;
  followUpTime: string;
}
