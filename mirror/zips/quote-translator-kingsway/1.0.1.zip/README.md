# quote-translator - 报价单翻译器

> 保留原始样式，仅翻译文字内容 - v2.0.0

---

## 🚀 快速开始

### 方式 1：直接告诉 AI（最简单）

直接告诉我文件路径和目标语言：

> "把 C:\Users\...\quote.xlsx 翻译成日语"
> "翻译这个 Excel 报价单为西班牙语"

### 方式 2：使用命令行

```bash
# 翻译 Excel 报价单为日语
python scripts/translate_quote.py quotation.xlsx -l ja

# 翻译 HTML 报价单为西班牙语
python scripts/translate_quote.py quote.html -l es

# 翻译 Word 报价单为法语
python scripts/translate_quote.py quote.docx -l fr

# 指定输出路径
python scripts/translate_quote.py quote.xlsx -l de -o german_quote.xlsx

# 使用自定义翻译词库
python scripts/translate_quote.py quote.xlsx -l ja -c my_translations.json
```

---

## 📋 支持的语言

| 代码 | 语言 | 代码 | 语言 |
|------|------|------|------|
| `zh` | 中文 | `en` | 英语 |
| `es` | 西班牙语 | `hi` | 印地语 |
| `ar` | 阿拉伯语 | `fr` | 法语 |
| `ru` | 俄语 | `pt` | 葡萄牙语 |
| `de` | 德语 | `ja` | 日语 |
| `ko` | 韩语 | | |

---

## 📁 支持的文件格式

| 格式 | 扩展名 | 保留内容 |
|------|--------|----------|
| **Excel** | `.xlsx`, `.xlsm`, `.xls` | ✅ 样式、公式、格式、合并单元格、条件格式 |
| **HTML** | `.html`, `.htm` | ✅ CSS 样式、布局、字体、颜色 |
| **Word** | `.docx` | ✅ 字体、颜色、表格、段落格式 |

---

## ✨ v2.0.0 新特性

### ✅ 无需外部 API
- 内置翻译词库，开箱即用
- 不依赖网络，离线可用
- 无 API 调用限制

### ✅ 智能文本识别
- 自动跳过网址、邮箱、产品编号
- 跳过全大写的缩写和代码
- 跳过纯数字和过短文本

### ✅ 长文本翻译
- 支持产品描述、公司介绍等长文本
- 按行业/场景预置翻译模板
- 保持语义准确

### ✅ 自定义词库
- 支持 JSON 格式自定义翻译
- 可为特定客户/产品定制
- 优先使用自定义翻译

---

## 🎨 自定义翻译词库

创建 `my_translations.json`：

```json
{
  "ja": {
    "Charms": "チャーム",
    "Stainless steel Charms": "ステンレススチールチャーム",
    "Contact us for more Collection": "その他のコレクションについてはお問い合わせください"
  },
  "es": {
    "Charms": "Dijes",
    "Stainless steel Charms": "Dijes de acero inoxidable"
  }
}
```

使用：
```bash
python scripts/translate_quote.py quote.xlsx -l ja -c my_translations.json
```

---

## 📦 依赖安装

```bash
pip install openpyxl beautifulsoup4 lxml python-docx python-dotenv
```

---

## 📝 使用案例

### 案例 1：珠宝报价单多语言版本

```bash
# 生成中文版
python scripts/translate_quote.py dg1688_template_quote.xlsx -l zh

# 生成日语版
python scripts/translate_quote.py dg1688_template_quote.xlsx -l ja

# 生成西班牙语版
python scripts/translate_quote.py dg1688_template_quote.xlsx -l es
```

### 案例 2：阿拉伯语报价单（RTL 布局）

```bash
python scripts/translate_quote.py quotation.html -l ar
```

输出自动添加 `dir="rtl"` 属性，文字从右到左排列。

---

## ⚠️ 注意事项

### ✅ 适合的场景
- 报价单、产品目录、价格表
- 包含产品描述、公司介绍的文档
- 需要保留原格式的正式文件

### ⚠️ 限制
- **图片中的文字不翻译** - 仅翻译文本内容
- **复杂表格建议校对** - 翻译后建议人工检查
- **专业术语建议定制词库** - 行业特定术语添加到自定义词库

---

## 🔄 版本历史

### v2.0.0 (2026-03-31)
- ✅ 重构为直接翻译模式，无需外部 API
- ✅ 支持 Excel 格式（.xlsx, .xlsm, .xls）
- ✅ 支持自定义翻译词库
- ✅ 优化文本识别逻辑
- ✅ 内置长文本翻译模板

### v1.0.0 (2026-03-31)
- 初始版本
- 依赖 DeepL/Google Translate API

---

## 📍 技能位置

```
C:\Users\caizheyu\.openclaw\workspace\skills\quote-translator\
```

---

**创建时间**：2026-03-31  
**版本**：v2.0.0  
**作者**：薯条 🍟
