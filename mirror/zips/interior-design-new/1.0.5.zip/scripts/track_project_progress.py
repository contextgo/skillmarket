#!/usr/bin/env python3
"""
项目进度追踪脚本 v2.2.0
管理项目各阶段进度，支持延期预警

用法示例：
    python track_project_progress.py --action create --project_name "李府雅居" --start_date 2024-02-01
    python track_project_progress.py --action report --project ./project.json
    python track_project_progress.py -a query -n "李府雅居" -o status.json
"""

import argparse
import json
import os
import sys
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional

class ProjectProgressTracker:
    """项目进度追踪器 v2.2.0"""
    
    def __init__(self):
        # 默认项目阶段
        self.default_phases = {
            "设计阶段": {
                "duration": 14,
                "tasks": [
                    "客户需求沟通",
                    "现场量房",
                    "平面方案设计",
                    "平面方案确认",
                    "效果图设计",
                    "效果图确认",
                    "施工图设计",
                    "施工图审核",
                    "预算编制",
                    "合同签订"
                ]
            },
            "施工准备": {
                "duration": 7,
                "tasks": [
                    "物业报建",
                    "材料采购",
                    "施工队进场",
                    "现场交底",
                    "成品保护"
                ]
            },
            "拆除工程": {
                "duration": 5,
                "tasks": [
                    "墙体拆除",
                    "门窗拆除",
                    "地面拆除",
                    "垃圾清运"
                ]
            },
            "水电工程": {
                "duration": 7,
                "tasks": [
                    "水电定位",
                    "开槽布管",
                    "水路改造",
                    "电路改造",
                    "水电验收"
                ]
            },
            "泥瓦工程": {
                "duration": 10,
                "tasks": [
                    "砌墙抹灰",
                    "防水处理",
                    "闭水试验",
                    "墙地砖铺贴",
                    "地面找平"
                ]
            },
            "木工工程": {
                "duration": 10,
                "tasks": [
                    "天花吊顶",
                    "背景墙基层",
                    "定制柜体",
                    "门套窗套"
                ]
            },
            "油漆工程": {
                "duration": 10,
                "tasks": [
                    "墙面基层处理",
                    "腻子批刮",
                    "打磨",
                    "底漆涂刷",
                    "面漆涂刷"
                ]
            },
            "安装工程": {
                "duration": 7,
                "tasks": [
                    "地板安装",
                    "开关插座安装",
                    "灯具安装",
                    "洁具安装",
                    "五金安装",
                    "门窗安装"
                ]
            },
            "收尾阶段": {
                "duration": 7,
                "tasks": [
                    "开荒保洁",
                    "家具进场",
                    "软装布置",
                    "家电安装",
                    "整体调试",
                    "竣工验收",
                    "通风散味"
                ]
            }
        }
    
    def validate_inputs(self, args: argparse.Namespace) -> tuple[bool, str]:
        """验证输入"""
        if args.action == "create":
            if not args.project_name:
                return False, "创建项目时必须指定项目名称 (--project-name)"
            if args.start_date:
                try:
                    datetime.strptime(args.start_date, "%Y-%m-%d")
                except ValueError:
                    return False, f"日期格式错误，应为 YYYY-MM-DD，当前: {args.start_date}"
        elif args.action in ["update", "check", "report"]:
            if not args.project_file and not args.project:
                return False, f"操作 {args.action} 需要指定项目文件 (--project)"
        return True, ""
    
    def create_project(self, args: argparse.Namespace) -> Dict[str, Any]:
        """创建新项目"""
        start_date = datetime.strptime(args.start_date or datetime.now().strftime("%Y-%m-%d"), "%Y-%m-%d")
        
        project = {
            "project_info": {
                "project_name": args.project_name,
                "project_address": args.address or "",
                "client_name": args.client or "",
                "designer": args.designer or "",
                "project_manager": args.project_manager or "",
                "start_date": start_date.strftime("%Y-%m-%d"),
                "status": "筹备中",
                "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            },
            "phases": {},
            "total_duration": 0
        }
        
        # 计算各阶段计划日期
        current_date = start_date
        
        for phase_name, phase_config in self.default_phases.items():
            duration = phase_config["duration"]
            phase_start = current_date
            phase_end = current_date + timedelta(days=duration - 1)
            
            tasks = {}
            task_duration = max(1, duration // len(phase_config["tasks"]))
            task_date = phase_start
            
            for task_name in phase_config["tasks"]:
                task_end = task_date + timedelta(days=task_duration - 1)
                tasks[task_name] = {
                    "status": "待开始",
                    "planned_start": task_date.strftime("%Y-%m-%d"),
                    "planned_end": task_end.strftime("%Y-%m-%d"),
                    "actual_start": "",
                    "actual_end": "",
                    "progress": 0,
                    "notes": ""
                }
                task_date = task_end + timedelta(days=1)
            
            project["phases"][phase_name] = {
                "planned_start": phase_start.strftime("%Y-%m-%d"),
                "planned_end": phase_end.strftime("%Y-%m-%d"),
                "duration": duration,
                "actual_start": "",
                "actual_end": "",
                "status": "待开始",
                "progress": 0,
                "tasks": tasks
            }
            
            project["total_duration"] += duration
            current_date = phase_end + timedelta(days=1)
        
        # 计算计划竣工日期
        project["project_info"]["planned_completion"] = (
            start_date + timedelta(days=project["total_duration"] - 1)
        ).strftime("%Y-%m-%d")
        
        return project
    
    def update_progress(self, project: Dict, args: argparse.Namespace) -> Dict[str, Any]:
        """更新进度"""
        phase_name = args.phase
        task_name = args.task
        status = args.status
        progress = args.progress
        notes = args.notes
        
        if phase_name and phase_name not in project["phases"]:
            return {"error": f"阶段 '{phase_name}' 不存在", "valid_phases": list(project["phases"].keys())}
        
        if phase_name:
            phase = project["phases"][phase_name]
            
            if task_name:
                if task_name not in phase["tasks"]:
                    return {"error": f"任务 '{task_name}' 不存在", "valid_tasks": list(phase["tasks"].keys())}
                
                task = phase["tasks"][task_name]
                task["status"] = status or task["status"]
                task["progress"] = progress if progress is not None else task["progress"]
                task["notes"] = notes if notes else task["notes"]
                
                if status == "进行中" and not task["actual_start"]:
                    task["actual_start"] = datetime.now().strftime("%Y-%m-%d")
                elif status == "已完成":
                    task["actual_end"] = datetime.now().strftime("%Y-%m-%d")
                    task["progress"] = 100
            else:
                phase["status"] = status or phase["status"]
                phase["progress"] = progress if progress is not None else phase["progress"]
                phase["notes"] = notes if notes else phase["notes"]
                
                if status == "进行中" and not phase["actual_start"]:
                    phase["actual_start"] = datetime.now().strftime("%Y-%m-%d")
                elif status == "已完成":
                    phase["actual_end"] = datetime.now().strftime("%Y-%m-%d")
                    phase["progress"] = 100
            
            # 重新计算阶段进度
            self._recalculate_phase_progress(phase)
            self._recalculate_project_status(project)
        
        return {"success": True, "message": f"已更新 {phase_name}" + (f" - {task_name}" if task_name else "")}
    
    def _recalculate_phase_progress(self, phase: Dict):
        """重新计算阶段进度"""
        tasks = phase["tasks"]
        completed = sum(1 for t in tasks.values() if t["status"] == "已完成")
        total = len(tasks)
        phase["progress"] = int(completed / total * 100) if total > 0 else 0
    
    def _recalculate_project_status(self, project: Dict):
        """重新计算项目状态"""
        phases = project["phases"]
        
        all_completed = all(p["status"] == "已完成" for p in phases.values())
        if all_completed:
            project["project_info"]["status"] = "已完成"
            return
        
        any_in_progress = any(p["status"] == "进行中" for p in phases.values())
        if any_in_progress:
            project["project_info"]["status"] = "施工中"
        
        # 计算总体进度
        total_progress = sum(p["progress"] for p in phases.values()) / len(phases)
        project["overall_progress"] = round(total_progress, 1)
    
    def check_delays(self, project: Dict) -> Dict[str, Any]:
        """检查延期情况"""
        today = datetime.now()
        delays = []
        warnings = []
        
        for phase_name, phase in project["phases"].items():
            planned_end = datetime.strptime(phase["planned_end"], "%Y-%m-%d")
            remaining_days = (planned_end - today).days
            
            if phase["status"] == "待开始" and remaining_days < 0:
                delays.append({
                    "phase": phase_name,
                    "type": "延期未开始",
                    "planned_end": phase["planned_end"],
                    "days_overdue": abs(remaining_days),
                    "severity": "严重"
                })
            elif phase["status"] == "进行中":
                if remaining_days < 0:
                    delays.append({
                        "phase": phase_name,
                        "type": "施工延期",
                        "planned_end": phase["planned_end"],
                        "days_overdue": abs(remaining_days),
                        "progress": f"{phase['progress']}%",
                        "severity": "严重" if remaining_days < -3 else "中等"
                    })
                elif remaining_days <= 3:
                    warnings.append({
                        "phase": phase_name,
                        "type": "即将到期",
                        "planned_end": phase["planned_end"],
                        "days_remaining": remaining_days,
                        "severity": "警告" if remaining_days <= 1 else "提醒"
                    })
        
        overall_status = "正常"
        if delays:
            overall_status = "延期"
        elif warnings:
            overall_status = "需关注"
        
        return {
            "check_date": today.strftime("%Y-%m-%d"),
            "overall_status": overall_status,
            "delays": delays,
            "warnings": warnings,
            "statistics": {
                "total_phases": len(project["phases"]),
                "completed_phases": sum(1 for p in project["phases"].values() if p["status"] == "已完成"),
                "in_progress_phases": sum(1 for p in project["phases"].values() if p["status"] == "进行中"),
                "delayed_phases": len(delays),
                "warning_phases": len(warnings)
            }
        }
    
    def generate_report(self, project: Dict) -> Dict[str, Any]:
        """生成进度报告"""
        delay_info = self.check_delays(project)
        
        report = {
            "report_info": {
                "project_name": project["project_info"]["project_name"],
                "report_date": datetime.now().strftime("%Y-%m-%d"),
                "overall_progress": project.get("overall_progress", 0)
            },
            "project_summary": {
                "start_date": project["project_info"]["start_date"],
                "planned_completion": project["project_info"].get("planned_completion", "未知"),
                "total_duration": project["total_duration"],
                "elapsed_days": (datetime.now() - datetime.strptime(
                    project["project_info"]["start_date"], "%Y-%m-%d")).days + 1,
                "status": project["project_info"]["status"]
            },
            "phase_details": [],
            "delay_analysis": delay_info,
            "recommendations": []
        }
        
        # 阶段详情
        for phase_name, phase in project["phases"].items():
            phase_report = {
                "phase": phase_name,
                "status": phase["status"],
                "progress": f"{phase['progress']}%",
                "planned": f"{phase['planned_start']} 至 {phase['planned_end']}",
                "actual": f"{phase['actual_start'] or '未开始'} 至 {phase['actual_end'] or '进行中'}",
                "completed_tasks": sum(1 for t in phase["tasks"].values() if t["status"] == "已完成"),
                "total_tasks": len(phase["tasks"]),
                "pending_tasks": [
                    t for t, info in phase["tasks"].items() 
                    if info["status"] in ["待开始", "进行中"]
                ]
            }
            report["phase_details"].append(phase_report)
        
        # 建议
        if delay_info["delays"]:
            report["recommendations"].append("⚠️ 存在延期阶段，建议立即调整施工计划")
        if delay_info["warnings"]:
            report["recommendations"].append("⚡ 多个阶段即将到期，提前协调资源")
        if report["project_summary"]["elapsed_days"] < project["total_duration"] * 0.3:
            report["recommendations"].append("📋 项目初期阶段，加强设计阶段管控")
        elif report["project_summary"]["elapsed_days"] > project["total_duration"] * 0.8:
            report["recommendations"].append("🎯 项目收尾阶段，注意细节验收")
        
        return report
    
    def format_report(self, report: Dict, format_type: str = "text") -> str:
        """格式化报告"""
        if format_type == "json":
            return json.dumps(report, ensure_ascii=False, indent=2)
        
        output = []
        output.append("=" * 70)
        output.append("📊 项目进度追踪报告")
        output.append("=" * 70)
        
        info = report["report_info"]
        summary = report["project_summary"]
        
        output.append(f"\n🏠 项目：{info['project_name']}")
        output.append(f"   报告日期：{info['report_date']}")
        output.append(f"   总体进度：{info['overall_progress']}%")
        
        output.append(f"\n📅 时间概览")
        output.append(f"   开工日期：{summary['start_date']}")
        output.append(f"   计划竣工：{summary['planned_completion']}")
        output.append(f"   总工期：{summary['total_duration']}天")
        output.append(f"   已过天数：{summary['elapsed_days']}天")
        output.append(f"   项目状态：{summary['status']}")
        
        # 阶段进度
        output.append(f"\n📈 阶段进度")
        for phase in report["phase_details"]:
            status_icon = "✅" if phase["status"] == "已完成" else ("🔄" if phase["status"] == "进行中" else "⏳")
            progress_bar = "█" * (int(phase["progress"][:-1]) // 5) + "░" * (20 - int(phase["progress"][:-1]) // 5)
            output.append(f"   {status_icon} {phase['phase']}: {phase['progress']}")
            output.append(f"      [{progress_bar}] {phase['planned']}")
            if phase["completed_tasks"] > 0:
                output.append(f"      任务完成：{phase['completed_tasks']}/{phase['total_tasks']}")
        
        # 延期分析
        delay = report["delay_analysis"]
        if delay["overall_status"] != "正常":
            output.append(f"\n🚨 延期/预警")
            if delay["delays"]:
                output.append("   【延期项目】")
                for d in delay["delays"]:
                    output.append(f"     🔴 {d['phase']}: 延期{d['days_overdue']}天 ({d['type']})")
            if delay["warnings"]:
                output.append("   【预警项目】")
                for w in delay["warnings"]:
                    output.append(f"     🟡 {w['phase']}: 剩余{w['days_remaining']}天 ({w['type']})")
        else:
            output.append(f"\n✅ 项目状态：正常，无延期")
        
        # 建议
        if report["recommendations"]:
            output.append(f"\n💡 建议措施")
            for rec in report["recommendations"]:
                output.append(f"   • {rec}")
        
        output.append("\n" + "=" * 70)
        
        return "\n".join(output)


def create_parser() -> argparse.ArgumentParser:
    """创建参数解析器"""
    parser = argparse.ArgumentParser(
        description="项目进度追踪器 - 管理项目各阶段进度，支持延期预警",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例用法：
  创建项目：
    python track_project_progress.py -a create -n "李府雅居" --start 2024-02-01
  
  更新进度：
    python track_project_progress.py -a update -p project.json --phase 水电工程 --task 水电验收 --status 已完成
  
  检查延期：
    python track_project_progress.py -a check -p project.json
  
  生成报告：
    python track_project_progress.py -a report -p project.json
        """
    )
    
    parser.add_argument(
        "-a", "--action",
        type=str,
        required=True,
        choices=["create", "update", "check", "report"],
        help="操作类型：create(创建项目), update(更新进度), check(检查延期), report(生成报告)"
    )
    
    # 创建项目参数
    parser.add_argument(
        "-n", "--project-name",
        type=str,
        help="项目名称（创建项目时必填）"
    )
    
    parser.add_argument(
        "--start",
        type=str,
        dest="start_date",
        help="开工日期 YYYY-MM-DD"
    )
    
    parser.add_argument(
        "--address",
        type=str,
        help="项目地址"
    )
    
    parser.add_argument(
        "--client",
        type=str,
        help="客户姓名"
    )
    
    parser.add_argument(
        "--designer",
        type=str,
        help="设计师姓名"
    )
    
    parser.add_argument(
        "--pm",
        type=str,
        dest="project_manager",
        help="项目经理姓名"
    )
    
    # 更新/查询参数
    parser.add_argument(
        "-p", "--project",
        type=str,
        dest="project_file",
        help="项目文件路径"
    )
    
    parser.add_argument(
        "--phase",
        type=str,
        help="阶段名称"
    )
    
    parser.add_argument(
        "--task",
        type=str,
        help="任务名称"
    )
    
    parser.add_argument(
        "--status",
        type=str,
        choices=["待开始", "进行中", "已完成", "已暂停"],
        help="状态"
    )
    
    parser.add_argument(
        "--progress",
        type=int,
        help="进度百分比 (0-100)"
    )
    
    parser.add_argument(
        "--notes",
        type=str,
        help="备注信息"
    )
    
    # 输出参数
    parser.add_argument(
        "-o", "--output",
        type=str,
        help="输出文件路径"
    )
    
    parser.add_argument(
        "-f", "--format",
        type=str,
        choices=["text", "json"],
        default="text",
        help="输出格式"
    )
    
    return parser


def main():
    """主函数"""
    parser = create_parser()
    args = parser.parse_args()
    
    tracker = ProjectProgressTracker()
    
    # 验证输入
    valid, error_msg = tracker.validate_inputs(args)
    if not valid:
        print(f"❌ 参数错误: {error_msg}", file=sys.stderr)
        parser.print_help()
        sys.exit(1)
    
    try:
        # 加载项目（如果是更新/查询操作）
        project = None
        if args.action in ["update", "check", "report"]:
            if args.project_file and os.path.exists(args.project_file):
                with open(args.project_file, 'r', encoding='utf-8') as f:
                    project = json.load(f)
            elif args.project and os.path.exists(args.project):
                with open(args.project, 'r', encoding='utf-8') as f:
                    project = json.load(f)
            else:
                print(f"❌ 项目文件不存在: {args.project_file or args.project}")
                sys.exit(1)
        
        # 执行操作
        if args.action == "create":
            result = tracker.create_project(args)
            output = tracker.format_report({
                "report_info": {
                    "project_name": result["project_info"]["project_name"],
                    "report_date": datetime.now().strftime("%Y-%m-%d"),
                    "overall_progress": 0
                },
                "project_summary": {
                    "start_date": result["project_info"]["start_date"],
                    "planned_completion": result["project_info"]["planned_completion"],
                    "total_duration": result["total_duration"],
                    "elapsed_days": 0,
                    "status": "筹备中"
                },
                "phase_details": [
                    {
                        "phase": name,
                        "status": info["status"],
                        "progress": "0%",
                        "planned": f"{info['planned_start']} 至 {info['planned_end']}",
                        "actual": "未开始 至 未开始",
                        "completed_tasks": 0,
                        "total_tasks": len(info["tasks"]),
                        "pending_tasks": list(info["tasks"].keys())
                    }
                    for name, info in result["phases"].items()
                ],
                "delay_analysis": {"overall_status": "正常", "delays": [], "warnings": [], "statistics": {}},
                "recommendations": ["项目创建成功，开始设计阶段"]
            }, args.format)
            
        elif args.action == "update":
            result = tracker.update_progress(project, args)
            output = f"✅ {result.get('message', '更新成功')}"
            if "error" in result:
                output = f"❌ {result['error']}"
            
        elif args.action == "check":
            result = tracker.check_delays(project)
            output = tracker.format_report({
                "report_info": {
                    "project_name": project["project_info"]["project_name"],
                    "report_date": datetime.now().strftime("%Y-%m-%d"),
                    "overall_progress": project.get("overall_progress", 0)
                },
                "project_summary": {
                    "start_date": project["project_info"]["start_date"],
                    "planned_completion": project["project_info"].get("planned_completion", "未知"),
                    "total_duration": project["total_duration"],
                    "elapsed_days": (datetime.now() - datetime.strptime(
                        project["project_info"]["start_date"], "%Y-%m-%d")).days + 1,
                    "status": project["project_info"]["status"]
                },
                "phase_details": [],
                "delay_analysis": result,
                "recommendations": []
            }, args.format)
            
        elif args.action == "report":
            result = tracker.generate_report(project)
            output = tracker.format_report(result, args.format)
        
        # 输出结果
        if args.output:
            with open(args.output, 'w', encoding='utf-8') as f:
                if args.action == "create":
                    f.write(json.dumps(result, ensure_ascii=False, indent=2))
                else:
                    f.write(json.dumps(result, ensure_ascii=False, indent=2))
            print(f"✅ 结果已保存至: {args.output}")
        else:
            print(output)
        
        # 如果是创建或更新操作，保存项目文件
        if args.action in ["create", "update"] and args.output:
            project_output = args.output.replace(".json", "_project.json")
            with open(project_output, 'w', encoding='utf-8') as f:
                if args.action == "create":
                    json.dump(result, f, ensure_ascii=False, indent=2)
                else:
                    json.dump(project, f, ensure_ascii=False, indent=2)
        
    except Exception as e:
        print(f"❌ 操作出错: {str(e)}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
