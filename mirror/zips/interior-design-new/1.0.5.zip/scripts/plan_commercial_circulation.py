#!/usr/bin/env python3
"""
商业动线规划脚本 - v2.3.0
用于商业空间动线设计分析

功能：
1. 办公空间动线规划（员工/访客/后勤分离）
2. 餐饮空间动线规划（顾客/后厨/传菜分离）
3. 零售空间动线规划（顾客/补货分离）
4. 教育空间动线规划（学生/家长/安全疏散）
5. 生成动线规划报告

Author: interior-design-assistant v2.3.0
"""

import argparse
from dataclasses import dataclass, asdict
from typing import List, Dict, Optional
from enum import Enum


class BusinessType(Enum):
    """商业业态类型"""
    OFFICE = "办公"
    RESTAURANT = "餐饮"
    RETAIL = "零售"
    EDUCATION = "教育"


@dataclass
class CirculationNode:
    """动线节点"""
    name: str
    node_type: str  # 入口/出口/功能区/通道
    x: float  # 相对位置X
    y: float  # 相对位置Y
    capacity: int = 0  # 人流容量
    width: float = 1.2  # 通道宽度(m)


@dataclass
class CirculationFlow:
    """动线"""
    name: str
    flow_type: str  # 顾客/员工/后勤
    nodes: List[str]  # 节点名称列表
    width: float = 1.2  # 通道宽度要求


@dataclass
class CirculationReport:
    """动线规划报告"""
    business_type: str
    area: float
    flows: List[Dict]
    recommendations: List[str]
    min_corridor_width: float


class CommercialCirculationPlanner:
    """商业动线规划类"""
    
    # 各业态动线设计标准
    DESIGN_STANDARDS = {
        "办公": {
            "员工通道": 1.2,
            "访客通道": 1.5,
            "后勤通道": 1.5,
            "会议室入口": 1.5,
            "主通道": 2.4,
            "次通道": 1.2
        },
        "餐饮": {
            "顾客通道": 1.2,
            "传菜通道": 1.2,
            "后厨通道": 1.0,
            "收银通道": 1.5,
            "主通道": 1.8,
            "餐桌间距": 0.9
        },
        "零售": {
            "顾客主通道": 2.4,
            "顾客次通道": 1.2,
            "补货通道": 1.5,
            "收银通道": 1.5,
            "陈列间隙": 0.8
        },
        "教育": {
            "学生通道": 1.2,
            "家长等候": 2.0,
            "疏散通道": 1.5,
            "教室走廊": 2.4,
            "安全出口": 1.5
        }
    }
    
    # 各业态动线设计要点
    DESIGN_TIPS = {
        "办公": [
            "员工流线与访客流线应分离，避免相互干扰",
            "后勤通道应连接仓储区与各功能区",
            "会议室设置独立出入口，便于分组讨论",
            "开放办公区采用鱼骨式或环岛式布局",
            "卫生间位置应便于各区域员工使用"
        ],
        "餐饮": [
            "顾客流线与后厨流线必须分离",
            "传菜通道宽度≥1.2m，满足托盘通过",
            "翻台率高的餐厅采用单通道+卡座布局",
            "收银台设置在出口处或靠近主通道",
            "后厨应设有独立进货通道"
        ],
        "零售": [
            "采用漏斗式动线，引导顾客深入",
            "主通道宽度≥2.4m，满足最大人流",
            "高毛利商品置于顾客动线必经位置",
            "收银台数量与客流量匹配",
            "设置后退通道，避免死胡同"
        ],
        "教育": [
            "儿童活动区域设置独立出入口",
            "课间高峰期需考虑人流分流",
            "安全出口数量和宽度满足疏散要求",
            "家长等候区设置在室外或独立区域",
            "教室门向外开，疏散时不堵塞"
        ]
    }
    
    def __init__(self, business_type: str, area: float):
        self.business_type = business_type
        self.area = area
        self.flows: List[CirculationFlow] = []
        self.standards = self.DESIGN_STANDARDS.get(business_type, {})
    
    def plan_office_circulation(self, employee_count: int = 0) -> CirculationReport:
        """规划办公空间动线"""
        flows = [
            {
                "name": "员工流线",
                "description": "入口 → 打卡区 → 工位区 → 茶水间/卫生间",
                "nodes": ["主入口", "考勤点", "开放办公区", "走廊", "茶水间", "卫生间"],
                "width": "1.2m",
                "design_points": [
                    "打卡点设置在入口明显位置",
                    "工位区通道满足轮椅通过（≥1.2m）",
                    "茶水间和卫生间设置在各层中部"
                ]
            },
            {
                "name": "访客流线",
                "description": "入口 → 前台 → 接待区 → 会议室/高管办公室",
                "nodes": ["访客入口", "接待台", "等候区", "会议室", "高管区"],
                "width": "1.5m",
                "design_points": [
                    "访客入口与员工入口分开",
                    "接待台后设置背景墙，提升企业形象",
                    "会议室配置独立卫生间"
                ]
            },
            {
                "name": "后勤流线",
                "description": "货梯 → 仓储区 → 复印室/茶水间",
                "nodes": ["货运入口", "货梯", "仓储区", "走廊", "复印室", "茶水间"],
                "width": "1.5m",
                "design_points": [
                    "货运入口设置在建筑背面或角落",
                    "货梯载重≥1000kg",
                    "仓储区靠近电梯或楼梯"
                ]
            }
        ]
        
        min_width = min(self.standards.values())
        recommendations = self.DESIGN_TIPS.get("办公", [])
        recommendations.extend([
            f"开放办公区面积建议：{self.area * 0.6:.0f}㎡",
            f"独立办公室面积建议：{self.area * 0.2:.0f}㎡",
            f"公共区域（会议室/茶水间等）建议：{self.area * 0.2:.0f}㎡"
        ])
        
        return CirculationReport(
            business_type="办公",
            area=self.area,
            flows=flows,
            recommendations=recommendations,
            min_corridor_width=min_width
        )
    
    def plan_restaurant_circulation(self, seat_count: int = 0, has_kitchen: bool = True) -> CirculationReport:
        """规划餐饮空间动线"""
        flows = [
            {
                "name": "顾客流线",
                "description": "入口 → 等位区 → 座位区 → 收银台 → 出口",
                "nodes": ["主入口", "等位区", "座位区", "收银台", "出口"],
                "width": "1.2m",
                "design_points": [
                    "入口设置玄关，避免冷气直吹",
                    "等位区提供座位和茶水设施",
                    "餐桌间距≥0.9m，满足椅背通过"
                ]
            }
        ]
        
        if has_kitchen:
            flows.append({
                "name": "后厨流线",
                "description": "收货区 → 粗加工 → 烹饪区 → 备餐区 → 传菜口",
                "nodes": ["收货区", "粗加工区", "烹饪区", "备餐区", "传菜口"],
                "width": "1.2m",
                "design_points": [
                    "收货区设置在建筑背面或角落",
                    "粗加工与烹饪区严格分离",
                    "传菜口设置在服务员视线范围内"
                ]
            })
            
            flows.append({
                "name": "传菜动线",
                "description": "传菜口 → 服务通道 → 餐桌",
                "nodes": ["传菜口", "服务通道", "餐桌"],
                "width": "1.2m",
                "design_points": [
                    "传菜通道与顾客通道立体交叉",
                    "服务通道宽度≥1.2m",
                    "传菜路径越短越好"
                ]
            })
        
        min_width = min(self.standards.values())
        recommendations = self.DESIGN_TIPS.get("餐饮", [])
        recommendations.extend([
            f"用餐区面积建议：{self.area * 0.55:.0f}㎡（含50%通道）",
            f"厨房区面积建议：{self.area * 0.25:.0f}㎡" if has_kitchen else "",
            f"公共区面积建议：{self.area * 0.2:.0f}㎡（入口/收银/卫生间）",
            f"座位数量建议：{int(self.area * 0.4)}座（按每座2.5㎡估算）"
        ])
        
        return CirculationReport(
            business_type="餐饮",
            area=self.area,
            flows=[f for f in flows if f],
            recommendations=[r for r in recommendations if r],
            min_corridor_width=min_width
        )
    
    def plan_retail_circulation(self, shop_type: str = "普通零售") -> CirculationReport:
        """规划零售空间动线"""
        flows = [
            {
                "name": "顾客流线",
                "description": "入口 → 主通道 → 次通道 → 陈列区 → 收银区 → 出口",
                "nodes": ["入口", "主通道", "次通道", "陈列区", "收银区", "出口"],
                "width": "主通道2.4m / 次通道1.2m",
                "design_points": [
                    "入口设置橱窗，吸引顾客注意",
                    "采用漏斗式动线，引导顾客深入",
                    "收银台设置在出口处"
                ]
            },
            {
                "name": "补货流线",
                "description": "仓库 → 后门 → 理货区 → 陈列区",
                "nodes": ["仓库", "后门", "理货区", "陈列区"],
                "width": "1.5m",
                "design_points": [
                    "补货通道与顾客通道分离",
                    "仓库设置在建筑后部或角落",
                    "理货区靠近仓库和主通道"
                ]
            }
        ]
        
        min_width = min(self.standards.values())
        recommendations = self.DESIGN_TIPS.get("零售", [])
        recommendations.extend([
            f"陈列区面积建议：{self.area * 0.5:.0f}㎡",
            f"通道面积建议：{self.area * 0.3:.0f}㎡（含主/次通道）",
            f"仓储面积建议：{self.area * 0.1:.0f}㎡",
            f"辅助区面积建议：{self.area * 0.1:.0f}㎡（收银/试衣间/卫生间）"
        ])
        
        return CirculationReport(
            business_type="零售",
            area=self.area,
            flows=flows,
            recommendations=recommendations,
            min_corridor_width=min_width
        )
    
    def plan_education_circulation(self, student_count: int = 0, age_group: str = "成人") -> CirculationReport:
        """规划教育空间动线"""
        is_children = age_group in ["幼儿", "儿童", "小学"]
        
        flows = [
            {
                "name": "学生流线",
                "description": "入口 → 签到区 → 教室/活动区 → 卫生间",
                "nodes": ["校门/楼门", "签到区", "走廊", "教室", "卫生间"],
                "width": "1.2m",
                "design_points": [
                    "入口设置考勤/签到设备",
                    "走廊宽度满足双向人流",
                    "卫生间设置在各层"
                ]
            }
        ]
        
        if is_children:
            flows.append({
                "name": "家长接送流线",
                "description": "接送区 → 等待区 → 教室门口",
                "nodes": ["接送区", "等待区", "走廊", "教室门口"],
                "width": "2.0m",
                "design_points": [
                    "设置独立家长等候区",
                    "出入口与学生通道分离",
                    "等候区设置座椅和遮阳设施"
                ]
            })
        
        flows.append({
            "name": "安全疏散流线",
            "description": "教室 → 疏散通道 → 安全出口 → 室外集合点",
            "nodes": ["教室", "走廊", "疏散楼梯", "安全出口", "集合点"],
            "width": "1.5m",
            "design_points": [
                "疏散出口宽度满足疏散计算",
                "疏散门向外开启",
                "设置明显疏散指示标志"
            ]
        })
        
        min_width = min(self.standards.values())
        recommendations = self.DESIGN_TIPS.get("教育", [])
        recommendations.extend([
            f"教室数量建议：{max(2, int(self.area / 60))}间（按60㎡/间估算）",
            f"每间教室容纳：{max(20, student_count // max(2, int(self.area / 60)))}人",
            f"走廊宽度：{2.4 if is_children else 2.0}m（儿童教育加宽）",
            f"安全出口数量：≥2个"
        ])
        
        return CirculationReport(
            business_type="教育",
            area=self.area,
            flows=flows,
            recommendations=recommendations,
            min_corridor_width=min_width
        )
    
    def generate_report(self) -> Dict:
        """生成动线规划报告"""
        if self.business_type == "办公":
            report = self.plan_office_circulation()
        elif self.business_type == "餐饮":
            report = self.plan_restaurant_circulation()
        elif self.business_type == "零售":
            report = self.plan_retail_circulation()
        elif self.business_type == "教育":
            report = self.plan_education_circulation()
        else:
            report = CirculationReport(
                business_type=self.business_type,
                area=self.area,
                flows=[],
                recommendations=["未知的商业类型"],
                min_corridor_width=1.2
            )
        
        return asdict(report)


def print_report(report: Dict):
    """格式化打印报告"""
    print("\n" + "=" * 60)
    print(f"【{report['business_type']}空间动线规划报告】")
    print("=" * 60)
    print(f"建筑面积：{report['area']:.0f}㎡")
    print(f"最小通道宽度：{report['min_corridor_width']}m")
    
    print("\n" + "-" * 60)
    print("动线设计")
    print("-" * 60)
    
    for flow in report["flows"]:
        print(f"\n【{flow['name']}】({flow['width']})")
        print(f"  路径：{flow['description']}")
        print(f"  节点：{' → '.join(flow['nodes'])}")
        print("  设计要点：")
        for point in flow.get("design_points", []):
            print(f"    · {point}")
    
    print("\n" + "-" * 60)
    print("规划建议")
    print("-" * 60)
    for i, rec in enumerate(report["recommendations"], 1):
        print(f"  {i}. {rec}")
    
    print()


def main():
    parser = argparse.ArgumentParser(description="商业空间动线规划工具")
    parser.add_argument("--type", type=str, required=True,
                       choices=["办公", "餐饮", "零售", "教育"],
                       help="商业类型")
    parser.add_argument("--area", type=float, required=True,
                       help="建筑面积（平方米）")
    parser.add_argument("--seat_count", type=int, default=0,
                       help="座位数量（餐饮用）")
    parser.add_argument("--employee_count", type=int, default=0,
                       help="员工数量（办公用）")
    parser.add_argument("--student_count", type=int, default=0,
                       help="学生数量（教育用）")
    parser.add_argument("--age_group", type=str, default="成人",
                       choices=["幼儿", "儿童", "小学", "中学", "成人"],
                       help="学生年龄段（教育用）")
    parser.add_argument("--has_kitchen", action="store_true", default=True,
                       help="是否含厨房（餐饮用）")
    parser.add_argument("--no_kitchen", action="store_true",
                       help="不含厨房")
    parser.add_argument("--shop_type", type=str, default="普通零售",
                       help="零售类型")
    parser.add_argument("--output", type=str, help="输出JSON文件路径")
    
    args = parser.parse_args()
    
    planner = CommercialCirculationPlanner(args.type, args.area)
    
    if args.type == "餐饮":
        report = planner.plan_restaurant_circulation(
            seat_count=args.seat_count,
            has_kitchen=not args.no_kitchen
        )
    elif args.type == "办公":
        report = planner.plan_office_circulation(
            employee_count=args.employee_count
        )
    elif args.type == "零售":
        report = planner.plan_retail_circulation(
            shop_type=args.shop_type
        )
    elif args.type == "教育":
        report = planner.plan_education_circulation(
            student_count=args.student_count,
            age_group=args.age_group
        )
    else:
        report = planner.generate_report()
    
    report_dict = asdict(report)
    print_report(report_dict)
    
    if args.output:
        import json
        with open(args.output, "w", encoding="utf-8") as f:
            json.dump(report_dict, f, ensure_ascii=False, indent=2)
        print(f"报告已保存至: {args.output}")


if __name__ == "__main__":
    main()
