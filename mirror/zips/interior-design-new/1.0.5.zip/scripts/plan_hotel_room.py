#!/usr/bin/env python3
"""
客房模块化布局生成脚本 - v2.4.0
用于酒店客房室内布局设计和面积计算

功能：
1. 单床间布局方案
2. 双床间布局方案
3. 套房布局方案
4. 无障碍客房布局方案
5. 面积计算与核查
6. 生成布局方案报告

Author: interior-design-assistant v2.4.0
"""

import argparse
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple
from enum import Enum


class RoomType(Enum):
    """客房类型"""
    SINGLE = "单人间"
    STANDARD = "标准间(双床)"
    DOUBLE = "大床间"
    JUNIOR_SUITE = "小套房"
    SUITE = "套房"
    ACCESSIBLE = "无障碍客房"


class HotelClass(Enum):
    """酒店档次"""
    ECONOMY = "经济型"
    THREE_STAR = "三星级"
    FOUR_STAR = "四星级"
    FIVE_STAR = "五星级"
    LUXURY = "奢华型"


@dataclass
class RoomDimensions:
    """客房尺寸"""
    width: float  # 开间(m)
    depth: float  # 进深(m)
    height: float = 2.8  # 净高(m)
    
    @property
    def area(self) -> float:
        """建筑面积"""
        return self.width * self.depth
    
    @property
    def net_area(self) -> float:
        """净使用面积（扣除墙体约10%）"""
        return self.area * 0.9


@dataclass
class BathroomDimensions:
    """卫生间尺寸"""
    width: float
    depth: float
    
    @property
    def area(self) -> float:
        return self.width * self.depth


@dataclass
class FurnitureItem:
    """家具项目"""
    name: str
    width: float
    depth: float
    quantity: int = 1
    
    @property
    def area(self) -> float:
        return self.width * self.depth * self.quantity


@dataclass
class RoomLayout:
    """客房布局方案"""
    room_type: RoomType
    hotel_class: HotelClass
    room_dims: RoomDimensions
    bath_dims: BathroomDimensions
    furniture: List[FurnitureItem] = field(default_factory=list)
    features: List[str] = field(default_factory=list)
    
    def generate_report(self) -> str:
        """生成布局报告"""
        report = []
        report.append("=" * 60)
        report.append(f"🏨 客房布局方案 - {self.room_type.value}")
        report.append("=" * 60)
        
        report.append(f"\n📐 基础尺寸")
        report.append(f"  客房开间: {self.room_dims.width}m")
        report.append(f"  客房进深: {self.room_dims.depth}m")
        report.append(f"  建筑面积: {self.room_dims.area:.1f}㎡")
        report.append(f"  净使用面积: {self.room_dims.net_area:.1f}㎡")
        report.append(f"  层高: {self.room_dims.height}m")
        
        report.append(f"\n🚿 卫生间尺寸")
        report.append(f"  卫生间开间: {self.bath_dims.width}m")
        report.append(f"  卫生间进深: {self.bath_dims.depth}m")
        report.append(f"  卫生间面积: {self.bath_dims.area:.1f}㎡")
        
        report.append(f"\n🛋️ 家具配置")
        for item in self.furniture:
            report.append(f"  • {item.name}: {item.width}m×{item.depth}m × {item.quantity}")
        
        if self.features:
            report.append(f"\n✨ 设计特点")
            for feature in self.features:
                report.append(f"  • {feature}")
        
        # 功能分区
        report.append(f"\n📋 功能分区建议")
        report.append(self._get_zoning_plan())
        
        return "\n".join(report)
    
    def _get_zoning_plan(self) -> str:
        """获取功能分区方案"""
        plans = {
            RoomType.SINGLE: """
  睡眠区(40%): 床、衣柜
  工作区(25%): 写字台、椅子
  起居区(20%): 单人沙发、茶几
  入口区(15%): 玄关、行李架""",
            
            RoomType.STANDARD: """
  睡眠区(35%): 双床、床头柜×2
  工作区(20%): 写字台、椅子
  起居区(25%): 沙发/贵妃椅、茶几
  入口区(20%): 玄关、衣柜、行李架""",
            
            RoomType.DOUBLE: """
  睡眠区(40%): 大床、床头柜×2
  工作区(20%): 写字台、椅子
  起居区(25%): 沙发区、休闲椅
  入口区(15%): 玄关、衣柜""",
            
            RoomType.JUNIOR_SUITE: """
  客厅区(35%): 沙发区、餐区
  睡眠区(30%): 大床、衣柜
  工作区(15%): 写字台
  入口区(10%): 玄关、行李架
  卫生间(10%): 独立卫生间""",
            
            RoomType.SUITE: """
  客厅区(30%): 会客区、餐区
  卧室区(25%): 独立卧室
  书房区(15%): 书房/办公
  入口区(10%): 玄关、衣帽间
  卫生间(20%): 主卫+客卫""",
            
            RoomType.ACCESSIBLE: """
  睡眠区(35%): 床、轮椅回转空间
  工作区(20%): 写字台（低位）
  起居区(20%): 轮椅通行区
  入口区(15%): 无障碍入口
  卫生间(10%): 无障碍卫生间""",
        }
        return plans.get(self.room_type, "")


class RoomLayoutGenerator:
    """客房布局生成器"""
    
    # 各档次客房尺寸标准（行业经验值）
    ROOM_DIMENSIONS = {
        HotelClass.ECONOMY: {
            RoomType.SINGLE: (3.0, 4.0),
            RoomType.STANDARD: (3.3, 4.5),
            RoomType.DOUBLE: (3.3, 4.5),
        },
        HotelClass.THREE_STAR: {
            RoomType.SINGLE: (3.3, 4.5),
            RoomType.STANDARD: (3.6, 5.0),
            RoomType.DOUBLE: (3.6, 5.0),
            RoomType.ACCESSIBLE: (3.6, 5.5),
        },
        HotelClass.FOUR_STAR: {
            RoomType.SINGLE: (3.6, 4.5),
            RoomType.STANDARD: (3.9, 5.5),
            RoomType.DOUBLE: (3.9, 5.5),
            RoomType.JUNIOR_SUITE: (5.4, 6.0),
            RoomType.ACCESSIBLE: (3.9, 5.5),
        },
        HotelClass.FIVE_STAR: {
            RoomType.SINGLE: (4.0, 5.0),
            RoomType.STANDARD: (4.2, 6.0),
            RoomType.DOUBLE: (4.2, 6.0),
            RoomType.JUNIOR_SUITE: (6.0, 7.0),
            RoomType.SUITE: (8.0, 10.0),
            RoomType.ACCESSIBLE: (4.2, 6.0),
        },
        HotelClass.LUXURY: {
            RoomType.DOUBLE: (4.5, 7.0),
            RoomType.JUNIOR_SUITE: (7.0, 8.0),
            RoomType.SUITE: (10.0, 15.0),
        },
    }
    
    # 卫生间尺寸标准
    BATHROOM_DIMENSIONS = {
        HotelClass.ECONOMY: (1.8, 2.5),
        HotelClass.THREE_STAR: (2.0, 2.8),
        HotelClass.FOUR_STAR: (2.2, 3.0),
        HotelClass.FIVE_STAR: (2.5, 3.5),
        HotelClass.LUXURY: (3.0, 4.0),
    }
    
    # 各类型客房家具配置
    FURNITURE_CONFIG = {
        RoomType.SINGLE: [
            FurnitureItem("单人床", 1.2, 2.0),
            FurnitureItem("衣柜", 1.2, 0.6),
            FurnitureItem("写字台", 1.0, 0.5),
            FurnitureItem("椅子", 0.5, 0.5),
            FurnitureItem("床头柜", 0.5, 0.4),
            FurnitureItem("行李架", 0.6, 0.4),
        ],
        RoomType.STANDARD: [
            FurnitureItem("单人床×2", 1.2, 2.0, 2),
            FurnitureItem("衣柜", 1.5, 0.6),
            FurnitureItem("写字台", 1.2, 0.6),
            FurnitureItem("椅子", 0.5, 0.5),
            FurnitureItem("床头柜×2", 0.5, 0.4, 2),
            FurnitureItem("行李架", 0.6, 0.4),
            FurnitureItem("沙发/贵妃椅", 1.8, 0.9),
            FurnitureItem("茶几", 0.6, 0.6),
        ],
        RoomType.DOUBLE: [
            FurnitureItem("大床", 1.8, 2.0),
            FurnitureItem("衣柜", 1.8, 0.6),
            FurnitureItem("写字台", 1.2, 0.6),
            FurnitureItem("椅子", 0.5, 0.5),
            FurnitureItem("床头柜×2", 0.5, 0.4, 2),
            FurnitureItem("休闲椅×2", 0.8, 0.8, 2),
            FurnitureItem("茶几", 0.8, 0.8),
        ],
        RoomType.JUNIOR_SUITE: [
            FurnitureItem("大床", 1.8, 2.0),
            FurnitureItem("衣柜", 2.0, 0.6),
            FurnitureItem("写字台", 1.4, 0.7),
            FurnitureItem("沙发组", 2.5, 2.5),
            FurnitureItem("茶几", 1.0, 0.6),
            FurnitureItem("餐区(2人)", 1.5, 1.5),
            FurnitureItem("床头柜×2", 0.6, 0.5, 2),
            FurnitureItem("行李架", 0.8, 0.5),
        ],
        RoomType.SUITE: [
            FurnitureItem("大床(主卧)", 2.0, 2.0),
            FurnitureItem("衣柜", 2.5, 0.6),
            FurnitureItem("床头柜×2", 0.6, 0.5, 2),
            FurnitureItem("沙发组", 3.0, 3.0),
            FurnitureItem("茶几", 1.2, 0.7),
            FurnitureItem("餐区(4-6人)", 2.0, 2.0),
            FurnitureItem("写字台/书桌", 1.6, 0.7),
            FurnitureItem("书椅", 0.6, 0.6),
            FurnitureItem("行李架", 1.0, 0.5),
        ],
        RoomType.ACCESSIBLE: [
            FurnitureItem("大床", 1.8, 2.0),
            FurnitureItem("衣柜(低位挂衣杆)", 1.5, 0.6),
            FurnitureItem("写字台(低位)", 1.2, 0.6),
            FurnitureItem("轮椅", 0.7, 1.0),
            FurnitureItem("床头柜", 0.6, 0.5),
        ],
    }
    
    def __init__(self, room_type: RoomType, hotel_class: HotelClass):
        self.room_type = room_type
        self.hotel_class = hotel_class
    
    def generate(self) -> RoomLayout:
        """生成布局方案"""
        # 获取尺寸标准
        room_dims = self.ROOM_DIMENSIONS.get(self.hotel_class, {}).get(
            self.room_type, (3.6, 5.0)
        )
        bath_dims = self.BATHROOM_DIMENSIONS.get(
            self.hotel_class, (2.0, 2.8)
        )
        
        # 无障碍客房特殊尺寸
        if self.room_type == RoomType.ACCESSIBLE:
            bath_dims = (2.2, 2.8)  # 轮椅回转空间≥1.5m
        
        # 获取家具配置
        furniture = self.FURNITURE_CONFIG.get(
            self.room_type, 
            self.FURNITURE_CONFIG[RoomType.STANDARD]
        )
        
        # 生成特点
        features = self._generate_features()
        
        return RoomLayout(
            room_type=self.room_type,
            hotel_class=self.hotel_class,
            room_dims=RoomDimensions(
                width=room_dims[0],
                depth=room_dims[1],
                height=self._get_height()
            ),
            bath_dims=BathroomDimensions(
                width=bath_dims[0],
                depth=bath_dims[1]
            ),
            furniture=furniture,
            features=features
        )
    
    def _get_height(self) -> float:
        """获取层高"""
        heights = {
            HotelClass.ECONOMY: 2.6,
            HotelClass.THREE_STAR: 2.8,
            HotelClass.FOUR_STAR: 3.0,
            HotelClass.FIVE_STAR: 3.2,
            HotelClass.LUXURY: 3.5,
        }
        return heights.get(self.hotel_class, 2.8)
    
    def _generate_features(self) -> List[str]:
        """生成设计特点"""
        features = []
        
        # 根据客房类型添加特点
        type_features = {
            RoomType.SINGLE: ["紧凑实用", "工作区功能完善"],
            RoomType.STANDARD: ["双床配置灵活", "沙发区提升舒适度"],
            RoomType.DOUBLE: ["大床提升睡眠品质", "休闲区域宽敞"],
            RoomType.JUNIOR_SUITE: ["客餐分区", "空间层次丰富"],
            RoomType.SUITE: ["独立客厅", "豪华配置", "管家服务空间"],
            RoomType.ACCESSIBLE: ["轮椅无障碍", "低位配置", "紧急呼叫系统"],
        }
        features.extend(type_features.get(self.room_type, []))
        
        # 根据档次添加特点
        class_features = {
            HotelClass.ECONOMY: ["标准化设计", "成本控制优先"],
            HotelClass.THREE_STAR: ["舒适实用", "品质保证"],
            HotelClass.FOUR_STAR: ["设计感强", "注重细节"],
            HotelClass.FIVE_STAR: ["豪华配置", "高端材质", "个性化服务"],
            HotelClass.LUXURY: ["顶级配置", "管家服务", "艺术品陈设"],
        }
        features.extend(class_features.get(self.hotel_class, []))
        
        return features


def check_accessibility_compliance(layout: RoomLayout) -> List[str]:
    """检查无障碍合规性"""
    issues = []
    
    if layout.room_type != RoomType.ACCESSIBLE:
        return issues
    
    # 检查轮椅回转空间
    min_turn_diameter = 1.5  # GB 50763要求
    if layout.room_dims.width < 3.6 or layout.room_dims.depth < 4.5:
        issues.append(f"轮椅回转空间可能不足（建议净尺寸≥3.6m×4.5m）")
    
    # 检查门净宽
    issues.append("无障碍门净宽应≥0.9m")
    
    # 检查开关高度
    issues.append("电气开关应设置在0.9-1.1m高度")
    
    return issues


def main():
    """主函数"""
    parser = argparse.ArgumentParser(
        description="客房模块化布局生成工具 - v2.4.0",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用示例:
  python plan_hotel_room.py --type standard --class five_star
  python plan_hotel_room.py --type suite --class luxury --output report.txt
  python plan_hotel_room.py --type accessible --class four_star --verify

布局类型说明:
  single      - 单人间
  standard    - 标准间(双床)
  double      - 大床间
  junior_suite - 小套房
  suite       - 套房
  accessible  - 无障碍客房

酒店档次说明:
  economy     - 经济型
  three_star  - 三星级
  four_star   - 四星级
  five_star   - 五星级
  luxury      - 奢华型
        """
    )
    
    parser.add_argument("--type", "-t", 
                        choices=["single", "standard", "double", 
                                 "junior_suite", "suite", "accessible"],
                        default="standard",
                        help="客房类型")
    parser.add_argument("--class", "-c",
                        choices=["economy", "three_star", "four_star", 
                                 "five_star", "luxury"],
                        default="four_star",
                        help="酒店档次")
    parser.add_argument("--width", type=float, default=None,
                        help="自定义开间(m)，如不指定则使用标准")
    parser.add_argument("--depth", type=float, default=None,
                        help="自定义进深(m)，如不指定则使用标准")
    parser.add_argument("--verify", action="store_true",
                        help="验证无障碍合规性")
    parser.add_argument("--output", "-o",
                        help="输出报告到文件")
    
    args = parser.parse_args()
    
    # 参数映射
    room_type_map = {
        "single": RoomType.SINGLE,
        "standard": RoomType.STANDARD,
        "double": RoomType.DOUBLE,
        "junior_suite": RoomType.JUNIOR_SUITE,
        "suite": RoomType.SUITE,
        "accessible": RoomType.ACCESSIBLE,
    }
    
    hotel_class_map = {
        "economy": HotelClass.ECONOMY,
        "three_star": HotelClass.THREE_STAR,
        "four_star": HotelClass.FOUR_STAR,
        "five_star": HotelClass.FIVE_STAR,
        "luxury": HotelClass.LUXURY,
    }
    
    room_type = room_type_map[args.type]
    hotel_class = hotel_class_map[args.class]
    
    # 生成布局
    generator = RoomLayoutGenerator(room_type, hotel_class)
    layout = generator.generate()
    
    # 如果指定了自定义尺寸
    if args.width:
        layout.room_dims = RoomDimensions(
            width=args.width,
            depth=layout.room_dims.depth,
            height=layout.room_dims.height
        )
    if args.depth:
        layout.room_dims = RoomDimensions(
            width=layout.room_dims.width,
            depth=args.depth,
            height=layout.room_dims.height
        )
    
    # 生成报告
    report = layout.generate_report()
    
    # 无障碍验证
    if args.verify or args.type == "accessible":
        issues = check_accessibility_compliance(layout)
        if issues:
            report += "\n\n" + "=" * 60
            report += "\n♿ 无障碍合规性检查"
            report += "\n" + "-" * 60
            for issue in issues:
                report += f"\n  ⚠️ {issue}"
    
    # 输出
    print(report)
    
    # 保存到文件
    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(report)
        print(f"\n📄 报告已保存至: {args.output}")


if __name__ == "__main__":
    main()
