#!/usr/bin/env python3
"""
施工图审核脚本 v2.2.0
自动检查施工图的完整性和常见问题

用法示例：
    python check_construction_drawings.py --project "李府雅居" --standard residential
    python check_construction_drawings.py -p "商业空间" -s commercial -o checklist.json
"""

import argparse
import json
import sys
from datetime import datetime
from typing import Dict, Any, List, Optional

class ConstructionDrawingChecker:
    """施工图审核器 v2.2.0"""
    
    def __init__(self):
        # 住宅施工图清单
        self.residential_drawings = [
            {"name": "原始结构图", "required": True, "priority": "high"},
            {"name": "墙体拆除图", "required": True, "priority": "high"},
            {"name": "墙体新建图", "required": True, "priority": "high"},
            {"name": "平面布置图", "required": True, "priority": "high"},
            {"name": "家具尺寸图", "required": True, "priority": "medium"},
            {"name": "地面铺装图", "required": True, "priority": "high"},
            {"name": "天花布置图", "required": True, "priority": "high"},
            {"name": "天花尺寸图", "required": False, "priority": "medium"},
            {"name": "灯具定位图", "required": True, "priority": "medium"},
            {"name": "开关布置图", "required": True, "priority": "high"},
            {"name": "插座布置图", "required": True, "priority": "high"},
            {"name": "弱电布置图", "required": False, "priority": "medium"},
            {"name": "给排水布置图", "required": True, "priority": "high"},
            {"name": "地暖/暖气布置图", "required": False, "priority": "low"},
            {"name": "立面索引图", "required": True, "priority": "high"},
            {"name": "客厅立面图", "required": True, "priority": "high"},
            {"name": "主卧立面图", "required": True, "priority": "medium"},
            {"name": "餐厅立面图", "required": True, "priority": "medium"},
            {"name": "厨房立面图", "required": True, "priority": "high"},
            {"name": "卫生间立面图", "required": True, "priority": "high"},
            {"name": "节点大样图", "required": True, "priority": "high"},
            {"name": "门表图", "required": True, "priority": "medium"},
            {"name": "窗表图", "required": False, "priority": "low"},
        ]
        
        # 商业空间施工图清单
        self.commercial_drawings = [
            {"name": "原始平面图", "required": True, "priority": "high"},
            {"name": "平面布置图", "required": True, "priority": "high"},
            {"name": "综合天花图", "required": True, "priority": "high"},
            {"name": "地面铺装图", "required": True, "priority": "high"},
            {"name": "隔墙定位图", "required": True, "priority": "high"},
            {"name": "机电综合图", "required": True, "priority": "high"},
            {"name": "照明布置图", "required": True, "priority": "high"},
            {"name": "插座系统图", "required": True, "priority": "medium"},
            {"name": "给排水图", "required": False, "priority": "medium"},
            {"name": "排油烟图", "required": False, "priority": "medium"},
            {"name": "空调风口图", "required": True, "priority": "medium"},
            {"name": "主要空间立面图", "required": True, "priority": "high"},
            {"name": "节点大样图", "required": True, "priority": "high"},
            {"name": "门表图", "required": True, "priority": "medium"},
            {"name": "材料表", "required": True, "priority": "medium"},
            {"name": "Logo/招牌定位图", "required": False, "priority": "medium"},
        ]
        
        # 分项审核项目
        self.check_items = {
            "平面布置图": [
                {"item": "功能分区合理", "category": "布局", "required": True},
                {"item": "动线流畅（主通道≥900mm）", "category": "布局", "required": True},
                {"item": "家具尺寸标注", "category": "尺寸", "required": True},
                {"item": "门窗开启方向", "category": "细节", "required": True},
                {"item": "标高标注", "category": "尺寸", "required": False},
                {"item": "面积标注", "category": "尺寸", "required": False},
            ],
            "天花布置图": [
                {"item": "完成面标高（≥2400mm）", "category": "规范", "required": True},
                {"item": "灯具定位标注", "category": "尺寸", "required": True},
                {"item": "空调出风口位置", "category": "设备", "required": True},
                {"item": "新风/换气口位置", "category": "设备", "required": False},
                {"item": "检修口预留位置", "category": "设备", "required": True},
                {"item": "吊顶材料标注", "category": "材料", "required": True},
            ],
            "地面铺装图": [
                {"item": "材料标注（品牌/型号/规格）", "category": "材料", "required": True},
                {"item": "铺贴方向标注", "category": "工艺", "required": True},
                {"item": "标高/坡度标注", "category": "尺寸", "required": True},
                {"item": "地漏/排水沟位置", "category": "细节", "required": True},
                {"item": "门槛石位置", "category": "细节", "required": True},
            ],
            "立面图": [
                {"item": "材质标注（品牌/型号）", "category": "材料", "required": True},
                {"item": "尺寸标注完整", "category": "尺寸", "required": True},
                {"item": "完成面厚度", "category": "工艺", "required": True},
                {"item": "工艺说明", "category": "工艺", "required": False},
                {"item": "收口处理方式", "category": "工艺", "required": True},
            ],
            "水电图": [
                {"item": "开关位置（距门100-200mm）", "category": "规范", "required": True},
                {"item": "插座高度合理", "category": "规范", "required": True},
                {"item": "大功率电器独立回路", "category": "安全", "required": True},
                {"item": "厨卫阳台防水插座", "category": "安全", "required": True},
                {"item": "给水管走向标注", "category": "尺寸", "required": True},
                {"item": "排水管走向及坡度", "category": "尺寸", "required": True},
            ],
            "节点大样图": [
                {"item": "材料层次标注", "category": "材料", "required": True},
                {"item": "尺寸标注", "category": "尺寸", "required": True},
                {"item": "工艺做法说明", "category": "工艺", "required": True},
                {"item": "与其他构造的交接", "category": "工艺", "required": True},
            ]
        }
    
    def validate_inputs(self, args: argparse.Namespace) -> tuple[bool, str]:
        """验证输入"""
        if args.standard not in ["residential", "commercial"]:
            return False, f"不支持的审核标准: {args.standard}，可选: residential, commercial"
        return True, ""
    
    def get_drawing_list(self, standard: str) -> List[Dict]:
        """获取图纸清单"""
        if standard == "commercial":
            return self.commercial_drawings
        return self.residential_drawings
    
    def check_drawings(self, args: argparse.Namespace) -> Dict[str, Any]:
        """审核图纸"""
        standard = args.standard
        drawings = args.drawings if args.drawings else []
        project_name = args.project or "未命名项目"
        
        # 获取图纸清单
        required_drawings = self.get_drawing_list(standard)
        
        # 检查图纸完整性
        completeness = {
            "required_drawings": len([d for d in required_drawings if d["required"]]),
            "provided_drawings": 0,
            "missing_drawings": [],
            "optional_drawings": [],
            "check_list": []
        }
        
        for drawing in required_drawings:
            drawing_name = drawing["name"]
            is_provided = any(drawing_name in d or d in drawing_name for d in drawings)
            
            item = {
                "name": drawing_name,
                "required": drawing["required"],
                "priority": drawing["priority"],
                "status": "已提供" if is_provided else ("缺失（必填）" if drawing["required"] else "缺失（可选）"),
                "provided": is_provided
            }
            
            completeness["check_list"].append(item)
            
            if is_provided:
                completeness["provided_drawings"] += 1
            elif drawing["required"]:
                completeness["missing_drawings"].append({
                    "name": drawing_name,
                    "priority": drawing["priority"],
                    "suggestion": self._get_suggestion(drawing_name)
                })
            else:
                completeness["optional_drawings"].append(drawing_name)
        
        # 计算完整度
        completeness["score"] = round(
            completeness["provided_drawings"] / completeness["required_drawings"] * 100, 1
        )
        
        # 分项审核
        detail_checks = {}
        for drawing_type, items in self.check_items.items():
            # 检查是否有该类图纸
            has_drawing = any(drawing_type in d for d in drawings)
            
            if has_drawing:
                detail_checks[drawing_type] = {
                    "status": "可审核",
                    "items": [
                        {
                            "name": item["item"],
                            "category": item["category"],
                            "required": item["required"],
                            "status": "待检查"
                        }
                        for item in items
                    ]
                }
        
        # 生成报告
        result = {
            "report_info": {
                "project_name": project_name,
                "standard": "住宅装修" if standard == "residential" else "商业空间",
                "audit_date": datetime.now().strftime("%Y-%m-%d"),
                "auditor": args.auditor or "AI助手"
            },
            "completeness": completeness,
            "detail_checks": detail_checks,
            "summary": self._generate_summary(completeness),
            "recommendations": self._generate_recommendations(completeness)
        }
        
        return result
    
    def _get_suggestion(self, drawing_name: str) -> str:
        """获取图纸缺失建议"""
        suggestions = {
            "原始结构图": "必须提供，用于了解房屋原始结构",
            "墙体拆除图": "如有拆改必须提供",
            "墙体新建图": "如有新建墙体必须提供",
            "平面布置图": "核心图纸，必须提供",
            "家具尺寸图": "建议提供，便于施工方了解家具布置",
            "地面铺装图": "必须提供，标注材料规格和铺贴方式",
            "天花布置图": "必须提供，标注吊顶造型和材料",
            "天花尺寸图": "建议提供，标注详细尺寸",
            "灯具定位图": "建议提供，便于水电定位",
            "开关布置图": "必须提供",
            "插座布置图": "必须提供",
            "给排水布置图": "必须提供",
            "立面索引图": "必须提供",
            "节点大样图": "必须提供，用于指导施工工艺",
            "门表图": "建议提供，标注门型号规格"
        }
        return suggestions.get(drawing_name, "建议提供此图纸")
    
    def _generate_summary(self, completeness: Dict) -> Dict[str, Any]:
        """生成摘要"""
        score = completeness["score"]
        
        if score >= 95:
            status = "优秀"
            comment = "图纸基本完整，可进入下一阶段"
        elif score >= 80:
            status = "良好"
            comment = "图纸完整度良好，建议补充缺失项"
        elif score >= 60:
            status = "一般"
            comment = "图纸缺失较多，建议完善后再施工"
        else:
            status = "不足"
            comment = "图纸严重缺失，必须补充完整"
        
        return {
            "score": score,
            "status": status,
            "comment": comment,
            "required_count": completeness["required_drawings"],
            "provided_count": completeness["provided_drawings"],
            "missing_count": len(completeness["missing_drawings"]),
            "missing_high_priority": len([d for d in completeness["missing_drawings"] if d["priority"] == "high"])
        }
    
    def _generate_recommendations(self, completeness: Dict) -> List[str]:
        """生成建议"""
        recommendations = []
        
        missing = completeness["missing_drawings"]
        
        # 高优先级建议
        high_priority = [d for d in missing if d["priority"] == "high"]
        if high_priority:
            names = ", ".join([d["name"] for d in high_priority[:3]])
            recommendations.append(f"【高优先级】请尽快补充：{names}")
            if len(high_priority) > 3:
                recommendations.append(f"          及其他{len(high_priority)-3}项必填图纸")
        
        # 中优先级建议
        medium_priority = [d for d in missing if d["priority"] == "medium"]
        if medium_priority:
            names = ", ".join([d["name"] for d in medium_priority[:3]])
            recommendations.append(f"【建议补充】{names}等图纸")
        
        return recommendations
    
    def format_output(self, result: Dict, format_type: str = "text") -> str:
        """格式化输出"""
        if format_type == "json":
            return json.dumps(result, ensure_ascii=False, indent=2)
        
        output = []
        output.append("=" * 70)
        output.append("🔍 施工图审核报告")
        output.append("=" * 70)
        
        info = result["report_info"]
        output.append(f"\n📋 项目：{info['project_name']}")
        output.append(f"   标准：{info['standard']}")
        output.append(f"   日期：{info['audit_date']}")
        output.append(f"   审核：{info['auditor']}")
        
        # 完整度摘要
        summary = result["summary"]
        output.append(f"\n📊 图纸完整度评分：{summary['score']}% ({summary['status']})")
        output.append(f"   必填图纸：{summary['required_count']}项")
        output.append(f"   已提供：{summary['provided_count']}项")
        output.append(f"   缺失：{summary['missing_count']}项")
        
        if summary['missing_high_priority'] > 0:
            output.append(f"   ⚠️ 高优先级缺失：{summary['missing_high_priority']}项")
        
        output.append(f"\n💬 {summary['comment']}")
        
        # 缺失图纸
        missing = result["completeness"]["missing_drawings"]
        if missing:
            output.append(f"\n⚠️ 【缺失图纸清单】")
            for i, d in enumerate(missing, 1):
                priority_icon = "🔴" if d["priority"] == "high" else ("🟡" if d["priority"] == "medium" else "⚪")
                output.append(f"   {i}. {priority_icon} {d['name']}")
                output.append(f"      💡 {d['suggestion']}")
        
        # 分项审核
        detail_checks = result["detail_checks"]
        if detail_checks:
            output.append(f"\n📝 【分项审核】")
            for drawing_type, check_info in detail_checks.items():
                output.append(f"\n   ▶ {drawing_type}")
                for item in check_info["items"][:4]:  # 只显示前4项
                    required_icon = "★" if item["required"] else "☆"
                    output.append(f"     {required_icon} {item['name']} [{item['category']}]")
        
        # 建议
        recommendations = result["recommendations"]
        if recommendations:
            output.append(f"\n💡 【补充建议】")
            for rec in recommendations:
                output.append(f"   • {rec}")
        
        output.append("\n" + "=" * 70)
        output.append(f"📅 报告生成时间：{info['audit_date']}")
        
        return "\n".join(output)


def create_parser() -> argparse.ArgumentParser:
    """创建参数解析器"""
    parser = argparse.ArgumentParser(
        description="施工图审核器 - 自动检查施工图的完整性和常见问题",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例用法：
  python check_construction_drawings.py --project "李府雅居" --standard residential
  python check_construction_drawings.py -p "商业空间" -s commercial -d "平面布置图" "天花布置图" -o checklist.json

注意事项：
  - --drawings 参数为可选项，不指定则仅检查图纸完整性
  - 如需详细审核，请提供已完成的图纸名称
        """
    )
    
    parser.add_argument(
        "-p", "--project",
        type=str,
        help="项目名称"
    )
    
    parser.add_argument(
        "-s", "--standard",
        type=str,
        required=True,
        choices=["residential", "commercial"],
        help="审核标准：residential(住宅) 或 commercial(商业空间)"
    )
    
    parser.add_argument(
        "-d", "--drawings",
        type=str,
        nargs="+",
        help="已完成的图纸列表（可选）"
    )
    
    parser.add_argument(
        "-a", "--auditor",
        type=str,
        help="审核人"
    )
    
    parser.add_argument(
        "-o", "--output",
        type=str,
        help="输出文件路径"
    )
    
    parser.add_argument(
        "-f", "--format",
        type=str,
        choices=["text", "json"],
        default="text",
        help="输出格式"
    )
    
    return parser


def main():
    """主函数"""
    parser = create_parser()
    args = parser.parse_args()
    
    checker = ConstructionDrawingChecker()
    
    # 验证输入
    valid, error_msg = checker.validate_inputs(args)
    if not valid:
        print(f"❌ 参数错误: {error_msg}", file=sys.stderr)
        parser.print_help()
        sys.exit(1)
    
    try:
        result = checker.check_drawings(args)
        output = checker.format_output(result, args.format)
        
        if args.output:
            with open(args.output, 'w', encoding='utf-8') as f:
                f.write(json.dumps(result, ensure_ascii=False, indent=2))
            print(f"✅ 审核报告已保存至: {args.output}")
        else:
            print(output)
        
    except Exception as e:
        print(f"❌ 审核出错: {str(e)}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
