#!/usr/bin/env python3
"""
设计提案生成脚本 v2.2.0
根据项目信息生成结构化的设计提案文档

用法示例：
    python generate_design_proposal.py --area 120 --style 现代简约 --budget 中等 --output ./proposal/
    python generate_design_proposal.py -a 100 -s 轻奢 -b 较高 -p "李府雅居" -o proposal.json
"""

import argparse
import json
import os
import sys
from datetime import datetime
from typing import Dict, Any, List, Optional

class DesignProposalGenerator:
    """设计方案生成器 v2.2.0"""
    
    def __init__(self):
        # 风格配置
        self.styles = {
            "现代简约": {
                "keywords": ["简洁", "功能", "黑白灰", "少即是多"],
                "concept": "以\"少即是多\"为设计核心，通过简洁的线条和纯粹的色彩，打造一个功能完善、视觉清爽的生活空间。",
                "materials": {
                    "地面": "灰色系抛光砖或浅灰木地板",
                    "墙面": "白色或浅灰色乳胶漆",
                    "天花": "白色石膏板平顶，无主灯设计",
                    "定制": "白色或木色柜体，石英石台面"
                },
                "colors": {
                    "主色调": "白色/浅灰色 (60%)",
                    "辅助色": "中灰色/木色 (30%)",
                    "点缀色": "黑色/亮色如黄色、蓝色 (10%)"
                },
                "furniture": ["简约沙发", "几何茶几", "多功能柜"]
            },
            "北欧": {
                "keywords": ["自然", "温馨", "原木", "清新"],
                "concept": "追求自然与生活的和谐统一，运用大量原木元素和柔和色彩，营造一个温馨舒适的居家氛围。",
                "materials": {
                    "地面": "浅色原木地板",
                    "墙面": "白色或浅灰色乳胶漆",
                    "天花": "白色，局部可用木饰面",
                    "定制": "白色或原木色柜体"
                },
                "colors": {
                    "主色调": "白色 (60%)",
                    "辅助色": "原木色/浅灰色 (30%)",
                    "点缀色": "灰蓝色/薄荷绿/粉色 (10%)"
                },
                "furniture": ["布艺沙发", "圆形茶几", "绿植"]
            },
            "新中式": {
                "keywords": ["传统", "对称", "沉稳", "东方"],
                "concept": "将传统东方美学与现代生活方式融合，通过对称布局和中式元素，打造一个有文化底蕴的雅致空间。",
                "materials": {
                    "地面": "深色实木地板或大理石",
                    "墙面": "米色乳胶漆+木格栅/护墙板",
                    "天花": "白色+木线条装饰",
                    "定制": "深色木饰面柜体"
                },
                "colors": {
                    "主色调": "米色/浅灰色 (60%)",
                    "辅助色": "深木色/棕色 (30%)",
                    "点缀色": "中国红/墨绿/金色 (10%)"
                },
                "furniture": ["实木沙发", "圈椅", "博古架"]
            },
            "轻奢": {
                "keywords": ["精致", "金属", "大理石", "品质"],
                "concept": "在简约的基础上融入精致的细节和高品质的材料，打造一个低调奢华、品味非凡的居住空间。",
                "materials": {
                    "地面": "大理石或深色木地板",
                    "墙面": "护墙板或艺术涂料",
                    "天花": "造型吊顶+金属线条",
                    "定制": "深色柜体+岩板台面+金属拉手"
                },
                "colors": {
                    "主色调": "米白/浅咖色 (60%)",
                    "辅助色": "深灰/驼色/金色 (30%)",
                    "点缀色": "墨绿/宝石蓝/金属色 (10%)"
                },
                "furniture": ["皮质沙发", "金属边几", "艺术装饰画"]
            },
            "日式": {
                "keywords": ["极简", "禅意", "原木", "收纳"],
                "concept": "遵循\"侘寂\"美学，追求自然、质朴、宁静的空间氛围，打造一个让人身心放松的禅意空间。",
                "materials": {
                    "地面": "榻榻米或原木地板",
                    "墙面": "白色+木饰面",
                    "天花": "白色或木饰面",
                    "定制": "原木色柜体，隐形把手"
                },
                "colors": {
                    "主色调": "白色/米色 (60%)",
                    "辅助色": "原木色/浅棕色 (30%)",
                    "点缀色": "深棕色/黑色/绿植 (10%)"
                },
                "furniture": ["矮式沙发", "榻榻米", "纸灯笼"]
            },
            "奶油风": {
                "keywords": ["温柔", "暖调", "治愈", "柔和"],
                "concept": "以温柔治愈的奶油色调为主，营造一个温暖、舒适、让人放松的居家氛围。",
                "materials": {
                    "地面": "暖色木地板或柔光砖",
                    "墙面": "奶白色/奶油色乳胶漆",
                    "天花": "白色，柔和圆润",
                    "定制": "奶白色柜体，圆弧造型"
                },
                "colors": {
                    "主色调": "奶白色/奶油色 (60%)",
                    "辅助色": "浅咖色/暖灰色 (30%)",
                    "点缀色": "焦糖色/粉色/绿色 (10%)"
                },
                "furniture": ["圆润沙发", "拱形镜子", "毛绒单品"]
            }
        }
        
        # 空间布局建议
        self.layout_suggestions = {
            "客厅": {
                "功能分区": ["会客区", "视听区", "休闲区"],
                "furniture_layout": "沙发靠墙或居中摆放，茶几置于沙发前，电视柜布置于对面",
                "动线规划": "入口→客厅中央→各功能区，保持主要通道宽度≥90cm",
                "尺寸建议": {
                    "沙发": "2.4-2.8m（三人位）",
                    "茶几": "1.0-1.2m",
                    "电视柜": "1.8-2.2m"
                }
            },
            "卧室": {
                "功能分区": ["睡眠区", "储物区", "梳妆/工作区"],
                "furniture_layout": "床居中或靠墙摆放，床头两侧留50-60cm通道",
                "动线规划": "入口→床两侧→各功能区，避免动线穿过睡眠区",
                "尺寸建议": {
                    "双人床": "1.8m×2.0m或2.0m×2.0m",
                    "床头柜": "0.5m×0.5m",
                    "衣柜深度": "0.6m"
                }
            },
            "厨房": {
                "功能分区": ["储藏区", "清洗区", "备餐区", "烹饪区"],
                "furniture_layout": "按\"取→洗→切→炒\"顺序布置，形成高效工作三角",
                "动线规划": "冰箱→水槽→操作台→灶台→出菜口，单向流动",
                "尺寸建议": {
                    "台面高度": "80-90cm（根据身高调整）",
                    "操作台深度": "60cm",
                    "吊柜深度": "35cm"
                }
            },
            "卫生间": {
                "功能分区": ["洗漱区", "如厕区", "淋浴区"],
                "furniture_layout": "干湿分离，洗手台可外置",
                "动线规划": "入口→洗漱区→如厕/淋浴区",
                "尺寸建议": {
                    "标准干区": "90cm×120cm",
                    "淋浴房": "90cm×90cm最小",
                    "马桶前方": "≥60cm"
                }
            }
        }
    
    def validate_inputs(self, args: argparse.Namespace) -> tuple[bool, str]:
        """验证输入"""
        if args.area <= 0 or args.area > 1000:
            return False, f"面积必须在1-1000㎡之间，当前: {args.area}㎡"
        if args.style not in self.styles:
            return False, f"不支持的风格: {args.style}，可选: {list(self.styles.keys())}"
        if args.output and os.path.exists(args.output) and os.path.isfile(args.output):
            return False, f"输出路径已存在且为文件，请使用目录路径"
        return True, ""
    
    def generate_proposal(self, args: argparse.Namespace) -> Dict[str, Any]:
        """生成设计提案"""
        style_config = self.styles.get(args.style, self.styles["现代简约"])
        
        proposal = {
            "project_info": {
                "name": args.project_name or "未命名项目",
                "area": args.area,
                "style": args.style,
                "budget_level": args.budget,
                "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            },
            "design_concept": {
                "title": args.style,
                "concept": style_config["concept"],
                "keywords": style_config["keywords"],
                "description": f"本方案以{args.style}为核心设计理念，通过精心搭配的材料、色彩和软装，打造一个既美观又实用的居住空间。"
            },
            "space_analysis": self._generate_space_analysis(args),
            "layout_plan": self._generate_layout_plan(args),
            "material_scheme": style_config["materials"],
            "color_scheme": style_config["colors"],
            "furniture_plan": self._generate_furniture_plan(style_config),
            "lighting_design": self._generate_lighting_design(args.style),
            "budget_estimate": self._generate_budget_estimate(args),
            "timeline": self._generate_timeline(args.area),
            "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        
        return proposal
    
    def _generate_space_analysis(self, args: argparse.Namespace) -> Dict[str, Any]:
        """生成空间分析"""
        area = args.area
        
        # 根据面积估算各空间比例
        if area < 60:
            rooms_config = "紧凑型两居室，客厅与餐厅合并设计"
        elif area < 90:
            rooms_config = "标准三居室，客餐厅分离"
        elif area < 120:
            rooms_config = "舒适三居室，宽敞客厅"
        else:
            rooms_config = "大户型设计，多功能空间规划"
        
        return {
            "total_area": f"{area}㎡",
            "configuration": rooms_config,
            "lighting_analysis": "根据朝向设计自然采光方案" if hasattr(args, 'orientation') else "自然采光+人工照明结合",
            "ventilation": "南北通透设计，空气流通佳" if hasattr(args, 'orientation') else "建议合理开窗，确保通风"
        }
    
    def _generate_layout_plan(self, args: argparse.Namespace) -> Dict[str, Any]:
        """生成布局方案"""
        area = args.area
        
        # 基础布局
        layout = {
            "客厅": self.layout_suggestions.get("客厅", {}),
            "主卧": self.layout_suggestions.get("卧室", {}),
            "厨房": self.layout_suggestions.get("厨房", {}),
            "卫生间": self.layout_suggestions.get("卫生间", {})
        }
        
        # 根据面积调整
        if area < 60:
            layout["备注"] = "面积紧凑，建议开放式厨房，增加空间感"
        elif area > 120:
            layout["备注"] = "空间充裕，可考虑增加书房或衣帽间"
        
        return layout
    
    def _generate_furniture_plan(self, style_config: Dict) -> Dict[str, Any]:
        """生成家具方案"""
        return {
            "客厅": style_config["furniture"],
            "卧室": ["双人床", "床头柜", "衣柜", "梳妆台"],
            "餐厅": ["餐桌", "餐椅", "餐边柜"],
            "建议": "家具选择注重品质与风格的统一，建议统一在同一家具品牌选购"
        }
    
    def _generate_lighting_design(self, style: str) -> Dict[str, Any]:
        """生成照明设计"""
        if style in ["现代简约", "轻奢", "北欧"]:
            return {
                "type": "无主灯设计",
                "description": "采用筒灯+射灯+灯带的组合，均匀布光，可调节氛围",
                "设计方案": {
                    "客厅": "嵌入式筒灯（基础照明）+ 射灯（重点照明）+ 灯带（氛围照明）",
                    "卧室": "床头壁灯/吊灯+筒灯天花照明",
                    "厨房": "筒灯基础照明+操作台上方射灯",
                    "卫生间": "镜前灯+筒灯"
                }
            }
        elif style in ["新中式", "日式"]:
            return {
                "type": "主灯+辅助灯",
                "description": "保留主灯设计，配合氛围灯具，营造温馨感",
                "设计方案": {
                    "客厅": "新中式吊灯+壁灯+台灯组合",
                    "卧室": "中式台灯/吊灯+间接照明",
                    "餐厅": "新中式吊灯"
                }
            }
        else:
            return {
                "type": "混合设计",
                "description": "主灯+辅助灯组合，根据空间功能灵活配置"
            }
    
    def _generate_budget_estimate(self, args: argparse.Namespace) -> Dict[str, Any]:
        """生成预算估算"""
        area = args.area
        level = args.budget
        
        base_prices = {
            "低": 1200,
            "中等": 2000,
            "较高": 3500,
            "高": 6000
        }
        
        base_price = base_prices.get(level, 2000)
        total = area * base_price
        
        return {
            "单价参考": f"{base_price}元/㎡",
            "总价估算": f"{total/10000:.1f}-{total*1.1/10000:.1f}万元",
            "说明": "预算含硬装+软装，不含家具家电",
            "注": "具体价格受材料品牌、市场波动影响，建议预留10-15%弹性空间"
        }
    
    def _generate_timeline(self, area: float) -> Dict[str, Any]:
        """生成项目周期"""
        if area < 60:
            design_days = 7
            construction_days = 45
        elif area < 100:
            design_days = 14
            construction_days = 60
        elif area < 150:
            design_days = 21
            construction_days = 75
        else:
            design_days = 30
            construction_days = 90
        
        return {
            "设计阶段": f"{design_days}天",
            "施工阶段": f"{construction_days}天",
            "总工期": f"{design_days + construction_days}天",
            "各阶段": {
                "设计": ["需求沟通", "方案设计", "深化设计", "施工图"],
                "施工": ["拆改", "水电", "泥瓦", "木工", "油漆", "安装", "验收"]
            }
        }
    
    def format_proposal(self, proposal: Dict, format_type: str = "markdown") -> str:
        """格式化提案文档"""
        if format_type == "json":
            return json.dumps(proposal, ensure_ascii=False, indent=2)
        
        output = []
        output.append("# 📄 设计提案文档")
        output.append("")
        output.append(f"**项目名称**: {proposal['project_info']['name']}")
        output.append(f"**建筑面积**: {proposal['project_info']['area']}㎡")
        output.append(f"**设计风格**: {proposal['project_info']['style']}")
        output.append(f"**预算等级**: {proposal['project_info']['budget_level']}")
        output.append(f"**生成日期**: {proposal['generated_at']}")
        output.append("")
        output.append("---")
        output.append("")
        
        # 设计理念
        output.append("## 一、设计理念")
        output.append("")
        output.append(f"**主题**: {proposal['design_concept']['title']}")
        output.append("")
        output.append(f"{proposal['design_concept']['concept']}")
        output.append("")
        output.append(f"**关键词**: {', '.join(proposal['design_concept']['keywords'])}")
        output.append("")
        
        # 空间分析
        output.append("## 二、空间分析")
        output.append("")
        space = proposal['space_analysis']
        output.append(f"- **总面积**: {space['total_area']}")
        output.append(f"- **空间配置**: {space['configuration']}")
        output.append(f"- **采光分析**: {space['lighting_analysis']}")
        output.append(f"- **通风设计**: {space['ventilation']}")
        output.append("")
        
        # 布局方案
        output.append("## 三、空间布局方案")
        output.append("")
        for space_name, layout in proposal['layout_plan'].items():
            if space_name == "备注":
                continue
            output.append(f"### {space_name}")
            if "功能分区" in layout:
                output.append(f"- **功能分区**: {', '.join(layout['功能分区'])}")
            if "furniture_layout" in layout:
                output.append(f"- **家具布置**: {layout['furniture_layout']}")
            if "动线规划" in layout:
                output.append(f"- **动线规划**: {layout['动线规划']}")
            if "尺寸建议" in layout:
                output.append(f"- **尺寸建议**:")
                for k, v in layout["尺寸建议"].items():
                    output.append(f"  - {k}: {v}")
            output.append("")
        
        if "备注" in proposal['layout_plan']:
            output.append(f"**备注**: {proposal['layout_plan']['备注']}")
            output.append("")
        
        # 材料方案
        output.append("## 四、材料方案")
        output.append("")
        materials = proposal['material_scheme']
        for k, v in materials.items():
            output.append(f"- **{k}**: {v}")
        output.append("")
        
        # 色彩方案
        output.append("## 五、色彩方案")
        output.append("")
        colors = proposal['color_scheme']
        for k, v in colors.items():
            output.append(f"- **{k}**: {v}")
        output.append("")
        
        # 家具方案
        output.append("## 六、家具方案")
        output.append("")
        furniture = proposal['furniture_plan']
        for space, items in furniture.items():
            if space != "建议":
                output.append(f"- **{space}**: {', '.join(items)}")
        output.append(f"- **建议**: {furniture['建议']}")
        output.append("")
        
        # 照明设计
        output.append("## 七、照明设计")
        output.append("")
        lighting = proposal['lighting_design']
        output.append(f"- **类型**: {lighting['type']}")
        output.append(f"- **说明**: {lighting['description']}")
        if '设计方案' in lighting:
            output.append("- **设计方案**:")
            for space, design in lighting['设计方案'].items():
                output.append(f"  - {space}: {design}")
        output.append("")
        
        # 预算估算
        output.append("## 八、预算估算")
        output.append("")
        budget = proposal['budget_estimate']
        output.append(f"- **单价参考**: {budget['单价参考']}")
        output.append(f"- **总价估算**: {budget['总价估算']}")
        output.append(f"- **说明**: {budget['说明']}")
        output.append(f"- **注**: {budget['注']}")
        output.append("")
        
        # 项目周期
        output.append("## 九、项目周期")
        output.append("")
        timeline = proposal['timeline']
        output.append(f"- **设计阶段**: {timeline['设计阶段']}")
        output.append(f"- **施工阶段**: {timeline['施工阶段']}")
        output.append(f"- **总工期**: {timeline['总工期']}")
        output.append("")
        
        output.append("---")
        output.append("")
        output.append(f"*本提案由室内设计助手自动生成 | {proposal['generated_at']}*")
        
        return "\n".join(output)


def create_parser() -> argparse.ArgumentParser:
    """创建参数解析器"""
    parser = argparse.ArgumentParser(
        description="设计提案生成器 - 根据项目信息生成完整的设计提案文档",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例用法：
  python generate_design_proposal.py --area 120 --style 现代简约 --budget 中等 --output ./proposal/
  python generate_design_proposal.py -a 100 -s 轻奢 -b 较高 -p "李府雅居" -o proposal.md
  
支持的风格：现代简约、北欧、新中式、轻奢、日式、奶油风
支持的预算等级：低、中等、较高、高
        """
    )
    
    parser.add_argument(
        "-a", "--area",
        type=float,
        required=True,
        help="建筑面积（平方米）"
    )
    
    parser.add_argument(
        "-s", "--style",
        type=str,
        required=True,
        choices=["现代简约", "北欧", "新中式", "轻奢", "日式", "奶油风"],
        help="设计风格"
    )
    
    parser.add_argument(
        "-b", "--budget",
        type=str,
        required=True,
        choices=["低", "中等", "较高", "高"],
        help="预算等级"
    )
    
    parser.add_argument(
        "-p", "--project-name",
        type=str,
        help="项目名称"
    )
    
    parser.add_argument(
        "-o", "--output",
        type=str,
        help="输出文件/目录路径"
    )
    
    parser.add_argument(
        "-f", "--format",
        type=str,
        choices=["markdown", "json"],
        default="markdown",
        help="输出格式，默认为markdown"
    )
    
    return parser


def main():
    """主函数"""
    parser = create_parser()
    args = parser.parse_args()
    
    generator = DesignProposalGenerator()
    
    # 验证输入
    valid, error_msg = generator.validate_inputs(args)
    if not valid:
        print(f"❌ 参数错误: {error_msg}", file=sys.stderr)
        parser.print_help()
        sys.exit(1)
    
    try:
        proposal = generator.generate_proposal(args)
        output = generator.format_proposal(proposal, args.format)
        
        if args.output:
            # 如果指定了输出路径
            with open(args.output, 'w', encoding='utf-8') as f:
                f.write(output)
            # 同时保存JSON版本
            json_path = args.output.rsplit('.', 1)[0] + '.json'
            with open(json_path, 'w', encoding='utf-8') as f:
                f.write(json.dumps(proposal, ensure_ascii=False, indent=2))
            print(f"✅ 提案已保存至: {args.output}")
            print(f"✅ JSON数据已保存至: {json_path}")
        else:
            print(output)
        
    except Exception as e:
        print(f"❌ 生成出错: {str(e)}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
