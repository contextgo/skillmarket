#!/usr/bin/env python3
"""
酒店隔声合规检查脚本 - v2.4.0
用于酒店隔声设计合规性检查

功能：
1. 分户墙隔声量检查（对照GB 50118）
2. 楼板撞击声隔声检查
3. 客房门隔声检查
4. 管道隔声检查
5. 生成隔声合规报告

Author: interior-design-assistant v2.4.0
"""

import argparse
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple
from enum import Enum


class HotelClass(Enum):
    """酒店档次"""
    THREE_STAR = "三星级"
    FOUR_STAR = "四星级"
    FIVE_STAR = "五星级/奢华"


class SoundClass(Enum):
    """隔声等级"""
    CLASS_ONE = "一级（高标准）"
    CLASS_TWO = "二级（标准）"
    CLASS_THREE = "三级（一般）"


@dataclass
class SoundInsulation:
    """隔声指标"""
    name: str
    standard: str  # 规范值
    actual: float  # 实际值
    unit: str = "dB"
    
    def is_compliant(self) -> bool:
        """是否满足规范"""
        # 隔声量越大越好，撞击声压级越小越好
        if "Ln" in self.standard:  # 撞击声压级
            return self.actual <= float(self.standard.replace("Ln,w≤", "").replace("≤", ""))
        else:  # 空气声隔声量
            return self.actual >= float(self.standard.replace("Rw≥", "").replace("≥", ""))
    
    def get_diff(self) -> float:
        """与标准的差值"""
        if "Ln" in self.standard:
            return self.actual - float(self.standard.replace("Ln,w≤", "").replace("≤", ""))
        else:
            return self.actual - float(self.standard.replace("Rw≥", "").replace("≥", ""))


@dataclass
class SoundCheckResult:
    """隔声检查结果"""
    item: str
    standard_class: SoundClass
    standard_value: str
    actual_value: float
    unit: str
    passed: bool
    suggestion: str = ""


@dataclass
class SoundCheckReport:
    """隔声检查报告"""
    hotel_class: HotelClass
    results: List[SoundCheckResult] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)
    references: List[str] = field(default_factory=list)


class HotelAcousticChecker:
    """酒店隔声检查类"""
    
    # GB 50118-2010 旅馆建筑隔声标准
    WALL_INSULATION_STANDARDS = {
        # 部位: [一级, 二级, 三级]
        "客房与客房隔墙": ["Rw≥50dB", "Rw≥45dB", "Rw≥40dB"],
        "走廊与客房隔墙": ["Rw≥50dB", "Rw≥45dB", "Rw≥40dB"],
        "客房与电梯井道": ["Rw≥55dB", "Rw≥50dB", "Rw≥45dB"],
        "客房与管道井": ["Rw≥45dB", "Rw≥40dB", "Rw≥35dB"],
        "客房与楼梯间": ["Rw≥50dB", "Rw≥45dB", "Rw≥40dB"],
    }
    
    FLOOR_IMPACT_STANDARDS = {
        # 部位: [一级, 二级, 三级]
        "客房楼板": ["Ln,w≤65dB", "Ln,w≤75dB", "Ln,w≤85dB"],
    }
    
    DOOR_INSULATION_STANDARDS = {
        "客房与走廊门": ["Rw+C≥30dB", "Rw+C≥25dB", "Rw+C≥20dB"],
    }
    
    # 五星/奢华酒店推荐值（高于GB 50118标准）
    LUXURY_HOTEL_RECOMMENDED = {
        "客房分户墙Rw": 55,
        "楼板空气声Rw": 55,
        "楼板撞击声Ln,w": 55,
        "客房门Rw+C": 32,
    }
    
    def __init__(self, hotel_class: HotelClass):
        self.hotel_class = hotel_class
    
    def _get_standard_index(self) -> int:
        """获取标准等级索引"""
        maps = {
            HotelClass.THREE_STAR: 2,  # 三级标准
            HotelClass.FOUR_STAR: 1,   # 二级标准
            HotelClass.FIVE_STAR: 0,   # 一级标准
        }
        return maps.get(self.hotel_class, 1)
    
    def _get_standard_class(self) -> SoundClass:
        """获取标准等级"""
        maps = {
            HotelClass.THREE_STAR: SoundClass.CLASS_THREE,
            HotelClass.FOUR_STAR: SoundClass.CLASS_TWO,
            HotelClass.FIVE_STAR: SoundClass.CLASS_ONE,
        }
        return maps.get(self.hotel_class, SoundClass.CLASS_TWO)
    
    def check_partition_wall(self, wall_type: str, actual_rw: float) -> SoundCheckResult:
        """检查分户墙隔声"""
        standards = self.WALL_INSULATION_STANDARDS.get(
            wall_type, 
            self.WALL_INSULATION_STANDARDS["客房与客房隔墙"]
        )
        idx = self._get_standard_index()
        standard = standards[idx]
        standard_class = self._get_standard_class()
        
        passed = actual_rw >= float(standard.replace("Rw≥", ""))
        diff = actual_rw - float(standard.replace("Rw≥", ""))
        
        suggestion = ""
        if not passed:
            suggestion = f"隔声量不足{diff:.0f}dB，建议：1)增加墙体厚度 2)采用双排龙骨 3)内部填充矿棉"
        elif diff >= 5:
            suggestion = "满足规范且有一定余量"
        else:
            suggestion = "刚好满足规范，可适当优化"
        
        # 五星酒店额外检查
        if self.hotel_class == HotelClass.FIVE_STAR and actual_rw < self.LUXURY_HOTEL_RECOMMENDED["客房分户墙Rw"]:
            suggestion += f"\n   ⚠️ 五星酒店建议达到{self.LUXURY_HOTEL_RECOMMENDED['客房分户墙Rw']}dB以提升隔音品质"
        
        return SoundCheckResult(
            item=f"分户墙隔声 - {wall_type}",
            standard_class=standard_class,
            standard_value=standard,
            actual_value=actual_rw,
            unit="dB",
            passed=passed,
            suggestion=suggestion
        )
    
    def check_floor_impact(self, actual_ln: float) -> SoundCheckResult:
        """检查楼板撞击声隔声"""
        standards = self.FLOOR_IMPACT_STANDARDS["客房楼板"]
        idx = self._get_standard_index()
        standard = standards[idx]
        standard_class = self._get_standard_class()
        
        # 撞击声压级越低越好
        limit = float(standard.replace("Ln,w≤", ""))
        passed = actual_ln <= limit
        diff = actual_ln - limit
        
        suggestion = ""
        if not passed:
            suggestion = f"撞击声超标{diff:.0f}dB，建议：1)增设隔声垫层 2)采用浮筑楼板 3)铺设地毯"
        elif diff <= -10:
            suggestion = "撞击声控制良好，隔声效果优秀"
        else:
            suggestion = "满足规范要求"
        
        # 五星酒店额外检查
        if self.hotel_class == HotelClass.FIVE_STAR and actual_ln > self.LUXURY_HOTEL_RECOMMENDED["楼板撞击声Ln,w"]:
            suggestion += f"\n   ⚠️ 五星酒店建议控制在{self.LUXURY_HOTEL_RECOMMENDED['楼板撞击声Ln,w']}dB以内"
        
        return SoundCheckResult(
            item="楼板撞击声隔声",
            standard_class=standard_class,
            standard_value=standard,
            actual_value=actual_ln,
            unit="dB",
            passed=passed,
            suggestion=suggestion
        )
    
    def check_door_insulation(self, actual_rw_c: float) -> SoundCheckResult:
        """检查门隔声"""
        standards = self.DOOR_INSULATION_STANDARDS["客房与走廊门"]
        idx = self._get_standard_index()
        standard = standards[idx]
        standard_class = self._get_standard_class()
        
        limit = float(standard.replace("Rw+C≥", ""))
        passed = actual_rw_c >= limit
        diff = actual_rw_c - limit
        
        suggestion = ""
        if not passed:
            suggestion = f"门隔声不足{diff:.0f}dB，建议：1)选用专业隔声门 2)门底设自动密封条 3)门框设弹性密封条"
        else:
            suggestion = "门隔声满足要求"
        
        return SoundCheckResult(
            item="客房门隔声",
            standard_class=standard_class,
            standard_value=standard,
            actual_value=actual_rw_c,
            unit="dB",
            passed=passed,
            suggestion=suggestion
        )
    
    def check_window_insulation(self, actual_rw_c: float) -> SoundCheckResult:
        """检查外窗隔声"""
        # 外窗隔声参考值
        standards_map = {
            HotelClass.THREE_STAR: "Rw+C≥30dB",
            HotelClass.FOUR_STAR: "Rw+C≥35dB",
            HotelClass.FIVE_STAR: "Rw+C≥40dB",
        }
        standard = standards_map.get(self.hotel_class, "Rw+C≥30dB")
        standard_class = self._get_standard_class()
        
        limit = float(standard.replace("Rw+C≥", ""))
        passed = actual_rw_c >= limit
        diff = actual_rw_c - limit
        
        suggestion = ""
        if not passed:
            suggestion = f"外窗隔声不足，建议选用中空夹胶玻璃或三层中空玻璃"
        else:
            suggestion = "外窗隔声满足要求"
        
        return SoundCheckResult(
            item="外窗隔声",
            standard_class=standard_class,
            standard_value=standard,
            actual_value=actual_rw_c,
            unit="dB",
            passed=passed,
            suggestion=suggestion
        )
    
    def calculate_wall_construction(self, target_rw: float) -> List[Dict]:
        """推荐墙体构造"""
        constructions = []
        
        # 不同隔声量的推荐构造
        if target_rw >= 55:
            constructions.append({
                "target": "≥55dB",
                "construction": "120mm加气混凝土+双面双层12mm石膏板+双排50mm轻钢龙骨(填岩棉)",
                "approx_rw": "55-58dB"
            })
        elif target_rw >= 50:
            constructions.append({
                "target": "≥50dB",
                "construction": "100mm轻钢龙骨(双排)+双面双层12mm石膏板+50mm岩棉",
                "approx_rw": "50-55dB"
            })
        elif target_rw >= 45:
            constructions.append({
                "target": "≥45dB",
                "construction": "75mm轻钢龙骨+双面12mm石膏板+50mm岩棉",
                "approx_rw": "45-50dB"
            })
        else:
            constructions.append({
                "target": "≥40dB",
                "construction": "75mm轻钢龙骨+双面12mm石膏板+50mm岩棉",
                "approx_rw": "42-48dB"
            })
        
        return constructions
    
    def generate_report(self, 
                        partition_rw: float = 50.0,
                        floor_ln: float = 70.0,
                        door_rw_c: float = 28.0,
                        window_rw_c: float = 32.0) -> SoundCheckReport:
        """生成隔声检查报告"""
        report = SoundCheckReport(hotel_class=self.hotel_class)
        
        # 分户墙检查
        report.results.append(self.check_partition_wall("客房与客房隔墙", partition_rw))
        report.results.append(self.check_partition_wall("走廊与客房隔墙", partition_rw))
        
        # 楼板撞击声检查
        report.results.append(self.check_floor_impact(floor_ln))
        
        # 门隔声检查
        report.results.append(self.check_door_insulation(door_rw_c))
        
        # 外窗隔声检查
        report.results.append(self.check_window_insulation(window_rw_c))
        
        # 规范说明
        report.references.extend([
            "GB 50118-2010《民用建筑隔声设计规范》",
            "GB/T 50121《建筑隔声评价标准》",
            "⚠️ 具体项目应以设计任务书和当地规范为准"
        ])
        
        return report
    
    def print_report(self, report: SoundCheckReport) -> None:
        """打印报告"""
        print("\n" + "=" * 70)
        print("🔊 酒店隔声合规检查报告")
        print("=" * 70)
        
        print(f"\n酒店档次: {report.hotel_class.value}")
        print(f"检查日期: 自动生成")
        
        print("\n" + "-" * 70)
        print("📋 隔声检查结果汇总")
        print("-" * 70)
        
        passed_count = 0
        failed_count = 0
        
        for result in report.results:
            status = "✅ 通过" if result.passed else "❌ 不合格"
            if result.passed:
                passed_count += 1
            else:
                failed_count += 1
            
            print(f"\n【{result.item}】")
            print(f"  标准等级: {result.standard_class.value}")
            print(f"  规范要求: {result.standard_value}")
            print(f"  实测/设计值: {result.actual_value} {result.unit}")
            print(f"  检查结果: {status}")
            if result.suggestion:
                print(f"  💡 {result.suggestion}")
        
        print("\n" + "-" * 70)
        print(f"📊 检查统计: ✅ 通过 {passed_count} 项 | ❌ 不合格 {failed_count} 项")
        
        # 构造推荐
        print("\n" + "-" * 70)
        print("🧱 推荐隔声构造")
        print("-" * 70)
        
        for result in report.results:
            if "分户墙" in result.item and result.passed:
                constructions = self.calculate_wall_construction(result.actual_value)
                for c in constructions:
                    print(f"\n目标隔声量 {c['target']}:")
                    print(f"  构造: {c['construction']}")
                    print(f"  预计Rw: {c['approx_rw']}")
                break
        
        # 五星酒店特别提示
        if report.hotel_class == HotelClass.FIVE_STAR:
            print("\n" + "-" * 70)
            print("⭐ 五星/奢华酒店隔声建议（高于GB 50118）")
            print("-" * 70)
            print("  • 客房分户墙 Rw≥55dB")
            print("  • 楼板空气声 Rw≥55dB")
            print("  • 楼板撞击声 Ln,w≤55dB")
            print("  • 客房门 Rw+C≥32dB")
            print("  • 外窗 Rw+C≥40dB")
        
        print("\n" + "-" * 70)
        print("📚 规范依据")
        print("-" * 70)
        for ref in report.references:
            print(f"  • {ref}")
        
        print("\n" + "=" * 70)
        print("⚠️ 本报告仅供参考，实际隔声效果应以检测报告为准")
        print("=" * 70)


def main():
    """主函数"""
    parser = argparse.ArgumentParser(
        description="酒店隔声合规检查工具 - v2.4.0",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用示例:
  python check_hotel_acoustic.py --class five_star --partition 52 --floor 65
  python check_hotel_acoustic.py --class four_star --door 25
  python check_hotel_acoustic.py --class three_star --window 28

隔声参数说明:
  --partition  客房分户墙空气声隔声量 Rw (dB)
  --floor      楼板撞击声隔声量 Ln,w (dB)，越小越好
  --door       客房门隔声量 Rw+C (dB)
  --window     外窗隔声量 Rw+C (dB)

规范依据:
  GB 50118-2010《民用建筑隔声设计规范》

注意事项:
  1. 不确定的数据请标注"需根据项目实际情况核实"
  2. 建议在设计阶段进行声学模拟验证
  3. 施工后应进行隔声检测验收
        """
    )
    
    parser.add_argument("--class", "-c",
                        choices=["three_star", "four_star", "five_star"],
                        default="four_star",
                        help="酒店档次")
    parser.add_argument("--partition", "-p", type=float, default=50.0,
                        help="分户墙隔声量 Rw (dB)，默认50dB")
    parser.add_argument("--floor", "-f", type=float, default=70.0,
                        help="楼板撞击声 Ln,w (dB)，默认70dB")
    parser.add_argument("--door", "-d", type=float, default=28.0,
                        help="客房门隔声 Rw+C (dB)，默认28dB")
    parser.add_argument("--window", "-w", type=float, default=32.0,
                        help="外窗隔声 Rw+C (dB)，默认32dB")
    parser.add_argument("--calculate", action="store_true",
                        help="根据目标隔声量推荐构造做法")
    parser.add_argument("--target", "-t", type=float, default=50.0,
                        help="目标隔声量（与--calculate配合使用）")
    
    args = parser.parse_args()
    
    # 参数映射
    hotel_class_map = {
        "three_star": HotelClass.THREE_STAR,
        "four_star": HotelClass.FOUR_STAR,
        "five_star": HotelClass.FIVE_STAR,
    }
    
    hotel_class = hotel_class_map[args.class]
    
    # 创建检查器
    checker = HotelAcousticChecker(hotel_class)
    
    # 如果指定了构造计算
    if args.calculate:
        print("\n" + "=" * 70)
        print("🧱 隔声构造推荐")
        print("=" * 70)
        print(f"\n目标隔声量: Rw ≥ {args.target} dB")
        print("-" * 70)
        
        constructions = checker.calculate_wall_construction(args.target)
        for c in constructions:
            print(f"\n推荐构造:")
            print(f"  {c['construction']}")
            print(f"  预计隔声量: {c['approx_rw']}")
        
        print("\n" + "=" * 70)
        return
    
    # 执行隔声检查
    report = checker.generate_report(
        partition_rw=args.partition,
        floor_ln=args.floor,
        door_rw_c=args.door,
        window_rw_c=args.window
    )
    
    # 输出报告
    checker.print_report(report)


if __name__ == "__main__":
    main()
