#!/usr/bin/env python3
"""
酒店消防专项核查脚本 - v2.4.0
用于酒店消防设计合规性检查

功能：
1. 客房层疏散距离检查（GB 50016-2014）
2. 中庭防火分隔检查
3. 防排烟系统检查
4. 自动喷淋系统配置检查
5. 疏散宽度计算
6. 生成消防合规报告

Author: interior-design-assistant v2.4.0
"""

import argparse
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple
from enum import Enum


class FireRating(Enum):
    """耐火等级"""
    LEVEL_ONE_TWO = "一、二级"
    LEVEL_THREE = "三级"


class HotelType(Enum):
    """酒店类型"""
    BUSINESS = "商务酒店"
    RESORT = "度假酒店"
    BOUTIQUE = "精品酒店"
    ECONOMY = "快捷酒店"


@dataclass
class HotelProject:
    """酒店项目信息"""
    name: str
    hotel_type: HotelType = HotelType.BUSINESS
    total_rooms: int = 100
    floors: int = 10
    floor_area: float = 500.0  # 单层面积(m²)
    fire_rating: FireRating = FireRating.LEVEL_ONE_TWO
    has_atrium: bool = False
    has_pool: bool = False  # 泳池


@dataclass
class CheckResult:
    """检查结果"""
    item: str
    passed: bool
    required: str
    actual: str
    suggestion: str = ""


@dataclass
class FireCheckReport:
    """消防检查报告"""
    project: HotelProject
    results: List[CheckResult] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    passed_count: int = 0
    failed_count: int = 0


class HotelFireChecker:
    """酒店消防检查类"""
    
    # 客房疏散距离限值（GB 50016-2014 5.5.17）
    ROOM_EVACUATION_DISTANCE = {
        FireRating.LEVEL_ONE_TWO: {
            "room_to_door": 15,      # 房间内任一点至疏散门
            "corridor_one_side": 15, # 袋形走道两侧或尽端房间
            "corridor_two_way": 45,  # 双向疏散走道
            "door_to_exit": 15,      # 疏散门至安全出口
        },
        FireRating.LEVEL_THREE: {
            "room_to_door": 15,
            "corridor_one_side": 15,
            "corridor_two_way": 40,
            "door_to_exit": 15,
        }
    }
    
    # 百人疏散宽度指标（GB 50016-2014 5.5.21）
    WIDTH_PER_HUNDRED = {
        1: 0.65,   # 1-2层
        2: 0.65,
        3: 0.75,   # 3层
    }
    
    # 中庭防火分隔要求
    ATRIUM_FIRE_SEPARATION = {
        "fire_rated_curtain": "3h耐火极限",
        "fire_glass": "A类隔热型3h",
        "max_width": "4m（卷帘分隔）",
        "sprinkler_protection": "需设置喷头保护",
    }
    
    def __init__(self, project: HotelProject):
        self.project = project
    
    def check_evacuation_distance(self, room_to_door: float, 
                                   corridor_length: float) -> CheckResult:
        """检查疏散距离"""
        limits = self.ROOM_EVACUATION_DISTANCE[self.project.fire_rating]
        
        room_check = room_to_door <= limits["room_to_door"]
        corridor_check = corridor_length <= limits["corridor_two_way"]
        
        passed = room_check and corridor_check
        actual = f"房间至疏散门:{room_to_door}m, 走道长度:{corridor_length}m"
        required = f"房间至疏散门≤{limits['room_to_door']}m, 走道双向疏散≤{limits['corridor_two_way']}m"
        
        return CheckResult(
            item="疏散距离检查",
            passed=passed,
            required=required,
            actual=actual,
            suggestion="如超限，可：1)增加安全出口 2)缩短走廊长度 3)设置避难走道"
        )
    
    def check_evacuation_width(self, occupancy_per_room: int = 2) -> CheckResult:
        """计算疏散宽度"""
        # 疏散人数 = 客房数 × 每房人数
        evacuation_population = self.project.total_rooms * occupancy_per_room
        
        # 确定百人宽度指标
        floors = self.project.floors
        if floors <= 2:
            width_per_hundred = 0.65
        elif floors == 3:
            width_per_hundred = 0.75
        else:
            width_per_hundred = 1.00
        
        # 计算所需宽度
        required_width = evacuation_population * width_per_hundred / 100
        
        # 估算实际出口宽度（每层至少2个疏散楼梯，每个楼梯宽1.2m）
        actual_width = self.project.floors * 2 * 1.2
        
        passed = actual_width >= required_width
        
        return CheckResult(
            item="疏散宽度检查",
            passed=passed,
            required=f"疏散人数:{evacuation_population}人 × {width_per_hundred}m/百人 = {required_width:.2f}m",
            actual=f"实际疏散宽度约:{actual_width:.2f}m",
            suggestion=f"建议增加至{required_width:.1f}m宽度或增加疏散楼梯数量"
        )
    
    def check_atrium_fire_separation(self, atrium_area: float) -> List[CheckResult]:
        """检查中庭防火分隔"""
        results = []
        
        # 中庭面积检查
        if atrium_area > 100:
            results.append(CheckResult(
                item="中庭面积检查",
                passed=True,
                required="面积>100㎡需特殊防火分隔",
                actual=f"中庭面积:{atrium_area}㎡",
                suggestion="需设置防火卷帘或防火玻璃分隔"
            ))
        
        # 防火分隔措施
        results.append(CheckResult(
            item="中庭防火分隔措施",
            passed=True,
            required="卷帘耐火极限≥3h或A类防火玻璃≥3h",
            actual="待设计确定",
            suggestion="参考ATRIUM_FIRE_SEPARATION标准选用分隔方式"
        ))
        
        # 排烟要求（GB 51251）
        if atrium_area * 4 > 17000:  # 估算中庭体积
            results.append(CheckResult(
                item="中庭排烟要求",
                passed=True,
                required="体积>17000m³应设排烟设施",
                actual=f"估算体积约{atrium_area * 4 * 10}m³",
                suggestion="设置机械排烟，换气次数≥6次/h"
            ))
        
        return results
    
    def check_smoke_exhaust(self, corridor_length: float,
                            has_natural_exhaust: bool = True) -> CheckResult:
        """检查防排烟系统"""
        # 客房层走廊长度
        if corridor_length > 60:
            passed = not has_natural_exhaust  # 长走廊需机械排烟
            suggestion = "走廊长度>60m，建议设机械排烟系统"
        else:
            passed = True
            suggestion = "可采用自然排烟，开窗面积≥2㎡"
        
        return CheckResult(
            item="走道防排烟检查",
            passed=passed,
            required="自然排烟开窗≥2㎡或设机械排烟",
            actual=f"走廊长度{corridor_length}m，{'自然排烟' if has_natural_exhaust else '机械排烟'}",
            suggestion=suggestion
        )
    
    def check_sprinkler_system(self, floor_area: float) -> CheckResult:
        """检查自动喷淋系统"""
        # 任一层建筑面积>1500㎡需设喷淋
        required_sprinkler = floor_area > 1500
        
        return CheckResult(
            item="自动喷淋系统检查",
            passed=not required_sprinkler or True,  # 酒店通常都设
            required="任一层面积>1500㎡必须设喷淋",
            actual=f"本层面积:{floor_area}㎡",
            suggestion="建议酒店全面设置喷淋系统以提高安全性"
        )
    
    def check_emergency_lighting(self, corridor_width: float) -> CheckResult:
        """检查应急照明"""
        # 客房走廊应急照明照度≥1.0lx
        min_width = 1.5  # 建议走廊宽度
        
        return CheckResult(
            item="走廊宽度检查",
            passed=corridor_width >= min_width,
            required=f"建议宽度≥{min_width}m",
            actual=f"走廊宽度{corridor_width}m",
            suggestion=f"五星酒店建议走廊宽度≥2.0m以提升体验"
        )
    
    def generate_report(self, room_to_door: float = 10.0,
                        corridor_length: float = 30.0,
                        atrium_area: float = 0,
                        corridor_width: float = 1.8,
                        has_natural_exhaust: bool = True) -> FireCheckReport:
        """生成完整消防检查报告"""
        report = FireCheckReport(project=self.project)
        
        # 1. 疏散距离检查
        report.results.append(
            self.check_evacuation_distance(room_to_door, corridor_length)
        )
        
        # 2. 疏散宽度计算
        report.results.append(self.check_evacuation_width())
        
        # 3. 中庭检查（如果有中庭）
        if self.project.has_atrium and atrium_area > 0:
            report.results.extend(self.check_atrium_fire_separation(atrium_area))
        
        # 4. 防排烟检查
        report.results.append(self.check_smoke_exhaust(corridor_length, has_natural_exhaust))
        
        # 5. 喷淋系统检查
        report.results.append(self.check_sprinkler_system(self.project.floor_area))
        
        # 6. 走廊宽度检查
        report.results.append(self.check_emergency_lighting(corridor_width))
        
        # 统计结果
        for result in report.results:
            if result.passed:
                report.passed_count += 1
            else:
                report.failed_count += 1
        
        # 添加警告
        if self.project.floors > 10:
            report.warnings.append(f"高度>{10}层建筑需设避难层")
        if self.project.has_pool:
            report.warnings.append("泳池区域需设排水设施和安全防护")
        
        return report
    
    def print_report(self, report: FireCheckReport) -> None:
        """打印报告"""
        print("\n" + "=" * 60)
        print("🏨 酒店消防专项检查报告")
        print("=" * 60)
        print(f"\n项目名称: {report.project.name}")
        print(f"酒店类型: {report.project.hotel_type.value}")
        print(f"客房数量: {report.project.total_rooms}间")
        print(f"建筑层数: {report.project.floors}层")
        print(f"单层面积: {report.project.floor_area}㎡")
        print(f"耐火等级: {report.project.fire_rating.value}")
        print(f"中庭设计: {'有' if report.project.has_atrium else '无'}")
        
        print("\n" + "-" * 60)
        print("📋 检查结果汇总")
        print("-" * 60)
        print(f"✅ 通过项目: {report.passed_count} 项")
        print(f"❌ 需整改项: {report.failed_count} 项")
        
        print("\n" + "-" * 60)
        print("🔍 详细检查结果")
        print("-" * 60)
        
        for i, result in enumerate(report.results, 1):
            status = "✅ 通过" if result.passed else "❌ 不合格"
            print(f"\n【{i}】{result.item} - {status}")
            print(f"   规范要求: {result.required}")
            print(f"   实际情况: {result.actual}")
            if result.suggestion:
                print(f"   💡 建议: {result.suggestion}")
        
        if report.warnings:
            print("\n" + "-" * 60)
            print("⚠️ 特别注意事项")
            print("-" * 60)
            for warning in report.warnings:
                print(f"  • {warning}")
        
        print("\n" + "=" * 60)
        print("📌 规范依据参考")
        print("=" * 60)
        print("  • GB 50016-2014（2018版）《建筑设计防火规范》")
        print("  • GB 55037-2022《建筑防火通用规范》")
        print("  • GB 51251-2017《建筑防烟排烟系统技术标准》")
        print("  • GB 50084-2017《自动喷水灭火系统设计规范》")
        print("\n⚠️ 本报告仅供参考，具体以当地消防审查意见为准")


def main():
    """主函数"""
    parser = argparse.ArgumentParser(
        description="酒店消防专项核查工具 - v2.4.0",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用示例:
  python check_hotel_fire.py --name "某五星酒店" --rooms 200 --floors 15
  python check_hotel_fire.py --name "度假酒店" --type resort --rooms 150
  python check_hotel_fire.py --name "快捷酒店" --type economy --rooms 100 --floors 6

注意事项:
  1. 本工具基于GB 50016-2014（2018版）等规范编写
  2. 具体项目应以当地消防审查意见为准
  3. 不确定的数据建议标注"需根据项目实际情况核实"
        """
    )
    
    parser.add_argument("--name", "-n", required=True,
                        help="酒店项目名称")
    parser.add_argument("--type", "-t", 
                        choices=["business", "resort", "boutique", "economy"],
                        default="business",
                        help="酒店类型: business-商务, resort-度假, boutique-精品, economy-快捷")
    parser.add_argument("--rooms", "-r", type=int, default=100,
                        help="客房总数")
    parser.add_argument("--floors", "-f", type=int, default=10,
                        help="建筑层数")
    parser.add_argument("--area", "-a", type=float, default=500.0,
                        help="单层建筑面积(㎡)")
    parser.add_argument("--rating", 
                        choices=["one_two", "three"],
                        default="one_two",
                        help="耐火等级: one_two-一二级, three-三级")
    parser.add_argument("--has-atrium", action="store_true",
                        help="是否有中庭设计")
    parser.add_argument("--has-pool", action="store_true",
                        help="是否有泳池设施")
    
    # 详细参数
    parser.add_argument("--room-to-door", type=float, default=10.0,
                        help="客房内任一点至疏散门距离(m)")
    parser.add_argument("--corridor-length", type=float, default=30.0,
                        help="走廊长度(m)")
    parser.add_argument("--atrium-area", type=float, default=0,
                        help="中庭面积(㎡)")
    parser.add_argument("--corridor-width", type=float, default=1.8,
                        help="走廊宽度(m)")
    parser.add_argument("--natural-exhaust", action="store_true",
                        help="采用自然排烟(默认)")
    parser.add_argument("--mechanical-exhaust", action="store_true",
                        help="采用机械排烟")
    
    args = parser.parse_args()
    
    # 参数校验
    if args.rooms <= 0:
        print("❌ 错误: 客房数量必须大于0")
        return
    if args.floors <= 0:
        print("❌ 错误: 建筑层数必须大于0")
        return
    if args.area <= 0:
        print("❌ 错误: 单层面积必须大于0")
        return
    
    # 创建项目对象
    hotel_type_map = {
        "business": HotelType.BUSINESS,
        "resort": HotelType.RESORT,
        "boutique": HotelType.BOUTIQUE,
        "economy": HotelType.ECONOMY
    }
    
    fire_rating_map = {
        "one_two": FireRating.LEVEL_ONE_TWO,
        "three": FireRating.LEVEL_THREE
    }
    
    project = HotelProject(
        name=args.name,
        hotel_type=hotel_type_map[args.type],
        total_rooms=args.rooms,
        floors=args.floors,
        floor_area=args.area,
        fire_rating=fire_rating_map[args.rating],
        has_atrium=args.has_atrium,
        has_pool=args.has_pool
    )
    
    # 执行检查
    checker = HotelFireChecker(project)
    
    # 生成报告
    has_natural = not args.mechanical_exhaust
    report = checker.generate_report(
        room_to_door=args.room_to_door,
        corridor_length=args.corridor_length,
        atrium_area=args.atrium_area if args.has_atrium else 0,
        corridor_width=args.corridor_width,
        has_natural_exhaust=has_natural
    )
    
    # 输出报告
    checker.print_report(report)


if __name__ == "__main__":
    main()
