#!/usr/bin/env python3
"""
酒店动线规划脚本 - v2.4.0
用于宾客/服务/布草三条动线规划

功能：
1. 宾客动线规划
2. 员工服务动线规划
3. 布草物流动线规划
4. 货物流线规划
5. 动线交叉点分析
6. 生成动线规划报告

Author: interior-design-assistant v2.4.0
"""

import argparse
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple, Set
from enum import Enum


class HotelZone(Enum):
    """酒店功能区"""
    GUEST_ROOM = "客房区"
    LOBBY = "大堂区"
    RESTAURANT = "餐饮区"
    BANQUET = "宴会会议区"
    FITNESS = "康体区"
    BACK_HOUSE = "后场区"
    SERVICE_CORE = "服务核心"
    PARKING = "停车区"
    LOADING = "卸货区"


@dataclass
class CirculationNode:
    """动线节点"""
    name: str
    zone: HotelZone
    flow_type: str  # 宾客/员工/布草/货物
    width: float  # 通道宽度(m)
    is_accessible: bool = True  # 是否可达
    is_shared: bool = False  # 是否与其他动线共用


@dataclass
class CirculationFlow:
    """动线"""
    name: str
    flow_type: str  # 宾客/员工/布草/货物
    nodes: List[str]  # 节点名称列表
    width: float  # 建议宽度
    separation_required: bool = True  # 是否需要与其他动线分离
    crossing_points: List[str] = field(default_factory=list)  # 交叉点


@dataclass
class CirculationReport:
    """动线规划报告"""
    project_name: str
    total_rooms: int
    flows: Dict[str, CirculationFlow] = field(default_factory=dict)
    crossing_points: List[Dict] = field(default_factory=list)
    recommendations: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)


class HotelCirculationPlanner:
    """酒店动线规划类"""
    
    # 通道宽度标准
    WIDTH_STANDARDS = {
        "宾客主通道": 2.0,
        "宾客次通道": 1.5,
        "员工通道": 1.2,
        "服务通道": 1.5,
        "布草通道": 1.5,
        "餐车通道": 1.5,
        "行李通道": 1.8,
        "卸货通道": 3.0,
        "电梯厅": 2.0,
        "走廊(五星)": 1.8,
        "走廊(五星推荐)": 2.0,
        "电梯(客梯)": 1.6,
        "电梯(货梯)": 1.8,
    }
    
    def __init__(self, project_name: str, total_rooms: int):
        self.project_name = project_name
        self.total_rooms = total_rooms
    
    def plan_guest_flow(self, has_luggage_storage: bool = True) -> CirculationFlow:
        """规划宾客动线"""
        nodes = [
            "主入口",
            "落客区",
            "大堂接待",
            "前台办理",
            "电梯厅",
            "电梯",
            "客房层走廊",
            "客房"
        ]
        
        if has_luggage_storage:
            nodes.insert(4, "行李服务")
        
        return CirculationFlow(
            name="宾客动线",
            flow_type="宾客",
            nodes=nodes,
            width=2.0,
            separation_required=True,
            crossing_points=["与员工动线交叉点", "与服务动线交叉点"]
        )
    
    def plan_staff_flow(self) -> CirculationFlow:
        """规划员工服务动线"""
        nodes = [
            "员工入口",
            "员工更衣",
            "员工通道",
            "楼层服务间",
            "布草配送",
            "客房服务",
            "物品补给"
        ]
        
        return CirculationFlow(
            name="员工服务动线",
            flow_type="员工",
            nodes=nodes,
            width=1.5,
            separation_required=True,
            crossing_points=["与宾客动线交叉点"]
        )
    
    def plan_linen_flow(self) -> CirculationFlow:
        """规划布草动线"""
        nodes = [
            "洗衣房/布草房",
            "干净布草储存",
            "货梯/布草梯",
            "楼层服务间",
            "布草更换",
            "脏布草回收",
            "货梯/布草梯",
            "洗衣房"
        ]
        
        return CirculationFlow(
            name="布草物流动线",
            flow_type="布草",
            nodes=nodes,
            width=1.5,
            separation_required=True,
            crossing_points=["与员工动线共用段"]
        )
    
    def plan_goods_flow(self) -> CirculationFlow:
        """规划货物流线"""
        nodes = [
            "卸货区",
            "收货区",
            "验收区",
            "仓库",
            "货梯",
            "楼层备餐间",
            "各使用点"
        ]
        
        return CirculationFlow(
            name="货物流线",
            flow_type="货物",
            nodes=nodes,
            width=2.0,
            separation_required=True,
            crossing_points=["卸货区与垃圾区交叉"]
        )
    
    def plan_trash_flow(self) -> CirculationFlow:
        """规划垃圾动线"""
        nodes = [
            "楼层服务间",
            "垃圾暂存",
            "货梯/垃圾梯",
            "垃圾房",
            "外运"
        ]
        
        return CirculationFlow(
            name="垃圾清运动线",
            flow_type="垃圾",
            nodes=nodes,
            width=1.5,
            separation_required=True,
            crossing_points=["与宾客动线必须分离"]
        )
    
    def analyze_crossing_points(self, flows: List[CirculationFlow]) -> List[Dict]:
        """分析动线交叉点"""
        crossing_points = []
        
        # 宾客与员工的必要交叉
        crossing_points.append({
            "location": "大堂前台区域",
            "flows": ["宾客动线", "员工动线"],
            "risk": "中",
            "solution": "设置员工专用通道，与宾客流线保持1m以上距离"
        })
        
        # 布草与宾客的隔离检查
        guest_flow = next((f for f in flows if f.flow_type == "宾客"), None)
        linen_flow = next((f for f in flows if f.flow_type == "布草"), None)
        
        if guest_flow and linen_flow:
            crossing_points.append({
                "location": "电梯厅",
                "flows": ["宾客动线", "布草动线"],
                "risk": "高",
                "solution": "建议设置独立布草电梯，与客梯分离"
            })
        
        # 货物与宾客的隔离
        goods_flow = next((f for f in flows if f.flow_type == "货物"), None)
        if goods_flow:
            crossing_points.append({
                "location": "卸货区/后勤入口",
                "flows": ["货物流线", "宾客动线"],
                "risk": "高",
                "solution": "宾客入口与卸货区必须分离，设置独立后勤入口"
            })
        
        return crossing_points
    
    def generate_recommendations(self, flows: List[CirculationFlow]) -> List[str]:
        """生成动线规划建议"""
        recommendations = []
        
        # 基础建议
        recommendations.extend([
            "宾客动线与服务动线应在垂直方向和水平方向同时分离",
            "员工通道与宾客通道应设物理分隔或时间差管理",
            "布草电梯应与客梯分离，设置于服务电梯厅内",
            "卸货区、垃圾房应设置于建筑背面或地下，避免影响宾客",
            "服务间应设置于每层电梯厅附近，便于服务半径覆盖",
            "员工更衣室、卫生间应与服务动线直接连通",
        ])
        
        # 根据规模建议
        if self.total_rooms >= 300:
            recommendations.append("大型酒店建议设置独立的后勤通道系统，与宾客完全分离")
            recommendations.append("建议设置员工专用电梯，与客梯分离")
        
        if self.total_rooms >= 500:
            recommendations.append("超大型酒店建议设置多个后勤卸货点，分散物流压力")
            recommendations.append("建议设置集中布草处理中心，减少楼层布草间面积")
        
        return recommendations
    
    def generate_warnings(self) -> List[str]:
        """生成警告信息"""
        warnings = []
        
        warnings.append("宾客流线与后勤流线必须保持分离，避免宾客看到服务人员或设备")
        warnings.append("垃圾动线应全封闭处理，避免异味影响宾客区域")
        warnings.append("厨房与客房之间应避免直接连通，防止串味")
        warnings.append("洗衣房应设置独立出入口，与酒店主入口保持距离")
        
        return warnings
    
    def generate_report(self) -> CirculationReport:
        """生成动线规划报告"""
        report = CirculationReport(
            project_name=self.project_name,
            total_rooms=self.total_rooms
        )
        
        # 生成各条动线
        flows = [
            self.plan_guest_flow(),
            self.plan_staff_flow(),
            self.plan_linen_flow(),
            self.plan_goods_flow(),
            self.plan_trash_flow()
        ]
        
        for flow in flows:
            report.flows[flow.name] = flow
        
        # 分析交叉点
        report.crossing_points = self.analyze_crossing_points(flows)
        
        # 生成建议
        report.recommendations = self.generate_recommendations(flows)
        
        # 生成警告
        report.warnings = self.generate_warnings()
        
        return report
    
    def print_report(self, report: CirculationReport) -> None:
        """打印报告"""
        print("\n" + "=" * 70)
        print("🏨 酒店三条动线规划报告")
        print("=" * 70)
        
        print(f"\n项目名称: {report.project_name}")
        print(f"客房数量: {report.total_rooms}间")
        
        print("\n" + "-" * 70)
        print("📍 动线规划总图")
        print("-" * 70)
        print("""
        ┌────────────────────────────────────────────────────────────┐
        │                        宾客动线                           │
        │  主入口 → 落客区 → 大堂 → 前台 → 电梯厅 → 客房层 → 客房    │
        └────────────────────────────────────────────────────────────┘
        
        ┌────────────────────────────────────────────────────────────┐
        │                      员工服务动线                         │
        │  员工入口 → 更衣 → 员工通道 → 服务间 → 客房服务            │
        └────────────────────────────────────────────────────────────┘
        
        ┌────────────────────────────────────────────────────────────┐
        │                      布草物流动线                          │
        │  洗衣房 → 干净布草 → 布草梯 → 服务间 → 客房 → 脏布草回收   │
        └────────────────────────────────────────────────────────────┘
        
        ┌────────────────────────────────────────────────────────────┐
        │                       货物流线                             │
        │  卸货区 → 收货 → 仓库 → 货梯 → 各使用点                    │
        └────────────────────────────────────────────────────────────┘
        """)
        
        print("\n" + "-" * 70)
        print("🔍 各条动线详情")
        print("-" * 70)
        
        for name, flow in report.flows.items():
            print(f"\n【{name}】")
            print(f"  类型: {flow.flow_type}")
            print(f"  建议宽度: ≥{flow.width}m")
            print(f"  节点序列:")
            for i, node in enumerate(flow.nodes, 1):
                print(f"    {i}. {node}")
            if flow.crossing_points:
                print(f"  需注意交叉点: {', '.join(flow.crossing_points)}")
        
        print("\n" + "-" * 70)
        print("⚠️ 动线交叉点分析")
        print("-" * 70)
        
        for i, cp in enumerate(report.crossing_points, 1):
            risk_emoji = "🔴" if cp["risk"] == "高" else "🟡"
            print(f"\n【{i}】{cp['location']} {risk_emoji} 风险:{cp['risk']}")
            print(f"    涉及动线: {', '.join(cp['flows'])}")
            print(f"    解决方案: {cp['solution']}")
        
        print("\n" + "-" * 70)
        print("📋 规划建议")
        print("-" * 70)
        for i, rec in enumerate(report.recommendations, 1):
            print(f"  {i}. {rec}")
        
        print("\n" + "-" * 70)
        print("🚨 安全/卫生注意事项")
        print("-" * 70)
        for warning in report.warnings:
            print(f"  ⚠️ {warning}")
        
        print("\n" + "-" * 70)
        print("📐 通道宽度标准速查")
        print("-" * 70)
        for name, width in self.WIDTH_STANDARDS.items():
            print(f"  {name}: ≥{width}m")
        
        print("\n" + "=" * 70)
        print("💡 温馨提醒")
        print("=" * 70)
        print("""
  • 动线设计应满足消防疏散要求
  • 后场入口应隐蔽，避免影响宾客体验
  • 各功能区应有独立的对外通道
  • 建议在设计阶段进行人流模拟验证
        """)
        print("=" * 70)


def main():
    """主函数"""
    parser = argparse.ArgumentParser(
        description="酒店三条动线规划工具 - v2.4.0",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用示例:
  python plan_hotel_circulation.py --name "某五星酒店" --rooms 200
  python plan_hotel_circulation.py --name "度假酒店" --rooms 150 --format text
  python plan_hotel_circulation.py --name "快捷酒店" --rooms 100

适用场景:
  - 酒店项目初期规划
  - 后场动线优化
  - 设计方案评审

规划原则:
  1. 宾客动线与服务动线分离
  2. 干净布草与脏布草分离
  3. 货物与宾客动线分离
  4. 垃圾动线全封闭处理
        """
    )
    
    parser.add_argument("--name", "-n", required=True,
                        help="酒店项目名称")
    parser.add_argument("--rooms", "-r", type=int, default=100,
                        help="客房总数")
    parser.add_argument("--format", "-f", choices=["text", "simple"],
                        default="text",
                        help="输出格式")
    parser.add_argument("--output", "-o",
                        help="输出报告到文件")
    
    args = parser.parse_args()
    
    # 参数校验
    if args.rooms <= 0:
        print("❌ 错误: 客房数量必须大于0")
        return
    
    # 创建规划器
    planner = HotelCirculationPlanner(args.name, args.rooms)
    
    # 生成报告
    report = planner.generate_report()
    
    # 输出报告
    if args.format == "simple":
        # 简化输出
        print(f"\n🏨 {report.project_name} - 动线规划")
        print(f"客房数: {report.total_rooms}间\n")
        for name, flow in report.flows.items():
            print(f"【{name}】宽度≥{flow.width}m")
    else:
        planner.print_report(report)
    
    # 保存到文件
    if args.output:
        import io
        import sys
        
        # 捕获输出
        old_stdout = sys.stdout
        sys.stdout = io.StringIO()
        
        planner.print_report(report)
        
        output = sys.stdout.getvalue()
        sys.stdout = old_stdout
        
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(output)
        
        print(f"\n📄 报告已保存至: {args.output}")


if __name__ == "__main__":
    main()
