#!/usr/bin/env python3
"""
平面图分析脚本 v2.2.0
分析平面图纸/文字描述，提取关键空间信息

用法示例：
    python analyze_floor_plan.py --description "三室两厅，120平米，南北通透"
    python analyze_floor_plan.py -d "主卧朝南20㎡，带独立卫生间和衣帽间" -o analysis.json
"""

import argparse
import json
import re
import sys
from datetime import datetime
from typing import Dict, Any, List, Optional, Tuple

class FloorPlanAnalyzer:
    """平面图分析器 v2.2.0"""
    
    def __init__(self):
        # 空间类型关键词
        self.space_keywords = {
            "客厅": ["客厅", "起居室", "living", "厅", "客餐厅"],
            "卧室": ["卧室", "主卧", "次卧", "bedroom", "房", "卧"],
            "厨房": ["厨房", "厨", "kitchen", "开放式厨房"],
            "餐厅": ["餐厅", "餐", "dining", "用餐区"],
            "卫生间": ["卫生间", "厕所", "卫浴", "bathroom", "toilet", "wc", "浴室", "洗手间"],
            "阳台": ["阳台", "露台", "balcony", "terrace", "景观阳台", "生活阳台"],
            "书房": ["书房", "书", "study", "工作室", "办公区"],
            "玄关": ["玄关", "入户", "entry", "foyer", "门厅", "鞋柜区"],
            "衣帽间": ["衣帽间", "更衣室", "衣柜区"],
            "储藏室": ["储藏室", "杂物间", "储藏", "收纳间"]
        }
        
        # 朝向关键词
        self.orientation_keywords = {
            "南北通透": ["南北通透", "南北方正", "通透"],
            "南向": ["南向", "朝南", "南厅", "南卧", "主朝向南"],
            "东南向": ["东南", "东南向", "朝东南", "东南朝向"],
            "东向": ["东向", "朝东", "东厅", "东卧"],
            "西南向": ["西南", "西南向", "朝西南"],
            "西向": ["西向", "朝西", "西晒"],
            "东北向": ["东北", "东北向", "朝东北"],
            "北向": ["北向", "朝北", "北卧"]
        }
        
        # 户型类型
        self.layout_types = {
            "一居室": ["一居", "一室", "1室", "studio", "开间", "单间"],
            "两居室": ["两居", "二居", "两室", "二室", "2室"],
            "三居室": ["三居", "三室", "3室", "三房"],
            "四居室": ["四居", "四室", "4室", "四房"],
            "五居室及以上": ["五居", "五室", "5室", "五房", "多室"],
            "别墅": ["别墅", "villa", "独栋", "联排", "叠拼", "排屋"],
            "复式": ["复式", "loft", "跃层", "双层"],
            "公寓": ["公寓", "apartment", "平层", "高层"]
        }
        
        # 特殊特征关键词
        self.feature_keywords = {
            "落地窗": ["落地窗", "大窗户", "全景窗", "宽幕窗"],
            "飘窗": ["飘窗", "凸窗", "转角窗"],
            "大阳台": ["大阳台", "双阳台", "景观阳台", "长阳台"],
            "挑高": ["挑高", "loft", "复式", "层高"],
            "采光好": ["采光好", "光线好", "明亮", "全明", "采光充足"],
            "南北通透": ["南北通透", "通透"],
            "明厨明卫": ["明厨", "明卫", "明厨明卫"],
            "干湿分离": ["干湿分离", "分离设计"],
            "动静分区": ["动静分区", "分区明确"],
            "套房设计": ["套房", "主卧套", "带卫", "带独卫"],
            "电梯": ["电梯", "电梯房", "有电梯"],
            "花园": ["花园", "院子", "庭院", "私家花园"],
            "车位": ["车位", "停车", "车库", "地下车位"],
            "人车分流": ["人车分流", "分流管理"]
        }
        
        # 采光评分标准
        self.light_score_keywords = {
            "优": ["南北通透", "全明", "三面采光", "采光极佳"],
            "良": ["采光好", "明亮", "光线充足", "南向"],
            "中": ["基本采光", "一般", "正常"],
            "差": ["采光差", "暗卫", "暗房", "无窗"]
        }
    
    def validate_inputs(self, args: argparse.Namespace) -> tuple[bool, str]:
        """验证输入"""
        if not args.description or len(args.description.strip()) < 2:
            return False, "请提供有效的空间描述文字"
        if len(args.description) > 2000:
            return False, "描述文字过长（最多2000字），请精简"
        return True, ""
    
    def extract_area(self, text: str) -> Tuple[Optional[float], str]:
        """提取面积信息"""
        patterns = [
            r'(\d+(?:\.\d+)?)\s*(?:平米|平方米|㎡|平|m2|sqm)',
            r'面积[约为]*\s*(\d+(?:\.\d+)?)',
            r'约?\s*(\d+(?:\.\d+)?)\s*平',
            r'总[面积积]\s*(\d+(?:\.\d+)?)'
        ]
        
        areas = []
        for pattern in patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            for match in matches:
                area = float(match)
                if 5 <= area <= 2000:  # 合理面积范围
                    areas.append(area)
        
        if areas:
            return max(areas), f"主面积{max(areas)}㎡"
        return None, "未明确"
    
    def extract_room_areas(self, text: str) -> List[Dict[str, Any]]:
        """提取各房间面积"""
        room_area_pattern = r'([^\s，,]+)\s*[约大约]?\s*(\d+(?:\.\d+)?)\s*(?:平米|㎡|平)?'
        matches = re.findall(room_area_pattern, text)
        
        rooms = []
        for room_name, area in matches:
            for space_type, keywords in self.space_keywords.items():
                for keyword in keywords:
                    if keyword in room_name:
                        rooms.append({
                            "type": space_type,
                            "name": room_name,
                            "area": float(area)
                        })
                        break
        return rooms
    
    def detect_space_types(self, text: str) -> List[str]:
        """检测空间类型"""
        detected = []
        text_lower = text.lower()
        
        for space_type, keywords in self.space_keywords.items():
            for keyword in keywords:
                if keyword in text or keyword in text_lower:
                    if space_type not in detected:
                        detected.append(space_type)
                    break
        return detected if detected else ["未明确"]
    
    def detect_orientation(self, text: str) -> str:
        """检测朝向"""
        text_lower = text.lower()
        
        # 优先匹配最具体的描述
        for orientation, keywords in self.orientation_keywords.items():
            for keyword in keywords:
                if keyword in text or keyword in text_lower:
                    return orientation
        return "未明确"
    
    def detect_layout_type(self, text: str) -> str:
        """检测户型类型"""
        text_lower = text.lower()
        
        # 先匹配复式/别墅等特殊类型
        for layout_type, keywords in self.layout_types.items():
            for keyword in keywords:
                if keyword in text or keyword in text_lower:
                    return layout_type
        return "普通平层"
    
    def extract_room_count(self, text: str) -> Dict[str, int]:
        """提取房间数量"""
        result = {}
        
        # 匹配 "X室X厅X卫" 格式
        pattern1 = r'(\d+)\s*室.*?(\d+)\s*厅.*?(\d+)\s*卫'
        match1 = re.search(pattern1, text)
        if match1:
            result["卧室"] = int(match1.group(1))
            result["客厅"] = int(match1.group(2))
            result["卫生间"] = int(match1.group(3))
            return result
        
        # 匹配 "X室X厅" 格式
        pattern2 = r'(\d+)\s*室.*?(\d+)\s*厅'
        match2 = re.search(pattern2, text)
        if match2:
            result["卧室"] = int(match2.group(1))
            result["客厅"] = int(match2.group(2))
            return result
        
        # 逐个检测
        for space_type, keywords in self.space_keywords.items():
            count = 0
            for keyword in keywords:
                # 查找 "X+关键词" 或 "关键词X个" 格式
                patterns = [
                    rf'(\d+)\s*(?:个|间|套)?\s*{re.escape(keyword)}',
                    rf'{re.escape(keyword)}.*?(\d+)\s*(?:个|间|套)?'
                ]
                for pattern in patterns:
                    matches = re.findall(pattern, text)
                    for m in matches:
                        count = max(count, int(m))
            if count > 0:
                result[space_type] = count
        
        return result if result else {"卧室": 0, "客厅": 0, "卫生间": 0}
    
    def extract_floor(self, text: str) -> str:
        """提取楼层信息"""
        patterns = [
            r'(\d+)\s*楼',
            r'第?\s*(\d+)\s*层',
            r'(\d+)[\/-](\d+)F?'
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                if len(match.groups()) >= 2:
                    return f"{match.group(1)}-{match.group(2)}层"
                return f"{match.group(1)}楼/共未知层"
        
        if any(k in text for k in ["底层", "一楼", "1楼", "首层"]):
            return "低楼层(1-3层)"
        if any(k in text for k in ["顶层", "顶楼"]):
            return "顶楼"
        if any(k in text for k in ["中层", "中间层"]):
            return "中楼层"
        
        return "未明确"
    
    def extract_features(self, text: str) -> List[str]:
        """提取特殊特征"""
        features = []
        text_lower = text.lower()
        
        for feature, keywords in self.feature_keywords.items():
            for keyword in keywords:
                if keyword in text or keyword in text_lower:
                    if feature not in features:
                        features.append(feature)
                    break
        return features if features else ["无特殊标注"]
    
    def assess_lighting(self, text: str, features: List[str], orientation: str) -> Dict[str, Any]:
        """评估采光条件"""
        score = 3  # 默认中等
        factors = []
        
        # 朝向因素
        if orientation == "南北通透":
            score = 5
            factors.append("南北通透，采光通风最佳")
        elif orientation in ["南向", "东南向"]:
            score = 4
            factors.append(f"{orientation}，采光良好")
        elif orientation in ["东向", "西南向"]:
            score = 3
            factors.append(f"{orientation}，采光一般")
        elif orientation in ["西向", "北向"]:
            score = 2
            factors.append(f"{orientation}，采光较弱，需人工补光")
        
        # 特征因素
        if "采光好" in features or "南北通透" in features:
            score = min(score + 1, 5)
            factors.append("标注采光条件好")
        
        if "落地窗" in features:
            factors.append("落地窗设计，采光更佳")
        
        score_text = {
            5: "⭐⭐⭐⭐⭐ 极佳",
            4: "⭐⭐⭐⭐ 良好",
            3: "⭐⭐⭐ 一般",
            2: "⭐⭐ 较弱",
            1: "⭐ 差"
        }
        
        return {
            "score": score,
            "rating": score_text.get(score, "一般"),
            "factors": factors,
            "建议": "增加人工照明" if score < 3 else ("保持自然采光优势" if score >= 4 else "注意灯具布局")
        }
    
    def analyze_space_structure(self, room_count: Dict, features: List) -> Dict[str, Any]:
        """分析空间结构优劣势"""
        analysis = {
            "优点": [],
            "缺点": [],
            "建议": []
        }
        
        # 动静分区
        if "动静分区" in features:
            analysis["优点"].append("动静分区设计，居住体验佳")
        elif room_count.get("卧室", 0) >= 3:
            analysis["建议"].append("建议规划动静分区：客厅/餐厅为动区，卧室/书房为静区")
        
        # 卫生间数量
        wc_count = room_count.get("卫生间", 0)
        bed_count = room_count.get("卧室", 0)
        if wc_count >= bed_count:
            analysis["优点"].append(f"{wc_count}个卫生间配置充足")
        elif wc_count == 1 and bed_count >= 3:
            analysis["缺点"].append("仅1个卫生间，多人居住可能不便")
            analysis["建议"].append("建议将主卧卫生间改为公卫，提高使用效率")
        
        # 套房设计
        if "套房设计" in features:
            analysis["优点"].append("主卧套房设计，私密性好")
        
        # 南北通透
        if "南北通透" in features:
            analysis["优点"].append("南北通透，通风采光俱佳")
        
        return analysis
    
    def generate_design_suggestions(self, result: Dict) -> List[str]:
        """生成设计建议"""
        suggestions = []
        
        room_count = result["room_count"]
        orientation = result["orientation"]
        features = result["features"]
        lighting = result["lighting"]
        
        # 基于采光建议
        if lighting["score"] >= 4:
            suggestions.append("采光优秀，可考虑深色地板或墙面，提升品质感")
        else:
            suggestions.append("采光一般，建议大面积使用浅色，提亮空间")
        
        # 基于朝向建议
        if "南向" in orientation or "东南" in orientation:
            suggestions.append("南向空间适合打造阳光书房或休闲区")
        
        # 基于功能间建议
        if "厨房" in result["space_types"]:
            suggestions.append("厨房建议开放式设计（若无燃气顾虑），增加空间感")
        
        if "书房" in result["space_types"]:
            suggestions.append("书房位置建议选择北向，午后无西晒，阅读更舒适")
        
        if "阳台" in result["space_types"]:
            suggestions.append("阳台可考虑纳入客厅或卧室，扩展使用面积")
        
        return suggestions
    
    def analyze(self, text: str) -> Dict[str, Any]:
        """全面分析文本描述"""
        # 提取各项信息
        area, area_note = self.extract_area(text)
        room_count = self.extract_room_count(text)
        room_areas = self.extract_room_areas(text)
        space_types = self.detect_space_types(text)
        orientation = self.detect_orientation(text)
        layout_type = self.detect_layout_type(text)
        floor = self.extract_floor(text)
        features = self.extract_features(text)
        lighting = self.assess_lighting(text, features, orientation)
        structure = self.analyze_space_structure(room_count, features)
        suggestions = self.generate_design_suggestions({
            "room_count": room_count,
            "orientation": orientation,
            "features": features,
            "lighting": lighting,
            "space_types": space_types
        })
        
        result = {
            "basic_info": {
                "total_area": f"{area}㎡" if area else "未明确",
                "layout_type": layout_type,
                "orientation": orientation,
                "floor": floor
            },
            "room_count": room_count,
            "room_areas": room_areas,
            "space_types": space_types,
            "features": features,
            "lighting": lighting,
            "structure_analysis": structure,
            "design_suggestions": suggestions,
            "original_description": text,
            "analyzed_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        
        return result
    
    def format_output(self, result: Dict, format_type: str = "text") -> str:
        """格式化输出"""
        if format_type == "json":
            return json.dumps(result, ensure_ascii=False, indent=2)
        
        output = []
        output.append("=" * 60)
        output.append("🏠 户型分析报告")
        output.append("=" * 60)
        
        basic = result["basic_info"]
        output.append(f"\n📐 基本信息")
        output.append(f"   户型类型：{basic['layout_type']}")
        output.append(f"   总面积：{basic['total_area']}")
        output.append(f"   朝向：{basic['orientation']} ⭐" if basic['orientation'] != "未明确" else f"   朝向：{basic['orientation']}")
        output.append(f"   楼层：{basic['floor']}")
        
        room_count = result["room_count"]
        if room_count:
            output.append(f"\n🛏️ 房间配置")
            for room, count in room_count.items():
                output.append(f"   {room}：{count}个")
        
        room_areas = result["room_areas"]
        if room_areas:
            output.append(f"\n📏 各空间面积")
            for room in room_areas:
                output.append(f"   {room['name']}：{room['area']}㎡")
        
        features = result["features"]
        if features:
            output.append(f"\n✨ 户型特征")
            for feature in features:
                output.append(f"   ✓ {feature}")
        
        lighting = result["lighting"]
        output.append(f"\n💡 采光评估")
        output.append(f"   {lighting['rating']}")
        for factor in lighting["factors"]:
            output.append(f"   • {factor}")
        output.append(f"   💡 建议：{lighting['建议']}")
        
        structure = result["structure_analysis"]
        if structure["优点"]:
            output.append(f"\n✅ 空间优势")
            for item in structure["优点"]:
                output.append(f"   ✓ {item}")
        
        if structure["缺点"]:
            output.append(f"\n⚠️ 空间劣势")
            for item in structure["缺点"]:
                output.append(f"   ✗ {item}")
        
        if structure["建议"]:
            output.append(f"\n💡 优化建议")
            for item in structure["建议"]:
                output.append(f"   → {item}")
        
        suggestions = result["design_suggestions"]
        if suggestions:
            output.append(f"\n🎨 设计建议")
            for i, suggestion in enumerate(suggestions, 1):
                output.append(f"   {i}. {suggestion}")
        
        output.append("=" * 60)
        output.append(f"📅 分析时间：{result['analyzed_at']}")
        
        return "\n".join(output)


def create_parser() -> argparse.ArgumentParser:
    """创建参数解析器"""
    parser = argparse.ArgumentParser(
        description="户型分析器 - 分析平面图纸或文字描述，提取空间信息并给出设计建议",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例用法：
  python analyze_floor_plan.py --description "三室两厅，120平米，南北通透，主卧朝南"
  python analyze_floor_plan.py -d "120㎡ 三室两厅两卫 南向 客厅30㎡ 主卧20㎡" -o analysis.json
  python analyze_floor_plan.py --description "主卧带独立卫生间和衣帽间，客厅带超大阳台"

支持分析的内容：
  - 户型结构（几室几厅几卫）
  - 面积信息（总面积、各空间面积）
  - 朝向（南北通透、南向等）
  - 特殊特征（落地窗、飘窗、干湿分离等）
  - 采光评估
  - 设计建议
        """
    )
    
    parser.add_argument(
        "-d", "--description",
        type=str,
        required=True,
        help="空间描述文字，如：'三室两厅，120平米，南北通透'"
    )
    
    parser.add_argument(
        "-o", "--output",
        type=str,
        help="输出文件路径（JSON格式）"
    )
    
    parser.add_argument(
        "-f", "--format",
        type=str,
        choices=["text", "json"],
        default="text",
        help="输出格式，默认为text"
    )
    
    return parser


def main():
    """主函数"""
    parser = create_parser()
    args = parser.parse_args()
    
    analyzer = FloorPlanAnalyzer()
    
    # 验证输入
    valid, error_msg = analyzer.validate_inputs(args)
    if not valid:
        print(f"❌ 参数错误: {error_msg}", file=sys.stderr)
        parser.print_help()
        sys.exit(1)
    
    try:
        result = analyzer.analyze(args.description)
        output = analyzer.format_output(result, args.format)
        
        if args.output:
            with open(args.output, 'w', encoding='utf-8') as f:
                f.write(json.dumps(result, ensure_ascii=False, indent=2))
            print(f"✅ 分析结果已保存至: {args.output}")
        
        print(output)
        
    except Exception as e:
        print(f"❌ 分析出错: {str(e)}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
