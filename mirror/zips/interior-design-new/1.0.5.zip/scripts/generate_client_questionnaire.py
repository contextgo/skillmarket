#!/usr/bin/env python3
"""
客户需求问卷生成脚本 v2.2.0
根据项目类型生成定制化的客户需求问卷，支持装修人格测试

用法示例：
    python generate_client_questionnaire.py --type 住宅 --output ./questionnaire.md
    python generate_client_questionnaire.py -t 住宅 -n "张三住宅" -o questionnaire.json
"""

import argparse
import json
import sys
from datetime import datetime
from typing import Dict, Any, List, Optional

class ClientQuestionnaireGenerator:
    """客户需求问卷生成器 v2.2.0"""
    
    def __init__(self):
        # 住宅问卷模板
        self.residential_template = {
            "section1_basic_info": {
                "title": "一、基本信息",
                "questions": [
                    {"id": "name", "question": "您的姓名", "type": "text", "required": True},
                    {"id": "phone", "question": "联系电话", "type": "text", "required": True},
                    {"id": "address", "question": "项目地址", "type": "text", "required": True},
                    {"id": "area", "question": "建筑面积", "type": "number", "unit": "㎡", "required": True},
                    {"id": "house_type", "question": "房屋类型", "type": "radio", 
                     "options": ["新房", "二手房", "老房翻新", "别墅"], "required": True},
                    {"id": "layout", "question": "户型结构", "type": "text", 
                     "placeholder": "如：3室2厅2卫", "required": True}
                ]
            },
            "section2_family": {
                "title": "二、家庭成员",
                "questions": [
                    {"id": "family_members", "question": "常住人口", "type": "number", 
                     "placeholder": "几口人", "required": True},
                    {"id": "family_detail", "question": "家庭成员详情", "type": "table",
                     "columns": ["关系", "年龄", "职业/身份", "特殊需求"],
                     "example": "如：本人-30岁-设计师-需要书房"},
                    {"id": "pets", "question": "是否有宠物", "type": "radio",
                     "options": ["无", "狗", "猫", "其他（请说明）"]}
                ]
            },
            "section3_lifestyle": {
                "title": "三、生活方式",
                "questions": [
                    {"id": "work_from_home", "question": "是否需要居家办公", "type": "radio",
                     "options": ["是，需要独立书房", "是，卧室兼顾", "否，很少在家工作"]},
                    {"id": "cooking", "question": "烹饪频率", "type": "radio",
                     "options": ["每天做饭", "经常做饭", "偶尔做饭", "很少/不做饭"]},
                    {"id": "guests", "question": "待客频率", "type": "radio",
                     "options": ["经常（每周1次以上）", "偶尔（每月1-2次）", "很少"]},
                    {"id": "hobbies", "question": "兴趣爱好", "type": "checkbox",
                     "options": ["阅读", "健身", "影音娱乐", "烹饪烘焙", "收藏", "园艺绿植", "手工DIY", "游戏"]},
                    {"id": "daily_routine", "question": "典型一天", "type": "textarea",
                     "placeholder": "描述一下您在家的一天，从早到晚主要活动"}
                ]
            },
            "section4_functional_needs": {
                "title": "四、功能需求",
                "questions": [
                    {"id": "storage_needs", "question": "收纳需求", "type": "textarea",
                     "placeholder": "如：大量衣物、书籍、孩子的玩具、季节性物品等"},
                    {"id": "special_functions", "question": "特殊功能需求", "type": "checkbox",
                     "options": ["智能家居系统", "家庭影院", "酒窖/吧台", "健身区", "儿童游乐区", "茶室", "宠物活动区"]},
                    {"id": "accessibility", "question": "无障碍需求", "type": "checkbox",
                     "options": ["老人友好（无高低差）", "轮椅通行", "扶手配置", "紧急呼叫系统"]},
                    {"id": "comfort", "question": "舒适系统", "type": "checkbox",
                     "options": ["中央空调", "地暖", "新风系统", "全屋净水", "热水循环"]}
                ]
            },
            "section5_aesthetic": {
                "title": "五、审美偏好",
                "questions": [
                    {"id": "style_preference", "question": "喜欢的风格", "type": "checkbox",
                     "options": ["现代简约", "北欧", "新中式", "轻奢", "日式", "美式", "工业风", "混搭", "奶油风", "不确定"]},
                    {"id": "style_references", "question": "参考案例", "type": "file",
                     "description": "上传喜欢的装修图片（可选）"},
                    {"id": "color_preference", "question": "色调偏好", "type": "radio",
                     "options": ["暖色调（米白、浅黄、木色）", "冷色调（灰、蓝、绿）", "中性色调（黑白灰）", "混搭"]},
                    {"id": "atmosphere", "question": "期望氛围", "type": "checkbox",
                     "options": ["温馨舒适", "明亮通透", "沉稳大气", "个性独特", "自然清新", "简约整洁"]}
                ]
            },
            "section6_budget": {
                "title": "六、预算范围",
                "questions": [
                    {"id": "total_budget", "question": "总预算范围", "type": "radio",
                     "options": ["10万以下", "10-20万", "20-30万", "30-50万", "50-100万", "100万以上", "暂不确定"]},
                    {"id": "budget_priority", "question": "预算重点分配", "type": "checkbox",
                     "options": ["基础装修（隐蔽工程）", "主材（瓷砖地板）", "家具", "软装配饰", "家电设备"]},
                    {"id": "brand_preference", "question": "品牌偏好", "type": "radio",
                     "options": ["国际大牌优先", "性价比品牌即可", "无所谓，看具体情况"]}
                ]
            },
            "section7_timeline": {
                "title": "七、时间期望",
                "questions": [
                    {"id": "move_in_date", "question": "期望入住时间", "type": "date"},
                    {"id": "flexibility", "question": "时间弹性", "type": "radio",
                     "options": ["时间紧迫，越快越好", "有一定弹性", "不着急，质量优先"]}
                ]
            },
            "section8_notes": {
                "title": "八、其他信息",
                "questions": [
                    {"id": "restrictions", "question": "特殊限制", "type": "textarea",
                     "placeholder": "如：物业规定、风水要求、宗教禁忌等"},
                    {"id": "questions_to_designer", "question": "对设计师的问题", "type": "textarea",
                     "placeholder": "有什么想了解或特别要求的可以在这里说明"},
                    {"id": "additional_notes", "question": "补充说明", "type": "textarea"}
                ]
            }
        }
        
        # 装修人格测试
        self.personality_test = {
            "title": "🎭 装修人格测试（快速5题）",
            "description": "回答以下5个问题，测出你的装修风格DNA",
            "questions": [
                {
                    "id": "q1",
                    "question": "周末在家，你更喜欢：",
                    "options": [
                        {"id": "a", "text": "睡到自然醒，窝在沙发追剧吃零食", "score": {"慵懒宅": 2}},
                        {"id": "b", "text": "约朋友来家里聚餐喝酒聊天", "score": {"社交达人": 2}},
                        {"id": "c", "text": "安静地看书/工作/做手工", "score": {"效率优先": 2}},
                        {"id": "d", "text": "大扫除+整理收纳，极度舒适", "score": {"收纳强迫": 2}}
                    ]
                },
                {
                    "id": "q2",
                    "question": "理想家的关键词是：",
                    "options": [
                        {"id": "a", "text": "温馨、治愈、慵懒", "score": {"慵懒宅": 1, "奶油控": 1}},
                        {"id": "b", "text": "有范儿、能秀、能社交", "score": {"社交达人": 1, "轻奢": 1}},
                        {"id": "c", "text": "高效、整洁、有条理", "score": {"效率优先": 1, "极简": 1}},
                        {"id": "d", "text": "温暖、有烟火气、有人味儿", "score": {"收纳强迫": 1, "北欧": 1}}
                    ]
                },
                {
                    "id": "q3",
                    "question": "搬家时，你首先整理的是：",
                    "options": [
                        {"id": "a", "text": "零食储备和娱乐设备", "score": {"慵懒宅": 1}},
                        {"id": "b", "text": "酒柜和音响设备", "score": {"社交达人": 1}},
                        {"id": "c", "text": "书架和办公用品", "score": {"效率优先": 1}},
                        {"id": "d", "text": "衣柜和储物柜", "score": {"收纳强迫": 1}}
                    ]
                },
                {
                    "id": "q4",
                    "question": "你家的沙发通常变成：",
                    "options": [
                        {"id": "a", "text": "第二张床", "score": {"慵懒宅": 1}},
                        {"id": "b", "text": "聚餐时的座位扩展", "score": {"社交达人": 1}},
                        {"id": "c", "text": "猫/狗的专属领地", "score": {"效率优先": 1}},
                        {"id": "d", "text": "堆满衣服的\"衣架\"", "score": {"收纳强迫": 1}}
                    ]
                },
                {
                    "id": "q5",
                    "question": "朋友对你家的评价，你最希望听到：",
                    "options": [
                        {"id": "a", "text": "\"好舒服啊，想赖着不走\"", "score": {"慵懒宅": 2}},
                        {"id": "b", "text": "\"太酷了，开派对一定很棒\"", "score": {"社交达人": 2}},
                        {"id": "c", "text": "\"好整洁，强迫症患者福音\"", "score": {"效率优先": 2}},
                        {"id": "d", "text": "\"好有生活气息，家的感觉\"", "score": {"收纳强迫": 2}}
                    ]
                }
            ],
            "results": {
                "慵懒宅": {
                    "title": "🦥 慵懒宅家型",
                    "description": "你是一个享受生活、注重舒适度的人。家是你放松充电的港湾。",
                    "recommended_styles": ["奶油风", "北欧", "现代简约"],
                    "must_have": ["舒适沙发", "大地毯", "投影仪/大电视", "遮光窗帘"],
                    "avoid": ["开放式置物架（落灰）", "硬邦邦的皮质沙发", "太多锐利边角"]
                },
                "社交达人": {
                    "title": "🎉 社交达人型",
                    "description": "你家就是朋友圈的据点！需要足够大的公共空间和氛围感。",
                    "recommended_styles": ["轻奢", "现代简约", "混搭"],
                    "must_have": ["大餐桌（6人以上）", "氛围灯光系统", "音响设备", "酒柜/吧台"],
                    "avoid": ["太小气的客厅", "不够用的插座", "昏暗的灯光"]
                },
                "效率优先": {
                    "title": "⚡ 效率优先型",
                    "description": "你注重功能性和条理性，生活高效，空间整洁是你的追求。",
                    "recommended_styles": ["日式", "极简", "现代简约"],
                    "must_have": ["强大收纳系统", "高效工作角", "智能家居", "隐形把手柜子"],
                    "avoid": ["太多装饰品", "开放式衣柜", "不好用的鸡肋空间"]
                },
                "收纳强迫": {
                    "title": "📦 收纳强迫型",
                    "description": "你追求秩序美，断舍离不适合你，多储物才是王道！",
                    "recommended_styles": ["日式", "北欧", "现代简约"],
                    "must_have": ["顶天立地大柜子", "榻榻米", "整面墙收纳", "标签系统"],
                    "avoid": ["开放格", "展示架", "太多装饰品"]
                }
            }
        }
    
    def validate_inputs(self, args: argparse.Namespace) -> tuple[bool, str]:
        """验证输入"""
        if args.type not in ["住宅", "商业"]:
            return False, f"不支持的项目类型: {args.type}，可选: 住宅、商业"
        return True, ""
    
    def generate_questionnaire(self, args: argparse.Namespace) -> Dict[str, Any]:
        """生成问卷"""
        project_type = args.type
        template = self.residential_template if project_type == "住宅" else self.residential_template
        
        questionnaire = {
            "project_info": {
                "project_name": args.project_name or "未命名项目",
                "project_type": project_type,
                "designer": args.designer or "",
                "generated_at": datetime.now().strftime("%Y-%m-%d")
            },
            "questionnaire": template,
            "personality_test": self.personality_test,
            "usage_guide": {
                "description": "本问卷用于全面了解客户需求，请引导客户认真填写",
                "steps": [
                    "1. 发送问卷给客户",
                    "2. 收集填写结果",
                    "3. 根据结果分析需求",
                    "4. 生成需求分析报告"
                ]
            }
        }
        
        return questionnaire
    
    def analyze_personality_test(self, answers: Dict[str, str]) -> Dict[str, Any]:
        """分析人格测试结果"""
        scores = {}
        
        for q_id, answer in answers.items():
            if q_id in self.personality_test["questions"]:
                q = self.personality_test["questions"][int(q_id.replace("q", "")) - 1]
                for opt in q["options"]:
                    if opt["id"] == answer:
                        for style, score in opt["score"].items():
                            scores[style] = scores.get(style, 0) + score
        
        # 找出最高分
        if scores:
            top_style = max(scores, key=scores.get)
            result = self.personality_test["results"].get(top_style, self.personality_test["results"]["慵懒宅"])
            return {
                "primary_style": top_style,
                "result": result,
                "all_scores": scores
            }
        
        return None
    
    def format_questionnaire(self, questionnaire: Dict, format_type: str = "markdown") -> str:
        """格式化问卷"""
        if format_type == "json":
            return json.dumps(questionnaire, ensure_ascii=False, indent=2)
        
        output = []
        output.append("# 📋 客户需求问卷")
        output.append("")
        output.append(f"**项目名称**: {questionnaire['project_info']['project_name']}")
        output.append(f"**项目类型**: {questionnaire['project_info']['project_type']}")
        output.append(f"**设计师**: {questionnaire['project_info']['designer'] or '待定'}")
        output.append(f"**日期**: {questionnaire['project_info']['generated_at']}")
        output.append("")
        output.append("---")
        output.append("")
        
        # 标准问卷
        for section_key, section in questionnaire['questionnaire'].items():
            output.append(f"## {section['title']}")
            output.append("")
            for q in section['questions']:
                output.append(f"**{q['question']}** {'*' if q.get('required') else ''}")
                output.append("")
                
                if q['type'] == 'radio':
                    for opt in q['options']:
                        output.append(f"- [ ] {opt}")
                elif q['type'] == 'checkbox':
                    for opt in q['options']:
                        output.append(f"- [ ] {opt}")
                elif q['type'] == 'table':
                    output.append(f"（表格：{', '.join(q['columns'])})")
                    if 'example' in q:
                        output.append(f"示例：{q['example']}")
                elif 'placeholder' in q:
                    output.append(f"（{q['placeholder']}）")
                
                output.append("")
        
        # 人格测试
        test = questionnaire['personality_test']
        output.append("---")
        output.append("")
        output.append(f"## {test['title']}")
        output.append("")
        output.append(f"*{test['description']}*")
        output.append("")
        
        for q in test['questions']:
            output.append(f"**{q['question']}**")
            for opt in q['options']:
                output.append(f"- [ ] {opt['id'].upper()}. {opt['text']}")
            output.append("")
        
        output.append("---")
        output.append("")
        output.append(f"*本问卷由室内设计助手生成 | {questionnaire['project_info']['generated_at']}*")
        
        return "\n".join(output)


def create_parser() -> argparse.ArgumentParser:
    """创建参数解析器"""
    parser = argparse.ArgumentParser(
        description="客户需求问卷生成器 - 生成标准化的客户需求问卷，含装修人格测试",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例用法：
  python generate_client_questionnaire.py --type 住宅 --output ./questionnaire.md
  python generate_client_questionnaire.py -t 住宅 -n "李府雅居" -d "张设计师" -o questionnaire.md
        """
    )
    
    parser.add_argument(
        "-t", "--type",
        type=str,
        required=True,
        choices=["住宅", "商业"],
        help="项目类型"
    )
    
    parser.add_argument(
        "-n", "--project-name",
        type=str,
        help="项目名称"
    )
    
    parser.add_argument(
        "-d", "--designer",
        type=str,
        help="设计师姓名"
    )
    
    parser.add_argument(
        "-o", "--output",
        type=str,
        help="输出文件路径"
    )
    
    parser.add_argument(
        "-f", "--format",
        type=str,
        choices=["markdown", "json"],
        default="markdown",
        help="输出格式，默认为markdown"
    )
    
    return parser


def main():
    """主函数"""
    parser = create_parser()
    args = parser.parse_args()
    
    generator = ClientQuestionnaireGenerator()
    
    # 验证输入
    valid, error_msg = generator.validate_inputs(args)
    if not valid:
        print(f"❌ 参数错误: {error_msg}", file=sys.stderr)
        parser.print_help()
        sys.exit(1)
    
    try:
        questionnaire = generator.generate_questionnaire(args)
        output = generator.format_questionnaire(questionnaire, args.format)
        
        if args.output:
            with open(args.output, 'w', encoding='utf-8') as f:
                f.write(output)
            print(f"✅ 问卷已保存至: {args.output}")
        else:
            print(output)
        
    except Exception as e:
        print(f"❌ 生成出错: {str(e)}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
