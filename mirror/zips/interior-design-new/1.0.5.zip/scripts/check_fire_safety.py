#!/usr/bin/env python3
"""
消防合规检查脚本 - v2.3.0
用于商业空间消防平面审核自查

功能：
1. 防火分区检查
2. 安全疏散检查（疏散宽度、距离、出口数量）
3. 消防设施检查
4. 装修材料燃烧性能检查
5. 生成合规检查报告

规范依据：
- GB 55037-2022 建筑防火通用规范
- GB 50016-2014（2018版）建筑设计防火规范
- GB 50222-2017 建筑内部装修设计防火规范
- GB 50084-2017 自动喷水灭火系统设计规范
- GB 50116-2013 火灾自动报警系统设计规范
- GB 51251-2017 建筑防烟排烟系统技术标准
- GB 50974-2014 消防给水及消火栓系统技术规范

Author: interior-design-assistant v2.3.0
"""

import argparse
import json
from dataclasses import dataclass, asdict
from typing import List, Optional, Dict


@dataclass
class ProjectInfo:
    """项目基本信息"""
    name: str
    project_type: str  # 办公/餐饮/零售/教育
    area: float  # 建筑面积（平方米）
    floors: int = 1  # 层数
    fire_rating: str = "一二级"  # 耐火等级
    has_sprinkler: bool = True  # 是否设自动喷淋
    floor_areas: Optional[List[float]] = None  # 各层面积


@dataclass
class CheckResult:
    """检查项结果"""
    item: str
    category: str
    status: str  # pass/fail/warn
    required: str
    actual: str
    suggestion: str
    priority: str  # high/medium/low


@dataclass
class EvacuationCalc:
    """疏散计算结果"""
    floor: int
    area: float
    density: float  # 人/㎡
    persons: int  # 计算人数
    width_index: float  # 百人宽度指标 m/百人
    required_width: float  # 需疏散宽度 m
    actual_width: float  # 实际疏散宽度 m
    exit_count: int  # 安全出口数量
    max_exit_persons: int  # 单出口最大允许人数


class FireSafetyChecker:
    """消防合规检查类"""
    
    # 防火分区面积限值（平方米）
    FIRE_COMPARTMENT_LIMITS = {
        "一二级": {"单多层": 2500, "高层": 1500, "地下": 500},
        "三级": {"单多层": 1200, "地下": 500}
    }
    
    # 人员密度（人/㎡）- 依据GB50016-2014 5.5.21
    PERSON_DENSITY = {
        "办公": {"普通": 0.1, "会议室": 0.5},
        "餐饮": {"地上": 0.8, "地下": 0.85},
        "零售": {"地上": 0.5, "地下": 0.6},
        "教育": {"教室": 0.5, "活动室": 0.8}
    }
    
    # 百人疏散宽度指标（m/百人）- 依据GB50016-2014 5.5.21
    WIDTH_INDEX = {
        "1-2层": {"一二层": 0.65, "三层": 0.75, "三四层以上": 1.0},
        "3层": {"一二层": 0.75, "三层": 1.0, "三四层以上": 1.0},
        "4层及以上": {"一二层": 1.0, "三层": 1.0, "三四层以上": 1.25}
    }
    
    # 疏散距离限值（米）- 依据GB50016-2014 5.5.17
    EVACUATION_DISTANCE = {
        "办公": {"双向": 40, "袋形": 20},
        "餐饮": {"双向": 30, "袋形": 15, "歌舞": {"双向": 25, "袋形": 9}},
        "零售": {"双向": 30, "袋形": 15},
        "教育": {"双向": 25, "袋形": 10}
    }
    
    # 单个安全出口最大允许人数
    MAX_PERSONS_PER_EXIT = {"一二级": 250, "三级": 200}
    
    def __init__(self, project: ProjectInfo):
        self.project = project
        self.results: List[CheckResult] = []
        self.evacuation_calcs: List[EvacuationCalc] = []
    
    def check_fire_compartment(self) -> List[CheckResult]:
        """检查防火分区"""
        results = []
        base_limit = self.FIRE_COMPARTMENT_LIMITS.get(
            self.project.fire_rating, {}
        ).get("单多层", 2500)
        
        if self.project.has_sprinkler:
            limit_with_sprinkler = base_limit * 1.5
        else:
            limit_with_sprinkler = base_limit
        
        if self.project.floor_areas:
            areas = self.project.floor_areas
        else:
            areas = [self.project.area / self.project.floors] * self.project.floors
        
        for i, floor_area in enumerate(areas):
            status = "pass" if floor_area <= limit_with_sprinkler else "fail"
            results.append(CheckResult(
                item=f"楼层{i+1}防火分区",
                category="防火分区",
                status=status,
                required=f"≤{limit_with_sprinkler:.0f}㎡（设喷淋）",
                actual=f"{floor_area:.0f}㎡",
                suggestion="增加防火墙分隔或增设喷淋" if status == "fail" else "符合要求",
                priority="high" if status == "fail" else "low"
            ))
        
        return results
    
    def calculate_evacuation(self) -> List[EvacuationCalc]:
        """计算疏散"""
        calcs = []
        
        if self.project.project_type in self.PERSON_DENSITY:
            density_type = list(self.PERSON_DENSITY[self.project.project_type].keys())[0]
            density = self.PERSON_DENSITY[self.project.project_type][density_type]
        else:
            density = 0.5
        
        if self.project.floors <= 2:
            width_index = self.WIDTH_INDEX["1-2层"]["一二层"]
        elif self.project.floors == 3:
            width_index = self.WIDTH_INDEX["3层"]["三层"]
        else:
            width_index = self.WIDTH_INDEX["4层及以上"]["三四层以上"]
        
        if self.project.floor_areas:
            areas = self.project.floor_areas
        else:
            areas = [self.project.area / self.project.floors] * self.project.floors
        
        for i, floor_area in enumerate(areas):
            persons = int(floor_area * density)
            required_width = persons * width_index / 100
            max_persons_per_exit = self.MAX_PERSONS_PER_EXIT.get(
                self.project.fire_rating, 250
            )
            exit_count = (persons + max_persons_per_exit - 1) // max_persons_per_exit
            
            calcs.append(EvacuationCalc(
                floor=i + 1,
                area=floor_area,
                density=density,
                persons=persons,
                width_index=width_index,
                required_width=required_width,
                actual_width=0,
                exit_count=exit_count,
                max_exit_persons=max_persons_per_exit
            ))
        
        self.evacuation_calcs = calcs
        return calcs
    
    def check_evacuation_width(self, actual_widths: List[float]) -> List[CheckResult]:
        """检查疏散宽度"""
        results = []
        
        for i, calc in enumerate(self.evacuation_calcs):
            actual = actual_widths[i] if i < len(actual_widths) else 0
            status = "pass" if actual >= calc.required_width else "fail"
            
            results.append(CheckResult(
                item=f"楼层{calc.floor}疏散宽度",
                category="安全疏散",
                status=status,
                required=f"{calc.required_width:.2f}m",
                actual=f"{actual:.2f}m" if actual > 0 else "待提供",
                suggestion="增加疏散门宽度" if status == "fail" else "符合要求",
                priority="high" if status == "fail" else "low"
            ))
        
        return results
    
    def run_full_check(
        self,
        actual_widths: List[float] = None,
        exit_counts: List[int] = None
    ) -> Dict:
        """执行完整检查"""
        self.results = []
        
        # 1. 防火分区检查
        self.results.extend(self.check_fire_compartment())
        
        # 2. 疏散计算
        self.calculate_evacuation()
        
        # 3. 疏散宽度检查
        if actual_widths:
            self.results.extend(self.check_evacuation_width(actual_widths))
        
        return self.generate_report()
    
    def generate_report(self) -> Dict:
        """生成检查报告"""
        failed = [r for r in self.results if r.status == "fail"]
        high_priority = [r for r in self.results if r.priority == "high"]
        
        report = {
            "project": asdict(self.project),
            "summary": {
                "total_items": len(self.results),
                "passed": len([r for r in self.results if r.status == "pass"]),
                "failed": len(failed),
                "warnings": len([r for r in self.results if r.status == "warn"]),
                "high_priority_issues": len(high_priority)
            },
            "evacuation_calculation": [asdict(calc) for calc in self.evacuation_calcs],
            "check_results": [asdict(r) for r in self.results],
            "recommendations": self._generate_recommendations(failed)
        }
        
        return report
    
    def _generate_recommendations(self, failed: List[CheckResult]) -> List[str]:
        """生成整改建议"""
        recommendations = []
        
        if not failed:
            recommendations.append("所有检查项均已通过")
            return recommendations
        
        by_category = {}
        for r in failed:
            if r.category not in by_category:
                by_category[r.category] = []
            by_category[r.category].append(r)
        
        for category, items in by_category.items():
            recommendations.append(f"【{category}类问题】共{len(items)}项")
            for item in items:
                recommendations.append(f"  {item.item}: {item.suggestion}")
        
        return recommendations


def print_report(report: Dict):
    """格式化打印报告"""
    project = report["project"]
    summary = report["summary"]
    
    print("\n" + "=" * 60)
    print("【消防合规检查报告】")
    print("=" * 60)
    print(f"项目：{project['name']}")
    print(f"类型：{project['project_type']} | 面积：{project['area']}㎡ | 层数：{project['floors']}层")
    
    print("\n检查概要:")
    print(f"  总检查项：{summary['total_items']}")
    print(f"  通过：{summary['passed']}")
    print(f"  失败：{summary['failed']}")
    print(f"  高优先级问题：{summary['high_priority_issues']}")
    
    print("\n疏散计算:")
    for calc in report["evacuation_calculation"]:
        print(f"  楼层{calc['floor']}: {calc['persons']}人 × {calc['width_index']}m/百人 = 需宽度{calc['required_width']:.2f}m, 需出口≥{calc['exit_count']}个")
    
    print("\n检查结果:")
    for result in report["check_results"]:
        icon = "OK" if result["status"] == "pass" else "FAIL" if result["status"] == "fail" else "WARN"
        print(f"  [{icon}] {result['item']}: 要求{result['required']}, 实际{result['actual']}")
    
    print("\n整改建议:")
    for rec in report["recommendations"]:
        print(f"  {rec}")
    
    print()


def main():
    parser = argparse.ArgumentParser(description="商业空间消防合规检查工具")
    parser.add_argument("--name", type=str, default="商业项目", help="项目名称")
    parser.add_argument("--project_type", type=str, default="餐饮", 
                       choices=["办公", "餐饮", "零售", "教育"], help="项目类型")
    parser.add_argument("--area", type=float, required=True, help="建筑面积（平方米）")
    parser.add_argument("--floors", type=int, default=1, help="层数")
    parser.add_argument("--fire_rating", type=str, default="一二级", help="耐火等级")
    parser.add_argument("--no_sprinkler", action="store_true", help="不设自动喷淋")
    parser.add_argument("--floor_areas", type=str, help="各层面积，逗号分隔")
    parser.add_argument("--actual_widths", type=str, help="各层实际疏散宽度，逗号分隔")
    parser.add_argument("--output", type=str, help="输出JSON文件路径")
    
    args = parser.parse_args()
    
    floor_areas = None
    if args.floor_areas:
        floor_areas = [float(x) for x in args.floor_areas.split(",")]
    
    project = ProjectInfo(
        name=args.name,
        project_type=args.project_type,
        area=args.area,
        floors=args.floors,
        fire_rating=args.fire_rating,
        has_sprinkler=not args.no_sprinkler,
        floor_areas=floor_areas
    )
    
    actual_widths = None
    if args.actual_widths:
        actual_widths = [float(x) for x in args.actual_widths.split(",")]
    
    checker = FireSafetyChecker(project)
    report = checker.run_full_check(actual_widths=actual_widths)
    
    print_report(report)
    
    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        print(f"报告已保存至: {args.output}")


if __name__ == "__main__":
    main()
