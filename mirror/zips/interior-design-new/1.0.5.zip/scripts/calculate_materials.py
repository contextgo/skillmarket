#!/usr/bin/env python3
"""
材料用量计算脚本 v2.2.0
根据空间尺寸自动计算材料用量，含损耗系数

用法示例：
    python calculate_materials.py --room 客厅 --length 5 --width 4 --height 2.8
    python calculate_materials.py -r 卧室 -l 4 -w 3.5 -h 2.8 -o materials.json
"""

import argparse
import json
import sys
import math
from datetime import datetime
from typing import Dict, Any, List, Optional

class MaterialCalculator:
    """材料用量计算器 v2.2.0"""
    
    def __init__(self):
        # 材料损耗率
        self.waste_rates = {
            "地板": 0.05,
            "瓷砖": 0.08,
            "涂料": 0.10,
            "壁纸": 0.15,
            "石材": 0.10,
            "地毯": 0.05,
            "木饰面": 0.08,
            "石膏板": 0.08,
            "铝扣板": 0.05
        }
        
        # 涂料覆盖率（㎡/升）
        self.paint_coverage = {
            "底漆": 12,
            "面漆": 8
        }
        
        # 材料规格
        self.specs = {
            "实木地板": {"规格": "910×127×15mm", "每片面积": 0.1156, "每包片数": 20},
            "复合地板": {"规格": "1215×169×12mm", "每片面积": 0.2054, "每包片数": 12},
            "瓷砖800": {"规格": "800×800mm", "每片面积": 0.64},
            "瓷砖600": {"规格": "600×600mm", "每片面积": 0.36},
            "瓷砖400": {"规格": "400×400mm", "每片面积": 0.16},
            "瓷砖300": {"规格": "300×300mm", "每片面积": 0.09},
            "壁纸": {"规格": "0.53×10m", "每卷面积": 5.3},
            "石膏板": {"规格": "1200×2400×9.5mm", "每张面积": 2.88},
            "铝扣板300": {"规格": "300×300mm", "每片面积": 0.09},
            "铝扣板600": {"规格": "600×600mm", "每片面积": 0.36}
        }
        
        # 推荐材料配置
        self.room_materials = {
            "客厅": {
                "地面": "实木地板",
                "墙面": "涂料",
                "天花": "石膏板"
            },
            "卧室": {
                "地面": "实木地板",
                "墙面": "涂料",
                "天花": "石膏板"
            },
            "书房": {
                "地面": "复合地板",
                "墙面": "涂料",
                "天花": "石膏板"
            },
            "厨房": {
                "地面": "瓷砖800",
                "墙面": "瓷砖600",
                "天花": "铝扣板600"
            },
            "卫生间": {
                "ground": "瓷砖600",
                "墙面": "瓷砖400",
                "天花": "铝扣板300"
            },
            "阳台": {
                "地面": "瓷砖600",
                "墙面": "涂料",
                "天花": "石膏板"
            },
            "餐厅": {
                "地面": "实木地板",
                "墙面": "涂料",
                "天花": "石膏板"
            }
        }
    
    def validate_inputs(self, args: argparse.Namespace) -> tuple[bool, str]:
        """验证输入参数"""
        if args.length <= 0 or args.width <= 0:
            return False, f"长度和宽度必须大于0，当前: 长{args.length}m × 宽{args.width}m"
        if args.height <= 0 or args.height > 10:
            return False, f"高度必须在0-10米之间，当前: {args.height}m"
        if args.room not in self.room_materials and args.material_type not in ["地板", "瓷砖", "涂料", "壁纸"]:
            return False, f"不支持的空间类型: {args.room}，可选: {list(self.room_materials.keys())}"
        if args.window_area < 0 or args.door_area < 0:
            return False, "门窗面积不能为负数"
        if args.window_area > args.length * args.height * 4:
            return False, "窗户面积过大，请检查输入"
        return True, ""
    
    def calculate_floor(self, length: float, width: float, material_type: str = "实木地板") -> Dict[str, Any]:
        """计算地面材料用量"""
        floor_area = length * width
        waste_rate = self.waste_rates.get(material_type, 0.05)
        
        if material_type in ["实木地板", "复合地板"]:
            spec = self.specs.get(material_type, self.specs["实木地板"])
            actual_area = floor_area * (1 + waste_rate)
            total_pieces = actual_area / spec["每片面积"]
            packages = total_pieces / spec["每包片数"]
            
            return {
                "material_type": material_type,
                "floor_area": round(floor_area, 2),
                "waste_rate": f"{waste_rate*100:.0f}%",
                "actual_area": round(actual_area, 2),
                "spec": spec["规格"],
                "piece_area": f"{spec['每片面积']:.4f}㎡",
                "pieces_needed": round(total_pieces, 1),
                "packages_needed": round(packages, 1),
                "备货建议": f"{round(actual_area * 1.03, 1)}㎡（多买3%备货）"
            }
        
        elif "瓷砖" in material_type or material_type == "瓷砖":
            # 根据面积选择合适规格
            if floor_area > 30:
                spec = self.specs["瓷砖800"]
            elif floor_area > 15:
                spec = self.specs["瓷砖600"]
            else:
                spec = self.specs["瓷砖400"]
            
            actual_area = floor_area * (1 + waste_rate)
            pieces_needed = actual_area / spec["每片面积"]
            
            return {
                "material_type": f"瓷砖（{spec['规格']}）",
                "floor_area": round(floor_area, 2),
                "waste_rate": f"{waste_rate*100:.0f}%",
                "actual_area": round(actual_area, 2),
                "spec": spec["规格"],
                "pieces_needed": round(pieces_needed, 1),
                "备货建议": f"{round(actual_area * 1.03, 1)}㎡（多买3%备货）"
            }
        
        elif material_type == "地毯":
            return {
                "material_type": "地毯",
                "floor_area": round(floor_area, 2),
                "waste_rate": f"{waste_rate*100:.0f}%",
                "actual_area": round(floor_area, 2),
                "recommended_size": f"{length:.2f}m × {width:.2f}m（整块定制）"
            }
        
        else:
            return {
                "material_type": material_type,
                "floor_area": round(floor_area, 2),
                "waste_rate": f"{waste_rate*100:.0f}%",
                "actual_area": round(floor_area * (1 + waste_rate), 2)
            }
    
    def calculate_wall(self, length: float, width: float, height: float, 
                       material_type: str = "涂料", 
                       window_area: float = 0, 
                       door_area: float = 0) -> Dict[str, Any]:
        """计算墙面材料用量"""
        # 墙面总面积（四面墙）
        wall_area = 2 * (length + width) * height
        # 扣除门窗
        deductions = window_area + door_area
        net_area = max(wall_area - deductions, 0)
        
        waste_rate = self.waste_rates.get(material_type, 0.10)
        actual_area = net_area * (1 + waste_rate)
        
        if material_type == "涂料":
            primer_coverage = self.paint_coverage["底漆"]
            paint_coverage = self.paint_coverage["面漆"]
            
            # 两遍涂刷
            primer_liters = (net_area * 1) / primer_coverage
            paint_liters = (net_area * 2) / paint_coverage
            
            primer_buckets = primer_liters / 5
            paint_buckets = paint_liters / 5
            
            return {
                "material_type": "乳胶漆",
                "gross_wall_area": round(wall_area, 2),
                "window_deduction": round(window_area, 2),
                "door_deduction": round(door_area, 2),
                "net_area": round(net_area, 2),
                "waste_rate": f"{waste_rate*100:.0f}%",
                "actual_area": round(actual_area, 2),
                "coats": "2遍",
                "底漆": {
                    "liters": round(primer_liters, 1),
                    "buckets_5l": round(primer_buckets, 1),
                    "coverage": f"{primer_coverage}㎡/升"
                },
                "面漆": {
                    "liters": round(paint_liters, 1),
                    "buckets_5l": round(paint_buckets, 1),
                    "coverage": f"{paint_coverage}㎡/升"
                },
                "备货建议": f"底漆{math.ceil(primer_buckets)}桶 + 面漆{math.ceil(paint_buckets)}桶"
            }
        
        elif material_type == "壁纸":
            spec = self.specs["壁纸"]
            rolls_needed = actual_area / spec["每卷面积"]
            
            return {
                "material_type": "壁纸",
                "gross_wall_area": round(wall_area, 2),
                "net_area": round(net_area, 2),
                "waste_rate": f"{waste_rate*100:.0f}%",
                "actual_area": round(actual_area, 2),
                "spec": f"{spec['规格']}（每卷{spec['每卷面积']}㎡）",
                "rolls_needed": round(rolls_needed, 1),
                "备货建议": f"{math.ceil(rolls_needed)}卷（建议多买1-2卷备用）"
            }
        
        elif "瓷砖" in material_type or material_type == "瓷砖":
            spec = self.specs.get("瓷砖300", self.specs["瓷砖400"])
            pieces_needed = actual_area / spec["每片面积"]
            
            return {
                "material_type": f"墙砖（{spec['规格']}）",
                "gross_wall_area": round(wall_area, 2),
                "net_area": round(net_area, 2),
                "waste_rate": f"{waste_rate*100:.0f}%",
                "actual_area": round(actual_area, 2),
                "spec": spec["规格"],
                "pieces_needed": round(pieces_needed, 1),
                "备货建议": f"{round(actual_area * 1.08, 1)}㎡（多买8%备货）"
            }
        
        else:
            return {
                "material_type": material_type,
                "gross_wall_area": round(wall_area, 2),
                "net_area": round(net_area, 2),
                "waste_rate": f"{waste_rate*100:.0f}%",
                "actual_area": round(actual_area, 2)
            }
    
    def calculate_ceiling(self, length: float, width: float, 
                         material_type: str = "石膏板") -> Dict[str, Any]:
        """计算天花材料用量"""
        ceiling_area = length * width
        waste_rate = self.waste_rates.get(material_type, 0.08)
        actual_area = ceiling_area * (1 + waste_rate)
        
        if material_type == "石膏板":
            spec = self.specs["石膏板"]
            sheets_needed = actual_area / spec["每张面积"]
            
            return {
                "material_type": "石膏板吊顶",
                "ceiling_area": round(ceiling_area, 2),
                "waste_rate": f"{waste_rate*100:.0f}%",
                "actual_area": round(actual_area, 2),
                "spec": f"{spec['规格']}（每张{spec['每张面积']}㎡）",
                "sheets_needed": round(sheets_needed, 1),
                "备货建议": f"{math.ceil(sheets_needed)}张"
            }
        
        elif material_type == "铝扣板":
            spec = self.specs["铝扣板600"]
            pieces_needed = actual_area / spec["每片面积"]
            
            return {
                "material_type": "铝扣板吊顶",
                "ceiling_area": round(ceiling_area, 2),
                "waste_rate": f"{waste_rate*100:.0f}%",
                "actual_area": round(actual_area, 2),
                "spec": f"{spec['规格']}（每片{spec['每片面积']}㎡）",
                "pieces_needed": round(pieces_needed, 1),
                "备货建议": f"{math.ceil(pieces_needed)}片"
            }
        
        else:
            return {
                "material_type": material_type,
                "ceiling_area": round(ceiling_area, 2),
                "waste_rate": f"{waste_rate*100:.0f}%",
                "actual_area": round(actual_area, 2)
            }
    
    def calculate_cabinet(self, length: float, height: float, depth: float = 0.6) -> Dict[str, Any]:
        """计算定制柜体"""
        projection_area = length * height
        # 展开面积约为投影面积的3-3.5倍
        unfold_area = projection_area * 3.2
        material_with_waste = unfold_area * 1.08
        
        return {
            "柜体类型": "定制柜",
            "投影面积": round(projection_area, 2),
            "展开面积系数": "3.2",
            "展开面积": round(unfold_area, 2),
            "含损耗展开面积": round(material_with_waste, 2),
            "尺寸": f"长{length:.2f}m × 高{height:.2f}m × 深{depth:.2f}m",
            "参考价格": {
                "实木颗粒板": f"{material_with_waste * 80:.0f}-{material_with_waste * 150:.0f}元",
                "多层实木板": f"{material_with_waste * 120:.0f}-{material_with_waste * 200:.0f}元"
            }
        }
    
    def calculate_all(self, args: argparse.Namespace) -> Dict[str, Any]:
        """计算所有材料"""
        room = args.room
        length = args.length
        width = args.width
        height = args.height
        window_area = args.window_area
        door_area = args.door_area
        
        # 获取推荐材料
        recommended = self.room_materials.get(room, {
            "地面": "实木地板",
            "墙面": "涂料",
            "天花": "石膏板"
        })
        
        result = {
            "space_info": {
                "room": room,
                "length": length,
                "width": width,
                "height": height,
                "floor_area": round(length * width, 2),
                "wall_area": round(2 * (length + width) * height, 2),
                "ceiling_area": round(length * width, 2)
            },
            "recommended_materials": recommended,
            "calculations": {
                "地面": self.calculate_floor(length, width, recommended.get("地面", "实木地板")),
                "墙面": self.calculate_wall(length, width, height, recommended.get("墙面", "涂料"), 
                                          window_area, door_area),
                "天花": self.calculate_ceiling(length, width, recommended.get("天花", "石膏板"))
            },
            "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "notes": [
                "以上用量含合理损耗，实际采购可略少于计算值",
                "建议额外预留3-5%备货量，应对补货困难",
                "涂料涂刷需要2遍，请按2遍用量购买"
            ]
        }
        
        return result
    
    def format_output(self, result: Dict[str, Any], format_type: str = "text") -> str:
        """格式化输出"""
        if format_type == "json":
            return json.dumps(result, ensure_ascii=False, indent=2)
        
        output = []
        output.append("=" * 60)
        output.append("📦 材料用量计算报告")
        output.append("=" * 60)
        
        space = result["space_info"]
        output.append(f"\n🏠 空间信息：{space['room']}")
        output.append(f"   尺寸：{space['length']}m × {space['width']}m × {space['height']}m")
        output.append(f"   地面面积：{space['floor_area']}㎡")
        output.append(f"   墙面面积：{space['wall_area']}㎡")
        output.append(f"   天花面积：{space['ceiling_area']}㎡")
        
        output.append(f"\n🔧 推荐材料配置")
        rec = result["recommended_materials"]
        output.append(f"   地面：{rec.get('地面', '实木地板')}")
        output.append(f"   墙面：{rec.get('墙面', '涂料')}")
        output.append(f"   天花：{rec.get('天花', '石膏板')}")
        
        calcs = result["calculations"]
        
        output.append(f"\n🪵 地面材料")
        floor = calcs["地面"]
        for key, value in floor.items():
            if isinstance(value, str):
                output.append(f"   {key}：{value}")
            elif isinstance(value, (int, float)):
                output.append(f"   {key}：{value}")
        
        output.append(f"\n🎨 墙面材料")
        wall = calcs["墙面"]
        for key, value in wall.items():
            if isinstance(value, dict):
                output.append(f"   {key}：")
                for k, v in value.items():
                    output.append(f"      {k}：{v}")
            elif isinstance(value, str):
                output.append(f"   {key}：{value}")
        
        output.append(f"\n🪛 天花材料")
        ceiling = calcs["天花"]
        for key, value in ceiling.items():
            if isinstance(value, str):
                output.append(f"   {key}：{value}")
            elif isinstance(value, (int, float)):
                output.append(f"   {key}：{value}")
        
        output.append(f"\n💡 备注")
        for note in result["notes"]:
            output.append(f"   • {note}")
        
        output.append("=" * 60)
        
        return "\n".join(output)


def create_parser() -> argparse.ArgumentParser:
    """创建参数解析器"""
    parser = argparse.ArgumentParser(
        description="材料用量计算器 - 根据空间尺寸计算地面、墙面、天花材料用量",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例用法：
  python calculate_materials.py --room 客厅 --length 5 --width 4 --height 2.8
  python calculate_materials.py -r 卧室 -l 4 -w 3.5 -h 2.8 -o materials.json
  python calculate_materials.py --room 厨房 --length 3 --width 2.5 --height 2.8 --window-area 2 --door-area 1.5

可选空间类型：客厅、卧室、书房、厨房、卫生间、阳台、餐厅
        """
    )
    
    parser.add_argument(
        "-r", "--room",
        type=str,
        required=True,
        help="空间类型（客厅/卧室/书房/厨房/卫生间/阳台/餐厅）"
    )
    
    parser.add_argument(
        "-l", "--length",
        type=float,
        required=True,
        help="房间长度（米）"
    )
    
    parser.add_argument(
        "-w", "--width",
        type=float,
        required=True,
        help="房间宽度（米）"
    )
    
    parser.add_argument(
        "--height",
        type=float,
        default=2.8,
        help="房间高度（米），默认为2.8m"
    )
    
    parser.add_argument(
        "--window-area",
        type=float,
        default=0,
        help="窗户总面积（平方米），默认为0"
    )
    
    parser.add_argument(
        "--door-area",
        type=float,
        default=0,
        help="门洞总面积（平方米），默认为0"
    )
    
    parser.add_argument(
        "-m", "--material-type",
        type=str,
        help="指定材料类型（可选，不指定则根据空间类型自动推荐）"
    )
    
    parser.add_argument(
        "-o", "--output",
        type=str,
        help="输出文件路径（JSON格式）"
    )
    
    parser.add_argument(
        "-f", "--format",
        type=str,
        choices=["text", "json"],
        default="text",
        help="输出格式，默认为text"
    )
    
    return parser


def main():
    """主函数"""
    import math
    
    parser = create_parser()
    args = parser.parse_args()
    
    calculator = MaterialCalculator()
    
    # 验证输入
    valid, error_msg = calculator.validate_inputs(args)
    if not valid:
        print(f"❌ 参数错误: {error_msg}", file=sys.stderr)
        parser.print_help()
        sys.exit(1)
    
    try:
        result = calculator.calculate_all(args)
        
        output = calculator.format_output(result, args.format)
        
        if args.output:
            with open(args.output, 'w', encoding='utf-8') as f:
                f.write(json.dumps(result, ensure_ascii=False, indent=2))
            print(f"✅ 材料清单已保存至: {args.output}")
        
        print(output)
        
    except Exception as e:
        print(f"❌ 计算出错: {str(e)}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
