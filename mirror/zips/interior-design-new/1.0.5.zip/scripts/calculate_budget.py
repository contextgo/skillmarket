#!/usr/bin/env python3
"""
预算计算脚本 v2.2.0
根据面积、风格、预算等级、城市系数自动估算装修预算

用法示例：
    python calculate_budget.py --area 100 --style 轻奢 --city 一线 --level 品质
    python calculate_budget.py --area 120 --style 现代简约 --city 新一线 --level 舒适 --rooms 3 --output budget.json
"""

import argparse
import json
import sys
from datetime import datetime
from typing import Dict, Any, Optional

class BudgetCalculator:
    """装修预算计算器 v2.2.0"""
    
    def __init__(self):
        # 城市系数
        self.city_coefficients = {
            "一线": 1.35,
            "新一线": 1.15,
            "二线": 1.0,
            "三线": 0.85,
            "四线": 0.75
        }
        
        # 风格系数
        self.style_coefficients = {
            "现代简约": 1.0,
            "北欧": 1.05,
            "新中式": 1.15,
            "轻奢": 1.25,
            "工业": 0.95,
            "日式": 1.1,
            "美式": 1.2,
            "欧式": 1.3,
            "混搭": 1.1,
            "极简": 0.95,
            "奶油": 1.1
        }
        
        # 装修等级基础价（元/㎡）
        self.base_prices = {
            "经济": 800,
            "舒适": 1500,
            "品质": 2500,
            "豪华": 4000
        }
        
        # 预算分配比例
        self.budget_ratios = {
            "硬装占比": 0.60,
            "软装占比": 0.40
        }
        
        # 硬装分项比例
        self.hard_ratios = {
            "基装人工": 0.30,
            "主材": 0.40,
            "定制家具": 0.20,
            "不可预见费": 0.10
        }
        
        # 软装分项比例
        self.soft_ratios = {
            "家具": 0.45,
            "家电": 0.35,
            "软装配饰": 0.20
        }
        
        # 空间类型参考面积分配
        self.room_distribution = {
            "客厅": 0.25,
            "餐厅": 0.10,
            "主卧": 0.18,
            "次卧1": 0.14,
            "次卧2": 0.13,
            "厨房": 0.08,
            "卫生间1": 0.06,
            "卫生间2": 0.04,
            "阳台": 0.02
        }
    
    def validate_inputs(self, args: argparse.Namespace) -> tuple[bool, str]:
        """验证输入参数"""
        if args.area <= 0:
            return False, f"面积必须大于0，当前值: {args.area}"
        if args.area > 1000:
            return False, f"面积过大（{args.area}㎡），请确认输入是否正确"
        if args.city not in self.city_coefficients:
            return False, f"不支持的城市等级: {args.city}，可选: {list(self.city_coefficients.keys())}"
        if args.style not in self.style_coefficients:
            return False, f"不支持的风格: {args.style}，可选: {list(self.style_coefficients.keys())}"
        if args.level not in self.base_prices:
            return False, f"不支持的装修等级: {args.level}，可选: {list(self.base_prices.keys())}"
        return True, ""
    
    def calculate_budget(self, area: float, style: str, city: str, level: str, 
                        rooms: int = 3, is_new_house: bool = True) -> Dict[str, Any]:
        """计算装修预算"""
        
        # 获取系数
        city_coef = self.city_coefficients[city]
        style_coef = self.style_coefficients[style]
        base_price = self.base_prices[level]
        
        # 房屋类型系数
        house_coef = 1.0 if is_new_house else 1.25
        
        # 综合系数
        total_coef = city_coef * style_coef * house_coef
        
        # 单方造价
        unit_price = base_price * total_coef
        
        # 总硬装预算
        total_hard = area * unit_price
        
        # 硬装分项计算
        hard_items = {
            "基装人工": total_hard * self.hard_ratios["基装人工"],
            "主材": total_hard * self.hard_ratios["主材"],
            "定制家具": total_hard * self.hard_ratios["定制家具"],
            "不可预见费": total_hard * self.hard_ratios["不可预见费"]
        }
        
        # 主材分项（估算）
        material_items = {
            "瓷砖地板": hard_items["主材"] * 0.30,
            "橱柜定制": hard_items["主材"] * 0.25,
            "门窗": hard_items["主材"] * 0.15,
            "洁具龙头": hard_items["主材"] * 0.15,
            "其他": hard_items["主材"] * 0.15
        }
        
        # 软装预算
        total_soft = total_hard * (self.budget_ratios["软装占比"] / self.budget_ratios["硬装占比"])
        
        # 软装分项计算
        soft_items = {
            "家具": total_soft * self.soft_ratios["家具"],
            "家电": total_soft * self.soft_ratios["家电"],
            "软装配饰": total_soft * self.soft_ratios["软装配饰"]
        }
        
        # 总预算
        total_budget = total_hard + total_soft
        
        # 预算范围（±10%）
        budget_min = total_budget * 0.9
        budget_max = total_budget * 1.1
        
        return {
            "project_info": {
                "area": area,
                "style": style,
                "city": city,
                "level": level,
                "rooms": rooms,
                "house_type": "新房" if is_new_house else "二手房",
                "city_coef": city_coef,
                "style_coef": style_coef,
                "house_coef": house_coef,
                "total_coef": total_coef,
                "unit_price": unit_price,
                "is_new_house": is_new_house
            },
            "budget_summary": {
                "total_min": budget_min,
                "total_max": budget_max,
                "total_median": total_budget,
                "unit_price_display": f"{unit_price:.0f}",
                "display_range": f"{budget_min/area:.0f}-{budget_max/area:.0f}"
            },
            "hard_decoration": {
                "subtotal": total_hard,
                "ratio": self.budget_ratios["硬装占比"],
                "items": {
                    "基装人工": {
                        "amount": hard_items["基装人工"],
                        "ratio": self.hard_ratios["基装人工"],
                        "description": "水电改造、泥瓦工、木工、油漆工等人工费用"
                    },
                    "主材": {
                        "amount": hard_items["主材"],
                        "ratio": self.hard_ratios["主材"],
                        "description": "瓷砖、地板、涂料、门窗等材料费用",
                        "breakdown": {
                            "瓷砖地板": material_items["瓷砖地板"],
                            "橱柜定制": material_items["橱柜定制"],
                            "门窗": material_items["门窗"],
                            "洁具龙头": material_items["洁具龙头"],
                            "其他": material_items["其他"]
                        }
                    },
                    "定制家具": {
                        "amount": hard_items["定制家具"],
                        "ratio": self.hard_ratios["定制家具"],
                        "description": "衣柜、鞋柜、书柜等定制柜体"
                    },
                    "不可预见费": {
                        "amount": hard_items["不可预见费"],
                        "ratio": self.hard_ratios["不可预见费"],
                        "description": "预留的突发情况费用"
                    }
                }
            },
            "soft_decoration": {
                "subtotal": total_soft,
                "ratio": self.budget_ratios["软装占比"],
                "items": soft_items
            },
            "calculation_details": {
                "formula": f"总预算 = 面积({area}㎡) × 单方造价({unit_price:.0f}元/㎡)",
                "single_price_calc": f"单方造价 = 基础价({base_price}) × 城市系数({city_coef}) × 风格系数({style_coef}) × 房屋系数({house_coef})",
                "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "note": "预算为估算值，实际价格受品牌、市场波动影响，建议预留10-15%弹性空间"
            }
        }
    
    def format_output(self, result: Dict[str, Any], format_type: str = "text") -> str:
        """格式化输出"""
        if format_type == "json":
            return json.dumps(result, ensure_ascii=False, indent=2)
        
        # 文本格式输出
        output = []
        output.append("=" * 60)
        output.append("💰 装修预算计算报告")
        output.append("=" * 60)
        
        info = result["project_info"]
        summary = result["budget_summary"]
        
        output.append(f"\n📍 项目信息")
        output.append(f"   建筑面积：{info['area']}㎡")
        output.append(f"   装修风格：{info['style']}")
        output.append(f"   城市等级：{info['city']}（系数{info['city_coef']}）")
        output.append(f"   装修等级：{info['level']}")
        output.append(f"   房屋类型：{info['house_type']}")
        
        output.append(f"\n💵 预算概要")
        output.append(f"   总预算范围：{summary['total_min']/10000:.1f}-{summary['total_max']/10000:.1f}万元")
        output.append(f"   单方造价：{summary['unit_price_display']}元/㎡")
        output.append(f"   面积单价范围：{summary['display_range']}元/㎡")
        
        hard = result["hard_decoration"]
        output.append(f"\n🏠 硬装预算（约60%）：{hard['subtotal']/10000:.1f}万元")
        output.append(f"   ├── 基装人工：{hard['items']['基装人工']['amount']/10000:.1f}万元")
        output.append(f"   ├── 主材：{hard['items']['主材']['amount']/10000:.1f}万元")
        output.append(f"   │   ├── 瓷砖地板：{hard['items']['主材']['breakdown']['瓷砖地板']/10000:.1f}万元")
        output.append(f"   │   ├── 橱柜定制：{hard['items']['主材']['breakdown']['橱柜定制']/10000:.1f}万元")
        output.append(f"   │   ├── 门窗：{hard['items']['主材']['breakdown']['门窗']/10000:.1f}万元")
        output.append(f"   │   └── 洁具龙头：{hard['items']['主材']['breakdown']['洁具龙头']/10000:.1f}万元")
        output.append(f"   ├── 定制家具：{hard['items']['定制家具']['amount']/10000:.1f}万元")
        output.append(f"   └── 不可预见费：{hard['items']['不可预见费']['amount']/10000:.1f}万元")
        
        soft = result["soft_decoration"]
        output.append(f"\n🛋️ 软装预算（约40%）：{soft['subtotal']/10000:.1f}万元")
        output.append(f"   ├── 家具：{soft['items']['家具']/10000:.1f}万元")
        output.append(f"   ├── 家电：{soft['items']['家电']/10000:.1f}万元")
        output.append(f"   └── 软装配饰：{soft['items']['软装配饰']/10000:.1f}万元")
        
        output.append(f"\n📐 计算公式")
        output.append(f"   {result['calculation_details']['formula']}")
        output.append(f"   {result['calculation_details'][f'single_price_calc']}")
        
        output.append(f"\n💡 备注：{result['calculation_details']['note']}")
        output.append("=" * 60)
        
        return "\n".join(output)


def create_parser() -> argparse.ArgumentParser:
    """创建参数解析器"""
    parser = argparse.ArgumentParser(
        description="装修预算计算器 - 根据面积、风格、城市、等级自动估算装修预算",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例用法：
  python calculate_budget.py --area 100 --style 轻奢 --city 一线 --level 品质
  python calculate_budget.py -a 120 -s 现代简约 -c 新一线 -l 舒适 -o budget.json
  python calculate_budget.py --area 150 --style 新中式 --city 二线 --level 豪华 --rooms 4

支持的城市等级：一线、新一线、二线、三线、四线
支持的风格：现代简约、北欧、新中式、轻奢、工业、日式、美式、欧式、混搭、极简、奶油
支持的等级：经济、舒适、品质、豪华
        """
    )
    
    parser.add_argument(
        "-a", "--area",
        type=float,
        required=True,
        help="装修面积（平方米），必填，示例：100"
    )
    
    parser.add_argument(
        "-s", "--style",
        type=str,
        required=True,
        help="设计风格，示例：轻奢、现代简约、北欧"
    )
    
    parser.add_argument(
        "-c", "--city",
        type=str,
        required=True,
        choices=["一线", "新一线", "二线", "三线", "四线"],
        help="城市等级"
    )
    
    parser.add_argument(
        "-l", "--level",
        type=str,
        required=True,
        choices=["经济", "舒适", "品质", "豪华"],
        help="装修等级"
    )
    
    parser.add_argument(
        "-r", "--rooms",
        type=int,
        default=3,
        help="房间数量，默认为3"
    )
    
    parser.add_argument(
        "--new-house",
        action="store_true",
        default=True,
        help="新房装修（默认），关闭请用 --no-new-house"
    )
    
    parser.add_argument(
        "--no-new-house",
        action="store_true",
        help="二手房装修"
    )
    
    parser.add_argument(
        "-o", "--output",
        type=str,
        help="输出文件路径（JSON格式），可选"
    )
    
    parser.add_argument(
        "-f", "--format",
        type=str,
        choices=["text", "json"],
        default="text",
        help="输出格式，默认为text"
    )
    
    return parser


def main():
    """主函数"""
    parser = create_parser()
    args = parser.parse_args()
    
    # 处理二手房标志
    is_new_house = not args.no_new_house
    
    # 创建计算器
    calculator = BudgetCalculator()
    
    # 验证输入
    valid, error_msg = calculator.validate_inputs(args)
    if not valid:
        print(f"❌ 参数错误: {error_msg}", file=sys.stderr)
        parser.print_help()
        sys.exit(1)
    
    try:
        # 计算预算
        result = calculator.calculate_budget(
            area=args.area,
            style=args.style,
            city=args.city,
            level=args.level,
            rooms=args.rooms,
            is_new_house=is_new_house
        )
        
        # 输出结果
        output = calculator.format_output(result, args.format)
        
        if args.output:
            with open(args.output, 'w', encoding='utf-8') as f:
                f.write(json.dumps(result, ensure_ascii=False, indent=2))
            print(f"✅ 预算结果已保存至: {args.output}")
        
        print(output)
        
    except Exception as e:
        print(f"❌ 计算出错: {str(e)}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
