# 室内设计方案

## 项目信息

| 项目 | 内容 |
|-----|------|
| 空间类型 | {{space_type}} |
| 面积 | {{area}} |
| 朝向 | {{orientation}} |
| 设计风格 | {{style}} |
| 预算等级 | {{budget}} |
| 设计日期 | {{date}} |

---

## 设计理念

{{design_concept}}

---

## 平面布局方案

### 功能分区
{{layout_zones}}

### 家具布置
{{furniture_arrangement}}

### 动线规划
{{circulation_plan}}

---

## 材料清单

### 地面材料
{{floor_material}}

### 墙面材料
{{wall_material}}

### 天花材料
{{ceiling_material}}

### 定制家具材料
{{custom_material}}

---

## 色彩搭配方案

### 配色比例
- **主色调 (60%)**: {{primary_color}}
- **辅助色 (30%)**: {{secondary_color}}
- **点缀色 (10%)**: {{accent_color}}

### 配色说明
{{color_description}}

---

## 家具与软装建议

### 家具风格
{{furniture_style}}

### 推荐材质
{{furniture_material}}

### 软装搭配
{{soft_decoration}}

---

## 照明设计

### 基础照明
{{general_lighting}}

### 重点照明
{{task_lighting}}

### 氛围照明
{{ambient_lighting}}

### 照明建议
{{lighting_tips}}

---

## 预算估算

| 项目 | 估算价格 |
|-----|---------|
| 预算等级 | {{budget_level}} |
| 每平米造价 | {{unit_cost}} |
| 估算总价 | {{total_cost}} |

**说明**: {{budget_note}}

---

## 注意事项

1. 本方案仅供参考，实际施工请咨询专业设计师和施工团队
2. 材料价格会因品牌、地区、季节等因素有所浮动
3. 施工前请确认所有尺寸和细节
4. 建议预留10-15%的预算作为不可预见费用

---

**设计师**: AI设计助手  
**方案版本**: v1.0
