# Copyright (c) 2026 ZXJ@DEVS. Author: QQ 1817694478 | Q-Group: 972156177
# Skill: dragon-skill-hub | Version: 1.1.0

"""
clawhub_learning.py - 龙虾技能管家自学习引擎
继承自 skill-self-learning-core 的核心自学习机制：
  - 权重自进化（连胜/连败加速）
  - 意图路由命中率追踪
  - 来源效果评估
  - 修正自动检测
  - 经验池管理
  - 自我反省审计
"""

import os
import re
import sys
import json
import hashlib
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple

# UTF-8编码兼容
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')

SCRIPT_DIR = Path(__file__).parent
SKILL_DIR = SCRIPT_DIR.parent
ASSETS_DIR = SKILL_DIR / "assets"


# ══════════════════════════════════════════════════════════════
# 修正检测器（从 skill-self-learning-core 蒸馏）
# ══════════════════════════════════════════════════════════════

CORRECTION_PATTERNS = [
    (re.compile(r'^不是[，。,\s]|^不[是对的]|^不，应该|^应该'), 'correction'),
    (re.compile(r'能不能|加个|增加一个|建议增加|能不能|建议.*加'), 'feature_request'),
    (re.compile(r'其实|补充|你不知道|实际上|准确说|严格说'), 'knowledge_gap'),
    (re.compile(r'可以这样|用.{0,8}代替|换.*方法|试试.*做法|不如用'), 'workaround'),
    (re.compile(r'换个说法|太啰嗦|简洁点|说人话|太复杂'), 'style_feedback'),
]

CORRECTION_PRIORITY = {'correction': 0, 'knowledge_gap': 1, 'feature_request': 2, 'workaround': 3, 'style_feedback': 4}


class CorrectionTracker:
    """自动检测用户纠错和反馈"""

    def __init__(self, learn_data: Dict):
        self.learn_data = learn_data

    def detect(self, text: str) -> Optional[Dict]:
        """检测文本中是否包含修正/反馈，返回类型和详情"""
        if not text:
            return None
        for pattern, ctype in CORRECTION_PATTERNS:
            if pattern.search(text):
                return {'type': ctype, 'match': pattern.findall(text)[0] if pattern.findall(text) else ''}
        return None

    def add_correction(self, text: str, context: str = ""):
        """添加一条修正记录"""
        detection = self.detect(text)
        if not detection:
            return False
        ctype = detection['type']
        corrections = self.learn_data.setdefault('corrections', [])
        record = {
            'timestamp': datetime.now().isoformat(),
            'type': ctype,
            'text_hash': hashlib.md5(text.encode('utf-8', errors='replace')).hexdigest()[:8],
            'text_preview': text[:60],
            'context': context[:100] if context else '',
            'count': 1,
            'first_seen': datetime.now().isoformat(),
            'last_seen': datetime.now().isoformat(),
        }
        # 合并同类型修正
        for c in corrections:
            if c['type'] == ctype and c['text_hash'] == record['text_hash']:
                c['count'] += 1
                c['last_seen'] = record['last_seen']
                return True
        corrections.append(record)
        corrections.sort(key=lambda x: CORRECTION_PRIORITY.get(x['type'], 5))
        return True


# ══════════════════════════════════════════════════════════════
# 权重进化引擎（从 skill-self-learning-core 蒸馏）
# ══════════════════════════════════════════════════════════════

class LearningData:
    """
    自学习核心数据管理器
    包含：来源效果追踪、关键词权重、连胜/连败进化
    """

    # 来源配置
    SOURCES = {
        'local_db':      {'boost': 1.0,  'label': '本地数据库'},
        'clawhub_market': {'boost': 1.2,  'label': 'ClawHub市场'},
        'intent_router': {'boost': 0.9,  'label': '意图路由'},
    }

    # 意图标签配置（dragon-skill-hub专有）
    INTENT_LABELS = [
        'search_skill', 'install_skill', 'list_skill', 'analyze_skill',
        'update_skill', 'backup_skill', 'rollback_skill', 'submit_skill',
        'rate_skill', 'check_update', 'audit_skill', 'unknown'
    ]

    # 关键词分类
    KEYWORD_CATEGORIES = ['技能', '搜索', '安装', '分析', '审核', '评分',
                          '备份', '更新', '回滚', '上架', '发布']

    def __init__(self, learn_data_path: str = None):
        if learn_data_path is None:
            ASSETS_DIR.mkdir(parents=True, exist_ok=True)
            learn_data_path = str(ASSETS_DIR / "learn_data.json")

        self.path = learn_data_path
        self.data = self._load()
        self._ct = CorrectionTracker(self.data)

    # ── 基础读写 ──────────────────────────────────────────────

    def _load(self) -> Dict:
        if os.path.exists(self.path):
            try:
                with open(self.path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError):
                pass
        return self._default_data()

    def _default_data(self) -> Dict:
        return {
            'version': '1.1',
            'created_at': datetime.now().isoformat(),
            'updated_at': datetime.now().isoformat(),
            'source_effectiveness': {
                src: {
                    'weight': float(cfg['boost']),
                    'consecutive_success': 0,
                    'consecutive_failure': 0,
                    'total_success': 0,
                    'total_failure': 0,
                    'last_result': None,
                    'last_used': None,
                } for src, cfg in self.SOURCES.items()
            },
            'intent_stats': {
                intent: {
                    'total': 0, 'success': 0, 'failure': 0,
                    'last_result': None,
                } for intent in self.INTENT_LABELS
            },
            'keyword_weights': {
                kw: 1.0 for kw in self.KEYWORD_CATEGORIES
            },
            'corrections': [],
            'experiences': [],
            'paradigms': [],
        }

    def save(self):
        self.data['updated_at'] = datetime.now().isoformat()
        try:
            with open(self.path, 'w', encoding='utf-8') as f:
                json.dump(self.data, f, ensure_ascii=False, indent=2)
        except IOError as e:
            sys.stderr.write(f"[WARNING] 保存learn_data失败: {e}\n")

    # ── 来源效果追踪 ──────────────────────────────────────────

    def record_success(self, source: str, intent: str = "", keyword: str = "") -> Dict:
        """记录一次成功，更新权重（连胜加速机制）"""
        now = datetime.now().isoformat()
        updated = []

        # 来源权重更新
        if source in self.data['source_effectiveness']:
            src = self.data['source_effectiveness'][source]
            src['total_success'] += 1
            src['consecutive_success'] += 1
            src['consecutive_failure'] = 0
            src['last_result'] = 'success'
            src['last_used'] = now

            # 连胜加速进化
            boost = 0.05
            if src['consecutive_success'] >= 5:
                boost = 0.15
            elif src['consecutive_success'] >= 3:
                boost = 0.10

            old = src['weight']
            src['weight'] = min(old * (1 + boost), old * 2.0)  # 上限2倍
            if src['weight'] != old:
                updated.append(f"来源[{source}]: {old:.3f} -> {src['weight']:.3f} (连{ src['consecutive_success']}胜 +{int(boost*100)}%)")

        # 意图统计
        if intent in self.data['intent_stats']:
            stats = self.data['intent_stats'][intent]
            stats['success'] += 1
            stats['total'] += 1
            stats['last_result'] = 'success'

        # 关键词权重
        if keyword and keyword in self.data['keyword_weights']:
            old = self.data['keyword_weights'][keyword]
            self.data['keyword_weights'][keyword] = min(old * 1.05, old * 1.5)
            if self.data['keyword_weights'][keyword] != old:
                updated.append(f"关键词[{keyword}]: {old:.3f} -> {self.data['keyword_weights'][keyword]:.3f}")

        # 经验记录
        self.data['experiences'].append({
            'timestamp': now,
            'type': 'success',
            'source': source,
            'intent': intent,
            'keyword': keyword,
        })
        self._trim_experiences()

        self.save()
        return {
            'consecutive': self.data['source_effectiveness'].get(source, {}).get('consecutive_success', 0),
            'total_success': self.data['source_effectiveness'].get(source, {}).get('total_success', 0),
            'updated': updated,
            'status': 'EVOLVED' if updated else 'recorded',
        }

    def record_failure(self, source: str, intent: str = "", reason: str = "") -> Dict:
        """记录一次失败（连败降权机制）"""
        now = datetime.now().isoformat()
        updated = []

        if source in self.data['source_effectiveness']:
            src = self.data['source_effectiveness'][source]
            src['total_failure'] += 1
            src['consecutive_failure'] += 1
            src['consecutive_success'] = 0
            src['last_result'] = 'failure'

            if src['consecutive_failure'] >= 3:
                old = src['weight']
                src['weight'] = max(old * 0.90, old * 0.5)  # 下限50%
                if src['weight'] != old:
                    updated.append(f"来源[{source}]: {old:.3f} -> {src['weight']:.3f} (连{src['consecutive_failure']}败 -10%)")

        if intent in self.data['intent_stats']:
            stats = self.data['intent_stats'][intent]
            stats['failure'] += 1
            stats['total'] += 1
            stats['last_result'] = 'failure'

        self.data['experiences'].append({
            'timestamp': now,
            'type': 'failure',
            'source': source,
            'intent': intent,
            'reason': reason[:80] if reason else '',
        })
        self._trim_experiences()
        self.save()
        return {
            'consecutive_failure': self.data['source_effectiveness'].get(source, {}).get('consecutive_failure', 0),
            'total_failure': self.data['source_effectiveness'].get(source, {}).get('total_failure', 0),
            'updated': updated,
            'status': 'DEGRADED' if updated else 'recorded',
        }

    def _trim_experiences(self):
        """保留最近500条经验"""
        if len(self.data['experiences']) > 500:
            self.data['experiences'] = self.data['experiences'][-500:]

    # ── 检测修正 ──────────────────────────────────────────────

    def detect_correction(self, text: str) -> Optional[Dict]:
        return self._ct.detect(text)

    def add_correction(self, text: str, context: str = "") -> bool:
        return self._ct.add_correction(text, context)

    # ── 报告与健康检查 ────────────────────────────────────────

    def get_report(self) -> str:
        """生成自学习状态报告"""
        lines = ["", "=" * 56]
        lines.append("  [LEARN] 自学习状态报告")
        lines.append("=" * 56)

        # 来源效果
        lines.append("\n  [1] 来源效果（权重越高越优先使用）")
        lines.append(f"  {'来源':<18} {'权重':<8} {'成功':<8} {'失败':<8} {'连胜':<6}")
        lines.append("  " + "-" * 50)
        for src, cfg in self.SOURCES.items():
            s = self.data['source_effectiveness'].get(src, {})
            weight = s.get('weight', 1.0)
            success = s.get('total_success', 0)
            failure = s.get('total_failure', 0)
            consec = s.get('consecutive_success', 0)
            bar = "[OK]" if consec >= 3 else "[  ]" if consec > 0 else "    "
            lines.append(f"  {cfg['label']:<18} {weight:<8.3f} {success:<8} {failure:<8} {bar}{consec:<4}")

        # 意图命中率
        lines.append("\n  [2] 意图路由命中率")
        lines.append(f"  {'意图':<20} {'总计':<8} {'成功':<8} {'命中率':<10}")
        lines.append("  " + "-" * 46)
        for intent, stats in self.data['intent_stats'].items():
            total = stats['total']
            success = stats['success']
            rate = f"{success/total*100:.0f}%" if total > 0 else "N/A"
            lines.append(f"  {intent:<20} {total:<8} {success:<8} {rate:<10}")

        # 关键词权重
        lines.append("\n  [3] 关键词权重")
        sorted_kw = sorted(self.data['keyword_weights'].items(), key=lambda x: -x[1])
        lines.append(f"  {'关键词':<12} {'权重':<8} {'关键词':<12} {'权重':<8}")
        for i in range(0, len(sorted_kw), 2):
            a, wa = sorted_kw[i]
            if i + 1 < len(sorted_kw):
                b, wb = sorted_kw[i + 1]
                lines.append(f"  {a:<12} {wa:<8.3f} {b:<12} {wb:<8.3f}")
            else:
                lines.append(f"  {a:<12} {wa:<8.3f}")

        # 修正记录
        corrections = self.data.get('corrections', [])
        lines.append(f"\n  [4] 修正记录 ({len(corrections)}条)")
        if corrections:
            for c in corrections[:5]:
                lines.append(f"    [{c['type']:<16}] {c['text_preview'][:35]}... x{c['count']}")
        else:
            lines.append("    暂无修正记录")

        # 经验池
        lines.append(f"\n  [5] 经验池 ({len(self.data['experiences'])}条)")
        lines.append("=" * 56)
        return "\n".join(lines)

    def health_check(self) -> Dict:
        """自我反省审计，返回健康度指标"""
        data = self.data
        issues = []

        # 检查各来源权重是否漂移
        for src in self.SOURCES:
            s = data['source_effectiveness'].get(src, {})
            weight = s.get('weight', 1.0)
            base = self.SOURCES[src]['boost']
            drift = abs(weight - base) / base
            if drift > 0.5:
                issues.append(f"权重漂移[{src}]: 当前{weight:.3f} vs 基线{base:.3f} (漂移{int(drift*100)}%)")

        # 检查僵尸经验（30天无更新）
        cutoff = datetime.now().timestamp() - 30 * 86400
        zombie = [e for e in data['experiences'] if datetime.fromisoformat(e['timestamp']).timestamp() < cutoff]
        if zombie:
            issues.append(f"僵尸经验: {len(zombie)}条超过30天未更新")

        # 检查未处理修正
        uncorrected = [c for c in data.get('corrections', []) if c['count'] >= 2]
        if uncorrected:
            issues.append(f"高频修正: {len(uncorrected)}条被重复提出")

        # 计算意图总体命中率
        total_intents = sum(s['total'] for s in data['intent_stats'].values())
        total_success = sum(s['success'] for s in data['intent_stats'].values())
        intent_rate = total_success / total_intents if total_intents > 0 else 0

        # 经验→范式转化率（范式数/经验数，目标>20%）
        exp_count = len(data['experiences'])
        para_count = len(data.get('paradigms', []))
        conv_rate = para_count / exp_count if exp_count > 0 else 0

        status = 'HEALTHY' if len(issues) == 0 else 'WARNING' if len(issues) <= 2 else 'DEGRADED'

        return {
            'status': status,
            'intent_hit_rate': f"{intent_rate*100:.1f}%",
            'experience_count': exp_count,
            'paradigm_count': para_count,
            'exp_to_para_rate': f"{conv_rate*100:.1f}%",
            'issues': issues,
            'timestamp': datetime.now().isoformat(),
        }

    def format_health(self) -> str:
        h = self.health_check()
        lines = ["", "=" * 56]
        lines.append("  [LEARN] 自我反省审计")
        lines.append("=" * 56)
        status_icon = {"HEALTHY": "[OK] 健康", "WARNING": "[!] 警告", "DEGRADED": "[X] 退化"}
        lines.append(f"  整体状态: {status_icon.get(h['status'], h['status'])}")
        lines.append(f"  意图命中率: {h['intent_hit_rate']}")
        lines.append(f"  经验数量: {h['experience_count']}")
        lines.append(f"  范式数量: {h['paradigm_count']}")
        lines.append(f"  经验→范式转化率: {h['exp_to_para_rate']}")
        if h['issues']:
            lines.append("\n  发现问题:")
            for iss in h['issues']:
                lines.append(f"    [!] {iss}")
        else:
            lines.append("\n  [OK] 未发现问题")
        lines.append("=" * 56)
        return "\n".join(lines)


# ══════════════════════════════════════════════════════════════
# CLI 入口
# ══════════════════════════════════════════════════════════════

def main():
    import argparse
    parser = argparse.ArgumentParser(description="龙虾技能管家 - 自学习引擎 CLI")
    parser.add_argument('--report', action='store_true', help='学习状态报告')
    parser.add_argument('--health', action='store_true', help='自我反省审计')
    parser.add_argument('--record-success', nargs=3, metavar=('SOURCE', 'INTENT', 'KEYWORD'),
                        help='记录成功: SOURCE INTENT KEYWORD')
    parser.add_argument('--record-failure', nargs=3, metavar=('SOURCE', 'INTENT', 'REASON'),
                        help='记录失败: SOURCE INTENT REASON')
    parser.add_argument('--detect', metavar='TEXT', help='检测修正/反馈')
    parser.add_argument('--add-correction', metavar='TEXT', help='添加修正记录')
    args = parser.parse_args()

    ld = LearningData()

    if args.report:
        sys.stdout.buffer.write((ld.get_report() + "\n").encode("utf-8", errors="replace"))
    elif args.health:
        sys.stdout.buffer.write((ld.format_health() + "\n").encode("utf-8", errors="replace"))
    elif args.record_success:
        source, intent, keyword = args.record_success
        result = ld.record_success(source, intent, keyword)
        sys.stdout.buffer.write(f"[OK] 记录成功: 连胜{result['consecutive']}次 | 总成功{result['total_success']}次 | {result['status']}\n".encode("utf-8", errors="replace"))
        if result['updated']:
            for u in result['updated']:
                sys.stdout.buffer.write(f"  {u}\n".encode("utf-8", errors="replace"))
    elif args.record_failure:
        source, intent, reason = args.record_failure
        result = ld.record_failure(source, intent, reason)
        sys.stdout.buffer.write(f"[!] 记录失败: 连败{result['consecutive_failure']}次 | 总失败{result['total_failure']}次 | {result['status']}\n".encode("utf-8", errors="replace"))
        if result['updated']:
            for u in result['updated']:
                sys.stdout.buffer.write(f"  {u}\n".encode("utf-8", errors="replace"))
    elif args.detect:
        result = ld.detect_correction(args.detect)
        if result:
            sys.stdout.buffer.write(f"[DETECTED] type={result['type']} match='{result['match']}'\n".encode("utf-8", errors="replace"))
        else:
            sys.stdout.buffer.write("[CLEAN] 无修正/反馈信号\n".encode("utf-8", errors="replace"))
    elif args.add_correction:
        ok = ld.add_correction(args.add_correction)
        sys.stdout.buffer.write(f"[{'OK' if ok else 'SKIP'}] 修正已{'添加' if ok else '跳过'}\n".encode("utf-8", errors="replace"))
    else:
        sys.stdout.buffer.write(("帮助:\n  --report            学习状态报告\n  --health            自我反省审计\n  --record-success SOURCE INTENT KW   记录成功\n  --record-failure SOURCE INTENT REASON  记录失败\n  --detect TEXT       检测修正/反馈\n  --add-correction TEXT  添加修正记录\n").encode("utf-8", errors="replace"))

    sys.stdout.buffer.write("\n联系作者QQ：1817694478\n".encode("utf-8", errors="replace"))


if __name__ == "__main__":
    main()
