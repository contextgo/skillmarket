# Copyright (c) 2026 ZXJ@DEVS. Author: QQ 1817694478 | Q-Group: 972156177
# Skill: dragon-skill-hub | Version: 1.1.0

"""
clawhub_workflow.py - 审核流程引擎
五阶段模型: 提交 → AI初筛 → 风险判定 → 人工复核 → 发布/反馈
"""

import os
import sys
import json
import sqlite3
from pathlib import Path
from typing import Dict, List, Any, Optional
from datetime import datetime

# UTF-8编码兼容
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')


class AuditWorkflow:
    """
    审核工作流管理器
    五阶段: submit → ai_scan → risk_classification → manual_review → publish_feedback
    """

    STAGES = ["submit", "ai_scan", "risk_classification", "manual_review", "publish_feedback"]

    RISK_LEVELS = {
        "low": {"label": "低风险", "emoji": "[OK]", "color": "green",
                "action": "自动通过", "description": "所有扫描项PASS或仅WARNING"},
        "medium": {"label": "中风险", "emoji": "[!]", "color": "yellow",
                  "action": "有条件通过", "description": "1-2个WARNING，发布时加风险提示"},
        "high": {"label": "高风险", "emoji": "[X]", "color": "red",
                "action": "人工复核", "description": "有FAIL项，需开发者修复后重提"},
        "rejected": {"label": "拒绝", "emoji": "[XX]", "color": "red",
                    "action": "拒绝发布", "description": "严重安全问题，拒绝并通知"},
    }

    def __init__(self):
        self._init_db()

    def _init_db(self):
        """确保数据库表存在"""
        base = Path.home() / ".workbuddy" / "skills" / "dragon-skill-hub" / "data"
        base.mkdir(parents=True, exist_ok=True)
        db_path = str(base / "clawhub.db")

        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        # 审核队列表
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS review_queue (
                skill_id TEXT PRIMARY KEY,
                skill_name TEXT,
                submitted_by TEXT,
                submitted_at TEXT DEFAULT CURRENT_TIMESTAMP,
                current_stage TEXT DEFAULT 'submit',
                ai_scan_result TEXT,
                risk_level TEXT DEFAULT 'low',
                status TEXT DEFAULT 'pending',
                reviewer_id TEXT,
                reviewed_at TEXT,
                feedback TEXT,
                stages_completed TEXT DEFAULT '[]'
            )
        """)
        conn.commit()
        conn.close()

    def get_db_path(self) -> str:
        base = Path.home() / ".workbuddy" / "skills" / "dragon-skill-hub" / "data"
        return str(base / "clawhub.db")

    # ==================== 工作流入口 ====================

    def submit(self, skill_dir: str, skill_name: str, submitted_by: str = "unknown") -> Dict[str, Any]:
        """
        阶段1: 提交审核
        """
        db_path = self.get_db_path()
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # 检查是否已存在
        cursor.execute("SELECT status, current_stage FROM review_queue WHERE skill_id = ?", (skill_name,))
        existing = cursor.fetchone()

        if existing:
            conn.close()
            return {
                "success": False,
                "message": f"技能 {skill_name} 已在审核队列中",
                "existing_status": existing[0],
                "current_stage": existing[1]
            }

        cursor.execute("""
            INSERT INTO review_queue (skill_id, skill_name, submitted_by, current_stage, status)
            VALUES (?, ?, ?, 'submit', 'in_progress')
        """, (skill_name, skill_name, submitted_by))
        conn.commit()
        conn.close()

        return {
            "success": True,
            "stage": "submit",
            "skill_id": skill_name,
            "message": f"技能 {skill_name} 已提交审核，进入第1阶段",
            "next_stage": "ai_scan",
            "stages": {
                "1_submit": {"status": "completed", "message": "提交成功"},
                "2_ai_scan": {"status": "pending", "message": "等待AI初筛"},
                "3_risk": {"status": "pending", "message": "等待风险判定"},
                "4_manual_review": {"status": "pending", "message": "等待人工复核"},
                "5_publish": {"status": "pending", "message": "等待发布"}
            }
        }

    def run_ai_scan(self, skill_id: str, scan_result: Dict) -> Dict[str, Any]:
        """
        阶段2: AI初筛
        """
        db_path = self.get_db_path()
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # 更新阶段和扫描结果
        cursor.execute("""
            UPDATE review_queue
            SET current_stage = 'ai_scan',
                ai_scan_result = ?,
                stages_completed = stages_completed || '["ai_scan"]'
            WHERE skill_id = ?
        """, (json.dumps(scan_result), skill_id))
        conn.commit()

        # 触发风险判定
        risk_level = self._classify_risk(scan_result)
        cursor.execute("""
            UPDATE review_queue SET risk_level = ? WHERE skill_id = ?
        """, (risk_level, skill_id))
        conn.commit()
        conn.close()

        # 格式化扫描结果
        from clawhub_scanner import AIScanner
        scanner = AIScanner()
        report = scanner.format_scan_report({"skill_name": skill_id, **scan_result})

        return {
            "success": True,
            "stage": "ai_scan",
            "risk_level": risk_level,
            "risk_info": self.RISK_LEVELS[risk_level],
            "scan_report": report,
            "next_stage": "risk_classification" if risk_level != "rejected" else "publish_feedback",
            "message": f"AI初筛完成，风险等级: {self.RISK_LEVELS[risk_level]['label']}"
        }

    def _classify_risk(self, scan_result: Dict) -> str:
        """基于AI初筛结果判定风险等级"""
        checks = scan_result.get("checks", [])

        # 检测P0问题
        p0_fail = sum(
            1 for c in checks
            if c.get("severity") in ("BLOCKER", "P0")
            and c.get("status") == "FAIL"
        )

        # 检测WARNING
        warn_count = sum(1 for c in checks if c.get("status") == "WARN")

        if p0_fail > 0:
            # 检测是否严重到拒绝
            for c in checks:
                if c.get("severity") in ("BLOCKER", "P0") and c.get("status") == "FAIL":
                    code = c.get("item", "")
                    if code in ("credential_scan",) and "exec" in str(c.get("detail", "")).lower():
                        return "rejected"
            return "high"
        elif warn_count > 2:
            return "medium"
        else:
            return "low"

    def approve(self, skill_id: str, reviewer_id: str = "system") -> Dict[str, Any]:
        """
        阶段4+5: 通过审核 → 发布
        """
        db_path = self.get_db_path()
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        cursor.execute("""
            UPDATE review_queue
            SET current_stage = 'publish_feedback',
                status = 'approved',
                reviewer_id = ?,
                reviewed_at = ?,
                feedback = ?,
                stages_completed = stages_completed || '["manual_review","publish_feedback"]'
            WHERE skill_id = ?
        """, (
            reviewer_id,
            datetime.now().isoformat(),
            "审核通过，技能已发布",
            skill_id
        ))
        conn.commit()
        conn.close()

        return {
            "success": True,
            "stage": "publish_feedback",
            "status": "approved",
            "message": f"技能 {skill_id} 审核通过，已发布上线！",
            "details": [
                "已入库技能索引库",
                "已更新搜索索引",
                "已通知开发者"
            ]
        }

    def reject(self, skill_id: str, feedback: str, reviewer_id: str = "system") -> Dict[str, Any]:
        """
        拒绝技能
        """
        db_path = self.get_db_path()
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        cursor.execute("""
            UPDATE review_queue
            SET current_stage = 'publish_feedback',
                status = 'rejected',
                reviewer_id = ?,
                reviewed_at = ?,
                feedback = ?
            WHERE skill_id = ?
        """, (reviewer_id, datetime.now().isoformat(), feedback, skill_id))
        conn.commit()
        conn.close()

        return {
            "success": True,
            "stage": "publish_feedback",
            "status": "rejected",
            "message": f"技能 {skill_id} 未通过审核",
            "feedback": feedback
        }

    def get_workflow_status(self, skill_id: str) -> Optional[Dict[str, Any]]:
        """获取工作流状态"""
        db_path = self.get_db_path()
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        cursor.execute("SELECT * FROM review_queue WHERE skill_id = ?", (skill_id,))
        row = cursor.fetchone()
        conn.close()

        if not row:
            return None

        row = dict(row)
        current_stage = row.get("current_stage", "submit")
        stages_completed = json.loads(row.get("stages_completed", "[]"))

        return {
            "skill_id": skill_id,
            "skill_name": row.get("skill_name", skill_id),
            "status": row.get("status", "pending"),
            "current_stage": current_stage,
            "risk_level": row.get("risk_level", "low"),
            "risk_info": self.RISK_LEVELS.get(row.get("risk_level", "low"), {}),
            "submitted_at": row.get("submitted_at", ""),
            "reviewed_at": row.get("reviewed_at", ""),
            "feedback": row.get("feedback", ""),
            "stages": self._format_stages(current_stage, stages_completed)
        }

    def _format_stages(self, current: str, completed: List[str]) -> Dict[str, Dict]:
        """格式化阶段状态"""
        stage_map = {
            "submit": "1_submit",
            "ai_scan": "2_ai_scan",
            "risk_classification": "3_risk",
            "manual_review": "4_manual_review",
            "publish_feedback": "5_publish"
        }
        result = {}
        for stage, label in stage_map.items():
            status = "completed" if stage in completed else ("active" if stage == current else "pending")
            result[label] = {
                "status": status,
                "stage": stage
            }
        return result

    def format_workflow_display(self, status: Dict) -> str:
        """格式化工作流展示"""
        lines = [
            "",
            "=" * 50,
            f"  审核工作流 - {status['skill_id']}",
            "=" * 50,
            f"  状态: {status['status'].upper()}",
            f"  风险: {status['risk_info'].get('label', 'N/A')}",
            f"  提交时间: {status['submitted_at'][:19] if status['submitted_at'] else 'N/A'}",
        ]

        if status.get("reviewed_at"):
            lines.append(f"  审核时间: {status['reviewed_at'][:19]}")

        lines.append("-" * 50)
        lines.append("  阶段进度:")
        for label, info in status["stages"].items():
            icon = {"completed": "[OK]", "active": ">>>", "pending": "   "}.get(info["status"], "   ")
            status_text = {"completed": "完成", "active": "进行中", "pending": "等待"}.get(info["status"], "N/A")
            lines.append(f"    {icon} {label.replace('_', ' ').title()} - {status_text}")

        if status.get("feedback"):
            lines.append("")
            lines.append(f"  审核反馈: {status['feedback']}")

        lines.append("=" * 50)
        return "\n".join(lines)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="龙虾技能审核工作流")
    parser.add_argument("--submit", type=str, help="提交技能审核")
    parser.add_argument("--scan", type=str, help="执行AI扫描")
    parser.add_argument("--status", type=str, help="查看审核状态")
    parser.add_argument("--approve", type=str, help="通过审核")
    parser.add_argument("--reject", type=str, nargs=2, metavar=("skill_id", "reason"), help="拒绝审核")
    args = parser.parse_args()

    wf = AuditWorkflow()

    if args.submit:
        result = wf.submit(args.submit, args.submit)
        print(json.dumps(result, ensure_ascii=False, indent=2))

    elif args.scan:
        from clawhub_scanner import AIScanner
        scanner = AIScanner()
        scan_result = scanner.scan(args.scan)
        result = wf.run_ai_scan(args.scan, scan_result)
        print(result["scan_report"])
        print(json.dumps({"risk_level": result["risk_level"]}, ensure_ascii=False))

    elif args.status:
        status = wf.get_workflow_status(args.status)
        if status:
            print(wf.format_workflow_display(status))
        else:
            print(f"[INFO] 技能 {args.status} 不在审核队列中")

    elif args.approve:
        result = wf.approve(args.approve)
        print(json.dumps(result, ensure_ascii=False, indent=2))

    elif args.reject:
        skill_id, reason = args.reject
        result = wf.reject(skill_id, reason)
        print(json.dumps(result, ensure_ascii=False, indent=2))

    else:
        print("用法:")
        print("  --submit <skill_name>     提交审核")
        print("  --scan <skill_dir>        执行AI扫描")
        print("  --status <skill_id>       查看审核状态")
        print("  --approve <skill_id>      通过审核")
        print("  --reject <skill_id> <reason> 拒绝审核")
