# Copyright (c) 2026 ZXJ@DEVS. Author: QQ 1817694478 | Q-Group: 972156177
# Skill: dragon-skill-hub | Version: 1.1.0

"""
clawhub_snapshot.py - 备份快照系统
支持: 自动快照创建 / 手动快照 / 回滚操作 / 过期清理
"""

import os
import sys
import json
import shutil
import zipfile
import hashlib
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Any, Optional

# UTF-8编码兼容
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')


class SnapshotManager:
    """
    备份快照管理器
    - 自动创建快照
    - 版本回滚
    - 快照列表
    - 过期清理
    """

    def __init__(self, snapshot_dir: str = None):
        if snapshot_dir is None:
            base = Path.home() / ".workbuddy" / "skills" / "dragon-skill-hub" / "data" / "snapshots"
            base.mkdir(parents=True, exist_ok=True)
            self.snapshot_dir = str(base)
        else:
            self.snapshot_dir = snapshot_dir
            Path(snapshot_dir).mkdir(parents=True, exist_ok=True)

    def create_snapshot(self, skill_dir: str, skill_name: str,
                        version: str = None, snapshot_type: str = "auto",
                        note: str = "") -> Optional[Dict[str, Any]]:
        """
        创建技能快照
        返回: {snapshot_id, file_path, size_bytes, checksum}
        """
        skill_dir = os.path.abspath(skill_dir)
        if not os.path.isdir(skill_dir):
            return None

        version = version or self._detect_version(skill_dir)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        snapshot_name = f"{skill_name}_v{version}_{timestamp}.zip"
        snapshot_path = os.path.join(self.snapshot_dir, snapshot_name)

        try:
            # 打包技能目录
            size_bytes = self._zip_directory(skill_dir, snapshot_path)

            # 计算SHA256
            checksum = self._calc_checksum(snapshot_path)

            # 生成snapshot_id
            import uuid
            snapshot_id = str(uuid.uuid4())

            result = {
                "snapshot_id": snapshot_id,
                "skill_name": skill_name,
                "version": version,
                "file_path": snapshot_path,
                "size_bytes": size_bytes,
                "checksum": checksum,
                "created_at": datetime.now().isoformat(),
                "snapshot_type": snapshot_type,
                "note": note
            }

            # 保存元数据
            meta_path = snapshot_path + ".meta.json"
            with open(meta_path, "w", encoding="utf-8") as f:
                json.dump(result, f, ensure_ascii=False, indent=2)

            return result

        except Exception as e:
            print(f"[ERROR] 创建快照失败: {str(e)}")
            return None

    def restore_snapshot(self, snapshot_path: str, target_dir: str) -> bool:
        """
        从快照恢复技能
        """
        if not os.path.exists(snapshot_path):
            print(f"[ERROR] 快照文件不存在: {snapshot_path}")
            return False

        # 验证checksum
        if not self._verify_checksum(snapshot_path):
            print(f"[ERROR] 快照校验失败，可能已损坏")
            return False

        try:
            # 清理目标目录
            if os.path.exists(target_dir):
                shutil.rmtree(target_dir)
            os.makedirs(os.path.dirname(target_dir) or ".", exist_ok=True)

            # 解压
            with zipfile.ZipFile(snapshot_path, "r") as zf:
                zf.extractall(os.path.dirname(target_dir) or ".")

            # 重命名
            extracted_name = os.path.basename(snapshot_path).replace(".zip", "")
            extracted_path = os.path.join(os.path.dirname(target_dir), extracted_name)
            if os.path.exists(extracted_path) and extracted_path != target_dir:
                if os.path.exists(target_dir):
                    shutil.rmtree(target_dir)
                shutil.move(extracted_path, target_dir)

            print(f"[OK] 快照恢复成功: {target_dir}")
            return True

        except Exception as e:
            print(f"[ERROR] 恢复失败: {str(e)}")
            return False

    def list_snapshots(self, skill_name: str = None) -> List[Dict[str, Any]]:
        """列出快照"""
        snapshots = []
        for fname in os.listdir(self.snapshot_dir):
            if fname.endswith(".meta.json"):
                meta_path = os.path.join(self.snapshot_dir, fname)
                try:
                    with open(meta_path, "r", encoding="utf-8") as f:
                        meta = json.load(f)
                    if skill_name and meta.get("skill_name") != skill_name:
                        continue
                    snapshots.append(meta)
                except Exception:
                    pass

        # 按时间倒序
        snapshots.sort(key=lambda x: x.get("created_at", ""), reverse=True)
        return snapshots

    def cleanup_old_snapshots(self, days: int = 30, max_per_skill: int = 5) -> Dict[str, int]:
        """
        清理过期快照
        - 删除超过days天的自动快照
        - 每个技能最多保留max_per_skill个
        """
        stats = {"deleted": 0, "kept": 0}
        cutoff = datetime.now() - timedelta(days=days)

        # 按技能分组
        skill_snapshots = {}
        for fname in os.listdir(self.snapshot_dir):
            if not fname.endswith(".meta.json"):
                continue
            meta_path = os.path.join(self.snapshot_dir, fname)
            try:
                with open(meta_path, "r", encoding="utf-8") as f:
                    meta = json.load(f)
                skill_name = meta.get("skill_name", "unknown")
                if skill_name not in skill_snapshots:
                    skill_snapshots[skill_name] = []
                skill_snapshots[skill_name].append(meta)
            except Exception:
                pass

        # 清理每个技能
        for skill_name, snaps in skill_snapshots.items():
            # 按时间排序
            snaps.sort(key=lambda x: x.get("created_at", ""), reverse=True)

            for i, snap in enumerate(snaps):
                delete_reason = None
                if snap.get("snapshot_type") == "auto":
                    # 检查过期
                    try:
                        created = datetime.fromisoformat(snap["created_at"])
                        if created < cutoff:
                            delete_reason = "expired"
                    except Exception:
                        pass

                # 检查数量
                if not delete_reason and i >= max_per_skill:
                    delete_reason = "exceed_max"

                if delete_reason:
                    self._delete_snapshot(snap)
                    stats["deleted"] += 1
                else:
                    stats["kept"] += 1

        return stats

    def _delete_snapshot(self, snapshot_meta: Dict):
        """删除快照及其元数据"""
        for key in ["file_path"]:
            fpath = snapshot_meta.get(key)
            if fpath and os.path.exists(fpath):
                try:
                    os.remove(fpath)
                except Exception:
                    pass
        meta_path = snapshot_meta.get("file_path", "") + ".meta.json"
        if os.path.exists(meta_path):
            try:
                os.remove(meta_path)
            except Exception:
                pass

    # ==================== 辅助方法 ====================

    def _detect_version(self, skill_dir: str) -> str:
        """检测技能版本"""
        manifest_path = os.path.join(skill_dir, "manifest.json")
        if os.path.exists(manifest_path):
            try:
                with open(manifest_path, "r", encoding="utf-8") as f:
                    manifest = json.load(f)
                return manifest.get("version", "1.0.0")
            except Exception:
                pass
        return "1.0.0"

    def _zip_directory(self, source_dir: str, output_path: str) -> int:
        """打包目录为zip"""
        total_size = 0
        with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
            for root, dirs, files in os.walk(source_dir):
                # 排除
                dirs[:] = [d for d in dirs if d not in [
                    "__pycache__", ".git", ".clawdhub", "node_modules", "data", "reports"
                ]]
                for file in files:
                    if file.endswith((".pyc", ".pyo", ".log", ".lock")):
                        continue
                    fpath = os.path.join(root, file)
                    arcname = os.path.relpath(fpath, source_dir)
                    zf.write(fpath, arcname)
                    total_size += os.path.getsize(fpath)
        return total_size

    def _calc_checksum(self, file_path: str) -> str:
        """计算SHA256校验和"""
        sha = hashlib.sha256()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                sha.update(chunk)
        return sha.hexdigest()

    def _verify_checksum(self, file_path: str) -> bool:
        """验证文件校验和"""
        meta_path = file_path + ".meta.json"
        if not os.path.exists(meta_path):
            return True  # 无元数据时跳过验证
        try:
            with open(meta_path, "r", encoding="utf-8") as f:
                meta = json.load(f)
            expected = meta.get("checksum", "")
            if not expected:
                return True
            actual = self._calc_checksum(file_path)
            return actual == expected
        except Exception:
            return True


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="龙虾技能快照管理")
    parser.add_argument("--create", nargs=2, metavar=("skill_dir", "skill_name"), help="创建快照")
    parser.add_argument("--list", type=str, metavar="skill_name", help="列出快照")
    parser.add_argument("--restore", nargs=2, metavar=("snapshot_path", "target_dir"), help="恢复快照")
    parser.add_argument("--cleanup", action="store_true", help="清理过期快照")
    args = parser.parse_args()

    mgr = SnapshotManager()

    if args.create:
        skill_dir, skill_name = args.create
        result = mgr.create_snapshot(skill_dir, skill_name, snapshot_type="manual")
        if result:
            print(f"[OK] 快照创建成功: {result['file_path']}")
            print(f"    大小: {result['size_bytes']} bytes")
            print(f"    校验: {result['checksum'][:16]}...")
        else:
            print("[ERROR] 创建快照失败")

    elif args.list is not None:
        skill_name = args.list if args.list != "None" else None
        snaps = mgr.list_snapshots(skill_name)
        if not snaps:
            print("[INFO] 暂无快照")
        else:
            print(f"[INFO] 快照列表 ({len(snaps)}):")
            for s in snaps:
                print(f"  - {s['skill_name']} v{s['version']} [{s['snapshot_type']}] {s['created_at'][:19]}")

    elif args.restore:
        path, target = args.restore
        mgr.restore_snapshot(path, target)

    elif args.cleanup:
        stats = mgr.cleanup_old_snapshots(days=30, max_per_skill=5)
        print(f"[OK] 清理完成: 删除 {stats['deleted']}, 保留 {stats['kept']}")

    else:
        print("用法:")
        print("  --create <skill_dir> <skill_name>  创建快照")
        print("  --list [skill_name]               列出快照")
        print("  --restore <path> <target>         恢复快照")
        print("  --cleanup                         清理过期快照")
