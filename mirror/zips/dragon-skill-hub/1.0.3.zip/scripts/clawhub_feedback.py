# Copyright (c) 2026 ZXJ@DEVS. Author: QQ 1817694478 | Q-Group: 972156177
# Skill: dragon-skill-hub | Version: 1.1.0

"""
clawhub_feedback.py - 龙虾技能管家反馈收集器
继承自 skill-self-learning-core 的反馈收集机制
"""

import os
import sys
import json
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional

# UTF-8编码兼容
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')

SCRIPT_DIR = Path(__file__).parent
SKILL_DIR = SCRIPT_DIR.parent
ASSETS_DIR = SKILL_DIR / "assets"

FEEDBACK_PATH = ASSETS_DIR / "feedback.json"

PRESET_TAGS = ['时效性', '准确性', '完整性', '实用性', '易懂性', '重复性']


class FeedbackCollector:
    """反馈收集：星级 + 标签 + 评论"""

    def __init__(self):
        ASSETS_DIR.mkdir(parents=True, exist_ok=True)
        self.path = str(FEEDBACK_PATH)
        self.data = self._load()

    def _load(self) -> Dict:
        if os.path.exists(self.path):
            try:
                with open(self.path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError):
                pass
        return {'reviews': [], 'stats': {'total': 0, 'sum_rating': 0, 'tag_counts': {t: 0 for t in PRESET_TAGS}}}

    def _save(self):
        try:
            with open(self.path, 'w', encoding='utf-8') as f:
                json.dump(self.data, f, ensure_ascii=False, indent=2)
        except IOError:
            pass

    def quick_feedback(self, rating: int, comment: str = "", tags: List[str] = None) -> Dict:
        """快速反馈记录（非交互式）"""
        if not (1 <= rating <= 5):
            return {'success': False, 'error': 'rating must be 1-5'}

        review = {
            'timestamp': datetime.now().isoformat(),
            'rating': rating,
            'comment': comment[:200] if comment else '',
            'tags': [t for t in (tags or []) if t in PRESET_TAGS],
            'auto': True,
        }
        self.data['reviews'].append(review)
        self.data['stats']['total'] += 1
        self.data['stats']['sum_rating'] += rating
        for tag in review['tags']:
            self.data['stats']['tag_counts'][tag] = self.data['stats']['tag_counts'].get(tag, 0) + 1
        self._save()
        return {'success': True, 'avg_rating': self.avg_rating, 'total': self.data['stats']['total']}

    def get_summary(self) -> str:
        stats = self.data['stats']
        total = stats['total']
        avg = self.avg_rating
        recent = self.data['reviews'][-5:]

        lines = ["", "=" * 56]
        lines.append("  [FEEDBACK] 用户反馈汇总")
        lines.append("=" * 56)
        lines.append(f"  总评价数: {total}")
        lines.append(f"  平均星级: {'*' * int(avg)}{'.' * (5 - int(avg))} ({avg:.1f}/5)")
        lines.append(f"\n  标签分布:")
        tag_counts = stats.get('tag_counts', {})
        if tag_counts and sum(tag_counts.values()) > 0:
            for tag in PRESET_TAGS:
                cnt = tag_counts.get(tag, 0)
                bar = '+' * min(cnt, 20)
                lines.append(f"    {tag:<8} {cnt:>4} {bar}")
        lines.append(f"\n  最近 {len(recent)} 条反馈:")
        for r in reversed(recent):
            stars = '*' * r['rating']
            ts = r['timestamp'][:10]
            comment = r['comment'][:30] if r['comment'] else '(无评论)'
            lines.append(f"    {ts} {stars} {comment}")
        lines.append("=" * 56)
        return "\n".join(lines)

    @property
    def avg_rating(self) -> float:
        stats = self.data['stats']
        if stats['total'] == 0:
            return 0.0
        return stats['sum_rating'] / stats['total']


def main():
    import argparse
    parser = argparse.ArgumentParser(description="龙虾技能管家 - 反馈收集 CLI")
    parser.add_argument('--quick', nargs='+', metavar='RATING [COMMENT] [TAGS]',
                        help='快速反馈: 星级 [评论] [标签1,标签2...]')
    parser.add_argument('--summary', action='store_true', help='反馈汇总')
    args = parser.parse_args()

    fc = FeedbackCollector()

    if args.summary:
        sys.stdout.buffer.write((fc.get_summary() + "\n").encode("utf-8", errors="replace"))
    elif args.quick:
        rating = int(args.quick[0])
        comment = args.quick[1] if len(args.quick) > 1 else ""
        tags = args.quick[2].split(',') if len(args.quick) > 2 else []
        result = fc.quick_feedback(rating, comment, tags)
        if result['success']:
            sys.stdout.buffer.write(f"[OK] 反馈已记录 | 平均星级: {result['avg_rating']:.1f} | 总计: {result['total']}条\n".encode("utf-8", errors="replace"))
        else:
            sys.stdout.buffer.write(f"[ERROR] {result['error']}\n".encode("utf-8", errors="replace"))
    else:
        sys.stdout.buffer.write(("用法:\n  --quick RATING [COMMENT] [TAGS]  快速反馈\n  --summary                    反馈汇总\n").encode("utf-8", errors="replace"))

    sys.stdout.buffer.write("联系作者QQ：1817694478\n".encode("utf-8", errors="replace"))


if __name__ == "__main__":
    main()
