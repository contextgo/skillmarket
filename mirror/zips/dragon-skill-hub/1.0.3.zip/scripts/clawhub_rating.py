# Copyright (c) 2026 ZXJ@DEVS. Author: QQ 1817694478 | Q-Group: 972156177
# Skill: dragon-skill-hub | Version: 1.1.0

"""
clawhub_rating.py - 三层评分系统
B(基础评分30%) + C(社区评分50%) + Q(质量评分20%)
包含贝叶斯估计、用户权重、时效衰减、防刷机制
"""

import json
import sqlite3
import sys
import re
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Any, Optional

# UTF-8编码兼容
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')


class RatingEngine:
    """三层评分引擎"""

    # 权重配置
    WEIGHTS = {
        "basic": 0.30,
        "community": 0.50,
        "quality": 0.20
    }

    # 市场参数
    MARKET_MEAN = 3.5        # 市场平均分
    CONFIDENCE_M = 5        # 贝叶斯置信系数

    # 基础评分维度权重
    BASIC_DIMENSIONS = {
        "functionality": 25,    # 功能完整性
        "documentation": 20,    # 文档质量
        "security": 25,         # 安全性
        "compatibility": 15,    # 兼容性
        "performance": 15       # 性能规范
    }

    def __init__(self, db_path: str = None):
        if db_path is None:
            base = Path.home() / ".workbuddy" / "skills" / "dragon-skill-hub" / "data"
            base.mkdir(parents=True, exist_ok=True)
            db_path = str(base / "clawhub.db")
        self.db_path = db_path

    # ==================== 综合评分 ====================

    def calculate_overall(self, skill_id: str) -> Dict[str, Any]:
        """计算综合评分"""
        B = self._calc_basic_score(skill_id)
        C = self._calc_community_score(skill_id)
        Q = self._calc_quality_score(skill_id)

        overall = B * self.WEIGHTS["basic"] + C * self.WEIGHTS["community"] + Q * self.WEIGHTS["quality"]

        result = {
            "skill_id": skill_id,
            "basic": round(B, 2),
            "basic_label": self._score_to_label(B),
            "community": round(C, 2),
            "community_label": self._score_to_label(C),
            "quality": round(Q, 2),
            "quality_label": self._score_to_label(Q),
            "overall": round(overall, 2),
            "overall_label": self._score_to_label(overall),
            "weights": self.WEIGHTS,
            "total_reviews": self._get_review_count(skill_id),
            "calculated_at": datetime.now().isoformat()
        }
        return result

    def _score_to_label(self, score: float) -> str:
        if score >= 4.5: return "excellent"
        elif score >= 3.5: return "good"
        elif score >= 2.5: return "fair"
        elif score >= 1.5: return "poor"
        else: return "very_poor"

    # ==================== B层: 基础评分(AI自动评估) ====================

    def _calc_basic_score(self, skill_id: str) -> float:
        """
        B = (功能完整分 + 文档质量分 + 安全分 + 兼容分 + 性能分) / 100 * 5
        满分5.0，由AI审核时自动生成
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT rating_basic FROM skills WHERE id = ?", (skill_id,))
        row = cursor.fetchone()
        conn.close()
        if row:
            return row[0]
        return self.MARKET_MEAN

    def update_basic_score(self, skill_id: str, scan_result: Dict) -> bool:
        """
        根据AI扫描结果更新基础评分
        scan_result: AI初筛返回的checks列表
        """
        score = 0.0
        max_score = 0.0

        # 功能完整性 - 通过文件检查加分
        if self._check_files_exist(skill_id):
            score += self.BASIC_DIMENSIONS["functionality"]

        # 文档质量 - 检查README
        if self._check_documentation(skill_id):
            score += self.BASIC_DIMENSIONS["documentation"]

        # 安全性 - 根据扫描结果
        sec_score = self._calc_security_score(scan_result)
        score += sec_score * self.BASIC_DIMENSIONS["security"] / 100

        # 兼容性 - 检查平台支持
        compat_score = self._check_compatibility(skill_id)
        score += compat_score * self.BASIC_DIMENSIONS["compatibility"] / 100

        # 性能规范 - 检查代码质量
        perf_score = self._check_performance(scan_result)
        score += perf_score * self.BASIC_DIMENSIONS["performance"] / 100

        B = (score / 100) * 5
        B = max(1.0, min(5.0, B))  # 限制在1-5

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("UPDATE skills SET rating_basic = ? WHERE id = ?", (round(B, 2), skill_id))
        conn.commit()
        conn.close()
        return True

    def _check_files_exist(self, skill_id: str) -> bool:
        """检查核心文件是否存在"""
        # 简化：检查数据库中是否有记录
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT 1 FROM skills WHERE id = ?", (skill_id,))
        result = cursor.fetchone() is not None
        conn.close()
        return result

    def _check_documentation(self, skill_id: str) -> float:
        """检查文档完整性，返回0-100"""
        # 简化检查：检查是否有描述
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT description, long_desc FROM skills WHERE id = ?", (skill_id,))
        row = cursor.fetchone()
        conn.close()
        if not row:
            return 0.0
        desc, long_desc = row
        score = 0.0
        if desc and len(desc) > 10:
            score += 50
        if long_desc and len(long_desc) > 50:
            score += 50
        return score

    def _check_compatibility(self, skill_id: str) -> float:
        """检查平台兼容性"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT platform FROM skills WHERE id = ?", (skill_id,))
        row = cursor.fetchone()
        conn.close()
        if not row or not row[0]:
            return 50.0  # 默认50分
        try:
            platform = json.loads(row[0])
            count = sum(1 for v in platform.values() if v)
            return (count / 3) * 100  # 3个平台各占1/3
        except:
            return 50.0

    def _calc_security_score(self, scan_result: Dict) -> float:
        """根据安全扫描结果计算安全分"""
        if not scan_result:
            return 75.0  # 无数据给75分
        checks = scan_result.get("checks", [])
        if not checks:
            return 75.0

        p0_fail = sum(1 for c in checks if c.get("severity") == "BLOCKER" and c.get("status") == "FAIL")
        p1_fail = sum(1 for c in checks if c.get("severity") in ("HIGH", "WARNING") and c.get("status") == "FAIL")
        p2_fail = sum(1 for c in checks if c.get("severity") in ("MEDIUM", "INFO") and c.get("status") == "WARN")

        # 扣分规则
        score = 100.0
        score -= p0_fail * 30
        score -= p1_fail * 15
        score -= p2_fail * 5
        return max(0, score)

    def _check_performance(self, scan_result: Dict) -> float:
        """检查性能规范"""
        # 简化：无明显问题时给满分
        if not scan_result:
            return 100.0
        checks = scan_result.get("checks", [])
        for c in checks:
            if "loop" in str(c).lower() or "timeout" in str(c).lower():
                return 70.0
        return 100.0

    # ==================== C层: 社区评分(用户反馈) ====================

    def _calc_community_score(self, skill_id: str) -> float:
        """
        社区评分 = 贝叶斯平均 * 0.6 + 时效衰减 * 0.4
        """
        reviews = self._get_reviews_with_weights(skill_id)
        if not reviews:
            return self.MARKET_MEAN

        # 计算加权平均
        total_weighted = 0.0
        total_weight = 0.0
        fresh_sum = 0.0
        fresh_count = 0.0
        old_sum = 0.0
        old_count = 0.0

        for r in reviews:
            rating = r["rating"]
            weight = r["weight"]
            created_at = r["created_at"]

            total_weighted += rating * weight
            total_weight += weight

            # 新旧评分分离(90天)
            try:
                review_date = datetime.fromisoformat(created_at)
                days_old = (datetime.now() - review_date).days
                if days_old <= 90:
                    fresh_sum += rating * weight
                    fresh_count += weight
                else:
                    old_sum += rating * weight
                    old_count += weight
            except:
                fresh_sum += rating * weight
                fresh_count += weight

        # 贝叶斯平均
        bayesian = (total_weighted + self.CONFIDENCE_M * self.MARKET_MEAN) / (total_weight + self.CONFIDENCE_M)

        # 时效衰减
        fresh_avg = fresh_sum / fresh_count if fresh_count > 0 else self.MARKET_MEAN
        old_avg = old_sum / old_count if old_count > 0 else self.MARKET_MEAN
        recency_adjusted = fresh_avg * 0.7 + old_avg * 0.3

        # 综合
        final = bayesian * 0.6 + recency_adjusted * 0.4
        return max(1.0, min(5.0, final))

    def _get_reviews_with_weights(self, skill_id: str) -> List[Dict]:
        """获取带权重的评分列表"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute("""
            SELECT rating, weight, created_at, is_verified, use_count
            FROM reviews WHERE skill_id = ? ORDER BY created_at DESC LIMIT 100
        """, (skill_id,))
        rows = cursor.fetchall()
        conn.close()

        reviews = []
        for row in rows:
            rating = row["rating"]
            base_weight = 1.0
            # 经验加成
            use_count = row["use_count"] or 0
            if use_count >= 10:
                exp_mult = 1.5
            elif use_count >= 3:
                exp_mult = 1.2
            else:
                exp_mult = 1.0
            # 验证加成
            verified_mult = 1.2 if row["is_verified"] else 0.8
            weight = base_weight * exp_mult * verified_mult
            reviews.append({
                "rating": rating,
                "weight": weight,
                "created_at": row["created_at"]
            })
        return reviews

    def _get_review_count(self, skill_id: str) -> int:
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM reviews WHERE skill_id = ?", (skill_id,))
        count = cursor.fetchone()[0]
        conn.close()
        return count

    # ==================== Q层: 质量评分(客观数据) ====================

    def _calc_quality_score(self, skill_id: str) -> float:
        """
        Q = (更新活跃度*0.25 + 响应率*0.20 + Issue关闭率*0.15 + 版本规范*0.10 + 安装成功率*0.30) / 100 * 5
        """
        # 更新活跃度(简化)
        update_score = self._calc_update_score(skill_id)
        # 问题响应率(简化)
        response_score = self._calc_response_score(skill_id)
        # 版本规范性
        version_score = self._calc_version_score(skill_id)
        # 安装成功率(简化)
        install_score = self._calc_install_score(skill_id)
        # Issue关闭率(简化)
        resolution_score = 75.0  # 简化默认值

        Q = (update_score * 0.25 + response_score * 0.20 + resolution_score * 0.15
             + version_score * 0.10 + install_score * 0.30) / 100 * 5
        return max(1.0, min(5.0, Q))

    def _calc_update_score(self, skill_id: str) -> float:
        """最近6个月更新次数"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT last_updated FROM skills WHERE id = ?
        """, (skill_id,))
        row = cursor.fetchone()
        conn.close()
        if not row or not row[0]:
            return 50.0
        try:
            last_updated = datetime.fromisoformat(row[0])
            days_since = (datetime.now() - last_updated).days
            if days_since <= 7:
                return 100.0
            elif days_since <= 30:
                return 80.0
            elif days_since <= 90:
                return 60.0
            elif days_since <= 180:
                return 30.0
            else:
                return 10.0
        except:
            return 50.0

    def _calc_response_score(self, skill_id: str) -> float:
        """问题响应率(简化:使用安装量和更新时间推断)"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT install_count FROM skills WHERE id = ?", (skill_id,))
        row = cursor.fetchone()
        conn.close()
        if not row or row[0] == 0:
            return 60.0
        install_count = row[0]
        if install_count >= 1000:
            return 90.0
        elif install_count >= 100:
            return 75.0
        elif install_count >= 10:
            return 60.0
        else:
            return 50.0

    def _calc_version_score(self, skill_id: str) -> float:
        """版本规范性: 是否使用SemVer"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT version FROM skills WHERE id = ?", (skill_id,))
        row = cursor.fetchone()
        conn.close()
        if not row or not row[0]:
            return 50.0
        version = row[0]
        # SemVer格式: X.Y.Z
        if re.match(r'^\d+\.\d+\.\d+$', version):
            return 100.0
        elif re.match(r'^\d+\.\d+$', version):
            return 60.0
        else:
            return 0.0

    def _calc_install_score(self, skill_id: str) -> float:
        """安装成功率(简化:无失败记录时给高分)"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT COUNT(*) FROM audit_log
            WHERE skill_id = ? AND action = 'install' AND result = 'fail'
        """, (skill_id,))
        fail_count = cursor.fetchone()[0]
        cursor.execute("""
            SELECT COUNT(*) FROM audit_log
            WHERE skill_id = ? AND action = 'install'
        """, (skill_id,))
        total_count = cursor.fetchone()[0]
        conn.close()
        if total_count == 0:
            return 95.0
        success_rate = (total_count - fail_count) / total_count * 100
        return success_rate

    # ==================== 防刷机制 ====================

    def detect_anomalies(self, skill_id: str) -> List[Dict]:
        """检测刷分异常"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT user_id, COUNT(*) as cnt, AVG(rating) as avg
            FROM reviews WHERE skill_id = ? GROUP BY user_id
        """, (skill_id,))
        rows = cursor.fetchall()
        conn.close()

        anomalies = []
        for user_id, cnt, avg in rows:
            if cnt > 5:
                anomalies.append({
                    "type": "excessive_reviews",
                    "user_id": user_id,
                    "count": cnt,
                    "avg_rating": avg,
                    "severity": "high" if cnt > 10 else "medium"
                })
            if cnt >= 3 and (avg >= 4.5 or avg <= 1.5):
                anomalies.append({
                    "type": "suspicious_rating_pattern",
                    "user_id": user_id,
                    "count": cnt,
                    "avg_rating": avg,
                    "severity": "high"
                })
        return anomalies

    # ==================== 评分格式化输出 ====================

    def format_rating_display(self, rating_result: Dict) -> str:
        """格式化评分展示"""
        stars = lambda s: "".join(["*" if i < round(s) else "-" for i in range(5)])

        lines = [
            "",
            "=" * 50,
            f"  [B] 基础评分   : {stars(rating_result['basic'])} {rating_result['basic']}/5.0  (权重30%)",
            f"  [C] 社区评分   : {stars(rating_result['community'])} {rating_result['community']}/5.0  (权重50%)",
            f"  [Q] 质量评分   : {stars(rating_result['quality'])} {rating_result['quality']}/5.0  (权重20%)",
            "=" * 50,
            f"  [综合]        : {stars(rating_result['overall'])} {rating_result['overall']}/5.0",
            f"  评分人数: {rating_result['total_reviews']}",
            "=" * 50,
        ]
        return "\n".join(lines)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="龙虾技能评分系统")
    parser.add_argument("--skill-id", type=str, help="技能ID")
    parser.add_argument("--all", action="store_true", help="计算所有技能评分")
    args = parser.parse_args()

    engine = RatingEngine()

    if args.skill_id:
        result = engine.calculate_overall(args.skill_id)
        print(engine.format_rating_display(result))

    elif args.all:
        from clawhub_database import ClawHubDB
        db = ClawHubDB()
        conn = sqlite3.connect(engine.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute("SELECT id, name FROM skills")
        rows = cursor.fetchall()
        conn.close()
        for row in rows:
            result = engine.calculate_overall(row["id"])
            print(f"{row['name']}: overall={result['overall']} (B={result['basic']} C={result['community']} Q={result['quality']})")
    else:
        print("用法: python clawhub_rating.py --skill-id <id> --all")
