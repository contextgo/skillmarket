# Copyright (c) 2026 ZXJ@DEVS. Author: QQ 1817694478 | Q-Group: 972156177
# Skill: dragon-skill-hub | Version: 1.1.0

"""
clawhub_database.py - SQLite数据层
管理技能索引、评分、快照、审计日志、审核队列
"""

import sqlite3
import json
import os
import sys
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
from pathlib import Path

# UTF-8编码兼容处理
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')


class ClawHubDB:
    """技能管家数据库管理器"""

    def __init__(self, db_path: str = None):
        if db_path is None:
            base = Path.home() / ".workbuddy" / "skills" / "dragon-skill-hub" / "data"
            base.mkdir(parents=True, exist_ok=True)
            db_path = str(base / "clawhub.db")
        self.db_path = db_path
        self._ensure_init()

    def _ensure_init(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        self._create_tables(cursor)
        conn.commit()
        conn.close()

    def _create_tables(self, cursor):
        # 技能索引表
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS skills (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL UNIQUE,
                display_name TEXT NOT NULL,
                version TEXT NOT NULL,
                developer_id TEXT NOT NULL,
                developer_name TEXT,
                description TEXT,
                long_desc TEXT,
                category TEXT,
                tags TEXT,
                platform TEXT,
                repo_url TEXT,
                install_count INTEGER DEFAULT 0,
                rating_basic REAL DEFAULT 3.5,
                rating_community REAL DEFAULT 3.5,
                rating_quality REAL DEFAULT 3.5,
                rating_overall REAL DEFAULT 3.5,
                rating_count INTEGER DEFAULT 0,
                status TEXT DEFAULT 'pending',
                risk_level TEXT DEFAULT 'low',
                last_updated TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                installed_at TEXT,
                local_version TEXT,
                is_favorite INTEGER DEFAULT 0
            )
        """)
        # 评分详情表
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS reviews (
                id TEXT PRIMARY KEY,
                skill_id TEXT NOT NULL,
                user_id TEXT NOT NULL,
                rating INTEGER CHECK(rating >= 1 AND rating <= 5),
                tags TEXT,
                body TEXT,
                helpful_count INTEGER DEFAULT 0,
                developer_reply TEXT,
                is_verified INTEGER DEFAULT 0,
                use_count INTEGER DEFAULT 0,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (skill_id) REFERENCES skills(id)
            )
        """)
        # 备份快照表
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS snapshots (
                id TEXT PRIMARY KEY,
                skill_id TEXT NOT NULL,
                skill_version TEXT NOT NULL,
                file_path TEXT NOT NULL,
                size_bytes INTEGER,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                snapshot_type TEXT DEFAULT 'auto',
                note TEXT,
                FOREIGN KEY (skill_id) REFERENCES skills(id)
            )
        """)
        # 用户偏好表
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS user_prefs (
                key TEXT PRIMARY KEY,
                value TEXT,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        # 审计日志表
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS audit_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                action TEXT NOT NULL,
                skill_id TEXT,
                skill_name TEXT,
                details TEXT,
                result TEXT,
                error_msg TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        # 审核队列表
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS review_queue (
                skill_id TEXT PRIMARY KEY,
                skill_name TEXT,
                submitted_by TEXT,
                submitted_at TEXT DEFAULT CURRENT_TIMESTAMP,
                current_stage TEXT DEFAULT 'submit',
                ai_scan_result TEXT,
                risk_level TEXT,
                status TEXT DEFAULT 'pending',
                reviewer_id TEXT,
                reviewed_at TEXT,
                feedback TEXT
            )
        """)
        # 分析缓存表
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS analysis_cache (
                skill_id TEXT PRIMARY KEY,
                analysis_json TEXT,
                computed_at TEXT DEFAULT CURRENT_TIMESTAMP,
                expires_at TEXT
            )
        """)
        # 索引
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_skills_name ON skills(name)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_skills_rating ON skills(rating_overall DESC)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_reviews_skill ON reviews(skill_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_snapshots_skill ON snapshots(skill_id)")

    def add_skill(self, skill_data: Dict[str, Any]) -> bool:
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        try:
            cursor.execute("""
                INSERT OR REPLACE INTO skills (
                    id, name, display_name, version, developer_id, developer_name,
                    description, long_desc, category, tags, platform, repo_url,
                    install_count, rating_basic, rating_community, rating_quality,
                    rating_overall, rating_count, status, risk_level, last_updated
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                skill_data.get("id", skill_data.get("name", "")),
                skill_data.get("name", ""),
                skill_data.get("display_name", ""),
                skill_data.get("version", "1.0.0"),
                skill_data.get("developer_id", ""),
                skill_data.get("developer_name", ""),
                skill_data.get("description", ""),
                skill_data.get("long_desc", ""),
                json.dumps(skill_data.get("category", [])),
                json.dumps(skill_data.get("tags", [])),
                json.dumps(skill_data.get("platform", {})),
                skill_data.get("repo_url", ""),
                skill_data.get("install_count", 0),
                skill_data.get("rating_basic", 3.5),
                skill_data.get("rating_community", 3.5),
                skill_data.get("rating_quality", 3.5),
                skill_data.get("rating_overall", 3.5),
                skill_data.get("rating_count", 0),
                skill_data.get("status", "approved"),
                skill_data.get("risk_level", "low"),
                skill_data.get("last_updated", datetime.now().isoformat())
            ))
            conn.commit()
            return True
        except Exception as e:
            self._log_audit("add_skill", None, None, "fail", str(e))
            return False
        finally:
            conn.close()

    def get_skill(self, name: str) -> Optional[Dict]:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM skills WHERE name = ?", (name,))
        row = cursor.fetchone()
        conn.close()
        return dict(row) if row else None

    def get_installed_skills(self) -> List[Dict]:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM skills WHERE installed_at IS NOT NULL ORDER BY installed_at DESC")
        rows = cursor.fetchall()
        conn.close()
        return [dict(row) for row in rows]

    def search_skills(self, keyword: str, limit: int = 20) -> List[Dict]:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        pattern = f"%{keyword}%"
        cursor.execute("""
            SELECT * FROM skills
            WHERE status = 'approved'
            AND (name LIKE ? OR display_name LIKE ? OR description LIKE ? OR tags LIKE ?)
            ORDER BY rating_overall DESC, install_count DESC LIMIT ?
        """, (pattern, pattern, pattern, pattern, limit))
        rows = cursor.fetchall()
        conn.close()
        return [dict(row) for row in rows]

    def update_skill_local(self, name: str, installed_at: str, local_version: str) -> bool:
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("UPDATE skills SET installed_at = ?, local_version = ? WHERE name = ?",
                       (installed_at, local_version, name))
        conn.commit()
        affected = cursor.rowcount
        conn.close()
        return affected > 0

    def mark_skill_uninstalled(self, name: str) -> bool:
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("UPDATE skills SET installed_at = NULL, local_version = NULL WHERE name = ?", (name,))
        conn.commit()
        affected = cursor.rowcount
        conn.close()
        return affected > 0

    def add_review(self, skill_id: str, user_id: str, rating: int,
                   body: str = "", tags: List[str] = None,
                   is_verified: bool = False, use_count: int = 0) -> bool:
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        import uuid
        review_id = str(uuid.uuid4())
        try:
            cursor.execute("""
                INSERT INTO reviews (id, skill_id, user_id, rating, body, tags, is_verified, use_count)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (review_id, skill_id, user_id, rating, body, json.dumps(tags or []),
                  1 if is_verified else 0, use_count))
            cursor.execute("UPDATE skills SET rating_count = rating_count + 1 WHERE id = ?", (skill_id,))
            conn.commit()
            return True
        except Exception as e:
            self._log_audit("add_review", skill_id, None, "fail", str(e))
            return False
        finally:
            conn.close()

    def get_reviews(self, skill_id: str, limit: int = 50) -> List[Dict]:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM reviews WHERE skill_id = ? ORDER BY created_at DESC LIMIT ?",
                       (skill_id, limit))
        rows = cursor.fetchall()
        conn.close()
        return [dict(row) for row in rows]

    def add_snapshot(self, skill_id: str, skill_name: str, skill_version: str,
                     file_path: str, size_bytes: int = 0,
                     snapshot_type: str = "auto", note: str = "") -> Optional[str]:
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        import uuid
        snapshot_id = str(uuid.uuid4())
        try:
            cursor.execute("""
                INSERT INTO snapshots (id, skill_id, skill_version, file_path, size_bytes, snapshot_type, note)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (snapshot_id, skill_id, skill_version, file_path, size_bytes, snapshot_type, note))
            conn.commit()
            return snapshot_id
        except Exception as e:
            self._log_audit("add_snapshot", skill_id, skill_name, "fail", str(e))
            return None
        finally:
            conn.close()

    def get_snapshots(self, skill_id: str) -> List[Dict]:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM snapshots WHERE skill_id = ? ORDER BY created_at DESC", (skill_id,))
        rows = cursor.fetchall()
        conn.close()
        return [dict(row) for row in rows]

    def cleanup_old_snapshots(self, days: int = 30) -> int:
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cutoff = (datetime.now() - timedelta(days=days)).isoformat()
        cursor.execute("DELETE FROM snapshots WHERE created_at < ? AND snapshot_type = 'auto'", (cutoff,))
        deleted = cursor.rowcount
        conn.commit()
        conn.close()
        return deleted

    def submit_for_review(self, skill_id: str, submitted_by: str = "unknown",
                          ai_scan_result: Dict = None) -> bool:
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        try:
            risk_level = "low"
            if ai_scan_result:
                checks = ai_scan_result.get("checks", [])
                fail_count = sum(1 for c in checks if c.get("status") == "FAIL")
                warn_count = sum(1 for c in checks if c.get("status") == "WARN")
                if fail_count > 0:
                    risk_level = "high"
                elif warn_count > 2:
                    risk_level = "medium"
            cursor.execute("""
                INSERT OR REPLACE INTO review_queue
                (skill_id, submitted_by, ai_scan_result, risk_level, status)
                VALUES (?, ?, ?, ?, 'pending')
            """, (skill_id, submitted_by, json.dumps(ai_scan_result or {}), risk_level))
            conn.commit()
            return True
        except Exception:
            return False
        finally:
            conn.close()

    def get_review_status(self, skill_id: str) -> Optional[Dict]:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM review_queue WHERE skill_id = ?", (skill_id,))
        row = cursor.fetchone()
        conn.close()
        return dict(row) if row else None

    def update_review_status(self, skill_id: str, status: str,
                             reviewer_id: str = None, feedback: str = None) -> bool:
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE review_queue SET status = ?, reviewer_id = ?, reviewed_at = ?, feedback = ?
            WHERE skill_id = ?
        """, (status, reviewer_id, datetime.now().isoformat(), feedback, skill_id))
        conn.commit()
        affected = cursor.rowcount
        conn.close()
        return affected > 0

    def _log_audit(self, action: str, skill_id: str, skill_name: str,
                   result: str, error_msg: str = ""):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO audit_log (action, skill_id, skill_name, result, error_msg)
            VALUES (?, ?, ?, ?, ?)
        """, (action, skill_id, skill_name, result, error_msg))
        conn.commit()
        conn.close()

    def get_audit_log(self, skill_id: str = None, limit: int = 100) -> List[Dict]:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        if skill_id:
            cursor.execute("SELECT * FROM audit_log WHERE skill_id = ? ORDER BY created_at DESC LIMIT ?",
                           (skill_id, limit))
        else:
            cursor.execute("SELECT * FROM audit_log ORDER BY created_at DESC LIMIT ?", (limit,))
        rows = cursor.fetchall()
        conn.close()
        return [dict(row) for row in rows]

    def get_stats(self) -> Dict[str, int]:
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM skills")
        total = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM skills WHERE installed_at IS NOT NULL")
        installed = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM review_queue WHERE status = 'pending'")
        pending = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM snapshots")
        snapshots = cursor.fetchone()[0]
        conn.close()
        return {
            "total_skills": total,
            "installed_skills": installed,
            "pending_reviews": pending,
            "total_snapshots": snapshots
        }


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="龙虾技能管家数据库工具")
    parser.add_argument("--init", action="store_true", help="初始化数据库")
    parser.add_argument("--stats", action="store_true", help="显示统计信息")
    parser.add_argument("--list", action="store_true", help="列出已安装技能")
    args = parser.parse_args()

    db = ClawHubDB()

    if args.init:
        print("[OK] 数据库初始化完成")
        print(f"    路径: {db.db_path}")

    if args.stats:
        stats = db.get_stats()
        print(f"[INFO] 数据库统计:")
        for k, v in stats.items():
            print(f"    {k}: {v}")

    if args.list:
        skills = db.get_installed_skills()
        if not skills:
            print("[INFO] 暂无已安装的技能")
        else:
            print(f"[INFO] 已安装技能 ({len(skills)}):")
            for s in skills:
                print(f"  - {s['name']} v{s.get('local_version','?')} (评分:{s['rating_overall']})")

    if not any(vars(args).values()):
        print("[INFO] 数据库工具")
        print("用法: python clawhub_database.py --init --stats --list")
