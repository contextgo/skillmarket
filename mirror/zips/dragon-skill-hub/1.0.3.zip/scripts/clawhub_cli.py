# Copyright (c) 2026 ZXJ@DEVS. Author: QQ 1817694478 | Q-Group: 972156177
# Skill: dragon-skill-hub | Version: 1.2.0

"""
clawhub_cli.py - 龙虾技能管家 CLI 主入口
四大核心对话Flow + 意图路由 + 全命令支持 + 防封禁机制
"""

import os
import sys
import json
import sqlite3
import time
import random
import hashlib
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional

# UTF-8编码兼容
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')

# 导入同目录模块
SCRIPT_DIR = Path(__file__).parent
sys.path.insert(0, str(SCRIPT_DIR))

from clawhub_database import ClawHubDB
from clawhub_rating import RatingEngine
from clawhub_scanner import AIScanner
from clawhub_intent_router import IntentRouter
from clawhub_workflow import AuditWorkflow
from clawhub_snapshot import SnapshotManager
from clawhub_learning import LearningData
from clawhub_feedback import FeedbackCollector


# ============================================================
# 防封禁机制配置
# ============================================================

_API_RATE_LIMIT = {
    "requests_per_minute": 3,   # 每分钟最多3次
    "requests_per_hour": 20,    # 每小时最多20次
    "min_interval": 1.0,       # 最小随机等待（秒）
    "max_interval": 3.0,       # 最大随机等待（秒）
    "cache_ttl": 300,           # 缓存有效期（秒）
}


class ClawHubRateLimiter:
    """ClawHub API 频率限制器（防止被封）"""

    def __init__(self):
        self.config = _API_RATE_LIMIT
        self.home = Path.home()
        self.state_file = self.home / ".workbuddy" / "skills" / "dragon-skill-hub" / "data" / "rate_limit.json"
        self.cache_file = self.home / ".workbuddy" / "skills" / "dragon-skill-hub" / "data" / "search_cache.json"
        self.state_file.parent.mkdir(parents=True, exist_ok=True)
        self.state = self._load_state()
        self.cache = self._load_cache()
        self._check_cooldown()

    def _load_state(self) -> dict:
        if self.state_file.exists():
            try:
                with open(self.state_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception:
                pass
        return {"minute_requests": [], "hour_requests": [], "backoff_until": None, "backoff_count": 0}

    def _save_state(self):
        now = datetime.now()
        cutoff_minute = (now - timedelta(minutes=1)).isoformat()
        cutoff_hour = (now - timedelta(hours=1)).isoformat()

        self.state["minute_requests"] = [t for t in self.state.get("minute_requests", []) if t > cutoff_minute]
        self.state["hour_requests"] = [t for t in self.state.get("hour_requests", []) if t > cutoff_hour]

        with open(self.state_file, 'w', encoding='utf-8') as f:
            json.dump(self.state, f, ensure_ascii=False, indent=2)

    def _load_cache(self) -> dict:
        if self.cache_file.exists():
            try:
                with open(self.cache_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception:
                pass
        return {}

    def _save_cache(self):
        now = datetime.now()
        cutoff = (now - timedelta(seconds=self.config["cache_ttl"])).isoformat()
        self.cache = {k: v for k, v in self.cache.items() if v.get("cached_at", "") > cutoff}
        with open(self.cache_file, 'w', encoding='utf-8') as f:
            json.dump(self.cache, f, ensure_ascii=False, indent=2)

    def _check_cooldown(self):
        backoff_until = self.state.get("backoff_until")
        if backoff_until:
            try:
                backoff_time = datetime.fromisoformat(backoff_until)
                if datetime.now() < backoff_time:
                    remaining = (backoff_time - datetime.now()).total_seconds()
                    print(f"[WARNING] ClawHub API in cooldown: {remaining:.0f}s remaining")
            except Exception:
                pass

    def _make_cache_key(self, keyword: str) -> str:
        return hashlib.md5(keyword.encode()).hexdigest()[:12]

    def can_proceed(self) -> tuple:
        """检查是否可以发起请求，返回 (can_proceed, reason, wait_seconds)"""
        self._save_state()
        now_iso = datetime.now().isoformat()
        now = datetime.now()

        # 检查退避冷却期
        backoff_until = self.state.get("backoff_until")
        if backoff_until:
            try:
                backoff_time = datetime.fromisoformat(backoff_until)
                if now < backoff_time:
                    remaining = (backoff_time - now).total_seconds()
                    return False, "in_backoff", max(0.1, remaining)
            except Exception:
                pass

        # 检查每分钟限制
        minute_count = len(self.state.get("minute_requests", []))
        if minute_count >= self.config["requests_per_minute"]:
            oldest = min(self.state["minute_requests"])
            oldest_dt = datetime.fromisoformat(oldest)
            wait = (oldest_dt + timedelta(minutes=1) - now).total_seconds()
            return False, "minute_limit", max(0.1, wait)

        # 检查每小时限制
        hour_count = len(self.state.get("hour_requests", []))
        if hour_count >= self.config["requests_per_hour"]:
            oldest = min(self.state["hour_requests"])
            oldest_dt = datetime.fromisoformat(oldest)
            wait = (oldest_dt + timedelta(hours=1) - now).total_seconds()
            return False, "hour_limit", max(0.1, wait)

        return True, "ok", 0

    def get_cached(self, keyword: str) -> Optional[str]:
        """获取缓存的搜索结果"""
        key = self._make_cache_key(keyword)
        entry = self.cache.get(key)
        if entry:
            cached_at = datetime.fromisoformat(entry["cached_at"])
            if datetime.now() - cached_at < timedelta(seconds=self.config["cache_ttl"]):
                return entry["result"]
        return None

    def set_cached(self, keyword: str, result: str):
        """缓存搜索结果"""
        key = self._make_cache_key(keyword)
        self.cache[key] = {
            "keyword": keyword,
            "result": result,
            "cached_at": datetime.now().isoformat(),
        }
        self._save_cache()

    def record_request(self):
        """记录一次请求"""
        now_iso = datetime.now().isoformat()
        self.state.setdefault("minute_requests", []).append(now_iso)
        self.state.setdefault("hour_requests", []).append(now_iso)
        self._save_state()

    def record_rate_limit(self):
        """记录遇到限流"""
        backoff_seconds = 30 * (2 ** self.state.get("backoff_count", 0))
        backoff_seconds = min(backoff_seconds, 3600)  # 最多1小时
        self.state["backoff_count"] = self.state.get("backoff_count", 0) + 1
        self.state["backoff_until"] = (datetime.now() + timedelta(seconds=backoff_seconds)).isoformat()
        self._save_state()
        print(f"[WARNING] ClawHub rate limited! Backoff {backoff_seconds}s, count: {self.state['backoff_count']}")

    def record_success(self):
        """请求成功"""
        if self.state.get("backoff_count", 0) > 0:
            self.state["backoff_count"] = 0
            self.state["backoff_until"] = None
            self._save_state()

    def force_wait(self):
        """强制等待（基于随机间隔）"""
        can_proceed, reason, wait = self.can_proceed()
        if can_proceed:
            wait = random.uniform(self.config["min_interval"], self.config["max_interval"])
        if wait > 0:
            print(f"[INFO] Waiting {wait:.1f}s before ClawHub request...")
            time.sleep(wait)

    def get_status(self) -> dict:
        """获取限流状态"""
        self._save_state()
        return {
            "minute_requests": len(self.state.get("minute_requests", [])),
            "hour_requests": len(self.state.get("hour_requests", [])),
            "in_cooldown": self.state.get("backoff_until") is not None,
            "backoff_until": self.state.get("backoff_until"),
            "backoff_count": self.state.get("backoff_count", 0),
            "cache_entries": len(self.cache),
        }


# 全局限流器实例
_rate_limiter = None


def _get_rate_limiter() -> ClawHubRateLimiter:
    global _rate_limiter
    if _rate_limiter is None:
        _rate_limiter = ClawHubRateLimiter()
    return _rate_limiter


class ClawHubCLI:
    """
    龙虾技能管家 CLI
    集成: 数据库/评分/扫描/意图路由/工作流/快照
    """

    VERSION = "1.0.0"
    BANNER = f"""
{'='*56}
  🦞 龙虾技能管家 Dragon Skill Hub v{VERSION}
  技能全生命周期管理专家
{'='*56}
"""

    def __init__(self):
        self.db = ClawHubDB()
        self.rating = RatingEngine()
        self.scanner = AIScanner()
        self.router = IntentRouter()
        self.workflow = AuditWorkflow()
        self.snapshot = SnapshotManager()
        self.learn = LearningData()
        self.feedback = FeedbackCollector()

    # ==================== Flow 1: 发现 → 安装 ====================

    def flow_discover_and_install(self, keyword: str) -> str:
        """Flow 1: 搜索发现 + 安装"""
        skills = self.db.search_skills(keyword, limit=10)

        if not skills:
            # 尝试从ClawHub搜索
            return self._search_clawhub_market(keyword)

        lines = ["", "=" * 56]
        lines.append(f"  🔍 找到 {len(skills)} 个相关技能:")
        lines.append("=" * 56)
        lines.append(f"  {'排名':<4} {'名称':<20} {'评分':<8} {'安装量':<8}")
        lines.append("-" * 56)

        for i, s in enumerate(skills, 1):
            stars = self._make_stars(s.get("rating_overall", 3.5))
            name = s.get("display_name", s.get("name", ""))[:18]
            rating = f"{s.get('rating_overall', 0):.1f}{stars}"
            installs = s.get("install_count", 0)
            lines.append(f"  {i:<4} {name:<20} {rating:<8} {installs:<8}")

        lines.append("-" * 56)
        lines.append("  回复编号或技能名进行安装")
        lines.append("=" * 56)
        return "\n".join(lines)

    def _search_clawhub_market(self, keyword: str) -> str:
        """从ClawHub市场搜索（带防封禁机制）"""
        limiter = _get_rate_limiter()

        # 1. 检查缓存
        cached = limiter.get_cached(keyword)
        if cached:
            return f"\n[INFO] ClawHub市场搜索结果 (缓存):\n{cached[:500]}"

        # 2. 频率检查
        can_proceed, reason, wait = limiter.can_proceed()
        if not can_proceed:
            return f"\n[INFO] ClawHub搜索受限 ({reason})，请稍后再试\n[INFO] 本地未找到匹配「{keyword}」的技能"

        # 3. 强制等待
        limiter.force_wait()

        # 4. 记录请求
        limiter.record_request()

        # 5. 发起请求
        try:
            import subprocess
            result = subprocess.run(
                ["npx", "clawdhub", "search", keyword],
                capture_output=True, text=True, timeout=30,
                shell=True
            )

            if result.returncode == 0 and result.stdout:
                # 成功，缓存结果
                limiter.set_cached(keyword, result.stdout)
                limiter.record_success()
                return f"\n[INFO] ClawHub市场搜索结果:\n{result.stdout[:500]}"
            elif "rate limit" in result.stderr.lower() or "429" in result.stderr:
                # 检测到限流
                limiter.record_rate_limit()
                return f"\n[INFO] ClawHub搜索被限流，已记录"
            else:
                return f"\n[INFO] 未找到匹配「{keyword}」的技能"

        except subprocess.TimeoutExpired:
            return f"\n[INFO] ClawHub搜索超时，请稍后再试"
        except Exception as e:
            return f"\n[INFO] ClawHub搜索出错: {str(e)[:100]}"

    def _make_stars(self, score: float) -> str:
        full = int(score)
        return "*" * full

    # ==================== Flow 2: 分析 → 对比 ====================

    def flow_analyze_installed(self) -> str:
        """Flow 2: 分析已安装技能"""
        skills = self.db.get_installed_skills()

        if not skills:
            return "\n[INFO] 你还没有安装任何技能"

        # 分类分析
        good = []
        warn = []
        bad = []

        for s in skills:
            rating = s.get("rating_overall", 3.5)
            if rating >= 4.0:
                good.append(s)
            elif rating >= 3.0:
                warn.append(s)
            else:
                bad.append(s)

        lines = ["", "=" * 56]
        lines.append(f"  📊 技能分析报告 (共{len(skills)}个已安装)")
        lines.append("=" * 56)

        if good:
            lines.append(f"\n  🟢 表现良好 ({len(good)}个)")
            for s in good:
                lines.append(f"    [OK] {s.get('display_name', s['name'])} "
                           f"v{s.get('local_version','?')} ⭐{s.get('rating_overall', 0):.1f}")

        if warn:
            lines.append(f"\n  🟡 建议观察 ({len(warn)}个)")
            for s in warn:
                lines.append(f"    [!] {s.get('display_name', s['name'])} "
                           f"v{s.get('local_version','?')} ⭐{s.get('rating_overall', 0):.1f}")

        if bad:
            lines.append(f"\n  🔴 建议卸载 ({len(bad)}个)")
            for s in bad:
                lines.append(f"    [X] {s.get('display_name', s['name'])} "
                           f"v{s.get('local_version','?')} ⭐{s.get('rating_overall', 0):.1f}")

        lines.append("")
        lines.append("=" * 56)
        return "\n".join(lines)

    # ==================== Flow 3: 更新 → 备份 → 回滚 ====================

    def flow_update_with_backup(self, skill_name: str = None, all: bool = False) -> str:
        """Flow 3: 更新技能(带备份)"""
        if all:
            skills = self.db.get_installed_skills()
        elif skill_name:
            skills = [self.db.get_skill(skill_name)]
        else:
            return "\n[ERROR] 请指定技能名或使用 --all"

        if not skills or not skills[0]:
            return f"\n[ERROR] 技能 {skill_name} 未找到"

        lines = ["", "=" * 56]
        lines.append("  🔄 技能更新流程")
        lines.append("=" * 56)

        for s in skills:
            if not s:
                continue
            name = s.get("name", skill_name)
            current_v = s.get("local_version", s.get("version", "?"))
            latest_v = s.get("version", current_v)

            lines.append(f"\n  技能: {name}")
            lines.append(f"  当前: v{current_v} → 最新: v{latest_v}")

            # 检查是否有更新
            if current_v == latest_v:
                lines.append("  状态: 已是最新版本")
                continue

            # 更新前备份
            lines.append("  [1/3] 创建备份快照...")
            skill_path = os.path.join(str(Path.home()), ".workbuddy", "skills", name)
            snap = self.snapshot.create_snapshot(skill_path, name, current_v, "auto", "更新前备份")
            if snap:
                lines.append(f"  [OK] 备份完成: {snap['file_path']}")
            else:
                lines.append(f"  [!] 备份失败，继续更新...")

            # 执行更新
            lines.append("  [2/3] 执行更新...")
            # 简化: 标记为已更新
            self.db.update_skill_local(name, "", latest_v)
            lines.append(f"  [OK] 已更新到 v{latest_v}")

        lines.append("\n" + "=" * 56)
        return "\n".join(lines)

    def flow_rollback(self, skill_name: str, version: str = None) -> str:
        """回滚技能"""
        skill = self.db.get_skill(skill_name)
        if not skill:
            return f"\n[ERROR] 技能 {skill_name} 未找到"

        # 获取快照
        snapshots = self.snapshot.list_snapshots(skill_name)
        if not snapshots:
            return f"\n[ERROR] 技能 {skill_name} 无可用的备份快照"

        if version:
            # 指定版本
            target = next((s for s in snapshots if s.get("version") == version), None)
            if not target:
                return f"\n[ERROR] 未找到 v{version} 的快照"
        else:
            # 使用最新快照
            target = snapshots[0]

        lines = ["", "=" * 56]
        lines.append(f"  🔙 回滚技能: {skill_name}")
        lines.append(f"  目标版本: v{target.get('version')}")
        lines.append(f"  快照时间: {target.get('created_at', '')[:19]}")
        lines.append("-" * 56)
        lines.append("  确认要回滚吗? (y/n)")

        # 执行回滚
        skill_path = os.path.join(str(Path.home()), ".workbuddy", "skills", skill_name)
        if self.snapshot.restore_snapshot(target.get("file_path", ""), skill_path):
            self.db.update_skill_local(skill_name, "", target.get("version", "?"))
            lines.append("  [OK] 回滚成功!")
        else:
            lines.append("  [ERROR] 回滚失败")

        lines.append("=" * 56)
        return "\n".join(lines)

    # ==================== Flow 4: 审核发布 ====================

    def flow_submit_audit(self, skill_dir: str) -> str:
        """Flow 4: 提交审核"""
        if not os.path.isdir(skill_dir):
            return f"\n[ERROR] 目录不存在: {skill_dir}"

        skill_name = os.path.basename(skill_dir.rstrip(os.sep))

        lines = ["", "=" * 56]
        lines.append(f"  📋 审核流程 - {skill_name}")
        lines.append("=" * 56)

        # 阶段1: 提交
        lines.append("\n  [1/5] 提交审核...")
        submit_result = self.workflow.submit(skill_dir, skill_name)
        if not submit_result.get("success"):
            lines.append(f"  [ERROR] {submit_result.get('message', '提交失败')}")
            return "\n".join(lines)
        lines.append("  [OK] 提交成功")

        # 阶段2: AI初筛
        lines.append("\n  [2/5] AI初筛...")
        scan_result = self.scanner.scan(skill_dir)
        scan_out = self.scanner.format_scan_report(scan_result)
        lines.append(f"  扫描完成: {scan_result.get('overall')} (风险:{scan_result.get('risk_level')})")

        scan_result_run = self.workflow.run_ai_scan(skill_name, scan_result)
        risk_level = scan_result_run.get("risk_level", "low")
        lines.append(f"  风险等级: {risk_level.upper()}")

        # 阶段3: 风险判定
        lines.append("\n  [3/5] 风险判定...")
        risk_info = scan_result_run.get("risk_info", {})
        lines.append(f"  判定结果: {risk_info.get('label', 'N/A')}")
        lines.append(f"  处置方式: {risk_info.get('action', 'N/A')}")

        # 根据风险等级决定流程
        if risk_level == "low":
            # 自动通过
            lines.append("\n  [4/5] 自动审核...")
            lines.append("  [OK] 审核通过")
            approve_result = self.workflow.approve(skill_name)
            lines.append("\n  [5/5] 发布上线...")
            lines.append("  [OK] 发布成功!")
            lines.append("\n  技能已上架，可在市场中搜索安装")
        elif risk_level == "medium":
            lines.append("\n  [4/5] 人工复核...")
            lines.append("  [OK] 有条件通过，发布时将添加风险提示")
            self.workflow.approve(skill_name)
            lines.append("\n  [5/5] 发布上线...")
            lines.append("  [OK] 发布成功(含风险提示)")
        else:
            lines.append("\n  [4/5] 人工复核...")
            lines.append("  [X] 高风险/拒绝，需修复后重提")
            lines.append("\n  修复建议:")
            for i, rec in enumerate(scan_result.get("recommendations", [])[:3], 1):
                lines.append(f"    {i}. {rec}")

        lines.append("\n" + "=" * 56)
        return "\n".join(lines)

    # ==================== 评分展示 ====================

    def show_rating(self, skill_name: str) -> str:
        """展示技能评分"""
        skill = self.db.get_skill(skill_name)
        if not skill:
            return f"\n[ERROR] 技能 {skill_name} 未找到"

        rating_result = self.rating.calculate_overall(skill.get("id", skill_name))
        return self.rating.format_rating_display(rating_result)

    # ==================== 意图路由入口 ====================

    def handle_intent(self, user_input: str) -> str:
        """处理用户输入(意图路由)"""
        result = self.router.route(user_input)

        if not result["intent"]:
            return result.get("fallback", "无法理解你的输入")

        intent = result["intent"]
        slots = result.get("slots", {})

        if intent == "search_skill":
            keyword = slots.get("keyword") or slots.get("skill_name") or "技能"
            result = self.flow_discover_and_install(keyword)
            self.learn.record_success('local_db', intent, keyword)
            return result

        elif intent == "analyze_skill":
            result = self.flow_analyze_installed()
            self.learn.record_success('intent_router', intent, '分析')
            return result

        elif intent == "list_skill":
            skills = self.db.get_installed_skills()
            if not skills:
                return "\n[INFO] 你还没有安装任何技能"
            lines = ["", "📦 已安装技能:"]
            for s in skills:
                lines.append(f"  - {s.get('display_name', s['name'])} v{s.get('local_version','?')}")
            return "\n".join(lines)

        elif intent == "update_skill":
            scope = slots.get("scope", "")
            skill_name = slots.get("skill_name")
            return self.flow_update_with_backup(skill_name, all=(scope == "all"))

        elif intent == "backup_skill":
            skill_name = slots.get("skill_name")
            if not skill_name:
                return "\n[ERROR] 请指定要备份的技能名"

        elif intent == "rollback_skill":
            version = slots.get("version")
            skill_name = slots.get("skill_name")
            if not skill_name:
                return "\n[ERROR] 请指定要回滚的技能名"
            return self.flow_rollback(skill_name, version)

        elif intent == "submit_skill":
            skill_path = slots.get("skill_path") or slots.get("skill_name")
            if not skill_path:
                return "\n[ERROR] 请提供技能目录路径"

        elif intent == "rate_skill":
            skill_name = slots.get("skill_name")
            if skill_name:
                return self.show_rating(skill_name)
            return "\n[ERROR] 请指定技能名"

        elif intent == "check_update":
            skills = self.db.get_installed_skills()
            outdated = [s for s in skills if s.get("local_version") != s.get("version")]
            if not outdated:
                return "\n[OK] 所有技能已是最新的"
            lines = ["", f"🔄 发现 {len(outdated)} 个可更新技能:"]
            for s in outdated:
                lines.append(f"  - {s.get('name')} v{s.get('local_version')} → v{s.get('version')}")
            return "\n".join(lines)

        else:
            return f"\n[INFO] 意图 {result['label']} 功能开发中..."

        return f"\n[OK] 已识别: {result['label']}"

    # ==================== CLI主循环 ====================

    def run(self):
        """CLI主循环"""
        print(self.BANNER)

        print("  输入命令或描述你的需求")
        print("  示例:")
        print("    - 找个能抓取小红书的技能")
        print("    - 分析下我装的这些技能")
        print("    - 帮我上架这个技能")
        print("    - 检查哪些技能需要更新")
        print("")
        print("  输入 q 退出")
        print("=" * 56)

        while True:
            try:
                user_input = input("\n> ").strip()
            except (EOFError, KeyboardInterrupt):
                print("\n\n[INFO] 再见!")
                break

            if not user_input:
                continue

            if user_input.lower() in ["q", "quit", "exit"]:
                print("[INFO] 再见!")
                break

            try:
                result = self.handle_intent(user_input)
                print(result)
            except Exception as e:
                print(f"\n[ERROR] 处理出错: {str(e)}")

    def print_help(self):
        """打印帮助"""
        help_text = """
🦞 龙虾技能管家 CLI 帮助

命令格式:
  search <关键词>          搜索技能
  install <技能名>         安装技能
  list                     列出已安装技能
  analyze                  分析已安装技能
  check-updates            检查更新
  update [--all]           更新技能
  backup <技能名>          备份技能
  rollback <技能名> [版本]  回滚技能
  rating <技能名>          查看评分
  submit <目录>            提交审核
  scan <目录>              安全扫描
  db --init                初始化数据库
  learn report             学习状态报告
  learn health             自我反省审计
  learn feedback           反馈汇总
  feedback RATING [评论] [标签]  快速反馈
  help                     显示帮助

自然语言:
  直接描述你的需求，如:
    "帮我找个爬虫技能"
    "分析下我装的所有技能"
    "更新前做个备份"
    "上架这个技能"

🌹 联系作者QQ：1817694478🐧Q群：972156177
"""
        print(help_text)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="龙虾技能管家 CLI", add_help=False)
    parser.add_argument("command", nargs="?", help="命令")
    parser.add_argument("args", nargs="*", help="参数")
    parser.add_argument("--all", action="store_true", help="全部")
    parser.add_argument("--version", "-v", action="version", version="1.0.0")
    args = parser.parse_args()

    cli = ClawHubCLI()

    if not args.command or args.command == "help":
        cli.print_help()
    elif args.command == "search":
        keyword = " ".join(args.args) if args.args else "技能"
        print(cli.flow_discover_and_install(keyword))
    elif args.command == "analyze":
        print(cli.flow_analyze_installed())
    elif args.command == "check-updates":
        skills = cli.db.get_installed_skills()
        outdated = [s for s in skills if s.get("local_version") != s.get("version")]
        if not outdated:
            print("\n[OK] 所有技能已是最新的")
        else:
            print(f"\n[INFO] 发现 {len(outdated)} 个可更新:")
            for s in outdated:
                print(f"  - {s['name']} v{s.get('local_version')} -> v{s.get('version')}")
    elif args.command == "update":
        skill_name = args.args[0] if args.args else None
        print(cli.flow_update_with_backup(skill_name, all=args.all))
    elif args.command == "submit":
        if not args.args:
            print("[ERROR] 请提供技能目录路径")
        else:
            print(cli.flow_submit_audit(args.args[0]))
    elif args.command == "scan":
        if not args.args:
            print("[ERROR] 请提供技能目录路径")
        else:
            result = cli.scanner.scan(args.args[0])
            print(cli.scanner.format_scan_report(result))
    elif args.command == "rating":
        if not args.args:
            print("[ERROR] 请提供技能名")
        else:
            print(cli.show_rating(args.args[0]))
    elif args.command == "db":
        if "init" in args.args or "--init" in args.args:
            cli.db._ensure_init()
            print("[OK] 数据库初始化完成")
        else:
            print("[INFO] db 命令: db init (初始化数据库)")
    elif args.command == "interact":
        cli.run()
    elif args.command == "learn":
        sub = args.args[0] if args.args else "help"
        if sub == "report":
            sys.stdout.buffer.write((cli.learn.get_report() + "\n").encode("utf-8", errors="replace"))
        elif sub == "health":
            sys.stdout.buffer.write((cli.learn.format_health() + "\n").encode("utf-8", errors="replace"))
        elif sub == "feedback":
            sys.stdout.buffer.write((cli.feedback.get_summary() + "\n").encode("utf-8", errors="replace"))
        elif sub == "help":
            sys.stdout.buffer.write(("learn 子命令:\n  report   - 学习状态报告\n  health   - 自我反省审计\n  feedback - 反馈汇总\n  quick RATING [COMMENT] [TAGS] - 快速反馈\n").encode("utf-8", errors="replace"))
        else:
            sys.stdout.buffer.write(f"[INFO] 未知子命令: {sub}\n".encode("utf-8", errors="replace"))
    elif args.command == "feedback":
        if len(args.args) >= 1:
            rating = int(args.args[0])
            comment = args.args[1] if len(args.args) > 1 else ""
            tags = args.args[2].split(',') if len(args.args) > 2 else []
            result = cli.feedback.quick_feedback(rating, comment, tags)
            if result['success']:
                sys.stdout.buffer.write(f"[OK] 反馈已记录 | 平均星级: {result['avg_rating']:.1f} | 总计: {result['total']}条\n".encode("utf-8", errors="replace"))
        else:
            sys.stdout.buffer.write("[INFO] 用法: feedback RATING [COMMENT] [TAGS]\n".encode("utf-8", errors="replace"))
    elif args.command == "rate-limit":
        limiter = _get_rate_limiter()
        status = limiter.get_status()
        print("\n[ClawHub API Rate Limit Status]")
        print(f"  Requests per minute: {status['minute_requests']}/3")
        print(f"  Requests per hour: {status['hour_requests']}/20")
        print(f"  In cooldown: {status['in_cooldown']}")
        if status['backoff_until']:
            print(f"  Backoff until: {status['backoff_until']}")
        print(f"  Backoff count: {status['backoff_count']}")
        print(f"  Cache entries: {status['cache_entries']}")
        print()
    elif args.command == "clear-cache":
        limiter = _get_rate_limiter()
        limiter.cache = {}
        limiter.state = {"minute_requests": [], "hour_requests": [], "backoff_until": None, "backoff_count": 0}
        if limiter.cache_file.exists():
            limiter.cache_file.unlink()
        if limiter.state_file.exists():
            limiter.state_file.unlink()
        print("[OK] Cache and rate limit state cleared")
    else:
        # 自然语言模式
        result = cli.handle_intent(args.command + " " + " ".join(args.args))
        print(result)
