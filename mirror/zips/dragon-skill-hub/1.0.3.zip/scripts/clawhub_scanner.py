# Copyright (c) 2026 ZXJ@DEVS. Author: QQ 1817694478 | Q-Group: 972156177
# Skill: dragon-skill-hub | Version: 1.1.0

"""
clawhub_scanner.py - AI初筛安全审核引擎
P0(致命)/P1(警告)/P2(提示) 三级安全扫描
支持: 文件完整性/SHA256校验/凭证扫描/依赖安全/路径兼容/权限边界/Manifest规范/SemVer格式
"""

import os
import re
import json
import hashlib
import sqlite3
import sys
from pathlib import Path
from typing import Dict, List, Any, Optional
from datetime import datetime

# UTF-8编码兼容
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')


class AIScanner:
    """
    自动化代码安全与质量扫描
    7大扫描维度 + 3级严重性
    """

    # 危险模式配置
    DANGEROUS_PATTERNS = [
        # P0: 致命问题
        (r"api[_\-]?key\s*=\s*['\"][a-zA-Z0-9_\-]{20,}['\"]", "P0", "hardcoded_api_key",
         "发现硬编码API Key，可能导致密钥泄露"),
        (r"password\s*=\s*['\"][^'\"]{8,}['\"]", "P0", "hardcoded_password",
         "发现硬编码密码，安全性风险"),
        (r"Bearer\s+[a-zA-Z0-9_\-]+\.[a-zA-Z0-9_\-]+\.[a-zA-Z0-9_\-]+", "P0", "hardcoded_jwt",
         "发现JWT Token硬编码"),
        (r"exec\s*\(", "P0", "exec_usage",
         "发现exec()调用，存在代码注入风险"),
        (r"eval\s*\(", "P0", "eval_usage",
         "发现eval()调用，存在代码注入风险"),
        (r"os\.system\s*\(", "P0", "os_system",
         "发现os.system()调用，存在命令注入风险"),
        (r"subprocess\.call\s*\([^)]*shell\s*=\s*True", "P0", "subprocess_shell",
         "发现shell=True的subprocess调用，命令注入风险"),
        # P1: 警告问题
        (r"os\.environ\[[\'\"]?(OPENAI|API_KEY|SECRET|PASSWORD|TOKEN)", "P1", "env_secret_access",
         "访问敏感环境变量"),
        (r"requests?\s*\(\s*['\"]https?://", "P1", "http_request",
         "发起HTTP请求，注意数据安全"),
        (r"shutil\.rmtree\s*\(", "P1", "recursive_delete",
         "发现递归删除操作，可能导致误删"),
        (r"open\s*\([^)]*['\"]w['\"]", "P1", "file_write",
         "直接文件写入操作"),
        (r"\.\.\/|\.\.\\\\", "P1", "path_traversal",
         "发现路径遍历模式(..)，需确认无恶意利用"),
        (r"socket\s*\.", "P1", "socket_usage",
         "使用socket网络通信"),
        # P2: 提示问题
        (r"print\s*\(", "P2", "debug_print",
         "存在print调试语句，建议生产环境移除"),
        (r"#\s*TODO|#\s*FIXME|#\s*XXX", "P2", "code_comment",
         "存在TODO/FIXME注释"),
        (r"time\.sleep\s*\(", "P2", "sleep_usage",
         "存在sleep阻塞，可能影响性能"),
        (r"global\s+\w+", "P2", "global_variable",
         "使用全局变量，建议使用类封装"),
    ]

    # 白名单文件(不扫描)
    SKIP_PATTERNS = [
        r"__pycache__", r"\.git", r"\.clawdhub", r"node_modules",
        r"\.pyc$", r"\.pyo$", r"\.ico$", r"\.png$", r"\.jpg$",
        r"\.lock$", r"\.log$"
    ]

    def __init__(self):
        pass

    def scan(self, skill_dir: str) -> Dict[str, Any]:
        """
        执行全量扫描，返回结构化结果
        """
        skill_dir = os.path.abspath(skill_dir)
        if not os.path.isdir(skill_dir):
            return {"error": f"目录不存在: {skill_dir}"}

        results = {
            "skill_dir": skill_dir,
            "skill_name": os.path.basename(skill_dir.rstrip(os.sep)),
            "scanned_at": datetime.now().isoformat(),
            "overall": "PASS",
            "checks": [],
            "summary": {"total": 0, "pass": 0, "warn": 0, "fail": 0},
            "score": 100.0,
            "risk_level": "low",
            "recommendations": []
        }

        # 执行各项检查
        check_methods = [
            self._check_file_integrity,
            self._scan_credentials,
            self._scan_dependencies,
            self._check_path_compatibility,
            self._check_permission_bounds,
            self._validate_manifest,
            self._check_version_format,
        ]

        for method in check_methods:
            try:
                check_result = method(skill_dir)
                results["checks"].append(check_result)
                results["summary"]["total"] += 1
                status = check_result.get("status", "WARN")
                severity = check_result.get("severity", "INFO")
                results["summary"][status.lower()] = results["summary"].get(status.lower(), 0) + 1
                # 按严重性扣分
                if severity == "BLOCKER":
                    results["score"] -= 25
                elif severity == "WARNING":
                    results["score"] -= 10
                elif severity == "INFO":
                    results["score"] -= 2  # P2: 轻微提示
            except Exception as e:
                results["checks"].append({
                    "item": method.__name__,
                    "status": "WARN",
                    "detail": f"扫描异常: {str(e)}"
                })
                results["summary"]["total"] += 1
                results["summary"]["warn"] += 1

        results["score"] = max(0, min(100, results["score"]))

        # 风险判定
        fail_count = results["summary"]["fail"]
        warn_count = results["summary"]["warn"]
        if fail_count > 0:
            results["risk_level"] = "high"
            results["overall"] = "FAIL"
        elif warn_count > 2:
            results["risk_level"] = "medium"
            results["overall"] = "WARN"
        else:
            results["risk_level"] = "low"
            results["overall"] = "PASS"

        # 修复建议
        results["recommendations"] = self._generate_recommendations(results["checks"])

        return results

    # ==================== 各维度检查 ====================

    def _check_file_integrity(self, skill_dir: str) -> Dict:
        """文件完整性检查"""
        required_files = ["SKILL.md", "manifest.json"]
        missing = []
        for fname in required_files:
            if not os.path.exists(os.path.join(skill_dir, fname)):
                missing.append(fname)

        if missing:
            return {
                "item": "file_integrity",
                "status": "FAIL",
                "severity": "BLOCKER",
                "detail": f"缺少必需文件: {', '.join(missing)}",
                "files": missing
            }
        return {
            "item": "file_integrity",
            "status": "PASS",
            "detail": f"文件完整性检查通过 ({len(missing)==0} 必需文件存在)"
        }

    def _scan_credentials(self, skill_dir: str) -> Dict:
        """凭证扫描 - 硬编码密钥/密码检测"""
        findings = []
        severity = "PASS"

        for root, dirs, files in os.walk(skill_dir):
            # 跳过白名单目录
            dirs[:] = [d for d in dirs if not any(re.search(p, d) for p in self.SKIP_PATTERNS)]

            for fname in files:
                if any(re.search(p, fname) for p in self.SKIP_PATTERNS):
                    continue
                fpath = os.path.join(root, fname)
                # 跳过 data/ 目录下的 .json/.log/.cache 等数据文件（避免误报）
                rel = os.path.relpath(fpath, skill_dir)
                if rel.startswith("data" + os.sep) and fname.endswith((".json", ".log", ".cache", ".tmp", ".csv")):
                    continue
                try:
                    with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
                        for lineno, line in enumerate(f, 1):
                            # 忽略注释行
                            stripped = line.strip()
                            if stripped.startswith("#") or stripped.startswith("//"):
                                continue
                            # 忽略包含版权/作者信息的行
                            if "Copyright" in line or "Author:" in line or "Q-Group" in line:
                                continue
                            # 忽略危险模式描述行(防止扫描器自扫描)
                            if "DANGEROUS_PATTERNS" in line or "发现exec()" in line or "发现eval()" in line or "发现os.system()" in line:
                                continue
                            # 忽略文档文件(.md)中的模式描述
                            if fname.endswith(".md") and any(k in line for k in ("eval", "exec", "os.system", "api_key", "password", "Bearer")):
                                continue
                            # 忽略Puppeteer的$eval/$$eval方法(浏览器自动化API，不是代码注入)
                            if "$eval" in line or "$$eval" in line or "page.$$eval" in line:
                                continue
                            # 忽略代码质量检查的正则表达式字符串本身
                            if any(k in line for k in ("r'\\beval", "r'\\bexec", "os_system':", "eval_usage':", "exec_usage':", "'os_system',")):
                                continue
                            for pattern, level, code, msg in self.DANGEROUS_PATTERNS:
                                if re.search(pattern, line, re.IGNORECASE):
                                    # 二次验证: 排除误报模式
                                    # 排除: open(write)用于配置/元数据写入
                                    if code == "file_write" and ("json.dump" in line or "meta" in line or "snapshot" in line or "sha256" in line):
                                        continue
                                    # 排除: rmtree用于快照恢复(先清理目标目录再解压)
                                    if code == "recursive_delete" and ("target_dir" in line or "extract" in line):
                                        continue
                                    findings.append({
                                        "file": os.path.relpath(fpath, skill_dir),
                                        "line": lineno,
                                        "code": code,
                                        "level": level,
                                        "message": msg,
                                        "snippet": line.strip()[:80]
                                    })
                                    if level == "P0":
                                        severity = "FAIL"
                                    elif level == "P1" and severity != "FAIL":
                                        severity = "WARN"
                except Exception:
                    pass

        if findings:
            # 分类
            p0 = [f for f in findings if f["level"] == "P0"]
            p1 = [f for f in findings if f["level"] == "P1"]
            p2 = [f for f in findings if f["level"] == "P2"]

            detail_parts = [f"共{len(findings)}处代码模式匹配"]
            if p0:
                detail_parts.append(f"含{len(p0)}个P0致命问题")
            if p1:
                detail_parts.append(f"含{len(p1)}个P1警告")

            # 重新计算severity(只对P0/P1降级P2)
            actual_severity = "BLOCKER" if p0 else ("WARNING" if p1 else "INFO")
            # P2-only 不算FAIL，降级为WARN
            actual_status = "FAIL" if (p0 or p1) else "WARN"

            return {
                "item": "credential_scan",
                "status": actual_status,
                "severity": actual_severity,
                "detail": " | ".join(detail_parts),
                "findings": findings,
                "summary": {"p0": len(p0), "p1": len(p1), "p2": len(p2)}
            }

        return {
            "item": "credential_scan",
            "status": "PASS",
            "detail": "未发现硬编码凭证或危险代码模式"
        }

    def _scan_dependencies(self, skill_dir: str) -> Dict:
        """依赖安全扫描 - 检查requirements.txt"""
        req_path = os.path.join(skill_dir, "requirements.txt")
        if not os.path.exists(req_path):
            return {
                "item": "dependency_security",
                "status": "PASS",
                "detail": "无requirements.txt依赖文件"
            }

        advisories = []
        try:
            with open(req_path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue
                    # 解析依赖
                    match = re.match(r"([a-zA-Z0-9_\-]+)\s*[><=!~]+\s*([0-9\.]+)", line)
                    if match:
                        pkg, version = match.groups()
                        # 已知问题包检测(简化版)
                        known_issues = {
                            "requests": "2.27.1",
                            "urllib3": "1.26.0",
                            "jinja2": "3.0.0",
                            "pillow": "8.1.0"
                        }
                        if pkg.lower() in known_issues:
                            advisories.append({
                                "package": pkg,
                                "current_version": version,
                                "advisory": f"建议更新到 >= {known_issues[pkg.lower()]} 以修复已知问题",
                                "severity": "MEDIUM"
                            })
        except Exception as e:
            return {
                "item": "dependency_security",
                "status": "WARN",
                "detail": f"解析requirements.txt失败: {str(e)}"
            }

        if advisories:
            return {
                "item": "dependency_security",
                "status": "WARN",
                "severity": "WARNING",
                "detail": f"发现 {len(advisories)} 个依赖建议更新",
                "advisories": advisories
            }

        return {
            "item": "dependency_security",
            "status": "PASS",
            "detail": "依赖检查通过，未发现已知漏洞"
        }

    def _check_path_compatibility(self, skill_dir: str) -> Dict:
        """路径兼容性检查"""
        issues = []
        for root, dirs, files in os.walk(skill_dir):
            dirs[:] = [d for d in dirs if not any(re.search(p, d) for p in self.SKIP_PATTERNS)]
            for fname in files:
                if any(re.search(p, fname) for p in self.SKIP_PATTERNS):
                    continue
                fpath = os.path.join(root, fname)
                rel_path = os.path.relpath(fpath, skill_dir)
                # 检查绝对路径使用
                if os.path.isabs(rel_path) or rel_path.startswith("C:\\") or "/home/" in rel_path:
                    issues.append(f"使用绝对路径: {rel_path}")

        if issues:
            return {
                "item": "path_compatibility",
                "status": "WARN",
                "severity": "WARNING",
                "detail": f"发现 {len(issues)} 处可能不兼容的路径写法",
                "issues": issues[:5]
            }

        return {
            "item": "path_compatibility",
            "status": "PASS",
            "detail": "路径兼容性良好，使用相对路径或占位符"
        }

    def _check_permission_bounds(self, skill_dir: str) -> Dict:
        """权限边界检查"""
        manifest_path = os.path.join(skill_dir, "manifest.json")
        if not os.path.exists(manifest_path):
            return {
                "item": "permission_bounds",
                "status": "WARN",
                "severity": "WARNING",
                "detail": "未找到manifest.json，无法验证权限声明"
            }

        try:
            with open(manifest_path, "r", encoding="utf-8") as f:
                manifest = json.load(f)

            permissions = manifest.get("permissions", {})
            declared = permissions.get("required", [])

            # 危险权限检测
            dangerous = ["file_storage", "system_admin", "network_full"]
            dangerous_used = [p for p in declared if p in dangerous]

            if dangerous_used:
                return {
                    "item": "permission_bounds",
                    "status": "WARN",
                    "severity": "WARNING",
                    "detail": f"声明了敏感权限: {', '.join(dangerous_used)}",
                    "permissions": dangerous_used
                }
        except Exception as e:
            return {
                "item": "permission_bounds",
                "status": "WARN",
                "detail": f"无法解析manifest.json: {str(e)}"
            }

        return {
            "item": "permission_bounds",
            "status": "PASS",
            "detail": "权限声明正常"
        }

    def _validate_manifest(self, skill_dir: str) -> Dict:
        """Manifest规范性验证"""
        manifest_path = os.path.join(skill_dir, "manifest.json")
        if not os.path.exists(manifest_path):
            return {
                "item": "manifest_validation",
                "status": "FAIL",
                "severity": "BLOCKER",
                "detail": "manifest.json 不存在"
            }

        required_fields = ["name", "version", "description"]
        try:
            with open(manifest_path, "r", encoding="utf-8") as f:
                manifest = json.load(f)

            missing = [f for f in required_fields if f not in manifest or not manifest[f]]
            if missing:
                return {
                    "item": "manifest_validation",
                    "status": "FAIL",
                    "severity": "BLOCKER",
                    "detail": f"缺少必需字段: {', '.join(missing)}",
                    "missing_fields": missing
                }
        except json.JSONDecodeError as e:
            return {
                "item": "manifest_validation",
                "status": "FAIL",
                "severity": "BLOCKER",
                "detail": f"JSON格式错误: {str(e)}"
            }
        except Exception as e:
            return {
                "item": "manifest_validation",
                "status": "FAIL",
                "severity": "BLOCKER",
                "detail": f"无法读取manifest: {str(e)}"
            }

        return {
            "item": "manifest_validation",
            "status": "PASS",
            "detail": "manifest.json 格式验证通过"
        }

    def _check_version_format(self, skill_dir: str) -> Dict:
        """版本格式检查 - SemVer规范"""
        manifest_path = os.path.join(skill_dir, "manifest.json")
        if not os.path.exists(manifest_path):
            return {
                "item": "version_format",
                "status": "WARN",
                "detail": "无manifest.json，跳过版本检查"
            }

        try:
            with open(manifest_path, "r", encoding="utf-8") as f:
                manifest = json.load(f)

            version = manifest.get("version", "")
            if not version:
                return {
                    "item": "version_format",
                    "status": "WARN",
                    "detail": "version字段为空"
                }

            # SemVer检查: MAJOR.MINOR.PATCH
            if re.match(r'^\d+\.\d+\.\d+$', version):
                return {
                    "item": "version_format",
                    "status": "PASS",
                    "detail": f"版本格式正确 (SemVer): {version}"
                }
            elif re.match(r'^\d+\.\d+$', version):
                return {
                    "item": "version_format",
                    "status": "WARN",
                    "detail": f"版本格式为MAJOR.MINOR，建议使用MAJOR.MINOR.PATCH: {version}"
                }
            else:
                return {
                    "item": "version_format",
                    "status": "WARN",
                    "detail": f"版本格式不符合SemVer规范: {version}"
                }
        except Exception as e:
            return {
                "item": "version_format",
                "status": "WARN",
                "detail": f"版本检查失败: {str(e)}"
            }

    # ==================== 修复建议 ====================

    def _generate_recommendations(self, checks: List[Dict]) -> List[str]:
        """根据检查结果生成修复建议"""
        recs = []
        for check in checks:
            if check.get("status") == "FAIL":
                item = check.get("item", "")
                if item == "file_integrity":
                    recs.append("补充缺失的必需文件 (SKILL.md, manifest.json)")
                elif item == "credential_scan":
                    findings = check.get("findings", [])
                    p0_count = sum(1 for f in findings if f.get("level") == "P0")
                    if p0_count > 0:
                        recs.append(f"修复 {p0_count} 个P0安全问题 (移除硬编码密钥/凭证)")
                elif item == "manifest_validation":
                    recs.append("修正 manifest.json 格式和必需字段")
            elif check.get("status") == "WARN":
                item = check.get("item", "")
                if item == "credential_scan":
                    p1_count = check.get("summary", {}).get("p1", 0)
                    if p1_count > 0:
                        recs.append(f"检查 {p1_count} 处潜在风险代码")
                elif item == "dependency_security":
                    recs.append("更新过低的依赖版本")
                elif item == "version_format":
                    recs.append("使用标准SemVer格式 (X.Y.Z)")
        return recs

    # ==================== CLI 输出 ====================

    def format_scan_report(self, result: Dict) -> str:
        """格式化扫描报告"""
        lines = [
            "",
            "=" * 56,
            f"  AI初筛报告 - {result['skill_name']}",
            "=" * 56,
            f"  扫描时间: {result['scanned_at'][:19]}",
            f"  风险等级: {result['risk_level'].upper()}",
            f"  综合评分: {result['score']:.0f}/100",
            "=" * 56,
            "",
            "  [检查项]              [状态]   [说明]",
            "-" * 56,
        ]

        status_icons = {"PASS": "[OK]", "WARN": "[!]", "FAIL": "[X]"}
        for check in result["checks"]:
            icon = status_icons.get(check.get("status", "WARN"), "[?]")
            item = check.get("item", "").ljust(22)
            status = check.get("status", "?").ljust(7)
            detail = check.get("detail", "")[:30]
            lines.append(f"  {item} {icon} {status} {detail}")

        lines.extend([
            "-" * 56,
            f"  汇总: 通过={result['summary']['pass']} 警告={result['summary']['warn']} 失败={result['summary']['fail']}",
        ])

        if result["recommendations"]:
            lines.append("")
            lines.append("  [修复建议]")
            for i, rec in enumerate(result["recommendations"], 1):
                lines.append(f"    {i}. {rec}")

        lines.append("=" * 56)
        return "\n".join(lines)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="龙虾技能AI安全扫描")
    parser.add_argument("skill_dir", type=str, help="技能目录路径")
    parser.add_argument("--fix", action="store_true", help="生成修复建议")
    args = parser.parse_args()

    scanner = AIScanner()
    result = scanner.scan(args.skill_dir)
    print(scanner.format_scan_report(result))
