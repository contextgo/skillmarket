# Copyright (c) 2026 ZXJ@DEVS. Author: QQ 1817694478 | Q-Group: 972156177
# Skill: dragon-skill-hub | Version: 1.1.0

"""
clawhub_intent_router.py - 意图理解与路由
支持13种意图分类，模糊匹配，置信度评分
"""

import re
import sys
from typing import Dict, List, Any, Optional, Tuple

# UTF-8编码兼容
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')


class IntentRouter:
    """
    意图理解路由器
    12种核心意图 + 模糊匹配 + 置信度评分
    """

    # 意图模式定义
    INTENT_PATTERNS = {
        "search_skill": {
            "patterns": [
                r"找个.*技能",
                r"有没有.*的技能",
                r"搜索.*技能",
                r"推荐.*技能",
                r"哪个技能.*",
                r"想.*用什么技能",
                r"帮我.*找.*技能",
                r"有没有.*能.*的",
            ],
            "slots": ["keyword"],
            "examples": ["帮我找个能抓取小红书的技能", "推荐数据分析相关的技能"]
        },
        "install_skill": {
            "patterns": [
                r"安装.*技能",
                r"帮我装.*",
                r"下载.*技能",
                r"把这个.*装上",
                r"装一个.*",
                r"添加.*技能",
                r"^安装",
                r"装上.*skill",
            ],
            "slots": ["skill_name"],
            "examples": ["帮我安装小红书采集器", "下载一个爬虫技能"]
        },
        "uninstall_skill": {
            "patterns": [
                r"卸载.*技能",
                r"删掉.*技能",
                r"移除.*技能",
                r"不要.*技能了",
                r"删了.*技能",
                r"去掉.*技能",
                r"^卸载",
                r"卸载.*",
            ],
            "slots": ["skill_name"],
            "examples": ["卸载XX技能", "不要这个技能了"]
        },
        "update_skill": {
            "patterns": [
                r"更新.*技能",
                r"升级.*技能",
                r".*新版.*",
                r"技能.*新版本",
                r"把.*更新.*",
            ],
            "slots": ["skill_name", "scope"],
            "examples": ["更新所有技能", "升级小红书采集器到最新版"]
        },
        "backup_skill": {
            "patterns": [
                r"备份.*",
                r"做个快照",
                r"保存.*版本",
                r"更新前.*备份",
                r"先.*备份.*",
            ],
            "slots": ["skill_name"],
            "examples": ["帮我备份一下所有技能", "做个快照"]
        },
        "rollback_skill": {
            "patterns": [
                r"回滚.*",
                r"恢复到.*版本",
                r"用旧版本",
                r"撤销.*更新",
                r"回到.*版本",
            ],
            "slots": ["skill_name", "version"],
            "examples": ["回滚到上一个版本", "恢复到v1.2.0"]
        },
        "analyze_skill": {
            "patterns": [
                r"分析.*技能",
                r"哪个.*更好",
                r".*对比",
                r".*评分",
                r"我的技能.*怎么样",
                r"已安装.*技能.*分析",
                r"检查.*技能.*表现",
                r"扫描这个",
                r"检查一下",
                r"帮我.*看.*skill",
                r"帮我看看.*好不好",
            ],
            "slots": ["scope"],
            "examples": ["分析下我装的这些技能", "对比XX和YY哪个更好"]
        },
        "rate_skill": {
            "patterns": [
                r"给.*评.*分",
                r".*好用.*",
                r".*不好用",
                r".*打.*星",
                r"这个技能.*怎么样",
                r".*评分.*",
            ],
            "slots": ["skill_name", "rating"],
            "examples": ["给小红书采集器打个分", "这个技能好用吗"]
        },
        "submit_skill": {
            "patterns": [
                r"上架.*",
                r"发布.*技能",
                r"提交.*审核",
                r"把这个.*提交.*",
                r"申请.*上架",
                r"^发布",
                r"发布skill",
                r"发布.*skill",
            ],
            "slots": ["skill_name", "skill_path"],
            "examples": ["帮我把这个技能上架", "提交审核"]
        },
        "help_skill": {
            "patterns": [
                r"怎么用.*",
                r".*使用.*帮助",
                r".*教程",
                r".*说明",
                r".*帮助",
            ],
            "slots": ["skill_name"],
            "examples": ["怎么用这个技能", "使用帮助"]
        },
        "list_skill": {
            "patterns": [
                r"我装了.*技能",
                r"列出.*已安装",
                r"看看.*装.*",
                r"有哪些技能",
                r"技能列表",
            ],
            "slots": [],
            "examples": ["我装了哪些技能", "列出所有已安装的技能"]
        },
        "check_update": {
            "patterns": [
                r".*有新版本.*",
                r".*该更新.*",
                r"检查.*更新",
                r"有没有.*更新",
            ],
            "slots": [],
            "examples": ["检查哪些技能需要更新", "有没有可更新的技能"]
        },
        "audit_status": {
            "patterns": [
                r"审核.*到哪",
                r"审核状态",
                r".*审核结果",
                r"上架.*进度",
            ],
            "slots": ["skill_name"],
            "examples": ["我的技能审核到哪了", "审核结果是什么"]
        },
    }

    # 意图中文映射
    INTENT_LABELS = {
        "search_skill": "搜索发现",
        "install_skill": "安装技能",
        "uninstall_skill": "卸载技能",
        "update_skill": "更新技能",
        "backup_skill": "备份快照",
        "rollback_skill": "回滚版本",
        "analyze_skill": "分析对比",
        "rate_skill": "评分反馈",
        "submit_skill": "提交审核",
        "help_skill": "使用帮助",
        "list_skill": "列出技能",
        "check_update": "检查更新",
        "audit_status": "审核状态",
    }

    def __init__(self):
        self._compile_patterns()

    def _compile_patterns(self):
        """预编译所有正则表达式"""
        self._compiled = {}
        for intent, config in self.INTENT_PATTERNS.items():
            self._compiled[intent] = {
                "regexes": [re.compile(p, re.IGNORECASE) for p in config["patterns"]],
                "slots": config["slots"],
                "examples": config["examples"]
            }

    def route(self, user_input: str) -> Dict[str, Any]:
        """
        路由用户输入
        返回: {intent, confidence, slots, fallback}
        """
        user_input = user_input.strip()
        if not user_input:
            return {
                "intent": None,
                "confidence": 0.0,
                "slots": {},
                "fallback": "请告诉我你想做什么？"
            }

        best_intent = None
        best_score = 0.0
        best_slots = {}

        for intent, config in self._compiled.items():
            for regex in config["regexes"]:
                match = regex.search(user_input)
                if match:
                    # 基础分 = 完整匹配1.0 + 部分匹配0.8
                    score = 1.0 if match.group() == user_input else 0.8
                    # 长度惩罚：越长的模式越精确
                    pattern_len = len(match.group())
                    input_len = len(user_input)
                    if pattern_len < input_len * 0.5:
                        score *= 0.7  # 模式只匹配了一小部分

                    if score > best_score:
                        best_score = score
                        best_intent = intent
                        best_slots = self._extract_slots(user_input, match, config["slots"])

        if best_intent and best_score >= 0.5:
            return {
                "intent": best_intent,
                "confidence": round(best_score, 2),
                "slots": best_slots,
                "label": self.INTENT_LABELS.get(best_intent, best_intent),
                "fallback": None
            }

        # 未能明确匹配
        return {
            "intent": None,
            "confidence": best_score,
            "slots": {},
            "fallback": f"没有找到完全匹配的指令，但你可能想：\n"
                        f"  - '搜索XX技能'\n"
                        f"  - '安装XX技能'\n"
                        f"  - '分析已安装技能'\n"
                        f"  - '上架技能'\n"
                        f"请说得更具体一些？"
        }

    def _extract_slots(self, user_input: str, match, slot_types: List[str]) -> Dict[str, str]:
        """从用户输入中提取槽位"""
        slots = {}
        text = user_input

        for slot_type in slot_types:
            if slot_type == "skill_name":
                # 提取技能名称 - 常见的技能名模式
                # "安装XX技能" -> XX
                patterns = [
                    r"安装([^\s]+?)技能",
                    r"装([^\s]+)",
                    r"卸载([^\s]+?)技能",
                    r"更新([^\s]+?)技能",
                    r"回滚([^\s]+)",
                    r"分析([^\s]+?)和([^\s]+)",
                    r"分析下([^\s]+)",
                    r"帮我.*(小红书|[^\s]+采集器|[^\s]+助手|[^\s]+工具)",
                ]
                for p in patterns:
                    m = re.search(p, text)
                    if m:
                        slots["skill_name"] = m.group(1) if m.lastindex == 1 else (m.group(1), m.group(2))
                        break

            elif slot_type == "keyword":
                # 提取关键词
                # "找个能做XX的技能" -> XX
                m = re.search(r"做个?能(.*?)的技能", text)
                if m:
                    slots["keyword"] = m.group(1).strip()
                else:
                    m = re.search(r"推荐(.*?)技能", text)
                    if m:
                        slots["keyword"] = m.group(1).strip()

            elif slot_type == "version":
                # 提取版本号
                m = re.search(r"v?(\d+\.\d+(?:\.\d+)?)", text)
                if m:
                    slots["version"] = m.group(1)
                else:
                    m = re.search(r"恢复到?(.*?版本)", text)
                    if m:
                        slots["version"] = m.group(1).replace("版本", "").strip()

            elif slot_type == "scope":
                # 提取范围
                if "所有" in text or "全部" in text:
                    slots["scope"] = "all"
                elif "这些" in text:
                    slots["scope"] = "installed"

        return slots

    def format_intent_display(self, result: Dict) -> str:
        """格式化意图识别结果"""
        if not result["intent"]:
            return f"  未能识别意图 (置信度: {result.get('confidence',0):.0%})"
        lines = [
            f"  识别意图: {result['label']} (置信度: {result.get('confidence',0):.0%})",
        ]
        if result.get("slots"):
            lines.append("  提取参数:")
            for k, v in result["slots"].items():
                lines.append(f"    - {k}: {v}")
        return "\n".join(lines)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="意图路由测试")
    parser.add_argument("--text", type=str, help="测试文本")
    parser.add_argument("--interactive", action="store_true", help="交互模式")
    args = parser.parse_args()

    router = IntentRouter()

    if args.interactive:
        print("=" * 50)
        print("  意图路由测试 - 输入q退出")
        print("=" * 50)
        while True:
            text = input("\n> ")
            if text.lower() == "q":
                break
            result = router.route(text)
            print(router.format_intent_display(result))

    elif args.text:
        result = router.route(args.text)
        print(router.format_intent_display(result))

    else:
        # 内置测试
        test_cases = [
            "帮我找个能抓取小红书的技能",
            "安装小红书采集器",
            "分析下我装的这些技能",
            "更新所有技能",
            "回滚到v1.2.0",
            "上架这个技能",
            "审核到哪了",
            "检查有没有更新",
        ]
        print("=" * 50)
        print("  意图路由测试")
        print("=" * 50)
        for text in test_cases:
            result = router.route(text)
            print(f"\n输入: {text}")
            print(router.format_intent_display(result))
