# -*- coding: utf-8 -*-
"""
generate_excel.py - 从OCR结果生成Excel文件
用法: python generate_excel.py [--workspace DIR]

每个PDF源生成一个Excel文件，文件名 = 原PDF名_AI整理.xlsx
Excel内部按银行分Sheet，每条记录标注来源页码。
支持通过 overrides.json 配置银行分页纠正和页数限制。
"""
import json, os, sys, io, argparse
from collections import defaultdict
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
from openpyxl.utils import get_column_letter

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

parser = argparse.ArgumentParser(description='Generate Excel from OCR results')
parser.add_argument('--workspace', default=os.getcwd(), help='Workspace directory')
args = parser.parse_args()

WORKSPACE = args.workspace
RES_DIR = os.path.join(WORKSPACE, "batch_v2_results")
OUT_DIR = WORKSPACE
OVERRIDES_FILE = os.path.join(WORKSPACE, "overrides.json")

# ===== 加载覆盖配置 =====
overrides = {"pdf_config": [], "bank_map": {}, "name_map": {},
             "page_bank_override": {}, "pdf_max_page": {}}
if os.path.exists(OVERRIDES_FILE):
    with open(OVERRIDES_FILE, 'r', encoding='utf-8') as f:
        overrides = json.load(f)

PDF_CONFIG = overrides["pdf_config"]
BANK_MAP = overrides.get("bank_map", {})
NAME_MAP = overrides.get("name_map", {})
PAGE_BANK_OVERRIDE = {tuple(k.split("_", 1)): v for k, v in overrides.get("page_bank_override", {}).items()}
PDF_MAX_PAGE = {k: int(v) for k, v in overrides.get("pdf_max_page", {}).items()}

if not PDF_CONFIG:
    for f in sorted(os.listdir(RES_DIR)):
        if f.endswith("_ocr.json"):
            key = f.replace("_ocr.json", "")
            PDF_CONFIG.append({"key": key, "name": key, "owner": ""})

DEFAULT_BANK_MAP = {
    "招商银行": "招商银行", "招商银行股份有限公司": "招商银行",
    "招商银行股份有限公司北京分行": "招商银行", "银行股份有限公司": "招商银行",
    "中国建设银行": "中国建设银行", "建设银行": "中国建设银行",
    "交通银行": "交通银行", "中国工商银行": "中国工商银行",
    "中国银行": "中国银行",
}
DEFAULT_BANK_MAP.update(BANK_MAP)

def norm_bank(raw, pdf_key="", pg=0):
    raw = raw.strip()
    override = PAGE_BANK_OVERRIDE.get((pdf_key, pg))
    if override: return override
    return DEFAULT_BANK_MAP.get(raw, raw) if raw else "其他"

def parse_amount(val):
    if not val: return None
    try: return float(str(val).replace(",", "").replace("+", ""))
    except: return None

title_font = Font(name='微软雅黑', size=14, bold=True, color='2F5496')
header_font = Font(name='微软雅黑', size=10, bold=True, color='FFFFFF')
data_font = Font(name='微软雅黑', size=10)
info_label_font = Font(name='微软雅黑', size=11, bold=True)
info_font = Font(name='微软雅黑', size=11)
header_fill = PatternFill(start_color='2F5496', end_color='2F5496', fill_type='solid')
alt_fill = PatternFill(start_color='D6E4F0', end_color='D6E4F0', fill_type='solid')
thin_border = Border(
    left=Side(style='thin'), right=Side(style='thin'),
    top=Side(style='thin'), bottom=Side(style='thin')
)
center_align = Alignment(horizontal='center', vertical='center', wrap_text=True)
left_align = Alignment(horizontal='left', vertical='center', wrap_text=True)
right_align = Alignment(horizontal='right', vertical='center')
money_fmt = '#,##0.00'

def make_sheet(ws, bank_name, records, pdf_label, owner_name):
    all_keys = set()
    for r in records: all_keys.update(r["record"].keys())
    priority = ["序号", "日期", "时间", "记账时间", "摘要", "交易类型", "币种",
                "收入", "支出", "金额", "余额", "交易渠道", "渠道", "网点名称",
                "附言", "对方户名", "对方账户名称", "对方账号", "对方账号/卡号", "对方开户行"]
    ordered_keys = []
    for k in priority:
        if k in all_keys: ordered_keys.append(k); all_keys.discard(k)
    ordered_keys.extend(sorted(all_keys))
    ordered_keys.append("来源页码")
    ncol = len(ordered_keys)
    lc = get_column_letter(ncol)

    ws.merge_cells(f'A1:{lc}1')
    ws['A1'] = f"{owner_name} - {bank_name} 流水明细" if owner_name else f"{bank_name} 流水明细"
    ws['A1'].font = title_font
    ws['A1'].alignment = Alignment(horizontal='center', vertical='center')
    ws.row_dimensions[1].height = 35

    ws.merge_cells(f'A2:{lc}2')
    ws['A2'] = f"来源：{pdf_label}  |  共 {len(records)} 条记录"
    ws['A2'].font = Font(name='微软雅黑', size=10, color='666666')
    ws['A2'].alignment = Alignment(horizontal='center', vertical='center')
    ws.row_dimensions[2].height = 22

    hr = 4
    for ci, h in enumerate(ordered_keys, start=1):
        c = ws.cell(row=hr, column=ci, value=h)
        c.font = header_font; c.fill = header_fill; c.alignment = center_align; c.border = thin_border
    ws.row_dimensions[hr].height = 28

    ti = te = 0.0; ic = ec = 0
    for idx, item in enumerate(records):
        row = hr + 1 + idx
        rec = item["record"]
        for ci, key in enumerate(ordered_keys, start=1):
            if key == "来源页码":
                cell = ws.cell(row=row, column=ci, value=f"第{item['pdf_page']}页")
                cell.alignment = center_align
            else:
                val = rec.get(key, "")
                cell = ws.cell(row=row, column=ci, value=val if val != "" else None)
                if key in ("收入", "支出", "余额", "金额") and val:
                    num = parse_amount(val)
                    if num is not None:
                        cell.value = abs(num); cell.number_format = money_fmt; cell.alignment = right_align
                        if key == "收入" and num > 0: ti += num; ic += 1
                        elif key == "支出": te += abs(num); ec += 1
                    else: cell.alignment = left_align
                elif key in ("序号", "日期", "时间", "记账时间", "币种"): cell.alignment = center_align
                else: cell.alignment = left_align
            cell.font = data_font; cell.border = thin_border
            if idx % 2 == 1: cell.fill = alt_fill

    cw = []
    for key in ordered_keys:
        if key in ("序号", "币种"): cw.append(6)
        elif key in ("日期", "时间", "记账时间"): cw.append(12)
        elif key in ("收入", "支出", "余额", "金额"): cw.append(14)
        elif key in ("对方户名", "对方账户名称", "网点名称", "对方开户行"): cw.append(26)
        elif key == "来源页码": cw.append(10)
        else: cw.append(18)
    for i, w in enumerate(cw, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w

    ws.freeze_panes = f'A{hr+1}'
    ws.auto_filter.ref = f"A{hr}:{lc}{hr+len(records)}"

    sr = hr + len(records) + 2
    ws.cell(row=sr, column=1, value="统计汇总").font = Font(name='微软雅黑', size=11, bold=True)
    sr += 1
    for lab, val, ism in [("总交易笔数", len(records), False), ("收入笔数", ic, False),
                           ("支出笔数", ec, False), ("收入合计", ti, True),
                           ("支出合计", te, True), ("净流入", ti-te, True)]:
        ws.cell(row=sr, column=1, value=lab).font = info_label_font
        ws.cell(row=sr, column=1).border = thin_border
        c = ws.cell(row=sr, column=2, value=val)
        c.font = info_font; c.border = thin_border
        if ism: c.number_format = money_fmt
        sr += 1
    return len(records), ti, te


print("=" * 60, flush=True)
print("Generate Excel from OCR results", flush=True)
print("=" * 60, flush=True)

grand_rec = 0; grand_inc = 0; grand_exp = 0

for cfg in PDF_CONFIG:
    pdf_key = cfg["key"]
    pdf_name = cfg["name"]
    owner = cfg.get("owner", "")
    jf = os.path.join(RES_DIR, f"{pdf_key}_ocr.json")
    if not os.path.exists(jf):
        print(f"\n[{pdf_key}] SKIP - no OCR result", flush=True)
        continue
    with open(jf, 'r', encoding='utf-8') as f:
        data = json.load(f)
    print(f"\n[{pdf_key}] {pdf_name} ({owner}) - {len(data)} pages", flush=True)

    max_pg = PDF_MAX_PAGE.get(pdf_key, 9999)
    if max_pg < 9999:
        data = [p for p in data if p.get("pdf_page", 0) <= max_pg]
        print(f"  limit to first {max_pg} pages => {len(data)} pages", flush=True)

    bank_groups = defaultdict(list)
    prev_name = owner or ""
    for page in data:
        if page.get("type") != "transactions": continue
        pg = page.get("pdf_page", 0)
        bank = norm_bank(page.get("bank", ""), pdf_key, pg)
        # 户名继承与归一化：如果本页有户名则更新，否则沿用前一页户名
        page_name = page.get("name", "").strip()
        if page_name:
            prev_name = NAME_MAP.get(page_name, page_name) if page_name in NAME_MAP else page_name
        elif not prev_name and owner:
            prev_name = owner
        for rec in page.get("records", []):
            bank_groups[bank].append({"pdf_page": pg, "record": rec, "page_owner": prev_name})

    sorted_banks = sorted(bank_groups.keys())
    wb = Workbook()
    first = True
    file_rec = 0; file_inc = 0; file_exp = 0

    for bank in sorted_banks:
        records = bank_groups[bank]
        pages = sorted(set(r["pdf_page"] for r in records))
        # 收集本银行下所有页面的户名
        owners = sorted(set(r["page_owner"] for r in records if r.get("page_owner")))
        owner_display = "、".join(owners) if owners else (owner or "")
        print(f"  {bank}: {len(records)} recs (pages {pages[0]}-{pages[-1]}) owners: {owner_display}", flush=True)
        if first:
            ws = wb.active; ws.title = bank[:31]; first = False
        else:
            ws = wb.create_sheet(bank[:31])
        rec_cnt, ti, te = make_sheet(ws, bank, records, pdf_name, owner_display)
        file_rec += rec_cnt; file_inc += ti; file_exp += te

    out_name = f"{pdf_name}_AI整理.xlsx"
    out_path = os.path.join(OUT_DIR, out_name)
    wb.save(out_path)
    print(f"  => {out_name} ({file_rec} recs, income {file_inc:,.2f}, expense {file_exp:,.2f})", flush=True)
    grand_rec += file_rec; grand_inc += file_inc; grand_exp += file_exp

print(f"\n{'='*60}", flush=True)
print(f"Done! {len(PDF_CONFIG)} files, total {grand_rec} recs", flush=True)
