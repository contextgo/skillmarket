# -*- coding: utf-8 -*-
"""
batch_worker.py - 银行流水OCR并行处理Worker
用法:
  # 自动并行模式（推荐）：自动将页码分配给多个worker
  python batch_worker.py <label> <start_page> <end_page> [--workers N]

  # 单worker模式（兼容旧用法）：手动指定页码
  python batch_worker.py <worker_id> <label> <page1> [page2] [page3] ...

使用前需设置环境变量或在脚本中配置:
  - OCR_API_URL: API端点 (默认读取 OPENAI_BASE_URL 或 https://api.openai.com/v1/chat/completions)
  - OCR_API_KEY: API密钥 (默认读取 OPENAI_API_KEY)
  - OCR_MODEL: 模型名称 (默认 gpt-4o)
  - WORKSPACE: 工作目录 (默认当前目录)
  - OCR_PROMPT: 自定义OCR提示词 (可选)
  - OCR_WORKERS: 并行worker数 (默认 3，也可通过 --workers 参数指定)
"""
import os, json, base64, requests, time, sys, re, argparse, threading
from PIL import Image
from concurrent.futures import ThreadPoolExecutor, as_completed

# ===== 全局配置 =====
API_URL = os.environ.get("OCR_API_URL", "") or os.environ.get("OPENAI_BASE_URL", "https://api.openai.com/v1/chat/completions")
if not API_URL.endswith("/chat/completions"):
    API_URL = API_URL.rstrip("/") + "/chat/completions"
API_KEY = os.environ.get("OCR_API_KEY", "") or os.environ.get("OPENAI_API_KEY", "")
MODEL = os.environ.get("OCR_MODEL", "gpt-4o")
WORKSPACE = os.environ.get("WORKSPACE", os.getcwd())

DEFAULT_PROMPT = """请仔细识别这张图片的全部内容，严格按JSON输出：
如果本页包含银行流水，输出bank、name、account字段。看不到则留空字符串""。
type规则："transactions"=交易明细页, "info"=封面/信息页, "footer"=尾部页, "other"=非流水文件。
模板：{"type":"transactions","bank":"","name":"","account":"","records":[{"日期":"","摘要":"","收入":"","支出":"","余额":"","对方户名":"","对方账号":""}]}
注意：金额保留原文格式，不遗漏记录，只输出纯JSON。"""
PROMPT = os.environ.get("OCR_PROMPT", DEFAULT_PROMPT)


def wlog(msg, wid=""):
    now = time.strftime("%H:%M:%S")
    prefix = "[%s]" % now + (" [%s]" % wid if wid else "")
    line = "%s %s\n" % (prefix, msg)
    sys.stdout.write(line)
    sys.stdout.flush()


def compress(path):
    img = Image.open(path)
    if img.mode in ("RGBA", "P"):
        img = img.convert("RGB")
    iw, ih = img.size
    if max(iw, ih) > 1200:
        ratio = 1200 / max(iw, ih)
        img = img.resize((int(iw * ratio), int(ih * ratio)), Image.LANCZOS)
    buf = __import__("io").BytesIO()
    img.save(buf, format="JPEG", quality=82)
    return base64.b64encode(buf.getvalue()).decode()


def do_api(img_b64, prompt_text):
    hdrs = {"Content-Type": "application/json", "Authorization": "Bearer " + API_KEY}
    payload = {
        "model": MODEL,
        "messages": [{"role": "user", "content": [
            {"type": "image_url", "image_url": {"url": "data:image/jpeg;base64," + img_b64}},
            {"type": "text", "text": prompt_text}
        ]}],
        "max_tokens": 8192, "temperature": 0
    }
    t0 = time.time()
    resp = requests.post(API_URL, headers=hdrs, json=payload, timeout=120)
    elapsed = time.time() - t0
    resp.raise_for_status()
    content = resp.json()["choices"][0]["message"]["content"].strip()
    if content.startswith("```"):
        lines = content.split("\n")
        content = "\n".join(lines[1:])
        if content.endswith("```"):
            content = content[:-3]
        content = content.strip()
    return content, elapsed


def try_parse(text):
    if not text:
        return None
    try:
        return json.loads(text)
    except Exception:
        m = re.search(r"\{[\s\S]*\}", text)
        if m:
            try:
                return json.loads(m.group())
            except Exception:
                pass
    return None


def process_one_page(pnum, label, wid="", res_dir="", base_dir=""):
    """处理单个页面，返回解析后的dict"""
    img_path = os.path.join(base_dir, label, "page_%03d.png" % pnum)
    rf = os.path.join(res_dir, "%s_ocr.json" % label)

    # 加载已有数据获取继承信息（只读本页之前的数据）
    prev_bank = prev_name = prev_account = ""
    if os.path.exists(rf):
        try:
            with open(rf, "r", encoding="utf-8") as f:
                existing = json.load(f)
            for p in existing:
                if p.get("pdf_page", 0) < pnum:
                    if p.get("bank", "").strip():
                        prev_bank = p["bank"].strip()
                    if p.get("name", "").strip():
                        prev_name = p["name"].strip()
                    if p.get("account", "").strip():
                        prev_account = p["account"].strip()
        except Exception:
            pass

    wlog("W%s P%d processing..." % (wid, pnum), wid)

    try:
        b64 = compress(img_path)
        wlog("W%s P%d compressed %d chars" % (wid, pnum, len(b64)), wid)
        txt, el = do_api(b64, PROMPT)
        parsed = try_parse(txt)

        if parsed:
            parsed["bank"] = parsed.get("bank", "").strip() or prev_bank
            parsed["name"] = parsed.get("name", "").strip() or prev_name
            parsed["account"] = parsed.get("account", "").strip() or prev_account
            parsed["pdf_page"] = pnum
            nr = len(parsed.get("records", []))
            bk = parsed["bank"][:12] if parsed["bank"] else "(inherit)"
            wlog("W%s P%d OK %s | %s | %s | %drec | %ds" % (wid, pnum, parsed.get("type", "?"), bk, parsed["name"], nr, int(el)), wid)
        else:
            parsed = {"pdf_page": pnum, "type": "error", "bank": prev_bank, "name": prev_name, "account": prev_account}
            wlog("W%s P%d PARSE_ERR | %ds" % (wid, pnum, int(el)), wid)
    except Exception as e:
        parsed = {"pdf_page": pnum, "type": "error", "bank": prev_bank, "name": prev_name, "account": prev_account}
        wlog("W%s P%d ERR: %s" % (wid, pnum, str(e)[:80]), wid)

    # 保存到结果文件（加锁写入，防止并发冲突）
    with process_one_page._write_lock:
        if os.path.exists(rf):
            try:
                with open(rf, "r", encoding="utf-8") as f:
                    existing = json.load(f)
            except Exception:
                existing = []
            existing = [p for p in existing if p.get("pdf_page", 0) != pnum]
        else:
            existing = []
        existing.append(parsed)
        existing.sort(key=lambda x: x.get("pdf_page", 0))
        with open(rf, "w", encoding="utf-8") as f:
            json.dump(existing, f, ensure_ascii=False, indent=2)

    return parsed


def run_parallel(label, start_page, end_page, num_workers):
    """并行调度模式：将页码分配给多个worker并行处理"""
    res_dir = os.path.join(WORKSPACE, "batch_v2_results")
    base_dir = os.path.join(WORKSPACE, "batch_v2")

    all_pages = list(range(start_page, end_page + 1))
    total = len(all_pages)

    # 将页码分配给workers（交错分配，确保负载均衡）
    chunks = [[] for _ in range(num_workers)]
    for i, pg in enumerate(all_pages):
        chunks[i % num_workers].append(pg)

    wlog("PARALLEL MODE: %d pages, %d workers" % (total, num_workers))
    wlog("API=%s MODEL=%s" % (API_URL, MODEL))
    for i, chunk in enumerate(chunks):
        if chunk:
            wlog("  Worker %d: pages %s" % (i + 1, chunk))

    # 初始化线程锁
    process_one_page._write_lock = threading.Lock()

    # 提交所有任务到线程池
    t_start = time.time()
    done_count = 0
    error_count = 0

    with ThreadPoolExecutor(max_workers=num_workers) as executor:
        futures = {}
        for wid, chunk in enumerate(chunks):
            for pnum in chunk:
                future = executor.submit(process_one_page, pnum, label, str(wid + 1), res_dir, base_dir)
                futures[future] = (wid + 1, pnum)

        for future in as_completed(futures):
            wid, pnum = futures[future]
            try:
                result = future.result()
                done_count += 1
                if result.get("type") == "error":
                    error_count += 1
            except Exception as e:
                done_count += 1
                error_count += 1
                wlog("W%s P%d FUTURE_ERR: %s" % (wid, pnum, str(e)[:80]))

            # 进度报告
            elapsed = time.time() - t_start
            avg = elapsed / done_count if done_count else 0
            remaining = avg * (total - done_count)
            wlog("Progress: %d/%d (%.0f%%) | errors: %d | elapsed: %.0fs | ETA: %.0fs" % (
                done_count, total, done_count / total * 100, error_count, elapsed, remaining))

    total_elapsed = time.time() - t_start
    wlog("DONE %d pages in %.0fs (%.1f pages/sec) | %d errors" % (
        total, total_elapsed, total / total_elapsed if total_elapsed > 0 else 0, error_count))

    return error_count == 0


def run_single(label, page_nums, worker_id="W1"):
    """单worker顺序处理模式（兼容旧用法）"""
    res_dir = os.path.join(WORKSPACE, "batch_v2_results")
    base_dir = os.path.join(WORKSPACE, "batch_v2")

    wlog("SINGLE MODE: %s pages=%s" % (worker_id, page_nums))
    wlog("API=%s MODEL=%s" % (API_URL, MODEL))

    # 初始化线程锁（单线程也需要，因为函数里用了）
    process_one_page._write_lock = threading.Lock()

    t_start = time.time()
    error_count = 0

    for idx, pnum in enumerate(page_nums):
        result = process_one_page(pnum, label, wid=worker_id, res_dir=res_dir, base_dir=base_dir)
        if result.get("type") == "error":
            error_count += 1

    elapsed = time.time() - t_start
    wlog("DONE %d pages in %.0fs | %d errors" % (len(page_nums), elapsed, error_count))

    return error_count == 0


def main():
    parser = argparse.ArgumentParser(
        description="Bank Statement OCR Worker",
        epilog="Examples:\n"
               "  Auto parallel:  python batch_worker.py pdf1 1 59\n"
               "  Custom workers: python batch_worker.py pdf1 1 59 --workers 5\n"
               "  Legacy single:  python batch_worker.py W1 pdf1 1 2 3 4\n"
    )
    parser.add_argument("args", nargs="+", help="label + page range, or worker_id + label + pages")
    parser.add_argument("--workers", "-w", type=int, default=None,
                        help="Number of parallel workers (default: 3 or OCR_WORKERS env)")
    parsed = parser.parse_args()

    args = parsed.args

    # 检测模式：
    # 并行模式: python batch_worker.py <label> <start> <end> [--workers N]
    # 单worker模式: python batch_worker.py <worker_id> <label> <p1> [p2] ...

    num_workers = parsed.workers or int(os.environ.get("OCR_WORKERS", "3"))

    # 判断：如果第1个参数是数字且第2个参数也是数字 → 可能是并行模式
    # 进一步判断：如果第1个参数看起来像worker_id（如W1, W2, A, B）→ 单worker模式
    if len(args) >= 3:
        arg1, arg2, arg3 = args[0], args[1], args[2]
        # 并行模式：label + start + end
        if arg2.isdigit() and arg3.isdigit():
            label = arg1
            start_page = int(arg2)
            end_page = int(arg3)
            if len(args) > 3 and args[3].isdigit():
                end_page = int(args[3])
            success = run_parallel(label, start_page, end_page, num_workers)
            sys.exit(0 if success else 1)
        # 单worker模式：worker_id + label + pages...
        else:
            worker_id = arg1
            label = arg2
            page_nums = [int(x) for x in args[2:]]
            success = run_single(label, page_nums, worker_id)
            sys.exit(0 if success else 1)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
