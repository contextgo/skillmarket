#!/usr/bin/env python3
"""
基金会负面新闻搜索与评估工具 v2.0
Foundation News & Public Opinion Evaluator

用于评估基金会的网络舆情状况，包括：
1. 百度搜索引擎负面新闻检索框架
2. 负面事件分级（A/B/C三级）
3. 扣分自动计算
4. 正面加分项识别
5. 风险等级评定

使用方式:
    python news_evaluator.py "{基金会名称}"
    python news_evaluator.py "中国妇女发展基金会" --output json
    python news_evaluator.py "某某基金会" --search-date 2026-04-08

注意: 本脚本提供的是搜索关键词和评估框架，实际搜索需要AI通过浏览器/搜索API执行。
"""

import sys
import json
import argparse
from datetime import datetime, timedelta
from typing import Optional, List, Dict
from dataclasses import dataclass, field, asdict


# ============================================================
# 数据模型
# ============================================================

@dataclass
class NegativeEvent:
    """负面事件数据结构"""
    level: str  # A / B / C
    event_type: str  # 事件类型名称
    description: str  # 事件描述
    source: str  # 来源/证据
    confirmation: str  # 确认程度: confirmed / likely / unverified
    url: Optional[str] = None  # 来源链接
    event_date: Optional[str] = None  # 事发日期
    deduction: float = 0.0  # 扣分
    years_ago: Optional[int] = None  # 距今几年(用于时效衰减)


@dataclass
class PositiveEvent:
    """正面加分事件"""
    category: str  # 类别
    description: str  # 描述
    source: str  # 来源
    bonus: float = 0.0  # 加分


@dataclass
class NewsEvaluationResult:
    """舆情评价总结果"""
    foundation_name: str
    search_date: str
    search_platform: str = "百度"
    
    negative_events: List[Dict] = field(default_factory=list)
    positive_events: List[Dict] = field(default_factory=list)
    
    # 统计
    total_negative_count: int = 0
    level_a_count: int = 0
    level_b_count: int = 0
    level_c_count: int = 0
    
    total_deduction: float = 0.0
    total_bonus: float = 0.0
    net_score: float = 0.0
    
    risk_level: str = ""  # LOW / MEDIUM / HIGH
    
    search_keywords_used: List[str] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)


# ============================================================
# 搜索关键词矩阵
# ============================================================

SEARCH_KEYWORD_MATRIX = [
    {"keyword": "处罚",       "target": "行政处罚记录",     "priority": "HIGH"},
    {"keyword": "警告",       "target": "监管警告",         "priority": "HIGH"},
    {"keyword": "负面新闻",   "target": "媒体负面报道",     "priority": "HIGH"},
    {"keyword": "违规",       "target": "违规行为曝光",     "priority": "HIGH"},
    {"keyword": "举报",       "target": "投诉举报事件",     "priority": "MEDIUM"},
    {"keyword": "撤销 OR 吊销", "target": "资格被撤销",     "priority": "HIGH"},
    {"keyword": "异常经营 OR 经营异常", "target": "经营异常名录", "priority": "MEDIUM"},
    {"keyword": "失信",       "target": "失信被执行人",      "priority": "HIGH"},
]

# 备用扩展搜索词
EXTENDED_KEYWORDS = [
    ("挪用", "资金挪用嫌疑"),
    ("贪污", "贪污腐败相关"),
    ("调查", "被相关部门调查"),
    ("整改", "责令整改通知"),
    ("通报批评", "通报批评"),
    ("降级", "信用/评级降级"),
    ("投诉量", "大量投诉"),
    ("造假", "财务/信息造假"),
    ("欺诈", "募捐欺诈"),
]


# ============================================================
# 负面事件分级标准
# ============================================================

LEVEL_A_RULES = {
    "行政处罚": {
        "keywords": ["处罚", "罚款", "行政处罚决定书", "责令限期改正"],
        "deduction": -20,
        "description_template": "被处以行政处罚（{detail}）"
    },
    "撤销登记": {
        "keywords": ["撤销登记", "注销登记", "吊销登记证书"],
        "deduction": -20,
        "description_template": "登记资格被{action}"
    },
    "刑事立案": {
        "keywords": ["立案侦查", "刑事拘留", "移送司法机关", "涉嫌犯罪"],
        "deduction": -20,
        "description_template": "涉及刑事立案侦查"
    },
    "严重挪用侵占": {
        "keywords": ["挪用公款", "侵占财产", "贪污捐赠", "私分善款"],
        "deduction": -15,
        "description_template": "经证实存在{behavior}行为",
        "requires_confirmation": True  # 必须经权威确认
    },
}

LEVEL_B_RULES = {
    "监管警告": {
        "keywords": ["警告", "通报批评", "书面警告"],
        "deduction": -10,
        "description_template": "收到监管部门{type}处分"
    },
    "经营异常名录": {
        "keywords": ["列入经营异常名录", "异常名录", "异常经营"],
        "deduction": -8,
        "description_template": "被列入{list_type}"
    },
    "信用降级": {
        "keywords": ["信用降级", "等级降低", "评估降级"],
        "deduction": -8,
        "description_template": "{type}被降低"
    },
    "主流媒体负面报道": {
        "deduction_range": (-10, -5),
        "description_template": "主流媒体发布负面报道：{topic}",
        "note": "视严重程度扣5-10分"
    },
}

LEVEL_C_RULES = {
    "投诉较多": {
        "keywords": ["投诉", "质疑声多", "多人投诉"],
        "deduction": -3,
        "description_template": "存在较多{type}投诉"
    },
    "信息不透明质疑": {
        "keywords": ["不透明", "拒绝公开", "信息披露不足"],
        "deduction": -3,
        "description_template": "被质疑{issue}"
    },
    "项目争议": {
        "keywords": ["项目争议", "执行争议", "效果存疑"],
        "deduction_range": (-5, -2),
        "description_template": "单个项目存在{type}争议"
    },
    "高管负面言论": {
        "keywords": ["不当言论", "争议言论"],
        "deduction": -3,
        "description_template": "负责人发表不当言论"
    },
}

# 合并所有规则便于查找
ALL_LEVEL_RULES = {
    'A': LEVEL_A_RULES,
    'B': LEVEL_B_RULES,
    'C': LEVEL_C_RULES,
}


# ============================================================
# 正面加分规则
# ============================================================

POSITIVE_RULES = {
    "国家级表彰": {
        "examples": ["中华慈善奖", "全国先进社会组织", "国家脱贫攻坚奖"],
        "max_bonus": 5.0,
        "default_bonus": 5.0
    },
    "省部级荣誉": {
        "examples": ["省级先进社会组织", "省慈善奖", "五一劳动奖章(集体)"],
        "max_bonus": 3.0,
        "default_bonus": 3.0
    },
    "抗灾救灾突出贡献": {
        "examples": ["抗震救灾", "防汛抗旱", "疫情防控", "紧急救援"],
        "max_bonus": 3.0,
        "default_bonus": 3.0
    },
    "行业影响力正面报道": {
        "examples": ["人民日报", "新华社", "央视新闻", "光明日报"],
        "max_bonus": 6.0,
        "per_item_bonus": 2.0,
        "description": "主流媒体深度正面报道，每篇+2分(上限+6)"
    }
}


# ============================================================
# 核心评估函数
# ============================================================

def classify_event(event_description: str, source_type: str) -> Dict:
    """
    根据事件描述和来源类型进行分级分类
    
    Args:
        event_description: 事件的文字描述
        source_type: 来源类型 (government/mainstream/media/forum/other)
    
    Returns:
        包含级别、类型、扣分的字典
    """
    desc_lower = event_description.lower()
    
    # A级优先匹配
    for rule_name, rule in LEVEL_A_RULES.items():
        if 'keywords' in rule:
            for kw in rule['keywords']:
                if kw in event_description:
                    result = {
                        'level': 'A',
                        'event_type': rule_name,
                        'deduction': abs(rule['deduction']),
                        'rule': rule
                    }
                    # 如果需要确认且来源非政府/权威媒体，降级为C
                    if rule.get('requires_confirmation') and source_type not in ('government', 'mainstream'):
                        result['level'] = 'C'
                        result['deduction'] = 3
                    return result
    
    # B级匹配
    for rule_name, rule in LEVEL_B_RULES.items():
        if 'keywords' in rule:
            for kw in rule['keywords']:
                if kw in event_description:
                    return {
                        'level': 'B',
                        'event_type': rule_name,
                        'deduction': abs(rule.get('deduction', 8)),
                        'rule': rule
                    }
    
    # C级兜底
    for rule_name, rule in LEVEL_C_RULES.items():
        if 'keywords' in rule:
            for kw in rule['keywords']:
                if kw in event_description:
                    ded_range = rule.get('deduction_range', (-3, -3))
                    return {
                        'level': 'C',
                        'event_type': rule_name,
                        'deduction': abs(ded_range[0]),
                        'rule': rule
                    }
    
    # 无法分类的归入C级
    return {
        'level': 'C',
        'event_type': '其他负面',
        'deduction': 2,
        'rule': {'description_template': '{desc}'}
    }


def apply_time_decay(event_date_str: str, base_deduction: float, current_date: datetime = None) -> tuple:
    """
    时效衰减计算 — 超过3年的旧事件扣分减半
    
    Args:
        event_date_str: 事件发生日期 (YYYY-MM-DD 或 YYYY)
        base_deduction: 基础扣分数
        current_date: 当前日期（默认今天）
    
    Returns:
        (最终扣分, 是否已衰减)
    """
    if current_date is None:
        current_date = datetime.now()
    
    try:
        # 尝试解析完整日期
        if len(event_date_str) >= 10:
            event_date = datetime.strptime(event_date_str[:10], "%Y-%m-%d")
        elif len(event_date_str) == 4:
            event_date = datetime.strptime(event_date_str, "%Y")
        else:
            return base_deduction, False
        
        delta = current_date - event_date
        years = delta.days / 365.25
        
        if years > 3:
            return round(base_deduction * 0.5, 1), True
        
        return base_deduction, False
    except (ValueError, TypeError):
        return base_deduction, False


def determine_risk_level(net_score: int, level_a_count: int) -> str:
    """
    根据净得分和A级事件数确定风险等级
    
    规则:
    - 有任何A级事件 → 至少中等风险
    - 净得分 <= -15 → 高风险
    - 净得分 > 0 且无A级事件 → 低风险
    - 其他 → 中等风险
    """
    if level_a_count > 0 and net_score <= -15:
        return "HIGH"
    elif level_a_count > 0:
        return "MEDIUM"
    elif net_score <= -8:
        return "MEDIUM"
    else:
        return "LOW"


RISK_LEVEL_MAP = {
    "LOW": ("🟢 低风险", "未发现重大负面事件或负面影响有限"),
    "MEDIUM": ("🟡 中等风险", "存在需关注的负面信息，建议进一步核实"),
    "HIGH": ("🔴 高风险", "存在严重负面事件，建议审慎评估"),
}


def generate_search_keywords(foundation_name: str) -> List[str]:
    """生成完整的百度搜索关键词列表"""
    keywords = []
    for item in SEARCH_KEYWORD_MATRIX:
        keywords.append(f"{foundation_name} {item['keyword']}")
    
    # 扩展搜索
    for kw, target in EXTENDED_KEYWORDS:
        keywords.append(f"{foundation_name} {kw}")
    
    return keywords


def evaluate_news(
    foundation_name: str,
    negative_events_data: List[Dict] = None,
    positive_events_data: List[Dict] = None,
    search_date: str = None
) -> NewsEvaluationResult:
    """
    综合舆情评价主函数
    
    Args:
        foundation_name: 基金会名称
        negative_events_data: 发现的负面事件列表（每项包含 description, source, confirmation?, date?）
        positive_events_data: 正面事件列表（每项包含 category, description, source）
        search_date: 搜索日期 (YYYY-MM-DD)，默认当天
    
    Returns:
        NewsEvaluationResult 完整评价结果
    """
    if search_date is None:
        search_date = datetime.now().strftime("%Y-%m-%d")
    
    result = NewsEvaluationResult(
        foundation_name=foundation_name,
        search_date=search_date,
        search_keywords_used=generate_search_keywords(foundation_name)
    )
    
    # 处理负面事件
    if negative_events_data:
        current_date = datetime.now()
        
        for ev in negative_events_data:
            desc = ev.get('description', '')
            source_type = ev.get('source_type', 'other')  # government/mainstream/media/forum/other
            
            classification = classify_event(desc, source_type)
            
            base_deduction = classification['deduction']
            event_date = ev.get('date')
            
            # 应用时效衰减
            if event_date:
                final_deduction, decayed = apply_time_decay(
                    event_date, base_deduction, current_date
                )
                decay_note = f" (时效衰减: {base_deduction}→{final_deduction})" if decayed else ""
            else:
                final_deduction = base_deduction
                decay_note = ""
            
            event_record = {
                "level": classification['level'],
                "event_type": classification['event_type'],
                "description": desc,
                "source": ev.get('source', ''),
                "confirmation": ev.get('confirmation', 'unverified'),
                "url": ev.get('url'),
                "event_date": event_date,
                "deduction": -final_deduction,
                "decay_note": decay_note.strip(),
            }
            
            result.negative_events.append(event_record)
            result.total_deduction += final_deduction
            result.total_negative_count += 1
            
            if classification['level'] == 'A':
                result.level_a_count += 1
            elif classification['level'] == 'B':
                result.level_b_count += 1
            else:
                result.level_c_count += 1
    
    # 处理正面事件
    if positive_events_data:
        for ev in positive_events_data:
            cat = ev.get('category', '')
            rule = POSITIVE_RULES.get(cat, {})
            default_bonus = rule.get('default_bonus', 2.0)
            max_bonus = rule.get('max_bonus', default_bonus)
            
            bonus = min(default_bonus, max_bonus)
            
            event_record = {
                "category": cat,
                "description": ev.get('description', ''),
                "source": ev.get('source', ''),
                "bonus": bonus,
            }
            
            result.positive_events.append(event_record)
            result.total_bonus += bonus
    
    # 计算净得分
    result.net_score = result.total_bonus - result.total_deduction
    
    # 确定风险等级
    risk_code = determine_risk_level(int(result.net_score), result.level_a_count)
    result.risk_level = risk_code
    
    # 添加备注
    if result.level_a_count > 0:
        result.notes.append(f"⚠️ 发现{result.level_a_count}件严重负面(A级)事件")
    if result.total_negative_count > 5:
        result.notes.append("⚠️ 负面事件数量较多，建议深入排查")
    if result.net_score > 0 and result.total_negative_count == 0:
        result.notes.append("✅ 未发现显著负面事件")
    
    return result


# ============================================================
# 输出格式化
# ============================================================

def format_report(result: NewsEvaluationResult) -> str:
    """生成Markdown格式报告"""
    risk_icon, risk_desc = RISK_LEVEL_MAP.get(result.risk_level, ("❓ 未知", ""))
    
    lines = []
    lines.append(f"# 【{result.foundation_name}】网络舆情与负面事件评价")
    lines.append(f"")
    lines.append(f"**搜索平台**: {result.search_platform}")
    lines.append(f"**搜索日期**: {result.search_date}")
    lines.append(f"**搜索关键词组合**: {len(result.search_keywords_used)}组")
    lines.append(f"")
    lines.append("---")
    lines.append("")
    
    # 1. 负面事件汇总
    lines.append("## 1. 发现的负面事件汇总")
    lines.append("")
    
    if result.negative_events:
        lines.append("| 级别 | 事件类型 | 描述 | 来源 | 确认度 | 扣分 |")
        lines.append("|------|----------|------|------|--------|------|")
        for ev in result.negative_events:
            level_icon = {'A': '🔴', 'B': '🟠', 'C': '🟡'}.get(ev['level'], '⚪')
            conf_map = {'confirmed': '✅已确认', 'likely': '🔶待核实', 'unverified': '❓未确认'}
            conf_text = conf_map.get(ev['confirmation'], ev['confirmation'])
            decay = ev.get('decay_note', '')
            lines.append(
                f"| {level_icon}{ev['level']}级 "
                f"| {ev['event_type']} "
                f"| {ev['description'][:40]}{'...' if len(ev['description'])>40 else ''} "
                f"| {ev['source'][:20]} "
                f"| {conf_text} "
                f"| **{ev['deduction']}** {decay} |"
            )
    else:
        lines.append("✅ 未发现明显负面事件。")
    lines.append("")
    
    # 2. 正面事件
    lines.append("## 2. 正面加分事件")
    lines.append("")
    if result.positive_events:
        lines.append("| 类别 | 描述 | 来源 | 加分 |")
        lines.append("|------|------|------|------|")
        for ev in result.positive_events:
            lines.append(
                f"| {ev['category']} "
                f"| {ev['description'][:35]}{'...' if len(ev['description'])>35 else ''} "
                f"| {ev['source'][:20]} "
                f"| +{ev['bonus']} |"
            )
    else:
        lines.append("— 未找到可加分的正面事件。")
    lines.append("")
    
    # 3. 结论
    lines.append("## 3. 舆情评价结论")
    lines.append("")
    lines.append("| 维度 | 结果 |")
    lines.append("|------|------|")
    lines.append(f"| 负面事件总数 | **{result.total_negative_count}**件 "
                 f"(A级{result.level_a_count}件/B级{result.level_b_count}件/C级{result.level_c_count}件)|")
    lines.append(f"| 舆情总扣分 | **-{result.total_deduction:.1f}分** |")
    lines.append(f"| 正面加分数 | **+{result.total_bonus:.1f}分** |")
    lines.append(f"| 净舆情分 | **{result.net_score:+.1f}分** |")
    lines.append(f"| 舆情风险等级 | **{risk_icon} {risk_desc[0]}** — {risk_desc[1]} |")
    lines.append("")
    
    # 4. 搜索关键词清单
    lines.append("## 附录: 本次搜索使用的全部关键词")
    lines.append("")
    for i, kw in enumerate(result.search_keywords_used, 1):
        priority = "🔴高" if i <= 8 else "🟡中"
        lines.append(f"{i}. `{kw}` [{priority}]")
    lines.append("")
    
    # 备注
    if result.notes:
        lines.append("> **审计师备注**:")
        for note in result.notes:
            lines.append(f"> - {note}")
    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("*⚠️ 本舆情评价基于公开网络搜索结果，仅供参考，不构成法律判断。*")
    lines.append(f"*搜索时间: {result.search_date}*")
    
    return "\n".join(lines)


def format_json(result: NewsEvaluationResult) -> str:
    """输出JSON格式"""
    data = asdict(result)
    # 将risk_level转换为可读格式
    risk_info = RISK_LEVEL_MAP.get(result.risk_level, ("未知", ""))
    data["risk_level_display"] = f"{risk_info[0]} — {risk_info[1]}"
    return json.dumps(data, ensure_ascii=False, indent=2)


# ============================================================
# CLI 入口
# ============================================================

def main():
    parser = argparse.ArgumentParser(
        description="基金会负面新闻搜索与评估工具 v2.0",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用示例:
  python news_evaluator.py "中国妇女发展基金会"
  python news_evaluator.py "某某基金会" --output json
  python news_evaluator.py "某某基金会" --events '[{"description":"2024年被民政部罚款","source":"民政部公告","source_type":"government","confirmation":"confirmed","date":"2024-06-15"}]'
        """
    )
    
    parser.add_argument("foundation_name", help="基金会名称")
    parser.add_argument("--search-date", help="搜索日期 (YYYY-MM-DD)", default=None)
    parser.add_argument("--output", choices=["text", "json"], default="text", 
                        help="输出格式 (默认: text)")
    parser.add_argument("--events", help='JSON格式的负面事件数据（用于测试）', default=None)
    parser.add_argument("--positives", help='JSON格式的正面事件数据（用于测试）', default=None)
    
    args = parser.parse_args()
    
    # 解析测试用的负面事件数据
    neg_events = None
    if args.events:
        try:
            neg_events = json.loads(args.events)
        except json.JSONDecodeError:
            print(f"错误: 无法解析 --events 参数: {args.events}", file=sys.stderr)
            sys.exit(1)
    
    pos_events = None
    if args.positives:
        try:
            pos_events = json.loads(args.positives)
        except json.JSONDecodeError:
            print(f"错误: 无法解析 --positives 参数: {args.positives}", file=sys.stderr)
            sys.exit(1)
    
    # 执行评价
    result = evaluate_news(
        foundation_name=args.foundation_name,
        negative_events_data=neg_events,
        positive_events_data=pos_events,
        search_date=args.search_date
    )
    
    # 输出结果
    if args.output == "json":
        print(format_json(result))
    else:
        print(format_report(result))


if __name__ == "__main__":
    main()


# ============================================================
# 示例用法 / 测试代码
# ============================================================

def demo():
    """演示示例"""
    sample_negatives = [
        {
            "description": "2024年因未按时披露年度报告被民政部处以5万元罚款",
            "source": "民政部行政处罚公告",
            "source_type": "government",
            "confirmation": "confirmed",
            "date": "2024-06-15",
            "url": "http://example.gov/penalty/12345"
        },
        {
            "description": "2023年列入经营异常名录",
            "source": "国家企业信用信息公示系统",
            "source_type": "government",
            "confirmation": "confirmed",
            "date": "2023-03-20"
        },
        {
            "description": "网友在论坛质疑某项目执行效率低",
            "source": "某论坛讨论帖",
            "source_type": "forum",
            "confirmation": "unverified",
            "date": "2025-12-01"
        },
    ]
    
    sample_positives = [
        {
            "category": "国家级表彰",
            "description": "荣获第十一届中华慈善奖",
            "source": "民政部公告"
        },
        {
            "category": "行业影响力正面报道",
            "description": "《人民日报》深度报道该基金会扶贫项目成效",
            "source": "人民日报2025-01-15"
        }
    ]
    
    result = evaluate_news(
        foundation_name="示例公益基金会",
        negative_events_data=sample_negatives,
        positive_events_data=sample_positives,
        search_date=datetime.now().strftime("%Y-%m-%d")
    )
    
    print(format_report(result))
    print("\n\n========== JSON输出 ==========\n")
    print(format_json(result))
