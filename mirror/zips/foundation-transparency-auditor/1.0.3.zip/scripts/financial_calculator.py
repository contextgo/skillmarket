#!/usr/bin/env python3
"""
基金会财务指标核算工具
Foundation Financial Metrics Calculator

基于《民间非营利组织会计制度》计算关键财务指标
"""

import sys
from typing import Optional

def calculate_public_welfare_ratio(
    welfare_expenditure: float,
    beginning_net_assets: float,
    ending_net_assets: float,
    foundation_type: str = "non-public"  # "public" 公募, "non-public" 非公募
) -> dict:
    """
    计算公益支出比例
    
    公式: 公益支出比 = 年度公益支出 ÷ 净资产年均余额 × 100%
    要求: 公募基金会 ≥ 70%, 非公募基金会 ≥ 8%
    """
    avg_net_assets = (beginning_net_assets + ending_net_assets) / 2
    
    if avg_net_assets == 0:
        return {
            "ratio": None,
            "avg_net_assets": 0,
            "status": "error",
            "message": "净资产年均余额为零，无法计算"
        }
    
    ratio = (welfare_expenditure / avg_net_assets) * 100
    
    if foundation_type == "public":
        threshold = 70
        warning_threshold = 60
    else:  # non-public
        threshold = 8
        warning_threshold = 5
    
    if ratio >= threshold:
        status = "pass"
    elif ratio >= warning_threshold:
        status = "warning"
    else:
        status = "fail"
    
    type_label = "公募基金会" if foundation_type == "public" else "非公募基金会"
    
    return {
        "ratio": round(ratio, 2),
        "avg_net_assets": round(avg_net_assets, 2),
        "welfare_expenditure": welfare_expenditure,
        "foundation_type": type_label,
        "status": status,
        "requirement": f"≥{threshold}%",
        "message": f"公益支出比例({type_label}): {ratio:.2f}% (要求≥{threshold}%)"
    }


def calculate_admin_ratio(
    admin_expense: float,
    total_expense: float,
    foundation_type: str = "public"  # "public" 公募, "non-public" 非公募
) -> dict:
    """
    计算管理费用比例
    
    公式: 管理费用比 = 管理费用 ÷ 当年总支出 × 100%
    要求: 公募基金会 ≤10%, 非公募基金会 ≤20%
    """
    if total_expense == 0:
        return {
            "ratio": None,
            "status": "error",
            "message": "总支出为零，无法计算"
        }
    
    ratio = (admin_expense / total_expense) * 100
    
    if foundation_type == "public":
        threshold = 10
        warning_threshold = 10
    else:  # non-public
        threshold = 13
        warning_threshold = 13
    
    if ratio <= threshold:
        status = "pass"
    elif ratio <= warning_threshold:
        status = "warning"
    else:
        status = "fail"
    
    return {
        "ratio": round(ratio, 2),
        "admin_expense": admin_expense,
        "total_expense": total_expense,
        "status": status,
        "requirement": f"≤{threshold}%",
        "message": f"管理费用比例: {ratio:.2f}% (要求≤{threshold}%)"
    }


def calculate_fundraising_ratio(
    fundraising_expense: float,
    donation_income: float
) -> dict:
    """
    计算筹资费用比例
    
    公式: 筹资费用比 = 筹资费用 ÷ 捐赠收入 × 100%
    建议: <10%, 异常 >20%
    """
    if donation_income == 0:
        return {
            "ratio": None,
            "status": "error",
            "message": "捐赠收入为零，无法计算"
        }
    
    ratio = (fundraising_expense / donation_income) * 100
    
    if ratio < 10:
        status = "pass"
    elif ratio <= 10:
        status = "warning"
    else:
        status = "fail"
    
    return {
        "ratio": round(ratio, 2),
        "fundraising_expense": fundraising_expense,
        "donation_income": donation_income,
        "status": status,
        "requirement": "<10%",
        "message": f"筹资费用比例: {ratio:.2f}% (建议<10%)"
    }


def calculate_staff_ratio(
    staff_expense: float,
    admin_expense: float
) -> dict:
    """
    计算人员费用占管理费用比例
    
    公式: 人员费用比 = 人员费用 ÷ 管理费用 × 100%
    异常阈值: >60%
    """
    if admin_expense == 0:
        return {
            "ratio": None,
            "status": "error",
            "message": "管理费用为零，无法计算"
        }
    
    ratio = (staff_expense / admin_expense) * 100
    
    if ratio <= 60:
        status = "pass"
    elif ratio <= 80:
        status = "warning"
    else:
        status = "fail"
    
    return {
        "ratio": round(ratio, 2),
        "staff_expense": staff_expense,
        "admin_expense": admin_expense,
        "status": status,
        "requirement": "≤60%",
        "message": f"人员费用占管理费用比例: {ratio:.2f}% (建议≤60%)"
    }


def calculate_debt_ratio(
    total_liabilities: float,
    total_assets: float
) -> dict:
    """
    计算资产负债率
    
    公式: 资产负债率 = 总负债 ÷ 总资产 × 100%
    正常范围: 30%-70%, 异常 >80%
    """
    if total_assets == 0:
        return {
            "ratio": None,
            "status": "error",
            "message": "总资产为零，无法计算"
        }
    
    ratio = (total_liabilities / total_assets) * 100
    
    if 30 <= ratio <= 70:
        status = "pass"
    elif 70 < ratio <= 80:
        status = "warning"
    else:
        status = "fail"
    
    return {
        "ratio": round(ratio, 2),
        "total_liabilities": total_liabilities,
        "total_assets": total_assets,
        "status": status,
        "requirement": "30%-70%",
        "message": f"资产负债率: {ratio:.2f}% (正常范围30%-70%)"
    }


def calculate_welfare_growth(
    current_welfare: float,
    previous_welfare: float
) -> dict:
    """
    计算公益支出增长率
    
    公式: 增长率 = (本期-上期) ÷ 上期 × 100%
    """
    if previous_welfare == 0:
        return {
            "growth_rate": None,
            "status": "warning",
            "message": "上期公益支出为零，无法计算增长率"
        }
    
    growth_rate = ((current_welfare - previous_welfare) / previous_welfare) * 100
    
    if growth_rate >= 0:
        status = "pass"
        message = f"公益支出同比增长: {growth_rate:.2f}%"
    else:
        status = "warning"
        message = f"公益支出同比下降: {growth_rate:.2f}%"
    
    return {
        "growth_rate": round(growth_rate, 2),
        "current_welfare": current_welfare,
        "previous_welfare": previous_welfare,
        "status": status,
        "message": message
    }


def comprehensive_audit(
    foundation_name: str,
    foundation_type: str,
    welfare_expenditure: float,
    beginning_net_assets: float,
    ending_net_assets: float,
    admin_expense: float,
    total_expense: float,
    fundraising_expense: float = 0,
    donation_income: float = 0,
    staff_expense: float = 0,
    total_liabilities: float = 0,
    total_assets: float = 0,
    previous_welfare: float = 0
) -> dict:
    """
    综合财务审计
    
    Args:
        foundation_name: 基金会名称
        foundation_type: "public" 公募, "non-public" 非公募
        welfare_expenditure: 年度公益支出
        beginning_net_assets: 年初净资产
        ending_net_assets: 年末净资产
        admin_expense: 管理费用
        total_expense: 当年总支出
        fundraising_expense: 筹资费用
        donation_income: 捐赠收入
        staff_expense: 人员费用
        total_liabilities: 总负债
        total_assets: 总资产
        previous_welfare: 上年度公益支出
    
    Returns:
        包含所有指标计算结果的字典
    """
    results = {
        "foundation_name": foundation_name,
        "foundation_type": "公募基金会" if foundation_type == "public" else "非公募基金会",
        "metrics": {},
        "summary": {}
    }
    
    # 公益支出比例
    welfare_ratio = calculate_public_welfare_ratio(
        welfare_expenditure, beginning_net_assets, ending_net_assets, foundation_type
    )
    results["metrics"]["公益支出比例"] = welfare_ratio
    
    # 管理费用比例
    admin_ratio = calculate_admin_ratio(
        admin_expense, total_expense, foundation_type
    )
    results["metrics"]["管理费用比例"] = admin_ratio
    
    # 筹资费用比例
    if donation_income > 0:
        fundraising_ratio = calculate_fundraising_ratio(
            fundraising_expense, donation_income
        )
        results["metrics"]["筹资费用比例"] = fundraising_ratio
    
    # 人员费用比例
    if staff_expense > 0 and admin_expense > 0:
        staff_ratio = calculate_staff_ratio(staff_expense, admin_expense)
        results["metrics"]["人员费用比例"] = staff_ratio
    
    # 资产负债率
    if total_assets > 0:
        debt_ratio = calculate_debt_ratio(total_liabilities, total_assets)
        results["metrics"]["资产负债率"] = debt_ratio
    
    # 公益支出增长率
    if previous_welfare > 0:
        growth = calculate_welfare_growth(welfare_expenditure, previous_welfare)
        results["metrics"]["公益支出增长率"] = growth
    
    # 综合评定
    fail_count = sum(1 for m in results["metrics"].values() if m.get("status") == "fail")
    warning_count = sum(1 for m in results["metrics"].values() if m.get("status") == "warning")
    total_count = len(results["metrics"])
    
    if fail_count > 0:
        overall = "不合格"
    elif warning_count > total_count * 0.3:
        overall = "需改进"
    else:
        overall = "合格"
    
    results["summary"] = {
        "total_metrics": total_count,
        "fail_count": fail_count,
        "warning_count": warning_count,
        "pass_count": total_count - fail_count - warning_count,
        "overall": overall
    }
    
    return results


def print_report(results: dict):
    """打印审计报告"""
    print("=" * 60)
    print(f"基金会财务合规审计报告: {results['foundation_name']}")
    print(f"组织类型: {results['foundation_type']}")
    print("=" * 60)
    
    print("\n【财务指标核算结果】")
    print("-" * 60)
    
    for metric_name, metric_data in results["metrics"].items():
        status_map = {
            "pass": "✓ 合规",
            "warning": "⚠ 关注",
            "fail": "✗ 违规",
            "error": "❌ 错误"
        }
        status_icon = status_map.get(metric_data.get("status", ""), "")
        
        print(f"\n{metric_name}: {status_icon}")
        if "ratio" in metric_data and metric_data["ratio"] is not None:
            print(f"  计算值: {metric_data['ratio']}%")
        if "requirement" in metric_data:
            print(f"  法规要求: {metric_data['requirement']}")
        print(f"  说明: {metric_data['message']}")
    
    print("\n" + "=" * 60)
    print("【综合评定】")
    print(f"  检测指标数: {results['summary']['total_metrics']}")
    print(f"  合规项: {results['summary']['pass_count']}")
    print(f"  关注项: {results['summary']['warning_count']}")
    print(f"  违规项: {results['summary']['fail_count']}")
    print(f"  综合评定: {results['summary']['overall']}")
    print("=" * 60)


if __name__ == "__main__":
    # 示例：某公募基金会年度数据
    sample_results = comprehensive_audit(
        foundation_name="示例基金会",
        foundation_type="public",
        welfare_expenditure=8000000,  # 公益支出800万
        beginning_net_assets=50000000,  # 年初净资产5000万
        ending_net_assets=55000000,     # 年末净资产5500万
        admin_expense=1200000,          # 管理费用120万
        total_expense=12000000,         # 总支出1200万
        fundraising_expense=500000,     # 筹资费用50万
        donation_income=10000000,       # 捐赠收入1000万
        staff_expense=600000,           # 人员费用60万
        total_liabilities=3000000,      # 总负债300万
        total_assets=58000000,         # 总资产5800万
        previous_welfare=7500000        # 上年公益支出750万
    )
    
    print_report(sample_results)
