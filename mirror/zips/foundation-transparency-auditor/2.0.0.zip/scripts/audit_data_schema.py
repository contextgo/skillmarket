#!/usr/bin/env python3
"""
基金会透明审计 - 数据结构定义与示例 v2.0
Foundation Transparency Audit Data Schema & Demo

本文件定义了审计数据的 JSON Schema，AI 按此结构组织数据后，
通过 generate_report.py 生成 HTML 审计报告。

使用方式（由 AI 自动执行）：
  1. AI 按此结构将审计数据写入 JSON 文件
  2. 运行: python generate_report.py audit_data.json --output report.html
"""

import json
from datetime import datetime

# ===== 完整数据结构（JSON Schema 示例）=====

AUDIT_DATA_SCHEMA = {
    "foundation_name": "示例公益基金会",
    "audit_date": "2026-04-27",
    "audit_period": "2025",
    "version": "2.0",

    "basic_info": {
        "name": "示例公益基金会",
        "credit_code": "53100000XXXXXXXXXX",
        "legal_person": "张三",
        "establish_date": "2008-06-15",
        "org_type": "公募基金会",
        "supervisor": "民政部",
        "address": "北京市XX区XX路XX号",
        "website_url": "https://www.example-foundation.org",
        "wechat_name": "示例公益基金会"
    },

    "channel_scores": {
        "cszg_score": 78,
        "cszg_details": [
            {"name": "基础登记信息完整度", "max": 15, "score": 15, "note": "全部完整"},
            {"name": "年度工作报告填报", "max": 25, "score": 17, "note": "2024年缺失，扣8分"},
            {"name": "财务会计报告公开", "max": 20, "score": 20, "note": "含资产负债表+业务活动表+审计报告"},
            {"name": "募捐方案备案", "max": 15, "score": 11, "note": "有备案但部分过期"},
            {"name": "慈善项目信息", "max": 15, "score": 8, "note": "仅有项目名称，缺进展"},
            {"name": "等级评估结果", "max": 10, "score": 7, "note": "4A等级"}
        ],
        "website_score": 65,
        "website_details": [
            {"name": "网站可用性与更新", "max": 20, "score": 15, "note": "可访问，最近2月有更新"},
            {"name": "组织信息公开", "max": 20, "score": 12, "note": "章程和机构设置有，理事名单不全"},
            {"name": "财务信息披露", "max": 25, "score": 18, "note": "有年报摘要，无完整审计报告下载"},
            {"name": "项目展示完整性", "max": 20, "score": 12, "note": "仅列在执行项目"},
            {"name": "联系方式与反馈", "max": 15, "score": 8, "note": "有电话邮箱，缺捐赠渠道"}
        ],
        "wechat_score": 72,
        "wechat_details": [
            {"name": "认证状态", "max": 15, "score": 15, "note": "已认证服务号"},
            {"name": "发布频率", "max": 25, "score": 18, "note": "月均2-3篇"},
            {"name": "内容质量", "max": 25, "score": 18, "note": "含项目进展和活动报告"},
            {"name": "互动反馈", "max": 20, "score": 13, "note": "有菜单导航，缺捐赠入口"},
            {"name": "账号一致性", "max": 15, "score": 8, "note": "主体与基金会名称基本一致"}
        ]
    },

    "governance": [
        {"check_item": "理事会规模", "requirement": "5-25人", "status": "pass", "note": "15人，合规"},
        {"check_item": "理事长产生", "requirement": "选举或章程规定", "status": "pass", "note": "按章程选举产生"},
        {"check_item": "会议制度", "requirement": "每年至少2次", "status": "pass", "note": "2025年召开4次理事会"},
        {"check_item": "监事设置", "requirement": "规模较大设监事会", "status": "warning", "note": "仅有监事1名，无监事会"},
        {"check_item": "利益冲突回避", "requirement": "关联关系披露", "status": "pass", "note": "章程中有回避条款"}
    ],

    "finance_metrics": [
        {"name": "慈善活动支出比例", "requirement": "≥上年总收入70%", "actual": "78.5%", "status": "pass", "regulation": "2026新规第八条"},
        {"name": "管理费用比例", "requirement": "≤总支出10%", "actual": "8.2%", "status": "pass", "regulation": "2026新规第八条"},
        {"name": "募捐成本比例", "requirement": "≤前三年捐赠收入均值3%", "actual": "2.1%", "status": "pass", "regulation": "2026新规第十五条"},
        {"name": "人员费用比例", "requirement": "≤60%（参考）", "actual": "45.3%", "status": "pass", "regulation": "行业参考"},
        {"name": "资产负债率", "requirement": "30%-70%", "actual": "18.5%", "status": "warning", "regulation": "行业参考"}
    ],

    "timeliness": [
        {"report_type": "年度工作报告", "is_public": "是", "latest_date": "2026-03-20", "elapsed": "1个月", "timeliness_status": "✅ 及时", "deduction": 0},
        {"report_type": "审计报告", "is_public": "是", "latest_date": "2026-03-20", "elapsed": "1个月", "timeliness_status": "✅ 及时", "deduction": 0},
        {"report_type": "资产负债表", "is_public": "是", "latest_date": "2025-03-15", "elapsed": "13个月", "timeliness_status": "🔴 滞后>3月", "deduction": -8},
        {"report_type": "业务活动表", "is_public": "否", "latest_date": "—", "elapsed": "—", "timeliness_status": "❌ 缺失", "deduction": -5}
    ],

    "opinion": {
        "negative_events": [
            {
                "level": "B",
                "description": "2023年因信息披露不完整被民政部书面警告",
                "source": "民政部公告",
                "confirmation": "confirmed",
                "deduction": -10,
                "decay_note": "(时效衰减: 10→5.0)"
            }
        ],
        "total_negative_count": 1,
        "level_a_count": 0,
        "level_b_count": 1,
        "level_c_count": 0,
        "total_deduction": 5.0,
        "total_bonus": 5.0,
        "net_score": 0.0,
        "risk_level_display": "🟡 中等风险"
    },

    "project": [
        {"check_item": "项目与宗旨一致性", "status": "pass", "note": "全部项目与教育扶贫宗旨一致"},
        {"check_item": "受益人遴选机制", "status": "pass", "note": "有明确遴选标准"},
        {"check_item": "项目成效披露", "status": "warning", "note": "部分项目仅有概述，缺量化成效"},
        {"check_item": "专款专用", "status": "pass", "note": "财务追踪正常"}
    ],

    "scores": {
        "disclosure_raw": 72,
        "disclosure_weighted": 18.0,
        "governance_score": 82,
        "governance_weighted": 16.4,
        "finance_score": 75,
        "finance_weighted": 18.75,
        "project_score": 80,
        "project_weighted": 12.0,
        "opinion_raw": 0,
        "opinion_score": 55,
        "opinion_weighted": 8.25,
        "timeliness_deduction": 13,
        "subtotal": 73.4,
        "total_score": 60
    },

    "improvements": {
        "high": [
            {"issue": "资产负债表披露滞后超过3个月", "regulation": "《慈善组织信息公开办法》第五条", "suggestion": "在30日内补充披露"},
            {"issue": "业务活动表未公开", "regulation": "《慈善法》第七十五条", "suggestion": "立即在慈善中国补充上传"}
        ],
        "medium": [
            {"issue": "监事仅1名，未设监事会", "regulation": "《基金会管理条例》第二十条", "suggestion": "增选监事，组建监事会"},
            {"issue": "项目成效量化披露不足", "regulation": "《慈善组织信息公开办法》第十条", "suggestion": "建立项目成效评估体系"}
        ],
        "low": [
            {"issue": "官网捐赠渠道缺失", "regulation": "最佳实践", "suggestion": "增设在线捐赠入口"},
            {"issue": "微信公众号缺捐赠入口", "regulation": "最佳实践", "suggestion": "在菜单中添加捐赠入口"}
        ]
    }
}


def create_sample_json(output_path: str = "sample_audit_data.json"):
    """生成示例 JSON 数据文件"""
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(AUDIT_DATA_SCHEMA, f, ensure_ascii=False, indent=2)
    print(f"[OK] 示例数据已生成: {output_path}")


def validate_data(data: dict) -> list:
    """验证审计数据结构完整性"""
    errors = []
    required_top = ["foundation_name", "audit_date", "basic_info", "channel_scores",
                    "governance", "finance_metrics", "timeliness", "opinion",
                    "project", "scores", "improvements"]
    for key in required_top:
        if key not in data:
            errors.append(f"缺少顶层字段: {key}")

    # 检查评分字段
    if "scores" in data:
        score_fields = ["disclosure_raw", "governance_score", "finance_score",
                       "project_score", "opinion_score", "total_score"]
        for sf in score_fields:
            if sf not in data["scores"]:
                errors.append(f"scores 中缺少字段: {sf}")

    return errors


if __name__ == "__main__":
    # 生成示例数据
    create_sample_json()

    # 验证
    errors = validate_data(AUDIT_DATA_SCHEMA)
    if errors:
        print("[WARN] 数据验证问题:")
        for e in errors:
            print(f"  - {e}")
    else:
        print("[OK] 示例数据结构验证通过")
