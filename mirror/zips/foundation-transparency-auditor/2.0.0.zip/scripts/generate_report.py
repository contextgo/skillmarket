#!/usr/bin/env python3
"""
基金会透明审计 HTML 报告生成器 v2.0
Foundation Transparency Audit HTML Report Generator

输入: 审计数据 JSON 文件
输出: 格式化的 HTML 审计报告

使用方式:
    python generate_report.py audit_data.json
    python generate_report.py audit_data.json --output report.html
"""

import sys
import json
import argparse
import os
from datetime import datetime
from pathlib import Path


# ===== 工具函数 =====

def status_badge(status):
    """根据状态返回 HTML badge"""
    mapping = {
        "pass": '<span class="badge badge-pass">✅ 合规</span>',
        "fail": '<span class="badge badge-fail">❌ 违规</span>',
        "warning": '<span class="badge badge-warning">⚠️ 关注</span>',
        "exempt": '<span class="badge badge-exempt">○ 豁免</span>',
        "error": '<span class="badge badge-error">❌ 错误</span>',
        "na": '<span class="badge badge-error">N/A</span>',
    }
    return mapping.get(status, f'<span class="badge">{status}</span>')


def format_amount(value):
    """格式化金额（万元）"""
    if value is None:
        return "N/A"
    return f"{value / 10000:.2f} 万元"


def format_pct(value):
    """格式化百分比"""
    if value is None:
        return "N/A"
    return f"{value:.2f}%"


def get_grade_info(score):
    """根据分数获取等级信息"""
    if score >= 108:
        return "AAAAA", "#27ae60", "#e8f8f0"
    elif score >= 96:
        return "AAAA", "#27ae60", "#e8f8f0"
    elif score >= 84:
        return "AAA", "#2980b9", "#eaf2f8"
    elif score >= 72:
        return "AA", "#f39c12", "#fef5e7"
    elif score >= 60:
        return "A", "#e67e22", "#fef5e7"
    else:
        return "不合格", "#e74c3c", "#fde8e8"


def get_ring_color(score):
    """根据分数获取环形图颜色"""
    if score >= 96:
        return "#27ae60"
    elif score >= 72:
        return "#2980b9"
    elif score >= 60:
        return "#f39c12"
    else:
        return "#e74c3c"


def calc_ring_offset(score, max_score=120):
    """计算环形图的 stroke-dashoffset"""
    circumference = 2 * 3.14159 * 66  # 约414.69
    ratio = min(score / max_score, 1.0)
    return round(circumference * (1 - ratio), 2)


def generate_basic_info_rows(data):
    """生成基本信息行"""
    info = data.get("basic_info", {})
    rows_template = """
      <div class="info-item"><span class="label">注册名称</span><span class="value">{name}</span></div>
      <div class="info-item"><span class="label">统一社会信用代码</span><span class="value">{credit_code}</span></div>
      <div class="info-item"><span class="label">法定代表人</span><span class="value">{legal_person}</span></div>
      <div class="info-item"><span class="label">成立日期</span><span class="value">{establish_date}</span></div>
      <div class="info-item"><span class="label">组织类型</span><span class="value">{org_type}</span></div>
      <div class="info-item"><span class="label">业务主管单位</span><span class="value">{supervisor}</span></div>
      <div class="info-item"><span class="label">注册地址</span><span class="value">{address}</span></div>
      <div class="info-item"><span class="label">官方网站</span><span class="value">{website}</span></div>
      <div class="info-item"><span class="label">微信公众号</span><span class="value">{wechat}</span></div>
    """
    return rows_template.format(
        name=info.get("name", "—"),
        credit_code=info.get("credit_code", "—"),
        legal_person=info.get("legal_person", "—"),
        establish_date=info.get("establish_date", "—"),
        org_type=info.get("org_type", "—"),
        supervisor=info.get("supervisor", "—"),
        address=info.get("address", "—"),
        website=info.get("website_url", "—"),
        wechat=info.get("wechat_name", "—"),
    )


def generate_channel_detail_rows(items):
    """生成渠道评分明细行"""
    rows = []
    for item in items:
        rows.append(
            f'<tr><td>{item.get("name","")}</td><td>{item.get("max","")}</td>'
            f'<td><strong>{item.get("score","")}</strong></td><td>{item.get("note","")}</td></tr>'
        )
    return "\n        ".join(rows)


def generate_governance_rows(items):
    """生成组织治理行"""
    rows = []
    for item in items:
        badge = status_badge(item.get("status", "na"))
        rows.append(
            f'<tr><td>{item.get("check_item","")}</td><td>{item.get("requirement","")}</td>'
            f'<td>{badge}</td><td>{item.get("note","")}</td></tr>'
        )
    return "\n        ".join(rows)


def generate_finance_metric_rows(metrics):
    """生成财务指标行"""
    rows = []
    for m in metrics:
        badge = status_badge(m.get("status", "na"))
        rows.append(
            f'<tr><td>{m.get("name","")}</td><td>{m.get("requirement","")}</td>'
            f'<td><strong>{m.get("actual","")}</strong></td><td>{badge}</td>'
            f'<td style="font-size:12px;color:var(--gray-600)">{m.get("regulation","")}</td></tr>'
        )
    return "\n        ".join(rows)


def generate_timeliness_rows(items):
    """生成时效性行"""
    rows = []
    for item in items:
        status = item.get("timeliness_status", "")
        if "及时" in status:
            badge = status_badge("pass")
        elif "滞后" in status:
            badge = status_badge("fail")
        else:
            badge = status_badge("error")
        rows.append(
            f'<tr><td>{item.get("report_type","")}</td><td>{item.get("is_public","")}</td>'
            f'<td>{item.get("latest_date","")}</td><td>{item.get("elapsed","")}</td>'
            f'<td>{badge}</td><td style="color:var(--danger)">{item.get("deduction","0")}</td></tr>'
        )
    return "\n        ".join(rows)


def generate_negative_events_html(events):
    """生成负面事件 HTML"""
    if not events:
        return '<div style="padding:16px;color:var(--success);font-weight:500">✅ 未发现明显负面事件</div>'

    html_parts = []
    for ev in events:
        level = ev.get("level", "C")
        level_class = f"level-{level.lower()}"
        desc = ev.get("description", "")
        source = ev.get("source", "")
        conf_map = {"confirmed": "✅已确认", "likely": "🔶待核实", "unverified": "❓未确认"}
        conf = conf_map.get(ev.get("confirmation", ""), ev.get("confirmation", ""))
        deduction = ev.get("deduction", 0)
        decay = ev.get("decay_note", "")

        html_parts.append(
            f'<div class="event-row">'
            f'<div class="event-level {level_class}">{level}</div>'
            f'<div style="flex:1"><div style="font-weight:500">{desc}</div>'
            f'<div style="font-size:12px;color:var(--gray-600);margin-top:4px">'
            f'来源: {source} | 确认度: {conf} | 扣分: <strong style="color:var(--danger)">{deduction}</strong> {decay}</div></div></div>'
        )
    return "\n    ".join(html_parts)


def generate_project_rows(items):
    """生成项目执行行"""
    rows = []
    for item in items:
        badge = status_badge(item.get("status", "na"))
        rows.append(
            f'<tr><td>{item.get("check_item","")}</td><td>{badge}</td><td>{item.get("note","")}</td></tr>'
        )
    return "\n        ".join(rows)


def generate_improvement_items(items, level):
    """生成改进事项"""
    if not items:
        return '<div style="padding:8px;color:var(--gray-600)">— 无</div>'
    css_class = f"improvement-{level}"
    html_parts = []
    for idx, item in enumerate(items, 1):
        html_parts.append(
            f'<div class="improvement-item {css_class}">'
            f'<span style="font-weight:600;min-width:24px">{idx}.</span>'
            f'<div><strong>{item.get("issue","")}</strong><br>'
            f'<span style="font-size:12px;color:var(--gray-600)">法规依据: {item.get("regulation","")} | 建议: {item.get("suggestion","")}</span></div></div>'
        )
    return "\n    ".join(html_parts)


def generate_html_report(data):
    """主函数：生成完整 HTML 报告"""

    # 读取模板
    template_dir = Path(__file__).parent.parent / "templates"
    template_path = template_dir / "audit_report.html"
    with open(template_path, "r", encoding="utf-8") as f:
        template = f.read()

    # 提取数据
    name = data.get("foundation_name", "未知基金会")
    audit_date = data.get("audit_date", datetime.now().strftime("%Y-%m-%d"))
    audit_period = data.get("audit_period", "2025")
    org_type = data.get("basic_info", {}).get("org_type", "—")

    # 评分数据
    scores = data.get("scores", {})
    total_score = scores.get("total_score", 0)

    disclosure_raw = scores.get("disclosure_raw", 0)
    disclosure_weighted = scores.get("disclosure_weighted", 0)
    governance_score = scores.get("governance_score", 0)
    governance_weighted = scores.get("governance_weighted", 0)
    finance_score = scores.get("finance_score", 0)
    finance_weighted = scores.get("finance_weighted", 0)
    project_score = scores.get("project_score", 0)
    project_weighted = scores.get("project_weighted", 0)
    opinion_score = scores.get("opinion_score", 0)
    opinion_weighted = scores.get("opinion_weighted", 0)
    opinion_raw = scores.get("opinion_raw", 0)
    timeliness_deduction = scores.get("timeliness_deduction", 0)
    subtotal = scores.get("subtotal", 0)

    # 渠道评分
    channels = data.get("channel_scores", {})
    cszg_score = channels.get("cszg_score", 0)
    website_score = channels.get("website_score", 0)
    wechat_score = channels.get("wechat_score", 0)

    # 等级
    grade, grade_color, grade_bg = get_grade_info(total_score)
    ring_color = get_ring_color(total_score)
    ring_offset = calc_ring_offset(total_score)

    # 舆情
    opinion_data = data.get("opinion", {})

    # 替换模板变量
    html = template
    replacements = {
        "{{FOUNDATION_NAME}}": name,
        "{{AUDIT_DATE}}": audit_date,
        "{{AUDIT_PERIOD}}": audit_period,
        "{{ORG_TYPE}}": org_type,
        "{{TOTAL_SCORE}}": str(total_score),
        "{{RING_COLOR}}": ring_color,
        "{{RING_OFFSET}}": str(ring_offset),
        "{{GRADE}}": grade,
        "{{GRADE_BG}}": grade_bg,
        "{{GRADE_COLOR}}": grade_color,
        "{{DISCLOSURE_SCORE}}": str(disclosure_raw),
        "{{DISCLOSURE_RAW}}": str(disclosure_raw),
        "{{DISCLOSURE_WEIGHTED}}": f"{disclosure_weighted:.1f}",
        "{{DISCLOSURE_PCT}}": str(disclosure_raw),
        "{{GOVERNANCE_SCORE}}": str(governance_score),
        "{{GOVERNANCE_WEIGHTED}}": f"{governance_weighted:.1f}",
        "{{GOVERNANCE_PCT}}": str(governance_score),
        "{{FINANCE_SCORE}}": str(finance_score),
        "{{FINANCE_WEIGHTED}}": f"{finance_weighted:.1f}",
        "{{FINANCE_PCT}}": str(finance_score),
        "{{PROJECT_SCORE}}": str(project_score),
        "{{PROJECT_WEIGHTED}}": f"{project_weighted:.1f}",
        "{{PROJECT_PCT}}": str(project_score),
        "{{OPINION_SCORE}}": str(opinion_score),
        "{{OPINION_RAW}}": str(opinion_raw),
        "{{OPINION_WEIGHTED}}": f"{opinion_weighted:.1f}",
        "{{OPINION_PCT}}": str(min(max(opinion_score, 0), 100)),
        "{{TIMELINESS_DEDUCTION}}": str(timeliness_deduction),
        "{{SUBTOTAL}}": f"{subtotal:.1f}",
        "{{CSZG_SCORE}}": str(cszg_score),
        "{{CSZG_PCT}}": str(cszg_score),
        "{{CSZG_WEIGHTED}}": f"{cszg_score * 0.5:.1f}",
        "{{WEBSITE_SCORE}}": str(website_score),
        "{{WEBSITE_PCT}}": str(website_score),
        "{{WEBSITE_WEIGHTED}}": f"{website_score * 0.3:.1f}",
        "{{WECHAT_SCORE}}": str(wechat_score),
        "{{WECHAT_PCT}}": str(wechat_score),
        "{{WECHAT_WEIGHTED}}": f"{wechat_score * 0.2:.1f}",
        "{{SEARCH_DATE}}": audit_date,
        "{{DATA_SOURCES}}": f"慈善中国({audit_date}) + 官方网站({audit_date}) + 微信公众号({audit_date}) + 百度舆情检索({audit_date})",
        # 动态生成的内容
        "{{BASIC_INFO_ROWS}}": generate_basic_info_rows(data),
        "{{CSZG_DETAIL_ROWS}}": generate_channel_detail_rows(channels.get("cszg_details", [])),
        "{{WEBSITE_DETAIL_ROWS}}": generate_channel_detail_rows(channels.get("website_details", [])),
        "{{WECHAT_DETAIL_ROWS}}": generate_channel_detail_rows(channels.get("wechat_details", [])),
        "{{GOVERNANCE_ROWS}}": generate_governance_rows(data.get("governance", [])),
        "{{FINANCE_METRIC_ROWS}}": generate_finance_metric_rows(data.get("finance_metrics", [])),
        "{{TIMELINESS_ROWS}}": generate_timeliness_rows(data.get("timeliness", [])),
        "{{NEGATIVE_EVENTS_HTML}}": generate_negative_events_html(opinion_data.get("negative_events", [])),
        "{{NEG_COUNT}}": str(opinion_data.get("total_negative_count", 0)),
        "{{NEG_A}}": str(opinion_data.get("level_a_count", 0)),
        "{{NEG_B}}": str(opinion_data.get("level_b_count", 0)),
        "{{NEG_C}}": str(opinion_data.get("level_c_count", 0)),
        "{{NEG_DEDUCTION}}": str(opinion_data.get("total_deduction", 0)),
        "{{POS_BONUS}}": str(opinion_data.get("total_bonus", 0)),
        "{{NET_OPINION}}": str(opinion_data.get("net_score", 0)),
        "{{RISK_LEVEL}}": opinion_data.get("risk_level_display", "🟢 低风险"),
        "{{PROJECT_ROWS}}": generate_project_rows(data.get("project", [])),
        "{{HIGH_PRIORITY_ITEMS}}": generate_improvement_items(data.get("improvements", {}).get("high", []), "high"),
        "{{MEDIUM_PRIORITY_ITEMS}}": generate_improvement_items(data.get("improvements", {}).get("medium", []), "medium"),
        "{{LOW_PRIORITY_ITEMS}}": generate_improvement_items(data.get("improvements", {}).get("low", []), "low"),
    }

    for key, value in replacements.items():
        html = html.replace(key, str(value))

    return html


def main():
    parser = argparse.ArgumentParser(
        description="基金会透明审计 HTML 报告生成器 v2.0"
    )
    parser.add_argument("input_json", help="审计数据 JSON 文件路径")
    parser.add_argument("--output", "-o", help="输出 HTML 文件路径", default=None)

    args = parser.parse_args()

    # 读取数据
    with open(args.input_json, "r", encoding="utf-8") as f:
        data = json.load(f)

    # 生成报告
    html = generate_html_report(data)

    # 输出
    if args.output:
        output_path = args.output
    else:
        base_name = Path(args.input_json).stem
        output_path = f"{base_name}_report.html"

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)

    print(f"[OK] Report generated: {output_path}")
    return output_path


if __name__ == "__main__":
    main()
