#!/usr/bin/env python3
"""
基金会财务指标核算工具 v1.0.4
Foundation Financial Metrics Calculator

依据《关于慈善组织开展慈善活动年度支出、管理费用和募捐成本的规定》
（民政部/财政部/税务总局，2026年4月27日发布施行）

v1.0.4 更新：
  - 修正非公募基金会净资产分层标准（基金会：≥6000万/800-6000万/400-800万/<400万）
  - 修正公益支出基准（公募：上年总收入×70%；非公募：上年末净资产×分层比例）
  - 新增募捐成本3%上限核查（年度募捐成本 ≤ 前三年捐赠收入平均数×3%）
  - 新增募捐成本口径检查（本组织场地设备和工作人员费用不得计入）
  - 新增年管理费用20万豁免线检查
"""

import sys
from typing import Optional, List


# ==================== 分层标准常量 ====================

# 非公募基金会净资产分层（第九条）
NONPROFIT_FOUNDATION_TIERS = [
    # (净资产下限, 净资产上限(含), 公益支出最低比例%, 管理费用最高比例%)
    (6000_0000, float('inf'), 6, 12),     # ≥6000万
    (800_0000,  6000_0000,   6, 13),      # 800万~6000万
    (400_0000,  800_0000,    7, 15),      # 400万~800万
    (0,         400_0000,    8, 20),      # <400万
]

# 非公募社会团体/社会服务机构净资产分层（第十条）
NONPROFIT_ASSOCIATION_TIERS = [
    # (净资产下限, 净资产上限(含), 公益支出最低比例%, 管理费用最高比例%)
    (1000_0000, float('inf'), 6, 13),     # ≥1000万
    (500_0000,  1000_0000,   7, 14),      # 500万~1000万
    (100_0000,  500_0000,    8, 15),      # 100万~500万
    (0,         100_0000,    8, 20),      # <100万（且须≥上年总收入50%）
]

# 公募组织标准（第八条）
PUBLIC_WELFARE_RATIO = 70       # 公募：年度慈善活动支出 ≥ 上年总收入70%
PUBLIC_FOUNDATION_ADMIN_RATIO = 10   # 公募基金会管理费 ≤ 10%
PUBLIC_ASSOC_ADMIN_RATIO = 13        # 公募社会团体/服务机构管理费 ≤ 13%

# 募捐成本上限（第十五条）
FUNDRAISING_COST_RATIO = 3      # 年度募捐成本 ≤ 前三年捐赠收入平均数 × 3%

# 管理费用绝对金额豁免线（第十三条）
ADMIN_EXPENSE_EXEMPT = 20_0000  # 年管理费用 < 20万元则不受比例限制


# ==================== 工具函数 ====================

def get_nonprofit_foundation_tier(net_assets: float) -> dict:
    """获取非公募基金会适用的净资产分档标准（第九条）"""
    for low, high, welfare_pct, admin_pct in NONPROFIT_FOUNDATION_TIERS:
        if low <= net_assets < high or (low == 0 and net_assets < high):
            if high == float('inf'):
                tier_label = f"净资产≥{low/10000:.0f}万"
            elif low == 0:
                tier_label = f"净资产<{high/10000:.0f}万"
            else:
                tier_label = f"净资产{low/10000:.0f}万~{high/10000:.0f}万"
            return {
                "tier_label": tier_label,
                "welfare_min_pct": welfare_pct,
                "admin_max_pct": admin_pct,
            }
    return {"tier_label": "未知", "welfare_min_pct": 8, "admin_max_pct": 20}


def get_nonprofit_association_tier(net_assets: float) -> dict:
    """获取非公募社会团体/服务机构适用的净资产分档标准（第十条）"""
    for low, high, welfare_pct, admin_pct in NONPROFIT_ASSOCIATION_TIERS:
        if low <= net_assets < high or (low == 0 and net_assets < high):
            if high == float('inf'):
                tier_label = f"净资产≥{low/10000:.0f}万"
            elif low == 0:
                tier_label = f"净资产<{high/10000:.0f}万"
            else:
                tier_label = f"净资产{low/10000:.0f}万~{high/10000:.0f}万"
            return {
                "tier_label": tier_label,
                "welfare_min_pct": welfare_pct,
                "admin_max_pct": admin_pct,
            }
    return {"tier_label": "未知", "welfare_min_pct": 8, "admin_max_pct": 20}


# ==================== 指标核算函数 ====================

def calculate_public_welfare_ratio(
    charity_expenditure: float,
    prev_year_total_income: float,
    org_type: str = "public_foundation"
) -> dict:
    """
    计算公募基金会/社会团体/服务机构的年度慈善活动支出比例（第八条）
    
    公式: 年度慈善活动支出 ÷ 上年总收入 × 100%
    要求: ≥ 70%
    
    org_type: "public_foundation" 公募基金会
              "public_association" 公募社会团体/服务机构
    """
    if prev_year_total_income == 0:
        return {"ratio": None, "status": "error", "message": "上年总收入为零，无法计算"}
    
    ratio = (charity_expenditure / prev_year_total_income) * 100
    threshold = PUBLIC_WELFARE_RATIO  # 70%
    
    status = "pass" if ratio >= threshold else "fail"
    type_label = "公募基金会" if org_type == "public_foundation" else "公募社会团体/服务机构"
    
    return {
        "ratio": round(ratio, 2),
        "charity_expenditure": charity_expenditure,
        "prev_year_total_income": prev_year_total_income,
        "org_type": type_label,
        "status": status,
        "requirement": f"≥{threshold}%（上年总收入）",
        "regulation": "2026年新规第八条",
        "message": f"慈善活动支出比例({type_label}): {ratio:.2f}% (要求≥{threshold}%)"
    }


def calculate_nonprofit_foundation_welfare(
    charity_expenditure: float,
    prev_year_net_assets: float,
    prev_year_total_income: float = 0
) -> dict:
    """
    计算非公募基金会年度慈善活动支出比例（第九条，净资产分层）
    
    公式: 年度慈善活动支出 ÷ 上年末净资产 × 100%
    阈值: 按净资产分层
    注: 也可用前三年平均净资产代替上年末净资产（第十一条）
    """
    if prev_year_net_assets == 0:
        return {"ratio": None, "status": "error", "message": "上年末净资产为零，无法计算"}
    
    tier = get_nonprofit_foundation_tier(prev_year_net_assets)
    threshold = tier["welfare_min_pct"]
    ratio = (charity_expenditure / prev_year_net_assets) * 100
    
    status = "pass" if ratio >= threshold else "fail"
    
    result = {
        "ratio": round(ratio, 2),
        "charity_expenditure": charity_expenditure,
        "prev_year_net_assets": prev_year_net_assets,
        "tier": tier["tier_label"],
        "status": status,
        "requirement": f"≥{threshold}%（上年末净资产）",
        "regulation": "2026年新规第九条",
        "message": f"慈善活动支出比例(非公募基金会/{tier['tier_label']}): {ratio:.2f}% (要求≥{threshold}%)"
    }
    
    # 最低档额外要求：<100万净资产时还需≥上年总收入50%
    if prev_year_net_assets < 100_0000 and prev_year_total_income > 0:
        income_ratio = (charity_expenditure / prev_year_total_income) * 100
        result["income_ratio"] = round(income_ratio, 2)
        result["income_ratio_requirement"] = "≥50%（上年总收入）"
        if income_ratio < 50:
            result["status"] = "fail"
            result["message"] += f"；另：慈善活动支出/上年总收入={income_ratio:.2f}%，未达50%要求"
    
    return result


def calculate_admin_ratio(
    admin_expense: float,
    total_expense: float,
    org_type: str = "public_foundation",
    prev_year_net_assets: float = 0
) -> dict:
    """
    计算管理费用比例（第八条/第九条/第十条）
    
    公式: 管理费用 ÷ 当年总支出 × 100%
    阈值: 按组织类型和净资产档位
    
    org_type: "public_foundation"       公募基金会 ≤10%
              "public_association"      公募社会团体/服务机构 ≤13%
              "nonprofit_foundation"    非公募基金会（按净资产分层）
              "nonprofit_association"   非公募社会团体/服务机构（按净资产分层）
    """
    # 绝对金额豁免（第十三条）
    exempt_note = None
    if admin_expense < ADMIN_EXPENSE_EXEMPT:
        exempt_note = f"年管理费用{admin_expense/10000:.1f}万元 < 豁免线20万元，不受比例限制"
    
    if total_expense == 0:
        return {"ratio": None, "status": "error", "message": "总支出为零，无法计算"}
    
    ratio = (admin_expense / total_expense) * 100
    
    if org_type == "public_foundation":
        threshold = PUBLIC_FOUNDATION_ADMIN_RATIO
        tier_label = "公募基金会"
        regulation = "2026年新规第八条"
    elif org_type == "public_association":
        threshold = PUBLIC_ASSOC_ADMIN_RATIO
        tier_label = "公募社会团体/服务机构"
        regulation = "2026年新规第八条"
    elif org_type == "nonprofit_foundation":
        tier = get_nonprofit_foundation_tier(prev_year_net_assets)
        threshold = tier["admin_max_pct"]
        tier_label = f"非公募基金会/{tier['tier_label']}"
        regulation = "2026年新规第九条"
    else:  # nonprofit_association
        tier = get_nonprofit_association_tier(prev_year_net_assets)
        threshold = tier["admin_max_pct"]
        tier_label = f"非公募社会团体/服务机构/{tier['tier_label']}"
        regulation = "2026年新规第十条"
    
    if exempt_note:
        status = "exempt"
        message = f"管理费用比例({tier_label}): {ratio:.2f}% — {exempt_note}"
    else:
        status = "pass" if ratio <= threshold else "fail"
        message = f"管理费用比例({tier_label}): {ratio:.2f}% (要求≤{threshold}%)"
    
    return {
        "ratio": round(ratio, 2),
        "admin_expense": admin_expense,
        "total_expense": total_expense,
        "tier_label": tier_label,
        "status": status,
        "requirement": f"≤{threshold}%" if not exempt_note else "豁免（<20万元）",
        "regulation": regulation,
        "exempt_note": exempt_note,
        "message": message
    }


def calculate_fundraising_cost_ratio(
    annual_fundraising_cost: float,
    donation_income_year1: float,
    donation_income_year2: float = 0,
    donation_income_year3: float = 0
) -> dict:
    """
    计算年度募捐成本比例（2026年新规第十五条）
    
    公式: 年度募捐成本 ÷ 前三年捐赠收入平均数 × 100%
    要求: ≤ 3%
    注意: 本组织场地设备和工作人员的相关费用不得计入募捐成本（第六条）
    
    若只有当年捐赠收入，传入 donation_income_year1 即可（前三年均用此数代替）
    """
    years_provided = sum(1 for x in [donation_income_year1, donation_income_year2, donation_income_year3] if x > 0)
    
    if years_provided == 0:
        return {"ratio": None, "status": "error", "message": "捐赠收入为零，无法计算"}
    
    if donation_income_year2 == 0 and donation_income_year3 == 0:
        avg_donation = donation_income_year1
        avg_note = "仅提供当年捐赠收入（建议补充前三年数据）"
    elif donation_income_year3 == 0:
        avg_donation = (donation_income_year1 + donation_income_year2) / 2
        avg_note = "使用两年平均值"
    else:
        avg_donation = (donation_income_year1 + donation_income_year2 + donation_income_year3) / 3
        avg_note = "使用前三年平均值"
    
    if avg_donation == 0:
        return {"ratio": None, "status": "error", "message": "前三年捐赠收入平均数为零，无法计算"}
    
    ratio = (annual_fundraising_cost / avg_donation) * 100
    threshold = FUNDRAISING_COST_RATIO  # 3%
    
    status = "pass" if ratio <= threshold else "fail"
    
    return {
        "ratio": round(ratio, 2),
        "annual_fundraising_cost": annual_fundraising_cost,
        "avg_donation_3yr": round(avg_donation, 2),
        "avg_note": avg_note,
        "status": status,
        "requirement": f"≤{threshold}%（前三年捐赠收入平均数）",
        "regulation": "2026年新规第十五条",
        "cost_scope_note": "⚠️ 注意：本组织场地设备和工作人员相关费用不得计入募捐成本（第六条）",
        "message": f"募捐成本比例: {ratio:.2f}% (要求≤{threshold}%，{avg_note})"
    }


def calculate_staff_ratio(
    staff_expense: float,
    admin_expense: float
) -> dict:
    """
    计算人员费用占管理费用比例
    异常阈值: >60%
    """
    if admin_expense == 0:
        return {"ratio": None, "status": "error", "message": "管理费用为零，无法计算"}
    
    ratio = (staff_expense / admin_expense) * 100
    status = "pass" if ratio <= 60 else ("warning" if ratio <= 80 else "fail")
    
    return {
        "ratio": round(ratio, 2),
        "staff_expense": staff_expense,
        "admin_expense": admin_expense,
        "status": status,
        "requirement": "≤60%（参考）",
        "message": f"人员费用占管理费用比例: {ratio:.2f}% (建议≤60%)"
    }


def calculate_debt_ratio(
    total_liabilities: float,
    total_assets: float
) -> dict:
    """计算资产负债率，正常范围: 30%-70%"""
    if total_assets == 0:
        return {"ratio": None, "status": "error", "message": "总资产为零，无法计算"}
    
    ratio = (total_liabilities / total_assets) * 100
    
    if 30 <= ratio <= 70:
        status = "pass"
    elif 70 < ratio <= 80:
        status = "warning"
    else:
        status = "fail"
    
    return {
        "ratio": round(ratio, 2),
        "total_liabilities": total_liabilities,
        "total_assets": total_assets,
        "status": status,
        "requirement": "30%-70%",
        "message": f"资产负债率: {ratio:.2f}% (正常范围30%-70%)"
    }


def comprehensive_audit(
    foundation_name: str,
    org_type: str,
    prev_year_net_assets: float,
    charity_expenditure: float,
    prev_year_total_income: float,
    admin_expense: float,
    total_expense: float,
    fundraising_cost: float = 0,
    donation_income_year1: float = 0,
    donation_income_year2: float = 0,
    donation_income_year3: float = 0,
    staff_expense: float = 0,
    total_liabilities: float = 0,
    total_assets: float = 0
) -> dict:
    """
    综合财务审计（依据2026年新规）
    
    Args:
        foundation_name:        基金会/组织名称
        org_type:               组织类型
                                "public_foundation"      公募基金会
                                "public_association"     公募社会团体/服务机构
                                "nonprofit_foundation"   非公募基金会
                                "nonprofit_association"  非公募社会团体/服务机构
        prev_year_net_assets:   上年末净资产（非公募分层用）
        charity_expenditure:    年度慈善活动支出
        prev_year_total_income: 上年总收入（公募基金会基准）
        admin_expense:          年度管理费用
        total_expense:          当年总支出
        fundraising_cost:       年度募捐成本
        donation_income_year1:  当年/最近一年捐赠收入
        donation_income_year2:  前一年捐赠收入（可选）
        donation_income_year3:  前两年捐赠收入（可选）
        staff_expense:          人员费用（可选）
        total_liabilities:      总负债（可选）
        total_assets:           总资产（可选）
    """
    org_labels = {
        "public_foundation": "公募基金会",
        "public_association": "公募社会团体/服务机构",
        "nonprofit_foundation": "非公募基金会",
        "nonprofit_association": "非公募社会团体/服务机构",
    }
    
    results = {
        "foundation_name": foundation_name,
        "org_type": org_labels.get(org_type, org_type),
        "regulation_basis": "《关于慈善组织开展慈善活动年度支出、管理费用和募捐成本的规定》（2026）",
        "metrics": {},
        "summary": {}
    }
    
    # 慈善活动支出比例
    if org_type in ("public_foundation", "public_association"):
        welfare_result = calculate_public_welfare_ratio(
            charity_expenditure, prev_year_total_income, org_type
        )
    elif org_type == "nonprofit_foundation":
        welfare_result = calculate_nonprofit_foundation_welfare(
            charity_expenditure, prev_year_net_assets, prev_year_total_income
        )
    else:  # nonprofit_association — 复用基金会逻辑，按第十条分层
        tier = get_nonprofit_association_tier(prev_year_net_assets)
        if prev_year_net_assets == 0:
            welfare_result = {"ratio": None, "status": "error", "message": "净资产为零"}
        else:
            ratio = (charity_expenditure / prev_year_net_assets) * 100
            threshold = tier["welfare_min_pct"]
            status = "pass" if ratio >= threshold else "fail"
            welfare_result = {
                "ratio": round(ratio, 2), "status": status,
                "requirement": f"≥{threshold}%（上年末净资产）",
                "regulation": "2026年新规第十条",
                "tier": tier["tier_label"],
                "message": f"慈善活动支出比例(非公募社会团体/{tier['tier_label']}): {ratio:.2f}% (要求≥{threshold}%)"
            }
    results["metrics"]["慈善活动支出比例"] = welfare_result
    
    # 管理费用比例
    admin_result = calculate_admin_ratio(
        admin_expense, total_expense, org_type, prev_year_net_assets
    )
    results["metrics"]["管理费用比例"] = admin_result
    
    # 募捐成本比例（2026年新规核心指标）
    if fundraising_cost > 0 or donation_income_year1 > 0:
        fundraising_result = calculate_fundraising_cost_ratio(
            fundraising_cost, donation_income_year1,
            donation_income_year2, donation_income_year3
        )
        results["metrics"]["募捐成本比例（新规）"] = fundraising_result
    
    # 人员费用比例
    if staff_expense > 0 and admin_expense > 0:
        results["metrics"]["人员费用比例"] = calculate_staff_ratio(staff_expense, admin_expense)
    
    # 资产负债率
    if total_assets > 0:
        results["metrics"]["资产负债率"] = calculate_debt_ratio(total_liabilities, total_assets)
    
    # 综合评定
    fail_count = sum(1 for m in results["metrics"].values() if m.get("status") == "fail")
    warning_count = sum(1 for m in results["metrics"].values() if m.get("status") == "warning")
    total_count = len(results["metrics"])
    
    if fail_count > 0:
        overall = "不合格（有违规项）"
    elif warning_count > 0:
        overall = "需关注（有预警项）"
    else:
        overall = "合格"
    
    results["summary"] = {
        "total_metrics": total_count,
        "fail_count": fail_count,
        "warning_count": warning_count,
        "pass_count": total_count - fail_count - warning_count,
        "overall": overall
    }
    
    return results


def print_report(results: dict):
    """打印审计报告"""
    print("=" * 70)
    print(f"基金会财务合规审计报告（依据2026年三部门新规）")
    print(f"组织名称: {results['foundation_name']}")
    print(f"组织类型: {results['org_type']}")
    print(f"法规依据: {results.get('regulation_basis', '')}")
    print("=" * 70)
    print("\n【财务指标核算结果】")
    print("-" * 70)
    
    for metric_name, metric_data in results["metrics"].items():
        status_map = {
            "pass": "✓ 合规",
            "warning": "⚠ 关注",
            "fail": "✗ 违规",
            "error": "❌ 错误",
            "exempt": "○ 豁免"
        }
        status_icon = status_map.get(metric_data.get("status", ""), "?")
        print(f"\n{metric_name}: {status_icon}")
        if metric_data.get("ratio") is not None:
            print(f"  计算值: {metric_data['ratio']}%")
        if "requirement" in metric_data:
            print(f"  法规要求: {metric_data['requirement']}")
        if "regulation" in metric_data:
            print(f"  依据: {metric_data['regulation']}")
        if "cost_scope_note" in metric_data:
            print(f"  {metric_data['cost_scope_note']}")
        if "exempt_note" in metric_data and metric_data["exempt_note"]:
            print(f"  豁免说明: {metric_data['exempt_note']}")
        print(f"  结论: {metric_data.get('message', '')}")
    
    print("\n" + "=" * 70)
    print("【综合评定】")
    print(f"  检测指标数: {results['summary']['total_metrics']}")
    print(f"  合规项: {results['summary']['pass_count']}")
    print(f"  关注项: {results['summary']['warning_count']}")
    print(f"  违规项: {results['summary']['fail_count']}")
    print(f"  综合评定: {results['summary']['overall']}")
    print("=" * 70)


if __name__ == "__main__":
    # 示例1: 公募基金会
    print("\n===== 示例1：公募基金会 =====")
    sample1 = comprehensive_audit(
        foundation_name="示例公募基金会",
        org_type="public_foundation",
        prev_year_net_assets=5000_0000,
        charity_expenditure=800_0000,
        prev_year_total_income=1000_0000,
        admin_expense=90_0000,
        total_expense=1000_0000,
        fundraising_cost=25_0000,
        donation_income_year1=1000_0000,
        donation_income_year2=900_0000,
        donation_income_year3=800_0000,
        staff_expense=50_0000,
        total_liabilities=300_0000,
        total_assets=5800_0000
    )
    print_report(sample1)
    
    # 示例2: 非公募基金会（净资产1000万档）
    print("\n===== 示例2：非公募基金会（净资产1000万） =====")
    sample2 = comprehensive_audit(
        foundation_name="示例非公募基金会",
        org_type="nonprofit_foundation",
        prev_year_net_assets=1000_0000,
        charity_expenditure=65_0000,
        prev_year_total_income=200_0000,
        admin_expense=28_0000,
        total_expense=100_0000,
        fundraising_cost=0,
        donation_income_year1=200_0000,
    )
    print_report(sample2)


