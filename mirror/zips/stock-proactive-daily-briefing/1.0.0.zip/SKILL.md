---
name: proactive-daily-briefing
description: 面向 OpenClaw 的主动日报 skill，用于把用户的模糊需求转成每日例行分析、候选股、执行计划和下一步建议。
---

# 主动日报推进

当用户表达以下意图时，使用这个 skill：

- “帮我看今天该关注什么”
- “每天给我一个可执行的股票摘要”
- “不要只回答，直接给我今天的行动建议”
- “帮我形成日常盯盘/复盘流程”

## 设计目标

这个 skill 不是只回答“今天有哪些股票”，而是把用户需求推进成一个完整的每日价值交付：

1. 先生成候选和价位
2. 再输出结构化日报
3. 再告诉用户今天真正要做的动作
4. 最后指出还缺什么自动化能力

## 主动工作流程

### 1. 先判断是否已有最新日报

优先检查这些文件是否存在且内容可用：

- `a_share_daily_report_latest.md`
- `a_share_agent_top5.csv`
- `a_share_agent_execution_plan.csv`

如果这些文件不存在、明显过旧，或用户明确要求重跑，则生成新的日报包。

### 2. 生成完整日报包

Windows：

```powershell
d:/pythonfile/uderestimate/.venv/Scripts/python.exe d:/pythonfile/uderestimate/generate_daily_report.py
```

Linux：

```bash
./.venv/bin/python ./generate_daily_report.py
```

### 3. 主动输出而不是等待追问

完成后不要只说“已生成报告”，而应主动给出：

- 今日 5 只候选股中最值得先看的一到两只
- 哪些票更适合突破买入，哪些更适合回踩买入
- 哪些票的风险回报比更优
- 如果用户今天只能执行一单，优先该看哪只

### 4. 自动补上下一步建议

如果用户没有明确提出下一步，也应主动补充一个最小动作建议，例如：

- “是否需要我继续把这 5 只缩成 2 只主盯标的”
- “是否需要我把今天的挂单区间整理成更易执行的清单”
- “是否需要我给出尾盘版或次日版交易摘要”

## 约束

1. 除非用户明确要求刷新数据，否则优先使用缓存评分。
2. 行情失败时保留 fallback，不要终止全流程。
3. 输出应聚焦行动价值，不要只复述文件存在。
4. 如果当前结果只是本地文件，不要说成“已经推送”。

## 输出要求

至少说明：

- 使用的是缓存还是刷新数据
- 报告文件路径
- 执行计划是否使用 fallback
- 今日最值得优先执行的候选股

## 与现有脚本的关系

- 选股和执行计划基础能力来自 `generate_daily_report.py`
- 详细执行价位来自 `trade_execution_plan.py`
- 手工条件单来自 `manual_order_ticket.py`
