---
name: MemWatch
description: "Monitor RAM usage in real time and alert on high memory consumption thresholds. Use when tracking memory, identifying RAM hogs, setting alert thresholds."
version: "2.0.0"
author: "BytesAgain"
homepage: https://bytesagain.com
source: https://github.com/bytesagain/ai-skills
tags: ["memory","ram","monitor","system","process","swap","admin","performance"]
categories: ["System Tools", "Developer Tools"]
---

# MemWatch

System operations toolkit for logging, tracking, and auditing infrastructure events. Record scan results, monitor statuses, alerts, benchmarks, and more — all stored locally as timestamped log files with full export and search capabilities.

## Commands

All commands are invoked via `memwatch <command> [args]`.

### Core Logging Commands

Each of these commands works the same way: called without arguments it shows the 20 most recent entries; called with arguments it saves a new timestamped entry.

| Command | Description |
|---------|-------------|
| `scan <input>` | Log a scan result (e.g. port scan, vulnerability scan, disk scan) |
| `monitor <input>` | Log a monitoring observation (service health, uptime check, etc.) |
| `report <input>` | Log a report entry (incident report, status report, audit note) |
| `alert <input>` | Log an alert (threshold breach, warning, critical event) |
| `top <input>` | Log a top-process snapshot or resource peak |
| `usage <input>` | Log resource usage data (CPU, memory, disk, bandwidth) |
| `check <input>` | Log a health check result |
| `fix <input>` | Log a fix or remediation action taken |
| `cleanup <input>` | Log a cleanup operation (temp files, old logs, cache purge) |
| `backup <input>` | Log a backup event (what was backed up, where, size) |
| `restore <input>` | Log a restore operation |
| `log <input>` | General-purpose log entry |
| `benchmark <input>` | Log a benchmark result (performance test, load test) |
| `compare <input>` | Log a comparison (before/after, A/B test, config diff) |

### Utility Commands

| Command | Description |
|---------|-------------|
| `stats` | Summary statistics — entry counts per category, total entries, data size, earliest record |
| `export <fmt>` | Export all data in `json`, `csv`, or `txt` format |
| `search <term>` | Search across all log files for a keyword (case-insensitive) |
| `recent` | Show the 20 most recent entries from the activity history |
| `status` | Health check — version, data directory, total entries, disk usage, last activity |
| `help` | Show the built-in help message |
| `version` | Print version string (`memwatch v2.0.0`) |

## Data Storage

- **Location:** `~/.local/share/memwatch/`
- **Format:** Each command category has its own `.log` file (e.g. `scan.log`, `alert.log`, `backup.log`)
- **History:** All activity is also appended to `history.log` with timestamps
- **Exports:** Generated export files are saved to the same data directory as `export.json`, `export.csv`, or `export.txt`
- **Entry format:** Each log line is `YYYY-MM-DD HH:MM|<value>`

## Requirements

- Bash 4+
- Standard Unix utilities (`date`, `wc`, `du`, `head`, `tail`, `grep`, `basename`, `cat`)
- No external dependencies, no API keys, no network access needed

## When to Use

1. **Infrastructure auditing** — Log scan results, health checks, and monitoring observations to build an audit trail of system events over time
2. **Incident tracking** — Record alerts, fixes, and reports during an incident so you have a timestamped timeline of what happened and what was done
3. **Backup & restore documentation** — Keep a running log of backup and restore operations with details about what was backed up, sizes, and destinations
4. **Performance benchmarking** — Log benchmark results and comparisons across different configurations or time periods, then export for analysis
5. **Operational housekeeping** — Track cleanup operations, usage patterns, and resource consumption to identify trends and plan capacity

## Examples

```bash
# Log a scan result
memwatch scan "Port scan complete: 3 open ports on 192.168.1.1"

# View recent scan entries (no args = show last 20)
memwatch scan

# Log an alert
memwatch alert "Disk usage at 92% on /dev/sda1"

# Log a backup event
memwatch backup "Full backup to s3://mybackups — 12GB, took 8m"

# Log a benchmark result
memwatch benchmark "nginx throughput: 14,200 req/s with 4 workers"

# Search across all logs
memwatch search "disk"

# Show summary statistics
memwatch stats

# Export everything to JSON
memwatch export json

# Export to CSV for spreadsheet analysis
memwatch export csv

# Check overall status
memwatch status

# View 20 most recent activities
memwatch recent
```

## Output

All command output goes to stdout. Redirect to save:

```bash
memwatch stats > report.txt
memwatch export json   # saves to ~/.local/share/memwatch/export.json
```

## Configuration

No configuration file needed. Data directory is fixed at `~/.local/share/memwatch/`.

---

*Powered by BytesAgain | bytesagain.com | hello@bytesagain.com*
