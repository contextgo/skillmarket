/**
 * openclaw-cli-bridge-elvatis — index.ts
 *
 * Phase 1 (auth bridge): registers openai-codex provider using tokens from
 *   ~/.codex/auth.json (Codex CLI is already logged in — no re-login needed).
 *
 * Phase 2 (request bridge): starts a local OpenAI-compatible HTTP proxy server
 *   and configures OpenClaw's vllm provider to route through it. Model calls
 *   are routed to CLI tools or browser-session providers.
 *
 * Phase 3 (slash commands): registers /cli-* commands for instant model switching.
 *   /cli-sonnet       → vllm/cli-claude/claude-sonnet-4-6      (Claude Code CLI proxy)
 *   /cli-opus         → vllm/cli-claude/claude-opus-4-6        (Claude Code CLI proxy)
 *   /cli-haiku        → vllm/cli-claude/claude-haiku-4-5       (Claude Code CLI proxy)
 *   /cli-gemini       → vllm/cli-gemini/gemini-2.5-pro         (Gemini CLI proxy)
 *   /cli-gemini-flash → vllm/cli-gemini/gemini-2.5-flash       (Gemini CLI proxy)
 *   /cli-gemini3      → vllm/cli-gemini/gemini-3-pro-preview   (Gemini CLI proxy)
 *   /cli-codex        → openai-codex/gpt-5.3-codex             (Codex CLI OAuth, direct API)
 *   /cli-codex54      → openai-codex/gpt-5.4                   (Codex CLI OAuth, direct API)
 *   /cli-back         → restore model that was active before last /cli-* switch
 *   /cli-test [model] → one-shot proxy health check (does NOT switch global model)
 *   /cli-list         → list all registered CLI bridge models with commands
 *
 * Provider / model naming:
 *   vllm/cli-gemini/gemini-2.5-pro  → `gemini -m gemini-2.5-pro @<tmpfile>`
 *   vllm/cli-claude/claude-opus-4-6 → `claude -p -m claude-opus-4-6 --output-format text` (stdin)
 */

import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";
import http from "node:http";
import type {
  OpenClawPluginApi,
  ProviderAuthContext,
  ProviderAuthResult,
} from "openclaw/plugin-sdk";

// OpenClawPluginCommandDefinition is defined in the SDK types but not re-exported
// by the package — derive it from the registerCommand signature.
type OpenClawPluginCommandDefinition = Parameters<OpenClawPluginApi["registerCommand"]>[0];
import { buildOauthProviderAuthResult } from "openclaw/plugin-sdk";
import {
  DEFAULT_CODEX_AUTH_PATH,
  DEFAULT_MODEL as CODEX_DEFAULT_MODEL,
  readCodexCredentials,
} from "./src/codex-auth.js";
import { startProxyServer } from "./src/proxy-server.js";
import { patchOpencllawConfig } from "./src/config-patcher.js";
import {
  loadSession,
  deleteSession,
  isSessionExpiredByAge,
  verifySession,
  runInteractiveLogin,
  createContextFromSession,
  DEFAULT_SESSION_PATH,
} from "./src/grok-session.js";
import type { BrowserContext, Browser } from "playwright";

// ──────────────────────────────────────────────────────────────────────────────
// Types derived from SDK (not re-exported by the package)
// ──────────────────────────────────────────────────────────────────────────────
type RegisterCommandParam = Parameters<OpenClawPluginApi["registerCommand"]>[0];
type PluginCommandContext = Parameters<RegisterCommandParam["handler"]>[0];
type PluginCommandResult = Awaited<ReturnType<RegisterCommandParam["handler"]>>;

// ──────────────────────────────────────────────────────────────────────────────
// Plugin config type
// ──────────────────────────────────────────────────────────────────────────────
interface CliPluginConfig {
  codexAuthPath?: string;
  enableCodex?: boolean;
  enableProxy?: boolean;
  proxyPort?: number;
  proxyApiKey?: string;
  proxyTimeoutMs?: number;
  grokSessionPath?: string;
}

// ──────────────────────────────────────────────────────────────────────────────
// Grok web-session state (module-level, persists across commands)
// ──────────────────────────────────────────────────────────────────────────────

let grokBrowser: Browser | null = null;
let grokContext: BrowserContext | null = null;

// Persistent profile dir — survives gateway restarts, keeps cookies intact
const GROK_PROFILE_DIR = join(homedir(), ".openclaw", "grok-profile");

// ── Gemini web-session state ──────────────────────────────────────────────────
let geminiContext: BrowserContext | null = null;
const GEMINI_EXPIRY_FILE = join(homedir(), ".openclaw", "gemini-cookie-expiry.json");

interface GeminiExpiryInfo { expiresAt: number; loginAt: number; cookieName: string; }

function saveGeminiExpiry(info: GeminiExpiryInfo): void {
  try { writeFileSync(GEMINI_EXPIRY_FILE, JSON.stringify(info, null, 2)); } catch { /* ignore */ }
}
function loadGeminiExpiry(): GeminiExpiryInfo | null {
  try { return JSON.parse(readFileSync(GEMINI_EXPIRY_FILE, "utf-8")) as GeminiExpiryInfo; } catch { return null; }
}
function formatGeminiExpiry(info: GeminiExpiryInfo): string {
  const daysLeft = Math.floor((info.expiresAt - Date.now()) / 86_400_000);
  const dateStr = new Date(info.expiresAt).toISOString().substring(0, 10);
  if (daysLeft < 0)   return `⚠️ EXPIRED (${dateStr}) — run /gemini-login`;
  if (daysLeft <= 7)  return `🚨 expires in ${daysLeft}d (${dateStr}) — run /gemini-login NOW`;
  if (daysLeft <= 14) return `⚠️ expires in ${daysLeft}d (${dateStr}) — run /gemini-login soon`;
  return `✅ valid for ${daysLeft} more days (expires ${dateStr})`;
}
async function scanGeminiCookieExpiry(ctx: BrowserContext): Promise<GeminiExpiryInfo | null> {
  try {
    const cookies = await ctx.cookies(["https://gemini.google.com", "https://accounts.google.com"]);
    const auth = cookies.filter(c => ["__Secure-1PSID", "__Secure-3PSID", "SID"].includes(c.name) && c.expires && c.expires > 0);
    if (!auth.length) return null;
    auth.sort((a, b) => (a.expires ?? 0) - (b.expires ?? 0));
    const earliest = auth[0];
    return { expiresAt: (earliest.expires ?? 0) * 1000, loginAt: Date.now(), cookieName: earliest.name };
  } catch { return null; }
}
// ─────────────────────────────────────────────────────────────────────────────

// ── ChatGPT web-session state ─────────────────────────────────────────────────
let chatgptContext: BrowserContext | null = null;
const CHATGPT_EXPIRY_FILE = join(homedir(), ".openclaw", "chatgpt-cookie-expiry.json");
interface ChatGPTExpiryInfo { expiresAt: number; loginAt: number; cookieName: string; }
function saveChatGPTExpiry(i: ChatGPTExpiryInfo) { try { writeFileSync(CHATGPT_EXPIRY_FILE, JSON.stringify(i, null, 2)); } catch { /* ignore */ } }
function loadChatGPTExpiry(): ChatGPTExpiryInfo | null { try { return JSON.parse(readFileSync(CHATGPT_EXPIRY_FILE, "utf-8")); } catch { return null; } }
function formatChatGPTExpiry(i: ChatGPTExpiryInfo): string {
  const d = Math.floor((i.expiresAt - Date.now()) / 86_400_000);
  const dt = new Date(i.expiresAt).toISOString().substring(0, 10);
  if (d < 0) return `⚠️ EXPIRED (${dt}) — run /chatgpt-login`;
  if (d <= 7) return `🚨 expires in ${d}d (${dt}) — run /chatgpt-login NOW`;
  if (d <= 14) return `⚠️ expires in ${d}d (${dt}) — run /chatgpt-login soon`;
  return `✅ valid for ${d} more days (expires ${dt})`;
}
async function scanChatGPTCookieExpiry(ctx: BrowserContext): Promise<ChatGPTExpiryInfo | null> {
  try {
    const cookies = await ctx.cookies(["https://chatgpt.com", "https://openai.com"]);
    const auth = cookies.filter(c => ["__Secure-next-auth.session-token", "cf_clearance", "__cf_bm"].includes(c.name) && c.expires && c.expires > 0);
    if (!auth.length) return null;
    auth.sort((a, b) => (a.expires ?? 0) - (b.expires ?? 0));
    const earliest = auth[0];
    return { expiresAt: (earliest.expires ?? 0) * 1000, loginAt: Date.now(), cookieName: earliest.name };
  } catch { return null; }
}
// ─────────────────────────────────────────────────────────────────────────────

// ── Claude web-session state ──────────────────────────────────────────────────
let claudeContext: BrowserContext | null = null;
const CLAUDE_EXPIRY_FILE = join(homedir(), ".openclaw", "claude-cookie-expiry.json");

interface ClaudeExpiryInfo {
  expiresAt: number;
  loginAt: number;
  cookieName: string;
}

function saveClaudeExpiry(info: ClaudeExpiryInfo): void {
  try { writeFileSync(CLAUDE_EXPIRY_FILE, JSON.stringify(info, null, 2)); } catch { /* ignore */ }
}
function loadClaudeExpiry(): ClaudeExpiryInfo | null {
  try { return JSON.parse(readFileSync(CLAUDE_EXPIRY_FILE, "utf-8")) as ClaudeExpiryInfo; } catch { return null; }
}
function formatClaudeExpiry(info: ClaudeExpiryInfo): string {
  const daysLeft = Math.floor((info.expiresAt - Date.now()) / 86_400_000);
  const dateStr = new Date(info.expiresAt).toISOString().substring(0, 10);
  if (daysLeft < 0)  return `⚠️ EXPIRED (${dateStr}) — run /claude-login`;
  if (daysLeft <= 7) return `🚨 expires in ${daysLeft}d (${dateStr}) — run /claude-login NOW`;
  if (daysLeft <= 14) return `⚠️ expires in ${daysLeft}d (${dateStr}) — run /claude-login soon`;
  return `✅ valid for ${daysLeft} more days (expires ${dateStr})`;
}
async function scanClaudeCookieExpiry(ctx: BrowserContext): Promise<ClaudeExpiryInfo | null> {
  try {
    const cookies = await ctx.cookies(["https://claude.ai", "https://anthropic.com"]);
    const authCookies = cookies.filter(c => ["sessionKey", "intercom-session-igviqkfk"].includes(c.name) && c.expires && c.expires > 0);
    if (!authCookies.length) return null;
    authCookies.sort((a, b) => (a.expires ?? 0) - (b.expires ?? 0));
    const earliest = authCookies[0];
    return { expiresAt: (earliest.expires ?? 0) * 1000, loginAt: Date.now(), cookieName: earliest.name };
  } catch { return null; }
}
// ─────────────────────────────────────────────────────────────────────────────

// Cookie expiry tracking file — written on /grok-login, read on startup
const GROK_EXPIRY_FILE = join(homedir(), ".openclaw", "grok-cookie-expiry.json");

interface GrokExpiryInfo {
  expiresAt: number;    // epoch ms — earliest auth cookie expiry
  loginAt: number;      // epoch ms — when /grok-login was last run
  cookieName: string;   // which cookie determines the expiry
}

function saveGrokExpiry(info: GrokExpiryInfo): void {
  try {
    writeFileSync(GROK_EXPIRY_FILE, JSON.stringify(info, null, 2));
  } catch { /* ignore */ }
}

function loadGrokExpiry(): GrokExpiryInfo | null {
  try {
    const raw = readFileSync(GROK_EXPIRY_FILE, "utf-8");
    return JSON.parse(raw) as GrokExpiryInfo;
  } catch { return null; }
}

/** Returns human-readable expiry summary e.g. "179 days (2026-09-07)" */
function formatExpiryInfo(info: GrokExpiryInfo): string {
  const daysLeft = Math.ceil((info.expiresAt - Date.now()) / 86_400_000);
  const dateStr = new Date(info.expiresAt).toISOString().split("T")[0];
  if (daysLeft <= 0) return `⚠️ EXPIRED (was ${dateStr})`;
  if (daysLeft <= 7) return `🚨 expires in ${daysLeft}d (${dateStr}) — run /grok-login NOW`;
  if (daysLeft <= 14) return `⚠️ expires in ${daysLeft}d (${dateStr}) — run /grok-login soon`;
  return `✅ valid for ${daysLeft} more days (expires ${dateStr})`;
}

/** Scan context cookies and return earliest auth cookie expiry */
async function scanCookieExpiry(ctx: import("playwright").BrowserContext): Promise<GrokExpiryInfo | null> {
  try {
    const cookies = await ctx.cookies(["https://grok.com", "https://x.ai"]);
    const authCookies = cookies.filter((c) => ["sso", "sso-rw"].includes(c.name) && c.expires > 0);
    if (authCookies.length === 0) return null;
    const earliest = authCookies.reduce((min, c) => (c.expires < min.expires ? c : min));
    return {
      expiresAt: earliest.expires * 1000,
      loginAt: Date.now(),
      cookieName: earliest.name,
    };
  } catch { return null; }
}

// Singleton CDP connection — one browser object shared across grok + claude
let _cdpBrowser: import("playwright").Browser | null = null;
let _cdpBrowserLaunchPromise: Promise<import("playwright").BrowserContext | null> | null = null;

/**
 * Connect to the OpenClaw managed browser (CDP port 18800).
 * Singleton: reuses the same connection. Falls back to persistent Chromium for Grok only.
 * NEVER launches a new browser for Claude — Claude requires the OpenClaw browser.
 */
async function connectToOpenClawBrowser(
  log: (msg: string) => void
): Promise<BrowserContext | null> {
  // Reuse existing CDP connection if still alive
  if (_cdpBrowser) {
    try {
      _cdpBrowser.contexts(); // ping
      return _cdpBrowser.contexts()[0] ?? null;
    } catch {
      _cdpBrowser = null;
    }
  }
  const { chromium } = await import("playwright");
  try {
    const browser = await chromium.connectOverCDP("http://127.0.0.1:18800", { timeout: 3000 });
    _cdpBrowser = browser;
    browser.on("disconnected", () => { _cdpBrowser = null; log("[cli-bridge] OpenClaw browser disconnected"); });
    log("[cli-bridge] connected to OpenClaw browser via CDP");
    return browser.contexts()[0] ?? null;
  } catch {
    log("[cli-bridge] OpenClaw browser not available (CDP 18800)");
    return null;
  }
}

/**
 * Launch (or reuse) a persistent headless Chromium context for grok.com.
 * ONLY used for Grok — Grok has a saved persistent profile with cookies.
 * Claude does NOT use this — it requires the OpenClaw browser.
 */
async function getOrLaunchGrokContext(
  log: (msg: string) => void
): Promise<BrowserContext | null> {
  // Already have a live context?
  if (grokContext) {
    try { grokContext.pages(); return grokContext; } catch { grokContext = null; }
  }

  // Try OpenClaw browser first (singleton CDP)
  const cdpCtx = await connectToOpenClawBrowser(log);
  if (cdpCtx) return cdpCtx;

  // Coalesce concurrent launch requests into one
  if (_cdpBrowserLaunchPromise) return _cdpBrowserLaunchPromise;

  _cdpBrowserLaunchPromise = (async () => {
    const { chromium } = await import("playwright");
    log("[cli-bridge:grok] launching persistent Chromium…");
    try {
      const ctx = await chromium.launchPersistentContext(GROK_PROFILE_DIR, {
        headless: true,
        args: ["--no-sandbox", "--disable-setuid-sandbox"],
      });
      grokContext = ctx;
      // Auto-cleanup on browser crash
      ctx.on("close", () => { grokContext = null; log("[cli-bridge:grok] persistent context closed"); });
      log("[cli-bridge:grok] persistent context ready");
      return ctx;
    } catch (err) {
      log(`[cli-bridge:grok] failed to launch browser: ${(err as Error).message}`);
      return null;
    } finally {
      _cdpBrowserLaunchPromise = null;
    }
  })();
  return _cdpBrowserLaunchPromise;
}

/** Clean up all browser resources — call on plugin teardown */
async function cleanupBrowsers(log: (msg: string) => void): Promise<void> {
  if (grokContext) {
    try { await grokContext.close(); } catch { /* ignore */ }
    grokContext = null;
  }
  if (_cdpBrowser) {
    try { await _cdpBrowser.close(); } catch { /* ignore */ }
    _cdpBrowser = null;
  }
  claudeContext = null;
  geminiContext = null;
  chatgptContext = null;
  log("[cli-bridge] browser resources cleaned up");
}

/**
 * Ensure all browser provider contexts are connected.
 * 1. Try the shared OpenClaw browser (CDP 18800)
 * 2. Fallback: launch a persistent headless Chromium per provider (saved profile with cookies)
 */
async function ensureAllProviderContexts(log: (msg: string) => void): Promise<void> {
  const { chromium } = await import("playwright");

  // Try CDP first (OpenClaw browser)
  let sharedCtx: BrowserContext | null = null;
  try {
    const b = await chromium.connectOverCDP("http://127.0.0.1:18800", { timeout: 2000 });
    sharedCtx = b.contexts()[0] ?? null;
    if (sharedCtx) log("[cli-bridge] using OpenClaw browser for all providers");
  } catch { /* not available */ }

  // For each provider: if no context yet, try shared ctx or launch own persistent context
  const providerConfigs = [
    {
      name: "claude",
      profileDir: join(homedir(), ".openclaw", "claude-profile"),
      getCtx: () => claudeContext,
      setCtx: (c: BrowserContext) => { claudeContext = c; },
      homeUrl: "https://claude.ai/new",
      verifySelector: ".ProseMirror",
    },
    {
      name: "gemini",
      profileDir: join(homedir(), ".openclaw", "gemini-profile"),
      getCtx: () => geminiContext,
      setCtx: (c: BrowserContext) => { geminiContext = c; },
      homeUrl: "https://gemini.google.com/app",
      verifySelector: ".ql-editor",
    },
    {
      name: "chatgpt",
      profileDir: join(homedir(), ".openclaw", "chatgpt-profile"),
      getCtx: () => chatgptContext,
      setCtx: (c: BrowserContext) => { chatgptContext = c; },
      homeUrl: "https://chatgpt.com",
      verifySelector: "#prompt-textarea",
    },
  ];

  for (const cfg of providerConfigs) {
    if (cfg.getCtx()) continue; // already connected

    let ctx: BrowserContext | null = null;

    // 1. Try shared OpenClaw browser context
    if (sharedCtx) {
      try {
        const pages = sharedCtx.pages();
        const existing = pages.find(p => p.url().includes(new URL(cfg.homeUrl).hostname));
        const page = existing ?? await sharedCtx.newPage();
        if (!existing) {
          await page.goto(cfg.homeUrl, { waitUntil: "domcontentloaded", timeout: 10_000 });
          await new Promise(r => setTimeout(r, 2000));
        }
        const visible = await page.locator(cfg.verifySelector).isVisible().catch(() => false);
        if (visible) {
          ctx = sharedCtx;
          log(`[cli-bridge:${cfg.name}] connected via OpenClaw browser ✅`);
        }
      } catch { /* fall through */ }
    }

    // 2. Launch own persistent context (has saved cookies)
    if (!ctx) {
      try {
        mkdirSync(cfg.profileDir, { recursive: true });
        const pCtx = await chromium.launchPersistentContext(cfg.profileDir, {
          headless: true,
          args: ["--no-sandbox", "--disable-setuid-sandbox"],
        });
        const page = await pCtx.newPage();
        await page.goto(cfg.homeUrl, { waitUntil: "domcontentloaded", timeout: 15_000 });
        await new Promise(r => setTimeout(r, 4000));
        const visible = await page.locator(cfg.verifySelector).isVisible().catch(() => false);
        if (visible) {
          ctx = pCtx;
          log(`[cli-bridge:${cfg.name}] launched persistent context ✅`);
        } else {
          const title = await page.title().catch(() => "unknown");
          const bodySnippet = await page.evaluate(() => document.body?.innerText?.substring(0, 100) ?? "").catch(() => "");
          log(`[cli-bridge:${cfg.name}] persistent headless: editor not visible — title="${title}" body="${bodySnippet}"`);
          await pCtx.close().catch(() => {});
        }
      } catch (err) {
        log(`[cli-bridge:${cfg.name}] could not launch browser: ${(err as Error).message}`);
      }
    }

    if (ctx) cfg.setCtx(ctx);
  }
}

async function tryRestoreGrokSession(
  _sessionPath: string,
  log: (msg: string) => void
): Promise<boolean> {
  try {
    const ctx = await getOrLaunchGrokContext(log);
    if (!ctx) return false;

    const check = await verifySession(ctx, log);
    if (!check.valid) {
      log(`[cli-bridge:grok] session invalid: ${check.reason}`);
      return false;
    }
    grokContext = ctx;
    log("[cli-bridge:grok] session restored ✅");
    // Log cookie expiry status on startup
    const expiry = loadGrokExpiry();
    if (expiry) {
      log(`[cli-bridge:grok] cookie expiry: ${formatExpiryInfo(expiry)}`);
      // Re-scan to keep expiry file fresh (cookies may have been renewed)
      const freshExpiry = await scanCookieExpiry(ctx);
      if (freshExpiry) saveGrokExpiry(freshExpiry);
    }
    return true;
  } catch (err) {
    log(`[cli-bridge:grok] session restore error: ${(err as Error).message}`);
    return false;
  }
}

const DEFAULT_PROXY_PORT = 31337;
const DEFAULT_PROXY_API_KEY = "cli-bridge";

// ──────────────────────────────────────────────────────────────────────────────
// State file — persists the model that was active before the last /cli-* switch
// Located at ~/.openclaw/cli-bridge-state.json (survives gateway restarts)
// ──────────────────────────────────────────────────────────────────────────────
const STATE_FILE = join(homedir(), ".openclaw", "cli-bridge-state.json");

interface CliBridgeState {
  previousModel: string;
}

function readState(): CliBridgeState | null {
  try {
    return JSON.parse(readFileSync(STATE_FILE, "utf8")) as CliBridgeState;
  } catch {
    return null;
  }
}

function writeState(state: CliBridgeState): void {
  try {
    mkdirSync(join(homedir(), ".openclaw"), { recursive: true });
    writeFileSync(STATE_FILE, JSON.stringify(state, null, 2) + "\n", "utf8");
  } catch {
    // non-fatal — /cli-back will just report no previous model
  }
}

// ──────────────────────────────────────────────────────────────────────────────
// Read the current primary model from openclaw.json
// ──────────────────────────────────────────────────────────────────────────────
function readCurrentModel(): string | null {
  try {
    const cfg = JSON.parse(
      readFileSync(join(homedir(), ".openclaw", "openclaw.json"), "utf8")
    );
    const m = cfg?.agents?.defaults?.model;
    if (typeof m === "string") return m;
    if (typeof m === "object" && m !== null && typeof m.primary === "string")
      return m.primary;
    return null;
  } catch {
    return null;
  }
}

// ──────────────────────────────────────────────────────────────────────────────
// Phase 3: model command table
// ──────────────────────────────────────────────────────────────────────────────
const CLI_MODEL_COMMANDS = [
  // ── Claude Code CLI (via local proxy) ────────────────────────────────────────
  { name: "cli-sonnet",       model: "vllm/cli-claude/claude-sonnet-4-6",    description: "Claude Sonnet 4.6 (Claude Code CLI)",   label: "Claude Sonnet 4.6 (CLI)" },
  { name: "cli-opus",         model: "vllm/cli-claude/claude-opus-4-6",      description: "Claude Opus 4.6 (Claude Code CLI)",     label: "Claude Opus 4.6 (CLI)" },
  { name: "cli-haiku",        model: "vllm/cli-claude/claude-haiku-4-5",     description: "Claude Haiku 4.5 (Claude Code CLI)",    label: "Claude Haiku 4.5 (CLI)" },
  // ── Gemini CLI (via local proxy) ─────────────────────────────────────────────
  { name: "cli-gemini",       model: "vllm/cli-gemini/gemini-2.5-pro",       description: "Gemini 2.5 Pro (Gemini CLI)",           label: "Gemini 2.5 Pro (CLI)" },
  { name: "cli-gemini-flash", model: "vllm/cli-gemini/gemini-2.5-flash",     description: "Gemini 2.5 Flash (Gemini CLI)",         label: "Gemini 2.5 Flash (CLI)" },
  { name: "cli-gemini3",      model: "vllm/cli-gemini/gemini-3-pro-preview", description: "Gemini 3 Pro (Gemini CLI)",             label: "Gemini 3 Pro (CLI)" },
  // ── Codex CLI (openai-codex provider, OAuth auth) ────────────────────────────
  { name: "cli-codex",        model: "openai-codex/gpt-5.3-codex",          description: "GPT-5.3 Codex (Codex CLI auth)",        label: "GPT-5.3 Codex" },
  { name: "cli-codex54",      model: "openai-codex/gpt-5.4",                description: "GPT-5.4 (Codex CLI auth)",              label: "GPT-5.4" },
] as const;

/** Default model used by /cli-test when no arg is given */
const CLI_TEST_DEFAULT_MODEL = "cli-claude/claude-sonnet-4-6";

// ──────────────────────────────────────────────────────────────────────────────
// Staged-switch state file
// Stores a pending model switch that has not yet been applied.
// Written by /cli-* (default), applied by /cli-apply or /cli-* --now.
// Located at ~/.openclaw/cli-bridge-pending.json
// ──────────────────────────────────────────────────────────────────────────────
const PENDING_FILE = join(homedir(), ".openclaw", "cli-bridge-pending.json");

interface CliBridgePending {
  model: string;
  label: string;
  requestedAt: string;
}

function readPending(): CliBridgePending | null {
  try {
    return JSON.parse(readFileSync(PENDING_FILE, "utf8")) as CliBridgePending;
  } catch {
    return null;
  }
}

function writePending(pending: CliBridgePending): void {
  try {
    mkdirSync(join(homedir(), ".openclaw"), { recursive: true });
    writeFileSync(PENDING_FILE, JSON.stringify(pending, null, 2) + "\n", "utf8");
  } catch {
    // non-fatal
  }
}

function clearPending(): void {
  try {
    const { unlinkSync } = require("node:fs");
    unlinkSync(PENDING_FILE);
  } catch {
    // non-fatal — file may not exist
  }
}

// ──────────────────────────────────────────────────────────────────────────────
// Helper: immediately apply the model switch (no safety checks)
// ──────────────────────────────────────────────────────────────────────────────
async function applyModelSwitch(
  api: OpenClawPluginApi,
  model: string,
  label: string,
): Promise<PluginCommandResult> {
  const current = readCurrentModel();
  if (current && current !== model) {
    writeState({ previousModel: current });
    api.logger.info(`[cli-bridge] saved previous model: ${current}`);
  }

  try {
    const result = await api.runtime.system.runCommandWithTimeout(
      ["openclaw", "models", "set", model],
      { timeoutMs: 8_000 }
    );

    if (result.code !== 0) {
      const err = (result.stderr || result.stdout || "unknown error").trim();
      api.logger.warn(`[cli-bridge] models set failed (code ${result.code}): ${err}`);
      return { text: `❌ Failed to switch to ${label}: ${err}` };
    }

    clearPending();
    api.logger.info(`[cli-bridge] switched model → ${model}`);
    return {
      text:
        `✅ Switched to **${label}**\n` +
        `\`${model}\`\n\n` +
        `Use \`/cli-back\` to restore previous model.`,
    };
  } catch (err) {
    const msg = (err as Error).message;
    api.logger.warn(`[cli-bridge] models set error: ${msg}`);
    return { text: `❌ Error switching model: ${msg}` };
  }
}

// ──────────────────────────────────────────────────────────────────────────────
// Helper: staged switch (default behavior)
//
// ⚠️  SAFETY: /cli-* mid-session bricht den aktiven Agenten.
//
// `openclaw models set` ist ein **sofortiger, globaler Switch**.
// Der laufende Agent verliert seinen Kontext — Tool-Calls werden nicht
// ausgeführt, Planfiles werden nicht geschrieben, keine Rückmeldung.
//
// Default: Switch wird nur gespeichert (nicht angewendet).
// Mit --now: sofortiger Switch (nur zwischen Sessions verwenden!).
// Mit /cli-apply: gespeicherten Switch anwenden (nach Session-Ende).
// ──────────────────────────────────────────────────────────────────────────────
async function switchModel(
  api: OpenClawPluginApi,
  model: string,
  label: string,
  forceNow: boolean,
): Promise<PluginCommandResult> {
  // --now: sofortiger Switch, volle Verantwortung beim User
  if (forceNow) {
    api.logger.warn(`[cli-bridge] --now switch to ${model} (immediate, session may break)`);
    return applyModelSwitch(api, model, label);
  }

  // Default: staged switch — speichern, warnen, nicht anwenden
  const current = readCurrentModel();

  if (current === model) {
    return { text: `ℹ️ Already on **${label}**\n\`${model}\`` };
  }

  writePending({ model, label, requestedAt: new Date().toISOString() });
  api.logger.info(`[cli-bridge] staged switch → ${model} (pending, not applied yet)`);

  return {
    text:
      `📋 **Model switch staged: ${label}**\n` +
      `\`${model}\`\n\n` +
      `⚠️ **NOT applied yet** — switching mid-session breaks the active agent:\n` +
      `tool calls fail silently, plan files don't get written, no feedback.\n\n` +
      `**To apply:**\n` +
      `• \`/cli-apply\` — apply after finishing your current task\n` +
      `• \`/cli-* --now\` — force immediate switch (only between sessions!)`,
  };
}

// ──────────────────────────────────────────────────────────────────────────────
// Helper: fire a one-shot test request directly at the proxy (no global switch)
// ──────────────────────────────────────────────────────────────────────────────
function proxyTestRequest(
  port: number,
  apiKey: string,
  model: string,
  timeoutMs: number
): Promise<string> {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify({
      model,
      messages: [{ role: "user", content: "Reply with exactly: CLI bridge OK" }],
      stream: false,
    });

    const req = http.request(
      {
        hostname: "127.0.0.1",
        port,
        path: "/v1/chat/completions",
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${apiKey}`,
          "Content-Length": Buffer.byteLength(body),
        },
      },
      (res) => {
        let data = "";
        res.on("data", (chunk: Buffer) => { data += chunk.toString(); });
        res.on("end", () => {
          try {
            const parsed = JSON.parse(data) as {
              choices?: Array<{ message?: { content?: string } }>;
              error?: { message?: string };
            };
            if (parsed.error) {
              resolve(`Proxy error: ${parsed.error.message}`);
            } else {
              resolve(parsed.choices?.[0]?.message?.content?.trim() ?? "(empty response)");
            }
          } catch {
            resolve(`(non-JSON response: ${data.slice(0, 200)})`);
          }
        });
      }
    );

    req.setTimeout(timeoutMs, () => {
      req.destroy();
      reject(new Error(`Proxy test timed out after ${timeoutMs}ms`));
    });
    req.on("error", reject);
    req.write(body);
    req.end();
  });
}

// ──────────────────────────────────────────────────────────────────────────────
// Plugin definition
// ──────────────────────────────────────────────────────────────────────────────
const plugin = {
  id: "openclaw-cli-bridge-elvatis",
  name: "OpenClaw CLI Bridge",
  version: "1.3.1",
  description:
    "Phase 1: openai-codex auth bridge. " +
    "Phase 2: HTTP proxy for gemini/claude CLIs. " +
    "Phase 3: /cli-* model switching, /cli-back restore, /cli-test health check.",

  register(api: OpenClawPluginApi) {
    const cfg = (api.pluginConfig ?? {}) as CliPluginConfig;
    const enableCodex = cfg.enableCodex ?? true;
    const enableProxy = cfg.enableProxy ?? true;
    const port = cfg.proxyPort ?? DEFAULT_PROXY_PORT;
    const apiKey = cfg.proxyApiKey ?? DEFAULT_PROXY_API_KEY;
    const timeoutMs = cfg.proxyTimeoutMs ?? 120_000;
    const codexAuthPath = cfg.codexAuthPath ?? DEFAULT_CODEX_AUTH_PATH;
    const grokSessionPath = cfg.grokSessionPath ?? DEFAULT_SESSION_PATH;

    // ── Grok session restore (non-blocking) ───────────────────────────────────
    void tryRestoreGrokSession(grokSessionPath, (msg) => api.logger.info(msg));

    // ── Auto-connect all browser providers on startup (non-blocking) ──────────
    void (async () => {
      await new Promise(r => setTimeout(r, 3000)); // wait for proxy to start
      await ensureAllProviderContexts((msg) => api.logger.info(msg));
    })();

    // ── Phase 1: openai-codex auth bridge ─────────────────────────────────────
    if (enableCodex) {
      api.registerProvider({
        id: "openai-codex",
        label: "OpenAI Codex (CLI bridge)",
        docsPath: "/providers/openai",
        aliases: ["codex-cli"],

        auth: [
          {
            id: "codex-cli-oauth",
            label: "Codex CLI (existing login)",
            hint: "Reads OAuth tokens from ~/.codex/auth.json — no re-login needed",
            kind: "oauth",

            run: async (ctx: ProviderAuthContext): Promise<ProviderAuthResult> => {
              const spin = ctx.prompter.progress("Reading Codex CLI credentials…");
              try {
                const creds = await readCodexCredentials(codexAuthPath);
                spin.stop("Codex CLI credentials loaded");
                return buildOauthProviderAuthResult({
                  providerId: "openai-codex",
                  defaultModel: CODEX_DEFAULT_MODEL,
                  access: creds.accessToken,
                  refresh: creds.refreshToken,
                  expires: creds.expiresAt,
                  email: creds.email,
                  notes: [
                    `Auth read from: ${codexAuthPath}`,
                    "If calls fail, run 'codex login' to refresh, then re-run auth.",
                  ],
                });
              } catch (err) {
                spin.stop("Failed to read Codex credentials");
                throw err;
              }
            },
          },
        ],

        refreshOAuth: async (cred) => {
          try {
            const fresh = await readCodexCredentials(codexAuthPath);
            return {
              ...cred,
              access: fresh.accessToken,
              refresh: fresh.refreshToken ?? cred.refresh,
              expires: fresh.expiresAt ?? cred.expires,
            };
          } catch {
            return cred;
          }
        },
      });

      api.logger.info("[cli-bridge] openai-codex provider registered");
    }

    // ── Phase 2: CLI request proxy ─────────────────────────────────────────────
    let proxyServer: import("node:http").Server | null = null;

    if (enableProxy) {
      // Probe whether a healthy proxy is already listening on our port.
      // This handles hot-reloads where the previous plugin instance's server.close()
      // may not have completed yet — rather than killing anything (dangerous: fuser -k
      // can kill the gateway process itself during in-process hot-reloads), we just
      // check if the existing server still responds and reuse it if so.
      const probeExisting = (): Promise<boolean> => {
        return new Promise((resolve) => {
          const req = http.request(
            { hostname: "127.0.0.1", port, path: "/v1/models", method: "GET",
              headers: { Authorization: `Bearer ${apiKey}` } },
            (res) => { res.resume(); resolve(res.statusCode === 200); }
          );
          req.setTimeout(800, () => { req.destroy(); resolve(false); });
          req.on("error", () => resolve(false));
          req.end();
        });
      };

      const startProxy = async (): Promise<void> => {
        // If a healthy proxy is already up, reuse it — no need to rebind.
        const alive = await probeExisting();
        if (alive) {
          api.logger.info(`[cli-bridge] proxy already running on :${port} — reusing`);
          return;
        }

        try {
          const server = await startProxyServer({
            port,
            apiKey,
            timeoutMs,
            log: (msg) => api.logger.info(msg),
            warn: (msg) => api.logger.warn(msg),
            getGrokContext: () => grokContext,
            connectGrokContext: async () => {
              const ctx = await connectToOpenClawBrowser((msg) => api.logger.info(msg));
              if (ctx) {
                const check = await verifySession(ctx, (msg) => api.logger.info(msg));
                if (check.valid) { grokContext = ctx; return ctx; }
              }
              return null;
            },
            getClaudeContext: () => claudeContext,
            connectClaudeContext: async () => {
              const ctx = await connectToOpenClawBrowser((msg) => api.logger.info(msg));
              if (ctx) {
                const { getOrCreateClaudePage } = await import("./src/claude-browser.js");
                const { page } = await getOrCreateClaudePage(ctx);
                const editor = await page.locator(".ProseMirror").isVisible().catch(() => false);
                if (editor) { claudeContext = ctx; return ctx; }
              }
              // Fallback: try persistent context
              await ensureAllProviderContexts((msg) => api.logger.info(msg));
              return claudeContext;
            },
            getGeminiContext: () => geminiContext,
            connectGeminiContext: async () => {
              const ctx = await connectToOpenClawBrowser((msg) => api.logger.info(msg));
              if (ctx) {
                const { getOrCreateGeminiPage } = await import("./src/gemini-browser.js");
                const { page } = await getOrCreateGeminiPage(ctx);
                const editor = await page.locator(".ql-editor").isVisible().catch(() => false);
                if (editor) { geminiContext = ctx; return ctx; }
              }
              // Fallback: try persistent context
              await ensureAllProviderContexts((msg) => api.logger.info(msg));
              return geminiContext;
            },
            getChatGPTContext: () => chatgptContext,
            connectChatGPTContext: async () => {
              const ctx = await connectToOpenClawBrowser((msg) => api.logger.info(msg));
              if (ctx) {
                const { getOrCreateChatGPTPage } = await import("./src/chatgpt-browser.js");
                const { page } = await getOrCreateChatGPTPage(ctx);
                const editor = await page.locator("#prompt-textarea").isVisible().catch(() => false);
                if (editor) { chatgptContext = ctx; return ctx; }
              }
              // Fallback: try persistent context
              await ensureAllProviderContexts((msg) => api.logger.info(msg));
              return chatgptContext;
            },
          });
          proxyServer = server;
          api.logger.info(
            `[cli-bridge] proxy ready on :${port} — vllm/cli-gemini/* and vllm/cli-claude/* available`
          );
          const result = patchOpencllawConfig(port);
          if (result.patched) {
            api.logger.info(
              `[cli-bridge] openclaw.json patched with vllm provider. Restart gateway to activate.`
            );
          }
        } catch (err: unknown) {
          const msg = (err as Error).message ?? String(err);
          if (msg.includes("EADDRINUSE")) {
            // Port is busy but probe didn't respond — wait for the OS to release it
            api.logger.warn(`[cli-bridge] port ${port} busy, waiting 1s for OS release…`);
            await new Promise((r) => setTimeout(r, 1000));
            // One final attempt
            try {
              const server = await startProxyServer({
                port, apiKey, timeoutMs,
                log: (msg) => api.logger.info(msg),
                warn: (msg) => api.logger.warn(msg),
                getGrokContext: () => grokContext,
                connectGrokContext: async () => {
                  const ctx = await connectToOpenClawBrowser((msg) => api.logger.info(msg));
                  if (ctx) {
                    const check = await verifySession(ctx, (msg) => api.logger.info(msg));
                    if (check.valid) { grokContext = ctx; return ctx; }
                  }
                  return null;
                },
                getClaudeContext: () => claudeContext,
                connectClaudeContext: async () => {
                  const ctx = await connectToOpenClawBrowser((msg) => api.logger.info(msg));
                  if (ctx) {
                    const { getOrCreateClaudePage } = await import("./src/claude-browser.js");
                    const { page } = await getOrCreateClaudePage(ctx);
                    const editor = await page.locator(".ProseMirror").isVisible().catch(() => false);
                    if (editor) { claudeContext = ctx; return ctx; }
                  }
                  // Fallback: try persistent context
                  await ensureAllProviderContexts((msg) => api.logger.info(msg));
                  return claudeContext;
                },
                getGeminiContext: () => geminiContext,
                connectGeminiContext: async () => {
                  const ctx = await connectToOpenClawBrowser((msg) => api.logger.info(msg));
                  if (ctx) {
                    const { getOrCreateGeminiPage } = await import("./src/gemini-browser.js");
                    const { page } = await getOrCreateGeminiPage(ctx);
                    const editor = await page.locator(".ql-editor").isVisible().catch(() => false);
                    if (editor) { geminiContext = ctx; return ctx; }
                  }
                  // Fallback: try persistent context
                  await ensureAllProviderContexts((msg) => api.logger.info(msg));
                  return geminiContext;
                },
                getChatGPTContext: () => chatgptContext,
                connectChatGPTContext: async () => {
                  const ctx = await connectToOpenClawBrowser((msg) => api.logger.info(msg));
                  if (ctx) {
                    const { getOrCreateChatGPTPage } = await import("./src/chatgpt-browser.js");
                    const { page } = await getOrCreateChatGPTPage(ctx);
                    const editor = await page.locator("#prompt-textarea").isVisible().catch(() => false);
                    if (editor) { chatgptContext = ctx; return ctx; }
                  }
                  // Fallback: try persistent context
                  await ensureAllProviderContexts((msg) => api.logger.info(msg));
                  return chatgptContext;
                },
              });
              proxyServer = server;
              api.logger.info(`[cli-bridge] proxy ready on :${port} (retry)`);
            } catch (e2: unknown) {
              api.logger.warn(`[cli-bridge] proxy unavailable after retry: ${(e2 as Error).message}`);
            }
          } else {
            api.logger.warn(`[cli-bridge] proxy failed to start on port ${port}: ${msg}`);
          }
        }
      };

      startProxy().catch(() => {});
    }

    // ── Cleanup: close proxy server on plugin stop (hot-reload / gateway restart) ──
    // Register a named service so OpenClaw can call stop() on plugin teardown.
    api.registerService({
      id: "cli-bridge-proxy",
      start: async () => { /* proxy already started above */ },
      stop: async () => {
        // Clean up browser resources first
        await cleanupBrowsers((msg) => api.logger.info(msg));

        if (proxyServer) {
          // closeAllConnections() forcefully terminates keep-alive connections
          // so that server.close() releases the port immediately rather than
          // waiting for them to drain. Without this, the port stays bound
          // during hot-reloads and the next start() call gets EADDRINUSE.
          if (typeof (proxyServer as any).closeAllConnections === "function") {
            (proxyServer as any).closeAllConnections();
          }
          await new Promise<void>((resolve) => {
            proxyServer!.close((err) => {
              if (err) api.logger.warn(`[cli-bridge] proxy close error: ${err.message}`);
              else api.logger.info(`[cli-bridge] proxy server closed on plugin stop`);
              resolve();
            });
          });
          proxyServer = null;
        }
      },
    });


    // ── Phase 3a: /cli-* model switch commands ─────────────────────────────────
    for (const entry of CLI_MODEL_COMMANDS) {
      const { name, model, description, label } = entry;
      api.registerCommand({
        name,
        description: `${description}. Pass --now to apply immediately (only between sessions!).`,
        acceptsArgs: true,
        requireAuth: false,
        handler: async (ctx: PluginCommandContext): Promise<PluginCommandResult> => {
          const forceNow = (ctx.args ?? "").trim().toLowerCase() === "--now";
          api.logger.info(`[cli-bridge] /${name} by ${ctx.senderId ?? "?"} forceNow=${forceNow}`);
          return switchModel(api, model, label, forceNow);
        },
      } satisfies OpenClawPluginCommandDefinition);
    }

    // ── Phase 3b: /cli-back — restore previous model ──────────────────────────
    api.registerCommand({
      name: "cli-back",
      description: "Restore the model active before the last /cli-* switch. Clears any pending staged switch.",
      requireAuth: false,
      handler: async (ctx: PluginCommandContext): Promise<PluginCommandResult> => {
        api.logger.info(`[cli-bridge] /cli-back by ${ctx.senderId ?? "?"}`);

        // Clear any pending staged switch
        clearPending();

        const state = readState();
        if (!state?.previousModel) {
          return { text: "ℹ️ No previous model saved. Use `/cli-sonnet` etc. to switch first." };
        }

        const prev = state.previousModel;

        // Clear the saved state so a second /cli-back doesn't bounce back
        writeState({ previousModel: "" });

        try {
          const result = await api.runtime.system.runCommandWithTimeout(
            ["openclaw", "models", "set", prev],
            { timeoutMs: 8_000 }
          );

          if (result.code !== 0) {
            const err = (result.stderr || result.stdout || "unknown error").trim();
            return { text: `❌ Failed to restore \`${prev}\`: ${err}` };
          }

          api.logger.info(`[cli-bridge] /cli-back restored → ${prev}`);
          return { text: `✅ Restored previous model\n\`${prev}\`` };
        } catch (err) {
          return { text: `❌ Error: ${(err as Error).message}` };
        }
      },
    } satisfies OpenClawPluginCommandDefinition);

    // ── Phase 3b2: /cli-apply — apply staged model switch ─────────────────────
    api.registerCommand({
      name: "cli-apply",
      description: "Apply a staged /cli-* model switch. Use this AFTER finishing your current task.",
      requireAuth: false,
      handler: async (ctx: PluginCommandContext): Promise<PluginCommandResult> => {
        api.logger.info(`[cli-bridge] /cli-apply by ${ctx.senderId ?? "?"}`);

        const pending = readPending();
        if (!pending) {
          const current = readCurrentModel();
          return {
            text:
              `ℹ️ No staged switch pending.\n` +
              `Current model: \`${current ?? "unknown"}\`\n\n` +
              `Use \`/cli-sonnet\`, \`/cli-opus\` etc. to stage a switch.`,
          };
        }

        api.logger.info(`[cli-bridge] applying staged switch → ${pending.model}`);
        return applyModelSwitch(api, pending.model, pending.label);
      },
    } satisfies OpenClawPluginCommandDefinition);

    // ── Phase 3b3: /cli-pending — show staged switch ───────────────────────────
    api.registerCommand({
      name: "cli-pending",
      description: "Show the currently staged model switch (if any).",
      requireAuth: false,
      handler: async (): Promise<PluginCommandResult> => {
        const pending = readPending();
        const current = readCurrentModel();
        if (!pending) {
          return {
            text:
              `✅ No pending switch.\n` +
              `Current model: \`${current ?? "unknown"}\``,
          };
        }
        return {
          text:
            `📋 **Staged switch pending:**\n` +
            `→ \`${pending.model}\` (${pending.label})\n` +
            `Requested: ${pending.requestedAt}\n\n` +
            `Current: \`${current ?? "unknown"}\`\n\n` +
            `Run \`/cli-apply\` to apply after finishing your current task.\n` +
            `Run \`/cli-sonnet --now\` etc. to discard and switch immediately.`,
        };
      },
    } satisfies OpenClawPluginCommandDefinition);

    // ── Phase 3c: /cli-test — one-shot proxy ping, no global model switch ──────
    api.registerCommand({
      name: "cli-test",
      description: "Test the CLI bridge proxy without switching your active model. Usage: /cli-test [model]",
      acceptsArgs: true,
      requireAuth: false,
      handler: async (ctx: PluginCommandContext): Promise<PluginCommandResult> => {
        const targetModel = ctx.args?.trim() || CLI_TEST_DEFAULT_MODEL;
        // Accept short names like "cli-sonnet" or full "vllm/cli-claude/claude-sonnet-4-6"
        const model = targetModel.startsWith("vllm/")
          ? targetModel
          : `vllm/${targetModel}`;

        api.logger.info(`[cli-bridge] /cli-test → ${model} by ${ctx.senderId ?? "?"}`);

        if (!enableProxy) {
          return { text: "❌ Proxy is disabled (enableProxy: false in config)." };
        }

        const current = readCurrentModel();
        const testTimeoutMs = Math.min(timeoutMs, 30_000);

        try {
          const start = Date.now();
          const response = await proxyTestRequest(port, apiKey, model, testTimeoutMs);
          const elapsed = Date.now() - start;

          return {
            text:
              `🧪 **CLI Bridge Test**\n` +
              `Model: \`${model}\`\n` +
              `Response: _${response}_\n` +
              `Latency: ${elapsed}ms\n\n` +
              `Active model unchanged: \`${current ?? "unknown"}\``,
          };
        } catch (err) {
          return {
            text:
              `❌ **CLI Bridge Test Failed**\n` +
              `Model: \`${model}\`\n` +
              `Error: ${(err as Error).message}\n\n` +
              `Active model unchanged: \`${current ?? "unknown"}\``,
          };
        }
      },
    } satisfies OpenClawPluginCommandDefinition);

    // ── Phase 3d: /cli-list — formatted model overview ────────────────────────
    api.registerCommand({
      name: "cli-list",
      description: "List all registered CLI bridge models and their commands.",
      requireAuth: false,
      handler: async (): Promise<PluginCommandResult> => {
        const groups: Record<string, { cmd: string; model: string }[]> = {
          "Claude Code CLI": [],
          "Gemini CLI": [],
          "Codex (OAuth)": [],
        };

        for (const c of CLI_MODEL_COMMANDS) {
          const entry = { cmd: `/${c.name}`, model: c.model };
          if (c.model.startsWith("vllm/cli-claude/")) groups["Claude Code CLI"].push(entry);
          else if (c.model.startsWith("vllm/cli-gemini/")) groups["Gemini CLI"].push(entry);
          else groups["Codex (OAuth)"].push(entry);
        }

        const lines: string[] = ["🤖 *CLI Bridge Models*", ""];
        for (const [group, entries] of Object.entries(groups)) {
          if (entries.length === 0) continue;
          lines.push(`*${group}*`);
          for (const { cmd, model } of entries) {
            const modelId = model.replace(/^vllm\/cli-(claude|gemini)\//, "").replace(/^openai-codex\//, "");
            lines.push(`  ${cmd.padEnd(20)} ${modelId}`);
          }
          lines.push("");
        }
        const pending = readPending();
        const pendingNote = pending ? ` ← pending: ${pending.label}` : "";

        lines.push("*Utility*");
        lines.push(`  /cli-apply           Apply staged switch${pendingNote}`);
        lines.push("  /cli-pending         Show staged switch (if any)");
        lines.push("  /cli-back            Restore previous model + clear staged");
        lines.push("  /cli-test [model]    Health check (no model switch)");
        lines.push("  /cli-list            This overview");
        lines.push("");
        lines.push("*Switching safely:*");
        lines.push("  /cli-sonnet          → stages switch (safe, apply later)");
        lines.push("  /cli-sonnet --now    → immediate switch (only between sessions!)");
        lines.push("");
        lines.push(`Proxy: \`127.0.0.1:${port}\``);

        return { text: lines.join("\n") };
      },
    } satisfies OpenClawPluginCommandDefinition);

    // ── Phase 4: Grok web-session commands ────────────────────────────────────

    api.registerCommand({
      name: "grok-login",
      description: "Authenticate grok.com: imports cookies from OpenClaw browser into persistent profile",
      handler: async (): Promise<PluginCommandResult> => {
        if (grokContext) {
          const check = await verifySession(grokContext, (msg) => api.logger.info(msg));
          if (check.valid) {
            return { text: "✅ Already connected to grok.com. Use `/grok-logout` first to reset." };
          }
          grokContext = null;
        }
        api.logger.info("[cli-bridge:grok] /grok-login: importing session from OpenClaw browser…");
        const { chromium } = await import("playwright");

        // Step 1: try to grab cookies from the OpenClaw browser (user must have grok.com open)
        let importedCookies: unknown[] = [];
        try {
          const ocBrowser = await chromium.connectOverCDP("http://127.0.0.1:18800", { timeout: 3000 });
          const ocCtx = ocBrowser.contexts()[0];
          if (ocCtx) {
            importedCookies = await ocCtx.cookies(["https://grok.com", "https://x.ai", "https://accounts.x.ai"]);
            api.logger.info(`[cli-bridge:grok] imported ${importedCookies.length} cookies from OpenClaw browser`);
          }
          await ocBrowser.close().catch(() => {});
        } catch {
          api.logger.info("[cli-bridge:grok] OpenClaw browser not available — using saved profile");
        }

        // Step 2: launch/connect persistent context and inject cookies
        const ctx = await getOrLaunchGrokContext((msg) => api.logger.info(msg));
        if (!ctx) return { text: "❌ Could not launch browser. Check server logs." };

        if (importedCookies.length > 0) {
          await ctx.addCookies(importedCookies as Parameters<typeof ctx.addCookies>[0]);
          api.logger.info(`[cli-bridge:grok] cookies injected into persistent profile`);
        }

        // Step 3: navigate to grok.com and verify
        const pages = ctx.pages();
        const page = pages.find(p => p.url().includes("grok.com")) ?? await ctx.newPage();
        if (!page.url().includes("grok.com")) {
          await page.goto("https://grok.com", { waitUntil: "domcontentloaded", timeout: 15_000 });
        }

        const check = await verifySession(ctx, (msg) => api.logger.info(msg));
        if (!check.valid) {
          return { text: `❌ Session not valid: ${check.reason}\n\nMake sure grok.com is open in your browser and you're logged in, then run /grok-login again.` };
        }
        grokContext = ctx;

        // Scan cookie expiry and persist it
        const expiry = await scanCookieExpiry(ctx);
        if (expiry) {
          saveGrokExpiry(expiry);
          api.logger.info(`[cli-bridge:grok] cookie expiry: ${new Date(expiry.expiresAt).toISOString()}`);
        }
        const expiryLine = expiry ? `\n\n🕐 Cookie expiry: ${formatExpiryInfo(expiry)}` : "";

        return { text: `✅ Grok session ready!\n\nModels available:\n• \`vllm/web-grok/grok-3\`\n• \`vllm/web-grok/grok-3-fast\`\n• \`vllm/web-grok/grok-3-mini\`\n• \`vllm/web-grok/grok-3-mini-fast\`${expiryLine}` };
      },
    } satisfies OpenClawPluginCommandDefinition);

    api.registerCommand({
      name: "grok-status",
      description: "Check grok.com session status",
      handler: async (): Promise<PluginCommandResult> => {
        if (!grokContext) {
          return { text: "❌ No active grok.com session\nRun `/grok-login` to authenticate." };
        }
        const check = await verifySession(grokContext, (msg) => api.logger.info(msg));
        if (check.valid) {
          const expiry = loadGrokExpiry();
          const expiryLine = expiry ? `\n🕐 ${formatExpiryInfo(expiry)}` : "";
          return { text: `✅ grok.com session active\nProxy: \`127.0.0.1:${port}\`\nModels: web-grok/grok-3, web-grok/grok-3-fast, web-grok/grok-3-mini, web-grok/grok-3-mini-fast${expiryLine}` };
        }
        grokContext = null;
        return { text: `❌ Session expired: ${check.reason}\nRun \`/grok-login\` to re-authenticate.` };
      },
    } satisfies OpenClawPluginCommandDefinition);

    api.registerCommand({
      name: "grok-logout",
      description: "Disconnect from grok.com session (does not close the browser)",
      handler: async (): Promise<PluginCommandResult> => {
        grokContext = null;
        deleteSession(grokSessionPath);
        return { text: "✅ Disconnected from grok.com. Run `/grok-login` to reconnect." };
      },
    } satisfies OpenClawPluginCommandDefinition);

    // ── Claude web-session commands ───────────────────────────────────────────
    api.registerCommand({
      name: "claude-login",
      description: "Authenticate claude.ai: imports session from OpenClaw browser",
      handler: async (): Promise<PluginCommandResult> => {
        if (claudeContext) {
          const { getOrCreateClaudePage } = await import("./src/claude-browser.js");
          try {
            const { page } = await getOrCreateClaudePage(claudeContext);
            const editor = await page.locator(".ProseMirror").isVisible().catch(() => false);
            if (editor) return { text: "✅ Already connected to claude.ai. Use `/claude-logout` first to reset." };
          } catch { /* fall through */ }
          claudeContext = null;
        }

        api.logger.info("[cli-bridge:claude] /claude-login: connecting to OpenClaw browser…");

        // Connect to OpenClaw browser context for session (singleton CDP)
        const ctx = await connectToOpenClawBrowser((msg) => api.logger.info(msg));
        if (!ctx) return { text: "❌ Could not connect to OpenClaw browser.\nMake sure claude.ai is open in your browser." };

        // Navigate to claude.ai/new if not already there
        const { getOrCreateClaudePage } = await import("./src/claude-browser.js");
        let page;
        try {
          ({ page } = await getOrCreateClaudePage(ctx));
        } catch (err) {
          return { text: `❌ Failed to open claude.ai: ${(err as Error).message}` };
        }

        // Verify editor is visible
        const editor = await page.locator(".ProseMirror").isVisible().catch(() => false);
        if (!editor) {
          return { text: "❌ claude.ai editor not visible — are you logged in?\nOpen claude.ai in your browser and try again." };
        }

        claudeContext = ctx;

        // Export + bake cookies into persistent profile
        const claudeProfileDir = join(homedir(), ".openclaw", "claude-profile");
        mkdirSync(claudeProfileDir, { recursive: true });
        try {
          const allCookies = await ctx.cookies([
            "https://claude.ai",
            "https://anthropic.com",
          ]);
          const { chromium } = await import("playwright");
          const pCtx = await chromium.launchPersistentContext(claudeProfileDir, {
            headless: true,
            args: ["--no-sandbox", "--disable-setuid-sandbox"],
          });
          await pCtx.addCookies(allCookies);
          await pCtx.close();
          api.logger.info(`[cli-bridge:claude] cookies baked into ${claudeProfileDir}`);
        } catch (err) {
          api.logger.warn(`[cli-bridge:claude] cookie bake failed: ${(err as Error).message}`);
        }

        // Scan cookie expiry
        const expiry = await scanClaudeCookieExpiry(ctx);
        if (expiry) {
          saveClaudeExpiry(expiry);
          api.logger.info(`[cli-bridge:claude] cookie expiry: ${new Date(expiry.expiresAt).toISOString()}`);
        }
        const expiryLine = expiry ? `\n\n🕐 Cookie expiry: ${formatClaudeExpiry(expiry)}` : "";

        return { text: `✅ claude.ai session ready!\n\nModels available:\n• \`vllm/web-claude/claude-sonnet\`\n• \`vllm/web-claude/claude-opus\`\n• \`vllm/web-claude/claude-haiku\`${expiryLine}` };
      },
    } satisfies OpenClawPluginCommandDefinition);

    api.registerCommand({
      name: "claude-status",
      description: "Check claude.ai session status",
      handler: async (): Promise<PluginCommandResult> => {
        if (!claudeContext) {
          return { text: "❌ No active claude.ai session\nRun `/claude-login` to authenticate." };
        }
        const { getOrCreateClaudePage } = await import("./src/claude-browser.js");
        try {
          const { page } = await getOrCreateClaudePage(claudeContext);
          const editor = await page.locator(".ProseMirror").isVisible().catch(() => false);
          if (editor) {
            const expiry = loadClaudeExpiry();
            const expiryLine = expiry ? `\n🕐 ${formatClaudeExpiry(expiry)}` : "";
            return { text: `✅ claude.ai session active\nProxy: \`127.0.0.1:${port}\`\nModels: web-claude/claude-sonnet, web-claude/claude-opus, web-claude/claude-haiku${expiryLine}` };
          }
        } catch { /* fall through */ }
        claudeContext = null;
        return { text: "❌ Session lost — run `/claude-login` to re-authenticate." };
      },
    } satisfies OpenClawPluginCommandDefinition);

    api.registerCommand({
      name: "claude-logout",
      description: "Disconnect from claude.ai session",
      handler: async (): Promise<PluginCommandResult> => {
        claudeContext = null;
        return { text: "✅ Disconnected from claude.ai. Run `/claude-login` to reconnect." };
      },
    } satisfies OpenClawPluginCommandDefinition);

    // ── Gemini web-session commands ───────────────────────────────────────────
    api.registerCommand({
      name: "gemini-login",
      description: "Authenticate gemini.google.com: imports session from OpenClaw browser",
      handler: async (): Promise<PluginCommandResult> => {
        if (geminiContext) {
          const { getOrCreateGeminiPage } = await import("./src/gemini-browser.js");
          try {
            const { page } = await getOrCreateGeminiPage(geminiContext);
            const editor = await page.locator(".ql-editor").isVisible().catch(() => false);
            if (editor) return { text: "✅ Already connected to gemini.google.com. Use `/gemini-logout` first to reset." };
          } catch { /* fall through */ }
          geminiContext = null;
        }

        api.logger.info("[cli-bridge:gemini] /gemini-login: connecting to OpenClaw browser…");
        const ctx = await connectToOpenClawBrowser((msg) => api.logger.info(msg));
        if (!ctx) return { text: "❌ Could not connect to OpenClaw browser.\nMake sure gemini.google.com is open in your browser." };

        const { getOrCreateGeminiPage } = await import("./src/gemini-browser.js");
        let page;
        try {
          ({ page } = await getOrCreateGeminiPage(ctx));
        } catch (err) {
          return { text: `❌ Failed to open gemini.google.com: ${(err as Error).message}` };
        }

        const editor = await page.locator(".ql-editor").isVisible().catch(() => false);
        if (!editor) {
          return { text: "❌ Gemini editor not visible — are you logged in?\nOpen gemini.google.com in your browser and try again." };
        }

        geminiContext = ctx;

        // Export + bake cookies into persistent profile
        const geminiProfileDir = join(homedir(), ".openclaw", "gemini-profile");
        mkdirSync(geminiProfileDir, { recursive: true });
        try {
          const allCookies = await ctx.cookies([
            "https://gemini.google.com",
            "https://accounts.google.com",
            "https://google.com",
          ]);
          const { chromium } = await import("playwright");
          const pCtx = await chromium.launchPersistentContext(geminiProfileDir, {
            headless: true,
            args: ["--no-sandbox", "--disable-setuid-sandbox"],
          });
          await pCtx.addCookies(allCookies);
          await pCtx.close();
          api.logger.info(`[cli-bridge:gemini] cookies baked into ${geminiProfileDir}`);
        } catch (err) {
          api.logger.warn(`[cli-bridge:gemini] cookie bake failed: ${(err as Error).message}`);
        }

        const expiry = await scanGeminiCookieExpiry(ctx);
        if (expiry) {
          saveGeminiExpiry(expiry);
          api.logger.info(`[cli-bridge:gemini] cookie expiry: ${new Date(expiry.expiresAt).toISOString()}`);
        }
        const expiryLine = expiry ? `\n\n🕐 Cookie expiry: ${formatGeminiExpiry(expiry)}` : "";

        return { text: `✅ Gemini session ready!\n\nModels available:\n• \`vllm/web-gemini/gemini-2-5-pro\`\n• \`vllm/web-gemini/gemini-2-5-flash\`\n• \`vllm/web-gemini/gemini-3-pro\`\n• \`vllm/web-gemini/gemini-3-flash\`${expiryLine}` };
      },
    } satisfies OpenClawPluginCommandDefinition);

    api.registerCommand({
      name: "gemini-status",
      description: "Check gemini.google.com session status",
      handler: async (): Promise<PluginCommandResult> => {
        if (!geminiContext) {
          return { text: "❌ No active gemini.google.com session\nRun `/gemini-login` to authenticate." };
        }
        const { getOrCreateGeminiPage } = await import("./src/gemini-browser.js");
        try {
          const { page } = await getOrCreateGeminiPage(geminiContext);
          const editor = await page.locator(".ql-editor").isVisible().catch(() => false);
          if (editor) {
            const expiry = loadGeminiExpiry();
            const expiryLine = expiry ? `\n🕐 ${formatGeminiExpiry(expiry)}` : "";
            return { text: `✅ gemini.google.com session active\nProxy: \`127.0.0.1:${port}\`\nModels: web-gemini/gemini-2-5-pro, gemini-2-5-flash, gemini-3-pro, gemini-3-flash${expiryLine}` };
          }
        } catch { /* fall through */ }
        geminiContext = null;
        return { text: "❌ Session lost — run `/gemini-login` to re-authenticate." };
      },
    } satisfies OpenClawPluginCommandDefinition);

    api.registerCommand({
      name: "gemini-logout",
      description: "Disconnect from gemini.google.com session",
      handler: async (): Promise<PluginCommandResult> => {
        geminiContext = null;
        return { text: "✅ Disconnected from gemini.google.com. Run `/gemini-login` to reconnect." };
      },
    } satisfies OpenClawPluginCommandDefinition);

    // ── ChatGPT web-session commands ──────────────────────────────────────────
    api.registerCommand({
      name: "chatgpt-login",
      description: "Authenticate chatgpt.com: imports session from OpenClaw browser",
      handler: async (): Promise<PluginCommandResult> => {
        if (chatgptContext) {
          const { getOrCreateChatGPTPage } = await import("./src/chatgpt-browser.js");
          try {
            const { page } = await getOrCreateChatGPTPage(chatgptContext);
            if (await page.locator("#prompt-textarea").isVisible().catch(() => false))
              return { text: "✅ Already connected to chatgpt.com. Use `/chatgpt-logout` first to reset." };
          } catch { /* fall through */ }
          chatgptContext = null;
        }
        api.logger.info("[cli-bridge:chatgpt] /chatgpt-login: connecting to OpenClaw browser…");
        const ctx = await connectToOpenClawBrowser((msg) => api.logger.info(msg));
        if (!ctx) return { text: "❌ Could not connect to OpenClaw browser.\nMake sure chatgpt.com is open in your browser." };

        const { getOrCreateChatGPTPage } = await import("./src/chatgpt-browser.js");
        let page;
        try { ({ page } = await getOrCreateChatGPTPage(ctx)); }
        catch (err) { return { text: `❌ Failed to open chatgpt.com: ${(err as Error).message}` }; }

        if (!await page.locator("#prompt-textarea").isVisible().catch(() => false))
          return { text: "❌ ChatGPT editor not visible — are you logged in?\nOpen chatgpt.com in your browser and try again." };

        chatgptContext = ctx;

        // Export + bake cookies into persistent profile
        const chatgptProfileDir = join(homedir(), ".openclaw", "chatgpt-profile");
        mkdirSync(chatgptProfileDir, { recursive: true });
        try {
          const allCookies = await ctx.cookies([
            "https://chatgpt.com",
            "https://openai.com",
            "https://auth.openai.com",
          ]);
          const { chromium } = await import("playwright");
          const pCtx = await chromium.launchPersistentContext(chatgptProfileDir, {
            headless: true,
            args: ["--no-sandbox", "--disable-setuid-sandbox"],
          });
          await pCtx.addCookies(allCookies);
          await pCtx.close();
          api.logger.info(`[cli-bridge:chatgpt] cookies baked into ${chatgptProfileDir}`);
        } catch (err) {
          api.logger.warn(`[cli-bridge:chatgpt] cookie bake failed: ${(err as Error).message}`);
        }

        const expiry = await scanChatGPTCookieExpiry(ctx);
        if (expiry) { saveChatGPTExpiry(expiry); api.logger.info(`[cli-bridge:chatgpt] cookie expiry: ${new Date(expiry.expiresAt).toISOString()}`); }
        const expiryLine = expiry ? `\n\n🕐 Cookie expiry: ${formatChatGPTExpiry(expiry)}` : "";
        return { text: `✅ ChatGPT session ready!\n\nModels available:\n• \`vllm/web-chatgpt/gpt-4o\`\n• \`vllm/web-chatgpt/gpt-4o-mini\`\n• \`vllm/web-chatgpt/gpt-o3\`\n• \`vllm/web-chatgpt/gpt-o4-mini\`\n• \`vllm/web-chatgpt/gpt-5\`${expiryLine}` };
      },
    } satisfies OpenClawPluginCommandDefinition);

    api.registerCommand({
      name: "chatgpt-status",
      description: "Check chatgpt.com session status",
      handler: async (): Promise<PluginCommandResult> => {
        if (!chatgptContext) return { text: "❌ No active chatgpt.com session\nRun `/chatgpt-login` to authenticate." };
        const { getOrCreateChatGPTPage } = await import("./src/chatgpt-browser.js");
        try {
          const { page } = await getOrCreateChatGPTPage(chatgptContext);
          if (await page.locator("#prompt-textarea").isVisible().catch(() => false)) {
            const expiry = loadChatGPTExpiry();
            const expiryLine = expiry ? `\n🕐 ${formatChatGPTExpiry(expiry)}` : "";
            return { text: `✅ chatgpt.com session active\nProxy: \`127.0.0.1:${port}\`\nModels: web-chatgpt/gpt-4o, gpt-4o-mini, gpt-o3, gpt-o4-mini, gpt-5${expiryLine}` };
          }
        } catch { /* fall through */ }
        chatgptContext = null;
        return { text: "❌ Session lost — run `/chatgpt-login` to re-authenticate." };
      },
    } satisfies OpenClawPluginCommandDefinition);

    api.registerCommand({
      name: "chatgpt-logout",
      description: "Disconnect from chatgpt.com session",
      handler: async (): Promise<PluginCommandResult> => {
        chatgptContext = null;
        return { text: "✅ Disconnected from chatgpt.com. Run `/chatgpt-login` to reconnect." };
      },
    } satisfies OpenClawPluginCommandDefinition);

    // ── /bridge-status — all providers at a glance ───────────────────────────
    api.registerCommand({
      name: "bridge-status",
      description: "Show status of all headless browser providers (Grok, Claude, Gemini, ChatGPT)",
      handler: async (): Promise<PluginCommandResult> => {
        const lines: string[] = [`🌉 *CLI Bridge v${plugin.version} — Provider Status*\n`];

        const checks = [
          {
            name: "Grok",
            ctx: grokContext,
            check: async () => {
              if (!grokContext) return false;
              const r = await verifySession(grokContext, () => {});
              if (!r.valid) { grokContext = null; }
              return r.valid;
            },
            models: "web-grok/grok-3, grok-3-fast, grok-3-mini",
            loginCmd: "/grok-login",
            expiry: () => { const e = loadGrokExpiry(); return e ? formatExpiryInfo(e) : null; },
          },
          {
            name: "Claude",
            ctx: claudeContext,
            check: async () => {
              if (!claudeContext) return false;
              try {
                const { getOrCreateClaudePage } = await import("./src/claude-browser.js");
                const { page } = await getOrCreateClaudePage(claudeContext);
                return page.locator(".ProseMirror").isVisible().catch(() => false);
              } catch { claudeContext = null; return false; }
            },
            models: "web-claude/claude-sonnet, claude-opus, claude-haiku",
            loginCmd: "/claude-login",
            expiry: () => { const e = loadClaudeExpiry(); return e ? formatClaudeExpiry(e) : null; },
          },
          {
            name: "Gemini",
            ctx: geminiContext,
            check: async () => {
              if (!geminiContext) return false;
              try {
                const { getOrCreateGeminiPage } = await import("./src/gemini-browser.js");
                const { page } = await getOrCreateGeminiPage(geminiContext);
                return page.locator(".ql-editor").isVisible().catch(() => false);
              } catch { geminiContext = null; return false; }
            },
            models: "web-gemini/gemini-2-5-pro, gemini-2-5-flash, gemini-3-pro, gemini-3-flash",
            loginCmd: "/gemini-login",
            expiry: () => { const e = loadGeminiExpiry(); return e ? formatGeminiExpiry(e) : null; },
          },
          {
            name: "ChatGPT",
            ctx: chatgptContext,
            check: async () => {
              if (!chatgptContext) return false;
              try {
                const { getOrCreateChatGPTPage } = await import("./src/chatgpt-browser.js");
                const { page } = await getOrCreateChatGPTPage(chatgptContext);
                return page.locator("#prompt-textarea").isVisible().catch(() => false);
              } catch { chatgptContext = null; return false; }
            },
            models: "web-chatgpt/gpt-4o, gpt-o3, gpt-o4-mini, gpt-5",
            loginCmd: "/chatgpt-login",
            expiry: () => { const e = loadChatGPTExpiry(); return e ? formatChatGPTExpiry(e) : null; },
          },
        ];

        for (const c of checks) {
          const active = c.ctx !== null;
          const ok = active ? await c.check() : false;
          const expiry = c.expiry();
          if (ok) {
            lines.push(`✅ *${c.name}* — active`);
            if (expiry) lines.push(`   🕐 ${expiry}`);
            lines.push(`   Models: ${c.models}`);
          } else {
            lines.push(`❌ *${c.name}* — not connected (run \`${c.loginCmd}\`)`);
          }
          lines.push("");
        }

        lines.push(`🔌 Proxy: \`127.0.0.1:${port}\` | 22 models total`);
        return { text: lines.join("\n") };
      },
    } satisfies OpenClawPluginCommandDefinition);
    // ─────────────────────────────────────────────────────────────────────────

    const allCommands = [
      ...CLI_MODEL_COMMANDS.map((c) => `/${c.name}`),
      "/cli-back",
      "/cli-test",
      "/cli-list",
      "/grok-login",
      "/grok-status",
      "/grok-logout",
      "/claude-login",
      "/claude-status",
      "/claude-logout",
      "/gemini-login",
      "/gemini-status",
      "/gemini-logout",
      "/chatgpt-login",
      "/chatgpt-status",
      "/chatgpt-logout",
      "/bridge-status",
    ];
    api.logger.info(`[cli-bridge] registered ${allCommands.length} commands: ${allCommands.join(", ")}`);
  },
};

export default plugin;
