---
name: journai-flight-mcp
description: 智程机票出行 MCP 工具调用指南 — 教 Agent 通过 curl + JSON-RPC 调用航班搜索、预订、退改签、发票等 14 个工具
---

# JournAI 机票出行 MCP 工具调用指南

本技能教你如何正确调用 JournAI MCP Server 的机票出行工具。读完本指南，你就能通过 curl 直接调用所有工具，不需要了解 MCP 协议细节。

---

## 一、调用方式

### 基础信息

| 项目 | 值 |
|------|-----|
| 端点 | `https://fly.huoli.com/mcp/flight_server` |
| 方法 | `POST` |
| Content-Type | `application/json` |
| 认证 | `Authorization: Bearer <api-key>` |

> API Key 绑定用户身份，所有调用自动关联该用户，无需传递用户标识。
> C 端用户获取 API Key：https://h5.133.cn/webapp/pages/mcpApiKey

### 统一调用格式

```bash
curl -s -X POST https://fly.huoli.com/mcp/flight_server \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{
    "jsonrpc": "2.0",
    "id": 1,
    "method": "tools/call",
    "params": {
      "name": "<工具名>",
      "arguments": { ... }
    }
  }'
```

### 响应结构

```json
{"success": true, "data": {...}, "errorCode": null, "errorMessage": null}
```

检查 `success` 字段判断是否成功。业务错误通过 `errorCode` + `errorMessage` 返回，HTTP 状态码仍为 200。

---

## 二、隐私与个人信息（PII）说明

预订、退票、改签等功能会将用户提供的**个人信息**（联系人姓名、手机号、乘机人姓名、证件号、出生日期、国籍等）通过 HTTP POST 发送至 JournAI MCP 远端服务（`https://fly.huoli.com/mcp/flight_server`），以完成机票业务操作。使用本 skill 即表示用户知晓并同意上述 PII 被发送到外部服务。**请勿在日志、回复或任何输出中暴露用户个人信息。**

---

## 三、铁律（违反即出错）

### 铁律 1：写操作必须用 AskUserQuestion 确认

以下 6 个工具会修改数据（`destructiveHint: true`），**调用前必须使用 AskUserQuestion 工具向用户确认**，用户明确同意后才能调用：

- `uni_order_create` — 预订机票
- `uni_order_cancel` — 取消订单
- `refund_submit` — 提交退票
- `reroute_submit` — 提交改签
- `submit_invoice` — 提交发票申请
- `manage_invoice` — 发票取消/修改/重发

**确认方式：** 使用 AskUserQuestion，question 中说明即将执行的操作和关键信息（航班号、金额等），让用户选择"确认"或"取消"。

### 铁律 2：严格按步骤，不可跳步

退票和改签有严格的流程顺序，缺少前置步骤的调用必然失败：

**退票：** `uni_order_query` → `refund_query_fee` → 用户确认 → `refund_submit`
**改签：** `uni_order_query` → `reroute_query_flight_filter` → `reroute_confirm` → 用户确认 → `reroute_submit`

### 铁律 3：禁止编造参数

以下参数必须从上游接口返回值获取，**自行编造必然导致调用失败**：

`priceId` `flightInfoId` `orderSource` `ticketId` `tripId` `voucherOrderInfo` `postId`

### 铁律 4：国内/国际参数不同

`refund_submit` 和 `reroute_submit` 根据订单号前缀选参数：

- `D` 开头（国内）→ 用 `ticketIds` + 航班信息
- `I` 开头（国际）→ 用 `tripInfoList` + `contacts`

### 铁律 5：多选项必须用 AskUserQuestion

需要用户从多个选项中选择时（选航班、选退哪张票等），**必须使用 AskUserQuestion 工具**展示选项列表让用户选择。

---

## 四、工具决策树

```
用户意图
├── 搜索航班 → search_flights → get_flight_offers → [确认] → uni_order_create
├── 查订单 → uni_order_query
├── 取消订单 → uni_order_cancel（仅限未支付）
├── 退票 → refund_query_fee → [确认] → refund_submit
├── 改签 → reroute_query_flight_filter → [选航班] → reroute_confirm → [确认] → reroute_submit
└── 发票 → query_invoiceable → submit_invoice / query_invoices / manage_invoice
```

---

## 五、工具详解

---

### search_flights — 搜索航班

搜索指定日期航班。出发地/目的地支持城市码或机场码四种组合。

**必填：** `date` + (`departureCityCode` 或 `departureAirportCode`) + (`arrivalCityCode` 或 `arrivalAirportCode`)
**可选：** `adultNum` `cabinPreference`(Y/S/C/F) `sortBy`(price/totalPrice/departureTime/arrivalTime/duration) `sortOrder`(asc/desc) `page` `pageSize` `maxPrice` `maxTotalPrice` `maxTransferCount` `onlyDirect` `excludeShare` `preferredAirlines` `excludeAirlines`

```bash
curl -s -X POST https://fly.huoli.com/mcp/flight_server \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{
    "jsonrpc":"2.0","id":1,"method":"tools/call",
    "params":{
      "name":"search_flights",
      "arguments":{
        "departureCityCode":"BJS","arrivalCityCode":"SHA",
        "date":"2026-05-15","adultNum":"1","cabinPreference":"Y",
        "sortBy":"price","sortOrder":"asc","pageSize":5
      }
    }
  }'
```

---

### get_flight_offers — 获取航班报价

查询指定航班行程的报价详情、舱位分组及可选附加产品。需先调用 `search_flights` 获取 `flightInfoId`。此工具返回的 `priceId`、`flightInfoId`、`orderSource` 是预订（`uni_order_create`）的必需参数。

**必填：** `flightInfoId`(从 search_flights 获取) `traceId`(调用方生成的唯一标识)
**可选：** `priceId`(指定时获取舱位详情) `from` `phoneId` `adultNum`(默认1) `childNum`(默认0) `cabinPreference`(Y/S/C/F)

```bash
curl -s -X POST https://fly.huoli.com/mcp/flight_server \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{
    "jsonrpc":"2.0","id":2,"method":"tools/call",
    "params":{
      "name":"get_flight_offers",
      "arguments":{
        "flightInfoId":"从search_flights返回获取",
        "traceId":"uuid-或自定义唯一标识",
        "adultNum":"1",
        "cabinPreference":"Y"
      }
    }
  }'
```

指定 priceId 获取舱位详情（用于确认预订参数）：

```bash
curl -s -X POST https://fly.huoli.com/mcp/flight_server \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{
    "jsonrpc":"2.0","id":2,"method":"tools/call",
    "params":{
      "name":"get_flight_offers",
      "arguments":{
        "flightInfoId":"从search_flights返回获取",
        "traceId":"uuid-或自定义唯一标识",
        "priceId":"从search_flights返回获取"
      }
    }
  }'
```

---

### uni_order_create — 机票预订 [需确认]

预订国内/国际机票。`priceId` `flightInfoId` `orderSource` 从 `get_flight_offers` 获取。

**必填：** `priceId` `flightInfoId` `orderSource`(domestic/international) `contactName` `contactPhoneCode` `contactPhone` `passengers[]`
**乘客必填：** `name` `idType`(0-9) `idCard` `phoneCode` `phone` `type`(ADT/CHD) `gender`(M/F)
**国际额外必填：** `birthday` `nationality` `issueNa` `validDate`（且 idType 不能为 0）

```bash
# 国内预订（身份证）
curl -s -X POST https://fly.huoli.com/mcp/flight_server \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{
    "jsonrpc":"2.0","id":3,"method":"tools/call",
    "params":{
      "name":"uni_order_create",
      "arguments":{
        "priceId":"从get_flight_offers获取","flightInfoId":"从get_flight_offers获取",
        "orderSource":"domestic","totalPrice":1280,
        "contactName":"张三","contactPhoneCode":"86","contactPhone":"13800138000",
        "passengers":[{
          "name":"张三","idType":0,"idCard":"110101199001011234",
          "phoneCode":"86","phone":"13800138000","type":"ADT","gender":"M"
        }]
      }
    }
  }'
```

```bash
# 国际预订（护照，需额外字段）
curl -s -X POST https://fly.huoli.com/mcp/flight_server \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{
    "jsonrpc":"2.0","id":3,"method":"tools/call",
    "params":{
      "name":"uni_order_create",
      "arguments":{
        "priceId":"从get_flight_offers获取","flightInfoId":"从get_flight_offers获取",
        "orderSource":"international","totalPrice":5680,
        "contactName":"Zhang San","contactPhoneCode":"86","contactPhone":"13800138000",
        "passengers":[{
          "name":"Zhang San","idType":1,"idCard":"E12345678",
          "phoneCode":"86","phone":"13800138000","type":"ADT","gender":"M",
          "birthday":"1990-01-01","nationality":"CN","issueNa":"CN","validDate":"2030-12-31"
        }]
      }
    }
  }'
```

---

### uni_order_query — 订单查询

查询订单列表或详情。不传 `orderId` 返回列表，传入返回详情（含 ticketId，退改签必需）。

**可选：** `orderSource`(domestic/international) `orderId`

```bash
# 查列表
curl -s -X POST https://fly.huoli.com/mcp/flight_server \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{"jsonrpc":"2.0","id":3,"method":"tools/call","params":{"name":"uni_order_query","arguments":{}}}'

# 查详情
curl -s -X POST https://fly.huoli.com/mcp/flight_server \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{"jsonrpc":"2.0","id":3,"method":"tools/call","params":{"name":"uni_order_query","arguments":{"orderId":"D20260501001"}}}'
```

---

### uni_order_cancel — 取消订单 [需确认]

取消未支付订单。已支付请走退票流程。**必填：** `orderId`

```bash
curl -s -X POST https://fly.huoli.com/mcp/flight_server \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{"jsonrpc":"2.0","id":4,"method":"tools/call","params":{"name":"uni_order_cancel","arguments":{"orderId":"D20260501001"}}}'
```

---

### refund_query_fee — 退票费计算

查询退票手续费和可退金额。`ticketIds` 从 `uni_order_query` 详情获取。

**必填：** `orderId` `ticketIds`(数组) `refundType`(0=自愿, 1=非自愿)

```bash
curl -s -X POST https://fly.huoli.com/mcp/flight_server \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{"jsonrpc":"2.0","id":5,"method":"tools/call","params":{"name":"refund_query_fee","arguments":{"orderId":"D20260501001","ticketIds":["ticket_id_from_query"],"refundType":0}}}'
```

---

### refund_submit — 退票申请 [需确认]

提交退票申请。国内用 `ticketIds`，国际用 `tripInfoList`+`contacts`。

**必填：** `orderId` `refundType`(0=自愿, 1=非自愿)
**国内必填：** `ticketIds`
**国内非自愿额外：** `refundReasonType`(0-5) `url`(附件)
**国际必填：** `tripInfoList`(segmentIds+passengerIds) `contacts`(phone)

```bash
# 国内自愿退票
curl -s -X POST https://fly.huoli.com/mcp/flight_server \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{"jsonrpc":"2.0","id":6,"method":"tools/call","params":{"name":"refund_submit","arguments":{"orderId":"D20260501001","refundType":0,"ticketIds":["ticket_id_from_query"]}}}'

# 国内非自愿退票（航班取消）
curl -s -X POST https://fly.huoli.com/mcp/flight_server \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{"jsonrpc":"2.0","id":6,"method":"tools/call","params":{"name":"refund_submit","arguments":{"orderId":"D20260501001","refundType":1,"ticketIds":["ticket_id"],"refundReasonType":2,"url":"https://example.com/proof.png","refundRemark":"航班取消"}}}'

# 国际退票
curl -s -X POST https://fly.huoli.com/mcp/flight_server \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{"jsonrpc":"2.0","id":6,"method":"tools/call","params":{"name":"refund_submit","arguments":{"orderId":"I20260501001","refundType":0,"tripInfoList":[{"segmentIds":["seg_id"],"passengerIds":["pax_id"]}],"contacts":{"phone":"13800138000"}}}}'
```

---

### reroute_query_flight_filter — 改期航班列表

查询可改签航班。`ticketIds` 从 `uni_order_query` 获取。

**必填：** `orderId` `ticketIds`(数组) `date` `rerouteType`(0=自愿, 1=非自愿)
**可选：** `filterType`(0=不筛选, 1=按时间最近, 2=按价格差最少, 3=同时筛选)

```bash
curl -s -X POST https://fly.huoli.com/mcp/flight_server \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{"jsonrpc":"2.0","id":7,"method":"tools/call","params":{"name":"reroute_query_flight_filter","arguments":{"orderId":"D20260501001","ticketIds":["ticket_id"],"date":"2026-05-20","rerouteType":0,"filterType":1}}}'
```

---

### reroute_confirm — 改期费计算

锁定改签航班并获取费用明细。`tripId` `priceId` 从 `reroute_query_flight_filter` 获取。

**必填：** `orderId` `ticketIds` `tripId` `priceId` `date` `rerouteType`

```bash
curl -s -X POST https://fly.huoli.com/mcp/flight_server \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{"jsonrpc":"2.0","id":8,"method":"tools/call","params":{"name":"reroute_confirm","arguments":{"orderId":"D20260501001","ticketIds":["ticket_id"],"tripId":"trip_id_from_filter","priceId":"price_id_from_filter","date":"2026-05-20","rerouteType":0}}}'
```

---

### reroute_submit — 改期申请 [需确认]

提交改签申请。国内用 `ticketIds`+航班信息，国际用 `tripInfoList`+`contacts`+`expectTravelList`。

**必填：** `orderId` `rerouteType`(0=自愿, 1=非自愿)
**国内必填：** `ticketIds` `date` `flightNo` `departureAirportCode` `arrivalAirportCode`
**国际必填：** `tripInfoList`(segmentIds+passengerIds) `contacts`(phone) `expectTravelList`(tripIndex+date)

```bash
# 国内改期
curl -s -X POST https://fly.huoli.com/mcp/flight_server \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{"jsonrpc":"2.0","id":9,"method":"tools/call","params":{"name":"reroute_submit","arguments":{"orderId":"D20260501001","rerouteType":0,"ticketIds":["ticket_id"],"date":"2026-05-20","flightNo":"CA1234","departureAirportCode":"PEK","arrivalAirportCode":"PVG"}}}'

# 国际改期
curl -s -X POST https://fly.huoli.com/mcp/flight_server \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{"jsonrpc":"2.0","id":9,"method":"tools/call","params":{"name":"reroute_submit","arguments":{"orderId":"I20260501001","rerouteType":0,"tripInfoList":[{"segmentIds":["seg_id"],"passengerIds":["pax_id"]}],"contacts":{"phone":"13800138000"},"expectTravelList":[{"tripIndex":1,"date":"2026-05-25"}],"travelRemark":"尽量上午航班"}}}'
```

---

### query_invoiceable — 可报销列表查询

查询可开票订单。不传查全部，传 `orderId` 查指定订单。

**可选：** `orderId` `pageSize`

```bash
# 全部可开票
curl -s -X POST https://fly.huoli.com/mcp/flight_server \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{"jsonrpc":"2.0","id":10,"method":"tools/call","params":{"name":"query_invoiceable","arguments":{}}}'

# 指定订单
curl -s -X POST https://fly.huoli.com/mcp/flight_server \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{"jsonrpc":"2.0","id":10,"method":"tools/call","params":{"name":"query_invoiceable","arguments":{"orderId":"D20260501001"}}}'
```

---

### submit_invoice — 报销凭证提交 [需确认]

提交发票申请。`voucherOrderInfo` 从 `query_invoiceable` 获取。

**必填：** `orderId` `voucherOrderInfo` `email` `title` `invoiceTitleType`(0=个人, 1=企业, 2=机关事业单位军队)
**企业时必填：** `identityId`(纳税人识别号)

```bash
# 个人发票
curl -s -X POST https://fly.huoli.com/mcp/flight_server \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{"jsonrpc":"2.0","id":11,"method":"tools/call","params":{"name":"submit_invoice","arguments":{"orderId":"D20260501001","voucherOrderInfo":"从query_invoiceable获取","email":"zhangsan@example.com","title":"张三","invoiceTitleType":0}}}'

# 企业发票
curl -s -X POST https://fly.huoli.com/mcp/flight_server \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{"jsonrpc":"2.0","id":11,"method":"tools/call","params":{"name":"submit_invoice","arguments":{"orderId":"D20260501001","voucherOrderInfo":"从query_invoiceable获取","email":"finance@example.com","title":"深圳某某科技有限公司","invoiceTitleType":1,"identityId":"91440300XXXXXXXXXX"}}}'
```

---

### query_invoices — 已提交凭证查询

查询发票记录。`postId` 查详情，`orderId` 查订单历史，都空查全部。

**可选：** `postId` `orderId` `pageNum` `pageSize`

```bash
# 全部历史
curl -s -X POST https://fly.huoli.com/mcp/flight_server \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{"jsonrpc":"2.0","id":12,"method":"tools/call","params":{"name":"query_invoices","arguments":{}}}'

# 包裹详情
curl -s -X POST https://fly.huoli.com/mcp/flight_server \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{"jsonrpc":"2.0","id":12,"method":"tools/call","params":{"name":"query_invoices","arguments":{"postId":"P20260501001"}}}'
```

---

### manage_invoice — 报销凭证管理 [需确认]

发票操作：取消(cancel)、修改(update)、重发(resend)。`postId` 从 `query_invoices` 获取。

**必填：** `action`(cancel/update/resend) `postId` `orderId`
**resend 必填：** `email`
**update 可选：** `email` `title` `invoiceTitleType` `identityId`（至少填一个）

> 操作前先调 `query_invoices` 确认可操作状态（canCancel/canUpdate/canResend）。

```bash
# 取消
curl -s -X POST https://fly.huoli.com/mcp/flight_server \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{"jsonrpc":"2.0","id":13,"method":"tools/call","params":{"name":"manage_invoice","arguments":{"action":"cancel","postId":"P20260501001","orderId":"D20260501001"}}}'

# 修改抬头
curl -s -X POST https://fly.huoli.com/mcp/flight_server \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{"jsonrpc":"2.0","id":13,"method":"tools/call","params":{"name":"manage_invoice","arguments":{"action":"update","postId":"P20260501001","orderId":"D20260501001","title":"深圳某某科技有限公司","invoiceTitleType":1,"identityId":"91440300XXXXXXXXXX"}}}'

# 重发到新邮箱
curl -s -X POST https://fly.huoli.com/mcp/flight_server \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{"jsonrpc":"2.0","id":13,"method":"tools/call","params":{"name":"manage_invoice","arguments":{"action":"resend","postId":"P20260501001","orderId":"D20260501001","email":"newemail@example.com"}}}'
```

---

## 六、数据字典

完整的数据字典（证件类型、舱位代码、退票原因、改签筛选、城市三字码、通用约定）请见 [reference.md](reference.md)。