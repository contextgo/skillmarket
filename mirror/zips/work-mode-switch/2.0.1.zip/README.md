# work-mode-switch

SuperMike 工作模式切换技�?- 12 种工作模式，支持灵活切换协作节奏�?
**SuperMike Work Mode Switch Skill - 12 work modes for flexible AI collaboration.**

---

## 📖 功能简�?/ Features

本技能定义了 12 种工作模式，帮助用户根据任务类型灵活调整 AI 助手的行为方式�?
This skill defines 12 work modes, enabling users to flexibly adjust AI assistant behavior based on task type.

| 模式 / Mode | 用�?/ Purpose | 约束强度 / Constraint |
|-------------|----------------|----------------------|
| 🟢 **自由 / Free** (默认) | 边说边干、灵活应�?| �?/ Low |
| 💬 **闲聊 / Chat** | 轻松对话、不记录 | �?/ Low |
| 🟡 **讨论规划 / Discuss & Plan** | 提问记录、不执行 | �?/ Medium |
| 🔍 **研究 / Research** | 文献调研、信息整�?| �?/ Medium |
| 🔴 **深度研究 / Deep Research** | 多智能体独立推进 | �?/ High |
| 📝 **写作 / Writing** | 撰写文档/论文 | �?/ Medium |
| 💻 **编码 / Coding** | 编写/调试代码 | �?/ Medium |
| 🌐 **翻译 / Translation** | 中英文互�?| �?/ Medium |
| �?**执行 / Execute** | 直接干活、创建文�?| �?/ Medium |
| 🔵 **审核 / Review** | 审稿/评审/检�?| �?/ Medium |
| 🟣 **自检 / Self-Check** | 系统健康检�?| �?/ High |
| 🟠 **自学 / Self-Learn** | 独立学习提升 | �?/ High |

---

## 🚀 快速开�?/ Quick Start

### 安装 / Installation

```bash
# 通过 ClawHub 安装 / Install via ClawHub
clawhub install work-mode-switch

# 或手动复�?/ Or manually copy
cp -r skills/work-mode-switch ~/.openclaw/skills/
```

### 使用 / Usage

**模式切换命令 / Mode Switch Commands:**

```
切换到自由模�?/ Switch to Free mode       �?默认模式，边说边�?/ Default, work as you go
切换到讨论规划模�?/ Switch to Discuss&Plan �?只讨论，不执�?/ Discuss only, no execution
切换到深度研究模�?/ Switch to Deep Research �?独立研究直到交付 / Independent research until delivery
切换到审核模�?/ Switch to Review mode      �?审稿/评审 / Review papers/code
切换到自检模式 / Switch to Self-Check mode  �?系统健康检�?/ System health check
切换到自学模�?/ Switch to Self-Learn mode  �?独立学习 / Independent learning
切换到写作模�?/ Switch to Writing mode     �?撰写文档 / Write documents
切换到执行模�?/ Switch to Execute mode     �?直接干活 / Execute tasks
切换到闲聊模�?/ Switch to Chat mode        �?轻松聊天 / Casual chat
```

**隐式切换 / Implicit Switch:**

- 无明确指�?�?自动判断（默认自由模式）/ No instruction �?Auto-detect (default: Free mode)
- 模糊任务 �?自由模式，必要时询问 / Vague task �?Free mode, ask if needed

---

## 💡 使用场景 / Use Cases

### 场景 1：需求讨�?�?文档撰写 / Scenario 1: Requirements Discussion �?Documentation

```
1. 用户�?我们讨论一下振动台控制软件的需�?
   User: "Let's discuss the shaking table control software requirements"
   �?讨论规划模式 / Discuss & Plan mode �?提问、记录、不写文�?/ Ask, record, no doc

2. （讨论多轮后 / After discussion�?   用户�?好了，需求清楚了，你整理成文档吧"
   User: "Good, requirements are clear, now write the document"
   �?切换到写作模�?/ Switch to Writing mode �?撰写正式文档 / Write formal doc
```

### 场景 2：深度研究任�?/ Scenario 2: Deep Research Task

```
用户�?深度研究一下振动台控制技术的发展趋势"
User: "Deep research on trends in shaking table control technology"
�?深度研究模式 / Deep Research mode �?6 阶段流程 / 6-stage process �?完整研究报告 / Full report
```

### 场景 3：系统健康检�?/ Scenario 3: System Health Check

```
用户�?自检一�?
User: "Self-check"
�?自检模式 / Self-Check mode �?自动检�?/ Auto-check �?自检报告 / Self-check report
```

### 场景 4：论文审�?/ Scenario 4: Paper Review

```
用户�?帮我审一下这篇论�?
User: "Review this paper for me"
�?审核模式 / Review mode �?仔细阅读 / Careful reading �?评审意见清单 / Review checklist
```

---

## 📋 模式详细说明 / Mode Details

### 讨论规划模式（核心推荐）/ Discuss & Plan Mode (Recommended)

**适用�?* 需求不明确、需要充分讨论的任务  
**Use:** Unclear requirements, tasks needing full discussion

**纪律 / Discipline:**
- �?不马上干�?/ No immediate execution
- �?不写正式文档 / No formal documentation
- �?等用户确认后再执�?/ Execute after user confirmation

### 深度研究模式（复杂任务）/ Deep Research Mode (Complex Tasks)

**适用�?* 文献综述、竞品分析、技术方案论�? 
**Use:** Literature review, competitive analysis, technical proposal

**流程 / Process:** 6 阶段 / 6 stages  
**特点 / Features:**
- 多智能体协作 / Multi-agent collaboration
- 独立推进直到交付 / Independent until delivery
- 不频繁打扰用�?/ Minimal user interruption

### 自检模式（系统维护）/ Self-Check Mode (System Maintenance)

**适用�?* 定期系统健康检�? 
**Use:** Regular system health check

**检查项 / Checklist:**
- 记忆文件状�?/ Memory files status
- HEARTBEAT.md 同步 / HEARTBEAT.md sync
- 项目文件完整�?/ Project file integrity
- 技能配�?/ Skill configuration
- 临时文件清理 / Temp file cleanup
- 待办任务更新 / TODO task update

---

## 🎯 最佳实�?/ Best Practices

### 模式选择建议 / Mode Selection Guide

| 场景 / Scenario | 推荐模式 / Recommended Mode |
|----------------|---------------------------|
| 需求不明确，需要先聊聊 / Unclear requirements, need discussion | 讨论规划模式 / Discuss & Plan |
| 写论�?文档 / Write paper/document | 写作模式 / Writing |
| 写代�?开发功�?/ Write code/develop feature | 编码模式 / Coding |
| 复杂研究任务 / Complex research task | 深度研究模式 / Deep Research |
| 快速查资料 / Quick research | 研究模式 / Research |
| 审稿/评审 / Review paper/code | 审核模式 / Review |
| 系统健康检�?/ System health check | 自检模式 / Self-Check |
| 技能提�?/ Skill improvement | 自学模式 / Self-Learn |
| 日常协作 / Daily collaboration | 自由模式（默认）/ Free mode (default) |

### 模式切换技�?/ Mode Switch Tips

1. **明确指示 / Clear instruction** �?直接�?切换�?XX 模式" / Say "switch to XX mode"
2. **自然过渡 / Natural transition** �?讨论完后�?好了，整理成文档" / After discussion, say "now write it"
3. **紧急任�?/ Urgent task** �?"马上执行" �?执行模式 / "Execute now" �?Execute mode
4. **定期检�?/ Regular check** �?每周"自检一�? / Weekly "self-check"

---

## 📄 文件结构 / File Structure

```
work-mode-switch/
├── SKILL.md          # 技能定义（详细文档�? Skill definition
├── package.json      # 包元数据 / Package metadata
├── README.md         # 本文件（使用说明�? This file
└── .gitignore        # Git 忽略文件 / Git ignore
```

---

## 🔄 版本历史 / Version History

| 版本 / Version | 日期 / Date | 更新内容 / Changes |
|---------------|-------------|-------------------|
| 1.0.0 | 2026-03-31 | 初始版本�?2 种工作模�?/ Initial release, 12 work modes |

---

## 🤝 贡献 / Contributing

欢迎提交 Issue �?Pull Request�?
Issues and Pull Requests welcome!

- 报告问题 / Report issues: https://github.com/openclaw/openclaw/issues
- 功能建议 / Feature requests: https://github.com/openclaw/openclaw/discussions

---

## 📄 许可�?/ License

MIT License

---

## 🔗 相关资源 / Resources

- [OpenClaw 官方文档 / OpenClaw Docs](https://docs.openclaw.ai)
- [ClawHub 技能市�?/ ClawHub Marketplace](https://clawhub.ai)
- [Agent Skills 规范 / Agent Skills Spec](https://agentskills.io/)

---

_作�?/ Author: SuperMike_  
_创建日期 / Created: 2026-03-31_  
_版本 / Version: 1.0.0_

