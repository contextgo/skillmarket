# Keep 扫码登录鉴权

## TL;DR（OpenClaw / Hermes · exec 方式）

整个扫码登录压到 3 次 `exec`，Agent **不要自己 sleep + 轮询**，也**不要自己发 HTTP 拉 ASCII**：

```bash
# 1) 获取二维码；从返回里拿 data.qrcodeAscii（可打印 ASCII）+ data.qrcodeUrl（图片 URL）
#    双通道同时输出给用户：ASCII 贴代码块 + ![](qrcodeUrl) 图片兜底
#    （桥层 mcp-cli 的 hydrateQrcode 已经帮你 fetch 过 qrcodeTextUrl，Agent 不再需要 HTTP 调用）
node {baseDir}/scripts/mcp-call.js get_qrcode '{"authType":"openclaw"}'

# 2) 一次 background exec 包住整轮轮询，notifyOnExit 回调唤醒 Agent（90s 窗口）
node {baseDir}/scripts/login-wait.js <qrcodeId>

# 3) 扫码成功后持久化 token；<jwt>、<name> 来自上一步 envelope 的 data.token / data.user.username
node {baseDir}/scripts/persist_auth.js --token='<jwt>' --username='<name>'
```

---

## 概述

Keep MCP Gateway 使用 Keep App 扫码登录进行用户鉴权。所有工具通过 `scripts/mcp-call.js` / `scripts/login-wait.js` 代理；stdout 统一 `{ok, data}` envelope。

> 工具参数由 MCP Server 的 `tools/list` 动态返回，本文档仅描述编排逻辑和业务语义。
> 凭证路径采用运行器无关的命名（`.keepai`），便于跨宿主共享。

## exec 调用约定（mcp-call.js）

本 Skill 的所有 MCP 工具在路径 B 下都通过 `scripts/mcp-call.js` 代理（底层是 `@keepclaw/skill-sdk/mcp-cli`），不只用于鉴权。SKILL.md 中的所有 exec 命令都遵循下述统一约定。

```json
{
  "tool": "exec",
  "command": "node {baseDir}/scripts/mcp-call.js <tool_name> '<json_args>'"
}
```

- `<tool_name>` = `tools/list` 返回的任一工具名（`get_qrcode` / `check_login` / `revoke_auth` / `get_upload_url` / `record_tool`）
- `<json_args>` = JSON 字符串；无参时可省略或传 `'{}'`
- 脚本自动从 `keep_auth_token` 环境变量或 `~/.keepai/.env` 读取凭证注入 `Authorization` header
- stdout 单行 JSON envelope：
  - 成功：`{ "ok": true,  "data": { ... } }`
  - 失败：`{ "ok": false, "error": { "code": "...", "message": "..." } }`
- 退出码：`0` 成功 / `1` 业务错误 / `2` 用法错误 / `3` 网络协议错误 / `4` 鉴权错误

附加用法：

- 列工具：`node {baseDir}/scripts/mcp-call.js --list`
- 从 stdin 读参数（避免 shell 引号噩梦）：`node {baseDir}/scripts/mcp-call.js <tool> --stdin`

> **禁止**：在 `command` 里 `export keep_auth_token=...` inline token（脚本自己读凭证）；不得在 Agent 上下文中复述 `data` 里的敏感字段（如 token）。详见文末「安全最佳实践」。

## 触发时机

在调用任何需登录的 MCP 工具（如 `record_tool`、`get_upload_url`、`revoke_auth`）之前，必须先确保已完成鉴权。收到 `AUTH_REQUIRED` / `TOKEN_EXPIRED` 也需要重新走一遍本流程。

## 执行流程

### 1. 先检查本地凭证

读取环境变量：

| 变量 | 含义 |
|---|---|
| `keep_auth_token` | Keep JWT token |
| `keep_auth_token_expired` | token 过期 Unix 时间戳 |
| `keep_username` | 登录用户名（展示用，可选） |

如果 `keep_auth_token` 存在、`keep_auth_token_expired` 仍大于当前 Unix 时间戳 → 视为已登录，告知用户"Keep 登录凭证有效，无需重新登录"，结束本流程。否则进入第 2 步。

### 2. 调用 `get_qrcode`

- 入参：`{ "authType": "<runtime>" }`，`<runtime>` 填运行器标识（`openclaw` / `cursor` / `hermes` 等）
- 关键返回字段：

  | 字段 | 含义 | 正确用法 |
  |---|---|---|
  | `qrcodeId` | 登录会话 ID | **记住它**，第 3 步用 |
  | `qrcodeAscii` | 服务端预渲染的 Unicode-block ASCII QR 字符串（**由桥层 `@keepclaw/skill-sdk/mcp-cli` 的 `hydrateQrcode` 注水**；非 null 时直接可打印） | **终端 / TUI 首选**：原样 print 到 stderr；手机扫出来就是 Keep 扫码 deeplink。**不要**再用 `qrcode-terminal` 做二次编码 |
  | `qrcodeTextUrl` | 指向 `/account/v2/qrcode/text/<id>` 的 URL | **兜底**：`qrcodeAscii == null` 时（注水失败 / opt-out）再自行 GET 这个 URL 拿 `text/plain` 响应体，不要把 URL 本身贴给用户 |
  | `qrcodeUrl` | 二维码**图片** URL | 富文本 / GUI runner 用 `![](url)` 或可点击链接给用户 |

- 展示策略（**图片优先，ASCII 兜底**）：

  **OpenClaw Web 等聊天 / 富文本 UI 默认优先展示 `data.qrcodeUrl` 图片，不要默认先贴 ASCII 二维码。**

  1. **二维码图片**：`data.qrcodeUrl`，以 Markdown 图片 + 可点击链接形式给出，作为默认主展示
  2. **ASCII 二维码**：`data.qrcodeAscii`，仅在终端 / 等宽字体场景主展示，或作为补充兜底

  ```markdown
  请使用 Keep App 扫描下方二维码完成登录：

  ![扫码登录](<qrcodeUrl>)

  或复制到浏览器打开：<qrcodeUrl>

  如当前运行器是终端，或上方图片无法显示，再补充输出：
  <qrcodeAscii 原样贴进来，用 ```text ... ``` 包住>
  ```

  原因：OpenClaw Web / 微信 / 飞书 等聊天 UI 的等宽字体 + 行高渲染不稳定，块字符 QR 经常被拉扯错位变成不可扫（见 [issue 截图](../_meta.json)）。因此在聊天 / 富文本 UI 中应以图片二维码为主；ASCII 更适合纯终端场景，作为补充兜底保留。

- **终端 / TUI** 运行器（OpenClaw CLI / Hermes CLI）：ASCII 写 stderr，`qrcodeUrl` 也一并附在提示里（让用户手机扫不上时能换浏览器）。`qrcodeAscii == null` 时再 GET `qrcodeTextUrl` 兜底。
- **禁止**：
  - 只给 `qrcodeAscii` 不附 `qrcodeUrl`（聊天 UI 会翻车，正是当前 bug）
  - 只给 `qrcodeUrl` 不附 ASCII（纯终端不可点）
  - 把 `qrcodeTextUrl`（text/plain 端点）当成展示链接贴给用户——它只是 ASCII 拉取兜底，不是给人看的

伪代码（OpenClaw 终端场景 · 首选路径）：

```bash
QR_JSON=$(node {baseDir}/scripts/mcp-call.js get_qrcode '{"authType":"openclaw"}')
# stdout 是单行 envelope：{"ok":true,"data":{"qrcodeAscii":"<ASCII>","qrcodeId":"...","qrcodeTextUrl":"...","qrcodeUrl":"..."}}
# Agent 从 envelope 解析后：
#   1) 把 data.qrcodeAscii 原样打印（终端场景写 stderr；聊天场景用 ```text``` 代码块包住）
#   2) 同时把 data.qrcodeUrl 以 ![](url) + 纯 URL 形式附在下方作为兜底
# 两步都做，一个都不能少。
```

> `qrcodeAscii` 由 `@keepclaw/skill-sdk/mcp-cli` 的 `hydrateQrcode` 在桥层 fetch 后注入，`keep-cli` 的终端渲染逻辑也复用同一份字段（见 `keep-cli/src/commands/login.js`）。两端统一口径，同一条服务端变更会自动通过注水生效。关闭注水可设 `KEEP_MCP_NO_HYDRATE=1`。

### 3. 轮询扫码结果

把整轮轮询封闭在**一次 background exec** 里，由 `notifyOnExit` 在完成 / 失败 / 超时后回调唤醒 Agent。**不要在 LLM 回合里反复 `sleep + exec check_login`**——违反 [OpenClaw background-process 指引](https://docs.openclaw.ai/gateway/background-process)，且费 token：

```bash
node {baseDir}/scripts/login-wait.js <qrcodeId> [--interval=<ms>] [--timeout=<ms>]
```

- 默认：`interval=2000`（2s）、`timeout=90000`（90s 总窗口）
- 脚本内部：按 `intervalMs` 节拍自循环 `check_login`；单次请求超时 45s；遇 `-32001 / timed out` 视为 long-poll 返回立即下一轮；总时长超 `timeoutMs` 未 authorized 则返回 `LOGIN_TIMEOUT`
- stdout：单行 JSON envelope；退出码沿用 `mcp-call.js` 约定（`0` 成功 / `1` 业务错误 / `2` 用法错误 / `3` 协议错误 / `4` 鉴权错误，`LOGIN_TIMEOUT` 归 `1`）

| envelope | 含义 | Agent 下一步 |
|---|---|---|
| `{ ok: true, data: { status: "authorized", token, user, qrcodeId, elapsedMs } }` | 扫码成功 | 进入第 4 步持久化 |
| `{ ok: false, error: { code: "QRCODE_EXPIRED", ... } }` | 二维码过期 | 告知用户并回到第 2 步 |
| `{ ok: false, error: { code: "LOGIN_TIMEOUT", ... } }` | 90s 内未完成扫码 | 告知用户超时，询问是否重试；重试回第 2 步 |
| 其他 `{ ok: false, error: {...} }` | 传输 / 协议 / 鉴权 / 业务异常 | 把 `error.message` 原样告知用户，按 `error.code` 决定是否重试 |

> `login-wait.js` 是 `@keepclaw/skill-sdk/login-wait` 的薄 shim，命令路径**稳定**，不受 npm hoist 布局影响。始终用这条命令，不要直接 `require` SDK。

### 4. 持久化 token

登录成功后只执行持久化脚本，**不要**再用脚本调用 MCP：

```bash
node {baseDir}/scripts/persist_auth.js --token='<jwt>' --username='<name>'
```

- `<jwt>` = `check_login` / `login-wait` 返回的 `token`
- `<name>` = 返回的 `user.username`（缺省可省略）
- 命令里**不要** `export` 任何 token（详见文末安全章节）

### 5. 向用户确认

告知用户登录成功，继续原业务流程（`record_tool` / `get_upload_url` / `revoke_auth`）。之后业务工具由 `mcp-call.js` 自动读取 `~/.keepai/.env` 注入 `Authorization` header（exec 方式），或运行器自动注入（原生 MCP 方式），Agent 都不再接触 token 值。

## 凭证存储

登录成功后，凭证写入 `~/.keepai/.env`（权限 `0600`）：

```
keep_auth_token=eyJhbGciOi...
keep_auth_token_expired=1713312000
keep_username=Seancaixp
```

运行器在后续会话中从该文件读取 `keep_auth_token`，并：

- 作为环境变量注入进程（供 `mcp-call.js` 读取）
- 注入到 MCP HTTP 请求的 `Authorization: Bearer <jwt>` header（见 `SKILL.md` 的 `mcpServers.headers`）

> `keep_username` 同时作为 `username` 写在 JWT payload 中，本地仅用于排查与展示；运行器调用 MCP 时只需要 `keep_auth_token`。

## 脚本文件

| 文件 | 职责 |
|---|---|
| `scripts/persist_auth.js` | 持久化 / 清除 token（`--token=<jwt>` 或 `--clear`） |
| `scripts/login-wait.js` | 登录轮询（`@keepclaw/skill-sdk/login-wait` 的 shim） |
| `scripts/mcp-call.js` | MCP 调用代理（`@keepclaw/skill-sdk/mcp-cli` 的 shim） |
| `@keepclaw/skill-sdk/auth` | 鉴权公共工具（token 判断、exp 解码、凭证落盘 / 清理） |

## 鉴权 / 登录相关错误码

| 错误码 | 出现时机 | Agent 行为 |
|---|---|---|
| `AUTH_REQUIRED` | 调用需登录工具时未携带 token / token 非法 | 重新执行本文档的鉴权流程 |
| `TOKEN_EXPIRED` | JWT 已过期 | 重新执行本文档的鉴权流程 |
| `QRCODE_EXPIRED` | `check_login` / `login-wait.js` 返回此码 | 告知用户二维码过期，重新调 `get_qrcode` |
| `LOGIN_TIMEOUT` | `login-wait.js` 90s 内未完成扫码 | 询问用户是否重试，重试时回到 `get_qrcode` |
| `PROTOCOL_ERROR` / `-32001` | `check_login` 长连接瞬时超时 | **不要**当失败；`login-wait.js` 内部已自动处理，继续等待直到整体 90s 窗口耗尽 |

## 退出登录

详细流程见 [revoke-auth.md](revoke-auth.md)。一句话版本：**先 `revoke_auth` 让服务端失效 token，再 `persist_auth.js --clear` 清理本地**；若 `tools/list` 未返回 `revoke_auth` 则只做本地 `--clear`。

---

## 安全最佳实践

> 说明：Agent + exec 模型下，`check_login` 返回的 token 不可避免会以工具调用参数形式穿过 Agent 上下文一次（从 `check_login` 返回到 `persist_auth.js` 入参）。下述规则不是阻止 Agent "看见" token，而是把暴露面压到最小，避免在 shell 历史与系统日志中留痕。

- **不要把 token 通过 shell `export` / 环境变量方式 inline 到命令中**（例如 `export keep_auth_token=... && node ...`）。这会把 JWT 写入 `~/.zsh_history` / `~/.bash_history` 和系统进程表。**统一使用 `persist_auth.js --token=<jwt>` 参数形式**。
- **Token 的合法流动只有三处**：
  1. `check_login` / `login-wait` 返回值 → `persist_auth.js --token=<jwt>` 参数（一次性转交，不写日志）
  2. `persist_auth.js` 写入 `~/.keepai/.env`（`0600`）
  3. 运行器读取环境变量后，注入 MCP HTTP `Authorization` header
- **Agent 不得展示、复述或总结 token 值**；持久化完成后，后续业务工具由 header / env 自动带 token，Agent 不需要再接触。
- **运行器侧建议**：若支持字段级脱敏（如 OpenClaw 的 secret mask），把 `persist_auth.js --token=*` 的 `--token` 字段配置为 mask 字段。
