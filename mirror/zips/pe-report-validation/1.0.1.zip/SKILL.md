---
name: 药经报告审核验证
description: 验证药物经济学研究报告的正确性并输出格式清晰的验证报告。从报告方法部分理解计算逻辑，重建模型并对比结果，明确说明验证中发现的差异，清晰说明验证所用算法。支持PSM/Markov/决策树等模型，覆盖成本/QALY/ICER计算验证、敏感性分析审核。中英文双语支持。Use this skill when the user asks to verify, validate, audit, or review a pharmacoeconomic report, HTA report, cost-effectiveness analysis, Markov model, PSM, or decision tree. Keywords: 验证、审核、药物经济学报告、cost-effectiveness、ICER、QALY、Markov、PSM、HTA、差异说明、算法验证.
---

# 药经报告审核验证 / PE Report Validation

> **中文** | [English Version](#english-version)

## 适用场景

本 skill 用于 **AI 辅助验证药物经济学研究报告** 的正确性，并输出结构化验证报告。覆盖以下模型类型：

| 模型类型 | 说明 |
|---------|------|
| 分区生存模型（PSM）| Partitioned Survival Model，三状态 PFS/PD/Death |
| Markov 模型 | 多状态转移模型，含半周期校正 |
| 决策树模型 | 单次/有限决策路径 |

---

## 核心原则 / Core Principles

### 验证透明度要求（必需）

1. **算法必须明确说明**：验证报告中必须清晰说明验证所使用的所有算法，包括：
   - 计算公式（LaTeX格式或标准数学符号）
   - 参数来源（报告具体页码、表格编号）
   - 计算步骤（Python代码或伪代码）
   - 假设条件（明确列出所有假设及其依据）

2. **差异必须详细解释**：对每一项验证差异，必须说明：
   - 差异的数值（报告值 vs 验证值）
   - 差异的百分比
   - 可能的原因（按可能性排序）：
     - 参数理解不同（说明报告可能的参数取值）
     - 计算方法不同（说明报告可能使用的算法）
     - 报告错误（明确指出并提供依据）
     - 信息不完整（说明缺失的信息及影响）
   - 对结论的影响程度（无影响/轻微影响/显著影响）

3. **假设必须明确列出**：验证过程中的所有假设必须：
   - 在报告中单独列出
   - 说明每个假设的合理性
   - 说明假设对结果的影响

### 报告可读性要求（必需）

验证报告必须：
- **使用清晰的章节结构**：编号清晰，便于快速定位信息
- **使用表格对比**：所有数值对比使用表格，包含报告值、验证值、偏差、判定
- **使用直观符号**：✅（通过）、⚠️（需关注）、❌（不通过）
- **提供执行摘要**：1-2页Executive Summary，便于快速理解验证结论
- **术语解释**：对专业术语提供简要说明（脚注或术语表）
- **可视化**：适当使用图表展示对比结果（如偏差条形图）

---

## 验证工作流程 / Validation Workflow

### 第一步：提取报告方法 / Step 1: Extract Methods from Report

从以下格式提取报告内容：
- `.docx` → 使用 `docx` skill 读取
- `.pdf` → 使用 `pdf` skill 读取
- 纯文本 → 直接读取

**重点阅读「研究方法」章节，理解其计算逻辑。** 提取以下关键信息：

```yaml
报告信息:
  标题:
  研究角度: 全社会 / 医保支付方 / 医疗机构
  研究时限: __ 年（或 患者终生）
  贴现率: __%
  模型类型: PSM / Markov / 决策树

模型结构:
  健康状态: [PFS, PD/R, Death] 等
  周期长度: __ 月/年
  模拟时长: __ 月/年
  半周期校正: 是/否（若未说明，可推断）
  药品费计算方式: 【重点关注】是否按在治人数加权

参数来源:
  生存曲线:
    数据来源: KM曲线 / 文献 / 临床试验
    分布类型: 指数 / Weibull / 对数正态 / 对数逻辑
    参数值: OS λ=__, PFS λ=__, p=__
    HR值: OS_HR=__, PFS_HR=__
    拟合方法: AIC/BIC / 视觉效果
  
  效用值:
    PFS效用: __ (来源: __)
    PD效用: __ (来源: __)
    Death效用: 0 (标准假设)
  
  成本参数:
    药品单价: __ 元/单位 (来源: __)
    用药剂量: __ 单位/天
    住院费: __ 元/次 (来源: __)
    不良反应处理费: __ 元/次 (来源: __)

基线结果:
  实验组成本: __ 元/人
  对照组成本: __ 元/人
  Δ成本: __ 元/人
  实验组QALY: __
  对照组QALY: __
  ΔQALY: __
  ICER: __ 元/QALY

敏感性分析 (如有):
  - 单因素敏感性分析: 参数范围=__, 基准=__
  - 概率敏感性分析: 模拟次数=__, 分布类型=__

情景分析 (如有):
  - 情景1: 名称=__, 定义=__, 成本=__, ICER=__
  - 情景2: ...
```

**信息缺失处理：**
- 若关键信息缺失，在提取结果中明确标注"未提供"
- 若参数来源不明确，标注"需假设"并说明常用假设
- 继续后续步骤，但在验证报告中说明信息缺失的影响

### 第二步：理解并重建模型 / Step 2: Understand & Rebuild the Model

**核心原则：从报告的方法描述直接理解其计算逻辑。**

#### 2.1 理解算法（关键步骤）

在阅读方法章节时，重点理解：

1. **生存曲线如何拟合**
   - 报告是否说明了分布选择依据（AIC/BIC值）？
   - 是否提供了参数值？还是只提供了HR？
   - 若只提供HR，如何推导实验组生存曲线？

2. **成本如何计算**（最核心的差异来源）
   - **药品费**：是否按在治（PFS）人数比例加权？
     - 正确做法：`Σ(月药品费 × PFS人数比例 × 贴现因子)`
     - 错误做法：`Σ(月药品费 × 1.0 × 贴现因子)` ← 全员全额！
   - **其他成本**：住院费按新发PD人数？不良反应费按PFS人数？

3. **QALY 如何计算**
   - 周期长度是多少？（月/年）
   - 是否进行月→年转换？（月度模型需除以12）
   - 是否应用贴现？

4. **贴现如何应用**
   - 年度贴现率是否换算为月度？（若模型用月周期）
   - 贴现因子公式：`DF(t) = (1+r)^(-t)` 还是 `DF(t) = (1+r_monthly)^(-t)`

#### 2.2 用 Python（NumPy）重建模型

**必须保存完整的可执行Python代码，用于验证报告附录。**

```python
"""
药物经济学模型验证 - 模型重建代码
报告：<报告标题>
验证日期：<日期>
"""

import numpy as np
import pandas as pd

# ========== 1. 参数设定（从报告提取）==========
N0 = 1000                           # 初始队列大小
N_MONTHS = 28 * 12                  # 模拟时长（月）
DR = 0.045                          # 年度贴现率（中国推荐5%）
r_monthly = (1 + DR)**(1/12) - 1   # 月度贴现率
df = np.array([(1 + r_monthly)**(-(t+1)) for t in range(N_MONTHS)])

# 生存曲线参数（必须注明来源）
OS_lam = 0.025                      # λ，来源：报告表3.2
PFS_lam = 0.132                     # λ，来源：报告表3.2
PFS_p = 0.813                       # 形状参数p，来源：报告表3.2

# 效用值（必须注明来源）
u_pfs = 0.498                       # PFS效用值，来源：文献[5]
u_pd = 0.360                        # PD效用值，来源：文献[5]

# 成本参数（必须注明来源和计算方式）
price_per_tablet = 80.33             # 元/片，来源：招标文件
daily_tablets = 6                    # 片/天，来源：药品说明书
cost_hospitalization = 19400         # 元/次，来源：医保目录
cost_ae = 300                        # 元/次，来源：文献[10]


# ========== 2. 生存曲线 ==========
def os_survival(t, lam):
    """OS生存函数（指数分布）"""
    return np.exp(-lam * t)

def pfs_survival(t, lam, p):
    """PFS生存函数（Weibull分布）"""
    return np.exp(-lam * (t ** p))

# 评估时点（半周期校正：取每月中点）
t_pts = np.arange(0.5, N_MONTHS + 0.5, 1.0)
OS = os_survival(t_pts, OS_lam)
PFS = pfs_survival(t_pts, PFS_lam, PFS_p)


# ========== 3. 半周期校正 ==========
def half_cycle(population_frac, n_months, init=N0):
    """
    半周期校正：取相邻两期平均值
    公式：N_corrected[t] = (N[t-1] + N[t]) / 2
    """
    pop = population_frac * N0
    a = np.zeros(n_months)
    a[0] = (init + pop[0]) / 2          # 第0期特殊处理
    for i in range(1, n_months):
        a[i] = (pop[i-1] + pop[i]) / 2
    return a

apfs = half_cycle(PFS, N_MONTHS, N0)
aos  = half_cycle(OS, N_MONTHS, N0)
apd  = aos - apfs                       # 校正后PD人数
adeath = N0 - aos                       # 校正后死亡人数


# ========== 4. 成本计算 ==========
def calc_drug_cost(price, daily_tablets, limit_months=None):
    """
    药品费计算（按PFS人数加权）
    
    算法说明：
    月药品费 = 每日片数 × 30天 × 单片价格
    加权药品费 = 月药品费 × (PFS人数/N0) × 贴现因子
    
    注意：第1月为剂量递增期，需特殊处理
    """
    total = 0
    for m in range(N_MONTHS):
        if limit_months is not None and m >= limit_months:
            break
        # 第1月：剂量递增（7天3片/天，7天4片/天，7天5片/天，9天6片/天）
        if m == 0:
            mc = (7*3 + 7*4 + 7*5 + 9*daily_tablets) * price / 30 * 30
        else:
            mc = daily_tablets * 30 * price
        
        pfs_frac = apfs[m] / N0
        total += mc * pfs_frac * df[m]
    return total

drug_cost = calc_drug_cost(price_per_tablet, daily_tablets)

# 其他成本（按对应人数加权）
ae_cost = 0.067*20 + 0.111*25 + 0.067*300  # 示例：按发生率计算
ae_total = np.sum(ae_cost * apfs / N0 * df)

new_pd = np.maximum(0, np.diff(np.concatenate([[N0], apd])))
prog_total = np.sum(new_pd * cost_hospitalization * df) / N0

new_death = np.maximum(0, np.diff(np.concatenate([[0], adeath])))
eol_total = np.sum(new_death * 15000 * df) / N0  # 终末期费用

total_cost = drug_cost + ae_total + prog_total + eol_total


# ========== 5. QALY 计算 ==========
"""
QALY计算公式：
QALY = Σ[N_state(t) × u_state × DF(t)] / (N0 × 12)

注意：
- 除以12是将月度人年转换为年度QALY
- 若报告使用年度周期，则不需除以12
"""

qaly = np.sum(apfs * u_pfs + apd * u_pd) / N0 / 12 * df
qaly_total = np.sum(qaly)


# ========== 6. ICER 计算 ==========
delta_cost = cost_treat - cost_ctrl
delta_qaly = qaly_treat - qaly_ctrl
icer = delta_cost / delta_qaly

print(f"实验组成本: {cost_treat:,.0f} 元/人")
print(f"对照组成本: {cost_ctrl:,.0f} 元/人")
print(f"实验组QALY: {qaly_treat:.4f}")
print(f"ΔQALY: {delta_qaly:.4f}")
print(f"ICER: {icer:,.0f} 元/QALY")
```

**代码保存要求：**
- 保存为独立Python文件（如 `validation_model_rebuild.py`）
- 包含所有参数来源的注释
- 包含所有关键步骤的公式说明
- 可独立于验证过程执行

### 第三步：对比基线结果 / Step 3: Compare Baseline Results

将重建模型的基线结果与报告值逐项对比：

#### 3.1 成本对比表

| 成本项目 | 报告值（元/人） | 重建值（元/人） | 绝对差异 | 相对差异 | 判定 | 差异说明 |
|---------|----------------|----------------|---------|---------|------|---------|
| 实验组总成本 | | | | ±__% | ✅/⚠️/❌ | |
| 对照组总成本 | | | | ±__% | ✅/⚠️/❌ | |
| Δ成本 | | | | ±__% | ✅/⚠️/❌ | |
| 其中：药品费 | | | | ±__% | ✅/⚠️/❌ | |
| 其中：住院费 | | | | ±__% | ✅/⚠️/❌ | |
| 其中：不良反应费 | | | | ±__% | ✅/⚠️/❌ | |

#### 3.2 效果对比表

| 效果指标 | 报告值 | 重建值 | 绝对差异 | 相对差异 | 判定 | 差异说明 |
|---------|--------|--------|---------|---------|------|---------|
| 实验组QALY | | | | ±__% | ✅/⚠️/❌ | |
| 对照组QALY | | | | ±__% | ✅/⚠️/❌ | |
| ΔQALY | | | | ±__% | ✅/⚠️/❌ | |

#### 3.3 ICER对比

| ICER | 报告值（元/QALY） | 重建值（元/QALY） | 绝对差异 | 相对差异 | 判定 | 差异说明 |
|------|-------------------|-------------------|---------|---------|------|---------|
| 基线ICER | | | | ±__% | ✅/⚠️/❌ | |

**判定标准：**
- ✅ 偏差 ≤ 5%：验证通过，算法理解正确
- ⚠️ 偏差 5~15%：有条件通过，必须详细说明差异来源
- ❌ 偏差 > 15%：不通过，存在算法理解错误，需回到第二步重新理解方法

**差异说明要求（必需）：**

对每个⚠️或❌的项目，必须在报告中详细说明：

```markdown
#### 差异说明示例

**问题：** 实验组成本差异 +12.3%

**可能原因（按可能性排序）：**

1. **药品费计算方式不同**（可能性：高）
   - 报告可能使用了全员全额计算（未加权）
   - 验证使用的算法：按PFS人数加权
   - 检查方法：若报告药品费 > 100万/人，可确认是此原因
   - 依据：中国《2025版药物经济学评价指南》推荐按在治人数加权

2. **贴现率应用不同**（可能性：中）
   - 报告可能未将年度贴现率换算为月度
   - 验证使用的贴现因子：`DF(t) = (1+0.045/12)^(-t)`
   - 若报告使用：`DF(t) = (1+0.045)^(-t/12)` ← 错误！
   - 影响：长期模型偏差可达20%

3. **参数取值不同**（可能性：低）
   - 报告未明确说明药品单价，可能使用了不同的采购价格
   - 验证使用：80.33元/片（来源：招标文件）
   - 建议：要求报告提供详细的参数取值表

**对结论的影响：**
- ICER差异：+8.5%（从250,000元/QALY变为271,250元/QALY）
- 结论影响：仍低于WTP阈值（270,000元/QALY），结论不变
- 但需在报告中明确说明成本计算的差异

**建议：**
1. 要求报告提供详细的药品费计算说明
2. 在敏感性分析中测试药品费的影响
3. 若确认是算法错误，建议在讨论章节说明
```

### 第四步（可选）：情景分析验证 / Step 4 (Optional): Scenario Validation

**如果报告提供了情景分析结果**，可用作交叉验证：

#### 4.1 逆向工程：从情景结果反推算法

当报告提供 ≥3 个情景时，可建立方程组辅助理解药品费的计算逻辑：

```
假设：各情景总成本 = 药品费 × 权重_i + 非药品成本（固定）

基线    C0 = DrugCost × w0 + NonDrugCost
情景1   C1 = DrugCost × w1 + NonDrugCost
情景2   C2 = DrugCost × w2 + NonDrugCost

→ 从任意两个情景联立解出 DrugCost 和 NonDrugCost
→ 将解出值代入其余情景，检查是否吻合
```

**逆向工程Python模板：**

```python
# 已知：报告给出多个情景的总成本（以3个情景为例）
C_base   = 210983   # 基线情景总成本（元/人）
C_s1     = 169664   # 情景1总成本（如：剂量减半）
C_s2     = 115693   # 情景2总成本（如：停药）

# 核心假设：非药品成本与药品费无关（各情景固定不变）
# 则每个情景的总成本可表示为：
#     C_i = DrugCost_base × w_i + NonDrugCost
# 其中 w_i 为该情景下药品费相对于基线的权重

# 从两个情景联立方程，解出基线药品费和非药品成本：
w_base, w_s2 = 1.0, 0.0       # 基线：100%用药；情景2：停药（0%）
DrugCost_base = (C_base - C_s2) / (w_base - w_s2)
NonDrugCost   = C_base - DrugCost_base * w_base

print(f"反推基线药品费: {DrugCost_base:,.0f} 元/人")
print(f"反推非药品成本: {NonDrugCost:,.0f} 元/人")

# 验证：将解出值代入其余情景进行交叉验证
w_s1 = 0.5  # 情景1：剂量减半（50%）
C_s1_rebuilt = DrugCost_base * w_s1 + NonDrugCost
bias_s1 = (C_s1_rebuilt - C_s1) / C_s1 * 100

print(f"情景1重建: {C_s1_rebuilt:,.0f} 元/人 vs 报告 {C_s1:,.0f} 元/人")
print(f"情景1偏差: {bias_s1:.1f}%")

if abs(bias_s1) < 5:
    print("✅ 逆向工程验证通过：报告药品费计算方式理解正确")
else:
    print("⚠️ 逆向工程验证未通过：需重新检查算法理解")
```

⚠️ **注意：** 上述逆向工程仅用于辅助理解，不是验证的必要条件。核心验证仍依赖于第二步对报告方法的正确理解。

### 第五步：输出验证报告 / Step 5: Output Validation Report

使用 `docx` skill 生成结构化验证报告（Word 格式）。

#### 5.1 验证报告模板（必需）

```
==========================================
药物经济学研究报告验证报告
Verification Report of Pharmacoeconomic Analysis
==========================================

执行摘要（Executive Summary）
------------------------------------------
1. 验证结论：□ 通过  □ 有条件通过  □ 不通过
2. 关键发现：
   - 成本计算验证：✅/⚠️/❌
   - 效果计算验证：✅/⚠️/❌
   - ICER验证：✅/⚠️/❌
3. 主要问题：（若有）
4. 建议：（若有）


第一章 验证方法与范围
------------------------------------------
1.1 验证目的
    - 验证报告：<报告标题>
    - 验证内容：模型结构、参数来源、计算方法、基线结果、敏感性分析
    - 验证标准：中国《2025版药物经济学评价指南》

1.2 验证方法
    - 方法1：报告方法章节理解
    - 方法2：Python模型重建与结果对比
    - 方法3：情景分析交叉验证（若有）

1.3 验证范围与限制
    - 验证范围：<说明验证覆盖的内容>
    - 限制：<说明信息缺失、假设等内容>

1.4 验证中使用的关键假设
    - 假设1：<说明> （依据：<依据>）
    - 假设2：<说明> （依据：<依据>）
    - ...


第二章 模型结构验证
------------------------------------------
2.1 模型类型验证
    | 检查项目 | 报告描述 | 验证结果 | 判定 |
    |---------|---------|---------|------|
    | 模型类型 | | ✅/❌ | |
    | 健康状态定义 | | ✅/⚠️/❌ | |
    | 周期长度 | | ✅/⚠️/❌ | |
    | 模拟时长 | | ✅/⚠️/❌ | |
    | 半周期校正 | | ✅/⚠️/❌ | |

2.2 模型透明度评估
    | 透明度项目 | 是否充分公开 | 备注 |
    |-----------|--------------|------|
    | 模型结构 | □是 □否 | |
    | 参数来源 | □是 □否 | |
    | 计算公式 | □是 □否 | |
    | 软件实现 | □是 □否 | |


第三章 参数验证
------------------------------------------
3.1 生存曲线参数
    | 参数 | 报告值 | 来源 | 验证结果 | 备注 |
    |------|--------|------|---------|------|
    | OS分布类型 | | | ✅/⚠️/❌ | |
    | OS λ | | | ✅/⚠️/❌ | |
    | PFS分布类型 | | | ✅/⚠️/❌ | |
    | PFS λ | | | ✅/⚠️/❌ | |
    | PFS p | | | ✅/⚠️/❌ | |

3.2 效用值参数
    | 健康状态 | 报告值 | 来源 | 验证结果 | 备注 |
    |---------|--------|------|---------|------|
    | PFS | | | ✅/⚠️/❌ | |
    | PD | | | ✅/⚠️/❌ | |
    | Death | | | ✅/⚠️/❌ | |

3.3 成本参数
    | 成本项目 | 报告值 | 来源 | 验证结果 | 备注 |
    |---------|--------|------|---------|------|
    | 药品单价 | | | ✅/⚠️/❌ | |
    | 用药剂量 | | | ✅/⚠️/❌ | |
    | 住院费 | | | ✅/⚠️/❌ | |
    | 不良反应费 | | | ✅/⚠️/❌ | |


第四章 计算结果验证（核心章节）
------------------------------------------
4.1 验证使用的算法说明（必需详细）

4.1.1 生存曲线算法
   公式：
   - OS: S(t) = exp(-λt)  【指数分布】
   - PFS: S(t) = exp(-λt^p)  【Weibull分布】
   
   参数来源：
   - λ_OS = 0.025，来源：报告表3.2
   - λ_PFS = 0.132，来源：报告表3.2
   - p_PFS = 0.813，来源：报告表3.2
   
   Python实现：
   ```python
   def os_survival(t, lam):
       return np.exp(-lam * t)
   
   def pfs_survival(t, lam, p):
       return np.exp(-lam * (t ** p))
   ```

4.1.2 成本计算算法（核心）
   药品费计算公式：
   C_drug = Σ [月药品费 × (N_PFS(t)/N0) × DF(t)]
   
   其中：
   - 月药品费 = 每日片数 × 30天 × 单片价格
   - N_PFS(t) = t时刻PFS人数（半周期校正后）
   - N0 = 初始队列大小
   - DF(t) = (1 + r_monthly)^(-t)  【月度贴现因子】
   
   正确算法与错误算法对比：
   | 项目 | 正确算法 | 错误算法（常见） |
   |------|---------|-----------------|
   | 公式 | Σ[月费×(N_PFS/N0)×DF] | Σ[月费×1.0×DF] |
   | 说明 | 按在治人数加权 | 全员全额计算 |
   | 结果 | 数万~数十万元/人 | 数百万元/人 |
   
   Python实现：
   ```python
   def calc_drug_cost(price, daily_tablets):
       total = 0
       for m in range(N_MONTHS):
           monthly_cost = daily_tablets * 30 * price
           pfs_frac = apfs[m] / N0
           total += monthly_cost * pfs_frac * df[m]
       return total
   ```

4.1.3 QALY计算算法
   公式：
   QALY = Σ [N_state(t) × u_state × DF(t)] / (N0 × 12)
   
   其中：
   - N_state(t) = t时刻处于该健康状态的人数（半周期校正后）
   - u_state = 该健康状态的效用值
   - DF(t) = 贴现因子
   - 除以12 = 将月度人年转换为年度QALY
   
   注意：若模型使用年度周期，则不需除以12

4.1.4 ICER计算算法
   公式：
   ICER = ΔC / ΔQ = (C_treat - C_ctrl) / (QALY_treat - QALY_ctrl)
   
   判定标准（中国WTP = 3×人均GDP ≈ 270,000元/QALY）：
   - ICER < WTP → 具有成本效果
   - ICER ≥ WTP → 不具有成本效果
   - ICER < 0 → 占优（成本更低，效果更好）

4.2 基线结果对比
   
   表4.1 成本对比
   | 成本项目 | 报告值 | 重建值 | 绝对差异 | 相对差异 | 判定 |
   |---------|--------|--------|---------|---------|------|
   | 实验组总成本 | | | | ±__% | ✅/⚠️/❌ |
   | 对照组总成本 | | | | ±__% | ✅/⚠️/❌ |
   | Δ成本 | | | | ±__% | ✅/⚠️/❌ |
   
   表4.2 效果对比
   | 效果指标 | 报告值 | 重建值 | 绝对差异 | 相对差异 | 判定 |
   |---------|--------|--------|---------|---------|------|
   | 实验组QALY | | | | ±__% | ✅/⚠️/❌ |
   | 对照组QALY | | | | ±__% | ✅/⚠️/❌ |
   | ΔQALY | | | | ±__% | ✅/⚠️/❌ |
   
   表4.3 ICER对比
   | ICER | 报告值 | 重建值 | 绝对差异 | 相对差异 | 判定 |
   |------|--------|--------|---------|---------|------|
   | 基线ICER | | | | ±__% | ✅/⚠️/❌ |

4.3 差异详细说明（对每个⚠️或❌的项目）
   
   【格式要求：对每个差异，按以下模板说明】
   
   差异编号：D-01
   差异项目：实验组成本
   报告值：xxx 元/人
   重建值：xxx 元/人
   相对差异：+xx%
   
   可能原因（按可能性排序）：
   1. <原因1>（可能性：高/中/低）
      - 说明：<详细解释>
      - 依据：<文献、指南、逻辑依据>
      - 检查方法：<如何确认>
   
   2. <原因2>（可能性：高/中/低）
      - ...
   
   对结论的影响：
   - ICER变化：从xxx变为xxx
   - 结论是否改变：□是 □否
   - 影响程度：□无影响 □轻微影响 □显著影响
   
   建议：<具体建议>

4.4 情景分析验证（若有）
   | 情景 | 报告ICER | 重建ICER | 偏差 | 判定 |
   |------|---------|---------|------|------|
   | 基线 | | | ±__% | ✅/⚠️/❌ |
   | 情景1 | | | ±__% | ✅/⚠️/❌ |
   | 情景2 | | | ±__% | ✅/⚠️/❌ |


第五章 敏感性分析验证
------------------------------------------
5.1 单因素敏感性分析
    | 参数 | 报告范围 | 验证范围 | 判定 | 备注 |
    |------|---------|---------|------|------|
    | 药品费 | | | ✅/⚠️/❌ | |
    | 效用值 | | | ✅/⚠️/❌ | |
    | 贴现率 | | | ✅/⚠️/❌ | |
    
     tornado图对比：（若有）
     [插入报告tornado图 vs 验证tornado图]

5.2 概率敏感性分析（PSA）
    | 项目 | 报告值 | 验证值 | 判定 |
    |------|--------|--------|------|
    | 模拟次数 | | | ✅/⚠️/❌ |
    | ICER分布（均值） | | | ✅/⚠️/❌ |
    | ICER分布（95%CI） | | | ✅/⚠️/❌ |
    | 成本效果概率 | | | ✅/⚠️/❌ |


第六章 识别的问题与改进建议
------------------------------------------
6.1 识别的问题（按严重程度排序）
   
   问题编号：P-01
   问题类型：□算法错误 □参数不明 □计算错误 □报告不清
   问题描述：<详细描述>
   严重程度：□高 □中 □低
   影响：<对结论的影响>
   
   问题编号：P-02
   ...

6.2 改进建议（对应每个问题）
   
   建议编号：R-01（对应P-01）
   建议内容：<具体改进建议>
   优先级：□高 □中 □低
   
   建议编号：R-02
   ...


第七章 总体结论
------------------------------------------
7.1 验证结论
   □ 验证通过：所有关键指标偏差≤5%，算法理解正确，参数来源明确
   □ 有条件通过：关键指标偏差5~15%，需说明差异来源，结论可能受影响
   □ 验证不通过：关键指标偏差>15%，存在算法理解错误，或信息严重缺失

7.2 验证置信度
   □ 高：所有关键参数和算法均明确，验证结果可靠
   □ 中：部分参数或算法不明确，需依赖假设，验证结果需谨慎解读
   □ 低：关键信息严重缺失，验证结果参考价值有限

7.3 使用建议
   <根据验证结论，说明如何使用该报告的结果>


附录
------------------------------------------
附录A：模型重建Python代码（完整可运行）
附录B：参数提取详细记录（报告页码、表格编号）
附录C：验证过程 Intermediate Results
附录D：术语表


==========================================
报告结束
==========================================
```

#### 5.2 报告格式要求（必需）

1. **页码**：底部居中
2. **页眉**：左对齐显示报告标题，右对齐显示章节名称
3. **表格**：
   - 使用三线表格式
   - 表头加粗
   - 数字使用千位分隔符（如：210,983）
   - 偏差使用颜色标注：✅绿色、⚠️黄色、❌红色
4. **图表**：
   - 所有图表必须有编号和标题
   - 图表在正文中必须被引用
5. **参考文献**：
   - 使用标准引用格式
   - 列出验证中引用的所有文献和指南

---

## 验证检查清单 / Validation Checklist

在输出验证报告前，使用此清单确保完整性：

### A. 报告内容检查

- [ ] 执行摘要是否清晰？（1-2页，包含验证结论、关键发现、主要问题、建议）
- [ ] 所有算法是否都有详细说明？（公式、参数来源、Python代码）
- [ ] 所有差异是否都有详细解释？（可能原因、对结论影响、建议）
- [ ] 假设是否都明确列出？（假设内容、依据、对结果影响）
- [ ] 表格是否完整？（报告值、验证值、偏差、判定、备注）
- [ ] 判定标准是否一致？（✅≤5%、⚠️5~15%、❌>15%）

### B. 算法说明检查

- [ ] 生存曲线算法是否说明？（分布类型、参数、拟合方法）
- [ ] 成本计算算法是否说明？（尤其是药品费是否加权）
- [ ] QALY计算算法是否说明？（是否除以12、是否贴现）
- [ ] 贴现算法是否说明？（年度→月度换算是否正确）
- [ ] ICER计算算法是否说明？（公式、判定标准）

### C. 差异解释检查

- [ ] 对每个⚠️项目，是否说明了差异原因？
- [ ] 对每个❌项目，是否详细解释了算法理解错误？
- [ ] 是否分析了差异对结论的影响？
- [ ] 是否提供了改进建议？

### D. 可读性检查

- [ ] 章节编号是否清晰？
- [ ] 是否使用了表格对比？
- [ ] 是否使用了✅⚠️❌符号？
- [ ] 是否有术语解释？
- [ ] Python代码是否作为附录提供？

### E. 附件完整性检查

- [ ] Python模型重建代码（完整可运行）
- [ ] 参数提取记录（报告具体位置）
- [ ] 中间结果（便于复审）

---

## 常见算法错误检查清单

| 错误类型 | 检查方法 | 典型偏差 |
|---------|---------|---------|
| 药品费未加权（全员全额计算）| 检查成本量级：若单人药品费 > 100万，高度可疑 | 可达10倍以上 |
| 贴现率应用错误 | 检查贴现因子：`df = (1+dr)^(-t)`，月度贴现 `r_m = (1+dr)^(1/12)-1` | 长期模型>20% |
| 半周期校正遗漏 | 第1期应为 `(init + pop[0])/2`，而非 `pop[0]` | QALY偏差2~5% |
| QALY 未除以12（月→年）| QALY 结果若 >5，检查是否漏了 `/12` | QALY夸大12倍 |
| 对照组成本参数不明确 | 对比报告值与重建值，差异 >20% 时标注"参数未充分公开" | 不确定 |
| HR错误应用 | 检查是否正确使用HR调整生存曲线：`S_treat(t) = S_ctrl(t)^(HR)` | 可达30% |

---

## 引用规范

验证报告中引用时，使用以下格式：

> 本研究按计划开展，模型重建基于 Python（NumPy）完成，验证流程遵循中国《2025版药物经济学评价指南》和ISPOR模型透明度最佳实践。

**标准引用格式：**

1. 中国药物经济学评价指南（2025版）[J]. 中国卫生经济, 2025.
2. ISPOR Good Research Practices for Model Transparency. Value in Health, 2012.
3. <报告作者>. <报告标题>[R]. <发表年份>.

---

# English Version

## When to Use This Skill

Trigger this skill when the user asks to:
- verify, validate, audit, or review a pharmacoeconomic / HTA / cost-effectiveness report
- check ICER / QALY / cost calculations
- verify a Markov model, PSM (Partitioned Survival Model), or decision tree
- Keywords: `验证`, `审核`, `药物经济学`, `ICER`, `QALY`, `cost-effectiveness`, `Markov`, `PSM`, `HTA`, `difference explanation`, `algorithm verification`

---

## Core Principles (Mandatory)

### Transparency Requirements

1. **Algorithms MUST be clearly explained**: The validation report must clearly explain all algorithms used, including:
   - Formulas (LaTeX or standard math notation)
   - Parameter sources (report page numbers, table numbers)
   - Calculation steps (Python code or pseudocode)
   - Assumptions (explicitly list all assumptions and their rationale)

2. **Differences MUST be detailed explained**: For each validation difference, must explain:
   - Numerical difference (reported value vs validated value)
   - Percentage difference
   - Possible causes (sorted by likelihood)
   - Impact on conclusion (no impact / minor impact / significant impact)

3. **Assumptions MUST be explicitly listed**: All assumptions must:
   - Be listed separately in the report
   - Include rationale for each assumption
   - Include impact of assumption on results

### Report Readability Requirements (Mandatory)

The validation report MUST:
- **Use clear section structure**: Numbered sections for easy navigation
- **Use tables for comparison**: All numerical comparisons use tables with reported value, validated value, bias, verdict
- **Use intuitive symbols**: ✅ (pass), ⚠️ (needs attention), ❌ (fail)
- **Provide Executive Summary**: 1-2 page summary for quick understanding
- **Explain terminology**: Provide brief explanations for technical terms
- **Visualization**: Appropriately use charts to show comparison results

---

## Validation Workflow

### Step 1: Extract and Understand Methods

Read the report (`.docx` → `docx` skill; `.pdf` → `pdf` skill).

**Focus on the "Methods" section — understand the calculation logic from the text.**

Extract:
- Model structure (PSM / Markov / decision tree)
- Survival curve parameters (distribution, λ, p, HR — and how they were fitted)
- Utility values per health state (and their sources)
- Cost methodology (**key**: is drug cost weighted by on-treatment population, or charged to all patients?)
- Discount rate (annual; check if correctly converted to monthly if model uses monthly cycles)
- Baseline results (cost per arm, QALYs, ICER)
- Sensitivity analysis results (if any)
- Scenario analysis results (if any)

**Handling missing information:**
- If key information is missing, clearly mark "Not provided" in extraction
- If parameter sources are unclear, mark "Need to assume" and explain common assumptions
- Continue with subsequent steps, but explain impact of missing information in validation report

### Step 2: Rebuild the Model in Python

**Core principle: Understand the calculation logic directly from the methods section.**

#### 2.1 Understand the Algorithm (Critical Step)

When reading the methods section, focus on understanding:

1. **How survival curves are fitted**
   - Does the report explain basis for distribution selection (AIC/BIC values)?
   - Are parameter values provided? Or only HR?
   - If only HR provided, how to derive treatment arm survival curves?

2. **How costs are calculated** (most common source of differences)
   - **Drug cost**: Is it weighted by on-treatment (PFS) population?
     - Correct approach: `Σ(monthly cost × N_PFS/N0 × discount factor)`
     - Wrong approach: `Σ(monthly cost × 1.0 × discount factor)` ← full pop!
   - **Other costs**: Hospitalization cost weighted by new PD cases? AE cost weighted by PFS population?

3. **How QALY is calculated**
   - What is the cycle length? (month / year)
   - Is month→year conversion applied? (monthly model needs /12)
   - Is discounting applied?

4. **How discounting is applied**
   - Is annual discount rate converted to monthly? (if model uses monthly cycles)
   - Discount factor formula: `DF(t) = (1+r)^(-t)` or `DF(t) = (1+r_monthly)^(-t)`

#### 2.2 Rebuild Model in Python

**Must save complete executable Python code for validation report appendix.**

```python
"""
PE Model Validation - Model Rebuild Code
Report: <Report Title>
Validation Date: <Date>
"""

import numpy as np
import pandas as pd

# ========== 1. Parameter Setting (Extracted from Report) ==========
# ... (Same as Chinese version)

# ========== 2. Survival Curves ==========
# ... (Same as Chinese version)

# ========== 3. Half-cycle Correction ==========
# ... (Same as Chinese version)

# ========== 4. Cost Calculation ==========
# ... (Same as Chinese version)

# ========== 5. QALY Calculation ==========
# ... (Same as Chinese version)

# ========== 6. ICER Calculation ==========
# ... (Same as Chinese version)
```

**Code Saving Requirements:**
- Save as independent Python file (e.g., `validation_model_rebuild.py`)
- Include all parameter sources in comments
- Include formula explanations for all key steps
- Executable independently of validation process

### Step 3: Compare Baseline Results

Compare rebuilt model baseline results with reported values item by item.

#### 3.1 Cost Comparison Table

| Cost Item | Reported (CNY/person) | Rebuilt (CNY/person) | Abs Diff | Rel Diff | Verdict | Difference Explanation |
|-----------|----------------------|---------------------|---------|---------|---------|----------------------|
| Tx total cost | | | | ±__% | ✅/⚠️/❌ | |
| Ctrl total cost | | | | ±__% | ✅/⚠️/❌ | |
| Δ cost | | | | ±__% | ✅/⚠️/❌ | |
| Of which: drug cost | | | | ±__% | ✅/⚠️/❌ | |
| Of which: hospitalization | | | | ±__% | ✅/⚠️/❌ | |
| Of which: AE cost | | | | ±__% | ✅/⚠️/❌ | |

#### 3.2 Effect Comparison Table

| Effect Metric | Reported | Rebuilt | Abs Diff | Rel Diff | Verdict | Difference Explanation |
|---------------|---------|---------|---------|---------|---------|----------------------|
| Tx QALY | | | | ±__% | ✅/⚠️/❌ | |
| Ctrl QALY | | | | ±__% | ✅/⚠️/❌ | |
| ΔQALY | | | | ±__% | ✅/⚠️/❌ | |

#### 3.3 ICER Comparison

| ICER | Reported (CNY/QALY) | Rebuilt (CNY/QALY) | Abs Diff | Rel Diff | Verdict | Difference Explanation |
|------|---------------------|---------------------|---------|---------|---------|----------------------|
| Baseline ICER | | | | ±__% | ✅/⚠️/❌ | |

**Thresholds:** ✅ ≤5% bias; ⚠️ 5–15%; ❌ >15%

**Difference Explanation Requirements (Mandatory):**

For each ⚠️ or ❌ item, must explain in detail in report:

```markdown
#### Difference Explanation Example

**Issue:** Tx cost difference +12.3%

**Possible Causes (sorted by likelihood):**

1. **Different drug cost calculation method** (likelihood: high)
   - Report may have used full population calculation (not weighted)
   - Validation algorithm: weighted by PFS population
   - Check method: If reported drug cost > 1M/person, confirm this is the cause
   - Basis: China "2025 Pharmacoeconomic Evaluation Guidelines" recommends weighting by on-treatment population

2. **Different discount rate application** (likelihood: medium)
   - Report may not have converted annual discount rate to monthly
   - Validation discount factor: `DF(t) = (1+0.045/12)^(-t)`
   - If report uses: `DF(t) = (1+0.045)^(-t/12)` ← WRONG!
   - Impact: Long-term model bias can reach 20%

3. **Different parameter values** (likelihood: low)
   - Report did not clearly state drug unit price, may have used different procurement price
   - Validation uses: 80.33 CNY/tablet (source: bidding document)
   - Recommendation: Request report to provide detailed parameter value table

**Impact on Conclusion:**
- ICER difference: +8.5% (from 250,000 CNY/QALY to 271,250 CNY/QALY)
- Conclusion impact: Still below WTP threshold (270,000 CNY/QALY), conclusion unchanged
- But need to clearly state cost calculation difference in discussion section

**Recommendations:**
1. Request report to provide detailed drug cost calculation explanation
2. Test drug cost impact in sensitivity analysis
3. If confirmed as algorithm error, recommend stating in discussion section
```

### Step 4 (Optional): Scenario Analysis Cross-Validation

**If the report includes scenario analysis results**, use them as additional validation:

When ≥3 scenarios are available, set up equations to cross-check your understanding.

*(Same reverse engineering template as Chinese version)*

⚠️ **Note:** Reverse engineering is a supplementary check, NOT a prerequisite for validation. The core validation relies on correctly understanding the methods section.

### Step 5: Generate Validation Report

Use `docx` skill to generate a structured Word report.

*(Same report template as Chinese version, but in English)*

---

## Validation Checklist

Before outputting validation report, use this checklist to ensure completeness:

### A. Report Content Check

- [ ] Is Executive Summary clear? (1-2 pages, including validation conclusion, key findings, major issues, recommendations)
- [ ] Are all algorithms explained in detail? (formulas, parameter sources, Python code)
- [ ] Are all differences explained in detail? (possible causes, impact on conclusion, recommendations)
- [ ] Are assumptions explicitly listed? (assumption content, basis, impact on results)
- [ ] Are tables complete? (reported value, validated value, bias, verdict, notes)
- [ ] Are judgment criteria consistent? (✅≤5%, ⚠️5~15%, ❌>15%)

### B. Algorithm Explanation Check

- [ ] Is survival curve algorithm explained? (distribution type, parameters, fitting method)
- [ ] Is cost calculation algorithm explained? (especially whether drug cost is weighted)
- [ ] Is QALY calculation algorithm explained? (whether /12 is applied, whether discounted)
- [ ] Is discount algorithm explained? (whether annual→monthly conversion is correct)
- [ ] Is ICER calculation algorithm explained? (formula, judgment criteria)

### C. Difference Explanation Check

- [ ] For each ⚠️ item, is difference cause explained?
- [ ] For each ❌ item, is algorithm misunderstanding explained in detail?
- [ ] Is impact of difference on conclusion analyzed?
- [ ] Are improvement suggestions provided?

### D. Readability Check

- [ ] Are section numbers clear?
- [ ] Are tables used for comparison?
- [ ] Are ✅⚠️❌ symbols used?
- [ ] Is terminology explained?
- [ ] Is Python code provided as appendix?

### E. Attachment Completeness Check

- [ ] Python model rebuild code (complete and runnable)
- [ ] Parameter extraction record (specific report location)
- [ ] Intermediate results (for review)

---

## Common Algorithm Errors Checklist

| Error Type | How to Detect | Typical Bias |
|-----------|---------------|--------------|
| Drug cost not weighted (full pop × full duration) | Cost per patient > 1M CNY → highly suspicious | Up to 10× |
| Wrong discount application | Check: monthly `dr = (1+dr_annual)^(1/12)-1` | >20% for long-term |
| Missing half-cycle correction | Month 0 should be `(init + pop[0])/2`, not `pop[0]` | QALY bias 2~5% |
| QALY missing `/12` (months→years) | QALY > 5 → likely missing division by 12 | QALY exaggerated 12× |
| Control arm cost parameters unclear | >20% gap → flag "parameters not fully disclosed" | Uncertain |
| HR wrong application | Check if HR correctly applied: `S_treat(t) = S_ctrl(t)^(HR)` | Up to 30% |

---

## References

- `references/pe_validation_guide.md` — Detailed technical reference (bilingual)
- China 2025 Pharmacoeconomic Evaluation Guidelines (CEEUA)
- ISPOR Good Research Practices for Model Transparency
- Siebert, U. et al. State-Transition Modeling. Medical Decision Making, 2012.
