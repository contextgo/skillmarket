# 药物经济学验证技术参考 / PE Validation Technical Reference

> 双语参考手册 — Bilingual technical reference for pharmacoeconomic model validation

---

## 目录 / Table of Contents

1. [模型理论基础](#1-模型理论基础)
2. [核心计算公式](#2-核心计算公式)
3. [Python 实现模板](#3-python-实现模板)
4. [验证判定标准](#4-验证判定标准)
5. [常见错误案例库](#5-常见错误案例库)

---

## 1. 模型理论基础 / Model Theory

### 1.1 分区生存模型（PSM）/ Partitioned Survival Model

PSM 直接利用生存曲线（OS 和 PFS）推导各健康状态人数，**无需定义转移概率**。

```
状态定义：
  PFS（无进展生存）→ PD/R（进展/复发）→ Death（死亡，吸收状态）

核心逻辑：
  N_PFS(t) = N × S_PFS(t)
  N_OS(t)  = N × S_OS(t)
  N_PD(t)  = N_OS(t) - N_PFS(t)
  N_Death(t) = N - N_OS(t)
```

**生存分布常用形式：**

| 分布 | 生存函数 S(t) | 危险函数 h(t) | 适用场景 |
|------|---------------|---------------|---------|
| 指数分布 | e^(-λt) | λ（常数） | 危险率恒定 |
| Weibull | e^(-λt^p) | λp·t^(p-1) | 危险率递增/递减 |
| 对数正态 | — | — | 存在峰值危险 |
| 对数逻辑 | — | — | 对称危险函数 |

> **中国指南推荐：** 采用 AIC/BIC 准则选择最优分布，而非仅依赖视觉效果。

### 1.2 Markov 模型 / Markov Model

Markov 模型通过定义状态间转移概率，循环模拟队列演进。

```
周期 t → 周期 t+1：
  [N₁(t+1), N₂(t+1), ..., Nₙ(t+1)] = [N₁(t), N₂(t), ..., Nₙ(t)] × P

其中 P 为 n×n 转移概率矩阵，每行之和为1。
```

**半周期校正（Half-cycle Correction）：**

未校正：状态人数取周期末值 → 高估（或低估）QALY
校正方法：`N_corrected[t] = (N[t-1] + N[t]) / 2`，第0期 `(init + N[0])/2`

---

## 2. 核心计算公式 / Core Formulas

### 2.1 贴现 / Discounting

**年度贴现：**
```
DF(t) = (1 + r)^(-t)   其中 t 为年数，r 为年度贴现率（中国推荐 4.5%）
```

**月度贴现（推荐，与月周期模型一致）：**
```
r_monthly = (1 + r)^(1/12) - 1
DF(t) = (1 + r_monthly)^(-t)   其中 t 为月数
```

### 2.2 QALY 计算 / QALY Calculation

```
QALY = Σ [N_state(t) × u_state × DF(t)] / (N₀ × 12)

其中：
  N_state(t)  = 第 t 月处于该健康状态的人数（半周期校正后）
  u_state     = 该健康状态的效用值
  DF(t)       = 第 t 月贴现因子
  除以 12     = 将月度人年转换为 QALY（单位：人年）
```

### 2.3 成本计算 / Cost Calculation

**药品费（核心，最易出错）：**

```
C_drug = Σ [Cost_monthly(t) × N_PFS(t)/N₀ × DF(t)]

错误算法（切勿使用）：
  C_drug_WRONG = Σ [Cost_monthly(t) × 1.0 × DF(t)]  ← 全员终生用药！
```

**其他成本组件：**

```
C_AE      = Σ [AE_cost_per_patient × N_PFS(t)/N₀ × DF(t)]
C_prog    = Σ [New_PD(t) × Cost_prog × DF(t)] / N₀
C_EOL     = Σ [New_Death(t) × Cost_EOL × DF(t)] / N₀
C_total   = C_drug + C_AE + C_prog + C_EOL + Other_costs
```

### 2.4 ICER 计算 / ICER Calculation

```
ICER = ΔC / ΔQ = (C_treat - C_ctrl) / (QALY_treat - QALY_ctrl)

判定标准（中国 WTP = 3×人均GDP ≈ 270,000 元/QALY）：
  ICER < WTP        → 具有成本效果
  ICER ≥ WTP        → 不具有成本效果
  ICER < 0          → 占优（成本更低，效果更好）
```

---

## 3. Python 实现模板 / Python Implementation Template

### 3.1 完整 PSM 重建模板

```python
import numpy as np

# ========== 参数设定 ==========
N0 = 1000                   # 初始队列大小
N_MONTHS = 28 * 12          # 模拟时长（月）
DR = 0.045                  # 年度贴现率
r_month = (1 + DR)**(1/12) - 1
df = np.array([(1 + r_month)**(-(t+1)) for t in range(N_MONTHS)])

# 生存曲线参数（从报告提取）
OS_lam = 0.025              # 示例：指数分布 λ
PFS_lam = 0.132             # 示例：Weibull λ
PFS_p = 0.813               # 示例：Weibull 形状参数

# 效用值（从报告提取）
u_pfs = 0.498               # 示例：无进展生存效用值
u_pd = 0.360                # 示例：进展后效用值

# 药品费参数（从报告提取，按实际报告替换）
price_per_tablet = 80.33    # 示例：元/片
daily_tablets = 6           # 示例：稳定期每日片数


# ========== 生存曲线 ==========
def os_survival(t, lam):
    return np.exp(-lam * t)

def pfs_survival(t, lam, p):
    return np.exp(-lam * (t ** p))

# 评估时点（半周期校正：取每月中点）
t_pts = np.arange(0.5, N_MONTHS + 0.5, 1.0)

OS = os_survival(t_pts, OS_lam)
PFS = pfs_survival(t_pts, PFS_lam, PFS_p)


# ========== 半周期校正 ==========
def half_cycle(population_frac, n_months, init=N0):
    """半周期校正：取相邻两期平均值"""
    pop = population_frac * N0
    a = np.zeros(n_months)
    a[0] = (init + pop[0]) / 2          # 第0期特殊处理
    for i in range(1, n_months):
        a[i] = (pop[i-1] + pop[i]) / 2
    return a

apfs = half_cycle(PFS, N_MONTHS, N0)
aos  = half_cycle(OS, N_MONTHS, N0)
apd  = aos - apfs
```

*(continued in Section 3.2)*

### 3.2 成本计算（正确算法）

```python
# ========== 药品费（按PFS人数加权）==========
def calc_drug_cost(price, daily_tablets, limit_months=None):
    """
    正确算法：月药品费 × PFS人数比例 × 贴现因子
    """
    total = 0
    for m in range(N_MONTHS):
        if limit_months is not None and m >= limit_months:
            break
        month_idx = m + 1  # 1-indexed
        if month_idx == 1:
            # 第1月：剂量递增过程
            mc = (7*3 + 7*4 + 7*5 + 9*daily_tablets) * price
        else:
            mc = daily_tablets * 30 * price
        pfs_frac = apfs[m] / N0
        total += mc * pfs_frac * df[m]
    return total

drug_cost = calc_drug_cost(price_per_tablet, daily_tablets)

# ========== 非药品成本 ==========
# 不良反应费（按PFS人数加权）
ae_cost_monthly = 0.067*20 + 0.111*25 + 0.067*300  # 示例
ae_cost = np.sum(ae_cost_monthly * apfs / N0 * df)

# 进展住院费（按新发PD人数加权）
pd_state = aos - apfs   # 校正后PD人数
new_pd = np.maximum(0, np.diff(np.concatenate([[N0], pd_state])))
prog_cost = np.sum(new_pd * 19400 * df) / N0   # 示例住院费

# 终末期费用（按新增死亡人数加权）
new_death = np.maximum(0, np.diff(np.concatenate([[0], (N0 - aos)])))
eol_cost = np.sum(new_death * 15000 * df) / N0

total_cost = drug_cost + ae_cost + prog_cost + eol_cost
```

### 3.3 逆向工程：从情景结果反推算法

```python
# ========== 逆向工程模板 ==========
# 已知：报告给出多个情景的总成本（以4个情景为例）
C_base   = 210983   # 示例值：基线情景总成本（元/人）
C_s1     = 169664   # 示例值：情景1总成本
C_s2     = 149143   # 示例值：情景2总成本
C_s3     = 115693   # 示例值：情景3总成本

# 核心假设：非药品成本与药品费无关（各情景固定不变）
# 则每个情景的总成本可表示为：
#     C_i = DrugCost_base × w_i + NonDrugCost
# 其中 w_i 为该情景下药品费相对于基线的权重

# 从两个情景联立方程，解出基线药品费和非药品成本：
# 以基线和情景3为例：
#   C_base = DrugCost × w_base + NonDrugCost    (通常 w_base = 1.0)
#   C_s3   = DrugCost × w_3 + NonDrugCost
# → DrugCost = (C_base - C_s3) / (w_base - w_3)

w_base, w_3 = 1.0, 0.5       # 示例权重（根据实际情景定义调整）
DrugCost_base = (C_base - C_s3) / (w_base - w_3)
NonDrugCost   = C_base - DrugCost_base * w_base

print(f"反推基线药品费: {DrugCost_base:,.0f} 元")
print(f"反推非药品成本: {NonDrugCost:,.0f} 元")

# 验证：将解出值代入其余情景进行交叉验证
# （需根据实际情景定义计算对应权重 w_1、w_2）
w_1, w_2 = None, None        # ← 按实际情景定义填入
if w_1 is not None:
    C_s1_rebuilt = DrugCost_base * w_1 + NonDrugCost
    print(f"情景1重建: {C_s1_rebuilt:,.0f} 元 vs 报告 {C_s1:,.0f} 元")
```

---

## 4. 验证判定标准 / Validation Criteria

### 4.1 量化偏差判定

| 偏差范围 | 符号 | 判定 | 后续行动 |
|---------|------|------|---------|
| |Δ| ≤ 3% | ✅ | 验证通过，无需额外说明 |
| 3% < |Δ| ≤ 5% | ✅ | 验证通过，可在报告中注明微小差异来源 |
| 5% < |Δ| ≤ 15% | ⚠️ | 有条件通过，必须说明差异来源 |
| |Δ| > 15% | ❌ | 不通过，存在算法错误，需深入排查 |

### 4.2 各指标验证优先级

```
第一优先级（必须精确验证）：
  ✅ 实验组成本（尤其是药品费）
  ✅ ICER（核心结论指标）
  ✅ 增量成本 ΔC

第二优先级（允许小幅偏差）：
  ⚠️ 对照组成本（参数常未充分公开）
  ⚠️ QALY 绝对值（效用值来源可能影响）

第三优先级（方向正确即可）：
  △ 敏感性分析结果（方向一致、排序一致）
  △ 预算影响（数量级正确即可）
```

---

## 5. 常见错误案例库 / Common Error Case Library

### 案例1：药品费未加权（全员全额计算）

| 项目 | 错误算法 | 正确算法 |
|------|---------|---------|
| 公式 | `Σ 月费 × 1.0 × DF` | `Σ 月费 × (N_PFS/N₀) × DF` |
| 典型结果（错误）| 数百万元/人级别 | 正常量级（数万~数十万元）|
| 偏差 | **可达 10倍以上** | 基准（正确） |

**检测方法：** 若单人药品费 > 100万人民币，立即警惕。这是最常见的药经模型重建错误。

### 案例2：月度贴现率计算错误

| 错误做法 | 正确做法 |
|---------|---------|
| `df = (1+0.045)^(-t)` （t为月数，错误！）| `r_m = (1+0.045)^(1/12)-1; df = (1+r_m)^(-t)` |
| 直接用年度贴现率按月计算 | 先换算为月度贴现率再计算 |

**影响：** 长期模型（>10年）偏差可达 20% 以上。

### 案例3：QALY 漏除 12（月→年转换）

```python
# 错误：
qaly = np.sum(pop * u * df) / N0        # 结果约 14（明显过大）

# 正确：
qaly = np.sum(pop * u * df) / N0 / 12   # 结果约 1.2（合理）
```

### 案例4：半周期校正遗漏

```python
# 错误（未校正）：
apfs[0] = pop[0]   # 直接用周期末值

# 正确（半周期校正）：
apfs[0] = (N0 + pop[0]) / 2   # 取初始值与周期末的平均值
```

**影响：** 首周期 QALY 高估约 50%，整体 QALY 偏差约 2~5%。

---

## 附录：中国药物经济学评价指南要点（2025版）

| 项目 | 推荐标准 |
|------|---------|
| 贴现率 | 4.5%（成本与效果同时贴现）|
| 支付意愿阈值 | 3倍人均GDP（约270,000元/QALY）|
| 研究角度 | 医保支付方（主要）/ 全社会 |
| 时间范围 | 患者终生（或足够长，覆盖主要成本/效果差异）|
| 敏感性分析 | 必须包含：单因素、概率敏感性分析（PSA，≥1000次）|
| 模型透明性 | 必须公开：模型结构、参数来源、计算公式 |

---

*本参考文档随验证实践持续更新。最后更新：2026-05-01*
