#!/usr/bin/env node

const https = require('https');

const args = process.argv.slice(2);
if (args[0] === 'models') {
  console.log("Check supported models here: https://www.weryai.com/api/discovery");
  process.exit(0);
}

let API_TOKEN = process.env.WERYAI_API_KEY || '';

if (!API_TOKEN) {
  console.error("Error: WERYAI_API_KEY is not set.");
  process.exit(1);
}

let MODEL = "WERYAI_PODCAST_1_0";
let podcastArgs = [];
for (let i = 0; i < args.length; i++) {
  if (args[i] === '--model' && i + 1 < args.length) {
    MODEL = args[i + 1];
    i++;
  } else {
    podcastArgs.push(args[i]);
  }
}
const query = podcastArgs.join(' ');

if (!query) {
  console.error("Please provide a query. Usage: node weryai-podcast.js [--model <model>] <query>");
  process.exit(1);
}

async function request(url, options, body = null, retries = 3) {
  for (let i = 0; i < retries; i++) {
    try {
      return await new Promise((resolve, reject) => {
        const req = https.request(url, options, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => {
            try { resolve(JSON.parse(data)); } catch (e) { resolve(data); }
          });
        });
        req.on('error', reject);
        req.setTimeout(30000, () => req.destroy(new Error('Request timeout')));
        if (body) req.write(JSON.stringify(body));
        req.end();
      });
    } catch (error) {
      if (i === retries - 1) throw error;
      await new Promise(res => setTimeout(res, 2000 * (i + 1)));
    }
  }
}

async function generatePodcast() {
  
  console.log(`Submitting podcast text task for topic: "${query}" using model: ${MODEL}...`);
  
  const submitRes = await request('https://api.weryai.com/growthai/v1/generation/podcast/generate/text', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': API_TOKEN
    }
  }, {
    model: MODEL,
    query: query,
    speakers: ["travel-girl-english", "leo-9328b6d2"],
    language: "en",
    mode: "quick"
  });

  if (!submitRes.success && !submitRes.data) {
    console.error("Text task submission failed:", submitRes);
    process.exit(1);
  }

  const taskId = submitRes.data ? submitRes.data.task_id : submitRes.task_id;
  console.log(`Task submitted successfully. Task ID: ${taskId}`);
  console.log(`Phase 1: Generating script...`);

  // Poll for text generation
  while (true) {
    await new Promise(r => setTimeout(r, 5000));
    const statusRes = await request(`https://api.weryai.com/growthai/v1/generation/${taskId}/status`, {
      method: 'GET',
      headers: { 'x-api-key': API_TOKEN }
    });

    const cStatus = statusRes.data ? statusRes.data.content_status : statusRes.content_status;
    if (cStatus === 'text-success') {
      console.log(`\nScript generation successful! Moving to Phase 2: Generating audio...`);
      break;
    } else if (cStatus === 'text-fail') {
      console.error("\nText generation failed:", JSON.stringify(statusRes));
      process.exit(1);
    } else {
      console.log(".");
    }
  }

  // Trigger Audio generation
  const audioSubmitRes = await request(`https://api.weryai.com/growthai/v1/generation/podcast/generate/${taskId}/audio`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': API_TOKEN
    }
  }, {});
  
  if (!audioSubmitRes.success && !audioSubmitRes.data) {
    console.error("Audio generation trigger failed:", audioSubmitRes);
    process.exit(1);
  }

  // Poll for audio generation
  while (true) {
    await new Promise(r => setTimeout(r, 5000));
    const statusRes = await request(`https://api.weryai.com/growthai/v1/generation/${taskId}/status`, {
      method: 'GET',
      headers: { 'x-api-key': API_TOKEN }
    });

    const cStatus = statusRes.data ? statusRes.data.content_status : statusRes.content_status;
    if (cStatus === 'audio-success') {
      console.log(`\nAudio generation successful!`);
      const data = statusRes.data || statusRes;
      const audioUrl = data.audio_url || data.audios?.[0] || data.podcast_audio_url || (data.videos && data.videos[0]);
      if (audioUrl) {
        console.log(`\nAudio URL: ${audioUrl}`);
      }
      break;
    } else if (cStatus === 'audio-fail') {
      console.error("\nAudio generation failed:", JSON.stringify(statusRes));
      process.exit(1);
    } else {
      console.log(".");
    }
  }
}
generatePodcast();

