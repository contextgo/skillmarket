#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
WeChat Sender - Windows 微信自动发送工具核心类

支持功能：
- 发送文字消息
- 发送图片
- 发送文件

使用示例：
    from wechat_sender import WeChatSender
    
    sender = WeChatSender()
    sender.send_message("YHD", "你好")
    sender.send_image("YHD", "C:/path/to/image.jpg")
    sender.send_file("YHD", "C:/path/to/file.xlsx")
"""

import pyautogui
import pyperclip
import ctypes
import time
import sys
import os
import io
from ctypes import wintypes

if sys.platform == 'win32':
    import win32clipboard
from pathlib import Path

if sys.platform == 'win32':
    sys.stdout.reconfigure(encoding='utf-8')

# 注意：GUI 自动化时 FAILSAFE 会被误触发（如窗口贴近屏幕边缘），
# 导致脚本随机中断。此处关闭以确保操作稳定性，用户可随时手动关闭脚本。
pyautogui.FAILSAFE = False
pyautogui.PAUSE = 0.5


class WeChatSender:
    """微信自动发送工具类"""
    
    def __init__(self, verbose: bool = True):
        """
        初始化微信发送器
        
        Args:
            verbose: 是否打印详细日志
        """
        self.verbose = verbose
        self.user32 = ctypes.windll.user32
        self.hwnd = None
        self.win_rect = None
        
    def log(self, msg: str):
        """打印日志"""
        if self.verbose:
            print(f"[WeChatSender] {msg}")
    
    def find_wechat_window(self) -> bool:
        """
        查找微信主窗口
        
        Returns:
            bool: 是否找到窗口
        """
        main_hwnds = []
        child_hwnds = []
        
        def enum_callback(hwnd, lParam):
            length = self.user32.GetWindowTextLengthW(hwnd)
            if length > 0:
                buffer = ctypes.create_unicode_buffer(length + 1)
                self.user32.GetWindowTextW(hwnd, buffer, length + 1)
                title = buffer.value
                if '微信' in title:
                    class_buffer = ctypes.create_unicode_buffer(256)
                    self.user32.GetClassNameW(hwnd, class_buffer, 256)
                    class_name = class_buffer.value
                    if class_name.startswith('Qt5'):
                        main_hwnds.append(hwnd)
                    elif class_name.startswith('Chrome_WidgetWin'):
                        child_hwnds.append(hwnd)
            return True
        
        EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)
        self.user32.EnumWindows(EnumWindowsProc(enum_callback), 0)
        
        # 关闭子窗口
        for child_hwnd in child_hwnds:
            self.user32.PostMessageW(child_hwnd, 0x0010, 0, 0)  # WM_CLOSE
            time.sleep(0.5)
        
        if child_hwnds:
            time.sleep(1)
        
        if not main_hwnds:
            self.log("未找到微信主窗口")
            return False
        
        self.hwnd = main_hwnds[0]
        self.log(f"找到微信窗口: hwnd={self.hwnd}")
        return True
    
    def activate_window(self) -> bool:
        """
        激活微信窗口（恢复最小化并强制置前台）
        
        使用 AttachThreadInput + keybd_event(Alt) + SetForegroundWindow 组合，
        解决 Windows 限制非前台进程调用 SetForegroundWindow 的问题。
        单独使用 SetForegroundWindow 或 SetWindowPos(HWND_TOPMOST) 均不可靠。
        
        Returns:
            bool: 是否成功激活
        """
        if not self.hwnd:
            self.log("请先调用 find_wechat_window()")
            return False
        
        # 恢复最小化
        if self.user32.IsIconic(self.hwnd):
            self.user32.ShowWindow(self.hwnd, 9)  # SW_RESTORE
            time.sleep(1)
            self.log("已恢复最小化窗口")
        
        # === 可靠的前台切换：AttachThreadInput + keybd_event ===
        # Windows 只允许前台进程的线程调用 SetForegroundWindow，
        # 通过 AttachThreadInput 将当前线程附加到前台线程，绕过此限制。
        foreground_hwnd = self.user32.GetForegroundWindow()
        foreground_thread = self.user32.GetWindowThreadProcessId(foreground_hwnd, None)
        wechat_thread = self.user32.GetWindowThreadProcessId(self.hwnd, None)
        
        attached = False
        if foreground_thread != wechat_thread:
            self.user32.AttachThreadInput(foreground_thread, wechat_thread, True)
            attached = True
        
        self.user32.ShowWindow(self.hwnd, 9)  # SW_RESTORE（确保不是最小化）
        time.sleep(0.3)
        self.user32.BringWindowToTop(self.hwnd)
        time.sleep(0.3)
        
        # 模拟 Alt 键，欺骗 Windows 允许前台切换
        self.user32.keybd_event(0x12, 0, 0, 0)  # Alt down
        self.user32.keybd_event(0x12, 0, 2, 0)  # Alt up
        time.sleep(0.1)
        
        self.user32.SetForegroundWindow(self.hwnd)
        time.sleep(0.5)
        
        if attached:
            self.user32.AttachThreadInput(foreground_thread, wechat_thread, False)
        
        time.sleep(1.5)  # 等待 UI 完全就绪
        
        # 验证切换结果
        new_fg = self.user32.GetForegroundWindow()
        if new_fg != self.hwnd:
            self.log(f"警告：前台切换可能未成功 (fg={new_fg}, wechat={self.hwnd})")
        
        # 获取窗口位置
        rect = wintypes.RECT()
        self.user32.GetWindowRect(self.hwnd, ctypes.byref(rect))
        self.win_rect = (rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top)
        self.log(f"窗口位置: ({rect.left}, {rect.top}, {rect.right}, {rect.bottom})")
        
        return True
    
    def search_contact(self, contact_name: str) -> bool:
        """
        搜索并进入联系人聊天窗口
        
        Args:
            contact_name: 联系人名称
            
        Returns:
            bool: 是否成功
        """
        if not self.win_rect:
            self.log("请先调用 activate_window()")
            return False
        
        win_left, win_top, win_width, win_height = self.win_rect
        
        # 点击左侧聊天列表区域
        pyautogui.click(win_left + 80, win_top + 150)
        time.sleep(1)
        
        # Ctrl+F 打开搜索
        pyautogui.hotkey('ctrl', 'f')
        time.sleep(2)
        
        # 点击搜索框并输入
        pyautogui.click(win_left + 150, win_top + 40)
        time.sleep(1)
        pyautogui.hotkey('ctrl', 'a')
        time.sleep(0.3)
        pyperclip.copy(contact_name)
        pyautogui.hotkey('ctrl', 'v')
        time.sleep(2)
        
        # 第一次回车：确认选择联系人
        pyautogui.press('enter')
        time.sleep(2)
        
        # 第二次回车：进入聊天窗口
        pyautogui.press('enter')
        time.sleep(2)
        
        # 点击输入框区域
        input_x = win_left + win_width // 2
        input_y = win_top + win_height - 100
        pyautogui.click(input_x, input_y)
        time.sleep(1)
        
        self.log(f"已进入联系人 '{contact_name}' 的聊天窗口")
        return True
    
    def send_message(self, contact_name: str, message: str) -> bool:
        """
        发送文字消息
        
        Args:
            contact_name: 联系人名称
            message: 消息内容
            
        Returns:
            bool: 是否成功
        """
        self.log(f"准备发送消息给 '{contact_name}': {message[:50]}...")
        
        if not self.find_wechat_window():
            return False
        
        if not self.activate_window():
            return False
        
        if not self.search_contact(contact_name):
            return False
        
        # 发送消息
        pyperclip.copy(message)
        pyautogui.hotkey('ctrl', 'v')
        time.sleep(1)
        pyautogui.press('enter')
        time.sleep(1)
        
        self.log("消息发送完成")
        return True
    
    def send_image(self, contact_name: str, image_path: str) -> bool:
        """
        发送图片
        
        Args:
            contact_name: 联系人名称
            image_path: 图片路径
            
        Returns:
            bool: 是否成功
        """
        self.log(f"准备发送图片给 '{contact_name}': {image_path}")
        
        if not Path(image_path).exists():
            self.log(f"图片不存在: {image_path}")
            return False
        
        if not self.find_wechat_window():
            return False
        
        if not self.activate_window():
            return False
        
        if not self.search_contact(contact_name):
            return False
        
        # 将图片转换为 BMP/DIB 格式并复制到剪贴板
        import win32clipboard
        import win32con
        from PIL import Image
        
        img = Image.open(image_path).convert('RGB')
        buf = io.BytesIO()
        img.save(buf, 'BMP')
        bmp_data = buf.getvalue()[14:]  # 去掉 BMP 文件头
        
        win32clipboard.OpenClipboard()
        win32clipboard.EmptyClipboard()
        win32clipboard.SetClipboardData(win32con.CF_DIB, bmp_data)
        win32clipboard.CloseClipboard()
        
        time.sleep(0.5)
        
        # 点击输入框区域，确保焦点在输入框（2026-04-29 修复）
        win_left, win_top, win_width, win_height = self.win_rect
        input_x = win_left + win_width // 2
        input_y = win_top + win_height - 100
        pyautogui.click(input_x, input_y)
        time.sleep(1)
        
        # Ctrl+A 全选输入框内容（搜索后输入框可能残留搜索词，如YHD）
        pyautogui.hotkey('ctrl', 'a')
        time.sleep(0.5)
        
        # 粘贴并发送
        pyautogui.hotkey('ctrl', 'v')
        time.sleep(2)
        pyautogui.press('enter')
        time.sleep(1)
        
        self.log("图片发送完成")
        return True
    
    def send_file(self, contact_name: str, file_path: str) -> bool:
        """
        发送文件
        
        Args:
            contact_name: 联系人名称
            file_path: 文件路径
            
        Returns:
            bool: 是否成功
        """
        self.log(f"准备发送文件给 '{contact_name}': {file_path}")
        
        if not Path(file_path).exists():
            self.log(f"文件不存在: {file_path}")
            return False
        
        if not self.find_wechat_window():
            return False
        
        if not self.activate_window():
            return False
        
        if not self.search_contact(contact_name):
            return False
        
        # 使用 win32clipboard 将文件路径以 CF_HDROP 格式写入剪贴板
        abs_path = os.path.abspath(file_path)
        path_bytes = (abs_path + '\0').encode('utf-16-le')

        class DROPFILES(ctypes.Structure):
            _fields_ = [
                ('pFiles', ctypes.c_uint32),   # 文件列表偏移
                ('pt_x',   ctypes.c_int32),
                ('pt_y',   ctypes.c_int32),
                ('fNC',    ctypes.c_int32),
                ('fWide',  ctypes.c_bool),
            ]

        df = DROPFILES()
        df.pFiles = ctypes.sizeof(DROPFILES)
        df.fWide = True

        # 分配内存，复制 DROPFILES 头 + 路径 + 双\0结尾
        buf_len = ctypes.sizeof(df) + len(path_bytes) + 2
        GMEM_MOVEABLE = 0x0002
        h_mem = ctypes.windll.kernel32.GlobalAlloc(GMEM_MOVEABLE, buf_len)
        p_mem = ctypes.windll.kernel32.GlobalLock(h_mem)
        ctypes.memmove(p_mem, ctypes.addressof(df), ctypes.sizeof(df))
        ctypes.memmove(p_mem + ctypes.sizeof(df), path_bytes, len(path_bytes))
        ctypes.windll.kernel32.GlobalUnlock(h_mem)

        win32clipboard.OpenClipboard()
        win32clipboard.EmptyClipboard()
        win32clipboard.SetClipboardData(win32clipboard.CF_HDROP, h_mem)
        win32clipboard.CloseClipboard()
        time.sleep(1)
        
        # 粘贴并发送
        pyautogui.hotkey('ctrl', 'v')
        time.sleep(3)
        pyautogui.press('enter')
        time.sleep(1)
        
        self.log("文件发送完成")
        return True


def main():
    """命令行入口"""
    import argparse
    
    parser = argparse.ArgumentParser(description='微信自动发送工具')
    parser.add_argument('--contact', required=True, help='联系人名称')
    parser.add_argument('--message', help='消息内容')
    parser.add_argument('--image', help='图片路径')
    parser.add_argument('--file', help='文件路径')
    
    args = parser.parse_args()
    
    sender = WeChatSender()
    
    if args.message:
        sender.send_message(args.contact, args.message)
    elif args.image:
        sender.send_image(args.contact, args.image)
    elif args.file:
        sender.send_file(args.contact, args.file)
    else:
        print("请指定 --message, --image 或 --file")


if __name__ == '__main__':
    main()
