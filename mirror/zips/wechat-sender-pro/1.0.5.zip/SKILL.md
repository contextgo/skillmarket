---
name: wechat-sender
description: Windows 微信自动发送工具。支持搜索微信联系人并发送文字、图片、文件。通过 GUI 自动化控制微信窗口，无需微信开放接口。触发场景： 离开电脑时，远程指令OpenClaw发送图片/文件给微信联系人。条件： 微信打开并登录（允许最小化）。举例：1、把桌面上的龙虾图片发送给张三（默认微信发送）；2、查找D盘最新的报价单Excel表并发送给李四（默认微信发送）。
version: 1.0.1
author: Huangd-sz
license: MIT
platform: windows
requires:
  - python3
  - pyautogui>=0.63.0,<1.0.0
  - pyperclip>=1.8.0,<2.0.0
  - pywin32>=306,<310
  - Pillow>=10.0.0,<13.0.0
keywords:
  - 微信
  - 自动化
  - 发送消息
  - GUI自动化
---

# WeChat Sender Pro

Windows 微信自动发送工具。支持搜索微信联系人并发送文字、图片、文件。通过 GUI 自动化控制微信窗口，无需微信开放接口。 
触发场景： 离开电脑时，远程指令OpenClaw发送图片/文件给微信联系人。条件： 微信打开并登录（允许最小化）。举例：1、把桌面上的龙虾图片发送给张三（默认微信发送）；2、查找D盘最新的报价单Excel表并发送给李四（默认微信发送）。

## 核心流程

```
找窗口 → 恢复最小化 → 激活 → 搜索联系人 → 进入聊天 → 发送内容
```

## 快速使用

### 发送文字消息

```bash
python scripts/send_message.py --contact "联系人名字" --message "消息内容"
```

### 发送图片

```bash
python scripts/send_image.py --contact "联系人名字" --image "图片路径"
```

### 发送文件

```bash
python scripts/send_file.py --contact "联系人名字" --file "文件路径"
```

## Python API 调用

```python
from scripts.wechat_sender import WeChatSender

# 初始化
sender = WeChatSender()

# 发送文字
sender.send_message("YHD", "你好，这是测试消息")

# 发送图片
sender.send_image("YHD", r"C:\path\to\image.jpg")

# 发送文件
sender.send_file("YHD", r"C:\path\to\file.xlsx")
```

## 脚本说明

| 脚本 | 功能 | 参数 |
|---|---|---|
| `send_message.py` | 发送文字消息 | --contact, --message |
| `send_image.py` | 发送图片 | --contact, --image |
| `send_file.py` | 发送文件 | --contact, --file |
| `wechat_sender.py` | 核心类库 | - |

## 关键要点

1. **必须用 EnumWindows**：pygetwindow.getAllWindows() 找不到最小化窗口
2. **恢复最小化**：用 `ShowWindow(hwnd, 9)`，不能用 `ShowWindow(hwnd, 5)`
3. **关闭子窗口**：通过类名 `Chrome_WidgetWin` 找到并关闭公众号弹窗等子窗口
4. **两次回车**：第一次确认选择联系人，第二次进入聊天窗口
5. **点击输入框**：进入聊天后必须点击输入框区域才能粘贴内容
6. **不要按 ESC**：ESC 会关闭微信窗口导致焦点丢失
7. **中文编码**：Python 脚本开头加 `sys.stdout.reconfigure(encoding='utf-8')`
8. **图片格式**：微信只接受 BMP/DIB 格式，必须转换
9. **前台切换必须用 AttachThreadInput**：单独调用 `SetForegroundWindow` 或 `SetWindowPos(HWND_TOPMOST)` 均不可靠。Windows 只允许前台进程的线程切换前台窗口，必须用以下组合：
   ```python
   foreground_thread = user32.GetWindowThreadProcessId(user32.GetForegroundWindow(), None)
   wechat_thread = user32.GetWindowThreadProcessId(hwnd, None)
   user32.AttachThreadInput(foreground_thread, wechat_thread, True)  # 附加线程
   user32.keybd_event(0x12, 0, 0, 0)  # 模拟 Alt 键（欺骗 Windows）
   user32.keybd_event(0x12, 0, 2, 0)
   user32.SetForegroundWindow(hwnd)
   user32.AttachThreadInput(foreground_thread, wechat_thread, False)  # 取消附加
   ```

## 环境要求

- Windows 操作系统
- Python 3.x
- 依赖包: `pip install "pyautogui>=0.63.0,<1.0.0" "pyperclip>=1.8.0,<2.0.0" "pywin32>=306,<310" "Pillow>=10.0.0,<13.0.0"`
- 微信 PC 客户端已登录
- 目标联系人在微信搜索中可找到

## 安装依赖

```bash
pip install "pyautogui>=0.63.0,<1.0.0" "pyperclip>=1.8.0,<2.0.0" "pywin32>=306,<310" "Pillow>=10.0.0,<13.0.0"
```

## 详细文档

- [reference.md](reference.md) - 详细技术文档和故障排查
- [examples.md](examples.md) - 更多使用示例

## 注意事项

⚠️ **重要**：
- 本工具通过 GUI 自动化实现，不使用微信官方接口
- 请确保微信已打开且能正常使用
- 发送大量消息时请适当增加延时，避免被限制
- 建议先在测试账号上验证流程

## 更新日志

### v1.0.1 (2026-04-24)
- 修复微信窗口被其他窗口遮挡时无法切换到前台的问题
- `activate_window` 方法改用 `AttachThreadInput + keybd_event(Alt) + SetForegroundWindow` 组合，确保微信窗口必定切换到前台

### v1.0.0 (2026-04-16)
- 初始版本
- 支持发送文字、图片、文件
- 完整的错误处理和日志
