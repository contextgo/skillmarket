# WeChat Sender 使用示例

## 基础示例

### 1. 发送简单消息

```python
from wechat_sender import WeChatSender

sender = WeChatSender()
sender.send_message("张三", "你好，这是测试消息")
```

### 2. 发送图片

```python
sender.send_image("张三", r"C:\Users\admin\Desktop\photo.jpg")
```

### 3. 发送文件

```python
sender.send_file("张三", r"C:\Users\admin\Desktop\report.xlsx")
```

---

## 进阶示例

### 4. 批量发送不同消息

```python
messages = [
    ("张三", "张三你好"),
    ("李四", "李四你好"),
    ("王五", "王五你好"),
]

sender = WeChatSender()
for contact, msg in messages:
    sender.send_message(contact, msg)
    time.sleep(3)
```

### 5. 发送多行格式化消息

```python
report = """
📊 每日工作报告

日期：2026-04-16
完成事项：
1. 完成项目 A 的需求分析
2. 编写技术文档
3. 参加团队会议

明日计划：
1. 开始编码实现
2. 代码评审
"""

sender.send_message("领导", report)
```

### 6. 从文件读取并发送

```python
# 从文本文件读取消息
with open('daily_report.txt', 'r', encoding='utf-8') as f:
    content = f.read()

sender.send_message("YHD", content)
```

### 7. 发送多个文件

```python
files = [
    r"C:\Reports\report1.xlsx",
    r"C:\Reports\report2.pdf",
    r"C:\Reports\summary.docx"
]

for file in files:
    sender.send_file("张三", file)
    time.sleep(5)
```

---

## 命令行示例

### 发送消息

```bash
python scripts/send_message.py --contact "张三" --message "你好"
```

### 发送图片

```bash
python scripts/send_image.py --contact "张三" --image "C:\photo.jpg"
```

### 发送文件

```bash
python scripts/send_file.py --contact "张三" --file "C:\report.xlsx"
```

### 静默模式（不打印日志）

```bash
python scripts/send_message.py --contact "张三" --message "你好" --quiet
```

---

## 与定时任务结合

### 使用 cron 定时发送

```python
# daily_report.py
from wechat_sender import WeChatSender
from datetime import datetime

today = datetime.now().strftime('%Y-%m-%d')
message = f"📅 今日日报已生成，请查收。\n生成时间：{today}"

sender = WeChatSender()
sender.send_message("领导", message)
sender.send_file("领导", r"C:\Reports\daily_report.xlsx")
```

配置 cron：
```bash
# 每天 9:30 执行
30 9 * * * python C:\skills\wechat-sender\scripts\daily_report.py
```

---

## 错误处理示例

```python
from wechat_sender import WeChatSender
import time

def send_with_retry(contact, message, max_retries=3):
    """带重试机制的发送"""
    sender = WeChatSender()
    
    for attempt in range(max_retries):
        try:
            success = sender.send_message(contact, message)
            if success:
                print(f"✅ 发送成功: {contact}")
                return True
            else:
                print(f"⚠️ 发送失败，尝试 {attempt + 1}/{max_retries}")
                time.sleep(2)
        except Exception as e:
            print(f"❌ 发送异常: {e}")
            time.sleep(2)
    
    print(f"❌ 发送失败，已重试 {max_retries} 次")
    return False

# 使用
send_with_retry("张三", "重要消息，请查收")
```

---

## 实际应用场景

### 场景 1：自动发送日报

```python
import pandas as pd
from wechat_sender import WeChatSender

# 生成日报
df = pd.read_excel("sales_data.xlsx")
summary = f"""
📊 销售日报

日期：{pd.Timestamp.now().strftime('%Y-%m-%d')}
销售额：{df['amount'].sum():,.2f}
订单数：{len(df)}
"""

# 发送
sender = WeChatSender()
sender.send_message("销售总监", summary)
sender.send_file("销售总监", "sales_report.xlsx")
```

### 场景 2：监控系统告警

```python
def check_server_and_alert():
    """检查服务器状态，异常时告警"""
    import requests
    
    try:
        response = requests.get('https://api.example.com/health', timeout=10)
        if response.status_code != 200:
            alert_msg = f"⚠️ 服务器异常！状态码：{response.status_code}"
            sender = WeChatSender()
            sender.send_message("运维组", alert_msg)
    except Exception as e:
        alert_msg = f"❌ 服务器无法访问：{e}"
        sender = WeChatSender()
        sender.send_message("运维组", alert_msg)
```

### 场景 3：客户关怀

```python
from datetime import datetime

def send_birthday_greeting(contact, name):
    """发送生日祝福"""
    message = f"""
🎂 生日快乐！

亲爱的 {name}，
祝您生日快乐，万事如意！

—— 您的专属客服
"""
    sender = WeChatSender()
    sender.send_message(contact, message)
```
