# WeChat Sender 详细参考文档

## 目录

1. [技术原理](#技术原理)
2. [窗口查找机制](#窗口查找机制)
3. [发送流程详解](#发送流程详解)
4. [故障排查](#故障排查)
5. [高级用法](#高级用法)

---

## 技术原理

### GUI 自动化

本工具通过模拟用户操作实现微信消息发送，不依赖微信官方 API：

1. **窗口操作**：使用 Windows API 查找、激活微信窗口
2. **键盘模拟**：pyautogui 模拟按键（Ctrl+F 搜索、Ctrl+V 粘贴、Enter 发送）
3. **鼠标模拟**：点击聊天区域、输入框等
4. **剪贴板操作**：将文字/图片/文件写入剪贴板后粘贴

### 为什么不用微信 API？

- 微信官方 API 仅对企业开放，申请门槛高
- 个人用户无法获取 API 权限
- GUI 自动化适用于个人使用场景

---

## 窗口查找机制

### EnumWindows vs pygetwindow

| 方法 | 能否找到最小化窗口 | 推荐度 |
|---|---|---|
| EnumWindows (Win32 API) | ✅ 可以 | ⭐⭐⭐⭐⭐ |
| pygetwindow.getAllWindows() | ❌ 不行 | ⭐ |

### 窗口类名

| 类名前缀 | 窗口类型 | 处理方式 |
|---|---|---|
| `Qt5` | 微信主窗口 | 激活使用 |
| `Chrome_WidgetWin` | 子窗口（公众号等） | 需关闭 |

### 代码示例

```python
import ctypes

user32 = ctypes.windll.user32
main_hwnds = []

def enum_callback(hwnd, lParam):
    length = user32.GetWindowTextLengthW(hwnd)
    if length > 0:
        buffer = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(hwnd, buffer, length + 1)
        title = buffer.value
        if '微信' in title:
            class_buffer = ctypes.create_unicode_buffer(256)
            user32.GetClassNameW(hwnd, class_buffer, 256)
            if class_buffer.value.startswith('Qt5'):
                main_hwnds.append(hwnd)
    return True

EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)
user32.EnumWindows(EnumWindowsProc(enum_callback), 0)
```

---

## 发送流程详解

### 完整 10 步流程

```
1. EnumWindows 枚举所有微信窗口
2. 关闭子窗口（公众号弹窗等）
3. ShowWindow(hwnd, 9) 恢复最小化
4. SetForegroundWindow 激活窗口
5. 点击左侧聊天列表区域（确保焦点）
6. Ctrl+F 打开搜索
7. 输入联系人名称
8. 第一次回车 → 确认选择
9. 第二次回车 → 进入聊天
10. 点击输入框 → 发送内容
```

### 为什么需要两次回车？

- **第一次回车**：在搜索结果列表中选中目标联系人
- **第二次回车**：打开选中联系人的聊天窗口

### 为什么需要点击输入框？

进入聊天窗口后，焦点可能在消息列表或其他位置，必须点击输入框才能确保 Ctrl+V 粘贴到正确位置。

---

## 故障排查

### 问题：找不到微信窗口

**原因**：
- 微信未运行
- 微信窗口标题不是"微信"

**解决方案**：
```python
# 检查所有包含"微信"的窗口
import ctypes
user32 = ctypes.windll.user32

def list_all_windows():
    windows = []
    def callback(hwnd, lParam):
        length = user32.GetWindowTextLengthW(hwnd)
        if length > 0:
            buf = ctypes.create_unicode_buffer(length + 1)
            user32.GetWindowTextW(hwnd, buf, length + 1)
            windows.append(buf.value)
        return True
    
    EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)
    user32.EnumWindows(EnumWindowsProc(callback), 0)
    return windows

print([w for w in list_all_windows() if '微信' in w or 'WeChat' in w])
```

### 问题：消息粘贴到错误位置

**原因**：焦点不在输入框

**解决方案**：
```python
# 进入聊天后，点击输入框区域
win_left, win_top, win_width, win_height = win_rect
input_x = win_left + win_width // 2
input_y = win_top + win_height - 100  # 输入框通常在底部
pyautogui.click(input_x, input_y)
time.sleep(1)
```

### 问题：图片发送失败

**原因**：
- 图片格式不支持
- 图片文件不存在
- 剪贴板写入失败

**解决方案**：
```python
# 确保图片转换为 BMP/DIB 格式
from PIL import Image
import io

img = Image.open(image_path).convert('RGB')
buf = io.BytesIO()
img.save(buf, 'BMP')
bmp_data = buf.getvalue()[14:]  # 去掉 14 字节 BMP 文件头
```

### 问题：文件发送失败

**原因**：
- PowerShell 剪贴板操作失败
- 文件路径包含特殊字符

**解决方案**：
```python
# 路径中的反斜杠需要转义
file_path = r'C:\path\to\file.xlsx'.replace('\\', '\\\\')
```

### 问题：中文乱码

**解决方案**：
```python
# Python 脚本开头添加
if sys.platform == 'win32':
    sys.stdout.reconfigure(encoding='utf-8')
```

---

## 高级用法

### 批量发送

```python
from wechat_sender import WeChatSender

sender = WeChatSender()

contacts = ['张三', '李四', '王五']
message = '大家好，这是群发消息'

for contact in contacts:
    sender.send_message(contact, message)
    time.sleep(5)  # 间隔 5 秒，避免被限制
```

### 定时发送（配合 cron）

```bash
# 每天早上 9:30 发送日报
# crontab 表达式: 30 9 * * *
```

### 从文件读取消息

```python
with open('message.txt', 'r', encoding='utf-8') as f:
    message = f.read()

sender.send_message('YHD', message)
```

### 发送带格式的消息

```python
# 多行消息
message = """📋 供应链金融日报

日期：2026-04-16

一、市场动态
- 电子债权凭证规模增长 5%

二、产品热度
- 建行 e信通 排名第一

三、行业关注
- 制造业融资需求旺盛
"""

sender.send_message('YHD', message)
```

---

## 注意事项

1. **避免频繁发送**：微信有反垃圾机制，建议每条消息间隔 3-5 秒
2. **检查窗口状态**：确保微信窗口没有被其他窗口遮挡
3. **测试先行**：建议先在测试账号上验证流程
4. **日志记录**：开启 verbose 模式便于排查问题
5. **异常处理**：生产环境建议添加 try-except 和重试逻辑

---

## 更新记录

| 日期 | 版本 | 更新内容 |
|---|---|---|
| 2026-04-16 | 1.0.0 | 初始版本 |
