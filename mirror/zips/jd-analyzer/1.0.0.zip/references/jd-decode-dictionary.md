# JD 暗语解码词典

> 本词典收录 JD 中常见"黑话"/委婉语/潜台词的真实含义。
> 每条标注置信度和适用场景，供分析时精确匹配。

## 一、工作节奏与文化类

| 原文表述 | 解码含义 | 置信度 | 适用岗位 |
|----------|---------|--------|----------|
| Fast-paced environment / 快节奏环境 | 团队人少事多，技术债重，deadline 频繁 | 🔴 高 | 全类 |
| Dynamic environment / 动态环境 | 方向经常变，需求不稳定，需要频繁适应 | 🔴 高 | 全类 |
| Wear many hats / 一人多职 | 资源严重不足，一个人干三个人的活 | 🔴 高 | 初创/小团队 |
| Self-starter / 自驱型 / 主观能动性强 | 没有导师/mentorship，没人带，全靠自己摸索 | 🔴 高 | 全类 |
| Entrepreneurial mindset / 创业精神 | 没有现成流程，需要自己创造方法 | 🟡 中 | 全类 |
| Work hard, play hard | 暗示每周 50-60 小时工作，用披萨和啤酒补偿 | 🔴 高 | 科技/初创 |
| Comfortable with ambiguity / 适应不确定性 | 没有清晰流程、文档和规范，一切靠自己定义 | 🔴 高 | 产品/运营/技术 |
| Thrive in chaos / 在混乱中成长 | 组织混乱是常态，不要指望秩序感 | 🔴 高 | 初创公司 |
| Flexible hours / 弹性工作时间 | 但期望你随时在线响应（隐性 on-call） | 🟡 中 | 远程岗位 |
| Startup culture / 创业文化 | 资源有限，变化快，但决策链短 | 🟡 中 | 早期公司 |
| Family-like team / 像家人一样的团队 | 可能边界模糊，或难以划清工作生活界限 | 🟡 中 | 小公司 |

## 二、技能与经验类

| 原文表述 | 解码含义 | 置信度 | 适用岗位 |
|----------|---------|--------|----------|
| 3-5 years experience (for entry-level) | 入门级职位写了中高级要求，HR 堆砌的 wish list | 🔴 高 | 技术岗 |
| Equivalent experience 可等效替代经验 | 他们其实找不到符合所有条件的人 | 🟡 中 | 全类 |
| Nice-to-have / Preferred 加分项 | 没有也没关系，不要因为这条自我淘汰 | 🟢 高 | 全类 |
| Rockstar / Ninja / Guru / 10x engineer | 招聘文化不成熟，对人才有幻想式期待 | 🔴 高 | 技术/设计 |
| T-shaped skills / T型人才 | 需要一个领域的深度 + 多个领域的广度 | 🟢 高 | 产品/技术 |
| Full-stack 全栈 | 一个前端+后端+可能还要运维的人 | 🔴 高 | 技术 |
| Proven track record / 有成功案例 | 需要可量化的成果数据，不是"参与了"而是"主导了" | 🟢 高 | 全类 |
| Experience with [specific tool] | 这项技能在面试中大概率会被考察 | 🟢 高 | 全类 |
| Familiarity with / 了解即可 | 不需要精通，但最好知道基本概念 | 🟢 高 | 全类 |
| Hands-on experience / 动手能力 | 不只做管理/规划，要亲自写代码/执行 | 🟡 中 | 技术/运营 |
| Industry experience preferred 有行业经验优先 | 行业 know-how 是隐形门槛，跨行业申请需额外准备 | 🟡 中 | 全类 |

## 三、协作与沟通类

| 原文表述 | 解码含义 | 置信度 | 适用岗位 |
|----------|---------|--------|----------|
| Cross-functional collaboration / 跨部门协作 | 40%+ 时间花在会议和协调上，需要影响无汇报关系的人 | 🔴 高 | 产品/项目/技术 |
| Stakeholder management / 利益相关方管理 | 需要对高管/客户说"不"，处理冲突的能力很重要 | 🟡 中 | 产品/PM/销售 |
| Influence without authority / 无权威影响力 | 你负责的事情需要别人配合但你管不了他们 | 🔴 高 | 项目/产品 |
| Strong communication skills / 沟通能力强 | 要能把复杂的事向非专业人士解释清楚 | 🟢 高 | 技术/数据 |
| Partner with [team] / 与...合作 | 对方的配合意愿未知，你需要主动推进 | 🟡 中 | 全类 |
| Matrix organization experience / 矩阵组织经验 | 汇报线复杂，多个老板，资源争夺激烈 | 🟡 中 | 大公司 |
| Work independently / 独立工作 | 上级不会微观管理，但也意味着支持有限 | 🟡 中 | 全类 |
| Team player / 团队协作者 | 不要太个人英雄主义，能妥协 | 🟡 低 | 全类（过于泛化） |

## 四、战略与结果类

| 原文表述 | 解码含义 | 置信度 | 适用岗位 |
|----------|---------|--------|----------|
| Results-oriented / 结果导向 | 只看产出数字，KPI 压力大，过程透明度高 | 🔴 高 | 销售/增长/运营 |
| Data-driven decision making / 数据驱动决策 | 此前决策靠直觉/经验，现在想引入科学方法论 | 🟡 中 | 产品/运营/战略 |
| Drive growth / 推动增长 | 公司处于增长压力下，这个岗位背负营收/用户指标 | 🔴 高 | 增长/销售/市场 |
| Optimize efficiency / 提升效率 | 当前流程效率低，成本压力大，需要降本 | 🟡 中 | 运维/工程/供应链 |
| 0 to 1 experience / 从0到1经验 | 没有路线图、没有基础设施、没有先例可循 | 🔴 高 | 产品/技术/运营 |
| Scale-up experience / 规模化经验 | 业务要从 10x 到 100x，系统/流程/团队都要重构 | 🟡 中 | 技术/运营 |
| Strategic thinking / 战略思维 | 不只是执行者，需要对业务方向有自己的判断和主张 | 🟡 中 | Senior+ 岗位 |
| Own the outcome / 对结果负责 | 出了问题你是第一责任人，不是"协助"或"参与" | 🟢 高 | Lead/Manager 岗位 |
| Stretch responsibilities / 具有挑战性的职责 | 这个角色可能合并了被裁撤/重组后的岗位职责 | 🟡 中 | 大公司重组期 |
| Impactful work / 有影响力的工作 | 公司希望员工感受到工作的意义，也可能是用愿景代替高薪 | 🟡 低 | 全类 |

## 五、薪资与福利类

| 原文表述 | 解码含义 | 置信度 | 适用岗位 |
|----------|---------|--------|----------|
| Competitive salary / 有竞争力的薪资 | 不敢写具体数字，大概率等于或低于市场中位数 | 🔴 高 | 全类 |
| Salary earning potential / 薪酬潜力 | 底薪低，大部分收入依赖佣金/奖金，波动大 | 🔴 高 | 销售/BD |
| Market-rate compensation / 市场化薪酬 | 就是市场价，没有溢价空间 | 🟡 中 | 全类 |
| Equity / RSU / Stock options | 股权价值不确定，需自行评估公司前景 | 🟢 高 | 科技/初创 |
| Comprehensive benefits / 完善福利 | 标准福利包，无特殊亮点 | 🟡 中 | 全类 |
| Unlimited PTO / 无限年假 | 实际上不敢休太多，文化压力导致平均休假反而更少 | 🟡 中 | 科技公司 |
| Performance bonus / 绩效奖金 | 浮动收入占比高，实际到手可能低于预期 | 🟡 中 | 全类 |
| Relocation assistance available / 提供搬迁支持 | 这个位置在当地招不到合适的人 | 🟡 中 | 全类 |

## 六、团队与发展类

| 原文表述 | 解码含义 | 置信度 | 适用岗位 |
|----------|---------|--------|----------|
| Join a fast-growing team / 加入快速成长的团队 | 团队新成立或快速扩张期 = 高流动率 or 急招 | 🟡 中 | 全类 |
| Small but mighty team / 小而精干的团队 | 人少钱紧，每个人都身兼数职 | 🟡 中 | 初创/小团队 |
| World-class team / 世界级团队 | 团队里有知名背景的人，但也可能有 ego 问题 | 🟡 低 | 大公司 |
| Report to [C-level] / 向CXO汇报 | 岗位可见性高，但政治风险也高 | 🟢 高 | 全类 |
| Mentorship opportunities / 导师机会 | 团队里 senior people 愿意带新人（但也可能没时间） | 🟡 低 | Junior 岗位 |
| Flat hierarchy / 扁平化管理 | 层级少但可能角色不清，或者"扁平"只是口号 | 🟡 中 | 初创/科技 |
| Opportunity to learn / 学习机会 | 用成长换低薪的经典话术 | 🟡 中 | 初级岗位 |
| Career progression / 职业发展路径 | 内部晋升通道存在，但不确定是否真的有机会 | 🟡 低 | 全类 |

## 七、红旗信号速查表

以下表述出现时自动标记为 **🔴 红旗**：

| 表述 | 风险等级 | 原因 |
|------|---------|------|
| "Rockstar/Ninja/Guru/Wizard" | ⭐⭐⭐⭐⭐ | 不成熟的招聘文化 |
| "Work hard, play hard" | ⭐⭐⭐⭐⭐ | 长工时预期 |
| "Wear many hats" + 低薪资 | ⭐⭐⭐⭐ | 严重人手不足且不愿付费 |
| "Family environment" | ⭐⭐⭐ | 边界模糊风险 |
| "Must be comfortable with [X]" where X is unreasonable | ⭐⭐⭐⭐ | 不合理的常态化要求 |
| Title doesn't match responsibilities | ⭐⭐⭐⭐ | 职级压低以少付薪水 |
| Excessive requirements for entry-level | ⭐⭐⭐⭐ | 不现实的期望值 |
| Vague salary ("competitive") for senior role | ⭐⭐⭐ | 薪资谈判空间存疑 |
| "Immediate start" / "ASAP" | ⭐⭐⭐ | 可能是离职替补（了解原因） |
| JD posted >3 months ago still open | ⭐⭐⭐⭐ | 要么招不到人（有问题），要么忘了关（混乱） |

---

*词典来源：基于 LinkedIn/Revarta/Duke University Career Hub/i人事/CSDN/知乎等多源资料整理，持续更新。*
*使用方式：在 Step 3 执行时逐条匹配 JD 文本中的关键词，未命中时使用通用解码原则推理。*
