# Dependency Contract With Signing Foundation

## Principle

本 Skill 仅生成业务模型、业务服务、回调 Handler，不生成签名/验签算法。
签名规则统一复用 `gcp-api-quick-integration`。

## Specification Source

接口字段与 path 真源：`embedded-organ-va-chapter2-6-spec.md`。

## Outbound Calls

- 业务 Service 仅调用既有签名客户端（如 `GcpClient`、`signedPost`、`postJson`）。
- 禁止在业务层拼接待签名串或计算签名。

## Inbound Callbacks

- 回调（如 `applynotify`、`acctbalauditrst`、`entityauditrst`、`bnfauditrst`、`cusauditrst`、`vastatenotify`）统一先验签再解析。
- 禁止复制验签算法；验签实现须与 **`gcp-api-quick-integration/signing-and-verify-spec.md`** 一致：**响应/回调侧签名为 hex**，`hexDecode` 后再 `RSA-SHA512-VERIFY`，**不得**仅按 Base64 解码（除非文档明确兼容且已标注为过渡方案）。

## Implementation Notes（避免客户重复踩坑）

1. **业务 Service** 只负责组装 DTO 并调用底座 HTTP 客户端；**不得**自行改 `X-AGCP-Date` / `Send` / `Auth` / `Crdt` 的生成规则。
2. 若底座由本仓库 Skill 生成，生成后应让客户对照 **`implementation-pitfalls.md`** 做一次头字段与 hex 签名自检。
3. **测试（Java/Spring 出站）**：须生成 **真实 HTTP 集成测试**，**禁止**用 Mockito 等对签名 HTTP 客户端桩替换联调；交付说明中须写明 `base-url`、密钥与本地配置文件（如 `application-local.properties`）、`@SpringBootTest(classes=…)` 及无密钥时跳过整类的策略。
4. **Java 8**：业务测试与公共代码避免 `isBlank`、`Path.of`、`Files.readString`。
5. **可观测性（推荐）**：由底座统一记录请求 URL、body、响应状态与 body；请求头日志应对签名与 keyid **脱敏**。
6. **DTO 形态（Java）**：业务请求/响应须为 **独立源文件 + JavaBean（Lombok `@Getter/@Setter` 或手写）**，便于 `setXxx` 赋值；**禁止**单文件嵌套 `static` 类承载全部接口模型；源文件 **UTF-8 无 BOM**（详见本 Skill 的 `SKILL.md`「请求/响应模型形态」）。**每个字段须有中文注释**（JavaDoc），释义来自内嵌规范表「中文名称」「备注」等（详见 `SKILL.md`「请求/响应字段中文注释」）。
7. **请求 JSON**：**`null` 字段不上送**（不出现 `"field": null`）；签名客户端序列化须 **`NON_NULL`**（或等价），**摘要与 HTTP body 字节一致**（见 `gcp-api-quick-integration/implementation-pitfalls.md` 第 2.1 节）。
