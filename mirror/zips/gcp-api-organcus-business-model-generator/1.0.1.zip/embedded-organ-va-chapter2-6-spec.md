﻿# 内嵌规范：第二至第六章接口（机构 VA）

> 本文件为本 Skill 的唯一接口规范来源，覆盖第2~6章。

## 快速导航

- [第二章结构化](#第二章结构化)
- [第三章结构化](#第三章结构化)
- [第四章结构化](#第四章结构化)
- [第五章结构化](#第五章结构化)
- [第六章结构化](#内嵌规范第六章-合作方客户类接口机构-va)

## 响应公共参数（全局规则）

以下字段适用于**所有合作方 -> 通联接口**的响应报文。  
当接口存在特定响应业务字段时，响应结构应为：`响应公共参数 + 接口特定字段`。

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 响应码 | rspcode | String | 8 | Y | `0000` 表示成功，响应码参考附录 |
| 响应信息 | rspinfo | String | 300 | Y | 响应结果描述 |
| 客户号 | authcus | String | 15 | C | 非成功响应可能不存在 |
| 商户号 | merid | String | 15 | O | 非成功响应可能不存在 |
| 请求流水号 | reqid | String | 32 | C | 非成功响应可能不存在 |
## 第二章（结构化）

### 第二章.1 1. 跨境结汇/离岸下发申请

- 接口：/gcpapi/organvatrx/apply 方向：合作方->通联

#### 请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 申请单流水 | meraplid | String | 32 | Y | 客户自己生成，保持唯一 |
| 收款账户号 | vaaccountno | String | 30 | O | 在【收款户查询】接口返回结果中获取 |
| 提款方式 | trxtype | String | 120 | Y | 跨境结汇：CP105离岸下发：CP109 |
| 交易币种 | currency | String | 3 | Y | 见附录【币种类型】卖出方币种 |
| 到账币种 | withdrawcurrency | String | 3 | A | 到账方账户币种，离岸下发不同币种时必填 |
| 锁定方 | lockflg | String | 1 | O | S:锁定卖出，为空默认为锁定卖出方 |
| 受益人ID | bnfid | String | 30 | A | 提款方式为离岸下发时必填 |
| 本次提现金额 | withdrawamount | Number | 18,2 | Y | 物流运输凭证 |
| 贸易协议或发票 | agrefid | String | 80 | Y | 使用上传文件的fid字段 |
| 海关报关单据 | cdffid | String | 80 | O | 使用上传文件的fid字段 |
| 其他文件 | otherfid | String | 80 | O | 使用上传文件的fid字段 |
| 交易附言 | ps | String | 60 | O |  |
| 申请单号 | applyid | String | 32 | Y |  |

#### 响应报文

- 响应结构：公共参数 + 接口特定字段。

- 响应公共参数见“响应公共参数（全局规则）”；接口特定字段按本节定义补充。

### 第二章.2 2. 离岸换汇

- 接口：/gcpapi/organvaexchange/apply 方向：合作方->通联

#### 请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 申请单流水 | meraplid | String | 32 | Y | 客户自己生成，保持唯一 |
| 收款账户号 | vaaccountno | String | 30 | O | 在【收款户查询】接口返回结果中获取 |
| 到账币种 | payeeccy | String | 3 | O | 见附录【币种类型】 |
| 卖出币种 | payerccy | String | 3 | O | 见附录【币种类型】 |
| 锁定方 | lockamountflag | String | 1 | O | S：锁定卖出方 |
| 金额 | amount | Number | 18,2 | Y |  |
| 申请单号 | applyid | String | 32 | Y |  |

#### 响应报文

- 响应结构：公共参数 + 接口特定字段。

- 响应公共参数见“响应公共参数（全局规则）”；接口特定字段按本节定义补充。

### 第二章.3 3. 同名转账

- 接口：/gcpapi/organvatrx/fundmerge 方向：合作方->通联

#### 请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 申请单流水 | meraplid | String | 32 | Y | 客户自己生成，保持唯一 |
| 付款VA账户号 | payeraccountno | String | 32 | O | 付款方收款账户号，为空情况资金从机构客户虚户出 |
| 到账商户号 | payeemerid | String | 32 | A | 收款户添加完成审批通过后，通过收款户查询接口，结果中获取指定收款户的商户ID（merid）,与到账收款账户号两者必填其一 |
| 到账收款账户号 | payeeaccountno | String | 32 | A | 到账方收款账户号或通联内部虚拟账户号，与到到账商户号两者必填其一 |
| 币种 | currency | String | 3 | O | 见附录【币种类型】 |
| 金额 | amount | Number | 18,2 | Y |  |
| 申请单号 | applyid | String | 32 | Y |  |

#### 响应报文

- 响应结构：公共参数 + 接口特定字段。

- 响应公共参数见“响应公共参数（全局规则）”；接口特定字段按本节定义补充。

### 第二章.4 4. 锁汇询价

- 接口：/gcpapi/apply/lock  方向：合作方->通联

#### 请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 申请单号 | applyId | String | 32 | A | 两者必选其一 |
| 申请单流水 | meraplid | String | 32 | A |  |
| 申请单号 | applyId | String | 32 | Y | 交易金额 |
| 交易币种 | feeCurrency | String | 3 | Y | 结算金额 |
| 结算币种 | settleCurrency | String | 3 | Y | 汇率 |
| 手续费 | fee | Number | 18,6 | Y |  |

#### 响应报文

- 响应结构：公共参数 + 接口特定字段。

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 申请单号 | applyId | String | 32 | Y | 交易金额 |
| 交易币种 | feeCurrency | String | 3 | Y | 结算金额 |
| 结算币种 | settleCurrency | String | 3 | Y | 汇率 |
| 手续费 | fee | Number | 18,6 | Y |  |

### 第二章.5 5. 申请单确认

- 接口：/gcpapi/organvatrx/confirm 方向：合作方->通联

#### 请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 申请单流水 | meraplid | String | 32 | A | meraplid和applyid两者必选其一 |
| 申请单号 | applyid | String | 32 | Y | 成交方式 |
| 商户手续费币种 | merfeeccy | String | 3 | C | 同到账币种，合作方客户自行计算的商户总手续费场景必填 |
| 商户总手续费 | merfee | Number | 20,2 | C | 合作方客户自行计算的商户总手续费场景必填 |

#### 响应报文

- 响应结构：公共参数 + 接口特定字段。

- 响应公共参数见“响应公共参数（全局规则）”；接口特定字段按本节定义补充。

### 第二章.6 6. 提交规范标准申报附件

- 接口：/gcpapi/declare/submitfile方向：合作方->通联

#### 请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 文件ID | fileid | String | 15 | Y | 使用文件上传接口上传文件时的fid |
| 申请单流水 | meraplid | String | 32 | A | 提交申请单时由客户自己生成，和申请单号二选一 |
| 申请单号 | applyId | String | 32 | A | 申报明细对应的申请单号，和申请单流水二选一 |

#### 响应报文

- 响应结构：公共参数 + 接口特定字段。

- 响应公共参数见“响应公共参数（全局规则）”；接口特定字段按本节定义补充。

### 第二章.7 7. 申请单状态通知

- 接口：合作方定义/applynotify 方向：通联->合作方

#### 请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 申请单流水 | meraplid | String | 32 | Y | 批次号 |
| 受益人ID | accid | String | 30 | O | 受益人账号 |
| 锁定方 | lockflg | String | 1 | Y | B/S锁定支付/结算金额 |
| 支付金额 | payamount | Number | 18,6 | Y | B/S方金额 |
| 结算金额 | stlamount | Number | 18,6 | Y | 手续费 |
| 手续费币种 | feeccy | String | 3 | O | 汇率 |
| 支付币种 | payccy | String | 3 | Y | 结算币种 |
| 申报编号 | declarecode | String | 8 | O | 附言 |
| 汇款用途 | purpose | String | 200 | O | 备注 |
| 申请单号 | applyiid | String | 32 | Y | 状态 |
| 状态描述 | stateExplain | String | 300 | Y | 通知时间 |

#### 响应报文

- 响应结构：公共参数 + 接口特定字段。

- 响应公共参数见“响应公共参数（全局规则）”；接口特定字段按本节定义补充。

### 第二章.8 8.  申请单查询

- 接口：/gcpapi/apply/query 方向：合作方->通联

#### 请求报文

- 响应公共参数见“响应公共参数（全局规则）”；接口特定字段按本节定义补充。

#### 响应报文

- 响应结构：公共参数 + 接口特定字段。

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 申请单流水 | meraplid | String | 32 | Y | 批次号 |
| 受益人账号 | acctno | String | 30 | O | 锁定方 |
| 支付金额 | payamount | Number | 20 | Y | 结算金额 |
| 手续费 | fee | Number | 20 | O | 手续费币种 |
| 汇率 | exchrate | Number | 10 | O | 支付币种 |
| 结算币种 | stlccy | String | 3 | Y | 申报编号 |
| 附言 | ps | String | 200 | O | 汇款用途 |
| 备注 | remark | String | 200 | O | 申请单号 |
| 状态 | state | String | 2 | Y | 详细参考“附录——申请单状态” |
| 状态描述 | stateExplain | String | 300 | Y | 合作方分润币种 |
| 合作方分润金额 | cusprofit | Number | 20,2 | C | 针对合作方客户，在商户总手续费中扣除通联手续费后将剩余额度计入合作方余额户中的金额 |
| 创建时间 | createTime | String | 30 | Y | yyyy-MM-ddThh:mi:ss +8时区的日期如：2023-10-15T17:14:23+0800 |
| 完成时间 | payTime | String | 30 | C | yyyy-MM-ddThh:mi:ss +8时区的日期如：2023-10-15T17:14:23+0800 |

### 第二章.9 9.汇率查询

- 接口：/gcpapi/card/getexrate  方向：合作方->通联

#### 请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 交易币种 | currency | String | 3 | Y | 源币种，待换汇币种 |
| 结算币种 | settlecurrency | String | 3 | Y | 目标币种 |

#### 响应报文

- 响应结构：公共参数 + 接口特定字段。

- 响应公共参数见“响应公共参数（全局规则）”；接口特定字段按本节定义补充。


## 第三章（结构化）

### 第三章.1 未命名接口

- 接口：/gcpapi/acctinfo/histbal  方向：合作方->通联

#### 请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 账号 | memacct | String | 22 | O | 充值到账账户账号，账号：“100******” |
| 通联内部账户 | acctno | String | 32 | O | 通联内部账户账号，账号：“800*****” |
| 币种 | currency | String | 3 | O | 币种 |
| 记账起始日期 | begday | String | 8 | Y | yyyyMMdd 固定+8时区的日期 |
| 记账结束日期 | endday | String | 8 | Y | yyyyMMdd 固定+8时区的日期 |

#### 响应报文

- 响应结构：公共参数 + 接口特定字段。

- 响应公共参数见“响应公共参数（全局规则）”；接口特定字段按本节定义补充。

### 第三章.2 2.账务明细查询

- 接口：/gcpapi/acctinfo/acctsdtl  方向：合作方->通联

#### 请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 开始时间 | begdate | String | 25 | Y | ISO格式[yyyy-MM-dd'T'HH:mm:ssZ] |
| 结束时间 | enddate | String | 25 | Y | ISO格式[yyyy-MM-dd'T'HH:mm:ssZ] |
| 充值账号 | memacct | String | 22 | O | 充值到账账户账号 |
| 通联内部虚拟账号 | acctno | String | 22 | O | 通联内部虚拟账号 |
| 系统流水号 | trxid | String | 32 | O | 可指定系统流水号查询相关明细 |
| 页标识 | curpag | String | 10 | O | 为空时表示第1页，下一页的标识从响应获取。 |

#### 响应报文

- 响应结构：公共参数 + 接口特定字段。

- 响应公共参数见“响应公共参数（全局规则）”；接口特定字段按本节定义补充。

### 第三章.3 3.账户余额查询

- 接口：/gcpapi/acctinfo/getacctbal  方向：合作方->通联

#### 请求报文

- 响应公共参数见“响应公共参数（全局规则）”；接口特定字段按本节定义补充。

#### 响应报文

- 响应结构：公共参数 + 接口特定字段。

- 响应公共参数见“响应公共参数（全局规则）”；接口特定字段按本节定义补充。

### 第三章.4 4.入账通知

- 接口：合作方定义/acctbalauditrst 方向：通联->合作方

#### 请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 通知id | nid | String | 32 | Y | 相同id表示同一个通知 |
| 业务关联id | bid | String | 18 | Y | 业务关联id |
| 入账账号 | acctno | String | 15 | Y | 通联内部虚拟账号 |
| 变动金额 | amount | Number | 18,2 | Y | 变动金额 |
| 币种 | currency | String | 3 | Y | 变动金额币种 |
| 交易类型 | trxcod | String | 10 | Y | CP201-打款充值 CP202-结算入账CP203-网关充值 CP213-收款户上账CP217-离岸收款CP309-B2B交易转入(资金归集和生态圈转账的转入） |
| 入账时间 | time | String | 25 | Y | ISO格式[yyyy-MM-dd'T'HH:mm:ssZ] |
| 入账VA账号 | payeeaccountno | String | 45 | O | 如果是VA入账，收款款方VA账户号 |
| 打款方姓名 | payeraccountname | String | 120 | O | 付款方账户名称 |
| 打款方银行账号 | payeraccountno | String | 45 | O | 付款方账户号 |
| 打款方银行号 | payeraccountbank | String | 30 | O | 打款方国家 |
| 附言 | ps | String | 200 | O | 收款账户号 |

#### 响应报文

- 响应结构：公共参数 + 接口特定字段。

- 响应公共参数见“响应公共参数（全局规则）”；接口特定字段按本节定义补充。

### 第三章.5 5.提现/本地付款交易发起

- 接口：/gcpapi/trx/create  方向：合作方->通联

#### 请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 交易流水 | mertrxid | String | 32 | Y | 调用方自己生成，确保唯一 |
| 交易类型 | trxcode | String | 8 | Y | CP208—提现 CP205—本地付款 |
| 锁定方 | lockflg | String | 1 | O | S/B锁定卖方/买方 （不填写默认锁定买方） |
| 账户号 | acctno | String | 15 | Y | 对于提现，账户号就是客户账户号；对于本地付款则是受益人ID |
| 金额 | amount | Number | 18,6 | Y | 币种 |
| 附言 | ps | String | 20 | O | 银行摘要 |
| 商户手续费币种 | merfeeccy | String | 3 | C | 见附录【币种类型】，同交易币种 |
| 商户总手续费 | merfee | Number | 20，2 | C | 针对合作方客户，商户总手续费=二级客户手续费+通联交易手续，通联扣取手续费后，将商户总手续费剩余额度计入合作方余额户； |

#### 响应报文

- 响应结构：公共参数 + 接口特定字段。

- 响应公共参数见“响应公共参数（全局规则）”；接口特定字段按本节定义补充。

### 第三章.6 6.交易查询

- 接口：/gcpapi/trx/query  方向：合作方->通联

#### 请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 商户交易流水 | mertrxid | String | 32 | A | 商户交易流水或通联交易流水二选一 |
| 通联交易流水 | trxid | String | 32 | A | 商户交易流水或通联交易流水二选一 |

#### 响应报文

- 响应结构：公共参数 + 接口特定字段。

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 合作方分润币种 | cusprofitccy | String | 3 | C | 同到账币种 |
| 合作方分润金额 | cusprofit | Number | 20,2 | C | 针对合作方客户，在商户总手续费中扣除通联手续费后将剩余额度计入合作方余额户中的金额 |


## 第四章（结构化）

### 第四章.1 1.  受益实体注册

- 接口：/gcpapi/entity/regbnf  方向：合作方->通联

#### 请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 跟踪号 | ctid | String | 15 | Y | 相同注册的唯一标识，合作方应确保唯一性 |
| 客户名 | entityname | String | 100 | Y | 注册地址 |
| 所属地区 | areacode | String | 10 | Y | 参考附录“国家代码”表——“代码”字段 |
| 住所/经营场所代码 | areadtlcode | String | 6 | C | 所属地区为中国则必填，参考附录【区县代码】内区/县id |
| 客户性质 | flag | String | 1 | Y | 客户性质：1-合资、股份制、民营、2-世界500强或国有、3-个体户、4-个人 |
| 法人联系电话 | tel | String | 30 | Y | 手机号或电话 |
| 客户分类 | cuskind | String | 1 | Y | 1-电子商务平台经营者；2-电子商务平台内经营者；3-其他电子商务经营者 |
| 客户业务 | businesskind | String | 1 | Y | 1-知名品牌官方网站；2-政府组织、事业单位；3-百货类电商；4-教育培训；5-机票、酒店、旅游；6-游戏出海；7-广告服务费；8-物流；9-其他； |
| 是否三证合一 | threcertflag | String | 1 | Y | 1-是 0-否 |
| 社会信用证代码 | creditcode | String | 30 | C | 三证合一必填 |
| 组织机构代码 | organcode | String | 30 | C | 非三证合一必填 |
| 营业执照代码 | buslicense | String | 30 | C | 非三证合一必填 |
| 社会信用代码证有效期 | creditcodeexpire | String | 30 | O | yyyy-MM-dd |
| 法人代表证件号 | legalidno | String | 50 | Y | 法人姓名 |
| 法人邮箱 | legalemail | String | 50 | Y | 法人身份证有效期 |
| 交易网站所属国家/地区 | websitecountry | String | 10 | Y | 参考附录“国家代码”表——“代码”字段 |
| 交易网站名称 | website | String | 500 | Y | 跨境交易地址 |
| 行业属性 | industrycode | String | 4 | Y | 行业属性代码，具体参考附录【行业属性】 |
| 经济类型 | ecoctype | String | 3 | Y | 经济类型代码，具体参考附录【经济类型代码】 |
| 是否特殊经济区内企业 | istaxfree | String | 1 | Y | Y-是 N-否 |
| 特殊经济区内企业类型代码 | taxfreecode | String | 2 | C | 当企业是特殊经济区内企业是，该项必填。具体参考附录【特殊经济区内企业类型代码】 |
| 常住国家代码 | country | String | 3 | Y | 国家代码 |
| 邮政编码 | postalcode | String | 10 | C | 邮政编码 |
| 文件ID | fid | String | 80 | Y | 文件ID，使用文件上传接口上传 |
| 资料类型 | ftype | int | 2 | Y | 详细参考 “附录——资料类型”1、统一社会信用证代码及影印件(盖公章) |

#### 响应报文

- 响应结构：公共参数 + 接口特定字段。

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 状态 | state | String | 2 | Y | 00：审核中; 01：注册成功; |
| 账户响应信息 | acctrets | String | n | C | 如果添加了受益人数组，且为免审商户则必填。字段参考【受益人添加】接口 |

### 第四章.2 2.  受益实体修改

- 接口：/gcpapi/entity/modbnf  方向：合作方->通联

#### 请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 跟踪号 | ctid | String | 15 | A | 注册时的唯一标识，和实体id必填一个 |
| 实体id | entityid | String | 15 | A | 被修改的实体id，和跟踪号必填一个。 |
| 客户名 | entityname | String | 100 | Y | 注册地址 |
| 所属地区 | areacode | String | 10 | Y | 参考附录“国家代码”表——“代码”字段 |
| 住所/经营场所代码 | areadtlcode | String | 6 | C | 所属地区为中国则必填，参考附录【区县代码】内区/县id |
| 客户性质 | flag | String | 1 | Y | 客户性质：1-合资、股份制、民营、2-世界500强或国有、3-个体户、4-个人 |
| 法人联系电话 | tel | String | 30 | Y | 手机号或电话 |
| 客户分类 | cuskind | String | 1 | Y | 1-电子商务平台经营者；2-电子商务平台内经营者；3-其他电子商务经营者 |
| 客户业务 | businesskind | String | 1 | Y | 1-知名品牌官方网站；2-政府组织、事业单位；3-百货类电商；4-教育培训；5-机票、酒店、旅游；6-游戏出海；7-广告服务费；8-物流；9-其他； |
| 是否三证合一 | threcertflag | String | 1 | Y | 1-是 0-否 |
| 社会信用证代码 | creditcode | String | 30 | C | 三证合一必填 |
| 组织机构代码 | organcode | String | 30 | C | 非三证合一必填 |
| 营业执照代码 | buslicense | String | 30 | C | 非三证合一必填 |
| 社会信用代码证有效期 | creditcodeexpire | String | 30 | O | yyyy-MM-dd |
| 法人代表证件号 | legalidno | String | 50 | Y | 法人姓名 |
| 法人邮箱 | legalemail | String | 50 | Y | 法人身份证有效期 |
| 交易网站所属国家/地区 | websitecountry | String | 10 | Y | 参考附录“国家代码”表——“代码”字段 |
| 交易网站名称 | website | String | 500 | Y | 跨境交易地址 |
| 行业属性 | industrycode | String | 4 | C | 行业属性代码，具体参考附录【行业属性】 |
| 经济类型 | ecoctype | String | 3 | C | 经济类型代码，具体参考附录【经济类型代码】 |
| 是否特殊经济区内企业 | istaxfree | String | 1 | C | Y-是 N-否 |
| 特殊经济区内企业类型代码 | taxfreecode | String | 2 | C | 当企业是特殊经济区内企业是，该项必填。具体参考附录【特殊经济区内企业类型代码】 |
| 邮政编码 | postalcode | String | 10 | C | 邮政编码 |
| 文件ID | fid | String | 80 | Y | 文件ID，使用文件上传接口上传 |
| 资料类型 | ftype | int | 2 | Y | 详细参考 “附录——资料类型” |

#### 响应报文

- 响应结构：公共参数 + 接口特定字段。

- 响应公共参数见“响应公共参数（全局规则）”；接口特定字段按本节定义补充。

### 第四章.3 3.  受益实体查询

- 接口：/gcpapi/entity/get 方向：合作方->通联

#### 请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 跟踪号 | ctid | String | 15 | Y |  |
| 跟踪号 | ctid | String | 15 | Y | 相同注册的唯一标识 |
| 实体ID | entityid | Stirng | 15 | C | 审核通过后必填 |
| 实体名称 | entityname | String | 100 | Y | 状态 |
| 状态描述 | stateExplain | String | 150 | O | accts数组，即受益人状态数组 |
| 受益人ID | id | String | 15 | Y | 账户号 |
| 账户币种 | currency | String | 3 | Y | 参考附录“币种类型” |
| 账户名 | accountName | String | 120 | Y | 如果实体ID上送，账号名称必须是受益实体注册的法人代表名称，非国内账户只允许【英文字母数字空格.,/-()'】 |
| 状态 | state | String | 2 | Y | 0-待审核；1-审核通过；2-审核不通过；3-关联实体未审核；4-冻结 |
| 状态描述 | stateExplain | String | 150 | O |  |

#### 响应报文

- 响应结构：公共参数 + 接口特定字段。

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 跟踪号 | ctid | String | 15 | Y | 相同注册的唯一标识 |
| 实体ID | entityid | Stirng | 15 | C | 审核通过后必填 |
| 实体名称 | entityname | String | 100 | Y | 状态 |
| 状态描述 | stateExplain | String | 150 | O | accts数组，即受益人状态数组 |
| 受益人ID | id | String | 15 | Y | 账户号 |
| 账户币种 | currency | String | 3 | Y | 参考附录“币种类型” |
| 账户名 | accountName | String | 120 | Y | 如果实体ID上送，账号名称必须是受益实体注册的法人代表名称，非国内账户只允许【英文字母数字空格.,/-()'】 |
| 状态 | state | String | 2 | Y | 0-待审核；1-审核通过；2-审核不通过；3-关联实体未审核；4-冻结 |
| 状态描述 | stateExplain | String | 150 | O |  |

### 第四章.4 4.  受益实体审核通知

- 接口：合作方自定义/entityauditrst  方向：通联->合作方

#### 请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 跟踪号 | ctid | String | 15 | Y | 注册时合作方提供的惟一标识号 |
| 实体ID | entityid | String | 15 | C | 审核通过后必填 |
| 实体名称 | entityname | String | 100 | Y | 状态 |
| 审核失败原因 | reason | String | 300 | O | 如果审核失败的原因 |

#### 响应报文

- 响应结构：公共参数 + 接口特定字段。

- 响应公共参数见“响应公共参数（全局规则）”；接口特定字段按本节定义补充。

### 第四章.5 5.  受益人添加

- 接口：/gcpapi/bnfacct/create  方向：合作方->通联

#### 请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 实体ID | entityid | String | 15 | C | 受益实体ID |
| 账户号 | accountNo | String | 30 | Y | 银行账号 |
| 账户币种 | currency | String | 3 | Y | 参考附录“币种类型”，如果支持多币种则用逗号分隔。 |
| 账户名 | accountName | String | 120 | Y | 如果实体ID上送，账号名称必须是受益实体注册的法人代表名称，非国内账户只允许【英文字母数字空格.,/-()'】 |
| 账户类型 | nature | String | 2 | Y | 账户类型 00:借记卡 01:存折 02:信用卡 03:准贷记卡 04:预付卡费 05:境外卡 |
| 账户地区/受益人所在国家 | country | String | 10 | Y | 参考附录“国家代码”表——“代码”字段 |
| 账户开户所在国家 | depositcountry | String | 3 | Y | 参考附录“国家代码”表——“代码”字段 |
| 分行编号 | branchCode | String | 5 | A | 账户开户所在国家/地区为香港必填 |
| 客户地址 | cusaddr | String | 100 | C | 非中国内地账户的客户地址不能为空 |
| 账户开户所在城市 | accountcity | String | 50 | C | 【账户开户所在国家】为美国时，必填【账户开户所在国家】为中国时，必填，填入城市代码 |
| 账户开户所在州/省 | accountprovince | String | 50 | C | 【账户开户所在国家】为美国时，必填【账户开户所在国家】为中国时，必填，填入省代码 |
| 账户开户所在区/县 | accountdistrict | String | 20 | O | 【账户开户所在国家】为中国时，必填，填入区/县代码 |
| 账户开户所在邮编 | accountpostcode | String | 20 | C | 【账户开户所在国家】为美国时，必填 |
| 账户属性 | isOSA | String | 3 | C | 账户开户所在国家为中国则必填。 |
| 受益人归属类型 | bentype | String | 1 | C | 账户属性为“在岸账户”时必填； |
| 归属受益人ID | belongid | String | 20 | C | 受益人归属类型为“受益人供应商”时必填；填写归属受益人对应的id |
| 账户省份 | province | String | 10 | O | 参考附录“省市区代码” |
| 账户城市 | city | String | 10 | O | 参考附录“省市区代码 |
| 受益人名称 | benname | String | 100 | C | 账户属性为“在岸账户”时必填； |
| 受益人证件类型 | idtype | String | 2 | C | 账户属性为“在岸账户”时必填； |
| 证件号 | legalidno | String | 20 | O | 如果country与depositcountry字段都是CHN时，必填； |
| 受益人证件有效期 | idexpire | String | 30 | C | 账户属性为“在岸账户”时必填； |
| 受益人联系电话 | telephone | String | 20 | O | 账户地区是日本则必填； |
| 公私类型 | flag | String | 1 | Y | 0:个人(对私) 1:公司(对公) |
| 法人姓名 | legal | String | 100 | C | 账户属性为“在岸账户”且“公私类型”为公司（对公）时必填； |
| 法人证件号 | idno | String | 50 | C | 账户属性为“在岸账户”且“公私类型”为公司（对公）时必填； |
| 银行名称 | bankName | String | 150 | Y | 可大体识别银行就行 |
| 开户行地址 | addr | String | 300 | C | 账户地区非中国必填，【账户名+开户行地址不可超过114个字符（只允许【英文字母数字空格.,/-()'】），否则可能导致境外银行付款失败】 |
| 本地行号 | biccode | String | 60 | C | 参考接口说明。 |
| swiftcode | swiftcode | String | 60 | C | 参考接口说明。商户从离岸VA户下发至该受益人境内银行账户的交易时必填 |
| 大额支付行号/支付行号 | cnaps | String | 30 | C | 参考接口说明。境外（大额支付行号）参考附录【大额行号】，境内（支付行号）参考附录【支付行号】 |
| 中转行号 | clrbank | String | 30 | C | 参考接口说明。 |
| 合作有效期 | expiredate | String | 30 | Y | YYYY-MM-dd |
| 交易网站名称 | website | String | 500 | C | 非必填； |
| 跨境电商网站地址 | websiteurl | String | 500 | C | 非必填； |
| 企业证件照正面 | companyFrontPhoto | String | 80 | C | 账户属性为“在岸账户”且“公私类型”为对公时，必填；上传的文件ID |
| 法人证件照正面 | legalIdFrontPhoto | String | 80 | C | 账户属性为“在岸账户”且“公私类型”为对公时，必填；上传的文件ID |
| 法人证件照反面 | legalIdBackPhoto | String | 80 | C | 账户属性为“在岸账户”且“公私类型”为对公时，必填；上传的文件ID |
| 受益人证件照正面 | benFrontPhoto | String | 80 | C | 账户属性为“在岸账户”且“公私类型”为个人时，必填；上传的文件ID |
| 受益人证件照反面 | benBackPhoto | String | 80 | C | 账户属性为“在岸账户”且“公私类型”为个人时，必填；上传的文件ID |
| 合作协议 | coopAgreeFile | String | 80 | C | 账户属性为“在岸账户”时，上传的文件ID |
| 关联附件 | fid | String | 80 | C | 上传的文件ID |

#### 响应报文

- 响应结构：公共参数 + 接口特定字段。

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 受益人ID | id | String | 15 | Y | 账号 |
| 币种 | currency | String | 3 | Y |  |

### 第四章.6 6.  受益人修改

- 接口：/gcpapi/bnfacct/update  方向：合作方->通联

#### 请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 受益人ID | id | String | 15 | Y | 受益人添加返回的id |
| 实体ID | entityid | String | 15 | C | 受益实体ID |
| 账户号 | accountNo | String | 30 | Y | 银行账号 |
| 账户币种 | currency | String | 3 | Y | 参考附录“币种类型”，如果支持多币种则用逗号分隔。 |
| 账户名 | accountName | String | 120 | Y | 如果实体ID上送，账号名称必须是受益实体注册的法人代表名称，非国内账户只允许【英文字母数字空格.,/-()'】 |
| 账户类型 | nature | String | 2 | Y | 00:借记卡 01:存折 02:信用卡 03:准贷记卡 04:预付卡费 05: 境外卡 |
| 账户地区/受益人所在国家 | country | String | 10 | Y | 参考附录“国家代码”表——“代码”字段 |
| 账户开户所在国家 | depositcountry | String | 3 | Y | 参考附录“国家代码”表——“代码”字段 |
| 分行编号 | branchCode | String | 5 | A | 账户开户所在国家/地区为香港必填 |
| 客户地址 | cusaddr | String | 100 | C | 非中国内地账户的客户地址不能为空 |
| 城市 | accountcity | String | 50 | C | 【账户开户所在国家】为美国时，必填 |
| 州/省 | accountprovince | String | 50 | C | 【账户开户所在国家】为美国时，必填 |
| 邮编 | accountpostcode | String | 20 | C | 【账户开户所在国家】为美国时，必填 |
| 账户属性 | isOSA | String | 3 | C | 账户开户所在国家为中国则必填。 |
| 受益人归属类型 | bentype | String | 1 | C | 账户属性为“在岸账户”时必填； |
| 归属受益人ID | belongid | String | 20 | C | 受益人归属类型为“受益人供应商”时必填；填写归属受益人对应的id |
| 账户省份 | province | String | 10 | O | 参考附录“省市区代码” |
| 账户城市 | city | String | 10 | O | 参考附录“省市区代码 |
| 受益人名称 | benname | String | 100 | C | 账户属性为“在岸账户”时必填； |
| 受益人证件类型 | idtype | String | 2 | C | 账户属性为“在岸账户”时必填； |
| 证件号 | legalidno | String | 20 | C | 如果country与depositcountry字段都是CHN时，必填； |
| 受益人证件有效期 | idexpire | String | 30 | C | 账户属性为“在岸账户”时必填； |
| 手机号 | telephone | String | 20 | C | 账户地区是日本则必填； |
| 公私类型 | flag | String | 1 | Y | 0:个人 1:对公 |
| 法人姓名 | legal | String | 100 | C | 账户属性为“在岸账户”且“公私类型”为公司（对公）时必填； |
| 法人证件号 | idno | String | 50 | C | 账户属性为“在岸账户”且“公私类型”为公司（对公）时必填； |
| 银行名称 | bankName | String | 150 | Y | 可大体识别银行就行 |
| 开户行地址 | addr | String | 300 | C | 账户地区非中国必填，【账户名+开户行地址不可超过114个字符（只允许【英文字母数字空格.,/-()'】），否则可能导致境外银行付款失败】 |
| 本地行号 | biccode | String | 60 | C | 参考接口说明。 |
| swiftcode | swiftcode | String | 60 | C | 参考接口说明。商户从离岸VA户下发至该受益人境内银行账户的交易时必填 |
| 大额支付行号/支付行号 | cnaps | String | 30 | C | 参考接口说明。境外（大额支付行号）参考附录【大额行号】，境内（支付行号）参考附录【支付行号】 |
| 中转行号 | clrbank | String | 30 | C | 参考接口说明。 |
| 合作有效期 | expiredate | String | 30 | Y | YYYY-MM-dd |
| 交易网站名称 | website | String | 500 | C | 非必填 |
| 跨境电商网站地址 | websiteurl | String | 500 | C | 非必填 |
| 企业证件照正面 | companyFrontPhoto | String | 80 | C | 账户属性为“在岸账户”且“公私类型”为对公时，必填；上传的文件ID |
| 法人证件照正面 | legalIdFrontPhoto | String | 80 | C | 账户属性为“在岸账户”且“公私类型”为对公时，必填；上传的文件ID |
| 法人证件照反面 | legalIdBackPhoto | String | 80 | C | 账户属性为“在岸账户”且“公私类型”为对公时，必填；上传的文件ID |
| 受益人证件照正面 | benFrontPhoto | String | 80 | C | 账户属性为“在岸账户”且“公私类型”为个人时，必填；上传的文件ID |
| 受益人证件照反面 | benBackPhoto | String | 80 | C | 账户属性为“在岸账户”且“公私类型”为个人时，必填；上传的文件ID |
| 合作协议 | coopAgreeFile | String | 80 | C | 账户属性为“在岸账户”时，上传的文件ID |
| 关联附件 | fid | String | 80 | O | 上传的文件ID |

#### 响应报文

- 响应结构：公共参数 + 接口特定字段。

- 响应公共参数见“响应公共参数（全局规则）”；接口特定字段按本节定义补充。

### 第四章.7 7.  受益人审核通知

- 接口：合作方自定义/bnfauditrst  方向：通联->合作方

#### 请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 实体ID | entityid | String | 15 | C | 实体ID |
| 账户号 | accountNo | String | 30 | Y | 银行账号 |
| 账户币种 | currency | String | 3 | Y | 参考附录“币种类型” |
| 受益人ID | id | String | 15 | Y | 受益人添加返回的id |
| 状态 | state | String | 2 | Y | 0-待审核；1-审核通过；2-审核不通过；3-关联实体未审核；4-冻结；5-关闭；6-待复审 |
| 状态描述 | stateExplain | String | 100 | O | 状态的描述 |

#### 响应报文

- 响应结构：公共参数 + 接口特定字段。

- 响应公共参数见“响应公共参数（全局规则）”；接口特定字段按本节定义补充。

### 第四章.8 8.  受益人查询

- 接口：/gcpapi/bnfacct/get  方向：合作方->通联

#### 请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 账户ID | id | String | 15 | A | 受益人添加返回的id，账户号和账户ID选其一 |
| 账户号 | accountno | String | 30 | A | 银行账户号要与注册受益人时保持一致，账户号和账户ID选其一 |
| 账户币种 | currency | String | 3 | C | 使用账户号时必选 |

#### 响应报文

- 响应结构：公共参数 + 接口特定字段。

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 受益人ID | id | String | 15 | Y | 账户号 |
| 账户币种 | currency | String | 3 | Y | 账户名 |
| 账户类型 | nature | String | 2 | Y | 00:借记卡 01:存折 02:信用卡 03:准贷记卡 04:预付卡费 05:非CHN卡 |
| 账户地区/受益人所在国家 | country | String | 10 | Y | 参考附录“国家代码” |
| 账户开户所在国家 | depositcountry | String | 3 | Y | 参考附录“国家代码”表——“代码”字段 |
| 分行编号 | branchCode | String | 5 | A | 账户开户所在国家/地区为香港必填 |
| 客户地址 | cusaddr | String | 100 | C | 非中国内地账户的客户地址不能为空 |
| 城市 | accountcity | String | 50 | C | 【账户开户所在国家】为美国时，必填 |
| 州/省 | accountprovince | String | 50 | C | 【账户开户所在国家】为美国时，必填 |
| 邮编 | accountpostcode | String | 20 | C | 【账户开户所在国家】为美国时，必填 |
| 账户属性 | isOSA | String | 3 | C | 受益人归属类型 |
| 归属受益人ID | belongid | String | 20 | C | 账户省份 |
| 账户城市 | city | String | 10 | O | 参考附录“省市区代码 |
| 受益人名称 | benname | String | 100 | C | 受益人证件类型 |
| 证件号 | legalidno | String | 20 | O | 受益人证件有效期 |
| 手机号 | telephone | String | 20 | O | 公私类型 |
| 法人姓名 | legal | String | 100 | C | 法人证件号 |
| 银行名称 | bankName | String | 15 | Y | 开户行地址 |
| 本地行号 | biccode | String | 60 | C | swiftcode |
| 大额支付行号/支付行号 | cnaps | String | 30 | C | 中转行号 |
| 合作有效期 | expiredate | String | 30 | Y | 交易网站名称 |
| 跨境电商网站地址 | websiteurl | String | 500 | C | 企业证件照正面 |
| 法人证件照正面 | legalIdFrontPhoto | String | 80 | C | 法人证件照反面 |
| 受益人证件照正面 | benFrontPhoto | String | 80 | C | 受益人证件照反面 |
| 合作协议 | coopAgreeFile | String | 80 | C | 关联附件 |
| 关联实体 | entityid | String | 15 | O | 状态 |
| 状态描述 | stateExplain | String | 100 | Y | 状态的描述 |

### 第四章.9 9.  受益人列表

- 接口：/gcpapi/bnfacct/list  方向：合作方->通联

#### 请求报文

- 响应公共参数见“响应公共参数（全局规则）”；接口特定字段按本节定义补充。

#### 响应报文

- 响应结构：公共参数 + 接口特定字段。

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 受益人id | id | String | 15 | Y | 客户号 |
| 账户号 | accountNo | String | 30 | Y | 银行账号 |
| 账户币种 | currency | String | 3 | Y | 账户名 |
| 账户类型 | nature | String | 2 | Y | 00:借记卡 01:存折 02:信用卡 03:准贷记卡 04:预付卡费 05:非CHN卡 |
| 账户地区/受益人所在国家 | country | String | 10 | Y | 参考附录“国家代码” |
| 账户开户所在国家 | depositcountry | String | 3 | Y | 参考附录“国家代码”表——“代码”字段 |
| 分行编号 | branchCode | String | 5 | A | 账户开户所在国家/地区为香港必填 |
| 客户地址 | cusaddr | String | 100 | C | 非中国内地账户的客户地址不能为空 |
| 城市 | accountcity | String | 50 | C | 【账户开户所在国家】为美国时，必填 |
| 州/省 | accountprovince | String | 50 | C | 【账户开户所在国家】为美国时，必填 |
| 邮编 | accountpostcode | String | 20 | C | 【账户开户所在国家】为美国时，必填 |
| 账户属性 | isOSA | String | 3 | C | 受益人归属类型 |
| 归属受益人ID | belongid | String | 20 | C | 账户省份 |
| 账户城市 | city | String | 10 | O | 参考附录“省市区代码 |
| 受益人名称 | benname | String | 100 | C | 受益人证件类型 |
| 证件号 | legalidno | String | 20 | O | 受益人证件有效期 |
| 手机号 | telephone | String | 20 | O | 公私类型 |
| 法人姓名 | legal | String | 100 | C | 法人证件号 |
| 银行名称 | bankName | String | 15 | Y | 开户行地址 |
| 本地行号 | biccode | String | 60 | C | swiftcode |
| 大额支付行号/支付行号 | cnaps | String | 30 | C | 中转行号 |
| 合作有效期 | expiredate | String | 30 | Y | 交易网站名称 |
| 跨境电商网站地址 | websiteurl | String | 500 | C | 企业证件照正面 |
| 法人证件照正面 | legalIdFrontPhoto | String | 80 | C | 法人证件照反面 |
| 受益人证件照正面 | benFrontPhoto | String | 80 | C | 受益人证件照反面 |
| 合作协议 | coopAgreeFile | String | 80 | Y | 状态 |


## 第五章（结构化）

### 第五章.1 1. 文件上传

- 接口：/gcpapi/file/upload?fid=fileid&zip=$iszip&spos=position 方向：合作方->通联

#### 请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 文件ID | fid | String | 80 | Y | 同一客户内文件唯一标识，包含原文件格式后缀。 |
| 压缩文件 | zip | boolean | 1 | C | 是否压缩文件，true/false |

#### 响应报文

- 响应结构：公共参数 + 接口特定字段。

- 响应公共参数见“响应公共参数（全局规则）”；接口特定字段按本节定义补充。

### 第五章.2 2. 文件上传查询

- 接口：/gcpapi/file/upquery 方向：合作方->通联

#### 请求报文

- 响应公共参数见“响应公共参数（全局规则）”；接口特定字段按本节定义补充。

#### 响应报文

- 响应结构：公共参数 + 接口特定字段。

- 响应公共参数见“响应公共参数（全局规则）”；接口特定字段按本节定义补充。

### 第五章.3 3. 交易明细下载

- 接口：/gcpapi/file/downtransdetail  方向：合作方->通联

#### 请求报文

- 响应公共参数见“响应公共参数（全局规则）”；接口特定字段按本节定义补充。

#### 响应报文

- 响应结构：公共参数 + 接口特定字段。

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 交易单号 | outtrxid | String | 15 | Y | 申请单号 |
| 系统流水号 | trxid | String | 32 | Y | 子商户号 |
| 交易类型 | trxcode | String | 32 | Y | 状态 |
| 卖出金额 | amount | String | 16,2 | Y | eg: 1,000, |
| 卖出币种 | currency | String | 3 | Y | 买入金额 |
| 买入币种 | setlcurrency | String | 3 | Y | 本方户名 |
| 本方账号 | payeracctno | String | 32 | Y | 对方户名 |
| 对方账号 | payeeacctno | String | 32 | Y | 购汇方式 |
| 手续费 | fee | String | 16,2 | Y | eg: 1,000, |
| 手续费币种 | feecurrency | String | 3 | Y | 原因说明 |
| 申请时间 | starttime | String | 20 | Y | yyyy-MM-dd HH:mm:ss |
| 完成时间 | endtime | String | 20 | Y | yyyy-MM-dd HH:mm:ss |
| 合作方分润币种 | cusprofitccy | String | 3 | C | 见附录【币种类型】 |
| 合作方分润金额 | cusprofit | Number | 20,2 | C | 针对合作方客户，在商户总手续费中扣除通联手续费后将剩余额度计入合作方余额户中的金额 |

### 第五章.4 4. 对账单下载

- 接口：/gcpapi/file/downdailytrxbill  方向：合作方->通联

#### 请求报文

- 响应公共参数见“响应公共参数（全局规则）”；接口特定字段按本节定义补充。

#### 响应报文

- 响应结构：公共参数 + 接口特定字段。

- 响应公共参数见“响应公共参数（全局规则）”；接口特定字段按本节定义补充。

### 第五章.5 5. 日交易账单下载

- 接口：/gcpapi/file/downdailyreport  方向：合作方->通联

#### 请求报文

- 响应公共参数见“响应公共参数（全局规则）”；接口特定字段按本节定义补充。

#### 响应报文

- 响应结构：公共参数 + 接口特定字段。

- 响应公共参数见“响应公共参数（全局规则）”；接口特定字段按本节定义补充。


# 内嵌规范：第六章 合作方客户类接口（机构 VA）

本文件是本 Skill 的唯一接口事实来源，已将第六章整理为结构化字段表，供模型直接生成代码。

## 1. 接口清单

| 序号 | 接口 | Path/路由 | 方向 |
|---|---|---|---|
| 1 | 子客户注册 | `/gcpapi/organcusmanage/regcus` | 合作方->通联 |
| 2 | 子客户基础信息编辑 | `/gcpapi/organcusmanage/updatecus` | 合作方->通联 |
| 3 | 客户状态查询 | `/gcpapi/organcusmanage/get` | 合作方->通联 |
| 4 | 客户状态通知 | `/cusauditrst`（合作方定义） | 通联->合作方 |
| 5 | 收款户添加 | `/gcpapi/organaccount/add` | 合作方->通联 |
| 6 | 收款户状态通知 | `/vastatenotify`（合作方定义） | 通联->合作方 |
| 7 | 收款户查询 | `/gcpapi/b2baccount/query_new` | 合作方->通联 |

## 2. 统一规则

- 6.1 顶层 `organvacusinfo`、`organvainfo`、`uboinfo` 均为字符串类型，值为 JSON 序列化字符串。
- `A/C/O/Y` 保留文档原义；代码生成时按语言习惯映射为必填/条件必填/可选。
- 参考附录字段（国家代码、省市区、证件类型、收款账户状态等）保留注释，不在本文件展开附录表。

## 3. 1) 子客户注册

### 3.1 基本信息

- 接口：`/gcpapi/organcusmanage/regcus`
- 方向：合作方->通联
- 场景：注册的客户为主体开展业务

### 3.2 请求报文（顶层）

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 客户基础信息 | organvacusinfo | String | Not required | Y | 上送 1.1 客户基础信息 jsonstring |
| 收款户信息 | organvainfo | String | Not required | O | 上送 1.2 收款户信息 jsonstring |
| UBO信息 | uboinfo | String | Not required | Y | 上送 1.3 UBO 信息 JSONArray 格式 |

### 3.3 响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 状态 | state | String | 2 | Y | 00：审核中; 01：已注册; 其他情况为空 |
| 客户号 | cusid | String | 32 | Y |  |

### 3.4 1.1 客户基础信息

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 注册跟踪号 | ctid | String | 15 | Y | 相同注册的唯一标识，合作方应确保唯一性 |
| 企业/个人名称 | cusname | String | 100 | Y |  |
| 企业/个人英文名 | cusengname | String | 100 | A | 所在国家/地区为非中国，必填 |
| 所在国家/地区 | areacode | String | 3 | Y | 参考附录“国家代码”表——“代码”字 |
| 注册(联系)地址 | address | String | 256 | Y |  |
| 交易网站所属国家/地区 | websitecountry | String | 10 | Y | 参考附录“国家代码”表——“代码”字 |
| 客户联系人邮箱 | legalemail | String | 50 | Y |  |
| 客户联系电话 | tel | String | 30 | Y | 公司联系手机号或电话 |
| 经营商品类目 | businessnature | String | 20 | Y | 参考附录【经营商品类目】中的代码 |
| 法人/拥有人/董事姓名 | legal | String | 30 | Y |  |
| 法人/拥有人/董事证件类型 | legalidtype | String | 10 | Y | 01居民身份证/02军人或武警身份证/03港澳台通行证/04护照/05其他有效旅行证件/06其他类个人有效证件 |
| 法人/拥有人/董事证件号 | legalidno | String | 30 | Y |  |
| 法人/拥有人/董事证件起始有效期 | legalidbegin | String | 10 | Y | YYYYMMDD |
| 法人/拥有人/董事证件有效期 | legalidexpire | String | 30 | Y | YYYYMMDD |
| 邮编 | postalcode | String | 10 | Y |  |
| 出生日期 | birthdate | String | 15 | Y | 中国填法人生日，其他填拥有人/董事生日；格式 YYYYMMDD |
| 公司成立日期 | companyregdate | String | 15 | Y | YYYYMMDD |
| 所属分公司 | belongbranch | String | 30 | Y | 参考附录【所属分公司代码】 |
| 所在省份 | province | String | 10 | Y | areacode=CHN 时必填，参考附录“省市区代码” |
| 所在城市 | city | String | 10 | Y | areacode=CHN 时必填，参考附录“省市区代码” |
| 所在区县 | areadtlcode | String | 10 | Y | areacode=CHN 时必填，参考附录“省市区代码” |
| 受益人身份证件号码 | bnfidno | String | 50 | Y | areacode=CHN 时必填 |
| 受益人身份证件有效期 | bnfexpire | String | 30 | Y | YYYYMMdd，areacode=CHN 时必填 |
| 营业执照名称 | buslicensename | String | 100 | Y | 客户所在国家为中国时必填 |
| 法人代表住址 | legaladdress | String | 200 | Y |  |
| 法人代表职业 | legaloccop | String | 1 | Y | 1国家机关等/2专业技术人员/3办事人员/4商业服务业/5农林牧渔水利/6生产运输设备操作/7军人/8其他 |
| 法人代表手机号码 | legaltel | String | 20 | Y |  |
| 法人代表国籍 | legalarea | String | 3 | Y | 见附录【1111-国别信息】中的 CODE，如 CHN |
| 法人代表性别 | legalgender | String | 10 | Y | 1男，0女 |
| 控股股东或实际控制人姓名 | holdername | String | 100 | C | areacode=CHN 时必填 |
| 控股股东或实际控制人身份证件号码 | holderidno | String | 32 | C | areacode=CHN 时必填 |
| 控股股东或实际控制人身份证件有效期 | holderexpire | String | 32 | C | areacode=CHN 时必填，YYYYMMdd |
| 法人身份证正面附件 | legalphotofrontfid | String | 200 | Y |  |
| 法人身份证反面附件 | legalphotobackfid | String | 200 | Y |  |
| 公司银行账户开户证明附件 | compcardfid | String | 200 | Y |  |
| 法人银行卡正面附件 | legalcardfrontfid | String | 200 | C | areacode=CHN 时必填 |
| 法人银行卡反面附件 | legalcardbehindfid | String | 200 | C | areacode=CHN 时必填 |
| 是否三证合一 | threcertflag | String | 2 | Y | 0-否，1-是 |

#### 3.4.1 三证合一（threcertflag=1）

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 统一社会信用证代码 | creditcode | String | 30 | Y |  |
| 统一社会信用代码起始有效期 | creditcodebegin | String | 10 | Y | YYYYMMDD |
| 统一社会信用证代码有效期 | creditcodeexpire | String | 30 | Y | YYYYMMDD |
| 统一社会信用证及影印件 | credifid | String | 200 | Y | 统一社会信用证及影印件上传文件 fid |

#### 3.4.2 三证不合一（threcertflag=0）

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 税务登记证代码 | creditcode | String | 30 | Y |  |
| 税务登记证代码起始有效期 | creditcodebegin | String | 10 | Y | YYYYMMDD |
| 税务登记证代码有效期 | creditcodeexpire | String | 30 | Y | YYYYMMDD |
| 税务登记证及影印件 | credifid | String | 200 | Y | 税务登记证及影印件上传文件 fid |
| 组织机构代码 | organcode | String | 30 | Y |  |
| 组织机构代码有效期 | organcodeexpire | String | 30 | Y | YYYYMMDD |
| 组织机构代码及影印件 | organfid | String | 200 | Y | 组织机构代码及影印件上传文件 fid |
| 营业执照代码 | buslicense | String | 10 | Y |  |
| 营业执照有效期 | buslicenseexpire | String | 30 | Y | YYYYMMDD |
| 营业执照 | buslicensefid | String | 200 | Y | 营业执照上传文件 fid |

#### 3.4.3 areacode 非 CHN（境外）扩展

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 营业执照CR代码 | organcode | String | 30 | Y |  |
| 营业执照CR有效期 | organcodeexpire | String | 30 | O | YYYYMMDD |
| 营业执照CR附件 | organfid | String | 200 | Y | 公司注册证书 CR 上传文件 fid |
| 组织机构BR代码 | buslicense | String | 10 | Y |  |
| 组织机构BR有效期 | buslicenseexpire | String | 30 | Y | YYYYMMDD |
| 商业登记证BR附件 | buslicensefid | String | 200 | Y | 商业登记证 BR 上传文件 fid |
| NAR1/NNC1附件 | nar1fid | String | 200 | Y | 满一周年 NAR1 / 未满一周年 NNC1 |
| 董事长身份证/港澳台证件/护照正面 | chairmanfrontfid | String | 200 | Y |  |
| 董事长身份证/港澳台证件/护照反面 | chairmanbehindfid | String | 200 | Y |  |

### 3.5 1.2 收款户信息

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 跟踪号 | ctid | String | 15 | Y | 注册唯一标识，合作方应确保唯一性 |
| 客户号 | cusid | String | 30 | Y | 子客户号 |
| 收款户名称 | vaaccountname | String | 120 | Y | 客户英文名称 |
| 收款国家地区 | areacode | String | 3 | Y | 见附录【收款国家地区及对应支持币种】 |
| 币种 | currency | String | 3 | O | 见附录【收款国家地区及对应支持币种】 |
| 平台名称 | storename | String | 100 | Y |  |
| 店铺URL | weburl | String | 200 | Y |  |

### 3.6 1.3 UBO 信息（数组元素）

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 姓名-中文 | name | String | 100 | Y |  |
| 名-英文 | firstnameen | String | 100 | Y |  |
| 姓-英文 | lastnameen | String | 100 | Y |  |
| 性别 | gender | String | 1 | Y | 1男性，0女性 |
| 归属国家地区 | areacode | String | 3 | Y | 参考附录“国家代码” |
| 居住地址 | residentialaddress | String | 200 | Y |  |
| 证件类型 | idcardtype | String | 2 | Y | 见附录【证件类型】 |
| 证件号码 | idcardno | String | 50 | Y |  |
| 出生日期 | birthday | String | 10 | Y | YYYY-MM-DD |
| 持股比例 | shareholdingratio | String | 5 | Y | 例如 40 或 68.5，且需大于25% |
| 证件有效期-起始 | idcardstartingdate | String | 10 | Y | yyyy-MM-dd |
| 证件有效期-截止 | idcardclosingdate | String | 10 | Y | yyyy-MM-dd |
| 是否为公司高级管理员 | uboismanager | String | 1 | Y | 1是，0否 |
| 是否为高级管理人员 | uboispublic | String | 1 | Y | 1是，0否 |
| 证件照正面 | idcardfront | String | 80 | O | 文件ID，使用文件上传接口上传 |
| 证件照反面 | idcardbehind | String | 80 | O | 文件ID，使用文件上传接口上传 |
| 居住地址证明 | residencephone | String | 80 | O | 文件ID，使用文件上传接口上传 |

## 4. 2) 子客户基础信息编辑

- 接口：`/gcpapi/organcusmanage/updatecus`
- 方向：合作方->通联

### 请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 子客户号 | cusid | String | 32 | Y |  |
| 客户基础信息 | organvacusinfo | String | Not required | Y | 上送 1.1 客户基础信息 jsonstring |

### 响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 状态 | state | String | 2 | Y | 00：审核中; 01：已注册; 其他情况为空 |

## 5. 3) 客户状态查询

- 接口：`/gcpapi/organcusmanage/get`
- 方向：合作方->通联

### 请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 客户跟踪号 | ctid | String | 15 | Y |  |

### 响应报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 跟踪号 | ctid | String | 15 | Y | 相同注册的唯一标识 |
| 客户号 | cusid | String | 15 | C | 已注册情况返回 |
| 客户名 | cusname | String | 100 | C | 已注册情况返回 |
| 状态 | state | String | 2 | Y | 00审核中; 01已注册; 04已关闭; 06审核不通过 |
| 状态描述 | stateexplain | String | 300 | O |  |

## 6. 4) 客户状态通知（回调）

- 接口：`/cusauditrst`（合作方定义）
- 方向：通联->合作方

### 请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 跟踪号 | ctid | String | 15 | Y | 相同注册的唯一标识 |
| 客户号 | cusid | String | 15 | A | 状态为审核成功时返回 |
| 状态 | state | String | 2 | Y | 04审核成功; 05审核失败 |
| 状态描述 | stateexplain | String | 300 | O |  |

## 7. 5) 收款户添加

- 接口：`/gcpapi/organaccount/add`
- 方向：合作方->通联
- 说明：用于添加收款账户信息

### 请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 跟踪号 | ctid | String | 15 | Y | 注册唯一标识，合作方应确保唯一性 |
| 客户号 | cusid | String | 30 | Y | 子客户号 |
| 收款户名称 | vaaccountname | String | 120 | Y | 客户英文名称，大写 |
| 收款国家地区 | areacode | String | 3 | Y | 见附录【收款国家地区及对应支持币种】 |
| 币种 | currency | String | 3 | O | 见附录【收款国家地区及对应支持币种】 |
| 平台名称 | storename | String | 100 | Y |  |
| 店铺URL | weburl | String | 200 | Y |  |

### 响应报文

- 仅返回公共响应参数（按公共响应模型处理）

## 8. 6) 收款户状态通知（回调）

- 接口：`/vastatenotify`（合作方定义）
- 方向：通联->合作方
- 说明：收款户创建后，状态变更通过该接口下发

### 请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 跟踪号 | ctid | String | 15 | Y |  |
| 收款账户号 | vaaccountno | String | 30 | O | VA账号 |
| 收款账户状态 | vaaccountstate | String | 2 | Y | 见附录【收款账户状态】 |
| 状态描述 | vaaccountstateexplain | String | 200 | O |  |

## 9. 7) 收款户查询

- 接口：`/gcpapi/b2baccount/query_new`
- 方向：合作方->通联
- 说明：用于查询收款账户信息

### 请求报文

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 收款账户号 | vaaccountno | String | 30 | A | 与 ctid 两者必选其一 |
| 跟踪号 | ctid | String | 15 | A | 与 vaaccountno 两者必选其一 |

### 响应报文（accountList 主体）

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 跟踪号 | ctid | String | 15 | Y |  |
| 商户ID | merid | String | 32 | Y |  |
| 收款户名称 | vaaccountname | String | 120 | Y |  |
| 收款账户号 | vaaccountno | String | 30 | O | VA账号 |
| 收款账户状态 | vaaccountstate | String | 2 | Y | 见附录【收款账户状态】 |
| 收款账号通联内部账户 | vaaccountdetail | JSONArray | A | 状态为正常时返回；每个 VA 可能多个，按币种区分 |
| 通联内部账户 | tlaccount | String | 30 | O | 一个 VA 有且仅有一个内部账户，多个 VA 可能对应同一个内部账户 |
| 状态描述 | vaaccountstateexplain | String | 200 | O |  |
| 平台名称 | storename | String | 100 | Y |  |
| 店铺URL | weburl | String | 200 | Y |  |
| 创建时间 | createtime | String | 25 | Y | ISO格式 `yyyy-MM-dd'T'HH:mm:ssZ` |
| 账户所在国家/地区 | countryname | String | 100 | O |  |
| 银行名称 | bankname | String | 200 | O |  |
| 银行地址 | addr | String | 300 | O |  |
| 邮编 | postcode | String | 10 | O |  |
| 城市 | cityname | String | 100 | O |  |
| 银行代码 | biccode | String | 10 | O |  |
| SWIFT CODE | swiftcode | String | 10 | O |  |

### 9.1 通联内部账户数据结构（vaaccountdetail 元素）

| 中文名称 | 字段 | 类型 | 长度 | 必输 | 备注 |
|---|---|---|---|---|---|
| 币种 | currency | String | 3 | Y |  |
| 收款户余额 | balance | Number | 18,2 | Y |  |
| 提现中金额 | taskamount | Number | 18,2 | Y |  |
| VA通联内部账户 | tlvaaccountno | String | 30 | Y | va账户所对应的通联内部账号 |

### 9.2 响应示例（节选）

```json
{
  "rspcode": "0000",
  "tlaccount": "xx",
  "vaaccountdetail": [
    {"tlvaaccountno":"80000000310864","balance":697.09,"currency":"CNY","taskamount":"0"},
    {"tlvaaccountno":"80000000310865","balance":23110,"currency":"USD","taskamount":"0"}
  ],
  "rspinfo": "请求处理成功",
  "createtime": "2023-05-09T16:09:33Z",
  "ctid": "xx",
  "cityname": "xx",
  "vaaccountstate": "01",
  "countryname": "xx",
  "storename": "xx",
  "vaaccountname": "xxx",
  "areacode": "HKG",
  "authcus": "xx",
  "reqid": "xx",
  "biccode": "xx",
  "merid": "xx",
  "vaaccountno": "xx",
  "bankname": "xx",
  "addr": "xx"
}
```


