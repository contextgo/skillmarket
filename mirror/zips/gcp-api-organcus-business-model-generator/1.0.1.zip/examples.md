# Examples

规范来源：`embedded-organ-va-chapter2-6-spec.md`（无需外部文档）。

## Example 1

`语言=python；签名客户端=mypkg.gcp_client.GcpClient；回调基址=PARTNER_NOTIFY_BASE_URL。请生成机构VA第二至第六章全部接口代码。`

## Example 2

`在当前项目中生成gcp机构VA接口对接第二至第六章模块。`

预期行为：
1. 自动检查签名底座；
2. 缺失则先自动补齐签名底座，且底座符合 **`gcp-api-quick-integration/signing-and-verify-spec.md`** 与 **`implementation-pitfalls.md`**（hex 签名、请求头格式等）；
3. 再生成第二至第六章业务代码；所有请求/响应/回调模型 **逐字段中文注释**（与内嵌规范表一致）；
4. 为每个 **出站** 接口生成 **真实 HTTP 集成测试**（`@SpringBootTest(classes=启动类)`、真实 Service/Client，**禁止** Mock HTTP 客户端）；交付说明中含本地配置（如 `application-local.properties`）、CI 跳过策略及 Java 8 / Maven 与 Spring Boot 版本等环境注意点。
