# Scripts 目录

本目录包含微信小程序云测对外服务版 CLI 工具的自动化脚本。

## 主要脚本

### cloudtest_api.py

Python3 编写的命令行工具，仅支持对外服务 (`minitest.weixin.qq.com`)。

功能：
- 提交测试任务
- 查询任务状态
- 取消/删除任务
- 获取任务列表
- 查看测试账号
- 查看测试计划
- 获取AI测试用例
- 获取报告分享链接

## 使用方法

```bash
# 基本用法
py -3 cloudtest_api.py --token <token> --group_en_id <group_id> <command>

# 提交测试
py -3 cloudtest_api.py --token xxx --group_en_id yyy submit --platforms android

# 查询状态
py -3 cloudtest_api.py --token xxx --group_en_id yyy status --plan_id 12345

# 查看帮助
py -3 cloudtest_api.py --help
```

详细文档请参考项目根目录的 README.md
