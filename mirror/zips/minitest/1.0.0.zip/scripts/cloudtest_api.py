# -*- coding: utf-8 -*-
"""
微信小程序云测 API 客户端 - 对外服务版 (Python3)
使用标准库 urllib，无需安装额外依赖

仅支持对外服务: https://minitest.weixin.qq.com/thirdapi/

使用方法:
    py -3 cloudtest_api.py <command> [options]

Commands:
    submit         - 提交测试任务
    status         - 查询任务状态
    cancel         - 取消任务
    delete         - 删除任务
    list           - 获取任务列表
    accounts       - 获取测试账号
    plans          - 获取测试计划
    cases          - 获取测试用例
    share          - 获取报告分享链接

示例:
    py -3 cloudtest_api.py submit --token YOUR_TOKEN --group_en_id YOUR_GROUP_ID --test_type 1 --wx_version 2 --platforms android
    py -3 cloudtest_api.py status --token YOUR_TOKEN --group_en_id YOUR_GROUP_ID --plan_id 12345
"""
import json
import urllib.request
import urllib.parse
import sys
import os
import argparse


class WechatMiniTestClient:
    """微信小程序云测API客户端 - 对外服务专用"""

    BASE_URL = "https://minitest.weixin.qq.com/thirdapi/"

    def __init__(self, token, group_en_id):
        """
        初始化客户端

        Args:
            token: 用户Token
            group_en_id: 项目英文ID
        """
        self.token = token
        self.group_en_id = group_en_id

    def _request(self, method, endpoint, params=None, data=None):
        """发送API请求"""
        # 构建URL
        if method == 'GET':
            if params:
                query = urllib.parse.urlencode(params)
                url = f'{self.BASE_URL}{endpoint}?{query}'
            else:
                url = f'{self.BASE_URL}{endpoint}'
        else:
            url = f'{self.BASE_URL}{endpoint}'

        # 设置请求头
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'application/json'
        }

        if method in ('POST', 'PUT'):
            headers['Content-Type'] = 'application/json'

        req = urllib.request.Request(url, headers=headers, method=method)

        if data:
            req.data = json.dumps(data).encode('utf-8')

        try:
            with urllib.request.urlopen(req, timeout=30) as response:
                result = response.read().decode('utf-8')
                return json.loads(result)
        except urllib.error.HTTPError as e:
            try:
                detail = e.read().decode('utf-8')
            except:
                detail = str(e)
            return {'error': f'HTTP Error: {e.code}', 'detail': detail, 'http_code': e.code}
        except Exception as e:
            return {'error': str(e)}

    # ========== 测试任务 ==========

    def submit_plan(self, test_type=1, wx_version=2, platforms='android', remark='', **kwargs):
        """提交测试任务"""
        data = {
            'token': self.token,
            'group_en_id': self.group_en_id,
            'test_type': test_type,
            'wx_version': wx_version,
            'platforms': platforms,
            'remark': remark
        }
        # 支持可选参数
        for key in ['selected_android_num', 'selected_ios_num', 'wx_id', 'test_plan_id',
                     'task_run_time', 'desc', 'dev_account_no', 'ai_monkey',
                     'special_cloud', 'device_ids']:
            if key in kwargs and kwargs[key] is not None:
                data[key] = kwargs[key]
        return self._request('POST', 'plan', data=data)

    def get_plan_status(self, plan_id, full_info=0):
        """查询任务状态"""
        params = {
            'token': self.token,
            'group_en_id': self.group_en_id,
            'plan_id': int(plan_id),
            'full_info': full_info
        }
        return self._request('GET', 'plan', params=params)

    def get_task_list(self, page=1, page_size=10, test_type=None, platform=None):
        """获取任务列表"""
        params = {
            'token': self.token,
            'group_en_id': self.group_en_id,
            'page_index': page,
            'page_size': page_size
        }
        if test_type is not None:
            params['test_type'] = test_type
        if platform is not None:
            params['platform'] = platform
        return self._request('GET', 'plan_list', params=params)

    def cancel_plan(self, plan_id):
        """取消任务"""
        data = {
            'token': self.token,
            'group_en_id': self.group_en_id,
            'plan_id': int(plan_id)
        }
        return self._request('POST', 'plan/cancel', data=data)

    def delete_plan(self, plan_id):
        """删除任务"""
        data = {
            'token': self.token,
            'group_en_id': self.group_en_id,
            'plan_id': int(plan_id)
        }
        return self._request('POST', 'plan/delete', data=data)

    def get_share_url(self, plan_id):
        """获取报告分享链接"""
        params = {
            'token': self.token,
            'group_en_id': self.group_en_id,
            'plan_id': int(plan_id)
        }
        return self._request('GET', 'share_url', params=params)

    def get_test_resources(self, plan_id, need_image=1, need_log=0):
        """获取测试结果资源"""
        params = {
            'token': self.token,
            'group_en_id': self.group_en_id,
            'plan_id': int(plan_id),
            'need_image': need_image,
            'need_log': need_log
        }
        return self._request('GET', 'report/static_resource', params=params)

    # ========== 测试账号 ==========

    def get_test_accounts(self):
        """获取绑定测试账号"""
        params = {
            'token': self.token,
            'group_en_id': self.group_en_id
        }
        return self._request('GET', 'account/entity_accounts', params=params)

    # ========== 质检任务 ==========

    def submit_quality_inspection(self, platforms, wx_version, desc='', union_type=1):
        """提交质检任务"""
        data = {
            'token': self.token,
            'group_en_id': self.group_en_id,
            'platforms': platforms,
            'wx_version': wx_version,
            'desc': desc,
            'union_type': union_type
        }
        return self._request('POST', 'union_plan', data=data)

    def get_quality_inspection_list(self):
        """查询质检任务列表"""
        params = {
            'token': self.token,
            'group_en_id': self.group_en_id
        }
        return self._request('GET', 'union_plan_list', params=params)

    def get_quality_inspection_status(self, plan_id):
        """查询质检任务状态"""
        params = {
            'token': self.token,
            'group_en_id': self.group_en_id,
            'plan_id': int(plan_id)
        }
        return self._request('GET', 'union_plan', params=params)

    # ========== 测试计划 ==========

    def create_minium_plan(self, test_plan_name, test_plan_config):
        """创建Minium测试计划"""
        data = {
            'token': self.token,
            'group_en_id': self.group_en_id,
            'test_plan_name': test_plan_name,
            'test_plan_config': test_plan_config
        }
        return self._request('POST', 'case_plan', data=data)

    def create_ai_plan(self, test_plan_name, case_ids):
        """创建AI测试计划"""
        data = {
            'token': self.token,
            'group_en_id': self.group_en_id,
            'test_plan_name': test_plan_name,
            'case_ids': case_ids
        }
        return self._request('POST', 'ai_case_plan', data=data)

    def get_test_plans(self, test_type):
        """查询测试计划"""
        params = {
            'token': self.token,
            'group_en_id': self.group_en_id,
            'test_type': test_type
        }
        return self._request('GET', 'case_plan_list', params=params)

    def update_test_plan(self, test_plan_id, test_plan_name):
        """修改测试计划"""
        data = {
            'token': self.token,
            'group_en_id': self.group_en_id,
            'test_plan_id': int(test_plan_id),
            'test_plan_name': test_plan_name
        }
        return self._request('PUT', 'case_plan', data=data)

    def delete_test_plan(self, test_plan_id):
        """删除测试计划"""
        data = {
            'token': self.token,
            'group_en_id': self.group_en_id,
            'test_plan_id': int(test_plan_id)
        }
        return self._request('POST', 'case_plan/delete', data=data)

    # ========== 测试用例 ==========

    def get_minium_cases(self):
        """获取所有Minium用例"""
        params = {
            'token': self.token,
            'group_en_id': self.group_en_id
        }
        return self._request('GET', 'minium_case_list', params=params)

    def get_replay_cases(self):
        """获取所有录制回放用例"""
        params = {
            'token': self.token,
            'group_en_id': self.group_en_id
        }
        return self._request('GET', 'replay_case_list', params=params)

    def get_ai_cases(self):
        """获取所有AI用例"""
        params = {
            'token': self.token,
            'group_en_id': self.group_en_id
        }
        return self._request('GET', 'ai_case', params=params)

    def add_ai_case(self, name, description):
        """添加AI用例"""
        data = {
            'token': self.token,
            'group_en_id': self.group_en_id,
            'name': name,
            'description': description
        }
        return self._request('POST', 'ai_case', data=data)

    def update_ai_case(self, case_id, **kwargs):
        """修改AI用例"""
        data = {
            'token': self.token,
            'group_en_id': self.group_en_id,
            'case_id': int(case_id)
        }
        for key in ['name', 'description']:
            if key in kwargs and kwargs[key] is not None:
                data[key] = kwargs[key]
        return self._request('PUT', 'ai_case', data=data)

    def delete_test_case(self, file_path):
        """删除测试用例"""
        params = {
            'token': self.token,
            'group_en_id': self.group_en_id,
            'file_path': file_path
        }
        return self._request('DELETE', 'case/api/case_file', params=params)

    # ========== 图片对比 ==========

    def set_baseline_images(self, plan_id):
        """设置基线图片"""
        data = {
            'token': self.token,
            'group_en_id': self.group_en_id,
            'plan_id': int(plan_id)
        }
        return self._request('POST', 'set_plan_image', data=data)

    def re_diff_images(self, plan_id):
        """重新对比"""
        data = {
            'token': self.token,
            'group_en_id': self.group_en_id,
            'plan_id': int(plan_id)
        }
        return self._request('POST', 're_diff_plan_image', data=data)

    def delete_baseline_images(self):
        """删除基线图片"""
        data = {
            'token': self.token,
            'group_en_id': self.group_en_id
        }
        return self._request('POST', 'del_plan_image', data=data)


def main():
    parser = argparse.ArgumentParser(
        description='微信小程序云测 API 客户端 - 对外服务版 (minitest.weixin.qq.com)')
    parser.add_argument('--token', required=True, help='用户Token')
    parser.add_argument('--group_en_id', required=True, help='项目英文ID')

    subparsers = parser.add_subparsers(dest='command', help='要执行的命令')

    # Submit命令
    submit_parser = subparsers.add_parser('submit', help='提交测试任务')
    submit_parser.add_argument('--test_type', type=int, default=1,
                               help='测试类型: 1=Monkey, 2=Minium, 3=录制回放, 4=快速Monkey, 5=启动性能分析')
    submit_parser.add_argument('--wx_version', type=int, default=2,
                               help='版本: 1=线上, 2=体验, 3=开发')
    submit_parser.add_argument('--platforms', required=True, help='平台: android,ios')
    submit_parser.add_argument('--remark', default='', help='备注')
    submit_parser.add_argument('--ai_monkey', type=int, help='AI Monkey (1=启用)')
    submit_parser.add_argument('--device_ids', help='指定设备ID，逗号分隔')

    # Status命令
    status_parser = subparsers.add_parser('status', help='查询任务状态')
    status_parser.add_argument('--plan_id', type=int, required=True, help='任务ID')
    status_parser.add_argument('--full_info', type=int, default=0, help='详细信息 (0/1)')

    # Cancel命令
    cancel_parser = subparsers.add_parser('cancel', help='取消任务')
    cancel_parser.add_argument('--plan_id', type=int, required=True, help='任务ID')

    # Delete命令
    delete_parser = subparsers.add_parser('delete', help='删除任务')
    delete_parser.add_argument('--plan_id', type=int, required=True, help='任务ID')

    # List命令
    list_parser = subparsers.add_parser('list', help='获取任务列表')
    list_parser.add_argument('--page', type=int, default=1, help='页码')
    list_parser.add_argument('--page_size', type=int, default=10, help='每页数量')

    # Accounts命令
    subparsers.add_parser('accounts', help='获取测试账号')

    # Plans命令
    plans_parser = subparsers.add_parser('plans', help='获取测试计划')
    plans_parser.add_argument('--test_type', type=int, default=1,
                              help='测试类型: 1=Monkey, 2=Minium, 3=录制回放')

    # Cases命令
    cases_parser = subparsers.add_parser('cases', help='获取AI测试用例')

    # Share命令
    share_parser = subparsers.add_parser('share', help='获取报告分享链接')
    share_parser.add_argument('--plan_id', type=int, required=True, help='任务ID')

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        print("\n服务信息:")
        print("  域名: minitest.weixin.qq.com")
        print("  基础路径: /thirdapi/")
        print("  协议: HTTPS")
        print("\n示例:")
        print("  py -3 cloudtest_api.py --token xxx --group_en_id yyy submit --platforms android")
        print("  py -3 cloudtest_api.py --token xxx --group_en_id yyy status --plan_id 12345")
        os._exit(0)

    client = WechatMiniTestClient(args.token, args.group_en_id)

    result = None

    if args.command == 'submit':
        extra = {}
        if hasattr(args, 'ai_monkey') and args.ai_monkey:
            extra['ai_monkey'] = args.ai_monkey
        if hasattr(args, 'device_ids') and args.device_ids:
            extra['device_ids'] = args.device_ids
        result = client.submit_plan(
            test_type=args.test_type,
            wx_version=args.wx_version,
            platforms=args.platforms,
            remark=args.remark,
            **extra
        )
    elif args.command == 'status':
        result = client.get_plan_status(args.plan_id, args.full_info)
    elif args.command == 'cancel':
        result = client.cancel_plan(args.plan_id)
    elif args.command == 'delete':
        result = client.delete_plan(args.plan_id)
    elif args.command == 'list':
        result = client.get_task_list(args.page, args.page_size)
    elif args.command == 'accounts':
        result = client.get_test_accounts()
    elif args.command == 'plans':
        result = client.get_test_plans(args.test_type)
    elif args.command == 'cases':
        result = client.get_ai_cases()
    elif args.command == 'share':
        result = client.get_share_url(args.plan_id)
    else:
        print(f'未知命令: {args.command}')
        os._exit(1)

    print("\n" + "=" * 50)
    print("API响应:")
    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()
