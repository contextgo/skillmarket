# 微信小程序云测 API 接口文档 (对外服务版)

## 服务信息

| 项目 | 值 |
|------|-----|
| 服务域名 | minitest.weixin.qq.com |
| API 基础路径 | /thirdapi/ |
| 协议 | HTTPS |

## 通用参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| token | string | 是 | 用户令牌，在 https://minitest.weixin.qq.com/cloudtest/system/my_info 获取 |
| group_en_id | string | 是 | 项目标识，在项目管理页面获取 |

## 接口列表

### 1. 提交测试任务

**接口地址**: `POST https://minitest.weixin.qq.com/thirdapi/plan`

**请求参数**:

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| platforms | string | 是 | 平台类型: android, ios |
| test_type | int | 是 | 测试类型: 1=Monkey, 2=Minium, 3=录制回放, 4=快速Monkey, 5=启动性能分析 |
| wx_version | int | 是 | 版本: 1=线上, 2=体验, 3=开发 |

**返回示例**:
```json
{
  "rtn": 0,
  "msg": "添加成功，等待后台创建任务。",
  "data": {
    "plan_id": 123456
  }
}
```

---

### 2. 查询任务状态

**接口地址**: `GET https://minitest.weixin.qq.com/thirdapi/plan`

**请求参数**:

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| plan_id | int | 是 | 任务ID |

**返回示例**:
```json
{
  "rtn": 0,
  "data": {
    "status": "testing",
    "progress": 50,
    "result_url": "https://..."
  }
}
```

---

### 3. 查看测试账号

**接口地址**: `GET https://minitest.weixin.qq.com/thirdapi/account/entity_accounts`

**返回示例**:
```json
{
  "rtn": 0,
  "data": {
    "accounts": [
      {
        "id": 1,
        "username": "test_user",
        "platform": "android"
      }
    ]
  }
}
```

---

### 4. 查看测试计划

**接口地址**: `GET https://minitest.weixin.qq.com/thirdapi/case_plan_list`

**返回示例**:
```json
{
  "rtn": 0,
  "data": {
    "plans": [
      {
        "id": 123,
        "name": "Monkey测试计划",
        "type": "monkey"
      }
    ]
  }
}
```

---

### 5. 获取测试报告资源

**接口地址**: `GET https://minitest.weixin.qq.com/thirdapi/report/static_resource`

**请求参数**:

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| plan_id | int | 是 | 任务ID |

---

## 错误码

| 错误码 | 说明 |
|--------|------|
| 0 | 成功 |
| -1 | 失败/未找到项目 |
| 400 | 参数错误 |
| 401 | token 过期 |
| 403 | 权限不足 |
| 404 | 接口不存在 |
| 500 | 服务器错误 |

## 注意事项

1. 所有请求使用 HTTPS 协议
2. `plan_id` 类型必须是整数，不能是字符串
3. GET 请求不需要设置 Content-Type
4. POST/PUT 请求需要设置 `Content-Type: application/json`
