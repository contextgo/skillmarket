---
name: minitest_extern
description: MiniTest (小程序云测) skill for WeChat Mini Program automated testing (External Service Only). Use when submitting test tasks, querying task status, managing test plans, test cases, or quality inspection tasks. Uses external service at minitest.weixin.qq.com. Docs: https://developers.weixin.qq.com/miniprogram/dev/devtools/minitest/
---

# WeChat Mini Program Cloud Testing Skill (External Service)

This skill provides comprehensive capabilities to interact with WeChat Mini Program Cloud Testing (小程序云测) API for automated testing management.

> **本技能仅支持对外服务**，所有 API 请求均通过 `https://minitest.weixin.qq.com/thirdapi/` 发送。

## Service Configuration

| 项目 | 值 |
|------|-----|
| 服务域名 | minitest.weixin.qq.com |
| API 基础路径 | /thirdapi/ |
| 协议 | HTTPS |
| 平台入口 | https://minitest.weixin.qq.com |

## Required Parameters:

The following parameters must be provided by the user:

| Parameter | Description | How to Get |
|-----------|-------------|------------|
| `token` | User authentication token | 进入云测页面，点击页面右上角头像，在下拉菜单中选择 "我的信息" 获取。直接访问 https://minitest.weixin.qq.com/cloudtest/system/my_info |
| `group_en_id` | Project English ID | 在云测平台的 项目管理/产品管理 页面获取 |

---

# API Endpoints

## Part 1: Test Task (测试任务)

### 1.1 Submit Test Task (提交测试任务)

**Endpoint:** `POST https://minitest.weixin.qq.com/thirdapi/plan`

**Required Parameters:**
- `token` (string): User token
- `group_en_id` (string): Project English ID
- `test_type` (int): Test type - `1`: monkey, `2`: minium, `3`: 录制回放, `4`: 快速Monkey, `5`: 启动性能分析
- `wx_version` (int): Mini program version - `1`: 线上版本, `2`: 体验版本, `3`: 开发版本
- `platforms` (string): Test platforms, comma-separated - `android`, `ios`

**Optional Parameters:**
- `selected_android_num` (int): Number of Android devices (max 10)
- `selected_ios_num` (int): Number of iOS devices (max 10)
- `wx_id` (string): Mini program AppID
- `test_plan_id` (int): Test plan ID
- `task_run_time` (int): Custom test duration in seconds
- `desc` (string): Task description
- `dev_account_no` (int): Developer account number for dev version testing
- `ai_monkey` (int): AI Monkey test (1: enable)
- `special_cloud` (string): Paid capability, e.g., `fast_test`
- `device_ids` (string): Specific device IDs, comma-separated

### 1.2 Query Task List (查询任务列表)

**Endpoint:** `GET https://minitest.weixin.qq.com/thirdapi/plan_list`

**Required Parameters:**
- `token` (string): User token
- `group_en_id` (string): Project English ID
- `page_index` (int): Page number, default 1

**Optional Parameters:**
- `page_size` (int): Page size, default 10
- `test_type` (int): Filter by test type
- `platform` (string): Filter by platform

### 1.3 Query Task Status (查询任务状态)

**Endpoint:** `GET https://minitest.weixin.qq.com/thirdapi/plan`

**Required Parameters:**
- `token` (string): User token
- `group_en_id` (string): Project English ID
- `plan_id` (int): Task ID

**Optional Parameters:**
- `full_info` (int): Get detailed results, default 0

### 1.4 Cancel Task (取消任务)

**Endpoint:** `POST https://minitest.weixin.qq.com/thirdapi/plan/cancel`

**Required Parameters:**
- `token` (string): User token
- `group_en_id` (string): Project English ID
- `plan_id` (int): Task ID

### 1.5 Delete Task (删除任务)

**Endpoint:** `POST https://minitest.weixin.qq.com/thirdapi/plan/delete`

**Required Parameters:**
- `token` (string): User token
- `group_en_id` (string): Project English ID
- `plan_id` (int): Task ID

### 1.6 Get Report Share Link (获取报告分享链接)

**Endpoint:** `GET https://minitest.weixin.qq.com/thirdapi/share_url`

**Required Parameters:**
- `token` (string): User token
- `group_en_id` (string): Project English ID
- `plan_id` (int): Task ID

### 1.7 Get Test Resources (获取测试结果资源)

**Endpoint:** `GET https://minitest.weixin.qq.com/thirdapi/report/static_resource`

**Required Parameters:**
- `token` (string): User token
- `group_en_id` (string): Project English ID
- `plan_id` (int): Task ID

**Optional Parameters:**
- `need_image` (int): Include images, default 1
- `need_log` (int): Include logs, default 0

---

## Part 2: Test Account (测试账号)

### 2.1 Get Bound Accounts (获取绑定测试账号)

**Endpoint:** `GET https://minitest.weixin.qq.com/thirdapi/account/entity_accounts`

**Required Parameters:**
- `token` (string): User token
- `group_en_id` (string): Project English ID

---

## Part 3: Quality Inspection Task (质检任务)

### 3.1 Submit Quality Inspection Task (提交质检任务)

**Endpoint:** `POST https://minitest.weixin.qq.com/thirdapi/union_plan`

**Required Parameters:**
- `token` (string): User token
- `group_en_id` (string): Project English ID
- `platforms` (string): Test platforms - `android`, `ios`
- `wx_version` (int): Mini program version - `1`: 线上版本, `2`: 体验版本, `3`: 开发版本

**Optional Parameters:**
- `desc` (string): Task description
- `union_type` (int): Inspection type, default 1

### 3.2 Query Quality Inspection Task List (查询质检任务列表)

**Endpoint:** `GET https://minitest.weixin.qq.com/thirdapi/union_plan_list`

**Required Parameters:**
- `token` (string): User token
- `group_en_id` (string): Project English ID

### 3.3 Query Quality Inspection Task Status (查询质检任务状态)

**Endpoint:** `GET https://minitest.weixin.qq.com/thirdapi/union_plan`

**Required Parameters:**
- `token` (string): User token
- `group_en_id` (string): Project English ID
- `plan_id` (int): Task ID

---

## Part 4: Test Plan (测试计划)

### 4.1 Create Minium Test Plan (创建Minium测试计划)

**Endpoint:** `POST https://minitest.weixin.qq.com/thirdapi/case_plan`

**Required Parameters:**
- `token` (string): User token
- `group_en_id` (string): Project English ID
- `test_plan_name` (string): Test plan name
- `test_plan_config` (string): Test plan config (JSON string)

### 4.2 Create AI Test Plan (创建AI测试计划)

**Endpoint:** `POST https://minitest.weixin.qq.com/thirdapi/ai_case_plan`

**Required Parameters:**
- `token` (string): User token
- `group_en_id` (string): Project English ID
- `test_plan_name` (string): Test plan name
- `case_ids` (string): Case IDs (JSON array string, e.g., '[1,2]')

### 4.3 Query Test Plans (查询测试计划)

**Endpoint:** `GET https://minitest.weixin.qq.com/thirdapi/case_plan_list`

**Required Parameters:**
- `token` (string): User token
- `group_en_id` (string): Project English ID
- `test_type` (int): Test type - `1`: Monkey, `2`: Minium, `3`: 录制回放

### 4.4 Update Test Plan (修改测试计划)

**Endpoint:** `PUT https://minitest.weixin.qq.com/thirdapi/case_plan`

**Required Parameters:**
- `token` (string): User token
- `group_en_id` (string): Project English ID
- `test_plan_id` (int): Test plan ID
- `test_plan_name` (string): Test plan name

### 4.5 Delete Test Plan (删除测试计划)

**Endpoint:** `POST https://minitest.weixin.qq.com/thirdapi/case_plan/delete`

**Required Parameters:**
- `token` (string): User token
- `group_en_id` (string): Project English ID
- `test_plan_id` (int): Test plan ID

---

## Part 5: Test Case (测试用例)

### 5.1 Upload Test Case (上传测试用例)

**Endpoint:** `POST https://minitest.weixin.qq.com/thirdapi/case/upload`

**Required Parameters:**
- `token` (string): User token
- `group_en_id` (string): Project English ID
- `file` (file): ZIP file
- `test_type` (int): Test type - `2`: Minium, `3`: 录制回放

### 5.2 Download Test Case (下载测试用例)

**Endpoint:** `GET https://minitest.weixin.qq.com/thirdapi/case/download`

**Required Parameters:**
- `token` (string): User token
- `group_en_id` (string): Project English ID
- `test_type` (int): Test type

### 5.3 Delete Test Case (删除测试用例)

**Endpoint:** `DELETE https://minitest.weixin.qq.com/thirdapi/case/api/case_file`

**Required Parameters:**
- `token` (string): User token
- `group_en_id` (string): Project English ID
- `file_path` (string): File path

### 5.4 Get All Minium Cases (获取所有Minium用例)

**Endpoint:** `GET https://minitest.weixin.qq.com/thirdapi/minium_case_list`

**Required Parameters:**
- `token` (string): User token
- `group_en_id` (string): Project English ID

### 5.5 Get All Replay Cases (获取所有录制回放用例)

**Endpoint:** `GET https://minitest.weixin.qq.com/thirdapi/replay_case_list`

**Required Parameters:**
- `token` (string): User token
- `group_en_id` (string): Project English ID

### 5.6 Get All AI Cases (获取所有AI用例)

**Endpoint:** `GET https://minitest.weixin.qq.com/thirdapi/ai_case`

**Required Parameters:**
- `token` (string): User token
- `group_en_id` (string): Project English ID

### 5.7 Add AI Case (添加AI用例)

**Endpoint:** `POST https://minitest.weixin.qq.com/thirdapi/ai_case`

**Required Parameters:**
- `token` (string): User token
- `group_en_id` (string): Project English ID
- `name` (string): Case name
- `description` (string): Case description

### 5.8 Update AI Case (修改AI用例)

**Endpoint:** `PUT https://minitest.weixin.qq.com/thirdapi/ai_case`

**Required Parameters:**
- `token` (string): User token
- `group_en_id` (string): Project English ID
- `case_id` (int): Case ID

---

## Part 6: Image Comparison (图片对比)

### 6.1 Set Baseline Images (设置基线图片)

**Endpoint:** `POST https://minitest.weixin.qq.com/thirdapi/set_plan_image`

**Required Parameters:**
- `token` (string): User token
- `group_en_id` (string): Project English ID
- `plan_id` (int): Task ID

### 6.2 Re-diff Images (重新对比)

**Endpoint:** `POST https://minitest.weixin.qq.com/thirdapi/re_diff_plan_image`

**Required Parameters:**
- `token` (string): User token
- `group_en_id` (string): Project English ID
- `plan_id` (int): Task ID

### 6.3 Delete Baseline Images (删除基线图片)

**Endpoint:** `POST https://minitest.weixin.qq.com/thirdapi/del_plan_image`

**Required Parameters:**
- `token` (string): User token
- `group_en_id` (string): Project English ID

---

## Part 7: SourceMap (SourceMap管理)

### 7.1 Upload SourceMap (上传SourceMap)

**Endpoint:** `POST https://minitest.weixin.qq.com/thirdapi/source_map`

**Required Parameters:**
- `token` (string): User token
- `group_en_id` (string): Project English ID
- `file` (file): SourceMap ZIP file

**Optional Parameters:**
- `appid` (string): Mini program AppID
- `upload_desc` (string): Upload description

---

# Usage Examples

## Example 1: Submit Test Task

```
"提交一个monkey测试，token是xxx，group_en_id是yyy，测试android平台"
```

## Example 2: Query Task Status

```
"查看任务12345的状态，token是xxx，group_en_id是yyy"
```

## Example 3: Submit Quality Inspection

```
"提交一个质检任务，token是xxx，group_en_id是yyy，平台android，版本为线上版本"
```

## Example 4: Manage AI Test Cases

```
"帮我添加一个AI测试用例，名称是登录流程测试，描述是验证微信登录后的页面跳转"
```

---

# Project Structure

```
minitest_extern/
├── README.md                 # 项目说明（给人看的）
├── SKILL.md                  # Skill 定义文件（给 AI 看的）
├── references/               # 参考资料和知识库
│   └── api_docs.md          # API 接口文档
├── assets/                   # 模板和工具箱
│   └── example.env          # 环境变量示例
└── scripts/                  # 自动化辅助脚本
    ├── README.md            # 脚本说明
    └── cloudtest_api.py     # Python3 CLI 工具
```
