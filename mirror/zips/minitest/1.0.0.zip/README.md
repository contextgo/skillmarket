# 微信小程序云测 - 对外服务版 (MiniTest External)

微信小程序云测服务 CLI 工具，**仅支持对外服务** (`minitest.weixin.qq.com`)。

## 功能特性

- 📱 **提交测试任务** - 支持 Android/iOS 平台的 Monkey 测试、Minium 自动化测试、AI 测试
- 📊 **查询任务状态** - 实时查看测试进度和结果
- 👥 **测试账号管理** - 查看绑定的测试账号
- 📋 **测试计划管理** - 创建、查询、修改、删除测试计划
- 🧪 **测试用例管理** - 上传、下载、管理 Minium/录制回放/AI 用例
- 🔍 **质检任务** - 提交和管理质检任务
- 🖼️ **图片对比** - 设置基线、重新对比、删除基线
- 📦 **SourceMap** - 上传 SourceMap 文件

## 服务信息

| 项目 | 值 |
|------|-----|
| 服务域名 | minitest.weixin.qq.com |
| API 基础路径 | /thirdapi/ |
| 协议 | HTTPS |
| 平台入口 | https://minitest.weixin.qq.com |

## 快速开始

### 环境要求

- Python 3.6+
- 无需安装额外依赖（使用标准库）

### 获取凭证

1. 访问 https://minitest.weixin.qq.com
2. 点击右上角头像 → "我的信息" 获取 `token`
3. 在 项目管理/产品管理 页面获取 `group_en_id`

### 使用方式

```bash
# 通过 AI 助手直接调用
"帮我提交一个安卓测试任务"

# 命令行使用
py -3 cloudtest_api.py --token <token> --group_en_id <group_id> <command> [options]
```

### 可用命令

| 命令 | 说明 |
|------|------|
| `submit` | 提交测试任务 |
| `status` | 查询任务状态 |
| `cancel` | 取消测试任务 |
| `delete` | 删除测试任务 |
| `list` | 获取任务列表 |
| `accounts` | 查看测试账号 |
| `plans` | 查看测试计划 |
| `cases` | 获取测试用例 |
| `share` | 获取报告分享链接 |

### 示例

```bash
# 提交 Monkey 测试
py -3 cloudtest_api.py --token xxx --group_en_id yyy submit --platforms android

# 查询任务状态
py -3 cloudtest_api.py --token xxx --group_en_id yyy status --plan_id 12345

# 获取报告分享链接
py -3 cloudtest_api.py --token xxx --group_en_id yyy share --plan_id 12345
```

## 项目结构

```
minitest_extern/
├── README.md                 # 项目说明
├── SKILL.md                  # Skill 定义文件
├── references/               # 参考资料
│   └── api_docs.md          # API 接口文档
├── assets/                   # 模板和工具
│   └── example.env          # 环境变量示例
└── scripts/                  # 自动化脚本
    └── cloudtest_api.py     # CLI 工具
```

## 相关文档

- [微信小程序云测官方文档](https://developers.weixin.qq.com/miniprogram/dev/devtools/minitest/api_exe.html)

## 注意事项

1. 本技能仅支持对外服务 (`minitest.weixin.qq.com`)
2. 提交任务前请确保包名和平台参数正确
3. `plan_id` 必须是整数类型
4. GET 请求不需要设置 Content-Type
