import json
import re
import subprocess
import sys
from pathlib import Path
from datetime import date, timedelta
from docx import Document

DEFAULT_SHEET_URL = 'https://seazen.feishu.cn/wiki/ZM1RwixcpiCfAMkpFACcMu4XnKe?sheet=S1YD9E'
DEFAULT_OUTPUT_DIR = Path('/mnt/shared/openclaw/workspace')
PERCENT_METRICS = {
    '品牌级次得分提升率',
    '动态空铺率',
    '掉铺率',
    '招调递增率',
    '取高收入',
    '会员消费占比',
    '高潜保留率',
    '人工成本使用率',
    '收缴率',
}


def parse_sheet_url(url: str):
    m1 = re.search(r'/wiki/([A-Za-z0-9]+)', url)
    m2 = re.search(r'[?&]sheet=([A-Za-z0-9]+)', url)
    if not m1 or not m2:
        raise ValueError('无法从飞书地址中解析 wiki token 或 sheet id')
    return m1.group(1), m2.group(1)


def get_feishu_doc_title(sheet_url: str):
    """获取飞书 Wiki 文档标题"""
    import warnings
    import os

    # 禁用 subprocess 警告输出
    stderr_orig = os.dup(2)
    devnull = os.open(os.devnull, os.O_WRONLY)
    os.dup2(devnull, 2)

    try:
        token, _ = parse_sheet_url(sheet_url)

        # 如果环境指示不支持日期更新，直接返回
        if os.environ.get('SKIP_DATE_UPDATE'):
            return ''

        # 尝试多种方式获取标题
        # 方式1：通过 openclaw 工具（如果在 OpenClaw 环境中）
        try:
            import importlib.util
            spec = importlib.util.find_spec('openclaw')
            if spec:
                # 可以尝试写入一个临时文件让 OpenClaw 处理
                pass
        except:
            pass

        # 方式2：查找 feishu_wiki 可执行文件
        try:
            # 尝试使用 openclaw 命令行
            cmd = "which openclaw"
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
            if result.returncode == 0 and result.stdout.strip():
                openclaw_path = result.stdout.strip()
                # 尝试调用 openclaw 的 wiki 子命令
                # 注意：这个功能依赖于 openclaw 的版本和配置
                pass
        except:
            pass

        # 方式3：使用环境变量中的命令
        import shutil
        feishu_wiki_path = shutil.which('openclaw')
        if feishu_wiki_path:
            # 这里可能需要更复杂的逻辑来调用飞书 API
            pass

        # 如果以上方式都失败，尝试直接调用 feishu_wiki（可能在 PATH 中）
        cmd = f"feishu_wiki action=get token={token}"
        out = subprocess.check_output(cmd, shell=True, stderr=subprocess.DEVNULL, text=True, timeout=5)
        data = json.loads(out)
        return data.get('title', '')
    except subprocess.CalledProcessError:
        # feishu_wiki 命令不可用，这是预期情况
        return ''
    except subprocess.TimeoutExpired:
        return ''
    except Exception:
        # 任何其他错误都静默失败
        return ''
    finally:
        # 恢复 stderr
        os.dup2(stderr_orig, 2)
        os.close(stderr_orig)


def extract_date_from_title(title: str):
    """从飞书文档标题中提取日期信息"""
    if not title:
        return None
    # 模式：2026年4月第四周
    pattern = r'(\d{4})年(\d{1,2})月第([一二三四五六七八九十]+)周'
    match = re.search(pattern, title)
    if match:
        year = int(match.group(1))
        month = int(match.group(2))
        week_chinese = match.group(3)
        week_map = {'一': 1, '二': 2, '三': 3, '四': 4, '五': 5, '六': 6, '七': 7, '八': 8, '九': 9, '十': 10}
        week_num = week_map.get(week_chinese, 1)
        return {
            'year': year,
            'month': month,
            'week_chinese': week_chinese,
            'week_num': week_num,
            'date_str': f"{year}年{month}月第{week_chinese}周"
        }
    return None


def calculate_meeting_date(date_info):
    """计算会议日期（第N周的周一）"""
    if not date_info:
        return None
    year = date_info['year']
    month = date_info['month']
    week_num = date_info['week_num']

    # 获取该月1号
    first_day = date(year, month, 1)
    # 周一为0，周日为6
    weekday = first_day.weekday()

    # 计算第N周的周一日期
    days_to_monday = (week_num - 1) * 7
    meeting_date = first_day + timedelta(days=days_to_monday)
    return f"{year}年{month}月{meeting_date.day}日"


def update_docx_dates(doc, date_info):
    """更新文档中的日期信息（标题和会议时间）"""
    if not date_info:
        return False

    date_str = date_info['date_str']
    meeting_date_str = calculate_meeting_date(date_info)

    if not meeting_date_str:
        return False

    updated = False

    # 遍历所有段落进行替换
    for para in doc.paragraphs:
        original_text = para.text

        # 1. 替换标题中的日期（年月周）
        # 匹配：2026年3月第四周
        title_pattern = r'\d{4}年\d{1,2}月第[一二三四五六七八九十]+周'
        if re.search(title_pattern, original_text):
            new_text = re.sub(title_pattern, date_str, original_text)
            if new_text != original_text:
                # 保留原有样式，更新文本
                runs = para.runs
                if runs:
                    # 清空所有 run 的文本
                    for run in runs:
                        run.text = ""
                    # 在第一个 run 中添加新文本
                    runs[0].text = new_text
                    updated = True

        # 2. 替换会议时间中的日期
        time_pattern = r'\d{4}年\d{1,2}月\d{1,2}日'
        if "会议时间" in original_text:
            new_text = re.sub(time_pattern, meeting_date_str, original_text)
            if new_text != original_text:
                # 保留原有样式，更新文本
                runs = para.runs
                if runs:
                    for run in runs:
                        run.text = ""
                    runs[0].text = new_text
                    updated = True

    return updated


def norm(v):
    if v is None:
        return ''
    s = str(v).strip()
    return '' if s == 'null' else s


def num(v):
    try:
        if isinstance(v, (int, float)):
            return float(v)
        raw = norm(v)
        if raw == '':
            return None
        is_percent = ('%' in raw) or ('％' in raw)
        s = raw.replace(',', '').replace('%', '').replace('％', '')
        s = s.replace('＜', '').replace('＞', '').replace('<', '').replace('>', '')
        if s == '':
            return None
        val = float(s)
        if is_percent:
            val = val / 100.0
        return val
    except Exception:
        return None


def format_decimal(value, digits=4):
    if value is None:
        return ''
    if abs(value - round(value)) < 1e-9:
        return str(int(round(value)))
    return f"{value:.{digits}f}".rstrip('0').rstrip('.')


def format_percent(value, digits=2):
    if value is None:
        return ''
    pct = value * 100
    if abs(pct - round(pct)) < 1e-9:
        return f"{int(round(pct))}%"
    return f"{pct:.{digits}f}".rstrip('0').rstrip('.') + '%'


def header_to_field(h):
    h = norm(h)
    if h == '年完成值':
        return 'year_done'
    if h == '年完成进度':
        return 'year_progress'
    if h.endswith('指标'):
        return 'month_target'
    if h.endswith('达成'):
        return 'month_done'
    if '达成率' in h:
        return 'month_rate'
    if '缺口' in h:
        return 'month_gap'
    if '有无风险' in h:
        return 'risk'
    return None


def compute_formula(raw_value, row):
    s = norm(raw_value)
    m = re.fullmatch(r'([A-Z]+)(\d+)([/-])([A-Z]+)(\d+)', s)
    if not m:
        return None
    c1, r1, op, c2, r2 = m.groups()
    if r1 != r2 or int(r1) != int(row.get('sheet_row')):
        return None
    v1 = num(row.get('colmap', {}).get(c1))
    v2 = num(row.get('colmap', {}).get(c2))
    if v1 is None or v2 is None:
        return None
    if op == '/':
        if v2 == 0:
            return None
        return v1 / v2
    return v1 - v2


def should_percent(metric, sub, field, raw_value):
    metric = norm(metric)
    sub = norm(sub)
    raw = norm(raw_value)
    if metric in PERCENT_METRICS or sub in PERCENT_METRICS:
        if field in ('year_done', 'year_progress', 'month_target', 'month_done', 'month_rate', 'month_gap'):
            return True
    if '%' in raw or '％' in raw:
        return True
    if field in ('year_progress', 'month_rate'):
        return True
    return False


def render_value(value, metric, sub, field, raw_value):
    if should_percent(metric, sub, field, raw_value):
        return format_percent(value)
    return format_decimal(value, 4)


def maybe_compute(raw_value, row, field):
    if field == 'risk':
        gap_raw = norm(row.get('month_gap', ''))
        gap_num = compute_formula(gap_raw, row)
        if gap_num is None:
            gap_num = num(gap_raw)
        if gap_num is None:
            return ''
        return '无' if gap_num >= 0 else '有'

    raw = norm(raw_value)
    if not raw:
        return ''
    calc = compute_formula(raw, row)
    if calc is not None:
        return render_value(calc, row.get('metric', ''), row.get('sub', ''), field, raw)

    direct = num(raw)
    if direct is not None and should_percent(row.get('metric', ''), row.get('sub', ''), field, raw):
        return format_percent(direct)
    return raw


def pick_sheet_match(rows, metric, sub):
    metric = norm(metric)
    sub = norm(sub) or '/'
    exact = [r for r in rows if norm(r['metric']) == metric and norm(r['sub']) == sub]
    if exact:
        return exact[0]
    metric_only = [r for r in rows if norm(r['metric']) == metric]
    if len(metric_only) == 1:
        return metric_only[0]
    if sub and sub != '/':
        sub_only = [r for r in rows if norm(r['sub']) == sub]
        if len(sub_only) == 1:
            return sub_only[0]
    return None


def read_sheet(sheet_url: str):
    token, sheet_id = parse_sheet_url(sheet_url)
    cmd = f"bash /mnt/shared/openclaw/workspace/skills/feishu-sheet/scripts/feishu-sheet.sh read {token} '{sheet_id}!A1:V200'"
    out = subprocess.check_output(cmd, shell=True, text=True)
    data = json.loads(out)['values']
    rows = data[3:]
    result = []
    current_metric = ''
    for idx, r in enumerate(rows, start=4):
        metric = norm(r[2]) if len(r) > 2 else ''
        sub = norm(r[3]) if len(r) > 3 else ''
        if metric:
            current_metric = metric
        else:
            metric = current_metric
        if not metric:
            continue
        colmap = {}
        for letter, pos in zip(list('ABCDEFGHIJKLMNOPQRSTUVWXYZ')[:22], range(22)):
            if len(r) > pos:
                colmap[letter] = r[pos]
        result.append({
            'sheet_row': idx,
            'metric': metric,
            'sub': sub or '/',
            'year_done': norm(r[6]) if len(r) > 6 else '',
            'year_progress': norm(r[7]) if len(r) > 7 else '',
            'month_target': norm(r[9]) if len(r) > 9 else '',
            'month_done': norm(r[10]) if len(r) > 10 else '',
            'month_rate': norm(r[11]) if len(r) > 11 else '',
            'month_gap': norm(r[12]) if len(r) > 12 else '',
            'risk': '',
            'colmap': colmap,
        })
    return result


def next_version_path(template: Path):
    base = template.stem
    suffix = template.suffix
    parent = DEFAULT_OUTPUT_DIR
    parent.mkdir(parents=True, exist_ok=True)
    pattern = re.compile(re.escape(base) + r'-第(\d+)版' + re.escape(suffix) + r'$')
    max_n = 0
    for p in parent.iterdir():
        m = pattern.fullmatch(p.name)
        if m:
            max_n = max(max_n, int(m.group(1)))
    return parent / f"{base}-第{max_n + 1}版{suffix}"


def fill_docx(template_path: str, sheet_url: str = DEFAULT_SHEET_URL, output_path: str | None = None):
    template = Path(template_path)
    if output_path:
        out = Path(output_path)
    else:
        out = next_version_path(template)

    sheet_rows = read_sheet(sheet_url)
    doc = Document(str(template))

    target_tables = []
    for table in doc.tables:
        if any('[待更新]' in norm(cell.text) for row in table.rows for cell in row.cells):
            target_tables.append(table)

    replaced = []
    unmatched = []

    for table in target_tables:
        if not table.rows:
            continue
        header = [norm(c.text) for c in table.rows[0].cells]
        for ri in range(1, len(table.rows)):
            row = table.rows[ri]
            cells = row.cells
            metric = norm(cells[2].text) if len(cells) > 2 else ''
            sub = norm(cells[4].text) if len(cells) > 4 else ''
            sheet_match = pick_sheet_match(sheet_rows, metric, sub)
            for ci, cell in enumerate(cells):
                if norm(cell.text) != '[待更新]':
                    continue
                col_title = header[ci] if ci < len(header) else ''
                field = header_to_field(col_title)
                replacement = ''
                if sheet_match and field:
                    replacement = maybe_compute(sheet_match.get(field, ''), sheet_match, field)
                if replacement:
                    cell.text = replacement
                    replaced.append({'metric': metric, 'sub': sub, 'column': col_title, 'value': replacement})
                else:
                    cell.text = ''
                    unmatched.append({'metric': metric, 'sub': sub, 'column': col_title})

    # 自动更新文档日期（从飞书文档标题中提取）
    try:
        doc_title = get_feishu_doc_title(sheet_url)
        if doc_title:
            date_info = extract_date_from_title(doc_title)
            if date_info:
                update_docx_dates(doc, date_info)
    except Exception as e:
        print(f"自动更新日期时出错（已跳过）: {e}")

    doc.save(str(out))
    return {
        'output': str(out),
        'replaced': replaced,
        'unmatched': unmatched,
        'sheet_url': sheet_url,
    }


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print(json.dumps({'ok': False, 'error': '用法: python fill_from_feishu_sheet.py <template.docx> [sheet_url] [output.docx]'}, ensure_ascii=False))
        sys.exit(1)
    template_path = sys.argv[1]
    sheet_url = sys.argv[2] if len(sys.argv) > 2 else DEFAULT_SHEET_URL
    output_path = sys.argv[3] if len(sys.argv) > 3 else None
    result = fill_docx(template_path, sheet_url, output_path)
    print(json.dumps({
        'ok': True,
        'output': result['output'],
        'replaced_count': len(result['replaced']),
        'unmatched_count': len(result['unmatched']),
        'sheet_url': result['sheet_url'],
    }, ensure_ascii=False))
