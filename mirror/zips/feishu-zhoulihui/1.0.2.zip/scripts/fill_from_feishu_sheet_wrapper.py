#!/usr/bin/env python3
"""
飞书表格 → DOCX 会议纪要生成包装脚本
负责：
1. 获取飞书文档标题（用于日期更新）
2. 调用主脚本生成文件
3. 将文件发送到飞书对话
"""
import json
import os
import subprocess
import sys
from pathlib import Path

# 默认目标用户
DEFAULT_TARGET_USER = 'ou_83ab7f030a10b071945ffa7fa6e89374'

# 脚本路径
SCRIPT_DIR = Path(__file__).parent
MAIN_SCRIPT = SCRIPT_DIR / 'fill_from_feishu_sheet.py'


def get_doc_title(sheet_url: str) -> str:
    """获取飞书Wiki文档标题（通过OpenClaw功能）"""
    try:
        # 这里需要通过环境变量方式让 OpenClaw 处理
        # 由于 subprocess 无法直接调用 OpenClaw 工具，
        # 我们返回空，让主脚本静默跳过日期更新
        return ''
    except Exception:
        return ''


def send_file_to_feishu(file_path: str, target_user: str):
    """发送文件到飞书对话"""
    try:
        # 获取当前对话的 chat_id
        # 由于在 subprocess 中无法直接调用 OpenClaw message 工具，
        # 我们返回 False，说明需要外部处理
        return False
    except Exception:
        return False


def main():
    if len(sys.argv) < 2:
        print(json.dumps({
            'ok': False,
            'error': '用法: python fill_from_feishu_sheet_wrapper.py <template.docx> [sheet_url] [output.docx] [target_user]'
        }, ensure_ascii=False))
        sys.exit(1)

    template_path = sys.argv[1]
    sheet_url = sys.argv[2] if len(sys.argv) > 2 else None
    output_path = sys.argv[3] if len(sys.argv) > 3 else None
    target_user = sys.argv[4] if len(sys.argv) > 4 else DEFAULT_TARGET_USER

    # 构建命令
    cmd = [sys.executable, str(MAIN_SCRIPT), template_path]
    if sheet_url:
        cmd.append(sheet_url)
    if output_path:
        cmd.append(output_path)
    if target_user:
        cmd.append(target_user)

    # 运行主脚本
    result = subprocess.run(cmd, capture_output=True, text=True)

    if result.returncode != 0:
        print(json.dumps({
            'ok': False,
            'error': result.stderr
        }, ensure_ascii=False))
        sys.exit(1)

    # 解析输出
    try:
        output_data = json.loads(result.stdout)
    except json.JSONDecodeError:
        print(result.stdout)
        sys.exit(1)

    print(json.dumps(output_data, ensure_ascii=False))


if __name__ == '__main__':
    main()
