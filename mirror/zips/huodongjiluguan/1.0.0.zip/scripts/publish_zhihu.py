#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
知乎发布脚本
使用前请先在 config/platform_config.json 中配置 Token
"""

import json
import requests
import sys
import os
from datetime import datetime

CONFIG_PATH = os.path.join(os.path.dirname(__file__), '..', 'config', 'platform_config.json')

def load_config():
    """加载配置文件"""
    try:
        with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"❌ 配置文件不存在: {CONFIG_PATH}")
        sys.exit(1)
    except json.JSONDecodeError:
        print("❌ 配置文件格式错误")
        sys.exit(1)

def create_article(token, title, content, table_of_contents=False):
    """
    创建知乎文章
    
    参数:
        token: 知乎 Access Token
        title: 文章标题
        content: 文章内容（Markdown格式）
        table_of_contents: 是否显示目录
    """
    url = "https://api.zhihu.com/articles"
    
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    
    data = {
        "title": title,
        "content": content,
        "table_of_contents": table_of_contents
    }
    
    try:
        response = requests.post(url, headers=headers, json=data, timeout=10)
        result = response.json()
        
        if response.status_code == 201:
            return result
        else:
            print(f"❌ 创建文章失败: {result.get('error', '未知错误')}")
            return None
    except Exception as e:
        print(f"❌ 请求失败: {e}")
        return None

def main():
    """主函数"""
    if len(sys.argv) < 3:
        print("用法: python publish_zhihu.py <标题> <Markdown文件路径>")
        sys.exit(1)
    
    title = sys.argv[1]
    md_file = sys.argv[2]
    
    # 读取Markdown内容
    try:
        with open(md_file, 'r', encoding='utf-8') as f:
            content = f.read()
    except FileNotFoundError:
        print(f"❌ Markdown文件不存在: {md_file}")
        sys.exit(1)
    
    # 加载配置
    print("🔧 正在加载配置...")
    config = load_config()
    
    zhihu_config = config.get('zhihu', {})
    if not zhihu_config.get('enabled', False):
        print("❌ 知乎发布未启用，请在配置文件中设置 enabled: true")
        sys.exit(1)
    
    token = zhihu_config.get('token', '')
    
    if not token:
        print("❌ 请先在配置文件中设置 Token")
        sys.exit(1)
    
    # 创建文章
    print("📝 正在创建知乎文章...")
    result = create_article(token, title, content)
    
    if result:
        print(f"✅ 文章创建成功！")
        print(f"   文章ID: {result.get('id')}")
        print(f"   链接: {result.get('url', '请在知乎后台查看')}")
        
        # 保存记录
        record = {
            "platform": "zhihu",
            "title": title,
            "article_id": result.get('id'),
            "url": result.get('url'),
            "created_at": datetime.now().isoformat(),
            "status": "published"
        }
        
        record_file = os.path.join(os.path.dirname(__file__), '..', 'outputs', 'publish_records.json')
        try:
            with open(record_file, 'r', encoding='utf-8') as f:
                records = json.load(f)
        except:
            records = []
        
        records.append(record)
        
        with open(record_file, 'w', encoding='utf-8') as f:
            json.dump(records, f, ensure_ascii=False, indent=2)
        
        return result
    else:
        sys.exit(1)

if __name__ == '__main__':
    main()
