#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
微信公众号发布脚本
使用前请先在 config/platform_config.json 中配置 AppID 和 AppSecret
"""

import json
import requests
import sys
import os
from datetime import datetime

# 配置文件路径
CONFIG_PATH = os.path.join(os.path.dirname(__file__), '..', 'config', 'platform_config.json')

def load_config():
    """加载配置文件"""
    try:
        with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"❌ 配置文件不存在: {CONFIG_PATH}")
        print("请先复制 config/platform_config_template.json 并重命名为 platform_config.json")
        sys.exit(1)
    except json.JSONDecodeError:
        print("❌ 配置文件格式错误")
        sys.exit(1)

def get_access_token(appid, appsecret):
    """获取微信 access_token"""
    url = f"https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid={appid}&secret={appsecret}"
    
    try:
        response = requests.get(url, timeout=10)
        data = response.json()
        
        if 'access_token' in data:
            return data['access_token']
        else:
            print(f"❌ 获取 access_token 失败: {data.get('errmsg', '未知错误')}")
            return None
    except Exception as e:
        print(f"❌ 请求失败: {e}")
        return None

def create_draft(access_token, title, content, author="", digest="", content_source_url=""):
    """
    创建公众号草稿
    
    参数:
        access_token: 微信接口调用凭证
        title: 文章标题
        content: 图文消息内容（HTML格式）
        author: 作者（可选）
        digest: 图文消息摘要（可选）
        content_source_url: 图文消息来源链接（可选）
    """
    url = f"https://api.weixin.qq.com/cgi-bin/draft/add?access_token={access_token}"
    
    data = {
        "articles": [
            {
                "title": title,
                "content": content,
                "author": author,
                "digest": digest,
                "content_source_url": content_source_url,
                "thumb_media_id": "",  # 封面图片素材ID（需先上传）
                "need_open_comment": 1,  # 是否打开评论
                "only_fans_can_comment": 0  # 是否只有粉丝可以评论
            }
        ]
    }
    
    try:
        response = requests.post(url, json=data, timeout=10)
        result = response.json()
        
        if 'media_id' in result:
            return result['media_id']
        else:
            print(f"❌ 创建草稿失败: {result.get('errmsg', '未知错误')}")
            return None
    except Exception as e:
        print(f"❌ 请求失败: {e}")
        return None

def main():
    """主函数"""
    # 检查参数
    if len(sys.argv) < 3:
        print("用法: python publish_wechat.py <标题> <HTML文件路径>")
        print("示例: python publish_wechat.py '文章标题' ./article.html")
        sys.exit(1)
    
    title = sys.argv[1]
    html_file = sys.argv[2]
    
    # 读取HTML内容
    try:
        with open(html_file, 'r', encoding='utf-8') as f:
            content = f.read()
    except FileNotFoundError:
        print(f"❌ HTML文件不存在: {html_file}")
        sys.exit(1)
    
    # 加载配置
    print("🔧 正在加载配置...")
    config = load_config()
    
    wechat_config = config.get('wechat_mp', {})
    if not wechat_config.get('enabled', False):
        print("❌ 微信公众号发布未启用，请在配置文件中设置 enabled: true")
        sys.exit(1)
    
    appid = wechat_config.get('appid', '')
    appsecret = wechat_config.get('appsecret', '')
    
    if not appid or not appsecret:
        print("❌ 请先在配置文件中设置 AppID 和 AppSecret")
        sys.exit(1)
    
    # 获取 access_token
    print("🔑 正在获取 access_token...")
    access_token = get_access_token(appid, appsecret)
    if not access_token:
        sys.exit(1)
    
    # 创建草稿
    print("📝 正在创建草稿...")
    media_id = create_draft(access_token, title, content)
    
    if media_id:
        print(f"✅ 草稿创建成功！")
        print(f"   Media ID: {media_id}")
        print(f"   请登录公众号后台查看草稿")
        
        # 保存发布记录
        record = {
            "platform": "wechat_mp",
            "title": title,
            "media_id": media_id,
            "created_at": datetime.now().isoformat(),
            "status": "draft"
        }
        
        record_file = os.path.join(os.path.dirname(__file__), '..', 'outputs', 'publish_records.json')
        try:
            with open(record_file, 'r', encoding='utf-8') as f:
                records = json.load(f)
        except:
            records = []
        
        records.append(record)
        
        with open(record_file, 'w', encoding='utf-8') as f:
            json.dump(records, f, ensure_ascii=False, indent=2)
        
        return media_id
    else:
        sys.exit(1)

if __name__ == '__main__':
    main()
