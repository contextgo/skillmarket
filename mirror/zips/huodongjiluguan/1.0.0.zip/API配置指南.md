# 多平台API配置指南

## 一、微信公众号

### 1. 获取 AppID 和 AppSecret

1. 登录 [微信公众平台](https://mp.weixin.qq.com/)
2. 左侧菜单 → 开发 → 基本配置
3. 找到「开发者ID」
   - AppID(应用ID)：一串18位左右的字母数字
   - AppSecret(应用密钥)：点击「重置」获取（**注意：只显示一次，请妥善保存**）

### 2. 配置 IP 白名单

1. 在「基本配置」页面，找到「IP白名单」
2. 点击「查看」→「修改」
3. 添加你的服务器IP或本机公网IP
4. 如果不确定IP，可以先用 `curl ip.sb` 查询

### 3. 配置步骤

```json
{
  "wechat_mp": {
    "name": "微信公众号",
    "enabled": true,
    "appid": "wx1234567890abcdef",
    "appsecret": "your_app_secret_here",
    "token": "",
    "encoding_aes_key": ""
  }
}
```

### 4. 验证配置

运行测试命令：
```bash
cd scripts
python publish_wechat.py "测试标题" "../outputs/test_article.html"
```

---

## 二、知乎

### 1. 获取 Access Token

知乎开放平台目前主要面向企业开发者，个人获取Token较为复杂。

**替代方案：**
- 使用知乎专栏的「导入文档」功能
- 或使用浏览器插件辅助发布

### 2. 手动发布流程

1. 复制生成的知乎版本Markdown内容
2. 登录 [知乎创作中心](https://zhuanlan.zhihu.com/)
3. 点击「写文章」
4. 粘贴内容，调整格式
5. 发布

---

## 三、小红书

### 1. 现状说明

小红书**暂不支持**通过API直接发布图文笔记。

### 2. 手动发布流程

1. 复制生成的小红书版本文案
2. 登录 [小红书创作服务平台](https://creator.xiaohongshu.com/)
3. 点击「发布笔记」
4. 上传图片（活动照片/PPT截图）
5. 粘贴文案，添加话题标签
6. 发布

### 3. 优化建议

小红书笔记最佳实践：
- 封面图：PPT金句页或嘉宾特写
- 标题：20字以内，带emoji
- 正文：分段清晰，多用表情
- 话题：3-5个相关话题标签

---

## 四、今日头条

### 1. 获取 AppID 和 AppSecret

1. 登录 [今日头条开放平台](https://developer.toutiao.com/)
2. 注册开发者账号
3. 创建应用
4. 获取 AppID 和 AppSecret

### 2. 配置步骤

```json
{
  "toutiao": {
    "name": "今日头条",
    "enabled": true,
    "appid": "your_app_id",
    "appsecret": "your_app_secret"
  }
}
```

---

## 五、微博

### 1. 获取 Access Token

1. 登录 [微博开放平台](https://open.weibo.com/)
2. 创建应用
3. 获取 App Key 和 App Secret
4. 通过OAuth授权获取 Access Token

### 2. 注意事项

微博API有较多限制：
- 需要企业认证
- 有发布频次限制
- 内容需要审核

**建议：** 手动复制内容到微博发布

---

## 六、配置文件示例

完整的 `platform_config.json` 示例：

```json
{
  "wechat_mp": {
    "name": "微信公众号",
    "enabled": true,
    "appid": "wx1234567890abcdef",
    "appsecret": "your_secret_here",
    "token": "",
    "encoding_aes_key": ""
  },
  
  "xiaohongshu": {
    "name": "小红书",
    "enabled": false,
    "note": "暂不支持API发布，需手动复制"
  },
  
  "zhihu": {
    "name": "知乎",
    "enabled": false,
    "token": "your_token_here"
  },
  
  "toutiao": {
    "name": "今日头条",
    "enabled": false,
    "appid": "",
    "appsecret": ""
  },
  
  "weibo": {
    "name": "微博",
    "enabled": false,
    "access_token": ""
  }
}
```

---

## 七、安全提醒

⚠️ **重要：**

1. **不要分享配置文件**：包含敏感API密钥
2. **定期更换密钥**：建议每3个月重置一次AppSecret
3. **设置IP白名单**：限制API调用来源
4. **本地存储**：配置文件仅保存在本地，不上传云端

---

## 八、故障排查

### 微信公众号

| 错误码 | 含义 | 解决方案 |
|--------|------|---------|
| 40001 | access_token 失效 | 重新获取 |
| 40014 | token 无效 | 检查 AppID/AppSecret |
| 40164 | IP不在白名单 | 添加IP白名单 |
| 45009 | 接口调用频次超限 | 等待或升级接口额度 |

### 通用排查步骤

1. 检查网络连接
2. 检查配置文件格式（JSON有效）
3. 检查API密钥是否正确
4. 检查IP白名单设置
5. 查看API调用限额

---

## 九、帮助与支持

如遇问题，可以：

1. 查阅各平台官方文档
2. 在WorkBuddy中询问
3. 查看脚本输出的错误信息

**官方文档：**
- [微信公众号开发文档](https://developers.weixin.qq.com/doc/offiaccount/Getting_Started/Overview.html)
- [知乎开放平台](https://open.zhihu.com/)
- [今日头条开放平台](https://developer.toutiao.com/)
