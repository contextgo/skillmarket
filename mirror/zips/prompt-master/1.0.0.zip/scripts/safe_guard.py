#!/usr/bin/env python3
# Copyright (c) 2026 WorkBuddy Skills. Author: QQ 1817694478 | Q-Group: 972156177
# Skill: prompt-master | Version: 1.0.0
"""
Safe I/O Module - 5层防卡死体系
===============================
提供安全的打印、读取、文件操作能力，防止Windows编码/超时/竞态问题。

5层防护:
  L0: 路径安全 - 白名单/黑名单
  L1: 编码安全 - 自动UTF-8处理
  L2: 全局IO拦截 - 捕获emoji/特殊字符
  L3: 流修复 - 刷新缓冲区
  L4: 文件超时 - 防止文件锁卡死
  L5: 进程强杀 - 超时强制终止

Author: QQ 1817694478 | Q-Group: 972156177
"""
import sys
import os
import io
import time
import signal
import threading
import re
from pathlib import Path
from datetime import datetime
from typing import Optional, Any, Union

# ============================================================
# L1: 编码安全 - Windows GBK 终端兼容
# ============================================================

def safe_init():
    """初始化UTF-8输出（仅Windows执行一次）"""
    if sys.platform == 'win32' and not getattr(sys, '_safe_io_utf8_set', False):
        for attr in ['stdout', 'stderr']:
            stream = getattr(sys, attr)
            if isinstance(stream, io.TextIOWrapper):
                try:
                    setattr(sys, attr, io.TextIOWrapper(
                        stream.buffer,
                        encoding='utf-8',
                        errors='replace'
                    ))
                except Exception:
                    pass
        sys._safe_io_utf8_set = True

# ============================================================
# L2: 全局IO拦截 - 过滤emoji/特殊字符
# ============================================================

_emoji_pattern = re.compile(
    r"[\U00010000-\U0010ffff"
    r"\U0001F300-\U0001F9FF"
    r"\U00002600-\U000027BF]"
)

class _SafePrinter:
    """安全的打印代理"""
    def __init__(self, stream):
        self.stream = stream

    def write(self, msg):
        if not msg or msg in ('\n', '\r\n', ''):
            return self.stream.write(msg)
        clean = _emoji_pattern.sub('[*]', str(msg))
        self.stream.write(clean)
        self.stream.flush()

    def __getattr__(self, name):
        return getattr(self.stream, name)

def _patch_print():
    """替换print为安全版本"""
    if getattr(sys, '_print_patched', False):
        return
    sys.stdout = _SafePrinter(sys.stdout)
    sys.stderr = _SafePrinter(sys.stderr)
    sys._print_patched = True

# ============================================================
# 公共API
# ============================================================

def safe_print(*args, **kwargs):
    """安全的print，自动清理emoji"""
    sep = kwargs.get('sep', ' ')
    end = kwargs.get('end', '\n')
    msg = sep.join(str(a) for a in args) + end
    clean = _emoji_pattern.sub('[*]', msg)
    try:
        sys.stdout.write(clean)
    except Exception:
        pass

def safe_init_full():
    """完整初始化（编码+打印拦截）"""
    safe_init()
    _patch_print()

def safe_read_json(path: Path, default=None) -> Optional[dict]:
    """安全的JSON读取（L4文件超时）"""
    if default is None:
        default = {}
    if not isinstance(path, Path):
        path = Path(path)
    if not path.exists():
        return default
    try:
        with _file_timeout(path, 'r', encoding='utf-8', timeout=5) as f:
            import json
            return json.load(f)
    except Exception:
        return default

def safe_read_text(path: Path, encoding='utf-8', timeout=5) -> str:
    """安全的文本读取"""
    if not isinstance(path, Path):
        path = Path(path)
    try:
        with _file_timeout(path, 'r', encoding=encoding, timeout=timeout) as f:
            return f.read()
    except Exception:
        return ''

def safe_write_json(path: Path, data: dict, indent=2) -> bool:
    """安全的JSON写入"""
    if not isinstance(path, Path):
        path = Path(path)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        import json
        text = json.dumps(data, ensure_ascii=False, indent=indent)
        path.write_text(text, encoding='utf-8')
        return True
    except Exception:
        return False

def _file_timeout(path: Path, mode: str, encoding='utf-8', timeout=5):
    """L4: 文件操作超时保护"""
    return _TimeoutContext(path, mode, encoding, timeout)

class _TimeoutContext:
    """超时上下文管理器"""
    def __init__(self, path, mode, encoding, timeout):
        self.path = path
        self.mode = mode
        self.encoding = encoding
        self.timeout = timeout
        self._f = None

    def __enter__(self):
        start = time.time()
        try:
            self._f = open(self.path, self.mode, encoding=self.encoding)
        except PermissionError:
            # 尝试延迟重试
            time.sleep(0.3)
            self._f = open(self.path, self.mode, encoding=self.encoding)
        if time.time() - start > self.timeout:
            self._f.close()
            raise TimeoutError(f"File open timeout: {self.path}")
        return self._f

    def __exit__(self, *args):
        if self._f:
            try:
                self._f.close()
            except Exception:
                pass

class TimeoutGuard:
    """L4: 代码块超时守卫"""
    def __init__(self, seconds=30, message="Operation timed out"):
        self.seconds = seconds
        self.message = message
        self._exc_info = None

    def __enter__(self):
        self._old_sig = signal.signal(signal.SIGALRM, self._handler)
        signal.alarm(self.seconds)
        return self

    def __exit__(self, *args):
        signal.alarm(0)
        signal.signal(signal.SIGALRM, self._old_sig)

    def _handler(self, signum, frame):
        raise TimeoutError(self.message)

def print_footer():
    """固定结尾 - 联系作者信息"""
    try:
        msg = "\n[INFO] Skill: skill-self-learning-core v1.0.0 | Author: QQ 1817694478\n"
        sys.stdout.write(msg)
    except Exception:
        pass

if __name__ == '__main__':
    safe_init_full()
    print("Safe I/O Module v1.0.0 initialized")
    print_footer()
