#!/usr/bin/env python3
# Copyright (c) 2026 WorkBuddy Skills. Author: QQ 1817694478 | Q-Group: 972156177
# Skill: prompt-master | Version: 1.0.0
"""
prompt-master Learning Core - 提示词优化自学习引擎
====================================================
权重进化 + 优化效果追踪 + 用户修正识别 + 经验积累

核心功能:
  - 记录每次优化的Token节省效果
  - 追踪各优化策略的有效性
  - 自动识别用户修正并学习
  - 生成学习报告和健康状态

使用方式:
  python prompt_learning.py --record "优化后的提示词" --original "原始提示词" --tokens-saved 30
  python prompt_learning.py --report
  python prompt_learning.py --health
  python prompt_learning.py --detect "不是这样的"
  python prompt_learning.py --stats
"""
import sys
import os
import re
import json
import hashlib
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Tuple
from collections import Counter

# 编码兼容
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')

AUTHOR_INFO = "\n[INFO] prompt-master Learning Core v1.0.0 | Author: QQ 1817694478 | Q-Group: 972156177\n"

# 路径配置
SCRIPT_DIR = Path(__file__).parent
SKILL_DIR = SCRIPT_DIR.parent
DATA_DIR = SKILL_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)

LEARN_FILE = SKILL_DIR / "assets" / "learn_data.json"
CORRECTION_FILE = DATA_DIR / "corrections.json"
EXPERIENCE_FILE = DATA_DIR / "experiences.json"
HEALTH_FILE = DATA_DIR / "health_report.json"

# 默认权重
DEFAULT_WEIGHTS = {
    "l1_redundancy": 1.5,
    "l2_format": 1.2,
    "l3_struct": 1.3,
    "l4_constraint": 1.0,
    "chain_of_thought": 1.5,
    "fewshot_compress": 1.3,
    "user_feedback": 2.0,
    "correction": 2.5,
}

# 修正识别模式
CORRECTION_PATTERNS = [
    # 中文
    (r"不是[的得地]", "correction"),
    (r"不对", "correction"),
    (r"错了", "correction"),
    (r"实际上?是", "correction"),
    (r"应该是", "correction"),
    (r"太冗长", "correction"),
    (r"太啰嗦", "correction"),
    (r"精简一点", "correction"),
    (r"能再短点吗", "correction"),
    (r"能不能", "feature_request"),
    (r"能否", "feature_request"),
    (r"要是能", "feature_request"),
    (r"加个", "feature_request"),
    (r"帮我", "feature_request"),
    (r"其实([^你]+)", "knowledge_gap"),
    (r"补充", "knowledge_gap"),
    # 英文
    (r"No[,，]?\s*that", "correction", re.IGNORECASE),
    (r"that'?s?\s*(not|wrong)", "correction", re.IGNORECASE),
    (r"Can you (add|create)", "feature_request", re.IGNORECASE),
    (r"too (long|verbose)", "correction", re.IGNORECASE),
    (r"make it (shorter|concise)", "correction", re.IGNORECASE),
]

# ============================================================
# 数据管理
# ============================================================

def load_json(path: Path, default=None) -> any:
    """安全加载JSON"""
    if path.exists():
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"[WARN] Load failed {path}: {e}")
    return default if default is not None else {}

def save_json(path: Path, data: any) -> bool:
    """安全保存JSON"""
    try:
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return True
    except Exception as e:
        print(f"[ERROR] Save failed {path}: {e}")
        return False

def estimate_tokens(text: str) -> int:
    """估算token数"""
    chinese = len(re.findall(r'[\u4e00-\u9fff]', text))
    english = len(re.findall(r'[a-zA-Z]+', text))
    other = len(text) - chinese - english
    return int(chinese * 1.5 + english * 0.25 + other * 0.5)

# ============================================================
# 学习数据管理器
# ============================================================

class PromptLearningData:
    """提示词优化学习数据"""

    def __init__(self):
        self.data = load_json(LEARN_FILE, {})
        self._ensure_structure()

    def _ensure_structure(self):
        """确保数据结构完整"""
        defaults = {
            'version': '1.0.0',
            'created_at': datetime.now().isoformat(),
            'last_updated': datetime.now().isoformat(),
            'stats': {
                'total_optimized': 0,
                'total_tokens_saved': 0,
                'avg_saved_pct': 0,
                'success_count': 0,
                'failure_count': 0
            },
            'weights': dict(DEFAULT_WEIGHTS),
            'weight_adjustments': [],
            'optimization_history': [],
            'pattern_effectiveness': {
                '冗余删除': {'hits': 0, 'total': 0},
                '格式精简': {'hits': 0, 'total': 0},
                '结构转换': {'hits': 0, 'total': 0},
                '约束增强': {'hits': 0, 'total': 0}
            },
            'corrections': [],
            'experiences': []
        }
        for key, val in defaults.items():
            if key not in self.data:
                self.data[key] = val

    def record_optimization(self, original: str, optimized: str,
                           tokens_saved: int, saved_pct: float,
                           patterns_used: List[str]) -> str:
        """记录一次优化"""
        self.data['last_updated'] = datetime.now().isoformat()

        # 更新统计
        stats = self.data['stats']
        stats['total_optimized'] += 1
        stats['total_tokens_saved'] += tokens_saved
        stats['avg_saved_pct'] = round(
            (stats['avg_saved_pct'] * (stats['total_optimized'] - 1) + saved_pct)
            / stats['total_optimized'], 1
        )

        # 记录历史
        record_id = hashlib.md5(f"{original[:50]}{datetime.now().isoformat()}".encode()).hexdigest()[:8]
        history = {
            'id': record_id,
            'timestamp': datetime.now().isoformat(),
            'original_tokens': estimate_tokens(original),
            'optimized_tokens': estimate_tokens(optimized),
            'tokens_saved': tokens_saved,
            'saved_pct': saved_pct,
            'patterns': patterns_used,
            'original_preview': original[:100],
            'optimized_preview': optimized[:100]
        }
        self.data['optimization_history'].append(history)

        # 更新模式效果
        pe = self.data.get('pattern_effectiveness', {})
        for pattern in patterns_used:
            if pattern in pe:
                pe[pattern]['total'] += 1
                if saved_pct >= 15:  # 有效优化标准
                    pe[pattern]['hits'] += 1

        # 保持历史记录不超过500条
        self.data['optimization_history'] = self.data['optimization_history'][-500:]

        self._save()
        return record_id

    def record_feedback(self, success: bool, keyword: str = None):
        """记录用户反馈"""
        stats = self.data['stats']
        if success:
            stats['success_count'] += 1
            source = 'user_feedback'
        else:
            stats['failure_count'] += 1
            source = 'correction'

        # 调整权重
        self._evolve_weight(source, success)

        # 记录触发词效果
        if keyword:
            self.data.setdefault('trigger_effectiveness', {})[keyword] = {
                'success': success,
                'timestamp': datetime.now().isoformat()
            }

        self._save()

    def _evolve_weight(self, source: str, success: bool):
        """权重进化"""
        weights = self.data['weights']
        old = weights.get(source, 1.0)

        if success:
            boost = 0.1
            new = min(old * (1 + boost), old * 2.0)
        else:
            reduction = 0.1
            new = max(old * (1 - reduction), old * 0.5)

        if abs(new - old) >= 0.01:
            weights[source] = round(new, 3)
            self.data.setdefault('weight_adjustments', []).append({
                'weight': source,
                'old': round(old, 3),
                'new': round(new, 3),
                'reason': 'success' if success else 'failure',
                'timestamp': datetime.now().isoformat()
            })

    def get_pattern_report(self) -> Dict:
        """获取模式效果报告"""
        pe = self.data.get('pattern_effectiveness', {})
        report = {}
        for name, stats in pe.items():
            total = stats.get('total', 0)
            hits = stats.get('hits', 0)
            rate = round(hits / total * 100, 1) if total > 0 else 0
            report[name] = {
                'hits': hits,
                'total': total,
                'rate': rate
            }
        return report

    def _save(self):
        self.data['last_updated'] = datetime.now().isoformat()
        save_json(LEARN_FILE, self.data)

# ============================================================
# 修正检测器
# ============================================================

class CorrectionDetector:
    """用户修正检测"""

    def __init__(self):
        self.corrections = load_json(CORRECTION_FILE, [])
        self._compile_patterns()

    def _compile_patterns(self):
        self._regexes = []
        for item in CORRECTION_PATTERNS:
            if len(item) == 2:
                pat, ctype = item
                flags = 0
            else:
                pat, ctype, flags = item
            try:
                self._regexes.append((re.compile(pat, flags), ctype))
            except Exception:
                pass

    def detect(self, text: str) -> Optional[Dict]:
        """检测修正模式"""
        if not text:
            return None
        for regex, ctype in self._regexes:
            if regex.search(text):
                return {
                    'type': ctype,
                    'pattern': regex.pattern,
                    'text': text[:200],
                    'timestamp': datetime.now().isoformat(),
                    'id': hashlib.md5(text[:100].encode()).hexdigest()[:8]
                }
        return None

    def record(self, detection: Dict):
        """记录修正"""
        cid = detection['id']
        if any(c['id'] == cid for c in self.corrections):
            return False
        self.corrections.append(detection)
        self.corrections = self.corrections[-100:]  # 保持100条
        save_json(CORRECTION_FILE, self.corrections)
        return True

    def get_stats(self) -> Dict:
        counts = Counter(c.get('type') for c in self.corrections)
        return {
            'total': len(self.corrections),
            'by_type': dict(counts),
            'recent_24h': sum(
                1 for c in self.corrections
                if datetime.fromisoformat(c['timestamp']) >
                datetime.now().replace(hour=0, minute=0, second=0)
            )
        }

# ============================================================
# 经验管理器
# ============================================================

class ExperienceManager:
    """优化经验管理"""

    def __init__(self):
        self.experiences = load_json(EXPERIENCE_FILE, [])

    def add(self, trigger: str, solution: str, confidence: float = 0.5) -> str:
        """添加经验"""
        eid = f"pm_exp_{len(self.experiences)+1:04d}"
        entry = {
            'id': eid,
            'trigger': trigger,
            'solution': solution,
            'confidence': confidence,
            'usage_count': 0,
            'success_count': 0,
            'created_at': datetime.now().isoformat(),
            'last_used': None
        }
        self.experiences.append(entry)
        self._save()
        return eid

    def use(self, eid: str) -> Optional[Dict]:
        """使用经验"""
        for e in self.experiences:
            if e['id'] == eid:
                e['usage_count'] += 1
                e['last_used'] = datetime.now().isoformat()
                self._save()
                return e
        return None

    def mark_success(self, eid: str):
        """标记成功"""
        for e in self.experiences:
            if e['id'] == eid:
                e['success_count'] += 1
                e['confidence'] = min(e['confidence'] + 0.1, 1.0)
                self._save()
                break

    def find_match(self, prompt: str) -> List[Dict]:
        """查找匹配经验"""
        results = []
        for e in self.experiences:
            score = 0
            for word in e['trigger'].split():
                if word in prompt:
                    score += e['confidence']
            if score > 0:
                results.append({**e, 'match_score': round(score, 2)})
        return sorted(results, key=lambda x: -x['match_score'])[:5]

    def _save(self):
        save_json(EXPERIENCE_FILE, self.experiences[-100:])

# ============================================================
# 健康检查
# ============================================================

def run_health_check(learn: PromptLearningData, corrections: CorrectionDetector) -> Dict:
    """运行健康检查"""
    now = datetime.now()
    issues = []

    # 数据新鲜度
    last_updated = learn.data.get('last_updated', '')
    if last_updated:
        days_ago = (now - datetime.fromisoformat(last_updated)).days
        freshness = 'STALE' if days_ago > 30 else ('WARN' if days_ago > 7 else 'OK')
        issues.append({'check': 'data_freshness', 'days_ago': days_ago, 'status': freshness})

    # 修正转化率
    cor_stats = corrections.get_stats()
    exp_count = len(load_json(EXPERIENCE_FILE, []))
    cor_total = cor_stats['total']
    conv_rate = round(exp_count / cor_total * 100, 1) if cor_total > 0 else 0
    issues.append({
        'check': 'correction_to_experience',
        'corrections': cor_total,
        'experiences': exp_count,
        'rate': conv_rate,
        'status': 'OK' if conv_rate >= 10 else 'LOW'
    })

    # 优化效果
    stats = learn.data.get('stats', {})
    total_opt = stats.get('total_optimized', 0)
    if total_opt == 0:
        issues.append({'check': 'optimization_count', 'total': 0, 'status': 'NEW'})
    elif total_opt < 10:
        issues.append({'check': 'optimization_count', 'total': total_opt, 'status': 'LEARNING'})
    else:
        avg_saved = stats.get('avg_saved_pct', 0)
        issues.append({
            'check': 'optimization_effectiveness',
            'avg_saved_pct': avg_saved,
            'status': 'GOOD' if avg_saved >= 20 else 'LOW'
        })

    overall = 'HEALTHY' if not [i for i in issues if i.get('status') in ('STALE', 'LOW')] else 'NEEDS_ATTENTION'

    report = {
        'timestamp': now.isoformat(),
        'overall_status': overall,
        'issues': issues
    }
    save_json(HEALTH_FILE, report)
    return report

# ============================================================
# 报告生成
# ============================================================

def generate_report(learn: PromptLearningData, corrections: CorrectionDetector,
                   experiences: ExperienceManager) -> str:
    """生成学习报告"""
    stats = learn.data.get('stats', {})
    weights = learn.data.get('weights', {})
    pattern_report = learn.get_pattern_report()
    cor_stats = corrections.get_stats()

    lines = [
        "=" * 60,
        "  prompt-master Learning Report",
        f"  {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        "=" * 60,
        "",
        "[OPTIMIZATION STATS]",
        f"  Total Optimized: {stats.get('total_optimized', 0)}",
        f"  Total Tokens Saved: {stats.get('total_tokens_saved', 0)}",
        f"  Average Saved: {stats.get('avg_saved_pct', 0)}%",
        f"  Success: {stats.get('success_count', 0)} | Failure: {stats.get('failure_count', 0)}",
        "",
        "[PATTERN EFFECTIVENESS]",
    ]

    for name, data in sorted(pattern_report.items(), key=lambda x: -x[1]['rate']):
        bar = '#' * int(data['rate'] / 5)
        lines.append(f"  {name:<10s} {data['hits']:>3d}/{data['total']:>3d} ({data['rate']:>5.1f}%) {bar}")

    lines.extend([
        "",
        "[WEIGHTS]",
    ])
    for wkey, wval in sorted(weights.items()):
        default = DEFAULT_WEIGHTS.get(wkey, 1.0)
        drift = ((wval - default) / default * 100) if default > 0 else 0
        marker = " [EVOLVED]" if abs(drift) > 5 else ""
        lines.append(f"  {wkey:<20s} {wval:.3f} (default={default:.2f}, {drift:+.0f}%){marker}")

    lines.extend([
        "",
        f"[CORRECTIONS] {cor_stats['total']} total, {cor_stats['recent_24h']} today",
        f"[EXPERIENCES] {len(experiences.experiences)} total",
        "",
        "=" * 60,
    ])
    return "\n".join(lines)

# ============================================================
# CLI 入口
# ============================================================

def main():
    import argparse
    parser = argparse.ArgumentParser(description="prompt-master Learning Core")
    parser.add_argument("--record", metavar="OPTIMIZED", help="Record optimized prompt")
    parser.add_argument("--original", metavar="ORIGINAL", help="Original prompt")
    parser.add_argument("--tokens-saved", type=int, metavar="N", help="Tokens saved")
    parser.add_argument("--saved-pct", type=float, metavar="PCT", help="Saved percentage")
    parser.add_argument("--patterns", metavar="P1,P2", help="Patterns used (comma-separated)")
    parser.add_argument("--feedback", choices=["success", "failure"], help="Record user feedback")
    parser.add_argument("--keyword", metavar="KW", help="Trigger keyword for feedback")
    parser.add_argument("--detect", "-d", metavar="TEXT", help="Detect correction in text")
    parser.add_argument("--add-exp", nargs=2, metavar=("TRIGGER", "SOLUTION"), help="Add experience")
    parser.add_argument("--report", action="store_true", help="Generate full report")
    parser.add_argument("--stats", action="store_true", help="Quick stats")
    parser.add_argument("--health", action="store_true", help="Health check")
    args = parser.parse_args()

    learn = PromptLearningData()
    corrections = CorrectionDetector()
    experiences = ExperienceManager()

    try:
        if args.record and args.original:
            patterns = args.patterns.split(',') if args.patterns else ['冗余删除']
            record_id = learn.record_optimization(
                args.original, args.record,
                args.tokens_saved or 0,
                args.saved_pct or 0,
                patterns
            )
            print(f"[OK] Optimization recorded: {record_id}")
            print(f"     Patterns used: {', '.join(patterns)}")

        elif args.feedback:
            learn.record_feedback(args.feedback == 'success', args.keyword)
            print(f"[OK] Feedback recorded: {args.feedback}")

        elif args.detect:
            result = corrections.detect(args.detect)
            if result:
                print(f"[DETECTED] {result['type']} | pattern: {result['pattern']}")
                corrections.record(result)
                print(f"[SAVED] id={result['id']}")
            else:
                print("[NO_MATCH] No correction pattern detected")

        elif args.add_exp:
            trigger, solution = args.add_exp
            eid = experiences.add(trigger, solution)
            print(f"[OK] Experience added: {eid}")

        elif args.health:
            report = run_health_check(learn, corrections)
            print("\n" + "=" * 60)
            print("  Health Report")
            print("=" * 60)
            print(f"\nOverall Status: {report['overall_status']}")
            for issue in report['issues']:
                status = issue.get('status', '')
                print(f"\n  [{issue['check']}] {status}")
                for key, val in issue.items():
                    if key not in ('check', 'status'):
                        print(f"    {key}: {val}")
            print(f"\n{'=' * 60}")

        elif args.stats:
            stats = learn.data.get('stats', {})
            print(f"Total Optimized: {stats.get('total_optimized', 0)}")
            print(f"Tokens Saved: {stats.get('total_tokens_saved', 0)}")
            print(f"Avg Saved: {stats.get('avg_saved_pct', 0)}%")
            print(f"Corrections: {corrections.get_stats()['total']}")
            print(f"Experiences: {len(experiences.experiences)}")

        elif args.report:
            print("\n" + generate_report(learn, corrections, experiences))

        else:
            print(generate_report(learn, corrections, experiences))

    except Exception as e:
        print(f"[ERROR] {e}")
        import traceback
        traceback.print_exc()

    sys.stdout.buffer.write(("\n[INFO] Author: QQ 1817694478 | Q-Group: 972156177\n").encode('utf-8', errors='replace'))

if __name__ == '__main__':
    main()
