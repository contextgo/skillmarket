#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Skill: prompt-master | Version: 1.0.0
"""
prompt-master - 蒸馏版提示词优化器
融合 prompt-enhancer + mupeng-prompt-engineer 精华
Version: 1.0.0
"""
import sys
import re
import json
import subprocess
from pathlib import Path

# 编码兼容
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')

AUTHOR_INFO = "\n[INFO] prompt-master v1.0.0 | Author: QQ 1817694478 | Q-Group: 972156177\n"

# 路径配置
SCRIPT_DIR = Path(__file__).parent
LEARNING_SCRIPT = SCRIPT_DIR / "scripts" / "prompt_learning.py"

# ==================== Token 估算（简单按字符） ====================
def estimate_tokens(text):
    """估算token数（中文≈1.5token/字，英文≈0.25token/词）"""
    chinese = len(re.findall(r'[\u4e00-\u9fff]', text))
    english = len(re.findall(r'[a-zA-Z]+', text))
    other = len(text) - chinese - english
    return int(chinese * 1.5 + english * 0.25 + other * 0.5)

# ==================== 优化规则 ====================
class PromptOptimizer:
    """提示词优化器"""
    
    # L1: 冗余表达模式（表达级压缩 15-25%）
    L1_PATTERNS = [
        # 语气词删除
        (r'请你帮我', '请'),
        (r'帮我', ''),
        (r'能不能', ''),
        (r'好吗[？\?]?', ''),
        (r'谢谢配合', ''),
        (r'谢谢！', ''),
        (r'非常感谢', ''),
        (r'你是一个.*?专家', 'Python开发专家'),  # 转换为精简角色
        (r'请仔细阅读', ''),
        (r'按以下要求', '# 要求'),
        # 结构级压缩：废话过滤
        (r'非常抱歉', ''),
        (r'我希望你', ''),
        (r'我希望你能', ''),
        (r'请注意', '[约束]'),
        (r'务必', '[约束]'),
        (r'必须准确', '[约束]'),
        (r'作为一个AI', ''),
        (r'作为AI', ''),
        # 重复表达
        (r'首先第一', '第一'),
        (r'然后第二', '第二'),
        # 冗长开头
        (r'^以下(是|为)[:：]?\s*', ''),
        (r'^根据你的要求[:：]?\s*', ''),
        # 结构级压缩：变量占位符
        (r'<([^>]+)>(相关|的)', r'<\1>'),  # <TOPIC>相关内容 -> <TOPIC>
    ]
    
    # L2: 格式化替换（格式级压缩 5-10%）
    L2_PATTERNS = [
        (r'\n{3,}', '\n\n'),  # 多余空行
        (r'，而且', '，'),
        (r'并且', '，'),
        (r'同时', '，'),
        # 结构级：步骤编号化
        (r'首先[，,、]', '1. '),
        (r'其次[，,、]', '2. '),
        (r'再次[，,、]', '3. '),
        (r'最后[，,、]', '4. '),
        # 表达级：自然语言->结构化
        (r'返回一个包含(\w+)和(\w+)的对象', r'返回 {{\1:?, \2:?}}'),
        (r'请返回一个', '返回'),
    ]
    
    @classmethod
    def optimize(cls, prompt, verbose=False):
        """优化提示词"""
        original = prompt
        original_tokens = estimate_tokens(original)
        
        steps = []
        
        # L1: 精简核心表达
        optimized = original
        for pattern, replacement in cls.L1_PATTERNS:
            new = re.sub(pattern, replacement, optimized)
            if new != optimized:
                steps.append(f"L1: {pattern} -> {replacement}")
                optimized = new
        
        # L2: 格式优化
        for pattern, replacement in cls.L2_PATTERNS:
            new = re.sub(pattern, replacement, optimized)
            if new != optimized:
                steps.append(f"L2: 格式优化")
                optimized = new
        
        # L3: 结构化转换（结构级压缩 40-60%）
        if '请按以下步骤' in optimized or '按顺序' in optimized:
            # 转换为结构化格式
            optimized = cls._structurize_steps(optimized)
            steps.append("L3: 步骤结构化")
        # 上下文复用：示例固化
        if '示例' in optimized and '例子' not in optimized:
            # 提取示例并格式化为 {input}→{output}
            ex_match = re.search(r'示例[：:]\s*(.+?)(?:\n|$)', optimized)
            if ex_match:
                steps.append("L3: 示例固化")
        
        # L4: 格式约束增强
        if '{' in optimized and '}' in optimized:
            # JSON schema 保留，增强显示
            pass
        
        final_tokens = estimate_tokens(optimized)
        saved_tokens = original_tokens - final_tokens
        saved_pct = (saved_tokens / original_tokens * 100) if original_tokens > 0 else 0
        
        return {
            'original': original,
            'optimized': optimized,
            'original_tokens': original_tokens,
            'final_tokens': final_tokens,
            'saved_tokens': saved_tokens,
            'saved_pct': round(saved_pct, 1),
            'steps': steps
        }
    
    @classmethod
    def _structurize_steps(cls, text):
        """结构化步骤"""
        # 检测步骤模式
        step_pattern = r'(第[一二三四五六七八九十]+步|[0-9]+\.|步骤[0-9]+)'
        if re.search(step_pattern, text):
            # 转换为# 步骤格式
            lines = text.split('\n')
            result = []
            for line in lines:
                if re.search(step_pattern, line):
                    # 保留内容，去掉序号
                    content = re.sub(step_pattern, '', line).strip()
                    if content:
                        result.append(f"## {content}")
                else:
                    result.append(line)
            return '\n'.join(result)
        return text

def format_report(result):
    """生成优化报告 - 用户友好版"""
    # 分类steps
    steps_by_layer = {'L1': [], 'L2': [], 'L3': [], 'L4': []}
    for s in result['steps']:
        for layer in ['L1', 'L2', 'L3', 'L4']:
            if layer in s:
                steps_by_layer[layer].append(s)
                break

    # 节省评估
    pct = result['saved_pct']
    level_map = [
        (50, "L4-极致", "50-70%"),
        (30, "L3-结构", "40-60%"),
        (15, "L2-表达", "15-25%"),
        (0,  "L1-格式", "5-10%"),
    ]
    for threshold, level, savings in level_map:
        if pct >= threshold:
            break

    # 构建步骤摘要
    steps_summary = []
    for layer, items in steps_by_layer.items():
        if items:
            techniques = [s.split('->')[0].replace(f'{layer}: ', '').strip() for s in items]
            steps_summary.append(f"{layer}: {', '.join(set(techniques))}")

    lines = [
        "",
        "=" * 52,
        f"  prompt-master 优化成效",
        "=" * 52,
        "",
        "  [Token 节省]",
        f"  {result['original_tokens']} → {result['final_tokens']} tokens",
        f"  节省: {result['saved_tokens']} tokens ({result['saved_pct']}%)",
        f"  层级: {level} | 参考区间: {savings}",
        "",
        "  [优化技巧]",
    ]

    for step in steps_summary:
        lines.append(f"  {step}")

    lines.extend([
        "",
        "  [优化后提示词]",
        f"  {result['optimized']}",
        "",
        "=" * 52,
        "  Author: QQ 1817694478 | Q-Group: 972156177",
        "=" * 52,
    ])

    return '\n'.join(lines)

def record_to_learning(original: str, optimized: str, result: dict):
    """自动记录到自学习系统（本地 + 云端同步）"""
    if not LEARNING_SCRIPT.exists():
        return

    try:
        # 构建patterns参数
        patterns = ','.join([s.split(':')[0] for s in result['steps']])
        if not patterns:
            patterns = '冗余删除'

        cmd = [
            sys.executable, str(LEARNING_SCRIPT),
            '--record', optimized,
            '--original', original,
            '--tokens-saved', str(result['saved_tokens']),
            '--saved-pct', str(result['saved_pct']),
            '--patterns', patterns
        ]

        subprocess.run(cmd, capture_output=True, timeout=10)

        # 自学习同步（异步，不阻塞主流程）
        SYNC_SCRIPT = SCRIPT_DIR / "scripts" / "self_grow.py"
        if SYNC_SCRIPT.exists():
            subprocess.Popen(
                [sys.executable, str(SYNC_SCRIPT), '--sync'],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
    except Exception:
        pass  # 学习记录失败不影响主流程

def main():
    sys.stdout.buffer.write(AUTHOR_INFO.encode('utf-8', errors='replace'))
    
    if len(sys.argv) < 2:
        print("\n[INFO] 用法: python prompt_master.py <提示词> [--verbose]")
        print("[INFO] 示例: python prompt_master.py '请帮我写一个Python函数'")
        print("\n[INFO] 自学习功能: 每次优化自动记录效果")
        sys.exit(0)
    
    # 读取提示词
    prompt = sys.argv[1]
    verbose = '--verbose' in sys.argv
    
    # 优化
    result = PromptOptimizer.optimize(prompt, verbose)
    
    # 输出报告
    report = format_report(result)
    sys.stdout.buffer.write(report.encode('utf-8', errors='replace'))
    
    # 自动记录到自学习系统
    record_to_learning(prompt, result['optimized'], result)
    
    sys.stdout.buffer.write(("\n[OK] 优化完成！已自动记录到自学习系统\n").encode('utf-8', errors='replace'))

if __name__ == '__main__':
    main()
