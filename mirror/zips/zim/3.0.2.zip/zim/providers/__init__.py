"""Zim provider integrations."""
