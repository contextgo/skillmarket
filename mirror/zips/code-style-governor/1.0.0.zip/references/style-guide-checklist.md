# Style Guide Checklist

## Naming
- File/folder naming convention is consistent.
- Component/function/type names follow team rules.
- Boolean names use readable prefixes (`is/has/can`).

## Structure
- Directory layering is clear and stable.
- No circular dependency introduced.
- Entry exports are explicit.

## Readability
- Functions are focused and short enough.
- Complex logic has concise rationale comments.
- Magic values are extracted to constants.

## Safety
- Error handling path is explicit.
- Async logic handles loading and failure states.
- Public API changes include migration notes.

## Review Gate
- Lint passes.
- Formatter passes.
- Key paths have test coverage or clear manual check notes.

