# 代码生成规范

## 硬性门禁

生成 ServiceImpl 之前，必须已完成第三步的验证：读取 Demo、javap 反编译、交叉比对。

**代码质量要求**：生成的代码应该是优雅的、可维护的。具体标准：
- 命名清晰：变量名、方法名自解释，不言自明的代码不写注释
- 结构整洁：一个方法一个职责，参数组装 → SDK 调用 → 结果解析，层次分明
- 注释恰当：注释表达业务含义或调用意图（如「2.42 直接下发」「解析下发响应」）
- 不堆砌：不用到处 try-catch，统一在 ServiceImpl 方法外层处理；不用冗余的 null 判断包装

---

## 代码结构

```
src/main/java/{项目包路径}/sumpay/
├── config/SumpayFxSettleConfig.java     — @ConfigurationProperties，含 resolveCertPath()
├── client/SumpayClient.java             — SDK 封装，3 个 execute + verifySign
├── model/
│   ├── dto/                             — 各接口请求 DTO
│   ├── vo/                              — 含 SumpayResult<T> + 各接口响应 VO
│   └── enums/                            — FxSettleServiceEnum + 文档枚举类（IdTypeEnum 等）
├── service/
│   ├── FxSettleService.java             — 接口定义
│   └── impl/FxSettleServiceImpl.java    — 实现（核心）
└── exception/SumpayFxSettleException.java
```

包路径和命名风格与现有项目一致。如项目已有 `integration/`、`thirdparty/` 等包，优先放入。不生成 Controller。

---

## 基础组件

### SumpayFxSettleConfig

`@ConfigurationProperties(prefix = "sumpay.fx-settle")`，字段：

| 字段 | 示例 | 说明 |
|------|------|------|
| `gatewayUrl` | `https://test.sumpay.cn/entrance/gateway.htm` | 生产换 `entrance.sumpay.cn` |
| `appId` | `s100000040` | |
| `merNo` | `200104913781` | |
| `certType` | `CERT` | 固定 |
| `certPassword` | `sumpay` | 生产换真实密码 |
| `privateKeyPath` | `classpath:cert/your-private-key.pfx` | 从文档系统下载的证书文件名 |
| `publicKeyPath` | `classpath:cert/your-public-key.cer` | 从文档系统下载的证书文件名 |
| `domain` | `www.your-domain.com` | 仅文件上传用 |
| `notifyBaseUrl` | `http://your-server:8080` | 必须公网可达 |

必须提供 `resolveCertPath(String path)`：支持 `classpath:` 前缀，必须 `URLDecoder.decode(url.getFile(), "UTF-8")`。

### SumpayClient

```java
@Service
public class SumpayClient {
    public Map<String, String> execute(MerchantBaseRequest bizRequest) { ... }
    public Map<String, String> execute(MerchantBaseRequest bizRequest, List<FileContext> fileParams) { ... }
    public Map<String, String> execute(MerchantBaseRequest bizRequest, Map<String, String> subParams, List<FileContext> fileParams) { ... }
    public boolean verifySign(Map<String, String> params) { ... }  // params 会被修改，调用前需 copy
}
```

doExecute 四步：填充公共参数 → 构建 Request（certType/content/password/证书路径/url/编码字段）→ 处理 fileParams/subParams → `new SumpayServiceImpl().execute(targetRequest)`。

关键：sign_type 不在 bizRequest 上设，由 `Request.setCertType("CERT")` 内部处理。domain 仅 fileParams 非空时设置。

### SumpayResult

统一响应包装。`SumpayResult.success(data)` / `SumpayResult.fail(respCode, respMsg)`。

---

## 接口方法清单与调用模式

所有接口遵循 **DTO → SDK Request → execute → 解析响应** 模式。共四种变体：

### 模式 A: 普通接口

适用：2.1 个人客户信息上传、2.2 查询个人客户信息、2.4 查询企业客户信息、2.10 文件查询、2.42 直接下发、2.43 直接下发查询、2.45 收结汇4.0材料查询、2.46 收结汇财务明细下载、2.29 下发电子回单下载

```java
SdkXxxRequest req = new SdkXxxRequest();
req.setService(FxSettleServiceEnum.XXX.getValue());
req.setMer_no(config.getMerNo());
// 必填：req.setXxx(request.getXxx());
// 选填：if (request.getXxx() != null) req.setXxx(request.getXxx());
// 每个 setter 必须 javap 确认存在

Map<String, String> resp = sumpayClient.execute(req);  // 不设 domain、不设 fileParams
```

### 模式 B: 文件上传

适用：2.9 文件上传

```java
FileContext fileContext = new FileContext();
fileContext.setFieldName("file");
fileContext.setOriginalFilename(request.getFile().getOriginalFilename());
fileContext.setFileBytes(request.getFile().getBytes());  // byte[]，不调用 req.setFile()

SdkXxxRequest req = new SdkXxxRequest();
req.setService(...);  req.setMer_no(...);  // 其他 setter

Map<String, String> resp = sumpayClient.execute(req, Collections.singletonList(fileContext));
// doExecute 自动设 domain 和 setUserMultipart
```

### 模式 C: 带子参数

适用：2.40 材料上送

```java
List<Map<String, Object>> detailFiles = new ArrayList<>();
for (var item : request.getFiles()) {
    Map<String, Object> map = new HashMap<>();
    map.put("customer_no", item.getCustomerNo());
    map.put("trade_type", item.getTradeType());
    map.put("sumpay_batch_no", item.getSumpayBatchNo());
    detailFiles.add(map);
}

Map<String, String> subParams = new HashMap<>();
subParams.put("[files", JSON.toJSONString(detailFiles));  // key = "[files"，从 Demo 确认

SdkXxxRequest req = new SdkXxxRequest();
req.setService(...);  req.setMer_no(...);
// 不调用 req.setFiles()，走 subParams

Map<String, String> resp = sumpayClient.execute(req, subParams, null);
```

### 模式 D: 文件上传 + 实体参数

适用：2.3 企业客户

```java
SdkXxxRequest req = new SdkXxxRequest();
req.setService(...);  req.setMer_no(...);  // 其他 setter

Map<String, String> resp;
if (request.getFile() != null && !request.getFile().isEmpty()) {
    FileContext fileContext = new FileContext();
    fileContext.setFieldName("file");
    fileContext.setOriginalFilename(request.getFile().getOriginalFilename());
    fileContext.setFileBytes(request.getFile().getBytes());  // 不调用 req.setFile()
    resp = sumpayClient.execute(req, Collections.singletonList(fileContext));
} else {
    resp = sumpayClient.execute(req);
}
```

### 异步通知

适用：2.41 收款材料异步通知、2.44 直接下发异步通知

**返回格式规则：** 通知接口必须通过 Map 构建响应对象，再用 `JSON.toJSONString()` 序列化为 JSON 字符串返回。`resp_code` 为 `000000` 表示成功（商盟不再重试），其他值表示失败（商盟会持续重试）。禁止手写 JSON 字符串字面量。

```java
public String handleXxxNotify(Map<String, String> params) {
    Map<String, String> verifyParams = new HashMap<>(params);  // copy，verifySign 会修改原 map
    if (!sumpayClient.verifySign(verifyParams)) {
        Map<String, String> fail = new HashMap<>();
        fail.put("resp_code", "999999");
        fail.put("resp_msg", "verify failed");
        return JSON.toJSONString(fail);
    }
    // 解析参数、幂等处理（数据库 UNIQUE / Redis SETNX）

    // 返回 000000 后不再重试；非 000000 持续重试
    Map<String, String> success = new HashMap<>();
    success.put("resp_code", "000000");
    success.put("resp_msg", "success");
    return JSON.toJSONString(success);
}
```

---

## 字段处理规范

### 命名映射

| 层级 | 规则 | 示例 |
|------|------|------|
| 文档/SDK 字段 | 下划线 | `order_no` |
| DTO/VO Java 字段 | 驼峰 | `orderNo` |
| SDK setter | set + 下划线 | `setOrder_no()` — javap 确认 |
| SDK 响应 Map key | 下划线原样 | `resp.get("order_no")` |

### DTO/VO 命名规范

所有 DTO 和 VO 类以 `Sm` 前缀命名，避免与 SDK 类名冲突：

| 类型 | 命名规则 | 示例 |
|------|----------|------|
| 请求 DTO | `Sm{业务名}Request` | `SmDistributeRequest`、`SmQueryPersonalCustomerRequest` |
| 响应 VO | `Sm{业务名}Result` | `SmDistributeResult`、`SmFileUploadResult` |

### 字段来源处理

| 来源 | 处理 |
|------|------|
| `service` | 固定值 `req.setService(FxSettleServiceEnum.XXX.getValue())` |
| `mer_no` | 配置读取 `req.setMer_no(config.getMerNo())` |
| `notify_url` | 配置拼接 `req.setNotify_url(config.getNotifyBaseUrl() + "/sumpay/notify/xxx")` |
| 文档必填 + javap 存在 | 直接映射 |
| 文档选填 + javap 存在 | null 判断后映射 |
| 文档有 + javap 不存在 | 跳过，记录 TODO |
| Demo 有 + 文档没有 | 以 Demo 为准 |

敏感字段（realname, account_no, id_no 等）无需手动加密，SDK 自动 AES 处理。

### 注释规范

所有注释内容必须来源于在线接口文档，不自编描述。

**DTO 字段**：取在线文档「请求参数」表的「变量名」+「说明」列。无枚举引用时用单行格式；有 `@see` 时必须用多行格式，描述和 `@see` 分行。

```java
/** 订单号 — 商户下发订单号，商户自己生成保证唯一 */
private String orderNo;
/**
 * 下发类型 — 01:提现下发 02:供应商付款
 * @see DistributeTypeEnum
 */
private String distributeType;
```

**VO 字段**：取在线文档「返回参数」表的「变量名」+「说明」列，标注 `(doc key: xxx)` 以便与响应解析代码对照。

```java
/** 订单号 (doc key: order_no) */
private String orderNo;
/** 商盟订单号 (doc key: trade_no) — 成功时返回 */
private String tradeNo;
/** 支付状态 (doc key: status) — 0:失败 1:成功 2:处理中 */
private String status;
```

**接口方法**：注释包含接口编号、中文名称，加 `@see` 指向 service 枚举。

```java
/**
 * 2.42 直接下发
 * @see FxSettleServiceEnum#PAYMENT_DISTRIBUTE
 */
SumpayResult<SmDistributeResult> distribute(SmDistributeRequest request);
```

### 枚举字段处理

文档中标注为枚举值的字段（如 `id_type: 1-身份证 2-护照`），必须生成对应的 Java 枚举类：

**枚举类规范：**
- 放置于 `model/enums/` 包，与 `FxSettleServiceEnum` 同级
- 命名从字段名派生：`id_type` → `IdTypeEnum`，`business_type` → `BusinessTypeEnum`
- 每个枚举项包含 `code`（枚举值）和 `msg`（中文说明）
- 提供 `getByCode(String code)` 静态查找方法

```java
public enum IdTypeEnum {
    ID_CARD("1", "身份证"),
    PASSPORT("2", "护照"),
    // ... 按文档补全
    ;

    private final String code;
    private final String msg;

    IdTypeEnum(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }
    // getter + getByCode
}
```

**DTO 字段标注：**
DTO 中对应的枚举字段必须加 `@see` 注释指向枚举类：

```java
/** @see IdTypeEnum */
private String idType;
```

---

## 响应解析

响应的外层 key 名（如 `sumpay_distribute_response`）和内层字段名（如 `trade_no`、`order_no`）均以在线接口文档的返回参数定义为准，在第三步交叉比对时已提取到「已验证方法清单」中。

```java
if ("000000".equals(resp.get("resp_code"))) {
    XxxResult result = new XxxResult();
    // 外层 key 和内层字段名均从在线文档获取
    String responseJson = resp.get("文档中的响应key");
    if (responseJson != null) {
        Map respMap = JSON.parseObject(responseJson, Map.class);
        result.setXxx((String) respMap.get("文档中的字段名"));
    }
    return SumpayResult.success(result);
}
return SumpayResult.fail(resp.get("resp_code"), resp.get("resp_msg"));
```

首次调试时打印完整 resp，与文档对比确认 key 名一致。

---

## 用户对接指南

```java
@Autowired
private FxSettleService fxSettleService;

// 调用
XxxRequest req = new XxxRequest();
SumpayResult<XxxResult> result = fxSettleService.xxxMethod(req);

// 异步通知端点（添加在用户 Controller 中，地址与 notify_url 一致，必须公网可达）
@PostMapping("/sumpay/notify/distribute")
public String distributeNotify(@RequestParam Map<String, String> params) {
    return fxSettleService.handleDistributeNotify(params);
}
```
