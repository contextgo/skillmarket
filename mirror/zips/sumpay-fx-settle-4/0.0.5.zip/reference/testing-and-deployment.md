# 测试与部署

## 编译验证

**提示用户在终端执行以下命令验证编译（不要自动执行）：**

> 请在项目根目录执行：`mvn clean compile`

编译通过后，进入单元测试阶段。

## 单元测试

### 硬性要求：所有接口都必须编写单元测试，且测试必须通过

1. **每个接口都必须有对应的单元测试方法**，不可遗漏。本次接入的所有接口（查询类、写入类、异步通知）全部覆盖。
2. **测试必须实际运行并通过**。不是生成 @Disabled 的测试就结束，而是建议用户执行 `mvn test` 确认可通过。

### 测试分阶段执行

| 阶段 | 适用接口 | 要求 | 说明 |
|------|----------|------|------|
| 签名通信验证 | 查询类（2.2/2.4/2.10/2.43/2.45） | **必须通过** | 假数据即可验证签名通信，这是硬性门禁 |
| 写入类 | 写入类（2.1/2.3/2.9/2.40/2.42） | 必须生成，`@Disabled` | 需真实数据，生成测试框架代码，标注 TODO 占位 |
| 异步通知 | 通知类（2.41/2.44） | 必须生成，`@Disabled` | 模拟回调参数，验证参数解析逻辑 |

### 执行流程

```
Step 1: 提示用户执行 mvn clean compile（不要自动执行） → 编译通过
Step 2: 生成全部接口的单元测试       → 查询类启用，写入类/通知类 @Disabled
Step 3: 提示用户执行 mvn test（不要自动执行）          → 查询类测试必须全部通过
Step 4: 向用户报告测试结果          → 列出每个测试的状态和响应码
```

**查询类测试不通过 = 集成失败**，必须排查签名/证书/配置问题后重跑，直到全部通过。
写入类/异步通知因为需要真实业务数据，生成测试方法但标记 `@Disabled`，提醒用户替换数据后启用。

### 测试类结构

```java
@SpringBootTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class FxSettleServiceTest {
    @Autowired
    private FxSettleService fxSettleService;

    // ===== 签名通信验证（查询类，假数据即可）=====

    /**
     * 2.43 下发查询 — 假单号，预期 CRL120（签名通信正常）
     */
    @Test
    @Order(1)
    public void testQueryDistribute() {
        SmQueryDistributeRequest request = new SmQueryDistributeRequest();
        request.setOrderNo("TEST" + System.currentTimeMillis());
        SumpayResult<SmDistributeResult> result = fxSettleService.queryDistribute(request);
        assertNotNull(result);
        System.out.println("2.43 下发查询: respCode=" + result.getRespCode() + " respMsg=" + result.getRespMsg());
        assertNotEquals("888888", result.getRespCode(), "参数不合法，检查 sign_type/domain");
        assertNotEquals("EG000001", result.getRespCode(), "验签失败，检查证书");
    }

    /**
     * 2.45 材料查询 — 假流水号，预期 CCL038
     */
    @Test
    @Order(2)
    public void testQueryCollectFiles() {
        SmQueryCollectFilesRequest request = new SmQueryCollectFilesRequest();
        request.setMerSerialNo("TEST" + System.currentTimeMillis());
        SumpayResult<SmQueryCollectFilesResult> result = fxSettleService.queryCollectFiles(request);
        assertNotNull(result);
        System.out.println("2.45 材料查询: respCode=" + result.getRespCode() + " respMsg=" + result.getRespMsg());
        assertNotEquals("888888", result.getRespCode());
        assertNotEquals("EG000001", result.getRespCode());
    }

    /**
     * 2.46 财务明细 — 昨天日期，预期 EG200002（无数据）
     */
    @Test
    @Order(3)
    public void testDownloadFinancialDetail() {
        String yesterday = new SimpleDateFormat("yyyyMMdd")
                .format(new Date(System.currentTimeMillis() - 86400000L));
        SmFinancialDetailRequest request = new SmFinancialDetailRequest();
        request.setBillDate(yesterday);
        request.setPartNum("1");
        SumpayResult<SmFinancialDetailResult> result = fxSettleService.downloadFinancialDetail(request);
        assertNotNull(result);
        System.out.println("2.46 财务明细: respCode=" + result.getRespCode() + " respMsg=" + result.getRespMsg());
        assertNotEquals("888888", result.getRespCode());
        assertNotEquals("EG000001", result.getRespCode());
    }

    /**
     * 2.2 个人客户查询 — 假客户编号
     */
    @Test
    @Order(4)
    public void testQueryPersonalCustomer() {
        SmQueryPersonalCustomerRequest request = new SmQueryPersonalCustomerRequest();
        request.setCustomerNo("TEST_NOT_EXIST_" + System.currentTimeMillis());
        SumpayResult<SmQueryPersonalCustomerResult> result = fxSettleService.queryPersonalCustomer(request);
        assertNotNull(result);
        System.out.println("2.2 个人客户查询: respCode=" + result.getRespCode() + " respMsg=" + result.getRespMsg());
        assertNotEquals("888888", result.getRespCode());
        assertNotEquals("EG000001", result.getRespCode());
    }

    /**
     * 2.4 企业客户查询 — 假客户编号
     */
    @Test
    @Order(5)
    public void testQueryCompanyCustomer() {
        SmQueryCompanyCustomerRequest request = new SmQueryCompanyCustomerRequest();
        request.setCustomerNo("TEST_NOT_EXIST_" + System.currentTimeMillis());
        SumpayResult<SmQueryCompanyCustomerResult> result = fxSettleService.queryCompanyCustomer(request);
        assertNotNull(result);
        System.out.println("2.4 企业客户查询: respCode=" + result.getRespCode() + " respMsg=" + result.getRespMsg());
        assertNotEquals("888888", result.getRespCode());
        assertNotEquals("EG000001", result.getRespCode());
    }

    /**
     * 2.10 文件查询 — 假文件标识
     */
    @Test
    @Order(6)
    public void testQueryFiles() {
        SmQueryFilesRequest request = new SmQueryFilesRequest();
        request.setFileToken("TEST_NOT_EXIST_" + System.currentTimeMillis());
        SumpayResult<SmQueryFilesResult> result = fxSettleService.queryFiles(request);
        assertNotNull(result);
        System.out.println("2.10 文件查询: respCode=" + result.getRespCode() + " respMsg=" + result.getRespMsg());
        assertNotEquals("888888", result.getRespCode());
        assertNotEquals("EG000001", result.getRespCode());
    }

    // ===== 写入类接口（需要真实数据，@Disabled）=====

    /**
     * 2.1 个人客户报备
     * ⚠️ 需替换为真实身份数据后去掉 @Disabled
     */
    @Test
    @Order(10)
    @Disabled("需要真实身份数据，替换后启用")
    public void testAddPersonalCustomer() {
        SmPersonalCustomerRequest request = new SmPersonalCustomerRequest();
        request.setMerSerialNo("TEST" + System.currentTimeMillis());
        request.setRealname("TODO_REALNAME");          // TODO: 替换
        request.setIdType("1");
        request.setIdNo("TODO_ID_NO");                 // TODO: 替换
        request.setPlatformName("测试平台");
        request.setStoreUrl("https://example.com");

        SumpayResult<SmCustomerResult> result = fxSettleService.addPersonalCustomer(request);
        assertNotNull(result);
        System.out.println("2.1 个人客户: " + result.getRespCode() + " " + result.getRespMsg());
    }

    /**
     * 2.3 企业客户报备
     * ⚠️ 需替换为真实企业数据后去掉 @Disabled
     */
    @Test
    @Order(11)
    @Disabled("需要真实企业数据，替换后启用")
    public void testAddCompanyCustomer() {
        SmCompanyCustomerRequest request = new SmCompanyCustomerRequest();
        request.setMerSerialNo("TEST" + System.currentTimeMillis());
        request.setCompanyName("TODO_COMPANY");         // TODO: 替换
        request.setSocialCreditCode("TODO_CODE");       // TODO: 替换
        request.setBusinessScopeCode("110108");
        request.setIndustryAttributeCode("0314");
        request.setEconomyTypeCode("130");
        request.setSpecialEconomicZone("N");
        request.setCompanyAddress("浙江省杭州市");
        request.setCountryCode("CHN");

        SumpayResult<SmCustomerResult> result = fxSettleService.addCompanyCustomer(request);
        assertNotNull(result);
        System.out.println("2.3 企业客户: " + result.getRespCode() + " " + result.getRespMsg());
    }

    /**
     * 2.9 文件上传
     * ⚠️ 需准备真实文件后去掉 @Disabled
     */
    @Test
    @Order(12)
    @Disabled("需要真实文件，替换后启用")
    public void testUploadFile() {
        SmFileUploadRequest request = new SmFileUploadRequest();
        // TODO: 创建 MockMultipartFile
        request.setFileBatchNo("BATCH" + System.currentTimeMillis());
        request.setFileToken("TOKEN" + System.currentTimeMillis());
        request.setFileUse("01");

        SumpayResult<SmFileUploadResult> result = fxSettleService.uploadFile(request);
        assertNotNull(result);
        System.out.println("2.9 文件上传: " + result.getRespCode() + " " + result.getRespMsg());
    }

    /**
     * 2.40 材料上送
     * ⚠️ 需先完成客户报备+文件上传，获取 customer_no 和 sumpay_batch_no
     */
    @Test
    @Order(13)
    @Disabled("需要 customer_no + sumpay_batch_no，替换后启用")
    public void testUploadCollectFiles() {
        SmCollectFilesUploadRequest request = new SmCollectFilesUploadRequest();
        request.setMerSerialNo("TEST" + System.currentTimeMillis());
        SmCollectFilesUploadRequest.CollectDetailItem item = new SmCollectFilesUploadRequest.CollectDetailItem();
        item.setCustomerNo("TODO_CUSTOMER_NO");         // TODO: 替换
        item.setTradeType("03");
        item.setSumpayBatchNo("TODO_BATCH_NO");         // TODO: 替换
        request.setFiles(Collections.singletonList(item));

        SumpayResult<Void> result = fxSettleService.uploadCollectFiles(request);
        assertNotNull(result);
        System.out.println("2.40 材料上送: " + result.getRespCode() + " " + result.getRespMsg());
    }

    /**
     * 2.42 直接下发
     * ⚠️ 需先完成客户报备，获取 customer_no
     */
    @Test
    @Order(14)
    @Disabled("需要真实 customer_no，替换后启用")
    public void testDistribute() {
        SmDistributeRequest request = new SmDistributeRequest();
        request.setOrderNo("TEST" + System.currentTimeMillis());
        request.setCustomerNo("TODO_CUSTOMER_NO");      // TODO: 替换
        request.setDistributeType("01");
        request.setBusinessType("02");
        request.setOrderAmount("100.00");
        request.setAccountType("1");
        request.setRealname("TODO_NAME");               // TODO: 替换
        request.setAccountNo("TODO_ACCOUNT");           // TODO: 替换
        request.setIdType("1");
        request.setIdNo("TODO_ID_NO");                  // TODO: 替换
        request.setNeedNotify("1");

        SumpayResult<SmDistributeResult> result = fxSettleService.distribute(request);
        assertNotNull(result);
        System.out.println("2.42 直接下发: " + result.getRespCode() + " " + result.getRespMsg());
    }

    // ===== 异步通知（模拟回调参数，@Disabled）=====

    /**
     * 2.41 收款材料通知 — 模拟回调参数
     */
    @Test
    @Order(20)
    @Disabled("异步通知由商盟服务器回调，此处仅验证参数解析格式")
    public void testHandleCollectFilesNotify() {
        Map<String, String> params = new HashMap<>();
        params.put("mer_no", "200104913781");
        params.put("mer_serial_no", "TEST_SERIAL");
        params.put("customer_no", "TEST_CUSTOMER");
        params.put("notify_type", "03");
        params.put("status", "00");
        params.put("sign_type", "CERT");
        params.put("sign", "MOCK_SIGN");

        String response = fxSettleService.handleCollectFilesNotify(params);
        assertTrue(response.contains("\"resp_code\""));
        System.out.println("2.41 材料通知: " + response);
    }

    /**
     * 2.44 下发通知 — 模拟回调参数
     */
    @Test
    @Order(21)
    @Disabled("异步通知由商盟服务器回调，此处仅验证参数解析格式")
    public void testHandleDistributeNotify() {
        Map<String, String> params = new HashMap<>();
        params.put("mer_no", "200104913781");
        params.put("order_no", "TEST_ORDER");
        params.put("status", "1");
        params.put("order_amount", "100.00");
        params.put("sign_type", "CERT");
        params.put("sign", "MOCK_SIGN");

        String response = fxSettleService.handleDistributeNotify(params);
        assertTrue(response.contains("\"resp_code\""));
        System.out.println("2.44 下发通知: " + response);
    }
}
```

**提示用户在终端执行（不要自动执行）：**

> 请在项目根目录执行：`mvn test -Dtest=FxSettleServiceTest`

### 测试通过标准

**查询类测试必须全部通过：**

**提示用户在终端执行（不要自动执行）：**

> 请在项目根目录执行：`mvn test -Dtest=FxSettleServiceTest`

预期输出：
```
Tests run: 13, Failures: 0, Errors: 0, Skipped: 7
```

如果查询类测试有失败，**必须排查并修复**后重跑，不能跳过。常见问题：
- `EG000001` → 证书路径或密码错误
- `888888` → sign_type 误设或 domain 误设
- 连接超时 → 网络不通，检查代理/防火墙

**写入类/异步通知向用户报告的内容：**
```
✅ 签名通信验证：6/6 通过
⚠️ 写入类测试：5 个已生成（@Disabled），需替换以下数据后启用：
   - 2.1 个人客户：realname, id_no
   - 2.3 企业客户：company_name, social_credit_code
   - 2.9 文件上传：需准备真实文件
   - 2.40 材料上送：customer_no, sumpay_batch_no（依赖 2.1/2.9 的返回值）
   - 2.42 直接下发：customer_no（依赖 2.1 的返回值）
⚠️ 异步通知：2 个已生成（@Disabled），需公网回调端点就绪后启用
```

## 测试结果判定

| 响应码 | 含义 | 判定 |
|--------|------|------|
| `000000` | 成功 | 通过 |
| `CRL120` / `CCL038` / `EG200002` | 数据不存在 | 通过（签名正常） |
| `500` | 业务校验失败 | 通过（需真实数据） |
| `EG000001` | 验签失败 | **失败** — 检查证书 |
| `888888` | 参数不合法 | **失败** — 检查 sign_type/domain |

---

## 输出与配置提醒

集成完成后，**必须提醒用户**：

```
收结汇4.0 集成完成

新增文件:
  lib/merchant-integration-api-core.jar
  {pkg}/sumpay/config/SumpayFxSettleConfig.java
  {pkg}/sumpay/client/SumpayClient.java
  {pkg}/sumpay/model/dto/*.java + vo/*.java + enums/*.java
  {pkg}/sumpay/service/FxSettleService.java + impl/FxSettleServiceImpl.java
  {pkg}/sumpay/exception/SumpayFxSettleException.java
  src/test/{pkg}/sumpay/FxSettleServiceTest.java
  src/main/resources/cert/
修改文件:
  pom.xml + application.yml

⚠️ 必须修改的配置 (application.yml):
  - gateway-url, app-id, mer-no, cert-password
  - private-key-path, public-key-path
  - domain（仅文件上传用，生产必须与报备域名一致）
  - notify-base-url（必须公网可达）

⚠️ 必须实现:
  - handleDistributeNotify/handleCollectFilesNotify 幂等逻辑
  - Controller 中添加异步通知回调端点

⚠️ 打包注意:
  Spring Boot 打包插件需 <includeSystemScope>true</includeSystemScope>
```

## 生产上线检查清单

**安全：**
- [ ] 证书文件(.pfx/.cer) 加入 .gitignore，不提交仓库
- [ ] 证书密码使用环境变量：`cert-password: ${SUMPAY_CERT_PASSWORD}`
- [ ] 私钥证书限制文件读取权限

**网络：**
- [ ] notify-base-url 公网可达
- [ ] 服务器出方向 sumpay.cn 的 HTTPS(443) 已放行
- [ ] 商盟回调 IP 加入白名单

**功能：**
- [ ] 所有配置项已替换为生产值
- [ ] 幂等逻辑已实现
- [ ] 回调端点已添加且公网可达
- [ ] domain 与报备域名一致

**验证：**
- [ ] 单元测试通过（查询类全部通过）
- [ ] 完整业务流程跑通：客户报备 → 文件上传 → 材料上送 → 下发 → 对账
