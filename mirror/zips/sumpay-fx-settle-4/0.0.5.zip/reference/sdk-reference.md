# SDK 技术参考

## 环境规格

| 事项 | 规格 |
|------|------|
| 接口协议 | HTTPS POST + FORM，JSON 响应 |
| 测试环境 | `https://test.sumpay.cn/entrance/gateway.htm` |
| 生产环境 | `https://entrance.sumpay.cn/gateway.htm` |
| 签名方式 | CERT（SHA256withRSA，CFCA证书，PKCS12格式） |
| AES加密 | AES256/SM4，一次一密，密钥通过RSA公钥加密 |
| Base64编码 | terminal_info, longitude, latitude, notify_url, remark |
| 时间格式 | YYYYMMDDHHMMSS（东八区） |
| 金额单位 | **元**（不是分），最多两位小数 |

## 签名机制

1. 所有非空参数（除 sign、sign_type 外）按 key ASCII 升序排列
2. 拼接 `key1=value1&key2=value2`
3. 商户私钥 SHA256withRSA 签名 → Base64 → 放入 sign 字段

## service 名枚举

| 枚举 | service 值 |
|------|-----------|
| PERSONAL_CUSTOMER | `fosun.sumpay.api.crossborder.add.or.update.personal.customer` |
| QUERY_PERSONAL_CUSTOMER | `fosun.sumpay.api.crossborder.query.personal.customer.info` |
| COMPANY_CUSTOMER | `fosun.sumpay.api.crossborder.add.or.update.customer` |
| QUERY_COMPANY_CUSTOMER | `fosun.sumpay.api.crossborder.query.customer.info` |
| FILE_UPLOAD | `fosun.sumpay.api.crossborder.files.common.upload` |
| QUERY_FILES_COMMON | `fosun.sumpay.api.crossborder.query.files.common` |
| COLLECT_FILES_UPLOAD | `fosun.sumpay.api.crossborder.collect.files.upload` |
| PAYMENT_DISTRIBUTE | `fosun.sumpay.api.crossborder.payment.distribute` |
| DISTRIBUTE_SEARCH | `fosun.sumpay.api.crossborder.distribute.search` |
| COLLECT_FILES_QUERY | `fosun.sumpay.api.crossborder.collect.files.query` |
| BALANCE_FLOW | `fosun.sumpay.entrance.crossborder.get.balance.flow.file.url` |
| ELECTRONIC_RECEIPT | `fosun.sumpay.api.download.electronic.receipt` |

---

## Demo 映射表

Demo 文件从文档系统下载（见 SKILL.md「SDK 与 Demo 获取」），解压到临时目录后按相对路径读取。

### 核心接口

| 接口 | 接口名 | Demo 文件路径 | SDK Request 类 | 调用模式 |
|------|--------|--------------|----------------|----------|
| 2.1 | 个人客户信息上传 | `demo/.../CustRegReport/AddOrUpdatePersonalCustomer.java` | `AddOrUpdatePersonalCustomerRequest` | 模式 A（普通） |
| 2.2 | 查询个人客户信息 | `demo/.../CustRegReport/QueryPersonalCustomer.java` | `QueryPersonalCustomerRequest` | 模式 A（普通） |
| 2.3 | 企业客户信息上传 | `demo/.../CustRegReport/AddOrUpdateCustome.java` | `AddOrUpdateCustomerRequest` | 模式 D（文件上传+实体） |
| 2.4 | 查询企业客户信息 | `demo/.../CustRegReport/QueryCustomerInfo.java` | `QueryCustomerInfoRequest` | 模式 A（普通） |
| 2.9 | 文件上传 | `demo/.../FileUploadAndAppendix/FileUpload.java` | `FilesCommonUploadRequest` | 模式 B（文件上传） |
| 2.10 | 文件查询 | `demo/.../FileUploadAndAppendix/QueryFilesCommon.java` | `QueryFilesCommonRequest` | 模式 A（普通） |
| 2.40 | 收款材料上送 | `demo/.../FXSettleFour/CollectFilesUpload.java` | `CollectMaterialUploadRequest` | 模式 C（子参数） |
| 2.41 | 收款材料异步通知 | 无 Demo（异步通知） | — | — |
| 2.42 | 直接下发 | `demo/.../FXSettleFour/DirectDistribution.java` | `PaymentDistributeRequest` | 模式 A（普通） |
| 2.43 | 直接下发查询 | 无独立 Demo，参考 2.42 | `QueryPaymentDistributeRequest` | 模式 A（普通） |
| 2.44 | 直接下发异步通知 | 无 Demo（异步通知） | — | — |
| 2.45 | 收结汇4.0材料查询 | `demo/.../FXSettleFour/CollectFilesQuery.java` | `QueryCollectMaterialRequest` | 模式 A（普通） |

### 可选接口

| 接口 | 接口名 | Demo 文件路径 | SDK Request 类 | 调用模式 |
|------|--------|--------------|----------------|----------|
| 2.46 | 收结汇财务明细下载 | 无独立 Demo | `QueryTradeBillInfoRequest` | 模式 A（普通） |
| 2.29 | 下发电子回单下载 | 无 Demo | `GetElectronicReceiptUrlRequest` ⚠️ | 模式 A（普通） |

> ⚠️ `GetElectronicReceiptUrlRequest` 包路径为 `fosun.sumpay.merchant.integration.core.request.outer.common`（非 crossborder）

Demo 文件完整路径前缀（解压后）：`SMdemo/src/main/java/org/demo/CrossBorderProducts/FXSettle/`

---

## 已验证接口模式

以下模式由 Demo 源码和 javap 反编译交叉验证得出，代码生成时直接应用。

### 2.9 文件上传

**Demo 行为：**
- FileContext: `setFieldName("file")` + `setOriginalFilename(name)` + `setFileBytes(bytes)`
- **不调用** `req.setFile(fileContext)`
- 设置 `targetRequest.setDomain(...)` 和 `targetRequest.setUserMultipart(true)`
- 文件通过 `targetRequest.setFileParams(fileParams)` 传递

**javap 确认 FilesCommonUploadRequest setter：**
- setMer_no, setFile_batch_no, setFile_token, setFile_use, setFile(FileContext)
- ⚠️ setFile 存在但**不应调用**（会序列化进 JSON content）

### 2.40 收款材料上送

**Demo 行为：**
- 使用 SDK entity 类 `CollectDetailFile`（customer_no, trade_type, sumpay_batch_no）
- 子参数通过 `requestSubParams.put("[files", JSON.toJSONString(list))` — **key 是 `"[files"`**
- **不调用** `req.setFiles()`
- 设置 `targetRequest.setRequestSubParams(requestSubParams)`

**javap 确认 CollectMaterialUploadRequest setter：**
- setMer_no, setMer_serial_no, setNotify_url, setRemark, setFiles(String)
- ⚠️ setFiles 存在但 Demo 走 subParams，**以 Demo 为准**

**javap 确认 CollectDetailFile entity setter：**
- setCustomer_no, setTrade_type, setSumpay_batch_no

### 2.42 直接下发

**Demo 行为：**
- 标准 setter 调用
- 无文件上传、无子参数
- 不设置 domain

**javap 确认 PaymentDistributeRequest setter：**
- setMer_no, setOrder_no, setCustomer_no, setPayer_no, setDistribute_type, setBusiness_type, setOrder_amount, setAccount_type, setBank_code, setRealname, setBank_line_no, setAccount_no, setId_no, setId_type, setId_valid_date, setCard_type, setRemark, setMemo, setNeed_notify, setNotify_url
- ⚠️ 不存在 setDirectConnCut — 文档有此字段但 SDK 未实现，跳过

### 2.43 下发查询

**javap 确认 QueryPaymentDistributeRequest setter：**
- setMer_no, setOrder_no

### 2.45 材料查询

**Demo 行为：** 标准 setter 调用，无特殊处理

**javap 确认 QueryCollectMaterialRequest setter：**
- setMer_no, setMer_serial_no, setFiles(String)

### 2.46 收结汇财务明细下载

**javap 确认 QueryTradeBillInfoRequest setter：**
- setMer_no, setBill_date, setPart_num, setBill_file_type

### 2.29 下发电子回单下载

**javap 确认 GetElectronicReceiptUrlRequest setter：**
- setMer_no, setSub_mer_no, setOrder_no, setOrder_type, setVoucher_no
- ⚠️ 包路径为 `request.outer.common`（非 crossborder）

### 2.1 个人客户信息上传

**Demo 行为：**
- 标准 setter 调用
- Demo 设置了 domain，但 Critical Rules #2 说非文件上传不能设 domain → **遵守 Critical Rules，不设 domain**

**javap 确认 AddOrUpdatePersonalCustomerRequest setter：**
- setMer_no, setMer_serial_no, setCustomer_no, setCustomer_mer_no, setRealname, setId_no, setId_type, setId_start_end_time, setPlatform_name, setContact_person, setContact_phone, setStore_url, setRemark, setBusiness_type
- ⚠️ 不存在 setDirectConnCut — 跳过

### 2.2 查询个人客户信息

**Demo 行为：** 标准 setter 调用。Demo 设置了 domain → **遵守 Critical Rules，不设 domain**

**javap 确认 QueryPersonalCustomerRequest setter：**
- setMer_no, setCustomer_no, setMer_serial_no, setNotify_type

### 2.3 企业客户信息上传

**Demo 行为：**
- 标准 setter 调用 + 文件上传
- **不调用** `req.setFile(fileContext)`
- 文件通过 `targetRequest.setFileParams(fileParams)` 传递
- Demo 设置了 domain（文件上传场景）

**javap 确认 AddOrUpdateCustomerRequest setter：**
- setMer_no, setMer_serial_no, setCustomer_no, setCustomer_mer_no, setCompany_name, setSupervision_list_level, setSocial_credit_code, setBusiness_scope_code, setIndustry_attribute_code, setEconomy_type_code, setSpecial_economic_zone, setEnterprise_type, setCompany_address, setContact_person, setContact_phone, setPostcode, setInvestment_country, setCountry_code, setBank_code, setBank_city, setBank_branch_name, setBank_line_no, setAccount_name, setAccount_no, setCompany_abbreviation, setEnglish_company_name, setRegist_time, setBusiness_end_time, setBusiness_scope, setLegal_person_name, setLegal_person_id, setOrganization_type, setCustoms_registration_number, setRemark, setNotify_url, setBusiness_type, setFile(FileContext)
- ⚠️ setFile 存在但**不应调用**（会序列化进 JSON content）
- ⚠️ 不存在 setDirectConnCut — 跳过

### 2.4 查询企业客户信息

**Demo 行为：** 标准 setter 调用。Demo 设置了 domain → **遵守 Critical Rules，不设 domain**

**javap 确认 QueryCustomerInfoRequest setter：**
- setMer_no, setCustomer_no, setMer_serial_no

### 2.10 文件查询

**Demo 行为：** 标准 setter 调用。Demo 设置了 domain → **遵守 Critical Rules，不设 domain**

**javap 确认 QueryFilesCommonRequest setter：**
- setMer_no, setSumpay_token, setFile_token

---

## SDK 核心类路径

以下包路径必须精确使用。

**基础类（包 `fosun.sumpay.merchant.integration.core.request`）：**
- `MerchantBaseRequest` — 请求基类，提供 getAesEncodedWords() / getBase64EncodedWords() / getCharsetChangeWords()
- `Request` — SDK 请求包装（certType, content, password, privateKeyPath, url 等）

**上下文（包 `fosun.sumpay.merchant.integration.core.context`）：**
- `FileContext` — 文件上传上下文（setFileBytes/setOriginalFilename/setFieldName，**不是** setFile(MultipartFile)）

**服务（包 `fosun.sumpay.merchant.integration.core.service`，无 impl 子包）：**
- `SumpayServiceImpl` — 执行入口，execute(Request) → Map<String,String>
- `SignServiceImpl` — 签名/验签，verifyMsgNew() throws Exception

**SignServiceImpl 验签调用模式（javap + Demo Rsign.java 已验证）：**

```java
// 签名：signMsg(String plaintext, String privateKeyPath, String passWord, String charset, String certType)
// 验签：verifyMsgNew(String sign, String content, String publicKeyPath, String signType)

// 验签完整流程：
String sign = params.get("sign");
params.remove("sign");
params.remove("sign_type");
String content = ParamUtil.createLinkString(params);  // key升序拼接
boolean verified = new SignServiceImpl().verifyMsgNew(sign, content, publicKeyPath, "CERT");
// ⚠️ verifyMsgNew 抛 checked exception，必须 try-catch
```

**工具（包 `fosun.sumpay.merchant.integration.core.util`）：**
- `ParamUtil` — 参数排序拼接 createLinkString()

**接口请求类（包 `fosun.sumpay.merchant.integration.core.request.outer.crossborder`）：**

| 类 | 接口 | 包路径 |
|----|------|--------|
| `AddOrUpdatePersonalCustomerRequest` | 2.1 个人客户信息上传 | crossborder |
| `QueryPersonalCustomerRequest` | 2.2 查询个人客户信息 | crossborder |
| `AddOrUpdateCustomerRequest` | 2.3 企业客户信息上传 | crossborder |
| `QueryCustomerInfoRequest` | 2.4 查询企业客户信息 | crossborder |
| `FilesCommonUploadRequest` | 2.9 文件上传 | crossborder |
| `QueryFilesCommonRequest` | 2.10 文件查询 | crossborder |
| `CollectMaterialUploadRequest` | 2.40 收款材料上送 | crossborder |
| `PaymentDistributeRequest` | 2.42 直接下发 | crossborder |
| `QueryPaymentDistributeRequest` | 2.43 直接下发查询 | crossborder |
| `QueryCollectMaterialRequest` | 2.45 收结汇4.0材料查询 | crossborder |
| `QueryTradeBillInfoRequest` | 2.46 收结汇财务明细下载 | crossborder |
| `GetElectronicReceiptUrlRequest` | 2.29 下发电子回单下载 | **common** ⚠️ |

**Entity 类（包 `fosun.sumpay.merchant.integration.core.request.outer.crossborder.entity`）：**

| 类 | 用途 |
|----|------|
| `CollectDetailFile` | 2.40 材料上送的 files 子参数结构 |

### SumpayClient import

```java
import fosun.sumpay.merchant.integration.core.request.MerchantBaseRequest;
import fosun.sumpay.merchant.integration.core.request.Request;
import fosun.sumpay.merchant.integration.core.context.FileContext;
import fosun.sumpay.merchant.integration.core.service.SumpayServiceImpl;
import fosun.sumpay.merchant.integration.core.service.SignServiceImpl;
import fosun.sumpay.merchant.integration.core.util.ParamUtil;
```

### ServiceImpl import

```java
import fosun.sumpay.merchant.integration.core.request.outer.crossborder.*;
```

---

## 错误排查

### 业务错误码

| 错误码 | 含义 | 排查 |
|--------|------|------|
| `EG000001` | 验签失败 | 检查证书路径、密码、证书是否损坏 |
| `888888` | 参数不合法 | 检查 sign_type 是否误设；domain 是否在非上传接口设置；bizRequest 上是否设了 FileContext 字段 |
| `CRL120` / `CCL038` | 数据不存在 | 正常 — 签名通信已通 |
| `EG200002` | 对账数据不存在 | 正常 — 无交易数据 |
| `AM999998` | 参数校验出错 | 检查必填项、参数格式、枚举值 |
| `500` | 业务校验失败 | 需真实匹配数据 |

### 编译错误

| 错误 | 解决 |
|------|------|
| `找不到符号 MerchantBaseRequest` | `fosun.sumpay.merchant.integration.core.request.MerchantBaseRequest` |
| `找不到符号 Request` | `fosun.sumpay.merchant.integration.core.request.Request` |
| `找不到符号 FileContext` | `fosun.sumpay.merchant.integration.core.context.FileContext` |
| `找不到符号 SumpayServiceImpl` | `fosun.sumpay.merchant.integration.core.service.SumpayServiceImpl`（无 impl 子包） |
| `找不到符号 SignServiceImpl` | `fosun.sumpay.merchant.integration.core.service.SignServiceImpl`（无 impl 子包） |
| `未报告的异常 java.lang.Exception` | verifyMsgNew() 抛 checked exception，try-catch 包裹 |
| `NoClassDefFoundError: commons-lang3` | pom.xml 添加 commons-lang3:3.12.0 |
| `找不到符号 setXxx()` | javap -p ClassName.class 反编译确认实际字段名 |

### 运行时错误

| 错误现象 | 原因 | 解决 |
|----------|------|------|
| 888888 | sign_type 误设在 bizRequest 上 | 只通过 Request.setCertType("CERT") 设置 |
| 888888 | domain 在非文件上传接口设置 | 只在有 fileParams 时设 domain |
| 请求体包含 FileContext JSON | 在 bizRequest 上调了 setFile() | 文件只通过 fileParams 传递 |
| files 子参数丢失 | subParams key 用了 "files" | 改为 "[files"（以 Demo 为准） |
