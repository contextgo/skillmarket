# SDK 集成指南

## 下载 SDK

SDK 从文档系统动态获取，下载方式见 [resource-download.md](resource-download.md)。

## Maven 项目

1. 在项目根目录创建 `lib/` 目录，复制下载的 SDK JAR：
   ```bash
   mkdir -p lib
   cp merchant-integration-api-core.jar lib/
   ```

2. pom.xml 添加依赖：
   ```xml
   <dependency>
       <groupId>fosun.sumpay</groupId>
       <artifactId>merchant-integration-api-core</artifactId>
       <version>1.0.0</version>
       <scope>system</scope>
       <systemPath>${project.basedir}/lib/merchant-integration-api-core.jar</systemPath>
   </dependency>
   ```

3. 确认必要的依赖（如不存在则添加）：
   ```xml
   <dependency>
       <groupId>com.alibaba</groupId>
       <artifactId>fastjson</artifactId>
       <version>1.2.83</version>
   </dependency>
   <dependency>
       <groupId>org.apache.httpcomponents</groupId>
       <artifactId>httpclient</artifactId>
       <version>4.5.13</version>
   </dependency>
   <dependency>
       <groupId>org.apache.httpcomponents</groupId>
       <artifactId>httpmime</artifactId>
       <version>4.5.13</version>
   </dependency>
   <dependency>
       <groupId>org.bouncycastle</groupId>
       <artifactId>bcprov-jdk15on</artifactId>
       <version>1.68</version>
   </dependency>
   <!-- SDK 隐式依赖，缺少会 NoClassDefFoundError -->
   <dependency>
       <groupId>org.apache.commons</groupId>
       <artifactId>commons-lang3</artifactId>
       <version>3.12.0</version>
   </dependency>
   ```

4. Spring Boot 打包插件需添加：
   ```xml
   <configuration>
       <includeSystemScope>true</includeSystemScope>
   </configuration>
   ```

5. surefire 插件必须指定版本（默认 2.12.4 不支持 JUnit 5，测试会注入 null）：
   ```xml
   <plugin>
       <groupId>org.apache.maven.plugins</groupId>
       <artifactId>maven-surefire-plugin</artifactId>
       <version>2.22.2</version>
   </plugin>
   ```

## Gradle 项目

```groovy
implementation files('lib/merchant-integration-api-core.jar')
implementation 'com.alibaba:fastjson:1.2.83'
implementation 'org.apache.httpcomponents:httpclient:4.5.13'
implementation 'org.apache.httpcomponents:httpmime:4.5.13'
implementation 'org.bouncycastle:bcprov-jdk15on:1.68'
implementation 'org.apache.commons:commons-lang3:3.12.0'
```

## 测试证书

测试证书的下载方式见 [resource-download.md](resource-download.md)。

生产环境替换为真实证书，并将证书文件加入 `.gitignore`。
