# 资源获取

SDK、Demo、测试证书、在线接口文档均从商盟文档系统动态获取。所有操作依赖用户提供的 Token。

## 文档系统 API

```bash
# 获取目录树（入口）
curl -s -H "Authorization: Bearer {TOKEN}" \
  "https://doc.sumpay.cn/api/public/doc/catalogTree?projectId=1000000002"

# 获取页面详情（catalogId 从目录树中提取）
curl -s -H "Authorization: Bearer {TOKEN}" \
  "https://doc.sumpay.cn/api/public/doc/page/detail?catalogId={catalogId}"

# 下载附件（filePath 从页面详情的 attachmentList 中提取）
# ⚠️ filePath 含中文必须 URL 编码，直接 curl 中文路径会 400
curl -s -L -H "Authorization: Bearer {TOKEN}" -o {filename} \
  "https://doc.sumpay.cn/api/public/doc/download?filePath={URL编码后的path}"
```

## 通用流程

1. 拉取目录树，识别目标 catalogId
2. 请求页面详情，从 `data.attachmentList` 提取 filePath
3. URL 编码 filePath 后下载
4. 下载后校验 SHA256，与下方「资源校验」表对比，不一致则终止并提示用户联系商盟技术支持

---

## 目录树 catalogId 映射

从目录树中识别以下 catalogId，后续步骤按需使用：

| 目录位置 | 用途 | 使用时机 |
|----------|------|----------|
| 「开发资源」或「SDK下载」 | 下载 SDK 和 Demo | 第二步：集成 SDK |
| 「开发规范」→「安全规范」 | 下载测试证书 | 第五步：编译与测试 |
| 各接口页面（如「个人客户信息上传」） | 拉取接口字段定义 | 第三步：SDK 验证 |

---

## SDK 与 Demo 下载

使用「开发资源」的 catalogId：

```bash
# 1. 请求页面详情
curl -s -H "Authorization: Bearer {TOKEN}" \
  "https://doc.sumpay.cn/api/public/doc/page/detail?catalogId={catalogId}"
# 2. 从 data.attachmentList 中提取 filePath（SDK 和 Demo 各一个附件）
# 3. 下载
curl -s -L -H "Authorization: Bearer {TOKEN}" -o sdk.zip \
  "https://doc.sumpay.cn/api/public/doc/download?filePath={SDK的URL编码后的path}"
curl -s -L -H "Authorization: Bearer {TOKEN}" -o demo.zip \
  "https://doc.sumpay.cn/api/public/doc/download?filePath={Demo的URL编码后的path}"
# 4. 解压 SDK JAR 到项目 lib/，解压 Demo 到临时目录供第三步读取
```

---

## 测试证书下载

使用「安全规范」的 catalogId：

```bash
# 1. 请求页面详情
curl -s -H "Authorization: Bearer {TOKEN}" \
  "https://doc.sumpay.cn/api/public/doc/page/detail?catalogId={catalogId}"
# 2. 从 data.attachmentList[0].attachmentPath 取证书路径
# 3. 下载
curl -s -L -H "Authorization: Bearer {TOKEN}" -o cert.zip \
  "https://doc.sumpay.cn/api/public/doc/download?filePath={URL编码后的path}"
# 4. 解压到 src/main/resources/cert/
```

证书内含私钥证书（.pfx）、公钥证书（.cer）和密码文件。生产环境替换为真实证书，并将证书文件加入 `.gitignore`。

---

## 在线接口文档

使用各接口页面的 catalogId：

```bash
curl -s -H "Authorization: Bearer {TOKEN}" \
  "https://doc.sumpay.cn/api/public/doc/page/detail?catalogId={catalogId}"
```

返回的 `data.content` 包含接口字段定义（请求参数、返回参数、枚举值等），用于第三步交叉比对。

---

## 资源校验

下载完成后，对每个文件计算 SHA256 并与下表对比。校验不通过说明文档系统资源已更新，需重新验证 SDK 接口。

| 文件 | 大小 | SHA256 |
|------|------|--------|
| SDK (merchant-integration-api-core.jar) | 402627 | `4abaa19b4062c3cdcb822d290aab97227eb8e02a0c8abf9b5e14965a9fea1542` |
| Demo (SMdemo.zip) | 768706 | `f7cbe889307dc133f0186fa2d46d5e2d7481a580435a33fc34f38419ca485fce` |
| 测试证书 (商盟测试证书.zip) | 6372 | `540cff120135fb8595d44cfef3ac635d82c1c57f28dfa8c525a98e7c4445ad16` |

证书解压后内部文件：

| 文件 | SHA256 |
|------|--------|
| yixuntiankong.pfx (私钥) | `38eceb54bcd4ae46e53bf6b71f4212be96e67c24e562b08bce24333fe652f291` |
| yixun.cer (公钥) | `bdb89319407b81b259df0a0cd00af6ffb1015deeb3ece9167dccd722877bf4bc` |

> **注意：** 上述校验值基于 2026-04-23 文档系统版本。若商盟更新了 SDK/Demo/证书，校验将不通过，此时需重新执行 javap 验证和 Demo 交叉比对。
