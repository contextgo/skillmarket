# 数据字典

> 本文档说明 `data/plot-image-mapping.json` 的数据结构，以及如何添加新角色或新剧情节点。

---

## 一、数据结构总览

```json
{
  "version": "1.0",
  "gameTitle": "碧海传图纸",
  "assetsBasePath": "./assets",

  "plotMapping": { ... },      // 剧情节点映射
  "characterAssets": { ... },  // 角色资产
  "sceneAssets": { ... }      // 场景资产
}
```

---

## 二、plotMapping（剧情节点映射）

### 作用
定义每个剧情节点的**触发条件**和**对应图片**，供AI运行时查询并推送图片。

### 节点结构

```json
"剧情锁节点X_节点名称": {
  "nodeId": 1,                    // 节点序号（唯一）
  "nodeName": "节点名称",          // 节点名称
  "triggerConditions": {            // 触发条件
    "scene": ["S01"],              // 场景ID列表
    "characters": ["C01_朱尾", "C03_朱袈"]  // 角色ID列表
  },
  "images": {                      // 对应图片
    "scene": "场景图.png",          // 场景图文件名
    "characters": ["角色1.png", "角色2.png"]  // 角色图文件名列表
  }
}
```

### 添加新节点

在 `plotMapping` 中新增条目：

```json
"剧情锁节点17_新节点": {
  "nodeId": 17,
  "nodeName": "新节点名称",
  "triggerConditions": {
    "scene": ["S02"],
    "characters": ["C01_朱尾", "C07_刘戏蟾"]
  },
  "images": {
    "scene": "京城街口.png",
    "characters": ["朱尾.png", "刘戏蟾.png"]
  }
}
```

**注意**：
- `nodeId` 必须唯一，不能与现有节点重复
- `scene` 必须是 `sceneAssets` 中已定义的场景ID
- `characters` 必须是 `characterAssets` 中已定义的角色的ID
- `images.scene` 必须是 `assets/scene/` 目录下存在的文件
- `images.characters` 必须是 `assets/character/` 目录下存在的文件

---

## 三、characterAssets（角色资产）

### 作用
定义所有角色的ID、名称、等级和图片文件路径。

### 结构

```json
"C01_朱尾": {
  "name": "朱尾",      // 角色显示名称
  "grade": "S",        // 角色等级：S/A/B
  "file": "朱尾.png"   // 对应图片文件名
}
```

### 添加新角色

**步骤1**：在 `characterAssets` 中添加：

```json
"C13_新角色": {
  "name": "新角色名称",
  "grade": "B",
  "file": "新角色.png"
}
```

**步骤2**：将角色图片放入 `assets/character/新角色.png`

**步骤3**：在 `reference/characters.md` 中添加角色详细人设

**命名规范**：
- ID格式：`C{序号}_{角色名}`，如 `C13_新角色`
- 序号使用两位数字，如01、02...13
- 角色名用中文，不能重复

### 角色ID对照表

| ID | 名称 | 等级 |
|----|------|------|
| C01_朱尾 | 朱尾 | S |
| C02_陌上春 | 陌上春 | S |
| C03_朱袈 | 朱袈 | A |
| C04_朱裟 | 朱裟 | A |
| C05_白音 | 白音 | B |
| C06_刘徽 | 刘徽 | A |
| C07_刘戏蟾 | 刘戏蟾 | B |
| C08_靖国公 | 靖国公莫麒 | A |
| C09_徐灵胎 | 徐灵胎 | B |
| C10_秦桑 | 秦桑 | B |
| C11_倚天 | 倚天 | S |
| C12_朱镝 | 朱镝 | A |

---

## 四、sceneAssets（场景资产）

### 作用
定义所有场景的ID、名称、等级和图片文件路径。

### 结构

```json
"S01": {
  "name": "近海战场·血染碧波",  // 场景显示名称
  "grade": "S",                  // 场景等级：S/A/B
  "file": "金海战场.png"          // 对应图片文件名
}
```

### 添加新场景

**步骤1**：在 `sceneAssets` 中添加：

```json
"S12_新场景": {
  "name": "新场景名称",
  "grade": "B",
  "file": "新场景.png"
}
```

**步骤2**：将场景图片放入 `assets/scene/新场景.png`

**命名规范**：
- ID格式：`S{序号}`，如 `S12`
- 序号使用两位数字，从01开始递增

### 场景ID对照表

| ID | 名称 | 等级 |
|----|------|------|
| S01 | 近海战场·血染碧波 | S |
| S02 | 京城街口·初入京师 | A |
| S03 | 客栈门前·囊中羞涩 | A |
| S04 | 靖国府·湖心岛别院 | S |
| S05 | 靖国府内室·病榻前的照料 | A |
| S06 | 董记当铺·暗藏玄机 | B |
| S07 | 法严寺·古刹寻兄 | S |
| S08 | 湖心岛·月下逃亡 | A |
| S09 | 水下密室·定情之约 | S |
| S10 | 凤还楼·最终决战 | S |
| S11 | 海港重逢·家人团聚 | S |

---

## 五、添加新剧情的完整流程

当需要添加一个新剧情节点时，需要同步更新以下文件：

### 1. 新增图片资产

```
assets/
├── character/新角色.png   (如有新角色)
└── scene/新场景.png       (如有新场景)
```

### 2. 更新 data/plot-image-mapping.json

```json
{
  "characterAssets": {
    "C13_新角色": { ... }   // 新增角色定义
  },
  "sceneAssets": {
    "S12_新场景": { ... }   // 新增场景定义
  },
  "plotMapping": {
    "剧情锁节点17_新剧情": {
      "nodeId": 17,
      "nodeName": "新剧情",
      "triggerConditions": {
        "scene": ["S12_新场景"],
        "characters": ["C01_朱尾", "C13_新角色"]
      },
      "images": {
        "scene": "新场景.png",
        "characters": ["朱尾.png", "新角色.png"]
      }
    }
  }
}
```

### 3. 更新 reference/plot-nodes.md

在文档中添加新节点的完整叙事：

```markdown
## 节点17：新剧情

**场景**：新场景名称
**登场角色**：朱尾、新角色

[完整叙事描写...]
```

### 4. 更新 SKILL.md 剧情锁表格

在主线关键节点表格中新增一行：

```markdown
| 17 | **新剧情** | 新场景名称 | 朱尾、新角色 |
```

### 5. 更新 reference/characters.md（如有新角色）

添加新角色的详细人设信息。

---

## 六、修改检查清单

添加/修改剧情节点时，逐一检查：

- [ ] `assets/character/` 目录下图片是否存在
- [ ] `assets/scene/` 目录下图片是否存在
- [ ] `characterAssets` 中角色ID是否唯一
- [ ] `sceneAssets` 中场景ID是否唯一
- [ ] `plotMapping` 中 `nodeId` 是否唯一
- [ ] `triggerConditions.scene` 引用的场景ID是否存在
- [ ] `triggerConditions.characters` 引用的角色ID是否存在
- [ ] `reference/plot-nodes.md` 中是否添加了节点叙事
- [ ] `SKILL.md` 主线关键节点表格是否已更新
