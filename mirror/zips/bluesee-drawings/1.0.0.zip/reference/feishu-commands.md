# 飞书发送命令详解

> 本文档包含飞书发送图片的完整命令格式和示例。

---

## 关键规则

**⚠️ 必须先将图片文件拷贝到 `/tmp/openclaw/` 目录才能发送！**

---

## 发送流程

```
1. 拷贝图片到允许目录
   cp {图片路径} /tmp/openclaw/

2. 使用 openclaw 发送图片
   openclaw message send \
     --channel feishu \
     --account default \
     --target "{用户飞书ID}" \
     --media "/tmp/openclaw/{图片文件名}" \
     -m "{消息文字}"
```

---

## 命令参数说明

| 参数 | 说明 |
|------|------|
| `--channel feishu` | 指定飞书渠道 |
| `--account default` | 使用默认账号 |
| `--target "{飞书ID}"` | 发送目标用户的飞书ID |
| `--media "{路径}"` | 图片文件路径（必须在/tmp/openclaw/下） |
| `-m "{消息}"` | 随图片发送的文字消息 |

---

## 示例命令

```bash
# 复制图片到允许目录
cp /Users/libaoquan/Documents/Agent Stuff/openclawd/dongfang/skills/bluesee-drawings/assets/scene/金海战场.png /tmp/openclaw/

# 发送场景图片到飞书
openclaw message send \
  --channel feishu \
  --account default \
  --target "ou_130d65fca2bc42e2fd08e4bd539d6c04" \
  --media "/tmp/openclaw/金海战场.png" \
  -m "【场景】近海战场·血染碧波"
```

---

## 飞书用户ID

| 用户 | 飞书ID |
|------|--------|
| 张三 | `ou_130d65fca2bc42e2fd08e4bd539d6c04` |

---

## 图片展示格式

```
═══════════════════════════════════════════
【场景】
[场景图：京口街口·初入京师]

【登场角色】
[角色图：朱尾] [角色图：白音]
═══════════════════════════════════════════
```

---

## 场景图与角色图对照表

| 节点 | 节点名称 | 场景图 | 登场角色图 |
|------|---------|--------|-----------|
| 1 | 海上突围 | 金海战场.png | 朱尾.png, 朱袈.png |
| 2 | 入靖国府 | 湖心岛.png | 朱尾.png, 陌上春.png |
| 3 | 误会初结 | 靖国府室内.png | 朱尾.png, 陌上春.png, 白音.png |
| 4 | 师父救场 | 董记当铺.png | 刘徽.png, 陌上春.png |
| 5 | 情愫渐生 | 靖国府室内.png | 朱尾.png, 陌上春.png |
| 6 | 归还玉璧 | 靖国府.png | 朱尾.png, 陌上春.png, 白音.png |
| 7 | 图纸损毁 | 靖国府.png | 朱尾.png |
| 8 | 重绘图纸 | 靖国府室内.png | 朱尾.png, 陌上春.png, 靖国公莫麒.png |
| 9 | 湖心岛密室 | 水下密室.png | 朱尾.png, 陌上春.png |
| 10 | 身份暴露 | 湖心岛.png | 朱尾.png, 白音.png, 倚天.png |
| 11 | 朱裟相助 | 法严寺.png | 朱尾.png, 朱裟.png |
| 12 | 图纸送京 | 京城街口.png | 朱尾.png |
| 13 | 朱尾被抓 | 凤还楼.png | 朱尾.png, 倚天.png |
| 14 | 最终决战 | 凤还楼.png | 陌上春.png, 倚天.png, 刘徽.png |
| 15 | 家人团聚 | 海港重逢.png | 朱尾.png, 朱镝.png, 朱袈.png |
| 16 | 定亲大结局 | 海港重逢.png | 朱尾.png, 陌上春.png, 朱镝.png |

---

## 发图规则

1. 每进入新节点，先发送该节点的**场景图**
2. 该节点的**所有登场角色图**按顺序发送
3. 已出现过的角色不重复发送（仅新角色首次登场时发送）
