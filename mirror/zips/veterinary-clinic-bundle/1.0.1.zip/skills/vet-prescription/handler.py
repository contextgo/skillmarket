"""
处方模板管理 - 技能处理器
触发词: 开处方, 处方
"""


def handle(message: str, config: dict) -> str:
    """
    处理用户消息

    Args:
        message: 用户输入的消息
        config: 诊所配置

    Returns:
        str: AI回复内容
    """
    # TODO: 实现具体逻辑
    return f"[处方模板管理] 功能开发中..."
