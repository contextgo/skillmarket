/**
 * Markdown Parser for Eisenhower Task Manager
 * Parses tasks.md, customer-projects.md, delegation.md, maybe.md
 */

const fs = require('fs');
const path = require('path');

// Tasks are located in workspace/tasks/ directory (4 levels up from dashboard)
const TASKS_DIR = path.join(__dirname, '../../../tasks');

/**
 * Parse tasks.md - Four Quadrants Format
 */
function parseTasks(content) {
  const result = {
    q1: [],
    q2: [],
    q3: [],
    q4: [],
    stats: { q1: 0, q2: 0, q3: 0, q4: 0, total: 0 }
  };

  // Stats will be calculated based on actual parsed tasks (more accurate than header text)

  // Split by quadrants - support both half-width () and full-width () parentheses
  const q1Match = content.match(/## 🔥 Q1[\s\S]*?(?=## 💼 Q2|$)/);
  const q2Match = content.match(/## 💼 Q2[\s\S]*?(?=## ⚡ Q3|$)/);
  const q3Match = content.match(/## ⚡ Q3[\s\S]*?(?=## 🧘 Q4|$)/);
  const q4Match = content.match(/## 🧘 Q4[\s\S]*?(?=## 👑|$)/);

  if (q1Match) result.q1 = parseQuadrantTasks(q1Match[0], 'Q1');
  if (q2Match) result.q2 = parseQuadrantTasks(q2Match[0], 'Q2');
  if (q3Match) result.q3 = parseQuadrantTasks(q3Match[0], 'Q3');
  if (q4Match) result.q4 = parseQuadrantTasks(q4Match[0], 'Q4');

  // Calculate stats based on actual parsed tasks (more accurate than header text)
  result.stats.q1 = result.q1.length;
  result.stats.q2 = result.q2.length;
  result.stats.q3 = result.q3.length;
  result.stats.q4 = result.q4.length;
  result.stats.total = result.q1.length + result.q2.length + result.q3.length + result.q4.length;

  return result;
}

function parseQuadrantTasks(content, quadrant) {
  const tasks = [];
  // Match task sections: ### X. Task Name [tags]
  const taskRegex = /### (\d+)\.\s*(.+?)(?:\s*\[([^\]]+)\])?\n([\s\S]*?)(?=### \d+\.|## |\n## |\n---|$)/g;

  let match;
  while ((match = taskRegex.exec(content)) !== null) {
    const taskContent = match[4];
    const task = {
      id: parseInt(match[1]),
      title: match[2].trim(),
      tags: match[3] ? match[3].split('/').map(t => t.trim()) : [],
      quadrant: quadrant,
      status: extractStatus(taskContent),
      priority: extractPriority(taskContent),
      description: extractDescription(taskContent),
      created: extractDate(taskContent, '创建'),
      updated: extractDate(taskContent, '更新'),
      blocked: taskContent.includes('🚫') || taskContent.includes('阻塞'),
      subtasks: extractSubtasks(taskContent),
      raw: match[0]
    };
    tasks.push(task);
  }

  return tasks;
}

function extractStatus(content) {
  const statusMatch = content.match(/\*\*状态\*\*:(.+)/);
  if (statusMatch) {
    const status = statusMatch[1].trim();
    if (status.includes('P0')) return 'P0';
    if (status.includes('P1')) return 'P1';
    if (status.includes('P2')) return 'P2';
    return status;
  }
  return '';
}

function extractPriority(content) {
  if (content.includes('P0')) return 'P0';
  if (content.includes('P1')) return 'P1';
  if (content.includes('P2')) return 'P2';
  return '';
}

function extractDescription(content) {
  const descMatch = content.match(/\*\*描述\*\*:(.+)/);
  return descMatch ? descMatch[1].trim() : '';
}

function extractDate(content, type) {
  const dateMatch = content.match(new RegExp(`\\*\\*${type}\\*\\*:(.+)`));
  return dateMatch ? dateMatch[1].trim() : '';
}

function extractSubtasks(content) {
  const subtasks = [];
  const subtaskRegex = /-\s*\*\*(.+?)\*\*\n([\s\S]*?)(?=\n\s*-\s*\*\*|\n### |\n## |$)/g;

  let match;
  while ((match = subtaskRegex.exec(content)) !== null) {
    subtasks.push({
      title: match[1].trim(),
      content: match[2].trim()
    });
  }

  return subtasks;
}

/**
 * Parse customer-projects.md - Customer Project List Format
 */
function parseCustomerProjects(content) {
  const result = {
    customers: [],
    stats: { active: 0, blocked: 0, pending: 0, total: 0 }
  };

  // Extract stats from overview table (support both Chinese and English)
  const activeMatch = content.match(/🟢\s*(?:Active|进行中)\s*\|\s*(\d+)/);
  const blockedMatch = content.match(/🟡\s*(?:Blocked|阻塞中|阻塞)\s*\|\s*(\d+)/);
  const pendingMatch = content.match(/🔵\s*(?:Pending|待开始)\s*\|\s*(\d+)/);
  const totalMatch = content.match(/\*\*\s*(?:Total|总计)\s*\*\*\s*\|\s*\*\*(\d+)\*\*/);

  if (activeMatch) result.stats.active = parseInt(activeMatch[1]);
  if (blockedMatch) result.stats.blocked = parseInt(blockedMatch[1]);
  if (pendingMatch) result.stats.pending = parseInt(pendingMatch[1]);
  if (totalMatch) result.stats.total = parseInt(totalMatch[1]);

  // Parse customers and their projects
  // Support format: ### 🔴 优先级1：Name (Chinese colon)
  // Note: Emoji is 2 UTF-16 code units (surrogate pair)
  // Use split parsing: first find customer headers, then extract sections manually
  const customerHeaders = Array.from(content.matchAll(/^###\s+(.{1,2})\s+优先级[\d一二三四五]+[：:](.+)$/gmu));

  for (let i = 0; i < customerHeaders.length; i++) {
    const headerMatch = customerHeaders[i];
    const startPos = headerMatch.index + headerMatch[0].length;
    const endPos = i < customerHeaders.length - 1 ? customerHeaders[i + 1].index : content.length;
    const section = content.substring(startPos, endPos);

    const customer = {
      name: headerMatch[2].trim(),
      priority: headerMatch[1].trim(),
      projects: []
    };

    // Parse projects within customer section
    // Match #### (project level)
    const projectRegex = /^#### (\d+)\.\s*(.+?)\n/gm;
    let projMatch;
    while ((projMatch = projectRegex.exec(section)) !== null) {
      const projStart = projMatch.index + projMatch[0].length;
      // Find where this project ends (next #### or end of section)
      const nextProjMatch = /^#### \d+\./m.exec(section.substring(projStart));
      const projEnd = nextProjMatch ? projStart + nextProjMatch.index : section.length;
      const projContent = section.substring(projStart, projEnd);

      const project = {
        id: parseInt(projMatch[1]),
        name: projMatch[2].trim(),
        status: extractField(projContent, '状态') || extractField(projContent, 'Status'),
        type: extractField(projContent, '类型') || extractField(projContent, 'Type'),
        priority: extractField(projContent, '优先级') || extractField(projContent, 'Priority'),
        created: extractField(projContent, '创建时间') || extractField(projContent, 'Created'),
        lastReview: extractField(projContent, '上次回顾') || extractField(projContent, 'Last Review'),
        nextReview: extractField(projContent, '下次检查') || extractField(projContent, 'Next Review'),
        notes: extractField(projContent, '备注') || extractField(projContent, 'Notes'),
        quadrantTask: extractField(projContent, '象限任务') || extractField(projContent, 'Quadrant Task'),
        blocked: projContent.includes('🟡') || projContent.includes('阻塞')
      };
      customer.projects.push(project);
    }

    result.customers.push(customer);
  }

  return result;
}

function extractField(content, fieldName) {
  // Escape special regex characters in fieldName
  const escapedFieldName = fieldName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  // Support Chinese colon (:) - the document uses Chinese colons
  const regex = new RegExp(`- \\*\\*${escapedFieldName}\\*\\*:(.+)`, 'im');
  const match = content.match(regex);
  return match ? match[1].trim() : '';
}

/**
 * Parse delegation.md - Delegation List Format
 */
function parseDelegation(content) {
  const result = {
    tasks: [],
    stats: { total: 0, inProgress: 0, delegated: 0, overdue: 0 }
  };

  // Extract total count
  const totalMatch = content.match(/总任务数:(\d+) 个/);
  if (totalMatch) result.stats.total = parseInt(totalMatch[1]);

  // Parse delegation tasks
  const taskRegex = /#### (\d+)\.\s*(.+?)\n([\s\S]*?)(?=#### \d+\.|## |\n---|$)/g;

  let match;
  while ((match = taskRegex.exec(content)) !== null) {
    const taskContent = match[3];
    const task = {
      id: parseInt(match[1]),
      title: match[2].trim(),
      status: extractField(taskContent, '状态'),
      assignee: extractAssignee(taskContent),
      description: extractField(taskContent, '说明'),
      deadline: extractField(taskContent, 'Deadline'),
      created: extractField(taskContent, '创建时间'),
      lastReview: extractField(taskContent, 'Last Review'),
      nextReview: extractField(taskContent, 'Next Review'),
      overdue: taskContent.includes('⚠️') || taskContent.includes('已过期'),
      raw: match[0]
    };
    result.tasks.push(task);
  }

  // Calculate stats based on actual parsed tasks
  result.stats.total = result.tasks.length;
  result.stats.inProgress = result.tasks.filter(t => t.status === '进行中').length;
  result.stats.delegated = result.tasks.filter(t => t.status === '待开始').length;
  result.stats.overdue = result.tasks.filter(t => t.overdue).length;

  return result;
}

function extractAssignee(content) {
  const match = content.match(/\*\*责任人\*\*:(.+)/);
  return match ? match[1].trim() : '';
}

/**
 * Parse maybe.md - Maybe List Format
 */
function parseMaybeList(content) {
  const result = {
    tasks: [],
    stats: { total: 0 }
  };

  // Parse maybe tasks
  const taskRegex = /#### (\d+)\.\s*(.+?)\n([\s\S]*?)(?=#### \d+\.|## |\n---|$)/g;

  let match;
  while ((match = taskRegex.exec(content)) !== null) {
    const taskContent = match[3];
    const task = {
      id: parseInt(match[1]),
      title: match[2].trim(),
      status: extractField(taskContent, '状态'),
      description: extractField(taskContent, '说明'),
      created: extractField(taskContent, '创建时间'),
      category: extractCategory(taskContent),
      raw: match[0]
    };
    result.tasks.push(task);
  }

  // Calculate stats based on actual parsed tasks
  result.stats.total = result.tasks.length;

  return result;
}

function extractCategory(content) {
  const match = content.match(/【(.+?)】/);
  return match ? match[1] : '其他';
}

/**
 * Load and parse all task files
 */
function loadAllTasks() {
  const data = {
    timestamp: new Date().toISOString()
  };

  try {
    const tasksContent = fs.readFileSync(path.join(TASKS_DIR, 'tasks.md'), 'utf8');
    data.tasks = parseTasks(tasksContent);
  } catch (e) {
    data.tasks = { error: e.message, q1: [], q2: [], q3: [], q4: [], stats: {} };
  }

  try {
    const customerContent = fs.readFileSync(path.join(TASKS_DIR, 'customer-projects.md'), 'utf8');
    data.customerProjects = parseCustomerProjects(customerContent);
  } catch (e) {
    data.customerProjects = { error: e.message, customers: [], stats: {} };
  }

  try {
    const delegationContent = fs.readFileSync(path.join(TASKS_DIR, 'delegation.md'), 'utf8');
    data.delegation = parseDelegation(delegationContent);
  } catch (e) {
    data.delegation = { error: e.message, tasks: [], stats: {} };
  }

  try {
    const maybeContent = fs.readFileSync(path.join(TASKS_DIR, 'maybe.md'), 'utf8');
    data.maybe = parseMaybeList(maybeContent);
  } catch (e) {
    data.maybe = { error: e.message, tasks: [], stats: {} };
  }

  return data;
}

/**
 * Move a task between quadrants or reorder within the same quadrant
 * @param {number} taskId - The task ID to move
 * @param {string} sourceQuadrant - Source quadrant (Q1, Q2, Q3, Q4)
 * @param {string} targetQuadrant - Target quadrant (Q1, Q2, Q3, Q4)
 * @param {number} insertIndex - Position to insert in target quadrant (-1 for append)
 */
async function moveTask(taskId, sourceQuadrant, targetQuadrant, insertIndex = -1) {
  try {
    console.log(`[Parser] Moving task ${taskId} from ${sourceQuadrant} to ${targetQuadrant} at index ${insertIndex}`);

    const tasksFile = path.join(TASKS_DIR, 'tasks.md');
    const content = fs.readFileSync(tasksFile, 'utf8');

    // Parse current tasks
    const tasks = parseTasks(content);

    // Find the task to move
    const sourceList = tasks[sourceQuadrant.toLowerCase()];
    const targetList = tasks[targetQuadrant.toLowerCase()];

    if (!sourceList || !targetList) {
      return { success: false, error: `Invalid quadrant: ${sourceQuadrant} or ${targetQuadrant}` };
    }

    const taskIndex = sourceList.findIndex(t => t.id === taskId);
    if (taskIndex === -1) {
      return { success: false, error: `Task ${taskId} not found in ${sourceQuadrant}` };
    }

    const taskToMove = sourceList[taskIndex];

    // Update task quadrant
    taskToMove.quadrant = targetQuadrant;

    // Remove from source
    sourceList.splice(taskIndex, 1);

    // Insert into target
    if (insertIndex === -1 || insertIndex >= targetList.length) {
      targetList.push(taskToMove);
    } else {
      targetList.splice(insertIndex, 0, taskToMove);
    }

    // Generate new markdown content (this will handle renumbering)
    const newContent = generateTasksMarkdown(tasks, content);

    // Write back to file
    fs.writeFileSync(tasksFile, newContent, 'utf8');

    // Calculate the new ID for the moved task
    let newId;
    if (targetQuadrant === 'Q1') {
      newId = insertIndex === -1 ? tasks.q1.length : insertIndex + 1;
    } else if (targetQuadrant === 'Q2') {
      newId = tasks.q1.length + (insertIndex === -1 ? tasks.q2.length : insertIndex + 1);
    } else if (targetQuadrant === 'Q3') {
      newId = tasks.q1.length + tasks.q2.length + (insertIndex === -1 ? tasks.q3.length : insertIndex + 1);
    } else {
      newId = tasks.q1.length + tasks.q2.length + tasks.q3.length + (insertIndex === -1 ? tasks.q4.length : insertIndex + 1);
    }

    console.log(`[Parser] Task moved successfully. New ID: ${newId}`);

    return {
      success: true,
      message: `Task moved from ${sourceQuadrant} to ${targetQuadrant}`,
      newId: newId
    };

  } catch (error) {
    console.error('[Parser] Move task error:', error);
    return { success: false, error: error.message };
  }
}

/**
 * Generate tasks.md content from parsed tasks
 * Uses task.raw to preserve original formatting, only updates task numbers
 */
function generateTasksMarkdown(tasks, originalContent) {
  // Extract header (everything before ## 🔥 Q1)
  const headerMatch = originalContent.match(/^(.*?)(?=## 🔥 Q1)/s);
  const header = headerMatch ? headerMatch[1] : '# 任务清单\n\n';

  // Calculate totals
  const totalTasks = tasks.q1.length + tasks.q2.length + tasks.q3.length + tasks.q4.length;

  // Update stats line in header (match both Chinese and English colons)
  let updatedHeader = header.replace(
    /总任务数[：:]\d+ \(Q1: \d+ \+ Q2: \d+ \+ Q3: \d+ \+ Q4: \d+\)/,
    `总任务数：${totalTasks} (Q1: ${tasks.q1.length} + Q2: ${tasks.q2.length} + Q3: ${tasks.q3.length} + Q4: ${tasks.q4.length})`
  );

  // Generate content
  let content = updatedHeader;

  // Q1
  content += '## 🔥 Q1(重要+紧急)\n\n';
  tasks.q1.forEach((task, index) => {
    content += formatTaskMarkdown(task, index + 1);
  });

  // Q2
  content += '\n## 💼 Q2(重要+不紧急)\n\n';
  tasks.q2.forEach((task, index) => {
    content += formatTaskMarkdown(task, tasks.q1.length + index + 1);
  });

  // Q3
  content += '\n## ⚡ Q3(不重要+紧急)\n\n';
  tasks.q3.forEach((task, index) => {
    content += formatTaskMarkdown(task, tasks.q1.length + tasks.q2.length + index + 1);
  });

  // Q4
  content += '\n## 🧘 Q4(不重要+不紧急)\n\n';
  tasks.q4.forEach((task, index) => {
    content += formatTaskMarkdown(task, tasks.q1.length + tasks.q2.length + tasks.q3.length + index + 1);
  });

  return content;
}

/**
 * Format a single task as markdown
 * Uses raw content if available, otherwise constructs from fields
 * Updates the task number to the new sequential number
 */
function formatTaskMarkdown(task, newId) {
  // If we have raw content, use it and just update the task number
  if (task.raw) {
    // Replace the task number in the raw content
    // Pattern: ### N. Title → ### newId. Title
    return task.raw.replace(/^### \d+\./, `### ${newId}.`);
  }

  // Fallback: construct from fields
  let md = `### ${newId}. ${task.title}`;

  if (task.tags && task.tags.length > 0) {
    md += ` [${task.tags.join('/')}]`;
  }

  md += '\n';

  if (task.priority) {
    md += `- **状态**:${task.priority}\n`;
  }
  if (task.description) {
    md += `- **描述**:${task.description}\n`;
  }
  if (task.created) {
    md += `- **创建**:${task.created}\n`;
  }
  if (task.blocked) {
    md += `- 🚫 **阻塞**\n`;
  }

  md += '\n';
  return md;
}

module.exports = {
  loadAllTasks,
  parseTasks,
  parseCustomerProjects,
  parseDelegation,
  parseMaybeList,
  moveTask
};
