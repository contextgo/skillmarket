---
name: cclaw
version: "1.8.0"
description: "Open-source comedy AI + video editing + poster generation. Create standup/sketch/manzai/scripts, edit videos via FFmpeg, and generate comedy posters via canvas-design. Supports Damai/Maoyan/Xiudong platform specs. Keywords: comedy, standup, sketch, video, edit, poster, canvas."
description_zh: "全球首个开源喜剧 AI + 视频剪辑 + 海报生成工具。创作脱口秀/小品/漫才/剧本等喜剧内容，或通过自然语言脚本驱动 FFmpeg 进行视频剪辑，或生成脱口秀/演出/金句海报及大麦/猫眼/秀动等平台标准规格物料。"
category: "data-analysis"
---
# Cclaw

[![License: MIT-0](https://img.shields.io/badge/License-MIT--0-lightgrey.svg)](https://opensource.org/licenses/MIT-0)

全球首个开源喜剧 AI —— 喜剧龙虾

一款面向全场景喜剧创作者的开源 AI 喜剧创作辅助工具 + 视频剪辑助手，专注解决从灵感构思到完整喜剧稿件"从0到1"难题，并支持自然语言驱动的视频剪辑。

## 项目定位

Cclaw，喜剧龙虾。
它不只是一个工具，更是一条路。
作为全链路喜剧创作孵化平台的开源核心，它以 AI 为笔，帮每一个有表达欲的人，将自身独特喜剧视角，写成能笑、能传、能站得住的喜剧文本。同时，它也是你的视频剪辑搭档——用自然语言描述剪辑意图，FFmpeg 帮你执行。

我们不制造廉价的梗，我们搭建真正的喜剧发生机制。
AI 完成"从零到一"，人完成从一到无穷。

## 我们在解决什么

- 普通人心里有戏，笔下无文，有情绪却不会成稿。
- 市面上的 AI 只懂堆砌笑点，不懂喜剧章法，更不懂人。
- 新人写了稿，没人改、没人教、没人指路子。
- 视频剪辑门槛高，时间轴操作繁琐，喜剧节奏难以精准把控。
- 喜剧这一行，长期缺一个真正好用、真正懂行的工具。

## 核心能力

### 喜剧文本创作

- 一事、一情、一念，即可生成完整喜剧文本，让氛围写作变成现实。
- 内置脱口秀、小品、漫才、日式短剧（コント）、剧本、讽刺、仿讽、荒诞剧等 **8 种全类型结构**。
- 语言口语、节奏利落、气质鲜明，适配线上传播，也适配喜剧舞台。
- 知识驱动：基于喜剧理论体系 + 案例库，不是随机堆梗，而是有章法地制造笑点。
- 尊重创作者风格，不模板化，不千人一面。

### 视频剪辑

- 自然语言脚本驱动 FFmpeg：说出你的剪辑意图，自动解析为 FFmpeg 命令。
- 支持基础剪辑（裁剪/删除/拼接）、过渡效果（fade/fadeblack/crossfade）、音频处理（loudnorm/加BGM）、字幕烧录。
- 内置 3 个剪辑配方：基础剪辑、高光集锦、喜剧节奏剪辑。
- 过渡效果库：快速查阅各种转场参数。
- 默认 H.264 输出，Windows 全平台可播。

### 海报生成

- 自然语言描述生成专业演出海报，支持脱口秀个人海报、演出宣传海报、社交分享卡。
- 支持大麦/猫眼/秀动等主流演出平台规格：海报、详情页、Banner。
- Design Brief 驱动：将喜剧语境自动翻译为设计语言，输出专业视觉。
- 内置配色方案、版式模板，一键生成可直接上传平台的物料。
- 输出格式：PNG（默认）、PDF（可选）。

## 谁都能用

- 脱口秀演员、喜剧编剧、真心热爱喜剧的普通人。
- 抖音、快手、小红书、视频号等平台的喜剧内容创作者。
- 深耕漫才、Sketch、喜剧短剧的团队与个人。
- 需要幽默表达、年会文案、宣传稿件、喜剧化演讲的企业与机构。
- 需要快速剪辑喜剧视频、制作高光片段的内容创作者。
- 需要生成演出海报、宣传物料的喜剧演员和主办方。
- 每一个想把生活讲成喜剧的人。

## 我们想做的事

做喜剧行业的基础设施。
用 AI 拆掉创作的门槛，用体系铺好成长的道路。
让每一个心怀欢喜的人，都能站上属于自己的喜剧舞台。

## 安装

```bash
# 方式一：ClawHub CLI
clawhub install cclaw

# 方式二：SkillHub CLI
skillhub install cclaw

# 方式三：手动安装
# 将本仓库内容放入 OpenClaw 的 skills 目录：
# ~/.qclaw/skills/cclaw/
```

## 使用示例

### 喜剧创作

```
写一段脱口秀，主题是中年程序员失业
帮我写个漫才，题材是大龄程序员面试
写个讽刺文，主题是内卷
用荒诞剧的形式表达沟通的不可能
```

### 视频剪辑

```
帮我剪辑视频，删掉第5秒到第20秒
拼接这4个片段，加上fade过渡
给56秒处加一个zoom特写效果
帮我提取高光片段做成集锦
```

### 海报生成

```
生成脱口秀海报，主题是AI打败了程序员
生成大麦演出海报，演出名称51笑翻天
生成金句卡，内容是35岁一个Bug都没修好的人生
生成大麦详情页，演员Diego，时间五月1日
```

## 架构

```
├── SKILL.md                     # 技能入口 + 三步路由工作流
├── commands.md                  # 用户命令配置（文本+视频）
├── LICENSE                      # MIT No Attribution
├── modules/
│   ├── writing/                 # 喜剧输出模板（8种）
│   │   ├── standup-template.md  # 脱口秀
│   │   ├── sketch-template.md   # 小品
│   │   ├── manzai-template.md   # 漫才
│   │   ├── japanese-sketch-template.md # 日式短剧（コント）
│   │   ├── script-template.md   # 剧本
│   │   ├── satire-template.md   # 讽刺文
│   │   ├── parody-template.md   # 仿讽
│   │   └── absurdist-template.md# 荒诞剧
│   └── tools/
│       ├── video/               # 视频剪辑模块
│       │   ├── README.md        # FFmpeg工作流 + 自然语言脚本解析
│       │   ├── transitions.md   # 过渡效果库
│       │   └── recipes/         # 剪辑配方
│       │       ├── basic-cut.md
│       │       ├── highlight-reel.md
│       │       └── comedy-timing.md
│       └── poster/              # 海报生成模块
│           ├── README.md        # 海报工作流 + Design Brief 规范
│           ├── briefs/          # 海报规格模板（大麦/猫眼/秀动）
│           │   ├── standup-poster.md
│           │   ├── comedy-show.md
│           │   ├── social-card.md
│           │   ├── damai-poster.md
│           │   ├── damai-detail.md
│           │   ├── banner-damai-999.md
│           │   └── banner-damai-1404.md
│           └── recipes/         # 海报配方
│               └── quote-card.md
├── knowledge/
│   ├── theory/                  # 喜剧底层原理（必读）
│   │   ├── eb7cb5ef.md         # 喜剧创作核心原理
│   │   ├── ac07d434.md         # 包袱结构与铺垫节奏
│   │   ├── 126b44e8.md         # 笑的心理学机制
│   │   └── 9d01e4da.md         # 喜剧类型速查 + 推荐手法
│   ├── cases/                   # 案例库 + 创作方法论（必读）
│   │   ├── standup/             # 脱口秀案例（充实 ✅）
│   │   ├── sketch/              # 小品案例（有模板 ✅）
│   │   ├── japanese-sketch/    # 日式短剧案例（待填充）
│   │   ├── manzai/              # 漫才（待填充）
│   │   ├── parody/              # 仿讽（待填充）
│   │   └── script/              # 剧本（待填充）
└── references/                  # 索引
    ├── comedy-theory.md         # 理论文件索引
    └── comedy-templates.md      # 模板文件索引
```

## 工作流程

Cclaw 采用**三步路由**架构：

1. **识别命令** — 读取 commands.md，判断是文本创作还是视频工具
2. **路由执行** — 文本创作走 knowledge 驱动（模板→案例→理论），视频工具走 FFmpeg 脚本驱动，海报生成走 Design Brief 驱动
3. **输出** — 成品 + 创作笔记（手法说明 + 知识来源标注）

## 喜剧理论体系

一切喜剧效果的根本来源：**生命中出现机械性、僵硬性**。

三大铁律：
1. 角色越不自觉，越可笑
2. 观众越不动情，越能发笑
3. 效果逐级递增

核心手法：弹簧魔鬼 / 雪球效应 / 系列干扰 / 换位 / 反转 / 三番四抖 / 连续否认 / Call Back（遗忘后再炸）

## 风格体系

Cclaw 在每种喜剧大类下，引入了**风格**作为第二层维度。同一个体裁（如脱口秀），可以有不同的讲法——自嘲式、观察式、荒诞解构式……详见 `knowledge/style-guide.md`。

## 版本历史

### v1.9.0 (2026-04-30)
- 新增风格体系（style-guide.md）：在每个喜剧大类下建立风格分类索引
- SKILL.md 新增 Step 1C 第五步"选定风格"：四问之后再确认风格（可跳过，默认自动推断）
- 创作流程重构：②模板+风格 → ③案例库（按style标签筛选） → ④理论 → ⑤创作
- 现有案例（growth-path.md、sketch创作模板）已添加 style 标签
- 未来新增案例时，顶部统一使用 `style:` 标签标记所属风格
- 发布至 ClawHub

### v1.8.0 (2026-04-28)
- 新增日式短剧（コント）创作类型
- 新增 8 条核心原则：装傻彻底、留白停顿（日式喜剧灵魂）
- 完善理论基础：起承转合四步结构、节奏铁律（15秒小/1分钟大）、三谷幸喜心法
- 新增创作模板：modules/writing/japanese-sketch-template.md
- 新增案例目录：knowledge/cases/japanese-sketch/
- 发布至 ClawHub

### v1.7.0 (2026-04-27)
- 新增海报生成模块，支持 3 种基础海报类型 + 8 种演出平台规格
- 支持大麦/猫眼/秀动：海报、详情页、Banner（共 11 个规格模板）
- 新增 Design Brief 工作流：喜剧语境 → 设计语言 → 专业视觉
- 集成 canvas-design skill 实现高质量视觉输出
- 本地版本完成，待发布至 ClawHub

### v1.6.0 (2026-04-26)
- 新增海报生成模块 P0+P1 实现
- 3 种海报类型：脱口秀海报(1080×1920)、演出海报(1920×1080)、社交分享卡(1200×630)
- 新增金句卡配方
- SKILL.md 新增 Step 2C 海报工作流
- 本地版本完成

### v1.5.1 (2026-04-26)
- 四问流程优化：Q3标题改为"创作者核心情绪"（明确问的是创作者自己的感受）
- 新增交互原则：用户可只选选项字母，也可补充描述
- 每步增加示例回复和括号提示引导
- 发布至 ClawHub

### v1.5.0 (2026-04-26)
- 新增意图确认分支：情况A（具体话题）直接创作，情况B（模糊如"写一段脱口秀"）走四问交互
- 四问流程：体裁→题材→情绪→受众
- 发布至 ClawHub

### v1.4.0 (2026-04-25)
- 新增 knowledge/blackbook.md 黑话手册（蒸馏/龙虾/国潮术语定义）
- SKILL.md 新增步骤⓪加载黑话（最高优先级）
- cases 空目录改为跳过不再读其他类型
- 发布至 ClawHub

## 许可证

本技能采用 **MIT No Attribution (MIT-0)** 许可证。

✅ 可自由使用、修改、分发、商用，无需署名。

详见 [LICENSE](./LICENSE) 文件。
