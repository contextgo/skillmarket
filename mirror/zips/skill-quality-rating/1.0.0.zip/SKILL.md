---
name: skill-reviewer
description: "审查 AgentSkill 的整体质量，包含两个阶段：Description 审查（6维/12分）和 Body 内容审查（7维/14分），总分 26 分。Use when 用户说「审查 skill」「review skill」「检查技能」「skill 质量」「描述质量」「内容质量」「body 审查」「全面审查」，或提供 skill 要求评估时触发。NOT for: skill 功能正确性验证、scripts/ 代码审查、运行时行为测试。"
---

# Skill Reviewer

基于 Anthropic 官方 Skill Best Practices、mgechev/skills-best-practices、SurePrompts Agent Prompting Guide 的全面 Skill 质量审查工具。

## 审查模式

用户可指定审查范围：
- `desc` — 只跑阶段一（Description 审查）
- `body` — 只跑阶段二（Body 内容审查）
- `full` — 两阶段全量审查（默认）

## 阶段一：Description 审查

### 1. 获取待审查的 description

三种输入方式：
- 用户直接提供 description 文本
- 用户指定 skill 名称 → 读取对应 SKILL.md 的 frontmatter
- 用户要求批量审查 → 扫描 `~/.openclaw/workspace/skills/` 下所有 SKILL.md

### 2. 执行六维评分

读取 [references/scoring-criteria.md](references/scoring-criteria.md) 获取完整评分标准。

六个维度，每项 0-2 分，满分 12 分：
- 动作清晰度 — 能否一句话说清做什么
- 触发条件 — LLM 能否准确判断何时使用
- 排除边界 — 是否有 NOT for 防止误触发
- 原子性 — 是否只解决一个问题
- 简洁性 — 是否在 1024 字符内且无冗余
- 命名一致性 — name 与 description 是否语义一致

### 3. 输出 Description 审查报告

按 scoring-criteria.md 中定义的输出格式生成报告。
总分 < 7 时，读取 [references/examples.md](references/examples.md) 获取重写模板和对照示例，提供重写建议。

## 阶段二：Body 内容审查

### 4. 获取 SKILL.md 完整内容

读取目标 skill 的 SKILL.md 全文及目录结构（`find <skill-dir> -type f`）。

### 5. 执行七维评分

读取 [references/body-scoring-criteria.md](references/body-scoring-criteria.md) 获取完整评分标准。

七个维度，每项 0-2 分，满分 14 分：
- 渐进式披露 — SKILL.md 是否只做导航，详细内容是否拆分
- 体积控制 — SKILL.md 行数是否合理（≤150 优秀，≤500 合格）
- 步骤结构化 — 工作流是否用编号步骤，分支是否清晰
- 指令风格 — 是否第三人称祈使句，面向 LLM
- 模板优于描述 — 复杂输出是否提供模板
- 脚本封装 — 易碎操作是否封装为脚本
- 错误处理 — 是否有失败路径和降级方案

### 6. 输出 Body 审查报告

按 body-scoring-criteria.md 中定义的输出格式生成报告。
总分 < 8 时，读取 [references/body-examples.md](references/body-examples.md) 获取重构建议和对照示例。

## 综合评分

两阶段完成后，输出综合报告：

```
## 综合评审: <skill-name>

| 阶段 | 得分 | 评级 |
|------|------|------|
| Description | X/12 | ... |
| Body | X/14 | ... |
| **综合** | **X/26** | ... |
```

综合评级标准：
- 22-26 分：✅ 优秀
- 15-21 分：⚠️ 合格
- 8-14 分：🔶 需改进
- 0-7 分：❌ 不合格

## 批量审查模式

用户要求审查所有 skill 时：
1. 扫描 skills 目录下所有 SKILL.md
2. 逐个执行选定的审查阶段
3. 汇总为排序表格，优先展示需改进的 skill
4. 输出整体质量分布统计
