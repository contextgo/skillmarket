# 好/差 Body 对照示例

## ❌ 差的 Body

### 示例 1：所有内容堆在 SKILL.md

```markdown
---
name: api-caller
description: "Call external APIs..."
---

# API Caller

You should call APIs when the user asks. First you need to check if the API key
is configured. The API key is stored in ~/.env file. You can read it with cat.
Then you construct the curl command. The format should be like this:
curl -H "Authorization: Bearer $KEY" https://api.example.com/v1/data
If it fails you might want to try again. Sometimes the API returns 429 which
means rate limited. In that case wait a bit and retry.

The output format should be a JSON with these fields:
- status: success or error
- data: the response data
- timestamp: when the call was made

Here is a complete example of the output:
{"status": "success", "data": {"items": [...]}, "timestamp": "2026-01-01T00:00:00Z"}

... (后续 300 行配置说明、错误码列表、各 API 端点文档)
```

问题：
- 全部内容堆在一个文件，没有渐进式披露
- 面向人类的口语化描述（"You should"、"you might want to"）
- 没有编号步骤
- 输出模板和说明混在一起
- 错误处理只是"try again"

### 示例 2：散文式无结构

```markdown
---
name: data-processor
description: "Process data files..."
---

# Data Processor

This skill helps process various data files. It can handle CSV, JSON, and XML
formats. When processing data, it's important to validate the input first.
The validation should check for encoding issues, missing headers, and malformed
rows. After validation, the data can be transformed according to the user's
requirements. Common transformations include filtering, sorting, and aggregation.
```

问题：
- 纯散文，没有任何步骤
- 面向人类的说明文风格
- 没有具体指令，agent 需要自己猜怎么做
- 没有脚本封装，复杂解析全靠 agent 临时写

---

## ✅ 好的 Body

### 示例 1：weather skill（精炼 + 步骤清晰）

```markdown
---
name: weather
description: "Get current weather and forecasts via wttr.in or Open-Meteo.
  Use when: user asks about weather, temperature, or forecasts.
  NOT for: historical weather data, severe weather alerts."
---

# Weather

## 查询流程

### 1. 确定位置
从用户输入提取城市名或坐标。无明确位置时询问用户。

### 2. 获取天气
执行 `curl "wttr.in/{location}?format=j1"` 获取 JSON 数据。

### 3. 解析并回复
提取温度、体感温度、湿度、风速、天气描述，用自然语言回复。

### 4. 失败降级
wttr.in 不可用时，切换 Open-Meteo API：
`curl "https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}&current_weather=true"`
```

亮点：编号步骤、祈使句、有降级方案、体积极小。

### 示例 2：渐进式披露 + 脚本封装

```markdown
---
name: excel-xlsx
description: "Create, inspect, and edit Excel workbooks..."
---

# Excel / XLSX

## 操作流程

### 1. 判断操作类型
根据用户意图分类：创建 / 读取 / 编辑 / 格式化。

### 2. 执行操作
读取 [references/operations.md](references/operations.md) 获取对应操作的详细步骤和 API 用法。

### 3. 公式与格式
涉及公式时，读取 [references/formula-guide.md](references/formula-guide.md)。

### 4. 输出验证
执行 `python3 scripts/validate-xlsx.py <file>` 验证输出文件完整性。
脚本返回非零退出码时，根据 stderr 信息修正后重试。
```

亮点：
- SKILL.md 只有导航，详细内容在 references/
- 脚本封装了验证逻辑
- 明确的 JiT 加载指令（"读取 references/xxx 获取..."）
- 错误处理路径清晰

---

## Body 改进套路

当 Body 质量差时，按以下步骤重构：

1. **拆分**：把 SKILL.md 中超过 10 行的详细说明移到 references/
2. **编号**：把散文改写为编号步骤
3. **祈使化**：把"You should..."改为"Extract..."、"Read..."
4. **模板化**：把输出格式描述替换为 assets/ 中的模板文件
5. **封装**：把重复/易碎操作提取为 scripts/ 下的脚本
6. **加降级**：为每个外部依赖（API、文件、网络）加失败路径
