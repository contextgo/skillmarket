# 好/差 Description 对照示例

## ❌ 差的 description

### 示例 1：过短
```yaml
description: "Excel skill"
```
问题：没动作、没触发、没边界。

### 示例 2：过于宽泛
```yaml
description: "Helps with documents"
```
问题：什么文档？做什么？什么时候用？全是问号。

### 示例 3：只有动作没有触发
```yaml
description: "Creates and edits Word documents"
```
问题：什么场景下该用？什么时候不用？容易误触发。

### 示例 4：多功能堆砌
```yaml
description: "Handles files, sends emails, manages calendar, and runs shell commands"
```
问题：违反原子性，应该拆成多个 skill。

## ✅ 好的 description

### 示例 1：Excel skill（三要素齐全）
```yaml
description: "Create, inspect, and edit Microsoft Excel workbooks and XLSX files
  with reliable formulas, dates, types, formatting, recalculation, and template preservation.
  Use when (1) the task is about Excel, `.xlsx`, `.xlsm`, `.xls`, `.csv`, or `.tsv`;
  (2) formulas, formatting, workbook structure, or compatibility matter;
  (3) the file must stay reliable after edits."
```
亮点：动作明确、触发条件有编号、暗含排除（普通文本表格不适用）。

### 示例 2：Weather skill（显式 NOT for）
```yaml
description: "Get current weather and forecasts via wttr.in or Open-Meteo.
  Use when: user asks about weather, temperature, or forecasts for any location.
  NOT for: historical weather data, severe weather alerts, or detailed meteorological analysis.
  No API key needed."
```
亮点：NOT for 明确，减少误触发。

### 示例 3：中文 skill 带触发词
```yaml
description: "腾讯文档（docs.qq.com）在线云文档平台。
  触发词：新建文档、创建文档、写文档、在线文档、云文档、腾讯文档、docs.qq.com。
  支持能力：创建各类在线文档、管理知识库空间、读取/搜索文档内容、编辑智能表。
  不适用于：本地 Word/Excel 文件处理、其他云文档平台（飞书、Notion）。"
```
亮点：触发词列表 + 能力边界 + 排除说明。

## 重写套路

当原 description 质量差时，用这个模板重写：

```
<一句话做什么>.
Use when <场景1>; <场景2>; <场景3>.
NOT for: <排除场景1>; <排除场景2>.
[可选：关键触发词/触发文件类型]
```

## 常见问题修复清单

| 问题 | 修复方式 |
|------|---------|
| 描述太短 | 补充触发条件和适用场景 |
| 描述太长（>1024字符） | 删除实现细节、参数说明，只保留"做什么+何时用" |
| 没有 NOT for | 根据功能边界添加至少一条排除场景 |
| 动词模糊（"handles", "helps"） | 换成具体动词（"create", "query", "validate"） |
| 多功能堆砌 | 拆分成多个 skill |
| 只有英文/只有中文 | 根据用户语言偏好保持一致 |

---

> Body 内容的好/差对照示例见 [body-examples.md](body-examples.md)。
