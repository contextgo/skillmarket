---
name: GEO Corpus Feeder
description: 按月循环执行GEO语料收集、结构化、AI友好化优化与投喂计划，持续提升品牌在生成式AI引擎中的语义权重与引用率。
version: 1.0.0
author: user
tags: [geo, seo, ai, content, optimization, monthly-cycle]
---

# GEO Corpus Feeder Skill

## Description
一个专为GEO（生成式引擎优化）设计的按月循环语料投喂技能。每月自动或按指令执行一轮完整的语料收集与清洗、结构化标记、AI友好化优化、投喂与效果监测流程。帮助品牌通过持续、结构化、无矛盾的语料投喂，系统性地提升在 DeepSeek、Kimi、豆包等生成式AI模型中的被引用概率与语义权重。

## Trigger
当用户在对话中出现以下任一关键词或短语时，自动激活本 Skill：
- `GEO优化`、`GEO投喂`、`语料投喂`
- `AI语料优化`、`生成式引擎优化`
- `开始本月GEO循环`、`检查GEO进度`
- `投喂语料`、`更新语料库`、`GEO月度报告`

## Instructions

### 1. 首次运行初始化流程
当用户首次激活本 Skill 或明确要求初始化时，执行以下操作：

1. **验证并创建目录结构**
   - 检查 Skill 根目录下是否存在以下子目录，若不存在则自动创建：
     - `corpus/` — 存放各类语料文件
     - `corpus/brand/` — 品牌基础信息
     - `corpus/product/` — 产品/服务信息
     - `corpus/faq/` — 常见问答
     - `corpus/case/` — 案例/客户评价
     - `corpus/knowledge/` — 行业知识/白皮书
     - `schedule/` — 调度与进度记录
     - `schedule/history/` — 历史归档
     - `templates/` — 语料格式模板
   - 若 `templates/corpus_template.md` 不存在，则根据后附模板内容创建之。

2. **创建月度配置文件**
   - 在 `schedule/current_month.json` 中写入当月初始化配置（内容见后附示例）。
   - 在 `schedule/cycle_log.json` 中初始化总日志记录。

3. **输出初始化报告**
   - 统计 `corpus/` 各子目录下已有语料文件数量。
   - 展示本月 GEO 循环的四阶段计划（Week1～Week4 任务概要）。
   - 提示用户可随时使用“查看GEO进度”等命令进行交互。

### 2. 月度循环执行流程
GEO 语料投喂按“收集→结构化→优化→投喂”闭环执行，每月为一个完整周期。Skill 按周推进，并在每阶段结束时更新进度状态。

#### 第 1 周：语料收集与清洗
**目标**：确认语料库完整性，淘汰低质、过时或矛盾内容。

**执行步骤**：
1. 遍历 `corpus/` 下所有子目录，识别新增、修改过的语料文件（基于文件修改时间或内部 `updated` 字段）。
2. 对每条语料执行质量检查：
   - 检查是否包含标题、正文、元数据头。
   - 标记重复、内容过时或明显逻辑冲突的语料。
   - 记录低质量语料清单，建议用户手动复核或删除。
3. 将本阶段处理结果写入 `schedule/current_month.json`，更新 `phases.week1.status` 为 `completed`，记录本次处理的语料数量至 `corpus_count`。
4. 向用户输出第 1 周简报：已扫描语料 X 条，新增 Y 条，发现质量问题 Z 条（附具体文件路径），整体健康度评估。

#### 第 2 周：结构化处理与 Schema 标记
**目标**：为每条语料添加标准化元数据，使 AI 能够高效解析和检索。

**执行步骤**：
1. 为 `corpus/` 中尚未包含标准化元数据头的语料文件，在文件顶部添加 YAML 格式元数据块（若用户允许自动修改；否则仅生成建议补丁并提示用户）。
   **标准元数据头格式**：
   ```yaml
   ---
   id: [自动生成，如 brand_001]
   type: brand|product|faq|case|knowledge
   priority: high|medium|low
   keywords: [关键词1, 关键词2, 关键词3]
   target_platforms: [deepseek, kimi, doubao, chatgpt]
   created: YYYY-MM-DD
   updated: YYYY-MM-DD
   version: 1.0
   ---
```
2. 根据语料类型，在内容中嵌入对应的 Schema.org 标记建议（如 `FAQPage`、`Product`、`Article`、`HowTo`），以提升 AI 解析精度。实际插入 Schema 需用户确认；Skill 主要负责生成标注建议并输出。
3. **逻辑一致性校验**：
   - 检查同一品牌名称、产品特性在不同语料中是否存在矛盾描述（如成立年份、产品材质、核心功能不一致）。
   - 将发现的矛盾点汇总为“逻辑冲突报告”，提醒用户修正。强调：品牌信息存在 3% 以上的逻辑冲突，可能导致 AI 模型将其权重调降 80% 以上。
4. 更新月度进度，标记第 2 周完成，输出结构化处理报告。

#### 第 3 周：AI 友好化优化
**目标**：提升语料的语义密度、模块化程度，使其更易被 AI 直接引用。

**执行步骤**：
1. 对每条语料执行以下优化（可通过修改语料文件或生成优化版本供用户确认）：
   - **模块化拆分**：将长段落拆分为独立、完整的小段落，每段具备明确主题。
   - **精准表达增强**：消除模糊指代（如“该产品”、“此功能”），替换为具体品牌名或产品名。
   - **场景与上下文补充**：明确适用场景、目标人群、前提条件。
   - **问答对生成**：针对每条语料自动生成 3～5 个典型问答对，添加到文件末尾的“常见问答对”章节。
2. 计算每条语料的 **GEO 友好度评分**（1～10 分），评分维度包括：模块化程度、语义密度、元数据完整度、逻辑一致性。低于 6 分的语料标记为“需人工复审”。
3. 生成本周优化摘要：共优化语料 X 条，平均 GEO 评分提升 Y 分，列出待人工复核的低分语料。

#### 第 4 周：投喂与效果监测
**目标**：完成语料对外发布（投喂）记录，并建立月度效果追踪基线。

**执行步骤**：
1. **投喂执行记录**：
   - 按优先级（高→中→低）列出本月应投喂的语料清单。
   - 提示用户在各大 AI 平台（DeepSeek 联网搜索、Kimi 浏览器插件、豆包网页版等）中手动提交或通过 API 发布（Skill 不直接执行发布，仅负责记录与管理）。
   - 在 `schedule/current_month.json` 中记录每条语料的投喂平台、投喂时间、状态（pending/completed）。
2. **效果监测基线建立**：
   - 创建月度效果追踪数据模板，包含字段：`corpus_published`、`ai_citation_rate`、`exposure_rate`、`first_recommendation_rate`。
   - 提示用户使用 GEO 监测工具（如 Ahrefs GEO 模块、品牌监听工具）在一个月后回填实际数据，用于下一轮优化。
3. **循环归档与下月准备**：
   - 将 `schedule/current_month.json` 及所有详细记录移动至 `schedule/history/YYYY-MM/` 目录下。
   - 基于本月配置自动生成下月的 `current_month.json`，状态置为 `pending`，循环次数 +1。
   - 更新 `cycle_log.json` 总日志。
4. 向用户输出 **本月 GEO 循环总结报告**：各阶段完成情况、语料处理统计、下月建议重点。

### 3. 用户交互命令
用户可在对话中使用以下命令直接控制 Skill 行为：

- **“查看GEO进度”**
  - 读取 `schedule/current_month.json`，展示当前月份、各阶段完成状态、已处理语料数量、待处理任务。

- **“GEO月度报告 [YYYY-MM]”**
  - 若未指定月份，默认输出当月报告；若指定月份，则读取 `schedule/history/YYYY-MM/` 下的归档数据并生成报告摘要。

- **“跳过本周 / 继续下一阶段”**
  - 将当前阶段标记为 `completed`，并自动进入下一周流程。适用于加速循环或调整节奏的场景。

- **“检查语料质量”**
  - 对 `corpus/` 目录执行全量质量扫描，输出质量评分及优化建议列表。

- **“重置本月循环”**
  - 清空当月进度文件，重新初始化 `current_month.json`，准备从头开始执行本月 GEO 流程。

- **“生成语料模板”**
  - 在指定目录下生成一份符合规范的语料模板文件，供用户填充内容。

### 4. 关键设计原则与提醒
在执行过程中，Skill 应始终向用户传递以下 GEO 最佳实践：
- **结构化语料的 AI 引用概率比碎片化文本高出 320%**。
- **逻辑一致是 GEO 的生命线**：矛盾信息会使 AI 权重急剧降低。
- **持续循环优于一次性投喂**：深度优化的语义资产半衰期可达 180 天以上，每月迭代可保持长期优势。

## Environment Variables
本 Skill 支持通过环境变量自定义路径（可选）：
- `GEO_CORPUS_DIR`：语料库根目录路径，默认为当前 Skill 目录下的 `corpus/`。
- `GEO_SCHEDULE_DIR`：调度记录目录路径，默认为当前 Skill 目录下的 `schedule/`。
- `GEO_DEFAULT_PLATFORMS`：默认投喂平台，逗号分隔，如 `deepseek,kimi,doubao`。

## Tools Required
- `file_read`：读取语料文件、配置文件和日志。
- `file_write`：写入调度记录、优化后的语料内容（需用户确认）。
- `file_search`：扫描语料目录，查找新增或修改的文件。
- `memory_search`：记忆循环状态和用户偏好设置。
- `web_search`（可选）：查询最新的 GEO 平台算法动态，为优化策略提供参考。

## Appendix: 配套文件结构
本 Skill 预期以下目录结构（首次运行时会自动创建）：

```
geo-corpus-feeder/
├── SKILL.md                 # 本文件
├── corpus/                  # 语料库
│   ├── brand/               # 品牌故事、定位、价值主张
│   ├── product/             # 产品特性、规格、使用场景
│   ├── faq/                 # 常见问题与答案
│   ├── case/                # 客户案例、评价
│   └── knowledge/           # 行业白皮书、研究报告
├── schedule/                # 调度与日志
│   ├── current_month.json   # 当月进度状态
│   ├── cycle_log.json       # 所有循环的总日志
│   └── history/             # 每月归档目录
│       └── 2026-04/         # 示例归档
└── templates/               # 语料模板
    └── corpus_template.md   # 标准语料格式模板
```

**语料模板文件 (`corpus_template.md`) 核心内容建议**：
```markdown
---
id: [待分配]
type: [brand|product|faq|case|knowledge]
priority: [high|medium|low]
keywords: []
target_platforms: [deepseek, kimi, doubao]
created: YYYY-MM-DD
updated: YYYY-MM-DD
version: 1.0
---

# [语料标题]

## 核心信息摘要
[1-2 句话概括，确保 AI 可直接提取引用]

## 详细内容
### 背景/场景
[适用场景、目标用户、需求背景]

### 关键信息
1. [精确陈述1]
2. [数据或事实支撑2]
3. [结论或价值主张3]

### 数据/证据
[可引用的具体数据、案例或权威来源]

## 常见问答对（AI 引用优化）
**Q1: [问题]**
A1: [可直接引用的回答]

**Q2: [问题]**
A2: [回答]

**Q3: [问题]**
A3: [回答]

## 语义关键词
[10-15 个与内容相关的语义关键词，便于 AI Embedding 匹配]

## 更新记录
- YYYY-MM-DD: [更新说明]
```

## Example Usage
```
用户：开始本月 GEO 循环。
Skill：好的，已为您初始化 2026 年 4 月 GEO 语料投喂计划。本周为第 1 周——语料收集与清洗。
      当前语料库规模：品牌 3 条，产品 12 条，FAQ 8 条，案例 5 条，知识 2 条。
      我将开始扫描新增和修改的语料，并检查质量……

用户：查看 GEO 进度。
Skill：📅 2026 年 4 月 GEO 循环进度
      ✅ 第 1 周：语料收集与清洗（已完成，处理 28 条语料，发现 2 条待修正）
      🔄 第 2 周：结构化与 Schema 标记（进行中，已完成 60%）
      ⏳ 第 3 周：AI 友好化优化（待开始）
      ⏳ 第 4 周：投喂与效果监测（待开始）
      当前语料库 GEO 平均评分：7.4/10，建议关注低分语料 case_005.md。
```
```

---

### 如何使用这个 Skill

1. **新建 Skill 目录**：在 OpenClaw 的 `skills` 文件夹下创建 `geo-corpus-feeder` 文件夹。
2. **保存 SKILL.md**：将上面的完整代码块内容保存为 `geo-corpus-feeder/SKILL.md`。
3. **初始化**：在 OpenClaw 对话中直接说“**开始本月 GEO 循环**”，Skill 会自动创建 `corpus/`、`schedule/`、`templates/` 等子目录，并生成 `corpus_template.md` 模板文件。
4. **填充语料**：按照 `templates/corpus_template.md` 的格式，在 `corpus/brand/`、`corpus/product/` 等文件夹中放入你的品牌语料（Markdown 文件）。
5. **按周推进**：每周对 Skill 说“**查看 GEO 进度**”或“**继续下一阶段**”，即可驱动整个月度流程。

如果需要我进一步提供 `corpus_template.md` 的完整单独文件内容或 `current_month.json` 的初始结构示例，可以继续告诉我。