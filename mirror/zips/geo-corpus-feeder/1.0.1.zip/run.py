import os
import json
import datetime
import uuid

BASE_DIR = os.getcwd()
CORPUS_DIR = os.path.join(BASE_DIR, "corpus")
SCHEDULE_DIR = os.path.join(BASE_DIR, "schedule")

def ensure_dirs():
    dirs = [
        "corpus/brand",
        "corpus/product",
        "corpus/faq",
        "corpus/case",
        "corpus/knowledge",
        "schedule/history",
        "templates"
    ]
    for d in dirs:
        path = os.path.join(BASE_DIR, d)
        os.makedirs(path, exist_ok=True)

def init_month():
    now = datetime.datetime.now()
    month = now.strftime("%Y-%m")

    current_file = os.path.join(SCHEDULE_DIR, "current_month.json")

    data = {
        "month": month,
        "cycle": 1,
        "phases": {
            "week1": {"status": "pending"},
            "week2": {"status": "pending"},
            "week3": {"status": "pending"},
            "week4": {"status": "pending"}
        },
        "corpus_stats": {},
        "logs": []
    }

    with open(current_file, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def scan_corpus():
    stats = {}
    total = 0

    for root, dirs, files in os.walk(CORPUS_DIR):
        for file in files:
            if file.endswith(".md"):
                total += 1
                category = root.split(os.sep)[-1]
                stats[category] = stats.get(category, 0) + 1

    return total, stats

def check_quality(file_path):
    with open(file_path, "r", encoding="utf-8") as f:
        content = f.read()

    score = 10

    if "---" not in content:
        score -= 2
    if len(content) < 300:
        score -= 2
    if "##" not in content:
        score -= 1

    return max(score, 1)

def week1_cleaning():
    issues = []
    total = 0

    for root, dirs, files in os.walk(CORPUS_DIR):
        for file in files:
            if file.endswith(".md"):
                total += 1
                path = os.path.join(root, file)
                score = check_quality(path)

                if score < 6:
                    issues.append({
                        "file": path,
                        "score": score
                    })

    return total, issues

def generate_id(prefix):
    return f"{prefix}_{str(uuid.uuid4())[:6]}"

def week2_structure():
    updated = 0

    for root, dirs, files in os.walk(CORPUS_DIR):
        for file in files:
            if file.endswith(".md"):
                path = os.path.join(root, file)

                with open(path, "r", encoding="utf-8") as f:
                    content = f.read()

                if not content.strip().startswith("---"):
                    meta = f"""---
id: {generate_id("auto")}
type: unknown
priority: medium
keywords: []
target_platforms: [deepseek, kimi, doubao]
created: {datetime.date.today()}
updated: {datetime.date.today()}
version: 1.0
---

"""
                    content = meta + content

                    with open(path, "w", encoding="utf-8") as f:
                        f.write(content)

                    updated += 1

    return updated

def week3_optimize():
    improved = 0

    for root, dirs, files in os.walk(CORPUS_DIR):
        for file in files:
            if file.endswith(".md"):
                improved += 1

    return improved

def week4_publish_record():
    record = {
        "published": [],
        "date": str(datetime.date.today())
    }

    return record

def update_schedule(week, result):
    file = os.path.join(SCHEDULE_DIR, "current_month.json")

    with open(file, "r", encoding="utf-8") as f:
        data = json.load(f)

    data["phases"][week]["status"] = "completed"
    data["phases"][week]["result"] = result

    with open(file, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def run_week(week):
    if week == "week1":
        total, issues = week1_cleaning()
        update_schedule("week1", {"total": total, "issues": issues})

    elif week == "week2":
        updated = week2_structure()
        update_schedule("week2", {"updated": updated})

    elif week == "week3":
        improved = week3_optimize()
        update_schedule("week3", {"optimized": improved})

    elif week == "week4":
        record = week4_publish_record()
        update_schedule("week4", record)

if __name__ == "__main__":
    ensure_dirs()
    init_month()
    run_week("week1")