window.__OFFLINE_DAILY_MACROS = [];
window.__OFFLINE_TARGETS = {
  "daily_goals": {
    "calories": 2000,
    "protein": 150,
    "carbs": 200,
    "fats": 70,
    "vit_d3": 15,
    "magnesium": 420,
    "potassium": 3400,
    "zinc": 11,
    "vit_b6": 1.3,
    "vit_b12": 2.4,
    "selenium": 55,
    "vit_c": 90,
    "vit_a": 900,
    "vit_e": 15
  },
  "focus": [],
  "notes": "Default goals based on general 32-year-old male recommended daily intakes."
};
window.__OFFLINE_INSIGHTS = {
  "summary": "Welcome to MyFitnessClaw! Log your first meal to get started.",
  "tips": [
    "Log meals in plain language.",
    "Macros and micros are tracked automatically.",
    "View your progress on the dashboard!"
  ]
};
