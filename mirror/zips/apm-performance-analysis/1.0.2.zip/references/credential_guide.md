# 凭证配置详细指南

本文档是 SKILL.md 的补充参考，包含腾讯云凭证的完整配置步骤。

## 凭证用途

腾讯云凭证（SecretId / SecretKey）用于 MCP Server 认证。`mcp_client.py` 自动从 shell 环境变量读取凭证并通过 HTTP header（`secretId` / `secretKey`）传递给 MCP Server。

## 配置步骤

### 第一步：获取密钥

前往 [腾讯云 API 密钥管理](https://console.cloud.tencent.com/cam/capi) 获取。

**安全建议**：创建最小权限子账号，避免使用主账号密钥。

### 第二步：写入 shell 配置文件（永久生效）

在终端执行以下命令（将 `your-secret-id` 和 `your-secret-key` 替换为你的实际密钥）：

**macOS / Linux (Zsh)**：

```bash
echo 'export TENCENTCLOUD_SECRET_ID="your-secret-id"' >> ~/.zshrc
echo 'export TENCENTCLOUD_SECRET_KEY="your-secret-key"' >> ~/.zshrc
source ~/.zshrc
```

**macOS / Linux (Bash)**：

```bash
echo 'export TENCENTCLOUD_SECRET_ID="your-secret-id"' >> ~/.bashrc
echo 'export TENCENTCLOUD_SECRET_KEY="your-secret-key"' >> ~/.bashrc
source ~/.bashrc
```

### 第三步：验证配置

```bash
# 检查环境变量是否生效（应输出你的 SecretId）
echo $TENCENTCLOUD_SECRET_ID
```

### 第四步（可选）：配置其他环境变量

```bash
# 默认地域（不设置则为 ap-guangzhou）
echo 'export TENCENTCLOUD_REGION="ap-guangzhou"' >> ~/.zshrc

# 自定义 MCP Server 地址（不设置则使用内置默认地址）
# echo 'export APM_MCP_SSE_URL="https://your-mcp-server/sse"' >> ~/.zshrc

source ~/.zshrc
```

## 支持的环境变量

| 变量名 | 必填 | 说明 |
|-------|------|------|
| `TENCENTCLOUD_SECRET_ID` | 是 | 腾讯云 API SecretId（通过 HTTP header 传递给 MCP Server） |
| `TENCENTCLOUD_SECRET_KEY` | 是 | 腾讯云 API SecretKey（通过 HTTP header 传递给 MCP Server） |
| `TENCENTCLOUD_REGION` | 否 | 默认地域，不设置则为 `ap-guangzhou` |
| `APM_MCP_SSE_URL` | 否 | MCP SSE Server 地址，不设置则使用内置默认地址 |
| `APM_MCP_TIMEOUT` | 否 | MCP 连接超时（秒），默认 `30` |
| `APM_MCP_SSE_READ_TIMEOUT` | 否 | MCP SSE 读取超时（秒），默认 `300` |
| `APM_VENV_DIR` | 否 | 自定义虚拟环境目录路径，不设置则为 `./.apm-venv/` |
| `APM_ERROR_LOG_DIR` | 否 | 错误日志目录，不设置则为 `./logs/` |

## 凭证优先级

1. 命令行参数 `--secret-id` / `--secret-key`（最高优先级）
2. 环境变量 `TENCENTCLOUD_SECRET_ID` / `TENCENTCLOUD_SECRET_KEY`

## 安全强制规则

1. **禁止硬编码**: 任何代码中不得出现真实的 SecretId 或 SecretKey 值。
2. **占位符引用**: 在文档、示例代码、终端输出中，必须使用占位符。
3. **版本控制排除**: 密钥仅存在于用户的 shell 配置文件中，不会出现在项目文件里。
4. **日志脱敏**: 错误日志不记录密钥值，日志文件权限 `600`。
5. **对话安全**: 用户提供密钥明文时不得回显，应提示在终端中配置环境变量。
6. **不使用 .env 文件**: 凭证不通过 `.env` 文件管理，避免被意外提交到版本控制。
