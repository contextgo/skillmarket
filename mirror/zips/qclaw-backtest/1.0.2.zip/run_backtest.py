# -*- coding: utf-8 -*-
"""直接执行回测脚本
用法: python run_backtest.py [--策略 策略名] [--文本 策略描述] [--开始 YYYY-MM-DD] [--结束 YYYY-MM-DD] [--输出 目录]
"""
import sys
import os
import argparse
from pathlib import Path
from datetime import date

# 动态添加 SKILL 根目录到 PYTHONPATH（qclaw_quant 包直接在根目录，无需 src/ 子目录）
_script_dir = Path(__file__).resolve().parent          # run_backtest.py 所在目录
_skill_root = _script_dir                              # SKILL 包根目录

if str(_skill_root) not in sys.path:
    sys.path.insert(0, str(_skill_root))

from qclaw_quant import QuantSystem

# ============ 默认配置 ============
DEFAULT_STRATEGY_TEXT = "选股池:沪深300,PE<15,市值100-500亿,等权分配,止损8%,止盈20%,每月1日调仓,初始资金100万"
DEFAULT_START_DATE = "2020-01-01"
DEFAULT_END_DATE = "2024-12-31"
# 默认输出到脚本同目录下的 QClaw报告 文件夹
DEFAULT_BASE_DIR = str(_skill_root / 'QClaw报告')
# =================================

def parse_args():
    parser = argparse.ArgumentParser(description='QClaw 量化回测执行脚本')
    parser.add_argument('--策略', '--name', '-n', default='策略',
                        help='策略名称简写（用于子文件夹命名）')
    parser.add_argument('--文本', '--text', '-t', default=DEFAULT_STRATEGY_TEXT,
                        help='策略描述（自然语言）')
    parser.add_argument('--开始', '--start', '-s', default=DEFAULT_START_DATE,
                        help='回测开始日期 (YYYY-MM-DD)')
    parser.add_argument('--结束', '--end', '-e', default=DEFAULT_END_DATE,
                        help='回测结束日期 (YYYY-MM-DD)')
    parser.add_argument('--输出', '--out', '-o', default=DEFAULT_BASE_DIR,
                        help='输出基础目录')
    return parser.parse_args()

def main():
    args = parse_args()
    
    # 策略名称简写（用于子文件夹命名）
    strategy_short_name = args.策略
    today = date.today().strftime("%Y%m%d")
    
    # 构建输出路径：{基础目录}/{策略名}_{日期}/
    output_dir = f"{args.输出}/{strategy_short_name}_{today}"
    os.makedirs(output_dir, exist_ok=True)
    
    print(f"[目录] {output_dir}")
    
    # 创建系统实例
    qs = QuantSystem()
    
    # 执行回测
    print("[开始] 回测中...")
    result = qs.auto_execute(
        nl_text=args.文本,
        start_date=args.开始,
        end_date=args.结束,
        output_dir=output_dir,
        skip_confirm=True
    )
    
    print("\n=== 回测结果 ===")
    print(f"状态: {result.get('status')}")
    if 'metrics' in result:
        m = result['metrics']
        print(f"总收益率: {m.get('total_return', 'N/A')}%")
        print(f"年化收益: {m.get('annual_return', 'N/A')}%")
        print(f"超额收益: {m.get('excess_return', 'N/A')}%")
        print(f"夏普比率: {m.get('sharpe_ratio', 'N/A')}")
        print(f"最大回撤: {m.get('max_drawdown', 'N/A')}%")
    
    print(f"\n[完成] 报告已保存至: {output_dir}")

if __name__ == '__main__':
    main()
