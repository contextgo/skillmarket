# -*- coding: utf-8 -*-
from setuptools import setup, find_packages

setup(
    name='qclaw-quant',
    version='2.0.0',
    description='QClaw Quant - 量化交易策略回测与实盘系统',
    author='QClaw',
    packages=find_packages(where='src'),
    package_dir={'': 'src'},
    install_requires=[
        'akshare>=1.18.56',
        'baostock>=0.9.1',
        'pandas>=3.0.0',
        'numpy>=1.26.0',
        'pyyaml>=6.0',
        'python-docx>=1.2.0',
        'openpyxl>=3.1.0',
        'matplotlib>=3.8.0',
    ],
    python_requires='>=3.8',
    entry_points={
        'console_scripts': [
            'qclaw-quant=qclaw_quant.__main__:main',
        ],
    },
)