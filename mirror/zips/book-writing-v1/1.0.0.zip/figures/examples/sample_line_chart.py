#!/usr/bin/env python3
"""
文件：sample_line_chart.py
用途：折线图示例 - 展示数据随时间的变化趋势
使用场景：适合展示趋势、增长、变化曲线等
"""

import matplotlib.pyplot as plt
import numpy as np
import matplotlib as mpl
from pathlib import Path

# ============================================================
# 全书统一图表样式设置
# ============================================================
def setup_book_style():
    """设置全书统一图表样式"""
    # 中文字体设置（macOS 优先使用 Arial Unicode MS）
    mpl.rcParams['font.sans-serif'] = ['Arial Unicode MS', 'SimHei', 'DejaVu Sans', 'sans-serif']
    mpl.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题
    
    # 字号设置
    mpl.rcParams['figure.titlesize'] = 16
    mpl.rcParams['axes.titlesize'] = 14
    mpl.rcParams['axes.labelsize'] = 12
    mpl.rcParams['xtick.labelsize'] = 10
    mpl.rcParams['ytick.labelsize'] = 10
    mpl.rcParams['legend.fontsize'] = 10
    
    # 线条和标记设置
    mpl.rcParams['lines.linewidth'] = 2
    mpl.rcParams['lines.markersize'] = 6
    
    # 图表背景和网格
    plt.style.use('seaborn-v0_8-whitegrid')

# ============================================================
# 生成示例数据
# ============================================================
np.random.seed(42)

# 生成时间轴数据（12个月）
months = np.arange(1, 13)
month_labels = [f'{m}月' for m in months]

# 生成三条趋势线（模拟不同场景）
# 趋势1：稳定增长
trend1 = 10 + months * 1.5 + np.random.randn(12) * 2

# 趋势2：快速起步后平缓
trend2 = 5 + months * 2.5 - 0.1 * (months - 6)**2 + np.random.randn(12) * 2

# 趋势3：波动型
trend3 = 15 + np.sin(months / 2) * 5 + np.random.randn(12) * 1.5

# ============================================================
# 绘图
# ============================================================
setup_book_style()

fig, ax = plt.subplots(figsize=(10, 6))

# 绘制三条折线
ax.plot(months, trend1, marker='o', label='方案A', linewidth=2, color='#2E86AB')
ax.plot(months, trend2, marker='s', label='方案B', linewidth=2, color='#A23B72')
ax.plot(months, trend3, marker='^', label='方案C', linewidth=2, color='#F18F01')

# 添加图表元素
ax.set_title('不同方案的效果对比', pad=20, fontweight='bold')
ax.set_xlabel('时间（月）')
ax.set_ylabel('效果值')
ax.set_xlim(0.5, 12.5)
ax.set_xticks(months)
ax.set_xticklabels(month_labels)
ax.legend(loc='upper left', frameon=True, shadow=True)

# 添加网格和边框
ax.grid(True, alpha=0.3, linestyle='--')
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)

# ============================================================
# 保存图片
# ============================================================
# 确保 figures 目录存在
output_dir = Path(__file__).parent.parent / 'figures'
output_dir.mkdir(parents=True, exist_ok=True)

# 保存为高分辨率 PNG
output_path = output_dir / 'fig-line-chart-sample.png'
plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='white')

# 同时保存为 PDF（如用于印刷）
plt.savefig(output_dir / 'fig-line-chart-sample.pdf', bbox_inches='tight', facecolor='white')

print(f"✅ 图片已保存至：{output_path}")
print(f"📄 PDF 已保存至：{output_dir / 'fig-line-chart-sample.pdf'}")

plt.close()
