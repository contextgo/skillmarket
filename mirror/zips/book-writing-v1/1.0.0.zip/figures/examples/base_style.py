#!/usr/bin/env python3
"""
文件：base_style.py
用途：全书统一图表样式配置
说明：在所有绘图脚本的开头导入并调用 setup_book_style()
"""

import matplotlib.pyplot as plt
import matplotlib as mpl
import seaborn as sns
from typing import Optional, List, Tuple

# ============================================================
# 全书配色方案（可自定义）
# ============================================================
BOOK_COLORS = {
    'primary': '#2E86AB',      # 主色调 - 蓝色
    'secondary': '#A23B72',     # 辅色 - 紫色
    'accent': '#F18F01',        # 强调色 - 橙色
    'success': '#06A77D',       # 成功色 - 绿色
    'warning': '#E63946',       # 警告色 - 红色
    'neutral': '#6C757D',       # 中性色 - 灰色
}

# 配色方案（用于多条线/多个柱）
BOOK_PALETTES = {
    'default': ['#2E86AB', '#A23B72', '#F18F01', '#06A77D', '#E63946'],
    'cool': ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd'],
    'warm': ['#FF6B6B', '#4ECDC4', '#FFE66D', '#95E1D3', '#F38181'],
    'diverging': ['#1a9850', '#91cf60', '#d9ef8b', '#fee08b', '#d73027'],
}


# ============================================================
# 全书样式配置函数
# ============================================================
def setup_book_style(
    font_family: Optional[str] = None,
    title_size: int = 16,
    label_size: int = 12,
    tick_size: int = 10,
    legend_size: int = 10,
    linewidth: float = 2.0,
    grid_alpha: float = 0.3,
) -> None:
    """
    设置全书统一的图表样式
    
    参数：
        font_family: 字体家族，None 表示自动检测
        title_size: 标题字号
        label_size: 坐标轴标签字号
        tick_size: 刻度标签字号
        legend_size: 图例字号
        linewidth: 线条宽度
        grid_alpha: 网格透明度
    """
    # 字体设置
    if font_family:
        mpl.rcParams['font.family'] = [font_family, 'sans-serif']
    else:
        # 默认字体检测（macOS / Linux / Windows）
        mpl.rcParams['font.sans-serif'] = [
            'Arial Unicode MS',  # macOS
            'SimHei',           # Windows
            'DejaVu Sans',      # Linux fallback
            'sans-serif'
        ]
    
    # 解决负号显示问题
    mpl.rcParams['axes.unicode_minus'] = False
    
    # 字号设置
    mpl.rcParams['figure.titlesize'] = title_size
    mpl.rcParams['axes.titlesize'] = int(title_size * 0.875)  # axes title = 87.5% of figure title
    mpl.rcParams['axes.labelsize'] = label_size
    mpl.rcParams['xtick.labelsize'] = tick_size
    mpl.rcParams['ytick.labelsize'] = tick_size
    mpl.rcParams['legend.fontsize'] = legend_size
    
    # 线条和标记设置
    mpl.rcParams['lines.linewidth'] = linewidth
    mpl.rcParams['lines.markersize'] = 6
    mpl.rcParams['patch.linewidth'] = 1
    
    # 图表背景
    plt.style.use('seaborn-v0_8-whitegrid')
    
    # 网格设置
    mpl.rcParams['grid.alpha'] = grid_alpha
    mpl.rcParams['grid.linestyle'] = '--'
    mpl.rcParams['grid.color'] = '#666666'


def get_palette(name: str = 'default', n: Optional[int] = None) -> List[str]:
    """
    获取配色方案
    
    参数：
        name: 配色方案名称（default/cool/warm/diverging）
        n: 需要的颜色数量，None 表示返回全部
    
    返回：
        颜色列表
    """
    palette = BOOK_PALETTES.get(name, BOOK_PALETTES['default'])
    if n is None:
        return palette
    return palette[:n]


def get_color(name: str) -> str:
    """
    获取单色
    
    参数：
        name: 颜色名称（primary/secondary/accent/success/warning/neutral）
    
    返回：
        颜色代码
    """
    return BOOK_COLORS.get(name, BOOK_COLORS['primary'])


# ============================================================
# 常用图表配置
# ============================================================
def save_figure(
    filename: str,
    dpi: int = 300,
    formats: Tuple[str, ...] = ('png', 'pdf'),
    facecolor: str = 'white',
    bbox_inches: str = 'tight',
) -> None:
    """
    保存图表（支持多格式）
    
    参数：
        filename: 文件名（不含扩展名）
        dpi: PNG 分辨率
        formats: 保存的格式列表
        facecolor: 背景色
        bbox_inches: 边界框
    """
    from pathlib import Path
    
    output_dir = Path(__file__).parent.parent / 'figures'
    output_dir.mkdir(parents=True, exist_ok=True)
    
    for fmt in formats:
        output_path = output_dir / f'{filename}.{fmt}'
        plt.savefig(
            output_path,
            dpi=dpi if fmt == 'png' else None,
            format=fmt,
            facecolor=facecolor,
            bbox_inches=bbox_inches,
        )
        print(f"✅ {fmt.upper()} 已保存：{output_path}")


# ============================================================
# 快速开始示例
# ============================================================
if __name__ == '__main__':
    """运行此脚本会生成一个测试图，验证样式配置是否正常"""
    import numpy as np
    
    # 设置样式
    setup_book_style()
    
    # 生成测试数据
    x = np.linspace(0, 10, 100)
    y = np.sin(x)
    
    # 绘图
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.plot(x, y, color=get_color('primary'), linewidth=2.5, label='正弦曲线')
    ax.fill_between(x, 0, y, alpha=0.3, color=get_color('primary'))
    
    ax.set_title('图表样式测试', fontweight='bold')
    ax.set_xlabel('X 轴')
    ax.set_ylabel('Y 轴')
    ax.legend()
    ax.grid(True, alpha=0.3)
    
    # 保存
    save_figure('style-test')
    
    plt.show()
