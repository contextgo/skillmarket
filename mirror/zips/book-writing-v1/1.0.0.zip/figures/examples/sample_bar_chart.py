#!/usr/bin/env python3
"""
文件：sample_bar_chart.py
用途：柱状图示例 - 展示分类数据对比
使用场景：适合展示不同类别的数值对比、排名等
"""

import matplotlib.pyplot as plt
import numpy as np
import matplotlib as mpl
from pathlib import Path

# ============================================================
# 全书统一图表样式设置
# ============================================================
def setup_book_style():
    """设置全书统一图表样式"""
    mpl.rcParams['font.sans-serif'] = ['Arial Unicode MS', 'SimHei', 'DejaVu Sans', 'sans-serif']
    mpl.rcParams['axes.unicode_minus'] = False
    mpl.rcParams['figure.titlesize'] = 16
    mpl.rcParams['axes.titlesize'] = 14
    mpl.rcParams['axes.labelsize'] = 12
    mpl.rcParams['xtick.labelsize'] = 10
    mpl.rcParams['ytick.labelsize'] = 10
    mpl.rcParams['legend.fontsize'] = 10
    plt.style.use('seaborn-v0_8-whitegrid')

# ============================================================
# 生成示例数据
# ============================================================
np.random.seed(42)

categories = ['类别A', '类别B', '类别C', '类别D', '类别E', '类别F']
values = [45, 78, 62, 55, 89, 71]

# 生成分组数据（对比两组）
group1 = [45, 78, 62, 55, 89, 71]
group2 = [52, 71, 68, 62, 85, 78]
group3 = [48, 75, 65, 58, 82, 74]

# ============================================================
# 绘图 - 简单柱状图
# ============================================================
setup_book_style()

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))

# 左图：简单柱状图
bars1 = ax1.bar(categories, values, color='#2E86AB', alpha=0.8, edgecolor='white', linewidth=1.5)
ax1.set_title('各类别数值对比', fontweight='bold')
ax1.set_ylabel('数值')
ax1.set_ylim(0, 100)

# 在柱子上添加数值标签
for bar in bars1:
    height = bar.get_height()
    ax1.text(bar.get_x() + bar.get_width()/2., height,
             f'{int(height)}',
             ha='center', va='bottom', fontsize=9)

# 右图：分组柱状图
x = np.arange(len(categories))
width = 0.25

bars2a = ax2.bar(x - width, group1, width, label='组A', color='#2E86AB', alpha=0.8)
bars2b = ax2.bar(x, group2, width, label='组B', color='#A23B72', alpha=0.8)
bars2c = ax2.bar(x + width, group3, width, label='组C', color='#F18F01', alpha=0.8)

ax2.set_title('分组数据对比', fontweight='bold')
ax2.set_ylabel('数值')
ax2.set_xticks(x)
ax2.set_xticklabels(categories)
ax2.set_ylim(0, 100)
ax2.legend(loc='upper right')

# ============================================================
# 保存图片
# ============================================================
output_dir = Path(__file__).parent.parent / 'figures'
output_dir.mkdir(parents=True, exist_ok=True)

output_path = output_dir / 'fig-bar-chart-sample.png'
plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='white')
plt.savefig(output_dir / 'fig-bar-chart-sample.pdf', bbox_inches='tight', facecolor='white')

print(f"✅ 图片已保存至：{output_path}")
plt.close()
