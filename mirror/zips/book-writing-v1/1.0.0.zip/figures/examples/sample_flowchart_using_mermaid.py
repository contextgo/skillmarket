"""
文件：sample_flowchart_using_mermaid.py
用途：说明如何在书中使用 Mermaid 绘制流程图

Mermaid 流程图可以直接嵌入 Markdown，无需使用 Python 生成图片。
本文档展示常用 Mermaid 流程图语法。

在 Markdown 中使用方式：
```mermaid
flowchart TD
    A[开始] --> B[处理]
    B --> C{判断}
    C -->|是| D[方案A]
    C -->|否| E[方案B]
    D --> F[结束]
    E --> F
```
"""

# ========================================
# 常用 Mermaid 流程图示例
# ========================================

# 示例 1：基本流程图（从上到下）
basic_flowchart_td = '''
flowchart TD
    A[开始] --> B[初始化]
    B --> C[数据处理]
    C --> D{检查结果}
    D -->|成功| E[保存数据]
    D -->|失败| F[记录错误]
    E --> G[结束]
    F --> G
'''

# 示例 2：基本流程图（从左到右）
basic_flowchart_lr = '''
flowchart LR
    A[输入] --> B[处理步骤1]
    B --> C[处理步骤2]
    C --> D[输出]
'''

# 示例 3：带子图的流程图
subgraph_flowchart = '''
flowchart TD
    subgraph 第一阶段 [阶段一：准备]
        A1[数据收集] --> A2[数据清洗]
    end
    
    subgraph 第二阶段 [阶段二：分析]
        B1[特征工程] --> B2[模型训练]
    end
    
    subgraph 第三阶段 [阶段三：部署]
        C1[模型评估] --> C2[上线部署]
    end
    
    A2 --> B1
    B2 --> C1
'''

# 示例 4：复杂决策树
decision_tree = '''
flowchart TD
    Start[开始] --> Check{数据充足?}
    Check -->|是| Process[开始处理]
    Check -->|否| Collect[收集更多数据]
    Collect --> Check
    
    Process --> Model{选择模型}
    Model -->|简单| ModelA[线性回归]
    Model -->|复杂| ModelB[神经网络]
    
    ModelA --> Train[训练模型]
    ModelB --> Train
    
    Train --> Eval{评估准确率}
    Eval -->|>85%| Deploy[部署]
    Eval -->|≤85%| Tune[参数调优]
    Tune --> Train
    
    Deploy --> End[完成]
'''

# 示例 5：带样式的流程图
styled_flowchart = '''
flowchart LR
    A[开始节点<br/>Start] -->|标签1| B[中间节点<br/>Middle]
    B -->|标签2| C[结束节点<br/>End]
    
    style A fill:#2E86AB,stroke:#0F4C75,stroke-width:3px,color:#fff
    style B fill:#A23B72,stroke:#6A1B52,stroke-width:2px,color:#fff
    style C fill:#06A77D,stroke:#046A55,stroke-width:3px,color:#fff
    
    linkStyle default stroke:#666,stroke-width:2px
'''

# ========================================
# Mermaid 流程图使用建议
# ========================================

usage_tips = """
## 在书中使用 Mermaid 流程图的建议：

### 1. 布局选择
- **TD (Top-Down)**: 适合垂直展示步骤（如工作流程）
- **LR (Left-Right)**: 适合水平展示（如时间线）

### 2. 节点形状
- `[矩形]`: 普通步骤
- `(圆形)`: 开始/结束节点
- `{菱形}`: 判断/决策节点
- `[(/圆角矩形/)]`: 可选步骤
- `[[平行四边形]]`: 输入/输出

### 3. 子图（subgraph）
- 用于将相关步骤分组
- 适合展示阶段性流程

### 4. 样式（style）
- 使用 `style` 设置节点颜色
- 使用 `linkStyle` 设置连线样式
- 统一使用全书配色方案

### 5. 标签（labels）
- 使用 `|标签|` 为连线添加说明
- 标签应简洁（不超过10字）

### 6. 何时用 Mermaid vs Python
| 场景 | 工具 | 原因 |
|------|------|------|
| 简单流程图 | Mermaid | 直接嵌入，编辑方便 |
| 复杂架构图 | Python (graphviz) | 更灵活，视觉效果好 |
| 数据图表 | Python (matplotlib) | 专业数据可视化 |
| 思维导图 | Mermaid | 简洁直观 |
"""

# ========================================
# 导出为 Markdown 文档（可选）
# ========================================

if __name__ == '__main__':
    # 将所有示例导出为 Markdown 文档，方便查阅
    with open('mermaid_flowchart_examples.md', 'w', encoding='utf-8') as f:
        f.write("# Mermaid 流程图示例\n\n")
        
        f.write("## 1. 基本流程图（TD）\n")
        f.write(f"```mermaid{basic_flowchart_td}```\n\n")
        
        f.write("## 2. 基本流程图（LR）\n")
        f.write(f"```mermaid{basic_flowchart_lr}```\n\n")
        
        f.write("## 3. 带子图的流程图\n")
        f.write(f"```mermaid{subgraph_flowchart}```\n\n")
        
        f.write("## 4. 复杂决策树\n")
        f.write(f"```mermaid{decision_tree}```\n\n")
        
        f.write("## 5. 带样式的流程图\n")
        f.write(f"```mermaid{styled_flowchart}```\n\n")
        
        f.write("## 使用建议\n")
        f.write(usage_tips)
    
    print("✅ Mermaid 示例文档已导出：mermaid_flowchart_examples.md")
