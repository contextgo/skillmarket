# Review & Polish Prompt (English Version)

> **Purpose**: After a chapter is written, conduct a comprehensive review covering logic, language, factual accuracy, style consistency, and provide polishing suggestions.

---

## 🤖 System Prompt

```
You are a professional book review editor with 10+ years of experience editing non-fiction. Your review style is both rigorous and constructive — you catch issues while providing specific, actionable revision suggestions.

Your review dimensions include:

1. **Logic & Structure**
   - Are arguments sound? Are there logical gaps?
   - Are transitions between paragraphs and chapters smooth?
   - Is there redundant or duplicated content?
   - Is the pacing and rhythm appropriate?

2. **Language & Expression**
   - Are sentences clear and easy to understand?
   - Are there ambiguities or poorly expressed ideas?
   - Are technical terms used consistently?
   - Are there typos or grammatical errors?

3. **Facts & Accuracy**
   - Do mentioned data and facts need verification?
   - Are case studies credible?
   - Are citations properly formatted?

4. **Style Consistency**
   - Is the tone consistent throughout the book?
   - Does any section deviate from the intended style?
   - Is the grammatical person (first/second/third) consistent?

5. **Readability & Formatting**
   - Are paragraph lengths reasonable?
   - Are headings and lists used effectively?
   - Would a diagram help clarify something?

Your output format:
- First, an overall assessment (strengths + weaknesses)
- Then, specific issues organized by dimension (with line numbers / quotes)
- For each issue, provide a fix suggestion and a rewrite example
- Finally, optional overall polishing recommendations
```

---

## 💬 User Prompts

### Prompt 1: Full Chapter Review

```
Book title: {{Book Title}}
Chapter: {{Chapter N: Title}}
Style guide summary: {{Briefly summarize core style requirements}}

Below is the complete chapter text:

{{Paste full chapter text}}

Please review along the following dimensions:

1. **Logic & Structure**
   - Are there gaps in the reasoning?
   - Is any content missing that should be added?
   - Is there redundancy that can be cut?
   - Are transitions between paragraphs and sections smooth?

2. **Language & Expression**
   - Are sentences clear?
   - Are there awkward expressions or ambiguities?
   - Are terms used consistently? Are they defined on first use?
   - Are there typos or grammatical errors?

3. **Facts & Accuracy**
   - Are there any factual claims that need verification?
   - Are case studies credible?

4. **Style Consistency**
   - Does it match the intended style?
   - Does the tone need adjustment?

5. **Readability**
   - Are paragraph lengths appropriate?
   - Should headings or lists be added?
   - Would a diagram help?

Output format:
- Overall assessment
- Issue list (with specific quotes and revision suggestions)
- Overall score (1–10)
```

---

### Prompt 2: Language Polish (Text Only)

```
Book title: {{Book Title}}
Style guide: {{Concise, direct / Use "you" / Avoid passive voice, etc.}}

Below is the text to polish:

{{Paste text}}

Please polish the language with these requirements:
1. Preserve the original meaning
2. Improve flow and readability
3. Unify terminology
4. Fix grammar and typos
5. Optimize sentence length and rhythm

Output format:
- **Original paragraph**
  - Issue identified
  - Revised version
  - Explanation of the change

Process paragraph by paragraph.
```

---

### Prompt 3: Logic Gap Detection

```
Book title: {{Book Title}}
Chapter: {{Chapter Title}}
Core argument: {{The chapter's main claim}}

Below is the chapter text:

{{Paste chapter text}}

Please act as a critical reader and find logical flaws:
1. Which claims lack support?
2. Where are there logical jumps?
3. Are there contradictions?
4. Are counterexamples ignored?

For each issue:
- Quote the original text
- Identify the logical problem
- Suggest a fix (e.g., "Add supporting evidence", "Reorder the argument")
```

---

### Prompt 4: Terminology Consistency Check

```
Book title: {{Book Title}}
Domain: {{e.g., "Machine learning", "Fintech"}}

Below is the current chapter text:

{{Paste chapter text}}

Please check:
1. What technical terms appear in this chapter?
2. Is each term clearly defined on first use?
3. Is terminology consistent (e.g., is "algorithm" and "model" used interchangeably)?
4. Are there any不规范的中英文混用?

Output:
- List of terms
- First occurrence locations and definition status
- Inconsistent usage with correction suggestions
- Terms that should go in an appendix glossary (if more than 3)
```

---

### Prompt 5: Readability Optimization

```
Book title: {{Book Title}}
Chapter: {{Chapter Title}}
Target readers: {{Reader positioning}}

Below is the chapter text:

{{Paste chapter text}}

Please suggest readability improvements:

1. **Paragraph optimization**
   - Which paragraphs are too long and should be split?
   - Which paragraphs are too short and could be merged?

2. **Headings & Lists**
   - Are any subheadings needed?
   - Which content should use numbered lists?
   - Which content should use bullet points?

3. **Diagram suggestions**
   - Where would a flowchart make things clearer?
   - Where would an example be more intuitive?
   - Are any data charts needed?

4. **Emphasis & highlights**
   - Which key concepts should be bolded?
   - Where should "Tip" or "Warning" callout boxes be used?

Output an optimized structure suggestion with specific examples.
```

---

### Prompt 6: Book-Wide Style Consistency Check

```
Book title: {{Book Title}}
Style guide: {{Briefly summarize core style}}

Below are sample passages from multiple chapters:

[Chapter X sample]
{{Text}}

[Chapter Y sample]
{{Text}}

[Chapter Z sample]
{{Text}}

Please check for style consistency:
1. Tone differences
2. Grammatical person differences
3. Sentence structure differences
4. Terminology explanation style differences

For inconsistencies, point out the specific issues and provide unification suggestions.
```

---

## 📋 Review Scoring Rubric

| Dimension | Scoring (0–10) | Excellent Indicators |
|-----------|----------------|----------------------|
| Logic | 0–10 | Sound arguments, progressive flow, no gaps |
| Language | 0–10 | Clear, smooth, no redundancy |
| Accuracy | 0–10 | Accurate facts, reliable data, proper citations |
| Style | 0–10 | Matches intended style, consistent throughout |
| Readability | 0–10 | Good formatting, effective use of lists, comfortable pacing |

---

## 🔗 Next Step

After review, if you need to further improve the content, use prompts in [`08-iterative-improvement`](../08-iterative-improvement/).
