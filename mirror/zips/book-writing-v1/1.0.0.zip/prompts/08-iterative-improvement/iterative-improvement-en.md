# Iterative Improvement Prompt (English Version)

> **Purpose**: Based on review feedback, reader feedback, or self-reflection, perform multiple rounds of iterative improvements to continuously enhance content quality.

---

## 🤖 System Prompt

```
You are a writing coach skilled in iterative refinement, knowing how to convert feedback into concrete revision plans. Your approach is:

1. **Accurately Understand Feedback**
   - Identify the core issue behind the feedback (not just surface symptoms)
   - Understand the reader's needs underlying the feedback
   - Distinguish between "must fix" and "optional improvement"

2. **Translate into Actionable Tasks**
   - Turn vague feedback into specific revision instructions
   - Distinguish structural adjustments from language polish
   - Prioritize issues with the highest impact

3. **Maintain Iterative Discipline**
   - Focus each iteration round on addressing a batch of issues
   - Avoid undoing previously optimized changes without confirmation
   - Track iteration history to prevent regression

When processing iterations, you follow:
- Structure first, then language
- Global changes first, then local
- Summarize improvements after each iteration round
```

---

## 💬 User Prompts

### Prompt 1: Iteration Based on Review Feedback

```
Book title: {{Book Title}}
Chapter: {{Chapter N: Title}}

Review feedback summary:
{{Paste review feedback highlights}}

Current chapter text:
{{Paste current chapter text}}

Please make iterative changes based on the feedback:
1. Identify core issues from feedback (prioritized)
2. For each issue, propose a revision plan
3. Execute changes (you may revise only key paragraphs; no need to rewrite the full chapter)
4. Mark changed sections with revision rationale

Output format:
- Prioritized issue list (High / Medium / Low)
- Revision plan
- Revised key paragraphs (with change markers)
- Iteration summary (main improvements this round)
```

---

### Prompt 2: Iteration Based on Reader Feedback

```
Book title: {{Book Title}}
Chapter: {{Chapter N: Title}}

Reader feedback:
{{Paste reader feedback (may be multiple items)}}

Current chapter text:
{{Paste current chapter text}}

Please analyze reader feedback and create a revision plan:
1. Categorize feedback:
   - Content unclear: {{specifics}}
   - Missing examples: {{specifics}}
   - Poor ordering: {{specifics}}
   - Confusing terminology: {{specifics}}

2. For each category, provide revision suggestions
3. Execute changes (if conflicts arise, explain how you weighed them)

Output:
- Feedback analysis report
- Revised key paragraphs
- Notes on feedback not adopted (if any)
```

---

### Prompt 3: Self-Reflection Iteration

```
Book title: {{Book Title}}
Chapter: {{Chapter N: Title}}

Current chapter text:
{{Paste current chapter text}}

Please act as the author doing a self-review and identify potential issues for iteration:
1. Which parts might confuse readers?
2. Which parts feel redundant?
3. Which claims lack support?
4. Where should a diagram be added but wasn't?

Provide:
- Issue list (self-identified)
- Revision plan
- Revised paragraphs
```

---

### Prompt 4: Iteration History Tracking

```
Book title: {{Book Title}}

Current iteration round: Round {{N}}

Below is the revision log from previous rounds:

[Round 1]
- Change 1: {{Description}}
- Change 2: {{Description}}

[Round 2]
- Change 1: {{Description}}
- Change 2: {{Description}}

...

[Round N-1]
- Change 1: {{Description}}
- Change 2: {{Description}}

Planned changes this round:
{{Issues to address this round}}

Please:
1. Summarize the core improvements from previous rounds
2. Ensure this round does not break prior improvements
3. Generate iteration history (Markdown format)
4. Provide suggestions for this round's changes
```

---

### Prompt 5: Iteration Quality Assessment

```
Book title: {{Book Title}}
Chapter: {{Chapter N: Title}}

Round 1 version:
{{Paste round 1 version}}

Round 2 version:
{{Paste round 2 version}}

Round 3 version (current):
{{Paste round 3 version}}

Please assess iteration quality:
1. What did each round improve?
2. Did any content regress during iteration?
3. Is the current version publication-ready?
4. What still needs improvement?

Provide an assessment report and suggestions for the next round (if any).
```

---

### Prompt 6: Multi-Chapter Linked Iteration

```
Book title: {{Book Title}}

Linked chapters:
- Chapter {{X}}: {{Title}}
- Chapter {{Y}}: {{Title}}
- Chapter {{Z}}: {{Title}}

Issue: These chapters have content overlap, contradictions, or ordering problems that require coordinated revision.

Please:
1. Analyze related content across chapters
2. Identify conflict points
3. Provide a coordinated revision plan (ensuring book-wide consistency)
4. Execute changes (key paragraphs per chapter)

Output:
- Conflict analysis report
- Revision plan
- Revised key paragraphs for each chapter
```

---

## 📋 Iteration Prioritization Guidelines

| Priority | Criteria | Examples |
|----------|----------|----------|
| High | Affects core arguments, leads to reader misunderstanding | Logic gaps, term misuse |
| Medium | Affects reading experience but not understanding | Redundant phrasing, overly long paragraphs |
| Low | Polish / optimization | Word choice refinement, formatting tweaks |

---

## 🔗 Related Prompts

- Use [`07-review-polish`](../07-review-polish/) to get review feedback before iteration
- After iteration completes, use review prompts again to validate improvements
