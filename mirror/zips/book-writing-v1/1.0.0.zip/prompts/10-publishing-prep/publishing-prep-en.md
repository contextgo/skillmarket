# Publishing Preparation Prompt (English Version)

> **Purpose**: After manuscript is complete, prepare all publishing-related materials including copyright page information, cover copy, marketing materials, index, and more.

---

## 🤖 System Prompt

```
You are a professional publishing preparation expert, familiar with all aspects of traditional publishing and self-publishing. You understand:

**Core publishing materials include:**
1. **Copyright page**: Title, author info, copyright notice, ISBN, CIP, etc.
2. **Cover copy**: Title, subtitle, cover tagline, author bio
3. **Flap/jacket copy**: Blurbs, key selling points
4. **Marketing copy**: Book description, selling points, target channels
5. **Index**: Term index, name index (if needed)
6. **Back matter**: References, downloadable code, errata page

When working, you follow:
- Industry standards and best practices
- Compelling but honest copy (no exaggeration)
- Consideration of different display channels (e-commerce, bookstores, offline)
- Professional, complete materials that editors can use directly
```

---

## 💬 User Prompts

### Prompt 1: Copyright Page Information

```
Book title: {{Book Title}}
Subtitle: {{Subtitle}}
Author: {{Name}}
Publishing method: {{Traditional / Self-publishing / E-book}}
Publisher (if known): {{Publisher name}}

Please generate copyright page information:

## Basic Book Info
- Title: {{}}
- Subtitle: {{}}
- Author: {{}}
- Author bio (under 300 words): {{}}
- Illustrator (if any): {{}}
- Translator (if any): {{}}

## Publication Info
- Place of publication: {{City}}
- Publisher: {{}}
- Publication date: {{}}
- Edition: {{1st edition}}
- Printing: {{1st printing}}
- Print run: {{e.g., "1–5000 copies"}}

## Copyright Info
- ISBN (if known): {{}}
- CIP data (if known): {{}}
- Copyright notice: {{Suggested standard text}}

## Technical Specs
- Trim size: {{e.g., "16mo"}}
- Imposition: {{}}
- Word count: {{}}
- Page count: {{}}
- Price: {{currency}}
```

---

### Prompt 2: Cover Copy

```
Book title: {{Book Title}}
Subtitle: {{Subtitle}}
Book summary: {{200–300 words}}
Key selling points:
1. {{Point 1}}
2. {{Point 2}}
3. {{Point 3}}
Author bio: {{100–200 words}}
Target readers: {{Description}}
Competing titles: {{1–2 similar books, for differentiation}}

Please write cover copy:

## Front Cover Copy
- Main title (optimization suggestions welcome)
- Subtitle
- Cover tagline(s) (1–2, each under 20 characters)

## Back Cover Copy
- Book description (under 200 words, highlighting core value)
- Author bio (under 150 words)
- Blurbs (if available, or suggest whom to invite)
- Key selling points list (3–5)
- Reader testimonials (if available)

## Flap/Jacket Copy (optional)
- Flap front tagline
- Flap back blurbs
```

---

### Prompt 3: Marketing Copy

```
Book title: {{Book Title}}
Subtitle: {{Subtitle}}
Book summary: {{200–300 words}}
Target readers: {{Description}}
Key selling points: {{List}}
Author background: {{Brief summary}}

Please write marketing copy for:

## E-commerce Product Page
- Product title (with keywords)
- Product description (under 500 words)
- Selling points list (5–7)
- Target audience tags

## Social Media
- WeChat Moments copy (200 words, image suggestions)
- Weibo copy (under 140 chars, hashtags)
- Xiaohongshu copy (visual style, emphasize aesthetics and use cases)

## Book Club / Offline Event
- Event title
- Event description (300 words)
- Highlights list (3)

## Press Release Template
- Headline
- Lead paragraph
- Core content
- Author bio
```

---

### Prompt 4: Blurb Invitation Email

```
Book title: {{Book Title}}
Subtitle: {{Subtitle}}
Book summary: {{200 words}}
Author bio: {{100 words}}
Invited person: {{e.g., "notable author", "industry expert", specific name}}

Please write a blurb invitation email:

## Email Subject
{{Suggested email subject}}

## Email Body
- Self introduction
- Why this person is being invited
- Book positioning and value
- Type of blurb requested (short endorsement / long review)
- Timeline expectations
- How to access manuscript (digital / physical)
- Contact info

## Blurb Template (for ease of use by recommender)
- Endorsement (under 200 words)
- Recommender info (name, title)
```

---

### Prompt 5: Index Generation

```
Book title: {{Book Title}}
Chapter list:
{{List all chapter titles}}

Please generate an index including:

## Term Index
Extract terms from:
- {{Chapter titles}}
- {{Professional terms in body}}
- {{Terms defined on first use}}

Output format:
```
Term | Page/Chapter
---|---
Term A | Chapter X, Chapter Y
Term B | Chapter X
```

## Name Index (if needed)
{{Experts/scholars mentioned in book}}

## Subject Index (if needed)
{{Core themes discussed in book}}
```

---

### Prompt 6: Errata Page Template

```
Book title: {{Book Title}}
Edition: {{1st edition}}
Printing batch: {{1st printing}}

Please generate an errata page template:

```
# {{Book Title}} Errata

## Version Info
- Current version: Edition {{}}, Printing {{}}
- Last updated: {{Date}}
- Note: This errata page is continuously updated. If you discover new errors, please contact {{contact email}}

## Known Errata

| Chapter | Page | Location | Original | Should be | Submitted by |
|---------|-------|-----------|-----------|------------|--------------|
| Chapter X | Page {{N}} | Line {{M}} | {{Incorrect content}} | {{Correct content}} | {{Name}} |
| Chapter X | Page {{N}} | {{Figure number}} | {{Incorrect}} | {{Correct}} | {{Name}} |

## Subscribe to Errata Updates
Readers can scan the QR code or visit {{URL}} to subscribe to errata updates.
```
```

---

## 📋 Publishing Preparation Checklist

```
□ Copyright page information
□ Cover copy (front, back, flap)
□ Marketing copy (e-commerce, social media, offline)
□ Author bio (short 150 words, long 300 words)
□ Blurb invitation emails
□ Index (terms, names, subjects)
□ Reference list
□ Appendix materials
□ Errata page template
□ Author photos (various sizes)
□ Cover design brief
```

---

## 📝 E-commerce Product Page Keywords Reference

| Book Type | High-volume Keywords | Long-tail Keywords |
|-----------|---------------------|-------------------|
| Technical | Programming, Python, Development | Python入门, 数据分析实战 |
| Management | Management, Leadership, Team | 管理实战, 团队建设方法 |
| Self-improvement | Learning, Productivity, Habits | 高效学习, 时间管理 |
```

---

## 🔗 Related Prompts

- For value proposition提炼, refer to [`01-book-concept`](../01-book-concept/)
