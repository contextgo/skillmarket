# Book Concept & Positioning Prompt (English Version)

> **Purpose**: Help authors define the core positioning, title, target audience, and unique value proposition of a book from scratch — building a solid foundation for the entire writing project.

---

## 🤖 System Prompt

```
You are an experienced publishing strategist and book positioning expert with 20+ years in editorial planning across multiple domains. You deeply understand reader psychology and excel at helping authors discover their book's unique value proposition (UVP), transforming vague writing ideas into clear, market-ready publishing concepts.

Your responsibilities are to help authors:
1. Clarify the book's domain and niche
2. Analyze target readers' pain points and needs
3. Articulate the book's core value proposition
4. Generate multiple candidate titles with subtitles
5. Assess market viability

Working principles:
- Always center on reader needs
- Provide specific, actionable advice — not generic platitudes
- Justify every title and positioning recommendation
- Proactively ask clarifying questions when information is insufficient
```

---

## 💬 User Prompts

### Prompt 1: Initial Book Concept Exploration

```
I want to write a book about 【{{Book Topic}}】.

Please help me with the following:

1. **Domain Analysis**
   - What niche does this topic belong to?
   - What similar books already exist? What are their shortcomings?
   - What unique angle can my book take?

2. **Target Reader Profile**
   - Who is the primary reader? (profession, age range, knowledge background)
   - What are their core pain points in this domain?
   - What will they gain after reading this book?

3. **Core Value Proposition**
   - Summarize the book's unique value in one sentence
   - What is the key differentiator from competing books?

4. **Candidate Titles**
   - Provide 5 candidate titles (main title + subtitle)
   - Include a brief explanation for each: why it resonates with target readers

My background information:
- Author background: {{Author's profession/experience}}
- Writing purpose: {{Personal brand / commercial / knowledge sharing, etc.}}
- Expected length: {{Word count or page count}}
- Publication format: {{Traditional publishing / self-publishing / e-book, etc.}}
```

---

### Prompt 2: Title Refinement & Selection

```
Here are my current candidate titles:

{{List your candidate titles}}

Please score each on the following dimensions (1–10) and provide improvement suggestions:

| Title | Appeal | Clarity | Differentiation | SEO Friendliness | Overall Score |
|-------|--------|---------|-----------------|------------------|---------------|
| ...   | ...    | ...     | ...             | ...              | ...           |

Then:
1. Recommend the best title and explain why
2. Provide 3 subtitle variations for the recommended title
3. Flag any potential issues (ambiguity, unclear audience, etc.)
```

---

### Prompt 3: Deep Reader Persona Development

```
Book topic: {{Book Topic}}
Tentative title: {{Title}}

Please build 3 typical target reader personas. Each persona should include:

**Persona {{Number}}: {{Character Name}}**
- Age:
- Occupation:
- Knowledge level: (Beginner / Intermediate / Advanced)
- Core pain points:
- Motivation to buy this book:
- What they expect to be able to do after reading:
- Where they are most likely to discover this book:

Based on these three personas, please recommend:
1. The appropriate difficulty level for the book
2. Content that must be included
3. Content that can be omitted or moved to appendices
```

---

## 📋 Variable Reference

| Variable | Description | Example |
|----------|-------------|---------|
| `{{Book Topic}}` | Core topic of the book | "Python Data Analysis", "Personal Finance" |
| `{{Author's profession/experience}}` | Author's relevant background | "10-year software engineer focused on ML" |
| `{{Writing purpose}}` | Main reason for writing | "Build personal brand, attract consulting clients" |
| `{{Expected length}}` | Planned book length | "150,000 words", "300 pages" |
| `{{Publication format}}` | How the book will be published | "Traditional publishing", "Kindle e-book" |
| `{{Candidate titles}}` | Titles you've considered | One per line |

---

## 💡 Usage Example

**Input:**
```
I want to write a book about "Introduction to Quantum Computing."
Author background: PhD in Physics, 5 years in quantum algorithm research at a tech company
Writing purpose: Popularize quantum computing knowledge, build industry influence
Expected length: 200,000 words
Publication format: Traditional publishing + e-book
```

**Expected output:**
- Positioning focused on the pain point: "tech professionals curious about quantum computing but lacking the math background"
- Candidate titles such as: *Quantum Computing: The Mental Leap from Bits to Qubits*
- Three reader personas: software engineers, students, and tech enthusiasts

---

## 🔗 Next Step

Once your book concept is defined, use the prompts in [`02-table-of-contents`](../02-table-of-contents/) to design the chapter structure.
