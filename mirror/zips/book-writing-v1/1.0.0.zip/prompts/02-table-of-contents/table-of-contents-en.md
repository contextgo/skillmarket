# Table of Contents Design Prompt (English Version)

> **Purpose**: Help authors design a coherent, well-structured chapter outline for their book — ensuring logical flow, proper depth, and complete coverage.

---

## 🤖 System Prompt

```
You are a professional book structure designer and content architect, specializing in creating clear, logical table-of-contents frameworks for non-fiction books. You deeply understand how readers learn and process information, and can decompose complex knowledge systems into well-layered, progressively-structured chapters.

When designing a table of contents, you consider:
1. Reader cognitive load and learning curve
2. Knowledge dependencies and sequencing
3. Information density and length balance across chapters
4. Narrative pacing and reading experience throughout the book
5. Reinforcement and review of key concepts

Design principles:
- Start from the reader's perspective: every chapter must answer "why should I read this?"
- Chapter titles should be both professional and engaging
- Maintain balance in length — no chapter should be too heavy or too light
- Provide clear learning objectives for each chapter
```

---

## 💬 User Prompts

### Prompt 1: Generate Initial Table of Contents

```
Book title: {{Book Title}}
Book summary: {{One paragraph describing the core content and value}}
Target readers: {{Description of target audience}}
Expected number of chapters: {{e.g., "10–15 chapters"}}
Book type: {{Technical / Management / Popular science / Methodology / Biography, etc.}}

Please design a complete table of contents for this book:

1. **Overall Framework**
   - How many parts (sections) will the book have? What is the core theme of each part?
   - Describe each part's role in the book in one sentence.

2. **Detailed Table of Contents**
   Use the following format:

   **Preface** — approx. {{word count}} words

   **Part I: {{Part Name}}**
   - Chapter 1: {{Chapter Title}} (approx. {{word count}} words)
     - Problem this chapter solves:
     - Core content points (3–5):
   - Chapter 2: {{Chapter Title}} (approx. {{word count}} words)
     ...

   **Appendices** (if needed)
   - Appendix A: {{Content}}

   **Afterword** — approx. {{word count}} words

3. **Structure Rationale**
   - Why this structure?
   - What is the logical connection between chapters?
   - Can readers read linearly, or jump to any chapter?
```

---

### Prompt 2: Table of Contents Refinement

```
Here is my current table of contents:

{{Paste your current TOC here}}

Please review and improve from the following angles:

1. **Structural Diagnosis**
   - Which chapters may be too long and should be split?
   - Which chapters are too short and could be merged?
   - Is any important content missing?
   - Is the chapter order optimal?

2. **Title Optimization**
   - Which chapter titles are not compelling enough?
   - Provide 3 alternative titles for those chapters.

3. **Length Recommendations**
   - Suggest a reasonable word count range for each chapter
   - What is the expected total word count for the entire book?

4. **Reader Journey**
   - Describe the reader's learning journey from Chapter 1 to the last chapter
   - How does the reader's understanding evolve at each stage?
```

---

### Prompt 3: Chapter Title Creation

```
Book title: {{Book Title}}
Book tone: {{Academic / Practical & approachable / Narrative, etc.}}

For each chapter topic below, generate 5 candidate titles:
- Consistent with the book's overall tone
- Moderate length (under 15 words)
- Accurately reflects content while sparking reader curiosity

Chapter topic list:
1. {{Chapter Topic 1}}
2. {{Chapter Topic 2}}
3. {{Chapter Topic 3}}
(Add more as needed)

For each group of titles:
- Rate the recommendation level (⭐⭐⭐⭐⭐)
- Explain what makes each title compelling
```

---

### Prompt 4: Table of Contents Logic Audit

```
Please act as a critical reader. After reviewing the following table of contents, raise 10 questions about content completeness and logical flow:

{{Paste your full TOC here}}

Questions may include:
- "Why does Chapter A come before Chapter B?"
- "{{Some topic}} is not covered at all"
- "Do Chapter X and Chapter Y overlap in content?"
- "Is the jump from Chapter X to Chapter Y too abrupt?"

Then, provide improvement suggestions for each question raised.
```

---

## 📋 Variable Reference

| Variable | Description | Example |
|----------|-------------|---------|
| `{{Book Title}}` | Book title | *Deep Learning in Practice* |
| `{{One paragraph describing...}}` | Book summary | "A hands-on guide for engineers" |
| `{{Description of target audience}}` | Reader positioning | "Developers with Python basics" |
| `{{Expected number of chapters}}` | Planned chapters | "12–15 chapters" |
| `{{Book type}}` | Book category | "Technical", "Business management" |
| `{{Word count}}` | Expected words per chapter | "8,000–12,000" |

---

## 💡 Example of a Strong Table of Contents

A well-structured technical book typically follows this pattern:

```
Preface: Why this book was written; what readers will gain

Part I: Foundations (Building understanding)
  Chapter 1: Background & Key Concepts ("What is it?")
  Chapter 2: Core Principles ("Why does it work?")
  Chapter 3: Tools & Environment ("How do I get started?")

Part II: Practice (Hands-on)
  Chapter 4: First complete end-to-end example
  Chapters 5–8: Progressive skill deepening

Part III: Advanced Topics (Synthesis)
  Chapters 9–11: Complex scenarios & best practices

Part IV: Expansion (Broader context)
  Chapter 12: Intersections with other fields
  Chapter 13: Future trends

Appendices: References, quick-reference guides
Afterword: Recommended learning paths
```

---

## 🔗 Next Step

Once your table of contents is finalized, use [`03-outline`](../03-outline/) to generate a detailed outline for each chapter.
