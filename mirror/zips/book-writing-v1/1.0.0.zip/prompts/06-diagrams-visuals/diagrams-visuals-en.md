# Diagrams & Visualizations Prompt (English Version)

> **Purpose**: Help authors design Mermaid diagrams (embedded directly in Markdown) and Python chart scripts (to generate high-quality images for import into Markdown) — making abstract content clearer and more intuitive.

---

## 🤖 System Prompt

```
You are a professional technical visualization expert, skilled at designing clear, accurate, and beautiful diagrams for non-fiction books. You are proficient in:

1. **Mermaid Diagram Syntax** (embeddable in Markdown):
   - flowchart: Flowcharts
   - sequenceDiagram: Sequence diagrams
   - classDiagram: Class diagrams
   - stateDiagram: State machines
   - erDiagram: Entity-relationship diagrams
   - gantt: Gantt charts
   - mindmap: Mind maps
   - pie: Pie charts

2. **Python Data Visualization** (matplotlib, seaborn, plotly):
   - Line charts, bar charts, scatter plots
   - Heatmaps, box plots
   - Network graphs, tree diagrams
   - Custom architecture diagrams

When designing diagrams, you follow:
- Clarity first: Diagrams must be readable independently, without relying on body text
- Simplicity principle: Each diagram should convey only one core message
- Consistency: Unified style across all diagrams (colors, fonts, naming conventions)
- Accessibility: Avoid relying solely on color to distinguish information; consider colorblind readers

Each diagram you provide includes:
- Complete, runnable code
- Suggested figure title
- Suggested insertion location in the text
- Figure caption text
```

---

## 💬 User Prompts

### Prompt 1: Mermaid Flowchart Generation

```
Book title: {{Book Title}}
Chapter: {{Chapter Title}}
Content to visualize: {{Describe the process/relationship/structure}}
Diagram type: Flowchart

Please generate a Mermaid flowchart with these requirements:
- Number of nodes: {{approximately N nodes}}
- Direction: {{Top-to-bottom / Left-to-right}}
- Include decision branches: {{Yes / No}}
- Include loops: {{Yes / No}}

Output format:
1. Mermaid code block
2. Suggested figure title (for caption)
3. Suggested insertion location in the text
4. Brief description of the diagram (under 50 words, for caption)

Example:
\`\`\`mermaid
flowchart TD
    A[Start] --> B{Decision}
    B -->|Yes| C[Step A]
    B -->|No| D[Step B]
    C --> E[End]
    D --> E
\`\`\`
```

---

### Prompt 2: Mermaid System Architecture Diagram

```
System/concept to display: {{Description}}
Component list:
- {{Component 1}}: {{Function}}
- {{Component 2}}: {{Function}}
- {{Component 3}}: {{Function}}

Relationships between components:
- {{Component 1}} → {{Component 2}}: {{Relationship}}
- {{Component 2}} → {{Component 3}}: {{Relationship}}

Please use Mermaid graph syntax to create an architecture diagram:
1. Use boxes (subgraph) to group different types of components
2. Label arrows with relationship descriptions
3. Highlight key paths with different colors or line styles (e.g., dashed lines for optional flows)

If this architecture would look better rendered with Python, also provide a Python version (using matplotlib + networkx or graphviz).
```

---

### Prompt 3: Python Data Chart Script

```
Book title: {{Book Title}}
Chapter: {{Chapter Title}}
Purpose of the chart: {{What data/trend/comparison to show}}
Chart type: {{Line chart / Bar chart / Scatter plot / Heatmap, etc.}}
Data description: {{Describe the data, or provide sample data}}

Please generate a complete Python plotting script with these requirements:
1. Use matplotlib and/or seaborn
2. Complete title, axis labels, and legend
3. Font sizes suitable for print (recommended: title=16, label=13, tick=11)
4. Professional, attractive color scheme (use seaborn palette or custom colors)
5. Save as high-resolution: plt.savefig('figures/filename.png', dpi=300, bbox_inches='tight')
6. Configure fonts for Chinese characters if needed

Script structure:
\`\`\`python
# File: figures/{{filename}}.py
# Description: {{Chart description}}

import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

# Set Chinese font if needed
# ...

# Data
# ...

# Plot
# ...

# Save
plt.savefig('figures/{{filename}}.png', dpi=300, bbox_inches='tight')
plt.show()
\`\`\`

Also provide:
- Markdown reference syntax: `![Caption](./figures/{{filename}}.png)`
- Suggested figure title
- Suggested caption text
```

---

### Prompt 4: Mind Map Generation

```
Chapter topic: {{Topic}}
Core concept: {{Core concept}}
First-level branches:
- {{Branch 1}}
- {{Branch 2}}
- {{Branch 3}}

Sub-concepts per branch (optional):
- {{Branch 1}}: {{Sub 1a}}, {{Sub 1b}}
- {{Branch 2}}: {{Sub 2a}}

Please use Mermaid mindmap syntax:

Requirements:
- Clear hierarchy, maximum 3 levels
- Concise node text (under 8 words per node)
- Balanced distribution — aim for even branch sizes

\`\`\`mermaid
mindmap
  root(({{Core concept}}))
    {{Branch 1}}
      {{Sub 1a}}
      {{Sub 1b}}
    {{Branch 2}}
      {{Sub 2a}}
\`\`\`
```

---

### Prompt 5: Sequence Diagram / Interaction Diagram

```
Scenario description: {{Describe interactions between actors in a system or process}}
Actors:
- {{Actor 1}}
- {{Actor 2}}
- {{Actor 3}}

Interaction steps:
1. {{Actor 1}} sends {{message/operation}} to {{Actor 2}}
2. {{Actor 2}} processes and returns {{result}}
3. ...

Please generate a sequence diagram using Mermaid sequenceDiagram:

Requirements:
- Include all key interaction steps
- Distinguish synchronous calls (solid arrows) from asynchronous calls (dashed arrows)
- Mark key success/failure branches (using alt/else)
- Diagram width should fit within book page (maximum 5 actors recommended)
```

---

### Prompt 6: Book-Wide Diagram Standards

```
Book title: {{Book Title}}
Book type: {{Type}}
Estimated total diagrams: {{approx. N diagrams}}

Please create book-wide diagram usage standards:

1. **Naming conventions**
   - File naming format: fig-{{chapter}}-{{sequence}}-{{short-name}}.png
   - Caption format: Figure {{chapter}}-{{sequence}}: {{Title}}

2. **Color scheme**
   - Primary color: {{Color}}
   - Secondary color: {{Color}}
   - Warning color: {{Color}}
   - Grayscale compatibility (for black-and-white printing)

3. **Diagram type usage guidelines**
   - When to use Mermaid (simple relationship diagrams, flowcharts)
   - When to use Python (data charts, complex architecture diagrams)

4. **Font and font size standards**
   - Font settings for Mermaid diagrams
   - Font sizes for Python diagrams (title/label/tick)

5. **Diagram editing suggestions**
   - Provide a unified Python chart base template (reusable boilerplate code)
```

---

## 📋 Mermaid Diagram Types Quick Reference

```mermaid
%% Flowchart
flowchart LR
    A[Input] --> B[Process] --> C[Output]

%% Sequence diagram
sequenceDiagram
    User->>Server: Request data
    Server-->>User: Return result

%% State diagram
stateDiagram-v2
    [*] --> Initial
    Initial --> Processing: Trigger event
    Processing --> [*]: Complete

%% Mind map
mindmap
  root((Core Theme))
    Branch A
    Branch B
    Branch C
```

---

## 💡 Python Chart Base Template

```python
# figures/base_style.py — Unified book-wide style

import matplotlib.pyplot as plt
import matplotlib as mpl
import seaborn as sns

def setup_book_style():
    """Apply book-wide chart styling"""
    # Chinese fonts (macOS)
    mpl.rcParams['font.family'] = ['Arial Unicode MS', 'SimHei', 'sans-serif']
    mpl.rcParams['axes.unicode_minus'] = False
    
    # Font sizes
    mpl.rcParams['figure.titlesize'] = 16
    mpl.rcParams['axes.titlesize'] = 14
    mpl.rcParams['axes.labelsize'] = 12
    mpl.rcParams['xtick.labelsize'] = 10
    mpl.rcParams['ytick.labelsize'] = 10
    mpl.rcParams['legend.fontsize'] = 10
    
    # Color palette
    sns.set_palette("muted")
    
    # Chart background
    plt.style.use('seaborn-v0_8-whitegrid')

# Call at the beginning of each chart script:
# from base_style import setup_book_style
# setup_book_style()
```

---

## 🔗 Related Directories

- All Python chart scripts go in [`/figures`](../../figures/)
- Include generated images with `![Caption](./figures/filename.png)` in Markdown
