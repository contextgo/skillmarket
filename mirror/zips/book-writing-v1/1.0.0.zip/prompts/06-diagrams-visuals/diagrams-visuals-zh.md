# 图表与可视化 Prompt（中文版）

> **用途**：帮助作者为书中的复杂内容设计 Mermaid 图表（直接嵌入 Markdown）和 Python 图表脚本（生成高质量图片导入 Markdown），让抽象内容更直观易懂。

---

## 🤖 System Prompt（系统提示词）

```
你是一位专业的技术可视化专家，擅长为非虚构书籍设计清晰、准确、美观的图表。你熟练掌握：

1. **Mermaid 图表语法**（可直接嵌入 Markdown）：
   - flowchart：流程图
   - sequenceDiagram：时序图
   - classDiagram：类图
   - stateDiagram：状态机
   - erDiagram：实体关系图
   - gantt：甘特图
   - mindmap：思维导图
   - pie：饼图

2. **Python 数据可视化**（matplotlib、seaborn、plotly）：
   - 折线图、柱状图、散点图
   - 热力图、箱线图
   - 网络图、树状图
   - 自定义架构图

在设计图表时，你遵循：
- 清晰优先：图表要能独立阅读，不依赖正文解释
- 简洁原则：每张图只传达一个核心信息
- 一致性：全书图表风格统一（颜色、字体、命名规范）
- 可访问性：避免仅用颜色区分信息，兼顾色盲读者

你输出的每个图表都会附带：
- 完整可运行的代码
- 图表标题建议
- 插入位置建议（在正文的哪里插入）
- 图表说明文字（图注）
```

---

## 💬 User Prompt（用户提示词）

### Prompt 1：Mermaid 流程图生成

```
书名：{{书名}}
章节：{{章节标题}}
需要可视化的内容：{{描述需要展示的流程/关系/结构}}
图表类型：流程图

请生成一个 Mermaid 流程图，要求：
- 节点数量：{{约N个节点}}
- 流向：{{从上到下/从左到右}}
- 是否包含判断分支：{{是/否}}
- 是否包含循环：{{是/否}}

输出格式：
1. Mermaid 代码块
2. 图表标题（用于图注）
3. 在正文中的建议插入位置
4. 对图表的简短描述文字（50字以内，用于图注）

示例：
\`\`\`mermaid
flowchart TD
    A[开始] --> B{判断条件}
    B -->|是| C[执行步骤A]
    B -->|否| D[执行步骤B]
    C --> E[结束]
    D --> E
\`\`\`
```

---

### Prompt 2：Mermaid 系统架构图

```
需要展示的系统/概念：{{描述}}
组件列表：
- {{组件1}}：{{功能说明}}
- {{组件2}}：{{功能说明}}
- {{组件3}}：{{功能说明}}

组件之间的关系：
- {{组件1}} → {{组件2}}：{{关系描述}}
- {{组件2}} → {{组件3}}：{{关系描述}}

请用 Mermaid graph 语法生成架构图，要求：
1. 使用方框区分不同类型的组件（用 subgraph 分组）
2. 箭头上标注关系说明
3. 关键路径用不同颜色或线型标注（如虚线表示可选流程）

同时，如果这个架构图用 Python 绘制会更好看，也请提供 Python 版本的绘图代码（使用 matplotlib + networkx 或 graphviz）。
```

---

### Prompt 3：Python 数据图表脚本

```
书名：{{书名}}
章节：{{章节标题}}
图表目的：{{这张图要展示什么数据/趋势/对比}}
图表类型：{{折线图/柱状图/散点图/热力图等}}
数据描述：{{描述数据的大致内容，或提供示例数据}}

请生成完整的 Python 绘图脚本，要求：
1. 使用 matplotlib 和/或 seaborn
2. 图表标题、坐标轴标签、图例都要完整
3. 字体大小适合书籍印刷（建议 title=16, label=13, tick=11）
4. 颜色方案专业美观（推荐使用 seaborn palette 或自定义颜色）
5. 保存为高分辨率图片：plt.savefig('figures/图片名.png', dpi=300, bbox_inches='tight')
6. 中文字体设置（如需）

脚本结构：
\`\`\`python
# 文件：figures/{{图片文件名}}.py
# 说明：{{图表说明}}

import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

# 设置中文字体（如需）
# ...

# 数据
# ...

# 绘图
# ...

# 保存
plt.savefig('figures/{{图片文件名}}.png', dpi=300, bbox_inches='tight')
plt.show()
\`\`\`

同时提供：
- 在 Markdown 中引用的语法：`![图注](./figures/{{图片文件名}}.png)`
- 图表标题建议
- 图注文字建议
```

---

### Prompt 4：思维导图生成

```
章节主题：{{主题}}
核心概念：{{核心概念}}
一级分支：
- {{分支1}}
- {{分支2}}
- {{分支3}}

每个分支的子概念（可选）：
- {{分支1}}：{{子概念1a}}、{{子概念1b}}
- {{分支2}}：{{子概念2a}}

请用 Mermaid mindmap 语法生成思维导图：

要求：
1. 层次清晰，最多3级
2. 节点文字简洁（每个节点不超过8个字）
3. 平衡分布，各分支数量尽量均匀

\`\`\`mermaid
mindmap
  root(({{核心概念}}))
    {{分支1}}
      {{子概念1a}}
      {{子概念1b}}
    {{分支2}}
      {{子概念2a}}
\`\`\`
```

---

### Prompt 5：时序图/交互图生成

```
场景描述：{{描述一个系统或流程中各角色之间的交互}}
参与者：
- {{角色1}}
- {{角色2}}
- {{角色3}}

交互步骤：
1. {{角色1}} 向 {{角色2}} 发送 {{消息/操作}}
2. {{角色2}} 处理后返回 {{结果}}
3. ...

请用 Mermaid sequenceDiagram 生成时序图：

要求：
1. 包含所有关键交互步骤
2. 区分同步调用（实线箭头）和异步调用（虚线箭头）
3. 标注关键的成功/失败分支（用 alt/else）
4. 时序图宽度不超过书页宽度（建议参与者不超过5个）
```

---

### Prompt 6：全书图表规范制定

```
书名：{{书名}}
书籍类型：{{类型}}
预计图表总数：{{约N张}}

请制定全书的图表使用规范：

1. **命名规范**
   - 文件命名格式：fig-{{章节编号}}-{{序号}}-{{简短描述}.png
   - 图注格式：图{{章节}-{序号}}：{{标题}}

2. **颜色规范**
   - 主色：{{颜色}}
   - 辅色：{{颜色}}
   - 警告色：{{颜色}}
   - 灰度版本兼容性要求（印刷时可能转为黑白）

3. **图表类型使用规范**
   - 什么情况下用 Mermaid（简单关系图、流程图）
   - 什么情况下用 Python（数据图表、复杂架构图）

4. **字体与字号规范**
   - Mermaid 图表字体设置
   - Python 图表字号设置（title/label/tick）

5. **图表编辑建议**
   - 提供统一的 Python 图表基础样式代码（可复用模板）
```

---

## 📋 常用 Mermaid 图类型速查

```mermaid
%% 流程图示例
flowchart LR
    A[输入] --> B[处理] --> C[输出]

%% 时序图示例
sequenceDiagram
    用户->>服务器: 请求数据
    服务器-->>用户: 返回结果

%% 状态图示例
stateDiagram-v2
    [*] --> 初始状态
    初始状态 --> 处理中: 触发事件
    处理中 --> [*]: 完成

%% 思维导图示例
mindmap
  root((核心主题))
    分支A
    分支B
    分支C
```

---

## 💡 Python 图表基础模板

```python
# figures/base_style.py — 全书统一样式设置

import matplotlib.pyplot as plt
import matplotlib as mpl
import seaborn as sns

def setup_book_style():
    """全书统一图表样式"""
    # 中文字体（macOS）
    mpl.rcParams['font.family'] = ['Arial Unicode MS', 'SimHei', 'sans-serif']
    mpl.rcParams['axes.unicode_minus'] = False
    
    # 字号
    mpl.rcParams['figure.titlesize'] = 16
    mpl.rcParams['axes.titlesize'] = 14
    mpl.rcParams['axes.labelsize'] = 12
    mpl.rcParams['xtick.labelsize'] = 10
    mpl.rcParams['ytick.labelsize'] = 10
    mpl.rcParams['legend.fontsize'] = 10
    
    # 颜色方案
    sns.set_palette("muted")
    
    # 图表背景
    plt.style.use('seaborn-v0_8-whitegrid')

# 在每个绘图脚本开头调用：
# from base_style import setup_book_style
# setup_book_style()
```

---

## 🔗 相关目录

- 所有 Python 绘图脚本存放在 [`/figures`](../../figures/) 目录
- 生成的图片用 `![图注](./figures/文件名.png)` 引入 Markdown
