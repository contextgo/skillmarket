# Chapter Content Writing Prompt (English Version)

> **Purpose**: Based on a finalized outline, drive AI to write actual chapter content. Covers full chapter writing, section-by-section writing, case studies, concept explanations, chapter closings, and technical content with code.

---

## 🤖 System Prompt

```
You are a professional non-fiction book author, skilled at transforming detailed chapter outlines into smooth, in-depth, and persuasive prose. Your writing is characterized by:

[Writing Capabilities]
- Adapts style to different book types (technical tutorials, management methodology, popular science, etc.)
- Explains abstract concepts using concrete examples and analogies
- Maintains professional depth while keeping content highly readable
- Uses headings, lists, and emphasis formatting to enhance readability

[Technical Standards]
- All output uses Markdown formatting
- Embeds Mermaid diagram code where appropriate
- For charts requiring Python generation, provides clear image placeholders with descriptions
- Code examples use standard code block format with language specified

[Content Principles]
- Each paragraph focuses on one core idea
- Theory is immediately followed by examples; examples are followed by practical recommendations
- Avoid vague generalities — all claims must be supported
- Key concepts must be clearly defined the first time they appear

When a visual is needed, use the following format:
- Mermaid diagrams: provide a mermaid code block directly
- Python-generated charts: use `![Description](./figures/filename.png)` format, followed by a note describing what the Python script should generate
```

---

## 💬 User Prompts

### Prompt 1: Full Chapter Writing

```
Book title: {{Book Title}}
Chapter: {{Chapter N: Chapter Title}}
Target readers: {{Description}}
Chapter outline:
{{Paste chapter outline here}}

Writing requirements:
- Word count: {{target word count}} words
- Tone: {{Formal / Conversational / Story-driven / Technical}}
- Language style: {{Concise / Analytical / Example-rich}}
- Mermaid diagrams: {{Yes / No — specify where}}
- Code examples: {{Programming language, or "Not needed"}}

Please write the full chapter body following the outline structure, in Markdown format.
Requirements:
1. Open with an engaging scene or question
2. Smooth transitions between sections
3. Key terms bolded (**term**) or in code format (`term`)
4. Insert visuals at appropriate points (Mermaid or Python placeholder)
5. End with a summary and reflection questions
```

---

### Prompt 2: Section-by-Section Writing

```
Book title: {{Book Title}}
Current chapter: {{Chapter Title}}
Current section: {{Section Title}}
Core argument of this section: {{argument}}
Target word count: {{word count}}

Last paragraph of the previous section (for continuity):
{{Paste ending of previous section}}

Please write this section, with these requirements:
1. Opening naturally connects from the previous section
2. Stays focused on the core argument without drifting
3. Includes at least {{number}} concrete examples or case studies
4. Uses Mermaid diagrams or Python chart placeholders where needed
5. Ends with a transition sentence leading into the next section
```

---

### Prompt 3: Case Study / Opening Story

```
Chapter topic: {{Topic}}
Purpose of the case: {{What argument this case should support}}
Case type: {{Real case / Fictional scenario / Industry archetype}}

Please write an opening story or case study for this chapter:
- Length: {{200–500}} words
- Protagonist: {{Character type, e.g., "a CTO at an early-stage startup"}}
- Setting: {{Specific scenario description}}
- Conflict / Problem: {{The core challenge the protagonist faces}}
- How the story leads into the chapter's core theme

The case should end with a natural transition into the body of the chapter using phrases like "This story reveals..." or "Situations like this are common in..."
```

---

### Prompt 4: Concept Explanation Paragraphs

```
Concept to explain: {{Concept Name}}
Reader background: {{Reader's knowledge level}}
Book type: {{Book Type}}

Please explain this concept in three different ways — I'll choose the most fitting:

**Approach 1: Definition-First**
Give a precise, concise definition, then expand with explanation

**Approach 2: Analogy-Based**
Use a familiar everyday object/experience as an analogy, then transition to the professional explanation

**Approach 3: Problem-Driven**
First present a problem the reader might encounter, then introduce this concept as the solution

Each approach should be {{150–300}} words.
```

---

### Prompt 5: Chapter Closing and Transition

```
Current chapter: {{Chapter Title}}
Core takeaways from this chapter:
1. {{Takeaway 1}}
2. {{Takeaway 2}}
3. {{Takeaway 3}}

Next chapter: {{Next Chapter Title}}
Next chapter theme: {{Brief description}}

Please write:
1. **Chapter Summary** (300–500 words)
   - Recap key content in bullet point form
   - Explain how these points help readers achieve the chapter's goals
   
2. **Transition Paragraph** (100–150 words)
   - Naturally bridge to the next chapter
   - Build anticipation and make readers want to continue

3. **Reflection Questions** (optional)
   - 3 questions that encourage readers to connect theory to their own situation
```

---

### Prompt 6: Technical Content Writing (with Code)

```
Book title: {{Book Title}}
Chapter: {{Chapter Title}}
Technical topic: {{Specific technical topic}}
Programming language: {{Language}}
Reader technical level: {{Beginner / Intermediate / Advanced}}

Please write this technical section with the following structure:
1. 1–2 paragraphs in non-technical language explaining "why this is needed"
2. Explanation of the core principle
3. A complete, runnable code example:
   \`\`\`{{language}}
   # Code example
   \`\`\`
4. Line-by-line annotation of key code parts
5. Description of the expected output (text description or visual)
6. Common mistakes and caveats
7. A practice variation exercise

Code example requirements:
- Must be real and runnable — no pseudocode
- Use meaningful variable names
- Use example data that reflects realistic scenarios
```

---

## 📋 Variable Reference

| Variable | Description | Example |
|----------|-------------|---------|
| `{{Book Title}}` | Book title | *Cloud-Native App Development in Practice* |
| `{{Chapter Title}}` | Current chapter | "Chapter 5: Container Orchestration & Kubernetes" |
| `{{Target word count}}` | Writing length goal | "8,000 words" |
| `{{Tone}}` | Writing tone | "Technical & practical", "Light and accessible" |
| `{{argument}}` | Core claim of the section | "Kubernetes scheduling determines app resilience" |

---

## 📊 Recommended Visual Types

| Content Type | Recommended Visual | Tool |
|-------------|-------------------|------|
| Process / steps | Flowchart | Mermaid flowchart |
| System architecture | Architecture diagram | Mermaid graph / Python |
| Time sequence | Sequence diagram | Mermaid sequenceDiagram |
| Data comparison | Bar chart / line chart | Python matplotlib |
| Concept relationships | Mind map | Mermaid mindmap |
| State transitions | State machine | Mermaid stateDiagram |
| Org structure | Tree diagram | Mermaid graph TD |
| Data distribution | Scatter / box plot | Python seaborn |

---

## 💡 Markdown Writing Template

```markdown
# Chapter N: {{Chapter Title}}

> **Chapter Overview**: {{One sentence: what problem this chapter solves and what readers will learn}}

---

## Opening Scene

{{Engaging story or scenario}}

---

## {{First Section Title}}

{{Body content}}

\`\`\`mermaid
graph TD
    A[Start] --> B[Step 1]
    B --> C[Step 2]
    C --> D[End]
\`\`\`

> 💡 **Tip**: {{Important tip}}

> ⚠️ **Warning**: {{Caution}}

---

## {{Second Section Title}}

{{Body content}}

![{{Image description}}](./figures/{{filename}}.png)
*Figure N-N: {{Figure caption}}*

---

## Chapter Summary

In this chapter, we covered:
- ✅ {{Takeaway 1}}
- ✅ {{Takeaway 2}}
- ✅ {{Takeaway 3}}

## Reflection & Exercises

1. {{Reflection question 1}}
2. {{Reflection question 2}}
3. {{Hands-on exercise}}

---

*The next chapter will cover {{next chapter topic}}, building on what we've learned here...*
```

---

## 🔗 Next Step

After completing chapter writing, use [`05-writing-style`](../05-writing-style/) to review and unify the writing style across the entire book.
