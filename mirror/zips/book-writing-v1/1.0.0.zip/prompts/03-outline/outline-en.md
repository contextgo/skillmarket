# Chapter Outline Writing Prompt (English Version)

> **Purpose**: After finalizing the table of contents, generate detailed writing outlines for each chapter — clearly defining core content, arguments, examples, and structural arrangement for every section.

---

## 🤖 System Prompt

```
You are an experienced non-fiction writing coach, specializing in transforming vague chapter topics into clear, detailed, and actionable writing outlines. You understand the structural differences across book types (technical, management, popular science, etc.) and can design the most appropriate organization based on content characteristics.

When creating chapter outlines, you ensure:
1. Every section has a clear core argument or core skill
2. Arguments unfold following the logic: "Raise the problem → Analyze root causes → Provide solutions → Validate with examples"
3. Appropriate content density — not overly compressed or unnecessarily expanded
4. Examples, charts, or exercises are strategically placed at key points
5. Chapters have clear, cohesive introductions and conclusions

You proactively identify:
- Which content requires supporting diagrams or visuals
- Where code examples should be inserted (for technical books)
- Which claims need data or research citations
- Which content is best formatted as a checklist
```

---

## 💬 User Prompts

### Prompt 1: Detailed Single-Chapter Outline

```
Book title: {{Book Title}}
Chapter: {{Chapter N: Chapter Title}}
Chapter's position in the book: {{Which chapter, what comes before and after}}
Reader state: {{What readers already know before this chapter; what they should master after}}
Expected word count: {{word count}}

Please generate a detailed writing outline for this chapter in the following format:

---

## Chapter Goals
After completing this chapter, readers will be able to:
- [ ] {{Skill / knowledge point 1}}
- [ ] {{Skill / knowledge point 2}}
- [ ] {{Skill / knowledge point 3}}

## Chapter Opening (approx. {{word count}} words)
- Hook: {{How to grab reader interest — story / data / question / scenario}}
- Chapter preview: Tell readers what problem this chapter will solve

## Body Structure

### Section 1: {{Section Title}} (approx. {{word count}} words)
- Core argument:
- How it unfolds:
- Supporting visuals/examples:
- Key concept definitions:

### Section 2: {{Section Title}} (approx. {{word count}} words)
- Core argument:
- How it unfolds:
- Supporting visuals/examples:
- Caveats / common misconceptions:

### Section 3: {{Section Title}} (approx. {{word count}} words)
(Add more sections as needed)

## Chapter Closing (approx. {{word count}} words)
- Key takeaways (3–5 bullet points)
- Bridge to the next chapter
- Further reading / references (optional)
- Exercises / reflection questions (optional):

---

Additional notes:
- Mark which content needs visual support (charts, flowcharts, diagrams)
- Mark which content could be formatted as a "Tip" or "Warning" callout box
```

---

### Prompt 2: Batch Outline Generation for Multiple Chapters

```
Book title: {{Book Title}}
Chapters to outline:

1. Chapter {{N}}: {{Chapter Title}} — Core theme: {{theme}}
2. Chapter {{N}}: {{Chapter Title}} — Core theme: {{theme}}
3. Chapter {{N}}: {{Chapter Title}} — Core theme: {{theme}}

Overall book style: {{Practical technical / Theoretical depth / Story-driven / Mixed}}
Target readers: {{Description}}

Please generate a condensed outline for each chapter (500–800 words per outline), including:
- Chapter core value (1–2 sentences)
- Main section titles (4–6)
- Core content points per section (2–3 each)
- Recommended visual/example types
- Recommended word count
```

---

### Prompt 3: Outline Logic Review

```
Here is the outline for Chapter {{N}}:

{{Paste outline here}}

Please diagnose from the following angles:

1. **Logical completeness**: Are there logical gaps in the outline? Can readers follow the reasoning?
2. **Content balance**: Is the content volume balanced across sections?
3. **Practicality**: Is there sufficient examples and hands-on content for technical sections?
4. **Missing content**: Are there any obvious gaps in knowledge coverage?
5. **Redundancy**: Are there sections that could be cut or merged?

Provide a revised version of the outline.
```

---

### Prompt 4: Chapter Knowledge Map

```
Chapter topic: {{Chapter Topic}}

Please build a knowledge map for this chapter using Mermaid syntax:

Requirements:
- Show relationships between concepts
- Distinguish "core concepts" from "extended concepts"
- Mark which concepts are covered in detail vs. only mentioned

Output format:
1. Mermaid code (mindmap or graph type)
2. Map explanation: describe the relationships between nodes

Example output:
\`\`\`mermaid
mindmap
  root((Chapter Topic))
    Core Concept A
      Sub-concept A1
      Sub-concept A2
    Core Concept B
      Sub-concept B1
    Extended Concept C
\`\`\`
```

---

## 📋 Variable Reference

| Variable | Description | Example |
|----------|-------------|---------|
| `{{Book Title}}` | Book title | *Machine Learning Engineering in Practice* |
| `{{Chapter N: Chapter Title}}` | Chapter label and title | "Chapter 3: The Art of Feature Engineering" |
| `{{Chapter's position}}` | Preceding and following chapters | "Previous chapter: data cleaning; next: model training" |
| `{{Reader state}}` | Prior knowledge and expected outcome | "Knows Python basics; can do feature engineering independently after" |
| `{{Expected word count}}` | Target chapter length | "10,000–12,000 words" |

---

## 💡 Outline Writing Tips

**Characteristics of a great outline:**
- Each section title can independently answer "what does this section cover?"
- Clear problem-solution correspondence throughout
- Appropriate ratio of examples to theory (typically 3:7 to 5:5 for technical books)
- Explicit placement for key definitions and core formulas

**Common outline mistakes:**
- Overly generic section titles ("Basic Concepts", "Common Methods")
- Missing transitional logic between sections
- No concrete examples planned for abstract concepts
- No summary or exercises at chapter end

---

## 🔗 Next Step

Once your outline is complete, use [`04-chapter-writing`](../04-chapter-writing/) prompts to write the actual chapter content.
