# Introduction & Afterword Prompt (English Version)

> **Purpose**: Write high-quality front matter (preface/foreword/introduction) and back matter (afterword/acknowledgments) that create a strong first impression and provide a satisfying conclusion.

---

## 🤖 System Prompt

```
You are a professional book opening and closing specialist, well-versed in the art of writing effective introductions and afterwords. You understand:

**Role of an Introduction:**
- Establish connection with readers; explain "why I wrote this book"
- Convey the book's core value and what readers will gain
- Explain the book's structure and how to use it
- Set the tone for the main content

**Role of an Afterword:**
- Reflect on the writing journey and emotionally resonate with readers
- Add content that didn't fit in the main text
- Thank those who helped
- Provide readers with next steps and resources

When writing, you pay attention to:
- Authenticity and sincerity; avoid empty clichés
- Warmth; show the author's personality
- Appropriate length (preface typically 3,000–8,000 words)
- Consistency with main text style while allowing for more personal voice
```

---

## 💬 User Prompts

### Prompt 1: Preface / Self-Introduction

```
Book title: {{Book Title}}
Subtitle: {{Subtitle}}
Book summary: {{100–200 words overview}}
Target readers: {{Description}}
Writing background:
- {{Why I wrote this book}}
- {{Author's relevant background / experience}}
- {{What pain points this book addresses}}

Book structure:
{{Briefly describe parts and what each covers}}

Please write a preface (self-introduction) with these requirements:
1. Word count: {{3,000–5,000}} words
2. Tone: {{Sincere / Professional / Warm}}
3. Include:
   - Opening: A story or data point to hook the reader
   - Motivation: Why write this book, what problem does it solve?
   - Reader personas: Who this book is for (and who it's not for)
   - Value promise: What readers will gain
   - Usage guide: How to read this book (linear / skip around / with exercises)
   - Structure overview: What each part covers
   - Acknowledgments: Brief thanks to key people (optional)

Style requirements:
- Match main text style
- Slightly more personal than main text; show your authentic side
- No empty clichés; every paragraph must have substance
```

---

### Prompt 2: Foreword Invitation & Framework

```
Book title: {{Book Title}}
Subtitle: {{Subtitle}}
Book summary: {{100–200 words}}
Author bio: {{Author background}}
Invited person: {{e.g., "domain expert", "well-known author", specific person}}

Please help me prepare:
1. **Foreword invitation email**
   - Email format
   - Explain why I'm inviting this person
   - Book positioning and value
   - Expected delivery date

2. **Foreword writing guide** (to share with the invitee)
   - Recommended length: {{1,500–3,000}} words
   - Recommended content:
     - Evaluation of the book's value
     - Connection to the author or topic
     - Reason for recommendation
     - Advice for readers
   - Recommended tone: {{Authoritative / Warmly supportive}}
   - Deadline

3. **Foreword outline template**
   - Provide a framework to guide the invitee
```

---

### Prompt 3: Afterword / Postscript

```
Book title: {{Book Title}}
Book content recap: {{Brief overview}}
Writing journey: {{From concept to completion}}
Message to readers: {{Thanks, encouragement, future outlook}}
Follow-up resources: {{Recommended reading, courses, websites, etc.}}

Please write an afterword with these requirements:
1. Word count: {{2,000–4,000}} words
2. Include:
   - Reflection: The journey from initial idea to completed manuscript
   - Gains: What I learned, challenges faced, regrets
   - Acknowledgments: Thank all who helped (family, colleagues, editors, beta readers)
   - Next steps: Advice for readers' continued learning, recommended resources
   - Closing: A warm, powerful ending that resonates

Style requirements:
- More personal and emotional than the preface
- Sincere; don't avoid mentioning shortcomings
- Can include "behind-the-scenes" stories
```

---

### Prompt 4: Acknowledgments

```
Book title: {{Book Title}}
People and organizations to thank:
- {{Family / Partner}}
- {{Colleagues / Mentors}}
- {{Editor / Publisher}}
- {{Beta readers / feedback contributors}}
- {{Others}}

Please write the acknowledgments with these requirements:
1. Word count: {{800–1,500}} words
2. Structure:
   - Opening: Why acknowledgments matter
   - Categorized thanks:
     - Family: Support and understanding
     - Mentors: Guidance and inspiration
     - Colleagues: Collaboration and discussions
     - Readers: Feedback and suggestions
   - Closing: Final expression of gratitude

Style requirements:
- Sincere and specific (avoid generic "I thank everyone who helped")
- Include concrete stories or acts of help
- Warm tone
```

---

### Prompt 5: How to Use This Book Guide

```
Book title: {{Book Title}}
Book structure: {{Number of parts, chapter themes}}
Target readers: {{Types}} (multiple possible)

Please write the "How to Use This Book" section for the introduction:
1. Provide different reading paths for different reader types:
   - Type 1: {{e.g., "Beginners"}}
     - Recommended order: {{Chapter sequence}}
     - Key chapters: {{}}
     - Should they do exercises? {{Yes/No}}
   - Type 2: {{e.g., "Experienced practitioners"}}
     - Recommended order: {{}}
     - Key chapters: {{}}
   - Type 3: {{e.g., "Quick reference"}}
     - How to skim: {{}}

2. Explain usage of special elements in the book:
   - {{Code examples}}
   - {{Diagrams}}
   - {{Exercises}}
   - {{Tip callouts}}

3. Estimated learning time: {{e.g., "{{X}} hours/days to complete the book"}}
```

---

## 📋 Preface / Afterword Structure Templates

### Preface Structure
```
1. Engaging opening (story / data / question)
2. Why I wrote this book (motivation)
3. Who this book is for (reader personas)
4. What readers will gain (value promise)
5. How to use this book (reading guide)
6. Book structure overview
7. Acknowledgments (optional)
```

### Afterword Structure
```
1. Writing journey reflection
2. Gains and learnings
3. Regrets and areas for improvement
4. Acknowledgments (detailed version)
5. Reader advice and recommended resources
6. Warm closing
```

---

## 🔗 Next Step

After the introduction and afterword are complete, use [`10-publishing-prep`](../10-publishing-prep/) to prepare publishing-related materials.
