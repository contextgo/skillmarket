# Writing Style Definition & Consistency Prompt (English Version)

> **Purpose**: Help authors define, lock in, and maintain a consistent writing style throughout the entire book — ensuring language, tone, and expression remain cohesive from the first page to the last.

---

## 🤖 System Prompt

```
You are a professional style analyst and writing style consultant, specializing in analyzing, defining, and maintaining consistency in book writing styles. You are familiar with the full spectrum of non-fiction writing styles — from rigorous academic works to casual business reads, from richly illustrated technical manuals to immersive narrative popular science books.

Your core capabilities include:
1. Extracting core stylistic characteristics from sample texts
2. Crafting a tailored Style Guide for a book
3. Detecting deviations from the defined style and providing correction suggestions
4. Allowing natural variation across chapters while maintaining overall stylistic unity

Dimensions you use to evaluate writing style:
- Sentence structure: ratio of long vs. short sentences, sentence complexity
- Voice/Tone: formal / informal, person (1st/2nd/3rd), active vs. passive voice
- Vocabulary: density of technical terms, use of slang or colloquialisms
- Structure: paragraph length, use of lists and headings
- Figurative language: frequency of analogies, metaphors, and storytelling
- Pacing: information density, breathing room, rhythm
```

---

## 💬 User Prompts

### Prompt 1: Writing Style Definition

```
Book title: {{Book Title}}
Target readers: {{Description}}
Book type: {{Technical / Business / Popular science / Methodology}}
Desired reader experience: How should readers feel after reading? (e.g., "rigorous but engaging", "like a conversation with a friend")

Style references (optional): I'd like my book's style to resemble:
- {{Reference book 1}}
- {{Reference book 2}}

Please create a detailed Writing Style Guide for this book, including:

## 1. Voice & Person
- Which grammatical person should be used? (Recommended: "you" for technical books, "we" for academic)
- Tone positioning: {{Formal / Neutral / Warm / Humorous}}
- Is conversational language acceptable?

## 2. Sentence Style Standards
- Recommended sentence length (word count)
- Suggested long-to-short sentence ratio
- Are rhetorical questions allowed? Exclamations?

## 3. Vocabulary Standards
- Technical terms: how should they be introduced? Should original language (e.g., English terms in Chinese text) be included?
- Prohibited word list (e.g., vague words like "many", "some", "very")
- Recommended replacement expressions

## 4. Structure Standards
- Recommended paragraph length
- When to use numbered lists vs. bullet points
- Heading hierarchy standards

## 5. Special Elements
- Usage guidelines for callout boxes (Tip / Note / Warning)
- How to write case study stories
- Data citation format
- Code comment style

## 6. Style Don'ts
- List 5–10 "don't write it this way" rules
```

---

### Prompt 2: Style Sample Analysis

```
Please analyze the writing style of the following text excerpt and advise whether I should adopt it for my book:

[Text Sample]
{{Paste a 200–500 word sample of a style you like}}

Analyze along these dimensions:
1. Average sentence length and complexity
2. Person and tone used
3. Technical vocabulary density and explanation approach
4. Frequency of metaphors and analogies
5. Paragraph pacing and information density
6. Strengths and limitations of this style

Then tell me:
- What type of readers does this style suit best?
- For my book ({{Book Title}}, target readers: {{Readers}}), is this style recommended?
- If adopted, what adjustments should be made?
```

---

### Prompt 3: Style Audit & Correction

```
Below is a passage from my book. Please check whether it conforms to the following style guidelines:

[Style Guidelines Summary]
- Tone: {{Warm, use "you", avoid passive voice}}
- Sentences: {{Avoid sentences over 40 words; prefer short sentences}}
- Vocabulary: {{Avoid vague words like "some", "many"; include original term for technical jargon}}

[Text to Audit]
{{Paste text here}}

Please:
1. Flag all instances that deviate from the style guide (quote the original text)
2. Explain what the issue is
3. Provide a revised version
4. Give an overall style consistency score (1–10)
```

---

### Prompt 4: Cross-Chapter Style Consistency Check

```
Below are sample passages from different chapters of the book. Please check for style consistency:

[Chapter X Sample]
{{Text}}

[Chapter Y Sample]
{{Text}}

[Chapter Z Sample]
{{Text}}

Please analyze:
1. How different are the styles across the three passages?
2. Which differences are acceptable natural variation (e.g., technical chapters being more precise)?
3. Which differences need correction to maintain overall book consistency?
4. Which sample is closest to the ideal style? Use it as a benchmark to give specific revision suggestions for the other two.
```

---

### Prompt 5: Style Adaptation for Specific Content Types

```
Book title: {{Book Title}}
Style Guide summary: {{Brief description of your defined style}}

I need to write the following types of content. Please advise how to make appropriate micro-adjustments while maintaining the overall style:

1. **Technical concept explanation**: How to stay professional without sacrificing readability?
2. **Warning / Note callout boxes**: What tone and wording works best?
3. **Chapter opening story**: How should the style differ from the main body text?
4. **Data and research citations**: How to weave them naturally into the narrative rather than listing them mechanically?
5. **Step-by-step instructions**: Should they be imperative ("Do X") or descriptive ("You should X")?

Provide a writing example under 300 words for each content type.
```

---

## 📋 Variable Reference

| Variable | Description | Example |
|----------|-------------|---------|
| `{{Book Title}}` | Book title | *The Growth Hacker's Playbook* |
| `{{Target readers}}` | Reader positioning | "Product managers at startups" |
| `{{Book type}}` | Book category | "Business methodology" |
| `{{Reference book}}` | Style reference | *The Lean Startup*, *Principles* |

---

## 💡 Common Book Style Reference Guide

| Book Type | Recommended Style | Examples |
|-----------|------------------|---------|
| Technical tutorial | Clear, step-oriented, code-driven | *Python Crash Course* |
| Business management | Opinionated, story-rich, inspiring | *Good to Great* |
| Popular science | Vivid, analogy-heavy, accessible | *Sapiens* |
| Academic work | Rigorous, well-cited, logically tight | Academic monographs |
| Methodology | Framework-clear, actionable, well-exemplified | *The Pyramid Principle* |
| Self-improvement | Encouraging, relatable, practical | *Atomic Habits* |

---

## 🔗 Next Step

Once the style is defined, reference the Style Guide while writing each chapter. During the review phase, use [`07-review-polish`](../07-review-polish/) prompts to perform style checks.
