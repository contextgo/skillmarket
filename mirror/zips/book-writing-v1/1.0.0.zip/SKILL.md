---
name: awesome-ai-book-writing
description: 一个专门的AI辅助书籍创作技能,帮助作者从概念到出版完成整本书的创作流程。包含20个精心设计的prompt(10个分类,中英文各1个)、Python图表生成脚本、Markdown写作模板,以及从书籍定位到出版准备的完整创作流程。
---

# Awesome AI Book Writing Skill

一个专门的AI辅助书籍创作技能,帮助作者从概念到出版完成整本书的创作流程。

## 技能概述

这个skill提供了完整的AI辅助书籍创作工具链,包括:
- 20个精心设计的prompt(10个分类,中英文各1个)
- Python脚本支持图表生成
- Markdown写作模板
- 全流程指导(从书籍定位到出版准备)

## 何时使用此skill

当用户需要以下任何任务时,使用此skill:
- 计划或开始写一本书
- 需要设计书籍结构、目录、大纲
- 需要撰写具体章节
- 需要优化写作风格
- 需要创建图表或可视化内容
- 需要审阅和润色书稿
- 需要准备出版材料

## 核心能力

### 1. 项目初始化

帮助用户在本地创建完整的书籍项目结构:

```bash
# 项目结构
awesome-ai-book-writing/
├── prompts/              # Prompt合集
│   ├── 01-book-concept/
│   ├── 02-table-of-contents/
│   ├── 03-outline/
│   ├── 04-chapter-writing/
│   ├── 05-writing-style/
│   ├── 06-diagrams-visuals/
│   ├── 07-review-polish/
│   ├── 08-iterative-improvement/
│   ├── 09-book-intro-conclusion/
│   └── 10-publishing-prep/
├── figures/              # Python绘图脚本
├── templates/           # Markdown模板
├── README.md
└── PROJECT_SUMMARY.md
```

### 2. Prompt分类与用途

| # | 分类 | 主要功能 | 中文版 | 英文版 |
|---|------|---------|--------|--------|
| 01 | 书籍定位 | 定义书名、目标读者、核心价值 | ✅ | ✅ |
| 02 | 目录设计 | 创建书籍目录结构 | ✅ | ✅ |
| 03 | 大纲撰写 | 生成章节详细大纲 | ✅ | ✅ |
| 04 | 章节撰写 | 撰写具体章节内容 | ✅ | ✅ |
| 05 | 写作风格 | 定义和调整写作风格 | ✅ | ✅ |
| 06 | 图表可视化 | 创建Mermaid流程图、Python图表 | ✅ | ✅ |
| 07 | 审阅润色 | 检查语法、逻辑、一致性 | ✅ | ✅ |
| 08 | 迭代优化 | 根据反馈改进内容 | ✅ | ✅ |
| 09 | 前言后记 | 撰写前言和后记 | ✅ | ✅ |
| 10 | 出版准备 | 准备营销文案、封面描述等 | ✅ | ✅ |

### 3. 图表与可视化支持

#### Mermaid图表
- 流程图
- 时序图
- 思维导图
- 甘特图

#### Python图表
- 折线图 (趋势分析)
- 柱状图 (数据对比)
- 散点图 (关系分析)
- 热力图 (矩阵分析)

提供统一样式配置,确保全书视觉一致性。

### 4. 模板支持

- **章节模板** (`chapter-template.md`): 标准章节结构
- **全书结构模板** (`book-structure-template.md`): 完整书籍组织方式

## 使用工作流程

### 阶段1: 规划阶段

1. **书籍定位** (`prompts/01-book-concept/`)
   - 使用 `book-concept-zh.md` 或 `book-concept-en.md`
   - 定义书名、目标读者、核心价值、竞争分析

2. **目录设计** (`prompts/02-table-of-contents/`)
   - 使用 `table-of-contents-zh.md` 或 `table-of-contents-en.md`
   - 创建清晰的章节结构

3. **大纲撰写** (`prompts/03-outline/`)
   - 使用 `outline-zh.md` 或 `outline-en.md`
   - 为每个章节生成详细大纲

### 阶段2: 写作阶段

4. **章节撰写** (`prompts/04-chapter-writing/`)
   - 使用 `chapter-writing-zh.md` 或 `chapter-writing-en.md`
   - 撰写具体章节内容

5. **写作风格** (`prompts/05-writing-style/`)
   - 使用 `writing-style-zh.md` 或 `writing-style-en.md`
   - 定义和调整写作风格

6. **图表创建** (`prompts/06-diagrams-visuals/`)
   - 使用 `diagrams-visuals-zh.md` 或 `diagrams-visuals-en.md`
   - 创建Mermaid流程图或使用Python生成图表

### 阶段3: 优化阶段

7. **审阅润色** (`prompts/07-review-polish/`)
   - 使用 `review-polish-zh.md` 或 `review-polish-en.md`
   - 检查语法、逻辑、一致性

8. **迭代优化** (`prompts/08-iterative-improvement/`)
   - 使用 `iterative-improvement-zh.md` 或 `iterative-improvement-en.md`
   - 根据反馈改进内容

### 阶段4: 收尾阶段

9. **前言后记** (`prompts/09-book-intro-conclusion/`)
   - 使用 `book-intro-conclusion-zh.md` 或 `book-intro-conclusion-en.md`
   - 撰写前言和后记

10. **出版准备** (`prompts/10-publishing-prep/`)
    - 使用 `publishing-prep-zh.md` 或 `publishing-prep-en.md`
    - 准备营销文案、封面描述、作者简介等

## Python图表使用指南

### 安装依赖

```bash
cd figures/
pip install -r requirements.txt
```

### 运行示例

```bash
# 生成折线图
python examples/sample_line_chart.py

# 生成柱状图
python examples/sample_bar_chart.py
```

### 自定义图表

1. 导入统一样式配置:
```python
from examples.base_style import BOOK_STYLE
```

2. 应用样式:
```python
plt.style.use(BOOK_STYLE)
```

3. 生成图片并保存到 `figures/output/` 目录

4. 在Markdown中引用:
```markdown
![图表名称](../figures/output/your_chart.png)
```

## 快速开始

### 方法1: 查看现有项目

如果已存在项目,直接打开对应的prompt文件查看。

### 方法2: 创建新项目

1. 确认用户想要创建新书籍项目
2. 询问项目基本信息:
   - 书籍主题/领域
   - 目标读者
   - 书籍类型(教程、技术书、商业书等)
   - 语言偏好(中文/英文)

3. 在合适的位置创建项目目录
4. 复制所有prompt文件和模板
5. 根据用户需求初始化配置

### 方法3: 直接提供Prompt

用户可以直接使用现有的prompt文件,无需创建完整项目结构。

## Prompt文件说明

每个prompt文件包含:
- **System Prompt**: 系统角色定义
- **User Prompt**: 具体任务描述
- **变量说明**: 需要替换的占位符
- **使用示例**: 如何使用该prompt

### 示例: 书籍定位Prompt

**中文版**: `prompts/01-book-concept/book-concept-zh.md`

**英文版**: `prompts/01-book-concept/book-concept-en.md`

## 工具和资源

### 内置工具
- `execute_command`: 创建目录、运行Python脚本
- `read_file`: 读取现有prompt文件
- `write_to_file`: 创建新文件或修改现有文件
- `search_file`: 查找特定prompt

### 外部资源
- Mermaid官方文档: https://mermaid.js.org/
- Matplotlib官方文档: https://matplotlib.org/
- Seaborn官方文档: https://seaborn.pydata.org/

## 最佳实践

1. **按顺序使用prompt**: 从01到10,按照创作流程使用
2. **保持一致性**: 使用统一样式配置,确保全书风格一致
3. **版本控制**: 使用Git跟踪每次修改
4. **定期备份**: 保存重要的草稿和最终版本
5. **结合使用**: 将不同prompt组合使用,发挥最大效果

## 常见问题

### Q: 如何选择使用中文还是英文版prompt?
A: 根据目标书籍的语言选择。中文书籍使用中文版prompt,英文书籍使用英文版prompt。

### Q: 可以修改prompt内容吗?
A: 可以。prompt文件是完全可定制的,根据具体需求调整变量和说明。

### Q: Python图表需要编程基础吗?
A: 提供了详细的示例脚本,直接修改数据即可,无需深入编程知识。

### Q: Mermaid图表和Python图表如何选择?
A:
- **Mermaid**: 流程图、思维导图、概念图 - 适合展示逻辑关系
- **Python**: 数据图表、统计图 - 适合展示数据和趋势

### Q: 可以跨平台使用吗?
A: 可以。prompt文件是Markdown格式,可在任何AI工具中使用。Python脚本需要Python环境。

## 扩展和定制

### 添加新的prompt分类
1. 在`prompts/`目录下创建新文件夹
2. 创建中英文两个版本的prompt文件
3. 在README.md中更新文档

### 自定义样式
1. 修改`figures/examples/base_style.py`
2. 调整颜色、字体、图表大小等参数

### 创建新模板
1. 在`templates/`目录下创建新模板文件
2. 遵循现有模板的结构和格式

## 项目维护

- 定期更新prompt以适应新的AI模型
- 根据用户反馈优化内容
- 添加新的图表类型和模板
- 保持中英文版本的同步更新

## 参考资源

- [GitHub项目](https://github.com/yourusername/awesome-ai-book-writing)
- [AI写作最佳实践](#)
- [出版行业指南](#)

---

**版本**: 1.0.0
**最后更新**: 2026-04-01
**维护者**: Awesome AI Book Writing Team
