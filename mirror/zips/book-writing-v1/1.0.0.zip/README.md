# Awesome AI Book Writing - Skill

一个专门的AI辅助书籍创作技能,帮助作者从概念到出版完成整本书的创作流程。

## 安装

此skill已安装到本地WorkBuddy技能库中,可直接使用。

## 快速开始

当您需要开始写作一本书时,只需要说:

- "我想写一本关于[主题]的书"
- "帮我设计一本书的结构"
- "我需要写一个章节的内容"
- "帮我润色这段文字"

WorkBuddy会自动加载此skill并提供相应的prompt和工具。

## 主要功能

### 10个创作阶段

1. **书籍定位** - 定义书名、目标读者、核心价值
2. **目录设计** - 创建清晰的章节结构
3. **大纲撰写** - 为每个章节生成详细大纲
4. **章节撰写** - 撰写具体章节内容
5. **写作风格** - 定义和调整写作风格
6. **图表可视化** - 创建Mermaid流程图、Python图表
7. **审阅润色** - 检查语法、逻辑、一致性
8. **迭代优化** - 根据反馈改进内容
9. **前言后记** - 撰写前言和后记
10. **出版准备** - 准备营销文案、封面描述等

### 中英双语支持

所有prompt都提供中英文两个版本,根据您的书籍语言选择使用。

### 图表工具

- **Mermaid**: 流程图、思维导图、时序图
- **Python**: 折线图、柱状图、散点图、热力图

### 模板系统

- 章节模板
- 全书结构模板

## 使用示例

### 示例1: 创建新书籍项目

```
你: 我想写一本关于Python编程的入门书,面向零基础读者

AI: 好的,我会帮你创建一个完整的书籍项目。让我使用AI书籍创作工具...
```

### 示例2: 撰写章节

```
你: 帮我写第3章的内容,主题是"变量与数据类型"

AI: 好的,我会使用章节写作prompt来帮助你...
```

### 示例3: 创建图表

```
你: 我需要一个流程图来展示Python程序执行流程

AI: 好的,我会创建一个Mermaid流程图...
```

## 文件结构

```
skill-awesome-ai-book-writing/
├── SKILL.md                    # 技能完整文档
├── skill-config.json           # 技能配置
├── README.md                   # 快速开始指南
├── prompts/                    # Prompt合集
│   ├── 01-book-concept/
│   ├── 02-table-of-contents/
│   ├── 03-outline/
│   ├── 04-chapter-writing/
│   ├── 05-writing-style/
│   ├── 06-diagrams-visuals/
│   ├── 07-review-polish/
│   ├── 08-iterative-improvement/
│   ├── 09-book-intro-conclusion/
│   └── 10-publishing-prep/
├── figures/                    # Python绘图脚本
│   ├── examples/
│   │   ├── base_style.py
│   │   ├── sample_bar_chart.py
│   │   ├── sample_line_chart.py
│   │   └── sample_flowchart_using_mermaid.py
│   ├── requirements.txt
│   └── output/
└── templates/                   # Markdown模板
    ├── book-structure-template.md
    └── chapter-template.md
```

## 更多信息

查看 [SKILL.md](./SKILL.md) 获取完整的技能文档和使用指南。

## 版本历史

- **1.0.0** (2026-04-01) - 初始版本发布
  - 20个prompt文件(10个分类,中英文各1个)
  - 4个Python绘图脚本
  - 2个Markdown模板
  - 完整文档
