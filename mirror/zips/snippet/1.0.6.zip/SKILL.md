---
name: Snippet
description: "Save and search code snippets in a personal vault for instant recall. Use when checking syntax, validating blocks, generating boilerplate, formatting code."
version: "2.0.0"
author: "BytesAgain"
homepage: https://bytesagain.com
source: https://github.com/bytesagain/ai-skills
tags: ["snippet","code","manager","clipboard","template","cheatsheet","developer"]
categories: ["Developer Tools", "Productivity"]
---

# Snippet — Developer Tools Toolkit

Snippet v2.0.0 is a developer-focused toolkit for checking, validating, generating, formatting, and managing code snippets. It provides a comprehensive set of commands covering the full code quality lifecycle — from initial checks and linting through formatting, conversion, and reporting.

All operations are logged with timestamps and stored locally for full traceability. Each command can record input for later review, or display recent entries when called without arguments.

## Commands

| Command | Description |
|---------|-------------|
| `snippet check <input>` | Check code or configuration for issues |
| `snippet validate <input>` | Validate code blocks, syntax, or structure |
| `snippet generate <input>` | Generate boilerplate code or snippets |
| `snippet format <input>` | Format code according to conventions |
| `snippet lint <input>` | Lint code for style and quality issues |
| `snippet explain <input>` | Explain what a code snippet does |
| `snippet convert <input>` | Convert code between formats or languages |
| `snippet template <input>` | Create or apply code templates |
| `snippet diff <input>` | Compare code snippets or track changes |
| `snippet preview <input>` | Preview rendered output of code |
| `snippet fix <input>` | Fix identified issues in code |
| `snippet report <input>` | Generate reports on code quality or changes |
| `snippet stats` | Show summary statistics across all command categories |
| `snippet export <fmt>` | Export all data (formats: `json`, `csv`, `txt`) |
| `snippet search <term>` | Search across all log entries for a keyword |
| `snippet recent` | Show the 20 most recent activity log entries |
| `snippet status` | Health check — version, data dir, entry count, disk usage |
| `snippet help` | Show help with all available commands |
| `snippet version` | Print current version (v2.0.0) |

Each code command (check, validate, generate, etc.) works in two modes:
- **With arguments** — saves the input with a timestamp to its dedicated log file
- **Without arguments** — displays the 20 most recent entries from that log

## Data Storage

All data is stored locally in `~/.local/share/snippet/`:

- **Per-command logs**: `check.log`, `validate.log`, `generate.log`, `format.log`, `lint.log`, `explain.log`, `convert.log`, `template.log`, `diff.log`, `preview.log`, `fix.log`, `report.log`
- **Activity history**: `history.log` — chronological log of all operations
- **Exports**: `export.json`, `export.csv`, or `export.txt` when using the export command

Log format: `YYYY-MM-DD HH:MM|<input>` (pipe-delimited timestamp and value).

## Requirements

- **Bash** 4.0+ (uses `set -euo pipefail`)
- **Standard Unix tools**: `date`, `wc`, `du`, `head`, `tail`, `grep`, `basename`, `cat`
- No external dependencies, API keys, or network access required
- Works on Linux and macOS

## When to Use

1. **Code review tracking** — Use `snippet check` and `snippet lint` to log code issues found during reviews, then `snippet fix` to track resolutions
2. **Boilerplate generation** — Use `snippet generate` to record frequently-used code patterns and `snippet template` to maintain reusable templates
3. **Code conversion projects** — Use `snippet convert` to track language or format conversions, and `snippet diff` to log before/after comparisons
4. **Documentation and explanation** — Use `snippet explain` to log explanations of complex code, building a knowledge base searchable with `snippet search`
5. **Quality reporting** — Use `snippet report` for quality summaries, `snippet stats` for activity overview, and `snippet export json` for integration with external analysis tools

## Examples

### Check and validate code

```bash
# Check a code block for issues
snippet check "function getData() { return fetch('/api').then(r => r.json()) }"

# Validate syntax structure
snippet validate "SELECT * FROM users WHERE id = 1; DROP TABLE users;--"

# Lint for style issues
snippet lint "var x=1;var y=2;console.log(x+y)"

# View recent check entries
snippet check
```

### Generate and format

```bash
# Generate a boilerplate
snippet generate "Express.js REST endpoint with error handling"

# Format code
snippet format "const f=(x)=>{return x*2}"

# Create a template
snippet template "React functional component with useState and useEffect"

# Convert between languages
snippet convert "Python list comprehension to JavaScript map/filter"
```

### Analyze and report

```bash
# Explain a snippet
snippet explain "arr.reduce((acc, val) => acc.concat(Array.isArray(val) ? val.flat() : val), [])"

# Diff two approaches
snippet diff "for-loop vs Array.map performance comparison"

# Generate a report
snippet report "Weekly code quality summary: 12 issues found, 9 fixed"

# Preview output
snippet preview "Markdown table with 3 columns and 5 rows"
```

### Review and export

```bash
# View recent activity
snippet recent

# Search for specific entries
snippet search "React"

# Check overall stats
snippet stats

# Export everything as CSV
snippet export csv

# Health check
snippet status
```

## How It Works

Snippet uses a simple file-based storage system. Each command writes timestamped entries to its own `.log` file in the data directory. The `history.log` file maintains a chronological record of all operations across all commands. The `stats` command aggregates line counts from all log files, while `export` serializes everything into your chosen format (JSON, CSV, or plain text). The `search` command performs case-insensitive grep across all log files.

---

*Powered by BytesAgain | bytesagain.com | hello@bytesagain.com*
