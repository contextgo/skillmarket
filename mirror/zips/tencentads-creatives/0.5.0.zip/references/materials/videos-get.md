# 查询视频列表 (videos/get)

## 接口信息

- **HTTP方法**: GET
- **接口路径**: `/v3.0/videos/get`
- **完整URL**: `https://api.e.qq.com/v3.0/videos/get`
- **权限要求**: 需登录api.e.qq.com 并具有对应账户操作权限
- **官方文档**: https://developers.e.qq.com/v3.0/docs/api/videos/get

## 功能说明

获取素材库中的视频列表，支持过滤条件、分页查询。

## 全局参数（URL Query参数）

> `timestamp`、`nonce` 及 API Key 鉴权均由 CLI 底层自动注入，**无需手动传入**。

以下内容为腾讯广告营销 API（`api.e.qq.com`）各 skill 共享的公共约定，会在构建阶段自动内联到目标 skill 文档中。各 skill 不需要重复这些内容。

## 基础信息

- **Base URL**: `https://api.e.qq.com`
- **认证方式**: API Key 鉴权（api.e.qq.com），可通过 `tencent-ads auth status` 查看当前认证状态
- **权限要求**: 需登录api.e.qq.com 并具有对应账户操作权限
- **时区**: GMT+8（北京时间）
- **金额单位**: 分（不是元），示例：`10000` 分 = `100` 元人民币
- **时间戳**: 秒级 Unix timestamp，允许误差 ±300 秒

## 调用方式

所有接口均通过 `tencent-ads` CLI 工具调用（agent 通过 bash 执行）。API Key 鉴权由 CLI 自动处理（通过 X-MKT-API-Key header），无需手动传入。

### GET 请求

```bash
tencent-ads api '{
  "method": "GET",
  "path": "/v3.0/xxx/get",
  "account_id": "YOUR_ACCOUNT_ID",
  "params": {"page": 1, "page_size": 10}
}'
```

### POST 请求

```bash
tencent-ads api '{
  "method": "POST",
  "path": "/v3.0/xxx/add",
  "account_id": "YOUR_ACCOUNT_ID",
  "body": {"account_id": 12345, "field1": "value1"}
}'
```

### 参数说明

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| method | string | 否 | GET 或 POST（默认 GET） |
| path | string | **是** | API 路径 |
| account_id | string | **是** | 广告账户 ID |
| params | object | 否 | GET 查询参数（JSON 对象） |
| body | object | 否 | POST 请求体（JSON 对象） |

> **严格规则**：调用任何接口时，**必须严格使用该接口文档中声明的 HTTP 方法（GET / POST）**，不得擅自更改。使用错误的请求方法会导致服务端返回 `405 Method Not Allowed`。

## 通用响应格式

所有接口返回的 JSON 响应都遵循以下格式：

```json
{
  "code": 0,
  "message": "",
  "message_cn": "",
  "data": {
    // 接口特定的响应数据
  }
}
```

| 字段 | 类型 | 说明 |
|------|------|------|
| code | integer | 响应码，0 表示成功，非 0 表示错误 |
| message | string | 英文错误消息（成功时为空） |
| message_cn | string | 中文错误消息（成功时为空） |
| data | object | 响应数据对象 |

## 错误处理

`tencent-ads api` 返回的 JSON 响应中包含 `code` 字段：
- `code` 为 0 表示成功
- `code` 非 0 时，检查 `message_cn` 获取中文错误说明

### 常见错误码

| 错误码 | 说明 | 处理方式 |
|--------|------|----------|
| 0 | 成功 | - |
| 3 | 参数错误 | 检查请求参数格式和必填项 |
| 5 | 权限不足 | 确认 API Key 有效且具有相应权限 |
| 6 | 系统错误 | 重试或联系技术支持 |
| 1001 | `timestamp` 超时 | 确保请求时间戳在当前时间 ±300 秒内 |
| 1002 | `nonce` 重复 | 使用新的随机字符串 |
| 1800428 | 相似广告冲突（三元组 + OG + 定向相似） | **⛔ 严禁自动修改参数绕过。** 必须停止创建 → 以对比表格展示当前广告与冲突广告的核心信息（三元组、OG、定向等） → 告知冲突原因 → 等待用户指示。不主动给调整建议。详见各创建 skill 的执行原则。 |

## 数值单位说明

### 金额单位
- 所有涉及金额的字段（出价、预算等）单位均为**分**（不是元）
- 示例：`10000` 分 = `100` 元人民币
- 日预算范围：5000-400000000 分（50 元-400 万元）

### 时间单位
- 时间戳：秒（Unix timestamp）
- 日期格式：`YYYY-MM-DD`
- 时间格式：`HH:ii:ss`
- 时区：`GMT+8`（北京时间）

## 分页参数

大多数列表查询接口支持以下分页参数：

### 标准分页

| 参数名 | 类型 | 默认值 | 说明 |
|--------|------|--------|------|
| page | integer | 1 | 页码（1-100） |
| page_size | integer | 10 | 每页数量（1-100） |

### 游标分页

| 参数名 | 类型 | 说明 |
|--------|------|------|
| pagination_mode | enum | 分页方式：`PAGINATION_MODE_NORMAL`（标准）/ `PAGINATION_MODE_CURSOR`（游标） |
| cursor | string | 游标值，有效期 24 小时 |

### 分页响应

```json
{
  "page_info": {
    "page": 1,
    "page_size": 10,
    "total_number": 100,
    "total_page": 10
  }
}
```

## 过滤参数

大多数查询接口支持 `filtering` 参数进行条件过滤：

### filtering 结构

```json
{
  "filtering": [
    {
      "field": "字段名",
      "operator": "操作符",
      "values": ["值1", "值2"]
    }
  ]
}
```

### 操作符说明

| 操作符 | 说明 | 示例 |
|--------|------|------|
| EQUALS | 等于 | `{"field": "status", "operator": "EQUALS", "values": ["NORMAL"]}` |
| CONTAINS | 模糊匹配 | `{"field": "name", "operator": "CONTAINS", "values": ["测试"]}` |
| LESS | 小于 | `{"field": "created_time", "operator": "LESS", "values": ["2026-04-01 00:00:00"]}` |
| LESS_EQUALS | 小于等于 | `{"field": "created_time", "operator": "LESS_EQUALS", "values": ["2026-04-01 23:59:59"]}` |
| GREATER | 大于 | `{"field": "created_time", "operator": "GREATER", "values": ["2026-03-01 00:00:00"]}` |
| GREATER_EQUALS | 大于等于 | `{"field": "created_time", "operator": "GREATER_EQUALS", "values": ["2026-03-01 00:00:00"]}` |
| IN | IN 操作符 | `{"field": "id", "operator": "IN", "values": ["1", "2", "3"]}` |

## 最佳实践

1. **请求方法**：严格按照各接口文档声明的 HTTP 方法（GET/POST）发起请求，不得混用
2. **错误处理**：始终检查响应中的 `code` 字段
3. **重试机制**：对于系统错误（`code = 6`），可以实施指数退避重试
4. **API Key 如失效需重新配置
5. **分页处理**：对于大数据量查询，使用游标分页性能更好
6. **字段筛选**：使用 `fields` 参数只请求需要的字段，减少数据传输

## 请求参数

### 必填参数

| 参数名 | 类型 | 说明 |
|--------|------|------|
| account_id | integer | 广告主账号ID（与 organization_id 二选一必填，不支持代理商ID） |
| organization_id | integer | 业务单元ID（与 account_id 二选一必填） |

### 可选参数

| 参数名 | 类型 | 默认值 | 说明 | 限制 |
|--------|------|--------|------|------|
| filtering | struct[] | - | 过滤条件数组 | 1-4 个元素 |
| page | integer | 1 | 页码 | 1-99999 |
| page_size | integer | 10 | 每页数量 | 1-100 |
| label_id | integer | - | 标签ID | - |
| business_scenario | integer | - | 业务场景 | 1=内容素材包，2=投放素材包 |

## filtering 过滤条件

每个 filtering 元素包含：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| field | string | 是 | 过滤字段（长度1-32字节） |
| operator | enum | 是 | 操作符 |
| values | string[] | 是 | 字段值数组 |

### 支持的过滤字段

| 过滤字段 | 可选操作符 | values 说明 |
|---------|----------|-----------|
| video_id | EQUALS, CONTAINS | - |
| media_id | EQUALS, IN | EQUALS时数组长度1；IN时数组长度1-100 |
| media_signature | EQUALS, CONTAINS | 数组长度1 |
| media_width | EQUALS | 数组长度1，取值0-3840 |
| media_height | EQUALS | 数组长度1，取值0-2160 |
| created_time | EQUALS, LESS_EQUALS, LESS, GREATER_EQUALS, GREATER | 支持 `YYYY-MM-DD HH:mm:ss` 格式（脚本自动转为时间戳），数组长度1 |
| last_modified_time | EQUALS, LESS_EQUALS, LESS, GREATER_EQUALS, GREATER | 支持 `YYYY-MM-DD HH:mm:ss` 格式（脚本自动转为时间戳），数组长度1 |
| source_type | EQUALS | 见枚举值说明 |
| status | EQUALS, CONTAINS | ADSTATUS_NORMAL, ADSTATUS_DELETED |
| media_description | EQUALS, CONTAINS | 数组长度1，长度1-100字节 |
| sample_aspect_ratio | EQUALS, CONTAINS | 宽高比，数组长度1 |
| owner_account_id | EQUALS, CONTAINS | 数组长度1，长度1-100字节 |
| product_catalog_id | EQUALS, CONTAINS | 数组长度1，长度1-100字节 |
| product_outer_id | EQUALS, CONTAINS | 商品ID，数组长度1，长度1-100字节 |
| first_publication_status | EQUALS | 首发状态 |
| quality_status | - | 质量状态 |
| file_size | LESS_EQUALS | 文件大小（B） |
| height | GREATER_EQUALS, LESS_EQUALS | 视频高度 |
| width | GREATER_EQUALS, LESS_EQUALS | 视频宽度 |
| ratio | EQUALS | 宽高比 |
| video_duration_millisecond | GREATER_EQUALS, LESS_EQUALS | 视频时长（毫秒） |
| aigc_flag | EQUALS | AIGC 标识（数组长度1） |

> 枚举值完整定义见 [enums.md](../enums.md) > 素材管理枚举（source_type、status、similarity_status、first_publication_status、quality_status、aigc_flag、filtering 操作符）

## 响应字段

### 主要响应结构

| 字段名 | 类型 | 说明 |
|--------|------|------|
| code | integer | 响应码（0表示成功） |
| message | string | 英文错误消息 |
| message_cn | string | 中文错误消息 |
| data.list | struct[] | 视频信息列表 |
| data.page_info | struct | 分页信息 |

### list 数组元素字段

| 字段名 | 类型 | 说明 |
|--------|------|------|
| video_id | integer | 视频ID |
| width | integer | 视频宽度（px） |
| height | integer | 视频高度（px） |
| video_frames | integer | 视频帧数 |
| video_fps | float | 视频帧率 |
| video_codec | string | 视频编码格式（如 H264） |
| video_bit_rate | integer | 视频码率（b/s） |
| audio_codec | string | 音频编码格式（如 AAC） |
| audio_bit_rate | integer | 音频码率（b/s） |
| file_size | integer | 视频文件大小（B） |
| type | enum | 视频类型，见枚举值说明 |
| signature | string | 视频文件签名（MD5值） |
| system_status | enum | 转码状态 |
| description | string | 视频文件描述 |
| preview_url | string | 视频预览地址 |
| key_frame_image_url | string | 视频首帧缩略图地址 |
| created_time | integer | 创建时间（时间戳） |
| last_modified_time | integer | 最后修改时间（时间戳） |
| video_profile_name | string | 视频格式类型 |
| audio_sample_rate | integer | 音频采样率（hz） |
| max_keyframe_interval | integer | 关键帧最大间隔帧数 |
| min_keyframe_interval | integer | 关键帧最小间隔帧数 |
| sample_aspect_ratio | string | 采样纵横比 |
| audio_profile_name | string | 音频格式类型 |
| scan_type | string | 扫描类型 |
| image_duration_millisecond | integer | 画面时长（ms） |
| audio_duration_millisecond | integer | 音频时长（ms） |
| source_type | enum | 视频来源 |
| product_outer_id | string | 商品ID |
| source_reference_id | string | 素材来源关联ID |
| owner_account_id | string | 素材拥有者ID |
| status | enum | 视频状态 |
| similarity_status | enum | 相似度检测状态，见枚举值说明 |

> type（视频格式）、similarity_status、system_status 枚举值见 [enums.md](../enums.md) > 素材管理枚举

### page_info 分页信息

| 字段名 | 类型 | 说明 |
|--------|------|------|
| page | integer | 当前页码 |
| page_size | integer | 每页数量 |
| total_number | integer | 总记录数 |
| total_page | integer | 总页数 |

## 请求示例

### 基础查询（最近半年）

```bash
node scripts/get-videos.mjs '{"account_id":"123456789"}'
```

### 按视频 ID 查询（确认转码状态）

```bash
node scripts/get-videos.mjs '{"account_id":"123456789","filtering":[{"field":"video_id","operator":"EQUALS","values":["123456"]}]}'
```

### 按尺寸查询

```bash
node scripts/get-videos.mjs '{"account_id":"123456789","filtering":[{"field":"media_width","operator":"EQUALS","values":["1280"]},{"field":"media_height","operator":"EQUALS","values":["720"]}]}'
```

### 按来源类型查询

```bash
node scripts/get-videos.mjs '{"account_id":"123456789","filtering":[{"field":"source_type","operator":"EQUALS","values":["SOURCE_TYPE_API"]}]}'
```

### 按视频时长查询（30秒以内）

```bash
node scripts/get-videos.mjs '{"account_id":"123456789","filtering":[{"field":"video_duration_millisecond","operator":"LESS_EQUALS","values":["30000"]}]}'
```

### 批量查询视频 ID

```bash
node scripts/get-videos.mjs '{"account_id":"123456789","filtering":[{"field":"media_id","operator":"IN","values":["111222","333444"]}]}'
```

## 响应示例

### 成功响应

```json
{
    "code": 0,
    "message": "",
    "message_cn": "",
    "data": {
        "list": [
            {
                "video_id": 1234567890,
                "width": 1280,
                "height": 720,
                "video_frames": 750,
                "video_fps": 25.0,
                "video_codec": "H264",
                "video_bit_rate": 2000000,
                "audio_codec": "AAC",
                "audio_bit_rate": 128000,
                "file_size": 10485760,
                "type": "TYPE_MP4",
                "signature": "19efcaeda3c30e1cf28170d86ecbf5e0",
                "system_status": "MEDIA_STATUS_VALID",
                "description": "产品宣传视频",
                "preview_url": "https://example.com/video.mp4",
                "key_frame_image_url": "https://example.com/thumbnail.jpg",
                "created_time": 1704038400,
                "last_modified_time": 1704124800,
                "source_type": "SOURCE_TYPE_API",
                "status": "ADSTATUS_NORMAL"
            }
        ],
        "page_info": {
            "page": 1,
            "page_size": 10,
            "total_number": 1,
            "total_page": 1
        }
    }
}
```

### 错误响应

```json
{
    "code": 3,
    "message": "Parameter error",
    "message_cn": "参数错误",
    "data": {}
}
```

## 注意事项

1. **微信广告主限制**: 微信广告主调用此接口仅返回以下字段：
   - video_id
   - width
   - height
   - file_size

2. **过滤条件数量**: 最多支持 4 个过滤条件

3. **分页限制**: 
   - page_size 最大值为 100
   - page 最大值为 99999

4. **账户标识**: account_id 不支持代理商ID，与 organization_id 二选一必填

5. **转码状态**: 新上传的视频需要转码，只有 system_status 为 MEDIA_STATUS_VALID 时才可使用

## 常见错误码

| 错误码 | 说明 | 解决方案 |
|--------|------|----------|
| 0 | 成功 | - |
| 3 | 参数错误 | 检查account_id是否正确，filtering格式是否正确 |
| 5 | 权限不足 | 确认 API Key 有效且有查询权限 |

## 最佳实践

1. **转码检查**: 查询视频时检查 system_status，确认视频已转码完成
2. **分页查询**: 首次查询使用小的 page_size，确认数据量后再调整
3. **时间过滤**: 建议指定 created_time 过滤条件，避免返回过多数据
4. **批量查询**: 使用 IN 操作符可一次查询多个视频ID（最多100个）
