# 获取妙思版权音频列表 (muse_audios/get)

## 接口信息

- **HTTP方法**: POST
- **接口路径**: `/v3.0/muse_audios/get`
- **完整URL**: `https://api.e.qq.com/v3.0/muse_audios/get`
- **Content-Type**: application/json
- **权限要求**: 需登录api.e.qq.com 并具有对应账户操作权限
- **官方文档**: https://developers.e.qq.com/v3.0/docs/api/muse_audios/get

## 功能说明

获取妙思平台提供的版权音频列表，用于视频创意制作。

## 全局参数（URL Query参数）

> `timestamp`、`nonce` 及 API Key 鉴权均由 CLI 底层自动注入，**无需手动传入**。

以下内容为腾讯广告营销 API（`api.e.qq.com`）各 skill 共享的公共约定，会在构建阶段自动内联到目标 skill 文档中。各 skill 不需要重复这些内容。

## 基础信息

- **Base URL**: `https://api.e.qq.com`
- **认证方式**: API Key 鉴权（api.e.qq.com），可通过 `tencent-ads auth status` 查看当前认证状态
- **权限要求**: 需登录api.e.qq.com 并具有对应账户操作权限
- **时区**: GMT+8（北京时间）
- **金额单位**: 分（不是元），示例：`10000` 分 = `100` 元人民币
- **时间戳**: 秒级 Unix timestamp，允许误差 ±300 秒

## 调用方式

所有接口均通过 `tencent-ads` CLI 工具调用（agent 通过 bash 执行）。API Key 鉴权由 CLI 自动处理（通过 X-MKT-API-Key header），无需手动传入。

### GET 请求

```bash
tencent-ads api '{
  "method": "GET",
  "path": "/v3.0/xxx/get",
  "account_id": "YOUR_ACCOUNT_ID",
  "params": {"page": 1, "page_size": 10}
}'
```

### POST 请求

```bash
tencent-ads api '{
  "method": "POST",
  "path": "/v3.0/xxx/add",
  "account_id": "YOUR_ACCOUNT_ID",
  "body": {"account_id": 12345, "field1": "value1"}
}'
```

### 参数说明

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| method | string | 否 | GET 或 POST（默认 GET） |
| path | string | **是** | API 路径 |
| account_id | string | **是** | 广告账户 ID |
| params | object | 否 | GET 查询参数（JSON 对象） |
| body | object | 否 | POST 请求体（JSON 对象） |

> **严格规则**：调用任何接口时，**必须严格使用该接口文档中声明的 HTTP 方法（GET / POST）**，不得擅自更改。使用错误的请求方法会导致服务端返回 `405 Method Not Allowed`。

## 通用响应格式

所有接口返回的 JSON 响应都遵循以下格式：

```json
{
  "code": 0,
  "message": "",
  "message_cn": "",
  "data": {
    // 接口特定的响应数据
  }
}
```

| 字段 | 类型 | 说明 |
|------|------|------|
| code | integer | 响应码，0 表示成功，非 0 表示错误 |
| message | string | 英文错误消息（成功时为空） |
| message_cn | string | 中文错误消息（成功时为空） |
| data | object | 响应数据对象 |

## 错误处理

`tencent-ads api` 返回的 JSON 响应中包含 `code` 字段：
- `code` 为 0 表示成功
- `code` 非 0 时，检查 `message_cn` 获取中文错误说明

### 常见错误码

| 错误码 | 说明 | 处理方式 |
|--------|------|----------|
| 0 | 成功 | - |
| 3 | 参数错误 | 检查请求参数格式和必填项 |
| 5 | 权限不足 | 确认 API Key 有效且具有相应权限 |
| 6 | 系统错误 | 重试或联系技术支持 |
| 1001 | `timestamp` 超时 | 确保请求时间戳在当前时间 ±300 秒内 |
| 1002 | `nonce` 重复 | 使用新的随机字符串 |
| 1800428 | 相似广告冲突（三元组 + OG + 定向相似） | **⛔ 严禁自动修改参数绕过。** 必须停止创建 → 以对比表格展示当前广告与冲突广告的核心信息（三元组、OG、定向等） → 告知冲突原因 → 等待用户指示。不主动给调整建议。详见各创建 skill 的执行原则。 |

## 数值单位说明

### 金额单位
- 所有涉及金额的字段（出价、预算等）单位均为**分**（不是元）
- 示例：`10000` 分 = `100` 元人民币
- 日预算范围：5000-400000000 分（50 元-400 万元）

### 时间单位
- 时间戳：秒（Unix timestamp）
- 日期格式：`YYYY-MM-DD`
- 时间格式：`HH:ii:ss`
- 时区：`GMT+8`（北京时间）

## 分页参数

大多数列表查询接口支持以下分页参数：

### 标准分页

| 参数名 | 类型 | 默认值 | 说明 |
|--------|------|--------|------|
| page | integer | 1 | 页码（1-100） |
| page_size | integer | 10 | 每页数量（1-100） |

### 游标分页

| 参数名 | 类型 | 说明 |
|--------|------|------|
| pagination_mode | enum | 分页方式：`PAGINATION_MODE_NORMAL`（标准）/ `PAGINATION_MODE_CURSOR`（游标） |
| cursor | string | 游标值，有效期 24 小时 |

### 分页响应

```json
{
  "page_info": {
    "page": 1,
    "page_size": 10,
    "total_number": 100,
    "total_page": 10
  }
}
```

## 过滤参数

大多数查询接口支持 `filtering` 参数进行条件过滤：

### filtering 结构

```json
{
  "filtering": [
    {
      "field": "字段名",
      "operator": "操作符",
      "values": ["值1", "值2"]
    }
  ]
}
```

### 操作符说明

| 操作符 | 说明 | 示例 |
|--------|------|------|
| EQUALS | 等于 | `{"field": "status", "operator": "EQUALS", "values": ["NORMAL"]}` |
| CONTAINS | 模糊匹配 | `{"field": "name", "operator": "CONTAINS", "values": ["测试"]}` |
| LESS | 小于 | `{"field": "created_time", "operator": "LESS", "values": ["2026-04-01 00:00:00"]}` |
| LESS_EQUALS | 小于等于 | `{"field": "created_time", "operator": "LESS_EQUALS", "values": ["2026-04-01 23:59:59"]}` |
| GREATER | 大于 | `{"field": "created_time", "operator": "GREATER", "values": ["2026-03-01 00:00:00"]}` |
| GREATER_EQUALS | 大于等于 | `{"field": "created_time", "operator": "GREATER_EQUALS", "values": ["2026-03-01 00:00:00"]}` |
| IN | IN 操作符 | `{"field": "id", "operator": "IN", "values": ["1", "2", "3"]}` |

## 最佳实践

1. **请求方法**：严格按照各接口文档声明的 HTTP 方法（GET/POST）发起请求，不得混用
2. **错误处理**：始终检查响应中的 `code` 字段
3. **重试机制**：对于系统错误（`code = 6`），可以实施指数退避重试
4. **API Key 如失效需重新配置
5. **分页处理**：对于大数据量查询，使用游标分页性能更好
6. **字段筛选**：使用 `fields` 参数只请求需要的字段，减少数据传输

## 请求Body参数（JSON格式）

### 必填参数

| 参数名 | 类型 | 说明 | 限制 |
|--------|------|------|------|
| fields | string[] | 需要返回的字段列表 | 数组长度1-1024，字段长度1-64字节 |

### 可选参数

| 参数名 | 类型 | 默认值 | 说明 | 限制 |
|--------|------|--------|------|------|
| page | integer | 1 | 页码 | 1-99999 |
| page_size | integer | 10 | 每页数量 | 1-100 |

### fields 可选字段

| 字段名 | 说明 |
|--------|------|
| audio_id | 音频ID |
| audio_name | 音频文件名称 |
| cover_image_url | 音频封面图地址 |
| author | 音频作者 |
| duration | 音频时长（秒） |
| expire_time | 音频版权过期时间戳 |
| feel_tags | 音频情感标签列表 |
| genre_tags | 音频流派标签列表 |

## 响应字段

### 主要响应结构

| 字段名 | 类型 | 说明 |
|--------|------|------|
| code | integer | 响应码（0表示成功） |
| message | string | 英文错误消息 |
| message_cn | string | 中文错误消息 |
| data.list | struct[] | 音频信息列表 |
| data.page_info | struct | 分页信息 |

### list 数组元素字段

| 字段名 | 类型 | 说明 |
|--------|------|------|
| audio_id | string | 音频ID |
| audio_name | string | 音频文件名称 |
| cover_image_url | string | 音频封面图地址 |
| author | string | 音频作者 |
| duration | float | 音频时长（秒） |
| expire_time | integer | 音频版权过期时间戳 |
| feel_tags | string[] | 音频情感标签列表 |
| genre_tags | string[] | 音频流派标签列表 |

### page_info 分页信息

| 字段名 | 类型 | 说明 |
|--------|------|------|
| page | integer | 当前页码 |
| page_size | integer | 每页数量 |
| total_number | integer | 总记录数 |
| total_page | integer | 总页数 |

## 请求示例

### 基础查询（返回全部字段）

```bash
node scripts/get-audios.mjs '{"account_id":"123456789"}'
```

### 指定返回字段

```bash
node scripts/get-audios.mjs '{"account_id":"123456789","fields":["audio_id","audio_name","author","duration","feel_tags"]}'
```

### 分页查询

```bash
node scripts/get-audios.mjs '{"account_id":"123456789","page":2,"page_size":20}'
```

## 响应示例

### 成功响应

```json
{
    "code": 0,
    "message": "",
    "message_cn": "",
    "data": {
        "list": [
            {
                "audio_id": "88",
                "audio_name": "8-bit",
                "cover_image_url": "https://example.com/cover.jpg",
                "author": "Cassiopeia",
                "duration": 51.36,
                "expire_time": 1760025599,
                "feel_tags": [
                    "复古",
                    "可爱/童真"
                ],
                "genre_tags": [
                    "电子"
                ]
            },
            {
                "audio_id": "89",
                "audio_name": "Summer Vibes",
                "cover_image_url": "https://example.com/cover2.jpg",
                "author": "MusicMaker",
                "duration": 120.5,
                "expire_time": 1760025599,
                "feel_tags": [
                    "欢快",
                    "活力"
                ],
                "genre_tags": [
                    "流行",
                    "电子"
                ]
            }
        ],
        "page_info": {
            "page": 1,
            "page_size": 10,
            "total_number": 100,
            "total_page": 10
        }
    }
}
```

### 错误响应

```json
{
    "code": 3,
    "message": "Parameter error",
    "message_cn": "参数错误：fields 不能为空",
    "data": {}
}
```

## 常见标签说明

### 情感标签 (feel_tags)

常见的情感标签包括：
- 欢快
- 活力
- 复古
- 可爱/童真
- 温馨
- 励志
- 浪漫
- 紧张
- 悲伤

### 流派标签 (genre_tags)

常见的流派标签包括：
- 电子
- 流行
- 摇滚
- 古典
- 嘻哈
- 民谣
- 爵士

## 注意事项

1. **fields 必填**: 必须指定需要返回的字段列表

2. **版权有效期**: 注意检查 expire_time，确保音频版权在使用时仍然有效

3. **分页限制**: 
   - page_size 最大值为 100
   - page 最大值为 99999

4. **用途说明**: 妙思音频主要用于视频创意制作，需配合视频编辑工具使用

5. **标签筛选**: 可根据 feel_tags 和 genre_tags 选择适合的背景音乐

## 常见错误码

| 错误码 | 说明 | 解决方案 |
|--------|------|----------|
| 0 | 成功 | - |
| 3 | 参数错误 | 检查 fields 参数是否正确 |
| 5 | 权限不足 | 确认 API Key 有效且有查询权限 |

## 最佳实践

1. **按需获取字段**: 只请求需要的字段，减少数据传输
2. **分页遍历**: 使用分页获取完整音频列表
3. **标签匹配**: 根据视频内容选择匹配的情感和流派标签
4. **版权检查**: 使用前检查音频版权是否在有效期内
5. **缓存列表**: 音频列表相对稳定，可适当缓存减少请求
