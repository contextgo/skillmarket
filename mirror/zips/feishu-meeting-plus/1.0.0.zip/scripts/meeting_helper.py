#!/usr/bin/env python3
"""
Feishu Meeting Helper Script
辅助飞书会议自动化操作
"""

import json
import sys
from datetime import datetime, timedelta


def format_meeting_notice(
    title: str,
    start_time: str,
    end_time: str,
    location: str,
    attendees: list,
    agenda: str = "",
    urgent: bool = False,
) -> str:
    """格式化会议通知"""
    emoji = "🚨" if urgent else "📅"
    lines = [
        f"{emoji} 会议通知",
        "━━━━━━━━━━━━━━",
        f"📌 主题: {title}",
        f"🕐 时间: {start_time} ~ {end_time}",
        f"📍 地点: {location}",
        f"👥 参会人: {'、'.join(attendees)}",
    ]

    if agenda:
        lines.append(f"📝 议程:\n{agenda}")

    lines.append("━━━━━━━━━━━━━━")

    if urgent:
        lines.append("⚠️ 紧急！请务必准时参加！")
    else:
        lines.append("⏰ 请准时参加！收到请回复 👍")

    return "\n".join(lines)


def format_meeting_minutes(
    title: str,
    date: str,
    start_time: str,
    end_time: str,
    attendees: list,
    decisions: list,
    todos: list,
) -> str:
    """格式化会议纪要"""
    lines = [
        "📝 会议纪要",
        "━━━━━━━━━━━━━━",
        f"📌 会议: {title}",
        f"🕐 时间: {date} {start_time} ~ {end_time}",
        f"👥 出席: {'、'.join(attendees)}",
        "",
        "✅ 决议事项:",
    ]
    for d in decisions:
        lines.append(f"  - {d}")

    lines.append("")
    lines.append("📌 待办事项:")
    for t in todos:
        lines.append(f"  - [ ] {t}")

    lines.append("━━━━━━━━━━━━━━")
    return "\n".join(lines)


def format_reminder(
    title: str, start_time: str, location: str, minutes_before: int = 15
) -> str:
    """格式化会前提醒"""
    return "\n".join(
        [
            "⏰ 会议提醒",
            "━━━━━━━━━━━━━━",
            f"您的会议将在 {minutes_before} 分钟后开始：",
            f"📌 {title}",
            f"🕐 {start_time}",
            f"📍 {location}",
            "━━━━━━━━━━━━━━",
            "请准时参加！",
        ]
    )


def parse_time(time_str: str) -> dict:
    """解析时间字符串"""
    formats = [
        "%Y-%m-%d %H:%M",
        "%Y-%m-%d %H:%M:%S",
        "%m-%d %H:%M",
        "%H:%M",
        "today %H:%M",
        "tomorrow %H:%M",
    ]

    for fmt in formats:
        try:
            dt = datetime.strptime(time_str, fmt)
            if fmt.startswith("today"):
                dt = dt.replace(year=datetime.now().year, month=datetime.now().month, day=datetime.now().day)
            elif fmt.startswith("tomorrow"):
                tomorrow = datetime.now() + timedelta(days=1)
                dt = dt.replace(year=tomorrow.year, month=tomorrow.month, day=tomorrow.day)
            elif "-" not in time_str.split()[0]:
                dt = dt.replace(year=datetime.now().year, month=datetime.now().month, day=datetime.now().day)
            return {
                "datetime": dt.isoformat(),
                "date": dt.strftime("%Y-%m-%d"),
                "time": dt.strftime("%H:%M"),
                "weekday": dt.strftime("%A"),
            }
        except ValueError:
            continue

    return {"error": f"无法解析时间格式: {time_str}"}


def suggest_group_name(title: str, date: str = None) -> str:
    """生成群名称"""
    if date:
        return f"📅 {title} - {date}"
    today = datetime.now().strftime("%m-%d")
    return f"📅 {title} - {today}"


def main():
    """CLI 入口"""
    if len(sys.argv) < 2:
        print("用法: python meeting_helper.py <command> [args]")
        print("命令: notice, minutes, reminder, parse_time, group_name")
        sys.exit(1)

    command = sys.argv[1]

    if command == "notice":
        # python meeting_helper.py notice "标题" "开始时间" "结束时间" "地点" "参会人1,参会人2"
        if len(sys.argv) < 7:
            print("用法: python meeting_helper.py notice <title> <start> <end> <location> <attendees>")
            sys.exit(1)
        attendees = sys.argv[6].split(",")
        print(format_meeting_notice(sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5], attendees))

    elif command == "parse_time":
        if len(sys.argv) < 3:
            print("用法: python meeting_helper.py parse_time <time_str>")
            sys.exit(1)
        print(json.dumps(parse_time(sys.argv[2]), ensure_ascii=False, indent=2))

    elif command == "group_name":
        title = sys.argv[2] if len(sys.argv) > 2 else "会议"
        date = sys.argv[3] if len(sys.argv) > 3 else None
        print(suggest_group_name(title, date))

    else:
        print(f"未知命令: {command}")
        sys.exit(1)


if __name__ == "__main__":
    main()
