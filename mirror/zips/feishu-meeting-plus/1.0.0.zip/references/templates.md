# Meeting Templates — 会议通知模板

## 1. 标准会议通知

```
📅 会议通知
━━━━━━━━━━━━━━
📌 主题: {title}
🕐 时间: {date} {start_time} ~ {end_time}
📍 地点: {location}
👥 参会人: {attendees}
 议程:
{agenda_items}
━━━━━━━━━━━━━━
⏰ 请准时参加！收到请回复 👍
```

## 2. 紧急会议通知

```
🚨 紧急会议通知
━━━━━━━━━━━━━━
📌 主题: {title}
🕐 时间: {date} {start_time}（{minutes}分钟后开始）
📍 地点: {location}
👥 参会人: {attendees}
📝 议题:
{agenda_items}
━━━━━━━━━━━━━━
⚠️ 重要！请务必准时参加！
```

## 3. 例会通知

```
📋 例会提醒
━━━━━━━━━━━━━━
📌 {meeting_name}（第{count}期）
🕐 时间: {date} {start_time} ~ {end_time}
📍 地点: {location}
👥 参会人: {attendees}
📝 本周议程:
{agenda_items}
📎 请提前准备:
{preparation_items}
━━━━━━━━━━━━━━
```

## 4. 会议变更通知

```
⚠️ 会议变更通知
━━━━━━━━━━━━━━
📌 主题: {title}
🔄 变更内容:
  时间: {old_time} → {new_time}
  地点: {old_location} → {new_location}
📝 原因: {reason}
━━━━━━━━━━━━━━
收到请回复确认 🙏
```

## 5. 会议取消通知

```
❌ 会议取消通知
━━━━━━━━━━━━━━
📌 原主题: {title}
🕐 原时间: {date} {start_time}
📍 原地点: {location}
📝 原因: {reason}
━━━━━━━━━━━━━━
造成不便，敬请谅解。
```

## 6. 会议纪要

```
📝 会议纪要
━━━━━━━━━━━━━━
📌 会议: {title}
🕐 时间: {date} {start_time} ~ {end_time}
👥 出席: {attendees}
❌ 缺席: {absentees}

📋 讨论内容:
{discussion_items}

✅ 决议事项:
{decisions}

📌 待办事项:
{todo_items}

📎 附件: {attachments}
━━━━━━━━━━━━━━
```

## 7. 会前提醒

```
⏰ 会议提醒
━━━━━━━━━━━━━━
您的会议将在 {minutes} 分钟后开始：
📌 {title}
🕐 {start_time}
📍 {location}
━━━━━━━━━━━━━━
请准时参加！
```

## 8. 一对一会议

```
🤝 1v1 会议邀请
━━━━━━━━━━━━━━
📌 主题: {title}
🕐 时间: {date} {start_time} ~ {end_time}
📍 地点: {location}
👤 参与人: {person1} & {person2}
📝 讨论话题:
{topics}
━━━━━━━━━━━━━━
```

## 9. 跨部门会议

```
🏢 跨部门协作会议
━━━━━━━━━━━━━━
📌 主题: {title}
🕐 时间: {date} {start_time} ~ {end_time}
📍 地点: {location}
👥 参会部门:
{departments}
📝 协作议题:
{agenda_items}
📎 请各部门准备:
{preparation_items}
━━━━━━━━━━━━━━
```

## 10. 线上会议

```
💻 线上会议邀请
━━━━━━━━━━━━━━
📌 主题: {title}
🕐 时间: {date} {start_time} ~ {end_time}
🔗 会议链接: {meeting_url}
🆔 会议号: {meeting_id}
🔑 密码: {password}
👥 参会人: {attendees}
📝 议程:
{agenda_items}
━━━━━━━━━━━━━━
请提前5分钟入会测试音视频
```

## 使用方式

选择模板 → 替换占位符 → 通过 message tool 发送

### 占位符说明

| 占位符 | 说明 | 示例 |
|--------|------|------|
| `{title}` | 会议标题 | 项目评审会 |
| `{date}` | 日期 | 2026-04-15 |
| `{start_time}` | 开始时间 | 14:00 |
| `{end_time}` | 结束时间 | 15:00 |
| `{location}` | 地点 | 会议室A / 飞书视频会议 |
| `{attendees}` | 参会人 | 张三、李四、王五 |
| `{agenda_items}` | 议程 | 1. xxx\n2. xxx |
| `{reason}` | 原因 | 客户临时要求 |
| `{meeting_url}` | 会议链接 | https://... |
| `{minutes}` | 分钟数 | 15 |
