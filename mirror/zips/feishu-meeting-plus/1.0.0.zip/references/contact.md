# Feishu Contact Lookup — 飞书用户查找

## 查找用户

当前应用有 `contact:user.id:readonly` 权限，可以通过以下方式查找用户：

### 通过飞书 chat member_info

```
feishu_chat(action="member_info", chat_id="oc_xxx", member_id="ou_xxx")
```

### 通过群成员列表搜索

```
feishu_chat(action="members", chat_id="oc_xxx", page_size=100)
```

遍历返回的成员列表，按 name 匹配。

## 用户 ID 类型

| 类型 | 格式 | 说明 |
|------|------|------|
| open_id | `ou_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx` | 应用级唯一标识 |
| user_id | `user_xxx` | 租户级唯一标识 |
| union_id | `on_xxx` | 跨应用唯一标识 |

## 常见场景

### 按姓名查找

```
# 在已有群中查找
members = feishu_chat(action="members", chat_id=chat_id)
for member in members:
    if name in member["name"]:
        return member["member_id"]
```

### 按邮箱查找

飞书用户邮箱通常在 member_info 中返回：

```
info = feishu_chat(action="member_info", chat_id=chat_id, member_id=open_id)
if info.get("email") == target_email:
    return info
```

### 批量查找

```
# 从群成员中批量匹配
target_names = ["张三", "李四", "王五"]
found = []
for member in all_members:
    if member["name"] in target_names:
        found.append(member["member_id"])
```

## 注意事项

- open_id 以 `ou_` 开头
- 不同应用的 open_id 不同
- 查找用户需要先有共同群聊或通过其他方式获取 open_id
- 当前权限限制：只能读取，不能修改用户信息

## 替代方案

如果无法直接查找用户：

1. **让用户在群里@目标人** — 从消息中获取 open_id
2. **从已有群成员中选择** — 列出成员让用户选择
3. **手动输入 open_id** — 用户从飞书个人设置中复制
