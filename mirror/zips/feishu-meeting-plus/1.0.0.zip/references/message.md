# Feishu Message Sending — 飞书消息发送

## 发送普通消息

```
message(channel="feishu", target=chat_id, message="纯文本消息")
```

## 发送富文本消息

飞书支持富文本格式，使用 HTML-like 标签：

```
message(channel="feishu", target=chat_id, message="""
<at id=all>所有人</at>
<b>会议通知</b>

📌 主题: 项目评审会
🕐 时间: 2026-04-15 14:00-15:00
📍 地点: 会议室A
""")
```

### 富文本标签

| 标签 | 效果 |
|------|------|
| `<at id=all>` | @所有人 |
| `<at id=ou_xxx>` | @指定用户 |
| `<b>text</b>` | 粗体 |
| `<i>text</i>` | 斜体 |
| `<a href="url">text</a>` | 链接 |
| `<font color="red">text</font>` | 颜色 |

## 发送卡片消息

卡片消息更美观，支持按钮和交互：

```
message(channel="feishu", target=chat_id, message=卡片JSON)
```

### 会议通知卡片模板

```json
{
  "config": {
    "wide_screen_mode": true
  },
  "header": {
    "title": {
      "tag": "plain_text",
      "content": "📅 会议通知"
    },
    "template": "blue"
  },
  "elements": [
    {
      "tag": "div",
      "text": {
        "tag": "lark_md",
        "content": "**主题**: 项目评审会\n**时间**: 2026-04-15 14:00-15:00\n**地点**: 会议室A"
      }
    },
    {
      "tag": "action",
      "actions": [
        {
          "tag": "button",
          "text": {
            "tag": "plain_text",
            "content": "确认参加"
          },
          "type": "primary"
        }
      ]
    }
  ]
}
```

## 回复消息

```
message(channel="feishu", target=chat_id, replyTo=messageId, message="回复内容")
```

## 线程回复

```
message(channel="feishu", target=chat_id, threadId=threadId, message="线程内容")
```

## @用户

```
# @所有人
message(channel="feishu", target=chat_id, message="<at id=all>请大家注意</at>")

# @指定用户
message(channel="feishu", target=chat_id, message="<at id=ou_xxx>请准备材料</at>")
```

## 常见场景

### 会议开始前提醒

```
message(channel="feishu", target=chat_id, message="<at id=all>会议将在15分钟后开始，请准时参加！")
```

### 会议纪要

```
message(channel="feishu", target=chat_id, message="""
<b>📝 会议纪要</b>
━━━━━━━━━━━━━━
<b>会议</b>: 项目评审会
<b>时间</b>: 2026-04-15

<b>决议事项</b>:
1. xxx
2. xxx

<b>待办</b>:
- [ ] xxx (负责人: @张三)
- [ ] xxx (负责人: @李四)
""")
```

### 会议变更通知

```
message(channel="feishu", target=chat_id, message="""
<at id=all><b>⚠️ 会议变更通知</b>

<b>原时间</b>: 4/15 14:00
<b>新时间</b>: 4/15 15:00
<b>原因</b>: 会议室冲突

请收到回复确认。
""")
```
