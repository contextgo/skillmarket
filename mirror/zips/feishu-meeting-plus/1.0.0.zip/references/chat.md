# Feishu Chat Management — 飞书群聊管理

## 创建群聊

通过 `message(action=send)` 发送到飞书时，可以创建新群聊：

```
message(channel="feishu", target="新群聊名称", message="初始化消息")
```

- `target` 可以是群名（创建新群）或已有 chat_id
- 创建群后返回 chat_id，后续操作用 chat_id

## 添加成员

```
message(channel="feishu", target=chat_id, targets=["ou_xxx1", "ou_xxx2"], message="欢迎加入会议群")
```

- `targets`: 用户 open_id 数组
- 一次可添加多个用户
- 用户已存在会自动跳过

## 获取群信息

```
feishu_chat(action="info", chat_id="oc_xxx")
```

返回:
- `name`: 群名称
- `owner_id`: 群主 open_id
- `member_count`: 成员数

## 获取群成员

```
feishu_chat(action="members", chat_id="oc_xxx", page_size=50)
```

返回成员列表，包含:
- `member_id`: 成员 open_id
- `name`: 显示名
- `avatar_url`: 头像

## 获取成员详情

```
feishu_chat(action="member_info", chat_id="oc_xxx", member_id="ou_xxx")
```

## 修改群名称

创建群后可以通过发送消息来管理，或通过飞书后台修改。

## 群公告

飞书群公告通过消息置顶实现：
- 发送重要消息后使用 `message(action=pin, messageId="xxx")`

## 常见场景

### 创建会议群

```
1. message(channel="feishu", target="📅 项目周会 - 4/15", message="会议群已创建")
   → 返回 chat_id

2. message(channel="feishu", target=chat_id, targets=[...], message="欢迎")
   → 添加参会人

3. message(channel="feishu", target=chat_id, message=会议通知)
   → 发送通知
```

### 查找群

如果不确定群是否存在，先尝试获取群信息，失败则创建新群。
