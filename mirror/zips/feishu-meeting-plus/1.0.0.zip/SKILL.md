---
name: feishu-meeting
description: >
  Feishu meeting automation. Auto-create meeting groups, add participants, send meeting notifications, find users.
  Triggers: feishu meeting, create meeting, schedule meeting, create group, add members, meeting invite, calendar, find user, 飞书会议, 创建会议, 预约会议, 建群, 拉群, 加人, 会议通知。
---

# Feishu Meeting Automation — 飞书会议自动化

Automate Feishu meeting workflows: create groups, add participants, send notifications, find users.

## Quick Workflow

1. **Identify meeting details** — title, time, attendees, location
2. **Find participants** — search by name/email/phone
3. **Create group chat** — with meeting name
4. **Add members** — invite all participants
5. **Send meeting notice** — formatted message with all details
6. **Optional** — set reminders, pin messages

## Core Workflows

### 1. 创建会议群聊 + 通知

```
输入: 会议标题、时间、地点、参会人
步骤:
  a. 用 feishu_chat(action=info) 确认当前上下文
  b. 用 message(action=send, channel=feishu) 创建群聊
  c. 逐个添加参会人 (message action 支持 targets 参数)
  d. 发送格式化会议通知
```

### 2. 查找参会人员

```
输入: 姓名/邮箱/手机号
步骤:
  a. 根据输入类型选择查找方式
  b. 返回用户 open_id 和显示名
  c. 用于后续加群操作
```

### 3. 发送会议通知

```
格式模板:
📅 会议通知
━━━━━━━━━━━━━━
📌 主题: {title}
🕐 时间: {start} ~ {end}
📍 地点: {location}
👥 参会人: {attendees}
━━━━━━━━━━━━━━
{agenda}
⏰ 请准时参加！
```

## API Usage Reference

For detailed API specs, see reference files:

| Topic | File | Description |
|-------|------|-------------|
| 群聊管理 | `references/chat.md` | 创建群、加人、改名、公告 |
| 消息发送 | `references/message.md` | 发送通知、富文本、卡片 |
| 用户查找 | `references/contact.md` | 按姓名/邮箱/手机号查找 |
| 会议模板 | `references/templates.md` | 各类会议通知模板 |

## Available Actions via message tool

| Action | Use |
|--------|-----|
| `send` | 发送消息到群/个人 |
| `channel-info` | 获取群信息 |
| `members` | 获取群成员列表 |
| `member-info` | 获取成员详情 |

## Parameters for feishu channel

- `channel`: `"feishu"`
- `target`: chat_id or user open_id
- `targets`: array of user open_ids (for adding members)
- `message`: plain text or formatted content
- `threadId`: for thread replies

## Error Handling

- **User not found**: 提示用户提供邮箱或手机号
- **Already in group**: 跳过，不重复添加
- **Permission denied**: 提示需要飞书应用权限
- **Rate limit**: 等待后重试，不要频繁调用

## Best Practices

- 群名格式: `📅 {会议标题} - {日期}`
- 通知消息使用 emoji 分隔，清晰易读
- 会前 15 分钟可设置提醒（用 cron）
- 重要会议用富文本或卡片消息
- 会后发送纪要到同一群组

## Limitations

- 当前应用无 calendar:event 权限，无法直接创建日历日程
- 可通过群聊 + 消息通知替代日程功能
- 用户查找依赖 contact:user.id:readonly 权限
