#!/bin/bash

se_get_file_perm() {
  local file="$1"
  local perm=""
  if stat -f "%Lp" "$file" >/dev/null 2>&1; then
    perm="$(stat -f "%Lp" "$file" 2>/dev/null || true)"
  elif stat -c "%a" "$file" >/dev/null 2>&1; then
    perm="$(stat -c "%a" "$file" 2>/dev/null || true)"
  fi
  echo "$perm"
}

se_try_load_env_file() {
  local file="$1"
  [ -f "$file" ] || return 1
  local perm
  perm="$(se_get_file_perm "$file")"
  if [ -n "$perm" ] && [ "$perm" != "600" ] && [ "$perm" != "400" ]; then
    echo "⚠️ WARNING: API Key 文件权限不是 600/400（当前: $perm）。建议执行: chmod 600 \"$file\""
  fi
  source "$file"
  return 0
}

se_load_api_key() {
  if [ -n "$STOCK_API_KEY" ]; then
    return 0
  fi

  local candidates=(
    "$STOCKEARNING_ENV_FILE"
    "$HOME/.openclaw/stockearning.env"
    "$HOME/.config/openclaw/stockearning.env"
    "$HOME/.config/hermes/stockearning.env"
    "$HOME/.hermes/stockearning.env"
  )

  local f
  for f in "${candidates[@]}"; do
    if se_try_load_env_file "$f"; then
      break
    fi
  done

  if [ -z "$STOCK_API_KEY" ]; then
    echo "⚠️ ERROR: STOCK_API_KEY is missing."
    echo "mkdir -p ~/.config/stockearning && (umask 077; printf 'export STOCK_API_KEY=\"sk_your_api_key_here\"\\n' > ~/.config/stockearning/stockearning.env)"
    echo "export STOCK_API_KEY=\"sk_your_api_key_here\""
    return 1
  fi

  return 0
}

se_require_trusted_base_url() {
  STOCK_BASE_URL="${STOCK_BASE_URL%/}"

  if [[ "$STOCK_BASE_URL" != https://* ]]; then
    echo "Error: STOCK_BASE_URL must start with https://"
    return 1
  fi

  if [ -n "$DEFAULT_STOCK_BASE_URL" ] && [ "$STOCK_BASE_URL" != "$DEFAULT_STOCK_BASE_URL" ]; then
    if [ "${STOCKEARNING_TRUST_BASE_URL:-0}" != "1" ]; then
      echo "Error: STOCK_BASE_URL is customized. Refusing to send API key to an untrusted endpoint."
      echo "If you trust this endpoint, set STOCKEARNING_TRUST_BASE_URL=1 and try again."
      return 1
    fi

    if ! curl -sS --max-time 5 -I "$STOCK_BASE_URL" >/dev/null 2>&1; then
      echo "Error: Cannot verify custom STOCK_BASE_URL is reachable."
      return 1
    fi
  fi

  return 0
}

se_request() {
  local method="$1"
  local path="$2"
  local json_data="$3"

  if ! se_load_api_key; then
    return 1
  fi

  if ! se_require_trusted_base_url; then
    return 1
  fi

  if [ "$method" = "GET" ]; then
    curl -s -H "X-API-Key: $STOCK_API_KEY" "${STOCK_BASE_URL}${path}"
    return $?
  fi

  if [ "$method" = "POST" ] || [ "$method" = "PUT" ]; then
    if [ -n "$json_data" ]; then
      curl -s -X "$method" -H "Content-Type: application/json" -H "X-API-Key: $STOCK_API_KEY" -d "$json_data" "${STOCK_BASE_URL}${path}"
      return $?
    fi
    curl -s -X "$method" -H "X-API-Key: $STOCK_API_KEY" "${STOCK_BASE_URL}${path}"
    return $?
  fi

  echo "Error: Unsupported HTTP method $method"
  return 1
}
