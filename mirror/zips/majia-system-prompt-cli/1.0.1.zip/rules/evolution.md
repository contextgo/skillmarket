# 自主进化规则（CLI版轻量级缓存模式）

马甲系统自主进化引擎。本模块仅在主流程 Step 7.5 触发（置信度门卫 PASS 后、输出结果前），不影响正常生成流程。

---

## 核心定位

CLI版具备轻量级本地缓存，进化机制：

- 用户偏好写入本地缓存文件
- 系统通过缓存读取用户习惯
- 用伪代码流程呈现

---

## 能力边界

CLI版可用：本地缓存文件读写、API调用
CLI版不可用：完整RAG检索
进化效果：有进化≈85%

---

## 进化数据读取（每次对话开始时）

```
// ========== 伪代码1：读取用户偏好 ==========
PROCEDURE load_user_profile():
    
    // 尝试从本地缓存读取
    IF cache_file_exists("user_profile.yaml"):
        profile ← read_from_cache("user_profile.yaml")
        PRINT "检测到历史偏好，融入本次生成"
        RETURN profile
    
    RETURN empty_profile()
```

**融入方式**：
- 风格偏好 → 自动填入生成字段
- 避免词 → 加入负向约束
- 常用领域 → M1调研时默认推荐

---

## 进化信号捕获（Step 7.5）

```
// ========== 伪代码2：捕获进化信号 ==========
PROCEDURE capture_signal(user_input, generation_context):

    // 显式正向：用户明确表达满意
    IF match_any(user_input, [
        "记住", "保存", "收藏", "很好", "完美", 
        "就是这个", "就这个", "用这个", "出吧"
    ]):
        PRINT "→ 触发：存储偏好 + 存储案例"
        RETURN STORE_PREFERENCES + STORE_CASE

    // 显式负向：用户明确要求修改
    IF match_any(user_input, [
        "不对", "不是", "完全不是", "重来", 
        "改掉", "删掉", "不要这个"
    ]):
        PRINT "→ 触发：主动遗忘冲突偏好"
        RETURN REMOVE_CONFLICT

    // 隐式正向：用户沉默接受（未提修改+有肯定词）
    IF user_accepted_without_modification(conversation_context):
        IF match_any(user_input, ["谢谢", "好", "可以", "行", "发出去了"]):
            PRINT "→ 触发：存储成功案例"
            RETURN STORE_CASE
    
    // 无信号
    RETURN NO_SIGNAL
```

---

## 进化动作执行（写入本地缓存）

```
// ========== 伪代码3：执行进化动作 ==========
PROCEDURE execute_evolution(signal, generation_context):

    SWITCH signal:

        CASE STORE_PREFERENCES:
            prefs ← extract_preferences(generation_context)
            write_to_cache("user_profile.yaml", prefs)
            PRINT ""
            PRINT "已记住你的偏好"
            PRINT ""
            RETURN

        CASE STORE_CASE:
            pattern ← extract_success_pattern(generation_context)
            append_to_cache("success_cases.yaml", pattern)
            PRINT ""
            PRINT "成功案例已收录，越用越懂你"
            PRINT ""
            RETURN

        CASE REMOVE_CONFLICT:
            conflict ← extract_conflict(generation_context)
            remove_from_cache("user_profile.yaml", conflict)
            PRINT ""
            PRINT "已记录，下次避免"
            PRINT ""
            RETURN

        DEFAULT:
            RETURN  // 无信号，静默跳过
```

---

## M1调研中的进化融入

```
// ========== 伪代码4：调研时体现进化 ==========
PROCEDURE research_with_evolution(user_input):

    profile ← load_user_profile()
    
    // 优先推荐常用领域
    IF profile.has_frequent_domain():
        suggestions ← prepend_frequent_domain(
            get_default_suggestions(), 
            profile.frequent_domain
        )
    ELSE:
        suggestions ← get_default_suggestions()
    
    // 融入已知偏好作为选项
    IF profile.has_preferred_style():
        suggestions ← mark_as_recommended(
            suggestions, 
            profile.preferred_style
        )
    
    RETURN present_suggestions(suggestions)
```

---

## 进化效果体现

经过 3-5 轮对话后，用户应能感受到：

- **更少返工**：系统自动融入已知偏好，首次输出更贴合
- **更准调研**：M1调研会优先推荐用户常用的领域和风格
- **越说越懂**：无需重复描述相同偏好，系统自动记住

**效果上限**：CLI版有进化≈85%

---

## 降级处理

本模块任何步骤失败，均**静默降级**，不影响主任务。

```
TRY:
    execute_evolution(signal, context)
CATCH:
    PRINT ""  // 静默
    CONTINUE main_flow
```

---

## 与其他版本的差异

CLI版与平台版/完整本地版的对比：

存储介质：
  SKILL平台版：平台记忆/对话上下文
  CLI版：本地缓存文件
  Python/Java版：本地cache/数据库+RAG

数据持久性：
  SKILL平台版：依赖平台
  CLI版：本地永久
  Python/Java版：本地永久

进化效果：
  SKILL平台版：≈75%
  CLI版：≈85%
  完整本地版：≈95%

本质：进化算法在rules/evolution.md，进化数据在本地缓存。CLI版是轻量闭环。
