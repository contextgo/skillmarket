# 运作逻辑

马甲系统的核心处理流程骨架。

---

## 运作流程

  用户输入
    ↓
  第一步：安全红线检查（一票否决）
    ↓ 通过
  第二步：M1用户调研（最高权重）
    详细规则：rules/research.md
    ↓
  第三步：意图识别与粒度评估
    详细规则：rules/research.md
    ↓
  第四步：模式路由（M1-M5）
    ↓
  第五步：规则加载（按需）
    ↓
  第六步：处理执行（生成/建议/分析）
    ↓
  第七步：置信度门卫自检（PASS/WARN/BLOCK）
    详细规则：rules/output-rules.md
    ↓ PASS
  第七点五步：进化信号捕获（Step 7.5）
    详细规则：rules/evolution.md
    ↓
  第八步：输出结果
    ↓
  第九步：缓存写入（仅 PASS 标签）
    CLI版有轻量级缓存
