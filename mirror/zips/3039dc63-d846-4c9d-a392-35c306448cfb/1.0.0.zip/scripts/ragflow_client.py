#!/usr/bin/env python3
"""
RAGFlow API 客户端 - 用于操作 RAGFlow 知识库系统

这个模块提供了与 RAGFlow API 交互的完整功能，包括：
- 知识库管理（创建、删除、列出）
- 文档管理（上传、删除、列出）
- 知识检索
- RAG 对话

使用前请配置环境变量：
- RAGFLOW_BASE_URL: RAGFlow 服务地址
- RAGFLOW_API_KEY: RAGFlow API 密钥
"""

import logging
import os
from typing import Any, Dict, List, Optional
import requests
from pathlib import Path

logger = logging.getLogger(__name__)


class RagflowClient:
    """RAGFlow API 客户端类"""

    def __init__(
        self,
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
        enabled: bool = True
    ) -> None:
        """
        初始化 RAGFlow 客户端

        Args:
            base_url: RAGFlow 服务地址（可选，默认从环境变量读取）
            api_key: RAGFlow API 密钥（可选，默认从环境变量读取）
            enabled: 是否启用 RAGFlow 服务
        """
        self._enabled = enabled
        self._base_url = (base_url or os.getenv("RAGFLOW_BASE_URL", "")).rstrip("/")
        self._api_key = api_key or os.getenv("RAGFLOW_API_KEY", "")
        
        self._session = requests.Session()
        self._session.headers.update({
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json"
        })
        
        if self._enabled and self.available:
            self._test_connection()

    def _test_connection(self) -> None:
        """测试与 RAGFlow 服务的连接"""
        try:
            response = self._session.get(f"{self._base_url}/api/v1/datasets", timeout=5)
            if response.status_code == 200:
                logger.info("RAGFlow connected: %s", self._base_url)
            else:
                logger.warning("RAGFlow connection failed with status: %s", response.status_code)
        except Exception as exc:
            logger.warning("RAGFlow unavailable: %s", exc)

    @property
    def available(self) -> bool:
        """检查 RAGFlow 服务是否可用"""
        return self._enabled and bool(self._api_key) and bool(self._base_url)

    def get_knowledge_bases(self) -> List[Dict[str, Any]]:
        """
        获取所有知识库列表

        Returns:
            知识库列表，每个知识库包含 id, name, description 等字段
        """
        if not self.available:
            return []
        try:
            response = self._session.get(f"{self._base_url}/api/v1/datasets")
            if response.status_code == 200:
                result = response.json()
                if result.get("code") == 0:
                    return result.get("data", [])
            return []
        except Exception as exc:
            logger.error("Failed to get knowledge bases: %s", exc)
            return []

    def create_knowledge_base(self, name: str, description: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """
        创建新知识库

        Args:
            name: 知识库名称
            description: 知识库描述（可选）

        Returns:
            创建的知识库信息，失败返回 None
        """
        if not self.available:
            return None
        try:
            payload = {"name": name}
            if description:
                payload["description"] = description
            response = self._session.post(f"{self._base_url}/api/v1/datasets", json=payload)
            if response.status_code == 200:
                result = response.json()
                if result.get("code") == 0:
                    return result.get("data")
            logger.error("Failed to create knowledge base: %s", response.text)
            return None
        except Exception as exc:
            logger.error("Failed to create knowledge base: %s", exc)
            return None

    def delete_knowledge_base(self, kb_id: str) -> bool:
        """
        删除知识库

        Args:
            kb_id: 知识库 ID

        Returns:
            是否删除成功
        """
        if not self.available:
            return False
        try:
            response = self._session.delete(f"{self._base_url}/api/v1/datasets/{kb_id}")
            if response.status_code == 200:
                result = response.json()
                return result.get("code") == 0
            return False
        except Exception as exc:
            logger.error("Failed to delete knowledge base: %s", exc)
            return False

    def get_documents(self, kb_id: str) -> List[Dict[str, Any]]:
        """
        获取知识库中的文档列表

        Args:
            kb_id: 知识库 ID

        Returns:
            文档列表
        """
        if not self.available:
            return []
        try:
            response = self._session.get(f"{self._base_url}/api/v1/datasets/{kb_id}/documents")
            if response.status_code == 200:
                result = response.json()
                if result.get("code") == 0:
                    docs = result.get("data", {}).get("docs", [])
                    for doc in docs:
                        if doc.get("dataset_id") and not doc.get("knowledge_base_id"):
                            doc["knowledge_base_id"] = doc["dataset_id"]
                    return docs
            return []
        except Exception as exc:
            logger.error("Failed to get documents: %s", exc)
            return []

    def upload_document(self, kb_id: str, file_path: str) -> Optional[Dict[str, Any]]:
        """
        上传文档到知识库

        Args:
            kb_id: 知识库 ID
            file_path: 文档文件路径

        Returns:
            上传的文档信息，失败返回 None
        """
        if not self.available:
            return None
        try:
            with open(file_path, 'rb') as f:
                files = {'file': f}
                headers = {"Authorization": f"Bearer {self._api_key}"}
                response = requests.post(
                    f"{self._base_url}/api/v1/datasets/{kb_id}/documents",
                    files=files,
                    headers=headers
                )
            if response.status_code == 200:
                result = response.json()
                if result.get("code") == 0:
                    return result.get("data")
            logger.error("Failed to upload document: %s", response.text)
            return None
        except Exception as exc:
            logger.error("Failed to upload document: %s", exc)
            return None

    def delete_document(self, kb_id: str, doc_id: str) -> bool:
        """
        删除知识库中的文档

        Args:
            kb_id: 知识库 ID
            doc_id: 文档 ID

        Returns:
            是否删除成功
        """
        if not self.available:
            return False
        try:
            response = self._session.delete(f"{self._base_url}/api/v1/datasets/{kb_id}/documents/{doc_id}")
            if response.status_code == 200:
                result = response.json()
                return result.get("code") == 0
            return False
        except Exception as exc:
            logger.error("Failed to delete document: %s", exc)
            return False

    def retrieve(self, kb_id: str, query: str, top_k: int = 5) -> List[Dict[str, Any]]:
        """
        在知识库中检索相关知识片段

        Args:
            kb_id: 知识库 ID
            query: 查询文本
            top_k: 返回的结果数量（默认 5）

        Returns:
            检索结果列表，每个结果包含 content, score 等字段
        """
        if not self.available:
            return []
        try:
            payload = {
                "dataset_ids": [kb_id],
                "question": query,
                "top_k": top_k
            }
            response = self._session.post(f"{self._base_url}/api/v1/retrieval", json=payload)
            if response.status_code == 200:
                result = response.json()
                if result.get("code") == 0:
                    chunks = result.get("data", {}).get("chunks", [])
                    processed_chunks = []
                    for i, chunk in enumerate(chunks):
                        processed_chunk = chunk.copy()
                        if "score" not in processed_chunk:
                            processed_chunk["score"] = max(0.1, 1.0 - (i * 0.05))
                        processed_chunks.append(processed_chunk)
                    logger.info(f"RAGFlow retrieval returned {len(processed_chunks)} chunks")
                    return processed_chunks
            return []
        except Exception as exc:
            logger.error("Failed to retrieve: %s", exc)
            return []

    def simple_chat(
        self,
        kb_id: str,
        question: str,
        top_k: int = 5
    ) -> Dict[str, Any]:
        """
        简单的 RAG 对话：检索知识库并生成回答

        注意：这个方法只返回检索到的上下文，
        实际的 LLM 调用需要用户自己实现。

        Args:
            kb_id: 知识库 ID
            question: 用户问题
            top_k: 检索的知识片段数量

        Returns:
            包含检索结果和建议提示词的字典
        """
        retrieval_results = self.retrieve(kb_id, question, top_k=top_k)
        
        if not retrieval_results:
            return {
                "answer": "未在知识库中找到相关内容。",
                "sources": [],
                "retrieval_count": 0,
                "context": "",
                "suggested_prompt": ""
            }
        
        context_parts = []
        sources = []
        seen_docs = set()
        
        for i, chunk in enumerate(retrieval_results, 1):
            content = chunk.get("content", "").strip()
            if content:
                context_parts.append(f"[文档片段 {i}]\n{content}")
                doc_name = chunk.get("document_keyword") or chunk.get("document_name", "未知文档")
                if doc_name and doc_name not in seen_docs:
                    sources.append(f"{len(seen_docs) + 1}. {doc_name}")
                    seen_docs.add(doc_name)
        
        context = "\n\n".join(context_parts)
        sources_text = "\n".join(sources)
        
        system_prompt = """你是一个基于知识库的AI助手。请根据提供的文档片段回答用户的问题。

要求：
1. 基于提供的文档片段内容回答问题
2. 如果文档片段中没有相关信息，请明确说明
3. 回答要准确、简洁、有条理
4. 可以适当引用文档片段中的内容
5. 如果涉及多个文档片段，请综合信息给出完整回答"""

        user_prompt = f"""基于以下文档片段，请回答问题：

=== 文档片段 ===
{context}

=== 问题 ===
{question}

请根据上述文档片段回答问题。"""

        return {
            "sources": sources,
            "retrieval_count": len(retrieval_results),
            "context": context,
            "system_prompt": system_prompt,
            "user_prompt": user_prompt,
            "retrieval_results": retrieval_results
        }


def main():
    """命令行演示"""
    import argparse
    
    parser = argparse.ArgumentParser(description="RAGFlow API 客户端")
    parser.add_argument("--list-kbs", action="store_true", help="列出所有知识库")
    parser.add_argument("--list-docs", metavar="KB_ID", help="列出指定知识库的文档")
    parser.add_argument("--create-kb", nargs=2, metavar=("NAME", "DESC"), help="创建知识库")
    parser.add_argument("--upload", nargs=2, metavar=("KB_ID", "FILE"), help="上传文档")
    parser.add_argument("--retrieve", nargs=3, metavar=("KB_ID", "QUERY", "TOP_K"), help="检索知识")
    
    args = parser.parse_args()
    
    logging.basicConfig(level=logging.INFO)
    client = RagflowClient()
    
    if args.list_kbs:
        kbs = client.get_knowledge_bases()
        print("知识库列表:")
        for kb in kbs:
            print(f"  - {kb.get('name')} (ID: {kb.get('id')})")
    
    elif args.list_docs:
        docs = client.get_documents(args.list_docs)
        print("文档列表:")
        for doc in docs:
            print(f"  - {doc.get('name')} (ID: {doc.get('id')})")
    
    elif args.create_kb:
        name, desc = args.create_kb
        kb = client.create_knowledge_base(name, desc)
        if kb:
            print(f"知识库创建成功: {kb}")
        else:
            print("知识库创建失败")
    
    elif args.upload:
        kb_id, file_path = args.upload
        doc = client.upload_document(kb_id, file_path)
        if doc:
            print(f"文档上传成功: {doc}")
        else:
            print("文档上传失败")
    
    elif args.retrieve:
        kb_id, query, top_k = args.retrieve
        results = client.retrieve(kb_id, query, int(top_k))
        print(f"检索到 {len(results)} 个结果:")
        for i, result in enumerate(results, 1):
            print(f"\n--- 结果 {i} (分数: {result.get('score', 0):.3f}) ---")
            print(result.get('content', '')[:200])


if __name__ == "__main__":
    main()
