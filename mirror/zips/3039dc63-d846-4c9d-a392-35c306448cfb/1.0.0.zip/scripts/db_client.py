#!/usr/bin/env python3
"""
数据库交互客户端 - 用于管理知识库相关的数据库操作

这个模块提供了与数据库交互的完整功能，包括：
- 知识库文档管理（创建、查询、更新、删除）
- 研究任务管理
- 研究报告管理

使用前请配置环境变量：
- DATABASE_URL: 完整的数据库连接URL（可选，优先使用）
- DB_TYPE: 数据库类型 (mysql 或 sqlite，默认 sqlite)
- DB_HOST: 数据库主机地址（MySQL）
- DB_PORT: 数据库端口（MySQL，默认 3306）
- DB_USER: 数据库用户名（MySQL）
- DB_PASSWORD: 数据库密码（MySQL）
- DB_NAME: 数据库名称（MySQL）
"""

import logging
import os
from contextlib import contextmanager
from datetime import datetime
from typing import Any, Dict, Generator, List, Optional, Type, TypeVar
from urllib.parse import quote_plus

from sqlalchemy import JSON, Boolean, Column, DateTime, ForeignKey, Integer, String, Text, create_engine, func
from sqlalchemy.orm import Session, declarative_base, relationship, sessionmaker

logger = logging.getLogger(__name__)

Base = declarative_base()
T = TypeVar("T", bound=Base)


class KnowledgeDocument(Base):
    """知识库文档模型"""
    __tablename__ = "knowledge_documents"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(500), index=True, nullable=False)
    source_type = Column(String(100), index=True, nullable=False, default="DOCUMENT")
    source_url = Column(String(1000), nullable=True)
    content_summary = Column(Text, nullable=True)
    metadata_info = Column(JSON, nullable=True)
    is_parsed = Column(Boolean, default=False)
    ragflow_dataset_id = Column(String(200), index=True, nullable=True)
    ragflow_document_id = Column(String(200), index=True, nullable=True)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())


class ResearchTask(Base):
    """研究任务模型"""
    __tablename__ = "research_tasks"

    id = Column(Integer, primary_key=True, index=True)
    company_name = Column(String(200), index=True, nullable=False)
    research_title = Column(String(500), nullable=False)
    research_goal = Column(Text, nullable=False)
    focus_domains = Column(JSON, nullable=True)
    output_depth = Column(String(50), default="standard")
    status = Column(String(50), default="pending", index=True)
    current_step = Column(String(50), nullable=True)
    progress = Column(Integer, default=0)
    iteration = Column(Integer, default=1)
    total_iterations = Column(Integer, default=3)
    state_data = Column(JSON, nullable=True)
    report_content = Column(Text, nullable=True)
    error_message = Column(Text, nullable=True)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())


class ResearchReport(Base):
    """研究报告模型"""
    __tablename__ = "research_reports"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(300), nullable=False)
    company_name = Column(String(200), index=True, nullable=False)
    research_goal = Column(Text, nullable=True)
    file_path = Column(String(500), nullable=True)
    status = Column(String(50), default="draft")
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())


class DatabaseClient:
    """数据库交互客户端类"""

    def __init__(
        self,
        database_url: Optional[str] = None,
        db_type: Optional[str] = None,
        host: Optional[str] = None,
        port: Optional[int] = None,
        user: Optional[str] = None,
        password: Optional[str] = None,
        db_name: Optional[str] = None,
    ) -> None:
        """
        初始化数据库客户端

        Args:
            database_url: 完整的数据库连接URL（可选，优先使用）
            db_type: 数据库类型 (mysql 或 sqlite)
            host: 数据库主机地址
            port: 数据库端口
            user: 数据库用户名
            password: 数据库密码
            db_name: 数据库名称
        """
        self._database_url = self._build_database_url(
            database_url, db_type, host, port, user, password, db_name
        )
        self._engine = None
        self._SessionLocal = None
        self._initialized = False

    def _build_database_url(
        self,
        database_url: Optional[str],
        db_type: Optional[str],
        host: Optional[str],
        port: Optional[int],
        user: Optional[str],
        password: Optional[str],
        db_name: Optional[str],
    ) -> str:
        """构建数据库连接URL"""
        # 优先使用传入的完整URL
        if database_url:
            return database_url

        # 从环境变量读取配置
        env_url = os.getenv("DATABASE_URL")
        if env_url:
            return env_url

        db_type = db_type or os.getenv("DB_TYPE", "sqlite")

        if db_type.lower() == "mysql":
            host = host or os.getenv("DB_HOST", "localhost")
            port = port or int(os.getenv("DB_PORT", "3306"))
            user = user or os.getenv("DB_USER", "root")
            password = password or os.getenv("DB_PASSWORD", "")
            db_name = db_name or os.getenv("DB_NAME", "ragflow_db")
            charset = os.getenv("DB_CHARSET", "utf8mb4")

            password = quote_plus(password)
            return (
                f"mysql+pymysql://{user}:{password}@{host}:{port}/{db_name}"
                f"?charset={charset}"
            )
        else:
            # SQLite 默认配置
            db_path = os.getenv("SQLITE_PATH", "./ragflow_data.db")
            return f"sqlite:///{db_path}"

    def initialize(self) -> bool:
        """
        初始化数据库连接和表结构

        Returns:
            是否初始化成功
        """
        try:
            connect_args = {}
            if self._database_url.startswith("sqlite"):
                connect_args = {"check_same_thread": False}

            self._engine = create_engine(
                self._database_url, pool_pre_ping=True, connect_args=connect_args
            )
            self._SessionLocal = sessionmaker(
                autocommit=False, autoflush=False, bind=self._engine
            )

            # 创建所有表
            Base.metadata.create_all(bind=self._engine)

            self._initialized = True
            logger.info("Database initialized successfully")
            return True
        except Exception as exc:
            logger.error("Failed to initialize database: %s", exc)
            return False

    @property
    def available(self) -> bool:
        """检查数据库是否可用"""
        return self._initialized and self._engine is not None

    @contextmanager
    def get_session(self) -> Generator[Session, None, None]:
        """
        获取数据库会话的上下文管理器

        Yields:
            SQLAlchemy Session 对象
        """
        if not self._SessionLocal:
            raise RuntimeError("Database not initialized. Call initialize() first.")

        session = self._SessionLocal()
        try:
            yield session
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    # ==================== 知识库文档操作 ====================

    def create_knowledge_document(
        self,
        title: str,
        source_type: str = "DOCUMENT",
        source_url: Optional[str] = None,
        content_summary: Optional[str] = None,
        metadata_info: Optional[Dict[str, Any]] = None,
        ragflow_dataset_id: Optional[str] = None,
        ragflow_document_id: Optional[str] = None,
    ) -> Optional[KnowledgeDocument]:
        """
        创建知识库文档记录

        Args:
            title: 文档标题
            source_type: 来源类型
            source_url: 来源URL
            content_summary: 内容摘要
            metadata_info: 元数据信息
            ragflow_dataset_id: RAGFlow 知识库ID
            ragflow_document_id: RAGFlow 文档ID

        Returns:
            创建的文档对象
        """
        with self.get_session() as session:
            doc = KnowledgeDocument(
                title=title,
                source_type=source_type,
                source_url=source_url,
                content_summary=content_summary,
                metadata_info=metadata_info or {},
                ragflow_dataset_id=ragflow_dataset_id,
                ragflow_document_id=ragflow_document_id,
            )
            session.add(doc)
            session.flush()
            session.refresh(doc)
            return doc

    def get_knowledge_document(self, doc_id: int) -> Optional[KnowledgeDocument]:
        """
        根据ID获取知识库文档

        Args:
            doc_id: 文档ID

        Returns:
            文档对象
        """
        with self.get_session() as session:
            return session.query(KnowledgeDocument).filter(KnowledgeDocument.id == doc_id).first()

    def list_knowledge_documents(
        self,
        source_type: Optional[str] = None,
        search: Optional[str] = None,
        skip: int = 0,
        limit: int = 100,
    ) -> tuple[List[KnowledgeDocument], int]:
        """
        列出知识库文档

        Args:
            source_type: 按来源类型筛选
            search: 搜索关键词
            skip: 跳过记录数
            limit: 返回记录数

        Returns:
            (文档列表, 总数)
        """
        with self.get_session() as session:
            query = session.query(KnowledgeDocument)

            if source_type:
                query = query.filter(KnowledgeDocument.source_type == source_type)

            if search:
                query = query.filter(
                    KnowledgeDocument.title.contains(search)
                    | KnowledgeDocument.content_summary.contains(search)
                )

            total = query.count()
            docs = (
                query.order_by(KnowledgeDocument.created_at.desc())
                .offset(skip)
                .limit(limit)
                .all()
            )
            return docs, total

    def update_knowledge_document(
        self, doc_id: int, **kwargs
    ) -> Optional[KnowledgeDocument]:
        """
        更新知识库文档

        Args:
            doc_id: 文档ID
            **kwargs: 要更新的字段

        Returns:
            更新后的文档对象
        """
        with self.get_session() as session:
            doc = session.query(KnowledgeDocument).filter(KnowledgeDocument.id == doc_id).first()
            if not doc:
                return None

            for key, value in kwargs.items():
                if hasattr(doc, key):
                    setattr(doc, key, value)

            doc.updated_at = datetime.utcnow()
            session.flush()
            session.refresh(doc)
            return doc

    def delete_knowledge_document(self, doc_id: int) -> bool:
        """
        删除知识库文档

        Args:
            doc_id: 文档ID

        Returns:
            是否删除成功
        """
        with self.get_session() as session:
            doc = session.query(KnowledgeDocument).filter(KnowledgeDocument.id == doc_id).first()
            if not doc:
                return False

            session.delete(doc)
            return True

    def sync_from_ragflow_document(
        self,
        ragflow_doc: Dict[str, Any],
        kb_id: str,
        source_type: str = "DOCUMENT",
    ) -> KnowledgeDocument:
        """
        从 RAGFlow 文档同步到数据库

        Args:
            ragflow_doc: RAGFlow 文档数据
            kb_id: 知识库ID
            source_type: 来源类型

        Returns:
            同步的文档对象
        """
        with self.get_session() as session:
            existing = (
                session.query(KnowledgeDocument)
                .filter(
                    KnowledgeDocument.ragflow_dataset_id == kb_id,
                    KnowledgeDocument.ragflow_document_id == ragflow_doc.get("id"),
                )
                .first()
            )

            if existing:
                return existing

            doc = KnowledgeDocument(
                title=ragflow_doc.get("name", ragflow_doc.get("filename", "Unknown")),
                source_type=source_type,
                source_url=f"ragflow://{kb_id}/{ragflow_doc.get('id')}",
                content_summary="",
                metadata_info={
                    "ragflow_dataset_id": kb_id,
                    "ragflow_document_id": ragflow_doc.get("id"),
                    "upload_result": ragflow_doc,
                },
                is_parsed=ragflow_doc.get("run") == "SUCCESS",
                ragflow_dataset_id=kb_id,
                ragflow_document_id=ragflow_doc.get("id"),
            )
            session.add(doc)
            session.flush()
            session.refresh(doc)
            return doc

    # ==================== 研究任务操作 ====================

    def create_research_task(
        self,
        company_name: str,
        research_title: str,
        research_goal: str,
        focus_domains: Optional[List[str]] = None,
        output_depth: str = "standard",
        total_iterations: int = 3,
    ) -> Optional[ResearchTask]:
        """
        创建研究任务

        Args:
            company_name: 公司名称
            research_title: 研究标题
            research_goal: 研究目标
            focus_domains: 关注领域列表
            output_depth: 输出深度
            total_iterations: 总迭代次数

        Returns:
            创建的任务对象
        """
        with self.get_session() as session:
            task = ResearchTask(
                company_name=company_name,
                research_title=research_title,
                research_goal=research_goal,
                focus_domains=focus_domains or [],
                output_depth=output_depth,
                total_iterations=total_iterations,
            )
            session.add(task)
            session.flush()
            session.refresh(task)
            return task

    def get_research_task(self, task_id: int) -> Optional[ResearchTask]:
        """
        根据ID获取研究任务

        Args:
            task_id: 任务ID

        Returns:
            任务对象
        """
        with self.get_session() as session:
            return session.query(ResearchTask).filter(ResearchTask.id == task_id).first()

    def list_research_tasks(
        self,
        company_name: Optional[str] = None,
        status: Optional[str] = None,
        skip: int = 0,
        limit: int = 100,
    ) -> tuple[List[ResearchTask], int]:
        """
        列出研究任务

        Args:
            company_name: 按公司名称筛选
            status: 按状态筛选
            skip: 跳过记录数
            limit: 返回记录数

        Returns:
            (任务列表, 总数)
        """
        with self.get_session() as session:
            query = session.query(ResearchTask)

            if company_name:
                query = query.filter(ResearchTask.company_name == company_name)

            if status:
                query = query.filter(ResearchTask.status == status)

            total = query.count()
            tasks = (
                query.order_by(ResearchTask.created_at.desc())
                .offset(skip)
                .limit(limit)
                .all()
            )
            return tasks, total

    def update_research_task_status(
        self,
        task_id: int,
        status: str,
        progress: Optional[int] = None,
        current_step: Optional[str] = None,
        error_message: Optional[str] = None,
    ) -> Optional[ResearchTask]:
        """
        更新研究任务状态

        Args:
            task_id: 任务ID
            status: 新状态
            progress: 进度百分比
            current_step: 当前步骤
            error_message: 错误信息

        Returns:
            更新后的任务对象
        """
        with self.get_session() as session:
            task = session.query(ResearchTask).filter(ResearchTask.id == task_id).first()
            if not task:
                return None

            task.status = status
            if progress is not None:
                task.progress = progress
            if current_step:
                task.current_step = current_step
            if error_message:
                task.error_message = error_message

            session.flush()
            session.refresh(task)
            return task

    # ==================== 研究报告操作 ====================

    def create_research_report(
        self,
        title: str,
        company_name: str,
        research_goal: Optional[str] = None,
        file_path: Optional[str] = None,
        status: str = "draft",
    ) -> Optional[ResearchReport]:
        """
        创建研究报告

        Args:
            title: 报告标题
            company_name: 公司名称
            research_goal: 研究目标
            file_path: 文件路径
            status: 状态

        Returns:
            创建的报告对象
        """
        with self.get_session() as session:
            report = ResearchReport(
                title=title,
                company_name=company_name,
                research_goal=research_goal,
                file_path=file_path,
                status=status,
            )
            session.add(report)
            session.flush()
            session.refresh(report)
            return report

    def get_research_report(self, report_id: int) -> Optional[ResearchReport]:
        """
        根据ID获取研究报告

        Args:
            report_id: 报告ID

        Returns:
            报告对象
        """
        with self.get_session() as session:
            return session.query(ResearchReport).filter(ResearchReport.id == report_id).first()

    def list_research_reports(
        self,
        company_name: Optional[str] = None,
        status: Optional[str] = None,
        skip: int = 0,
        limit: int = 100,
    ) -> tuple[List[ResearchReport], int]:
        """
        列出研究报告

        Args:
            company_name: 按公司名称筛选
            status: 按状态筛选
            skip: 跳过记录数
            limit: 返回记录数

        Returns:
            (报告列表, 总数)
        """
        with self.get_session() as session:
            query = session.query(ResearchReport)

            if company_name:
                query = query.filter(ResearchReport.company_name == company_name)

            if status:
                query = query.filter(ResearchReport.status == status)

            total = query.count()
            reports = (
                query.order_by(ResearchReport.created_at.desc())
                .offset(skip)
                .limit(limit)
                .all()
            )
            return reports, total


def main():
    """命令行演示"""
    import argparse

    parser = argparse.ArgumentParser(description="数据库交互客户端")
    parser.add_argument("--init", action="store_true", help="初始化数据库")
    parser.add_argument("--list-docs", action="store_true", help="列出知识库文档")
    parser.add_argument("--list-tasks", action="store_true", help="列出研究任务")
    parser.add_argument("--list-reports", action="store_true", help="列出研究报告")

    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO)
    client = DatabaseClient()

    if args.init:
        if client.initialize():
            print("数据库初始化成功")
        else:
            print("数据库初始化失败")

    elif args.list_docs:
        if not client.initialize():
            print("数据库初始化失败")
            return
        docs, total = client.list_knowledge_documents()
        print(f"知识库文档 (共 {total} 条):")
        for doc in docs:
            print(f"  - {doc.title} (ID: {doc.id}, 类型: {doc.source_type})")

    elif args.list_tasks:
        if not client.initialize():
            print("数据库初始化失败")
            return
        tasks, total = client.list_research_tasks()
        print(f"研究任务 (共 {total} 条):")
        for task in tasks:
            print(f"  - {task.research_title} (ID: {task.id}, 状态: {task.status})")

    elif args.list_reports:
        if not client.initialize():
            print("数据库初始化失败")
            return
        reports, total = client.list_research_reports()
        print(f"研究报告 (共 {total} 条):")
        for report in reports:
            print(f"  - {report.title} (ID: {report.id}, 状态: {report.status})")


if __name__ == "__main__":
    main()
