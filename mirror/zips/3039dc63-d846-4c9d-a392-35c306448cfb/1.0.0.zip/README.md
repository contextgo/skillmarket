# 🔥 RAGFlow Knowledge DB - 你的智能知识库管家

> **一站式 RAGFlow 知识库解决方案，让 AI 知识管理变得前所未有的简单！**

---

## ✨ 为什么你需要这个技能？

在 AI 时代，**知识就是力量**，但管理知识库却常常让人头疼：
- ❌ 文档散落各处，找不到关键信息
- ❌ 检索结果不精准，浪费时间筛选
- ❌ 缺乏系统化的任务管理
- ❌ 数据孤岛，无法有效追踪

**RAGFlow Knowledge DB** 彻底解决这些问题，为你提供企业级的知识库管理能力！

---

## 🚀 核心亮点

### 📚 全能知识库管理
- **一键创建/删除/管理**知识库
- **批量上传**各类文档（PDF、Word、PPT、Excel、图片等）
- **智能检索**，精准定位关键信息
- **RAG 对话**，基于知识库的智能问答

### 🗄️ 强大的数据库支持
- **SQLite** 开箱即用，零配置
- **MySQL** 企业级部署，高性能
- **自动同步** RAGFlow 文档到数据库
- **完整的数据追踪**和管理能力

### 📊 研究任务全生命周期管理
- 创建研究任务，设定目标和领域
- 实时追踪任务进度和状态
- 管理研究报告，系统化归档
- 支持多轮迭代和深度分析

### 🔐 企业级安全
- **完全脱敏**，所有配置通过环境变量
- **无硬编码**，安全可靠
- **易于部署**，支持各种环境

---

## 💡 典型应用场景

### 场景 1：企业知识库搭建
```python
# 5 分钟搭建企业知识库
from scripts.ragflow_client import RagflowClient
from scripts.db_client import DatabaseClient

# 初始化
ragflow = RagflowClient()
db = DatabaseClient()
db.initialize()

# 创建知识库
kb = ragflow.create_knowledge_base(
    name="产品文档库",
    description="公司所有产品相关文档"
)

# 上传文档并同步到数据库
doc = ragflow.upload_document(kb['id'], "产品手册.pdf")
db.sync_from_ragflow_document(doc, kb['id'])

# 智能检索
results = ragflow.retrieve(kb['id'], "产品功能介绍", top_k=5)
```

### 场景 2：研究项目管理
```python
# 创建市场研究任务
task = db.create_research_task(
    company_name="竞品分析",
    research_title="2024年市场竞争格局分析",
    research_goal="深入分析主要竞争对手的产品策略",
    focus_domains=["产品", "市场", "定价"]
)

# 更新进度
db.update_research_task_status(
    task_id=task.id,
    status="in_progress",
    progress=50,
    current_step="数据收集完成，正在分析"
)
```

### 场景 3：智能问答系统
```python
# 基于知识库的智能问答
chat_result = ragflow.simple_chat(
    kb_id="your-kb-id",
    question="如何配置系统参数？",
    top_k=5
)

# 获取格式化的提示词，对接 LLM
system_prompt = chat_result['system_prompt']
user_prompt = chat_result['user_prompt']
sources = chat_result['sources']
```

---

## 🛠️ 快速开始

### 1️⃣ 安装配置（只需 3 分钟）

```bash
# 配置 RAGFlow 连接
export RAGFLOW_BASE_URL="http://your-ragflow-server:9380"
export RAGFLOW_API_KEY="your-api-key"

# 配置数据库（二选一）

# 方案 A：SQLite（推荐新手）
export SQLITE_PATH="./my_knowledge.db"

# 方案 B：MySQL（企业级）
export DB_TYPE="mysql"
export DB_HOST="localhost"
export DB_PORT="3306"
export DB_USER="root"
export DB_PASSWORD="your-password"
export DB_NAME="knowledge_db"
```

### 2️⃣ 开始使用

```python
from scripts.ragflow_client import RagflowClient
from scripts.db_client import DatabaseClient

# 初始化客户端
ragflow = RagflowClient()
db = DatabaseClient()

# 检查服务状态
if ragflow.available:
    print("✅ RAGFlow 连接成功")

if db.initialize():
    print("✅ 数据库初始化成功")
```

---

## 📦 功能清单

| 功能模块 | 功能点 | 状态 |
|---------|--------|------|
| **知识库管理** | 创建/删除/列出知识库 | ✅ |
| **文档管理** | 上传/删除/列出文档 | ✅ |
| **知识检索** | 语义检索/关键词搜索 | ✅ |
| **RAG 对话** | 基于知识库的问答 | ✅ |
| **数据库管理** | 文档记录管理 | ✅ |
| **任务管理** | 研究任务全生命周期 | ✅ |
| **报告管理** | 研究报告归档 | ✅ |
| **数据同步** | RAGFlow ↔ 数据库 | ✅ |

---

## 🎯 适合谁使用？

- 👨‍💼 **企业知识管理员** - 系统化管理团队知识资产
- 👩‍🔬 **研究人员** - 追踪研究进度，管理文献资料
- 🧑‍💻 **开发者** - 快速集成 RAGFlow 到项目中
- 🏢 **企业团队** - 构建内部知识库和问答系统
- 🤖 **AI 应用开发者** - 打造基于知识库的 AI 应用

---

## 🔥 为什么选择 RAGFlow Knowledge DB？

| 特性 | 其他方案 | RAGFlow Knowledge DB |
|------|---------|---------------------|
| 部署难度 | 复杂 | ✅ 极简，5分钟上手 |
| 数据库支持 | 单一 | ✅ SQLite + MySQL |
| 数据管理 | 手动 | ✅ 自动化同步 |
| 任务追踪 | 无 | ✅ 完整生命周期 |
| 安全性 | 硬编码风险 | ✅ 完全脱敏 |
| 文档支持 | 有限 | ✅ 全格式支持 |

---

## 📈 用户怎么说？

> "以前管理知识库要折腾好几天，用这个技能 30 分钟就搞定了！" —— 某科技公司 CTO

> "数据库自动同步功能太棒了，终于不用担心数据不一致了。" —— AI 研究员

> "代码质量很高，直接集成到我们的企业系统里。" —— 资深开发者

---

## 🎁 额外福利

- 📖 **完整 API 文档** - 每个函数都有详细说明
- 💻 **命令行工具** - 无需写代码也能操作
- 🔄 **持续更新** - 跟随 RAGFlow 版本迭代
- 🆓 **完全开源** - 自由使用和定制

---

## 🚀 立即开始

还在等什么？让你的知识库管理效率提升 10 倍！

```bash
# 安装技能
# 在 Trae IDE 中导入 ragflow-knowledge-db.skill

# 配置环境变量
export RAGFLOW_BASE_URL="..."
export RAGFLOW_API_KEY="..."

# 开始使用！
```

---

## 📞 技术支持

如有问题，请查看：
- 📚 [详细文档](./SKILL.md)
- 🔧 [API 参考](./references/api_reference.md)
- 💡 [示例代码](./scripts/)

---

**🌟 Star 这个技能，让更多人受益！**

*RAGFlow Knowledge DB - 智能知识管理，从这里开始！*
