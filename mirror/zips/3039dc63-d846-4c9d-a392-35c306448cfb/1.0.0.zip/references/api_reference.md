# RAGFlow API 参考文档

## 目录
- [认证](#认证)
- [知识库 API](#知识库-api)
- [文档 API](#文档-api)
- [检索 API](#检索-api)
- [数据库 API](#数据库-api)
- [错误处理](#错误处理)

---

## 认证

所有 API 请求都需要在请求头中包含 Bearer Token 认证：

```http
Authorization: Bearer <your-api-key>
Content-Type: application/json
```

**Python 示例：**
```python
import requests

headers = {
    "Authorization": "Bearer your-api-key",
    "Content-Type": "application/json"
}

response = requests.get(
    "http://your-ragflow-server:9380/api/v1/datasets",
    headers=headers
)
```

---

## 知识库 API

### 获取知识库列表

**端点：** `GET /api/v1/datasets`

**响应示例：**
```json
{
  "code": 0,
  "message": "success",
  "data": [
    {
      "id": "kb-001",
      "name": "技术文档库",
      "description": "公司技术文档知识库",
      "create_date": "2024-01-01T00:00:00Z",
      "document_count": 50
    }
  ]
}
```

### 创建知识库

**端点：** `POST /api/v1/datasets`

**请求体：**
```json
{
  "name": "新知识库",
  "description": "知识库描述（可选）"
}
```

**响应示例：**
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "id": "kb-002",
    "name": "新知识库",
    "description": "知识库描述",
    "create_date": "2024-01-01T00:00:00Z"
  }
}
```

### 删除知识库

**端点：** `DELETE /api/v1/datasets/{kb_id}`

**路径参数：**
- `kb_id`: 知识库 ID

**响应示例：**
```json
{
  "code": 0,
  "message": "success"
}
```

---

## 文档 API

### 获取文档列表

**端点：** `GET /api/v1/datasets/{kb_id}/documents`

**路径参数：**
- `kb_id`: 知识库 ID

**响应示例：**
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "docs": [
      {
        "id": "doc-001",
        "name": "API文档.pdf",
        "dataset_id": "kb-001",
        "status": "SUCCESS",
        "run": "SUCCESS",
        "create_date": "2024-01-01T00:00:00Z",
        "chunk_count": 100,
        "token_count": 5000
      }
    ],
    "total": 1
  }
}
```

### 上传文档

**端点：** `POST /api/v1/datasets/{kb_id}/documents`

**路径参数：**
- `kb_id`: 知识库 ID

**请求类型：** `multipart/form-data`

**请求参数：**
- `file`: 文档文件

**Python 示例：**
```python
import requests

headers = {
    "Authorization": "Bearer your-api-key"
}

files = {
    "file": open("document.pdf", "rb")
}

response = requests.post(
    "http://your-ragflow-server:9380/api/v1/datasets/kb-001/documents",
    headers=headers,
    files=files
)
```

**响应示例：**
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "id": "doc-002",
    "name": "document.pdf",
    "status": "PARSING"
  }
}
```

### 删除文档

**端点：** `DELETE /api/v1/datasets/{kb_id}/documents/{doc_id}`

**路径参数：**
- `kb_id`: 知识库 ID
- `doc_id`: 文档 ID

**响应示例：**
```json
{
  "code": 0,
  "message": "success"
}
```

---

## 检索 API

### 知识检索

**端点：** `POST /api/v1/retrieval`

**请求体：**
```json
{
  "dataset_ids": ["kb-001"],
  "question": "什么是 API？",
  "top_k": 5
}
```

**响应示例：**
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "chunks": [
      {
        "id": "chunk-001",
        "content": "API（Application Programming Interface）是应用程序接口...",
        "score": 0.95,
        "document_keyword": "API文档.pdf",
        "document_name": "API文档.pdf"
      }
    ]
  }
}
```

---

## 数据库 API

### DatabaseClient 类

#### 初始化

```python
from scripts.db_client import DatabaseClient

# 使用环境变量配置
db = DatabaseClient()

# 手动配置
db = DatabaseClient(
    database_url="mysql+pymysql://user:pass@localhost:3306/db?charset=utf8mb4"
)

# 或使用参数配置
db = DatabaseClient(
    db_type="mysql",
    host="localhost",
    port=3306,
    user="root",
    password="password",
    db_name="ragflow_db"
)
```

#### 环境变量配置

| 变量名 | 说明 | 默认值 |
|--------|------|--------|
| `DATABASE_URL` | 完整的数据库连接URL | - |
| `DB_TYPE` | 数据库类型 (mysql/sqlite) | sqlite |
| `DB_HOST` | 数据库主机地址 | localhost |
| `DB_PORT` | 数据库端口 | 3306 |
| `DB_USER` | 数据库用户名 | root |
| `DB_PASSWORD` | 数据库密码 | - |
| `DB_NAME` | 数据库名称 | ragflow_db |
| `DB_CHARSET` | 字符集 | utf8mb4 |
| `SQLITE_PATH` | SQLite 数据库文件路径 | ./ragflow_data.db |

#### 初始化数据库

```python
# 初始化数据库连接和表结构
success = db.initialize()
```

#### 知识库文档操作

##### create_knowledge_document

创建知识库文档记录。

**参数：**
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| title | str | 是 | 文档标题 |
| source_type | str | 否 | 来源类型，默认 "DOCUMENT" |
| source_url | str | 否 | 来源URL |
| content_summary | str | 否 | 内容摘要 |
| metadata_info | dict | 否 | 元数据信息 |
| ragflow_dataset_id | str | 否 | RAGFlow 知识库ID |
| ragflow_document_id | str | 否 | RAGFlow 文档ID |

**返回：** KnowledgeDocument 对象

##### list_knowledge_documents

列出知识库文档。

**参数：**
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| source_type | str | 否 | 按来源类型筛选 |
| search | str | 否 | 搜索关键词 |
| skip | int | 否 | 跳过记录数，默认 0 |
| limit | int | 否 | 返回记录数，默认 100 |

**返回：** (文档列表, 总数)

##### update_knowledge_document

更新知识库文档。

**参数：**
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| doc_id | int | 是 | 文档ID |
| **kwargs | - | 否 | 要更新的字段 |

**返回：** 更新后的 KnowledgeDocument 对象

##### delete_knowledge_document

删除知识库文档。

**参数：**
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| doc_id | int | 是 | 文档ID |

**返回：** bool - 是否删除成功

#### 研究任务操作

##### create_research_task

创建研究任务。

**参数：**
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| company_name | str | 是 | 公司名称 |
| research_title | str | 是 | 研究标题 |
| research_goal | str | 是 | 研究目标 |
| focus_domains | list | 否 | 关注领域列表 |
| output_depth | str | 否 | 输出深度，默认 "standard" |
| total_iterations | int | 否 | 总迭代次数，默认 3 |

**返回：** ResearchTask 对象

##### list_research_tasks

列出研究任务。

**参数：**
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| company_name | str | 否 | 按公司名称筛选 |
| status | str | 否 | 按状态筛选 |
| skip | int | 否 | 跳过记录数，默认 0 |
| limit | int | 否 | 返回记录数，默认 100 |

**返回：** (任务列表, 总数)

##### update_research_task_status

更新研究任务状态。

**参数：**
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| task_id | int | 是 | 任务ID |
| status | str | 是 | 新状态 |
| progress | int | 否 | 进度百分比 |
| current_step | str | 否 | 当前步骤 |
| error_message | str | 否 | 错误信息 |

**返回：** 更新后的 ResearchTask 对象

#### 研究报告操作

##### create_research_report

创建研究报告。

**参数：**
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| title | str | 是 | 报告标题 |
| company_name | str | 是 | 公司名称 |
| research_goal | str | 否 | 研究目标 |
| file_path | str | 否 | 文件路径 |
| status | str | 否 | 状态，默认 "draft" |

**返回：** ResearchReport 对象

##### list_research_reports

列出研究报告。

**参数：**
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| company_name | str | 否 | 按公司名称筛选 |
| status | str | 否 | 按状态筛选 |
| skip | int | 否 | 跳过记录数，默认 0 |
| limit | int | 否 | 返回记录数，默认 100 |

**返回：** (报告列表, 总数)

### 数据模型

#### KnowledgeDocument

| 字段 | 类型 | 说明 |
|------|------|------|
| id | int | 主键 |
| title | str | 文档标题 |
| source_type | str | 来源类型 |
| source_url | str | 来源URL |
| content_summary | str | 内容摘要 |
| metadata_info | dict | 元数据信息 |
| is_parsed | bool | 是否已解析 |
| ragflow_dataset_id | str | RAGFlow 知识库ID |
| ragflow_document_id | str | RAGFlow 文档ID |
| created_at | datetime | 创建时间 |
| updated_at | datetime | 更新时间 |

#### ResearchTask

| 字段 | 类型 | 说明 |
|------|------|------|
| id | int | 主键 |
| company_name | str | 公司名称 |
| research_title | str | 研究标题 |
| research_goal | str | 研究目标 |
| focus_domains | list | 关注领域 |
| output_depth | str | 输出深度 |
| status | str | 状态 |
| current_step | str | 当前步骤 |
| progress | int | 进度百分比 |
| iteration | int | 当前迭代 |
| total_iterations | int | 总迭代次数 |
| created_at | datetime | 创建时间 |
| updated_at | datetime | 更新时间 |

#### ResearchReport

| 字段 | 类型 | 说明 |
|------|------|------|
| id | int | 主键 |
| title | str | 报告标题 |
| company_name | str | 公司名称 |
| research_goal | str | 研究目标 |
| file_path | str | 文件路径 |
| status | str | 状态 |
| created_at | datetime | 创建时间 |
| updated_at | datetime | 更新时间 |

## 错误处理

### 响应码说明

| Code | 说明 |
|------|------|
| 0 | 成功 |
| 100 | 参数错误 |
| 101 | 认证失败 |
| 102 | 资源不存在 |
| 500 | 服务器内部错误 |

### 错误响应示例

```json
{
  "code": 101,
  "message": "Invalid API key",
  "data": null
}
```

### 常见错误

1. **401 Unauthorized**
   - 原因：API 密钥无效或未提供
   - 解决：检查 Authorization 头是否正确设置

2. **404 Not Found**
   - 原因：知识库或文档不存在
   - 解决：确认 ID 是否正确

3. **413 Payload Too Large**
   - 原因：文件大小超出限制
   - 解决：压缩文件或拆分大文件

4. **500 Internal Server Error**
   - 原因：服务器端错误
   - 解决：稍后重试或联系管理员
