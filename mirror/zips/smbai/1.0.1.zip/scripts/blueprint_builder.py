"""
废品机械师蓝图生成器 v2.2
支持多体+joints，完整部件数据库含物理尺寸

已验证规则：
- 轴承-板-轮子三者刚性连接，相对位置不可变
- 平台连接器: xaxis=1, zaxis=-2（工业件标准朝向）
- 基础方块(金属/木/混凝土): xaxis=1, zaxis=3, 需bounds字段
- 不同块类型不能混用 xaxis/zaxis
"""
import json, uuid, os, math
from pathlib import Path

# ============================================================
# 部件物理尺寸数据库（从游戏 files 提取：box/cyl/hull/sphere）
# 碰撞体积 = 尺寸 + margin（如有）
# ============================================================

SIZES = {
    # blocks
    "混凝土块":    {"type":"box","x":1,"y":1,"z":1},
    "木块":        {"type":"box","x":1,"y":1,"z":1},
    "金属块":      {"type":"box","x":1,"y":1,"z":1},
    "警戒块":      {"type":"box","x":1,"y":1,"z":1},
    "瓷砖":        {"type":"box","x":1,"y":1,"z":1},
    "玻璃":        {"type":"box","x":1,"y":1,"z":1},
    # interactive
    "轴承":        {"type":"cyl","d":1,"h":1,"axis":"z","margin":0},
    "悬挂弹簧":    {"type":"cyl","d":1,"h":2,"axis":"z","margin":0},
    "弹簧":        {"type":"cyl","d":1,"h":3,"axis":"z","margin":0},
    "逻辑门":      {"type":"box","x":1,"y":1,"z":1},
    "开关":        {"type":"hull","x":1,"y":1,"z":1},
    "按钮":        {"type":"hull","x":1,"y":1,"z":1},
    "传感器":      {"type":"box","x":1,"y":1,"z":1},
    "控制器":      {"type":"box","x":2,"y":1,"z":1},
    "推进器":      {"type":"box","x":2,"y":2,"z":4},
    "推进器(大)":  {"type":"box","x":2,"y":2,"z":4},
    "活塞":        {"type":"box","x":1,"y":1,"z":1},
    "驾驶座":      {"type":"hull","x":4,"y":4,"z":6},
    # vehicle
    "小轮":        {"type":"cyl","d":3,"h":1,"axis":"z","margin":0.5},
    "大轮":        {"type":"cyl","d":5,"h":2,"axis":"z","margin":0.5},
    # lights
    "前灯":        {"type":"box","x":1,"y":1,"z":1},
    "梁框灯":      {"type":"hull","x":2,"y":1,"z":1},
    # industrial
    "工业梁":      {"type":"box","x":1,"y":1,"z":1},
    "工业梁(长)":  {"type":"box","x":1,"y":1,"z":4},
    # plants
    "种植箱":      {"type":"box","x":6,"y":1,"z":4},
    "叶植物":      {"type":"cyl","d":2,"h":4,"axis":"y","margin":0},
    # containers
    "木箱":        {"type":"box","x":3,"y":2,"z":2},
    # decor
    "床":          {"type":"box","x":5,"y":2,"z":7},
    "锥桶":        {"type":"hull","x":2,"y":3,"z":2},
    # spaceship
    "飞船门":      {"type":"hull","x":5,"y":7,"z":1},
    "飞船顶灯":    {"type":"box","x":3,"y":1,"z":8},
}

def get_collision_size(part_name):
    """返回部件的碰撞体积 (dx, dy, dz)，考虑 margin"""
    s = SIZES.get(part_name, {"type":"box","x":1,"y":1,"z":1})
    if s["type"] == "box":
        return (s["x"], s["y"], s["z"])
    elif s["type"] == "cyl":
        m = s.get("margin", 0)
        ed = s["d"] + m * 2  # effective diameter
        if s["axis"] == "z":
            return (ed, ed, s["h"])
        elif s["axis"] == "y":
            return (ed, s["h"], ed)
        else:
            return (s["h"], ed, ed)
    elif s["type"] == "hull":
        return (s["x"], s["y"], s["z"])
    return (1, 1, 1)

def get_spacing(part_name, axis="x"):
    """返回该部件在指定轴上需要的最小间距"""
    dx, dy, dz = get_collision_size(part_name)
    return {"x": dx, "y": dy, "z": dz}[axis]

# ============================================================
# 部件 UUID 数据库（从游戏文件提取）
# ============================================================

SHAPES = {
    # === 建筑材料 ===
    "混凝土块":    "a6c6ce30-dd47-4587-b475-085d55c6a3b4",
    "木块":        "df953d9c-234f-4ac2-af5e-f0490b223e71",
    "金属块":      "8aedf6c2-94e1-4506-89d4-a0227c552f1e",
    "警戒块":      "09ca2713-28ee-4119-9622-e85490034758",
    "瓷砖":        "8ca49bff-eeef-4b43-abd0-b527a567f1b7",
    "玻璃":        "4a0cb9c5-df0a-4c69-80f0-eea1023f3cc7",

    # === 交互部件 ===
    "逻辑门":      "9f0f56e8-2c31-4d83-996c-d00a9b296c3f",
    "开关":        "7cf717d7-d167-4f2d-a6e7-6b2c70aa3986",
    "按钮":        "1e8d93a4-506b-470d-9ada-9c0a321e2db5",
    "传感器":      "add3acc6-a6fd-44e8-a384-a7a16ce13c81",
    "控制器":      "12862001-666c-4bdd-8326-a1f43610d28b",
    "轴承":        "4a1b886b-913e-4aad-b5b6-6e41b0db23a6",
    "悬挂弹簧":    "aa8d89eb-919b-42f4-8b58-af6f0d5856bc",
    "弹簧":        "68f7ff0c-7bfd-4f6a-9aac-4ca55990ec7f",
    "推进器":      "e8ac41a2-3454-4496-a94f-a2de0e9e15a4",
    "推进器(大)":  "4e163cce-db18-43a2-9da7-4e2b68bd56ab",
    "活塞":        "21bf34e4-7b6c-48fe-8175-10995c73e4e6",
    "真空泵":      "6c8faf5d-ea52-4f70-9d29-f2311822b2fa",
    "气泵":        "339dc807-099c-449f-bc4b-ecad92e9908d",
    "喇叭":        "6e37f09d-b084-4e8b-8508-0885cd1fa439",
    "驾驶座":      "8cd1a4bf-e4ab-491d-9cff-0f7cce5bd336",

    # === 管道 ===
    "水管(直)":    "9dd5ee9c-aa5c-4bec-8fc2-a67999697085",
    "水管(弯)":    "7f658dcd-e31d-4890-b4a7-4cd5e1378eaf",
    "风管(短)":    "9d7e182f-c5d6-45e9-af21-1c24977b30c9",
    "风管(长)":    "01d2298b-6cdb-4f4f-bd73-37c76cd60ca3",

    # === 工业部件 ===
    "工业梁":      "87878e83-8170-4796-9401-6baba45ccef2",
    "工业梁(长)":  "4c7b8096-b8ca-4341-bfe9-d31d2d5443b8",

    # === 灯光 ===
    "前灯":        "ed27f5e2-cac5-4a32-a5d9-49f116acc6af",
    "梁框灯":      "695d66c8-b937-472d-8bc2-f3d72dd92879",

    # === 车轮 ===
    "小轮":        "69e362c3-32aa-4cd1-adc0-dcfc47b92c0d",
    "大轮":        "db66f0b1-0c50-4b74-bdc7-771374204b1f",

    # === 植物 ===
    "种植箱":      "13ffabca-91ec-48ce-9dd6-4f6660714701",
    "叶植物":      "df3734e2-f04b-443f-b568-fe5b076646c7",
    "多肉":        "89f6c762-c0ed-44ad-b3f1-a60dbdd889c5",
    "仙人掌(球)":  "d1421af8-6f80-4413-8099-2c6b217fb929",
    "仙人掌(刺)":  "bc575e0c-d1aa-438e-9f3d-0a80f4ea915f",
    "蓝花":        "bb443a05-b5b9-4fad-90fc-5e04aa90fd8f",

    # === 装饰 ===
    "杯子":        "a6ec1dcc-07e9-418a-819e-904e28a32f63",
    "靴子":        "c89f7bc8-5720-474d-989d-761916a411b2",
    "小黄鸭":      "80bc2b9f-98a9-44e4-9cb8-d4ec7e95b40f",
    "床":          "9eead4cf-4743-486e-99be-a553c4c10740",
    "枕头":        "ff2207c1-e40b-416f-8bdd-66a9efd6d1a9",
    "锥桶":        "1f334b62-8955-4406-8848-91e03228c330",

    # === 飞船 ===
    "飞船门":      "aec1ff30-9347-4166-9cb7-f414e1563d9d",
    "飞船顶灯":    "47062936-5d28-43ec-81b5-8fdb619e97e4",
}

PART_COLORS = {
    "混凝土块": "8D8F89", "木块": "9B683A", "金属块": "675F51",
    "警戒块": "CE9E0C", "瓷砖": "B3B5AD", "玻璃": "C8E8EB",
    "逻辑门": "DF7F01", "开关": "DF7F01", "按钮": "DF7F01",
    "传感器": "DF7F01", "控制器": "DF7F01", "轴承": "DF7F01",
    "弹簧": "DF7F01", "悬挂弹簧": "DF7F01", "推进器": "DF7F01",
    "推进器(大)": "DF7F01", "活塞": "DF7F01",
    "前灯": "DF7F01", "小轮": "DF7F01", "大轮": "DF7F01",
    "工业梁": "F3871C", "工业梁(长)": "F3871C",
    "种植箱": "DADAC9", "叶植物": "BE6740",
}

LOGIC_GATE_MODES = {
    "AND": 0, "OR": 1, "NAND": 2,
    "NOR": 4, "XOR": 5, "XNOR": 6,
    "TIMER": 3,
}

BLUEPRINT_DIR = None  # 延迟初始化

def _find_blueprint_dir():
    """自动查找废品机械师蓝图目录"""
    appdata = Path(os.environ.get("APPDATA", ""))
    sm_user = appdata / "Axolot Games" / "Scrap Mechanic" / "User"
    if sm_user.exists():
        for d in sm_user.iterdir():
            if d.is_dir() and d.name.startswith("User_"):
                bp = d / "Blueprints"
                if bp.exists():
                    return bp
    # 回退：常用 Steam ID
    fallback = appdata / "Axolot Games/Scrap Mechanic/User/User_76561198898761025/Blueprints"
    return fallback

def _get_bp_dir():
    global BLUEPRINT_DIR
    if BLUEPRINT_DIR is None:
        BLUEPRINT_DIR = _find_blueprint_dir()
    return BLUEPRINT_DIR


# ============================================================
# 蓝图构建器（v3 + v4）
# ============================================================

class Blueprint:
    """
    废品机械师蓝图构建器

    用法:
      # v4 单体蓝图（建筑、电路）
      bp = Blueprint("建筑名", version=4)
      bp.block("木块", 0, 0, 0)
      bp.save()

      # v3 多体蓝图（机械、载具）
      bp = Blueprint("载具名", version=3)
      chassis = bp.add_body()
      wheel_assembly = bp.add_body()
      bp.block("金属块", 0, 0, 0, body=chassis)
      bp.joint(0, 1, pos_a=(...), pos_b=(...), xaxis_a=..., ...)
      bp.save()
    """

    def __init__(self, name="未命名蓝图", version=4):
        self.name = name
        self.blueprint_id = str(uuid.uuid4())
        self.version = version
        self._next_id = 1
        self._active_body = 0

        # 所有模式共用 flat childs + body 索引
        self._body_childs = [[]]   # list of lists: body → childs
        self._body_joints = []     # list of child-level joints per body
        self._top_joints = []      # top-level joints (v3 only)

    def _next(self) -> int:
        n = self._next_id
        self._next_id += 1
        return n

    def _resolve(self, name_or_uuid: str) -> str:
        return SHAPES.get(name_or_uuid, name_or_uuid)

    def _color(self, name_or_uuid: str, override: str = None) -> str:
        if override:
            return override
        return PART_COLORS.get(name_or_uuid, "DF7F01")

    # ================================================================
    # 体管理（v3 多体/子装配）
    # ================================================================

    def add_body(self) -> int:
        """创建新 body（子装配），返回 body 索引"""
        idx = len(self._body_childs)
        self._body_childs.append([])
        return idx

    def set_body(self, idx: int):
        """切换到指定 body"""
        if idx < len(self._body_childs):
            self._active_body = idx

    def body(self, idx: int = None) -> int:
        """获取/设置当前操作的 body"""
        if idx is not None:
            self._active_body = idx
        return self._active_body

    # ================================================================
    # 静态方块
    # ================================================================

    def block(self, shape: str, x: int, y: int, z: int,
              xaxis: int = 1, zaxis: int = 3, color: str = None,
              bounds: tuple = None, body: int = None) -> dict:
        """添加静态方块"""
        c = self._resolve(shape)
        child = {
            "color": self._color(shape, color),
            "pos": {"x": x, "y": y, "z": z},
            "shapeId": c,
            "xaxis": xaxis,
            "zaxis": zaxis,
        }
        if bounds:
            child["bounds"] = {"x": bounds[0], "y": bounds[1], "z": bounds[2]}
        bid = body if body is not None else self._active_body
        self._body_childs[bid].append(child)
        return child

    # ================================================================
    # 交互部件
    # ================================================================

    def part(self, shape: str, x: int, y: int, z: int,
             xaxis: int = 1, zaxis: int = 3, color: str = None,
             mode: int = None, controllers: list = None,
             active: bool = False, bounds: tuple = None,
             child_joints: list = None,  # v3: [{"id": target_id}]
             body: int = None) -> dict:
        """添加交互部件（带 controller）"""
        c = self._resolve(shape)
        cid = self._next()
        ctr = {
            "id": cid,
            "controllers": [],
            "joints": None,
        }
        # v4 style
        if self.version >= 4:
            ctr["mode"] = mode if mode is not None else 0
            ctr["active"] = active
        if controllers:
            ctr["controllers"] = [{"id": i} for i in controllers]

        child = {
            "color": self._color(shape, color),
            "controller": ctr,
            "pos": {"x": x, "y": y, "z": z},
            "shapeId": c,
            "xaxis": xaxis,
            "zaxis": zaxis,
        }
        if bounds:
            child["bounds"] = {"x": bounds[0], "y": bounds[1], "z": bounds[2]}
        if child_joints:
            child["joints"] = child_joints
        bid = body if body is not None else self._active_body
        self._body_childs[bid].append(child)
        return child

    # ================================================================
    # 电路快捷方法
    # ================================================================

    def gate(self, gate_type: str, x: int, y: int, z: int,
             inputs: list = None, xaxis: int = 1, zaxis: int = 3,
             body: int = None) -> dict:
        """逻辑门：AND/OR/NAND/NOR/XOR/XNOR/TIMER"""
        mode = LOGIC_GATE_MODES.get(gate_type.upper(), 0)
        return self.part("逻辑门", x, y, z, xaxis=xaxis, zaxis=zaxis,
                         mode=mode, controllers=inputs or [], body=body)

    def nor(self, x: int, y: int, z: int, inputs: list, **kw):
        return self.gate("NOR", x, y, z, inputs, **kw)

    def switch(self, x: int, y: int, z: int, xaxis: int = 1, zaxis: int = 3,
               body: int = None) -> dict:
        return self.part("开关", x, y, z, xaxis=xaxis, zaxis=zaxis, body=body)

    def button(self, x: int, y: int, z: int, xaxis: int = 1, zaxis: int = 3,
               body: int = None) -> dict:
        return self.part("按钮", x, y, z, xaxis=xaxis, zaxis=zaxis, body=body)

    def sensor(self, x: int, y: int, z: int, inputs: list = None,
               xaxis: int = 1, zaxis: int = 3, body: int = None) -> dict:
        return self.part("传感器", x, y, z, xaxis=xaxis, zaxis=zaxis,
                         controllers=inputs or [], body=body)

    # ================================================================
    # Joints（v3 核心：连接 bodies 和 childs）
    # ================================================================

    def joint(self, body_a: int, body_b: int,
              child_a: int, child_b: int,
              pos_a: tuple = None, pos_b: tuple = None,
              xaxis_a: int = 1, zaxis_a: int = 3,
              xaxis_b: int = 1, zaxis_b: int = 3,
              shape: str = "轴承") -> dict:
        """
        顶层 joint：在两个 body 的 child 间创建轴承/焊接/弹簧连接
        
        body_a/b: body 索引
        child_a/b: 该 body 内的 child 索引
        pos_a/b: 可省略，自动从 child 位置推断
        """
        # 计算全局 child 索引
        global_a = self._global_child_index(body_a, child_a)
        global_b = self._global_child_index(body_b, child_b)
        
        ca = self._body_childs[body_a][child_a]
        cb = self._body_childs[body_b][child_b]
        
        if pos_a is None:
            pos_a = (ca["pos"]["x"], ca["pos"]["y"], ca["pos"]["z"])
        if pos_b is None:
            pos_b = (cb["pos"]["x"], cb["pos"]["y"], cb["pos"]["z"])
        
        jid = len(self._top_joints) + 1
        j = {
            "childA": global_a, "childB": global_b,
            "color": "DF7F01",
            "id": jid,
            "posA": {"x": pos_a[0], "y": pos_a[1], "z": pos_a[2]},
            "posB": {"x": pos_b[0], "y": pos_b[1], "z": pos_b[2]},
            "shapeId": self._resolve(shape),
            "xaxisA": xaxis_a, "zaxisA": zaxis_a,
            "xaxisB": xaxis_b, "zaxisB": zaxis_b,
        }
        self._top_joints.append(j)
        
        # 在两个 child 上绑定 joint 引用
        if "joints" not in ca:
            ca["joints"] = []
        ca["joints"].append({"id": jid})
        if "joints" not in cb:
            cb["joints"] = []
        cb["joints"].append({"id": jid})
        
        return j

    def bearing(self, body_a: int, child_a: int,
                body_b: int, child_b: int,
                pos_a: tuple = None, pos_b: tuple = None,
                xaxis_a: int = 1, zaxis_a: int = 3,
                xaxis_b: int = 1, zaxis_b: int = 3) -> dict:
        """快捷方法：在两个 child 间创建轴承连接"""
        return self.joint(body_a, body_b, child_a, child_b,
                         pos_a, pos_b, xaxis_a, zaxis_a, xaxis_b, zaxis_b,
                         shape="轴承")

    # ================================================================
    # 车辆轮子快捷方法（已验证规则）
    # ================================================================

    def add_wheel(self, side: str, board_body: int, board_x: int, board_y: int,
                  board_z: int = 2):
        """
        添加一个轮子及其轴承连接（规则已验证）
        side: "bottom" 或 "top"
        board_body, board_x, board_y, board_z: 板角坐标
        返回 (wheel_body_idx, child_idx)
        
        规则:
        - 轴承放在轮子上，相对偏移=(2,0,2) (从轴承到轮子中心)
        - 轴承 pos 固定在板角位置
        - 下排: wheel_x=board_x-1, bearing_y=-2, zaxis=-2
        - 上排: wheel_x=board_x+2, bearing_y=3, zaxis=2
        """
        if side == "bottom":
            wx, wy, wz = board_x - 1, -1, 4
            bx, by, bz = board_x, -2, 2
            zax = -2
        else:
            wx, wy, wz = board_x + 2, 3, 4
            bx, by, bz = board_x, 3, 2
            zax = 2

        # 创建轮子 body
        wheel_body = self.add_body()
        wheel_child_idx = len(self._body_childs[wheel_body])
        self._body_childs[wheel_body].append({
            "color": "DF7F01",
            "pos": {"x": wx, "y": wy, "z": wz},
            "shapeId": self._resolve("小轮"),
            "xaxis": -3,
            "zaxis": zax,
        })

        # 找板角 child
        board_idx = None
        for i, c in enumerate(self._body_childs[board_body]):
            if c["pos"]["x"] == board_x and c["pos"]["y"] == board_y and c["pos"]["z"] == board_z:
                board_idx = i
                break
        if board_idx is None:
            raise ValueError("board corner not found at (%d,%d,%d)" % (board_x, board_y, board_z))

        # 创建 joint
        global_a = self._global_child_index(board_body, board_idx)
        global_b = self._global_child_index(wheel_body, wheel_child_idx)
        jid = len(self._top_joints) + 1

        j = {
            "childA": global_a, "childB": global_b,
            "color": "DF7F01", "id": jid,
            "posA": {"x": bx, "y": by, "z": bz},
            "posB": {"x": bx, "y": by, "z": bz},
            "shapeId": self._resolve("轴承"),
            "xaxisA": 1, "zaxisA": zax,
            "xaxisB": 1, "zaxisB": zax,
        }
        self._top_joints.append(j)

        # child-level joint refs
        self._body_childs[board_body][board_idx].setdefault("joints", []).append({"id": jid})
        self._body_childs[wheel_body][wheel_child_idx]["joints"] = [{"id": jid}]

        return wheel_body, wheel_child_idx

    def _global_child_index(self, body_idx: int, child_idx: int) -> int:
        """计算 child 在所有 body 中的全局索引"""
        idx = 0
        for bi in range(body_idx):
            idx += len(self._body_childs[bi])
        return idx + child_idx

    def _find_child(self, body_idx: int, child_idx: int) -> dict:
        return self._body_childs[body_idx][child_idx]

    # ================================================================
    # 几何生成器
    # ================================================================

    def cube(self, shape: str, x0: int, y0: int, z0: int,
             w: int, h: int, d: int, color: str = None,
             body: int = None) -> int:
        """实心长方体，返回方块数"""
        count = 0
        for x in range(x0, x0 + w):
            for y in range(y0, y0 + h):
                for z in range(z0, z0 + d):
                    self.block(shape, x, y, z, color=color, body=body)
                    count += 1
        return count

    def hollow_cube(self, shape: str, x0: int, y0: int, z0: int,
                    w: int, h: int, d: int, color: str = None,
                    body: int = None) -> int:
        """中空长方体（只有壳），返回方块数"""
        count = 0
        for x in range(x0, x0 + w):
            for y in range(y0, y0 + h):
                for z in range(z0, z0 + d):
                    if (x == x0 or x == x0 + w - 1 or
                        y == y0 or y == y0 + h - 1 or
                        z == z0 or z == z0 + d - 1):
                        self.block(shape, x, y, z, color=color, body=body)
                        count += 1
        return count

    def sphere(self, shape: str, cx: float, cy: float, cz: float,
               radius: float, color: str = None, body: int = None) -> int:
        """完美球体，返回方块数"""
        r2 = radius * radius
        count = 0
        for x in range(int(cx - radius), int(cx + radius + 1)):
            for y in range(int(cy - radius), int(cy + radius + 1)):
                for z in range(int(cz - radius), int(cz + radius + 1)):
                    if (x - cx) ** 2 + (y - cy) ** 2 + (z - cz) ** 2 <= r2:
                        self.block(shape, x, y, z, color=color, body=body)
                        count += 1
        return count

    def cylinder(self, shape: str, cx: float, cz: float, y0: int, h: int,
                 radius: float, axis: str = "y", color: str = None,
                 body: int = None) -> int:
        """圆柱体（沿 Y 轴），返回方块数"""
        r2 = radius * radius
        count = 0
        for x in range(int(cx - radius), int(cx + radius + 1)):
            for y in range(y0, y0 + h):
                for z in range(int(cz - radius), int(cz + radius + 1)):
                    if (x - cx) ** 2 + (z - cz) ** 2 <= r2:
                        self.block(shape, x, y, z, color=color, body=body)
                        count += 1
        return count

    # ================================================================
    # 输出与保存
    # ================================================================

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2, ensure_ascii=False)

    def to_dict(self) -> dict:
        bodies = []
        for childs in self._body_childs:
            bodies.append({"childs": childs})
        data = {
            "bodies": bodies,
            "version": self.version,
        }
        if self._top_joints:
            data["joints"] = self._top_joints
        return data

    def total_parts(self) -> int:
        return sum(len(childs) for childs in self._body_childs)

    def save(self, output_dir: str = None, bp_id: str = None):
        """
        保存蓝图到游戏目录或指定位置。
        优先：save_to() 覆盖已有蓝图
        新蓝图用 bp_id 参数指定 ID
        """
        if output_dir:
            bp_dir = Path(output_dir)
        elif bp_id:
            bp_dir = _get_bp_dir() / bp_id
        else:
            bp_dir = _get_bp_dir() / self.blueprint_id

        bp_dir.mkdir(parents=True, exist_ok=True)

        bp_json = self.to_json()
        (bp_dir / "blueprint.json").write_text(bp_json, encoding="utf-8")

        desc = {
            "description": "",
            "localId": bp_dir.name,
            "name": self.name,
            "type": "Blueprint",
            "version": 4,
        }
        (bp_dir / "description.json").write_text(
            json.dumps(desc, indent=3, ensure_ascii=False), encoding="utf-8")

        total = self.total_parts()
        print("[OK] Blueprint saved: %s" % bp_dir)
        print("     Name: %s" % self.name)
        print("     ID: %s" % bp_dir.name)
        print("     Bodies: %d, Joints: %d, Parts: %d" % (
            len(self._body_childs), len(self._top_joints), total))
        return str(bp_dir)

    def save_to(self, target_dir: str):
        """覆盖已有蓝图目录（推荐用法）"""
        return self.save(output_dir=target_dir)

    def stats(self) -> dict:
        total = self.total_parts()
        return {
            "name": self.name, "id": self.blueprint_id,
            "version": self.version, "bodies": len(self._body_childs),
            "joints": len(self._top_joints), "parts": total,
            "json_size": len(self.to_json().encode("utf-8")),
        }


# ============================================================
# 快捷函数
# ============================================================

def new_blueprint(name="蓝图", version=4) -> Blueprint:
    return Blueprint(name, version=version)


# ============================================================
# 测试
# ============================================================
if __name__ == "__main__":
    # 用 add_wheel 生成标准的 6 轮车
    bp = Blueprint("6轮车-标准", version=4)
    bp.cube("木块", 1, 0, 2, 10, 4, 1, body=0)
    
    # 三组轮子
    for xi, bx in enumerate([1, 5, 9]):
        bp.add_wheel("bottom", 0, bx, 0)
        bp.add_wheel("top", 0, bx, 3)
    
    bp.save()
    print("\n对比用户正确版本...")
    for j in bp._top_joints:
        print("  J%d: childA=%d childB=%d zaxis=%d pos=(%d,%d,%d)" % (
            j["id"], j["childA"], j["childB"], j["zaxisA"],
            j["posA"]["x"], j["posA"]["y"], j["posA"]["z"]))
