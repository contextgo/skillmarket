# Verified Digital Circuits (Scrap Mechanic)

## 1-tick Pulse Generator
```
Button → AND_A ─┬→ AND_B → Light
                │    ↑
                └→ NAND ─┘
```
NAND flips 1 tick slower → AND_B briefly sees both=1 → 1tick pulse.

## T Flip-Flop (toggle on each press)
```
Button→pulse→ AND ─┬→ XOR↺self → Light
                   │    ↑
                   └→ NAND ─┘
```
XOR with self-feedback toggles: XOR(0,1)=1, XOR(1,1)=0.

## OR Self-Latch
```
Button → OR↺self
```
1 tick pulse → permanent ON. Can only reset by breaking wire.

## 3-OR Ring Oscillator
```
OR(A)→OR(B)→OR(C)→OR(A)
```
Odd ORs = stable oscillator, period = N×1tick. Even ORs = all lock ON.

## 5-bit Ripple Counter
```
Button→pulse→XOR0(toggle)─→carryAND1─→XOR1─→carryAND2─→...
              ↑               ↑           ↑
              pulse           pulse+b0    pulse+b0+b1
```
Each higher bit toggles when all lower bits=1 AND pulse arrives.

## 3x5 Digit Display Decoder
```
XOR outputs(5bit) → NAND inverters(5) → Value ANDs(21) → Pixel ORs(26) → Lights(26)
```
- NAND single input = NOT gate (NAND(0)=1, NAND(1)=0)
- Each value AND: 5 inputs (bit=1→XOR, bit=0→inverter)
- Each pixel OR collects from all values where pixel=ON
- Each light has exactly ONE input (its pixel OR)

## Simplified Counter (no per-stage NAND)
```
Button→pulse→sharedAND→ OR1→AND2→ OR2→AND3→ ...
```
1-tick pulse width < chain length → only one stage advances per press.
