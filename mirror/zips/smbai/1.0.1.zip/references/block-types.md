# Block Types Reference

## Platform Connector (industrial.json)
- UUID: `295451dd-f5b2-421d-9113-b3f704d799d4`
- Format: `xaxis=1, zaxis=-2`, bounds NOT required
- Size: box(1,1,1)
- Use for: vehicle bodies, structural frames on lift

## Basic Blocks (blocks.json)
All basic blocks share the same format: `xaxis=1, zaxis=3`, bounds REQUIRED `{x, y, z}`

| Block | UUID | Default Color |
|-------|------|---------------|
| Metal | `8aedf6c2-94e1-4506-89d4-a0227c552f1e` | 675F51 |
| Wood | `df953d9c-234f-4ac2-af5e-f0490b223e71` | 9B683A |
| Concrete | `a6c6ce30-dd47-4587-b475-085d55c6a3b4` | 8D8F89 |
| Glass | `4a0cb9c5-df0a-4c69-80f0-eea1023f3cc7` | C8E8EB |
| Caution | `09ca2713-28ee-4119-9622-e85490034758` | CE9E0C |
| Tiles | `8ca49bff-eeef-4b43-abd0-b527a567f1b7` | B3B5AD |

Bounds can be stretched: `{"x":10,"y":1,"z":1}` = one 10x1x1 metal bar.

## Interactive Components
- `xaxis` and `zaxis` vary per component
- bounds usually NOT required
- Always have `controller` field

Key UUIDs:
| Component | UUID |
|-----------|------|
| Logic Gate | `9f0f56e8-2c31-4d83-996c-d00a9b296c3f` |
| Switch | `7cf717d7-d167-4f2d-a6e7-6b2c70aa3986` |
| Button | `1e8d93a4-506b-470d-9ada-9c0a321e2db5` |
| Timer | `8f7fd0e7-c46e-4944-a414-7ce2437bb30f` |
| Bearing | `4a1b886b-913e-4aad-b5b6-6e41b0db23a6` |
| Headlight | `ed27f5e2-cac5-4a32-a5d9-49f116acc6af` |
| Small Wheel | `69e362c3-32aa-4cd1-adc0-dcfc47b92c0d` |
| Big Wheel | `db66f0b1-0c50-4b74-bdc7-771374204b1f` |
| Controller | `12862001-666c-4bdd-8326-a1f43610d28b` |
| Sensor | `add3acc6-a6fd-44e8-a384-a7a16ce13c81` |
