---
name: scrap-mechanic
description: |
  Generate and modify Scrap Mechanic blueprints (JSON). Build vehicles, buildings, digital logic circuits (gates, flip-flops, counters, oscillators, displays), and pixel art. Use when the user wants to create or edit Scrap Mechanic blueprint files, design circuits, or build structures for the game. Covers blueprint JSON format (v3/v4), parts database (170+ items with UUIDs), block types (platform connectors vs basic blocks like metal/wood), digital logic (AND/OR/XOR/NAND/NOR gates, controllers wiring, tick timing), vehicle building rules (bearing joints, wheel placement), and the blueprint_builder.py generation tool.
---

# Scrap Mechanic Blueprint Skill

## Quick Start

1. **Ask user for game install path** (usually `D:\SteamLibrary\steamapps\common\Scrap Mechanic\` or `C:\Program Files (x86)\Steam\steamapps\common\Scrap Mechanic\`)
2. **Only modify existing blueprints** — never create new UUID. Game can't find new blueprints. User tells you which blueprint name/ID to overwrite.
3. **Blueprint save path**: `%APPDATA%\Axolot Games\Scrap Mechanic\User\User_*\Blueprints\<uuid>\blueprint.json`

## Parts Database

Load `references/parts-database.json` for 170+ parts with UUIDs, sizes. Load `references/block-types.md` for zaxis/bounds rules.

## Blueprint JSON Format (v4)

```json
{
  "bodies": [{"childs": [...]}],
  "joints": [...],  // optional
  "version": 4
}
```

Each child: `{"color":"HEX","controller":{...},"pos":{"x":x,"y":y,"z":z},"shapeId":"uuid","xaxis":1,"zaxis":-2}`

### Block Type Differences (CRITICAL)
| Type | zaxis | bounds | stretch |
|------|-------|--------|---------|
| Platform connector (`295451dd-`) | **-2** | optional | no |
| Metal/Wood/Concrete blocks | **3** | **required** `{x,y,z}` | yes |

Never mix zaxis values between types.

### controllers (logic wiring)
- `controllers: [{"id":X}]` = this component's output goes TO component X
- `controllers: null` = endpoint (light, no forwarding)
- IDs start at 1; 0 is reserved

### Logic Gate Modes
| mode | gate | behavior |
|------|------|----------|
| 0 | AND | all 1→1 |
| 1 | OR | any 1→1 |
| 2 | XOR | exactly one 1→1 |
| 3 | NAND | all 1→0. **Single input = NOT gate** |
| 4 | NOR | any 1→0 |

## Key Rules (Game Verified)

1. **Signal has NO loss** — fan-out is unlimited, no buffers needed
2. **1 tick delay per hop** — only propagation cost
3. **Lights only accept ONE input** — need OR gate to combine multiple sources
4. **Blocks must be adjacent** — floating blocks split into separate pieces
5. **Bearing+board+wheel form rigid triangle** — can't change relative positions
6. **Wheels**: small d=3+margin*2≈4 effective, spacing ≥4

## Vehicle Building (zaxis=-2 orientation)

```
Board at z=2, xaxis=1, zaxis=-2
Bottom wheels: pos(board_x-1, -1, 4), zaxis=-2
Top wheels: pos(board_x+2, 3, 4), zaxis=2
Bearing joint: posA=posB=(board_x, -2, 2) bottom / (board_x, 3, 2) top
```

## Digital Circuits (Game Verified)

### Core Circuits
- **1-tick pulse gen**: AND→NAND→AND feedback
- **T flip-flop**: edge detector(AND+NAND)→XOR↺self
- **OR self-latch**: OR↺self, 1-tick pulse→permanent ON
- **3-OR ring oscillator**: odd ORs = stable oscillator
- **Ripple counter**: shared 1tick pulse→XOR chain with carry ANDs
- **Simplified counter**: pulse width < chain length prevents ripple, saves NANDs

### Display Decoder
```
Counter bits → NAND inverters(single input=~X) → 
  Value-detecting AND gates(one per value) → Pixel-collecting OR gates → Lights
```

Each light has exactly ONE OR gate as input. OR gate collects from all value-ANDs where pixel should be ON.

## Tools

Use `scripts/blueprint_builder.py` for programmatic blueprint generation. Key API:
- `Blueprint(name, version=4)` — create blueprint
- `.block/shape, x, y, z)` — add static block (platform connector)
- `.metal(x, y, z, w, h, d)` — add metal block with bounds
- `.cube/hollow_cube/sphere/cylinder(...)` — geometry
- `.part/shape, x, y, z, mode, controllers)` — interactive component
- `.gate/type, x, y, z, inputs)` — logic gate shortcut
- `.add_wheel(side, body, board_x, board_y)` — vehicle wheel with bearing
- `.save_to(target_dir)` — save to existing blueprint directory
