---
name: 抖音视频拆分_存入飞书
description: >
  抖音视频分镜提取与分析，完整版（包含飞书写入）。
  触发词：提取分镜、分镜分析、视频拆分、逐帧分析、爆款分镜、分镜写入飞书
---

# 抖音视频拆分_存入飞书

提取抖音短视频的分镜结构，生成「画面 + 台词 + 爆款逻辑」分析表，写入飞书分镜表。

---

## ⚠️ 使用前必读：需要提供的凭证

### 1. SiliconFlow API Key（必填）
用于：语音转写 + 语义分段 + 画面描述

**获取方式：**
1. 访问 https://siliconflow.cn
2. 注册/登录账号
3. 进入「API密钥」页面
4. 复制密钥（格式：`sk-xxxxx...`）

### 2. 飞书凭证（写入飞书时需要）

| 凭证 | 获取方式 | 用途 |
|------|----------|------|
| App ID | 飞书开放平台 → 应用开发 → 创建应用 | 身份标识 |
| App Secret | 同上，应用详情页 | 身份密钥 |
| App Token | 多维表 URL 中提取 | 多维表唯一标识 |
| Table ID | 多维表 → 打开表格 → 浏览器 URL 中获取 | 具体哪个表 |

**获取步骤：**
1. 打开飞书开放平台：https://open.feishu.cn/app
2. 创建企业自建应用
3. 在「凭证与基础信息」复制 App ID 和 App Secret
4. 创建或打开目标多维表
5. 浏览器地址栏 URL 格式：`https://xxx.feishu.cn/base/xxx?table=xxx`
   - `xxx`（第一段）= App Token
   - `table=` 后面的 `xxx` = Table ID

---

## 核心功能

1. **分镜截帧**：按字幕句子截帧 + 开场5秒每秒1帧
2. **画面描述**：多模态模型分析每帧画面（人物/场景/运镜/道具）
3. **分镜表生成**：时间点 + 台词 + 画面描述 → 结构化分镜表
4. **爆款逻辑分析**：AI 分析开场钩子/视觉节奏/情绪曲线/转化时机
5. **飞书写入**：批量写入飞书多维表「分镜表」

## 截帧策略

| 段落 | 策略 | 说明 |
|------|------|------|
| 开场 0-5s | 每秒1帧 | 钩子密度最高，需高分辨率观察 |
| 正文 | 按字幕句子截帧 | 台词和画面精准对齐 |
| 合并去重 | 相邻<0.8s 合并 | 避免重复，保持分镜独立 |

## 飞书分镜表字段结构

| 字段名 | 类型 | 说明 |
|--------|------|------|
| 分镜序号 | 数字（主字段） | 顺序编号 |
| 视频ID | 文本 | 抖音视频 ID |
| 视频名称 | 文本 | 视频标题 |
| 视频链接 | 超链接 | 原始短链 |
| 开始时间(秒) | 数字 | 分镜开始时间 |
| 结束时间(秒) | 数字 | 分镜结束时间 |
| 台词 | 长文本 | 该分镜对应台词 |
| 画面描述 | 长文本 | 多模态模型分析结果 |
| 分镜爆款作用 | 长文本 | 该分镜在整体中的作用 |

默认 Table ID: `tblG3xwnQxfYBpvS`

## 使用方法

```bash
# 基本提取（本地报告）
node ~/.workbuddy/skills/抖音视频拆分_存入飞书/douyin_shot.js extract "https://www.iesdouyin.com/share/video/7632645193632482738/"

# 提取并写入飞书分镜表
node ~/.workbuddy/skills/抖音视频拆分_存入飞书/douyin_shot.js extract "https://www.iesdouyin.com/share/video/7632645193632482738/" --feishu
```

## 环境变量配置

在 `~/.zshrc` 或 `~/.bashrc` 中添加：

```bash
# SiliconFlow API Key（必填）
export SILI_FLOW_API_KEY="sk-xxxxxxxxxxxxxxxxxxxxxxxx"

# 飞书凭证（写入飞书时需要）
export LARK_APP_ID="cli_xxxxxxxxxxxxx"
export LARK_APP_SECRET="xxxxxxxxxxxxxxxxxxxxxxxx"
export LARK_APP_TOKEN="OKvxb7b4QaLUicsuuAfc4DshnFg"
export LARK_STORYBOARD_TABLE_ID="tblG3xwnQxfYBpvS"
```

配置完成后执行 `source ~/.zshrc` 使环境变量生效。

## 产出示例

| 序号 | 时间 | 台词 | 画面描述 |
|------|------|------|---------|
| 01 | 0.0-2.5s | 一定要晨读！ | 开场/特写/人物出场/妈妈手持书本表情严肃 |
| 02 | 2.5-5.0s | 别让孩子语言爆发期被浪费 | 全场/孩子盯着手机/背景虚化 |
| 03 | 5.0-8.0s | 这本书每天认识6个生字 | 产品露出/书本特写/翻页动作 |

## 注意事项

- **多模态模型**：`describeFrame` 当前输出基础描述（台词+时间戳），需在 SiliconFlow 确认支持 Qwen2.5-VL 等 vision 模型后，将函数改为传图+多模态分析，可大幅提升画面描述质量
- 飞书多维表需提前创建「分镜表」，Table ID 写入环境变量
- 视频时长通过 ffmpeg 探测，自动获取真实时长
- 写入飞书时自动上传截图到多维表附件
