#!/usr/bin/env node

/**
 * 抖音视频分镜提取工具
 *
 * 功能:
 * 1. 下载抖音无水印视频
 * 2. 音频转写（带时间戳）
 * 3. 按字幕句子截帧 + 开场高密度截帧
 * 4. 多模态模型分析每帧画面
 * 5. 生成分镜表并写入飞书分镜表
 *
 * 环境变量:
 * - SILI_FLOW_API_KEY: 硅基流动 API 密钥
 * - LARK_APP_ID / LARK_APP_SECRET / LARK_APP_TOKEN / LARK_STORYBOARD_TABLE_ID
 *
 * 用法:
 *   node douyin_shot.js extract "https://v.douyin.com/xxxxx"
 *   node douyin_shot.js extract "链接" --feishu
 */

const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const https = require('https');
const http = require('http');
const { URL } = require('url');

const SILI_FLOW_BASE_URL = 'https://api.siliconflow.cn/v1';
const FFMPEG = process.env.FFMPEG_PATH ||
  '/Users/Zhuanz/WorkBuddy/20260421110229/venv/lib/python3.12/site-packages/imageio_ffmpeg/binaries/ffmpeg-macos-aarch64-v7.1';
const DEFAULT_DOWNLOAD_PATH = '/tmp/douyin-shot/';

// 飞书多维表配置
const LARK_APP_ID = process.env.LARK_APP_ID;
const LARK_APP_SECRET = process.env.LARK_APP_SECRET;
const LARK_APP_TOKEN = process.env.LARK_APP_TOKEN;
const LARK_STORYBOARD_TABLE_ID = process.env.LARK_STORYBOARD_TABLE_ID || 'tblG3xwnQxfYBpvS';

const HEADERS = {
  'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) EdgiOS/121.0.2277.107 Version/17.0 Mobile/15E148 Safari/604.1',
  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
  'Accept-Language': 'zh-CN,zh;q=0.9',
};

const LARK_BASE_URL = 'https://open.feishu.cn/open-apis';

// ========== 工具函数 ==========

function httpRequest(url, options = {}) {
  return new Promise((resolve, reject) => {
    const parsedUrl = new URL(url);
    const client = parsedUrl.protocol === 'https:' ? https : http;
    const req = client.request(url, {
      method: options.method || 'GET',
      headers: { ...HEADERS, ...options.headers }
    }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        httpRequest(res.headers.location, options).then(resolve).catch(reject);
        return;
      }
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve({ statusCode: res.statusCode, body: data, url }));
    });
    req.on('error', reject);
    req.setTimeout(30000, () => { req.destroy(); reject(new Error('Request timeout')); });
    if (options.body) req.write(options.body);
    req.end();
  });
}

function downloadFile(url, filepath) {
  return new Promise((resolve, reject) => {
    const parsedUrl = new URL(url);
    const client = parsedUrl.protocol === 'https:' ? https : http;
    const req = client.get(url, { headers: HEADERS }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        downloadFile(res.headers.location, filepath).then(resolve).catch(reject);
        return;
      }
      if (res.statusCode !== 200) { reject(new Error(`HTTP ${res.statusCode}`)); return; }
      const writer = fs.createWriteStream(filepath);
      res.pipe(writer);
      writer.on('finish', () => resolve(filepath));
      writer.on('error', reject);
    });
    req.on('error', reject);
    req.setTimeout(120000, () => { req.destroy(); reject(new Error('Download timeout')); });
  });
}

function runFfmpeg(args) {
  return new Promise((resolve, reject) => {
    const proc = spawn(FFMPEG, args);
    let stderr = '';
    proc.stderr.on('data', (data) => { stderr += data.toString(); });
    proc.on('close', (code) => {
      if (code === 0) resolve(); else reject(new Error(`ffmpeg exited ${code}: ${stderr.slice(-300)}`));
    });
    proc.on('error', reject);
  });
}

function spawnCmd(cmd, args) {
  return new Promise((resolve, reject) => {
    const proc = spawn(cmd, args);
    let stdout = '', stderr = '';
    proc.stdout.on('data', c => { stdout += c.toString(); });
    proc.stderr.on('data', c => { stderr += c.toString(); });
    proc.on('close', (code) => resolve({ code, stdout, stderr }));
    proc.on('error', reject);
  });
}

// ========== 解析抖音链接 ==========

async function parseShareUrl(shareText) {
  const modalIdMatch = shareText.match(/(?:modal_id[=:])?(\d{16,})/);
  if (modalIdMatch) return await getVideoInfoByModalId(modalIdMatch[1]);
  const urlMatch = shareText.match(/https?:\/\/[^\s]+/);
  if (!urlMatch) throw new Error('未找到有效的分享链接');
  const resp = await httpRequest(urlMatch[0]);
  const videoIdMatch = resp.url.match(/\/video\/(\d+)/);
  if (!videoIdMatch) throw new Error('无法从URL中提取视频ID');
  return await getVideoInfoByModalId(videoIdMatch[1]);
}

async function getVideoInfoByModalId(modalId) {
  const resp = await httpRequest(`https://www.iesdouyin.com/share/video/${modalId}/`);
  const match = resp.body.match(/window\._ROUTER_DATA\s*=\s*(.*?)<\/script>/);
  if (!match) throw new Error('解析视频信息失败');
  const jsonData = JSON.parse(match[1].trim());
  const loaderData = jsonData.loaderData || jsonData;
  let videoData = loaderData['video_(id)/page']?.videoInfoRes?.item_list?.[0]
    || loaderData['note_(id)/page']?.videoInfoRes?.item_list?.[0];
  if (!videoData) throw new Error('无法获取视频数据');
  const videoUrl = videoData.video?.play_addr?.url_list?.[0]?.replace('playwm', 'play')
    || videoData.video?.download_addr?.url_list?.[0];
  const desc = videoData.desc || `douyin_${modalId}`;
  return { url: videoUrl, title: desc.replace(/[\\/:*?"<>|]/g, '_'), video_id: modalId };
}

// ========== 语音转写 + 规则分段 + 时间戳估算 ==========

async function transcribeAndSegment(audioPath, apiKey, totalDuration, showProgress = true) {
  if (showProgress) console.log('正在语音转写...');
  const { stdout } = await spawnCmd('curl', [
    '-X', 'POST', `${SILI_FLOW_BASE_URL}/audio/transcriptions`,
    '-H', `Authorization: Bearer ${apiKey}`,
    '-F', `file=@${audioPath}`,
    '-F', `model=FunAudioLLM/SenseVoiceSmall`
  ]);
  let text = '';
  try { text = JSON.parse(stdout).text || ''; }
  catch { text = stdout; }
  if (showProgress) console.log(`转写完成: ${text.length} 字，时长${totalDuration.toFixed(1)}s`);

  if (showProgress) console.log('正在语义分段（全标点拆分，限制最大5秒/分镜）...');
  // 规则：按所有标点拆分（，。！？；：、）
  // 过滤过短片段（<5字），合并相邻短片段避免过度碎片化
  const MAX_SEG_DURATION = 5; // 每分镜最长5秒
  const MIN_CHARS = 5; // 最少字数

  // 拆分：先按所有标点拆成片段
  const rawParts = text.split(/(?<=[，。！？；：、])/g).map(s => s.trim()).filter(s => s.length > 0);

  // 合并相邻短片段（防止"（承接上句）"这种过短片段）
  const mergedParts = [];
  let buffer = '';
  for (const part of rawParts) {
    if (buffer.length === 0) {
      buffer = part;
    } else if (buffer.length < MIN_CHARS) {
      buffer += part;
    } else {
      mergedParts.push(buffer);
      buffer = part;
    }
  }
  if (buffer.length > 0) mergedParts.push(buffer);

  // 按字数比例分配时间，限制每段时长上限
  const totalChars = mergedParts.reduce((sum, s) => sum + s.length, 0);
  const segments = [];
  let currentTime = 0;
  for (const part of mergedParts) {
    const rawDuration = (part.length / totalChars) * totalDuration;
    const segDuration = Math.min(rawDuration, MAX_SEG_DURATION);
    const start = parseFloat(currentTime.toFixed(2));
    const end = parseFloat((currentTime + segDuration).toFixed(2));
    segments.push({ start, end, text: part });
    currentTime += segDuration;
    if (currentTime >= totalDuration) break;
  }

  if (showProgress) console.log(`分段完成: ${segments.length} 个分镜`);
  return { text, segments };
}

// ========== 多模态画面分析 + 每分镜爆款作用 ==========

async function describeFrame(imagePath, shotIndex, timestamp, dialogue, apiKey, showProgress = true) {
  if (showProgress) process.stdout.write(`\r  分析分镜 ${shotIndex} (${timestamp}s)...`);
  const imageData = fs.readFileSync(imagePath).toString('base64');
  const ext = path.extname(imagePath).replace('.', '') || 'jpeg';

  const data = {
    model: 'Qwen/Qwen2.5-VL-72B-Instruct',
    messages: [{
      role: 'user',
      content: [
        {
          type: 'image_url',
          image_url: { url: `data:image/${ext};base64,${imageData}` }
        },
        {
          type: 'text',
          text: `你是专业短视频编导，请仔细看图并结合台词分析：

台词：「${dialogue}」
时间：${timestamp}秒

请按以下格式输出（不要偏离格式）：
【画面描述】特写/中景/全景：具体画面内容，包括人物动作、产品/道具、场景、字幕等
【分镜爆款作用】该分镜在此视频中的作用：开场钩子/建立信任/产品展示/制造紧迫感/引导转化等，简短1-2句话`
        }
      ]
    }],
    max_tokens: 1024,
    temperature: 0.3,
    stream: false
  };

  const { stdout } = await spawnCmd('curl', [
    '-X', 'POST', `${SILI_FLOW_BASE_URL}/chat/completions`,
    '-H', `Authorization: Bearer ${apiKey}`,
    '-H', 'Content-Type: application/json',
    '-d', JSON.stringify(data)
  ]);

  try {
    const json = JSON.parse(stdout);
    const raw = json.choices?.[0]?.message?.content || '';
    // 解析结构化输出
    const descMatch = raw.match(/【画面描述】(.+?)(?=【分镜爆款作用】|$)/s);
    const analMatch = raw.match(/【分镜爆款作用】(.+)/s);
    const frameDesc = descMatch ? descMatch[1].trim() : raw.slice(0, 100);
    const shotAnalysis = analMatch ? analMatch[1].trim() : '（该分镜在整体视频中的作用待分析）';
    return { frameDesc, shotAnalysis };
  } catch {
    return { frameDesc: '（画面分析失败）', shotAnalysis: '（分镜作用待分析）' };
  }
}

// ========== 分镜爆款逻辑分析 ==========

async function analyzeShotViralLogic(shots, apiKey, showProgress = true) {
  if (showProgress) console.log('\n正在分析分镜爆款逻辑...');
  const shotList = shots.map((s, i) =>
    `[分镜${i + 1}] ${s.start}s-${s.end}s | 台词: ${s.dialogue} | 画面: ${s.frameDesc}`
  ).join('\n');
  const prompt = `# 角色
你是专业电商带货短视频编导，请分析以下分镜表的爆款逻辑。

# 分镜表
${shotList}

# 请从以下维度分析：
1. 开篇钩子：开场分镜如何3秒抓眼球？
2. 视觉节奏：各分镜镜头长短如何配合台词节奏？
3. 情绪曲线：情绪如何递进？
4. 产品露出：产品在哪个分镜自然出现？
5. 转化时机：结尾如何引导下单？
6. 可复用方法论：总结通用编导结构

请简洁回答，每维度不超过3句话。`;

  const data = {
    model: 'Qwen/Qwen2.5-7B-Instruct',
    messages: [{ role: 'user', content: prompt }],
    max_tokens: 2048,
    temperature: 0.3,
    stream: false
  };
  const { stdout } = await spawnCmd('curl', [
    '-X', 'POST', `${SILI_FLOW_BASE_URL}/chat/completions`,
    '-H', `Authorization: Bearer ${apiKey}`,
    '-H', 'Content-Type: application/json',
    '-d', JSON.stringify(data)
  ]);
  try {
    const json = JSON.parse(stdout);
    return json.choices?.[0]?.message?.content || null;
  } catch { return null; }
}

// ========== 截帧 ==========

async function extractFrames(videoPath, outputDir, timestamps, showProgress = true) {
  fs.mkdirSync(outputDir, { recursive: true });
  const frames = [];
  for (const ts of timestamps) {
    const framePath = path.join(outputDir, `frame_${String(ts.frameIndex).padStart(3, '0')}_${ts.time.toFixed(2)}s.jpg`);
    try {
      await runFfmpeg([
        '-ss', String(ts.time),
        '-i', videoPath,
        '-vframes', '1',
        '-q:v', '2',
        '-y', framePath
      ]);
      if (fs.existsSync(framePath)) {
        frames.push({ path: framePath, time: ts.time, dialogue: ts.dialogue, index: ts.frameIndex });
      }
    } catch (e) {
      if (showProgress) console.log(`  截帧失败 ${ts.time}s: ${e.message}`);
    }
  }
  return frames;
}

// ========== 飞书写入 ==========

async function getLarkToken(showProgress = true) {
  if (!LARK_APP_ID || !LARK_APP_SECRET) return null;
  const resp = await httpRequest(`${LARK_BASE_URL}/auth/v3/tenant_access_token/internal`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ app_id: LARK_APP_ID, app_secret: LARK_APP_SECRET })
  });
  const data = JSON.parse(resp.body);
  if (data.code !== 0) throw new Error(`获取飞书Token失败: ${data.msg}`);
  return data.tenant_access_token;
}

async function uploadImageToLark(imagePath, larkToken) {
  // 飞书多维表附件字段需用 Drive API 上传
  return new Promise((resolve, reject) => {
    const filename = path.basename(imagePath);
    const imageBuffer = fs.readFileSync(imagePath);
    const fileSize = imageBuffer.length;
    const boundary = '----FormBoundary7MA4YWxkTrZu0gW';

    const bodyParts = [
      Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="file_name"\r\n\r\n${filename}\r\n`),
      Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="parent_type"\r\n\r\nbitable_file\r\n`),
      Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="parent_node"\r\n\r\n${LARK_APP_TOKEN}\r\n`),
      Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="size"\r\n\r\n${fileSize}\r\n`),
      Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="${filename}"\r\nContent-Type: image/jpeg\r\n\r\n`),
      imageBuffer,
      Buffer.from(`\r\n--${boundary}--`),
    ];
    const body = Buffer.concat(bodyParts);

    const urlObj = new URL(`${LARK_BASE_URL}/drive/v1/medias/upload_all`);
    const options = {
      hostname: urlObj.hostname,
      path: urlObj.pathname,
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${larkToken}`,
        'Content-Type': `multipart/form-data; boundary=${boundary}`,
        'Content-Length': body.length,
      }
    };
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', c => { data += c; });
      res.on('end', () => {
        try {
          const json = JSON.parse(data);
          resolve(json.data?.file_token || null);
        } catch { resolve(null); }
      });
    });
    req.on('error', () => resolve(null));
    req.write(body);
    req.end();
  });
}

async function writeStoryboardToFeishu(videoInfo, shots, frameTimeMap, larkToken, showProgress = true) {
  if (!larkToken || !LARK_APP_TOKEN || !LARK_STORYBOARD_TABLE_ID) return false;
  if (showProgress) console.log('\n正在写入飞书分镜表...');

  const batchSize = 5;
  for (let i = 0; i < shots.length; i += batchSize) {
    const batch = shots.slice(i, i + batchSize);
    // 根据分镜起始时间查找截图路径并上传
    console.log(`[截图] frameTimeMap 大小: ${frameTimeMap.size}, 示例 keys: ${[...frameTimeMap.keys()].slice(0,3)}`);
    const uploadedImages = await Promise.all(
      batch.map(async (shot) => {
        const roundedStart = Math.round(shot.start * 10) / 10;
        const framePath = frameTimeMap.get(roundedStart);
        if (!framePath) {
          console.log(`[截图] 分镜${shot.start}s 未找到截图 (rounded=${roundedStart})`);
          return null;
        }
        if (!fs.existsSync(framePath)) {
          console.log(`[截图] 截图文件不存在: ${framePath}`);
          return null;
        }
        const imgToken = await uploadImageToLark(framePath, larkToken);
        console.log(`[截图] 上传 ${roundedStart}s → ${imgToken ? '成功' : '失败'}`);
        return imgToken;
      })
    );

    const records = batch.map((shot, j) => {
      const idx = String(i + j + 1);
      const fields = {
        '分镜序号': String(idx),  // 文本类型字段
        '视频ID': videoInfo.video_id,
        '视频名称': videoInfo.title,  // 视频标题
        '视频链接': { link: `https://v.douyin.com/${videoInfo.video_id}/` },
        '开始时间(秒)': Math.round(shot.start * 10) / 10,
        '结束时间(秒)': shot.end ? Math.round(shot.end * 10) / 10 : null,
        '台词': shot.dialogue || '',
        '画面描述': (shot.frameDesc || '').replace(/\n+/g, ' ').trim(),
        '分镜爆款作用': (shot.shotAnalysis || '').replace(/\n+/g, ' ').trim(),
      };
      // 附件字段：截图（需要用 file_token 格式）
      const imageKey = uploadedImages[j];
      if (imageKey) {
        fields['截图'] = [{ file_token: imageKey }];
      }
      return { fields };
    });
    const resp = await httpRequest(
      `${LARK_BASE_URL}/bitable/v1/apps/${LARK_APP_TOKEN}/tables/${LARK_STORYBOARD_TABLE_ID}/records/batch_create`,
      {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${larkToken}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ records })
      }
    );
    const data = JSON.parse(resp.body);
    if (data.code !== 0) {
      if (showProgress) console.log(`  写入失败: ${data.msg}`);
    }
  }
  if (showProgress) console.log(`✓ 分镜表已写入飞书（共 ${shots.length} 条分镜）`);
  return true;
}

// ========== 主提取函数 ==========

async function extractStoryboard(shareLink, apiKey, outputDir, writeToFeishu = false, showProgress = true) {
  if (showProgress) console.log('正在解析抖音链接...');
  const videoInfo = await parseShareUrl(shareLink);

  if (showProgress) console.log(`正在下载视频: ${videoInfo.title}`);
  const videoPath = path.join(outputDir, `${videoInfo.video_id}.mp4`);
  await downloadFile(videoInfo.url, videoPath);

  // 获取视频真实时长（使用 -f null 探测，不依赖特定输出格式）
  if (showProgress) console.log('正在获取视频时长...');
  let totalDuration = 60;
  try {
    const { stdout: probeStdout, stderr: probeStderr } = await spawnCmd(FFMPEG, [
      '-i', videoPath, '-f', 'null', '-'
    ]);
    const probeOutput = probeStdout + probeStderr;
    const match = probeOutput.match(/time[=_]?(\d+):(\d+):(\d+\.?\d*)/);
    if (match) {
      totalDuration = parseInt(match[1]) * 3600 + parseInt(match[2]) * 60 + parseFloat(match[3]);
      if (showProgress) console.log(`视频时长: ${totalDuration.toFixed(1)}s`);
    } else {
      if (showProgress) console.log(`视频时长: 估算 ${totalDuration.toFixed(1)}s`);
    }
  } catch (e) {
    if (showProgress) console.log(`视频时长: 估算 ${totalDuration.toFixed(1)}s`);
  }

  if (showProgress) console.log('正在提取音频...');
  const audioPath = videoPath.replace(/\.mp4$/, '.mp3');
  await runFfmpeg(['-i', videoPath, '-vn', '-acodec', 'libmp3lame', '-q:a', '0', '-y', audioPath]);

  // 语音转写 + 语义分段 + 时间戳估算
  const { text: fullText, segments } = await transcribeAndSegment(audioPath, apiKey, totalDuration, showProgress);

  // 构建截帧时间点
  const frameTimestamps = [];

  // 策略1：开场3秒，每秒1帧（高密度）
  const openingSeconds = Math.min(3, totalDuration);
  for (let t = 0; t < openingSeconds; t += 1) {
    frameTimestamps.push({ time: t, dialogue: '(开场画面)', frameIndex: frameTimestamps.length + 1 });
  }

  // 策略2：每个分镜取起始时间点（非中间点），确保时间轴精准对齐
  segments.forEach((seg, i) => {
    if (seg.start > openingSeconds || i === segments.length - 1) {
      const dialogue = seg.text || '(无台词)';
      frameTimestamps.push({ time: seg.start, dialogue, frameIndex: frameTimestamps.length + 1 });
    }
  });

  // 去重（按时间排序后，合并相近时间点）
  frameTimestamps.sort((a, b) => a.time - b.time);
  const deduped = [];
  let lastTime = -1;
  for (const ft of frameTimestamps) {
    if (ft.time - lastTime > 0.8) {
      deduped.push(ft);
      lastTime = ft.time;
    }
  }

  if (showProgress) console.log(`\n共需分析 ${deduped.length} 个分镜...`);

  // 截帧
  const framesDir = path.join(outputDir, `${videoInfo.video_id}_frames`);
  const frames = await extractFrames(videoPath, framesDir, deduped, showProgress);
  if (showProgress) console.log(`\n截帧完成: ${frames.length} 张`);

  // 构建分镜数据
  // 直接匹配 frame.time → segment（帧时间 = 分镜起始时间）
  const shots = [];
  const frameTimeMap = new Map(); // 帧时间 → 截图路径
  for (const frame of frames) {
    // 精确匹配：帧时间 = 分镜起始时间
    const matched = segments.find(s => Math.abs(s.start - frame.time) < 0.5);
    const dialogue = matched?.text || frame.dialogue;
    const startTime = matched?.start ?? frame.time;
    const endTime = matched?.end ?? Math.min(frame.time + 3, totalDuration);

    // 多模态分析：画面描述 + 分镜爆款作用
    let frameDesc = '';
    let shotAnalysis = '';
    try {
      const result = await describeFrame(frame.path, frame.index, frame.time, dialogue, apiKey, showProgress);
      frameDesc = result.frameDesc;
      shotAnalysis = result.shotAnalysis;
    } catch (e) {
      frameDesc = `画面截图 | ${dialogue}`;
      shotAnalysis = '（分析失败）';
    }

    shots.push({
      start: Math.round(startTime * 10) / 10,
      end: Math.round(endTime * 10) / 10,
      dialogue,
      frameDesc,
      shotAnalysis,
      framePath: frame.path
    });
    // 建立帧时间→截图路径的映射，供写飞书时查找
    frameTimeMap.set(Math.round(frame.time * 10) / 10, frame.path);
  }

  // 写入飞书（分镜爆款作用已由 describeFrame 逐镜生成）
  if (writeToFeishu) {
    try {
      const token = await getLarkToken(showProgress);
      if (token) await writeStoryboardToFeishu(videoInfo, shots, frameTimeMap, token, showProgress);
    } catch (e) {
      if (showProgress) console.log('写入飞书失败:', e.message);
    }
  }

  // 清理临时文件
  try { fs.unlinkSync(videoPath); } catch {}
  try { fs.unlinkSync(audioPath); } catch {}

  // 保存本地报告
  const reportPath = path.join(outputDir, `${videoInfo.video_id}_storyboard.md`);
  const report = `# ${videoInfo.title}

| 属性 | 值 |
|------|-----|
| 视频ID | \`${videoInfo.video_id}\` |
| 时长 | ${totalDuration.toFixed(1)}s |
| 分镜数 | ${shots.length} |
| 提取时间 | ${new Date().toLocaleString('zh-CN')} |

---

## 分镜表

| 序号 | 时间 | 台词 | 画面描述 | 分镜爆款作用 |
|------|------|------|---------|------------|
${shots.map((s, i) => `| ${i + 1} | ${s.start}-${s.end}s | ${s.dialogue} | ${s.frameDesc} | ${s.shotAnalysis} |`).join('\n')}
`;
  fs.writeFileSync(reportPath, report, 'utf-8');
  if (showProgress) console.log(`\n报告已保存: ${reportPath}`);

  return { videoInfo, shots, reportPath, totalDuration };
}

// ========== 主入口 ==========

async function main() {
  const args = process.argv.slice(2);
  const command = args[0];
  const shareLink = args[1];

  if (!command || !shareLink || command === 'help') {
    console.log(`
抖音视频分镜提取工具

用法:
  node douyin_shot.js extract "链接"              - 提取分镜
  node douyin_shot.js extract "链接" --feishu     - 提取并写入飞书分镜表

环境变量:
  SILI_FLOW_API_KEY        - 硅基流动 API 密钥
  LARK_APP_ID              - 飞书 App ID
  LARK_APP_SECRET          - 飞书 App Secret
  LARK_APP_TOKEN           - 多维表 App Token
  LARK_STORYBOARD_TABLE_ID - 分镜表 Table ID（默认 tblG3xwnQxfYBpvS）

截帧策略:
  开场5秒：每秒1帧
  正文部分：按字幕句子截帧
`);
    process.exit(1);
  }

  const apiKey = process.env.SILI_FLOW_API_KEY;
  if (!apiKey) { console.error('请设置 SILI_FLOW_API_KEY'); process.exit(1); }

  let outputDir = DEFAULT_DOWNLOAD_PATH;
  let writeToFeishu = false;
  for (let i = 2; i < args.length; i++) {
    if (args[i] === '-o' && args[i + 1]) { outputDir = args[i + 1]; i++; }
    else if (args[i] === '--feishu') writeToFeishu = true;
  }

  try {
    const result = await extractStoryboard(shareLink, apiKey, outputDir, writeToFeishu, true);
    console.log('\n' + '='.repeat(50));
    console.log('分镜提取完成 ✅');
    console.log('='.repeat(50));
    console.log(`视频: ${result.videoInfo.title}`);
    console.log(`分镜数: ${result.shots.length}`);
    console.log(`时长: ${result.totalDuration.toFixed(1)}s`);
    console.log(`报告: ${result.reportPath}`);
    console.log('='.repeat(50));
  } catch (err) {
    console.error(`错误: ${err.message}`);
    process.exit(1);
  }
}

main();
