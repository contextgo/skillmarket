#!/usr/bin/env python3
"""
Configuration management for github-proxy-clone.

Supports environment variable overrides:
- GHPROXY_API_URL: Proxy node API endpoint
- GHPROXY_GITHUB_API_BASES: Comma-separated list of GitHub API bases
- GHPROXY_OUTPUT_DIR: Default output directory
- GHPROXY_FALLBACK_HOSTS: Comma-separated list of fallback hosts
"""

from dataclasses import dataclass, field
import os
from typing import Any
from urllib.parse import urlparse

# Constants for readability
DEFAULT_LATENCY = 999999
DEFAULT_SPEED = 0.0
VERSION = "2.0"
DEFAULT_HTTP_TIMEOUT = 15


@dataclass
class Node:
    """Represents a proxy node."""
    host: str
    latency: int = DEFAULT_LATENCY
    speed: float = DEFAULT_SPEED
    tag: str = ""
    location: str = ""
    server: str = ""

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Node":
        """Create Node from API response dict."""
        raw_url = data.get("url", "").strip()
        parsed = urlparse(raw_url if raw_url.startswith("http") else f"//{raw_url}")
        host = parsed.netloc or parsed.path

        try:
            latency = int(data.get("latency", DEFAULT_LATENCY))
        except (ValueError, TypeError):
            latency = DEFAULT_LATENCY

        try:
            speed = float(data.get("speed", DEFAULT_SPEED))
        except (ValueError, TypeError):
            speed = DEFAULT_SPEED

        return cls(
            host=host,
            latency=latency,
            speed=speed,
            tag=data.get("tag", ""),
            location=data.get("location", ""),
            server=data.get("server", ""),
        )


@dataclass
class Config:
    """Global configuration with environment variable overrides."""

    # API endpoints
    api_url: str = "https://api.akams.cn/github"
    github_api_bases: list[str] = field(default_factory=lambda: [
        "https://api.github.com",
        "https://ghfile.geekertao.top/https://api.github.com",
    ])

    # Fallback hosts when API is unavailable
    fallback_hosts: list[Node] = field(default_factory=lambda: [
        Node(host="gh.llkk.cc", latency=999999, speed=0.0, tag="fallback"),
        Node(host="gh.felicity.ac.cn", latency=999999, speed=0.0, tag="fallback"),
    ])

    # Output settings
    output_dir: str = field(default_factory=lambda: os.path.join(
        os.environ.get("TEMP", "/tmp") if os.name == "nt" else "/tmp",
        "github_project"
    ))

    # User agent for HTTP requests
    user_agent: str = f"OpenClaw github-proxy-clone/{VERSION}"

    # HTTP timeout in seconds
    http_timeout: int = DEFAULT_HTTP_TIMEOUT

    @classmethod
    def from_env(cls) -> "Config":
        """Create Config from environment variables."""
        config = cls()

        if api_url := os.environ.get("GHPROXY_API_URL"):
            config.api_url = api_url

        if github_api_bases := os.environ.get("GHPROXY_GITHUB_API_BASES"):
            config.github_api_bases = [
                b.strip() for b in github_api_bases.split(",") if b.strip()
            ]

        if output_dir := os.environ.get("GHPROXY_OUTPUT_DIR"):
            config.output_dir = os.path.expanduser(output_dir)

        if fallback_hosts := os.environ.get("GHPROXY_FALLBACK_HOSTS"):
            config.fallback_hosts = [
                Node(host=h.strip()) for h in fallback_hosts.split(",") if h.strip()
            ]

        return config

    def get_output_dir(self) -> str:
        """Get output directory, creating it if needed."""
        path = os.path.expanduser(self.output_dir)
        os.makedirs(path, exist_ok=True)
        return path

    def resolve_output_path(
        self, output: str | None, default_name: str | None = None
    ) -> str | None:
        """Resolve final output path from user input and defaults.

        Raises:
            ValueError: If path traversal is detected.
        """
        if output:
            output = os.path.expanduser(output)
            # Security: prevent path traversal
            if ".." in output:
                raise ValueError("Path traversal not allowed")
            if output.endswith("/") or output.endswith("\\") or os.path.isdir(output):
                if not default_name:
                    raise ValueError("default_name required when output is a directory")
                os.makedirs(output, exist_ok=True)
                return os.path.join(output, default_name)
            parent = os.path.dirname(output)
            if parent:
                os.makedirs(parent, exist_ok=True)
            return output

        if default_name:
            return os.path.join(self.get_output_dir(), default_name)
        return None


# Global config instance
_config: Config | None = None


def get_config() -> Config:
    """Get the global Config instance."""
    global _config
    if _config is None:
        _config = Config.from_env()
    return _config


def reset_config() -> None:
    """Reset global config (mainly for testing)."""
    global _config
    _config = None
