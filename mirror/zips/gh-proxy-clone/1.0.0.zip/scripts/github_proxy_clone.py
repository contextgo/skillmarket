#!/usr/bin/env python3
"""
GitHub proxy downloader: clone/archive/raw/releases

Supports four modes:
- clone: Generate or execute git clone with proxy
- archive: Download repository archives (zip/tar.gz)
- raw: Download single raw files
- releases: List or download release assets
"""

import argparse
import json
import os
import re
import subprocess
import sys
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import quote, urlparse

from config import Config, Node, get_config


@dataclass
class RawInfo:
    """Parsed raw file information."""
    owner: str
    repo: str
    ref: str
    path: str
    normalized_raw: str


@dataclass
class Payload:
    """Download payload with all metadata."""
    kind: str
    source_url: str = ""
    proxy_url: str = ""
    command: list[str] = field(default_factory=list)
    output: str | None = None
    ref: str = ""
    archive_kind: str = ""
    format: str = ""
    path: str = ""
    tag: str = ""
    release_name: str = ""
    assets: list[dict] = field(default_factory=list)


def http_get_json(url: str, config: Config | None = None) -> dict:
    """Fetch JSON from URL with error handling.

    Raises:
        urllib.error.URLError: If connection fails.
        json.JSONDecodeError: If response is not valid JSON.
    """
    if config is None:
        config = get_config()
    req = urllib.request.Request(
        url,
        headers={"User-Agent": config.user_agent}
    )
    with urllib.request.urlopen(req, timeout=config.http_timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def normalize_repo(repo: str) -> tuple[str, str, str]:
    """
    Normalize various repo input formats to (owner, name, git_url).

    Supported formats:
    - https://github.com/owner/repo
    - https://github.com/owner/repo.git
    - owner/repo
    - owner/repo.git
    """
    repo = repo.strip()
    if not repo:
        raise ValueError("empty repo")

    if repo.startswith("https://") or repo.startswith("http://"):
        m = re.match(r"https?://github\.com/([^/]+)/([^/]+?)(?:\.git)?/?$", repo)
        if not m:
            raise ValueError(f"unsupported GitHub repo URL: {repo}")
        owner, name = m.group(1), m.group(2)
    else:
        m = re.match(r"([^/]+)/([^/]+?)(?:\.git)?$", repo)
        if not m:
            raise ValueError(f"unsupported repo format: {repo}")
        owner, name = m.group(1), m.group(2)

    return owner, name, f"https://github.com/{owner}/{name}.git"


def normalize_raw_input(
    raw_url: str | None,
    repo: str | None,
    raw_path: str | None,
    ref: str | None,
    config: Config | None = None
) -> RawInfo:
    """
    Normalize raw file input.

    Supports:
    - Direct raw.githubusercontent.com URL
    - repo + path combination
    """
    if raw_url:
        m = re.match(
            r"https?://raw\.githubusercontent\.com/([^/]+)/([^/]+)/([^/]+)/(.+)$",
            raw_url.strip()
        )
        if not m:
            raise ValueError("unsupported raw URL format")
        return RawInfo(
            owner=m.group(1),
            repo=m.group(2),
            ref=m.group(3),
            path=m.group(4),
            normalized_raw=raw_url.strip(),
        )

    if not repo or not raw_path:
        raise ValueError("raw mode requires either --raw-url or (--repo + --raw-path)")

    owner, name, _ = normalize_repo(repo)
    raw_path = raw_path.lstrip("/")
    if not ref:
        ref = get_default_branch(owner, name, config)
    normalized_raw = f"https://raw.githubusercontent.com/{owner}/{name}/{ref}/{raw_path}"
    return RawInfo(
        owner=owner,
        repo=name,
        ref=ref,
        path=raw_path,
        normalized_raw=normalized_raw,
    )


def fetch_nodes(config: Config | None = None) -> list[Node]:
    """Fetch proxy nodes from API and parse into Node objects."""
    if config is None:
        config = get_config()

    data = http_get_json(config.api_url, config)
    items = data.get("data") or []
    results = []

    for item in items:
        node = Node.from_dict(item)
        if node.host:
            results.append(node)

    if not results:
        raise RuntimeError("empty node list from API")
    return results


def choose_nodes(nodes: list[Node], top: int = 3) -> tuple[list[Node], list[Node]]:
    """
    Choose top N nodes by latency and speed, with deduplication.

    Returns (recommended, all_ordered).
    """
    dedup: dict[str, Node] = {}
    for n in nodes:
        prev = dedup.get(n.host)
        if prev is None or (n.latency, -n.speed) < (prev.latency, -prev.speed):
            dedup[n.host] = n

    ordered = sorted(
        dedup.values(),
        key=lambda x: (x.latency, -x.speed, x.host)
    )
    return ordered[:top], ordered


def proxy_url(host: str, original_url: str) -> str:
    """Build proxy URL from host and original URL."""
    return f"https://{host}/{original_url}"


def curl_command(url: str, output: str | None = None) -> list[str]:
    """Build curl download command."""
    cmd = ["curl", "-L"]
    if output:
        cmd += ["-o", output]
    else:
        cmd += ["-O"]
    cmd.append(url)
    return cmd


def wget_command(url: str, output: str | None = None) -> list[str]:
    """Build wget download command."""
    cmd = ["wget"]
    if output:
        cmd += ["-O", output]
    cmd.append(url)
    return cmd


def download_command(
    url: str,
    downloader: str,
    output: str | None = None
) -> list[str]:
    """Build download command for specified downloader."""
    return curl_command(url, output) if downloader == "curl" else wget_command(url, output)


def github_api_get(path: str, config: Config | None = None) -> dict:
    """Fetch from GitHub API with fallback bases.

    Raises:
        RuntimeError: If all API bases fail.
    """
    if config is None:
        config = get_config()

    errors = []
    for base in config.github_api_bases:
        url = f"{base}{path}"
        try:
            return http_get_json(url, config)
        except (urllib.error.URLError, json.JSONDecodeError, OSError) as e:
            errors.append(f"{base}: {e}")
    raise RuntimeError("all GitHub API bases failed: " + " | ".join(errors))


def get_default_branch(
    owner: str,
    repo: str,
    config: Config | None = None
) -> str:
    """Get default branch name for a repository."""
    data = github_api_get(f"/repos/{quote(owner)}/{quote(repo)}", config)
    branch = data.get("default_branch")
    if not branch:
        raise RuntimeError(f"cannot determine default branch for {owner}/{repo}")
    return branch


def get_release(
    owner: str,
    repo: str,
    tag: str | None,
    config: Config | None = None
) -> dict:
    """Get release by tag (or latest)."""
    if not tag or tag == "latest":
        return github_api_get(f"/repos/{quote(owner)}/{quote(repo)}/releases/latest", config)
    return github_api_get(f"/repos/{quote(owner)}/{quote(repo)}/releases/tags/{quote(tag)}", config)


def build_clone_payload(
    best_host: str,
    owner: str,
    repo: str,
    normalized_repo: str,
    dest: str | None,
    config: Config | None = None
) -> Payload:
    """Build clone payload."""
    if config is None:
        config = get_config()

    url = proxy_url(best_host, normalized_repo)
    target_dir = os.path.expanduser(dest) if dest else os.path.join(config.get_output_dir(), repo)
    parent = os.path.dirname(target_dir)
    if parent:
        os.makedirs(parent, exist_ok=True)
    cmd = ["git", "clone", url, target_dir]
    return Payload(
        kind="clone",
        source_url=normalized_repo,
        proxy_url=url,
        command=cmd,
        output=target_dir,
    )


def build_archive_source(
    owner: str,
    repo: str,
    ref: str,
    archive_kind: str,
    fmt: str
) -> str:
    """Build archive source URL."""
    fmt = "tar.gz" if fmt == "tgz" else fmt
    if archive_kind == "auto":
        archive_kind = "branch"
    if archive_kind == "branch":
        return f"https://github.com/{owner}/{repo}/archive/refs/heads/{ref}.{fmt}"
    if archive_kind == "tag":
        return f"https://github.com/{owner}/{repo}/archive/refs/tags/{ref}.{fmt}"
    if archive_kind == "commit":
        return f"https://github.com/{owner}/{repo}/archive/{ref}.{fmt}"
    raise ValueError(f"unsupported archive kind: {archive_kind}")


def default_archive_output(repo: str, ref: str, fmt: str) -> str:
    """Generate default archive filename."""
    safe_fmt = "tar.gz" if fmt == "tar.gz" else fmt
    return f"{repo}-{ref}.{safe_fmt}"


def build_archive_payload(
    best_host: str,
    owner: str,
    repo: str,
    ref: str,
    archive_kind: str,
    fmt: str,
    downloader: str,
    output: str | None,
    config: Config | None = None
) -> Payload:
    """Build archive download payload."""
    if config is None:
        config = get_config()

    source = build_archive_source(owner, repo, ref, archive_kind, fmt)
    proxied = proxy_url(best_host, source)
    out = config.resolve_output_path(output, default_archive_output(repo, ref, fmt))
    return Payload(
        kind="archive",
        source_url=source,
        proxy_url=proxied,
        command=download_command(proxied, downloader, out),
        output=out,
        ref=ref,
        archive_kind=archive_kind,
        format=fmt,
    )


def build_raw_payload(
    best_host: str,
    raw_info: RawInfo,
    downloader: str,
    output: str | None,
    config: Config | None = None
) -> Payload:
    """Build raw file download payload."""
    if config is None:
        config = get_config()

    source = raw_info.normalized_raw
    proxied = proxy_url(best_host, source)
    out = config.resolve_output_path(output, os.path.basename(raw_info.path))
    return Payload(
        kind="raw",
        source_url=source,
        proxy_url=proxied,
        command=download_command(proxied, downloader, out),
        output=out,
        ref=raw_info.ref,
        path=raw_info.path,
    )


def build_release_payload(
    best_host: str,
    owner: str,
    repo: str,
    tag: str | None,
    asset_name: str | None,
    downloader: str,
    output: str | None,
    config: Config | None = None
) -> Payload:
    """Build release assets payload."""
    if config is None:
        config = get_config()

    rel = get_release(owner, repo, tag, config)
    tag_name = rel.get("tag_name")
    assets = rel.get("assets") or []

    if asset_name:
        match = next((a for a in assets if a.get("name") == asset_name), None)
        if not match:
            names = ", ".join(a.get("name", "") for a in assets[:20])
            raise RuntimeError(
                f"release asset not found: {asset_name}. available: {names}"
            )
        source = match["browser_download_url"]
        proxied = proxy_url(best_host, source)
        out = config.resolve_output_path(output, match.get("name") or asset_name)
        return Payload(
            kind="release-asset",
            tag=tag_name,
            release_name=rel.get("name", ""),
            source_url=source,
            proxy_url=proxied,
            command=download_command(proxied, downloader, out),
            output=out,
            assets=[
                {
                    "name": a.get("name"),
                    "size": a.get("size"),
                    "download_count": a.get("download_count"),
                    "browser_download_url": a.get("browser_download_url"),
                }
                for a in assets
            ],
        )

    return Payload(
        kind="release-list",
        tag=tag_name,
        release_name=rel.get("name", ""),
        assets=[
            {
                "name": a.get("name"),
                "size": a.get("size"),
                "download_count": a.get("download_count"),
                "browser_download_url": a.get("browser_download_url"),
                "proxy_url": proxy_url(best_host, a.get("browser_download_url")),
                "command": download_command(
                    proxy_url(best_host, a.get("browser_download_url")),
                    downloader,
                    config.resolve_output_path(None, a.get("name")),
                ),
            }
            for a in assets
        ],
    )


def print_human(payload: Payload, recommendations: list[Node]) -> None:
    """Print human-readable output."""
    print(f"Mode: {payload.kind}")
    print("Recommended nodes:")
    for idx, n in enumerate(recommendations, 1):
        print(f"{idx}. {n.host}  latency={n.latency}ms  speed={n.speed:.2f}Mbps")
    print()

    if payload.kind == "release-list":
        print(f"Release: {payload.tag}  name={payload.release_name}")
        if not payload.assets:
            print("No assets in this release.")
            return
        print("Assets:")
        for idx, asset in enumerate(payload.assets, 1):
            print(f"{idx}. {asset['name']}  size={asset.get('size')}  downloads={asset.get('download_count')}")
            print("   " + asset["proxy_url"])
            print("   " + " ".join(asset["command"]))
        return

    if payload.source_url:
        print(f"Source: {payload.source_url}")
    print(f"Proxy : {payload.proxy_url}")
    print(f"Output: {payload.output}")
    print("Command:")
    print("  " + " ".join(payload.command))


def build_result(
    used_fallback: bool,
    fallback_reason: str | None,
    best: Node,
    recommendations: list[Node],
    payload: Payload
) -> dict:
    """Build result dict for JSON output."""
    return {
        "used_fallback": used_fallback,
        "fallback_reason": fallback_reason,
        "best_node": {
            "host": best.host,
            "latency": best.latency,
            "speed": best.speed,
            "tag": best.tag,
            "location": best.location,
            "server": best.server,
        },
        "recommendations": [
            {
                "host": n.host,
                "latency": n.latency,
                "speed": n.speed,
                "tag": n.tag,
            }
            for n in recommendations
        ],
        "payload": {
            "kind": payload.kind,
            "source_url": payload.source_url,
            "proxy_url": payload.proxy_url,
            "command": payload.command,
            "output": payload.output,
        },
    }


def main() -> None:
    """Main entry point."""
    ap = argparse.ArgumentParser(
        description="GitHub proxy downloader: clone/archive/raw/releases",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Environment variables:
  GHPROXY_API_URL         Proxy node API endpoint
  GHPROXY_GITHUB_API_BASES  Comma-separated GitHub API bases
  GHPROXY_OUTPUT_DIR      Default output directory
  GHPROXY_FALLBACK_HOSTS  Comma-separated fallback hosts
        """
    )
    ap.add_argument("--repo", help="GitHub repo URL or owner/repo")
    ap.add_argument(
        "--mode",
        choices=["clone", "archive", "raw", "releases"],
        default="clone",
        help="Operation mode (default: clone)"
    )
    ap.add_argument("--top", type=int, default=3, help="How many recommended nodes to show")
    ap.add_argument("--exec", dest="do_exec", action="store_true",
                    help="Execute the generated command with the best node")
    ap.add_argument("--dest", help="Destination dir/path")
    ap.add_argument("--json", action="store_true", help="Print JSON output")
    ap.add_argument("--downloader", choices=["curl", "wget"], default="curl")

    ap.add_argument("--ref", help="Branch/tag/commit/ref")
    ap.add_argument("--archive-kind", choices=["auto", "branch", "tag", "commit"], default="auto")
    ap.add_argument("--format", choices=["zip", "tar.gz", "tgz"], default="zip")

    ap.add_argument("--raw-path", help="Path inside repo for raw file")
    ap.add_argument("--raw-url", help="Direct raw.githubusercontent.com URL")

    ap.add_argument("--tag", help="Release tag (omit for latest)")
    ap.add_argument("--asset", help="Specific release asset name to download")

    args = ap.parse_args()

    config = get_config()
    used_fallback = False
    error = None

    try:
        nodes = fetch_nodes(config)
    except Exception as e:
        used_fallback = True
        error = str(e)
        nodes = config.fallback_hosts[:]

    recommended, _ = choose_nodes(nodes, top=max(1, args.top))
    best = recommended[0]

    if args.mode == "raw":
        raw_info = normalize_raw_input(
            args.raw_url, args.repo, args.raw_path, args.ref, config
        )
        payload = build_raw_payload(
            best.host, raw_info, args.downloader, args.dest, config
        )
    else:
        if not args.repo:
            raise SystemExit("--repo is required for modes clone/archive/releases")
        owner, repo, normalized_repo = normalize_repo(args.repo)

        if args.mode == "clone":
            payload = build_clone_payload(
                best.host, owner, repo, normalized_repo, args.dest, config
            )
        elif args.mode == "archive":
            ref = args.ref or get_default_branch(owner, repo, config)
            payload = build_archive_payload(
                best.host, owner, repo, ref,
                args.archive_kind, args.format,
                args.downloader, args.dest, config
            )
        elif args.mode == "releases":
            payload = build_release_payload(
                best.host, owner, repo, args.tag, args.asset,
                args.downloader, args.dest, config
            )
        else:
            raise SystemExit(f"unsupported mode: {args.mode}")

    if args.do_exec:
        if payload.kind == "release-list":
            raise SystemExit("release list mode cannot be executed; provide --asset to download")
        print(f"[github-proxy-clone] using host: {best.host}", file=sys.stderr)
        print(f"[github-proxy-clone] running: {' '.join(payload.command)}", file=sys.stderr)
        subprocess.run(payload.command, check=True)
        return

    if args.json:
        result = build_result(used_fallback, error, best, recommended, payload)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return

    if used_fallback:
        print(f"Warning: API unavailable, using fallback hosts. reason={error}")
    print_human(payload, recommended)


if __name__ == "__main__":
    main()
