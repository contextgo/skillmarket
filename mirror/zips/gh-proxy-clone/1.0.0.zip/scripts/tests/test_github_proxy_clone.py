#!/usr/bin/env python3
"""Unit tests for github_proxy_clone.py"""

import pytest
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from github_proxy_clone import (
    normalize_repo,
    normalize_raw_input,
    choose_nodes,
    build_archive_source,
    default_archive_output,
    build_clone_payload,
    proxy_url,
)
from config import Config, Node


class TestNormalizeRepo:
    """Tests for normalize_repo function."""

    def test_owner_repo_format(self):
        owner, name, git_url = normalize_repo("owner/repo")
        assert owner == "owner"
        assert name == "repo"
        assert git_url == "https://github.com/owner/repo.git"

    def test_owner_repo_with_git_suffix(self):
        owner, name, git_url = normalize_repo("owner/repo.git")
        assert owner == "owner"
        assert name == "repo"
        assert git_url == "https://github.com/owner/repo.git"

    def test_https_github_url(self):
        owner, name, git_url = normalize_repo("https://github.com/owner/repo")
        assert owner == "owner"
        assert name == "repo"

    def test_https_github_url_with_git(self):
        owner, name, git_url = normalize_repo("https://github.com/owner/repo.git")
        assert owner == "owner"
        assert name == "repo"

    def test_https_github_url_with_trailing_slash(self):
        owner, name, git_url = normalize_repo("https://github.com/owner/repo/")
        assert owner == "owner"
        assert name == "repo"

    def test_empty_repo_raises(self):
        with pytest.raises(ValueError, match="empty repo"):
            normalize_repo("")

    def test_whitespace_repo(self):
        owner, name, git_url = normalize_repo("  owner/repo  ")
        assert owner == "owner"
        assert name == "repo"

    def test_invalid_format_raises(self):
        with pytest.raises(ValueError, match="unsupported repo format"):
            normalize_repo("invalid")

    def test_invalid_url_raises(self):
        with pytest.raises(ValueError, match="unsupported GitHub repo URL"):
            normalize_repo("https://gitlab.com/owner/repo")


class TestNormalizeRawInput:
    """Tests for normalize_raw_input function."""

    def test_raw_url_parsing(self):
        info = normalize_raw_input(
            raw_url="https://raw.githubusercontent.com/owner/repo/main/README.md",
            repo=None,
            raw_path=None,
            ref=None
        )
        assert info.owner == "owner"
        assert info.repo == "repo"
        assert info.ref == "main"
        assert info.path == "README.md"

    def test_raw_url_with_branch(self):
        info = normalize_raw_input(
            raw_url="https://raw.githubusercontent.com/owner/repo/develop/src/index.ts",
            repo=None,
            raw_path=None,
            ref=None
        )
        assert info.ref == "develop"
        assert info.path == "src/index.ts"

    def test_raw_url_invalid_format(self):
        with pytest.raises(ValueError, match="unsupported raw URL"):
            normalize_raw_input(
                raw_url="https://invalid.com/owner/repo/main/file",
                repo=None,
                raw_path=None,
                ref=None
            )

    def test_repo_and_path_requires_ref_or_api(self):
        """When repo+path given but no ref, requires API call (mocked)."""
        # This will fail without network, but validates the error path
        with pytest.raises(Exception):  # Could be ValueError or RuntimeError
            normalize_raw_input(
                raw_url=None,
                repo="owner/repo",
                raw_path="README.md",
                ref=None
            )

    def test_repo_and_path_with_ref(self):
        info = normalize_raw_input(
            raw_url=None,
            repo="owner/repo",
            raw_path="README.md",
            ref="main"
        )
        assert info.owner == "owner"
        assert info.repo == "repo"
        assert info.ref == "main"
        assert info.path == "README.md"
        assert "raw.githubusercontent.com" in info.normalized_raw

    def test_raw_path_with_leading_slash_stripped(self):
        info = normalize_raw_input(
            raw_url=None,
            repo="owner/repo",
            raw_path="/README.md",
            ref="main"
        )
        assert info.path == "README.md"

    def test_missing_repo_raises(self):
        with pytest.raises(ValueError, match="raw mode requires"):
            normalize_raw_input(
                raw_url=None,
                repo=None,
                raw_path="README.md",
                ref="main"
            )

    def test_missing_raw_path_raises(self):
        with pytest.raises(ValueError, match="raw mode requires"):
            normalize_raw_input(
                raw_url=None,
                repo="owner/repo",
                raw_path=None,
                ref="main"
            )


class TestChooseNodes:
    """Tests for choose_nodes function."""

    def test_empty_nodes(self):
        recommended, all_ordered = choose_nodes([], top=3)
        assert recommended == []
        assert all_ordered == []

    def test_single_node(self):
        nodes = [Node(host="node1.com", latency=100, speed=10.0)]
        recommended, all_ordered = choose_nodes(nodes, top=3)
        assert len(recommended) == 1
        assert recommended[0].host == "node1.com"

    def test_deduplication_by_host(self):
        """Same host should appear only once with best latency/speed."""
        nodes = [
            Node(host="node1.com", latency=100, speed=10.0),
            Node(host="node1.com", latency=50, speed=5.0),  # Better latency
            Node(host="node2.com", latency=100, speed=10.0),
        ]
        recommended, all_ordered = choose_nodes(nodes, top=3)
        hosts = [n.host for n in recommended]
        assert hosts.count("node1.com") == 1
        # Should pick the lower latency one
        node1 = next(n for n in recommended if n.host == "node1.com")
        assert node1.latency == 50

    def test_sort_by_latency_then_speed(self):
        nodes = [
            Node(host="slow.com", latency=500, speed=100.0),
            Node(host="fast.com", latency=50, speed=10.0),
            Node(host="medium.com", latency=200, speed=200.0),  # Faster but higher latency
        ]
        recommended, all_ordered = choose_nodes(nodes, top=3)
        assert recommended[0].host == "fast.com"
        assert recommended[1].host == "medium.com"
        assert recommended[2].host == "slow.com"

    def test_top_k_limit(self):
        nodes = [
            Node(host=f"node{i}.com", latency=i * 10, speed=10.0)
            for i in range(10)
        ]
        recommended, all_ordered = choose_nodes(nodes, top=3)
        assert len(recommended) == 3
        # All ordered should have all 10
        assert len(all_ordered) == 10

    def test_alphabetical_tiebreaker(self):
        """Same latency and speed should be sorted alphabetically."""
        nodes = [
            Node(host="zebra.com", latency=100, speed=10.0),
            Node(host="alpha.com", latency=100, speed=10.0),
        ]
        recommended, all_ordered = choose_nodes(nodes, top=2)
        assert recommended[0].host == "alpha.com"
        assert recommended[1].host == "zebra.com"


class TestBuildArchiveSource:
    """Tests for build_archive_source function."""

    def test_branch_archive(self):
        url = build_archive_source("owner", "repo", "main", "branch", "zip")
        assert url == "https://github.com/owner/repo/archive/refs/heads/main.zip"

    def test_branch_archive_tar_gz(self):
        url = build_archive_source("owner", "repo", "main", "branch", "tar.gz")
        assert url == "https://github.com/owner/repo/archive/refs/heads/main.tar.gz"

    def test_tgz_converted_to_tar_gz(self):
        url = build_archive_source("owner", "repo", "main", "branch", "tgz")
        assert url == "https://github.com/owner/repo/archive/refs/heads/main.tar.gz"

    def test_tag_archive(self):
        url = build_archive_source("owner", "repo", "v1.0.0", "tag", "zip")
        assert url == "https://github.com/owner/repo/archive/refs/tags/v1.0.0.zip"

    def test_commit_archive(self):
        url = build_archive_source("owner", "repo", "abc123", "commit", "zip")
        assert url == "https://github.com/owner/repo/archive/abc123.zip"

    def test_auto_defaults_to_branch(self):
        url = build_archive_source("owner", "repo", "main", "auto", "zip")
        assert "refs/heads/main" in url

    def test_invalid_archive_kind_raises(self):
        with pytest.raises(ValueError, match="unsupported archive kind"):
            build_archive_source("owner", "repo", "main", "invalid", "zip")


class TestDefaultArchiveOutput:
    """Tests for default_archive_output function."""

    def test_zip_format(self):
        result = default_archive_output("repo", "main", "zip")
        assert result == "repo-main.zip"

    def test_tar_gz_format(self):
        result = default_archive_output("repo", "v1.0", "tar.gz")
        assert result == "repo-v1.0.tar.gz"

    def test_tgz_preserved(self):
        """default_archive_output preserves format (tgz not converted to tar.gz)."""
        result = default_archive_output("repo", "v1.0", "tgz")
        assert result == "repo-v1.0.tgz"


class TestProxyUrl:
    """Tests for proxy_url function."""

    def test_proxy_url_construction(self):
        result = proxy_url("proxy.com", "https://github.com/owner/repo.git")
        assert result == "https://proxy.com/https://github.com/owner/repo.git"


class TestBuildClonePayload:
    """Tests for build_clone_payload function."""

    def test_basic_clone(self):
        config = Config()
        payload = build_clone_payload(
            best_host="proxy.com",
            owner="owner",
            repo="repo",
            normalized_repo="https://github.com/owner/repo.git",
            dest=None,
            config=config
        )
        assert payload.kind == "clone"
        assert "proxy.com" in payload.proxy_url
        assert "owner/repo.git" in payload.source_url
        assert "git" in payload.command[0]

    def test_clone_with_custom_dest(self):
        config = Config()
        payload = build_clone_payload(
            best_host="proxy.com",
            owner="owner",
            repo="repo",
            normalized_repo="https://github.com/owner/repo.git",
            dest="/custom/path",
            config=config
        )
        assert "/custom/path" in payload.output


class TestConfig:
    """Tests for Config class."""

    def test_default_config(self):
        config = Config()
        assert "api.github.com" in config.github_api_bases[0]
        assert len(config.fallback_hosts) == 2

    def test_config_from_env_overrides_api_url(self, monkeypatch):
        monkeypatch.setenv("GHPROXY_API_URL", "https://custom.api.com/github")
        from config import reset_config, get_config
        reset_config()
        config = get_config()
        assert config.api_url == "https://custom.api.com/github"

    def test_config_from_env_overrides_github_api_bases(self, monkeypatch):
        monkeypatch.setenv("GHPROXY_GITHUB_API_BASES", "https://custom.ghapi.com,https://fallback.com")
        from config import reset_config, get_config
        reset_config()
        config = get_config()
        assert config.github_api_bases == ["https://custom.ghapi.com", "https://fallback.com"]

    def test_config_from_env_overrides_fallback_hosts(self, monkeypatch):
        monkeypatch.setenv("GHPROXY_FALLBACK_HOSTS", "host1.com,host2.com")
        from config import reset_config, get_config
        reset_config()
        config = get_config()
        assert len(config.fallback_hosts) == 2
        assert config.fallback_hosts[0].host == "host1.com"

    def test_resolve_output_path_blocks_path_traversal(self):
        """Path traversal attempts should raise ValueError."""
        config = Config()
        with pytest.raises(ValueError, match="Path traversal not allowed"):
            config.resolve_output_path("../../../etc/passwd", "file")


class TestNodeFromDict:
    """Tests for Node.from_dict method."""

    def test_full_dict(self):
        data = {
            "url": "https://node.com/proxy",
            "latency": "100",
            "speed": "50.5",
            "tag": "fast",
            "location": "US",
            "server": "main"
        }
        node = Node.from_dict(data)
        assert node.host == "node.com"
        assert node.latency == 100
        assert node.speed == 50.5
        assert node.tag == "fast"

    def test_missing_fields(self):
        data = {"url": "https://node.com/proxy"}
        node = Node.from_dict(data)
        assert node.host == "node.com"
        assert node.latency == 999999
        assert node.speed == 0.0

    def test_invalid_latency(self):
        data = {"url": "https://node.com", "latency": "not-a-number"}
        node = Node.from_dict(data)
        assert node.latency == 999999

    def test_invalid_speed(self):
        data = {"url": "https://node.com", "speed": "also-invalid"}
        node = Node.from_dict(data)
        assert node.speed == 0.0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
