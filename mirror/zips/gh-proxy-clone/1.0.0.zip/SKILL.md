---
name: github-proxy-clone
description: 为国内网络环境下的 GitHub 下载提供代理加速。适用于用户要求下载 GitHub 仓库、生成 git clone 加速命令、下载 zip/archive、下载 raw 文件、查看或下载 releases 资产、以及优先选择低延迟代理节点的场景。会通过 github.akams.cn 对应的 API 获取代理节点列表，优先按低延迟、高速度排序，再构造代理下载 URL 或命令。
---

# GitHub Proxy Clone

## Overview

这个 skill 用来处理 **GitHub 下载/克隆加速**，尤其适合中国大陆网络环境下需要经过代理节点访问 GitHub 的情况。

支持四类任务：
- **clone**：生成或执行 `git clone` 加速命令
- **archive**：下载仓库归档包（zip / tar.gz）
- **raw**：下载仓库中的单个原始文件
- **releases**：查看 release 资产列表，或下载某个 release asset

## When to use

当用户出现以下意图时使用：
- "帮我下载这个 GitHub 项目"
- "给我一个 GitHub 加速 clone 命令"
- "下载这个仓库的 zip 包 / archive"
- "把这个仓库的 README/raw 文件下下来"
- "帮我下载 GitHub release 里的某个文件"
- "优先选延迟低的 GitHub proxy 节点"

## Quick workflow

1. 先判断用户要的是：`clone` / `archive` / `raw` / `releases`
2. 优先使用 `scripts/github_proxy_clone.py`
3. 默认先返回命令或代理 URL；只有在用户明确要求时才实际执行下载
4. 节点优先级：
   - 更低 `latency`
   - 同延迟下更高 `speed`

## Supported modes

### 1) Clone

```bash
python3 skills/github-proxy-clone/scripts/github_proxy_clone.py --repo owner/repo --mode clone
```

### 2) Archive

支持下载：
- 分支 archive
- tag archive
- commit archive
- zip / tar.gz

示例：

```bash
# 默认分支 zip
python3 skills/github-proxy-clone/scripts/github_proxy_clone.py --repo owner/repo --mode archive

# 指定分支
python3 skills/github-proxy-clone/scripts/github_proxy_clone.py --repo owner/repo --mode archive --ref main --archive-kind branch --format zip

# 指定 tag
python3 skills/github-proxy-clone/scripts/github_proxy_clone.py --repo owner/repo --mode archive --ref v1.0.0 --archive-kind tag --format tar.gz
```

### 3) Raw

支持两种输入：
- 直接给 `raw.githubusercontent.com` URL
- 给 repo + 文件路径

示例：

```bash
# repo + path
python3 skills/github-proxy-clone/scripts/github_proxy_clone.py --mode raw --repo owner/repo --raw-path README.md

# 指定分支
python3 skills/github-proxy-clone/scripts/github_proxy_clone.py --mode raw --repo owner/repo --ref main --raw-path README.md

# 直接 raw URL
python3 skills/github-proxy-clone/scripts/github_proxy_clone.py --mode raw --raw-url https://raw.githubusercontent.com/owner/repo/main/README.md
```

### 4) Releases

支持：
- 查看最新 release 或指定 tag 的资产列表
- 下载指定 asset

示例：

```bash
# 查看最新 release 资产
python3 skills/github-proxy-clone/scripts/github_proxy_clone.py --repo owner/repo --mode releases

# 查看指定 tag
python3 skills/github-proxy-clone/scripts/github_proxy_clone.py --repo owner/repo --mode releases --tag v1.0.0

# 下载指定 asset
python3 skills/github-proxy-clone/scripts/github_proxy_clone.py --repo owner/repo --mode releases --tag v1.0.0 --asset app-linux-amd64.tar.gz
```

## Environment variables

可通过环境变量覆盖默认配置：

| Variable | Description | Default |
|----------|-------------|---------|
| `GHPROXY_API_URL` | 代理节点 API 端点 | `https://api.akams.cn/github` |
| `GHPROXY_GITHUB_API_BASES` | GitHub API 备用地址（逗号分隔） | `https://api.github.com,https://ghfile.geekertao.top/https://api.github.com` |
| `GHPROXY_OUTPUT_DIR` | 默认输出目录 | `~/tmp/github_project` (Linux/macOS) 或 `%TEMP%\github_project` (Windows) |
| `GHPROXY_FALLBACK_HOSTS` | 备用代理主机（逗号分隔） | `gh.llkk.cc,gh.felicity.ac.cn` |

## Input normalization

### Repo inputs
支持：
- `https://github.com/owner/repo`
- `https://github.com/owner/repo.git`
- `owner/repo`

### Raw inputs
支持：
- `https://raw.githubusercontent.com/owner/repo/ref/path/to/file`
- `--repo owner/repo --ref main --raw-path path/to/file`

## Safety / behavior

- **默认不要直接执行下载**，除非用户明确要求
- 默认输出目录是 `~/tmp/github_project`
- clone 默认会克隆到 `~/tmp/github_project/<repo>`
- archive / raw / release asset 默认会下载到 `~/tmp/github_project/`
- 如果用户传入 `--dest`，则优先使用用户指定路径
- release 列表模式不能直接执行；只有指定 `--asset` 才能下载
- 如果 repo / raw 路径 / asset 名称不明确，先澄清，不要猜

## Troubleshooting

### 节点 API 失败

退化到 `gh.llkk.cc` 和 `gh.felicity.ac.cn`。

### GitHub API 失败

脚本会轮询多个 API base；如果都失败，再提示用户换节点或稍后重试。

### release asset 找不到

先列出 assets，让用户从列表里选具体文件名。

## File structure

```
github-proxy-clone/
├── SKILL.md                    # This file
├── scripts/
│   ├── github_proxy_clone.py    # Main script
│   └── config.py                # Configuration management
└── references/
    └── proxy-patterns.md       # Technical reference
```
