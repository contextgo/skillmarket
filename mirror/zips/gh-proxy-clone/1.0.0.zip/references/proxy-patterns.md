# Proxy patterns

## 数据源

- 页面：`https://github.akams.cn/`
- 节点 API：`https://api.akams.cn/github`
- GitHub API 备用：
  - `https://api.github.com`
  - `https://ghfile.geekertao.top/https://api.github.com`

## 代理 URL 拼接规则

统一规则：

```text
https://<节点host>/<原始GitHubURL>
```

## 1) Clone

```text
git clone https://<节点host>/https://github.com/<owner>/<repo>.git
```

## 2) Archive

### 分支
```text
https://<节点host>/https://github.com/<owner>/<repo>/archive/refs/heads/<ref>.zip
https://<节点host>/https://github.com/<owner>/<repo>/archive/refs/heads/<ref>.tar.gz
```

### Tag
```text
https://<节点host>/https://github.com/<owner>/<repo>/archive/refs/tags/<tag>.zip
```

### Commit
```text
https://<节点host>/https://github.com/<owner>/<repo>/archive/<commit>.zip
```

## 3) Raw

```text
https://<节点host>/https://raw.githubusercontent.com/<owner>/<repo>/<ref>/<path>
```

## 4) Releases asset

```text
https://<节点host>/https://github.com/<owner>/<repo>/releases/download/<tag>/<asset>
```

## 默认排序规则

1. `latency` 更低优先
2. 同延迟下 `speed` 更高优先
3. 同分时按 host 字母序稳定输出

## 回退规则

如果 `https://api.akams.cn/github` 不可用，回退到：
- `gh.llkk.cc`
- `gh.felicity.ac.cn`

## 适用边界

这个 skill 主要处理：
- GitHub 仓库 clone
- 仓库归档下载
- raw 文件下载
- release 资产查看/下载
- 给用户生成可复制命令

不负责：
- 私有仓库认证绕过
- SSH key 配置
- 企业代理/堡垒机配置
