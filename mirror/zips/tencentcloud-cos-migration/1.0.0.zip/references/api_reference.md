# MSP 迁移服务平台 API 参考

本文档提供腾讯云 MSP 迁移服务平台的 API 参考信息。

## 官方文档

| 资源 | 链接 |
|------|------|
| MSP 产品文档 | https://cloud.tencent.com/document/product/659 |
| 阿里云 OSS 迁移指南 | https://cloud.tencent.com/document/product/659/81171 |
| 半托管迁移 Agent | https://cloud.tencent.com/document/product/659/81158 |
| COS Migration 工具 | https://cloud.tencent.com/document/product/436/15392 |
| 预估迁移时间 | https://cloud.tencent.com/document/product/436/32976 |

## MSP 控制台

- **控制台入口**：https://console.cloud.tencent.com/msp
- **对象存储迁移**：https://console.cloud.tencent.com/msp/migration/object

## 迁移模式对比

### 全托管迁移

| 特性 | 说明 |
|------|------|
| 工作原理 | MSP 通过公网从源端拉取数据 |
| 适用场景 | 中小规模数据、源端可公网访问 |
| 优点 | 无需部署 Agent、配置简单 |
| 限制 | 依赖公网带宽 |

### 半托管迁移（Agent）

| 特性 | 说明 |
|------|------|
| 工作原理 | 在源端部署 Agent 推送数据 |
| 适用场景 | 大规模数据、专线/VPN 场景 |
| 优点 | 可控带宽、支持专线加速 |
| 要求 | 需要在源端服务器部署 Agent |

**半托管模式必需参数：**

| 参数 | 类型 | 说明                                             |
|------|------|------------------------------------------------|
| ListerIp | string | Agent 服务器 IP 地址（如 10.1.4.4）                    |
| EndPoint | string | 源端访问地址（如 oss-cn-beijing-internal.aliyuncs.com） |

**配置示例：**

```json
{
  "Mode": 1,
  "ListerIp": "10.1.4.4",
  "EndPoint": "oss-cn-beijing.aliyuncs.com"
}
```

### 定时迁移

| 特性 | 说明 |
|------|------|
| 工作原理 | 按 Cron 规则重复执行迁移任务 |
| 适用场景 | 增量数据同步、持续迁移 |
| 优点 | 自动化、支持增量同步 |
| 配置 | 支持固定间隔和 Cron 表达式 |

## 源端配置参数

### 阿里云 OSS

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| SrcService | string | 是 | OSS | 固定值：`OSS` |
| SrcBucket | string | 是 | - | 源存储桶名称 |
| SrcRegion | string | 否 | - | 源区域（如 oss-cn-hangzhou） |
| ManifestURL | string | 否 | - | 清单文件 URL |
| MigrationHeaderType | int | 是 | 1 | Header 迁移方式：1=保留全部，2=丢弃全部，3=自定义替换 |
| MigrationHeader | array | 否 | [] | Header 替换规则（MigrationHeaderType=3 时必需） |
| MigrationRuleType | int | 是 | 1 | 文件名过滤：1=不过滤，2=前缀匹配，3=正则匹配 |
| MigrationRule | array | 否 | [] | 过滤规则内容（MigrationRuleType=2/3 时必需） |
| HasFileTime | int | 是 | 0 | 是否启用时间过滤：0=否，1=是 |
| FileStartTime | string | 否 | - | 开始时间（HasFileTime=1 时必需） |
| FileEndTime | string | 否 | - | 结束时间（HasFileTime=1 时必需） |
| SpeedLimitInfo | object | 否 | - | 限速配置（JSON 格式） |

### 区域代码对照表

| 阿里云区域 | 代码 |
|-----------|------|
| 华东1（杭州） | oss-cn-hangzhou |
| 华东2（上海） | oss-cn-shanghai |
| 华北1（青岛） | oss-cn-qingdao |
| 华北2（北京） | oss-cn-beijing |
| 华北3（张家口） | oss-cn-zhangjiakou |
| 华南1（深圳） | oss-cn-shenzhen |
| 华南2（河源） | oss-cn-heyuan |
| 西南1（成都） | oss-cn-chengdu |
| 中国香港 | oss-cn-hongkong |

## 目标端配置参数

### 腾讯云 COS

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| DstService | string | 是 | COS | 固定值：`COS` |
| DstBucket | string | 是 | - | 目标存储桶（格式：name-appid）|
| SaveType | int | 是 | 0 | 保存类型：0=根目录，1=指定目录 |
| SavePath | string | 否 | - | 保存目录（SaveType=1 时必需）|
| FileOverwrite | int | 是 | 1 | 同名文件处理：0=覆盖，1=跳过 |
| StorageType | int | 是 | 3 | 存储类型：1=标准，2=低频，3=保持原属性，4=归档，5=智能分层，6=冷存储 |
| Mode | int | 是 | 0 | Agent 模式：0=全托管，1=半托管 |
| ListerIp | string | 条件 | - | Lister IP（Mode=1 时必需）|
| EndPoint | string | 条件 | - | 源端 Endpoint（Mode=1 时必需）|

### 区域代码对照表

| 腾讯云区域 | 代码 |
|-----------|------|
| 广州 | ap-guangzhou |
| 上海 | ap-shanghai |
| 北京 | ap-beijing |
| 成都 | ap-chengdu |
| 重庆 | ap-chongqing |
| 深圳 | ap-shenzhen |
| 南京 | ap-nanjing |
| 中国香港 | ap-hongkong |

## 同名文件处理策略

| 策略 | 行为 |
|------|------|
| **覆盖** | 直接覆盖同名文件 |
| **跳过（基于 LastModified）** | 若源文件 LastModified >= 目标文件，则覆盖；否则跳过 |

## 任务状态

| 状态 | 颜色 | 说明 |
|------|------|------|
| 待执行 | 灰色 | 任务已创建，等待执行 |
| 执行中 | 蓝色 | 正在迁移数据 |
| 任务完成 | 绿色 | 全部文件迁移成功 |
| 任务完成（部分失败） | 黄色 | 部分文件迁移失败 |
| 任务失败 | 红色 | 任务执行失败 |

## 错误处理

### 常见错误

| 错误 | 原因 | 解决方案 |
|------|------|----------|
| 权限不足 | RAM/CAM 策略配置错误 | 检查子账号权限配置 |
| 网络超时 | 网络不稳定或带宽限制 | 调整执行速度设置 |
| 桶不存在 | 桶名称或区域错误 | 确认桶名称和区域代码 |
| 凭证过期 | STS 临时凭证过期 | 刷新临时凭证 |

### 重试机制

- 在控制台单击「重试失败任务」重新迁移失败的文件
- 已成功迁移的文件不会重传
- 可导出失败文件列表进行分析

## 迁移时间预估

```
迁移时间 ≈ 数据总量 / (有效带宽 × 并发数)
```

### 影响因素

1. **源端带宽**：阿里云 OSS 出口带宽限制
2. **网络延迟**：跨云公网传输延迟
3. **目标端写入**：COS 写入 QPS 和带宽
4. **文件特征**：小文件多则 HTTP 请求开销大

### 优化建议

- 在业务低峰期执行迁移
- 使用半托管 Agent 模式（专线场景）
- 大文件迁移时适当降低并发数
- 增量迁移使用定时任务模式

## 费用说明

### 阿里云（源端）

| 费用类型 | 说明 |
|----------|------|
| 流出流量费 | 数据从 OSS 流出产生费用 |
| API 请求费 | List/Get 等请求费用 |

### 腾讯云（目标端）

| 费用类型 | 说明 |
|----------|------|
| 存储费用 | 数据存储在 COS 产生费用 |
| 请求费用 | PUT/GET 等请求费用 |
| MSP 服务费 | **免费**（仅收取底层资源费用）|

> 💡 **省钱技巧**：选择同区域的 OSS/COS 减少公网流量费用
