# 迁移配置模板

本文档提供 MSP 迁移任务的配置模板，用于快速创建迁移任务。

## 控制台配置模板

### 基本信息

```yaml
任务名称: aliyun-oss-to-cos-migration-001
预估规模: 1000  # GB
```

### 源端配置（阿里云 OSS）

```yaml
服务提供商: aliyun
AccessKey: <阿里云 AccessKeyID>
SecretKey: <阿里云 AccessKeySecret>
区域: oss-cn-hangzhou
迁移桶名称: my-source-bucket
Header 迁移方式: 保留  # 保留 | 替换
文件名过滤规则: 全部文件  # 全部文件 | 指定前缀
前缀过滤: ""  # 如 "images/" 仅迁移 images 目录下的文件
时间范围:
  启用: false
  开始时间: ""
  结束时间: ""
执行速度: 100  # Mbps
限速方式: 按任务限速
```

### 目标端配置（腾讯云 COS）

```yaml
服务提供商: tencent
SecretId: <腾讯云 SecretId>
SecretKey: <腾讯云 SecretKey>
区域: ap-guangzhou
迁移桶名称: my-target-bucket-1250000000  # 格式：name-appid
保存路径:
  类型: 保存到根目录  # 保存到根目录 | 保存到指定目录
  目录: ""  # 如 "migrated/" 则文件保存到 migrated/ 目录下
同名文件: 跳过  # 覆盖 | 跳过（基于 LastModified 判断）
文件存储方式: 保持原存储属性  # 标准存储 | 低频存储 | 归档存储 | 保持原存储属性
```

### 迁移模式

```yaml
模式: 全托管迁移  # 全托管迁移 | 半托管迁移(Agent) | 定时迁移
```

#### 半托管迁移配置（Agent 模式）

当选择半托管迁移模式时，需要额外配置以下参数：

```yaml
模式: 半托管迁移
ListerIp: 10.6.8.5  # Agent 服务器 IP 地址（必需）
EndPoint: oss-cn-beijing.aliyuncs.com  # 源端 Endpoint（必需）
```

**半托管模式说明：**
- 适用于大规模数据迁移或专线/VPN 场景
- 需要在源端服务器部署 MSP Agent
- ListerIp: Agent 服务器的 IP 地址，用于接收迁移指令
- EndPoint: 源端存储服务的访问端点，通常使用内网地址

**常用 EndPoint 示例：**
- 阿里云 OSS 内网：`oss-cn-beijing-internal.aliyuncs.com`
- 阿里云 OSS 公网：`oss-cn-beijing.aliyuncs.com`

#### 定时迁移配置（仅定时模式）

```yaml
定时类型: 按小时间隔  # 按小时间隔 | 按天间隔 | Cron 表达式
间隔: 1  # 小时
重复次数: 3  # 执行 3 次
```

## COS Migration 工具配置模板

### config.ini

```ini
[common]
workspace = ./workspace
# 日志级别: info, debug, error
log_level = info
# 并发数
small_file_executor = 64
big_file_executor = 8

[source]
type = aliyun
# 阿里云 OSS 凭证
access_key_id = <AccessKeyId>
access_key_secret = <AccessKeySecret>
# 源桶配置
bucket = my-source-bucket
region = oss-cn-hangzhou
# 可选：仅迁移指定前缀
prefix =
# 可选：跳过指定后缀
# suffix = .bak

[dest]
type = cos
# 腾讯云 COS 凭证
access_key_id = <SecretId>
access_key_secret = <SecretKey>
# 目标桶配置
bucket = my-target-bucket-1250000000
region = ap-guangzhou
# 可选：保存到指定目录
prefix =
```

## 权限策略模板

### 阿里云 RAM 策略（最小权限）

```json
{
  "Version": "1",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "oss:ListBuckets",
        "oss:GetBucketAcl",
        "oss:GetBucketLocation",
        "oss:GetBucketInfo",
        "oss:GetBucketTagging",
        "oss:GetBucketEncryption"
      ],
      "Resource": [
        "acs:oss:*:*:*"
      ]
    },
    {
      "Effect": "Allow",
      "Action": [
        "oss:ListObjects",
        "oss:GetObject",
        "oss:GetObjectAcl",
        "oss:GetObjectTagging",
        "oss:GetObjectMeta"
      ],
      "Resource": [
        "acs:oss:*:*:<源桶名称>",
        "acs:oss:*:*:<源桶名称>/*"
      ]
    }
  ]
}
```

### 腾讯云 CAM 策略（最小权限）

```json
{
  "version": "2.0",
  "statement": [
    {
      "effect": "allow",
      "action": [
        "msp:*"
      ],
      "resource": [
        "*"
      ]
    },
    {
      "effect": "allow",
      "action": [
        "cos:*"
      ],
      "resource": [
        "qcs::cos:<Region>::uid/<APPID>:<目标桶名称>",
        "qcs::cos:<Region>::uid/<APPID>:<目标桶名称>/*"
      ]
    }
  ]
}
```

## 迁移前检查清单

### 源端检查

- [ ] RAM 子账号已创建
- [ ] RAM 策略已配置（仅 OSS 读取权限）
- [ ] AccessKey 已获取
- [ ] 源桶名称和区域已确认
- [ ] 源桶数据量已统计

### 目标端检查

- [ ] CAM 子账号已创建
- [ ] CAM 策略已配置（MSP + COS 权限）
- [ ] SecretId/SecretKey 已获取
- [ ] 目标桶已创建
- [ ] 目标桶名称和区域已确认
- [ ] 目标桶存储类型已设置

### 网络检查

- [ ] 源端可公网访问（全托管模式）
- [ ] 带宽限制已确认

#### 半托管模式额外检查

- [ ] 专线/VPN 已配置
- [ ] Agent 已部署到源端服务器
- [ ] ListerIp 已配置（Agent 服务器 IP）
- [ ] EndPoint 已配置（源端内网地址）
- [ ] 源端服务器到 COS 网络连通性已验证

### 时间规划

- [ ] 迁移窗口已确定（业务低峰期）
- [ ] 预估迁移时间已计算
- [ ] 回滚方案已准备
