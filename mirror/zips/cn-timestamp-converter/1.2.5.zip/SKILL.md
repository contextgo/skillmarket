---
slug: cn-timestamp-converter
name: 时间戳转换器
version: "1.2.1"
author: 千策
---

# 时间戳转换器

Unix时间戳与日期互转。开发调试必备。

## 功能

- **时间戳→日期**：将Unix时间戳转为可读日期
- **日期→时间戳**：将日期字符串转为时间戳
- **秒/毫秒自动识别**：10位秒级 vs 13位毫秒级
- **时区支持**：UTC/Asia-Shanghai等常用时区
- **当前时间戳**：快速获取当前时间戳
- **相对时间**：「3小时后」「明天」等自然语言

## 安装要求

- Python 3.6+
- 无外部依赖

## 使用方法

```bash
# 时间戳转日期
python3 scripts/timestamp_converter.py "1745800000"

# 日期转时间戳
python3 scripts/timestamp_converter.py "2026-04-29 12:00:00"

# 当前时间戳
python3 scripts/timestamp_converter.py "now"
```

## 示例

输入：`1745800000`
输出：`2025-04-28 07:46:40 (UTC) / 2025-04-28 15:46:40 (CST)`

## 分类

开发工具

## 关键词

时间戳, timestamp, 日期转换, 时区, datetime
