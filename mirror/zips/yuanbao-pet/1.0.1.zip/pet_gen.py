#!/usr/bin/env python3
"""
电子宠物系统 Pet — 核心脚本
确定性分配 + RPG 属性 + 互动 + 对战 + 衰减

用法:
  python pet_gen.py <user_id> --adopt            # 领养宠物
  python pet_gen.py <user_id> --action <指令>     # 互动
  python pet_gen.py <user_id1> --battle <user_id2> # 对战
  python pet_gen.py --leaderboard                 # 排行榜
"""

import json
import sys
import hashlib
import time
import random
import os

# ===== Windows UTF-8 =====
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8")

# ===== 确定性 PRNG =====

SALT = "xiaobai-xxp-2025"
PETS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "pets.json")

def fnv1a(data: bytes) -> int:
    """FNV-1a 32-bit hash"""
    h = 0x811c9dc5
    for b in data:
        h ^= b
        h = (h * 0x01000193) & 0xFFFFFFFF
    return h

def mulberry32(seed: int):
    """Mulberry32 PRNG generator"""
    while True:
        seed = (seed + 0x60D2BFE) & 0xFFFFFFFF
        t = seed
        t = (t ^ (t >> 15)) * 0x1E35A7BD & 0xFFFFFFFF
        t = (t ^ (t >> 15)) * 0x1E35A7BD & 0xFFFFFFFF
        t = (t ^ (t >> 15)) & 0xFFFFFFFF
        yield t / 0xFFFFFFFF

def get_prng(user_id: str):
    """获取用户的确定性 PRNG"""
    data = f"{user_id}:{SALT}".encode("utf-8")
    seed = fnv1a(data)
    return mulberry32(seed)

# ===== 宠物种类定义 =====

SPECIES = [
    # ⭐ 普通 (60%)
    {"name": "虾", "emoji": "🦐", "rarity": "common", "rarity_stars": "⭐", "species_key": "shrimp", "weight": 9},
    {"name": "鱼", "emoji": "🐟", "rarity": "common", "rarity_stars": "⭐", "species_key": "fish", "weight": 9},
    {"name": "螺", "emoji": "🐌", "rarity": "common", "rarity_stars": "⭐", "species_key": "snail", "weight": 7},
    {"name": "龟", "emoji": "🐢", "rarity": "common", "rarity_stars": "⭐", "species_key": "turtle", "weight": 7},
    {"name": "蟹", "emoji": "🦀", "rarity": "common", "rarity_stars": "⭐", "species_key": "crab", "weight": 7},
    {"name": "虫", "emoji": "🐛", "rarity": "common", "rarity_stars": "⭐", "species_key": "bug", "weight": 5},
    {"name": "猫", "emoji": "🐱", "rarity": "common", "rarity_stars": "⭐", "species_key": "cat", "weight": 9},
    {"name": "狗", "emoji": "🐶", "rarity": "common", "rarity_stars": "⭐", "species_key": "dog", "weight": 5},
    {"name": "鼠", "emoji": "🐹", "rarity": "common", "rarity_stars": "⭐", "species_key": "hamster", "weight": 3},
    # ⭐⭐ 稀有 (25%)
    {"name": "狐", "emoji": "🦊", "rarity": "rare", "rarity_stars": "⭐⭐", "species_key": "fox", "weight": 12},
    {"name": "鸮", "emoji": "🦉", "rarity": "rare", "rarity_stars": "⭐⭐", "species_key": "owl", "weight": 8},
    {"name": "兔", "emoji": "🐰", "rarity": "rare", "rarity_stars": "⭐⭐", "species_key": "rabbit", "weight": 5},
    # ⭐⭐⭐ 史诗 (10%)
    {"name": "龙", "emoji": "🐲", "rarity": "epic", "rarity_stars": "⭐⭐⭐", "species_key": "dragon", "weight": 4},
    {"name": "狮", "emoji": "🦁", "rarity": "epic", "rarity_stars": "⭐⭐⭐", "species_key": "lion", "weight": 3},
    {"name": "熊", "emoji": "🐼", "rarity": "epic", "rarity_stars": "⭐⭐⭐", "species_key": "bear", "weight": 3},
    # ⭐⭐⭐⭐ 传说 (4%)
    {"name": "凤", "emoji": "🔥", "rarity": "legendary", "rarity_stars": "⭐⭐⭐⭐", "species_key": "phoenix", "weight": 2},
    {"name": "独角兽", "emoji": "🦄", "rarity": "legendary", "rarity_stars": "⭐⭐⭐⭐", "species_key": "unicorn", "weight": 2},
    # ⭐⭐⭐⭐⭐ 神话 (1%)
    {"name": "鲲", "emoji": "🐾", "rarity": "mythic", "rarity_stars": "⭐⭐⭐⭐⭐", "species_key": "kun", "weight": 1},
    {"name": "虾皇", "emoji": "💎", "rarity": "mythic", "rarity_stars": "⭐⭐⭐⭐⭐", "species_key": "shrimp_king", "weight": 1},
]

# 稀有度中文名
RARITY_NAMES = {
    "common": "普通", "rare": "稀有", "epic": "史诗",
    "legendary": "传说", "mythic": "神话"
}

# 等级定义
LEVEL_THRESHOLDS = [0, 100, 300, 600, 1000]
LEVEL_NAMES = {1: "幼年", 2: "成长期", 3: "成熟期", 4: "觉醒", 5: "传说"}

# ===== 工具函数 =====

def clamp(val, lo=0, hi=100):
    return max(lo, min(hi, val))

def get_level(exp: int) -> int:
    for i in range(len(LEVEL_THRESHOLDS) - 1, -1, -1):
        if exp >= LEVEL_THRESHOLDS[i]:
            return i + 1
    return 1

def load_pets() -> dict:
    """读取 pets.json"""
    try:
        with open(PETS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return {"pets": {}}

def save_pets(data: dict):
    """保存 pets.json"""
    os.makedirs(os.path.dirname(PETS_FILE), exist_ok=True)
    with open(PETS_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

# ===== 属性生成 =====

STAT_KEYS = ["intelligence", "strength", "luck", "charisma", "zen"]
STAT_EMOJIS = {"intelligence": "🧠", "strength": "💪", "luck": "🍀", "charisma": "😎", "zen": "🧘"}

def generate_stats(rng):
    """生成 RPG 五维：1 项巅峰 80-100，1 项低谷 1-25，其余底线~底线+40"""
    stats = {}
    peak = next(rng)
    low = next(rng)

    indices = list(range(5))
    peak_idx = int(peak * 5) % 5
    remaining = [i for i in indices if i != peak_idx]
    low_idx = remaining[int(low * len(remaining)) % len(remaining)]

    for i, name in enumerate(STAT_KEYS):
        if i == peak_idx:
            stats[name] = int(80 + next(rng) * 21)
        elif i == low_idx:
            stats[name] = int(1 + next(rng) * 25)
        else:
            base = int(20 + next(rng) * 20)
            stats[name] = min(100, base + int(next(rng) * 40))

    return stats

def pick_species(rng):
    """根据权重选择宠物种类"""
    total_weight = sum(s["weight"] for s in SPECIES)
    roll = next(rng) * total_weight
    cumulative = 0
    for species in SPECIES:
        cumulative += species["weight"]
        if roll < cumulative:
            return species
    return SPECIES[0]

def check_shiny(rng):
    """1% 闪光概率"""
    return next(rng) < 0.01

def generate_soul(species, stats, rng):
    """生成灵魂：名字 + 性格签名 + 灵魂词"""
    peak_stat = max(STAT_KEYS, key=lambda k: stats[k])
    low_stat = min(STAT_KEYS, key=lambda k: stats[k])

    # 名字池（按稀有度分层）
    name_pools = {
        "common": ["小团子", "豆豆", "圆滚滚", "毛球", "咕噜", "肥肥", "嘟嘟", "球球", "咪咪", "旺财"],
        "rare": ["霜月", "星辰", "暮光", "碧落", "青鸾", "紫烟", "银翼", "风铃"],
        "epic": ["烈焰", "苍穹", "雷霆", "玄冥", "赤霄", "墨渊"],
        "legendary": ["涅槃", "天命", "永恒", "混沌"],
        "mythic": ["道", "始", "终", "无"],
    }

    # 灵魂词池
    soul_word_pools = {
        "common": ["摸鱼", "干饭", "睡觉", "可爱", "发呆"],
        "rare": ["优雅", "神秘", "灵动", "骄傲", "沉默"],
        "epic": ["霸气", "威严", "深不可测", "一击必杀", "不怒自威"],
        "legendary": ["不朽", "超越", "命运", "永恒"],
        "mythic": ["道法", "天地", "虚无", "创世"],
    }

    # 性格签名模板
    sig_templates = [
        "{peak_emoji}是它的强项，{low_emoji}是它的遗憾",
        "以{peak_emoji}行走天下，{low_emoji}只是伪装",
        "{peak_emoji}满点，{low_emoji}欠费",
        "天生{peak_emoji}，{low_emoji}靠边站",
        "{peak_emoji}爆表的存在，{low_emoji}就当没有",
    ]

    pool = name_pools.get(species["rarity"], name_pools["common"])
    name_idx = int(next(rng) * len(pool)) % len(pool)
    name = pool[name_idx]

    # 闪光加 ⚡ 前缀
    shiny = check_shiny(rng)
    if shiny:
        name = f"⚡{name}"

    # 神话/传说加后缀
    if species["rarity"] == "mythic":
        name = f"{name}·{species['name']}王"
    elif species["rarity"] == "legendary":
        name = f"{name}·{species['name']}"

    sig_idx = int(next(rng) * len(sig_templates)) % len(sig_templates)
    signature = sig_templates[sig_idx].format(
        peak_emoji=STAT_EMOJIS[peak_stat],
        low_emoji=STAT_EMOJIS[low_stat]
    )

    # 灵魂词（3个）
    word_pool = soul_word_pools.get(species["rarity"], soul_word_pools["common"])
    words = []
    for _ in range(3):
        idx = int(next(rng) * len(word_pool)) % len(word_pool)
        w = word_pool[idx]
        if w not in words:
            words.append(w)
    while len(words) < 3:
        words.append(word_pool[int(next(rng) * len(word_pool)) % len(word_pool)])

    return {
        "name": name,
        "signature": signature,
        "shiny": shiny,
        "prompt_words": words[:3],
        "personality": signature,
    }

# ===== 领养 =====

def adopt(user_id: str, owner_name: str = "") -> dict:
    """领养宠物"""
    data = load_pets()

    if user_id in data["pets"]:
        return {"error": f"你已经有一只宠物了！", "pet": data["pets"][user_id]}

    rng = get_prng(user_id)
    species = pick_species(rng)
    stats = generate_stats(rng)
    soul = generate_soul(species, stats, rng)

    # hash_id
    hash_data = f"{user_id}:{SALT}:hash".encode("utf-8")
    hash_id = hashlib.md5(hash_data).hexdigest()[:6]

    now = int(time.time())

    pet = {
        "name": soul["name"],
        "species": species["species_key"],
        "species_name": species["name"],
        "species_emoji": species["emoji"],
        "rarity": species["rarity"],
        "rarity_stars": species["rarity_stars"],
        "shiny": soul["shiny"],
        "owner": owner_name or user_id,
        "owner_id": user_id,
        "stats": {
            "hp": 100, "mood": 60, "hunger": 50,
            "exp": 0, "level": 1, "level_name": "幼年",
            "intelligence": stats["intelligence"],
            "strength": stats["strength"],
            "luck": stats["luck"],
            "charisma": stats["charisma"],
            "zen": stats["zen"],
        },
        "soul": {
            "prompt_words": soul["prompt_words"],
            "personality": soul["personality"],
        },
        "hash_id": hash_id,
        "last_decay": now,
        "message_count": 0,
        "adopted_at": now,
        "rename_used": False,
    }

    data["pets"][user_id] = pet
    save_pets(data)

    return {"pet": pet, "event": f"🎉 {soul['name']}（{species['emoji']} {species['name']}）选择了你！"}

# ===== 日常互动 =====

def interact(user_id: str, action: str) -> dict:
    """处理互动指令"""
    data = load_pets()

    if user_id not in data["pets"]:
        return {"error": "你还没有宠物，请先领养！"}

    pet = data["pets"][user_id]
    stats = pet["stats"]
    event = ""
    condition_error = ""

    if action == "feed":
        stats["hunger"] = clamp(stats["hunger"] + 20)
        event = f"{pet['species_emoji']} {pet['name']}开心地吃了一顿！饱食+20"

    elif action == "walk":
        if stats["hunger"] < 15:
            condition_error = f"{pet['name']}太饿了，走不动……（饱食需≥15）"
        else:
            stats["mood"] = clamp(stats["mood"] + 15)
            stats["exp"] += 5
            stats["hunger"] = clamp(stats["hunger"] - 8)
            event = f"{pet['species_emoji']} {pet['name']}出门溜达了一圈！心情+15，成长+5，饱食-8"

    elif action == "play":
        if stats["hunger"] < 5:
            condition_error = f"{pet['name']}太饿了，没力气玩……（饱食需≥5）"
        else:
            stats["mood"] = clamp(stats["mood"] + 10)
            stats["hunger"] = clamp(stats["hunger"] - 5)
            event = f"{pet['species_emoji']} {pet['name']}玩得很开心！心情+10，饱食-5"

    elif action == "train":
        if stats["hunger"] < 20:
            condition_error = f"{pet['name']}太饿了，没法训练……（饱食需≥20）"
        else:
            stats["exp"] += 10
            stats["mood"] = clamp(stats["mood"] - 5)
            # 训练有概率微增属性
            train_stat = STAT_KEYS[int(random.random() * 5)]
            if random.random() < 0.3:
                stats[train_stat] = clamp(stats[train_stat] + 1)
                event = f"{pet['species_emoji']} {pet['name']}刻苦训练！成长+10，心情-5，{STAT_EMOJIS[train_stat]}+1"
            else:
                event = f"{pet['species_emoji']} {pet['name']}刻苦训练！成长+10，心情-5"

    elif action == "sleep":
        stats["hunger"] = clamp(stats["hunger"] + 5)
        stats["mood"] = clamp(stats["mood"] + 10)
        event = f"{pet['species_emoji']} {pet['name']}美美地睡了一觉！饱食+5，心情+10"

    elif action == "pet":
        stats["mood"] = clamp(stats["mood"] + 5)
        bonus = random.random() < 0.3
        if bonus:
            stats["mood"] = clamp(stats["mood"] + 5)
            event = f"{pet['species_emoji']} 摸摸{pet['name']}~它蹭了蹭你！心情+10（贴贴！）"
        else:
            event = f"{pet['species_emoji']} 摸摸{pet['name']}~它眯起了眼睛。心情+5"

    elif action == "rename":
        if pet.get("rename_used"):
            condition_error = f"{pet['name']}已经改过名字了，改名机会只有1次！"
        else:
            # 改名需要 AI 生成新名字，这里只标记状态
            event = f"请告诉{pet['name']}的新名字（≤6字符，限1次）"

    else:
        condition_error = f"未知指令: {action}"

    if condition_error:
        return {"error": condition_error}

    # 更新等级
    level = get_level(stats["exp"])
    stats["level"] = level
    stats["level_name"] = LEVEL_NAMES.get(level, "幼年")

    # 被动事件（5%）
    passive = check_passive_event(pet)

    # 时间衰减
    decay_msg = apply_decay(pet, data)

    pet["last_interaction"] = int(time.time())
    save_pets(data)

    result = {"pet": pet, "event": event}
    if passive:
        result["passive"] = passive
    if decay_msg:
        result["decay"] = decay_msg

    return result

# ===== 被动事件 =====

def check_passive_event(pet: dict) -> str:
    """5% 概率触发被动事件"""
    if random.random() > 0.05:
        return None

    stats = pet["stats"]
    events = [
        ("🎉翻了个跟头", "mood", 5),
        ("😴睡着了", "hunger", 3),
        ("🔍发现了小鱼干", "exp", 3),
        ("🌧️淋雨了", "mood", -5),
        ("👀盯着你看", None, 0),
        ("🥁在敲鼓", "charisma", 1),
    ]

    event = random.choice(events)
    name, attr, delta = event

    if attr:
        if attr == "exp":
            stats[attr] = stats.get(attr, 0) + delta
        else:
            stats[attr] = clamp(stats.get(attr, 50) + delta)

    return f"{pet['species_emoji']} {pet['name']}{name}！" + (f" {STAT_EMOJIS.get(attr, '')}{attr}{'+'if delta>0 else ''}{delta}" if attr and delta else "")

# ===== 时间衰减 =====

def apply_decay(pet: dict, data: dict) -> str:
    """时间衰减：每24h或每30条消息"""
    now = int(time.time())
    last_decay = pet.get("last_decay", now)
    msg_count = pet.get("message_count", 0)

    hours_since = (now - last_decay) / 3600
    triggers = 0
    if hours_since >= 24:
        triggers += int(hours_since / 24)
    if msg_count >= 30:
        triggers += int(msg_count / 30)

    if triggers == 0:
        return None

    # 🧘佛系高减半
    zen = pet["stats"].get("zen", 50)
    zen_factor = 0.5 if zen >= 60 else 1.0

    stats = pet["stats"]
    for _ in range(triggers):
        stats["hunger"] = clamp(stats["hunger"] - int(5 * zen_factor))
        stats["mood"] = clamp(stats["mood"] - int(3 * zen_factor))
        if stats["hunger"] < 10:
            stats["hp"] = clamp(stats["hp"] - 5)

    pet["last_decay"] = now
    pet["message_count"] = msg_count % 30  # 保留余数

    return f"时间流逝……饱食-{int(5*zen_factor*triggers)}，心情-{int(3*zen_factor*triggers)}"

# ===== 对战 =====

def battle(user_id1: str, user_id2: str) -> dict:
    """宠物对战"""
    data = load_pets()

    if user_id1 not in data["pets"]:
        return {"error": f"用户 {user_id1} 还没有宠物"}
    if user_id2 not in data["pets"]:
        return {"error": f"用户 {user_id2} 还没有宠物"}

    pet1 = data["pets"][user_id1]
    pet2 = data["pets"][user_id2]

    if pet1["stats"]["level"] < 2:
        return {"error": f"{pet1['name']}还没到成长期，不能对战！"}
    if pet2["stats"]["level"] < 2:
        return {"error": f"{pet2['name']}还没到成长期，不能对战！"}

    # 胜率 = 力量×0.6 + 运气×0.4
    s1 = pet1["stats"]
    s2 = pet2["stats"]
    score1 = s1["strength"] * 0.6 + s1["luck"] * 0.4
    score2 = s2["strength"] * 0.6 + s2["luck"] * 0.4

    total = score1 + score2
    win_rate1 = score1 / total if total > 0 else 0.5

    # 随机判定（运气可爆冷）
    roll = random.random()
    winner = pet1 if roll < win_rate1 else pet2
    loser = pet2 if winner is pet1 else pet1

    # 胜方成长+10，败方+3
    winner["stats"]["exp"] += 10
    loser["stats"]["exp"] += 3

    # 更新等级
    for p in [winner, loser]:
        level = get_level(p["stats"]["exp"])
        p["stats"]["level"] = level
        p["stats"]["level_name"] = LEVEL_NAMES.get(level, "幼年")

    save_pets(data)

    return {
        "winner": winner["name"],
        "loser": loser["name"],
        "win_rate": f"{win_rate1:.0%} vs {1-win_rate1:.0%}",
        "report": (
            f"⚔️ {pet1['name']} VS {pet2['name']}\n"
            f"胜率: {win_rate1:.0%} vs {1-win_rate1:.0%}\n"
            f"🏆 {winner['name']} 获胜！成长+10\n"
            f"💪 {loser['name']} 虽败犹荣，成长+3"
        )
    }

# ===== 排行榜 =====

def leaderboard() -> dict:
    """宠物图鉴/排行榜"""
    data = load_pets()
    pets = data.get("pets", {})

    if not pets:
        return {"message": "还没有宠物被领养！"}

    # 按成长值排序
    sorted_pets = sorted(pets.values(), key=lambda p: p["stats"]["exp"], reverse=True)

    # 稀有度统计
    rarity_count = {}
    for p in sorted_pets:
        r = p["rarity_stars"]
        rarity_count[r] = rarity_count.get(r, 0) + 1

    board = []
    for i, p in enumerate(sorted_pets[:20]):
        board.append({
            "rank": i + 1,
            "name": p["name"],
            "species": f"{p['species_emoji']} {p.get('species_name', p['species'])}",
            "rarity": p["rarity_stars"],
            "level": f"Lv{p['stats']['level']} {p['stats']['level_name']}",
            "exp": p["stats"]["exp"],
            "shiny": p.get("shiny", False),
        })

    return {"leaderboard": board, "rarity_stats": rarity_count, "total": len(sorted_pets)}

# ===== CLI =====

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法:")
        print("  python pet_gen.py <user_id> --adopt [owner_name]")
        print("  python pet_gen.py <user_id> --action <feed|walk|play|train|sleep|pet>")
        print("  python pet_gen.py <user_id1> --battle <user_id2>")
        print("  python pet_gen.py --leaderboard")
        sys.exit(1)

    cmd = sys.argv[1]

    if cmd == "--leaderboard":
        result = leaderboard()
        print(json.dumps(result, ensure_ascii=False, indent=2))

    elif len(sys.argv) >= 3 and sys.argv[2] == "--adopt":
        user_id = cmd
        owner_name = sys.argv[3] if len(sys.argv) >= 4 else ""
        result = adopt(user_id, owner_name)
        print(json.dumps(result, ensure_ascii=False, indent=2))

    elif len(sys.argv) >= 4 and sys.argv[2] == "--action":
        user_id = cmd
        action = sys.argv[3]
        result = interact(user_id, action)
        print(json.dumps(result, ensure_ascii=False, indent=2))

    elif len(sys.argv) >= 4 and sys.argv[2] == "--battle":
        user_id1 = cmd
        user_id2 = sys.argv[3]
        result = battle(user_id1, user_id2)
        print(json.dumps(result, ensure_ascii=False, indent=2))

    else:
        print(f"未知命令: {sys.argv}")
        sys.exit(1)
