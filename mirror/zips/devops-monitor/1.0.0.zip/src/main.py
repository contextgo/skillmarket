#!/usr/bin/env python3
"""
DevOps Monitor Skill - 主入口
智能运维监控与告警自动化
"""

import json
import sys
import time
import socket
import subprocess
from pathlib import Path
from typing import Optional, Dict, Any, List
from dataclasses import dataclass, asdict
from datetime import datetime
import re


@dataclass
class CheckResult:
    """检查结果"""
    target: str
    check_type: str
    status: str  # ok, warning, critical, unknown
    message: str
    value: Optional[float]
    threshold: Optional[Dict]
    timestamp: str
    response_time_ms: Optional[float]


@dataclass
class InspectionReport:
    """巡检报告"""
    timestamp: str
    total_checks: int
    ok_count: int
    warning_count: int
    critical_count: int
    results: List[CheckResult]
    summary: str


class HealthChecker:
    """健康检查器"""

    def check_http(self, url: str, timeout: int = 10, expected_status: int = 200) -> CheckResult:
        """HTTP 健康检查"""
        start_time = time.time()
        try:
            import requests
            response = requests.get(url, timeout=timeout)
            response_time_ms = (time.time() - start_time) * 1000

            if response.status_code == expected_status:
                status = "ok"
                message = f"HTTP {response.status_code} OK"
            elif response.status_code >= 500:
                status = "critical"
                message = f"HTTP {response.status_code} Server Error"
            elif response.status_code >= 400:
                status = "warning"
                message = f"HTTP {response.status_code} Client Error"
            else:
                status = "ok"
                message = f"HTTP {response.status_code}"

            return CheckResult(
                target=url,
                check_type="http",
                status=status,
                message=message,
                value=response.status_code,
                threshold={"expected": expected_status},
                timestamp=datetime.now().isoformat(),
                response_time_ms=response_time_ms
            )

        except Exception as e:
            return CheckResult(
                target=url,
                check_type="http",
                status="critical",
                message=f"HTTP check failed: {str(e)}",
                value=None,
                threshold=None,
                timestamp=datetime.now().isoformat(),
                response_time_ms=None
            )

    def check_tcp(self, host: str, port: int, timeout: int = 5) -> CheckResult:
        """TCP 端口检查"""
        start_time = time.time()
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(timeout)
            result = sock.connect_ex((host, port))
            sock.close()
            response_time_ms = (time.time() - start_time) * 1000

            if result == 0:
                return CheckResult(
                    target=f"{host}:{port}",
                    check_type="tcp",
                    status="ok",
                    message=f"Port {port} is open",
                    value=1,
                    threshold=None,
                    timestamp=datetime.now().isoformat(),
                    response_time_ms=response_time_ms
                )
            else:
                return CheckResult(
                    target=f"{host}:{port}",
                    check_type="tcp",
                    status="critical",
                    message=f"Port {port} is closed",
                    value=0,
                    threshold=None,
                    timestamp=datetime.now().isoformat(),
                    response_time_ms=response_time_ms
                )

        except Exception as e:
            return CheckResult(
                target=f"{host}:{port}",
                check_type="tcp",
                status="critical",
                message=f"TCP check failed: {str(e)}",
                value=None,
                threshold=None,
                timestamp=datetime.now().isoformat(),
                response_time_ms=None
            )

    def check_ping(self, host: str, count: int = 3, timeout: int = 5) -> CheckResult:
        """Ping 检查"""
        try:
            # 使用系统 ping 命令
            cmd = ["ping", "-c", str(count), "-W", str(timeout), host]
            start_time = time.time()
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout * count + 5)
            response_time_ms = (time.time() - start_time) * 1000

            if result.returncode == 0:
                # 解析 ping 输出，提取丢包率和平均延迟
                output = result.stdout
                loss_match = re.search(r'(\d+)% packet loss', output)
                avg_match = re.search(r'avg = [\d.]+/([\d.]+)/[\d.]+', output)

                loss_rate = float(loss_match.group(1)) if loss_match else 0
                avg_latency = float(avg_match.group(1)) if avg_match else 0

                if loss_rate == 0:
                    status = "ok"
                    message = f"Ping OK, avg={avg_latency:.1f}ms"
                elif loss_rate < 50:
                    status = "warning"
                    message = f"Ping {loss_rate}% packet loss"
                else:
                    status = "critical"
                    message = f"Ping {loss_rate}% packet loss"

                return CheckResult(
                    target=host,
                    check_type="ping",
                    status=status,
                    message=message,
                    value=avg_latency,
                    threshold={"loss_rate": loss_rate},
                    timestamp=datetime.now().isoformat(),
                    response_time_ms=response_time_ms
                )
            else:
                return CheckResult(
                    target=host,
                    check_type="ping",
                    status="critical",
                    message="Ping failed - host unreachable",
                    value=None,
                    threshold=None,
                    timestamp=datetime.now().isoformat(),
                    response_time_ms=None
                )

        except Exception as e:
            return CheckResult(
                target=host,
                check_type="ping",
                status="critical",
                message=f"Ping check failed: {str(e)}",
                value=None,
                threshold=None,
                timestamp=datetime.now().isoformat(),
                response_time_ms=None
            )

    def check_log(self, log_path: str, pattern: str = "ERROR|CRITICAL|FATAL") -> CheckResult:
        """日志文件检查"""
        try:
            log_file = Path(log_path)
            if not log_file.exists():
                return CheckResult(
                    target=log_path,
                    check_type="log",
                    status="unknown",
                    message=f"Log file not found: {log_path}",
                    value=None,
                    threshold=None,
                    timestamp=datetime.now().isoformat(),
                    response_time_ms=None
                )

            # 检查最近 100 行
            error_count = 0
            with open(log_path, 'r', encoding='utf-8', errors='ignore') as f:
                lines = f.readlines()[-100:]
                for line in lines:
                    if re.search(pattern, line, re.IGNORECASE):
                        error_count += 1

            if error_count == 0:
                status = "ok"
                message = "No recent errors in log"
            elif error_count < 10:
                status = "warning"
                message = f"Found {error_count} error(s) in recent logs"
            else:
                status = "critical"
                message = f"Found {error_count} error(s) in recent logs"

            return CheckResult(
                target=log_path,
                check_type="log",
                status=status,
                message=message,
                value=error_count,
                threshold={"pattern": pattern},
                timestamp=datetime.now().isoformat(),
                response_time_ms=None
            )

        except Exception as e:
            return CheckResult(
                target=log_path,
                check_type="log",
                status="critical",
                message=f"Log check failed: {str(e)}",
                value=None,
                threshold=None,
                timestamp=datetime.now().isoformat(),
                response_time_ms=None
            )


class AlertManager:
    """告警管理器"""

    def __init__(self):
        self.alert_history = []

    def should_alert(self, result: CheckResult, cooldown_minutes: int = 5) -> bool:
        """判断是否应该发送告警（避免告警风暴）"""
        now = datetime.now()

        # 检查是否在冷却期内
        for prev_alert in self.alert_history:
            time_diff = (now - prev_alert['time']).total_seconds() / 60
            if (prev_alert['target'] == result.target and
                time_diff < cooldown_minutes and
                prev_alert['status'] == result.status):
                return False

        # 记录告警
        if result.status in ["warning", "critical"]:
            self.alert_history.append({
                'target': result.target,
                'status': result.status,
                'time': now
            })

        return True

    def format_alert(self, result: CheckResult) -> str:
        """格式化告警消息"""
        emoji = {"ok": "✅", "warning": "⚠️", "critical": "🚫", "unknown": "❓"}.get(result.status, "•")
        return f"""{emoji} [{result.status.upper()}] {result.target}
类型：{result.check_type}
信息：{result.message}
时间：{result.timestamp}
"""


def generate_inspection_report(results: List[CheckResult]) -> InspectionReport:
    """生成巡检报告"""
    ok_count = sum(1 for r in results if r.status == "ok")
    warning_count = sum(1 for r in results if r.status == "warning")
    critical_count = sum(1 for r in results if r.status == "critical")

    if critical_count > 0:
        summary = f"发现 {critical_count} 个严重问题，需要立即处理！"
    elif warning_count > 0:
        summary = f"发现 {warning_count} 个警告，建议关注"
    else:
        summary = "所有检查项正常"

    return InspectionReport(
        timestamp=datetime.now().isoformat(),
        total_checks=len(results),
        ok_count=ok_count,
        warning_count=warning_count,
        critical_count=critical_count,
        results=results,
        summary=summary
    )


def format_output(report: InspectionReport, format: str = "text") -> str:
    """格式化输出"""

    if format == "json":
        return json.dumps(asdict(report), indent=2, ensure_ascii=False)

    output = []
    output.append("\n" + "=" * 60)
    output.append("运维巡检报告")
    output.append("=" * 60)
    output.append(f"生成时间：{report.timestamp}")
    output.append(f"总检查项：{report.total_checks}")
    output.append(f"正常：{report.ok_count} ✅")
    output.append(f"警告：{report.warning_count} ⚠️")
    output.append(f"严重：{report.critical_count} 🚫")
    output.append("")
    output.append(f"摘要：{report.summary}")
    output.append("")
    output.append("-" * 40)
    output.append("详细结果:")

    # 按严重程度排序
    status_order = {"critical": 0, "warning": 1, "unknown": 2, "ok": 3}
    sorted_results = sorted(report.results, key=lambda x: status_order.get(x.status, 4))

    for result in sorted_results:
        emoji = {"ok": "✅", "warning": "⚠️", "critical": "🚫", "unknown": "❓"}.get(result.status, "•")
        output.append(f"\n{emoji} [{result.check_type.upper()}] {result.target}")
        output.append(f"   状态：{result.status}")
        output.append(f"   信息：{result.message}")
        if result.response_time_ms:
            output.append(f"   响应时间：{result.response_time_ms:.2f}ms")

    output.append("\n" + "=" * 60)
    return "\n".join(output)


def main():
    """主函数"""
    import argparse

    parser = argparse.ArgumentParser(description="DevOps Monitor - 智能运维监控")
    parser.add_argument("--target", "-t", help="监控目标 (URL/主机：端口/日志路径)")
    parser.add_argument("--type", choices=["http", "tcp", "ping", "log"], default="http", help="检查类型")
    parser.add_argument("--timeout", type=int, default=10, help="超时时间 (秒)")
    parser.add_argument("--inspection", action="store_true", help="执行完整巡检")
    parser.add_argument("--format", choices=["text", "json"], default="text", help="输出格式")
    parser.add_argument("--output", "-o", help="输出文件路径")

    args = parser.parse_args()

    checker = HealthChecker()
    alert_mgr = AlertManager()
    results = []

    if args.inspection:
        # 执行完整巡检
        print("执行运维巡检...")

        # 示例检查项（实际使用时可以配置）
        demo_targets = [
            ("https://www.google.com", "http"),
            ("https://www.baidu.com", "http"),
            ("8.8.8.8", "ping"),
        ]

        for target, check_type in demo_targets:
            if check_type == "http":
                result = checker.check_http(target, timeout=args.timeout)
            elif check_type == "ping":
                result = checker.check_ping(target)
            else:
                continue
            results.append(result)

            # 判断是否告警
            if alert_mgr.should_alert(result):
                print(alert_mgr.format_alert(result))

    elif args.target:
        # 单个检查
        if args.type == "http":
            result = checker.check_http(args.target, timeout=args.timeout)
        elif args.type == "tcp":
            host, port = args.target.rsplit(":", 1)
            result = checker.check_tcp(host, int(port), timeout=args.timeout)
        elif args.type == "ping":
            result = checker.check_ping(args.target)
        elif args.type == "log":
            result = checker.check_log(args.target)
        else:
            print(f"未知检查类型：{args.type}")
            sys.exit(1)

        results.append(result)

        # 告警
        if alert_mgr.should_alert(result):
            print(alert_mgr.format_alert(result))

    else:
        parser.print_help()
        sys.exit(1)

    # 生成报告
    report = generate_inspection_report(results)
    output = format_output(report, args.format)

    if args.output:
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(output)
        print(f"报告已保存到：{args.output}")
    else:
        print(output)

    # 有严重问题时返回非零
    has_critical = any(r.status == "critical" for r in results)
    sys.exit(1 if has_critical else 0)


if __name__ == "__main__":
    main()
