---
name: devops-monitor
version: 1.0.0
description: 智能运维监控与告警自动化
license: PROPRIETARY

capabilities:
  - health_check
  - alerting
  - log_analysis
  - auto_inspection
  - root_cause_analysis

permissions:
  - file_read
  - file_write
  - network_request
  - shell_command

inputs:
  - name: target
    type: string
    description: 监控目标 (URL/主机/服务名)
    required: true
  - name: check_type
    type: string
    description: 检查类型 (http/tcp/ping/log)
    default: http
    required: false
  - name: threshold
    type: object
    description: 告警阈值配置
    required: false

examples:
  - description: HTTP 健康检查
    command: "/monitor --target https://api.example.com/health --type http"
  - description: TCP 端口检查
    command: "/monitor --target db.example.com:5432 --type tcp"
  - description: 日志分析
    command: "/monitor --target /var/log/app.log --type log"

---

# DevOps Monitor 技能

## 功能说明

本技能提供智能运维监控与告警能力：

1. **健康检查** - HTTP/TCP/Ping 多种检查
2. **智能告警** - 动态阈值，减少误报
3. **日志分析** - 自动发现异常模式
4. **自动巡检** - 定时执行 + 报告生成

## 使用方式

### 健康检查

```
/monitor --target https://api.example.com/health
```

### 配置告警

```
/monitor --target https://api.example.com
         --threshold '{"latency_p99": 200, "error_rate": 0.01}'
```

### 生成巡检报告

```
/monitor --inspection --output daily-report.md
```

## 支持的监控源

| 类型 | 支持程度 |
|------|---------|
| HTTP/HTTPS | ✅ 完整支持 |
| TCP 端口 | ✅ 完整支持 |
| Ping | ✅ 完整支持 |
| 日志文件 | ✅ 完整支持 |
| Prometheus | 🔄 部分支持 |
