# DevOps Monitor - 使用文档

## 安装

```bash
# 通过 skillhub 安装
skillhub install devops-monitor
```

## 快速开始

### 1. HTTP 健康检查

```bash
# 检查 API 健康
python src/main.py --target https://api.example.com/health --type http
```

### 2. TCP 端口检查

```bash
# 检查数据库端口
python src/main.py --target db.example.com:5432 --type tcp
```

### 3. Ping 检查

```bash
# 检查主机可达性
python src/main.py --target 8.8.8.8 --type ping
```

### 4. 日志检查

```bash
# 检查应用日志
python src/main.py --target /var/log/app.log --type log
```

### 5. 完整巡检

```bash
# 执行预设的巡检任务
python src/main.py --inspection
```

## 命令参数

| 参数 | 说明 | 默认值 |
|------|------|-------|
| --target, -t | 监控目标 | - |
| --type | 检查类型 (http/tcp/ping/log) | http |
| --timeout | 超时时间 (秒) | 10 |
| --inspection | 执行完整巡检 | false |
| --format | 输出格式 (text/json) | text |
| --output, -o | 输出文件路径 | stdout |

## 示例场景

### 场景 1: 日常巡检

```bash
# 生成每日巡检报告
python src/main.py --inspection --output daily-report.md
```

### 场景 2: 监控多个服务

```bash
# 创建脚本循环检查
for url in api.example.com web.example.com db.example.com; do
    python src/main.py -t "https://$url" --type http
done
```

### 场景 3: 集成到 CI/CD

```bash
# GitHub Actions 步骤
- name: Health Check
  run: |
    python devops-monitor/src/main.py -t https://api.example.com/health
```

### 场景 4: 告警集成

```bash
# 结合钉钉机器人
result=$(python src/main.py -t https://api.example.com/health --format json)
if echo "$result" | jq '.results[].status' | grep -q critical; then
    curl https://oapi.dingtalk.com/robot/send -H 'Content-Type: application/json' \
         -d "{\"msgtype\":\"text\",\"text\":{\"content\":\"告警：服务不可用\"}}"
fi
```

## 检查类型详解

### HTTP 检查

- 检查 HTTP 状态码
- 测量响应时间
- 支持预期状态码配置

### TCP 检查

- 检查端口是否开放
- 测量连接建立时间
- 支持超时配置

### Ping 检查

- 检查主机可达性
- 测量往返延迟
- 检测丢包率

### 日志检查

- 扫描错误关键字
- 统计错误数量
- 支持自定义模式

## 告警级别

| 级别 | 图标 | 说明 |
|------|------|------|
| OK | ✅ | 正常 |
| Warning | ⚠️ | 警告，需要关注 |
| Critical | 🚫 | 严重，需要立即处理 |
| Unknown | ❓ | 未知状态 |

## 许可证

**专有软件** - 未开源，保留所有权利

## 定价

| 版本 | 价格 | 限制 |
|------|------|------|
| 免费 | $0 | 每日 10 次检查 |
| Pro | $49/月 | 无限检查，1000 指标 |
| Team | $199/月 | 无限检查，10000 指标，10 人 |
