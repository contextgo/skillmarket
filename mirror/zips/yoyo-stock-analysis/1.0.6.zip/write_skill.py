
import sys, os, codecs

src = r'C:\Users\eacde\.qclaw\workspace\skills\yoyo-stock-analysis\SKILL.md'
dst = r'C:\Users\eacde\.qclaw\workspace\skills\yoyo-stock-analysis\SKILL.md.fixed'

raw = open(src, 'rb').read()
print(f'Raw size: {len(raw)} bytes')

# Part 1: valid UTF-8 (bytes 0-14199)
p1 = raw[:14199].decode('utf-8', errors='replace')
print(f'Part1 chars: {len(p1)}')

# Part 2: garbled (bytes 14200-15919) - skip
# Part 3: clean UTF-8 (bytes 15920+)
p3 = raw[15920:].decode('utf-8', errors='replace')
print(f'Part3 chars: {len(p3)}')

# Combine
combined = p1 + p3
print(f'Total chars: {len(combined)}')

# Verify
missing = []
for kw in ['芒格六大思维', '逆向思维', '腾腾爸操作建议六要素', '止损公式', '附录C', '附录D', '输出模板', '简版（200字', '详版（全维度']:
    if kw not in combined:
        missing.append(kw)
print('Missing keywords:', missing if missing else 'NONE')

# Write as clean UTF-8
with open(dst, 'w', encoding='utf-8', newline='\n') as f:
    f.write(combined)
print(f'Written to: {dst}')
print(f'File size: {os.path.getsize(dst)} bytes')
