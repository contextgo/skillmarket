#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""发送 HTML 报告邮件。

用法：
    python send_html_email.py --html <html文件绝对路径> [--subject <主题>] [--to <邮箱>] [--attach]
"""

from __future__ import annotations

import argparse
import os
import smtplib
import sys
from datetime import datetime
from email.header import Header
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import formataddr

CONFIG_DIR = r"C:\Users\Administrator\WorkBuddy\Claw"
if CONFIG_DIR not in sys.path:
    sys.path.insert(0, CONFIG_DIR)

try:
    from email_config import (
        EMAIL_PASSWORD,
        RECEIVER_EMAIL,
        SENDER_EMAIL,
        SENDER_NAME,
        SMTP_PORT,
        SMTP_SERVER,
        validate_config,
    )
except Exception as exc:  # pragma: no cover
    print(f"[ERROR] 无法加载 email_config.py：{exc}")
    sys.exit(1)


def build_message(subject: str, html_content: str, to_email: str, attach_path: str | None) -> MIMEMultipart:
    msg = MIMEMultipart("mixed")
    msg["From"] = formataddr((str(Header(SENDER_NAME, "utf-8")), SENDER_EMAIL))
    msg["To"] = to_email
    msg["Subject"] = Header(subject, "utf-8")
    msg.attach(MIMEText(html_content, "html", "utf-8"))

    if attach_path:
        with open(attach_path, "rb") as f:
            attachment = MIMEApplication(f.read(), Name=os.path.basename(attach_path))
        attachment.add_header(
            "Content-Disposition",
            "attachment",
            filename=("utf-8", "", os.path.basename(attach_path)),
        )
        msg.attach(attachment)

    return msg


def send_mail(message: MIMEMultipart, to_email: str) -> None:
    server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
    try:
        server.starttls()
        server.login(SENDER_EMAIL, EMAIL_PASSWORD)
        server.sendmail(SENDER_EMAIL, [to_email], message.as_string())
    finally:
        try:
            server.quit()
        except Exception:
            pass


def main() -> int:
    parser = argparse.ArgumentParser(description="发送 HTML 报告邮件")
    parser.add_argument("--html", required=True, help="HTML 文件绝对路径")
    parser.add_argument("--subject", help="邮件主题")
    parser.add_argument("--to", help="可选，若提供则必须与 email_config.py 中的固定收件人一致")
    parser.add_argument("--attach", action="store_true", help="附加 HTML 文件")
    args = parser.parse_args()


    ok, msg = validate_config()
    if not ok:
        print(f"[ERROR] 邮件配置无效：{msg}")
        return 1

    html_path = os.path.abspath(args.html)
    if not os.path.exists(html_path):
        print(f"[ERROR] HTML 文件不存在：{html_path}")
        return 1

    with open(html_path, "r", encoding="utf-8") as f:
        html_content = f.read()

    if args.to and args.to.strip().lower() != RECEIVER_EMAIL.strip().lower():
        print("[ERROR] 本脚本仅允许发送到 email_config.py 中配置的固定收件人")
        return 1

    to_email = RECEIVER_EMAIL
    subject = args.subject or f"归江价值精选｜HTML报告｜{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    attach_path = html_path if args.attach else None


    message = build_message(subject, html_content, to_email, attach_path)
    send_mail(message, to_email)

    print("[OK] 邮件发送成功")
    print(f"[INFO] 收件人：{to_email}")
    print(f"[INFO] 主题：{subject}")
    print(f"[INFO] HTML：{html_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
