# -*- coding: utf-8 -*-
"""
升级版 send_checklist_email.py
改进点：
  1. HTML 报告作为附件添加到邮件（满足全局格式要求）
  2. 邮件正文使用白底高对比格式（内联样式，表格布局）
  3. 保留纯文本降级版本
  4. 完整的邮件头信息
"""

import os
import sys
import smtplib
import importlib.util
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from email.header import Header
from email.utils import formataddr

# ─── 邮件配置（复用 Claw 中已保存的配置）──────────────
CONFIG_PATH = r"C:\Users\Administrator\WorkBuddy\Claw\email_config.py"


def load_email_config():
    """从 email_config.py 读取配置"""
    spec = importlib.util.spec_from_file_location("email_config", CONFIG_PATH)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return {
        "sender":    module.SENDER_EMAIL,
        "password":  module.EMAIL_PASSWORD,
        "recipient": module.RECEIVER_EMAIL,
        "smtp_server": getattr(module, "SMTP_SERVER",  "smtp.qq.com"),
        "smtp_port":   getattr(module, "SMTP_PORT",     587),
    }


def find_latest_checklist():
    """查找 output 目录下最新的清单 HTML 文件"""
    skill_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    output_dir = os.path.join(skill_dir, "scripts", "output")
    if not os.path.exists(output_dir):
        return None
    files = [
        f for f in os.listdir(output_dir)
        if f.startswith("归江价值投资决策对照清单_") and f.endswith(".html")
    ]
    if not files:
        return None
    latest = sorted(files)[-1]
    return os.path.join(output_dir, latest)


def build_email_body(name_a, report_date, fname):
    """
    构建白底高对比邮件正文（内联样式，表格布局）。
    格式标准：
      - 白色正文区背景 + 深色标题 + 高对比度
      - HTML 表格布局（兼容 QQ/163/Outlook/Gmail）
      - 移除 border-radius（邮件客户端不支持）
      - 全局 inline style
      - 字号 >= 13px
    """
    FP = "'PingFang SC','Microsoft YaHei',sans-serif"
    return (
        '<!DOCTYPE html>'
        '<html lang="zh-CN">'
        '<head><meta charset="UTF-8">'
        '<meta name="viewport" content="width=device-width,initial-scale=1">'
        f'<title>归江价值投资决策对照清单 · {report_date}</title></head>'
        f'<body style="margin:0;padding:0;background:#e8eef5;font-family:{FP}">'

        # 外层包裹
        '<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#e8eef5;padding:20px 0">'
        '<tr><td align="center">'
        '<table width="700" cellpadding="0" cellspacing="0" border="0" style="max-width:700px">'

        # 邮件头
        '<tr><td style="background:#1a3a5c;padding:28px 28px 22px">'
        '<div style="text-align:center">'
        f'<div style="font-size:11px;color:#7ab8e0;letter-spacing:3px;margin-bottom:8px;font-family:{FP}">归江价值投资体系</div>'
        f'<h1 style="font-size:22px;font-weight:700;color:#ffffff;margin:0 0 8px;letter-spacing:2px;font-family:{FP}">归江价值投资决策对照清单</h1>'
        f'<div style="font-size:13px;color:#7ab8e0;margin-bottom:0;font-family:{FP}">生成日期：{report_date}</div>'
        '</div></td></tr>'

        # 提示
        '<tr><td style="background:#ffffff;padding:16px 20px;border-left:1px solid #d0dff0;border-right:1px solid #d0dff0">'
        '<table cellpadding="0" cellspacing="0" border="0" style="background:#fff3cd;border:1px solid #ffc107;width:100%">'
        '<tr><td style="padding:12px 20px;font-size:13px;color:#856404;font-family:{FP}">'
        '<b>提示：</b>完整的清单报告已作为附件附上。如正文显示不完整，请下载附件在浏览器中打开查看。'
        '</td></tr></table></td></tr>'

        # 内容简介
        '<tr><td style="background:#ffffff;padding:20px 24px;border-left:1px solid #d0dff0;border-right:1px solid #d0dff0">'
        f'<p style="font-size:14px;font-weight:700;color:#1a2a3a;margin:0 0 12px;font-family:{FP}">尊敬的价值投资者：</p>'
        f'<p style="font-size:13px;color:#444;line-height:1.9;margin:0 0 12px;font-family:{FP}">'
        f'您好！附件为您自动生成的《归江价值投资决策对照清单》，生成日期：{report_date}。</p>'
        f'<p style="font-size:13px;color:#444;line-height:1.9;margin:0 0 12px;font-family:{FP}">'
        f'本清单涵盖六大维度十九项检查：</p>'
        f'<table cellpadding="0" cellspacing="0" border="0" style="margin:0 0 16px">'
        f'<tr><td style="padding:2px 0;font-size:13px;color:#333;font-family:{FP}">一、战略定位与周期判断</td></tr>'
        f'<tr><td style="padding:2px 0;font-size:13px;color:#333;font-family:{FP}">二、生意本质与生态位</td></tr>'
        f'<tr><td style="padding:2px 0;font-size:13px;color:#333;font-family:{FP}">三、财务健康度评估</td></tr>'
        f'<tr><td style="padding:2px 0;font-size:13px;color:#333;font-family:{FP}">四、估值与安全边际</td></tr>'
        f'<tr><td style="padding:2px 0;font-size:13px;color:#333;font-family:{FP}">五、治理与资本配置</td></tr>'
        f'<tr><td style="padding:2px 0;font-size:13px;color:#333;font-family:{FP}">六、市场情绪与逆向思维</td></tr>'
        f'</table>'
        f'<p style="font-size:13px;color:#444;line-height:1.9;margin:0;font-family:{FP}">'
        f'请在投资决策前逐一对照填写，做好投资"体检"。</p>'
        '</td></tr>'

        # 邮件底
        '<tr><td style="background:#f0f4f8;padding:18px 24px;border:1px solid #d0dff0;border-top:none">'
        f'<p style="font-size:11px;color:#7a8fa8;text-align:center;margin:0 0 4px;font-family:{FP}">'
        f'本邮件由归江价值精选自动化系统生成 · {report_date}</p>'
        f'<p style="font-size:11px;color:#aabbcc;text-align:center;margin:0;font-family:{FP}">'
        f'归江价值投资体系 · 深度价值 · 逆向投资 · 长期持有</p>'
        '</td></tr>'

        '</table></td></tr></table>'
        '</body></html>'
    )


def send_email(html_path, config):
    """
    发送清单邮件，包含：
      - HTML 邮件正文（白底高对比）
      - HTML 报告作为附件

    格式标准（全局统一）：
      · 白色正文区背景 + 深色标题
      · HTML 表格布局，内联样式
      · 字号 >= 13px
      · HTML 报告作为附件发送
    """
    with open(html_path, "r", encoding="utf-8") as f:
        html_content = f.read()

    # 从文件名提取日期
    filename = os.path.basename(html_path)
    date_str = filename.replace("归江价值投资决策对照清单_", "").replace(".html", "")
    formatted_date = f"{date_str[:4]}年{date_str[4:6]}月{date_str[6:8]}日"

    # 构建邮件
    msg = MIMEMultipart('mixed')
    subject = f"【归江价值投资决策对照清单】{formatted_date} 生成"
    msg['From']    = formataddr((str(Header("归江价值精选·每日报告", 'utf-8')), config["sender"]))
    msg['To']      = config["recipient"]
    msg['Subject'] = Header(subject, 'utf-8')

    # 纯文本版本（降级）
    plain_text = (
        f"归江价值投资决策对照清单\n"
        f"{'='*40}\n\n"
        f"尊敬的价值投资者：\n\n"
        f"您好！附件为您自动生成的《归江价值投资决策对照清单》，"
        f"生成日期：{formatted_date}。\n\n"
        f"本清单涵盖六大维度十九项检查：\n"
        f"  一、战略定位与周期判断\n"
        f"  二、生意本质与生态位\n"
        f"  三、财务健康度评估\n"
        f"  四、估值与安全边际\n"
        f"  五、治理与资本配置\n"
        f"  六、市场情绪与逆向思维\n\n"
        f"请在投资决策前逐一对照填写，做好投资"体检"。\n\n"
        f"归江价值投资体系 · 深度价值 · 逆向投资\n"
        f"（本邮件由自动化系统发送，请勿直接回复）"
    )
    msg.attach(MIMEText(plain_text, "plain", "utf-8"))

    # HTML 邮件正文（白底高对比）
    email_body = build_email_body(None, formatted_date, filename)
    msg.attach(MIMEText(email_body, "html", "utf-8"))

    # ── HTML 报告作为附件 ───────────────────────────────────
    # 附件名称：使用与文件名一致的规范名称
    att_name = f"归江价值投资决策对照清单_{date_str}.html"
    with open(html_path, 'rb') as f:
        att = MIMEApplication(f.read(), Name=att_name)
    att.add_header(
        'Content-Disposition', 'attachment',
        filename=('utf-8', '', att_name)
    )
    msg.attach(att)

    # 发送
    print(f"[INFO] 连接 SMTP: {config['smtp_server']}:{config['smtp_port']}")
    print(f"[INFO] 发件人: {config['sender']}")
    print(f"[INFO] 收件人: {config['recipient']}")
    print(f"[INFO] 附件: {att_name}")

    with smtplib.SMTP(config["smtp_server"], config["smtp_port"]) as server:
        server.ehlo()
        server.starttls()
        server.ehlo()
        server.login(config["sender"], config["password"])
        server.sendmail(config["sender"], config["recipient"], msg.as_string())

    print(f"[OK] 邮件发送成功！")
    return True


def main():
    # 确定 HTML 文件路径
    if len(sys.argv) >= 2:
        html_path = sys.argv[1]
    else:
        html_path = find_latest_checklist()
        if html_path is None:
            print("[ERROR] 请先运行 generate_checklist_html.py 生成清单文件，"
                  "或传入 HTML 文件路径作为参数。")
            sys.exit(1)

    if not os.path.exists(html_path):
        print(f"[ERROR] HTML 文件不存在：{html_path}")
        sys.exit(1)

    print(f"[INFO] 使用清单文件：{html_path}")

    try:
        config = load_email_config()
    except Exception as e:
        print(f"[ERROR] 读取邮件配置失败：{e}")
        print("[ERROR] 请确保 email_config.py 存在并包含正确的配置字段。")
        sys.exit(1)

    send_email(html_path, config)
    print(f"\n[COMPLETE] 邮件已发送至 {config['recipient']}")
    print(f"[FILE] HTML 文件路径：{html_path}")


if __name__ == "__main__":
    main()
