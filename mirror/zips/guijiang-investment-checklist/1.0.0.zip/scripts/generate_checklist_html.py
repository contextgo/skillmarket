#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
归江价值投资决策对照清单 — HTML 生成器
用法：python generate_checklist_html.py [日期字符串]
"""

import os
import sys
from datetime import datetime

# ─── 配置 ───────────────────────────────────────────────────────────────────
OUTPUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output")
os.makedirs(OUTPUT_DIR, exist_ok=True)


def get_report_date(argv):
    if len(argv) >= 2:
        return argv[1]
    return datetime.now().strftime("%Y年%m月%d日 %H:%M")


def get_file_date():
    return datetime.now().strftime("%Y%m%d")


# ─── 检查维度数据（使用单引号避免字符串内引号冲突）────────────────────────
# 中文引用内容用 「」 替代 ""
SECTIONS = [
    {
        "dim": "一",
        "title": "战略定位与周期判断",
        "subtitle": "核心：判断生意是否可持续、可积累，并定位其在长周期中的位置。",
        "bg": "#eef3fa",
        "border": "#3b7dd8",
        "questions": [
            {
                "no": 1,
                "q": '行业是否具备「生物性周期」特征？',
                "detail": '需求是否根植于人类不可改变的生理/物理结构（如恒温、补水、能源）或社会基础运行？是否抗技术颠覆？（参考：空调、水电，品牌食品）',
                "ideal": "是。需求稳定、坡道极长。"
            },
            {
                "no": 2,
                "q": '公司是否拥有可持续的「经济特许权」（护城河）？',
                "detail": "市场份额是否长期稳定？ROIC 是否持续显著高于资本成本？（参考《价值投资第二版》竞争优势检验法）",
                "ideal": "是。表现为高且稳定的 ROE/ROIC。"
            },
            {
                "no": 3,
                "q": "公司当前处于自身资本开支周期和行业周期的什么阶段？",
                "detail": "是否处于产能扩张尾声、资本开支下降、行业普遍悲观或出清阶段？（这是归江认为的最佳击球点）",
                "ideal": "处于周期底部或复苏早期。"
            },
        ]
    },
    {
        "dim": "二",
        "title": "生意本质与生态位",
        "subtitle": "核心：穿透财务数据，理解生意的本质和公司在产业链中的真实地位。",
        "bg": "#fef9f0",
        "border": "#e08c2c",
        "questions": [
            {
                "no": 4,
                "q": "能否用一句话说清公司最核心的赚钱逻辑？",
                "detail": '它是「皮」还是「毛」？是「生态管理者」还是「价值依附者」？（例如：茅台是「社交货币」，海天是「餐饮业的盐」）',
                "ideal": "清晰、简单、直指本质。"
            },
            {
                "no": 5,
                "q": "公司在产业链中拥有强势话语权吗？",
                "detail": "对比应收账款天数、应付账款天数、预收账款。是否像格力、茅台一样能占用上下游资金？",
                "ideal": "是。现金流结构健康，占用上下游资金。"
            },
            {
                "no": 6,
                "q": "上下游生态是否健康？",
                "detail": '上下游是否有合理的利润空间（ROE > 5%）？还是利润分配极度畸形，存在「宝马供应商造反」风险？',
                "ideal": "健康、相对均衡，非单方面极致挤压。"
            },
        ]
    },
    {
        "dim": "三",
        "title": "财务健康度评估",
        "subtitle": "核心：验证盈利的含金量、资产的真实性和财务的稳健性。",
        "bg": "#f0f7f0",
        "border": "#3b9e3b",
        "questions": [
            {
                "no": 7,
                "q": "ROE 的构成是否优质且可持续？",
                "detail": "杜邦分析：高 ROE 主要来自高净利率（品牌/专利）、高周转（效率），还是高杠杆？杠杆是否可控？",
                "ideal": "来自净利率或周转率，杠杆稳健。"
            },
            {
                "no": 8,
                "q": "盈利的现金流含量高吗？",
                "detail": "「经营现金流净额/净利润」比率是否长期大于 1？利润是否被应收账款或存货大量占用？",
                "ideal": "持续 > 1，利润变现能力强。"
            },
            {
                "no": 9,
                "q": "资产负债表是否扎实、无重大隐患？",
                "detail": "有息负债率是否过高？是否存在大量商誉、复杂金融资产或表外负债？资产是否容易重估或减值？",
                "ideal": '负债率低，资产实在，无「暗雷」。'
            },
        ]
    },
    {
        "dim": "四",
        "title": "估值与安全边际",
        "subtitle": "核心：基于保守资产价值计算，要求足够的价格折扣。",
        "bg": "#faf0fe",
        "border": "#9b3bdb",
        "questions": [
            {
                "no": 10,
                "q": '「调整后每股净资产」是多少？',
                "detail": "对净资产进行保守调整：剔除商誉、对存货/应收减值、评估固定资产重置成本。（这是价值的底线）",
                "ideal": '计算出一个保守的「破产清算价」。'
            },
            {
                "no": 11,
                "q": '当前估值在「PB-ROE」坐标系中处于什么位置？',
                "detail": "是否处于低 PB、高 ROE 或低 PB、合理 ROE 的象限？PB 是否处于历史估值底部（如后 20% 分位）？",
                "ideal": "低 PB，ROE 可接受或较高。"
            },
            {
                "no": 12,
                "q": "价格是否提供了足够的安全边际？",
                "detail": '当前股价是否低于「调整后每股净资产」的 70%（即 7 折）？是否追求 5 折？',
                "ideal": "是，折扣越大越好。"
            },
            {
                "no": 13,
                "q": "预期股息率是否有吸引力？",
                "detail": "在潜在买入价下，预期股息率是否显著高于（如 2 倍）十年期国债收益率？",
                "ideal": "是，例如 > 5%。"
            },
        ]
    },
    {
        "dim": "五",
        "title": "治理与资本配置",
        "subtitle": "核心：评估管理层是否理性、诚信，并以股东利益为导向。",
        "bg": "#fff5f5",
        "border": "#db3b3b",
        "questions": [
            {
                "no": 14,
                "q": "管理层的历史资本配置记录如何？",
                "detail": "留存收益的再投资回报率（ROIC）是否持续高于资本成本？还是盲目多元化、毁灭价值？",
                "ideal": "再投资回报率 > 资本成本。"
            },
            {
                "no": 15,
                "q": "公司是否愿意与股东分享成果？",
                "detail": "是否有稳定、透明的分红政策？是否在股价低估时进行回购？",
                "ideal": "有稳定分红史，或明智回购。"
            },
            {
                "no": 16,
                "q": "是否存在损害小股东利益的治理瑕疵？",
                "detail": "是否存在不透明、定价不公的关联交易？控股股东是否曾有不良信用记录？",
                "ideal": "无重大治理瑕疵。"
            },
        ]
    },
    {
        "dim": "六",
        "title": "市场情绪与逆向思维",
        "subtitle": "核心：利用市场先生的错误，在无人问津处寻找机会。",
        "bg": "#f5f5f5",
        "border": "#555555",
        "questions": [
            {
                "no": 17,
                "q": "当前市场的普遍叙事是什么？",
                "detail": "市场是过度乐观（讲述成长、颠覆故事），还是过度悲观（认为其将被淘汰、永无翻身）？",
                "ideal": "市场普遍悲观、忽视或误解。"
            },
            {
                "no": 18,
                "q": "我买入的理由是否与市场共识相反？",
                "detail": "我是否看到了市场未充分认知的资产价值、周期反转或生态位改善？",
                "ideal": "是，基于独立于共识的分析。"
            },
            {
                "no": 19,
                "q": "我是否有足够的耐心持有？",
                "detail": "是否做好了持有 3-5 年不动，仅吃分红的心理准备？（成为「土豆投资人」）",
                "ideal": "是，愿意长期持有，陪伴周期。"
            },
        ]
    },
]


def build_question_row(q):
    bg_class = "row-light" if q["no"] % 2 == 1 else "row-dark"
    return f'''
        <tr class="{bg_class}">
            <td class="q-no">{q["no"]}</td>
            <td class="q-text">
                <div class="q-title">{q["q"]}</div>
                <div class="q-detail">{q["detail"]}</div>
            </td>
            <td class="q-ideal">
                <div class="ideal-label">理想答案</div>
                <div class="ideal-text">{q["ideal"]}</div>
                <div class="answer-cell">
                    <div class="answer-label">您的答案：</div>
                    <div class="answer-line"></div>
                    <div class="answer-line"></div>
                </div>
                <div class="pass-cell">
                    <span class="pass-tag pass">&#10003; 合规</span>
                    <span class="pass-tag fail">&#10007; 存疑</span>
                    <span class="pass-tag pending">? 待查</span>
                </div>
            </td>
        </tr>
    '''


def build_section(sec):
    rows = "".join(build_question_row(q) for q in sec["questions"])
    return f'''
    <div class="section-block" style="background:{sec["bg"]}; border-left:4px solid {sec["border"]};">
        <div class="section-header" style="border-bottom:2px solid {sec["border"]};">
            <span class="dim-badge" style="background:{sec["border"]};">维度{sec["dim"]}</span>
            <h2 class="section-title">{sec["title"]}</h2>
            <p class="section-subtitle">{sec["subtitle"]}</p>
        </div>
        <table class="checklist-table">
            <thead>
                <tr>
                    <th class="th-no">#</th>
                    <th class="th-q">核心问题 &amp; 检查要点</th>
                    <th class="th-ideal">理想答案 / 您的记录</th>
                </tr>
            </thead>
            <tbody>
                {rows}
            </tbody>
        </table>
    </div>
    '''


def build_html(report_date):
    sections_html = "".join(build_section(sec) for sec in SECTIONS)

    html = f'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>归江价值投资决策对照清单</title>
<style>
* {{ box-sizing: border-box; margin: 0; padding: 0; }}
body {{
    font-family: "PingFang SC", "Microsoft YaHei", "Helvetica Neue", Arial, sans-serif;
    background: #e8eef4;
    color: #2c3e50;
    line-height: 1.7;
    padding: 20px 10px;
}}
.wrapper {{
    max-width: 960px;
    margin: 0 auto;
    background: #ffffff;
    border-radius: 12px;
    box-shadow: 0 4px 24px rgba(0,0,0,0.10);
    overflow: hidden;
}}
.report-header {{
    background: linear-gradient(135deg, #1a3a5c 0%, #0f2240 100%);
    color: #fff;
    padding: 40px 50px;
    text-align: center;
    position: relative;
    overflow: hidden;
}}
.report-header::before {{
    content: "";
    position: absolute;
    top: -50px; right: -50px;
    width: 200px; height: 200px;
    border-radius: 50%;
    background: rgba(201,168,76,0.15);
}}
.report-header::after {{
    content: "";
    position: absolute;
    bottom: -30px; left: -30px;
    width: 150px; height: 150px;
    border-radius: 50%;
    background: rgba(201,168,76,0.10);
}}
.report-header .logo-tag {{
    display: inline-block;
    background: rgba(201,168,76,0.25);
    border: 1px solid rgba(201,168,76,0.5);
    color: #c9a84c;
    padding: 4px 16px;
    border-radius: 20px;
    font-size: 12px;
    letter-spacing: 2px;
    margin-bottom: 14px;
    text-transform: uppercase;
    position: relative;
    z-index: 1;
}}
.report-header h1 {{
    font-size: 28px;
    font-weight: 700;
    color: #ffffff;
    letter-spacing: 1px;
    margin-bottom: 10px;
    position: relative;
    z-index: 1;
}}
.report-header h1 span {{
    color: #c9a84c;
}}
.report-header .report-meta {{
    font-size: 13px;
    color: rgba(255,255,255,0.7);
    margin-top: 6px;
    position: relative;
    z-index: 1;
}}
.report-header .report-meta strong {{
    color: #c9a84c;
}}
.report-header .subtitle {{
    font-size: 14px;
    color: rgba(255,255,255,0.55);
    margin-top: 12px;
    max-width: 600px;
    margin-left: auto;
    margin-right: auto;
    position: relative;
    z-index: 1;
}}
.guide-box {{
    background: linear-gradient(90deg, #f0f4ff 0%, #fff 100%);
    border: 1px solid #c5d8f8;
    border-radius: 8px;
    margin: 30px 40px;
    padding: 20px 24px;
}}
.guide-box h3 {{
    color: #1a3a5c;
    font-size: 15px;
    margin-bottom: 10px;
    display: flex;
    align-items: center;
    gap: 8px;
}}
.guide-box h3::before {{
    content: "\25B6";
    color: #3b7dd8;
    font-size: 11px;
}}
.guide-box ol {{
    padding-left: 20px;
    color: #444;
    font-size: 13.5px;
}}
.guide-box ol li {{
    margin-bottom: 4px;
}}
.guide-box .warn {{
    color: #c0392b;
    font-weight: 600;
}}
.section-block {{
    margin: 24px 40px;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
}}
.section-header {{
    padding: 16px 24px 14px;
    display: flex;
    align-items: center;
    gap: 14px;
    flex-wrap: wrap;
}}
.dim-badge {{
    color: #fff;
    font-size: 12px;
    font-weight: 700;
    padding: 3px 10px;
    border-radius: 20px;
    letter-spacing: 1px;
    white-space: nowrap;
    flex-shrink: 0;
}}
.section-title {{
    font-size: 18px;
    font-weight: 700;
    color: #1a3a5c;
}}
.section-subtitle {{
    width: 100%;
    font-size: 13px;
    color: #5a6a7a;
    margin-top: 4px;
    padding-left: 42px;
    font-style: italic;
}}
.checklist-table {{
    width: 100%;
    border-collapse: collapse;
    font-size: 13.5px;
}}
.checklist-table thead {{
    background: #1a3a5c;
    color: #fff;
}}
.checklist-table thead th {{
    padding: 10px 16px;
    font-weight: 600;
    font-size: 12px;
    letter-spacing: 0.5px;
    text-align: left;
}}
.th-no {{ width: 40px; text-align: center !important; }}
.th-q {{ width: 52%; }}
.th-ideal {{ width: 38%; }}
.checklist-table tbody tr {{
    border-bottom: 1px solid rgba(0,0,0,0.06);
}}
.row-light {{ background: rgba(255,255,255,0.8); }}
.row-dark {{ background: rgba(240,245,255,0.5); }}
.checklist-table tbody tr:hover {{ background: #e8f2ff; }}
.checklist-table td {{
    padding: 12px 16px;
    vertical-align: top;
}}
.q-no {{
    text-align: center;
    font-size: 18px;
    font-weight: 700;
    color: #1a3a5c;
    width: 40px;
}}
.q-title {{
    font-weight: 600;
    color: #1a3a5c;
    font-size: 13.5px;
    margin-bottom: 5px;
}}
.q-detail {{
    font-size: 12px;
    color: #607080;
    line-height: 1.6;
}}
.q-ideal {{ border-left: 1px solid #e0e6ed; }}
.ideal-label {{
    font-size: 11px;
    font-weight: 700;
    color: #c9a84c;
    text-transform: uppercase;
    letter-spacing: 1px;
    margin-bottom: 4px;
}}
.ideal-text {{
    font-size: 12.5px;
    color: #2c7a2c;
    background: #f0faf0;
    border-left: 3px solid #3b9e3b;
    padding: 5px 10px;
    border-radius: 0 4px 4px 0;
    margin-bottom: 10px;
}}
.answer-cell {{ margin-bottom: 8px; }}
.answer-label {{
    font-size: 11.5px;
    color: #556;
    margin-bottom: 3px;
    font-weight: 600;
}}
.answer-line {{
    border-bottom: 1px dashed #aab;
    height: 16px;
    margin-bottom: 4px;
}}
.pass-cell {{
    display: flex;
    gap: 6px;
    flex-wrap: wrap;
    margin-top: 4px;
}}
.pass-tag {{
    font-size: 11px;
    padding: 2px 8px;
    border-radius: 10px;
    font-weight: 600;
    cursor: default;
}}
.pass {{ background: #e8f5e9; color: #2e7d32; border: 1px solid #a5d6a7; }}
.fail {{ background: #ffebee; color: #c62828; border: 1px solid #ef9a9a; }}
.pending {{ background: #fff8e1; color: #f57f17; border: 1px solid #ffe082; }}
.footer-section {{
    margin: 30px 40px 40px;
    padding: 24px;
    background: #f8fafc;
    border: 1px solid #e0e6ed;
    border-radius: 10px;
}}
.footer-section h3 {{
    font-size: 15px;
    color: #1a3a5c;
    margin-bottom: 12px;
    display: flex;
    align-items: center;
    gap: 8px;
}}
.footer-section h3::before {{
    content: "\25C6";
    color: #c9a84c;
    font-size: 10px;
}}
.footer-section p {{
    font-size: 12.5px;
    color: #5a6a7a;
    line-height: 1.8;
    margin-bottom: 8px;
}}
.footer-section .highlight {{
    background: linear-gradient(90deg, #fff3cd, #fff);
    border: 1px solid #ffe082;
    border-radius: 6px;
    padding: 10px 14px;
    font-size: 12.5px;
    color: #856404;
    margin-top: 12px;
}}
.report-footer {{
    background: #1a3a5c;
    color: rgba(255,255,255,0.5);
    text-align: center;
    padding: 16px;
    font-size: 11.5px;
}}
.report-footer span {{ color: #c9a84c; }}
@media (max-width: 700px) {{
    .report-header {{ padding: 28px 20px; }}
    .report-header h1 {{ font-size: 20px; }}
    .guide-box {{ margin: 20px 16px; }}
    .section-block {{ margin: 16px 16px; }}
    .footer-section {{ margin: 20px 16px 30px; }}
    .section-subtitle {{ padding-left: 0; }}
    .checklist-table {{ font-size: 12px; }}
    .checklist-table td, .checklist-table thead th {{ padding: 8px 10px; }}
    .th-q {{ width: 55%; }}
    .th-ideal {{ width: 35%; }}
    .q-title {{ font-size: 12.5px; }}
    .q-detail {{ font-size: 11px; }}
    .ideal-text {{ font-size: 11.5px; }}
}}
</style>
</head>
<body>
<div class="wrapper">

    <div class="report-header">
        <div class="logo-tag">归江价值投资体系</div>
        <h1>归江<span>&#183;</span>价值投资决策对照清单</h1>
        <div class="report-meta">
            生成时间：<strong>{report_date}</strong>
        </div>
        <div class="subtitle">
            根据归江价值投资思想体系构建 &#183; 六维度十九项检查 &#183; 系统化投资体检工具
        </div>
    </div>

    <div class="guide-box">
        <h3>使用指南</h3>
        <ol>
            <li>在投资决策前，逐一回答表格中的问题，填写您的答案。</li>
            <li>对于答案为「否」或「待查」的项，必须深入研究，直至有合理解释。</li>
            <li>理想投资标的：应在绝大多数维度（尤其是 <strong>三、四、五</strong> 部分）符合「理想答案」，并在 <strong>一、六</strong> 部分体现出明显的逆向机会。</li>
            <li class="warn">警示信号：如果在第 4、6、10、12、14、16 等关键问题上出现否定答案，需极度谨慎，这可能是一个价值陷阱。</li>
        </ol>
        <div class="highlight">
            <strong>核心逻辑链：</strong>从产业视角看资产（一、二）&#8594; 用财务透视验证（三）&#8594; 以破产价购买（四）&#8594; 评估人的因素（五）&#8594; 并利用市场情绪（六）
        </div>
    </div>

    {sections_html}

    <div class="footer-section">
        <h3>声明与建议</h3>
        <p>本清单是归江价值投资思想体系的系统性实践工具，旨在帮助投资者进行结构化自我审视，并非投资建议或盈利保证。</p>
        <p>归江价值投资强调：好生意 &#215; 强护城河 &#215; 保守估值 &#215; 逆向思维 &#215; 长期持有，五位一体，缺一不可。</p>
        <p>使用本清单时，请务必结合具体标的的基本面研究和行业分析，独立判断，理性决策。</p>
        <div class="highlight">
            <strong>记住：</strong>模糊的正确胜于精确的错误。清单帮助您思考，但不替代您的判断。
        </div>
    </div>

    <div class="report-footer">
        归江价值投资体系 &#183; <span>归江价值精选</span> &#183; 深度价值 &#183; 逆向投资 &#183; 长期持有
    </div>

</div>
</body>
</html>'''
    return html


def main():
    report_date = get_report_date(sys.argv)
    file_date = get_file_date()
    html_content = build_html(report_date)
    filename = f"归江价值投资决策对照清单_{file_date}.html"
    filepath = os.path.join(OUTPUT_DIR, filename)

    with open(filepath, "w", encoding="utf-8") as f:
        f.write(html_content)

    print(f"[OK] HTML 报告已生成：{filepath}")
    print(f"[DATE] 报告日期：{report_date}")
    return filepath


if __name__ == "__main__":
    main()
