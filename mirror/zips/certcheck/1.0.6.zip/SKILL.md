---
name: CertCheck
description: "Check SSL certificate expiry dates and catch renewals before breakage. Use when auditing domain certs, monitoring expiry, or verifying chain trust."
version: "2.0.0"
author: "BytesAgain"
homepage: https://bytesagain.com
source: https://github.com/bytesagain/ai-skills
tags: ["ssl","tls","certificate","security","https","expiry","domain","devops"]
categories: ["Security", "System Tools", "Developer Tools"]
---

# CertCheck

A comprehensive security toolkit for managing certificates, credentials, and security policies. Track generation, rotation, auditing, and revocation of certificates and secrets — all from the command line.

## Commands

| Command | Description |
|---------|-------------|
| `certcheck generate <input>` | Generate a new certificate or credential entry |
| `certcheck check-strength <input>` | Check the strength of a certificate or credential |
| `certcheck rotate <input>` | Record a credential rotation event |
| `certcheck audit <input>` | Log an audit entry for compliance tracking |
| `certcheck store <input>` | Store a certificate or secret reference |
| `certcheck retrieve <input>` | Retrieve a previously stored entry |
| `certcheck expire <input>` | Record or check expiration details |
| `certcheck policy <input>` | Define or review security policies |
| `certcheck report <input>` | Generate a security report entry |
| `certcheck hash <input>` | Record a hash value for verification |
| `certcheck verify <input>` | Verify a certificate or credential |
| `certcheck revoke <input>` | Revoke a certificate or credential |
| `certcheck stats` | Show summary statistics across all logs |
| `certcheck export <fmt>` | Export data in json, csv, or txt format |
| `certcheck search <term>` | Search across all log files |
| `certcheck recent` | Show the 20 most recent activity entries |
| `certcheck status` | Health check — version, data size, last activity |
| `certcheck help` | Show available commands |
| `certcheck version` | Show version |

All data commands (generate, check-strength, rotate, audit, store, retrieve, expire, policy, report, hash, verify, revoke) work the same way:
- **With arguments:** Saves a timestamped entry to its dedicated log file and records it in the history log.
- **Without arguments:** Shows the 20 most recent entries from that command's log.

## Data Storage

- **Location:** `~/.local/share/certcheck/`
- Each command writes to its own log file (e.g., `generate.log`, `audit.log`, `revoke.log`)
- A unified `history.log` tracks all activity across commands
- Export supports JSON, CSV, and plain text formats
- All data is stored locally — no external APIs or network calls

## Requirements

- bash 4+ (uses `set -euo pipefail`)
- Standard Unix utilities (`date`, `wc`, `du`, `grep`, `head`, `tail`)
- No external dependencies or API keys required

## When to Use

1. **Certificate lifecycle tracking** — Record generation, rotation, expiration, and revocation events for SSL/TLS certificates across your infrastructure.
2. **Security audit logging** — Maintain a timestamped audit trail of credential changes for compliance and internal reviews.
3. **Credential strength assessment** — Log and track password/key strength evaluations over time to identify weak spots.
4. **Policy enforcement documentation** — Define and review security policies, then verify adherence through the report and audit commands.
5. **Team security reporting** — Export consolidated security activity data in JSON/CSV/TXT for sharing with stakeholders or feeding into dashboards.

## Examples

```bash
# Generate and track a new certificate
certcheck generate "wildcard cert for *.example.com SHA-256"

# Check credential strength
certcheck check-strength "api-key-prod-2024 128-bit"

# Record a rotation event
certcheck rotate "db-password rotated for production cluster"

# Log an audit finding
certcheck audit "quarterly review: 3 certs expiring within 30 days"

# Store a certificate reference
certcheck store "letsencrypt cert serial:ABC123 for api.example.com"

# Mark a certificate for expiration tracking
certcheck expire "wildcard cert expires 2024-12-15"

# Revoke a compromised credential
certcheck revoke "api-key-staging-old compromised via leaked .env"

# View statistics across all activity
certcheck stats

# Export everything to JSON
certcheck export json

# Search for a specific domain
certcheck search example.com

# Check system health
certcheck status
```

---

*Powered by BytesAgain | bytesagain.com | hello@bytesagain.com*
