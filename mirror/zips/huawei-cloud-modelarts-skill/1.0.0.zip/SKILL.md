# Skill 信息

## 1. 基本信息
- Skill 名称：ModelArts 全资源统一管理
- Skill 版本：1.0.0
- 运行环境：Python 3.6+
- 依赖 SDK：modelarts-sdk
- 安全等级：高

## 2. 功能描述
本 Skill 提供 ModelArts 全资源安全查询能力，支持：
- Notebook 实例
- 训练作业
- 推理服务
- 模型管理

严格遵守安全规范：
- 不处理明文 AK/SK
- 不存储任何凭证
- 仅使用环境安全认证
- 所有返回信息脱敏

## 3. 调用说明
- 入口函数：handler(event, context)
- 请求方式：HTTP / 函数工作流
- 返回格式：JSON

## 4. 安全声明
1. 认证方式：使用 ModelArts 运行环境临时安全凭证
2. 数据处理：所有 ID、密钥、网络信息自动脱敏
3. 凭证管理：无缓存、无存储、无持久化
4. 异常信息：不暴露系统内部结构

## 5. 输入参数
无

## 6. 正常返回示例
{
  "status": "success",
  "counts": {
    "notebook": 2,
    "training_job": 3,
    "service": 1,
    "model": 5
  },
  "resources": {
    "notebooks": [...],
    "training_jobs": [...],
    "services": [...],
    "models": [...]
  }
}

## 7. 异常返回
{
  "status": "error",
  "message": "服务处理失败，请检查权限"
}

## 8. 部署要求
- 无需配置 AK/SK
- 无需密钥
- 运行环境：ModelArts Skill
- 权限：运行时默认权限