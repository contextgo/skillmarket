# -*- coding: utf-8 -*-
"""
ModelArts 通用资源管理 SKILL
支持：Notebook / 训练 / 推理 / 模型
安全规范：零明文凭证、零存储、数据脱敏
Skill规范：符合华为云 ModelArts 官方标准入口格式
"""
import json
import logging
from typing import Dict, Any

# ==================== 安全配置 ====================
SAFE_CONFIG = {
    "enable_credential_cache": False,
    "CREDENTIAL_TYPE": "environment",
    "SENSITIVE_FIELDS": {
        "id", "instance_id", "job_id", "service_id", "model_id",
        "ak", "sk", "token", "secret", "password", "access_key",
        "network", "subnet", "security_group", "pod_id", "secret_key"
    }
}

# ==================== 标准日志 ====================
logger = logging.getLogger("ModelArtsUniversalSkill")
logger.setLevel(logging.INFO)

# ==================== 安全会话 ====================
def get_secure_session():
    from modelarts.session import Session
    try:
        return Session(cred_type=SAFE_CONFIG["CREDENTIAL_TYPE"], config=SAFE_CONFIG)
    except Exception as e:
        logger.error(f"认证失败: {str(e)}")
        raise RuntimeError("安全认证失败，请确认运行环境权限")

# ==================== 数据脱敏 ====================
def desensitize(data: Any) -> Any:
    if isinstance(data, list):
        return [desensitize(item) for item in data]
    if isinstance(data, dict):
        cleaned = {}
        for k, v in data.items():
            lk = k.lower()
            if lk in SAFE_CONFIG["SENSITIVE_FIELDS"] or any(
                s in lk for s in ["id", "ak", "sk", "token", "secret"]
            ):
                cleaned[k] = "***已脱敏***"
            elif isinstance(v, (dict, list)):
                cleaned[k] = desensitize(v)
            else:
                cleaned[k] = v
        return cleaned
    return data

# ==================== 资源获取统一封装 ====================
def list_all_resources(session):
    from modelarts.notebook import Notebook
    from modelarts.training import TrainingJob
    from modelarts.service import Service
    from modelarts.model import Model

    nb = Notebook(session)
    tr = TrainingJob(session)
    sv = Service(session)
    md = Model(session)

    return {
        "notebooks": desensitize(nb.list_notebooks()),
        "training_jobs": desensitize(tr.list_jobs()),
        "services": desensitize(sv.list_services()),
        "models": desensitize(md.list_models())
    }

# ==================== 标准 SKILL 入口 ====================
def handler(event: Dict, context: Dict) -> Dict:
    try:
        session = get_secure_session()
        resources = list_all_resources(session)

        resp = {
            "status": "success",
            "counts": {
                "notebook": len(resources["notebooks"]),
                "training_job": len(resources["training_jobs"]),
                "service": len(resources["services"]),
                "model": len(resources["models"])
            },
            "resources": resources
        }

        return {
            "statusCode": 200,
            "headers": {"Content-Type": "application/json; charset=utf-8"},
            "body": json.dumps(resp, ensure_ascii=False)
        }

    except Exception as e:
        logger.error(f"执行异常: {str(e)}")
        return {
            "statusCode": 500,
            "headers": {"Content-Type": "application/json; charset=utf-8"},
            "body": json.dumps({
                "status": "error",
                "message": "服务处理失败，请检查权限"
            }, ensure_ascii=False)
        }