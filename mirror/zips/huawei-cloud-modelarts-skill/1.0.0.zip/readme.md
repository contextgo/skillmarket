# ModelArts 全资源管理 Skill
## 支持资源
- Notebook
- 训练作业
- 推理服务
- 模型

## 部署方法
1. 将所有文件打包为 ZIP
2. 上传至 ModelArts Skill 平台
3. 无需配置任何凭证
4. 直接发布使用

## 安全特性
✅ 无明文 AK/SK
✅ 无凭证存储
✅ 全资源脱敏返回
✅ 官方标准 Skill 格式
✅ 可直接上线