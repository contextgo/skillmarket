---
name: morning-daily-report
description: 生成专业早间日报，包含今日天气、穿衣推荐、飞书日程、多平台热点新闻、GitHub AI项目趋势和早安寄语。触发条件：(1) 用户要求生成早间日报 (2) 每日定时自动推送早报 (3) 需要快速获取当日天气、日程、热点等关键信息集合
---

# 早间日报生成 Skill

## 🔧 初始化配置

### 自动配置引导（推荐）

首次使用本技能时，**配置引导会自动启动**。系统会检测 `config.json` 是否存在，如果不存在或配置不完整，会自动运行交互式配置向导。

**触发方式：**
1. 向 assistant 发送「生成今日早间日报」
2. 如果检测到未配置，会自动引导您完成设置
3. 或者直接运行配置脚本：`python3 config_setup.py`

**配置向导会询问：**
1. 📍 **地理位置**（默认：四川省成都市温江区）
2. 🔍 **关注的热点领域**（多选，默认：科技,互联网,AI,财经）
3. 📤 **推送渠道**（可选：feishu/weixin/both，默认：feishu）
4. 🎯 **推送目标**（飞书群ID/用户ID，默认：auto 自动推送当前用户）
5. ⏰ **推送时间**（默认：08:00）

配置完成后自动保存到 `config.json`，后续无需重复配置。

### 配置脚本使用方式

```bash
# 交互式配置（推荐）
python3 config_setup.py

# 检查当前配置
python3 config_setup.py --check

# 重置配置
python3 config_setup.py --reset

# 使用默认配置（非交互式）
python3 config_setup.py --auto

# 快速配置（命令行参数）
python3 config_setup.py --location "北京市" --focus "科技,AI,游戏" --channel feishu --target auto --time "08:30"
```

### 配置示例

手动创建 `config.json` 文件：
```json
{
  "location": "四川省成都市温江区",
  "hot_focus": ["科技", "互联网", "AI", "财经"],
  "push_channel": "feishu",
  "push_target": "auto",
  "push_time": "08:00",
  "language": "zh-CN"
}
```

**字段说明：**
| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `location` | string | ✅ | 地理位置，用于获取天气 |
| `hot_focus` | array | ✅ | 关注的热点领域，影响新闻筛选 |
| `push_channel` | string | ✅ | 推送渠道：`feishu`/`weixin`/`both` |
| `push_target` | string | ✅ | 推送目标：`auto` 或具体的群ID/用户ID |
| `push_time` | string | ❌ | 自动推送时间，默认 `08:00` |
| `language` | string | ❌ | 语言，默认 `zh-CN` |

### 修改配置
向 assistant 发送指令即可重新配置：
- 「修改早间日报配置」→ 重新运行配置向导
- 「重置早报配置」→ 使用默认配置
- 「检查早报配置」→ 查看当前配置状态

## 📋 依赖技能
使用本技能前需要确保以下技能已安装：
1. `weather` - 获取天气数据（系统内置）
2. `feishu-calendar` - 获取飞书日程和待办
3. `daily-hot-news` - 获取多平台热点新闻
4. `github-ai-trends` - 获取GitHub AI项目趋势

### 依赖服务检查

```bash
# 检查 DailyHotApi 服务是否运行
curl -s http://localhost:6688 > /dev/null && echo "✅ DailyHotApi 运行中" || echo "❌ DailyHotApi 未启动"

# 检查配置是否完整
python3 config_setup.py --check
```

### 首次使用流程

```
用户：生成今日早间日报
  ↓
Agent：检测到 config.json 不存在 → 启动配置向导
  ↓
用户：按向导回答问题（或直接回车使用默认值）
  ↓
Agent：保存配置 → 生成早报
  ↓
用户：收到完整早报 ✅
```

后续使用直接说「生成早报」即可，无需重复配置。

## 🚀 使用方法
### 手动生成
直接向assistant Agent发送指令："生成今日早间日报"即可自动生成。

### 定时推送
在cron中添加每日定时任务，例如每天早上8点推送：
```bash
openclaw cron add --name "每日早报推送" --schedule '{"kind":"cron","expr":"0 8 * * *","tz":"Asia/Shanghai"}' --payload '{"kind":"agentTurn","message":"生成今日早间日报并推送给用户","agentId":"assistant"}'
```

## 📝 生成规范
严格按照以下格式生成早间日报，确保清晰美观：

```markdown
## 🌅 早间日报 - {{日期}} {{星期}}
---
## 📅 今日概览
### 🌤️ 今日天气 - {{配置的地理位置}}
| 项⽬ | 内容 |
|------|------|
| 当前温度 | {{value}}℃ |
| 最高温度 | {{value}}℃ |
| 最低温度 | {{value}}℃ |
| 天气状况 | {{value}} |
| 湿度 | {{value}}% |
| 风速 | {{value}}级 |
| 紫外线指数 | {{value}} |
| 日出时间 | {{value}} |
| 日落时间 | {{value}} |

### 👕 今日穿衣推荐
根据天气数据给出个性化建议，包含：
- 温度适配穿搭建议
- 雨雪/大风等特殊天气防护建议
- 紫外线强度对应的防晒建议
- 其他需要注意的事项

### 📅 今日日程
列出用户今日的飞书日历会议和待办事项，如果没有则显示**今日暂无日程**。

---
## 📰 今日热点新闻
整合以下平台的Top 5热点新闻，按平台分类展示：
- 📱 微博热搜
- 💡 知乎热榜
- 🚀 36氪
- 💻 IT之家
- 💻 抖音
- 💻 小红书

每条新闻格式：
`{{序号}}. {{标题}} | 🔥 {{热度值（如有）}}`

---
## 📊 GitHub AI 项目趋势
展示今日Top 10 AI项目，每条格式：
`{{排名}}. [{{项目名}}]({{项目链接}}) | ⭐ {{Star数}}
{{项目描述}}
💡 中文说明：{{中文描述}}`

---
## 💡 今日寄语
一句简短、积极的早安问候或励志话语。

---
⏰ 生成时间：{{当前时间}}
🤖 由小右自动生成，祝您今天愉快！✨
```

## ⚠️ 注意事项
1. **配置引导**：首次使用务必运行配置向导，确保所有设置正确。可直接说「生成早报」触发自动配置。
2. **天气数据**：优先使用 `weather` 技能获取，确保准确实时。位置信息来自用户配置。
3. **日程数据**：需用户授权飞书日历权限后才能获取。权限在飞书后台开通后，需要用户重新授权才能生效。
4. **热点新闻**：优先筛选用户配置中 `hot_focus` 关注的领域内容，未关注的领域可以跳过。
5. **DailyHotApi 服务**：`daily-hot-news` 技能依赖此服务，需确保服务已部署在 `http://localhost:6688`。
6. **GitHub项目**：优先展示中文项目或对中文用户友好的项目。
7. **生成的内容**：要简洁实用，避免冗余信息。

## 🆘 常见问题

**Q: 首次使用没有弹出配置向导？**
A: 运行 `python3 config_setup.py` 手动启动配置向导，或向 assistant 说「生成早报」触发自动检测。

**Q: 配置完成后如何修改？**
A: 向 assistant 说「修改早间日报配置」，或运行 `python3 config_setup.py --reset`。

**Q: DailyHotApi 服务未启动？**
A: 检查服务是否运行：`curl http://localhost:6688`。如果未启动，参考 `daily-hot-news` 技能的部署说明启动服务。

**Q: 飞书日程获取失败？**
A: 检查飞书应用是否已开通 `calendar:calendar:read` 权限，并确保用户已完成 OAuth 授权。