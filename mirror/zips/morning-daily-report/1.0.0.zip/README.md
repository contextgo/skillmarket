# 🌅 早间日报生成 Skill

生成专业早间日报，包含今日天气、穿衣推荐、飞书日程、多平台热点新闻、GitHub AI 项目趋势和早安寄语。

## 🚀 快速开始

### 1. 安装依赖技能

```bash
# 通过 SkillHub 安装
skillhub install daily-hot-news
skillhub install github-ai-trends

# 确保 DailyHotApi 服务已部署并运行
# 服务地址：http://localhost:6688
```

### 2. 运行配置向导

```bash
# 方式一：命令行
python3 config_setup.py

# 方式二：通过 assistant 对话
# 向 assistant 发送：「生成今日早间日报」
# 会自动检测并引导配置
```

### 3. 配置说明

配置向导会引导您设置：

| 配置项 | 说明 | 默认值 |
|--------|------|--------|
| 📍 地理位置 | 用于获取天气 | 四川省成都市温江区 |
| 🔍 热点领域 | 关注的新闻领域 | 科技,互联网,AI,财经 |
| 📤 推送渠道 | feishu/weixin/both | feishu |
| 🎯 推送目标 | 群ID/用户ID/auto | auto |
| ⏰ 推送时间 | 自动推送时间 | 08:00 |

### 4. 生成早报

```bash
# 手动生成
# 向 assistant 发送：「生成今日早间日报」
```

### 5. 设置自动推送

```bash
# 添加定时任务（每天早上8点）
openclaw cron add --name "每日早报推送" \
  --schedule '{"kind":"cron","expr":"0 8 * * *","tz":"Asia/Shanghai"}' \
  --payload '{"kind":"agentTurn","message":"生成今日早间日报并推送给用户","agentId":"assistant"}'
```

## 📁 文件结构

```
morning-daily-report/
├── SKILL.md              # 技能说明文档
├── README.md             # 本文件（快速入门）
├── config.json           # 用户配置文件（由向导生成）
├── config_setup.py       # 配置引导脚本
├── init.py               # 初始化检查模块
└── config.example.json   # 配置示例
```

## 🔧 配置脚本用法

```bash
# 交互式配置（推荐）
python3 config_setup.py

# 检查当前配置
python3 config_setup.py --check

# 重置配置
python3 config_setup.py --reset

# 使用默认配置
python3 config_setup.py --auto

# 快速配置
python3 config_setup.py --location "北京市" --focus "科技,AI" --channel feishu --time "08:30"
```

## 📋 依赖清单

| 依赖 | 类型 | 说明 |
|------|------|------|
| `weather` | 系统内置 | 天气数据 |
| `feishu-calendar` | 技能 | 飞书日程 |
| `daily-hot-news` | 技能 | 热点新闻 |
| `github-ai-trends` | 技能 | GitHub AI 趋势 |
| DailyHotApi 服务 | 外部服务 | 热榜数据聚合服务 |

## 🆘 故障排查

**配置不完整？**
```bash
python3 config_setup.py --check
```

**DailyHotApi 未启动？**
```bash
curl http://localhost:6688
# 如果无响应，需部署 DailyHotApi 服务
```

**飞书日程获取失败？**
- 检查飞书应用是否开通 `calendar:calendar:read` 权限
- 用户需要重新完成 OAuth 授权

## 📝 更新日志

**v1.1.0** (2026-04-30)
- ✨ 新增交互式配置引导脚本 `config_setup.py`
- ✨ 新增配置检查模块 `init.py`
- ✨ 支持首次使用自动检测和引导配置
- ✨ 支持命令行快速配置参数

**v1.0.0** (2026-04-30)
- 初始版本
- 支持天气、日程、热榜、GitHub 趋势
- 支持定时自动推送
