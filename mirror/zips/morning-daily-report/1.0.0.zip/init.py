#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
早间日报初始化检查模块

当技能被加载时自动检查：
1. 配置文件是否存在
2. 配置是否完整
3. 依赖服务是否可用

使用方法：
    from init import check_and_init
    result = check_and_init()
"""

import json
import subprocess
import sys
from pathlib import Path

# 技能根目录
SKILL_DIR = Path(__file__).parent
CONFIG_PATH = SKILL_DIR / "config.json"


def check_config():
    """检查配置是否存在且完整"""
    if not CONFIG_PATH.exists():
        return False, "配置文件不存在"

    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            config = json.load(f)
    except Exception as e:
        return False, f"配置文件读取失败：{e}"

    required_keys = ["location", "hot_focus", "push_channel", "push_target"]
    missing = [k for k in required_keys if k not in config]

    if missing:
        return False, f"配置不完整，缺少：{', '.join(missing)}"

    return True, config


def check_dependencies():
    """检查依赖服务是否可用"""
    results = {}

    # 检查 DailyHotApi 服务
    try:
        import urllib.request
        req = urllib.request.Request(
            "http://localhost:6688",
            method="HEAD",
            timeout=3
        )
        with urllib.request.urlopen(req) as resp:
            results["daily_hot_api"] = resp.status == 200
    except Exception:
        results["daily_hot_api"] = False

    return results


def run_setup():
    """运行配置向导"""
    setup_script = SKILL_DIR / "config_setup.py"
    if setup_script.exists():
        try:
            subprocess.run([sys.executable, str(setup_script)], check=True)
            return True
        except subprocess.CalledProcessError:
            return False
    return False


def check_and_init(auto_setup=True):
    """
    检查并初始化配置

    Args:
        auto_setup: 如果配置不存在，是否自动运行配置向导

    Returns:
        dict: 检查结果
    """
    ok, config_or_msg = check_config()

    if ok:
        deps = check_dependencies()
        return {
            "ready": True,
            "config": config_or_msg,
            "dependencies": deps,
            "message": "配置完整，可以生成早报"
        }

    # 配置不完整
    if auto_setup:
        print(f"⚠️ {config_or_msg}")
        print("🔄 正在启动配置向导...\n")
        if run_setup():
            # 重新检查
            ok, config_or_msg = check_config()
            if ok:
                return {
                    "ready": True,
                    "config": config_or_msg,
                    "dependencies": check_dependencies(),
                    "message": "配置完成"
                }

    return {
        "ready": False,
        "config": None,
        "dependencies": check_dependencies(),
        "message": config_or_msg
    }


def get_config():
    """获取当前配置"""
    ok, result = check_config()
    return result if ok else None


if __name__ == "__main__":
    result = check_and_init(auto_setup=True)
    print(f"\n状态：{'✅ 就绪' if result['ready'] else '❌ 未就绪'}")
    print(f"消息：{result['message']}")
