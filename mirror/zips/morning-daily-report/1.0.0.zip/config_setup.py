#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
早间日报配置引导脚本

功能：
1. 首次使用时自动引导用户配置
2. 检查配置完整性
3. 支持重新配置
4. 支持命令行参数快速配置

使用方法：
    python3 config_setup.py              # 交互式配置
    python3 config_setup.py --check      # 仅检查配置
    python3 config_setup.py --reset      # 重置配置
    python3 config_setup.py --auto       # 使用默认配置
"""

import json
import os
import sys
from pathlib import Path

# 配置文件路径
CONFIG_PATH = Path(__file__).parent / "config.json"

# 默认配置
DEFAULT_CONFIG = {
    "location": "四川省成都市温江区",
    "hot_focus": ["科技", "互联网", "AI", "财经"],
    "push_channel": "feishu",
    "push_target": "auto",
    "push_time": "08:00",
    "language": "zh-CN"
}

# 热点领域选项
HOT_FOCUS_OPTIONS = {
    "1": "科技",
    "2": "互联网",
    "3": "AI",
    "4": "财经",
    "5": "社会",
    "6": "娱乐",
    "7": "游戏",
    "8": "汽车",
    "9": "体育",
    "10": "教育",
    "11": "健康",
    "12": "房产",
    "13": "数码",
    "14": "时尚",
    "15": "美食"
}

# 推送渠道选项
PUSH_CHANNEL_OPTIONS = {
    "1": "feishu",
    "2": "weixin",
    "3": "both"
}


def print_banner():
    """打印配置向导标题"""
    print("\n" + "=" * 50)
    print("🌅  早间日报配置向导")
    print("=" * 50)
    print("\n欢迎使用早间日报！首次使用需要简单配置一下。\n")


def print_section(title):
    """打印配置节标题"""
    print(f"\n{'─' * 50}")
    print(f"  {title}")
    print(f"{'─' * 50}")


def get_input(prompt, default=None):
    """获取用户输入，支持默认值"""
    if default:
        full_prompt = f"{prompt}（默认：{default}）："
    else:
        full_prompt = f"{prompt}："

    try:
        user_input = input(full_prompt).strip()
        return user_input if user_input else default
    except (EOFError, KeyboardInterrupt):
        print("\n\n⚠️ 配置已取消。")
        sys.exit(1)


def select_location():
    """选择地理位置"""
    print_section("📍 地理位置配置")
    print("请输入您所在的城市/地区，用于获取天气信息。")
    print("支持格式：省份+城市+区县，如「四川省成都市温江区」")
    print("或直接输入城市名，如「北京」「上海」「深圳」等\n")

    location = get_input("📍 您的位置", DEFAULT_CONFIG["location"])
    print(f"✅ 已设置位置：{location}")
    return location


def select_hot_focus():
    """选择关注的热点领域"""
    print_section("🔍 热点领域配置")
    print("请选择您关注的热点领域（可多选），早报将优先展示这些领域的新闻。\n")

    # 显示选项
    print("可选领域：")
    for key, value in HOT_FOCUS_OPTIONS.items():
        marker = "✓" if value in DEFAULT_CONFIG["hot_focus"] else " "
        print(f"  [{marker}] {key}. {value}")

    print(f"\n默认选中：{', '.join(DEFAULT_CONFIG['hot_focus'])}")
    print("输入方式：")
    print("  • 直接回车：使用默认选项")
    print("  • 输入编号：如 1,3,5,7")
    print("  • 输入名称：如 科技,AI,汽车\n")

    user_input = get_input("🔍 关注领域", ",".join(DEFAULT_CONFIG["hot_focus"]))

    # 解析用户输入
    selected = []
    for item in user_input.split(","):
        item = item.strip()
        if item in HOT_FOCUS_OPTIONS:
            selected.append(HOT_FOCUS_OPTIONS[item])
        elif item in HOT_FOCUS_OPTIONS.values():
            selected.append(item)

    if not selected:
        selected = DEFAULT_CONFIG["hot_focus"]

    print(f"✅ 已选择：{', '.join(selected)}")
    return selected


def select_push_channel():
    """选择推送渠道"""
    print_section("📤 推送渠道配置")
    print("请选择早报推送渠道。\n")

    print("可选渠道：")
    for key, value in PUSH_CHANNEL_OPTIONS.items():
        label = {"feishu": "飞书", "weixin": "微信", "both": "两者都推送"}[value]
        marker = "✓" if value == DEFAULT_CONFIG["push_channel"] else " "
        print(f"  [{marker}] {key}. {label}")

    print(f"\n默认：飞书\n")

    user_input = get_input("📤 推送渠道", "1")

    if user_input in PUSH_CHANNEL_OPTIONS:
        channel = PUSH_CHANNEL_OPTIONS[user_input]
    elif user_input in ["feishu", "飞书", "1"]:
        channel = "feishu"
    elif user_input in ["weixin", "微信", "2"]:
        channel = "weixin"
    elif user_input in ["both", "两者", "3"]:
        channel = "both"
    else:
        channel = DEFAULT_CONFIG["push_channel"]

    label = {"feishu": "飞书", "weixin": "微信", "both": "飞书+微信"}[channel]
    print(f"✅ 已选择：{label}")
    return channel


def select_push_target():
    """选择推送目标"""
    print_section("🎯 推送目标配置")
    print("设置早报推送到哪里。\n")

    print("选项说明：")
    print("  • auto：自动推送给当前对话用户（推荐）")
    print("  • 群ID：飞书群聊的 chat_id（格式：oc_xxxx）")
    print("  • 用户ID：指定用户的 open_id（格式：ou_xxxx）\n")

    target = get_input("🎯 推送目标", DEFAULT_CONFIG["push_target"])
    print(f"✅ 已设置：{target}")
    return target


def select_push_time():
    """选择推送时间"""
    print_section("⏰ 推送时间配置")
    print("设置早报自动推送的时间（24小时制）。\n")

    time = get_input("⏰ 推送时间", DEFAULT_CONFIG["push_time"])

    # 简单验证时间格式
    if ":" not in time:
        time = DEFAULT_CONFIG["push_time"]

    print(f"✅ 已设置：每天 {time}")
    return time


def save_config(config):
    """保存配置到文件"""
    try:
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        return True
    except Exception as e:
        print(f"❌ 保存配置失败：{e}")
        return False


def load_config():
    """加载现有配置"""
    if not CONFIG_PATH.exists():
        return None

    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def check_config():
    """检查配置是否完整"""
    config = load_config()

    if not config:
        print("❌ 未找到配置文件")
        return False, None

    required_keys = ["location", "hot_focus", "push_channel", "push_target"]
    missing = [k for k in required_keys if k not in config]

    if missing:
        print(f"⚠️ 配置不完整，缺少：{', '.join(missing)}")
        return False, config

    print("✅ 配置完整")
    print(f"\n当前配置：")
    print(f"  📍 位置：{config.get('location')}")
    print(f"  🔍 关注：{', '.join(config.get('hot_focus', []))}")
    print(f"  📤 渠道：{config.get('push_channel')}")
    print(f"  🎯 目标：{config.get('push_target')}")
    print(f"  ⏰ 时间：{config.get('push_time', '08:00')}")
    return True, config


def run_interactive_setup():
    """运行交互式配置"""
    print_banner()

    # 检查现有配置
    existing = load_config()
    if existing:
        print("⚠️ 检测到已有配置：")
        print(json.dumps(existing, ensure_ascii=False, indent=2))
        print()
        confirm = input("是否重新配置？(y/N)：").strip().lower()
        if confirm not in ["y", "yes", "是"]:
            print("✅ 保留现有配置，退出向导。")
            return existing

    # 开始配置
    config = {}

    config["location"] = select_location()
    config["hot_focus"] = select_hot_focus()
    config["push_channel"] = select_push_channel()
    config["push_target"] = select_push_target()
    config["push_time"] = select_push_time()
    config["language"] = "zh-CN"

    # 保存
    print("\n" + "=" * 50)
    if save_config(config):
        print("✅ 配置已保存！")
        print(f"📁 配置文件：{CONFIG_PATH}")
        print("\n您随时可以运行以下命令修改配置：")
        print("  python3 config_setup.py --reset")
        print("\n或向我说「修改早间日报配置」")
    else:
        print("❌ 配置保存失败")

    print("=" * 50 + "\n")
    return config


def run_auto_setup():
    """使用默认配置（非交互式）"""
    config = DEFAULT_CONFIG.copy()
    save_config(config)
    print("✅ 已使用默认配置：")
    print(json.dumps(config, ensure_ascii=False, indent=2))
    return config


def main():
    """主入口"""
    import argparse

    parser = argparse.ArgumentParser(description="早间日报配置向导")
    parser.add_argument("--check", action="store_true", help="仅检查配置")
    parser.add_argument("--reset", action="store_true", help="重置配置")
    parser.add_argument("--auto", action="store_true", help="使用默认配置")
    parser.add_argument("--location", help="快速设置位置")
    parser.add_argument("--focus", help="快速设置关注领域（逗号分隔）")
    parser.add_argument("--channel", choices=["feishu", "weixin", "both"], help="推送渠道")
    parser.add_argument("--target", help="推送目标")
    parser.add_argument("--time", help="推送时间")

    args = parser.parse_args()

    # 快速配置模式
    if any([args.location, args.focus, args.channel, args.target, args.time]):
        config = load_config() or DEFAULT_CONFIG.copy()

        if args.location:
            config["location"] = args.location
        if args.focus:
            config["hot_focus"] = [f.strip() for f in args.focus.split(",")]
        if args.channel:
            config["push_channel"] = args.channel
        if args.target:
            config["push_target"] = args.target
        if args.time:
            config["push_time"] = args.time

        save_config(config)
        print("✅ 配置已更新")
        return config

    # 检查模式
    if args.check:
        ok, config = check_config()
        sys.exit(0 if ok else 1)

    # 自动模式
    if args.auto:
        return run_auto_setup()

    # 重置模式
    if args.reset:
        print("🔄 重置配置...")
        return run_interactive_setup()

    # 默认：交互式配置
    return run_interactive_setup()


if __name__ == "__main__":
    main()
