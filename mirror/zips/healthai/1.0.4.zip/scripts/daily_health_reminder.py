#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
每日健康运动提醒脚本 - 使用飞书 API
"""

import os
import json
import requests
from datetime import datetime

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

# 查找 config 目录
CONFIG_DIR = None
for base in [SCRIPT_DIR, os.path.dirname(SCRIPT_DIR), os.path.dirname(os.path.dirname(SCRIPT_DIR))]:
    config_path = os.path.join(base, "config")
    if os.path.exists(os.path.join(config_path, "user_config.json")):
        CONFIG_DIR = config_path
        break

if not CONFIG_DIR:
    CONFIG_DIR = "/Users/amitabhama/.openclaw-autoclaw/skills/HealthSkill-1.0/config"


def get_feishu_credentials():
    """从配置文件读取飞书凭证"""
    cred_path = os.path.join(CONFIG_DIR, "user_config.json")
    if os.path.exists(cred_path):
        with open(cred_path, "r") as f:
            config = json.load(f)
            return config.get("feishu_app_id", ""), config.get("feishu_app_secret", "")
    return "", ""


def get_token(app_id, app_secret):
    """获取飞书 token"""
    url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
    payload = {"app_id": app_id, "app_secret": app_secret}
    try:
        resp = requests.post(url, json=payload, timeout=10)
        data = resp.json()
        return data.get("tenant_access_token", "")
    except Exception as e:
        print(f"❌ 获取 token 失败: {e}")
        return ""


def send_message(token, user_id, message):
    """发送消息"""
    if not token or not user_id:
        print("❌ token 或 user_id 为空")
        return False

    url = "https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type=open_id"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    payload = {
        "receive_id": user_id,
        "msg_type": "text",
        "content": json.dumps({"text": message})
    }

    try:
        resp = requests.post(url, headers=headers, json=payload, timeout=10)
        data = resp.json()
        if data.get("code") == 0:
            return True
        else:
            print(f"❌ 发送失败: {data}")
            return False
    except Exception as e:
        print(f"❌ 发送异常: {e}")
        return False


def main():
    # 1. 获取凭证
    app_id, app_secret = get_feishu_credentials()
    if not app_id or not app_secret:
        print("❌ 未配置飞书凭证，请在 config/user_config.json 中设置 feishu_app_id 和 feishu_app_secret")
        return

    # 2. 获取用户 ID
    user_id = os.environ.get("FEISHU_USER_ID", "")
    if not user_id:
        config_path = os.path.join(CONFIG_DIR, "user_config.json")
        if os.path.exists(config_path):
            with open(config_path, "r") as f:
                user_id = json.load(f).get("feishu_user_id", "")

    if not user_id or user_id == "ou_your_user_id_here":
        print("❌ 未配置用户 ID")
        return

    # 3. 读取运动计划
    plan_path = os.path.join(CONFIG_DIR, "exercise_plan.json")
    with open(plan_path, "r", encoding="utf-8") as f:
        plan = json.load(f)

    day_map = {0: "周一", 1: "周二", 2: "周三", 3: "周四", 4: "周五", 5: "周六", 6: "周日"}
    day_name = day_map[datetime.now().weekday()]

    weekly = plan.get("weekly_plan", plan)
    day_data = weekly.get(day_name, {})
    morning = day_data.get("早上", {})
    afternoon = day_data.get("下午", {})

    # 4. 构建消息
    msg = f"🏃 每日运动提醒（{day_name}）\n\n"
    msg += f"早上：\n"
    msg += f"  运动：{morning.get('运动', '休息')}\n"
    msg += f"  时长：{morning.get('时长', '-')}\n"
    msg += f"  目的：{morning.get('目的', '-')}"

    video = morning.get("video", "")
    if video:
        msg += f"\n  视频：{video}"

    if afternoon.get("运动") and afternoon.get("运动") != "休息":
        msg += f"\n\n下午：\n"
        msg += f"  运动：{afternoon.get('运动')}\n"
        msg += f"  时长：{afternoon.get('时长', '-')}\n"
        msg += f"  目的：{afternoon.get('目的', '-')}"

    msg += f"\n\n💪 坚持就是胜利！"

    # 5. 发送
    token = get_token(app_id, app_secret)
    if not token:
        print("❌ 获取 token 失败")
        return

    print(f"发送运动提醒给用户: {user_id}")
    if send_message(token, user_id, msg):
        print("✅ 消息发送成功")
    else:
        print("❌ 消息发送失败")


if __name__ == "__main__":
    main()
