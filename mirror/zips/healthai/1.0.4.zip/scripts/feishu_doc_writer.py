#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
飞书文档写入器 - 统一格式
"""

import json
from datetime import datetime

# 卡路里计算（估算）
CALORIE_RATE = {
    "走路": 4.5,      # 每分钟
    "步行": 4.5,
    "跑步": 11.0,
    "俯卧撑": 8.0,
    "力量训练": 7.0,
    "拉伸": 3.0,
    "瑜伽": 4.0,
    "八段锦": 4.0,
    "太极": 4.0,
    "晒太阳": 1.7,   # 每分钟（很少，主要是促进维生素D）
    "户外活动": 5.0,
    "骑行": 8.0,
    "游泳": 10.0,
}

def calculate_calories(duration, sport_type):
    """自动计算卡路里"""
    rate = CALORIE_RATE.get(sport_type, 5.0)  # 默认5卡/分钟
    return int(duration * rate)

def format_checkin_doc(user_id, checkin_data, weight=None):
    """格式化打卡记录为表格"""
    
    date = datetime.now().strftime("%Y-%m-%d（周%s）" % ["一","二","三","四","五","六","日"][datetime.now().weekday()])
    
    # 计算总卡路里
    total_calories = 0
    for record in checkin_data.get("records", []):
        duration = record.get("运动时长", 0)
        sport = record.get("运动类型", "")
        total_calories += calculate_calories(duration, sport)
    
    # 获取运动类型列表
    sports = [r.get("运动项目", "") for r in checkin_data.get("records", [])]
    sports_str = "+".join([s for s in sports if s]) if sports else "-"
    
    # 构建表格内容
    markdown = f"""
---

## {date}

|lark-table rows="9" cols="3" header-row="true" column-widths="200,200,200"|

|lark-tr|\n|lark-td|项目|\n|lark-td|数据|\n|lark-td|状态|\n|/lark-tr|\n

|lark-tr|\n|lark-td|步数|\n|lark-td|{checkin_data.get('总步数', 0)} 步|\n|lark-td|{'✅ 超额(目标8000)' if checkin_data.get('总步数', 0) >= 8000 else '⚠️ 未达标'}|\n|/lark-tr|\n

|lark-tr|\n|lark-td|运动时长|\n|lark-td|{checkin_data.get('总运动时长', 0)} 分钟|\n|lark-td|{'✅' if checkin_data.get('总运动时长', 0) >= 60 else '⚠️'}|\n|/lark-tr|\n

|lark-tr|\n|lark-td|运动类型|\n|lark-td|{sports_str}|\n|lark-td|-|\n|/lark-tr|\n

|lark-tr|\n|lark-td|卡路里消耗|\n|lark-td|约 {total_calories} 卡|\n|lark-td|-|\n|/lark-tr|\n

|lark-tr|\n|lark-td|打卡次数|\n|lark-td|{checkin_data.get('打卡次数', 0)} 次|\n|lark-td|-|\n|/lark-tr|\n

|lark-tr|\n|lark-td|体重|\n|lark-td|{weight} kg|\n|lark-td|{'-' if not weight else '⚖️'}|\n|/lark-tr|\n

**运动详情：**
"""
    
    # 添加每条运动详情
    for i, record in enumerate(checkin_data.get("records", []), 1):
        sport = record.get("运动项目", "-")
        duration = record.get("运动时长", 0)
        steps = record.get("步数", 0)
        notes = record.get("备注", "")
        mode = record.get("模式", "新增")
        
        detail = f"\n{i}. {sport}"
        if duration:
            detail += f" - {duration}分钟"
        if steps:
            detail += f" - {steps}步"
        if notes:
            detail += f" ({notes})"
        
        markdown += detail
    
    markdown += f"\n\n---\n*每天更新*"
    
    return markdown

# 测试
if __name__ == "__main__":
    test_data = {
        "总步数": 10300,
        "总运动时长": 130,
        "打卡次数": 3,
        "records": [
            {"运动项目": "走路", "运动时长": 60, "步数": 10300, "运动类型": "走路/步行"},
            {"运动项目": "俯卧撑", "运动时长": 10, "运动类型": "力量训练"},
            {"运动项目": "晒太阳", "运动时长": 60, "运动类型": "户外活动"},
        ]
    }
    
    result = format_checkin_doc("test", test_data, 68.85)
    print(result)
