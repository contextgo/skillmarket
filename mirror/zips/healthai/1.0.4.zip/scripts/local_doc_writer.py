#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
本地文档写入器 v2.0 - 写到 Downloads 文件夹
不需要用户ID，直接写到当前设备的 Downloads 目录
"""

import json
import os
from datetime import datetime
from pathlib import Path

# Downloads 文件夹路径
DOWNLOADS_DIR = Path.home() / "Downloads" / "HealthSkill2.0"
DATA_DIR = DOWNLOADS_DIR / "data"
CHECKINS_DIR = DATA_DIR / "checkins"
HEALTH_DIR = DATA_DIR / "health"
PLANS_DIR = DATA_DIR / "plans"

# 确保目录存在
for d in [DATA_DIR, CHECKINS_DIR, HEALTH_DIR, PLANS_DIR]:
    d.mkdir(parents=True, exist_ok=True)


# 卡路里计算（估算）
CALORIE_RATE = {
    "走路": 4.5,      # 每分钟
    "步行": 4.5,
    "跑步": 11.0,
    "俯卧撑": 8.0,
    "力量训练": 7.0,
    "拉伸": 3.0,
    "瑜伽": 4.0,
    "八段锦": 4.0,
    "太极": 4.0,
    "晒太阳": 1.7,   # 每分钟
    "户外活动": 5.0,
    "骑行": 8.0,
    "游泳": 10.0,
}

def calculate_calories(duration, sport_type):
    """自动计算卡路里"""
    rate = CALORIE_RATE.get(sport_type, 5.0)
    return int(duration * rate)


def save_checkin(date=None, **data):
    """保存打卡记录到本地"""
    if date is None:
        date = datetime.now().strftime("%Y-%m-%d")
    
    year_month = date[:7]
    checkin_file = CHECKINS_DIR / f"{year_month}.json"
    
    # 加载已有数据
    if checkin_file.exists():
        with open(checkin_file, "r", encoding="utf-8") as f:
            checkins = json.load(f)
    else:
        checkins = {}
    
    # 如果当天已有记录，追加
    if date in checkins:
        if "records" not in checkins[date]:
            checkins[date] = {"records": [], "打卡次数": 0, "总运动时长": 0, "总步数": 0}
        
        checkins[date]["records"].append({
            "timestamp": datetime.now().isoformat(),
            "运动项目": data.get("运动项目", ""),
            "运动时长": data.get("运动时长", 0),
            "运动类型": data.get("运动类型", ""),
            "步数": data.get("步数", 0),
            "备注": data.get("备注", "")
        })
        
        # 更新汇总
        checkins[date]["打卡次数"] = len(checkins[date]["records"])
        checkins[date]["总运动时长"] = sum(r.get("运动时长", 0) for r in checkins[date]["records"])
        checkins[date]["总步数"] = sum(r.get("步数", 0) for r in checkins[date]["records"])
        checkins[date]["完成状态"] = "已完成"
    else:
        checkins[date] = {
            "date": date,
            "records": [{
                "timestamp": datetime.now().isoformat(),
                "运动项目": data.get("运动项目", ""),
                "运动时长": data.get("运动时长", 0),
                "运动类型": data.get("运动类型", ""),
                "步数": data.get("步数", 0),
                "备注": data.get("备注", "")
            }],
            "打卡次数": 1,
            "总运动时长": data.get("运动时长", 0),
            "总步数": data.get("步数", 0),
            "完成状态": "已完成"
        }
    
    # 保存
    with open(checkin_file, "w", encoding="utf-8") as f:
        json.dump(checkins, f, ensure_ascii=False, indent=2)
    
    return {
        "success": True,
        "path": str(checkin_file),
        "date": date
    }


def load_checkins(year_month=None):
    """加载打卡记录"""
    if year_month is None:
        year_month = datetime.now().strftime("%Y-%m")
    
    checkin_file = CHECKINS_DIR / f"{year_month}.json"
    
    if checkin_file.exists():
        with open(checkin_file, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


def generate_weekly_report(week_data):
    """生成周报"""
    if not week_data:
        return "本周暂无打卡记录"
    
    total_days = len(week_data)
    total_duration = 0
    total_steps = 0
    total_calories = 0
    checkin_count = 0
    
    report = "📊 **本周运动总结**\n\n"
    
    for date, data in sorted(week_data.items()):
        checkin_count += data.get("打卡次数", 0)
        duration = data.get("总运动时长", 0)
        steps = data.get("总步数", 0)
        
        total_duration += duration
        total_steps += steps
        
        # 计算当天卡路里
        for record in data.get("records", []):
            sport = record.get("运动类型", "")
            d = record.get("运动时长", 0)
            total_calories += calculate_calories(d, sport)
        
        day_name = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"][datetime.strptime(date, "%Y-%m-%d").weekday()]
        report += f"📅 {date} ({day_name}): {duration}分钟, {steps}步\n"
    
    report += f"\n**本周总计:**\n"
    report += f"  🏃 运动天数: {total_days}天\n"
    report += f"  ⏱️ 总时长: {total_duration}分钟\n"
    report += f"  👣 总步数: {total_steps}步\n"
    report += f"  🔥 消耗热量: 约{total_calories}卡\n"
    report += f"  📝 打卡次数: {checkin_count}次\n"
    
    return report


def generate_monthly_report(year_month, month_data=None):
    """生成月报"""
    if month_data is None:
        month_data = load_checkins(year_month)
    
    if not month_data:
        return f"{year_month}月暂无打卡记录"
    
    total_duration = 0
    total_steps = 0
    total_calories = 0
    checkin_count = 0
    
    report = f"📊 **{year_month}月运动总结**\n\n"
    
    for date, data in sorted(month_data.items()):
        checkin_count += data.get("打卡次数", 0)
        duration = data.get("总运动时长", 0)
        steps = data.get("总步数", 0)
        
        total_duration += duration
        total_steps += steps
        
        for record in data.get("records", []):
            sport = record.get("运动类型", "")
            d = record.get("运动时长", 0)
            total_calories += calculate_calories(d, sport)
    
    report += f"**本月总计:**\n"
    report += f"  🏃 运动天数: {len(month_data)}天\n"
    report += f"  ⏱️ 总时长: {total_duration}分钟\n"
    report += f"  👣 总步数: {total_steps}步\n"
    report += f"  🔥 消耗热量: 约{total_calories}卡\n"
    report += f"  📝 打卡次数: {checkin_count}次\n"
    
    # 计算平均
    if month_data:
        avg_duration = total_duration / len(month_data)
        avg_steps = total_steps / len(month_data)
        report += f"\n**日均:**\n"
        report += f"  ⏱️ {avg_duration:.0f}分钟\n"
        report += f"  👣 {avg_steps:.0f}步\n"
    
    return report


def save_health_data(indicators, source="text"):
    """保存体检数据"""
    from indicator_extractor import save_health_record
    return save_health_record("local", indicators, source)


def save_exercise_plan(plan):
    """保存运动计划"""
    plan_file = PLANS_DIR / "current_plan.json"
    plan["updated_at"] = datetime.now().isoformat()
    
    with open(plan_file, "w", encoding="utf-8") as f:
        json.dump(plan, f, ensure_ascii=False, indent=2)
    
    return {"success": True, "path": str(plan_file)}


def load_exercise_plan():
    """加载运动计划"""
    plan_file = PLANS_DIR / "current_plan.json"
    
    if plan_file.exists():
        with open(plan_file, "r", encoding="utf-8") as f:
            return json.load(f)
    return None


# 测试
if __name__ == "__main__":
    print("=== 测试打卡 ===")
    result = save_checkin(运动项目="八段锦", 运动时长=30, 步数=5000, 运动类型="传统运动")
    print(f"已保存到: {result['path']}")
    
    print("\n=== 测试加载 ===")
    data = load_checkins()
    print(json.dumps(data, ensure_ascii=False, indent=2))
    
    print("\n=== 测试周报 ===")
    print(generate_weekly_report(data))
    
    print("\n=== 测试月报 ===")
    print(generate_monthly_report(datetime.now().strftime("%Y-%m"), data))
