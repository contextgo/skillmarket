#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
营养建议 Agent
根据用户状态提供饮食建议
"""

import json
from datetime import datetime


class NutritionAgent:
    """营养建议 Agent"""
    
    def __init__(self):
        # 异常指标对应的饮食建议
        self.nutrition_guides = {
            "血压": {
                "要多吃": ["芹菜", "西红柿", "香蕉", "黑木耳", "绿茶"],
                "要少吃": ["盐", "腌制品", "腊肉", "酱油", "味精"],
                "advice": "控制钠盐摄入，每天不超过5克"
            },
            "血糖": {
                "要多吃": ["粗粮", "蔬菜", "魔芋", "山药", "桑叶"],
                "要少吃": ["白米", "白面", "糖", "甜食", "高GI食物"],
                "advice": "少食多餐，避免血糖波动"
            },
            "血脂": {
                "要多吃": ["深海鱼", "坚果", "橄榄油", "燕麦", "豆制品"],
                "要少吃": ["动物内脏", "肥肉", "蛋黄", "油炸食品"],
                "advice": "增加膳食纤维摄入"
            },
            "尿酸": {
                "要多吃": ["蔬菜", "水果", "牛奶", "鸡蛋", "苏打水"],
                "要少吃": ["海鲜", "动物内脏", "浓汤", "啤酒", "豆制品"],
                "advice": "多喝水，每天2000ml以上"
            },
            "BMI": {
                "要多吃": ["蔬菜", "粗粮", "瘦肉", "水果"],
                "要少吃": ["高热量", "油炸", "甜食", "零食"],
                "advice": "控制总热量，适量运动"
            },
            "脂肪肝": {
                "要多吃": ["蔬菜", "水果", "粗粮", "鱼肉"],
                "要少吃": ["肥肉", "动物内脏", "酒精", "甜食"],
                "advice": "戒酒，控制体重"
            }
        }
        
        # 阶段对应的饮食策略
        self.stage_diets = {
            "调整期": "以清淡易消化为主，少食多餐",
            "适应期": "均衡饮食，逐步增加营养",
            "基础期": "注重蛋白质摄入，配合运动",
            "稳定期": "保持均衡，适量补充",
            "进阶期": "高蛋白低脂，注重恢复",
            "精英期": "专业营养配比，精准补充"
        }
    
    def get_advice(self, user_state):
        """
        获取营养建议
        输入：用户状态
        输出：个性化饮食建议
        """
        abnormal = user_state.get("abnormal", [])
        stage = user_state.get("current_stage", "适应期")
        
        # 收集所有饮食建议
        all_guides = []
        for item in abnormal:
            indicator = item.get("indicator", "")
            if indicator in self.nutrition_guides:
                all_guides.append({
                    "target": indicator,
                    **self.nutrition_guides[indicator]
                })
        
        # 合并相同指标的饮食建议
        food_recommendations = self.merge_recommendations(all_guides)
        
        # 获取阶段饮食策略
        stage_strategy = self.stage_diets.get(stage, self.stage_diets["适应期"])
        
        # 生成每日建议
        daily_advice = self.generate_daily_advice(user_state, food_recommendations)
        
        return {
            "success": True,
            "generated_at": datetime.now().isoformat(),
            "stage": stage,
            "stage_strategy": stage_strategy,
            "food_recommendations": food_recommendations,
            "daily_advice": daily_advice,
            "calories_target": self.calculate_calories(user_state),
            "tips": self.generate_tips(abnormal, stage)
        }
    
    def merge_recommendations(self, guides):
        """合并饮食建议"""
        foods_to_eat = set()
        foods_to_avoid = set()
        specific_advice = []
        
        for guide in guides:
            if "要多吃" in guide:
                foods_to_eat.update(guide["要多吃"])
            if "要少吃" in guide:
                foods_to_avoid.update(guide["要少吃"])
            if "advice" in guide:
                specific_advice.append(guide["advice"])
        
        return {
            "to_eat": list(foods_to_eat),
            "to_avoid": list(foods_to_avoid),
            "specific_advice": specific_advice
        }
    
    def calculate_calories(self, user_state):
        """计算每日热量目标"""
        # 基础代谢 + 活动消耗
        # 简化估算
        weight = user_state.get("indicators", {}).get("体重", {}).get("value", 70)
        stage = user_state.get("current_stage", "适应期")
        
        # 基础代谢 (简单估算)
        bmr = weight * 24
        
        # 活动系数
        activity_factors = {
            "调整期": 1.2,
            "适应期": 1.3,
            "基础期": 1.4,
            "稳定期": 1.4,
            "进阶期": 1.5,
            "精英期": 1.6
        }
        
        activity = activity_factors.get(stage, 1.3)
        target = int(bmr * activity)
        
        return {
            "maintain": target,
            "mild_deficit": target - 300,  # 轻度减脂
            "moderate_deficit": target - 500  # 中度减脂
        }
    
    def generate_daily_advice(self, user_state, recommendations):
        """生成每日饮食建议"""
        stage = user_state.get("current_stage", "适应期")
        calories = self.calculate_calories(user_state)
        
        advice = f"""
📋 每日饮食建议

🍳 早餐（占30%）
- 主食：粗粮粥或全麦面包
- 蛋白：鸡蛋、牛奶
- 蔬果：新鲜蔬菜或水果

🥗 午餐（占40%）
- 主食：糙米或杂粮饭
- 蛋白：瘦肉、鱼、豆制品
- 蔬菜：多样化蔬菜

🍽️ 晚餐（占30%）
- 主食：少量主食或不吃
- 蛋白：清淡蛋白
- 蔬菜：大量蔬菜

💧 饮水：每天2000ml以上
"""
        return advice.strip()
    
    def generate_tips(self, abnormal, stage):
        """生成小贴士"""
        tips = []
        
        # 阶段相关
        if stage in ["调整期", "适应期"]:
            tips.append("饮食要循序渐进，不要一下子改变太大")
        
        # 指标相关
        indicators = [a.get("indicator") for a in abnormal]
        if "血糖" in indicators:
            tips.append("注意餐后血糖，避免血糖波动")
        if "血脂" in indicators:
            tips.append("烹调方式以蒸煮为主，少油炸")
        if "尿酸" in indicators:
            tips.append("避免高嘌呤食物，多喝水")
        
        # 通用
        tips.append("规律进食，不要暴饮暴食")
        tips.append("细嚼慢咽，有助于消化")
        
        return tips


# 测试
if __name__ == "__main__":
    agent = NutritionAgent()
    
    user_state = {
        "current_stage": "适应期",
        "abnormal": [
            {"indicator": "血脂"},
            {"indicator": "BMI"}
        ],
        "indicators": {
            "体重": {"value": 75}
        }
    }
    
    result = agent.get_advice(user_state)
    print(json.dumps(result, ensure_ascii=False, indent=2))
