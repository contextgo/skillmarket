#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
体检分析 Agent
分析用户体检报告，提取指标，检测异常，评估风险
"""

import json
import re
from datetime import datetime
from pathlib import Path

# 体检指标标准参考值
INDICATOR_STANDARDS = {
    # 常规项目
    "体重": {"min": 45, "max": 85, "unit": "kg"},
    "BMI": {"min": 18.5, "max": 24, "unit": ""},
    "体脂率": {"min": 10, "max": 25, "unit": "%"},
    
    # 血压
    "收缩压": {"min": 90, "max": 140, "unit": "mmHg"},
    "舒张压": {"min": 60, "max": 90, "unit": "mmHg"},
    "血压": {"min": 90, "max": 140, "unit": "mmHg"},
    
    # 血糖
    "空腹血糖": {"min": 3.9, "max": 6.1, "unit": "mmol/L"},
    "血糖": {"min": 3.9, "max": 6.1, "unit": "mmol/L"},
    "糖化血红蛋白": {"min": 4, "max": 6, "unit": "%"},
    
    # 血脂
    "总胆固醇": {"min": 2.8, "max": 5.7, "unit": "mmol/L"},
    "甘油三酯": {"min": 0.5, "max": 1.7, "unit": "mmol/L"},
    "高密度脂蛋白": {"min": 1.0, "max": 2.0, "unit": "mmol/L"},
    "低密度脂蛋白": {"min": 0, "max": 3.4, "unit": "mmol/L"},
    "血脂": {"min": 0, "max": 1.7, "unit": "mmol/L"},
    
    # 肝功能
    "谷丙转氨酶": {"min": 0, "max": 50, "unit": "U/L"},
    "谷草转氨酶": {"min": 0, "max": 40, "unit": "U/L"},
    "肝功能": {"min": 0, "max": 50, "unit": "U/L"},
    
    # 肾功能
    "肌酐": {"min": 44, "max": 133, "unit": "umol/L"},
    "尿素氮": {"min": 2.9, "max": 8.2, "unit": "mmol/L"},
    "尿酸": {"min": 150, "max": 440, "unit": "umol/L"},
    
    # 血常规
    "血红蛋白": {"min": 120, "max": 160, "unit": "g/L"},
    "白细胞": {"min": 4, "max": 10, "unit": "10^9/L"},
    "血小板": {"min": 100, "max": 300, "unit": "10^9/L"},
    
    # 甲状腺
    "TSH": {"min": 0.27, "max": 4.2, "unit": "mIU/L"},
    "T3": {"min": 1.3, "max": 3.1, "unit": "nmol/L"},
    "T4": {"min": 66, "max": "181", "unit": "nmol/L"},
    
    # 心电图
    "心率": {"min": 60, "max": 100, "unit": "bpm"},
}

# 异常指标对应的健康问题
INDICATOR_ISSUES = {
    "体重": "需要控制体重",
    "BMI": "体重指数异常",
    "体脂率": "体脂率偏高",
    "收缩压": "高血压风险",
    "舒张压": "高血压风险",
    "血压": "血压异常",
    "空腹血糖": "血糖异常，可能糖尿病前期",
    "血糖": "血糖异常",
    "糖化血红蛋白": "血糖控制不佳",
    "总胆固醇": "血脂偏高",
    "甘油三酯": "血脂偏高",
    "高密度脂蛋白": "血脂异常",
    "低密度脂蛋白": "血脂偏高",
    "血脂": "血脂异常",
    "谷丙转氨酶": "肝功能异常",
    "谷草转氨酶": "肝功能异常",
    "肝功能": "肝功能异常",
    "肌酐": "肾功能异常",
    "尿素氮": "肾功能异常",
    "尿酸": "尿酸偏高，需注意痛风风险",
    "血红蛋白": "贫血风险",
    "白细胞": "免疫系统异常",
    "血小板": "凝血功能异常",
    "心率": "心率异常",
}


class PhysicalExamAgent:
    """体检分析 Agent"""
    
    def __init__(self):
        self.standards = INDICATOR_STANDARDS
        self.issues = INDICATOR_ISSUES
    
    def analyze(self, report_text):
        """
        分析体检报告
        输入：报告文本
        输出：分析结果字典
        """
        # 1. 提取指标
        indicators = self.extract_indicators(report_text)
        
        # 2. 异常检测
        abnormal = self.detect_abnormal(indicators)
        
        # 3. 风险评估
        risk_level = self.assess_risk(abnormal)
        
        # 4. 优先级排序
        priority = self.prioritize(abnormal)
        
        # 5. 计算健康分数
        health_score = self.calculate_health_score(indicators)
        
        return {
            "success": True,
            "analyzed_at": datetime.now().isoformat(),
            "indicators": indicators,
            "abnormal": abnormal,
            "risk_level": risk_level,
            "priority": priority,
            "health_score": health_score,
            "summary": self.generate_summary(abnormal, risk_level, health_score)
        }
    
    def extract_indicators(self, text):
        """从文本中提取指标"""
        indicators = {}
        text = str(text)
        
        # 匹配常见指标格式：指标名: 数值 单位 或 指标名 数值 单位
        patterns = [
            r'([体重BMI体脂率收缩压舒张压血压空腹血糖血糖糖化血红蛋白总胆固醇甘油三酯高密度脂蛋白低密度脂蛋白谷丙转氨酶谷草转氨酶肝功能肌酐尿素氮尿酸血红蛋白白细胞血小板心率TSHT3T4]+)[:\s]*(\d+\.?\d*)\s*([a-zA-Z%/°]+)?',
            r'(收缩压|舒张压|空腹血糖|总胆固醇|甘油三酯)[/:：]\s*(\d+\.?\d*)\s*/\s*(\d+\.?\d*)\s*([mmHg%]+)?',
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, text)
            for match in matches:
                if len(match) >= 2:
                    name = match[0].strip()
                    value = match[1].strip()
                    unit = match[2].strip() if len(match) > 2 else ""
                    
                    try:
                        if name in ["收缩压", "舒张压"]:
                            # 血压格式：收缩压/舒张压
                            if len(match) >= 4:
                                indicators[name] = {
                                    "value": float(value),
                                    "unit": "mmHg"
                                }
                        else:
                            indicators[name] = {
                                "value": float(value),
                                "unit": unit if unit else self.standards.get(name, {}).get("unit", "")
                            }
                    except ValueError:
                        continue
        
        # 特殊处理血压同时存在的情况
        bp_match = re.findall(r'血压[/:：]\s*(\d+)/(\d+)\s*(mmHg)?', text)
        if bp_match:
            indicators["收缩压"] = {"value": float(bp_match[0][0]), "unit": "mmHg"}
            indicators["舒张压"] = {"value": float(bp_match[0][1]), "unit": "mmHg"}
        
        return indicators
    
    def detect_abnormal(self, indicators):
        """检测异常指标"""
        abnormal = []
        
        for name, data in indicators.items():
            value = data.get("value")
            standard = self.standards.get(name)
            
            if not standard or value is None:
                continue
            
            is_high = value > standard["max"]
            is_low = value < standard["min"]
            
            if is_high or is_low:
                direction = "偏高" if is_high else "偏低"
                normal_range = f"{standard['min']}-{standard['max']}"
                
                abnormal.append({
                    "indicator": name,
                    "value": value,
                    "unit": data.get("unit", ""),
                    "normal_range": normal_range,
                    "status": direction,
                    "issue": self.issues.get(name, "需要关注"),
                    "severity": self.calculate_severity(name, value, standard)
                })
        
        return abnormal
    
    def calculate_severity(self, name, value, standard):
        """计算严重程度"""
        if name in ["血压", "血糖", "血脂", "尿酸"]:
            # 这些是重点关注的慢性病指标
            range_size = standard["max"] - standard["min"]
            deviation = abs(value - (standard["max"] + standard["min"]) / 2) / range_size
            if deviation > 0.5:
                return "high"
            elif deviation > 0.25:
                return "medium"
            else:
                return "low"
        elif name in ["BMI", "体脂率"]:
            if value > standard["max"] * 1.2 or value < standard["min"] * 0.8:
                return "high"
            elif value > standard["max"] * 1.1 or value < standard["min"] * 0.9:
                return "medium"
            else:
                return "low"
        else:
            return "low"
    
    def assess_risk(self, abnormal):
        """评估风险等级"""
        if not abnormal:
            return "none"
        
        high_count = sum(1 for a in abnormal if a.get("severity") == "high")
        medium_count = sum(1 for a in abnormal if a.get("severity") == "medium")
        
        if high_count >= 2:
            return "high"
        elif high_count >= 1 or medium_count >= 3:
            return "medium"
        elif medium_count >= 1 or len(abnormal) >= 2:
            return "low"
        else:
            return "minimal"
    
    def prioritize(self, abnormal):
        """优先级排序：先处理高风险、有并发症的指标"""
        priority_order = {
            "high": 0,
            "medium": 1,
            "low": 2
        }
        
        # 按严重程度+慢性病相关性排序
        critical_indicators = ["血压", "血糖", "血脂", "尿酸", "BMI"]
        
        sorted_abnormal = sorted(
            abnormal,
            key=lambda x: (
                priority_order.get(x.get("severity"), 3),
                0 if x.get("indicator") in critical_indicators else 1
            )
        )
        
        return [a.get("indicator") for a in sorted_abnormal]
    
    def calculate_health_score(self, indicators):
        """计算健康分数 (0-100)"""
        if not indicators:
            return 50  # 无数据给中等分
        
        total_score = 0
        count = 0
        
        for name, data in indicators.items():
            value = data.get("value")
            standard = self.standards.get(name)
            
            if not standard or value is None:
                continue
            
            # 计算偏离程度
            mid = (standard["max"] + standard["min"]) / 2
            range_size = standard["max"] - standard["min"]
            
            if range_size == 0:
                continue
            
            deviation = abs(value - mid) / (range_size / 2)
            # 偏离0-50%得100-60分，偏离50-100%得60-20分
            if deviation <= 0.5:
                score = 100 - deviation * 80  # 100-60
            else:
                score = 60 - (deviation - 0.5) * 80  # 60-20
            
            total_score += max(0, score)
            count += 1
        
        return int(total_score / count) if count > 0 else 50
    
    def generate_summary(self, abnormal, risk_level, health_score):
        """生成总结"""
        if not abnormal:
            return "体检指标基本正常，请继续保持健康生活方式！"
        
        high_abnormal = [a for a in abnormal if a.get("severity") == "high"]
        
        if risk_level == "high":
            return f"发现 {len(abnormal)} 项异常，其中 {len(high_abnormal)} 项严重。建议优先改善：{', '.join(self.prioritize(abnormal)[:3])}"
        elif risk_level == "medium":
            return f"发现 {len(abnormal)} 项指标异常，建议关注：{', '.join(self.prioritize(abnormal)[:2])}"
        else:
            return f"体检发现 {len(abnormal)} 项指标需要关注，整体风险较低。"


# 测试
if __name__ == "__main__":
    agent = PhysicalExamAgent()
    
    test_report = """
    体检日期：2026-03-15
    体重：75kg
    BMI：25.3
    血压：135/88mmHg
    空腹血糖：5.8mmol/L
    总胆固醇：6.2mmol/L
    甘油三酯：2.1mmol/L
    低密度脂蛋白：3.8mmol/L
    谷丙转氨酶：45U/L
    尿酸：480umol/L
    """
    
    result = agent.analyze(test_report)
    print(json.dumps(result, ensure_ascii=False, indent=2))
