#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
打卡评估 Agent
评估用户打卡情况，判断是否需要调整方案
"""

import json
from datetime import datetime, timedelta
from collections import Counter


class CheckinEvaluatorAgent:
    """打卡评估 Agent"""
    
    def __init__(self):
        self.feeling_weights = {
            "excellent": 100,
            "great": 85,
            "good": 70,
            "normal": 50,
            "tired": 30,
            "very_tired": 10
        }
    
    def evaluate(self, checkin_history, feeling=None):
        """
        评估打卡情况
        输入：打卡历史 + 体感反馈
        输出：评估结果
        """
        # 1. 计算完成度
        completion = self.calc_completion(checkin_history)
        
        # 2. 体感分析
        feeling_score = self.analyze_feeling(checkin_history, feeling)
        
        # 3. 进步检测
        progress = self.detect_progress(checkin_history)
        
        # 4. 连续性分析
        streak = self.calc_streak(checkin_history)
        
        # 5. 综合评分
        total_score = completion * 0.35 + feeling_score * 0.35 + progress * 0.2 + streak * 0.1
        
        # 6. 决策判断
        should_upgrade = total_score >= 80 and progress > 0
        should_downgrade = total_score < 40 or feeling == "very_tired"
        should_maintain = 40 <= total_score < 80
        
        # 7. 生成建议
        suggestion = self.get_suggestion(total_score, feeling, progress, completion)
        
        return {
            "success": True,
            "evaluated_at": datetime.now().isoformat(),
            "completion_rate": round(completion, 2),
            "feeling_score": round(feeling_score, 2),
            "progress_score": round(progress, 2),
            "streak_score": round(streak, 2),
            "total_score": round(total_score, 2),
            "should_upgrade": should_upgrade,
            "should_downgrade": should_downgrade,
            "should_maintain": should_maintain,
            "streak_days": streak,
            "suggestion": suggestion,
            "alerts": self.get_alerts(checkin_history, feeling)
        }
    
    def calc_completion(self, checkin_history):
        """计算完成度"""
        if not checkin_history:
            return 0.0
        
        total_planned = 0
        total_completed = 0
        
        for date, data in checkin_history.items():
            planned = data.get("planned_duration", 60)
            actual = data.get("total_duration", 0)
            
            total_planned += planned
            total_completed += min(actual, planned)  # 不超过计划
        
        if total_planned == 0:
            return 0.0
        
        return min(1.0, total_completed / total_planned)
    
    def analyze_feeling(self, checkin_history, feeling=None):
        """分析体感"""
        # 优先使用传入的 feeling
        if feeling:
            return self.feeling_weights.get(feeling, 50) / 100
        
        # 否则从历史记录分析
        feelings = []
        for date, data in checkin_history.items():
            f = data.get("feeling")
            if f:
                feelings.append(f)
        
        if not feelings:
            return 0.5  # 无数据给中等分
        
        # 计算加权平均
        total_weight = 0
        weighted_sum = 0
        for f in feelings:
            weight = self.feeling_weights.get(f, 50)
            weighted_sum += weight
            total_weight += 1
        
        return (weighted_sum / total_weight) / 100 if total_weight > 0 else 0.5
    
    def detect_progress(self, checkin_history):
        """检测进步"""
        if len(checkin_history) < 3:
            return 0.5  # 数据不够，给中等分
        
        # 按日期排序
        sorted_data = sorted(checkin_history.items(), key=lambda x: x[0])
        
        # 比较前半和后半的完成度
        mid = len(sorted_data) // 2
        first_half = sorted_data[:mid]
        second_half = sorted_data[mid:]
        
        first_completion = sum(d.get("completion", 0) for d in first_half) / len(first_half) if first_half else 0
        second_completion = sum(d.get("completion", 0) for d in second_half) / len(second_half) if second_half else 0
        
        # 进步幅度
        if second_completion > first_completion:
            return min(1.0, 0.5 + (second_completion - first_completion) * 2)
        elif second_completion < first_completion:
            return max(0.0, 0.5 - (first_completion - second_completion) * 2)
        else:
            return 0.5
    
    def calc_streak(self, checkin_history):
        """计算连续性得分"""
        if not checkin_history:
            return 0.0
        
        # 找出连续打卡天数
        today = datetime.now().date()
        streak = 0
        
        for i in range(30):  # 最多看30天
            check_date = (today - timedelta(days=i)).strftime("%Y-%m-%d")
            if check_date in checkin_history:
                streak += 1
            else:
                break
        
        # 转换为得分（21天满分）
        return min(1.0, streak / 21)
    
    def get_suggestion(self, total_score, feeling, progress, completion):
        """生成建议"""
        suggestions = []
        
        if total_score >= 85:
            suggestions.append("表现优秀！可以考虑升级运动方案")
        elif total_score >= 70:
            suggestions.append("保持得很好！继续坚持")
        elif total_score >= 50:
            suggestions.append("还行，继续保持规律")
        elif total_score >= 30:
            suggestions.append("有点懈怠了，需要调整状态")
        else:
            suggestions.append("状态不佳，建议休息或降低强度")
        
        if feeling == "tired" or feeling == "very_tired":
            suggestions.append("检测到疲劳，注意休息")
        
        if progress < 0:
            suggestions.append("有退步迹象，建议分析原因")
        
        if completion < 0.5:
            suggestions.append("完成度偏低，尝试降低每日目标")
        
        return suggestions
    
    def get_alerts(self, checkin_history, feeling):
        """获取提醒"""
        alerts = []
        
        # 疲劳警告
        if feeling in ["tired", "very_tired"]:
            alerts.append({
                "type": "fatigue",
                "level": "warning",
                "message": "检测到疲劳信号，建议降低强度或休息"
            })
        
        # 连续未打卡
        today = datetime.now().date()
        yesterday = (today - timedelta(days=1)).strftime("%Y-%m-%d")
        
        if yesterday not in checkin_history and today not in checkin_history:
            alerts.append({
                "type": "absence",
                "level": "info",
                "message": "已经连续2天没有打卡了"
            })
        
        # 完成度突变
        if len(checkin_history) >= 3:
            recent = list(checkin_history.items())[-3:]
            recent_completion = [d.get("completion", 0) for d in recent]
            if all(c < 0.5 for c in recent_completion):
                alerts.append({
                    "type": "low_motivation",
                    "level": "warning",
                    "message": "近期完成度持续偏低，需要调整"
                })
        
        return alerts


# 测试
if __name__ == "__main__":
    agent = CheckinEvaluatorAgent()
    
    test_history = {
        "2026-04-15": {"planned_duration": 60, "total_duration": 55, "completion": 0.9, "feeling": "good"},
        "2026-04-16": {"planned_duration": 60, "total_duration": 60, "completion": 1.0, "feeling": "great"},
        "2026-04-17": {"planned_duration": 60, "total_duration": 45, "completion": 0.75, "feeling": "normal"},
    }
    
    result = agent.evaluate(test_history)
    print(json.dumps(result, ensure_ascii=False, indent=2))
