#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
对话管理器 v2.0
处理用户对话，集成PDCA循环
"""

import json
from pathlib import Path


class DialogManager:
    """对话管理器"""
    
    def __init__(self):
        self.engine = None
    
    def set_engine(self, engine):
        self.engine = engine
    
    def process(self, user_input, user_id="local"):
        from tools.local_storage import load_user, save_user
        
        user_state = load_user(user_id)
        result = self.engine.process(user_input, user_state)
        
        # 处理结果，生成完整回复（含方案）
        result = self.enhance_result(result, user_state, user_id)
        
        save_user(user_id, user_state)
        
        result["intent"] = self.classify_intent(user_input)
        result["user_id"] = user_id
        
        return result
    
    def enhance_result(self, result, user_state, user_id):
        """增强结果，添加方案详情"""
        input_type = result.get("type", "")
        
        # 如果是查询方案
        if input_type == "query" or "方案" in str(result.get("reply", "")):
            # 生成完整方案
            plan = self.generate_full_plan(user_state, user_id)
            result["full_plan"] = plan
            result["reply"] = self.format_plan_reply(plan)
        
        # 如果是打卡，添加评估和可能的调整
        if input_type == "checkin":
            adjustment = self.evaluate_execution(result, user_state)
            if adjustment:
                result["adjustment"] = adjustment
                result["reply"] += f"\n\n{adjustment['message']}"
        
        return result
    
    def generate_full_plan(self, user_state, user_id):
        """生成完整方案（含视频教程）"""
        from agents.exercise_planner_agent import ExercisePlannerAgent
        
        planner = ExercisePlannerAgent()
        
        # 获取或生成方案
        plan_data = planner.generate_plan(user_state)
        
        return plan_data
    
    def format_plan_reply(self, plan):
        """格式化方案回复"""
        if not plan:
            return "暂无方案，请先上传体检报告"
        
        reply = f"📋 **运动方案**\n\n"
        reply += f"🪜 当前阶段: {plan.get('stage', '适应期')}\n"
        reply += f"📊 难度: {plan.get('difficulty_level', '入门')}\n\n"
        
        # 运动详情
        exercises = plan.get("exercises", [])
        if exercises:
            reply += "🏃 **今日运动**\n"
            for i, ex in enumerate(exercises, 1):
                reply += f"\n{i}. {ex['name']} - {ex['duration']}分钟\n"
                if ex.get("video", {}).get("search_url"):
                    reply += f"   📹 教程: {ex['video']['search_url']}\n"
        
        # 周计划
        weekly = plan.get("weekly_schedule", {})
        if weekly:
            reply += "\n📅 **周计划**\n"
            for day, detail in weekly.items():
                if detail.get("type") == "运动":
                    ex_name = detail.get("exercise", "")
                    duration = detail.get("duration", 0)
                    reply += f"{day}: {ex_name} {duration}分钟\n"
                else:
                    reply += f"{day}: 休息\n"
        
        # 检查标准
        check = plan.get("check_criteria", {})
        if check:
            reply += "\n✅ **达成标准**\n"
            reply += f"- 完成率: {check.get('completion_rate', '80%')}\n"
            reply += f"- 体感: {check.get('feeling_check', '正常或良好')}\n"
        
        return reply
    
    def evaluate_execution(self, checkin_result, user_state):
        """评估执行结果"""
        from agents.exercise_planner_agent import ExercisePlannerAgent
        
        # 模拟执行结果
        execution_result = {
            "completion_rate": checkin_result.get("evaluation", {}).get("completion", 0.8),
            "feeling": user_state.get("last_feeling", "normal")
        }
        
        planner = ExercisePlannerAgent()
        adjustment = planner.evaluate_and_adjust(execution_result, None)
        
        return adjustment
    
    def classify_intent(self, user_input):
        """识别意图"""
        text = str(user_input).lower()
        
        keywords = {
            "checkin": ["打卡", "运动", "跑步", "走路"],
            "report": ["体检", "报告", "指标"],
            "feeling": ["累", "疲乏", "感觉"],
            "query": ["方案", "计划", "怎么练", "看方案"]
        }
        
        for intent, keys in keywords.items():
            if any(k in text for k in keys):
                return intent
        return "general"
    
    def format_reply(self, result):
        """格式化最终回复"""
        if not result.get("success"):
            return result.get("reply", "处理失败")
        
        return result.get("reply", "")
