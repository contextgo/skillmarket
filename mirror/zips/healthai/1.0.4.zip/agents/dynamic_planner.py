#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
动态方案规划器
根据用户约束、执行情况、状态变化动态调整方案
"""

import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional


class DynamicPlanner:
    """动态方案规划器"""
    
    def __init__(self, storage):
        self.storage = storage
        self.user_constraints = {}  # 用户约束
        self.execution_history = {}  # 执行历史
    
    # ==================== 用户约束 ====================
    
    def add_constraint(self, user_id: str, constraint_type: str, value: str):
        """
        添加用户约束
        
        constraint_type:
        - diet: 饮食（不吃牛肉、不吃辣、素食等）
        - exercise: 运动（膝盖不好、不能跑步等）
        - time: 时间（每天只能晚上等）
        - other: 其他
        """
        if user_id not in self.user_constraints:
            self.user_constraints[user_id] = {
                "diet": [],
                "exercise": [],
                "time": [],
                "other": []
            }
        
        self.user_constraints[user_id][constraint_type].append({
            "constraint": value,
            "added_at": datetime.now().isoformat()
        })
        
        return f"已添加约束：{constraint_type} - {value}"
    
    def get_constraints(self, user_id: str) -> dict:
        """获取用户约束"""
        return self.user_constraints.get(user_id, {
            "diet": [],
            "exercise": [],
            "time": [],
            "other": []
        })
    
    # ==================== 方案生成（避开约束）====================
    
    def generate_plan(self, user_id: str, health_status: dict) -> dict:
        """
        根据约束和状态生成方案
        
        确保方案符合用户约束
        """
        constraints = self.get_constraints(user_id)
        
        # 获取最近的执行情况
        recent_execution = self._get_recent_execution(user_id, days=7)
        
        # 根据状态和约束生成方案
        plan = {
            "exercise": self._generate_exercise_plan(
                health_status, 
                constraints.get("exercise", []),
                recent_execution
            ),
            "diet": self._generate_diet_plan(
                health_status,
                constraints.get("diet", [])
            ),
            "lifestyle": self._generate_lifestyle_plan(health_status),
            "generated_at": datetime.now().isoformat()
        }
        
        return plan
    
    def _generate_exercise_plan(self, health_status: dict, 
                                 exercise_constraints: list,
                                 recent_execution: dict) -> dict:
        """生成运动方案（避开约束）"""
        
        # 检查用户约束
        has_knee_issue = any("膝盖" in c.get("constraint", "") for c in exercise_constraints)
        cannot_run = any("跑步" in c.get("constraint", "") for c in exercise_constraints)
        no_intense = any("不能剧烈" in c.get("constraint", "") for c in exercise_constraints)
        
        # 根据健康状态确定强度
        condition = health_status.get("condition", "一般")
        
        if condition == "欠佳" or no_intense:
            intensity = "低"
            exercises = ["散步", "拉伸", "瑜伽", "太极"]
        elif condition == "良好":
            intensity = "中"
            if has_knee_issue:
                exercises = ["游泳", "瑜伽", "骑单车", "椭圆机"]
            elif cannot_run:
                exercises = ["游泳", "瑜伽", "骑行", "健身操"]
            else:
                exercises = ["跑步", "游泳", "骑行", "健身操"]
        else:
            intensity = "高"
            exercises = ["跑步", "HIIT", "游泳", "登山"]
        
        # 调整频率（根据最近执行情况）
        completion_rate = recent_execution.get("completion_rate", 0.7)
        
        if completion_rate < 0.3:
            # 执行很差，降低要求
            frequency = "每周2次"
            duration = "每次15-20分钟"
        elif completion_rate < 0.7:
            frequency = "每周3-4次"
            duration = "每次30分钟"
        else:
            frequency = "每周4-5次"
            duration = "每次30-45分钟"
        
        return {
            "intensity": intensity,
            "exercises": exercises,
            "frequency": frequency,
            "duration": duration,
            "note": self._generate_exercise_note(exercise_constraints)
        }
    
    def _generate_exercise_note(self, constraints: list) -> str:
        """生成运动说明"""
        if not constraints:
            return ""
        
        notes = []
        for c in constraints:
            constraint = c.get("constraint", "")
            if "膝盖" in constraint:
                notes.append("注意保护膝盖")
            if "心脏" in constraint:
                notes.append("避免剧烈运动")
        
        return " | ".join(notes) if notes else ""
    
    def _generate_diet_plan(self, health_status: dict, 
                             diet_constraints: list) -> dict:
        """生成饮食方案（避开约束）"""
        
        # 基础建议
        suggestions = [
            "每天喝8杯水",
            "多吃蔬菜水果",
            "少油少盐"
        ]
        
        # 根据约束调整
        avoid_list = []
        for c in diet_constraints:
            constraint = c.get("constraint", "").lower()
            if "牛肉" in constraint:
                avoid_list.append("牛肉")
                suggestions.append("用鸡肉/鱼肉代替牛肉")
            if "猪肉" in constraint:
                avoid_list.append("猪肉")
                suggestions.append("用鱼肉/鸡肉代替猪肉")
            if "辣" in constraint:
                avoid_list.append("辣椒")
                suggestions.append("避免辛辣食物")
            if "素" in constraint:
                suggestions.append("增加豆制品补充蛋白")
        
        # 根据健康状态调整
        condition = health_status.get("condition", "一般")
        if condition == "欠佳":
            suggestions.append("建议清淡饮食")
        
        return {
            "avoid": avoid_list,
            "suggestions": suggestions
        }
    
    def _generate_lifestyle_plan(self, health_status: dict) -> dict:
        """生成生活方式建议"""
        
        return {
            "sleep": "23点前入睡，保证7-8小时",
            "stress": "每天冥想10分钟",
            "habit": "久坐每小时站起来活动5分钟"
        }
    
    def _get_recent_execution(self, user_id: str, days: int) -> dict:
        """获取近期执行情况"""
        checkins = self.storage.get_checkins(user_id, days=days)
        
        if not checkins:
            return {"completion_rate": 0.5, "days_active": 0}
        
        completed = sum(1 for c in checkins if c.get("completed", False))
        
        return {
            "completion_rate": completed / len(checkins) if checkins else 0,
            "days_active": len(checkins),
            "total_checkins": len(checkins)
        }
    
    # ==================== 执行监测与调整 ====================
    
    def check_and_adjust(self, user_id: str) -> dict:
        """
        检查执行情况，必要时调整
        
        返回：是否需要提醒用户
        """
        # 获取最近3天数据
        recent = self._get_recent_execution(user_id, days=3)
        
        # 判断是否需要提醒
        alerts = []
        
        if recent["days_active"] == 0:
            # 3天没任何活动
            alerts.append({
                "type": "inactive_3days",
                "message": "3天没有运动了，今天动一动？",
                "action": "降低难度"
            })
        
        if recent["completion_rate"] < 0.3:
            # 完成率很低
            alerts.append({
                "type": "low_completion",
                "message": "这周完成率有点低，是方案太难了吗？",
                "action": "调整方案"
            })
        
        # 检查用户体感
        checkins = self.storage.get_checkins(user_id, days=7)
        if checkins:
            # 看看用户反馈
            tired_count = sum(1 for c in checkins if c.get("feeling") == "累")
            if tired_count >= 3:
                alerts.append({
                    "type": "feeling_tired",
                    "message": "你最近说累好多次了，建议降低运动强度",
                    "action": "降低强度"
                })
        
        return {
            "needs_alert": len(alerts) > 0,
            "alerts": alerts
        }
    
    # ==================== 主动触发 ====================
    
    def should_proactively_contact(self, user_id: str) -> dict:
        """
        判断是否需要主动联系用户
        
        触发条件：
        - 3天没运动
        - 感觉好了停止
        - 周复盘时间到
        - 异常预警
        """
        triggers = []
        
        # 1. 检查是否3天没运动
        recent = self._get_recent_execution(user_id, days=3)
        if recent["days_active"] == 0:
            triggers.append({
                "trigger": "inactive_3days",
                "message": "3天没运动了，在忙什么？",
                "priority": "medium"
            })
        
        # 2. 检查是否感觉好了就停了（查看历史）
        # 连续运动后突然停止
        checkins = self.storage.get_checkins(user_id, days=30)
        if len(checkins) >= 10:
            # 看最近是否停止了
            last_week = [c for c in checkins[-7:] if c.get("completed")]
            this_week = [c for c in checkins[-7:] if c.get("completed")]
            
            if len(last_week) >= 3 and len(this_week) == 0:
                triggers.append({
                    "trigger": "stopped_feeling_better",
                    "message": "感觉好了也不能完全停哦！反弹更快",
                    "priority": "high"
                })
        
        # 3. 周复盘时间（周日）
        if datetime.now().weekday() == 6:  # 周日
            triggers.append({
                "trigger": "weekly_review",
                "message": "这周复盘一下？看看状态如何",
                "priority": "medium"
            })
        
        return {
            "should_contact": len(triggers) > 0,
            "triggers": triggers
        }
    
    def generate_proactive_message(self, user_id: str) -> str:
        """生成主动联系的消息"""
        
        check = self.should_proactively_contact(user_id)
        
        if not check["should_contact"]:
            return None
        
        # 按优先级排序
        triggers = sorted(check["triggers"], 
                         key=lambda x: {"high": 0, "medium": 1, "low": 2}.get(x.get("priority", "low"), 2))
        
        # 生成消息
        main_trigger = triggers[0]
        
        messages = {
            "inactive_3days": "3天没见到你了，在忙什么？记得动一动哦！",
            "stopped_feeling_better": "感觉好了也不能完全停呀！身体会反弹的～",
            "weekly_review": "周末了，要不要做个周复盘？看看这周状态怎么样",
            "feeling_tired": "你最近说累好多次了，方案要不要调简单点？"
        }
        
        return messages.get(main_trigger["trigger"], main_trigger["message"])


# 测试
if __name__ == "__main__":
    from data.storage import get_storage
    
    storage = get_storage()
    planner = DynamicPlanner(storage)
    
    print("=== 动态方案规划器 ===\n")
    
    # 测试添加约束
    result = planner.add_constraint("test_user", "diet", "不吃牛肉")
    print(result)
    
    # 测试获取约束
    constraints = planner.get_constraints("test_user")
    print(f"约束: {constraints}")
    
    # 测试生成方案
    health_status = {"condition": "良好"}
    plan = planner.generate_plan("test_user", health_status)
    print(f"\n生成的运动方案:")
    print(f"  强度: {plan['exercise']['intensity']}")
    print(f"  项目: {plan['exercise']['exercises']}")
    print(f"  频率: {plan['exercise']['frequency']}")
    
    print(f"\n生成的饮食方案:")
    print(f"  避免: {plan['diet']['avoid']}")
    
    # 测试主动触发
    msg = planner.generate_proactive_message("test_user")
    print(f"\n主动消息: {msg}")
