#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
健康评估引擎 (核心大脑) v2.0
- 动态基准对比
- 阶段升级自动推方案
- 体感疲劳自动降强度
- 隐私保护
"""

import json
import re
from datetime import datetime, timedelta
from pathlib import Path


class HealthAssessmentEngine:
    """核心决策引擎"""
    
    # 可配置的常量（不写死）
    CONFIG = {
        "stages": ["调整期", "适应期", "基础期", "稳定期", "进阶期", "精英期"],
        "fatigue_feelings": ["tired", "very_tired", "exhausted", "累", "疲乏", "疲劳"],
        "good_feelings": ["great", "excellent", "good", "很好", "不错", "精神"],
        "upgrade_threshold": 80,    # 升级阈值
        "downgrade_threshold": 40,  # 降级阈值
        "fatigue_reduction": 0.2,   # 疲劳时强度降低20%
        "min_streak_upgrade": 14,   # 连续打卡14天可升级
        "stage_duration_weeks": 4,  # 阶段持续周数
    }
    
    def __init__(self):
        self.config = self.CONFIG
    
    def process(self, user_input, user_state):
        """主处理函数"""
        input_type = self.classify_input(user_input)
        
        if input_type == "checkin":
            result = self.handle_checkin(user_input, user_state)
        elif input_type == "report":
            result = self.handle_report(user_input, user_state)
        elif input_type == "feeling":
            result = self.handle_feeling(user_input, user_state)
        elif input_type == "query":
            result = self.handle_query(user_input, user_state)
        else:
            result = self.handle_general(user_input, user_state)
        
        return result
    
    def classify_input(self, user_input):
        """分类用户输入"""
        text = str(user_input).lower()
        
        keywords = {
            "checkin": ["打卡", "运动", "跑步", "走路", "游泳", "锻炼"],
            "report": ["体检", "报告", "指标", "血糖", "血压", "血脂", "检查"],
            "feeling": ["累", "疲乏", "不舒服", "感觉", "体力"],
            "query": ["方案", "计划", "怎么练", "吃", "查"]
        }
        
        for intent, keys in keywords.items():
            if any(k in text for k in keys):
                return intent
        return "general"
    
    # ========== 打卡处理 ==========
    def handle_checkin(self, user_input, user_state):
        """处理打卡（带自动强度调整）"""
        # 1. 提取打卡数据
        checkin_data = self.extract_checkin_data(user_input)
        
        # 2. 检查体感，如果累自动降强度
        checkin_data = self.auto_adjust_for_fatigue(checkin_data, user_state)
        
        # 3. 计算评分
        evaluation = self.evaluate_checkin(checkin_data, user_state)
        
        # 4. 生成回复
        reply = self.generate_checkin_reply(checkin_data, evaluation, user_state)
        
        # 5. 检查是否需要升级方案
        stage_change = None
        plan_change = None
        
        if evaluation.get("should_upgrade"):
            # 自动生成新方案
            plan_change = self.generate_upgraded_plan(user_state)
            stage_change = self.calculate_next_stage(
                user_state.get("current_stage", "适应期"), "up"
            )
            reply += f"\n\n🎉 表现优秀！已自动生成 {stage_change} 方案"
        
        return {
            "type": "checkin",
            "success": True,
            "checkin_data": checkin_data,
            "evaluation": evaluation,
            "reply": reply,
            "stage_change": stage_change,
            "plan_change": plan_change,
            "auto_adjusted": checkin_data.get("auto_adjusted", False)
        }
    
    def auto_adjust_for_fatigue(self, checkin_data, user_state):
        """体感疲劳自动降强度"""
        recent_feelings = user_state.get("recent_feelings", [])
        
        # 检查最近是否累
        fatigue_keywords = self.config["fatigue_feelings"]
        is_tired = any(any(fk in str(f).lower() for fk in fatigue_keywords) for f in recent_feelings)
        
        if is_tired:
            # 降低运动时长
            original_duration = checkin_data.get("运动时长", 30)
            reduction = self.config["fatigue_reduction"]
            new_duration = int(original_duration * (1 - reduction))
            
            checkin_data["运动时长"] = new_duration
            checkin_data["auto_adjusted"] = True
            checkin_data["adjust_reason"] = f"检测到疲劳，降低强度{int(reduction*100)}%"
        
        return checkin_data
    
    def extract_checkin_data(self, user_input):
        """提取打卡数据"""
        data = {"运动项目": "运动", "运动时长": 30, "步数": 0}
        text = str(user_input)
        
        # 运动类型
        sports = ["走路", "跑步", "游泳", "骑行", "瑜伽", "八段锦", "太极", "力量", "HIIT", "健身"]
        for sport in sports:
            if sport in text:
                data["运动项目"] = sport
                break
        
        # 时长
        duration_match = re.search(r'(\d+)\s*(分钟|分|min)', text)
        if duration_match:
            data["运动时长"] = int(duration_match.group(1))
        
        # 步数
        steps_match = re.search(r'(\d+)\s*步', text)
        if steps_match:
            data["步数"] = int(steps_match.group(1))
        
        return data
    
    def evaluate_checkin(self, checkin_data, user_state):
        """评估打卡"""
        # 简单评分逻辑
        completion = 0.8  # 打卡就算完成
        feeling = user_state.get("last_feeling", "normal")
        
        feeling_scores = {"great": 1.0, "good": 0.85, "normal": 0.7, "tired": 0.5, "very_tired": 0.3}
        feeling_score = feeling_scores.get(feeling, 0.7)
        
        total_score = completion * 50 + feeling_score * 50
        
        return {
            "completion": completion,
            "feeling_score": feeling_score,
            "total_score": total_score,
            "should_upgrade": total_score >= self.config["upgrade_threshold"],
            "should_downgrade": total_score <= self.config["downgrade_threshold"],
            "streak_qualifies": user_state.get("streak_days", 0) >= self.config["min_streak_upgrade"]
        }
    
    # ========== 体检报告处理 ==========
    def handle_report(self, user_input, user_state):
        """处理体检报告 - 动态基准"""
        # 1. 提取所有指标（不只异常）
        all_indicators = self.extract_all_indicators(user_input)
        
        # 2. 隐私过滤（不存个人隐私）
        indicators = self.filter_privacy(all_indicators)
        
        # 3. 对比动态基准（上次数据）
        comparison = self.compare_with_previous(indicators, user_state)
        
        # 4. 计算当前阶段
        current_stage = self.calculate_dynamic_stage(comparison, user_state)
        
        # 5. 生成建议
        suggestions = self.generate_suggestions(comparison)
        
        # 6. 更新状态
        user_state["indicators"] = indicators
        user_state["last_indicators"] = user_state.get("indicators", {})  # 保存上次
        user_state["comparison"] = comparison
        user_state["current_stage"] = current_stage
        user_state["last_report_date"] = datetime.now().isoformat()
        
        # 生成回复
        reply = self.generate_report_reply(indicators, comparison, current_stage, suggestions)
        
        return {
            "type": "report",
            "success": True,
            "indicators": indicators,  # 所有指标
            "comparison": comparison,  # 对比结果
            "current_stage": current_stage,
            "suggestions": suggestions,
            "reply": reply
        }
    
    def extract_all_indicators(self, text):
        """提取所有体检指标（不只异常）"""
        indicators = {}
        text = str(text)
        
        # 常见指标模式
        patterns = [
            r'([体重BMI体脂率收缩压舒张压血压空腹血糖血糖糖化血红蛋白总胆固醇甘油三酯高密度脂蛋白低密度脂蛋白谷丙转氨酶谷草转氨酶肌酐尿素氮尿酸血红蛋白白细胞血小板心率]+)[:\s：:]*(\d+\.?\d*)\s*([a-zA-Z%/°]+)?',
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, text)
            for match in matches:
                if len(match) >= 2:
                    name = match[0].strip()
                    try:
                        value = float(match[1].strip())
                        unit = match[2].strip() if len(match) > 2 else ""
                        indicators[name] = {"value": value, "unit": unit}
                    except:
                        continue
        
        return indicators
    
    def filter_privacy(self, indicators):
        """过滤隐私信息 - 只保留指标数据"""
        # 需要过滤的隐私字段
        privacy_fields = ["姓名", "名字", "身份证", "电话", "手机", "地址", "年龄", "性别"]
        
        filtered = {}
        for name, value in indicators.items():
            if name not in privacy_fields:
                filtered[name] = value
        
        return filtered
    
    def compare_with_previous(self, current_indicators, user_state):
        """与上一次数据动态对比"""
        previous = user_state.get("last_indicators", {})
        
        comparison = {}
        
        for name, data in current_indicators.items():
            current_value = data.get("value")
            prev_value = previous.get(name, {}).get("value")
            
            if prev_value is not None:
                change = current_value - prev_value
                change_pct = (change / prev_value) * 100 if prev_value != 0 else 0
                
                # 判断趋势
                # 特殊指标：越低越好的
                inverse_indicators = ["体重", "BMI", "血糖", "血压", "血脂", "尿酸", "胆固醇"]
                
                if name in inverse_indicators:
                    if change < 0:
                        trend = "improving"
                        trend_text = "↓ 下降"
                    elif change > 0:
                        trend = "declining"
                        trend_text = "↑ 上升"
                    else:
                        trend = "stable"
                        trend_text = "→ 持平"
                else:
                    if change > 0:
                        trend = "improving"
                        trend_text = "↑ 上升"
                    elif change < 0:
                        trend = "declining"
                        trend_text = "↓ 下降"
                    else:
                        trend = "stable"
                        trend_text = "→ 持平"
                
                comparison[name] = {
                    "current": current_value,
                    "previous": prev_value,
                    "change": round(change, 2),
                    "change_pct": round(change_pct, 1),
                    "trend": trend,
                    "trend_text": trend_text
                }
            else:
                # 首次数据
                comparison[name] = {
                    "current": current_value,
                    "previous": None,
                    "change": None,
                    "change_pct": None,
                    "trend": "first",
                    "trend_text": "首次记录"
                }
        
        # 整体趋势
        improving_count = sum(1 for c in comparison.values() if c.get("trend") == "improving")
        declining_count = sum(1 for c in comparison.values() if c.get("trend") == "declining")
        
        if improving_count > declining_count:
            overall_trend = "improving"
        elif declining_count > improving_count:
            overall_trend = "declining"
        else:
            overall_trend = "stable"
        
        return {
            "indicators": comparison,
            "overall_trend": overall_trend,
            "improving_count": improving_count,
            "declining_count": declining_count
        }
    
    def calculate_dynamic_stage(self, comparison, user_state):
        """动态计算阶段"""
        # 基于趋势计算
        overall = comparison.get("overall_trend", "stable")
        streak = user_state.get("streak_days", 0)
        
        current_stage = user_state.get("current_stage", "适应期")
        
        # 根据趋势和连续性判断
        if overall == "improving" and streak >= self.config["min_streak_upgrade"]:
            return self.calculate_next_stage(current_stage, "up")
        elif overall == "declining":
            return self.calculate_next_stage(current_stage, "down")
        
        return current_stage
    
    def calculate_next_stage(self, current, direction):
        """计算下一阶段"""
        stages = self.config["stages"]
        try:
            idx = stages.index(current)
            if direction == "up" and idx < len(stages) - 1:
                return stages[idx + 1]
            elif direction == "down" and idx > 0:
                return stages[idx - 1]
        except ValueError:
            pass
        return current
    
    # ========== 体感处理 ==========
    def handle_feeling(self, user_input, user_state):
        """处理体感反馈"""
        feeling = self.extract_feeling(user_input)
        
        # 更新体感历史
        user_state["recent_feelings"] = user_state.get("recent_feelings", [])
        user_state["recent_feelings"].append(feeling)
        user_state["recent_feelings"] = user_state["recent_feelings"][-7:]
        user_state["last_feeling"] = feeling
        
        # 判断是否需要调整
        need_adjust = feeling in ["tired", "very_tired"]
        
        reply = self.generate_feeling_reply(feeling, need_adjust)
        
        return {
            "type": "feeling",
            "success": True,
            "feeling": feeling,
            "need_adjust": need_adjust,
            "reply": reply
        }
    
    def extract_feeling(self, user_input):
        """提取体感"""
        text = str(user_input).lower()
        
        good_keywords = self.config["good_feelings"]
        bad_keywords = self.config["fatigue_feelings"]
        
        if any(k in text for k in good_keywords):
            return "good"
        elif any(k in text for k in bad_keywords):
            return "tired"
        else:
            return "normal"
    
    # ========== 生成回复 ==========
    def generate_checkin_reply(self, data, evaluation, user_state):
        """生成打卡回复"""
        msg = f"✅ 打卡成功！\n\n"
        msg += f"🏃 {data.get('运动项目', '运动')} {data.get('运动时长', 30)}分钟"
        
        if data.get("步数"):
            msg += f" / {data['步数']}步"
        
        if data.get("auto_adjusted"):
            msg += f"\n⚠️ {data['adjust_reason']}"
        
        msg += f"\n\n📊 评分: {evaluation['total_score']:.0f}分"
        
        return msg
    
    def generate_report_reply(self, indicators, comparison, stage, suggestions):
        """生成报告回复"""
        msg = f"📋 体检数据已更新\n\n"
        msg += f"🪜 当前阶段: {stage}\n"
        msg += f"📈 整体趋势: {comparison.get('overall_trend', 'stable')}\n\n"
        
        # 显示有变化的指标
        changed = [k for k, v in comparison.get("indicators", {}).items() 
                   if v.get("trend") != "first"]
        
        if changed:
            msg += "📊 指标变化:\n"
            for name in changed[:5]:
                v = comparison["indicators"][name]
                msg += f"  {name}: {v['trend_text']} ({v.get('change_pct', 0):.1f}%)\n"
        
        return msg
    
    def generate_feeling_reply(self, feeling, need_adjust):
        """生成体感回复"""
        feeling_text = {
            "great": "精神饱满！💪",
            "good": "状态不错～",
            "normal": "还行",
            "tired": "有点累了，注意休息",
            "very_tired": "需要好好休息一下"
        }
        
        msg = f"收到！你现在: {feeling_text.get(feeling, feeling)}\n"
        
        if need_adjust:
            msg += "\n⚠️ 已自动降低今日运动强度"
        
        return msg
    
    def generate_suggestions(self, comparison):
        """生成建议"""
        suggestions = []
        
        overall = comparison.get("overall_trend", "stable")
        
        if overall == "improving":
            suggestions.append("指标整体向好继续保持！")
        elif overall == "declining":
            suggestions.append("部分指标有波动，建议关注饮食和休息")
        else:
            suggestions.append("保持现有生活习惯")
        
        return suggestions
    
    # ========== 其他处理 ==========
    def handle_query(self, user_input, user_state):
        """处理查询"""
        return {
            "type": "query",
            "success": True,
            "reply": f"当前阶段: {user_state.get('current_stage', '适应期')}"
        }
    
    def handle_general(self, user_input, user_state):
        """通用处理"""
        return {
            "type": "general",
            "success": True,
            "reply": "收到！有什么需要随时告诉我～"
        }
    
    def generate_upgraded_plan(self, user_state):
        """生成升级方案（待调用运动规划Agent）"""
        return {
            "new_stage": self.calculate_next_stage(
                user_state.get("current_stage", "适应期"), "up"
            ),
            "message": "自动生成新阶段方案"
        }


# 测试
if __name__ == "__main__":
    engine = HealthAssessmentEngine()
    
    # 测试动态对比
    user_state = {
        "current_stage": "适应期",
        "streak_days": 15,
        "last_indicators": {
            "体重": {"value": 75},
            "血糖": {"value": 5.8}
        },
        "recent_feelings": ["good", "good"],
        "last_feeling": "good"
    }
    
    # 模拟新数据
    current_indicators = {
        "体重": {"value": 73},
        "血糖": {"value": 5.5},
        "血脂": {"value": 2.0}
    }
    
    comparison = engine.compare_with_previous(current_indicators, user_state)
    print(json.dumps(comparison, ensure_ascii=False, indent=2))
