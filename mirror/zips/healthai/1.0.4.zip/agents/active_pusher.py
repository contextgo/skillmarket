#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
主动推送引擎
定时检查并主动推送消息给用户
"""

import json
from datetime import datetime, timedelta
from pathlib import Path


class ActivePusher:
    """主动推送引擎"""
    
    def __init__(self):
        # 推送触发条件
        self.triggers = {
            "streak_milestone": self.check_streak_milestone,
            "low_completion": self.check_low_completion,
            "fatigue_warning": self.check_fatigue,
            "plan_refresh": self.check_plan_refresh,
            "milestone_reached": self.check_milestone,
            "weather_good": self.check_weather,
            "no_checkin_yesterday": self.check_absence
        }
    
    def check_and_push(self, user_state):
        """检查并返回需要推送的内容"""
        push_contents = []
        
        # 检查所有触发条件
        for trigger_name, check_func in self.triggers.items():
            result = check_func(user_state)
            if result:
                push_contents.append({
                    "trigger": trigger_name,
                    "content": result,
                    "priority": self.get_priority(trigger_name)
                })
        
        # 按优先级排序
        push_contents.sort(key=lambda x: x["priority"], reverse=True)
        
        return push_contents
    
    def check_streak_milestone(self, user_state):
        """检查连续打卡里程碑"""
        streak_days = user_state.get("streak_days", 0)
        
        milestones = [7, 14, 21, 30, 60, 90, 180, 365]
        
        if streak_days in milestones:
            return f"🎉 恭喜！连续打卡 {streak_days} 天！习惯已经养成了！"
        
        # 接近里程碑
        next_milestone = next((m for m in milestones if m > streak_days), None)
        if next_milestone and next_milestone - streak_days == 3:
            return f"📅 再坚持 {next_milestone - streak_days} 天就达成里程碑了！加油！"
        
        return None
    
    def check_low_completion(self, user_state):
        """检查完成度"""
        weekly_completion = user_state.get("weekly_completion", 1.0)
        
        if weekly_completion < 0.5:
            days = user_state.get("days_since_low_completion", 1)
            if days >= 2:
                return "📉 最近完成度有点低呀～是太忙了还是太累了？需要我帮你调整计划吗？"
        
        return None
    
    def check_fatigue(self, user_state):
        """检查疲劳"""
        recent_feelings = user_state.get("recent_feelings", [])
        tired_count = recent_feelings.count("tired") + recent_feelings.count("very_tired")
        
        if tired_count >= 3:
            return "😴 检测到您最近比较疲劳，建议今天好好休息一下，降低运动强度也行～"
        
        return None
    
    def check_plan_refresh(self, user_state):
        """检查方案是否需要更新"""
        days_since_update = user_state.get("days_since_plan_update", 0)
        
        if days_since_update >= 14:
            return "📋 运动方案已经用了一段时间了，需要我帮你评估并更新吗？"
        
        return None
    
    def check_milestone(self, user_state):
        """检查阶段里程碑"""
        stage = user_state.get("current_stage", "")
        stage_start = user_state.get("stage_start_date")
        
        if not stage_start:
            return None
        
        # 计算阶段持续时间
        try:
            start_date = datetime.strptime(stage_start, "%Y-%m-%d")
            days = (datetime.now() - start_date).days
            
            if days >= 21 and user_state.get("recent_completion", 0) > 0.8:
                # 可以升级了
                return f"🏆 在 {stage} 已经坚持21天了！表现优秀，可以考虑升级方案了，要试试吗？"
        except:
            pass
        
        return None
    
    def check_weather(self, user_state):
        """检查天气（预留接口）"""
        # 可以接入天气 API
        # 晴天适合户外运动
        return None
    
    def check_absence(self, user_state):
        """检查昨天是否没打卡"""
        last_checkin = user_state.get("last_checkin_date", "")
        
        if last_checkin:
            try:
                last_date = datetime.strptime(last_checkin, "%Y-%m-%d")
                days_since = (datetime.now() - last_date).days
                
                if days_since >= 2:
                    return f"📢 已经有 {days_since} 天没打卡了～在忙什么呢？记得动起来呀！"
            except:
                pass
        
        return None
    
    def get_priority(self, trigger_name):
        """获取优先级"""
        priorities = {
            "fatigue_warning": 100,    # 疲劳最高优先
            "milestone_reached": 90,   # 达成里程碑
            "streak_milestone": 80,    # 连续打卡
            "low_completion": 60,      # 完成度低
            "plan_refresh": 40,        # 方案更新
            "no_checkin_yesterday": 70,# 没打卡
            "weather_good": 20         # 天气好
        }
        return priorities.get(trigger_name, 50)
    
    def generate_push_message(self, pushes):
        """生成推送消息"""
        if not pushes:
            return None
        
        if len(pushes) == 1:
            return pushes[0]["content"]
        
        # 多条推送合并
        messages = [p["content"] for p in pushes[:2]]  # 最多2条
        return "\n\n".join(messages)


# 测试
if __name__ == "__main__":
    pusher = ActivePusher()
    
    user_state = {
        "streak_days": 20,
        "weekly_completion": 0.3,
        "recent_feelings": ["tired", "tired", "good", "tired"],
        "days_since_plan_update": 15,
        "last_checkin_date": "2026-04-10"
    }
    
    pushes = pusher.check_and_push(user_state)
    for p in pushes:
        print(f"[{p['priority']}] {p['content']}")
