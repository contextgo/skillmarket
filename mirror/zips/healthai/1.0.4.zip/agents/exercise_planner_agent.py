#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
运动规划 Agent v2.0 - 动态方案 + 动态视频教程
PDCA 循环核心
"""

import json
import random
from datetime import datetime, timedelta


class ExercisePlannerAgent:
    """动态运动规划 Agent"""
    
    # 运动动作库（动态选择）
    EXERCISE_DB = {
        "有氧": {
            "入门": [
                {"name": "慢走", "duration": 20, "calories": 60, "difficulty": 1, 
                 "tags": ["新手", "膝盖友好", "减脂"]},
                {"name": "原地踏步", "duration": 15, "calories": 50, "difficulty": 1,
                 "tags": ["新手", "室内", "简单"]},
                {"name": "拉伸走", "duration": 20, "calories": 70, "difficulty": 1,
                 "tags": ["热身", "活动全身"]},
            ],
            "进阶": [
                {"name": "快走", "duration": 30, "calories": 150, "difficulty": 2,
                 "tags": ["户外", "心肺", "减脂"]},
                {"name": "慢跑", "duration": 20, "calories": 180, "difficulty": 2,
                 "tags": ["心肺", "燃脂", "户外"]},
                {"name": "游泳", "duration": 30, "calories": 250, "difficulty": 2,
                 "tags": ["全身", "关节友好", "减脂"]},
            ],
            "高级": [
                {"name": "冲刺跑", "duration": 10, "calories": 150, "difficulty": 4,
                 "tags": ["高强度", "心肺", "爆发力"]},
                {"name": "HIIT", "duration": 20, "calories": 280, "difficulty": 4,
                 "tags": ["燃脂", "心肺", "高效"]},
                {"name": "跳绳", "duration": 15, "calories": 200, "difficulty": 3,
                 "tags": ["协调", "燃脂", "室内"]},
            ]
        },
        "力量": {
            "入门": [
                {"name": "靠墙俯卧撑", "duration": 10, "calories": 40, "difficulty": 1,
                 "tags": ["新手", "胸部", "室内"]},
                {"name": "跪姿俯卧撑", "duration": 10, "calories": 50, "difficulty": 1,
                 "tags": ["新手", "胸部", "核心"]},
                {"name": "椅子深蹲", "duration": 15, "calories": 60, "difficulty": 1,
                 "tags": ["新手", "腿部", "安全"]},
            ],
            "进阶": [
                {"name": "标准俯卧撑", "duration": 15, "calories": 80, "difficulty": 2,
                 "tags": ["胸部", "手臂", "核心"]},
                {"name": "深蹲", "duration": 15, "calories": 100, "difficulty": 2,
                 "tags": ["腿部", "臀部", "全身"]},
                {"name": "平板支撑", "duration": 2, "calories": 30, "difficulty": 2,
                 "tags": ["核心", "腹部", "稳定"]},
            ],
            "高级": [
                {"name": "钻石俯卧撑", "duration": 12, "calories": 90, "difficulty": 3,
                 "tags": ["胸部", "三头", "高强度"]},
                {"name": "单腿深蹲", "duration": 15, "calories": 120, "difficulty": 4,
                 "tags": ["腿部", "平衡", "核心"]},
                {"name": "硬拉", "duration": 20, "calories": 150, "difficulty": 3,
                 "tags": ["背部", "腿部", "力量"]},
            ]
        },
        "柔韧": {
            "入门": [
                {"name": "全身拉伸", "duration": 10, "calories": 30, "difficulty": 1,
                 "tags": ["新手", "放松", "恢复"]},
                {"name": "颈椎放松", "duration": 5, "calories": 10, "difficulty": 1,
                 "tags": ["办公室", "放松"]},
            ],
            "进阶": [
                {"name": "瑜伽基础", "duration": 20, "calories": 80, "difficulty": 2,
                 "tags": ["柔韧", "平衡", "放松"]},
                {"name": "八段锦", "duration": 15, "calories": 60, "difficulty": 1,
                 "tags": ["传统", "调理", "养身"]},
                {"name": "太极", "duration": 20, "calories": 80, "difficulty": 1,
                 "tags": ["传统", "平衡", "修养"]},
            ]
        }
    }
    
    # 视频搜索关键词模板
    VIDEO_SEARCH_TEMPLATES = {
        "慢走": ["慢走正确姿势", "走路正确姿势教程"],
        "快走": ["快走燃脂教程", "快走正确姿势"],
        "慢跑": ["跑步正确姿势", "新手跑步教程"],
        "游泳": ["游泳入门教程", "游泳动作讲解"],
        "标准俯卧撑": ["俯卧撑正确姿势", "俯卧撑教程"],
        "深蹲": ["深蹲正确姿势", "健身深蹲教程"],
        "平板支撑": ["平板支撑动作", "核心训练"],
        "瑜伽": ["瑜伽入门教程", "基础瑜伽动作"],
        "八段锦": ["八段锦完整版", "八段锦教程"],
        "太极": ["太极拳入门", "24式太极拳"],
        "HIIT": ["HIIT训练教程", "高强度间歇训练"],
        "跳绳": ["跳绳正确姿势", "跳绳技巧"],
    }
    
    def __init__(self):
        self.exercise_db = self.EXERCISE_DB
        self.video_templates = self.VIDEO_SEARCH_TEMPLATES
    
    def generate_plan(self, user_state):
        """
        动态生成运动计划 + 视频教程
        """
        # 1. 分析用户当前状态
        stage = user_state.get("current_stage", "适应期")
        abnormal = user_state.get("abnormal", [])
        recent_feelings = user_state.get("recent_feelings", [])
        streak = user_state.get("streak_days", 0)
        
        # 2. 确定难度级别
        difficulty_level = self.get_difficulty_level(stage, recent_feelings, streak)
        
        # 3. 根据异常指标确定运动目标
        goals = self.determine_goals(abnormal)
        
        # 4. 动态选择运动组合
        exercises = self.select_exercises(goals, difficulty_level)
        
        # 5. 为每个运动匹配视频教程
        plan_with_videos = self.add_video_tutorials(exercises)
        
        # 6. 生成周计划
        weekly_schedule = self.create_weekly_schedule(plan_with_videos)
        
        # 7. 预估下一阶段
        next_stage_hint = self.predict_next_stage(stage, plan_with_videos)
        
        return {
            "success": True,
            "generated_at": datetime.now().isoformat(),
            
            # 方案信息
            "stage": stage,
            "difficulty_level": difficulty_level,
            "goals": goals,
            
            # 运动详情（带视频）
            "exercises": plan_with_videos,
            "weekly_schedule": weekly_schedule,
            
            # 下一阶段
            "next_stage_hint": next_stage_hint,
            
            # PDCA 相关
            "check_criteria": self.get_check_criteria(plan_with_videos),
            "adjustment_rules": self.get_adjustment_rules()
        }
    
    def get_difficulty_level(self, stage, recent_feelings, streak):
        """根据状态动态确定难度级别"""
        # 基础级别
        stage_level = {
            "调整期": "入门",
            "适应期": "入门",
            "基础期": "进阶",
            "稳定期": "进阶",
            "进阶期": "高级",
            "精英期": "高级"
        }
        level = stage_level.get(stage, "入门")
        
        # 体感调整
        fatigue_count = sum(1 for f in recent_feelings if f in ["tired", "very_tired"])
        if fatigue_count >= 2:
            level = "入门"  # 累了降级
        
        # 连续性调整
        if streak >= 21 and level == "入门":
            level = "进阶"
        
        return level
    
    def determine_goals(self, abnormal):
        """根据异常指标确定目标"""
        goal_map = {
            "血压": {"type": "有氧", "focus": "心肺", "avoid": "高强度"},
            "血糖": {"type": "有氧", "focus": "代谢", "avoid": "空肚运动"},
            "血脂": {"type": "有氧", "focus": "燃脂", "avoid": "高脂"},
            "BMI": {"type": "有氧", "focus": "减脂", "avoid": ""},
            "尿酸": {"type": "柔韧", "focus": "关节", "avoid": "高冲击"},
            "脂肪肝": {"type": "有氧", "focus": "减脂", "avoid": ""},
            "心率": {"type": "柔韧", "focus": "放松", "avoid": "剧烈"}
        }
        
        goals = []
        for item in abnormal:
            indicator = item.get("indicator", "")
            if indicator in goal_map:
                goals.append(goal_map[indicator])
        
        # 默认目标
        if not goals:
            goals = [{"type": "混合", "focus": "全面", "avoid": ""}]
        
        return goals
    
    def select_exercises(self, goals, difficulty_level):
        """动态选择运动"""
        selected = []
        
        # 优先选择符合目标的运动
        for goal in goals:
            goal_type = goal.get("type", "混合")
            
            if goal_type == "有氧":
                pool = self.exercise_db.get("有氧", {}).get(difficulty_level, [])
                selected.extend(pool[:2])
            elif goal_type == "力量":
                pool = self.exercise_db.get("力量", {}).get(difficulty_level, [])
                selected.extend(pool[:1])
            elif goal_type == "柔韧":
                pool = self.exercise_db.get("柔韧", {}).get(difficulty_level, [])
                selected.extend(pool[:1])
        
        # 如果不够，补充其他类型
        if len(selected) < 3:
            for category in ["柔韧"]:
                pool = self.exercise_db.get(category, {}).get("入门", [])
                if pool and len(selected) < 3:
                    selected.append(random.choice(pool))
        
        # 去重
        seen = set()
        unique = []
        for e in selected:
            if e["name"] not in seen:
                seen.add(e["name"])
                unique.append(e)
        
        return unique[:4]  # 最多4个运动
    
    def add_video_tutorials(self, exercises):
        """为每个运动添加视频教程"""
        result = []
        
        for ex in exercises:
            name = ex["name"]
            
            # 搜索关键词
            search_keywords = self.video_templates.get(name, [f"{name}教程", f"{name}动作"])
            
            # 模拟视频链接（实际可接入B站API）
            video_info = self.search_video(search_keywords[0])
            
            result.append({
                **ex,
                "video": video_info
            })
        
        return result
    
    def search_video(self, keyword):
        """
        搜索视频教程（可接入B站API）
        这里是模拟，返回搜索关键词供后续使用
        """
        # 实际生产中可以接入B站搜索API
        return {
            "keyword": keyword,
            "search_url": f"https://search.bilibili.com/search?keyword={keyword}&search_type=video",
            "note": "点击链接查看B站视频教程",
            "platform": "bilibili"
        }
    
    def create_weekly_schedule(self, exercises):
        """创建周计划"""
        schedule = {}
        days = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]
        
        # 分配运动日（间隔开）
        workout_days = {
            "周一": exercises[0] if len(exercises) > 0 else None,
            "周二": exercises[1] if len(exercises) > 1 else None,
            "周三": None,  # 休息
            "周四": exercises[2] if len(exercises) > 2 else exercises[0],
            "周五": exercises[1] if len(exercises) > 1 else None,
            "周六": exercises[0] if exercises else None,
            "周日": None,  # 休息
        }
        
        for day in days:
            ex = workout_days.get(day)
            if ex:
                schedule[day] = {
                    "type": "运动",
                    "exercise": ex["name"],
                    "duration": ex["duration"],
                    "calories": ex["calories"],
                    "tags": ex.get("tags", []),
                    "video": ex.get("video", {}),
                    "tips": self.get_exercise_tips(ex)
                }
            else:
                schedule[day] = {
                    "type": "休息",
                    "tips": "充分休息，让身体恢复"
                }
        
        return schedule
    
    def get_exercise_tips(self, exercise):
        """获取运动小贴士"""
        tips_map = {
            "慢走": "保持背部挺直，步幅适中",
            "快走": "收紧腹部，配合呼吸",
            "慢跑": "前脚掌着地，避免膝盖冲击",
            "标准俯卧撑": "身体成直线，不要塌腰",
            "深蹲": "膝盖不超过脚尖，臀部向后坐",
            "平板支撑": "核心收紧，保持呼吸",
            "八段锦": "动作舒缓，意念随动",
            "太极": "重心稳定，动作圆活"
        }
        return tips_map.get(exercise["name"], "量力而行，注意安全")
    
    def predict_next_stage(self, current_stage, exercises):
        """预估下一阶段"""
        stage_order = ["调整期", "适应期", "基础期", "稳定期", "进阶期", "精英期"]
        
        try:
            idx = stage_order.index(current_stage)
            if idx < len(stage_order) - 1:
                next_stage = stage_order[idx + 1]
                return {
                    "next_stage": next_stage,
                    "suggestion": f"完成当前计划后可尝试{next_stage}方案",
                    "difficulty_hint": "强度提升约20%"
                }
        except ValueError:
            pass
        
        return {"message": "保持当前方案"}
    
    def get_check_criteria(self, exercises):
        """获取检查标准（用于C阶段）"""
        return {
            "completion_rate": "完成80%以上为达标",
            "feeling_check": "运动后体感应为'正常'或'良好'",
            "duration_check": "每个运动达标准时长",
            "video_check": "建议观看视频教程后再开始"
        }
    
    def get_adjustment_rules(self,):
        """获取调整规则（用于A阶段）"""
        return {
            "too_easy": {
                "condition": "完成率>95% + 体感持续良好",
                "action": "升级到下一难度或增加运动量"
            },
            "too_hard": {
                "condition": "完成率<50% 或 体感持续疲劳",
                "action": "降级或减少运动量"
            },
            "normal": {
                "condition": "完成率70-90%",
                "action": "保持当前方案"
            }
        }
    
    def evaluate_and_adjust(self, execution_result, current_plan):
        """
        评估执行结果并调整方案（PDCA的A阶段）
        """
        completion = execution_result.get("completion_rate", 0)
        feeling = execution_result.get("feeling", "normal")
        
        # 判断调整
        if completion > 0.95 and feeling in ["good", "great"]:
            return {
                "action": "upgrade",
                "message": "表现优秀！建议升级方案"
            }
        elif completion < 0.5 or feeling in ["tired", "very_tired"]:
            return {
                "action": "downgrade",
                "message": "有点吃力，建议降低强度"
            }
        else:
            return {
                "action": "maintain",
                "message": "保持得不错，继续坚持"
            }


# 测试
if __name__ == "__main__":
    planner = ExercisePlannerAgent()
    
    user_state = {
        "current_stage": "适应期",
        "abnormal": [{"indicator": "血脂"}],
        "recent_feelings": ["good", "good"],
        "streak_days": 5
    }
    
    plan = planner.generate_plan(user_state)
    print(json.dumps(plan, ensure_ascii=False, indent=2))
