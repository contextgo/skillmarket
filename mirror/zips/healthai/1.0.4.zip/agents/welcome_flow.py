#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
首次激活引导系统 v2.0
完整流程：硬件 → 体检报告 → 健康状况 → 生成方案
"""

import json
from datetime import datetime
from pathlib import Path


class WelcomeFlow:
    """首次激活引导"""
    
    # 用户状态
    STEPS = {
        "STEP1_HARDWARE": "step1_hardware",        # 问有没有手表
        "STEP2_DEVICE": "step2_device",            # 选择设备
        "STEP3_EXAM": "step3_exam",                # 问体检报告
        "STEP4_HEALTH": "step4_health",            # 问健康状况
        "STEP5_COMPLETE": "step5_complete"         # 完成
    }
    
    def __init__(self, storage):
        self.storage = storage
        self.user_state_file = self.storage.base_dir / "user_states.json"
        self.user_states = self.load_states()
    
    def load_states(self):
        """加载用户状态"""
        if self.user_state_file.exists():
            with open(self.user_state_file, "r", encoding="utf-8") as f:
                return json.load(f)
        return {}
    
    def save_states(self):
        """保存用户状态"""
        with open(self.user_state_file, "w", encoding="utf-8") as f:
            json.dump(self.user_states, f, ensure_ascii=False, indent=2)
    
    def is_first_time(self, user_id: str) -> bool:
        """是否首次使用"""
        return user_id not in self.user_states or \
               self.user_states[user_id].get("step", "") == ""
    
    def get_current_step(self, user_id: str) -> str:
        """获取当前步骤"""
        return self.user_states.get(user_id, {}).get("step", "")
    
    def get_welcome_message(self, user_id: str) -> str:
        """获取首次欢迎消息"""
        # 初始化状态
        self.user_states[user_id] = {
            "step": self.STEPS["STEP1_HARDWARE"],
            "created_at": datetime.now().isoformat(),
            "device": None,
            "has_exam_report": None,
            "health_issues": [],
            "all_ok": False,
            "completed": False
        }
        self.save_states()
        
        return self._generate_step1_hardware()
    
    # ==================== 步骤1: 有没有手表 ====================
    
    def _generate_step1_hardware(self) -> str:
        return """
👋 欢迎使用 HealthCoach 2.0！

我是你的智能健康教练 🦞

═══════════════════════════════════

我能帮你：
✅ 分析体检报告，发现健康问题
✅ 生成个性化运动方案
✅ 记录运动打卡，追踪效果
✅ 每周复盘，动态调整方案
✅ 极端情况预警（可选通知家人）

═══════════════════════════════════

现在，告诉我：

你有没有运动手表/手环？

  ① 有 → 帮你配置自动同步
  ② 没有 → 用手动打卡也可以

请回复「有」或「没有」
"""
    
    # ==================== 步骤2: 选择设备 ====================
    
    def _generate_step2_device(self) -> str:
        return """
太好了！配置硬件后，数据自动同步更精准！

═══════════════════════════════════

支持的设备：

✅ COROS 高驰      ✅ Apple Watch
✅ 小米手环/手表  ✅ 华为手表/手环
✅ Garmin         ✅ 还没买，先用手动的

═══════════════════════════════════

你用的是哪个？

请回复品牌名或数字（1-6）
"""
    
    # ==================== 步骤3: 体检报告 ====================
    
    def _generate_step3_exam(self) -> str:
        return """
好的！设备配置完成～

═══════════════════════════════════

下一步：你有最近的体检报告吗？

  ① 有 → 可以发给我，我帮你分析
  ② 没有 → 我可以问你想改善什么问题

（有体检报告分析更精准，没有也OK）
"""
    
    # ==================== 步骤4: 健康状况 ====================
    
    def _generate_step4_health(self, has_exam: bool = False) -> str:
        prefix = "好的，没有体检报告也没关系～" if not has_exam else "没问题！"
        
        return f"""
{prefix}

═══════════════════════════════════

告诉我你的身体状况（可以多选）：

  ① 容易疲劳，没精神
  ② 睡眠不好，失眠
  ③ 体重超标，想减肥
  ④ 血压/血糖高
  ⑤ 膝盖/腰不好的
  ⑥ 经常感冒，免疫力差
  ⑦ 感觉都OK，不需要特别改善

你可以直接说序号，或者用自己的话描述
"""
    
    # ==================== 步骤5: 完成 ====================
    
    def _generate_step5_complete(self, health_issues: list, all_ok: bool) -> str:
        if all_ok:
            return """
═══════════════════════════════════

很好！你的身体状态看起来不错～

我帮你准备一套**抗衰老保健方案**：

🏃 运动建议：
   - 每周4次有氧运动（跑步/游泳/骑行）
   - 每次30-45分钟
   - 心率保持在110-140

🥗 饮食建议：
   - 多吃深色蔬菜水果（抗氧化）
   - 适量补充蛋白质
   - 少油少盐少糖

😴 作息建议：
   - 23点前入睡
   - 每天7-8小时睡眠
   - 睡前冥想10分钟

═══════════════════════════════════

现在开始记录今天的运动？

直接告诉我：今天做了什么运动？
"""
        else:
            issues_text = "\n".join([f"   {i+1}. {issue}" for i, issue in enumerate(health_issues)])
            return f"""
═══════════════════════════════════

了解了你需要改善的问题：
{issues_text}

我正在为你制定个性化方案...

（稍等片刻，马上好！）

═══════════════════════════════════

方案生成后，我会告诉你每天怎么做～

今天先记录一下你的基本情况：
- 年龄：
- 性别：
- 身高：
- 体重：

或者直接告诉我今天的运动情况也可以！
"""
    
    # ==================== 处理用户响应 ====================
    
    def handle_response(self, user_id: str, response: str) -> dict:
        """处理用户响应"""
        if user_id not in self.user_states:
            return {"error": "用户状态错误，请重新开始"}
        
        step = self.get_current_step(user_id)
        response = response.strip()
        
        # 步骤1：有没有手表
        if step == self.STEPS["STEP1_HARDWARE"]:
            if "有" in response:
                self.user_states[user_id]["step"] = self.STEPS["STEP2_DEVICE"]
                self.save_states()
                return {"message": self._generate_step2_device(), "continue": True}
            else:
                # 没有手表，直接进入步骤3（不需要配置硬件）
                self.user_states[user_id]["device"] = "manual"
                self.user_states[user_id]["step"] = self.STEPS["STEP3_EXAM"]
                self.save_states()
                return {"message": self._generate_step3_exam(), "continue": True}
        
        # 步骤2：选择设备
        elif step == self.STEPS["STEP2_DEVICE"]:
            device = self._parse_device(response)
            self.user_states[user_id]["device"] = device
            self.user_states[user_id]["step"] = self.STEPS["STEP3_EXAM"]
            self.save_states()
            
            device_name = {
                "coros": "COROS 高驰",
                "apple": "Apple Watch",
                "xiaomi": "小米",
                "huawei": "华为",
                "garmin": "Garmin",
                "manual": "手动模式"
            }.get(device, "手动模式")
            
            return {
                "message": f"✅ 已选择 {device_name}\n\n" + self._generate_step3_exam(),
                "continue": True
            }
        
        # 步骤3：体检报告
        elif step == self.STEPS["STEP3_EXAM"]:
            if "有" in response:
                self.user_states[user_id]["has_exam_report"] = True
                self.save_states()
                return {
                    "message": "好的！请发给我你的体检报告（PDF/图片都可以）\n\n我会帮你分析报告中的异常指标～",
                    "continue": True
                }
            else:
                self.user_states[user_id]["has_exam_report"] = False
                self.user_states[user_id]["step"] = self.STEPS["STEP4_HEALTH"]
                self.save_states()
                return {"message": self._generate_step4_health(), "continue": True}
        
        # 步骤4：健康状况
        elif step == self.STEPS["STEP4_HEALTH"]:
            issues, all_ok = self._parse_health_issues(response)
            
            self.user_states[user_id]["health_issues"] = issues
            self.user_states[user_id]["all_ok"] = all_ok
            self.user_states[user_id]["step"] = self.STEPS["STEP5_COMPLETE"]
            self.user_states[user_id]["completed"] = True
            self.save_states()
            
            return {"message": self._generate_step5_complete(issues, all_ok), "continue": True}
        
        return {"continue": False, "message": None}
    
    def _parse_device(self, response: str) -> str:
        """解析设备选择"""
        response = response.lower()
        
        if "1" in response or "coros" in response:
            return "coros"
        elif "2" in response or "apple" in response:
            return "apple"
        elif "3" in response or "小米" in response:
            return "xiaomi"
        elif "4" in response or "华为" in response:
            return "huawei"
        elif "5" in response or "garmin" in response:
            return "garmin"
        else:
            return "manual"
    
    def _parse_health_issues(self, response: str) -> tuple:
        """解析健康问题"""
        response = response.lower()
        
        issue_map = {
            "1": "容易疲劳，没精神",
            "2": "睡眠不好，失眠", 
            "3": "体重超标，想减肥",
            "4": "血压/血糖高",
            "5": "膝盖/腰不好",
            "6": "经常感冒，免疫力差",
            "7": "感觉都OK"
        }
        
        issues = []
        
        for num, text in issue_map.items():
            if num in response or text.split("，")[0] in response:
                if num != "7":
                    issues.append(text)
        
        all_ok = "7" in response or "都ok" in response or "没问题" in response
        
        return issues, all_ok
    
    def is_setup_complete(self, user_id: str) -> bool:
        """检查是否完成设置"""
        return self.user_states.get(user_id, {}).get("completed", False)


# 便捷函数
def get_welcome_message(user_id: str) -> str:
    from data.storage import get_storage
    storage = get_storage()
    welcome = WelcomeFlow(storage)
    return welcome.get_welcome_message(user_id)


def handle_welcome_response(user_id: str, response: str) -> dict:
    from data.storage import get_storage
    storage = get_storage()
    welcome = WelcomeFlow(storage)
    return welcome.handle_response(user_id, response)


# 测试
if __name__ == "__main__":
    print("=== 完整引导流程测试 ===\n")
    
    from data.storage import get_storage
    storage = get_storage()
    welcome = WelcomeFlow(storage)
    
    # 步骤1
    print("【步骤1】首次欢迎")
    msg = welcome.get_welcome_message("test_user_999")
    print(msg[:200])
    
    # 步骤2 - 回复"有"
    print("\n【步骤2】用户回复「有」")
    result = welcome.handle_response("test_user_999", "有")
    print(result["message"][:200])
    
    # 步骤3 - 选择1
    print("\n【步骤3】用户选择1 (COROS)")
    result = welcome.handle_response("test_user_999", "1")
    print(result["message"][:200])
    
    # 步骤4 - 回复"没有"
    print("\n【步骤4】用户回复「没有」体检报告")
    result = welcome.handle_response("test_user_999", "没有")
    print(result["message"][:200])
    
    # 步骤5 - 说都OK
    print("\n【步骤5】用户说「都OK」")
    result = welcome.handle_response("test_user_999", "都OK")
    print(result["message"][:300])
    
    print("\n✅ 完整流程测试通过！")
