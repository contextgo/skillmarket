#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
进度预测 Agent
预估用户未来的进度和状态
"""

import json
from datetime import datetime, timedelta
from collections import defaultdict


class ProgressPredictorAgent:
    """进度预测 Agent"""
    
    def __init__(self):
        # 各项指标改善的典型速度（每周）
        self.improvement_rates = {
            "体重": -0.3,      # 每周减0.3kg
            "BMI": -0.1,      # 每周减0.1
            "血压": -2,        # 每周降2mmHg
            "血糖": -0.1,     # 每周降0.1mmol/L
            "血脂": -0.1,     # 每周降0.1mmol/L
            "尿酸": -10,      # 每周降10umol/L
        }
    
    def predict(self, user_state, weeks=4):
        """
        预测用户进度
        输入：用户当前状态 + 预测周数
        输出：预测结果
        """
        # 1. 分析历史趋势
        trend = self.analyze_trend(user_state.get("history", {}))
        
        # 2. 预测下周状态
        next_week = self.predict_next_week(trend, user_state)
        
        # 3. 预测下月状态
        next_month = self.predict_next_month(trend, user_state)
        
        # 4. 风险预警
        risks = self.predict_risks(trend, user_state)
        
        # 5. 里程碑预测
        milestones = self.predict_milestones(trend, user_state, weeks)
        
        return {
            "success": True,
            "predicted_at": datetime.now().isoformat(),
            "prediction_weeks": weeks,
            "trend": trend,
            "next_week_prediction": next_week,
            "next_month_prediction": next_month,
            "risk_warnings": risks,
            "milestones": milestones,
            "confidence": self.calculate_confidence(user_state)
        }
    
    def analyze_trend(self, history):
        """分析历史趋势"""
        if not history:
            return {"status": "insufficient_data"}
        
        # 按指标分组
        indicator_data = defaultdict(list)
        for date, data in history.items():
            if "indicators" in data:
                for name, value in data["indicators"].items():
                    if isinstance(value, (int, float)):
                        indicator_data[name].append({"date": date, "value": value})
        
        trends = {}
        for name, data_list in indicator_data.items():
            if len(data_list) >= 2:
                # 简单线性回归
                values = [d["value"] for d in data_list]
                first_half = sum(values[:len(values)//2]) / (len(values)//2)
                second_half = sum(values[len(values)//2:]) / (len(values) - len(values)//2)
                
                if second_half < first_half:
                    trend = "improving"
                    change_rate = (first_half - second_half) / first_half
                elif second_half > first_half:
                    trend = "declining"
                    change_rate = (second_half - first_half) / first_half
                else:
                    trend = "stable"
                    change_rate = 0
                
                trends[name] = {
                    "trend": trend,
                    "change_rate": change_rate,
                    "recent_value": values[-1]
                }
        
        # 打卡趋势
        checkin_trend = self.analyze_checkin_trend(history)
        
        return {
            "indicators": trends,
            "checkins": checkin_trend,
            "overall": self.calculate_overall_trend(trends, checkin_trend)
        }
    
    def analyze_checkin_trend(self, history):
        """分析打卡趋势"""
        checkin_count = len([d for d in history.values() if d.get("checkin")])
        
        if checkin_count >= 14:
            return {"trend": "excellent", "count": checkin_count}
        elif checkin_count >= 7:
            return {"trend": "good", "count": checkin_count}
        elif checkin_count >= 3:
            return {"trend": "normal", "count": checkin_count}
        else:
            return {"trend": "low", "count": checkin_count}
    
    def calculate_overall_trend(self, indicator_trends, checkin_trend):
        """计算整体趋势"""
        if not indicator_trends:
            return checkin_trend.get("trend", "stable")
        
        improving = sum(1 for t in indicator_trends.values() if t.get("trend") == "improving")
        declining = sum(1 for t in indicator_trends.values() if t.get("trend") == "declining")
        
        if improving > declining:
            return "improving"
        elif declining > improving:
            return "declining"
        else:
            return "stable"
    
    def predict_next_week(self, trend, user_state):
        """预测下周状态"""
        current = user_state.get("indicators", {})
        abn = user_state.get("abnormal", [])
        
        predictions = {}
        
        for item in abn:
            indicator = item.get("indicator", "")
            current_value = current.get(indicator, {}).get("value")
            
            if current_value and indicator in self.improvement_rates:
                rate = self.improvement_rates[indicator]
                # 根据趋势调整
                if trend.get("overall") == "improving":
                    rate *= 1.2
                elif trend.get("overall") == "declining":
                    rate *= 0.5
                
                predicted = current_value + rate
                predictions[indicator] = {
                    "current": current_value,
                    "predicted": round(predicted, 2),
                    "improvement": round(rate, 2)
                }
        
        # 打卡预测
        checkin_trend = trend.get("checkins", {})
        checkin_pred = "保持" if checkin_trend.get("trend") in ["excellent", "good"] else "需要督促"
        
        return {
            "indicator_predictions": predictions,
            "checkin_prediction": checkin_pred,
            "summary": f"预计 {len(predictions)} 项指标改善"
        }
    
    def predict_next_month(self, trend, user_state):
        """预测下月状态"""
        current = user_state.get("indicators", {})
        abn = user_state.get("abnormal", [])
        
        predictions = {}
        
        for item in abn:
            indicator = item.get("indicator", "")
            current_value = current.get(indicator, {}).get("value")
            
            if current_value and indicator in self.improvement_rates:
                rate = self.improvement_rates[indicator] * 4  # 4周
                if trend.get("overall") == "improving":
                    rate *= 1.2
                elif trend.get("overall") == "declining":
                    rate *= 0.5
                
                predicted = current_value + rate
                predictions[indicator] = {
                    "current": current_value,
                    "predicted": round(predicted, 2),
                    "improvement": round(rate, 2),
                    "weeks_4": round(rate, 2)
                }
        
        return {
            "indicator_predictions": predictions,
            "summary": f"预计4周后 {len(predictions)} 项指标改善"
        }
    
    def predict_risks(self, trend, user_state):
        """风险预警"""
        risks = []
        
        # 打卡中断风险
        checkin = trend.get("checkins", {})
        if checkin.get("trend") == "low":
            risks.append({
                "type": "adherence",
                "level": "high",
                "message": "打卡规律较低，可能难以形成习惯"
            })
        
        # 指标恶化风险
        for name, data in trend.get("indicators", {}).items():
            if data.get("trend") == "declining" and data.get("change_rate", 0) > 0.1:
                risks.append({
                    "type": "indicator",
                    "level": "medium",
                    "message": f"{name}指标有恶化趋势，需关注"
                })
        
        # 过度训练风险
        if checkin.get("trend") == "excellent":
            risks.append({
                "type": "overtraining",
                "level": "low",
                "message": "运动强度较高，注意预防过度训练"
            })
        
        return risks
    
    def predict_milestones(self, trend, user_state, weeks):
        """里程碑预测"""
        milestones = []
        current = user_state.get("indicators", {})
        
        # 根据当前状态预测里程碑
        for name, data in current.items():
            if name in self.improvement_rates:
                value = data.get("value")
                if value:
                    rate = self.improvement_rates[name] * weeks
                    predicted = value + rate
                    
                    milestones.append({
                        "indicator": name,
                        "current": value,
                        "predicted": round(predicted, 2),
                        "weeks": weeks
                    })
        
        return milestones
    
    def calculate_confidence(self, user_state):
        """计算预测置信度"""
        history = user_state.get("history", {})
        
        if len(history) >= 14:
            return 0.85
        elif len(history) >= 7:
            return 0.7
        elif len(history) >= 3:
            return 0.5
        else:
            return 0.3


# 测试
if __name__ == "__main__":
    agent = ProgressPredictorAgent()
    
    user_state = {
        "indicators": {
            "体重": {"value": 75},
            "BMI": {"value": 25.3},
            "血脂": {"value": 2.1}
        },
        "abnormal": [
            {"indicator": "体重"},
            {"indicator": "血脂"}
        ],
        "history": {
            "2026-04-01": {"checkin": True, "indicators": {"体重": 78}},
            "2026-04-08": {"checkin": True, "indicators": {"体重": 76}},
            "2026-04-15": {"checkin": True, "indicators": {"体重": 75}},
        }
    }
    
    result = agent.predict(user_state)
    print(json.dumps(result, ensure_ascii=False, indent=2))
