#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
硬件数据采集器 - 统一接口 v2.0
支持多种硬件设备的数据采集
"""

import json
from datetime import datetime, timedelta
from pathlib import Path


class HardwareDataCollector:
    """统一硬件数据采集器"""
    
    def __init__(self, base_dir=None):
        if base_dir is None:
            base_dir = Path(__file__).parent
        
        self.base_dir = Path(base_dir)
        self.config = self.load_config()
    
    def load_config(self):
        """加载配置"""
        config_file = self.base_dir / "config.json"
        
        if config_file.exists():
            with open(config_file, "r", encoding="utf-8") as f:
                return json.load(f)
        
        return {
            "enabled_devices": [],
            "auto_sync": True,
            "sync_interval": 3600,
        }
    
    def get_available_devices(self):
        """获取可用的设备列表"""
        devices = []
        
        # 检查每个支持的设备
        supported = [
            {"id": "coros", "name": "COROS 高驰", "type": "运动手表"},
            {"id": "apple_health", "name": "Apple Watch", "type": "智能手表"},
            {"id": "xiaomi", "name": "小米手环/手表", "type": "运动手环"},
            {"id": "huawei", "name": "华为手表/手环", "type": "运动手环"},
            {"id": "garmin", "name": "Garmin", "type": "运动手表"},
        ]
        
        for device in supported:
            status = self.check_device_status(device["id"])
            devices.append({
                **device,
                **status
            })
        
        return devices
    
    def check_device_status(self, device_id):
        """检查设备状态"""
        if device_id == "coros":
            return self.check_coros()
        elif device_id == "apple_health":
            return self.check_apple_health()
        else:
            return {"status": "not_configured", "ready": False, "how_to": "规划中"}
    
    def check_coros(self):
        """检查 COROS 配置"""
        coros_dir = self.base_dir
        
        # 检查是否有 Node.js 环境和配置
        if (coros_dir / "coros.js").exists():
            # 检查配置文件
            if (coros_dir / ".env").exists():
                with open(coros_dir / ".env", "r") as f:
                    content = f.read()
                    if "COROS_ACCOUNT=" in content and "COROS_PASSWORD=" in content:
                        return {
                            "status": "ready",
                            "ready": True,
                            "how_to": "已配置，可自动同步"
                        }
                    else:
                        return {
                            "status": "configured_not_ready",
                            "ready": False,
                            "how_to": "需要配置账号信息，详见 hardware/README.md"
                        }
        
        return {
            "status": "not_configured",
            "ready": False,
            "how_to": "配置 COROS 账号即可自动同步，详见 hardware/README.md"
        }
    
    def check_apple_health(self):
        """检查 Apple Health 配置"""
        apple_dir = self.base_dir
        
        # 检查是否有导入的数据
        data_file = apple_dir / "apple_health_data.json"
        
        if data_file.exists():
            # 检查数据是否是最新的（7天内）
            mtime = datetime.fromtimestamp(data_file.stat().st_mtime)
            days_ago = (datetime.now() - mtime).days
            
            if days_ago <= 7:
                return {
                    "status": "ready",
                    "ready": True,
                    "how_to": f"数据 {days_ago} 天前导入，可手动重新导入更新"
                }
            else:
                return {
                    "status": "data_stale",
                    "ready": False,
                    "how_to": f"数据 {days_ago} 天前导入，建议重新导出更新"
                }
        
        return {
            "status": "not_configured",
            "ready": False,
            "how_to": "在 iPhone 健康App导出数据，然后导入到系统。详见 hardware/apple_health_sync.md"
        }
    
    def fetch_data(self, device_id=None):
        """获取硬件数据"""
        if device_id:
            return self.fetch_device_data(device_id)
        
        # 获取所有已配置设备的数据
        results = []
        
        for device in self.get_available_devices():
            if device.get("ready"):
                data = self.fetch_device_data(device["id"])
                if data:
                    results.append({
                        "device": device["name"],
                        "data": data
                    })
        
        return results if results else None
    
    def fetch_device_data(self, device_id):
        """获取指定设备数据"""
        if device_id == "coros":
            return self.fetch_coros()
        elif device_id == "apple_health":
            return self.fetch_apple_health()
        
        return None
    
    def fetch_coros(self):
        """获取 COROS 数据"""
        return {
            "device": "COROS 高驰",
            "status": "需要运行 Node.js 脚本",
            "how_to": "详见 hardware/README.md"
        }
    
    def fetch_apple_health(self):
        """获取 Apple Health 数据"""
        data_file = self.base_dir / "apple_health_data.json"
        
        if data_file.exists():
            with open(data_file, "r", encoding="utf-8") as f:
                return json.load(f)
        
        return {
            "device": "Apple Watch",
            "status": "no_data",
            "how_to": "请先导入 Apple Health 数据，详见 hardware/apple_health_sync.md"
        }
    
    def get_status(self):
        """获取硬件接入状态"""
        devices = self.get_available_devices()
        
        configured = [d for d in devices if d.get("ready")]
        
        # 生成用户提示
        tips = []
        for d in devices:
            if not d.get("ready"):
                tips.append(f"• {d['name']}: {d.get('how_to', '未配置')}")
        
        return {
            "has_hardware": len(configured) > 0,
            "configured_devices": configured,
            "all_devices": devices,
            "tips": tips,
            "recommendation": self.get_recommendation(configured, devices)
        }
    
    def get_recommendation(self, configured, all_devices):
        """获取建议"""
        if configured:
            return f"✅ 已检测到 {len(configured)} 个设备数据源，将自动同步"
        
        # 找出最简单的接入方式
        easy_options = [d for d in all_devices if 
                       d["id"] in ["apple_health", "coros"] and 
                       not d.get("ready")]
        
        if easy_options:
            opt = easy_options[0]
            return f"💡 建议接入 {opt['name']}，{opt.get('how_to', '')}"
        
        return "⚠️ 请手动记录运动数据，或配置硬件设备获取更精准的分析"


def get_hardware_status():
    """获取硬件状态"""
    collector = HardwareDataCollector()
    return collector.get_status()


def fetch_hardware_data(device=None):
    """获取硬件数据"""
    collector = HardwareDataCollector()
    return collector.fetch_data(device)


def import_apple_health_xml(xml_path):
    """导入 Apple Health XML 数据"""
    from apple_health import import_apple_health
    
    result = import_apple_health(xml_path)
    
    # 保存到数据文件
    data_file = Path(__file__).parent / "apple_health_data.json"
    with open(data_file, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    
    return result


# 测试
if __name__ == "__main__":
    print("=== 硬件接入状态 ===")
    status = get_hardware_status()
    print(f"是否有硬件: {status['has_hardware']}")
    print(f"已配置设备: {len(status['configured_devices'])}")
    print()
    print("所有设备:")
    for d in status['all_devices']:
        print(f"  - {d['name']}: {d['status']} | {d.get('how_to', '')[:30]}...")
