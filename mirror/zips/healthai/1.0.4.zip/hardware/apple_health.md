# Apple Watch / Apple Health 数据接入

## 接入方案

Apple Watch 的数据通过 **Apple HealthKit** 获取，有以下几种方式：

### 方式一：iPhone 导出 XML（最简单）

1. 打开 iPhone "健康" App
2. 点击右上角头像 → "导出健康数据"
3. 生成 XML 文件，可以导入到我们的系统

**数据类型**：
- 步数 (step count)
- 心率 (heart rate)
- 睡眠 (sleep analysis)
- 运动记录 (workout)
- 卡路里 (active energy)

### 方式二：Shortcuts + API（自动化）

使用 iOS Shortcuts 调用 HealthKit，然后通过 API 发送给我们的系统

### 方式三：HealthKit API（开发者模式）

需要注册 Apple Developer Program，开发原生 iOS App 来读取 HealthKit 数据

---

## 推荐方案

对于我们的系统，推荐 **方式一 + 方式二** 的组合：

1. **用户首次使用**：导出 XML 初始化数据
2. **日常使用**：通过 Shortcuts 定时同步

---

## 数据字段映射

| Apple Health | 对应字段 | 说明 |
|--------------|----------|------|
| stepCount | 步数 | 每日步数 |
| heartRate | 心率 | 静息/运动心率 |
| workout | 运动 | 跑步/骑行等 |
| sleepAnalysis | 睡眠 | 睡眠时长/质量 |
| activeEnergyBurned | 消耗卡路里 | 运动消耗 |

---

## 实现计划

1. **数据解析器** - 解析 Apple 导出的 XML
2. **Shortcuts 集成** - 自动同步
3. **实时数据获取** - 通过 API（可选）

---

## 注意事项

- Apple Health 数据包含隐私，需要用户明确授权
- 导出的 XML 不包含原始传感器数据，仅为汇总统计
- 建议用户定期导出作为备份
