#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
硬件数据采集器 v2.0
整合配置管理、数据采集、异常检测
支持: COROS, Apple Watch, 小米, 华为, Garmin
"""

import json
from datetime import datetime, timedelta
from pathlib import Path

from config_manager import HardwareConfigManager
from data_processor import process_health_data


class HardwareCollector:
    """硬件数据采集器 - 整合版"""
    
    def __init__(self, base_dir=None):
        if base_dir is None:
            base_dir = Path(__file__).parent
        
        self.base_dir = Path(base_dir)
        self.config_manager = HardwareConfigManager(base_dir)
        
        # 数据存储目录
        self.data_dir = self.base_dir / "data"
        self.data_dir.mkdir(exist_ok=True)
    
    def sync_all_devices(self) -> dict:
        """同步所有已配置的设备"""
        config = self.config_manager.generate_cron_config()
        devices = config.get("cron_jobs", [])
        
        results = {
            "sync_time": datetime.now().isoformat(),
            "devices_checked": len(devices),
            "data_collected": [],
            "alerts": [],
        }
        
        for device in devices:
            device_id = device["device_id"]
            
            # 检查是否应该同步
            last_sync = self._get_last_sync_time(device_id)
            if not self.config_manager.should_sync_now(device_id, last_sync):
                continue
            
            # 获取数据
            data = self._fetch_device_data(device)
            
            if data and not data.get("error"):
                # 保存原始数据
                self._save_device_data(device_id, data)
                
                # 处理数据（检测异常）
                processed = self._process_device_data(device_id, data)
                
                results["data_collected"].append({
                    "device_id": device_id,
                    "device_name": device.get("device_name"),
                    "status": "success",
                })
                
                # 如果有实时预警
                if processed.get("type") == "realtime_alert":
                    results["alerts"].append(processed)
        
        # 更新同步时间
        self._update_last_sync_times()
        
        return results
    
    def _fetch_device_data(self, device: dict) -> dict:
        """获取设备数据"""
        device_type = device.get("device_type")
        
        if device_type == "coros":
            return self._fetch_coros()
        elif device_type == "apple_health":
            return self._fetch_apple_health()
        elif device_type == "xiaomi":
            return self._fetch_xiaomi()
        elif device_type == "huawei":
            return self._fetch_huawei()
        elif device_type == "garmin":
            return self._fetch_garmin()
        else:
            return {"error": f"不支持的设备类型: {device_type}"}
    
    def _fetch_coros(self) -> dict:
        """获取 COROS 数据"""
        # 需要先配置 .env 文件
        env_file = self.base_dir / ".env"
        
        if not env_file.exists():
            return {
                "source": "coros",
                "error": "请先配置 COROS 账号（见 hardware/README.md）",
                "how_to": "cp .env.example .env 并编辑"
            }
        
        # 实际应该调用 Node.js 脚本
        # 这里返回模拟结构
        return {
            "source": "coros",
            "timestamp": datetime.now().isoformat(),
            "steps": 0,
            "heart_rate": 0,
            "workout": [],
            "note": "需要配置 COROS 账号才能获取真实数据"
        }
    
    def _fetch_apple_health(self) -> dict:
        """获取 Apple Health 数据"""
        # 检查是否有导入的数据
        import_file = self.base_dir / "apple_health_data.json"
        
        if import_file.exists():
            with open(import_file, "r", encoding="utf-8") as f:
                return json.load(f)
        
        return {
            "source": "apple_health",
            "timestamp": datetime.now().isoformat(),
            "steps": 0,
            "heart_rate": 0,
            "workout": [],
            "note": "需要导入 Apple Health 数据（见 hardware/apple_health_sync.md）"
        }
    
    def _fetch_xiaomi(self) -> dict:
        """获取小米数据"""
        # 检查是否有导入的数据
        import_file = self.base_dir / "data" / "xiaomi_import.csv"
        
        if import_file.exists():
            try:
                from xiaomi import XiaomiHealthData
                handler = XiaomiHealthData()
                return handler.import_from_csv(str(import_file))
            except Exception as e:
                return {"source": "xiaomi", "error": str(e)}
        
        return {
            "source": "xiaomi",
            "timestamp": datetime.now().isoformat(),
            "steps": 0,
            "heart_rate": 0,
            "note": "需要导入小米数据（见 hardware/xiaomi_huawei_guide.md）"
        }
    
    def _fetch_huawei(self) -> dict:
        """获取华为数据"""
        # 检查是否有导入的数据
        import_file = self.base_dir / "data" / "huawei_import.xml"
        
        if import_file.exists():
            try:
                from huawei import HuaweiHealthData
                handler = HuaweiHealthData()
                return handler.import_from_healthkit(str(import_file))
            except Exception as e:
                return {"source": "huawei", "error": str(e)}
        
        return {
            "source": "huawei",
            "timestamp": datetime.now().isoformat(),
            "steps": 0,
            "heart_rate": 0,
            "note": "需要导入华为数据（见 hardware/xiaomi_huawei_guide.md）"
        }
    
    def _fetch_garmin(self) -> dict:
        """获取 Garmin 数据"""
        return {
            "source": "garmin",
            "timestamp": datetime.now().isoformat(),
            "steps": 0,
            "heart_rate": 0,
            "note": "Garmin 支持规划中，可通过 Garmin Connect 导出数据"
        }
    
    def _process_device_data(self, device_id: str, raw_data: dict) -> dict:
        """处理设备数据"""
        # 加载历史基线
        baseline = self._load_baseline(device_id)
        
        # 数据处理
        result = process_health_data(raw_data, baseline)
        
        # 保存处理结果
        self._save_processed_result(device_id, result)
        
        return result
    
    def _save_device_data(self, device_id: str, data: dict):
        """保存设备原始数据"""
        file = self.data_dir / f"device_{device_id}.json"
        
        with open(file, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    
    def _save_processed_result(self, device_id: str, result: dict):
        """保存处理结果"""
        # 实时预警
        if result.get("type") == "realtime_alert":
            alerts_file = self.data_dir / "alerts.json"
            
            alerts = []
            if alerts_file.exists():
                with open(alerts_file, "r") as f:
                    alerts = json.load(f)
            
            alerts.append({
                **result,
                "device_id": device_id,
                "created_at": datetime.now().isoformat()
            })
            
            # 只保留最近10条
            alerts = alerts[-10:]
            
            with open(alerts_file, "w", encoding="utf-8") as f:
                json.dump(alerts, f, ensure_ascii=False, indent=2)
    
    def _load_baseline(self, device_id: str) -> dict:
        """加载历史基线"""
        history_file = self.data_dir / "history.json"
        
        if history_file.exists():
            with open(history_file, "r", encoding="utf-8") as f:
                history = json.load(f)
                return history.get(device_id, {})
        return {}
    
    def _get_last_sync_time(self, device_id: str) -> str:
        """获取上次同步时间"""
        sync_file = self.data_dir / "sync_times.json"
        
        if sync_file.exists():
            with open(sync_file, "r", encoding="utf-8") as f:
                times = json.load(f)
                return times.get(device_id)
        
        return None
    
    def _update_last_sync_times(self):
        """更新所有设备的同步时间"""
        sync_file = self.data_dir / "sync_times.json"
        
        times = {}
        if sync_file.exists():
            with open(sync_file, "r", encoding="utf-8") as f:
                times = json.load(f)
        
        devices = self.config_manager.get_all_devices()
        now = datetime.now().isoformat()
        
        for device_id in devices.keys():
            times[device_id] = now
        
        with open(sync_file, "w", encoding="utf-8") as f:
            json.dump(times, f, ensure_ascii=False, indent=2)
    
    def get_status(self) -> dict:
        """获取硬件状态"""
        config = self.config_manager.generate_cron_config()
        
        return {
            "configured": config.get("total_devices", 0),
            "settlement_time": config.get("settlement_time"),
            "alert_enabled": config.get("alert_enabled"),
            "devices": config.get("cron_jobs", []),
            "supported_devices": [
                {"id": "coros", "name": "COROS 高驰", "status": "ready"},
                {"id": "apple_health", "name": "Apple Watch", "status": "ready"},
                {"id": "xiaomi", "name": "小米手环/手表", "status": "ready"},
                {"id": "huawei", "name": "华为手表/手环", "status": "ready"},
                {"id": "garmin", "name": "Garmin", "status": "ready"},
            ]
        }
    
    def get_pending_alerts(self) -> list:
        """获取待处理的预警"""
        alerts_file = self.data_dir / "alerts.json"
        
        if alerts_file.exists():
            with open(alerts_file, "r", encoding="utf-8") as f:
                return json.load(f)
        
        return []


def run_sync():
    """运行同步（供 cron 调用）"""
    collector = HardwareCollector()
    result = collector.sync_all_devices()
    
    # 检查是否有预警需要处理
    alerts = result.get("alerts", [])
    if alerts:
        print(f"发现 {len(alerts)} 个预警！")
        for alert in alerts:
            print(f"  - {alert.get('message', 'Unknown')}")
    
    return result


# 测试
if __name__ == "__main__":
    print("=== 硬件采集器 v2.0 测试 ===\n")
    
    collector = HardwareCollector()
    status = collector.get_status()
    
    print("状态:")
    print(json.dumps(status, ensure_ascii=False, indent=2))
