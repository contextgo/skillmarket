#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Garmin 手表数据接入
支持 Garmin Connect 数据同步

接入方式：
1. Garmin Connect 网页导出
2. 第三方工具（Garmin Express, Garmin Fit SDK）
3. Strava 同步
"""

import json
from datetime import datetime
from pathlib import Path


class GarminHealthData:
    """Garmin 健康数据"""
    
    # 数据字段映射
    FIELD_MAPPING = {
        "steps": "步数",
        "distance": "距离",
        "activeMinutes": "活动时间",
        "heartRate": "心率",
        "restingHeartRate": "静息心率",
        "sleep": "睡眠",
        "calories": "卡路里",
        "stress": "压力",
        "bodyBattery": "身体电量",
        "oxygenSaturation": "血氧",
        "respiratoryRate": "呼吸率",
        "hydration": "饮水量",
    }
    
    def __init__(self):
        self.data = {}
    
    def import_from_garmin_connect(self, export_file: str) -> dict:
        """
        从 Garmin Connect 导出的数据导入
        
        导出方式：
        1. 登录 Garmin Connect (connect.garmin.com)
        2. 设置 → 我的数据 → 导出数据
        3. 下载 ZIP 文件
        """
        file_path = Path(export_file)
        
        if not file_path.exists():
            return {"error": "文件不存在"}
        
        # 解压并解析 ZIP
        if file_path.suffix == ".zip":
            return self._parse_zip_export(str(file_path))
        
        # 解析 JSON 文件
        if file_path.suffix == ".json":
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                return self._parse_garmin_json(data)
            except Exception as e:
                return {"error": f"解析失败: {e}"}
        
        return {"error": "不支持的文件格式"}
    
    def _parse_zip_export(self, zip_path: str) -> dict:
        """解析 Garmin 导出的 ZIP 文件"""
        import zipfile
        
        try:
            with zipfile.ZipFile(zip_path, "r") as z:
                # 列出ZIP内容
                files = z.namelist()
                
                # 查找 JSON 文件
                json_files = [f for f in files if f.endswith(".json")]
                
                parsed_data = {
                    "source": "garmin_export",
                    "files": [],
                }
                
                for jf in json_files:
                    if "dailies" in jf.lower():
                        # 每日数据
                        content = z.read(jf)
                        try:
                            dailies = json.loads(content)
                            parsed_data["dailies"] = dailies
                        except:
                            pass
                    
                    elif "sleep" in jf.lower():
                        # 睡眠数据
                        content = z.read(jf)
                        try:
                            sleep = json.loads(content)
                            parsed_data["sleep"] = sleep
                        except:
                            pass
                    
                    elif "activities" in jf.lower():
                        # 运动记录
                        content = z.read(jf)
                        try:
                            activities = json.loads(content)
                            parsed_data["activities"] = activities
                        except:
                            pass
                
                parsed_data["file_count"] = len(json_files)
                return parsed_data
                
        except Exception as e:
            return {"error": f"解压失败: {e}"}
    
    def _parse_garmin_json(self, data: dict) -> dict:
        """解析 Garmin JSON 格式"""
        parsed = {
            "source": "garmin",
            "records": [],
        }
        
        # 解析每日数据
        if isinstance(data, list):
            for item in data:
                if "date" in item or "summaryDate" in item:
                    parsed["records"].append(item)
        elif isinstance(data, dict):
            if "dailies" in data:
                parsed["records"] = data["dailies"]
        
        return parsed
    
    def import_from_strava(self, strava_export_path: str) -> dict:
        """
        从 Strava 导出的数据导入
        
        很多 Garmin 用户会同步到 Strava
        Strava 导出更简单
        """
        file_path = Path(strava_export_path)
        
        if not file_path.exists():
            return {"error": "文件不存在"}
        
        # 查找 activities.csv
        csv_file = file_path / "activities.csv"
        
        if csv_file.exists():
            return self._parse_strava_csv(str(csv_file))
        
        return {"error": "未找到 activities.csv"}
    
    def _parse_strava_csv(self, csv_path: str) -> dict:
        """解析 Strava CSV"""
        import csv
        
        records = []
        
        try:
            with open(csv_path, "r", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    records.append({
                        "activity_name": row.get("Activity Name", ""),
                        "date": row.get("Date", ""),
                        "type": row.get("Activity Type", ""),
                        "distance": float(row.get("Distance", 0)),
                        "moving_time": row.get("Moving Time", ""),
                        "elapsed_time": row.get("Elapsed Time", ""),
                        "elevation": float(row.get("Elevation Gain", 0)),
                        "calories": float(row.get("Calories", 0)),
                    })
            
            return {
                "source": "strava",
                "records": records,
                "count": len(records),
            }
            
        except Exception as e:
            return {"error": str(e)}
    
    def import_from_fit(self, fit_file: str) -> dict:
        """
        从 FIT 文件导入（Garmin 标准格式）
        
        FIT 是 Garmin 设备的原生格式
        需要 fitdecode 库
        """
        try:
            # 需要安装: pip install fitdecode
            import fitdecode
            
            records = []
            
            with fitdecode.FitReader(fit_file) as fit:
                for frame in fit:
                    if frame.frame_type == fitdecode.FIT_FRAME_DATA:
                        # 提取数据
                        record = {}
                        for field in frame.fields:
                            record[field.name] = field.value
                        if record:
                            records.append(record)
            
            return {
                "source": "fit",
                "records": records,
                "count": len(records),
            }
            
        except ImportError:
            return {"error": "需要安装 fitdecode: pip install fitdecode"}
        except Exception as e:
            return {"error": str(e)}
    
    def get_daily_summary(self, date: str = None) -> dict:
        """获取指定日期的汇总"""
        if not self.data.get("records"):
            return {}
        
        if date is None:
            date = datetime.now().strftime("%Y-%m-%d")
        
        for record in self.data.get("records", []):
            record_date = record.get("date", "")
            if record_date == date or record_date.startswith(date):
                return {
                    "date": date,
                    "steps": record.get("steps", 0),
                    "distance": record.get("distance", 0),
                    "active_minutes": record.get("activeMinutes", 0),
                    "calories": record.get("calories", 0),
                    "sleep_hours": record.get("sleep", {}).get("sleepDuration", 0) if isinstance(record.get("sleep"), dict) else 0,
                }
        
        return {}


def import_garmin_data(file_path: str) -> dict:
    """导入 Garmin 数据便捷函数"""
    handler = GarminHealthData()
    
    file_path = Path(file_path)
    
    if file_path.suffix == ".zip":
        return handler.import_from_garmin_connect(str(file_path))
    elif file_path.suffix == ".fit":
        return handler.import_from_fit(str(file_path))
    elif file_path.is_dir():
        return handler.import_from_strava(str(file_path))
    else:
        return handler.import_from_garmin_connect(str(file_path))


# 测试
if __name__ == "__main__":
    print("=== Garmin 数据接入 ===")
    print("")
    print("使用方法：")
    print("1. 从 Garmin Connect 导出数据")
    print("2. 或使用 Strava 同步后导出")
    print("3. 使用 import_garmin_data('导出文件路径') 导入")
    print("")
    print("支持的导出格式：")
    print("  - ZIP 文件（Garmin Connect 导出）")
    print("  - FIT 文件（设备原始格式）")
    print("  - CSV 文件（Strava 导出）")
    print("  - 文件夹（Strava 导出目录）")
