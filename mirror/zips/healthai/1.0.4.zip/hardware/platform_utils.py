#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
跨平台工具库
支持 Windows / macOS / Linux
"""

import sys
import platform
import subprocess
from pathlib import Path


def get_platform() -> str:
    """获取当前平台"""
    system = platform.system().lower()
    
    if system == "darwin":
        return "macos"
    elif system == "windows":
        return "windows"
    elif system == "linux":
        return "linux"
    else:
        return system


def get_downloads_folder() -> Path:
    """获取各平台的下载文件夹"""
    system = get_platform()
    
    if system == "windows":
        # Windows: 用户目录/Downloads
        return Path.home() / "Downloads"
    elif system == "macos":
        return Path.home() / "Downloads"
    elif system == "linux":
        # Linux 可能有多种情况
        download = Path.home() / "Downloads"
        if not download.exists():
            download = Path.home() / "下载"
        return download
    else:
        return Path.home() / "Downloads"


def get_data_folder(app_name: str = "HealthCoach") -> Path:
    """获取应用数据文件夹"""
    system = get_platform()
    
    if system == "windows":
        # Windows: AppData/Local
        return Path.home() / "AppData" / "Local" / app_name
    elif system == "macos":
        # macOS: Library/Application Support
        return Path.home() / "Library" / "Application Support" / app_name
    elif system == "linux":
        # Linux: .local/share
        return Path.home() / ".local" / "share" / app_name
    else:
        return Path.home() / app_name


def run_cron_job(cron_expr: str, command: str) -> bool:
    """设置定时任务（跨平台）"""
    system = get_platform()
    
    if system == "windows":
        return _add_windows_task(cron_expr, command)
    else:
        # macOS / Linux 使用 crontab
        return _add_cron_job(cron_expr, command)


def _add_cron_job(cron_expr: str, command: str) -> bool:
    """添加 crontab 任务（macOS/Linux）"""
    try:
        # 读取现有 crontab
        result = subprocess.run(
            ["crontab", "-l"],
            capture_output=True,
            text=True
        )
        
        existing = result.stdout if result.returncode == 0 else ""
        
        # 添加新任务
        new_cron = f"{cron_expr} {command}\n{existing}"
        
        # 写入 crontab
        proc = subprocess.Popen(
            ["crontab", "-"],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        proc.communicate(input=new_cron.encode())
        
        return True
    except Exception as e:
        print(f"设置cron失败: {e}")
        return False


def _add_windows_task(cron_expr: str, command: str) -> bool:
    """
    添加 Windows 计划任务
    
    注意：cron_expr 格式需要转换为 Windows 格式
    例如: "0 7 * * *" -> 每天7点
    """
    try:
        # 解析 cron 表达式
        parts = cron_expr.split()
        if len(parts) != 5:
            return False
        
        minute, hour, _, _, _ = parts
        
        # 构建 schtasks 命令
        task_name = "HealthCoach_Sync"
        
        # 转换时间格式
        if minute == "*":
            minute = "0"
        if hour == "*":
            hour = "0"
        
        # 创建计划任务
        cmd = f'schtasks /create /tn "{task_name}" /tr "{command}" /sc daily /st {hour}:{minute} /f'
        
        subprocess.run(cmd, shell=True, check=True)
        return True
    except Exception as e:
        print(f"设置Windows任务失败: {e}")
        return False


def detect_node() -> bool:
    """检测是否有 Node.js"""
    try:
        result = subprocess.run(
            ["node", "--version"],
            capture_output=True,
            text=True
        )
        return result.returncode == 0
    except:
        return False


def detect_python() -> str:
    """检测 Python 版本"""
    return f"{sys.version_info.major}.{sys.version_info.minor}"


def is_venv() -> bool:
    """是否在虚拟环境中"""
    return (hasattr(sys, 'real_prefix') or 
            (hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix))


# 平台信息
PLATFORM_INFO = {
    "platform": get_platform(),
    "system": platform.system(),
    "release": platform.release(),
    "python": detect_python(),
    "node": detect_node(),
    "is_venv": is_venv(),
    "downloads": str(get_downloads_folder()),
    "data_folder": str(get_data_folder()),
}


def print_platform_info():
    """打印平台信息"""
    print("=== 系统信息 ===")
    for key, value in PLATFORM_INFO.items():
        print(f"  {key}: {value}")


# 测试
if __name__ == "__main__":
    print_platform_info()
