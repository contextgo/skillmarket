# 小米/华为手表接入指南

## 支持的设备

| 品牌 | 型号 | 数据类型 | 接入方式 |
|------|------|----------|----------|
| **小米** | 小米手环9/8/7 | 步数、心率、睡眠、运动 | App导出/CSV |
| **小米** | 小米手表S系列 | 步数、心率、GPS轨迹 | App导出 |
| **华为** | Watch GT系列 | 步数、心率、血氧、睡眠 | 健康App导出 |
| **华为** | Watch D/Fit | 步数、心率、血压 | 健康App导出 |

---

## 小米手环/手表接入

### 方法一：小米运动健康 App 导出（推荐）

**步骤：**
1. 打开 **小米运动健康** App
2. 点击右下角 **我的** → **设置**
3. 找到 **数据导出** 或 **导出健康数据**
4. 选择导出格式（推荐 CSV）
5. 发送到电脑

**数据字段：**
| 字段 | 说明 |
|------|------|
| date | 日期 |
| steps | 步数 |
| heart_rate | 心率 |
| sleep_hours | 睡眠时长 |
| calories | 卡路里消耗 |
| distance | 距离（米） |

### 方法二：第三方同步

- **Sync to Google Fit**（需要谷歌服务）
- **Notion 模板**（手动同步）

---

## 华为手表/手表接入

### 方法一：华为健康 App 导出

**步骤：**
1. 打开 **华为健康** App
2. 点击右下角 **我的** → **数据导出**
3. 选择导出项目（步数、心率、睡眠等）
4. 发送到电脑

### 方法二：通过 Garmin Connect

如果你同时使用 Garmin Connect：
1. 华为手表 → 同步到 Garmin Connect
2. Garmin Connect → 导出数据
3. 导入到 HealthCoach

### 方法三：FIT 文件（高级）

华为手表导出的运动记录通常是 **.fit** 格式：
- 需要解析 FIT 二进制文件
- 可提取详细运动轨迹、心率曲线

---

## 数据字段对照

| 统一字段 | 小米 | 华为 | 说明 |
|----------|------|------|------|
| steps | steps | stepCount | 每日步数 |
| heart_rate | heart_rate | heartRate | 心率 |
| sleep_hours | sleep_hours | sleep | 睡眠时长 |
| calories | calories | calories | 消耗卡路里 |
| distance | distance | distance | 距离 |
| spo2 | - | spO2 | 血氧（部分型号） |
| stress | - | stress | 压力（部分型号） |

---

## 导入命令

### 小米数据
```python
from hardware.xiaomi import import_xiaomi_data

# 导入 CSV 文件
result = import_xiaomi_data("~/Downloads/mi_health_export.csv")

# 导入文件夹
result = import_xiaomi_data("~/Downloads/mi_export_folder/")
```

### 华为数据
```python
from hardware.huawei import import_huawei_data

# 导入 XML
result = import_huawei_data("~/Downloads/huawei_health.xml")

# 导入 FIT 文件
result = import_huawei_data("~/Downloads/workout.fit")
```

---

## 常见问题

**Q: 华为/小米导出数据收费吗？**
A: 官方App导出是免费的

**Q: 导出的数据包含 GPS 轨迹吗？**
A: 包含，但需要 .fit 格式文件

**Q: 可以自动同步吗？**
A: 目前需要手动导出，后续可设置定时读取特定文件夹

**Q: 数据安全吗？**
A: 所有数据存在本地，不上传云端

---

## 自动同步设置

如果你想定期同步：

1. 将导出的数据放到固定文件夹
2. 设置定时任务读取该文件夹
3. 系统会自动解析新文件

示例：
```bash
# 每天早上8点检查小米数据
0 8 * * * cp ~/Downloads/mi_export.csv ~/HealthCoach/hardware/data/xiaomi_import.csv
```

---

## Garmin 手表接入

### 方法一：Garmin Connect 导出

**步骤：**
1. 登录 [Garmin Connect](https://connect.garmin.com)
2. 点击 **设置** → **我的数据** → **导出数据**
3. 下载 ZIP 文件
4. 导入到 HealthCoach

### 方法二：Strava 同步

如果你同时使用 Strava：
1. Strava → 设置 → **导出 Strava 数据**
2. 下载 ZIP 文件
3. 导入到 HealthCoach

### 方法三：直接读取 FIT 文件

Garmin 设备导出的运动记录通常是 **.fit** 格式：
- 需要 fitdecode 库解析
- 可提取详细运动轨迹、心率曲线、GPS数据

### 数据字段

| 统一字段 | Garmin | 说明 |
|----------|--------|------|
| steps | steps | 每日步数 |
| distance | distance | 距离 |
| activeMinutes | activeMinutes | 活动时间 |
| heartRate | heartRate | 心率 |
| restingHeartRate | restingHeartRate | 静息心率 |
| calories | calories | 卡路里 |
| sleep | sleep | 睡眠 |
| stress | stress | 压力 |
| bodyBattery | bodyBattery | 身体电量 |
| oxygen | oxygenSaturation | 血氧 |

### 导入命令

```python
from hardware.garmin import import_garmin_data

# 导入 Garmin Connect 导出的 ZIP
result = import_garmin_data("~/Downloads/garmin_export.zip")

# 导入 Strava 导出的文件夹
result = import_garmin_data("~/Downloads/strava_export/")

# 导入单个 FIT 文件
result = import_garmin_data("~/Downloads/morning_run.fit")
```
