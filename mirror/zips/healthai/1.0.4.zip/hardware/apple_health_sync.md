# Apple Health 自动同步方案

## 方案一：iPhone 导出 XML（初始化）

### 操作步骤

1. **打开 iPhone "健康" App**
2. **点击右上角头像** → "导出健康数据"
3. **生成 XML 文件**（可能需要几分钟）
4. **通过微信/邮件发送到电脑**
5. **在我们的系统中导入**

### 导入命令

```python
from hardware.apple_health import import_apple_health

# 导入 XML 文件
result = import_apple_health("~/Downloads/export.xml")

print(result['summary'])  # 打印汇总
```

---

## 方案二：Shortcuts 自动同步（日常）

### 创建 Shortcut

1. 打开 **Shortcuts** App
2. 创建新的 Shortcut
3. 添加以下操作：

```
1. HealthKit → "获取步数"
   - 日期: 今天
   - 样本类型: 计步数

2. HealthKit → "获取心率"
   - 日期: 今天

3. HealthKit → "获取运动"
   - 日期: 今天

3. Text → 格式化数据为 JSON

4. URL → 发送 HTTP 请求
   - 目标: 你的服务器 API
   - 方法: POST
   - 内容: JSON 数据
```

### 自动触发

设置自动化：
- 每天早上 7:00 自动执行
- 或每次运动结束后执行

---

## 方案三：第三方服务

如果有第三方服务（如 QS Access, QS Read），可以通过它们导出 CSV 然后导入

---

## 快速开始

### 第一次使用

```bash
# 1. 导出 Apple Health 数据
#    健康App → 头像 → 导出健康数据

# 2. 导入到系统
cd HealthSkill-2.0/hardware
python3 -c "
from apple_health import import_apple_health
result = import_apple_health('/path/to/export.xml')
print('导入成功！')
print('今日步数:', result['summary']['steps'])
"
```

### 定期同步（推荐 Shortcuts）

配置 Shortcuts 后，每天自动同步，无需手动操作

---

## 数据映射

| Apple Health | 系统字段 | 说明 |
|--------------|----------|------|
| stepCount | steps | 每日总步数 |
| heartRate | heart_rate | 心率采样 |
| workout | workouts | 运动记录 |
| sleepAnalysis | sleep | 睡眠分析 |
| activeEnergyBurned | calories | 消耗卡路里 |
