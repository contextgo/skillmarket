#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
硬件配置命令行工具
用户可以通过此工具配置硬件同步参数
"""

import sys
import json
from config_manager import HardwareConfigManager, add_hardware_device


def show_menu():
    """显示菜单"""
    print("""
🏃 HealthCoach 硬件配置
━━━━━━━━━━━━━━━━━━━━━━━━

1. 查看当前配置
2. 添加设备（COROS 高驰）
3. 添加设备（Apple Watch）
4. 添加设备（小米手环）
5. 移除设备
6. 修改同步频率
7. 修改结算时间
8. 生成 cron 命令
9. 帮助/说明

0. 退出
""")


def view_config():
    """查看配置"""
    manager = HardwareConfigManager()
    config = manager.config
    
    print("\n📋 当前配置:")
    print(f"  自动同步: {'开启' if config['global_settings']['enable_auto_sync'] else '关闭'}")
    print(f"  结算时间: {config['global_settings']['settlement_time']}")
    print(f"  异常提醒: {'开启' if config['global_settings']['alert_enabled'] else '关闭'}")
    
    devices = config.get("devices", {})
    print(f"\n📱 已配置设备: {len(devices)}")
    
    for device_id, device in devices.items():
        print(f"\n  [{device_id}]")
        print(f"    名称: {device.get('name')}")
        print(f"    类型: {device.get('type')}")
        print(f"    同步间隔: {device.get('sync_interval', 3600)//60} 分钟")
        print(f"    同步时段: {device.get('sync_start')}-{device.get('sync_end')}")
    
    print()


def add_device_menu():
    """添加设备菜单"""
    print("""
选择设备类型:
1. COROS 高驰手表
2. Apple Watch (iPhone健康App)
3. 小米手环/手表
4. 华为手表
""")
    
    choice = input("请选择 (1-4): ").strip()
    
    name = input("给设备起个名字（如'我的手表'）: ").strip()
    
    interval = input("同步间隔（分钟，默认60）: ").strip()
    if not interval:
        interval = 60
    else:
        interval = int(interval)
    
    device_map = {
        "1": "coros",
        "2": "apple_health",
        "3": "xiaomi",
        "4": "huawei"
    }
    
    device_type = device_map.get(choice)
    if not device_type:
        print("❌ 无效选择")
        return
    
    result = add_hardware_device(device_type, name, sync_interval=interval*60)
    print(f"\n✅ 已添加设备: {name}")
    print(f"   类型: {device_type}")
    print(f"   同步间隔: {interval} 分钟")


def remove_device():
    """移除设备"""
    manager = HardwareConfigManager()
    devices = manager.get_all_devices()
    
    if not devices:
        print("❌ 暂无可移除的设备")
        return
    
    print("\n可移除的设备:")
    for i, (device_id, device) in enumerate(devices.items(), 1):
        print(f"  {i}. {device.get('name')} ({device.get('type')})")
    
    choice = input("\n选择要移除的设备编号: ").strip()
    
    try:
        device_id = list(devices.keys())[int(choice) - 1]
        manager.remove_device(device_id)
        print(f"\n✅ 已移除设备")
    except (ValueError, IndexError):
        print("❌ 无效选择")


def update_sync_interval():
    """修改同步间隔"""
    manager = HardwareConfigManager()
    devices = manager.get_all_devices()
    
    if not devices:
        print("❌ 暂无可配置的设备")
        return
    
    print("\n可配置的设备:")
    for i, (device_id, device) in enumerate(devices.items(), 1):
        print(f"  {i}. {device.get('name')} (当前: {device.get('sync_interval', 3600)//60}分钟)")
    
    choice = input("\n选择要修改的设备编号: ").strip()
    
    try:
        device_id = list(devices.keys())[int(choice) - 1]
        interval = input("新的同步间隔（分钟）: ").strip()
        
        if interval:
            interval = int(interval) * 60
            device = manager.get_device(device_id)
            device["sync_interval"] = interval
            manager.save_config()
            print(f"\n✅ 已更新同步间隔为 {interval//60} 分钟")
    except (ValueError, IndexError):
        print("❌ 无效选择")


def update_settlement_time():
    """修改结算时间"""
    manager = HardwareConfigManager()
    
    current = manager.get_global_settings().get("settlement_time", "21:00")
    print(f"\n当前结算时间: {current}")
    
    new_time = input("新的结算时间（格式HH:MM，如21:00）: ").strip()
    
    if new_time:
        manager.update_global_settings({"settlement_time": new_time})
        print(f"\n✅ 已更新结算时间为 {new_time}")


def generate_cron():
    """生成 cron 命令"""
    manager = HardwareConfigManager()
    config = manager.generate_cron_config()
    
    print("\n📜 Cron 配置:")
    print(f"  结算时间: {config['settlement_time']}")
    print(f"  设备数量: {config['total_devices']}")
    
    for job in config.get("cron_jobs", []):
        print(f"\n  设备: {job['device_name']}")
        print(f"    Cron: {job['cron_expression']}")
    
    print("\n\n💡 使用方法:")
    print("  将上述 cron 表达式添加到 crontab:")
    print("  crontab -e")
    print("  然后按格式添加定时任务")


def show_help():
    """显示帮助"""
    print("""
📖 帮助说明

🏃 HealthCoach 硬件配置

【支持的设备】
- COROS 高驰: 运动手表，自动同步运动数据
- Apple Watch: 通过 iPhone 健康App导出数据
- 小米/华为: 规划中

【同步频率选择建议】
- 10-30分钟: 实时监测（有心率异常风险的用户）
- 1小时: 常规推荐
- 2-4小时: 省电模式
- 每天1次: 最低频率

【结算时间】
- 建议设为晚上21:00-22:00
- 此时当日运动数据基本完整

【异常提醒】
- 心率 > 140: 紧急提醒
- 连续3天 < 1000步: 警告提醒
- 睡眠 < 5小时: 警告提醒
""")


def main():
    """主函数"""
    while True:
        show_menu()
        choice = input("请选择 (0-9): ").strip()
        
        if choice == "0":
            print("\n👋 再见！")
            break
        elif choice == "1":
            view_config()
        elif choice == "2":
            # COROS
            result = add_hardware_device("coros", "我的高驰手表", sync_interval=3600)
            print(f"\n✅ 已添加 COROS 高驰手表")
            print(f"   同步间隔: 1小时")
        elif choice == "3":
            # Apple Watch
            result = add_hardware_device("apple_health", "我的Apple Watch", sync_interval=3600)
            print(f"\n✅ 已添加 Apple Watch")
            print(f"   同步间隔: 1小时")
            print("   提示: 需要在 iPhone 健康App导出数据")
        elif choice == "4":
            # 小米
            result = add_hardware_device("xiaomi", "小米手环", sync_interval=3600)
            print(f"\n✅ 已添加小米手环")
        elif choice == "5":
            remove_device()
        elif choice == "6":
            update_sync_interval()
        elif choice == "7":
            update_settlement_time()
        elif choice == "8":
            generate_cron()
        elif choice == "9":
            show_help()
        else:
            print("❌ 无效选择")


if __name__ == "__main__":
    main()
