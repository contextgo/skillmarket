#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
紧急通知系统
只发送极端情况：心率为0或<30
"""

import json
from datetime import datetime
from pathlib import Path


class EmergencyNotifier:
    """紧急通知器"""
    
    def __init__(self, config_dir=None):
        if config_dir is None:
            config_dir = Path(__file__).parent
        
        self.config_dir = Path(config_dir)
        self.config_file = self.config_dir / "emergency_config.json"
        self.config = self.load_config()
    
    def load_config(self):
        """加载配置"""
        if self.config_file.exists():
            with open(self.config_file, "r", encoding="utf-8") as f:
                return json.load(f)
        
        return self.get_default_config()
    
    def get_default_config(self):
        """默认配置"""
        return {
            "enabled": False,  # 默认关闭
            "service": None,   # 短信服务商：aliyun/tencent
            "api_key": None,
            "api_secret": None,
            "sign_name": None,  # 短信签名
            "template_id": None,  # 短信模板ID
            "contacts": [],  # 紧急联系人列表
            "last_notification": None,
            "notify_cooldown": 3600,  # 通知冷却时间（秒）
        }
    
    def save_config(self):
        """保存配置"""
        with open(self.config_file, "w", encoding="utf-8") as f:
            json.dump(self.config, f, ensure_ascii=False, indent=2)
    
    def is_enabled(self) -> bool:
        """是否开启"""
        return self.config.get("enabled", False)
    
    def add_contact(self, name: str, phone: str, relation: str = ""):
        """添加紧急联系人（电话加密存储）"""
        import hashlib
        
        # 电话加密存储（SHA256，前8位用于显示）
        phone_hash = hashlib.sha256(phone.encode()).hexdigest()
        phone_display = phone[:3] + "****" + phone[-4:]
        
        contact = {
            "name": name,
            "phone_hash": phone_hash,
            "phone_display": phone_display,  # 只显示部分
            "relation": relation,
            "added_at": datetime.now().isoformat()
        }
        
        self.config["contacts"].append(contact)
        self.save_config()
        
        return f"已添加紧急联系人: {name} ({phone_display})"
    
    def remove_contact(self, name: str):
        """移除紧急联系人"""
        contacts = self.config.get("contacts", [])
        self.config["contacts"] = [c for c in contacts if c.get("name") != name]
        self.save_config()
    
    def get_contacts(self):
        """获取联系人列表（隐藏电话）"""
        return [
            {
                "name": c.get("name"),
                "phone": c.get("phone_display"),
                "relation": c.get("relation")
            }
            for c in self.config.get("contacts", [])
        ]
    
    def enable(self, service: str, api_key: str, api_secret: str, 
               sign_name: str, template_id: str):
        """启用紧急通知"""
        self.config["enabled"] = True
        self.config["service"] = service
        self.config["api_key"] = api_key
        self.config["api_secret"] = api_secret
        self.config["sign_name"] = sign_name
        self.config["template_id"] = template_id
        self.save_config()
        
        return "✅ 紧急通知已开启！\n只会在极端情况下（心率为0或<30）发送短信"
    
    def disable(self):
        """关闭紧急通知"""
        self.config["enabled"] = False
        self.save_config()
        return "❌ 紧急通知已关闭"
    
    def send_emergency_sms(self, user_name: str, emergency_type: str, 
                           value: str = "") -> dict:
        """发送紧急短信（仅极端情况）"""
        
        if not self.is_enabled():
            return {"success": False, "reason": "紧急通知未开启"}
        
        # 检查冷却时间
        last = self.config.get("last_notification")
        if last:
            last_time = datetime.fromisoformat(last)
            cooldown = self.config.get("notify_cooldown", 3600)
            if (datetime.now() - last_time).total_seconds() < cooldown:
                return {"success": False, "reason": "冷却时间内"}
        
        # 消息模板
        message_templates = {
            "heart_rate_zero": f"【HealthCoach健康预警】{user_name}当前心率为0，请立即联系确认安全！",
            "heart_rate_critical": f"【HealthCoach健康预警】{user_name}当前心率异常（{value}），请尽快联系确认！",
        }
        
        message = message_templates.get(emergency_type, 
            f"【HealthCoach健康预警】{user_name}健康数据异常，请关注！")
        
        # 发送短信
        contacts = self.config.get("contacts", [])
        
        if not contacts:
            return {"success": False, "reason": "没有配置紧急联系人"}
        
        # 实际发送（需要配置API）
        results = []
        
        for contact in contacts:
            # 这里调用实际的SMS API
            # 实际部署时需要配置阿里云/腾讯云
            result = self._send_via_api(
                contact.get("phone_hash"),  # 实际发送需要解密
                message,
                contact.get("name")
            )
            results.append(result)
        
        # 更新最后通知时间
        self.config["last_notification"] = datetime.now().isoformat()
        self.save_config()
        
        return {
            "success": True,
            "contacts_notified": len(contacts),
            "message": message,
        }
    
    def _send_via_api(self, phone: str, message: str, name: str) -> dict:
        """
        实际发送短信（需要配置API）
        
        实际部署时替换为真正的API调用
        """
        service = self.config.get("service")
        
        if service == "aliyun":
            # 阿里云短信调用
            # 需要安装 aliyun-python-sdk-core
            pass
        elif service == "tencent":
            # 腾讯云短信调用
            # 需要安装 tencentcloud-sdk-python
            pass
        
        # 当前返回模拟结果
        return {
            "to": name,
            "status": "simulated",
            "note": "需要配置API密钥才能真正发送"
        }
    
    def get_status(self) -> dict:
        """获取状态"""
        return {
            "enabled": self.is_enabled(),
            "service": self.config.get("service"),
            "contacts_count": len(self.config.get("contacts", [])),
            "contacts": self.get_contacts(),
        }


# 便捷函数
def get_notifier():
    return EmergencyNotifier()


def send_emergency(emergency_type: str, user_name: str = "用户", 
                   value: str = "") -> dict:
    """发送紧急通知"""
    notifier = get_notifier()
    
    # 只处理极端情况
    if emergency_type not in ["heart_rate_zero", "heart_rate_critical"]:
        return {"success": False, "reason": "非极端情况，不发送"}
    
    return notifier.send_emergency_sms(user_name, emergency_type, value)


# 测试
if __name__ == "__main__":
    notifier = EmergencyNotifier()
    
    print("=== 紧急通知系统 ===\n")
    
    # 测试状态
    status = notifier.get_status()
    print(f"开启状态: {'是' if status['enabled'] else '否'}")
    print(f"服务商: {status['service']}")
    print(f"联系人数量: {status['contacts_count']}")
    
    print("\n使用说明：")
    print("1. 默认不开启，需要用户手动配置")
    print("2. 配置后只在极端情况发送（心率=0或<30）")
    print("3. 电话加密存储，不会暴露")
