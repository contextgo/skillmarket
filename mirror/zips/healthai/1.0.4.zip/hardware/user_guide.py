#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
硬件接入用户指南生成器
根据用户已配置的硬件，生成对应的使用说明和功能提醒
"""

from typing import List, Dict


def get_user_guide(status: dict) -> str:
    """
    根据硬件状态生成用户指南
    """
    has_hardware = status.get("has_hardware", False)
    devices = status.get("all_devices", [])
    
    if has_hardware:
        return get_connected_guide(status)
    else:
        return get_unconnected_guide(devices)


def get_unconnected_guide(devices: List[Dict]) -> str:
    """未配置硬件时的用户指南"""
    
    guide = """
🏃 **HealthCoach 硬件接入指南**

---

### ❓ 我没有运动手表怎么办？

**没问题！** 你可以：
- ✅ 每天手动打卡（运动类型、时长、体感）
- ✅ 系统会根据你输入的数据生成个性化方案

---

### 🔌 如果你想接入硬件

支持的设备：

| 设备 | 状态 | 如何接入 |
|------|------|----------|
"""
    
    for d in devices:
        status_emoji = "✅" if d.get("ready") else "⏳"
        guide += f"| {d['name']} | {status_emoji} {d['status']} | {d.get('how_to', '')} |\n"
    
    guide += """

---

### 💡 接入硬件能做什么？

1. **自动同步运动数据** - 步数、心率、跑步记录
2. **更精准的分析** - 基于真实数据分析身体状态
3. **智能提醒** - 运动时长到了自动提醒
4. **自动方案调整** - 根据真实数据动态调整计划

---

### 🚀 快速接入 COROS 高驰

1. 确认你有一块 COROS 高驰手表
2. 在 COROS App 中确认账号可登录
3. 配置账号信息（见下方）

**配置方法：**
```bash
cd HealthSkill-2.0/hardware
cp .env.example .env
# 编辑 .env 填入你的 COROS 账号和密码(MD5)
```

配置好后，系统每天会自动同步你的运动数据！

"""
    
    return guide


def get_connected_guide(status: dict) -> str:
    """已配置硬件时的用户指南"""
    
    connected = status.get("configured_devices", [])
    
    guide = f"""
🏃 **HealthCoach 已连接硬件**

---

### ✅ 已连接的设备

"""
    
    for d in connected:
        guide += f"- **{d['name']}** - {d.get('how_to', '已配置')}\n"
    
    guide += """

---

### 📊 这些设备能做什么？

| 功能 | 说明 |
|------|------|
| **自动同步** | 每天自动获取运动数据，无需手动 |
| **步数追踪** | 记录每日步数、活动量 |
| **心率监测** | 静息心率、运动心率 |
| **运动记录** | 跑步、骑行等运动详情 |
| **睡眠分析** | 睡眠时长和质量 |

---

### 🔄 数据同步

系统会自动同步数据，你只需要：
- ✅ 正常佩戴手表
- ✅ 同步手表数据到 App

每天早上查看数据汇总即可！

---

### ⚙️ 管理硬件

如需修改配置或添加新设备，请联系管理员
"""
    
    return guide


def generate_hardware_prompt() -> str:
    """
    生成硬件相关的提示信息（用于消息回复中）
    """
    return """
💡 **提示**：我可以接入运动手表自动同步数据！

支持的设备：
- ✅ COROS 高驰（运动手表）
- ✅ Apple Watch（通过 iPhone 健康App）
- 🔄 小米/华为（规划中）

有这些设备吗？可以帮你配置自动同步！
"""


def generate_sync_reminder() -> str:
    """生成同步提醒"""
    return """
🔔 **今日运动数据同步提醒**

你的硬件设备今天已自动同步：
- 步数、心率、运动记录

打开 HealthCoach 查看今日分析！
"""


# 测试
if __name__ == "__main__":
    from hardware.collector import get_hardware_status
    
    status = get_hardware_status()
    print(get_user_guide(status))
