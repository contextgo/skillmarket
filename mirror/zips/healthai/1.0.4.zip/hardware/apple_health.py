#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Apple Health 数据采集器
支持解析 Apple Health 导出的 XML 数据
"""

import xml.etree.ElementTree as ET
import json
from datetime import datetime, timedelta
from pathlib import Path
from collections import defaultdict


class AppleHealthParser:
    """Apple Health XML 数据解析器"""
    
    # 数据类型映射
    TYPE_MAPPING = {
        "StepCount": "steps",
        "DistanceWalkingRunning": "distance",
        "HeartRate": "heart_rate",
        "RestingHeartRate": "resting_heart_rate",
        "WalkingHeartRateAverage": "walking_heart_rate",
        "ActiveEnergyBurned": "calories",
        "BasalEnergyBurned": "basal_calories",
        "FlightsClimbed": "flights",
        "AppleExerciseTime": "exercise_time",
        "StandTime": "stand_time",
        "SleepAnalysis": "sleep",
        "Workout": "workout",
    }
    
    def __init__(self):
        self.data = defaultdict(list)
        self.summary = {}
    
    def parse_xml_file(self, xml_path):
        """解析 Apple Health 导出的 XML 文件"""
        tree = ET.parse(xml_path)
        root = tree.getroot()
        
        # 解析记录
        for record in root.findall(".//Record"):
            self.parse_record(record)
        
        # 解析运动记录
        for workout in root.findall(".//Workout"):
            self.parse_workout(workout)
        
        # 生成汇总
        self.generate_summary()
        
        return self.data
    
    def parse_record(self, record):
        """解析单条记录"""
        record_type = record.get("type", "")
        value = record.get("value", "")
        unit = record.get("unit", "")
        start_date = record.get("startDate", "")
        end_date = record.get("endDate", "")
        
        # 转换类型名
        if record_type in self.TYPE_MAPPING:
            field = self.TYPE_MAPPING[record_type]
        else:
            return  # 忽略未映射的类型
        
        try:
            # 数值类型
            if value:
                try:
                    value = float(value)
                except ValueError:
                    value = str(value)
            
            # 日期
            if start_date:
                start_date = self.parse_apple_date(start_date)
            
            self.data[field].append({
                "value": value,
                "unit": unit,
                "date": start_date,
                "type": record_type
            })
        
        except Exception as e:
            pass  # 忽略解析错误
    
    def parse_workout(self, workout):
        """解析运动记录"""
        workout_type = workout.get("workoutActivityType", "")
        duration = workout.get("duration", "")
        distance = workout.get("totalDistance", "")
        energy = workout.get("totalEnergyBurned", "")
        start = workout.get("startDate", "")
        end = workout.get("endDate", "")
        
        # 运动类型映射
        type_map = {
            "HKWorkoutActivityTypeRunning": "跑步",
            "HKWorkoutActivityTypeWalking": "步行",
            "HKWorkoutActivityTypeCycling": "骑行",
            "HKWorkoutActivityTypeSwimming": "游泳",
            "HKWorkoutActivityTypeYoga": "瑜伽",
            "HKWorkoutActivityTypeStrengthTraining": "力量训练",
            "HKWorkoutActivityTypeHIIT": "HIIT",
        }
        
        workout_name = type_map.get(workout_type, workout_type)
        
        self.data["workouts"].append({
            "type": workout_name,
            "duration": float(duration) if duration else 0,
            "distance": float(distance) if distance else 0,
            "calories": float(energy) if energy else 0,
            "start": self.parse_apple_date(start) if start else None,
            "end": self.parse_apple_date(end) if end else None,
        })
    
    def parse_apple_date(self, date_str):
        """解析 Apple 日期格式"""
        try:
            # 格式: 2026-04-18 09:30:00 +0800
            return datetime.strptime(date_str.split(" ")[0], "%Y-%m-%d")
        except:
            return None
    
    def generate_summary(self):
        """生成数据汇总"""
        today = datetime.now().date()
        
        # 今日步数
        today_steps = self.get_today_value("steps")
        
        # 今日心率
        today_hr = self.get_today_value("heart_rate")
        
        # 本周运动
        week_workouts = self.get_week_data("workouts")
        
        # 睡眠
        today_sleep = self.get_today_value("sleep")
        
        self.summary = {
            "date": today.strftime("%Y-%m-%d"),
            "steps": today_steps,
            "heart_rate": today_hr,
            "workouts_this_week": len(week_workouts),
            "sleep_hours": today_sleep / 3600 if today_sleep else 0,  # 转换为小时
        }
    
    def get_today_value(self, field):
        """获取今日指定字段的值"""
        today = datetime.now().date()
        values = self.data.get(field, [])
        
        for item in values:
            if item.get("date"):
                if item["date"].date() == today:
                    return item.get("value", 0)
        
        return 0
    
    def get_week_data(self, field):
        """获取本周数据"""
        today = datetime.now().date()
        week_ago = today - timedelta(days=7)
        
        items = self.data.get(field, [])
        week_items = [
            item for item in items 
            if item.get("date") and item["date"].date() >= week_ago
        ]
        
        return week_items
    
    def get_daily_summary(self, days=7):
        """获取多日汇总"""
        result = []
        
        for i in range(days):
            date = datetime.now().date() - timedelta(days=i)
            date_str = date.strftime("%Y-%m-%d")
            
            day_data = {
                "date": date_str,
                "steps": 0,
                "heart_rate": None,
                "workouts": 0,
                "calories": 0,
            }
            
            # 步数
            steps = self.data.get("steps", [])
            for s in steps:
                if s.get("date") and s["date"].date() == date:
                    day_data["steps"] += int(s.get("value", 0))
            
            # 心率（取平均值）
            hr_values = []
            hrs = self.data.get("heart_rate", [])
            for h in hrs:
                if h.get("date") and h["date"].date() == date:
                    if isinstance(h.get("value"), (int, float)):
                        hr_values.append(h["value"])
            if hr_values:
                day_data["heart_rate"] = sum(hr_values) / len(hr_values)
            
            # 运动次数
            workouts = self.data.get("workouts", [])
            day_data["workouts"] = sum(1 for w in workouts 
                                       if w.get("start") and w["start"].date() == date)
            
            # 卡路里
            calories = self.data.get("calories", [])
            for c in calories:
                if c.get("date") and c["date"].date() == date:
                    day_data["calories"] += c.get("value", 0)
            
            result.append(day_data)
        
        return result


def import_apple_health(xml_path, output_dir=None):
    """
    导入 Apple Health 数据的便捷函数
    """
    parser = AppleHealthParser()
    
    # 解析数据
    data = parser.parse_xml_file(xml_path)
    
    # 生成汇总
    summary = parser.summary
    
    # 生成每日详情
    daily = parser.get_daily_summary(30)
    
    result = {
        "source": "apple_health",
        "imported_at": datetime.now().isoformat(),
        "summary": summary,
        "daily_data": daily,
        "workouts": data.get("workouts", []),
    }
    
    # 如果指定了输出目录，保存 JSON
    if output_dir:
        output_path = Path(output_dir) / "apple_health_import.json"
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        result["saved_to"] = str(output_path)
    
    return result


# 测试
if __name__ == "__main__":
    print("=== Apple Health 数据解析器 ===")
    print("使用方法：")
    print("1. 在 iPhone 上导出健康数据 (健康App → 头像 → 导出健康数据)")
    print("2. 将导出的 XML 文件路径传入 import_apple_health() 函数")
    print()
    print("示例：")
    print('  result = import_apple_health("~/Downloads/export.xml")')
    print("  print(result['summary'])")
