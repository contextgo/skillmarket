#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
健康数据处理器
整合西医、中医、运动科学、营养学的多维度分析
"""

import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from collections import defaultdict


class HealthDataProcessor:
    """健康数据处理器 - 多维度分析"""
    
    def __init__(self):
        # 初始化各维度分析器
        self.western_agent = WesternMedicineAgent()
        self.tcm_agent = TraditionalChineseMedicineAgent()
        self.sports_agent = SportsScienceAgent()
        self.nutrition_agent = NutritionAgent()
        
        # 结算时间设置
        self.settlement_hour = 21  # 默认21:00结算
    
    def set_settlement_time(self, hour: int):
        """设置结算时间"""
        self.settlement_hour = hour
    
    def process_realtime_data(self, raw_data: dict) -> dict:
        """
        处理实时数据流
        检测异常并决定是否立即预警
        """
        alerts = []
        
        # 心率异常检测
        if "heart_rate" in raw_data:
            hr_data = raw_data["heart_rate"]
            hr_alert = self._check_heart_rate_abnormal(hr_data)
            if hr_alert:
                alerts.append(hr_alert)
        
        # 步数异常检测（连续多天未动）
        if "steps" in raw_data:
            steps_data = raw_data["steps"]
            steps_alert = self._check_steps_abnormal(steps_data)
            if steps_alert:
                alerts.append(steps_alert)
        
        # 睡眠异常检测
        if "sleep" in raw_data:
            sleep_data = raw_data["sleep"]
            sleep_alert = self._check_sleep_abnormal(sleep_data)
            if sleep_alert:
                alerts.append(sleep_alert)
        
        return {
            "has_alerts": len(alerts) > 0,
            "alerts": alerts,
            "processed_at": datetime.now().isoformat()
        }
    
    def process_daily_settlement(self, daily_data: dict, historical_baseline: dict) -> dict:
        """
        每日结算处理
        在结算时间（默认21:00）调用
        """
        # 1. 汇总当日数据
        summary = self._summarize_daily_data(daily_data)
        
        # 2. 对比baseline
        comparison = self._compare_with_baseline(summary, historical_baseline)
        
        # 3. 多维度分析
        western_analysis = self.western_agent.analyze(summary, comparison)
        tcm_analysis = self.tcm_agent.analyze(summary, comparison)
        sports_analysis = self.sports_agent.analyze(summary, comparison)
        nutrition_analysis = self.nutrition_agent.analyze(summary, comparison)
        
        # 4. 综合评估
        overall_assessment = self._generate_assessment(
            western_analysis, tcm_analysis, sports_analysis, nutrition_analysis
        )
        
        # 5. 生成建议
        recommendations = self._generate_recommendations(
            western_analysis, tcm_analysis, sports_analysis, nutrition_analysis
        )
        
        return {
            "settlement_time": datetime.now().isoformat(),
            "daily_summary": summary,
            "comparison": comparison,
            "analysis": {
                "western": western_analysis,
                "tcm": tcm_analysis,
                "sports": sports_analysis,
                "nutrition": nutrition_analysis,
            },
            "overall_assessment": overall_assessment,
            "recommendations": recommendations,
        }
    
    def _check_heart_rate_abnormal(self, hr_data: dict) -> Optional[dict]:
        """检测心率异常"""
        current = hr_data.get("current", 0)
        
        # 紧急：心率突然过高
        if current > 140:
            return {
                "level": "critical",
                "type": "heart_rate_high",
                "message": "⚠️ 心率过高！当前心率 {} 次/分，可能运动过激，请立即停止运动并休息！".format(current),
                "suggestion": "原地休息，深呼吸，喝温水",
                "require_immediate_action": True
            }
        
        # 警告：心率偏高
        if current > 120:
            return {
                "level": "warning",
                "type": "heart_rate_elevated",
                "message": "心率偏快（{} 次/分），注意运动强度".format(current),
                "suggestion": "适当降低运动强度",
                "require_immediate_action": False
            }
        
        return None
    
    def _check_steps_abnormal(self, steps_data: dict) -> Optional[dict]:
        """检测步数异常（连续多天不动）"""
        recent_days = steps_data.get("recent_days", [])
        
        if len(recent_days) >= 3:
            low_days = [d for d in recent_days if d.get("steps", 0) < 1000]
            
            if len(low_days) >= 3:
                return {
                    "level": "warning",
                    "type": "inactive",
                    "message": "连续{}天步数不足1000步，该运动了！".format(len(low_days)),
                    "suggestion": "每天至少步行30分钟",
                    "require_immediate_action": False
                }
        
        return None
    
    def _check_sleep_abnormal(self, sleep_data: dict) -> Optional[dict]:
        """检测睡眠异常"""
        hours = sleep_data.get("hours", 0)
        
        if hours < 5:
            return {
                "level": "warning",
                "type": "sleep_deprived",
                "message": "睡眠不足{}小时，注意休息！".format(hours),
                "suggestion": "尽量在23点前入睡",
                "require_immediate_action": False
            }
        
        return None
    
    def _summarize_daily_data(self, daily_data: dict) -> dict:
        """汇总当日数据"""
        return {
            "total_steps": daily_data.get("steps", 0),
            "avg_heart_rate": daily_data.get("heart_rate_avg", 0),
            "max_heart_rate": daily_data.get("heart_rate_max", 0),
            "workout_minutes": daily_data.get("workout_duration", 0),
            "calories_burned": daily_data.get("calories", 0),
            "sleep_hours": daily_data.get("sleep_hours", 0),
            "workout_count": daily_data.get("workout_count", 0),
        }
    
    def _compare_with_baseline(self, summary: dict, baseline: dict) -> dict:
        """与基准对比"""
        comparisons = {}
        
        for key in ["total_steps", "avg_heart_rate", "workout_minutes", "sleep_hours"]:
            current = summary.get(key, 0)
            base = baseline.get(key, current)
            
            if base == 0:
                change_pct = 0
            else:
                change_pct = ((current - base) / base) * 100
            
            comparisons[key] = {
                "current": current,
                "baseline": base,
                "change_pct": round(change_pct, 1),
                "trend": "up" if change_pct > 5 else ("down" if change_pct < -5 else "stable")
            }
        
        return comparisons
    
    def _generate_assessment(self, western, tcm, sports, nutrition) -> dict:
        """综合评估"""
        scores = []
        
        # 汇总各维度评分
        if western.get("score"):
            scores.append(western["score"])
        if tcm.get("score"):
            scores.append(tcm["score"])
        if sports.get("score"):
            scores.append(sports["score"])
        if nutrition.get("score"):
            scores.append(nutrition["score"])
        
        avg_score = sum(scores) / len(scores) if scores else 0
        
        # 总体状态
        if avg_score >= 80:
            status = "excellent"
            status_text = "优秀"
        elif avg_score >= 60:
            status = "good"
            status_text = "良好"
        elif avg_score >= 40:
            status = "fair"
            status_text = "一般"
        else:
            status = "poor"
            status_text = "需关注"
        
        return {
            "overall_score": round(avg_score, 1),
            "status": status,
            "status_text": status_text,
        }
    
    def _generate_recommendations(self, western, tcm, sports, nutrition) -> List[dict]:
        """生成建议"""
        recommendations = []
        
        # 优先级排序
        if western.get("recommendations"):
            recommendations.extend(western["recommendations"])
        if tcm.get("recommendations"):
            recommendations.extend(tcm["recommendations"])
        if sports.get("recommendations"):
            recommendations.extend(sports["recommendations"])
        if nutrition.get("recommendations"):
            recommendations.extend(nutrition["recommendations"])
        
        # 按优先级排序
        priority_map = {"critical": 0, "warning": 1, "info": 2}
        recommendations.sort(key=lambda x: priority_map.get(x.get("priority", "info"), 2))
        
        return recommendations[:5]  # 最多5条


# ==================== 西医 Agent ====================
class WesternMedicineAgent:
    """西医健康分析"""
    
    def analyze(self, summary: dict, comparison: dict) -> dict:
        """西医角度分析"""
        issues = []
        recommendations = []
        score = 100
        
        # 心率分析
        hr = comparison.get("avg_heart_rate", {})
        if hr.get("current", 0) > 100:
            issues.append("静息心率偏快")
            score -= 10
            recommendations.append({
                "priority": "warning",
                "type": "cardiovascular",
                "title": "心血管健康",
                "content": "建议进行有氧运动降低静息心率"
            })
        
        # 睡眠分析
        sleep = summary.get("sleep_hours", 0)
        if sleep < 7:
            issues.append("睡眠不足")
            score -= 15
            recommendations.append({
                "priority": "warning",
                "type": "sleep",
                "title": "睡眠建议",
                "content": "成年人建议每天7-8小时睡眠"
            })
        
        # 运动量分析
        steps = summary.get("total_steps", 0)
        if steps < 5000:
            issues.append("活动量不足")
            score -= 15
            recommendations.append({
                "priority": "warning",
                "type": "activity",
                "title": "运动建议",
                "content": "建议每天步行8000-10000步"
            })
        
        return {
            "score": score,
            "issues": issues,
            "recommendations": recommendations
        }


# ==================== 中医 Agent ====================
class TraditionalChineseMedicineAgent:
    """中医健康分析 - 融入经络时辰理论"""
    
    # 时辰经络对应
    MERIDIAN_HOURS = {
        (7, 9): "胃经 - 脾胃",
        (9, 11): "脾经 - 运化",
        (11, 13): "心经 - 午休",
        (13, 15): "小肠经",
        (15, 17): "膀胱经 - 下午运动黄金期",
        (17, 19): "肾经 - 运动增强",
        (19, 21): "心包经 - 静养",
        (21, 23): "三焦经 - 准备入睡",
    }
    
    def analyze(self, summary: dict, comparison: dict) -> dict:
        """中医角度分析"""
        issues = []
        recommendations = []
        score = 100
        
        now = datetime.now()
        current_hour = now.hour
        
        # 获取当前时辰经络
        meridian = self._get_current_meridian(current_hour)
        
        # 步数分析 - 对应阳气
        steps = summary.get("total_steps", 0)
        if steps < 5000:
            issues.append("阳气不足")
            score -= 10
            recommendations.append({
                "priority": "info",
                "type": "yang_energy",
                "title": "阳气调理",
                "content": f"当前{meridian[0]}，适度运动升发阳气"
            })
        
        # 睡眠分析 - 对应阴气
        sleep = summary.get("sleep_hours", 0)
        if sleep < 7:
            issues.append("阴气不足")
            score -= 10
            recommendations.append({
                "priority": "warning",
                "type": "yin_energy",
                "title": "滋阴养血",
                "content": "23点前入睡，最晚不超过24点"
            })
        
        # 心率分析 - 对应心神
        hr = summary.get("avg_heart_rate", 0)
        if hr > 90:
            issues.append("心火旺")
            score -= 10
            recommendations.append({
                "priority": "info",
                "type": "heart_fire",
                "title": "心火调理",
                "content": "可练习静坐、深呼吸清心火"
            })
        
        return {
            "score": score,
            "current_meridian": meridian,
            "issues": issues,
            "recommendations": recommendations
        }
    
    def _get_current_meridian(self, hour: int) -> tuple:
        """获取当前时辰经络"""
        for time_range, meridian in self.MERIDIAN_HOURS.items():
            if time_range[0] <= hour < time_range[1]:
                return (meridian, f"{time_range[0]}:00-{time_range[1]}:00")
        return ("其他", "")


# ==================== 运动科学 Agent ====================
class SportsScienceAgent:
    """运动科学分析"""
    
    def analyze(self, summary: dict, comparison: dict) -> dict:
        """运动科学角度分析"""
        issues = []
        recommendations = []
        score = 100
        
        # 运动时长
        workout_min = summary.get("workout_minutes", 0)
        
        if workout_min < 30:
            issues.append("运动时长不足")
            score -= 15
            recommendations.append({
                "priority": "warning",
                "type": "duration",
                "title": "运动时长",
                "content": "建议每天运动30-60分钟"
            })
        
        # 步数趋势
        steps_trend = comparison.get("total_steps", {}).get("trend", "stable")
        if steps_trend == "down":
            issues.append("活动量下降")
            score -= 10
            recommendations.append({
                "priority": "info",
                "type": "progression",
                "title": "运动进阶",
                "content": "建议逐渐增加运动量，避免突然大幅减少"
            })
        
        # 卡路里
        calories = summary.get("calories_burned", 0)
        if calories < 200:
            issues.append("消耗不足")
            score -= 10
            recommendations.append({
                "priority": "info",
                "type": "calories",
                "title": "热量消耗",
                "content": "建议增加运动强度或时长"
            })
        
        return {
            "score": score,
            "issues": issues,
            "recommendations": recommendations
        }


# ==================== 营养 Agent ====================
class NutritionAgent:
    """营养学分析"""
    
    def analyze(self, summary: dict, comparison: dict) -> dict:
        """营养学角度分析"""
        issues = []
        recommendations = []
        score = 100
        
        # 根据运动量给出营养建议
        workout_min = summary.get("workout_minutes", 0)
        calories = summary.get("calories_burned", 0)
        
        if workout_min > 60:
            # 大运动量
            recommendations.append({
                "priority": "info",
                "type": "nutrition",
                "title": "运动营养",
                "content": "高强度运动后补充蛋白质和电解质"
            })
        
        if calories > 500:
            # 可适当补充
            score += 5
        
        # 睡眠不足时的营养建议
        sleep = summary.get("sleep_hours", 0)
        if sleep < 7:
            recommendations.append({
                "priority": "info",
                "type": "sleep_nutrition",
                "title": "助眠营养",
                "content": "睡前避免咖啡因，可喝温牛奶或小米粥"
            })
        
        return {
            "score": score,
            "issues": issues,
            "recommendations": recommendations
        }


# 便捷函数
def process_health_data(raw_data: dict, historical: dict = None) -> dict:
    """处理健康数据"""
    processor = HealthDataProcessor()
    
    # 先检查实时异常
    realtime_result = processor.process_realtime_data(raw_data)
    
    # 如果有异常，立即返回预警
    if realtime_result.get("has_alerts"):
        return {
            "type": "realtime_alert",
            **realtime_result
        }
    
    # 日常结算
    if historical is None:
        historical = {}
    
    return processor.process_daily_settlement(raw_data, historical)


# 测试
if __name__ == "__main__":
    print("=== 健康数据处理器测试 ===\n")
    
    # 测试实时数据
    test_data = {
        "heart_rate": {"current": 145},
    }
    
    result = process_health_data(test_data)
    print(json.dumps(result, ensure_ascii=False, indent=2))
