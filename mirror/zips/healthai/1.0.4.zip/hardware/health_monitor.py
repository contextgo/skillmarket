#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
健康监控与预警系统
四象限分析 + 主动发现问题 + 紧急通知
"""

import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional


class HealthMonitor:
    """健康监控器"""
    
    # 紧急阈值
    CRITICAL_THRESHOLDS = {
        "heart_rate_zero": 0,           # 心率0
        "heart_rate_min": 30,           # 心率过低
        "heart_rate_max": 160,          # 心率过高
        "spo2_min": 90,                 # 血氧过低
        "temp_high": 39.0,              # 发烧
    }
    
    def __init__(self):
        self.user_profile = {}  # 用户档案
        self.emergency_contacts = []  # 紧急联系人
    
    def set_user_profile(self, profile: dict):
        """设置用户档案"""
        # 已知问题
        self.user_profile["known_issues"] = profile.get("known_issues", [])
        # 已知该怎么做
        self.user_profile["known_solutions"] = profile.get("known_solutions", [])
        # 紧急联系人
        self.user_profile["emergency_contacts"] = profile.get("emergency_contacts", [])
        # 历史数据
        self.user_profile["history"] = profile.get("history", {})
    
    def analyze_health_status(self, current_data: dict, baseline: dict) -> dict:
        """
        四象限健康分析
        返回用户属于哪个象限，以及对应的建议
        """
        # 1. 检测是否有已知问题
        has_known_issues = len(self.user_profile.get("known_issues", [])) > 0
        
        # 2. 检测是否知道怎么做
        has_known_solutions = len(self.user_profile.get("known_solutions", [])) > 0
        
        # 3. 通过数据分析潜在问题
        hidden_issues = self._detect_hidden_issues(current_data, baseline)
        
        # 4. 四象限判断
        if has_known_issues and has_known_solutions:
            quadrant = "A"
            quadrant_name = "优化指导"
            action = self._generate_optimization_guidance(current_data)
        elif has_known_issues and not has_known_solutions:
            quadrant = "B"
            quadrant_name = "提供方案"
            action = self._generate_solution_guidance(current_data, hidden_issues)
        elif not has_known_issues and has_known_solutions:
            quadrant = "C"
            quadrant_name = "发现问题"
            action = self._generate_discovery_guidance(hidden_issues)
        else:
            quadrant = "D"
            quadrant_name = "全面指导"
            action = self._generate_comprehensive_guidance(current_data, hidden_issues)
        
        return {
            "quadrant": quadrant,
            "quadrant_name": quadrant_name,
            "has_known_issues": has_known_issues,
            "has_known_solutions": has_known_solutions,
            "detected_issues": hidden_issues,
            "recommended_action": action,
        }
    
    def _detect_hidden_issues(self, current: dict, baseline: dict) -> List[dict]:
        """通过数据发现隐藏问题"""
        issues = []
        
        # 心率相关
        hr = current.get("heart_rate", 0)
        baseline_hr = baseline.get("heart_rate", hr)
        
        if hr > 0 and hr < 40:
            issues.append({
                "type": "heart_rate_too_low",
                "severity": "critical",
                "title": "心率过低",
                "description": f"当前心率 {hr} bpm，可能存在心脏传导问题",
                "suggestion": "建议立即就医检查",
            })
        elif hr > 100 and (baseline_hr > 0 and hr > baseline_hr * 1.3):
            issues.append({
                "type": "heart_rate_elevated",
                "severity": "warning",
                "title": "心率异常升高",
                "description": f"心率比平时高出30%以上，可能压力过大或睡眠不足",
                "suggestion": "建议适当休息，减少剧烈运动",
            })
        
        # 步数相关
        steps = current.get("steps", 0)
        baseline_steps = baseline.get("steps", steps)
        
        if baseline_steps > 5000 and steps < 1000:
            issues.append({
                "type": "activity_sudden_drop",
                "severity": "warning",
                "title": "活动量骤降",
                "description": "步数突然大幅减少，可能存在健康问题或情绪低落",
                "suggestion": "关注身心健康，必要时寻求帮助",
            })
        
        # 睡眠相关
        sleep = current.get("sleep_hours", 0)
        if sleep < 4:
            issues.append({
                "type": "severe_sleep_deprivation",
                "severity": "warning",
                "title": "严重睡眠不足",
                "description": "连续睡眠不足4小时，对身体健康影响很大",
                "suggestion": "优先保证睡眠，23点前入睡",
            })
        
        # HRV（心率变异性）
        hrv = current.get("hrv", 0)
        if hrv > 0 and hrv < 20:
            issues.append({
                "type": "hrv_low",
                "severity": "warning",
                "title": "心率变异性偏低",
                "description": "HRV偏低可能提示心脏自主神经功能失调",
                "suggestion": "建议进行心脏检查，避免过度劳累",
            })
        
        # 运动强度
        workout_hr = current.get("workout_heart_rate_avg", 0)
        if workout_hr > 0 and workout_hr > 170:
            issues.append({
                "type": "intensity_too_high",
                "severity": "warning",
                "title": "运动强度过高",
                "description": "运动时心率持续过高，心血管负担大",
                "suggestion": "降低运动强度，选择温和运动",
            })
        
        return issues
    
    def _generate_optimization_guidance(self, data: dict) -> dict:
        """A象限：已知问题+已知做法 → 优化指导"""
        return {
            "type": "optimization",
            "title": "你做得很好！",
            "content": "你知道自己有什么问题，也知道怎么改善。",
            "suggestions": [
                "根据近期数据，可以适当调整方案",
                "保持当前良好的生活习惯",
                "建议每周复盘数据，持续优化",
            ],
        }
    
    def _generate_solution_guidance(self, data: dict, issues: List[dict]) -> dict:
        """B象限：有问题+不知道怎么做 → 提供方案"""
        suggestions = []
        
        for issue in issues:
            suggestions.append({
                "issue": issue.get("title"),
                "solution": issue.get("suggestion"),
            })
        
        return {
            "type": "solution",
            "title": "发现问题了！",
            "content": "你有一些健康问题，让我帮你制定解决方案。",
            "suggestions": suggestions,
        }
    
    def _generate_discovery_guidance(self, issues: List[dict]) -> dict:
        """C象限：没问题+知道做法 → 发现问题"""
        if not issues:
            return {
                "type": "discovery",
                "title": "状态良好",
                "content": "目前数据正常，你已经有很好的健康习惯！",
                "suggestions": ["继续保持！"],
            }
        
        return {
            "type": "discovery",
            "title": "发现潜在问题",
            "content": "虽然你没有明显不适，但数据发现了一些需要注意的情况：",
            "suggestions": [
                f"• {i.get('title')}: {i.get('description')}"
                for i in issues
            ],
        }
    
    def _generate_comprehensive_guidance(self, data: dict, issues: List[dict]) -> dict:
        """D象限：不知道问题+不知道怎么做 → 全面指导"""
        # 基础健康建议
        base_suggestions = [
            "每天保持7-8小时睡眠",
            "每周至少150分钟中等强度运动",
            "保持均衡饮食，多喝水",
            "定期体检，关注身体变化",
        ]
        
        # 针对发现的问题
        issue_suggestions = [
            f"• {i.get('title')}: {i.get('suggestion')}"
            for i in issues
        ] if issues else []
        
        return {
            "type": "comprehensive",
            "title": "健康全面指导",
            "content": "让我帮你建立完整的健康方案！",
            "suggestions": base_suggestions + issue_suggestions,
        }
    
    def check_emergency(self, data: dict) -> Optional[dict]:
        """检查是否需要紧急预警"""
        alerts = []
        
        # 心率为0或极低
        hr = data.get("heart_rate", 0)
        if hr == 0 or (hr > 0 and hr < self.CRITICAL_THRESHOLDS["heart_rate_min"]):
            alerts.append({
                "level": "critical",
                "type": "heart_rate_dangerous",
                "title": "⚠️ 紧急：心率异常",
                "content": f"当前心率: {hr} bpm",
                "action": "立即停止运动，休息，必要时拨打120",
                "notify_family": True,
            })
        
        # 心率过高
        if hr > self.CRITICAL_THRESHOLDS["heart_rate_max"]:
            alerts.append({
                "level": "critical",
                "type": "heart_rate_too_high",
                "title": "⚠️ 紧急：心率过高",
                "content": f"当前心率: {hr} bpm",
                "action": "立即停止运动，深呼吸，休息",
                "notify_family": False,  # 暂时先通知用户
            })
        
        # 血氧过低
        spo2 = data.get("spo2", 0)
        if 0 < spo2 < self.CRITICAL_THRESHOLDS["spo2_min"]:
            alerts.append({
                "level": "critical",
                "type": "spo2_low",
                "title": "⚠️ 紧急：血氧过低",
                "content": f"当前血氧: {spo2}%",
                "action": "立即休息，必要时吸氧，联系医生",
                "notify_family": True,
            })
        
        # 运动中突然停止（无数据更新但之前在运动）
        last_workout = data.get("last_workout")
        if last_workout and data.get("steps") == 0:
            # 可能需要进一步判断
            pass
        
        if alerts:
            return {
                "has_emergency": True,
                "alerts": alerts,
                "notify_contacts": [a.get("notify_family", False) for a in alerts],
            }
        
        return None
    
    def generate_report(self, data: dict, baseline: dict) -> dict:
        """生成完整健康报告"""
        # 1. 紧急检查
        emergency = self.check_emergency(data)
        
        # 2. 四象限分析
        status = self.analyze_health_status(data, baseline)
        
        # 3. 综合报告
        return {
            "report_time": datetime.now().isoformat(),
            "emergency": emergency,
            "health_status": status,
            "data_summary": {
                "steps": data.get("steps"),
                "heart_rate": data.get("heart_rate"),
                "sleep_hours": data.get("sleep_hours"),
                "workout_minutes": data.get("workout_minutes", 0),
            },
        }


def analyze_user_situation(user_data: dict, current_health_data: dict) -> dict:
    """便捷函数：分析用户情况"""
    monitor = HealthMonitor()
    monitor.set_user_profile(user_data)
    return monitor.generate_report(current_health_data, user_data.get("baseline", {}))


# 测试
if __name__ == "__main__":
    print("=== 健康监控与预警系统 ===\n")
    
    # 模拟用户：知道自己有高血压，知道要少盐
    user_data = {
        "known_issues": ["高血压"],
        "known_solutions": ["少盐", "运动"],
        "baseline": {
            "heart_rate": 75,
            "steps": 8000,
        }
    }
    
    # 模拟当前数据
    current = {
        "heart_rate": 72,
        "steps": 6500,
        "sleep_hours": 6.5,
    }
    
    result = analyze_user_situation(user_data, current)
    print(json.dumps(result, ensure_ascii=False, indent=2))
