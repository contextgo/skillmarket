#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
硬件数据自动同步脚本
配合 cron 定时任务使用
每天自动抓取所有已配置硬件的数据
"""

import sys
import json
from pathlib import Path
from datetime import datetime

# 添加项目根目录到路径
sys.path.insert(0, str(Path(__file__).parent.parent))

from hardware.collector import HardwareDataCollector


def main():
    """主同步函数"""
    print(f"\n{'='*50}")
    print(f"🏃 HealthCoach 硬件数据同步")
    print(f"⏰ 时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'='*50}\n")
    
    collector = HardwareDataCollector()
    
    # 1. 检查硬件状态
    status = collector.get_status()
    print(f"📱 硬件状态:")
    print(f"   已配置设备: {len(status['configured_devices'])}")
    print(f"   推荐: {status['recommendation']}\n")
    
    # 2. 尝试获取数据
    print("🔄 正在同步数据...\n")
    
    try:
        data = collector.fetch_data()
        
        if data:
            print(f"✅ 成功获取 {len(data)} 个设备的数据")
            
            for item in data:
                device = item.get("device", "未知设备")
                print(f"   - {device}: ✓")
                
                # 显示关键数据
                if device == "COROS 高驰":
                    if item.get("data", {}).get("activities"):
                        acts = item["data"]["activities"]
                        print(f"     运动记录: {len(acts)} 条")
                
        else:
            print("⚠️ 未能获取到任何硬件数据")
            print("\n📋 配置提示:")
            for tip in status.get("tips", [])[:3]:
                print(f"   {tip}")
    
    except Exception as e:
        print(f"❌ 同步出错: {e}")
        return 1
    
    # 3. 更新用户状态
    print("\n🔄 正在更新用户状态...")
    try:
        from tools.local_storage import load_user, save_user
        from agents.health_assessment_engine import HealthAssessmentEngine
        
        # 如果有硬件数据，更新用户状态
        if data:
            # 这里可以添加数据处理逻辑
            # 比如：更新步数、心率、运动记录到用户状态
            pass
        
        print("✅ 状态更新完成")
        
    except Exception as e:
        print(f"⚠️ 状态更新跳过: {e}")
    
    print(f"\n{'='*50}")
    print("🏁 同步完成!")
    print(f"{'='*50}\n")
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
