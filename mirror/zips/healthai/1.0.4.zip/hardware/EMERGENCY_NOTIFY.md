# 紧急通知系统

> ⚠️ **重要说明**：此功能**默认关闭**，只有用户主动配置才会启用！

---

## 什么是紧急通知？

当检测到**极端健康危机**时，自动发短信通知家人：

| 极端情况 | 触发条件 |
|----------|----------|
| 心率为0 | 心跳停止 |
| 心率<30 | 严重心动过缓 |
| 血氧<85% | 严重缺氧 |

---

## 为什么默认关闭？

1. **避免骚扰**：只有真正危及生命的情况才发
2. **用户授权**：需要用户明确同意并配置
3. **隐私保护**：电话加密存储，不暴露

---

## 如何开启？

### 方式一：通过命令配置

```bash
cd HealthSkill-2.0/hardware
python3 notification.py
```

然后按提示配置：
- 选择服务商（阿里云/腾讯云）
- 输入 API 密钥
- 添加紧急联系人

### 方式二：代码配置

```python
from hardware.notification import EmergencyNotifier

notifier = EmergencyNotifier()

# 1. 开启服务（需要阿里云/腾讯云账号）
notifier.enable(
    service="aliyun",
    api_key="你的API Key",
    api_secret="你的API Secret",
    sign_name="你的短信签名",
    template_id="模板ID"
)

# 2. 添加家人联系方式
notifier.add_contact("妻子", "13800138000", "配偶")
notifier.add_contact("父亲", "13900139000", "父子")
```

---

## 需要什么准备？

### 1. 阿里云/腾讯云短信服务

**阿里云**：
1. 登录阿里云 → 搜索"短信服务"
2. 开通服务 → 申请签名（如"YourFamily"）
3. 申请模板（如"紧急通知"）
4. 获取 AccessKey

**腾讯云**：
1. 登录腾讯云 → 搜索"短信"
2. 开通服务 → 申请签名和模板
3. 获取 SecretId/SecretKey

### 2. 费用

- 阿里云：约 ¥0.05/条
- 腾讯云：约 ¥0.05/条
- 首次配置需充值少量余额

---

## 电话隐私保护

```
存储方式：加密存储（SHA256）
显示方式：138****8000（部分隐藏）
传输方式：HTTPS 加密传输
```

**家人电话永远不会完整显示在聊天记录中！**

---

## 短信模板

收到短信类似：
```
【HealthCoach健康预警】
张三 当前心率为0，请立即联系确认安全！
```

---

## 触发逻辑

```
检测到极端数据
     ↓
检查是否开启紧急通知
     ↓
检查冷却时间（1小时内不重复发）
     ↓
发送短信给所有紧急联系人
     ↓
记录发送时间
```

---

## 常见问题

**Q：不配置会怎样？**
A：不会发送任何短信给家人，只提醒用户本人

**Q：误报怎么办？**
A：设置了冷却时间，1小时内不会重复发送

**Q：怎么关闭？**
A：运行 `notifier.disable()` 即可关闭

---

## 代码示例

```python
from hardware.health_monitor import analyze_user_situation
from hardware.notification import send_emergency

# 分析健康数据
result = analyze_user_situation(user_data, current_data)

# 检查是否有紧急情况
if result.get("emergency"):
    # 发送紧急通知
    send_emergency(
        emergency_type="heart_rate_critical",
        user_name="张三",
        value="28 bpm"
    )
```
