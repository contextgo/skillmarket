#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
硬件同步配置管理器
用户配置硬件同步参数（设备、频率、时段）
"""

import json
from pathlib import Path
from datetime import datetime


class HardwareConfigManager:
    """硬件同步配置管理器"""
    
    def __init__(self, config_dir=None):
        if config_dir is None:
            config_dir = Path(__file__).parent
        
        self.config_dir = Path(config_dir)
        self.config_file = self.config_dir / "hardware_config.json"
        self.config = self.load_config()
    
    def load_config(self):
        """加载配置"""
        if self.config_file.exists():
            with open(self.config_file, "r", encoding="utf-8") as f:
                return json.load(f)
        
        # 默认配置
        return self.get_default_config()
    
    def get_default_config(self):
        """获取默认配置"""
        return {
            "version": "2.0",
            "devices": {},  # 用户配置的设备
            "global_settings": {
                "enable_auto_sync": True,
                "default_sync_interval": 3600,  # 默认1小时
                "settlement_time": "21:00",     # 每日结算时间
                "alert_enabled": True,           # 开启异常提醒
                "alert_channels": ["feishu"],    # 提醒渠道
            },
            "updated_at": None
        }
    
    def save_config(self):
        """保存配置"""
        self.config["updated_at"] = datetime.now().isoformat()
        
        with open(self.config_file, "w", encoding="utf-8") as f:
            json.dump(self.config, f, ensure_ascii=False, indent=2)
    
    def add_device(self, device_id: str, device_type: str, settings: dict = None):
        """
        添加/更新设备配置
        
        Args:
            device_id: 设备ID（如 "my_apple_watch"）
            device_type: 设备类型（coros, apple_health, xiaomi, huawei）
            settings: 设备特定设置
        """
        if settings is None:
            settings = {}
        
        # 默认设置
        default_settings = {
            "enabled": True,
            "sync_interval": 3600,     # 同步间隔（秒）
            "sync_start": "00:00",     # 同步开始时间
            "sync_end": "23:59",       # 同步结束时间
            "data_types": ["steps", "heart_rate", "workout"],  # 要同步的数据类型
        }
        default_settings.update(settings)
        
        self.config["devices"][device_id] = {
            "type": device_type,
            "name": settings.get("name", f"我的{device_type}"),
            **default_settings,
            "added_at": datetime.now().isoformat()
        }
        
        self.save_config()
        return self.config["devices"][device_id]
    
    def remove_device(self, device_id: str):
        """移除设备"""
        if device_id in self.config["devices"]:
            del self.config["devices"][device_id]
            self.save_config()
            return True
        return False
    
    def get_device(self, device_id: str):
        """获取设备配置"""
        return self.config["devices"].get(device_id)
    
    def get_all_devices(self):
        """获取所有已配置的设备"""
        return self.config["devices"]
    
    def update_global_settings(self, settings: dict):
        """更新全局设置"""
        self.config["global_settings"].update(settings)
        self.save_config()
    
    def get_global_settings(self):
        """获取全局设置"""
        return self.config["global_settings"]
    
    def is_sync_time(self, device_id: str = None) -> bool:
        """
        判断当前是否在同步时间段内
        
        Args:
            device_id: 设备ID，为None时检查全局设置
        """
        now = datetime.now()
        current_time = now.strftime("%H:%M")
        
        if device_id:
            device = self.get_device(device_id)
            if not device:
                return False
            start = device.get("sync_start", "00:00")
            end = device.get("sync_end", "23:59")
        else:
            # 全局时间设置
            settings = self.get_global_settings()
            # 不限制具体时间
            return True
        
        return start <= current_time <= end
    
    def should_sync_now(self, device_id: str, last_sync_time: str = None) -> bool:
        """
        判断是否应该现在同步
        
        Args:
            device_id: 设备ID
            last_sync_time: 上次同步时间（ISO格式）
        """
        device = self.get_device(device_id)
        if not device or not device.get("enabled"):
            return False
        
        # 检查是否在同步时间段内
        if not self.is_sync_time(device_id):
            return False
        
        # 检查间隔
        if last_sync_time:
            last = datetime.fromisoformat(last_sync_time)
            interval = device.get("sync_interval", 3600)
            if (datetime.now() - last).total_seconds() < interval:
                return False
        
        return True
    
    def generate_cron_config(self) -> dict:
        """
        生成 cron 配置（供定时任务使用）
        """
        global_settings = self.get_global_settings()
        devices = self.get_all_devices()
        
        cron_jobs = []
        
        for device_id, device in devices.items():
            if not device.get("enabled", True):
                continue
            
            interval = device.get("sync_interval", 3600)
            
            # 转换为 cron 格式
            # 简单处理：每N分钟/小时
            if interval >= 3600:
                # 每N小时
                hours = interval // 3600
                cron_expr = f"0 */{hours} * * *"
            else:
                # 每N分钟
                minutes = interval // 60
                cron_expr = f"*/{minutes} * * * *"
            
            cron_jobs.append({
                "device_id": device_id,
                "device_name": device.get("name"),
                "device_type": device.get("type"),
                "interval_seconds": interval,
                "cron_expression": cron_expr,
                "sync_start": device.get("sync_start"),
                "sync_end": device.get("sync_end"),
            })
        
        return {
            "settlement_time": global_settings.get("settlement_time", "21:00"),
            "alert_enabled": global_settings.get("alert_enabled", True),
            "cron_jobs": cron_jobs,
            "total_devices": len(cron_jobs),
        }


# 便捷函数
def get_config_manager():
    """获取配置管理器实例"""
    return HardwareConfigManager()


def add_hardware_device(device_type: str, name: str = None, **settings):
    """快速添加设备"""
    manager = HardwareConfigManager()
    device_id = f"{device_type}_{datetime.now().strftime('%Y%m%d%H%M%S')}"
    
    if name is None:
        name_map = {
            "coros": "我的COROS手表",
            "apple_health": "我的Apple Watch",
            "xiaomi": "小米手环",
            "huawei": "华为手表",
        }
        name = name_map.get(device_type, "运动设备")
    
    return manager.add_device(device_id, device_type, {"name": name, **settings})


# 测试
if __name__ == "__main__":
    print("=== 硬件配置管理测试 ===\n")
    
    # 添加设备示例
    # add_hardware_device("coros", "我的高驰手表", sync_interval=1800)  # 30分钟
    
    manager = HardwareConfigManager()
    print("当前配置:")
    print(json.dumps(manager.config, ensure_ascii=False, indent=2))
    
    print("\n\nCron配置:")
    print(json.dumps(manager.generate_cron_config(), ensure_ascii=False, indent=2))
