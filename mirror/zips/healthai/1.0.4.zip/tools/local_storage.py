#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
本地存储工具 v2.0
- 通用路径配置（不写死）
- 隐私保护（不存个人信息）
- 动态基准存储
"""

import json
from datetime import datetime
from pathlib import Path

# ========== 通用配置（不写死）==========
def get_config():
    """获取配置 - 可自定义"""
    return {
        "data_base_dir": Path.home() / "Downloads" / "HealthSkill2.0" / "data",
        "privacy_fields": ["姓名", "名字", "name", "身份证", "id_card", "电话", "phone", 
                          "手机", "mobile", "地址", "address", "邮箱", "email", "性别", "sex",
                          "年龄", "age", "生日", "birthday"],
    }


def get_data_dir():
    """获取数据目录"""
    config = get_config()
    return config["data_base_dir"]


def get_privacy_fields():
    """获取隐私字段列表"""
    config = get_config()
    return config["privacy_fields"]


# 确保目录存在
DATA_DIR = get_data_dir()
DATA_DIR.mkdir(parents=True, exist_ok=True)


# ========== 隐私过滤 ==========
def filter_privacy(data):
    """过滤隐私信息"""
    privacy_fields = get_privacy_fields()
    
    if isinstance(data, dict):
        filtered = {}
        for key, value in data.items():
            if key not in privacy_fields:
                filtered[key] = filter_privacy(value)
        return filtered
    elif isinstance(data, list):
        return [filter_privacy(item) for item in data]
    else:
        return data


# ========== 用户数据 ==========
def get_user_file(user_id):
    """获取用户文件路径"""
    return DATA_DIR / "users" / f"user_{user_id}.json"


def load_user(user_id):
    """加载用户数据"""
    user_file = get_user_file(user_id)
    user_file.parent.mkdir(parents=True, exist_ok=True)
    
    if user_file.exists():
        with open(user_file, "r", encoding="utf-8") as f:
            data = json.load(f)
            # 加载时也过滤隐私
            return filter_privacy(data)
    
    return create_user(user_id)


def save_user(user_id, data):
    """保存用户数据 - 自动过滤隐私"""
    user_file = get_user_file(user_id)
    user_file.parent.mkdir(parents=True, exist_ok=True)
    
    # 保存前过滤隐私
    safe_data = filter_privacy(data)
    safe_data["last_updated"] = datetime.now().isoformat()
    
    with open(user_file, "w", encoding="utf-8") as f:
        json.dump(safe_data, f, ensure_ascii=False, indent=2)
    
    return user_file


def create_user(user_id):
    """创建新用户"""
    user_data = {
        "user_id": user_id,  # 仅存ID，不存其他信息
        "created_at": datetime.now().isoformat(),
        "current_stage": "适应期",
        "stage_score": 50,
        "health_score": None,
        "indicators": {},        # 指标数据
        "last_indicators": {},   # 上次指标（用于动态对比）
        "abnormal": [],
        "risk_level": None,
        "streak_days": 0,
        "completion_rate": 0.5,
        "recent_feelings": [],
        "last_feeling": None,
        "checkin_history": {},
        "current_plan": None,
        "last_checkin_date": None,
        "last_report_date": None,
        "days_since_plan_update": 0,
        "weekly_completion": 0.5,
        "stage_start_date": datetime.now().strftime("%Y-%m-%d")
    }
    
    save_user(user_id, user_data)
    return user_data


# ========== 打卡数据 ==========
def get_checkin_dir():
    """获取打卡目录"""
    return DATA_DIR / "checkins"


def save_checkin(user_id, date, data):
    """保存打卡 - 自动过滤隐私"""
    year_month = date[:7]
    checkin_dir = get_checkin_dir()
    checkin_dir.mkdir(parents=True, exist_ok=True)
    
    checkin_file = checkin_dir / f"{year_month}.json"
    
    # 加载
    if checkin_file.exists():
        with open(checkin_file, "r", encoding="utf-8") as f:
            checkins = json.load(f)
    else:
        checkins = {}
    
    # 追加（过滤隐私）
    safe_data = filter_privacy(data)
    
    if date in checkins:
        if "records" not in checkins[date]:
            checkins[date] = {"records": [], "打卡次数": 0}
        
        checkins[date]["records"].append({
            "timestamp": datetime.now().isoformat(),
            **safe_data
        })
        
        checkins[date]["打卡次数"] = len(checkins[date]["records"])
        checkins[date]["总运动时长"] = sum(r.get("运动时长", 0) for r in checkins[date]["records"])
        checkins[date]["总步数"] = sum(r.get("步数", 0) for r in checkins[date]["records"])
    else:
        checkins[date] = {
            "date": date,
            "records": [{
                "timestamp": datetime.now().isoformat(),
                **safe_data
            }],
            "打卡次数": 1,
            "总运动时长": safe_data.get("运动时长", 0),
            "总步数": safe_data.get("步数", 0),
            "完成状态": "已完成"
        }
    
    with open(checkin_file, "w", encoding="utf-8") as f:
        json.dump(checkins, f, ensure_ascii=False, indent=2)
    
    return checkin_file


def load_checkins(year_month=None):
    """加载打卡记录"""
    if year_month is None:
        year_month = datetime.now().strftime("%Y-%m")
    
    checkin_file = get_checkin_dir() / f"{year_month}.json"
    
    if checkin_file.exists():
        with open(checkin_file, "r", encoding="utf-8") as f:
            return json.load(f)
    
    return {}


# ========== 动态基准存储 ==========
def get_baseline_dir():
    """获取基准数据目录"""
    return DATA_DIR / "baselines"


def save_baseline(user_id, indicators, baseline_type="latest"):
    """
    保存动态基准
    - latest: 最新基准
    - first: 首次基准
    """
    baseline_dir = get_baseline_dir()
    baseline_dir.mkdir(parents=True, exist_ok=True)
    
    baseline_file = baseline_dir / f"{user_id}_{baseline_type}.json"
    
    data = {
        "timestamp": datetime.now().isoformat(),
        "indicators": filter_privacy(indicators),  # 过滤隐私
        "baseline_type": baseline_type
    }
    
    with open(baseline_file, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    
    return baseline_file


def load_baseline(user_id, baseline_type="latest"):
    """加载动态基准"""
    baseline_file = get_baseline_dir() / f"{user_id}_{baseline_type}.json"
    
    if baseline_file.exists():
        with open(baseline_file, "r", encoding="utf-8") as f:
            data = json.load(f)
            return data.get("indicators", {})
    
    return None


def compare_with_baseline(current_indicators, user_id):
    """与动态基准对比"""
    previous = load_baseline(user_id, "latest")
    
    if not previous:
        return {"is_first": True, "indicators": current_indicators}
    
    comparison = {}
    for name, data in current_indicators.items():
        current = data.get("value")
        prev = previous.get(name, {}).get("value")
        
        if prev is not None:
            change = current - prev
            comparison[name] = {
                "current": current,
                "previous": prev,
                "change": round(change, 2)
            }
        else:
            comparison[name] = {"current": current, "previous": None}
    
    return {"is_first": False, "indicators": comparison}


# ========== 通用存储接口 ==========
def save_record(user_id, record_type, data):
    """通用记录保存"""
    record_dir = DATA_DIR / record_type
    record_dir.mkdir(parents=True, exist_ok=True)
    
    record_file = record_dir / f"{user_id}.json"
    
    # 加载历史
    if record_file.exists():
        with open(record_file, "r", encoding="utf-8") as f:
            records = json.load(f)
    else:
        records = []
    
    # 添加新记录（过滤隐私）
    safe_data = filter_privacy(data)
    records.append({
        "timestamp": datetime.now().isoformat(),
        **safe_data
    })
    
    # 只保留最近50条
    records = records[-50:]
    
    with open(record_file, "w", encoding="utf-8") as f:
        json.dump(records, f, ensure_ascii=False, indent=2)
    
    return record_file


def load_records(user_id, record_type):
    """通用记录加载"""
    record_file = DATA_DIR / record_type / f"{user_id}.json"
    
    if record_file.exists():
        with open(record_file, "r", encoding="utf-8") as f:
            return json.load(f)
    
    return []


# 测试
if __name__ == "__main__":
    print("=== 测试隐私过滤 ===")
    test_data = {
        "姓名": "张三",
        "体重": 75,
        "血糖": 5.5,
        "phone": "13800138000"
    }
    filtered = filter_privacy(test_data)
    print(f"原始: {test_data}")
    print(f"过滤后: {filtered}")
    
    print("\n=== 测试基准对比 ===")
    current = {"体重": {"value": 73}, "血糖": {"value": 5.3}}
    # 假设之前存过基准
    save_baseline("test", {"体重": {"value": 75}, "血糖": {"value": 5.5}})
    result = compare_with_baseline(current, "test")
    print(json.dumps(result, ensure_ascii=False, indent=2))
