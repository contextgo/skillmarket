# HealthCoach 2.0 🦞

> 智能健康教练 - 多Agent康养管理系统

**版本**: 2.0  
**最后更新**: 2026-04-18  
**状态**: ✅ 全部测试通过

---

## 🎯 功能概览

| 功能 | 说明 |
|------|------|
| ✅ 首次激活引导 | 自动引导用户配置硬件/手动模式 |
| ✅ 体检报告分析 | 识别健康问题 |
| ✅ 动态运动方案 | 根据用户情况生成个性化方案 |
| ✅ 打卡记录 | 记录运动数据 |
| ✅ 多Agent决策 | 西医+中医+运动+营养 |
| ✅ 隐私保护 | 自动过滤姓名/电话/身份证等 |
| ✅ 长周期跟踪 | 按阶段记录健康状态 |
| ✅ 周复盘（号脉） | 中医四诊分析 |
| ✅ 主动推送 | 3天不动/异常预警 |
| ✅ 紧急通知 | 极端情况通知家人 |
| ✅ 硬件接入 | COROS/Apple/小米/华为/Garmin |
| ✅ 跨平台 | Windows/Mac/Linux |

---

## 🔄 核心逻辑

```
用户安装 → 首次引导 → 生成方案 → 执行打卡 → 反馈调整
                ↓                         ↓
            有体检报告? ──是──→ 分析指标 → 发现问题
                ↓ 否
            用户知道问题? ──是──→ 针对问题生成方案
                ↓ 否
            有硬件? ──是──→ 监控数据 → 发现异常 → 提醒用户
                ↓ 否
            生成通用康养方案 → 监督执行 → 看反馈调整
```

---

## 🎭 多Agent角色

| Agent | 角色 | 功能 |
|-------|------|------|
| 西医Agent | 医生 | 指标分析、风险评估 |
| 中医Agent | 先生 | 经络气血、治未病 |
| 运动Agent | 教练 | 运动处方、强度控制 |
| 营养Agent | 营养师 | 饮食建议、食疗方案 |
| 主决策 | 院长 | 综合评估、动态调整 |

---

## 📁 文件结构

```
HealthSkill-2.0/
├── main.py                    # 入口
├── SKILL.md                   # 技能说明
├── README.md                  # 本文件
├── FLOWCHART.md               # 完整流程图
├── SYSTEM_STATUS.md           # 系统状态
│
├── agents/                    # Agent模块
│   ├── welcome_flow.py        # 首次引导
│   ├── health_assessment_engine.py  # 核心引擎
│   ├── dynamic_planner.py     # 动态规划
│   ├── exercise_planner_agent.py    # 运动方案
│   ├── physical_exam_agent.py       # 体检分析
│   ├── checkin_evaluator_agent.py   # 打卡评估
│   ├── progress_predictor_agent.py  # 进度预测
│   ├── nutrition_agent.py    # 营养建议
│   ├── active_pusher.py      # 主动推送
│   └── dialog_manager.py     # 对话管理
│
├── hardware/                  # 硬件接入
│   ├── collector_v2.py       # 数据收集器
│   ├── health_monitor.py     # 健康监控
│   ├── notification.py       # 紧急通知
│   ├── coros.py              # COROS
│   ├── apple_health.py       # Apple Watch
│   ├── xiaomi.py             # 小米
│   ├── huawei.py             # 华为
│   └── garmin.py             # Garmin
│
├── data/                      # 数据存储
│   ├── storage.py            # 统一存储
│   ├── user_profile.py       # 用户档案
│   ├── weekly_review.py      # 周复盘
│   └── ...
│
└── tools/                     # 工具
    └── local_storage.py      # 本地存储
```

---

## 🚀 使用方式

### 1. 安装后首次使用

系统会自动发送欢迎消息，引导你完成配置：

```
👋 欢迎使用 HealthCoach 2.0！
我有运动手表吗？有/没有
有体检报告吗？有/没有
身体有什么问题？选择或描述
```

### 2. 日常使用

```python
# 打卡
"今天跑步30分钟，感觉良好"

# 问方案
"今天做什么运动?"

# 看状态
"我的健康状态怎么样?"
```

---

## 🔒 隐私保护

- ✅ 姓名/电话/身份证/地址 自动过滤
- ✅ 只保留业务需要的user_id
- ✅ 数据存在用户本地目录

---

## 📊 测试状态

```
✅ 存储模块
✅ 欢迎引导
✅ 用户档案+隐私
✅ 动态规划
✅ 主动推送
✅ 健康监控
✅ 周复盘
✅ 硬件收集
✅ 紧急通知
✅ 多Agent系统

10/10 通过
```

---

## 📝 更新日志

### 2026-04-18 v2.0
- 首次激活引导
- 完整隐私保护
- 长周期用户档案
- 周复盘（号脉）
- 主动推送触发
- 全部测试通过

---

**Ready for ClawHub / SkillHub!** 🦞
