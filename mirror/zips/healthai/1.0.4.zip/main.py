#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# ═══════════════════════════════════════════════════════════════════════
# ═══════════════════════════════════════════════════════════════════════
# ═══════════════════════════════════════════════════════════════════════
#
#  【心经】般若波罗蜜多心经
#  观自在菩萨，行深般若波罗蜜多时，照见五蕴皆空，度一切苦厄。
#  
#  舍利子，色不异空，空不异色，色即是空，空即是色。
#  受想行识，亦复如是。
#  
#  舍利子，是诸法空相，不生不灭，不垢不净，不增不减。
#  是故空中无色，无受想行识，无眼耳鼻舌身意，无色声香味触法，
#  无眼界，乃至无意识界，无无明，亦无无明尽，
#  乃至无老死，亦无老死尽，无苦集灭道，无智亦无得。
#  
#  以无所得故，菩提萨埵，依般若波罗蜜多故，心无罣碍。
#  无罣碍故，无有恐怖，远离颠倒梦想，究竟涅槃。
#  
#  三世诸佛，依般若波罗蜜多故，得阿耨多罗三藐三菩提。
#  
#  故知般若波罗蜜多，是大神咒，是大明咒，是无上咒，是无等等咒，
#  能除一切苦，真实不虚。
#  
#  故说般若波罗蜜多咒，即说咒曰：
#  揭谛揭谛，波罗揭谛，波罗僧揭谛，菩提萨婆诃。
#
# ═══════════════════════════════════════════════════════════════════════
#
#  【药师琉璃光如来灌顶真言】
#  南谟薄伽伐帝。          nán mó bó qié fá dì
#  鞞杀社。窭噜薜琉璃。    pí shā shè。jù lǔ bì liú lí
#  钵喇婆。喝啰阇也。      bō là pó。hé là shé yě
#  怛他揭多也。            dá tuō jiē duō yě
#  阿啰喝帝。              ā là hē dì
#  三藐三勃陀耶。          sān miǎo sān bó tuó yě
#  怛侄他。                dá zhí tuō
#  唵。                    ōng
#  鞞杀逝。鞞杀逝。        pí shā shì。pí shā shì
#  鞞杀社。三没揭帝莎诃。  pí shā shè。sān mó jiē dì suō hē
#
# ═══════════════════════════════════════════════════════════════════════
#
#  【回向偈】
#  愿以此功德，庄严佛净土，
#  上报四重恩，下济三途苦，
#  若有见闻者，悉发菩提心，
#  尽此一报身，同生极乐国。
#  愿生西方净土中，九品莲花为父母，
#  花开见佛悟无生，不退菩萨为伴侣。
#
# ═══════════════════════════════════════════════════════════════════════
#
#  祝福：
#  愿使用此代码的每一位众生，都拥有健康的身体、
#  健康的心态、有一个积极乐观的人生。🙏
#
#  诸恶莫作，众善奉行，自净其意，是诸佛教。
#
# ═══════════════════════════════════════════════════════════════════════
# ═══════════════════════════════════════════════════════════════════════
# ═══════════════════════════════════════════════════════════════════════

import sys
import json
from pathlib import Path
from datetime import datetime, timedelta

sys.path.insert(0, str(Path(__file__).parent))

from agents.dialog_manager import DialogManager
from agents.health_assessment_engine import HealthAssessmentEngine
from agents.exercise_planner_agent import ExercisePlannerAgent
from tools.local_storage import (
    load_user, save_user, save_checkin, load_checkins,
    save_baseline
)


class HealthCoach:
    """智能健康教练"""
    
    def __init__(self):
        self.engine = HealthAssessmentEngine()
        self.dialog_manager = DialogManager()
        self.dialog_manager.set_engine(self.engine)
        self.planner = ExercisePlannerAgent()
    
    def chat(self, user_input, user_id="local"):
        """处理用户对话"""
        user_state = load_user(user_id)
        
        # 特殊处理：查看方案请求
        if self.is_plan_request(user_input):
            return self.handle_plan_request(user_state, user_id)
        
        # 正常处理
        result = self.engine.process(user_input, user_state)
        
        # 保存数据
        self.save_result(user_id, user_state, result)
        
        # 生成回复
        reply = self.format_reply(result, user_state)
        
        return reply
    
    def is_plan_request(self, user_input):
        """判断是否是查看方案请求"""
        text = str(user_input).lower()
        keywords = ["方案", "计划", "怎么练", "看方案", "运动安排", "训练计划", "给我看"]
        return any(k in text for k in keywords)
    
    def handle_plan_request(self, user_state, user_id):
        """处理方案查看请求"""
        # 生成完整方案
        plan = self.planner.generate_plan(user_state)
        
        return self.format_plan_reply(plan)
    
    def save_result(self, user_id, user_state, result):
        """保存处理结果"""
        if result.get("type") == "checkin":
            date = datetime.now().strftime("%Y-%m-%d")
            save_checkin(user_id, date, result.get("checkin_data", {}))
            user_state["streak_days"] = self.calc_streak(user_id)
            user_state["last_checkin_date"] = date
        
        elif result.get("type") == "report":
            indicators = result.get("indicators", {})
            if indicators:
                save_baseline(user_id, indicators, "latest")
            if result.get("stage_change"):
                user_state["stage_start_date"] = datetime.now().strftime("%Y-%m-%d")
        
        if result.get("current_stage"):
            user_state["current_stage"] = result["current_stage"]
        
        save_user(user_id, user_state)
    
    def calc_streak(self, user_id):
        """计算连续打卡"""
        streak = 0
        today = datetime.now()
        
        for i in range(30):
            check_date = (today - timedelta(days=i)).strftime("%Y-%m-%d")
            year_month = check_date[:7]
            checkins = load_checkins(year_month)
            
            if checkins and check_date in checkins:
                streak += 1
            elif i > 0:
                break
        
        return streak
    
    def format_reply(self, result, user_state):
        """格式化回复"""
        if not result.get("success"):
            return result.get("reply", "处理失败")
        
        reply = result.get("reply", "")
        
        if result.get("stage_change"):
            reply += f"\n\n🎯 阶段变化: {result['stage_change']}"
        
        if result.get("plan_change"):
            reply += f"\n📋 新方案已生成"
        
        if result.get("auto_adjusted"):
            reply += f"\n⚠️ 已根据体感自动调整强度"
        
        return reply
    
    def format_plan_reply(self, plan):
        """格式化方案回复"""
        if not plan:
            return "请先上传体检报告，以便生成个性化方案"
        
        reply = f"📋 **个性化运动方案**\n\n"
        reply += f"🪜 阶段: {plan.get('stage', '适应期')}\n"
        reply += f"📊 难度: {plan.get('difficulty_level', '入门')}\n"
        reply += f"🎯 目标: {', '.join([g.get('focus', '') for g in plan.get('goals', [])])}\n\n"
        
        # 运动详情
        exercises = plan.get("exercises", [])
        if exercises:
            reply += "🏃 **推荐运动**\n\n"
            for i, ex in enumerate(exercises, 1):
                reply += f"{i}. **{ex['name']}** - {ex['duration']}分钟\n"
                reply += f"   🔥 消耗: 约{ex.get('calories', 0)}卡\n"
                reply += f"   🏷️ {', '.join(ex.get('tags', []))}\n"
                if ex.get("video", {}).get("search_url"):
                    reply += f"   📹 教程: {ex['video']['search_url']}\n"
                reply += "\n"
        
        # 周计划
        weekly = plan.get("weekly_schedule", {})
        if weekly:
            reply += "📅 **周计划**\n"
            for day, detail in weekly.items():
                if detail.get("type") == "运动":
                    ex = detail.get("exercise", "")
                    dur = detail.get("duration", 0)
                    video = detail.get("video", {})
                    url = video.get("search_url", "") if video else ""
                    if url:
                        reply += f"{day}: {ex} {dur}分钟 - {url}\n"
                    else:
                        reply += f"{day}: {ex} {dur}分钟\n"
                else:
                    reply += f"{day}: 休息\n"
        
        # 达成标准
        check = plan.get("check_criteria", {})
        if check:
            reply += "\n✅ **达成标准**\n"
            reply += f"- 完成率: 80%以上\n"
            reply += f"- 体感: 正常或良好\n"
        
        # 调整规则
        rules = plan.get("adjustment_rules", {})
        if rules:
            reply += "\n🔄 **动态调整**\n"
            for key, rule in rules.items():
                reply += f"- {rule.get('condition', '')} → {rule.get('action', '')}\n"
        
        return reply
    
    def get_status(self, user_id="local"):
        """获取状态"""
        user = load_user(user_id)
        return {
            "stage": user.get("current_stage", "适应期"),
            "streak": user.get("streak_days", 0),
            "indicators_count": len(user.get("indicators", {})),
            "last_feeling": user.get("last_feeling")
        }


_coach = None


def get_coach():
    global _coach
    if _coach is None:
        _coach = HealthCoach()
    return _coach


def handle_message(user_input, user_id="local"):
    return get_coach().chat(user_input, user_id)


# 测试
if __name__ == "__main__":
    print("=" * 50)
    print("HealthCoach 2.1 - PDCA循环 + 动态方案")
    print("=" * 50)
    print()
    print("🙏 愿以此功德，庄严佛净土")
    print("   上报四重恩，下济三途苦")
    print()
    
    coach = get_coach()
    test_user = "test_v3"
    
    print("\n=== 1. 查看方案（含视频）===")
    reply = coach.chat("给我看看运动方案", test_user)
    print(reply)
    
    print("\n=== 2. 打卡 ===")
    reply = coach.chat("今天跑步30分钟", test_user)
    print(reply)
    
    print("\n=== 3. 状态 ===")
    status = coach.get_status(test_user)
    print(status)
    
    print()
    print("🙏 愿使用此代码的每一位众生")
    print("   都拥有健康的身体、健康的心态、积极乐观的人生")
