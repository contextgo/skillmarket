#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
周复盘系统（中医"号脉"）
每周自动分析用户健康状态，调整方案
"""

import json
from datetime import datetime, timedelta
from pathlib import Path


class WeeklyReviewer:
    """周复盘（号脉）"""
    
    def __init__(self, storage):
        self.storage = storage
    
    def create_weekly_review(self, user_id: str, user_profile: dict = None) -> dict:
        """
        创建周复盘
        
        中医四诊：
        1. 望 → 看数据趋势
        2. 问 → 问用户体感
        3. 切 → 分析指标
        4. 断 → 判断状态 + 开方
        """
        # 1. 获取本周数据
        now = datetime.now()
        week_start = (now - timedelta(days=6)).strftime("%Y-%m-%d")
        week_end = now.strftime("%Y-%m-%d")
        
        # 获取硬件数据
        hardware_data = self.storage.get_hardware_data_range(week_start, week_end)
        
        # 获取打卡数据
        checkins = self.storage.get_checkins(user_id, days=7)
        
        # 获取基准
        baseline = self.storage.get_baseline(user_id)
        
        # 2. 分析数据
        analysis = self._analyze_week_data(hardware_data, checkins, baseline)
        
        # 3. 四诊判断
        diagnosis = self._four_diagnoses(analysis, user_profile)
        
        # 4. 生成复盘报告
        review = {
            "week": f"{now.isocalendar()[0]}-W{now.isocalendar()[1]:02d}",
            "user_id": user_id,
            "period": {"start": week_start, "end": week_end},
            "data_summary": analysis,
            "diagnosis": diagnosis,
            "recommendations": self._generate_recommendations(diagnosis),
            "next_week_plan": self._generate_next_week_plan(diagnosis),
            "created_at": datetime.now().isoformat()
        }
        
        # 5. 保存
        self.storage.create_weekly_review(user_id, review)
        
        return review
    
    def _analyze_week_data(self, hardware_data: list, checkins: list, baseline: dict) -> dict:
        """分析本周数据"""
        
        # 汇总硬件数据
        total_steps = 0
        total_workout_min = 0
        avg_heart_rate = 0
        heart_rates = []
        
        for h in hardware_data:
            total_steps += h.get("steps", 0)
            total_workout_min += h.get("workout_minutes", 0)
            if h.get("heart_rate"):
                heart_rates.append(h.get("heart_rate"))
        
        if heart_rates:
            avg_heart_rate = sum(heart_rates) / len(heart_rates)
        
        # 打卡统计
        checkin_count = len(checkins)
        completed_count = sum(1 for c in checkins if c.get("completed", False))
        completion_rate = (completed_count / checkin_count * 100) if checkin_count > 0 else 0
        
        # 对比基准
        changes = {}
        if baseline:
            if total_steps > baseline.get("avg_steps", 0):
                changes["steps"] = "↑ 上升"
            elif total_steps < baseline.get("avg_steps", 0) * 0.7:
                changes["steps"] = "↓ 下降"
            else:
                changes["steps"] = "→ 稳定"
        
        return {
            "total_steps": total_steps,
            "total_workout_min": total_workout_min,
            "avg_heart_rate": round(avg_heart_rate, 1),
            "checkin_count": checkin_count,
            "completion_rate": round(completion_rate, 1),
            "changes": changes,
            "trend": self._calculate_trend(changes)
        }
    
    def _calculate_trend(self, changes: dict) -> str:
        """计算整体趋势"""
        up = sum(1 for v in changes.values() if "↑" in str(v))
        down = sum(1 for v in changes.values() if "↓" in str(v))
        
        if up > down:
            return "上升"
        elif down > up:
            return "下降"
        else:
            return "稳定"
    
    def _four_diagnoses(self, analysis: dict, user_profile: dict = None) -> dict:
        """中医四诊"""
        
        # 望：看数据
        data_trend = analysis.get("trend", "稳定")
        completion_rate = analysis.get("completion_rate", 0)
        
        # 问：问体感（如果有用户反馈）
        user_feeling = user_profile.get("feeling", "良好") if user_profile else "良好"
        
        # 切：分析指标
        heart_rate = analysis.get("avg_heart_rate", 0)
        steps = analysis.get("total_steps", 0)
        
        # 切脉结论
        pulse = {}
        
        if heart_rate > 90:
            pulse["heart"] = "弦脉（心火旺/压力大）"
        elif heart_rate < 60:
            pulse["heart"] = "缓脉（气血虚）"
        else:
            pulse["heart"] = "平脉（正常）"
        
        if steps < 30000:
            pulse["activity"] = "迟脉（活动不足）"
        elif steps > 70000:
            pulse["activity"] = "洪脉（运动过量）"
        else:
            pulse["activity"] = "平脉（正常）"
        
        # 断：判断状态
        if data_trend == "上升" and completion_rate >= 70:
            status = "健康向上"
            condition = "良好"
        elif data_trend == "下降" or completion_rate < 30:
            status = "需要关注"
            condition = "欠佳"
        else:
            status = "基本稳定"
            condition = "一般"
        
        return {
            "望_data": f"数据趋势{data_trend}，完成率{completion_rate}%",
            "问_feeling": user_feeling,
            "切_pulse": pulse,
            "断_status": status,
            "断_condition": condition
        }
    
    def _generate_recommendations(self, diagnosis: dict) -> List[dict]:
        """根据诊断生成建议"""
        recommendations = []
        
        status = diagnosis.get("断_status", "")
        pulse = diagnosis.get("切_pulse", {})
        
        # 根据脉象给建议
        if "弦脉" in str(pulse.get("heart", "")):
            recommendations.append({
                "type": "降火",
                "content": "心火旺，建议：静坐冥想、少熬夜、多喝水"
            })
        
        if "迟脉" in str(pulse.get("activity", "")):
            recommendations.append({
                "type": "增加活动",
                "content": "活动不足，建议：每天步行30分钟，逐步增加"
            })
        
        if "洪脉" in str(pulse.get("activity", "")):
            recommendations.append({
                "type": "减量",
                "content": "运动可能过量，建议：适当休息，减少强度"
            })
        
        if status == "需要关注":
            recommendations.append({
                "type": "重点关注",
                "content": "本周状态欠佳，建议：调整心态，适当运动"
            })
        
        # 通用建议
        recommendations.append({
            "type": "养生",
            "content": "保持规律作息，23点前入睡"
        })
        
        return recommendations
    
    def _generate_next_week_plan(self, diagnosis: dict) -> dict:
        """生成下周计划（调整药方）"""
        
        status = diagnosis.get("断_status", "")
        
        if status == "健康向上":
            return {
                "intensity": "保持或轻微增加",
                "focus": "巩固现有成果",
                "target_steps": "每天8000-10000步",
                "workout": "每周3-4次，每次30分钟"
            }
        elif status == "需要关注":
            return {
                "intensity": "降低，以恢复为主",
                "focus": "调整状态",
                "target_steps": "每天5000步",
                "workout": "每周2次，轻度运动"
            }
        else:
            return {
                "intensity": "维持现状",
                "focus": "保持节奏",
                "target_steps": "每天6000-8000步",
                "workout": "每周3次"
            }
    
    def get_weekly_summary(self, user_id: str) -> str:
        """生成周复盘摘要（给用户看）"""
        
        # 获取最新复盘
        review = self.storage.get_latest_review(user_id)
        
        if not review:
            return "暂无周复盘数据"
        
        diagnosis = review.get("diagnosis", {})
        plan = review.get("next_week_plan", {})
        recommendations = review.get("recommendations", [])
        
        # 拼接消息
        msg = f"""
📋 本周健康复盘

【四诊结果】
{diagnosis.get('望_data', '')}
体感: {diagnosis.get('问_feeling', '')}
脉象: 心-{diagnosis.get('切_pulse', {}).get('heart', '')}
状态: {diagnosis.get('断_status', '')} ({diagnosis.get('断_condition', '')})

【下周方案】（调整药方）
强度: {plan.get('intensity', '')}
重点: {plan.get('focus', '')}
目标: {plan.get('target_steps', '')}
运动: {plan.get('workout', '')}

【建议】
"""
        for r in recommendations[:3]:
            msg += f"• {r.get('content', '')}\n"
        
        return msg


# 测试
if __name__ == "__main__":
    from storage import get_storage
    
    storage = get_storage()
    reviewer = WeeklyReviewer(storage)
    
    print("=== 周复盘系统 ===")
    print("使用示例：")
    print("  review = reviewer.create_weekly_review('user_123')")
    print("  summary = reviewer.get_weekly_summary('user_123')")
