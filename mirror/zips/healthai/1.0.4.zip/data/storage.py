#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
数据存储系统
统一管理：硬件数据、打卡数据、基准数据、周复盘
"""

import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional

# 使用跨平台工具
import sys
sys.path.insert(0, str(Path(__file__).parent.parent / "hardware"))
from platform_utils import get_data_folder


class HealthDataStorage:
    """健康数据存储器"""
    
    def __init__(self, app_name: str = "HealthSkill2.0"):
        # 数据目录
        self.base_dir = get_data_folder(app_name) / "data"
        self.hardware_dir = self.base_dir / "hardware"
        self.checkin_dir = self.base_dir / "checkins"
        self.baseline_dir = self.base_dir / "baselines"
        self.weekly_dir = self.base_dir / "weekly_reviews"
        
        # 创建目录
        for d in [self.hardware_dir, self.checkin_dir, self.baseline_dir, self.weekly_dir]:
            d.mkdir(parents=True, exist_ok=True)
    
    # ==================== 硬件数据 ====================
    
    def save_hardware_data(self, date: str, data: dict) -> str:
        """
        保存硬件抓取的数据
        
        文件名: hardware/2026-04-18.json
        """
        file_path = self.hardware_dir / f"{date}.json"
        
        # 读取现有数据
        existing = {}
        if file_path.exists():
            with open(file_path, "r", encoding="utf-8") as f:
                existing = json.load(f)
        
        # 合并新数据
        existing.update({
            "updated_at": datetime.now().isoformat(),
            **data
        })
        
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(existing, f, ensure_ascii=False, indent=2)
        
        return str(file_path)
    
    def get_hardware_data(self, date: str = None) -> dict:
        """获取指定日期的硬件数据"""
        if date is None:
            date = datetime.now().strftime("%Y-%m-%d")
        
        file_path = self.hardware_dir / f"{date}.json"
        
        if file_path.exists():
            with open(file_path, "r", encoding="utf-8") as f:
                return json.load(f)
        
        return {}
    
    def get_hardware_data_range(self, start_date: str, end_date: str) -> List[dict]:
        """获取日期范围的硬件数据"""
        result = []
        start = datetime.strptime(start_date, "%Y-%m-%d")
        end = datetime.strptime(end_date, "%Y-%m-%d")
        
        current = start
        while current <= end:
            date_str = current.strftime("%Y-%m-%d")
            data = self.get_hardware_data(date_str)
            if data:
                data["date"] = date_str
                result.append(data)
            current += timedelta(days=1)
        
        return result
    
    # ==================== 打卡数据 ====================
    
    def save_checkin(self, user_id: str, checkin_data: dict) -> str:
        """
        保存打卡记录
        
        文件: checkins/checkins.json
        结构: {user_id: [checkin1, checkin2, ...]}
        """
        file_path = self.checkin_dir / "checkins.json"
        
        # 读取现有数据
        all_checkins = {}
        if file_path.exists():
            with open(file_path, "r", encoding="utf-8") as f:
                all_checkins = json.load(f)
        
        # 添加新打卡
        if user_id not in all_checkins:
            all_checkins[user_id] = []
        
        checkin_record = {
            "id": len(all_checkins[user_id]) + 1,
            "date": datetime.now().strftime("%Y-%m-%d"),
            "time": datetime.now().strftime("%H:%M:%S"),
            **checkin_data
        }
        
        all_checkins[user_id].append(checkin_record)
        
        # 保存
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(all_checkins, f, ensure_ascii=False, indent=2)
        
        return str(file_path)
    
    def get_checkins(self, user_id: str, days: int = 7) -> List[dict]:
        """获取用户的打卡记录"""
        file_path = self.checkin_dir / "checkins.json"
        
        if not file_path.exists():
            return []
        
        with open(file_path, "r", encoding="utf-8") as f:
            all_checkins = json.load(f)
        
        user_checkins = all_checkins.get(user_id, [])
        
        # 过滤最近N天
        if days:
            cutoff = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")
            user_checkins = [c for c in user_checkins if c.get("date", "") >= cutoff]
        
        return user_checkins
    
    # ==================== 动态基准 ====================
    
    def update_baseline(self, user_id: str, metrics: dict) -> str:
        """
        更新用户基准数据
        
        对比每次新增数据与上次基准
        """
        file_path = self.baseline_dir / f"{user_id}.json"
        
        # 读取现有基准
        baseline = {}
        if file_path.exists():
            with open(file_path, "r", encoding="utf-8") as f:
                baseline = json.load(f)
        
        # 计算变化
        changes = {}
        for key, value in metrics.items():
            if key in baseline:
                old_value = baseline[key]
                if isinstance(value, (int, float)) and isinstance(old_value, (int, float)):
                    change = value - old_value
                    change_pct = (change / old_value * 100) if old_value != 0 else 0
                    changes[key] = {
                        "old": old_value,
                        "new": value,
                        "change": change,
                        "change_pct": round(change_pct, 1)
                    }
        
        # 更新基准
        baseline.update(metrics)
        baseline["updated_at"] = datetime.now().isoformat()
        
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(baseline, f, ensure_ascii=False, indent=2)
        
        return changes
    
    def get_baseline(self, user_id: str) -> dict:
        """获取用户基准"""
        file_path = self.baseline_dir / f"{user_id}.json"
        
        if file_path.exists():
            with open(file_path, "r", encoding="utf-8") as f:
                return json.load(f)
        
        return {}
    
    # ==================== 周复盘 ====================
    
    def create_weekly_review(self, user_id: str, week_data: dict) -> str:
        """
        创建周复盘（号脉）
        
        文件: weekly_reviews/2026-W16.json
        """
        # 计算周数
        now = datetime.now()
        week_num = now.isocalendar()[1]
        year = now.year
        week_key = f"{year}-W{week_num:02d}"
        
        file_path = self.weekly_dir / f"{week_key}.json"
        
        review = {
            "week": week_key,
            "user_id": user_id,
            "created_at": datetime.now().isoformat(),
            **week_data
        }
        
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(review, f, ensure_ascii=False, indent=2)
        
        return str(file_path)
    
    def get_latest_review(self, user_id: str) -> dict:
        """获取最新的周复盘"""
        # 找到最新的周复盘文件
        files = sorted(self.weekly_dir.glob("*.json"), reverse=True)
        
        for f in files:
            with open(f, "r", encoding="utf-8") as fp:
                data = json.load(fp)
                if data.get("user_id") == user_id:
                    return data
        
        return {}
    
    def get_weekly_review_history(self, user_id: str, weeks: int = 4) -> List[dict]:
        """获取历史周复盘"""
        files = sorted(self.weekly_dir.glob("*.json"), reverse=True)[:weeks]
        
        result = []
        for f in files:
            with open(f, "r", encoding="utf-8") as fp:
                data = json.load(fp)
                if data.get("user_id") == user_id:
                    result.append(data)
        
        return result


# 便捷函数
def get_storage():
    return HealthDataStorage()


# 测试
if __name__ == "__main__":
    storage = HealthDataStorage()
    
    print("=== 数据存储系统 ===\n")
    print(f"数据目录: {storage.base_dir}")
    print(f"硬件数据: {storage.hardware_dir}")
    print(f"打卡数据: {storage.checkin_dir}")
    print(f"基准数据: {storage.baseline_dir}")
    print(f"周复盘:   {storage.weekly_dir}")
