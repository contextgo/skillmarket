# HealthCoach 2.0 数据存储系统

## 目录结构

```
data/
├── hardware/           # 硬件抓取的数据（按天）
│   └── 2026-04-18.json
├── checkins/          # 手动打卡数据
│   └── checkins.json
├── baselines/         # 动态基准（每次对比）
│   └── user_id.json
├── weekly_reviews/    # 周复盘（号脉）
│   └── 2026-W16.json
└── users/             # 用户档案
```

---

## 数据类型

### 1. 硬件数据
- 来源：运动手表自动抓取
- 存储：`hardware/YYYY-MM-DD.json`
- 内容：步数、心率、运动记录

### 2. 打卡数据
- 来源：用户手动打卡
- 存储：`checkins/checkins.json`
- 内容：运动类型、时长、感觉

### 3. 动态基准
- 每次新增数据与上次对比
- 存储：`baselines/user_id.json`
- 内容：指标变化百分比

### 4. 周复盘（中医号脉）
- 每周自动生成
- 存储：`weekly_reviews/YYYY-Www.json`
- 内容：四诊分析 + 下周方案

---

## 周复盘（号脉）

### 中医四诊

```
┌─────────────────────────────────────────────────┐
│           周复盘 = 中医号脉                      │
├─────────────────────────────────────────────────┤
│  1. 望 → 看本周数据趋势                         │
│  2. 问 → 问用户感觉如何                         │
│  3. 切 → 分析指标变化                           │
│  4. 断 → 判断健康状态                           │
│  5. 开 → 调整下周期方案（换药）                 │
└─────────────────────────────────────────────────┘
```

### 脉象对应

| 脉象 | 指标 | 状态 | 建议 |
|------|------|------|------|
| 平脉 | 心率60-90 | 正常 | 保持 |
| 弦脉 | 心率>90 | 心火旺/压力大 | 静坐冥想 |
| 缓脉 | 心率<60 | 气血虚 | 适当运动 |
| 迟脉 | 步数<30k/周 | 活动不足 | 增加步行 |
| 洪脉 | 步数>70k/周 | 运动过量 | 适当休息 |

### 下周方案（调整药方）

根据本周状态动态调整：

| 本周状态 | 下周强度 | 目标步数 |
|----------|----------|----------|
| 健康向上 | 保持或增加 | 8000-10000 |
| 基本稳定 | 维持现状 | 6000-8000 |
| 需要关注 | 降低恢复 | 5000 |

---

## 使用方式

```python
from data.storage import get_storage
from data.weekly_review import WeeklyReviewer

# 初始化
storage = get_storage()

# 保存硬件数据
storage.save_hardware_data("2026-04-18", {
    "steps": 8500,
    "heart_rate": 72,
    "workout_minutes": 30
})

# 保存打卡
storage.save_checkin("user_123", {
    "type": "跑步",
    "duration": 30,
    "feeling": "累"
})

# 更新基准
changes = storage.update_baseline("user_123", {
    "steps": 8500,
    "heart_rate": 72
})

# 创建周复盘
reviewer = WeeklyReviewer(storage)
review = reviewer.create_weekly_review("user_123")

# 获取复盘摘要
summary = reviewer.get_weekly_summary("user_123")
print(summary)
```

---

## 定时任务

### 每日任务
- 21:00 结算当日数据
- 保存硬件数据到文件
- 更新动态基准

### 每周任务
- 周日 20:00 生成周复盘
- 调用中医四诊分析
- 生成下周方案

---

## 数据路径（跨平台）

| 平台 | 路径 |
|------|------|
| Windows | `C:\Users\xxx\AppData\Local\HealthSkill2.0\data\` |
| macOS | `~/Library/Application Support/HealthSkill2.0/data/` |
| Linux | `~/.local/share/HealthSkill2.0/data/` |
