#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
上传 Universal AutoStart 技能到 SkillHub
"""

import os
import sys
import zipfile
import json
import requests
from pathlib import Path

# 配置
SKILLHUB_API_KEY = "sk-skillhubs-JNpqszhN_oGF3u3xGEAMpJIjG6V2_etC"
SKILLHUB_BASE_URL = "https://www.skillhub.club/api/v1"
SKILL_FOLDER = r"C:\Users\Administrator\.copaw\workspaces\default\skills\universal-autostart"

def create_skill_package(skill_path, output_path):
    """创建技能压缩包"""
    print(f"[INFO] Packing skill: {skill_path}")
    
    with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(skill_path):
            # Skip unnecessary directories
            dirs[:] = [d for d in dirs if not d.startswith('.') and d != '__pycache__']
            
            for file in files:
                # Skip unnecessary files
                if file.startswith('.') or file.endswith('.pyc'):
                    continue
                    
                file_path = os.path.join(root, file)
                arc_name = os.path.relpath(file_path, skill_path)
                
                print(f"  + {arc_name}")
                zipf.write(file_path, arc_name)
    
    print(f"[OK] Skill package created: {output_path}")
    return output_path


def upload_to_skillhub(skill_package_path):
    """Upload to SkillHub"""
    print("\n[INFO] Uploading to SkillHub...")
    
    url = f"{SKILLHUB_BASE_URL}/skills"
    
    headers = {
        "Authorization": f"Bearer {SKILLHUB_API_KEY}"
    }
    
    with open(skill_package_path, 'rb') as f:
        files = {
            'skill': ('universal-autostart.skill', f, 'application/zip')
        }
        
        data = {
            'name': 'Universal AutoStart Service Manager',
            'slug': 'universal-autostart',
            'version': '1.1.0',
            'description': 'Cross-platform auto-start service manager for Windows and macOS'
        }
        
        try:
            response = requests.post(url, headers=headers, files=files, data=data, timeout=120)
            
            if response.status_code == 200 or response.status_code == 201:
                result = response.json()
                print("[OK] Upload successful!")
                print(f"\nSkill details:")
                print(f"  Name: {result.get('name')}")
                print(f"  Slug: {result.get('slug')}")
                print(f"  Version: {result.get('version')}")
                print(f"  URL: https://www.skillhub.club/skills/{result.get('slug')}")
                return True
            else:
                print(f"[ERROR] Upload failed (HTTP {response.status_code})")
                print(f"Error message: {response.text}")
                return False
                
        except requests.exceptions.Timeout:
            print("[ERROR] Request timeout, please check network connection")
            return False
        except Exception as e:
            print(f"[ERROR] Upload error: {e}")
            return False


def main():
    """Main function"""
    print("=" * 60)
    print("  Universal AutoStart - SkillHub Publisher")
    print("=" * 60)
    print()
    
    # Check skill folder
    if not os.path.exists(SKILL_FOLDER):
        print(f"[ERROR] Skill folder does not exist: {SKILL_FOLDER}")
        return False
    
    # Create skill package
    package_name = "universal-autostart.skill"
    package_path = os.path.join(os.path.dirname(SKILL_FOLDER), package_name)
    
    try:
        create_skill_package(SKILL_FOLDER, package_path)
        
        # Upload
        success = upload_to_skillhub(package_path)
        
        if success:
            print("\n" + "=" * 60)
            print("  [SUCCESS] Publishing complete!")
            print("=" * 60)
        else:
            print("\n[WARNING] Publishing failed, please try again later")
        
        return success
        
    finally:
        # Optional: clean up temporary files
        pass


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
