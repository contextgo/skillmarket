#!/usr/bin/env python3
"""
群聊清理脚本
每月导出并清理群聊历史
"""

import json
import os
from datetime import datetime

def export_session_to_md(session_file, output_file, max_entries=30):
    """导出会话为md格式"""
    import re
    
    texts = []
    try:
        with open(session_file, 'r') as f:
            for line in f:
                try:
                    data = json.loads(line)
                    if data.get('type') == 'message':
                        msg = data.get('message', {})
                        role = msg.get('role')
                        content = msg.get('content', [])
                        for c in content:
                            if c.get('type') == 'text':
                                text = c.get('text', '')
                                if text and len(text) > 20:
                                    # 清理markdown
                                    text = re.sub(r'```[\s\S]*?```', '', text)
                                    if role == 'user':
                                        texts.append(f"### 👤 用户\n{text[:500]}\n")
                                    elif role == 'assistant':
                                        texts.append(f"### 🤖 助手\n{text[:500]}\n")
                except:
                    continue
    except:
        return False
    
    if texts:
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(f"# 群聊历史导出\n\n")
            f.write(f"导出时间: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n\n")
            f.write('\n---\n\n'.join(texts[:max_entries]))
        return True
    return False

def cleanup_group_sessions():
    """清理群聊会话"""
    sessions_dir = "/root/.openclaw/agents/main/sessions"
    memory_dir = "/root/.openclaw/workspace/memory"
    backup_dir = "/root/.openclaw/workspace/memory/group-backup"
    
    print("🧹 群聊清理开始...")
    
    # 创建备份目录
    os.makedirs(backup_dir, exist_ok=True)
    
    # 读取sessions.json
    with open(f"{sessions_dir}/sessions.json", 'r') as f:
        sessions = json.load(f)
    
    to_delete = []
    exported = []
    
    for sk, sd in sessions.items():
        # 只处理群聊会话
        if "group:" not in sk:
            continue
        
        sid = sd.get("sessionId")
        transcript = f"{sessions_dir}/{sid}.jsonl"
        
        if not sid or not os.path.exists(transcript):
            continue
        
        # 导出
        date = datetime.now().strftime("%Y-%m-%d")
        output_file = f"{memory_dir}/群聊历史_{sk.split(':')[-1]}_{date}.md"
        
        if export_session_to_md(transcript, output_file):
            exported.append(sk)
            print(f"  📄 导出: {sk[:35]}...")
        
        to_delete.append((sk, sid, transcript))
    
    print(f"\n统计: 导出{len(exported)}个, 将删除{len(to_delete)}个")
    
    # 执行删除
    for sk, sid, transcript in to_delete:
        # 备份
        if os.path.exists(transcript):
            date = datetime.now().strftime("%Y%m%d")
            backup_file = f"{backup_dir}/{sid}_{date}.jsonl"
            os.rename(transcript, backup_file)
        # 删除session记录
        sessions.pop(sk, None)
    
    # 保存
    with open(f"{sessions_dir}/sessions.json", 'w') as f:
        json.dump(sessions, f, indent=2)
    
    print(f"\n✅ 完成! 导出文件: {memory_dir}/群聊历史_*")
    print(f"   备份位置: {backup_dir}/")

if __name__ == "__main__":
    cleanup_group_sessions()
