#!/usr/bin/env python3
"""
梦境清理 (Dream Cleanup)
借鉴OpenClaw Dreaming机制 - 六维评分系统决定记忆去留
"""

import json
import os
import shutil
from datetime import datetime
from typing import Dict, List

WEIGHTS = {
    "relevance": 0.30,
    "frequency": 0.24,
    "temporal": 0.15,
    "diversity": 0.15,
    "integration": 0.10,
    "richness": 0.06
}

# 核心主题关键词（用户经常发布的任务类型）
CORE_TOPICS = ["项目", "任务", "技能", "定时任务", "团队", "复盘", "决策", "洞察", "配置", "agent", "skill", "cron", "memory"]
# 关键敏感词（必须保留）
KEY_TOPICS = ["密码", "secret", "key", "token", "api_key", "账号", "凭证"]

def score_relevance(text):
    text_lower = text.lower()
    matches = sum(1 for t in CORE_TOPICS if t.lower() in text_lower)
    return min(matches / 3, 1.0)

def score_frequency(session_data):
    return min(session_data.get("message_count", 1) / 10, 1.0)

def score_temporal(session_data):
    updated_at = session_data.get("updatedAt", 0)
    age_days = (datetime.now().timestamp() * 1000 - updated_at) / 86400000
    return max(1 - age_days / 7, 0)

def score_diversity(text):
    domains = ["技术", "编程", "数据分析", "财务", "营销", "战略", "产品", "运营", "设计", "管理", "学习"]
    matches = sum(1 for d in domains if d in text)
    return min(matches / 3, 1.0)

def score_integration(text):
    connectors = ["因为", "所以", "但是", "因此", "并且", "然后"]
    return min(sum(1 for c in connectors if c in text) / 2, 1.0)

def score_richness(text):
    indicators = ["%", "倍", "策略", "方法论", "模型", "框架", "流程"]
    return min(sum(1 for i in indicators if i in text) / 2, 1.0)

def is_key_topic(text):
    return any(k.lower() in text.lower() for k in KEY_TOPICS)

def calculate_score(session_data, text):
    if is_key_topic(text): return 1.0
    scores = {
        "relevance": score_relevance(text),
        "frequency": score_frequency(session_data),
        "temporal": score_temporal(session_data),
        "diversity": score_diversity(text),
        "integration": score_integration(text),
        "richness": score_richness(text)
    }
    return sum(scores[k] * WEIGHTS[k] for k in WEIGHTS)

def decide_fate(session_data, text):
    score = calculate_score(session_data, text)
    if score >= 0.6: return "keep"
    elif score >= 0.3: return "summarize"
    else: return "forget"

def export_text(session_file):
    texts = []
    try:
        with open(session_file, 'r') as f:
            for line in f:
                try:
                    data = json.loads(line)
                    if data.get('type') == 'message':
                        msg = data.get('message', {})
                        for c in msg.get('content', []):
                            if c.get('type') == 'text':
                                texts.append(c.get('text', ''))
                except: continue
    except: pass
    return '\n'.join(texts[:20])

def main(dry_run=True):
    sessions_dir = "/root/.openclaw/agents/main/sessions"
    memory_dir = "/root/.openclaw/workspace/memory"
    backup_dir = "/root/.openclaw/workspace/memory/dream-backup"
    
    print("🌙 梦境清理...")
    mode = "预览" if dry_run else "执行"
    print(f"模式: {mode}\n权重: {WEIGHTS}\n")
    
    os.makedirs(backup_dir, exist_ok=True)
    
    with open(f"{sessions_dir}/sessions.json", 'r') as f:
        sessions = json.load(f)
    
    stats = {"keep": 0, "summarize": 0, "forget": 0}
    to_delete = []
    
    for sk, sd in sessions.items():
        if sd.get("totalTokens", 0) < 1000: continue
        sid = sd.get("sessionId")
        if not sid: continue
        
        transcript = f"{sessions_dir}/{sid}.jsonl"
        if not os.path.exists(transcript): continue
        
        text = export_text(transcript)
        if not text: continue
        
        fate = decide_fate(sd, text)
        
        if fate == "keep":
            stats["keep"] += 1
            print(f"✅ 保留: {sk[:35]}...")
        elif fate == "summarize":
            stats["summarize"] += 1
            date = datetime.now().strftime("%Y-%m-%d")
            with open(f"{memory_dir}/dream-summaries-{date}.md", 'a') as f:
                f.write(f"\n### {sk}\n{text[:500]}...\n")
            print(f"📝 摘要: {sk[:35]}...")
        else:
            stats["forget"] += 1
            to_delete.append((sk, sid, transcript))
            print(f"❌ 遗忘: {sk[:35]}...")
    
    print(f"\n结果: 保留{stats['keep']}, 摘要{stats['summarize']}, 遗忘{stats['forget']}")
    
    if not dry_run and to_delete:
        print("\n🗑️ 执行删除...")
        for sk, sid, transcript in to_delete:
            shutil.copy(transcript, f"{backup_dir}/{sid}.jsonl")
            sessions.pop(sk, None)
            os.remove(transcript)
        with open(f"{sessions_dir}/sessions.json", 'w') as f:
            json.dump(sessions, f, indent=2)
        print(f"已删除{len(to_delete)}个会话，备份到dream-backup/")
    elif not dry_run:
        print("没有需要删除的会话")

if __name__ == "__main__":
    import sys
    dry = "--execute" not in sys.argv
    main(dry_run=dry)
