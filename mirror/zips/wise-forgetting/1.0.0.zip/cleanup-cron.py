#!/usr/bin/env python3
"""
Cron会话清理脚本
每周清理旧的定时任务会话历史
"""

import json
import os
from datetime import datetime, timedelta
from pathlib import Path

def cleanup_cron_sessions(days_to_keep=14):
    """清理旧的cron任务会话"""
    sessions_dir = "/root/.openclaw/agents/main/sessions"
    backup_dir = "/root/.openclaw/workspace/memory/cron-backup"
    
    print(f"🧹 Cron会话清理 (保留最近{days_to_keep}天)...")
    
    # 创建备份目录
    os.makedirs(backup_dir, exist_ok=True)
    
    # 读取sessions.json
    with open(f"{sessions_dir}/sessions.json", 'r') as f:
        sessions = json.load(f)
    
    now = datetime.now()
    cutoff = (now - timedelta(days=days_to_keep)).timestamp() * 1000
    
    to_delete = []
    kept = []
    
    for sk, sd in sessions.items():
        # 只处理cron会话
        if "cron:" not in sk:
            continue
        
        updated = sd.get("updatedAt", 0)
        
        if updated < cutoff:
            sid = sd.get("sessionId")
            transcript = f"{sessions_dir}/{sid}.jsonl"
            to_delete.append((sk, sid, transcript))
            print(f"  ❌ 将删除: {sk[:40]}...")
        else:
            kept.append(sk)
            print(f"  ✅ 保留: {sk[:40]}...")
    
    print(f"\n统计: 保留{len(kept)}个, 删除{len(to_delete)}个")
    
    # 执行删除
    for sk, sid, transcript in to_delete:
        # 备份
        if os.path.exists(transcript):
            date = datetime.now().strftime("%Y%m%d")
            backup_file = f"{backup_dir}/{sid}_{date}.jsonl"
            os.rename(transcript, backup_file)
        # 删除session记录
        sessions.pop(sk, None)
    
    # 保存
    with open(f"{sessions_dir}/sessions.json", 'w') as f:
        json.dump(sessions, f, indent=2)
    
    print(f"\n✅ 完成! 已备份到 {backup_dir}/")

if __name__ == "__main__":
    import sys
    days = int(sys.argv[1]) if len(sys.argv) > 1 else 14
    cleanup_cron_sessions(days)
