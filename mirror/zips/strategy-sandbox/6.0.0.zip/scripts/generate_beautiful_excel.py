#!/usr/bin/env python3
"""
策略沙盘Excel生成脚本 v6.0.0
支持：串联模板(8行) + 并联模板(11行) + 任意用户模板（任何xlsx文件）

★ 输出路径强制为桌面 /Users/wangzhongwei/Desktop/策略沙盘_已完成.xlsx ★

★ 用户模板长什么样就生成什么样，一分一毫都不动 ★

【v6.0.0 核心原则】：
1. 不拆任何原有合并，不加任何新合并
2. 策略内容按列头类别分门别类填入对应列（每个列独立填自己）
3. 自适应尺寸只调整列宽行高，不动合并结构
4. 策略行识别后，每个策略维度填入对应列，不重复、不合并
5. 输出前检查所有单元格内容完整性

用法：
  python3 generate_beautiful_excel.py --template custom \
    --data data.json --output out.xlsx --template-file 用户模板.xlsx
"""

import openpyxl
from openpyxl.styles import Font, Alignment, Border, Side
from openpyxl import load_workbook
import json, argparse, os, re

# 版本号 - 必须与SKILL.md中的版本号一致
__version__ = "6.0.0"

# 固定openpyxl版本，防止恶意包攻击
assert openpyxl.__version__ >= "3.0.0", f"openpyxl版本需要>=3.0.0，当前版本{openpyxl.__version__}"

def thick_border():
    s = Side(style='medium', color='000000')
    return Border(left=s, right=s, top=s, bottom=s)

def text_width(text):
    if not text: return 0
    return sum(2 if ord(ch) > 127 else 1 for ch in str(text))

def calc_lines(text, col_width_char=30):
    if not text: return 1
    total = 0
    for line in str(text).split('\n'):
        lw = text_width(line)
        total += max(1, (lw + col_width_char - 1) // col_width_char) if lw > 0 else 1
    return max(1, total)

def get_a_value(ws, row):
    v = ws.cell(row, 1).value
    return str(v).replace('\n', '').replace('\r', '').strip() if v else ''

def is_strategy_row(ws, row):
    return '策略' in get_a_value(ws, row)

def is_data_row(ws, row):
    a = get_a_value(ws, row)
    return any(kw in a for kw in ['完成', '目标', '指标', '上月', '本月'])

def clean_strat(raw):
    """逐行去掉中文编号①②③④前缀"""
    if not raw or str(raw) in ('?', 'None'): return None
    lines = str(raw).strip().split('\n')
    result = []
    for line in lines:
        c = re.sub(r'^[①②③④⑤⑥⑦⑧⑨⑩]\s*', '', line.strip())
        if c: result.append(c)
    return '\n'.join(result) if result else None

def make_block(raw):
    """
    将原始策略文本重新整理为清晰的1、2、3、4序号。
    原始数据每条带①②③④或①②③④⑤编号，整理后统一为1、2、3、4…
    每条之间用换行分隔。
    """
    if not raw or str(raw) in ('?', 'None'): return '持续优化运营'
    # 按换行分割，逐条去掉中文编号，重新编号
    lines = str(raw).strip().split('\n')
    result = []
    for i, line in enumerate(lines, 1):
        c = re.sub(r'^[①②③④⑤⑥⑦⑧⑨⑩]\s*', '', line.strip())
        if c: result.append(f"{i}、{c}")
    return '\n'.join(result) if result else '持续优化运营'

def re_number(text):
    """重新给文本编号为1、2、3、4"""
    if not text: return ''
    lines = text.split('\n')
    result = []
    for i, ln in enumerate(lines, 1):
        c = re.sub(r'^[①②③④⑤⑥⑦⑧⑨⑩]\s*', '', ln.strip())
        if c: result.append(f"{i}、{c}")
    return '\n'.join(result)

def write_cell(ws, row, col, value, bold=False, size=10, wrap=True, halign='center', red_bold=False):
    cell = ws.cell(row, col)
    cell.value = value if value is not None else ''
    cell.alignment = Alignment(wrap_text=wrap, vertical='center', horizontal=halign)
    cell.border = thick_border()
    if red_bold:
        cell.font = Font(bold=True, size=size, color='FF0000')
    else:
        cell.font = Font(bold=bold, size=size)


def check_content_completeness(data, template_type='series'):
    """
    检查数据完整性
    确保数字、策略和三要素都已完整填写
    """
    issues = []

    # 定义需要检查的维度
    if template_type == 'parallel':
        dims = ['老客业绩', '老客总数', '续签率', '老客均价',
                '新客业绩', '新客总数', '转化率', '新客均价',
                '业务总人数', '人效']
    else:
        dims = ['总业绩', '业务总人力', '人均触客数', '转化率', '客均件数', '件均单价', '心态']

    for dim in dims:
        dim_data = data.get(dim, {})

        # 检查数字数据
        for period in ['完成', '目标']:
            if not dim_data.get(period):
                issues.append(f"{dim} - {period}数字为空")

        # 检查策略
        if not dim_data.get('策略'):
            issues.append(f"{dim} - 策略为空")

        # 检查三要素
        if not dim_data.get('可衡量结果'):
            issues.append(f"{dim} - 可衡量结果为空")
        if not dim_data.get('负责人'):
            issues.append(f"{dim} - 负责人为空")
        if not dim_data.get('截止日'):
            issues.append(f"{dim} - 截止日为空")

    if issues:
        print(f"  ⚠️ 发现{len(issues)}个空值，将使用参考策略和三要素填充")
        for issue in issues[:5]:  # 只显示前5个
            print(f"     - {issue}")

    return len(issues) == 0


def fill_missing_with_reference(data, template_type='series'):
    """
    用参考策略和三要素填充空缺的内容
    """
    if template_type == 'parallel':
        ref_strategies = {
            '老客业绩': '1、客户数量提升：把所有老客户数量增长10%，这是最直接的业绩增长方式\n2、客单价提升：给老客户推荐更贵的套餐或新产品，单笔消费增加\n3、产品组合销售：设计套餐产品，让客户一次买更多\n4、促销激励政策：设置续签优惠，让客户觉得续费划算\n5、激活沉睡客户：把长期没成交的老客户筛选出来，专门做激活活动',
            '老客总数': '1、定期回访老客户：通过定期电话或上门维护客情关系\n2、推荐新客户：鼓励老客户转介绍新客户\n3、提供增值服务：通过服务增加客户粘性\n4、建立客户积分体系：通过积分激励客户持续消费\n5、举办客户活动：通过线下活动增强客户归属感',
            '续签率': '1、优化产品服务：提升客户满意度\n2、建立续签提醒机制：提前3个月开始跟进\n3、提供续签优惠：设置阶梯式续签折扣\n4、定期客户回访：了解客户需求变化\n5、解决客户问题：及时处理客户投诉和反馈',
            '老客均价': '1、推荐高价值产品：引导客户购买高端产品\n2、套餐设计：设计多档位套餐让客户选择\n3、增值服务包：提供额外服务增加单笔消费\n4、促销升级：设置满减活动鼓励消费升级\n5、客户分级管理：针对高价值客户提供专属服务',
            '新客业绩': '1、加大市场推广：通过多渠道获取新客户\n2、优化转化流程：提升从触达到成交的转化率\n3、拓展获客渠道：开发新的获客来源\n4、提升品牌知名度：通过宣传吸引潜在客户\n5、优惠活动吸引：通过首单优惠吸引新客户',
            '新客总数': '1、线上推广：投流、SEO、社交媒体\n2、线下活动：展会、会议营销、地推\n3、转介绍激励：设置老带新奖励机制\n4、合作渠道：与异业合作伙伴互相引流\n5、内容营销：通过文章视频吸引潜在客户',
            '转化率': '1、优化销售话术：提升沟通技巧\n2、完善产品演示：让客户更了解产品价值\n3、处理价格异议：提供多种付款方案\n4、建立信任感：通过案例和资质展示专业性\n5、快速响应：及时跟进客户需求',
            '新客均价': '1、价值塑造：通过案例展示产品价值\n2、套餐推荐：引导客户选择更高价值的方案\n3、限时优惠：设置紧迫感促使客户下单\n4、组合销售：推荐关联产品增加客单价\n5、VIP服务：提供专属服务吸引高价值客户',
            '业务总人数': '1、优化招聘渠道：多平台发布招聘信息\n2、提升面试效率：快速筛选合适候选人\n3、加强培训：缩短新员工上手时间\n4、激励团队：设置绩效奖励激发积极性\n5、留存关怀：关注员工满意度降低离职率',
            '人效': '1、聚焦高价值客户：把时间花在更有价值的客户身上\n2、优化工作流程：减少无效劳动\n3、技能培训：提升员工专业能力\n4、工具赋能：提供高效的办公工具\n5、目标管理：设定清晰的业绩目标'
        }
        ref_three_elements = {
            '可衡量结果': '1、老客业绩提升X%\n2、成交客户数增加X个\n3、平均客单价提升X%\n4、续签率提升X%\n5、激活沉睡客户X个',
            '负责人': '1、销售部门\n2、分公司总经理\n3、产品部\n4、市场部\n5、客服部',
            '截止日': '1、2026-12-31\n2、2026-06-30\n3、2026-09-30\n4、2026-08-31\n5、2026-10-31'
        }
    else:
        ref_strategies = {
            '总业绩': '1、扩大市场份额：通过多渠道获取新客户\n2、提升转化率：优化销售流程\n3、增加客单价：推荐高价值产品\n4、维护老客：提升续签率\n5、优化产品结构：聚焦高利润产品',
            '业务总人力': '1、优化招聘流程：快速补充人才\n2、加强培训体系：提升员工能力\n3、激励机制：设置绩效奖励\n4、团队文化建设：增强凝聚力\n5、留存关怀：降低离职率',
            '人均触客数': '1、优化客户分配：确保资源合理配置\n2、提升触客效率：减少无效沟通\n3、使用工具赋能：借助CRM系统\n4、目标管理：设定每日触客目标\n5、时间管理培训：提升工作效率',
            '转化率': '1、销售技能培训：提升沟通能力\n2、优化产品演示：增强产品说服力\n3、价格策略调整：提供多种方案选择\n4、建立信任：通过案例展示专业性\n5、快速跟进：及时响应客户需求',
            '客均件数': '1、关联销售：推荐配套产品\n2、套餐设计：设计多件优惠\n3、促销活动：设置多买多送\n4、VIP服务：提供专属权益\n5、客户升级引导：推荐高端产品',
            '件均单价': '1、价值塑造：强调产品独特价值\n2、组合销售：推荐高价值组合\n3、限时优惠：设置紧迫感\n4、客户分级：针对高价值客户提供专属方案\n5、服务增值：提供额外服务提升感知价值',
            '心态': '1、定期团建：增强团队凝聚力\n2、目标激励：设置清晰业绩目标\n3、荣誉表彰：表彰优秀员工\n4、培训提升：提供成长机会\n5、管理沟通：定期一对一沟通'
        }
        ref_three_elements = {
            '可衡量结果': '1、各项指标提升X%\n2、团队稳定性提升\n3、工作效率提升X%\n4、客户满意度提升\n5、业绩增长X%',
            '负责人': '1、销售负责人\n2、人力资源\n3、业务负责人\n4、客服负责人\n5、管理层',
            '截止日': '1、2026-12-31\n2、2026-06-30\n3、2026-09-30\n4、2026-08-31\n5、2026-10-31'
        }

    # 填充空缺的策略和三要素
    for dim in ref_strategies:
        if dim not in data:
            data[dim] = {}

        # 如果策略为空，使用参考策略
        if not data[dim].get('策略'):
            data[dim]['策略'] = ref_strategies.get(dim, '持续优化运营')

        # 如果三要素为空，使用参考三要素
        for key in ['可衡量结果', '负责人', '截止日']:
            if not data[dim].get(key):
                data[dim][key] = ref_three_elements.get(key, '')

    return data


# ============ 固定模板填充（内置串联+并联）============

def fill_fixed_template(ws, data, template_type='series'):
    # 获取时间标签，如果没有则使用默认值
    time_labels = data.get('time_labels', ['去年完成', '今年目标'])
    # 提取时间前缀，例如"上月完成" -> "上月"
    import re
    time_prefix = []
    for label in time_labels:
        # 匹配中文前缀，如"上月"、"上季"、"上年"、"去年"等
        m = re.match(r'([上下本去今][月季半年]?)', label)
        if m:
            time_prefix.append(m.group(1))
        else:
            # 回退：取前两个字符
            time_prefix.append(label[:2])
    # 确保有两个前缀
    if len(time_prefix) < 2:
        time_prefix = ['去年', '今年']

    if template_type == 'parallel':
        tmpl = {1:{"A":"维度","B":time_labels[0],"C":time_labels[1],"D":"行动策略","E":"可衡量结果","F":"负责人","G":"截止日"},
                2:{"A":"老客业绩"},3:{"A":"老客总数"},4:{"A":"续签率"},5:{"A":"老客均价"},
                6:{"A":"新客业绩"},7:{"A":"新客总数"},8:{"A":"转化率"},9:{"A":"新客均价"},
                10:{"A":"业务总人数"},11:{"A":"人效"}}
        COL_W = {'A':14,'B':22,'C':22,'D':55,'E':40,'F':14,'G':14}
        rows = 11
    else:
        tmpl = {1:{"A":"维度","B":time_labels[0]+"(R)","C":time_labels[1]+"(O)","D":"行动策略(KR)","E":"可衡量结果(KR)","F":"负责人(O)","G":"截止日(D)"},
                2:{"A":"总业绩"},3:{"A":"业务总人力"},4:{"A":"人均触客数"},
                5:{"A":"转化率"},6:{"A":"客均件数"},7:{"A":"件均单价"},8:{"A":"心态"}}
        COL_W = {'A':12,'B':22,'C':28,'D':55,'E':40,'F':14,'G':14}
        rows = 8

    ws.row_dimensions[1].height = 35
    for col_letter, text in tmpl[1].items():
        col_idx = ord(col_letter) - 64
        write_cell(ws, 1, col_idx, text, bold=True, size=11)

    highlighted = data.get('重点维度', [])
    for row_num in range(2, rows + 1):
        dim = tmpl[row_num].get("A","")
        is_highlighted = dim in highlighted
        row_h = 35
        for col_letter, _ in tmpl[1].items():
            col_idx = ord(col_letter) - 64
            if col_idx == 1:
                write_cell(ws, row_num, 1, dim, bold=True, size=11, red_bold=is_highlighted)
            else:
                cell_val = ''
                # B/C列数字（col_idx 2=去年/上月，3=今年/本月）
                if col_idx == 2:
                    cell_val = data.get(dim, {}).get(time_prefix[0], '')
                elif col_idx == 3:
                    cell_val = data.get(dim, {}).get(time_prefix[1], '')
                # 策略/可衡量/负责人/截止日（col_idx 4-7）
                elif col_idx == 4:
                    cell_val = make_block(data.get(dim, {}).get('策略', ''))
                    if cell_val:
                        lines = calc_lines(str(cell_val), COL_W.get(col_letter, 30))
                        row_h = max(50, lines * 18 + 15)
                elif col_idx == 5:
                    cell_val = data.get(dim, {}).get('可衡量结果', '')
                    cell_val = re_number(cell_val)  # 格式化序号
                elif col_idx == 6:
                    cell_val = data.get(dim, {}).get('负责人', '')
                    cell_val = re_number(cell_val)  # 格式化序号
                elif col_idx == 7:
                    cell_val = data.get(dim, {}).get('截止日', '')
                    cell_val = re_number(cell_val)  # 格式化序号
                halign = 'left' if col_idx in [4, 5] else 'center'
                write_cell(ws, row_num, col_idx, cell_val,
                           bold=False, size=10, wrap=True, halign=halign,
                           red_bold=is_highlighted and col_idx in [1, 4])
        ws.row_dimensions[row_num].height = row_h

    for col, w in COL_W.items():
        ws.column_dimensions[col].width = w
    ws.freeze_panes = 'B2'


# ============ 用兵沙盘模板（v6.0.0核心·硬编码列头映射）============

YONGBING_COL_MAP = {
    # 列索引 -> (列头标签, 数据key, 数据subkey_pattern)
    # 板块行（第3行）定义：B:E=老客  F:I=新客  J=人数  K=人效
    # 指标行（第4行）定义：B=业绩  C=客户数  D=续签率  E=均价
    #                   F=业绩  G=客户数  H=转化率  I=均价
    2: {'label': '业绩(B-E老客/F-I新客)', 'data_key': None, 'note': 'B2:E2=E列老客(业绩+客户数+续签率+均价)'},
    3: {'label': '客户数', 'data_key': None},
    4: {'label': '续签率', 'data_key': None},
    5: {'label': '均价', 'data_key': None},
    6: {'label': '业绩', 'data_key': None},
    7: {'label': '客户数', 'data_key': None},
    8: {'label': '转化率', 'data_key': None},
    9: {'label': '均价', 'data_key': None},
    10: {'label': '人数', 'data_key': None},
    11: {'label': '人效', 'data_key': None},
}

def fill_yongbing_template(ws, data):
    """
    【用兵沙盘模板专用填充】

    模板列头（第4行）：
      B=业绩(老客) C=客户数(老客) D=续签率(老客) E=均价(老客)
      F=业绩(新客) G=客户数(新客) H=转化率(新客) I=均价(新客)
      J=人数  K=人效

    策略行（第6、8行）：
      B~E列 = 老客户策略（分别对应：业绩/客户数/续签率/均价的策略）
      F~I列 = 新客户策略（分别对应：业绩/客户数/转化率/均价的策略）
      J列 = 人数策略，K列 = 人效策略

    【核心原则】：每个列独立填自己的内容，不重复、不合并。
    """
    max_row = ws.max_row
    max_col = ws.max_column

    print(f"  📐 用兵沙盘模板：{max_row}行×{max_col}列")
    print(f"  🔒 原有合并（不动）: {[m.coord for m in ws.merged_cells.ranges]}")

    # 识别行类型
    strategy_rows = [r for r in range(1, max_row + 1) if is_strategy_row(ws, r)]
    all_data_rows = [r for r in range(1, max_row + 1) if is_data_row(ws, r)]
    data_rows = [r for r in all_data_rows if r not in strategy_rows]
    print(f"  📋 策略行: {strategy_rows}, 数字行: {data_rows}")

    # 解析数据
    def get(key, subkey=''):
        if subkey:
            return str(data.get(key, {}).get(subkey, '') or '')
        return str(data.get(key, '') or '')

    # 获取时间标签，如果没有则使用默认值
    time_labels = data.get('time_labels', ['去年完成', '今年目标'])
    # 提取时间前缀，例如"上月完成" -> "上月"
    import re
    time_prefix = []
    for label in time_labels:
        m = re.match(r'([上下本去今][月季半年]?)', label)
        if m:
            time_prefix.append(m.group(1))
        else:
            time_prefix.append(label[:2])
    # 确保有两个前缀
    if len(time_prefix) < 2:
        time_prefix = ['去年', '今年']

    # 构建映射：模板中的文本关键词 -> 数据键前缀
    # 模板中可能包含"上月"、"完成"、"本月"、"目标"等关键词
    # 我们根据时间标签的第一个标签判断"完成"时期，第二个标签判断"目标"时期
    period_map = {}
    # 判断第一个标签是否包含"完成"
    if '完成' in time_labels[0]:
        period_map['完成'] = time_prefix[0]
    # 判断第二个标签是否包含"目标"
    if '目标' in time_labels[1]:
        period_map['目标'] = time_prefix[1]
    # 如果没有明确的"完成"/"目标"，则使用默认映射
    if not period_map.get('完成'):
        period_map['完成'] = time_prefix[0]
    if not period_map.get('目标'):
        period_map['目标'] = time_prefix[1]

    # 数字行数据（第5行=上月，第7行=本月）
    def fill_data_row(row_num, period_key):
        fills = {
            2: get('老客业绩', period_key),    # B=老客业绩
            3: get('老客总数', period_key),    # C=老客总数
            4: get('续签率', period_key),      # D=续签率
            5: get('老客均价', period_key),    # E=老客均价
            6: get('新客业绩', period_key),    # F=新客业绩
            7: get('新客户数', period_key),    # G=新客客户数
            8: get('转化率', period_key),      # H=转化率
            9: get('新客均价', period_key),   # I=新客均价
            10: get('业务总人数', period_key) or '根据实际情况填写',
            11: get('人效', period_key) or '根据实际情况填写',
        }
        for col_idx, val in fills.items():
            write_cell(ws, row_num, col_idx, val, bold=False, size=10, wrap=True, halign='center')

    # 判断数字行的时期（"上月\n完成"=去年，"本月\n目标"=今年）
    for row_num in data_rows:
        a = get_a_value(ws, row_num)
        # 根据映射判断时期
        if '完成' in a or period_map['完成'] in a:
            fill_data_row(row_num, period_map['完成'])
        elif '目标' in a or period_map['目标'] in a:
            fill_data_row(row_num, period_map['目标'])
        else:
            # 回退逻辑
            if '上月' in a:
                fill_data_row(row_num, time_prefix[0])
            elif '本月' in a:
                fill_data_row(row_num, time_prefix[1])
            else:
                # 默认填充第一个时期
                fill_data_row(row_num, time_prefix[0])

    # 策略行数据（按列头类别分填，每个列用 make_block 整理成1、2、3序号）
    # 每条原始策略带①②③④编号 → make_block 去掉中文编号 → 重新标为1、2、3、4
    # 最终效果：每条策略前有清晰的 1、2、3、4 序号，每条换行显示
    strat_by_col = {
        2:  make_block(get('老客业绩', '策略')),
        3:  make_block(get('老客总数', '策略')),
        4:  make_block(get('续签率', '策略')),
        5:  make_block(get('老客均价', '策略')),
        6:  make_block(get('新客业绩', '策略')),
        7:  make_block(get('新客总数', '策略')),
        8:  make_block(get('转化率', '策略')),
        9:  make_block(get('新客均价', '策略')),
        10: make_block(get('人数', '策略')) or '稳定团队，持续提升人效',
        11: make_block(get('人效', '策略')) or '优化结构，聚焦高价值客户',
    }

    print(f"\n  📝 各列策略内容预览:")
    col_labels = {2:'B=老客业绩', 3:'C=客户数', 4:'D=续签率', 5:'E=均价',
                  6:'F=新客业绩', 7:'G=客户数', 8:'H=转化率', 9:'I=均价', 10:'J=人数', 11:'K=人效'}
    for col_idx, content in strat_by_col.items():
        print(f"    列{chr(64+col_idx)}({col_labels.get(col_idx,'')}): {str(content)[:40] if content else '空'}")

    # 策略行填充（每个列只写自己，不重复）
    for row_num in strategy_rows:
        a = get_a_value(ws, row_num)
        for col_idx, content in strat_by_col.items():
            if content:
                write_cell(ws, row_num, col_idx, content, bold=False, size=10, wrap=True, halign='left')

    # 自适应尺寸（不动任何合并）
    print(f"\n  📏 应用自适应列宽行高...")
    for col_i in range(1, max_col + 1):
        col_l = chr(64 + col_i)
        orig = ws.column_dimensions[col_l].width
        if orig is None or orig < 5: orig = 12
        max_c = max(text_width(str(ws.cell(r, col_i).value or '')) for r in range(1, max_row + 1))
        if max_c > 50:
            new_w = max(orig, min(max_c / 2.0, 40))
        elif max_c > 30:
            new_w = max(orig, min(max_c / 2.0, 30))
        else:
            new_w = max(orig, min(max_c / 2.0, 20))
        ws.column_dimensions[col_l].width = new_w

    for row_num in range(1, max_row + 1):
        orig_h = ws.row_dimensions[row_num].height
        if orig_h is None or orig_h < 10: orig_h = 30
        max_l = 1
        for col_i in range(1, max_col + 1):
            v = ws.cell(row_num, col_i).value
            if v:
                cw = ws.column_dimensions[chr(64 + col_i)].width or 15
                lines = calc_lines(str(v), int(cw))
                max_l = max(max_l, lines)
        if is_strategy_row(ws, row_num):
            new_h = min(max(orig_h, max_l * 15 + 30), 400)
        else:
            new_h = min(max(orig_h, max_l * 15 + 15), 400)
        ws.row_dimensions[row_num].height = new_h

    print(f"  🔒 合并单元格（未动）: {[m.coord for m in ws.merged_cells.ranges]}")
    ws.freeze_panes = 'A5'
    print(f"  ✅ 用兵沙盘模板填充完成")


# ============ 通用自定义模板填充 ============

def fill_generic_custom_template(ws, data):
    """通用自定义模板：读取列头，按类别匹配数据填入"""
    max_row = ws.max_row
    max_col = ws.max_column

    # 建立列头映射（第1行或含"维度"的行）
    header_row = 1
    for row in range(1, max_row + 1):
        if '维度' in get_a_value(ws, row) or '指标' in get_a_value(ws, row):
            header_row = row; break

    # 列头：col_idx -> label（直接从单元格读，合并格读取左上格）
    col_headers = {}
    for col in range(1, max_col + 1):
        v = ws.cell(header_row, col).value
        if v: col_headers[col] = str(v)

    print(f"  📐 通用模板：表头行={header_row}，{max_row}行×{max_col}列")
    print(f"  📊 列头: {col_headers}")

    strategy_rows = [r for r in range(1, max_row + 1) if is_strategy_row(ws, r)]
    all_data_rows = [r for r in range(1, max_row + 1) if is_data_row(ws, r)]
    data_rows = [r for r in all_data_rows if r not in strategy_rows]

    # 获取时间标签，如果没有则使用默认值
    time_labels = data.get('time_labels', ['去年完成', '今年目标'])
    # 提取时间前缀，例如"上月完成" -> "上月"
    import re
    time_prefix = []
    for label in time_labels:
        m = re.match(r'([上下本去今][月季半年]?)', label)
        if m:
            time_prefix.append(m.group(1))
        else:
            time_prefix.append(label[:2])
    # 确保有两个前缀
    if len(time_prefix) < 2:
        time_prefix = ['去年', '今年']

    # 构建映射：模板中的关键词 -> 数据键前缀
    # 默认映射：'完成' -> 第一个前缀，'目标' -> 第二个前缀
    period_map = {}
    if '完成' in time_labels[0]:
        period_map['完成'] = time_prefix[0]
    if '目标' in time_labels[1]:
        period_map['目标'] = time_prefix[1]
    if not period_map.get('完成'):
        period_map['完成'] = time_prefix[0]
    if not period_map.get('目标'):
        period_map['目标'] = time_prefix[1]

    # 数字行填充
    for row_num in data_rows:
        a = get_a_value(ws, row_num)
        # 判断时期
        period = period_map['完成']  # 默认
        if '完成' in a or period_map['完成'] in a:
            period = period_map['完成']
        elif '目标' in a or period_map['目标'] in a:
            period = period_map['目标']
        else:
            # 回退逻辑
            if '上月' in a:
                period = time_prefix[0]
            elif '本月' in a:
                period = time_prefix[1]
            # 否则保持默认

        for col_idx in range(2, max_col + 1):
            header = col_headers.get(col_idx, '')
            val = ''
            for dim_key, subkeys in [
                ('老客业绩', ['去年', '今年']), ('新客业绩', ['去年', '今年']),
                ('老客总数', ['去年', '今年']), ('老客成交数', ['去年', '今年']),
                ('新客总数', ['去年', '今年']), ('新客成交数', ['去年', '今年']),
                ('续签率', ['去年', '今年']), ('转化率', ['去年', '今年']),
                ('老客均价', ['去年', '今年']), ('新客均价', ['去年', '今年']),
                ('业务总人数', ['去年', '今年']), ('总业绩', ['去年', '今年']),
            ]:
                if any(kw in header for kw in [dim_key[:2]]):
                    # 将默认的'去年'/'今年'替换为实际的时间前缀
                    # 这里subkeys列表是固定的，我们需要映射到正确的前缀
                    # 简单方案：根据period选择对应的键
                    # 但数据中可能使用不同的键名，我们需要从data中查找
                    # 先尝试直接使用dim_key和period
                    val = data.get(dim_key, {}).get(period, '')
                    if not val:
                        # 回退：尝试使用'去年'/'今年'
                        fallback_period = '去年' if period == time_prefix[0] else '今年'
                        val = data.get(dim_key, {}).get(fallback_period, '')
                    break
            if val:
                write_cell(ws, row_num, col_idx, val, bold=False, size=10, wrap=True, halign='center')

    # 策略行填充（按列头匹配策略key）
    for row_num in strategy_rows:
        for col_idx in range(2, max_col + 1):
            header = col_headers.get(col_idx, '')
            val = ''
            for dim_key in ['老客业绩','新客业绩','老客总数','新客总数',
                            '老客成交数','新客成交数',
                            '续签率','转化率','老客均价','新客均价',
                            '业务总人数','总业绩']:
                if any(kw in header for kw in [dim_key[:2]]):
                    val = data.get(dim_key, {}).get('策略', ''); break
            if not val and '人数' in header:
                val = data.get('人数', {}).get('策略', '') or '稳定团队，持续提升'
            if not val and '人效' in header:
                val = data.get('人效', {}).get('策略', '') or '优化结构，聚焦高价值'

            if val:
                cleaned = re_number(clean_strat(val) or '')
                write_cell(ws, row_num, col_idx, cleaned, bold=False, size=10, wrap=True, halign='left')

    # 自适应尺寸
    for col_i in range(1, max_col + 1):
        col_l = chr(64 + col_i)
        orig = ws.column_dimensions[col_l].width or 12
        max_c = max(text_width(str(ws.cell(r, col_i).value or '')) for r in range(1, max_row + 1))
        new_w = max(orig, min(max_c / 2.0, 40 if max_c > 50 else 30 if max_c > 30 else 20))
        ws.column_dimensions[col_l].width = new_w

    for row_num in range(1, max_row + 1):
        orig_h = ws.row_dimensions[row_num].height or 30
        max_l = max((calc_lines(str(ws.cell(row_num, c).value or ''),
                     int(ws.column_dimensions[chr(64+c)].width or 15))
                     for c in range(1, max_col + 1)), default=1)
        new_h = min(max(orig_h, max_l * 15 + 30), 400)
        ws.row_dimensions[row_num].height = new_h

    print(f"  ✅ 通用自定义模板填充完成")


# ============ 主函数 ============

def create_sandbox_excel(data: dict, output_path: str,
                         template: str = "series",
                         user_template_path: str = None):
    """
    生成策略沙盘Excel文件

    参数:
        data: 字典，包含业务流程和每个环节的量、技能、心态信息
        output_path: 输出文件路径
        template: 模板类型（series/parallel/custom）
        user_template_path: 用户自定义模板路径

    输出前检查:
        - 所有数字数据都已填写
        - 所有策略内容都已填写
        - 所有三要素都已填写
    """
    print(f"  📋 v6.0.0 开始生成策略沙盘...")

    # 检查内容完整性
    print(f"  🔍 检查内容完整性...")
    is_complete = check_content_completeness(data, template)

    # 如果不完整，用参考策略和三要素填充
    if not is_complete:
        print(f"  🔧 填充空缺内容...")
        data = fill_missing_with_reference(data, template)

    if user_template_path and os.path.exists(user_template_path):
        print(f"  📂 加载用户模板：{user_template_path}")
        wb = load_workbook(user_template_path)
        ws = wb.active
        print(f"  📐 模板尺寸：{ws.max_row}行 × {ws.max_column}列")
        print(f"  🔒 原有合并：{[m.coord for m in ws.merged_cells.ranges]}")

        # 判断是否为用兵沙盘模板（有第4行列头：B=业绩 C=客户数...）
        is_yongbing = False
        row4_labels = [ws.cell(4, c).value for c in range(2, 12)]
        if row4_labels[0] and '业绩' in str(row4_labels[0]):
            is_yongbing = True

        if is_yongbing:
            print(f"  🔍 检测到用兵沙盘模板（列头：B=业绩 C=客户数 D=续签率 E=均价...）")
            fill_yongbing_template(ws, data)
        else:
            fill_generic_custom_template(ws, data)
        rows_info = "自定义模板"
    else:
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "策略沙盘"
        fill_fixed_template(ws, data, template)
        rows_info = f"{'并联' if template=='parallel' else '串联'}模板"

    wb.save(output_path)
    print(f"✅ 策略沙盘已生成（{rows_info}）：{output_path}")
    print(f"   版本：v6.0.0")


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="生成策略沙盘Excel v6.0.0")
    p.add_argument("--template", default="series", choices=["series","parallel","custom"])
    p.add_argument("--data", required=True, help="JSON数据文件路径")
    p.add_argument("--output", required=True, help="输出Excel路径")
    p.add_argument("--template-file", default=None, help="用户自定义模板")
    p.add_argument("--version", action="store_true", help="显示版本号")
    a = p.parse_args()

    if a.version:
        print(f"策略沙盘Excel生成脚本 v{__version__}")
        exit(0)

    with open(a.data, 'r', encoding='utf-8') as f:
        data = json.load(f)
    create_sandbox_excel(data, a.output, a.template, a.template_file)