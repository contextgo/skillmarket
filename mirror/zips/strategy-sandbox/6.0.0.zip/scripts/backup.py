#!/usr/bin/env python3
"""
wzwcelue技能备份脚本 v6.0.0
每次更新技能后，运行此脚本创建备份压缩包到桌面
"""

import os
import zipfile

# 版本号 - 必须与SKILL.md和generate_beautiful_excel.py中的版本号一致
__version__ = "6.0.0"

# 路径配置
SKILL_DIR = "/Users/wangzhongwei/.claude/skills/wzwcelue"
DESKTOP_PATH = "/Users/wangzhongwei/Desktop"

def create_backup():
    """创建技能备份压缩包"""

    # 备份文件名
    backup_name = f"wzwcelue_v{__version__}.zip"
    backup_path = os.path.join(DESKTOP_PATH, backup_name)

    # 创建压缩包
    with zipfile.ZipFile(backup_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(SKILL_DIR):
            # 跳过 .git 目录
            if '.git' in root:
                continue
            for file in files:
                file_path = os.path.join(root, file)
                # 压缩时保持目录结构
                arcname = os.path.relpath(file_path, os.path.dirname(SKILL_DIR))
                zipf.write(file_path, arcname)

    print(f"备份已创建: {backup_path}")
    return backup_path


if __name__ == "__main__":
    create_backup()