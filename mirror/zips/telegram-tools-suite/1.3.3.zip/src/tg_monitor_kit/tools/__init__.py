"""One-off Telegram utilities."""
