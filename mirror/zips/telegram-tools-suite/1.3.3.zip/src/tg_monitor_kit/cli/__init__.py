"""CLI entrypoint."""
