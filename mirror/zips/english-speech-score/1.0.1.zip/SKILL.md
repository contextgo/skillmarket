---
name: english-speech-score
description: |
  英语口语音频评测服务。
  适用场景：英语口语评分、朗读评测、发音纠正、音频打分等。
  使用方式：提供标准文本和音频（URL 或文件），即可获取总分及单词、音素级别的评分结果。
  快速体验：对 音频 https://wecome.oss-cn-shenzhen.aliyuncs.com/test/helloworld.mp3，文本 "hello world" 进行评测。
---

# English Speech Score

## Overview

英语口语音频评测技能，通过调用远程评测服务对英语口语音频进行自动评分。提供标准文本和音频文件，返回总得分及单词/音素级别的详细评分信息。

## API Endpoint

**正式环境地址：** `https://api.yingyutingshuo.com/open/api/v1/score/evaluate`

**请求方式：** `POST` (multipart/form-data)

## Parameters

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| target_text | string | 是 | 标准文本，评测的参考文本 |
| audio_url | string | 否 | 音频文件网络地址（与 audio_file 二选一） |
| audio_file | file | 否 | 音频文件二进制上传（与 audio_url 二选一） |
| mode | string | 否 | 评测模式，默认 A |

### Mode 说明

| Mode | 说明 |
|------|------|
A - 单词和句子，默认
D - 含音素详情
C - 篇章

## Response Format

```json
{
  "ret": 0,
  "msg": "success",
  "data": {
    "score": 88.66,
    "lines": [
      {
        "sample": "hello world",
        "usertext": "hello world",
        "score": 88.66,  # 总得分
        "fluency": 91.87,       # 流利度得分
        "integrity": 100,       # 完整度得分
        "pronunciation": 88.56, # 发音得分
        "words": [
          {
            "text": "hello",
            "score": 9.0,
            "subwords": [
              {"subtext": "h", "score": 8.5},
              {"subtext": "ə", "score": 9.2},
              {"subtext": "l", "score": 9.0},
              {"subtext": "oʊ", "score": 8.8}
            ]
          },
          {
            "text": "world",
            "score": 8.5,
            "subwords": [
              {"subtext": "w", "score": 8.0},
              {"subtext": "ɜː", "score": 8.7},
              {"subtext": "l", "score": 8.5},
              {"subtext": "d", "score": 8.3}
            ]
          }
        ]
      }
    ],
    "session_id": "xxx"
  }
}
```

## How to Call

### 方式一：音频 URL

```bash
curl -X POST https://api.yingyutingshuo.com/open/api/v1/score/evaluate \
  -F "target_text=hello world" \
  -F "audio_url=https://example.com/audio.mp3"
```

### 方式二：音频文件上传

```bash
curl -X POST https://api.yingyutingshuo.com/open/api/v1/score/evaluate \
  -F "target_text=hello world" \
  -F "audio_file=@./test.mp3"
```

### 指定评测模式

```bash
curl -X POST https://api.yingyutingshuo.com/open/api/v1/score/evaluate \
  -F "target_text=hello world" \
  -F "mode=D" \
  -F "audio_file=@./test.mp3"
```

## Workflow

1. 确定用户需求：是否需要对英语口语音频进行评分
2. 获取必要参数：标准文本（target_text）和音频来源（URL 或文件）
3. 根据音频来源选择调用方式（audio_url 或 audio_file）
4. 根据用户需求选择合适的 mode（默认A-单词和句子，需要音素详情选 D，篇章选 C）
5. 发送 POST 请求到 API endpoint
6. 解析返回结果，向用户呈现总分和各维度得分

## Notes

- audio_url 和 audio_file 必须且只能提供一个，不能同时提供
- 音频格式支持 mp3/wav/pcm/silk/opus/amrnb/speex，推荐 mp3（16K 采样率，64kbps 比特率）
- mp3 音频不能含有 tag 信息，不支持双声道
- 若 ret != 0 表示调用出错，查看 msg 了解原因
