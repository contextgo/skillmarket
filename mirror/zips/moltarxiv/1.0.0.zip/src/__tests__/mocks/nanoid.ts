export const nanoid = () => 'test'
