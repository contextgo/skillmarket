#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Project Context Manager - Python Implementation"""
import hashlib, json, os, re, sys, io

# Fix Windows console encoding
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List

class Utils:
    COLOR_RESET, COLOR_RED, COLOR_GREEN = "\033[0m", "\033[31m", "\033[32m"
    COLOR_YELLOW, COLOR_BLUE, COLOR_CYAN = "\033[33m", "\033[34m", "\033[36m"
    _log_level = 1
    
    @classmethod
    def log(cls, level: str, message: str) -> None:
        colors = {"DEBUG": cls.COLOR_CYAN, "INFO": cls.COLOR_GREEN, "WARN": cls.COLOR_YELLOW, "ERROR": cls.COLOR_RED}
        color = colors.get(level, cls.COLOR_RESET)
        print(f"{color}[project-context] {level}: {message}{cls.COLOR_RESET}", file=sys.stderr)
    
    @staticmethod
    def safe_read(fp: Path, default: str = "") -> str:
        return fp.read_text(encoding='utf-8') if fp.exists() else default
    
    @staticmethod
    def ensure_dir(dp: Path) -> None:
        dp.mkdir(parents=True, exist_ok=True)
    
    @staticmethod
    def get_timestamp() -> str:
        return datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
    
    @staticmethod
    def get_date() -> str:
        return datetime.now().strftime("%Y-%m-%d")
    
    @staticmethod
    def compute_hash(s: str) -> str:
        return hashlib.sha256(s.encode('utf-8')).hexdigest()
    
    @staticmethod
    def compute_fingerprint(content: str) -> str:
        if not content: return ""
        normalized = re.sub(r'[ \t]+', ' ', content).replace('\r\n', '\n').replace('\r', '\n')
        return hashlib.sha256(normalized.encode('utf-8')).hexdigest()
    
    @staticmethod
    def detect_language(content: str) -> str:
        if not content: return "unknown"
        chinese = len(re.findall(r'[\u4e00-\u9fff]', content))
        return "zh" if chinese / len(content) > 0.1 else "en"
    
    @staticmethod
    def format_size(size: int) -> str:
        return f"{size}B" if size < 1024 else f"{size/1024:.1f}KB" if size < 1048576 else f"{size/1048576:.1f}MB"


class SecurityManager:
    PATTERNS = [
        {"type": "password", "pattern": r"(?i)(password|pwd|passwd|密码)\s*[:=]\s*\S+", "desc": "密码"},
        {"type": "api_key", "pattern": r"(?i)(api[_-]?key|apikey|secret[_-]?key|token)\s*[:=]\s*[a-zA-Z0-9_-]{16,}", "desc": "API密钥"},
        {"type": "private_key", "pattern": r"-----BEGIN (RSA |DSA |EC |OPENSSH )?PRIVATE KEY-----", "desc": "私钥"},
        {"type": "email", "pattern": r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b", "desc": "邮箱"},
    ]
    
    def __init__(self, data_dir: Path):
        self.data_dir = data_dir
        self.audit_dir = data_dir / "audit"
        Utils.ensure_dir(self.audit_dir)
    
    def log_audit(self, event_type: str, details: Dict, ws_hash: str = "") -> None:
        today = Utils.get_date()
        audit_file = self.audit_dir / f"{today}.jsonl"
        entry = {"timestamp": Utils.get_timestamp(), "event_type": event_type, "workspace_hash": ws_hash, "details": details}
        with open(audit_file, 'a', encoding='utf-8') as f:
            f.write(json.dumps(entry, ensure_ascii=False) + '\n')
    
    def scan_sensitive(self, content: str) -> List[Dict]:
        findings = []
        for p in self.PATTERNS:
            matches = re.findall(p["pattern"], content)
            if matches:
                findings.append({"type": p["type"], "description": p["desc"], "count": len(matches), "masked": True})
        return findings
    
    def filter_sensitive(self, content: str) -> str:
        filtered = re.sub(r'(?i)(password|pwd|passwd|密码)\s*[:=]\s*\S+', r'\1: [REDACTED]', content)
        filtered = re.sub(r'(?i)(api[_-]?key|apikey|secret[_-]?key)\s*[:=]\s*[a-zA-Z0-9_-]{16,}', r'\1: [REDACTED]', filtered)
        filtered = re.sub(r'-----BEGIN.*?PRIVATE KEY-----.*?-----END.*?PRIVATE KEY-----', '[PRIVATE KEY REDACTED]', filtered, flags=re.DOTALL)
        return filtered


class CacheManager:
    def __init__(self, data_dir: Path):
        self.data_dir = data_dir
        self.workspace_hash = ""
        Utils.ensure_dir(self.data_dir)
    
    def init(self, workspace_path: str) -> bool:
        if not workspace_path:
            return False
        self.workspace_hash = Utils.compute_hash(workspace_path)[:16]
        Utils.ensure_dir(self.data_dir / self.workspace_hash / "versions")
        return True
    
    def get_path(self, ctype: str) -> Path:
        base = self.data_dir / self.workspace_hash
        paths = {"l1": base / "fingerprint.sha256", "l2": base / "summary.json", 
                 "l3": base / "project-context.md", "l4": base / "confirmed.json", "idx": self.data_dir / "index.json"}
        return paths.get(ctype, Path())
    
    def query(self, content: str, prev: str = "") -> Dict:
        if not self.workspace_hash:
            return {"error": "Not initialized"}
        fp = Utils.compute_fingerprint(content)
        l1_file = self.get_path("l1")
        if l1_file.exists() and l1_file.read_text(encoding='utf-8').strip() == fp:
            return {"level": 1, "status": "hit", "fingerprint": fp, "token_saving": 100}
        l3_file = self.get_path("l3")
        if l3_file.exists():
            return {"level": 3, "status": "hit", "fingerprint": fp, "token_saving": 70}
        return {"level": 0, "status": "miss", "fingerprint": fp, "token_saving": 0}
    
    def update(self, level: str, content: str, meta: str = "{}") -> None:
        paths = {"1": self.get_path("l1"), "2": self.get_path("l2"), "3": self.get_path("l3"), "4": self.get_path("l4")}
        if level in paths:
            if level == "1":
                content = Utils.compute_fingerprint(content)
            paths[level].write_text(content if level != "4" else meta, encoding='utf-8')


class ConversationAnalyzer:
    def analyze(self, content: str) -> Dict:
        if not content:
            return {"error": "No content"}
        entities = []
        for m in re.findall(r'(?i)(决定|决策|采用|选择|确定|结论|decided|decision)[^\n]{0,100}', content)[:10]:
            entities.append({"type": "decision", "text": m[:100]})
        for m in re.findall(r'(?i)(目标|目的|需要|goal|objective)[^\n]{0,100}', content)[:10]:
            entities.append({"type": "goal", "text": m[:100]})
        return {
            "entities": entities,
            "milestones": re.findall(r'(?i)(里程碑|阶段|完成|milestone|completed)[^\n]{0,150}', content)[:5],
            "todos": re.findall(r'(?i)(TODO|FIXME|待办|pending)[^\n]{0,100}', content)[:10],
            "language": Utils.detect_language(content),
            "analyzed_at": Utils.get_timestamp()
        }


class SummaryGenerator:
    DEFAULT_TEMPLATE = '''---
project_name: {{PROJECT_NAME}}
workspace_path: {{WORKSPACE_PATH}}
created: {{CREATED_AT}}
last_updated: {{UPDATED_AT}}
tags: {{TAGS}}
---

# Project Context: {{PROJECT_NAME}}

## Overview

**Project Goal**: {{PROJECT_GOAL}}

**Current Status**: {{CURRENT_STATUS}}

**Last Session**: {{LAST_SESSION_DATE}}

---

## Key Decisions

{{KEY_DECISIONS}}

---

## Open Items

{{OPEN_ITEMS}}

---

*Generated by Project Context Manager*
*Last Updated: {{UPDATED_AT}}*
'''
    
    def generate(self, analysis: Dict, workspace: str, project: str) -> str:
        goals = [e["text"] for e in analysis.get("entities", []) if e["type"] == "goal"][:3]
        decisions = [e["text"] for e in analysis.get("entities", []) if e["type"] == "decision"][:3]
        ts = Utils.get_timestamp()
        doc = self.DEFAULT_TEMPLATE
        doc = doc.replace("{{PROJECT_NAME}}", project)
        doc = doc.replace("{{WORKSPACE_PATH}}", workspace)
        doc = doc.replace("{{CREATED_AT}}", ts)
        doc = doc.replace("{{UPDATED_AT}}", ts)
        doc = doc.replace("{{TAGS}}", "[]")
        doc = doc.replace("{{PROJECT_GOAL}}", "; ".join(goals) if goals else "TBD")
        doc = doc.replace("{{CURRENT_STATUS}}", "In Progress")
        doc = doc.replace("{{LAST_SESSION_DATE}}", ts)
        doc = doc.replace("{{KEY_DECISIONS}}", "\n- ".join([""] + decisions) if decisions else "None yet")
        doc = doc.replace("{{OPEN_ITEMS}}", "- [ ] Define next steps")
        return doc


class TagManager:
    CATEGORIES = {
        "technology": ["react", "vue", "angular", "nodejs", "python", "go", "rust", "java", "typescript", "javascript"],
        "domain": ["frontend", "backend", "api", "database", "devops", "testing", "security"],
        "task_type": ["feature", "bugfix", "refactor", "docs", "research", "design", "planning"]
    }
    
    def __init__(self, data_dir: Path):
        self.data_dir = data_dir
        self.tag_file = data_dir / "tag-index.json"
    
    def init(self) -> None:
        if not self.tag_file.exists():
            self.tag_file.write_text(json.dumps({"version": "1.0.0", "tags": {}, "projects": {}}, ensure_ascii=False), encoding='utf-8')
    
    def suggest(self, content: str) -> List[str]:
        if not content:
            return []
        content_lower = content.lower()
        suggestions = []
        for tag in self.CATEGORIES["technology"]:
            if tag in content_lower and tag not in suggestions:
                suggestions.append(tag)
        return suggestions[:5]
    
    def add(self, ws_hash: str, project: str, tags: List[str]) -> None:
        self.init()
        data = json.loads(self.tag_file.read_text(encoding='utf-8'))
        if ws_hash not in data["projects"]:
            data["projects"][ws_hash] = {"name": project, "tags": []}
        for tag in tags:
            if tag not in data["projects"][ws_hash]["tags"]:
                data["projects"][ws_hash]["tags"].append(tag)
            if tag not in data["tags"]:
                data["tags"][tag] = {"count": 0, "projects": []}
            if ws_hash not in data["tags"][tag]["projects"]:
                data["tags"][tag]["projects"].append(ws_hash)
                data["tags"][tag]["count"] += 1
        self.tag_file.write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')
    
    def get(self, ws_hash: str) -> List[str]:
        self.init()
        data = json.loads(self.tag_file.read_text(encoding='utf-8'))
        return data["projects"].get(ws_hash, {}).get("tags", [])


class PCM:
    """Project Context Manager 主类"""
    
    def __init__(self):
        self.home = Path.home()
        self.data_dir = self.home / ".workbuddy" / "project-context"
        self.sessions_dir = self.home / ".workbuddy" / "sessions"
        Utils.ensure_dir(self.data_dir)
        
        self.cache = CacheManager(self.data_dir)
        self.analyzer = ConversationAnalyzer()
        self.security = SecurityManager(self.data_dir)
        self.summary = SummaryGenerator()
        self.tags = TagManager(self.data_dir)
    
    def handle_stop_hook(self, workspace: str = "", session: str = "") -> None:
        """Stop hook 处理"""
        if not workspace:
            workspace = str(Path.cwd())
        
        Utils.log("INFO", f"Stop hook triggered for: {workspace}")
        
        if not self.cache.init(workspace):
            return
        
        # 读取会话内容
        content = ""
        if session and Path(session).exists():
            content = Path(session).read_text(encoding='utf-8')
        else:
            # 查找最新会话
            today = Utils.get_date()
            for f in sorted(self.sessions_dir.glob(f"{today}-*.md"), reverse=True):
                content = f.read_text(encoding='utf-8')
                break
        
        if not content:
            Utils.log("WARN", "No session content found")
            return
        
        # 安全检查
        filtered = self.security.filter_sensitive(content)
        
        # 分析
        analysis = self.analyzer.analyze(filtered)
        
        # 生成摘要
        project = Path(workspace).name or "Project"
        doc = self.summary.generate(analysis, workspace, project)
        
        # 更新缓存
        self.cache.update("1", filtered)
        self.cache.update("2", doc)
        
        # 更新标签
        ws_hash = Utils.compute_hash(workspace)[:16]
        suggestions = self.tags.suggest(filtered)
        if suggestions:
            self.tags.add(ws_hash, project, suggestions)
        
        # 审计日志
        self.security.log_audit("auto_save", {"workspace": workspace, "tags": suggestions}, ws_hash)
        
        Utils.log("INFO", "Auto-save completed")
    
    def handle_create(self, workspace: str = "") -> None:
        """手动创建/更新项目上下文"""
        if not workspace:
            workspace = str(Path.cwd())
        
        project = Path(workspace).name or "Project"
        print(f"🔄 正在为项目 '{project}' 生成上下文...")
        
        self.cache.init(workspace)
        
        # 读取最近会话
        all_content = ""
        if self.sessions_dir.exists():
            for i in range(7):
                date = (datetime.now() - timedelta(days=i)).strftime("%Y-%m-%d")
                for f in self.sessions_dir.glob(f"{date}-*.md"):
                    all_content += f.read_text(encoding='utf-8') + "\n---\n"
        
        if not all_content:
            print("⚠️ 未找到对话历史")
            return
        
        # 安全过滤
        filtered = self.security.filter_sensitive(all_content)
        
        # 分析
        analysis = self.analyzer.analyze(filtered)
        
        # 生成文档
        doc = self.summary.generate(analysis, workspace, project)
        
        # 保存
        self.cache.update("1", filtered)
        self.cache.update("2", doc)
        self.cache.update("3", doc)
        
        ws_hash = Utils.compute_hash(workspace)[:16]
        suggestions = self.tags.suggest(filtered)
        if suggestions:
            self.tags.add(ws_hash, project, suggestions)
        
        print(f"✅ 项目上下文已保存")
        print(f"\n预览:\n{doc[:500]}...")
    
    def handle_status(self, workspace: str = "") -> None:
        """查看状态"""
        if not workspace:
            workspace = str(Path.cwd())
        
        ws_hash = Utils.compute_hash(workspace)[:16]
        project = Path(workspace).name or "Project"
        
        print(f"## 📊 Project Context Status\n")
        print(f"**项目**: {project}")
        print(f"**工作空间哈希**: {ws_hash}\n")
        
        ctx_dir = self.data_dir / ws_hash
        print("### 缓存状态\n")
        
        l1 = ctx_dir / "fingerprint.sha256"
        print(f"- L1 指纹缓存: {'✅' if l1.exists() else '❌'}")
        
        l2 = ctx_dir / "summary.json"
        print(f"- L2 摘要缓存: {'✅' if l2.exists() else '❌'}")
        
        l3 = ctx_dir / "project-context.md"
        print(f"- L3 上下文缓存: {'✅' if l3.exists() else '❌'}")
        
        l4 = ctx_dir / "confirmed.json"
        print(f"- L4 确认缓存: {'✅' if l4.exists() else '❌'}")
        
        print(f"\n### 项目标签\n")
        tags = self.tags.get(ws_hash)
        if tags:
            for t in tags:
                print(f"- `{t}`")
        else:
            print("_暂无标签_")
    
    def run(self, args: List[str]) -> None:
        """主入口"""
        if len(args) < 1:
            print("""Usage: pcm.py {command} [args...]

Commands:
  stop [workspace]           Stop hook 入口（自动触发）
  create [workspace]         创建/更新项目上下文
  status [workspace]         查看缓存状态
""")
            return
        
        cmd = args[0]
        if cmd == "stop":
            self.handle_stop_hook(args[1] if len(args) > 1 else "")
        elif cmd in ("create", "update"):
            self.handle_create(args[1] if len(args) > 1 else "")
        elif cmd == "status":
            self.handle_status(args[1] if len(args) > 1 else "")
        else:
            print(f"Unknown command: {cmd}")


if __name__ == "__main__":
    PCM().run(sys.argv[1:])
