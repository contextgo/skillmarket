#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Project Context Manager - Cross-platform Installer
"""
import os, sys, shutil, json
from pathlib import Path

# Fix Windows console encoding
if sys.platform == 'win32':
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

class Installer:
    def __init__(self):
        self.skill_name = "project-context-manager"
        self.skill_dir = Path.home() / ".workbuddy" / "skills" / self.skill_name
        self.data_dir = Path.home() / ".workbuddy" / "project-context"
        self.source_dir = Path(__file__).parent

    def log(self, msg, level="INFO"):
        print(f"[{level}] {msg}")

    def check_python(self):
        if sys.version_info < (3, 8):
            self.log("Python 3.8+ required", "ERROR")
            return False
        self.log(f"Python {sys.version_info.major}.{sys.version_info.minor} OK")
        return True

    def install_files(self):
        self.log("Installing files...")
        self.skill_dir.mkdir(parents=True, exist_ok=True)

        files = ["SKILL.md", "README.md", "install.py", "pcm.py"]
        for f in files:
            src = self.source_dir / f
            dst = self.skill_dir / f
            if src.exists():
                shutil.copy2(src, dst)
                self.log(f"  Copied: {f}")

    def init_data_dir(self):
        self.log("Initializing data directory...")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        (self.data_dir / "audit").mkdir(exist_ok=True)

        index_file = self.data_dir / "index.json"
        if not index_file.exists():
            index_file.write_text(json.dumps({
                "version": "1.0.0",
                "workspaces": {}
            }, indent=2))

        tag_file = self.data_dir / "tag-index.json"
        if not tag_file.exists():
            tag_file.write_text(json.dumps({
                "version": "1.0.0",
                "tags": {},
                "projects": {}
            }, indent=2))

    def verify(self):
        self.log("Verifying installation...")
        all_ok = True
        for f in ["SKILL.md", "README.md", "pcm.py"]:
            if not (self.skill_dir / f).exists():
                self.log(f"Missing: {f}", "ERROR")
                all_ok = False
        return all_ok

    def uninstall(self):
        self.log("Uninstalling...")
        if self.skill_dir.exists():
            shutil.rmtree(self.skill_dir)
            self.log(f"Removed: {self.skill_dir}")

        # Ask about data
        resp = input("Remove data directory? [y/N]: ").strip().lower()
        if resp == 'y':
            if self.data_dir.exists():
                shutil.rmtree(self.data_dir)
                self.log(f"Removed: {self.data_dir}")

    def run(self, action="install"):
        if action == "install":
            if not self.check_python():
                sys.exit(1)
            self.install_files()
            self.init_data_dir()
            if self.verify():
                self.log("Installation complete!")
                self.log(f"Skill directory: {self.skill_dir}")
                self.log(f"Data directory: {self.data_dir}")
            else:
                self.log("Verification failed", "ERROR")
                sys.exit(1)
        elif action == "uninstall":
            self.uninstall()
        else:
            self.log(f"Usage: {sys.argv[0]} [install|uninstall]")

if __name__ == "__main__":
    action = sys.argv[1] if len(sys.argv) > 1 else "install"
    Installer().run(action)
