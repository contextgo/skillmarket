---
name: douyin-analyzer
description: "抖音视频内容分析工具 - 通过CDP控制浏览器截取视频页面，使用AI多模态能力分析教学内容"
version: "1.0.0"
author: "QClaw"
trigger_keywords:
  - 分析抖音视频
  - 抖音视频内容
  - 视频知识点提取
  - 教学内容分析
  - 抖音链接分析
exclude_when:
  - 用户需要下载视频文件
  - 用户需要提取视频音频
  - 用户需要视频剪辑功能
---

# douyin-analyzer - 抖音视频内容分析

> **定位**：通过CDP控制浏览器截取抖音视频页面，使用AI多模态能力分析教学内容。
>
> **核心能力**：抖音视频链接 → 截图 → AI分析 → 结构化报告

## 1. 核心功能

### 支持能力

| 功能 | 状态 | 说明 |
|------|------|------|
| 抖音视频链接解析 | ✅ | 支持短链接和完整链接 |
| 浏览器CDP控制 | ✅ | 通过Edge/Chrome远程调试端口 |
| 页面截图 | ✅ | 保存视频页面截图 |
| AI多模态分析 | ✅ | 直接分析截图内容（无需OCR） |
| 知识点提取 | ✅ | 自动识别教学内容 |
| 结构化报告 | ✅ | 生成Markdown格式分析报告 |

### 不支持能力

| 功能 | 说明 |
|------|------|
| 视频下载 | ❌ 仅分析页面，不下载视频文件 |
| 音频提取 | ❌ 无法处理视频音频流 |
| 视频剪辑 | ❌ 无视频编辑功能 |
| 批量分析 | ❌ 当前仅支持单个视频分析 |

## 2. 技术架构

### 工作流程
```
输入抖音链接 → 连接CDP → 打开页面 → 等待加载 → 截图 → AI分析 → 生成报告
```

### 核心组件
1. **xbrowser skill**: 通过CDP控制浏览器（需单独安装）
2. **Edge/Chrome CDP**: 远程调试端口（默认28800）
3. **AI多模态**: 直接分析截图内容
4. **Node.js脚本**: 自动化截图流程

### 依赖技能
- **xbrowser** (必须): `openclaw skills install xbrowser`
- **agent-browser** (可选): `openclaw skills install agent-browser`

## 3. 使用方法

### 步骤一：启动浏览器（带CDP）
```bash
# 关闭所有Edge进程
taskkill /IM msedge.exe /F

# 启动Edge带远程调试
"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" --remote-debugging-port=28800
```

### 步骤二：分析抖音视频
```bash
# 方法1：使用skill命令
douyin-analyzer "https://v.douyin.com/Mo6r--OixXQ/"

# 方法2：直接运行脚本
node scripts/analyze.js "https://www.douyin.com/video/7497104894491905307"
```

### 步骤三：查看分析结果
- **截图保存位置**: `C:\Users\zhuyi\.openclaw\workspace\douyin-screenshots\`
- **分析报告**: `summary-{timestamp}.md`

## 4. 输出示例

```markdown
# 抖音视频内容分析

## 视频信息
- **标题**: 七下数学# 平行线中的拐点问题大总结
- **链接**: https://www.douyin.com/video/7497104894491905307
- **分析时间**: 2026-04-26 07:00

## 内容分析
### 知识点识别
- 平行线拐点问题
- 猪蹄模型：∠A + ∠C = ∠B
- 辅助线作法

### 适用人群
- 七年级学生
- 期中考试复习

### 教学质量评分
- 内容准确性: ⭐⭐⭐⭐⭐ (5/5)
- 讲解清晰度: ⭐⭐⭐⭐☆ (4/5)
- 推荐指数: ⭐⭐⭐⭐☆ (4/5)
```

## 5. 配置说明

### CDP连接配置
| 参数 | 默认值 | 说明 |
|------|--------|------|
| `CDP_HOST` | `127.0.0.1` | CDP服务器地址 |
| `CDP_PORT` | `28800` | CDP远程调试端口 |
| `SCREENSHOT_DIR` | `douyin-screenshots` | 截图保存目录 |
| `REPORT_DIR` | `douyin-screenshots` | 报告保存目录 |

### 环境变量
```bash
# 自定义CDP端口
export CDP_PORT=9222

# 自定义工作目录
export WORKSPACE="C:\Users\zhuyi\.openclaw\workspace"
```

## 6. 故障排除

### 常见问题

**Q: CDP连接失败**
```
错误: Unable to connect to CDP port 28800
解决: 确保浏览器以远程调试模式启动
```

**Q: 截图黑屏**
```
原因: 页面未完全加载
解决: 增加等待时间，或手动确保页面渲染完成
```

**Q: 抖音反爬拦截**
```
现象: 跳转到登录页
解决: 确保浏览器已登录抖音，CDP连接正确
```

**Q: xbrowser skill未安装**
```
错误: Cannot find module 'xbrowser'
解决: 运行 `openclaw skills install xbrowser`
```

## 7. 技术细节

### 文件结构
```
douyin-analyzer/
├── package.json          # SkillHub元数据
├── README.md           # 使用说明
├── SKILL.md            # OpenClaw技能定义
├── scripts/
│   └── analyze.js     # 核心分析脚本
└── examples/          # 示例文件
```

### CDP协议命令
- `Target.createTarget` - 创建新页面
- `Page.navigate` - 页面导航
- `Page.captureScreenshot` - 截图
- `Runtime.evaluate` - 执行JavaScript

### AI分析提示词模板
```
请分析这张抖音视频截图，提取以下信息：
1. 视频标题
2. 主要知识点
3. 适用人群
4. 教学内容总结
5. 质量评分（1-5星）

请以结构化Markdown格式输出。
```

## 8. 更新日志

### v1.0.0 (2026-04-26)
- ✅ 初始版本发布
- ✅ 支持抖音视频链接分析
- ✅ 多模态AI内容识别
- ✅ 结构化报告生成
- ✅ CDP浏览器控制
- ✅ 登录态复用

## 9. 许可证

MIT License

## 10. 贡献

欢迎提交Issue和Pull Request！

## 11. 作者

QClaw - OpenClaw定制技能开发

---

**快速开始**：
1. 安装依赖：`openclaw skills install xbrowser`
2. 启动浏览器：`msedge --remote-debugging-port=28800`
3. 分析视频：`douyin-analyzer "https://v.douyin.com/xxx/"`
