# douyin-analyzer

抖音视频内容分析工具 - 通过CDP控制浏览器截取视频页面，使用AI多模态能力分析教学内容

## 功能特点

- 🎯 **抖音视频分析**: 输入抖音视频链接，自动截取页面并分析内容
- 🖼️ **多模态AI分析**: 直接分析截图中的视觉内容（无需OCR）
- 📚 **教育内容识别**: 自动识别教学知识点、适用人群、质量评分
- 🔐 **登录态复用**: 通过CDP连接已登录的浏览器，绕过反爬限制
- 📊 **结构化输出**: 生成标准化的分析报告（知识点、适用人群、推荐指数）

## 技术架构

### 核心组件
1. **xbrowser skill**: 通过CDP控制浏览器（需单独安装）
2. **Edge/Chrome CDP**: 远程调试端口（默认28800）
3. **AI多模态**: 直接分析截图内容
4. **Node.js脚本**: 自动化截图流程

### 工作流程
```
输入抖音链接 → 连接CDP → 打开页面 → 等待加载 → 截图 → AI分析 → 生成报告
```

## 安装要求

### 依赖技能
- **xbrowser** (必须): `openclaw skills install xbrowser`
- **agent-browser** (可选): `openclaw skills install agent-browser`

### 浏览器要求
- Edge (推荐) 或 Chrome
- 需启用远程调试端口：`--remote-debugging-port=28800`

## 使用方法

### 1. 启动浏览器（带CDP）
```bash
# 关闭所有Edge进程
taskkill /IM msedge.exe /F

# 启动Edge带远程调试
"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" --remote-debugging-port=28800
```

### 2. 分析抖音视频
```bash
# 方法1：短链接
douyin-analyzer "https://v.douyin.com/Mo6r--OixXQ/"

# 方法2：完整链接
douyin-analyzer "https://www.douyin.com/video/7497104894491905307"
```

### 3. 查看分析结果
- 截图保存位置: `C:\Users\zhuyi\.openclaw\workspace\douyin-screenshots\`
- 分析报告: `summary-{timestamp}.md`

## 输出示例

```markdown
# 抖音视频内容分析

## 视频信息
- **标题**: 七下数学# 平行线中的拐点问题大总结
- **链接**: https://www.douyin.com/video/7497104894491905307
- **分析时间**: 2026-04-26 07:00

## 内容分析
### 知识点识别
- 平行线拐点问题
- 猪蹄模型：∠A + ∠C = ∠B
- 辅助线作法

### 适用人群
- 七年级学生
- 期中考试复习

### 教学质量评分
- 内容准确性: ⭐⭐⭐⭐⭐ (5/5)
- 讲解清晰度: ⭐⭐⭐⭐☆ (4/5)
- 推荐指数: ⭐⭐⭐⭐☆ (4/5)
```

## 技术细节

### CDP连接配置
- **端口**: 28800 (可自定义)
- **连接URL**: `http://127.0.0.1:28800`
- **协议**: Chrome DevTools Protocol

### 文件结构
```
douyin-analyzer/
├── package.json          # SkillHub元数据
├── README.md           # 使用说明
├── SKILL.md            # OpenClaw技能定义
├── scripts/
│   └── analyze.js     # 核心分析脚本
└── examples/          # 示例文件
```

## 限制说明

### 当前限制
- ❌ 无法处理视频音频（仅视觉分析）
- ❌ 强反爬网站可能失败
- ❌ 需要人工确保页面加载完成

### 适用场景
- ✅ 教育类视频分析
- ✅ 教学内容总结
- ✅ 知识点提取
- ✅ 视频质量评估

## 故障排除

### 常见问题

**Q: CDP连接失败**
```
错误: Unable to connect to CDP port 28800
解决: 确保浏览器以远程调试模式启动
```

**Q: 截图黑屏**
```
原因: 页面未完全加载
解决: 增加等待时间，或手动确保页面渲染完成
```

**Q: 分统反爬拦截**
```
现象: 跳转到登录页
解决: 确保浏览器已登录抖音，CDP连接正确
```

## 更新日志

### v1.0.0 (2026-04-26)
- ✅ 初始版本发布
- ✅ 支持抖音视频链接分析
- ✅ 多模态AI内容识别
- ✅ 结构化报告生成

## 许可证

MIT License

## 贡献

欢迎提交Issue和Pull Request！

## 作者

QClaw - OpenClaw定制技能开发
