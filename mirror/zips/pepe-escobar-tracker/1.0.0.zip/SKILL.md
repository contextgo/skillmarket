---
name: pepe-escobar-tracker
description: 追踪地缘政治学者佩佩·埃斯科巴尔（Pepe Escobar）的最新动态。当用户想要获取Pepe Escobar的最新视频、访谈、专栏文章，或想了解当前地缘政治热点（美伊局势、中俄关系、欧亚整合等）时触发。触发词：Pepe Escobar动态、Pepe最新视频、埃斯科巴尔、地缘政治追踪、追踪地缘政治博主、Pepe's latest、geopolitical tracker
---

# Pepe Escobar Tracker

## Overview

抓取并整理地缘政治学者 **佩佩·埃斯科巴尔（Pepe Escobar）** 在多个平台上的最新动态，输出结构化报告。

Pepe Escobar 是一位巴西裔美国独立记者、地缘政治分析师，专注于欧亚大陆整合、中东局势、能源地缘政治等议题。他主要活跃于以下三个 YouTube 频道：

| 频道 | URL | 定位 |
|------|-----|------|
| **Pepe Café** | @pepecafe | 本人主频道（葡萄牙语为主） |
| **Dialogue Works** | @dialogueworks01 | 核心发声平台，Nima主持的深度访谈 |
| **Judging Freedom** | @judgingfreedom | Judge Napolitano主持，偶做客访谈 |

此外他的专栏文章发布于 **The Unz Review** (unz.com/pescobar)。

## Workflow

### Step 1 — 安装/启动浏览器

检查 `agent-browser` 是否可用，如未安装则先 `npm install -g agent-browser && agent-browser install`。

```bash
agent-browser launch
```

> 注意：新版 agent-browser 直接用 `open` 命令，无需单独 launch。

### Step 2 — 抓取 YouTube 频道

依次访问以下三个频道页面，使用 `snapshot` 获取内容：

1. **Pepe Café** 视频页：`https://www.youtube.com/@pepecafe/videos`
2. **Dialogue Works** 首页：`https://www.youtube.com/@dialogueworks01`
3. **Judging Freedom** 直播页：`https://www.youtube.com/@judgingfreedom/streams`

每个页面等待 3 秒加载：
```bash
agent-browser open "<URL>" && agent-browser wait 3000 && agent-browser snapshot
```

### Step 3 — 补充搜索最新动态

同时发起 Web 搜索获取最新内容，关键词示例：
- `Pepe Escobar April 2026 latest`
- `Pepe Escobar "Dialogue Works" 2026`
- `Pepe Escobar Unz Review latest`

搜索范围覆盖：YouTube视频标题、直播时间、观看量，以及 The Unz Review 专栏、Dialogue Works Substack/Podbean。

### Step 4 — 整理报告

输出结构化报告，包含：

1. **频道概览表**（频道名、链接、视频总数）
2. **各频道最新视频**（标题、时长、观看量、发布时间）
3. **核心主题聚焦**（当前最热的1-3个话题）
4. **Pepe最新专栏摘要**
5. **总结：Pepe当前分析框架**

### Step 5 — 关闭浏览器

```bash
agent-browser close
```

## Output Format

报告使用中文输出，包含 Markdown 表格和分层标题。

如用户有特定话题需求（如"伊朗"、"中俄"、"石油美元"），在报告中重点展开相关内容。

## Channel-Specific Notes

- **Pepe Café**：默认按热度排序，需注意最新视频可能排在下方；页面描述显示"Aqui fala Pepe Escobar"
- **Dialogue Works**：Pepe 最活跃的平台，2026年以来几乎每周都有他的访谈；Substack和Podbean有完整音频/文字版
- **Judging Freedom**：Pepe 作为嘉宾出现，搜索"Pepe Escobar Judging Freedom"获取相关视频

## Known Content Themes (2026)

当前 Pepe Escobar 高度聚焦的主题：
- ⚔️ **美伊战争危机**：封锁政策失败、霍尔木兹海峡、伊朗"马赛克战略"
- 🌏 **欧亚整合**：中俄轴心、伊朗作为欧亚枢纽、一带一路延伸
- 💰 **石油美元崩塌**：2026年10万亿美债到期、全球金融格局重组
