"""
Pydantic Schemas
"""
