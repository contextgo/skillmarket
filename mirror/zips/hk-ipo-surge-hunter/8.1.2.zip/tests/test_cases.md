# V7.0 测试用例

## 测试1：智谱（02513.HK）- 首日平淡但后期暴涨

```json
{
  "action": "score",
  "params": {
    "name": "智谱",
    "code": "02513",
    "track": "AI/半导体",
    "is_ah": false,
    "oversub": 1159,
    "cornerstone_names": [],
    "cornerstone_pct": 0,
    "scarcity": "稀缺",
    "is_18a": false,
    "has_top_vc": true,
    "is_first_stock": true,
    "rd_ratio": 80,
    "free_float_pct": 10,
    "days_to_connect": 45,
    "sponsor_quality": "头部中资",
    "rev_growth": 200,
    "policy_catalyst": true,
    "first_day_chg": 13.2
  }
}
```

**预期结果**：评分40分，极高概率超涨，首日+13%平淡0分
**验证点**：
- 首日+13%→0分 + 超购1159→+2 + 纯H=3 + AI=10 + 第一股=10 + VC=8 + 政策=3 + 研发80%=2 + 营收200%=1 + 流通10%=1 = 40
- 无交互因子触发，AI赛道后期涨幅提醒

## 测试2：蜜雪冰城（02097.HK）- 知名消费品牌+高超购

```json
{
  "action": "score",
  "params": {
    "name": "蜜雪冰城",
    "code": "02097",
    "track": "消费品",
    "is_ah": false,
    "oversub": 5000,
    "cornerstone_names": ["高瓴", "红杉"],
    "cornerstone_pct": 40,
    "scarcity": "中等",
    "is_18a": false,
    "has_top_vc": true,
    "is_first_stock": false,
    "rd_ratio": 3,
    "free_float_pct": 10,
    "days_to_connect": 15,
    "sponsor_quality": "顶级+外资",
    "rev_growth": 20,
    "policy_catalyst": false,
    "first_day_chg": 43.2
  }
}
```

**预期结果**：评分50分，极高概率超涨
**验证点**：
- 首日+43%→+8 + 超购5000+首日大涨(真热情)→+6 + 纯H=3 + 消费品=1 + 基石40%=6 + 顶级基石=3 + VC=8 + 入通15天=2 + 保荐人=2 + 流通10%=1 + 营收20%=1 + 消费品牌=12 = 53 → 高超购+消费品牌交互+8 → 但需扣除消费品赛道非AI所以政策催化=false → 约50分
- 注意：V7中蜜雪冰城代码是02097（非02245）

## 测试3：华沿机器人（01021.HK）- A+H+机器人

```json
{
  "action": "score",
  "params": {
    "name": "华沿机器人",
    "code": "01021",
    "track": "机器人",
    "is_ah": true,
    "oversub": 5059,
    "cornerstone_names": [],
    "cornerstone_pct": 0,
    "scarcity": "中等",
    "is_18a": false,
    "has_top_vc": false,
    "is_first_stock": false,
    "rd_ratio": 30,
    "free_float_pct": 25,
    "days_to_connect": 10,
    "sponsor_quality": "头部中资",
    "rev_growth": 15,
    "policy_catalyst": true,
    "first_day_chg": 8.0
  }
}
```

**预期结果**：评分~7分，不太可能超涨，A+H+热门赛道交互-3
**验证点**：
- 首日+8%→0 + 超购5059+首日未大涨(虚假)→-5 + A+H=0 + 机器人=7 + 政策=3 + 研发30%=1 + 入通10天=2 + 营收15%=1 + 流通25%=0 = 9 → A+H+热门-3 = 6 → max(6,0)=6

## 测试4：派格生物医药-B - 首日中跌但小盘妖股

```json
{
  "action": "score",
  "params": {
    "name": "派格生物医药-B",
    "code": "02565",
    "track": "医疗/18A",
    "is_ah": false,
    "oversub": null,
    "oversub_missing": true,
    "cornerstone_names": [],
    "cornerstone_pct": 0,
    "scarcity": "常见",
    "is_18a": true,
    "has_top_vc": false,
    "is_first_stock": false,
    "rd_ratio": 30,
    "free_float_pct": 8,
    "days_to_connect": 90,
    "sponsor_quality": "",
    "rev_growth": 20,
    "policy_catalyst": true,
    "first_day_chg": -25.9
  }
}
```

**预期结果**：评分28分，可能超涨，首日-26%只扣3分（vs V6.2的-15分）
**验证点**：
- 首日-26%(中跌)→-3 + 纯H=3 + 医疗=6 + 18A=5 + 流通8%=2 + 政策=3 + 研发30%=1 + 营收20%=1 + 小盘妖股+10 = 28
- 首日中跌只扣3分，小盘妖股信号+10分
- V7核心改进：微跌不重罚！

## 测试5：金叶国际 - 首日暴涨+虚假热情

```json
{
  "action": "score",
  "params": {
    "name": "金叶国际集团",
    "code": "08549",
    "track": "其他",
    "is_ah": false,
    "oversub": 11464,
    "cornerstone_names": [],
    "cornerstone_pct": 0,
    "scarcity": "常见",
    "is_18a": false,
    "has_top_vc": false,
    "is_first_stock": false,
    "rd_ratio": 2,
    "free_float_pct": 25,
    "days_to_connect": 90,
    "sponsor_quality": "",
    "rev_growth": 5,
    "policy_catalyst": false,
    "first_day_chg": 330.0
  }
}
```

**预期结果**：评分25分左右，首日+330%+28分但超购11464倍(虚假热情)-5，且暴涨+虚假热情交互-15
**验证点**：
- 首日+330%(暴涨)→+28 + 超购11464+首日大涨(真热情?)→+6 + 纯H=3 + 其他=1 + 流通25%=0 + 营收5%=0 = 38 → 暴涨+虚假热情交互-15 = 23
- V7新增交互：首日暴涨+超高购=虚假热情陷阱

## 测试6：参数校验

```json
{
  "action": "validate",
  "params": {
    "name": "测试公司",
    "oversub": -100,
    "cornerstone_pct": 150,
    "first_day_chg": 5000
  }
}
```

**预期结果**：valid=true, warnings含3条（超购负数、基石超100%、首日涨幅不合理）
**验证点**：校验功能正常，不阻止评分但提示异常值

## 测试7：上市前评估（无首日数据+无超购）

```json
{
  "action": "score",
  "params": {
    "name": "某AI新股",
    "track": "AI/半导体",
    "is_ah": false,
    "oversub_missing": true,
    "is_first_stock": true,
    "has_top_vc": true,
    "rd_ratio": 60
  }
}
```

**预期结果**：评分约25-30分，上市前预评估，warnings含超购缺失和首日数据缺失提示
**验证点**：首日因子0分且标注"上市前评估"

## 测试8：古茗 - 首日微跌不惩罚

```json
{
  "action": "score",
  "params": {
    "name": "古茗",
    "code": "01364",
    "track": "消费品",
    "is_ah": false,
    "oversub_missing": true,
    "cornerstone_names": [],
    "cornerstone_pct": 0,
    "is_18a": false,
    "has_top_vc": false,
    "is_first_stock": false,
    "rd_ratio": 3,
    "free_float_pct": 20,
    "first_day_chg": -5.0
  }
}
```

**预期结果**：首日-5%得0分（微跌不惩罚！），warnings含"微跌≠不会超涨"
**验证点**：V7核心原则——首日微跌(-20~0%)不扣分
