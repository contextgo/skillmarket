#!/usr/bin/env python3
"""
港股IPO超涨股选股评分脚本 V7.0
基于2025-2026年84只有效港股IPO样本的量化因子分析
采用"上市10日后收盘价≥发行价×2(翻倍)"的超涨定义
V7.0评分模型AUC=0.9784（20000次随机搜索最优）

V7.0关键变更（vs V6.2）：
- 超涨定义升级：最大涨幅≥50% → 上市10日后收盘价翻倍（更实用，可操作）
- 样本扩充：55只 → 84只有效样本（+53%）
- 引入首日涨跌幅因子（分段，微跌不惩罚）
- 新增4个因子：首日涨跌幅(信号/预警)、小盘妖股、知名消费品牌、高超购消费
- AUC从0.9150→0.9784（+6.3pp）
- 首日跌幅分段处理：暴跌(<-40%)-18, 大跌(-40~-30%)-15, 中跌(-30~-20%)-3, 微跌(>-20%)0
- 超高购(≥5000)+首日大涨=真热情(+6), 否则虚假热情(-5)
- A+H×热门赛道交互从-15→-3（兆易创新A+H+AI实际超涨250%）
- 低超购+AI交互从-8→-15（加强惩罚）

使用方式:
  echo '{"action":"score","params":{...}}' | python3 hk_ipo_scorer.py

Actions:
  score - 计算评分
  info  - 返回模型信息
  validate - 校验输入参数

V2接口契约:
  输入: stdin JSON
  输出: stdout JSON（含 success/error/metadata）
"""

import json
import os
import sys
from typing import Any, Dict, List, Optional

# ====== 版本信息 ======
VERSION = "V7.0"
AUC = 0.9784
MODEL_DATE = "2026-04-24"

# ====== V7.0 评分参数（AUC=0.9784，20000次随机搜索最优） ======
PARAMS = {
    # 首日涨跌幅（V7新增，分段处理）
    "fd_100": 28,               # 首日≥100%: +28分（强信号，96%超涨率）
    "fd_50": 12,                # 首日50~100%: +12分（100%超涨率）
    "fd_30": 8,                 # 首日30~50%: +8分（60%超涨率）
    "fd_10": 0,                 # 首日10~30%: 0分
    "fd_m40": -18,              # 首日<-40%: -18分（暴跌预警，0%超涨率）
    "fd_m30": -15,              # 首-40~-30%: -15分（0%超涨率）
    "fd_m20": -3,               # 首-30~-20%: -3分（弱负向，17%超涨率）
    # 首-20~0%: 0分（微跌不惩罚！29%超涨率）

    # 超购倍数（V7优化）
    "os_5k": -5,                # ≥5000倍"虚假热情"惩罚
    "os_5k_surge": 6,           # ≥5000倍+首日大涨=真热情
    "os_1k": 2,                 # ≥1000倍
    "os_100": 4,                # ≥100倍
    "os_10": 3,                 # ≥10倍
    "os_low": 1,                # <10倍
    "os_missing": 0,            # 超购数据缺失时不评分

    # 上市方式
    "ah_bonus": 3,              # 纯H股加分（从15降至3）
    "ah_penalty": 0,            # A+H惩罚（独立参数）

    # 赛道热度
    "track_ai": 10,             # AI/半导体赛道
    "track_ne": 8,              # 新能源赛道（从4升至8）

    # 新增因子
    "consumer_brand": 12,       # 知名消费品牌加分
    "small_monster": 10,        # 小盘妖股信号

    # 原有因子（权重调整）
    "first_stock": 10,          # "第一股"标签（从12降至10）
    "cs_pct_top": 6,            # 基石占比最高分
    "vc_pts": 8,                # 知名VC/PE（从14降至8，V7f优化确认）
    "float_pts": 2,             # 低流通得分
    "policy_pts": 3,            # 政策催化得分
    "rd_pts": 2,                # 高研发占比得分
    "18a_pts": 5,               # 18A章节得分
    "cs_quality_top": 4,        # 顶级基石质量得分
    "connect_pts": 2,           # 快速入通得分
    "sponsor_pts": 2,           # 顶级保荐人得分
    "rev_growth_pts": 3,        # 高营收增速得分

    # 交互因子（V7大幅调整）
    "interaction_ah_hot": -3,   # A+H+热门赛道（从-15降至-3）
    "interaction_low_os_hot": -15,  # 低超购+热门赛道（从-8升至-15）
    "interaction_highos_consumer": 8,  # 高超购+消费品牌（新增）
    "interaction_crash_18a": -8,    # 首日暴跌+18A双杀（新增）
    "interaction_surge_fake": -15,  # 首日暴涨+虚假热情（新增）
}

# ====== 顶级VC/PE名单 ======
def _load_vc_lists():
    """从 references/cornerstone_whitelist.md 加载 VC 名单。
    返回 (top_vcs, professional_vcs) 两个集合。"""
    import os, re
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                        "..", "references", "cornerstone_whitelist.md")
    try:
        with open(path) as f:
            content = f.read()
        top_vcs = set()
        pro_vcs = set()
        section = None  # None | "top" | "pro"
        for line in content.split("\n"):
            # 节标题检测
            if "内置顶级VC" in line or "知名VC/PE识别" in line:
                section = "top"
                continue
            if "内置专业VC" in line:
                section = "pro"
                continue
            # 非表格行或离开表格区域
            if section is None:
                continue
            if not line.startswith("|"):
                continue  # 仍在表格区域内，跳过空行和非表格行
            # 匹配表格行：| 名称 | 类型 | 关键词 | (可选：出现次数)
            match = re.match(r'^\|\s*([\u4e00-\u9fff\w·\s\-]+)\s*\|\s*[\u4e00-\u9fff\w·\s\-/]+\s*\|\s*`?(\w+)`?\s*\|', line)
            if not match:
                continue
            name_col = match.group(1).strip()
            kw = match.group(2).strip()
            # 过滤表头行和示例行
            if kw in ('------', '关键词', 'VC', 'V7得分'):
                continue
            if not kw or len(kw) < 2:
                continue
            if section == "top":
                top_vcs.add(kw)
            elif section == "pro":
                pro_vcs.add(kw)
        if top_vcs:
            return top_vcs, pro_vcs
    except Exception:
        pass
    return {"高瓴", "红杉", "淡马锡", "贝莱德"}, {"奥博", "HBM", "启明"}

_raw_top, _raw_pro = _load_vc_lists()
TOP_VCS = _raw_top | _raw_pro  # has_top_vc 评分：顶级+专业VC均可
PROFESSIONAL_VCS = _raw_pro     # 基石质量子评分：仅专业VC

# ====== 知名消费品牌关键词 ======
def _load_consumer_brands():
    """从 references/consumer_brands.md 加载消费品牌关键词列表。
    兜底：文件读取失败时回退到内置最小集合。"""
    import os, re
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                        "..", "references", "consumer_brands.md")
    try:
        with open(path) as f:
            content = f.read()
        # 从 Markdown 表格第二列提取关键词
        brands = []
        _skip = {'------', '关键词', '关键词建议', '备注', '品牌'}
        for line in content.split("\n"):
            match = re.match(r'^\|\s*[\u4e00-\u9fff\w·]+\s*\|\s*`?([\u4e00-\u9fff\w]+)`?\s*\|', line)
            if match:
                kw = match.group(1).strip()
                if kw and kw not in _skip:
                    brands.append(kw)
        if brands:
            return brands
    except Exception:
        pass
    return ["蜜雪", "古茗", "绿茶", "布鲁可"]

CONSUMER_BRANDS = _load_consumer_brands()

# ====== 参数定义（用于validate） ======
PARAM_SCHEMA = {
    "name": {"type": str, "required": True, "desc": "公司名称"},
    "code": {"type": str, "required": False, "desc": "股票代码"},
    "track": {"type": str, "required": False, "desc": "赛道", "enum": ["AI/半导体", "医疗/18A", "机器人", "新能源", "消费品", "资源/材料", "软件服务", "A+H/传统", "其他"]},
    "is_ah": {"type": bool, "required": False, "desc": "是否A+H上市"},
    "oversub": {"type": (int, float, type(None)), "required": False, "desc": "公开发售超购倍数(None=数据缺失)"},
    "cornerstone_names": {"type": list, "required": False, "desc": "基石投资者名称列表"},
    "cornerstone_pct": {"type": (int, float), "required": False, "desc": "基石投资者占比(0-100)"},
    "scarcity": {"type": str, "required": False, "desc": "稀缺性", "enum": ["稀缺", "中等", "常见"]},
    "is_loss": {"type": bool, "required": False, "desc": "是否亏损"},
    "is_18a": {"type": bool, "required": False, "desc": "是否18A章节上市"},
    "has_top_vc": {"type": bool, "required": False, "desc": "是否有知名VC/PE投资"},
    "is_first_stock": {"type": bool, "required": False, "desc": "是否赛道\"第一股\""},
    "rd_ratio": {"type": (int, float), "required": False, "desc": "研发费用占营收比例(%)"},
    "free_float_pct": {"type": (int, float), "required": False, "desc": "自由流通比例(%)"},
    "days_to_connect": {"type": int, "required": False, "desc": "预计入通天数"},
    "sponsor_quality": {"type": str, "required": False, "desc": "保荐人质量", "enum": ["顶级+外资", "外资", "头部中资", "中小保荐人"]},
    "rev_growth": {"type": (int, float), "required": False, "desc": "营收增速(%)"},
    "market_cap_yi": {"type": (int, float), "required": False, "desc": "发行市值(亿港元)"},
    "policy_catalyst": {"type": bool, "required": False, "desc": "是否有政策催化"},
    "public_pct": {"type": (int, float), "required": False, "desc": "公开发售比例(%)"},
    "oversub_missing": {"type": bool, "required": False, "desc": "超购数据是否缺失"},
    # V7新增参数
    "first_day_chg": {"type": (int, float, type(None)), "required": False, "desc": "首日涨跌幅(%)，上市前评估时传None"},
    # V7.1新增数据质量参数（防止发行价/价格错误）
    "issue_price_source": {"type": str, "required": False, "desc": "发行价数据来源（如：东方财富网IPO列表）"},
    "current_price_source": {"type": str, "required": False, "desc": "当前价数据来源（如：新浪财经API）"},
    "issue_price_verified": {"type": bool, "required": False, "desc": "发行价是否已交叉验证"},
    # V7.1扩展参数（支持AI Agent传入非内置品牌/VC）
    "consumer_brand": {"type": bool, "required": False, "desc": "是否知名消费品牌（AI Agent判断后直接传入，优先级高于内置名单匹配）"},
    "extra_consumer_brands": {"type": list, "required": False, "desc": "额外消费品牌关键词列表（与内置CONSUMER_BRANDS合并匹配公司名）"},
    "extra_vcs": {"type": list, "required": False, "desc": "额外VC/PE名称关键词列表（与内置TOP_VCS合并匹配基石投资者名称）"},
}


def safe_float(v, default=0):
    """安全转换为浮点数"""
    if v is None:
        return default
    try:
        return float(v)
    except (ValueError, TypeError):
        return default


def output_success(data: Dict[str, Any], duration_ms: int = 0) -> None:
    """输出成功结果（V2契约）"""
    result = {
        "success": True,
        "data": data,
        "metadata": {
            "script": "hk_ipo_scorer.py",
            "version": VERSION,
            "model_date": MODEL_DATE,
            "duration_ms": duration_ms,
        }
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))


def output_error(code: str, message: str, details: Dict[str, Any] = None) -> None:
    """输出错误结果（V2契约）"""
    error = {
        "success": False,
        "error": {
            "code": code,
            "message": message,
            "details": details or {},
        }
    }
    print(json.dumps(error, ensure_ascii=False, indent=2))


def validate_params(params: Dict[str, Any]) -> Dict[str, Any]:
    """校验输入参数"""
    warnings = []
    missing_required = []

    for key, schema in PARAM_SCHEMA.items():
        if schema.get("required") and key not in params:
            missing_required.append(key)

        if key in params:
            val = params[key]
            expected_type = schema["type"]
            if not isinstance(val, expected_type):
                warnings.append(f"参数 '{key}' 类型应为 {expected_type.__name__}，实际为 {type(val).__name__}")

            if "enum" in schema and val not in schema["enum"]:
                warnings.append(f"参数 '{key}' 值 '{val}' 不在可选范围 {schema['enum']} 中")

    # 范围校验
    if "cornerstone_pct" in params:
        pct = safe_float(params["cornerstone_pct"])
        if pct < 0 or pct > 100:
            warnings.append(f"基石占比 {pct}% 超出合理范围(0-100)")

    if "oversub" in params and params["oversub"] is not None:
        os_val = safe_float(params["oversub"])
        if os_val < 0:
            warnings.append(f"超购倍数 {os_val} 不能为负")

    if "rd_ratio" in params:
        rd = safe_float(params["rd_ratio"])
        if rd < 0 or rd > 200:
            warnings.append(f"研发占比 {rd}% 可能不合理")

    if "first_day_chg" in params and params["first_day_chg"] is not None:
        fdc = safe_float(params["first_day_chg"])
        if fdc < -90 or fdc > 1000:
            warnings.append(f"首日涨跌幅 {fdc}% 可能不合理")

    if missing_required:
        return {
            "valid": False,
            "errors": [f"缺少必需参数: {k}" for k in missing_required],
            "warnings": warnings,
        }

    return {
        "valid": True,
        "errors": [],
        "warnings": warnings,
    }


# ====== 因子报告强调等级（基于IV值和权重） ======
# 用于指导报告生成时哪些因子值得作为标题/卖点强调，哪些只能作为辅助信息
FACTOR_EMPHASIS = {
    # factor_key: (emphasis_level, reason)
    # emphasis_level: "headline" → 可用作报告标题/核心卖点
    #                 "body"     → 正文提及，不可做标题
    #                 "footnote" → 仅脚注/风险提示中提及
    "首日涨跌幅": ("headline", "IV=8.22，最强预测因子"),
    "赛道热度": ("headline", "AI赛道+10分，决定性赛道因子"),
    "第一股标签": ("headline", "IV=3.01，题材稀缺性核心"),
    "知名VC/PE": ("headline", "IV=2.76，机构背书信号"),
    "18A章节": ("body", "IV=2.27，医疗板块重要标识"),
    "基石占比": ("body", "IV=2.08，机构锁仓信号"),
    "知名消费品牌": ("headline", "+12分，消费品牌溢价"),
    "小盘妖股信号": ("headline", "+10分，筹码结构特殊信号"),
    "研发占比": ("body", "IV=1.82，高研发支撑成长性"),
    "纯H股": ("body", "无A股定价锚，灵活定价"),
    "基石质量": ("footnote", "IV=1.15，辅助确认信号"),
    "超购倍数": ("footnote", "IV=1.01，预测力极弱；超购仅作风险过滤/交互辅助，不可作为正面卖点"),
    "自由流通": ("footnote", "低流通仅辅助说明"),
    "政策催化": ("footnote", "辅助赛道判断"),
    "入通时间": ("body", "IV=3.08，入通效应可预期"),
    "保荐人质量": ("footnote", "IV=0.46，弱信号"),
    "营收增速": ("footnote", "辅助成长性判断"),
}


def _get_emphasis(factor_name: str) -> str:
    """获取因子的报告强调等级"""
    for key, (level, _) in FACTOR_EMPHASIS.items():
        if key in factor_name:
            return level
    return "body"


# ====== 行业发行价合理性阈值 ======
# 从共享配置文件加载（与 data_validator.py 使用同一数据源）
def _load_price_thresholds():
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                        "..", "references", "price_thresholds.json")
    try:
        with open(path) as f:
            data = json.load(f)
        return data.get("thresholds", {}), data.get("default", {"min": 5, "max": 500})
    except Exception:
        return {}, {"min": 5, "max": 500}

_INDUSTRY_PRICE_THRESHOLDS, _DEFAULT_PRICE_THRESHOLD = _load_price_thresholds()


def _check_data_quality(params: Dict[str, Any], score: int, factors: list) -> Dict[str, Any]:
    """检查输入数据的合理性，防止发行价/价格错误导致结论翻车
    
    基于事故教训（2026-04-24）：42只股票发行价全面错误，导致报告结论两次推翻。
    """
    warnings = []
    name = params.get("name", "未知")
    track = params.get("track", "")
    
    # 1. 发行价合理性检查
    issue_price = params.get("market_cap_yi", 0)  # 此处用市值估算做辅助
    
    # 发行价可能通过其他方式传入，检查行业阈值
    threshold = _DEFAULT_PRICE_THRESHOLD
    for key, t in _INDUSTRY_PRICE_THRESHOLDS.items():
        if key in track:
            threshold = t
            break
    
    # 2. 首日涨跌幅与评分一致性
    first_day_chg = params.get("first_day_chg", None)
    if first_day_chg is not None:
        # 如果首日大涨(≥50%)但评分很低(<20)，可能是数据问题
        if first_day_chg >= 50 and score < 20:
            warnings.append({
                "level": "P1",
                "field": "first_day_chg vs score",
                "message": f"{name} 首日+{first_day_chg}%但V7仅{score}分，评分因子数据可能有问题",
            })
        # 如果首日暴跌(<-30%)但评分很高(≥40)，可能是数据问题
        if first_day_chg < -30 and score >= 40:
            warnings.append({
                "level": "P1",
                "field": "first_day_chg vs score",
                "message": f"{name} 首日{first_day_chg}%但V7达{score}分，首日数据可能有问题",
            })
    
    # 3. 超购倍数与赛道热度矛盾
    oversub = params.get("oversub", None)
    if oversub is not None:
        # AI赛道超购<100倍比较罕见
        if "AI" in track and oversub < 100:
            warnings.append({
                "level": "P2",
                "field": "oversub vs track",
                "message": f"{name} AI赛道但超购仅{oversub}倍（AI股通常>100倍），确认超购数据",
            })
    
    # 4. 数据来源标记检查
    issue_price_source = params.get("issue_price_source", "")
    current_price_source = params.get("current_price_source", "")
    
    source_warnings = []
    if not issue_price_source:
        source_warnings.append("发行价未标注来源")
    elif "估算" in issue_price_source or "推算" in issue_price_source:
        source_warnings.append("发行价来源为估算值（禁止）")
    elif "neodata" in issue_price_source.lower():
        source_warnings.append("发行价来源为NeoData（港股不可靠）")
    
    if not current_price_source:
        source_warnings.append("当前价未标注来源")
    elif "neodata" in current_price_source.lower():
        source_warnings.append("当前价来源为NeoData（港股不可靠）")
    
    for sw in source_warnings:
        warnings.append({
            "level": "P1" if "禁止" in sw else "P2",
            "field": "data_source",
            "message": f"{name} {sw}",
        })
    
    # 5. 推荐标的必须交叉验证
    if score >= 40 and not params.get("issue_price_verified"):
        warnings.append({
            "level": "P1",
            "field": "issue_price_verification",
            "message": f"{name} V7评分≥40但发行价未经交叉验证，推荐标的必须用新闻二次确认",
        })
    
    # 汇总
    p0_count = sum(1 for w in warnings if w["level"] == "P0")
    p1_count = sum(1 for w in warnings if w["level"] == "P1")
    p2_count = sum(1 for w in warnings if w["level"] == "P2")
    
    quality_level = "fail" if p0_count > 0 else ("warning" if p1_count > 0 else "pass")
    
    return {
        "level": quality_level,
        "p0_count": p0_count,
        "p1_count": p1_count,
        "p2_count": p2_count,
        "warnings": warnings,
        "issue_price_source": issue_price_source or "未标注",
        "current_price_source": current_price_source or "未标注",
        "issue_price_verified": params.get("issue_price_verified", False),
        "checks": [
            "首日涨跌幅与评分一致性",
            "超购倍数与赛道热度矛盾",
            "数据来源合规性",
            "推荐标的交叉验证",
        ],
        "history_note": "2026-04-24: 42只股票发行价全部错误导致报告推翻，建立此检查机制",
    }


def score_stock(params: Dict[str, Any]) -> Dict[str, Any]:
    """V7.0评分主函数"""
    p = PARAMS
    score = 0
    factors = []

    # ====== 因子0: 首日涨跌幅（V7新增，分段处理） ======
    # 核心原则：微跌不惩罚！暴跌才预警！
    fd_chg = safe_float(params.get("first_day_chg"))
    fd_available = params.get("first_day_chg") is not None

    if fd_available:
        # 单通道分段计分（从高到低，覆盖全部区间）
        if fd_chg >= 100:
            fd_pts = p["fd_100"]
            fd_detail = f"首日+{fd_chg:.0f}%暴涨→{fd_pts}分(96%超涨率)"
        elif fd_chg >= 50:
            fd_pts = p["fd_50"]
            fd_detail = f"首日+{fd_chg:.0f}%大涨→{fd_pts}分(100%超涨率)"
        elif fd_chg >= 30:
            fd_pts = p["fd_30"]
            fd_detail = f"首日+{fd_chg:.0f}%中涨→{fd_pts}分(60%超涨率)"
        elif fd_chg >= 10:
            fd_pts = p["fd_10"]
            fd_detail = f"首日+{fd_chg:.0f}%小涨→{fd_pts}分"
        elif fd_chg >= 0:
            fd_pts = 0
            fd_detail = f"首日{fd_chg:+.0f}%平淡→0分"
        elif fd_chg >= -20:
            fd_pts = 0
            fd_detail = f"首日{fd_chg:.0f}%微跌→0分(29%超涨率，不惩罚)"
        elif fd_chg >= -30:
            fd_pts = p["fd_m20"]
            fd_detail = f"首日{fd_chg:.0f}%中跌→{fd_pts}分(17%超涨率)"
        elif fd_chg >= -40:
            fd_pts = p["fd_m30"]
            fd_detail = f"首日{fd_chg:.0f}%大跌→{fd_pts}分(0%超涨率)"
        else:
            fd_pts = p["fd_m40"]
            fd_detail = f"首日{fd_chg:.0f}%暴跌→{fd_pts}分(0%超涨率)"

        score += fd_pts
        factors.append({"factor": "首日涨跌幅", "group": "7.首日表现", "points": fd_pts,
                         "detail": fd_detail,
                         "iv": 8.22, "max_score": p["fd_100"]})
    else:
        fd_pts = 0
        factors.append({"factor": "首日涨跌幅", "group": "7.首日表现", "points": 0,
                         "detail": "首日数据缺失(上市前评估)→0分",
                         "iv": 8.22, "max_score": p["fd_100"]})

    # ====== 因子1: 超购倍数（V7优化：区分真热情和虚假热情） ======
    oversub_raw = params.get("oversub")
    oversub_missing = params.get("oversub_missing", False) or oversub_raw is None or oversub_raw == 0
    oversub = safe_float(oversub_raw) if not oversub_missing else 0

    if oversub_missing:
        os_pts = 0
        os_detail = "超购数据缺失→不评分"
    elif oversub >= 5000:
        # 关键区分：超高购+首日大涨=真热情 vs 虚假热情
        if fd_available and fd_chg >= 50:
            os_pts = p["os_5k_surge"]  # +6
            os_detail = f"超购{oversub:.0f}倍+首日大涨(真热情)→{os_pts}分"
        else:
            os_pts = p["os_5k"]  # -5
            os_detail = f"超购{oversub:.0f}倍(虚假热情)→{os_pts}分"
    elif oversub >= 1000:
        os_pts = p["os_1k"]  # +2
        os_detail = f"超购{oversub:.0f}倍(甜蜜区)→{os_pts}分"
    elif oversub >= 100:
        os_pts = p["os_100"]  # +4
        os_detail = f"超购{oversub:.0f}倍→{os_pts}分"
    elif oversub >= 10:
        os_pts = p["os_10"]  # +3
        os_detail = f"超购{oversub:.0f}倍→{os_pts}分"
    else:
        os_pts = p["os_low"]  # +1
        os_detail = f"超购{oversub:.0f}倍→{os_pts}分"
    score += os_pts
    factors.append({"factor": "超购倍数", "group": "核心因子", "points": os_pts,
                     "detail": os_detail,
                     "iv": 1.01, "max_score": p["os_100"]})

    # ====== 因子2: 上市方式 ======
    is_ah = params.get("is_ah", False)
    if is_ah:
        ah_pts = p["ah_penalty"]
        ah_detail = "A+H→0分(有A股定价锚)"
    else:
        ah_pts = p["ah_bonus"]
        ah_detail = f"纯H→{ah_pts}分(无定价锚)"
    score += ah_pts
    factors.append({"factor": "上市方式", "group": "核心因子", "points": ah_pts,
                     "detail": ah_detail,
                     "iv": 1.21, "max_score": p["ah_bonus"]})

    # ====== 因子3: 赛道热度 ======
    track = params.get("track", "")
    is_hot_track = "AI" in track or "半导体" in track or "机器人" in track
    if "AI" in track or "半导体" in track:
        track_pts, track_name = p["track_ai"], "AI/半导体"
    elif "机器人" in track:
        track_pts, track_name = 7, "机器人"
    elif "医疗" in track or "18A" in track or "生物" in track:
        track_pts, track_name = 6, "医疗/18A"
    elif "新能源" in track:
        track_pts, track_name = p["track_ne"], "新能源"
    elif "软件" in track:
        track_pts, track_name = 5, "软件服务"
    else:
        track_pts, track_name = 1, "其他"
    score += track_pts
    factors.append({"factor": "赛道热度", "group": "1.赛道热度", "points": track_pts,
                     "detail": f"{track_name}→{track_pts}分",
                     "iv": 0.99, "max_score": p["track_ai"]})

    # ====== 因子4: "第一股"标签 ======
    is_first = params.get("is_first_stock", False)
    scarcity = params.get("scarcity", "")
    if scarcity == "稀缺" and not is_first:
        is_first = True
    fs_pts = p["first_stock"] if is_first else 0
    score += fs_pts
    factors.append({"factor": "第一股标签", "group": "2.题材稀缺性", "points": fs_pts,
                     "detail": f"{'第一股/稀缺→' + str(fs_pts) + '分' if is_first else '非第一股→0分'}",
                     "iv": 3.01, "max_score": p["first_stock"]})

    # ====== 因子5: 基石占比 ======
    cs_pct = safe_float(params.get("cornerstone_pct"))
    if cs_pct >= 40:
        cs_pts = p["cs_pct_top"]
    elif cs_pct >= 20:
        cs_pts = 5
    elif cs_pct > 0:
        cs_pts = 2
    else:
        cs_pts = 0
    score += cs_pts
    factors.append({"factor": "基石占比", "group": "4.基石投资者", "points": cs_pts,
                     "detail": f"基石占比{cs_pct:.0f}%→{cs_pts}分",
                     "iv": 2.08, "max_score": p["cs_pct_top"]})

    # ====== 因子6: 18A章节 ======
    is_18a = params.get("is_18a", False)
    pts_18a = p["18a_pts"] if is_18a else 0
    score += pts_18a
    factors.append({"factor": "18A章节", "group": "核心因子", "points": pts_18a,
                     "detail": f"{'18A→' + str(pts_18a) + '分' if is_18a else '非18A→0分'}",
                     "iv": 2.27, "max_score": p["18a_pts"]})

    # ====== 因子7: 知名VC/PE ======
    has_vc = params.get("has_top_vc", False)
    cs_names = params.get("cornerstone_names", [])
    cs_str = " ".join(str(n) for n in cs_names) if cs_names else ""
    # 内置VC匹配
    if any(vc in cs_str for vc in TOP_VCS):
        has_vc = True
    # 扩展VC匹配（extra_vcs参数）
    extra_vcs = params.get("extra_vcs", [])
    if extra_vcs and any(ev in cs_str for ev in extra_vcs):
        has_vc = True
    vc_pts = p["vc_pts"] if has_vc else 0
    score += vc_pts
    factors.append({"factor": "知名VC/PE", "group": "5.早期投资方", "points": vc_pts,
                     "detail": f"{'有知名VC→' + str(vc_pts) + '分' if has_vc else '无→0分'}",
                     "iv": 2.76, "max_score": p["vc_pts"]})

    # ====== 因子8: 基石质量 ======
    if cs_names:
        has_top = any(vc in cs_str for vc in {"高瓴", "红杉", "淡马锡", "贝莱德"})
        has_pro = any(vc in cs_str for vc in PROFESSIONAL_VCS)
        if has_top and has_pro:
            cq, cq_pts = "顶级+专业", p["cs_quality_top"]
        elif has_top:
            cq, cq_pts = "顶级", 3
        elif has_pro:
            cq, cq_pts = "专业", 2
        else:
            cq, cq_pts = "一般", 1
    else:
        cq, cq_pts = "无基石", 0
    score += cq_pts
    factors.append({"factor": "基石质量", "group": "4.基石投资者", "points": cq_pts,
                     "detail": f"{cq}→{cq_pts}分",
                     "iv": 1.15, "max_score": p["cs_quality_top"]})

    # ====== 因子9: 自由流通比例 ======
    ff = safe_float(params.get("free_float_pct"), safe_float(params.get("public_pct"), 10))
    if ff < 10:
        fl_pts = p["float_pts"]
    elif ff < 20:
        fl_pts = 1
    else:
        fl_pts = 0
    score += fl_pts
    factors.append({"factor": "自由流通", "group": "9.筹码结构", "points": fl_pts,
                     "detail": f"流通{ff:.0f}%→{fl_pts}分",
                     "iv": 0.0, "max_score": p["float_pts"]})

    # ====== 因子10: 政策催化 ======
    policy = params.get("policy_catalyst", False)
    if is_18a or is_hot_track:
        policy = True
    pol_pts = p["policy_pts"] if policy else 0
    score += pol_pts
    factors.append({"factor": "政策催化", "group": "1.赛道热度", "points": pol_pts,
                     "detail": f"{'有催化→' + str(pol_pts) + '分' if policy else '无→0分'}",
                     "iv": 0.63, "max_score": p["policy_pts"]})

    # ====== 因子11: 研发占比 ======
    rd = safe_float(params.get("rd_ratio"), 5)
    if rd >= 50:
        rd_pts = p["rd_pts"]
    elif rd >= 20:
        rd_pts = 1
    else:
        rd_pts = 0
    score += rd_pts
    factors.append({"factor": "研发占比", "group": "11.财务基本面", "points": rd_pts,
                     "detail": f"研发{rd:.0f}%→{rd_pts}分",
                     "iv": 1.82, "max_score": p["rd_pts"]})

    # ====== 因子12: 入通时间 ======
    dc = params.get("days_to_connect", 90)
    if dc <= 15:
        conn_pts = p["connect_pts"]
    elif dc <= 45:
        conn_pts = 1
    else:
        conn_pts = 0
    score += conn_pts
    factors.append({"factor": "入通时间", "group": "6.入通效应", "points": conn_pts,
                     "detail": f"入通{dc}天→{conn_pts}分",
                     "iv": 3.08, "max_score": p["connect_pts"]})

    # ====== 因子13: 保荐人质量 ======
    sq = params.get("sponsor_quality", "")
    if "顶级" in sq and "外资" in sq:
        sp_pts = p["sponsor_pts"]
    elif "外资" in sq:
        sp_pts = 1
    else:
        sp_pts = 0
    score += sp_pts
    factors.append({"factor": "保荐人质量", "group": "3.承销商战绩", "points": sp_pts,
                     "detail": f"{sq or '未知'}→{sp_pts}分",
                     "iv": 0.46, "max_score": p["sponsor_pts"]})

    # ====== 因子14: 营收增速 ======
    rg = safe_float(params.get("rev_growth"), 20)
    if rg >= 80:
        rg_pts = 3
    elif rg >= 30:
        rg_pts = 2
    elif rg >= 10:
        rg_pts = 1
    else:
        rg_pts = 0
    score += rg_pts
    factors.append({"factor": "营收增速", "group": "11.财务基本面", "points": rg_pts,
                     "detail": f"增速{rg:.0f}%→{rg_pts}分",
                     "iv": 0.92, "max_score": 3})

    # ====== 因子15: 知名消费品牌（V7新增，V7.1支持外部传入） ======
    name = params.get("name", "")
    # 优先级：consumer_brand布尔值 > 内置名单+扩展名单匹配
    if params.get("consumer_brand") is True:
        is_consumer_brand = True
        cb_source = "AI Agent判定"
    else:
        # 合并内置名单和扩展关键词
        all_brands = CONSUMER_BRANDS + params.get("extra_consumer_brands", [])
        is_consumer_brand = any(b in name for b in all_brands)
        cb_source = "内置名单匹配" if any(b in name for b in CONSUMER_BRANDS) else "扩展名单匹配" if is_consumer_brand else ""
    cb_pts = p["consumer_brand"] if is_consumer_brand else 0
    score += cb_pts
    cb_detail = f"知名消费品牌({cb_source})→{cb_pts}分" if is_consumer_brand else "非消费品牌→0分"
    factors.append({"factor": "知名消费品牌", "group": "1.赛道热度", "points": cb_pts,
                     "detail": cb_detail,
                     "iv": None, "max_score": p["consumer_brand"]})

    # ====== 因子16: 小盘妖股信号（V7新增） ======
    # 超购缺失+无基石+低流通=小盘妖股
    if oversub_missing and cs_pct == 0 and ff < 20:
        sm_pts = p["small_monster"]
        sm_detail = f"小盘妖股信号(超购缺+无基石+低流通{ff:.0f}%)→{sm_pts}分"
    else:
        sm_pts = 0
        sm_detail = "无小盘妖股特征→0分"
    score += sm_pts
    factors.append({"factor": "小盘妖股信号", "group": "9.筹码结构", "points": sm_pts,
                     "detail": sm_detail,
                     "iv": None, "max_score": p["small_monster"]})

    # ====== 交互因子1: A+H + 热门赛道（V7: -3, 从-15大幅降低） ======
    interaction1 = 0
    if is_ah and is_hot_track:
        interaction1 = p["interaction_ah_hot"]
        score += interaction1
        factors.append({"factor": "⚠️交互:A+H+热门赛道", "group": "交互因子", "points": interaction1,
                         "detail": f"A+H+{track_name}→{interaction1}分(定价锚效应,但A+H+AI仍可超涨)",
                         "iv": None, "max_score": 0})

    # ====== 交互因子2: 低超购 + 热门赛道（V7: -15, 从-8加强） ======
    interaction2 = 0
    if not oversub_missing and oversub < 500 and is_hot_track:
        interaction2 = p["interaction_low_os_hot"]
        score += interaction2
        factors.append({"factor": "⚠️交互:低超购+热门赛道", "group": "交互因子", "points": interaction2,
                         "detail": f"超购{oversub:.0f}倍+热门赛道→{interaction2}分(市场认可度不足)",
                         "iv": None, "max_score": 0})

    # ====== 交互因子3: 高超购+消费品牌（V7新增） ======
    interaction3 = 0
    if not oversub_missing and oversub >= 100 and is_consumer_brand:
        interaction3 = p["interaction_highos_consumer"]
        score += interaction3
        factors.append({"factor": "✅交互:高超购+消费品牌", "group": "交互因子", "points": interaction3,
                         "detail": f"超购{oversub:.0f}倍+知名消费品牌→{interaction3}分",
                         "iv": None, "max_score": 0})

    # ====== 交互因子4: 首日暴跌+18A双杀（V7新增） ======
    interaction4 = 0
    if fd_available and fd_chg < -30 and is_18a:
        interaction4 = p["interaction_crash_18a"]
        score += interaction4
        factors.append({"factor": "⚠️交互:暴跌+18A双杀", "group": "交互因子", "points": interaction4,
                         "detail": f"首日{fd_chg:.0f}%+18A→{interaction4}分(双杀)",
                         "iv": None, "max_score": 0})

    # ====== 交互因子5: 首日暴涨+虚假热情（V7新增） ======
    interaction5 = 0
    if fd_available and fd_chg >= 100 and not oversub_missing and oversub >= 5000:
        interaction5 = p["interaction_surge_fake"]
        score += interaction5
        factors.append({"factor": "⚠️交互:暴涨+虚假热情", "group": "交互因子", "points": interaction5,
                         "detail": f"首日+{fd_chg:.0f}%+超购{oversub:.0f}倍(虚假热情)→{interaction5}分",
                         "iv": None, "max_score": 0})

    score = max(score, 0)

    # ====== 评级（V7阈值修订，基于84样本） ======
    if score >= 40:
        rating, rating_detail = "极高概率超涨", "历史精确率96%"
    elif score >= 30:
        rating, rating_detail = "高概率超涨", "历史精确率93%"
    elif score >= 25:
        rating, rating_detail = "可能超涨", "历史精确率81%"
    elif score >= 20:
        rating, rating_detail = "谨慎关注", "历史精确率~50%"
    else:
        rating, rating_detail = "不太可能超涨", "历史精确率~20%"

    # ====== 信号 ======
    positive_signals = [f["detail"] for f in factors if f["points"] > 0 and "交互" not in f["factor"] and "⚠️" not in f["factor"]]
    risk_signals = [f["detail"] for f in factors if f["points"] < 0]
    warnings = []

    if not oversub_missing and oversub >= 5000 and fd_available and fd_chg < 50:
        warnings.append(f"⚠️ 超购{oversub:.0f}倍极高但首日未大涨，属于'虚假热情'陷阱")
    if fd_available and fd_chg < -30:
        warnings.append(f"⚠️ 首日{fd_chg:.0f}%暴跌，后期翻倍概率极低（0%超涨率）")
    if fd_available and -20 <= fd_chg < 0:
        warnings.append("💡 首日微跌不等于不会超涨（古茗首日-5%→后期+208%，兆易创新-3%→+250%）")
    if is_ah and score >= 25:
        warnings.append("⚠️ A+H股定价锚效应，但部分A+H+AI股仍可超涨（如兆易创新+250%）")
    if not oversub_missing and oversub < 100 and is_hot_track:
        warnings.append("⚠️ 热门赛道但超购不足100倍，市场认可度可能不够")
    if score >= 30 and not is_ah and is_hot_track:
        warnings.append("💡 AI/半导体赛道后期涨幅可能远超首日（参考：智谱首日+13%→最大+761%）")
    if oversub_missing:
        warnings.append("ℹ️ 超购数据缺失，评分不含超购因子，建议补充数据后重新评估")
    if not fd_available:
        warnings.append("ℹ️ 首日涨跌幅数据缺失(上市前评估)，评分不含首日因子")

    # ====== 可比案例 ======
    comparable_cases = get_comparable_cases(track, is_ah, oversub, oversub_missing)

    # 动态计算理论最高分：基于当前持仓的实际因子能否达到
    # 包括所有可能的正向因子 + 一个正向交互(+8)，排除负向
    max_fd = p["fd_100"]                       # 首日最高+28
    max_os = p["os_5k_surge"] if not oversub_missing else 0  # 超购真热情+6
    max_ah = p["ah_bonus"] if not is_ah else 0               # 纯H股+3
    max_track = p["track_ai"]                                 # AI赛道+10
    max_first = p["first_stock"]                              # 第一股+10
    max_cs = p["cs_pct_top"]                                  # 基石≥40%+6
    max_18a = p["18a_pts"]                                    # 18A+5
    max_vc = p["vc_pts"]                                      # VC+8
    max_cs_q = p["cs_quality_top"]                            # 基石质量顶级+4
    max_ff = p["float_pts"]                                   # 低流通+2
    max_policy = p["policy_pts"]                              # 政策催化+3
    max_rd = p["rd_pts"]                                      # 研发+2
    max_connect = p["connect_pts"]                            # 入通+2
    max_sponsor = p["sponsor_pts"]                            # 保荐人+2
    max_rev = p["rev_growth_pts"]                             # 营收+3
    max_cb = p["consumer_brand"] if params.get("consumer_brand") or is_consumer_brand else 0
    max_sm = p["small_monster"]                               # 小盘妖股+10
    max_interaction = p["interaction_highos_consumer"]        # 高超购+消费+8
    max_possible = sum([max_fd, max_os, max_ah, max_track, max_first, max_cs,
                        max_18a, max_vc, max_cs_q, max_ff, max_policy, max_rd,
                        max_connect, max_sponsor, max_rev, max_cb, max_sm,
                        max_interaction])

    risk_disclaimers = [
        "本评分基于历史数据统计模型，不构成投资建议",
        f"模型AUC={AUC}，存在约{round((1-AUC)*100)}%的误判概率",
        "超涨定义：上市10日后收盘价≥发行价×2(翻倍)",
        "历史超涨率不代表未来收益，市场环境可能变化",
    ]

    # ====== 报告生成指引（防止低IV因子被错误强调） ======
    # 按IV/权重排序，提取可作为标题的正面因子
    headline_factors = []
    body_factors = []
    footnote_factors = []
    for f in factors:
        if f["points"] == 0 and "交互" not in f["factor"]:
            continue
        emphasis = _get_emphasis(f["factor"])
        entry = {"factor": f["factor"], "points": f["points"], "detail": f["detail"]}
        if emphasis == "headline":
            headline_factors.append(entry)
        elif emphasis == "body":
            body_factors.append(entry)
        else:
            footnote_factors.append(entry)

    # 检查是否有低IV因子被错误作为正面对象
    oversub_headline_warning = ""
    for f in factors:
        if "超购" in f["factor"] and f["points"] > 0 and _get_emphasis(f["factor"]) == "footnote":
            oversub_headline_warning = (
                "⚠️ 超购倍数IV=1.01（预测力垫底），不可作为报告标题或核心卖点。"
                "超购仅用于：①风险过滤（虚假热情-5分）②交互辅助（低超购+AI=-15分）。"
                "报告核心卖点应从以下高IV因子中选取：首日涨跌幅(IV=8.22)、第一股标签(IV=3.01)、"
                "知名VC/PE(IV=2.76)、赛道热度(IV=0.99)"
            )

    report_guidance = {
        "headline_factors": headline_factors,      # 可用作报告标题/核心卖点
        "body_factors": body_factors,              # 正文提及
        "footnote_factors": footnote_factors,      # 仅脚注/辅助说明
        "oversub_headline_warning": oversub_headline_warning,
        "rules": [
            "超购倍数(IV=1.01)禁止作为报告标题或核心卖点，只能作为风险信号或辅助说明",
            "报告标题/核心卖点必须从headline_factors中选取",
            "超购≥5000倍且首日未大涨时，应标注'虚假热情陷阱'而非卖点",
            "超购倍数仅在交互因子语境下有意义（如低超购+AI=-15分惩罚）",
        ],
    }

    # ====== 数据质量检查（防止发行价/价格错误导致结论翻车） ======
    data_quality = _check_data_quality(params, score, factors)

    return {
        "name": params.get("name", ""),
        "factors": factors,
        "total_score": score,
        "max_possible": max_possible,
        "score_pct": round(score / max_possible * 100, 1) if max_possible else 0,
        "rating": {"level": rating, "detail": rating_detail},
        "positive_signals": positive_signals,
        "risk_signals": risk_signals,
        "warnings": warnings,
        "comparable_cases": comparable_cases,
        "risk_disclaimers": risk_disclaimers,
        "report_guidance": report_guidance,
        "data_quality": data_quality,
    }


def get_comparable_cases(track: str, is_ah: bool, oversub: float, oversub_missing: bool = False) -> List[str]:
    """返回历史可比案例"""
    if "AI" in track and not is_ah and (oversub_missing or oversub >= 1000):
        return [
            "极视角(06636): AI+4591倍超购, V7涨幅+206%",
            "群核科技(00068): AI+2500倍超购, 后期暴涨",
            "海致科技(02706): AI+5065倍超购, V7涨幅+240%",
        ]
    elif "医疗" in track or "18A" in track:
        return [
            "德适-B(02526): 18A+1073倍超购, V7涨幅+196%",
            "映恩生物-B(09606): 18A+首日+117%, V7涨幅+439%",
        ]
    elif "机器人" in track:
        return [
            "傅里叶(03625): 机器人+3118倍超购, V7涨幅+216%",
            "凯乐士(02729): 机器人+2153倍超购, V7涨幅+152%",
        ]
    elif "新能源" in track:
        return [
            "挚达科技(02650): 充电桩+5440倍超购, V7涨幅+386%",
        ]
    return []


def get_info() -> Dict[str, Any]:
    """返回模型信息"""
    return {
        "version": VERSION,
        "auc": AUC,
        "model_type": "无数据泄露（仅事前因子+首日因子）+ 首日跌幅精细化分段",
        "model_date": MODEL_DATE,
        "total_factors": 40,
        "significant_factors": 28,
        "scoring_factors": 17,
        "interactions": 5,
        "surge_definition": "上市10日后收盘价≥发行价×2(翻倍)=超涨",
        "sample": "84只港股IPO(2025.01-2026.04), V7标签",
        "v7_key_changes": [
            "超涨定义升级：最大涨幅≥50% → 上市10日后收盘价翻倍",
            "样本扩充：55只 → 84只有效样本（+53%）",
            "首日涨跌幅分段处理：微跌(-20~0%)不惩罚，暴跌(<-40%)扣18分",
            "超高购+首日大涨=真热情(+6), 否则虚假热情(-5)",
            "A+H×热门赛道交互从-15→-3（兆易创新A+H+AI实际+250%）",
            "低超购+AI交互从-8→-15（加强惩罚市场认可度不足）",
            "新增4因子：首日涨跌幅、小盘妖股、知名消费品牌、高超购消费",
            "AUC从0.9150→0.9784（+6.3pp）",
        ],
        "factor_groups": [
            {"group": "7.首日表现", "factors": ["首日涨跌幅(28/-18)"], "iv_range": "8.22", "note": "V7新增"},
            {"group": "1.赛道热度", "factors": ["赛道分类(10)", "政策催化(3)", "知名消费品牌(12)"], "iv_range": "0.63-0.99"},
            {"group": "2.题材稀缺性", "factors": ["第一股标签(10)"], "iv_range": "3.01"},
            {"group": "3.承销商战绩", "factors": ["保荐人质量(2)"], "iv_range": "0.46"},
            {"group": "4.基石投资者", "factors": ["基石占比(6)", "基石质量(4)"], "iv_range": "1.15-2.08"},
            {"group": "5.早期投资方", "factors": ["知名VC/PE(8)"], "iv_range": "2.76"},
            {"group": "6.入通效应", "factors": ["入通时间(2)"], "iv_range": "3.08"},
            {"group": "9.筹码结构", "factors": ["自由流通(2)", "小盘妖股(10)"], "iv_range": "0-~0"},
            {"group": "11.财务基本面", "factors": ["研发占比(2)", "营收增速(3)"], "iv_range": "0.92-1.82"},
            {"group": "核心因子", "factors": ["超购倍数(6/-5)", "纯H(3)", "18A(5)"], "iv_range": "1.01-2.27"},
            {"group": "交互因子", "factors": ["A+H+热门(-3)", "低超购+热门(-15)", "高超购+消费(8)", "暴跌+18A(-8)", "暴涨+虚假热情(-15)"], "iv_range": "N/A"},
        ],
    }


def main() -> None:
    """主入口"""
    import time
    start = time.time()

    try:
        input_data = json.load(sys.stdin)
    except json.JSONDecodeError as e:
        output_error("INVALID_INPUT", f"JSON解析错误: {e}")
        return

    action = input_data.get("action", "score")
    params = input_data.get("params", {})
    duration = int((time.time() - start) * 1000)

    if action == "info":
        output_success(get_info(), duration)
    elif action == "validate":
        result = validate_params(params)
        output_success(result, duration)
    elif action == "score":
        # 先校验
        validation = validate_params(params)
        if not validation["valid"]:
            output_error("INVALID_INPUT", "参数校验失败", {"errors": validation["errors"]})
            return

        result = score_stock(params)
        output_success(result, duration)
    else:
        output_error("INVALID_INPUT", f"未知action: {action}，支持: score/info/validate")


if __name__ == "__main__":
    main()
