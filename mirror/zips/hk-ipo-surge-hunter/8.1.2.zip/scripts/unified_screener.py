#!/usr/bin/env python3
"""
港股次新股统一50%上行筛选器 V1.0
从当前价出发，筛选所有还有50%+上行空间的港股次新股。

核心逻辑：
  1. 所有标的按涨幅分流：
     - 已翻倍(gain≥100%) → 二次爆发模型V1评分，评估再涨50%
     - 未翻倍(gain<100%) → V7评分，计算翻倍目标价到当前价的上行空间
  2. 统一输出：按当前价上行50%的可行性排序

注意：本脚本是组合路由器，不是新评分模型。
  - 已翻倍股：直接使用 second_surge_scorer.py 的评分结果
  - 未翻倍股：直接使用 hk_ipo_scorer.py 的评分结果
  - 本脚本负责：分流 + 上行空间计算 + 合并排序 + 统一输出

使用方式:
  echo '{"action":"screen","params":{...}}' | python3 unified_screener.py

Actions:
  screen    - 执行统一筛选（单只或批量）
  info      - 返回筛选器信息
  validate  - 校验输入参数

V2接口契约:
  输入: stdin JSON
  输出: stdout JSON（含 success/error/metadata）
"""

import json
import sys
from typing import Any, Dict, List, Optional

# ====== 版本信息 ======
VERSION = "V1.0"
SCREENER_DATE = "2026-04-24"

# ====== 上行空间阈值 ======
UPSIDE_THRESHOLD = 50  # 最低上行空间百分比（50%）

# ====== 筛选阈值 ======
V7_MIN_SCORE = 40       # 未翻倍股：V7最低分（高概率翻倍）
SS_MIN_SCORE = 35       # 已翻倍股：二次爆发最低分


def _compute_v7_upside(current_price: float, issue_price: float) -> Optional[float]:
    """
    计算未翻倍股从当前价到翻倍目标价的上行空间。
    
    翻倍目标价 = 发行价 × 2
    上行空间 = (翻倍目标价 - 当前价) / 当前价 × 100%
    
    Returns:
        上行空间百分比，如果当前价已超过翻倍目标价返回None
    """
    if not current_price or current_price <= 0 or not issue_price or issue_price <= 0:
        return None
    
    target_price = issue_price * 2
    if current_price >= target_price:
        return None  # 已翻倍，不应走这条路径
    
    upside = (target_price - current_price) / current_price * 100
    return round(upside, 1)


def _classify_stock(gain_pct: float) -> str:
    """根据累计涨幅分流：已翻倍 vs 未翻倍"""
    if gain_pct >= 100:
        return "doubled"  # 已翻倍 → 二次爆发
    else:
        return "not_doubled"  # 未翻倍 → V7


def screen_single(params: Dict[str, Any]) -> Dict[str, Any]:
    """
    对单只股票执行统一筛选。
    
    输入参数说明：
    - 必需：name, current_price, issue_price
    - 已翻倍股需额外提供：second_surge_score（二次爆发评分）
    - 未翻倍股需额外提供：v7_score（V7评分）
    - 可选：gain_pct（自动计算或手动提供）、second_surge_data、v7_data
    """
    name = params.get("name", "未知")
    code = params.get("code", "")
    current_price = float(params.get("current_price", 0))
    issue_price = float(params.get("issue_price", 0))
    
    if not current_price or not issue_price:
        return {
            "name": name,
            "code": code,
            "eligible": False,
            "reason": "缺少current_price或issue_price",
        }
    
    # 计算或获取涨幅
    gain_pct = params.get("gain_pct")
    if gain_pct is None:
        gain_pct = (current_price - issue_price) / issue_price * 100
    else:
        gain_pct = float(gain_pct)
    
    # 分流
    stock_type = _classify_stock(gain_pct)
    
    # 目标价：当前价 × 1.5
    target_50pct = round(current_price * 1.5, 2)
    
    if stock_type == "doubled":
        # ===== 已翻倍股：二次爆发模型 =====
        ss_score = params.get("second_surge_score")
        ss_data = params.get("second_surge_data")  # 完整二次爆发评分结果
        
        if ss_score is None:
            return {
                "name": name,
                "code": code,
                "stock_type": "doubled",
                "eligible": False,
                "reason": "已翻倍股需提供second_surge_score（二次爆发评分）",
                "gain_pct": round(gain_pct, 1),
                "current_price": current_price,
                "issue_price": issue_price,
                "target_50pct": target_50pct,
            }
        
        ss_score = int(ss_score)
        
        # 二次爆发评级
        if ss_score >= 40:
            ss_rating = "🟢 强候选"
        elif ss_score >= 35:
            ss_rating = "🟡 候选"
        elif ss_score >= 30:
            ss_rating = "🟠 观察名单"
        else:
            ss_rating = "🔴 不推荐"
        
        eligible = ss_score >= SS_MIN_SCORE
        
        result = {
            "name": name,
            "code": code,
            "stock_type": "doubled",
            "gain_pct": round(gain_pct, 1),
            "current_price": current_price,
            "issue_price": issue_price,
            "target_50pct": target_50pct,
            "model": "二次爆发V1",
            "score": ss_score,
            "max_score": 50,
            "score_pct": round(ss_score / 50 * 100, 1),
            "rating": ss_rating,
            "eligible": eligible,
            "eligible_reason": f"二次爆发分{ss_score}{'≥' if eligible else '<'}{SS_MIN_SCORE}" if eligible else f"二次爆发分{ss_score}<{SS_MIN_SCORE}，不够候选门槛",
            "upside_type": "定性评估",
            "upside_note": "二次爆发模型评估当前价再涨50%+的概率",
        }
        
        if ss_data:
            result["detail"] = ss_data
        
        return result
    
    else:
        # ===== 未翻倍股：V7模型 =====
        v7_score = params.get("v7_score")
        v7_data = params.get("v7_data")  # 完整V7评分结果
        
        if v7_score is None:
            return {
                "name": name,
                "code": code,
                "stock_type": "not_doubled",
                "eligible": False,
                "reason": "未翻倍股需提供v7_score（V7评分）",
                "gain_pct": round(gain_pct, 1),
                "current_price": current_price,
                "issue_price": issue_price,
                "target_50pct": target_50pct,
            }
        
        v7_score = int(v7_score)
        
        # 计算翻倍目标价到当前价的上行空间
        v7_upside = _compute_v7_upside(current_price, issue_price)
        
        if v7_upside is None:
            return {
                "name": name,
                "code": code,
                "stock_type": "not_doubled",
                "gain_pct": round(gain_pct, 1),
                "current_price": current_price,
                "issue_price": issue_price,
                "target_50pct": target_50pct,
                "model": "V7",
                "score": v7_score,
                "eligible": False,
                "reason": "当前价已超过翻倍目标价，应使用二次爆发模型",
            }
        
        # 翻倍目标价
        double_target = round(issue_price * 2, 2)
        
        # 双重条件：V7≥40 且 上行空间≥50%
        v7_pass = v7_score >= V7_MIN_SCORE
        upside_pass = v7_upside >= UPSIDE_THRESHOLD
        eligible = v7_pass and upside_pass
        
        # 不入选原因
        if eligible:
            eligible_reason = f"V7={v7_score}≥{V7_MIN_SCORE}，上行空间{v7_upside}%≥{UPSIDE_THRESHOLD}%"
        else:
            reasons = []
            if not v7_pass:
                reasons.append(f"V7={v7_score}<{V7_MIN_SCORE}")
            if not upside_pass:
                reasons.append(f"上行空间{v7_upside}%<{UPSIDE_THRESHOLD}%")
            eligible_reason = "，".join(reasons)
        
        result = {
            "name": name,
            "code": code,
            "stock_type": "not_doubled",
            "gain_pct": round(gain_pct, 1),
            "current_price": current_price,
            "issue_price": issue_price,
            "double_target": double_target,
            "target_50pct": target_50pct,
            "model": "V7",
            "score": v7_score,
            "v7_upside_pct": v7_upside,
            "eligible": eligible,
            "eligible_reason": eligible_reason,
            "upside_type": "量化计算",
            "upside_note": f"从当前价{current_price}到翻倍目标{double_target}的上行空间={v7_upside}%",
        }
        
        if v7_data:
            result["detail"] = v7_data
        
        return result


def screen_batch(params: Dict[str, Any]) -> Dict[str, Any]:
    """
    批量统一筛选。
    
    输入：stocks 数组，每个元素包含 screen_single 所需的参数
    输出：合并排序后的筛选结果
    """
    stocks = params.get("stocks", [])
    if not stocks:
        return {
            "total_input": 0,
            "eligible": [],
            "ineligible": [],
            "summary": "无输入数据",
        }
    
    eligible_list = []
    ineligible_list = []
    
    for stock in stocks:
        result = screen_single(stock)
        if result.get("eligible"):
            eligible_list.append(result)
        else:
            ineligible_list.append(result)
    
    # 入选标的排序：已翻倍按二次爆发分降序，未翻倍按上行空间降序
    def sort_key(x):
        if x.get("stock_type") == "doubled":
            return (0, -x.get("score", 0))  # 二次爆发分高的排前面
        else:
            return (1, -x.get("v7_upside_pct", 0))  # 上行空间大的排前面
    
    eligible_list.sort(key=sort_key)
    
    # 摘要统计
    def _get_gain_pct(s):
        gp = s.get("gain_pct")
        if gp is not None:
            return float(gp)
        cp = float(s.get("current_price", 0))
        ip = float(s.get("issue_price", 0))
        if ip > 0:
            return (cp - ip) / ip * 100
        return 0

    doubled_count = sum(1 for s in stocks if _classify_stock(_get_gain_pct(s)) == "doubled")
    not_doubled_count = len(stocks) - doubled_count
    
    eligible_doubled = sum(1 for e in eligible_list if e.get("stock_type") == "doubled")
    eligible_not_doubled = sum(1 for e in eligible_list if e.get("stock_type") == "not_doubled")
    
    return {
        "total_input": len(stocks),
        "total_doubled": doubled_count,
        "total_not_doubled": not_doubled_count,
        "eligible_count": len(eligible_list),
        "eligible_doubled": eligible_doubled,
        "eligible_not_doubled": eligible_not_doubled,
        "eligible": eligible_list,
        "ineligible": ineligible_list,
        "thresholds": {
            "v7_min_score": V7_MIN_SCORE,
            "ss_min_score": SS_MIN_SCORE,
            "upside_min_pct": UPSIDE_THRESHOLD,
        },
        "summary": f"共{len(stocks)}只：{doubled_count}只已翻倍({eligible_doubled}只入选)、{not_doubled_count}只未翻倍({eligible_not_doubled}只入选)",
    }


def info() -> Dict[str, Any]:
    """返回筛选器信息"""
    return {
        "model": "港股次新股统一50%上行筛选器",
        "version": VERSION,
        "date": SCREENER_DATE,
        "description": "从当前价出发，统一筛选所有还有50%+上行空间的港股次新股",
        "routing": {
            "doubled": {
                "condition": "gain_pct >= 100%",
                "model": "二次爆发V1",
                "threshold": f"二次爆发分 ≥ {SS_MIN_SCORE}",
                "upside_type": "定性评估",
            },
            "not_doubled": {
                "condition": "gain_pct < 100%",
                "model": "V7打新评分",
                "threshold": f"V7分 ≥ {V7_MIN_SCORE} 且 翻倍上行空间 ≥ {UPSIDE_THRESHOLD}%",
                "upside_type": "量化计算",
            },
        },
        "output": "按当前价上行空间排序的候选标的列表",
        "vs_individual_models": {
            "unified": "一个入口，自动路由，统一输出50%+上行视角",
            "v7_only": "只看未翻倍股的翻倍概率，不关心当前价上行空间",
            "ss_only": "只看已翻倍股的二次爆发，不覆盖未翻倍股",
        },
    }


def validate(params: Dict[str, Any]) -> Dict[str, Any]:
    """校验输入参数"""
    errors = []
    warnings = []
    
    stocks = params.get("stocks")
    if stocks:
        # 批量模式
        for i, s in enumerate(stocks):
            if not s.get("name"):
                errors.append(f"stocks[{i}]: name为必需参数")
            if not s.get("current_price") or float(s.get("current_price", 0)) <= 0:
                errors.append(f"stocks[{i}]: current_price必须>0")
            if not s.get("issue_price") or float(s.get("issue_price", 0)) <= 0:
                errors.append(f"stocks[{i}]: issue_price必须>0")
    else:
        # 单只模式
        if not params.get("name"):
            errors.append("name为必需参数")
        if not params.get("current_price") or float(params.get("current_price", 0)) <= 0:
            errors.append("current_price必须>0")
        if not params.get("issue_price") or float(params.get("issue_price", 0)) <= 0:
            errors.append("issue_price必须>0")
        
        # 提醒：需要提供对应模型的评分
        gain_pct = params.get("gain_pct")
        if gain_pct is not None:
            gain_pct = float(gain_pct)
        else:
            cp = float(params.get("current_price", 0))
            ip = float(params.get("issue_price", 0))
            if ip > 0:
                gain_pct = (cp - ip) / ip * 100
        
        if gain_pct is not None:
            if gain_pct >= 100:
                if params.get("second_surge_score") is None:
                    warnings.append("已翻倍股需提供second_surge_score（二次爆发评分）")
            else:
                if params.get("v7_score") is None:
                    warnings.append("未翻倍股需提供v7_score（V7评分）")
    
    return {
        "valid": len(errors) == 0,
        "errors": errors,
        "warnings": warnings,
    }


def main():
    """主入口：读取stdin JSON，执行action，输出stdout JSON"""
    try:
        raw = sys.stdin.read().strip()
        if not raw:
            print(json.dumps({
                "success": False,
                "error": "EMPTY_INPUT",
                "message": "stdin为空，请提供JSON输入"
            }, ensure_ascii=False))
            return

        data = json.loads(raw)
        action = data.get("action", "screen")
        params = data.get("params", {})

        if action == "screen":
            # 判断单只还是批量
            if params.get("stocks"):
                result = screen_batch(params)
            else:
                result = screen_single(params)
            
            print(json.dumps({
                "success": True,
                "data": result,
                "metadata": {
                    "script": "unified_screener.py",
                    "version": VERSION,
                    "date": SCREENER_DATE,
                }
            }, ensure_ascii=False, indent=2))

        elif action == "info":
            print(json.dumps({
                "success": True,
                "data": info(),
                "metadata": {
                    "script": "unified_screener.py",
                    "version": VERSION,
                }
            }, ensure_ascii=False, indent=2))

        elif action == "validate":
            print(json.dumps({
                "success": True,
                "data": validate(params),
            }, ensure_ascii=False, indent=2))

        else:
            print(json.dumps({
                "success": False,
                "error": "UNKNOWN_ACTION",
                "message": f"未知action: {action}，支持: screen/info/validate"
            }, ensure_ascii=False))

    except json.JSONDecodeError as e:
        print(json.dumps({
            "success": False,
            "error": "INVALID_JSON",
            "message": f"JSON解析失败: {str(e)}"
        }, ensure_ascii=False))
    except Exception as e:
        print(json.dumps({
            "success": False,
            "error": "INTERNAL_ERROR",
            "message": str(e)
        }, ensure_ascii=False))


if __name__ == "__main__":
    main()
