#!/usr/bin/env python3
"""
港股IPO翻倍股二次爆发评分脚本 V1.0
针对已翻倍（当前价≥发行价×2）的港股次新股，评估从当前价再涨50%+的可能性。

与V7模型（IPO因子→预测发行价翻倍）完全独立：
- V7因子：超购/基石/首日表现/赛道/18A等（事前因子，一次性）
- 二次爆发因子：行业景气度/业绩兑现/机构认可/催化管线/估值空间（动态因子，持续更新）

评分模型：
- 5个核心维度，每维度10分，满分50分
- ≥35分=二次爆发候选，≥40分=强候选
- 基于定性分析框架，非量化回测（翻倍后再涨50%历史样本不足）

使用方式:
  echo '{"action":"score","params":{...}}' | python3 second_surge_scorer.py

Actions:
  score   - 计算评分
  info    - 返回模型信息
  validate - 校验输入参数

V2接口契约:
  输入: stdin JSON
  输出: stdout JSON（含 success/error/metadata）
"""

import json
import sys
from typing import Any, Dict, List, Optional

# ====== 版本信息 ======
VERSION = "V1.0"
MODEL_DATE = "2026-04-24"

# ====== 二次爆发评分参数 ======
# 5个维度，每维度0-10分，总分50分

PARAMS = {
    # 1. 行业景气度 (0-10)
    "industry_ai_surge": 10,       # AI大模型/算力处于爆发加速期
    "industry_ai_growth": 8,       # AI应用/半导体等高增长
    "industry_robot": 7,           # 机器人产业化拐点
    "industry_medical_ai": 7,      # AI+医疗政策强驱动
    "industry_medical": 6,         # 医疗/创新药稳定
    "industry_new_energy": 6,      # 新能源周期波动
    "industry_chip": 7,            # 半导体国产替代
    "industry_consumer": 4,        # 消费复苏缓慢
    "industry_traditional": 2,     # 传统行业景气低迷

    # 2. 业绩兑现度 (0-10)
    "earn_rev_3x": 10,             # 营收增速≥200%
    "earn_rev_2x": 8,              # 营收增速≥100%
    "earn_rev_50": 6,              # 营收增速≥50%
    "earn_rev_30": 4,              # 营收增速≥30%
    "earn_rev_10": 2,              # 营收增速≥10%
    "earn_rev_neg": 0,             # 营收负增长
    "earn_profit_strong": 2,       # 已盈利且利润高增（加分）
    "earn_margin_high": 2,         # 毛利率≥60%（加分）
    "earn_loss_expanding": -2,     # 亏损扩大（减分）
    "earn_scale_tiny": -1,         # 营收<2亿（规模太小，减分）

    # 3. 机构认可度 (0-10)
    "inst_multi_buy": 10,          # 3家以上券商买入/增持
    "inst_two_buy": 7,             # 2家券商买入
    "inst_one_buy": 5,             # 1家券商买入
    "inst_target_upside_30": 3,    # 机构目标价≥当前价×1.3（加分）
    "inst_target_upside_50": 5,    # 机构目标价≥当前价×1.5（加分）
    "inst_no_coverage": 1,         # 无机构覆盖

    # 4. 催化剂管线 (0-10)
    "catalyst_major_soon": 10,     # 1-3月内有重大催化（产品发布/获批/入通）
    "catalyst_major_near": 7,      # 3-6月内有重大催化
    "catalyst_minor_soon": 5,      # 1-3月内有一般催化
    "catalyst_policy": 3,          # 政策催化明确（如AI+医疗2030目标）
    "catalyst_index_inclusion": 3, # 即将入通（南向资金预期）
    "catalyst_none_visible": 1,    # 无明确催化剂

    # 5. 估值空间 (0-10)
    # 基于当前涨幅和估值合理性判断
    "val_gain_just_doubled": 8,    # 刚翻倍（+100~130%），估值尚有空间
    "val_gain_2x": 6,              # 涨幅+130~200%，估值消化中
    "val_gain_3x": 4,              # 涨幅+200~400%，估值已高
    "val_gain_5x": 2,              # 涨幅+400~700%，估值极高
    "val_gain_7x": 1,              # 涨幅≥700%，估值泡沫风险
    "val_target_upside_50": 5,     # 机构共识目标价≥当前价×1.5（加分）
    "val_target_upside_30": 3,     # 机构共识目标价≥当前价×1.3（加分）
    "val_ah_anchor": -3,           # A+H溢价倒挂（A股定价锚限制上行）
    "val_profitable": 2,           # 已盈利（估值锚更清晰，加分）
    "val_loss_ps_extreme": -2,     # PS>300x且亏损（估值极不合理，减分）
}

# 评分阈值
THRESHOLDS = {
    "strong": 40,   # ≥40: 强候选
    "candidate": 35, # ≥35: 候选
    "watch": 30,    # ≥30: 观察名单
    "below": 30,    # <30: 不推荐
}


def _score_industry(track: str) -> tuple:
    """评分维度1：行业景气度"""
    track_lower = track.lower() if track else ""
    detail = ""
    score = PARAMS["industry_traditional"]

    if any(k in track_lower for k in ["ai大模型", "大模型", "llm", "agi"]):
        score = PARAMS["industry_ai_surge"]
        detail = "AI大模型处于爆发加速期"
    elif any(k in track_lower for k in ["ai", "gpu", "gpgpu", "算力"]):
        score = PARAMS["industry_ai_growth"]
        detail = "AI/算力赛道高景气"
    elif any(k in track_lower for k in ["机器人", "robot"]):
        score = PARAMS["industry_robot"]
        detail = "机器人产业化拐点"
    elif any(k in track_lower for k in ["医疗", "医学", "药", "18a"]):
        if any(k in track_lower for k in ["ai"]):
            score = PARAMS["industry_medical_ai"]
            detail = "AI+医疗政策强驱动"
        else:
            score = PARAMS["industry_medical"]
            detail = "医疗/创新药赛道稳定"
    elif any(k in track_lower for k in ["芯片", "半导体", "chip", "ic", "存储", "cis"]):
        score = PARAMS["industry_chip"]
        detail = "半导体国产替代加速"
    elif any(k in track_lower for k in ["新能源", "锂电", "光伏"]):
        score = PARAMS["industry_new_energy"]
        detail = "新能源周期波动"
    elif any(k in track_lower for k in ["消费", "食品", "饮料", "户外"]):
        score = PARAMS["industry_consumer"]
        detail = "消费赛道复苏缓慢"
    else:
        detail = "传统/一般行业景气度"

    return min(score, 10), detail


def _score_earnings(rev_growth: float, is_profitable: bool, gross_margin: float,
                    loss_expanding: bool, revenue_yi: float) -> tuple:
    """评分维度2：业绩兑现度"""
    score = 0
    details = []

    # 营收增速
    if rev_growth >= 200:
        score += PARAMS["earn_rev_3x"]
        details.append(f"营收增速{rev_growth:.0f}%≥200%，极高增长")
    elif rev_growth >= 100:
        score += PARAMS["earn_rev_2x"]
        details.append(f"营收增速{rev_growth:.0f}%≥100%，翻倍增长")
    elif rev_growth >= 50:
        score += PARAMS["earn_rev_50"]
        details.append(f"营收增速{rev_growth:.0f}%≥50%，高增长")
    elif rev_growth >= 30:
        score += PARAMS["earn_rev_30"]
        details.append(f"营收增速{rev_growth:.0f}%≥30%，稳健增长")
    elif rev_growth >= 10:
        score += PARAMS["earn_rev_10"]
        details.append(f"营收增速{rev_growth:.0f}%≥10%，低速增长")
    else:
        score += PARAMS["earn_rev_neg"]
        details.append(f"营收增速{rev_growth:.0f}%，负增长")

    # 盈利加分
    if is_profitable:
        score += PARAMS["earn_profit_strong"]
        details.append("已盈利，估值锚清晰")

    # 毛利率加分
    if gross_margin >= 60:
        score += PARAMS["earn_margin_high"]
        details.append(f"毛利率{gross_margin:.0f}%≥60%，商业模式优")

    # 亏损扩大减分
    if loss_expanding:
        score += PARAMS["earn_loss_expanding"]
        details.append("亏损扩大，需关注现金流")

    # 规模太小减分
    if revenue_yi > 0 and revenue_yi < 2:
        score += PARAMS["earn_scale_tiny"]
        details.append(f"营收{revenue_yi:.1f}亿<2亿，规模偏小")

    return max(min(score, 10), 0), "; ".join(details)


def _score_institution(analyst_count: int, target_upside: float) -> tuple:
    """评分维度3：机构认可度"""
    score = 0
    details = []

    # 券商覆盖
    if analyst_count >= 3:
        score += PARAMS["inst_multi_buy"]
        details.append(f"{analyst_count}家券商买入/增持")
    elif analyst_count == 2:
        score += PARAMS["inst_two_buy"]
        details.append("2家券商买入")
    elif analyst_count == 1:
        score += PARAMS["inst_one_buy"]
        details.append("1家券商买入")
    else:
        score += PARAMS["inst_no_coverage"]
        details.append("无机构覆盖")

    # 目标价上行空间
    if target_upside >= 50:
        score += PARAMS["inst_target_upside_50"]
        details.append(f"目标价上行空间{target_upside:.0f}%≥50%")
    elif target_upside >= 30:
        score += PARAMS["inst_target_upside_30"]
        details.append(f"目标价上行空间{target_upside:.0f}%≥30%")

    return min(score, 10), "; ".join(details)


def _score_catalyst(has_major_catalyst: bool, catalyst_timeline: str,
                    has_policy_catalyst: bool, index_inclusion_soon: bool) -> tuple:
    """评分维度4：催化剂管线"""
    score = 0
    details = []

    if has_major_catalyst:
        if catalyst_timeline in ("1-3月", "1-3m", "soon"):
            score += PARAMS["catalyst_major_soon"]
            details.append("1-3月内有重大催化")
        elif catalyst_timeline in ("3-6月", "3-6m", "near"):
            score += PARAMS["catalyst_major_near"]
            details.append("3-6月内有重大催化")
        else:
            score += PARAMS["catalyst_minor_soon"]
            details.append("有催化但时间不确定")
    else:
        score += PARAMS["catalyst_none_visible"]
        details.append("无明确催化剂")

    # 政策催化
    if has_policy_catalyst:
        score += PARAMS["catalyst_policy"]
        details.append("有政策催化")

    # 入通预期
    if index_inclusion_soon:
        score += PARAMS["catalyst_index_inclusion"]
        details.append("即将入通，南向资金预期")

    return min(score, 10), "; ".join(details)


def _score_valuation(gain_pct: float, is_ah: bool, is_profitable: bool,
                     target_upside: float, ps_ratio: float, is_loss: bool) -> tuple:
    """评分维度5：估值空间"""
    score = 0
    details = []

    # 按累计涨幅分档
    if gain_pct < 130:
        score += PARAMS["val_gain_just_doubled"]
        details.append(f"涨幅{gain_pct:.0f}%，刚翻倍，估值尚有空间")
    elif gain_pct < 200:
        score += PARAMS["val_gain_2x"]
        details.append(f"涨幅{gain_pct:.0f}%，估值消化中")
    elif gain_pct < 400:
        score += PARAMS["val_gain_3x"]
        details.append(f"涨幅{gain_pct:.0f}%，估值已高")
    elif gain_pct < 700:
        score += PARAMS["val_gain_5x"]
        details.append(f"涨幅{gain_pct:.0f}%，估值极高")
    else:
        score += PARAMS["val_gain_7x"]
        details.append(f"涨幅{gain_pct:.0f}%，估值泡沫风险")

    # A+H减分
    if is_ah:
        score += PARAMS["val_ah_anchor"]
        details.append("A+H溢价倒挂，定价锚限制上行")

    # 已盈利加分
    if is_profitable:
        score += PARAMS["val_profitable"]
        details.append("已盈利，估值锚清晰")

    # 目标价空间
    if target_upside >= 50:
        score += PARAMS["val_target_upside_50"]
        details.append(f"目标价上行{target_upside:.0f}%≥50%")
    elif target_upside >= 30:
        score += PARAMS["val_target_upside_30"]
        details.append(f"目标价上行{target_upside:.0f}%≥30%")

    # PS极端+亏损减分
    if is_loss and ps_ratio > 300:
        score += PARAMS["val_loss_ps_extreme"]
        details.append(f"PS={ps_ratio:.0f}x+亏损，估值极不合理")

    return max(min(score, 10), 0), "; ".join(details)


def score(params: Dict[str, Any]) -> Dict[str, Any]:
    """计算二次爆发评分"""
    name = params.get("name", "未知")
    code = params.get("code", "")

    # 1. 行业景气度
    track = params.get("track", "")
    industry_score, industry_detail = _score_industry(track)

    # 2. 业绩兑现度
    rev_growth = float(params.get("rev_growth", 0))
    is_profitable = params.get("is_profitable", False)
    gross_margin = float(params.get("gross_margin", 0))
    loss_expanding = params.get("loss_expanding", False)
    revenue_yi = float(params.get("revenue_yi", 0))
    earnings_score, earnings_detail = _score_earnings(
        rev_growth, is_profitable, gross_margin, loss_expanding, revenue_yi
    )

    # 3. 机构认可度
    analyst_count = int(params.get("analyst_count", 0))
    target_upside = float(params.get("target_upside", 0))
    institution_score, institution_detail = _score_institution(analyst_count, target_upside)

    # 4. 催化剂管线
    has_major_catalyst = params.get("has_major_catalyst", False)
    catalyst_timeline = params.get("catalyst_timeline", "")
    has_policy_catalyst = params.get("has_policy_catalyst", False)
    index_inclusion_soon = params.get("index_inclusion_soon", False)
    catalyst_score, catalyst_detail = _score_catalyst(
        has_major_catalyst, catalyst_timeline, has_policy_catalyst, index_inclusion_soon
    )

    # 5. 估值空间
    gain_pct = float(params.get("gain_pct", 0))
    is_ah = params.get("is_ah", False)
    is_loss = params.get("is_loss", not is_profitable)
    ps_ratio = float(params.get("ps_ratio", 0))
    valuation_score, valuation_detail = _score_valuation(
        gain_pct, is_ah, is_profitable, target_upside, ps_ratio, is_loss
    )

    # 总分
    total_score = industry_score + earnings_score + institution_score + catalyst_score + valuation_score

    # 评级
    if total_score >= THRESHOLDS["strong"]:
        rating = {"level": "🟢 强候选", "detail": f"二次爆发分{total_score}≥40，高概率再涨50%"}
    elif total_score >= THRESHOLDS["candidate"]:
        rating = {"level": "🟡 候选", "detail": f"二次爆发分{total_score}≥35，可能再涨50%"}
    elif total_score >= THRESHOLDS["watch"]:
        rating = {"level": "🟠 观察名单", "detail": f"二次爆发分{total_score}≥30，值得关注"}
    else:
        rating = {"level": "🔴 不推荐", "detail": f"二次爆发分{total_score}<30，再涨50%概率低"}

    # 正面信号
    positive_signals = []
    if industry_score >= 8:
        positive_signals.append(f"行业高景气：{industry_detail}")
    if earnings_score >= 7:
        positive_signals.append(f"业绩强劲：{earnings_detail}")
    if institution_score >= 7:
        positive_signals.append(f"机构认可：{institution_detail}")
    if catalyst_score >= 7:
        positive_signals.append(f"催化密集：{catalyst_detail}")
    if target_upside >= 30:
        positive_signals.append(f"目标价空间：+{target_upside:.0f}%")

    # 风险信号
    risk_signals = []
    if gain_pct >= 400:
        risk_signals.append(f"涨幅已达{gain_pct:.0f}%，估值极高，回调风险大")
    if is_ah:
        risk_signals.append("A+H架构，A股定价锚限制上行空间")
    if loss_expanding:
        risk_signals.append("亏损持续扩大，现金流压力")
    if analyst_count == 0:
        risk_signals.append("无机构覆盖，市场关注度不足")
    if not has_major_catalyst and not has_policy_catalyst:
        risk_signals.append("缺乏明确催化剂，上涨动力不足")

    # 因子明细
    factors = [
        {"factor": "行业景气度", "group": "行业", "points": industry_score,
         "max_score": 10, "detail": industry_detail, "emphasis": "headline"},
        {"factor": "业绩兑现度", "group": "财务", "points": earnings_score,
         "max_score": 10, "detail": earnings_detail, "emphasis": "headline"},
        {"factor": "机构认可度", "group": "市场", "points": institution_score,
         "max_score": 10, "detail": institution_detail, "emphasis": "headline"},
        {"factor": "催化剂管线", "group": "催化", "points": catalyst_score,
         "max_score": 10, "detail": catalyst_detail, "emphasis": "headline"},
        {"factor": "估值空间", "group": "估值", "points": valuation_score,
         "max_score": 10, "detail": valuation_detail, "emphasis": "headline"},
    ]

    # 报告指引
    headline_factors = []
    for f in factors:
        if f["points"] >= 7:
            headline_factors.append(f["factor"])

    return {
        "name": name,
        "code": code,
        "total_score": total_score,
        "max_possible": 50,
        "score_pct": round(total_score / 50 * 100, 1),
        "factors": factors,
        "rating": rating,
        "positive_signals": positive_signals,
        "risk_signals": risk_signals,
        "headline_factors": headline_factors,
        "gain_pct": gain_pct,
        "target_50pct": round(float(params.get("current_price", 0)) * 1.5, 2) if params.get("current_price") else None,
        "risk_disclaimers": [
            "二次爆发模型为定性分析框架，无历史回测AUC",
            "翻倍后再涨50%的不确定性远高于IPO打新预测",
            "分析结果仅供参考，不构成投资建议",
        ]
    }


def info() -> Dict[str, Any]:
    """返回模型信息"""
    return {
        "model": "港股IPO翻倍股二次爆发评分",
        "version": VERSION,
        "model_date": MODEL_DATE,
        "description": "评估已翻倍港股次新股从当前价再涨50%+的可能性",
        "dimensions": [
            {"name": "行业景气度", "max_score": 10, "weight": "20%"},
            {"name": "业绩兑现度", "max_score": 10, "weight": "20%"},
            {"name": "机构认可度", "max_score": 10, "weight": "20%"},
            {"name": "催化剂管线", "max_score": 10, "weight": "20%"},
            {"name": "估值空间", "max_score": 10, "weight": "20%"},
        ],
        "thresholds": THRESHOLDS,
        "vs_v7": {
            "v7_target": "预测发行价翻倍（事前因子）",
            "ss_target": "预测翻倍后再涨50%（动态因子）",
            "v7_auc": 0.9784,
            "ss_auc": "定性框架，无回测",
            "v7_factors": "超购/基石/首日/赛道/18A",
            "ss_factors": "景气度/业绩/机构/催化/估值",
        }
    }


def validate(params: Dict[str, Any]) -> Dict[str, Any]:
    """校验输入参数"""
    errors = []
    warnings = []

    if not params.get("name"):
        errors.append("name 为必需参数")

    gain_pct = params.get("gain_pct")
    if gain_pct is not None:
        if float(gain_pct) < 100:
            warnings.append(f"涨幅{gain_pct}%<100%，该股票尚未翻倍，建议使用V7模型")
    else:
        warnings.append("gain_pct 未提供，无法确认是否已翻倍")

    return {
        "valid": len(errors) == 0,
        "errors": errors,
        "warnings": warnings,
    }


def main():
    """主入口：读取stdin JSON，执行action，输出stdout JSON"""
    try:
        raw = sys.stdin.read().strip()
        if not raw:
            print(json.dumps({
                "success": False,
                "error": "EMPTY_INPUT",
                "message": "stdin为空，请提供JSON输入"
            }, ensure_ascii=False))
            return

        data = json.loads(raw)
        action = data.get("action", "score")
        params = data.get("params", {})

        if action == "score":
            result = score(params)
            print(json.dumps({
                "success": True,
                "data": result,
                "metadata": {
                    "script": "second_surge_scorer.py",
                    "version": VERSION,
                    "model_date": MODEL_DATE,
                }
            }, ensure_ascii=False, indent=2))

        elif action == "info":
            print(json.dumps({
                "success": True,
                "data": info(),
                "metadata": {
                    "script": "second_surge_scorer.py",
                    "version": VERSION,
                }
            }, ensure_ascii=False, indent=2))

        elif action == "validate":
            print(json.dumps({
                "success": True,
                "data": validate(params),
            }, ensure_ascii=False, indent=2))

        else:
            print(json.dumps({
                "success": False,
                "error": "UNKNOWN_ACTION",
                "message": f"未知action: {action}，支持: score/info/validate"
            }, ensure_ascii=False))

    except json.JSONDecodeError as e:
        print(json.dumps({
            "success": False,
            "error": "INVALID_JSON",
            "message": f"JSON解析失败: {str(e)}"
        }, ensure_ascii=False))
    except Exception as e:
        print(json.dumps({
            "success": False,
            "error": "INTERNAL_ERROR",
            "message": str(e)
        }, ensure_ascii=False))


if __name__ == "__main__":
    main()
