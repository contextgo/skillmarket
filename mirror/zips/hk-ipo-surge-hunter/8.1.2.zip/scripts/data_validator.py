#!/usr/bin/env python3
"""
港股IPO数据验证器 (data_validator.py)

功能：
1. 发行价合理性检查 — 按行业阈值检测异常发行价
2. 累计涨幅异常检测 — 与已知新闻对比
3. 数据完整性检查 — 必填字段缺失检测
4. 多源交叉验证 — 对比不同来源的价格数据
5. 输出验证报告 — 含告警等级和阻止标记

使用方式：
    echo '{"action":"validate","data":{...}}' | python3 data_validator.py
    echo '{"action":"validate_batch","data":[{...},{...}]} | python3 data_validator.py

告警等级：
    P0 = 阻止级（数据明显错误，禁止生成报告）
    P1 = 警告级（数据可能有误，需人工确认）
    P2 = 提示级（数据合理但需注意）
"""

import sys
import json
import os
from typing import Dict, List, Any, Optional

# ====== 行业发行价合理性阈值 ======
# 从共享配置文件加载（与 hk_ipo_scorer.py 使用同一数据源）
def _load_thresholds():
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                        "..", "references", "price_thresholds.json")
    try:
        with open(path) as f:
            data = json.load(f)
        return data.get("thresholds", {}), data.get("default", {"min": 5, "max": 500})
    except Exception:
        return {}, {"min": 5, "max": 500}

INDUSTRY_PRICE_THRESHOLDS, DEFAULT_THRESHOLD = _load_thresholds()

# ====== 已知的错误数据模式 ======
# 历史上出现过错误的数据特征，用于自动识别
KNOWN_ERROR_PATTERNS = [
    # (pattern, description, expected_range)
    ("AI公司发行价<10港元", "AI/半导体公司发行价低于10港元几乎不可能", lambda d: d.get("track", "") in ["AI", "AI/半导体", "半导体", "GPU"] and d.get("issue_price", 999) < 10),
    ("18A-B股发行价<15港元", "18A/B股通常发行价较高", lambda d: "18a" in str(d.get("track", "")).lower() or "-B" in d.get("name", "") and d.get("issue_price", 999) < 15),
    ("发行价<1港元", "港股主板发行价低于1港元极为罕见", lambda d: d.get("issue_price", 999) < 1),
]

# ====== 必填字段检查 ======
REQUIRED_FIELDS = {
    "name": "公司名称",
    "code": "股票代码",
    "issue_price": "发行价",
    "current_price": "当前价格",
    "track": "行业赛道",
}


def get_threshold(track: str) -> Dict[str, float]:
    """根据行业赛道获取发行价阈值"""
    for key, threshold in INDUSTRY_PRICE_THRESHOLDS.items():
        if key in track:
            return threshold
    return DEFAULT_THRESHOLD


def validate_issue_price(data: Dict[str, Any]) -> List[Dict[str, Any]]:
    """发行价合理性检查"""
    warnings = []
    issue_price = data.get("issue_price", 0)
    track = data.get("track", "")
    name = data.get("name", "未知")
    
    if issue_price <= 0:
        warnings.append({
            "level": "P0",
            "field": "issue_price",
            "message": f"{name} 发行价为{issue_price}，明显无效",
            "action": "阻止评分，必须获取有效发行价",
        })
        return warnings
    
    # 行业阈值检查
    threshold = get_threshold(track)
    if issue_price < threshold["min"]:
        warnings.append({
            "level": "P0",
            "field": "issue_price",
            "message": f"{name}({track}) 发行价{issue_price}港元 低于行业最低阈值{threshold['min']}港元，极大概率是错误数据",
            "action": "阻止评分，必须用东方财富网+新闻二次确认发行价",
            "history": "2026-04-24: 精锋医疗-B错误6.80→正确43.24, 极视角错误3.08→正确40.00",
        })
    elif issue_price > threshold["max"]:
        warnings.append({
            "level": "P1",
            "field": "issue_price",
            "message": f"{name}({track}) 发行价{issue_price}港元 高于行业最高阈值{threshold['max']}港元，需确认",
            "action": "需用新闻搜索确认发行价是否正确",
        })
    
    # 已知错误模式检查
    for pattern_name, desc, check_fn in KNOWN_ERROR_PATTERNS:
        if check_fn(data):
            warnings.append({
                "level": "P0",
                "field": "issue_price",
                "message": f"{name} 触发已知错误模式: {desc}",
                "action": "阻止评分，发行价极大概率为错误数据",
            })
    
    return warnings


def validate_cumulative_gain(data: Dict[str, Any]) -> List[Dict[str, Any]]:
    """累计涨幅异常检测"""
    warnings = []
    issue_price = data.get("issue_price", 0)
    current_price = data.get("current_price", 0)
    name = data.get("name", "未知")
    first_day_chg = data.get("first_day_chg", 0)
    
    if issue_price <= 0 or current_price <= 0:
        return warnings
    
    cum_chg = (current_price - issue_price) / issue_price * 100
    
    # 首日涨幅与累计涨幅的逻辑一致性
    if first_day_chg != 0:
        if cum_chg < first_day_chg * 0.3 and first_day_chg > 0:
            # 累计涨幅远低于首日涨幅，说明当前价可能被低估或首日涨幅有误
            warnings.append({
                "level": "P1",
                "field": "cumulative_gain",
                "message": f"{name} 首日+{first_day_chg}%但累计仅+{cum_chg:.1f}%，首日涨幅或当前价可能有误",
                "action": "需确认首日涨幅和当前价格数据",
            })
        
        if cum_chg > first_day_chg * 20 and first_day_chg > 0:
            # 累计涨幅远超首日，正常但需标记
            warnings.append({
                "level": "P2",
                "field": "cumulative_gain",
                "message": f"{name} 累计+{cum_chg:.1f}%远超首日+{first_day_chg}%，需确认当前价是否含复权因素",
                "action": "确认当前价是否经复权调整",
            })
    
    # 极端涨幅检测
    if cum_chg > 5000:
        warnings.append({
            "level": "P1",
            "field": "cumulative_gain",
            "message": f"{name} 累计涨幅+{cum_chg:.1f}%极高，需用新闻验证当前价",
            "action": "web_search确认当前股价",
        })
    
    if cum_chg < -50:
        warnings.append({
            "level": "P1",
            "field": "cumulative_gain",
            "message": f"{name} 累计跌幅{cum_chg:.1f}%极深，需确认是否除权除息",
            "action": "确认是否发生拆股/合股/除权",
        })
    
    return warnings


def validate_completeness(data: Dict[str, Any]) -> List[Dict[str, Any]]:
    """必填字段完整性检查"""
    warnings = []
    name = data.get("name", "未知")
    
    for field, label in REQUIRED_FIELDS.items():
        if field not in data or data[field] is None or data[field] == "":
            warnings.append({
                "level": "P0",
                "field": field,
                "message": f"{name} 缺少必填字段: {label}({field})",
                "action": "必须补充数据后才能评分",
            })
        elif field in ["issue_price", "current_price"] and isinstance(data[field], (int, float)) and data[field] <= 0:
            warnings.append({
                "level": "P0",
                "field": field,
                "message": f"{name} {label}值为{data[field]}，无效",
                "action": "必须获取有效数据后才能评分",
            })
    
    return warnings


def validate_cross_check(data: Dict[str, Any], alt_data: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    """多源交叉验证"""
    warnings = []
    name = data.get("name", "未知")
    
    if alt_data is None:
        # 没有备选数据源时，仅检查是否有验证标记
        if not data.get("issue_price_verified"):
            v7_score = data.get("v7_score", 0)
            if v7_score >= 40:
                warnings.append({
                    "level": "P1",
                    "field": "issue_price",
                    "message": f"{name} V7评分≥40但发行价未经交叉验证",
                    "action": "推荐标的必须用新闻二次确认发行价",
                })
        return warnings
    
    # 有备选数据源时，做差异对比
    for field in ["issue_price", "current_price"]:
        primary = data.get(field, 0)
        secondary = alt_data.get(field, 0)
        if primary > 0 and secondary > 0:
            diff_pct = abs(primary - secondary) / primary * 100
            if diff_pct > 10:
                warnings.append({
                    "level": "P0",
                    "field": field,
                    "message": f"{name} {field}两源差异{diff_pct:.1f}%：主源{primary} vs 备源{secondary}",
                    "action": "差异>10%，必须确认哪个更准确",
                })
            elif diff_pct > 5:
                warnings.append({
                    "level": "P1",
                    "field": field,
                    "message": f"{name} {field}两源差异{diff_pct:.1f}%：主源{primary} vs 备源{secondary}",
                    "action": "差异5-10%，取保守值并标记warning",
                })
    
    return warnings


def validate_data_source(data: Dict[str, Any]) -> List[Dict[str, Any]]:
    """数据来源合规性检查"""
    warnings = []
    name = data.get("name", "未知")
    
    # 检查是否使用了禁止的数据源
    price_source = data.get("current_price_source", "")
    if "neodata" in price_source.lower() or "neo_data" in price_source.lower():
        warnings.append({
            "level": "P0",
            "field": "current_price",
            "message": f"{name} 当前价格来源为NeoData，港股数据已验证不准确",
            "action": "必须改用新浪财经API获取港股价格",
        })
    
    issue_source = data.get("issue_price_source", "")
    if not issue_source:
        warnings.append({
            "level": "P1",
            "field": "issue_price",
            "message": f"{name} 发行价未标注数据来源",
            "action": "必须标注发行价来源（东方财富网/新闻/港交所公告）",
        })
    elif "估算" in issue_source or "推算" in issue_source:
        warnings.append({
            "level": "P0",
            "field": "issue_price",
            "message": f"{name} 发行价来源为估算值，禁止使用",
            "action": "必须从东方财富网或新闻获取真实发行价",
        })
    
    return warnings


def validate_stock(data: Dict[str, Any], alt_data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """对单只股票执行全量验证"""
    all_warnings = []
    
    all_warnings.extend(validate_completeness(data))
    all_warnings.extend(validate_issue_price(data))
    all_warnings.extend(validate_cumulative_gain(data))
    all_warnings.extend(validate_data_source(data))
    all_warnings.extend(validate_cross_check(data, alt_data))
    
    # 按等级分类
    p0_warnings = [w for w in all_warnings if w["level"] == "P0"]
    p1_warnings = [w for w in all_warnings if w["level"] == "P1"]
    p2_warnings = [w for w in all_warnings if w["level"] == "P2"]
    
    # 判定是否可继续
    can_proceed = len(p0_warnings) == 0
    
    return {
        "name": data.get("name", "未知"),
        "code": data.get("code", "未知"),
        "validation_passed": can_proceed,
        "p0_count": len(p0_warnings),
        "p1_count": len(p1_warnings),
        "p2_count": len(p2_warnings),
        "p0_warnings": p0_warnings,
        "p1_warnings": p1_warnings,
        "p2_warnings": p2_warnings,
        "data_quality_level": "fail" if p0_warnings else ("warning" if p1_warnings else "pass"),
    }


def validate_batch(data_list: List[Dict[str, Any]]) -> Dict[str, Any]:
    """批量验证"""
    results = []
    for item in data_list:
        result = validate_stock(item)
        results.append(result)
    
    # 汇总
    total = len(results)
    pass_count = sum(1 for r in results if r["data_quality_level"] == "pass")
    warning_count = sum(1 for r in results if r["data_quality_level"] == "warning")
    fail_count = sum(1 for r in results if r["data_quality_level"] == "fail")
    
    return {
        "total": total,
        "pass": pass_count,
        "warning": warning_count,
        "fail": fail_count,
        "can_proceed": fail_count == 0,
        "results": results,
    }


def main():
    """主入口：读取stdin JSON，执行action，输出stdout JSON"""
    try:
        raw = sys.stdin.read().strip()
        if not raw:
            print(json.dumps({
                "success": False,
                "error": "EMPTY_INPUT",
                "message": "stdin为空，请提供JSON输入"
            }, ensure_ascii=False))
            return

        input_data = json.loads(raw)
        action = input_data.get("action", "")
        data = input_data.get("data", {})

        if action == "validate":
            # 单只股票验证
            alt_data = input_data.get("alt_data")
            result = validate_stock(data, alt_data)
            print(json.dumps({
                "success": True,
                "data": result,
                "metadata": {"script": "data_validator.py", "version": "1.0"}
            }, ensure_ascii=False, indent=2))

        elif action == "validate_batch":
            # 批量验证
            if not isinstance(data, list):
                print(json.dumps({
                    "success": False,
                    "error": "INVALID_INPUT",
                    "message": "validate_batch需要data为数组"
                }, ensure_ascii=False))
                return
            result = validate_batch(data)
            print(json.dumps({
                "success": True,
                "data": result,
                "metadata": {"script": "data_validator.py", "version": "1.0"}
            }, ensure_ascii=False, indent=2))

        elif action == "check_price":
            # 仅检查发行价合理性
            result = validate_issue_price(data)
            print(json.dumps({
                "success": True,
                "warnings": result,
                "metadata": {"script": "data_validator.py", "version": "1.0"}
            }, ensure_ascii=False, indent=2))

        else:
            print(json.dumps({
                "success": False,
                "error": "UNKNOWN_ACTION",
                "message": f"未知action: {action}，支持: validate/validate_batch/check_price"
            }, ensure_ascii=False))

    except json.JSONDecodeError as e:
        print(json.dumps({
            "success": False,
            "error": "INVALID_JSON",
            "message": f"JSON解析失败: {str(e)}"
        }, ensure_ascii=False))
    except Exception as e:
        print(json.dumps({
            "success": False,
            "error": "INTERNAL_ERROR",
            "message": str(e)
        }, ensure_ascii=False))


if __name__ == "__main__":
    main()
