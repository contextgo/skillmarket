# 港股新股超涨股选股脚本 - 接口文档

## 版本信息

- 模型版本：V7.0（打新评分）+ V1.0（二次爆发）+ V1.0（统一筛选）
- V7 AUC：0.9784（84只有效样本）
- V7 超涨定义：上市10日后收盘价≥发行价×2(翻倍)=超涨
- 二次爆发定义：已翻倍股从当前价再涨50%+
- 统一筛选定义：从当前价出发，筛选所有还有50%+上行空间的标的
- 脚本版本：v8.1.0

## 脚本列表

### hk_ipo_scorer.py（场景一：打新评分）

**功能**：为待上市/已上市港股新股计算超涨因子评分

**支持 Actions**：
| Action | 说明 |
|--------|------|
| `score` | 计算评分 |
| `info` | 返回模型信息 |
| `validate` | 校验输入参数 |

### second_surge_scorer.py（场景二：二次爆发）

**功能**：评估已翻倍港股次新股从当前价再涨50%+的可能性

**支持 Actions**：
| Action | 说明 |
|--------|------|
| `score` | 计算二次爆发评分 |
| `info` | 返回模型信息 |
| `validate` | 校验输入参数（含涨幅<100%预警） |

### data_validator.py（共享）

**功能**：校验发行价/价格数据合理性

### unified_screener.py（场景三：统一50%上行筛选）

**功能**：从当前价出发，统一筛选所有还有50%+上行空间的港股次新股（组合路由器）

**支持 Actions**：
| Action | 说明 |
|--------|------|
| `screen` | 执行统一筛选（单只或批量） |
| `info` | 返回筛选器信息 |
| `validate` | 校验输入参数 |

### 输入参数

| 字段 | 类型 | 必需 | 说明 | 默认值 |
|------|------|------|------|--------|
| name | string | ✅ | 公司名称 | — |
| code | string | ❌ | 股票代码 | "" |
| track | string | ❌ | 赛道 | "" |
| is_ah | boolean | ❌ | 是否A+H上市 | false |
| oversub | float | ❌ | 超购倍数(None=缺失) | None |
| cornerstone_names | array | ❌ | 基石投资者名称列表 | [] |
| cornerstone_pct | float | ❌ | 基石占比(%) | 0 |
| scarcity | string | ❌ | 稀缺性 | "" |
| is_18a | boolean | ❌ | 是否18A章节 | false |
| has_top_vc | boolean | ❌ | 是否有知名VC/PE | false |
| is_first_stock | boolean | ❌ | 是否赛道"第一股" | false |
| rd_ratio | float | ❌ | 研发占比(%) | 5 |
| free_float_pct | float | ❌ | 自由流通比例(%) | 10 |
| days_to_connect | int | ❌ | 预计入通天数 | 90 |
| sponsor_quality | string | ❌ | 保荐人质量 | "" |
| rev_growth | float | ❌ | 营收增速(%) | 20 |
| first_day_chg | float/None | ❌ | **首日涨跌幅(%)**，上市前传None | None |
| oversub_missing | boolean | ❌ | 超购数据是否缺失 | false |
| policy_catalyst | boolean | ❌ | 是否有政策催化 | false |
| market_cap_yi | float | ❌ | 发行市值(亿港元) | — |
| public_pct | float | ❌ | 公开发售比例(%) | — |

### 输出结果（V2契约格式）

```json
{
  "success": true,
  "data": {
    "name": "公司名",
    "factors": [
      {"factor": "因子名", "group": "因子群", "points": 5, "detail": "说明", "iv": 1.01, "max_score": 28}
    ],
    "total_score": 40,
    "max_possible": 100,
    "score_pct": 40.0,
    "rating": {"level": "极高概率超涨", "detail": "历史精确率96%"},
    "positive_signals": ["..."],
    "risk_signals": ["..."],
    "warnings": ["..."],
    "comparable_cases": ["..."],
    "risk_disclaimers": ["..."]
  },
  "metadata": {
    "script": "hk_ipo_scorer.py",
    "version": "V7.0",
    "model_date": "2026-04-24",
    "duration_ms": 5
  }
}
```

### V7.0因子权重

| 因子 | 权重 | 满分 | 说明 |
|------|------|------|------|
| 首日涨跌幅 | +28/-18 | 28 | V7新增，分段处理 |
| 知名消费品牌 | 12 | 12 | V7新增 |
| 小盘妖股信号 | 10 | 10 | V7新增 |
| 赛道热度(AI) | 10 | 10 | |
| 第一股标签 | 10 | 10 | |
| 知名VC/PE | 8 | 8 | |
| 超购真热情 | 6 | 6 | V7新增区分 |
| 基石占比 | 6 | 6 | |
| 18A章节 | 5 | 5 | |
| 基石质量 | 4 | 4 | |
| 营收增速 | 3 | 3 | |
| 政策催化 | 3 | 3 | |
| 纯H股 | 3 | 3 | V7降低(从15) |
| 入通时间 | 2 | 2 | |
| 研发占比 | 2 | 2 | |
| 保荐人质量 | 2 | 2 | |
| 自由流通 | 2 | 2 | |
| 交互:A+H+热门 | -3 | — | V7降低(从-15) |
| 交互:低超购+热门 | -15 | — | V7加强(从-8) |
| 交互:高超购+消费 | +8 | — | V7新增 |
| 交互:暴跌+18A | -8 | — | V7新增 |
| 交互:暴涨+虚假热情 | -15 | — | V7新增 |

### 调用示例

**评分（含首日数据）**：
```bash
echo '{"action":"score","params":{"name":"智谱","track":"AI/半导体","is_ah":false,"oversub":1159,"is_first_stock":true,"has_top_vc":true,"rd_ratio":80,"first_day_chg":13.2}}' | python3 hk_ipo_scorer.py
```

**评分（上市前，无首日数据）**：
```bash
echo '{"action":"score","params":{"name":"某AI新股","track":"AI/半导体","is_ah":false,"oversub":2000}}' | python3 hk_ipo_scorer.py
```

**模型信息**：
```bash
echo '{"action":"info","params":{}}' | python3 hk_ipo_scorer.py
```

**参数校验**：
```bash
echo '{"action":"validate","params":{"name":"测试","oversub":-100}}' | python3 hk_ipo_scorer.py
```

### 错误码

| 错误码 | 说明 |
|--------|------|
| INVALID_INPUT | 输入参数错误或JSON解析失败 |

---

## second_surge_scorer.py

### 输入参数

| 字段 | 类型 | 必需 | 说明 | 默认值 |
|------|------|------|------|--------|
| name | string | ✅ | 公司名称 | — |
| code | string | ❌ | 股票代码 | "" |
| track | string | ❌ | 赛道描述 | "" |
| gain_pct | float | ✅ | 累计涨幅(%) | — |
| current_price | float | ❌ | 当前价(港元) | 0 |
| rev_growth | float | ❌ | 营收增速(%) | 0 |
| is_profitable | boolean | ❌ | 是否已盈利 | false |
| gross_margin | float | ❌ | 毛利率(%) | 0 |
| loss_expanding | boolean | ❌ | 亏损是否扩大 | false |
| revenue_yi | float | ❌ | 营收(亿元) | 0 |
| analyst_count | int | ❌ | 覆盖券商数量 | 0 |
| target_upside | float | ❌ | 机构共识目标价上行(%) | 0 |
| has_major_catalyst | boolean | ❌ | 是否有重大催化 | false |
| catalyst_timeline | string | ❌ | 催化时间("1-3月"/"3-6月") | "" |
| has_policy_catalyst | boolean | ❌ | 是否有政策催化 | false |
| index_inclusion_soon | boolean | ❌ | 是否即将入通 | false |
| is_ah | boolean | ❌ | 是否A+H | false |
| ps_ratio | float | ❌ | PS估值倍数 | 0 |

### 输出结果

```json
{
  "success": true,
  "data": {
    "name": "MINIMAX-W",
    "code": "00100.HK",
    "total_score": 41,
    "max_possible": 50,
    "score_pct": 82.0,
    "factors": [
      {"factor": "行业景气度", "group": "行业", "points": 10, "max_score": 10, "detail": "...", "emphasis": "headline"},
      {"factor": "业绩兑现度", "group": "财务", "points": 6, "max_score": 10, "detail": "...", "emphasis": "headline"},
      {"factor": "机构认可度", "group": "市场", "points": 10, "max_score": 10, "detail": "...", "emphasis": "headline"},
      {"factor": "催化剂管线", "group": "催化", "points": 10, "max_score": 10, "detail": "...", "emphasis": "headline"},
      {"factor": "估值空间", "group": "估值", "points": 5, "max_score": 10, "detail": "...", "emphasis": "headline"}
    ],
    "rating": {"level": "🟢 强候选", "detail": "二次爆发分41≥40，高概率再涨50%"},
    "positive_signals": ["..."],
    "risk_signals": ["..."],
    "headline_factors": ["行业景气度", "机构认可度", "催化剂管线"],
    "gain_pct": 396.0,
    "target_50pct": 1227.75,
    "risk_disclaimers": ["..."]
  },
  "metadata": {"script": "second_surge_scorer.py", "version": "V1.0"}
}
```

### 评分阈值

| 得分 | 评级 |
|------|------|
| ≥40 | 🟢 强候选 |
| 35-39 | 🟡 候选 |
| 30-34 | 🟠 观察名单 |
| <30 | 🔴 不推荐 |

### 调用示例

```bash
echo '{"action":"score","params":{"name":"MINIMAX-W","code":"00100.HK","track":"AI大模型","gain_pct":396,"rev_growth":100,"is_profitable":false,"loss_expanding":true,"analyst_count":3,"target_upside":37,"has_major_catalyst":true,"catalyst_timeline":"1-3月","current_price":818.5}}' | python3 second_surge_scorer.py
```

**参数校验（涨幅<100%会预警）**：
```bash
echo '{"action":"validate","params":{"name":"测试","gain_pct":50}}' | python3 second_surge_scorer.py
```

---

## unified_screener.py

### 功能说明

组合路由器，从当前价出发统一筛选所有还有50%+上行空间的港股次新股。

**核心逻辑**：
- 已翻倍股（gain≥100%）→ 二次爆发V1评分 → 入选条件：分≥35
- 未翻倍股（gain<100%）→ V7评分 → 入选条件：V7≥40 且 翻倍上行空间≥50%

### 输入参数（单只筛选）

| 字段 | 类型 | 必需 | 说明 |
|------|------|------|------|
| name | string | ✅ | 公司名称 |
| code | string | ❌ | 股票代码 |
| current_price | float | ✅ | 当前价(港元) |
| issue_price | float | ✅ | 发行价(港元) |
| gain_pct | float | ❌ | 累计涨幅(%)，不提供则自动计算 |
| second_surge_score | int | 条件 | 已翻倍股的二次爆发评分 |
| second_surge_data | object | ❌ | 二次爆发完整评分结果 |
| v7_score | int | 条件 | 未翻倍股的V7评分 |
| v7_data | object | ❌ | V7完整评分结果 |

### 输入参数（批量筛选）

| 字段 | 类型 | 必需 | 说明 |
|------|------|------|------|
| stocks | array | ✅ | 股票数组，每个元素同上 |

### 输出结果（单只）

```json
{
  "success": true,
  "data": {
    "name": "MINIMAX-W",
    "code": "00100.HK",
    "stock_type": "doubled",
    "gain_pct": 396.1,
    "current_price": 818.5,
    "issue_price": 165.0,
    "target_50pct": 1227.75,
    "model": "二次爆发V1",
    "score": 41,
    "max_score": 50,
    "score_pct": 82.0,
    "rating": "🟢 强候选",
    "eligible": true,
    "eligible_reason": "二次爆发分41≥35",
    "upside_type": "定性评估",
    "upside_note": "二次爆发模型评估当前价再涨50%+的概率"
  }
}
```

### 输出结果（批量）

```json
{
  "success": true,
  "data": {
    "total_input": 5,
    "total_doubled": 2,
    "total_not_doubled": 3,
    "eligible_count": 3,
    "eligible_doubled": 2,
    "eligible_not_doubled": 1,
    "eligible": [...],
    "ineligible": [...],
    "thresholds": {"v7_min_score": 40, "ss_min_score": 35, "upside_min_pct": 50},
    "summary": "共5只：2只已翻倍(2只入选)、3只未翻倍(1只入选)"
  }
}
```

### 调用示例

**单只筛选（已翻倍股）**：
```bash
echo '{"action":"screen","params":{"name":"MINIMAX-W","code":"00100.HK","current_price":818.5,"issue_price":165.0,"second_surge_score":41}}' | python3 unified_screener.py
```

**单只筛选（未翻倍股）**：
```bash
echo '{"action":"screen","params":{"name":"某股","code":"00001.HK","current_price":12.0,"issue_price":10.0,"v7_score":55}}' | python3 unified_screener.py
```

**批量筛选**：
```bash
echo '{"action":"screen","params":{"stocks":[{"name":"MINIMAX-W","current_price":818.5,"issue_price":165.0,"second_surge_score":41},{"name":"某股","current_price":12.0,"issue_price":10.0,"v7_score":55}]}}' | python3 unified_screener.py
```
