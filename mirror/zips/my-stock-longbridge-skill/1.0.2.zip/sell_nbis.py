from longbridge.openapi import Config, TradeContext, OrderType, OrderSide, TimeInForceType

# 凭证信息
APP_KEY = "1ab56e0d711bf492491a795fd088170f"
APP_SECRET = "6f9285faff4b8aec2e6de8fc4fdb67f0f08426c7ba9a92fc9b041f9151b9f111"
ACCESS_TOKEN = "m_eyJhbGciOiJSUzI1NiIsImtpZCI6ImQ5YWRiMGIxYTdlNzYxNzEiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJsb25nYnJpZGdlIiwic3ViIjoiYWNjZXNzX3Rva2VuIiwiZXhwIjoxNzgxMDE5Njc3LCJpYXQiOjE3NzMyNDM2NzksImFrIjoiMWFiNTZlMGQ3MTFiZjQ5MjQ5MWE3OTVmZDA4ODE3MGYiLCJhYWlkIjoyMDUzMjY1MCwiYWMiOiJsYl9wYXBlcnRyYWRpbmciLCJtaWQiOjE2MTg0MzksInNpZCI6ImJmSDV6SUNpL0Rwc3ViK050T1I3akE9PSIsImJsIjozLCJ1bCI6MCwiaWsiOiJsYl9wYXBlcnRyYWRpbmdfMjA1MzI2NTAifQ.OG-mJZpPtEMy-j_6bBnh8rrw_i_VVOuu1XsuAY4yDGcpjXTEFDKe_l-OH853hc5JDmfQFRDb1SBc5bB_Gj4zsPFKtpHqP0Ogyuj7vwvtk6iwVmm4ubAImYhx8HaRwMsowglEaUm0jwQrI1yLmyw2yI3nPJQ43Ai_fvFIJifN907LOk7nrhNxyTOo6EKRE29qfBu4w6EeE9b0vK7Gq25nTwQ2N5xprZSplZkNTUg2t1QdlFXVgrjvWP44JFkYegEJgg8EGFKfx_CaYGFgRO8z1GwM9GilhIHj9d7YLBn3WRhdO22_rsH46YcXOhpIXxwlUNQSdf3fqyhglG_rd6Vveg3GvPEKfSPpxjUadAqKth61d13bjRMX3LAgaeR4oM7tV1tep6MH5r5w1pNMOjX51Ac8p6Z0-fLFDJ45qRmk3RFoR6NjgTXB-E5NBfC36WNJKgSzerUeQE3KbO8ob-McY1jymQ4yfCuv4BSEM0NJrTEdYsKDDhsvfQ15DGQP2VCm5Myg6YRt9rG0OvSLsTdXD73OtGyU-0lBJdrPs9eTIcp_Ldp2cREea-SOQiNcsOQ-nNhI2PCulsgtgsfws77strdwgNb6QyEXVQRsU4LGcKHEdNeAmKzi6yAnNBrBAGOevgudk8yHae3l79LmZoxwPDTc6PyFOuFazMadMDjGA-c"

config = Config.from_apikey(app_key=APP_KEY, app_secret=APP_SECRET, access_token=ACCESS_TOKEN)
trade = TradeContext(config)

# 卖出 NBIS 5 股
symbol = "NBIS.US"

try:
    resp = trade.submit_order(
        symbol=symbol,
        order_type=OrderType.MO,
        side=OrderSide.Sell,
        submitted_quantity=5,
        time_in_force=TimeInForceType.Day
    )
    print(f"订单提交成功: {resp}")
except Exception as e:
    print(f"订单提交失败: {e}")
