"""Web Crawler Skill for AI Agent"""

import os
import re
import json
import time
import random
import requests
from datetime import datetime
from bs4 import BeautifulSoup
from typing import List, Dict, Optional, Tuple

class CrawlerSkill:
    """Web crawler skill for collecting AI, digitalization articles"""
    
    def __init__(self, output_dir: str = "."):
        self.output_dir = output_dir
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        })
        
        # Create output directories
        self.dirs = {
            'articles': os.path.join(output_dir, 'original_articles'),
            'links': os.path.join(output_dir, 'article_links'),
            'summaries': os.path.join(output_dir, 'ai_summaries')
        }
        for dir_path in self.dirs.values():
            os.makedirs(dir_path, exist_ok=True)
        
        # Keywords configuration
        self.keywords = [
            "人工智能", "数字化", "信息化", "智能化", 
            "智能技术", "AI", "算法", "大数据", 
            "云计算", "数字经济", "数字转型"
        ]
        
        self.exclude_keywords = [
            "报表", "采购", "公示", "公告", "招标", "投标", 
            "结果", "租赁", "服务", "通知", "办法", "目录", 
            "处罚", "检查", "认定", "标准", "设备", "购买", 
            "购置", "询价", "竞争性", "谈判", "单一来源", 
            "中标", "成交", "合同"
        ]
        
        # Crawled links tracking
        self.crawled_links_file = os.path.join(output_dir, 'crawled_links.json')
        self.crawled_links = self._load_crawled_links()
    
    def _load_crawled_links(self) -> Dict:
        """Load previously crawled links"""
        if os.path.exists(self.crawled_links_file):
            try:
                with open(self.crawled_links_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return {}
        return {}
    
    def _save_crawled_links(self):
        """Save crawled links to file"""
        with open(self.crawled_links_file, 'w', encoding='utf-8') as f:
            json.dump(self.crawled_links, f, ensure_ascii=False, indent=2)
    
    def is_crawled(self, url: str) -> bool:
        """Check if URL has been crawled"""
        return url in self.crawled_links
    
    def mark_as_crawled(self, url: str, title: str):
        """Mark URL as crawled"""
        self.crawled_links[url] = {
            'title': title,
            'crawled_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        self._save_crawled_links()
    
    def _get_with_retry(self, url: str, max_retries: int = 3) -> Optional[requests.Response]:
        """HTTP GET with retry mechanism"""
        for attempt in range(max_retries):
            try:
                time.sleep(random.uniform(1, 3))
                response = self.session.get(url, timeout=10)
                if response.status_code == 200:
                    return response
            except Exception as e:
                print(f"Attempt {attempt + 1} failed for {url}: {e}")
                if attempt < max_retries - 1:
                    time.sleep(2 ** attempt)
        return None
    
    def _extract_date(self, text: str) -> datetime:
        """Extract publication date from text"""
        patterns = [
            r'(\d{4})[\-/年](\d{1,2})[\-/月](\d{1,2})',
            r'(\d{4})(\d{2})(\d{2})',
        ]
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                try:
                    year, month, day = int(match.group(1)), int(match.group(2)), int(match.group(3))
                    return datetime(year, month, day)
                except:
                    continue
        return datetime.now()
    
    def _get_next_index(self, directory: str, prefix: str) -> int:
        """Get next available file index"""
        max_index = 0
        if os.path.exists(directory):
            for filename in os.listdir(directory):
                if filename.startswith(prefix) and filename.endswith('.txt'):
                    match = re.search(rf'{prefix}_(\d+)\.txt$', filename)
                    if match:
                        index = int(match.group(1))
                        if index > max_index:
                            max_index = index
        return max_index + 1
    
    def _filter_title(self, title: str) -> bool:
        """Check if title matches keywords and excludes"""
        if not any(kw in title for kw in self.keywords):
            return False
        if any(ex in title for ex in self.exclude_keywords):
            return False
        return True
    
    def crawl_website(self, name: str, urls: List[str], source: str, max_articles: int = 5) -> List[Dict]:
        """Crawl a specific website"""
        print(f"\n{'='*50}")
        print(f"开始爬取: {name}")
        
        articles = []
        for url in urls:
            response = self._get_with_retry(url)
            if not response:
                continue
            
            try:
                soup = BeautifulSoup(response.text, "lxml")
                all_links = soup.find_all("a", href=True)
                
                for link in all_links:
                    title = link.text.strip()
                    href = link.get("href")
                    
                    if not title or not href or len(title) < 5:
                        continue
                    
                    if any(x in href for x in ["list", "index", "javascript", "#", "video"]):
                        continue
                    
                    # Build full URL
                    if not href.startswith("http"):
                        base = url.split('/')[0] + '//' + url.split('/')[2]
                        full_link = base + (href if href.startswith('/') else '/' + href)
                    else:
                        full_link = href
                    
                    # Filter by keywords
                    if not self._filter_title(title):
                        continue
                    
                    # Check duplicates
                    if any(a["link"] == full_link for a in articles):
                        continue
                    if self.is_crawled(full_link):
                        print(f"  跳过已爬取: {title[:30]}...")
                        continue
                    
                    articles.append({
                        "title": title,
                        "link": full_link,
                        "source": source
                    })
                    
                    if len(articles) >= max_articles:
                        return articles
                        
            except Exception as e:
                print(f"  解析失败: {e}")
        
        return articles
    
    def extract_article_content(self, url: str) -> Tuple[str, datetime]:
        """Extract article content from URL"""
        response = self._get_with_retry(url)
        if not response:
            return "获取内容失败", datetime.now()
        
        try:
            soup = BeautifulSoup(response.text, "lxml")
            
            # Try multiple content selectors
            selectors = [
                ".content", ".article-content", "#content", 
                ".article-body", ".text", ".article", ".news-content",
                ".detail", ".main-content", ".post-content"
            ]
            
            content_elem = None
            for selector in selectors:
                content_elem = soup.select_one(selector)
                if content_elem:
                    break
            
            publish_date = self._extract_date(response.text)
            
            if content_elem:
                return content_elem.text.strip(), publish_date
            else:
                paragraphs = soup.select("p")
                content = "\n".join([p.text.strip() for p in paragraphs if p.text.strip() and len(p.text.strip()) > 50])
                return content, publish_date
        except Exception as e:
            print(f"提取文章内容失败: {e}")
            return "获取内容失败", datetime.now()
    
    def save_article(self, article: Dict, content: str, publish_date: datetime, index: int):
        """Save article to files"""
        # Save original article
        article_file = os.path.join(self.dirs['articles'], f'article_{index}.txt')
        with open(article_file, 'w', encoding='utf-8') as f:
            f.write(f"标题: {article['title']}\n")
            f.write(f"链接: {article['link']}\n")
            f.write(f"来源: {article['source']}\n")
            f.write(f"发布时间: {publish_date.strftime('%Y-%m-%d')}\n\n")
            f.write(content)
        
        # Save link metadata
        link_file = os.path.join(self.dirs['links'], f'link_{index}.txt')
        with open(link_file, 'w', encoding='utf-8') as f:
            f.write(f"标题: {article['title']}\n")
            f.write(f"链接: {article['link']}\n")
            f.write(f"来源: {article['source']}\n")
            f.write(f"发布时间: {publish_date.strftime('%Y-%m-%d')}\n")
        
        # Mark as crawled
        self.mark_as_crawled(article['link'], article['title'])
        
        print(f"  已保存: article_{index}.txt")
    
    def run(self, target_count: int = 10):
        """Run the crawler with all configured sources"""
        print("=" * 50)
        print("开始爬取人工智能、数字化、信息化相关文章")
        print("=" * 50)
        
        # Define all sources
        sources = [
            {
                'name': '国家能源局',
                'urls': ['https://www.nea.gov.cn'],
                'source': 'www.nea.gov.cn',
                'max': 4
            },
            {
                'name': '工业和信息化部',
                'urls': ['https://www.miit.gov.cn'],
                'source': 'www.miit.gov.cn',
                'max': 3
            },
            {
                'name': '新华网',
                'urls': ['https://www.xinhuanet.com/tech/'],
                'source': 'www.xinhuanet.com',
                'max': 5
            },
            {
                'name': '澎湃新闻',
                'urls': ['https://www.thepaper.cn/'],
                'source': 'www.thepaper.cn',
                'max': 3
            }
        ]
        
        all_articles = []
        
        # Crawl each source
        for src in sources:
            if len(all_articles) >= target_count:
                break
            articles = self.crawl_website(src['name'], src['urls'], src['source'], src['max'])
            all_articles.extend(articles)
        
        if not all_articles:
            print("未找到新文章")
            return
        
        print(f"\n找到 {len(all_articles)} 篇文章，开始保存...")
        
        # Save articles
        start_index = self._get_next_index(self.dirs['articles'], 'article')
        for i, article in enumerate(all_articles[:target_count], start=start_index):
            print(f"[{i - start_index + 1}/{min(target_count, len(all_articles))}] 处理: {article['title'][:40]}...")
            content, publish_date = self.extract_article_content(article['link'])
            self.save_article(article, content, publish_date, i)
        
        print("\n" + "=" * 50)
        print("爬取完成！")
        print(f"文章保存在: {self.dirs['articles']}/")
        print(f"链接保存在: {self.dirs['links']}/")

if __name__ == "__main__":
    crawler = CrawlerSkill()
    crawler.run(target_count=10)