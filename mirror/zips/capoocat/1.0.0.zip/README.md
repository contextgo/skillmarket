# Web Crawler Skill for AI Agent

## Overview

This skill provides a web crawling capability to collect articles about artificial intelligence, digitalization, and informatization from Chinese government and news websites.

## Features

- **Multi-source crawling**: Supports government websites and news portals
- **Intelligent filtering**: Uses keywords to find relevant content while excluding irrelevant material
- **Deduplication**: Tracks crawled links to avoid duplicates
- **Date extraction**: Automatically extracts publication dates
- **Incremental saving**: Uses sequential file indexing to preserve existing content
- **Error handling**: Includes retry mechanisms and robust content extraction

## Supported Sources

### Government Websites
- 国家能源局 (www.nea.gov.cn)
- 工业和信息化部 (www.miit.gov.cn)

### News Websites
- 新华网 (www.xinhuanet.com)
- 澎湃新闻 (www.thepaper.cn)

## Keywords Configuration

### Include Keywords
- 人工智能 (Artificial Intelligence)
- 数字化 (Digitalization)
- 信息化 (Informatization)
- 智能化 (Intelligentization)
- 智能技术 (Intelligent Technology)
- AI
- 算法 (Algorithm)
- 大数据 (Big Data)
- 云计算 (Cloud Computing)
- 数字经济 (Digital Economy)
- 数字转型 (Digital Transformation)

### Exclude Keywords
- 报表, 采购, 公示, 公告, 招标, 投标, 结果, 租赁, 服务
- 通知, 办法, 目录, 处罚, 检查, 认定, 标准
- 设备, 购买, 购置, 询价, 竞争性, 谈判, 单一来源, 中标, 成交, 合同

## Usage

### As a Skill in AI Agent

The skill can be invoked by the AI Agent when you need to collect articles about artificial intelligence, digital transformation, or technology policy from Chinese official sources.

### Direct Execution

You can also run the crawler directly:

```bash
python .trae/skills/web-crawler/crawler_skill.py
```

### Output Structure

- `original_articles/` - Original article content
- `article_links/` - Article metadata and links
- `crawled_links.json` - Deduplication tracking

## Customization

To modify the crawler behavior:

1. **Add new sources**: Edit the `sources` list in the `run()` method
2. **Modify keywords**: Update the `keywords` and `exclude_keywords` lists
3. **Adjust crawler settings**: Modify parameters like `max_retries`, `timeout`, etc.

## Dependencies

```
requests
beautifulsoup4
lxml
```

Install with:

```bash
pip install -r requirements.txt
```

## Example Output

```
==================================================
开始爬取人工智能、数字化、信息化相关文章
==================================================

==================================================
开始爬取: 国家能源局

==================================================
开始爬取: 工业和信息化部
  跳过已爬取: 工业和信息化部党组举办树立和践行正确政绩观学习教育辅导报告会...

==================================================
开始爬取: 新华网
  跳过已爬取: 新华视点｜AI赋能医疗，科技守护健康...

==================================================
开始爬取: 澎湃新闻

找到 11 篇文章，开始保存...
[1/10] 处理: 2026年全国工业和信息化科技创新和产业创新融合发展工作座谈会在苏州召开...
  已保存: article_48.txt
...

==================================================
爬取完成！
文章保存在: .\original_articles/
链接保存在: .\article_links/
```
