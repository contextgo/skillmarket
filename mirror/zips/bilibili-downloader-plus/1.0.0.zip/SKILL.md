---
name: bilibili-downloader
description: "B站(Bilibili)视频下载技能。当用户要求下载B站视频、B站合集、bilibili链接中的视频时，应触发此技能。支持单个视频下载和整个合集批量下载，自动选择最高可用画质，支持通过浏览器Cookie获取登录态以解锁1080P/1080P+等更高清晰度。典型触发场景包括：用户给出bilibili.com链接并要求下载、用户提到下载B站视频、用户要求下载某个UP主的合集或系列视频。"
---

# B站视频下载技能

## 概述

此技能提供从 Bilibili (B站) 下载视频的完整工作流，支持单个视频和合集批量下载，自动选择最高可用画质。

## 何时使用

- 用户提供 bilibili.com 或 b23.tv 链接并要求下载
- 用户提到"下载B站视频"、"B站"、"bilibili"等关键词
- 用户要求下载某个UP主的合集或系列视频

## 前置依赖

在首次使用前，运行依赖检查脚本确保环境就绪：

```bash
python3 {SKILL_DIR}/scripts/ensure_deps.py
```

该脚本会自动检测并安装 `yt-dlp` 和 `ffmpeg`。

## 核心工作流

### 1. 查看视频/合集信息

在下载前，先获取视频信息以了解是否属于合集及合集结构：

```bash
python3 {SKILL_DIR}/scripts/bilibili_download.py info "<BILIBILI_URL>"
```

输出包含：视频标题、UP主、所属合集名称、合集内所有视频列表（含分类和BV号）。

### 2. 下载单个视频

```bash
python3 {SKILL_DIR}/scripts/bilibili_download.py download "<BILIBILI_URL>" -o <输出目录>
```

### 3. 下载整个合集

```bash
python3 {SKILL_DIR}/scripts/bilibili_download.py download "<BILIBILI_URL>" -o <输出目录> --collection
```

合集内如有多个分类（section），会自动按分类创建子目录。

### 4. 使用浏览器 Cookie 获取最高画质（推荐）

未登录状态下B站只提供 480P/360P 画质。要获取 1080P 或更高画质，**必须**使用浏览器 Cookie：

```bash
python3 {SKILL_DIR}/scripts/bilibili_download.py download "<BILIBILI_URL>" -o <输出目录> --collection --browser chrome
```

支持的浏览器：`chrome`、`safari`、`edge`、`firefox`。

> **重要**：使用浏览器 Cookie 涉及用户登录态，**必须先征得用户明确同意**后才能使用 `--browser` 参数。

### 5. 自动画质探测

脚本在下载前会自动探测当前能获取的最高画质，并根据结果给出提示：

- **480P 及以下** → 输出醒目警告，建议用户授权浏览器 Cookie 以获得更高画质
- **720P** → 提示画质尚可，登录后可能更高
- **1080P 及以上** → 确认画质良好

探测在每次下载任务开始时自动运行一次（对第一个视频探测），不会阻塞下载流程。如果探测失败则静默跳过。

WorkBuddy 在看到画质探测输出低于 720P 的警告时，应**主动中断下载并询问用户**是否要提供浏览器 Cookie，而不是继续以低画质下载。

## 关键决策指南

### 画质选择策略

1. **始终优先最高画质**。脚本默认使用 `bestvideo+bestaudio/best`。
2. 如果用户偏好最高画质（大多数情况），**主动建议**使用浏览器 Cookie。
3. 使用 Cookie 前**必须征得用户同意**并确认使用哪个浏览器。

### 合集 vs 单视频判断

1. 收到B站链接后，**先用 `info` 命令**查看是否属于合集。
2. 如果属于合集，**主动告知用户**该视频属于合集（共 N 集），并询问是否要下载整个合集。
3. 用户说"相关的都下载"或"系列都下"等表述时，使用 `--collection` 参数。

### 输出目录组织

- 单个合集：`<用户指定目录>/<合集名>/`
- 多分类合集：自动按分类建子目录
- 多个不同合集：分别放到各自命名的子目录中

### 断点续传

脚本使用 `--download-archive` 记录已下载视频。如果下载中断，重新运行同一命令会自动跳过已完成的视频。

## 常见问题处理

| 问题 | 解决方案 |
|------|---------|
| 403 Forbidden | yt-dlp 版本过旧，运行 `pip install -U yt-dlp` 升级 |
| 画质只有 480P | 未使用浏览器 Cookie，建议用户授权后加 `--browser` |
| ffmpeg 未找到 | 运行 `ensure_deps.py` 自动安装 |
| 某些视频需要大会员 | 告知用户该视频需要大会员才能下载高码率版本，普通1080P仍可下载 |

## 后台运行（大量视频时）

下载大量视频时（如 50+ 集合集），建议后台运行并输出日志：

```bash
nohup python3 {SKILL_DIR}/scripts/bilibili_download.py download "<URL>" -o <DIR> --collection --browser chrome > download_log.txt 2>&1 &
```

查看进度：

```bash
tail -f download_log.txt
```
