#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
bilibili_download.py — B站视频/合集下载工具
支持单个视频、合集视频的批量下载，自动选择最高可用画质。

用法:
    # 查看视频信息（不下载）
    python3 bilibili_download.py --info <URL>

    # 下载单个视频到指定目录
    python3 bilibili_download.py --url <URL> --output <DIR>

    # 下载整个合集到指定目录
    python3 bilibili_download.py --url <URL> --output <DIR> --collection

    # 使用浏览器 Cookie（推荐，可获取更高画质）
    python3 bilibili_download.py --url <URL> --output <DIR> --collection --browser chrome
"""

import argparse
import json
import os
import subprocess
import sys
import shutil
from urllib.request import Request, urlopen

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                  "AppleWebKit/537.36 (KHTML, like Gecko) "
                  "Chrome/120.0.0.0 Safari/537.36",
    "Referer": "https://www.bilibili.com",
}


def extract_bvid(url: str) -> str:
    """从 URL 中提取 BV 号"""
    import re
    m = re.search(r"(BV[\w]+)", url)
    return m.group(1) if m else ""


def api_get(url: str) -> dict:
    """请求 B 站 API"""
    req = Request(url, headers=HEADERS)
    with urlopen(req, timeout=15) as resp:
        data = json.loads(resp.read().decode())
    if data.get("code") != 0:
        raise RuntimeError(f"B站 API 错误: {data.get('message', '未知错误')}")
    return data["data"]


def get_video_info(bvid: str) -> dict:
    """获取视频基本信息"""
    return api_get(f"https://api.bilibili.com/x/web-interface/view?bvid={bvid}")


def get_collection_videos(bvid: str) -> list[dict]:
    """
    获取视频所属合集的全部视频列表。
    返回 [{"bvid": ..., "title": ..., "section": ...}, ...]
    """
    info = get_video_info(bvid)
    ugc = info.get("ugc_season")
    if not ugc:
        return []

    result = []
    for section in ugc.get("sections", []):
        section_title = section.get("title", "默认")
        for ep in section.get("episodes", []):
            result.append({
                "bvid": ep.get("bvid", ""),
                "title": ep.get("title", ""),
                "section": section_title,
            })
    return result


def find_yt_dlp() -> str:
    """查找可用的 yt-dlp 路径"""
    # 依次尝试常见位置
    candidates = [
        shutil.which("yt-dlp"),
        os.path.expanduser("~/.local/bin/yt-dlp"),
        os.path.expanduser("~/Library/Python/3.9/bin/yt-dlp"),
        os.path.expanduser("~/Library/Python/3.10/bin/yt-dlp"),
        os.path.expanduser("~/Library/Python/3.11/bin/yt-dlp"),
        os.path.expanduser("~/Library/Python/3.12/bin/yt-dlp"),
    ]
    for c in candidates:
        if c and os.path.isfile(c):
            return c
    return ""


def find_ffmpeg() -> str:
    """查找可用的 ffmpeg 路径"""
    candidates = [
        shutil.which("ffmpeg"),
        "/tmp/ffmpeg",
        "/usr/local/bin/ffmpeg",
        "/opt/homebrew/bin/ffmpeg",
    ]
    for c in candidates:
        if c and os.path.isfile(c):
            return c
    return ""


QUALITY_MAP = {
    127: "8K 超高清",
    126: "杜比视界",
    125: "HDR 真彩",
    120: "4K 超清",
    116: "1080P 60帧",
    112: "1080P 高码率",
    80:  "1080P 高清",
    64:  "720P 高清",
    32:  "480P 清晰",
    16:  "360P 流畅",
}


def probe_max_quality(bvid: str, browser: str = "") -> dict:
    """
    探测指定视频当前可获取的最高画质。
    返回 {"max_height": int, "max_quality_id": int, "quality_label": str, "all_qualities": list}
    """
    info = get_video_info(bvid)
    aid, cid = info["aid"], info["cid"]

    # 请求播放地址（DASH 格式，fnval=16）
    play_url = (f"https://api.bilibili.com/x/player/playurl"
                f"?avid={aid}&cid={cid}&qn=127&fnval=16&fourk=1")
    req = Request(play_url, headers=HEADERS)
    play_data = json.loads(urlopen(req, timeout=15).read().decode())

    if play_data.get("code") != 0:
        return {"max_height": 0, "max_quality_id": 0, "quality_label": "未知",
                "all_qualities": []}

    data = play_data["data"]
    accept = data.get("accept_quality", [])

    # 从 DASH 流中取实际可用的最高分辨率
    dash = data.get("dash", {})
    videos = dash.get("video", [])

    max_height = 0
    max_qid = 0
    for v in videos:
        h = v.get("height", 0)
        vid = v.get("id", 0)
        if h > max_height:
            max_height = h
            max_qid = vid

    label = QUALITY_MAP.get(max_qid, f"{max_height}P")

    return {
        "max_height": max_height,
        "max_quality_id": max_qid,
        "quality_label": label,
        "all_qualities": accept,
    }


def check_quality_and_warn(bvid: str, browser: str = "") -> None:
    """
    下载前探测画质，如果低于 720P 则输出明显警告。
    此函数仅在首个视频时调用一次，避免重复探测。
    """
    try:
        probe = probe_max_quality(bvid, browser)
        h = probe["max_height"]
        label = probe["quality_label"]
        accept = probe["all_qualities"]

        accept_labels = [QUALITY_MAP.get(q, str(q)) for q in sorted(accept, reverse=True)]

        print(f"\n🔍 画质探测结果:")
        print(f"   当前可下载最高画质: {label} ({probe['max_height']}P)")
        print(f"   该视频支持的画质档位: {', '.join(accept_labels)}")

        if h <= 480:
            print()
            print("=" * 60)
            print("⚠️  警告: 当前只能获取 480P 及以下画质！")
            print("   这通常是因为未使用浏览器登录态。")
            print("   建议: 在已登录B站的浏览器中运行，并加上")
            print("         --browser chrome (或 safari / edge / firefox)")
            print("   登录后通常可获取 1080P 高清画质。")
            print("=" * 60)
            print()
        elif h >= 1080:
            print(f"   ✅ 画质良好，将以 {label} 下载。\n")
        else:
            print(f"   ℹ️  画质尚可 ({label})，登录后可能获得更高画质。\n")

    except Exception as e:
        # 探测失败不阻塞下载流程
        print(f"   ℹ️  画质探测跳过 ({e})\n")


def download_video(bvid: str, output_dir: str, browser: str = "",
                   archive_file: str = "") -> bool:
    """使用 yt-dlp 下载单个视频（最高可用画质）"""
    yt_dlp = find_yt_dlp()
    if not yt_dlp:
        print("❌ 找不到 yt-dlp，请先安装: pip install yt-dlp", file=sys.stderr)
        return False

    url = f"https://www.bilibili.com/video/{bvid}"
    cmd = [
        yt_dlp,
        "-f", "bestvideo+bestaudio/best",
        "--merge-output-format", "mp4",
        "--no-warnings",
        "-o", os.path.join(output_dir, "%(title)s.%(ext)s"),
        url,
    ]

    ffmpeg = find_ffmpeg()
    if ffmpeg:
        cmd.insert(1, "--ffmpeg-location")
        cmd.insert(2, ffmpeg)

    if browser:
        cmd.insert(1, "--cookies-from-browser")
        cmd.insert(2, browser)

    if archive_file:
        cmd.insert(1, "--download-archive")
        cmd.insert(2, archive_file)

    result = subprocess.run(cmd, capture_output=False)
    return result.returncode == 0


def cmd_info(args):
    """--info: 打印视频 / 合集信息"""
    bvid = extract_bvid(args.url)
    if not bvid:
        print("❌ 无法从 URL 提取 BV 号", file=sys.stderr)
        sys.exit(1)

    info = get_video_info(bvid)
    print(f"标题: {info['title']}")
    print(f"UP主: {info['owner']['name']}")
    print(f"时长: {info.get('duration', 0)} 秒")
    print(f"播放: {info['stat']['view']}")

    # 画质探测
    check_quality_and_warn(bvid, getattr(args, "browser", ""))

    ugc = info.get("ugc_season")
    if ugc:
        videos = get_collection_videos(bvid)
        sections = {}
        for v in videos:
            sections.setdefault(v["section"], []).append(v)

        print(f"\n📚 所属合集: {ugc['title']} (共 {len(videos)} 集)")
        for sec, vids in sections.items():
            print(f"\n  [{sec}] ({len(vids)} 集)")
            for v in vids:
                print(f"    {v['bvid']} | {v['title']}")
    else:
        print("\n该视频不属于任何合集。")


def cmd_download(args):
    """下载视频或合集"""
    bvid = extract_bvid(args.url)
    if not bvid:
        print("❌ 无法从 URL 提取 BV 号", file=sys.stderr)
        sys.exit(1)

    output_dir = os.path.abspath(args.output)

    # 下载前画质探测（仅对第一个视频探测一次）
    check_quality_and_warn(bvid, args.browser)

    if args.collection:
        # 下载整个合集
        videos = get_collection_videos(bvid)
        if not videos:
            print("⚠️  该视频不属于合集，将仅下载单个视频。")
            videos = [{"bvid": bvid, "title": "", "section": ""}]

        # 如果合集有多个分类，按分类建子目录
        sections = {v["section"] for v in videos}
        use_section_dirs = len(sections) > 1

        archive = os.path.join(output_dir, ".downloaded.txt")
        total = len(videos)
        success = 0

        for i, v in enumerate(videos, 1):
            if use_section_dirs and v["section"]:
                dest = os.path.join(output_dir, v["section"])
            else:
                dest = output_dir
            os.makedirs(dest, exist_ok=True)

            print(f"\n[{i}/{total}] {v['title'] or v['bvid']}")
            if download_video(v["bvid"], dest, args.browser, archive):
                success += 1

        print(f"\n✅ 合集下载完成: {success}/{total}")
    else:
        # 下载单个视频
        os.makedirs(output_dir, exist_ok=True)
        print(f"下载 {bvid} ...")
        if download_video(bvid, output_dir, args.browser):
            print("✅ 下载完成")
        else:
            print("❌ 下载失败", file=sys.stderr)
            sys.exit(1)


def main():
    parser = argparse.ArgumentParser(description="B站视频/合集下载工具")
    sub = parser.add_subparsers(dest="command")

    # info 子命令
    p_info = sub.add_parser("info", help="查看视频/合集信息")
    p_info.add_argument("url", help="B站视频 URL")

    # download 子命令
    p_dl = sub.add_parser("download", help="下载视频")
    p_dl.add_argument("url", help="B站视频 URL")
    p_dl.add_argument("-o", "--output", required=True, help="输出目录")
    p_dl.add_argument("-c", "--collection", action="store_true",
                      help="下载整个合集（含所有分类）")
    p_dl.add_argument("-b", "--browser", default="",
                      help="浏览器名称，用于读取登录态 Cookie（如 chrome/safari/edge）")

    # 兼容直接传 --info / --url 的旧用法
    parser.add_argument("--info", metavar="URL", help="查看视频信息")
    parser.add_argument("--url", metavar="URL", help="下载视频 URL")
    parser.add_argument("--output", "-o", metavar="DIR", help="输出目录")
    parser.add_argument("--collection", "-c", action="store_true")
    parser.add_argument("--browser", "-b", default="")

    args = parser.parse_args()

    if args.command == "info":
        cmd_info(args)
    elif args.command == "download":
        cmd_download(args)
    elif args.info:
        # 兼容旧用法
        args.url = args.info
        cmd_info(args)
    elif args.url:
        if not args.output:
            print("❌ 请用 --output 指定输出目录", file=sys.stderr)
            sys.exit(1)
        cmd_download(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
