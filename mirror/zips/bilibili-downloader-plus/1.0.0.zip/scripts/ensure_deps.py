#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ensure_deps.py — 确保 yt-dlp 和 ffmpeg 已安装
在下载前运行此脚本检查并自动安装依赖。
"""

import os
import shutil
import subprocess
import sys


def check_yt_dlp() -> str:
    """检查 yt-dlp 是否可用，返回路径或空字符串"""
    candidates = [
        shutil.which("yt-dlp"),
        os.path.expanduser("~/.local/bin/yt-dlp"),
        os.path.expanduser("~/Library/Python/3.9/bin/yt-dlp"),
        os.path.expanduser("~/Library/Python/3.10/bin/yt-dlp"),
        os.path.expanduser("~/Library/Python/3.11/bin/yt-dlp"),
        os.path.expanduser("~/Library/Python/3.12/bin/yt-dlp"),
    ]
    for c in candidates:
        if c and os.path.isfile(c):
            return c
    return ""


def check_ffmpeg() -> str:
    """检查 ffmpeg 是否可用"""
    candidates = [
        shutil.which("ffmpeg"),
        "/tmp/ffmpeg",
        "/usr/local/bin/ffmpeg",
        "/opt/homebrew/bin/ffmpeg",
    ]
    for c in candidates:
        if c and os.path.isfile(c):
            return c
    return ""


def install_yt_dlp():
    """尝试安装 yt-dlp"""
    print("正在安装 yt-dlp ...")
    subprocess.run([sys.executable, "-m", "pip", "install", "--user", "-U", "yt-dlp"],
                   check=False)


def install_ffmpeg_mac():
    """在 macOS 上下载预编译 ffmpeg"""
    import platform
    if platform.system() != "Darwin":
        print("⚠️  非 macOS 系统，请手动安装 ffmpeg: https://ffmpeg.org/download.html")
        return

    dest = "/tmp/ffmpeg"
    if os.path.isfile(dest):
        return

    print("正在下载 ffmpeg (macOS 预编译版本) ...")
    subprocess.run([
        "curl", "-L", "-o", "/tmp/ffmpeg.zip",
        "https://evermeet.cx/ffmpeg/getrelease/zip"
    ], check=False)

    if os.path.exists("/tmp/ffmpeg.zip"):
        subprocess.run(["unzip", "-o", "-d", "/tmp", "/tmp/ffmpeg.zip"], check=False)
        os.chmod(dest, 0o755)
        print(f"✅ ffmpeg 已安装到 {dest}")


def main():
    print("检查依赖项 ...\n")

    yt_dlp = check_yt_dlp()
    if yt_dlp:
        print(f"✅ yt-dlp: {yt_dlp}")
    else:
        print("❌ yt-dlp 未安装，正在安装 ...")
        install_yt_dlp()
        yt_dlp = check_yt_dlp()
        if yt_dlp:
            print(f"✅ yt-dlp 安装成功: {yt_dlp}")
        else:
            print("❌ yt-dlp 安装失败，请手动执行: pip install yt-dlp")

    ffmpeg = check_ffmpeg()
    if ffmpeg:
        print(f"✅ ffmpeg: {ffmpeg}")
    else:
        print("❌ ffmpeg 未安装，正在安装 ...")
        install_ffmpeg_mac()
        ffmpeg = check_ffmpeg()
        if ffmpeg:
            print(f"✅ ffmpeg 安装成功: {ffmpeg}")
        else:
            print("❌ ffmpeg 安装失败，请手动安装: brew install ffmpeg")

    print("\n依赖检查完成。")


if __name__ == "__main__":
    main()
