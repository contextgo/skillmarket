#!/usr/bin/env python3
"""
红利低波ETF(512890) 历史净值数据获取与MA60W分析脚本

全程使用累计净值(LJJZ)口径，彻底消除2021-10-22份额折算(1拆2)的影响：
- 实际涨幅：基于累计净值计算（真实复权收益）
- MA60W：累计净值的60周移动均线
- 净值/均线、偏离均线：均在累计净值口径下比较
- 单位净值(DWJZ)仅作参考展示，不参与均线计算
"""

import json
import math
import subprocess
import sys
from datetime import datetime
from collections import defaultdict

FUND_CODE = "512890"
API_BASE = "https://api.fund.eastmoney.com/f10/lsjz"
PAGE_SIZE = 20
MA_WINDOW = 60  # 60周均线，不足60周时不输出均线（避免虚假数据）


def fetch_page(page_index):
    url = (
        f"{API_BASE}?fundCode={FUND_CODE}"
        f"&pageIndex={page_index}&pageSize={PAGE_SIZE}"
        f"&startDate=&endDate="
    )
    cmd = [
        "curl", "-s", "-k",
        "-H", "Referer: https://fundf10.eastmoney.com/",
        "-H", "User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
        url
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
    if result.returncode != 0:
        raise RuntimeError(f"curl failed: {result.stderr}")
    return json.loads(result.stdout)


def fetch_all_data():
    print("正在获取数据...", file=sys.stderr)
    first = fetch_page(1)
    total = first["TotalCount"]
    total_pages = math.ceil(total / PAGE_SIZE)
    print(f"共 {total} 条，{total_pages} 页", file=sys.stderr)

    all_records = first["Data"]["LSJZList"][:]
    for page in range(2, total_pages + 1):
        if page % 20 == 0:
            print(f"  第 {page}/{total_pages} 页...", file=sys.stderr)
        data = fetch_page(page)
        records = data["Data"]["LSJZList"]
        if not records:
            break
        all_records.extend(records)

    print(f"获取完成，共 {len(all_records)} 条", file=sys.stderr)
    return all_records


def parse_records(records):
    """解析为按日期升序的列表 [(date, nav, ljnav)]"""
    parsed = []
    for r in records:
        try:
            d = datetime.strptime(r["FSRQ"], "%Y-%m-%d").date()
            nav = float(r["DWJZ"])
            ljnav = float(r["LJJZ"])
            parsed.append((d, nav, ljnav))
        except (KeyError, ValueError):
            continue
    parsed.sort(key=lambda x: x[0])
    return parsed


def build_weekly(daily_data):
    """取每周最后一个交易日，返回 [(date, nav, ljnav)]"""
    week_map = defaultdict(list)
    for d, nav, ljnav in daily_data:
        iso = d.isocalendar()
        week_map[(iso[0], iso[1])].append((d, nav, ljnav))
    weekly = []
    for key in sorted(week_map):
        weekly.append(sorted(week_map[key])[-1])
    return weekly


def calc_ma60w(weekly_data):
    """
    计算累计净值的60周移动均线。
    不足60周时 ma60w=None，严格避免虚假均线。
    返回 [(date, nav, ljnav, ma60w_or_None)]
    """
    result = []
    window = []
    for d, nav, ljnav in weekly_data:
        window.append(ljnav)
        if len(window) > MA_WINDOW:
            window.pop(0)
        ma60w = sum(window) / len(window) if len(window) >= MA_WINDOW else None
        result.append((d, nav, ljnav, ma60w))
    return result


def get_year_end(weekly_with_ma):
    """提取每年末（最后一个交易周）数据，返回 {year: (date, nav, ljnav, ma60w)}"""
    year_data = {}
    for row in weekly_with_ma:
        y = row[0].year
        if y not in year_data or row[0] > year_data[y][0]:
            year_data[y] = row
    return year_data


def fmt_pct(val):
    if val is None:
        return "N/A"
    return f"+{val:.2f}%" if val >= 0 else f"{val:.2f}%"


def fmt_num(val, decimals=4):
    return f"{val:.{decimals}f}" if val is not None else "N/A"


def print_row(label, date_str, nav, ljnav, ljnav_chg, ma60w, ma60w_chg, ratio, deviation, bold=False):
    b = "**" if bold else ""
    ma_str = fmt_num(ma60w) if ma60w is not None else "N/A"
    print(
        f"| {b}{label}{b} | {date_str} "
        f"| {b}{fmt_num(nav)}{b} | {b}{fmt_num(ljnav)}{b} "
        f"| {fmt_pct(ljnav_chg)} "
        f"| {b}{ma_str}{b} "
        f"| {fmt_pct(ma60w_chg)} "
        f"| {fmt_num(ratio)} "
        f"| {fmt_pct(deviation)} |"
    )


def main():
    records = fetch_all_data()
    daily = parse_records(records)
    if not daily:
        print("错误：未获取到有效数据")
        sys.exit(1)

    weekly = build_weekly(daily)
    print(f"周线数据点：{len(weekly)} 个", file=sys.stderr)

    weekly_ma = calc_ma60w(weekly)
    year_end = get_year_end(weekly_ma)

    latest_date, latest_nav, latest_ljnav, latest_ma60w = weekly_ma[-1]

    print("\n## 红利低波ETF(512890) 历年数据对比表\n")
    print(f"数据更新至：{latest_date.strftime('%Y-%m-%d')}（所有数值均使用累计净值口径）\n")
    print("| 年份 | 日期 | 单位净值 | 累计净值 | 实际涨幅 | MA60W | 均线涨幅 | 净值/均线 | 偏离均线 |")
    print("|------|------|----------|----------|----------|-------|----------|-----------|----------|")

    sorted_years = sorted(year_end.keys())
    prev_ljnav = None
    prev_ma60w = None

    for year in sorted_years:
        d, nav, ljnav, ma60w = year_end[year]

        ljnav_chg = (ljnav - prev_ljnav) / prev_ljnav * 100 if prev_ljnav else None
        ma60w_chg = (ma60w - prev_ma60w) / prev_ma60w * 100 if (prev_ma60w and ma60w) else None
        ratio     = ljnav / ma60w if ma60w else None
        deviation = (ljnav - ma60w) / ma60w * 100 if ma60w else None

        print_row(str(year), d.strftime("%m-%d"), nav, ljnav,
                  ljnav_chg, ma60w, ma60w_chg, ratio, deviation)

        prev_ljnav = ljnav
        prev_ma60w = ma60w

    # 当前行（若当前不是年末）
    current_year = latest_date.year
    is_year_end = current_year in year_end and year_end[current_year][0] == latest_date
    if not is_year_end:
        base = year_end.get(current_year - 1) or year_end.get(sorted_years[-1])
        base_ljnav = base[2] if base else None
        base_ma60w = base[3] if base else None

        ljnav_chg = (latest_ljnav - base_ljnav) / base_ljnav * 100 if base_ljnav else None
        ma60w_chg = (latest_ma60w - base_ma60w) / base_ma60w * 100 if (base_ma60w and latest_ma60w) else None
        ratio     = latest_ljnav / latest_ma60w if latest_ma60w else None
        deviation = (latest_ljnav - latest_ma60w) / latest_ma60w * 100 if latest_ma60w else None

        print_row("当前", latest_date.strftime("%Y-%m-%d"), latest_nav, latest_ljnav,
                  ljnav_chg, latest_ma60w, ma60w_chg, ratio, deviation, bold=True)

    print("\n**说明：**")
    print("- 实际涨幅、MA60W、净值/均线、偏离均线均基于**累计净值(LJJZ)**计算，不受2021-10-22份额折算影响")
    print("- MA60W = 累计净值的60周移动均线（不足60周时显示N/A）")
    print("- 偏离均线 > 0 表示累计净值高于均线，< 0 表示低于均线")
    print("- 实际涨幅/均线涨幅均为相对上年末的变化")


if __name__ == "__main__":
    main()
