---
name: meta
description: 闭环任务执行框架。将复杂任务拆解为「执行」和「评估」两个动态生成的 Skill，循环迭代直到质量达标。适用于代码重构、文档撰写、方案设计等需要多轮优化的场景。当用户提到 meta skill、metaskill、用 meta 执行时使用。
metadata:
  author: openclaw
  version: "3.0"
---

# Meta Skill — 闭环任务执行框架

当用户要求使用 meta skill 处理任务时，按以下流程执行。

## Phase 0: 初始化

1. 确定 `WORKDIR`：用户指定路径优先，否则使用当前工作目录。
2. 从任务描述提取关键词，生成 `TASK_ID`（kebab-case，仅 `a-z0-9` 和 `-`，≤ 30 字符）。
   - 示例：`"优化登录页面性能"` → `optimize-login-perf`
3. 若 `{WORKDIR}/.tmp/{TASK_ID}/` 已存在，询问用户：覆盖 / 追加编号（`task-id-2`）/ 取消。
4. 创建目录：

```
{WORKDIR}/.tmp/{TASK_ID}/
  ├── executor/SKILL.md
  └── evaluator/SKILL.md
```

## Phase 1: 生成执行 Skill

1. 分析用户意图：拆解目标、约束、预期产出。
2. 搜索最佳实践（有联网工具则搜索 2-3 个查询，否则基于自身知识并标注 `[offline]`）。
3. 写入 `executor/SKILL.md`（≤ 100 行），结构如下：

```markdown
---
name: executor-{TASK_ID}
description: {任务}的执行指南
metadata:
  iteration: "1"
---
# 执行指南: {任务标题}

## 目标
{一句话}

## 参考
{最佳实践来源或 [offline]}

## 步骤
1. {做什么} → 产出: {什么}
2. ...

## 约束
- ...
```

## Phase 2: 生成评估 Skill

1. 根据任务目标推导评估维度（正确性、完整性、质量等）。
2. 搜索该领域的 review checklist（有联网工具则搜索，否则标注 `[offline]`）。
3. 写入 `evaluator/SKILL.md`（≤ 100 行），结构如下：

```markdown
---
name: evaluator-{TASK_ID}
description: {任务}的评估标准
metadata:
  iteration: "1"
---
# 评估标准: {任务标题}

## 维度
| 维度 | 权重 | 通过标准 |
|------|------|----------|
| ... | ... | {可判定的标准} |

## 流程
1. 逐项检查
2. 记录结果（PASS / FAIL + 原因）
3. 全部 PASS → 通过；任一 FAIL → 给出改进建议

## 输出格式
- 状态: PASS / FAIL
- 详情: [逐项结果]
- 改进建议: [如有]
```

## Phase 3: 执行-评估循环

最大迭代次数默认 **5**，用户可覆盖。每轮：

1. **执行**：读取最新 `executor/SKILL.md`，按步骤执行，记录变更摘要。
2. **评估**：读取最新 `evaluator/SKILL.md`，逐项评估，输出 PASS / FAIL + 详情。
3. **判定**：
   - 全部 PASS → 进入 Phase 4。
   - 存在 FAIL → 分析原因，更新 executor 和/或 evaluator，输出本轮摘要（改了什么、下轮重点），回到步骤 1。
4. **达到上限仍有 FAIL** → 输出当前最佳结果 + 剩余问题，询问用户：继续 / 接受 / 终止。

## Phase 4: 完成报告

输出以下结构化报告：

```markdown
## 任务完成报告
### 摘要
{做了什么}
### 评估结果
{最终评估输出}
### 迭代历程
- 次数: {N}
- 关键改进: {逐轮概述}
### 产出文件
{路径列表}
### 经验总结
{可复用的模式或教训}
```

## 异常处理

| 场景 | 策略 |
|------|------|
| 联网不可用 | 降级为离线模式，标注 `[offline]` |
| Skill 文件丢失 | 从模板重新生成，提醒用户 |
| 用户中断 | 保存进度，输出已完成摘要 |
| 单步失败 | 记录错误，尝试替代方案，评估中标记 |
| 达到迭代上限 | 输出最佳结果 + 剩余问题，询问用户 |

## 注意事项

- 同一 `WORKDIR` 下可并存多个任务（不同 `TASK_ID`）。
- 迭代中 Skill 内容会演进，行数限制仅约束初始生成。
- `.tmp/` 为临时目录，完成后可清理。
- 每轮迭代前必须重新读取最新 Skill 文件。
- 可在 executor 步骤中调用其他 skill。
