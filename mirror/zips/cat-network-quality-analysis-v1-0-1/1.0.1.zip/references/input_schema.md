# 内部 JSON Schema

`cat_network_quality_analysis.py` 的 `_parse_markdown_to_report()` 函数将 CAT AI Console 返回的 Markdown 文本解析为以下结构化 JSON，随后由 `_build_html()` 渲染为 HTML 并通过 Playwright/Chromium 转为 PDF。

如果 SSE 流中包含 `pcap_check.done` 事件，`_build_pcap_section()` 会将其 `Data` 字段转为额外的 section 追加到报告末尾。

> 此 JSON 是脚本内部的中间表示，不对外暴露。用户只需要通过 CLI 参数与脚本交互。

## 数据流

```
SSE 事件流
    │
    ├── agent.done → full_text (Markdown)
    │       │
    │       └── _parse_markdown_to_report() → report JSON
    │                                            │
    ├── pcap_check.done → tool_data              │
    │       │                                    │
    │       └── _build_pcap_section() → section ─┘── 追加到 report["sections"]
    │
    └── agent.start → session_id (stdout 输出，供后续抓包分析使用)
```

## 顶层字段

| 字段 | 类型 | 来源 | 说明 |
|------|------|------|------|
| `title` | string | 硬编码 | 固定为 `"拨测任务分析报告"` |
| `task_id` | string | CLI `--task-id` | 任务 ID，显示在副标题中，也用于默认输出文件名。未提供时为空字符串 |
| `sections` | array[section] | Markdown 解析 + pcap 追加 | 报告章节列表，至少包含 1 个元素（无法解析时会生成兜底 section） |

## section 对象

每个 section 代表报告中的一个章节，由 Markdown 标题层级映射而来，或由 `_build_pcap_section()` 构造。

### 标题层级映射规则

- `#` / `##` → 主章节（独立 section）
- `###` → 子章节（独立 section）
- `####` / `#####` → 子块标题（关联到紧随其后的表格 `title` 字段）

### 字段定义

| 字段 | 类型 | 是否必填 | 说明 |
|------|------|---------|------|
| `title` | string | 可选 | 章节标题，来自 Markdown `#`/`##`/`###` 标题。可能包含 emoji，如 `"1. 数据总览 📊"` |
| `description` | string | 可选 | 章节正文，由标题下方的非表格文本行拼接而成（`\n` 分隔）。渲染时支持 Markdown 内联格式：`**bold**`、`` `code` ``、`~~strike~~` |
| `tables` | array[table] | 可选 | 章节中的表格列表，默认为空数组 `[]` |
| `note` | string | 可选 | 灰色小字备注，渲染为 `<div class="note-text">`。当前 Markdown 解析器不会生成该字段，但 `_build_html()` 支持渲染，预留供未来扩展 |

## table 对象

每个 table 代表一个 Markdown 表格，从 `| col1 | col2 |` 格式解析而来。

| 字段 | 类型 | 是否必填 | 说明 |
|------|------|---------|------|
| `title` | string | 可选 | 表格标题，来自紧邻表格上方的 `####`/`#####` 子标题 |
| `headers` | array[string] | **必填** | 表头列名列表，来自 Markdown 表格第一行 |
| `rows` | array[array[string]] | **必填** | 数据行，每行为字符串数组，来自 Markdown 表格数据行（自动跳过分隔线行 `|---|---|`） |

## pcap section（抓包分析候选列表）

当 SSE 流中包含 `pcap_check.done` 事件时，`_build_pcap_section()` 将事件的 `Data` 字段转为一个 section，结构如下：

```json
{
  "title": "🔍 抓包分析候选列表",
  "description": "检测到 N 个错误记录配置了\"错误时抓包\"模式，以下为抓包分析候选项。",
  "tables": [
    {
      "headers": ["城市", "运营商", "错误码", "任务ID", "拨测时间", "拨测点编码"],
      "rows": [
        ["慕尼黑", "Germany_COLT", "600", "task-xxx", "2026-03-17 07:06:35", "xxxxx"],
        ...
      ]
    }
  ]
}
```

> 该 section 由 `_build_pcap_section()` 直接构造（非 Markdown 解析），追加到 `report["sections"]` 末尾。

### 输入：tool_data（pcap_check.done 的 Data 字段）

| 字段 | 类型 | 说明 |
|------|------|------|
| `items` | array[pcap_item] | 抓包候选项列表 |

### pcap_item 对象

| 字段 | 类型 | 说明 | 示例 |
|------|------|------|------|
| `city` | string | 拨测城市 | `"慕尼黑"` |
| `operator` | string | 运营商名称 | `"Germany_COLT"` |
| `error_id` | string | 错误码 | `"600"` |
| `task_id` | string | 任务 ID | `"task-xxxxxxxx"` |
| `probe_time` | number | 拨测时间（**毫秒时间戳**） | `1773905195000` |
| `code` | string | 拨测点编码 | `"xxxxx"` |

> `probe_time` 在渲染到表格时会被格式化为 `YYYY-MM-DD HH:MM:SS`（本地时区）。

## SSE 事件解析结果

`_parse_sse_event()` 将原始 SSE 事件解析为以下统一结构，供 `_stream_cat_analysis()` 消费：

| 字段 | 类型 | 说明 |
|------|------|------|
| `type` | string | 事件类型：`agent.start`、`agent_message_chunk`、`agent.done`、`pcap_check.done` 等 |
| `content` | string | 增量文本内容（`agent_message_chunk` 时有值） |
| `full_text` | string | 完整文本（`agent.done` 时有值） |
| `session_id` | string | 会话 ID（`agent.start` 时有值，`agent.done` 也可能携带作为备选） |
| `tool_name` | string | 工具名称（`pcap_check.done` 时为 `"pcap_check"`） |
| `tool_data` | object \| null | 工具附带数据（`pcap_check.done` 时为包含 `items` 的对象，其他事件为 `null`） |

## 完整 JSON 示例

```json
{
  "title": "拨测任务分析报告",
  "task_id": "task-xxxxxxxx",
  "sections": [
    {
      "title": "1. 数据总览 📊",
      "description": "分析时间范围: 2026-03-19 16:40 ~ 2026-03-20 16:40\n共发生 4 次错误，涉及 3 种错误码。",
      "tables": [
        {
          "title": "错误分布",
          "headers": ["错误码", "次数", "占比"],
          "rows": [
            ["600", "1", "25%"],
            ["601", "2", "50%"],
            ["608", "1", "25%"]
          ]
        }
      ]
    },
    {
      "title": "2. 详细分析",
      "description": "以下为各错误的详细分析。",
      "tables": [],
      "note": "数据来源: CAT AI Console"
    },
    {
      "title": "🔍 抓包分析候选列表",
      "description": "检测到 2 个错误记录配置了\"错误时抓包\"模式，以下为抓包分析候选项。",
      "tables": [
        {
          "headers": ["城市", "运营商", "错误码", "任务ID", "拨测时间", "拨测点编码"],
          "rows": [
            ["新加坡市", "Canada_Digitalocean", "601", "task-xxxxxxxx", "2026-03-19 20:22:36", "xxxxx"],
            ["天水市", "中国电信", "600", "task-xxxxxxx", "2026-03-20 16:11:09", "xxxxx"]
          ]
        }
      ]
    }
  ]
}
```
