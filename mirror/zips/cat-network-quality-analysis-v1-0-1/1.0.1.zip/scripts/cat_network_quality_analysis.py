#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CAT Network Quality Analysis — 将 CAT 网络质量分析与 PDF 报告生成串联为顺序管道。

用法:
    python3 cat_network_quality_analysis.py \
        --query-text "请总结分析最近3小时的错误情况" \
        [--task-id task-xxx] \
        [--start-time 1773658839444] \
        [--end-time 1773745239444] \
        [--session-id xxx] \
        [--output report.pdf]

依赖:
    pip3 install tencentcloud-sdk-python playwright
    python3 -m playwright install chromium
"""

from tencentcloud.common.credential import Credential


import argparse
import datetime
import html as html_mod
import json
import os
import re
import ssl
import sys
import tempfile
import urllib.request
from typing import Any

# ---------------------------------------------------------------------------
# 腾讯云 SDK (无类型存根)
# ---------------------------------------------------------------------------
from tencentcloud.common import credential
from tencentcloud.common.common_client import CommonClient
from tencentcloud.common.exception.tencent_cloud_sdk_exception import (
    TencentCloudSDKException,
)
from tencentcloud.common.profile.client_profile import ClientProfile
from tencentcloud.common.profile.http_profile import HttpProfile

# ---------------------------------------------------------------------------
# Playwright — 通过 Chromium 将 HTML 渲染为 PDF，原生支持彩色 emoji
# ---------------------------------------------------------------------------
try:
    from playwright.sync_api import sync_playwright
except ImportError:
    print(
        "需要安装 playwright 库:\n"
        "  pip3 install playwright\n"
        "  python3 -m playwright install chromium",
        file=sys.stderr,
    )
    sys.exit(1)


# ═══════════════════════════════════════════════════════════════════════════
# 0. 字体资源自动下载
# ═══════════════════════════════════════════════════════════════════════════

# 字体文件清单：(文件名, 主选下载地址, 备选下载地址)
_FONT_ASSETS: list[tuple[str, str, str]] = [
    (
        "NotoSansSC-Regular.ttf",
        "https://github.com/notofonts/noto-cjk/raw/main/Sans/SubsetOTF/SC/NotoSansSC-Regular.otf",
        "https://cdn.jsdelivr.net/gh/notofonts/noto-cjk@main/Sans/SubsetOTF/SC/NotoSansSC-Regular.otf",
    ),
    (
        "NotoSansSC-Bold.ttf",
        "https://github.com/notofonts/noto-cjk/raw/main/Sans/SubsetOTF/SC/NotoSansSC-Bold.otf",
        "https://cdn.jsdelivr.net/gh/notofonts/noto-cjk@main/Sans/SubsetOTF/SC/NotoSansSC-Bold.otf",
    ),
    (
        "NotoColorEmoji-Regular.ttf",
        "https://github.com/googlefonts/noto-emoji/raw/main/fonts/NotoColorEmoji.ttf",
        "https://cdn.jsdelivr.net/gh/googlefonts/noto-emoji@main/fonts/NotoColorEmoji.ttf",
    ),
]


def _get_ssl_context() -> ssl.SSLContext:
    """
    获取可用的 SSL 上下文（在默认验证失败后调用）。
    优先级：certifi 证书 > 跳过验证（仅用于下载公开字体文件）。
    """
    # 1. 尝试使用 certifi 提供的证书（pip install certifi 后可用）
    try:
        import certifi  # noqa: F811
        ctx = ssl.create_default_context(cafile=certifi.where())
        print("[Font] 使用 certifi 证书库", file=sys.stderr)
        return ctx
    except (ImportError, Exception):
        pass

    # 2. 回退：跳过证书验证（仅用于下载公开的开源字体文件）
    print("[Font] ⚠️ 跳过 SSL 证书验证（仅用于下载公开字体）", file=sys.stderr)
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx


def _download_file(url: str, dest: str, timeout: int = 120) -> bool:
    """下载单个文件，成功返回 True。支持 SSL 证书回退。"""
    try:
        print(f"[Font] 正在下载: {url}", file=sys.stderr)
        req = urllib.request.Request(url, headers={"User-Agent": "CAT-Skill/1.0"})

        # 先尝试默认 SSL（系统证书）
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = resp.read()
        except (ssl.SSLCertVerificationError, ssl.SSLError, OSError):
            # SSL 验证失败，使用回退上下文重试
            print(f"[Font] SSL 验证失败，尝试回退方式…", file=sys.stderr)
            ssl_ctx = _get_ssl_context()
            with urllib.request.urlopen(req, timeout=timeout, context=ssl_ctx) as resp:
                data = resp.read()

        os.makedirs(os.path.dirname(dest), exist_ok=True)
        with open(dest, "wb") as f:
            f.write(data)
        size_mb = len(data) / (1024 * 1024)
        print(f"[Font] 下载完成: {os.path.basename(dest)} ({size_mb:.1f} MB)", file=sys.stderr)
        return True
    except Exception as e:
        print(f"[Font] 下载失败 ({url}): {e}", file=sys.stderr)
        return False


def _ensure_fonts(font_dir: str) -> None:
    """
    确保 assets/ 目录下所有必需的字体文件存在。
    如果字体文件缺失，依次尝试主选和备选地址下载。
    """
    all_present = True
    for filename, _primary, _fallback in _FONT_ASSETS:
        if not os.path.isfile(os.path.join(font_dir, filename)):
            all_present = False
            break

    if all_present:
        return  # 所有字体已存在，无需下载

    print("[Font] 检测到字体文件缺失，开始自动下载…", file=sys.stderr)
    os.makedirs(font_dir, exist_ok=True)

    for filename, primary_url, fallback_url in _FONT_ASSETS:
        dest = os.path.join(font_dir, filename)
        if os.path.isfile(dest):
            continue  # 该字体已存在

        # 尝试主选地址
        if _download_file(primary_url, dest):
            continue

        # 主选失败，尝试备选地址
        print(f"[Font] 主选地址失败，尝试备选地址…", file=sys.stderr)
        if _download_file(fallback_url, dest):
            continue

        # 两个地址都失败
        print(
            f"[Font] ⚠️ 字体 {filename} 下载失败，PDF 报告可能无法正确显示中文和 emoji。\n"
            f"[Font]    请手动下载字体文件放入: {font_dir}/",
            file=sys.stderr,
        )

    print("[Font] 字体检查完成。", file=sys.stderr)


# ═══════════════════════════════════════════════════════════════════════════
# 1. 工具函数 — 环境变量 / 密钥
# ═══════════════════════════════════════════════════════════════════════════


def _load_dotenv() -> None:
    """从 .env 文件中加载环境变量（不覆盖已有）。"""
    script_dir = os.path.dirname(os.path.abspath(__file__))
    candidates = [
        os.path.join(script_dir, ".env"),
        os.path.join(os.getcwd(), ".env"),
    ]
    env_file = None
    for path in candidates:
        if os.path.isfile(path):
            env_file = path
            break
    if env_file is None:
        return
    with open(env_file, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" not in line:
                continue
            key, _, value = line.partition("=")
            key = key.strip()
            value = value.strip()
            if len(value) >= 2 and value[0] == value[-1] and value[0] in ('"', "'"):
                value = value[1:-1]
            if key and key not in os.environ:
                os.environ[key] = value


def _get_credential() -> Credential:
    """获取腾讯云密钥。优先使用 CAT_xxx 环境变量，未设置时降级使用 TENCENTCLOUD_xxx。"""
    _load_dotenv()
    secret_id = os.environ.get("CAT_SECRET_ID") or os.environ.get("TENCENTCLOUD_SECRET_ID", "")
    secret_key = os.environ.get("CAT_SECRET_KEY") or os.environ.get("TENCENTCLOUD_SECRET_KEY", "")
    token = os.environ.get("CAT_TOKEN") or os.environ.get("TENCENTCLOUD_TOKEN", "")
    if not secret_id or not secret_key:
        print(
            "错误: 未找到腾讯云密钥，请配置 CAT_SECRET_ID/CAT_SECRET_KEY "
            "或 TENCENTCLOUD_SECRET_ID/TENCENTCLOUD_SECRET_KEY 环境变量",
            file=sys.stderr,
        )
        sys.exit(1)
    if token:
        return credential.Credential(secret_id, secret_key, token)
    return credential.Credential(secret_id, secret_key)


# ═══════════════════════════════════════════════════════════════════════════
# 2. Step 1 — CAT AI Console 调用
# ═══════════════════════════════════════════════════════════════════════════


def _parse_sse_event(data: str) -> dict[str, Any]:
    """
    解析 SSE 事件的 data 字段（标准 JSON 字符串，包含 Type 字段）。

    输入:
        data — call_sse 返回的 event dict 中的 "data" 值，
               格式: {"Type":"agent_message_chunk","Content":"...","FullText":"..."}

    返回:
        {
            "type": "agent_message_chunk"|"agent.done"|"pcap_check.done"|"",
            "content": "增量文本",
            "full_text": "完整文本",
            "session_id": "会话ID",
            "tool_name": "工具名称（如有）",
            "tool_data": { ... }  # 工具附带数据（如有）
        }
    """
    text = data.strip()
    if not text:
        return {"type": "", "content": "", "full_text": "", "session_id": "",
                "tool_name": "", "tool_data": None}

    try:
        obj = json.loads(text)
    except (json.JSONDecodeError, TypeError):
        # 无法解析，原样作为 content 返回
        return {"type": "", "content": text, "full_text": "", "session_id": "",
                "tool_name": "", "tool_data": None}

    return {
        "type": obj.get("Type", ""),
        "content": obj.get("Content", ""),
        "full_text": obj.get("FullText", ""),
        "session_id": obj.get("SessionID", ""),
        "tool_name": obj.get("ToolName", ""),
        "tool_data": obj.get("Data"),
    }


def _stream_cat_analysis(params: dict[str, Any]) -> tuple[str, Any, str]:
    """
    调用 CAT ProcessAIEventsStream，消费全部 SSE 事件后返回完整分析文本。

    返回:
        (full_text, tool_data, session_id) — full_text 为分析文本，tool_data 为 done
        事件附带的工具数据（如 pcap_check.done 中的抓包候选列表），无数据时为 None；
        session_id 为 agent.start 事件中携带的会话 ID，可用于后续抓包分析的上下文传递。
    """
    if not params:
        return "", None, ""

    cred = _get_credential()

    http_profile = HttpProfile()
    http_profile.endpoint = (
        os.environ.get("CAT_ENDPOINT")
        or os.environ.get("TENCENTCLOUD_ENDPOINT")
        or "cat.ai.tencentcloudapi.com"
    )
    http_profile.reqTimeout = 300

    client_profile = ClientProfile()
    client_profile.httpProfile = http_profile

    common_client = CommonClient(
        "cat", "2018-04-09", cred, "ap-guangzhou", profile=client_profile
    )

    api_params = {
        "AnalyzeAction": "Console",
        "QueryText": params["query_text"],
    }
    if params.get("session_id"):
        api_params["SessionID"] = params["session_id"]
    if params.get("start_time") is not None:
        api_params["StartTime"] = params["start_time"]
    if params.get("end_time") is not None:
        api_params["EndTime"] = params["end_time"]
    if params.get("task_id"):
        api_params["TaskID"] = params["task_id"]

    print("[Stream] 正在调用 CAT AI Console…", file=sys.stderr)
    # 使用 call_sse 实现真正的流式接收，避免 _call_and_deserialize 等待完整响应后再处理
    resp_iter = common_client.call_sse("ProcessAIEventsStream", api_params)

    chunk_idx = 0
    full_text = ""  # done 事件中的完整文本
    session_id = ""  # agent.start 事件中的会话 ID
    tool_data: Any = None  # done 事件中的工具附带数据（如抓包候选列表）
    incremental_parts: list[str] = []  # 增量 Content 片段

    # call_sse 返回生成器，每个元素是 {'event': ..., 'data': ..., 'id': ...} 字典
    # SSE 事件格式:
    #   event: agent.start
    #   data: {"Type":"agent.start","RequestId":"...","SessionID":"..."}
    #
    #   event: agent_message_chunk
    #   data: {"Type":"agent_message_chunk","Content":"增量文本","FullText":"完整文本"}
    #
    #   event: agent.done / pcap_check.done / ...
    #   data: {"Type":"agent.done","SessionID":"...","FullText":"完整文本"}
    #   data: {"Type":"pcap_check.done","FullText":"...","ToolName":"...","Data":{...}}
    for event in resp_iter:
        chunk_idx += 1

        # call_sse 返回 dict，直接取 data 字段（标准 JSON 字符串）
        raw: str = event.get("data", "")
        if not raw:
            continue  # 跳过空事件

        # 解析事件数据
        parsed = _parse_sse_event(raw)
        event_type = parsed.get("type", "")

        # agent.start 事件：提取 SessionID
        if event_type == "agent.start":
            sid = parsed.get("session_id", "")
            if sid:
                session_id = sid
            continue

        # done 类事件：保存完整文本和工具数据
        if event_type.endswith(".done"):
            if event_type == "agent.done":
                # 只有 agent.done 才终止消费
                full_text = parsed.get("full_text", "")
                # agent.done 也可能携带 SessionID，作为备选来源
                sid = parsed.get("session_id", "")
                if sid and not session_id:
                    session_id = sid
                print(
                    f"[Stream] {event_type} — 完整文本 {len(full_text)} chars",
                    file=sys.stderr,
                )
                break
            elif event_type == "pcap_check.done":
                tool_data = parsed.get("tool_data")
            else:
                # 其他 *.done 事件（如 tool.done）：不做记录，继续消费
                continue

        # 增量 chunk：收集并输出进度
        content = parsed.get("content", "")
        if content and content != "{}":
            incremental_parts.append(content)
            print(content, end="", file=sys.stderr)

    print(f"[Stream] 分析完成，共 {chunk_idx} 个事件", file=sys.stderr)
    if session_id:
        print(f"[Stream] SessionID: {session_id}", file=sys.stderr)

    # 优先使用 done 事件的 FullText (最权威、最完整)
    if full_text:
        # FullText 中的 \\n 是字面转义，需要转换为真实换行
        final_text = full_text.replace("\\n", "\n").replace('\\"', '"')
        print(
            f"[Stream] 使用 done FullText ({len(final_text)} chars)",
            file=sys.stderr,
        )
        return final_text, tool_data, session_id
    elif incremental_parts:
        # 降级方案：拼接增量 chunk
        final_text = "".join(incremental_parts)
        print(
            f"[Stream] 使用增量拼接文本 ({len(final_text)} chars)",
            file=sys.stderr,
        )
        return final_text, tool_data, session_id
    else:
        print("[Stream] 未收到任何分析内容", file=sys.stderr)
        return "", tool_data, session_id


# ═══════════════════════════════════════════════════════════════════════════
# 3. Step 2 — Markdown → 结构化 JSON 解析
# ═══════════════════════════════════════════════════════════════════════════


def _parse_markdown_to_report(full_text: str, task_id: str = "") -> dict[str, Any]:
    """
    将 CAT AI Console 返回的 Markdown 文本解析为 PDF 报告所需的结构化 JSON。
    这是一个纯规则解析器，不依赖任何 LLM。

    标题层级映射:
        #  / ##   → section（主章节）
        ###       → section（子章节，与 ## 同级存入 sections 列表）
        #### / ##### → sub_title（表格/子块标题，归入当前 section）
    """
    text = full_text.strip()

    sections: list[dict[str, Any]] = []
    current_section: dict[str, Any] | None = None
    in_table = False
    table_headers: list[str] = []
    table_rows: list[list[str]] = []
    # 暂存 ####/##### 子标题，等待后续表格关联
    pending_sub_title: str = ""

    def _flush_table() -> None:
        """将当前积累的表格数据存入 current_section。"""
        nonlocal in_table, table_headers, table_rows, pending_sub_title
        if not (in_table and table_headers):
            return
        tbl: dict[str, Any] = {"headers": table_headers, "rows": table_rows}
        if pending_sub_title:
            tbl["title"] = pending_sub_title
            pending_sub_title = ""
        if current_section is not None:
            tables_list: list[Any] = current_section.setdefault("tables", [])
            tables_list.append(tbl)
        else:
            sections.append({"title": "", "tables": [tbl]})
        in_table = False
        table_headers = []
        table_rows = []

    def _flush_section() -> None:
        """将当前 section 存入 sections 列表。"""
        nonlocal current_section, pending_sub_title
        if current_section is not None:
            _flush_table()
            # 如果有悬空的 sub_title 没被表格消费，追加到 description
            if pending_sub_title:
                _append_desc(pending_sub_title)
                pending_sub_title = ""
            sections.append(current_section)
            current_section = None

    def _append_desc(line_text: str) -> None:
        """将文本追加到 current_section 的 description。"""
        if current_section is None:
            return
        existing = str(current_section.get("description", ""))
        if existing:
            current_section["description"] = existing + "\n" + line_text
        else:
            current_section["description"] = line_text

    for line in text.split("\n"):
        stripped = line.strip()

        # --- 空行 ---
        if not stripped:
            continue

        # --- Markdown 水平分割线 (---, ***, ___) → 跳过 ---
        if re.match(r"^[-*_]{3,}$", stripped):
            continue

        # --- 表格分隔线 (|---|---|) → 跳过 ---
        if re.match(r"^\|[\s\-:|]+\|$", stripped):
            continue

        # --- 表格行 ---
        if stripped.startswith("|") and stripped.endswith("|"):
            cols = [c.strip() for c in stripped.strip("|").split("|")]
            if not in_table:
                in_table = True
                table_headers = cols
                table_rows = []
            else:
                table_rows.append(cols)
            continue

        # 如果刚离开表格区域（当前行不是表格行），先 flush
        if in_table:
            _flush_table()

        # --- 标题识别（从高级到低级，避免正则误匹配） ---
        # #### / ##### → 子标题（归入当前 section 的下一个表格标题或作为描述）
        m_sub = re.match(r"^#{4,6}\s+(.+)$", stripped)
        if m_sub:
            # 如果有之前未消费的 sub_title，先追加到 description
            if pending_sub_title:
                _append_desc(pending_sub_title)
            pending_sub_title = m_sub.group(1)
            continue

        # ### → 子章节（作为独立 section）
        m_h3 = re.match(r"^#{3}\s+(.+)$", stripped)
        if m_h3:
            _flush_section()
            current_section = {"title": m_h3.group(1), "tables": []}
            continue

        # # / ## → 主章节
        m_h12 = re.match(r"^#{1,2}\s+(.+)$", stripped)
        if m_h12:
            _flush_section()
            current_section = {"title": m_h12.group(1), "tables": []}
            continue

        # --- 普通文本 → 追加到 description ---
        if current_section is not None:
            # 如果有悬空 sub_title 且后面跟的是普通文本而非表格，先输出 sub_title
            if pending_sub_title:
                _append_desc(pending_sub_title)
                pending_sub_title = ""
            _append_desc(stripped)
        else:
            # 还没遇到任何标题，创建一个默认 section
            current_section = {"title": "", "tables": []}
            if pending_sub_title:
                _append_desc(pending_sub_title)
                pending_sub_title = ""
            _append_desc(stripped)

    # --- 结尾处理 ---
    _flush_table()
    if pending_sub_title and current_section is not None:
        _append_desc(pending_sub_title)
    if current_section is not None:
        sections.append(current_section)

    # 如果没有解析出任何 section，则将全部文本放进一个段落
    if not sections:
        sections = [
            {
                "title": "分析结果",
                "description": text,
                "tables": [],
            }
        ]

    return {
        "title": "拨测任务分析报告",
        "task_id": task_id,
        "sections": sections,
    }



# ═══════════════════════════════════════════════════════════════════════════
# 4. Step 3 — PDF 生成 (HTML → Playwright/Chromium — 原生彩色 emoji)
# ═══════════════════════════════════════════════════════════════════════════

# --- 本地字体目录（assets/ 目录） ---
_FONT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), os.pardir, "assets")


def _build_css() -> str:
    """构建 CSS，注入 @font-face 引用本地字体文件（file:// 绝对路径）。"""
    font_dir_uri = "file://" + _FONT_DIR.replace("\\", "/")

    return f"""\
@font-face {{
  font-family: "Noto Sans SC";
  font-style: normal;
  font-weight: 400;
  src: url("{font_dir_uri}/NotoSansSC-Regular.ttf") format("truetype");
}}
@font-face {{
  font-family: "Noto Sans SC";
  font-style: normal;
  font-weight: 700;
  src: url("{font_dir_uri}/NotoSansSC-Bold.ttf") format("truetype");
}}
@font-face {{
  font-family: "Noto Color Emoji";
  font-style: normal;
  src: url("{font_dir_uri}/NotoColorEmoji-Regular.ttf") format("truetype");
}}

@page {{
  size: A4;
  margin: 20mm 18mm 25mm 18mm;
}}
@page :first {{
  margin-top: 15mm;
}}

/* ---- 基础排版 ---- */
* {{ box-sizing: border-box; margin: 0; padding: 0; }}
html {{
  font-size: 14px;
  -webkit-print-color-adjust: exact;
  print-color-adjust: exact;
}}
body {{
  font-family: "Noto Sans SC", "Noto Color Emoji", "PingFang SC",
               "Hiragino Sans GB", "Microsoft YaHei", "Apple Color Emoji",
               "Segoe UI Emoji", sans-serif;
  color: #475569;
  line-height: 1.65;
}}

/* ---- 页眉 / 页脚 (运行时 header/footer 模板) ---- */
.page-header, .page-footer {{
  font-size: 10px;
  color: #94a3b8;
  text-align: center;
  width: 100%;
}}
.page-footer {{ font-size: 10px; }}

/* ---- 报告标题区 ---- */
.report-header {{
  text-align: center;
  margin-bottom: 28px;
}}
.report-title {{
  font-size: 24px;
  font-weight: 700;
  color: #334155;
  margin-bottom: 6px;
}}
.report-subtitle {{
  font-size: 13px;
  color: #94a3b8;
  margin-bottom: 12px;
}}
.title-divider {{
  width: 80px;
  height: 3px;
  background: #6366f1;
  border-radius: 2px;
  margin: 0 auto;
}}

/* ---- 章节标题 ---- */
.section-title {{
  font-size: 18px;
  font-weight: 700;
  color: #334155;
  margin: 24px 0 10px 0;
  padding-left: 14px;
  border-left: 4px solid #6366f1;
  line-height: 1.4;
}}
.sub-title {{
  font-size: 15px;
  font-weight: 600;
  color: #475569;
  margin: 14px 0 6px 0;
}}

/* ---- 正文 ---- */
.body-text {{
  font-size: 13px;
  color: #475569;
  margin-bottom: 10px;
  white-space: pre-wrap;
  word-break: break-word;
}}
.note-text {{
  font-size: 12px;
  color: #94a3b8;
  margin-bottom: 8px;
}}

/* ---- 表格 ---- */
.report-table {{
  width: 100%;
  border-collapse: collapse;
  margin: 8px 0 18px 0;
  font-size: 12.5px;
}}
.report-table th {{
  background: #e2e8f0;
  color: #1e293b;
  font-weight: 600;
  text-align: left;
  padding: 8px 10px;
  border-bottom: 2px solid #cbd5e1;
}}
.report-table td {{
  padding: 7px 10px;
  border-bottom: 1px solid #e2e8f0;
  color: #334155;
}}
.report-table tr:nth-child(even) td {{
  background: #f8fafc;
}}
.report-table tr:hover td {{
  background: #f1f5f9;
}}

/* ---- Markdown 行内格式 ---- */
.body-text strong {{ font-weight: 600; color: #334155; }}
.body-text code {{
  background: #f1f5f9; padding: 1px 5px; border-radius: 3px;
  font-family: "SF Mono", "Fira Code", monospace;
  font-size: 0.92em; color: #dc2626;
}}
"""


def _esc(text: str) -> str:
    """HTML 转义。"""
    return html_mod.escape(text, quote=True)


def _clean_html_text(text: str) -> str:
    """清理转义字符，保留 emoji，将简单 Markdown 转换为 HTML 内联标签。"""
    text = text.replace("\\u003cbr\\u003e", "\n")
    text = text.replace("<br>", "\n")
    text = text.replace("\\n", "\n")
    text = text.replace('\\"', '"')

    # 先 HTML 转义（防止注入），然后再应用 Markdown 内联格式
    text = _esc(text)

    # **bold**
    text = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", text)
    # `code`
    text = re.sub(r"`([^`]+?)`", r"<code>\1</code>", text)
    # ~~strike~~
    text = re.sub(r"~~(.+?)~~", r"<del>\1</del>", text)
    # 换行符 → <br>（在表格单元格中尤其需要）
    text = text.replace("\n", "<br>")

    return text


def _build_html(report_data: dict[str, Any]) -> str:
    """将结构化报告 JSON 渲染为完整的 HTML 字符串。"""
    title = str(report_data.get("title", "拨测任务分析报告"))
    task_id = str(report_data.get("task_id", ""))
    gen_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    parts: list[str] = []
    parts.append("<!DOCTYPE html>")
    parts.append('<html lang="zh-CN"><head>')
    parts.append('<meta charset="utf-8">')
    parts.append(f"<title>{_esc(title)}</title>")
    parts.append(f"<style>{_build_css()}</style>")
    parts.append("</head><body>")

    # --- 标题区 ---
    parts.append('<div class="report-header">')
    parts.append(f'<div class="report-title">{_esc(title)}</div>')
    subtitle_parts: list[str] = []
    if task_id:
        subtitle_parts.append(f"任务ID: {_esc(task_id)}")
    subtitle_parts.append(f"生成时间: {gen_time}")
    parts.append(f'<div class="report-subtitle">{" | ".join(subtitle_parts)}</div>')
    parts.append('<div class="title-divider"></div>')
    parts.append("</div>")

    # --- 各章节 ---
    for section in report_data.get("sections", []):
        section_title = section.get("title", "")
        description = section.get("description", "")
        tables = section.get("tables", [])
        note = section.get("note", "")

        if section_title:
            parts.append(
                f'<div class="section-title">{_clean_html_text(section_title)}</div>'
            )
        if description:
            cleaned = _clean_html_text(description)
            # 按空行（连续<br>）拆分段落
            for para in re.split(r"(?:<br>){2,}", cleaned):
                para = para.strip()
                if para:
                    parts.append(f'<div class="body-text">{para}</div>')

        for tbl in tables:
            tbl_title = tbl.get("title", "")
            if tbl_title:
                parts.append(
                    f'<div class="sub-title">{_clean_html_text(tbl_title)}</div>'
                )
            tbl_headers = tbl.get("headers", [])
            tbl_rows = tbl.get("rows", [])
            if tbl_headers:
                parts.append('<table class="report-table"><thead><tr>')
                for h in tbl_headers:
                    parts.append(f"<th>{_clean_html_text(h)}</th>")
                parts.append("</tr></thead><tbody>")
                for row in tbl_rows:
                    parts.append("<tr>")
                    for cell in row:
                        parts.append(f"<td>{_clean_html_text(cell)}</td>")
                    parts.append("</tr>")
                parts.append("</tbody></table>")

        if note:
            parts.append(f'<div class="note-text">{_clean_html_text(note)}</div>')

    parts.append("</body></html>")
    return "\n".join(parts)


def _generate_pdf(report_data: dict[str, Any], output_path: str) -> str:
    """
    根据结构化 JSON 生成 PDF 报告（HTML → Playwright/Chromium），返回输出路径。

    优势: Chromium 内核原生支持彩色 emoji 渲染，排版与浏览器一致。
    """
    print("[PDF] 正在生成 HTML…", file=sys.stderr)

    html_content = _build_html(report_data)

    # 写入临时 HTML 文件（Playwright 需要 file:// 路径来正确加载本地资源）
    tmp_html = tempfile.NamedTemporaryFile(
        suffix=".html",
        prefix="cat_report_",
        delete=False,
        mode="w",
        encoding="utf-8",
    )
    try:
        tmp_html.write(html_content)
        tmp_html.close()
        html_path = tmp_html.name

        print("[PDF] 正在启动 Chromium 渲染 PDF…", file=sys.stderr)
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            page = browser.new_page()
            page.goto(f"file://{html_path}", wait_until="networkidle")

            # 页脚模板
            # 注意: Playwright 的 header/footer template 在独立渲染上下文中绘制，
            # 不会继承页面 <style> 中的 @font-face，必须在模板内重新声明字体。
            font_dir_uri = "file://" + _FONT_DIR.replace("\\", "/")
            hf_font_style = (
                f'@font-face {{'
                f'  font-family: "Noto Sans SC";'
                f'  src: url("{font_dir_uri}/NotoSansSC-Regular.ttf") format("truetype");'
                f'}}'
            )
            # 不使用页眉（第一页已有大标题，页眉重复且影响美观）
            header_tpl = '<div></div>'
            footer_tpl = (
                f'<style>{hf_font_style}</style>'
                '<div style="font-family:\'Noto Sans SC\',sans-serif;'
                'font-size:9px;color:#94a3b8;text-align:center;'
                'width:100%;padding:4px 0;">'
                '— <span class="pageNumber"></span> —'
                "</div>"
            )

            page.pdf(
                path=output_path,
                format="A4",
                print_background=True,
                display_header_footer=True,
                header_template=header_tpl,
                footer_template=footer_tpl,
                margin={
                    "top": "18mm",
                    "bottom": "25mm",
                    "left": "18mm",
                    "right": "18mm",
                },
            )
            browser.close()

        print(f"[PDF] PDF 报告已生成: {output_path}", file=sys.stderr)
        return output_path
    finally:
        # 清理临时 HTML
        try:
            os.unlink(html_path)
        except OSError:
            pass


def _build_pcap_section(tool_data: dict[str, Any]) -> dict[str, Any] | None:
    """
    将 pcap_check.done 事件的 Data 字段转为报告的一个 section。

    Data 结构示例:
        {
            "items": [
                {"city": "慕尼黑", "operator": "Germany_COLT", "error_id": "600",
                    "task_id": "task-xxx", "probe_time": 1773905195000, "code": "10970"},
                ...
            ]
        }

    返回一个 section dict，可直接追加到 report["sections"] 中。
    如果 items 为空或 tool_data 不合法，返回 None。
    """
    if not tool_data or not isinstance(tool_data, dict):
        return None
    items = tool_data.get("items", [])
    if not items:
        return None

    headers = ["城市", "运营商", "错误码", "任务ID", "拨测时间", "拨测点编码"]
    rows: list[list[str]] = []
    for item in items:
        probe_ts = item.get("probe_time")
        if probe_ts:
            probe_str = datetime.datetime.fromtimestamp(
                probe_ts / 1000
            ).strftime("%Y-%m-%d %H:%M:%S")
        else:
            probe_str = ""
        rows.append([
            str(item.get("city", "")),
            str(item.get("operator", "")),
            str(item.get("error_id", "")),
            str(item.get("task_id", "")),
            probe_str,
            str(item.get("code", "")),
        ])

    return {
        "title": "🔍 抓包分析候选列表",
        "description": (
            f"检测到 {len(rows)} 个错误记录配置了\"错误时抓包\"模式，"
            "以下为抓包分析候选项。"
        ),
        "tables": [{"headers": headers, "rows": rows}],
    }


def _print_pcap_table(section: dict[str, Any]) -> None:
    """
    将 pcap section 的表格以可读格式输出到 stderr 控制台。
    """
    title = section.get("title", "")
    desc = section.get("description", "")
    tables = section.get("tables", [])

    print(f"\n{'=' * 60}", file=sys.stderr)
    print(f"  {title}", file=sys.stderr)
    print(f"{'=' * 60}", file=sys.stderr)
    if desc:
        print(f"  {desc}", file=sys.stderr)
        print(file=sys.stderr)

    for table in tables:
        headers = table.get("headers", [])
        rows = table.get("rows", [])
        if not headers:
            continue

        # 计算每列最大宽度（考虑中文字符占2个宽度）
        def _display_width(s: str) -> int:
            """计算字符串的显示宽度（中文占2宽度）。"""
            w = 0
            for ch in s:
                w += 2 if "\u4e00" <= ch <= "\u9fff" or "\u3000" <= ch <= "\u303f" else 1
            return w

        def _pad(s: str, width: int) -> str:
            """将字符串填充到指定显示宽度。"""
            return s + " " * (width - _display_width(s))

        col_widths = [_display_width(h) for h in headers]
        for row in rows:
            for i, cell in enumerate(row):
                col_widths[i] = max(col_widths[i], _display_width(cell))

        # 表头
        header_line = " | ".join(_pad(h, col_widths[i]) for i, h in enumerate(headers))
        sep_line = "-+-".join("-" * w for w in col_widths)
        print(f"  {header_line}", file=sys.stderr)
        print(f"  {sep_line}", file=sys.stderr)

        # 数据行
        for row in rows:
            row_line = " | ".join(
                _pad(cell, col_widths[i]) for i, cell in enumerate(row)
            )
            print(f"  {row_line}", file=sys.stderr)

    print(f"{'=' * 60}\n", file=sys.stderr)
# 5. 管道编排 — 纯函数顺序调用
# ═══════════════════════════════════════════════════════════════════════════


def run_pipeline(
    params: dict[str, Any],
    task_id: str = "",
    output_path: str = "report.pdf",
) -> tuple[str, str]:
    """
    顺序执行三步管道，返回 (PDF路径, SessionID)。

        Input(dict) ──▶ SSE分析 ──▶ Markdown解析 ──▶ PDF生成
    """
    # Step 1: 调用 CAT AI Console，获取完整分析文本
    full_text, tool_data, session_id = _stream_cat_analysis(params)
    if not full_text:
        print("[Pipeline] 未获取到分析内容，终止", file=sys.stderr)
        sys.exit(1)
    print(f"[Pipeline] 分析文本就绪 ({len(full_text)} chars)", file=sys.stderr)

    # Step 2: 解析 Markdown → 结构化 JSON
    print("[Pipeline] 正在将分析结果转为结构化报告…", file=sys.stderr)
    report = _parse_markdown_to_report(full_text, task_id=task_id)

    # Step 2.5: 如果 done 事件附带了工具数据（如抓包候选列表），追加为额外章节
    if tool_data:
        pcap_section = _build_pcap_section(tool_data)
        if pcap_section:
            report["sections"].append(pcap_section)
            print("[Pipeline] 已追加抓包分析候选列表章节", file=sys.stderr)
            # 将表格同步输出到控制台
            _print_pcap_table(pcap_section)

    n_sections = len(report.get("sections", []))
    n_tables = sum(len(s.get("tables", [])) for s in report.get("sections", []))
    print(
        f"[Pipeline] 解析完成: {n_sections} 个章节, {n_tables} 个表格", file=sys.stderr
    )

    # Step 3: 生成 PDF
    pdf_path = _generate_pdf(report, output_path)
    return pdf_path, session_id


# ═══════════════════════════════════════════════════════════════════════════
# 6. CLI 入口
# ═══════════════════════════════════════════════════════════════════════════


def main() -> None:
    parser = argparse.ArgumentParser(
        description="CAT Network Quality Analysis + PDF 生成一体化"
    )
    parser.add_argument(
        "--query-text",
        required=True,
        help="(必选) 发送给 CAT AI Console 的分析查询",
    )
    parser.add_argument("--task-id", default=None, help="(可选) 任务 ID")
    parser.add_argument(
        "--start-time",
        type=int,
        default=None,
        help="(可选) 分析起始时间 (ms)",
    )
    parser.add_argument(
        "--end-time",
        type=int,
        default=None,
        help="(可选) 分析截止时间 (ms)",
    )
    parser.add_argument("--session-id", default=None, help="(可选) 会话 ID")
    parser.add_argument(
        "--output",
        "-o",
        default=None,
        help="(可选) 输出 PDF 路径，默认: {task_id}_error_report_{timestamp}.pdf",
    )

    args = parser.parse_args()

    # 计算输出路径
    if args.output:
        output_path = args.output
    else:
        tid = args.task_id or "report"
        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        output_path = f"{tid}_error_report_{ts}.pdf"

    # 构建输入参数
    params = {
        "query_text": args.query_text,
        "task_id": args.task_id,
        "start_time": args.start_time,
        "end_time": args.end_time,
        "session_id": args.session_id,
    }

    # 确保字体文件就绪（缺失时自动下载）
    _ensure_fonts(_FONT_DIR)

    # 执行管道
    try:
        result, session_id = run_pipeline(
            params,
            task_id=args.task_id or "",
            output_path=output_path,
        )
        print(result)  # 输出 PDF 路径到 stdout
        if session_id:
            print(f"SessionID={session_id}")  # 输出 SessionID 到 stdout
    except TencentCloudSDKException as err:
        print(f"调用失败: {err}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
