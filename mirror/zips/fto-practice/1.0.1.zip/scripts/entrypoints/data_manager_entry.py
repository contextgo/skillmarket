import os
import sys
import json
import argparse

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.db_manager import DatabaseManager
from repository.patent_repository import PatentRepository
from importer.import_service import ImportService


def handle_import(args, repo):
    import_service = ImportService(repository=repo)
    result = import_service.import_local_file(
        file_path=args.file,
        patent_id=args.patent_id,
        title=args.title,
        abstract=args.abstract,
        full_claims=args.full_claims,
        application_number=args.application_number,
        application_date=args.application_date,
        publication_date=args.publication_date,
        assignees=args.assignees,
        legal_status=args.legal_status,
        node=args.node,
    )
    print(json.dumps({"status": "success", "action": "import", "result": result}, ensure_ascii=False, indent=2))


def handle_export(args, repo):
    patents = repo.get_patents_with_claims()
    if args.output:
        os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(patents, f, ensure_ascii=False, indent=2)
        print(json.dumps({"status": "success", "action": "export", "count": len(patents), "file": args.output}, ensure_ascii=False))
    else:
        print(json.dumps({"status": "success", "action": "export", "count": len(patents), "data": patents}, ensure_ascii=False, indent=2))


def main():
    parser = argparse.ArgumentParser(
        description="Local Data Manager: 专利本地数据库文件导入导出管理"
    )
    parser.add_argument("--db_path", type=str, required=True, help="项目专属的 SQLite 数据库文件路径")

    subparsers = parser.add_subparsers(dest="command", required=True, help="子命令")

    parser_import = subparsers.add_parser("import", help="从本地 JSON/Excel/CSV/ZIP 文件导入专利数据到数据库")
    parser_import.add_argument("--file", type=str, required=True, help="要导入的文件路径")
    parser_import.add_argument("--patent_id", type=str, help="Excel/CSV 列名 → patent_id（公开号/专利号）")
    parser_import.add_argument("--title", type=str, help="Excel/CSV 列名 → title（发明名称）")
    parser_import.add_argument("--abstract", type=str, help="Excel/CSV 列名 → abstract（摘要）")
    parser_import.add_argument("--full_claims", type=str, help="Excel/CSV 列名 → full_claims（权利要求书全文）")
    parser_import.add_argument("--application_number", type=str, help="Excel/CSV 列名 → application_number（申请号）")
    parser_import.add_argument("--application_date", type=str, help="Excel/CSV 列名 → application_date（申请日）")
    parser_import.add_argument("--publication_date", type=str, help="Excel/CSV 列名 → publication_date（公开日）")
    parser_import.add_argument("--assignees", type=str, help="Excel/CSV 列名 → assignees（申请人）")
    parser_import.add_argument("--legal_status", type=str, help="Excel/CSV 列名 → legal_status（法律状态）")
    parser_import.add_argument("--node", type=str, help="附加的技术分类节点标签（可选）")

    parser_export = subparsers.add_parser("export_for_filter", help="导出带权利要求的专利列表（JSON）")
    parser_export.add_argument("--output", type=str, help="导出文件路径（可选，不填则打印 JSON）")

    args = parser.parse_args()

    try:
        db_manager = DatabaseManager(db_path=args.db_path)
        repo = PatentRepository(db_manager=db_manager)

        if args.command == "import":
            handle_import(args, repo)
        elif args.command == "export_for_filter":
            handle_export(args, repo)

    except Exception as e:
        print(json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False))
        sys.exit(1)


if __name__ == "__main__":
    main()
