from __future__ import annotations

import argparse
import asyncio
import logging
import os
import sys
import uuid

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _SCRIPT_DIR)

from core.db_manager import DatabaseManager
from repository.patent_repository import PatentRepository
from search.api_clients.factory import ApiClientFactory
from search.services.claims_service import ClaimsService
from search.services.search_service import SearchService
from step05.services.precision_eval_runner import run_step05_precision_eval

logger = logging.getLogger(__name__)


def _normalize_sample(sample: dict) -> dict:
    patent_id = (
        sample.get("patent_id")
        or sample.get("publication_number")
        or sample.get("公开号")
        or sample.get("publicationNumber")
        or ""
    )
    return {
        "patent_id": patent_id,
        "title": sample.get("title", ""),
        "abstract": sample.get("abstract", ""),
        "full_claims": sample.get("claims_text", "") or sample.get("full_claims", ""),
        "publication_number": sample.get("publication_number", patent_id),
        "application_number": sample.get("application_number", ""),
        "application_date": sample.get("application_date", ""),
        "publication_date": sample.get("publication_date", ""),
        "assignees": sample.get("assignees", []),
        "inventors": sample.get("inventors", []),
        "ipc_classes": sample.get("ipc_classes", []),
        "legal_status": sample.get("legal_status", ""),
        "raw_data": sample,
    }


async def evaluate_query(provider: str, query: str, sample_size: int) -> tuple[int, list[dict]]:
    client = ApiClientFactory.create(provider_name=provider)
    search_service = SearchService(client)
    search_result = search_service.execute_search(query=query, max_fetch=sample_size)
    target_pool = [{"publication_number": pn} for pn in search_result.patent_numbers]
    claims_service = ClaimsService(client)
    samples = await claims_service.execute_claims_pipeline(target_pool=target_pool, limit=sample_size)
    return int(search_result.hit_count or 0), samples


async def run_sample_evaluate(
    *,
    provider: str,
    llm_provider: str,
    db_path: str,
    features_file: str,
    query: str,
    sample_size: int = 30,
    round_id: str | None = None,
    concurrency: int = 10,
) -> dict:
    if not os.path.exists(features_file):
        raise FileNotFoundError(f"特征文件不存在: {features_file}")
    with open(features_file, "r", encoding="utf-8") as f:
        features_text = f.read().strip()
    if not features_text:
        raise ValueError("features_file 内容为空")

    rid = str(round_id or uuid.uuid4().hex[:8])
    source = f"step05_round_{rid}"
    db = DatabaseManager(db_path=db_path)
    repo = PatentRepository(db_manager=db)

    hit_count, samples = await evaluate_query(provider=provider, query=query, sample_size=sample_size)
    normalized = [_normalize_sample(s) for s in samples]
    repo.bulk_import_patents(normalized, source=source)

    patent_ids = []
    for item in normalized:
        patent_id = item.get("patent_id")
        if not patent_id:
            continue
        patent_ids.append(patent_id)
        claims_text = item.get("full_claims", "")
        if claims_text:
            db.save_patent_claims(patent_id=patent_id, independent_claims=claims_text)

    metrics = await run_step05_precision_eval(
        db_path=db_path,
        features_text=features_text,
        llm_provider=llm_provider,
        provider=provider,
        round_id=rid,
        query_text=query,
        hit_count=hit_count,
        patent_ids=patent_ids,
        source=source,
        concurrency=concurrency,
    )
    return metrics


def calculate_precision(*args, **kwargs):
    raise RuntimeError("旧 JSON 评估链路已废弃，请使用 run_sample_evaluate(...) 纯 DB 流程。")


async def _async_main():
    parser = argparse.ArgumentParser(description="Step4 抽样评估（纯 DB 管道）")
    parser.add_argument("--provider", type=str, required=True, choices=["zhihuiya", "lens", "epo", "baiten"], help="检索数据库提供商")
    parser.add_argument("--llm_provider", type=str, required=True, choices=["minimax", "deepseek", "openai"], help="LLM 提供商")
    parser.add_argument("--db_path", type=str, required=True, help="项目唯一 SQLite 路径")
    parser.add_argument("--features_file", type=str, required=True, help="核心技术特征文件路径")
    parser.add_argument("--query", type=str, required=True, help="待评估检索式")
    parser.add_argument("--sample_size", type=int, default=30, help="抽样数量，默认30")
    parser.add_argument("--round_id", type=str, default="", help="轮次ID，不传则自动生成")
    parser.add_argument("--concurrency", type=int, default=10, help="评估并发")
    args = parser.parse_args()

    metrics = await run_sample_evaluate(
        provider=args.provider,
        llm_provider=args.llm_provider,
        db_path=args.db_path,
        features_file=args.features_file,
        query=args.query,
        sample_size=args.sample_size,
        round_id=args.round_id or None,
        concurrency=args.concurrency,
    )
    print(
        "Step4 评估完成 | "
        f"round_id={metrics['round_id']} | hit_count={metrics['hit_count']} | "
        f"evaluated={metrics['evaluated_count']} | non_noise={metrics['non_noise_count']} | "
        f"precision={metrics['precision']:.4f}"
    )


def main():
    asyncio.run(_async_main())


if __name__ == "__main__":
    main()
