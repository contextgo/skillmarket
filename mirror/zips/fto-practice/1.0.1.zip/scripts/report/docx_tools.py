import docx
from docx.shared import Pt
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_ALIGN_VERTICAL

def merge_duplicate_cells_in_first_column(
    doc_path: str,
    table_index: int = 0,
    start_keyword: str = "比对分析",
    stop_keywords: tuple = ("对比", "推定"),
    font_en: str = 'Times New Roman',
    font_cn: str = '宋体',
    font_size: float = 10.5
): 
    doc = docx.Document(doc_path) 
    if not doc.tables or len(doc.tables) <= table_index: 
        return 
        
    table = doc.tables[table_index] 
    
    # 1. 定位比对分析的起点 
    start_row_idx = -1 
    for i, row in enumerate(table.rows): 
        if len(row.cells) > 0 and row.cells[0].text.strip() == start_keyword: 
            start_row_idx = i 
            break 
            
    if start_row_idx == -1: 
        return 
        
    data_start_idx = start_row_idx + 2 
    
    # 2. 核心优化：先计算出需要合并的行区间 (绝不在循环中执行 merge) 
    merge_blocks = [] 
    current_text = None 
    start_r = -1 
    
    for i in range(data_start_idx, len(table.rows)): 
        if len(table.rows[i].cells) == 0: 
            continue 
            
        text = table.cell(i, 0).text.strip() 
        
        # 遇到分割线，结算当前块 
        if any(kw in text for kw in stop_keywords) or not text: 
            if current_text and start_r != -1 and (i - 1 >= start_r): 
                merge_blocks.append((start_r, i - 1, current_text)) 
            current_text = None 
            start_r = -1 
            continue 
            
        # 发现新文本，结算上一个块 
        if text != current_text: 
            if current_text and start_r != -1 and (i - 1 >= start_r): 
                merge_blocks.append((start_r, i - 1, current_text)) 
            current_text = text 
            start_r = i 
            
    # --- 【优化 2：兜底防御，处理表格结尾没有特殊关键字的情况】 ---
    if current_text and start_r != -1 and (len(table.rows) - 1 >= start_r):
        merge_blocks.append((start_r, len(table.rows) - 1, current_text))
            
    # 3. 统一执行合并与格式化（最安全的底层操作） 
    for start_idx, end_idx, text in merge_blocks: 
        start_cell = table.cell(start_idx, 0) 
        end_cell = table.cell(end_idx, 0) 
        
        # 只有在确实跨行的情况下才执行 merge
        if start_idx != end_idx:
            start_cell.merge(end_cell) 
        
        # --- 【修复重点 1 & 优化 3：清理合并产生的多余幽灵段落（切片语法）】 --- 
        for p_extra in start_cell.paragraphs[1:]:
            p_ele = p_extra._element
            p_ele.getparent().remove(p_ele) 
            
        # 拿到仅存的唯一、干净的段落 
        p = start_cell.paragraphs[0] 
        p.text = "" 
        r = p.add_run(text) 
        
        # 设置字体与加粗 
        r.font.name = font_en 
        r._element.rPr.rFonts.set(qn('w:eastAsia'), font_cn) 
        r.font.size = Pt(font_size) 
        r.font.bold = True 
        
        # --- 【修复重点 2：暴力击杀“中文字符缩进”】 --- 
        # 先清除磅值缩进 
        p.paragraph_format.first_line_indent = Pt(0) 
        p.paragraph_format.left_indent = Pt(0) 
        p.paragraph_format.right_indent = Pt(0) 
        
        # 直接操作底层 XML，强行抹除“字符缩进(Chars)”属性 
        pPr = p._element.get_or_add_pPr() 
        ind = pPr.get_or_add_ind() 
        ind.set(qn('w:firstLineChars'), '0') 
        ind.set(qn('w:leftChars'), '0') 
        
        # 重新应用完美的水平与垂直居中 
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER 
        start_cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER 

    doc.save(doc_path)
