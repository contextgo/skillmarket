import os
import re
import json
import logging

logger = logging.getLogger(__name__)


def get_valid_value(*args):
    """返回第一个非空且不是'未知'的值"""
    for val in args:
        if val and val != "未知":
            return val
    return "未知"


def prepare_fto_context(patent_data: dict, fto_result: dict, filename: str, topic: str) -> dict:
    """
    合并专利数据与 FTO 结果，生成 Word 渲染所需的上下文字典。
    如果著录项缺失，会尝试通过 API 补全。
    """
    biblio = patent_data.get("bibliography", {}) or {}
    legal = patent_data.get("legal_status", {}) or {}

    dynamic_data = {
        "patent_title": biblio.get("title", "未命名专利"),
        "patent_publication_number": get_valid_value(patent_data.get("patent_number"), biblio.get("patent_number")),
        "patent_publication_date": biblio.get("publication_date", "未知"),
        "patent_application_number": get_valid_value(biblio.get("application_number")),
        "patent_application_date": biblio.get("application_date", "未知"),
        "patent_applicant": ", ".join(biblio.get("assignees", [])) if biblio.get("assignees") else "未知",
        "patent_legal_status": legal.get("status_description", "未知"),
        "target_technology_topic": get_valid_value(fto_result.get("topic"), topic),
        "claims": fto_result.get("claims", []),
        "final_risk_conclusion": fto_result.get("final_risk_conclusion", "未知风险")
    }

    if dynamic_data.get("patent_application_number") == "未知":
        dynamic_data = _enrich_missing_fields(dynamic_data, filename)

    return dynamic_data


def _enrich_missing_fields(dynamic_data: dict, filename: str) -> dict:
    """尝试从外部 API 补全缺失的著录项"""
    patent_num = dynamic_data.get("patent_publication_number")
    if patent_num == "未知":
        match = re.search(r'([A-Z]{2}\d+[A-Z0-9]+)', os.path.basename(filename))
        if match:
            patent_num = match.group(1)
            dynamic_data["patent_publication_number"] = patent_num

    if not patent_num or patent_num == "未知":
        return dynamic_data

    try:
        epo_bib = _fetch_patent_bibliography(patent_num)
        if epo_bib:
            dynamic_data["patent_application_number"] = get_valid_value(
                dynamic_data.get("patent_application_number"), epo_bib.application_number
            )
            dynamic_data["patent_application_date"] = get_valid_value(
                dynamic_data.get("patent_application_date"), epo_bib.application_date
            )
            dynamic_data["patent_title"] = get_valid_value(
                dynamic_data.get("patent_title"), epo_bib.title
            )
            dynamic_data["patent_publication_date"] = get_valid_value(
                dynamic_data.get("patent_publication_date"), epo_bib.publication_date
            )
            if dynamic_data.get("patent_applicant") == "未知" and epo_bib.assignees:
                dynamic_data["patent_applicant"] = (
                    ", ".join(epo_bib.assignees)
                    if isinstance(epo_bib.assignees, list)
                    else str(epo_bib.assignees)
                )
            logger.info("✅ 缺失属性补全合并完成！")
        else:
            logger.warning("⚠️ 尝试了所有 API 渠道，均未能补全著录项目数据。")
    except Exception as e:
        logger.warning(f"⚠️ 尝试通过 API 补全数据失败: {e}，将保持原有空缺状态。")

    return dynamic_data


def _fetch_patent_bibliography(patent_num: str):
    """依次尝试从 Zhihuiya 和 EPO OPS 获取专利著录项"""
    epo_bib = None

    try:
        from search.api_clients.zhihuiya_client import ZhihuiyaClient
        zh_client = ZhihuiyaClient()
        zh_data = zh_client.get_standardized_patent_data(patent_num)
        if zh_data and zh_data.bibliography and zh_data.bibliography.application_number:
            epo_bib = zh_data.bibliography
            logger.info("✅ 成功从智慧芽 (Zhihuiya) 获取到补充著录项数据！")
    except Exception as e:
        logger.debug(f"Zhihuiya 获取失败: {e}")

    if not epo_bib:
        try:
            from search.api_clients.epo_client import EpoOpsClient
            epo_client = EpoOpsClient()
            epo_data = epo_client.get_standardized_patent_data(patent_num)
            if epo_data and epo_data.bibliography and epo_data.bibliography.application_number:
                epo_bib = epo_data.bibliography
                logger.info("✅ 成功从 EPO OPS 获取到补充著录项数据！")
        except Exception as e:
            logger.debug(f"EPO OPS 获取失败: {e}")

    return epo_bib
