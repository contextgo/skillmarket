import json
import os
import argparse
from docxtpl import DocxTemplate

from report.docx_tools import merge_duplicate_cells_in_first_column


def generate_search_report(report_data: dict, template_path: str, output_path: str) -> str:
    doc = DocxTemplate(template_path)
    doc.render(report_data)
    doc.save(output_path)
    merge_duplicate_cells_in_first_column(output_path)
    return output_path


def render_search_reports_from_db(db_path, template_path, output_dir):
    from repository.patent_repository import PatentRepository
    from core.db_manager import DatabaseManager

    db_manager = DatabaseManager(db_path=db_path)
    repo = PatentRepository(db_manager=db_manager)

    patents = repo.get_all_patents()
    if not patents:
        print("⚠️ 数据库中未找到任何专利。")
        return

    os.makedirs(output_dir, exist_ok=True)
    success_count = 0
    error_count = 0

    for patent in patents:
        pub_number = patent.get("publication_number")
        print(f"📄 正在处理专利: {pub_number}")

        try:
            context = {
                "patent_title": patent.get("title", "未知"),
                "patent_publication_number": pub_number,
                "patent_publication_date": patent.get("publication_date", "未知"),
                "patent_application_number": patent.get("application_number", "未知"),
                "patent_application_date": patent.get("application_date", "未知"),
                "patent_applicant": ", ".join(patent.get("assignees", [])) if patent.get("assignees") else "未知",
                "patent_legal_status": patent.get("legal_status", "未知"),
                "search_keywords": json.dumps(patent.get("search_keywords", []), ensure_ascii=False) if isinstance(patent.get("search_keywords"), list) else str(patent.get("search_keywords", "")),
            }

            output_path = os.path.join(output_dir, f"{pub_number}_检索报告.docx")
            doc = DocxTemplate(template_path)
            doc.render(context)
            doc.save(output_path)
            merge_duplicate_cells_in_first_column(output_path)
            print(f"  ✅ 报告已生成: {output_path}")
            success_count += 1

        except Exception as e:
            print(f"  ❌ 处理 {pub_number} 时发生异常: {e}")
            error_count += 1

    print(f"\n🏁 批量渲染完成！")
    print(f"   ✅ 成功: {success_count} 篇")
    print(f"   ❌ 失败: {error_count} 篇")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="批量检索报告 Word 渲染工具")
    parser.add_argument("--db_path", type=str, required=True)
    parser.add_argument("-t", "--template", type=str, required=True)
    parser.add_argument("-o", "--output", type=str, required=True)
    args = parser.parse_args()
    render_search_reports_from_db(args.db_path, args.template, args.output)
