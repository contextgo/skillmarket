import json
import os
import sys
import argparse
from docxtpl import DocxTemplate
from typing import List

from report.contexts.fto_context import prepare_fto_context
from report.docx_tools import merge_duplicate_cells_in_first_column


def generate_fto_report(report_data: dict, template_path: str, output_path: str) -> str:
    doc = DocxTemplate(template_path)
    doc.render(report_data)
    doc.save(output_path)
    merge_duplicate_cells_in_first_column(output_path)
    return output_path


def main():
    parser = argparse.ArgumentParser(description="专利 FTO 报告自动化生成工具 (CLI)")
    parser.add_argument("--db_path", type=str, required=True)
    parser.add_argument("--pub_number", type=str, required=True)
    parser.add_argument("-t", "--template", type=str, required=True)
    parser.add_argument("-o", "--output", type=str, required=True)
    args = parser.parse_args()

    print(f"📄 正在从数据库读取专利 {args.pub_number} 的比对结果...")

    from repository.patent_repository import PatentRepository
    from core.db_manager import DatabaseManager

    db_manager = DatabaseManager(db_path=args.db_path)
    repo = PatentRepository(db_manager=db_manager)

    assessment = repo.get_assessment_by_pub_number(args.pub_number, stage="fto_done")
    if not assessment:
        print(f"❌ 数据库中未找到专利 {args.pub_number} 的 fto_done 阶段评估结果。")
        sys.exit(1)

    patent_data = repo.get_patent_by_publication_number(args.pub_number)
    if not patent_data:
        print(f"❌ 数据库中未找到专利 {args.pub_number} 的基础信息。")
        sys.exit(1)

    context = prepare_fto_context(
        patent_data=patent_data,
        fto_result={
            "topic": assessment.get("assessment_summary", ""),
            "claims": json.loads(assessment["feature_matches"]) if assessment.get("feature_matches") else [],
            "final_risk_conclusion": assessment.get("analysis_conclusion", "")
        },
        filename=args.pub_number,
        topic=""
    )

    print("⚙️ 正在渲染 Word 报告...")
    try:
        result_path = generate_fto_report(context, args.template, args.output)
        print(f"✅ 报告已成功生成于: {result_path}")
    except Exception as e:
        print(f"❌ 生成报告时发生异常: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
