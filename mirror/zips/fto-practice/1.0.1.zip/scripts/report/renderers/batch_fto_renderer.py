import json
import os
import argparse
from datetime import datetime

from docxtpl import DocxTemplate
from report.docx_tools import merge_duplicate_cells_in_first_column
from report.contexts.fto_context import prepare_fto_context


def get_valid_value(*args):
    for val in args:
        if val and val != "未知":
            return val
    return "未知"


def render_fto_report_from_db(db_path, template_path, output_dir):
    from repository.patent_repository import PatentRepository
    from core.db_manager import DatabaseManager

    db_manager = DatabaseManager(db_path=db_path)
    repo = PatentRepository(db_manager=db_manager)

    assessments = repo.get_all_assessments_by_stage("fto_done")
    if not assessments:
        print("⚠️ 未找到任何 fto_done 阶段的评估结果。")
        return

    os.makedirs(output_dir, exist_ok=True)
    success_count = 0
    error_count = 0

    for assessment in assessments:
        pub_number = assessment.get("publication_number")
        print(f"📄 正在处理专利: {pub_number}")

        try:
            patent_data = repo.get_patent_by_publication_number(pub_number)
            if not patent_data:
                print(f"  ⚠️ 数据库中未找到专利 {pub_number} 的基础信息，跳过。")
                error_count += 1
                continue

            fto_result = {
                "topic": assessment.get("assessment_summary", ""),
                "claims": json.loads(assessment["feature_matches"]) if assessment.get("feature_matches") else [],
                "final_risk_conclusion": assessment.get("analysis_conclusion", "")
            }

            context = prepare_fto_context(patent_data, fto_result, pub_number, topic="")

            output_path = os.path.join(output_dir, f"{pub_number}_FTO_报告.docx")
            doc = DocxTemplate(template_path)
            doc.render(context)
            doc.save(output_path)
            merge_duplicate_cells_in_first_column(output_path)
            print(f"  ✅ 报告已生成: {output_path}")
            success_count += 1

        except Exception as e:
            print(f"  ❌ 处理 {pub_number} 时发生异常: {e}")
            error_count += 1

    print(f"\n🏁 批量渲染完成！")
    print(f"   ✅ 成功: {success_count} 篇")
    print(f"   ❌ 失败: {error_count} 篇")
    print(f"   📂 输出目录: {output_dir}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="批量 FTO Word 报告渲染工具")
    parser.add_argument("--db_path", type=str, required=True, help="SQLite 数据库路径")
    parser.add_argument("-t", "--template", type=str, required=True, help="Word 模板文件路径")
    parser.add_argument("-o", "--output", type=str, required=True, help="输出目录路径")
    args = parser.parse_args()
    render_fto_report_from_db(args.db_path, args.template, args.output)
