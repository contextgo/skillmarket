import json
import os
import argparse
from docxtpl import DocxTemplate

from report.docx_tools import merge_duplicate_cells_in_first_column


def generate_warning_report(report_data: dict, template_path: str, output_path: str) -> str:
    doc = DocxTemplate(template_path)
    doc.render(report_data)
    doc.save(output_path)
    merge_duplicate_cells_in_first_column(output_path)
    return output_path


def render_warning_reports_from_db(db_path, template_path, output_dir):
    from repository.patent_repository import PatentRepository
    from core.db_manager import DatabaseManager

    db_manager = DatabaseManager(db_path=db_path)
    repo = PatentRepository(db_manager=db_manager)

    assessments = repo.get_all_assessments_by_stage("filter_done")
    if not assessments:
        print("⚠️ 未找到任何 filter_done 阶段的评估结果。")
        return

    os.makedirs(output_dir, exist_ok=True)
    success_count = 0
    error_count = 0

    for assessment in assessments:
        pub_number = assessment.get("publication_number")
        print(f"📄 正在处理专利: {pub_number}")

        try:
            patent_data = repo.get_patent_by_publication_number(pub_number)
            if not patent_data:
                print(f"  ⚠️ 数据库中未找到专利 {pub_number} 的基础信息，跳过。")
                error_count += 1
                continue

            context = {
                "patent_title": patent_data.get("title", "未知"),
                "patent_publication_number": pub_number,
                "patent_publication_date": patent_data.get("publication_date", "未知"),
                "patent_application_number": patent_data.get("application_number", "未知"),
                "patent_application_date": patent_data.get("application_date", "未知"),
                "patent_applicant": ", ".join(patent_data.get("assignees", [])) if patent_data.get("assignees") else "未知",
                "patent_legal_status": patent_data.get("legal_status", "未知"),
                "filter_relevance_score": assessment.get("relevance_score", ""),
                "filter_summary": assessment.get("assessment_summary", ""),
            }

            output_path = os.path.join(output_dir, f"{pub_number}_预警报告.docx")
            doc = DocxTemplate(template_path)
            doc.render(context)
            doc.save(output_path)
            merge_duplicate_cells_in_first_column(output_path)
            print(f"  ✅ 报告已生成: {output_path}")
            success_count += 1

        except Exception as e:
            print(f"  ❌ 处理 {pub_number} 时发生异常: {e}")
            error_count += 1

    print(f"\n🏁 批量渲染完成！")
    print(f"   ✅ 成功: {success_count} 篇")
    print(f"   ❌ 失败: {error_count} 篇")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="批量预警报告 Word 渲染工具")
    parser.add_argument("--db_path", type=str, required=True)
    parser.add_argument("-t", "--template", type=str, required=True)
    parser.add_argument("-o", "--output", type=str, required=True)
    args = parser.parse_args()
    render_warning_reports_from_db(args.db_path, args.template, args.output)
