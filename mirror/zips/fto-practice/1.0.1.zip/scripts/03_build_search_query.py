import json
import sys
import argparse
from pathlib import Path

def build_tac_all(keyword_groups, platform="patsnap"):
    zh_parts = []
    en_parts = []
    for group in keyword_groups:
        # 中文部分
        zh_words = []
        if group.get("中文主词"):
            zh_words.append(group.get("中文主词"))
        if group.get("中文扩展词"):
            zh_words.extend(group.get("中文扩展词"))
        
        # 英文部分
        en_words = []
        if group.get("英文主词"):
            en_words.append(group.get("英文主词"))
        if group.get("英文扩展词"):
            en_words.extend(group.get("英文扩展词"))
            
        if platform == "epo":
            # EPO 需要对每个词加 ta= 前缀
            zh_group_parts = [f"ta={w}" for w in zh_words]
            en_group_parts = [f'ta="{w}"' for w in en_words]
            if zh_group_parts:
                zh_parts.append("(" + " OR ".join(zh_group_parts) + ")")
            if en_group_parts:
                en_parts.append("(" + " OR ".join(en_group_parts) + ")")
        else:
            if zh_words:
                zh_parts.append("(" + " OR ".join(zh_words) + ")")
            if en_words:
                en_words_quoted = [f'"{w}"' for w in en_words]
                en_parts.append("(" + " OR ".join(en_words_quoted) + ")")
            
    zh_clause = " AND ".join(zh_parts)
    en_clause = " AND ".join(en_parts)
    
    parts = []
    if platform == "epo":
        if zh_clause:
            parts.append(f"({zh_clause})")
        if en_clause:
            parts.append(f"({en_clause})")
    elif platform == "patsnap":
        if zh_clause:
            parts.append(f"TAC:({zh_clause})")
        if en_clause:
            parts.append(f"TAC:({en_clause})")
    elif platform == "baiten":
        if zh_clause:
            parts.append(f"ALL:({zh_clause})")
        if en_clause:
            parts.append(f"ALL:({en_clause})")
    else: # uspto, himmpat, cn
        if zh_clause:
            parts.append(f"({zh_clause})")
        if en_clause:
            parts.append(f"({en_clause})")
        
    return " OR ".join(parts)

def build_ipc_cpc(ipc_cpc_list, platform="patsnap"):
    if not ipc_cpc_list:
        return "IPC:()" if platform != "epo" else "()"
        
    joined = " OR ".join(ipc_cpc_list)
    if platform == "epo":
        parts = [f"ipc={code} OR cpc={code}" for code in ipc_cpc_list]
        return "(" + " OR ".join(parts) + ")"
    elif platform == "patsnap":
        return f"(IPC:({joined}) OR CPC:({joined}))"
    elif platform == "baiten":
        return f"(ipc:({joined}) OR cpc:({joined}))"
    else:
        return f"IPC_CPC:({joined})"

def generate_queries(json_data, platform="patsnap"):
    # 1. 过滤数据：仅保留“技术领域”和“核心特征”
    filtered_data = [
        item for item in json_data 
        if item.get("特征类型") in ["技术领域", "核心特征"]
    ]
    
    if not filtered_data:
        print("未找到'技术领域'或'核心特征'的数据。")
        return

    queries = []
    
    # 2. S0: 全局限定
    s0 = "AUTHORITY:(US OR CN OR EP OR JP OR KR) AND PATENT_TYPE:(A OR B OR U) AND SIMPLE_LEGAL_STATUS:(1 OR 2)"
    queries.append(("S0", s0))
    
    odd_indices = []
    even_indices = []
    
    # 3. 动态生成成对的检索式
    for i, item in enumerate(filtered_data):
        odd_num = 2 * i + 1
        even_num = 2 * i + 2
        
        odd_indices.append(f"S{odd_num}")
        even_indices.append(f"S{even_num}")
        
        # S{奇数}: 关键词
        keyword_query = build_tac_all(item.get("关键词组", []), platform)
        queries.append((f"S{odd_num}", keyword_query))
        
        # S{偶数}: 分类号
        class_query = build_ipc_cpc(item.get("IPC_CPC", []), platform)
        queries.append((f"S{even_num}", class_query))
        
    # 4. 构建最终组合检索式 S_Final
    n = 2 * len(filtered_data)
    final_num = n + 1
    
    # Part A: (S1) AND ((S3) OR (S5) OR ...)
    s1 = odd_indices[0]
    rest_odds = odd_indices[1:]
    
    if rest_odds:
        if len(rest_odds) == 1:
            part_a = f"(({s1}) AND ({rest_odds[0]}))"
        else:
            rest_odds_str = " OR ".join([f"({s})" for s in rest_odds])
            part_a = f"(({s1}) AND ({rest_odds_str}))"
    else:
        part_a = f"({s1})"
        
    # Part B: ((S2 OR S4 OR ...) AND (S1 OR S3 OR ...))
    even_str = " OR ".join([f"({s})" for s in even_indices])
    all_odds_str = " OR ".join([f"({s})" for s in odd_indices])
    part_b = f"(({even_str}) AND ({all_odds_str}))"
    
    # 最终式
    final_query = f"(S0) AND ({part_a} OR {part_b})"
    queries.append((f"S{final_num}", final_query))
    
    # 打印输出
    for name, query in queries:
        print(f"检索式{name}:")
        print(query)
        print()

def main():
    parser = argparse.ArgumentParser(description="将增强版技术特征JSON转换为布尔逻辑检索式。")
    parser.add_argument("-f", "--file", type=str, help="输入的JSON文件路径。如果不提供，则从标准输入读取。")
    parser.add_argument("-p", "--platform", type=str, default="patsnap", choices=["patsnap", "baiten", "epo", "uspto", "himmpat", "cn"], help="目标检索平台")
    args = parser.parse_args()

    try:
        if args.file:
            with open(args.file, "r", encoding="utf-8") as f:
                json_data = json.load(f)
        else:
            print("请输入JSON数据 (按 Ctrl+D 或 Ctrl+Z 结束):")
            input_data = sys.stdin.read()
            json_data = json.loads(input_data)
            
        generate_queries(json_data, args.platform)
        
    except json.JSONDecodeError as e:
        print(f"JSON解析错误: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"发生错误: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
