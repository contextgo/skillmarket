from __future__ import annotations

from typing import Any, Protocol

from pydantic import BaseModel

from .cleanser_base import BaseCleanser
from .models import FinalStatus
from .parse_pipeline import ParsePipeline
from .transport import LLMTransport


class JobAdapter(Protocol):
    response_model: type[BaseModel]
    job_type: str
    temperature: float
    failure_status: FinalStatus

    def build_prompt(self, ctx: dict[str, Any]) -> str:
        ...

    def get_cleanser(self) -> BaseCleanser | None:
        ...

    def augment_retry_prompt(self, base_prompt: str, attempt: int, error: Exception | None) -> str:
        ...

    def on_success(self, ctx: dict[str, Any], parsed: BaseModel | dict[str, Any], raw_text: str, stats: dict[str, Any]) -> None:
        ...

    def on_failure(self, ctx: dict[str, Any], error: Exception, raw_text: str | None, stats: dict[str, Any]) -> None:
        ...


async def execute_with_retry(
    adapter: JobAdapter,
    ctx: dict[str, Any],
    transport: LLMTransport,
    parse_pipeline: ParsePipeline,
    max_attempts: int = 2,
) -> tuple[bool, dict[str, Any]]:
    try:
        base_prompt = adapter.build_prompt(ctx)
    except Exception as exc:
        adapter.on_failure(
            ctx,
            exc,
            None,
            stats={"attempts": 0, "error_type": "unknown_error"},
        )
        return False, {"attempts": 0, "status": adapter.failure_status, "error_type": "unknown_error"}
    cleanser = adapter.get_cleanser()

    last_error: Exception | None = None
    last_raw_text: str | None = None
    last_error_type: str | None = None

    for attempt in range(1, max_attempts + 1):
        prompt = base_prompt if attempt == 1 else adapter.augment_retry_prompt(base_prompt, attempt, last_error)
        try:
            parsed, raw_text = await transport.call_async(
                prompt=prompt,
                response_model=adapter.response_model,
                temperature=adapter.temperature,
            )
            adapter.on_success(
                ctx,
                parsed,
                raw_text,
                stats={"attempts": attempt, "error_type": None},
            )
            return True, {"attempts": attempt, "status": "success", "error_type": None}
        except Exception as exc:
            last_error = exc
            raw_text = parse_pipeline.extract_raw_text_from_exception(exc)
            if raw_text:
                last_raw_text = raw_text
                parse_outcome = parse_pipeline.parse_or_cleanse(
                    raw_text=raw_text,
                    response_model=adapter.response_model,
                    cleanser=cleanser,
                )
                if parse_outcome.ok:
                    parsed_after_cleanse = parse_outcome.parsed
                    adapter.on_success(
                        ctx,
                        parsed_after_cleanse,
                        raw_text,
                        stats={"attempts": attempt, "error_type": parse_outcome.error_type},
                    )
                    return True, {"attempts": attempt, "status": "success", "error_type": parse_outcome.error_type}
                last_error_type = parse_outcome.error_type
            else:
                last_error_type = "llm_call_error"

    final_error = last_error or RuntimeError("Unknown retry failure")
    adapter.on_failure(
        ctx,
        final_error,
        last_raw_text,
        stats={"attempts": max_attempts, "error_type": last_error_type},
    )
    return False, {"attempts": max_attempts, "status": adapter.failure_status, "error_type": last_error_type}
