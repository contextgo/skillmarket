from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal


ErrorType = Literal["json_decode_error", "schema_validation_error", "llm_call_error", "unknown_error"]
FinalStatus = Literal["success", "failed", "skipped"]


@dataclass
class JobContext:
    job_id: str
    payload: dict[str, Any]


@dataclass
class ParseOutcome:
    ok: bool
    parsed: Any | None = None
    raw_text: str | None = None
    error_type: ErrorType | None = None
    error: Exception | None = None


@dataclass
class RetryDecision:
    should_retry: bool
    retry_prompt: str | None = None
    reason: str | None = None


@dataclass
class RunStats:
    total_input: int = 0
    success_count: int = 0
    skipped_count: int = 0
    failed_count: int = 0
    retry_histogram: dict[int, int] = field(default_factory=dict)
    error_type_histogram: dict[str, int] = field(default_factory=dict)

    def record_terminal(self, status: FinalStatus) -> None:
        if status == "success":
            self.success_count += 1
        elif status == "skipped":
            self.skipped_count += 1
        else:
            self.failed_count += 1

    def record_retry(self, retry_count: int) -> None:
        self.retry_histogram[retry_count] = self.retry_histogram.get(retry_count, 0) + 1

    def record_error_type(self, error_type: str | None) -> None:
        if not error_type:
            return
        self.error_type_histogram[error_type] = self.error_type_histogram.get(error_type, 0) + 1

    @property
    def terminal_count(self) -> int:
        return self.success_count + self.skipped_count + self.failed_count
