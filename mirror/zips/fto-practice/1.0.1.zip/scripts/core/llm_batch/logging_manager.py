from __future__ import annotations

import logging
import os


class BatchLoggingManager:
    _STEP_TO_FILENAME = {
        "step6_screening": "filter_step6_screening.log",
        "step5_precision_eval": "step5_precision_eval.log",
        "step5_query_optimize": "step5_query_optimize.log",
        "step7_step1_extract": "fto_step1_extract.log",
        "step7_step2_compare": "fto_step2_compare.log",
    }

    def setup_for_step(self, step_name: str, db_path: str) -> str:
        log_dir = os.path.dirname(os.path.abspath(db_path))
        file_name = self._STEP_TO_FILENAME.get(step_name, f"{step_name}.log")
        log_path = os.path.join(log_dir, file_name)

        root_logger = logging.getLogger()
        root_logger.setLevel(logging.INFO)
        for handler in root_logger.handlers[:]:
            root_logger.removeHandler(handler)

        file_handler = logging.FileHandler(log_path, encoding="utf-8")
        file_handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
        root_logger.addHandler(file_handler)

        logging.getLogger("httpx").setLevel(logging.INFO)
        return log_path
