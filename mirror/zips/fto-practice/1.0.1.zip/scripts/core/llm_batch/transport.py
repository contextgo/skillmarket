from __future__ import annotations

from pydantic import BaseModel

from core.llm_client import LLMClient


class LLMTransport:
    def __init__(self, llm_client: LLMClient) -> None:
        self._llm_client = llm_client

    async def call_async(
        self,
        prompt: str,
        response_model: type[BaseModel],
        temperature: float = 0.2,
    ) -> tuple[BaseModel, str]:
        return await self._llm_client.generate_structured_data_async(
            prompt=prompt,
            response_model=response_model,
            temperature=temperature,
        )

    def call_sync(
        self,
        prompt: str,
        response_model: type[BaseModel],
        temperature: float = 0.2,
    ) -> BaseModel:
        return self._llm_client.generate_structured_data(
            prompt=prompt,
            response_model=response_model,
            temperature=temperature,
        )
