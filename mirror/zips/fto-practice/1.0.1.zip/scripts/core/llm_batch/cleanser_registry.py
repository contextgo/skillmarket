from __future__ import annotations

from collections.abc import Callable

from .cleanser_base import BaseCleanser


class CleanserRegistry:
    def __init__(self) -> None:
        self._registry: dict[str, Callable[[], BaseCleanser] | BaseCleanser] = {}

    def register(self, job_type: str, cleanser: Callable[[], BaseCleanser] | BaseCleanser) -> None:
        self._registry[job_type] = cleanser

    def get(self, job_type: str) -> BaseCleanser | None:
        registered = self._registry.get(job_type)
        if registered is None:
            return None
        if callable(registered):
            return registered()
        return registered
