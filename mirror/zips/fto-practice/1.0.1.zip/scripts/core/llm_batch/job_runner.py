from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from typing import Any

from .models import RunStats


Processor = Callable[[dict[str, Any]], Awaitable[dict[str, Any]]]


class BatchJobRunner:
    def __init__(self, worker_count: int = 5) -> None:
        self.worker_count = max(1, worker_count)

    async def run(
        self,
        jobs: list[dict[str, Any]],
        processor: Processor,
        progress_callback: Callable[[RunStats], None] | None = None,
    ) -> RunStats:
        stats = RunStats(total_input=len(jobs))
        queue: asyncio.Queue[dict[str, Any] | None] = asyncio.Queue()
        for job in jobs:
            await queue.put(job)
        for _ in range(self.worker_count):
            await queue.put(None)

        async def worker() -> None:
            while True:
                item = await queue.get()
                if item is None:
                    queue.task_done()
                    break
                try:
                    result = await processor(item)
                    stats.record_terminal(result.get("status", "failed"))
                    stats.record_retry(max(0, int(result.get("attempts", 1)) - 1))
                    stats.record_error_type(result.get("error_type"))
                except Exception:
                    stats.record_terminal("failed")
                    stats.record_retry(0)
                    stats.record_error_type("unknown_error")
                finally:
                    queue.task_done()
                    if progress_callback:
                        progress_callback(stats)

        workers = [asyncio.create_task(worker()) for _ in range(self.worker_count)]
        await queue.join()
        await asyncio.gather(*workers)

        if stats.total_input != stats.terminal_count:
            raise RuntimeError(
                f"终态计数不一致: total_input={stats.total_input}, terminal={stats.terminal_count}"
            )
        return stats
