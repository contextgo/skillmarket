from __future__ import annotations

from typing import Protocol


class BaseCleanser(Protocol):
    def cleanse(self, raw_text: str) -> str | dict | None:
        ...
