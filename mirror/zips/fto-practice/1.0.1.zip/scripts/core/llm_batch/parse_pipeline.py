from __future__ import annotations

import json
from typing import Any

from pydantic import BaseModel, ValidationError

from .cleanser_base import BaseCleanser
from .models import ParseOutcome


class ParsePipeline:
    def parse_direct(self, raw_text: str, response_model: type[BaseModel]) -> ParseOutcome:
        stripped = self._strip_markdown_fence(raw_text or "")
        try:
            return ParseOutcome(ok=True, parsed=response_model.model_validate_json(stripped), raw_text=raw_text)
        except ValidationError as exc:
            return ParseOutcome(
                ok=False,
                raw_text=raw_text,
                error=exc,
                error_type="schema_validation_error",
            )
        except json.JSONDecodeError as exc:
            return ParseOutcome(ok=False, raw_text=raw_text, error=exc, error_type="json_decode_error")
        except Exception as exc:
            # Some providers return non-standard payloads. Try dict validation as fallback.
            try:
                parsed_dict = json.loads(stripped)
                return ParseOutcome(ok=True, parsed=response_model.model_validate(parsed_dict), raw_text=raw_text)
            except ValidationError as inner_exc:
                return ParseOutcome(
                    ok=False,
                    raw_text=raw_text,
                    error=inner_exc,
                    error_type="schema_validation_error",
                )
            except json.JSONDecodeError as inner_exc:
                return ParseOutcome(ok=False, raw_text=raw_text, error=inner_exc, error_type="json_decode_error")
            except Exception:
                return ParseOutcome(ok=False, raw_text=raw_text, error=exc, error_type="unknown_error")

    def parse_or_cleanse(
        self,
        raw_text: str,
        response_model: type[BaseModel],
        cleanser: BaseCleanser | None = None,
    ) -> ParseOutcome:
        first_outcome = self.parse_direct(raw_text, response_model)
        if first_outcome.ok or cleanser is None:
            return first_outcome

        cleansed = cleanser.cleanse(raw_text)
        if cleansed is None:
            return first_outcome

        try:
            if isinstance(cleansed, dict):
                parsed = response_model.model_validate(cleansed)
            elif isinstance(cleansed, str):
                parsed = response_model.model_validate_json(self._strip_markdown_fence(cleansed))
            else:
                return first_outcome
            return ParseOutcome(ok=True, parsed=parsed, raw_text=raw_text)
        except ValidationError as exc:
            return ParseOutcome(ok=False, raw_text=raw_text, error=exc, error_type="schema_validation_error")
        except json.JSONDecodeError as exc:
            return ParseOutcome(ok=False, raw_text=raw_text, error=exc, error_type="json_decode_error")
        except Exception as exc:
            return ParseOutcome(ok=False, raw_text=raw_text, error=exc, error_type="unknown_error")

    @staticmethod
    def _strip_markdown_fence(raw_text: str) -> str:
        stripped = (raw_text or "").strip()
        if not stripped.startswith("```"):
            return stripped
        lines = stripped.splitlines()
        if not lines:
            return stripped
        lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        return "\n".join(lines).strip()

    @staticmethod
    def extract_raw_text_from_exception(error: Exception) -> str | None:
        message = str(error)
        marker = "模型返回原文:"
        if marker in message:
            return message.split(marker, 1)[-1].strip()
        return None
