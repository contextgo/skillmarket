from pydantic import AliasChoices, BaseModel, Field, model_validator


class FeatureItem(BaseModel):
    id: str = Field(
        description="特征编号，例如 T1, T2",
        validation_alias=AliasChoices("id", "feature_id"),
    )
    content: str = Field(
        description="拆解出的独立技术特征文本",
        validation_alias=AliasChoices("content", "text", "description"),
    )


class ClaimExtractionResult(BaseModel):
    name: str = Field(
        description="权利要求名称，例如 '权1'",
        validation_alias=AliasChoices("name", "claim_name", "claim_id", "claim_number", "id"),
    )
    features: list[FeatureItem] = Field(
        description="该权利要求拆解出的所有特征列表",
        validation_alias=AliasChoices("features", "technical_features", "feature_list")
    )

    @model_validator(mode="before")
    @classmethod
    def _normalize_features_list(cls, value):
        if not isinstance(value, dict):
            return value

        if "name" not in value:
            raw_claim_number = value.get("claim_number")
            if raw_claim_number not in (None, ""):
                value["name"] = f"权{raw_claim_number}"
            else:
                raw_claim_id = value.get("claim_id")
                if raw_claim_id not in (None, ""):
                    value["name"] = str(raw_claim_id)

        raw_features = value.get("features") or value.get("technical_features") or value.get("feature_list")
        if not isinstance(raw_features, list):
            return value

        normalized = []
        for idx, item in enumerate(raw_features, start=1):
            if isinstance(item, dict):
                normalized.append(item)
                continue

            if isinstance(item, str):
                text = item.strip()
                if ":" in text or "：" in text:
                    splitter = ":" if ":" in text else "："
                    left, right = text.split(splitter, 1)
                    fid = left.strip() or f"T{idx}"
                    content = right.strip()
                else:
                    fid = f"T{idx}"
                    content = text
                normalized.append({"id": fid, "content": content})

        value["features"] = normalized
        return value


class ExtractionResponse(BaseModel):
    claims: list[ClaimExtractionResult] = Field(
        validation_alias=AliasChoices("claims", "independent_claims", "extraction")
    )


class FeatureResult(BaseModel):
    id: str = Field(
        description="特征编号",
        validation_alias=AliasChoices("id", "feature_id"),
    )
    content: str = Field(
        default="",
        description="特征文本",
        validation_alias=AliasChoices("content", "text", "description"),
    )
    analysis_reasoning: str = Field(
        default="",
        description="在此处填写你进行比对的内部推理逻辑和原因。务必简明扼要。",
        validation_alias=AliasChoices("analysis_reasoning", "reason", "reasoning"),
    )
    result: str = Field(
        description="最终比对结论，必须且只能是：'具有该特征'、'不具有该特征'、'具有等同特征'或'相同技术主题'",
        validation_alias=AliasChoices("result", "conclusion", "match_result", "judgment"),
    )


class ClaimResult(BaseModel):
    name: str = Field(
        description="权利要求名称",
        validation_alias=AliasChoices("name", "claim_name", "claim_id", "claim_number", "id"),
    )
    features: list[FeatureResult] = Field(
        description="特征比对结果列表，必须与输入特征一一对应，并且每个特征都必须包含 result 字段",
        validation_alias=AliasChoices("features", "feature_results", "results"),
    )
    analysis_conclusion: str = Field(
        default="",
        description="单项权利要求的比对小结",
        validation_alias=AliasChoices("analysis_conclusion", "conclusion", "summary", "claim_analysis"),
    )

    @model_validator(mode="before")
    @classmethod
    def _normalize_claim_result(cls, value):
        if not isinstance(value, dict):
            return value

        if "name" not in value:
            raw_claim_number = value.get("claim_number")
            if raw_claim_number not in (None, ""):
                value["name"] = f"权{raw_claim_number}"
            else:
                raw_claim_id = value.get("claim_id")
                if raw_claim_id not in (None, ""):
                    value["name"] = str(raw_claim_id)

        raw_features = value.get("features") or value.get("feature_results") or value.get("results")
        if isinstance(raw_features, list):
            normalized = []
            for idx, item in enumerate(raw_features, start=1):
                if isinstance(item, dict):
                    if "content" not in item and "text" not in item and "description" not in item:
                        item = {**item, "content": ""}
                    normalized.append(item)
                    continue
                if isinstance(item, str):
                    text = item.strip()
                    if ":" in text or "：" in text:
                        splitter = ":" if ":" in text else "："
                        left, right = text.split(splitter, 1)
                        fid = left.strip() or f"T{idx}"
                        content = right.strip()
                    else:
                        fid = f"T{idx}"
                        content = text
                    normalized.append(
                        {
                            "id": fid,
                            "content": content,
                            "result": "不具有该特征",
                            "analysis_reasoning": "",
                        }
                    )
            value["features"] = normalized

        if "analysis_conclusion" not in value:
            value["analysis_conclusion"] = value.get("conclusion") or value.get("summary") or value.get("claim_analysis") or ""

        conclusion = value.get("analysis_conclusion")
        if isinstance(conclusion, list):
            parts = []
            for item in conclusion:
                if isinstance(item, dict):
                    text = item.get("summary") or item.get("analysis") or item.get("conclusion") or item.get("analysis_conclusion") or ""
                    if text:
                        parts.append(str(text))
                elif isinstance(item, str):
                    parts.append(item)
            value["analysis_conclusion"] = "；".join([p for p in parts if p]).strip() or ""
        elif conclusion is None:
            value["analysis_conclusion"] = ""
        elif not isinstance(conclusion, str):
            value["analysis_conclusion"] = str(conclusion)
        return value


class LLMComparisonResult(BaseModel):
    claims: list[ClaimResult] = Field(
        default_factory=list,
        validation_alias=AliasChoices(
            "claims",
            "claim_results",
            "comparison_results",
            "feature_comparison",
            "comparisons",
            "claim_analysis",
            "claims_analysis",
        )
    )
    final_risk_conclusion: str = Field(
        default="",
        description="整体侵权风险结论",
        validation_alias=AliasChoices(
            "final_risk_conclusion",
            "overall_conclusion",
            "final_conclusion",
            "risk_conclusion",
            "conclusion",
            "overall_risk_conclusion",
            "risk_summary",
        ),
    )

    @model_validator(mode="before")
    @classmethod
    def _normalize_comparison_payload(cls, value):
        if not isinstance(value, dict):
            return value

        if "feature_comparison" in value and "claim_analysis" in value:
            claim_analysis = value.get("claim_analysis", [])
            feature_comparison = value.get("feature_comparison", [])

            if isinstance(claim_analysis, list) and len(claim_analysis) == 1:
                value["claims"] = [{
                    "name": claim_analysis[0].get("claim_name", "权1"),
                    "features": feature_comparison,
                    "analysis_conclusion": claim_analysis[0].get("analysis_conclusion", "")
                }]
            elif isinstance(claim_analysis, list) and len(claim_analysis) > 1:
                claims_res = []
                for idx, ca in enumerate(claim_analysis):
                    claims_res.append({
                        "name": ca.get("claim_name", f"权{idx+1}"),
                        "features": feature_comparison if idx == 0 else [],
                        "analysis_conclusion": ca.get("analysis_conclusion", "")
                    })
                value["claims"] = claims_res
            else:
                value["claims"] = [{
                    "name": "权1",
                    "features": feature_comparison,
                    "analysis_conclusion": str(claim_analysis)
                }]

        if not value.get("final_risk_conclusion"):
            for key in [
                "overall_risk_conclusion",
                "final_conclusion",
                "risk_conclusion",
                "conclusion",
                "overall_conclusion",
                "risk_summary",
            ]:
                if value.get(key):
                    value["final_risk_conclusion"] = value[key]
                    break

        if not value.get("claims"):
            if isinstance(value.get("feature_comparisons"), list) and value.get("feature_comparisons"):
                top_conclusion = value.get("analysis_conclusion", value.get("conclusion", ""))
                if isinstance(top_conclusion, list):
                    parts = []
                    for item in top_conclusion:
                        if isinstance(item, dict):
                            parts.append(str(item.get("summary") or item.get("analysis") or item.get("conclusion") or ""))
                        elif isinstance(item, str):
                            parts.append(item)
                    top_conclusion = "；".join([p for p in parts if p]).strip()
                elif top_conclusion is None:
                    top_conclusion = ""
                elif not isinstance(top_conclusion, str):
                    top_conclusion = str(top_conclusion)

                value["claims"] = [
                    {
                        "name": value.get("name", "权1"),
                        "features": value.get("feature_comparisons", []),
                        "analysis_conclusion": top_conclusion,
                    }
                ]

        if not value.get("claims"):
            if isinstance(value.get("features"), list) and value.get("features"):
                value["claims"] = [
                    {
                        "name": value.get("name", "权1"),
                        "features": value.get("features", []),
                        "analysis_conclusion": value.get("analysis_conclusion", value.get("conclusion", "")),
                    }
                ]

        if not value.get("claims"):
            list_candidate_keys = [
                "claim_results",
                "comparison_results",
                "comparisons",
                "claim_analysis",
                "claims_analysis",
                "feature_comparison",
                "feature_comparisons",
            ]
            for key in list_candidate_keys:
                raw_list = value.get(key)
                if isinstance(raw_list, list) and raw_list:
                    if all(isinstance(item, dict) for item in raw_list):
                        value["claims"] = raw_list
                        break
                    if all(isinstance(item, str) for item in raw_list):
                        value["claims"] = [
                            {
                                "name": f"权{i + 1}",
                                "features": [],
                                "analysis_conclusion": item,
                            }
                            for i, item in enumerate(raw_list)
                        ]
                        break

        if not value.get("claims"):
            for _, nested in value.items():
                if isinstance(nested, dict):
                    nested_list = nested.get("claims") or nested.get("claim_results")
                    if isinstance(nested_list, list):
                        value["claims"] = nested_list
                        break

        if not value.get("claims"):
            value["claims"] = []
        return value
