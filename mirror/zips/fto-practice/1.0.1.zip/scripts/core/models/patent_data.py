from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any, Literal

class UnifiedSearchResult(BaseModel):
    """统一专利检索结果模型"""
    hit_count: int
    patent_numbers: List[str]
    raw_response: Dict[str, Any] = Field(default_factory=dict)

class RelevanceResult4Tier(BaseModel):
    """4档评分结果模型（用于第六步FTO初筛）"""
    score: Literal[0, 1, 2, 3]
    reason: str
    node: str

class PatentClaim(BaseModel):
    """权利要求单项模型"""
    claim_number: str
    claim_text: str
    is_independent: bool = False
    dependencies: List[str] = Field(default_factory=list)

class PatentLegalStatus(BaseModel):
    """专利法律状态模型"""
    status_code: str
    status_description: str
    date: Optional[str] = None
    is_active: bool = False

class PatentBibliography(BaseModel):
    """专利著录项模型"""
    patent_number: str
    title: str
    abstract: str
    application_date: str
    publication_date: str
    application_number: Optional[str] = None
    assignees: List[str] = Field(default_factory=list)
    inventors: List[str] = Field(default_factory=list)
    ipc_classes: List[str] = Field(default_factory=list)

class PatentData(BaseModel):
    """
    统一专利数据模型
    无论底层是从 Zhihuiya, Lens 还是 EPO 提取的数据，最终传递给 Processor 的都应该是这个结构。
    """
    bibliography: Optional[PatentBibliography] = None
    legal_status: Optional[PatentLegalStatus] = None
    claims: List[PatentClaim] = Field(default_factory=list)
    
    # 原始响应数据的保留，用于排查问题或提取某些平台独有的特殊字段
    raw_source_data: Dict[str, Any] = Field(default_factory=dict)
    source_platform: str = "unknown"

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PatentData":
        """从字典安全反序列化为 PatentData 对象"""
        return cls(**data)
        
    def to_clean_dict(self) -> Dict[str, Any]:
        """
        导出干净的字典结构，专门剔除掉体积庞大的 raw_source_data，
        以避免将其一股脑写入中间文件（如 CNXXX_data.json）导致文件臃肿难以阅读。
        """
        return self.model_dump(exclude={"raw_source_data"})
