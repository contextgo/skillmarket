import os
import json
import logging
from typing import Type, TypeVar, Any, Tuple, Optional, Dict, Literal, get_origin, get_args
from pydantic import BaseModel

logger = logging.getLogger(__name__)

T = TypeVar('T', bound=BaseModel)


class LLMClient:
    """统一的大模型 API 调用客户端，支持 OpenAI兼容 / Gemini，通过参数注入或回退读取配置文件"""

    def __init__(
        self,
        config_path: str = None,
        api_key: str = None,
        base_url: str = None,
        actual_model: str = None,
        gemini_api_key: str = None
    ):
        if config_path is None:
            # 默认指向 assets/llm_api/config.json
            config_path = os.path.join(
                os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 
                "assets", "llm_api", "config.json"
            )
        self.config_path = config_path
        self.api_key = api_key
        self.base_url = base_url
        self.actual_model = actual_model
        self.gemini_api_key = gemini_api_key
        self._load_config()

    def _load_config(self):
        """加载配置，优先级：传入参数 > config.json (固定文件优先) > 环境变量 fallback"""
        
        # 1. 尝试从配置文件加载
        cfg_api_key, cfg_base_url, cfg_model_name, cfg_gemini_key = None, None, None, None
        if os.path.exists(self.config_path):
            try:
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    cfg = json.load(f)
                    cfg_api_key = cfg.get("MINIMAX_API_KEY") or cfg.get("OPENAI_API_KEY") or cfg.get("DEEPSEEK_API_KEY")
                    cfg_base_url = cfg.get("MINIMAX_BASE_URL") or cfg.get("OPENAI_BASE_URL") or cfg.get("OPENAI_API_BASE") or cfg.get("DEEPSEEK_BASE_URL")
                    cfg_model_name = cfg.get("MINIMAX_MODEL_NAME") or cfg.get("OPENAI_MODEL_NAME") or cfg.get("DEEPSEEK_MODEL_NAME")
                    cfg_gemini_key = cfg.get("gemini_api_key") or cfg.get("GEMINI_API_KEY")
            except Exception as e:
                logger.warning("读取配置文件 %s 失败: %s", self.config_path, e)

        # 2. 综合优先级赋值：传入参数 > 配置文件 > 环境变量
        self.api_key = (
            self.api_key
            or cfg_api_key
            or os.environ.get("MINIMAX_API_KEY")
            or os.environ.get("OPENAI_API_KEY")
            or os.environ.get("DEEPSEEK_API_KEY")
        )
        self.base_url = (
            self.base_url
            or cfg_base_url
            or os.environ.get("MINIMAX_BASE_URL")
            or os.environ.get("OPENAI_BASE_URL")
            or os.environ.get("DEEPSEEK_BASE_URL")
        )
        self.actual_model = (
            self.actual_model
            or cfg_model_name
            or os.environ.get("MINIMAX_MODEL_NAME")
            or os.environ.get("OPENAI_MODEL_NAME")
            or os.environ.get("DEEPSEEK_MODEL_NAME")
            or "deepseek-chat"
        )
        self.gemini_api_key = (
            self.gemini_api_key
            or cfg_gemini_key
            or os.environ.get("GEMINI_API_KEY")
        )

    def generate_structured_data(
        self, prompt: str, response_model: Type[T], temperature: float = 0.2
    ) -> T:
        """
        调用大模型生成结构化数据
        :param prompt: 提示词
        :param response_model: Pydantic 模型类，用于结构化输出约束和解析
        :param temperature: 温度参数
        :return: 解析后的 Pydantic 模型实例
        """
        try:
            if self.api_key and self.base_url:
                return self._call_openai_compatible(prompt, response_model, temperature)
            elif self.gemini_api_key:
                return self._call_gemini(prompt, response_model, temperature)
            else:
                raise ValueError(
                    "❌ 错误: 未找到大模型 API KEY 配置，无法调用大模型。"
                    "请配置 MINIMAX_API_KEY / DEEPSEEK_API_KEY / OPENAI_API_KEY 或 GEMINI_API_KEY。"
                )
        except Exception as e:
            logger.error("大模型 API 结构化生成失败: %s", e)
            raise

    async def generate_structured_data_async(
        self, prompt: str, response_model: Type[T], temperature: float = 0.2
    ) -> Tuple[T, str]:
        """
        异步调用大模型生成结构化数据
        :param prompt: 提示词
        :param response_model: Pydantic 模型类
        :param temperature: 温度参数
        :return: (解析后的 Pydantic 模型实例, 思考过程日志)
        """
        if self.api_key and self.base_url:
            return await self._call_openai_compatible_async(prompt, response_model, temperature)
        elif self.gemini_api_key:
            return await self._call_gemini_async(prompt, response_model, temperature)
        else:
            raise ValueError(
                "❌ 错误: 未找到大模型 API KEY 配置，无法调用大模型。"
                "请配置 MINIMAX_API_KEY / DEEPSEEK_API_KEY / OPENAI_API_KEY 或 GEMINI_API_KEY。"
            )

    def _call_openai_compatible(self, prompt: str, response_model: Type[T], temperature: float) -> T:
        """调用 OpenAI 兼容接口 (如 DeepSeek/MiniMax)"""
        from openai import OpenAI

        client = OpenAI(api_key=self.api_key, base_url=self.base_url)
        logger.debug("Using OpenAI compatible API with model: %s", self.actual_model)

        kwargs = {
            "model": self.actual_model,
            "messages": [{"role": "user", "content": prompt}],
            "response_format": {"type": "json_object"},
            "temperature": temperature
        }

        if "minimax" in (self.actual_model or "").lower() or "minimax" in (self.base_url or "").lower():
            kwargs["extra_body"] = {"reasoning_split": True}

        response = client.chat.completions.create(**kwargs)

        reasoning_content = ""
        message = response.choices[0].message

        if hasattr(message, "reasoning_details") and message.reasoning_details:
            reasoning_content = "".join([d.get("text", "") for d in message.reasoning_details if "text" in d])
        elif getattr(message, "model_extra", {}) and "reasoning_details" in message.model_extra:
            reasoning_content = "".join([d.get("text", "") for d in message.model_extra["reasoning_details"] if "text" in d])
        elif hasattr(message, "reasoning_content") and message.reasoning_content:
            reasoning_content = message.reasoning_content

        if reasoning_content:
            logger.debug("Thinking process:\n%s", reasoning_content)

        content = response.choices[0].message.content
        try:
            result = self._parse_response(content, response_model)
            return result
        except Exception:
            raise Exception(f"数据解析失败。模型返回原文: {content}")

    async def _call_openai_compatible_async(
        self, prompt: str, response_model: Type[T], temperature: float
    ) -> Tuple[T, str]:
        """异步调用 OpenAI 兼容接口 (如 DeepSeek/MiniMax)"""
        from openai import AsyncOpenAI

        client = AsyncOpenAI(api_key=self.api_key, base_url=self.base_url)
        logger.debug("Using async OpenAI compatible API with model: %s", self.actual_model)

        kwargs = {
            "model": self.actual_model,
            "messages": [{"role": "user", "content": prompt}],
            "response_format": {"type": "json_object"},
            "temperature": temperature
        }

        if "minimax" in (self.actual_model or "").lower() or "minimax" in (self.base_url or "").lower():
            kwargs["extra_body"] = {"reasoning_split": True}

        response = await client.chat.completions.create(**kwargs)

        reasoning_content = ""
        message = response.choices[0].message

        if hasattr(message, "reasoning_details") and message.reasoning_details:
            reasoning_content = "".join([d.get("text", "") for d in message.reasoning_details if "text" in d])
        elif getattr(message, "model_extra", {}) and "reasoning_details" in message.model_extra:
            reasoning_content = "".join([d.get("text", "") for d in message.model_extra["reasoning_details"] if "text" in d])
        elif hasattr(message, "reasoning_content") and message.reasoning_content:
            reasoning_content = message.reasoning_content

        if reasoning_content:
            logger.debug("Thinking process:\n%s", reasoning_content)

        content = response.choices[0].message.content
        try:
            result = self._parse_response(content, response_model)
            logger.debug("LLM 原始返回数据:\n%s", json.dumps(result, indent=2, ensure_ascii=False) if isinstance(result, dict) else str(result))
            return result, content
        except Exception:
            raise Exception(f"数据解析失败。模型返回原文: {content}")

    def _parse_response(self, content: str, response_model: Type[T]) -> T:
        """解析 LLM 返回内容为 Pydantic 模型"""
        raw_content = content
        try:
            content = self._strip_markdown_fence(content)
            data = json.loads(content)
            logger.debug("LLM 原始返回数据:\n%s", json.dumps(data, indent=2, ensure_ascii=False))
            try:
                return response_model(**data)
            except Exception as parse_error:
                fixed_data = self._try_fix_common_type_errors(data, response_model)
                if fixed_data is not None:
                    logger.warning("检测到 LLM 返回类型异常，已尝试自动修复并重新解析。")
                    return response_model(**fixed_data)
                raise parse_error
        except Exception as e:
            logger.error("OpenAI compatible API 返回数据解析失败.\nContent: %s", raw_content)
            raise Exception(f"数据解析失败: {e}。模型返回原文: {raw_content}")

    def _strip_markdown_fence(self, content: str) -> str:
        """移除可能存在的 markdown 代码块包裹，仅保留 JSON 文本"""
        stripped = content.strip()
        if not stripped.startswith("```"):
            return stripped

        lines = stripped.splitlines()
        if not lines:
            return stripped

        # 第一行可能是 ``` 或 ```json
        lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        return "\n".join(lines).strip()

    def _try_fix_common_type_errors(
        self, data: Any, response_model: Type[T]
    ) -> Optional[Dict[str, Any]]:
        """尝试修复 LLM 常见类型错误（如 Literal[int,...] 被输出为字符串）"""
        if not isinstance(data, dict):
            return None

        model_fields = getattr(response_model, "model_fields", None) or getattr(response_model, "__fields__", None)
        if not model_fields:
            return None

        fixed_data = data.copy()
        changed = False

        for field_name, field_info in model_fields.items():
            if field_name not in fixed_data:
                continue

            annotation = (
                getattr(field_info, "annotation", None)
                or getattr(field_info, "outer_type_", None)
                or getattr(field_info, "type_", None)
            )
            if annotation is None:
                continue

            if get_origin(annotation) is not Literal:
                continue

            literal_values = get_args(annotation)
            if not literal_values or not all(isinstance(v, int) for v in literal_values):
                continue

            current_value = fixed_data[field_name]
            if not isinstance(current_value, str):
                continue

            value_str = current_value.strip()
            if not value_str:
                continue

            if value_str.startswith("-"):
                numeric = value_str[1:].isdigit()
            else:
                numeric = value_str.isdigit()
            if not numeric:
                continue

            int_value = int(value_str)
            if int_value in literal_values:
                fixed_data[field_name] = int_value
                changed = True

        return fixed_data if changed else None

    def _call_gemini(self, prompt: str, response_model: Type[T], temperature: float) -> T:
        """调用 Gemini 接口"""
        from google import genai
        from google.genai import types

        logger.debug("Using Gemini API with model: gemini-2.5-pro")
        llm_client = genai.Client(api_key=self.gemini_api_key)
        response = llm_client.models.generate_content(
            model="gemini-2.5-pro",
            contents=prompt,
            config=types.GenerateContentConfig(
                response_mime_type="application/json",
                response_schema=response_model,
                temperature=temperature,
            ),
        )
        return response.parsed

    async def _call_gemini_async(
        self, prompt: str, response_model: Type[T], temperature: float
    ) -> Tuple[T, str]:
        """异步调用 Gemini 接口"""
        from google import genai
        from google.genai import types
        import asyncio

        logger.debug("Using async Gemini API with model: gemini-2.5-pro")
        llm_client = genai.Client(api_key=self.gemini_api_key)

        def run_sync():
            return llm_client.models.generate_content(
                model="gemini-2.5-pro",
                contents=prompt,
                config=types.GenerateContentConfig(
                    response_mime_type="application/json",
                    response_schema=response_model,
                    temperature=temperature,
                ),
            )

        response = await asyncio.to_thread(run_sync)
        return response.parsed, ""
