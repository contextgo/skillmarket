import os
import json
import logging
from dataclasses import dataclass
from typing import Optional

logger = logging.getLogger(__name__)

# 定义配置文件的固定绝对路径
BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
LLM_CONFIG_PATH = os.path.join(BASE_DIR, "assets", "llm_api", "config.json")
PATENT_DB_CONFIG_PATH = os.path.join(BASE_DIR, "assets", "patent_database_api", "config.json")

@dataclass
class LLMConfig:
    api_key: str
    base_url: str
    model_name: str
    gemini_api_key: Optional[str] = None

@dataclass
class ProviderCredential:
    token: Optional[str] = None
    client_id: Optional[str] = None
    client_secret: Optional[str] = None

class ConfigResolver:
    """统一配置解析器，提供 Single Source of Truth 的配置读取策略"""

    @staticmethod
    def _read_json_config(path: str) -> dict:
        if not os.path.exists(path):
            return {}
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            logger.warning("读取配置文件 %s 失败: %s", path, e)
            return {}

    @staticmethod
    def resolve_llm(provider: str) -> LLMConfig:
        """
        解析 LLM 配置
        优先级: 固定文件 > 环境变量
        """
        cfg = ConfigResolver._read_json_config(LLM_CONFIG_PATH)
        provider = provider.lower()

        if provider == "minimax":
            api_key = cfg.get("MINIMAX_API_KEY") or os.environ.get("MINIMAX_API_KEY")
            base_url = cfg.get("MINIMAX_BASE_URL") or os.environ.get("MINIMAX_BASE_URL") or "https://api.minimax.chat/v1"
            model_name = cfg.get("MINIMAX_MODEL_NAME") or os.environ.get("MINIMAX_MODEL_NAME") or "MiniMax-M2.7"
            
            if not api_key:
                raise ValueError("MiniMax API key 未配置。请在 assets/llm_api/config.json 或环境变量中设置 MINIMAX_API_KEY。")
                
            return LLMConfig(api_key=api_key, base_url=base_url, model_name=model_name)

        elif provider == "deepseek":
            api_key = cfg.get("DEEPSEEK_API_KEY") or os.environ.get("DEEPSEEK_API_KEY")
            base_url = cfg.get("DEEPSEEK_BASE_URL") or os.environ.get("DEEPSEEK_BASE_URL") or "https://api.deepseek.com/v1"
            model_name = cfg.get("DEEPSEEK_MODEL_NAME") or os.environ.get("DEEPSEEK_MODEL_NAME") or "deepseek-reasoner"
            
            if not api_key:
                raise ValueError("DeepSeek API key 未配置。请在 assets/llm_api/config.json 或环境变量中设置 DEEPSEEK_API_KEY。")
                
            return LLMConfig(api_key=api_key, base_url=base_url, model_name=model_name)
            
        elif provider == "openai":
            api_key = cfg.get("OPENAI_API_KEY") or os.environ.get("OPENAI_API_KEY")
            base_url = cfg.get("OPENAI_BASE_URL") or cfg.get("OPENAI_API_BASE") or os.environ.get("OPENAI_BASE_URL")
            model_name = cfg.get("OPENAI_MODEL_NAME") or os.environ.get("OPENAI_MODEL_NAME") or "gpt-4o"
            
            if not api_key:
                raise ValueError("OpenAI API key 未配置。请在 assets/llm_api/config.json 或环境变量中设置 OPENAI_API_KEY。")
                
            return LLMConfig(api_key=api_key, base_url=base_url, model_name=model_name)

        else:
            raise ValueError(f"不支持的 LLM 提供商: {provider}。支持: minimax, deepseek, openai")

    @staticmethod
    def resolve_patent_provider(provider: str) -> ProviderCredential:
        """
        解析专利数据库配置
        优先级: 固定文件 > 环境变量
        """
        cfg = ConfigResolver._read_json_config(PATENT_DB_CONFIG_PATH)
        provider = provider.lower()

        if provider == "zhihuiya":
            client_id = cfg.get("ZHIHUIYA_CLIENT_ID") or cfg.get("zhihuiya_client_id") or os.environ.get("ZHIHUIYA_CLIENT_ID")
            client_secret = cfg.get("ZHIHUIYA_CLIENT_SECRET") or cfg.get("zhihuiya_client_secret") or os.environ.get("ZHIHUIYA_CLIENT_SECRET")
            if not client_id or not client_secret:
                raise ValueError("智慧芽 (Zhihuiya) 凭据未配置。请在 assets/patent_database_api/config.json 或环境变量中设置 ZHIHUIYA_CLIENT_ID / ZHIHUIYA_CLIENT_SECRET。")
            return ProviderCredential(client_id=client_id, client_secret=client_secret)

        elif provider == "lens":
            token = cfg.get("LENS_API_TOKEN") or cfg.get("lens_api_token") or os.environ.get("LENS_API_TOKEN")
            if not token:
                raise ValueError("Lens API token 未配置。请在 assets/patent_database_api/config.json 或环境变量中设置 LENS_API_TOKEN。")
            return ProviderCredential(token=token)

        elif provider == "epo":
            client_id = cfg.get("EPO_CONSUMER_KEY") or cfg.get("epo_consumer_key") or os.environ.get("EPO_CONSUMER_KEY")
            client_secret = cfg.get("EPO_CONSUMER_SECRET") or cfg.get("epo_consumer_secret") or os.environ.get("EPO_CONSUMER_SECRET")
            if not client_id or not client_secret:
                raise ValueError("EPO 凭据未配置。请在 assets/patent_database_api/config.json 或环境变量中设置 EPO_CONSUMER_KEY / EPO_CONSUMER_SECRET。")
            return ProviderCredential(client_id=client_id, client_secret=client_secret)

        elif provider == "baiten":
            # Baiten 客户端使用 app_key / app_secret 进行签名鉴权
            app_key = cfg.get("BAITEN_APP_KEY") or cfg.get("baiten_app_key") or os.environ.get("BAITEN_APP_KEY")
            app_secret = cfg.get("BAITEN_APP_SECRET") or cfg.get("baiten_app_secret") or os.environ.get("BAITEN_APP_SECRET")
            return ProviderCredential(client_id=app_key, client_secret=app_secret)

        else:
            raise ValueError(f"未知 API Provider: {provider}")
