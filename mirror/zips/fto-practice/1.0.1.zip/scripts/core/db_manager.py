import sqlite3
import json
import os
import logging
from typing import Dict, Any, List, Optional, Union
from datetime import datetime

logger = logging.getLogger(__name__)

class DatabaseManager:
    """
    负责管理专利项目的 SQLite 数据库连接与所有增删改查操作，
    采用项目级 Local DB 模式，极简4表设计：

    1. project_meta       - 全局配置表（永远只有1行，存靶子技术方案）
    2. patent_raw_data    - 检索底表（无脑存1500篇专利）
    3. step06_screening   - 初筛表（06步产生的新数据）
    4. step07_comparison  - 深度比对表（07步的比对结论）
    """

    def __init__(self, db_path: str = None):
        if not db_path:
            raise ValueError("db_path 必须提供，指向项目专属的 .db 文件")

        os.makedirs(os.path.dirname(os.path.abspath(db_path)), exist_ok=True)
        self.db_path = db_path
        self._init_db()

    def get_connection(self):
        conn = sqlite3.connect(self.db_path, timeout=15.0)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self):
        """初始化数据库表结构 - 极简5表设计"""
        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS "project_meta" (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                target_title TEXT,
                target_abstract TEXT,
                target_tech_solution TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        cursor.execute('INSERT OR IGNORE INTO "project_meta" (id) VALUES (1)')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS "patent_raw_data" (
                patent_id TEXT PRIMARY KEY,
                title TEXT,
                abstract TEXT,
                full_claims TEXT,
                source TEXT DEFAULT 'target_pool',
                node TEXT,
                application_number TEXT,
                application_date TEXT,
                publication_number TEXT,
                publication_date TEXT,
                assignees TEXT,
                inventors TEXT,
                ipc_classes TEXT,
                legal_status TEXT,
                raw_data TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        self._ensure_column(cursor, "patent_raw_data", "source", "TEXT DEFAULT 'target_pool'")
        self._ensure_column(cursor, "patent_raw_data", "node", "TEXT")

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS "patent_claims" (
                patent_id TEXT PRIMARY KEY,
                independent_claims TEXT,
                extracted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (patent_id) REFERENCES "patent_raw_data" (patent_id) ON DELETE CASCADE
            )
        ''')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS "step06_screening" (
                patent_id TEXT PRIMARY KEY,
                score INTEGER DEFAULT 0,
                is_passed INTEGER DEFAULT 0,
                node TEXT,
                reason TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (patent_id) REFERENCES "patent_raw_data" (patent_id) ON DELETE CASCADE
            )
        ''')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS "step07_comparison" (
                patent_id TEXT PRIMARY KEY,
                independent_claims TEXT,
                extracted_features TEXT,
                feature_matches TEXT,
                final_risk_conclusion TEXT,
                stage TEXT DEFAULT 'init',
                raw_llm_output TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (patent_id) REFERENCES "patent_raw_data" (patent_id) ON DELETE CASCADE
            )
        ''')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS "step05_eval_results" (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                round_id TEXT NOT NULL,
                patent_id TEXT NOT NULL,
                score INTEGER DEFAULT 0,
                is_noise INTEGER DEFAULT 1,
                reason TEXT,
                llm_provider TEXT,
                attempts INTEGER DEFAULT 1,
                error_type TEXT,
                status TEXT DEFAULT 'success',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(round_id, patent_id),
                FOREIGN KEY (patent_id) REFERENCES "patent_raw_data" (patent_id) ON DELETE CASCADE
            )
        ''')
        self._ensure_index(cursor, "idx_step05_results_round", 'CREATE INDEX "idx_step05_results_round" ON "step05_eval_results" (round_id)')
        self._ensure_index(cursor, "idx_step05_results_score", 'CREATE INDEX "idx_step05_results_score" ON "step05_eval_results" (score)')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS "step05_eval_metrics" (
                round_id TEXT PRIMARY KEY,
                query_text TEXT,
                hit_count INTEGER DEFAULT 0,
                sample_count INTEGER DEFAULT 0,
                evaluated_count INTEGER DEFAULT 0,
                non_noise_count INTEGER DEFAULT 0,
                precision REAL DEFAULT 0.0,
                llm_provider TEXT,
                retry_histogram TEXT,
                error_type_histogram TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        conn.commit()
        conn.close()

    def _ensure_column(self, cursor: sqlite3.Cursor, table_name: str, column_name: str, column_def: str):
        """为老库补齐新增字段，避免升级失败。"""
        cursor.execute(f'PRAGMA table_info("{table_name}")')
        columns = {row[1] for row in cursor.fetchall()}
        if column_name not in columns:
            cursor.execute(f'ALTER TABLE "{table_name}" ADD COLUMN {column_name} {column_def}')

    def _ensure_index(self, cursor: sqlite3.Cursor, index_name: str, ddl: str):
        cursor.execute("SELECT name FROM sqlite_master WHERE type='index' AND name = ?", (index_name,))
        if not cursor.fetchone():
            cursor.execute(ddl)

    def _migrate_old_db(self, conn: sqlite3.Connection):
        """
        迁移旧数据库结构（兼容旧工作区）
        """
        cursor = conn.cursor()

        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [r[0] for r in cursor.fetchall()]

        if "06_patents" in tables:
            logger.info("检测到旧数据库结构，开始迁移...")
            cursor.execute('SELECT publication_number, application_number, title, abstract, assignees, application_date, publication_date, claims_text, legal_status, raw_data FROM "06_patents"')
            old_patents = cursor.fetchall()

            for row in old_patents:
                pub_num = row[0]
                bibliography = {
                    "application_number": row[1],
                    "title": row[2],
                    "abstract": row[3],
                    "assignees": json.loads(row[4]) if row[4] else [],
                    "application_date": row[5],
                    "publication_date": row[6],
                    "legal_status": row[8]
                }
                cursor.execute('''
                    INSERT OR REPLACE INTO "patent_raw_data" (patent_id, title, abstract, full_claims, bibliography, raw_data)
                    VALUES (?, ?, ?, ?, ?, ?)
                ''', (pub_num, row[2], row[3], row[7], json.dumps(bibliography, ensure_ascii=False), row[9]))

            cursor.execute('SELECT publication_number, risk_score, assessment_summary FROM "07_patent_assessments"')
            old_assessments = cursor.fetchall()
            for row in old_assessments:
                cursor.execute('''
                    INSERT OR REPLACE INTO "step06_screening" (patent_id, score, is_passed, reason)
                    VALUES (?, ?, ?, ?)
                ''', (row[0], row[1], 1 if row[1] and row[1] >= 1 else 0, row[2]))

            logger.info(f"迁移完成，共迁移 {len(old_patents)} 条专利记录")

    def save_project_meta(self, target_title: str = None, target_abstract: str = None, target_tech_solution: str = None):
        """保存全局配置（靶子技术方案）"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE "project_meta" SET
                target_title = COALESCE(?, target_title),
                target_abstract = COALESCE(?, target_abstract),
                target_tech_solution = COALESCE(?, target_tech_solution),
                updated_at = CURRENT_TIMESTAMP
            WHERE id = 1
        ''', (target_title, target_abstract, target_tech_solution))
        conn.commit()
        conn.close()

    def get_project_meta(self) -> Optional[Dict[str, Any]]:
        """获取全局配置"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM "project_meta" WHERE id = 1')
        row = cursor.fetchone()
        conn.close()
        if not row:
            return None
        return dict(row)

    def save_patents(self, patents: List[Dict[str, Any]], source: str = "target_pool", node: str = None):
        """批量保存专利到底表"""
        conn = self.get_connection()
        cursor = conn.cursor()

        for p in patents:
            patent_id = p.get("patent_id") or p.get("publication_number") or p.get("公开号")
            if not patent_id:
                continue

            title = p.get("title", "")
            abstract = p.get("abstract", "")
            full_claims = p.get("full_claims") or p.get("claims_text") or p.get("权利要求", "")

            application_number = p.get("application_number", "")
            application_date = p.get("application_date", "")
            publication_number = p.get("publication_number", "") or patent_id
            publication_date = p.get("publication_date", "")

            assignees = p.get("assignees", [])
            if isinstance(assignees, list):
                assignees = json.dumps(assignees, ensure_ascii=False)
            inventors = p.get("inventors", [])
            if isinstance(inventors, list):
                inventors = json.dumps(inventors, ensure_ascii=False)
            ipc_classes = p.get("ipc_classes", [])
            if isinstance(ipc_classes, list):
                ipc_classes = json.dumps(ipc_classes, ensure_ascii=False)
            legal_status = p.get("legal_status", "")

            raw_data = p.get("raw_data")
            if isinstance(raw_data, dict):
                raw_data_json = json.dumps(raw_data, ensure_ascii=False)
            else:
                raw_data_json = raw_data or "{}"

            cursor.execute('''
                INSERT INTO "patent_raw_data" (patent_id, title, abstract, full_claims, source, node, application_number, application_date, publication_number, publication_date, assignees, inventors, ipc_classes, legal_status, raw_data)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(patent_id) DO UPDATE SET
                    title=COALESCE(excluded.title, title),
                    abstract=COALESCE(excluded.abstract, abstract),
                    full_claims=COALESCE(excluded.full_claims, full_claims),
                    source=COALESCE(excluded.source, source),
                    node=COALESCE(excluded.node, node),
                    application_number=COALESCE(excluded.application_number, application_number),
                    application_date=COALESCE(excluded.application_date, application_date),
                    publication_number=COALESCE(excluded.publication_number, publication_number),
                    publication_date=COALESCE(excluded.publication_date, publication_date),
                    assignees=COALESCE(excluded.assignees, assignees),
                    inventors=COALESCE(excluded.inventors, inventors),
                    ipc_classes=COALESCE(excluded.ipc_classes, ipc_classes),
                    legal_status=COALESCE(excluded.legal_status, legal_status),
                    raw_data=COALESCE(excluded.raw_data, raw_data),
                    updated_at=CURRENT_TIMESTAMP
            ''', (patent_id, title, abstract, full_claims, source, node, application_number, application_date, publication_number, publication_date, assignees, inventors, ipc_classes, legal_status, raw_data_json))

        conn.commit()
        conn.close()

    def get_all_patents(self) -> List[Dict[str, Any]]:
        """获取所有专利底表数据"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM "patent_raw_data"')
        rows = cursor.fetchall()
        conn.close()
        result = []
        for row in rows:
            item = dict(row)
            for json_field in ["assignees", "inventors", "ipc_classes"]:
                if item.get(json_field):
                    try:
                        item[json_field] = json.loads(item[json_field])
                    except:
                        pass
            if item.get("raw_data"):
                try:
                    item["raw_data"] = json.loads(item["raw_data"])
                except:
                    pass
            result.append(item)
        return result

    def save_patent_claims(self, patent_id: str, independent_claims: str):
        """保存专利独立权利要求到 patent_claims 表"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO "patent_claims" (patent_id, independent_claims)
            VALUES (?, ?)
            ON CONFLICT(patent_id) DO UPDATE SET
                independent_claims=excluded.independent_claims,
                extracted_at=CURRENT_TIMESTAMP
        ''', (patent_id, independent_claims))
        conn.commit()
        conn.close()

    def get_patent_claims(self, patent_id: str) -> Optional[Dict[str, Any]]:
        """获取专利独立权利要求"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM "patent_claims" WHERE patent_id = ?', (patent_id,))
        row = cursor.fetchone()
        conn.close()
        if not row:
            return None
        return dict(row)

    def get_patent_by_id(self, patent_id: str) -> Optional[Dict[str, Any]]:
        """根据 patent_id 获取单条专利"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM "patent_raw_data" WHERE patent_id = ?', (patent_id,))
        row = cursor.fetchone()
        conn.close()
        if not row:
            return None
        item = dict(row)
        for json_field in ["assignees", "inventors", "ipc_classes"]:
            if item.get(json_field):
                try:
                    item[json_field] = json.loads(item[json_field])
                except:
                    pass
        if item.get("raw_data"):
            try:
                item["raw_data"] = json.loads(item["raw_data"])
            except:
                pass
        return item

    def save_screening_result(self, patent_id: str, score: int, is_passed: bool, node: str = None, reason: str = None):
        """保存06初筛结果"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO "step06_screening" (patent_id, score, is_passed, node, reason)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(patent_id) DO UPDATE SET
                score=excluded.score,
                is_passed=excluded.is_passed,
                node=COALESCE(excluded.node, node),
                reason=COALESCE(excluded.reason, reason),
                updated_at=CURRENT_TIMESTAMP
        ''', (patent_id, score, 1 if is_passed else 0, node, reason))
        conn.commit()
        conn.close()

    def get_screening_results(self, is_passed: bool = None) -> List[Dict[str, Any]]:
        """获取初筛结果"""
        conn = self.get_connection()
        cursor = conn.cursor()
        if is_passed is None:
            cursor.execute('SELECT * FROM "step06_screening"')
        else:
            cursor.execute('SELECT * FROM "step06_screening" WHERE is_passed = ?', (1 if is_passed else 0,))
        rows = cursor.fetchall()
        conn.close()
        return [dict(row) for row in rows]

    def save_comparison_result(
        self,
        patent_id: str,
        independent_claims: str = None,
        extracted_features: str = None,
        feature_matches: List[Dict] = None,
        final_risk_conclusion: str = None,
        stage: str = None,
        raw_llm_output: str = None
    ):
        """保存07深度比对结果，支持断点续传"""
        conn = self.get_connection()
        cursor = conn.cursor()
        feature_matches_json = json.dumps(feature_matches, ensure_ascii=False) if feature_matches else None
        cursor.execute('''
            INSERT INTO "step07_comparison" (patent_id, independent_claims, extracted_features, feature_matches, final_risk_conclusion, stage, raw_llm_output)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(patent_id) DO UPDATE SET
                independent_claims=COALESCE(excluded.independent_claims, independent_claims),
                extracted_features=COALESCE(excluded.extracted_features, extracted_features),
                feature_matches=COALESCE(excluded.feature_matches, feature_matches),
                final_risk_conclusion=COALESCE(excluded.final_risk_conclusion, final_risk_conclusion),
                stage=COALESCE(excluded.stage, stage),
                raw_llm_output=COALESCE(excluded.raw_llm_output, raw_llm_output),
                updated_at=CURRENT_TIMESTAMP
        ''', (patent_id, independent_claims, extracted_features, feature_matches_json, final_risk_conclusion, stage, raw_llm_output))
        conn.commit()
        conn.close()

    def get_comparison_results(self, patent_id: str = None) -> List[Dict[str, Any]]:
        """获取深度比对结果"""
        conn = self.get_connection()
        cursor = conn.cursor()
        if patent_id:
            cursor.execute('SELECT * FROM "step07_comparison" WHERE patent_id = ?', (patent_id,))
        else:
            cursor.execute('SELECT * FROM "step07_comparison"')
        rows = cursor.fetchall()
        conn.close()
        result = []
        for row in rows:
            item = dict(row)
            if item.get("feature_matches"):
                try:
                    item["feature_matches"] = json.loads(item["feature_matches"])
                except:
                    pass
            result.append(item)
        return result

    def get_patents_for_fto(self, limit: int = 100) -> List[Dict[str, Any]]:
        """
        获取待进行FTO比对的专利（用于07步）
        优先获取 step06_screening 中 is_passed=1 的专利，如果没有则获取全部
        """
        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute('SELECT COUNT(*) FROM "step06_screening" WHERE is_passed = 1')
        passed_count = cursor.fetchone()[0]

        if passed_count > 0:
            cursor.execute('''
                SELECT p.* FROM "patent_raw_data" p
                JOIN "step06_screening" s ON p.patent_id = s.patent_id
                WHERE s.is_passed = 1
                LIMIT ?
            ''', (limit,))
        else:
            cursor.execute('SELECT * FROM "patent_raw_data" LIMIT ?', (limit,))

        rows = cursor.fetchall()
        conn.close()
        result = []
        for row in rows:
            item = dict(row)
            if item.get("bibliography"):
                try:
                    item["bibliography"] = json.loads(item["bibliography"])
                except:
                    pass
            result.append(item)
        return result

    def get_fto_pending_patents(self, limit: int = 100) -> List[Dict[str, Any]]:
        """
        获取尚未进行FTO比对的专利（07步断点续跑用）
        """
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT p.* FROM "patent_raw_data" p
            LEFT JOIN "step07_comparison" c ON p.patent_id = c.patent_id
            WHERE c.patent_id IS NULL
            LIMIT ?
        ''', (limit,))
        rows = cursor.fetchall()
        conn.close()
        result = []
        for row in rows:
            item = dict(row)
            if item.get("bibliography"):
                try:
                    item["bibliography"] = json.loads(item["bibliography"])
                except:
                    pass
            result.append(item)
        return result

    def get_step1_done_step2_pending_patents(self, limit: int = 100) -> List[Dict[str, Any]]:
        """
        获取已完成 Step1（特征提取）但未完成 Step2（侵权比对）的专利，用于断点续传
        """
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT p.*, c.extracted_features, c.independent_claims, c.stage
            FROM "patent_raw_data" p
            JOIN "step07_comparison" c ON p.patent_id = c.patent_id
            WHERE c.extracted_features IS NOT NULL
              AND (c.feature_matches IS NULL OR c.feature_matches = '' OR c.feature_matches = '[]')
            LIMIT ?
        ''', (limit,))
        rows = cursor.fetchall()
        conn.close()
        result = []
        for row in rows:
            item = dict(row)
            if item.get("extracted_features"):
                try:
                    item["extracted_features"] = json.loads(item["extracted_features"])
                except:
                    pass
            if item.get("bibliography"):
                try:
                    item["bibliography"] = json.loads(item["bibliography"])
                except:
                    pass
            result.append(item)
        return result

    def clear_screening_results(self):
        """清空初筛结果"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('DELETE FROM "step06_screening"')
        conn.commit()
        conn.close()

    def clear_comparison_results(self):
        """清空深度比对结果"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('DELETE FROM "step07_comparison"')
        conn.commit()
        conn.close()

    def save_step05_eval_result(
        self,
        round_id: str,
        patent_id: str,
        score: int,
        reason: str = "",
        llm_provider: str = "",
        attempts: int = 1,
        error_type: Optional[str] = None,
        status: str = "success",
    ):
        conn = self.get_connection()
        cursor = conn.cursor()
        safe_score = int(score or 0)
        safe_attempts = max(1, int(attempts or 1))
        cursor.execute(
            '''
            INSERT INTO "step05_eval_results" (round_id, patent_id, score, is_noise, reason, llm_provider, attempts, error_type, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(round_id, patent_id) DO UPDATE SET
                score=excluded.score,
                is_noise=excluded.is_noise,
                reason=excluded.reason,
                llm_provider=excluded.llm_provider,
                attempts=excluded.attempts,
                error_type=excluded.error_type,
                status=excluded.status,
                updated_at=CURRENT_TIMESTAMP
            ''',
            (
                str(round_id),
                str(patent_id),
                safe_score,
                1 if safe_score <= 0 else 0,
                reason,
                llm_provider,
                safe_attempts,
                error_type,
                status,
            ),
        )
        conn.commit()
        conn.close()

    def get_step05_eval_results(self, round_id: str) -> List[Dict[str, Any]]:
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute(
            'SELECT * FROM "step05_eval_results" WHERE round_id = ? ORDER BY created_at ASC',
            (str(round_id),),
        )
        rows = cursor.fetchall()
        conn.close()
        return [dict(row) for row in rows]

    def save_step05_eval_metrics(
        self,
        round_id: str,
        query_text: str,
        hit_count: int,
        sample_count: int,
        evaluated_count: int,
        non_noise_count: int,
        precision: float,
        llm_provider: str = "",
        retry_histogram: Optional[Union[Dict[int, int], Dict[str, int]]] = None,
        error_type_histogram: Optional[Dict[str, int]] = None,
    ):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute(
            '''
            INSERT INTO "step05_eval_metrics" (
                round_id, query_text, hit_count, sample_count, evaluated_count,
                non_noise_count, precision, llm_provider, retry_histogram, error_type_histogram
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(round_id) DO UPDATE SET
                query_text=excluded.query_text,
                hit_count=excluded.hit_count,
                sample_count=excluded.sample_count,
                evaluated_count=excluded.evaluated_count,
                non_noise_count=excluded.non_noise_count,
                precision=excluded.precision,
                llm_provider=excluded.llm_provider,
                retry_histogram=excluded.retry_histogram,
                error_type_histogram=excluded.error_type_histogram,
                updated_at=CURRENT_TIMESTAMP
            ''',
            (
                str(round_id),
                query_text or "",
                int(hit_count or 0),
                int(sample_count or 0),
                int(evaluated_count or 0),
                int(non_noise_count or 0),
                float(precision or 0.0),
                llm_provider,
                json.dumps(retry_histogram or {}, ensure_ascii=False),
                json.dumps(error_type_histogram or {}, ensure_ascii=False),
            ),
        )
        conn.commit()
        conn.close()

    def get_step05_eval_metrics(self, round_id: Optional[str] = None) -> List[Dict[str, Any]]:
        conn = self.get_connection()
        cursor = conn.cursor()
        if round_id is None:
            cursor.execute('SELECT * FROM "step05_eval_metrics" ORDER BY created_at DESC')
        else:
            cursor.execute('SELECT * FROM "step05_eval_metrics" WHERE round_id = ?', (str(round_id),))
        rows = cursor.fetchall()
        conn.close()
        result = []
        for row in rows:
            item = dict(row)
            for json_field in ("retry_histogram", "error_type_histogram"):
                if item.get(json_field):
                    try:
                        item[json_field] = json.loads(item[json_field])
                    except Exception:
                        pass
            result.append(item)
        return result

    def clear_step05_round(self, round_id: str):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('DELETE FROM "step05_eval_results" WHERE round_id = ?', (str(round_id),))
        cursor.execute('DELETE FROM "step05_eval_metrics" WHERE round_id = ?', (str(round_id),))
        conn.commit()
        conn.close()

    def flush_wal(self):
        """强制将 WAL 缓存同步到主数据库"""
        try:
            conn = sqlite3.connect(self.db_path)
            conn.isolation_level = None
            cursor = conn.execute("PRAGMA wal_checkpoint(TRUNCATE);")
            result = cursor.fetchone()
            if result and result[0] == 1:
                print("⚠️ WAL 刷新被部分阻塞")
            conn.close()
        except Exception as e:
            print(f"⚠️ WAL 刷新异常: {e}")
