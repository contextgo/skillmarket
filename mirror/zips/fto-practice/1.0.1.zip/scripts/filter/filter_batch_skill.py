import os
import sys
import json
import logging
import argparse
import asyncio

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from core.llm_client import LLMClient
from core.config_resolver import ConfigResolver
from core.db_manager import DatabaseManager
from core.llm_batch.job_runner import BatchJobRunner
from core.llm_batch.logging_manager import BatchLoggingManager
from core.llm_batch.parse_pipeline import ParsePipeline
from core.llm_batch.retry_executor import execute_with_retry
from core.llm_batch.transport import LLMTransport
from repository.patent_repository import PatentRepository
from filter.adapters.step6_adapter import Step6Adapter

logger = logging.getLogger(__name__)

def build_llm_client_from_args(args) -> LLMClient:
    creds = ConfigResolver.resolve_llm(args.llm_provider)
    logger.info(f"使用 {args.llm_provider} 模型: {creds.model_name}")
    return LLMClient(api_key=creds.api_key, base_url=creds.base_url, actual_model=creds.model_name)

async def main():
    parser = argparse.ArgumentParser(description="Patent Relevance Filter Skill: 批量利用大模型进行专利相关性过滤和打分（纯DB模式）")
    parser.add_argument("--llm_provider", type=str, default="minimax", choices=["minimax", "deepseek"], help="LLM提供商 (默认: minimax)")
    parser.add_argument("--db_path", type=str, required=True, help="SQLite 数据库文件路径")
    parser.add_argument("--features_file", type=str, required=True, help="包含待比对技术特征的文本文件路径")
    parser.add_argument("--taxonomy_file", type=str, default="", help="包含分类节点列表的JSON文件路径(可选)")
    parser.add_argument("--limit", type=int, default=50, help="处理专利数量上限")
    parser.add_argument("--concurrency", type=int, default=10, help="并发线程数")
    args = parser.parse_args()

    logging_manager = BatchLoggingManager()
    log_file_path = logging_manager.setup_for_step("step6_screening", args.db_path)

    print(f"日志将输出至: {log_file_path}")

    if not os.path.exists(args.features_file):
        logger.error(f"特征文件不存在: {args.features_file}")
        print(f"特征文件不存在: {args.features_file}")
        return

    with open(args.features_file, 'r', encoding='utf-8') as f:
        features = f.read().strip()

    if not features:
        logger.error("特征文件内容为空。")
        print("特征文件内容为空。")
        return

    taxonomy_nodes = []
    if args.taxonomy_file and os.path.exists(args.taxonomy_file):
        with open(args.taxonomy_file, 'r', encoding='utf-8') as f:
            taxonomy_nodes = json.load(f)

    limit = args.limit
    concurrency_limit = args.concurrency

    db_manager = DatabaseManager(db_path=args.db_path)
    repo = PatentRepository(db_manager=db_manager)
    patents = db_manager.get_all_patents()

    if not patents:
        logger.error("数据库中未找到专利数据。请先导入专利数据到 patent_raw_data 表。")
        print("数据库中未找到专利数据。请先导入专利数据到 patent_raw_data 表。")
        return

    jobs = []
    for p in patents:
        patent_id = p.get("patent_id")
        claims_data = db_manager.get_patent_claims(patent_id) if patent_id else None
        jobs.append({
            "patent_id": p.get("patent_id"),
            "title": p.get("title", ""),
            "independent_claims": (claims_data or {}).get("independent_claims", ""),
        })

    if limit and len(jobs) > limit:
        jobs = jobs[:limit]

    logger.info(f"共加载 {len(jobs)} 条待评估专利，将使用 {concurrency_limit} 个并发线程。")
    print(f"📋 共加载 {len(jobs)} 条待评估专利 | ⚡ 并发上限: {concurrency_limit}")

    try:
        llm_client = build_llm_client_from_args(args)
    except ValueError as e:
        logger.error(str(e))
        print(str(e))
        return

    transport = LLMTransport(llm_client=llm_client)
    parse_pipeline = ParsePipeline()
    adapter = Step6Adapter(repo=repo, features=features, taxonomy_nodes=taxonomy_nodes)
    runner = BatchJobRunner(worker_count=concurrency_limit)
    stats_ref = {"success": 0, "skipped": 0, "failed": 0}

    async def run_spinner():
        spinner_chars = ['-', '\\', '|', '/']
        idx = 0
        try:
            while True:
                done = stats_ref["success"] + stats_ref["skipped"] + stats_ref["failed"]
                total = len(jobs)
                sys.stdout.write(
                    f"\r{spinner_chars[idx]} 进度: {done}/{total} "
                    f"(成功: {stats_ref['success']}, 失败: {stats_ref['failed']})"
                )
                sys.stdout.flush()
                idx = (idx + 1) % len(spinner_chars)
                await asyncio.sleep(0.1)
        except asyncio.CancelledError:
            done = stats_ref["success"] + stats_ref["skipped"] + stats_ref["failed"]
            total = len(jobs)
            sys.stdout.write(
                f"\r✅ 进度: {done}/{total} "
                f"(成功: {stats_ref['success']}, 失败: {stats_ref['failed']})\n"
            )
            sys.stdout.flush()

    spinner_task = asyncio.create_task(run_spinner())

    try:
        async def processor(job_ctx: dict) -> dict:
            _, result = await execute_with_retry(
                adapter=adapter,
                ctx=job_ctx,
                transport=transport,
                parse_pipeline=parse_pipeline,
                max_attempts=2,
            )
            return result

        def progress_callback(run_stats) -> None:
            stats_ref["success"] = run_stats.success_count
            stats_ref["skipped"] = run_stats.skipped_count
            stats_ref["failed"] = run_stats.failed_count

        run_stats = await runner.run(jobs=jobs, processor=processor, progress_callback=progress_callback)
    finally:
        spinner_task.cancel()
        try:
            await spinner_task
        except asyncio.CancelledError:
            pass

    logger.info("🎉 批量过滤打分任务结束。")
    logger.info(f"   ✅ 成功: {run_stats.success_count} 条")
    logger.info(f"   ⚠️ 跳过: {run_stats.skipped_count} 条")
    logger.info(f"   ❌ 失败: {run_stats.failed_count} 条")
    logger.info(f"   🔁 重试分布: {run_stats.retry_histogram}")
    logger.info(f"   🧭 错误分类: {run_stats.error_type_histogram}")
    print(
        f"\n🎉 批量过滤打分任务结束。✅ 成功: {run_stats.success_count} 条, "
        f"❌ 失败: {run_stats.failed_count} 条，结果已保存至数据库。"
    )

if __name__ == "__main__":
    asyncio.run(main())
