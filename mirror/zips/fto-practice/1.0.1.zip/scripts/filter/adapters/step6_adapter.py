from __future__ import annotations

from typing import Any

from core.models.patent_data import RelevanceResult4Tier


class Step6Adapter:
    response_model = RelevanceResult4Tier
    job_type = "step6_screening"
    temperature = 0.1
    failure_status = "failed"

    def __init__(self, repo, features: str, taxonomy_nodes: list[str] | None = None):
        self.repo = repo
        self.features = features
        self.taxonomy_nodes = taxonomy_nodes or []

    def build_prompt(self, ctx: dict[str, Any]) -> str:
        patent_id = str(ctx.get("patent_id") or ctx.get("publication_number") or "").strip()
        patent_title = str(ctx.get("title") or "").strip()
        independent_claims = str(ctx.get("independent_claims") or "").strip()
        if not independent_claims or len(independent_claims) < 10:
            raise ValueError(f"专利 {patent_id} ({patent_title}) 的独立权利要求文本无效或过短。")
        return f"""你是一位资深的专利代理人和FTO侵权分析专家。你的任务是根据用户提供的【我方产品核心技术特征】，判断目标专利的【独立权利要求】是否对我方产品构成侵权风险。
【我方产品核心技术特征】
{self.features}
【可选的技术分解节点】（用于归类相关专利）
{', '.join(self.taxonomy_nodes) if self.taxonomy_nodes else '未提供'}
【输出要求】
- 必须严格返回包含 score、reason、node 三个字段的JSON
- score 必须是整数类型（0、1、2 或 3），不得使用字符串（例如 "0"）
- reason 必须在50字以内
- node 填写 taxonomy_nodes 中最匹配的分类，或"其他"
请评估以下专利是否对我方产品构成侵权风险：
专利名称（参考）：{patent_title}
专利公开号：{patent_id}
专利独立权利要求：
{independent_claims}
"""

    def get_cleanser(self):
        return None

    def augment_retry_prompt(self, base_prompt: str, attempt: int, error: Exception | None) -> str:
        return base_prompt + "\n\n注意：请仅返回合法 JSON，字段必须为 score/reason/node。"

    def on_success(self, ctx: dict[str, Any], parsed: RelevanceResult4Tier | dict[str, Any], raw_text: str, stats: dict[str, Any]) -> None:
        patent_id = str(ctx.get("patent_id") or ctx.get("publication_number") or "").strip()
        result = parsed.model_dump() if hasattr(parsed, "model_dump") else dict(parsed)
        self.repo.save_patent_assessment(
            publication_number=patent_id,
            relevance_score=result.get("score", 0),
            node=result.get("node", "其他"),
            reason=result.get("reason", ""),
        )

    def on_failure(self, ctx: dict[str, Any], error: Exception, raw_text: str | None, stats: dict[str, Any]) -> None:
        patent_id = str(ctx.get("patent_id") or ctx.get("publication_number") or "").strip()
        self.repo.save_patent_assessment(
            publication_number=patent_id,
            relevance_score=0,
            node="其他",
            reason=str(error)[:50],
        )
