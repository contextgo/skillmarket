from __future__ import annotations

import argparse
import asyncio
import json
import logging
import os
import re
import sys
from typing import Dict

from pydantic import BaseModel, Field

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), ".")))
from core.config_resolver import ConfigResolver
from core.llm_client import LLMClient
from step05.prompting.provider_rules import resolve_provider_rule

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


def build_llm_client_from_provider(llm_provider: str) -> LLMClient:
    creds = ConfigResolver.resolve_llm(llm_provider)
    return LLMClient(api_key=creds.api_key, base_url=creds.base_url, actual_model=creds.model_name)

def parse_query_file(file_path: str) -> tuple[Dict[str, str], str]:
    """解析包含 S0, S1 等的多行检索式文件"""
    blocks = {}
    final_query = ""
    
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
        
    # 如果只有一行，直接返回
    if '\n' not in content.strip():
        return blocks, content.strip()
        
    # 解析多行格式 (例如：检索式S0:\nAUTHORITY:...)
    pattern = r"检索式(S\d+):\s*\n(.*?)(?=\n\n检索式|\Z)"
    matches = re.finditer(pattern, content, re.DOTALL)
    
    for match in matches:
        key = match.group(1)
        val = match.group(2).strip()
        blocks[key] = val
        
    # 如果没有匹配到标准格式，尝试按行读取，最后一行作为 query
    if not blocks:
        lines = [line.strip() for line in content.split('\n') if line.strip()]
        if lines:
            return blocks, lines[-1]
            
    # 查找最终合并表达式（通常是最大的数字，如 S9）
    if blocks:
        max_s = max(blocks.keys(), key=lambda x: int(x[1:]))
        final_query = blocks[max_s]
        
    return blocks, final_query

def expand_query(query_expr: str, blocks: Dict[str, str]) -> str:
    """将包含 (S0) AND (S1) 的表达式展开为完整的字符串"""
    if not blocks:
        return query_expr
        
    result = query_expr
    for key, val in sorted(blocks.items(), key=lambda x: int(x[0][1:]), reverse=True):
        # 替换 (S0) 为 (val)
        result = result.replace(f"({key})", f"({val})")
        # 替换 S0 为 val (没有括号的情况)
        result = re.sub(rf"\b{key}\b", f"({val})", result)
        
    return result

def validate_query(query: str, provider: str) -> tuple[bool, str]:
    if not query or not query.strip():
        return False, "检索式不能为空"
    
    # 1. 检查括号是否匹配
    stack = []
    for char in query:
        if char == '(':
            stack.append(char)
        elif char == ')':
            if not stack:
                return False, "存在未闭合的右括号 ')'"
            stack.pop()
    if stack:
        return False, "存在未闭合的左括号 '('"
        
    # 2. 检查引号是否匹配
    if query.count('"') % 2 != 0:
        return False, "存在未闭合的双引号 '\"'"
        
    # 3. 针对数据库的特定检查 (例如 Lens 不支持 TAC:，使用 title:, abstract:, ALL:)
    if provider.lower() == 'lens':
        if "TAC:" in query:
            return False, "Lens 数据库不支持 TAC: 字段，请使用 title:, abstract: 或 ALL:"
            
    return True, "验证通过"

class OptimizationResult(BaseModel):
    status_analysis: str = Field(
        description="一、 现状分析与问题诊断：评估当前指标，分析噪音专利引入的原因，或命中为0的原因。"
    )
    optimization_strategy: str = Field(
        description="二、 优化策略：明确优先级（如提升查准率、或挽救查全率/解决0命中），提出核心假设，制定执行方案。"
    )
    specific_modification: str = Field(
        description="三、 具体修改内容：详细列出关键词的增减、分类号的调整以及逻辑连接词的变更。"
    )
    analysis_and_justification: str = Field(
        description="四、 分析与理由：解释修改原因并预测指标走向，确保符合逐步迭代原则。"
    )
    optimized_blocks: Dict[str, str] = Field(
        description="优化后的各个模块字典，如 {'S0': '...', 'S1': '...'}。如果是单行检索式，返回 {'query': '...'}"
    )
    final_expression: str = Field(
        description="优化后的最终组装表达式，如 '(S0) AND ((S1) OR (S2))'。如果是单行检索式，这里留空或填写组装后的字符串"
    )

def _build_optimizer_prompt(provider: str) -> str:
    rule = resolve_provider_rule(provider)
    fallback_notice = ""
    if rule.fallback:
        fallback_notice = "提示：provider 未识别，已降级到通用布尔规则，请优先保证语法可执行。"
    return f"""
你是一个资深的专利检索优化专家。请基于当前命中数与查准率迭代优化检索式。

【核心KPI】
1. precision >= 0.5
2. 命中数量在保证查准率前提下尽量提升（上限 8000）

【策略约束】
- precision 偏低：收紧，剔除噪音词与噪音分类号。
- 命中为0或过低：放宽，减少强 AND 约束，保留核心主干。
- 输出保持数据库可执行语法，先可执行再复杂。

【provider 路由】
provider={provider}
{rule.syntax_rules}
{fallback_notice}

【返回格式】
必须返回 JSON，字段固定为：
status_analysis, optimization_strategy, specific_modification,
analysis_and_justification, optimized_blocks, final_expression
"""


async def optimize_query_with_llm(
    llm_client: LLMClient,
    current_blocks: Dict[str, str],
    current_expr: str,
    hit_count: int,
    precision: float,
    noise_samples: list,
    features: str,
    provider: str,
) -> tuple[Dict[str, str], str, str]:
    noise_text = ""
    for idx, sample in enumerate(noise_samples[:3]):  # 只取前3个噪音样本避免超出 token
        snippet = sample.get("claims_text", "")[:500]
        if not snippet:
            snippet = f"patent_id={sample.get('patent_id', '')}, reason={sample.get('reason', '')}"
        noise_text += f"噪音样本 {idx+1}:\n{snippet}\n"

    # 将 blocks 格式化为字符串展示给大模型
    blocks_str = ""
    if current_blocks:
        for k, v in current_blocks.items():
            blocks_str += f"{k}: {v}\n"
    else:
        blocks_str = f"query: {current_expr}\n"

    system_prompt = _build_optimizer_prompt(provider)
    
    user_prompt = f"""
    【目标核心特征】：
    {features}
    
    【当前检索式模块】：
    {blocks_str}
    【当前组装表达式】：
    {current_expr}
    
    【当前指标】：
    命中数：{hit_count}
    查准率：{precision * 100:.1f}%
    
    【噪音样本片段】：
    {noise_text if noise_text else "无"}
    
    请输出你的思考过程、优化后的模块和组装表达式：
    """
    
    max_retries = 3
    last_error = ""
    
    for attempt in range(max_retries):
        current_prompt = f"{system_prompt}\n\n{user_prompt}"
        if attempt > 0:
            current_prompt += f"\n\n注意：上一轮生成的检索式存在语法错误：{last_error}\n请修正该错误并重新生成。"
            
        try:
            response, reasoning = await llm_client.generate_structured_data_async(
                prompt=current_prompt,
                response_model=OptimizationResult,
                temperature=0.7
            )
            
            new_blocks = response.optimized_blocks
            new_expr = response.final_expression
            
            full_strategy = f"【一、现状分析】\n{response.status_analysis}\n\n【二、优化策略】\n{response.optimization_strategy}\n\n【三、具体修改】\n{response.specific_modification}\n\n【四、分析与理由】\n{response.analysis_and_justification}"
            
            logger.info(f"💡 LLM 思考与策略:\n{full_strategy}")
            
            # 兼容单行处理
            if 'query' in new_blocks and not new_expr:
                expanded_query = new_blocks['query']
            else:
                expanded_query = expand_query(new_expr, new_blocks)
            
            is_valid, error_msg = validate_query(expanded_query, provider)
            if is_valid:
                return new_blocks, new_expr, f"{full_strategy}\n\n【API Reasoning Content】\n{reasoning}"
            else:
                logger.warning(f"LLM 生成的检索式语法不合法 ({error_msg}): {expanded_query}")
                last_error = error_msg
        except Exception as e:
            logger.error(f"LLM 优化检索式失败: {e}")
            last_error = str(e)
            
    logger.error("达到最大重试次数，LLM 仍未能生成合法的检索式。")
    return current_blocks, current_expr, ""

from importlib.util import module_from_spec, spec_from_file_location


def load_sample_evaluate_module():
    import os

    script_path = os.path.join(os.path.dirname(__file__), '04_sample_evaluate.py')
    spec = spec_from_file_location("sample_evaluate", script_path)
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

sample_evaluate = load_sample_evaluate_module()
run_sample_evaluate = sample_evaluate.run_sample_evaluate

async def main():
    parser = argparse.ArgumentParser(description="自动化检索式迭代优化 Agent")
    parser.add_argument("--query_file", type=str, required=True, help="包含初始检索式的文件路径")
    parser.add_argument("--features_file", type=str, required=True, help="核心特征文件路径")
    parser.add_argument("--provider", type=str, default="lens", help="数据库提供商")
    parser.add_argument("--llm_provider", type=str, required=True, choices=["minimax", "deepseek", "openai"], help="LLM 提供商")
    parser.add_argument("--db_path", type=str, required=True, help="项目唯一数据库路径")
    parser.add_argument("--output_dir", type=str, default="output", help="输出目录")
    parser.add_argument("--max_iterations", type=int, default=5, help="最大迭代次数")
    parser.add_argument("--target_precision", type=float, default=0.5, help="目标查准率 (0-1)")
    
    args = parser.parse_args()
    os.makedirs(args.output_dir, exist_ok=True)
    
    with open(args.query_file, 'r', encoding='utf-8') as f:
        current_query = f.read().strip()
        
    with open(args.features_file, 'r', encoding='utf-8') as f:
        features = f.read().strip()
        
    llm_client = build_llm_client_from_provider(args.llm_provider)
    
    current_blocks, current_expr = parse_query_file(args.query_file)
    if 'query' in current_blocks and not current_expr:
        best_query = current_blocks['query']
    else:
        best_query = expand_query(current_expr, current_blocks)
        
    best_score = -1 # Score formula: precision * min(hit_count, 8000)
    
    iteration_log = []
    
    reasoning = "Initial check"
    for i in range(1, args.max_iterations + 1):
        logger.info(f"\n{'='*40}\n🚀 开始第 {i} 轮迭代优化\n{'='*40}")
        
        if 'query' in current_blocks and not current_expr:
            expanded_query = current_blocks['query']
        else:
            expanded_query = expand_query(current_expr, current_blocks)
            
        logger.info(f"当前组装检索式: {expanded_query}")
        
        metrics = await run_sample_evaluate(
            provider=args.provider,
            llm_provider=args.llm_provider,
            db_path=args.db_path,
            features_file=args.features_file,
            query=expanded_query,
            sample_size=30,
            round_id=str(i),
            concurrency=10,
        )
        hit_count = int(metrics["hit_count"])
        precision = float(metrics["precision"])
        noise_samples = metrics.get("noise_samples", [])
        logger.info(
            f"📊 第 {i} 轮结果 | round_id={metrics['round_id']} | "
            f"命中={hit_count} | precision={precision*100:.1f}% | "
            f"评估={metrics['evaluated_count']} | 非噪音={metrics['non_noise_count']}"
        )
        
        iteration_log.append({
            "iteration": i,
            "query": expanded_query,
            "blocks": current_blocks,
            "final_expression": current_expr,
            "hit_count": hit_count,
            "precision": precision,
            "reasoning": reasoning if i > 1 else "Initial check"
        })
        
        current_score = precision * min(hit_count, 8000) if hit_count > 0 else -1
        if hit_count > 0 and current_score > best_score:
            best_score = current_score
            best_query = expanded_query
            
        if hit_count > 0 and hit_count <= 8000 and precision >= args.target_precision:
            logger.info("🎯 达到目标 KPI (查准率>=目标且命中数<=8000)，停止迭代！")
            break
            
        if i < args.max_iterations:
            logger.info("🧠 正在请求 LLM 优化检索式...")
            # 传递上一轮的最佳 query 和指标
            new_blocks, new_expr, reasoning = await optimize_query_with_llm(
                llm_client, 
                current_blocks, 
                current_expr, 
                hit_count, 
                precision, 
                noise_samples, 
                features, 
                args.provider
            )
            
            if new_blocks == current_blocks and new_expr == current_expr:
                logger.warning("LLM 返回了相同的检索式模块，尝试强制放宽限制...")
                # 极度放宽
                if 'query' in current_blocks and not current_expr:
                    current_blocks['query'] = current_blocks['query'].replace(" AND ", " OR ")
                    expanded_query = current_blocks['query']
                else:
                    # 极端放宽：抛弃除了 S0 和 S1 以外的所有模块
                    new_expr = "(S1)"
                    new_blocks = {"S0": current_blocks.get("S0", "AUTHORITY:(US OR CN OR EP OR JP OR KR)"), "S1": "ALL:(折叠屏 OR foldable) AND ALL:(铰链 OR hinge)"}
                    
                    # 如果连 S1 都查不出来，再进一步拆分 S1
                    if hit_count == 0:
                        new_blocks["S1"] = "ALL:(折叠屏 OR foldable) AND ALL:(铰链 OR hinge)"
                        
                    current_expr = new_expr
                    current_blocks = new_blocks
                    expanded_query = expand_query(current_expr, current_blocks)
                    
                logger.info(f"强制放宽后的检索式: {expanded_query}")
            else:
                current_blocks = new_blocks
                current_expr = new_expr
            
    logger.info(f"\n{'='*40}\n🏆 迭代优化完成！\n最优检索式: {best_query}\n{'='*40}")
    
    with open(os.path.join(args.output_dir, "05_优化迭代记录_最终报告.json"), 'w', encoding='utf-8') as f:
        json.dump({
            "best_query": best_query,
            "iterations": iteration_log
        }, f, ensure_ascii=False, indent=2)
        
    with open(os.path.join(args.output_dir, "05_最终最优检索式.txt"), 'w', encoding='utf-8') as f:
        f.write(best_query)
        
    # 保存详细的 Markdown 报告
    with open(os.path.join(args.output_dir, "05_优化迭代记录_Round1.md"), 'w', encoding='utf-8') as f:
        f.write(f"# 检索式迭代优化报告\n\n")
        f.write(f"## 🏆 最终最优结果\n")
        f.write(f"- **命中数**: {best_score / args.target_precision if args.target_precision else 'N/A'}\n")
        f.write(f"- **单行检索式**:\n```\n{best_query}\n```\n\n")
        f.write(f"## 🔄 迭代过程记录\n")
        for log in iteration_log:
            f.write(f"### 第 {log['iteration']} 轮\n")
            f.write(f"- **指标**: 命中数 {log['hit_count']}, 查准率 {log['precision']*100:.1f}%\n")
            f.write(f"- **组装表达式**: `{log.get('final_expression', '')}`\n")
            f.write(f"#### 模块内容:\n")
            for k, v in log.get('blocks', {}).items():
                f.write(f"- **{k}**: `{v}`\n")
            f.write(f"#### 分析与思考过程:\n")
            f.write(f"{log.get('reasoning', 'N/A')}\n\n")

if __name__ == "__main__":
    asyncio.run(main())
