from __future__ import annotations

import json
from typing import Any

from core.models.fto_models import ExtractionResponse


class Step7Step1Adapter:
    response_model = ExtractionResponse
    job_type = "step7_step1_extract"
    temperature = 0.1
    failure_status = "skipped"

    def __init__(self, repo):
        self.repo = repo

    def build_prompt(self, ctx: dict[str, Any]) -> str:
        claims_text = self._resolve_claims_text(ctx)
        if not claims_text or len(claims_text.strip()) < 10 or "无权利要求" in claims_text:
            raise ValueError("专利权利要求文本无效或过短，无法进行特征提取！")
        return f"""
你是一名资深的专利代理师。请对以下【对比专利的权利要求书】进行技术特征拆解。
【对比专利的权利要求书】
{claims_text}
【拆解规范】
1. 将每一个独立权利要求拆解为多个独立的技术特征（例如 T1, T2, T3...）。
2. 权利要求的第一句话（前序部分/主题名称），如"一种用于...的方法"，请将其单独拆解为一个特征（如 T1）。
3. 对于长句子，特别是包含"当...时，...；当...时，..."等并列或分支逻辑的句子，必须将其在标点符号（如分号或句号）处拆分为多个独立的特征。
请以 JSON 格式输出，并严格符合提供的 Pydantic Schema (ExtractionResponse)。
"""

    def get_cleanser(self):
        return None

    def augment_retry_prompt(self, base_prompt: str, attempt: int, error: Exception | None) -> str:
        return base_prompt + "\n\n注意：请务必确保输出是合法的 JSON 格式，不要包含任何多余的 Markdown 标记或其他文本。"

    def on_success(self, ctx: dict[str, Any], parsed: ExtractionResponse | dict[str, Any], raw_text: str, stats: dict[str, Any]) -> None:
        patent_id = self._resolve_patent_id(ctx)
        claims_text = self._resolve_claims_text(ctx)
        extracted_claims = parsed.model_dump() if hasattr(parsed, "model_dump") else dict(parsed)
        self.repo.save_comparison_result(
            patent_id=patent_id,
            independent_claims=claims_text,
            extracted_features=json.dumps(extracted_claims, ensure_ascii=False),
            stage="step1_done",
        )

    def on_failure(self, ctx: dict[str, Any], error: Exception, raw_text: str | None, stats: dict[str, Any]) -> None:
        patent_id = self._resolve_patent_id(ctx)
        claims_text = self._resolve_claims_text(ctx)
        self.repo.save_comparison_result(
            patent_id=patent_id,
            independent_claims=claims_text,
            raw_llm_output=raw_text,
            stage="step1_done",
        )

    @staticmethod
    def _resolve_patent_id(ctx: dict[str, Any]) -> str:
        return str(
            ctx.get("patent_id")
            or ctx.get("publication_number")
            or ctx.get("公开号")
            or ""
        ).strip()

    @staticmethod
    def _resolve_claims_text(ctx: dict[str, Any]) -> str:
        return str(
            ctx.get("independent_claims")
            or ctx.get("claims_text")
            or ctx.get("full_claims")
            or ""
        ).strip()
