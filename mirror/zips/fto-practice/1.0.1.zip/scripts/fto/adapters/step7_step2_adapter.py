from __future__ import annotations

import json
from typing import Any

from core.models.fto_models import LLMComparisonResult
from core.llm_batch.cleanser_base import BaseCleanser
from fto.step7_step2_response_cleanser import Step7Step2ResponseCleanser


class _Step7Step2Cleanser(BaseCleanser):
    def cleanse(self, raw_text: str) -> str | dict | None:
        cleanser = Step7Step2ResponseCleanser(raw_text)
        if not cleanser.parse():
            return None
        return cleanser.cleanse()


class Step7Step2Adapter:
    response_model = LLMComparisonResult
    job_type = "step7_step2_compare"
    temperature = 0.2
    failure_status = "skipped"

    def __init__(self, repo, our_solution: str):
        self.repo = repo
        self.our_solution = our_solution

    def build_prompt(self, ctx: dict[str, Any]) -> str:
        extracted_claims = self._parse_extracted_claims(ctx)
        return f"""你是一名资深的知识产权律师，精通 FTO 侵权风险分析。
现在请你对以下【我方技术方案】和【已拆解的对比专利特征】进行比对，评估我方方案是否落入该专利的保护范围。
【我方技术方案】
{self.our_solution}
【已拆解的对比专利特征】
{json.dumps(extracted_claims, ensure_ascii=False, indent=2)}
【特征比对判断规范（向人工专家对齐）】
1. 专利侵权判定适用**"全面覆盖原则"**与**"等同原则"**。
2. 即使我方方案没有使用完全一致的专有名词，只要**实现的功能和达到的技术效果实质上是相同的**，就应该判定为"具有该特征"。
3. 请以**"原告律师"**的严苛视角进行推演。
【结论用语规范】
1. 对于前序部分/主题名称（通常是 T1），请在比对结论中直接输出"相同技术主题"。
2. 结论 `result` 字段必须是极其简练的"具有该特征"、"不具有该特征"或"具有等同特征"。
3. 针对单项权利要求的比对小结（analysis_conclusion），请使用极其严谨且格式化的法言法语。
4. 最终的整体侵权风险结论（final_risk_conclusion），请只输出简短的定性结论。
请以 JSON 格式输出，并严格符合提供的 Pydantic Schema (LLMComparisonResult)。
**极其重要：你必须在每个 feature 的 content 字段中完整保留【已拆解的对比专利特征】中对应的特征文本！**
【JSON 输出示例】
```json
{{
  "claims": [
    {{
      "name": "权1",
      "features": [
        {{
          "id": "T1",
          "content": "原始特征文本",
          "analysis_reasoning": "比对推理",
          "result": "具有该特征"
        }}
      ],
      "analysis_conclusion": "权1 比对小结"
    }}
  ],
  "final_risk_conclusion": "侵权风险低/存在侵权风险/不构成侵权"
}}
```
**极其重要：请严格按照上述 JSON 结构输出，不要添加额外字段。**
"""

    def get_cleanser(self) -> BaseCleanser | None:
        return _Step7Step2Cleanser()

    def augment_retry_prompt(self, base_prompt: str, attempt: int, error: Exception | None) -> str:
        return base_prompt + "\n\n注意：请务必确保输出是合法的 JSON 格式，并严格遵循 schema 结构。"

    def on_success(self, ctx: dict[str, Any], parsed: LLMComparisonResult | dict[str, Any], raw_text: str, stats: dict[str, Any]) -> None:
        patent_id = self._resolve_patent_id(ctx)
        claims_text = self._resolve_claims_text(ctx)
        extracted_claims = self._parse_extracted_claims(ctx)
        llm_result = parsed.model_dump() if hasattr(parsed, "model_dump") else dict(parsed)
        self._backfill_missing_feature_content(llm_result, extracted_claims)
        self.repo.save_comparison_result(
            patent_id=patent_id,
            independent_claims=claims_text,
            extracted_features=json.dumps(extracted_claims, ensure_ascii=False),
            feature_matches=llm_result.get("claims", []),
            final_risk_conclusion=llm_result.get("final_risk_conclusion", ""),
            stage="step2_done",
        )

    def on_failure(self, ctx: dict[str, Any], error: Exception, raw_text: str | None, stats: dict[str, Any]) -> None:
        patent_id = self._resolve_patent_id(ctx)
        claims_text = self._resolve_claims_text(ctx)
        extracted_claims = self._parse_extracted_claims(ctx)
        self.repo.save_comparison_result(
            patent_id=patent_id,
            independent_claims=claims_text,
            extracted_features=json.dumps(extracted_claims, ensure_ascii=False),
            raw_llm_output=raw_text,
            stage="step1_done",
        )

    @staticmethod
    def _resolve_patent_id(ctx: dict[str, Any]) -> str:
        return str(
            ctx.get("patent_id")
            or ctx.get("publication_number")
            or ctx.get("公开号")
            or ""
        ).strip()

    @staticmethod
    def _resolve_claims_text(ctx: dict[str, Any]) -> str:
        return str(ctx.get("independent_claims") or ctx.get("claims_text") or "").strip()

    @staticmethod
    def _parse_extracted_claims(ctx: dict[str, Any]) -> dict[str, Any]:
        extracted_features = ctx.get("extracted_features")
        if not extracted_features:
            raise ValueError("Step1 结果不存在，请先执行特征提取！")
        if isinstance(extracted_features, str):
            return json.loads(extracted_features)
        if isinstance(extracted_features, dict):
            return extracted_features
        raise ValueError("extracted_features 解析失败！")

    @staticmethod
    def _backfill_missing_feature_content(llm_result: dict[str, Any], extracted_claims: dict[str, Any]) -> None:
        for step2_claim in llm_result.get("claims", []):
            claim_name = step2_claim.get("name")
            step1_claim = next((c for c in extracted_claims.get("claims", []) if c.get("name") == claim_name), None)
            if not step1_claim:
                continue
            for step2_feat in step2_claim.get("features", []):
                feat_id = step2_feat.get("id")
                step1_feat = next((f for f in step1_claim.get("features", []) if f.get("id") == feat_id), None)
                if step1_feat and not step2_feat.get("content"):
                    step2_feat["content"] = step1_feat.get("content", "")
