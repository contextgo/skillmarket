import os
import sys
import argparse
import logging
import asyncio

_SCRIPT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _SCRIPT_DIR)

from core.llm_client import LLMClient
from core.config_resolver import ConfigResolver
from core.db_manager import DatabaseManager
from core.llm_batch.job_runner import BatchJobRunner
from core.llm_batch.logging_manager import BatchLoggingManager
from core.llm_batch.parse_pipeline import ParsePipeline
from core.llm_batch.retry_executor import execute_with_retry
from core.llm_batch.transport import LLMTransport
from repository.patent_repository import PatentRepository
from fto.adapters.step7_step2_adapter import Step7Step2Adapter

logger = logging.getLogger(__name__)


async def spinner_task(total, stats_ref, stop_event):
    spinner_chars = ['-', '\\', '|', '/']
    idx = 0
    while not stop_event.is_set():
        done = stats_ref["success"] + stats_ref["skipped"] + stats_ref["failed"]
        sys.stdout.write(
            f"\r{spinner_chars[idx]} 进度: {done}/{total} "
            f"(成功: {stats_ref['success']}, 跳过: {stats_ref['skipped']})"
        )
        sys.stdout.flush()
        idx = (idx + 1) % len(spinner_chars)
        await asyncio.sleep(0.1)
    done = stats_ref["success"] + stats_ref["skipped"] + stats_ref["failed"]
    sys.stdout.write(
        f"\r✅ 进度: {done}/{total} "
        f"(成功: {stats_ref['success']}, 跳过: {stats_ref['skipped']})\n"
    )
    sys.stdout.flush()


def build_llm_client_from_args(args) -> LLMClient:
    creds = ConfigResolver.resolve_llm(args.llm_provider)
    logger.info(f"使用 {args.llm_provider} 模型: {creds.model_name}")
    return LLMClient(api_key=creds.api_key, base_url=creds.base_url, actual_model=creds.model_name)


async def batch_fto_step2_async(db_path: str, our_solution: str, concurrent_limit: int = 5, llm_client: LLMClient = None):
    """
    FTO Step 2: 侵权比对（从 DB 读取 Step1 结果，并发执行）
    """
    db_manager = DatabaseManager(db_path=db_path)
    repo = PatentRepository(db_manager=db_manager)

    pending_patents = repo.get_step1_done_step2_pending_patents()

    if not pending_patents:
        logger.warning("未找到已完成 Step1 待执行 Step2 的专利。")
        print("未找到已完成 Step1 待执行 Step2 的专利。")
        return

    total_patents = len(pending_patents)
    logger.info(f"📋 待比对专利总数: {total_patents}")
    logger.info(f"⚡ 并发上限: {concurrent_limit}")
    print(f"📋 待比对专利总数: {total_patents} | ⚡ 并发上限: {concurrent_limit}")

    transport = LLMTransport(llm_client=llm_client)
    parse_pipeline = ParsePipeline()
    adapter = Step7Step2Adapter(repo=repo, our_solution=our_solution)
    runner = BatchJobRunner(worker_count=concurrent_limit)
    stats_ref = {"success": 0, "skipped": 0, "failed": 0}

    stop_event = asyncio.Event()
    spinner = asyncio.create_task(spinner_task(total_patents, stats_ref, stop_event))

    jobs = []
    for idx, patent_info in enumerate(pending_patents, start=1):
        pub_num = patent_info.get("patent_id") or patent_info.get("publication_number") or patent_info.get("公开号")
        logger.info(f"[{idx}/{len(pending_patents)}] 准备比对: {pub_num}")
        jobs.append(patent_info)

    async def processor(job_ctx: dict) -> dict:
        ok, result = await execute_with_retry(
            adapter=adapter,
            ctx=job_ctx,
            transport=transport,
            parse_pipeline=parse_pipeline,
            max_attempts=2,
        )
        pub_num = job_ctx.get("patent_id") or job_ctx.get("publication_number") or job_ctx.get("公开号")
        if ok:
            logger.info(f"✅ {pub_num} Step2 比对完成。")
        else:
            logger.warning(f"⚠️ {pub_num} 跳过: {result.get('error_type') or 'unknown_error'}")
        return result

    def progress_callback(run_stats) -> None:
        stats_ref["success"] = run_stats.success_count
        stats_ref["skipped"] = run_stats.skipped_count
        stats_ref["failed"] = run_stats.failed_count

    run_stats = await runner.run(jobs=jobs, processor=processor, progress_callback=progress_callback)

    stop_event.set()
    await spinner

    logger.info(f"\n🏁 Step 2 侵权比对完成！")
    logger.info(f"   ✅ 成功: {run_stats.success_count} 篇")
    logger.info(f"   ⚠️ 跳过: {run_stats.skipped_count} 篇")
    logger.info(f"   ❌ 失败: {run_stats.failed_count} 篇")
    logger.info(f"   🔁 重试分布: {run_stats.retry_histogram}")
    logger.info(f"   🧭 错误分类: {run_stats.error_type_histogram}")
    print(
        f"\n🏁 Step 2 侵权比对完成！✅ 成功: {run_stats.success_count} 篇, "
        f"⚠️ 跳过: {run_stats.skipped_count} 篇"
    )

async def async_main():
    parser = argparse.ArgumentParser(description="FTO Step 2: 批量侵权比对（从 DB 读取 Step1 结果，并发执行）")
    parser.add_argument("--llm_provider", type=str, default="minimax", choices=["minimax", "deepseek"], help="LLM提供商 (默认: minimax)")
    parser.add_argument("--db_path", type=str, required=True, help="SQLite 数据库路径")
    parser.add_argument("--solution_file", type=str, required=True, help="我方技术方案文本文件路径")
    parser.add_argument("--concurrent", type=int, default=5, help="并发上限（默认5）")
    args = parser.parse_args()

    logging_manager = BatchLoggingManager()
    log_file_path = logging_manager.setup_for_step("step7_step2_compare", args.db_path)

    print(f"日志将输出至: {log_file_path}")

    with open(args.solution_file, "r", encoding="utf-8") as f:
        our_solution = f.read()

    llm_client = build_llm_client_from_args(args)
    await batch_fto_step2_async(args.db_path, our_solution, args.concurrent, llm_client)

if __name__ == "__main__":
    asyncio.run(async_main())
