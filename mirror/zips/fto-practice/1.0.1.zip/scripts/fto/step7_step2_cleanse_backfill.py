import argparse
import json
import logging
import os
import sys

scripts_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, scripts_dir)

from core.db_manager import DatabaseManager
from core.llm_batch.logging_manager import BatchLoggingManager
from fto.step7_step2_response_cleanser import Step7Step2ResponseCleanser


def _setup_logging(db_path: str) -> str:
    return BatchLoggingManager().setup_for_step("step7_step2_cleanse_backfill", db_path)


def _persist_cleanse_result(db: DatabaseManager, patent_id: str, claims: list, final_conclusion: str) -> None:
    conn = db.get_connection()
    try:
        conn.execute(
            """
            UPDATE step07_comparison
            SET raw_llm_output = NULL, feature_matches = ?, final_risk_conclusion = ?
            WHERE patent_id = ?
            """,
            (json.dumps(claims, ensure_ascii=False), final_conclusion, patent_id),
        )
        conn.commit()
    finally:
        conn.close()


logger = logging.getLogger(__name__)


def main():
    parser = argparse.ArgumentParser(description="批量清洗并回写 step07_comparison.raw_llm_output")
    parser.add_argument("--db_path", required=True, help="SQLite 数据库路径")
    args = parser.parse_args()

    log_file = _setup_logging(args.db_path)
    print(f"日志文件: {log_file}")

    db = DatabaseManager(args.db_path)
    conn = db.get_connection()
    cursor = conn.cursor()

    cursor.execute(
        """
        SELECT patent_id, raw_llm_output
        FROM step07_comparison
        WHERE raw_llm_output IS NOT NULL
          AND raw_llm_output != ""
          AND (feature_matches IS NULL OR feature_matches = "" OR feature_matches = "[]")
        """
    )
    rows = cursor.fetchall()
    conn.close()

    if not rows:
        print("没有需要清洗的记录。")
        return

    print(f"找到 {len(rows)} 条待清洗记录")
    logger.info(f"找到 {len(rows)} 条待清洗记录")
    success_count = 0
    fail_count = 0

    for row in rows:
        patent_id = row[0]
        raw_str = row[1]
        logger.info(f"正在清洗: {patent_id}")

        cleanser = Step7Step2ResponseCleanser(raw_str)

        if not cleanser.parse():
            logger.warning(f"  JSON 解析失败: {cleanser.error}")
            fail_count += 1
            continue

        if cleanser.try_pydantic_parse():
            logger.info("  无需清洗，Pydantic 直接通过")
            _persist_cleanse_result(
                db=db,
                patent_id=patent_id,
                claims=cleanser.parsed.get("claims", []),
                final_conclusion=cleanser.parsed.get("final_risk_conclusion", ""),
            )
            success_count += 1
            continue

        cleansed = cleanser.cleanse()
        if cleansed is None:
            logger.warning("  清洗失败，保留原始输出")
            fail_count += 1
            continue

        try:
            _persist_cleanse_result(
                db=db,
                patent_id=patent_id,
                claims=cleansed.get("claims", []),
                final_conclusion=cleansed.get("final_risk_conclusion", ""),
            )
            logger.info("  清洗成功，已回写 feature_matches")
            success_count += 1
        except Exception as e:
            logger.warning(f"  回写失败: {e}")
            fail_count += 1

    logger.info(f"清洗完成: 成功={success_count}, 失败={fail_count}")
    print(f"清洗完成: 成功={success_count}, 失败={fail_count}")


if __name__ == "__main__":
    main()
