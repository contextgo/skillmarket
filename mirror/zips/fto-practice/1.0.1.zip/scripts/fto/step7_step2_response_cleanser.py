import json
import logging
from typing import Any, Optional

logger = logging.getLogger(__name__)

TARGET_TOP_LEVEL_KEYS = {"claims", "final_risk_conclusion"}
CLAIM_RESULT_KEYS = {"name", "features", "analysis_conclusion"}
FEATURE_RESULT_KEYS = {"id", "content", "analysis_reasoning", "result"}

ALIAS_MAP_TOP = {
    "claims": {
        "claims",
        "claim_results",
        "comparison_results",
        "feature_comparison",
        "feature_comparisons",
        "comparisons",
        "claim_analysis",
        "claims_analysis",
    },
    "final_risk_conclusion": {
        "final_risk_conclusion",
        "overall_conclusion",
        "final_conclusion",
        "risk_conclusion",
        "conclusion",
        "overall_risk_conclusion",
        "risk_summary",
        "overall_result",
    },
}
ALIAS_MAP_CLAIM = {
    "name": {"name", "claim_name", "claim_id", "claim_number", "id"},
    "features": {"features", "feature_results", "results"},
    "analysis_conclusion": {"analysis_conclusion", "conclusion", "summary", "claim_analysis"},
}
ALIAS_MAP_FEATURE = {
    "id": {"id", "feature_id"},
    "content": {"content", "text", "description"},
    "analysis_reasoning": {"analysis_reasoning", "reason", "reasoning"},
    "result": {"result", "conclusion", "match_result", "judgment"},
}


def _tokenize(s: str) -> set:
    return set(s.lower().replace("_", " ").replace("-", " ").split())


def _jaccard(s1: str, s2: str) -> float:
    t1, t2 = _tokenize(s1), _tokenize(s2)
    if not t1 or not t2:
        return 0.0
    inter = len(t1 & t2)
    union = len(t1 | t2)
    return inter / union if union > 0 else 0.0


def _best_schema_match(field_name: str, target_keys: set) -> str:
    best = None
    best_score = -1
    for tk in target_keys:
        score = _jaccard(field_name, tk)
        if score > best_score:
            best_score = score
            best = tk
    return best


class Step7Step2ResponseCleanser:
    def __init__(self, raw_json_str: str):
        self.raw_str = raw_json_str
        self.parsed = None
        self.error = None

    def parse(self) -> bool:
        raw = self.raw_str.strip()
        import re

        m = re.match(r"```(?:json)?\s*([\s\S]+?)```", raw, re.DOTALL)
        if m:
            raw = m.group(1).strip()
        try:
            self.parsed = json.loads(raw)
            return True
        except Exception as e:
            self.error = e
            return False

    def try_pydantic_parse(self) -> bool:
        if self.parsed is None:
            return False
        try:
            from core.models.fto_models import LLMComparisonResult

            LLMComparisonResult.model_validate(self.parsed)
            return True
        except Exception as e:
            logger.debug(f"Pydantic validation failed: {e}")
            return False

    def cleanse(self) -> Optional[dict]:
        if self.parsed is None:
            return None

        result = self._cleanse_recursive(self.parsed, top_level=True)
        if result is None:
            return None

        try:
            from core.models.fto_models import LLMComparisonResult

            LLMComparisonResult.model_validate(result)
            return result
        except Exception as e:
            logger.debug(f"Cleansed result still invalid: {e}")
            return None

    def _cleanse_recursive(self, data: Any, top_level: bool = False) -> Any:
        if not isinstance(data, dict):
            return data

        if top_level:
            return self._cleanse_top_level(data)

        if "features" in data or "name" in data:
            return self._cleanse_claim_or_feature(data)

        return data

    def _cleanse_top_level(self, data: dict) -> dict:
        result = {}
        used_target_keys = set()

        for target_key, aliases in ALIAS_MAP_TOP.items():
            for alias in aliases:
                if alias in data:
                    result[target_key] = data[alias]
                    used_target_keys.add(target_key)
                    break

        remaining = {k: v for k, v in data.items() if k not in {a for aliases in ALIAS_MAP_TOP.values() for a in aliases}}

        if len(remaining) == 1:
            remaining_key = next(iter(remaining))
            matched_target = _best_schema_match(remaining_key, TARGET_TOP_LEVEL_KEYS - used_target_keys)
            if matched_target:
                result[matched_target] = remaining[remaining_key]
                used_target_keys.add(matched_target)
            else:
                result[remaining_key] = remaining[remaining_key]
        elif len(remaining) >= 2:
            remaining_keys = list(remaining.keys())
            for rk in remaining_keys:
                matched_target = _best_schema_match(rk, TARGET_TOP_LEVEL_KEYS - used_target_keys)
                if matched_target:
                    result[matched_target] = remaining.pop(rk)
                    used_target_keys.add(matched_target)

        if not result.get("final_risk_conclusion"):
            for key in [
                "overall_risk_conclusion",
                "final_conclusion",
                "risk_conclusion",
                "conclusion",
                "overall_conclusion",
                "risk_summary",
                "overall_result",
            ]:
                if data.get(key):
                    result["final_risk_conclusion"] = data[key]
                    break

        if not result.get("claims"):
            for key in [
                "claim_results",
                "comparison_results",
                "comparisons",
                "claim_analysis",
                "claims_analysis",
                "feature_comparison",
                "feature_comparisons",
            ]:
                raw_list = data.get(key)
                if isinstance(raw_list, list):
                    result["claims"] = raw_list
                    break

        if not result.get("claims"):
            for _, val in data.items():
                if not isinstance(val, dict):
                    continue
                nested_list = (
                    val.get("claims")
                    or val.get("claim_results")
                    or val.get("comparison_results")
                    or val.get("comparisons")
                    or val.get("claim_analysis")
                    or val.get("claims_analysis")
                )
                if isinstance(nested_list, list):
                    result["claims"] = nested_list
                    break

        if "claims" in result and isinstance(result["claims"], list):
            result["claims"] = [self._cleanse_claim_or_feature(c) for c in result["claims"]]

        return result

    def _cleanse_claim_or_feature(self, data: dict) -> dict:
        if "features" not in data:
            return self._cleanse_claim(data)

        if isinstance(data.get("features"), list) and len(data["features"]) > 0:
            first_feat = data["features"][0]
            if isinstance(first_feat, dict):
                if "result" in first_feat or "conclusion" in first_feat or "match_result" in first_feat:
                    return self._cleanse_claim(data)
                if "content" in first_feat or "text" in first_feat or "description" in first_feat:
                    return self._cleanse_feature_result_item(data)

        return self._cleanse_claim(data)

    def _cleanse_claim(self, data: dict) -> dict:
        result = {}
        used_keys = set()

        for target_key, aliases in ALIAS_MAP_CLAIM.items():
            for alias in aliases:
                if alias in data:
                    result[target_key] = data[alias]
                    used_keys.add(target_key)
                    break

        remaining = {k: v for k, v in data.items() if k not in {a for aliases in ALIAS_MAP_CLAIM.values() for a in aliases}}

        if len(remaining) == 1:
            remaining_key = next(iter(remaining))
            matched_target = _best_schema_match(remaining_key, FEATURE_RESULT_KEYS - used_keys)
            if matched_target:
                result[matched_target] = remaining[remaining_key]
                used_keys.add(matched_target)
            else:
                result[remaining_key] = remaining[remaining_key]
        elif len(remaining) >= 2:
            remaining_keys = list(remaining.keys())
            for rk in remaining_keys:
                matched_target = _best_schema_match(rk, FEATURE_RESULT_KEYS - used_keys)
                if matched_target:
                    result[matched_target] = remaining.pop(rk)
                    used_keys.add(matched_target)

        if "features" in result and isinstance(result["features"], list):
            result["features"] = [self._cleanse_feature_result_item(f) if isinstance(f, dict) else f for f in result["features"]]

        return result

    def _cleanse_feature_result_item(self, feat: dict) -> dict:
        result = {}
        used_keys = set()

        for target_key, aliases in ALIAS_MAP_FEATURE.items():
            for alias in aliases:
                if alias in feat:
                    result[target_key] = feat[alias]
                    used_keys.add(target_key)
                    break

        remaining = {k: v for k, v in feat.items() if k not in {a for aliases in ALIAS_MAP_FEATURE.values() for a in aliases}}

        if len(remaining) == 1:
            remaining_key = next(iter(remaining))
            remaining_target = FEATURE_RESULT_KEYS - used_keys
            if remaining_target:
                matched_target = _best_schema_match(remaining_key, remaining_target)
                if matched_target:
                    result[matched_target] = remaining[remaining_key]
                    used_keys.add(matched_target)
                else:
                    result[remaining_key] = remaining[remaining_key]
        elif len(remaining) >= 2:
            remaining_keys = list(remaining.keys())
            for rk in remaining_keys:
                remaining_target = FEATURE_RESULT_KEYS - used_keys
                if remaining_target:
                    matched_target = _best_schema_match(rk, remaining_target)
                    if matched_target:
                        result[matched_target] = remaining.pop(rk)
                        used_keys.add(matched_target)

        for required_key in FEATURE_RESULT_KEYS:
            if required_key not in result:
                result[required_key] = ""

        return result
