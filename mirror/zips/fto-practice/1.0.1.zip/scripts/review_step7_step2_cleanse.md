# Step7 Step2 Cleanse 代码审查报告

审查时间：2026-04-21
审查范围：`cleanse_step2_output.py`, `cleanse_step2.py`, `patent_repository.py`, `llm_client.py`, `db_manager.py`, `fto_batch_skill.py`

---

## 执行摘要

| 检查项 | 状态 | 说明 |
|--------|------|------|
| DB schema raw_llm_output | PASS | 已正确实现 |
| _do_step2_compare_async 重试清洗顺序 | PASS | 逻辑符合 Spec |
| _do_step2_compare 同步版本一致性 | PASS | 与异步版本一致 |
| cleanse_step2_output.py 独立运行 | PASS | 支持 --db_path |
| 相似度算法（Jaccard + Levenshtein） | PASS | 实现正确 |
| 无 .json 文件产出 | PASS | 未发现 JSON 写入 |
| fto_batch_skill.py 日志配置 | PASS | 日志写入 .log 文件 |
| 终端日志静默（cleanse_step2_output.py） | **FAIL** | 使用 StreamHandler 打印到终端 |
| 终端日志静默（llm_client.py） | **WARN** | Thinking process 和原始数据用 info 级别 |

---

## Task 1: DB Schema `raw_llm_output` 字段

**Spec 要求**：`step07_comparison` 表必须包含 `raw_llm_output TEXT` 字段。

**实现检查**：

- `db_manager.py` L96-107：表定义已包含 `raw_llm_output TEXT` ✅
- `db_manager.py` L338-365：`save_comparison_result` 方法签名已包含 `raw_llm_output` 参数 ✅
- `patent_repository.py` L118-137：透传参数正确 ✅

**注**：Spec 提到 `_migrate_step07_checkpoint` 中应有 ALTER TABLE 迁移逻辑，代码中只有 `_migrate_old_db`，未找到该迁移方法。但对于新建数据库无影响。

---

## Task 2: `_do_step2_compare_async` 重试与清洗顺序

**Spec 要求（关键顺序）**：
1. 调用 LLM API
2. 尝试解析 JSON
3. 若解析失败，**先尝试清洗**（不重新调用 LLM）
4. 清洗成功 → 使用清洗结果继续
5. 清洗失败 → **重新调用 LLM**（最多 1 次重试）
6. 重试后仍失败 → 再次尝试清洗
7. 仍失败 → 将原始 LLM 输出存入 `raw_llm_output`，stage 仍为 `step1_done`，不 raise

**实际代码顺序**（`fto_service.py` L387-428）：

```
try:
    response_step2, raw_text = await do_llm_call_async(prompt)  # 1. 调用 LLM
    parsed_result = response_step2.model_dump()  # 2. 解析
except Exception as e:
    parsed_result = try_cleanse(raw_output_store["text"])  # 3. 失败时立即清洗

if parsed_result is None:
    response_step2, raw_text = await do_llm_call_async(retry_prompt)  # 4. 清洗失败则重试
    parsed_result = response_step2.model_dump()
    except Exception as retry_e:
        parsed_result = try_cleanse(raw_output_store["text"])  # 5. 重试后仍失败再清洗

if parsed_result is None:
    落库 raw_llm_output  # 6. 最终失败落库
```

**结论**：顺序符合 Spec ✅

**同步版本 `_do_step2_compare`**（L227-343）与异步版本逻辑一致 ✅

**潜在问题 - `raw_output_store["text"]` 可能为 None**：

- `fto_service.py` L289/303/415：当从异常信息中提取 `模型返回原文` 时，若异常格式不符预期，`raw_output_store["text"]` 将保持为 None，导致清洗失败
- 异步版本 L428 返回 None 而非 raise，符合 Spec "不 raise" 的要求 ✅

---

## Task 3: `cleanse_step2_output.py` 清洗脚本

**Spec 要求**：独立运行脚本，从 DB 读取 `raw_llm_output` 非空且 `feature_matches` 为空的记录，清洗后回写 `feature_matches`，清空 `raw_llm_output`。

**实现检查**：

- `cleanse_step2_output.py` L31-37：查询条件正确
- `cleanse_step2_output.py` L75-95：清洗后回写逻辑正确
- `cleanse_step2.py`：`Step2Cleanser` 类实现了精准匹配 + Jaccard/Levenshtein 相似度匹配逻辑 ✅

**FAIL - 日志配置违规**：

```python
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],  # 输出到终端
)
```

所有日志（包括进度信息）均通过 StreamHandler 打印到终端，违反了用户"终端仅显示进度条，详细日志写入 .log 文件"的要求。

---

## Task 4: `fto_batch_skill.py` 无 .json 文件产出

**Spec 要求**：实际流程中不得产生任何 .json 文件。

**结论**：未发现任何 `.json` 文件写入逻辑 ✅

---

## Task 5: `llm_client.py` 日志违规

**发现**：

- `llm_client.py` L158-159：`logger.info("Thinking process:\n%s", reasoning_content)` 打印思考过程到终端
- `llm_client.py` L199-200：异步版本同样打印
- `llm_client.py` L218：`logger.info("LLM 原始返回数据:\n%s", ...)` 打印原始返回

这些日志使用 `logger.info` 级别，当 `fto_batch_skill.py` 配置了 StreamHandler 时（虽然当前没有），会在终端显示，违反用户偏好。

---

## 待修复问题汇总

### P0 - 必须修复

1. **cleanse_step2_output.py 日志 StreamHandler**
   - 文件：`fto/cleanse_step2_output.py` L14-18
   - 问题：`logging.basicConfig` 配置了 `StreamHandler(sys.stdout)`，所有日志打印到终端
   - 修复方向：移除 StreamHandler，仅保留 FileHandler 写入 .log 文件；终端仅通过 `print()` 输出最少量信息

### P1 - 建议修复

2. **llm_client.py 思考过程和原始数据日志**
   - 文件：`core/llm_client.py` L158-159, L199-200, L218
   - 问题：`logger.info` 打印思考过程和原始返回数据
   - 修复方向：将这些日志改为 `logger.debug` 或直接写入日志文件而非 info，避免在终端显示
