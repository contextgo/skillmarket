import json
import unittest

from core.models.fto_models import ExtractionResponse
from fto.adapters.step7_step1_adapter import Step7Step1Adapter


class _FakeRepo:
    def __init__(self):
        self.calls = []

    def save_comparison_result(self, **kwargs):
        self.calls.append(kwargs)


class TestStep7Step1Adapter(unittest.TestCase):
    def setUp(self):
        self.repo = _FakeRepo()
        self.adapter = Step7Step1Adapter(repo=self.repo)
        self.ctx = {"patent_id": "CN001", "independent_claims": "一种装置，其特征在于包括模块A与模块B。"}

    def test_on_success_persists_step1_done(self):
        parsed = ExtractionResponse.model_validate(
            {"claims": [{"name": "权1", "features": [{"id": "T1", "content": "模块A"}]}]}
        )
        self.adapter.on_success(self.ctx, parsed, raw_text="{}", stats={})
        self.assertEqual(len(self.repo.calls), 1)
        record = self.repo.calls[0]
        self.assertEqual(record["stage"], "step1_done")
        extracted = json.loads(record["extracted_features"])
        self.assertEqual(extracted["claims"][0]["name"], "权1")

    def test_on_failure_persists_raw_output(self):
        self.adapter.on_failure(self.ctx, RuntimeError("x"), raw_text="bad-json", stats={})
        self.assertEqual(len(self.repo.calls), 1)
        record = self.repo.calls[0]
        self.assertEqual(record["stage"], "step1_done")
        self.assertEqual(record["raw_llm_output"], "bad-json")


if __name__ == "__main__":
    unittest.main()
