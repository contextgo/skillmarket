import unittest

from core.llm_client import LLMClient
from core.models.patent_data import RelevanceResult4Tier


class TestLLMClientTypeCoercion(unittest.TestCase):
    def setUp(self):
        self.client = LLMClient(
            api_key="dummy-key",
            base_url="https://example.com/v1",
            actual_model="dummy-model"
        )

    def test_parse_response_coerces_literal_int_from_string(self):
        content = '{"score":"0","reason":"场景不同","node":"其他"}'

        result = self.client._parse_response(content, RelevanceResult4Tier)

        self.assertEqual(result.score, 0)
        self.assertIsInstance(result.score, int)
        self.assertEqual(result.reason, "场景不同")
        self.assertEqual(result.node, "其他")

    def test_parse_response_rejects_out_of_literal_range(self):
        content = '{"score":"4","reason":"超出范围","node":"其他"}'

        with self.assertRaises(Exception):
            self.client._parse_response(content, RelevanceResult4Tier)


if __name__ == "__main__":
    unittest.main()
