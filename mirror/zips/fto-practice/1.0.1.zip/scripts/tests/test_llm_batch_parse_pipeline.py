import unittest

from pydantic import BaseModel

from core.llm_batch.parse_pipeline import ParsePipeline


class _SimpleResponse(BaseModel):
    value: int


class _FixingCleanser:
    def cleanse(self, raw_text: str):
        return {"value": 7}


class _FailingCleanser:
    def cleanse(self, raw_text: str):
        return None


class TestParsePipeline(unittest.TestCase):
    def setUp(self):
        self.pipeline = ParsePipeline()

    def test_parse_direct_valid_json(self):
        outcome = self.pipeline.parse_direct('{"value": 3}', _SimpleResponse)
        self.assertTrue(outcome.ok)
        self.assertEqual(outcome.parsed.value, 3)

    def test_parse_or_cleanse_recover(self):
        outcome = self.pipeline.parse_or_cleanse("invalid-json", _SimpleResponse, _FixingCleanser())
        self.assertTrue(outcome.ok)
        self.assertEqual(outcome.parsed.value, 7)

    def test_parse_or_cleanse_fail(self):
        outcome = self.pipeline.parse_or_cleanse("invalid-json", _SimpleResponse, _FailingCleanser())
        self.assertFalse(outcome.ok)
        self.assertIn(outcome.error_type, {"json_decode_error", "schema_validation_error"})


if __name__ == "__main__":
    unittest.main()
