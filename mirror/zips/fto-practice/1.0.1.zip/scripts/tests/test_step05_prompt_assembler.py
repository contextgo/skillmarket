import unittest

from step05.prompting.prompt_assembler import assemble_step05_precision_prompt


class TestStep05PromptAssembler(unittest.TestCase):
    def test_provider_specific_rules_are_applied(self):
        prompt, fallback = assemble_step05_precision_prompt(
            features_text="特征A",
            provider="lens",
            patent_id="CN1",
            patent_title="标题",
            independent_claims="一种装置，其特征在于包括模块A和模块B。",
        )
        self.assertFalse(fallback)
        self.assertIn("Lens 不支持 TAC", prompt)
        self.assertIn("特征A", prompt)

    def test_unknown_provider_fallback(self):
        prompt, fallback = assemble_step05_precision_prompt(
            features_text="特征A",
            provider="unknown_db",
            patent_id="CN2",
            patent_title="标题2",
            independent_claims="一种系统，其特征在于包括模块C。",
        )
        self.assertTrue(fallback)
        self.assertIn("provider 未识别，已降级", prompt)
        self.assertIn("保守布尔规则", prompt)


if __name__ == "__main__":
    unittest.main()
