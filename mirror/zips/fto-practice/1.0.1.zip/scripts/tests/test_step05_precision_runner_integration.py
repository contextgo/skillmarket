import asyncio
import tempfile
import unittest
from pathlib import Path

from core.db_manager import DatabaseManager
from step05.services import precision_eval_runner


class _FakeLLMClient:
    async def generate_structured_data_async(self, prompt, response_model, temperature=0.2):
        return response_model(score=1, reason="相关", node="其他"), '{"score":1,"reason":"相关","node":"其他"}'


class TestStep05PrecisionRunnerIntegration(unittest.TestCase):
    def test_runner_persist_metrics_and_results(self):
        with tempfile.TemporaryDirectory() as td:
            db_path = str(Path(td) / "patents.db")
            db = DatabaseManager(db_path=db_path)
            patents = [
                {"patent_id": "CN-A", "title": "A", "abstract": "a", "claims_text": "一种方法A"},
                {"patent_id": "CN-B", "title": "B", "abstract": "b", "claims_text": "一种方法B"},
            ]
            db.save_patents(patents, source="step05_round_r1")
            db.save_patent_claims("CN-A", "一种用于调度控制的系统，其特征在于包含模块A和模块B。")
            db.save_patent_claims("CN-B", "一种用于路径规划的方法，其特征在于包含步骤A和步骤B。")

            original_builder = precision_eval_runner._build_llm_client
            precision_eval_runner._build_llm_client = lambda llm_provider: _FakeLLMClient()
            try:
                metrics = asyncio.run(
                    precision_eval_runner.run_step05_precision_eval(
                        db_path=db_path,
                        features_text="特征X",
                        llm_provider="minimax",
                        provider="lens",
                        round_id="r1",
                        query_text="ALL:(x)",
                        hit_count=2,
                        source="step05_round_r1",
                        concurrency=2,
                    )
                )
            finally:
                precision_eval_runner._build_llm_client = original_builder

            self.assertEqual(metrics["evaluated_count"], 2)
            self.assertEqual(metrics["non_noise_count"], 2)
            self.assertEqual(metrics["precision"], 1.0)

            result_rows = db.get_step05_eval_results("r1")
            self.assertEqual(len(result_rows), 2)
            metric_rows = db.get_step05_eval_metrics("r1")
            self.assertEqual(len(metric_rows), 1)
            self.assertEqual(metric_rows[0]["hit_count"], 2)


if __name__ == "__main__":
    unittest.main()
