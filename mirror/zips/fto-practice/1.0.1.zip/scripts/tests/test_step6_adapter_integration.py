import unittest

from core.models.patent_data import RelevanceResult4Tier
from filter.adapters.step6_adapter import Step6Adapter


class _FakeRepo:
    def __init__(self):
        self.calls = []

    def save_patent_assessment(self, **kwargs):
        self.calls.append(kwargs)


class TestStep6Adapter(unittest.TestCase):
    def setUp(self):
        self.repo = _FakeRepo()
        self.adapter = Step6Adapter(repo=self.repo, features="技术特征A", taxonomy_nodes=["节点1"])
        self.ctx = {
            "patent_id": "CNX",
            "title": "测试专利",
            "independent_claims": "一种方法，其特征在于包括步骤A。",
        }

    def test_build_prompt_contains_required_fields(self):
        prompt = self.adapter.build_prompt(self.ctx)
        self.assertIn("score、reason、node", prompt)
        self.assertIn("技术特征A", prompt)
        self.assertIn("测试专利", prompt)

    def test_on_success_persists_assessment(self):
        parsed = RelevanceResult4Tier(score=2, reason="相关", node="节点1")
        self.adapter.on_success(self.ctx, parsed, raw_text="{}", stats={})
        self.assertEqual(len(self.repo.calls), 1)
        record = self.repo.calls[0]
        self.assertEqual(record["publication_number"], "CNX")
        self.assertEqual(record["relevance_score"], 2)

    def test_on_failure_persists_default_zero(self):
        self.adapter.on_failure(self.ctx, RuntimeError("oops"), raw_text=None, stats={})
        self.assertEqual(len(self.repo.calls), 1)
        record = self.repo.calls[0]
        self.assertEqual(record["relevance_score"], 0)
        self.assertEqual(record["node"], "其他")


if __name__ == "__main__":
    unittest.main()
