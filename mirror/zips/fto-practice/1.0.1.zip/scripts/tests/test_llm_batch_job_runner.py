import asyncio
import unittest

from core.llm_batch.job_runner import BatchJobRunner


class TestBatchJobRunner(unittest.IsolatedAsyncioTestCase):
    async def test_input_equals_terminal(self):
        runner = BatchJobRunner(worker_count=3)
        jobs = [{"id": str(i)} for i in range(6)]

        async def processor(job):
            await asyncio.sleep(0.001)
            if int(job["id"]) % 2 == 0:
                return {"status": "success", "attempts": 1, "error_type": None}
            return {"status": "skipped", "attempts": 2, "error_type": "json_decode_error"}

        stats = await runner.run(jobs=jobs, processor=processor)
        self.assertEqual(stats.total_input, 6)
        self.assertEqual(stats.terminal_count, 6)
        self.assertEqual(stats.success_count, 3)
        self.assertEqual(stats.skipped_count, 3)

    async def test_exception_job_not_blocking(self):
        runner = BatchJobRunner(worker_count=2)
        jobs = [{"id": "1"}, {"id": "2"}]

        async def processor(job):
            if job["id"] == "1":
                raise RuntimeError("boom")
            return {"status": "success", "attempts": 1, "error_type": None}

        stats = await runner.run(jobs=jobs, processor=processor)
        self.assertEqual(stats.total_input, 2)
        self.assertEqual(stats.terminal_count, 2)
        self.assertEqual(stats.failed_count, 1)
        self.assertEqual(stats.success_count, 1)


if __name__ == "__main__":
    unittest.main()
