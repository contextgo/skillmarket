import unittest

from core.models.fto_models import LLMComparisonResult
from fto.adapters.step7_step2_adapter import Step7Step2Adapter


class _FakeRepo:
    def __init__(self):
        self.calls = []

    def save_comparison_result(self, **kwargs):
        self.calls.append(kwargs)


class TestStep7Step2Adapter(unittest.TestCase):
    def setUp(self):
        self.repo = _FakeRepo()
        self.adapter = Step7Step2Adapter(repo=self.repo, our_solution="test solution")
        self.ctx = {
            "patent_id": "CN123",
            "independent_claims": "claim text",
            "extracted_features": '{"claims":[{"name":"权1","features":[{"id":"T1","content":"特征1"}]}]}',
        }

    def test_on_success_persists_step2_done_and_backfills_content(self):
        parsed = LLMComparisonResult.model_validate(
            {
                "claims": [
                    {
                        "name": "权1",
                        "features": [
                            {"id": "T1", "content": "", "analysis_reasoning": "x", "result": "具有该特征"}
                        ],
                        "analysis_conclusion": "",
                    }
                ],
                "final_risk_conclusion": "存在侵权风险",
            }
        )

        self.adapter.on_success(self.ctx, parsed, raw_text="{}", stats={})
        self.assertEqual(len(self.repo.calls), 1)
        record = self.repo.calls[0]
        self.assertEqual(record["stage"], "step2_done")
        self.assertEqual(record["feature_matches"][0]["features"][0]["content"], "特征1")

    def test_on_failure_persists_raw_output(self):
        self.adapter.on_failure(self.ctx, RuntimeError("x"), raw_text="raw-output", stats={})
        self.assertEqual(len(self.repo.calls), 1)
        record = self.repo.calls[0]
        self.assertEqual(record["stage"], "step1_done")
        self.assertEqual(record["raw_llm_output"], "raw-output")


if __name__ == "__main__":
    unittest.main()
