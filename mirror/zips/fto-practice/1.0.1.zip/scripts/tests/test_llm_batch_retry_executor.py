import unittest

from pydantic import BaseModel

from core.llm_batch.parse_pipeline import ParsePipeline
from core.llm_batch.retry_executor import execute_with_retry


class _SimpleResponse(BaseModel):
    value: int


class _NoopCleanser:
    def cleanse(self, raw_text: str):
        return None


class _Adapter:
    response_model = _SimpleResponse
    job_type = "test_job"
    temperature = 0.1
    failure_status = "failed"

    def __init__(self):
        self.success_called = 0
        self.failure_called = 0

    def build_prompt(self, ctx):
        return "prompt"

    def get_cleanser(self):
        return _NoopCleanser()

    def augment_retry_prompt(self, base_prompt, attempt, error):
        return base_prompt + " retry"

    def on_success(self, ctx, parsed, raw_text, stats):
        self.success_called += 1

    def on_failure(self, ctx, error, raw_text, stats):
        self.failure_called += 1


class _TransportFailThenPass:
    def __init__(self):
        self.calls = 0

    async def call_async(self, prompt, response_model, temperature=0.2):
        self.calls += 1
        if self.calls == 1:
            raise Exception('数据解析失败。模型返回原文: {"oops": 1}')
        return response_model(value=9), '{"value":9}'


class _TransportAlwaysFail:
    async def call_async(self, prompt, response_model, temperature=0.2):
        raise Exception("network down")


class TestRetryExecutor(unittest.IsolatedAsyncioTestCase):
    async def test_first_fail_second_success(self):
        adapter = _Adapter()
        transport = _TransportFailThenPass()

        ok, result = await execute_with_retry(
            adapter=adapter,
            ctx={"id": "1"},
            transport=transport,
            parse_pipeline=ParsePipeline(),
            max_attempts=2,
        )

        self.assertTrue(ok)
        self.assertEqual(result["status"], "success")
        self.assertEqual(adapter.success_called, 1)
        self.assertEqual(adapter.failure_called, 0)

    async def test_all_fail_triggers_on_failure(self):
        adapter = _Adapter()
        transport = _TransportAlwaysFail()

        ok, result = await execute_with_retry(
            adapter=adapter,
            ctx={"id": "1"},
            transport=transport,
            parse_pipeline=ParsePipeline(),
            max_attempts=2,
        )

        self.assertFalse(ok)
        self.assertEqual(result["status"], "failed")
        self.assertEqual(adapter.success_called, 0)
        self.assertEqual(adapter.failure_called, 1)


if __name__ == "__main__":
    unittest.main()
