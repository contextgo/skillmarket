import logging
import math
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
import os
import sys

# 确保能引入同目录的模块
from search.api_clients.base_client import BasePatentClient
from core.models.patent_data import UnifiedSearchResult

logger = logging.getLogger(__name__)

class SearchService:
    """
    负责核心搜索业务流的编排：调用 API 拉取宏观数据和靶点
    """
    def __init__(self, api_client: BasePatentClient):
        self.api_client = api_client
        self.provider = api_client.__class__.__name__.lower().replace("client", "")

    def fetch_page(self, query: str, limit: int, offset: int, max_retries: int = 3):
        """单独拉取一页的子任务"""
        for attempt in range(max_retries):
            try:
                return self.api_client.execute_unified_search(query=query, limit=limit, offset=offset)
            except Exception as e:
                logger.warning(f"⚠️ 翻页拉取失败 (offset={offset}): {e}，正在进行第 {attempt + 1} 次重试...")
                time.sleep(2 ** attempt)
        logger.error(f"❌ 经过多次重试，翻页拉取(offset={offset})彻底失败。")
        return None

    def execute_search(self, query: str, max_fetch: int = 20) -> UnifiedSearchResult:
        """
        调用 API 客户端执行统一检索 (支持并发分页拉取所有结果)
        """
        logger.info(f"📡 正在发送检索请求: {query}")
        all_pns = []
        total_hit_count = 0
        limit = 10

        first_page_result = self.fetch_page(query, limit, 0)
        if not first_page_result:
            return UnifiedSearchResult(hit_count=0, patent_numbers=[])
            
        total_hit_count = first_page_result.hit_count
        all_pns.extend(first_page_result.patent_numbers)
        
        if total_hit_count <= limit or len(first_page_result.patent_numbers) < limit:
            return UnifiedSearchResult(hit_count=total_hit_count, patent_numbers=all_pns)
            
        remaining_records = min(total_hit_count, max_fetch) - limit
        remaining_pages = math.ceil(remaining_records / limit) if remaining_records > 0 else 0
            
        if remaining_pages > 0:
            logger.info(f"   ... 首页已获取 {len(all_pns)} 条数据，总命中数 {total_hit_count}，准备并发拉取剩余 {remaining_pages} 页 ...")
            
            results_by_offset = {}
            fetched_pns = set(all_pns)
            
            with ThreadPoolExecutor(max_workers=min(5, remaining_pages)) as executor:
                future_to_offset = {
                    executor.submit(self.fetch_page, query, limit, limit + i * limit): limit + i * limit
                    for i in range(remaining_pages)
                }
                
                for future in as_completed(future_to_offset):
                    offset = future_to_offset[future]
                    try:
                        res = future.result()
                        if res and res.patent_numbers:
                            results_by_offset[offset] = res.patent_numbers
                            logger.info(f"   ... 第 {offset // limit + 1} 页拉取完成 ...")
                    except Exception as exc:
                        logger.error(f"   -> 第 {offset // limit + 1} 页拉取异常: {exc}")
                        
            for offset in sorted(results_by_offset.keys()):
                for pn in results_by_offset[offset]:
                    if pn not in fetched_pns:
                        fetched_pns.add(pn)
                        all_pns.append(pn)
                        
        return UnifiedSearchResult(hit_count=total_hit_count, patent_numbers=all_pns[:max_fetch])
