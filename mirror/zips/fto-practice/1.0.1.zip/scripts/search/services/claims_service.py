import asyncio
import logging
import sys
from typing import List
import os

# 确保能引入同目录的模块
from search.api_clients.base_client import BasePatentClient
from search.services.patent_service import PatentService

logger = logging.getLogger(__name__)

class ClaimsService:
    """
    负责权利要求拉取业务流的编排
    """
    def __init__(self, api_client: BasePatentClient):
        self.api_client = api_client

    async def fetch_patent_claims(self, patent_number: str) -> str:
        loop = asyncio.get_event_loop()
        max_retries = 3
        
        for attempt in range(max_retries):
            try:
                patent_data = await loop.run_in_executor(None, self.api_client.get_standardized_patent_data, patent_number)
                full_text = PatentService.extract_claims_text(patent_data, patent_number)
                return full_text
            except Exception as e:
                if attempt < max_retries - 1:
                    logger.warning(f"⚠️ 获取专利 {patent_number} 权利要求失败 ({e})，正在进行第 {attempt + 1} 次重试...")
                    await asyncio.sleep(1)
                else:
                    logger.error(f"❌ 获取专利 {patent_number} 权利要求最终失败: {e}")
                    return ""

    async def data_fetcher_worker(self, queue: asyncio.Queue, result_list: list):
        while True:
            patent_item = await queue.get()
            if patent_item is None:
                queue.task_done()
                break
                
            patent_number = patent_item.get("publication_number")
            logger.info(f"   ⏳ 正在拉取专利 {patent_number} 的权利要求...")
            
            claims_text = await self.fetch_patent_claims(patent_number)
            
            result_item = patent_item.copy()
            result_item["claims_text"] = claims_text
            result_list.append(result_item)
                
            queue.task_done()

    async def execute_claims_pipeline(self, target_pool: List[dict], limit: int = 50) -> list:
        if not target_pool:
            logger.warning("⚠️ 警告: 靶点池为空，没有需要处理的专利。")
            return []
            
        if limit and len(target_pool) > limit:
            logger.warning(f"⚠️ 提示: 靶点池共有 {len(target_pool)} 条数据，为节省时间，本次仅拉取前 {limit} 条。")
            target_pool = target_pool[:limit]
            
        logger.info(f"🚀 开始并发拉取权利要求数据，共 {len(target_pool)} 条...")
        
        fetch_queue = asyncio.Queue()
        result_list = []
        
        for item in target_pool:
            fetch_queue.put_nowait(item)
            
        FETCH_CONCURRENCY = 5
        fetchers = [asyncio.create_task(self.data_fetcher_worker(fetch_queue, result_list)) for _ in range(FETCH_CONCURRENCY)]
        
        await fetch_queue.join()
        for _ in range(FETCH_CONCURRENCY):
            await fetch_queue.put(None)
            
        logger.info(f"🎉 权利要求拉取完成！共成功获取 {len(result_list)} 条。")
        return result_list
