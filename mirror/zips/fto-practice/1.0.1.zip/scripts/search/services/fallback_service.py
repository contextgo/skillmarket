import os
import re
from typing import Any, Dict

import requests

from search.api_clients.mineru_client import MinerUClient
from search.parsers.pdf_patent_parser import extract_biblio_from_front_page, extract_claims_from_pdf


def _safe_patent_parts(patent_number: str) -> tuple[str, str, str]:
    """将公开号解析为 country/number/kind，失败时返回保守默认值。"""
    safe = patent_number
    if "." not in safe:
        match = re.match(r"^([A-Z]{2})(\d+)([A-Z1-9]*)$", safe)
        if match:
            safe = f"{match.group(1)}.{match.group(2)}.{match.group(3)}"

    match = re.match(r"^([A-Z]{2})\.(\d+)\.([A-Z1-9]*)$", safe)
    if match:
        return match.group(1), match.group(2), match.group(3) or "A"
    return "CN", safe.replace("CN", "").replace(".", ""), "A"


def _build_output_paths(patent_number: str) -> Dict[str, str]:
    out_dir = os.path.join("output", patent_number)
    os.makedirs(out_dir, exist_ok=True)
    return {
        "claims_pdf": os.path.join(out_dir, "claims.pdf"),
        "front_page_pdf": os.path.join(out_dir, "front_page.pdf"),
    }


class PdfFallbackService:
    """
    provider-agnostic PDF fallback 编排服务：
    - 客户端只提供认证与基础 URL；
    - 下载、PDF->MinerU 解析流程在此统一处理，避免 client 内部堆叠重逻辑。
    """

    def __init__(self, mineru_client: Any = None):
        self.mineru_client = mineru_client or MinerUClient()

    def _download_first_page_pdf(self, api_client: Any, patent_number: str, output_path: str) -> bool:
        country, number, kind = _safe_patent_parts(patent_number)
        headers = {"Authorization": f"Bearer {api_client.authenticate()}", "Accept": "application/pdf"}
        page_url = f"{api_client.base_url}/published-data/images/{country}/{number}/{kind}/fullimage?Range=1"
        resp = requests.get(page_url, headers=headers, timeout=20)
        if resp.status_code != 200:
            return False
        with open(output_path, "wb") as f:
            f.write(resp.content)
        return True

    def resolve_claims_with_pdf(self, api_client: Any, patent_number: str) -> str:
        paths = _build_output_paths(patent_number)
        if not self._download_first_page_pdf(api_client, patent_number, paths["claims_pdf"]):
            return ""
        return extract_claims_from_pdf(patent_number, paths["claims_pdf"], self.mineru_client)

    def resolve_biblio_with_pdf(self, api_client: Any, patent_number: str) -> Dict[str, Any]:
        paths = _build_output_paths(patent_number)
        if not self._download_first_page_pdf(api_client, patent_number, paths["front_page_pdf"]):
            return {}
        return extract_biblio_from_front_page(patent_number, paths["front_page_pdf"], self.mineru_client)
