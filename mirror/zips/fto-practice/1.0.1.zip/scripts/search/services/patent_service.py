import re
import logging
import os
import sys

# 确保能引入同目录的模块
from core.models.patent_data import PatentData
from search.api_clients.base_client import BasePatentClient

logger = logging.getLogger(__name__)

class PatentService:
    """
    负责核心业务逻辑的处理（如权利要求清洗、提取、截断、兜底等）。
    """
    @staticmethod
    def extract_claims_text(patent_data: PatentData, patent_number: str) -> str:
        """
        基于一系列策略从专利数据中提取、组装并清洗用于下游大模型分析的权利要求文本。
        """
        if not patent_data:
            return ""
            
        indep_claims = []
        
        # 策略 1：信任 API 提供的 is_independent 字段（如果有且可靠）
        for claim in getattr(patent_data, 'claims', []):
            if getattr(claim, 'is_independent', False):
                indep_claims.append(f"[{claim.claim_number}] {claim.claim_text}")
                
        # 策略 2：如果 API 字段失效，使用正则表达式兜底识别独立权利要求
        if not indep_claims and getattr(patent_data, 'claims', []):
            for claim in patent_data.claims:
                text = getattr(claim, 'claim_text', '')
                # 常见从属权利要求的特征词（中英文兼容）
                dependent_keywords = re.compile(r'(根据|如)权利要求\s*\d+|according to claim|The (method|system|device) of claim', re.IGNORECASE)
                
                # 如果没有包含引用词，极大概率是独立权利要求
                if not dependent_keywords.search(text):
                    indep_claims.append(f"[{claim.claim_number}] {text}")
                    
        # 兜底策略：如果连正则也找不出，把全部权项拼起来
        if getattr(patent_data, 'claims', []):
            full_text = "\n".join(indep_claims) if indep_claims else "\n".join([f"[{c.claim_number}] {c.claim_text}" for c in patent_data.claims])
        else:
            full_text = ""
        
        # 如果权利要求列表本身就是空的，则使用专利的摘要进行兜底
        if not full_text.strip() and hasattr(patent_data, 'bibliography') and patent_data.bibliography and getattr(patent_data.bibliography, 'abstract', None):
            logger.info(f"   ⚠️ 专利 {patent_number} 没有找到权利要求，已使用【摘要】作为兜底文本替代。")
            full_text = "[摘要替代权利要求] " + patent_data.bibliography.abstract
        elif not full_text.strip():
            logger.warning(f"   ⚠️ 专利 {patent_number} 既没有权利要求也没有摘要！")
        
        # 极端防爆：保留前 30000 和最后 10000（首尾兼顾，防大模型爆 Token）
        if len(full_text) > 40000:
            full_text = full_text[:30000] + "\n...[中间截断]...\n" + full_text[-10000:]
            
        return full_text
