import os
import re
from typing import Any, Dict, Optional

import requests

from search.api_clients.mineru_client import MinerUClient


def _extract_markdown(mineru_client: Any, pdf_path: str) -> str:
    # 统一从 MinerU 返回值中提取 markdown 文本，避免上层重复解析 data 结构。
    result = mineru_client.agent_parse_file_lightweight(pdf_path)
    return result.get("data", {}).get("markdown", "") if isinstance(result, dict) else ""


def extract_claims_from_pdf(patent_number: str, pdf_path: str, mineru_client: Any) -> str:
    """将 PDF 交给 MinerU 解析，并返回可直接用于 claims_text 的纯文本。"""
    markdown = _extract_markdown(mineru_client, pdf_path)
    return markdown.strip()


def extract_biblio_from_front_page(
    patent_number: str, pdf_path: str, mineru_client: Any, llm_client: Optional[Any] = None
) -> Dict[str, Any]:
    """从专利扉页 PDF 提取 title/abstract 等著录项的最小字段字典。"""
    markdown = _extract_markdown(mineru_client, pdf_path)
    title = ""
    abstract = ""
    for line in markdown.splitlines():
        text = line.strip()
        if text.lower().startswith("title:"):
            title = text.split(":", 1)[1].strip()
        if text.lower().startswith("abstract:"):
            abstract = text.split(":", 1)[1].strip()
    return {
        "title": title,
        "abstract": abstract,
        "publication_date": "",
        "application_date": "",
        "assignees": [],
    }


def _safe_patent_parts(patent_number: str) -> tuple[str, str, str]:
    """将公开号解析为 country/number/kind，失败时返回保守默认值。"""
    safe = patent_number
    if "." not in safe:
        match = re.match(r"^([A-Z]{2})(\d+)([A-Z1-9]*)$", safe)
        if match:
            safe = f"{match.group(1)}.{match.group(2)}.{match.group(3)}"

    match = re.match(r"^([A-Z]{2})\.(\d+)\.([A-Z1-9]*)$", safe)
    if match:
        return match.group(1), match.group(2), match.group(3) or "A"
    return "CN", safe.replace("CN", "").replace(".", ""), "A"


# 统一 PDF 中间产物路径构造，避免 output 路径拼接散落在多个函数里。
def _build_output_paths(patent_number: str) -> Dict[str, str]:
    out_dir = os.path.join("output", patent_number)
    os.makedirs(out_dir, exist_ok=True)
    return {
        "out_dir": out_dir,
        "claims_pdf": os.path.join(out_dir, "claims.pdf"),
        "front_page_pdf": os.path.join(out_dir, "front_page.pdf"),
    }


def get_claims_text_via_epo_pdf(epo_client: Any, patent_number: str) -> str:
    """
    EPO PDF claims 兜底入口：
    - 下载一页可用 PDF（最小 Green 版本先尝试第 1 页）；
    - 交由 MinerU 解析；
    - 返回 claims_text 字符串。
    """
    country, number, kind = _safe_patent_parts(patent_number)
    paths = _build_output_paths(patent_number)
    pdf_path = paths["claims_pdf"]

    headers = {"Authorization": f"Bearer {epo_client.authenticate()}", "Accept": "application/pdf"}
    page_url = f"{epo_client.base_url}/published-data/images/{country}/{number}/{kind}/fullimage?Range=1"
    resp = requests.get(page_url, headers=headers, timeout=20)
    if resp.status_code != 200:
        return ""
    with open(pdf_path, "wb") as f:
        f.write(resp.content)

    mineru = MinerUClient()
    return extract_claims_from_pdf(patent_number, pdf_path, mineru)


def get_biblio_via_epo_pdf(epo_client: Any, patent_number: str) -> Dict[str, Any]:
    """
    EPO 扉页著录项兜底入口：
    - 下载扉页 PDF；
    - 调用 MinerU 抽取文本；
    - 解析最小 biblio 字段返回。
    """
    country, number, kind = _safe_patent_parts(patent_number)
    paths = _build_output_paths(patent_number)
    pdf_path = paths["front_page_pdf"]

    headers = {"Authorization": f"Bearer {epo_client.authenticate()}", "Accept": "application/pdf"}
    page_url = f"{epo_client.base_url}/published-data/images/{country}/{number}/{kind}/fullimage?Range=1"
    resp = requests.get(page_url, headers=headers, timeout=20)
    if resp.status_code != 200:
        return {}
    with open(pdf_path, "wb") as f:
        f.write(resp.content)

    mineru = MinerUClient()
    return extract_biblio_from_front_page(patent_number, pdf_path, mineru)
