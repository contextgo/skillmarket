"""PDF and text parsers for patent data extraction."""

