import os
import sys
import json
import logging
import argparse
import asyncio

# 确保能引入同目录的模块以及上一级的 core 模块
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from search.api_clients.factory import ApiClientFactory
from search.services.search_service import SearchService
from search.services.claims_service import ClaimsService

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
logger = logging.getLogger(__name__)

def handle_single_search(args):
    """查询单篇专利"""
    logger.info(f"使用数据源: {args.provider}, 查询专利: {args.patent}")
    try:
        client = ApiClientFactory.create(provider_name=args.provider)
        biblio = client.get_patent_bibliography(args.patent)
        claims = client.get_patent_claims(args.patent)
        
        result = {
            "bibliography": biblio,
            "claims": claims
        }
        
        os.makedirs(args.output, exist_ok=True)
        out_path = os.path.join(args.output, f"{args.patent}_{args.provider}_result.json")
        with open(out_path, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
            
        logger.info(f"✅ 专利查询成功！结果已保存至 {out_path}")
    except Exception as e:
        logger.error(f"❌ 专利查询失败: {e}")

def handle_bulk_search(args):
    """批量宏观检索"""
    logger.info(f"使用数据源: {args.provider}, 执行批量检索: {args.query}")
    try:
        client = ApiClientFactory.create(provider_name=args.provider)
        service = SearchService(client)
        
        result = service.execute_search(query=args.query, max_fetch=args.max_fetch)
        
        os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump({
                "hit_count": result.hit_count,
                "patent_numbers": result.patent_numbers
            }, f, ensure_ascii=False, indent=2)
            
        logger.info(f"✅ 批量检索成功！命中数: {result.hit_count}, 获取数量: {len(result.patent_numbers)}")
        logger.info(f"结果已保存至 {args.output}")
    except Exception as e:
        logger.error(f"❌ 批量检索失败: {e}")

async def handle_fetch_claims(args):
    """批量抓取并补充权利要求"""
    logger.info(f"使用数据源: {args.provider}, 开始抓取权利要求")
    try:
        target_pool = []
        if not args.input or not os.path.exists(args.input):
            logger.error(f"输入文件不存在: {args.input}")
            return

        with open(args.input, 'r', encoding='utf-8') as f:
            data = json.load(f)

        # 兼容两种输入格式：
        # 1. {"patent_numbers": ["CN123", "US456"]}
        # 2. [{"publication_number": "CN123"}, ...]
        if isinstance(data, dict) and "patent_numbers" in data:
            target_pool = [{"publication_number": pn} for pn in data["patent_numbers"]]
        elif isinstance(data, list):
            target_pool = data
        else:
            logger.error("输入 JSON 格式不被支持。")
            return
            
        client = ApiClientFactory.create(provider_name=args.provider)
        service = ClaimsService(client)
        
        result_list = await service.execute_claims_pipeline(target_pool=target_pool, limit=args.limit)
        
        os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(result_list, f, ensure_ascii=False, indent=2)

        logger.info(f"✅ 权利要求抓取完成！结果已保存至 {args.output}")
    except Exception as e:
        logger.error(f"❌ 权利要求抓取失败: {e}")

async def handle_sample(args):
    """一键抽样：先检索获取公开号，再抓取指定数量样本的权利要求和摘要"""
    logger.info(f"使用数据源: {args.provider}, 执行抽样检索: {args.query}")
    try:
        client = ApiClientFactory.create(provider_name=args.provider)
        search_service = SearchService(client)
        
        # 第一步：获取总数和前 N 个专利号
        search_result = search_service.execute_search(query=args.query, max_fetch=args.sample_size)
        logger.info(f"✅ 检索成功！总命中数: {search_result.hit_count}, 准备抽取 {len(search_result.patent_numbers)} 篇样本")
        
        # 第二步：抓取详情（权利要求和摘要）
        target_pool = [{"publication_number": pn} for pn in search_result.patent_numbers]
        claims_service = ClaimsService(client)
        sample_results = await claims_service.execute_claims_pipeline(target_pool=target_pool, limit=args.sample_size)
        
        final_output = {
            "hit_count": search_result.hit_count,
            "query": args.query,
            "samples": sample_results
        }
        
        os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(final_output, f, ensure_ascii=False, indent=2)
            
        logger.info(f"✅ 抽样完成！结果已保存至 {args.output}")
    except Exception as e:
        logger.error(f"❌ 抽样检索失败: {e}")


def main():
    parser = argparse.ArgumentParser(description="专利数据库查询工具 (Agent Skill)")
    subparsers = parser.add_subparsers(dest="command", required=True, help="要执行的子命令")
    
    # 1. 查询单篇专利详情
    parser_single = subparsers.add_parser("single", help="查询单篇专利的基础信息和权利要求")
    parser_single.add_argument("--provider", type=str, required=True, choices=["zhihuiya", "lens", "epo", "baiten"], help="专利数据库提供商")
    parser_single.add_argument("--patent", type=str, required=True, help="目标专利公开号 (例如 CN106627239B)")
    parser_single.add_argument("--output", type=str, default="output/patent_search_results", help="结果输出目录")
    
    # 2. 批量执行检索式，拉取专利号列表
    parser_bulk = subparsers.add_parser("bulk_search", help="执行检索式，批量获取命中的专利公开号")
    parser_bulk.add_argument("--provider", type=str, required=True, choices=["zhihuiya", "lens", "epo", "baiten"], help="专利数据库提供商")
    parser_bulk.add_argument("--query", type=str, required=True, help="要执行的布尔检索式")
    parser_bulk.add_argument("--max_fetch", type=int, default=100, help="最多拉取多少条数据")
    parser_bulk.add_argument("--output", type=str, default="output/bulk_search_results.json", help="结果输出 JSON 文件路径")
    
    # 3. 批量补全权利要求文本
    parser_claims = subparsers.add_parser("fetch_claims", help="根据公开号列表批量抓取并清洗权利要求文本")
    parser_claims.add_argument("--provider", type=str, required=True, choices=["zhihuiya", "lens", "epo", "baiten"], help="专利数据库提供商")
    parser_claims.add_argument("--input", type=str, required=True, help="包含公开号的输入 JSON 文件路径")
    parser_claims.add_argument("--limit", type=int, default=50, help="最多处理多少条")
    parser_claims.add_argument("--output", type=str, default="output/enriched_patents.json", help="输出 JSON 文件路径")
    
    # 4. 一键抽样评估
    parser_sample = subparsers.add_parser("sample", help="一键抽样：执行检索并返回指定数量的样本详情（摘要与权利要求）")
    parser_sample.add_argument("--provider", type=str, required=True, choices=["zhihuiya", "lens", "epo", "baiten"], help="专利数据库提供商")
    parser_sample.add_argument("--query", type=str, required=True, help="要执行的布尔检索式")
    parser_sample.add_argument("--sample_size", type=int, default=30, help="要抽样的样本数量")
    parser_sample.add_argument("--output", type=str, default="output/sample_results.json", help="结果输出 JSON 文件路径")

    args = parser.parse_args()
    
    if args.command == "single":
        handle_single_search(args)
    elif args.command == "bulk_search":
        handle_bulk_search(args)
    elif args.command == "fetch_claims":
        asyncio.run(handle_fetch_claims(args))
    elif args.command == "sample":
        asyncio.run(handle_sample(args))

if __name__ == "__main__":
    main()
