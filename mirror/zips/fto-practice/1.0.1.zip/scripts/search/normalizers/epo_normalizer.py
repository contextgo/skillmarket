from typing import Any, Dict

from core.models.patent_data import PatentBibliography, PatentClaim, PatentData
from search.normalizers.common_normalizer import normalize_claims_text, pick_first_non_empty


def _safe_get_title(raw_biblio: Dict[str, Any]) -> str:
    doc = (
        raw_biblio.get("ops:world-patent-data", {})
        .get("exchange-documents", {})
        .get("exchange-document", {})
    )
    bib = doc.get("bibliographic-data", {})
    titles = bib.get("invention-title", [])
    if isinstance(titles, dict):
        titles = [titles]

    en_title = next((t.get("$", "") for t in titles if t.get("@lang") == "en"), "")
    if en_title:
        return en_title
    return titles[0].get("$", "") if titles else ""


def _safe_get_assignees(raw_biblio: Dict[str, Any]) -> list[str]:
    doc = (
        raw_biblio.get("ops:world-patent-data", {})
        .get("exchange-documents", {})
        .get("exchange-document", {})
    )
    bib = doc.get("bibliographic-data", {})
    applicants = bib.get("parties", {}).get("applicants", {}).get("applicant", [])
    if isinstance(applicants, dict):
        applicants = [applicants]
    return [
        a.get("applicant-name", {}).get("name", {}).get("$", "")
        for a in applicants
        if a.get("applicant-name", {}).get("name", {}).get("$", "")
    ]


def normalize_epo_raw_to_patent_data(
    raw_biblio: Dict[str, Any], raw_claims: Dict[str, Any], patent_number: str
) -> PatentData:
    """将 EPO 原始结构映射为统一 PatentData，供步骤4/5复用。"""
    title = pick_first_non_empty(_safe_get_title(raw_biblio), "EPO Title Placeholder")
    assignees = _safe_get_assignees(raw_biblio)
    claims_text = normalize_claims_text(raw_claims.get("xml_response", "") if isinstance(raw_claims, dict) else "")

    data = PatentData(
        source_platform="epo_ops",
        raw_source_data={"bibliography": raw_biblio, "claims": raw_claims},
        bibliography=PatentBibliography(
            patent_number=patent_number,
            title=title,
            abstract="",
            application_date="",
            publication_date="",
            assignees=assignees,
            inventors=[],
            ipc_classes=[],
        ),
        claims=[],
    )
    if claims_text:
        data.claims.append(PatentClaim(claim_number="1", claim_text=claims_text, is_independent=True))
    return data
