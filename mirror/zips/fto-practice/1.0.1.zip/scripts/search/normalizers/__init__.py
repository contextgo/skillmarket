"""Data normalizers for patent providers."""

