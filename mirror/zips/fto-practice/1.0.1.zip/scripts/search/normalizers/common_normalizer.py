from typing import Any, Dict, List


# 统一清洗文本字段：避免 None、前后空白和异常类型在下游扩散。
def clean_text(value: Any) -> str:
    if value is None:
        return ""
    return str(value).strip()


# 统一兜底策略：按顺序返回第一个非空值，减少重复 if/else 分支。
def pick_first_non_empty(*values: Any) -> str:
    for value in values:
        text = clean_text(value)
        if text:
            return text
    return ""


# 统一权利要求文本归一化：便于后续写库和步骤5直接消费。
def normalize_claims_text(value: Any) -> str:
    text = clean_text(value)
    if not text:
        return ""
    return text.replace("\r\n", "\n").replace("\r", "\n").strip()


# 统一申请人字段归一化：支持 list 或多分隔符字符串输入，输出稳定 list[str]。
def normalize_assignees(value: Any) -> List[str]:
    if isinstance(value, list):
        return [clean_text(v) for v in value if clean_text(v)]
    if isinstance(value, str):
        text = clean_text(value)
        if not text:
            return []
        for sep in (";", "；", ",", "，"):
            if sep in text:
                return [clean_text(part) for part in text.split(sep) if clean_text(part)]
        return [text]
    return []


# 统一构建入库标准结构：供步骤4多入口(API/Excel/PDF)共用，避免各处拼字段。
def build_standard_storage_record(record: Dict[str, Any], source_platform: str) -> Dict[str, Any]:
    pub_num = pick_first_non_empty(record.get("publication_number"), record.get("公开(公告)号"))
    # raw_data 允许上游传入更“纯净”的原始响应，避免把标准字段重复嵌套进 raw_data。
    raw_data = record.get("raw_data") if isinstance(record.get("raw_data"), dict) else record
    return {
        "publication_number": clean_text(pub_num),
        "title": clean_text(record.get("title", "")),
        "abstract": clean_text(record.get("abstract", "")),
        "assignees": normalize_assignees(record.get("assignees", "")),
        "publication_date": clean_text(record.get("publication_date", "")),
        "claims_text": normalize_claims_text(record.get("claims_text", "")),
        "legal_status": clean_text(record.get("legal_status", "")),
        "source_platform": source_platform,
        "raw_data": raw_data,
    }


def build_standard_storage_record_from_patent_data(patent_data: Any, publication_number: str, source_platform: str) -> Dict[str, Any]:
    """
    将 API 的 PatentData 模型归一为统一入库记录，供 03->DB 主链使用。

    输入:
    - patent_data: 各 provider 返回的统一 PatentData（字段可能缺失）
    - publication_number/source_platform: 用于兜底和写库来源标识

    输出:
    - 与 Excel/PDF 导入一致的标准入库结构
    """
    biblio = getattr(patent_data, "bibliography", None)
    legal = getattr(patent_data, "legal_status", None)
    claims = list(getattr(patent_data, "claims", []) or [])

    lines: list[str] = []
    for c in claims:
        no = clean_text(getattr(c, "claim_number", "") or "")
        txt = clean_text(getattr(c, "claim_text", "") or "")
        if txt:
            lines.append(f"[{no}] {txt}" if no else txt)

    record = {
        "publication_number": publication_number,
        "title": clean_text(getattr(biblio, "title", "") if biblio else ""),
        "abstract": clean_text(getattr(biblio, "abstract", "") if biblio else ""),
        "publication_date": clean_text(getattr(biblio, "publication_date", "") if biblio else ""),
        "assignees": list(getattr(biblio, "assignees", []) or []) if biblio else [],
        "claims_text": "\n".join(lines) if lines else "",
        "legal_status": clean_text(getattr(legal, "status_description", "") if legal else ""),
        "raw_data": getattr(patent_data, "raw_source_data", {}) if hasattr(patent_data, "raw_source_data") else {},
    }
    return build_standard_storage_record(record, source_platform=source_platform)
