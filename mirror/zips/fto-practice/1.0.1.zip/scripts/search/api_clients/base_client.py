from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, Tuple
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from core.models.patent_data import PatentData, UnifiedSearchResult


class PatentAPIError(Exception):
    """专利 API 调用的基础异常类"""
    pass

class AuthenticationError(PatentAPIError):
    """认证失败异常"""
    pass

class ResourceNotFoundError(PatentAPIError):
    """未找到专利数据异常"""
    pass


class BasePatentClient(ABC):
    """
    所有专利数据库 API 客户端的父类
    定义了从各个专利数据库进行数据获取的通用方法
    """

    def __init__(self, timeout: int = 15):
        """
        初始化客户端，设置具有重试机制的 requests Session。
        :param timeout: 全局默认超时时间，单位秒
        """
        self.timeout = timeout
        self.session = requests.Session()
        retries = Retry(total=3, backoff_factor=0.3, status_forcelist=[500, 502, 503, 504])
        self.session.mount('http://', HTTPAdapter(max_retries=retries))
        self.session.mount('https://', HTTPAdapter(max_retries=retries))

    def close(self):
        """关闭当前的 session，释放连接池资源"""
        if self.session:
            self.session.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    @abstractmethod
    def authenticate(self) -> Optional[str]:
        """
        获取或刷新权限令牌 (Token)。
        如果 API 使用静态 Token (如 Lens API)，可以返回静态 Token 或 None。
        """
        pass

    @abstractmethod
    def get_patent_claims(self, patent_number: str) -> Dict[str, Any]:
        """
        获取指定专利的权利要求
        :param patent_number: 专利公开号 (例如: CN108977442B)
        :return: 包含权利要求数据的字典
        """
        pass

    @abstractmethod
    def get_patent_description(self, patent_number: str) -> Dict[str, Any]:
        """
        获取专利说明书全文
        :param patent_number: 专利公开号
        :return: 包含说明书文本数据的字典
        """
        pass

    @abstractmethod
    def get_patent_bibliography(self, patent_number: str) -> Dict[str, Any]:
        """
        获取专利著录项目信息，包含申请号、申请日、公开日、申请人、标题等
        :param patent_number: 专利公开号
        :return: 包含著录项目数据的字典
        """
        pass

    @abstractmethod
    def get_patent_legal_status(self, patent_number: str) -> Dict[str, Any]:
        """
        获取专利法律状态
        :param patent_number: 专利公开号
        :return: 包含法律状态数据的字典
        """
        pass

    @abstractmethod
    def search_patents(self, query: str, limit: int = 100) -> Dict[str, Any]:
        """
        检索式检索专利
        :param query: 检索式 (各个数据库的具体语法可能不同)
        :param limit: 返回结果的最大数量
        :return: 包含检索结果的原生字典
        """
        pass

    @abstractmethod
    def execute_unified_search(self, query: str, limit: int = 100, offset: int = 0) -> UnifiedSearchResult:
        """
        执行统一结构的专利检索
        :param query: 检索式
        :param limit: 返回结果的最大数量
        :param offset: 检索结果的偏移量
        :return: 统一的检索结果模型 (UnifiedSearchResult)
        """
        pass

    @abstractmethod
    def get_standardized_patent_data(self, patent_number: str) -> PatentData:
        """
        获取统一专利数据模型
        :param patent_number: 专利公开号
        :return: 统一的 PatentData 结构
        """
        pass
