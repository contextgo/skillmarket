import os
import json
import base64
import time
import requests
import logging
from typing import Dict, Any, Optional

from search.api_clients.base_client import BasePatentClient, PatentAPIError, AuthenticationError, ResourceNotFoundError
from core.models.patent_data import PatentData, PatentBibliography, PatentLegalStatus, PatentClaim, UnifiedSearchResult

logger = logging.getLogger(__name__)

DEFAULT_DB_CONFIG_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))), 
    "assets", "patent_database_api", "config.json"
)

class ZhihuiyaClient(BasePatentClient):
    """
    智慧芽开放平台 API 客户端 (MVP)
    负责统一处理认证(Token获取与刷新)和 API 调用
    """
    
    def __init__(self, client_id: Optional[str] = None, client_secret: Optional[str] = None, timeout: int = 15):
        super().__init__(timeout=timeout)
        self.client_id = client_id
        self.client_secret = client_secret
        
        if not self.client_id or not self.client_secret:
            raise AuthenticationError("Client ID 或 Client Secret 未配置，请在统一配置解析器中配置。")
            
        self.token = None
        self.token_expires_at = 0  # 记录 Token 的过期时间戳
        self.base_url = "https://connect.zhihuiya.com"

    def _get_auth_header(self) -> str:
        """生成基于 Base64 的 Basic Auth 凭证"""
        credentials = f"{self.client_id}:{self.client_secret}"
        encoded_credentials = base64.b64encode(credentials.encode('utf-8')).decode('utf-8')
        return f"Basic {encoded_credentials}"

    def authenticate(self) -> str:
        """
        获取权限令牌 (Token)。
        如果 Token 仍然有效，则直接返回；否则重新请求。
        """
        # 提前 60 秒刷新，避免边界情况过期
        if self.token and time.time() < (self.token_expires_at - 60):
            return self.token

        url = f"{self.base_url}/oauth/token"
        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
            # 注意：某些 API 网关要求 Basic Auth，另一些则支持直接传入 client_id 等。
            # 根据智慧芽官方文档，这里也可以使用 HTTP Basic 认证（-u client_id:client_secret）
            "Authorization": self._get_auth_header()
        }
        data = {
            "grant_type": "client_credentials"
        }

        print("🔄 正在向智慧芽开放平台请求 Token...")
        try:
            response = self.session.post(url, headers=headers, data=data, timeout=self.timeout)
            response.raise_for_status()
        except requests.exceptions.RequestException as e:
            raise AuthenticationError(f"获取 Token 失败! 网络错误: {e}")
        
        if response.status_code == 200:
            result = response.json()
            # 智慧芽的返回结构是 {"status": true, "error_code": 0, "data": {"token": "...", "expires_in": "1799"}}
            data = result.get("data", {})
            self.token = data.get("token") or result.get("token") or result.get("access_token")
            if not self.token:
                 logger.warning(f"警告：成功获取到响应，但未找到 token 字段。完整响应内容: {result}")
            # token 默认有效期 30 分钟 (1799秒)
            expires_in = int(data.get("expires_in", 1799))
            self.token_expires_at = time.time() + expires_in
            print(f"✅ Token 获取成功！有效期: {expires_in} 秒")
            return self.token
        else:
            raise AuthenticationError(f"获取 Token 失败! HTTP {response.status_code}: {response.text}")

    def get_patent_claims(self, patent_number: str) -> Dict[str, Any]:
        """
        调用业务接口示例：获取指定专利的权利要求 ([P018]权利要求)
        :param patent_number: 专利公开号 (例如: CN108977442B)
        """
        return self.general_get("/basic-patent-data/claim-data", {"patent_number": patent_number})

    def get_patent_description(self, patent_number: str) -> Dict[str, Any]:
        """
        获取专利说明书全文 ([P019]说明书)
        :param patent_number: 专利公开号
        :return: 包含说明书文本数据的字典
        """
        # 注意: 具体接口路径需根据智慧芽最新文档确认，此处假设为 description-data 或 full-text
        return self.general_get("/basic-patent-data/description-data", {"patent_number": patent_number})

    def get_patent_bibliography(self, patent_number: str) -> Dict[str, Any]:
        """
        获取专利著录项目信息 ([P012]著录项目)，包含申请号、申请日、公开日、申请人、标题等
        """
        return self.general_get("/basic-patent-data/bibliography", {"patent_number": patent_number})

    def get_patent_legal_status(self, patent_number: str) -> Dict[str, Any]:
        """
        获取专利法律状态 ([P013]法律状态)
        """
        return self.general_get("/basic-patent-data/legal-status", {"patent_number": patent_number})

    def search_patents(self, query: str, limit: int = 100, offset: int = 0) -> Dict[str, Any]:
        """
        [P075] 检索式检索专利嵌套版
        支持布尔逻辑、IPC、关键词、申请人等嵌套查询。
        根据 API 文档，该接口路径为 /search/patent/nested-search-patent
        参数为 query_text, limit 等
        """
        payload = {
            "query_text": query,
            "limit": limit,
            "offset": offset
        }
        return self.general_post("/search/patent/nested-search-patent", data=payload)

    def execute_aggregate_search(self, query: str, group_by: str = "assignee") -> dict:
        """
        调用智慧芽的统计聚合API
        group_by: 'assignee' (竞争对手), 'ipc' (分类号), 'pub_year' (年份)
        注意：此处为根据文档建议的 mock 实现/扩展。实际需参照真实聚合接口 /search/patent/aggs-search-patent
        """
        payload = {
            "query_text": query,
            "group_by": group_by
        }
        try:
            # 尝试调用真实聚合接口，如果失败则返回空或模拟数据
            res = self.general_post("/search/patent/aggs-search-patent", data=payload)
            if res and res.get("status") and res.get("data"):
                # 假设返回结果中有 buckets 或类似的统计数组
                return res.get("data", {})
            return {}
        except Exception as e:
            logger.warning(f"聚合 API 调用失败或未实现 ({e})，返回空统计字典。")
            return {}

    def execute_unified_search(self, query: str, limit: int = 100, offset: int = 0) -> UnifiedSearchResult:
        """
        执行统一结构的专利检索 (智慧芽实现)
        """
        raw_result = self.search_patents(query, limit, offset)
        
        hit_count = 0
        patent_numbers = []
        
        if raw_result and raw_result.get("status"):
            data = raw_result.get("data", {})
            if data:
                hit_count = data.get("num_found", 0)
                patents_list = data.get("results") or data.get("patents") or data.get("list") or []
                for item in patents_list:
                    pn = item.get("publication_number") or item.get("pn")
                    if pn:
                        patent_numbers.append(pn)
                        
        return UnifiedSearchResult(
            hit_count=hit_count,
            patent_numbers=patent_numbers,
            raw_response=raw_result
        )

    def general_get(self, endpoint: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        通用的 GET 调用方法，用于后续扩展其他接口
        :param endpoint: API 路径，例如 '/basic-patent-data/simple-legal-status'
        """
        token = self.authenticate()
        url = f"{self.base_url}{endpoint}"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}"
        }
        
        if params is None:
            params = {}
        # 自动补全 apikey
        if "apikey" not in params:
            params["apikey"] = self.client_id
            
        try:
            response = self.session.get(url, headers=headers, params=params, timeout=self.timeout)
            response.raise_for_status()
        except requests.exceptions.RequestException as e:
            raise PatentAPIError(f"调用 {endpoint} 失败! 网络错误: {e}")
        
        if response.status_code == 200:
            return response.json()
        else:
            raise PatentAPIError(f"调用 {endpoint} 失败! HTTP {response.status_code}: {response.text}")

    def general_post(self, endpoint: str, data: Dict[str, Any], params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """通用的 POST 调用方法"""
        token = self.authenticate()
        url = f"{self.base_url}{endpoint}"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}"
        }
        
        if params is None:
            params = {}
        if "apikey" not in params:
            params["apikey"] = self.client_id
            
        try:
            response = self.session.post(url, headers=headers, params=params, json=data, timeout=self.timeout)
            response.raise_for_status()
        except requests.exceptions.RequestException as e:
            raise PatentAPIError(f"调用 {endpoint} 失败! 网络错误: {e}")
        
        if response.status_code == 200:
            return response.json()
        else:
            raise PatentAPIError(f"调用 {endpoint} 失败! HTTP {response.status_code}: {response.text}")

    def get_standardized_patent_data(self, patent_number: str) -> PatentData:
        """
        获取统一专利数据模型 (智慧芽实现)
        """
        patent_data = PatentData(
            source_platform="zhihuiya",
            raw_source_data={}
        )

        try:
            biblio_raw = self.get_patent_bibliography(patent_number)
            if isinstance(biblio_raw, list):
                biblio_raw = biblio_raw[0] if biblio_raw else {}
                
            patent_data.raw_source_data['bibliography'] = biblio_raw
            doc = biblio_raw.get('data', {}) or {}
            if isinstance(doc, list):
                doc = doc[0] if doc else {}
                
            patent_data.bibliography = PatentBibliography(
                patent_number=doc.get('apn') or patent_number,
                application_number=doc.get('apn') or patent_number,
                title=doc.get('title') or '',
                abstract=doc.get('abstract') or '',
                application_date=doc.get('apd') or '',
                publication_date=doc.get('pbd') or '',
                assignees=doc.get('assignee') or [],
                inventors=doc.get('inventor') or [],
                ipc_classes=doc.get('ipc') or []
            )
        except Exception as e:
            logger.error(f"智慧芽 API 获取著录项失败: {e}")

        try:
            legal_raw = self.get_patent_legal_status(patent_number)
            if isinstance(legal_raw, list):
                legal_raw = legal_raw[0] if legal_raw else {}
            patent_data.raw_source_data['legal_status'] = legal_raw
            status_doc = legal_raw.get('data', {}) or {}
            if isinstance(status_doc, list):
                status_doc = status_doc[0] if status_doc else {}
                
            patent_data.legal_status = PatentLegalStatus(
                status_code=status_doc.get('lse', 'unknown'),
                status_description=status_doc.get('lse', '未知法律状态'),
                date=status_doc.get('lssd', ''),
                is_active=status_doc.get('lse', '').lower() in ['有效', 'active', 'granted']
            )
        except Exception as e:
            logger.error(f"智慧芽 API 获取法律状态失败: {e}")

        try:
            claims_raw = self.get_patent_claims(patent_number)
            if isinstance(claims_raw, list):
                claims_raw = claims_raw[0] if claims_raw else {}
            patent_data.raw_source_data['claims'] = claims_raw
            claims_list = claims_raw.get('data', []) or []
            if isinstance(claims_list, dict):
                claims_list = [claims_list]
                
            for claim_doc in claims_list:
                # 智慧芽返回的结构中可能有依赖项字段，例如 'dep' 或 'depend_on'
                # 如果没有，可以通过判断文本或相关字段来评估独立性
                # 这里假设 'dep' 字段存在时代表其依赖项，如果为空则为独立权利要求
                dependencies = claim_doc.get('dep', [])
                if isinstance(dependencies, str):
                    dependencies = [dependencies] if dependencies else []
                
                # 若无依赖字段，我们默认只有编号为1的独权，但这可能不准确，所以最好根据依赖项为空来判定
                is_indep = len(dependencies) == 0 if 'dep' in claim_doc else str(claim_doc.get('cln', '')) == "1"

                patent_data.claims.append(PatentClaim(
                    claim_number=str(claim_doc.get('cln', '')),
                    claim_text=claim_doc.get('clt', ''),
                    dependencies=dependencies,
                    is_independent=is_indep
                ))
        except Exception as e:
            logger.error(f"智慧芽 API 获取权利要求失败: {e}")

        return patent_data

