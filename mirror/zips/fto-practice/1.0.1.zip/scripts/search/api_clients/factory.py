import os
import json
import logging

from search.api_clients.base_client import BasePatentClient
from search.api_clients.zhihuiya_client import ZhihuiyaClient
from search.api_clients.lens_client import LensClient
from search.api_clients.epo_client import EpoOpsClient
from search.api_clients.baiten_client import BaitenClient
from core.config_resolver import ConfigResolver

logger = logging.getLogger(__name__)

class ApiClientFactory:
    """专利数据库 API 客户端工厂"""

    @staticmethod
    def create(provider_name: str) -> BasePatentClient:
        provider_name = provider_name.lower()
        
        if provider_name == "zhihuiya":
            logger.info("🔌 正在初始化 智慧芽 (Zhihuiya) API 客户端...")
            creds = ConfigResolver.resolve_patent_provider("zhihuiya")
            return ZhihuiyaClient(client_id=creds.client_id, client_secret=creds.client_secret)
            
        elif provider_name == "lens":
            logger.info("🔌 正在初始化 Lens API 客户端...")
            creds = ConfigResolver.resolve_patent_provider("lens")
            return LensClient(token=creds.token)
            
        elif provider_name == "epo":
            logger.info("🔌 正在初始化 EPO API 客户端...")
            creds = ConfigResolver.resolve_patent_provider("epo")
            return EpoOpsClient(consumer_key=creds.client_id, consumer_secret=creds.client_secret)
            
        elif provider_name == "baiten":
            logger.info("🔌 正在初始化 佰腾 (Baiten) API 客户端...")
            creds = ConfigResolver.resolve_patent_provider("baiten")
            return BaitenClient(app_key=creds.client_id, app_secret=creds.client_secret)
            
        else:
            logger.warning(f"⚠️ 未知 API Provider: {provider_name}，回退到默认的 BaitenClient。")
            creds = ConfigResolver.resolve_patent_provider("baiten")
            return BaitenClient(app_key=creds.client_id, app_secret=creds.client_secret)
