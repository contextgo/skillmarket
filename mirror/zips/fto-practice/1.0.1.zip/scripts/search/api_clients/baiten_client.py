import os
import json
import time
import uuid
import hashlib
import requests
import logging
import html
from typing import Dict, Any, Optional

from search.api_clients.base_client import BasePatentClient, PatentAPIError, AuthenticationError, ResourceNotFoundError
from core.models.patent_data import PatentData, PatentBibliography, PatentLegalStatus, PatentClaim, UnifiedSearchResult

logger = logging.getLogger(__name__)

class BaitenClient(BasePatentClient):
    """
    佰腾开放平台 API 客户端
    套餐二权限包含: 申请号, 申请日, 公开号, 公开日, 标题, 权利人, 发明人, 专利类型, IPC主分类号, 当前法律状态, 当前法律事件
    注意: 套餐二不包含权利要求和说明书全文
    """
    
    def __init__(self, app_key: Optional[str] = None, app_secret: Optional[str] = None, timeout: int = 15):
        super().__init__(timeout=timeout)
        self.app_key = app_key
        self.app_secret = app_secret
        
        # 加载已购买 API 的配置
        self.purchased_apis = self._load_purchased_apis()
        
        # 实际通过反编译 Java SDK 提取到的真实请求 Base URL
        self.base_url = "http://open.patexplorer.com/router"
        self.api_level = "TWO" # Use level TWO since ONE is exhausted

    def _load_purchased_apis(self) -> Dict[str, Dict[str, Any]]:
        """加载 Baiten API 的购买状态和提示信息"""
        import os, json
        # 默认只包含当前 FTO 流水线必须的接口
        permissions = {
            "basic": {
                "purchased": True,
                "description": "基础检索服务",
                "purchase_url": "https://open.baiten.cn/interface/basic"
            },
            "claims": {
                "purchased": False,
                "description": "专利权利要求查询服务",
                "purchase_url": "https://open.baiten.cn/interface/claims"
            },
            "paAna": {
                "purchased": False,
                "description": "申请人统计分析服务",
                "purchase_url": "https://open.baiten.cn/interface/paAna"
            }
        }
        
        config_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))), 
            "assets", "patent_database_api", "config.json"
        )
            
        if os.path.exists(config_path):
            try:
                with open(config_path, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                    user_permissions = config.get("baiten_api_permissions", {})
                    if user_permissions:
                        for api_key, api_info in user_permissions.items():
                            if api_key in permissions:
                                permissions[api_key].update(api_info)
            except Exception as e:
                logger.warning(f"读取 {config_path} 失败: {e}")
                
        return permissions

    def _check_api_purchased(self, api_name: str) -> None:
        """检查特定的 API 是否已购买，未购买则提供详细的引导信息"""
        api_info = self.purchased_apis.get(api_name)
        if not api_info or not api_info.get("purchased", False):
            desc = api_info.get("description", "未知服务") if api_info else "未知服务"
            url = api_info.get("purchase_url", "https://open.baiten.cn/") if api_info else "https://open.baiten.cn/"
            
            error_msg = (
                f"\n{'='*60}\n"
                f"🚨 佰腾网 API 权限受限: 需要调用 [{api_name}] 接口\n"
                f"描述: {desc}\n"
                f"状态: 未购买或在 config.json 中未启用\n\n"
                f"💡 解决方法:\n"
                f"1. 请前往购买页面: {url}\n"
                f"2. 购买成功后，请将项目 assets/patent_database_api/config.json 文件中\n"
                f"   'baiten_api_permissions' -> '{api_name}' -> 'purchased' 的值修改为 true。\n"
                f"{'='*60}\n"
            )
            raise AuthenticationError(error_msg)

    def authenticate(self) -> Optional[str]:
        """
        佰腾使用请求时动态签名机制，不需要提前获取长效 Token。
        """
        if not self.app_key or not self.app_secret:
            raise AuthenticationError("未配置佰腾 API 的 App Key 或 App Secret。请在 config.json 中配置 baiten_app_key 和 baiten_app_secret。")
        return None

    def _generate_signature(self, params: Dict[str, Any]) -> str:
        """
        生成佰腾动态签名 (根据新版 SDK CubeUtils.signTopRequestNew 反编译逻辑重写)
        MD5(AppSecret + 按字典序排序的参数对拼接 + AppSecret)
        """
        # 过滤掉 None 或空值的参数，并确保全是字符串
        clean_params = {k: str(v) for k, v in params.items() if v is not None and str(v).strip() != ""}
        
        # 1. 按照参数名的字典序排序
        sorted_keys = sorted(clean_params.keys())
        
        # 2. 拼接字符串: AppSecret + key1value1key2value2... + AppSecret
        sign_source = self.app_secret
        for key in sorted_keys:
            sign_source += f"{key}{clean_params[key]}"
        sign_source += self.app_secret
        
        # 3. MD5 加密并转大写
        return hashlib.md5(sign_source.encode('utf-8')).hexdigest().upper()

    def _execute_request(self, endpoint: str, payload: Dict[str, Any], encrypt_val_core: str = "", request_method: str = "POST") -> Dict[str, Any]:
        """
        发送 POST 请求并进行签名处理
        :param endpoint: 具体的服务路由 (例如 /openService/search)
        :param payload: 请求参数字典
        :param encrypt_val_core: 遗留参数，新版签名逻辑已弃用
        """
        if not self.app_key or not self.app_secret:
            raise AuthenticationError("佰腾 API 凭据缺失。请在 config.json 中配置 baiten_app_key 和 baiten_app_secret。")

        url = f"{self.base_url}{endpoint}"
        
        # 添加公共参数
        payload["app_key"] = self.app_key
        # 新版 SDK 要求传入 timestamp (毫秒级)
        import time
        payload["timestamp"] = str(int(time.time() * 1000))
        
        # 生成新版签名 (传入所有参数参与签名)
        payload["sign"] = self._generate_signature(payload)
        
        headers = {
            "Content-Type": "application/x-www-form-urlencoded;charset=utf-8",
            "User-Agent": "Cube-Client-Java/1.0 (Python Port)"
        }

        try:
            response = self.session.post(url, data=payload, headers=headers, timeout=self.timeout)
            if response.status_code != 200:
                logger.error(f"Error response content: {response.text}")
            response.raise_for_status()
        except requests.exceptions.RequestException as e:
            logger.error(f"调用 {endpoint} 失败! 网络错误: {e}")
            raise PatentAPIError(f"调用 {endpoint} 失败! 网络错误: {e}")
            
        data = response.json()
        if str(data.get("code", "")) == "500":
            # 尝试通过报错信息判断是否是接口余量不足
            error_msg = str(data.get('msg', data))
            if "次" in error_msg or "额度" in error_msg or "余额" in error_msg or "权限" in error_msg:
                api_name = [k for k, v in self.purchased_apis.items() if v.get("endpoint") == endpoint]
                api_key_str = api_name[0] if api_name else endpoint
                url = self.purchased_apis.get(api_key_str, {}).get("purchase_url", "https://open.baiten.cn/")
                
                feedback = (
                    f"\n{'='*60}\n"
                    f"🚨 佰腾网 API 额度耗尽或权限不足: [{api_key_str}]\n"
                    f"接口地址: {endpoint}\n"
                    f"原始报错: {error_msg}\n\n"
                    f"💡 解决方法:\n"
                    f"1. 您的调用额度可能已耗尽，请前往购买/续费: {url}\n"
                    f"2. 购买后额度会自动刷新，无需修改代码配置。\n"
                    f"{'='*60}\n"
                )
                raise PatentAPIError(feedback)
            else:
                raise PatentAPIError(f"佰腾 API 业务错误: {error_msg}")
            
        return data

    def search_patents(self, query: str, limit: int = 10, offset: int = 0) -> Dict[str, Any]:
        """
        根据检索式查询专利。使用 /openService/search 接口，根据是否购买 basic 判定。
        """
        self._check_api_purchased("basic")
        # 佰腾 API 套餐权限控制
        level = self.api_level
        
        page_index = str((offset // limit) + 1)
        
        payload = {
            "query": query,
            "page_index": page_index,
            "page_size": str(limit),
            "level": level,
            "sort_field": "pn",
            "sort": "desc"
        }
        encrypt_val_core = str(len(query.strip()))
        return self._execute_request("/openService/search", payload, encrypt_val_core)

    def execute_aggregate_search(self, query: str, group_by: str = "assignee") -> dict:
        """
        调用佰腾的统计聚合API
        group_by: 'assignee' (竞争对手, 对应佰腾 paAna)
        """
        if group_by == "assignee":
            self._check_api_purchased("paAna")
            # 根据真实 API 文档，参数为 queryString, source, facetType
            # 但底层 HTTP 接口可能兼容 query 或者 queryString。我们直接按文档的 queryString 传。
            # 这里先将通用的 AP: / TAC: 转换为佰腾的 pa: / ti: 等
            import re
            baiten_query = query
            baiten_query = baiten_query.replace("TAC:", "")
            baiten_query = baiten_query.replace("ANCS:", "pa:")
            
            def replace_ipc_agg(match):
                parts = match.group(1).split(" OR ")
                cleaned_parts = [p.replace(" ", "") for p in parts]
                return f"ic1:({' OR '.join(cleaned_parts)})"
            
            baiten_query = re.sub(r'IPC_CPC:\(([^)]+)\)', replace_ipc_agg, baiten_query)
            
            payload = {
                "query": baiten_query,
                "source": "15", # 1,2,4,8 组合
                "facet_type": "pat_count" # 真实抓包/逆向得到的正确的 facet_type
            }
            try:
                # 佰腾申请人分析真实接口
                # 这里的加密核心值长度就是 len(query)
                res = self._execute_request("/openService/facet_pa", payload, str(len(baiten_query.strip())))
                
                # 解析返回的 facet_counts -> pa_ana
                # 示例响应: {"facet_counts": {"pa_ana": [{"name": "吉利", "count": 100}, ...]}, "success": true}
                buckets = []
                # 佰腾有的接口成功时没有显式的 success: true，直接判断数据是否存在
                pa_ana_list = res.get("facet_counts", {}).get("pa_ana", [])
                
                for item in pa_ana_list:
                    comp_name = item.get("name")
                    count = item.get("count", 0)
                    if comp_name:
                        buckets.append({"key": comp_name, "doc_count": count})
                             
                # 按数量降序排序
                buckets.sort(key=lambda x: x["doc_count"], reverse=True)
                
                return {"buckets": buckets}
                
            except Exception as e:
                logger.warning("佰腾聚合 API 调用失败 (%s)，返回空统计字典。", e)
                return {"buckets": []}
        else:
            raise NotImplementedError(f"当前未实现 {group_by} 的佰腾统计聚合功能。")

    def execute_unified_search(self, query: str, limit: int = 100, offset: int = 0) -> UnifiedSearchResult:
        """
        执行统一结构的专利检索 (佰腾实现)
        """
        # 将通用的 TAC/IPC/AP 转换为佰腾支持的语法
        # 佰腾: ti, ab, cl (对应 TAC), ipc (对应 IPC), pa (对应 AP)
        # 简单替换，注意不要误伤内容
        import re
        baiten_query = query
        # 佰腾支持全字段检索，或者我们可以把 TAC: 换为 (ti: OR ab: OR cl:)
        # 为了兼容性，先把 TAC: 替换为 ANY: 或者直接去掉 TAC: 让它默认全字段
        # 佰腾的默认检索就是全字段。我们把 TAC: 替换掉
        baiten_query = baiten_query.replace("TAC:", "")
        baiten_query = baiten_query.replace("ANCS:", "pa:")
        # 将 IPC_CPC: 换为 ic1: ，并去除分类号中的空格 (例如 E02F 9/00 -> E02F9/00)
        def replace_ipc(match):
            content = match.group(1)
            # 只能去掉分类号内部的空格，不能把 OR 的空格去掉
            parts = content.split(" OR ")
            cleaned_parts = [p.replace(" ", "") for p in parts]
            return f"ic1:({' OR '.join(cleaned_parts)})"
        
        # 修正: 贪婪匹配或精确匹配，防止内部嵌套括号被过早截断
        # 因为我们生成的策略中 IPC_CPC:(...) 内部只有 OR 并列的分类号，没有嵌套括号
        # 所以使用 [^)]+ 确保匹配到它自己的闭合括号
        baiten_query = re.sub(r'IPC_CPC:\(([^)]+)\)', replace_ipc, baiten_query)
        
        logger.info("   [Baiten] 转换后的检索式: %s", baiten_query)
        
        raw_result = self.search_patents(baiten_query, limit, offset)
        
        hit_count = 0
        patent_numbers = []
        
        if raw_result and isinstance(raw_result, dict):
            # 佰腾搜索结果结构通常包含 "total_hits", "total_count" 或 "documents"
            # 兼容不同层级，如果直接返回列表或嵌套
            hit_count = raw_result.get("total_hits", raw_result.get("total_count", raw_result.get("total", 0)))
            docs = raw_result.get("documents", raw_result.get("rows", []))
            
            for doc in docs:
                fields = doc.get("field_values", doc)
                # 优先取公开号 pn
                pn = fields.get("pn") or fields.get("an")
                if pn:
                    patent_numbers.append(pn)
                    
        return UnifiedSearchResult(
            hit_count=hit_count,
            patent_numbers=patent_numbers,
            raw_response=raw_result
        )

    def get_patent_bibliography(self, patent_number: str) -> Dict[str, Any]:
        """
        获取专利著录项数据。使用 /openService/get 接口。
        """
        self._check_api_purchased("basic")
        pn_cleaned = patent_number.replace(" ", "")
        payload = {
            "doc_id": pn_cleaned,
            "level": self.api_level
        }
        return self._execute_request("/openService/get", payload, pn_cleaned)

    def get_patent_legal_status(self, patent_number: str) -> Dict[str, Any]:
        """
        获取专利法律状态数据。使用 /openService/law 接口。
        """
        raise NotImplementedError("当前 FTO 工作流无需使用独立的法律状态 API (lawInfo)。如需扩展请购买后实现。")

    def _get_app_num(self, patent_number: str) -> Optional[str]:
        """
        通过检索获取专利的申请号 (an)，因为获取权利要求等接口需要 app_num
        """
        import re
        base_number = re.sub(r'[A-Za-z0-9]$', '', patent_number)
        search_query = f"pn:{patent_number} OR apn:{patent_number} OR an:{patent_number} OR pn:{base_number}"
        try:
            search_res = self.search_patents(search_query, limit=1)
            docs = search_res.get("documents", [])
            if docs:
                return docs[0].get("field_values", {}).get("an")
        except Exception as e:
            logger.warning(f"通过检索获取申请号失败: {e}")
        return None

    def get_patent_claims(self, patent_number: str) -> Dict[str, Any]:
        """
        获取权利要求 (claims)
        使用 /openService/claims 接口。
        """
        self._check_api_purchased("claims")
        app_num = self._get_app_num(patent_number)
        if not app_num:
            app_num = patent_number  # fallback

        payload = {
            "app_num": app_num,
            "pat_type": "APP"
        }
        
        try:
            return self._execute_request("/openService/claims", payload, app_num)
        except Exception as e:
            raise PatentAPIError(f"佰腾 API 获取权利要求失败: {e}")

    def get_patent_description(self, patent_number: str) -> Dict[str, Any]:
        """
        获取专利说明书全文
        :param patent_number: 专利公开号
        :return: 包含说明书文本数据的字典
        """
        raise NotImplementedError("当前 FTO 工作流无需获取说明书原文。如未来扩展请购买 spec 接口并实现。")

    def get_standardized_patent_data(self, patent_number: str) -> PatentData:
        """
        获取标准化专利数据
        由于佰腾的“套餐二”对 /openService/get 等接口有权限限制，
        但 /openService/search (level=TWO) 却能返回包含著录项和法律状态的列表，
        因此这里直接使用检索接口来映射数据。
        """
        patent_data = PatentData(
            source_platform="baiten",
            raw_source_data={}
        )

        try:
            # 1. 尝试通过公开号或申请号进行精准检索
            import re
            base_number = re.sub(r'[A-Za-z]$', '', patent_number)
            search_query = f"pn:{patent_number} OR apn:{patent_number} OR an:{patent_number} OR pn:{base_number}"
            search_res = self.search_patents(search_query, limit=1)
            patent_data.raw_source_data['search_response'] = search_res
            
            docs = search_res.get("documents", [])
            if docs:
                fields = docs[0].get("field_values", {})
                
                # 提取著录项
                patent_data.bibliography = PatentBibliography(
                    patent_number=fields.get('pn', patent_number) or patent_number,
                    application_number=fields.get('an') or '',
                    title=fields.get('ti') or '',
                    abstract=fields.get('ab') or '',
                    application_date=fields.get('ad') or '',
                    publication_date=fields.get('pd') or '',
                    assignees=fields.get('pa') or [],
                    inventors=fields.get('in') or [],
                    ipc_classes=[fields.get('ic1')] if fields.get('ic1') else []
                )

                # 提取法律状态
                status_desc = fields.get('lsn1', '')
                sub_status = fields.get('lsn2', '')
                if sub_status:
                    status_desc += f" - {sub_status}"
                    
                patent_data.legal_status = PatentLegalStatus(
                    status_code=fields.get('lsn1', ''),
                    status_description=status_desc,
                    date="", # 检索接口没有返回法律事件具体日期
                    is_active='有效' in status_desc or '授权' in status_desc
                )

            # 2. 提取权利要求
            try:
                # 因为前面检索时可能已经拿到了真正的 app_num (an)，这里直接复用
                app_num = fields.get('an') if docs else patent_number
                claims_res = self.get_patent_claims(app_num)
                patent_data.raw_source_data['claims_response'] = claims_res

                patent_data.claims = self._parse_baiten_claims(claims_res.get('patent_claims_list', []))
            except Exception as e:
                logger.error(f"佰腾 API 提取权利要求失败: {e}")

        except Exception as e:
            logger.error(f"佰腾 API 获取标准化数据失败: {e}")

        return patent_data

    def _parse_baiten_claims(self, patent_claims_list: list) -> list:
        """
        递归解析佰腾返回的树状权利要求结构，展平为 PatentClaim 列表。
        修正了多重依赖解析逻辑并增加了去重处理。
        """
        import re
        claims = []
        seen_nums = set()  # 记录已处理的权利要求编号，防止重复

        def clean_html(raw_html: Any) -> str:
            if raw_html is None:
                return ""
            # 移除 HTML 标签并解码实体字符
            cleanr = re.compile('<.*?>')
            cleantext = re.sub(cleanr, '', str(raw_html))
            return html.unescape(cleantext).strip()

        def traverse(claims_list):
            for claim_node in claims_list:
                num = str(claim_node.get('claims_num', '')).strip()
                if not num or num in seen_nums:
                    continue
                
                # 显式转换为字符串处理
                parent_num_raw = str(claim_node.get('claims_parentNum', '0')).strip()
                text = clean_html(claim_node.get('claim', ''))
                
                dependencies = []
                if parent_num_raw and parent_num_raw != '0':
                    # 关键修正：处理多重依赖（如 "1,2" 或 "1，2"）
                    # 兼容中英文逗号和分号
                    dependencies = [d.strip() for d in re.split(r'[,，;；]', parent_num_raw) if d.strip()]
                
                is_independent = (parent_num_raw == '0' or not parent_num_raw)

                if text and text.lower() != "none":
                    claims.append(PatentClaim(
                        claim_number=num,
                        claim_text=text,
                        dependencies=dependencies,
                        is_independent=is_independent
                    ))
                    seen_nums.add(num)
                
                # 递归处理子项
                children = claim_node.get('patentClaimses', [])
                if children:
                    traverse(children)
        
        traverse(patent_claims_list)
        
        # 按照权利要求编号进行数值排序
        try:
            claims.sort(key=lambda c: int(re.sub(r'\D', '', c.claim_number)) if re.search(r'\d', c.claim_number) else 999)
        except (ValueError, TypeError):
            pass 
        
        return claims

