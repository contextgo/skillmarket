import os
import time
import requests
from typing import Dict, Any, Optional

class MinerUClient:
    """
    MinerU API 客户端，用于将 PDF/图片 转换为大模型友好的 Markdown / JSON 格式。
    参考: https://mineru.net/apiManage/docs
    """
    
    def __init__(self, token: Optional[str] = None):
        """
        初始化 MinerU 客户端
        :param token: MinerU API Token。若不传则尝试从环境变量 MINERU_API_TOKEN 获取
        """
        self.token = token or os.environ.get("MINERU_API_TOKEN")
        # 尝试从 config.json 读取
        if not self.token:
            config_path = os.path.join(os.path.dirname(__file__), '..', '..', 'config.json')
            if os.path.exists(config_path):
                import json
                try:
                    with open(config_path, 'r') as f:
                        config = json.load(f)
                        self.token = config.get('mineru_token')
                except Exception as e:
                    print(f"读取 config.json 失败: {e}")
                    
        self.base_url_v4 = "https://mineru.net/api/v4"
        self.base_url_agent = "https://mineru.net/api/v1/agent"
        
    def _get_headers(self) -> Dict[str, str]:
        if not self.token:
            raise ValueError("未配置 MinerU API Token。请在初始化时传入或设置环境变量 MINERU_API_TOKEN。")
        return {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.token}"
        }

    def extract_task_by_file(self, file_path: str, model_version: str = "vlm") -> str:
        """
        [V4 精准解析 API] 提交本地文件进行解析任务 (通过先上传到预签名的URL，或者看官方接口是不是两步走)
        我们先查阅之前存的文档，如果官方不支持 multipart upload，我们先用基础方式
        由于之前代码写了 extract/task/upload 报 405，我们用 base64 或直接传文件流的形式尝试一下。
        其实官方文档是：
        """
        url = f"{self.base_url_v4}/extract/task"
        # ... 由于文档不明确，我们暂时跳过，如果只是测试，我们等会儿用 LLM 自己把 XML 转为 Markdown。
        raise NotImplementedError("V4 file upload is not fully documented. Use extract_task_by_url instead.")
        """
        [V4 精准解析 API] 提交通过 URL 解析的任务
        支持最大 200MB, 600页的文档，适合长篇 API 手册或专利全文。
        :param file_url: 文件的公网 URL
        :param model_version: 模型版本 (默认 vlm, 效果最佳)
        :return: task_id (任务批次号/ID)
        """
        url = f"{self.base_url_v4}/extract/task"
        payload = {
            "url": file_url,
            "model_version": model_version,
            "is_ocr": False,
            "enable_formula": True,
            "enable_table": True
        }
        
        print(f"🚀 正在向 MinerU 提交 URL 解析任务: {file_url}")
        response = requests.post(url, headers=self._get_headers(), json=payload)
        
        if response.status_code == 200:
            result = response.json()
            if result.get("code") == 0: # 假设 0 是成功
                task_id = result.get("data", {}).get("task_id") or result.get("data")
                print(f"✅ 任务提交成功！Task ID: {task_id}")
                return task_id
            else:
                raise Exception(f"提交失败，业务报错: {result}")
        else:
            raise Exception(f"请求失败! HTTP {response.status_code}: {response.text}")

    def query_task_status(self, task_id: str) -> Dict[str, Any]:
        """
        [V4 精准解析 API] 轮询查询任务状态
        :param task_id: extract_task_by_url 返回的任务 ID
        """
        url = f"{self.base_url_v4}/extract/task/{task_id}"
        
        response = requests.get(url, headers=self._get_headers())
        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"查询状态失败! HTTP {response.status_code}: {response.text}")

    def download_task_result(self, task_id: str, save_dir: str = "output"):
        """
        如果任务状态为 done，可以下载结果文件 (ZIP)
        通常返回中会有 download_url，这里做个简单封装
        """
        status_res = self.query_task_status(task_id)
        data = status_res.get("data", {})
        
        if data.get("state") != "done":
            print(f"任务未完成，当前状态: {data.get('state')}")
            return None
            
        full_zip_url = data.get("full_zip_url")
        if not full_zip_url:
            print("未能获取到 download_url")
            return None
            
        if not os.path.exists(save_dir):
            os.makedirs(save_dir)
            
        zip_path = os.path.join(save_dir, f"{task_id}.zip")
        print(f"正在下载结果至 {zip_path} ...")
        
        res = requests.get(full_zip_url)
        with open(zip_path, 'wb') as f:
            f.write(res.content)
            
        print("下载完成！")
        return zip_path

    def agent_parse_file_lightweight(self, file_path: str) -> Dict[str, Any]:
        """
        [Agent 轻量解析 API] 免登录签名上传解析
        根据最新的 MinerU 官方文档，采用两步上传法：
        1. POST /api/v1/agent/parse/file 获取签名 file_url 和 task_id
        2. PUT 真实文件至 file_url
        3. 轮询 /api/v1/agent/parse/{task_id} 直至状态为 done
        """
        import time

        if not os.path.exists(file_path):
            raise FileNotFoundError(f"找不到文件: {file_path}")
            
        print(f"🚀 正在向 MinerU (Agent) 请求上传签名: {file_path}")
        
        url_agent = f"{self.base_url_agent}/parse/file"
        name = os.path.basename(file_path)
        
        # 1. 获取签名上传 URL
        payload = {
            "file_name": name,
            "language": "ch",
            "enable_table": True,
            "is_ocr": False,
            "enable_formula": True
        }
        r = requests.post(url_agent, json=payload, timeout=10)
        if r.status_code != 200:
            raise Exception(f"获取签名失败! HTTP {r.status_code}: {r.text}")
            
        data = r.json()
        if data.get("code") != 0:
            raise Exception(f"获取签名失败: {data}")
            
        task_id = data.get("data", {}).get("task_id")
        file_url = data.get("data", {}).get("file_url")
        if not file_url or not task_id:
            raise Exception("未能从返回值中提取到 file_url 或 task_id")
            
        print(f"✅ 获取签名成功，正在 PUT 文件到 OSS...")
        
        # 2. PUT 上传文件到 OSS
        with open(file_path, "rb") as f:
            put_res = requests.put(file_url, data=f, timeout=30)
            if put_res.status_code not in (200, 201):
                raise Exception(f"文件上传失败, HTTP {put_res.status_code}")
                
        print("✅ 文件上传成功，正在等待解析结果...")
        
        # 3. 轮询解析结果
        max_retries = 30
        for i in range(max_retries):
            time.sleep(3)
            status_url = f"{self.base_url_agent}/parse/{task_id}"
            status_res = requests.get(status_url, timeout=10)
            r_json = status_res.json()
            state = r_json.get("data", {}).get("state")
            
            if state == "done":
                print("\n✅ 解析完成！")
                md_url = r_json.get("data", {}).get("markdown_url")
                if md_url:
                    # 下载 Markdown 文本
                    # 增加重试和备选方案，防止 cdn-mineru 的 SSL 兼容性问题 (SSLEOFError)
                    try:
                        md_resp = requests.get(md_url, timeout=15, verify=False)
                        md_text = md_resp.text
                    except requests.exceptions.SSLError:
                        print("⚠️ Python requests 遇到 SSL 异常，正在尝试使用 curl 回退下载...")
                        import subprocess
                        import tempfile
                        with tempfile.NamedTemporaryFile(delete=False) as tmp:
                            subprocess.run(["curl", "-s", "-k", "-L", md_url, "-o", tmp.name], check=True)
                            with open(tmp.name, "r", encoding="utf-8") as f:
                                md_text = f.read()
                            os.unlink(tmp.name)
                            
                    return {"data": {"markdown": md_text}}
                else:
                    raise Exception("任务显示 done，但未返回 markdown_url")
            elif state == "failed":
                err_msg = r_json.get("data", {}).get("err_msg", "未知错误")
                raise Exception(f"MinerU 解析失败: {err_msg}")
            else:
                print(".", end="", flush=True)
                
        raise Exception("MinerU 解析超时 (超过 90 秒)")
