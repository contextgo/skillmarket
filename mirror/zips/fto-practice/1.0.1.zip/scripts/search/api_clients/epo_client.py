import os
import requests
import base64
from typing import Dict, Any, Optional
import os
import requests

from search.api_clients.base_client import BasePatentClient
from core.models.patent_data import PatentData, PatentBibliography, PatentLegalStatus, PatentClaim, UnifiedSearchResult
from search.api_clients.mineru_client import MinerUClient

class EpoOpsClient(BasePatentClient):
    """
    EPO Open Patent Services (OPS) API 客户端
    参考: https://developers.epo.org/
    """
    
    def __init__(self, consumer_key: Optional[str] = None, consumer_secret: Optional[str] = None):
        """
        初始化 EPO OPS 客户端
        """
        super().__init__()
        self.consumer_key = consumer_key
        self.consumer_secret = consumer_secret
        
        self.token = None
        self.base_url = "https://ops.epo.org/3.2/rest-services"
        self.auth_url = "https://ops.epo.org/3.2/auth/accesstoken"
        
    def authenticate(self) -> str:
        """
        EPO OPS 使用 OAuth 2.0 Client Credentials 流程 (Basic Authentication)
        参考官方文档 Page 36
        """
        if self.token:
            return self.token
            
        if not self.consumer_key or not self.consumer_secret:
            raise ValueError("未配置 EPO OPS 的 Consumer Key 或 Consumer Secret。请在统一配置解析器中配置。")
            
        credentials = f"{self.consumer_key}:{self.consumer_secret}"
        encoded_credentials = base64.b64encode(credentials.encode('utf-8')).decode('utf-8')
        
        headers = {
            "Authorization": f"Basic {encoded_credentials}",
            "Content-Type": "application/x-www-form-urlencoded"
        }
        data = {"grant_type": "client_credentials"}
        
        response = requests.post(self.auth_url, headers=headers, data=data)
        if response.status_code == 200:
            result = response.json()
            self.token = result.get("access_token")
            # 官方文档提到 Token 有效期约 20 分钟
            return self.token
        else:
            raise Exception(f"EPO OPS 认证失败! HTTP {response.status_code}: {response.text}")

    def _execute_request(self, endpoint: str, method: str = "GET", data: Any = None) -> Dict[str, Any]:
        """
        执行对 EPO OPS 的 HTTP 请求
        """
        token = self.authenticate()
        url = f"{self.base_url}/{endpoint}"
        headers = {
            "Authorization": f"Bearer {token}",
            "Accept": "application/json"  # 尝试请求 JSON 格式响应
        }
        
        if method.upper() == "GET":
            response = requests.get(url, headers=headers)
        elif method.upper() == "POST":
            # 对于 published-data, POST 请求可以将多个文献用换行符分隔放入 body 中
            headers["Content-Type"] = "text/plain"
            response = requests.post(url, headers=headers, data=data)
        else:
            raise ValueError(f"不支持的 HTTP 方法: {method}")
            
        if response.status_code == 200:
            # 如果服务器只支持 XML，需要考虑转换。这里假设它能根据 Accept 头返回 JSON。
            try:
                return response.json()
            except Exception:
                return {"xml_response": response.text}
        elif response.status_code == 404:
            raise Exception(f"EPO OPS 返回 404: 未找到数据 ({endpoint})")
        else:
            raise Exception(f"EPO OPS 请求失败! HTTP {response.status_code}: {response.text}")

    def get_patent_claims(self, patent_number: str) -> Dict[str, Any]:
        """
        获取指定专利的权利要求 (EPO: published-data/publication/epodoc/{number}/claims)
        注意：使用 epodoc 格式，如果不带点（如 CN106627239A），需转为带点格式（如 CN.106627239.A）
        """
        import re
        safe_patent_number = patent_number
        if "." not in safe_patent_number:
            match = re.match(r'^([A-Z]{2})(\d+)([A-Z1-9]*)$', safe_patent_number)
            if match:
                safe_patent_number = f"{match.group(1)}.{match.group(2)}.{match.group(3)}"
                
        endpoint = f"published-data/publication/epodoc/{safe_patent_number}/claims"
        return self._execute_request(endpoint)

    def get_patent_bibliography(self, patent_number: str) -> Dict[str, Any]:
        """
        获取专利著录项目信息 (EPO: published-data/publication/epodoc/{number}/biblio)
        """
        import re
        safe_patent_number = patent_number
        if "." not in safe_patent_number:
            match = re.match(r'^([A-Z]{2})(\d+)([A-Z1-9]*)$', safe_patent_number)
            if match:
                safe_patent_number = f"{match.group(1)}.{match.group(2)}.{match.group(3)}"
                
        # EPO OPS 的公开号格式通常需要是 epodoc 格式，例如 EP1000000
        endpoint = f"published-data/publication/epodoc/{safe_patent_number}/biblio"
        return self._execute_request(endpoint)

    def get_patent_legal_status(self, patent_number: str) -> Dict[str, Any]:
        """
        获取专利法律状态 (EPO: legal-status/publication/epodoc/{number})
        """
        import re
        safe_patent_number = patent_number
        if "." not in safe_patent_number:
            match = re.match(r'^([A-Z]{2})(\d+)([A-Z1-9]*)$', safe_patent_number)
            if match:
                safe_patent_number = f"{match.group(1)}.{match.group(2)}.{match.group(3)}"
                
        endpoint = f"legal-status/publication/epodoc/{safe_patent_number}"
        return self._execute_request(endpoint)

    def search_patents(self, query: str, limit: int = 100, offset: int = 0) -> Dict[str, Any]:
        """
        检索式检索专利 (EPO: published-data/search)
        使用 CQL (Context Query Language) 语法，例如 'ti=plastic AND pa=BASF'
        """
        # /published-data/search?q={query}&Range=1-{limit}
        # Range=start-end (1-based)
        start = offset + 1
        end = offset + min(limit, 100)
        endpoint = f"published-data/search?q={query}&Range={start}-{end}"
        return self._execute_request(endpoint)

    def execute_unified_search(self, query: str, limit: int = 100, offset: int = 0) -> UnifiedSearchResult:
        """
        执行统一结构的专利检索 (EPO OPS 实现)
        """
        raw_result = self.search_patents(query, limit, offset)
        
        hit_count = 0
        patent_numbers = []
        
        # EPO OPS JSON response for search usually contains ops:world-patent-data
        wpd = raw_result.get("ops:world-patent-data", {})
        biblio_search = wpd.get("ops:biblio-search", {})
        
        # extract total count
        hit_count_str = biblio_search.get("@total-result-count", "0")
        try:
            hit_count = int(hit_count_str)
        except ValueError:
            pass
            
        search_results = biblio_search.get("ops:search-result", {}).get("ops:publication-reference", [])
        if isinstance(search_results, dict):
            search_results = [search_results]
            
        for ref in search_results:
            doc_id = ref.get("document-id", {})
            if isinstance(doc_id, list):
                doc_id = doc_id[0] if doc_id else {}
                
            country = doc_id.get("country", {}).get("$", "")
            doc_number = doc_id.get("doc-number", {}).get("$", "")
            kind = doc_id.get("kind", {}).get("$", "")
            
            if country and doc_number:
                # 组装为标准的公开号，例如 CN123456A
                patent_numbers.append(f"{country}{doc_number}{kind}")
                
        return UnifiedSearchResult(
            hit_count=hit_count,
            patent_numbers=patent_numbers,
            raw_response=raw_result
        )

    def _extract_biblio_via_pdf_vqa(self, patent_number: str) -> Dict[str, Any]:
        """
        [终极兜底方案] 当彻底拿不到任何 A/B 卷结构化著录项时，下载专利首页 PDF，用 MinerU 提取文本后让大模型提取著录项。
        """
        import os
        import re
        import json
        from google import genai
        from google.genai import types
        from pydantic import BaseModel, Field
        from mineru_client import MinerUClient

        print(f"💡 启动终极兜底：尝试从 EPO 抓取 {patent_number} 的首页 PDF 并通过 VQA 提取著录项目...")
        safe_patent_number = patent_number
        if "." not in safe_patent_number:
            match = re.match(r'^([A-Z]{2})(\d+)([A-Z1-9]*)$', safe_patent_number)
            if match: safe_patent_number = f"{match.group(1)}.{match.group(2)}.{match.group(3)}"
                
        match = re.match(r'^([A-Z]{2})\.(\d+)\.([A-Z1-9]*)$', safe_patent_number)
        if match:
            country, number, kind = match.group(1), match.group(2), match.group(3) or "A"
        else:
            return {}

        pdf_headers = {"Authorization": f"Bearer {self.authenticate()}", "Accept": "application/pdf"}
        out_dir = f"output/{patent_number}"
        os.makedirs(out_dir, exist_ok=True)
        front_page_path = f"{out_dir}/front_page.pdf"
        
        # 盲猜第一页通常是封面
        page_url = f"{self.base_url}/published-data/images/{country}/{number}/{kind}/fullimage?Range=1"
        try:
            resp = requests.get(page_url, headers=pdf_headers, verify=False)
            if resp.status_code == 200:
                with open(front_page_path, "wb") as f:
                    f.write(resp.content)
            else:
                # 尝试 A 卷的第一页
                kind_a = "A1" if country == "AU" else "A"
                page_url = f"{self.base_url}/published-data/images/{country}/{number}/{kind_a}/fullimage?Range=1"
                resp = requests.get(page_url, headers=pdf_headers, verify=False)
                if resp.status_code == 200:
                    with open(front_page_path, "wb") as f:
                        f.write(resp.content)
                else:
                    return {}
                    
            # 提取文本
            mineru = MinerUClient()
            parse_res = mineru.agent_parse_file_lightweight(front_page_path)
            clean_text = parse_res.get("data", {}).get("markdown", "")
            
            if not clean_text:
                return {}
                
            # 大模型提取
            class ExtractedBiblio(BaseModel):
                title: str = Field(description="专利名称/标题")
                assignee: str = Field(description="申请人/权利人名称，若有多个用逗号分隔")
                application_date: str = Field(description="申请日，格式如 YYYYMMDD")
                publication_date: str = Field(description="公开日/授权公告日，格式如 YYYYMMDD")
                
            # 获取 config 中的 API Key
            config_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../config.json'))
            api_key = os.environ.get("GEMINI_API_KEY")
            if not api_key and os.path.exists(config_path):
                with open(config_path, 'r') as f:
                    cfg = json.load(f)
                    api_key = cfg.get("gemini_api_key") or cfg.get("GEMINI_API_KEY")
                    
            if not api_key:
                print("⚠️ 缺少 Gemini API Key，无法执行 VQA 兜底提取。")
                return {}
                
            llm_client = genai.Client(api_key=api_key)
            prompt = f"以下是一篇专利扉页的 OCR 文本。请提取关键著录项目。若未找到则填空字符串。\n\n【扉页文本】\n{clean_text}"
            response = llm_client.models.generate_content(
                model="gemini-2.5-pro",
                contents=prompt,
                config=types.GenerateContentConfig(
                    response_mime_type="application/json",
                    response_schema=ExtractedBiblio,
                    temperature=0.1,
                ),
            )
            res_dict = json.loads(response.text)
            return {
                "title": res_dict.get("title", ""),
                "assignees": [res_dict.get("assignee", "")] if res_dict.get("assignee") else [],
                "application_date": res_dict.get("application_date", ""),
                "publication_date": res_dict.get("publication_date", "")
            }
        except Exception as e:
            print(f"❌ VQA 兜底提取异常: {e}")
            return {}

    def _get_claims_via_pdf_and_mineru(self, patent_number: str) -> str:
        """
        [EPO 特有逻辑] 当无法获取结构化 claims 时，尝试下载 EPO 的图片/PDF 并使用 MinerU 解析文本。
        修复：EPO OPS 的 /fullimage 如果指定 Range=x-y，在某些情况下只会返回该 Range 的最后一页。
        因此必须先请求 /images 接口获取文档结构，找出权利要求的准确页码，逐页下载后在本地合并。
        """
        import re
        import os
        import json
        import PyPDF2
        
        print(f"💡 EPO OPS 未提供纯文本 claims，正在尝试抓取 {patent_number} 的权利要求 PDF...")
        safe_patent_number = patent_number
        if "." not in safe_patent_number:
            match = re.match(r'^([A-Z]{2})(\d+)([A-Z1-9]*)$', safe_patent_number)
            if match:
                safe_patent_number = f"{match.group(1)}.{match.group(2)}.{match.group(3)}"
                
        match = re.match(r'^([A-Z]{2})\.(\d+)\.([A-Z1-9]*)$', safe_patent_number)
        if match:
            country, number, kind = match.group(1), match.group(2), match.group(3) or "A"
        else:
            country, number, kind = "CN", safe_patent_number.replace('CN', '').replace('.A', '').replace('.B', '').replace('B', '').replace('A', ''), "A"

        headers = {
            "Authorization": f"Bearer {self.authenticate()}",
            "Accept": "application/json"
        }
        
        # 第一步：获取文档结构
        pages_to_download = []
        
        def fetch_document_structure(k):
            url = f"{self.base_url}/published-data/publication/epodoc/{country}.{number}.{k}/images"
            resp = requests.get(url, headers=headers)
            if resp.status_code == 200:
                try:
                    data = resp.json()
                    instances = data.get('ops:world-patent-data', {}).get('ops:document-inquiry', {}).get('ops:inquiry-result', {}).get('ops:document-instance', [])
                    if isinstance(instances, dict): instances = [instances]
                    full_doc = next((i for i in instances if i.get('@desc') == 'FullDocument'), None)
                    if full_doc:
                        total_pages = int(full_doc.get('@number-of-pages', 1))
                        sections = full_doc.get('ops:document-section', [])
                        if isinstance(sections, dict): sections = [sections]
                        
                        # 必须按起始页码排序，因为 EPO 经常按字母顺序 (ABSTRACT, BIBLIO, CLAIMS, DESC) 返回节点！
                        sorted_sections = sorted(sections, key=lambda x: int(x.get('@start-page', 1)))
                        
                        for i, sec in enumerate(sorted_sections):
                            if sec.get('@name') == 'CLAIMS':
                                start_page = int(sec.get('@start-page'))
                                # 寻找下一个逻辑区块的起始页
                                end_page = total_pages
                                if i + 1 < len(sorted_sections):
                                    next_start = int(sorted_sections[i+1].get('@start-page'))
                                    end_page = next_start - 1 if next_start > start_page else start_page
                                return list(range(start_page, end_page + 1))
                except Exception as e:
                    print(f"⚠️ 解析文档结构失败: {e}")
            return None

        pages_to_download = fetch_document_structure(kind)
        if not pages_to_download and kind.startswith("B"):
            print(f"💡 EPO OPS 可能没有 {kind} 卷的 PDF 结构，尝试降级为 A/A1 卷获取...")
            kind = "A1" if country == "AU" else "A"
            pages_to_download = fetch_document_structure(kind)
            if not pages_to_download and kind == "A1":
                kind = "A"
                pages_to_download = fetch_document_structure(kind)
            
        if not pages_to_download:
            print("⚠️ 未能通过 EPO OPS 获取到明确的权利要求页码范围，将尝试盲猜前3页。")
            pages_to_download = [1, 2, 3]

        # 第二步：逐页下载并合并
        pdf_headers = {
            "Authorization": f"Bearer {self.authenticate()}",
            "Accept": "application/pdf"
        }
        merger = PyPDF2.PdfMerger()
        download_success = False
        
        # 确保输出目录存在
        out_dir = f"output/{safe_patent_number}"
        os.makedirs(out_dir, exist_ok=True)
        
        try:
            for page in pages_to_download:
                page_url = f"{self.base_url}/published-data/images/{country}/{number}/{kind}/fullimage?Range={page}"
                resp = requests.get(page_url, headers=pdf_headers)
                if resp.status_code == 200:
                    page_path = f"{out_dir}/page_{page}_{safe_patent_number}.pdf"
                    with open(page_path, "wb") as f:
                        f.write(resp.content)
                    merger.append(page_path)
                    os.remove(page_path)  # 合并后即可删除单页
                    download_success = True
                else:
                    print(f"⚠️ 无法下载第 {page} 页，状态码: {resp.status_code}")
            
            if not download_success:
                print("❌ EPO PDF 所有权利要求页面下载均失败。")
                return ""
                
            merged_pdf_path = f"{out_dir}/claims.pdf"
            merger.write(merged_pdf_path)
            merger.close()
            print(f"📄 成功下载并合并权利要求 PDF 至 {merged_pdf_path}")
            
            # 第三步：调用 MinerU 解析合并后的 PDF
            print("💡 正在调用 MinerU 解析 PDF 提取文本...")
            mineru = MinerUClient()
            parse_res = mineru.agent_parse_file_lightweight(merged_pdf_path)
            clean_text = parse_res.get("data", {}).get("markdown", "")
            
            # 注意：应用户要求，不要删除此中间产物 PDF
            # if os.path.exists(merged_pdf_path):
            #     os.remove(merged_pdf_path)
                
            if clean_text:
                return clean_text
            else:
                print("⚠️ MinerU 解析返回为空。")
                return ""
                
        except Exception as e:
            print(f"❌ EPO PDF 获取与解析异常: {e}")
            return ""

    def get_patent_description(self, patent_number: str) -> Dict[str, Any]:
        """
        获取说明书
        """
        raise NotImplementedError("EPO OPS 不直接提供说明书接口")

    def get_standardized_patent_data(self, patent_number: str) -> PatentData:
        """
        获取统一专利数据模型 (EPO OPS 实现)
        """
        import re
        patent_data = PatentData(
            source_platform="epo_ops",
            raw_source_data={}
        )

        try:
            biblio_raw = self.get_patent_bibliography(patent_number)
        except Exception as e:
            # 智能降级逻辑：如果查询 B 卷 (如 B, B1, B2) 报 404，尝试降级为 A 卷 (如 A1, A) 获取著录项
            match = re.search(r'(B[1-9]?)$', patent_number)
            if "404" in str(e) and match:
                base_number = patent_number[:match.start()]
                # 澳洲通常是 A1，中国通常是 A，这里优先尝试 A1，如果不行再尝试 A
                try_kinds = ["A1", "A"]
                biblio_raw = {}
                for kind in try_kinds:
                    patent_number_a = base_number + kind
                    print(f"💡 EPO OPS 没有 {patent_number} 的著录项数据，尝试降级获取 {patent_number_a} 的数据...")
                    try:
                        biblio_raw = self.get_patent_bibliography(patent_number_a)
                        if biblio_raw:
                            break # 成功获取则跳出循环
                    except Exception as e2:
                        print(f"EPO OPS 降级获取 {patent_number_a} 著录项也失败: {e2}")
            else:
                print(f"EPO OPS 获取著录项失败: {e}")
                biblio_raw = {}
                
        patent_data.raw_source_data['bibliography'] = biblio_raw
        
        # 如果经过 A 卷降级后，依然拿不到 biblio_raw（说明完全没有结构化数据）
        # 触发终极兜底：下载扉页 PDF，用 MinerU + 大模型进行视觉信息提取 (VQA)
        vqa_biblio = {}
        if not biblio_raw:
            vqa_biblio = self._extract_biblio_via_pdf_vqa(patent_number)
        
        # EPO OPS 返回的是复杂的嵌套 JSON，需要根据具体结构提取
        doc = biblio_raw.get('ops:world-patent-data', {}).get('exchange-documents', {}).get('exchange-document', {})
        if isinstance(doc, list):
            doc = doc[0] if doc else {}
            
        bib_data = doc.get('bibliographic-data', {})
        
        # 提取标题
        titles = bib_data.get('invention-title', [])
        if isinstance(titles, dict): titles = [titles]
        title_en = next((t.get('$', '') for t in titles if t.get('@lang') == 'en'), '')
        title = title_en or (titles[0].get('$', '') if titles else vqa_biblio.get('title', 'EPO Title Placeholder'))
        
        # 提取申请人
        applicants = bib_data.get('parties', {}).get('applicants', {}).get('applicant', [])
        if isinstance(applicants, dict): applicants = [applicants]
        assignees = [a.get('applicant-name', {}).get('name', {}).get('$', '') for a in applicants]
        if not assignees and vqa_biblio.get('assignees'):
            assignees = vqa_biblio.get('assignees')
        
        # 提取日期 (更稳健的遍历寻找 date 节点)
        app_ref = bib_data.get('application-reference', {}).get('document-id', [])
        if isinstance(app_ref, dict): app_ref = [app_ref]
        app_date = next((d.get('date', {}).get('$', '') for d in app_ref if 'date' in d), '')
        if not app_date: app_date = vqa_biblio.get('application_date', '')
        
        pub_ref = bib_data.get('publication-reference', {}).get('document-id', [])
        if isinstance(pub_ref, dict): pub_ref = [pub_ref]
        pub_date = next((d.get('date', {}).get('$', '') for d in pub_ref if 'date' in d), '')
        if not pub_date: pub_date = vqa_biblio.get('publication_date', '')
        
        # 提取发明人
        inventors_raw = bib_data.get('parties', {}).get('inventors', {}).get('inventor', [])
        if isinstance(inventors_raw, dict): inventors_raw = [inventors_raw]
        inventors = [
            inv.get('inventor-name', {}).get('name', {}).get('$', '')
            for inv in inventors_raw if inv.get('@data-format') == 'epodoc'
        ]
        
        # 提取 IPC 分类号
        ipc_raw = bib_data.get('patent-classifications', {}).get('patent-classification', [])
        if isinstance(ipc_raw, dict): ipc_raw = [ipc_raw]
        ipc_classes = []
        for ipc in ipc_raw:
            try:
                sec = ipc.get('section', {}).get('$', '')
                cls = ipc.get('class', {}).get('$', '')
                subcls = ipc.get('subclass', {}).get('$', '')
                maingrp = ipc.get('main-group', {}).get('$', '')
                subgrp = ipc.get('subgroup', {}).get('$', '')
                if sec and cls and subcls and maingrp and subgrp:
                    ipc_str = f"{sec}{cls}{subcls}{maingrp}/{subgrp}"
                    if ipc_str not in ipc_classes:
                        ipc_classes.append(ipc_str)
            except Exception:
                continue
        
        patent_data.bibliography = PatentBibliography(
            patent_number=patent_number,
            title=title,
            abstract="EPO Abstract Placeholder",
            application_date=app_date,
            publication_date=pub_date,
            assignees=assignees,
            inventors=inventors,
            ipc_classes=ipc_classes
        )

        try:
            legal_raw = self.get_patent_legal_status(patent_number)
        except Exception as e:
            if "404" in str(e) and patent_number.endswith("B"):
                patent_number_a = patent_number[:-1] + "A"
                print(f"💡 EPO OPS 没有 {patent_number} 的法律状态，尝试降级获取 {patent_number_a} 的数据...")
                try:
                    legal_raw = self.get_patent_legal_status(patent_number_a)
                except Exception as e2:
                    print(f"EPO OPS 降级获取法律状态也失败: {e2}")
                    legal_raw = {}
            else:
                print(f"EPO OPS 获取法律状态失败: {e}")
                legal_raw = {}
                
        patent_data.raw_source_data['legal_status'] = legal_raw
        
        patent_data.legal_status = PatentLegalStatus(
            status_code="EPO Status",
            status_description="EPO Status Description",
            date="",
            is_active=False
        )

        try:
            claims_raw = self.get_patent_claims(patent_number)
        except Exception as e:
            if "404" in str(e) and patent_number.endswith("B"):
                patent_number_a = patent_number[:-1] + "A"
                print(f"💡 EPO OPS 没有 {patent_number} 的权利要求数据，尝试降级获取 {patent_number_a} 的数据...")
                try:
                    claims_raw = self.get_patent_claims(patent_number_a)
                except Exception as e2:
                    print(f"EPO OPS 降级获取权利要求也失败: {e2}")
                    claims_raw = {}
            else:
                print(f"EPO OPS 获取权利要求失败: {e}")
                claims_raw = {}
                
        patent_data.raw_source_data['claims'] = claims_raw
        
        # 尝试直接从 XML 中提取
        claims_text = claims_raw.get("xml_response", "") if isinstance(claims_raw, dict) else ""
        if not claims_text or "404" in str(claims_text):
            # 触发后备逻辑：下载 PDF 并用 MinerU OCR 提取
            claims_text = self._get_claims_via_pdf_and_mineru(patent_number)
            
        if claims_text:
            patent_data.claims.append(PatentClaim(
                claim_number="1",
                claim_text=claims_text,
                is_independent=True
            ))
        else:
            print(f"⚠️ EPO OPS 未能提取到权利要求文本")

        return patent_data
