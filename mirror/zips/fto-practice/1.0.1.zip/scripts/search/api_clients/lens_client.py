import os
import time
import requests
from typing import Dict, Any, Optional

from search.api_clients.base_client import BasePatentClient
from core.models.patent_data import PatentData, PatentBibliography, PatentLegalStatus, PatentClaim, UnifiedSearchResult

class LensClient(BasePatentClient):
    """
    Lens.org API 客户端
    参考: https://docs.api.lens.org/getting-started.html
    """
    
    def __init__(self, token: Optional[str] = None):
        """
        :param token: Lens API 访问令牌。如果未提供，则抛出异常
        """
        super().__init__()
        
        self.token = token
        if not self.token or self.token == "YOUR_LENS_API_TOKEN_HERE":
            raise ValueError("未提供 Lens API Token。请在初始化时传入，或在统一配置解析器中设置。")
            
        self.base_url = "https://api.lens.org/patent/search"
        self.headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json"
        }

    def authenticate(self) -> str:
        """
        Lens API 使用静态长效 Token，无需动态刷新
        """
        return self.token

    def _execute_request(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        执行 HTTP POST 请求，并处理 429 速率限制 (Rate Limiting)
        """
        max_retries = 3
        for attempt in range(max_retries):
            response = requests.post(self.base_url, headers=self.headers, json=payload)
            
            if response.status_code == 200:
                return response.json()
            elif response.status_code == 429:
                # 处理 Rate Limiting
                retry_after = response.headers.get("x-rate-limit-retry-after-seconds")
                wait_time = int(retry_after) if retry_after else 8  # 默认等待 8 秒 (参考官方示例)
                print(f"⚠️ Lens API 触发速率限制 (429 Too Many Requests)，等待 {wait_time} 秒后重试...")
                time.sleep(wait_time)
            else:
                raise Exception(f"Lens API 请求失败! HTTP {response.status_code}: {response.text}")
                
        raise Exception(f"Lens API 请求失败! 超过最大重试次数 ({max_retries})。")

    def _search_by_patent_number(self, patent_number: str, includes: list) -> Dict[str, Any]:
        """
        通过专利公开号检索并返回指定字段
        注意: Lens 的 query_string 默认会在所有字段搜索，对具体号码搜索较为宽容
        """
        payload = {
            "query": {
                "query_string": {
                    "query": f'"{patent_number}"'
                }
            },
            "include": includes,
            "size": 1
        }
        return self._execute_request(payload)

    def get_patent_claims(self, patent_number: str) -> Dict[str, Any]:
        """
        获取指定专利的权利要求
        """
        return self._search_by_patent_number(patent_number, ["doc_key", "claims"])

    def get_patent_bibliography(self, patent_number: str) -> Dict[str, Any]:
        """
        获取专利著录项目信息
        """
        return self._search_by_patent_number(patent_number, ["doc_key", "biblio"])

    def get_patent_legal_status(self, patent_number: str) -> Dict[str, Any]:
        """
        获取专利法律状态
        """
        return self._search_by_patent_number(patent_number, ["doc_key", "legal_status"])

    def _translate_query(self, query: str) -> str:
        """
        将通用的检索语法翻译为 Lens 支持的 Elasticsearch query_string 语法
        例如:
        TAC: -> title: OR abstract: OR claim:
        IPC_CPC: -> class_ipc.symbol: OR class_cpc.symbol:
        ANCS: -> applicant.name:
        """
        import re
        
        # 提取括号内容的辅助函数
        def replace_field_dialect(q: str, prefix: str, replacement_func) -> str:
            while True:
                start_idx = q.find(prefix + ":(")
                if start_idx == -1:
                    break
                
                # 寻找匹配的右括号
                open_parens = 0
                content_start = start_idx + len(prefix) + 2
                content_end = -1
                
                for i in range(content_start, len(q)):
                    if q[i] == '(':
                        open_parens += 1
                    elif q[i] == ')':
                        if open_parens == 0:
                            content_end = i
                            break
                        else:
                            open_parens -= 1
                            
                if content_end == -1:
                    # 括号不匹配，直接跳过或者截断
                    break
                    
                content = q[content_start:content_end]
                replaced_content = replacement_func(content)
                q = q[:start_idx] + replaced_content + q[content_end+1:]
            return q
            
        # 1. 替换 TAC:
        def replace_tac(content):
            # 移除嵌套的括号以平铺 OR 关系
            content = content.replace("(", "").replace(")", "")
            parts = [p.strip() for p in content.split(" OR ")]
            formatted_parts = [f'"{p.strip().replace(chr(34), "")}"' for p in parts if p.strip()]
            formatted_content = " OR ".join(formatted_parts)
            return f"(title:({formatted_content}) OR title_zh:({formatted_content}) OR abstract:({formatted_content}) OR abstract_zh:({formatted_content}) OR claim:({formatted_content}) OR claim_zh:({formatted_content}))"
            
        query = replace_field_dialect(query, "TAC", replace_tac)
        query = replace_field_dialect(query, "TACD", replace_tac) # 暂且当做TAC处理
        
        # 2. 替换 IPC_CPC:
        def replace_ipc(content):
            content = content.replace("(", "").replace(")", "")
            parts = [p.strip() for p in content.split(" OR ")]
            formatted_parts = []
            for p in parts:
                p = p.strip().replace(chr(34), "")
                if not p:
                    continue
                p = p.replace("/", r"\/")
                if not p.endswith("*"):
                    p += "*"
                formatted_parts.append(p)
            formatted_content = " OR ".join(formatted_parts)
            return f"(class_ipc.symbol:({formatted_content}) OR class_cpc.symbol:({formatted_content}))"
            
        query = replace_field_dialect(query, "IPC_CPC", replace_ipc)
        
        # 3. 替换 ANCS: / PA:
        def replace_ancs(content):
            content = content.replace("(", "").replace(")", "")
            parts = [p.strip() for p in content.split(" OR ")]
            formatted_parts = [f'"{p.strip().replace(chr(34), "")}"' for p in parts if p.strip()]
            formatted_content = " OR ".join(formatted_parts)
            return f"applicant.name:({formatted_content})"
            
        query = replace_field_dialect(query, "ANCS", replace_ancs)
        query = replace_field_dialect(query, "PA", replace_ancs)
        
        # Lens 不支持 NOT 操作符的括号直接紧跟，通常需要将其替换为 AND NOT
        query = query.replace(") NOT (", ") AND NOT (")
        
        return query

    def search_patents(self, query: str, limit: int = 100, offset: int = 0) -> Dict[str, Any]:
        """
        检索式检索专利
        :param query: Elasticsearch 风格的查询体字典或简单查询字符串
        """
        # 如果传入的是 JSON 字符串，则尝试解析；如果是普通字符串，则用 query_string
        import json
        
        # 翻译方言
        translated_query = self._translate_query(query)
        
        try:
            query_obj = json.loads(translated_query)
            if "query" in query_obj:
                payload = query_obj
            else:
                payload = {"query": query_obj}
        except json.JSONDecodeError:
            payload = {
                "query": {
                    "query_string": {
                        "query": translated_query
                    }
                }
            }
            
        payload["size"] = limit
        payload["from"] = offset
        
        # 处理分页与 Scroll 的简单情况（此处支持了基本的 from/size 分页）
        return self._execute_request(payload)

    def execute_unified_search(self, query: str, limit: int = 100, offset: int = 0) -> UnifiedSearchResult:
        """
        执行统一结构的专利检索 (Lens 实现)
        """
        raw_result = self.search_patents(query, limit=limit, offset=offset)
        
        hit_count = 0
        patent_numbers = []
        
        try:
            if raw_result and type(raw_result) is dict:
                # Some lens api responses return hits directly if no aggregation
                if "data" in raw_result:
                    hit_count = raw_result.get("total", 0)
                    data_obj = raw_result.get("data")
                    if isinstance(data_obj, list):
                        hits = data_obj
                    elif isinstance(data_obj, dict):
                        hits = data_obj.get("search", {}).get("hits", [])
                    else:
                        hits = []
                elif "results" in raw_result:
                     hit_count = raw_result.get("total", 0)
                     hits = raw_result.get("results", [])
                else:
                    hit_count = raw_result.get("total", 0)
                    hits = raw_result.get("hits", [])
                
                for doc in hits:
                    if type(doc) is dict:
                        pn = doc.get("doc_key") or doc.get("patent_number") or doc.get("lens_id")
                        if pn:
                            patent_numbers.append(pn)
        except Exception as e:
            print(f"Error parsing lens search result: {e}, raw_result: {raw_result}")
                    
        return UnifiedSearchResult(
            hit_count=hit_count,
            patent_numbers=patent_numbers,
            raw_response=raw_result
        )

    def get_patent_description(self, patent_number: str) -> str:
        """获取专利说明书文本"""
        return ""
        
    def get_standardized_patent_data(self, patent_number: str) -> PatentData:
        """
        获取统一专利数据模型 (Lens 实现)
        """
        patent_data = PatentData(
            source_platform="lens",
            raw_source_data={}
        )
        
        try:
            # Lens 支持在一个请求中同时包含 biblio, claims, legal_status, abstract 等
            raw_data = self._search_by_patent_number(patent_number, ["doc_key", "biblio", "claims", "legal_status", "abstract"])
            patent_data.raw_source_data['full_response'] = raw_data
            
            data_obj = raw_data.get('data')
            if isinstance(data_obj, list):
                hits = data_obj
            elif isinstance(data_obj, dict):
                hits = data_obj.get('search', {}).get('hits', [])
            elif "results" in raw_data:
                hits = raw_data.get("results", [])
            else:
                hits = raw_data.get("hits", [])
                
            if hits:
                doc = hits[0]
                biblio = doc.get('biblio', {})
                legal_status = doc.get('legal_status', {})
                
                # 提取标题
                title_list = biblio.get('invention_title', [])
                title_text = title_list[0].get('text', '') if title_list and isinstance(title_list, list) else ''
                
                # 提取摘要
                abstract_list = doc.get('abstract', [])
                abstract_text = abstract_list[0].get('text', '') if abstract_list and isinstance(abstract_list, list) else ''
                
                patent_data.bibliography = PatentBibliography(
                    patent_number=doc.get('doc_key', patent_number) or patent_number,
                    title=title_text,
                    abstract=abstract_text,
                    application_date=biblio.get('application_reference', {}).get('date', ''),
                    publication_date=biblio.get('publication_reference', {}).get('date', ''),
                    assignees=[a.get('name', '') or a.get('extracted_name', {}).get('value', '') for a in biblio.get('parties', {}).get('applicants', [])],
                    inventors=[i.get('name', '') or i.get('extracted_name', {}).get('value', '') for i in biblio.get('parties', {}).get('inventors', [])],
                    ipc_classes=[ipc.get('symbol', '') for ipc in biblio.get('classifications_ipcr', {}).get('classifications', [])]
                )
                
                status_code = legal_status.get('patent_status', '')
                patent_data.legal_status = PatentLegalStatus(
                    status_code=status_code,
                    status_description=status_code,
                    date=legal_status.get('anticipated_term_date', ''),
                    is_active='ACTIVE' in str(status_code).upper()
                )
                
                # 提取权利要求
                raw_claims = doc.get('claims', [])
                claims_list = []
                if raw_claims and isinstance(raw_claims, list):
                    c_dict = raw_claims[0]
                    if 'claims' in c_dict:
                        claims_list = c_dict['claims']
                        
                for idx, c in enumerate(claims_list):
                    if isinstance(c, dict) and 'claim_text' in c:
                        claim_text_parts = c['claim_text']
                        if isinstance(claim_text_parts, list):
                            claim_text = "\n".join([str(p) for p in claim_text_parts])
                        else:
                            claim_text = str(claim_text_parts)
                    else:
                        claim_text = str(c)
                        
                    patent_data.claims.append(PatentClaim(
                        claim_number=str(idx + 1),
                        claim_text=claim_text,
                        is_independent=(idx == 0)
                    ))
        except Exception as e:
            print(f"Lens API 获取标准化数据失败: {e}")

        return patent_data
