from typing import List, Dict, Any, Optional, Union
import json
import logging
from core.db_manager import DatabaseManager

logger = logging.getLogger(__name__)

class PatentRepository:
    """
    负责专利数据的持久化和仓储层，将 fetchers 与底层具体的 SQL / DatabaseManager 解耦。
    适配极简4表设计：
    1. project_meta - 全局配置（靶子）
    2. patent_raw_data - 检索底表
    3. step06_screening - 初筛表
    4. step07_comparison - 深度比对表
    """

    def __init__(self, db_manager: DatabaseManager = None):
        self.db = db_manager or DatabaseManager()

    def save_project_meta(self, target_title: str = None, target_abstract: str = None, target_tech_solution: str = None):
        """保存全局配置（靶子技术方案）"""
        self.db.save_project_meta(target_title, target_abstract, target_tech_solution)

    def get_project_meta(self) -> Optional[Dict[str, Any]]:
        """获取全局配置"""
        return self.db.get_project_meta()

    def save_target_patents(self, patent_list: List[Dict[str, Any]]):
        """保存靶点专利列表到底表"""
        self.db.save_patents(patent_list, source="target_pool")

    def save_sample_patents(self, patent_list: List[Dict[str, Any]]):
        """保存样本专利列表到底表"""
        self.db.save_patents(patent_list, source="sample")

    def save_round_sample_patents(self, patent_list: List[Dict[str, Any]], round_id: str):
        """按 Step5 轮次写入样本专利。"""
        self.db.save_patents(patent_list, source=f"step05_round_{round_id}")

    def bulk_import_patents(self, patent_list: List[Dict[str, Any]], source: str = "target_pool", node: str = None):
        """
        批量导入本地专利数据到底表
        patent_list 中的每一项应该是包含 patent_id/publication_number 的字典
        """
        self.db.save_patents(patent_list, source=source, node=node)

    def get_all_patents(self) -> List[Dict[str, Any]]:
        """获取所有专利底表数据"""
        return self.db.get_all_patents()

    def get_patent_by_id(self, patent_id: str) -> Optional[Dict[str, Any]]:
        """根据 patent_id 获取单条专利"""
        return self.db.get_patent_by_id(patent_id)

    def get_patents_for_filter(self) -> List[Dict[str, Any]]:
        """
        获取待进行初筛的专利列表（用于06步 Filter）
        """
        return self.db.get_all_patents()

    def get_patents_with_claims(self) -> List[Dict[str, Any]]:
        """
        获取已包含权利要求的专利列表（用于06步 Filter Processor 和 07步 FTO）
        """
        all_patents = self.db.get_all_patents()
        return [p for p in all_patents if p.get("full_claims") or p.get("claims_text")]

    def save_patent_assessment(
        self,
        publication_number: str = None,
        risk_score: int = None,
        assessment_summary: str = "",
        feature_matches: List[Any] = None,
        analysis_conclusion: str = "",
        assessment_stage: str = "filtered",
        source_platform: str = "",
        patent_number: str = None,
        relevance_score: int = None,
        node: str = None,
        reason: str = None,
    ):
        """保存06初筛评估结果"""
        resolved_patent_id = publication_number or patent_number
        if not resolved_patent_id:
            raise ValueError("publication_number/patent_number 不能为空")

        resolved_score = risk_score if risk_score is not None else (relevance_score if relevance_score is not None else 0)
        is_passed = resolved_score >= 1 if resolved_score is not None else False

        self.db.save_screening_result(
            patent_id=resolved_patent_id,
            score=resolved_score,
            is_passed=is_passed,
            node=node or assessment_summary or "",
            reason=reason or analysis_conclusion or ""
        )

    def get_patent_assessments(self, assessment_stage: str = None) -> List[Dict[str, Any]]:
        """获取初筛评估结果"""
        return self.db.get_screening_results()

    def get_passed_patents(self) -> List[Dict[str, Any]]:
        """获取06步筛选通过的专利"""
        return self.db.get_screening_results(is_passed=True)

    def get_patents_for_fto(self, limit: int = 100) -> List[Dict[str, Any]]:
        """
        获取待进行FTO比对的专利（用于07步）
        优先从 step06_screening 中获取 is_passed=1 的专利
        """
        return self.db.get_patents_for_fto(limit=limit)

    def get_fto_pending_patents(self, limit: int = 100) -> List[Dict[str, Any]]:
        """获取尚未进行FTO比对的专利（07步断点续跑用）"""
        return self.db.get_fto_pending_patents(limit=limit)

    def get_step1_done_step2_pending_patents(self, limit: int = 100) -> List[Dict[str, Any]]:
        """获取已完成Step1但未完成Step2的专利（断点续传用）"""
        return self.db.get_step1_done_step2_pending_patents(limit=limit)

    def save_comparison_result(
        self,
        patent_id: str,
        independent_claims: str = None,
        extracted_features: str = None,
        feature_matches: List[Dict] = None,
        final_risk_conclusion: str = None,
        stage: str = None,
        raw_llm_output: str = None
    ):
        """保存07深度比对结果，支持断点续传"""
        self.db.save_comparison_result(
            patent_id=patent_id,
            independent_claims=independent_claims,
            extracted_features=extracted_features,
            feature_matches=feature_matches,
            final_risk_conclusion=final_risk_conclusion,
            stage=stage,
            raw_llm_output=raw_llm_output
        )

    def get_comparison_results(self, patent_id: str = None) -> List[Dict[str, Any]]:
        """获取深度比对结果"""
        return self.db.get_comparison_results(patent_id=patent_id)

    def clear_screening_results(self):
        """清空初筛结果"""
        self.db.clear_screening_results()

    def clear_comparison_results(self):
        """清空深度比对结果"""
        self.db.clear_comparison_results()

    def save_step05_eval_result(
        self,
        round_id: str,
        patent_id: str,
        score: int,
        reason: str = "",
        llm_provider: str = "",
        attempts: int = 1,
        error_type: Optional[str] = None,
        status: str = "success",
    ):
        self.db.save_step05_eval_result(
            round_id=round_id,
            patent_id=patent_id,
            score=score,
            reason=reason,
            llm_provider=llm_provider,
            attempts=attempts,
            error_type=error_type,
            status=status,
        )

    def save_step05_eval_metrics(
        self,
        round_id: str,
        query_text: str,
        hit_count: int,
        sample_count: int,
        evaluated_count: int,
        non_noise_count: int,
        precision: float,
        llm_provider: str = "",
        retry_histogram: Optional[Union[Dict[int, int], Dict[str, int]]] = None,
        error_type_histogram: Optional[Dict[str, int]] = None,
    ):
        self.db.save_step05_eval_metrics(
            round_id=round_id,
            query_text=query_text,
            hit_count=hit_count,
            sample_count=sample_count,
            evaluated_count=evaluated_count,
            non_noise_count=non_noise_count,
            precision=precision,
            llm_provider=llm_provider,
            retry_histogram=retry_histogram,
            error_type_histogram=error_type_histogram,
        )

    def get_step05_eval_results(self, round_id: str) -> List[Dict[str, Any]]:
        return self.db.get_step05_eval_results(round_id=round_id)

    def get_step05_eval_metrics(self, round_id: Optional[str] = None) -> List[Dict[str, Any]]:
        return self.db.get_step05_eval_metrics(round_id=round_id)

    def clear_step05_round(self, round_id: str):
        self.db.clear_step05_round(round_id=round_id)

    def update_patent_claims(self, patent_id: str, claims_text: str):
        """更新专利的权利要求文本"""
        conn = self.db.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE "patent_raw_data" SET full_claims = ?, updated_at = CURRENT_TIMESTAMP
            WHERE patent_id = ?
        ''', (claims_text, patent_id))
        conn.commit()
        conn.close()
