import argparse
import re
import sqlite3

from tqdm import tqdm


def extract_independent_claims(claims_text: str) -> str:
    """从 full_claims 中提取独立权利要求文本。"""
    if not claims_text or claims_text == "无权利要求":
        return ""

    text = claims_text.replace("\r\n", "\n")
    pattern = re.compile(r"(?:^|\n)\s*(\[\d+\]|\d+[\.、])\s*")
    parts = pattern.split(text)
    claims_list = []

    if len(parts) == 1:
        return text

    idx = 1 if not parts[0].strip() else 0
    expected_num = 1
    current_num_str = ""
    current_content = parts[0] if idx == 1 else ""

    while idx < len(parts):
        if idx + 1 < len(parts) and re.match(r"^(\[\d+\]|\d+[\.、])$", parts[idx]):
            num_str = parts[idx]
            content_part = parts[idx + 1]
            num_val = int(re.sub(r"[^\d]", "", num_str))

            if num_val == expected_num:
                if current_num_str or current_content.strip():
                    claims_list.append((current_num_str, current_content.strip()))
                current_num_str = num_str
                current_content = content_part
                expected_num += 1
            else:
                current_content += "\n" + num_str + content_part
            idx += 2
        else:
            if parts[idx].strip():
                current_content += "\n" + parts[idx]
            idx += 1

    if current_num_str or current_content.strip():
        claims_list.append((current_num_str, current_content.strip()))

    independent_claims = []
    for num, content in claims_list:
        if not content:
            continue
        clean_content = content.strip()
        is_dependent = False

        if re.match(r"^(?:根据|如|基于|按照)?权利要求\s*\d+", clean_content):
            is_dependent = True
        elif clean_content.startswith("所述"):
            is_dependent = True

        if not is_dependent:
            prefix = num if num else ""
            independent_claims.append(f"{prefix} {content}".strip())

    if not independent_claims and claims_list:
        first_num, first_content = claims_list[0]
        return f"{first_num} {first_content}".strip()

    return "\n\n".join(independent_claims)


def main():
    parser = argparse.ArgumentParser(description="提取独立权利要求并写入 patent_claims 表")
    parser.add_argument("--db_path", required=True, help="SQLite 数据库文件路径")
    parser.add_argument("--patent_id", type=str, help="仅处理指定公开号（可选，不填则处理全部）")
    args = parser.parse_args()

    conn = sqlite3.connect(args.db_path)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    if args.patent_id:
        cursor.execute(
            'SELECT patent_id, full_claims FROM "patent_raw_data" WHERE patent_id = ? AND full_claims IS NOT NULL AND full_claims != ""',
            (args.patent_id,),
        )
    else:
        cursor.execute(
            'SELECT patent_id, full_claims FROM "patent_raw_data" WHERE full_claims IS NOT NULL AND full_claims != ""'
        )

    rows = cursor.fetchall()
    print(f"🚀 开始处理 {len(rows)} 篇专利的权利要求...")

    update_count = 0
    for row in tqdm(rows, desc="提取进度"):
        patent_id = row["patent_id"]
        claims_text = row["full_claims"]
        indep_claims = extract_independent_claims(claims_text)
        if indep_claims:
            cursor.execute(
                """
                INSERT INTO "patent_claims" (patent_id, independent_claims)
                VALUES (?, ?)
                ON CONFLICT(patent_id) DO UPDATE SET
                    independent_claims = excluded.independent_claims,
                    extracted_at = CURRENT_TIMESTAMP
                """,
                (patent_id, indep_claims),
            )
            update_count += 1

    conn.commit()
    conn.close()
    print(f"🎉 提取完成，成功更新 {update_count} 篇专利的独立权利要求！")
    print("   结果已写入 patent_claims 表的 independent_claims 字段。")


if __name__ == "__main__":
    main()
