import pandas as pd
import numpy as np
import logging
import os
from typing import List, Dict, Any, Optional

from core.models.patent_data import PatentData, PatentBibliography, PatentLegalStatus, PatentClaim
from repository.patent_repository import PatentRepository

logger = logging.getLogger(__name__)


class ImportService:
    """
    处理本地专利数据文件（Excel/CSV）导入到数据库的服务
    适配极简4表设计：数据导入到 patent_raw_data 表
    """
    def __init__(self, repository: PatentRepository = None):
        self.repository = repository or PatentRepository()

    def import_local_file(
        self,
        file_path: str,
        patent_id: Optional[str] = None,
        title: Optional[str] = None,
        abstract: Optional[str] = None,
        full_claims: Optional[str] = None,
        application_number: Optional[str] = None,
        application_date: Optional[str] = None,
        publication_date: Optional[str] = None,
        assignees: Optional[str] = None,
        legal_status: Optional[str] = None,
        node: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        读取本地文件 (.xlsx, .csv)，根据传入的列映射导入到数据库
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"文件不存在: {file_path}")

        df = self._read_file(file_path)

        col_mapping = {
            "patent_id": patent_id,
            "title": title,
            "abstract": abstract,
            "full_claims": full_claims,
            "application_number": application_number,
            "application_date": application_date,
            "publication_date": publication_date,
            "assignees": assignees,
            "legal_status": legal_status,
        }

        reverse_map = {v: k for k, v in col_mapping.items() if v}
        df = df.rename(columns=reverse_map)
        df = df.replace({np.nan: None})

        records = df.to_dict('records')

        patent_records = []
        success_count = 0
        skip_count = 0

        for record in records:
            pub_num = record.get("patent_id")
            if not pub_num:
                skip_count += 1
                continue

            assignees_raw = record.get("assignees", "")
            assignees_parsed = self._parse_list_field(assignees_raw)

            patent_record = {
                "patent_id": str(pub_num).strip(),
                "title": str(record.get("title", "") or "").strip(),
                "abstract": str(record.get("abstract", "") or "").strip(),
                "full_claims": str(record.get("full_claims", "") or "").strip(),
                "application_number": str(record.get("application_number", "") or "").strip(),
                "application_date": str(record.get("application_date", "") or "").strip(),
                "publication_date": str(record.get("publication_date", "") or "").strip(),
                "assignees": assignees_parsed,
                "legal_status": str(record.get("legal_status", "") or "").strip(),
                "raw_data": record
            }
            patent_records.append(patent_record)
            success_count += 1

        if patent_records:
            self.repository.bulk_import_patents(patent_records, source="target_pool", node=node)

        summary = {
            "total_rows": len(records),
            "success_count": success_count,
            "skip_count": skip_count,
            "mapped_columns": {v: k for k, v in col_mapping.items() if v}
        }

        logger.info(f"本地文件导入完成: 成功 {success_count} 条，跳过 {skip_count} 条")
        return summary

    def _read_file(self, file_path: str) -> pd.DataFrame:
        """读取文件并返回 DataFrame"""
        file_path_lower = file_path.lower()
        try:
            if file_path_lower.endswith('.json'):
                import json
                with open(file_path, 'r', encoding='utf-8') as f:
                    json_data = json.load(f)

                if isinstance(json_data, dict) and "patent_numbers" in json_data:
                    return pd.DataFrame([{"patent_id": pn} for pn in json_data["patent_numbers"]])
                elif isinstance(json_data, list):
                    return pd.DataFrame(json_data)
                elif isinstance(json_data, dict) and "samples" in json_data:
                    return pd.DataFrame(json_data["samples"])
                else:
                    return pd.DataFrame([json_data] if isinstance(json_data, dict) else json_data)
            elif file_path_lower.endswith('.csv'):
                return pd.read_csv(file_path)
            elif file_path_lower.endswith(('.xlsx', '.xls')):
                return pd.read_excel(file_path)
            elif file_path_lower.endswith('.zip'):
                import zipfile
                import tempfile
                with zipfile.ZipFile(file_path, 'r') as z:
                    excel_files = [f for f in z.namelist() if f.endswith(('.xlsx', '.xls', '.csv'))]
                    if not excel_files:
                        raise ValueError(f"ZIP 文件中没有找到 .xlsx 或 .csv 文件: {file_path}")
                    target_file = 'index.xlsx' if 'index.xlsx' in excel_files else excel_files[0]
                    with tempfile.TemporaryDirectory() as tmpdir:
                        extracted_path = z.extract(target_file, tmpdir)
                        if target_file.endswith('.csv'):
                            return pd.read_csv(extracted_path)
                        else:
                            return pd.read_excel(extracted_path)
            else:
                raise ValueError(f"不支持的文件格式: {file_path}")
        except Exception as e:
            logger.error(f"读取文件失败 {file_path}: {e}")
            raise e

    def _parse_list_field(self, value: Any) -> List[str]:
        """解析列表型字段（申请人等）"""
        if isinstance(value, str) and value:
            for sep in [';', '；', ',', '，']:
                if sep in value:
                    return [v.strip() for v in value.split(sep) if v.strip()]
            return [value.strip()]
        elif isinstance(value, list):
            return value
        return []
