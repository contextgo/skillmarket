import os
import sys
import json
import argparse

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.db_manager import DatabaseManager
from repository.patent_repository import PatentRepository
from importer.import_service import ImportService


def main():
    parser = argparse.ArgumentParser(
        description="专利数据导入 CLI：接收列映射参数，执行物理落库"
    )
    parser.add_argument("--db_path", type=str, required=True, help="SQLite 数据库文件路径")
    parser.add_argument("--file", type=str, required=True, help="要导入的本地文件路径 (.xlsx, .csv, .json, .zip)")
    parser.add_argument("--patent_id", type=str, help="专利号/公开号列名")
    parser.add_argument("--title", type=str, help="发明名称列名")
    parser.add_argument("--abstract", type=str, help="摘要列名")
    parser.add_argument("--full_claims", type=str, help="权利要求书全文列名")
    parser.add_argument("--application_number", type=str, help="申请号列名")
    parser.add_argument("--application_date", type=str, help="申请日期列名")
    parser.add_argument("--publication_date", type=str, help="公开日/公告日列名")
    parser.add_argument("--assignees", type=str, help="申请人/专利权人列名")
    parser.add_argument("--legal_status", type=str, help="法律状态列名")
    parser.add_argument("--node", type=str, help="附加的技术分类节点标签 (可选)")

    args = parser.parse_args()

    try:
        db_manager = DatabaseManager(db_path=args.db_path)
        repo = PatentRepository(db_manager=db_manager)
        import_service = ImportService(repository=repo)

        result = import_service.import_local_file(
            file_path=args.file,
            patent_id=args.patent_id,
            title=args.title,
            abstract=args.abstract,
            full_claims=args.full_claims,
            application_number=args.application_number,
            application_date=args.application_date,
            publication_date=args.publication_date,
            assignees=args.assignees,
            legal_status=args.legal_status,
            node=args.node
        )
        print(json.dumps({"status": "success", "result": result}, ensure_ascii=False, indent=2))

    except FileNotFoundError as e:
        print(json.dumps({"status": "error", "message": f"文件不存在: {e}"}, ensure_ascii=False))
        sys.exit(1)
    except ValueError as e:
        print(json.dumps({"status": "error", "message": f"数据验证错误: {e}"}, ensure_ascii=False))
        sys.exit(1)
    except Exception as e:
        print(json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False))
        sys.exit(1)


if __name__ == "__main__":
    main()
