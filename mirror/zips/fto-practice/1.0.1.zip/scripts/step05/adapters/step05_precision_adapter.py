from __future__ import annotations

from typing import Any

from core.models.patent_data import RelevanceResult4Tier
from step05.prompting.prompt_assembler import assemble_step05_precision_prompt


class Step05PrecisionAdapter:
    response_model = RelevanceResult4Tier
    job_type = "step5_precision_eval"
    temperature = 0.1
    failure_status = "failed"

    def __init__(self, repo, features: str, round_id: str, provider: str, llm_provider: str):
        self.repo = repo
        self.features = features
        self.round_id = str(round_id)
        self.provider = provider
        self.llm_provider = llm_provider
        self._fallback_logged = False

    def build_prompt(self, ctx: dict[str, Any]) -> str:
        patent_id = str(ctx.get("patent_id") or ctx.get("publication_number") or "").strip()
        patent_title = str(ctx.get("title") or "").strip()
        independent_claims = str(ctx.get("independent_claims") or "").strip()
        if not independent_claims or len(independent_claims) < 10:
            raise ValueError(f"专利 {patent_id} ({patent_title}) 的独立权利要求文本无效或过短。")
        prompt, fallback = assemble_step05_precision_prompt(
            features_text=self.features,
            provider=self.provider,
            patent_id=patent_id,
            patent_title=patent_title,
            independent_claims=independent_claims,
        )
        if fallback:
            self._fallback_logged = True
        return prompt

    def get_cleanser(self):
        return None

    def augment_retry_prompt(self, base_prompt: str, attempt: int, error: Exception | None) -> str:
        err = f"\n上次错误: {str(error)[:200]}" if error else ""
        return base_prompt + f"\n\n注意：第 {attempt} 次重试。请仅返回合法 JSON，字段必须为 score/reason/node。{err}"

    def on_success(self, ctx: dict[str, Any], parsed: RelevanceResult4Tier | dict[str, Any], raw_text: str, stats: dict[str, Any]) -> None:
        patent_id = str(ctx.get("patent_id") or ctx.get("publication_number") or "").strip()
        result = parsed.model_dump() if hasattr(parsed, "model_dump") else dict(parsed)
        self.repo.save_step05_eval_result(
            round_id=self.round_id,
            patent_id=patent_id,
            score=int(result.get("score", 0)),
            reason=result.get("reason", ""),
            llm_provider=self.llm_provider,
            attempts=int(stats.get("attempts", 1)),
            error_type=stats.get("error_type"),
            status="success",
        )

    def on_failure(self, ctx: dict[str, Any], error: Exception, raw_text: str | None, stats: dict[str, Any]) -> None:
        patent_id = str(ctx.get("patent_id") or ctx.get("publication_number") or "").strip()
        reason = str(error)[:120]
        if self._fallback_logged:
            reason = f"[provider_fallback] {reason}"
        self.repo.save_step05_eval_result(
            round_id=self.round_id,
            patent_id=patent_id,
            score=0,
            reason=reason,
            llm_provider=self.llm_provider,
            attempts=int(stats.get("attempts", 1)),
            error_type=stats.get("error_type"),
            status="failed",
        )
