from __future__ import annotations

import asyncio
import os
import sys
from typing import Any

from core.config_resolver import ConfigResolver
from core.db_manager import DatabaseManager
from core.llm_batch.job_runner import BatchJobRunner
from core.llm_batch.logging_manager import BatchLoggingManager
from core.llm_batch.parse_pipeline import ParsePipeline
from core.llm_batch.retry_executor import execute_with_retry
from core.llm_batch.transport import LLMTransport
from core.llm_client import LLMClient
from repository.patent_repository import PatentRepository
from step05.adapters.step05_precision_adapter import Step05PrecisionAdapter


def _build_llm_client(llm_provider: str) -> LLMClient:
    creds = ConfigResolver.resolve_llm(llm_provider)
    return LLMClient(api_key=creds.api_key, base_url=creds.base_url, actual_model=creds.model_name)


def _collect_jobs(db: DatabaseManager, source: str | None, patent_ids: list[str] | None) -> list[dict[str, Any]]:
    all_patents = db.get_all_patents()
    selected = []
    patent_ids_set = set(patent_ids or [])
    for p in all_patents:
        patent_id = p.get("patent_id")
        if patent_ids_set and patent_id not in patent_ids_set:
            continue
        if source and p.get("source") != source:
            continue
        claims = db.get_patent_claims(patent_id) if patent_id else None
        selected.append(
            {
                "patent_id": patent_id,
                "title": p.get("title", ""),
                "independent_claims": (claims or {}).get("independent_claims") or p.get("full_claims", ""),
            }
        )
    return selected


async def run_step05_precision_eval(
    *,
    db_path: str,
    features_text: str,
    llm_provider: str,
    provider: str,
    round_id: str,
    query_text: str,
    hit_count: int,
    patent_ids: list[str] | None = None,
    source: str | None = None,
    concurrency: int = 10,
    max_attempts: int = 2,
) -> dict[str, Any]:
    if not os.path.exists(os.path.dirname(os.path.abspath(db_path))):
        os.makedirs(os.path.dirname(os.path.abspath(db_path)), exist_ok=True)

    log_file = BatchLoggingManager().setup_for_step("step5_precision_eval", db_path)
    db = DatabaseManager(db_path=db_path)
    repo = PatentRepository(db_manager=db)
    jobs = _collect_jobs(db, source=source, patent_ids=patent_ids)
    if not jobs:
        repo.save_step05_eval_metrics(
            round_id=round_id,
            query_text=query_text,
            hit_count=hit_count,
            sample_count=0,
            evaluated_count=0,
            non_noise_count=0,
            precision=0.0,
            llm_provider=llm_provider,
            retry_histogram={},
            error_type_histogram={},
        )
        return {
            "round_id": round_id,
            "hit_count": hit_count,
            "sample_count": 0,
            "evaluated_count": 0,
            "non_noise_count": 0,
            "precision": 0.0,
            "noise_samples": [],
            "log_file": log_file,
            "stats": {"success_count": 0, "failed_count": 0, "skipped_count": 0},
        }

    llm_client = _build_llm_client(llm_provider)
    transport = LLMTransport(llm_client=llm_client)
    parse_pipeline = ParsePipeline()
    adapter = Step05PrecisionAdapter(
        repo=repo,
        features=features_text,
        round_id=round_id,
        provider=provider,
        llm_provider=llm_provider,
    )
    runner = BatchJobRunner(worker_count=max(1, int(concurrency or 1)))
    stats_ref = {"success": 0, "failed": 0, "skipped": 0}

    async def spinner():
        chars = ["-", "\\", "|", "/"]
        idx = 0
        try:
            while True:
                done = stats_ref["success"] + stats_ref["failed"] + stats_ref["skipped"]
                sys.stdout.write(f"\r{chars[idx]} Step5评估进度: {done}/{len(jobs)}")
                sys.stdout.flush()
                idx = (idx + 1) % len(chars)
                await asyncio.sleep(0.1)
        except asyncio.CancelledError:
            done = stats_ref["success"] + stats_ref["failed"] + stats_ref["skipped"]
            sys.stdout.write(f"\r✅ Step5评估进度: {done}/{len(jobs)}\n")
            sys.stdout.flush()

    spinner_task = asyncio.create_task(spinner())
    try:
        async def processor(job_ctx: dict[str, Any]) -> dict[str, Any]:
            _, result = await execute_with_retry(
                adapter=adapter,
                ctx=job_ctx,
                transport=transport,
                parse_pipeline=parse_pipeline,
                max_attempts=max_attempts,
            )
            return result

        def progress_callback(run_stats) -> None:
            stats_ref["success"] = run_stats.success_count
            stats_ref["failed"] = run_stats.failed_count
            stats_ref["skipped"] = run_stats.skipped_count

        run_stats = await runner.run(jobs=jobs, processor=processor, progress_callback=progress_callback)
    finally:
        spinner_task.cancel()
        try:
            await spinner_task
        except asyncio.CancelledError:
            pass

    rows = repo.get_step05_eval_results(round_id=round_id)
    success_rows = [r for r in rows if r.get("status") == "success"]
    evaluated_count = len(success_rows)
    non_noise_count = len([r for r in success_rows if int(r.get("score") or 0) > 0])
    precision = (non_noise_count / evaluated_count) if evaluated_count > 0 else 0.0
    noise_samples = [r for r in success_rows if int(r.get("score") or 0) <= 0][:5]

    repo.save_step05_eval_metrics(
        round_id=round_id,
        query_text=query_text,
        hit_count=int(hit_count or 0),
        sample_count=len(jobs),
        evaluated_count=evaluated_count,
        non_noise_count=non_noise_count,
        precision=precision,
        llm_provider=llm_provider,
        retry_histogram=run_stats.retry_histogram,
        error_type_histogram=run_stats.error_type_histogram,
    )

    return {
        "round_id": round_id,
        "hit_count": int(hit_count or 0),
        "sample_count": len(jobs),
        "evaluated_count": evaluated_count,
        "non_noise_count": non_noise_count,
        "precision": precision,
        "noise_samples": noise_samples,
        "log_file": log_file,
        "stats": {
            "success_count": run_stats.success_count,
            "failed_count": run_stats.failed_count,
            "skipped_count": run_stats.skipped_count,
            "retry_histogram": run_stats.retry_histogram,
            "error_type_histogram": run_stats.error_type_histogram,
        },
    }
