from __future__ import annotations

from step05.prompting.base_prompt import build_precision_base_prompt
from step05.prompting.provider_rules import resolve_provider_rule


def assemble_step05_precision_prompt(
    *,
    features_text: str,
    provider: str,
    patent_id: str,
    patent_title: str,
    independent_claims: str,
) -> tuple[str, bool]:
    rule = resolve_provider_rule(provider)
    base_prompt = build_precision_base_prompt(
        features_text=features_text,
        provider_name=provider or "unknown",
        provider_rules_text=rule.syntax_rules,
    )
    provider_warning = ""
    if rule.fallback:
        provider_warning = "【提示】provider 未识别，已降级为通用布尔规则。请尽快确认数据库类型。\n"

    prompt = (
        f"{base_prompt}\n"
        f"{provider_warning}"
        f"【待评估专利】\n"
        f"专利号: {patent_id}\n"
        f"标题: {patent_title}\n"
        f"独立权利要求:\n{independent_claims}\n"
    )
    return prompt, rule.fallback
