from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ProviderRule:
    provider: str
    syntax_rules: str
    fallback: bool = False


_COMMON_FALLBACK = ProviderRule(
    provider="generic",
    fallback=True,
    syntax_rules=(
        "你正在使用未知数据库，按保守布尔规则生成检索式：\n"
        "- 优先使用 AND / OR / NOT 与普通括号，不使用位置算符。\n"
        "- 避免数据库专有字段前缀；如无把握，仅输出纯关键词逻辑。\n"
        "- 保持表达式扁平，禁止过深嵌套。\n"
        "- 若语法不确定，优先可执行而非复杂。"
    ),
)


_RULES = {
    "lens": ProviderRule(
        provider="lens",
        syntax_rules=(
            "- Lens 不支持 TAC:，优先使用 title:, abstract:, ALL:。\n"
            "- 避免在 ALL: 内做多层括号嵌套。\n"
            "- 推荐扁平结构：ALL:(A OR B) AND ALL:(C OR D)。\n"
            "- 0 命中时优先放宽 AND，先保留核心主干词。"
        ),
    ),
    "baiten": ProviderRule(
        provider="baiten",
        syntax_rules=(
            "- Baiten 与 Lens 类似，优先扁平表达式。\n"
            "- 避免复杂深层括号与不确定的距离算符。\n"
            "- 将中英文术语分段展开，减少单组内混杂。"
        ),
    ),
    "epo": ProviderRule(
        provider="epo",
        syntax_rules=(
            "- EPO 需要字段前缀落在词条级（如 ti=, ab=）。\n"
            "- 不要在外层统一包裹字段到整段布尔式。\n"
            "- 每个术语组都应明确字段归属。"
        ),
    ),
    "zhihuiya": ProviderRule(
        provider="zhihuiya",
        syntax_rules=(
            "- 智慧芽按常规布尔表达式组织，确保括号与引号配对。\n"
            "- 优先使用稳定字段与关键词组合，避免非常规算符。\n"
            "- 尽量输出可直接执行的简洁语句。"
        ),
    ),
}


def resolve_provider_rule(provider: str) -> ProviderRule:
    if not provider:
        return _COMMON_FALLBACK
    return _RULES.get(provider.lower(), _COMMON_FALLBACK)
