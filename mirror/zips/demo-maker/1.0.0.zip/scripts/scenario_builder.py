#!/usr/bin/env python3
"""
场景脚本构建器
根据用户提供的场景描述自动构建可执行的场景脚本
"""

import re
import json
import yaml
from typing import Dict, List, Any, Optional
from datetime import datetime

class ScenarioBuilder:
    """场景脚本构建器类"""
    
    def __init__(self):
        self.templates = self._load_templates()
        
    def _load_templates(self) -> Dict[str, Any]:
        """加载场景模板"""
        return {
            "data_processing": {
                "description": "数据处理场景",
                "steps": ["数据收集", "数据清洗", "数据分析", "结果展示"],
                "skills": ["data_analysis", "visualization", "reporting"]
            },
            "workflow_automation": {
                "description": "工作流自动化场景",
                "steps": ["流程分析", "任务分解", "工具选择", "自动化实现"],
                "skills": ["automation", "scripting", "integration"]
            },
            "integration_testing": {
                "description": "集成测试场景",
                "steps": ["环境准备", "组件配置", "测试执行", "结果验证"],
                "skills": ["testing", "debugging", "monitoring"]
            }
        }
    
    def analyze_scenario_description(self, description: str) -> Dict[str, Any]:
        """分析场景描述，提取关键信息"""
        result = {
            "scenario_type": None,
            "key_tasks": [],
            "required_skills": [],
            "complexity_level": "medium",
            "estimated_steps": 4
        }
        
        # 识别场景类型
        description_lower = description.lower()
        for scenario_type, template in self.templates.items():
            if any(keyword in description_lower for keyword in template["skills"]):
                result["scenario_type"] = scenario_type
                result["required_skills"] = template["skills"]
                break
        
        # 提取关键任务
        task_patterns = [
            r"(?:需要|应该|必须|要)(.+?)(?:。|，|；|！)",
            r"(?:实现|完成|构建|创建)(.+?)(?:的|一个)",
            r"(?:目标|目的|任务)是(.+?)(?:。|，|；|！)"
        ]
        
        for pattern in task_patterns:
            matches = re.findall(pattern, description)
            result["key_tasks"].extend(matches)
        
        # 评估复杂度
        if len(result["key_tasks"]) > 5:
            result["complexity_level"] = "high"
            result["estimated_steps"] = 6
        elif len(result["key_tasks"]) < 3:
            result["complexity_level"] = "low"
            result["estimated_steps"] = 3
        
        return result
    
    def build_scenario_script(self, description: str, analysis: Dict[str, Any]) -> Dict[str, Any]:
        """构建场景脚本"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        scenario_script = {
            "metadata": {
                "id": f"scenario_{timestamp}",
                "created_at": datetime.now().isoformat(),
                "description": description,
                "analysis": analysis
            },
            "scenario": {
                "name": f"{analysis.get('scenario_type', 'custom')}_scenario",
                "type": analysis.get("scenario_type", "custom"),
                "complexity": analysis["complexity_level"],
                "estimated_duration": "2-4小时"
            },
            "workflow": self._build_workflow_steps(analysis),
            "skills_required": analysis["required_skills"],
            "test_cases": self._generate_test_cases(description),
            "deliverables": self._define_deliverables(analysis)
        }
        
        return scenario_script
    
    def _build_workflow_steps(self, analysis: Dict[str, Any]) -> List[Dict[str, str]]:
        """构建工作流步骤"""
        steps = []
        template = self.templates.get(analysis.get("scenario_type", ""), {})
        
        if template:
            # 使用模板步骤
            for i, step_name in enumerate(template["steps"], 1):
                steps.append({
                    "id": f"step_{i:02d}",
                    "name": step_name,
                    "description": f"执行{step_name}任务",
                    "estimated_time": "30分钟"
                })
        else:
            # 自定义步骤
            for i, task in enumerate(analysis["key_tasks"][:analysis["estimated_steps"]], 1):
                steps.append({
                    "id": f"step_{i:02d}",
                    "name": f"任务{i}",
                    "description": task,
                    "estimated_time": "30-45分钟"
                })
        
        return steps
    
    def _generate_test_cases(self, description: str) -> List[Dict[str, str]]:
        """生成测试用例"""
        test_cases = [
            {
                "id": "tc_01",
                "name": "功能完整性测试",
                "description": "验证所有功能模块是否正常工作",
                "expected_result": "所有功能模块返回预期结果"
            },
            {
                "id": "tc_02",
                "name": "技能串联测试",
                "description": "验证多个技能是否能正确串联工作",
                "expected_result": "技能间数据传递正常，工作流完整执行"
            },
            {
                "id": "tc_03",
                "name": "边界条件测试",
                "description": "验证在边界条件下的系统行为",
                "expected_result": "系统能够正确处理边界情况"
            }
        ]
        
        return test_cases
    
    def _define_deliverables(self, analysis: Dict[str, Any]) -> Dict[str, str]:
        """定义交付物"""
        return {
            "scenario_script": "完整的场景脚本文件（JSON格式）",
            "test_report": "测试执行报告",
            "demo_document": "飞书云文档格式的demo文档",
            "integration_summary": "技能集成总结报告"
        }
    
    def save_script(self, script: Dict[str, Any], output_path: str) -> None:
        """保存场景脚本到文件"""
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(script, f, ensure_ascii=False, indent=2)
        
        print(f"场景脚本已保存到: {output_path}")
    
    def load_script(self, script_path: str) -> Dict[str, Any]:
        """加载场景脚本"""
        with open(script_path, 'r', encoding='utf-8') as f:
            return json.load(f)


def main():
    """主函数，示例用法"""
    builder = ScenarioBuilder()
    
    # 示例场景描述
    example_description = "我需要构建一个数据分析和可视化的工作流，包括数据清洗、分析和生成报告"
    
    print("=== 场景脚本构建器 ===")
    print(f"场景描述: {example_description}")
    
    # 分析场景
    analysis = builder.analyze_scenario_description(example_description)
    print(f"\n分析结果: {json.dumps(analysis, ensure_ascii=False, indent=2)}")
    
    # 构建脚本
    script = builder.build_scenario_script(example_description, analysis)
    print(f"\n生成的场景脚本结构:")
    print(json.dumps(script, ensure_ascii=False, indent=2))
    
    # 保存脚本
    output_file = f"/tmp/scenario_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    builder.save_script(script, output_file)


if __name__ == "__main__":
    main()