#!/usr/bin/env python3
"""
Clawhub集成模块
与Clawhub平台（skillhub.cn）进行交互，搜索和测试skill串联
"""

import requests
import json
import time
from typing import Dict, List, Any, Optional
from urllib.parse import urljoin
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ClawhubClient:
    """Clawhub API客户端"""
    
    def __init__(self, base_url: str = "https://skillhub.cn/api/"):
        self.base_url = base_url
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "Demo-Maker-Skill/1.0",
            "Content-Type": "application/json"
        })
    
    def search_skills(self, query: str, skill_types: List[str] = None, 
                     limit: int = 10) -> List[Dict[str, Any]]:
        """搜索技能"""
        endpoint = urljoin(self.base_url, "v1/skills/search")
        
        params = {
            "q": query,
            "limit": limit
        }
        
        if skill_types:
            params["types"] = ",".join(skill_types)
        
        try:
            response = self.session.get(endpoint, params=params, timeout=30)
            response.raise_for_status()
            
            data = response.json()
            return data.get("skills", [])
            
        except requests.exceptions.RequestException as e:
            logger.error(f"搜索技能失败: {e}")
            return []
    
    def get_skill_details(self, skill_id: str) -> Optional[Dict[str, Any]]:
        """获取技能详细信息"""
        endpoint = urljoin(self.base_url, f"v1/skills/{skill_id}")
        
        try:
            response = self.session.get(endpoint, timeout=30)
            response.raise_for_status()
            return response.json()
            
        except requests.exceptions.RequestException as e:
            logger.error(f"获取技能详情失败: {e}")
            return None
    
    def find_skill_combinations(self, required_skills: List[str]) -> List[Dict[str, Any]]:
        """寻找技能组合"""
        combinations = []
        
        # 为每个所需技能搜索相关技能
        for skill_name in required_skills:
            related_skills = self.search_skills(skill_name, limit=5)
            
            if related_skills:
                combination = {
                    "main_skill": skill_name,
                    "related_skills": related_skills,
                    "integration_possibilities": self._analyze_integration(related_skills)
                }
                combinations.append(combination)
        
        return combinations
    
    def _analyze_integration(self, skills: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """分析技能集成可能性"""
        integrations = []
        
        # 基于技能类别和功能分析集成可能性
        for i, skill1 in enumerate(skills):
            for skill2 in skills[i+1:]:
                integration_score = self._calculate_integration_score(skill1, skill2)
                
                if integration_score > 0.3:  # 阈值可调整
                    integration = {
                        "skill_pair": [skill1.get("name"), skill2.get("name")],
                        "integration_score": integration_score,
                        "integration_type": self._determine_integration_type(skill1, skill2),
                        "data_flow": self._suggest_data_flow(skill1, skill2)
                    }
                    integrations.append(integration)
        
        return integrations
    
    def _calculate_integration_score(self, skill1: Dict[str, Any], skill2: Dict[str, Any]) -> float:
        """计算技能集成分数"""
        score = 0.0
        
        # 基于类别的集成可能性
        categories1 = skill1.get("categories", [])
        categories2 = skill2.get("categories", [])
        
        common_categories = set(categories1) & set(categories2)
        if common_categories:
            score += 0.2
        
        # 基于功能的互补性
        functions1 = skill1.get("functions", [])
        functions2 = skill2.get("functions", [])
        
        # 检查是否有输入输出匹配
        outputs1 = skill1.get("outputs", [])
        inputs2 = skill2.get("inputs", [])
        
        common_io = set(outputs1) & set(inputs2)
        if common_io:
            score += 0.4
        
        # 基于使用场景的关联性
        scenarios1 = skill1.get("scenarios", [])
        scenarios2 = skill2.get("scenarios", [])
        
        common_scenarios = set(scenarios1) & set(scenarios2)
        if common_scenarios:
            score += 0.3
        
        return min(score, 1.0)
    
    def _determine_integration_type(self, skill1: Dict[str, Any], skill2: Dict[str, Any]) -> str:
        """确定集成类型"""
        types = {
            "data_processing": ["data_analysis", "visualization", "reporting"],
            "workflow": ["automation", "scripting", "scheduling"],
            "testing": ["validation", "debugging", "monitoring"]
        }
        
        skill1_type = skill1.get("type", "")
        skill2_type = skill2.get("type", "")
        
        for integration_type, skill_types in types.items():
            if skill1_type in skill_types and skill2_type in skill_types:
                return integration_type
        
        return "general"
    
    def _suggest_data_flow(self, skill1: Dict[str, Any], skill2: Dict[str, Any]) -> List[str]:
        """建议数据流"""
        data_flow = []
        
        # 根据技能功能建议数据流
        if skill1.get("category") == "data_collection" and skill2.get("category") == "data_analysis":
            data_flow = ["原始数据 → 数据清洗 → 分析结果"]
        
        elif skill1.get("category") == "analysis" and skill2.get("category") == "visualization":
            data_flow = ["分析结果 → 数据转换 → 可视化图表"]
        
        elif skill1.get("category") == "processing" and skill2.get("category") == "reporting":
            data_flow = ["处理结果 → 格式化 → 报告文档"]
        
        else:
            data_flow = [f"{skill1.get('name')}输出 → {skill2.get('name')}输入"]
        
        return data_flow
    
    def test_skill_combination(self, skill_ids: List[str], test_data: Dict[str, Any]) -> Dict[str, Any]:
        """测试技能组合"""
        endpoint = urljoin(self.base_url, "v1/testing/combinations")
        
        payload = {
            "skill_ids": skill_ids,
            "test_data": test_data,
            "test_type": "integration"
        }
        
        try:
            logger.info(f"开始测试技能组合: {skill_ids}")
            response = self.session.post(endpoint, json=payload, timeout=60)
            response.raise_for_status()
            
            result = response.json()
            logger.info(f"测试完成: {result.get('status')}")
            
            return result
            
        except requests.exceptions.RequestException as e:
            logger.error(f"技能组合测试失败: {e}")
            return {
                "status": "failed",
                "error": str(e),
                "skills_tested": skill_ids
            }
    
    def generate_test_report(self, test_results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """生成测试报告"""
        total_tests = len(test_results)
        passed_tests = sum(1 for r in test_results if r.get("status") == "success")
        failed_tests = total_tests - passed_tests
        
        report = {
            "summary": {
                "total_combinations_tested": total_tests,
                "passed": passed_tests,
                "failed": failed_tests,
                "success_rate": passed_tests / total_tests if total_tests > 0 else 0
            },
            "detailed_results": test_results,
            "recommendations": self._generate_recommendations(test_results),
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
        }
        
        return report
    
    def _generate_recommendations(self, test_results: List[Dict[str, Any]]) -> List[str]:
        """生成推荐"""
        recommendations = []
        
        for result in test_results:
            if result.get("status") == "success":
                skills = result.get("skills_tested", [])
                recommendations.append(
                    f"技能组合 {skills} 集成成功，建议在相关场景中使用"
                )
            else:
                error = result.get("error", "未知错误")
                recommendations.append(
                    f"技能组合测试失败，原因: {error}。建议检查技能兼容性或使用替代组合"
                )
        
        return recommendations


class SkillIntegrationAnalyzer:
    """技能集成分析器"""
    
    def __init__(self, clawhub_client: ClawhubClient):
        self.client = clawhub_client
    
    def analyze_scenario_skills(self, scenario_script: Dict[str, Any]) -> Dict[str, Any]:
        """分析场景脚本中的技能需求"""
        required_skills = scenario_script.get("skills_required", [])
        workflow_steps = scenario_script.get("workflow", [])
        
        analysis = {
            "skill_requirements": required_skills,
            "workflow_complexity": len(workflow_steps),
            "skill_combinations": [],
            "integration_challenges": []
        }
        
        # 搜索可用技能
        skill_search_results = {}
        for skill in required_skills:
            found_skills = self.client.search_skills(skill)
            skill_search_results[skill] = found_skills
        
        # 分析技能组合
        combinations = self.client.find_skill_combinations(required_skills)
        analysis["skill_combinations"] = combinations
        
        # 识别集成挑战
        analysis["integration_challenges"] = self._identify_challenges(combinations)
        
        return analysis
    
    def _identify_challenges(self, combinations: List[Dict[str, Any]]) -> List[str]:
        """识别集成挑战"""
        challenges = []
        
        for combo in combinations:
            integrations = combo.get("integration_possibilities", [])
            
            for integration in integrations:
                score = integration.get("integration_score", 0)
                
                if score < 0.5:
                    skill_pair = integration.get("skill_pair", [])
                    challenges.append(
                        f"技能 {skill_pair} 集成分数较低 ({score:.2f})，可能需要额外适配"
                    )
        
        return challenges


def main():
    """示例用法"""
    client = ClawhubClient()
    analyzer = SkillIntegrationAnalyzer(client)
    
    # 示例：搜索技能
    print("=== 技能搜索示例 ===")
    skills = client.search_skills("data analysis", limit=3)
    print(f"找到 {len(skills)} 个技能:")
    for skill in skills:
        print(f"  - {skill.get('name')} ({skill.get('type', 'unknown')})")
    
    # 示例：分析技能组合
    print("\n=== 技能组合分析示例 ===")
    required_skills = ["data_processing", "visualization", "reporting"]
    combinations = client.find_skill_combinations(required_skills)
    
    print(f"分析 {len(required_skills)} 个所需技能的组合可能性:")
    for combo in combinations:
        print(f"\n主技能: {combo['main_skill']}")
        print(f"相关技能: {len(combo['related_skills'])} 个")
        print(f"集成可能性: {len(combo['integration_possibilities'])} 种")


if __name__ == "__main__":
    main()