#!/usr/bin/env python3
"""
Demo制作主程序
整合所有组件，提供完整的场景构建、技能集成和文档生成功能
"""

import os
import sys
import json
import argparse
from datetime import datetime
from typing import Dict, List, Any, Optional

# 导入自定义模块
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

try:
    from scenario_builder import ScenarioBuilder
    from clawhub_integration import ClawhubClient, SkillIntegrationAnalyzer
    from skill_analyzer import SkillAnalyzer
    from demo_document_generator import FeishuDocGenerator
except ImportError as e:
    print(f"导入模块失败: {e}")
    print("请确保所有依赖模块已正确安装")
    sys.exit(1)

class DemoMaker:
    """Demo制作主类"""
    
    def __init__(self, output_dir: str = "./outputs"):
        self.output_dir = output_dir
        self.scenario_builder = ScenarioBuilder()
        self.clawhub_client = ClawhubClient()
        self.skill_analyzer = SkillAnalyzer()
        self.integration_analyzer = SkillIntegrationAnalyzer(self.clawhub_client)
        self.doc_generator = FeishuDocGenerator()
        
        # 创建输出目录
        os.makedirs(output_dir, exist_ok=True)
    
    def run_scenario(self, scenario_description: str, 
                    skill_requirements: List[str] = None) -> Dict[str, Any]:
        """运行完整场景"""
        
        print("=" * 60)
        print("🎬 开始Demo制作流程")
        print("=" * 60)
        
        # 步骤1: 分析场景
        print("\n📋 步骤1: 分析场景描述...")
        scenario_analysis = self.scenario_builder.analyze_scenario_description(scenario_description)
        print(f"   场景类型: {scenario_analysis.get('scenario_type', '未识别')}")
        print(f"   关键任务: {len(scenario_analysis.get('key_tasks', []))}个")
        print(f"   所需技能: {', '.join(scenario_analysis.get('required_skills', []))}")
        
        # 步骤2: 构建场景脚本
        print("\n📝 步骤2: 构建场景脚本...")
        scenario_script = self.scenario_builder.build_scenario_script(
            scenario_description, scenario_analysis
        )
        
        # 保存场景脚本
        scenario_file = os.path.join(self.output_dir, "scenario_script.json")
        self.scenario_builder.save_script(scenario_script, scenario_file)
        print(f"   场景脚本已保存: {scenario_file}")
        
        # 步骤3: 分析技能需求
        print("\n🔧 步骤3: 分析技能需求...")
        integration_results = self.integration_analyzer.analyze_scenario_skills(scenario_script)
        
        # 保存技能分析结果
        skill_analysis_file = os.path.join(self.output_dir, "skill_analysis.json")
        with open(skill_analysis_file, 'w', encoding='utf-8') as f:
            json.dump(integration_results, f, ensure_ascii=False, indent=2)
        print(f"   技能分析已保存: {skill_analysis_file}")
        
        # 步骤4: 测试技能组合（可选）
        test_reports = []
        if self._should_run_tests(integration_results):
            print("\n🧪 步骤4: 测试技能组合...")
            test_reports = self._run_skill_tests(integration_results)
        else:
            print("\n⏭️  步骤4: 跳过技能测试（配置或数据不足）")
        
        # 步骤5: 生成Demo文档
        print("\n📄 步骤5: 生成Demo文档...")
        demo_document = self.doc_generator.generate_demo_document(
            scenario_script, integration_results, test_reports
        )
        
        # 保存文档
        doc_file = self.doc_generator.save_document(demo_document, self.output_dir)
        print(f"   Demo文档已保存: {doc_file}")
        
        # 步骤6: 生成总结报告
        print("\n📊 步骤6: 生成总结报告...")
        summary = self._generate_summary_report(
            scenario_script, integration_results, test_reports, demo_document
        )
        
        # 保存总结报告
        summary_file = os.path.join(self.output_dir, "summary_report.json")
        with open(summary_file, 'w', encoding='utf-8') as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)
        print(f"   总结报告已保存: {summary_file}")
        
        print("\n" + "=" * 60)
        print("🎉 Demo制作完成！")
        print("=" * 60)
        
        return {
            "scenario_script": scenario_file,
            "skill_analysis": skill_analysis_file,
            "demo_document": doc_file,
            "summary_report": summary_file,
            "test_reports": test_reports,
            "output_dir": self.output_dir
        }
    
    def _should_run_tests(self, integration_results: Dict[str, Any]) -> bool:
        """判断是否应该运行测试"""
        # 检查是否有足够的技能组合
        combinations = integration_results.get("skill_combinations", [])
        if not combinations:
            return False
        
        # 检查是否有集成挑战（可能需要测试）
        challenges = integration_results.get("integration_challenges", [])
        if challenges:
            return True
        
        # 默认情况下运行测试
        return True
    
    def _run_skill_tests(self, integration_results: Dict[str, Any]) -> List[Dict[str, Any]]:
        """运行技能测试"""
        test_reports = []
        combinations = integration_results.get("skill_combinations", [])
        
        for i, combo in enumerate(combinations[:3], 1):  # 限制测试数量
            print(f"   测试组合 {i}/{min(len(combinations), 3)}...")
            
            # 提取相关技能ID进行测试
            related_skills = combo.get("related_skills", [])
            if not related_skills:
                continue
            
            # 使用前两个技能进行测试
            skill_ids = [skill.get("id", "") for skill in related_skills[:2] if skill.get("id")]
            if not skill_ids:
                continue
            
            # 准备测试数据
            test_data = {
                "test_type": "integration",
                "scenario": combo.get("main_skill", "unknown"),
                "data": {"sample": "test_data"}
            }
            
            # 运行测试
            test_result = self.clawhub_client.test_skill_combination(skill_ids, test_data)
            
            # 生成测试报告
            test_report = self.clawhub_client.generate_test_report([test_result])
            test_reports.append(test_report)
            
            # 保存测试报告
            test_file = os.path.join(self.output_dir, f"test_report_{i}.json")
            with open(test_file, 'w', encoding='utf-8') as f:
                json.dump(test_report, f, ensure_ascii=False, indent=2)
        
        return test_reports
    
    def _generate_summary_report(self, scenario_script: Dict[str, Any],
                               integration_results: Dict[str, Any],
                               test_reports: List[Dict[str, Any]],
                               demo_document: Dict[str, Any]) -> Dict[str, Any]:
        """生成总结报告"""
        
        # 计算关键指标
        scenario = scenario_script.get("scenario", {})
        workflow_steps = len(scenario_script.get("workflow", []))
        
        # 测试统计
        test_stats = {
            "total_tests": len(test_reports),
            "passed_tests": 0,
            "failed_tests": 0
        }
        
        for report in test_reports:
            summary = report.get("summary", {})
            test_stats["passed_tests"] += summary.get("passed", 0)
            test_stats["failed_tests"] += summary.get("failed", 0)
        
        success_rate = (test_stats["passed_tests"] / 
                       (test_stats["passed_tests"] + test_stats["failed_tests"])
                       if test_stats["passed_tests"] + test_stats["failed_tests"] > 0 else 0)
        
        # 技能组合统计
        skill_combinations = integration_results.get("skill_combinations", [])
        integration_challenges = integration_results.get("integration_challenges", [])
        
        summary = {
            "project_info": {
                "name": scenario.get("name", "未命名场景"),
                "type": scenario.get("type", "custom"),
                "complexity": scenario.get("complexity", "medium"),
                "created_at": datetime.now().isoformat()
            },
            "key_metrics": {
                "workflow_steps": workflow_steps,
                "required_skills": len(scenario_script.get("skills_required", [])),
                "skill_combinations_found": len(skill_combinations),
                "integration_challenges": len(integration_challenges),
                "test_success_rate": f"{success_rate:.1%}",
                "doc_sections": len(demo_document.get("content", {}))
            },
            "deliverables": {
                "scenario_script": "✓ 已生成",
                "skill_analysis": "✓ 已生成",
                "demo_document": "✓ 已生成",
                "test_reports": f"✓ {len(test_reports)}个报告已生成",
                "summary_report": "✓ 当前报告"
            },
            "recommendations": self._generate_final_recommendations(
                scenario_script, integration_results, test_reports
            ),
            "next_steps": [
                "1. 在Clawhub平台上验证技能组合",
                "2. 在实际环境中测试完整工作流",
                "3. 根据测试结果优化技能配置",
                "4. 将Demo文档导入飞书云文档",
                "5. 分享给团队成员进行评审"
            ]
        }
        
        return summary
    
    def _generate_final_recommendations(self, scenario_script: Dict[str, Any],
                                      integration_results: Dict[str, Any],
                                      test_reports: List[Dict[str, Any]]) -> List[str]:
        """生成最终推荐"""
        recommendations = []
        
        # 基于场景复杂度的推荐
        scenario = scenario_script.get("scenario", {})
        complexity = scenario.get("complexity", "medium")
        
        if complexity == "high":
            recommendations.append("🔴 高复杂度场景：建议分阶段实施，先验证核心功能")
        elif complexity == "medium":
            recommendations.append("🟡 中等复杂度：建议完整测试所有功能模块")
        else:
            recommendations.append("🟢 低复杂度：可以快速实施和验证")
        
        # 基于技能组合的推荐
        combinations = integration_results.get("skill_combinations", [])
        if combinations:
            best_combo = max(combinations, key=lambda x: len(x.get("integration_possibilities", [])))
            main_skill = best_combo.get("main_skill", "")
            
            if main_skill:
                recommendations.append(f"💡 核心技能 '{main_skill}' 有多个集成方案，建议优先测试")
        
        # 基于测试结果的推荐
        if test_reports:
            test_summary = test_reports[0].get("summary", {})
            success_rate = test_summary.get("success_rate", 0)
            
            if success_rate >= 0.8:
                recommendations.append("✅ 测试通过率高：技能组合稳定，可以投入生产使用")
            elif success_rate >= 0.6:
                recommendations.append("⚠️ 测试通过率中等：建议进行额外适配和测试")
            else:
                recommendations.append("❌ 测试通过率低：需要重新设计技能组合或寻找替代方案")
        
        # 基于集成挑战的推荐
        challenges = integration_results.get("integration_challenges", [])
        if challenges:
            recommendations.append(f"🔧 发现{len(challenges)}个集成挑战，需要额外关注和解决")
        
        return recommendations
    
    def create_quick_demo(self, scenario_description: str) -> str:
        """创建快速Demo（简化版）"""
        print("\n🚀 创建快速Demo...")
        
        # 分析场景
        scenario_analysis = self.scenario_builder.analyze_scenario_description(scenario_description)
        
        # 构建基础脚本
        scenario_script = self.scenario_builder.build_scenario_script(
            scenario_description, scenario_analysis
        )
        
        # 生成简化文档
        demo_document = self.doc_generator.generate_demo_document(
            scenario_script, {}, []
        )
        
        # 保存文档
        quick_output_dir = os.path.join(self.output_dir, "quick_demo")
        os.makedirs(quick_output_dir, exist_ok=True)
        
        doc_file = self.doc_generator.save_document(demo_document, quick_output_dir)
        
        print(f"✅ 快速Demo已创建: {doc_file}")
        return doc_file


def parse_arguments():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(description="Demo制作工具")
    
    parser.add_argument(
        "scenario",
        nargs="?",
        help="场景描述文本"
    )
    
    parser.add_argument(
        "--output-dir",
        "-o",
        default="./demo_outputs",
        help="输出目录 (默认: ./demo_outputs)"
    )
    
    parser.add_argument(
        "--quick",
        "-q",
        action="store_true",
        help="快速模式，跳过技能测试"
    )
    
    parser.add_argument(
        "--list-templates",
        "-l",
        action="store_true",
        help="列出可用的场景模板"
    )
    
    parser.add_argument(
        "--version",
        "-v",
        action="version",
        version="Demo Maker v1.0.0"
    )
    
    return parser.parse_args()


def main():
    """主函数"""
    args = parse_arguments()
    
    # 初始化Demo制作器
    maker = DemoMaker(output_dir=args.output_dir)
    
    if args.list_templates:
        print("可用的场景模板:")
        templates = maker.scenario_builder._load_templates()
        for name, template in templates.items():
            print(f"  - {name}: {template['description']}")
        return
    
    if not args.scenario:
        print("请提供场景描述")
        print("示例: python demo_maker.py '构建一个数据分析工作流'")
        return
    
    # 运行Demo制作
    try:
        if args.quick:
            result = maker.create_quick_demo(args.scenario)
        else:
            result = maker.run_scenario(args.scenario)
        
        print("\n📁 输出文件:")
        for key, value in result.items():
            if isinstance(value, str) and os.path.exists(value):
                print(f"  - {key}: {value}")
        
        print(f"\n📂 完整输出目录: {args.output_dir}")
        
    except Exception as e:
        print(f"❌ Demo制作失败: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()