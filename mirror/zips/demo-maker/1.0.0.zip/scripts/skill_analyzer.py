#!/usr/bin/env python3
"""
技能分析器
分析技能的特性和兼容性，为场景构建提供决策支持
"""

import json
import re
from typing import Dict, List, Any, Optional, Set
from collections import defaultdict
import hashlib

class SkillAnalyzer:
    """技能分析器类"""
    
    def __init__(self):
        self.skill_patterns = self._load_patterns()
        self.compatibility_matrix = self._load_compatibility_matrix()
        
    def _load_patterns(self) -> Dict[str, List[str]]:
        """加载技能模式"""
        return {
            "data_input": ["input", "read", "load", "import", "fetch"],
            "data_output": ["output", "write", "save", "export", "generate"],
            "processing": ["process", "transform", "convert", "calculate", "analyze"],
            "visualization": ["visualize", "plot", "chart", "graph", "display"],
            "reporting": ["report", "summarize", "document", "export_doc"],
            "automation": ["automate", "schedule", "trigger", "run"],
            "testing": ["test", "validate", "verify", "check"]
        }
    
    def _load_compatibility_matrix(self) -> Dict[str, Dict[str, float]]:
        """加载兼容性矩阵"""
        return {
            "data_input": {
                "processing": 0.9,
                "visualization": 0.7,
                "reporting": 0.6,
                "automation": 0.5
            },
            "data_output": {
                "data_input": 0.9,
                "reporting": 0.8,
                "automation": 0.7
            },
            "processing": {
                "visualization": 0.9,
                "reporting": 0.8,
                "data_output": 0.7,
                "testing": 0.6
            },
            "visualization": {
                "reporting": 0.9,
                "data_output": 0.8
            },
            "reporting": {
                "data_output": 0.9
            },
            "automation": {
                "data_input": 0.7,
                "processing": 0.6,
                "testing": 0.8
            },
            "testing": {
                "data_input": 0.8,
                "data_output": 0.9,
                "reporting": 0.7
            }
        }
    
    def analyze_skill_description(self, description: str, skill_name: str = "") -> Dict[str, Any]:
        """分析技能描述"""
        analysis = {
            "skill_id": self._generate_skill_id(description, skill_name),
            "name": skill_name,
            "description": description,
            "categories": [],
            "functions": [],
            "inputs": [],
            "outputs": [],
            "complexity_score": 0.0,
            "special_features": [],
            "compatibility_notes": []
        }
        
        # 分析类别
        analysis["categories"] = self._detect_categories(description)
        
        # 分析功能
        analysis["functions"] = self._detect_functions(description)
        
        # 分析输入输出
        analysis["inputs"], analysis["outputs"] = self._detect_inputs_outputs(description)
        
        # 计算复杂度
        analysis["complexity_score"] = self._calculate_complexity(description, analysis)
        
        # 识别特殊特性
        analysis["special_features"] = self._detect_special_features(description)
        
        # 生成兼容性备注
        analysis["compatibility_notes"] = self._generate_compatibility_notes(analysis)
        
        return analysis
    
    def _generate_skill_id(self, description: str, skill_name: str) -> str:
        """生成技能ID"""
        content = f"{skill_name}:{description}"
        return hashlib.md5(content.encode()).hexdigest()[:12]
    
    def _detect_categories(self, description: str) -> List[str]:
        """检测技能类别"""
        categories = []
        description_lower = description.lower()
        
        category_mapping = {
            "data": ["data", "dataset", "database"],
            "analysis": ["analyze", "analysis", "statistics"],
            "visualization": ["visualize", "plot", "chart", "graph"],
            "automation": ["automate", "schedule", "workflow"],
            "testing": ["test", "validate", "verify"],
            "reporting": ["report", "document", "summarize"],
            "integration": ["integrate", "connect", "api"],
            "processing": ["process", "transform", "convert"]
        }
        
        for category, keywords in category_mapping.items():
            if any(keyword in description_lower for keyword in keywords):
                categories.append(category)
        
        return list(set(categories))
    
    def _detect_functions(self, description: str) -> List[str]:
        """检测功能"""
        functions = []
        description_lower = description.lower()
        
        for func_type, keywords in self.skill_patterns.items():
            if any(keyword in description_lower for keyword in keywords):
                functions.append(func_type)
        
        return functions
    
    def _detect_inputs_outputs(self, description: str) -> tuple[List[str], List[str]]:
        """检测输入输出"""
        inputs = []
        outputs = []
        
        # 使用正则表达式提取输入输出信息
        input_patterns = [
            r"(?:接收|输入|获取|读取|导入)(.+?)(?:作为|的|数据)",
            r"(?:从|来自)(.+?)(?:获取|读取|加载)",
            r"(?:input|read|load|import)\s+(.+?)(?:file|data|from)"
        ]
        
        output_patterns = [
            r"(?:生成|输出|创建|导出)(.+?)(?:文件|数据|报告)",
            r"(?:保存|存储|写入)(.+?)(?:到|为|成)",
            r"(?:output|generate|export|save)\s+(.+?)(?:to|as|format)"
        ]
        
        description_lower = description.lower()
        
        for pattern in input_patterns:
            matches = re.findall(pattern, description_lower)
            inputs.extend([match.strip() for match in matches])
        
        for pattern in output_patterns:
            matches = re.findall(pattern, description_lower)
            outputs.extend([match.strip() for match in matches])
        
        # 去重
        inputs = list(set(inputs))
        outputs = list(set(outputs))
        
        return inputs, outputs
    
    def _calculate_complexity(self, description: str, analysis: Dict[str, Any]) -> float:
        """计算复杂度分数"""
        complexity = 0.0
        
        # 基于描述长度
        word_count = len(description.split())
        if word_count < 50:
            complexity += 0.2
        elif word_count < 100:
            complexity += 0.4
        else:
            complexity += 0.6
        
        # 基于类别数量
        category_count = len(analysis.get("categories", []))
        complexity += min(category_count * 0.1, 0.3)
        
        # 基于功能数量
        function_count = len(analysis.get("functions", []))
        complexity += min(function_count * 0.08, 0.2)
        
        return min(complexity, 1.0)
    
    def _detect_special_features(self, description: str) -> List[str]:
        """检测特殊特性"""
        features = []
        description_lower = description.lower()
        
        feature_patterns = {
            "real_time": ["real-time", "实时", "streaming", "实时处理"],
            "batch": ["batch", "批量", "批处理"],
            "parallel": ["parallel", "并行", "concurrent", "并发"],
            "distributed": ["distributed", "分布式"],
            "cloud": ["cloud", "云", "aws", "azure", "gcp"],
            "api_integration": ["api", "rest", "graphql", "接口"],
            "security": ["security", "secure", "加密", "安全"],
            "ml_ai": ["machine learning", "ai", "人工智能", "ml", "神经网络"]
        }
        
        for feature_name, keywords in feature_patterns.items():
            if any(keyword in description_lower for keyword in keywords):
                features.append(feature_name)
        
        return features
    
    def _generate_compatibility_notes(self, analysis: Dict[str, Any]) -> List[str]:
        """生成兼容性备注"""
        notes = []
        functions = analysis.get("functions", [])
        
        # 检查输入输出匹配
        inputs = analysis.get("inputs", [])
        outputs = analysis.get("outputs", [])
        
        if inputs and outputs:
            notes.append(f"具有明确的输入({', '.join(inputs[:3])})和输出({', '.join(outputs[:3])})")
        
        # 根据功能生成兼容性提示
        for func in functions:
            if func in self.compatibility_matrix:
                compatible_funcs = self.compatibility_matrix[func]
                best_matches = sorted(compatible_funcs.items(), key=lambda x: x[1], reverse=True)[:2]
                
                for match_func, score in best_matches:
                    if score > 0.7:
                        notes.append(f"与{match_func}功能技能高度兼容(分数{score:.1f})")
        
        # 基于特殊特性的兼容性提示
        features = analysis.get("special_features", [])
        if "real_time" in features:
            notes.append("支持实时处理，适合流式数据场景")
        if "batch" in features:
            notes.append("支持批处理，适合大规模数据处理")
        if "api_integration" in features:
            notes.append("支持API集成，适合系统集成场景")
        
        return notes
    
    def analyze_skill_compatibility(self, skill1: Dict[str, Any], skill2: Dict[str, Any]) -> Dict[str, Any]:
        """分析两个技能的兼容性"""
        
        compatibility = {
            "skill_pair": [skill1.get("name", "skill1"), skill2.get("name", "skill2")],
            "categories_match": self._check_categories_match(skill1, skill2),
            "functions_compatibility": self._check_functions_compatibility(skill1, skill2),
            "io_match": self._check_io_match(skill1, skill2),
            "overall_score": 0.0,
            "recommendations": []
        }
        
        # 计算整体兼容性分数
        scores = []
        
        # 类别匹配分数 (30%)
        category_score = compatibility["categories_match"].get("score", 0.0)
        scores.append(category_score * 0.3)
        
        # 功能兼容性分数 (40%)
        func_score = compatibility["functions_compatibility"].get("score", 0.0)
        scores.append(func_score * 0.4)
        
        # 输入输出匹配分数 (30%)
        io_score = compatibility["io_match"].get("score", 0.0)
        scores.append(io_score * 0.3)
        
        compatibility["overall_score"] = sum(scores)
        
        # 生成推荐
        compatibility["recommendations"] = self._generate_integration_recommendations(
            skill1, skill2, compatibility
        )
        
        return compatibility
    
    def _check_categories_match(self, skill1: Dict[str, Any], skill2: Dict[str, Any]) -> Dict[str, Any]:
        """检查类别匹配"""
        categories1 = set(skill1.get("categories", []))
        categories2 = set(skill2.get("categories", []))
        
        common = categories1 & categories2
        total = categories1 | categories2
        
        score = len(common) / len(total) if total else 0.0
        
        return {
            "common_categories": list(common),
            "all_categories": list(total),
            "score": score
        }
    
    def _check_functions_compatibility(self, skill1: Dict[str, Any], skill2: Dict[str, Any]) -> Dict[str, Any]:
        """检查功能兼容性"""
        functions1 = set(skill1.get("functions", []))
        functions2 = set(skill2.get("functions", []))
        
        # 检查互补性（如一个输出，一个输入）
        complementary_pairs = []
        score = 0.0
        
        for func1 in functions1:
            if func1 in self.compatibility_matrix:
                for func2 in functions2:
                    if func2 in self.compatibility_matrix[func1]:
                        pair_score = self.compatibility_matrix[func1][func2]
                        complementary_pairs.append((func1, func2, pair_score))
                        score = max(score, pair_score)
        
        # 检查冲突（如两个都是输出）
        potential_conflicts = []
        output_funcs = {"data_output", "reporting"}
        
        common_outputs = functions1 & functions2 & output_funcs
        if common_outputs:
            potential_conflicts.append({
                "conflict_type": "output_overlap",
                "functions": list(common_outputs)
            })
        
        return {
            "complementary_pairs": complementary_pairs,
            "potential_conflicts": potential_conflicts,
            "score": score
        }
    
    def _check_io_match(self, skill1: Dict[str, Any], skill2: Dict[str, Any]) -> Dict[str, Any]:
        """检查输入输出匹配"""
        outputs1 = skill1.get("outputs", [])
        inputs2 = skill2.get("inputs", [])
        
        matches = []
        
        # 简单的字符串匹配（可扩展为语义匹配）
        for output in outputs1[:5]:  # 限制检查数量
            for input_val in inputs2[:5]:
                # 检查是否有共同关键词
                output_words = set(output.lower().split())
                input_words = set(input_val.lower().split())
                
                common = output_words & input_words
                if common:
                    matches.append({
                        "output": output,
                        "input": input_val,
                        "common_keywords": list(common)
                    })
        
        score = min(len(matches) / 5, 1.0) if matches else 0.0
        
        return {
            "matches": matches,
            "score": score
        }
    
    def _generate_integration_recommendations(self, skill1: Dict[str, Any], 
                                            skill2: Dict[str, Any],
                                            compatibility: Dict[str, Any]) -> List[str]:
        """生成集成推荐"""
        recommendations = []
        score = compatibility.get("overall_score", 0.0)
        
        if score > 0.8:
            recommendations.append("🎯 高度推荐集成：这两个技能在设计上和功能上高度匹配")
            recommendations.append("📋 建议直接串联使用，无需额外适配")
            
        elif score > 0.6:
            recommendations.append("✅ 推荐集成：技能间有良好的互补性")
            recommendations.append("⚙️ 可能需要少量数据格式转换适配")
            
        elif score > 0.4:
            recommendations.append("⚠️ 有条件集成：需要评估具体使用场景")
            recommendations.append("🔧 建议进行详细的功能测试和适配工作")
            
        else:
            recommendations.append("⛔ 不推荐直接集成：技能间兼容性较低")
            recommendations.append("💡 建议寻找替代技能或重新设计工作流")
        
        # 添加具体建议
        func_compat = compatibility.get("functions_compatibility", {})
        complementary_pairs = func_compat.get("complementary_pairs", [])
        
        if complementary_pairs:
            best_pair = max(complementary_pairs, key=lambda x: x[2])
            recommendations.append(
                f"💡 最佳功能配对：{best_pair[0]} → {best_pair[1]} (兼容分数: {best_pair[2]:.1f})"
            )
        
        # 输入输出匹配建议
        io_match = compatibility.get("io_match", {})
        matches = io_match.get("matches", [])
        
        if matches:
            recommendations.append("🔌 输入输出匹配点：")
            for match in matches[:2]:
                recommendations.append(
                    f"  - {match['output']} → {match['input']} (关键词: {', '.join(match['common_keywords'])})"
                )
        
        return recommendations
    
    def find_best_skill_combinations(self, required_skills: List[str], 
                                   available_skills: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """寻找最佳技能组合"""
        combinations = []
        
        for req_skill in required_skills:
            # 寻找匹配的技能
            matching_skills = self._find_matching_skills(req_skill, available_skills)
            
            if matching_skills:
                # 分析最佳组合
                best_combo = self._analyze_best_combination(req_skill, matching_skills)
                combinations.append(best_combo)
        
        return combinations
    
    def _find_matching_skills(self, skill_name: str, 
                            available_skills: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """寻找匹配的技能"""
        matching = []
        
        for skill in available_skills:
            # 检查名称匹配
            if skill_name.lower() in skill.get("name", "").lower():
                matching.append(skill)
            
            # 检查类别匹配
            elif any(skill_name.lower() in category.lower() 
                    for category in skill.get("categories", [])):
                matching.append(skill)
        
        return matching[:5]  # 限制返回数量
    
    def _analyze_best_combination(self, target_skill: str, 
                                matching_skills: List[Dict[str, Any]]) -> Dict[str, Any]:
        """分析最佳组合"""
        if not matching_skills:
            return {
                "target_skill": target_skill,
                "best_match": None,
                "alternatives": [],
                "recommendation": "未找到匹配技能"
            }
        
        # 选择最佳匹配（基于名称匹配度）
        best_match = matching_skills[0]
        best_score = self._calculate_match_score(target_skill, best_match)
        
        for skill in matching_skills[1:]:
            score = self._calculate_match_score(target_skill, skill)
            if score > best_score:
                best_match = skill
                best_score = score
        
        return {
            "target_skill": target_skill,
            "best_match": best_match,
            "alternatives": matching_skills[1:4],
            "match_score": best_score,
            "recommendation": f"推荐使用技能: {best_match.get('name', '未命名')}"
        }
    
    def _calculate_match_score(self, target: str, skill: Dict[str, Any]) -> float:
        """计算匹配分数"""
        score = 0.0
        
        # 名称匹配
        skill_name = skill.get("name", "").lower()
        if target.lower() in skill_name:
            score += 0.5
        
        # 类别匹配
        categories = skill.get("categories", [])
        if any(target.lower() in cat.lower() for cat in categories):
            score += 0.3
        
        # 功能匹配
        functions = skill.get("functions", [])
        if any(target.lower() in func.lower() for func in functions):
            score += 0.2
        
        return min(score, 1.0)


def main():
    """示例用法"""
    analyzer = SkillAnalyzer()
    
    # 示例技能描述
    skill_descriptions = [
        "一个数据分析工具，可以处理CSV和JSON格式的数据，执行统计分析并生成报告",
        "数据可视化组件，支持创建柱状图、折线图和饼图，可以导出为PNG或PDF",
        "自动化工作流引擎，可以调度和执行任务，支持API集成和错误处理"
    ]
    
    print("=== 技能分析示例 ===")
    
    # 分析每个技能
    analyzed_skills = []
    for i, desc in enumerate(skill_descriptions, 1):
        print(f"\n分析技能 {i}:")
        print(f"描述: {desc}")
        
        analysis = analyzer.analyze_skill_description(desc, f"skill_{i}")
        
        print(f"类别: {analysis['categories']}")
        print(f"功能: {analysis['functions']}")
        print(f"输入: {analysis['inputs']}")
        print(f"输出: {analysis['outputs']}")
        print(f"复杂度分数: {analysis['complexity_score']:.2f}")
        
        analyzed_skills.append(analysis)
    
    # 分析技能兼容性
    if len(analyzed_skills) >= 2:
        print("\n=== 技能兼容性分析 ===")
        
        for i in range(len(analyzed_skills) - 1):
            skill1 = analyzed_skills[i]
            skill2 = analyzed_skills[i + 1]
            
            compatibility = analyzer.analyze_skill_compatibility(skill1, skill2)
            
            print(f"\n{skill1['name']} 与 {skill2['name']} 的兼容性:")
            print(f"整体兼容分数: {compatibility['overall_score']:.2f}")
            print(f"共同类别: {compatibility['categories_match']['common_categories']}")
            
            if compatibility['recommendations']:
                print("推荐:")
                for rec in compatibility['recommendations'][:2]:
                    print(f"  - {rec}")


if __name__ == "__main__":
    main()