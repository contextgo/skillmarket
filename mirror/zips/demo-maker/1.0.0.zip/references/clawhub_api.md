# Clawhub API 文档

## 概述

Clawhub (skillhub.cn) 是一个技能发现和测试平台，提供API接口用于搜索、测试和集成各种AI技能。

## API基础信息

### 基本URL
```
https://skillhub.cn/api/
```

### 认证方式
目前支持以下认证方式：
1. **API Key认证**：在请求头中添加 `X-API-Key: your_api_key`
2. **OAuth 2.0**：通过OAuth获取访问令牌

### 通用响应格式
```json
{
  "success": true,
  "data": {...},
  "message": "操作成功",
  "timestamp": "2026-01-01T12:00:00Z"
}
```

## 核心API端点

### 1. 技能搜索

**端点**: `GET /v1/skills/search`

**参数**:
- `q` (string): 搜索关键词
- `types` (string, optional): 技能类型筛选，多个用逗号分隔
- `category` (string, optional): 技能类别
- `limit` (int, optional): 返回数量限制，默认10
- `offset` (int, optional): 分页偏移量

**响应示例**:
```json
{
  "skills": [
    {
      "id": "skill_123456",
      "name": "数据分析工具",
      "description": "专业的数据分析和处理工具",
      "type": "data_processing",
      "categories": ["data", "analysis"],
      "functions": ["data_input", "processing", "data_output"],
      "inputs": ["csv", "json", "excel"],
      "outputs": ["report", "visualization", "statistics"],
      "compatibility_score": 0.85,
      "popularity": 1500
    }
  ],
  "total": 1,
  "has_more": false
}
```

### 2. 技能详情

**端点**: `GET /v1/skills/{skill_id}`

**响应示例**:
```json
{
  "skill": {
    "id": "skill_123456",
    "name": "数据分析工具",
    "description": "专业的数据分析和处理工具",
    "version": "1.2.0",
    "author": "技能开发者",
    "created_at": "2025-12-01T10:00:00Z",
    "updated_at": "2026-01-15T14:30:00Z",
    "metadata": {
      "type": "data_processing",
      "categories": ["data", "analysis"],
      "functions": ["data_input", "processing", "data_output"],
      "inputs": [
        {
          "name": "csv_data",
          "type": "file",
          "format": "csv",
          "description": "CSV格式的数据文件"
        }
      ],
      "outputs": [
        {
          "name": "analysis_report",
          "type": "document",
          "format": "json",
          "description": "分析结果报告"
        }
      ],
      "requirements": {
        "environment": "python3.8+",
        "dependencies": ["pandas>=1.5", "numpy>=1.21"],
        "memory": "2GB",
        "storage": "1GB"
      },
      "compatibility": {
        "tested_with": ["skill_789012", "skill_345678"],
        "integration_score": 0.92
      }
    },
    "stats": {
      "usage_count": 1250,
      "avg_rating": 4.7,
      "success_rate": 0.95
    }
  }
}
```

### 3. 技能组合测试

**端点**: `POST /v1/testing/combinations`

**请求体**:
```json
{
  "skill_ids": ["skill_123456", "skill_789012"],
  "test_data": {
    "input": {...},
    "config": {...}
  },
  "test_type": "integration",
  "timeout": 60
}
```

**响应示例**:
```json
{
  "test_id": "test_987654",
  "status": "completed",
  "result": {
    "success": true,
    "execution_time": 12.5,
    "output": {...},
    "logs": [
      "技能A初始化完成",
      "数据传递成功",
      "技能B执行完成",
      "输出验证通过"
    ],
    "errors": [],
    "warnings": []
  },
  "skills_tested": ["skill_123456", "skill_789012"],
  "started_at": "2026-01-01T12:00:00Z",
  "completed_at": "2026-01-01T12:00:12Z"
}
```

### 4. 测试报告获取

**端点**: `GET /v1/testing/reports/{test_id}`

**响应示例**:
```json
{
  "report": {
    "test_id": "test_987654",
    "summary": {
      "total_steps": 4,
      "passed_steps": 4,
      "failed_steps": 0,
      "success_rate": 1.0,
      "total_time": 12.5
    },
    "detailed_results": [
      {
        "step": 1,
        "action": "技能初始化",
        "status": "success",
        "duration": 2.1,
        "details": "技能A初始化成功"
      }
    ],
    "recommendations": [
      "技能组合稳定性良好，可以投入生产使用",
      "建议增加错误处理机制"
    ]
  }
}
```

## 使用示例

### Python客户端示例

```python
import requests
import json

class ClawhubClient:
    def __init__(self, api_key=None, base_url="https://skillhub.cn/api/"):
        self.base_url = base_url
        self.session = requests.Session()
        if api_key:
            self.session.headers.update({"X-API-Key": api_key})
    
    def search_skills(self, query, limit=10):
        endpoint = f"{self.base_url}v1/skills/search"
        params = {"q": query, "limit": limit}
        response = self.session.get(endpoint, params=params)
        response.raise_for_status()
        return response.json()
    
    def test_skill_combination(self, skill_ids, test_data):
        endpoint = f"{self.base_url}v1/testing/combinations"
        payload = {
            "skill_ids": skill_ids,
            "test_data": test_data,
            "test_type": "integration"
        }
        response = self.session.post(endpoint, json=payload)
        response.raise_for_status()
        return response.json()
```

### 命令行使用示例

```bash
# 搜索技能
curl -X GET "https://skillhub.cn/api/v1/skills/search?q=data+analysis&limit=5" \
  -H "X-API-Key: your_api_key"

# 测试技能组合
curl -X POST "https://skillhub.cn/api/v1/testing/combinations" \
  -H "Content-Type: application/json" \
  -H "X-API-Key: your_api_key" \
  -d '{
    "skill_ids": ["skill_123456", "skill_789012"],
    "test_data": {"input": "test_data"},
    "test_type": "integration"
  }'
```

## 错误处理

### 常见错误码

| 状态码 | 错误码 | 描述 |
|--------|--------|------|
| 400 | INVALID_PARAMETER | 参数无效 |
| 401 | UNAUTHORIZED | 认证失败 |
| 403 | FORBIDDEN | 权限不足 |
| 404 | NOT_FOUND | 资源不存在 |
| 429 | RATE_LIMITED | 请求频率超限 |
| 500 | INTERNAL_ERROR | 服务器内部错误 |

### 错误响应示例
```json
{
  "success": false,
  "error": {
    "code": "UNAUTHORIZED",
    "message": "无效的API密钥",
    "details": "请检查API密钥是否正确"
  },
  "timestamp": "2026-01-01T12:00:00Z"
}
```

## 最佳实践

### 1. 技能搜索优化
- 使用具体的关键词而非宽泛术语
- 结合类别筛选提高搜索精度
- 限制返回数量避免数据过载

### 2. 技能组合测试
- 先测试小规模数据验证基本功能
- 逐步增加数据量和复杂度
- 记录测试日志便于问题排查

### 3. 错误处理
- 实现重试机制处理临时错误
- 添加超时设置避免长时间等待
- 记录详细的错误信息便于调试

### 4. 性能优化
- 缓存频繁访问的技能信息
- 批量处理相关操作
- 异步处理长时间运行的任务

## 限制和配额

### API限制
- 搜索请求：每分钟100次
- 测试请求：每分钟20次
- 数据大小：单个请求不超过10MB
- 响应时间：最长60秒

### 技能限制
- 单个技能最大文件大小：50MB
- 最大依赖数量：20个
- 最长执行时间：300秒

## 更新日志

### v1.0.0 (2026-01-01)
- 初始版本发布
- 支持技能搜索和详情查询
- 支持技能组合测试
- 提供基础的错误处理

### v1.1.0 (计划中)
- 增加批量操作支持
- 优化搜索算法
- 增强测试报告功能
- 添加Webhook支持

## 支持与反馈

如有问题或建议，请通过以下方式联系：

- 邮箱：support@skillhub.cn
- 文档：https://docs.skillhub.cn
- GitHub Issues：https://github.com/skillhub/issues

## 相关资源

- [官方文档](https://docs.skillhub.cn)
- [SDK仓库](https://github.com/skillhub/sdk)
- [示例项目](https://github.com/skillhub/examples)
- [社区论坛](https://community.skillhub.cn)