# 技能模板库

## 概述

本文档提供了各种技能类型的标准模板和实现示例，帮助快速创建和集成新的技能。每个模板包含技能定义、接口规范、实现示例和使用说明。

## 技能类型分类

### 1. 数据输入类技能

#### 模板1.1: 文件读取技能
**技能功能**: 读取特定格式的文件数据
**适用场景**: CSV、Excel、JSON、XML等文件格式读取

**技能定义**:
```json
{
  "skill_type": "data_input",
  "name": "csv_reader",
  "description": "读取CSV格式文件并转换为结构化数据",
  "version": "1.0.0",
  "inputs": [
    {
      "name": "file_path",
      "type": "string",
      "description": "CSV文件路径",
      "required": true
    },
    {
      "name": "encoding",
      "type": "string",
      "description": "文件编码格式",
      "default": "utf-8"
    }
  ],
  "outputs": [
    {
      "name": "data",
      "type": "list",
      "description": "读取的数据行列表"
    },
    {
      "name": "columns",
      "type": "list",
      "description": "数据列名列表"
    }
  ],
  "requirements": {
    "dependencies": ["pandas>=1.5.0"],
    "environment": "python3.8+"
  }
}
```

**实现示例**:
```python
import pandas as pd

class CSVReaderSkill:
    def execute(self, file_path: str, encoding: str = "utf-8"):
        """
        读取CSV文件
        Args:
            file_path: CSV文件路径
            encoding: 文件编码
        Returns:
            dict: 包含数据和列名的字典
        """
        try:
            df = pd.read_csv(file_path, encoding=encoding)
            return {
                "data": df.to_dict(orient="records"),
                "columns": df.columns.tolist(),
                "row_count": len(df),
                "status": "success"
            }
        except Exception as e:
            return {
                "status": "error",
                "error": str(e)
            }
```

**使用说明**:
```python
# 调用示例
reader = CSVReaderSkill()
result = reader.execute("data.csv", encoding="utf-8-sig")

if result["status"] == "success":
    data = result["data"]
    columns = result["columns"]
    print(f"读取成功：{len(data)}行数据")
```

### 2. 数据处理类技能

#### 模板2.1: 数据清洗技能
**技能功能**: 清洗和预处理数据
**适用场景**: 缺失值处理、异常值检测、数据标准化

**技能定义**:
```json
{
  "skill_type": "data_processing",
  "name": "data_cleaner",
  "description": "数据清洗和预处理工具",
  "version": "1.0.0",
  "inputs": [
    {
      "name": "data",
      "type": "list",
      "description": "原始数据列表",
      "required": true
    },
    {
      "name": "operations",
      "type": "list",
      "description": "清洗操作列表",
      "required": true
    }
  ],
  "outputs": [
    {
      "name": "clean_data",
      "type": "list",
      "description": "清洗后的数据"
    },
    {
      "name": "report",
      "type": "dict",
      "description": "清洗过程报告"
    }
  ],
  "requirements": {
    "dependencies": ["pandas>=1.5.0", "numpy>=1.21.0"],
    "environment": "python3.8+"
  }
}
```

**实现示例**:
```python
import pandas as pd
import numpy as np
from typing import List, Dict, Any

class DataCleanerSkill:
    def execute(self, data: List[Dict], operations: List[str]):
        """
        数据清洗
        Args:
            data: 原始数据
            operations: 清洗操作列表
        Returns:
            dict: 清洗结果
        """
        df = pd.DataFrame(data)
        report = {}
        
        for operation in operations:
            if operation == "remove_null":
                original_count = len(df)
                df = df.dropna()
                report["null_removed"] = original_count - len(df)
            
            elif operation == "remove_duplicates":
                original_count = len(df)
                df = df.drop_duplicates()
                report["duplicates_removed"] = original_count - len(df)
            
            elif operation == "standardize_numbers":
                numeric_cols = df.select_dtypes(include=[np.number]).columns
                for col in numeric_cols:
                    if df[col].std() > 0:
                        df[col] = (df[col] - df[col].mean()) / df[col].std()
        
        return {
            "clean_data": df.to_dict(orient="records"),
            "report": report,
            "row_count": len(df),
            "status": "success"
        }
```

### 3. 数据分析类技能

#### 模板3.1: 统计分析技能
**技能功能**: 执行统计分析计算
**适用场景**: 描述统计、相关性分析、回归分析

**技能定义**:
```json
{
  "skill_type": "data_analysis",
  "name": "statistical_analyzer",
  "description": "统计分析工具，提供多种统计方法",
  "version": "1.0.0",
  "inputs": [
    {
      "name": "data",
      "type": "list",
      "description": "分析数据",
      "required": true
    },
    {
      "name": "analysis_type",
      "type": "string",
      "description": "分析类型",
      "required": true
    }
  ],
  "outputs": [
    {
      "name": "results",
      "type": "dict",
      "description": "分析结果"
    },
    {
      "name": "charts",
      "type": "dict",
      "description": "分析图表数据"
    }
  ],
  "requirements": {
    "dependencies": ["pandas>=1.5.0", "scipy>=1.8.0", "statsmodels>=0.13.0"],
    "environment": "python3.8+"
  }
}
```

### 4. 可视化类技能

#### 模板4.1: 图表生成技能
**技能功能**: 生成各种类型的图表
**适用场景**: 数据可视化、报告图表生成

**技能定义**:
```json
{
  "skill_type": "visualization",
  "name": "chart_generator",
  "description": "图表生成工具，支持多种图表类型",
  "version": "1.0.0",
  "inputs": [
    {
      "name": "data",
      "type": "list",
      "description": "图表数据",
      "required": true
    },
    {
      "name": "chart_type",
      "type": "string",
      "description": "图表类型",
      "required": true
    }
  ],
  "outputs": [
    {
      "name": "chart_config",
      "type": "dict",
      "description": "图表配置"
    },
    {
      "name": "image_data",
      "type": "string",
      "description": "图表图片数据"
    }
  ],
  "requirements": {
    "dependencies": ["plotly>=5.10.0", "matplotlib>=3.5.0"],
    "environment": "python3.8+"
  }
}
```

## 技能接口规范

### 通用接口要求

#### 1. 输入输出格式
所有技能必须遵循以下格式：
```python
class SkillTemplate:
    def execute(self, **kwargs) -> Dict[str, Any]:
        """
        技能执行方法
        Args:
            **kwargs: 技能输入参数
        Returns:
            dict: 技能执行结果，必须包含status字段
        """
```

#### 2. 响应格式规范
```json
{
  "status": "success",  // 或 "error"
  "data": {...},        // 技能处理结果
  "metadata": {         // 处理元数据
    "processing_time": 1.23,
    "row_count": 100,
    "error_count": 0
  },
  "errors": []          // 错误信息列表
}
```

#### 3. 错误处理规范
```python
def handle_error(self, error: Exception) -> Dict[str, Any]:
    """统一错误处理"""
    return {
        "status": "error",
        "error": str(error),
        "error_type": type(error).__name__,
        "timestamp": datetime.now().isoformat()
    }
```

### 技能注册机制

#### 1. 技能描述文件
每个技能必须包含一个`skill.json`文件：
```json
{
  "name": "skill_name",
  "version": "1.0.0",
  "description": "技能描述",
  "author": "开发者名称",
  "license": "MIT",
  "entry_point": "main.py:SkillClass",
  "requirements": ["package1>=1.0", "package2>=2.0"],
  "tags": ["data", "processing", "analysis"],
  "compatibility": {
    "input_formats": ["csv", "json"],
    "output_formats": ["json", "html"]
  }
}
```

#### 2. 技能发现机制
```python
class SkillRegistry:
    def discover_skills(self, skill_dir: str) -> List[Dict]:
        """发现技能目录中的所有技能"""
        skills = []
        for item in os.listdir(skill_dir):
            skill_path = os.path.join(skill_dir, item)
            config_file = os.path.join(skill_path, "skill.json")
            
            if os.path.isfile(config_file):
                with open(config_file, 'r') as f:
                    config = json.load(f)
                    config["path"] = skill_path
                    skills.append(config)
        
        return skills
```

## 技能集成模式

### 模式1: 链式处理
```python
class ChainProcessor:
    def __init__(self, skills: List):
        self.skills = skills
    
    def execute(self, initial_data):
        data = initial_data
        for skill in self.skills:
            result = skill.execute(data)
            if result["status"] != "success":
                return result
            data = result["data"]
        return {"status": "success", "data": data}
```

### 模式2: 并行处理
```python
import concurrent.futures

class ParallelProcessor:
    def execute(self, skills: List, data):
        results = {}
        with concurrent.futures.ThreadPoolExecutor() as executor:
            futures = {
                executor.submit(skill.execute, data): skill.name
                for skill in skills
            }
            
            for future in concurrent.futures.as_completed(futures):
                skill_name = futures[future]
                try:
                    results[skill_name] = future.result()
                except Exception as e:
                    results[skill_name] = {"status": "error", "error": str(e)}
        
        return results
```

### 模式3: 条件分支
```python
class ConditionalProcessor:
    def execute(self, condition, true_skill, false_skill, data):
        if condition(data):
            return true_skill.execute(data)
        else:
            return false_skill.execute(data)
```

## 技能测试模板

### 单元测试模板
```python
import unittest
from your_skill import YourSkillClass

class TestYourSkill(unittest.TestCase):
    def setUp(self):
        self.skill = YourSkillClass()
    
    def test_success_case(self):
        """测试正常情况"""
        result = self.skill.execute(test_data)
        self.assertEqual(result["status"], "success")
        self.assertIn("data", result)
    
    def test_error_case(self):
        """测试错误情况"""
        result = self.skill.execute(invalid_data)
        self.assertEqual(result["status"], "error")
        self.assertIn("error", result)
    
    def test_performance(self):
        """测试性能"""
        import time
        start = time.time()
        result = self.skill.execute(large_data)
        execution_time = time.time() - start
        
        self.assertLess(execution_time, 5.0)  # 5秒内完成
        self.assertEqual(result["status"], "success")
```

### 集成测试模板
```python
class IntegrationTest:
    def test_skill_chain(self):
        """测试技能链"""
        skill1 = DataReaderSkill()
        skill2 = DataCleanerSkill()
        skill3 = AnalyzerSkill()
        
        # 链式执行
        result1 = skill1.execute("data.csv")
        result2 = skill2.execute(result1["data"])
        result3 = skill3.execute(result2["clean_data"])
        
        # 验证结果
        self.assertTrue(result1["status"] == "success")
        self.assertTrue(result2["status"] == "success")
        self.assertTrue(result3["status"] == "success")
        
        # 验证数据完整性
        self.assertGreater(len(result3["results"]), 0)
```

## 技能部署指南

### 1. 本地部署
```bash
# 创建技能目录
mkdir -p skills/my_skill
cd skills/my_skill

# 复制技能文件
cp -r /path/to/skill/* .

# 安装依赖
pip install -r requirements.txt

# 注册技能
python register_skill.py
```

### 2. 容器化部署
```dockerfile
FROM python:3.9-slim

WORKDIR /app

# 复制技能文件
COPY skill.json .
COPY requirements.txt .
COPY main.py .

# 安装依赖
RUN pip install --no-cache-dir -r requirements.txt

# 运行技能服务
CMD ["python", "main.py"]
```

### 3. 云端部署
```yaml
# cloud_deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: skill-deployment
spec:
  replicas: 3
  selector:
    matchLabels:
      app: skill
  template:
    metadata:
      labels:
        app: skill
    spec:
      containers:
      - name: skill-container
        image: myregistry/skill:latest
        ports:
        - containerPort: 8080
```

## 技能性能优化

### 1. 内存优化技巧
```python
class MemoryEfficientSkill:
    def process_large_data(self, data_iterator):
        """流式处理大数据"""
        for chunk in data_iterator:
            # 处理数据块
            processed_chunk = self.process_chunk(chunk)
            yield processed_chunk
            
            # 及时清理内存
            del chunk
            import gc
            gc.collect()
```

### 2. 计算优化技巧
```python
import numpy as np
from numba import jit

@jit(nopython=True)
def fast_computation(data):
    """使用JIT编译加速计算"""
    result = np.zeros_like(data)
    for i in range(len(data)):
        result[i] = complex_computation(data[i])
    return result
```

### 3. I/O优化技巧
```python
import asyncio

class AsyncSkill:
    async def process_multiple_files(self, file_paths):
        """异步处理多个文件"""
        tasks = [self.process_file(path) for path in file_paths]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        return results
```

## 技能安全规范

### 1. 输入验证
```python
class SafeSkill:
    def validate_input(self, data, schema):
        """验证输入数据"""
        import jsonschema
        
        try:
            jsonschema.validate(data, schema)
            return True
        except jsonschema.ValidationError as e:
            return {"status": "error", "error": f"输入验证失败: {str(e)}"}
```

### 2. 资源限制
```python
import resource

class ResourceLimitedSkill:
    def set_limits(self):
        """设置资源限制"""
        # 内存限制：1GB
        resource.setrlimit(resource.RLIMIT_AS, 
                          (1024**3, 1024**3))
        
        # CPU时间限制：10秒
        resource.setrlimit(resource.RLIMIT_CPU, 
                          (10, 10))
```

### 3. 日志安全
```python
import logging

class SecureLogging:
    def __init__(self):
        # 配置安全日志
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - [REDACTED]',
            handlers=[
                logging.FileHandler('skill.log'),
                logging.StreamHandler()
            ]
        )
```

## 技能版本管理

### 1. 版本控制策略
```
v1.0.0 - 初始版本
v1.1.0 - 新增功能，向后兼容
v2.0.0 - 不兼容的API变更
```

### 2. 依赖管理
```toml
# pyproject.toml
[project]
name = "my-skill"
version = "1.0.0"
dependencies = [
    "pandas>=1.5.0,<2.0.0",
    "numpy>=1.21.0"
]
```

### 3. 向后兼容性
```python
class BackwardCompatibleSkill:
    def __init__(self):
        # 支持旧版参数名
        self.parameter_mapping = {
            "old_param": "new_param",
            "deprecated_option": "current_option"
        }
```

## 技能文档模板

### README模板
```markdown
# 技能名称

## 功能描述
简要描述技能的功能和用途。

## 安装说明
```bash
pip install -r requirements.txt
```

## 使用方法
```python
from skill_module import SkillClass

skill = SkillClass()
result = skill.execute(parameters)
```

## 输入输出
### 输入参数
- `param1`: 参数1的描述
- `param2`: 参数2的描述

### 输出格式
```json
{
  "status": "success",
  "data": {...}
}
```

## 示例
提供使用示例。

## 许可证
MIT License
```

## 更新记录

### v1.0.0 (2026-01-01)
- 初始版本发布
- 包含4大类技能模板
- 提供接口规范和集成模式
- 收录测试和部署指南

### 后续计划
- 增加更多专业技能模板
- 完善安全规范
- 提供自动化工具
- 建立技能质量评估标准