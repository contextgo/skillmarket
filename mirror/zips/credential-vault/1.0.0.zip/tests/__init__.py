"""Tests for credential vault."""
