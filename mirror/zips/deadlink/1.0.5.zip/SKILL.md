---
name: DeadLink
description: "Scan websites and files for broken links with HTTP status details. Use when auditing links, finding broken URLs, validating references."
version: "2.0.0"
author: "BytesAgain"
homepage: https://bytesagain.com
source: https://github.com/bytesagain/ai-skills
tags: ["link","checker","broken","dead","404","website","seo","validation","html"]
categories: ["Developer Tools", "Utility"]
---
# DeadLink

System operations toolkit for scanning, monitoring, reporting, alerting, benchmarking, and managing infrastructure health. Log observations across multiple categories — from resource usage and performance checks to backup/restore operations and cleanup tasks. All entries are timestamped and searchable.

## Commands

### Core SysOps Commands

| Command | Description |
|---------|-------------|
| `deadlink scan <input>` | Log a scan result or initiate a scan operation. Without arguments, shows recent scan entries. |
| `deadlink monitor <input>` | Record a monitoring observation (uptime, latency, service health). Without arguments, shows recent monitor entries. |
| `deadlink report <input>` | Log a report or incident summary. Without arguments, shows recent report entries. |
| `deadlink alert <input>` | Record an alert or warning condition. Without arguments, shows recent alert entries. |
| `deadlink top <input>` | Log top resource consumers or priority items. Without arguments, shows recent top entries. |
| `deadlink usage <input>` | Record resource usage data (CPU, memory, disk, bandwidth). Without arguments, shows recent usage entries. |
| `deadlink check <input>` | Log a health check or verification result. Without arguments, shows recent check entries. |
| `deadlink fix <input>` | Record a fix or remediation action taken. Without arguments, shows recent fix entries. |
| `deadlink cleanup <input>` | Log a cleanup operation (temp files, old logs, stale data). Without arguments, shows recent cleanup entries. |
| `deadlink backup <input>` | Record a backup operation or backup status note. Without arguments, shows recent backup entries. |
| `deadlink restore <input>` | Log a restore operation from a previous backup. Without arguments, shows recent restore entries. |
| `deadlink log <input>` | Add a general log entry. Without arguments, shows recent log entries. |
| `deadlink benchmark <input>` | Record a benchmark result or performance measurement. Without arguments, shows recent benchmark entries. |
| `deadlink compare <input>` | Log a comparison between systems, periods, or configurations. Without arguments, shows recent compare entries. |

### Utility Commands

| Command | Description |
|---------|-------------|
| `deadlink stats` | Show summary statistics across all log categories (entry counts, data size, first entry date). |
| `deadlink export <format>` | Export all data in `json`, `csv`, or `txt` format. Output saved to the data directory. |
| `deadlink search <term>` | Search across all log files for a keyword or phrase (case-insensitive). |
| `deadlink recent` | Show the 20 most recent entries from the activity history log. |
| `deadlink status` | Health check — shows version, data directory, total entries, disk usage, and last activity. |
| `deadlink help` | Display all available commands and usage information. |
| `deadlink version` | Show the current version (v2.0.0). |

## Data Storage

All data is stored in `~/.local/share/deadlink/` as plain-text log files:

- Each command category has its own `.log` file (e.g., `scan.log`, `monitor.log`, `backup.log`, `benchmark.log`)
- Entries are timestamped in `YYYY-MM-DD HH:MM|value` format
- A central `history.log` tracks all activity across commands
- Export files are saved as `export.json`, `export.csv`, or `export.txt` in the same directory

## Requirements

- Bash 4.0+ (uses `set -euo pipefail`)
- Standard Unix utilities: `date`, `wc`, `du`, `head`, `tail`, `grep`, `cut`
- No external API keys or network access required
- No additional dependencies to install

## When to Use

1. **Infrastructure health monitoring** — Use `scan`, `monitor`, and `check` to log periodic health checks on servers, services, and endpoints.
2. **Incident response and tracking** — Use `alert`, `report`, and `fix` to document incidents from detection through resolution.
3. **Resource usage auditing** — Use `usage`, `top`, and `benchmark` to track CPU, memory, disk, and network usage over time.
4. **Backup and disaster recovery** — Use `backup`, `restore`, and `compare` to log backup schedules, verify restores, and compare configurations.
5. **System maintenance and cleanup** — Use `cleanup`, `log`, and `stats` to record housekeeping operations and review the overall state of logged data.

## Examples

### Monitor and scan infrastructure
```bash
deadlink scan "Web server port 443 — responding, 12ms latency"
deadlink monitor "Database replica lag: 0.3s — within threshold"
deadlink check "SSL certificate expires in 45 days"
deadlink usage "Disk usage: /data at 72% (540GB/750GB)"
```

### Incident response workflow
```bash
deadlink alert "High CPU on web-03: 95% sustained for 10 minutes"
deadlink report "Incident #142: web-03 CPU spike caused by runaway query"
deadlink fix "Killed runaway query PID 4821, added query timeout limit"
```

### Backup and restore operations
```bash
deadlink backup "Daily backup completed: db-main 2.3GB → s3://backups/"
deadlink restore "Restored staging DB from backup 2024-03-15"
deadlink compare "Production vs staging config diff: 3 changes found"
```

### Benchmark and maintenance
```bash
deadlink benchmark "API response p99: 142ms (target: <200ms)"
deadlink top "Top 3 disk consumers: /var/log (12GB), /data (8GB), /tmp (3GB)"
deadlink cleanup "Removed 4.2GB of rotated logs older than 30 days"
deadlink export json
deadlink stats
deadlink recent
```

---

*Powered by BytesAgain | bytesagain.com | hello@bytesagain.com*
