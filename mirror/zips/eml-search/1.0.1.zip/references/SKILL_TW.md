---
name: eml-search
description: |
  本地 .eml 郵件匯入、分類與搜尋工具。
  
  首次使用流程：
  1. 使用者指定 .eml 檔案所在目錄
  2. 選擇分類模式（通用/自訂/AI 自動）
  3. 執行解析入庫
  4. 開始搜尋
  
  觸發詞：找郵件、搜郵件、查郵件、郵件搜尋、匯入郵件、搜尋歷史郵件...
  
  依賴：Python 3.8+（內建 sqlite3、email 模組）
metadata:
  openclaw:
    emoji: "📧"
---

# eml-search — 本地郵件匯入與搜尋

將本地 .eml 郵件檔案解析匯入 SQLite 資料庫，支援全文檢索、分類過濾、日期篩選。

---

## 功能

- **解析 .eml 檔案**：擷取主旨、寄件者、收件者、日期、正文、附件資訊
- **增量匯入**：跳過已匯入的檔案，僅處理新增郵件
- **自動分類**：支援通用分類、使用者自訂、AI 自動生成三種模式
- **全文檢索**：FTS5 + LIKE 混合搜尋
- **多維度過濾**：分類、日期範圍、寄件者

---

## 依賴

| 依賴 | 用途 | 安裝方式 |
|------|------|---------|
| Python 3.8+ | 執行環境 | 系統內建 |
| sqlite3 | 資料庫 | Python 內建 |
| email | 解析 .eml | Python 內建 |

**無需 pip 安裝任何套件。**

---

## 跨平台相容

腳本僅使用 Python 標準庫和 `os.path` 跨平台介面，無 Windows/macOS/Linux 專屬程式碼或硬編碼路徑分隔符號。以下系統均可正常執行：

- ✅ Windows（Python 3.8+）
- ✅ macOS（Python 3.8+）
- ✅ Linux（Python 3.8+）

---

## 使用方法

### 方式一：透過 AI 對話（推薦）

**首次匯入：**
```
"匯入郵件"
"解析 /path/to/mails 下的 .eml 檔案"
"初始化郵件資料庫"
"匯入郵件並自動按分類整理"
```

**搜尋郵件：**
```
"找一下 2022 年專案驗收的郵件"
"搜尋合約相關的郵件"
"去年的通知公告有哪些"
"週報在哪裡"
```

### 方式二：命令列

```bash
# 匯入郵件
python scripts/eml_import.py /path/to/eml --db /path/to/emails.db

# 匯入 + 自動按分類整理（一步完成）
python scripts/eml_import.py /path/to/eml --db /path/to/emails.db --auto-organize

# 套用分類
python scripts/eml_classify.py /path/to/emails.db --mode generic

# 搜尋
python scripts/eml_search.py "合約審批"

# 帶過濾搜尋
python scripts/eml_search.py "會議" --category NOTICE --date-from 2023-01-01

# 查看統計
python scripts/eml_search.py --stats
```

---

## 自動整理檔案

使用 `--auto-organize` 參數，匯入郵件時**自動按分類建立子目錄並移動檔案**：

```bash
# 匯入並自動整理（推薦）
python scripts/eml_import.py /path/to/eml --db emails.db --auto-organize

# 匯入 + 自訂分類整理
python scripts/eml_import.py /path/to/eml --db emails.db --auto-organize --mode custom
```

**效果：**
```
/path/to/eml/
├── RPT_WEEK/
│   ├── 2022-01-01_weekly_report.eml
│   └── ...
├── RPT_MONTH/
├── NOTICE/
├── REPLY/
├── FORWARD/
├── RECALL/
├── OTHER/
└── emails.db
```

- 自動分類 → 建立子目錄 → 移動檔案 → 更新資料庫路徑
- 重名檔案自動加 `_1`、`_2` 後綴
- 資料庫路徑自動同步更新

---

## 分類模式

### 模式 A：通用分類（預設）

| 分類 | 說明 | 匹配規則 |
|------|------|----------|
| RPT_WEEK | 週報 | 主旨含"週報"/"週總結"/"weekly report" |
| RPT_MONTH | 月報 | 主旨含"月報"/"月總結"/"monthly report" |
| NOTICE | 通知公告 | 主旨含"通知"/"公告"/"通告"/"notice" |
| REPLY | 回覆郵件 | 主旨以"Re:"或"回覆:"開頭 |
| FORWARD | 轉發郵件 | 主旨以"Fw:"或"轉發:"開頭 |
| RECALL | 已撤回 | 正文含撤回提示 |
| OTHER | 其他 | 以上均不匹配 |

**優先級**：郵件類型 > 主旨匹配 > 關鍵詞匹配

### 模式 B：使用者自訂

提供 JSON 檔案定義分類規則。鍵為分類名稱，值為關鍵詞列表，郵件主旨或正文匹配任一關鍵詞即歸入該分類。按 JSON 鍵順序匹配，先匹配先生效，未匹配歸入"其他"。

```json
{
  "人事行政": ["人事", "行政", "考勤", "入職", "離職"],
  "財務報銷": ["報銷", "發票", "預算", "付款"]
}
```

```bash
# 產生範本
python scripts/eml_classify.py --template > my_rules.json

# 套用自訂規則
python scripts/eml_classify.py /path/to/emails.db --mode custom --rules my_rules.json
```

### 模式 C：AI 自動生成（推薦）

讓 AI 分析郵件內容，自動生成貼合業務的分類規則。無需手動撰寫關鍵詞。

直接告訴 AI：
```
"幫我分析郵件，自動生成分類規則"
"AI 自動分類這些郵件"
```

**執行流程**：
1. AI 讀取資料庫中的郵件主旨和正文
2. 分析高頻詞和內容規律
3. 生成分類規則 JSON 檔案，例如：
   ```json
   {
     "人事行政": ["入職", "離職", "考勤", "社保", "年假"],
     "財務報銷": ["報銷", "發票", "預算", "付款", "審批"],
     "專案進展": ["里程碑", "排期", "驗收", "交付", "復盤"],
     "客戶溝通": ["客戶", "需求", "回饋", "投訴", "報價"],
     "會議紀要": ["會議", "紀要", "決議", "待辦", "與會"]
   }
   ```
4. 展示給你確認（可刪減、改名、合併）
5. 確認後呼叫 `eml_classify.py --mode custom --rules rules.json` 套用

**適用場景**：郵件量大、業務領域不熟悉、不知道怎麼分類時。

---

## 資料查詢

分類結果儲存在 `emails` 表的 `category` 欄位：

```sql
-- 按分類統計
SELECT category, COUNT(*) FROM emails GROUP BY category;

-- 查看某分類的郵件
SELECT subject, from_email, date FROM emails WHERE category = 'RPT_WEEK';
```

---

## 搜尋語法

| 技巧 | 範例 |
|------|------|
| 關鍵詞 | `合約` `報銷` |
| 短語 | `"會議通知"` `"專案驗收"` |
| 分類過濾 | `--category RPT_WEEK` |
| 日期範圍 | `--date-from 2022-01-01 --date-to 2022-12-31` |
| 寄件者 | `--from zhangsan` |

---

## 故障排查

**匯入失敗**
- 檢查 .eml 檔案是否損壞
- 查看 `parse_error` 欄位了解具體錯誤

**搜尋無結果**
- 確認已執行匯入流程
- 檢查資料庫路徑是否正確

**中文亂碼**
- .eml 檔案本身編碼問題，腳本已做 UTF-8 相容處理

**增量匯入不生效**
- 檢查檔案路徑是否變更（移動資料夾會導致重新匯入）
