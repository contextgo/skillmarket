---
name: eml-search
description: |
  Local .eml email import, classification and search tool.
  
  First-time workflow:
  1. User specifies the .eml file directory
  2. Select classification mode (generic / custom / AI auto)
  3. Parse and import into database
  4. Start searching
  
  Trigger words: find email, search email, email search, import email, search old emails...
  
  Dependencies: Python 3.8+ (built-in sqlite3, email module)
metadata:
  openclaw:
    emoji: "📧"
---

# eml-search — Local Email Import & Search

Parse local .eml email files into an SQLite database with full-text search, category filtering, and date range support.

---

## Features

- **Parse .eml files**: Extract subject, sender, recipient, date, body, and attachment info
- **Incremental import**: Skip already-imported files, process only new emails
- **Auto classification**: Three modes — generic, custom rules, or AI-generated rules
- **Full-text search**: FTS5 + LIKE hybrid retrieval
- **Multi-dimension filtering**: Category, date range, sender

---

## Dependencies

| Dependency | Purpose | Installation |
|------------|---------|-------------|
| Python 3.8+ | Runtime | System built-in |
| sqlite3 | Database | Python built-in |
| email | Parse .eml | Python built-in |

**No pip packages required.**

---

## Cross-Platform Compatibility

Scripts use only Python standard library and `os.path` cross-platform APIs — no OS-specific code, no hardcoded path separators. Runs on:

- ✅ Windows (Python 3.8+)
- ✅ macOS (Python 3.8+)
- ✅ Linux (Python 3.8+)

---

## Usage

### Option 1: Via AI Conversation (Recommended)

**First-time import:**
```
"Import emails"
"Parse .eml files in /path/to/mails"
"Initialize email database"
"Import emails and auto-organize by category"
```

**Search emails:**
```
"Find project acceptance emails from 2022"
"Search for contract-related emails"
"What announcements were there last year?"
"Where are the weekly reports?"
```

### Option 2: Command Line

```bash
# Import emails
python scripts/eml_import.py /path/to/eml --db /path/to/emails.db

# Import + auto-organize by category (one step)
python scripts/eml_import.py /path/to/eml --db /path/to/emails.db --auto-organize

# Apply classification
python scripts/eml_classify.py /path/to/emails.db --mode generic

# Search
python scripts/eml_search.py "contract approval"

# Search with filters
python scripts/eml_search.py "meeting" --category NOTICE --date-from 2023-01-01

# View statistics
python scripts/eml_search.py --stats
```

---

## Auto-Organize Files

Use the `--auto-organize` flag to **automatically create category subdirectories and move files** during import:

```bash
# Import and auto-organize (recommended)
python scripts/eml_import.py /path/to/eml --db emails.db --auto-organize

# Import + custom classification organize
python scripts/eml_import.py /path/to/eml --db emails.db --auto-organize --mode custom
```

**Result:**
```
/path/to/eml/
├── RPT_WEEK/
│   ├── 2022-01-01_weekly_report.eml
│   └── ...
├── RPT_MONTH/
├── NOTICE/
├── REPLY/
├── FORWARD/
├── RECALL/
├── OTHER/
└── emails.db
```

- Auto-classify → Create subdirectories → Move files → Update database paths
- Duplicate filenames auto-renamed with `_1`, `_2` suffixes
- Database paths automatically synchronized

---

## Classification Modes

### Mode A: Generic Classification (Default)

| Category | Description | Matching Rule |
|----------|-------------|---------------|
| RPT_WEEK | Weekly Report | Subject contains "weekly report"/"week summary" |
| RPT_MONTH | Monthly Report | Subject contains "monthly report"/"month summary" |
| NOTICE | Announcement | Subject contains "notice"/"announcement"/"bulletin" |
| REPLY | Reply | Subject starts with "Re:" |
| FORWARD | Forward | Subject starts with "Fw:" |
| RECALL | Recalled | Body contains recall notice |
| OTHER | Other | No match above |

**Priority**: Mail type > Subject match > Keyword match

### Mode B: Custom Rules

Provide a JSON file to define classification rules. Keys are category names, values are keyword lists. An email matching any keyword in its subject or body is assigned to that category. Rules are matched in JSON key order (first match wins). Unmatched emails go to "Other".

```json
{
  "HR & Admin": ["onboarding", "offboarding", "attendance", "leave", "payroll"],
  "Finance": ["reimbursement", "invoice", "budget", "payment"]
}
```

```bash
# Generate template
python scripts/eml_classify.py --template > my_rules.json

# Apply custom rules
python scripts/eml_classify.py /path/to/emails.db --mode custom --rules my_rules.json
```

### Mode C: AI Auto-Generate (Recommended)

Let AI analyze email content and automatically generate classification rules tailored to your business. No manual keyword writing needed.

Just tell AI:
```
"Analyze my emails and generate classification rules"
"Auto-classify these emails with AI"
```

**Workflow**:
1. AI reads email subjects and bodies from the database
2. Analyzes high-frequency words and content patterns
3. Generates a classification rules JSON file, e.g.:
   ```json
   {
     "HR & Admin": ["onboarding", "offboarding", "attendance", "social security", "annual leave"],
     "Finance": ["reimbursement", "invoice", "budget", "payment", "approval"],
     "Projects": ["milestone", "schedule", "acceptance", "delivery", "retrospective"],
     "Clients": ["customer", "requirement", "feedback", "complaint", "quotation"],
     "Meetings": ["meeting", "minutes", "resolution", "action item", "attendee"]
   }
   ```
4. Presents rules for your confirmation (you can delete, rename, or merge)
5. After confirmation, runs `eml_classify.py --mode custom --rules rules.json`

**Best for**: Large email volumes, unfamiliar business domains, or when you're unsure how to categorize.

---

## Data Queries

Classification results are stored in the `category` column of the `emails` table:

```sql
-- Count by category
SELECT category, COUNT(*) FROM emails GROUP BY category;

-- View emails in a specific category
SELECT subject, from_email, date FROM emails WHERE category = 'RPT_WEEK';
```

---

## Search Syntax

| Technique | Example |
|-----------|---------|
| Keywords | `contract` `expense` |
| Phrase | `"meeting notice"` `"project acceptance"` |
| Category filter | `--category RPT_WEEK` |
| Date range | `--date-from 2022-01-01 --date-to 2022-12-31` |
| Sender | `--from zhangsan` |

---

## Troubleshooting

**Import fails**
- Check if .eml files are corrupted
- Inspect the `parse_error` column for error details

**No search results**
- Confirm import has been completed
- Check if database path is correct

**Garbled Chinese text**
- Likely an encoding issue in the source .eml file; the script handles UTF-8 compatibility

**Incremental import not working**
- Check if file paths have changed (moving folders causes re-import)
