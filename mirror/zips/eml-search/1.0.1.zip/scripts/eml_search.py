# -*- coding: utf-8 -*-
"""
eml-search: Search emails in SQLite database with hybrid retrieval (FTS5 + LIKE).
"""
import os, sys, json, sqlite3, re

# Config path (dynamic: always resolves to skill root directory)
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_DIR = os.path.dirname(SCRIPT_DIR)
CONFIG_PATH = os.path.join(CONFIG_DIR, "config.json")


def load_config():
    """Load config.json if exists"""
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
            return json.load(f)
    return None


def save_config(eml_dir, db_path, classification_mode='generic'):
    """Save config.json"""
    os.makedirs(CONFIG_DIR, exist_ok=True)
    config = {
        'eml_dir': eml_dir,
        'db_path': db_path,
        'classification_mode': classification_mode,
    }
    with open(CONFIG_PATH, 'w', encoding='utf-8') as f:
        json.dump(config, f, ensure_ascii=False, indent=2)
    return config


def search_emails(db_path, query, limit=20, category=None, date_from=None, date_to=None,
                  from_email=None, search_mode='auto'):
    """
    Hybrid search: FTS5 + LIKE fallback.
    
    Args:
        db_path: Path to SQLite database
        query: Search query string
        limit: Max results to return
        category: Filter by category
        date_from: Filter by date >= (YYYY-MM-DD)
        date_to: Filter by date <= (YYYY-MM-DD)
        from_email: Filter by sender email (LIKE match)
        search_mode: 'fts5', 'like', or 'auto' (try FTS5 first, fallback to LIKE)
    
    Returns:
        List of email dicts
    """
    if not os.path.exists(db_path):
        return []
    
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    
    results = []
    seen_ids = set()
    
    # Channel 1: FTS5
    if search_mode in ('fts5', 'auto'):
        try:
            # Build FTS query: split Chinese chars for better matching
            fts_query = ' OR '.join(query) if len(query) > 1 else query
            
            sql = '''
                SELECT e.id, e.subject, e.from_name, e.from_email, e.to_list,
                       e.date, e.category, e.mail_type, e.body_length,
                       e.has_attachment, e.attachment_count,
                       snippet(emails_fts, -1, '>>', '<<', '...', 30) as snippet,
                       bm25(emails_fts) as rank
                FROM emails_fts f
                JOIN emails e ON e.id = f.rowid
                WHERE emails_fts MATCH ?
            '''
            params = [fts_query]
            
            # Add filters
            conditions = []
            if category:
                conditions.append('e.category = ?')
                params.append(category)
            if date_from:
                conditions.append('e.date >= ?')
                params.append(date_from)
            if date_to:
                conditions.append('e.date <= ?')
                params.append(date_to)
            if from_email:
                conditions.append('e.from_email LIKE ?')
                params.append(f'%{from_email}%')
            
            if conditions:
                sql += ' AND ' + ' AND '.join(conditions)
            
            sql += ' ORDER BY rank LIMIT ?'
            params.append(limit)
            
            cur.execute(sql, params)
            for row in cur.fetchall():
                if row['id'] not in seen_ids:
                    seen_ids.add(row['id'])
                    results.append(_row_to_dict(row, 'fts5'))
        except Exception as e:
            pass  # FTS5 might fail on certain queries
    
    # Channel 2: LIKE (for accurate Chinese phrase matching)
    if search_mode in ('like', 'auto') and len(results) < limit:
        try:
            sql = '''
                SELECT id, subject, from_name, from_email, to_list,
                       date, category, mail_type, body_length,
                       has_attachment, attachment_count,
                       SUBSTR(body_text, 1, 200) as snippet
                FROM emails
                WHERE (subject LIKE ? OR body_text LIKE ?)
            '''
            like_pattern = f'%{query}%'
            params = [like_pattern, like_pattern]
            
            conditions = []
            if category:
                conditions.append('category = ?')
                params.append(category)
            if date_from:
                conditions.append('date >= ?')
                params.append(date_from)
            if date_to:
                conditions.append('date <= ?')
                params.append(date_to)
            if from_email:
                conditions.append('from_email LIKE ?')
                params.append(f'%{from_email}%')
            
            if conditions:
                sql += ' AND ' + ' AND '.join(conditions)
            
            sql += ' ORDER BY date DESC LIMIT ?'
            params.append(limit)
            
            cur.execute(sql, params)
            for row in cur.fetchall():
                if row['id'] not in seen_ids:
                    seen_ids.add(row['id'])
                    results.append(_row_to_dict(row, 'like'))
        except Exception as e:
            pass
    
    conn.close()
    return results[:limit]


def _row_to_dict(row, source):
    """Convert sqlite3.Row to dict"""
    return {
        'id': row['id'],
        'subject': row['subject'] or '',
        'from_name': row['from_name'] or '',
        'from_email': row['from_email'] or '',
        'date': row['date'] or '',
        'category': row['category'] or '',
        'type': row['mail_type'] or '',
        'body_length': row['body_length'],
        'has_attachment': bool(row['has_attachment']),
        'attachments': row['attachment_count'],
        'snippet': (row['snippet'] or '').replace('\n', ' ')[:150],
        'source': source,
    }


def get_email_detail(db_path, email_id):
    """Get full email detail by ID"""
    if not os.path.exists(db_path):
        return None
    
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute('SELECT * FROM emails WHERE id = ?', (email_id,))
    row = cur.fetchone()
    conn.close()
    
    if not row:
        return None
    
    result = dict(row)
    # Clean up for display
    if result.get('body_text'):
        result['body_text'] = result['body_text'][:5000]
    return result


def get_stats(db_path):
    """Get database statistics"""
    if not os.path.exists(db_path):
        return None
    
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    
    stats = {}
    cur.execute('SELECT COUNT(*) FROM emails')
    stats['total'] = cur.fetchone()[0]
    
    cur.execute('SELECT COUNT(*) FROM emails WHERE body_length > 0')
    stats['with_body'] = cur.fetchone()[0]
    
    cur.execute('SELECT COUNT(*) FROM emails WHERE has_attachment = 1')
    stats['with_attachments'] = cur.fetchone()[0]
    
    cur.execute('SELECT category, COUNT(*) as cnt FROM emails GROUP BY category ORDER BY cnt DESC')
    stats['categories'] = [{'name': r[0], 'count': r[1]} for r in cur.fetchall()]
    
    cur.execute('SELECT MIN(date), MAX(date) FROM emails WHERE date != ""')
    row = cur.fetchone()
    stats['date_range'] = {'from': row[0], 'to': row[1]}
    
    conn.close()
    return stats


def get_categories(db_path):
    """Get list of categories"""
    if not os.path.exists(db_path):
        return []
    
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.execute('SELECT DISTINCT category FROM emails WHERE category != "" ORDER BY category')
    categories = [r[0] for r in cur.fetchall()]
    conn.close()
    return categories


if __name__ == '__main__':
    # CLI demo
    import argparse
    parser = argparse.ArgumentParser(description='Search emails in database')
    parser.add_argument('--db', help='Database path (or use config.json)')
    parser.add_argument('query', nargs='?', help='Search query')
    parser.add_argument('--category', help='Filter by category')
    parser.add_argument('--from', dest='from_email', help='Filter by sender')
    parser.add_argument('--date-from', help='Date from (YYYY-MM-DD)')
    parser.add_argument('--date-to', help='Date to (YYYY-MM-DD)')
    parser.add_argument('--limit', type=int, default=10, help='Max results')
    parser.add_argument('--stats', action='store_true', help='Show stats and exit')
    parser.add_argument('--categories', action='store_true', help='List categories and exit')
    args = parser.parse_args()
    
    # Determine database path
    db_path = args.db
    if not db_path:
        config = load_config()
        if config:
            db_path = config.get('db_path')
    
    if not db_path or not os.path.exists(db_path):
        print(f"Error: Database not found. Use --db or ensure config.json exists at {CONFIG_PATH}")
        exit(1)
    
    # Stats mode
    if args.stats:
        stats = get_stats(db_path)
        print(json.dumps(stats, ensure_ascii=False, indent=2))
        exit(0)
    
    # Categories mode
    if args.categories:
        categories = get_categories(db_path)
        for cat in categories:
            print(cat)
        exit(0)
    
    # Search mode
    if not args.query:
        print("Error: Query required (or use --stats / --categories)")
        exit(1)
    
    results = search_emails(
        db_path, args.query,
        limit=args.limit,
        category=args.category,
        date_from=args.date_from,
        date_to=args.date_to,
        from_email=args.from_email
    )
    
    print(f"Found {len(results)} results for: {args.query}")
    print("-" * 60)
    
    for i, r in enumerate(results):
        att = f" [📎{r['attachments']}]" if r['has_attachment'] else ""
        print(f"\n[{i+1}] {r['subject'][:60]}{att}")
        print(f"    From: {r['from_name']} <{r['from_email'][:30]}>")
        print(f"    Date: {r['date'][:10]} | Category: {r['category']}")
        if r['snippet']:
            print(f"    {r['snippet'][:120]}...")
