# -*- coding: utf-8 -*-
"""
eml-import: Parse .eml files into SQLite database with FTS5 full-text search.
Supports incremental import (only new files).
"""
import os, sys, json, re, sqlite3, email, time
from email import policy
from email.utils import parsedate_to_datetime
from datetime import datetime

# Database schema
SCHEMA_SQL = '''
CREATE TABLE IF NOT EXISTS emails (
    id INTEGER PRIMARY KEY,
    file_path TEXT UNIQUE,
    category TEXT,
    mail_type TEXT,
    message_id TEXT,
    in_reply_to TEXT,
    references_ TEXT,
    subject TEXT,
    from_name TEXT,
    from_email TEXT,
    to_list TEXT,
    cc_list TEXT,
    date TEXT,
    date_raw TEXT,
    body_text TEXT,
    body_length INTEGER,
    has_attachment INTEGER,
    attachment_count INTEGER,
    attachment_total_size INTEGER,
    file_size INTEGER,
    parse_error TEXT,
    attachments TEXT
);

CREATE VIRTUAL TABLE IF NOT EXISTS emails_fts USING fts5(
    subject, body_text, from_email, to_list,
    content=emails, content_rowid=id,
    tokenize='unicode61'
);

CREATE INDEX IF NOT EXISTS idx_emails_category ON emails(category);
CREATE INDEX IF NOT EXISTS idx_emails_date ON emails(date);
CREATE INDEX IF NOT EXISTS idx_emails_from ON emails(from_email);
'''


def init_database(db_path):
    """Initialize SQLite database with schema"""
    conn = sqlite3.connect(db_path)
    conn.executescript(SCHEMA_SQL)
    conn.commit()
    return conn


def parse_eml_file(file_path):
    """Parse a single .eml file and return dict"""
    result = {
        'file_path': file_path,
        'file_size': os.path.getsize(file_path),
        'category': '',
        'mail_type': '',
        'message_id': '',
        'in_reply_to': '',
        'references_': '',
        'subject': '',
        'from_name': '',
        'from_email': '',
        'to_list': '',
        'cc_list': '',
        'date': '',
        'date_raw': '',
        'body_text': '',
        'body_length': 0,
        'has_attachment': 0,
        'attachment_count': 0,
        'attachment_total_size': 0,
        'parse_error': '',
        'attachments': '[]',
    }
    
    try:
        with open(file_path, 'rb') as f:
            msg = email.message_from_binary_file(f, policy=policy.default)
        
        # Headers
        result['message_id'] = msg.get('Message-ID', '')
        result['in_reply_to'] = msg.get('In-Reply-To', '')
        result['references_'] = msg.get('References', '')
        result['subject'] = msg.get('Subject', '') or '(no subject)'
        
        # From
        from_addr = msg.get('From', '')
        if from_addr:
            parsed_from = email.utils.parseaddr(from_addr)
            result['from_name'] = parsed_from[0]
            result['from_email'] = parsed_from[1]
        
        # To
        to_addrs = msg.get_all('To', [])
        result['to_list'] = ', '.join(str(a) for a in to_addrs)
        
        # CC
        cc_addrs = msg.get_all('Cc', [])
        result['cc_list'] = ', '.join(str(a) for a in cc_addrs)
        
        # Date
        date_str = msg.get('Date', '')
        result['date_raw'] = date_str
        if date_str:
            try:
                dt = parsedate_to_datetime(date_str)
                result['date'] = dt.strftime('%Y-%m-%d %H:%M:%S')
            except:
                result['date'] = date_str[:19] if len(date_str) > 19 else date_str
        
        # Body and attachments
        body_parts = []
        attachments = []
        
        def walk_parts(part):
            content_type = part.get_content_type()
            disposition = part.get_content_disposition()
            
            if disposition == 'attachment':
                # Attachment
                filename = part.get_filename() or 'unnamed'
                payload = part.get_payload(decode=True)
                size = len(payload) if payload else 0
                attachments.append({
                    'filename': filename,
                    'size': size,
                    'type': content_type
                })
            elif content_type == 'text/plain':
                try:
                    text = part.get_content()
                    if text:
                        body_parts.append(text)
                except:
                    pass
            elif content_type == 'text/html':
                # Skip HTML for now, only extract plain text
                pass
            
            # Recurse for multipart
            if part.is_multipart():
                for subpart in part.iter_parts():
                    walk_parts(subpart)
        
        if msg.is_multipart():
            for part in msg.iter_parts():
                walk_parts(part)
        else:
            walk_parts(msg)
        
        # Combine body parts
        body_text = '\n\n'.join(body_parts)
        # Clean up
        body_text = re.sub(r'\r\n', '\n', body_text)
        body_text = re.sub(r'\n{3,}', '\n\n', body_text)
        result['body_text'] = body_text
        result['body_length'] = len(body_text)
        
        # Attachments
        result['attachment_count'] = len(attachments)
        result['attachment_total_size'] = sum(a['size'] for a in attachments)
        result['has_attachment'] = 1 if attachments else 0
        result['attachments'] = json.dumps(attachments, ensure_ascii=False)
        
        # Mail type detection
        if result['in_reply_to']:
            result['mail_type'] = 'reply'
        elif re.search(r'^(Fw:|转发[:：])', result['subject'], re.I):
            result['mail_type'] = 'forward'
        elif result['body_length'] < 1000 and '撤回' in result['body_text']:
            result['mail_type'] = 'recall'
        else:
            result['mail_type'] = 'normal'
        
    except Exception as e:
        result['parse_error'] = str(e)[:200]
    
    return result


def import_emails(eml_dir, db_path, progress_callback=None):
    """
    Import all .eml files from directory into database.
    Supports incremental import (skips already imported files).
    
    Args:
        eml_dir: Directory containing .eml files
        db_path: Path to SQLite database
        progress_callback: Optional callback(current, total, filepath)
    
    Returns:
        dict with import statistics
    """
    # Initialize database
    conn = init_database(db_path)
    cur = conn.cursor()
    
    # Get already imported files
    cur.execute("SELECT file_path FROM emails")
    imported_files = set(row[0] for row in cur.fetchall())
    
    # Find all .eml files
    eml_files = []
    for root, dirs, files in os.walk(eml_dir):
        for f in files:
            if f.lower().endswith('.eml'):
                full_path = os.path.join(root, f)
                if full_path not in imported_files:
                    eml_files.append(full_path)
    
    total_new = len(eml_files)
    if total_new == 0:
        conn.close()
        return {
            'total_files': 0,
            'new_files': 0,
            'success': 0,
            'failed': 0,
            'db_path': db_path,
            'message': 'No new files to import'
        }
    
    # Import files
    success_count = 0
    failed_count = 0
    
    for i, file_path in enumerate(eml_files):
        if progress_callback:
            progress_callback(i + 1, total_new, file_path)
        
        data = parse_eml_file(file_path)
        
        try:
            cur.execute('''
                INSERT INTO emails (
                    file_path, category, mail_type, message_id, in_reply_to, references_,
                    subject, from_name, from_email, to_list, cc_list, date, date_raw,
                    body_text, body_length, has_attachment, attachment_count,
                    attachment_total_size, file_size, parse_error, attachments
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                data['file_path'], data['category'], data['mail_type'],
                data['message_id'], data['in_reply_to'], data['references_'],
                data['subject'], data['from_name'], data['from_email'],
                data['to_list'], data['cc_list'], data['date'], data['date_raw'],
                data['body_text'], data['body_length'], data['has_attachment'],
                data['attachment_count'], data['attachment_total_size'],
                data['file_size'], data['parse_error'], data['attachments']
            ))
            success_count += 1
        except Exception as e:
            failed_count += 1
            print(f"  ERROR importing {file_path}: {e}")
        
        # Commit every 100 records
        if (i + 1) % 100 == 0:
            conn.commit()
    
    conn.commit()
    
    # Get final stats
    cur.execute("SELECT COUNT(*) FROM emails")
    total_emails = cur.fetchone()[0]
    
    cur.execute("SELECT COUNT(*) FROM emails WHERE parse_error != ''")
    error_count = cur.fetchone()[0]
    
    conn.close()
    
    return {
        'total_files': len(eml_files) + len(imported_files),
        'new_files': total_new,
        'success': success_count,
        'failed': failed_count,
        'total_in_db': total_emails,
        'errors_in_db': error_count,
        'db_path': db_path,
    }


def get_import_stats(db_path):
    """Get statistics about imported emails"""
    if not os.path.exists(db_path):
        return None
    
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    
    stats = {}
    cur.execute("SELECT COUNT(*) FROM emails")
    stats['total'] = cur.fetchone()[0]
    
    cur.execute("SELECT COUNT(*) FROM emails WHERE body_length > 0")
    stats['with_body'] = cur.fetchone()[0]
    
    cur.execute("SELECT COUNT(*) FROM emails WHERE has_attachment = 1")
    stats['with_attachments'] = cur.fetchone()[0]
    
    cur.execute("SELECT category, COUNT(*) FROM emails GROUP BY category")
    stats['by_category'] = dict(cur.fetchall())
    
    cur.execute("SELECT MIN(date), MAX(date) FROM emails WHERE date != ''")
    row = cur.fetchone()
    stats['date_range'] = {'from': row[0], 'to': row[1]}
    
    conn.close()
    return stats


def organize_files_by_category(db_path, base_dir, mode='generic'):
    """
    Organize .eml files into subdirectories by category after import.
    Moves files from flat structure to category-based structure.
    
    Args:
        db_path: Path to SQLite database
        base_dir: Base directory to create category subdirectories
        mode: 'generic' or 'custom' classification mode
    
    Returns:
        dict with organization statistics
    """
    import shutil
    from eml_classify import apply_classification
    
    # First, apply classification if not already done
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM emails WHERE category = '' OR category IS NULL")
    unclassified = cur.fetchone()[0]
    conn.close()
    
    if unclassified > 0:
        print(f"Classifying {unclassified} unclassified emails...")
        apply_classification(db_path, mode=mode)
    
    # Create category directories and move files
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    
    cur.execute("SELECT id, file_path, category FROM emails WHERE category != ''")
    rows = cur.fetchall()
    
    stats = {'moved': 0, 'skipped': 0, 'errors': 0}
    updated_paths = []
    
    for row in rows:
        email_id = row['id']
        old_path = row['file_path']
        category = row['category'] or 'OTHER'
        
        if not os.path.exists(old_path):
            stats['skipped'] += 1
            continue
        
        # Create category directory
        cat_dir = os.path.join(base_dir, category)
        os.makedirs(cat_dir, exist_ok=True)
        
        # Generate new path
        filename = os.path.basename(old_path)
        new_path = os.path.join(cat_dir, filename)
        
        # Handle duplicate filenames
        if os.path.exists(new_path) and old_path != new_path:
            name, ext = os.path.splitext(filename)
            counter = 1
            while os.path.exists(new_path):
                new_path = os.path.join(cat_dir, f"{name}_{counter}{ext}")
                counter += 1
        
        # Move file if path changed
        if old_path != new_path:
            try:
                shutil.move(old_path, new_path)
                updated_paths.append((email_id, new_path))
                stats['moved'] += 1
            except Exception as e:
                print(f"  Error moving {old_path}: {e}")
                stats['errors'] += 1
        else:
            stats['skipped'] += 1
    
    # Update database with new paths
    for email_id, new_path in updated_paths:
        cur.execute("UPDATE emails SET file_path = ? WHERE id = ?", (new_path, email_id))
    
    conn.commit()
    conn.close()
    
    return stats


if __name__ == '__main__':
    # CLI demo
    import argparse
    parser = argparse.ArgumentParser(description='Import .eml files to SQLite')
    parser.add_argument('eml_dir', help='Directory containing .eml files')
    parser.add_argument('--db', default='emails.db', help='Database path')
    parser.add_argument('--auto-organize', action='store_true',
                        help='Automatically organize files by category after import')
    parser.add_argument('--mode', choices=['generic', 'custom'], default='generic',
                        help='Classification mode for auto-organize')
    args = parser.parse_args()
    
    def progress(current, total, filepath):
        pct = current * 100 // total
        # Handle encoding issues on Windows console
        try:
            fname = os.path.basename(filepath)
            print(f"[{pct:3d}%] {current}/{total} - {fname}")
        except UnicodeEncodeError:
            # Fallback to ASCII representation
            fname = os.path.basename(filepath).encode('ascii', 'replace').decode('ascii')
            print(f"[{pct:3d}%] {current}/{total} - {fname}")
    
    print(f"Importing from: {args.eml_dir}")
    print(f"Database: {args.db}")
    print("-" * 60)
    
    result = import_emails(args.eml_dir, args.db, progress)
    
    print("-" * 60)
    print(f"Import complete!")
    print(f"  New files: {result['new_files']}")
    print(f"  Success: {result['success']}")
    print(f"  Failed: {result['failed']}")
    print(f"  Total in DB: {result.get('total_in_db', 'N/A')}")
    
    # Auto-organize if requested
    if args.auto_organize and result['success'] > 0:
        print("-" * 60)
        print(f"Auto-organizing files by category (mode: {args.mode})...")
        org_stats = organize_files_by_category(args.db, args.eml_dir, args.mode)
        print(f"Organization complete!")
        print(f"  Moved: {org_stats['moved']}")
        print(f"  Skipped: {org_stats['skipped']}")
        print(f"  Errors: {org_stats['errors']}")
