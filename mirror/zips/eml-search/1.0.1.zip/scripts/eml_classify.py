# -*- coding: utf-8 -*-
"""
eml-classify: Email classification engine for eml-import.
Supports three modes: generic (default), custom, ai-auto.
"""
import os, json, re, sqlite3

# Generic classification rules (default)
GENERIC_RULES = [
    {
        'code': 'RPT_WEEK',
        'name': 'Weekly Report',
        'keywords': ['周报', '周总结', 'weekly report', 'week summary'],
        'subject_patterns': [r'周报', r'周总结', r'weekly\s*report', r'week\s*summary'],
    },
    {
        'code': 'RPT_MONTH',
        'name': 'Monthly Report',
        'keywords': ['月报', '月总结', 'monthly report', 'month summary'],
        'subject_patterns': [r'月报', r'月总结', r'monthly\s*report', r'month\s*summary'],
    },
    {
        'code': 'NOTICE',
        'name': 'Announcement',
        'keywords': ['通知', '公告', '通告', 'notice', 'announcement'],
        'subject_patterns': [r'通知', r'公告', r'通告', r'notice', r'announcement'],
    },
    {
        'code': 'REPLY',
        'name': 'Reply',
        'keywords': [],
        'subject_patterns': [r'^Re:', r'^回复[:：]'],
        'mail_type': 'reply',
    },
    {
        'code': 'FORWARD',
        'name': 'Forward',
        'keywords': [],
        'subject_patterns': [r'^Fw:', r'^转发[:：]'],
        'mail_type': 'forward',
    },
    {
        'code': 'RECALL',
        'name': 'Recalled',
        'keywords': ['撤回', 'recall'],
        'subject_patterns': [],
        'mail_type': 'recall',
    },
    {
        'code': 'OTHER',
        'name': 'Other',
        'keywords': [],
        'subject_patterns': [],
    },
]


def classify_generic(subject, body_text, mail_type):
    """
    Classify email using generic rules.
    Returns category code.
    """
    subject = subject or ''
    body_text = body_text or ''
    
    for rule in GENERIC_RULES:
        # Check mail_type first (highest priority)
        if rule.get('mail_type'):
            if mail_type == rule['mail_type']:
                return rule['code']
            continue
        
        # Check subject patterns
        matched = False
        for pattern in rule.get('subject_patterns', []):
            if re.search(pattern, subject, re.IGNORECASE):
                matched = True
                break
        
        if matched:
            return rule['code']
        
        # Check keywords in subject and body
        for kw in rule.get('keywords', []):
            if kw in subject or kw in body_text:
                return rule['code']
    
    return 'OTHER'


def load_custom_rules(rules_path):
    """
    Load custom classification rules from JSON file.
    Format: {"分类名": ["关键词1", "关键词2", ...], ...}
    """
    with open(rules_path, 'r', encoding='utf-8') as f:
        return json.load(f)


def classify_custom(subject, body_text, custom_rules):
    """
    Classify email using custom rules.
    Returns category name (key from custom_rules).
    """
    subject = subject or ''
    body_text = body_text or ''
    text = subject + ' ' + body_text
    
    for category, keywords in custom_rules.items():
        for kw in keywords:
            if kw in text:
                return category
    
    return 'Other'


def apply_classification(db_path, mode='generic', custom_rules=None, progress_callback=None):
    """
    Apply classification to all emails in database.
    
    Args:
        db_path: Path to SQLite database
        mode: 'generic', 'custom', or 'ai'
        custom_rules: Dict for custom mode, loaded from JSON file
        progress_callback: Optional callback(current, total)
    
    Returns:
        dict with classification statistics
    """
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    
    # Get all emails
    cur.execute("SELECT id, subject, body_text, mail_type FROM emails")
    rows = cur.fetchall()
    total = len(rows)
    
    stats = {}
    
    for i, row in enumerate(rows):
        if progress_callback:
            progress_callback(i + 1, total)
        
        email_id = row['id']
        subject = row['subject'] or ''
        body_text = row['body_text'] or ''
        mail_type = row['mail_type'] or 'normal'
        
        # Classify
        if mode == 'generic':
            category = classify_generic(subject, body_text, mail_type)
        elif mode == 'custom' and custom_rules:
            category = classify_custom(subject, body_text, custom_rules)
        else:
            category = 'OTHER'
        
        # Update database
        cur.execute("UPDATE emails SET category = ? WHERE id = ?", (category, email_id))
        
        # Track stats
        stats[category] = stats.get(category, 0) + 1
        
        # Commit every 100
        if (i + 1) % 100 == 0:
            conn.commit()
    
    conn.commit()
    conn.close()
    
    return {
        'total': total,
        'mode': mode,
        'stats': stats,
    }


def get_generic_categories():
    """Return list of generic category definitions"""
    return [
        {'code': r['code'], 'name': r['name']}
        for r in GENERIC_RULES
    ]


def generate_custom_rules_template():
    """Generate a template for custom classification rules"""
    return {
        "人事行政": ["人事", "行政", "考勤", "入职", "离职", "社保"],
        "财务报销": ["报销", "发票", "预算", "付款", "财务"],
        "项目管理": ["项目", "里程碑", "排期", "验收", "交付"],
        "技术运维": ["服务器", "部署", "上线", "故障", "运维"],
        "客户沟通": ["客户", "需求", "反馈", "投诉", "方案"],
    }


if __name__ == '__main__':
    # CLI demo
    import argparse
    parser = argparse.ArgumentParser(description='Classify emails in database')
    parser.add_argument('db_path', help='Path to SQLite database')
    parser.add_argument('--mode', choices=['generic', 'custom'], default='generic',
                        help='Classification mode')
    parser.add_argument('--rules', help='Path to custom rules JSON file (for custom mode)')
    parser.add_argument('--template', action='store_true',
                        help='Print custom rules template and exit')
    args = parser.parse_args()
    
    if args.template:
        print(json.dumps(generate_custom_rules_template(), ensure_ascii=False, indent=2))
        exit(0)
    
    custom_rules = None
    if args.mode == 'custom':
        if not args.rules:
            print("Error: --rules required for custom mode")
            exit(1)
        custom_rules = load_custom_rules(args.rules)
        print(f"Loaded {len(custom_rules)} custom categories")
    
    def progress(current, total):
        pct = current * 100 // total
        print(f"[{pct:3d}%] Classifying {current}/{total}")
    
    print(f"Applying {args.mode} classification to: {args.db_path}")
    result = apply_classification(args.db_path, args.mode, custom_rules, progress)
    
    print("\nClassification complete!")
    print(f"  Total: {result['total']}")
    print(f"  Mode: {result['mode']}")
    print("\n  By category:")
    for cat, count in sorted(result['stats'].items(), key=lambda x: -x[1]):
        print(f"    {cat}: {count}")
