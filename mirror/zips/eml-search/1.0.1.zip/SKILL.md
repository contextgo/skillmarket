---
name: eml-search
description: |
  本地 .eml 邮件导入、分类与搜索工具。
  
  首次使用流程：
  1. 用户指定 .eml 文件所在目录
  2. 选择分类模式（通用/自定义/AI自动）
  3. 执行解析入库
  4. 开始搜索
  
  触发词：找邮件、搜邮件、查邮件、邮件搜索、导入邮件、搜索历史邮件...
  
  依赖：Python 3.8+（内置 sqlite3、email 模块）
metadata:
  openclaw:
    emoji: "📧"
---

# eml-search — 本地邮件导入与搜索

将本地 .eml 邮件文件解析导入 SQLite 数据库，支持全文检索、分类过滤、日期筛选。

---

## 功能

- **解析 .eml 文件**：提取主题、发件人、收件人、日期、正文、附件信息
- **增量导入**：跳过已导入的文件，只处理新增邮件
- **自动分类**：支持通用分类、用户自定义、AI 自动生成三种模式
- **全文检索**：FTS5 + LIKE 混合搜索
- **多维度过滤**：分类、日期范围、发件人

---

## 依赖

| 依赖 | 用途 | 安装方式 |
|------|------|---------|
| Python 3.8+ | 运行环境 | 系统自带 |
| sqlite3 | 数据库 | Python 内置 |
| email | 解析 .eml | Python 内置 |

**无需 pip 安装任何包。**

---

## 跨平台兼容

脚本仅使用 Python 标准库和 `os.path` 跨平台接口，无 Windows/macOS/Linux 专属代码或硬编码路径分隔符。以下系统均可正常运行：

- ✅ Windows（Python 3.8+）
- ✅ macOS（Python 3.8+）
- ✅ Linux（Python 3.8+）

---

## 使用方法

### 方式一：通过 AI 对话（推荐）

**首次导入：**
```
"导入邮件"
"解析 /path/to/mails 下的 .eml 文件"
"初始化邮件数据库"
"导入邮件并自动按分类整理"
```

**搜索邮件：**
```
"找一下 2022 年项目验收的邮件"
"搜索合同相关的邮件"
"去年的通知公告有哪些"
"周报在哪里"
```

### 方式二：命令行

```bash
# 导入邮件
python scripts/eml_import.py /path/to/eml --db /path/to/emails.db

# 导入 + 自动按分类整理（一步完成）
python scripts/eml_import.py /path/to/eml --db /path/to/emails.db --auto-organize

# 应用分类
python scripts/eml_classify.py /path/to/emails.db --mode generic

# 搜索
python scripts/eml_search.py "合同审批"

# 带过滤搜索
python scripts/eml_search.py "会议" --category NOTICE --date-from 2023-01-01

# 查看统计
python scripts/eml_search.py --stats
```

---

## 自动整理文件

使用 `--auto-organize` 参数，导入邮件时**自动按分类创建子目录并移动文件**：

```bash
# 导入并自动整理（推荐）
python scripts/eml_import.py /path/to/eml --db emails.db --auto-organize

# 导入 + 自定义分类整理
python scripts/eml_import.py /path/to/eml --db emails.db --auto-organize --mode custom
```

**效果：**
```
/path/to/eml/
├── RPT_WEEK/
│   ├── 2022-01-01_weekly_report.eml
│   └── ...
├── RPT_MONTH/
├── NOTICE/
├── REPLY/
├── FORWARD/
├── RECALL/
├── OTHER/
└── emails.db
```

- 自动分类 → 创建子目录 → 移动文件 → 更新数据库路径
- 重名文件自动加 `_1`、`_2` 后缀
- 数据库路径自动同步更新

---

## 分类模式

### 模式 A：通用分类（默认）

| 分类 | 说明 | 匹配规则 |
|------|------|----------|
| RPT_WEEK | 周报 | 主题含"周报"/"周总结"/"weekly report" |
| RPT_MONTH | 月报 | 主题含"月报"/"月总结"/"monthly report" |
| NOTICE | 通知公告 | 主题含"通知"/"公告"/"通告"/"notice" |
| REPLY | 回复邮件 | 主题以"Re:"或"回复:"开头 |
| FORWARD | 转发邮件 | 主题以"Fw:"或"转发:"开头 |
| RECALL | 已撤回 | 正文含撤回提示 |
| OTHER | 其他 | 以上均不匹配 |

**优先级**：邮件类型 > 主题匹配 > 关键词匹配

### 模式 B：用户自定义

提供 JSON 文件定义分类规则。键为分类名称，值为关键词列表，邮件主题或正文匹配任一关键词即归入该分类。按 JSON 键顺序匹配，先匹配先生效，未匹配归入"其他"。

```json
{
  "人事行政": ["人事", "行政", "考勤", "入职", "离职"],
  "财务报销": ["报销", "发票", "预算", "付款"]
}
```

```bash
# 生成模板
python scripts/eml_classify.py --template > my_rules.json

# 应用自定义规则
python scripts/eml_classify.py /path/to/emails.db --mode custom --rules my_rules.json
```

### 模式 C：AI 自动生成（推荐）

让 AI 分析邮件内容，自动生成贴合业务的分类规则。无需手动编写关键词。

直接告诉 AI：
```
"帮我分析邮件，自动生成分类规则"
"AI 自动分类这些邮件"
```

**执行流程**：
1. AI 读取数据库中的邮件主题和正文
2. 分析高频词和内容规律
3. 生成分类规则 JSON 文件，例如：
   ```json
   {
     "人事行政": ["入职", "离职", "考勤", "社保", "年假"],
     "财务报销": ["报销", "发票", "预算", "付款", "审批"],
     "项目进展": ["里程碑", "排期", "验收", "交付", "复盘"],
     "客户沟通": ["客户", "需求", "反馈", "投诉", "报价"],
     "会议纪要": ["会议", "纪要", "决议", "待办", "参会"]
   }
   ```
4. 展示给你确认（可删减、改名、合并）
5. 确认后调用 `eml_classify.py --mode custom --rules rules.json` 应用

**适用场景**：邮件量大、业务领域不熟悉、不知道怎么分类时。

---

## 数据查询

分类结果存储在 `emails` 表的 `category` 字段：

```sql
-- 按分类统计
SELECT category, COUNT(*) FROM emails GROUP BY category;

-- 查看某分类的邮件
SELECT subject, from_email, date FROM emails WHERE category = 'RPT_WEEK';
```

---

## 搜索语法

| 技巧 | 示例 |
|------|------|
| 关键词 | `合同` `报销` |
| 短语 | `"会议通知"` `"项目验收"` |
| 分类过滤 | `--category RPT_WEEK` |
| 日期范围 | `--date-from 2022-01-01 --date-to 2022-12-31` |
| 发件人 | `--from zhangsan` |

---

## 故障排查

**导入失败**
- 检查 .eml 文件是否损坏
- 查看 `parse_error` 字段了解具体错误

**搜索无结果**
- 确认已运行导入流程
- 检查数据库路径是否正确

**中文乱码**
- .eml 文件本身编码问题，脚本已做 UTF-8 兼容处理

**增量导入不生效**
- 检查文件路径是否变化（移动文件夹会导致重新导入）
