#!/bin/bash
# 美妆AI营销调研Agent启动脚本

# 进入技能目录
cd ~/.hermes/skills/beauty_marketing_ai

# 加载调研提示词
export HERMES_PROMPT=$(cat prompt/interview_prompt.txt)

# 启动主Agent
hermes run --skill . --context "启动美妆企业AI营销自动化调研，按8大模块执行访谈与方案生成"

echo "美妆AI营销调研Agent已启动，输入/help查看交互指令"