# Query Playbook

## Mode selection

- `search`: concrete asset list
- `host`: one IP or one domain, deeper profile
- `stats`: rankings, distributions, and aggregates
- `icon-hash`: derive an `icon_hash` query from a website

## Safe baseline fields

Use these first unless the user explicitly needs something richer:

`host,ip,port,protocol,title,domain,country_name,server`

This skill's helper script falls back to that set when FOFA rejects a higher-tier field request.

## Advanced field reminders

Field availability depends on FOFA plan level. Practical guidance:

- broadly safe: `host`, `ip`, `port`, `protocol`, `title`, `domain`, `server`, `country_name`, `asn`, `org`
- often restricted to higher tiers: `product`, `lastupdatetime`, `body`, `icon_hash`, `fid`, deep certificate fields

If FOFA rejects a query because of field permissions:

1. rerun with the safe baseline
2. preserve the original query
3. explain that the field set, not necessarily the query logic, caused the downgrade

## Query construction patterns

### Asset list

- `app="HIKVISION-Video Surveillance"`
- `app="ThinkPHP" && country="CN"`
- `(app="seeyon" || app="yonyou") && region="Beijing"`
- `protocol="mysql" && country="US"`

### Login and panel hunting

- `title="login"`
- `body="admin"`
- `(title="login" || body="signin") && protocol="http"`

### Certificate and organization pivots

- `cert="google"`
- `cert.subject.org="Google"`
- `org="Cloudflare"`

### Icon-based pivots

1. compute the favicon hash with the helper script
2. use the returned `fofa_query`

## Zero-result retry heuristics

When a search fails, do not only repeat it. Broaden it intentionally:

1. remove the narrowest geographic or version filter
2. replace exact host assumptions with broader content or product fingerprints
3. reduce a multi-clause query to the most distinctive signal
4. if a guessed domain suffix fails, try a broader keyword-based query instead

Example progression:

- strict: `app="Redis" && country="US" && city="Seattle"`
- broader: `app="Redis" && country="US"`
- broader: `protocol="redis" && country="US"`
- fallback: `title="Redis"`

## Host profiling cues

Use `host` mode when the user provides one IP or domain and wants:

- open ports
- ASN and organization
- country or geography
- product hints on discovered services

Prefer `host` mode over `search` when the target is singular.

## Stats guidance

Use `stats` when the user asks for:

- country distribution
- port distribution
- top titles
- ASN or organization rankings

Good fields:

- `country`
- `port`
- `title`
- `org`
- `asn`
- `server`

## Follow-up triage suggestions

After reviewing the FOFA data, you can suggest next steps. Keep passive findings and active checks separate.

Examples:

- Spring or Java patterns: suggest `nuclei` tags such as `spring`, `java`, or targeted CVE templates
- WebLogic or JBoss patterns: suggest `weblogic` or `jboss`
- ThinkPHP patterns: suggest `thinkphp`
- Exchange or OA patterns: suggest `exchange` or `oa`

Only recommend active validation when the user has asked for it or agreed to it.
