# Setup

## Required environment variables

- `FOFA_EMAIL`
- `FOFA_API_KEY`

## Optional environment variables

- `FOFA_BASE_URL`
  Default: `https://fofa.info`
- `FOFA_TIMEOUT`
  Default: `60`

## Basic checks

```bash
export FOFA_EMAIL="you@example.com"
export FOFA_API_KEY="your_fofa_key"
python3 scripts/fofa_recon.py login
```

## Common commands

```bash
python3 scripts/fofa_recon.py search --query 'app="nginx" && country="US"'
python3 scripts/fofa_recon.py search --query 'app="nginx" && country="US"' --alive-check --output nginx_us.xlsx
python3 scripts/fofa_recon.py search --query 'body="login"' --fields host,ip,port,title,server
python3 scripts/fofa_recon.py host --target 1.1.1.1
python3 scripts/fofa_recon.py host --target 1.1.1.1 --report-output host_report.md
python3 scripts/fofa_recon.py stats --query 'app="Redis"' --fields country,port,org
python3 scripts/fofa_recon.py stats --query 'app="Redis"' --fields country,port,org --report-output stats_report.md
python3 scripts/fofa_recon.py alive-check --target example.com --target 1.1.1.1:8443 --output alive.csv
python3 scripts/fofa_recon.py project-run --query 'app="nginx" && country="US"' --query 'app="grafana" && country="US"' --alive-check --split-exports
python3 scripts/fofa_recon.py project-run --query-file queries.txt --alive-check --run-nuclei
python3 scripts/fofa_recon.py icon-hash --url https://example.com
```

## Notes

- The helper prints JSON so it can be consumed directly by an agent.
- FOFA account tier affects which response fields are allowed.
- Search retries should broaden query logic before increasing result volume.
- Treat FOFA results as indexed intelligence, not live confirmation.
- `search --alive-check` adds live web reachability to the result set and can export that handoff directly.
- `--output` supports `csv` and `xlsx`.
- `project-run` creates a project directory with merged exports, per-query exports when requested, `targets.txt`, a Markdown report, and a suggested Nuclei command.
- `host --report-output` and `stats --report-output` generate analyst-friendly Markdown deliverables.
- `project-run --run-nuclei` and `nuclei-run` should only be used on authorized targets.
