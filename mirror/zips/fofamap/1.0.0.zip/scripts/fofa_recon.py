#!/usr/bin/env python3
"""
Deterministic FOFA helper for the fofamap skill.

Environment:
  Required:
    FOFA_EMAIL
    FOFA_API_KEY
  Optional:
    FOFA_BASE_URL   default: https://fofa.info
    FOFA_TIMEOUT    default: 60

Network access:
  - FOFA API endpoints under FOFA_BASE_URL
  - target hosts when using icon-hash or alive-check

Local files:
  - optional CSV/XLSX exports
  - optional project output directories
  - optional Markdown reports and targets lists
"""

from __future__ import annotations

import argparse
import base64
import csv
import datetime as dt
import json
import os
import re
import shlex
import shutil
import ssl
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Dict, Iterable, List, Sequence
from xml.sax.saxutils import escape as xml_escape


SAFE_FIELDS = "host,ip,port,protocol,title,domain,country_name,server"
DEFAULT_ALIVE_CONCURRENCY = 20
DEFAULT_RESULTS_DIR = "results"

HIGH_RISK_PORTS = {
    "22": "SSH exposure can invite password spraying or key abuse.",
    "445": "SMB exposure often deserves urgent validation.",
    "1433": "MSSQL exposure may allow brute force or weak-service review.",
    "1521": "Oracle listener exposure is worth immediate review.",
    "3306": "MySQL exposure should be reviewed for unintended internet reachability.",
    "3389": "RDP exposure is a classic high-risk entry point.",
    "5432": "PostgreSQL exposure often indicates database services on the edge.",
    "6379": "Redis exposure is frequently tied to weak or absent auth.",
    "7001": "WebLogic administrative exposure deserves high attention.",
    "8080": "Alternate web management ports often hide admin panels.",
    "8443": "Alternate HTTPS management ports often hide admin surfaces.",
    "9200": "Elasticsearch exposure can leak operational data.",
    "27017": "MongoDB exposure can indicate poor access control.",
}

NUCLEI_RULES = [
    (["spring", "springboot", "spring boot"], ["spring", "java"], "Spring-related signals detected."),
    (["shiro"], ["shiro", "java"], "Shiro-related signals detected."),
    (["weblogic"], ["weblogic", "java"], "WebLogic indicators detected."),
    (["jboss", "wildfly"], ["jboss", "java"], "JBoss or WildFly indicators detected."),
    (["thinkphp"], ["thinkphp"], "ThinkPHP indicators detected."),
    (["laravel"], ["laravel", "php"], "Laravel indicators detected."),
    (["exchange", "owa", "outlook web app"], ["exchange"], "Exchange or OWA indicators detected."),
    (["seeyon", "致远"], ["oa", "seeyon"], "Seeyon OA indicators detected."),
    (["tongda", "通达"], ["oa", "tongda"], "Tongda OA indicators detected."),
    (["yonyou", "用友"], ["oa", "yonyou"], "Yonyou indicators detected."),
    (["redis"], ["redis"], "Redis indicators detected."),
    (["grafana"], ["grafana"], "Grafana indicators detected."),
    (["jenkins"], ["jenkins"], "Jenkins indicators detected."),
]


def get_env(name: str, required: bool = True, default: str | None = None) -> str:
    value = os.environ.get(name, default)
    if required and not value:
        raise SystemExit(
            json.dumps(
                {
                    "ok": False,
                    "error": f"missing environment variable: {name}",
                },
                ensure_ascii=False,
            )
        )
    return value or ""


def json_print(payload: Dict[str, Any], exit_code: int = 0) -> None:
    sys.stdout.write(json.dumps(payload, ensure_ascii=False, indent=2))
    sys.stdout.write("\n")
    raise SystemExit(exit_code)


def api_config() -> tuple[str, str, str, int]:
    base_url = get_env("FOFA_BASE_URL", required=False, default="https://fofa.info").rstrip("/")
    email = get_env("FOFA_EMAIL")
    api_key = get_env("FOFA_API_KEY")
    timeout_raw = get_env("FOFA_TIMEOUT", required=False, default="60")
    try:
        timeout = int(timeout_raw)
    except ValueError:
        timeout = 60
    return base_url, email, api_key, timeout


def request_json(path: str, params: Dict[str, Any], retries: int = 3) -> Dict[str, Any]:
    base_url, email, api_key, timeout = api_config()
    merged = {"email": email, "key": api_key}
    merged.update(params)
    url = f"{base_url}{path}?{urllib.parse.urlencode(merged)}"
    headers = {"User-Agent": "fofamap-skill/2.0"}

    for attempt in range(1, retries + 1):
        request = urllib.request.Request(url, headers=headers)
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                return json.loads(response.read().decode("utf-8", errors="replace"))
        except urllib.error.HTTPError as exc:
            if exc.code == 429 and attempt < retries:
                time.sleep(2)
                continue
            body = exc.read().decode("utf-8", errors="replace")
            return {"error": True, "errmsg": body or f"http error {exc.code}", "status_code": exc.code}
        except urllib.error.URLError as exc:
            if attempt < retries:
                time.sleep(1)
                continue
            return {"error": True, "errmsg": str(exc.reason)}
        except Exception as exc:  # pragma: no cover - defensive
            if attempt < retries:
                time.sleep(1)
                continue
            return {"error": True, "errmsg": str(exc)}

    return {"error": True, "errmsg": "request failed"}


def field_names(fields_str: str) -> List[str]:
    return [part.strip() for part in str(fields_str).split(",") if part.strip()]


def normalize_row(row: Any, expected_count: int) -> List[str]:
    if isinstance(row, (list, tuple)):
        values = list(row)
    else:
        values = [row]
    normalized = ["" if value is None else str(value) for value in values]
    if len(normalized) < expected_count:
        normalized.extend([""] * (expected_count - len(normalized)))
    return normalized[:expected_count]


def build_row_mapping(row: Any, fields_str: str) -> Dict[str, str]:
    names = field_names(fields_str)
    values = normalize_row(row, len(names))
    return {names[index]: values[index] for index in range(len(names))}


def default_scheme_for_port(port: str) -> str:
    return "https" if str(port) in {"443", "8443"} else "http"


def normalize_url(raw: str) -> str:
    if raw.startswith("http://") or raw.startswith("https://"):
        return raw
    return f"http://{raw}"


def slugify(value: str, fallback: str = "fofa_task", limit: int = 40) -> str:
    text = re.sub(r"[^\w\-]+", "_", str(value)).strip("_")
    text = re.sub(r"_+", "_", text)
    text = text[:limit].strip("_")
    return text or fallback


def parse_csv_values(raw: str | None, lower: bool = False) -> List[str]:
    if not raw:
        return []
    values = [part.strip() for part in str(raw).split(",") if part.strip()]
    if lower:
        return [value.lower() for value in values]
    return values


def ordered_unique(values: Iterable[str]) -> List[str]:
    seen: set[str] = set()
    ordered: List[str] = []
    for value in values:
        if value not in seen:
            seen.add(value)
            ordered.append(value)
    return ordered


def build_target_from_row(row: Any, fields_str: str) -> str | None:
    mapped = build_row_mapping(row, fields_str)
    host = mapped.get("host") or mapped.get("link") or mapped.get("domain") or mapped.get("ip")
    if not host:
        return None

    if host.startswith("http://") or host.startswith("https://"):
        return host

    protocol = mapped.get("protocol") or mapped.get("base_protocol")
    port = mapped.get("port", "")
    scheme = protocol if protocol in {"http", "https"} else default_scheme_for_port(port)

    parsed = urllib.parse.urlsplit(f"//{host}")
    host_has_port = parsed.port is not None
    netloc = host
    if port and not host_has_port:
        netloc = f"{host}:{port}"
    return f"{scheme}://{netloc}"


def collect_targets(rows: Iterable[Any], fields_str: str) -> List[str]:
    return ordered_unique(
        target
        for target in (build_target_from_row(row, fields_str) for row in rows)
        if target
    )


def candidate_probe_urls(target: str) -> List[str]:
    target = target.strip()
    if not target:
        return []
    if target.startswith("http://") or target.startswith("https://"):
        return [target]
    return [f"https://{target}", f"http://{target}"]


def probe_once(url: str, timeout: int) -> str:
    context = ssl._create_unverified_context()
    headers = {"User-Agent": "fofamap-skill/2.0"}

    last_error = "error"
    for method in ("HEAD", "GET"):
        request = urllib.request.Request(url, headers=headers, method=method)
        try:
            with urllib.request.urlopen(request, timeout=timeout, context=context) as response:
                return str(response.getcode())
        except urllib.error.HTTPError as exc:
            return str(exc.code)
        except urllib.error.URLError as exc:
            last_error = str(exc.reason)
        except Exception as exc:  # pragma: no cover - defensive
            last_error = str(exc)
    return last_error


def probe_target(target: str, timeout: int) -> Dict[str, str]:
    last_status = "error"
    for url in candidate_probe_urls(target):
        status = probe_once(url, timeout=timeout)
        if status.isdigit():
            return {"target": target, "url": url, "status": status}
        last_status = status
    probe_urls = candidate_probe_urls(target)
    return {"target": target, "url": probe_urls[0] if probe_urls else target, "status": last_status}


def check_targets_alive(targets: List[str], timeout: int, concurrency: int) -> List[Dict[str, str]]:
    if not targets:
        return []
    ordered_targets = ordered_unique(targets)
    results: Dict[str, Dict[str, str]] = {}
    with ThreadPoolExecutor(max_workers=max(1, concurrency)) as executor:
        future_map = {
            executor.submit(probe_target, target, timeout): target
            for target in ordered_targets
        }
        for future in as_completed(future_map):
            result = future.result()
            results[result["target"]] = result
    return [results[target] for target in ordered_targets if target in results]


def is_alive_status(status: str) -> bool:
    return str(status).isdigit()


def load_targets_from_file(path: str) -> List[str]:
    lines = Path(path).read_text(encoding="utf-8", errors="replace").splitlines()
    return [line.strip() for line in lines if line.strip()]


def timestamp_slug() -> str:
    return dt.datetime.now().strftime("%Y%m%d_%H%M%S")


def resolve_export_format(output: str | None, export_format: str | None) -> str:
    if export_format:
        fmt = export_format.lower().strip(".")
    elif output and Path(output).suffix.lower() in {".csv", ".xlsx"}:
        fmt = Path(output).suffix.lower().lstrip(".")
    else:
        fmt = "xlsx"

    if fmt not in {"csv", "xlsx"}:
        raise ValueError("export format must be csv or xlsx")
    return fmt


def resolve_export_path(output: str | None, export_format: str | None, prefix: str) -> Path:
    fmt = resolve_export_format(output, export_format)
    if output:
        path = Path(output).expanduser()
        if path.suffix.lower() != f".{fmt}":
            path = path.with_suffix(f".{fmt}")
    else:
        path = Path.cwd() / f"{prefix}_{timestamp_slug()}.{fmt}"
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def sanitize_sheet_name(name: str) -> str:
    cleaned = re.sub(r"[\[\]:*?/\\]", "_", name).strip()
    cleaned = cleaned[:31] or "Sheet1"
    return cleaned


def make_unique_sheet_names(names: Sequence[str]) -> List[str]:
    used: set[str] = set()
    output: List[str] = []
    for raw in names:
        base = sanitize_sheet_name(raw)
        candidate = base
        counter = 2
        while candidate in used:
            suffix = f"_{counter}"
            candidate = sanitize_sheet_name(f"{base[: 31 - len(suffix)]}{suffix}")
            counter += 1
        used.add(candidate)
        output.append(candidate)
    return output


def write_csv_export(path: Path, headers: List[str], rows: List[List[str]]) -> None:
    with open(path, "w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(headers)
        writer.writerows(rows)


def excel_column_name(index: int) -> str:
    result = ""
    while index > 0:
        index, remainder = divmod(index - 1, 26)
        result = chr(65 + remainder) + result
    return result


def build_sheet_xml(headers: List[str], rows: List[List[str]]) -> str:
    all_rows = [headers] + rows
    xml_rows: List[str] = []
    for row_index, row in enumerate(all_rows, start=1):
        cells: List[str] = []
        for column_index, cell in enumerate(row, start=1):
            ref = f"{excel_column_name(column_index)}{row_index}"
            value = "" if cell is None else str(cell)
            cells.append(
                f'<c r="{ref}" t="inlineStr"><is><t xml:space="preserve">{xml_escape(value)}</t></is></c>'
            )
        xml_rows.append(f'<row r="{row_index}">{"".join(cells)}</row>')

    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        "<sheetData>"
        f'{"".join(xml_rows)}'
        "</sheetData>"
        "</worksheet>"
    )


def write_xlsx_workbook(path: Path, sheets: List[Dict[str, Any]]) -> None:
    created = dt.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"
    unique_names = make_unique_sheet_names([sheet["name"] for sheet in sheets])

    overrides = [
        '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>',
        '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>',
        '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>',
    ]
    workbook_sheet_entries: List[str] = []
    workbook_relationships: List[str] = []

    for index, name in enumerate(unique_names, start=1):
        overrides.append(
            f'<Override PartName="/xl/worksheets/sheet{index}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
        )
        workbook_sheet_entries.append(
            f'<sheet name="{xml_escape(name)}" sheetId="{index}" r:id="rId{index}"/>'
        )
        workbook_relationships.append(
            f'<Relationship Id="rId{index}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{index}.xml"/>'
        )

    content_types = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        '<Default Extension="xml" ContentType="application/xml"/>'
        f'{"".join(overrides)}'
        "</Types>"
    )
    root_rels = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
        '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>'
        '<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>'
        "</Relationships>"
    )
    workbook = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        "<sheets>"
        f'{"".join(workbook_sheet_entries)}'
        "</sheets>"
        "</workbook>"
    )
    workbook_rels = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        f'{"".join(workbook_relationships)}'
        "</Relationships>"
    )
    core = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
        'xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" '
        'xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
        '<dc:creator>fofamap</dc:creator>'
        '<cp:lastModifiedBy>fofamap</cp:lastModifiedBy>'
        f'<dcterms:created xsi:type="dcterms:W3CDTF">{created}</dcterms:created>'
        f'<dcterms:modified xsi:type="dcterms:W3CDTF">{created}</dcterms:modified>'
        "</cp:coreProperties>"
    )
    app = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" '
        'xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">'
        "<Application>fofamap</Application>"
        "</Properties>"
    )

    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("[Content_Types].xml", content_types)
        archive.writestr("_rels/.rels", root_rels)
        archive.writestr("xl/workbook.xml", workbook)
        archive.writestr("xl/_rels/workbook.xml.rels", workbook_rels)
        archive.writestr("docProps/core.xml", core)
        archive.writestr("docProps/app.xml", app)

        for index, sheet in enumerate(sheets, start=1):
            archive.writestr(
                f"xl/worksheets/sheet{index}.xml",
                build_sheet_xml(sheet["headers"], sheet["rows"]),
            )


def write_export(
    output: str | None,
    export_format: str | None,
    prefix: str,
    headers: List[str],
    rows: List[List[str]],
    sheet_name: str,
) -> str:
    path = resolve_export_path(output, export_format, prefix)
    fmt = path.suffix.lower().lstrip(".")
    if fmt == "csv":
        write_csv_export(path, headers, rows)
    else:
        write_xlsx_workbook(path, [{"name": sheet_name, "headers": headers, "rows": rows}])
    return str(path)


def write_multi_export(
    output: str | None,
    export_format: str | None,
    prefix: str,
    sheets: List[Dict[str, Any]],
    csv_headers: List[str],
    csv_rows: List[List[str]],
) -> str:
    path = resolve_export_path(output, export_format, prefix)
    fmt = path.suffix.lower().lstrip(".")
    if fmt == "csv":
        write_csv_export(path, csv_headers, csv_rows)
    else:
        write_xlsx_workbook(path, sheets)
    return str(path)


def write_text_file(path: Path, content: str) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return str(path)


def results_to_objects(
    rows: List[Any],
    fields_str: str,
    alive_by_target: Dict[str, str] | None = None,
) -> List[Dict[str, str]]:
    names = field_names(fields_str)
    objects: List[Dict[str, str]] = []
    for row in rows:
        mapped = build_row_mapping(row, fields_str)
        target = build_target_from_row(row, fields_str)
        if target:
            mapped["target"] = target
        if alive_by_target is not None and target:
            mapped["http_status"] = alive_by_target.get(target, "")
        objects.append(mapped)
    return objects


def object_text_blob(item: Dict[str, Any]) -> str:
    return " ".join(str(value) for value in item.values() if value).lower()


def matches_keywords(item: Dict[str, Any], keywords: List[str]) -> bool:
    if not keywords:
        return True
    blob = object_text_blob(item)
    return any(keyword in blob for keyword in keywords)


def apply_result_filters(
    rows: List[Any],
    fields_str: str,
    alive_by_target: Dict[str, str] | None = None,
    keyword: str | None = None,
    include_status: str | None = None,
    only_alive: bool = False,
) -> tuple[List[List[str]], List[Dict[str, str]]]:
    keywords = parse_csv_values(keyword, lower=True)
    allowed_status = set(parse_csv_values(include_status))
    filtered_rows: List[List[str]] = []
    filtered_objects: List[Dict[str, str]] = []
    expected_count = len(field_names(fields_str))

    for row in rows:
        normalized = normalize_row(row, expected_count)
        item = build_row_mapping(normalized, fields_str)
        target = build_target_from_row(normalized, fields_str)
        if target:
            item["target"] = target
        status = alive_by_target.get(target, "") if alive_by_target and target else ""
        if alive_by_target is not None and target:
            item["http_status"] = status
        if not matches_keywords(item, keywords):
            continue
        if only_alive and not is_alive_status(status):
            continue
        if allowed_status and status not in allowed_status:
            continue
        filtered_rows.append(normalized)
        filtered_objects.append(item)

    return filtered_rows, filtered_objects


def search_page(
    query: str,
    requested_fields: str,
    page: int,
    size: int,
    full: bool,
) -> Dict[str, Any]:
    query_b64 = base64.b64encode(query.encode("utf-8")).decode("ascii")
    params = {
        "qbase64": query_b64,
        "fields": requested_fields,
        "page": page,
        "size": size,
        "full": str(full).lower(),
    }
    data = request_json("/api/v1/search/all", params)
    used_fields = requested_fields
    error_text = str(data.get("errmsg", ""))
    permission_error = data.get("error") and ("820001" in error_text or "权限" in error_text)
    if permission_error and requested_fields != SAFE_FIELDS:
        params["fields"] = SAFE_FIELDS
        used_fields = SAFE_FIELDS
        data = request_json("/api/v1/search/all", params)

    ok = not data.get("error")
    return {
        "ok": ok,
        "query": query,
        "page": page,
        "requested_fields": requested_fields,
        "used_fields": used_fields,
        "data": data,
    }


def search_query_workflow(
    query: str,
    requested_fields: str,
    pages: int,
    size: int,
    full: bool,
    alive_check: bool = False,
    alive_timeout: int = 5,
    alive_concurrency: int = DEFAULT_ALIVE_CONCURRENCY,
    keyword: str | None = None,
    include_status: str | None = None,
    only_alive: bool = False,
) -> Dict[str, Any]:
    raw_results: List[List[str]] = []
    last_data: Dict[str, Any] | None = None
    used_fields = requested_fields

    for page in range(1, max(1, pages) + 1):
        page_payload = search_page(query, used_fields, page, size, full)
        if not page_payload["ok"]:
            return {
                "ok": False,
                "mode": "search",
                "query": query,
                "requested_fields": requested_fields,
                "used_fields": page_payload["used_fields"],
                "page": page,
                "size": size,
                "full": full,
                "data": page_payload["data"],
            }
        used_fields = page_payload["used_fields"]
        data = page_payload["data"]
        last_data = data
        page_results = data.get("results", []) or []
        if not page_results:
            break
        for item in page_results:
            raw_results.append(normalize_row(item, len(field_names(used_fields))))

    targets = collect_targets(raw_results, used_fields)
    alive_entries: List[Dict[str, str]] = []
    alive_by_target: Dict[str, str] | None = None
    if alive_check and targets:
        alive_entries = check_targets_alive(targets, timeout=alive_timeout, concurrency=alive_concurrency)
        alive_by_target = {entry["target"]: entry["status"] for entry in alive_entries}

    filtered_rows, filtered_objects = apply_result_filters(
        rows=raw_results,
        fields_str=used_fields,
        alive_by_target=alive_by_target,
        keyword=keyword,
        include_status=include_status,
        only_alive=only_alive,
    )

    alive_summary = None
    if alive_check:
        alive_count = sum(1 for entry in alive_entries if is_alive_status(entry["status"]))
        alive_summary = {
            "alive_count": alive_count,
            "checked_count": len(alive_entries),
            "requested_count": len(targets),
        }

    filtered_data = dict(last_data or {})
    filtered_data["results"] = filtered_rows

    return {
        "ok": True,
        "mode": "search",
        "query": query,
        "requested_fields": requested_fields,
        "used_fields": used_fields,
        "pages": pages,
        "size": size,
        "full": full,
        "raw_result_count": len(raw_results),
        "result_count": len(filtered_rows),
        "target_count": len(ordered_unique(item.get("target", "") for item in filtered_objects if item.get("target"))),
        "alive_summary": alive_summary,
        "alive_results": alive_entries,
        "data": filtered_data,
        "result_objects": filtered_objects,
    }


def port_int(port: str) -> int:
    try:
        return int(str(port))
    except Exception:
        return -1


def top_counts(values: Iterable[str], limit: int = 5) -> List[tuple[str, int]]:
    counter = Counter(value for value in values if value)
    return counter.most_common(limit)


def unique_nonempty(values: Iterable[str]) -> List[str]:
    return ordered_unique(value for value in values if value)


def detect_nuclei_suggestion(result_objects: List[Dict[str, str]], user_intent: str = "") -> Dict[str, Any]:
    text_blob = " ".join(object_text_blob(item) for item in result_objects).lower()
    intent_blob = user_intent.lower()

    tags: List[str] = []
    reasons: List[str] = []
    for keywords, rule_tags, reason in NUCLEI_RULES:
        if any(keyword in text_blob or keyword in intent_blob for keyword in keywords):
            for tag in rule_tags:
                if tag not in tags:
                    tags.append(tag)
            if reason not in reasons:
                reasons.append(reason)

    cve_ids: List[str] = []
    if "log4j" in intent_blob or "cve-2021-44228" in intent_blob:
        if "log4j" not in tags:
            tags.append("log4j")
        cve_ids.append("CVE-2021-44228")
        reasons.append("User intent explicitly mentions Log4Shell or CVE-2021-44228.")

    target_count = len(unique_nonempty(item.get("target", "") for item in result_objects))
    if target_count <= 25:
        severity = "critical,high"
        perf_args = ["-bs", "25", "-rl", "150"]
    elif target_count <= 100:
        severity = "critical,high,medium"
        perf_args = ["-bs", "50", "-rl", "100"]
    else:
        severity = "critical,high,medium"
        perf_args = ["-rl", "50"]

    broad_mode = not tags or target_count > 100
    if not tags:
        tags = ["cves", "misconfig"]
        reasons.append("No strong framework signature detected, so broad CVE and misconfiguration coverage is suggested.")

    parts = ["nuclei", "-l", "targets.txt", "-stats", "-severity", severity]
    if broad_mode:
        parts.append("-as")
    if cve_ids:
        parts.extend(["-id", ",".join(cve_ids)])
    if tags:
        parts.extend(["-tags", ",".join(ordered_unique(tags))])
    parts.extend(perf_args)

    return {
        "target_count": target_count,
        "severity": severity,
        "tags": ordered_unique(tags),
        "cve_ids": cve_ids,
        "broad_mode": broad_mode,
        "reasons": ordered_unique(reasons),
        "args": " ".join(parts[3:]),
        "command": " ".join(parts),
    }


def markdown_table(headers: List[str], rows: List[List[str]]) -> str:
    if not rows:
        return ""
    clean_headers = [str(header).replace("|", "\\|") for header in headers]
    out = ["| " + " | ".join(clean_headers) + " |", "| " + " | ".join(["---"] * len(headers)) + " |"]
    for row in rows:
        clean_row = [str(value).replace("|", "\\|").replace("\n", " ") for value in row]
        out.append("| " + " | ".join(clean_row) + " |")
    return "\n".join(out)


def build_asset_report(
    project_name: str,
    query_summaries: List[Dict[str, Any]],
    result_objects: List[Dict[str, str]],
    user_intent: str,
    nuclei_suggestion: Dict[str, Any] | None,
    output_files: Dict[str, str],
    nuclei_log_summary: Dict[str, int] | None = None,
) -> str:
    date_str = dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    total_assets = len(result_objects)
    unique_targets_count = len(unique_nonempty(item.get("target", "") for item in result_objects))
    unique_ips_count = len(unique_nonempty(item.get("ip", "") for item in result_objects))
    alive_count = sum(1 for item in result_objects if is_alive_status(item.get("http_status", "")))

    top_ports = top_counts((item.get("port", "") for item in result_objects), limit=5)
    top_servers = top_counts((item.get("server", "") for item in result_objects), limit=5)
    top_countries = top_counts((item.get("country_name", "") for item in result_objects), limit=5)
    top_titles = top_counts((item.get("title", "") for item in result_objects if item.get("title")), limit=5)

    risky_ports = ordered_unique(
        port for port in (item.get("port", "") for item in result_objects) if port in HIGH_RISK_PORTS
    )

    lines = [
        "# FOFAMAP Asset Exposure Report",
        "",
        f"- Project: `{project_name}`",
        f"- Generated: `{date_str}`",
        f"- User Intent: {user_intent or 'FOFA asset reconnaissance'}",
        f"- Queries Executed: `{len(query_summaries)}`",
        f"- Asset Rows: `{total_assets}`",
        f"- Unique Targets: `{unique_targets_count}`",
        f"- Unique IPs: `{unique_ips_count}`",
    ]
    if alive_count:
        lines.append(f"- Live HTTP Targets: `{alive_count}`")

    lines.extend(
        [
            "",
            "## Exposure Snapshot",
            "",
            "- This report preserves the original project's operator-first style: collect assets, keep what is actionable, and prepare the next step.",
        ]
    )

    if risky_ports:
        lines.append(f"- Notable exposed ports: `{', '.join(risky_ports)}`")
        for port in risky_ports[:5]:
            lines.append(f"  - Port `{port}`: {HIGH_RISK_PORTS.get(port, 'Review exposure.')}")
    else:
        lines.append("- No obviously high-signal management or database port stood out in the filtered result set.")

    if top_servers:
        lines.append("")
        lines.append("## Stack Signals")
        lines.append("")
        for name, count in top_servers:
            lines.append(f"- `{name}`: `{count}` rows")

    if top_countries:
        lines.append("")
        lines.append("## Geographic Distribution")
        lines.append("")
        for name, count in top_countries:
            lines.append(f"- `{name}`: `{count}` rows")

    if top_ports:
        lines.append("")
        lines.append("## Port Distribution")
        lines.append("")
        for name, count in top_ports:
            lines.append(f"- Port `{name}`: `{count}` rows")

    if nuclei_suggestion:
        lines.extend(
            [
                "",
                "## Suggested Nuclei Follow-up",
                "",
                "```bash",
                nuclei_suggestion["command"],
                "```",
            ]
        )
        if nuclei_suggestion.get("reasons"):
            for reason in nuclei_suggestion["reasons"]:
                lines.append(f"- {reason}")

    if nuclei_log_summary:
        lines.extend(
            [
                "",
                "## Nuclei Log Summary",
                "",
                f"- Critical: `{nuclei_log_summary.get('critical', 0)}`",
                f"- High: `{nuclei_log_summary.get('high', 0)}`",
                f"- Medium: `{nuclei_log_summary.get('medium', 0)}`",
                f"- Low: `{nuclei_log_summary.get('low', 0)}`",
                f"- Info: `{nuclei_log_summary.get('info', 0)}`",
            ]
        )

    if top_titles:
        lines.extend(["", "## Sample Titles", ""])
        for name, count in top_titles[:5]:
            lines.append(f"- `{name}`: `{count}` rows")

    lines.extend(["", "## Query Appendix", ""])
    appendix_rows: List[List[str]] = []
    for item in query_summaries:
        appendix_rows.append(
            [
                item.get("query", ""),
                item.get("used_fields", ""),
                str(item.get("result_count", 0)),
            ]
        )
    if appendix_rows:
        lines.append(markdown_table(["Query", "Used Fields", "Rows"], appendix_rows))

    lines.extend(["", "## Output Files", ""])
    for label, path in output_files.items():
        lines.append(f"- `{label}`: `{path}`")

    sample_rows: List[List[str]] = []
    for item in result_objects[:10]:
        sample_rows.append(
            [
                item.get("host") or item.get("target") or item.get("ip", ""),
                item.get("ip", ""),
                item.get("port", ""),
                item.get("title", ""),
                item.get("http_status", ""),
            ]
        )
    if sample_rows:
        lines.extend(["", "## Asset Sample", "", markdown_table(["Host", "IP", "Port", "Title", "HTTP Status"], sample_rows)])

    return "\n".join(lines).strip() + "\n"


def build_host_report(target: str, host_data: Dict[str, Any], user_intent: str = "") -> str:
    ports = sorted(host_data.get("ports", []), key=lambda item: item.get("port", 0))
    products: List[str] = []
    port_numbers: List[str] = []
    for item in ports:
        port_numbers.append(str(item.get("port", "")))
        for product in item.get("products", []) or []:
            name = str(product.get("product", "")).strip()
            if name:
                products.append(name)

    score = 0
    for port in port_numbers:
        if port in {"3389", "445", "6379", "7001", "1433"}:
            score += 3
        elif port in {"22", "3306", "5432", "8080", "8443"}:
            score += 1
    product_blob = " ".join(products).lower()
    for keywords, _, _ in NUCLEI_RULES:
        if any(keyword in product_blob for keyword in keywords):
            score += 2
            break
    if len(ports) >= 5:
        score += 1

    if score >= 6:
        risk_level = "High"
    elif score >= 3:
        risk_level = "Medium"
    else:
        risk_level = "Low"

    attack_paths: List[str] = []
    for port in port_numbers:
        if port in HIGH_RISK_PORTS:
            attack_paths.append(f"Port `{port}`: {HIGH_RISK_PORTS[port]}")
    if "weblogic" in product_blob:
        attack_paths.append("Validate WebLogic-specific exposures and admin interfaces.")
    if "redis" in product_blob or "6379" in port_numbers:
        attack_paths.append("Check for weak or absent Redis authentication and unsafe exposure.")
    if "exchange" in product_blob:
        attack_paths.append("Review Exchange-specific surface such as OWA or legacy endpoints.")
    if not attack_paths:
        attack_paths.append("Prioritize reachable web services and identify whether any exposed service is administrative.")

    appendix_rows: List[List[str]] = []
    for item in ports:
        product_list = [str(product.get("product", "")).strip() for product in item.get("products", []) or []]
        appendix_rows.append(
            [
                str(item.get("port", "")),
                str(item.get("protocol", "")),
                ", ".join([name for name in product_list if name])[:120],
                str(item.get("update_time", "")).split(" ")[0],
            ]
        )

    lines = [
        "# FOFAMAP Host Risk Report",
        "",
        f"- Target: `{target}`",
        f"- User Intent: {user_intent or 'Host profiling'}",
        f"- IP: `{host_data.get('ip', '')}`",
        f"- ASN: `{host_data.get('asn', '')}`",
        f"- Org: `{host_data.get('org', '')}`",
        f"- Country: `{host_data.get('country_name', '')}`",
        f"- Update Time: `{host_data.get('update_time', '')}`",
        "",
        "## Exposure Analysis",
        "",
    ]
    if ports:
        for item in ports:
            port = str(item.get("port", ""))
            protocol = str(item.get("protocol", ""))
            note = HIGH_RISK_PORTS.get(port, "Observed service exposure.")
            lines.append(f"- `{port}/{protocol}`: {note}")
    else:
        lines.append("- FOFA did not return detailed open-port information for this host.")

    lines.extend(["", "## Risk Judgement", "", f"- Overall Risk: `{risk_level}`"])
    if products:
        lines.append(f"- Product Hints: `{', '.join(unique_nonempty(products)[:8])}`")
    else:
        lines.append("- Product fingerprints are limited; confirm service identity with live validation if permitted.")

    lines.extend(["", "## Likely Attack Paths", ""])
    for item in attack_paths[:6]:
        lines.append(f"- {item}")

    if appendix_rows:
        lines.extend(["", "## Raw Port Snapshot", "", markdown_table(["Port", "Protocol", "Products", "Update"], appendix_rows)])

    return "\n".join(lines).strip() + "\n"


def build_stats_report(query: str, stat_data: Dict[str, Any], user_intent: str = "") -> str:
    total = int(stat_data.get("size", 0) or 0)
    aggs = stat_data.get("aggs", {}) or {}
    distinct = stat_data.get("distinct", {}) or {}

    lines = [
        "# FOFAMAP Statistical Trend Report",
        "",
        f"- Query: `{query}`",
        f"- User Intent: {user_intent or 'Statistical distribution analysis'}",
        f"- Total Matches: `{total}`",
        "",
        "## Distribution Traits",
        "",
    ]

    for field_name, items in aggs.items():
        if not items:
            continue
        top = items[0]
        top_name = top.get("name", "")
        top_count = int(top.get("count", 0) or 0)
        ratio = (top_count / total * 100) if total else 0
        lines.append(f"- `{field_name}` is led by `{top_name}` with `{top_count}` records ({ratio:.2f}%).")

    if not aggs:
        lines.append("- FOFA returned no aggregation buckets for the requested dimensions.")

    lines.extend(["", "## Anomaly Notes", ""])
    if "port" in aggs and aggs["port"]:
        unusual_ports = [item.get("name", "") for item in aggs["port"][:5] if item.get("name", "") not in {"80", "443"}]
        if unusual_ports:
            lines.append(f"- Non-default ports appear prominently: `{', '.join(unusual_ports)}`.")
        else:
            lines.append("- Distribution is dominated by standard web ports.")
    else:
        lines.append("- Port distribution data is not present in this query.")

    if distinct:
        lines.extend(["", "## Distinct Counts", ""])
        for key, value in distinct.items():
            lines.append(f"- `{key}`: `{value}`")

    for field_name, items in aggs.items():
        if not items:
            continue
        appendix_rows: List[List[str]] = []
        for item in items[:10]:
            appendix_rows.append(
                [
                    str(item.get("name", "")),
                    str(item.get("count", "")),
                    ", ".join(f"{region.get('name')}({region.get('count')})" for region in (item.get("regions", []) or [])[:3]),
                ]
            )
        lines.extend(["", f"## Top {field_name.upper()}", "", markdown_table(["Name", "Count", "Top Regions"], appendix_rows)])

    return "\n".join(lines).strip() + "\n"


def parse_nuclei_log(path: str | None) -> Dict[str, int] | None:
    if not path:
        return None
    file_path = Path(path).expanduser()
    if not file_path.exists():
        return None
    content = file_path.read_text(encoding="utf-8", errors="ignore").lower()
    return {
        "critical": content.count("[critical]"),
        "high": content.count("[high]"),
        "medium": content.count("[medium]"),
        "low": content.count("[low]"),
        "info": content.count("[info]"),
    }


def build_export_rows(result_objects: List[Dict[str, str]], fields_str: str, include_http_status: bool) -> tuple[List[str], List[List[str]]]:
    names = field_names(fields_str)
    headers = ["ID"] + [name.upper() for name in names]
    if include_http_status:
        headers.append("HTTP_STATUS")
    rows: List[List[str]] = []
    for index, item in enumerate(result_objects, start=1):
        row = [str(index)] + [item.get(name, "") for name in names]
        if include_http_status:
            row.append(item.get("http_status", ""))
        rows.append(row)
    return headers, rows


def build_query_sheet_name(index: int, query: str) -> str:
    return f"{index}_{slugify(query, fallback='query', limit=24)}"


def build_project_dir(project_name: str | None, outdir: str | None, seed_query: str) -> Path:
    if outdir:
        path = Path(outdir).expanduser()
        path.mkdir(parents=True, exist_ok=True)
        return path
    base_name = slugify(project_name or seed_query, fallback="fofa_task", limit=40)
    path = Path.cwd() / DEFAULT_RESULTS_DIR / f"{base_name}_{timestamp_slug()}"
    path.mkdir(parents=True, exist_ok=True)
    return path


def build_targets_file(project_dir: Path, result_objects: List[Dict[str, str]], suffix: str) -> str:
    targets = ordered_unique(item.get("target", "") for item in result_objects if item.get("target"))
    path = project_dir / f"targets_{suffix}.txt"
    path.write_text("\n".join(targets), encoding="utf-8")
    return str(path)


def build_nuclei_command_file(project_dir: Path, suggestion: Dict[str, Any], suffix: str) -> str:
    path = project_dir / f"nuclei_command_{suffix}.txt"
    body = suggestion["command"] + "\n"
    if suggestion.get("reasons"):
        body += "\n# Rationale\n"
        for reason in suggestion["reasons"]:
            body += f"# - {reason}\n"
    return write_text_file(path, body)


def locate_nuclei_binary() -> str | None:
    found = shutil.which("nuclei")
    if found:
        return found
    cwd_candidate = Path.cwd() / "nuclei"
    if cwd_candidate.exists() and cwd_candidate.is_file():
        return str(cwd_candidate)
    exe_candidate = Path.cwd() / "nuclei.exe"
    if exe_candidate.exists() and exe_candidate.is_file():
        return str(exe_candidate)
    return None


def run_nuclei_scan(nuclei_path: str, targets_file: str, extra_args: str, output_file: str) -> Dict[str, Any]:
    cmd = [nuclei_path, "-l", targets_file, "-o", output_file, "-stats"] + shlex.split(extra_args or "")
    completed = subprocess.run(cmd, capture_output=True, text=True)
    summary = parse_nuclei_log(output_file)
    return {
        "ok": completed.returncode == 0 or Path(output_file).exists(),
        "command": " ".join(cmd),
        "returncode": completed.returncode,
        "stdout": completed.stdout[-2000:],
        "stderr": completed.stderr[-2000:],
        "output_file": output_file,
        "summary": summary,
    }


def run_nuclei_update(nuclei_path: str) -> Dict[str, Any]:
    commands = [
        [nuclei_path, "-update"],
        [nuclei_path, "-ut"],
    ]
    results: List[Dict[str, Any]] = []
    ok = True
    for cmd in commands:
        completed = subprocess.run(cmd, capture_output=True, text=True)
        results.append(
            {
                "command": " ".join(cmd),
                "returncode": completed.returncode,
                "stdout": completed.stdout[-2000:],
                "stderr": completed.stderr[-2000:],
            }
        )
        if completed.returncode != 0:
            ok = False
    return {"ok": ok, "steps": results}


def project_csv_union_headers(query_payloads: List[Dict[str, Any]], include_http_status: bool) -> List[str]:
    ordered_fields: List[str] = []
    for payload in query_payloads:
        for field in field_names(payload.get("used_fields", "")):
            if field not in ordered_fields:
                ordered_fields.append(field)
    headers = ["QUERY", "ID"] + [field.upper() for field in ordered_fields]
    if include_http_status:
        headers.append("HTTP_STATUS")
    return headers


def project_csv_rows(query_payloads: List[Dict[str, Any]], include_http_status: bool) -> List[List[str]]:
    ordered_fields: List[str] = []
    for payload in query_payloads:
        for field in field_names(payload.get("used_fields", "")):
            if field not in ordered_fields:
                ordered_fields.append(field)

    rows: List[List[str]] = []
    for payload in query_payloads:
        for index, item in enumerate(payload.get("result_objects", []), start=1):
            row = [payload.get("query", ""), str(index)]
            for field in ordered_fields:
                row.append(item.get(field, ""))
            if include_http_status:
                row.append(item.get("http_status", ""))
            rows.append(row)
    return rows


def handle_login(_: argparse.Namespace) -> None:
    data = request_json("/api/v1/info/my", {})
    ok = not data.get("error")
    json_print({"ok": ok, "mode": "login", "data": data}, 0 if ok else 1)


def handle_search(args: argparse.Namespace) -> None:
    payload = search_query_workflow(
        query=args.query,
        requested_fields=args.fields or SAFE_FIELDS,
        pages=args.pages,
        size=args.size,
        full=args.full,
        alive_check=args.alive_check,
        alive_timeout=args.alive_timeout,
        alive_concurrency=args.alive_concurrency,
        keyword=args.keyword,
        include_status=args.include_status,
        only_alive=args.only_alive,
    )
    if not payload["ok"]:
        json_print(payload, 1)

    exported_to = None
    targets_written_to = None
    report_written_to = None
    nuclei_suggestion = None
    nuclei_command_file = None

    if args.output or args.export_format:
        export_headers, export_rows = build_export_rows(
            result_objects=payload["result_objects"],
            fields_str=payload["used_fields"],
            include_http_status=args.alive_check,
        )
        exported_to = write_export(
            output=args.output,
            export_format=args.export_format,
            prefix="fofa_search",
            headers=export_headers,
            rows=export_rows,
            sheet_name=args.sheet_name or "FOFA Assets",
        )

    if args.targets_output:
        targets = ordered_unique(item.get("target", "") for item in payload["result_objects"] if item.get("target"))
        target_path = Path(args.targets_output).expanduser()
        target_path.parent.mkdir(parents=True, exist_ok=True)
        target_path.write_text("\n".join(targets), encoding="utf-8")
        targets_written_to = str(target_path)

    if args.suggest_nuclei:
        nuclei_suggestion = detect_nuclei_suggestion(payload["result_objects"], user_intent=args.user_intent or args.query)
        if args.nuclei_command_output:
            nuclei_path = Path(args.nuclei_command_output).expanduser()
            nuclei_path.parent.mkdir(parents=True, exist_ok=True)
            nuclei_command_file = write_text_file(nuclei_path, nuclei_suggestion["command"] + "\n")

    if args.report_output:
        output_files: Dict[str, str] = {}
        if exported_to:
            output_files["export"] = exported_to
        if targets_written_to:
            output_files["targets"] = targets_written_to
        if nuclei_command_file:
            output_files["nuclei_command"] = nuclei_command_file
        report_text = build_asset_report(
            project_name=slugify(args.query, fallback="search"),
            query_summaries=[payload],
            result_objects=payload["result_objects"],
            user_intent=args.user_intent or args.query,
            nuclei_suggestion=nuclei_suggestion,
            output_files=output_files,
        )
        report_written_to = write_text_file(Path(args.report_output).expanduser(), report_text)

    payload["exported_to"] = exported_to
    payload["targets_written_to"] = targets_written_to
    payload["report_written_to"] = report_written_to
    payload["nuclei_suggestion"] = nuclei_suggestion
    payload["nuclei_command_file"] = nuclei_command_file
    json_print(payload)


def handle_host(args: argparse.Namespace) -> None:
    data = request_json(f"/api/v1/host/{urllib.parse.quote(args.target)}", {"detail": "true"})
    ok = not data.get("error")
    if not ok:
        json_print({"ok": False, "mode": "host", "target": args.target, "data": data}, 1)

    report_written_to = None
    report_markdown = None
    if args.report_output:
        report_markdown = build_host_report(args.target, data, user_intent=args.user_intent or "")
        report_written_to = write_text_file(Path(args.report_output).expanduser(), report_markdown)

    json_print(
        {
            "ok": True,
            "mode": "host",
            "target": args.target,
            "data": data,
            "report_written_to": report_written_to,
            "report_markdown": report_markdown,
        }
    )


def handle_stats(args: argparse.Namespace) -> None:
    query_b64 = base64.b64encode(args.query.encode("utf-8")).decode("ascii")
    data = request_json("/api/v1/search/stats", {"qbase64": query_b64, "fields": args.fields})
    ok = not data.get("error")
    if not ok:
        json_print(
            {
                "ok": False,
                "mode": "stats",
                "query": args.query,
                "fields": args.fields,
                "data": data,
            },
            1,
        )

    report_written_to = None
    report_markdown = None
    if args.report_output:
        report_markdown = build_stats_report(args.query, data, user_intent=args.user_intent or "")
        report_written_to = write_text_file(Path(args.report_output).expanduser(), report_markdown)

    json_print(
        {
            "ok": True,
            "mode": "stats",
            "query": args.query,
            "fields": args.fields,
            "data": data,
            "report_written_to": report_written_to,
            "report_markdown": report_markdown,
        }
    )


def handle_alive_check(args: argparse.Namespace) -> None:
    targets: List[str] = []
    for item in args.target or []:
        targets.append(item.strip())
    if args.file:
        targets.extend(load_targets_from_file(args.file))
    targets = [target for target in targets if target]

    if not targets:
        json_print({"ok": False, "mode": "alive-check", "error": "no targets provided"}, 1)

    results = check_targets_alive(targets=targets, timeout=args.timeout, concurrency=args.concurrency)
    alive_count = sum(1 for result in results if is_alive_status(result["status"]))

    exported_to = None
    if args.output or args.export_format:
        rows = [
            [str(index), result["target"], result["url"], result["status"]]
            for index, result in enumerate(results, start=1)
        ]
        exported_to = write_export(
            output=args.output,
            export_format=args.export_format,
            prefix="fofa_alive",
            headers=["ID", "TARGET", "URL", "HTTP_STATUS"],
            rows=rows,
            sheet_name=args.sheet_name or "Alive Check",
        )

    json_print(
        {
            "ok": True,
            "mode": "alive-check",
            "target_count": len(targets),
            "alive_count": alive_count,
            "results": results,
            "exported_to": exported_to,
        }
    )


def handle_project_run(args: argparse.Namespace) -> None:
    queries: List[str] = []
    for query in args.query or []:
        if query.strip():
            queries.append(query.strip())
    if args.query_file:
        queries.extend(load_targets_from_file(args.query_file))
    queries = [query for query in queries if query]

    if not queries:
        json_print({"ok": False, "mode": "project-run", "error": "no queries provided"}, 1)

    suffix = timestamp_slug()
    project_dir = build_project_dir(args.project_name, args.outdir, queries[0])
    query_payloads: List[Dict[str, Any]] = []
    per_query_exports: List[str] = []

    for index, query in enumerate(queries, start=1):
        payload = search_query_workflow(
            query=query,
            requested_fields=args.fields or SAFE_FIELDS,
            pages=args.pages,
            size=args.size,
            full=args.full,
            alive_check=args.alive_check,
            alive_timeout=args.alive_timeout,
            alive_concurrency=args.alive_concurrency,
            keyword=args.keyword,
            include_status=args.include_status,
            only_alive=args.only_alive,
        )
        if not payload["ok"]:
            json_print(
                {
                    "ok": False,
                    "mode": "project-run",
                    "project_dir": str(project_dir),
                    "failed_query": query,
                    "error_payload": payload,
                },
                1,
            )

        if args.split_exports:
            headers, rows = build_export_rows(
                result_objects=payload["result_objects"],
                fields_str=payload["used_fields"],
                include_http_status=args.alive_check,
            )
            export_path = project_dir / f"query_{index}_{slugify(query, fallback='query', limit=30)}.{args.export_format}"
            per_query_exports.append(
                write_export(
                    output=str(export_path),
                    export_format=args.export_format,
                    prefix="query",
                    headers=headers,
                    rows=rows,
                    sheet_name=build_query_sheet_name(index, query),
                )
            )
        query_payloads.append(payload)

    merged_result_objects: List[Dict[str, str]] = []
    sheets: List[Dict[str, Any]] = []
    for index, payload in enumerate(query_payloads, start=1):
        headers, rows = build_export_rows(
            result_objects=payload["result_objects"],
            fields_str=payload["used_fields"],
            include_http_status=args.alive_check,
        )
        sheets.append(
            {
                "name": build_query_sheet_name(index, payload["query"]),
                "headers": headers,
                "rows": rows,
            }
        )
        for item in payload["result_objects"]:
            enriched = dict(item)
            enriched["source_query"] = payload["query"]
            merged_result_objects.append(enriched)

    merged_headers = project_csv_union_headers(query_payloads, include_http_status=args.alive_check)
    merged_rows = project_csv_rows(query_payloads, include_http_status=args.alive_check)
    merged_export_path = project_dir / f"batch_merge_{suffix}.{args.export_format}"
    merged_export = write_multi_export(
        output=str(merged_export_path),
        export_format=args.export_format,
        prefix="batch_merge",
        sheets=sheets,
        csv_headers=merged_headers,
        csv_rows=merged_rows,
    )

    targets_file = build_targets_file(project_dir, merged_result_objects, suffix)
    nuclei_suggestion = detect_nuclei_suggestion(
        merged_result_objects,
        user_intent=args.user_intent or " ; ".join(queries),
    )
    nuclei_command_file = build_nuclei_command_file(project_dir, nuclei_suggestion, suffix)
    nuclei_log_summary = parse_nuclei_log(args.nuclei_log)
    nuclei_run = None

    if args.run_nuclei:
        nuclei_path = locate_nuclei_binary()
        if not nuclei_path:
            json_print(
                {
                    "ok": False,
                    "mode": "project-run",
                    "project_dir": str(project_dir),
                    "error": "nuclei binary not found",
                },
                1,
            )
        nuclei_args = args.nuclei_args or nuclei_suggestion["args"]
        nuclei_output = str(project_dir / f"nuclei_result_{suffix}.txt")
        nuclei_run = run_nuclei_scan(
            nuclei_path=nuclei_path,
            targets_file=targets_file,
            extra_args=nuclei_args,
            output_file=nuclei_output,
        )
        if nuclei_run.get("summary"):
            nuclei_log_summary = nuclei_run["summary"]

    output_files = {
        "merged_export": merged_export,
        "targets": targets_file,
        "nuclei_command": nuclei_command_file,
    }
    if per_query_exports:
        output_files["per_query_exports"] = "\n".join(per_query_exports)
    if nuclei_run and nuclei_run.get("output_file"):
        output_files["nuclei_result"] = nuclei_run["output_file"]

    report_markdown = build_asset_report(
        project_name=project_dir.name,
        query_summaries=query_payloads,
        result_objects=merged_result_objects,
        user_intent=args.user_intent or " ; ".join(queries),
        nuclei_suggestion=nuclei_suggestion,
        output_files=output_files,
        nuclei_log_summary=nuclei_log_summary,
    )
    report_path = write_text_file(project_dir / f"report_{suffix}.md", report_markdown)

    json_print(
        {
            "ok": True,
            "mode": "project-run",
            "project_dir": str(project_dir),
            "query_count": len(query_payloads),
            "total_result_count": len(merged_result_objects),
            "unique_target_count": len(unique_nonempty(item.get("target", "") for item in merged_result_objects)),
            "merged_export": merged_export,
            "per_query_exports": per_query_exports,
            "targets_file": targets_file,
            "report_file": report_path,
            "nuclei_command_file": nuclei_command_file,
            "nuclei_suggestion": nuclei_suggestion,
            "nuclei_run": nuclei_run,
            "queries": query_payloads,
        }
    )


def handle_nuclei_run(args: argparse.Namespace) -> None:
    nuclei_path = locate_nuclei_binary()
    if not nuclei_path:
        json_print({"ok": False, "mode": "nuclei-run", "error": "nuclei binary not found"}, 1)

    targets_file = args.targets_file
    temp_file = None
    if not targets_file:
        targets = [item.strip() for item in args.target or [] if item.strip()]
        if not targets:
            json_print({"ok": False, "mode": "nuclei-run", "error": "no targets provided"}, 1)
        temp_file = Path.cwd() / f"nuclei_targets_{timestamp_slug()}.txt"
        temp_file.write_text("\n".join(targets), encoding="utf-8")
        targets_file = str(temp_file)

    output = args.output or str(Path.cwd() / f"nuclei_result_{timestamp_slug()}.txt")
    payload = run_nuclei_scan(
        nuclei_path=nuclei_path,
        targets_file=targets_file,
        extra_args=args.args or "",
        output_file=output,
    )
    payload["mode"] = "nuclei-run"
    payload["targets_file"] = targets_file
    payload["temporary_targets_file"] = str(temp_file) if temp_file else None
    json_print(payload, 0 if payload["ok"] else 1)


def handle_nuclei_update(_: argparse.Namespace) -> None:
    nuclei_path = locate_nuclei_binary()
    if not nuclei_path:
        json_print({"ok": False, "mode": "nuclei-update", "error": "nuclei binary not found"}, 1)
    payload = run_nuclei_update(nuclei_path)
    payload["mode"] = "nuclei-update"
    payload["nuclei_path"] = nuclei_path
    json_print(payload, 0 if payload["ok"] else 1)


def rotl32(value: int, shift: int) -> int:
    value &= 0xFFFFFFFF
    return ((value << shift) & 0xFFFFFFFF) | (value >> (32 - shift))


def fmix32(value: int) -> int:
    value ^= value >> 16
    value = (value * 0x85EBCA6B) & 0xFFFFFFFF
    value ^= value >> 13
    value = (value * 0xC2B2AE35) & 0xFFFFFFFF
    value ^= value >> 16
    return value & 0xFFFFFFFF


def murmurhash3_x86_32(data: bytes, seed: int = 0) -> int:
    length = len(data)
    h1 = seed & 0xFFFFFFFF
    c1 = 0xCC9E2D51
    c2 = 0x1B873593
    rounded_end = length & 0xFFFFFFFC

    for index in range(0, rounded_end, 4):
        k1 = (
            data[index]
            | (data[index + 1] << 8)
            | (data[index + 2] << 16)
            | (data[index + 3] << 24)
        )
        k1 = (k1 * c1) & 0xFFFFFFFF
        k1 = rotl32(k1, 15)
        k1 = (k1 * c2) & 0xFFFFFFFF
        h1 ^= k1
        h1 = rotl32(h1, 13)
        h1 = (h1 * 5 + 0xE6546B64) & 0xFFFFFFFF

    k1 = 0
    tail = length & 0x03
    if tail == 3:
        k1 ^= data[rounded_end + 2] << 16
    if tail >= 2:
        k1 ^= data[rounded_end + 1] << 8
    if tail >= 1:
        k1 ^= data[rounded_end]
        k1 = (k1 * c1) & 0xFFFFFFFF
        k1 = rotl32(k1, 15)
        k1 = (k1 * c2) & 0xFFFFFFFF
        h1 ^= k1

    h1 ^= length
    h1 = fmix32(h1)
    if h1 & 0x80000000:
        return -((~h1 + 1) & 0xFFFFFFFF)
    return h1


def handle_icon_hash(args: argparse.Namespace) -> None:
    url = normalize_url(args.url)
    parsed = urllib.parse.urlparse(url)
    favicon_url = urllib.parse.urlunparse((parsed.scheme, parsed.netloc, args.favicon_path, "", "", ""))
    context = ssl._create_unverified_context() if args.insecure else None

    request = urllib.request.Request(
        favicon_url,
        headers={"User-Agent": "fofamap-skill/2.0"},
    )
    try:
        with urllib.request.urlopen(request, timeout=15, context=context) as response:
            content = response.read()
    except Exception as exc:
        json_print(
            {
                "ok": False,
                "mode": "icon-hash",
                "url": url,
                "favicon_url": favicon_url,
                "error": str(exc),
            },
            1,
        )

    encoded = base64.encodebytes(content)
    icon_hash = murmurhash3_x86_32(encoded)
    json_print(
        {
            "ok": True,
            "mode": "icon-hash",
            "url": url,
            "favicon_url": favicon_url,
            "icon_hash": icon_hash,
            "fofa_query": f'icon_hash="{icon_hash}"',
        }
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="FOFA helper for the fofamap skill")
    subparsers = parser.add_subparsers(dest="mode", required=True)

    login = subparsers.add_parser("login", help="validate FOFA credentials")
    login.set_defaults(func=handle_login)

    search = subparsers.add_parser("search", help="run a FOFA search query")
    search.add_argument("--query", required=True, help="FOFA query string")
    search.add_argument("--fields", default=SAFE_FIELDS, help="comma-separated response fields")
    search.add_argument("--pages", type=int, default=1, help="number of pages to fetch")
    search.add_argument("--size", type=int, default=100, help="page size, FOFA max is usually 10000")
    search.add_argument("--full", action="store_true", help="search historical data")
    search.add_argument("--keyword", help="comma-separated local keyword filter over returned rows")
    search.add_argument("--alive-check", action="store_true", help="probe returned web assets for live HTTP/HTTPS responses")
    search.add_argument("--alive-timeout", type=int, default=5, help="per-target timeout in seconds for alive checks")
    search.add_argument("--alive-concurrency", type=int, default=DEFAULT_ALIVE_CONCURRENCY, help="concurrency for alive checks")
    search.add_argument("--only-alive", action="store_true", help="keep only rows that return an HTTP status during alive checks")
    search.add_argument("--include-status", help="comma-separated HTTP statuses to keep after alive checks, e.g. 200,302,401")
    search.add_argument("--output", help="optional export path for csv/xlsx output")
    search.add_argument("--export-format", choices=["csv", "xlsx"], help="export format when writing a file")
    search.add_argument("--sheet-name", help="sheet name for xlsx export")
    search.add_argument("--targets-output", help="optional path to write a targets.txt handoff file")
    search.add_argument("--suggest-nuclei", action="store_true", help="include heuristic nuclei command suggestions")
    search.add_argument("--nuclei-command-output", help="optional path to write the suggested nuclei command")
    search.add_argument("--report-output", help="optional path to write a Markdown report")
    search.add_argument("--user-intent", help="optional original user intent to enrich suggestions and reports")
    search.set_defaults(func=handle_search)

    host = subparsers.add_parser("host", help="query one host aggregation record")
    host.add_argument("--target", required=True, help="single IP or domain")
    host.add_argument("--report-output", help="optional path to write a Markdown host report")
    host.add_argument("--user-intent", help="optional original user intent")
    host.set_defaults(func=handle_host)

    stats = subparsers.add_parser("stats", help="run a FOFA stats aggregation")
    stats.add_argument("--query", required=True, help="FOFA query string")
    stats.add_argument("--fields", default="country,title,org", help="comma-separated stats fields")
    stats.add_argument("--report-output", help="optional path to write a Markdown stats report")
    stats.add_argument("--user-intent", help="optional original user intent")
    stats.set_defaults(func=handle_stats)

    alive = subparsers.add_parser("alive-check", help="probe targets for HTTP/HTTPS liveness")
    alive.add_argument("--target", action="append", help="target URL, host, or host:port; repeat for multiple targets")
    alive.add_argument("--file", help="optional file containing one target per line")
    alive.add_argument("--timeout", type=int, default=5, help="per-target timeout in seconds")
    alive.add_argument("--concurrency", type=int, default=DEFAULT_ALIVE_CONCURRENCY, help="concurrency for live checks")
    alive.add_argument("--output", help="optional export path for csv/xlsx output")
    alive.add_argument("--export-format", choices=["csv", "xlsx"], help="export format when writing a file")
    alive.add_argument("--sheet-name", help="sheet name for xlsx export")
    alive.set_defaults(func=handle_alive_check)

    project = subparsers.add_parser("project-run", help="run one or more FOFA queries as a project workflow")
    project.add_argument("--query", action="append", help="FOFA query string; repeat for multiple queries")
    project.add_argument("--query-file", help="optional file containing one FOFA query per line")
    project.add_argument("--fields", default=SAFE_FIELDS, help="comma-separated response fields")
    project.add_argument("--pages", type=int, default=1, help="number of pages to fetch for each query")
    project.add_argument("--size", type=int, default=100, help="page size for each FOFA request")
    project.add_argument("--full", action="store_true", help="search historical data")
    project.add_argument("--keyword", help="comma-separated local keyword filter over returned rows")
    project.add_argument("--alive-check", action="store_true", help="probe returned web assets for live HTTP/HTTPS responses")
    project.add_argument("--alive-timeout", type=int, default=5, help="per-target timeout in seconds for alive checks")
    project.add_argument("--alive-concurrency", type=int, default=DEFAULT_ALIVE_CONCURRENCY, help="concurrency for alive checks")
    project.add_argument("--only-alive", action="store_true", help="keep only rows that return an HTTP status during alive checks")
    project.add_argument("--include-status", help="comma-separated HTTP statuses to keep after alive checks")
    project.add_argument("--project-name", help="optional project name used in the output directory name")
    project.add_argument("--outdir", help="optional explicit project output directory")
    project.add_argument("--export-format", choices=["csv", "xlsx"], default="xlsx", help="export format for project outputs")
    project.add_argument("--split-exports", action="store_true", help="also export each query as its own file inside the project directory")
    project.add_argument("--user-intent", help="optional original user intent to enrich the report and nuclei suggestion")
    project.add_argument("--nuclei-log", help="optional existing nuclei log to fold into the project report")
    project.add_argument("--run-nuclei", action="store_true", help="run nuclei against the generated targets.txt using the suggested or provided args")
    project.add_argument("--nuclei-args", help="explicit nuclei arguments to use when --run-nuclei is set")
    project.set_defaults(func=handle_project_run)

    nuclei_run = subparsers.add_parser("nuclei-run", help="run nuclei against a targets file or explicit targets")
    nuclei_run.add_argument("--targets-file", help="path to an existing targets file")
    nuclei_run.add_argument("--target", action="append", help="single target; repeat for multiple entries when not using --targets-file")
    nuclei_run.add_argument("--args", help="extra nuclei arguments such as '-tags grafana -severity critical,high'")
    nuclei_run.add_argument("--output", help="result log path")
    nuclei_run.set_defaults(func=handle_nuclei_run)

    nuclei_update = subparsers.add_parser("nuclei-update", help="run nuclei template and binary update steps")
    nuclei_update.set_defaults(func=handle_nuclei_update)

    icon_hash = subparsers.add_parser("icon-hash", help="calculate a FOFA icon hash query")
    icon_hash.add_argument("--url", required=True, help="target URL or host")
    icon_hash.add_argument("--favicon-path", default="/favicon.ico", help="favicon path")
    icon_hash.add_argument("--insecure", action="store_true", help="skip TLS verification for favicon fetch")
    icon_hash.set_defaults(func=handle_icon_hash)

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
