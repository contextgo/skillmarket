---
name: zk
description: 纯文本 Zettelkasten 笔记助手。创建、搜索和管理 Markdown 笔记，支持高级筛选、标签和维基链接。
homepage: https://github.com/zk-org/zk
metadata:
  {
    "openclaw":
      {
        "emoji": "📝",
        "requires": { "bins": ["zk"], "env": ["VAULT_PATH"] },
        "install":
          [
            {
              "id": "brew",
              "kind": "brew",
              "formula": "zk",
              "bins": ["zk"],
              "label": "Install zk (brew)",
            },
            {
              "id": "linux-tarball",
              "kind": "manual",
              "platforms": ["linux"],
              "bins": ["zk"],
              "label": "Install zk on Linux via tarball",
              "script": "curl -L https://gh-proxy.org/https://github.com/zk-org/zk/releases/download/v0.15.2/zk-v0.15.2-linux-amd64.tar.gz | tar xz && mv zk /usr/local/bin/",
            },
          ],
      },
  }
---

# zk

zk 是一个命令行工具，用于维护纯文本的 Zettelkasten（卡片笔记法）或个人维基。它以 Markdown 文件为载体，支持标签、Wiki 链接、全文搜索和交互式笔记浏览。

## 安装（如需）

如果尚未安装 `zk`，可参考以下步骤。若已安装，可直接跳到"快速开始"部分。

### Homebrew

```bash
brew install zk
```

### Linux tarball

```bash
curl -L https://gh-proxy.org/https://github.com/zk-org/zk/releases/download/v0.15.2/zk-v0.15.2-linux-amd64.tar.gz | tar xz
sudo mv zk /usr/local/bin/
```

### 验证安装

```bash
zk --version
```

## 快速开始

### 使用 `VAULT_PATH` 管理笔记库

如果你希望把笔记库保存在 `VAULT_PATH` 下，建议先设置变量并进入目录：

```bash
export VAULT_PATH="/path/to/your/vault"
cd "$VAULT_PATH"
```

然后直接在该目录下运行 `zk`：

```bash
zk list
zk new --title "新笔记"
zk edit <note-id>
```

> `zk` 默认会在当前工作目录查找笔记库，因此 `cd "$VAULT_PATH"` 通常最可靠。

### 初始化笔记本

```bash
zk init my-notes
cd my-notes
```

### 创建笔记

```bash
zk new --title "笔记标题"
zk new --interactive
```

### 搜索笔记

```bash
# 列出所有笔记
zk list

# 关键词搜索
zk list --match "关键词"

# 标签搜索
zk list --tag mytag

# 交互式搜索
zk list --interactive
```

### 编辑笔记

```bash
zk edit --interactive
zk edit <note-id>
```

## 支持的格式

### 链接

- Markdown: `[链接](note.md)`
- Wikilinks: `[[笔记名称]]`

### 标签

- `#hashtag`
- `:colon:tags:`
- `#多词标签#`

### YAML frontmatter

```yaml
---
title: 标题
tags: [tag1, tag2]
---
```

## 常用命令

| 命令         | 功能            |
| ------------ | --------------- |
| `zk init`    | 初始化笔记本    |
| `zk new`     | 创建新笔记      |
| `zk list`    | 列出/搜索笔记   |
| `zk edit`    | 编辑笔记        |
| `zk preview` | 预览笔记        |
| `zk mv`      | 重命名/移动笔记 |
| `zk rm`      | 删除笔记        |

更多命令请查看 `zk --help`。

## 过滤器选项

- `--match, -m` - 关键词匹配（支持 `-` 排除）
- `--tag, -t` - 标签匹配
- `--link` - 链接到指定笔记
- `--linked-by` - 被指定笔记链接
- `--interactive, -i` - 交互式筛选
- `--sort` - 排序 (created/modified/title)

## 配置

配置文件：`.zk/config.toml`

```bash
vim .zk/config.toml
```

如果你的 `zk` 版本支持配置文件，可以在其中指定默认编辑器、笔记格式、标签规则等。

### 配置示例（根据实际版本调整）

```toml
[editor]
cmd = "vim"

[notes]
default_tags = ["vault"]
```

## 典型工作流

### 创建并立即写笔记

```bash
cd "$VAULT_PATH"
zk new --title "会议纪要" --tag meeting
```

### 以标签搜索并编辑

```bash
cd "$VAULT_PATH"
zk list --tag project --match "设计"
zk edit <note-id>
```

### 查找双向链接

```bash
cd "$VAULT_PATH"
zk list --linked-by "目标笔记标题"
```

## 示例

```bash
# 搜索包含 pizza 但不包含 pineapple 的笔记
zk list --match "pizza -pineapple"

# 搜索 tag 为 recipe 且最近 7 天创建的笔记
zk list --tag recipe --created "7 days ago"

# 交互式选择并编辑
zk edit -i -m "recipe"
```
