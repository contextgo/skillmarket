# Store Metadata

    ## Listing identity
    - **Display name:** Multi Format Amplification Planner
    - **Slug:** `multi-format-amplification-planner`
    - **Category:** editorial-planning
    - **Short description:** Turn one topic into a differentiated multi-format package.
    - **One-line positioning:** Assign clear jobs to text, video, social, and other formats so one topic can move from visibility to understanding to recirculation.

    ## Suggested tags
    - `editorial-planning`
- `multi-format`
- `distribution-strategy`
- `video`
- `social`
- `amplification`

    ## Best-fit queries
    - Turn this topic into a text-video-social package.
- What should the anchor product be for this major-theme package?
- Design a lean package with one anchor, one entry asset, and one recirculation asset.

    ## Core use cases
    - Build a full-platform topic package
- Separate anchor, proof, and spread assets
- Reduce duplication across channels

    ## README intro block
    > Multi Format Amplification Planner helps editorial teams and planning agents solve one specific planning problem with repeatable structure, output patterns, and reference materials. It is best used as one module inside a larger editorial planning system.

    ## Publish notes
    - Keep this skill listed separately rather than bundling it with all six skills.
    - Use a concise changelog line such as `Initial public release` or `Improved trigger wording and examples`.
    - Keep the public listing focused on the problem it solves, not the full six-skill architecture.
    - Recommended audience: editorial strategists, newsroom innovation teams, international communication planners, and multi-agent OpenClaw builders.
