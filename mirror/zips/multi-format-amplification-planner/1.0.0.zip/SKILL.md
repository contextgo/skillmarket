---
name: multi-format-amplification-planner
description: design multi-format editorial amplification plans for major reporting themes in international communication. use when chatgpt needs to break one topic into anchor text, visual storytelling, social distribution, and staged platform roles, and build a coordinated path from visibility to comprehension to wider resonance across multiple formats and channels.
---

# Multi Format Amplification Planner

Design a coordinated multi-format communication plan for one editorial theme.

This skill is for editorial planning, not final drafting or posting. The goal is not to repeat the same message everywhere. The goal is to assign each format a clear job in the communication chain so the audience can move from first contact to deeper understanding and wider circulation.

## Core task
Given one topic, one audience orientation, and a set of available platforms or formats, produce an amplification plan that answers:
- what is the communication job of the overall topic?
- which content form should carry the deepest explanation?
- which format should create first visibility?
- how should formats connect rather than duplicate each other?

## Method

### 1. Define the communication chain
Specify the progression the audience needs: notice, enter, understand, remember, share, and return.

### 2. Define the anchor product
Name the one product that carries the deepest explanatory burden and stabilizes interpretation.

### 3. Assign distinct jobs to other formats
Each supporting format should mainly do one job: hook attention, humanize, visualize proof, generate fragments, or sustain attention.

### 4. Match format to audience-entry logic
Choose forms based on how the audience is most likely to enter and stay.

### 5. Design platform-specific functions
State why each platform matters. Do not just repost the same content.

### 6. Build connection pathways across formats
Show how one format leads to another.

### 7. Output a productized amplification plan
Use `references/amplification-output-template.md` and the role library in `references/format-role-patterns.md`.

## Editorial rules
- One topic does not mean one format.
- One package does not mean duplication.
- One anchor must carry meaning.
- Visibility and understanding are different jobs.
- Preserve coherence across forms.

## Boundary
This skill is for multi-format communication planning, platform role design, and editorial package architecture. It is not for detailed posting calendars, ad buying, or generic social media tips.
