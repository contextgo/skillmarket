# Changelog

## 1.0.0
- Initial public bundle for ClawHub-style installation.
