# Multi Format Amplification Planner

Design coordinated multi-format editorial packages.

## Included files
- SKILL.md
- agents/openai.yaml
- references/
- MANIFEST.yaml
- CHANGELOG.md
- _meta.json

## Install notes
This bundle is packaged as a standard ZIP with a top-level `multi-format-amplification-planner/` directory so it can be imported by skill installers that expect one skill per archive.
