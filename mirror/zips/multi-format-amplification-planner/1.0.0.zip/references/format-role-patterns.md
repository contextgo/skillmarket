# Format Role Patterns

## Core principle
A strong package does not repeat the same content everywhere. It assigns different jobs to different formats so the audience can move from first notice to deeper understanding and recirculation.

## Main communication jobs
- anchor meaning
- create first visibility
- lower entry barriers
- visualize proof
- humanize the topic
- generate shareable fragments
- sustain attention
- reactivate deeper engagement

## Common format roles
- **Longform text / deep feature**: anchor meaning
- **Flagship analysis**: define argument after evidence is established
- **Documentary or micro-documentary**: visualize proof and humanize
- **Short video clip**: create first visibility and drive traffic back to deeper products
- **Visual explainer**: lower entry barriers and clarify process or comparison
- **Social thread**: serialize understanding and reactivate anchor content
- **Quote/stat cards**: generate shareable fragments
- **Landing page / topic hub**: connect the package and support re-entry

## Strong package signals
- one clear anchor product
- formats with different jobs
- strong handoffs between assets
- visible proof plus interpretive stability

## Weak package signals
- same message copied into every format
- no anchor
- all formats try to explain everything
- visibility without understanding
