# Amplification Output Template

### Topic Definition
Restate the topic in editorial language.

### Communication Objective
State what the package should help the audience notice, understand, feel, remember, or do.

### Audience Entry Logic
Explain how the target audience is most likely to first enter this topic.

### Anchor Product
Name the product type, why it is the anchor, what explanatory burden it carries, and what evidence it needs.

### Supporting Products
For each supporting product, specify product type, primary function, best use in the chain, what it should do, and what it should not try to do.

### Platform Role Map
Assign each platform a specific communication job and handoff target.

### Sequencing Plan
Explain the release and intensification logic.

### Cross-Format Linkages
Show how each product should connect to another.

### Amplification Triggers
List the elements most likely to create spread, recall, or return attention.

### Meaning Control Measures
Explain how to prevent drift, oversimplification, or contradiction across formats.

### Resource Requirements
List the minimum resources needed to make the package work.

### Final Amplification Verdict
Choose one clear verdict and explain why.
