---
name: festival-poster
description: 中国传统节日海报生成技能。使用豆包 Doubao SeedImage AI 生成节日和节气品牌宣传海报（1080×1920px 竖版 PNG）。支持春节、中秋、端午等15个传统节日和24节气。当用户提到以下场景时触发：生成节日海报、节日宣传海报、农历节日海报、节气海报、品牌海报、朋友圈节日海报。
---

# 🎨 节日海报生成技能

> 使用豆包 Doubao SeedImage AI 生成中国传统节日与24节气品牌宣传海报

## 功能特点

| 特点 | 说明 |
|-----|------|
| 🎯 **38个节日/节气** | 15个传统节日 + 24个节气 |
| 🤖 **AI 智能生图** | 豆包 Doubao SeedImage 高质量海报 |
| 📱 **竖版手机格式** | 1080×1920px（9:16），适合朋友圈、小红书 |
| 🏢 **品牌信息保存** | 首次配置后自动记忆，无需重复输入 |
| 💾 **配置永久保存** | API Key 和品牌信息存储在用户目录 |

## 📋 首次使用配置（只需一次）

### 步骤 1：获取豆包 API Key

```
1. 访问 https://console.volcengine.com/
2. 登录/注册火山引擎账号
3. 进入「豆包 Doubao」服务
4. 创建 API Key（UUID 格式，如 xxxx-xxxx-xxxx）
5. ⚠️ 确保账户有足够余额（SeedImage 按次计费）
```

### 步骤 2：配置命令

```bash
# 方式一：一次性完成所有配置
python scripts/generate.py \
  --api-key "你的API-Key" \
  --brand "你的公司名称"

# 方式二：分步配置
python scripts/generate.py --api-key "你的API-Key"
python scripts/generate.py --brand "你的公司名称"

# 可选：添加 Logo
python scripts/generate.py --brand "公司名" --logo ~/logo.png
```

## 🚀 日常使用

```bash
# 生成指定节日海报
python scripts/generate.py 春节
python scripts/generate.py 中秋节
python scripts/generate.py 端午

# 随机节日
python scripts/generate.py --random

# 查看支持的节日列表
python scripts/generate.py --list
```

## 📂 文件结构

```
festival-poster/
├── SKILL.md              # 本文件
├── scripts/
│   └── generate.py       # 海报生成脚本
├── data/
│   └── festivals.json    # 节日数据
└── output/               # 海报输出目录
```

## ⚙️ 配置存储位置

- **API Key**：`~/.festival-poster/config.json`
- **品牌信息**：`~/.festival-poster/brand.json`

## ❓ 常见问题

| 问题 | 解决方案 |
|-----|---------|
| 提示"API Key 无效" | 检查 Key 格式，应为 UUID（如 xxxx-xxxx-xxxx） |
| 提示"余额不足" | 登录 https://console.volcengine.com/ 充值 |
| 想换品牌名称 | 重新运行 `--brand 新名称` 即可覆盖 |
| 想更换 API Key | 重新运行 `--api-key 新Key` 即可覆盖 |
