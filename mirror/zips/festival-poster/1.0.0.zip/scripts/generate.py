#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
节日海报生成脚本 - 豆包 Doubao SeedImage 版本
使用豆包 Doubao API 生成中国传统节日和节气品牌海报
"""

import json
import os
import sys
import time
import random
from pathlib import Path
from datetime import datetime
from base64 import b64decode

import requests

# 配置路径
SCRIPT_DIR = Path(__file__).parent.parent
DATA_DIR = SCRIPT_DIR / "data"
OUTPUT_DIR = SCRIPT_DIR / "output"
BRAND_CONFIG_PATH = Path.home() / ".festival-poster" / "brand.json"
CONFIG_PATH = Path.home() / ".festival-poster" / "config.json"

# 海报尺寸
POSTER_WIDTH = 1080
POSTER_HEIGHT = 1920

# 豆包 Doubao API 配置
DOUBAO_API_BASE = "https://ark.cn-beijing.volces.com/api/v3"
DOUBAO_MODEL = "doubao-seedream-4-5-251128"


def load_config():
    """加载配置"""
    if CONFIG_PATH.exists():
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    return None


def save_config(api_key, model=None):
    """保存配置"""
    config_dir = CONFIG_PATH.parent
    config_dir.mkdir(parents=True, exist_ok=True)
    
    config = {
        "api_key": api_key,
        "model": model or DOUBAO_MODEL,
        "created_at": datetime.now().strftime("%Y-%m-%d")
    }
    
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(config, f, ensure_ascii=False, indent=2)
    
    return config


def check_config():
    """检查配置是否完整"""
    config = load_config()
    if not config:
        return False, "未配置豆包 API 密钥"
    
    if not config.get("api_key"):
        return False, "API Key 未配置"
    
    return True, config


def load_festivals():
    """加载节日数据"""
    with open(DATA_DIR / "festivals.json", "r", encoding="utf-8") as f:
        data = json.load(f)
    
    all_festivals = []
    seen_names = set()
    
    for festival in data["traditional_festivals"]:
        if festival["name"] not in seen_names:
            all_festivals.append(festival)
            seen_names.add(festival["name"])
    
    for term in data["solar_terms"]:
        if term["name"] not in seen_names:
            all_festivals.append(term)
            seen_names.add(term["name"])
    
    return all_festivals


def load_brand():
    """加载品牌配置"""
    if BRAND_CONFIG_PATH.exists():
        with open(BRAND_CONFIG_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    return None


def save_brand(company_name, logo_path=None):
    """保存品牌配置"""
    config_dir = BRAND_CONFIG_PATH.parent
    config_dir.mkdir(parents=True, exist_ok=True)
    
    brand = {
        "company_name": company_name,
        "logo_path": str(logo_path) if logo_path else None,
        "created_at": datetime.now().strftime("%Y-%m-%d")
    }
    
    with open(BRAND_CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(brand, f, ensure_ascii=False, indent=2)
    
    return brand


def generate_seedimage_prompt(festival, brand):
    """生成 SeedImage 提示词"""
    
    brand_name = brand["company_name"]
    festival_name = festival["name"]
    blessing = festival["blessing"]
    
    # 根据节日类型构建不同的提示词
    if festival["name"] in ["春节", "除夕"]:
        prompt = f"""Create a vertical Chinese New Year festival poster (9:16 aspect ratio, 1080x1920px).
Design requirements:
- Deep red and gold color theme with festive atmosphere
- Traditional Chinese New Year elements: red lanterns, fireworks, lucky symbols, paper-cut art patterns
- Brand "{brand_name}" displayed prominently at top
- Main title "{festival_name}" in elegant traditional Chinese calligraphy style
- Blessing text "{blessing}"
- High quality professional marketing poster design
- Vertical mobile format
"""
    elif festival["name"] == "元宵节":
        prompt = f"""Create a vertical Lantern Festival poster (9:16 aspect ratio, 1080x1920px).
Design requirements:
- Deep red, gold and warm orange color theme
- Traditional Lantern Festival elements: colorful lanterns, tangyuan dumplings, festive decorations
- Brand "{brand_name}" displayed at top
- Main title "{festival_name}" in beautiful calligraphy
- Blessing text "{blessing}"
- High quality professional poster design
- Vertical mobile format
"""
    elif festival["name"] == "中秋节":
        prompt = f"""Create a vertical Mid-Autumn Festival poster (9:16 aspect ratio, 1080x1920px).
Design requirements:
- Deep blue night sky with golden full moon
- Traditional elements: osmanthus flowers, jade rabbit, mooncakes
- Romantic and warm atmosphere
- Brand "{brand_name}" displayed elegantly at top
- Main title "{festival_name}" in beautiful calligraphy
- Blessing text "{blessing}"
- High quality professional poster design
- Vertical mobile format
"""
    elif festival["name"] == "端午节":
        prompt = f"""Create a vertical Dragon Boat Festival poster (9:16 aspect ratio, 1080x1920px).
Design requirements:
- Fresh green and blue color theme
- Traditional elements: dragon boat, zongzi dumplings, calamus, festival traditions
- Traditional cultural atmosphere
- Brand "{brand_name}" displayed prominently
- Main title "{festival_name}" in elegant style
- Blessing text "{blessing}"
- High quality professional poster design
- Vertical mobile format
"""
    elif festival["name"] == "清明节":
        prompt = f"""Create a vertical Qingming Festival poster (9:16 aspect ratio, 1080x1920px).
Design requirements:
- Soft green, gray and misty blue tones representing spring
- Traditional elements: willow branches, gentle breeze, peaceful spring scenery
- Respectful and serene atmosphere
- Brand "{brand_name}" displayed elegantly
- Main title "{festival_name}" in refined calligraphy
- Blessing text "{blessing}"
- High quality professional poster design
- Vertical mobile format
"""
    elif festival["name"] == "七夕节":
        prompt = f"""Create a vertical Qixi Festival (Chinese Valentine's Day) poster (9:16 aspect ratio, 1080x1920px).
Design requirements:
- Romantic pink, purple and starlight tones
- Magical atmosphere with magpie bridge, stars, love symbols
- Dreamy and beautiful design
- Brand "{brand_name}" displayed elegantly
- Main title "{festival_name}" in beautiful calligraphy
- Blessing text "{blessing}"
- High quality professional poster design
- Vertical mobile format
"""
    elif festival["name"] == "重阳节":
        prompt = f"""Create a vertical Double Ninth Festival poster (9:16 aspect ratio, 1080x1920px).
Design requirements:
- Golden autumn tones with warm feeling
- Traditional elements: chrysanthemums, mountain scenery, longevity symbols
- Respect for elders theme
- Brand "{brand_name}" displayed prominently
- Main title "{festival_name}" in elegant calligraphy
- Blessing text "{blessing}"
- High quality professional poster design
- Vertical mobile format
"""
    else:
        # 其他节日或节气
        keywords = festival.get("keywords", "")
        if isinstance(keywords, list):
            keywords = ", ".join(keywords[:3])
        
        prompt = f"""Create a vertical Chinese traditional festival poster (9:16 aspect ratio, 1080x1920px).
{festival.get('lunar', '')}, {festival.get('date', '')}
Design requirements:
- Elegant Chinese aesthetic with seasonal elements
- Traditional cultural atmosphere, {keywords}
- Professional and refined design
- Brand "{brand_name}" displayed prominently
- Main title "{festival_name}" in beautiful calligraphy
- Blessing text "{blessing}"
- High quality professional poster design
- Vertical mobile format
"""
    
    return prompt.strip()


def call_doubao_api(prompt, config):
    """调用豆包 Doubao API"""
    
    api_key = config["api_key"]
    model = config.get("model", DOUBAO_MODEL)
    
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}"
    }
    
    # 尝试不同的 API 端点格式
    endpoints_to_try = [
        # 图片生成专用端点
        "https://ark.cn-beijing.volces.com/api/v3/images/generations",
        f"{DOUBAO_API_BASE}/images/generations",
    ]
    
    for endpoint in endpoints_to_try:
        try:
            print(f"   尝试端点: {endpoint}")
            
            # 图片生成请求格式
            payload = {
                "model": model,
                "prompt": prompt,
                "image_size": {
                    "width": 540,
                    "height": 960
                },
                "number": 1
            }
            
            response = requests.post(
                endpoint,
                headers=headers,
                json=payload,
                timeout=120
            )
            
            if response.status_code == 200:
                return response.json(), endpoint
            elif response.status_code == 400:
                # 可能需要调整请求格式
                error_data = response.json()
                if "error" in error_data:
                    return error_data, endpoint
            elif response.status_code == 401:
                return {"error": "API Key 无效或已过期"}, endpoint
            elif response.status_code == 429:
                return {"error": "请求过于频繁，请稍后再试"}, endpoint
            else:
                continue
                
        except requests.exceptions.Timeout:
            continue
        except requests.exceptions.ConnectionError:
            continue
        except Exception as e:
            continue
    
    return {"error": f"所有端点均失败"}, None


def download_image(url, output_path):
    """下载图片"""
    try:
        # 处理可能的数据URL
        if url.startswith('data:'):
            # Base64 编码的图片
            header, data = url.split(',', 1)
            with open(output_path, 'wb') as f:
                f.write(b64decode(data))
            return True
        
        # 普通 URL
        headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'
        }
        req = requests.get(url, headers=headers, timeout=60)
        if req.status_code == 200:
            with open(output_path, 'wb') as f:
                f.write(req.content)
            return True
        return False
    except Exception as e:
        print(f"下载失败: {e}")
        return False


def composite_poster(generated_image_path, brand, festival, output_path):
    """合成最终海报（添加品牌信息）"""
    try:
        from PIL import Image, ImageDraw, ImageFont
        
        # 打开生成的图片
        img = Image.open(generated_image_path)
        
        # 调整大小为标准尺寸
        img = img.resize((POSTER_WIDTH, POSTER_HEIGHT), Image.Resampling.LANCZOS)
        
        draw = ImageDraw.Draw(img)
        
        # 获取字体
        def get_font(size):
            font_paths = [
                "/System/Library/Fonts/PingFang.ttc",
                "/System/Library/Fonts/STHeiti Light.ttc",
                "/System/Library/Fonts/Hiragino Sans GB.ttc",
                "C:\\Windows\\Fonts\\msyh.ttc",
            ]
            for font_path in font_paths:
                if os.path.exists(font_path):
                    try:
                        return ImageFont.truetype(font_path, size)
                    except:
                        continue
            return ImageFont.load_default()
        
        # 底部添加品牌信息
        y_offset = POSTER_HEIGHT - 150
        
        # 品牌名称
        brand_font = get_font(36)
        brand_name = brand["company_name"]
        bbox = draw.textbbox((0, 0), brand_name, font=brand_font)
        text_width = bbox[2] - bbox[0]
        draw.text(
            ((POSTER_WIDTH - text_width) // 2, y_offset),
            brand_name,
            fill=(255, 255, 255),
            font=brand_font
        )
        
        # 保存最终海报
        img.save(output_path, "PNG")
        return True
        
    except ImportError:
        # 没有 Pillow，直接使用原图
        import shutil
        shutil.copy(generated_image_path, output_path)
        return True
    except Exception as e:
        print(f"合成海报时出错: {e}")
        import shutil
        shutil.copy(generated_image_path, output_path)
        return True


def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description="生成节日海报（使用豆包 Doubao SeedImage）")
    parser.add_argument("festival", nargs="?", help="节日名称，不指定则随机选择")
    parser.add_argument("--brand", help="品牌名称（首次配置）")
    parser.add_argument("--logo", help="Logo路径（可选）")
    parser.add_argument("--list", action="store_true", help="列出所有支持的节日")
    parser.add_argument("--random", action="store_true", help="随机生成")
    parser.add_argument("--api-key", dest="api_key", help="豆包 API Key（首次配置）")
    parser.add_argument("--model", help="模型名称（可选，默认 doubao-seedream-4-5-251128）")
    
    args = parser.parse_args()
    
    # === 检查/配置 API ===
    config_valid, result = check_config()
    
    if args.api_key:
        result = save_config(args.api_key, args.model)
        config_valid = True
        print(f"\n✅ 豆包 API 密钥已保存")
        print(f"   模型: {args.model or DOUBAO_MODEL}")
    
    if not config_valid:
        print("\n" + "="*60)
        print("🎨 节日海报生成技能 - 首次使用配置")
        print("="*60)
        print("\n📋 使用前需要完成以下配置：\n")
        
        print("Step 1️⃣ 获取豆包 API Key")
        print("-" * 40)
        print("  1. 访问 https://console.volcengine.com/")
        print("  2. 登录/注册火山引擎账号")
        print("  3. 进入「豆包 Doubao」服务")
        print("  4. 创建 API Key（UUID 格式）")
        print("  ⚠️ 注意：SeedImage 服务按次计费，请确保账户有余额\n")
        
        print("Step 2️⃣ 配置品牌信息")
        print("-" * 40)
        print("  需要提供您的公司/品牌名称\n")
        
        print("="*60)
        print("📝 配置命令示例：")
        print()
        print("  # 完整配置（API Key + 品牌）：")
        print("  python scripts/generate.py \\")
        print('    --api-key "your-api-key-here" \\')
        print('    --brand "您的公司名称"')
        print()
        print("  # 单独配置 API Key：")
        print('  python scripts/generate.py --api-key "your-api-key-here"')
        print()
        print("  # 单独配置品牌：")
        print('  python scripts/generate.py --brand "您的公司名称"')
        print("="*60)
        print()
        print("💡 提示：API Key 和品牌配置只需完成一次，之后直接生成海报即可")
        return
    
    config = result
    
    # === 检查余额 ===
    print("\n📋 检查豆包服务状态...")
    print("  ⚠️  请确保您的豆包账户有足够余额")
    print("  💰  SeedImage 服务按次计费，请先充值")
    print()
    
    # === 加载节日数据 ===
    festivals = load_festivals()
    
    if args.list:
        print("\n支持的节日列表：")
        print("\n传统节日（15个）：")
        for f in festivals[:15]:
            print(f"  • {f['name']} - {f['blessing']}")
        print("\n节气（23个）：")
        for f in festivals[15:]:
            print(f"  • {f['name']} - {f['blessing']}")
        print(f"\n总计：{len(festivals)} 个节日/节气")
        return
    
    # === 检查品牌配置 ===
    brand = load_brand()
    
    if not brand and not args.brand:
        print("\n" + "="*60)
        print("📋 请先配置品牌信息")
        print("="*60)
        print()
        print("  配置命令：")
        print('  python scripts/generate.py --brand "您的公司名称"')
        print()
        print("  可选：添加 Logo 图片")
        print('  python scripts/generate.py --brand "公司名" --logo ~/logo.png')
        print("="*60)
        return
    
    if args.brand:
        brand = save_brand(args.brand, args.logo)
        print(f"\n✅ 品牌信息已保存：{args.brand}")
    
    # === 选择节日 ===
    festival = None
    
    if args.random or not args.festival:
        festival = random.choice(festivals)
        print(f"\n🎲 随机选择：{festival['name']}")
    else:
        for f in festivals:
            if args.festival in f["name"] or f["name"] in args.festival:
                festival = f
                break
        
        if not festival:
            print(f"\n❌ 未找到节日：{args.festival}")
            print("   使用 --list 查看所有支持的节日")
            return
    
    # === 生成海报 ===
    print(f"\n🎨 正在生成 {festival['name']} 海报...")
    print("   使用豆包 Doubao SeedImage AI 生图...")
    
    # 生成提示词
    prompt = generate_seedimage_prompt(festival, brand)
    print(f"\n📝 提示词已生成（{len(prompt)} 字符）")
    
    # 调用 API
    print(f"\n⏳ 正在调用豆包 API，请稍候...")
    resp, endpoint = call_doubao_api(prompt, config)
    
    # 解析响应
    if "error" in resp:
        error_msg = resp.get("error", {}).get("message", resp.get("error", "未知错误"))
        print(f"\n❌ API 错误：{error_msg}")
        return
    
    resp_metadata = resp.get("ResponseMetadata", {})
    if resp_metadata.get("Error"):
        error = resp_metadata["Error"]
        print(f"\n❌ API 错误：{error.get('Message', '未知错误')} (Code: {error.get('Code', '')})")
        return
    
    # 获取图片URL或数据 - 豆包 API 返回格式
    image_url = None
    image_data = None
    
    # 尝试多种可能的返回格式
    if resp.get("data"):
        data = resp["data"]
        if isinstance(data, list) and len(data) > 0:
            image_url = data[0].get("url")
            image_data = data[0].get("b64_json")
        elif isinstance(data, dict):
            image_url = data.get("url")
            image_data = data.get("b64_json")
    
    if not image_url and not image_data:
        # 尝试其他格式
        choices = resp.get("choices", [])
        if choices and len(choices) > 0:
            message = choices[0].get("message", {})
            content = message.get("content", "")
            if isinstance(content, str):
                # 检查是否包含 URL
                if "http" in content:
                    import re
                    urls = re.findall(r'https?://[^\s\)]+', content)
                    if urls:
                        image_url = urls[0]
                # 检查是否是 base64
                elif "," in content:
                    image_data = content
    
    if not image_url and not image_data:
        print(f"\n❌ 未获取到图片")
        print(f"响应内容：{json.dumps(resp, ensure_ascii=False)[:800]}")
        return
    
    # 下载/保存图片
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    final_filename = f"{festival['name']}_{timestamp}.png"
    final_path = OUTPUT_DIR / final_filename
    
    if image_data:
        # 直接使用 base64 数据
        try:
            with open(final_path, 'wb') as f:
                f.write(b64decode(image_data))
            print(f"\n✅ 图片已生成")
        except Exception as e:
            print(f"\n❌ 保存图片失败: {e}")
            return
    else:
        print(f"\n📥 下载图片...")
        if not download_image(image_url, final_path):
            print(f"\n❌ 下载图片失败")
            return
    
    # 合成最终海报
    print(f"\n🖼️  合成海报...")
    if composite_poster(final_path, brand, festival, final_path):
        print(f"\n" + "="*50)
        print("✅ 海报生成成功！")
        print("="*50)
        print(f"\n📁 文件：{final_path}")
        print(f"📐 尺寸：{POSTER_WIDTH}×{POSTER_HEIGHT}px")
        print(f"🏷️  节日：{festival['name']}")
        print(f"🏢 品牌：{brand['company_name']}")
        print(f"💬 祝福：{festival['blessing']}")
        print("="*50)
    else:
        print(f"\n❌ 合成海报失败")


if __name__ == "__main__":
    main()
