#!/usr/bin/env node
/**
 * VCStat - Claude Code Session Statistics Analyzer
 *
 * 分析Claude Code会话数据，生成统计报告
 *
 * 功能：
 * - Token消耗统计（输入/输出/缓存）
 * - 技能/规则使用追踪
 * - 文档引用分析
 * - 文档有效性评分
 * - 多会话聚合统计
 * - 历史记录管理
 */

import fs from 'fs';
import os from 'os';
import path from 'path';
import readline from 'readline';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ---------------------------------------------------------------------------
// CLI 参数解析
// ---------------------------------------------------------------------------
const argv = process.argv.slice(2);

function flag(name, dflt) {
  const i = argv.indexOf(name);
  if (i === -1) return dflt;
  const v = argv[i + 1];
  return v === undefined || v.startsWith('--') ? true : v;
}

const MODE = flag('--mode', 'basic');
const SESSION_ID = flag('--session', null);
const PROJECTS_DIR = flag('--projects-dir', path.join(os.homedir(), '.claude', 'projects'));
const LIMIT = parseInt(flag('--limit', MODE === 'aggregate' ? 10 : 20), 10);
const SHOW_PROGRESS = !argv.includes('--no-progress');
const NO_SAVE = argv.includes('--no-save');

// ---------------------------------------------------------------------------
// 数据目录
// ---------------------------------------------------------------------------
const DATA_DIR = path.join(os.homedir(), '.claude', 'plugins', 'data', 'VCStat');
const REPORTS_DIR = path.join(DATA_DIR, 'reports');
const INDEX_PATH = path.join(REPORTS_DIR, 'index.json');

// ---------------------------------------------------------------------------
// 工具函数
// ---------------------------------------------------------------------------
function fmt(n) {
  if (n >= 1e9) return (n / 1e9).toFixed(2) + 'B';
  if (n >= 1e6) return (n / 1e6).toFixed(2) + 'M';
  if (n >= 1e3) return (n / 1e3).toFixed(1) + 'k';
  return String(n);
}

function pct(a, b) {
  return b > 0 ? ((100 * a) / b).toFixed(1) + '%' : '—';
}

function ensureDir(dir) {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

function formatDate(isoString) {
  const d = new Date(isoString);
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  const hh = String(d.getHours()).padStart(2, '0');
  const mi = String(d.getMinutes()).padStart(2, '0');
  return `${mm}-${dd} ${hh}:${mi}`;
}

// ---------------------------------------------------------------------------
// 数据结构
// ---------------------------------------------------------------------------
function createSessionStats() {
  return {
    sessionId: null,
    projectPath: null,
    timestamp: null,
    tokens: {
      input: 0,
      output: 0,
      cacheCreate: 0,
      cacheRead: 0,
      total: 0
    },
    skills: new Map(),
    rules: {
      globalClaudeMd: false,
      localClaudeMd: false,
      rulesFiles: [],
      hooks: [],
      mcpServers: []
    },
    documents: new Map(),
    messageCount: 0,
    humanMessages: 0,
    assistantMessages: 0,
    toolCalls: {
      Read: 0,
      Write: 0,
      Bash: 0,
      Skill: 0,
      other: 0
    }
  };
}

// ---------------------------------------------------------------------------
// ASCII 边框绘制
// ---------------------------------------------------------------------------
function drawBox(width, title) {
  const line = '─'.repeat(width - 2);
  const titleLen = title ? title.length : 0;
  let top = '╭' + line + '╮';
  let bottom = '╰' + line + '╯';

  if (title && titleLen > 0) {
    const padding = Math.max(0, width - titleLen - 4);
    const leftPad = Math.floor(padding / 2);
    const rightPad = padding - leftPad;
    top = '╭' + '─'.repeat(leftPad) + title + '─'.repeat(rightPad) + '╮';
  }

  return { top, bottom, divider: '├' + line + '┤', spacer: '│' + ' '.repeat(width - 2) + '│' };
}

// ---------------------------------------------------------------------------
// JSONL 解析器
// ---------------------------------------------------------------------------
async function parseSessionFile(filePath) {
  const stats = createSessionStats();

  if (!fs.existsSync(filePath)) {
    return { error: 'Session file not found' };
  }

  // 从文件名提取session ID
  const filename = path.basename(filePath, '.jsonl');
  if (!filename.includes('subagents')) {
    stats.sessionId = filename;
  }

  const rl = readline.createInterface({
    input: fs.createReadStream(filePath, { encoding: 'utf-8' }),
    crlfDelay: Infinity
  });

  const seenRequestIds = new Set();
  let firstTimestamp = null;

  for await (const line of rl) {
    if (!line.trim()) continue;

    try {
      const entry = JSON.parse(line);

      // 记录项目路径
      if (entry.project) {
        stats.projectPath = entry.project;
      }

      // 记录第一个时间戳
      if (entry.timestamp && !firstTimestamp) {
        stats.timestamp = entry.timestamp;
        firstTimestamp = entry.timestamp;
      }

      // 处理用户消息
      if (entry.type === 'user') {
        stats.messageCount++;
        stats.humanMessages++;

        // 检测技能列表附件
        if (entry.attachment && entry.attachment.type === 'skill_listing') {
          const content = entry.attachment.content || '';
          const skillMatches = content.match(/^- (\w+):/g);
          if (skillMatches) {
            skillMatches.forEach(match => {
              const skillName = match.replace(/^- (\w+):/, '$1').trim();
              if (!stats.skills.has(skillName)) {
                stats.skills.set(skillName, { count: 0, tokens: 0 });
              }
              stats.skills.get(skillName).count++;
            });
          }
        }
      }

      // 处理助手消息
      if (entry.type === 'assistant') {
        stats.messageCount++;
        stats.assistantMessages++;

        const msg = entry.message || {};
        const usage = msg.usage || {};
        const content = msg.content || [];

        // Token 统计
        const requestId = entry.requestId || msg?.id || `manual-${entry.uuid}`;
        if (!seenRequestIds.has(requestId)) {
          seenRequestIds.add(requestId);

          stats.tokens.input += usage.input_tokens || 0;
          stats.tokens.output += usage.output_tokens || 0;
          stats.tokens.cacheCreate += usage.cache_creation_input_tokens || 0;
          stats.tokens.cacheRead += usage.cache_read_input_tokens || 0;
        }

        // 处理工具调用
        if (Array.isArray(content)) {
          for (const item of content) {
            if (item.type === 'tool_use') {
              const toolName = item.name;

              // 统计工具调用
              if (stats.toolCalls.hasOwnProperty(toolName)) {
                stats.toolCalls[toolName]++;
              } else {
                stats.toolCalls.other++;
              }

              // 检测 Skill 工具调用
              if (toolName === 'Skill' && item.input?.skill) {
                const skillName = item.input.skill;
                if (!stats.skills.has(skillName)) {
                  stats.skills.set(skillName, { count: 0, tokens: 0 });
                }
                stats.skills.get(skillName).count++;

                // 关联token
                const tokens = (usage.input_tokens || 0) + (usage.output_tokens || 0);
                stats.skills.get(skillName).tokens += tokens;
              }

              // 检测 Read 工具调用（文档）
              if (toolName === 'Read' && item.input?.file_path) {
                const filePath = item.input.file_path;
                trackDocumentRead(stats, filePath, entry.timestamp, usage);
              }
            }
          }
        }
      }
    } catch (e) {
      // 跳过格式错误的行
    }
  }

  // 计算总token
  stats.tokens.total = stats.tokens.input + stats.tokens.output;

  return stats;
}

function trackDocumentRead(stats, filePath, timestamp, usage) {
  if (!stats.documents.has(filePath)) {
    stats.documents.set(filePath, {
      readCount: 0,
      totalChars: 0,
      estimatedReferencedChars: 0,
      contentRatio: 0,
      tokensSpent: 0,
      effectivenessScore: 0,
      readFrequencyScore: 0,
      contentRatioScore: 0,
      tokenScore: 0,
      timeDispersionScore: 0,
      firstReadTimestamp: timestamp,
      lastReadTimestamp: timestamp
    });
  }

  const doc = stats.documents.get(filePath);
  doc.readCount++;
  doc.lastReadTimestamp = timestamp;

  // 累加token消耗
  const tokens = (usage.input_tokens || 0) + (usage.cache_creation_input_tokens || 0);
  doc.tokensSpent += tokens;
}

// ---------------------------------------------------------------------------
// 规则检测
// ---------------------------------------------------------------------------
function detectRules(stats, projectPath) {
  if (!projectPath) return;

  // 检查全局 CLAUDE.md
  const globalClaudeMd = path.join(os.homedir(), '.claude', 'CLAUDE.md');
  stats.rules.globalClaudeMd = fs.existsSync(globalClaudeMd);

  // 检查本地 CLAUDE.md
  const localClaudeMd = path.join(projectPath, 'CLAUDE.md');
  stats.rules.localClaudeMd = fs.existsSync(localClaudeMd);

  // 检查 rules 目录
  const rulesDir = path.join(projectPath, '.claude', 'rules');
  if (fs.existsSync(rulesDir)) {
    try {
      const ruleFiles = fs.readdirSync(rulesDir)
        .filter(f => f.endsWith('.md'))
        .map(f => f.replace('.md', ''));
      stats.rules.rulesFiles = ruleFiles;
    } catch (e) {
      stats.rules.rulesFiles = [];
    }
  }

  // 检查 settings.json
  const settingsFile = path.join(projectPath, '.claude', 'settings.json');
  if (fs.existsSync(settingsFile)) {
    try {
      const settings = JSON.parse(fs.readFileSync(settingsFile, 'utf-8'));
      if (settings.hooks && Object.keys(settings.hooks).length > 0) {
        stats.rules.hooks = Object.keys(settings.hooks);
      }
      if (settings.mcpServers) {
        stats.rules.mcpServers = Object.keys(settings.mcpServers);
      }
    } catch (e) {
      // 忽略解析错误
    }
  }
}

// ---------------------------------------------------------------------------
// 文档分析
// ---------------------------------------------------------------------------
function analyzeDocuments(stats, totalTokens) {
  for (const [filePath, doc] of stats.documents) {
    try {
      // 读取文件内容获取总字符数
      if (fs.existsSync(filePath)) {
        const content = fs.readFileSync(filePath, 'utf-8');
        doc.totalChars = content.length;
      } else {
        doc.totalChars = 0;
      }

      // 计算引用字符数（基于token估算）
      // 1 token ≈ 4 字符，应用效率因子
      const avgTokensPerRead = doc.tokensSpent / doc.readCount;

      if (doc.readCount === 1) {
        // 单次读取：可能读取大部分内容
        doc.estimatedReferencedChars = Math.min(
          doc.totalChars,
          avgTokensPerRead * 4 * 0.8
        );
      } else {
        // 多次读取：首次读取完整，后续可能是缓存片段
        const firstReadTokens = doc.tokensSpent * 0.6;
        const cachedReadTokens = doc.tokensSpent * 0.4;
        doc.estimatedReferencedChars = Math.min(
          doc.totalChars,
          (firstReadTokens * 4 * 0.8) + (cachedReadTokens * 4 * 0.3)
        );
      }

      // 计算内容占比
      doc.contentRatio = doc.totalChars > 0
        ? doc.estimatedReferencedChars / doc.totalChars
        : 0;

      // 计算各维度得分

      // 1. 读取频率得分 (25%)
      doc.readFrequencyScore = Math.min(1.0, Math.log(doc.readCount + 1) / Math.log(5));

      // 2. 内容占比得分 (25%)
      doc.contentRatioScore = 0.5 + (doc.contentRatio * 0.5);

      // 3. Token消耗得分 (30%)
      const tokenProportion = totalTokens > 0 ? doc.tokensSpent / totalTokens : 0;
      let tokenScore;
      if (tokenProportion < 0.001) {
        tokenScore = 0.3;
      } else if (tokenProportion < 0.01) {
        tokenScore = 0.5 + (tokenProportion * 50);
      } else if (tokenProportion < 0.05) {
        tokenScore = 1.0 - ((tokenProportion - 0.01) * 10);
      } else {
        tokenScore = Math.max(0.1, 0.6 - ((tokenProportion - 0.05) * 5));
      }
      doc.tokenScore = Math.max(0.1, Math.min(1.0, tokenScore));

      // 4. 时间分散度得分 (20%)
      if (doc.readCount > 1 && doc.firstReadTimestamp && doc.lastReadTimestamp) {
        const timeSpan = new Date(doc.lastReadTimestamp) - new Date(doc.firstReadTimestamp);
        doc.timeDispersionScore = Math.min(1.0, timeSpan / (60 * 1000 * 60));
      } else {
        doc.timeDispersionScore = 0.1;
      }

      // 综合得分
      doc.effectivenessScore = Math.round(
        (doc.readFrequencyScore * 0.25 +
         doc.contentRatioScore * 0.25 +
         doc.tokenScore * 0.30 +
         doc.timeDispersionScore * 0.20) * 100
      ) / 100;

    } catch (e) {
      // 文件读取失败
      doc.totalChars = 0;
      doc.contentRatio = 0;
      doc.effectivenessScore = 0;
    }
  }
}

// ---------------------------------------------------------------------------
// 会话查找
// ---------------------------------------------------------------------------
function findSession(sessionId, projectsDir) {
  const sessions = [];

  function walk(dir) {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        walk(fullPath);
      } else if (entry.isFile() && entry.name === `${sessionId}.jsonl`) {
        sessions.push(fullPath);
      }
    }
  }

  walk(projectsDir);
  return sessions[0] || null;
}

function getAllSessions(projectsDir, limit) {
  const sessions = [];

  function walk(dir) {
    try {
      const entries = fs.readdirSync(dir, { withFileTypes: true });
      for (const entry of entries) {
        const fullPath = path.join(dir, entry.name);
        if (entry.isDirectory() && !entry.name.startsWith('.')) {
          walk(fullPath);
        } else if (entry.isFile() && entry.name.endsWith('.jsonl') && !fullPath.includes('subagents')) {
          sessions.push({
            path: fullPath,
            birthtime: fs.statSync(fullPath).birthtimeMs
          });
        }
      }
    } catch (e) {
      // 忽略无权访问的目录
    }
  }

  walk(projectsDir);

  // 按修改时间排序，取最近的N个
  sessions.sort((a, b) => b.birthtime - a.birthtime);
  return sessions.slice(0, limit);
}

// ---------------------------------------------------------------------------
// 输出格式化 - 基本模式
// ---------------------------------------------------------------------------
function formatBasicOutput(stats) {
  const width = 65;
  const { top, bottom, divider, spacer } = drawBox(width, 'VCS - 会话统计');

  let output = '\n';
  output += top + '\n';
  output += '│ 会话ID:  ' + (stats.sessionId || '未知').padEnd(45) + '│\n';
  output += '│ 项目:     ' + (stats.projectPath || '未知').padEnd(45) + '│\n';
  output += '│ 时间:     ' + (stats.timestamp ? formatDate(stats.timestamp) : '未知').padEnd(45) + '│\n';
  output += divider + '\n';
  output += '│ TOKENS                                                        │\n';
  output += '│ Input:        ' + fmt(stats.tokens.input).padStart(10) + '  (Uncached: ' + fmt(stats.tokens.input - stats.tokens.cacheCreate - stats.tokens.cacheRead).padStart(10) + '  Cached: ' + fmt(stats.tokens.cacheCreate + stats.tokens.cacheRead).padStart(8) + ')          │\n';
  output += '│ Output:       ' + fmt(stats.tokens.output).padStart(47) + '│\n';
  output += '│ Cache Create: ' + fmt(stats.tokens.cacheCreate).padStart(47) + '│\n';
  output += '│ Cache Read:   ' + fmt(stats.tokens.cacheRead).padStart(47) + '│\n';
  output += '│ Total:        ' + fmt(stats.tokens.total).padStart(47) + '│\n';
  output += divider + '\n';
  output += '│ SKILLS                                                        │\n';

  if (stats.skills.size === 0) {
    output += spacer + '\n';
  } else {
    const skillList = Array.from(stats.skills.entries()).slice(0, 5);
    for (const [name, data] of skillList) {
      output += '│ ' + name.padEnd(40) + data.count + ' 调用  (' + fmt(data.tokens) + ' tokens)        │\n';
    }
    if (stats.skills.size > 5) {
      output += '│ ... 还有 ' + (stats.skills.size - 5) + ' 个技能                                              │\n';
    }
  }

  output += divider + '\n';
  output += '│ RULES                                                         │\n';
  output += '│ 全局CLAUDE.md:     ' + (stats.rules.globalClaudeMd ? '是' : '否').padEnd(39) + '│\n';
  output += '│ 本地CLAUDE.md:      ' + (stats.rules.localClaudeMd ? '是' : '否').padEnd(39) + '│\n';
  output += '│ 规则文件:          ' + stats.rules.rulesFiles.length + ' 个' + ''.padEnd(39) + '│\n';
  output += '│ Hooks:             ' + stats.rules.hooks.length + ' 个' + ''.padEnd(39) + '│\n';
  output += '│ MCP服务器:         ' + stats.rules.mcpServers.length + ' 个' + ''.padEnd(39) + '│\n';
  output += divider + '\n';
  output += '│ DOCUMENTS                                                     │\n';
  output += '│ 唯一文档数:        ' + stats.documents.size + ''.padEnd(47) + '│\n';
  output += '│ 总读取次数:        ' + Array.from(stats.documents.values()).reduce((sum, d) => sum + d.readCount, 0) + ''.padEnd(47) + '│\n';

  const docTokens = Array.from(stats.documents.values()).reduce((sum, d) => sum + d.tokensSpent, 0);
  output += '│ 文档Token:         ' + fmt(docTokens) + ''.padEnd(47) + '│\n';

  if (stats.documents.size > 0) {
    const topDoc = Array.from(stats.documents.entries())
      .sort((a, b) => b[1].tokensSpent - a[1].tokensSpent)[0];
    const docName = path.basename(topDoc[0]);
    output += '│ 最多Token文档:     ' + (docName.length > 40 ? docName.slice(0, 37) + '...' : docName).padEnd(40) + fmt(topDoc[1].tokensSpent) + '│\n';
  }

  output += bottom + '\n';
  output += '\n';

  return output;
}

// ---------------------------------------------------------------------------
// 输出格式化 - 详细模式 (与 SKILL.md 模板一致)
// ---------------------------------------------------------------------------
function formatDetailOutput(stats) {
  // 分类文档 - HTML文件归入代码类
  const codeExtensions = ['.js', '.mjs', '.cjs', '.ts', '.tsx', '.jsx', '.py', '.java', '.go', '.rs', '.c', '.cpp', '.h', '.hpp', '.cs', '.php', '.rb', '.swift', '.kt', '.scala', '.sh', '.bash', '.json', '.yaml', '.yml', '.toml', '.xml', '.html'];
  const codeDocs = [];
  const nonCodeDocs = [];
  const totalDocTokens = Array.from(stats.documents.values()).reduce((sum, d) => sum + d.tokensSpent, 0);

  for (const [filePath, doc] of stats.documents) {
    const ext = path.extname(filePath).toLowerCase();
    if (codeExtensions.includes(ext)) {
      codeDocs.push([filePath, doc]);
    } else {
      nonCodeDocs.push([filePath, doc]);
    }
  }

  codeDocs.sort((a, b) => b[1].tokensSpent - a[1].tokensSpent);
  nonCodeDocs.sort((a, b) => b[1].tokensSpent - a[1].tokensSpent);

  // 计算Token百分比
  const codeDocTokens = codeDocs.reduce((sum, [, d]) => sum + d.tokensSpent, 0);
  const nonCodeDocTokens = nonCodeDocs.reduce((sum, [, d]) => sum + d.tokensSpent, 0);

  // 缓存效率
  const uncachedTokens = stats.tokens.input - stats.tokens.cacheCreate - stats.tokens.cacheRead;
  const savingsPct = stats.tokens.input > 0 ? Math.round((1 - uncachedTokens / stats.tokens.input) * 100) : 0;

  // 非代码文档有效性
  const nonCodeAvgEffectiveness = nonCodeDocs.length > 0
    ? nonCodeDocs.reduce((sum, [, d]) => sum + d.effectivenessScore, 0) / nonCodeDocs.length
    : 0;

  // 工具使用统计
  const totalToolCalls = stats.toolCalls.Read + stats.toolCalls.Write + stats.toolCalls.Bash + stats.toolCalls.Skill + stats.toolCalls.other;
  const noToolMessages = stats.messageCount - totalToolCalls;

  // 辅助函数
  const formatFileSize = (bytes) => {
    if (!bytes || bytes === 0) return '-';
    if (bytes >= 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(2) + ' KB';
    if (bytes >= 1024) return (bytes / 1024).toFixed(2) + ' KB';
    return bytes + ' B';
  };

  const truncateFileName = (name, maxLen = 28) => {
    if (name.length <= maxLen) return name;
    return name.slice(0, maxLen - 3) + '...';
  };

  let output = '\n';

  // ═══════════════════════════════════════════════════════════════════
  output += '══════════════════════════════════════════════════════════════════\n';
  output += '                        📊 VCS 详细会话分析报告\n';
  output += '══════════════════════════════════════════════════════════════════\n\n';

  // 📈 核心指标概览
  output += '📈 核心指标概览\n';
  output += '──────────────────────────────────────────────────────────────────────\n';
  output += `会话ID: ${stats.sessionId || '未知'}\n`;
  output += `项目路径: ${stats.projectPath || '未知'}\n`;
  output += `时间跨度: ${stats.timestamp ? formatDate(stats.timestamp) : '未知'}\n`;
  output += `消息数: ${stats.messageCount} (用户: ${stats.humanMessages} 助手: ${stats.assistantMessages})\n\n`;

  output += 'Token 消耗：\n';
  output += `- 总计: ${fmt(stats.tokens.total)}\n`;
  output += `- 输入: ${fmt(stats.tokens.input)} (${pct(stats.tokens.input, stats.tokens.total)})\n`;
  output += `- 输出: ${fmt(stats.tokens.output)} (${pct(stats.tokens.output, stats.tokens.total)})\n\n`;

  output += '缓存效果 ⭐：\n';
  output += `- Cache Created: ${fmt(stats.tokens.cacheCreate)} (${pct(stats.tokens.cacheCreate, stats.tokens.input)})\n`;
  output += `- Cache Read: ${fmt(stats.tokens.cacheRead)} (${pct(stats.tokens.cacheRead, stats.tokens.input)})\n`;
  output += `- Uncached: ${fmt(uncachedTokens)} (节省 ${savingsPct}%)\n`;

  output += '\n---\n';

  // 🛠️ 开发流程完整性分析
  output += '🛠️ 开发流程完整性分析\n\n';
  output += '技能使用时间线：\n';
  output += '┌────────────┬───────────────┬────────────┬──────────────────┐\n';
  output += '│    时间    │     技能      │ Token 消耗 │       作用       │\n';
  output += '├────────────┼───────────────┼────────────┼──────────────────┤\n';

  if (stats.skills.size === 0) {
    output += '│ 无技能使用                                              │\n';
  } else {
    for (const [name, data] of stats.skills) {
      const skillTime = stats.timestamp ? formatDate(stats.timestamp) : '-';
      const skillDesc = name === 'superpowers' ? '会话启动引导' :
                        name === 'vcs' ? '会话统计' : '技能调用';
      output += `│ ${skillTime.padEnd(10)} │ ${name.padEnd(13)} │ ${fmt(data.tokens).padEnd(10)} │ ${skillDesc.padEnd(16)} │\n`;
    }
  }
  output += '└────────────┴───────────────┴────────────┴──────────────────┘\n';

  output += '\n---\n';

  // 📚 文档使用深度分析
  output += '📚 文档使用深度分析\n\n';

  // 代码类文件
  const codeDocPct = totalDocTokens > 0 ? pct(codeDocTokens, totalDocTokens) : '0%';
  output += `🔍 代码类文件（${codeDocs.length} 个，${codeDocPct} 文档Token）\n\n`;
  output += 'Top 5 核心代码文件：\n';
  output += '┌─────┬────────────────────────────┬──────────┬────────────┬───────┬──────────┬─────────┬─────────────┐\n';
  output += '│  #  │            文件            │ 读取次数 │ Token 消耗 │ 占比  │   大小   │ 有效性  │  首次读取   │\n';
  output += '├─────┼────────────────────────────┼──────────┼────────────┼───────┼──────────┼─────────┼─────────────┤\n';

  if (codeDocs.length === 0) {
    output += '│ 无代码文件                                                           │\n';
  } else {
    for (let i = 0; i < Math.min(codeDocs.length, 5); i++) {
      const [filePath, doc] = codeDocs[i];
      const docName = truncateFileName(path.basename(filePath), 28);
      const tokenPct = pct(doc.tokensSpent, totalDocTokens);
      const firstRead = doc.firstReadTimestamp ? formatDate(doc.firstReadTimestamp) : '-';
      output += `│ ${String(i + 1).padStart(2)}  │ ${docName.padEnd(28)} │ ${String(doc.readCount).padEnd(8)} │ ${fmt(doc.tokensSpent).padEnd(10)} │ ${tokenPct.padEnd(5)} │ ${formatFileSize(doc.totalChars).padEnd(8)} │ ${String(doc.effectivenessScore).padEnd(7)} │ ${firstRead.padEnd(11)} │\n`;
    }
  }
  output += '└─────┴────────────────────────────┴──────────┴────────────┴───────┴──────────┴─────────┴─────────────┘\n\n';

  // 非代码类文件
  const nonCodeDocPct = totalDocTokens > 0 ? pct(nonCodeDocTokens, totalDocTokens) : '0%';
  output += `📄 非代码类文件（${nonCodeDocs.length} 个，${nonCodeDocPct} 文档Token）\n\n`;
  output += 'Top 5 非代码文件：\n';
  output += '┌─────┬────────────────────────────┬──────────┬────────────┬───────┬──────────┬─────────┬─────────────┐\n';
  output += '│  #  │            文件            │ 读取次数 │ Token 消耗 │ 占比  │   大小   │ 有效性  │  首次读取   │\n';
  output += '├─────┼────────────────────────────┼──────────┼────────────┼───────┼──────────┼─────────┼─────────────┤\n';

  if (nonCodeDocs.length === 0) {
    output += '│ 无非代码文件                                                         │\n';
  } else {
    for (let i = 0; i < Math.min(nonCodeDocs.length, 5); i++) {
      const [filePath, doc] = nonCodeDocs[i];
      const docName = truncateFileName(path.basename(filePath), 28);
      const tokenPct = pct(doc.tokensSpent, totalDocTokens);
      const firstRead = doc.firstReadTimestamp ? formatDate(doc.firstReadTimestamp) : '-';
      output += `│ ${String(i + 1).padStart(2)}  │ ${docName.padEnd(28)} │ ${String(doc.readCount).padEnd(8)} │ ${fmt(doc.tokensSpent).padEnd(10)} │ ${tokenPct.padEnd(5)} │ ${formatFileSize(doc.totalChars).padEnd(8)} │ ${String(doc.effectivenessScore).padEnd(7)} │ ${firstRead.padEnd(11)} │\n`;
    }
  }
  output += '└─────┴────────────────────────────┴──────────┴────────────┴───────┴──────────┴─────────┴─────────────┘\n\n';

  // 关键发现
  output += '关键发现：\n';
  if (codeDocs.length > 0) {
    const topCodeDoc = codeDocs[0];
    output += `- ✅ 代码文件 ${path.basename(topCodeDoc[0])} 是主要工作文件，消耗 ${pct(codeDocTokens, totalDocTokens)} 的文档Token\n`;
  }
  if (nonCodeDocs.length > 0) {
    const avgNonCodeEff = nonCodeDocs.reduce((sum, [, d]) => sum + d.effectivenessScore, 0) / nonCodeDocs.length;
    if (avgNonCodeEff >= 0.7) {
      output += `✅ 非代码文件使用效率较高（有效性 ${avgNonCodeEff.toFixed(2)}）\n`;
    }
  }
  if (stats.documents.size === 0) {
    output += `⚠️ 会话中未读取任何文档\n`;
  }

  output += '\n---\n';

  // 📊 文档使用效率分析
  output += '📊 文档使用效率分析\n\n';
  output += '按文件类型统计（代码类文件不计入有效性分析）\n';
  output += '┌──────────┬────────┬──────────┬────────────┬───────┐\n';
  output += '│   类型   │ 文件数 │ 读取次数 │ Token 消耗 │ 占比  │\n';
  output += '├──────────┼────────┼──────────┼────────────┼────────────┼──────────────────────────┤\n';
  output += `│ 代码类   │ ${String(codeDocs.length).padEnd(6)} │ ${String(codeDocs.reduce((s, [, d]) => s + d.readCount, 0)).padEnd(8)} │ ${fmt(codeDocTokens).padEnd(10)} │ ${pct(codeDocTokens, totalDocTokens).padEnd(6)} │  (不计入有效性分析)\n`;
  output += `│ 非代码类 │ ${String(nonCodeDocs.length).padEnd(6)} │ ${String(nonCodeDocs.reduce((s, [, d]) => s + d.readCount, 0)).padEnd(8)} │ ${fmt(nonCodeDocTokens).padEnd(10)} │ ${pct(nonCodeDocTokens, totalDocTokens).padEnd(6)} │\n`;
  output += `│ 总计     │ ${String(stats.documents.size).padEnd(6)} │ ${String(Array.from(stats.documents.values()).reduce((s, d) => s + d.readCount, 0)).padEnd(8)} │ ${fmt(totalDocTokens).padEnd(10)} │ 100%  │\n`;
  output += '└──────────┴────────┴──────────┴────────────┴───────┘\n\n';

  // 非代码类文档有效性分析
  output += '**非代码类文档有效性分析（排除代码类文件）：**\n\n';

  const highEffDocs = nonCodeDocs.filter(([, d]) => d.effectivenessScore >= 0.80);
  const mediumEffDocs = nonCodeDocs.filter(([, d]) => d.effectivenessScore >= 0.60 && d.effectivenessScore < 0.80);
  const lowEffDocs = nonCodeDocs.filter(([, d]) => d.effectivenessScore < 0.60);

  output += '高有效性文档 (≥0.80)：\n';
  if (highEffDocs.length === 0) {
    output += '- 无\n';
  } else {
    for (const [fp, d] of highEffDocs) {
      output += `- ${path.basename(fp)} (${d.effectivenessScore}) - 高频使用文档\n`;
    }
  }
  output += '\n';

  output += '中等有效性文档 (0.60-0.79)：\n';
  if (mediumEffDocs.length === 0) {
    output += '- 无\n';
  } else {
    for (const [fp, d] of mediumEffDocs) {
      output += `- ${path.basename(fp)} (${d.effectivenessScore})\n`;
    }
  }
  output += '\n';

  output += '低有效性文档 (<0.60)：\n';
  if (lowEffDocs.length === 0) {
    output += '- 无\n';
  } else {
    for (const [fp, d] of lowEffDocs) {
      output += `- ${path.basename(fp)} (${d.effectivenessScore}) ⚠️\n`;
    }
  }

  output += '\n💡 改进建议（仅针对非代码类文档，排除代码类文件）：\n';
  if (nonCodeDocs.length === 0) {
    output += '- 无非代码类文档可分析\n';
  } else if (nonCodeAvgEffectiveness >= 0.80) {
    output += '- 非代码类文档有效性优秀，无需特别优化\n';
  } else if (nonCodeAvgEffectiveness >= 0.60) {
    output += '- 非代码类文档整体有效性良好，可进一步优化文档结构\n';
  } else {
    output += '- 非代码类文档有效性偏低，建议优化文档结构化程度\n';
  }

  output += '\n---\n';

  // 🔧 工具使用效率分析
  output += '🔧 工具使用效率分析\n\n';
  output += '┌────────────┬──────────┬───────┬───────────────────────────┐\n';
  output += '│  工具类型  │ 使用次数 │ 占比  │           说明            │\n';
  output += '├────────────┼──────────┼───────┼───────────────────────────┤\n';
  output += `│ Read       │ ${String(stats.toolCalls.Read).padEnd(8)} │ ${pct(stats.toolCalls.Read, stats.messageCount).padEnd(5)} │ 文档读取 (${stats.documents.size} 个唯一文档) │\n`;
  output += `│ Bash       │ ${String(stats.toolCalls.Bash).padEnd(8)} │ ${pct(stats.toolCalls.Bash, stats.messageCount).padEnd(5)} │ 命令执行                    │\n`;
  output += `│ Skill      │ ${String(stats.toolCalls.Skill).padEnd(8)} │ ${pct(stats.toolCalls.Skill, stats.messageCount).padEnd(5)} │ 技能调用                    │\n`;
  output += `│ Other      │ ${String(stats.toolCalls.other).padEnd(8)} │ ${pct(stats.toolCalls.other, stats.messageCount).padEnd(5)} │ 其他工具                    │\n`;
  output += `│ 未使用工具 │ ${String(noToolMessages).padEnd(8)} │ ${pct(noToolMessages, stats.messageCount).padEnd(5)} │ 纯文本对话                  │\n`;
  output += '└────────────┴──────────┴───────┴───────────────────────────┘\n';

  output += '\n---\n';

  // 💡 关键洞察与发现
  output += '💡 关键洞察与发现\n\n';
  output += '✅ 做得好的地方\n';

  const insights = [];
  if (totalDocTokens / stats.tokens.total >= 0.3 && totalDocTokens / stats.tokens.total <= 0.5) {
    insights.push('文档Token占总Token比例合理，阅读与创作平衡良好');
  }
  if (stats.skills.size > 0) {
    insights.push('使用技能引导会话，流程规范');
  }
  if (nonCodeAvgEffectiveness >= 0.70) {
    insights.push(`非代码类文档有效性达到中等偏上水平（平均 ${nonCodeAvgEffectiveness.toFixed(2)}）`);
  }
  if (insights.length === 0) {
    insights.push('会话包含基本的统计分析数据');
  }
  insights.forEach((insight, i) => {
    output += `${i + 1}. ${insight}\n`;
  });

  output += '\n⚠️ 可优化的地方\n';
  const suggestions = [];
  if (savingsPct < 70) {
    suggestions.push(`缓存效率为 ${savingsPct}%，有提升空间，建议减少单次会话长度`);
  }
  if (noToolMessages / stats.messageCount > 0.5) {
    suggestions.push(`纯文本对话占比较高，可适当增加工具使用`);
  }
  if (stats.documents.size > 20) {
    suggestions.push(`文档使用数量较多（${stats.documents.size} 个），建议优化文档结构`);
  }
  if (suggestions.length === 0) {
    suggestions.push('会话整体表现良好');
  }
  suggestions.forEach((sug, i) => {
    output += `${i + 1}. ${sug}\n`;
  });

  output += '\n---\n';

  // 📊 对比标准分析
  output += '📊 对比标准分析\n\n';
  output += '┌────────────────┬────────────┬───────────┬──────┬──────────────────────────────────────┐\n';
  output += '│      指标      │   本会话   │  理想值   │ 评分 │                 说明                 │\n';
  output += '├────────────────┼────────────┼───────────┼──────┼──────────────────────────────────────┤\n';

  // Token评分
  const tokenRating = stats.tokens.total < 3e6 ? '★★★★★' : stats.tokens.total < 5e6 ? '★★★☆☆' : '★☆☆☆☆';
  const tokenDesc = stats.tokens.total < 3e6 ? '会话长度适中' : stats.tokens.total < 5e6 ? '会话较长，建议拆分' : '会话过长，建议拆分';
  output += `│ 总 Token       │ ${fmt(stats.tokens.total).padEnd(10)} │ <3M       │ ${tokenRating}  │ ${tokenDesc.padEnd(30)} │\n`;

  // 文档占比评分
  const docPct = pct(totalDocTokens, stats.tokens.total);
  const docPctVal = parseFloat(docPct);
  const docRating = docPctVal >= 30 && docPctVal <= 50 ? '★★★★★' : docPctVal >= 20 && docPctVal <= 60 ? '★★★☆☆' : '★☆☆☆☆';
  const docDesc = docPctVal >= 30 && docPctVal <= 50 ? '文档使用比例合理' : '文档使用比例偏高或偏低';
  output += `│ 文档占比       │ ${docPct.padEnd(10)} │ 30-50%    │ ${docRating}  │ ${docDesc.padEnd(30)} │\n`;

  // 有效性评分
  const effRating = nonCodeAvgEffectiveness >= 0.80 ? '★★★★★' : nonCodeAvgEffectiveness >= 0.70 ? '★★★★☆' : nonCodeAvgEffectiveness >= 0.60 ? '★★★☆☆' : '★★☆☆☆';
  const effDesc = nonCodeAvgEffectiveness >= 0.80 ? '非代码文档有效性优秀' : '非代码文档有效性有提升空间';
  output += `│ 平均有效性     │ ${nonCodeAvgEffectiveness.toFixed(2).padEnd(10)} │ >0.80     │ ${effRating}  │ ${effDesc.padEnd(30)} │\n`;

  // 缓存效率评分
  const cacheRating = savingsPct >= 70 ? '★★★★★' : savingsPct >= 50 ? '★★★☆☆' : '★★☆☆☆';
  const cacheDesc = savingsPct >= 70 ? '缓存效率优秀' : savingsPct >= 50 ? '缓存效率中等' : '缓存效率偏低';
  output += `│ 缓存效率       │ ${String(savingsPct + '%').padEnd(10)} │ >70%      │ ${cacheRating}  │ ${cacheDesc.padEnd(30)} │\n`;

  // 技能占比评分
  const skillPct = pct(stats.toolCalls.Skill, stats.messageCount);
  const skillPctVal = parseFloat(skillPct);
  const skillRating = skillPctVal >= 1 && skillPctVal <= 5 ? '★★★★☆' : skillPctVal > 0 ? '★★★☆☆' : '★☆☆☆☆';
  const skillDesc = skillPctVal >= 1 ? '技能使用适度' : '技能使用较少，可考虑使用更多技能';
  output += `│ 技能占比       │ ${skillPct.padEnd(10)} │ 1-5%      │ ${skillRating}  │ ${skillDesc.padEnd(30)} │\n`;
  output += '└────────────────┴────────────┴───────────┴──────┴──────────────────────────────────────┘\n\n';

  // 总体评分
  const totalScore = Math.round((tokenRating.length + docRating.length + effRating.length + cacheRating.length + skillRating.length) / 5);
  output += `总体评分: ${'⭐'.repeat(totalScore)}${'☆'.repeat(5 - totalScore)} (${totalScore}/5)\n`;

  output += '\n---\n';

  // 🎯 具体改进建议
  output += '🎯 具体改进建议\n\n';

  output += '1. 会话拆分策略\n';
  if (stats.tokens.total >= 5e6) {
    output += '建议将会话拆分为 3+ 个更小的子会话，每个会话控制在 2-3M tokens\n';
  } else if (stats.tokens.total >= 3e6) {
    output += '建议将会话拆分为 2 个子会话，每个会话控制在 2-3M tokens\n';
  } else {
    output += '当前会话长度适中，无需拆分\n';
  }

  output += '\n2. 文档读取优化\n';
  if (codeDocs.length > 0 && codeDocs[0][1].readCount > 30) {
    output += `- ${path.basename(codeDocs[0][0])} 读取次数过多（${codeDocs[0][1].readCount}次），建议优化文件结构\n`;
  }
  if (codeDocs.length === 0) {
    output += '- 文档结构整体良好\n';
  }

  output += '\n3. 自动化程度提升\n';
  if (stats.toolCalls.Bash / stats.messageCount < 0.1) {
    output += '当前 Bash 命令执行占比较低，可考虑增加自动化脚本使用\n';
  } else {
    output += 'Bash 命令执行比例适中\n';
  }

  output += '\n---\n';

  // 🏆 最终总结
  output += '🏆 最终总结\n\n';
  output += '会话亮点 ⭐\n';

  const highlights = [];
  if (totalDocTokens / stats.tokens.total >= 0.3 && totalDocTokens / stats.tokens.total <= 0.5) {
    highlights.push('文档阅读与内容创作平衡良好');
  }
  if (nonCodeAvgEffectiveness >= 0.70) {
    highlights.push(`非代码类文档有效性达到中等偏上水平（平均 ${nonCodeAvgEffectiveness.toFixed(2)}）`);
  }
  if (stats.skills.size > 0) {
    highlights.push('会话结构清晰，包含完整的技能使用流程');
  }
  if (highlights.length === 0) {
    highlights.push('会话包含完整的统计数据');
  }
  highlights.forEach((h, i) => {
    output += `${i + 1}. ${h}\n`;
  });

  output += '\n改进空间 💡\n';
  const improvements = [];
  if (stats.tokens.total >= 3e6) {
    improvements.push(`会话长度较长（${fmt(stats.tokens.total)}），建议拆分`);
  }
  if (savingsPct < 70) {
    improvements.push(`缓存效率偏低（${savingsPct}%），可通过拆分会话改善`);
  }
  if (improvements.length === 0) {
    improvements.push('会话整体表现良好，无明显改进空间');
  }
  improvements.forEach((im, i) => {
    output += `${i + 1}. ${im}\n`;
  });

  output += '\n══════════════════════════════════════════════════════════════════\n';

  return output;
}

// ---------------------------------------------------------------------------
// 输出格式化 - 聚合模式
// ---------------------------------------------------------------------------
function formatAggregateOutput(sessionsData) {
  const width = 70;
  const { top, bottom, divider, spacer } = drawBox(width, 'VCS - 聚合统计');

  // 聚合数据
  let totalSessions = sessionsData.length;
  let totalInput = 0, totalOutput = 0, totalCacheCreate = 0, totalCacheRead = 0;
  const allSkills = new Map();
  const allDocs = new Map();
  const projectCounts = new Map();
  let earliestTime = null, latestTime = null;

  for (const stats of sessionsData) {
    totalInput += stats.tokens.input;
    totalOutput += stats.tokens.output;
    totalCacheCreate += stats.tokens.cacheCreate;
    totalCacheRead += stats.tokens.cacheRead;

    // 聚合技能
    for (const [name, data] of stats.skills) {
      if (!allSkills.has(name)) {
        allSkills.set(name, { count: 0, tokens: 0, sessions: new Set() });
      }
      const skill = allSkills.get(name);
      skill.count += data.count;
      skill.tokens += data.tokens;
      skill.sessions.add(stats.sessionId);
    }

    // 聚合文档
    for (const [path, data] of stats.documents) {
      if (!allDocs.has(path)) {
        allDocs.set(path, { readCount: 0, tokens: 0, sessions: new Set() });
      }
      const doc = allDocs.get(path);
      doc.readCount += data.readCount;
      doc.tokens += data.tokensSpent;
      doc.sessions.add(stats.sessionId);
    }

    // 项目统计
    if (stats.projectPath) {
      const projName = path.basename(stats.projectPath);
      if (!projectCounts.has(projName)) {
        projectCounts.set(projName, { sessions: 0, tokens: 0 });
      }
      const proj = projectCounts.get(projName);
      proj.sessions++;
      proj.tokens += stats.tokens.total;
    }

    // 时间范围
    if (stats.timestamp) {
      const ts = new Date(stats.timestamp);
      if (!earliestTime || ts < earliestTime) earliestTime = ts;
      if (!latestTime || ts > latestTime) latestTime = ts;
    }
  }

  const totalTokens = totalInput + totalOutput;

  let output = '\n';
  output += top + '\n';
  output += '│ 会话总数:  ' + totalSessions + ''.padEnd(52) + '│\n';

  if (earliestTime && latestTime) {
    output += '│ 时间范围:  ' + formatDate(earliestTime.toISOString()) + ' → ' + formatDate(latestTime.toISOString()) + ''.padEnd(26) + '│\n';
  }

  output += divider + '\n';
  output += '│ 聚合Token统计                                                │\n';
  output += '│ 总输入:     ' + fmt(totalInput) + ''.padEnd(52) + '│\n';
  output += '│   未缓存:   ' + fmt(totalInput - totalCacheCreate - totalCacheRead) + ' (' + pct(totalInput - totalCacheCreate - totalCacheRead, totalInput) + ')' + ''.padEnd(32) + '│\n';
  output += '│   缓存创建: ' + fmt(totalCacheCreate) + ' (' + pct(totalCacheCreate, totalInput) + ')' + ''.padEnd(32) + '│\n';
  output += '│   缓存读取: ' + fmt(totalCacheRead) + ' (' + pct(totalCacheRead, totalInput) + ')' + ''.padEnd(32) + '│\n';
  output += '│ 总输出:     ' + fmt(totalOutput) + ''.padEnd(52) + '│\n';
  output += '│ 总计:       ' + fmt(totalTokens) + ''.padEnd(52) + '│\n';
  output += '│ 平均/会话:  ' + fmt(Math.round(totalTokens / totalSessions)) + ''.padEnd(52) + '│\n';
  output += divider + '\n';
  output += '│ 热门技能 (按Token)                                          │\n';

  if (allSkills.size === 0) {
    output += spacer + '\n';
  } else {
    output += '│ ┌─────────────┬────────┬──────────┬────────┬────────┐│\n';
    output += '│ │ 技能        │ 会话数 │ 调用次数 │ Tokens │ 占比   ││\n';
    output += '│ ├─────────────┼────────┼──────────┼────────┼────────┤│\n';

    const topSkills = Array.from(allSkills.entries())
      .sort((a, b) => b[1].tokens - a[1].tokens)
      .slice(0, 5);

    for (const [name, data] of topSkills) {
      const skillPct = pct(data.tokens, totalTokens);
      output += '│ │ ' + (name.length > 11 ? name.slice(0, 11) : name).padEnd(11) + ' │ ' + String(data.sessions.size).padEnd(6) + ' │ ' + String(data.count).padEnd(8) + ' │ ' + fmt(data.tokens).padEnd(6) + ' │ ' + skillPct.padEnd(6) + ' ││\n';
    }
    output += '│ └─────────────┴────────┴──────────┴────────┴────────┘│\n';
  }

  output += divider + '\n';
  output += '│ 热门文档 (按Token)                                          │\n';

  if (allDocs.size === 0) {
    output += spacer + '\n';
  } else {
    output += '│ ┌────────────────────────────────┬────────┬─────────┐│\n';
    output += '│ │ 文档                           │ 会话数 │ Tokens  ││\n';
    output += '│ ├────────────────────────────────┼────────┼─────────┤│\n';

    const topDocs = Array.from(allDocs.entries())
      .sort((a, b) => b[1].tokens - a[1].tokens)
      .slice(0, 5);

    for (const [path, data] of topDocs) {
      const docName = path.basename(path);
      const displayName = docName.length > 30 ? docName.slice(0, 27) + '...' : docName;
      output += '│ │ ' + displayName.padEnd(30) + ' │ ' + String(data.sessions.size).padEnd(6) + ' │ ' + fmt(data.tokens).padEnd(7) + ' ││\n';
    }
    output += '│ └────────────────────────────────┴────────┴─────────┘│\n';
  }

  output += spacer + '\n';
  output += '│ 文档统计:                                                    │\n';
  output += '│   唯一文档数:  ' + allDocs.size + ''.padEnd(56) + '│\n';
  const totalDocTokens = Array.from(allDocs.values()).reduce((sum, d) => sum + d.tokens, 0);
  output += '│   文档Token:   ' + fmt(totalDocTokens) + ' (' + pct(totalDocTokens, totalTokens) + ')' + ''.padEnd(36) + '│\n';

  output += divider + '\n';
  output += '│ 项目分布                                                      │\n';

  if (projectCounts.size === 0) {
    output += spacer + '\n';
  } else {
    output += '│ ┌─────────────────────┬────────┬──────────┬────────┬───────┐│\n';
    output += '│ │ 项目               │ 会话数 │ Tokens   │ 平均   │ 占比  ││\n';
    output += '│ ├─────────────────────┼────────┼──────────┼────────┼───────┤│\n';

    const topProjects = Array.from(projectCounts.entries())
      .sort((a, b) => b[1].tokens - a[1].tokens)
      .slice(0, 5);

    for (const [name, data] of topProjects) {
      const avgTokens = Math.round(data.tokens / data.sessions);
      const projPct = pct(data.tokens, totalTokens);
      output += '│ │ ' + (name.length > 19 ? name.slice(0, 19) : name).padEnd(19) + ' │ ' + String(data.sessions).padEnd(6) + ' │ ' + fmt(data.tokens).padEnd(8) + ' │ ' + fmt(avgTokens).padEnd(6) + ' │ ' + projPct.padEnd(5) + ' ││\n';
    }
    output += '│ └─────────────────────┴────────┴──────────┴────────┴───────┘│\n';
  }

  output += bottom + '\n';
  output += '\n';

  return output;
}

// ---------------------------------------------------------------------------
// 输出格式化 - 历史记录模式
// ---------------------------------------------------------------------------
function formatHistoryOutput(reports, limit) {
  const width = 68;
  const { top, bottom, divider, spacer } = drawBox(width, 'VCS - 历史分析记录');

  const displayReports = reports.slice(0, limit);

  let output = '\n';
  output += top + '\n';
  output += '│ 报告总数: ' + reports.length + ''.padEnd(52) + '│\n';
  output += divider + '\n';
  output += '│ 最近的分析记录                                              │\n';

  if (displayReports.length === 0) {
    output += spacer + '\n';
    output += '│ 暂无分析记录                                              │\n';
  } else {
    output += '│ ┌──────────────────┬─────────┬────────────────────────────────────┬────────────┐│\n';
    output += '│ │ 时间            │ 模式    │ 会话ID                            │ Tokens     ││\n';
    output += '│ ├──────────────────┼─────────┼────────────────────────────────────┼────────────┤│\n';

    for (const report of displayReports) {
      const time = formatDate(report.timestamp);
      const mode = report.mode;
      const sessionId = report.sessionId || '-';
      const tokens = report.totalTokens ? fmt(report.totalTokens) : '-';

      output += '│ │ ' + time.padEnd(16) + ' │ ' + mode.padEnd(7) + ' │ ' + sessionId.padEnd(36) + ' │ ' + String(tokens).padEnd(10) + ' ││\n';
    }
    output += '│ └──────────────────┴─────────┴────────────────────────────────────┴────────────┘│\n';
  }

  output += spacer + '\n';
  output += '│ 报告保存位置: ~/.claude/plugins/data/VCStat/reports/    │\n';
  output += '│ 使用 /vcs -s <sessionId> 重新查看某个报告               │\n';
  output += bottom + '\n';
  output += '\n';

  return output;
}

// ---------------------------------------------------------------------------
// 历史记录管理
// ---------------------------------------------------------------------------
function readHistoryIndex() {
  ensureDir(REPORTS_DIR);

  if (!fs.existsSync(INDEX_PATH)) {
    return { reports: [] };
  }

  try {
    return JSON.parse(fs.readFileSync(INDEX_PATH, 'utf-8'));
  } catch (e) {
    return { reports: [] };
  }
}

function saveReport(content, mode, sessionId, totalTokens) {
  ensureDir(REPORTS_DIR);

  // 生成文件名
  const timestamp = new Date().toISOString().replace(/[-:]/g, '').replace(/\..+$/, '');
  const sessionSuffix = sessionId ? `-${sessionId}` : '';
  const filename = `vcs-report-${timestamp}-${mode}${sessionSuffix}.txt`;
  const filepath = path.join(REPORTS_DIR, filename);

  // 保存报告内容
  fs.writeFileSync(filepath, content, 'utf-8');

  // 更新索引
  const index = readHistoryIndex();
  const reportMeta = {
    timestamp: new Date().toISOString(),
    filename,
    mode,
    sessionId,
    project: sessionId || '-',
    totalTokens
  };
  index.reports.unshift(reportMeta);
  fs.writeFileSync(INDEX_PATH, JSON.stringify(index, null, 2), 'utf-8');

  return filepath;
}

// ---------------------------------------------------------------------------
// 主函数
// ---------------------------------------------------------------------------
async function main() {
  ensureDir(REPORTS_DIR);

  let reportContent = '';
  let totalTokens = 0;
  let sessionId = SESSION_ID;

  switch (MODE) {
    case 'basic':
    case 'detail':
      if (!SESSION_ID) {
        console.error('错误: -s/-d 模式需要提供 sessionId');
        process.exit(1);
      }

      const sessionPath = findSession(SESSION_ID, PROJECTS_DIR);
      if (!sessionPath) {
        console.error('错误: 未找到会话 ' + SESSION_ID);
        process.exit(1);
      }

      const stats = await parseSessionFile(sessionPath);
      if (stats.error) {
        console.error('错误:', stats.error);
        process.exit(1);
      }

      // 检测规则
      detectRules(stats, stats.projectPath);

      // 分析文档
      analyzeDocuments(stats, stats.tokens.total);

      totalTokens = stats.tokens.total;

      if (MODE === 'basic') {
        reportContent = formatBasicOutput(stats);
      } else {
        reportContent = formatDetailOutput(stats);
      }
      break;

    case 'aggregate':
      console.log('正在扫描会话...');
      const sessions = getAllSessions(PROJECTS_DIR, LIMIT);

      if (sessions.length === 0) {
        console.log('未找到任何会话');
        process.exit(0);
      }

      console.log(`找到 ${sessions.length} 个会话，正在分析...`);

      const sessionsData = [];
      for (let i = 0; i < sessions.length; i++) {
        const session = sessions[i];

        if (SHOW_PROGRESS && i > 0 && i % 5 === 0) {
          const progress = Math.round((i / sessions.length) * 100);
          process.stderr.write(`\r处理进度: [${'='.repeat(Math.floor(progress / 5))}${' '.repeat(20 - Math.floor(progress / 5))}] ${progress}% (${i}/${sessions.length})`);
        }

        const sessionStats = await parseSessionFile(session.path);
        if (!sessionStats.error) {
          detectRules(sessionStats, sessionStats.projectPath);
          analyzeDocuments(sessionStats, sessionStats.tokens.total);
          sessionsData.push(sessionStats);
          totalTokens += sessionStats.tokens.total;
        }
      }

      if (SHOW_PROGRESS) {
        process.stderr.write('\r处理进度: [' + '='.repeat(20) + '] 100% (' + sessions.length + '/' + sessions.length + ')\n');
      }

      reportContent = formatAggregateOutput(sessionsData);
      break;

    case 'list':
      console.log('正在扫描会话...');
      const allSessions = getAllSessions(PROJECTS_DIR, LIMIT || 50);

      if (allSessions.length === 0) {
        console.log('未找到任何会话');
        process.exit(0);
      }

      console.log(`找到 ${allSessions.length} 个会话:\n`);

      // 解析每个会话获取基本信息，使用固定宽度格式确保可读性
      for (let i = 0; i < Math.min(allSessions.length, 20); i++) {
        const session = allSessions[i];
        const sessionStats = await parseSessionFile(session.path);
        if (!sessionStats.error) {
          const sessionId = sessionStats.sessionId || 'unknown';
          const time = sessionStats.timestamp ? formatDate(sessionStats.timestamp) : '未知';
          const project = sessionStats.projectPath ? path.basename(sessionStats.projectPath) : '未知';
          const tokens = fmt(sessionStats.tokens.total);
          // 使用固定格式：序号、SessionID、Token、时间、项目
          console.log(`${String(i + 1).padStart(2)}. ${sessionId} [${tokens}] ${time} ${project}`);
        }
      }

      if (allSessions.length > 20) {
        console.log(`... 还有 ${allSessions.length - 20} 个会话 (使用 -l 查看更多)`);
      }
      break;

    case 'history':
      const index = readHistoryIndex();
      reportContent = formatHistoryOutput(index.reports, LIMIT);
      break;

    default:
      console.error('错误: 未知的模式', MODE);
      process.exit(1);
  }

  // 输出报告
  console.log(reportContent);

  // 保存报告
  if (!NO_SAVE && MODE !== 'history') {
    const savedPath = saveReport(reportContent, MODE, sessionId, totalTokens);
    console.log('报告已保存到: ' + savedPath);
  }
}

main().catch(err => {
  console.error('错误:', err.message);
  process.exit(1);
});
