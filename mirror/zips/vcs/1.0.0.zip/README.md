# VCS 技能文档

VCS (Version Control Statistics) 技能用于分析 Claude Code 会话的使用情况。

## 命令参考

### 基本统计 (-s)

显示会话的基本统计信息。

**参数：**
- `-s <sessionId>` - 要分析的会话ID（必需）

**输出包括：**
- Token消耗（输入/输出/缓存）
- 使用的技能列表
- 规则配置摘要
- 文档使用摘要

**示例：**
```bash
/VCS -s a40ea86f-9f11-4931-9c2d-b9f232815089
```

### 详细分析 (-d)

显示会话的详细分析信息。

**参数：**
- `-d <sessionId>` - 要分析的会话ID（必需）

**输出包括：**
- 详细的Token分解
- 每个技能的详细统计（包括占比）
- 完整的规则配置
- 每个文档的详细分析，包括：
  - 读取次数
  - 总字符数
  - 估计引用字符数和占比
  - Token消耗
  - 有效性得分（四个维度的详细得分）
- 工具使用统计

**示例：**
```bash
/VCS -d a40ea86f-9f11-4931-9c2d-b9f232815089
```

### 聚合统计 (-a)

分析多个会话的聚合信息。

**参数：**
- `-a` - 聚合模式
- `[limit]` - 可选，分析的会话数量（默认：10）

**输出包括：**
- 会话总数
- 时间范围
- 聚合Token统计（输入/输出/缓存/平均值）
- 热门技能列表（按Token排序）
- 热门文档列表（按Token排序）
- 项目分布
- 文档统计汇总

**示例：**
```bash
/VCS -a          # 分析最近10个会话
/VCS -a 50       # 分析最近50个会话
```

### 历史记录 (-h)

查看之前保存的分析报告列表。

**参数：**
- `-h` - 历史记录模式
- `[limit]` - 可选，显示的记录数量（默认：20）

**输出包括：**
- 报告总数
- 最近的分析记录列表（包含时间、模式、会话ID、Token数）
- 报告保存位置

**示例：**
```bash
/VCS -h          # 显示最近20条记录
/VCS -h 50       # 显示最近50条记录
```

## 算法文档

### Token 提取

从会话JSONL文件中提取token信息：
- `usage.input_tokens` - 输入token
- `usage.output_tokens` - 输出token
- `usage.cache_creation_input_tokens` - 缓存创建token
- `usage.cache_read_input_tokens` - 缓存读取token

同一个API响应可能被分割成多个JSONL条目，使用`requestId`去重，避免重复计数。

### 技能追踪

通过以下方式检测技能使用：
1. 从`skill_listing`附件中加载的技能列表
2. 从`Skill`工具调用中使用的技能

追踪每个技能的调用次数和关联的token消耗。

### 文档追踪

检测`Read`工具调用以获取文档使用情况：
- 提取`file_path`字段获取文档路径
- 跟踪读取次数、token消耗、时间戳

### 内容占比计算

由于JSONL不包含精确的引用信息，使用以下方法估算：

```
estimatedReferencedChars = min(
  totalChars,
  (firstReadTokens * 4 * 0.8) + (cachedReadTokens * 4 * 0.3)
)

contentRatio = estimatedReferencedChars / totalChars
```

估算依据：
- 1 token ≈ 4 字符
- 首次读取：80%效率（大部分内容有用）
- 缓存读取：30%效率（可能只是特定片段）

### 有效性评分

多因子评分系统，显示每个维度的得分：

1. **读取频率得分 (25%权重)**
   ```
   score = min(1.0, log(readCount + 1) / log(5))
   ```
   多次读取表示文档持续相关。

2. **内容占比得分 (25%权重)**
   ```
   score = 0.5 + (contentRatio * 0.5)
   ```
   较高的占比表示更多文档内容被使用。

3. **Token得分 (30%权重)**
   ```
   proportion = docTokens / totalSessionTokens
   
   if proportion < 0.1%:
     score = 0.3
   else if proportion < 1%:
     score = 0.5 + proportion * 50
   else if proportion < 5%:
     score = 1.0 - (proportion - 1%) * 10
   else:
     score = max(0.1, 0.6 - (proportion - 5%) * 5)
   ```
   消耗1-5%的token表示"甜蜜点"——足够有意义不过于低效。

4. **时间分散度得分 (20%权重)**
   ```
   score = min(1.0, timeSpan / 60分钟)
   ```
   在整个会话中分布的读取表示持续相关性。

**综合得分：**
```
effectiveness = (
  frequencyScore * 0.25 +
  contentRatioScore * 0.25 +
  tokenScore * 0.30 +
  dispersionScore * 0.20
)
```

### 规则检测

检测项目中的规则配置：
- `~/.claude/CLAUDE.md` - 全局规则文件
- `<project>/CLAUDE.md` - 项目规则文件
- `<project>/.claude/rules/*.md` - 项目规则目录
- `<project>/.claude/settings.json` - 项目设置（hooks、MCP服务器）

## 故障排除

### 错误：未找到会话

**原因：** 指定的sessionId对应的JSONL文件不存在。

**解决方法：**
1. 检查sessionId是否正确
2. 使用`VCS -h`查看历史记录获取正确的sessionId

### 错误：文件读取失败

**原因：** 被引用的文档已被删除或无权访问。

**解决方法：**
- 文档分析仍可继续，但会显示"文件不可访问"
- 恢复文档后可重新分析

### 输出显示不正确

**原因：** 终端宽度不足或编码问题。

**解决方法：**
- 确保终端支持UTF-8编码
- 使用更宽的终端窗口
- 报告已保存到文件，可手动查看