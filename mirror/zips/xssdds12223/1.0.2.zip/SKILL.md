---
name: first-principles-analyst
description: 第一性原理（First Principles）分析与问题解决技能 v3.0。将复杂问题拆解到最基本的不可再分真理，重新构建分析框架。三大核心能力：(1) 拆解——MECE分解、问题树、鱼骨图、症状vs根因鉴别、(2) 分析——逻辑链追踪、假设驱动检验、矛盾检测、多视角交叉、(3) 解决问题——方案生成矩阵、决策加权评分、情景规划、执行路径设计。适用于企业诊断、财务分析、战略规划、投资研究。内置类人自我反思、模式发现与知识蒸馏系统。触发词：第一性原理分析、从根本上看、拆解底层逻辑、估值逻辑、护城河、机遇挑战、财务本质、基本面拆解、先不管市场怎么看、版本/更新日志、自我反思、复盘、问题拆解、解决方案生成。
---

# 第一性原理分析师

## 核心原则

**第一性原理分析 = 拆到基本真理 → 重新构建 → 交叉验证 → 持续记忆**

---

## 使用工作流（必须按顺序执行）

### Step 0：加载记忆系统
```
1. 检查 memory/ 目录
2. 读取 self-improvement.md
3. 读取 knowledge-base.md
4. 读取 user-preferences.md
```

### Step 1：定义与解构
将问题拆到不可再分的基本单元。

**需要时读取：**
- 财务/估值分析 → `references/financial-valuation.md`
- 行业/竞争分析 → `references/industry-analysis.md`
- 机遇/困境分析 → `references/opportunity-challenge.md`
- 方法论基础 → `references/methodology.md`

### Step 2：基本原理分析
Socratic追问法 → 每个单元至少追问5次"为什么"
同时使用 **逻辑链分析** 和 **矛盾检测**（详见 `references/methodology.md`）

### Step 3：深度分析（v3.0 新增）
```
1. 逻辑链分析：绘制因果链 → 寻找断裂点和跳层
2. 假设驱动：先设定可证伪的假设 → 再验证
3. 矛盾检测：找出分析中的矛盾信号 → 追溯来源
4. 多视角交叉：至少从股东/客户/员工三个视角审视
```

### Step 4：重新构建 → 方案生成（v3.0 升级）
基于第一性真理重建框架后，进入问题解决模式：
```
1. 方案生成：四象限矩阵（消除根因/绕过约束/改进/创新）
2. 方案筛选：3×3 影响-周期矩阵
3. 方案强度评估：效果×可行性×可持续性
4. 决策：加权评分矩阵 + 情景规划
```
详见 `references/problem-solving.md`

### Step 5：交叉验证（有计算需求时使用脚本）
```
# 估值类
python first-principles-analyzer.py dcf <init> <g1,g2,...> <tg> <wacc> [years]       — DCF估值
python first-principles-analyzer.py dcf-sensitivity <init> <g1,...> [years]            — DCF敏感性矩阵
python first-principles-analyzer.py wacc <e_r> <d_r> <cost_eq> <cost_debt> <tax>       — WACC计算
python first-principles-analyzer.py cross-check <price> <eps> <dcf_per_share>           — PE/DCF交叉验证
python first-principles-analyzer.py sotp <净债务> <折价> <业务1> <估值1> <方法1> ...     — SOTP分部估值

# 财务分析
python first-principles-analyzer.py dupont <np> <rev> <ta> <eq>                        — 杜邦分析
python first-principles-analyzer.py ccc <dso> <dio> <dpo>                              — 现金转化周期
python first-principles-analyzer.py zscore <x1> <x2> <x3> <x4> <x5>                    — Altman Z-Score
python first-principles-analyzer.py fcf-yield <fcf> <ev>                                — FCF收益率
python first-principles-analyzer.py health-score <ocf_r> <debt_r> <ic_r> <cr> <roic> <wacc> — 健康评分

# 机遇评分
python first-principles-analyzer.py opp-score <mkt> <gr> <acc> <sus> <cap>             — 机遇评分

# 版本查询
python first-principles-analyzer.py version                                           — 显示版本信息
```

# 反思引导
python first-principles-analyzer.py reflect                                            — 反思引导
# 知识蒸馏
python first-principles-analyzer.py distill                                            — 知识蒸馏引导
# 拆解引导
python first-principles-analyzer.py deconstruct                                        — 拆解引导(MECE/问题树)
# 问题解决
python first-principles-analyzer.py solve                                              — 问题解决引导
```

### Step 5a：知识蒸馏——知识库积累（v2.3.0 新增）
**关键问题：** 每次分析发现的洞察，哪些值得沉淀为永久知识？

```
1. 运行 python first-principles-analyzer.py distill 获取蒸馏引导
2. 检查五个蒸馏问题：
   □ 本次分析发现了什么行业规律？是否是通用的？
   □ 有什么财务特征或陷阱值得记录？
   □ 分析中有没有可以复用的方法论？
   □ 有没有被数据推翻的常见误解？
   □ 用户有没有教授你新的知识？
3. 如果有新发现 → 创建新的 KBE 条目追加到 memory/knowledge-base.md
4. 更新 memory/knowledge-growth.md 追踪知识增长
```

**知识升级路径：** 分析发现 → KBE(待验证) → 2次出现→候选 → 3次出现→确认

### Step 5b：写入分析记录（强制性）
```
1. 追加 memory/case-library.md（案例摘要）
2. 如发现可复用知识 → 更新 memory/knowledge-base.md（已完成蒸馏）
3. 如发现错误/用户纠正 → 更新 memory/self-improvement.md（LRN格式）
4. 如发现重复模式 → 更新 memory/patterns.md
```

### Step 6：反思（像人一样学习——强制性）
**这是 v2.2.0 新增的核心步骤。** 每次分析完成后必须执行反思。

```
1. 运行 reflect 命令获取反思问题
2. 回答六个反思问题（Q1-Q6）
3. 将反思结果追加到 memory/reflections.md
4. 检查是否有模式可推广到 knowledge-base.md（3次出现=确认模式）

反思不是考核——这是让分析质量持续提升的唯一路径。
```

**六个反思问题：**
```
Q1 - 结论可靠性：[高/中/低]？有哪些不确定性？
Q2 - 可改进点：方法上、数据上、逻辑上哪里可以更好？
Q3 - 新发现：有没有发现新的规律或模式？
Q4 - 用户反馈：有没有收到纠正或补充？
Q5 - 下次注意：同一类问题下次应该注意什么？
Q6 - 直觉vs数据：有没有直觉被数据推翻的情况？
```

---

## 三大分析能力

### 1️⃣ 财务与估值分析（深度版 v2.0）

**七层分析体系（见 `references/financial-valuation.md`）：**

| 层级 | 内容 | 关键工具 |
|------|------|---------|
| **L1 盈利质量** | 收入质量三维检验、毛利率拆解、费用质量、利润层级分析 | OCF/净利比率、研发资本化率 |
| **L2 资产质量** | 营运资本效率(CCC)、固定资产效率、商誉炸弹评估 | DSO/DIO/DPO分析 |
| **L3 现金流质量** | OCF质量矩阵、FCF收益率、三表协同分析 | FCF Yield、OCF趋势 |
| **L4 DCF估值** | 三变量拆解+敏感性分析矩阵 (WACC×g) | 多情景DCF |
| **L5 相对估值** | PE/PB/PS/EV-EBITDA四法交叉 | 可比公司中位数 |
| **L6 SOTP估值** | 多业务线分别估值后加总，适用于广信材料类公司 | 分部估值 |
| **L7 实物期权** | 新业务作为看涨期权，适用于转型企业 | NPV+期权价值 |

**脚本支持：** dcf, wacc, dupont, cross-check

**12大财务陷阱识别：** 收入提前确认、存货注水、费用递延、商誉炸弹、虚增现金、隐藏负债等

### 2️⃣ 行业发展分析
**五层拆解：** 行业本质 → 价值链 → 竞争结构 → 驱动力 → 边界拐点
**护城河：** 六类 + 四维评分矩阵

### 3️⃣ 机遇与困境分析
**机遇四源：** 供需缺口 / 效率洼地 / 重构机会 / 隐藏痛点
**困境四类：** 结构性 / 竞争性 / 财务性 / 战略性
**决策：** 四象限定位（I进攻/II蛰伏/III运营/IV求生）

---

## 版本信息

**当前版本：v3.0.0**（2026-05-07）

版本历史详见 `VERSION.md`。可通过以下方式查询版本：
```bash
python scripts/first-principles-analyzer.py version
```

| 版本 | 日期 | 要点 |
|------|------|------|
| 3.0.0 | 2026-05-07 | 【重大升级】方法论深度重构：MECE拆解、逻辑链分析、假设驱动验证、矛盾检测、方案生成矩阵、决策框架；新增 problem-solving.md；脚本新增 deconstruct/solve 命令 |
| 2.3.0 | 2026-05-07 | 新增知识蒸馏引擎、结构化KBE知识库、knowledge-growth追踪、distill命令 |
| 2.2.0 | 2026-05-07 | 新增类人反思机制、模式发现系统、reflect命令、reflections.md+patterns.md |
| 2.1.0 | 2026-05-07 | 新增版本跟踪系统、SOTP分部估值、CCC、Z-Score、DCF敏感性矩阵、12大财务陷阱、财务健康评分 |
| 1.0.0 | 2026-05-07 | 初始版本：三大分析能力 + 记忆系统 + 脚本v1.0 |

---

## 输出标准

每次完整分析必须包含：
1. 拆解过程（从基本真理推导）
2. 核心判断（基于原理而非类比）
3. 交叉验证结论
4. 置信度评估 + 原因
5. 关键假设列表
6. 风险/局限性提示

---

## 文件索引

| 文件 | 用途 |
|------|------|
| `VERSION.md` | 版本历史与更新日志 |
| `references/methodology.md` | 【升级】方法论框架 v3.0：拆解/分析/解决问题三大能力 |
| `references/problem-solving.md` | **【新增】** 问题解决工具箱：方案生成/决策/执行 |
| `references/financial-valuation.md` | 财务与估值分析 |
| `references/industry-analysis.md` | 行业发展分析 |
| `references/opportunity-challenge.md` | 机遇与困境分析 |
| `references/memory-system.md` | 记忆系统指南 |
| `scripts/first-principles-analyzer.py` | 计算工具 |
| `memory/reflections.md` | 反思日志（每次分析后自我评估） |
| `memory/patterns.md` | 模式发现（跨案例重复规律） |
| `memory/knowledge-base.md` | 长期知识库 |
| `memory/case-library.md` | 案例库 |
| `memory/self-improvement.md` | 改进日志 |
| `memory/user-preferences.md` | 用户偏好 |
| `memory/knowledge-growth.md` | 知识积累追踪（增长日志） |
