"""
第一性原理分析辅助工具 v3.0.0
用法: python first-principles-analyzer.py <command> [参数]
支持: dcf, dcf-sensitivity, wacc, dupont, cross-check, ccc,
      zscore, fcf-yield, health-score, opp-score, sotp, version,
      reflect, distill, deconstruct, solve
"""
import json, sys

# ─── 基础估值 ───────────────────────────────────────────────────

def dcf_calculation(initial_fcf, growth_rates, terminal_growth, wacc, years=5):
    if len(growth_rates) < years:
        growth_rates = growth_rates + [growth_rates[-1]] * (years - len(growth_rates))
    cf_values, pv_values = [], []
    fcf = initial_fcf
    for i in range(years):
        fcf *= (1 + growth_rates[i])
        cf_values.append(fcf)
        pv_values.append(fcf / ((1 + wacc) ** (i + 1)))
    terminal_fcf = fcf * (1 + terminal_growth)
    terminal_value = terminal_fcf / (wacc - terminal_growth)
    pv_terminal = terminal_value / ((1 + wacc) ** years)
    total = sum(pv_values) + pv_terminal
    return {"预测现金流(亿元)": [round(v,2) for v in cf_values], "现金流现值(亿元)": [round(v,2) for v in pv_values],
            "预测期现值": round(sum(pv_values),2), "终值现值": round(pv_terminal,2),
            "终值占比": f"{round(pv_terminal/total*100,1)}%", "企业总价值(亿元)": round(total,2)}

def dcf_sensitivity(initial_fcf, growth_rates, years=5):
    """DCF敏感性分析矩阵：WACC(8%-14%) × g(2%-5%)"""
    results = {}
    rows = []
    for wacc_pct in range(8, 15, 2):
        wacc = wacc_pct / 100
        row = {"WACC": f"{wacc_pct}%"}
        for tg_pct in range(2, 6):
            tg = tg_pct / 100
            r = dcf_calculation(initial_fcf, growth_rates, tg, wacc, years)
            row[f"g={tg_pct}%"] = r["企业总价值(亿元)"]
        rows.append(row)
    return {"敏感性矩阵(企业价值亿元)": rows, "结论": "当企业价值对WACC或g变化高度敏感时(>50%波动)，DCF应仅供趋势参考"}

def wacc_calc(e_ratio, d_ratio, cost_eq, cost_debt, tax):
    w = e_ratio*cost_eq + d_ratio*cost_debt*(1-tax)
    return {"WACC": f"{round(w*100,2)}%", "明细": {"权益贡献": f"{round(e_ratio*cost_eq*100,2)}%", "债务税后贡献": f"{round(d_ratio*cost_debt*(1-tax)*100,2)}%"}}

def dupont(np, rev, ta, eq):
    nm = np/rev if rev else 0; at = rev/ta if ta else 0; lev = ta/eq if eq else 0
    return {"ROE": f"{round(nm*at*lev*100,2)}%", "净利率": f"{round(nm*100,2)}%", "资产周转率": round(at,4), "权益乘数": round(lev,4)}

def cross_check(price, eps, dcf_per_share):
    pe = price/eps if eps else 0; fair_pe = dcf_per_share/eps if eps else 0; mos = (dcf_per_share-price)/price
    return {"当前PE": round(pe,2), "DCF隐含PE": round(fair_pe,2), "当前价": price, "公允价值(元/股)": round(dcf_per_share,2),
            "安全边际": f"{round(mos*100,2)}%", "结论": "低估" if dcf_per_share>price else "高估"}

# ─── 财务分析 ───────────────────────────────────────────────────

def ccc_calculation(dso, dio, dpo):
    """现金转化周期 = DSO + DIO - DPO"""
    ccc = dso + dio - dpo
    desc = "极佳(负CCC,占用他人资金)" if ccc < 0 else \
           "优秀(<30天)" if ccc < 30 else \
           "良好(30-60天)" if ccc < 60 else \
           "一般(60-90天)" if ccc < 90 else \
           "较差(>90天)"
    return {"CCC(天)": round(ccc,1), "DSO(应收)": dso, "DIO(存货)": dio, "DPO(应付)": dpo, "评价": desc}

def altman_zscore(x1, x2, x3, x4, x5):
    """Altman Z-Score 破产预测（制造业上市公司）"""
    z = 1.2*x1 + 1.4*x2 + 3.3*x3 + 0.6*x4 + 1.0*x5
    desc = "安全区间(>2.99)" if z > 2.99 else \
           "灰色区间(1.81-2.99)" if z >= 1.81 else \
           "危险区间(<1.81)"
    return {"Z-Score": round(z,2), "评价": desc,
            "X1(营运资本/总资产)": round(x1,4), "X2(留存收益/总资产)": round(x2,4),
            "X3(EBIT/总资产)": round(x3,4), "X4(市值/负债)": round(x4,4), "X5(收入/总资产)": round(x5,4)}

def fcf_yield(fcf, ev):
    """FCF收益率"""
    yield_pct = fcf / ev * 100 if ev else 0
    desc = "低估区间(>8%)" if yield_pct > 8 else \
           "合理区间(3-8%)" if yield_pct >= 3 else \
           "高估/高预期区间(<3%)"
    return {"FCF收益率": f"{round(yield_pct,2)}%", "FCF(亿元)": fcf, "EV(亿元)": ev, "评价": desc}

def health_score(ocf_ratio, debt_ratio, ic_ratio, current_ratio, roic, wacc):
    """财务健康综合评分(0-100)"""
    score = 0
    # OCF/净利润比率 (权重20)
    if ocf_ratio >= 1.2: score += 20
    elif ocf_ratio >= 0.8: score += 15
    elif ocf_ratio >= 0.5: score += 10
    else: score += 5
    # 资产负债率 (权重20) — 越低越安全
    if debt_ratio < 0.3: score += 20
    elif debt_ratio < 0.5: score += 15
    elif debt_ratio < 0.7: score += 10
    else: score += 5
    # 利息覆盖率 (权重20)
    if ic_ratio >= 5: score += 20
    elif ic_ratio >= 3: score += 15
    elif ic_ratio >= 1: score += 10
    else: score += 5
    # 流动比率 (权重20)
    if current_ratio >= 2: score += 20
    elif current_ratio >= 1.5: score += 15
    elif current_ratio >= 1: score += 10
    else: score += 5
    # ROIC vs WACC (权重20)
    if roic >= wacc + 0.05: score += 20
    elif roic >= wacc: score += 15
    elif roic >= wacc - 0.03: score += 10
    else: score += 5
    rating = "优秀(80-100)" if score >= 80 else \
             "良好(60-79)" if score >= 60 else \
             "关注(40-59)" if score >= 40 else \
             "警示(<40)"
    return {"财务健康评分": score, "评级": rating, "满分": 100}

# ─── 机遇评分 + SOTP ───────────────────────────────────────────

def opp_score(mkt, gr, acc, sus, cap):
    s = mkt*0.25+gr*0.20+acc*0.20+sus*0.15+cap*0.20
    r = "A+重大机遇" if s>=4.5 else "A优质机遇" if s>=4 else "B一般机遇" if s>=3 else "C弱机遇"
    return {"总分": round(s,1), "评级": r, "明细": {"市场规模": f"{mkt}/5","增速": f"{gr}/5","可获取性": f"{acc}/5","持续性": f"{sus}/5","能力匹配": f"{cap}/5"}}

def sotp_valuation(segments, net_debt, holding_discount=0.15):
    """
    SOTP分部估值
    segments: [(业务名, 估值(亿), 方法名), ...]
    net_debt: 净债务(亿), holding_discount: 控股折价(默认15%)
    """
    total = 0
    seg_list = []
    for name, val, method in segments:
        total += val
        seg_list.append({"业务": name, "估值(亿元)": val, "方法": method})
    after_discount = total * (1 - holding_discount)
    equity_value = after_discount - net_debt
    return {"分部估值明细": seg_list, "加总价值(亿元)": round(total,2),
            f"控股折价({int(holding_discount*100)}%)后(亿元)": round(after_discount,2),
            "减:净债务(亿元)": round(net_debt,2), "股权价值(亿元)": round(equity_value,2)}

# ─── 版本信息 ───────────────────────────────────────────────────

VERSION = "3.0.0"
VERSION_INFO = {
    "name": "first-principles-analyzer",
    "version": VERSION,
    "date": "2026-05-07",
    "description": "第一性原理分析辅助工具",
    "commands": [
        {"name": "dcf", "desc": "DCF估值"},
        {"name": "dcf-sensitivity", "desc": "DCF敏感性矩阵"},
        {"name": "wacc", "desc": "WACC计算"},
        {"name": "dupont", "desc": "杜邦分析"},
        {"name": "cross-check", "desc": "PE/DCF交叉验证"},
        {"name": "ccc", "desc": "现金转化周期"},
        {"name": "zscore", "desc": "Altman Z-Score"},
        {"name": "fcf-yield", "desc": "FCF收益率"},
        {"name": "health-score", "desc": "财务健康评分"},
        {"name": "opp-score", "desc": "机遇评分"},
        {"name": "sotp", "desc": "SOTP分部估值"},
        {"name": "version", "desc": "显示版本信息"},
        {"name": "reflect", "desc": "反思引导(生成反思模板)"},
        {"name": "distill", "desc": "知识蒸馏引导(从分析中提取可复用知识)"},
        {"name": "deconstruct", "desc": "拆解引导(MECE/问题树/鱼骨图)"},
        {"name": "solve", "desc": "问题解决引导(方案生成/决策/执行)"}
    ],
    "changelog": [
        {"version": "3.0.0", "date": "2026-05-07", "changes": ["【重大升级】方法论深度重构", "新增 MECE拆解、问题树、鱼骨图、症状vs根因鉴别", "新增逻辑链分析、假设驱动验证、矛盾检测", "新增方案生成矩阵、加权决策框架、情景规划", "新增 problem-solving.md 完整工具箱", "新增 deconstruct 和 solve 命令"]},
        {"version": "2.2.0", "date": "2026-05-07", "changes": ["新增反思机制与模式发现系统", "新增 reflections.md 和 patterns.md", "新增 reflect 命令", "记忆系统升级为类人学习闭环"]},
        {"version": "2.1.0", "date": "2026-05-07", "changes": ["新增版本跟踪系统", "新增SOTP分部估值、CCC、Z-Score、DCF敏感性矩阵、FCF收益率、健康评分", "新增12大财务陷阱清单", "financial-valuation.md 300+行深度内容"]},
        {"version": "1.0.0", "date": "2026-05-07", "changes": ["初始版本", "三大分析能力", "记忆系统", "脚本v1.0"]}
    ]
}

def show_version():
    return {"技能": VERSION_INFO["name"], "版本": VERSION, "发布日期": VERSION_INFO["date"],
            "说明": VERSION_INFO["description"], "命令数": len(VERSION_INFO["commands"]),
            "版本历史": [f"{v['version']} ({v['date']}): {'; '.join(v['changes'][:3])}" for v in VERSION_INFO["changelog"]]}

# ─── 反思引导（类人学习核心） ─────────────────────────────────

def reflect_prompt():
    """生成反思模板，引导分析后的结构化自我反思"""
    return {
        "命令": "分析后反思引导",
        "说明": "每次完整分析后，在心智中还保留分析全貌时，立即回答以下六个问题。这是'像人一样学习'的核心机制。",
        "六个反思问题": [
            "Q1 - 结论可靠性：本次分析的核心结论是否可靠？有哪些不确定性？（高/中/低）",
            "Q2 - 可改进点：本次分析中有哪些可以做得更好的地方？方法上、数据上、逻辑上？",
            "Q3 - 新发现：有没有发现新的规律或模式？是行业特有的还是通用的？",
            "Q4 - 用户反馈：有没有收到用户的纠正或补充？",
            "Q5 - 下次注意：下次分析同一类问题时应该注意什么？",
            "Q6 - 直觉vs数据：是否有'直觉'后来被数据推翻？（这是最有价值的反思）"
        ],
        "使用方式": "将反思结果写入 memory/reflections.md，格式参考 memory-system.md"
    }

# ─── 知识蒸馏（知识库积累核心） ─────────────────────────────

def distill_prompt():
    """生成知识蒸馏引导，帮助从分析中提取可复用的知识"""
    return {
        "命令": "知识蒸馏引导",
        "说明": "每次分析完成后，检查是否能从分析发现中蒸馏出可复用的知识，沉淀到 knowledge-base.md。这是知识库有机增长的核心机制。",
        "蒸馏检查清单": [
            "□ 本次分析发现了什么行业规律？是否是通用的？",
            "□ 有什么财务特征或陷阱值得记录？",
            "□ 这次的分析方法有没有可以复用的？",
            "□ 有没有被数据推翻的直觉或常见误解？",
            "□ 用户有没有教授你新的知识？"
        ],
        "知识条目标准格式": """
## KBE-XXX 标题
- **类型**：估值方法论/财务分析/风险评估/行业规律/行为模式
- **来源**：Case#N 或 用户反馈
- **置信度**：待验证/候选/确认（首次记录=待验证，2次=候选，3次=确认）
- **内容**：<一句话精髓｜展开说明>
- **使用条件**：<什么情况下可用>
- **反例/边界**：<什么情况下不适用>""",
        "蒸馏决策树": """
分析完成 → 有新发现吗？
  ├── 有 → 和知识库现有条目对比
  │     ├── 已有相同条目 → 更新使用次数、置信度
  │     ├── 有相似条目 → 考虑合并或分拆
  │     └── 全新发现 → 创建新 KBE 条目
  └── 无 → 搜索 patterns.md 是否有待验证的模式需要升级
        """
    }

# ─── 拆解引导（v3.0） ──────────────────────────────────────────

def deconstruct_prompt():
    """生成拆解引导，帮助系统化拆解问题"""
    return {
        "命令": "拆解引导",
        "说明": "使用MECE/问题树/鱼骨图将问题拆到不可再分的基本单元。这是第一性原理分析的第一步也是最重要的一步。",
        "拆解步骤": [
            "1. 选择拆解方法：MECE（通用）| 问题树（结构化追问）| 鱼骨图（因果追溯）",
            "2. 将问题拆成3-7个互不重叠的子维度",
            "3. 对每个子维度继续拆解，直到不可再分",
            "4. 在每个基本单元上标注：人为约定 vs 客观真理",
            "5. 完成拆解质量自检（见 references/methodology.md）"
        ],
        "MECE检查清单": [
            "□ 子维度之间无重叠（M）",
            "□ 子维度覆盖全部可能（E）",
            "□ 拆解层次不超过3层",
            "□ 每个元素都能明确归类",
            "□ 区分了症状和根因"
        ],
        "参考文件": "references/methodology.md - 第一能力：拆解"
    }

# ─── 问题解决引导（v3.0） ──────────────────────────────────────

def solve_prompt():
    """生成问题解决引导，从分析到方案到执行"""
    return {
        "命令": "问题解决引导",
        "说明": "基于第一性原理生成解决方案、做出决策、规划执行路径。",
        "解决步骤": [
            "1. 问题定义：用5W1H精确描述问题",
            "2. 根因确认：拆解找到的根因是否经过验证？",
            "3. 方案生成：使用四象限矩阵生成至少3个方案",
            "4. 方案评估：效果×可行性×可持续性 三维评分",
            "5. 决策：加权评分矩阵 + 情景规划",
            "6. 执行规划：第一步/里程碑/负责人/止损点"
        ],
        "参考文件": "references/problem-solving.md - 完整工具箱",
        "常见误区": [
            "❌ 急于出方案 → 先花70%时间定义问题",
            "❌ 单一方案 → 强制3个以上备选",
            "❌ 忽视止损 → 开始前设定止损点",
            "❌ 混淆症状与根因 → 三级追问法"
        ]
    }

# ─── 命令映射 ──────────────────────────────────────────────────

CMDS = {
    "dcf": dcf_calculation, "dcf-sensitivity": dcf_sensitivity,
    "wacc": wacc_calc, "dupont": dupont, "cross-check": cross_check,
    "ccc": ccc_calculation, "zscore": altman_zscore,
    "fcf-yield": fcf_yield, "health-score": health_score,
    "opp-score": opp_score, "sotp": sotp_valuation,
    "version": show_version, "reflect": reflect_prompt, "distill": distill_prompt,
    "deconstruct": deconstruct_prompt, "solve": solve_prompt
}

HELP = """
  估值类:
    dcf <init_fcf> <g1,g2,...> <tg> <wacc> [years]        — DCF估值
    dcf-sensitivity <init_fcf> <g1,g2,...> [years]          — DCF敏感性矩阵
    wacc <e_ratio> <d_ratio> <cost_eq> <cost_debt> <tax>    — WACC计算
    cross-check <price> <eps> <dcf_per_share>               — PE/DCF交叉验证
    sotp <净债务> <折价率> <业务1名> <估值1> <方法1> ...    — SOTP分部估值

  财务分析:
    dupont <np> <rev> <ta> <eq>              — 杜邦分析
    ccc <dso> <dio> <dpo>                    — 现金转化周期
    zscore <x1> <x2> <x3> <x4> <x5>          — Altman Z-Score
    fcf-yield <fcf> <ev>                     — FCF收益率
    health-score <ocf_r> <debt_r> <ic_r> <cr> <roic> <wacc> — 财务健康评分

  机遇评分:
    opp-score <market> <growth> <access> <sustain> <cap_fit> — 机遇评分

sotp示例: python first-principles-analyzer.py sotp 5 0.15 "传统业务" 5 PE "光伏胶" 8 DCF "涂料" 2 PS
"""

if __name__ == "__main__":
    if len(sys.argv) < 2 or sys.argv[1] not in CMDS:
        print(f"用法: {sys.argv[0]} <命令> [参数]\n{HELP}")
        print(f"命令: {', '.join(CMDS.keys())}")
        sys.exit(1)
    
    cmd = sys.argv[1]
    if cmd == "dcf":
        init = float(sys.argv[2]); growth = [float(x) for x in sys.argv[3].split(",")]
        r = dcf_calculation(init, growth, float(sys.argv[4]), float(sys.argv[5]), int(sys.argv[6]) if len(sys.argv)>6 else 5)
    elif cmd == "dcf-sensitivity":
        init = float(sys.argv[2]); growth = [float(x) for x in sys.argv[3].split(",")]
        r = dcf_sensitivity(init, growth, int(sys.argv[4]) if len(sys.argv)>4 else 5)
    elif cmd == "wacc":
        r = wacc_calc(*[float(x) for x in sys.argv[2:7]])
    elif cmd == "dupont":
        r = dupont(*[float(x) for x in sys.argv[2:6]])
    elif cmd == "cross-check":
        r = cross_check(*[float(x) for x in sys.argv[2:5]])
    elif cmd == "ccc":
        r = ccc_calculation(*[float(x) for x in sys.argv[2:5]])
    elif cmd == "zscore":
        r = altman_zscore(*[float(x) for x in sys.argv[2:7]])
    elif cmd == "fcf-yield":
        r = fcf_yield(*[float(x) for x in sys.argv[2:4]])
    elif cmd == "health-score":
        r = health_score(*[float(x) for x in sys.argv[2:8]])
    elif cmd == "opp-score":
        r = opp_score(*[float(x) for x in sys.argv[2:7]])
    elif cmd == "sotp":
        nd = float(sys.argv[2]); disc = float(sys.argv[3])
        segs = [(sys.argv[i], float(sys.argv[i+1]), sys.argv[i+2]) for i in range(4, len(sys.argv), 3)]
        r = sotp_valuation(segs, nd, disc)
    elif cmd == "version":
        r = show_version()
    elif cmd == "reflect":
        r = reflect_prompt()
    elif cmd == "distill":
        r = distill_prompt()
    elif cmd == "deconstruct":
        r = deconstruct_prompt()
    elif cmd == "solve":
        r = solve_prompt()
    print(json.dumps(r, ensure_ascii=False, indent=2))
