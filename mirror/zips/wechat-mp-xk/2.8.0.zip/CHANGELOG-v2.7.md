# wechat-mp-xk v2.7 代码块稳定性优化

**发布日期**: 2026 年 3 月 31 日

---

## 🎉 重大更新

### v2.7.0 - 微信编辑器兼容性优化

#### 问题背景

**用户反馈**：
> "在公众号后台首次预览正确，对文章做修改后脚本格式就出现错误"

**问题分析**：
- 首次粘贴/预览时，HTML 样式正确
- 但在微信编辑器中修改后，样式被重置
- 代码块显示为单行，失去换行

#### 根因分析

**微信公众号编辑器特点**：

1. **HTML 净化机制**
   - 微信编辑器会"净化"粘贴的 HTML
   - 某些标签和样式会被重置或移除
   - 特别是 `<pre>`和`<code>` 标签

2. **样式重置**
   - `white-space` 属性可能被忽略
   - `word-break` 属性可能被重置
   - 编辑后重新渲染时丢失格式

3. **标签兼容性**
   - `<pre>` 标签在编辑后容易失去样式
   - `<code>` 标签的字体可能被重置
   - 嵌套结构可能被简化

---

## 🔧 技术解决方案

### v2.6 及之前方案（不稳定）

```html
<pre style="white-space: pre-wrap; word-break: break-all;">
<code style="font-family: Consolas, monospace;">
第一行代码
第二行代码
第三行代码
</code>
</pre>
```

**问题**：
- 依赖 `white-space` 属性
- 编辑后 `<pre>` 样式被重置
- 所有行合并为单行

---

### v2.7 新方案（稳定）

```html
<section style="background: #F7F6F3; padding: 20px; border-radius: 4px; border-left: 4px solid #EB5757;">
<div style="white-space: pre; font-family: Consolas, monospace;">第一行代码</div>
<div style="white-space: pre; font-family: Consolas, monospace;">第二行代码</div>
<div style="white-space: pre; font-family: Consolas, monospace;">第三行代码</div>
</section>
```

**优势**：
- 每行独立 `<div>` 包裹
- 不依赖 `white-space` 跨行继承
- 编辑后格式保持
- 使用 `<section>` 替代 `<pre>`，微信支持更好

---

## 📊 效果对比

### 首次预览

**v2.6**（`<pre>+<code>`）：
```
✅ 正确显示
cd ~/.openclaw/workspace/skills/minimax-docx
bash scripts/setup.sh
```

**v2.7**（`<section>+<div>`）：
```
✅ 正确显示
cd ~/.openclaw/workspace/skills/minimax-docx
bash scripts/setup.sh
```

### 编辑后

**v2.6**（`<pre>+<code>`）：
```
❌ 格式丢失
cd ~/.openclaw/workspace/skills/minimax-docx bash scripts/setup.sh
```
（单行显示）

**v2.7**（`<section>+<div>`）：
```
✅ 格式保持
cd ~/.openclaw/workspace/skills/minimax-docx
bash scripts/setup.sh
```
（保持换行）

---

## 🔧 核心代码实现

### v2.7 代码块处理

```python
# 代码块（v2.7 优化：使用 section+div 结构，微信编辑器更稳定）
if in_code_block:
    if line_stripped.startswith('```'):
        html_parts.append('</section>')
        in_code_block = False
    else:
        # v2.7 关键修复：每行使用 div 包裹，不依赖 white-space
        # 转义 HTML 特殊字符
        safe_line = line.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
        html_parts.append(
            f'<div style="white-space: pre; '
            f'font-family: Consolas, \'Courier New\', monospace; '
            f'font-size: 13px; line-height: 1.6; '
            f'color: #EB5757;">{safe_line}</div>'
        )
    continue

if line_stripped.startswith('```'):
    # v2.7 使用 section 替代 pre，微信编辑器更稳定
    html_parts.append(
        '<section style="background: #F7F6F3; '
        'padding: 20px; border-radius: 4px; '
        'overflow-x: auto; margin: 30px 0; '
        'border-left: 4px solid #EB5757;">'
    )
    in_code_block = True
    continue
```

---

## ✅ 测试清单

### 基础测试
- [ ] 首次预览代码块正确显示
- [ ] 编辑后代码块保持换行
- [ ] 多行命令清晰可读
- [ ] 代码缩进保留
- [ ] 特殊字符正确转义（`&`、`<`、`>`）

### 编辑测试
- [ ] 在代码块前添加文字
- [ ] 在代码块后添加文字
- [ ] 修改代码块内容
- [ ] 删除部分代码行
- [ ] 复制粘贴代码块

### 兼容性测试
- [ ] 微信 PC 端编辑器
- [ ] 微信移动端编辑器
- [ ] 草稿箱预览
- [ ] 手机预览

---

## 🎯 最佳实践

### 代码块使用建议

1. **简洁优先**
   - 代码块不宜过长（建议<50 行）
   - 复杂代码考虑分多个代码块

2. **转义处理**
   - 包含 HTML 字符时自动转义
   - 包含 Markdown 语法时注意转义

3. **视觉标识**
   - 左侧红色边框标识代码块
   - 灰色背景区分正文

### 编辑建议

1. **首次预览后**
   - 确认格式正确再编辑
   - 避免大幅修改代码块

2. **需要修改时**
   - 在源码 Markdown 中修改
   - 重新发布而非编辑器修改

3. **紧急修改**
   - 小修改可在编辑器进行
   - v2.7 格式编辑后保持稳定

---

## 🐛 已知问题

暂无

---

## 📚 相关资源

- **GitHub**: https://github.com/xingkongqy/wechat-mp-xk
- **JVS Claw 推广**: https://www.aliyun.com/activity/ecs/clawdbot?userCode=d8ptsfvb
- **OpenClaw 文档**: https://docs.openclaw.ai
- **微信编辑器规范**: https://developers.weixin.qq.com/doc/offiaccount/Getting_Started/Overview.html

---

## 📈 版本演进

| 版本 | 发布日期 | 核心更新 |
|------|----------|----------|
| v2.5 | 2026-03-31 | 代码块换行修复（`white-space: pre-wrap`） |
| v2.6 | 2026-03-31 | 代码块优先级 + 空单元格继承 |
| v2.7 | 2026-03-31 | 微信编辑器兼容性优化（`section+div`） |

---

## 🔄 自我提升机制

```
用户反馈（编辑后格式丢失）
   ↓
根因分析（微信编辑器 HTML 净化）
   ↓
技术方案（section+div 替代 pre+code）
   ↓
实现验证（重新发布测试）
   ↓
文档更新（SKILL.md + CHANGELOG）
   ↓
版本迭代（v2.7）
   ↓
  持续改进
```

---

## 💡 经验教训

### 教训 1：了解目标平台特性

**问题**：通用 HTML 在微信编辑器表现不佳

**解决**：
- 深入了解微信编辑器的 HTML 处理机制
- 使用微信友好的标签和结构
- 避免依赖可能被重置的样式

### 教训 2：测试场景要全面

**问题**：只测试了首次预览，未测试编辑后

**解决**：
- 建立完整的测试清单
- 包括编辑后场景
- 模拟真实使用流程

### 教训 3：结构优于样式

**问题**：依赖 CSS 属性保持格式

**解决**：
- 使用 HTML 结构保证格式
- 每行独立 `<div>` 包裹
- 不依赖跨行样式继承

---

**持续改进，不断进步！** 🚀

wechat-mp-xk 团队  
2026 年 3 月 31 日
