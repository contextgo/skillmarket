# wechat-mp-xk v2.1 更新日志

**发布日期**: 2026 年 3 月 28 日

---

## 🎉 重大更新

### v2.1.0 - 格式优化与问题修复

#### 核心修复（根据用户反馈）

1. **移除 `---` 分隔符** ✅
   - **问题**: 段落后面出现 `---` 水平线，影响阅读体验
   - **修复**: 忽略 Markdown 水平线语法（`---`、`***`、`___`）
   - **影响**: 所有文章不再显示分隔线

2. **四级标题支持** ✅
   - **问题**: `#### 2.1.1 核心特征` 直接显示原文，未渲染
   - **修复**: 添加四级标题（h4）样式支持
   - **样式**: 16px 字体，600 字重，无背景色
   - **代码**:
     ```python
     if line_stripped.startswith('#### '):
         title_text = process_markdown_inline(line_stripped[5:])
         html_parts.append(f'<h4>...</h4>')
     ```

3. **表格加粗无背景色** ✅
   - **问题**: 表格第一列加粗有黄色背景色，与正文风格不统一
   - **修复**: 表格内加粗仅保留加粗样式，移除背景色
   - **实现**: `process_markdown_inline(text, for_table=True)` 参数控制
   - **对比**:
     ```python
     # 表格内：无背景色
     <strong style="color: #37352F; font-weight: 600;">实践导向</strong>
     
     # 普通段落：有背景色
     <strong style="...; background-color: #FDECC8; ...;">实践导向</strong>
     ```

4. **表格格式对齐优化** ✅
   - **新增**: `vertical-align: top;` 单元格垂直顶部对齐
   - **效果**: 多行内容表格更整齐

---

## 📊 效果对比

### 问题 1: `---` 分隔符

**修复前**（v2.0）:
```
3. AI 代理赋能科研的边界在哪里？
---
二、理论基础与文献综述
```

**修复后**（v2.1）:
```
3. AI 代理赋能科研的边界在哪里？

二、理论基础与文献综述
```

### 问题 2: 四级标题

**修复前**（v2.0）:
```
## 2.1 行动研究方法论
### 2.1.1 核心特征  ← 三级标题
#### 2.1.1 核心特征  ← 显示原文！
```

**修复后**（v2.1）:
```
## 2.1 行动研究方法论
### 2.1.1 核心特征  ← 三级标题（18px，底部黄线）
#### 2.1.1 核心特征  ← 四级标题（16px，无装饰）
```

### 问题 3: 表格加粗背景色

**修复前**（v2.0）:
```
| **实践导向** | 以解决组织实际问题为目标 |
```
显示：**实践导向**（黄色背景）

**修复后**（v2.1）:
```
| **实践导向** | 以解决组织实际问题为目标 |
```
显示：**实践导向**（仅加粗，无背景色）

---

## 🔧 技术实现

### 1. 水平线移除

```python
# v2.1 新增：在标题处理前检查
if line_stripped.startswith('---') or \
   line_stripped.startswith('***') or \
   line_stripped.startswith('___'):
    # 忽略水平线
    continue
```

### 2. 四级标题支持

```python
# v2.1 新增：四级标题
if line_stripped.startswith('#### '):
    title_text = process_markdown_inline(line_stripped[5:])
    html_parts.append(
        f'<h4 style="margin-top: 24px; margin-bottom: 10px;">'
        f'<span class="content" style="font-size: 16px; '
        f'font-weight: 600; color: #37352F;">{title_text}'
        f'</span></h4>'
    )
```

### 3. 表格加粗无背景色

```python
# 新增 for_table 参数
def process_markdown_inline(text, for_table=False):
    if for_table:
        # 表格内：无背景色
        text = re.sub(
            r'\*\*(.*?)\*\*',
            r'<strong style="color: #37352F; font-weight: 600;">\1</strong>',
            text
        )
    else:
        # 普通段落：有背景色
        text = re.sub(
            r'\*\*(.*?)\*\*',
            r'<strong style="...; background-color: #FDECC8; ...">\1</strong>',
            text
        )

# 表格调用时传入 for_table=True
cells_html = ''.join(
    f'<{row_tag}>{process_markdown_inline(c, for_table=True)}</{row_tag}>'
    for c in cells
)
```

---

## 📝 使用示例

### 学术论文发布（推荐）

```bash
python3 wechat_mp_xk.py article paper.md \
  --cover cover.jpg \
  --title "学术论文标题" \
  --author "研究团队"
```

### 技术文档发布

```bash
python3 wechat_mp_xk.py article docs.md \
  --cover tech.png \
  --title "技术文档" \
  --author "技术团队"
```

---

## ✅ 测试清单

发布前请确认：

- [ ] 段落无 `---` 分隔线
- [ ] 四级标题正确渲染
- [ ] 表格加粗无背景色
- [ ] 表格内容顶部对齐
- [ ] 封面图上传成功
- [ ] 发布到草稿箱成功

---

## 🐛 已知问题

暂无

---

## 📚 相关资源

- **GitHub**: https://github.com/xingkongqy/wechat-mp-xk
- **JVS Claw 推广**: https://www.aliyun.com/activity/ecs/clawdbot?userCode=d8ptsfvb
- **OpenClaw 文档**: https://docs.openclaw.ai

---

## 🎯 未来规划

### v2.2（计划中）
- [ ] 五级标题支持（`#####`）
- [ ] 表格跨页优化
- [ ] 图片自动压缩
- [ ] 发布历史记录

### v3.0（规划中）
- [ ] 可视化编辑器
- [ ] 模板系统
- [ ] 定时发布
- [ ] 数据分析

---

## 📈 版本演进

| 版本 | 发布日期 | 核心更新 |
|------|----------|----------|
| v1.3 | 2026-03-25 | 基础功能、Knowledge-Base 主题 |
| v2.0 | 2026-03-28 | Markdown 渲染全面优化 |
| v2.1 | 2026-03-28 | 格式问题修复（用户反馈驱动） |

---

**持续改进，不断进步！** 🚀

wechat-mp-xk 团队  
2026 年 3 月 28 日
