#!/usr/bin/env python3
"""
微信公众号文章发布工具 - 分步流程版 v2.2
参考：https://github.com/lyhue1991/wxgzh

支持分步执行：
1. md2html - Markdown 转 HTML（应用 Knowledge-Base 主题）
2. fix - 修复 HTML（处理图片、移除不适合结构）
3. cover - 生成/上传封面图
4. publish - 发布到草稿箱

也可一键执行：article - 完成全部流程

v2.2 更新：
- 优化流程图表格样式（文字居中、边框对齐、连接线一致）
- 单列表格自动居中显示
- 表格内多行内容垂直居中
"""

import sys
import requests
import json
import time
import os
import argparse
import tempfile
import re
from datetime import datetime

# 配置
env_file = os.path.join(os.path.dirname(__file__), '.env')
if os.path.exists(env_file):
    with open(env_file, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#') and '=' in line:
                key, value = line.split('=', 1)
                os.environ[key.strip()] = value.strip()

APPID = os.environ.get('WX_APPID')
SECRET = os.environ.get('WX_SECRET')
TOKEN_FILE = '/tmp/wechat_token.json'
DEFAULT_OUTPUT_DIR = './.wxgzh'

# 统一推广链接
JVS_CLAW_PROMO_LINK = "https://www.aliyun.com/activity/ecs/clawdbot?userCode=d8ptsfvb"

# 验证配置
if not APPID or not SECRET:
    print("❌ 错误：缺少 WX_APPID 或 WX_SECRET 配置")
    sys.exit(1)

# ==================== 工具函数 ====================

def get_access_token():
    """获取 stable_access_token"""
    if os.path.exists(TOKEN_FILE):
        try:
            with open(TOKEN_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
                if time.time() < data.get('expires_at', 0):
                    return data['access_token']
        except:
            pass
    
    url = 'https://api.weixin.qq.com/cgi-bin/stable_token'
    data = {
        'grant_type': 'client_credential',
        'appid': APPID,
        'secret': SECRET,
        'force_refresh': False
    }
    resp = requests.post(
        url,
        data=json.dumps(data, ensure_ascii=False).encode('utf-8'),
        timeout=10,
        headers={'Content-Type': 'application/json; charset=utf-8'}
    )
    result = resp.json()
    
    if 'access_token' in result:
        result['expires_at'] = time.time() + 7000
        with open(TOKEN_FILE, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False)
        return result['access_token']
    else:
        raise Exception(f"Token 获取失败：{result}")

def extract_front_matter(md_content):
    """提取 Front Matter 元数据"""
    front_matter = {}
    content = md_content
    
    if md_content.startswith('---'):
        parts = md_content.split('---', 2)
        if len(parts) >= 3:
            fm_text = parts[1].strip()
            content = parts[2].strip()
            
            for line in fm_text.split('\n'):
                if ':' in line:
                    key, value = line.split(':', 1)
                    front_matter[key.strip()] = value.strip().strip('"\'')
    
    return front_matter, content

def process_markdown_inline(text, for_table=False):
    """
    处理行内 Markdown 语法
    v2.8 优化：链接优先处理，避免被其他语法破坏
    
    Args:
        text: 待处理的文本
        for_table: 是否为表格内容（表格内加粗无背景色）
    """
    if not text:
        return text
    
    # v2.8 关键修复：链接优先处理（第一位），避免被加粗/斜体破坏
    # 处理链接 [text](url)
    text = re.sub(
        r'\[([^\]]+)\]\(([^)]+)\)',
        r'<a href="\2" style="color: #1E80FF; text-decoration: none; word-break: break-all; -webkit-tap-highlight-color: rgba(0,0,0,0);">\1</a>',
        text
    )
    
    # 处理加粗 **text**
    if for_table:
        text = re.sub(
            r'\*\*(.*?)\*\*',
            r'<strong style="color: #37352F; font-weight: 600;">\1</strong>',
            text
        )
    else:
        text = re.sub(
            r'\*\*(.*?)\*\*',
            r'<strong style="color: #37352F; font-weight: 600; background-color: #FDECC8; padding: 2px 4px; margin: 0 2px; border-radius: 3px;">\1</strong>',
            text
        )
    
    # 处理斜体 *text*
    text = re.sub(
        r'\*(?!\*)(.*?)(?<!\*)\*',
        r'<em style="font-style: italic;">\1</em>',
        text
    )
    
    # 处理行内代码 `code`
    text = re.sub(
        r'`([^`]+)`',
        r'<code style="background: #F7F6F3; padding: 2px 6px; border-radius: 3px; font-family: \'SFMono-Regular\', Consolas, monospace; font-size: 13px; color: #EB5757;">\1</code>',
        text
    )
    
    return text

def is_flowchart_table(cells):
    """
    判断是否为流程图表格
    特征：单列或多列，但内容包含流程步骤关键词
    """
    if not cells:
        return False
    
    # 单列表格通常是流程图或步骤说明
    if len(cells) == 1:
        return True
    
    # 检查是否包含流程关键词
    flowchart_keywords = [
        '阶段', '步骤', '流程', '循环', '模型',
        'Diagnosing', 'Action', 'Planning', 'Taking', 'Evaluating',
        '诊断', '行动', '规划', '执行', '评估',
        '基础设施', '建立', '研究范围'
    ]
    
    first_cell = cells[0].lower()
    return any(keyword.lower() in first_cell for keyword in flowchart_keywords)

def parse_table_alignment(separator_line):
    """
    解析 Markdown 表格分隔线的对齐语法
    |:-| 左对齐，|-:| 右对齐，|:-:| 居中对齐
    
    Args:
        separator_line: 分隔线，如 "|:---|:---:|---:|"
    
    Returns:
        list: 每列的对齐方式 ['left', 'center', 'right']
    """
    alignments = []
    cells = [c.strip() for c in separator_line.split('|') if c.strip()]
    
    for cell in cells:
        if cell.startswith(':') and cell.endswith(':'):
            alignments.append('center')  # :---: 居中
        elif cell.endswith(':'):
            alignments.append('right')   # ---: 右对齐
        else:
            alignments.append('left')    # --- 或 :--- 左对齐
    
    return alignments

def markdown_to_kb_html(md_content):
    """Markdown 转 Knowledge-Base 风格 HTML（v2.2 优化版）"""
    
    front_matter, content = extract_front_matter(md_content)
    
    lines = content.split('\n')
    html_parts = []
    
    html_parts.append('<section id="wemd" style="padding: 30px 24px; max-width: 677px; margin: 0 auto; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', \'Helvetica Neue\', \'PingFang SC\', sans-serif; color: #37352F; word-break: break-word;">')
    
    in_code_block = False
    in_table = False
    last_line_was_table = False
    current_table_is_flowchart = False
    
    for line in lines:
        line_stripped = line.strip()
        
        # 代码块（v2.7 优化：使用 section+div 结构，微信编辑器更稳定）
        # 微信编辑器特点：首次预览正确，但编辑后会重置 pre/code 样式
        # 解决方案：使用 section 包裹 + div 每行 + !important 强制样式
        if in_code_block:
            if line_stripped.startswith('```'):
                html_parts.append('</section>')
                in_code_block = False
                last_line_was_table = False
            else:
                # v2.7 关键修复：每行使用 div 包裹，不依赖 white-space
                # 转义 HTML 特殊字符
                safe_line = line.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
                html_parts.append(f'<div style="white-space: pre; font-family: Consolas, \'Courier New\', monospace; font-size: 13px; line-height: 1.7; color: #EB5757;">{safe_line}</div>')
            continue
        
        if line_stripped.startswith('```'):
            # v2.7 使用 section 替代 pre，微信编辑器更稳定
            html_parts.append('<section style="background: #F7F6F3; padding: 20px; border-radius: 4px; overflow-x: auto; margin: 30px 0; border-left: 4px solid #EB5757;">')
            in_code_block = True
            last_line_was_table = False
            continue
        
        # 空行
        if not line_stripped:
            if in_table:
                html_parts.append('</table></section></section>')
                in_table = False
            last_line_was_table = False
            continue
        
        # v2.1 修复：移除水平线 `---` 或 `***`
        if line_stripped.startswith('---') or line_stripped.startswith('***') or line_stripped.startswith('___'):
            last_line_was_table = False
            continue
        
        # 一级标题
        if line_stripped.startswith('# '):
            title_text = process_markdown_inline(line_stripped[2:])
            html_parts.append(f'<h1 style="margin-top: 50px; margin-bottom: 40px; text-align: left; border-bottom: 1px solid #E3E2E0; padding-bottom: 20px;"><span class="content" style="font-size: 28px; font-weight: 700; color: #37352F; display: inline-block; line-height: 1.2;">{title_text}</span></h1>')
            last_line_was_table = False
            continue
        
        # 二级标题
        if line_stripped.startswith('## '):
            title_text = process_markdown_inline(line_stripped[3:])
            html_parts.append(f'<h2 style="margin-top: 40px; margin-bottom: 20px; text-align: left;"><span class="content" style="display: block; font-size: 22px; font-weight: 600; color: #37352F; padding: 8px 12px; background-color: #F7F6F3; border-radius: 4px; line-height: 1.3;">{title_text}</span></h2>')
            last_line_was_table = False
            continue
        
        # 三级标题
        if line_stripped.startswith('### '):
            title_text = process_markdown_inline(line_stripped[4:])
            html_parts.append(f'<h3 style="margin-top: 30px; margin-bottom: 12px;"><span class="content" style="font-size: 18px; font-weight: 600; color: #37352F; display: inline-block; border-bottom: 3px solid #FDECC8; padding-bottom: 2px;">{title_text}</span></h3>')
            last_line_was_table = False
            continue
        
        # v2.1 新增：四级标题支持
        if line_stripped.startswith('#### '):
            title_text = process_markdown_inline(line_stripped[5:])
            html_parts.append(f'<h4 style="margin-top: 24px; margin-bottom: 10px;"><span class="content" style="font-size: 16px; font-weight: 600; color: #37352F; display: inline-block;">{title_text}</span></h4>')
            last_line_was_table = False
            continue
        
        # 引用块
        if line_stripped.startswith('> '):
            quote_text = process_markdown_inline(line_stripped[2:])
            html_parts.append(f'<div class="multiquote-1" style="margin: 24px 0; padding: 16px 16px 16px 20px; background-color: #F1F1EF; border: none; border-radius: 4px; border-left: 4px solid #37352F; overflow: visible !important;"><p style="margin: 0; color: #37352F; font-size: 15px; line-height: 1.6;">{quote_text}</p></div>')
            last_line_was_table = False
            continue
        
        # 表格处理（v2.6 优化：支持空单元格自动继承）
        if line_stripped.startswith('|'):
            if not in_table:
                # 判断是否为流程图表格
                test_cells = [c.strip() for c in line_stripped.split('|') if c.strip()]
                current_table_is_flowchart = is_flowchart_table(test_cells)
                
                if current_table_is_flowchart:
                    # 流程图表格样式：居中对齐，统一边框
                    html_parts.append('<section><section><table style="width: 100%; border-collapse: collapse; margin: 30px 0; font-size: 15px; border: 2px solid #E3E2E0; border-radius: 4px; word-break: break-word;">')
                else:
                    # 普通表格样式（v2.4 优化：添加 word-break）
                    html_parts.append('<section><section><table style="width: 100%; border-collapse: collapse; margin: 30px 0; font-size: 14px; border: 1px solid #E3E2E0; border-radius: 0; word-break: break-word;">')
                in_table = True
                table_column_alignments = []  # 存储每列的对齐方式
                table_prev_row_cells = []  # v2.6 新增：存储上一行单元格用于继承
            
            # 检查是否为分隔线行（包含 : 和 -）
            if line_stripped.startswith('|---') or line_stripped.startswith('|:--') or line_stripped.startswith('|--:'):
                # 解析对齐语法
                table_column_alignments = parse_table_alignment(line_stripped)
                last_line_was_table = True
                continue
            
            # 跳过分隔线行（已处理）
            if not (line_stripped.startswith('|---') or line_stripped.startswith('|:--') or line_stripped.startswith('|--:')):
                # v2.6 新增：解析原始单元格（保留空单元格）
                raw_cells = line_stripped.split('|')
                raw_cells = [c.strip() for c in raw_cells]  # 保留空字符串
                
                # 移除首尾空元素（Markdown 表格以 | 开头和结尾）
                if raw_cells and raw_cells[0] == '':
                    raw_cells = raw_cells[1:]
                if raw_cells and raw_cells[-1] == '':
                    raw_cells = raw_cells[:-1]
                
                # v2.6 关键修复：自动填充空单元格（继承上一行对应列的值）
                if 'table_prev_row_cells' not in locals():
                    table_prev_row_cells = []
                
                cells = []
                for i, cell in enumerate(raw_cells):
                    if cell == '' and i < len(table_prev_row_cells):
                        # 空单元格，继承上一行的值
                        cells.append(table_prev_row_cells[i])
                    else:
                        cells.append(cell)
                
                # 更新上一行单元格记录
                if cells:
                    table_prev_row_cells = cells
                
                if cells:
                    # 判断是否为表头
                    is_header = any(word in cells[0] for word in ['角色', '指标', '任务', '时间', '使用', '检查', '步骤', '文件', '项目', '状态', '版本', '特征', '内涵', '体现', '阶段', '对比', '类型', '权益', '说明', '适用场景', '首发优惠', '本地接入', '云端', '跨平台', '多任务', 'AI 技能', '专属文件', '新功能', '高峰优先', '月度积分'])
                    row_tag = 'th' if is_header else 'td'
                    
                    if current_table_is_flowchart:
                        # v2.2 流程图表格样式优化（v2.3 添加 word-break）
                        if is_header:
                            row_style = 'background: #F7F6F3; color: #37352F; font-weight: 600;'
                        else:
                            # 流程图内容：文字居中，垂直居中，统一边框
                            row_style = 'color: #37352F !important; background: #fff; text-align: center; vertical-align: middle;'
                        
                        cell_style = row_style + ' border: 2px solid #E3E2E0; padding: 16px 12px; word-break: break-word; white-space: normal;'
                    else:
                        # v2.4 普通表格样式优化：支持列对齐和表头居中
                        if is_header:
                            # v2.4 新增：表头内容上下左右居中
                            row_style = 'background: #F7F6F3; color: #37352F; font-weight: 600; text-align: center; vertical-align: middle;'
                        else:
                            row_style = 'color: #37352F !important; background: #fff;'
                        
                        # v2.4 关键优化：根据分隔线语法设置对齐方式
                        if table_column_alignments:
                            col_index = len([c for c in html_parts if '<tr>' in c]) % len(table_column_alignments)
                            align = table_column_alignments[col_index] if col_index < len(table_column_alignments) else 'left'
                            align_style = f'text-align: {align}; vertical-align: middle;'
                        else:
                            align_style = 'text-align: left; vertical-align: top;'
                        
                        # v2.3 关键修复：添加 word-break 和 white-space 确保文字换行
                        cell_style = row_style + ' border: 1px solid #E3E2E0; padding: 10px 12px; ' + align_style + ' word-break: break-word; white-space: normal;'
                    
                    # v2.1 关键修复：表格内容使用 for_table=True，加粗无背景色
                    cells_html = ''.join(f'<{row_tag} style="{cell_style}">{process_markdown_inline(c, for_table=True)}</{row_tag}>' for c in cells)
                    row = f'<tr>{cells_html}</tr>'
                    html_parts.append(row)
            last_line_was_table = True
            continue
        elif in_table and not last_line_was_table:
            html_parts.append('</table></section></section>')
            in_table = False
            current_table_is_flowchart = False
            table_column_alignments = []
            table_prev_row_cells = []  # v2.6 新增：重置单元格继承
            last_line_was_table = False
        
        # 列表
        if line_stripped.startswith('- ') or line_stripped.startswith('* '):
            list_text = process_markdown_inline(line_stripped[2:])
            html_parts.append(f'<ul style="list-style-type: disc; padding-left: 24px; margin: 20px 0; color: #37352F;"><li style="margin-bottom: 8px; line-height: 1.0;"><section style="color: #37352F; font-size: 16px;">{list_text}</section></li></ul>')
            last_line_was_table = False
            continue
        
        # 普通段落（v2.1 优化）
        paragraph = process_markdown_inline(line_stripped)
        html_parts.append(f'<section><section><p style="margin-top: 16px; margin-bottom: 16px; line-height: 1.25; letter-spacing: 0.2px; text-align: justify; color: #37352F; font-size: 16px;">{paragraph}</p></section></section>')
        last_line_was_table = False
    
    # 关闭未闭合标签
    if in_code_block:
        html_parts.append('</code></pre>')
    if in_table:
        html_parts.append('</table></section></section>')
    
    html_parts.append('</section>')
    
    html_content = '\n'.join(html_parts)
    
    return html_content, front_matter

def upload_image(image_path, token=None):
    """上传图片获取 media_id"""
    if token is None:
        token = get_access_token()
    
    if not os.path.exists(image_path):
        return None
    
    url = f'https://api.weixin.qq.com/cgi-bin/material/add_material?access_token={token}&type=image'
    with open(image_path, 'rb') as f:
        files = {'media': f}
        resp = requests.post(url, files=files, timeout=30)
    
    result = json.loads(resp.text, strict=False)
    return result.get('media_id')

def fix_html(html_content, upload_images=True):
    """修复 HTML"""
    html_content = re.sub(r'<script[^>]*>.*?</script>', '', html_content, flags=re.DOTALL)
    html_content = re.sub(r'<iframe[^>]*>.*?</iframe>', '', html_content, flags=re.DOTALL)
    html_content = re.sub(r'<style[^>]*>.*?</style>', '', html_content, flags=re.DOTALL)
    return html_content

def create_draft(title, content, summary, thumb_media_id, author='黑白'):
    """创建草稿"""
    token = get_access_token()
    url = f'https://api.weixin.qq.com/cgi-bin/draft/add?access_token={token}'
    
    data = {
        'articles': [{
            'title': title,
            'author': author,
            'digest': summary,
            'content': content,
            'thumb_media_id': thumb_media_id,
            'show_cover_pic': 1
        }]
    }
    
    resp = requests.post(
        url, 
        data=json.dumps(data, ensure_ascii=False).encode('utf-8'), 
        timeout=30, 
        headers={'Content-Type': 'application/json; charset=utf-8'}
    )
    result = resp.json()
    
    if result.get('errcode', 0) == 0:
        return result.get('media_id'), result
    else:
        raise Exception(f"发布失败：{result.get('errmsg', '未知错误')}")

# ==================== 分步命令 ====================

def cmd_md2html(args):
    """Step 1: Markdown 转 HTML"""
    print("=" * 60)
    print("Step 1: Markdown 转 HTML（Knowledge-Base 主题 v2.2）")
    print("=" * 60)
    
    if not os.path.exists(args.input):
        print(f"❌ 文件不存在：{args.input}")
        sys.exit(1)
    
    with open(args.input, 'r', encoding='utf-8') as f:
        md_content = f.read()
    
    html_content, front_matter = markdown_to_kb_html(md_content)
    
    output_file = args.output
    if not output_file:
        output_dir = args.output_dir or DEFAULT_OUTPUT_DIR
        os.makedirs(output_dir, exist_ok=True)
        base_name = os.path.splitext(os.path.basename(args.input))[0]
        output_file = os.path.join(output_dir, f'{base_name}.html')
    
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(html_content)
    
    print(f"✅ HTML 已生成：{output_file}")
    print(f"   内容长度：{len(html_content)}")
    print(f"   v2.2 优化：流程图表格居中、边框对齐、连接线一致")
    
    if front_matter:
        print(f"   元数据：{front_matter}")
    
    return output_file, front_matter

def cmd_fix(args):
    """Step 2: 修复 HTML"""
    print("=" * 60)
    print("Step 2: 修复 HTML")
    print("=" * 60)
    
    if not os.path.exists(args.input):
        print(f"❌ 文件不存在：{args.input}")
        sys.exit(1)
    
    with open(args.input, 'r', encoding='utf-8') as f:
        html_content = f.read()
    
    html_content = fix_html(html_content, upload_images=not args.no_upload)
    
    output_file = args.output or args.input
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(html_content)
    
    print(f"✅ HTML 已修复：{output_file}")
    print(f"   内容长度：{len(html_content)}")
    
    return output_file

def cmd_cover(args):
    """Step 3: 上传封面图"""
    print("=" * 60)
    print("Step 3: 上传封面图")
    print("=" * 60)
    
    if not args.cover:
        print("❌ 请指定封面图路径：--cover <path>")
        sys.exit(1)
    
    media_id = upload_image(args.cover)
    
    if media_id:
        print(f"✅ 封面图上传成功")
        print(f"   media_id: {media_id}")
        
        if args.output:
            with open(args.output, 'w', encoding='utf-8') as f:
                json.dump({'media_id': media_id}, f, ensure_ascii=False)
            print(f"   已保存：{args.output}")
        
        return media_id
    else:
        print("❌ 封面图上传失败")
        sys.exit(1)

def cmd_publish(args):
    """Step 4: 发布到草稿箱"""
    print("=" * 60)
    print("Step 4: 发布到草稿箱")
    print("=" * 60)
    
    if not os.path.exists(args.article):
        print(f"❌ 文章文件不存在：{args.article}")
        sys.exit(1)
    
    with open(args.article, 'r', encoding='utf-8') as f:
        content = f.read()
    
    thumb_media_id = None
    if args.cover:
        if os.path.exists(args.cover):
            thumb_media_id = upload_image(args.cover)
        else:
            thumb_media_id = args.cover
    
    if not thumb_media_id:
        print("❌ 请指定封面图：--cover <path>")
        sys.exit(1)
    
    title = args.title or os.path.basename(args.article)
    author = args.author or '黑白'
    summary = args.summary or ''
    
    try:
        media_id, result = create_draft(title, content, summary, thumb_media_id, author)
        print(f"✅ 发布成功！")
        print(f"   草稿 ID: {media_id}")
        print(f"   标题：{title}")
        print(f"   作者：{author}")
        print(f"   请前往公众号后台查看：https://mp.weixin.qq.com")
        return media_id
    except Exception as e:
        print(f"❌ 发布失败：{e}")
        sys.exit(1)

def cmd_article(args):
    """一键发布"""
    print("=" * 60)
    print("一键发布：Markdown → 公众号草稿箱 (v2.2)")
    print("=" * 60)
    print()
    
    html_file, front_matter = cmd_md2html(args)
    print()
    
    args.input = html_file
    args.output = html_file
    if not hasattr(args, 'no_upload'):
        args.no_upload = False
    cmd_fix(args)
    print()
    
    if args.cover:
        cover_file = os.path.join(os.path.dirname(html_file), 'cover.json')
        args.output = cover_file
        media_id = cmd_cover(args)
        print()
    else:
        media_id = None
        print("⚠️ 未指定封面图")
        print()
    
    args.article = html_file
    args.title = args.title or front_matter.get('title')
    args.author = args.author or front_matter.get('author', '黑白')
    args.summary = args.summary or front_matter.get('digest', '')
    args.cover = media_id or args.cover
    cmd_publish(args)

# ==================== 主函数 ====================

def main():
    parser = argparse.ArgumentParser(description='微信公众号文章发布工具 - 分步流程版 v2.2')
    subparsers = parser.add_subparsers(dest='command', help='子命令')
    
    p_md2html = subparsers.add_parser('md2html', help='Markdown 转 HTML')
    p_md2html.add_argument('input', help='输入 Markdown 文件')
    p_md2html.add_argument('-o', '--output', help='输出 HTML 文件')
    p_md2html.add_argument('--output-dir', default=DEFAULT_OUTPUT_DIR, help='输出目录')
    p_md2html.set_defaults(func=cmd_md2html)
    
    p_fix = subparsers.add_parser('fix', help='修复 HTML')
    p_fix.add_argument('input', help='输入 HTML 文件')
    p_fix.add_argument('-o', '--output', help='输出 HTML 文件')
    p_fix.add_argument('--no-upload', action='store_true', help='不上传图片')
    p_fix.set_defaults(func=cmd_fix)
    
    p_cover = subparsers.add_parser('cover', help='上传封面图')
    p_cover.add_argument('--cover', required=True, help='封面图路径')
    p_cover.add_argument('-o', '--output', help='保存 media_id 的文件')
    p_cover.set_defaults(func=cmd_cover)
    
    p_publish = subparsers.add_parser('publish', help='发布到草稿箱')
    p_publish.add_argument('--article', required=True, help='HTML 文章文件')
    p_publish.add_argument('--cover', required=True, help='封面图路径或 media_id')
    p_publish.add_argument('--title', help='文章标题')
    p_publish.add_argument('--author', default='黑白', help='作者名')
    p_publish.add_argument('--summary', default='', help='文章摘要')
    p_publish.set_defaults(func=cmd_publish)
    
    p_article = subparsers.add_parser('article', help='一键发布')
    p_article.add_argument('input', help='输入 Markdown 文件')
    p_article.add_argument('-o', '--output', help='输出 HTML 文件')
    p_article.add_argument('--output-dir', default=DEFAULT_OUTPUT_DIR, help='输出目录')
    p_article.add_argument('--cover', help='封面图路径')
    p_article.add_argument('--title', help='文章标题')
    p_article.add_argument('--author', default='黑白', help='作者名')
    p_article.add_argument('--summary', default='', help='文章摘要')
    p_article.set_defaults(func=cmd_article)
    
    args = parser.parse_args()
    
    if args.command is None:
        parser.print_help()
        sys.exit(1)
    
    args.func(args)

if __name__ == '__main__':
    main()
