# wechat-mp-xk v2.0 更新日志

**发布日期**: 2026 年 3 月 28 日

---

## 🎉 重大更新

### v2.0.0 - Markdown 渲染全面优化

#### 核心修复

1. **表格内 Markdown 语法渲染** ✅
   - 修复前：表格单元格内的 `**加粗**` 直接显示原文
   - 修复后：正确渲染为 HTML 加粗样式
   - 影响范围：所有包含表格的文章

2. **行内格式全面支持** ✅
   - **加粗** `**text**` → 黄色高亮背景
   - *斜体* `*text*` → 斜体样式
   - `代码` `` `code` `` → 红色等宽字体
   - [链接](url) `[text](url)` → 蓝色可点击链接

3. **标题 Markdown 处理** ✅
   - 一级、二级、三级标题均支持行内格式
   - 标题中的加粗、链接正确渲染

4. **引用块优化** ✅
   - 引用块内的 Markdown 语法正确处理

#### 技术改进

```python
# 新增加粗函数 process_markdown_inline()
def process_markdown_inline(text):
    """处理行内 Markdown 语法"""
    # 加粗
    text = re.sub(r'\*\*(.*?)\*\*', r'<strong>...</strong>', text)
    # 斜体
    text = re.sub(r'\*(?!\*)(.*?)(?<!\*)\*', r'<em>...</em>', text)
    # 代码
    text = re.sub(r'`([^`]+)`', r'<code>...</code>', text)
    # 链接
    text = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', r'<a href="...">...</a>', text)
    return text
```

#### 推广链接统一

- 新增 `JVS_CLAW_PROMO_LINK` 常量
- 统一使用链接：https://www.aliyun.com/activity/ecs/clawdbot?userCode=d8ptsfvb

---

## 📊 效果对比

### 表格渲染对比

**修复前**（v1.x）:
```
| **实践导向** | 以解决组织实际问题为目标 |
```
显示为：`**实践导向**`（原文）

**修复后**（v2.0）:
```
| <strong>实践导向</strong> | 以解决组织实际问题为目标 |
```
显示为：**实践导向**（正确渲染）

### 内容长度对比

| 版本 | 学术文章长度 | 提升 |
|------|-------------|------|
| v1.3 | 87,262 字符 | - |
| v2.0 | 91,863 字符 | +5.3% |

---

## 🔧 升级指南

### 方式 1：覆盖升级

```bash
cd ~/.openclaw/workspace/skills/wechat-mp-xk

# 备份旧版本
cp wechat_mp_xk.py wechat_mp_xk.py.bak

# 下载新版本
curl -L https://github.com/xingkongqy/wechat-mp-xk/raw/main/wechat_mp_xk.py \
  -o wechat_mp_xk.py

# 验证版本
python3 wechat_mp_xk.py --version
```

### 方式 2：重新安装

```bash
# 卸载旧版本
rm -rf ~/.openclaw/workspace/skills/wechat-mp-xk

# 重新克隆
git clone https://github.com/xingkongqy/wechat-mp-xk.git \
  ~/.openclaw/workspace/skills/wechat-mp-xk

# 配置凭证
cp .env.example .env
# 编辑 .env 填入 AppID 和 Secret
```

---

## ✅ 测试清单

发布前请确认以下功能正常：

- [ ] 表格内加粗正确渲染
- [ ] 表格内链接正确显示
- [ ] 标题中的 Markdown 格式正常
- [ ] 列表项加粗正常
- [ ] 引用块格式正常
- [ ] 封面图上传成功
- [ ] 发布到草稿箱成功

---

## 📝 使用示例

### 学术论文发布

```bash
python3 wechat_mp_xk.py article paper.md \
  --cover cover.jpg \
  --title "学术论文标题" \
  --author "研究团队"
```

### 技术文档发布

```bash
python3 wechat_mp_xk.py article docs.md \
  --cover tech.png \
  --title "技术文档" \
  --author "技术团队"
```

---

## 🐛 已知问题

暂无

---

## 📚 相关资源

- **GitHub**: https://github.com/xingkongqy/wechat-mp-xk
- **JVS Claw**: https://www.aliyun.com/activity/ecs/clawdbot?userCode=d8ptsfvb
- **OpenClaw 文档**: https://docs.openclaw.ai

---

## 🎯 未来规划

### v2.1（计划中）
- [ ] 支持更多 Markdown 语法（删除线、下划线等）
- [ ] 图片自动压缩
- [ ] 多文章批量发布
- [ ] 发布历史记录

### v3.0（规划中）
- [ ] 可视化编辑器
- [ ] 模板系统
- [ ] 定时发布
- [ ] 数据分析

---

**持续改进，不断进步！** 🚀

wechat-mp-xk 团队  
2026 年 3 月 28 日
