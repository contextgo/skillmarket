---
name: ai-agent-change-safety
description: Evaluate whether an AI agent or workflow change is safe to deploy. Use when reviewing prompt updates, model switches, tool integrations, workflow changes, or release readiness. Also covers risk scoring, blast radius, safeguards, rollback planning, and Go / Conditional Go / No-Go decisions.
user-invocable: true
metadata: {"openclaw":{"emoji":"🛡️","os":["linux","darwin","win32"]}}
---

# AI Agent Change Safety

Evaluate whether an AI agent or workflow change is safe to deploy.

Review the proposed change, estimate risk and blast radius, define
required safeguards, check rollback readiness, and return one clear
recommendation:

```text
Go
Conditional Go
No-Go
Default behavior is analysis-only. Use only information explicitly
provided by the user.

Quick Start
bash
clawhub install ai-agent-change-safety
text
changesafe prompt update for support agent with stricter refusal behavior
changesafe --high-risk switch from model A to model B for production support workflows
changesafe --verdict-only tool integration update with fallback and rollback plan
Best For
Agent builders

Prompt engineers

Agent ops teams

Release reviewers

Teams shipping model, tool, or workflow changes

Quick Reference
Need	Use
Standard deployment safety review	changesafe [change summary]
More conservative review	changesafe --strict [change summary]
High-risk release posture	changesafe --high-risk [change summary]
Structured export	changesafe --json [change summary]
Fast decision only	changesafe --verdict-only [change summary]
When to Use
Use this skill when the user asks:

Is this change safe to deploy

Review a prompt update

Assess a model switch

Check a tool integration change

Evaluate workflow logic changes

Estimate blast radius

Define safeguards before rollout

Decide Go / Conditional Go / No-Go

Safety Constraints
text
- Use only user-provided information or synthetic examples
- Do not access local files, credentials, or system configuration automatically
- Do not execute scripts unless explicitly provided and approved
- Do not retrieve external data automatically
Modes
text
changesafe [change summary]
changesafe --strict [change summary]
changesafe --high-risk [change summary]
changesafe --json [change summary]
changesafe --verdict-only [change summary]
If no mode is specified, use the standard review flow.

Inputs
text
change_summary
change_type
expected_improvement
affected_components
risk_level          | low / medium / high
current_safeguards
rollback_plan
regression_results  | optional
monitoring_plan     | optional
Example:

json
{
  "change_summary": "Switch from model A to model B and simplify the system prompt",
  "change_type": "model change",
  "expected_improvement": "Lower latency and better instruction following",
  "affected_components": ["core responses", "tool calling"],
  "risk_level": "medium"
}
Change Categories
text
- Prompt change
- Model change
- Tool integration
- Workflow logic change
- System configuration change
Always record:

text
- purpose of change
- expected improvement
- affected components
Risk Scoring
Score each factor from 1 to 5:

text
Operational impact  — could workflows break
Safety risk         — could harmful outputs increase
Tool reliability    — could tool behavior degrade
User impact         — could users receive worse responses
Reversibility       — how hard is rollback
Risk classification:

text
5–8   → Low risk
9–15  → Medium risk
16–25 → High risk
Blast Radius
Estimate how widely the change may affect the system.

Check:

text
- which workflows are affected
- which users or systems depend on the change
- whether failures could cascade across tools or workflows
Levels:

text
Low    — isolated feature or workflow
Medium — multiple workflows affected
High   — core system logic affected
Safeguards
Define protections required before deployment.

Examples:

text
- human approval checkpoints
- validation prompts
- tool-call verification
- monitoring alerts
- rate limiting
- staged rollout
High-risk changes should require explicit human approval.

Rollback Planning
Every approved deployment should include:

text
- previous working version
- rollback trigger conditions
- rollback procedure
- rollback validation tests
Rollback should be fast and executable.

Workflow
Step 1 — Describe the Change

Capture:

text
- change type
- purpose
- expected improvement
- affected components
Step 2 — Score Risk

Assign 1–5 scores for:

text
- operational impact
- safety risk
- tool reliability risk
- user impact
- reversibility
Step 3 — Estimate Blast Radius

Classify as:

text
Low / Medium / High
Explain what is affected and how failures could spread.

Step 4 — Define Safeguards

List safeguards required before rollout.

Step 5 — Review Rollback Readiness

Check whether rollback is:

text
- defined
- quick
- testable
- realistic
Step 6 — Return Recommendation

Return:

text
- executive summary
- risk score and classification
- blast radius
- required safeguards
- rollback plan
- final recommendation
- confidence
Recommendation Rules
Go

text
Risk is low, blast radius is limited, safeguards are sufficient, and rollback is clear.
Conditional Go

text
Deployment may proceed only after listed safeguards or checks are completed.
No-Go

text
Risk is too high, safeguards are insufficient, rollback is weak, or evidence is incomplete.
Output Template
text
## Executive Summary
[Short description of the change and main conclusion]

## Change Overview
- Change type:
- Expected improvement:
- Affected components:

## Risk Score
- Operational impact:
- Safety risk:
- Tool reliability:
- User impact:
- Reversibility:
- Total score:
- Classification:

## Blast Radius
- Level:
- Explanation:

## Required Safeguards
- Safeguard 1
- Safeguard 2
- Safeguard 3

## Rollback Plan
- Previous version:
- Trigger conditions:
- Rollback steps:
- Validation after rollback:

## Final Recommendation
Go / Conditional Go / No-Go

## Confidence
high / medium / low
JSON Output
json
{
  "change_summary": "",
  "change_type": "",
  "risk_level": "medium",
  "risk_score": {
    "operational_impact": 0,
    "safety_risk": 0,
    "tool_reliability": 0,
    "user_impact": 0,
    "reversibility": 0,
    "total": 0,
    "classification": "medium"
  },
  "blast_radius": {
    "level": "medium",
    "explanation": ""
  },
  "required_safeguards": [],
  "rollback_plan": {
    "previous_version": "",
    "trigger_conditions": [],
    "steps": [],
    "validation_tests": []
  },
  "recommendation": "Conditional Go",
  "confidence": "medium",
  "notes": []
}
Limits
This skill does not:

guarantee production safety

replace monitoring or live experiments

infer unknown system details not provided by the user

approve risky changes without evidence

Tips
Use this skill before release, not after an incident.

Pair it with regression results when possible.

Treat missing rollback detail as a serious weakness.

If blast radius is high, prefer staged rollout and human approval.

If evidence is incomplete, lower confidence instead of guessing.

Keep the recommendation operational.

Author
Vassiliy Lakhonin