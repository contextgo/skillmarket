import Vision
import AppKit
import Foundation

// 检查参数
let arguments = CommandLine.arguments
if arguments.count < 2 {
    print("Usage: ocr <image_path>", to: .standardError)
    exit(1)
}

let imagePath = arguments[1]

// 加载图片
guard let image = NSImage(contentsOfFile: imagePath) else {
    print("Error: Cannot load image at path: \(imagePath)", to: .standardError)
    exit(1)
}

guard let cgImage = image.cgImage(forProposedRect: nil, context: nil, hints: nil) else {
    print("Error: Cannot convert image to CGImage", to: .standardError)
    exit(1)
}

// 创建 OCR 请求
let request = VNRecognizeTextRequest { request, error in
    if let error = error {
        print("Error: \(error.localizedDescription)", to: .standardError)
        exit(1)
    }
    
    guard let observations = request.results as? [VNRecognizedTextObservation] else {
        print("Error: No text observations found", to: .standardError)
        exit(1)
    }
    
    var allText: [String] = []
    for observation in observations {
        if let topCandidate = observation.topCandidates(1).first {
            allText.append(topCandidate.string)
        }
    }
    
    print(allText.joined(separator: "\n"))
    exit(0)
}

// 配置 OCR
request.recognitionLevel = .accurate
request.recognitionLanguages = ["zh-Hans", "zh-Hant", "en-US"]

// 创建处理程序
let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])

// 执行 OCR
do {
    try handler.perform([request])
} catch {
    print("Error performing OCR: \(error.localizedDescription)", to: .standardError)
    exit(1)
}

// 保持运行直到回调完成
RunLoop.main.run()
