---
name: macos-ocr
slug: macos-ocr
description: 使用 macOS 内置 Vision OCR 框架从图片中提取文字。当用户需要在 macOS 上识别图片、截图、照片或扫描文档中的文字时使用。支持简体中文、繁体中文和英文识别。仅适用于支持 Swift 的 macOS 系统。
version: 1.0.0
author: QClaw
license: MIT
keywords: [ocr, 文字识别, 图片转文字, vision, macos, 截图识别, 中文, 英文]
---

# macOS OCR

使用 macOS 原生 Vision 框架从图片中提取文字。

## 适用场景

- 从图片、截图或照片中提取文字
- 对扫描文档或收据进行 OCR 识别
- 识别 macOS 上任意图片文件中的文字

## 系统要求

- 支持 Vision 框架的 macOS 系统（macOS 10.15+）
- 已安装 Swift 编译器（`swift` 命令可用）

## 使用方法

### 从图片中提取文字

```bash
swift scripts/ocr.swift <图片路径>
```

示例：
```bash
swift scripts/ocr.swift "/Users/username/Desktop/screenshot.png"
```

### 支持的图片格式

- PNG
- JPEG/JPG
- TIFF
- BMP
- 大多数常见图片格式

### 支持的语言

- 简体中文（zh-Hans）
- 繁体中文（zh-Hant）
- 英文（en-US）

## 输出说明

脚本将识别到的文字输出到标准输出（stdout），每个文本块占一行。

## 错误处理

- 如果图片无法加载，错误信息将输出到标准错误（stderr）
- 如果未识别到文字，输出将为空
- 错误信息将输出到 stderr，并返回退出码 1
