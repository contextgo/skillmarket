#!/usr/bin/env python3
"""
fetch_index.py — 未来7天逐3小时天气指数获取脚本

用法：
  python3 fetch_index.py --city 101010100 --index airc
  python3 fetch_index.py --city 101010100 --index airc,beer,uv
  python3 fetch_index.py --city 101010100 --all
  python3 fetch_index.py --city 101010100 --index airc --day 0  # 只看第0天（今天）

输出：JSON 格式结构化数据
"""

import json
import sys
import ssl
import urllib.request
import urllib.error
import argparse
from datetime import datetime, timedelta

# 忽略 SSL 证书验证（COS 使用自签名证书）
_SSL_CTX = ssl.create_default_context()
_SSL_CTX.check_hostname = False
_SSL_CTX.verify_mode = ssl.CERT_NONE

# COS 基础地址
COS_BASE = "https://diga2026-1252033877.cos.ap-beijing.myqcloud.com/index3hour"

# 26种指数配置：key → (name, icon, score_field, level_field, advice_field)
INDEX_CONFIG = {
    "airc":     ("空调开启", "❄️",  "acui_value",        "acui_level",        "acui_desc"),
    "beer":     ("啤酒",     "🍺",  "beer_index",        "index_level",       "index_detail"),
    "boat":     ("划船",     "🚣",  "bwi_value",         "bwi_level",         "bwi_description"),
    "chenlian": ("晨练",     "🏃",  "exercise_index",    "suggestion",         "suggestion"),
    "cold":     ("感冒",     "🤧",  "cold_index_score",   "cold_index_level",  "cold_index_advice"),
    "confort":  ("舒适度",   "😌",  "wci_value",         "wci_level",         "wci_desc"),
    "dating":   ("约会",     "💑",  "dating_index",       "index_level",       "index_description"),
    "dressing": ("穿衣",     "👔",  "clo",               "dressing_level",    "dressing_desc"),
    "dry":      ("晾晒",     "👕",  "drying_index",      "drying_level",      "drying_advice"),
    "fhan":     ("风寒",     "🥶",  "wind_chill_index",   "wind_chill_level",  "wind_chill_desc"),
    "fish":     ("钓鱼",     "🎣",  "fishing_index",     "index_level",       "index_description"),
    "go":       ("出行",     "🚗",  "index_score",       "index_level",       "index_desc"),
    "hair":     ("美发",     "💇",  "hair_index",        "index_level",       "index_desc"),
    "heat":     ("中暑",     "🌡️",  "heat_index",        "heat_level",        "heat_description"),
    "kite":     ("风筝",     "🪁",  "kite_index",        "index_level",       "index_desc"),
    "makeup":   ("化妆",     "💄",  "makeup_index",      "index_level",       "index_suggestion"),
    "mood":     ("心情",     "😊",  "mood_index",        "mood_level",        "mood_description"),
    "motion":   ("运动",     "🏅",  "sports_index",      "level",              "suggestion"),
    "night":    ("夜生活",   "🌃",  "index_value",       "index_level",       "index_description"),
    "road":     ("路况",     "🛣️",  "rwi",               "rwi_level",          "rwi_desc"),
    "street":   ("逛街",     "🛍️",  "comfort_score",     "index_level",       "index_desc"),
    "sun":      ("防晒",     "🕶️",  "spf",               "level",              "advice"),
    "tour":     ("旅游",     "✈️",  "tourism_score",     "index_level",       "index_desc"),
    "traffic":  ("交通",     "🚦",  "tmi",               "tmi_level",          "tmi_desc"),
    "umbrella": ("雨伞",     "☂️",  "umbrella_index",    "suggestion",         "suggestion"),
    "uv":       ("紫外线",   "☀️",  "uvi_value",         "uvi_level",          "uvi_desc"),
}

ALL_KEYS = list(INDEX_CONFIG.keys())


def build_url(city_id: str, index_key: str) -> str:
    return f"{COS_BASE}/{city_id}{index_key}.json"


def fetch_json(url: str, timeout: int = 10) -> list | dict | None:
    """从 COS URL 获取 JSON 数据"""
    try:
        req = urllib.request.Request(url, headers={
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                          "AppleWebKit/537.36 (KHTML, like Gecko) "
                          "Chrome/120.0.0.0 Safari/537.36"
        })
        with urllib.request.urlopen(req, timeout=timeout, context=_SSL_CTX) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        print(f"⚠️  HTTP {e.code} — {url}", file=sys.stderr)
        return None
    except urllib.error.URLError as e:
        print(f"⚠️  网络错误 — {url}，原因: {e.reason}", file=sys.stderr)
        return None
    except Exception as e:
        print(f"⚠️  {type(e).__name__} — {url}，原因: {e}", file=sys.stderr)
        return None


def get_val(rec: dict, *fields) -> str | float | int | None:
    """依次尝试从多个字段取值，取第一个存在的非空值"""
    for f in fields:
        if f and f in rec and rec[f] is not None and str(rec[f]).strip():
            return rec[f]
    return None


def extract_records(raw: list, score_f: str, level_f: str, advice_f: str,
                   day_filter: int | None = None) -> list:
    """
    从 JSON list 中提取所需字段。

    原始数据结构（list）：
    [
      {"city":"101010100","date":"2026-04-17","hour":20,"acui_value":0.81,...},
      ...
    ]
    """
    if not isinstance(raw, list):
        return []

    results = []
    for rec in raw:
        date_str = rec.get("date", "")
        hour = rec.get("hour")

        # 跳过无效记录
        if hour is None:
            continue

        # 日期过滤
        if day_filter is not None:
            # day_filter=0 表示今天，1=明天...7=7天后
            try:
                rec_date = datetime.strptime(date_str, "%Y-%m-%d")
                base = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
                days_diff = (rec_date.date() - base.date()).days
                if days_diff != day_filter:
                    continue
            except (ValueError, TypeError):
                continue

        # 提取三核心字段
        score = get_val(rec, score_f)
        level = get_val(rec, level_f)
        advice = get_val(rec, advice_f)

        # 格式化 datetime
        try:
            dt = datetime.strptime(date_str, "%Y-%m-%d")
            dt_str = dt.strftime("%Y-%m-%d")
        except (ValueError, TypeError):
            dt_str = date_str

        hour_label = f"{hour:02d}:00"

        results.append({
            "date":      dt_str,
            "hour":      hour,
            "time":      f"{dt_str} {hour_label}",
            "score":    score,
            "level":     level if level else "",
            "advice":    advice if advice else "",
        })

    return results


def fetch_single(city_id: str, index_key: str,
                 day_filter: int | None = None) -> dict:
    """获取单个指数"""
    name, icon, score_f, level_f, advice_f = INDEX_CONFIG.get(
        index_key, (index_key, "📊", None, None, None)
    )
    url = build_url(city_id, index_key)

    result = {
        "city_id":    city_id,
        "index_key":  index_key,
        "index_name": name,
        "icon":       icon,
        "url":        url,
        "success":    False,
        "records":    [],
        "error":      None,
    }

    raw = fetch_json(url)
    if raw is None:
        result["error"] = "无法获取数据"
        return result

    result["success"] = True
    result["records"] = extract_records(raw, score_f, level_f, advice_f, day_filter)
    return result


def fetch_multiple(city_id: str, index_keys: list[str],
                  day_filter: int | None = None) -> dict:
    """批量获取多个指数"""
    return {k: fetch_single(city_id, k, day_filter) for k in index_keys}


# ─────────────────────────────────────────────
# 格式化输出
# ─────────────────────────────────────────────

_HOUR_LABELS = {0:"凌晨", 3:"凌晨", 6:"早晨", 9:"上午",
                12:"中午", 15:"下午", 18:"傍晚", 21:"夜晚"}

_HOUR_SHORT  = {0:"00时", 3:"03时", 6:"06时", 9:"09时",
                12:"12时", 15:"15时", 18:"18时", 21:"21时"}


def _level_emoji(level) -> str:
    """根据等级值返回 emoji"""
    s = str(level).strip()
    # 数字型等级
    try:
        v = int(float(s))
        if v >= 4: return "🟢 极适宜"
        if v == 3: return "🟡 适宜"
        if v == 2: return "🟠 一般"
        if v == 1: return "🔴 不适宜"
        if v == 0: return "⚫ 极不适宜"
    except (ValueError, TypeError):
        pass
    # 文字型等级
    for kw, emoji in [
        ("极适宜", "🟢"), ("适宜", "🟡"), ("较适宜", "🟡"),
        ("一般", "🟠"), ("不适宜", "🔴"), ("极不适宜", "⚫"),
        ("畅通", "🟢"), ("拥堵", "🔴"),
    ]:
        if kw in s:
            return f"{emoji} {s}"
    return s


def _fmt_val(val, maxv: float = 1.0) -> str:
    """将 0-1 型数值格式化为百分比或直接字符串"""
    if val is None:
        return "-"
    try:
        f = float(val)
        if 0 <= f <= 1:
            return f"{f*100:.0f}%"
        return str(f)
    except (ValueError, TypeError):
        return str(val)


def format_single(result: dict, compact: bool = False) -> str:
    """将单指数结果格式化为表格文本"""
    icon   = result["icon"]
    name   = result["index_name"]
    city   = result["city_id"]
    records = result["records"]

    lines = []
    header = f"{'─'*54}"
    lines.append(f"\n{header}")
    lines.append(f"  {icon} {name}指数  |  城市: {city}")
    lines.append(header)

    if not result["success"]:
        lines.append(f"  ❌ 获取失败: {result['error']}")
        lines.append(header)
        return "\n".join(lines)

    if not records:
        lines.append("  （暂无数据）")
        lines.append(header)
        return "\n".join(lines)

    # 分日期展示
    dates = {}
    for r in records:
        d = r["date"]
        dates.setdefault(d, []).append(r)

    for date_str, day_recs in sorted(dates.items()):
        # 尝试美化日期显示
        try:
            d = datetime.strptime(date_str, "%Y-%m-%d")
            today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
            diff = (d.date() - today.date()).days
            if diff == 0:
                date_label = "今天"
            elif diff == 1:
                date_label = "明天"
            elif diff == 2:
                date_label = "后天"
            else:
                date_label = d.strftime("%m/%d")
        except (ValueError, TypeError):
            date_label = date_str

        lines.append(f"  ┌─ {date_label} {date_str}")

        if compact:
            # 紧凑模式：一行一条
            for r in day_recs:
                level = _level_emoji(r.get("level", ""))
                score = _fmt_val(r.get("score"))
                advice = str(r.get("advice") or "")[:15]
                hour_lbl = _HOUR_SHORT.get(r["hour"], f"{r['hour']:02d}时")
                lines.append(f"  │  {hour_lbl}  {score:<5}  {level}  {advice}")
        else:
            # 标准模式：按时间段分组
            rows = []
            for r in day_recs:
                hour = r["hour"]
                period = _HOUR_LABELS.get(hour, f"{hour:02d}时")
                score = _fmt_val(r.get("score"))
                level = str(r.get("level") or "")
                advice = str(r.get("advice") or "")[:25]
                rows.append((hour, period, score, level, advice))

            for hour, period, score, level, advice in rows:
                lines.append(f"  │  {period}({hour:02d}时)  {score:<5}  {level:<8}  {advice}")

        lines.append(f"  └─")

    lines.append(header)
    return "\n".join(lines)


def format_multi(results: dict, city_id: str) -> str:
    """多指数汇总输出"""
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    sep = "#" * 54

    parts = [f"\n{sep}"]
    parts.append(f"  🌤️  城市 {city_id} — 未来7天逐3小时天气指数")
    parts.append(f"  查询时间: {now}")
    parts.append(f"  共 {len(results)} 种指数")
    parts.append(sep)

    for key, res in results.items():
        parts.append(format_single(res))

    return "\n".join(parts)


# ─────────────────────────────────────────────
# CLI 入口
# ─────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="获取未来7天逐3小时天气指数",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例：
  python3 fetch_index.py --city 101010100 --index airc
  python3 fetch_index.py --city 101010100 --index airc,beer,uv
  python3 fetch_index.py --city 101010100 --all
  python3 fetch_index.py --city 101010100 --all --day 0   # 只看今天
  python3 fetch_index.py --city 101010100 --index airc --compact
        """
    )
    parser.add_argument("--city", "-c", required=True, help="城市ID，如 101010100")
    parser.add_argument("--index", "-i", help="指数key，多个用逗号分隔，如 airc,beer")
    parser.add_argument("--all", "-a", action="store_true", help="获取全部26种指数")
    parser.add_argument("--day", "-d", type=int, help="只看第N天（0=今天，1=明天，以此类推）")
    parser.add_argument("--compact", action="store_true", help="紧凑模式输出")
    parser.add_argument("--json", "-j", action="store_true", help="输出纯JSON")

    args = parser.parse_args()

    # 确定指数
    if args.all:
        keys = ALL_KEYS
    elif args.index:
        keys = [k.strip() for k in args.index.split(",")]
        bad = [k for k in keys if k not in INDEX_CONFIG]
        if bad:
            print(f"⚠️  未知指数: {bad}\n有效值: {ALL_KEYS}", file=sys.stderr)
            sys.exit(1)
    else:
        print("⚠️  请指定 --index 或 --all", file=sys.stderr)
        parser.print_help()
        sys.exit(1)

    # 获取数据
    if len(keys) == 1:
        res = fetch_single(args.city, keys[0], args.day)
        if args.json:
            print(json.dumps(res, ensure_ascii=False, indent=2))
        else:
            print(format_single(res, compact=args.compact))
    else:
        res = fetch_multiple(args.city, keys, args.day)
        if args.json:
            print(json.dumps(res, ensure_ascii=False, indent=2))
        else:
            print(format_multi(res, args.city))


if __name__ == "__main__":
    main()
