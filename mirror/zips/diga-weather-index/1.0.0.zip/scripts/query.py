#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
天气指数查询脚本 - 未来7天逐3小时天气指数
支持26种生活指数，覆盖全国3343个区县级城市
自动适配不同指数的字段名格式
"""

import sys
import json
import re
import urllib.request
import urllib.error
import ssl
from datetime import datetime
from collections import defaultdict

# 导入内置城市映射表 (共3193个城市)
from cities import CITY_MAP

# 指数名称到URL后缀的映射
INDEX_MAP = {
    "空调": "airc",
    "啤酒": "beer",
    "划船": "boat",
    "晨练": "chenlian",
    "感冒": "cold",
    "舒适度": "confort",
    "约会": "dating",
    "穿衣": "dressing",
    "晾晒": "dry",
    "风寒": "fhan",
    "钓鱼": "fish",
    "出行": "go",
    "美发": "hair",
    "中暑": "heat",
    "风筝": "kite",
    "化妆": "makeup",
    "心情": "mood",
    "运动": "motion",
    "夜生活": "night",
    "路况": "road",
    "逛街": "street",
    "防晒": "sun",
    "旅游": "tour",
    "交通": "traffic",
    "雨伞": "umbrella",
    "紫外线": "uv",
}

# URL后缀到中文名称的反向映射
INDEX_REVERSE_MAP = {v: k for k, v in INDEX_MAP.items()}

# 字段名模式映射 - 按优先级排序
FIELD_PATTERNS = {
    "airc": [("acui_value", "acui_level", "acui_desc")],
    "beer": [("beer_index", "index_level", "index_detail")],
    "boat": [("bwi_value", "bwi_level", "bwi_description")],
    "chenlian": [("exercise_index", "suggestion", None)],
    "cold": [("cold_index_score", "cold_index_level", "cold_index_level_desc")],
    "confort": [("wci_score", "wci_level", "wci_desc")],
    "dating": [("dating_index", "index_level", "index_description")],
    "dressing": [("clo", "dressing_level", "dressing_desc")],
    "dry": [("drying_index", "drying_level", "drying_advice")],
    "fhan": [("wind_chill_index", "wind_chill_level", "wind_chill_desc")],
    "fish": [("fishing_index", "index_level", "index_description")],
    "go": [("index_score", "index_level", "index_desc")],
    "hair": [("hair_index", "index_level", "index_desc")],
    "heat": [("heat_index", "heat_level", "heat_description")],
    "kite": [("kite_index", "index_level", "index_desc")],
    "makeup": [("makeup_index", "index_level", "index_description")],
    "mood": [("mood_index", "mood_level", "mood_description")],
    "motion": [("sports_index", "level", "suggestion")],
    "night": [("index_value", "index_level", "index_description")],
    "road": [("rwi", "rwi_level", "rwi_desc")],
    "street": [("comfort_score", "index_level", "index_desc")],
    "sun": [("uv_index", "level", "level_desc")],
    "tour": [("tourism_score", "index_level", "index_desc")],
    "traffic": [("tmi", "tmi_level", "tmi_desc")],
    "umbrella": [("umbrella_index", None, "suggestion")],
    "uv": [("uvi_value", "uvi_level", "uvi_desc")],
}

# 等级中文映射
LEVEL_MAPS = {
    "airc": {0: "无需开启", 1: "制热", 2: "制冷", 3: "部分人群需制冷"},
    "umbrella": {0: "不需要", 1: "建议带伞", 2: "最好带伞", 3: "必须带伞"},
    "cold": {0: "少发", 1: "低风险", 2: "中风险", 3: "高风险", 4: "极易发"},
    "heat": {0: "不易中暑", 1: "不易中暑", 2: "容易中暑", 3: "极易中暑"},
}

# 腾讯云COS基础URL
COS_BASE_URL = "https://diga2026-1252033877.cos.ap-beijing.myqcloud.com/index3hour/"

# 创建SSL上下文
SSL_CONTEXT = ssl.create_default_context()
SSL_CONTEXT.check_hostname = False
SSL_CONTEXT.verify_mode = ssl.CERT_NONE


def fuzzy_match_city(city_name, city_map):
    """模糊匹配城市名"""
    if not city_name:
        return None, None
    if city_name in city_map:
        return city_map[city_name], city_name
    matches = [(name, cid) for name, cid in city_map.items() if city_name in name]
    if matches:
        return matches[0][1], matches[0][0]
    matches = [(name, cid) for name, cid in city_map.items() if name.startswith(city_name)]
    if matches:
        return matches[0][1], matches[0][0]
    return None, None


def fetch_index_data(city_id, index_suffix):
    """从腾讯云COS获取指数数据"""
    url = f"{COS_BASE_URL}{city_id}{index_suffix}.json"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=10, context=SSL_CONTEXT) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError:
        return None
    except Exception as e:
        raise Exception(f"获取数据失败: {str(e)}")


def get_field_value(item, *fields):
    """尝试从多个可能的字段名中获取值"""
    for field in fields:
        if field and field in item:
            return item[field]
    return None


def format_level(level, index_suffix):
    """格式化等级显示"""
    if level is None:
        return ""
    if isinstance(level, str) and re.search(r'[\u4e00-\u9fff]', level):
        return level
    level_map = LEVEL_MAPS.get(index_suffix, {})
    if isinstance(level, (int, float)) and level in level_map:
        return level_map[level]
    return str(level)


def format_value(value):
    """格式化指数值"""
    if value is None:
        return "-"
    if isinstance(value, float):
        return f"{value:.2f}"
    return str(value)


def find_nearest_hour(all_hours, target_hour):
    """找到最接近目标小时的小时值"""
    if not all_hours:
        return None
    return min(all_hours, key=lambda x: abs(x - target_hour))


def group_by_date(data):
    """按日期分组数据"""
    grouped = defaultdict(list)
    for item in data:
        grouped[item.get("date", "unknown")].append(item)
    return dict(sorted(grouped.items()))


def extract_display_data(item, index_suffix):
    """从原始数据中提取显示所需的关键字段"""
    patterns = FIELD_PATTERNS.get(index_suffix, [(None, None, None)])[0]
    value_field, level_field, desc_field = patterns
    value = get_field_value(item, value_field)
    level = get_field_value(item, level_field)
    desc = get_field_value(item, desc_field)
    return {
        "hour": item.get("hour", "?"),
        "value": format_value(value),
        "level": format_level(level, index_suffix),
        "desc": desc if desc else ""
    }


def query_index(city_name, index_name, date_str=None, hour=None):
    """查询天气指数"""
    index_suffix = INDEX_MAP.get(index_name)
    if not index_suffix:
        available = ", ".join(sorted(INDEX_MAP.keys()))
        raise ValueError(f"未知指数: {index_name}\n可选指数: {available}")

    city_id, matched_name = fuzzy_match_city(city_name, CITY_MAP)
    if not city_id:
        raise ValueError(f"未找到城市: {city_name}")

    data = fetch_index_data(city_id, index_suffix)
    if data is None:
        raise Exception(f"城市 {matched_name}({city_id}) 的{index_name}指数数据不存在")

    if date_str:
        filtered = [item for item in data if item.get("date") == date_str]
        if filtered:
            data = filtered

    if hour is not None:
        all_hours = sorted(set(item.get("hour") for item in data if "hour" in item))
        if all_hours:
            nearest = find_nearest_hour(all_hours, hour)
            data = [item for item in data if item.get("hour") == nearest]

    grouped = group_by_date(data)

    return {
        "code": 0,
        "message": "success",
        "data": {
            "city_id": city_id,
            "city_name": matched_name,
            "index_name": INDEX_REVERSE_MAP.get(index_suffix, index_name),
            "index_suffix": index_suffix,
            "total_records": len(data),
            "grouped_data": grouped,
        }
    }


def print_result(result):
    """打印格式化结果"""
    if result.get("code") != 0:
        print(f"错误: {result.get('message', '未知错误')}")
        return

    data = result["data"]
    grouped = data.get("grouped_data", {})
    index_suffix = data.get("index_suffix", "")

    print(f"\n{'='*60}")
    print(f"📍 城市: {data['city_name']} (ID: {data['city_id']})")
    print(f"📊 指数: {data['index_name']}")
    print(f"📈 总记录: {data['total_records']}条")
    print(f"{'='*60}")

    for date, items in grouped.items():
        print(f"\n📅 {date}")
        print("-" * 40)
        for item in items:
            display = extract_display_data(item, index_suffix)
            print(f"  ⏰ {display['hour']:02d}:00")
            if display['value'] != "-":
                print(f"     指数值: {display['value']}")
            if display['level']:
                print(f"     等级: {display['level']}")
            if display['desc']:
                print(f"     建议: {display['desc']}")
            print()


def main():
    """主函数"""
    if len(sys.argv) < 3:
        print("用法: python3 query.py <城市名> <指数名> [日期 YYYY-MM-DD] [小时 0-23]")
        print("\n示例:")
        print("  python3 query.py 北京 空调")
        print("  python3 query.py 广州 雨伞 2026-04-20 14")
        print("  python3 query.py 上海 紫外线")
        print(f"\n支持的指数 (26种)，共覆盖 {len(CITY_MAP)} 个城市:")
        for name in sorted(INDEX_MAP.keys()):
            print(f"  - {name}")
        sys.exit(1)

    city_name = sys.argv[1]
    index_name = sys.argv[2]
    date_str = sys.argv[3] if len(sys.argv) > 3 else None
    hour = int(sys.argv[4]) if len(sys.argv) > 4 else None

    try:
        result = query_index(city_name, index_name, date_str, hour)
        print_result(result)
    except Exception as e:
        print(f"查询失败: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
