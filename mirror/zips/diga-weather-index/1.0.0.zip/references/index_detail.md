# 26种天气指数详细说明

## 1. airc — 空调开启指数 ❄️
**含义：** 体感温度与空调开启需求的匹配程度。
**典型字段：** `acui_value`（评分）、`acui_desc`（描述）
**等级参考：**
- 0-20：寒冷，需制热
- 21-40：较凉，少量制热
- 41-60：舒适，不需空调
- 61-80：较热，少量制冷
- 81-100：炎热，需制冷

## 2. beer — 啤酒指数 🍺
**含义：** 饮用啤酒的适宜程度，综合气温、体感温度。
**典型字段：** `beer_index`（评分）、`index_short`（等级）、`index_detail`（建议）

## 3. boat — 划船指数 🚣
**含义：** 水上划船活动的适宜程度，考虑风速、水温、天气状况。
**典型字段：** `bwi_value`（评分）、`bwi_level`（等级）、`bwi_description`（描述）

## 4. chenlian — 晨练指数 🏃
**含义：** 早晨户外锻炼的适宜程度，考虑气温、空气质量、能见度。
**典型字段：** `exercise_index`（评分）、`suggestion`（建议）

## 5. cold — 感冒指数 🤧
**含义：** 感冒发生风险，综合气温变化、湿度、风速。
**典型字段：** `cold_index_score`（风险评分）、`cold_index_level_desc`（等级描述）、`cold_index_advice`（建议）
**等级：** 极易感冒 / 易感冒 / 较易感冒 / 较不易感冒 / 不易感冒

## 6. confort — 舒适度指数 😌
**含义：** 人体感受的舒适程度，基于温湿度组合。
**典型字段：** `wci_level`（评分/等级）、`wci_desc`（描述）

## 7. dating — 约会指数 💑
**含义：** 户外约会的天气适宜程度。
**典型字段：** `dating_index`（评分）、`index_level`（等级）、`index_description`（描述）

## 8. dressing — 穿衣指数 👔
**含义：** 建议的穿衣厚度和类型。
**典型字段：** `clo`（服装热阻值）、`dressing_level`（穿衣等级）、`dressing_desc`（描述）

## 9. dry — 晾晒指数 👕
**含义：** 衣物晾晒的适宜程度，考虑降水、湿度、风速。
**典型字段：** `drying_index`（评分）、`drying_level`（等级）、`drying_advice`（建议）

## 10. fhan — 风寒指数 🥶
**含义：** 低温环境下风速对人体的冷却效应（体感更冷）。
**典型字段：** `wind_chill_index`（评分）、`wind_chill_level`（等级）、`wind_chill_desc`（描述）

## 11. fish — 钓鱼指数 🎣
**含义：** 钓鱼活动的适宜程度，考虑水温、气温、气压、风力。
**典型字段：** `fishing_index`（评分）、`index_level`（等级）、`index_description`（描述）

## 12. go — 出行指数 🚗
**含义：** 出行/旅游/交通的整体适宜程度。
**典型字段：** `index_score`（评分）、`index_level`（等级）、`index_desc`（描述）

## 13. hair — 美发指数 💇
**含义：** 美发造型保持效果，受湿度、风力、降水影响。
**典型字段：** `hair_index`（评分）、`index_level`（等级）、`index_desc`（描述）

## 14. heat — 中暑指数 🌡️
**含义：** 高温条件下中暑风险。
**典型字段：** `heat_index`（评分）、`heat_level`（等级）、`heat_description`（描述）

## 15. kite — 风筝指数 🪁
**含义：** 放风筝的适宜程度，主要考虑风力。
**典型字段：** `kite_index`（评分）、`index_level`（等级）、`index_desc`（描述）

## 16. makeup — 化妆指数 💄
**含义：** 妆容持久度和妆效，受湿度、气温、降水影响。
**典型字段：** `makeup_index`（评分）、`index_level`（等级）、`index_suggestion`（建议）

## 17. mood — 心情指数 😊
**含义：** 气象条件对情绪/心情的影响，综合气温、湿度、天气状况。
**典型字段：** `mood_index`（评分）、`mood_level`（等级）、`mood_description`（描述）

## 18. motion — 运动指数 🏅
**含义：** 户外运动的适宜程度，考虑气温、空气质量、降水。
**典型字段：** `sports_index`（评分）、`level`（等级）、`suggestion`（建议）

## 19. night — 夜生活指数 🌃
**含义：** 夜间户外活动或室内休闲娱乐的适宜程度。
**典型字段：** `index_value`（评分）、`index_level`（等级）、`index_description`（描述）

## 20. road — 路况指数 🛣️
**含义：** 道路行驶条件，考虑能见度、降水、路面状态。
**典型字段：** `rwi`（评分）、`rwi_level`（等级）、`rwi_desc`（描述）

## 21. street — 逛街指数 🛍️
**含义：** 逛街购物的适宜程度，考虑气温、降水、空气质量。
**典型字段：** `comfort_score`（舒适评分）、`index_level`（等级）、`index_desc`（描述）

## 22. sun — 防晒指数 🕶️
**含义：** 户外活动时需要防晒的程度，基于紫外线强度。
**典型字段：** `spf`（SPF防晒建议值）、`level_desc`（等级描述）、`advice`（建议）

## 23. tour — 旅游指数 ✈️
**含义：** 旅游出行的整体适宜程度，综合多种气象条件。
**典型字段：** `tourism_score`（评分）、`index_level`（等级）、`index_desc`（描述）

## 24. traffic — 交通指数 🚦
**含义：** 交通出行条件，考虑能见度、降水、路面摩擦力。
**典型字段：** `tmi`（交通指数值）、`tmi_level`（等级）、`tmi_desc`（描述）

## 25. umbrella — 雨伞指数 ☂️
**含义：** 携带雨伞的必要性，基于降水概率和强度。
**典型字段：** `umbrella_index`（评分）、`suggestion`（建议）

## 26. uv — 紫外线指数 ☀️
**含义：** 紫外线辐射强度，对皮肤伤害风险。
**典型字段：** `uvi_value`（UVI数值）、`uvi_level`（等级描述）、`uvi_desc`（建议）
**等级参考（WHO标准）：**
- 0-2：弱，无需防护
- 3-5：中等，涂SPF15+防晒霜
- 6-7：高，SPF30+，减少日晒
- 8-10：很高，SPF50+，避免日晒
- 11+：极强，避免户外活动
