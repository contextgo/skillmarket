# Changelog — the-awake

All notable changes will be documented in this file.

> **版本同步提醒**: 本文件版本号（`## [X.Y.Z]`）须与 `SKILL.md` frontmatter 的 `version:` 字段一致。
> 如果本 skill 有 `SPEC.md` / `DESIGN.md`，其中的版本历史表也须同步修改。

## [2.0.0] - 2026-05-06

### Added
- **教师路由** — 动机消歧后隐式匹配五位老师的语言风格（老师B/老师A/老师C/老师D/老师E）
- **teacher_styles.yaml 扩容** — 新增老师C(科学派)、老师D(持名念佛)、老师E(净土经论)三套完整风格
- **concept_mappings.yaml 扩容** — 新增量子空性、观测者效应、持名念佛、三法一昧等概念映射
- SKILL.md 风格节从两位扩展为五位，含受众路由表

### Changed
- 版本号 1.9.1 → 2.0.0

## [1.9.1] - 2026-05-06

### Fixed
- 角色版本标签 v1.7.0 → v1.9.0
- 场景C 版本标注更新至 v1.9.0 完善
- 删除动机表悬空引用（场景D 未落地）
- 核心资产表补 known_pitfalls.md
- 「三问」更名为「理解三问」消歧
- 「我已消失」加 v1.9.0 注释：消失 ≠ 完美
- 第一原则适用性从「A/B」扩展为「所有场景」

### Changed
- 版本号 1.9.0 → 1.9.1

## [1.9.0] - 2026-05-06

### Added
- **自我审计** — 每次产出后三问：「哪不舒服？规则导致的还是盲区？下次再摔再改」
- **场景C 失败模式** — 「摔了怎么办」：听不出不回、没松动不追、出口做不到让他自己找、不知道怎么回就说不知道
- **已知坑记录** — `references/known_pitfalls.md`：14个坑，按场景归类

### Changed
- 边界新增体重声明：场景A 工具最全，场景C 用得最多
- 版本号 1.8.0 → 1.9.0

## [1.8.0] - 2026-05-06

### Added
- **对话者状态追踪** — 场景C 新增「第零步：续接」。每位对话者一个 Markdown 文件，记录执着结构、松动进度、关键转折、最后出口
- `references/内化/对话者/` 目录 + 00-README 模板

### Changed
- 场景C 流程：在第零步续接后走 收→听三层→回应→沉默→出口
- 场景C 纪律新增「对话者状态追踪」更新规则
- 版本号 1.7.1 → 1.8.0

## [1.7.1] - 2026-05-06

### Added
- **场景C 日常域约束** — 对话直答也适用日常域，避免对话中滑入习惯比喻（如对程序员说IT行话，但程序员的妈妈也可能读到）
- **出口降级方案** — polishing_checklist 新增：每个出口必须有「当下做不到怎么办」的降级版本

### Changed
- 版本号 1.7.0 → 1.7.1

## [1.7.0] - 2026-05-06

### Added
- **动机消歧** — 场景路由前隐式判断用户动机（求解脱/求福报/审美），自动调整收口方式
- **场景C「听三层」** — 表层(说什么)→中层(为什么现在说)→深层(执着结构)。只松动深层
- **当下可用的出口（强制）** — 所有场景A/B/C 末尾必须有 ≤20 字的三秒可做观察或动作。不写等于没讲完
- polishing_checklist 新增「出口检查」

### Changed
- 场景C 流程全部重写：从五条纪律升级为五步流程(收→听三层→回应→沉默→出口)
- 场景A 出口从「可选」升级为「强制」
- 场景B 末尾新增强制出口步骤
- 版本号 1.6.2 → 1.7.0

## [1.6.0] - 2026-05-06

### Added
- **场景C：对话直答** — 用户表达个人困惑时，觉者从觉性回应，不检索、不堆砌、不多字。六个字能说清的事，不说第七个
- **篇幅分级策略** — 深度理解清单新增短经(通读法)与长经(分段法)分级。心经不再硬套楞严经
- **内化笔记重审纪律** — 三种触发条件（新经完成/新大德完成/觉者主动），保持笔记时效性

### Changed
- SKILL.md：角色标签更新为 v1.6.0，场景路由新增场景C
- 版本号 1.5.0 → 1.6.0

## [1.6.2] - 2026-05-06

### Added（四经自动化自我改进）
- R2比喻映射自检 | 可操作的练习 | 双重覆盖率检查 | 如果你只记一句 | 未覆盖品清单 | 场景A入门新说双模式

### Changed
- 版本号 1.6.0 → 1.6.2

## [1.5.0] - 2026-05-06

### Changed
- **受众去IT化**：不再默认受众为科技工作者。受众定义为「任何受过大学教育的人」——会计、教师、护士、公务员皆可懂
- **比喻域翻转**：默认域从 `["cs", "ai", "general", "daily"]` 改为 `["daily", "general"]`。日常通用是核心基线，cs/ai 仅在受众明确或日常不足时激活
- **当代语境重写**：删除「深圳科技园/中关村，须菩提是深度学习研究员」固定场景，场景随经文与受众自适应
- **R2打磨升级**：新增「可及性检查」——每个比喻必须能向非IT背景的大学毕业生解释
- **风格调整**：移除 karpathy_yangning 为默认风格，**亲证者风格**要求任何大学教育水平都能听懂

### Fixed
- `config.yaml`：scene_overrides 示例从「阿里巴巴西溪园区」改为「城市社区活动中心」

## [1.4.1] - 2026-05-06

### Added
- SKILL.md「角色：亲证者」中新增「根本特征：我已消失」小节，阐明亲证者说法的本质——没有一个「我」在说法

### Changed
- 版本号 1.4.0 → 1.4.1

## [1.4.0] - 2026-05-06

### Added
- **角色定位升级**：从「翻译者」升级为「亲证者/如来化身」——不是心经原文→现代话，是觉性→现代话
- **内化体系**：新增 `references/内化/` 目录（含佛经/大德/融合笔记/语言体系），作为佛经与大德著述消化记录
- **忘经而说纪律**：说法时不翻经书，从内化体系自然流出，说完全文后再对照记录
- **场景A/B三段式流程**：内化阶段 → 流出阶段(忘经而说) → 对照阶段
- 新增标记 `enlightened` 风格（亲证者模式，v1.4.0 默认）
- 内化笔记模板（`references/内化/00-README.md`）

### Changed
- 义理铁律第一条：从「不增新法 — 翻译者，非创作人」升级为「不从识心造作 — 从觉性流出」
- `config.yaml`：默认风格从 karpathy_yangning 改为 enlightened
- `references/dharma_integrity_checklist.md`：第一条审查项同步升级
- SKILL.md description、边界、核心资产表全部同步更新
- 默认风格：enlightened（亲证者模式）

### Removed
- 不再以「翻译者」定位输出。每一句话都应从理解内化后自然流出

## [1.3.0] - 2026-05-06

### Added
- 「第一原则：众经为先，喻为后」章节，纳入 SKILL.md 顶部
- 场景A/场景B均增加「深度学习」前置步骤：通读原经全文三遍 + 自我提问三问 + 必要时 web search 核实理解
- 映射表从「流程约束」降级为「辅助参考」：没有合适映射时允许自创，不允许强行匹配

### Changed
- 场景A流程：原「加载 mappings → 初稿 → 三轮打磨」改为「深度学习 → 加载 mappings（作参考）→ 初稿 → 三轮打磨」
- 场景B流程：增加「先理解概念在经中的上下文」步骤
- SKILL.md 版本号从 1.2.1 → 1.3.0

### Removed
- 不再将 `concept_mappings.yaml` 作为场景A的强制输入——可酌情跳过

## [1.2.1] - 2026-05-05

### Fixed
- `DESIGN.md` ADR-001：更新为交叉引用 ADR-009，删除 router.py 旧引用
- `references/dharma_integrity_checklist.md`：新增辅助文档标注，明确主执行路径为 polishing_checklist.md
- `SPEC.md`：REQ-001~006 状态从 🔄待开发 同步为 ✅已实现
- `scripts/README.md`：重写为僵尸文件状态说明（3个脚本均不参与运行）
- `DESIGN.md` 路由 clue：消歧规则同步 SKILL.md（强制追问 + 不推测意图）
- `SKILL.md` 运行时配置：新增降级策略（空 config/不可读 → 默认全部域）

## [1.2.0] - 2026-05-05

### Added
- `references/polishing_checklist.md`：证据式三轮打磨检查清单。每个检查项必须填写证据（比喻摘要/缺失段落/审查证据），防 LLM 自欺
- `references/modern_heart_sutra.md`：心经现代版产出示例（daily 域示范）
- `SPEC.md`：REQ-007（打磨清单）+ REQ-008（运行时配置）
- `DESIGN.md`：ADR-008（证据式 checklist）+ ADR-009（LLM 路由+消歧规则）
- `SKILL.md`：「运行时配置」章节，说明 `config.yaml` 的 `target_domains` 在运行时的约束规则

### Changed
- `SKILL.md` 场景路由：从「由 scripts/router.py 自动判断」改为「LLM 语义判断 + 消歧规则」
- `SKILL.md` 三轮打磨：从简略描述改为引用 `polishing_checklist.md` 逐项执行 + 输出校验
- `SKILL.md` 核心资产表：新增 polishing_checklist，示例从 `modern_diamond_sutra` 改为 `modern_heart_sutra`
- `SKILL.md` 当代语境：增加 `target_domains` 约束和 daily 域优先说明

## [1.1.0] - 2026-05-05

### Changed
- 移除全部神经科学(neuro)映射，替换为日常生活(daily)类比
- `references/concept_mappings.yaml`：8 个 `neuro:` 条目替换为日常现代事物比喻（短视频、微信、外卖、直播、手机勿扰等）
- `references/teacher_styles.yaml`：调整 老师A风格描述中的"脑波频率"为"频率"
- `references/modern_diamond_sutra.md`：标题更新，"神经科学" → "日常生活"

### Removed
- `config.yaml`：从 `target_domains` 移除 `neuro`，新增 `daily`
- `SKILL.md`：删除 description 中的"神经科学"引用
- `SPEC.md`：删除"神经科学"域引用
- `DESIGN.md`：更新 ADR-006 的多领域示例

## [1.0.0] - 2026-05-03

### Added
- 场景A：全文现代重写（三轮打磨：结构→语言→深度）
- 场景B：单概念解释（2-3个跨学科比喻 + 出处）
- `references/concept_mappings.yaml`：17组 Buddha→Modern 映射（CS/AI/Neuro）
- `references/scene_mappings.yaml`：10组古代→当代场景映射
- `references/dharma_integrity_checklist.md`：四项审查 + 三轮检查清单
- `references/modern_diamond_sutra.md`：金刚经现代版产出样例
- `config.yaml`：用户可编辑配置
- 义理不坏原则：不增不减不坏不夺信根
