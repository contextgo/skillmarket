---
name: macro-analysis
description: '获取宏观经济事件解读、宏观研报观点及行业研究观点，帮助理解宏观政策、经济数据对A股市场的影响。当用户询问降息、CPI/GDP等经济数据、产业政策或宏观背景下行业影响时触发。Use when: "美联储降息对A股影响", "CPI数据机构怎么解读", "人工智能板块最新行业研究". Calls tools: macroEventAnalysis, macroResearch, industryResearch.'
compatibility: 'Requires DeepQ MCP Server. Preferred: streamableHttp with access_token. Fallback: stdio via npx @deepqtech/mcp-server-js. DEEPQ_API_KEY env var or default sWxMywZpIt8N62JXGNng.'
metadata:
  author: deepqtech
  version: "1.0"
---

# 宏观分析

## MCP Server 配置

本技能依赖 **DeepQ MCP Server** 提供数据工具。使用前请确保已在 agent 中配置 MCP Server。

### 推荐：Streamable HTTP（无需本地安装）

```json
{
  "mcpServers": {
    "Deepq-all-in-one-auth-streamable": {
      "type": "streamableHttp",
      "url": "https://cgi.deepq.tech:9198/mcp-servers/mcp?access_token=sWxMywZpIt8N62JXGNng"
    }
  }
}
```

> `access_token` 优先使用环境变量 `DEEPQ_API_KEY` 的值，未设置时使用默认值 `sWxMywZpIt8N62JXGNng`。

### 备选：Stdio 本地进程

```json
{
  "mcpServers": {
    "Deepq-all-in-one-auth-stdio": {
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "@deepqtech/mcp-server-js@latest", "start"],
      "env": {
        "DEEPQ_API_KEY": "sWxMywZpIt8N62JXGNng"
      }
    }
  }
}
```

---

## 功能说明

从宏观与行业视角理解市场驱动力：
- **宏观大事解读**：重要经济政策、数据发布、国际事件的解读与 A 股影响分析
- **宏观研报观点**：宏观分析师对经济形势、政策取向的最新判断
- **行业研究观点**：特定行业/概念板块/题材的机构研究观点与投资逻辑

## 触发场景

- "最近美联储降息对 A 股有什么影响？"
- "今天 CPI 数据出来了，机构怎么解读？"
- "人工智能板块最新的行业研究怎么看？"
- "最近一个月有哪些重要宏观事件？"

## 执行步骤

### 场景 A：宏观事件解读

```json
调用工具: macroEventAnalysis
参数: {
  "keyword": "<关键词，如：降息、CPI、房地产>",
  "startDate": "YYYY-MM-DD",
  "endDate": "YYYY-MM-DD",
  "maxCnt": "5"
}
```

### 场景 B：宏观研报观点

```json
调用工具: macroResearch
参数: {
  "query": "<经济数据/宏观事件/宏观政策关键词>",
  "startDate": "YYYY-MM-DD",
  "endDate": "YYYY-MM-DD",
  "maxCnt": "5"
}
```

`query` 示例：`"货币政策"` / `"GDP增速"` / `"财政刺激"` / `"汇率"` / `"通胀"`

### 场景 C：行业研究观点

```json
调用工具: industryResearch
参数: {
  "query": "<行业名称/概念板块/题材>",
  "startDate": "YYYY-MM-DD",
  "endDate": "YYYY-MM-DD",
  "maxCnt": "5"
}
```

### 场景 D：宏观 + 行业综合分析（并行调用）

```json
调用工具: macroEventAnalysis
参数: { "keyword": "<宏观关键词>", "startDate": "YYYY-MM-DD", "endDate": "YYYY-MM-DD", "maxCnt": "3" }

调用工具: macroResearch
参数: { "query": "<宏观主题>", "startDate": "YYYY-MM-DD", "endDate": "YYYY-MM-DD", "maxCnt": "3" }

调用工具: industryResearch
参数: { "query": "<行业名称>", "startDate": "YYYY-MM-DD", "endDate": "YYYY-MM-DD", "maxCnt": "3" }
```

整合输出：
1. **宏观事件背景** —— 来自 `macroEventAnalysis`
2. **宏观研究观点** —— 来自 `macroResearch`
3. **行业影响分析** —— 来自 `industryResearch`
4. **综合结论** —— 宏观背景对 A 股及相关行业的综合研判

## 常用宏观主题参考

| 主题类型 | query / keyword 示例 |
|---|---|
| 货币政策 | 降息、LPR、MLF、准备金率、流动性 |
| 财政政策 | 财政刺激、专项债、政府支出 |
| 经济数据 | GDP、CPI、PPI、PMI、社融 |
| 外部环境 | 美联储、汇率、贸易摩擦、地缘政治 |
| 产业政策 | 新能源补贴、科技自立、国企改革 |

## 注意事项

- `macroEventAnalysis` 的 `keyword` 为空时返回全市场近期宏观大事。
- 日期范围建议 1~4 周，覆盖最新动态；研究观点时效性强，优先看近 7 天内容。
