# Exception Style

Use this file when deciding how to represent failures in controllers, services, and integration code.

## Core Rule

- Treat expected business failures as business exceptions, not generic runtime failures.
- In this repository, the default business exception is `ServiceException`.
- Let the global exception handlers shape the final `Result.fail(...)` response for most failures.

Relevant existing code:

- `com.miaohong.ai.common.core.exception.ServiceException`
- `com.miaohong.ai.common.security.handler.GlobalExceptionHandler`
- `com.miaohong.ai.gateway.handler.GatewayExceptionHandler`

## Controller Rule

- Keep controllers on the success path whenever possible.
- Prefer `Result.success(...)` for normal returns.
- Do not wrap controller methods in large `try/catch` blocks for business validation.
- Avoid scattering `Result.fail(...)` everywhere in controllers.
- Only allow controller-level `Result.fail(...)` for small, obvious, request-adaptation checks when that already matches nearby code and refactoring it downward would add noise.
- For new code written by Codex, prefer pushing failure checks into the service layer and throwing `ServiceException` there.

Preferred direction:

- controller: adapt request and return `Result.success(...)`
- service: validate business rules and throw `ServiceException` on failure

## Service Rule

- Use `ServiceException` for expected business errors such as:
  - data not found in a business sense
  - duplicate name/key conflicts
  - invalid state transitions
  - password or old-value verification failures
  - access or scope checks that fail after business resolution
  - integration responses that clearly represent business failure
- Use `new ServiceException("...")` by default.
- Use `new ServiceException("...", code)` only when a specific business code is truly needed.
- Do not casually use `RuntimeException` for business failures.

Preferred pattern:

```java
if (!BCrypt.checkpw(dto.getOldPassword(), password)) {
    throw new ServiceException("修改密码失败，旧密码错误");
}
```

## RuntimeException Rule

- Do not introduce `throw new RuntimeException("...")` for normal business flow.
- If a catch block is needed around third-party, IO, HTTP, or parsing logic:
  - log the technical exception with enough context
  - throw a `ServiceException` with a user-facing business message
- Let unexpected technical exceptions fall through only when there is no better local recovery or message.

Preferred pattern:

```java
try {
    httpClientResult = HttpClientUtils.doPostJson(url, headerMap, param, null, null);
} catch (Exception e) {
    log.error("SC登录失败, role={}", dto.getRole(), e);
    throw new ServiceException("SC登录失败");
}
```

## Existing Specialized Exceptions

- Keep existing specialized exceptions where they already model a specific failure type, for example:
  - `CaptchaException`
  - `CaptchaExpireException`
  - Sa-Token exceptions such as `NotLoginException`, `NotPermissionException`, and `NotRoleException`
- Do not collapse these specialized framework or auth exceptions into generic `ServiceException` unless the user asks for that refactor.

## Mapper Rule

- Mappers and mapper XML do not throw business exceptions.
- Mapper code only performs data access.
- Null handling, duplicate checks, permission interpretation, and user-facing failure messages belong in the service layer.

## Validation Rule

- Prefer DTO validation annotations plus `@Validated` for structural request validation.
- Use `ServiceException` for business validation that depends on database state, cross-field rules, permissions, or workflow rules.
- Existing helper assertions such as `AbstractFieldAssert` may continue to throw `ServiceException`.

## Logging Rule

- When throwing `ServiceException` for a simple business rule, you usually do not need an extra error log at the throw site unless the context would otherwise be lost.
- When catching lower-level technical exceptions and converting them to `ServiceException`, log the original exception with enough identifiers to diagnose the failure.
- Avoid duplicate logs for the same business failure at multiple layers.

## What To Prefer In New Code

- Prefer this:

```java
if (!roleService.checkRoleNameUnique(sysRole)) {
    throw new ServiceException("修改角色'" + role.getRoleName() + "'失败，角色名称已存在");
}
```

- Over this:

```java
if (!roleService.checkRoleNameUnique(sysRole)) {
    return Result.fail("修改角色'" + role.getRoleName() + "'失败，角色名称已存在");
}
```

- Prefer this:

```java
throw new ServiceException("登录失败");
```

- Over this:

```java
throw new RuntimeException("登录失败");
```

## Final Preference For This Repo

- controller: mostly `Result.success(...)`
- service: business rule checks and `ServiceException`
- framework/global handler: unified conversion to failure responses
- gateway: keep gateway-specific exception handling in the gateway handler
