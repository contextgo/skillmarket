# Commands

Assume this repository uses Maven from the system path. There is no checked-in Maven wrapper at the repo root.

## Preconditions

- Use Java 17.
- Run commands from the repo root unless a task clearly needs a module workdir.
- Expect service startup to depend on reachable Nacos config and injected profile properties from the parent `pom.xml`.

## Full Build

```powershell
mvn clean package -DskipTests
```

Use this only when module boundaries are unclear or after broader dependency changes.

## Targeted Build

Build only the changed module and any required upstream modules:

```powershell
mvn -pl miaohong-gateway -am clean package -DskipTests
mvn -pl miaohong-auth -am clean package -DskipTests
mvn -pl miaohong-modules/miaohong-system -am clean package -DskipTests
mvn -pl miaohong-modules/miaohong-content-security -am clean package -DskipTests
mvn -pl miaohong-common/miaohong-common-security -am clean package -DskipTests
mvn -pl miaohong-modules-api/miaohong-system-api/user-api -am clean package -DskipTests
```

## Targeted Tests

```powershell
mvn -pl miaohong-modules/miaohong-content-security -am test
mvn -pl miaohong-modules/miaohong-system -am test
```

If a module has few or no tests, say so explicitly and fall back to compile or package verification.

## Run Built Jars

Use this when the target jar already exists or after a package step:

```powershell
java -jar .\miaohong-gateway\target\miaohong-gateway.jar
java -jar .\miaohong-auth\target\miaohong-auth.jar
java -jar .\miaohong-modules\miaohong-system\target\miaohong-system.jar
java -jar .\miaohong-modules\miaohong-agent\target\miaohong-agent.jar
java -jar .\miaohong-modules\miaohong-content-security\target\miaohong-content-security.jar
```

For services without a confirmed jar name in the current workspace, inspect the module `target/` directory first.

## Quick Search Patterns

Use these when locating code on Windows PowerShell:

```powershell
Get-ChildItem -Recurse -Include *Controller.java,*Service.java,*Mapper.java -File .\miaohong-modules\miaohong-system\src\main\java
Get-ChildItem -Recurse -Include *Mapper.xml -File .\miaohong-modules\miaohong-system\src\main\java
Get-ChildItem -Recurse -Include application.yml,bootstrap.yml -File .\miaohong-gateway\src\main\resources
Get-ChildItem -Recurse -Include *.java -File . | Select-String -Pattern '@SpringBootApplication'
```

## Practical Verification Order

1. Run a targeted Maven package or test for the changed module.
2. If configuration or startup changed, inspect `bootstrap.yml`, `application.yml`, and expected Nacos imports.
3. If a runtime service was touched, verify the built jar or startup path for that specific service before attempting a full-system run.
