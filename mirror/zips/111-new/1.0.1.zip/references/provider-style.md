# Provider Style

## Scope

Use a provider only for cross-service contracts.

- Local HTTP endpoints inside one service module should stay in `controller`.
- Cross-service calls that need Feign contracts should use `modules-api` + runtime `provider`.
- Do not add a provider just to avoid calling a local service directly inside the same module.

For `miaohong-agent`, this distinction matters more than in older modules:

- The module already has many rich local controllers under `/agent/...`.
- New remote access should not reuse those controller classes directly.
- Remote contracts should be thinner, more stable, and hide agent-internal entities and orchestration details.

## Package And Naming

For new provider code, use this structure:

- Feign interface: `miaohong-modules-api/.../<domain>/api/feign/I<Domain><Capability>Provider.java`
- Runtime implementation: `miaohong-modules/.../<domain>/provider/<Domain><Capability>Provider.java`
- API request and response objects: place under the matching `modules-api` package, using `Api...DTO` and `Api...VO`

Naming rules:

- Interface names use `I...Provider`, for example `IAgentSkillProvider`
- Implementation names use `...Provider`, for example `AgentSkillProvider`
- Do not place provider implementations under `controller`
- Do not name a local controller as `...Provider`

## Route Constants

Do not hardcode provider routes in interface methods.

- Put provider paths in provider constant classes
- Keep the same pattern as existing modules, for example `/provider/<domain>/v1/...`
- For new `miaohong-agent` contracts, prefer a dedicated constant holder instead of mixing agent routes into unrelated system constants

Recommended direction for new agent contracts:

- Prefix: `/provider/agent/v1`
- Resource path follows the agent business domain, for example `/skill`, `/mcp`, `/registry`, `/knowledge`

Example constant style:

```java
public interface AgentProviderConstant {

    String PROVIDER = "/provider";
    String AGENT = "/agent";
    String V1 = "/v1";
    String SKILL = "/skill";

    String PROVIDER_AGENT_V1_SKILL_DETAIL = PROVIDER + AGENT + V1 + SKILL + "/detail";
}
```

## Feign Interface Rules

Provider interfaces define the remote contract.

- Use `@FeignClient`
- Use explicit Spring MVC mapping annotations on every method
- Do not use Swagger annotations
- Do not use `@PathVariable`
- Do not expose service internals, mapper objects, or entity classes unless the contract is already frozen and cannot be changed safely
- GET methods are only for single-parameter queries with one `@RequestParam`
- If a method needs multiple parameters, use `@PostMapping` with one `@RequestBody DTO`
- POST methods must not mix `@RequestParam` with `@RequestBody`
- POST request bodies must use DTOs, not `Map`

For new code:

- Query methods should prefer `Result<ApiVO>` or `Result<RowsData<ApiVO>>`
- Command methods should prefer `Result<Void>` when there is no payload to return
- Avoid returning MyBatis `Page<?>` directly over Feign
- Avoid returning runtime `entity` classes over Feign
- Avoid `Map` in request and response contracts

Backward compatibility rule:

- If an existing provider already returns a raw object and other modules depend on it, keep the current signature unless the user asks for a contract upgrade
- New provider methods should follow the unified result style instead of copying old irregular patterns

## Provider Implementation Rules

Provider implementations are thin adapters.

- Annotate with `@RestController`
- Use `@RequiredArgsConstructor`
- Inject dependencies with `private final`
- Do not use `@RequiredArgsConstructor(onConstructor_ = @Autowired)` for new code
- Use Javadoc on public methods
- Implement the Feign interface directly

Provider responsibilities:

- Accept Feign-facing DTOs and parameters
- Delegate to the service layer
- Convert between `ApiDTO` and internal DTO when needed
- Convert between internal VO and `ApiVO` when needed
- Wrap successful results with `Result.success(...)`

Provider should not:

- Hold complex business orchestration
- Reimplement controller validation rules in a second place
- Assemble large query wrappers or SQL conditions unless the method is a tiny read-only adapter
- Catch and swallow service exceptions
- Inject many peer services and become a second service layer

For `miaohong-agent`, keep providers even thinner than local controllers:

- Core orchestration stays in service classes such as dispatch, registry, skill, tool, and knowledge services
- Provider methods should expose only the remote contract needed by other modules
- Do not leak agent runtime state models unless they are already designed as shared `ApiVO`

## Result And DTO Rules

Provider contracts should be stricter than local controllers.

- Local controllers in `miaohong-agent` may temporarily return entity objects or `Page<?>`
- Providers should normalize those responses before crossing service boundaries

Recommended mapping:

- Detail query: `Result<ApiDetailsVO>`
- List query: `Result<List<ApiVO>>`
- Page query: `Result<RowsData<ApiVO>>`
- Existence or switch check: `Result<Boolean>`
- Create, update, delete, enable, disable, trigger without payload: `Result<Void>`
- Count, ID, token, or state payloads: return the matching scalar type in `Result<T>`

When conversion is needed:

- Convert internal entity or VO to `ApiVO` inside provider or a dedicated assembler/helper
- Do not make remote callers depend on internal packages under `miaohong-agent`
- If an endpoint needs multiple filters or compound conditions, define an `Api...QueryDTO` instead of exposing multiple scalar parameters in the Feign signature

## Exception And Logging Rules

- Let business failures come from the service layer as `ServiceException`
- Provider methods normally stay on the success path and do not return `Result.fail(...)`
- Do not wrap normal business failures as `RuntimeException`
- Only add boundary logging when the remote context itself adds value

## Dependency Boundary Rules

Use providers to avoid cross-module service coupling.

- A module that needs agent capability should call the agent provider through Feign
- Do not make another module depend on `miaohong-agent` service implementations directly
- Do not solve cross-module reuse by injecting services into each other across runtime modules

This is especially important for `miaohong-agent` because dispatch, memory, MCP, skill, and knowledge logic already have strong internal coordination. Cross-service consumers should see a stable provider facade, not the internal service graph.

## Recommended New Style For Agent Providers

When `miaohong-agent` starts exposing remote contracts, prefer this pattern:

```java
package com.miaohong.ai.agent.skill.api.feign;

import com.miaohong.ai.common.core.domain.Result;
import com.miaohong.ai.common.core.dto.RowsData;
import com.miaohong.ai.agent.skill.api.dto.ApiSkillQueryDTO;
import com.miaohong.ai.agent.skill.api.vo.ApiSkillDetailsVO;
import com.miaohong.ai.agent.skill.api.vo.ApiSkillListVO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * Agent Skill 提供者接口
 *
 * @author bianruhao
 * @since 2026-03-25
 */
@FeignClient(name = "miaohong-agent")
public interface IAgentSkillProvider {

    /**
     * 查询 Skill 列表
     *
     * @param dto 查询条件
     * @return Skill 列表
     */
    @PostMapping(AgentProviderConstant.PROVIDER_AGENT_V1_SKILL_LIST)
    Result<RowsData<ApiSkillListVO>> list(@RequestBody ApiSkillQueryDTO dto);

    /**
     * 查询 Skill 详情
     *
     * @param skillCode Skill 编码
     * @return Skill 详情
     */
    @GetMapping(AgentProviderConstant.PROVIDER_AGENT_V1_SKILL_DETAIL)
    Result<ApiSkillDetailsVO> detail(@RequestParam("skillCode") String skillCode);
}
```

```java
package com.miaohong.ai.agent.skill.provider;

import com.miaohong.ai.agent.skill.api.feign.IAgentSkillProvider;
import com.miaohong.ai.agent.skill.api.vo.ApiSkillDetailsVO;
import com.miaohong.ai.agent.skill.api.vo.ApiSkillListVO;
import com.miaohong.ai.agent.skill.dto.SkillQueryDTO;
import com.miaohong.ai.agent.skill.service.IAgentSkillService;
import com.miaohong.ai.common.core.domain.Result;
import com.miaohong.ai.common.core.dto.RowsData;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.RestController;

/**
 * Agent Skill 提供者
 *
 * @author bianruhao
 * @since 2026-03-25
 */
@RestController
@RequiredArgsConstructor
public class AgentSkillProvider implements IAgentSkillProvider {

    private final IAgentSkillService agentSkillService;

    /**
     * 查询 Skill 列表
     *
     * @param dto 查询条件
     * @return Skill 列表
     */
    @Override
    public Result<RowsData<ApiSkillListVO>> list(ApiSkillQueryDTO dto) {
        SkillQueryDTO queryDTO = new SkillQueryDTO();
        queryDTO.setCategory(dto.getCategory());
        queryDTO.setStatus(dto.getStatus());
        queryDTO.setPageNum(dto.getPageNum());
        queryDTO.setPageSize(dto.getPageSize());
        return Result.success(agentSkillService.providerList(queryDTO));
    }

    /**
     * 查询 Skill 详情
     *
     * @param skillCode Skill 编码
     * @return Skill 详情
     */
    @Override
    public Result<ApiSkillDetailsVO> detail(String skillCode) {
        return Result.success(agentSkillService.providerDetail(skillCode));
    }
}
```

## Migration Guidance

When touching old provider code in system modules:

- Do not force a full rewrite only to match the new style
- Prefer incremental cleanup when already editing the file
- New provider methods should follow the new conventions even if the old file still has legacy annotations or return types

For `miaohong-agent`, because provider contracts are not yet established, start directly from the new style instead of copying historical inconsistencies from older modules.
