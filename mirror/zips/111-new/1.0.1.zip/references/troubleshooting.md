# Troubleshooting

Use this file for startup failures, routing issues, config drift, or SQL/mapper problems.

## 1. Service Will Not Start

Check these first:

1. Confirm Java 17 and Maven are available.
2. Confirm the intended module builds with `mvn -pl <module> -am clean package -DskipTests`.
3. Inspect the service `bootstrap.yml` for `spring.application.name`, profile placeholder, and Nacos import settings.
4. Confirm the expected Nacos server, namespace, and group are reachable for the active profile.
5. Ignore noise from `target/` copies and inspect source files under `src/main`.

## 2. Nacos Config Does Not Seem To Apply

Work through this checklist:

1. Read the module `bootstrap.yml`.
2. Confirm which configs are imported through `spring.config.import`.
3. Compare the effective app name with the expected Nacos data IDs.
4. Compare the effective profile with the Nacos namespace.
5. Check whether the missing setting is supposed to live in local `application.yml` instead of Nacos.

Repo-specific note:

- Several services import both `miaohong-common` and `${spring.application.name}` config sets.
- `miaohong-system` additionally imports `miaohong-oss`.

## 3. Gateway Traffic Looks Wrong

Start with:

1. `miaohong-gateway/src/main/resources/bootstrap.yml`
2. The gateway service registration in Nacos
3. The downstream service registration and health
4. Any Nacos-managed route or filter configuration tied to `miaohong-gateway`

The checked-in gateway `application.yml` is minimal, so do not assume all route configuration lives in git.

## 4. Mapper or SQL Behavior Looks Wrong

This repo stores many mapper XML files beside Java source. Check both:

1. `.../mapper/*Mapper.java`
2. `.../mapper/xml/*Mapper.xml`

Do not stop after editing only the mapper interface if the query is XML-backed.

## 5. Cross-Service Contract Change Breaks Consumers

Check these together:

1. The provider controller/service implementation
2. The matching module under `miaohong-modules-api`
3. Any shared DTOs or Feign-facing interfaces in `miaohong-common` or API modules

If only the provider changed and the shared API module did not, contract drift is a likely cause.

## 6. Static Resource Or File Serving Looks Wrong

For `miaohong-system`, inspect `src/main/resources/application.yml` for local static resource overrides. The checked-in file includes local static locations and `/static/**` path handling, so not all resource behavior comes from Nacos.

## 7. Content Security Service Behavior Is Special

`miaohong-content-security` contains local `spring.ai.mcp.server` settings in `application.yml`. If behavior differs there, inspect both local configuration and any Nacos overrides before assuming the code path is wrong.
