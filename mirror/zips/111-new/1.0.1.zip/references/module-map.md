# Module Map

Use this file first when the request is about where a change belongs.

## Root Modules

| Path | Role | Use It When |
| --- | --- | --- |
| `pom.xml` | Parent aggregator and dependency management | You need Java version, Spring versions, Maven profiles, or global dependency alignment |
| `miaohong-gateway` | Spring Cloud Gateway service | You are debugging routes, filters, cross-service entry traffic, or gateway startup |
| `miaohong-auth` | Authentication service | You are touching login, token, or auth-related flows |
| `miaohong-modules` | Runtime business services | You are changing business behavior in concrete domain services |
| `miaohong-modules-api` | Shared API and contract modules | You are changing cross-service contracts, DTOs, or Feign-facing APIs |
| `miaohong-common` | Shared libraries and infrastructure | You are changing reusable framework code, security, MyBatis helpers, Redis, OpenFeign, logging, or shared utilities |
| `sql` | SQL assets | You need schema or migration context |
| `docs` | Project documentation | You need repo-local design or delivery context |

## Runtime Services

These application names and ports come from checked-in `bootstrap.yml` files when present.

| Service Path | `spring.application.name` | Local Port | Main Class | Notes |
| --- | --- | --- | --- | --- |
| `miaohong-gateway` | `miaohong-gateway` | `28088` | `com.miaohong.ai.gateway.DataAIGatewayApplication` | Imports `miaohong-common` and app-specific Nacos config |
| `miaohong-auth` | `miaohong-auth` | `28080` | `com.miaohong.ai.auth.DataAIAuthApplication` | Auth service with Nacos-backed config |
| `miaohong-modules/miaohong-system` | `miaohong-system` | `28087` | `com.miaohong.ai.DataAISystemApplication` | Large business module with many domain packages |
| `miaohong-modules/miaohong-agent` | `miaohong-agent` | `28092` | `com.miaohong.ai.agent.LobsterAgentApplication` | Agent-related service |
| `miaohong-modules/miaohong-content-security` | `miaohong-content-security` | `28093` | `com.miaohong.ai.DataAIContentSecurityApplication` | Contains local Spring AI MCP server settings in `application.yml` |
| `miaohong-modules/miaohong-micro-app` | `miaohong-micro-app` | not declared in checked-in `bootstrap.yml` | `com.miaohong.ai.DataAIMicroApplication` | Check Nacos and module config for effective runtime port |
| `miaohong-modules/miaohong-snailJob` | `miaohong-snailJob` | not declared in checked-in `bootstrap.yml` | `com.miaohong.ai.ScheduleServerApplication` | Check Nacos and module config for effective runtime port |

## `miaohong-modules`

| Path | Role |
| --- | --- |
| `miaohong-modules/miaohong-system` | Core system/business domains such as app, area, auth, board, config, customer, dept, dict, file, log, menu, message, org, role, upload, user |
| `miaohong-modules/miaohong-agent` | Agent-specific runtime service |
| `miaohong-modules/miaohong-content-security` | Content security service |
| `miaohong-modules/miaohong-micro-app` | Micro-app related business service |
| `miaohong-modules/miaohong-snailJob` | Job/scheduler-oriented service |

## `miaohong-modules-api`

Use this layer when a change must be shared across services.

| Path | Role |
| --- | --- |
| `miaohong-modules-api/miaohong-system-api` | System-facing API submodules such as `user-api`, `role-api`, `dept-api`, `dict-api`, and `upload-api` |
| `miaohong-modules-api/miaohong-micro-app-api` | Micro-app shared APIs |
| `miaohong-modules-api/content-security-api` | Content-security shared APIs including `basic-api`, `customer-api`, `risk-api`, and `task-api` |

## `miaohong-common`

This is the shared foundation. Common change targets include:

- `miaohong-common-core`
- `miaohong-common-security`
- `miaohong-common-mybatis`
- `miaohong-common-openfeign`
- `miaohong-common-redis`
- `miaohong-common-web`
- `miaohong-common-satoken`

Start here when a request smells reusable or cross-cutting rather than business-specific.
