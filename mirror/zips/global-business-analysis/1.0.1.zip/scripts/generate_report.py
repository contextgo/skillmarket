"""
Global Business Analysis Report - Professional PDF Generator
Enhanced version: charts, SWOT visual, executive dashboard, live data timestamps.

Features:
- Cover page with country-themed colors + gradient effect
- Executive dashboard (key metrics vizualization)
- SWOT analysis visual matrix
- Competitor radar chart (matplotlib, with table fallback)
- Market growth line chart
- All 6 analysis sections with styled tables
- PESTEL analysis table
- Headers/footers with page numbers + report hash
- Data timestamp footer (for data freshness tracking)
- Confidentiality disclaimer
- Methodology & data sources section

Usage:
    python generate_report.py --output <path.pdf> --data <data.json> --lang <iso_code>

Install dependencies:
    pip install reportlab matplotlib

JSON Schema (data.json) - see header section for full schema.
"""

import json
import sys
import os
from datetime import datetime, timezone
from pathlib import Path

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import inch, cm, mm
from reportlab.lib.colors import HexColor, white, black, Color, PCMYKColor
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT, TA_JUSTIFY
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    PageBreak, KeepTogether, HRFlowable, Image
)
from reportlab.platypus.flowables import Flowable
from reportlab.pdfgen import canvas as pdfcanvas
from reportlab.lib.units import mm

PAGE_W, PAGE_H = A4
MARGIN = 1.8 * cm

# ── Chart support ──────────────────────────────────────────────────────
MATPLOTLIB_OK = False
plt = None
np = None
try:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import numpy as np
    MATPLOTLIB_OK = True
except Exception:
    pass


# ── Custom Flowables ────────────────────────────────────────────────────

class SectionDivider(Flowable):
    def __init__(self, color, width=None, thickness=2):
        Flowable.__init__(self)
        self.color = HexColor(color)
        self._width = width or (PAGE_W - 2 * MARGIN)
        self.height = thickness + 4
        self.thickness = thickness
    def draw(self):
        self.canv.setStrokeColor(self.color)
        self.canv.setLineWidth(self.thickness)
        self.canv.line(0, self.thickness / 2, self._width, self.thickness / 2)


class CalloutBox(Flowable):
    def __init__(self, text, bg_color, border_color, width=None):
        Flowable.__init__(self)
        self.text = text
        self.bg_color = HexColor(bg_color)
        self.border_color = HexColor(border_color)
        self._width = width or (PAGE_W - 2 * MARGIN - 10)
        self.style = ParagraphStyle(
            'CalloutText', fontSize=9.5, leading=14,
            textColor=HexColor('#1a1a1a'), fontName='Helvetica'
        )
        p = Paragraph(self.text, self.style)
        w, h = p.wrap(self._width - 20, 1000)
        self.height = h + 20
    def draw(self):
        self.canv.setFillColor(self.bg_color)
        self.canv.setStrokeColor(self.border_color)
        self.canv.setLineWidth(1.5)
        self.canv.roundRect(0, 0, self._width, self.height, 4, fill=1, stroke=1)
        p = Paragraph(self.text, self.style)
        p.wrap(self._width - 20, 1000)
        p.drawOn(self.canv, 10, 10)


class KPIBox(Flowable):
    """A colored KPI box with label + big number."""
    def __init__(self, label, value, color, width=100):
        Flowable.__init__(self)
        self.label = label
        self.value = value
        self.color = HexColor(color)
        self._width = width
        self.height = 52
    def draw(self):
        self.canv.setFillColor(self.color)
        self.canv.setStrokeColor(self.color)
        self.canv.roundRect(0, 0, self._width, self.height, 3, fill=1, stroke=0)
        self.canv.setFillColor(white)
        self.canv.setFont('Helvetica-Bold', 16)
        self.canv.drawCentredString(self._width / 2, self.height - 22, str(self.value))
        self.canv.setFont('Helvetica', 7.5)
        self.canv.drawCentredString(self._width / 2, 8, self.label)


class SWOTMatrix(Flowable):
    """Visual 2x2 SWOT matrix."""
    def __init__(self, strengths, weaknesses, opportunities, threats, width=None):
        Flowable.__init__(self)
        self.s = strengths[:3]
        self.w = weaknesses[:3]
        self.o = opportunities[:3]
        self.t = threats[:3]
        self._width = width or (PAGE_W - 2 * MARGIN)
        self.height = 220
    def draw(self):
        w = self._width
        h = self.height
        hw = w / 2 - 4
        hh = h / 2 - 4
        # Strengths (top-left) - green tint
        self.canv.setFillColor(Color(0.9, 0.96, 0.9))
        self.canv.setStrokeColor(Color(0.4, 0.7, 0.4))
        self.canv.roundRect(0, h/2, hw, hh, 2, fill=1, stroke=1)
        self.canv.setFillColor(Color(0.2, 0.5, 0.2))
        self.canv.setFont('Helvetica-Bold', 8)
        self.canv.drawString(6, h/2 + hh - 14, 'STRENGTHS')
        self.canv.setFont('Helvetica', 6.5)
        for i, item in enumerate(self.s):
            y = h/2 + hh - 28 - i * 12
            if y < h/2 + 4:
                break
            self.canv.drawString(6, y, f'  {item}')
        # Weaknesses (top-right) - red tint
        self.canv.setFillColor(Color(0.96, 0.9, 0.9))
        self.canv.setStrokeColor(Color(0.7, 0.4, 0.4))
        self.canv.roundRect(w/2+4, h/2, hw, hh, 2, fill=1, stroke=1)
        self.canv.setFillColor(Color(0.5, 0.2, 0.2))
        self.canv.setFont('Helvetica-Bold', 8)
        self.canv.drawString(w/2+10, h/2 + hh - 14, 'WEAKNESSES')
        self.canv.setFont('Helvetica', 6.5)
        for i, item in enumerate(self.w):
            y = h/2 + hh - 28 - i * 12
            if y < h/2 + 4:
                break
            self.canv.drawString(w/2+10, y, f'  {item}')
        # Opportunities (bottom-left) - blue tint
        self.canv.setFillColor(Color(0.9, 0.92, 0.96))
        self.canv.setStrokeColor(Color(0.4, 0.5, 0.7))
        self.canv.roundRect(0, 0, hw, h/2-4, 2, fill=1, stroke=1)
        self.canv.setFillColor(Color(0.2, 0.2, 0.5))
        self.canv.setFont('Helvetica-Bold', 8)
        self.canv.drawString(6, h/2 - 18, 'OPPORTUNITIES')
        self.canv.setFont('Helvetica', 6.5)
        for i, item in enumerate(self.o):
            y = h/2 - 32 - i * 12
            if y < 4:
                break
            self.canv.drawString(6, y, f'  {item}')
        # Threats (bottom-right) - orange tint
        self.canv.setFillColor(Color(0.96, 0.94, 0.9))
        self.canv.setStrokeColor(Color(0.7, 0.6, 0.4))
        self.canv.roundRect(w/2+4, 0, hw, h/2-4, 2, fill=1, stroke=1)
        self.canv.setFillColor(Color(0.5, 0.4, 0.2))
        self.canv.setFont('Helvetica-Bold', 8)
        self.canv.drawString(w/2+10, h/2 - 18, 'THREATS')
        self.canv.setFont('Helvetica', 6.5)
        for i, item in enumerate(self.t):
            y = h/2 - 32 - i * 12
            if y < 4:
                break
            self.canv.drawString(w/2+10, y, f'  {item}')


# ── Chart generators ───────────────────────────────────────────────────

def generate_radar_chart(competitors, output_path, title_color, accent_color):
    """Generate competitor radar chart; returns path or None."""
    if not MATPLOTLIB_OK or not competitors:
        return None
    try:
        dims = ['Prod\nQuality', 'Price', 'Brand', 'Service',
                 'Distrib', 'Digital', 'Innov', 'Share', 'Retain', 'Value+',
                 'Finance', 'ESG']
        stats = []
        labels = []
        for c in competitors:
            scores = c.get('scores', {})
            s = [scores.get('product_quality', 5)/10,
                  scores.get('price_competitiveness', 5)/10,
                  scores.get('brand_recognition', 5)/10,
                  scores.get('customer_service', 5)/10,
                  scores.get('distribution', 5)/10,
                  scores.get('digital_presence', 5)/10,
                  scores.get('innovation', 5)/10,
                  scores.get('market_share', 5)/10,
                  scores.get('customer_retention', 5)/10,
                  scores.get('value_added', 5)/10,
                  scores.get('financial_strength', 5)/10,
                  scores.get('esg_compliance', 5)/10]
            stats.append(s)
            labels.append(c.get('name', 'Competitor')[:12])
        N = len(dims)
        angles = [n / float(N) * 2 * 3.14159 for n in range(N)]
        angles += angles[:1]
        fig, ax = plt.subplots(figsize=(5, 4), subplot_kw=dict(polar=True))
        tc = HexColor(title_color)
        ac = HexColor(accent_color)
        fig.patch.setFacecolor('#f8f9fa')
        ax.set_facecolor('#ffffff')
        for i, s in enumerate(stats):
            vals = s + s[:1]
            color = plt.cm.Set2(i / float(len(stats)))
            ax.plot(angles, vals, 'o-', linewidth=1.5,
                    label=labels[i], color=color, markersize=3)
            ax.fill(angles, vals, alpha=0.1, color=color)
        ax.set_thetagrids([a * 180 / 3.14159 for a in angles[:-1]], dims, fontsize=6)
        ax.set_ylim(0, 1)
        ax.set_yticks([0.2, 0.4, 0.6, 0.8, 1.0])
        ax.set_yticklabels(['0.2', '0.4', '0.6', '0.8', '1.0'], fontsize=5)
        ax.legend(loc='upper right', bbox_to_anchor=(1.3, 1.0), fontsize=6)
        plt.tight_layout()
        plt.savefig(output_path, dpi=150, bbox_inches='tight',
                    facecolor=fig.get_facecolor())
        plt.close(fig)
        return output_path
    except Exception:
        return None


def generate_market_growth_chart(market_data, output_path, accent_color):
    """Generate market growth line chart; returns path or None."""
    if not MATPLOTLIB_OK or not market_data:
        return None
    try:
        years = [m.get('year', 2020) for m in market_data]
        values = [float(m.get('value', 0)) for m in market_data]
        if not years or not values:
            return None
        fig, ax = plt.subplots(figsize=(5, 2.5))
        ac = HexColor(accent_color)
        ax.plot(years, values, 'o-', linewidth=2, color=ac, markersize=4)
        ax.fill_between(years, values, alpha=0.15, color=ac)
        ax.set_xlabel('Year', fontsize=7)
        ax.set_ylabel('Market Size (USD B)', fontsize=7)
        ax.tick_params(labelsize=6)
        ax.grid(True, linestyle='--', alpha=0.3)
        plt.tight_layout()
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        plt.close(fig)
        return output_path
    except Exception:
        return None


# ── Helpers ───────────────────────────────────────────────────────────

def make_table(headers, rows, col_widths=None, accent_color='#C8A951'):
    title_c = HexColor(accent_color)
    header_bg = Color(title_c.red*0.15+0.85, title_c.green*0.15+0.85, title_c.blue*0.15+0.85)
    alt_bg = Color(0.96, 0.97, 0.98)
    avail = PAGE_W - 2 * MARGIN
    n = len(headers)
    widths = col_widths or [avail / n] * n
    data = [headers] + rows
    t = Table(data, colWidths=widths, repeatRows=1)
    style_cmds = [
        ('BACKGROUND', (0,0), (-1,0), header_bg),
        ('TEXTCOLOR', (0,0), (-1,0), HexColor('#1a1a1a')),
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
        ('FONTSIZE', (0,0), (-1,0), 8.5),
        ('FONTNAME', (0,1), (-1,-1), 'Helvetica'),
        ('FONTSIZE', (0,1), (-1,-1), 8),
        ('ALIGN', (0,0), (-1,-1), 'CENTER'),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('GRID', (0,0), (-1,-1), 0.4, Color(0.8,0.8,0.8)),
        ('TOPPADDING', (0,0), (-1,-1), 5),
        ('BOTTOMPADDING', (0,0), (-1,-1), 5),
        ('LEFTPADDING', (0,0), (-1,-1), 6),
        ('RIGHTPADDING', (0,0), (-1,-1), 6),
    ]
    for i in range(1, len(data)):
        if i % 2 == 0:
            style_cmds.append(('BACKGROUND', (0,i), (-1,i), alt_bg))
    t.setStyle(TableStyle(style_cmds))
    return t


def make_score_table(competitors, accent_color, title_color):
    dims = [
        ('Product Quality', 'product_quality'),
        ('Price Competitiveness', 'price_competitiveness'),
        ('Brand Recognition', 'brand_recognition'),
        ('Customer Service', 'customer_service'),
        ('Distribution', 'distribution'),
        ('Digital Presence', 'digital_presence'),
        ('Innovation', 'innovation'),
        ('Market Share', 'market_share'),
        ('Customer Retention', 'customer_retention'),
        ('Value-added', 'value_added'),
        ('Financial Strength', 'financial_strength'),
        ('ESG / Compliance', 'esg_compliance'),
    ]
    headers = ['Dimension'] + [c.get('name','?')[:12] for c in competitors]
    rows = []
    for label, key in dims:
        row = [label]
        for c in competitors:
            row.append(str(c.get('scores',{}).get(key, 0)))
        rows.append(row)
    rows.append(['TOTAL /100'] + [str(c.get('total_score','?')) for c in competitors])
    avail = PAGE_W - 2 * MARGIN
    n = len(headers)
    widths = [avail*0.28] + [avail*0.72/(n-1)] * (n-1)
    data = [headers] + rows
    t = Table(data, colWidths=widths, repeatRows=1)
    tc = HexColor(title_color)
    ac = HexColor(accent_color)
    hbg = Color(tc.red*0.15+0.85, tc.green*0.15+0.85, tc.blue*0.15+0.85)
    style_cmds = [
        ('BACKGROUND', (0,0), (-1,0), hbg),
        ('TEXTCOLOR', (0,0), (-1,0), HexColor('#1a1a1a')),
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
        ('FONTSIZE', (0,0), (-1,0), 7.5),
        ('FONTNAME', (0,1), (-1,-1), 'Helvetica'),
        ('FONTSIZE', (0,1), (-1,-1), 7.5),
        ('ALIGN', (0,0), (0,-1), 'LEFT'),
        ('ALIGN', (1,0), (-1,-1), 'CENTER'),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('GRID', (0,0), (-1,-1), 0.4, Color(0.8,0.8,0.8)),
        ('TOPPADDING', (0,0), (-1,-1), 3),
        ('BOTTOMPADDING', (0,0), (-1,-1), 3),
        ('LEFTPADDING', (0,0), (-1,-1), 5),
        ('RIGHTPADDING', (0,0), (-1,-1), 5),
        ('BACKGROUND', (0,-1), (-1,-1), Color(ac.red*0.2+0.8, ac.green*0.2+0.8, ac.blue*0.2+0.8)),
        ('FONTNAME', (0,-1), (-1,-1), 'Helvetica-Bold'),
    ]
    for i in range(1, len(data)-1):
        if i % 2 == 0:
            style_cmds.append(('BACKGROUND', (0,i), (-1,i), Color(0.96,0.97,0.98)))
    t.setStyle(TableStyle(style_cmds))
    return t


# ── Styles ─────────────────────────────────────────────────────────────

def create_styles(title_color):
    tc = HexColor(title_color)
    return {
        'cover_title': ParagraphStyle('CoverTitle', fontSize=26, leading=32,
            textColor=tc, fontName='Helvetica-Bold', alignment=TA_CENTER, spaceAfter=10),
        'cover_subtitle': ParagraphStyle('CoverSub', fontSize=12, leading=16,
            textColor=Color(0.4,0.4,0.4), fontName='Helvetica',
            alignment=TA_CENTER, spaceAfter=6),
        'disclaimer': ParagraphStyle('Disc', fontSize=7, leading=10,
            textColor=Color(0.6,0.6,0.6), fontName='Helvetica-Oblique',
            alignment=TA_CENTER),
        'h1': ParagraphStyle('H1', fontSize=16, leading=20,
            textColor=tc, fontName='Helvetica-Bold', spaceBefore=14, spaceAfter=8),
        'h2': ParagraphStyle('H2', fontSize=12, leading=15,
            textColor=tc, fontName='Helvetica-Bold', spaceBefore=10, spaceAfter=6),
        'h3': ParagraphStyle('H3', fontSize=10, leading=13,
            textColor=HexColor('#333333'), fontName='Helvetica-Bold',
            spaceBefore=8, spaceAfter=4),
        'body': ParagraphStyle('Body', fontSize=9, leading=13.5,
            textColor=HexColor('#2a2a2a'), fontName='Helvetica',
            alignment=TA_JUSTIFY, spaceAfter=6),
        'body_bold': ParagraphStyle('BodyBold', fontSize=9, leading=13.5,
            textColor=HexColor('#2a2a2a'), fontName='Helvetica-Bold', spaceAfter=4),
        'bullet': ParagraphStyle('Bullet', fontSize=9, leading=12.5,
            textColor=HexColor('#2a2a2a'), fontName='Helvetica',
            leftIndent=18, bulletIndent=6, spaceAfter=3),
        'toc_item': ParagraphStyle('TOCItem', fontSize=11, leading=20,
            textColor=HexColor('#333333'), fontName='Helvetica', leftIndent=20),
        'caption': ParagraphStyle('Caption', fontSize=7.5, leading=10,
            textColor=Color(0.5,0.5,0.5), fontName='Helvetica-Oblique',
            alignment=TA_CENTER),
        'small': ParagraphStyle('Small', fontSize=7.5, leading=11,
            textColor=HexColor('#444444'), fontName='Helvetica'),
        'data_timestamp': ParagraphStyle('DTS', fontSize=7, leading=9,
            textColor=Color(0.55,0.55,0.55), fontName='Helvetica',
            alignment=TA_CENTER),
    }


# ── Page callbacks ─────────────────────────────────────────────────────

def make_page_callbacks(title_color, accent_color, client_name, client_url, data_timestamp=''):
    tc = HexColor(title_color)
    ac = HexColor(accent_color)
    ts = data_timestamp
    def on_first(c, doc):
        c.saveState()
        c.setFillColor(ac)
        c.rect(0, PAGE_H-10, PAGE_W, 10, fill=1, stroke=0)
        c.setFillColor(tc)
        c.rect(0, 0, PAGE_W, 4, fill=1, stroke=0)
        c.setFillColor(Color(tc.red, tc.green, tc.blue, 0.06))
        c.rect(0, 4, 10, PAGE_H-18, fill=1, stroke=0)
        c.restoreState()
    def on_later(c, doc):
        c.saveState()
        c.setStrokeColor(tc)
        c.setLineWidth(0.6)
        c.line(MARGIN, PAGE_H-MARGIN+12, PAGE_W-MARGIN, PAGE_H-MARGIN+12)
        c.setFont('Helvetica', 7)
        c.setFillColor(Color(0.4,0.4,0.4))
        c.drawString(MARGIN, PAGE_H-MARGIN+16, client_name[:40])
        c.drawRightString(PAGE_W-MARGIN, PAGE_H-MARGIN+16, 'Business Analysis')
        c.setStrokeColor(Color(0.82,0.82,0.82))
        c.line(MARGIN, MARGIN-12, PAGE_W-MARGIN, MARGIN-12)
        c.setFont('Helvetica', 7)
        c.setFillColor(Color(0.5,0.5,0.5))
        c.drawString(MARGIN, MARGIN-24, client_url)
        if ts:
            c.drawCentredString(PAGE_W/2, MARGIN-24, f'Data as of: {ts}')
        c.drawRightString(PAGE_W-MARGIN, MARGIN-24, f'Page {doc.page}')
        c.setFillColor(ac)
        c.rect(0, 0, PAGE_W, 3, fill=1, stroke=0)
        c.restoreState()
    return on_first, on_later


# ── Content builders ───────────────────────────────────────────────────

def build_cover(data, styles):
    el = []
    el.append(Spacer(1, 100))
    el.append(Paragraph(data.get('client_name','Client'), styles['cover_title']))
    el.append(Spacer(1, 6))
    el.append(Paragraph(f"{data.get('country','')}  Business Analysis Report", styles['cover_subtitle']))
    el.append(Spacer(1, 12))
    el.append(SectionDivider(data.get('accent_color','#C8A951'), thickness=2))
    el.append(Spacer(1, 20))
    el.append(Paragraph(f"Website: {data.get('client_url','')}", styles['cover_subtitle']))
    el.append(Paragraph(f"Industry: {data.get('industry','N/A')}", styles['cover_subtitle']))
    el.append(Paragraph(f"Report Date: {data.get('report_date', datetime.now().strftime('%Y-%m-%d'))}", styles['cover_subtitle']))
    if data.get('data_timestamp'):
        el.append(Spacer(1, 6))
        el.append(Paragraph(f"Market data timestamp: {data['data_timestamp']}", styles['data_timestamp']))
    el.append(Spacer(1, 40))
    if data.get('executive_summary'):
        es = ParagraphStyle('ES', fontSize=9.5, leading=14,
            textColor=Color(0.3,0.3,0.3), fontName='Helvetica-Oblique',
            alignment=TA_CENTER, leftIndent=50, rightIndent=50)
        el.append(Paragraph(data['executive_summary'], es))
    el.append(Spacer(1, 30))
    el.append(Paragraph('CONFIDENTIAL  FOR INTERNAL USE ONLY', styles['disclaimer']))
    el.append(PageBreak())
    return el


def build_toc(data, styles):
    el = []
    el.append(Paragraph('Table of Contents', styles['h1']))
    el.append(SectionDivider(data.get('accent_color','#C8A951'), thickness=1.5))
    el.append(Spacer(1, 12))
    sections = []
    for i in range(1, 7):
        key = f'section{i}'
        if key in data:
            sections.append(data[key].get('title', f'Section {i}'))
    for idx, title in enumerate(sections, 1):
        el.append(Paragraph(f"<b>{idx}.</b>   {title}", styles['toc_item']))
    el.append(PageBreak())
    return el


def build_executive_dashboard(data, styles, accent_color):
    """Page 3: visual dashboard with KPIs and SWOT."""
    el = []
    el.append(Paragraph('Executive Dashboard', styles['h1']))
    el.append(SectionDivider(data.get('accent_color','#C8A951'), thickness=1.5))
    el.append(Spacer(1, 10))
    # KPI row
    kpi_data = data.get('executive_kpis', [])
    if kpi_data:
        kpi_table_data = []
        row = []
        for kpi in kpi_data[:4]:
            row.append(KPIBox(kpi.get('label',''), kpi.get('value',''), accent_color))
        # arrange in a table for layout
        kpi_w = (PAGE_W - 2*MARGIN) / len(row)
        kpi_t = Table([[c for c in row]], colWidths=[kpi_w] * len(row))
        kpi_t.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'MIDDLE'),
                                  ('ALIGN',(0,0),(-1,-1),'CENTER')]))
        el.append(kpi_t)
        el.append(Spacer(1, 12))
    # SWOT
    swot = data.get('swot', {})
    if swot.get('strengths'):
        el.append(SWOTMatrix(
            swot.get('strengths',[]),
            swot.get('weaknesses',[]),
            swot.get('opportunities',[]),
            swot.get('threats',[])
        ))
        el.append(Spacer(1, 4))
        el.append(Paragraph('Figure 1: SWOT Analysis Matrix', styles['caption']))
    el.append(PageBreak())
    return el


def build_swot_detail(data, styles, accent_color):
    el = []
    swot = data.get('swot', {})
    if not any(swot.values()):
        return el
    el.append(Paragraph('SWOT Analysis — Detailed', styles['h2']))
    for label, key in [('Strengths','strengths'),('Weaknesses','weaknesses'),
                     ('Opportunities','opportunities'),('Threats','threats')]:
        items = swot.get(key, [])
        if items:
            el.append(Paragraph(label, styles['h3']))
            for item in items:
                el.append(Paragraph(f"  {item}", styles['bullet']))
    el.append(PageBreak())
    return el


def build_pestel(data, styles, accent_color):
    el = []
    pestel = data.get('pestel', {})
    if not any(pestel.values()):
        return el
    el.append(Paragraph('PESTEL Analysis', styles['h2']))
    el.append(SectionDivider(accent_color, thickness=1))
    el.append(Spacer(1, 6))
    dims = [('Political','political'),('Economic','economic'),('Social','social'),
            ('Technological','technological'),('Environmental','environmental'),('Legal','legal')]
    for label, key in dims:
        items = pestel.get(key, [])
        if items:
            el.append(Paragraph(f"{label}", styles['h3']))
            for item in items[:4]:
                el.append(Paragraph(f"  {item}", styles['bullet']))
            if len(items) > 4:
                el.append(Paragraph(f"  <i>(+ {len(items)-4} more — see appendix)</i>", styles['small']))
    el.append(PageBreak())
    return el


def build_section1(data, styles, accent_color):
    """Company Analysis."""
    s = data.get('section1', {})
    el = []
    el.append(Paragraph(s.get('title','Company Analysis'), styles['h1']))
    el.append(SectionDivider(accent_color, thickness=1.5))
    el.append(Spacer(1, 8))
    el.append(Paragraph('Business Model & Overview', styles['h2']))
    el.append(Paragraph(s.get('company_overview',''), styles['body']))
    if s.get('business_model'):
        el.append(Paragraph(f"<b>Business model:</b> {s['business_model']}", styles['body']))
    if s.get('founded'):
        el.append(Paragraph(f"<b>Founded:</b> {s['founded']}   <b> HQ:</b> {s.get('hq','N/A')}   <b> Employees:</b> {s.get('employees','N/A')}", styles['body']))
    if s.get('revenue_estimate'):
        el.append(Paragraph(f"<b>Revenue (est.):</b> {s['revenue_estimate']}", styles['body']))
    # Products
    products = s.get('products', [])
    if products:
        el.append(Spacer(1, 6))
        el.append(Paragraph('Products / Services', styles['h2']))
        headers = ['Name', 'Description', 'Price Range']
        rows = [[p.get('name',''), p.get('desc',''), p.get('price_range','')] for p in products]
        el.append(make_table(headers, rows, None, accent_color))
        el.append(Spacer(1, 6))
    # SWOT summary (if not already shown in dashboard)
    el.extend(build_swot_detail(data, styles, accent_color))
    # PESTEL
    el.extend(build_pestel(data, styles, accent_color))
    # Strengths/Weaknesses
    el.append(Paragraph('Key Strengths', styles['h2']))
    for item in s.get('strengths', []):
        el.append(Paragraph(f"  {item}", styles['bullet']))
    el.append(Paragraph('Key Weaknesses', styles['h2']))
    for item in s.get('weaknesses', []):
        el.append(Paragraph(f"  {item}", styles['bullet']))
    if s.get('website_score'):
        el.append(Spacer(1, 6))
        el.append(Paragraph(f"Website UX Score: <b>{s['website_score']}/10</b>", styles['body_bold']))
    el.append(PageBreak())
    return el


def build_section2(data, styles, accent_color):
    """Market & Industry Analysis."""
    s = data.get('section2', {})
    el = []
    el.append(Paragraph(s.get('title','Market & Industry Analysis'), styles['h1']))
    el.append(SectionDivider(accent_color, thickness=1.5))
    el.append(Spacer(1, 8))
    # Market size callout
    mkt_text = (f"Market Size: <b>{s.get('market_size','N/A')}</b>   |   "
                f"Growth: <b>{s.get('growth_rate','N/A')}</b>   |   "
                f"CAGR: <b>{s.get('cagr','N/A')}</b>")
    el.append(CalloutBox(mkt_text, '#f0f4f8', data.get('title_color','#1B3A5C')))
    el.append(Spacer(1, 10))
    # Market chart (if available)
    chart_path = data.get('_market_chart_path')
    if chart_path and os.path.exists(chart_path):
        try:
            img = Image(chart_path, width=PAGE_W-2*MARGIN-40, height=120)
            el.append(img)
            el.append(Spacer(1, 4))
            el.append(Paragraph('Figure 2: Market Size & Growth Projection', styles['caption']))
            el.append(Spacer(1, 8))
        except Exception:
            pass
    # Market data table
    market_data = s.get('market_data', [])
    if market_data:
        el.append(Paragraph('Key Market Metrics', styles['h2']))
        headers = ['Metric', 'Value', 'Source', 'Date']
        rows = [[d.get('metric',''), d.get('value',''), d.get('source',''), d.get('date','')] for d in market_data]
        el.append(make_table(headers, rows, None, accent_color))
        el.append(Spacer(1, 8))
    # Trends
    el.append(Paragraph('Key Market Trends', styles['h2']))
    for item in s.get('key_trends', []):
        el.append(Paragraph(f"  {item}", styles['bullet']))
    if s.get('regulatory_notes'):
        el.append(Paragraph('Regulatory Environment', styles['h2']))
        el.append(Paragraph(s['regulatory_notes'], styles['body']))
    if s.get('customer_behavior'):
        el.append(Paragraph('Customer Segmentation & Behavior', styles['h2']))
        el.append(Paragraph(s['customer_behavior'], styles['body']))
    el.append(PageBreak())
    return el


def build_section3(data, styles, accent_color, title_color):
    """Competitive Landscape."""
    s = data.get('section3', {})
    competitors = s.get('competitors', [])
    el = []
    el.append(Paragraph(s.get('title','Competitive Landscape'), styles['h1']))
    el.append(SectionDivider(accent_color, thickness=1.5))
    el.append(Spacer(1, 8))
    # Radar chart
    radar_path = data.get('_radar_chart_path')
    if radar_path and os.path.exists(radar_path):
        try:
            img = Image(radar_path, width=350, height=280)
            el.append(img)
            el.append(Spacer(1, 4))
            el.append(Paragraph('Figure 3: Competitor Capability Radar', styles['caption']))
            el.append(Spacer(1, 8))
        except Exception:
            pass
    # Score table
    if competitors:
        el.append(Paragraph('Competitive Positioning Scorecard (12 dimensions  8.33 pts = 100 max)', styles['h2']))
        el.append(make_score_table(competitors, accent_color, title_color))
        el.append(Spacer(1, 10))
    # Porter's 5 (if provided)
    porters = data.get('section3',{}).get('porters_five', {})
    if any(porters.values()):
        el.append(Paragraph("Porter's 5 Forces", styles['h2']))
        for label, key in [('New Entrants','new_entrants'),('Buyer Power','buyer_power'),
                         ('Supplier Power','supplier_power'),('Substitutes','substitutes'),
                         ('Rivalry','rivalry')]:
            val = porters.get(key, '')
            if val:
                el.append(Paragraph(f"<b>{label}:</b> {val}", styles['body']))
        el.append(Spacer(1, 6))
    # Competitor profiles
    for c in competitors:
        el.append(Paragraph(f"{c.get('name','?')} ({c.get('url','')})  Score: <b>{c.get('total_score','?')}/100</b>", styles['h2']))
        el.append(Paragraph('<b>Strengths:</b>', styles['body_bold']))
        for item in c.get('strengths', [])[:4]:
            el.append(Paragraph(f"  {item}", styles['bullet']))
        el.append(Paragraph('<b>Weaknesses:</b>', styles['body_bold']))
        for item in c.get('weaknesses', [])[:4]:
            el.append(Paragraph(f"  {item}", styles['bullet']))
        el.append(Spacer(1, 6))
    el.append(PageBreak())
    return el


def build_section4(data, styles, accent_color):
    """Strategic Recommendations."""
    s = data.get('section4', {})
    el = []
    el.append(Paragraph(s.get('title','Strategic Recommendations'), styles['h1']))
    el.append(SectionDivider(accent_color, thickness=1.5))
    el.append(Spacer(1, 8))
    if s.get('gap_analysis'):
        el.append(Paragraph('Gap Analysis', styles['h2']))
        for item in s['gap_analysis']:
            el.append(Paragraph(f"  {item}", styles['bullet']))
    # Opportunities table
    opps = s.get('new_opportunities', [])
    if opps:
        el.append(Spacer(1, 6))
        el.append(Paragraph('New Opportunities', styles['h2']))
        headers = ['Opportunity', 'Rationale', 'Est. Impact', 'Priority']
        rows = [[o.get('product',''), o.get('rationale',''),
                  o.get('estimated_demand',''), o.get('priority','M')] for o in opps]
        el.append(make_table(headers, rows, None, accent_color))
        el.append(Spacer(1, 8))
    if s.get('pricing_strategy'):
        el.append(Paragraph('Pricing & Commercial Strategy', styles['h2']))
        el.append(Paragraph(s['pricing_strategy'], styles['body']))
    if s.get('upsell_opportunities'):
        el.append(Paragraph('Upsell / Cross-sell', styles['h2']))
        for item in s['upsell_opportunities']:
            el.append(Paragraph(f"  {item}", styles['bullet']))
    el.append(PageBreak())
    return el


def build_section5(data, styles, accent_color):
    """Growth Strategies with timelines."""
    s = data.get('section5', {})
    el = []
    el.append(Paragraph(s.get('title','Growth Strategy'), styles['h1']))
    el.append(SectionDivider(accent_color, thickness=1.5))
    el.append(Spacer(1, 8))
    for label, key in [('Short-term (0-6 Months)','short_term'),('Medium-term (6-18 Months)','medium_term'),('Long-term (18-36 Months)','long_term')]:
        strategies = s.get(key, [])
        if strategies:
            el.append(Paragraph(label, styles['h2']))
            for idx, st in enumerate(strategies, 1):
                el.append(Paragraph(f"<b>{idx}. {st.get('strategy','')}</b>  <font color='#888888'>({st.get('timeline','')})</font>", styles['h3']))
                el.append(Paragraph(f"KPI: {st.get('kpi','')}", styles['body_bold']))
                for action in st.get('actions', []):
                    el.append(Paragraph(f"  {action}", styles['bullet']))
                el.append(Spacer(1, 4))
    el.append(PageBreak())
    return el


def build_section6(data, styles, accent_color):
    """Implementation & Optimization."""
    s = data.get('section6', {})
    el = []
    el.append(Paragraph(s.get('title','Implementation & Optimization'), styles['h1']))
    el.append(SectionDivider(accent_color, thickness=1.5))
    el.append(Spacer(1, 8))
    categories = [
        ('Digital & Technical','digital_recommendations'),
        ('Marketing & Sales','marketing_recommendations'),
        ('Operations & Supply Chain','operations_recommendations'),
        ('Risk & Compliance','risk_recommendations'),
    ]
    for title, key in categories:
        items = s.get(key, [])
        if items:
            el.append(Paragraph(title, styles['h2']))
            for item in items:
                el.append(Paragraph(f"  {item}", styles['bullet']))
            el.append(Spacer(1, 4))
    # Priority matrix
    pm = s.get('priority_matrix', [])
    if pm:
        el.append(Paragraph('Implementation Priority Matrix', styles['h2']))
        headers = ['Action', 'Impact', 'Effort', 'Cost', 'Priority', 'Timeline']
        rows = [[p.get('action',''), p.get('impact',''), p.get('effort',''),
                  p.get('cost',''), p.get('priority',''), p.get('timeline','')] for p in pm]
        el.append(make_table(headers, rows, None, accent_color))
        el.append(Spacer(1, 8))
    # Data sources
    sources = data.get('data_sources', [])
    if sources:
        el.append(Paragraph('Data Sources & Methodology', styles['h2']))
        for src in sources:
            el.append(Paragraph(f"  {src}", styles['small']))
    el.append(Spacer(1, 10))
    el.append(Paragraph('END OF REPORT', styles['disclaimer']))
    return el


# ── Main ───────────────────────────────────────────────────────────────

def generate_report(output_path, data):
    title_color = data.get('title_color', '#1B3A5C')
    accent_color = data.get('accent_color', '#C8A951')
    client_name = data.get('client_name', 'Client')
    client_url = data.get('client_url', '')
    lang = data.get('lang', 'en')
    data_ts = data.get('data_timestamp', datetime.now().strftime('%Y-%m-%d'))

    styles = create_styles(title_color)
    on_first, on_later = make_page_callbacks(title_color, accent_color, client_name, client_url, data_ts)

    # Generate charts (side-effect: creates PNG files)
    radar_path = None
    market_chart_path = None
    tmp_dir = os.path.dirname(output_path) or '.'
    if MATPLOTLIB_OK:
        radar_path = os.path.join(tmp_dir, '_radar_tmp.png')
        radar = generate_radar_chart(
            data.get('section3',{}).get('competitors',[]),
            radar_path, title_color, accent_color)
        if radar:
            data['_radar_chart_path'] = radar_path
        if data.get('section2',{}).get('market_chart_data'):
            market_chart_path = os.path.join(tmp_dir, '_market_tmp.png')
            mc = generate_market_growth_chart(
                data['section2']['market_chart_data'],
                market_chart_path, accent_color)
            if mc:
                data['_market_chart_path'] = market_chart_path

    doc = SimpleDocTemplate(
        output_path, pagesize=A4,
        leftMargin=MARGIN, rightMargin=MARGIN,
        topMargin=MARGIN+8, bottomMargin=MARGIN+8,
        title=f"{client_name} - Business Analysis",
        author='Business Analysis Consultant'
    )

    el = []
    el.extend(build_cover(data, styles))
    el.extend(build_toc(data, styles))
    el.extend(build_executive_dashboard(data, styles, accent_color))
    el.extend(build_section1(data, styles, accent_color))
    el.extend(build_section2(data, styles, accent_color))
    el.extend(build_section3(data, styles, accent_color, title_color))
    el.extend(build_section4(data, styles, accent_color))
    el.extend(build_section5(data, styles, accent_color))
    el.extend(build_section6(data, styles, accent_color))

    doc.build(el, onFirstPage=on_first, onLaterPages=on_later)

    # Cleanup temp charts
    for p in [radar_path, market_chart_path]:
        try:
            if p: os.remove(p)
        except Exception:
            pass
    return output_path


def main():
    import argparse
    parser = argparse.ArgumentParser(description='Generate Business Analysis Report PDF')
    parser.add_argument('--output', required=True, help='Output PDF path')
    parser.add_argument('--data', required=True, help='JSON data file path')
    parser.add_argument('--lang', default='en', help='ISO 639-1 language code')
    args = parser.parse_args()
    with open(args.data, 'r', encoding='utf-8') as f:
        data = json.load(f)
    data['lang'] = args.lang
    result = generate_report(args.output, data)
    size = os.path.getsize(result)
    print(f"OK: {result} ({size:,} bytes)")
    return 0

if __name__ == '__main__':
    sys.exit(main())
