---
name: global-business-analysis
description: "Generate professional PDF business analysis reports for any company in any country. Supports 20+ country configs with themed colors, multi-language output, live market data fetching, and multiple analysis frameworks (SWOT, PESTEL, Porter's 5). Use when user provides a company website URL and asks for business analysis, competitor research, market report, industry analysis, or due diligence report. Triggers: 'analyze this company', URL with country name, 'market research for', 'competitor analysis', 'business due diligence'."
---

# Global Business Analysis Report Generator

Professional, data-driven business analysis reports in PDF format.
Supports any industry, any country, any language.

## Overview

End-to-end workflow: Company URL + Country → Multi-source Research → Analysis Frameworks → Professional PDF → Desktop

Core capabilities:
- **Universal**: Works for any industry (manufacturing, SaaS, retail, services, etc.)
- **Multi-language**: Report written in the client's local language (EN/ES/DE/FR/PT/NL/ZH/JA/KO/AR/etc.)
- **Data-driven**: Pulls live market data, financials, news, and sentiment
- **Framework-agnostic**: SWOT, PESTEL, Porter's 5 Forces, Competitor Scorecard
- **Professional output**: 15-40 page PDF with charts, tables, executive summary

---

## Trigger Phrases

Use this skill when the user provides ANY of the following:
- A company website URL: `www.example.com`, `https://example.com`
- A company name + request: `Analyze Tesla`, `Market research for Unilever`
- Keywords: `business analysis`, `competitor analysis`, `market report`, `due diligence`, `industry analysis`
- Combined with country: `www.example.de germany`, `分析这家中国公司`

---

## Complete Workflow

### Phase 1: Intake & Configuration (1-2 min)

1. **Extract inputs**: company URL (required), country (infer or ask), industry (infer from URL)
2. **Load country config**: read `references/country-configs.md` → get language, colors, market sources, currency
3. **Set output path**: `C:\Users\alex\Desktop\[CompanyName]_Business_Analysis.pdf`

### Phase 2: Multi-Source Research (5-10 min)

Execute ALL of the following research steps. Do NOT skip any.

**A. Company Intelligence (WebFetch primary)**
- Fetch the client website homepage → extract: About/Team, Products/Services, Pricing, Contact, Careers, News
- Fetch `/about`, `/about-us`, `/team`, `/careers` pages if accessible
- Fetch LinkedIn company profile via WebSearch: `"[company name]" site:linkedin.com/company`

**B. Live Market Data (WebSearch + WebFetch)**
- Search: `"[industry]" market size [country] 2024 2025`
- Search: `"[industry]" market growth rate [country]`
- Search: `"[industry]" market forecast 2025 2030`
- Fetch: Statista, IBISWorld, Grand View Research, Mckinsey, Deloitte (free summaries)
- For publicly traded companies: search `"[company name]" revenue 2024 financial results`

**C. Competitor Identification & Scoring**
- Search: `"[company name]" competitors`, `"top [industry] companies [country]"`
- Identify TOP 4-6 competitors
- For each competitor: WebFetch their website → score on 12 dimensions (see below)
- Create competitive positioning matrix

**D. News & Sentiment (last 90 days)**
- Search: `"[company name]" news 2025`, `"[company name]" press release`
- Search: `"[industry]" trends 2025 [country]`
- Assess: positive/negative sentiment, recent milestones, controversies

**E. Regulatory & Macro Environment**
- Search: `"[industry]" regulation [country] 2024 2025`
- Search: `"[industry]" PESTEL [country]`
- Identify: upcoming regulatory changes, compliance requirements

### Phase 3: Analysis & Synthesis

Apply these frameworks (use the ones most relevant to the context):

| Framework | When to Use |
|----------|-------------|
| SWOT | Always — internal strengths/weaknesses + external opportunities/threats |
| PESTEL | Always — Political, Economic, Social, Tech, Environmental, Legal |
| Porter's 5 Forces | Competitive landscape deep-dive |
| Competitor Scorecard | Always — 12-dimension scored comparison |
| Value Chain | If analyzing operational efficiency |
| Growth-Share Matrix | If company has multiple products/divisions |

### Phase 4: Generate PDF Report

1. Assemble all research into structured JSON data file
2. Run `scripts/generate_report.py` with the JSON data file
3. Script generates professional PDF with:
   - Custom cover (country-themed colors)
   - Executive dashboard (key metrics vizualization)
   - SWOT matrix visual
   - Competitor radar chart (matplotlib)
   - PESTEL analysis table
   - All 6 sections with styled tables
   - Charts embedded (market size growth, competitive position)
   - Professional headers/footers with page numbers
4. Verify: file exists + file size > 15KB
5. Deliver via `open_result_view`

---

## Report Structure (6 Sections)

1. **Executive Summary** — Key findings, critical insights, top 3 recommendations (1-page dashboard)
2. **Company Analysis** — Business model, products/services, financial overview, website UX, SWOT
3. **Market & Industry Analysis** — Market size, growth, trends, PESTEL, regulatory, customer segments
4. **Competitive Landscape** — Top competitors, 12-dimension scorecard, positioning map, competitive gaps
5. **Strategic Recommendations** — Short-term (0-6 mo), Medium-term (6-18 mo), Long-term (18-36 mo), with KPIs
6. **Growth & Optimization** — Digital transformation, marketing, partnerships, M&A considerations, risk mitigation

---

## Competitor Scoring Framework (12 Dimensions × 8.33 pts = 100 max)

| # | Dimension | Weight | What to Evaluate |
|---|-----------|--------|-----------------|
| 1 | Product/Service Quality | High | Durability, performance, reliability, feature completeness |
| 2 | Price Competitiveness | High | Value vs market average, pricing model, discounting |
| 3 | Brand Recognition | Medium | Market awareness, reputation, awards, thought leadership |
| 4 | Customer Service | High | Responsiveness, support quality, NPS, satisfaction scores |
| 5 | Distribution & Reach | Medium | Channels, geography, partner network, availability |
| 6 | Digital Presence | High | SEO rank, social media, content quality, web traffic |
| 7 | Innovation & R&D | Medium | New products, tech adoption, patents, speed to market |
| 8 | Financial Strength | High | Revenue, growth, profitability, cash flow, funding |
| 9 | Customer Retention | Medium | Loyalty programs, repeat rate, churn, LTV |
| 10 | Operational Excellence | Medium | Supply chain, efficiency, scalability, automation |
| 11 | ESG & Compliance | Low-Medium | Environmental, social, governance, regulatory compliance |
| 12 | Value-added Services | Low-Medium | Training, consulting, warranties, ecosystem |

Score each dimension: 1-10 points (10 = best-in-class)
Total score = sum of all dimensions (max 120, normalized to 100)

---

## Language & Localization

| Rule | Detail |
|------|--------|
| Report language | MUST match client's primary business language |
| Country → Language | See `references/country-configs.md` |
| Multilingual countries | Use the most widely spoken official business language |
| Currency | Use local currency for financial data; USD for global context |
| Date format | Use local convention (MM/DD/YYYY us, DD/MM/YYYY = most others) |
| PDF fonts | Helvetica (Western), plus `references/font-mapping.md` for CJK |

---

## Data Freshness Protocol

Market data rot is real. Follow these rules:

1. **Always include data timestamp** in the report ("Market data as of: May 2026")
2. **Prefer sources < 12 months old**; flag anything older
3. **Re-fetch before each report**: never reuse market data from memory
4. **Use multiple sources** for market size (triangulate)
5. **Flag uncertain data**: add "(estimated)" or "(projected)" where appropriate
6. **Update country configs**: when new market data sources emerge, update `references/country-configs.md`

---

## PDF Generation

### Script Usage

```bash
python scripts/generate_report.py \
  --output "C:\Users\alex\Desktop\Report.pdf" \
  --data "report_data.json" \
  --lang "en"
```

### JSON Data Schema

See `scripts/generate_report.py` header for full JSON schema (lines 10-100).
Key sections: `executive_dashboard`, `swot`, `pestel`, `competitors`, `frameworks`, `recommendations`.

### HTML Escaping (Critical)

reportlab's XML parser is strict. Always escape:
- `"` → `&ldquo;` or `&rdquo;`
- `'` → `&rsquo;`
- `&` → `&amp;`
- `<` → `&lt;`  |  `>` → `&gt;`

### Chart Generation

The script auto-generates charts via matplotlib (if installed):
- Competitor radar chart (requires `matplotlib`)
- Market growth line chart (requires `matplotlib`)
- SWOT matrix visual

If matplotlib is not available, the script falls back to styled tables.

Install: `pip install matplotlib reportlab`

---

## Quality Standards

| Standard | Requirement |
|-----------|-------------|
| Length | Minimum 15 pages (compact) to 35 pages (comprehensive) |
| Competitors | Minimum 3, prefer 5-6 with full scorecards |
| Data sources | Minimum 5 distinct sources; always cite |
| Frameworks | Minimum: SWOT + Competitor Scorecard; prefer all 3 |
| Charts | Minimum 2 visualizations (competitor radar + 1 market chart) |
| Recommendations | Must be specific, actionable, with timelines and KPIs |
| Language | Native-level quality; no machine-translation artifacts |
| Review | 2 rounds of self-review before delivery |

---

## Error Handling

| Problem | Solution |
|---------|-----------|
| Website unresponsive | Use LinkedIn, news, Wayback Machine, crunchbase |
| Country not in config | Infer language → use generic theme → add to config post-report |
| No market data found | Use proxy industries, global data, expert estimates; flag clearly |
| Competitor data scarce | Use review sites (G2, Capterra, Trustpilot), news mentions |
| PDF generation fails | Check JSON schema, validate all strings are escaped |
| Font missing for language | See `references/font-mapping.md` for fallback chain |

---

## Customization

Users can customize reports by requesting:
- **Focus area**: "Focus on digital transformation opportunities"
- **Depth**: "Quick 5-page summary" vs "Full 40-page analysis"
- **Framework preference**: "Include Porter's 5 Forces analysis"
- **Output format**: PDF (default), Word (use `docx` skill), PowerPoint (use `pptx` skill)
