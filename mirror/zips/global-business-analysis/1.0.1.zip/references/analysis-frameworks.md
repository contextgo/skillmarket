# Analysis Frameworks Reference

Copy-paste these templates into the research workflow.
Each framework produces structured data that feeds into the PDF report JSON.

---

## SWOT Analysis

Use ALWAYS. Fills `data['swot']` in the JSON.

```json
"swot": {
    "strengths": ["S1", "S2", "S3"],
    "weaknesses": ["W1", "W2", "W3"],
    "opportunities": ["01", "02", "03"],
    "threats": ["T1", "T2", "T3"]
}
```

**How to fill each quadrant:**

| Quadrant | Internal/External | What to Capture |
|-----------|-------------------|-------------------|
| Strengths | Internal | What the company does better than competitors (IP, brand, team, cash) |
| Weaknesses | Internal | What competitors do better (tech debt,geographic gap, funding) |
| Opportunities | External | Market trends the company can capitalize on (regulation, tech shift) |
| Threats | External | External risks (new entrants, regulation, macro headwinds) |

**Pro tip:** Cross-check SWOT items against competitor scorecard. If a "strength" is also a competitor's strength, it's table stakes, not a differentiator.

---

## PESTEL Analysis

Use ALWAYS for sections 2 and 3. Fills `data['pestel']`.

```json
"pestel": {
    "political": ["P1", "P2"],
    "economic": ["E1", "E2"],
    "social": ["S1", "S2"],
    "technological": ["T1", "T2"],
    "environmental": ["E1", "E2"],
    "legal": ["L1", "L2"]
}
```

| Dimension | Key Questions to Research |
|-----------|----------------------------|
| Political | Elections, trade policy, tariffs, subsidies, sanctions |
| Economic | Interest rates, FX, inflation, consumer spending, GDP growth |
| Social | Demographics, cultural shifts, lifestyle changes, remote work |
| Technological | AI adoption, automation, digital transformation, R&D spend |
| Environmental | Carbon regulations, ESG mandates, supply chain sustainability |
| Legal | Data privacy (GDPR, CCPA), labor laws, IP enforcement, M&A regulation |

---

## Porter's 5 Forces

Use for deep competitive landscape analysis. Fills `data['section3']['porters_five']`.

```json
"porters_five": {
    "new_entrants": "Low/Medium/High + 1-sentence rationale",
    "buyer_power": "Low/Medium/High + rationale",
    "supplier_power": "Low/Medium/High + rationale",
    "substitutes": "Low/Medium/High + rationale",
    "rivalry": "Low/Medium/High + rationale"
}
```

| Force | What to Evaluate |
|-------|-------------------|
| Threat of New Entrants | Barriers to entry: capital, regulation, network effects, IP moat |
| Bargaining Power of Buyers | Customer concentration, switching costs, price sensitivity |
| Bargaining Power of Suppliers | Supplier concentration, uniqueness of inputs, forward integration risk |
| Threat of Substitutes | Alternative solutions, price-performance tradeoff |
| Competitive Rivalry | Number of competitors, industry growth rate, exit barriers, differentiation |

---

## Value Chain Analysis

Use when analyzing operational efficiency or cost structure. Dies NOT go into the standard 6-section report but can inform Section 5 (Recommendations).

**Primary activities to evaluate:**
- Inbound logistics
- Operations / manufacturing
- Outbound logistics
- Marketing & sales
- Service & support

**Support activities to evaluate:**
- Firm infrastructure (finance, legal, quality)
- HR management
- Technology development (R&D, IT)
- Procurement

**Output format:** Paragraph in Section 5 recommendations: "Value chain analysis reveals [bottleneck] as the highest-ROI improvement target..."

---

## Growth-Share Matrix (BCG)

Use when the client has multiple products / business units. Fills `data['section4']['bcg_matrix']`.

```
Stars (High share, High growth) → Invest
Cash Cows (High share, Low growth) → Harvest
Question Marks (Low share, High growth) → Invest or Divest
Dogs (Low share, Low growth) → Divest
```

---

## OKR Framework for Recommendations

When writing Section 5 (Strategic Recommendations), phrase each recommendation as an OKR:

```
Objective: [What we want to achieve - qualitative]
Key Result 1: [Metric] from X to Y by [date]
Key Result 2: [Metric] from X to Y by [date]
Key Result 3: [Metric] from X to Y by [date]
```

This makes recommendations measurable and time-bound.

---

## Using Frameworks Together

For a comprehensive report, layer them:

```
PESTEL → Market opportunity / threat sizing
       ↓
SWOT → Internal alignment with external reality
       ↓
Porter's 5 → Competitive strategy formulation
       ↓
OKRs → Actionable recommendation with KPIs
```

Example cascade:
- PESTEL says: "AI adoption in [industry] accelerating (tech dimension)"
- SWOT says: "Company has strong data science team (strength)"
- Porter's says: "Low threat of substitutes because proprietary data moat"
- Recommendation OKR: "Launch AI-powered feature set by Q3 → increase ARPU by 25%"
