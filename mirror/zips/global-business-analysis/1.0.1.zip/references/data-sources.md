# Live Data Sources Reference

ALWAYS prefer sources < 12 months old.
When a source goes stale (> 24 months), remove it and find a replacement.
To update this file: add new sources at the top of each section with the discovery date.

---

## Free Market Size APIs / Datasets

| Source | Coverage | Free Tier | Update Frequency | API? |
|--------|----------|----------|-----------------|------|
| World Bank Open Data | Global, macro | Full | Quarterly | ✅ REST |
| IMF Data | Global, macro | Full | Monthly | ✅ |
| UN Comtrade | Global trade | Full | Monthly | ✅ |
| OECD Data | Developed markets | Full | Varies | ✅ |
| Eurostat | EU only | Full | Monthly | ✅ |
| Statista (summary) | Global | 1 chart/day | Daily | ❌ Web only |
| IBISWorld (summary) | US/UK/AU | 1 report preview | N/A | ❌ |
| McKinsey Insights | Global | Full articles | Weekly | ❌ |
| Deloitte Insights | Global | Full articles | Weekly | ❌ |
| Google Trends | Global | Full | Real-time | ✅ |

---

## Company Financial Data (Public Companies)

| Source | What You Get | Free? | Notes |
|--------|---------------|-------|-------|
| SEC EDGAR (US) | 10-K, 10-Q, 8-K filings | ✅ Full | Use: `https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=[CIK]` |
| Companies House (UK) | Accounts, officers, PSC | ✅ Full | `https://find-and-update.company-information.service.gov.uk/` |
| AnnualReports.com | PDF annual reports | ✅ Full | Good for non-US/UK markets |
| Yahoo Finance | Stock price, basic financials | ✅ Full | Via `yfinance` Python pkg |
| Crunchbase | Funding rounds, headcount, founded | ⚠️ Partial | WebFetch / WebSearch |
| LinkedIn Company Page | Headcount, description, updates | ⚠️ Partial | WebFetch |
| Glassdoor | Employee count, salary, culture | ⚠️ Partial | WebSearch |

---

## News & Sentiment (Free / Low-Cost)

| Source | Use For | Access |
|--------|---------|--------|
| Google News RSS | Recent news (last 30 days) | `https://news.google.com/rss/search?q=[query]` |
| Bing News Search | Recent news + sentiment | WebSearch (free) |
| Hacker News API | Tech industry news | ✅ `https://hn.algolia.com/api` |
| Reddit (via WebSearch) | Community sentiment | WebSearch |
| Trustpilot | Customer reviews | WebFetch company page |
| G2 / Capterra | B2B software reviews | WebFetch |
| Wayback Machine | Historical website snapshots | `https://web.archive.org/web/*/[url]` |

---

## Industry-Specific Data Sources

### Technology / SaaS
- **Gartner** (summaries free via WebSearch): "[product] Gartner Magic Quadrant 2024"
- **G2 Crowd**: B2B software reviews → WebFetch `https://www.g2.com/products/[product]`
- **Stacklytics**: Technology adoption trends → WebSearch

### Retail / E-commerce
- **Nielsen IQ** (summaries via WebSearch)
- **McKinsey Retail Practice** (free articles)
- **Amazon Best Sellers** (category trends) → WebFetch

### Manufacturing / Industrial
- **UNIDO Statistics**: Industrial production indices
- **National statistical offices** (see country-configs.md)

### Financial Services
- **Central bank websites** (see country-configs.md for URLs)
- **Basel Committee publications** (regulatory trends)

### Healthcare / Pharma
- **WHO Data**: Global health metrics
- **FDA (US) / EMA (EU)**: Drug approval timelines
- **PubMed**: Research trend analysis

---

## WebFetch Strategy for Market Data

Many market research firms (Statista, IBISWorld) block bots. Use this fallback chain:

```
1. Try WebFetch on Statista summary page → if 403/redirected, go to 2
2. WebSearch: "[metric] [year] [source]" → look for press releases, news
3. WebSearch: "site:statista.com [metric] [year]" → sometimes shows snippet
4. Use proxy: World Bank / IMF / OECD (always open)
5. Use的新闻报道: Search "[industry] market size [country] [year] press release"
```

---

## Data Timestamp Convention

Record data age in the report. Use this format in JSON `market_data`:

```json
{"metric": "Market Size", "value": "$4.72B", "source": "Statista", "date": "2025-03", "freshness": "fresh"}
```

Freshness values: `fresh` (< 6 mo), `stale` (6-18 mo), `very-stale` (> 18 mo).
Flag `stale` and `very-stale` data in the report with ⚠️.

---

## Updating This File

When you discover a new reliable data source:
1. Add it to the relevant section above
2. Note the date discovered
3. Test it with WebFetch to confirm it's still accessible
4. Remove sources that return 404/403 consistently

Check this file quarterly. Sources rot — keep it alive.
