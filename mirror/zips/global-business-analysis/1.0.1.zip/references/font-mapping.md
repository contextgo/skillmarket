# Font Mapping Reference

reportlab's default `Helvetica` supports Latin-1 and most CE scripts.
For non-Latin languages, you must register system fonts.

---

## Supported Out-of-the-Box (Helvetica)

| Language | Code | Helvetica OK? | Notes |
|-----------|------|---------------|-------|
| English | `en` | ✅ | Full support |
| Spanish | `es` | ✅ | ñ, áéíóú, ¿¡ |
| French | `fr` | ✅ | ç, àâëîôù, œæ |
| German | `de` | ✅ | ß, äöü |
| Italian | `it` | ✅ | àèéìíîîòóùú |
| Portuguese | `pt` | ✅ | áâãçéêíóôõú |
| Dutch | `nl` | ✅ | ëïóöú |
| Czech | `cs` | ✅ | ščřžýáíéúůďťň |
| Polish | `pl` | ✅ | ąćęłńóśźż |
| Scandinavian | `sv`/`no`/`da` | ✅ | åäö øæ |
| Russian | `ru` | ❌ | Cyrilic — needs DejaVu |
| Arabic | `ar` | ❌ | RTL — needs Amiri |
| Chinese | `zh` | ❌ | CJK — needs bundled font |
| Japanese | `ja` | ❌ | CJK — needs bundled font |
| Korean | `ko` | ❌ | CJK — needs bundled font |

---

## How to Add a Font

### Step 1: Find a .ttf on the System

Windows typically has:
```
C:\Windows\Fonts\
  - simhei.ttf (Chinese, sans-serif)
  - simsun.ttc (Chinese, serif)
  - msgothic.ttc (Japanese)
  - malgun.ttf (Korean)
  - arial.ttf (Western fallback)
  - trebuc.ttf (Western alternative)
```

### Step 2: Register in `generate_report.py`

Add at the top (after the other imports):

```python
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

# Cal this once at startup
def register_fonts():
    try:
        pdfmetrics.registerFont(TTFont('SimHei', r'C:\Windows\Fonts\simhei.ttf'))
        pdfmetrics.registerFont(TTFont('MSMincho', r'C:\Windows\Fonts\msgothic.ttc,0'))
        return True
    except Exception:
        return False
```

### Step 3: Use the Registered Font

In `create_styles()`, add a `font_name` parameter:

```python
def create_styles(title_color, font_name='Helvetica'):
    # ... in each ParagraphStyle:
    styles['body'] = ParagraphStyle(..., fontName=font_name)
```

### Step 4: Pass the Font Name from JSON

In the JSON input, add:
```json
{"report_font": "SimHei", "fallback_font": "Helvetica"}
```

---

## Common Font Pairs by Language

| Language | Primary Font | Register As | Fallback |
|-----------|---------------|--------------|-----------|
| Chinese (Simplified) | `simhei.ttf` | `SimHei` | Helvetica |
| Chinese (Traditional) | `mingliu.ttc` | `MingLiu` | Helvetica |
| Japanese | `msgothic.ttc` | `MSGothic` | Helvetica |
| Korean | `malgun.ttf` | `Malgun` | Helvetica |
| Russian/Cyrilic | `arial.ttf` | `Arial` | Helvetica |
| Arabic (RTL)* | `amiri.ttf` (download) | `Amiri` | Helvetica |

*RTL (right-to-left) text in reportlab is experimental; for Arabic/Hebrew,
 consider generating the report in English and noting the native version
 would need specialized tooling.

---

## Quick Diagnostic

To check what fonts are available on the current system:

```python
from reportlab.pdfbase.pdfmetrics import getRegisteredFontNames
print(getRegisteredFontNames())  # shows what's loaded

import os
fonts_dir = r'C:\Windows\Fonts'
print([f for f in os.listdir(fonts_dir) if f.endswith('.ttf')][:20])
```

---

## For the Skill User

If the report language needs a non-Latin font:
1. Open `scripts/generate_report.py`
2. Follow "How to Add a Font" above
3. Update `references/font-mapping.md` with the new font entry
4. Re-package the skill

The skill does NOT bundle font files (licensing). Users must have
the font installed on their system, or provide a path to a licensed .ttf.
