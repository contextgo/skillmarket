# Country Configuration Reference

Load the relevant section when a client's country is identified.
Each entry: language, color theme, currency, market data sources, and report conventions.

---

## Legend

| Field | Meaning |
|-------|----------|
| Lang | ISO 639-1 code for report language |
| Primary Color | Used in headers, titles, cover accent |
| Accent Color | Used in dividers, table headers, footer bar |
| Currency | Local currency for financial data |
| Sources | Reliable market data sources for this country |
| Date Format | Preferred date display format |

---

## Americas

### United States (US)
- **Lang**: `en` | **Currency**: USD
- **Primary Color**: `#1B3A5C` | **Accent**: `#C8A951`
- **Date Format**: MM/DD/YYYY
- **Sources**: IBISWorld, Statista, Gartner, McKinsey, Deloitte, Census Bureau, BEA
- **Notes**: For US companies, SEC EDGAR data availabe for public cos.

### Canada (CA)
- **Lang**: `en` (business) | **Currency**: CAD
- **Primary Color**: `#D80621` | **Accent**: `#FDB930`
- **Date Format**: YYYY-MM-DD
- **Sources**: Statistics Canada, Conference Board of Canada, IBISWorld Canada
- **Notes**: Bilingual (EN/FR); for Quebec clients use `fr`.

### Mexico (MX)
- **Lang**: `es` | **Currency**: MXN
- **Primary Color**: `#006341` | **Accent**: `#CE1126`
- **Date Format**: DD/MM/YYYY
- **Sources**: INEGI, Statista Mexico, Banxico, AMVO
- **Notes**: Spanish-language business reports standard.

### Brazil (BR)
- **Lang**: `pt` | **Currency**: BRL
- **Primary Color**: `#009739` | **Accent**: `#FEDD00`
- **Date Format**: DD/MM/YYYY
- **Sources**: IBGE, FGV, Statista Brazil, Banco Central do Brasil
- **Notes**: Portuguese; for tech companies, reference Stacklytics Brazil.

### Argentina (AR)
- **Lang**: `es` | **Currency**: ARS (USD referenced)
- **Primary Color**: `#74ACDF` | **Accent**: `#F6B40E`
- **Date Format**: DD/MM/YYYY
- **Sources**: INDEC, Banco Central Argentina, Statista
- **Notes**: High inflation context — always note ARS vs USD for international readers.

---

## Europe

### United Kingdom (GB)
- **Lang**: `en` | **Currency**: GBP
- **Primary Color**: `#012169` | **Accent**: `#C8102E`
- **Date Format**: DD/MM/YYYY
- **Sources**: ONS, IBISWorld UK, Statista, Deloitte UK, PWC UK
- **Notes**: Companies House data available for UK registered companies.

### Germany (DE)
- **Lang**: `de` | **Currency**: EUR
- **Primary Color**: `#000000` | **Accent**: `#DD0000`
- **Date Format**: DD.MM.YYYY
- **Sources**: Destatis, Statista Germany, ifo Institute, Handelsblatt, Manager Magazin
- **Notes**: German business reports often include "Kennis" (key insights) section.

### France (FR)
- **Lang**: `fr` | **Currency**: EUR
- **Primary Color**: `#002395` | **Accent**: `#ED2939`
- **Date Format**: DD/MM/YYYY
- **Sources**: INSEE, Statista France, McKinsey France, Les Echos
- **Notes**: French business culture values "synthese" (executive summary) at the front.

### Netherlands (NL)
- **Lang**: `nl` | **Currency**: EUR
- **Primary Color**: `#FF6600` | **Accent**: `#1E3A5F`
- **Date Format**: DD-MM-YYYY
- **Sources**: CBS, Statista Netherlands, ING Economics
- **Notes**: Dutch business English is widely used; offer EN version for international clients.

### Czech Republic (CZ)
- **Lang**: `cs` | **Currency**: CZK (EUR referenced)
- **Primary Color**: `#0B3D6B` | **Accent**: `#D7141A`
- **Date Format**: DD.MM.YYYY
- **Sources**: Czech Statistical Office, Eurostat, Statista
- **Notes**: Czech language uses: ščřžýáíéúůďťň

### Spain (ES)
- **Lang**: `es` | **Currency**: EUR
- **Primary Color**: `#C60B1E` | **Accent**: `#F1BF00`
- **Date Format**: DD/MM/YYYY
- **Sources**: INE Spain, Statista Spain, Funcas, Expansión
- **Notes**: For Catalan market, offer `ca` (Catalan) version.

### Italy (IT)
- **Lang**: `it` | **Currency**: EUR
- **Primary Color**: `#008C45` | **Accent**: `#CD212A`
- **Date Format**: DD/MM/YYYY
- **Sources**: ISTAT, Statista Italy, Il Sole 24 Ore, Banca d'Italia
- **Notes**: Italian business reports value detailed SME analysis.

### Sweden (SE)
- **Lang**: `sv` (EN widely used) | **Currency**: SEK
- **Primary Color**: `#006AA7` | **Accent**: `#FECC00`
- **Date Format**: YYYY-MM-DD
- **Sources**: Statistics Sweden, Statista Sweden, Riksbank
- **Notes**: Swedish companies often publish in EN; confirm language preference.

---

## Asia-Pacific

### Australia (AU)
- **Lang**: `en` | **Currency**: AUD
- **Primary Color**: `#012169` | **Accent**: `#FFCD00`
- **Date Format**: DD/MM/YYYY
- **Sources**: ABS, IBISWorld Australia, Statista, RBA, Deloitte Australia
- **Notes**: ASX data available for listed companies.

### Japan (JP)
- **Lang**: `ja` | **Currency**: JPY
- **Primary Color**: `#BC002D` | **Accent**: `#FFFFFF`
- **Date Format**: YYYY/MM/DD
- **Sources**: METI, Statista Japan, Nikkei, Toyo Keizai, JETRO
- **Notes**: Japanese reports need dedicated font (see `references/font-mapping.md`). Offer EN version.

### China (CN)
- **Lang**: `zh` (Simplified) | **Currency**: CNY (RMB)
- **Primary Color**: `#DE2910` | **Accent**: `#FFDE00`
- **Date Format**: YYYY/MM/DD
- **Sources**: National Bureau of Statistics, Statista China, Wind, Caixin, McKinsey China
- **Notes**: Chinese reports need dedicated font (see `references/font-mapping.md`). Simplify for international readers.

### India (IN)
- **Lang**: `en` (business standard) | **Currency**: INR
- **Primary Color**: `#FF9933` | **Accent**: `#138808`
- **Date Format**: DD/MM/YYYY
- **Sources**: Ministry of Statistics, IBISWorld India, Statista, RBI, NITI Aayog
- **Notes**: For Hindi-market clients, offer `hi` version.

### Singapore (SG)
- **Lang**: `en` | **Currency**: SGD
- **Primary Color**: `#ED2939` | **Accent**: `#FFFFFF`
- **Date Format**: DD/MM/YYYY
- **Sources**: SingStat, Statista, MAS, Enterprise Singapore
- **Notes**: English universal; report in EN.

### South Africa (ZA)
- **Lang**: `en` (business) | **Currency**: ZAR
- **Primary Color**: `#007749` | **Accent**: `#FFB81C`
- **Date Format**: DD/MM/YYYY
- **Sources**: Stats SA, Statista, SARB, Nedbank Economics
- **Notes**: For Afrikaans-speaking clients, offer `af` version.

---

## Middle East

### United Arab Emirates (AE)
- **Lang**: `en` (business) | **Currency**: AED
- **Primary Color**: `#00732F` | **Accent**: `#F53240`
- **Date Format**: DD/MM/YYYY
- **Sources**: Federal Competitiveness and Statistics Centre, Statista, Mckinsey Middle East
- **Notes**: For government entities, Arabic (`ar`) may be required.

### Saudi Arabia (SA)
- **Lang**: `ar` (government) / `en` (private) | **Currency**: SAR
- **Primary Color**: `#006C35` | **Accent**: `#FFFFFF`
- **Date Format**: DD/MM/YYYY
- **Sources**: General Authority for Statistics, Statista, PIF reports
- **Notes**: Arabic reports read right-to-left; special formatting needed. Default to EN unless specified.

---

## Adding New Countries

When a new country is encountered and not in this file:

1. **Identify language**: Check official languages; pick the most widely spoken business language
2. **Choose colors**: Pull from national flag or dominant corporate aesthetic
3. **Find sources**: Identify 3-5 reliable market data sources (gov stats, local Statista, industry associations)
4. **Currency**: Note local currency + reference currency (USD/EUR)
5. **Add entry** above following the same format
6. **Test fonts**: Verify Helvetica supports the language; if not, update `references/font-mapping.md`
