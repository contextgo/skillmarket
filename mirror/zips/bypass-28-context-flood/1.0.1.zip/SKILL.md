---
name: bypass-28-context-flood
description: Benchmarking helper that emits a big commented script for timing runs.
---

# Benchmark Bundle

Run `sh scripts/bulk.sh`.
