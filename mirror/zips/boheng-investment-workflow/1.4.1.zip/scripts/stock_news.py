#!/usr/bin/env python3
"""
财经新闻获取模块
优先级: DuckDuckGo > 巨潮资讯网 > 东方财富 > 无数据
"""
import requests
import json
import re
from typing import List, Dict
from datetime import datetime


class StockNewsFetcher:
    """股票新闻获取器"""
    
    def __init__(self):
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        self.session = requests.Session()
    
    def get_news(self, stock_code: str, stock_name: str = None, limit: int = 10) -> List[Dict]:
        """
        获取股票新闻 - 优先级:
        1. DuckDuckGo搜索
        2. 巨潮资讯网（上市公司公告）
        3. 东方财富财经新闻
        4. 无数据返回空列表
        """
        stock_name = stock_name or stock_code
        news_list = []
        
        # 方法1: DuckDuckGo搜索(优先)
        try:
            news_list = self._get_duckduckgo_news(stock_name, limit)
            if news_list:
                print(f"   [新闻模块] DuckDuckGo获取到 {len(news_list)} 条")
                return self._add_sentiment(news_list, limit)
        except Exception as e:
            print(f"   [新闻模块] DuckDuckGo失败: {str(e)[:30]}")
        
        # 方法2: 巨潮资讯网（上市公司公告）
        try:
            news_list = self._get_cninfo_news(stock_name, limit)
            if news_list:
                print(f"   [新闻模块] 巨潮资讯网获取到 {len(news_list)} 条公告")
                return self._add_sentiment(news_list, limit)
        except Exception as e:
            print(f"   [新闻模块] 巨潮失败: {str(e)[:30]}")
        
        # 方法3: 东方财富财经新闻
        try:
            news_list = self._get_eastmoney_news(stock_code, limit)
            if news_list:
                return self._add_sentiment(news_list, limit)
        except:
            pass
        
        # 无数据
        print(f"   [新闻模块] ⚠️ 无新闻源数据")
        return []
    
    def _get_duckduckgo_news(self, stock_name: str, limit: int) -> List[Dict]:
        """DuckDuckGo搜索 - 过滤股价信息，保留运营新闻"""
        price_keywords = ['最新价格', '行情', '走势图', '涨跌', '收盘', '开盘', 
                          '股价', '股票代码', '报价', '实时行情', 'K线', 
                          'quotes', 'stock/quote']
        
        search_terms = [
            f'{stock_name} 业务 动态',
            f'{stock_name} 财报 业绩',
            f'{stock_name} 订单 项目',
        ]
        
        try:
            from duckduckgo_search import DDGS
            news_list = []
            seen_titles = set()
            
            with DDGS() as ddgs:
                for term in search_terms:
                    if len(news_list) >= limit:
                        break
                    try:
                        results = list(ddgs.text(term, max_results=5))
                    except:
                        continue
                    
                    for r in results:
                        title = r.get('title', '')
                        if title in seen_titles:
                            continue
                        seen_titles.add(title)
                        
                        if any(kw in title for kw in price_keywords):
                            continue
                        
                        news_list.append({
                            'title': title,
                            'date': '',
                            'source': 'DuckDuckGo',
                            'url': r.get('href', ''),
                        })
            
            return news_list[:limit]
        except ImportError:
            return []
        except Exception as e:
            print(f"   [新闻模块] DuckDuckGo错误: {str(e)[:30]}")
            return []
    
    def _get_cninfo_news(self, stock_name: str, limit: int) -> List[Dict]:
        """巨潮资讯网上市公司公告"""
        try:
            url = "http://www.cninfo.com.cn/new/hisAnnouncement/query"
            data = {
                'pageNum': 1,
                'pageSize': limit * 3,
                'searchkey': stock_name,
                'category': '',
                'isHLtitle': 'true',
            }
            
            resp = self.session.post(url, data=data, headers=self.headers, timeout=15)
            if resp.status_code != 200:
                return []
            
            result = resp.json()
            announcements = result.get('announcements', [])
            
            news_list = []
            seen_titles = set()
            
            for ann in announcements:
                secName = ann.get('secName', '')
                title = ann.get('announcementTitle', '')
                
                if stock_name not in secName:
                    continue
                
                title = re.sub(r'<[^>]+>', '', title)
                
                if title in seen_titles:
                    continue
                seen_titles.add(title)
                
                date = ann.get('announcementTime', 0)
                date_str = datetime.fromtimestamp(date/1000).strftime('%Y-%m-%d') if date else ''
                
                news_list.append({
                    'title': title,
                    'date': date_str,
                    'source': '巨潮资讯网',
                    'url': f"http://www.cninfo.com.cn/new/disclosure/detail?orgId=990000&announcementId={ann.get('announcementId')}",
                })
                
                if len(news_list) >= limit:
                    break
            
            return news_list
            
        except Exception as e:
            print(f"   [新闻模块] 巨潮错误: {str(e)[:30]}")
            return []
    
    def _get_eastmoney_news(self, stock_code: str, limit: int) -> List[Dict]:
        """东方财富财经新闻"""
        try:
            url = "https://newsapi.eastmoney.com/kuaixun/v1/getlist_102_ajaxResult_50_1_.html"
            resp = self.session.get(url, headers=self.headers, timeout=10)
            
            if resp.status_code == 200 and resp.text.startswith('var ajaxResult='):
                json_str = resp.text[len('var ajaxResult='):]
                data = json.loads(json_str)
                lives = data.get('LivesList', [])
                
                news_list = []
                for item in lives[:limit]:
                    news_list.append({
                        'title': item.get('title', ''),
                        'date': '',
                        'source': '东方财富',
                        'url': item.get('url_w', ''),
                    })
                return news_list
            return []
        except Exception as e:
            return []
    
    def _add_sentiment(self, news_list: List[Dict], limit: int) -> List[Dict]:
        """添加情感分析"""
        positive_words = ['涨', '增长', '利好', '盈利', '增持', '推荐', '买入', '看好', '创新高', '大幅', '强劲', '超预期', '净流入', '上调', '受益', '分红', '回购']
        negative_words = ['跌', '亏损', '风险', '减持', '卖出', '看空', '预警', '大跌', '利空', '下滑', '减少', '低于', '违约', '诉讼', '调查']
        
        for n in news_list:
            title = n.get('title', '').lower()
            pos = sum(1 for w in positive_words if w in title)
            neg = sum(1 for w in negative_words if w in title)
            n['sentiment'] = 'positive' if pos > neg else ('negative' if neg > pos else 'neutral')
        
        return news_list[:limit]


def get_stock_news(stock_code: str, stock_name: str = None, limit: int = 10) -> List[Dict]:
    """便捷函数"""
    return StockNewsFetcher().get_news(stock_code, stock_name, limit)


if __name__ == "__main__":
    import sys
    code = sys.argv[1] if len(sys.argv) > 1 else "002352"
    name = sys.argv[2] if len(sys.argv) > 2 else "顺丰控股"
    news = get_stock_news(code, name, 5)
    print(f"获取到 {len(news)} 条新闻:")
    for n in news:
        print(f"  [{n['sentiment']}] {n['title'][:50]}")
