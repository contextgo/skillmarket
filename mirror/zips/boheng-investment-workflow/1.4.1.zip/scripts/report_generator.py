#!/usr/bin/env python3
"""
投资研究系统 - 报告生成器
生成结构化的投资决策报告（含财务数据）
"""
from datetime import datetime
from typing import Dict, List
import os
import re

try:
    from config import REPORTS_DIR, VOTE_BUY, VOTE_CAUTION, VOTE_SELL
except ImportError:
    import sys
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from config import REPORTS_DIR, VOTE_BUY, VOTE_CAUTION, VOTE_SELL


def sanitize_filename(name: str) -> str:
    """
    清洗文件名，移除不安全字符
    仅保留字母、数字、中文、下划线
    """
    # 替换空格和其他不安全字符为下划线
    name = re.sub(r'[^\w\u4e00-\u9fff]', '_', name)
    # 移除连续的下划线
    name = re.sub(r'_+', '_', name)
    # 移除首尾的下划线
    name = name.strip('_')
    return name if name else "unknown"


def generate_report(
    code: str,
    name: str,
    quote: Dict,
    analyst_results: List[Dict],
    final_vote: str,
    final_score: float,
    financial: Dict = None
) -> str:
    """
    生成投资决策报告
    
    Args:
        code: 股票代码
        name: 股票名称
        quote: 行情数据
        analyst_results: 分析师结果
        final_vote: 最终投票
        final_score: 最终得分
        financial: 财务数据
        
    Returns:
        报告文本
    """
    lines = []
    
    # 标题
    lines.append("=" * 60)
    lines.append("        投资研究决策报告")
    lines.append("=" * 60)
    lines.append("")
    
    # 基本信息
    lines.append(f"【标的】：{code} {name}")
    lines.append(f"【研究时间】：{datetime.now().strftime('%Y-%m-%d %H:%M')}")
    
    if 'error' not in quote:
        price = quote.get('现价', 'N/A')
        change = quote.get('涨跌幅', 0)
        
        # 格式化价格
        if isinstance(price, (int, float)):
            price_str = f"¥{price:.2f}"
        else:
            price_str = str(price)
        
        # 格式化涨跌幅
        if isinstance(change, (int, float)):
            change_str = f"{change:+.2f}%"
        else:
            change_str = str(change)
        
        lines.append(f"【当前价格】：{price_str} ({change_str})")
        lines.append(f"【数据来源】：{quote.get('source', 'N/A')}")
        
        # 数据来源说明
        if financial and financial.get('data_source'):
            is_estimated = financial.get('is_estimated', True)
            source_note = "⚠️ 部分数据为估算值" if is_estimated else "✅ 数据来源于AKShare真实财报"
            lines.append(f"【财务数据】：{financial.get('data_source')} | {source_note}")
    
    lines.append("")
    
    # 财务数据概览
    if financial:
        lines.append("=" * 60)
        lines.append("        财务数据概览")
        lines.append("=" * 60)
        lines.append("")
        
        fi = financial.get('财务指标', {})
        is_estimated = financial.get('is_estimated', True)
        estimated_note = " (估算)" if is_estimated else ""
        
        if 'error' not in fi:
            lines.append("📊 盈利能力：")
            lines.append(f"   ROE: {fi.get('ROE', 0):.2f}%{estimated_note}  |  毛利率: {fi.get('毛利率', 0):.2f}%{estimated_note}  |  净利率: {fi.get('净利率', 0):.2f}%{estimated_note}")
            lines.append("")
            lines.append("📈 成长能力：")
            lines.append(f"   营收增速: {fi.get('营收增速', 0):.2f}%{estimated_note}  |  利润增速: {fi.get('利润增速', 0):.2f}%{estimated_note}")
            lines.append("")
            lines.append("💰 偿债能力：")
            lines.append(f"   资产负债率: {fi.get('资产负债率', 0):.2f}%  |  流动比率: {fi.get('流动比率', 0):.2f}")
            lines.append("")
        
        ev = financial.get('估值分位', {})
        valuation = financial.get('估值', {})
        if 'error' not in ev:
            lines.append("💎 估值指标：")
            lines.append(f"   PE: {ev.get('PE当前', 0)}倍 ({ev.get('PE分位', 0)}%分位)  |  PB: {ev.get('PB当前', 0)}倍")
            if 'error' not in valuation:
                lines.append(f"   股息率: {valuation.get('股息率', 0):.2f}%  |  估值评级: {ev.get('估值评级', '-')}")
            lines.append("")
        
        industry = financial.get('行业', {})
        if 'error' not in industry:
            lines.append("🏭 行业信息：")
            lines.append(f"   所属行业: {industry.get('行业', '-')}  |  行业涨跌幅: {industry.get('行业涨跌幅', 0):+.2f}%")
            lines.append(f"   行业景气度: {industry.get('行业景气度', '-')}")
            lines.append("")
    
    # 分析师投票结果
    lines.append("=" * 60)
    lines.append("        8位分析师投票结果")
    lines.append("=" * 60)
    lines.append("")
    
    for i, r in enumerate(analyst_results, 1):
        weight_mark = " ⭐" if r['weight'] >= 1.2 else ""
        lines.append(f"{i}. {r['name']} → {r['vote']} 建议 (权重 {r['weight']}x){weight_mark}")
        lines.append(f"   理由：{r['reason']}")
        lines.append("")
    
    # 投票统计
    lines.append("=" * 60)
    lines.append("            投票统计")
    lines.append("=" * 60)
    lines.append("")
    
    buy_count = sum(1 for r in analyst_results if r['vote'] == VOTE_BUY)
    caution_count = sum(1 for r in analyst_results if r['vote'] == VOTE_CAUTION)
    sell_count = sum(1 for r in analyst_results if r['vote'] == VOTE_SELL)
    
    buy_weight = sum(r['weight'] for r in analyst_results if r['vote'] == VOTE_BUY)
    caution_weight = sum(r['weight'] for r in analyst_results if r['vote'] == VOTE_CAUTION)
    sell_weight = sum(r['weight'] for r in analyst_results if r['vote'] == VOTE_SELL)
    
    lines.append(f"{VOTE_BUY} 建议投资：{buy_count}票 (加权得分: {buy_weight:.1f})")
    lines.append(f"{VOTE_CAUTION} 谨慎投资：{caution_count}票 (加权得分: {caution_weight:.1f})")
    lines.append(f"{VOTE_SELL} 不建议投资：{sell_count}票 (加权得分: {sell_weight:.1f})")
    lines.append("")
    
    # 最终结论
    lines.append("=" * 60)
    lines.append("            最终结论")
    lines.append("=" * 60)
    lines.append("")
    
    final_text = {
        VOTE_BUY: "✅ 建议投资",
        VOTE_CAUTION: "⚠️ 谨慎投资",
        VOTE_SELL: "❌ 不建议投资"
    }
    
    lines.append(f"最终建议：{final_text.get(final_vote, final_vote)}")
    lines.append("")
    
    # 综合建议
    lines.append("综合建议：")
    suggestions = _generate_suggestions(final_vote, quote, analyst_results, financial)
    for i, s in enumerate(suggestions, 1):
        lines.append(f"{i}. {s}")
    lines.append("")
    
    # 风险提示
    lines.append("风险提示：")
    risks = _extract_risks(analyst_results)
    for r in risks:
        lines.append(f"- {r}")
    
    lines.append("")
    lines.append("=" * 60)
    
    return "\n".join(lines)


def _generate_suggestions(
    final_vote: str,
    quote: Dict,
    analyst_results: List[Dict],
    financial: Dict = None
) -> List[str]:
    """生成具体建议"""
    suggestions = []
    
    # 获取估值信息
    ev = financial.get('估值分位', {}) if financial else {}
    valuation = financial.get('估值', {}) if financial else {}
    
    if final_vote == VOTE_BUY:
        suggestions.append("当前时点具备投资价值，可考虑建仓")
        
        # 根据估值给出建议
        if 'error' not in ev:
            pe_pct = ev.get('PE分位', 50)
            if pe_pct < 30:
                suggestions.append("估值处于历史低位，具备安全边际，可适当加大仓位")
        
        # 根据股息率给出建议
        if 'error' not in valuation:
            dv = valuation.get('股息率', 0)
            if dv > 4:
                suggestions.append(f"股息率{dv:.1f}%较高，适合长期持有获取分红收益")
        
        suggestions.append("建议分批买入，首次仓位控制在20%以内，设置10%止损线")
        
    elif final_vote == VOTE_CAUTION:
        suggestions.append("当前存在不确定性因素，建议观望")
        suggestions.append("如需参与，仓位控制在10%以内")
        suggestions.append("等待更明确的买入信号（如估值回落、业绩拐点确认）")
        
    else:
        suggestions.append("当前风险大于机会，建议规避")
        suggestions.append("如已持有，考虑减仓或止损")
        suggestions.append("等待更好的入场时机（估值回归、基本面改善）")
    
    return suggestions


def _extract_risks(analyst_results: List[Dict]) -> List[str]:
    """提取风险点"""
    risks = []
    
    for r in analyst_results:
        if r['name'] == "风险控制师":
            reason = r['reason']
            if '波动风险' in reason:
                risks.append("股价波动较大，短期风险较高")
            if '杠杆风险' in reason or '财务杠杆' in reason:
                risks.append("财务杠杆偏高，偿债压力较大")
            if '现金流风险' in reason:
                risks.append("经营现金流为负，需关注资金链安全")
            if '估值偏高' in reason:
                risks.append("估值处于历史高位，回调风险较大")
            if '系统性风险' in reason:
                risks.append("市场系统性风险不可忽视")
    
    # 默认风险提示
    if not risks:
        risks.append("投资有风险，决策需谨慎")
        risks.append("建议分散投资，控制单一标的仓位")
    
    return risks


def save_report(code: str, name: str, report: str) -> str:
    """
    保存报告到文件
    
    Returns:
        保存路径
    """
    date_str = datetime.now().strftime('%Y-%m-%d')
    # 清洗文件名，防止特殊字符
    safe_name = sanitize_filename(name)
    filename = f"{date_str}_{code}_{safe_name}.txt"
    filepath = os.path.join(REPORTS_DIR, filename)
    
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(report)
    
    return filepath


if __name__ == "__main__":
    # 测试
    test_results = [
        {'name': '宏观经济分析师', 'weight': 1.0, 'vote': VOTE_BUY, 'reason': '宏观环境稳定'},
        {'name': '行业研究员', 'weight': 1.5, 'vote': VOTE_BUY, 'reason': '行业景气度高'},
        {'name': '基本面分析师', 'weight': 1.5, 'vote': VOTE_CAUTION, 'reason': '基本面一般'},
    ]
    
    report = generate_report(
        '600919',
        '江苏银行',
        {'现价': 11.40, '涨跌幅': 0.35, 'source': 'AKShare'},
        test_results,
        VOTE_BUY,
        0.6
    )
    
    print(report)
