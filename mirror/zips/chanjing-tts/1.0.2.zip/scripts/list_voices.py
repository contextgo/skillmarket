#!/usr/bin/env python3
"""
列出公共声音人。与 chanjing-credentials-guard 使用同一配置文件获取 Token。
用法: list_voices.py [--page 1] [--size 100] [--json]
输出: 默认打印 id/name 表；--json 时输出完整 data
"""
import argparse
import json
import sys
import urllib.parse
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _auth import get_token

API_BASE = __import__("os").environ.get("CHANJING_API_BASE", "https://open-api.chanjing.cc")


def main():
    parser = argparse.ArgumentParser(description="列出蝉镜公共声音人")
    parser.add_argument("--page", type=int, default=1, help="页码")
    parser.add_argument("--size", type=int, default=100, help="每页数量")
    parser.add_argument("--json", action="store_true", help="输出完整 JSON")
    args = parser.parse_args()

    token, err = get_token()
    if err:
        print(err, file=sys.stderr)
        sys.exit(1)

    qs = urllib.parse.urlencode({"page": args.page, "size": args.size})
    url = f"{API_BASE}/open/v1/list_common_audio?{qs}"
    req = urllib.request.Request(url, headers={"access_token": token}, method="GET")
    with urllib.request.urlopen(req, timeout=30) as resp:
        body = json.loads(resp.read().decode("utf-8"))

    if body.get("code") != 0:
        print(body.get("msg", body), file=sys.stderr)
        sys.exit(1)

    data = body.get("data", {})
    if args.json:
        print(json.dumps(data, ensure_ascii=False, indent=2))
        return

    items = data.get("list", [])
    page_info = data.get("page_info", {})
    print(f"# 共 {page_info.get('total_count', len(items))} 个声音 (page={args.page})")
    print(f"{'id':<36}  name")
    print("-" * 60)
    for v in items:
        print(f"{v.get('id', ''):<36}  {v.get('name', '')}")


if __name__ == "__main__":
    main()
