# 橙美美容客服 Skill

面向中文顾客的美容院智能客服知识库，让 AI 以橙美的语气和专业度回答顾客问题。

## 结构

```
chengmei-beauty-skill/
├─ README.md                  # 本文件
├─ SKILL.md                   # Skill 核心指令
├─ CONFIG.yaml                # 店铺配置信息
├─ knowledge/                 # 知识文件
│  ├─ 店铺信息.md             # 地址、营业时间、联系方式
│  ├─ 服务项目.md             # 服务项目、产品
│  ├─ 常见问题.md             # 顾客常见问题解答
│  └─ 健康与预约规则.md       # 健康须知、预约规则
└─ examples/
   └─ 示例话术.md             # 客服话术示例
```

## 使用方式

将此目录作为 Skill 加载到 AI 对话中，AI 会自动读取 CONFIG.yaml 和 knowledge/ 下的文件来回答顾客问题。

## 自定义

修改 `CONFIG.yaml` 中的店铺信息，以及 `knowledge/` 下的文件内容即可适配不同门店。
