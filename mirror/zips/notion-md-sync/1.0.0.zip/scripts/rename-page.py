#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Notion 页面重命名工具

用途：修复创建页面时中文名称显示为 "???" 的问题
用法：python rename-page.py "页面ID" "新名称"

依赖：Python 3.x
"""

import json
import sys
import subprocess

def get_token():
    """获取 Notion Token"""
    result = subprocess.run(
        ["powershell", "-Command", 
         "E:\\软件\\QClaw\\resources\\openclaw\\config\\skills\\notion-md-sync\\scripts\\get-token.ps1"],
        capture_output=True, text=True, encoding='utf-8'
    )
    return result.stdout.strip()

def rename_page(token, page_id, new_name):
    """重命名 Notion 页面"""
    import urllib.request
    import urllib.error
    
    url = f"https://api.notion.com/v1/pages/{page_id}"
    
    data = {
        "properties": {
            "title": [
                {
                    "type": "text",
                    "text": {"content": new_name}
                }
            ]
        }
    }
    
    headers = {
        "Authorization": f"Bearer {token}",
        "Notion-Version": "2025-09-03",
        "Content-Type": "application/json; charset=utf-8"
    }
    
    req = urllib.request.Request(
        url, 
        data=json.dumps(data, ensure_ascii=False).encode('utf-8'),
        headers=headers,
        method='PATCH'
    )
    
    try:
        with urllib.request.urlopen(req) as response:
            result = json.loads(response.read().decode('utf-8'))
            print(f"✅ 重命名成功: {new_name}")
            return True
    except urllib.error.HTTPError as e:
        error_body = json.loads(e.read().decode('utf-8'))
        print(f"❌ HTTP {e.code}: {error_body.get('message', 'Unknown error')}")
        return False
    except Exception as e:
        print(f"❌ 错误: {str(e)}")
        return False

def main():
    if len(sys.argv) < 3:
        # 批量重命名模式
        token = get_token()
        if not token or not token.startswith(('secret_', 'ntn_')):
            print("获取 Token 失败")
            sys.exit(1)
        
        print(f"Token 已获取 (长度: {len(token)})")
        
        # 预定义的页面映射
        mapping = {
            "344fae7c-950d-8192-95c4-d74dcf489337": "Spring Boot",
            "344fae7c-950d-81e4-95b9-cc5cb9c44150": "Spring MVC",
            "344fae7c-950d-81fe-9485-de4034f081db": "网络编程",
            "344fae7c-950d-815a-8112-e8e2a00fdbec": "17~24day",
            "344fae7c-950d-81f7-90d8d6372436f1c1": "1~6day",
            "344fae7c-950d-819089b0e872810382c3": "23",
            "344fae7c-950d-810093e7d714051aa4bd": "7~16day",
            "344fae7c-950d-81a3961adeb8639e871d": "ElasticSearch",
            "344fae7c-950d-8117896bfa1d6685a8fe": "Git",
            "344fae7c-950d-81c0a7e6c456a4d35871": "JavaWeb",
            "344fae7c-950d-81e8b771ebb288a88fb6": "JVM调优",
            "344fae7c-950d-81e9a626f145e3738e14": "Linux_Docker",
            "344fae7c-950d-81f38843d951ab7f8d7c": "MyBatis-plus",
            "344fae7c-950d-8130953ff8a4ff60ffca": "Mybatis",
            "344fae7c-950d-81f08e8cc7c78834f322": "Nginx-Dubbo-Zookeeper",
            "344fae7c-950d-81b68af2d5c39aa9fa56": "Spring Cloud Alibaba",
            "344fae7c-950d-81aa9de0dc1740dad731": "Spring",
            "344fae7c-950d-815da3fcd28822918ba3": "web",
            "344fae7c-950d-81bba0e1c0695c08d024": "基础班Java",
            "344fae7c-950d-81a19ed8eb888a883edd": "基础班Web",
            "344fae7c-950d-81539b61fb8b236666fd": "多线程JUC",
            "344fae7c-950d-8149b407ee5d175ec997": "操作系统",
            "344fae7c-950d-815f8905fa500b0db66d": "数据库学习",
            "344fae7c-950d-81a7b249c9ed58976565": "数据结构算法学习",
            "344fae7c-950d-81d29cd7fbc50b4775c6": "QuartZ",
            "344fae7c-950d-8156aef4e64f9ef8231b": "SpringBoot整合笔记",
            "344fae7c-950d-81a0835af93aade0b0e0": "Spring整合JDBC实现用户的CRUD",
            "344fae7c-950d-81d6beeed7482d6dbb68": "Spring整合Mybatis实现用户的CRUD",
            "344fae7c-950d-81a7a4d1cdc32029638b": "Spring整合Redis",
            "344fae7c-950d-81c8945ff0fd48478860": "SSM整合",
            "344fae7c-950d-81ec9569dcdf55f5aa2b": "医疗管家",
            "344fae7c-950d-813f93e2db44d8fa28b6": "学生管理系统",
            "344fae7c-950d-813bb4e4c69822931e48": "一阶段",
            "344fae7c-950d-817ab2c9f03d32636ba3": "三阶段",
            "344fae7c-950d-810cad25c10fee801c6e": "二阶段",
            "344fae7c-950d-81bb8780f81aefa40cfc": "四阶段",
            "344fae7c-950d-8116a6adfb4e4722a503": "面试题",
            "344fae7c-950d-81f0ba6cec505bb2a593": "A高频面试题",
            "344fae7c-950d-810b90f0d0bec7f26f26": "Java2年暴书源",
            "344fae7c-950d-81838355d3132bb84f7b": "面试技巧",
        }
        
        total = len(mapping)
        success = 0
        failed = []
        
        print(f"\n开始重命名 {total} 个页面...")
        
        import time
        for i, (page_id, new_name) in enumerate(mapping.items(), 1):
            print(f"[{i}/{total}] {new_name}...", end=" ", flush=True)
            if rename_page(token, page_id, new_name):
                success += 1
            else:
                failed.append(new_name)
            time.sleep(0.3)
        
        print(f"\n=== 结果 ===")
        print(f"成功: {success}/{total}")
        print(f"失败: {len(failed)}")
        if failed:
            print(f"失败列表: {failed}")
        
    else:
        # 单个重命名模式
        token = get_token()
        if not token or not token.startswith(('secret_', 'ntn_')):
            print("获取 Token 失败")
            sys.exit(1)
        
        page_id = sys.argv[1]
        new_name = sys.argv[2]
        
        rename_page(token, page_id, new_name)

if __name__ == "__main__":
    main()