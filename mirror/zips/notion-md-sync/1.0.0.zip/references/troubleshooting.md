# 常见问题排查手册

本文档记录了 Notion Markdown 同步过程中遇到的所有问题及解决方案。

---

## 一、连接与认证

### 问题：页面创建返回 404

**错误信息**：
```json
{"object":"error","status":404,"code":"object_not_found"}
```

**原因**：使用了 `workspace_id` 作为 parent，但 Notion API 不支持这种方式。

**解决方案**：
```powershell
# ❌ 错误
$parent = @{ workspace = $true }

# ✅ 正确：用搜索 API 找到有效页面
$search = irm "https://api.notion.com/v1/search" -Method POST -Headers $headers -Body '{"filter":{"property":"object","value":"page"}}'
$parentPageId = $search.results | Where-Object { $_.parent.type -eq "workspace" } | Select-Object -First 1 -ExpandProperty id
```

---

## 二、编码问题

### 问题：中文变成 Unicode 转义

**现象**：
```
输入: "中文测试"
输出: "\u4e2d\u6587\u6d4b\u8bd5"
```

**原因**：PowerShell 5.1 的 `ConvertTo-Json` 强制转义非 ASCII 字符。

**失败的尝试**：
- ❌ `[System.Text.Encoding]::UTF8` - 不影响 JSON 序列化
- ❌ `[System.Text.Json]::Serialize()` - PowerShell 5.1 没有这个类
- ❌ `-Depth 10` - 只影响嵌套深度，不改变编码

**解决方案**：
```powershell
# 安装 Newtonsoft.Json
# 从 NuGet 下载或从已有项目复制

Add-Type -Path "C:\path\to\Newtonsoft.Json.dll"
$json = [Newtonsoft.Json.JsonConvert]::SerializeObject($obj)
```

**注意**：Notion API 能接受 Unicode 转义，但调试时难以阅读。

---

## 三、Markdown 解析

### 问题：Markdown 源码直接显示

**现象**：`**粗体**` 直接显示为 `**粗体**`，而不是加粗。

**原因**：脚本把 Markdown 语法当纯文本处理，未转换为 Notion 格式。

**解决方案**：实现完整解析器

```powershell
# 行内格式解析
function Parse-InlineFormat {
    param($text)
    
    $result = @()
    # 匹配 **bold**, *italic*, `code`
    $pattern = '(\*\*[^*]+\*\*)|(\*[^*]+\*)|(`[^`]+`)'
    $matches = [regex]::Matches($text, $pattern)
    
    $lastEnd = 0
    foreach ($m in $matches) {
        # 匹配前的普通文本
        if ($m.Index -gt $lastEnd) {
            $result += @{ type="text"; text=@{content=$text.Substring($lastEnd, $m.Index-$lastEnd)} }
        }
        
        # 匹配的格式文本
        $matched = $m.Value
        $content = $matched.Trim('*','`')
        $rt = @{ type="text"; text=@{content=$content} }
        
        if ($matched -match '^\*\*') { $rt.annotations = @{bold=$true} }
        elseif ($matched -match '^\*') { $rt.annotations = @{italic=$true} }
        elseif ($matched -match '^`') { $rt.annotations = @{code=$true} }
        
        $result += $rt
        $lastEnd = $m.Index + $m.Length
    }
    
    # 剩余文本
    if ($lastEnd -lt $text.Length) {
        $result += @{ type="text"; text=@{content=$text.Substring($lastEnd)} }
    }
    
    return $result
}
```

### 问题：列表识别不完整

**原因**：只识别了 `- ` 开头的列表，没有识别 `• `、`* ` 等格式。

**解决方案**：
```powershell
# 无序列表前缀
if ($line -match '^(\s*)[-*•]\s+') {
    $indent = $Matches[1].Length
    $content = $line -replace '^(\s*)[-*•]\s+', ''
    # 创建 bulleted_list_item
}

# 有序列表前缀
if ($line -match '^(\s*)\d+\.\s+') {
    $indent = $Matches[1].Length
    $content = $line -replace '^(\s*)\d+\.\s+', ''
    # 创建 numbered_list_item
}
```

---

## 四、代码块问题

### 问题：代码块不显示

**原因**：未正确解析 ` ```language ` 语法。

**解决方案**：
```powershell
if ($line -match '^```\s*(\w*)') {
    $lang = $Matches[1]
    # 语言映射
    $langMap = @{ "yml"="yaml"; "properties"="plain text" }
    if ($langMap[$lang]) { $lang = $langMap[$lang] }
    
    # 收集代码直到 ```
    $code = ""
    while (($nextLine = $reader.ReadLine()) -notmatch '^```') {
        $code += $nextLine + "`n"
    }
    
    # 创建 code Block
    $block = @{
        type = "code"
        code = @{
            rich_text = @(@{ type="text"; text=@{content=$code} })
            language = $lang
        }
    }
}
```

### 问题：代码块超长报错

**错误信息**：
```json
"code.rich_text[0].text.content should be shorter than 2001 characters"
```

**解决方案**：拆分为多个 code Block
```powershell
$maxLen = 2000
if ($code.Length -gt $maxLen) {
    $chunks = @()
    for ($i = 0; $i -lt $code.Length; $i += $maxLen) {
        $len = [math]::Min($maxLen, $code.Length - $i)
        $chunks += $code.Substring($i, $len)
    }
    
    foreach ($chunk in $chunks) {
        # 创建多个 code Block
    }
}
```

### 问题：语言名不识别

**现象**：`yml`、`properties` 等语言名报错。

**解决方案**：建立映射表
```powershell
$langMap = @{
    "yml" = "yaml"
    "yaml" = "yaml"
    "properties" = "plain text"
    "xml" = "plain text"
    "xaml" = "plain text"
    "txt" = "plain text"
    "conf" = "plain text"
    "ini" = "plain text"
    "sh" = "shell"
    "bash" = "shell"
    "zsh" = "shell"
    "js" = "javascript"
    "ts" = "typescript"
}
```

---

## 五、表格问题

### 问题：表格 API 报错

**错误信息**：
```json
"body.children[0].table.children should be defined, instead was undefined"
```

**原因**：用了 `table.rows` 而不是 `table.children`。

**解决方案**：
```json
// ❌ 错误
{
  "type": "table",
  "table": {
    "rows": [...]  // 没有这个属性
  }
}

// ✅ 正确
{
  "type": "table",
  "table": {
    "table_width": 3,
    "has_column_header": true,
    "children": [
      {
        "type": "table_row",
        "table_row": { "cells": [...] }
      }
    ]
  }
}
```

### 问题：cells 格式错误

**错误信息**：
```json
"cells[0] should be an array, instead was {...}"
```

**原因**：`cells` 必须是**二维数组**（rich_text 数组的数组）。

**解决方案**：
```powershell
# cells 结构：每一列是一个 rich_text 数组
$cells = @(
    @(@{type="text"; text=@{content="列1"}}),  # 第一列
    @(@{type="text"; text=@{content="列2"}}),  # 第二列
    @(@{type="text"; text=@{content="列3"}})   # 第三列
)

# 完整的 table_row
$tableRow = @{
    type = "table_row"
    table_row = @{ cells = $cells }
}
```

---

## 六、rich_text 数组问题

### 问题：双层数组 `[[...]]`

**现象**：rich_text 被包裹成双层数组，API 报错。

**原因**：PowerShell 中 `,@()` 会创建嵌套数组。

**解决方案**：
```powershell
# ❌ 错误：,@() 创建双层
function Get-RichText {
    return ,@(@{type="text"; text=@{content="hello"}})
}
$result = Get-RichText  # [[...]]

# ✅ 正确：直接返回数组
function Get-RichText {
    return @(@{type="text"; text=@{content="hello"}})
}
$result = Get-RichText  # [...]
```

---

## 七、多级标题

### 问题：Notion 只支持 H1-H3

**解决方案**：用其他 Block 模拟

| Markdown | Notion Block | 样式 |
|----------|--------------|------|
| `####` | `callout` | 📌 + 背景色 |
| `#####` | `paragraph` | ▶ **加粗** |
| `######` | `quote` | 引用块 |

```powershell
# H4 → callout
if ($line -match '^####\s+') {
    $content = $line -replace '^####\s+', ''
    $block = @{
        type = "callout"
        callout = @{
            rich_text = @(@{type="text"; text=@{content=$content}})
            icon = @{emoji="📌"}
        }
    }
}

# H5 → 加粗段落
if ($line -match '^#####\s+') {
    $content = $line -replace '^#####\s+', ''
    $block = @{
        type = "paragraph"
        paragraph = @{
            rich_text = @(@{
                type="text"
                text=@{content="▶ $content"}
                annotations=@{bold=$true}
            })
        }
    }
}

# H6 → quote
if ($line -match '^######\s+') {
    $content = $line -replace '^######\s+', ''
    $block = @{
        type = "quote"
        quote = @{
            rich_text = @(@{type="text"; text=@{content=$content}})
        }
    }
}
```

---

## 八、图片上传

### 问题：图片不显示

**原因**：未完成三步上传流程。

**解决方案**：
```powershell
# 第一步：创建上传任务
$createResp = irm "https://api.notion.com/v1/file_uploads" -Method POST `
    -Headers $headers -Body '{"mode":"single_part"}'
$fileUploadId = $createResp.id

# 第二步：发送文件
$form = @{
    file = Get-Item $imagePath
    file_upload_id = $fileUploadId
}
$sendResp = irm "https://api.notion.com/v1/file_uploads/$fileUploadId/send" `
    -Method POST -Headers $headers -Form $form

# 第三步：在 Block 中引用
$imageBlock = @{
    type = "image"
    image = @{
        type = "file_upload"
        file_upload = @{ id = $fileUploadId }
    }
}
```

---

## 九、调试技巧

### 技巧 1：写 JSON 到文件

PowerShell 直接传 JSON 可能有问题，建议写入文件：

```powershell
$jsonPath = "$env:TEMP\notion-test.json"
[System.IO.File]::WriteAllText($jsonPath, $jsonBody, [System.Text.Encoding]::UTF8)

$result = curl.exe -s -X PATCH "https://api.notion.com/v1/blocks/$pageId/children" `
    -H "Authorization: Bearer $token" `
    -H "Notion-Version: 2025-09-03" `
    -H "Content-Type: application/json; charset=utf-8" `
    --data-binary "@$jsonPath"
```

### 技巧 2：验证 JSON 格式

```powershell
# 检查是否是有效 JSON
try {
    $parsed = ConvertFrom-Json $jsonBody -ErrorAction Stop
    Write-Host "JSON 有效"
} catch {
    Write-Host "JSON 无效: $_"
}

# 检查数组嵌套
$rt = $parsed.children[0].paragraph.rich_text
Write-Host "rich_text 类型: $($rt.GetType().Name)"
Write-Host "元素数: $($rt.Count)"
```

### 技巧 3：逐步验证 Block

```powershell
# 先上传单个 Block 测试
$testBlock = @{ type="paragraph"; paragraph=@{rich_text=@(@{type="text"; text=@{content="测试"}})}}
$jsonBody = @{children=@($testBlock)} | ConvertTo-Json -Depth 10

# 检查响应
$result = irm "https://api.notion.com/v1/blocks/$pageId/children" -Method PATCH -Headers $headers -Body $jsonBody
Write-Host "创建成功: $($result.results[0].id)"
```

---

## 总结

| 问题类型 | 常见错误 | 核心解决 |
|----------|----------|----------|
| 连接 | 404 | 用搜索 API 找有效页面 |
| 编码 | Unicode 转义 | Newtonsoft.Json |
| 解析 | 源码显示 | 完整 MD 解析器 |
| 代码块 | 超长/语言 | 拆分 + 映射表 |
| 表格 | children 缺失 | `table.children` 结构 |
| rich_text | 双层数组 | 避免嵌套 `,@()` |
| 图片 | 不显示 | 三步上传流程 |
| 标题 | H4-H6 | 用其他 Block 模拟 |
| 页面重命名 | 显示??? | 使用 Python 或 curl.exe |
| Token | 401 未授权 | 重新配置 Integration |
| 路径 | 图片找不到 | 使用绝对路径 |
| 限流 | 429 | 添加延迟和重试 |
| 网络 | 502/503 | 重试逻辑 |

---

## 十一、Token 问题

### 问题：Token 无效或过期

**错误信息**：
```json
{"object":"error","status":401,"code":"unauthorized"}
```

**原因**：
1. Token 被 Notion 取消授权
2. Integration 被删除
3. Token 格式变化（Notion 迁移到新格式）

**解决方案**：
```powershell
# 检查 Token 是否有效
$headers = @{
    "Authorization" = "Bearer $token"
    "Notion-Version" = "2025-09-03"
}
try {
    $resp = irm "https://api.notion.com/v1/users/me" -Headers $headers -ErrorAction Stop
    Write-Host "Token 有效: $($resp.bot.name)"
} catch {
    Write-Host "Token 无效，需要重新配置"
    # 引导用户重新配置 Token
}
```

### 问题：页面未分享给 Integration

**错误信息**：
```json
{"object":"error","status":404,"code":"object_not_found"}
```

**解决方案**：
1. 打开 Notion 页面
2. 点击右上角 **...**
3. 选择 **Add connections**
4. 搜索并添加你的 Integration

---

## 十二、文件路径问题

### 问题：图片找不到

**错误信息**：
```
Get-Item : 找不到路径 xxx
```

**原因**：
1. 图片用相对路径（如 `img/a.jpg`），但脚本从其他目录运行
2. 图片文件已被删除或移动

**解决方案**：
```powershell
# 使用绝对路径
$mdFile = "C:\notes\SpringBoot.md"

# 或在脚本中切换到正确目录
Set-Location "C:\notes"

# 或指定图片基础目录
$script:ImageBaseDir = "C:\notes\img"
```

### 问题：路径包含空格

**原因**：Windows 路径包含空格需要特殊处理

**解决方案**：
```powershell
# PowerShell 自动处理，但确保用引号
$path = "C:\My Documents\notes\img.jpg"

# curl.exe 也需要引号
curl.exe -F "file=@""$imagePath"""
```

---

## 十三、API 限流

### 问题：请求被限流

**错误信息**：
```json
{"object":"error","status":429,"code":"rate_limited"}
```

**解决方案**：
```powershell
# 添加延迟
Start-Sleep -Milliseconds 350

# 或使用指数退避
$retryCount = 0
$maxRetries = 3
while ($retryCount -lt $maxRetries) {
    try {
        $resp = irm $url -Headers $headers -Body $body -ErrorAction Stop
        break
    } catch {
        $retryCount++
        $waitTime = [math]::Pow(2, $retryCount) * 1000
        Write-Host "限流等待 ${waitTime}ms..."
        Start-Sleep -Milliseconds $waitTime
    }
}
```

---

## 十四、Markdown 边缘情况

### 问题：嵌套列表解析失败

**原因**：多层缩进的列表（>3层）无法正确识别

**解决方案**：
```powershell
# 识别缩进级别
if ($line -match '^(\s+)-') {
    $indentLevel = $Matches[1].Length / 2  # 假设2空格=1级
    if ($indentLevel -gt 3) {
        # 降级为普通段落
        $block = @{ type = "paragraph"; ... }
    }
}
```

### 问题：代码块语言不支持

**原因**：Notion 不支持所有语言

**解决方案**：使用 "plain text" 作为后备
```powershell
$supportedLanguages = @("javascript", "python", "java", "html", "css", "sql", ...)

if ($supportedLanguages -notcontains $lang) {
    $lang = "plain text"
}
```

---

## 十五、网络问题

### 问题：图片上传超时

**原因**：图片太大（>5MB）或网络慢

**解决方案**：
```powershell
# 检查文件大小
$fileSize = (Get-Item $imagePath).Length
if ($fileSize -gt 5MB) {
    Write-Host "图片太大，考虑压缩或缩小"
}
```

### 问题：偶发 502/503 错误

**解决方案**：添加重试逻辑
```powershell
try {
    $resp = Invoke-RestMethod ... -ErrorAction Stop
} catch {
    if ($_.Exception.Response.StatusCode -in @(502, 503)) {
        Start-Sleep -Seconds 2
        $resp = Invoke-RestMethod ...
    }
}

---

## 十、页面重命名编码问题

### 问题：页面名称显示为 "???"

**现象**：
- 页面创建成功，但标题显示为 "???" 或乱码
- 批量重命名时，API 返回成功，但名称仍然是乱码

**原因分析**：
1. **PowerShell 控制台编码问题**：控制台能显示中文，但 `ConvertTo-Json` 序列化时编码不一致
2. **PowerShell 5.1 的 `.NET` 编码限制**：PowerShell ISE/编辑器编码与控制台编码不匹配
3. **使用 PowerShell 的 `application/json` 调用 API**：内部编码转换导致中文乱码

**症状**：
```
API 返回的数据:
{
  "properties": {
    "title": {
      "title": [
        { "plain_text": "???" }  // 中文变成问号
      ]
    }
  }
}
```

**解决方案 1：使用 Python 脚本（推荐）**

Python 的 `urllib` 默认使用 UTF-8 编码，避免 PowerShell 的编码问题：

```python
import urllib.request
import json

def rename_page(token, page_id, new_name):
    url = f"https://api.notion.com/v1/pages/{page_id}"
    data = {
        "properties": {
            "title": [
                {
                    "type": "text",
                    "text": {"content": new_name}
                }
            ]
        }
    }
    
    headers = {
        "Authorization": f"Bearer {token}",
        "Notion-Version": "2025-09-03",
        "Content-Type": "application/json"
    }
    
    req = urllib.request.Request(
        url, 
        data=json.dumps(data).encode('utf-8'),
        headers=headers,
        method='PATCH'
    )
    
    with urllib.request.urlopen(req) as response:
        return json.loads(response.read().decode('utf-8'))
```

**解决方案 2：使用 curl.exe（命令行）**

curl.exe 不会受到 PowerShell 编码问题影响：

```powershell
# 先获取 Token
$token = & $tokenScript

# 使用 curl.exe 重命名
$jsonBody = @{
    properties = @{
        title = @(@{ type = "text"; text = @{ content = "新的标题" } })
    }
} | ConvertTo-Json -Compress

# 写入文件（UTF-8 无 BOM）
$tempFile = "$env:TEMP\rename.json"
[System.IO.File]::WriteAllText($tempFile, $jsonBody, [System.Text.Encoding]::UTF8)

# 使用 curl.exe
curl.exe -s -X PATCH "https://api.notion.com/v1/pages/$pageId" `
    -H "Authorization: Bearer $token" `
    -H "Notion-Version: 2025-09-03" `
    -H "Content-Type: application/json; charset=utf-8" `
    --data-binary "@$tempFile"
```

**解决方案 3：使用 curl.exe 的 --data-raw**

```powershell
# 构建 JSON 时确保中文正确
$title = "中文标题"
$jsonBody = "{`"properties`":{`"title`":[{`"type`":`"text`",`"text`":{`"content`":`"$title`"}}]}}"

curl.exe -s -X PATCH "https://api.notion.com/v1/pages/$pageId" `
    -H "Authorization: Bearer $token" `
    -H "Notion-Version: 2025-09-03" `
    -H "Content-Type: application/json; charset=utf-8" `
    --data-raw $jsonBody
```

**验证修复是否成功**：

```powershell
# 检查 API 返回的原始数据
$resp = irm "https://api.notion.com/v1/pages/$pageId" -Headers $headers
$title = $resp.properties.title.title[0].plain_text
Write-Host "页面标题: $title"

# 如果仍然是乱码，说明 API 存储就是乱码，需要再次重命名
if ($title -match '^\?+$') {
    Write-Host "需要重新重命名..."
}
```

---

## 十一、内容完整性

### 问题：上传内容不完整

**现象**：
- 页面内容从中间开始，前面部分丢失
- 多次上传后内容叠加混乱
- Block 数量与原始文件不符

**原因分析**：
1. **批次上传失败**：某个批次因验证错误失败，后续内容丢失
2. **清空不彻底**：删除操作异步执行，未等待完成
3. **API 限制**：单次查询只返回 100 个 Block，清空时遗漏

**解决方案**：

```powershell
# 1. 循环清空直到页面为空
do {
    $existing = irm "https://api.notion.com/v1/blocks/$pageId/children?page_size=100" -Headers $headers
    if ($existing.results.Count -eq 0) { break }
    
    foreach ($block in $existing.results) {
        irm "https://api.notion.com/v1/blocks/$($block.id)" -Method DELETE -Headers $headers | Out-Null
    }
    Start-Sleep -Milliseconds 300
} while ($true)

# 2. 等待 Notion 同步
Start-Sleep -Seconds 2

# 3. 上传后验证完整性
$uploadedBlocks = @()
$cursor = $null
do {
    $url = "https://api.notion.com/v1/blocks/$pageId/children?page_size=100"
    if ($cursor) { $url += "&start_cursor=$cursor" }
    
    $resp = irm $url -Headers $headers
    $uploadedBlocks += $resp.results
    $cursor = if ($resp.has_more) { $resp.next_cursor } else { $null }
} while ($cursor)

# 4. 对比数量
$expectedH2 = ($mdLines | Where-Object { $_ -match '^## ' }).Count
$actualH2 = ($uploadedBlocks | Where-Object { $_.type -eq 'heading_2' }).Count

if ($expectedH2 -ne $actualH2) {
    Write-Host "⚠️ H2 标题数量不匹配！" -ForegroundColor Yellow
}
```

**预防措施**：
- ✅ 使用 `-ClearPage` 参数清空后再上传
- ✅ 上传成功后检查验证输出
- ✅ 如有失败批次，清空后重试
