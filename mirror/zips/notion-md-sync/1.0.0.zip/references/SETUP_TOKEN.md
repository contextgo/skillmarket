# Notion Token 配置

本技能需要 Notion API Token 才能使用。有两种配置方式：

---

## 方式一：OpenClaw 平台用户（推荐）

如果你是 OpenClaw/QClaw 用户，Token 由平台统一托管：

1. 在应用内**集成面板**中找到 Notion
2. 点击授权，完成 OAuth 流程
3. Token 会自动注入，无需手动配置

**验证 Token**：
```powershell
$token = & "E:\软件\QClaw\resources\openclaw\config\skills\notion\get-token.ps1"
Write-Host "Token: $token"
```

---

## 方式二：独立用户（发布到公共仓库）

如果你是独立用户，需要手动创建 Notion Integration：

### 步骤 1：创建 Notion Integration

1. 访问 https://www.notion.so/my-integrations
2. 点击 **"+ New integration"**
3. 填写名称（如 "MD Sync"），选择工作空间
4. 点击 **Submit** 创建
5. 复制 **Internal Integration Token**（以 `secret_` 开头）

### 步骤 2：分享页面给 Integration

1. 在 Notion 中打开你要同步的页面
2. 点击右上角 **...** → **Add connections**
3. 搜索并选择你创建的 Integration

### 步骤 3：配置 Token

**方法 A：环境变量（推荐）**
```powershell
# Windows (PowerShell)
$env:NOTION_TOKEN = "secret_your_token_here"

# macOS / Linux
export NOTION_TOKEN="secret_your_token_here"
```

**方法 B：配置文件**

创建 `~/.notion/token.txt` 文件，内容为你的 Token：
```
secret_your_token_here
```

### 步骤 4：验证 Token

```powershell
# 使用环境变量
$token = $env:NOTION_TOKEN
irm "https://api.notion.com/v1/users/me" -Headers @{
    "Authorization" = "Bearer $token"
    "Notion-Version" = "2025-09-03"
}
```

---

## 安全提示

⚠️ **Token 是敏感信息**：
- 不要提交到 Git 仓库
- 不要在公开场合分享
- 定期更换 Token
- 如果泄露，立即在 Notion Integration 设置中重新生成

---

## 常见问题

### Q: 提示 "未获取到 access_token"
**A**: 你还没有在集成面板中完成 Notion 授权。请先完成授权。

### Q: 提示 "unauthorized"
**A**: Token 无效或过期。请检查 Token 是否正确。

### Q: 提示 "object_not_found"
**A**: 页面没有分享给 Integration。请在 Notion 页面设置中添加连接。

### Q: 如何获取页面 ID？
**A**: 
- 从 URL 复制：`https://www.notion.so/your-workspace/PageName-1234567890abcdef` 
  → 页面 ID 是 `1234567890abcdef`（带连字符格式：`12345678-90ab-cdef-...`）
- 或使用搜索 API 查询
