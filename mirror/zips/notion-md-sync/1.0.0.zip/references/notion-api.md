# Notion Block API 参考

## 基础认证

```powershell
$Headers = @{
    "Authorization" = "Bearer $NOTION_TOKEN"
    "Notion-Version" = "2025-09-03"
    "Content-Type" = "application/json"
}
```

## Block 类型速查

### 文本类

```json
// 段落
{
  "type": "paragraph",
  "paragraph": {
    "rich_text": [{"type": "text", "text": {"content": "文本内容"}}]
  }
}

// 标题 (H1-H3)
{
  "type": "heading_1",
  "heading_1": {
    "rich_text": [{"type": "text", "text": {"content": "标题"}}]
  }
}

// 引用
{
  "type": "quote",
  "quote": {
    "rich_text": [{"type": "text", "text": {"content": "引用内容"}}]
  }
}

// 代码块
{
  "type": "code",
  "code": {
    "rich_text": [{"type": "text", "text": {"content": "print('hello')"}}],
    "language": "python"
  }
}

// Callout (高亮块)
{
  "type": "callout",
  "callout": {
    "rich_text": [{"type": "text", "text": {"content": "提示内容"}}],
    "icon": {"emoji": "📌"}
  }
}
```

### 列表类

```json
// 无序列表
{
  "type": "bulleted_list_item",
  "bulleted_list_item": {
    "rich_text": [{"type": "text", "text": {"content": "列表项"}}]
  }
}

// 有序列表
{
  "type": "numbered_list_item",
  "numbered_list_item": {
    "rich_text": [{"type": "text", "text": {"content": "列表项"}}]
  }
}

// 待办事项
{
  "type": "to_do",
  "to_do": {
    "rich_text": [{"type": "text", "text": {"content": "待办内容"}}],
    "checked": false
  }
}
```

### 媒体类

```json
// 图片
{
  "type": "image",
  "image": {
    "type": "file_upload",
    "file_upload": {"id": "file_upload_id"}
  }
}

// 分割线
{
  "type": "divider",
  "divider": {}
}
```

### 表格

```json
{
  "type": "table",
  "table": {
    "table_width": 3,
    "has_column_header": true,
    "has_row_header": false,
    "children": [
      {
        "type": "table_row",
        "table_row": {
          "cells": [
            [{"type": "text", "text": {"content": "单元格1"}}],
            [{"type": "text", "text": {"content": "单元格2"}}],
            [{"type": "text", "text": {"content": "单元格3"}}]
          ]
        }
      }
    ]
  }
}
```

## rich_text 格式

### 基础结构

```json
{
  "type": "text",
  "text": {
    "content": "文本内容",
    "link": {"url": "https://example.com"}  // 可选
  },
  "annotations": {  // 可选
    "bold": true,
    "italic": true,
    "code": true,
    "strikethrough": true,
    "underline": true,
    "color": "default"
  }
}
```

### 颜色值

```
default, gray, brown, orange, yellow, green, blue, purple, pink, red
gray_background, brown_background, orange_background, yellow_background,
green_background, blue_background, purple_background, pink_background, red_background
```

## 支持的代码语言

```
abap, arduino, bash, c, clojure, coffeescript, cpp, csharp, css, dart,
diff, docker, elixir, elm, erlang, flow, fortran, fsharp, gherkin, glsl,
go, graphql, groovy, haskell, html, java, javascript, json, julia, kotlin,
latex, less, lisp, livescript, lua, makefile, markdown, markup, matlab,
mermaid, nix, objective-c, ocaml, pascal, perl, php, plain text, powershell,
prolog, protobuf, python, r, reason, ruby, rust, sass, scala, scheme,
scss, shell, sql, swift, typescript, vb.net, verilog, vhdl, visual basic,
webassembly, xml, yaml
```

## API 端点

### 获取页面子 Block

```
GET /v1/blocks/{block_id}/children?page_size=100&start_cursor={cursor}
```

### 追加 Block

```
PATCH /v1/blocks/{block_id}/children
Body: {"children": [...]}
```

### 删除 Block

```
DELETE /v1/blocks/{block_id}
```

### 文件上传

```
POST /v1/file_uploads
Body: {"mode": "single_part"}

POST /v1/file_uploads/{id}/send
Body: multipart/form-data (file + file_upload_id)
```

## 限制

- 单次请求最多 100 个 Block
- 单个 rich_text 最多 2000 字符
- 单个 code Block 最多 2000 字符
- 表格最多 30 列
- 文件上传最大 20MB
