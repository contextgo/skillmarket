#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Invoice & Receipt Extractor - 中国电子发票/行程单批量提取工具

支持的文档类型:
  1. 电子发票（普通发票）- 新版全电发票，文本清晰
  2. 电子发票（增值税专用发票）- 新版全电专票
  3. 增值税电子普通发票 - 旧版（印章覆盖格式），部分信息被密文区遮挡
  4. 增值税电子专用发票 - 旧版专票
  5. 网约车行程单 - 享道/滴滴/高德/曹操等，非发票
  6. 机票报销凭证 - 实质是发票（经纪代理服务*机票款），含航班信息
  7. 结账单/账单 - 非发票，仅有消费记录

输出:
  - Excel工作簿，含发票明细、行程单明细、按月/季度/年度/类别汇总
"""

import os
import re
import sys
import json
import shutil
import hashlib
import zipfile
import argparse
import tempfile
from datetime import datetime
from collections import defaultdict
from xml.dom.minidom import parse as parse_xml

try:
    import pdfplumber
except ImportError:
    print("ERROR: pdfplumber not installed. Run: pip install pdfplumber")
    sys.exit(1)

try:
    from openpyxl import Workbook
    from openpyxl.styles import Font, Alignment, Border, Side, PatternFill, numbers
    from openpyxl.utils import get_column_letter
except ImportError:
    print("ERROR: openpyxl not installed. Run: pip install openpyxl")
    sys.exit(1)


# ============================================================
# Document Classification
# ============================================================

# ============================================================
# Expense Category Classification (报销类别分类)
# ============================================================

EXPENSE_CATEGORIES = {
    '综合费用': {
        '招待费': {
            'seller_keywords': ['餐饮', '餐厅', '酒楼', '饭店', '酒店', '咖啡', '茶', '酒吧', 'KTV', '娱乐'],
            'item_keywords': ['餐饮', '餐费', '酒水', '茶', '咖啡', '娱乐', '招待']
        },
        '办公费': {
            'seller_keywords': ['办公', '文具', '耗材', '设备', '软件', '打印', '复印', '图文', '广告', '办公用品'],
            'item_keywords': ['办公', '文具', '耗材', '打印纸', '墨盒', '硒鼓', '软件', '设备']
        },
        '行政后勤': {
            'seller_keywords': ['物业', '保洁', '保安', '绿化', '维修', '水电', '燃气', '租赁', '房租'],
            'item_keywords': ['物业费', '保洁', '维修', '水电', '燃气', '房租', '租赁']
        },
        '采购垫付': {
            'seller_keywords': ['材料', '原料', '配件', '五金', '建材', '工具', '劳保', '用品'],
            'item_keywords': ['材料', '原料', '配件', '五金', '建材', '工具', '劳保用品']
        },
        '物流垫付': {
            'seller_keywords': ['物流', '快递', '货运', '运输', '仓储', '供应链', '速运'],
            'item_keywords': ['运费', '快递费', '物流', '运输', '仓储']
        },
        '其它': {
            'seller_keywords': [],
            'item_keywords': []
        }
    },
    '差旅费用': {
        '住宿': {
            'seller_keywords': ['酒店', '宾馆', '旅馆', '客栈', '民宿', '公寓'],
            'item_keywords': ['住宿', '房费', '客房'],
            'exclude_seller': ['餐饮', '餐厅', '酒楼']  # 排除餐饮类酒店
        },
        '交通': {
            'seller_keywords': ['滴滴', '出租车', '地铁', '公交', '高铁', '火车', '航空', '机票', '出行', '网约车', '享道', '曹操', '高德'],
            'item_keywords': ['打车', '出租车', '地铁', '公交', '高铁', '火车', '机票', '客运', '运输服务'],
            'doc_type': ['itinerary']  # 行程单也归入交通
        },
        '油补': {
            'seller_keywords': ['石油', '石化', '壳牌', '中石油', '中石化', '加油站', '油'],
            'item_keywords': ['汽油', '柴油', '加油', '油费']
        },
        '餐补': {
            'seller_keywords': ['餐饮', '餐厅', '快餐', '食堂', '便利店', '超市'],
            'item_keywords': ['餐饮', '餐费', '快餐', '工作餐'],
            'context': '差旅'  # 需要结合上下文判断是否为差旅餐补
        },
        '通讯': {
            'seller_keywords': ['电信', '移动', '联通', '话费', '宽带', '通讯'],
            'item_keywords': ['话费', '宽带', '通讯费', '流量']
        },
        '其它': {
            'seller_keywords': [],
            'item_keywords': []
        }
    }
}


def _classify_expense_category(result):
    """
    根据项目内容和销售方判断报销类别。
    
    优先级：项目内容 > 销售方
    返回: (大类, 子类别) 或 (None, None) 表示无法识别
    """
    seller = result.get('seller', '') or ''
    item = result.get('item', '') or ''
    doc_category = result.get('doc_category', '')
    
    seller_lower = seller.lower()
    item_lower = item.lower()
    
    # 行程单优先归入交通
    if doc_category == 'itinerary':
        return ('差旅费用', '交通')
    
    # 遍历所有类别进行匹配
    best_match = None
    best_score = 0
    
    for main_cat, subcats in EXPENSE_CATEGORIES.items():
        for sub_cat, rules in subcats.items():
            if sub_cat == '其它':
                continue
                
            score = 0
            matched = False
            
            # 检查排除项
            exclude_sellers = rules.get('exclude_seller', [])
            if any(excl in seller for excl in exclude_sellers):
                continue
            
            # 项目内容关键词匹配（权重高，优先判断）
            for kw in rules.get('item_keywords', []):
                if kw in item:
                    score += 10
                    matched = True
            
            # 销售方关键词匹配（辅助判断）
            for kw in rules.get('seller_keywords', []):
                if kw in seller:
                    score += 5
                    matched = True
            
            # 特殊规则：餐补需要结合上下文（有"差旅"或"出差"关键词才优先归入餐补）
            if sub_cat == '餐补':
                if '差旅' in item or '出差' in item or '差旅' in seller or '出差' in seller:
                    score += 3
                else:
                    score = max(0, score - 5)  # 非差旅场景的餐饮归入招待费
            
            if matched and score > best_score:
                best_score = score
                best_match = (main_cat, sub_cat)
    
    # 如果没有匹配到，尝试简单启发式规则（兜底）
    if best_match is None:
        # 检查项目内容中的关键词
        if any(kw in item for kw in ['打车', '出租车', '地铁', '公交', '高铁', '火车', '机票', '客运']):
            return ('差旅费用', '交通')
        elif any(kw in item for kw in ['住宿', '房费', '客房']):
            return ('差旅费用', '住宿')
        elif any(kw in item for kw in ['餐饮', '餐费', '酒水', '茶']):
            return ('综合费用', '招待费')
        elif any(kw in item for kw in ['汽油', '柴油', '加油']):
            return ('差旅费用', '油补')
        # 检查销售方
        elif any(kw in seller for kw in ['滴滴', '出租', '地铁', '公交', '高铁']):
            return ('差旅费用', '交通')
        elif any(kw in seller for kw in ['酒店', '宾馆', '旅馆']):
            return ('差旅费用', '住宿')
    
    return best_match if best_match else (None, None)


def _copy_invoices_by_category(results, output_base_dir, base_dir, duplicate_groups=None):
    """
    按报销类别复制发票到对应文件夹（跳过重复发票）。
    
    只处理 doc_category='invoice' 的发票，行程单和非发票不处理。
    重复发票只复制首次出现的，后续重复跳过。
    返回分类统计信息（基于去重后的结果）。
    """
    import shutil
    
    if duplicate_groups is None:
        duplicate_groups = {}
    
    # 构建重复索引集合：只保留每组第一个（索引最小的）
    duplicate_indices = set()
    for indices in duplicate_groups.values():
        sorted_indices = sorted(indices)
        duplicate_indices.update(sorted_indices[1:])  # 除第一个外都是重复
    
    stats = defaultdict(lambda: defaultdict(int))
    unclassified = []
    
    # 创建输出目录结构
    for main_cat in EXPENSE_CATEGORIES.keys():
        for sub_cat in EXPENSE_CATEGORIES[main_cat].keys():
            cat_dir = os.path.join(output_base_dir, main_cat, sub_cat)
            os.makedirs(cat_dir, exist_ok=True)
    
    # 创建待确认目录
    pending_dir = os.path.join(output_base_dir, '待确认')
    os.makedirs(pending_dir, exist_ok=True)
    
    for idx, result in enumerate(results):
        if result.get('doc_category') != 'invoice':
            continue  # 只处理发票
        
        # 跳过重复发票（保留首次出现的）
        if idx in duplicate_indices:
            continue
        
        # 获取源文件路径
        filepath = result.get('filepath', '')
        source_zip = result.get('source_zip')
        
        if not filepath or not os.path.exists(filepath):
            continue
        
        # 分类
        main_cat, sub_cat = _classify_expense_category(result)
        
        if main_cat is None:
            # 无法识别，放入待确认
            target_dir = pending_dir
            unclassified.append(result)
            stats['待确认']['count'] += 1
        else:
            target_dir = os.path.join(output_base_dir, main_cat, sub_cat)
            stats[main_cat][sub_cat] += 1
        
        # 复制文件
        try:
            if source_zip:
                # ZIP内文件：从临时目录复制，保持原文件名
                filename = os.path.basename(result.get('zip_inner_path', ''))
                if not filename:
                    filename = os.path.basename(filepath)
            else:
                filename = os.path.basename(filepath)
            
            target_path = os.path.join(target_dir, filename)
            
            # 处理重名
            counter = 1
            base_name, ext = os.path.splitext(filename)
            while os.path.exists(target_path):
                target_path = os.path.join(target_dir, f"{base_name}_{counter}{ext}")
                counter += 1
            
            shutil.copy2(filepath, target_path)
            
        except Exception as e:
            print(f"  [WARN] 复制失败 {filename}: {e}")
            stats['复制失败']['count'] = stats['复制失败'].get('count', 0) + 1
    
    return stats, unclassified


# ============================================================
# OFD Parsing
# ============================================================

def _ofd_extract_customdatas(ofd_xml_content):
    """从OFD.xml的CustomDatas节点提取键值对。"""
    result = {}
    try:
        from io import BytesIO
        doc = parse_xml(BytesIO(ofd_xml_content.encode('utf-8')))
        nodes = doc.getElementsByTagName('ofd:CustomData')
        for node in nodes:
            name = node.getAttribute('Name')
            if name and node.firstChild:
                result[name] = node.firstChild.data.strip()
    except Exception:
        pass
    return result


def _ofd_extract_text_from_content(content_xml):
    """从OFD Content.xml中提取所有文本内容（智能拼接相邻片段）。
    
    返回两种格式：
    - 单一拼接文本（空格分隔），便于正则匹配
    - 有序列表，便于按位置关联字段
    """
    texts = re.findall(r'<ofd:TextCode[^>]*>([^<]+)</ofd:TextCode>', content_xml)
    # Filter whitespace-only
    texts = [t.strip() for t in texts if t.strip()]
    # 将所有片段用空格拼接为单一文本，方便正则匹配
    return ' '.join(texts)


def _ofd_extract_text_list_from_content(content_xml):
    """从OFD Content.xml中提取所有文本片段为有序列表。"""
    texts = re.findall(r'<ofd:TextCode[^>]*>([^<]+)</ofd:TextCode>', content_xml)
    return [t.strip() for t in texts if t.strip()]


def _ofd_smart_field_extract(text_list):
    """从OFD文本片段列表中，用位置关联方式智能提取字段。
    
    OFD的TextCode经常把标签和值拆开，如:
    ["发票号码：", "26327000000460023238", "开票日期：", "2026年03月04日"]
    通过识别标签后紧跟的值来提取。
    """
    result = {}
    
    # 建立标签到字段的映射（标签关键词 -> 字段名）
    label_map = {
        '发票号码': 'invoice_no',
        '开票日期': 'date',
        '开票人': 'issuer',
    }
    
    # 先合并相邻的碎片段（如"购""买""方" -> "购买方"）
    # 但保留原始分隔（如"："），只合并没有标点的单字
    merged = []
    i = 0
    while i < len(text_list):
        frag = text_list[i]
        # 只合并纯中文单字且不含标点的片段
        if (len(frag) == 1 and '\u4e00' <= frag <= '\u9fff' 
                and i + 1 < len(text_list) 
                and len(text_list[i+1]) == 1 
                and '\u4e00' <= text_list[i+1] <= '\u9fff'):
            combined = frag
            j = i + 1
            while j < len(text_list) and len(text_list[j]) == 1 and '\u4e00' <= text_list[j] <= '\u9fff':
                combined += text_list[j]
                j += 1
            merged.append(combined)
            i = j
        else:
            merged.append(frag)
            i += 1
    
    # 从合并后的列表中提取标签-值对
    for i, frag in enumerate(merged):
        for label, field in label_map.items():
            # 标签匹配：frag 以 label 开头，或 frag 就是 label
            if frag == label or frag.startswith(label + '：') or frag.startswith(label + ':'):
                # 情况1: "发票号码：26327000000460023238" (值在同一个frag中)
                if '：' in frag or ':' in frag:
                    after_colon = re.split(r'[：:]', frag, maxsplit=1)
                    if len(after_colon) > 1 and after_colon[1].strip():
                        result[field] = after_colon[1].strip()
                    elif i + 1 < len(merged):
                        # 值在下一个片段
                        next_val = merged[i + 1]
                        # 验证：值不应是另一个标签
                        if not any(next_val.startswith(lb) for lb in label_map):
                            result[field] = next_val
                elif i + 1 < len(merged):
                    # 标签和值分开
                    next_val = merged[i + 1]
                    if not any(next_val.startswith(lb) for lb in label_map):
                        result[field] = next_val
    
    # 提取公司名 - 找包含"有限公司""股份公司"等的片段
    companies = []
    company_pattern = r'([\u4e00-\u9fa5（）()\w]+(?:有限责任公司|有限公司|股份公司|合伙|商行|酒店|宾馆|餐厅|餐饮|商店|经营部))'
    for frag in merged:
        m = re.search(company_pattern, frag)
        if m:
            companies.append(m.group(1))
    
    if not result.get('buyer') and len(companies) >= 1:
        result['buyer'] = companies[0]
    if not result.get('seller') and len(companies) >= 2:
        result['seller'] = companies[1]
    
    # 验证提取结果：发票号码应为纯数字
    if result.get('invoice_no') and not re.match(r'^\d+$', result['invoice_no']):
        del result['invoice_no']
    # 日期应含数字
    if result.get('date') and not re.search(r'\d', result['date']):
        del result['date']
    # 开票人不应是纯数字长串
    if result.get('issuer') and re.match(r'^\d{10,}$', result['issuer']):
        del result['issuer']
    
    return result


def _ofd_find_attachment_xml(z, attachments_xml_content):
    """从Attachments.xml中找到附加的发票数据XML并读取。"""
    try:
        from io import BytesIO
        doc = parse_xml(BytesIO(attachments_xml_content.encode('utf-8')))
        attachments = doc.getElementsByTagName('ofd:Attachment')
        for att in attachments:
            file_loc_node = att.getElementsByTagName('ofd:FileLoc')
            if file_loc_node and file_loc_node[0].firstChild:
                file_loc = file_loc_node[0].firstChild.data.strip()
                # 尝试在Attachs目录下读取
                for prefix in ['Doc_0/Attachs/', 'Attachs/', '']:
                    try:
                        content = z.read(prefix + file_loc).decode('utf-8')
                        return content
                    except KeyError:
                        continue
    except Exception:
        pass
    return None


def _parse_xbrl_air_ticket(xbrl_content):
    """解析XBRL格式的机票报销凭证XML。"""
    result = {}
    try:
        from io import BytesIO
        doc = parse_xml(BytesIO(xbrl_content.encode('utf-8')))
        
        # 机票号码
        nodes = doc.getElementsByTagName('atr:ElectronicInvoiceAirTransportReceiptNumber')
        if nodes and nodes[0].firstChild:
            result['invoice_no'] = nodes[0].firstChild.data.strip()
        
        # 乘机人
        nodes = doc.getElementsByTagName('atr:PassengerName')
        if nodes and nodes[0].firstChild:
            result['passenger'] = nodes[0].firstChild.data.strip()
        
        # 身份证号
        nodes = doc.getElementsByTagName('atr:ValidIdNumber')
        if nodes and nodes[0].firstChild:
            result['id_number'] = nodes[0].firstChild.data.strip()
        
        # 出发站
        nodes = doc.getElementsByTagName('atr:DepartureStation')
        if nodes and nodes[0].firstChild:
            result['departure'] = nodes[0].firstChild.data.strip()
        
        # 到达站
        nodes = doc.getElementsByTagName('atr:DestinationStation')
        if nodes and nodes[0].firstChild:
            result['arrival'] = nodes[0].firstChild.data.strip()
        
        # 航班号
        nodes = doc.getElementsByTagName('atr:Flight')
        if nodes and nodes[0].firstChild:
            result['flight_no'] = nodes[0].firstChild.data.strip()
        
        # 承运人
        nodes = doc.getElementsByTagName('atr:Carrier')
        if nodes and nodes[0].firstChild:
            result['carrier'] = nodes[0].firstChild.data.strip()
        
        # 航班日期
        nodes = doc.getElementsByTagName('atr:CarrierDate')
        if nodes and nodes[0].firstChild:
            result['flight_date'] = nodes[0].firstChild.data.strip()
        
        # 出发时间
        nodes = doc.getElementsByTagName('atr:DepartureTime')
        if nodes and nodes[0].firstChild:
            result['departure_time'] = nodes[0].firstChild.data.strip()
        
        # 票价
        nodes = doc.getElementsByTagName('atr:Fare')
        if nodes and nodes[0].firstChild:
            try:
                result['amount'] = float(nodes[0].firstChild.data.strip())
            except ValueError:
                pass
        
        # 燃油附加费
        nodes = doc.getElementsByTagName('atr:FuelSurcharge')
        if nodes and nodes[0].firstChild:
            try:
                result['fuel_surcharge'] = float(nodes[0].firstChild.data.strip())
            except ValueError:
                pass
        
        # 税率
        nodes = doc.getElementsByTagName('atr:VatRate')
        if nodes and nodes[0].firstChild:
            try:
                rate = float(nodes[0].firstChild.data.strip())
                result['tax_rate'] = f"{rate*100:.0f}%"
            except ValueError:
                pass
        
        # 税额
        nodes = doc.getElementsByTagName('atr:VatTaxAmount')
        if nodes and nodes[0].firstChild:
            try:
                result['tax'] = float(nodes[0].firstChild.data.strip())
            except ValueError:
                pass
        
        # 民航发展基金
        nodes = doc.getElementsByTagName('atr:CivilAviationDevelopmentFund')
        if nodes and nodes[0].firstChild:
            try:
                result['civil_aviation_fund'] = float(nodes[0].firstChild.data.strip())
            except ValueError:
                pass
        
        # 价税合计
        nodes = doc.getElementsByTagName('atr:TotalAmount')
        if nodes and nodes[0].firstChild:
            try:
                result['total'] = float(nodes[0].firstChild.data.strip())
            except ValueError:
                pass
        
        # 开票日期
        nodes = doc.getElementsByTagName('atr:IssueDate')
        if nodes and nodes[0].firstChild:
            date_str = nodes[0].firstChild.data.strip()
            # 2025-10-11 -> 2025-10-11
            result['date'] = date_str
        
        # 购买方名称
        nodes = doc.getElementsByTagName('atr:NameOfPurchaser')
        if nodes and nodes[0].firstChild:
            result['buyer'] = nodes[0].firstChild.data.strip()
        
        # 销售方名称
        nodes = doc.getElementsByTagName('atr:NameOfSeller')
        if nodes and nodes[0].firstChild:
            result['seller'] = nodes[0].firstChild.data.strip()
        
        # 签发方（代理）
        nodes = doc.getElementsByTagName('atr:IssueParty')
        if nodes and nodes[0].firstChild:
            result['issuer'] = nodes[0].firstChild.data.strip()
        
        # 电子客票号
        nodes = doc.getElementsByTagName('atr:ETicketNumber')
        if nodes and nodes[0].firstChild:
            result['e_ticket_no'] = nodes[0].firstChild.data.strip()
        
        # 国内/国际
        nodes = doc.getElementsByTagName('atr:MarkingOfDomesticOrInternational')
        if nodes and nodes[0].firstChild:
            result['domestic_or_intl'] = nodes[0].firstChild.data.strip()
        
    except Exception:
        pass
    return result


def process_ofd_file(filepath):
    """处理OFD格式文件，自动识别类型并提取信息。
    
    OFD文件本质是ZIP压缩包，内部XML结构存储发票数据。
    支持三种OFD内部结构：
    1. 机票报销凭证：有Attachs/atr_issuer_*.xml (XBRL格式)
    2. 普通发票：OFD.xml的CustomDatas含关键字段
    3. 简化格式：需从Content.xml的TextCode提取文本
    """
    filename = os.path.basename(filepath)
    result = {
        'filename': filename,
        'filepath': filepath,
    }
    
    try:
        with zipfile.ZipFile(filepath, 'r') as z:
            # ---- Step 1: 检查是否有XBRL机票附件 ----
            namelist = z.namelist()
            xbrl_files = [n for n in namelist if 'atr_issuer' in n and n.endswith('.xml')]
            
            if xbrl_files:
                # 机票报销凭证 - 从XBRL提取
                xbrl_content = z.read(xbrl_files[0]).decode('utf-8')
                extracted = _parse_xbrl_air_ticket(xbrl_content)
                result.update(extracted)
                result['doc_category'] = 'invoice'
                result['invoice_type'] = '机票报销凭证'
                
                # 从OFD.xml补充信息
                try:
                    ofd_xml = z.read('OFD.xml').decode('utf-8')
                    custom = _ofd_extract_customdatas(ofd_xml)
                    # 补充缺失的字段
                    if not result.get('invoice_no') and custom.get('发票号码'):
                        result['invoice_no'] = custom['发票号码']
                except Exception:
                    pass
                
                return result
            
            # ---- Step 2: 读取OFD.xml的CustomDatas ----
            ofd_xml = z.read('OFD.xml').decode('utf-8')
            custom = _ofd_extract_customdatas(ofd_xml)
            
            # ---- Step 3: 读取Content.xml提取文本 ----
            text = ''
            text_list = []
            content_files = [n for n in namelist if n.endswith('Content.xml') and 'Page' in n]
            for cf in content_files:
                try:
                    page_content = z.read(cf).decode('utf-8')
                    text += _ofd_extract_text_from_content(page_content) + '\n'
                    text_list.extend(_ofd_extract_text_list_from_content(page_content))
                except Exception:
                    pass
            
            # ---- Step 4: 分类 ----
            doc_category, invoice_type = classify_document(filename, text)
            result['doc_category'] = doc_category
            result['invoice_type'] = invoice_type
            
            # ---- Step 5: 用CustomDatas提取关键字段 ----
            if custom:
                if custom.get('发票号码'):
                    result['invoice_no'] = custom['发票号码']
                if custom.get('开票日期'):
                    # "2025年12月31日" -> "2025-12-31"
                    m = re.search(r'(\d{4})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日', custom['开票日期'])
                    if m:
                        result['date'] = f"{m.group(1)}-{m.group(2).zfill(2)}-{m.group(3).zfill(2)}"
                    else:
                        result['date'] = custom['开票日期']
                if custom.get('合计金额'):
                    try:
                        result['amount'] = float(custom['合计金额'])
                    except ValueError:
                        pass
                if custom.get('合计税额'):
                    try:
                        result['tax'] = float(custom['合计税额'])
                    except ValueError:
                        pass
                if custom.get('购买方纳税人识别号'):
                    result['buyer_tax_id'] = custom['购买方纳税人识别号']
                if custom.get('销售方纳税人识别号'):
                    result['seller_tax_id'] = custom['销售方纳税人识别号']
            
            # ---- Step 6: 从文本补充缺失字段 ----
            if text:
                # OFD文本是空格拼接的，需适配正则
                if not result.get('invoice_no'):
                    # OFD中"发票号码："和号码可能被空格分开
                    m = re.search(r'发票号码[：:]\s*(\d{10,20})', text)
                    if not m:
                        # 号码可能在"发票号码："标签后面的独立片段中
                        m = re.search(r'发票号码[：:]\s+(\d{10,20})', text)
                    if m:
                        result['invoice_no'] = m.group(1)
                
                if not result.get('date'):
                    m = re.search(r'开票日期[：:]\s*(\d{4})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日', text)
                    if m:
                        result['date'] = f"{m.group(1)}-{m.group(2).zfill(2)}-{m.group(3).zfill(2)}"
                
                # 购买方和销售方 - OFD中"购 买 方 信 息 名称：公司名"格式
                if not result.get('buyer'):
                    m = re.search(r'购\s*买\s*方\s*.*?名称[：:]\s*([\u4e00-\u9fa5（）()][\u4e00-\u9fa5（）()\w]+)', text, re.DOTALL)
                    if not m:
                        m = re.search(r'名称[：:]\s*([\u4e00-\u9fa5（）()][\u4e00-\u9fa5（）()\w]+)', text, re.DOTALL)
                    if m:
                        val = m.group(1).strip()
                        # 检查是否误提取到标签文字
                        if '统一社会' not in val and '纳税人' not in val:
                            result['buyer'] = val
                
                if not result.get('seller'):
                    m = re.search(r'销\s*售\s*方\s*.*?名称[：:]\s*([\u4e00-\u9fa5（）()][\u4e00-\u9fa5（）()\w]+)', text, re.DOTALL)
                    if m:
                        val = m.group(1).strip()
                        if '统一社会' not in val and '纳税人' not in val:
                            result['seller'] = val
                    if not result.get('seller'):
                        # 取第二个"名称："后面的公司名
                        name_matches = re.findall(r'名称[：:]\s*([\u4e00-\u9fa5（）()][\u4e00-\u9fa5（）()\w]+)', text)
                        valid_names = [n.strip() for n in name_matches if '统一社会' not in n and '纳税人' not in n]
                        if len(valid_names) >= 2:
                            result['seller'] = valid_names[1]
                
                if not result.get('item'):
                    m = re.search(r'\*[^*]+\*\S+', text)
                    if m:
                        result['item'] = m.group(0).strip()
                
                if not result.get('tax_rate'):
                    m = re.search(r'(\d+(?:\.\d+)?%)', text)
                    if m:
                        result['tax_rate'] = m.group(1)
                
                # 价税合计 - OFD中"（ 小 写 ） ¥ 15.93"
                if not result.get('total'):
                    # 优先找"小写"后面紧跟的¥金额（价税合计）
                    m = re.search(r'小\s*写\s*[)）]?\s*[¥￥]\s*([\d,]+\.?\d*)', text)
                    if not m:
                        # 尝试找大写金额后面的¥（跳过中间文本）
                        m = re.search(r'[零壹贰叁肆伍陆柒捌玖拾佰仟万亿圆角分整]+.*?[¥￥]\s*([\d,]+\.?\d*)', text)
                    if m:
                        val = _clean_amount(m.group(1).replace(',', ''))
                        if val:
                            result['total'] = float(val)
                    else:
                        # 最后一个¥值通常是价税合计
                        all_yen = re.findall(r'[¥￥]\s*([\d,]+\.\d{2})', text)
                        if all_yen:
                            val = _clean_amount(all_yen[-1].replace(',', ''))
                            if val:
                                result['total'] = float(val)
                
                # 金额和税额（从合计行 ¥15.47 ¥0.46）
                if not result.get('amount') or not result.get('tax'):
                    # 找所有¥后面的金额
                    all_yen_vals = re.findall(r'[¥￥]\s*([\d,]+\.?\d*)', text)
                    if len(all_yen_vals) >= 2:
                        # 合计行通常有两个¥：金额和税额
                        # 但也可能有更多（单价、金额、税额等）
                        # 找合计标识后的¥值
                        m = re.search(r'合\s*计\s*(?:[¥￥]\s*([\d,]+\.?\d*)\s*)+(?:[¥￥]\s*([\d,]+\.?\d*))?', text)
                        if m:
                            # 取合计行最后一个¥值作为税额
                            m2 = re.findall(r'[¥￥]\s*([\d,]+\.?\d*)', text[text.find('合'):text.find('合')+100] if '合' in text else '')
                            if len(m2) >= 2:
                                val1 = _clean_amount(m2[0].replace(',', ''))
                                val2 = _clean_amount(m2[-1].replace(',', ''))
                                if val1 and not result.get('amount'):
                                    result['amount'] = float(val1)
                                if val2 and not result.get('tax'):
                                    result['tax'] = float(val2)
                
                # 大写金额
                if not result.get('total_cn'):
                    cn_num_pattern = r'[零壹贰叁肆伍陆柒捌玖拾佰仟万亿圆角分整]+'
                    m = re.search(cn_num_pattern, text)
                    if m and len(m.group(0)) >= 3:
                        result['total_cn'] = m.group(0)
                
                # 开票人 - OFD中"开 票 人 ： 姓名"
                if not result.get('issuer'):
                    m = re.search(r'开\s*票\s*[人⼈][：:]\s*(\S+)', text)
                    if m:
                        val = m.group(1).strip()
                        # 避免把发票号码或标签文字当成开票人
                        if not re.match(r'^\d{10,}$', val) and val not in ('项目名称', '单价', '金额'):
                            result['issuer'] = val
                
                # 行程单特殊字段
                if doc_category == 'itinerary':
                    itn = extract_itinerary(text)
                    result.update(itn)
                
                # ---- Step 6b: 智能字段提取（正则无法处理OFD碎片文本时的后备方案）----
                smart_result = _ofd_smart_field_extract(text_list)
                if not result.get('invoice_no') and smart_result.get('invoice_no'):
                    result['invoice_no'] = smart_result['invoice_no']
                if not result.get('date') and smart_result.get('date'):
                    date_val = smart_result['date']
                    m = re.search(r'(\d{4})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日', date_val)
                    if m:
                        result['date'] = f"{m.group(1)}-{m.group(2).zfill(2)}-{m.group(3).zfill(2)}"
                    else:
                        result['date'] = date_val
                if not result.get('buyer') and smart_result.get('buyer'):
                    result['buyer'] = smart_result['buyer']
                if not result.get('seller') and smart_result.get('seller'):
                    result['seller'] = smart_result['seller']
                if not result.get('issuer') and smart_result.get('issuer'):
                    val = smart_result['issuer']
                    if not re.match(r'^\d{10,}$', val):
                        result['issuer'] = val
            
            # ---- Step 7: 如果CustomDatas有金额但缺total，尝试计算 ----
            if result.get('amount') and result.get('tax') and not result.get('total'):
                result['total'] = result['amount'] + result['tax']
            
    except zipfile.BadZipFile:
        result['doc_category'] = 'unknown'
        result['invoice_type'] = 'OFD文件'
        result['error'] = 'OFD文件损坏或不是有效的ZIP格式'
    except Exception as e:
        result['doc_category'] = 'unknown'
        result['invoice_type'] = 'OFD文件'
        result['error'] = f'OFD解析失败: {str(e)}'
    
    return result

def _clean_amount(s):
    """清理PDF提取中常见的金额字符串问题。
    
    常见问题:
    - 字符重叠: "6622..8811" -> "66.81"
    - 多余小数点: "66..81" -> "66.81"
    """
    if not s:
        return None
    # 尝试直接转换
    try:
        float(s)
        return s
    except ValueError:
        pass
    # 处理重叠字符: 每隔一个字符取一个
    # 但只对看起来像重叠的模式处理
    if '..' in s:
        # 双点问题: "6622..8811" 
        # 尝试取前半部分
        parts = s.split('..')
        if len(parts) == 2:
            left = parts[0]
            right = parts[1]
            # 如果 right 长度是 left 的2倍，可能右半部分也是重叠的
            if len(right) >= len(left):
                cleaned = left + '.' + right[:len(left)]
                try:
                    float(cleaned)
                    return cleaned
                except ValueError:
                    pass
    
    # 最后尝试取第一个合理的数字
    m = re.match(r'(\d+\.\d{1,2})', s)
    if m:
        return m.group(1)
    
    return None


def _normalize_text_for_match(text):
    """去除文本中的空格和零宽字符，用于模糊匹配。
    旧版发票PDF提取后关键词被空格打断，如"增 值 税 电 子 普 通 发 票"。
    全电发票可能用异体字，如"电⼦发票"（⼦是CJK兼容字符U+2F26）。
    重叠打印导致字符重复，如"电电子子发发票票"需要去重为"电子发票"。
    """
    # 去除零宽字符和特殊空格
    text = re.sub(r'[\u200b\u200c\u200d\ufeff\u00a0]', '', text)
    # CJK兼容异体字替换为常用字
    compat_map = {'⼦': '子', '⽅': '方', '⽓': '气', '⽤': '用', '⽇': '日',
                  '⽉': '月', '⼀': '一', '⼆': '二', '⼈': '人', '⼊': '入',
                  '⼒': '力', '⼝': '口', '⼤': '大', '⼥': '女', '⼭': '山',
                  '⼯': '工', '⼼': '心', '⽂': '文', '⽊': '木', '⽔': '水',
                  '⽕': '火', '⼟': '土', '⾦': '金', '⾷': '食', '⾼': '高',
                  '⻓': '长', '⻔': '门', '⻋': '车', '⻛': '风', '⻦': '鸟',
                  '⻢': '马', '⿊': '黑', '⿓': '龙', '⿎': '鼓', '⼴': '广',
                  '⼚': '厂', '⼏': '几', '⼩': '小', '⼨': '寸', '⼰': '己',
                  '⼳': '幺', '⻨': '麦', '⻩': '黄', '⻬': '齐', '⻰': '龙',
                  '⻱': '龟', '⻲': '龟', '⾦': '金', '⽅': '方', '⻝': '食'}
    for k, v in compat_map.items():
        text = text.replace(k, v)
    # 去除空格
    text = re.sub(r'\s+', '', text)
    # 去除重叠打印导致的连续重复字符（如"电电子子" → "电子"）
    # 但只去除中文字符的连续重复，避免影响数字（如"11"）
    text = re.sub(r'([\u4e00-\u9fff\u2e80-\u2fdf\u3000-\u303f\uff00-\uffef（）])\1+', r'\1', text)
    return text


def classify_document(filename, text):
    """根据文件名和内容判断文档类型。
    
    返回: (doc_category, invoice_type)
      doc_category: 'invoice' | 'itinerary' | 'receipt' | 'unknown'
      invoice_type: 具体发票/凭证类型名称
    """
    fn = filename.lower()
    
    # 通行费电子行程单 - 非发票（优先判断，避免被发票规则误收）
    if text and '通行费' in text and '行程单' in text:
        return 'itinerary', '通行费行程单'
    
    # 行程单 - 非发票
    if any(kw in fn for kw in ['行程单', '行程报销单']):
        return 'itinerary', '网约车行程单'
    if any(kw in fn for kw in ['享道出行', '滴滴出行', '高德打车', '曹操出行']):
        if '行程' in fn and '发票' not in fn:
            return 'itinerary', '网约车行程单'
    
    # 结账单 - 非发票
    if '结账单' in fn or ('账单' in fn and '发票' not in fn):
        return 'receipt', '结账单'
    
    # 机票报销凭证 - 本质是发票，但有航班信息
    if '机票' in fn and '报销凭证' in fn:
        return 'invoice', '机票报销凭证'
    
    # 根据PDF/OFD文本内容判断
    if text:
        # 精确匹配（优先）
        if '电子发票（增值税专用发票）' in text or '电子发票(增值税专用发票)' in text:
            return 'invoice', '增值税专用发票'
        if '电子发票（普通发票）' in text or '电子发票(普通发票)' in text:
            return 'invoice', '全电普通发票'
        if '增值税电子专用发票' in text:
            return 'invoice', '增值税电子专用发票'
        if '增值税电子普通发票' in text:
            return 'invoice', '增值税电子普通发票'
        if '增值税普通发票' in text:
            return 'invoice', '增值税普通发票'
        if '增值税专用发票' in text:
            return 'invoice', '增值税专用发票'
        if '行程单' in text and ('出行' in text or '网约车' in text):
            return 'itinerary', '网约车行程单'
        
        # 航空运输电子客票行程单（新版，含"电子发票（航空运输电子客票行程单）"）
        if '航空运输电子客票行程单' in text:
            return 'invoice', '机票报销凭证'
        
        # 模糊匹配：去除空格和异体字后再匹配
        # 解决旧版发票关键词被空格打断的问题（如"增 值 税 电 子 普 通 发 票"）
        # 解决全电发票重叠字符问题（如"电⼦发票（普 通 发 票）"）
        norm_text = _normalize_text_for_match(text)
        
        if '电子发票（增值税专用发票）' in norm_text or '电子发票(增值税专用发票)' in norm_text:
            return 'invoice', '增值税专用发票'
        if '电子发票（普通发票）' in norm_text or '电子发票(普通发票)' in norm_text:
            return 'invoice', '全电普通发票'
        if '增值税电子专用发票' in norm_text:
            return 'invoice', '增值税电子专用发票'
        if '增值税电子普通发票' in norm_text:
            return 'invoice', '增值税电子普通发票'
        if '增值税普通发票' in norm_text:
            return 'invoice', '增值税普通发票'
        if '增值税专用发票' in norm_text:
            return 'invoice', '增值税专用发票'
        # 旧版发票"XX增值税电子普通发票"被省份名打断（如"江 苏 增 值 税 电 子 普 通 发 票"）
        if '增值税电子' in norm_text and '普通发票' in norm_text:
            return 'invoice', '增值税电子普通发票'
        if '增值税电子' in norm_text and '专用发票' in norm_text:
            return 'invoice', '增值税电子专用发票'
        
        # 全电发票（普通发票） - 重叠打印/异体字场景
        # 如"电⼦发票"（异体字）或"电电子子发发票票（（普普通通发发票票））"（重叠打印）
        if '电子发票' in norm_text and '普通发票' in norm_text:
            return 'invoice', '全电普通发票'
        if '电子发票' in norm_text and '增值税专用发票' in norm_text:
            return 'invoice', '增值税专用发票'
        # 打车发票等：重叠打印导致只有"电子发票"可识别 + 有20位发票号码
        has_20digit_no = bool(re.search(r'发票号码[：:]\s*\d{20}', text))
        if '电子发票' in norm_text and has_20digit_no:
            return 'invoice', '全电普通发票'
        # 哈啰打车等：异体字被normalize后"电子发票"出现，但"普通发票"被"统一发票监制"覆盖
        # 检查norm_text中是否包含"发票"+20位号码+"开票日期"+"价税合计"
        if ('发票' in norm_text and has_20digit_no and 
            '开票日期' in text and '价税合计' in text):
            return 'invoice', '全电普通发票'
        
        # 兜底：有发票代码+发票号码 但未被上述规则捕获
        # 典型场景：旧版增值税发票抬头被密文/印章覆盖导致关键词断裂
        has_code = bool(re.search(r'发票代码[：:]\s*\d{10,12}', text))
        has_number = bool(re.search(r'发票号码[：:]\s*\d{8}', text))
        if has_code and has_number:
            return 'invoice', '增值税电子普通发票'
    
    # 根据文件名中的代码格式推断
    # dzfp_ = 电子发票
    if 'dzfp_' in fn:
        return 'invoice', '全电普通发票'
    
    # 有发票号码格式的
    if re.search(r'\d{20,}', fn):
        return 'invoice', '电子发票'
    
    return 'unknown', '未识别'


# ============================================================
# Invoice Data Extraction
# ============================================================

def _extract_buyer_seller_from_tables(tables):
    """从PDF表格中提取购买方和销售方名称。
    
    全电发票的表格结构有两种：
    1. 紧凑型（前面修的3张发票）：
       ['购\n买\n方\n信\n息', '名称：xxx\n统一社会...', None, 
        '销\n售\n方\n信\n息', '名称：zzz\n统一社会...']
    2. 宽松型（41张bad发票）：
       Row: [None, '购\n买\n方\n信\n息', None, None, ..., '销\n售\n方\n信\n息', None, ...]
       Row: [None, None, None, '名称:湃', None, None, '特', '纳', ... , '名称:广州', None, '尚', '加', ...]
       Row: '湃特纳（佛山）机器人科技有限责任公司  广州尚加餐饮有限公司'
    
    策略：优先从"名称:"开头拼接后续cell；次选从独立文本行用公司名正则提取。
    """
    result = {}
    company_pattern = r'([\u4e00-\u9fa5（）()\w]+(?:有限责任公司|有限公司|股份公司))'
    
    for table in tables:
        if not table:
            continue
        for row in table:
            if not row:
                continue
            # 拼接所有单元格文本（去除换行后再检查关键词）
            row_text = ' '.join(str(c) for c in row if c)
            row_text_flat = row_text.replace('\n', '')
            if '购买方' not in row_text_flat and '买方' not in row_text_flat:
                continue
            
            # 策略1: 检查是否有含"名称:"的cell（紧凑型表格）
            has_name_cell = False
            for cell in row:
                if cell and '名称' in str(cell):
                    has_name_cell = True
                    break
            
            if has_name_cell:
                for i, cell in enumerate(row):
                    if not cell:
                        continue
                    cell_text = str(cell)
                    if '名称' not in cell_text:
                        continue
                    m = re.search(r'名称[：:]\s*(.+?)(?:\n|统一社会|$)', cell_text)
                    if m and m.group(1).strip():
                        name = m.group(1).strip()
                        # 判断买卖方：cell index小的=购买方，大的=销售方
                        mid = len(row) // 2
                        if i <= mid:
                            result.setdefault('buyer', name)
                        else:
                            result.setdefault('seller', name)
            
            # 策略2: 宽松型表格——"名称:"开头但cell被拆成单字
            # 找"名称:"开头的cell，然后拼接后续cell直到遇到None或另一个"名称:"
            if not result.get('buyer') or not result.get('seller'):
                i = 0
                while i < len(row):
                    cell = row[i]
                    if cell is None:
                        i += 1
                        continue
                    cell_text = str(cell)
                    if '名称' in cell_text:
                        # 从"名称:"后面开始拼接
                        m = re.search(r'名称[：:]\s*(.*)', cell_text)
                        if m:
                            parts = [m.group(1)] if m.group(1).strip() else []
                            j = i + 1
                            while j < len(row):
                                next_cell = row[j]
                                if next_cell is None:
                                    j += 1
                                    continue
                                next_text = str(next_cell)
                                # 遇到另一个"名称"就停
                                if '名称' in next_text:
                                    break
                                # 遇到非中文字符或关键字就停
                                if any(kw in next_text for kw in ['统一社会', '纳税人', '信用代码']):
                                    break
                                parts.append(next_text)
                                j += 1
                            name = ''.join(parts).strip()
                            if name and ('有限公司' in name or '股份' in name or '公司' in name):
                                mid = len(row) // 2
                                if i <= mid and 'buyer' not in result:
                                    result['buyer'] = name
                                elif i > mid and 'seller' not in result:
                                    result['seller'] = name
                    i += 1
            
            if 'buyer' in result and 'seller' in result:
                return result
    
    # 策略3: 如果只找到一个或都没找到，从所有表格行中搜公司名
    # 通常是Row 11的合并文本行
    if not result.get('buyer') or not result.get('seller'):
        for table in tables:
            if not table:
                continue
            for row in table:
                if not row:
                    continue
                row_text = ' '.join(str(c) for c in row if c).replace('\n', '')
                companies = re.findall(company_pattern, row_text)
                if len(companies) >= 2:
                    # 第一个通常是购买方，第二个是销售方
                    result.setdefault('buyer', companies[0])
                    result.setdefault('seller', companies[1])
                    return result
                elif len(companies) == 1:
                    # 只找到一个公司名——如果在后半部分更可能是销售方
                    mid = len(row) // 2
                    first_half = ' '.join(str(c) for c in row[:mid] if c).replace('\n', '')
                    if companies[0] in first_half:
                        result.setdefault('buyer', companies[0])
                    else:
                        result.setdefault('seller', companies[0])
    
    return result


def extract_new_electronic_invoice(text, tables=None):
    """提取新版全电发票信息（文本清晰，结构化好）。
    也处理重叠打印的全电发票（打车发票等），文本中买卖方信息顺序混乱。
    当文本提取失败时，从表格数据中补充。
    """
    result = {}
    
    # 发票号码 (20位) - 可能在文本任意位置
    m = re.search(r'发票号码[：:]\s*(\d{20})', text)
    if not m:
        # 重叠打印场景：号码可能跟在"发票号码"后面很远
        # 或在印章行中："制 26322000002731187161\n全 章\n国家税务总局"
        m = re.search(r'发票号码[：:]\s*\n.*?(\d{20})', text, re.DOTALL)
    if not m:
        # 在"统一发票监制"印章行附近找20位号码
        m = re.search(r'(?:制|章)\s*(\d{20})', text)
    if not m:
        # 兜底：文本中任意20位数字
        m = re.search(r'(\d{20})', text)
    if m:
        result['invoice_no'] = m.group(1)
    
    # 开票日期
    m = re.search(r'开票日期[：:]\s*(\d{4})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日', text)
    if not m:
        # 重叠打印场景：日期在"国家税务总局 YYYY年MM月DD日"后面
        m = re.search(r'国家税务总局\s*(\d{4})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日', text)
    if not m:
        # 带异体字的日期："2026年04⽉08⽇"
        norm_date_text = _normalize_text_for_match(text)
        m = re.search(r'开票日期[：:]?\s*(\d{4})年(\d{1,2})月(\d{1,2})日', norm_date_text)
        if not m:
            m = re.search(r'国家税务总局\s*(\d{4})年(\d{1,2})月(\d{1,2})日', norm_date_text)
    if m:
        result['date'] = f"{m.group(1)}-{m.group(2).zfill(2)}-{m.group(3).zfill(2)}"
    
    # 购买方 - 支持多种格式
    # 格式1: "购 名称：xxx" 或 "购买方 名称：xxx"
    m = re.search(r'购(?:买方)?\s*名称[：:]\s*(.+?)(?:\s+销|统一社会|\n)', text, re.DOTALL)
    if not m:
        m = re.search(r'购买方.*?名称[：:]\s*(.+?)(?:\s|统一社会)', text, re.DOTALL)
    # 格式2: 重叠打印 "买 名称:xxx 售 名称:yyy"
    if not m:
        m = re.search(r'买\s*名称[：:]\s*(.+?)(?:\s+售|\s+方|统一社会)', text, re.DOTALL)
    if m:
        result['buyer'] = m.group(1).strip()
    
    # 销售方 - 支持多种格式
    # 格式1: "销 名称：xxx" 或 "销售方 名称：xxx"
    m = re.search(r'销(?:售方)?\s*名称[：:]\s*(.+?)(?:\s+方|统一社会|\n)', text, re.DOTALL)
    if not m:
        m = re.search(r'销售方.*?名称[：:]\s*(.+?)(?:\s|统一社会)', text, re.DOTALL)
    # 格式2: 重叠打印 "售 名称:xxx"
    if not m:
        m = re.search(r'售\s*名称[：:]\s*(.+?)(?:\s+方|统一社会|\n)', text, re.DOTALL)
    if m:
        result['seller'] = m.group(1).strip()
    
    # 从散落文本中提取买卖方（印章覆盖导致买卖方信息不在原位）
    # 如: "湃智造机器人科技（东莞）有限责任公司 南京中图文化实业有限公司禄口机场分公司"
    if 'buyer' not in result or 'seller' not in result:
        # 尝试从印章下方散落的文本中提取
        # 通常是购买方和销售方名称在同一行，用空格分隔
        company_pattern = r'([\u4e00-\u9fa5（）()\w]+(?:有限责任公司|有限公司|股份公司))'
        # 在"省税务局"之后、"统一社会信用代码"之前找
        tax_bureau_match = re.search(r'省税务局\s*\n(.+?)(?:\n\d)', text, re.DOTALL)
        if tax_bureau_match:
            companies_in_range = re.findall(company_pattern, tax_bureau_match.group(1))
            if len(companies_in_range) >= 2:
                result.setdefault('buyer', companies_in_range[0])
                result.setdefault('seller', companies_in_range[1])
            elif len(companies_in_range) == 1:
                result.setdefault('seller', companies_in_range[0])
    
    # 从表格数据中补充买卖方信息（优先级最高）
    if tables:
        table_info = _extract_buyer_seller_from_tables(tables)
        if table_info.get('buyer'):
            result['buyer'] = table_info['buyer']
        if table_info.get('seller'):
            result['seller'] = table_info['seller']
    
    # 全电发票下载件兜底：信息在文本后半部分散落
    # 格式: "24127000000072285981\n2024年08月19日\n湃特纳（佛山）机器人科技有限责任公司 去哪儿网（天津）国际旅行社有限公司\n..."
    if not result.get('buyer') or not result.get('seller'):
        company_pattern = r'([\u4e00-\u9fa5（）()\w]+(?:有限责任公司|有限公司|股份公司))'
        # 在"下载次数"之后搜索公司名
        download_idx = text.find('下载次数')
        if download_idx >= 0:
            after_download = text[download_idx:]
            companies = re.findall(company_pattern, after_download)
            # 排除银行
            bank_kw = ['银行']
            companies = [c for c in companies if not any(b in c for b in bank_kw)]
            if len(companies) >= 2:
                result.setdefault('buyer', companies[0])
                result.setdefault('seller', companies[1])
            elif len(companies) == 1:
                if 'buyer' not in result:
                    result['buyer'] = companies[0]
                else:
                    result['seller'] = companies[0]
    
    # 如果没有发票号码，在"下载次数"后搜索20位号码
    if not result.get('invoice_no'):
        download_idx = text.find('下载次数')
        if download_idx >= 0:
            after_download = text[download_idx:]
            m = re.search(r'(\d{20})', after_download)
            if m:
                result['invoice_no'] = m.group(1)
    
    # 如果没有日期，在"下载次数"后搜索日期
    if not result.get('date'):
        download_idx = text.find('下载次数')
        if download_idx >= 0:
            after_download = text[download_idx:]
            m = re.search(r'(\d{4})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日', after_download)
            if m:
                result['date'] = f"{m.group(1)}-{m.group(2).zfill(2)}-{m.group(3).zfill(2)}"
    
    # 项目名称
    m = re.search(r'\*[^*]+\*[^\s\d]+', text)
    if m:
        result['item'] = m.group(0).strip()
    
    # 金额(不含税)
    m = re.search(r'合\s*计\s*[¥￥]?\s*([\d,]+\.?\d*)', text)
    if m:
        val = _clean_amount(m.group(1).replace(',', ''))
        if val:
            result['amount'] = float(val)
    
    # 税率
    m = re.search(r'(\d+(?:\.\d+)?%)', text)
    if m:
        result['tax_rate'] = m.group(1)
    
    # 税额 - 在合计之后
    m = re.search(r'合\s*计\s*[¥￥]?\s*[\d,]+\.?\d*\s*[¥￥]?\s*([\d,]+\.?\d*)', text)
    if m:
        val = _clean_amount(m.group(1).replace(',', ''))
        if val:
            result['tax'] = float(val)
    
    # 价税合计(小写)
    m = re.search(r'[（(]小写[)）]\s*[¥￥]?\s*([\d,]+\.?\d*)', text)
    if not m:
        m = re.search(r'价税合计.*?[¥￥]\s*([\d,]+\.?\d*)', text)
    if m:
        val = _clean_amount(m.group(1).replace(',', ''))
        if val:
            result['total'] = float(val)
    
    # 如果金额还是缺，从散落文本中找（全电发票下载件）
    if not result.get('total'):
        download_idx = text.find('下载次数')
        if download_idx >= 0:
            after_download = text[download_idx:]
            # 最后一个¥值通常是价税合计
            vals = re.findall(r'[¥￥]\s*([\d,]+\.?\d*)', after_download)
            if vals:
                try:
                    val = _clean_amount(vals[-1].replace(',', ''))
                    if val:
                        result['total'] = float(val)
                except (ValueError, TypeError):
                    pass
    
    # 如果金额还是缺，从"大写金额+¥数字"格式中找
    if not result.get('total'):
        m = re.search(r'[零壹贰叁肆伍陆柒捌玖拾佰仟万亿圆角分整]+\s*[¥￥]\s*([\d,]+\.?\d*)', text)
        if m:
            try:
                val = _clean_amount(m.group(1).replace(',', ''))
                if val:
                    result['total'] = float(val)
            except (ValueError, TypeError):
                pass
    
    # 价税合计(大写)
    m = re.search(r'价税合计[（(]大写[)）]\s*(.+?)(?:[（(]小写|$)', text)
    if m:
        result['total_cn'] = m.group(1).strip()
    
    # 开票人
    m = re.search(r'开票[人⼈][：:]\s*(\S+)', text)
    if m:
        result['issuer'] = m.group(1)
    
    return result


def extract_old_format_invoice(text, tables):
    """提取旧版增值税电子发票（印章覆盖格式）。
    这种格式的购买方/销售方名称被密文区覆盖，需要从表格中提取。"""
    result = {}
    
    # 发票代码
    m = re.search(r'发票代码[：:]\s*(\d+)', text)
    if not m:
        # 旧版发票：代码在"统一发票监"行（如"050002200311"）
        m = re.search(r'(?:统一发票监|机器编号[：:]?\s*\d+\s*)\s*(\d{12})', text)
    if m:
        result['invoice_code'] = m.group(1)
    
    # 发票号码
    m = re.search(r'发票号码[：:]\s*(\d+)', text)
    if not m:
        # 旧版发票：号码在"统一发票监"行后面（如"61133033"）
        # 格式: "统一发票监 61133033"
        m = re.search(r'统一发票监\s*(?:\w+\s*)*\s+(\d{8})', text)
    if not m:
        # 格式: "制\n全 国家税务总局 章 2023 12 20\n...80540 02353 15978 70179"
        # 8位号码可能在税局章附近
        m = re.search(r'税务局\s+([\d\s]{11,})', text)
        if m:
            # 提取第一个8位数字段
            digits = re.findall(r'\d{8}', m.group(1).replace(' ', ''))
            if digits:
                result['invoice_no'] = digits[0]
                m = None  # 避免下面重复赋值
    if m:
        result['invoice_no'] = m.group(1)
    
    # 开票日期 - 支持多种格式
    # 格式1: "2024年05月17日"
    m = re.search(r'(\d{4})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日', text)
    if m:
        result['date'] = f"{m.group(1)}-{m.group(2).zfill(2)}-{m.group(3).zfill(2)}"
    else:
        # 格式2: "开票日期: 2024 05 17" (日期无年月日分隔)
        m = re.search(r'开票日期[：:]\s*(\d{4})\s*(\d{2})\s*(\d{2})', text)
        if m:
            year = int(m.group(1))
            if 2020 <= year <= 2030:
                result['date'] = f"{m.group(1)}-{m.group(2)}-{m.group(3)}"
        else:
            # 格式3: "国家税务总局 章 2023 12 20" (印章行中)
            m = re.search(r'国家税务总局\s*章?\s*(\d{4})\s+(\d{1,2})\s+(\d{1,2})', text)
            if m:
                result['date'] = f"{m.group(1)}-{m.group(2).zfill(2)}-{m.group(3).zfill(2)}"
            else:
                # 格式4: 独立的"2024 05 17"附近有"开票日期"
                m = re.search(r'(\d{4})\s*(\d{2})\s*(\d{2})', text)
                if m:
                    year = int(m.group(1))
                    if 2020 <= year <= 2030:
                        result['date'] = f"{m.group(1)}-{m.group(2)}-{m.group(3)}"
    
    # 购买方名称 - 旧版发票中"名 称:"紧跟在"购"字后面
    # 格式: "名 称:xxx公司" 或 "名 称：xxx公司"
    # 注意: "购"和"名 称"可能不在同一行
    m = re.search(r'名\s*称[：:]\s*([\u4e00-\u9fa5（）()\w]+(?:有限责任公司|有限公司|股份公司))', text)
    if m:
        result['buyer'] = m.group(1).strip()
    
    # 销售方名称 - 通常在"销"字后面，格式同上
    # 旧版发票中销售方名称出现在文本后半部分
    # 找到所有"名 称:"出现的位置，第一个是购买方，第二个是销售方
    name_matches = list(re.finditer(r'名\s*称[：:]\s*([\u4e00-\u9fa5（）()\w]+(?:有限责任公司|有限公司|股份公司))', text))
    if len(name_matches) >= 2:
        result['buyer'] = name_matches[0].group(1).strip()
        result['seller'] = name_matches[1].group(1).strip()
    elif len(name_matches) == 1:
        if 'buyer' not in result:
            result['buyer'] = name_matches[0].group(1).strip()
    
    # 从表格中提取项目名称、金额、税率、税额
    if tables:
        for table in tables:
            for row in table:
                row_text = ' '.join([str(c) for c in row if c])
                # 项目名称 (格式: *类别*具体名称)
                m = re.search(r'\*[^*]+\*\S+', row_text)
                if m:
                    result['item'] = m.group(0)
                
                # 金额
                amounts = re.findall(r'[\d,]+\.\d{2}', row_text)
                if len(amounts) >= 2:
                    # 第一个是单价或金额
                    try:
                        result['amount'] = float(amounts[0].replace(',', ''))
                    except ValueError:
                        pass
                if len(amounts) >= 3:
                    try:
                        result['tax'] = float(amounts[-1].replace(',', ''))
                    except ValueError:
                        pass
    
    # 金额从"合计"行提取
    m = re.search(r'[¥￥]\s*([\d,]+\.?\d*)\s*[¥￥]\s*([\d,]+\.?\d*)', text)
    if m:
        try:
            val1 = _clean_amount(m.group(1).replace(',', ''))
            val2 = _clean_amount(m.group(2).replace(',', ''))
            if val1:
                result['amount'] = float(val1)
            if val2:
                result['tax'] = float(val2)
        except (ValueError, TypeError):
            pass
    
    # 价税合计(小写)
    m = re.search(r'[¥￥]\s*([\d,]+\.?\d*)', text)
    if m:
        vals = re.findall(r'[¥￥]\s*([\d,]+\.?\d*)', text)
        if vals:
            # 取最后一个 ¥ 值通常是价税合计
            try:
                val = _clean_amount(vals[-1].replace(',', ''))
                if val:
                    result['total'] = float(val)
            except (ValueError, TypeError):
                pass
    
    # 税率
    m = re.search(r'(\d+(?:\.\d+)?)%', text)
    if m:
        result['tax_rate'] = m.group(1) + '%'
    
    # 销售方名称 - 兜底：如果上面没从"名 称:"提取到，从文本尾部提取公司名称
    if 'seller' not in result:
        company_pattern = r'([\u4e00-\u9fa5（）()\w]+(?:有限责任公司|有限公司|股份公司|合伙|商行|酒店|宾馆|餐厅|餐饮|商店|经营部))'
        companies = re.findall(company_pattern, text)
        # 排除银行名称（银行是开户行，不是销售方）
        bank_keywords = ['银行', '招商银行', '建设银行', '工商银行', '农业银行', '中国银行']
        companies = [c for c in companies if not any(bk in c for bk in bank_keywords)]
        if companies:
            # 最后出现的公司名通常是销售方
            result['seller'] = companies[-1]
    
    # 从表格数据中补充买卖方信息（优先级最高）
    if tables:
        table_info = _extract_buyer_seller_from_tables(tables)
        if table_info.get('buyer'):
            result['buyer'] = table_info['buyer']
        if table_info.get('seller'):
            result['seller'] = table_info['seller']
    
    # 购买方名称 - 兜底：如果上面没从"名 称:"提取到，用公司名中的已知购买方
    if 'buyer' not in result:
        # 常见购买方名称模式
        buyer_match = re.search(r'(湃特纳[（(][\u4e00-\u9fa5]+[)）][\u4e00-\u9fa5]+(?:有限责任公司|有限公司))', text)
        if buyer_match:
            result['buyer'] = buyer_match.group(1)
        else:
            buyer_match = re.search(r'(湃智造[\u4e00-\u9fa5]+(?:有限责任公司|有限公司))', text)
            if buyer_match:
                result['buyer'] = buyer_match.group(1)
    
    # 大写金额
    cn_num_pattern = r'[零壹贰叁肆伍陆柒捌玖拾佰仟万亿圆角分整]+'
    m = re.search(cn_num_pattern, text)
    if m:
        result['total_cn'] = m.group(0)
    
    return result


def extract_itinerary(text):
    """提取网约车行程单信息。"""
    result = {'doc_type': 'itinerary'}
    
    # 平台名称
    if '享道出行' in text:
        result['platform'] = '享道出行'
    elif '滴滴' in text:
        result['platform'] = '滴滴出行'
    elif '高德' in text:
        result['platform'] = '高德打车'
    elif '曹操' in text:
        result['platform'] = '曹操出行'
    elif '腾飞出行' in text:
        result['platform'] = '腾飞出行'
    
    # 申请/行程日期 - 多种格式
    # 格式1: "行程起止日期：2023-12-14 至 2023-12-14" 或 "行程日期：2023-11-16至2023-12-13"
    m = re.search(r'行程(?:起止)?日期[：:]\s*(\d{4}-\d{2}-\d{2})\s*至\s*(\d{4}-\d{2}-\d{2})', text)
    if m:
        result['date_start'] = m.group(1)
        result['date_end'] = m.group(2)
        # 用结束日期作为date
        result['date'] = m.group(2)
    else:
        # 格式2: "行程时间：2025-10-20 06:46至2025-10-20 07:07" (高德)
        m = re.search(r'行程时间[：:]\s*(\d{4}-\d{2}-\d{2})\s*\d{2}:\d{2}\s*至\s*(\d{4}-\d{2}-\d{2})', text)
        if m:
            result['date_start'] = m.group(1)
            result['date_end'] = m.group(2)
            result['date'] = m.group(2)
        else:
            # 格式3: "申请日期：2023-12-20"
            m = re.search(r'申请日期[：:]\s*(\d{4}-\d{2}-\d{2})', text)
            if m:
                result['date'] = m.group(1)
            else:
                # 格式4: "申请时间：2025-11-10" (高德)
                m = re.search(r'申请时间[：:]\s*(\d{4}-\d{2}-\d{2})', text)
                if m:
                    result['date'] = m.group(1)
    
    # 如果还是缺日期，从行程明细中提取（"2023-12-13 04:40:00"格式）
    if not result.get('date'):
        m = re.search(r'(\d{4}-\d{2}-\d{2})\s+\d{2}:\d{2}', text)
        if m:
            result['date'] = m.group(1)
    
    # 合计金额 - 处理PDF字符重叠导致的双字符问题（如 6622..8811 -> 66.81）
    m = re.search(r'合计\s*([\d.]+)\s*元', text)
    if m:
        val_str = _clean_amount(m.group(1))
        if val_str:
            result['total'] = float(val_str)
    if 'total' not in result:
        m = re.search(r'([\d.]+)\s*元', text)
        if m:
            val_str = _clean_amount(m.group(1))
            if val_str:
                result['total'] = float(val_str)
    
    # 行程数量
    m = re.search(r'共(\d+)笔行程', text)
    if m:
        result['trip_count'] = int(m.group(1))
    
    # 城市
    m = re.search(r'([\u4e00-\u9fa5]+市)', text)
    if m:
        result['city'] = m.group(1)
    
    return result


def extract_toll_itinerary(text):
    """提取通行费电子行程单信息。非发票，但包含通行费和发票抬头等。"""
    result = {'doc_type': 'itinerary', 'platform': '通行费'}
    
    # 发票抬头
    m = re.search(r'发票抬头[：:]\s*(.+)', text)
    if m:
        result['buyer'] = m.group(1).strip()
    
    # 发票金额
    m = re.search(r'发票金额[：:]\s*([\d.]+)\s*元', text)
    if m:
        try:
            result['total'] = float(m.group(1))
        except ValueError:
            pass
    
    # 开票时间
    m = re.search(r'开票时间[：:]\s*(\d{4})[年/-](\d{1,2})[月/-](\d{1,2})', text)
    if m:
        result['date'] = f"{m.group(1)}-{m.group(2).zfill(2)}-{m.group(3).zfill(2)}"
    
    # 发票代码
    m = re.search(r'发票代码[：:]\s*(\d+)', text)
    if m:
        result['invoice_code'] = m.group(1)
    
    # 发票号码
    m = re.search(r'发票号码[：:]\s*(\d+)', text)
    if m:
        result['invoice_no'] = m.group(1)
    
    # 入口/出口信息
    m = re.search(r'入口站\s*(.+?)(?:\s+出口|$)', text)
    if m:
        result['departure'] = m.group(1).strip()
    m = re.search(r'出口站\s*(.+?)(?:\s+[\d.]+元|$)', text)
    if m:
        result['arrival'] = m.group(1).strip()
    
    # 入口时间
    m = re.search(r'入口时间\s*(\d{4}-\d{2}-\d{2}\s*\d{2}:\d{2})', text)
    if m:
        result['departure_time'] = m.group(1)
    
    # 交易金额/通行费金额
    if 'total' not in result:
        m = re.search(r'(?:交易|通行)金额\s*([\d.]+)\s*元', text)
        if m:
            try:
                result['total'] = float(m.group(1))
            except ValueError:
                pass
    
    # 车牌号码
    m = re.search(r'([京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤川青藏琼宁][A-Z][A-Z0-9]{5})', text)
    if m:
        result['note'] = f"车牌: {m.group(1)}"
    
    return result


def extract_flight_receipt(text, tables):
    """提取机票报销凭证信息。本质是发票，但还包含航班信息。
    支持旧版机票报销凭证和新版航空运输电子客票行程单。"""
    result = {}
    
    # 新版航空运输电子客票行程单格式
    if '航空运输电子客票行程单' in text:
        # 发票号码 (20位)
        m = re.search(r'发票号码[：:]\s*(\d{18,20})', text)
        if m:
            result['invoice_no'] = m.group(1)
        
        # 旅客姓名
        m = re.search(r'旅客姓名\s+有效身份证件号码', text)
        if m:
            # 姓名在下一行
            m2 = re.search(r'\n(\S{2,4})\s+\d', text[m.end():])
            if m2:
                result['passenger'] = m2.group(1)
        
        # 航班信息: "自:深圳 宝安 国航 CA1306 K 2025年10月10日 08:55"
        m = re.search(r'自[：:]?\s*([\u4e00-\u9fa5]+)\s+([\u4e00-\u9fa5]*)\s+([A-Z\u4e00-\u9fa5]{2,4})\s+([A-Z]{1,2}\d{2,6})\s+\S+\s+(\d{4})年(\d{1,2})月(\d{1,2})日\s+(\d{2}:\d{2})', text)
        if m:
            result['departure'] = m.group(1) + (' ' + m.group(2) if m.group(2) else '')
            result['carrier'] = m.group(3)
            result['flight_no'] = m.group(4)
            result['flight_date'] = f"{m.group(5)}-{m.group(6).zfill(2)}-{m.group(7).zfill(2)}"
            result['departure_time'] = m.group(8)
        
        # 目的地: "至:北京 首都"
        m = re.search(r'至[：:]?\s*([\u4e00-\u9fa5]+)\s+([\u4e00-\u9fa5]*)', text)
        if m:
            result['arrival'] = m.group(1) + (' ' + m.group(2) if m.group(2) else '')
        
        # 金额: "CNY 504.59 CNY 18.35 9% CNY 47.06 CNY 50.00 CNY 0.00 CNY 620.00"
        # 格式: 票价 燃油附加费 增值税税率 增值税税额 民航发展基金 其他税费 合计
        m = re.search(r'票价.*?CNY\s*([\d,.]+)\s*CNY\s*([\d,.]+)\s*(\d+(?:\.\d+)?)%\s*CNY\s*([\d,.]+)\s*CNY\s*([\d,.]+)\s*CNY\s*([\d,.]+)\s*CNY\s*([\d,.]+)', text)
        if m:
            try:
                result['amount'] = float(m.group(1).replace(',', ''))
                result['fuel_surcharge'] = float(m.group(2).replace(',', ''))
                result['tax_rate'] = m.group(3) + '%'
                result['tax'] = float(m.group(4).replace(',', ''))
                result['civil_aviation_fund'] = float(m.group(5).replace(',', ''))
                result['total'] = float(m.group(7).replace(',', ''))
            except (ValueError, IndexError):
                pass
        
        # 购买方名称
        m = re.search(r'购买方名称[：:]\s*(.+?)(?:\s+统一社会|$)', text)
        if m:
            result['buyer'] = m.group(1).strip()
        
        # 填开单位
        m = re.search(r'填开单位[：:]\s*(.+?)(?:\s+填开日期|$)', text)
        if m:
            result['seller'] = m.group(1).strip()
        
        result['invoice_type'] = '机票报销凭证'
        return result
    
    # 旧版机票报销凭证格式
    # 先按旧版发票格式提取基本发票信息
    result = extract_old_format_invoice(text, tables)
    result['invoice_type'] = '机票报销凭证'
    
    # 航班信息 (附加)
    # 格式1: "2023-11-09 09:10-11:30 广州白云国际机场-上海虹桥国际机场 MU5304"
    m = re.search(r'(\d{4}-\d{2}-\d{2})\s*(\d{2}:\d{2})-(\d{2}:\d{2})\s*([\u4e00-\u9fa5]+[机场])-([\u4e00-\u9fa5]+[机场])', text)
    if not m:
        # 格式2: 去哪儿网——航班信息在备注行
        # "2023-11-09 09:10-11:30 广州白云国际机场-上海虹桥\n国际机场 MU5304|2023-11-09 13:30-15:50 上海虹桥\n国际机场-北京首都国际机场 MU5157 王克成"
        m = re.search(r'(\d{4}-\d{2}-\d{2})\s*(\d{2}:\d{2})-(\d{2}:\d{2})\s*([\u4e00-\u9fa5]+)', text)
    if m:
        result['flight_date'] = m.group(1)
        result['departure_time'] = m.group(2)
        result['arrival_time'] = m.group(3)
        result['departure'] = m.group(4)
    
    # 从去哪儿网备注行提取更完整的航班信息
    # 格式: "广州白云国际机场-上海虹桥\n国际机场 MU5304"
    if 'departure' not in result:
        m = re.search(r'([\u4e00-\u9fa5]+(?:国际)?机场)\s*[-—]\s*([\u4e00-\u9fa5]+)', text)
        if m:
            result['departure'] = m.group(1)
            result['arrival'] = m.group(2)
    
    # 航班号 - 多种格式
    m = re.search(r'([A-Z0-9]{2}\d{2,5}|[A-Z]\d{3,5})\s', text)
    if not m:
        # 航班号可能紧跟在机场后面
        m = re.search(r'机场\s+([A-Z0-9]{2}\d{2,5})', text)
    if not m:
        # "MU5304|" 格式
        m = re.search(r'([A-Z0-9]{2}\d{2,5})[|\s]', text)
    if m:
        result['flight_no'] = m.group(1)
    
    # 乘机人
    m = re.search(r'(?:乘机人|旅客|姓名)[：:]\s*(\S+)', text)
    if not m:
        # 在航班号后面的名字（通常是2-4个中文字符）
        m = re.search(r'[A-Z0-9]{2}\d{2,5}[|\s]\s*([\u4e00-\u9fa5]{2,4})', text)
    if not m:
        # 最后一行中的名字（去哪儿网格式）
        m = re.search(r'\s([\u4e00-\u9fa5]{2,4})\s*$', text.strip())
    if m:
        result['passenger'] = m.group(1)
    
    # 如果没从发票中提取到日期，从航班日期取
    if 'date' not in result and result.get('flight_date'):
        result['date'] = result['flight_date']
    
    return result


# ============================================================
# Main Processing Pipeline
# ============================================================

def process_single_file(filepath):
    """处理单个PDF/OFD文件，返回提取结果。"""
    filename = os.path.basename(filepath)
    ext = filename.lower().split('.')[-1]
    
    # OFD文件 - 使用专用解析器
    if ext == 'ofd':
        return process_ofd_file(filepath)
    
    # 读取PDF
    text = ''
    tables = []
    try:
        with pdfplumber.open(filepath) as pdf:
            for page in pdf.pages:
                page_text = page.extract_text()
                if page_text:
                    text += page_text + '\n'
                page_tables = page.extract_tables()
                if page_tables:
                    tables.extend(page_tables)
    except Exception as e:
        return {
            'filename': filename,
            'filepath': filepath,
            'doc_category': 'unknown',
            'error': str(e),
        }
    
    if not text.strip():
        return {
            'filename': filename,
            'filepath': filepath,
            'doc_category': 'unknown',
            'error': 'PDF文本为空（可能是扫描件）',
        }
    
    # 分类
    doc_category, invoice_type = classify_document(filename, text)
    
    result = {
        'filename': filename,
        'filepath': filepath,
        'doc_category': doc_category,
        'invoice_type': invoice_type,
    }
    
    # 按类型提取
    if doc_category == 'itinerary':
        if invoice_type == '通行费行程单':
            extracted = extract_toll_itinerary(text)
        else:
            extracted = extract_itinerary(text)
        result.update(extracted)
    elif invoice_type == '机票报销凭证':
        extracted = extract_flight_receipt(text, tables)
        result.update(extracted)
    elif invoice_type in ('全电普通发票', '增值税专用发票', '全电增值税专用发票'):
        extracted = extract_new_electronic_invoice(text, tables)
        result.update(extracted)
    elif invoice_type in ('增值税电子普通发票', '增值税电子专用发票', '增值税普通发票', '电子发票'):
        extracted = extract_old_format_invoice(text, tables)
        result.update(extracted)
    elif doc_category == 'receipt':
        result['note'] = '非发票，仅消费记录'
    else:
        # 尝试新版格式
        extracted = extract_new_electronic_invoice(text, tables)
        if extracted.get('invoice_no') or extracted.get('total'):
            result.update(extracted)
        else:
            # 尝试旧版格式
            extracted = extract_old_format_invoice(text, tables)
            if extracted.get('invoice_no') or extracted.get('total'):
                result.update(extracted)
            else:
                result['error'] = '无法识别发票格式'
    
    # 后处理：清理提取结果中的异体字和重叠字符残留
    _clean_extracted_fields(result)
    
    return result


def _clean_extracted_fields(result):
    """清理提取结果中的CJK兼容异体字和重叠字符残留。
    分类时用_normalize_text_for_match做了替换，但提取结果中的文本字段
    （buyer/seller/item等）仍可能含异体字，需要统一替换为常用字。
    """
    compat_map = {'⼦': '子', '⽅': '方', '⽓': '气', '⽤': '用', '⽇': '日',
                  '⽉': '月', '⼀': '一', '⼆': '二', '⼈': '人', '⼊': '入',
                  '⼒': '力', '⼝': '口', '⼤': '大', '⼥': '女', '⼭': '山',
                  '⼯': '工', '⼼': '心', '⽂': '文', '⽊': '木', '⽔': '水',
                  '⽕': '火', '⼟': '土', '⾦': '金', '⾷': '食', '⾼': '高',
                  '⻓': '长', '⻔': '门', '⻋': '车', '⻛': '风', '⻦': '鸟',
                  '⻢': '马', '⿊': '黑', '⿓': '龙', '⿎': '鼓', '⼴': '广',
                  '⼚': '厂', '⼏': '几', '⼩': '小', '⼨': '寸', '⼰': '己',
                  '⼳': '幺', '⻨': '麦', '⻩': '黄', '⻬': '齐', '⻰': '龙',
                  '⻱': '龟', '⻲': '龟', '⾦': '金', '⻝': '食'}
    text_fields = ['buyer', 'seller', 'item', 'total_cn', 'issuer', 'note', 'passenger',
                   'departure', 'arrival', 'flight_no', 'carrier', 'platform']
    for field in text_fields:
        val = result.get(field)
        if val and isinstance(val, str):
            for k, v in compat_map.items():
                val = val.replace(k, v)
            # 清理重叠字符残留（如"⽅ ⽅"→"方"）
            val = re.sub(r'([\u4e00-\u9fff])\s+\1', r'\1', val)
            if val != result[field]:
                result[field] = val


def parse_year_arg(year_str):
    """解析 --year 参数为 year 整数。
    
    支持格式:
      2024, 2024年, 2024年/
    
    返回: year_int 或 None
    """
    if not year_str:
        return None
    
    s = year_str.strip().rstrip('/').rstrip('年').strip()
    
    m = re.match(r'^(\d{4})$', s)
    if m:
        year = int(m.group(1))
        if 2020 <= year <= 2099:
            return year
    
    return None


def parse_month_arg(month_str):
    """解析 --month 参数为 (year, month) 元组。
    
    支持格式:
      2026-03, 202603, 2026年3月, 2026年03月, 2026_03
    不支持: 20260430 (这是日期不是月份)
    
    返回: (year_int, month_int) 或 None
    """
    if not month_str:
        return None
    
    s = month_str.strip()
    
    # 2026-03 / 2026_03
    m = re.match(r'^(\d{4})[-_](\d{1,2})$', s)
    if m:
        return int(m.group(1)), int(m.group(2))
    
    # 202603 (6位纯数字，必须恰好6位)
    m = re.match(r'^(\d{4})(\d{2})$', s)
    if m:
        month = int(m.group(2))
        if 1 <= month <= 12:
            return int(m.group(1)), month
    
    # 2026年3月 / 2026年03月
    m = re.match(r'^(\d{4})\s*年\s*(\d{1,2})\s*月?$', s)
    if m:
        return int(m.group(1)), int(m.group(2))
    
    return None


def folder_name_to_month(folder_name):
    """从文件夹名中提取 (year, month)。
    
    支持格式:
      01月 / 1月 / 01      → 当年该月 (返回 (None, month))
      2026年4月 / 2026年04月 → (2026, 4)
      202604 / 2026-04 / 2026_04 → (2026, 4)
      20240430 / 20260331   → 从8位日期中提取年月 → (2024, 4) / (2026, 3)
      发票-20240301          → 提取8位日期中的年月 → (2024, 3)
    """
    s = folder_name.strip()
    
    # 2026年4月 / 2026年04月
    m = re.match(r'^(\d{4})\s*年\s*(\d{1,2})\s*月?$', s)
    if m:
        return int(m.group(1)), int(m.group(2))
    
    # 2026-04 / 2026_04
    m = re.match(r'^(\d{4})[-_](\d{1,2})$', s)
    if m:
        return int(m.group(1)), int(m.group(2))
    
    # 8位日期格式: 20260331, 20240430 → 提取前4位年+5-6位月
    m = re.match(r'^(\d{4})(\d{2})(\d{2})$', s)
    if m:
        month = int(m.group(2))
        if 1 <= month <= 12:
            return int(m.group(1)), month
    
    # 202604 (6位，恰好年+月)
    m = re.match(r'^(\d{4})(\d{2})$', s)
    if m:
        month = int(m.group(2))
        if 1 <= month <= 12:
            return int(m.group(1)), month
    
    # 01月 / 1月 / 01 (仅月，需外部补充年份)
    m = re.match(r'^(\d{1,2})\s*月?$', s)
    if m:
        month = int(m.group(1))
        if 1 <= month <= 12:
            return None, month
    
    # 带前缀的8位日期: 发票-20240301, 报销-20240228
    m = re.search(r'[^\d](\d{4})(\d{2})(\d{2})$', s)
    if m:
        month = int(m.group(2))
        if 1 <= month <= 12:
            return int(m.group(1)), month
    
    # 带前缀的6位年月: 发票-202403
    m = re.search(r'[^\d](\d{4})(\d{2})$', s)
    if m:
        month = int(m.group(2))
        if 1 <= month <= 12:
            return int(m.group(1)), month
    
    return None


def scan_directory(base_dir, month_filter=None, year_filter=None):
    """扫描目录，找到所有PDF和OFD文件（含ZIP压缩包内的）。
    
    Args:
        base_dir: 根目录
        month_filter: (year, month) 元组，只扫描对应月份的文件夹。
                      如果为None，扫描全部。
        year_filter: year 整数，只扫描对应年份的文件夹。
                     如果为None，不按年份过滤。
    
    Returns:
        list of dict: 每个元素包含:
            - 'filepath': 文件绝对路径（zip内文件为临时目录路径）
            - 'source_zip': 来源zip文件路径（如果不是从zip解压的则为None）
            - 'zip_inner_path': zip内相对路径（如果不是从zip解压的则为None）
    
    月份文件夹识别策略：
      1. 路径中的文件夹名如果匹配月份格式（如 20260331, 2026-03, 03月 等），
         则该目录下的文件属于该月份
      2. 如果路径中没有月份文件夹（如 2024年/发票-20231221/ 这种只有年份+批次的结构），
         则扫描该年份下的所有文件，后续由 _filter_results_by_month 用开票日期过滤
    """
    files = []
    zip_files = []  # 收集zip文件，后续统一解压
    base_dir = os.path.abspath(base_dir)
    
    # 预计算：检查每个年份目录下是否有月份子目录
    # 如果有月份子目录，则严格按月份过滤
    # 如果没有月份子目录，则扫描整个年份目录，后续用开票日期过滤
    year_dirs_with_month_subdirs = set()
    if month_filter or year_filter:
        for entry in os.listdir(base_dir):
            year_path = os.path.join(base_dir, entry)
            if os.path.isdir(year_path):
                has_month_subdir = False
                for sub in os.listdir(year_path):
                    sub_path = os.path.join(year_path, sub)
                    if os.path.isdir(sub_path):
                        fm = folder_name_to_month(sub)
                        if fm is not None:
                            has_month_subdir = True
                            break
                if has_month_subdir:
                    year_dirs_with_month_subdirs.add(entry)
    
    for root, dirs, filenames in os.walk(base_dir):
        # 年份过滤：如果指定了year_filter，只进入匹配的年份目录及其子目录
        if year_filter:
            rel_path = os.path.relpath(root, base_dir)
            path_parts = rel_path.replace('\\', '/').split('/')
            
            if len(path_parts) >= 1 and path_parts[0] != '.':
                # 检查第一级目录是否是目标年份
                first_dir = path_parts[0]
                ym = re.match(r'^(\d{4})\s*年?$', first_dir)
                if ym:
                    if int(ym.group(1)) == year_filter:
                        pass  # 匹配，继续
                    else:
                        # 不匹配的年份目录，跳过
                        # 同时剪枝：不进入子目录
                        dirs[:] = []
                        continue
                else:
                    # 第一级目录不是年份格式，可能是直接在根目录的文件
                    # 不做年份过滤（后续用开票日期过滤）
                    pass
            
            # 在第一级目录层级，剪掉不匹配的年份目录
            if rel_path == '.':
                # 在根目录层级，只保留匹配的年份子目录
                filtered_dirs = []
                for d in dirs:
                    ym = re.match(r'^(\d{4})\s*年?$', d)
                    if ym and int(ym.group(1)) == year_filter:
                        filtered_dirs.append(d)
                    elif not ym:
                        # 非年份格式的子目录也保留（后续用开票日期过滤）
                        filtered_dirs.append(d)
                dirs[:] = filtered_dirs
        
        if month_filter:
            target_year, target_month = month_filter
            rel_path = os.path.relpath(root, base_dir)
            path_parts = rel_path.replace('\\', '/').split('/')
            
            # 判断当前路径是否匹配目标月份
            month_matched = False
            found_year_in_path = None
            found_month_folders = []
            
            for part in path_parts:
                fm = folder_name_to_month(part)
                if fm is not None:
                    fy, fmonth = fm
                    if fy is not None:
                        found_month_folders.append((fy, fmonth))
                        if fy == target_year and fmonth == target_month:
                            month_matched = True
                    else:
                        # 仅有月份，需配合路径中的年份
                        found_month_folders.append((None, fmonth))
            
            # 如果路径中有年份文件夹（如 "2026年"）
            for part in path_parts:
                ym = re.match(r'^(\d{4})\s*年?$', part)
                if ym:
                    found_year_in_path = int(ym.group(1))
            
            # 综合判断：有月份文件夹是否匹配
            if found_month_folders:
                for fy, fmonth in found_month_folders:
                    if fy is not None:
                        if fy == target_year and fmonth == target_month:
                            month_matched = True
                            break
                    elif found_year_in_path is not None:
                        if found_year_in_path == target_year and fmonth == target_month:
                            month_matched = True
                            break
            
            # 如果当前年份目录下有月份子目录，则严格要求月份匹配
            # （即必须进入正确的月份文件夹）
            if path_parts and path_parts[0] in year_dirs_with_month_subdirs:
                if not month_matched:
                    # 不匹配的目录，跳过所有文件
                    continue
            
            # 如果当前年份目录下没有月份子目录，则不在此处过滤
            # 后续由 _filter_results_by_month 用开票日期过滤
        
        for fn in filenames:
            if fn.lower().endswith(('.pdf', '.ofd')):
                files.append({
                    'filepath': os.path.join(root, fn),
                    'source_zip': None,
                    'zip_inner_path': None,
                })
            elif fn.lower().endswith('.zip'):
                zip_files.append(os.path.join(root, fn))
    
    # 解压zip文件，提取其中的PDF/OFD
    if zip_files:
        tmp_base = tempfile.mkdtemp(prefix='invoice_zip_')
        print(f"  Found {len(zip_files)} ZIP files, extracting...")
        for zip_path in zip_files:
            try:
                with zipfile.ZipFile(zip_path, 'r') as zf:
                    # 只提取PDF和OFD文件
                    inner_files = [n for n in zf.namelist() 
                                   if n.lower().endswith(('.pdf', '.ofd')) 
                                   and not n.startswith('__MACOSX')
                                   and not n.startswith('.')]
                    if not inner_files:
                        continue
                    # 创建以zip文件名命名的子目录，避免不同zip中同名文件冲突
                    zip_basename = os.path.splitext(os.path.basename(zip_path))[0]
                    extract_dir = os.path.join(tmp_base, zip_basename)
                    os.makedirs(extract_dir, exist_ok=True)
                    for inner in inner_files:
                        try:
                            zf.extract(inner, extract_dir)
                            extracted_path = os.path.join(extract_dir, inner)
                            if os.path.isfile(extracted_path):
                                files.append({
                                    'filepath': extracted_path,
                                    'source_zip': zip_path,
                                    'zip_inner_path': inner,
                                })
                        except Exception:
                            pass  # 跳过无法解压的单个文件
            except zipfile.BadZipFile:
                pass  # 跳过损坏的zip
            except Exception:
                pass  # 跳过其他错误
    
    return sorted(files, key=lambda x: x['filepath'])


def extract_batch_info(filepath, base_dir, source_zip=None):
    """从文件路径中提取年份和报销批次信息。
    
    对于zip内文件，使用source_zip路径提取年份和批次。
    """
    # 如果是zip内文件，用zip源路径提取年份/批次
    effective_path = source_zip if source_zip else filepath
    rel = os.path.relpath(effective_path, base_dir)
    parts = rel.replace('\\', '/').split('/')
    
    year = ''
    batch = ''
    for p in parts:
        if p.endswith('年'):
            year = p
        elif p.startswith('发票-') or p.startswith('202') or (len(p) == 8 and p.isdigit()):
            batch = p
    
    return year, batch


# ============================================================
# Duplicate Detection
# ============================================================

def _detect_duplicates(results):
    """检测重复发票/行程单。
    
    以发票号码为主键进行分组：
    - 发票：同一发票号码视为重复（发票号码通常唯一）
    - 行程单：同一发票号码+同日期视为重复（行程单号码可能在不同月份重复）
    
    Returns:
        dict: {key: [result_index1, result_index2, ...]} 每组至少2个重复项
    """
    from collections import defaultdict
    
    # 按发票号码分组
    groups = defaultdict(list)
    
    for idx, r in enumerate(results):
        invoice_no = r.get('invoice_no', '').strip()
        if not invoice_no:
            continue
        
        doc_category = r.get('doc_category', '')
        date = r.get('date', '').strip()
        
        if doc_category == 'itinerary':
            # 行程单：发票号码+日期组合去重
            key = f"itn:{invoice_no}:{date}"
        elif doc_category == 'invoice':
            # 发票：仅按发票号码
            key = f"inv:{invoice_no}"
        else:
            # 其他类型不检测
            continue
        
        groups[key].append(idx)
    
    # 只保留有重复的组
    duplicates = {k: v for k, v in groups.items() if len(v) >= 2}
    return duplicates


# ============================================================
# Excel Output
# ============================================================

def create_output_workbook(results, base_dir, duplicate_groups=None, remove_duplicates=False):
    """生成包含多个Sheet的Excel工作簿。
    
    Args:
        remove_duplicates: 如果为True，则完全移除重复发票（只保留首次出现的）
    """
    if duplicate_groups is None:
        duplicate_groups = {}
    
    # 构建重复索引集合：{result_index} 是重复项（保留第一个出现的不标）
    dup_indices = set()  # 所有重复项的索引
    first_in_group = set()  # 每组的第一个索引（标"首次"不标"重复"）
    for key, indices in duplicate_groups.items():
        first_in_group.add(indices[0])
        for idx in indices:
            dup_indices.add(idx)
    
    # 如果需要去重，过滤掉所有重复项（包括首次出现的标记）
    if remove_duplicates:
        all_dup_related = dup_indices.union(first_in_group)
        results = [r for i, r in enumerate(results) if i not in all_dup_related or i in first_in_group]
        # 重新构建重复索引（此时应该为空，因为没有重复项了）
        dup_indices = set()
        first_in_group = set()
    
    wb = Workbook()
    
    # Separate invoices and itineraries
    invoices = [r for r in results if r.get('doc_category') == 'invoice']
    itineraries = [r for r in results if r.get('doc_category') == 'itinerary']
    receipts = [r for r in results if r.get('doc_category') == 'receipt']
    unknowns = [r for r in results if r.get('doc_category') == 'unknown']
    
    # 为发票建立results全局索引映射
    invoice_to_result_idx = {}
    result_idx = 0
    for r in results:
        if r.get('doc_category') == 'invoice':
            invoice_to_result_idx[id(r)] = result_idx
        result_idx += 1
    
    # ---- Sheet 1: 发票明细 ----
    ws_inv = wb.active
    ws_inv.title = '发票明细'
    
    inv_headers = ['序号', '年份', '报销批次', '发票类型', '发票代码', '发票号码', 
                   '开票日期', '购买方名称', '销售方名称', '项目名称', 
                   '金额(不含税)', '税率', '税额', '价税合计', '价税合计(大写)', 
                   '开票人', '是否重复', '来源', '文件名']
    
    ws_inv.append(inv_headers)
    _format_header(ws_inv, len(inv_headers))
    
    for i, inv in enumerate(invoices, 1):
        year, batch = extract_batch_info(inv['filepath'], base_dir, source_zip=inv.get('source_zip'))
        
        # 判断是否重复
        r_idx = invoice_to_result_idx.get(id(inv))
        if r_idx is not None and r_idx in dup_indices:
            if r_idx in first_in_group:
                dup_label = '首次出现'
            else:
                dup_label = '重复'
        else:
            dup_label = ''
        
        # 来源标注
        source = ''
        if inv.get('source_zip'):
            source = f"ZIP:{os.path.basename(inv['source_zip'])}"
        
        row = [
            i,
            year,
            batch,
            inv.get('invoice_type', ''),
            inv.get('invoice_code', ''),
            inv.get('invoice_no', ''),
            inv.get('date', ''),
            inv.get('buyer', ''),
            inv.get('seller', ''),
            inv.get('item', ''),
            inv.get('amount'),
            inv.get('tax_rate', ''),
            inv.get('tax'),
            inv.get('total'),
            inv.get('total_cn', ''),
            inv.get('issuer', ''),
            dup_label,
            source,
            inv.get('filename', ''),
        ]
        ws_inv.append(row)
        
        # 重复项标红
        if dup_label == '重复':
            for cell in ws_inv[ws_inv.max_row]:
                cell.fill = PatternFill(start_color='FFCCCC', end_color='FFCCCC', fill_type='solid')
    
    _auto_width(ws_inv, inv_headers)
    
    # ---- Sheet 2: 行程单明细 ----
    ws_itn = wb.create_sheet('行程单明细')
    
    itn_headers = ['序号', '年份', '报销批次', '凭证类型', '平台', 
                   '行程日期', '行程起止日期', '行程数', '城市', 
                   '合计金额(元)', '是否重复', '来源', '文件名']
    
    ws_itn.append(itn_headers)
    _format_header(ws_itn, len(itn_headers))
    
    # 为行程单建立results全局索引映射
    itn_to_result_idx = {}
    result_idx = 0
    for r in results:
        if r.get('doc_category') == 'itinerary':
            itn_to_result_idx[id(r)] = result_idx
        result_idx += 1
    
    for i, itn in enumerate(itineraries, 1):
        year, batch = extract_batch_info(itn['filepath'], base_dir, source_zip=itn.get('source_zip'))
        date_range = ''
        if itn.get('date_start') and itn.get('date_end'):
            date_range = f"{itn['date_start']} 至 {itn['date_end']}"
        
        # 判断是否重复
        r_idx = itn_to_result_idx.get(id(itn))
        if r_idx is not None and r_idx in dup_indices:
            if r_idx in first_in_group:
                dup_label = '首次出现'
            else:
                dup_label = '重复'
        else:
            dup_label = ''
        
        # 来源标注
        source = ''
        if itn.get('source_zip'):
            source = f"ZIP:{os.path.basename(itn['source_zip'])}"
        
        row = [
            i,
            year,
            batch,
            itn.get('invoice_type', '行程单'),
            itn.get('platform', ''),
            itn.get('date', ''),
            date_range,
            itn.get('trip_count', ''),
            itn.get('city', ''),
            itn.get('total'),
            dup_label,
            source,
            itn.get('filename', ''),
        ]
        ws_itn.append(row)
        
        # 重复项标红
        if dup_label == '重复':
            for cell in ws_itn[ws_itn.max_row]:
                cell.fill = PatternFill(start_color='FFCCCC', end_color='FFCCCC', fill_type='solid')
    
    _auto_width(ws_itn, itn_headers)
    
    # ---- Sheet 3: 非发票文件 ----
    ws_other = wb.create_sheet('非发票文件')
    other_headers = ['序号', '年份', '报销批次', '文件类型', '文件名', '备注']
    ws_other.append(other_headers)
    _format_header(ws_other, len(other_headers))
    
    all_other = receipts + unknowns
    for i, item in enumerate(all_other, 1):
        year, batch = extract_batch_info(item['filepath'], base_dir, source_zip=item.get('source_zip'))
        row = [
            i, year, batch,
            item.get('invoice_type', '其他'),
            item.get('filename', ''),
            item.get('note', item.get('error', '')),
        ]
        ws_other.append(row)
    
    _auto_width(ws_other, other_headers)
    
    # ---- Sheet 4: 重复发票（仅在有重复且不去重时添加） ----
    if duplicate_groups and not remove_duplicates:
        _create_duplicate_sheet(wb, results, duplicate_groups, base_dir)
    
    # ---- Sheet 5: 按月汇总 ----
    _create_monthly_summary(wb, invoices, base_dir)
    
    # ---- Sheet 6: 按季度汇总 ----
    _create_quarterly_summary(wb, invoices, base_dir)
    
    # ---- Sheet 7: 按年度汇总 ----
    _create_yearly_summary(wb, invoices, base_dir)
    
    # ---- Sheet 8: 按费用类别汇总 ----
    _create_category_summary(wb, invoices, base_dir)
    
    return wb


def _create_duplicate_sheet(wb, results, duplicate_groups, base_dir):
    """创建重复发票/行程单汇总sheet。"""
    ws = wb.create_sheet('重复发票')
    
    dup_headers = ['组号', '发票号码', '类型', '开票日期', '购买方', '销售方', 
                   '价税合计', '来源', '文件名']
    ws.append(dup_headers)
    _format_header(ws, len(dup_headers))
    
    # 重复行高亮色
    dup_fill = PatternFill(start_color='FFCCCC', end_color='FFCCCC', fill_type='solid')
    first_fill = PatternFill(start_color='FFFFCC', end_color='FFFFCC', fill_type='solid')
    
    group_num = 0
    for key, indices in sorted(duplicate_groups.items()):
        group_num += 1
        for i, idx in enumerate(indices):
            r = results[idx]
            source = ''
            if r.get('source_zip'):
                source = f"ZIP:{os.path.basename(r['source_zip'])}"
            
            doc_cat = r.get('doc_category', '')
            if doc_cat == 'itinerary':
                type_label = r.get('invoice_type', '行程单')
            else:
                type_label = r.get('invoice_type', '发票')
            
            row = [
                group_num if i == 0 else '',
                r.get('invoice_no', ''),
                type_label,
                r.get('date', ''),
                r.get('buyer', ''),
                r.get('seller', ''),
                r.get('total', ''),
                source,
                r.get('filename', ''),
            ]
            ws.append(row)
            
            # 首次出现标黄，重复项标红
            fill = first_fill if i == 0 else dup_fill
            for cell in ws[ws.max_row]:
                cell.fill = fill
    
    _auto_width(ws, dup_headers)
    
    # 在最底部添加说明
    ws.append([])
    ws.append(['说明：', '', '首次出现=黄底（保留项）', '', '重复=红底（可剔除）'])
    note_font = Font(color='666666', italic=True)
    for cell in ws[ws.max_row]:
        cell.font = note_font


def _format_header(ws, col_count):
    """格式化表头行。"""
    header_fill = PatternFill(start_color='1F4E79', end_color='1F4E79', fill_type='solid')
    header_font = Font(name='微软雅黑', bold=True, color='FFFFFF', size=11)
    for cell in ws[1]:
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)


def create_categorized_workbook(results, base_dir, cat_stats, month_filter, duplicate_groups=None):
    """
    生成带报销类别分类汇总的Excel工作簿（基于去重后的结果）。
    
    包含Sheet：
    1. 发票明细（含报销类别列，去重后）
    2. 行程单明细
    3. 按报销类别汇总（去重后）
    4. 非发票文件
    """
    from openpyxl import Workbook
    from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
    from openpyxl.utils import get_column_letter
    
    if duplicate_groups is None:
        duplicate_groups = {}
    
    wb = Workbook()
    
    # 构建重复索引集合：只保留每组第一个
    duplicate_indices = set()
    for indices in duplicate_groups.values():
        sorted_indices = sorted(indices)
        duplicate_indices.update(sorted_indices[1:])
    
    # 为每个结果添加分类信息（跳过重复）
    results_with_cat = []
    for idx, r in enumerate(results):
        if idx in duplicate_indices:
            continue
        r_copy = dict(r)
        if r.get('doc_category') == 'invoice':
            mc, sc = _classify_expense_category(r)
            r_copy['报销大类'] = mc if mc else '待确认'
            r_copy['报销子类'] = sc if sc else '-'
        else:
            r_copy['报销大类'] = '-'
            r_copy['报销子类'] = '-'
        results_with_cat.append(r_copy)
    
    # Sheet 1: 发票明细（含报销类别）
    ws_inv = wb.active
    ws_inv.title = '发票明细'
    headers = ['序号', '年份', '报销批次', '报销大类', '报销子类', '发票类型', '发票代码', '发票号码', 
               '开票日期', '购买方', '销售方', '项目', '金额', '税率', '税额', '价税合计', 
               '备注', '文件路径']
    ws_inv.append(headers)
    
    invoice_results = [r for r in results_with_cat if r.get('doc_category') == 'invoice']
    for i, r in enumerate(invoice_results, 1):
        year, batch = extract_batch_info(r.get('filepath', ''), base_dir, r.get('source_zip'))
        ws_inv.append([
            i, year, batch,
            r.get('报销大类', ''), r.get('报销子类', ''),
            r.get('invoice_type', ''), r.get('invoice_code', ''),
            r.get('invoice_no', ''), r.get('date', ''),
            r.get('buyer', ''), r.get('seller', ''),
            r.get('item', ''), r.get('amount', ''),
            r.get('tax_rate', ''), r.get('tax', ''),
            r.get('total', ''), r.get('remarks', ''),
            r.get('filename', '')
        ])
    
    _format_header(ws_inv, len(headers))
    _auto_width(ws_inv, headers)
    
    # Sheet 2: 行程单明细
    ws_itn = wb.create_sheet('行程单明细')
    itn_headers = ['序号', '年份', '报销批次', '文档类型', '发票代码', '发票号码', '开票日期',
                   '购买方', '销售方', '项目', '金额', '税率', '税额', '价税合计', '备注', '文件路径']
    ws_itn.append(itn_headers)
    
    itinerary_results = [r for r in results_with_cat if r.get('doc_category') == 'itinerary']
    for i, r in enumerate(itinerary_results, 1):
        year, batch = extract_batch_info(r.get('filepath', ''), base_dir, r.get('source_zip'))
        ws_itn.append([
            i, year, batch,
            r.get('invoice_type', ''), r.get('invoice_code', ''),
            r.get('invoice_no', ''), r.get('date', ''),
            r.get('buyer', ''), r.get('seller', ''),
            r.get('item', ''), r.get('amount', ''),
            r.get('tax_rate', ''), r.get('tax', ''),
            r.get('total', ''), r.get('remarks', ''),
            r.get('filename', '')
        ])
    
    _format_header(ws_itn, len(itn_headers))
    _auto_width(ws_itn, itn_headers)
    
    # Sheet 3: 按报销类别汇总
    ws_cat = wb.create_sheet('按报销类别汇总')
    cat_headers = ['大类', '子类别', '发票数量', '金额合计', '税额合计', '价税合计']
    ws_cat.append(cat_headers)
    
    # 计算各类别汇总
    total_amount = 0
    total_tax = 0
    total_with_tax = 0
    
    for main_cat in ['综合费用', '差旅费用']:
        main_cat_rows = []  # 收集该大类的所有行
        main_amount = 0
        main_tax = 0
        main_with_tax = 0
        
        for sub_cat in EXPENSE_CATEGORIES[main_cat].keys():
            # 统计该子类别的发票
            sub_results = [r for r in invoice_results 
                          if r.get('报销大类') == main_cat and r.get('报销子类') == sub_cat]
            count = len(sub_results)
            amount = sum(float(r.get('amount', 0) or 0) for r in sub_results)
            tax = sum(float(r.get('tax', 0) or 0) for r in sub_results)
            with_tax = sum(float(r.get('total', 0) or 0) for r in sub_results)
            
            if count > 0 or sub_cat == '其它':  # 显示有数据的类别，以及"其它"
                main_cat_rows.append([main_cat, sub_cat, count, amount, tax, with_tax])
                main_amount += amount
                main_tax += tax
                main_with_tax += with_tax
        
        # 写入该大类的所有子类别
        for row in main_cat_rows:
            ws_cat.append(row)
        
        # 大类小计
        if main_cat_rows:
            ws_cat.append(['', f'{main_cat}小计', '', main_amount, main_tax, main_with_tax])
            # 小计行格式
            for cell in ws_cat[ws_cat.max_row]:
                cell.font = Font(bold=True)
            total_amount += main_amount
            total_tax += main_tax
            total_with_tax += main_with_tax
        
        # 空行分隔
        ws_cat.append([''] * 6)
    
    # 待确认
    pending_results = [r for r in invoice_results if r.get('报销大类') == '待确认']
    pending_count = len(pending_results)
    pending_amount = sum(float(r.get('amount', 0) or 0) for r in pending_results)
    pending_tax = sum(float(r.get('tax', 0) or 0) for r in pending_results)
    pending_with_tax = sum(float(r.get('total', 0) or 0) for r in pending_results)
    
    if pending_count > 0:
        ws_cat.append(['待确认', '-', pending_count, pending_amount, pending_tax, pending_with_tax])
        ws_cat.append([''] * 6)
    
    # 总计
    ws_cat.append(['', '总计', '', total_amount + pending_amount, 
                   total_tax + pending_tax, total_with_tax + pending_with_tax])
    for cell in ws_cat[ws_cat.max_row]:
        cell.font = Font(bold=True, size=12)
        cell.fill = PatternFill(start_color='E7E6E6', end_color='E7E6E6', fill_type='solid')
    
    _format_header(ws_cat, len(cat_headers))
    _auto_width(ws_cat, cat_headers)
    
    # Sheet 4: 非发票文件
    ws_other = wb.create_sheet('非发票文件')
    other_headers = ['序号', '文件名', '文档类型', '原因/备注']
    ws_other.append(other_headers)
    
    other_results = [r for r in results if r.get('doc_category') not in ['invoice', 'itinerary']]
    for i, r in enumerate(other_results, 1):
        doc_type = '结账单' if r.get('doc_category') == 'receipt' else '未知'
        reason = r.get('error', '无法识别为发票或行程单')
        ws_other.append([i, r.get('filename', ''), doc_type, reason])
    
    _format_header(ws_other, len(other_headers))
    _auto_width(ws_other, other_headers)
    
    return wb


def _auto_width(ws, headers):
    """自动调整列宽。"""
    for i, h in enumerate(headers, 1):
        col_letter = get_column_letter(i)
        # 根据列内容设置宽度
        max_len = len(str(h)) * 2  # 中文字符宽度加倍
        for row in ws.iter_rows(min_row=2, min_col=i, max_col=i, values_only=True):
            val = row[0]
            if val:
                cell_len = len(str(val))
                if any('\u4e00' <= c <= '\u9fff' for c in str(val)):
                    cell_len = cell_len * 1.8
                max_len = max(max_len, cell_len)
        ws.column_dimensions[col_letter].width = min(max(max_len + 2, 10), 45)
    
    # 金额列右对齐，序号列整数格式
    seq_col_idx = None
    for ci, h in enumerate(headers, 1):
        if h == '序号':
            seq_col_idx = ci
            break
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            if isinstance(cell.value, (int, float)):
                cell.alignment = Alignment(horizontal='right')
                # 序号列用整数格式，金额列保留两位小数
                if cell.column == seq_col_idx:
                    cell.number_format = '0'
                else:
                    cell.number_format = '#,##0.00'


def _create_monthly_summary(wb, invoices, base_dir=''):
    """按月汇总。缺日期的发票归入'未确定月份'。"""
    ws = wb.create_sheet('按月汇总')
    monthly = defaultdict(lambda: {'count': 0, 'amount': 0, 'tax': 0, 'total': 0})
    
    for inv in invoices:
        date = inv.get('date', '')
        if date and len(date) >= 7:
            month_key = date[:7]
        else:
            month_key = '未确定月份'
        monthly[month_key]['count'] += 1
        if inv.get('amount'):
            monthly[month_key]['amount'] += inv['amount']
        if inv.get('tax'):
            monthly[month_key]['tax'] += inv['tax']
        if inv.get('total'):
            monthly[month_key]['total'] += inv['total']
    
    headers = ['月份', '发票数量', '金额(不含税)', '税额', '价税合计']
    ws.append(headers)
    _format_header(ws, len(headers))
    
    # Sort: dated months first, then '未确定月份' last
    dated = sorted([k for k in monthly.keys() if k != '未确定月份'])
    all_keys = dated + (['未确定月份'] if '未确定月份' in monthly else [])
    
    for month_key in all_keys:
        d = monthly[month_key]
        ws.append([month_key, d['count'], d['amount'], d['tax'], d['total']])
    
    # 合计行
    total_count = sum(d['count'] for d in monthly.values())
    total_amount = sum(d['amount'] for d in monthly.values())
    total_tax = sum(d['tax'] for d in monthly.values())
    total_total = sum(d['total'] for d in monthly.values())
    ws.append(['合计', total_count, total_amount, total_tax, total_total])
    
    # 格式化合计行
    for cell in ws[ws.max_row]:
        cell.font = Font(bold=True)
    
    _auto_width(ws, headers)


def _create_quarterly_summary(wb, invoices, base_dir=''):
    """按季度汇总。缺日期的发票归入'未确定季度'。"""
    ws = wb.create_sheet('按季度汇总')
    quarterly = defaultdict(lambda: {'count': 0, 'amount': 0, 'tax': 0, 'total': 0})
    
    for inv in invoices:
        date = inv.get('date', '')
        if date and len(date) >= 7:
            year = date[:4]
            month = int(date[5:7])
            q = (month - 1) // 3 + 1
            q_key = f"{year}Q{q}"
        else:
            q_key = '未确定季度'
        quarterly[q_key]['count'] += 1
        if inv.get('amount'):
            quarterly[q_key]['amount'] += inv['amount']
        if inv.get('tax'):
            quarterly[q_key]['tax'] += inv['tax']
        if inv.get('total'):
            quarterly[q_key]['total'] += inv['total']
    
    headers = ['季度', '发票数量', '金额(不含税)', '税额', '价税合计']
    ws.append(headers)
    _format_header(ws, len(headers))
    
    dated = sorted([k for k in quarterly.keys() if k != '未确定季度'])
    all_keys = dated + (['未确定季度'] if '未确定季度' in quarterly else [])
    
    for q_key in all_keys:
        d = quarterly[q_key]
        ws.append([q_key, d['count'], d['amount'], d['tax'], d['total']])
    
    total_count = sum(d['count'] for d in quarterly.values())
    total_amount = sum(d['amount'] for d in quarterly.values())
    total_tax = sum(d['tax'] for d in quarterly.values())
    total_total = sum(d['total'] for d in quarterly.values())
    ws.append(['合计', total_count, total_amount, total_tax, total_total])
    
    for cell in ws[ws.max_row]:
        cell.font = Font(bold=True)
    
    _auto_width(ws, headers)


def _create_yearly_summary(wb, invoices, base_dir=''):
    """按年度汇总。优先用开票日期，其次用文件夹路径年份。"""
    ws = wb.create_sheet('按年度汇总')
    yearly = defaultdict(lambda: {'count': 0, 'amount': 0, 'tax': 0, 'total': 0})
    
    for inv in invoices:
        # 优先用开票日期
        date = inv.get('date', '')
        if date and len(date) >= 4:
            year = date[:4] + '年'
        else:
            # 其次用文件夹路径的年份
            year, _ = extract_batch_info(inv['filepath'], base_dir, source_zip=inv.get('source_zip'))
        
        if year:
            yearly[year]['count'] += 1
            if inv.get('amount'):
                yearly[year]['amount'] += inv['amount']
            if inv.get('tax'):
                yearly[year]['tax'] += inv['tax']
            if inv.get('total'):
                yearly[year]['total'] += inv['total']
        else:
            yearly['未确定年度']['count'] += 1
            if inv.get('amount'):
                yearly['未确定年度']['amount'] += inv['amount']
            if inv.get('tax'):
                yearly['未确定年度']['tax'] += inv['tax']
            if inv.get('total'):
                yearly['未确定年度']['total'] += inv['total']
    
    headers = ['年度', '发票数量', '金额(不含税)', '税额', '价税合计']
    ws.append(headers)
    _format_header(ws, len(headers))
    
    for y_key in sorted(yearly.keys()):
        d = yearly[y_key]
        ws.append([y_key, d['count'], d['amount'], d['tax'], d['total']])
    
    total_count = sum(d['count'] for d in yearly.values())
    total_amount = sum(d['amount'] for d in yearly.values())
    total_tax = sum(d['tax'] for d in yearly.values())
    total_total = sum(d['total'] for d in yearly.values())
    ws.append(['合计', total_count, total_amount, total_tax, total_total])
    
    for cell in ws[ws.max_row]:
        cell.font = Font(bold=True)
    
    _auto_width(ws, headers)


def _create_category_summary(wb, invoices, base_dir=''):
    """按费用类别汇总。"""
    ws = wb.create_sheet('按费用类别汇总')
    categories = defaultdict(lambda: {'count': 0, 'amount': 0, 'tax': 0, 'total': 0})
    
    for inv in invoices:
        item = inv.get('item', '未分类')
        # 提取类别: *餐饮服务*餐饮服务 -> 餐饮服务
        m = re.match(r'\*([^*]+)\*', item)
        if m:
            cat = m.group(1)
        else:
            cat = item
        
        categories[cat]['count'] += 1
        if inv.get('amount'):
            categories[cat]['amount'] += inv['amount']
        if inv.get('tax'):
            categories[cat]['tax'] += inv['tax']
        if inv.get('total'):
            categories[cat]['total'] += inv['total']
    
    headers = ['费用类别', '发票数量', '金额(不含税)', '税额', '价税合计', '占比']
    ws.append(headers)
    _format_header(ws, len(headers))
    
    grand_total = sum(d['total'] for d in categories.values())
    
    for cat in sorted(categories.keys(), key=lambda x: -categories[x]['total']):
        d = categories[cat]
        pct = f"{d['total']/grand_total*100:.1f}%" if grand_total else '0%'
        ws.append([cat, d['count'], d['amount'], d['tax'], d['total'], pct])
    
    total_count = sum(d['count'] for d in categories.values())
    total_amount = sum(d['amount'] for d in categories.values())
    total_tax = sum(d['tax'] for d in categories.values())
    total_total_val = sum(d['total'] for d in categories.values())
    ws.append(['合计', total_count, total_amount, total_tax, total_total_val, '100%'])
    
    for cell in ws[ws.max_row]:
        cell.font = Font(bold=True)
    
    _auto_width(ws, headers)


# ============================================================
# CLI Entry Point
# ============================================================

def _get_file_sig(filepath):
    """获取文件签名（mtime + size），用于判断文件是否已修改。"""
    try:
        st = os.stat(filepath)
        return f"{st.st_mtime_ns}_{st.st_size}"
    except OSError:
        return None


def _load_cache(cache_path):
    """加载缓存文件。返回 dict[filepath -> {sig, result}] 或空dict。"""
    if not os.path.exists(cache_path):
        return {}
    try:
        with open(cache_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return {}


def _save_cache(cache_path, cache_data):
    """保存缓存文件。"""
    cache_dir = os.path.dirname(cache_path)
    if cache_dir and not os.path.exists(cache_dir):
        os.makedirs(cache_dir, exist_ok=True)
    try:
        with open(cache_path, 'w', encoding='utf-8') as f:
            json.dump(cache_data, f, ensure_ascii=False, default=str)
    except OSError as e:
        print(f"[WARN] Cannot save cache: {e}")


def _get_folder_month(filepath, base_dir):
    """从文件路径中提取它所属的月份文件夹 (year, month)。
    
    返回 (year, month) 元组或 None。
    用于判断文件属于哪个月份的报销批次——优先信任用户的文件夹分类。
    """
    rel_path = os.path.relpath(filepath, base_dir)
    path_parts = rel_path.replace('\\', '/').split('/')
    
    found_year_in_path = None
    last_month_folder = None
    
    for part in path_parts:
        fm = folder_name_to_month(part)
        if fm is not None:
            fy, fmonth = fm
            if fy is not None:
                last_month_folder = (fy, fmonth)
            else:
                # 仅有月份，从路径中找年份
                for other_part in path_parts:
                    ym = re.match(r'^(\d{4})\s*年?$', other_part)
                    if ym:
                        last_month_folder = (int(ym.group(1)), fmonth)
                        break
        # 记录路径中的年份
        ym = re.match(r'^(\d{4})\s*年?$', part)
        if ym:
            found_year_in_path = int(ym.group(1))
    
    return last_month_folder


def list_available_years(base_dir):
    """列出根目录下的所有年份文件夹。
    
    返回: [(year_int, folder_name, file_count), ...] 按年份倒序
    """
    base_dir = os.path.abspath(base_dir)
    years = []
    
    for entry in os.listdir(base_dir):
        year_path = os.path.join(base_dir, entry)
        if not os.path.isdir(year_path):
            continue
        # 匹配 "2024年" / "2024" 等年份文件夹
        m = re.match(r'^(\d{4})\s*年?$', entry)
        if m:
            year = int(m.group(1))
            # 统计PDF/OFD文件数
            count = 0
            for root, _, filenames in os.walk(year_path):
                count += sum(1 for f in filenames if f.lower().endswith(('.pdf', '.ofd')))
            years.append((year, entry, count))
    
    return sorted(years, key=lambda x: -x[0])


def list_available_months(base_dir, year):
    """列出指定年份下的所有月份文件夹。
    
    返回: [(month_int, folder_name, file_count), ...] 按月份排序
    """
    base_dir = os.path.abspath(base_dir)
    months = []
    
    # 找到年份目录
    year_dir = None
    for entry in os.listdir(base_dir):
        m = re.match(r'^(\d{4})\s*年?$', entry)
        if m and int(m.group(1)) == year:
            year_dir = os.path.join(base_dir, entry)
            break
    
    if not year_dir:
        return months
    
    for entry in os.listdir(year_dir):
        entry_path = os.path.join(year_dir, entry)
        if not os.path.isdir(entry_path):
            continue
        fm = folder_name_to_month(entry)
        if fm is not None:
            fy, fmonth = fm
            # 如果文件夹名本身含年份，验证是否匹配
            if fy is None or fy == year:
                count = sum(1 for f in os.listdir(entry_path) 
                           if os.path.isfile(os.path.join(entry_path, f)) 
                           and f.lower().endswith(('.pdf', '.ofd')))
                months.append((fmonth, entry, count))
    
    return sorted(months, key=lambda x: x[0])


def _find_year_dir(base_dir, year):
    """在根目录下查找对应年份的目录路径。返回绝对路径或None。"""
    base_dir = os.path.abspath(base_dir)
    for entry in os.listdir(base_dir):
        entry_path = os.path.join(base_dir, entry)
        if not os.path.isdir(entry_path):
            continue
        m = re.match(r'^(\d{4})\s*年?$', entry)
        if m and int(m.group(1)) == year:
            return entry_path
    return None


def _find_month_dir(base_dir, year, month):
    """在根目录下查找对应月份的目录路径。返回绝对路径或None。"""
    year_dir = _find_year_dir(base_dir, year)
    if not year_dir:
        return None
    
    for entry in os.listdir(year_dir):
        entry_path = os.path.join(year_dir, entry)
        if not os.path.isdir(entry_path):
            continue
        fm = folder_name_to_month(entry)
        if fm is not None:
            fy, fmonth = fm
            if (fy is None or fy == year) and fmonth == month:
                return entry_path
    return None


def _filter_results_by_month(results, month_filter, base_dir):
    """按月份过滤结果。
    
    过滤策略（优先信任用户的文件夹分类）：
    1. 如果文件路径中有月份文件夹，用文件夹分类（你放在哪个月就属于哪个月）
    2. 如果没有月份文件夹（如文件直接在年份根目录），用开票日期判断
    
    这保证了：20260331文件夹里的2月发票仍归入3月报销批次。
    """
    if not month_filter:
        return results
    
    target_year, target_month = month_filter
    filtered = []
    
    for r in results:
        filepath = r.get('filepath', '')
        
        # 对于zip内文件，用source_zip路径来判断年份/月份
        effective_path = r.get('source_zip') or filepath
        
        # 策略1：从文件夹名判断月份（优先）
        folder_month = _get_folder_month(effective_path, base_dir)
        if folder_month is not None:
            fy, fm = folder_month
            if fy == target_year and fm == target_month:
                filtered.append(r)
            continue  # 文件夹分类明确，不再用开票日期判断
        
        # 策略2：没有月份文件夹，用开票日期兜底
        date = r.get('date', '')
        if date and len(date) >= 7:
            try:
                y = int(date[:4])
                m = int(date[5:7])
                if y == target_year and m == target_month:
                    filtered.append(r)
            except (ValueError, IndexError):
                pass
    
    return filtered


def main():
    parser = argparse.ArgumentParser(description='中国电子发票/行程单批量提取工具')
    parser.add_argument('input_dir', nargs='?', default=None,
                        help='包含发票PDF/OFD文件的根目录')
    parser.add_argument('-o', '--output', default=None, help='输出Excel文件路径')
    parser.add_argument('--json', action='store_true', help='同时输出JSON格式的提取结果')
    parser.add_argument('--month', default=None, 
                        help='只处理指定月份的发票，支持格式: 2026-03, 202603, 2026年3月, 2026年03月')
    parser.add_argument('--year', default=None,
                        help='只处理指定年份的发票，支持格式: 2024, 2024年')
    parser.add_argument('--no-cache', action='store_true', help='禁用增量缓存，强制全量提取')
    parser.add_argument('--list', action='store_true', help='列出可用的年份和月份，不执行提取')
    args = parser.parse_args()
    
    # 确定base_dir
    if args.input_dir:
        base_dir = os.path.abspath(args.input_dir)
    else:
        # 尝试使用当前工作目录
        base_dir = os.getcwd()
    
    if not os.path.isdir(base_dir):
        print(f"ERROR: Directory not found: {base_dir}")
        sys.exit(1)
    
    # 解析年份参数
    year_filter = parse_year_arg(args.year)
    if args.year and not year_filter:
        print(f"ERROR: Invalid year format: {args.year}")
        print(f"  Supported: 2024, 2024年")
        sys.exit(1)
    
    # 解析月份参数
    month_filter = parse_month_arg(args.month)
    if args.month and not month_filter:
        print(f"ERROR: Invalid month format: {args.month}")
        print(f"  Supported: 2026-03, 202603, 2026年3月, 2026年03月")
        sys.exit(1)
    
    # --year 和 --month 不能同时使用
    if year_filter and month_filter:
        print(f"ERROR: Cannot use --year and --month together. Use --month for specific month.")
        sys.exit(1)
    
    # 列出可用年份/月份
    if args.list:
        _list_available_periods(base_dir)
        return
    
    # 如果没有指定 --year 或 --month，且目录下有年份子目录，提示用户选择
    if not year_filter and not month_filter:
        years = list_available_years(base_dir)
        if years:
            print(f"\n[*] 发现以下年份的发票文件夹：")
            for y, name, count in years:
                print(f"  {name} ({count} 个PDF/OFD文件)")
            print(f"\n[!] 提示：")
            print(f"  按年整理：添加 --year {years[0][0]}")
            print(f"  按月整理：添加 --month {years[0][0]}-01")
            print(f"  全量整理：当前将处理所有文件")
            print(f"  查看详情：添加 --list\n")
        # 继续执行全量处理
    
    # 确定扫描的目录
    scan_dir = base_dir
    if year_filter and not month_filter:
        # 按年整理：扫描年份目录
        year_dir = _find_year_dir(base_dir, year_filter)
        if year_dir:
            scan_dir = year_dir
        else:
            print(f"ERROR: Year directory not found for {year_filter}")
            sys.exit(1)
    
    # 确定输出路径逻辑：
    # 1. 用户指定 -o → 使用指定路径
    # 2. --month → 月份文件夹/发票统计汇总表_YYYY-MM.xlsx（找不到月份文件夹则放年份目录）
    # 3. --year → 年份目录/发票统计汇总表_YYYY.xlsx
    # 4. 全量 → 根目录/发票统计汇总表.xlsx
    if args.output:
        output_path = args.output
    elif month_filter:
        y, m = month_filter
        # 尝试放到月份文件夹
        month_dir = _find_month_dir(base_dir, y, m)
        if month_dir:
            output_path = os.path.join(month_dir, f'发票统计汇总表_{y}-{m:02d}.xlsx')
        else:
            # 月份文件夹不存在，放到年份目录
            year_dir = _find_year_dir(base_dir, y)
            if year_dir:
                output_path = os.path.join(year_dir, f'发票统计汇总表_{y}-{m:02d}.xlsx')
            else:
                output_path = os.path.join(base_dir, f'发票统计汇总表_{y}-{m:02d}.xlsx')
    elif year_filter:
        year_dir = _find_year_dir(base_dir, year_filter)
        if year_dir:
            output_path = os.path.join(year_dir, f'发票统计汇总表_{year_filter}.xlsx')
        else:
            output_path = os.path.join(base_dir, f'发票统计汇总表_{year_filter}.xlsx')
    else:
        output_path = os.path.join(base_dir, '发票统计汇总表.xlsx')
    
    # 缓存路径（始终在根发票目录的.workbuddy下，不随扫描范围变化）
    # 检测根发票目录：如果scan_dir是base_dir的子目录，cache仍放base_dir
    cache_root = base_dir
    cache_path = os.path.join(cache_root, '.workbuddy', 'invoice_cache.json')
    use_cache = not args.no_cache
    
    # Scan
    print(f"Scanning: {scan_dir}")
    if month_filter:
        y, m = month_filter
        print(f"Month filter: {y}年{m}月")
    elif year_filter:
        print(f"Year filter: {year_filter}年")
    file_entries = scan_directory(scan_dir, month_filter=month_filter, year_filter=year_filter)
    
    # 统计直文件和zip内文件数量
    direct_count = sum(1 for e in file_entries if e['source_zip'] is None)
    zip_count = sum(1 for e in file_entries if e['source_zip'] is not None)
    print(f"Found {direct_count} files (PDF + OFD)" + 
          (f" + {zip_count} files from ZIP archives" if zip_count > 0 else ''))
    
    if not file_entries:
        print("No files found. Exiting.")
        return
    
    # 加载缓存
    cache = _load_cache(cache_path) if use_cache else {}
    cache_hits = 0
    cache_misses = 0
    
    # Process
    results = []
    stats = {'invoice': 0, 'itinerary': 0, 'receipt': 0, 'unknown': 0, 'errors': 0}
    tmp_dirs_to_clean = set()  # 需要清理的临时目录
    
    for i, entry in enumerate(file_entries, 1):
        filepath = entry['filepath']
        source_zip = entry['source_zip']
        zip_inner_path = entry['zip_inner_path']
        
        # 记录临时目录（用于最后清理）
        if source_zip:
            tmp_dir = os.path.join(os.path.dirname(filepath), '..')
            tmp_dirs_to_clean.add(os.path.normpath(tmp_dir))
        
        # 构建缓存key：
        # - 直文件：相对路径
        # - zip内文件：zip文件相对路径 + zip内路径
        if source_zip:
            zip_rel = os.path.relpath(source_zip, base_dir).replace('\\', '/')
            cache_key = f"zip:{zip_rel}!{zip_inner_path}"
        else:
            cache_key = os.path.relpath(filepath, base_dir).replace('\\', '/')
        
        # 检查缓存（zip内文件暂不缓存，因为临时目录文件mtime不稳定）
        file_sig = _get_file_sig(filepath) if not source_zip else None
        use_cache_for_this = use_cache and not source_zip
        
        if use_cache_for_this and cache_key in cache:
            cached = cache[cache_key]
            if cached.get('sig') == file_sig:
                # 缓存命中
                result = cached.get('result', {})
                if result:
                    result['filepath'] = filepath
                    # 补充zip来源信息
                    if source_zip:
                        result['source_zip'] = source_zip
                        result['zip_inner_path'] = zip_inner_path
                    results.append(result)
                    cache_hits += 1
                    cat = result.get('doc_category', 'unknown')
                    stats[cat] = stats.get(cat, 0) + 1
                    if result.get('error'):
                        stats['errors'] += 1
                    continue
        
        # 缓存未命中，提取
        cache_misses += 1
        result = process_single_file(filepath)
        
        # 对zip内文件，替换filepath为原始zip路径（便于追溯）
        if source_zip:
            result['source_zip'] = source_zip
            result['zip_inner_path'] = zip_inner_path
            # 修改filename显示为"zip文件名/内部路径"
            result['filename'] = f"{os.path.basename(source_zip)}/{zip_inner_path}"
        
        results.append(result)
        
        # 更新缓存（仅直文件）
        if use_cache_for_this and file_sig:
            cache[cache_key] = {
                'sig': file_sig,
                'result': {k: v for k, v in result.items() if k not in ('filepath', 'source_zip', 'zip_inner_path')}
            }
        
        cat = result.get('doc_category', 'unknown')
        stats[cat] = stats.get(cat, 0) + 1
        if result.get('error'):
            stats['errors'] += 1
        
        if cache_misses % 50 == 0 and cache_misses > 0:
            print(f"  Processed {cache_misses} new files...")
    
    # 按月份做最终过滤（优先用文件夹分类，兜底用开票日期）
    if month_filter:
        results = _filter_results_by_month(results, month_filter, base_dir)
        # 重新统计
        stats = {'invoice': 0, 'itinerary': 0, 'receipt': 0, 'unknown': 0, 'errors': 0}
        for r in results:
            cat = r.get('doc_category', 'unknown')
            stats[cat] = stats.get(cat, 0) + 1
            if r.get('error'):
                stats['errors'] += 1
    
    # 按年份做最终过滤（兜底用开票日期）
    if year_filter and not month_filter:
        results = _filter_results_by_year(results, year_filter, base_dir)
        stats = {'invoice': 0, 'itinerary': 0, 'receipt': 0, 'unknown': 0, 'errors': 0}
        for r in results:
            cat = r.get('doc_category', 'unknown')
            stats[cat] = stats.get(cat, 0) + 1
            if r.get('error'):
                stats['errors'] += 1
    
    print(f"\nResults:")
    print(f"  Invoices: {stats.get('invoice', 0)}")
    print(f"  Itineraries (non-invoice): {stats.get('itinerary', 0)}")
    print(f"  Receipts (non-invoice): {stats.get('receipt', 0)}")
    print(f"  Unknown: {stats.get('unknown', 0)}")
    print(f"  Errors: {stats['errors']}")
    if use_cache:
        print(f"  Cache hits: {cache_hits}, misses: {cache_misses}")
    
    # 重复发票检测
    duplicate_groups = _detect_duplicates(results)
    if duplicate_groups:
        total_dups = sum(len(g) - 1 for g in duplicate_groups.values())
        print(f"  Duplicates detected: {total_dups} (in {len(duplicate_groups)} groups)")
    
    # 保存缓存
    if use_cache:
        _save_cache(cache_path, cache)
        print(f"  Cache saved: {cache_path}")
    
    # Optional JSON output (save BEFORE Excel in case Excel save fails)
    if args.json:
        json_path = output_path.replace('.xlsx', '.json')
        # Convert non-serializable types
        for r in results:
            for k, v in r.items():
                if isinstance(v, (int, float)):
                    r[k] = v
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(results, f, ensure_ascii=False, indent=2, default=str)
        print(f"[DONE] JSON saved to: {json_path}")
    
    # Create Excel (主汇总表也去重，避免重复统计)
    try:
        wb = create_output_workbook(results, base_dir, duplicate_groups=duplicate_groups, remove_duplicates=True)
        wb.save(output_path)
        print(f"\n[DONE] Saved to: {output_path}")
    except PermissionError:
        print(f"\n[WARN] Cannot save Excel (file may be open): {output_path}")
        print(f"  JSON data is still available: {output_path.replace('.xlsx', '.json')}")
    
    # 按月整理时，按报销类别分类复制发票（仅--month模式）
    if month_filter:
        print("\n[*] 按报销类别分类整理发票...")
        y, m = month_filter
        # 分类输出目录：放在月份文件夹下
        month_dir = os.path.dirname(output_path)  # 月份文件夹路径
        category_base_dir = os.path.join(month_dir, '按类别整理')
        
        cat_stats, unclassified = _copy_invoices_by_category(results, category_base_dir, base_dir, duplicate_groups)
        
        # 打印分类统计
        print("\n  分类结果:")
        total_classified = 0
        for main_cat in EXPENSE_CATEGORIES.keys():
            main_total = 0
            sub_stats = []
            for sub_cat in EXPENSE_CATEGORIES[main_cat].keys():
                count = cat_stats[main_cat].get(sub_cat, 0)
                if count > 0:
                    sub_stats.append(f"{sub_cat}:{count}")
                    main_total += count
            if main_total > 0:
                print(f"    {main_cat}: {main_total} ({', '.join(sub_stats)})")
                total_classified += main_total
        
        pending_count = cat_stats['待确认'].get('count', 0)
        if pending_count > 0:
            print(f"    待确认: {pending_count}")
        
        print(f"\n  分类文件保存至: {category_base_dir}")
        
        # 生成带分类汇总的总表（放在按类别整理目录下）
        if total_classified > 0:
            print("\n[*] 生成分类汇总表...")
            try:
                # 创建带分类信息的工作簿
                cat_wb = create_categorized_workbook(results, base_dir, cat_stats, (y, m), duplicate_groups)
                cat_output_path = os.path.join(category_base_dir, f'发票分类汇总表_{y}-{m:02d}.xlsx')
                cat_wb.save(cat_output_path)
                print(f"  分类汇总表: {cat_output_path}")
            except Exception as e:
                print(f"  [WARN] 生成分类汇总表失败: {e}")
    
    # 清理临时目录（zip解压的文件）
    for tmp_dir in tmp_dirs_to_clean:
        try:
            shutil.rmtree(tmp_dir, ignore_errors=True)
        except Exception:
            pass


def _filter_results_by_year(results, year_filter, base_dir):
    """按年份过滤结果。
    
    过滤策略（与月份过滤类似，优先信任文件夹分类）：
    1. 如果文件路径中有年份文件夹，用文件夹分类
    2. 如果没有年份文件夹，用开票日期判断
    """
    filtered = []
    
    for r in results:
        filepath = r.get('filepath', '')
        
        # 对于zip内文件，用source_zip路径来判断年份/月份
        effective_path = r.get('source_zip') or filepath
        
        # 从文件夹路径中找年份
        rel_path = os.path.relpath(effective_path, base_dir)
        path_parts = rel_path.replace('\\', '/').split('/')
        
        folder_year = None
        for part in path_parts:
            # "2024年" / "2024"
            ym = re.match(r'^(\d{4})\s*年?$', part)
            if ym:
                folder_year = int(ym.group(1))
                break
            # "发票-20241231" / "20260331" 等月份文件夹中的年份
            fm = folder_name_to_month(part)
            if fm is not None:
                fy, _ = fm
                if fy is not None:
                    folder_year = fy
                    break
        
        # 策略1：从文件夹名判断年份（优先）
        if folder_year is not None:
            if folder_year == year_filter:
                filtered.append(r)
            continue
        
        # 策略2：没有年份文件夹，用开票日期兜底
        date = r.get('date', '')
        if date and len(date) >= 4:
            try:
                y = int(date[:4])
                if y == year_filter:
                    filtered.append(r)
            except (ValueError, IndexError):
                pass
    
    return filtered


def _list_available_periods(base_dir):
    """列出可用的年份和月份，供用户选择。"""
    years = list_available_years(base_dir)
    
    if not years:
        print("未发现年份格式的子文件夹。将处理当前目录下所有文件。")
        print(f"  使用方式: python invoice_extractor.py \"{base_dir}\"")
        return
    
    print(f"\n[*] 可用的发票年份和月份：")
    print(f"{'='*50}")
    
    for y, name, total_count in years:
        print(f"\n  [+] {name} ({total_count} 个文件)")
        print(f"  {'-'*40}")
        
        months = list_available_months(base_dir, y)
        if months:
            for m, folder_name, count in months:
                print(f"    {m:2d}月  {folder_name:25s} ({count:3d} 个文件)")
        else:
            print(f"    (无月份子文件夹，按报销批次存放)")
        
        print(f"  {'-'*40}")
        print(f"  按年整理: --year {y}")
        if months:
            print(f"  按月整理: --month {y}-{months[-1][0]:02d}")
    
    print(f"\n{'='*50}")
    print(f"[*] 使用示例：")
    print(f"  全量整理: python invoice_extractor.py \"{base_dir}\"")
    print(f"  按年整理: python invoice_extractor.py \"{base_dir}\" --year {years[0][0]}")
    print(f"  按月整理: python invoice_extractor.py \"{base_dir}\" --month {years[0][0]}-01")
    print()


if __name__ == '__main__':
    main()
