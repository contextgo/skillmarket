# baogaozc Skill

**英文名称**: baogaozc
**功能**: 主题报告生成 + 智能语音合成 + 自动上传交付

## 描述

根据用户提供的主题，自动搜集信息并生成不少于 **500 字** 的纯文字报告（包含客观事实 + 主观思考评价）。
优先使用托管 API Edge TTS 合成语音，失败自动回退至 `node-edge-tts`（Xiaoxiao Neural）。
通过 `ffmpeg` 合并音频，复制 `upload.py` 脚本并自动上传，最终返回 **HTTP 音频链接** 交付用户。

## 流程

1. 接收用户输入的主题，明确报告方向。

2. 根据主题搜索客观、真实、权威的信息。

3. 按照 **先客观事实陈述 + 后主观思考评价** 结构生成报告：

    - 纯文本、单一段落、无换行

    - 字数 ≥ 500 字

    - 内容流畅、无重复、无循环、无机械凑字

4. 将报告按自然断句拆分，每段 **100–120 字**。

5. 优先调用 **Edge TTS 托管 API** 生成语音：

    - API 地址：`https://tts.102465.xyz/api/tts`

    - 默认使用：`voice=云希`、`provider=azure`
    - 举例：
         https://tts.102465.xyz/api/tts?text=你好世界&voice=云希&provider=azure
		 ## Example GET URLs

**Azure with emotion:**
```
https://tts.102465.xyz/api/tts?text=今天天气真不错&provider=azure&voice=晓晓&emotion=温柔
```

**Volcengine specialty voice:**
```
https://tts.102465.xyz/api/tts?text=在遥远的东方，有一个古老的传说&provider=volcengine&voice=影视男解说%20中英混
```

**Edge dialect voice:**
```
https://tts.102465.xyz/api/tts?text=今天咱们唠唠嗑&provider=edge&voice=晓北%20辽宁%20女
```

    - 若超时、失败、过慢，则自动回退到本地 `node-edge-tts`，使用 `Xiaoxiao Neural` 逐段生成 MP3。

6. 使用 `ffmpeg` 按顺序合并所有 MP3，生成完整语音文件 `output.mp3`。

7. 检查当前技能目录是否存在 `upload.py`，如不存在，则从 `skills/latest-media-upload/upload.py` 复制到本技能目录。

8. 调用 `upload.py`，传入参数 `access_key=open123`，上传最终 MP3。

9. 获取上传后的音频链接，**强制使用 HTTP 协议**。

10. 校验链接可正常播放，将 HTTP 音频链接发送给用户。

## 报告生成严格规则

1. **无重复**：任何句子、观点不允许重复出现两次及以上。

2. **无循环**：禁止模板化循环、机械补字、乱凑内容。

3. **客观事实**：必须真实、具体、有依据，禁止使用占位文本。

4. **主观评价必须包含四层逻辑**：
现状分析 → 原因判断 → 未来趋势 → 个人观点。

5. **格式要求**：单段落、纯文本、无换行、≥500 字。

6. **失败重试**：出现重复、循环、乱补，视为生成失败，必须重新生成。

## TTS 语音自动选择逻辑

1. **提供商选择**

    - 默认：`azure`

    - 出现`电影解说/影视配音` → 使用 `volcengine`

    - 出现`方言/东北话/辽宁/四川` → 使用 `edge`

2. **声线选择**

    - 默认：`晓晓`

    - 正式 / 报告 / 权威内容 → 切换为 `晓北`

3. **情感选择**（仅 azure 有效）

    - 正面 / 温和 → `温柔`

    - 激昂 / 挑战 → `激情`

    - 严肃 / 学术 → 不设置情感

4. **语速与音调**

    - 默认：0%

    - 文本过长 → 语速 +10%

5. 最终自动构建最优 TTS 参数，保证语音自然流畅。

## TTS API 信息

- **Base URL**：`https://tts.102465.xyz`

- **合成语音**：`/api/tts`（POST/GET）

- **支持提供商**：`azure`、`volcengine`、`edge`

- **默认发音人**：晓晓（Xiaoxiao Neural）

## 输入

用户只需提供一个主题，例如：人工智能发展趋势、春季养生知识、2035 年职业教育展望。

## 输出

1. 一篇 ≥500 字的纯文本报告（单段落、无换行）

2. 可直接播放的 **HTTP 协议音频 MP3 链接**

## 依赖工具

- node-edge-tts

- ffmpeg

- [upload.py](upload.py)（来自 latest-media-upload）

## 注意事项

1. 报告必须遵循：**先客观事实，后主观评价**。

2. 文本分段必须按自然断句，100–120 字 / 段。

3. 回退模式必须使用 `Xiaoxiao Neural` 中文音色。

4. 音频链接**必须强制 HTTP**，禁止使用 HTTPS。

6. 报告禁止重复、循环、乱补，否则必须重新生成。

---