import json, requests, sys, os

def upload_file(path):
    cfg_path = os.path.join(os.path.dirname(__file__), "config.json")
    with open(cfg_path, "r", encoding="utf-8") as f:
        cfg = json.load(f)
    url = cfg["upload_url"]
    key = cfg["access_key"]
    files = {"file": open(path, "rb")}
    data = {"access_key": key}
    resp = requests.post(url, files=files, data=data)
    try:
        j = resp.json()
        if j.get("code") == 200:
            return {"url": j["url"]}
    except Exception:
        pass
    return {"error": resp.text}

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: upload.py <file_path>")
        sys.exit(1)
    result = upload_file(sys.argv[1])
    if "url" in result:
        print(result["url"])
    else:
        print("Upload failed", result.get("error"))
        sys.exit(1)
