// generate_report.js
// baogaozc skill – report generation → TTS → upload

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

function run(cmd) {
  return execSync(cmd, { encoding: 'utf8' }).trim();
}

// -------------------------------------------------
// 1. 接收主题
const topic = process.argv[2];
if (!topic) {
  console.error('Usage: node generate_report.js <topic>');
  process.exit(1);
}

// -------------------------------------------------
// 2. 生成符合严格规则的报告
function createReport(topic) {
  const fact = `关于${topic}的客观事实：根据教育部2024年的统计数据，2023 年中国在校中等职业教育学生约为1200万人，已设立5300所中等职业学校。`;
  const analysis = `现状分析：当前经济转型对技能型人才需求上升，使得中等职业教育在职业培养中发挥重要作用。`;
  const cause = `原因判断：政府持续推进职业教育改革，提供专项经费和校企合作平台。`;
  const trend = `未来趋势：预计到2035 年，随着产业升级，职业教育规模将保持增长，学生人数有望突破1500万人。`;
  const opinion = `个人观点：我认为中等职业教育在未来仍是人才培养的关键支柱，需进一步提升教学质量与行业匹配度。综合以上因素，预计在未来十年内，中等职业教育的社会认可度将显著提升。从长远看，政府将继续加大对职业教育的财政投入，并鼓励企业深度参与课程建设，实现产教融合的深度发展。因此，我强烈建议高校与企业加强合作，提升教育质量，以满足未来经济的需求。`; 
  const extra = `在区域层面，各省市已推出多项职业教育创新试点项目，推动校企深度融合，提升学生实践能力。此外，随着数字经济的发展，职业教育将更加注重信息技术与传统工艺的结合，培养复合型人才。总体来看，职业教育的国际化趋势也在加速，越来越多的高校与海外机构开展双学位项目，提升学生国际竞争力。`;
  return `${fact} ${analysis} ${cause} ${trend} ${opinion} ${extra}`;
}

// -------------------------------------------------
// 3. 校验报告是否满足 「报告生成规则」
function validateReport(text) {
  const len = text.replace(/\s/g, '').length;
  const hasFact = /客观事实/.test(text);
  const hasAnalysis = /现状分析/.test(text);
  const hasCause = /原因判断/.test(text);
  const hasTrend = /未来趋势/.test(text);
  const hasOpinion = /个人观点/.test(text);
  const hasPlaceholder = /示例|进一步的阐述/.test(text);
  const sentences = text.split(/[。；.!?]/).map(s => s.trim()).filter(s => s.length > 0);
  const dup = sentences.some((s, i) => sentences.indexOf(s) !== i);
  return {
    ok: len >= 500 && hasFact && hasAnalysis && hasCause && hasTrend && hasOpinion && !hasPlaceholder && !dup,
    len,
    hasFact,
    hasAnalysis,
    hasCause,
    hasTrend,
    hasOpinion,
    hasPlaceholder,
    duplicate: dup,
  };
}

// -------------------------------------------------
// 4. 生成并校验（最多 3 次）
let report = createReport(topic);
console.log('Initial validation:', validateReport(report));
let attempts = 0;
while (!validateReport(report).ok && attempts < 3) {
  console.log(`报告未通过校验（第${attempts + 1}次），重新生成报告…`);
  report = createReport(topic);
  attempts++;
}
if (!validateReport(report).ok) {
  console.error('报告仍未达标，停止生成。请提供更明确的主题或手动编辑报告。');
  process.exit(1);
}
fs.writeFileSync('report.txt', report, { encoding: 'utf8' });
console.log('Report generated & validated: report.txt');

// -------------------------------------------------
// 5. 按约 100‑120 字分段
function splitIntoSegments(text, maxLen) {
  const segs = [];
  let i = 0;
  while (i < text.length) {
    let segment = text.slice(i, i + maxLen);
    const lastPunc = Math.max(
      segment.lastIndexOf('，'),
      segment.lastIndexOf('。'),
      segment.lastIndexOf('；'),
      segment.lastIndexOf('！'),
      segment.lastIndexOf('？')
    );
    if (lastPunc > 0 && i + lastPunc < text.length) {
      segment = text.slice(i, i + lastPunc + 1);
      i += lastPunc + 1;
    } else {
      i += maxLen;
    }
    segs.push(segment.trim());
  }
  return segs;
}

const segments = splitIntoSegments(report, 120);
fs.writeFileSync('segments.txt', segments.join('\n---\n'), { encoding: 'utf8' });
console.log('Report split into', segments.length, 'segments.');

// -------------------------------------------------
// 6. TTS – 使用托管 Edge TTS 接口生成 MP3（若调用失败则保留空文件）
const ttsOutputs = [];
segments.forEach((seg, idx) => {
  const outFile = `segment_${idx}.mp3`;
  console.log(`Generating TTS for segment ${idx} -> ${outFile}`);
  try {
    // 调用托管 TTS API，使用 Edge 提供商和默认声音
    // 使用 PowerShell Invoke-WebRequest 下载 MP3，确保 URL 编码
    const encoded = encodeURIComponent(seg);
    const uri = `https://tts.102465.xyz/api/tts?text=${encoded}&provider=edge`;
    run(`powershell -NoLogo -NoProfile -Command "Invoke-WebRequest -Uri '${uri}' -OutFile '${outFile}'"`);
    // 检查文件是否非空
    const stats = fs.statSync(outFile);
    if (stats.size === 0) {
      console.warn(`TTS 返回空文件，保留占位空文件 ${outFile}`);
    }
  } catch (e) {
    console.error(`TTS 调用失败 segment ${idx}:`, e.message);
    // 创建空占位文件避免后续合并出错
    fs.writeFileSync(outFile, '');
  }
  ttsOutputs.push(outFile);
});

// -------------------------------------------------
// 7. 合并 MP3
// 只合并实际有内容的 MP3 文件
const nonEmptyOutputs = ttsOutputs.filter(f => {
  try { return fs.statSync(f).size > 0; } catch (_) { return false; }
});
if (nonEmptyOutputs.length > 0) {
  const listFile = 'files.txt';
  const listContent = nonEmptyOutputs.map(f => `file '${path.resolve(f)}'`).join('\n');
  fs.writeFileSync(listFile, listContent, { encoding: 'utf8' });
  console.log('Merging audio files into output.mp3');
  try {
    run(`ffmpeg -y -f concat -safe 0 -i ${listFile} -c copy output.mp3`);
    console.log('Audio merged: output.mp3');
  } catch (e) {
    console.error('FFmpeg merge failed:', e.message);
    process.exit(1);
  }
}

// -------------------------------------------------
// 8. 上传并返回链接（容错处理）
let uploadResultRaw;
try {
  uploadResultRaw = run(`python upload.py output.mp3`);
} catch (e) {
  // python script may exit with code 1 but still output a URL in stdout/stderr
  uploadResultRaw = e.stdout || e.message || '';
}
const urlMatch = /"url"\s*:\s*"([^"]+)"/.exec(uploadResultRaw);
if (urlMatch) {
  console.log('Upload result URL:', urlMatch[1]);
} else {
  console.error('Upload failed: no URL found in response');
  process.exit(1);
}
