---
name: sms
version: "2.0.0"
author: BytesAgain
homepage: https://bytesagain.com
source: https://github.com/bytesagain/ai-skills
license: MIT-0
tags: [sms, tool, utility]
description: "Send SMS messages, manage contacts, and track delivery with templates. Use when drafting texts, scheduling sends, optimizing templates, tracking delivery."
---

# SMS — Content Toolkit

SMS v2.0.0 is a content creation and management toolkit for drafting, editing, optimizing, and scheduling text-based content. It provides a comprehensive set of commands for every stage of the content lifecycle — from initial drafts through tone adjustments and translations to final scheduling and publication.

All operations are logged with timestamps and stored locally for full traceability. Each command can record input for later review, or display recent entries when called without arguments.

## Commands

| Command | Description |
|---------|-------------|
| `sms draft <input>` | Draft new content — saves a draft entry with timestamp |
| `sms edit <input>` | Edit existing content — logs edit operations |
| `sms optimize <input>` | Optimize content for engagement or performance |
| `sms schedule <input>` | Schedule content for future delivery or publication |
| `sms hashtags <input>` | Generate or log hashtag suggestions for content |
| `sms hooks <input>` | Create attention-grabbing hooks for content openers |
| `sms cta <input>` | Craft call-to-action phrases for content |
| `sms rewrite <input>` | Rewrite content with a different angle or approach |
| `sms translate <input>` | Translate content to another language or style |
| `sms tone <input>` | Adjust the tone of content (formal, casual, etc.) |
| `sms headline <input>` | Generate or refine headlines for content |
| `sms outline <input>` | Create content outlines and structural plans |
| `sms stats` | Show summary statistics across all command categories |
| `sms export <fmt>` | Export all data (formats: `json`, `csv`, `txt`) |
| `sms search <term>` | Search across all log entries for a keyword |
| `sms recent` | Show the 20 most recent activity log entries |
| `sms status` | Health check — version, data dir, entry count, disk usage |
| `sms help` | Show help with all available commands |
| `sms version` | Print current version (v2.0.0) |

Each content command (draft, edit, optimize, etc.) works in two modes:
- **With arguments** — saves the input with a timestamp to its dedicated log file
- **Without arguments** — displays the 20 most recent entries from that log

## Data Storage

All data is stored locally in `~/.local/share/sms/`:

- **Per-command logs**: `draft.log`, `edit.log`, `optimize.log`, `schedule.log`, `hashtags.log`, `hooks.log`, `cta.log`, `rewrite.log`, `translate.log`, `tone.log`, `headline.log`, `outline.log`
- **Activity history**: `history.log` — chronological log of all operations
- **Exports**: `export.json`, `export.csv`, or `export.txt` when using the export command

Log format: `YYYY-MM-DD HH:MM|<input>` (pipe-delimited timestamp and value).

## Requirements

- **Bash** 4.0+ (uses `set -euo pipefail`)
- **Standard Unix tools**: `date`, `wc`, `du`, `head`, `tail`, `grep`, `basename`, `cat`
- No external dependencies, API keys, or network access required
- Works on Linux and macOS

## When to Use

1. **Drafting social media posts** — Use `sms draft` to capture raw post ideas with timestamps, then `sms edit` to refine them and `sms hashtags` to generate relevant tags
2. **Content pipeline management** — Track content through its lifecycle: `draft` → `edit` → `optimize` → `schedule`, with full history at every stage
3. **Tone and style iteration** — Use `sms tone` and `sms rewrite` to experiment with different voices, then compare results with `sms search`
4. **Multilingual content** — Use `sms translate` to log translated versions alongside originals, keeping everything organized by timestamp
5. **Content auditing and reporting** — Use `sms stats` for an overview, `sms recent` for latest activity, and `sms export json` for backup or analysis in external tools

## Examples

### Draft and refine content

```bash
# Create a draft
sms draft "New product launch: AI-powered writing assistant"

# Edit the draft
sms edit "AI-powered writing assistant — now with real-time suggestions"

# Adjust the tone
sms tone "Make it more casual and friendly"

# Add a call-to-action
sms cta "Try it free for 14 days — no credit card required"
```

### Generate supporting elements

```bash
# Create hashtags
sms hashtags "#AIWriting #ContentCreation #ProductivityTools"

# Write an attention hook
sms hooks "What if your first draft was already 80% done?"

# Create a headline
sms headline "Stop Staring at Blank Pages: AI That Writes With You"
```

### Review and export

```bash
# View recent activity
sms recent

# Search for specific content
sms search "product launch"

# Check overall stats
sms stats

# Export everything as JSON
sms export json

# Health check
sms status
```

### Content scheduling workflow

```bash
# Outline the campaign
sms outline "Week 1: Teaser posts. Week 2: Feature highlights. Week 3: Launch day."

# Schedule individual pieces
sms schedule "Monday 9AM: Teaser post #1"
sms schedule "Wednesday 2PM: Feature highlight video"

# Optimize for engagement
sms optimize "Add emojis, shorten to under 280 chars"
```

## How It Works

SMS uses a simple file-based storage system. Each command writes timestamped entries to its own `.log` file in the data directory. The `history.log` file maintains a chronological record of all operations across all commands. The `stats` command aggregates line counts from all log files, while `export` serializes everything into your chosen format (JSON, CSV, or plain text). The `search` command performs case-insensitive grep across all log files.

---

*Powered by BytesAgain | bytesagain.com | hello@bytesagain.com*
