---
name: face-analysis
description: 专业人脸照片分析与评分系统。使用计算机视觉算法检测面部关键点，分析五官比例、面部对称性、黄金比例契合度、皮肤质量等多维度指标，输出综合评分与详细报告。适用于人像摄影评估、美学分析、趣味打分等场景。用户发送人脸照片后自动分析，支持生成结构化JSON报告或可读文本报告。
---

# 人脸照片专业分析技能

## 功能概述

本技能提供基于计算机视觉的专业人脸分析能力，可评估以下维度：

| 分析维度 | 说明 |
|---------|------|
| 三庭五眼比例 | 面部纵向/横向比例均匀度分析 |
| 面部对称性 | 左右脸对称度评分 |
| 黄金比例 | 面部各段与1.618黄金比例的契合度 |
| 皮肤质量 | 亮度均匀度、纹理细腻度评估 |
| 综合评分 | 多维度加权总分与星级评定 |

## 使用方式

### 场景1：用户发送照片后分析

用户通过消息渠道发送人脸照片后，自动触发分析：

```python
# 从消息附件获取图片路径
image_path = context["MediaPath"]  # 或 context["MediaPaths"][0]

# 运行分析脚本
exec(f"python3 scripts/face_analyzer.py {image_path}")

# 解析输出并回复用户
```

### 场景2：批量分析本地图片

```python
exec(f"python3 scripts/face_analyzer.py /path/to/image.jpg")
```

## 输出格式

脚本输出两部分内容：

1. **可读报告** - 面向用户的格式化文本分析
2. **JSON数据** - 结构化的完整分析数据（位于 `[JSON_OUTPUT_BEGIN]` 和 `[JSON_OUTPUT_END]` 标记之间）

## 技术规格

- **检测引擎**: MediaPipe Face Mesh (468个面部关键点)
- **评分算法**: 几何测量 + 统计学标准差
- **依赖**: Python 3.8+, OpenCV, MediaPipe, NumPy, Pillow

## 安装依赖

```bash
pip3 install opencv-python-headless mediapipe numpy Pillow
```

## 注意事项

- 照片需正面、清晰、光线均匀
- 避免遮挡（眼镜、口罩等影响精度）
- 分析结果仅供参考娱乐，非专业医学/美学鉴定
