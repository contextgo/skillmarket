#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
人脸照片专业分析系统 v2.0
适配 MediaPipe 0.10.x API
Author: 47
"""

import cv2
import numpy as np
from PIL import Image
import mediapipe as mp
import math
import sys
import json
from pathlib import Path

class FaceAnalyzer:
    """专业人脸分析器 - MediaPipe 0.10.x 版本"""
    
    def __init__(self):
        # MediaPipe 0.10.x 新 API
        from mediapipe.tasks.python.vision import FaceLandmarker
        from mediapipe.tasks.python.core.base_options import BaseOptions
        
        # 下载模型文件
        model_path = self._get_model_path()
        
        base_options = BaseOptions(model_asset_path=model_path)
        options = mp.tasks.vision.FaceLandmarkerOptions(
            base_options=base_options,
            running_mode=mp.tasks.vision.RunningMode.IMAGE,
            num_faces=1,
            min_face_detection_confidence=0.5,
            min_face_presence_confidence=0.5,
            min_tracking_confidence=0.5,
            output_face_blendshapes=False,
            output_facial_transformation_matrixes=False
        )
        self.landmarker = FaceLandmarker.create_from_options(options)
        
        # 黄金比例参考值
        self.GOLDEN_RATIO = 1.618
    
    def _get_model_path(self):
        """获取或下载模型文件"""
        model_path = Path("/root/.openclaw/workspace/face_landmarker.task")
        if model_path.exists():
            return str(model_path)
        
        # 下载模型
        import urllib.request
        url = "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task"
        print(f"正在下载模型文件...")
        urllib.request.urlretrieve(url, str(model_path))
        return str(model_path)
    
    def analyze_image(self, image_path: str) -> dict:
        """分析单张人脸照片"""
        
        # 读取图片
        image = cv2.imread(image_path)
        if image is None:
            raise ValueError(f"无法读取图片: {image_path}")
        
        # 转换为 MediaPipe Image 格式
        h, w = image.shape[:2]
        rgb_image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb_image)
        
        # 人脸检测
        result = self.landmarker.detect(mp_image)
        
        if not result.face_landmarks:
            raise ValueError("未检测到人脸")
        
        landmarks = result.face_landmarks[0]
        
        # 各项分析
        analysis = {
            "基本信息": self._get_basic_info(image, landmarks),
            "五官比例分析": self._analyze_proportions(landmarks, w, h),
            "面部对称性": self._analyze_symmetry(landmarks, w, h),
            "黄金比例评估": self._analyze_golden_ratio(landmarks, w, h),
            "肤质分析": self._analyze_skin_quality(image, landmarks),
            "综合评分": None
        }
        
        # 计算综合评分
        analysis["综合评分"] = self._calculate_overall_score(analysis)
        
        return analysis
    
    def _get_basic_info(self, image, landmarks) -> dict:
        """获取基础信息"""
        h, w = image.shape[:2]
        
        # 计算人脸边界框
        x_coords = [lm.x for lm in landmarks]
        y_coords = [lm.y for lm in landmarks]
        
        face_width = (max(x_coords) - min(x_coords)) * w
        face_height = (max(y_coords) - min(y_coords)) * h
        
        return {
            "图片尺寸": f"{w} x {h}",
            "检测到关键点": len(landmarks),
            "面部区域": f"宽 {face_width:.1f} x 高 {face_height:.1f} px",
            "面部比例": f"宽高比 {face_height/max(face_width, 1):.3f}"
        }
    
    def _analyze_proportions(self, landmarks, w, h) -> dict:
        """分析五官比例"""
        
        def get_point(idx):
            lm = landmarks[idx]
            return np.array([lm.x * w, lm.y * h])
        
        # 关键点索引 (MediaPipe Face Landmarker)
        # 额头: 10 (头顶), 额头宽: 105-334
        # 眼睛: 33(左眼内), 133(左眼外), 362(右眼内), 263(右眼外)
        # 鼻子: 1(鼻尖), 168(鼻梁), 6(鼻根)
        # 嘴巴: 13(上唇中), 14(下唇中), 78(左嘴角), 308(右嘴角)
        # 下巴: 152
        
        # 三庭测量
        hairline = get_point(10)
        glabella = get_point(6)
        nose_tip = get_point(1)
        chin = get_point(152)
        
        upper_face = np.linalg.norm(hairline - glabella)
        mid_face = np.linalg.norm(glabella - nose_tip)
        lower_face = np.linalg.norm(nose_tip - chin)
        total_face = upper_face + mid_face + lower_face
        
        # 五眼测量
        left_eye_outer = get_point(33)
        left_eye_inner = get_point(133)
        right_eye_inner = get_point(362)
        right_eye_outer = get_point(263)
        left_face_edge = get_point(127)
        right_face_edge = get_point(356)
        
        eye_distance = np.linalg.norm(left_eye_inner - right_eye_inner)
        left_eye_width = np.linalg.norm(left_eye_outer - left_eye_inner)
        right_eye_width = np.linalg.norm(right_eye_outer - right_eye_inner)
        face_width = np.linalg.norm(left_face_edge - right_face_edge)
        
        return {
            "三庭比例": {
                "上庭（发际线-眉心）": f"{upper_face/total_face*100:.1f}%",
                "中庭（眉心-鼻尖）": f"{mid_face/total_face*100:.1f}%",
                "下庭（鼻尖-下巴）": f"{lower_face/total_face*100:.1f}%",
                "均匀度评分": self._score_uniformity([upper_face, mid_face, lower_face])
            },
            "五眼分析": {
                "眼间距与脸宽比": f"{eye_distance/max(face_width, 1):.3f}",
                "左眼宽度": f"{left_eye_width:.1f}px",
                "右眼宽度": f"{right_eye_width:.1f}px",
                "双眼对称度": self._score_symmetry(left_eye_width, right_eye_width)
            }
        }
    
    def _analyze_symmetry(self, landmarks, w, h) -> dict:
        """分析面部对称性"""
        
        symmetric_pairs = [
            (33, 263),   # 左右眼内角
            (133, 362),  # 左右眼外角
            (78, 308),   # 左右嘴角
            (127, 356),  # 左右脸颊
            (61, 291),   # 嘴角
        ]
        
        # 计算面部中心线
        nose_bridge = np.array([landmarks[6].x * w, landmarks[6].y * h])
        chin = np.array([landmarks[152].x * w, landmarks[152].y * h])
        
        asymmetry_scores = []
        for left_idx, right_idx in symmetric_pairs:
            left_pt = np.array([landmarks[left_idx].x * w, landmarks[left_idx].y * h])
            right_pt = np.array([landmarks[right_idx].x * w, landmarks[right_idx].y * h])
            
            left_dist = self._point_to_line_distance(left_pt, nose_bridge, chin)
            right_dist = self._point_to_line_distance(right_pt, nose_bridge, chin)
            
            ratio = min(left_dist, right_dist) / max(left_dist, right_dist, 0.001)
            asymmetry_scores.append(ratio)
        
        avg_symmetry = np.mean(asymmetry_scores) * 100
        
        return {
            "对称性评分": f"{avg_symmetry:.1f}/100",
            "等级": self._get_symmetry_grade(avg_symmetry),
            "检测点对": len(symmetric_pairs)
        }
    
    def _analyze_golden_ratio(self, landmarks, w, h) -> dict:
        """分析面部黄金比例"""
        
        def get_point(idx):
            lm = landmarks[idx]
            return np.array([lm.x * w, lm.y * h])
        
        face_height = np.linalg.norm(get_point(10) - get_point(152))
        face_width = np.linalg.norm(get_point(127) - get_point(356))
        
        eyebrow_eye = np.linalg.norm(get_point(105) - get_point(33))
        eye_nose = np.linalg.norm(get_point(33) - get_point(1))
        nose_lip = np.linalg.norm(get_point(1) - get_point(13))
        lip_chin = np.linalg.norm(get_point(13) - get_point(152))
        
        ratios = [
            face_height / max(face_width, 1),
            eyebrow_eye / max(eye_nose, 1),
            eye_nose / max(nose_lip, 1),
            nose_lip / max(lip_chin, 1),
        ]
        
        golden_scores = []
        for ratio in ratios:
            score = max(0, 100 - abs(ratio - self.GOLDEN_RATIO) * 50)
            golden_scores.append(score)
        
        avg_golden_score = np.mean(golden_scores) if golden_scores else 0
        
        return {
            "黄金比例评分": f"{avg_golden_score:.1f}/100",
            "面部高宽比": f"{ratios[0]:.3f} (目标: {self.GOLDEN_RATIO:.3f})",
            "眉眼-眼鼻比": f"{ratios[1]:.3f}",
            "眼鼻-鼻唇比": f"{ratios[2]:.3f}",
            "鼻唇-唇颏比": f"{ratios[3]:.3f}",
            "等级": self._get_golden_grade(avg_golden_score)
        }
    
    def _analyze_skin_quality(self, image, landmarks) -> dict:
        """分析皮肤质量"""
        
        h, w = image.shape[:2]
        
        x_coords = [int(lm.x * w) for lm in landmarks]
        y_coords = [int(lm.y * h) for lm in landmarks]
        
        x1, x2 = max(0, min(x_coords)), min(w, max(x_coords))
        y1, y2 = max(0, min(y_coords)), min(h, max(y_coords))
        
        face_region = image[y1:y2, x1:x2]
        
        if face_region.size == 0:
            return {"皮肤评分": "无法分析", "说明": "面部区域提取失败"}
        
        gray = cv2.cvtColor(face_region, cv2.COLOR_BGR2GRAY)
        
        brightness_std = np.std(gray)
        brightness_score = max(0, 100 - brightness_std / 2)
        
        laplacian_var = cv2.Laplacian(gray, cv2.CV_64F).var()
        texture_score = min(100, laplacian_var / 10)
        
        skin_score = (brightness_score * 0.6 + texture_score * 0.4)
        
        return {
            "皮肤质量评分": f"{skin_score:.1f}/100",
            "亮度均匀度": f"{brightness_score:.1f}",
            "纹理细腻度": f"{texture_score:.1f}",
            "等级": self._get_skin_grade(skin_score)
        }
    
    def _calculate_overall_score(self, analysis: dict) -> dict:
        """计算综合评分"""
        
        scores = []
        
        try:
            symmetry_str = analysis["面部对称性"]["对称性评分"].split("/")[0]
            scores.append(float(symmetry_str))
        except:
            pass
        
        try:
            golden_str = analysis["黄金比例评估"]["黄金比例评分"].split("/")[0]
            scores.append(float(golden_str))
        except:
            pass
        
        try:
            skin_str = analysis["肤质分析"]["皮肤质量评分"].split("/")[0]
            scores.append(float(skin_str))
        except:
            pass
        
        try:
            uniform_str = analysis["五官比例分析"]["三庭比例"]["均匀度评分"].split("/")[0]
            scores.append(float(uniform_str))
        except:
            pass
        
        overall = np.mean(scores) if scores else 0
        
        return {
            "总分": f"{overall:.1f}/100",
            "等级": self._get_overall_grade(overall),
            "各维度平均分": f"{np.mean(scores):.1f}" if scores else "N/A"
        }
    
    def _point_to_line_distance(self, point, line_p1, line_p2):
        """计算点到直线的距离"""
        return abs(np.cross(line_p2 - line_p1, line_p1 - point)) / np.linalg.norm(line_p2 - line_p1)
    
    def _score_uniformity(self, values):
        """评分均匀度"""
        if not values or len(values) < 2:
            return "N/A"
        mean_val = np.mean(values)
        std_val = np.std(values)
        cv = std_val / mean_val if mean_val > 0 else 0
        score = max(0, 100 - cv * 100)
        return f"{score:.1f}/100"
    
    def _score_symmetry(self, left, right):
        """评分对称度"""
        if max(left, right) == 0:
            return "N/A"
        ratio = min(left, right) / max(left, right)
        return f"{ratio * 100:.1f}/100"
    
    def _get_symmetry_grade(self, score):
        if score >= 90: return "极佳 (A+)"
        if score >= 80: return "优秀 (A)"
        if score >= 70: return "良好 (B)"
        if score >= 60: return "一般 (C)"
        return "待改善"
    
    def _get_golden_grade(self, score):
        if score >= 85: return "接近完美"
        if score >= 70: return "优秀"
        if score >= 55: return "良好"
        if score >= 40: return "一般"
        return "普通"
    
    def _get_skin_grade(self, score):
        if score >= 85: return "极佳"
        if score >= 70: return "优秀"
        if score >= 55: return "良好"
        if score >= 40: return "一般"
        return "需注意"
    
    def _get_overall_grade(self, score):
        if score >= 90: return "惊艳级 ⭐⭐⭐⭐⭐"
        if score >= 80: return "优秀级 ⭐⭐⭐⭐"
        if score >= 70: return "良好级 ⭐⭐⭐"
        if score >= 60: return "普通级 ⭐⭐"
        return "入门级 ⭐"


def format_report(analysis: dict) -> str:
    """格式化分析报告"""
    
    lines = [
        "=" * 50,
        "          人脸照片专业分析报告",
        "=" * 50,
        ""
    ]
    
    lines.append("【基本信息】")
    for k, v in analysis["基本信息"].items():
        lines.append(f"  • {k}: {v}")
    lines.append("")
    
    lines.append("【综合评分】")
    overall = analysis["综合评分"]
    lines.append(f"  ★ 总分: {overall['总分']}")
    lines.append(f"  ★ 等级: {overall['等级']}")
    lines.append("")
    
    lines.append("【五官比例分析】")
    for section, data in analysis["五官比例分析"].items():
        lines.append(f"  ▶ {section}:")
        if isinstance(data, dict):
            for k, v in data.items():
                lines.append(f"      {k}: {v}")
        else:
            lines.append(f"      {data}")
    lines.append("")
    
    lines.append("【面部对称性分析】")
    for k, v in analysis["面部对称性"].items():
        lines.append(f"  • {k}: {v}")
    lines.append("")
    
    lines.append("【黄金比例评估】")
    for k, v in analysis["黄金比例评估"].items():
        lines.append(f"  • {k}: {v}")
    lines.append("")
    
    lines.append("【肤质分析】")
    for k, v in analysis["肤质分析"].items():
        lines.append(f"  • {k}: {v}")
    lines.append("")
    
    lines.append("=" * 50)
    lines.append("注: 本分析基于面部几何特征和图像处理算法")
    lines.append("仅供参考，不作为专业医学或美学鉴定")
    lines.append("=" * 50)
    
    return "\n".join(lines)


def main():
    if len(sys.argv) < 2:
        print("用法: python3 face_analyzer.py <图片路径>")
        sys.exit(1)
    
    image_path = sys.argv[1]
    
    try:
        analyzer = FaceAnalyzer()
        analysis = analyzer.analyze_image(image_path)
        report = format_report(analysis)
        print(report)
        
        print("\n\n[JSON_OUTPUT_BEGIN]")
        print(json.dumps(analysis, ensure_ascii=False, indent=2))
        print("[JSON_OUTPUT_END]")
        
    except Exception as e:
        print(f"分析失败: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
