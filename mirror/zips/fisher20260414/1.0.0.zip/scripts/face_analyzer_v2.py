#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
人脸照片专业分析系统 v2.0
Face Analysis System v2.0 - MediaPipe 0.10.x Compatible
Author: 47
"""

import cv2
import numpy as np
from PIL import Image
import mediapipe as mp
from mediapipe.tasks import python as mp_tasks
from mediapipe.tasks.python import vision
import math
import sys
import json
from pathlib import Path

class FaceAnalyzer:
    """专业人脸分析器 - 兼容 MediaPipe 0.10.x"""
    
    def __init__(self):
        # 下载模型文件路径
        model_path = self._get_model_path()
        
        # 创建 FaceLandmarker
        base_options = mp_tasks.BaseOptions(model_asset_path=model_path)
        options = vision.FaceLandmarkerOptions(
            base_options=base_options,
            num_faces=1,
            min_face_detection_confidence=0.5,
            min_face_presence_confidence=0.5,
            min_tracking_confidence=0.5,
            output_face_blendshapes=False,
        )
        self.detector = vision.FaceLandmarker.create_from_options(options)
        
        # 黄金比例参考值
        self.GOLDEN_RATIO = 1.618
        
    def _get_model_path(self):
        """获取或下载模型文件"""
        model_dir = Path.home() / ".mediapipe" / "models"
        model_dir.mkdir(parents=True, exist_ok=True)
        model_path = model_dir / "face_landmarker.task"
        
        if not model_path.exists():
            print(f"正在下载模型文件...")
            import urllib.request
            url = "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task"
            urllib.request.urlretrieve(url, model_path)
            print(f"模型已下载到: {model_path}")
        
        return str(model_path)
        
    def analyze_image(self, image_path: str) -> dict:
        """分析单张人脸照片"""
        
        # 读取图片
        image = cv2.imread(image_path)
        if image is None:
            raise ValueError(f"无法读取图片: {image_path}")
        
        # 转换为RGB
        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        h, w = image.shape[:2]
        
        # 创建 MediaPipe Image
        mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=image_rgb)
        
        # 检测人脸关键点
        detection_result = self.detector.detect(mp_image)
        
        if not detection_result.face_landmarks:
            raise ValueError("未检测到人脸，请提供清晰的正面人脸照片")
        
        # 获取关键点 (468个点)
        landmarks = detection_result.face_landmarks[0]
        
        # 分析各项指标
        proportions = self._analyze_proportions(landmarks, w, h)
        symmetry = self._analyze_symmetry(landmarks, w, h)
        golden_ratio = self._analyze_golden_ratio(landmarks, w, h)
        skin_quality = self._analyze_skin_quality(image, landmarks)
        
        # 综合评分
        overall_score = self._calculate_overall_score(proportions, symmetry, golden_ratio, skin_quality)
        
        return {
            "综合评分": overall_score,
            "星级": self._score_to_stars(overall_score),
            "三庭五眼": proportions,
            "面部对称性": symmetry,
            "黄金比例": golden_ratio,
            "肤质分析": skin_quality
        }
    
    def _get_point(self, landmarks, idx, w, h):
        """获取关键点坐标"""
        lm = landmarks[idx]
        return (int(lm.x * w), int(lm.y * h))
    
    def _analyze_proportions(self, landmarks, w, h):
        """分析三庭五眼比例"""
        # 关键面部点索引 (基于 MediaPipe Face Mesh 468点模型)
        # 额头: 10 (眉心上方), 眉毛: 105, 334, 鼻子: 1, 鼻尖: 4
        # 上唇: 0, 下巴: 152
        # 左眼外/内: 33, 133, 右眼外/内: 362, 263
        # 左脸边缘: 127, 右脸边缘: 356
        
        top_head = self._get_point(landmarks, 10, w, h)
        glabella = self._get_point(landmarks, 168, w, h)  # 眉心
        nose_tip = self._get_point(landmarks, 4, w, h)
        chin = self._get_point(landmarks, 152, w, h)
        upper_lip = self._get_point(landmarks, 0, w, h)
        
        left_eye_outer = self._get_point(landmarks, 33, w, h)
        left_eye_inner = self._get_point(landmarks, 133, w, h)
        right_eye_inner = self._get_point(landmarks, 362, w, h)
        right_eye_outer = self._get_point(landmarks, 263, w, h)
        
        # 三庭计算
        face_height = self._distance(top_head, chin)
        upper_face = self._distance(top_head, glabella)
        middle_face = self._distance(glabella, nose_tip)
        lower_face = self._distance(nose_tip, chin)
        
        ideal_third = face_height / 3
        upper_score = max(0, 100 - abs(upper_face - ideal_third) / ideal_third * 100)
        middle_score = max(0, 100 - abs(middle_face - ideal_third) / ideal_third * 100)
        lower_score = max(0, 100 - abs(lower_face - ideal_third) / ideal_third * 100)
        
        # 五眼计算
        face_width = self._distance(
            self._get_point(landmarks, 127, w, h),
            self._get_point(landmarks, 356, w, h)
        )
        left_eye_width = self._distance(left_eye_outer, left_eye_inner)
        right_eye_width = self._distance(right_eye_inner, right_eye_outer)
        eye_distance = self._distance(left_eye_inner, right_eye_inner)
        
        ideal_eye_unit = face_width / 5
        left_eye_score = max(0, 100 - abs(left_eye_width - ideal_eye_unit) / ideal_eye_unit * 100)
        right_eye_score = max(0, 100 - abs(right_eye_width - ideal_eye_unit) / ideal_eye_unit * 100)
        eye_dist_score = max(0, 100 - abs(eye_distance - ideal_eye_unit) / ideal_eye_unit * 100)
        
        # 双眼对称性
        eye_symmetry = 100 - abs(left_eye_width - right_eye_width) / max(left_eye_width, right_eye_width) * 100
        
        return {
            "上庭均匀度": round(upper_score, 1),
            "中庭均匀度": round(middle_score, 1),
            "下庭均匀度": round(round(lower_score, 1)),
            "三庭综合": round((upper_score + middle_score + lower_score) / 3, 1),
            "左眼宽度": round(left_eye_score, 1),
            "右眼宽度": round(right_eye_score, 1),
            "眼间距": round(eye_dist_score, 1),
            "双眼对称": round(eye_symmetry, 1),
            "五眼综合": round((left_eye_score + right_eye_score + eye_dist_score + eye_symmetry) / 4, 1)
        }
    
    def _analyze_symmetry(self, landmarks, w, h):
        """分析面部对称性"""
        # 选取左右对称的关键点对
        symmetric_pairs = [
            (33, 263),   # 眼外角
            (133, 362),  # 眼内角
            (159, 386),  # 上眼睑
            (145, 374),  # 下眼睑
            (61, 291),   # 嘴角
            (185, 409),  # 眉尾
            (105, 334),  # 眉头
        ]
        
        center_x = w // 2
        symmetry_scores = []
        
        for left_idx, right_idx in symmetric_pairs:
            left_pt = self._get_point(landmarks, left_idx, w, h)
            right_pt = self._get_point(landmarks, right_idx, w, h)
            
            # 计算到中心线的距离
            left_dist = abs(left_pt[0] - center_x)
            right_dist = abs(right_pt[0] - center_x)
            
            # 对称度
            if max(left_dist, right_dist) > 0:
                pair_symmetry = 100 - abs(left_dist - right_dist) / max(left_dist, right_dist) * 100
                symmetry_scores.append(pair_symmetry)
        
        overall_symmetry = np.mean(symmetry_scores) if symmetry_scores else 80
        
        return {
            "对称度评分": round(overall_symmetry, 1),
            "评级": self._get_symmetry_rating(overall_symmetry)
        }
    
    def _analyze_golden_ratio(self, landmarks, w, h):
        """分析黄金比例契合度"""
        # 选取关键面部比例点
        top = self._get_point(landmarks, 10, w, h)
        brow = self._get_point(landmarks, 168, w, h)
        nose_tip = self._get_point(landmarks, 4, w, h)
        chin = self._get_point(landmarks, 152, w, h)
        left_face = self._get_point(landmarks, 127, w, h)
        right_face = self._get_point(landmarks, 356, w, h)
        
        # 计算多个黄金比例
        ratios = []
        
        # 脸长/脸宽
        face_height = self._distance(top, chin)
        face_width = self._distance(left_face, right_face)
        if face_width > 0:
            hw_ratio = face_height / face_width
            ratios.append(self._golden_ratio_score(hw_ratio))
        
        # 上庭:中庭
        upper = self._distance(top, brow)
        middle = self._distance(brow, nose_tip)
        if middle > 0:
            ratios.append(self._golden_ratio_score(upper / middle))
        
        # 中庭:下庭
        lower = self._distance(nose_tip, chin)
        if lower > 0:
            ratios.append(self._golden_ratio_score(middle / lower))
        
        avg_score = np.mean(ratios) if ratios else 70
        
        return {
            "黄金比例契合度": round(avg_score, 1),
            "评级": self._get_golden_rating(avg_score)
        }
    
    def _analyze_skin_quality(self, image, landmarks):
        """分析皮肤质量"""
        h, w = image.shape[:2]
        
        # 获取脸颊区域
        left_cheek = self._get_point(landmarks, 205, w, h)  # 左脸颊
        right_cheek = self._get_point(landmarks, 425, w, h)  # 右脸颊
        forehead = self._get_point(landmarks, 151, w, h)  # 额头
        
        # 提取区域进行分析
        regions = [left_cheek, right_cheek, forehead]
        brightness_scores = []
        smoothness_scores = []
        
        for x, y in regions:
            x1, y1 = max(0, x-20), max(0, y-20)
            x2, y2 = min(w, x+20), min(h, y+20)
            
            if x2 > x1 and y2 > y1:
                roi = image[y1:y2, x1:x2]
                gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
                
                # 亮度均匀度
                brightness = np.mean(gray)
                brightness_std = np.std(gray)
                brightness_score = max(0, 100 - brightness_std * 2)
                brightness_scores.append(brightness_score)
                
                # 纹理细腻度 (使用拉普拉斯算子)
                laplacian_var = cv2.Laplacian(gray, cv2.CV_64F).var()
                smoothness = min(100, 100 - laplacian_var / 100)
                smoothness_scores.append(smoothness)
        
        avg_brightness = np.mean(brightness_scores) if brightness_scores else 70
        avg_smoothness = np.mean(smoothness_scores) if smoothness_scores else 70
        
        return {
            "亮度均匀度": round(avg_brightness, 1),
            "纹理细腻度": round(avg_smoothness, 1),
            "皮肤综合": round((avg_brightness + avg_smoothness) / 2, 1),
            "评级": self._get_skin_rating((avg_brightness + avg_smoothness) / 2)
        }
    
    def _calculate_overall_score(self, proportions, symmetry, golden, skin):
        """计算综合评分"""
        weights = {
            "proportions": 0.25,
            "symmetry": 0.25,
            "golden": 0.25,
            "skin": 0.25
        }
        
        score = (
            proportions.get("三庭综合", 70) * weights["proportions"] +
            symmetry.get("对称度评分", 70) * weights["symmetry"] +
            golden.get("黄金比例契合度", 70) * weights["golden"] +
            skin.get("皮肤综合", 70) * weights["skin"]
        )
        
        return round(score, 1)
    
    def _distance(self, p1, p2):
        """计算两点间距离"""
        return math.sqrt((p1[0] - p2[0])**2 + (p1[1] - p2[1])**2)
    
    def _golden_ratio_score(self, ratio):
        """计算与黄金比例的接近度得分"""
        diff = abs(ratio - self.GOLDEN_RATIO)
        return max(0, 100 - diff * 50)
    
    def _score_to_stars(self, score):
        """分数转星级"""
        if score >= 95:
            return "⭐⭐⭐⭐⭐ (神级)"
        elif score >= 85:
            return "⭐⭐⭐⭐⭐ (优秀)"
        elif score >= 75:
            return "⭐⭐⭐⭐☆ (良好)"
        elif score >= 65:
            return "⭐⭐⭐☆☆ (中等)"
        elif score >= 55:
            return "⭐⭐☆☆☆ (一般)"
        else:
            return "⭐☆☆☆☆ (待提升)"
    
    def _get_symmetry_rating(self, score):
        """获取对称性评级"""
        if score >= 90:
            return "极对称"
        elif score >= 80:
            return "很对称"
        elif score >= 70:
            return "较对称"
        else:
            return "一般"
    
    def _get_golden_rating(self, score):
        """获取黄金比例评级"""
        if score >= 85:
            return "高度契合"
        elif score >= 70:
            return "较好契合"
        elif score >= 55:
            return "基本契合"
        else:
            return "差异较大"
    
    def _get_skin_rating(self, score):
        """获取皮肤评级"""
        if score >= 85:
            return "极好"
        elif score >= 70:
            return "良好"
        elif score >= 55:
            return "一般"
        else:
            return "需改善"


def main():
    if len(sys.argv) < 2:
        print("用法: python face_analyzer_v2.py <图片路径>")
        sys.exit(1)
    
    image_path = sys.argv[1]
    
    try:
        analyzer = FaceAnalyzer()
        result = analyzer.analyze_image(image_path)
        
        print(json.dumps(result, ensure_ascii=False, indent=2))
        
    except Exception as e:
        print(json.dumps({"error": str(e)}, ensure_ascii=False))
        sys.exit(1)


if __name__ == "__main__":
    main()
