#!/usr/bin/env python3
"""skill-creator-king v3.0 质量评分审计脚本

10维度评分 + 缓存 + 预检：
- 7个自动维度 + 3个手动维度（预检标记，不参与自动评分）
- 缓存：skill_path + version + mtime + skill-creator-king-version
- 两态：script_only（自动分）/ full（AI裁定后）
- --no-cache 跳过读写 / --save-cache --manual-scores 保存AI裁定
- --clear-cache 清理缓存

用法：python3 scripts/quality-audit.py <skill> [--channel auto|lightweight|full] [--no-cache] [--json]
      python3 scripts/quality-audit.py <skill> --save-cache --manual-scores dim1:N,dim2:N,dim3:N
      python3 scripts/quality-audit.py --clear-cache [<skill>]
"""

import hashlib
import json
import os
import re
import sys
import subprocess
import time
from datetime import datetime, timedelta
from pathlib import Path

SCRIPT_DIR = Path(__file__).parent
SKILL_COACH_DIR = SCRIPT_DIR.parent
CACHE_DIR = SKILL_COACH_DIR / "data" / "cache"
SKILL_COACH_VERSION = "3.0.0"

AUDIT_DIMENSIONS = [
    {"id": "frontmatter_safety", "weight": 15, "label": "Frontmatter 安全", "auto": True},
    {"id": "token_budget", "weight": 15, "label": "Token 预算合规", "auto": True},
    {"id": "file_completeness", "weight": 10, "label": "文件结构完整性", "auto": True},
    {"id": "version_consistency", "weight": 10, "label": "版本一致性", "auto": True},
    {"id": "trigger_coverage", "weight": 10, "label": "触发词覆盖", "auto": False,
     "prechecks": ["has_3plus_triggers", "has_disambiguation"]},
    {"id": "script_llm_boundary", "weight": 10, "label": "脚本-LLM 边界", "auto": False,
     "prechecks": ["has_fallback_config", "outputs_json_success"]},
    {"id": "l2_organization", "weight": 10, "label": "L2 组织合理性", "auto": False,
     "prechecks": ["files_within_limit", "no_oversized_files"]},
    {"id": "anti_patterns", "weight": 10, "label": "反模式扫描", "auto": True},
    {"id": "template_compliance", "weight": 5, "label": "模板合规", "auto": True},
    {"id": "data_sources", "weight": 5, "label": "数据源声明", "auto": True},
]

GRADES = [
    (95, "卓越", "架构扎实，可作为参考模板"),
    (85, "良好", "质量过硬，达到生产标准"),
    (70, "需打磨", "基础合格，有明确改进空间"),
    (0, "需重构", "存在关键缺陷，建议针对性修复"),
]

LIGHTWEIGHT_SKIP = {"script_llm_boundary"}

# Cache settings
CACHE_MAX_FILES = 50
CACHE_TTL_DAYS = 30


def get_cache_key(skill_path: Path, version: str) -> str:
    """生成缓存键"""
    version = version or "0.0.0"
    name = skill_path.name
    mtime = get_all_mtime(skill_path)
    short_hash = hashlib.md5(f"{skill_path}{version}{mtime}{SKILL_COACH_VERSION}".encode()).hexdigest()[:6]
    return f"{name}_v{version}_{short_hash}"


def get_all_mtime(skill_path: Path) -> float:
    """获取 skill 目录下所有非隐藏文件的 max mtime"""
    max_mt = 0.0
    for root, dirs, files in os.walk(skill_path):
        dirs[:] = [d for d in dirs if not d.startswith('.') and d != '__pycache__' and d != 'cache']
        for f in files:
            if f.startswith('.'):
                continue
            fp = Path(root) / f
            try:
                mt = fp.stat().st_mtime
                if mt > max_mt:
                    max_mt = mt
            except OSError:
                pass
    return max_mt


def cache_path(key: str) -> Path:
    """缓存文件路径"""
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    return CACHE_DIR / f"{key}.json"


def read_cache(key: str) -> dict | None:
    """读取缓存，过期返回 None"""
    cp = cache_path(key)
    if not cp.exists():
        return None
    try:
        with open(cp) as f:
            data = json.load(f)
        age = time.time() - data.get("cached_at", 0)
        if age > CACHE_TTL_DAYS * 86400:
            cp.unlink()
            return None
        return data
    except Exception:
        return None


def write_cache(key: str, data: dict, state: str = "script_only"):
    """写入缓存，保护 full 态不被 script_only 覆盖"""
    cp = cache_path(key)
    
    # Protect full state from being overwritten by script_only
    if state == "script_only":
        existing = read_cache(key)
        if existing and existing.get("state") == "full":
            return  # Don't overwrite full with script_only
    
    data["state"] = state
    data["cached_at"] = time.time()
    data["sck_version"] = SKILL_COACH_VERSION
    
    with open(cp, 'w') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    
    # Clean old cache files
    clean_cache()


def clean_cache():
    """清理过期和过多缓存文件"""
    cache_files = sorted(CACHE_DIR.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
    
    # Remove expired
    cutoff = time.time() - CACHE_TTL_DAYS * 86400
    for cf in cache_files:
        if cf.stat().st_mtime < cutoff:
            cf.unlink()
    
    # Keep only MAX_FILES newest
    cache_files = sorted(CACHE_DIR.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
    for cf in cache_files[CACHE_MAX_FILES:]:
        cf.unlink()


def clear_all_cache():
    """清空所有缓存"""
    if CACHE_DIR.exists():
        for cf in CACHE_DIR.glob("*.json"):
            cf.unlink()


def run_validate(skill_dir: Path) -> dict:
    vp = SCRIPT_DIR / "validate.py"
    try:
        result = subprocess.run(
            ["python3", str(vp), str(skill_dir), "--json"],
            capture_output=True, text=True, timeout=30
        )
        if result.returncode == 0:
            return json.loads(result.stdout)
    except Exception:
        pass
    return {"success": False, "error": "validate.py 执行失败"}


def run_estimate_tokens(skill_dir: Path) -> dict:
    ep = SCRIPT_DIR / "estimate-tokens.py"
    try:
        result = subprocess.run(
            ["python3", str(ep), str(skill_dir)],
            capture_output=True, text=True, timeout=30
        )
        output = result.stdout
        l0 = int(re.search(r'L0[^:]*:\s*([\d,]+)', output).group(1).replace(',', '')) if 'L0' in output else 0
        l1 = int(re.search(r'L1[^:]*:\s*([\d,]+)', output).group(1).replace(',', '')) if 'L1' in output else 0
        l2 = int(re.search(r'L2[^:]*:\s*([\d,]+)', output).group(1).replace(',', '')) if 'L2' in output else 0
        total = int(re.search(r'总计:\s*([\d,]+)', output).group(1).replace(',', '')) if '总计' in output else 0
        return {"L0": l0, "L1": l1, "L2": l2, "total": total}
    except Exception:
        return {"L0": 0, "L1": 0, "L2": 0, "total": 0}


def read_token_budget(skill_dir: Path) -> dict:
    skill_md = skill_dir / "SKILL.md"
    if not skill_md.exists():
        return {"L0": 100, "L1": 800, "L2": 3500, "hard": 5000}
    with open(skill_md) as f:
        content = f.read()
    fm_end = content.find('---', 3)
    fm_str = content[3:fm_end].strip() if fm_end > 0 else ''
    budgets = {"L0": 100, "L1": 800, "L2": 3500, "hard": 5000}
    for key, pattern in [("L0", r'L0_trigger:\s*(\d+)'), ("L1", r'L1_core:\s*(\d+)'),
                          ("L2", r'L2_deep:\s*(\d+)'), ("hard", r'hard_cap:\s*(\d+)')]:
        m = re.search(pattern, fm_str)
        if m:
            budgets[key] = int(m.group(1))
    return budgets


def run_prechecks(skill_dir: Path, validate_result: dict, token_result: dict) -> dict:
    """3个手动维度的预检标记"""
    prechecks = {}
    
    # Trigger coverage prechecks
    skill_md = skill_dir / "SKILL.md"
    trigger_count = 0
    has_disambig = False
    if skill_md.exists():
        with open(skill_md) as f:
            c = f.read()
        fm_end = c.find('---', 3)
        if fm_end > 0:
            fm = c[3:fm_end]
            # Count only triggers list items (after 'triggers:' line)
            trigger_section = fm.split('triggers:')[1].split('\n' + [k for k in ['token_budget', 'scenes', 'allowed', 'disable', 'template', 'L0'] if k in fm][0])[0] if 'triggers:' in fm and any(k in fm for k in ['token_budget', 'scenes', 'allowed', 'disable', 'template', 'L0']) else ''
            trigger_count = trigger_section.count('\n  - ') + trigger_section.count('\n- ') if trigger_section else fm.count('\n  - ') + fm.count('\n- ')
            has_disambig = '消歧' in fm or 'disambig' in fm.lower()
        body = c[fm_end+3:] if fm_end > 0 else c
        has_disambig = has_disambig or '消歧' in body or '优先级' in body
    
    prechecks["trigger_coverage"] = {
        "has_3plus_triggers": trigger_count >= 3,
        "has_disambiguation": has_disambig,
    }
    
    # Script-LLM boundary prechecks
    scripts_dir = skill_dir / "scripts"
    has_fallback = False
    outputs_json = False
    if scripts_dir.exists():
        for sf in scripts_dir.glob("*.py"):
            try:
                with open(sf) as f:
                    sc = f.read()
                if '_fallback_config' in sc or 'fallback' in sc.lower():
                    has_fallback = True
                if '"success"' in sc or "'success'" in sc:
                    outputs_json = True
            except Exception:
                pass
    
    prechecks["script_llm_boundary"] = {
        "has_fallback_config": has_fallback,
        "outputs_json_success": outputs_json,
    }
    
    # L2 organization prechecks
    refs_dir = skill_dir / "references"
    data_dir = skill_dir / "data"
    file_count = 0
    oversized = False
    for d in [refs_dir, data_dir]:
        if not d.exists():
            continue
        for root, dirs, files in os.walk(d):
            dirs[:] = [dr for dr in dirs if not dr.startswith('.')]
            for fn in files:
                if fn.endswith(('.md', '.yaml', '.yml')):
                    file_count += 1
                    try:
                        if Path(root, fn).stat().st_size > 10000:
                            oversized = True
                    except OSError:
                        pass
    
    prechecks["l2_organization"] = {
        "files_within_limit": file_count <= 20,
        "no_oversized_files": not oversized,
    }
    
    return prechecks


def audit(skill_dir: str, channel: str = "auto", no_cache: bool = False,
          manual_scores: dict = None) -> dict:
    """主审计函数"""
    skill_path = Path(skill_dir).expanduser().resolve()
    
    if not skill_path.exists():
        return {"success": False, "error": f"目录不存在: {skill_path}"}

    # Auto-detect channel
    has_spec = (skill_path / "SPEC.md").exists()
    has_scripts = bool(list((skill_path / "scripts").glob("*.py"))) if (skill_path / "scripts").exists() else False
    if channel == "auto":
        channel = "full" if (has_spec or has_scripts) else "lightweight"

    # Read version for cache key (read once, use consistently)
    version = "0.0.0"
    skill_md = skill_path / "SKILL.md"
    if skill_md.exists():
        with open(skill_md) as f:
            content = f.read()
        fm_end = content.find('---', 3)
        if fm_end > 0:
            m = re.search(r'version:\s*"([^"]+)"', content[:fm_end])
            if m:
                version = m.group(1)
    
    # Cache key uses SKILL.md version (read above), not validate_result version
    cache_key = get_cache_key(skill_path, version)

    # Try cache
    if not no_cache:
        cached = read_cache(cache_key)
        if cached:
            cached["_cache_hit"] = True
            cached["_cache_age"] = time.time() - cached.get("cached_at", time.time())
            return cached

    # Run auto checks (validate runs without --strict to avoid pyyaml dependency)
    validate_result = run_validate(skill_path)
    token_result = run_estimate_tokens(skill_path)
    budget = read_token_budget(skill_path)
    prechecks = run_prechecks(skill_path, validate_result, token_result)

    # Score each dimension
    dimensions = []
    total_score = 0
    total_weight = 0

    for dim in AUDIT_DIMENSIONS:
        did = dim["id"]
        
        # Skip lightweight dimensions
        if channel == "lightweight" and did in LIGHTWEIGHT_SKIP:
            dimensions.append({
                "id": did, "label": dim["label"], "weight": dim["weight"],
                "score": dim["weight"], "max": dim["weight"], "status": "skipped",
                "note": "轻量通道不评此维度"
            })
            continue

        score = dim["weight"]
        status = "pass"

        if did == "frontmatter_safety" and validate_result.get("success"):
            issues = validate_result.get("issues", [])
            critical = sum(1 for i in issues if i["severity"] == "critical")
            high = sum(1 for i in issues if i["severity"] == "high")
            if critical > 0:
                score = max(0, dim["weight"] - critical * 5 - high * 3)
                status = "fail"
            elif high > 0:
                score = max(0, dim["weight"] - high * 3)
                status = "warn"

        elif did == "token_budget" and token_result:
            checks = [
                token_result.get("L0", 0) <= budget["L0"],
                token_result.get("L1", 0) <= budget["L1"],
                token_result.get("L2", 0) <= budget["L2"],
                token_result.get("total", 0) <= budget["hard"],
            ]
            all_ok = all(checks)
            score = dim["weight"] if all_ok else max(0, dim["weight"] - 5 * sum(1 for c in checks if not c))
            status = "pass" if all_ok else "warn"

        elif did == "file_completeness":
            basics = [(skill_path / "SKILL.md").exists(), (skill_path / "README.md").exists(),
                       (skill_path / "CHANGELOG.md").exists()]
            score = dim["weight"] if all(basics) else max(0, dim["weight"] - 3 * sum(1 for b in basics if not b))
            status = "pass" if all(basics) else "warn"

        elif did == "version_consistency" and validate_result.get("success"):
            ver_issues = [i for i in validate_result.get("issues", []) if i["id"] == "version_mismatch"]
            score = dim["weight"] if not ver_issues else max(0, dim["weight"] - len(ver_issues) * 3)
            status = "pass" if not ver_issues else "warn"

        elif did == "anti_patterns" and validate_result.get("success"):
            critical = sum(1 for i in validate_result.get("issues", []) if i["severity"] == "critical")
            high = sum(1 for i in validate_result.get("issues", []) if i["severity"] == "high")
            score = dim["weight"] if critical == 0 and high <= 2 else max(0, dim["weight"] - critical * 5 - max(0, high - 2) * 2)
            status = "pass" if critical == 0 else "fail"

        elif did == "template_compliance":
            try:
                with open(skill_path / "SKILL.md") as f:
                    c = f.read()
                fm_end = c.find('---', 3)
                has_template = fm_end > 0 and 'template:' in c[3:fm_end]
                score = dim["weight"] if has_template else dim["weight"] // 2
                status = "pass" if has_template else "warn"
            except Exception:
                score = 0
                status = "fail"

        elif did == "data_sources":
            score = dim["weight"]
            status = "pass"

        elif not dim["auto"]:
            # Manual dimensions: auto-score as full, mark manual, attach prechecks
            status = "manual"
            score = dim["weight"]

        dimensions.append({
            "id": did, "label": dim["label"], "weight": dim["weight"],
            "score": max(0, min(dim["weight"], score)),
            "max": dim["weight"], "status": status,
            "precheck": prechecks.get(did) if not dim["auto"] else None,
            "note": "" if dim["auto"] else "待 AI 裁定"
        })
        total_score += max(0, min(dim["weight"], score))
        total_weight += dim["weight"]

    # Apply manual scores if provided
    if manual_scores:
        missing = []
        for dim in dimensions:
            if dim["status"] == "manual" and dim["id"] in manual_scores:
                new_score = min(dim["weight"], max(0, manual_scores[dim["id"]]))
                total_score = total_score - dim["score"] + new_score
                dim["score"] = new_score
                dim["note"] = "AI 已裁定"
            elif dim["status"] == "manual":
                missing.append(dim["id"])
        
        if missing:
            return {"success": False, "error": f"需要 {len(missing)} 个维度分数，当前缺少: {', '.join(missing)}。必须传齐 3 个维度。"}

    if channel == "lightweight":
        total_weight = 85

    percentage = (total_score / total_weight * 100) if total_weight > 0 else 0
    grade = "需重构"
    grade_meaning = ""
    for threshold, label, meaning in GRADES:
        if percentage >= threshold:
            grade = label
            grade_meaning = meaning
            break

    manual_dims = [d for d in dimensions if d["status"] == "manual"]
    
    result = {
        "success": True,
        "skill": str(skill_path),
        "version": version,
        "channel": channel,
        "score": round(percentage),
        "total_score": round(total_score),
        "total_weight": total_weight,
        "grade": grade,
        "grade_meaning": grade_meaning,
        "dimensions": dimensions,
        "manual_pending": len(manual_dims),
        "manual_dimensions": [d["label"] for d in manual_dims],
        "prechecks": prechecks,
        "token_actual": token_result,
        "token_budget": budget,
        "validate_issues": len(validate_result.get("issues", [])) if validate_result.get("success") else -1,
        "_cache_hit": False,
        "_cache_age": 0,
    }

    # Save cache (unless --no-cache)
    if not no_cache:
        state = "full" if manual_scores else "script_only"
        write_cache(cache_key, {k: v for k, v in result.items() if not k.startswith('_')}, state)

    return result


def format_report(result: dict) -> str:
    if not result.get("success"):
        return f"❌ 审计失败: {result.get('error')}"

    lines = [
        f"📊 质量审计 — {Path(result['skill']).name} v{result['version']}",
    ]
    
    if result.get("_cache_hit"):
        age_min = int(result.get("_cache_age", 0) / 60)
        lines.append(f"📦 缓存命中（{age_min} 分钟前）")
    
    lines.extend([
        f"",
        f"综合评分：{result['score']}/100  {result['grade']}",
        f"",
        f"| # | 维度 | 权重 | 得分 | 状态 |",
        f"|---|------|:---:|:---:|:---:|",
    ])
    
    for i, d in enumerate(result["dimensions"], 1):
        status_icon = {"pass": "✅", "warn": "⚠️", "fail": "🔴", "manual": "🤖", "skipped": "—"}.get(d["status"], "?")
        note = f"  {d['note']}" if d.get('note') else ""
        lines.append(f"| {i} | {d['label']} | {d['weight']} | {d['score']}/{d['max']} | {status_icon}{note} |")

    lines.extend([
        f"",
        f"评级：{result['grade']} — {result['grade_meaning']}",
    ])

    if result.get("manual_pending", 0) > 0:
        lines.extend([
            f"",
            f"🤖 {result['manual_pending']} 个维度待 AI 裁定：{', '.join(result['manual_dimensions'])}",
        ])
        lines.append(f"   预检信息：{json.dumps(result.get('prechecks', {}), ensure_ascii=False)}")
    
    if result.get("channel") == "lightweight":
        lines.extend(["", "💡 轻量通道 — 未评 SPEC/DESIGN/PHILOSOPHY/脚本维度"])

    if result.get("score", 100) < 70:
        lines.extend([
            "", "⚠️ 综合评分偏低。建议针对性修复后再投入使用——「修了再用」比「先用再修」更不容易半途搁置。"
        ])

    return '\n'.join(lines)


def main():
    # Handle --clear-cache
    if "--clear-cache" in sys.argv:
        clear_all_cache()
        print("🗑️  缓存已清空")
        return

    if len(sys.argv) < 2:
        print("用法: python3 scripts/quality-audit.py <skill> [--channel auto|lightweight|full] [--no-cache] [--json]")
        print("      python3 scripts/quality-audit.py <skill> --save-cache --manual-scores dim1:N,dim2:N,dim3:N")
        print("      python3 scripts/quality-audit.py --clear-cache")
        sys.exit(1)
    
    skill_dir = sys.argv[1]
    channel = "auto"
    json_output = "--json" in sys.argv
    no_cache = "--no-cache" in sys.argv
    save_cache = "--save-cache" in sys.argv
    manual_scores = None
    
    for i, arg in enumerate(sys.argv):
        if arg == "--channel" and i + 1 < len(sys.argv):
            channel = sys.argv[i + 1]
        if arg == "--manual-scores" and i + 1 < len(sys.argv):
            raw = sys.argv[i + 1]
            manual_scores = {}
            for pair in raw.split(","):
                k, v = pair.split(":")
                manual_scores[k.strip()] = int(v.strip())
    
    result = audit(skill_dir, channel, no_cache, manual_scores)
    
    if json_output:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(format_report(result))


if __name__ == '__main__':
    main()
