#!/usr/bin/env python3
"""Token 估算脚本

粗略估算 Token 数：
- 中文字符 × 0.3
- 英文字符 × 0.25
- 误差范围 ±15%

用法：python3 scripts/estimate-tokens.py <文件或目录> [--detail]
"""

import os
import sys
from pathlib import Path


def count_chars(text: str) -> dict:
    """统计中英文字符数"""
    chinese = sum(1 for c in text if '\u4e00' <= c <= '\u9fff')
    english = sum(1 for c in text if c.isascii() and c.isalpha())
    other = max(0, len(text) - chinese - english)
    return {"chinese": chinese, "english": english, "other": other, "total": len(text)}


def estimate_tokens(text: str, chinese_ratio=0.3, english_ratio=0.25) -> int:
    """估算 Token 数"""
    counts = count_chars(text)
    tokens = int(counts["chinese"] * chinese_ratio + counts["english"] * english_ratio + counts["other"] * 0.1)
    return tokens


def analyze_file(filepath: Path, chinese_ratio=0.3, english_ratio=0.25) -> dict:
    """分析单个文件"""
    with open(filepath, 'r') as f:
        content = f.read()
    
    chars = count_chars(content)
    tokens = estimate_tokens(content, chinese_ratio, english_ratio)
    
    return {
        "file": str(filepath),
        "filename": filepath.name,
        "chars": chars["total"],
        "tokens": tokens,
        "tokens_lower": int(tokens * 0.85),
        "tokens_upper": int(tokens * 1.15),
    }


def analyze_directory(dirpath: Path, chinese_ratio=0.3, english_ratio=0.25, exclude=None) -> list:
    """分析目录下所有 .md 文件"""
    if exclude is None:
        exclude = {'.git', '__pycache__', 'tests', '.gitkeep'}
    
    results = []
    
    for root, dirs, files in os.walk(dirpath):
        dirs[:] = [d for d in dirs if d not in exclude]
        for f in sorted(files):
            if f.endswith('.md') or f.endswith('.yaml') or f.endswith('.py'):
                filepath = Path(root) / f
                results.append(analyze_file(filepath, chinese_ratio, english_ratio))
    
    return results


def categorize_l0_l1_l2(results: list, skill_dir: Path) -> dict:
    """按 L0/L1/L2 分类"""
    l0 = 0  # frontmatter
    l1 = 0  # SKILL.md body
    l2 = 0  # references + data
    
    for r in results:
        rel_path = Path(r['file']).relative_to(skill_dir) if str(skill_dir) in r['file'] else r['file']
        rel_str = str(rel_path)
        
        if r['filename'] == 'SKILL.md':
            # Rough estimate: frontmatter ~15%, body ~85%
            l0 = int(r['tokens'] * 0.15)
            l1 = r['tokens'] - l0
        elif 'references/' in rel_str or 'data/' in rel_str:
            l2 += r['tokens']
    
    return {"L0": l0, "L1": l1, "L2": l2, "total": l0 + l1 + l2}


def main():
    if len(sys.argv) < 2:
        print("用法: python3 scripts/estimate-tokens.py <文件或目录> [--detail]")
        sys.exit(1)
    
    target = Path(sys.argv[1]).expanduser().resolve()
    detail = '--detail' in sys.argv
    
    if not target.exists():
        print(f"❌ 路径不存在: {target}")
        sys.exit(1)
    
    if target.is_file():
        result = analyze_file(target)
        print(f"文件: {result['filename']}")
        print(f"字符: {result['chars']:,}")
        print(f"Token: {result['tokens']:,} (~{result['tokens_lower']:,} - {result['tokens_upper']:,})")
    else:
        results = analyze_directory(target)
        categories = categorize_l0_l1_l2(results, target)
        
        print(f"📊 Token 估算: {target.name}")
        print(f"")
        print(f"L0 (frontmatter): {categories['L0']:,}")
        print(f"L1 (SKILL.md body): {categories['L1']:,}")
        print(f"L2 (references+data): {categories['L2']:,}")
        print(f"总计: {categories['total']:,}")
        print(f"")
        
        if detail:
            print("--- 文件明细 ---")
            total = 0
            for r in results:
                rel = Path(r['file']).relative_to(target) if str(target) in r['file'] else r['filename']
                print(f"  {rel}: {r['tokens']:,} tokens ({r['chars']:,} chars)")
                total += r['tokens']
            print(f"  ---")
            print(f"  合计: {total:,} tokens")


if __name__ == '__main__':
    main()
