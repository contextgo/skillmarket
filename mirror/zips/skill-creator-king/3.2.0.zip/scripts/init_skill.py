#!/usr/bin/env python3
"""skill-creator-king 脚手架初始化

一键创建 skill 目录骨架 + 模板文件。
支持三种模板：basic / multi-scene / data-driven

用法：python3 scripts/init_skill.py --name <skill-name> --template <basic|multi-scene|data-driven> [--dest <path>] [--channel lightweight|full]
"""

import argparse
import os
import sys
from datetime import date
from pathlib import Path

TODAY = date.today().isoformat()

SKILL_MD_BASIC = """---
name: {name}
version: "1.0.0"
description: {description}
template: basic
triggers:
  - TODO
token_budget:
  L0_trigger: 100
  L1_core: 800
  L2_deep: 3500
  hard_cap: 5000
disable: false
---

# {display_name}

**核心使命**：[一句话描述这个 skill 做什么]

适用：[目标用户]

## 核心原则

- TODO

## 文件索引

---
"""

SKILL_MD_MULTI_SCENE = """---
name: {name}
version: "1.0.0"
description: {description}
template: multi-scene --no-data
scenes:
  - id: scene_1
    name: TODO
    trigger_patterns: ["TODO"]
    workflow: A
triggers:
  - TODO
token_budget:
  L0_trigger: 120
  L1_core: 800
  L2_deep: 3500
  hard_cap: 5000
disable: false
---

# {display_name}

**核心使命**：[一句话描述]

## 场景路由

| 场景 | 触发词 | 工作流 |
|------|--------|--------|
| TODO | TODO | A |

## 文件索引

---
"""

README_TMPL = """# {display_name}

[TODO: 一句话定位]

## 能做什么

- TODO

## 怎么用

- "TODO"
"""

CHANGELOG_TMPL = """# Changelog — {display_name}

## [1.0.0] - {date}

### Added
- 初始版本

"""

SPEC_TMPL = """# SPEC.md — {display_name} v1.0.0

## 核心需求

### REQ-001: TODO
**描述**：TODO
**优先级**：P0
**验证标准**：TODO

## 非功能需求

| 需求 | 说明 |
|------|------|
| NFR-001 Token预算 | L0:100, L1:800, L2:3500, hard_cap:5000 |
"""

DESIGN_TMPL = """# DESIGN.md — {display_name} v1.0.0

## 架构决策记录

### ADR-001: TODO
**背景**：TODO
**决策**：TODO
**理由**：TODO
**后果**：TODO

## Token 实测

| 组件 | Token | 预算 | 状态 |
|------|-------|------|:---:|
| L0 | — | 100 | — |
| L1 | — | 800 | — |
| L2 | — | 3500 | — |
"""

CONFIG_TMPL = """# {name} v1.0.0 配置文件
# TODO: 添加配置参数
"""

SOURCES_TMPL = """# {name} v1.0.0 数据源配置

sources:
  # TODO: 定义数据源
  # main_source:
  #   name: ""
  #   type: local | remote
  #   primary: true
  #   description: ""
  #   format: ""
  #   cache_ttl: null
  #   update_trigger: ""
  #   forbidden: []
"""

PHILOSOPHY_TMPL = """# PHILOSOPHY.md — {display_name}

> version: 1.0.0 | date: {date}

## 核心信念

1. TODO
2. TODO
3. TODO

## 不可回退原则

- TODO
"""


def create_skill(name: str, template: str, dest: str, channel: str = "full"):
    """创建 skill 骨架"""
    skill_dir = Path(dest).expanduser().resolve()
    skill_dir.mkdir(parents=True, exist_ok=True)
    
    display_name = name.replace("-", " ").title()
    desc = f"[TODO: 一句话描述 {display_name}]"
    
    created = []

    # SKILL.md
    if template == "multi-scene":
        skill_content = SKILL_MD_MULTI_SCENE.format(name=name, display_name=display_name, description=desc)
    else:
        skill_content = SKILL_MD_BASIC.format(name=name, display_name=display_name, description=desc)
    (skill_dir / "SKILL.md").write_text(skill_content)
    created.append("SKILL.md")

    # README.md
    (skill_dir / "README.md").write_text(README_TMPL.format(display_name=display_name))
    created.append("README.md")

    # CHANGELOG.md
    (skill_dir / "CHANGELOG.md").write_text(CHANGELOG_TMPL.format(display_name=display_name, date=TODAY))
    created.append("CHANGELOG.md")

    # Full channel extras
    if channel == "full":
        (skill_dir / "SPEC.md").write_text(SPEC_TMPL.format(display_name=display_name))
        (skill_dir / "DESIGN.md").write_text(DESIGN_TMPL.format(display_name=display_name))
        (skill_dir / "PHILOSOPHY.md").write_text(PHILOSOPHY_TMPL.format(display_name=display_name, date=TODAY))
        created.extend(["SPEC.md", "DESIGN.md", "PHILOSOPHY.md"])

    # Directories
    for d in ["references", "scripts", "tests", "data"]:
        (skill_dir / d).mkdir(exist_ok=True)
        (skill_dir / d / ".gitkeep").touch()
        created.append(f"{d}/")

    # Config (skip for lightweight channel)
    if channel != "lightweight":
        (skill_dir / "config.yaml").write_text(CONFIG_TMPL.format(name=name))
        created.append("config.yaml")

    # Data-driven extras
    if template == "data-driven":
        (skill_dir / "data" / "sources.yaml").write_text(SOURCES_TMPL.format(name=name))
        created.append("data/sources.yaml")

    # Append file index to SKILL.md
    _append_file_index(skill_dir)

    return {
        "success": True,
        "name": name,
        "template": template,
        "channel": channel,
        "path": str(skill_dir),
        "files": created
    }


def _append_file_index(skill_dir: Path):
    """自动生成单列文件索引表并追加到 SKILL.md 末尾"""
    index_lines = []
    for subdir in ["references", "scripts", "tests", "data"]:
        path = skill_dir / subdir
        if not path.is_dir():
            continue
        files = sorted(f for f in os.listdir(path) if os.path.isfile(path / f) and not f.startswith("."))
        for f in files:
            index_lines.append(f"| {subdir}/{f} |")

    # Also add root files
    for root_file in ["README.md", "CHANGELOG.md", "SPEC.md", "DESIGN.md", "PHILOSOPHY.md", "config.yaml"]:
        if (skill_dir / root_file).exists():
            index_lines.append(f"| {root_file} |")

    if not index_lines:
        return

    skill_md = skill_dir / "SKILL.md"
    content = skill_md.read_text(encoding="utf-8")
    content = content.rstrip() + "\n\n" + "\n".join(index_lines) + "\n"
    skill_md.write_text(content, encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description="skill-creator-king 脚手架初始化")
    parser.add_argument("--name", required=True, help="Skill 名称（小写+连字符）")
    parser.add_argument("--template", required=True, choices=["basic", "multi-scene", "data-driven"], help="模板类型")
    parser.add_argument("--dest", default=None, help="目标路径（默认：~/.workbuddy/skills/<name>）")
    parser.add_argument("--channel", default="full", choices=["lightweight", "full"], help="通道（默认full）")
    
    args = parser.parse_args()
    
    dest = args.dest or os.path.expanduser(f"~/.workbuddy/skills/{args.name}")
    
    result = create_skill(args.name, args.template, dest, args.channel)
    
    if result["success"]:
        print(f"🎯 {result['name']} 骨架已创建")
        print(f"   模板: {result['template']}")
        print(f"   通道: {result['channel']}")
        print(f"   路径: {result['path']}")
        print(f"   文件: {', '.join(result['files'][:6])}{'...' if len(result['files']) > 6 else ''}")
        print(f"")
        print(f"下一步：用 skill-creator-king 引导填充模板 → \"帮我建一个 skill\"")


if __name__ == "__main__":
    main()
