# DESIGN.md — {{SKILL_NAME}}

## 架构决策记录

### ADR-001: {{ADR_001_TITLE}}
**背景**：{{ADR_001_BG}}
**决策**：{{ADR_001_DECISION}}
**理由**：{{ADR_001_REASON}}
**后果**：{{ADR_001_CONSEQUENCE}}

---

## Token 实测

| 组件 | 文件 | Token | 占比 |
|------|------|-------|------|
{{TOKEN_TABLE}}

## 模块关系图
{{MODULE_DIAGRAM}}

## 数据流图
{{DATAFLOW_DIAGRAM}}
