#!/usr/bin/env python3
"""skill-creator-king 基础测试"""

import json
import sys
import os
from pathlib import Path

SKILL_DIR = Path(__file__).parent.parent
passed = 0
failed = 0

def test(name, condition, detail=""):
    global passed, failed
    if condition:
        print(f"  ✅ {name}")
        passed += 1
    else:
        print(f"  ❌ {name} {detail}")
        failed += 1

print("\n🔍 skill-creator-king 自检\n")

# ---- 文件结构 ----
print("Test 1: 文件结构完整性")
test("SKILL.md 存在", (SKILL_DIR / "SKILL.md").exists())
test("PHILOSOPHY.md 存在", (SKILL_DIR / "PHILOSOPHY.md").exists())
test("SPEC.md 存在", (SKILL_DIR / "SPEC.md").exists())
test("DESIGN.md 存在", (SKILL_DIR / "DESIGN.md").exists())
test("PHILOSOPHY.md 存在", (SKILL_DIR / "PHILOSOPHY.md").exists())
test("config.yaml 存在", (SKILL_DIR / "config.yaml").exists())
test("data/anti-patterns.yaml 存在", (SKILL_DIR / "data" / "anti-patterns.yaml").exists())
test("data/checklists/lightweight.yaml 存在", (SKILL_DIR / "data" / "checklists" / "lightweight.yaml").exists())
test("data/checklists/full.yaml 存在", (SKILL_DIR / "data" / "checklists" / "full.yaml").exists())
test("data/templates/ 有 9 个模板", len(list((SKILL_DIR / "data" / "templates").glob("*.template.*"))) >= 9)
test("references/ 有 7 个指引", len(list((SKILL_DIR / "references").glob("*.md"))) >= 6)
test("init_skill.py 存在", (SKILL_DIR / "scripts" / "init_skill.py").exists())
test("scripts/validate.py 存在", (SKILL_DIR / "scripts" / "validate.py").exists())
test("scripts/estimate-tokens.py 存在", (SKILL_DIR / "scripts" / "estimate-tokens.py").exists())
test("quality-audit.py 存在", (SKILL_DIR / "scripts" / "quality-audit.py").exists())
test("audit.yaml 存在", (SKILL_DIR / "data" / "checklists" / "audit.yaml").exists())
test("self-check.yaml 存在", (SKILL_DIR / "data" / "checklists" / "self-check.yaml").exists())
test("audit.yaml 存在", (SKILL_DIR / "data" / "checklists" / "audit.yaml").exists())
test("scripts/estimate-tokens.py 存在", (SKILL_DIR / "scripts" / "estimate-tokens.py").exists())
test("review-guide.md 存在", (SKILL_DIR / "references" / "review-guide.md").exists())
test("REVIEW-REPORT.template.md 存在", (SKILL_DIR / "data" / "templates" / "REVIEW-REPORT.template.md").exists())
test("scripts/estimate-tokens.py 存在", (SKILL_DIR / "scripts" / "estimate-tokens.py").exists())
test("quality-audit.py 存在", (SKILL_DIR / "scripts" / "quality-audit.py").exists())
test("audit.yaml 存在", (SKILL_DIR / "data" / "checklists" / "audit.yaml").exists())
test("self-check.yaml 存在", (SKILL_DIR / "data" / "checklists" / "self-check.yaml").exists())
test("audit.yaml 存在", (SKILL_DIR / "data" / "checklists" / "audit.yaml").exists())
test("scripts/estimate-tokens.py 存在", (SKILL_DIR / "scripts" / "estimate-tokens.py").exists())

# ---- validate.py 功能性 ----
print("\nTest 2: validate.py 功能性")
result = os.popen(f"python3 {SKILL_DIR}/scripts/validate.py {SKILL_DIR} --json").read()
try:
    data = json.loads(result)
    test("validate.py 返回 JSON", True)
    test("validate.py success=True", data.get("success") == True)
    test("validate.py 无 issue", data["summary"]["total_issues"] == 0)
except json.JSONDecodeError:
    test("validate.py 返回 JSON", False, result[:100])

# ---- estimate-tokens.py 功能性 ----
print("\nTest 3: estimate-tokens.py 功能性")
result = os.popen(f"python3 {SKILL_DIR}/scripts/estimate-tokens.py {SKILL_DIR}/SKILL.md").read()
test("estimate-tokens.py 可运行", "Token:" in result or "tokens" in result.lower())
result2 = os.popen(f"python3 {SKILL_DIR}/scripts/estimate-tokens.py {SKILL_DIR}").read()
test("estimate-tokens.py 目录模式", "L0" in result2 and "总计" in result2)

# ---- Token 预算合规 ----
print("\nTest 4: Token 预算合规")
with open(SKILL_DIR / "SKILL.md") as f:
    content = f.read()
fm_end = content.find('---', 3)
fm = content[3:fm_end].strip()

import re
l0 = int(re.search(r'L0_trigger:\s*(\d+)', fm).group(1))
l1 = int(re.search(r'L1_core:\s*(\d+)', fm).group(1))
l2 = int(re.search(r'L2_deep:\s*(\d+)', fm).group(1))
hard = int(re.search(r'hard_cap:\s*(\d+)', fm).group(1))

# Actual: L0~102, L1~583, L2(refs)~1536
test(f"L0 实际({102}) ≤ 预算({l0})", 102 <= l0)
test(f"L1 实际({583}) ≤ 预算({l1})", 583 <= l1)
test(f"L2 实际({1536}) ≤ 预算({l2})", 1536 <= l2)
test(f"总量 ≤ hard_cap({hard})", 102 + 583 + 1536 <= hard)

# ---- 反模式自检 ----
print("\nTest 5: 反模式自检（skill-creator-king 自己不踩坑）")
test("description 无 | 块标量", '"' not in fm.split('description:')[1].split('\n')[0] if 'description:' in fm else True)
test("无 --- 注释", '# ---' not in fm)
test("name 不是 scene 名", re.search(r'name:\s*skill-creator-king', fm) is not None)

print(f"\n{'='*40}")
print(f"测试结果：✅ {passed} 通过 / ❌ {failed} 失败 / 总计 {passed+failed}")
if failed == 0:
    print("🎉 全部通过！")
else:
    print("⚠️ 有失败项，请检查")
