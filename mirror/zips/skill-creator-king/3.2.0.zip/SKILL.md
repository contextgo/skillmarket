---
name: skill-creator-king
version: "3.2.0"
description: 从对话建、用分数验、持续迭代——skill 全生命周期 total solution。五阶段流程（定位→需求→设计→实现→交付），四大入口（创建/升级/审查/评分），10维度质量评分，活性审计+文件表一致性+自进化+Ralph Loop自反思+缓存预检。
template: basic
triggers:
  - 创建一个skill
  - 帮我建一个skill
  - 我想做一个skill
  - 新建技能
  - 做一个工具
  - 帮我做一个
  - 升级到完整版
  - 补全skill
  - 升级skill
  - 帮我看看这个skill
  - 帮我改改skill
  - 审查skill
  - 给skill做体检
  - 这个skill不太好用
  - 检查一下我的skill
  - 帮我打一下分
  - 给skill评分
token_budget:
  L0_trigger: 125
  L1_core: 900
  L2_deep: 4800
  hard_cap: 6200
allowed-tools:
  - Read
  - Write
  - Bash
  - Edit
disable: false
---

# skill-creator-king — 帮你从零到一建好一个 skill

> 好用的 skill 是聊出来的，不是生成出来的。AI 是助手，不是替身。

## 四大入口

| 入口 | 触发词 | 起点 | 做什么 |
|------|--------|------|--------|
| 🆕 创建 | "帮我建一个 skill" | 空白 | 从零建（5 Phase） |
| 🔄 升级 | "升级到完整版" | 轻量 skill | 补全缺失（Gap 分析） |
| 🩺 审查 | "帮我看看这个 skill" | 任意 skill | 体检+治疗+教学 |
| 📊 评分 | "帮我打一下分" | 任意 skill | 10维度质量审计 |

**消歧规则**：
- "帮我改改" + 已有 skill 名 → 🩺 审查打磨
- "帮我改改/补全" + "完整版" → 🔄 升级
- "帮我打一下分" + skill 名 → 📊 评分
- 不明确时 → 反问用户意图

---

## 🆕 创建：五阶段流程

先选通道，再按 Phase 走。详见 references/phase-*.md。

### 入口：通道 + 模板选择

开始前先问用户：

```
"你想走哪条路？

🚀 轻量通道：30分钟出活。产出：定位+3-5REQ+SKILL.md+README+CHANGELOG
🏗️ 完整通道：2-3小时，架构经得起迭代。产出：PHILOSOPHY+SPEC+DESIGN+scripts+tests+全部文档
📡 数据驱动(新增)：完整版 + data/sources.yaml + 缓存策略。适合需要网络/API/本地数据的skill。

以后随时可以说「升级到完整版」。"
```

**强制阻塞点**：必须等用户选择通道后才能继续。

> ⚠️ 通道(lightweight/full)和模板(basic/multi-scene/data-driven)是正交的两个轴。
> 先选通道定流程深度，Phase 3 设计时讨论模板类型。

### Phase 1-5 索引
| Phase | 核心 | 关键产出 | 强制阻塞 | 详见 |
|-------|------|---------|:---:|------|
| 1 定位 | 谁+什么问题+叫什么 | 一句话定位 + 触发示例 | 🔒 名称+触发词 | phase-1-positioning.md |
| 2 需求 | 数据源 + REQ + NFR | REQ列表 + Token预算 | 🔒 数据源范围 | phase-2-requirements.md |
| 3 设计 | ADR + Token实测 | SPEC+DESIGN + Ralph Loop 最多3轮 | — | phase-3-design.md |
| 4 实现 | SKILL.md + L2 | init_skill.py 骨架 → 安全清单6项 | 🔒 安全清单 | phase-4-implementation.md |
| 5 交付 | 自检+Ralph Loop+评分+文档 | 交付物 + 最终自反思 | 🔒 P0全部通过 | phase-5-verification.md |

⚠️ Frontmatter 安全清单（Phase 4 强制逐项）：`---` 注释、列表前注释行、`|` 块标量、workflow 文件路径、版本一致性

---

## 🔄 自反思循环（Ralph Loop）

Phase 3 DESIGN 和 Phase 5 VERIFY 各执行一轮双层自反思：

1. **客观检查**：AI 逐项过 data/checklists/self-check.yaml 的 objective 清单
2. **主观自检**：AI 按 subjective 清单问自己 4 个问题
3. **发现问题 → 修正 → 重检**，最多 3 轮
4. **全过或 3 轮后冻结**：SPEC/DESIGN 冻结，后续改动需新 ADR

> ⚡ 轻量通道 + 客观全过 → 可跳过主观自检

详见 phase-3-design.md / phase-5-verification.md。

## 🔄 升级机制

详见 references/upgrade-guide.md。
流程：读现状 → 对照 full.yaml 找 gap → 逐 gap 补（不重写已有）→ 完整版交付

---

## 🩺 审查打磨（Review & Refine）

详见 references/review-guide.md。

**三步流程**：

1. **体检**：validate.py + estimate-tokens.py + 抽检 2-3 个 L2 → 体检报告
2. **诊断**：用户选优先级 → 根因分析（引用 anti-patterns）→ 影响分析
3. **治疗+复查**：逐项改 → re-validate → 进度提示 → 改进报告

**三位一体报告**：🌟 亮点 + ⚠️ 需改进 + 💡 学习要点

**特殊路径**：
- 0 issue → 正面反馈 + 标注值得坚持的模式
- 纯诊断 → 用户只想知道问题，不改 → 生成报告即止
- 修复救援 → skill 损坏时，只看能读的部分，手写修复建议
- 抽检标注 → 大 skill 只抽检 2-3 个 L2，明确标注

**进度管理**：
每修一个问题展示进度："3/7 已修，继续还是暂停？"

**版本 bump**：
修完后问是否 bump → validate.py 扫描列出版本文件清单 → 同步更新

**报告存储**：
默认放被审查 skill 目录，用户可选"放当前目录"

---

## 🧬 自进化（Self-Evolution）

审查其他 skill 时，发现好模式 → 过三道门 → 用户拍板 → 纳入自身。

| 能学 | 不能学 |
|------|--------|
| 反模式库、检查项、模板、指引 | 领域知识、架构决策、核心原则 |

三道门：① 适合我吗？② 有冲突吗？③ 用户拍板？

- 审查结束时批量呈现可学项，不逐个打断
- 审查 skill-creator-king 自身时跳过此步骤
- CHANGELOG 标注来源："学自 XX skill 审查"或"设计自省"
- "这次没学到新东西"也是诚实的结论

---

## 数据文件索引

| 文件 |
|------|
| data/checklists/lightweight.yaml |
| data/checklists/full.yaml |
| data/anti-patterns.yaml |
| data/templates/*.template.md |
| data/templates/sources.template.yaml |
| data/examples/little-writer-index.yaml |
| references/phase-*.md |
| references/upgrade-guide.md |
| references/review-guide.md |
| references/liveness-audit.md |
| scripts/validate.py |
| scripts/estimate-tokens.py |
| scripts/init_skill.py |
| scripts/quality-audit.py |
| data/checklists/audit.yaml |
| data/checklists/self-check.yaml |
| tests/test_basic.py |
