# skill-creator-king

> 从对话到 skill，从评分到进化——Skill 全生命周期管家。

## 这是什么

skill-creator-king 是 WorkBuddy 上的 Skill 开发工作台。从零创建一个新 skill，到审查已有 skill、升级版本、评分质量、发布到 SkillHub，覆盖全流程。每个阶段由 AI 引导用户对话决策，不替用户定案。

## 核心能力

| 能力 | 说明 |
|------|------|
| 🆕 创建 | 从空白 skill 起步，5 阶段对话引导（定位→需求→设计→实现→交付） |
| 🔄 升级 | 轻量→完整通道，先诊断 gap 再逐项补齐 |
| 🩺 审查 | 10 维度质量评分 + 活性审计 + 文件表一致性检查 |
| 📊 评分 | 10 维度质量审计，脚本定量 + AI 定性 |
| 🧬 自进化 | 审查中学习好模式，过三道门后纳入自身 |

## 快速使用

| 场景 | 触发词 |
|------|--------|
| 建 skill | "帮我建一个 skill" |
| 升级 | "升级到完整版" |
| 审查 | "帮我看看这个 skill" |
| 评分 | "帮我打一下分" |

## 技术架构

- **P0 文件结构**：SKILL.md → CHANGELOG/SPEC/DESIGN → references/phase-*.md 逐级细化
- **质量保证**：validate.py（frontmatter 检查 + 文件表一致性）+ quality-audit.py（10 维评分）+ Ralph Loop 自反思
- **自进化**：审查其他 skill 时识别可复用模式 → 三道门过滤（适合/不冲突/用户拍板）→ 纳入反模式库或检查项

## 环境要求

- WorkBuddy Agent
- Python 3（仅标准库）
- shell（bash/zsh）

## 安全与限制

- 仅读取 `~/.workbuddy/skills/` 目录下的文件
- 写操作需用户逐项确认
- 不发起外部网络请求
- 零 pip 依赖

## 版本更新说明（v3.0.2 → v3.2.0）

### v3.2.0
- PHILOSOPHY.md → PRINCIPLES.md：信念文件重命名，更准确反映 8 条核心原则

### v3.1.4
- validate.py 扫描改为自动发现目录，消除 tests/ 盲区
- 删除死模板 data/templates/SKILL.template.md
- review-guide.md 新增三条操作纪律：不穷举、不双写、不窄检

### v3.1.3
- SKILL.md 文件结构表改为单列格式
- init_skill.py 自动生成文件索引

### v3.1.2
- validate.py 新增 check_file_table()——文件表与 filesystem 一致性检查

### v3.1.1
- references/liveness-audit.md：活性审计四问法
- review-guide.md 集成活性审计触发条件

### v3.1.0
- 新增配置与逻辑分层、入口同步清单检查

### v3.0.2
- 版本管理 2 层规则重构
- validate.py check_version_consistency 重写
