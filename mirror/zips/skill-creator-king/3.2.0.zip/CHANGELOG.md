# Changelog — skill-creator-king

## [3.2.0] - 2026-05-07

### Changed
- **PHILOSOPHY.md → PRINCIPLES.md**：信念文件重命名，更准确反映 8 条核心原则

## [3.1.4] - 2026-05-07

### Fixed
- **validate.py 扫描改为自动发现目录**：不再硬编码目录列表，消除 tests/ 盲区
- **删除死模板 `data/templates/SKILL.template.md`**：0 引用，与 init_skill.py 内联模板漂移
- **SKILL.md 文件表补 `tests/test_basic.py`**
- **description 更新**

### Added
- **review-guide.md 新增「三条操作纪律」**：不穷举、不双写、不窄检

## [3.1.3] - 2026-05-07

### Changed
- **SKILL.md 文件结构表改为单列**：去掉「用途」列，只需维护文件路径
- **init_skill.py 自动生成文件索引**：创建新 skill 时自动追加所有文件的单列索引表
- **SKILL_MD_BASIC/MULTI_SCENE 模板增加「文件索引」占位节**

## [3.1.2] - 2026-05-07

### Added
- **validate.py 新增 `check_file_table()`**：检测 SKILL.md 文件结构表与 filesystem 一致性。每次加/删 references/ 文件后自动抓遗漏。零新增模块，内嵌在已有 validate 流程中。
- **SKILL.md 文件结构表**：补 `data/templates/sources.template.yaml` 条目（被新检查抓到的遗漏）

## [3.1.1] - 2026-05-07

### Added
- **references/liveness-audit.md**：活性审计（四问法），检测技能迭代 3+ 次后的死代码和冗余
- **review-guide.md**：末尾新增「活性审计」节，3 条件自动触发
- **SKILL.md 文件结构表**：新增 liveness-audit.md 条目
- **liveness-audit.md** 自身含元规则：「references/ 加文件必须同步更新 SKILL.md 文件结构表」

## [3.1.0] - 2026-05-07

### Added
- 📖 新增原则 9「配置与逻辑分层」和原则 10「入口内嵌同步清单」（学自 human-stars 审查）
- 🩺 review-guide.md 新增两项审查：配置分层检查 + 入口同步清单检查

## [3.0.2] - 2026-05-06

### Changed
- 🛠 版本管理规则重构：从"所有文件版本一致"改为2层规则——版本只存在于 SKILL.md frontmatter（权威）和 CHANGELOG/SPEC/DESIGN 版本历史（同步），其他文件禁止出现独立版本号
- 🛠 validate.py check_version_consistency 重写：🟢检查 frontmatter → 🟡检查版本历史同步 → ❌扫描屏蔽文件中的违规版本号
- 🛠 validate.py 版本散列正则优化：从反向排除改为正向匹配可疑模式，消除功能历史标记误报
- 🛠 模板（5个）移除 {{VERSION}} 变量：PHILOSOPHY/README/DESIGN/SPEC/sources
- 🛠 review-guide.md 版本 bump 流程同步更新

### Fixed
- 🐛 sck 自身版本散落：PHILOSOPHY/config/README/DESIGN/SPEC 标题移除版本号
- 🐛 sck 缺少版本历史表：SPEC.md + DESIGN.md 新增版本历史表
- 🐛 little-writer SPEC/DESIGN 标题残留 v3.8.0

### 背景
little-writer 审计发现 6 个文件版本号滞后，根因是模板在多个文件中散布 {{VERSION}}，升版时无人记得全改。改为2层规则后，validate.py 自动检测违规。

## [3.0.1] - 2026-05-05

### Removed
- 🗑️ 移除"打分量物不量人"信念（第7条），表述易误解且不必要——评分机制通过实践驱动，不需独立信念背书
- 信念从9条变为8条，后续信念重新编号（8→7，9→8）

### Changed
- PRINCIPLES.md: v3.0.1，移除第7条信念
- DESIGN.md ADR-006: 去除"量物不量人"引用
- CHANGELOG.md: 2.0 条目标注废弃说明

## [3.0.0] - 2026-05-04

### Added
- 🔄 Ralph Loop 自反思：Phase 3/5 双层自反思（客观+主观），最多3轮止损
- 轻量通道可短路跳过主观自检
- data/checklists/self-check.yaml（6客观+4主观）
- 信念 5/9 完善（迭代哲学 + 自反思底线）
- 🧬 缓存系统：quality-audit.py 内置缓存（同skill同版本秒出）
- 🤖 预检机制：3个手动维度脚本预检标记辅助AI裁定
- 🗑️ --clear-cache 清空全部缓存
- 📦 缓存命中提示 + --no-cache 强制重跑

### Design Iteration（v2.1 设计自省）
- 缓存键 = skill_path + version + mtime + skill-creator-king-version
- 两态缓存：script_only / full（保护full不被覆盖）
- 预检不参与评分——只给标记，AI裁定完整分数
- 缓存自动清理：50文件上限 + 30天过期

### Changed
- SKILL.md: Phase 3/5 嵌入 Ralph Loop
- PRINCIPLES.md: 第9条信念 + 第5条完善
- phase-3-design.md / phase-5-verification.md: 新增自反思步骤
- quality-audit.py: 内置缓存 + 预检 + --save-cache --manual-scores
- PRINCIPLES.md: 新增第8条信念"
- config.yaml: 新增cache配置

## [2.0.0] - 2026-05-04

### Added
- 🏗️ 脚手架初始化：init_skill.py 一键生成目录骨架+模板文件（继承SCK init_skill）
- 📊 质量评分：10维度质量审计（继承SCK verify.py），通道自适应（轻量6维/完整10维）
- 📡 数据驱动通道：完整版 + sources.yaml + 缓存策略
- 通道与模板正交选择（先选通道定深度，Phase 3选模板）
- quality-audit.py + data/checklists/audit.yaml

### Design Iteration（v2.0 设计自省）
- （已废弃）v2.0 曾引入"打分量物不量人"信念，v3.0.1 移除——理念虽好但表述易误解，改为实践驱动的评分机制而不设独立信念条目
- 评分嵌入报告不独立，作为体检/交付报告的一部分
- <70 分策略：警告不阻止，鼓励"修了再用"
- 轻量通道评分自适应（满分85，不评SPEC/DESIGN/脚本维度）
- 审查入口可选跳过评分
- 自进化后自动重跑评分
- 95+ 分可选 README 质量徽章

### Changed
- SKILL.md: Phase 5 增强（自检→评分→版本→文档）+ 评分独立入口
- validate.py: 新增 --strict 模式（检测pyyaml可用性）
- SPEC.md: 新增 REQ-007（质量评分）+ 通道数更新
- DESIGN.md: 新增 ADR-006（评分架构）+ Token 表刷新
- PRINCIPLES.md: 新增第7条信念
- config.yaml: 新增 audit 配置

## [1.1.0] - 2026-05-04

### Added
- 🩺 审查打磨入口：三步流程（体检→诊断→治疗+复查）
- 三位一体审查报告 + 自进化机制
- review-guide.md + REVIEW-REPORT.md.tmpl

### Design Iteration（v1.1 开发过程中两轮自省）
- 自进化三道门 + 不能学的边界 + 自指 guard 路径比对
- 审查标准按 template 类型适配（basic/multi-scene）
- 手动审查对照 anti-patterns auto_detectable:false 条目

### Learned（学自外部）
- （暂无，待首次审查其他 skill 后追加）

## [1.0.0] - 2026-05-04

### Added
- 五阶段结构化流程 + 双通道选择
- 12 个结构化反模式 + validate.py + estimate-tokens.py
- 8 个产出物模板 + 5 Phase 指引 + 升级指南
- 22 个自动化测试

### Notes
- 初始版本，基于 little-writer v2.0→v3.0 踩坑经验构建
