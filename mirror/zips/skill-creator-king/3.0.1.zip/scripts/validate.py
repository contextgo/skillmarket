#!/usr/bin/env python3
"""skill-creator-king Frontmatter 安全 + 版本一致性验证脚本

功能：
- 解析 SKILL.md frontmatter
- 检查已知反模式（--- 注释、| 块标量、workflow 文件路径等）
- 检查版本号一致性（跨 SKILL.md/SPEC/DESIGN/config/PHILOSOPHY/sources）
- 输出结构化 JSON + 人类可读报告

用法：python3 scripts/validate.py <skill目录路径> [--json]
"""

import json
import re
import sys
from pathlib import Path


def extract_frontmatter(content: str) -> tuple:
    """安全提取 frontmatter，返回 (dict, 原始字符串)"""
    if not content.startswith('---'):
        return {}, content
    
    end_idx = content.find('---', 3)
    if end_idx == -1:
        return {}, content
    
    fm_str = content[3:end_idx].strip()
    body = content[end_idx + 3:]
    
    # 简单手动解析 YAML frontmatter（避免依赖 yaml 库）
    fm = {}
    for line in fm_str.split('\n'):
        line = line.rstrip()
        if not line or line.startswith('#'):
            continue
        if ':' in line:
            key, _, val = line.partition(':')
            key = key.strip()
            val = val.strip().strip('"').strip("'")
            if val:
                fm[key] = val
    
    return fm, body


def check_anti_patterns(skill_dir: Path, fm_str: str, fm: dict, content: str) -> list:
    """检查已知反模式"""
    issues = []
    
    # AP-001: --- in comments
    if re.search(r'#.*---', fm_str):
        issues.append({
            "id": "yaml_comment_separator",
            "severity": "critical",
            "check": "frontmatter 注释中使用了 ---",
            "fix": "将 --- 替换为 === 或其他分隔符",
            "why": "yaml_parser 的 _extract_frontmatter_str() 用 content.find('---', 3) 会误匹配注释"
        })
    
    # AP-002: comment before list items
    lines = fm_str.split('\n')
    for i, line in enumerate(lines):
        stripped = line.strip()
        if stripped.startswith('#') and i + 1 < len(lines):
            next_line = lines[i + 1].strip()
            if next_line.startswith('- '):
                issues.append({
                    "id": "comment_before_list",
                    "severity": "critical",
                    "check": f"第{i+1}行：列表字段首行前有注释",
                    "fix": "删除列表字段首行前的注释行",
                    "why": "yaml_parser 无法识别注释行后的列表项"
                })
    
    # AP-003: | in description
    if 'description' in fm:
        desc_line = [l for l in fm_str.split('\n') if l.strip().startswith('description:')]
        if desc_line and '|' in desc_line[0]:
            issues.append({
                "id": "description_pipe_block",
                "severity": "high",
                "check": "description 使用了 | 块标量",
                "fix": "改为 description: 普通单行字符串",
                "why": "| 块标量在 yaml_parser 中可能引发截断或重复"
            })
    
    # AP-004: workflow filepath
    if 'scenes' in fm:
        for line in fm_str.split('\n'):
            if 'workflow:' in line and 'references/' in line:
                issues.append({
                    "id": "workflow_filepath",
                    "severity": "high",
                    "check": f"workflow 字段使用了文件路径: {line.strip()}",
                    "fix": "改为短代码，如 workflow: W1",
                    "why": "文件路径格式可能导致 skill 注册表显示异常"
                })
                break
    
    # AP-005: name looks like a scene name
    if 'name' in fm and 'scenes' in fm:
        scene_names = []
        for line in fm_str.split('\n'):
            if 'name:' in line and 'scenes' not in line:
                m = re.search(r'name:\s*(.+)', line)
                if m:
                    scene_names.append(m.group(1).strip().strip('"'))
        if len(scene_names) > 1:
            skill_name = scene_names[0]
            for sn in scene_names[1:]:
                if skill_name == sn:
                    issues.append({
                        "id": "name_field_confusion",
                        "severity": "high",
                        "check": f"所有 scene 的 name 与 skill name 相同: {skill_name}",
                        "fix": "每个 scene 应有独立的功能名称",
                        "why": "会导致 skill 显示名与某个 scene 名重复"
                    })
                    break
    
    # AP-006: description length check (heuristic for duplication)
    body_lines = content.split('\n')
    desc_count = sum(1 for l in body_lines if '覆盖想象作文' in l or '从"教你怎么写"' in l)
    if desc_count > 2:
        issues.append({
            "id": "description_duplication",
            "severity": "critical",
            "check": f"description 疑似重复 {desc_count} 次",
            "fix": "删除重复行，只保留一份 description",
            "why": "编辑工具循环替换导致内容重复"
        })
    
    return issues


def check_version_consistency(skill_dir: Path, expected_version: str) -> list:
    """检查版本号一致性"""
    issues = []
    
    version_files = {
        'SKILL.md': skill_dir / 'SKILL.md',
        'SPEC.md': skill_dir / 'SPEC.md',
        'DESIGN.md': skill_dir / 'DESIGN.md',
        'config.yaml': skill_dir / 'config.yaml',
        'PHILOSOPHY.md': skill_dir / 'PHILOSOPHY.md',
        'data/sources.yaml': skill_dir / 'data' / 'sources.yaml',
    }
    
    for label, path in version_files.items():
        if not path.exists():
            continue
        
        with open(path, 'r') as f:
            content = f.read()
        
        # Search for version patterns
        found = False
        patterns = [
            rf'(?:version|v)[:\s]*["\']?{re.escape(expected_version)}',
            rf'v{re.escape(expected_version)}',
        ]
        
        for pattern in patterns:
            if re.search(pattern, content):
                found = True
                break
        
        if not found:
            # Try to find what version is actually there
            ver_match = re.search(r'(?:version|v)[:\s]*["\']?(\d+\.\d+\.\d+)', content)
            actual = ver_match.group(1) if ver_match else '未找到'
            issues.append({
                "id": "version_mismatch",
                "severity": "high",
                "check": f"{label} 版本号 {actual}，预期 {expected_version}",
                "fix": f"将 {label} 中的版本号改为 {expected_version}",
                "why": "版本号不一致影响 skill 维护和问题定位"
            })
    
    return issues


def check_file_structure(skill_dir: Path) -> list:
    """检查文件结构完整性"""
    issues = []
    
    required = ['SKILL.md']
    for f in required:
        if not (skill_dir / f).exists():
            issues.append({
                "id": "missing_required_file",
                "severity": "critical",
                "check": f"缺少必需文件: {f}",
                "fix": f"创建 {f}"
            })
    
    return issues


def validate(skill_dir: str, strict: bool = False) -> dict:
    """主验证函数
    strict: 检测 pyyaml 可用时使用严格解析，不可用则降级为纯文本
    """
    skill_path = Path(skill_dir).expanduser().resolve()
    
    if not skill_path.exists():
        return {"success": False, "error": f"目录不存在: {skill_path}"}
    
    skill_md = skill_path / 'SKILL.md'
    if not skill_md.exists():
        return {"success": False, "error": f"SKILL.md 不存在: {skill_md}"}
    
    # Read SKILL.md
    with open(skill_md, 'r') as f:
        content = f.read()
    
    # Extract frontmatter
    fm_str_start = content.find('---', 3) if content.startswith('---') else -1
    fm_str = content[3:fm_str_start].strip() if fm_str_start > 0 else ''
    fm, _ = extract_frontmatter(content)
    version = fm.get('version', '0.0.0')
    

    # --strict mode: try pyyaml for deeper validation
    if strict:
        try:
            import yaml
            yaml.safe_load(fm_str)
        except ImportError:
            print("💡 提示：安装 pyyaml 可获得更严格的 Frontmatter 检查（pip install pyyaml）", file=sys.stderr)
        except Exception as e:
            all_issues.append({
                "id": "yaml_parse_error",
                "severity": "critical",
                "check": f"YAML 严格解析失败: {str(e)[:100]}",
                "fix": "检查 Frontmatter 格式是否符合 YAML 规范",
                "why": "正式环境可能使用严格解析器"
            })

    # Run checks
    anti_pattern_issues = check_anti_patterns(skill_path, fm_str, fm, content)
    version_issues = check_version_consistency(skill_path, version) if version != '0.0.0' else []
    structure_issues = check_file_structure(skill_path)
    
    all_issues = anti_pattern_issues + version_issues + structure_issues
    
    critical = [i for i in all_issues if i['severity'] == 'critical']
    high = [i for i in all_issues if i['severity'] == 'high']
    medium = [i for i in all_issues if i['severity'] == 'medium']
    
    return {
        "success": True,
        "skill": str(skill_path),
        "version": version,
        "summary": {
            "total_issues": len(all_issues),
            "critical": len(critical),
            "high": len(high),
            "medium": len(medium),
            "passed": len(all_issues) == 0
        },
        "issues": all_issues
    }


def format_report(result: dict) -> str:
    """格式化人类可读报告"""
    if not result.get('success'):
        return f"❌ 验证失败: {result.get('error')}"
    
    s = result['summary']
    lines = [
        f"📋 skill-creator-king 验证报告",
        f"",
        f"Skill: {result['skill']}",
        f"版本: {result['version']}",
        f"",
        f"结果: {'✅ 全部通过' if s['passed'] else '⚠️ 发现问题'}",
        f"  Critical: {s['critical']}",
        f"  High: {s['high']}",
        f"  Medium: {s['medium']}",
    ]
    
    if result['issues']:
        lines.append("")
        lines.append("--- 问题详情 ---")
        for i, issue in enumerate(result['issues'], 1):
            lines.append(f"")
            lines.append(f"[{issue['severity'].upper()}] #{i} {issue['id']}")
            lines.append(f"  检查: {issue['check']}")
            lines.append(f"  修复: {issue['fix']}")
            if 'why' in issue:
                lines.append(f"  原因: {issue['why']}")
    
    return '\n'.join(lines)


def main():
    if len(sys.argv) < 2:
        print("用法: python3 scripts/validate.py <skill目录路径> [--json]")
        print("示例: python3 scripts/validate.py ~/.workbuddy/skills/my-skill/")
        sys.exit(1)
    
    skill_dir = sys.argv[1]
    json_output = '--json' in sys.argv
    strict = '--strict' in sys.argv
    
    result = validate(skill_dir, strict=strict)
    
    if json_output:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(format_report(result))


if __name__ == '__main__':
    main()
