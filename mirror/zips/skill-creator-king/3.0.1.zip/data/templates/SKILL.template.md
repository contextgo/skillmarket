---
name: {{SKILL_NAME_SLUG}}
version: "{{VERSION}}"
description: {{DESCRIPTION}}
template: {{TEMPLATE_TYPE}}
triggers:
{{TRIGGERS}}
token_budget:
  L0_trigger: {{L0}}
  L1_core: {{L1}}
  L2_deep: {{L2}}
  hard_cap: {{HARD_CAP}}
allowed-tools:
{{ALLOWED_TOOLS}}
disable: false
---

# {{SKILL_NAME}} — {{TAGLINE}}

**核心使命**：{{MISSION}}

适用：{{TARGET_USERS}}

## 场景路由

{{ROUTING_TABLE}}

## 核心原则

{{PRINCIPLES}}

## 脚本

{{SCRIPTS_TABLE}}

## 三级加载

{{LOADING_TABLE}}
