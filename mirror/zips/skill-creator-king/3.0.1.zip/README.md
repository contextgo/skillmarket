# skill-creator-king

> 超强skill创建、评价、维护、迭代的元工具。从对话建、用分数验、持续迭代——skill 全生命周期 total solution。功能强大，持续更新。

## 核心理念

好用的 skill 是聊出来的，不是生成出来的。skill-creator-king 不是模板填充工具——AI 是陪练，用户拍板，每一步都带着真实踩坑经验帮用户绕开陷阱。

## 三大入口

| 入口 | 做什么 |
|------|--------|
| 🆕 创建 | 从零建一个 skill，支持轻量/完整/数据驱动三通道 |
| 🔄 升级 | 把轻量 skill 补全为完整版 |
| 🩺 审查 | 体检+治疗+教学，三位一体报告 |
| 📊 评分 | 10维度质量审计，100分制，通道自适应 |

- **五阶段结构化流程**：定位 → 需求 → 设计 → 实现 → 交付
- **双通道选择**：🚀 轻量（30分钟出活）或 🏗️ 完整（架构经得起迭代）
- **审查打磨**：自动扫描 + 三位一体报告（亮点/改进/学习要点）
- **质量评分**：10维度自动化审计（继承SCK verify.py），轻量6维/完整10维
- **自进化**：审查中主动学习好模式，经用户拍板纳入自身
- **Frontmatter 安全扫描**：自动检测 12 种已知反模式
- **Token 预算估算**：实测每个文件的 Token 数
- **缓存加速**：同skill同版本审查秒出结果，Token节省60%+
- **预检辅助**：手动维度脚本预检，辅助AI一致裁定
- **Ralph Loop 自反思**：Phase 3/5 双层自反思（客观+主观），最多3轮止损
- **自动交付物**：README.md + CHANGELOG.md + 交付报告
- **升级机制**：轻量 skill 随时升级到完整版

## 怎么用

直接说：
- "帮我建一个 skill"（创建）
- "升级到完整版"（升级）
- "帮我看看这个 skill"（审查）
- "帮我打一下分"（评分）
- "我想做一个工具"
- "给 skill 做个体检"

## 文件结构

```
skill-creator-king/
├── SKILL.md
├── PHILOSOPHY.md
├── SPEC.md
├── DESIGN.md
├── README.md
├── CHANGELOG.md
├── config.yaml
├── data/
│   ├── anti-patterns.yaml      ← 12 个结构化坑位
│   ├── checklists/             ← 轻量/完整检查清单
│   ├── templates/              ← 9 个产出物模板
│   └── examples/               ← little-writer 参考案例
├── references/
│   ├── phase-*md               ← 5 个 Phase 详细指引
│   ├── upgrade-guide.md        ← 升级流程
│   └── review-guide.md         ← 审查打磨 + 自进化
├── scripts/
│   ├── init_skill.py            ← 脚手架初始化
│   ├── validate.py             ← Frontmatter安全
│   ├── quality-audit.py          ← 10维度评分
│   └── estimate-tokens.py      ← Token 估算
└── tests/
    └── test_basic.py           ← 34 个测试
```

## 版本

v3.0.0 — skill全生命周期total solution（创建/升级/审查/评分 + Ralph Loop自反思 + 缓存预检），基于 little-writer v2.0→v3.0 踩坑经验构建
