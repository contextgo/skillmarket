# 审查打磨（Review & Refine）

> 🩺 给已有 skill 做体检 + 治疗 + 教学

## 三步流程

### Step 1：体检

**1.1 自动扫描**：
- `quality-audit.py` → 10维度评分（默认运行，含 validate + estimate-tokens 内部调用，不需单独跑）
- 审查入口默认询问"是否运行评分？"（轻量6维/完整10维自适应）— 跳过评分时单独跑 validate + estimate-tokens
  - 评分结果默认缓存（同版本秒出），加 `--no-cache` 重跑。缓存命中+AI已裁定态 → 跳过手动审查，直接展示结果

**1.2 手动审查**：
- 读 SKILL.md：先看 `template` 字段判断类型
  - multi-scene：路由是否清晰？场景消歧是否完备？
  - basic：原则是否可执行？入口是否单一明确？
- 读 config.yaml（如有）：参数集中？有降级策略？
- 手动对照 anti-patterns.yaml 中 `auto_detectable: false` 的条目：
  - #9 missing_fallback_config：脚本有降级配置吗？
  - #10 script_does_scoring：脚本只做计量吗？
  - #11 false_promise：有做不到却在承诺的功能吗？
  - #12 token_budget_guess：Token 是实测还是拍脑袋？
- 抽检 L2 文件：
  - L2 文件分布在 references/ 和 data/ 目录（不含 scripts/）
  - 先 `ls references/ data/` 数文件数
  - ≤2 个 → 全量审查
  - >2 个 → 抽检 2-3 个
  - 0 个 → 跳过，标注"无 L2 文件"
  - 抽检优先级：核心工作流文件 > Token 最大的文件 > 随机
- ⚠️ 抽检时明确标注"本次为抽样审查，非全量"

**1.3 0 issue 路径**：
```
"体检结果：✅ 0 issue。基础质量无可挑剔。
 我继续手动审查设计和 L2 内容，看有没有可以打磨的设计问题。"
```

**1.4 修复救援模式**：
validate.py 返回 success:false → 只看能读的部分，手写修复建议，不跑完整流程。

### Step 2：诊断

**2.1 呈现**：
```
"扫出 N 个问题：
 🔴 X Critical：...
 🟡 Y High：...
 🟢 Z Medium：...
 你想先解决哪个？还是按严重度从 Critical 开始？"
```

**2.2 深挖**（每个选定问题）：
- 引用 anti-patterns.yaml 的反模式
- 踩坑故事解释根因（"上次 little-writer 这里……"）
- 影响分析："改了会影响其他地方吗？" 判断标准：改动涉及 frontmatter 字段（triggers/scenes）、L2 文件路径、路由表时，检查所有引用处

**2.3 纯诊断出口**：
```
用户："你帮我看看就行，我这会儿不改"
→ 输出体检报告 + 改进建议 → REVIEW-REPORT.md
→ 仍然进入 Step 4（自进化，如有发现）
→ 结束："什么时候想修了，随时说「帮我改改这个 skill」。"
```

### Step 3：治疗 + 复查

**3.1 逐项改**：
- 改一个 → re-validate → 确认绿灯 → 下一个
- 进度提示："🔧 3/7 已修，继续还是暂停？"
- 如果改动涉及 references/ 或 data/ 文件 → 重新跑 estimate-tokens.py → 更新 Token 分布

**3.2 P0 门槛**：
- P0 未通过 = 不能收工
- P1/Medium 可放入"未处理建议"

**3.3 版本 bump**：
```
"修了 N 个问题，要不要 bump 到 1.0.1？"
→ 列出版本文件清单（validate.py 扫描）
→ 同步更新 SKILL.md / SPEC / DESIGN / config / PHILOSOPHY / sources
```

**3.4 报告存储**：
默认 `{被审查 skill}/REVIEW-REPORT-{DATE}.md`，用户可选放当前目录。

### Step 4（可选）：自进化

审查结束时，如果发现 skill-creator-king 能学的好模式：
```
"对了，这个 skill 有个做法 skill-creator-king 也可以学：[描述]。
 要不要加？"
```

- 批量呈现，不逐个打断
- 审查 skill-creator-king 自身时跳过
- "没学到新东西"诚实现身
- 采纳后 CHANGELOG 标注来源
- 采纳后自动重跑 quality-audit.py → 确认分数未降 → 降了则提醒

---

## 三位一体审查报告

### 🌟 亮点

每个亮点三要素：是什么 + 为什么好 + 能学到什么

例：
"脚本有 fallback 配置——这是反模式 #9 的正面案例。
 结果是 skill 在不同环境下可靠性大幅提升。
 以后建 skill 时，对所有脚本都这样做。"

### ⚠️ 需改进

反模式引用 + 根因 + 修复建议 + 踩坑故事

例：
"description 重复了 15 遍。可能是编辑工具 old_string 不唯一导致循环替换。
 好在修复简单：删重复行就行。我们 little-writer 也踩过这个坑。"

### 💡 学习要点

```
这次审查你能带走的设计教训：
1. ✅ Frontmatter 字段单一来源——version 只在 SKILL.md 定义
2. ⚠️ YAML 解析器比你想的脆弱
3. ✅ 脚本-LLM 边界清晰是架构基本功
```

**语气**：用"一起踩过的坑"口吻，不说教。

---

## 话术规则

| 场景 | 话术模式 |
|------|---------|
| 有亮点有不足 | 先说亮点（建立信任），再说问题（接受度更高） |
| 只有问题无亮点 | "虽然扫出几个问题，但我注意到 XXX 处理得挺干净的——直觉是对的" |
| 全绿无问题 | "基础质量无可挑剔。我给你标注了几个值得继续坚持的模式——" |
