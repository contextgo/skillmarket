# DESIGN.md — skill-creator-king v3.0.0

## 架构决策记录

### ADR-001: basic 模板（非 multi-scene）

**背景**：三个入口（创建/升级/审查）功能差异大，multi-scene 似乎合适。
**决策**：使用 basic 模板，L1 body 做路由索引，L2 推详细指引。
**理由**：
- 三个入口不是平行场景，是不同起点的同一件事（建好 skill）
- Phase 1-5 是线性流程，跳 Phase 会导致缺失依赖
- multi-scene 会让用户困惑"该选创建/升级/审查哪个场景"，但实际应该根据用户说的触发词自动路由
**后果**：
- ✅ L1 body 保持简洁（实测 542 token）
- ✅ 复杂流程推 L2，按需加载
- ⚠️ 无法通过 scenes 自动触发工作流，需要 AI 在对话中判断入口

### ADR-002: 双通道设计（轻量/完整）

**背景**：不同用户有不同的时间和质量需求。
**决策**：两个通道共享五阶段框架，复杂度在产出物深度上分化。
**理由**：
- 轻量用户不需要 SPEC/DESIGN/scripts/tests，但需要同样的引导质量
- 升级机制保证轻量不会变成死胡同
- 共享 checklist（lightweight.yaml / full.yaml）让差异结构化
**后果**：
- ✅ 入口统一，用户体验一致
- ⚠️ Phase 引导需要根据通道调整引导深度

### ADR-003: 三位一体审查报告

**背景**：传统的验证工具只报错，不教人。
**决策**：审查报告包含🌟亮点 + ⚠️需改进 + 💡学习要点。
**理由**：
- 用户走了弯路 ≠ 不会走直路，亮点标注好模式同样有价值
- "能学到什么"让每次审查都是微型架构课
- 符合 PHILOSOPHY 信念 3（追问比给出答案更重要）
**后果**：
- ✅ 审查从"挑错"变成"教学"
- ⚠️ 无亮点时不强行找，诚实说"没学到新东西"

### ADR-004: 🧬 自进化三道门

**背景**：审查中发现的模式可能适合 skill-creator-king 自身。
**决策**：三道门过滤 + 用户拍板 + CHANGELOG 标注来源。
**理由**：
- 不能所有好东西都学（领域知识、架构决策除外）
- PHILOSOPHY 信念 6："教练也要成长"，但"绝不自毁根基"
- 用户拍板保证不静默修改
**后果**：
- ✅ skill-creator-king 可持续进化
- ✅ 边界清晰（能学/不能学）
- ⚠️ 审查 skill-creator-king 自身时跳过（自指 guard：路径比对）

### ADR-005: 无 SPEC/DESIGN → 补上

**背景**：skill-creator-king 最初没有 SPEC.md 和 DESIGN.md，违反自己的完整通道标准。
**决策**：v3.0.0 补上，用自身流程检验一致性。
**理由**：
- 吃自己的狗粮是对哲学一致性的最终验证
- 如果 skill-creator-king 审查自己，它应该通过所有检查
**后果**：
- ✅ 完整通道标准自洽
- ⚠️ SPEC/DESIGN 需保持与 SKILL.md/PHILOSOPHY.md 同步

### ADR-006: 10维度质量评分 (v2.0)

**背景**：skill-creator-king 需要客观的质量度量。SCK 的 verify.py 已有成熟的 10 维度评分系统。
**决策**：创建 quality-audit.py，继承 SCK 评分思路，输出 100 分制但嵌入报告不独立。轻量通道 6 维(85满分)，完整通道 10 维(100满分)。
**理由**：
- "打分量物不量人"——技术质量评分不同于对人的评判
- 评分嵌入报告不独立，保持三位一体风格
- 通道自适应避免惩罚轻量 skill
- 手动维度(3个)标记待 AI 裁定，不隐藏不确定性
**后果**：
- ✅ skill-creator-king 自评 100/100 🏆
- ⚠️ 手动维度依赖 AI 判断质量，跨会话可能不一致

### ADR-007: 缓存与预检 (v3.0)

**背景**：同skill重复审查时 validate + estimate-tokens 多次重跑，耗时且Token浪费。手动维度纯靠AI裁定，跨会话不一致。
**决策**：quality-audit.py 内置缓存层。3个手动维度增加脚本预检标记，不参与评分，辅助AI裁定。
**理由**：
- 缓存键含 mtime——文件改后自动失效
- 两态缓存：script_only(自动)/full(AI裁定后)，保护full不被覆盖
- 预检不给分——标记是给AI的信息，不是预判
- "能代码不话术，能缓存不重算"（PHILOSOPHY #8）
**后果**：
- ✅ 同skill重复审查：Token节省60%+，3s→0.2s
- ✅ 跨会话评分一致性
- ⚠️ 缓存清理策略（50上限+30天过期）需微调

### ADR-008: Ralph Loop 自反思 (v3.0)

**背景**：AI 一次性输出 SPEC/DESIGN 常见遗漏（需求没进SPEC、ADR互相矛盾、缺少后果链）。用户成了第一道QA，本该AI先筛一轮。
**决策**：Phase 3 DESIGN 和 Phase 5 VERIFY 各嵌入一次双层自反思循环。最多3轮，3轮或全过后SPEC/DESIGN冻结。
**理由**：
- "AI 像人一样很难一次把所有事情做对"（PHILOSOPHY #5）
- "自反思把AI变成自己的第一道QA"（PHILOSOPHY #9）
- 轻量通道+客观全过可短路跳过主观自检
- 3轮上限防止无限循环
**后果**：
- ✅ 需求遗漏和ADR矛盾率大幅降低
- ✅ SPEC/DESIGN 冻结后BUILD有稳定基础
- ⚠️ 轻量通道下用户体验一致但质量保证略弱

## Token 实测

| 组件 | Token | 预算 | 状态 |
|------|-------|------|:---:|
| L0 (frontmatter) | 121 | 125 | ✅ |
| L1 (SKILL.md body) | 689 | 900 | ✅ |
| L2 (references+data) | 4704 | 4800 | ✅ |
| 总计 | 5514 | 6200 | ✅ |

## 模块关系图

```
用户输入
  │
  ├─ "帮我建一个 skill" → 🆕 创建
  │    └─ Phase 1-5 (references/phase-*.md)
  │         └─ data/checklists/ + data/templates/
  │
  ├─ "升级到完整版" → 🔄 升级
  │    └─ references/upgrade-guide.md
  │         └─ data/checklists/full.yaml
  │
  └─ "帮我看看这个 skill" → 🩺 审查
       └─ references/review-guide.md
            ├─ scripts/validate.py
            ├─ scripts/estimate-tokens.py
            ├─ scripts/quality-audit.py (评分)
            ├─ data/anti-patterns.yaml
            ├─ data/checklists/audit.yaml
            └─ data/templates/REVIEW-REPORT.md.tmpl
                    │
                    └─ 🧬 Step 4: 自进化 → CHANGELOG.md
```
