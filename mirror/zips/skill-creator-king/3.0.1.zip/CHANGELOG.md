# Changelog — skill-creator-king

## [3.0.0] - 2026-05-04

### Added
- 🔄 Ralph Loop 自反思：Phase 3/5 双层自反思（客观+主观），最多3轮止损
- 轻量通道可短路跳过主观自检
- data/checklists/self-check.yaml（6客观+4主观）
- 信念 5/9 完善（迭代哲学 + 自反思底线）
- 🧬 缓存系统：quality-audit.py 内置缓存（同skill同版本秒出）
- 🤖 预检机制：3个手动维度脚本预检标记辅助AI裁定
- 🗑️ --clear-cache 清空全部缓存
- 📦 缓存命中提示 + --no-cache 强制重跑

### Design Iteration（v2.1 设计自省）
- 缓存键 = skill_path + version + mtime + skill-creator-king-version
- 两态缓存：script_only / full（保护full不被覆盖）
- 预检不参与评分——只给标记，AI裁定完整分数
- 缓存自动清理：50文件上限 + 30天过期

### Changed
- SKILL.md: Phase 3/5 嵌入 Ralph Loop
- PHILOSOPHY.md: 第9条信念 + 第5条完善
- phase-3-design.md / phase-5-verification.md: 新增自反思步骤
- quality-audit.py: 内置缓存 + 预检 + --save-cache --manual-scores
- PHILOSOPHY.md: 新增第8条信念"
- config.yaml: 新增cache配置

## [2.0.0] - 2026-05-04

### Added
- 🏗️ 脚手架初始化：init_skill.py 一键生成目录骨架+模板文件（继承SCK init_skill）
- 📊 质量评分：10维度质量审计（继承SCK verify.py），通道自适应（轻量6维/完整10维）
- 📡 数据驱动通道：完整版 + sources.yaml + 缓存策略
- 通道与模板正交选择（先选通道定深度，Phase 3选模板）
- quality-audit.py + data/checklists/audit.yaml

### Design Iteration（v2.0 设计自省）
- 7th信念："打分量物，不量人"——技术质量评分对人的评判
- 评分嵌入报告不独立，作为体检/交付报告的一部分
- <70 分策略：警告不阻止，鼓励"修了再用"
- 轻量通道评分自适应（满分85，不评SPEC/DESIGN/脚本维度）
- 审查入口可选跳过评分
- 自进化后自动重跑评分
- 95+ 分可选 README 质量徽章

### Changed
- SKILL.md: Phase 5 增强（自检→评分→版本→文档）+ 评分独立入口
- validate.py: 新增 --strict 模式（检测pyyaml可用性）
- SPEC.md: 新增 REQ-007（质量评分）+ 通道数更新
- DESIGN.md: 新增 ADR-006（评分架构）+ Token 表刷新
- PHILOSOPHY.md: 新增第7条信念
- config.yaml: 新增 audit 配置

## [1.1.0] - 2026-05-04

### Added
- 🩺 审查打磨入口：三步流程（体检→诊断→治疗+复查）
- 三位一体审查报告 + 自进化机制
- review-guide.md + REVIEW-REPORT.md.tmpl

### Design Iteration（v1.1 开发过程中两轮自省）
- 自进化三道门 + 不能学的边界 + 自指 guard 路径比对
- 审查标准按 template 类型适配（basic/multi-scene）
- 手动审查对照 anti-patterns auto_detectable:false 条目

### Learned（学自外部）
- （暂无，待首次审查其他 skill 后追加）

## [1.0.0] - 2026-05-04

### Added
- 五阶段结构化流程 + 双通道选择
- 12 个结构化反模式 + validate.py + estimate-tokens.py
- 8 个产出物模板 + 5 Phase 指引 + 升级指南
- 22 个自动化测试

### Notes
- 初始版本，基于 little-writer v2.0→v3.0 踩坑经验构建
