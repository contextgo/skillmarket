# King 规范完整文档

> 本文档是 skill-creator-king 产出 skill 的完整规范，属于 L2 深度参考。

## 一、SKILL.md 极简规范

### 核心原则

SKILL.md 是 skill 的入口文件，承担三个职责：

1. **L0 触发匹配**：frontmatter 中的 `triggers` 让 AI 决定是否激活此 skill
2. **L1 场景路由**：body 部分告诉 AI 该调用哪个脚本
3. **L2 引导**：指引 AI 按需加载 references/ 中的深度文档

**SKILL.md 不应该做的**：
- ❌ 包含完整的业务逻辑描述
- ❌ 内联大段代码模板
- ❌ 包含详细的因子说明或评分规则
- ❌ 充当百科全书

### Token 预算软约束

| 级别 | 预算 | 内容 |
|------|------|------|
| L0 | ~100 | frontmatter（name/version/description/triggers） |
| L1 | ~800 | body（场景路由+核心指令+脚本调用说明） |
| L2 | ~3000 | references/（按需加载的完整文档） |

**估算方法**：
- 中文字符 × 1.5 ≈ token 数
- 英文单词 × 1.3 ≈ token 数
- 使用 `verify.py` 自动检查

### Frontmatter 规范

```yaml
---
name: skill-name              # 必需，小写+连字符
version: "1.0.0"              # 必需，语义化版本号
description: |                # 必需，含触发词描述
  一句话描述功能
triggers:                     # 必需，触发词列表
  - 触发词1
  - 触发词2
token_budget:                 # 必需
  L0_trigger: 100
  L1_core: 800
  L2_deep: 3000
  hard_cap: 4000
data_sources:                 # data-driven/multi-scene 必需
  - source_id
scenes:                       # multi-scene 必需
  - 场景一
  - 场景二
---
```

## 二、数据源管理规范（sources.yaml）

### 文件位置

`data/sources.yaml`

### 格式规范

```yaml
sources:
  <source_id>:
    primary:
      name: "主数据源名称"
      type: "api"              # api | web_scrape | file
      url: "https://..."
      format: "json"           # json | csv | html | xml
      pinned_at: "2026-04-24"  # 固化日期
      notes: "使用说明"
    fallback:                  # 可选但强烈建议
      name: "备数据源名称"
      type: "web_scrape"
      url: "https://..."
      format: "html"
      pinned_at: "2026-04-24"
    forbidden:                 # 明确禁止的源
      - name: "禁止源名称"
        reason: "禁止原因"
    cache_ttl: 300             # 缓存有效期（秒）
    update_trigger: "on_demand" # on_demand | scheduled
```

### 关键规则

1. **固化日期（pinned_at）**：标记数据源何时被验证可靠，固化后除非遇到问题否则不更新
2. **禁止源（forbidden）**：踩坑后明确标记，防止未来误用
3. **缓存有效期（cache_ttl）**：不同数据源有不同的时效性要求
4. **更新触发（update_trigger）**：
   - `on_demand`：执行时懒加载（被动更新）
   - `scheduled`：cron 定时刷新（主动更新，需配合 WorkBuddy automation）

## 三、缓存规范（data/cache/）

### 缓存文件格式

```json
{
  "source": "source_id",
  "fetched_at": "2026-04-24T10:30:00+00:00",
  "ttl": 300,
  "expires_at": "2026-04-24T10:35:00+00:00",
  "data": { ... }
}
```

### 缓存管理规则

- 缓存文件名 = `<source_id>.json`
- 写入时计算 `expires_at = fetched_at + ttl`
- 读取时检查 `expires_at`，过期则重新获取
- 缓存最多服务 `max_age_seconds`（config.yaml），超时强制刷新

## 四、三文件追溯规范

### SPEC.md / DESIGN.md 生命周期

#### 定位

| 文档 | 定位 | 本质 |
|------|------|------|
| **SPEC.md** | 需求契约 | 用户确认后冻结，BUILD/VERIFY/UPDATE/EVOLVE 的依据 |
| **DESIGN.md** | 架构契约 | 用户确认后冻结，BUILD 阶段技术决策的依据 |

**运行时 AI 不读 SPEC/DESIGN**，运行时只读 SKILL.md（L1）和 references/（L2）。

#### 读取时机

| 阶段 | 读 SPEC | 读 DESIGN | 目的 |
|------|---------|-----------|------|
| DESIGN（创建） | 生成 | 生成 | 输出提案供用户确认 |
| BUILD | **必读** | **必读** | 按契约执行构建 |
| VERIFY | **必读** | **必读** | 检查代码是否满足契约 |
| DISCUSS（更新） | 可选 | 不读 | 了解现状，快速确认意图 |
| DESIGN（更新） | **必读** | **必读** | 评估变更是否与原始契约冲突 |
| EVOLVE | **必读** | **必读** | 回顾契约是否仍有效 |
| 运行时 | 不读 | 不读 | — |

#### BUILD 阶段具体流程

```
读取 SPEC.md → 提取 REQ-xxx 需求条目
      ↓
读取 DESIGN.md → 提取 ADR-xxx 架构决策
      ↓
按需求生成代码 + 按 ADR 做技术选择
      ↓
写入 config.yaml / sources.yaml / scripts/
```

如果 BUILD 中发现需求必须调整：**回退到 DESIGN → 修改 SPEC/DESIGN → 重新确认 → 再 BUILD**。禁止直接改代码不同步文档。

#### 行为需求处理

运行时 AI 不读 SPEC/DESIGN，只读 SKILL.md。SPEC 中涉及以下行为需求时，BUILD 阶段必须在 SKILL.md 中显式转化为 AI 可执行的指令：

- **边界需求**（适用/禁止场景）→ 覆盖模板中的默认边界声明
- **数据处理约束**（标注盲区/禁止编造）→ 默认保持，DISCUSS 有明确约定时覆盖（如用户明确允许估算，则改为「可估算但需标注」）
- **输出质量**（结论前置/排版固定）→ 加入 SKILL.md 的使用方式或功能说明
- **领域红线**（禁止操作）→ 追加到行为约束段

转化要求：不使用 SPEC 编号或技术术语，用 AI 能直接理解和遵循的自然语言。

示例：
```
SPEC REQ-003: "仅处理港股 IPO，A 股/美股不响应"
→ SKILL.md 行为约束段修改为:
  "仅处理港股 IPO。收到 A 股/美股/加密货币相关提问时，告知超出范围并停止。"

SPEC REQ-004: "数据缺失时标注盲区，不编造评分"
→ SKILL.md 行为约束段保持不变（模板默认值已覆盖）或强化为:
  "某因子数据不可用时，标注「数据不足，该因子跳过」，禁止用均值或估算值替代。"
```

#### data-driven 何时需要 DESIGN.md

**有 P0/P1 级架构决策需要记录时，强烈建议写 DESIGN。**

判断标准：

| 场景 | 是否需要 DESIGN | 原因 |
|------|----------------|------|
| 单一数据源、简单脚本 | 可选 | 无复杂决策 |
| 多数据源（≥2） | **建议** | 需记录数据源优先级、切换策略 |
| 需要缓存策略 | **建议** | 需记录缓存 TTL、刷新策略选择 |
| 需要异常处理方案 | **建议** | 需记录降级策略、重试机制 |
| 涉及数据源主备切换 | **必需** | ADR 记录切换条件和逻辑 |
| 评分/阈值有复杂逻辑 | **建议** | ADR 记录算法选择和参数依据 |

### SPEC.md（需求规格）

- **何时需要**：data-driven / multi-scene 必需
- **核心内容**：
  - 版本历史
  - 核心需求列表（REQ-xxx 格式）
  - 非功能需求
- **更新时机**：每次新增/变更需求时

### DESIGN.md（设计文档）

- **何时需要**：multi-scene 必需，data-driven 按上述判断标准决定
- **核心内容**：
  - 版本历史
  - 架构决策记录（ADR-xxx 格式）
  - 模块关系图
  - 数据流图
- **更新时机**：每次架构变更时

### CHANGELOG.md（变更记录）

- **何时需要**：所有模板必需
- **核心内容**：
  - 版本号 + 日期
  - 变更内容 + **原因说明**
  - **勿回退标记**（❗ 前缀）
- **增强格式**：

```markdown
## [1.1.0] - 2026-04-24

### Changed
- ❗ 将 NeoData 从主数据源降级为禁止源
  - **原因**: 验证发现港股价格数据不准确
  - **替代方案**: 新浪财经API（主）+ 东方财富（备）
  - **勿回退**: 除非 NeoData API 明确修复并重新验证
  - **关联ADR**: ADR-003
```

## 五、配置分离规范（config.yaml）

### 文件位置

`config.yaml`（skill 根目录）

### 格式规范

```yaml
# 可调参数配置
# 修改配置不需要改代码

# 评分阈值
thresholds:
  pass_score: 40
  high_score: 70

# 数据获取
fetch:
  timeout_seconds: 30
  retry_count: 3
  retry_delay_ms: 1000

# 缓存策略
cache:
  default_ttl_seconds: 3600
  max_age_seconds: 86400
```

### 关键规则

- 所有可调参数（阈值、URL、超时时间）放入 config.yaml
- 脚本通过 `load_config()` 读取配置，不硬编码
- 修改阈值只需改 config.yaml，不需要改代码

## 六、脚本规范

### 通用约定

- 使用 Python 3 标准库，无外部依赖
- 输出格式为 JSON，`success` 字段表示执行结果
- 错误信息在 `error` 字段中返回
- 读取 config.yaml 获取配置参数
- 读取 data/sources.yaml 获取数据源
- 缓存数据存入 data/cache/

### 脚本模板

```python
#!/usr/bin/env python3
"""脚本功能简述"""

import json
import sys
from pathlib import Path


def load_config():
    """读取 config.yaml"""
    config_path = Path(__file__).parent.parent / "config.yaml"
    config = {}
    if config_path.exists():
        # 简易 YAML 读取
        ...
    return config


def main():
    config = load_config()
    # 实际业务逻辑
    result = {
        "success": True,
        "data": { ... }
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
```

## 七、更新策略

### 两路并行

| 路径 | 方式 | 适用场景 |
|------|------|---------|
| 主动更新 | WorkBuddy automation (cron) | 数据源定期刷新 |
| 被动更新 | 执行时懒加载 | 用户触发时检查缓存 |

### 在 sources.yaml 中声明

```yaml
sources:
  ipo_list:
    ...
    update_trigger: "scheduled"    # 主动更新
  realtime_price:
    ...
    update_trigger: "on_demand"    # 被动更新
```

### 设置 WorkBuddy Automation

对于 `scheduled` 类型的数据源，使用 WorkBuddy 的 automation 功能设置定时任务：

```
名称: 刷新 <skill-name> 缓存
频率: FREQ=DAILY;BYHOUR=9;BYMINUTE=0
提示: 执行 <skill-path>/scripts/refresh_cache.py
```

---

## 附录：king 自身修改的例外条款

当修改对象是 skill-creator-king 自身的**流程规则**（SKILL.md 中定义的阶段流程、循环上限、退出条件；DESIGN.md 中的架构决策；SPEC.md 中的核心需求）时：

- **可跳过 EVOLVE 阶段**：king 不能在自己进化时验证自己的进化规则，避免无限递归
- 修改后仍须运行 `verify.py ≥75`，并由人工确认
- **此例外仅适用于流程规则的修改**，脚本 bug 修复、文档补全等非流程改动仍需走完整五阶段

流程规则的判定标准：改动会影响后续 skill 创建/更新的执行方式，而不仅仅是修一个 bug。
