# 10 维度质量检查清单

> verify.py 使用的完整检查清单，属于 L2 深度参考。

## 维度1：结构规范（10%）

| # | 检查项 | 严重度 | 适用模板 |
|---|--------|--------|---------|
| 1.1 | SKILL.md 存在 | critical | all |
| 1.2 | CHANGELOG.md 存在 | critical | all |
| 1.2b | README.md 存在 | critical | all |
| 1.3 | SPEC.md 存在 | critical | data-driven, multi-scene |
| 1.4 | DESIGN.md 存在 | critical | multi-scene |
| 1.5 | config.yaml 存在 | critical | data-driven, multi-scene |
| 1.6 | data/sources.yaml 存在 | critical | data-driven, multi-scene |
| 1.7 | scripts/ 目录存在 | warning | all |
| 1.8 | references/ 目录存在 | warning | data-driven, multi-scene |
| 1.9 | data/cache/ 目录存在 | warning | data-driven, multi-scene |
| 1.10 | data/schemas/ 目录存在 | warning | data-driven, multi-scene |
| 1.11 | scripts/README.md 存在 | warning | all |

## 维度2：元数据完整（15%）

| # | 检查项 | 严重度 | 适用模板 |
|---|--------|--------|---------|
| 2.1 | frontmatter 含 name | critical | all |
| 2.2 | frontmatter 含 version | critical | all |
| 2.3 | frontmatter 含 description | critical | all |
| 2.4 | frontmatter 含 triggers | critical | all |
| 2.5 | frontmatter 含 token_budget | critical | all |
| 2.6 | triggers 列表非空 | warning | all |
| 2.7 | token_budget 含 L0/L1/L2/hard_cap | warning | all |
| 2.8 | data-driven/multi-scene 含 data_sources | warning | dd, ms |
| 2.9 | multi-scene 含 scenes 列表 | warning | ms |

## 维度3：文档有效性（10%）

| # | 检查项 | 严重度 | 适用模板 |
|---|--------|--------|---------|
| 3.1 | SPEC.md 含 REQ-xxx 需求条目 | warning | dd, ms |
| 3.2 | SPEC.md 含版本历史 | warning | dd, ms |
| 3.3 | DESIGN.md 含 ADR-xxx 决策记录 | warning | ms |
| 3.4 | CHANGELOG.md 含版本条目 | warning | all |
| 3.5 | CHANGELOG.md 含原因说明 | info | all |
| 3.6 | CHANGELOG.md 含勿回退标记 | info | all |
| 3.7 | SPEC 需求被代码满足（每个 REQ 有对应实现） | info | dd, ms |
| 3.8 | DESIGN ADR 被代码遵循（每个 ADR 有对应实现） | info | ms |
| 3.9 | README.md 含「一句话」「设计理念」等核心章节 | warning | all |

## 维度4：代码化优化（15%）

| # | 检查项 | 严重度 | 适用模板 |
|---|--------|--------|---------|
| 4.1 | scripts/ 有 .py 脚本 | warning | all |
| 4.2 | SKILL.md 引用了 scripts/ | warning | all |
| 4.3 | SKILL.md 无 >500字符的代码块 | warning | all |
| 4.4 | 脚本不是纯骨架（含实际逻辑） | info | all |
| 4.5 | 业务逻辑在脚本中而非 SKILL.md | warning | all |

## 维度5：一致性校验（15%）

| # | 检查项 | 严重度 | 适用模板 |
|---|--------|--------|---------|
| 5.1 | SKILL.md version = CHANGELOG 最新版本 | warning | all |
| 5.2 | SPEC.md 版本历史已同步 | info | dd, ms |
| 5.3 | DESIGN.md 版本历史已同步 | info | ms |
| 5.4 | 更新后 SPEC/DESIGN/CHANGELOG 同步一致 | warning | all |
| 5.5 | 脚本无硬编码阈值（应从 config.yaml 读取） | info | dd, ms |
| 5.6 | sources.yaml 中引用的脚本存在 | warning | dd, ms |

## 维度6：脚本规范（10%）

| # | 检查项 | 严重度 | 适用模板 |
|---|--------|--------|---------|
| 6.1 | 每个脚本有模块 docstring | warning | all |
| 6.2 | 每个脚本有 main() 函数 | info | all |
| 6.3 | 每个脚本有 JSON 格式输出 | info | all |
| 6.4 | 每个脚本有错误处理（try/except） | info | all |
| 6.5 | scripts/README.md 存在 | warning | all |
| 6.6 | scripts/README.md 含脚本接口文档 | info | all |

## 维度7：质量保障（5%）

| # | 检查项 | 严重度 | 适用模板 |
|---|--------|--------|---------|
| 7.1 | tests/ 目录存在 | info | all |
| 7.2 | tests/ 有测试文件 | info | all |
| 7.3 | 脚本有错误退出机制 | info | all |
| 7.4 | 脚本有空输入处理 | info | all |

## 维度8：数据层规范（10%）— V3新增

| # | 检查项 | 严重度 | 适用模板 |
|---|--------|--------|---------|
| 8.1 | data/sources.yaml 存在 | critical | dd, ms |
| 8.2 | 每个 source 有 primary | critical | dd, ms |
| 8.3 | 每个 source 有 fallback | warning | dd, ms |
| 8.4 | 每个 source 有 pinned_at | warning | dd, ms |
| 8.5 | forbidden 与 primary/fallback 无冲突 | warning | dd, ms |
| 8.6 | 缓存文件格式合规（source/fetched_at/ttl/data） | warning | dd, ms |
| 8.7 | data/schemas/ 目录存在 | info | dd, ms |
| 8.8 | basic 模板无 data/ 目录 | info | basic |

## 维度9：Token效率（5%）— V3新增

| # | 检查项 | 严重度 | 适用模板 |
|---|--------|--------|---------|
| 9.1 | SKILL.md 声明了 token_budget | critical | all |
| 9.2 | SKILL.md body < 800 tokens | warning | all |
| 9.3 | SKILL.md 无大段内联代码 | warning | all |
| 9.4 | references/ 文件存在（L2分离） | info | dd, ms |
| 9.5 | SKILL.md 声明了 L2 文件列表 | info | dd, ms |

## 维度10：可维护性（5%）— V3新增

| # | 检查项 | 严重度 | 适用模板 |
|---|--------|--------|---------|
| 10.1 | SPEC.md 存在 | critical | dd, ms |
| 10.2 | DESIGN.md 存在 | critical | ms |
| 10.3 | CHANGELOG.md 含原因说明 | info | all |
| 10.4 | CHANGELOG.md 关键变更含勿回退标记 | info | all |
| 10.5 | config.yaml 存在（阈值分离） | warning | dd, ms |

---

## 评分标准

| 分数 | 等级 | 处理 |
|------|------|------|
| ≥90 | 优秀 | 通过 |
| ≥75 | 合格 | 通过 |
| ≥60 | 需改进 | 建议修复后重验 |
| <60 | 不合格 | 必须修复 |

---

## King 自身版本升级检查清单（强制）

> 每次升级 skill-creator-king 版本时，必须逐项确认：

- [ ] **SKILL.md**：version 字段已更新
- [ ] **SPEC.md**：版本历史已追加，新增 REQ 条目已添加
- [ ] **DESIGN.md**：版本历史已追加，新增 ADR 已添加
- [ ] **CHANGELOG.md**：新版本条目已添加，含原因+勿回退标记
- [ ] **references/**：相关文档已同步更新
- [ ] **verify.py**：对 king 自身执行验证，评分 ≥75
- [ ] **一致性**：四文件版本号一致（SKILL.md = SPEC.md = DESIGN.md = CHANGELOG 最新版）
