# skill-creator-king

## 一句话
用五阶段工程化流程（讨论→设计→构建→验证→进化）创建和维护高质量的 WorkBuddy skill。

## 什么时候用
- 从零创建一个新 skill
- 修改/升级已有 skill
- 验证 skill 质量
- 打包 skill 分发

## 怎么用
对 AI 说「帮我创建一个 skill」或「帮我检查一下这个 skill 的质量」，king 会引导你走完整流程。

## 设计理念
**先想清楚再动手，每一步都可追溯。** 产出的 skill 自带四层文档（README/SKILL.md/SPEC/DESIGN），人类和 AI 各有入口，不混淆。

## 工作流程
| 阶段 | 做什么 |
|------|--------|
| PRESCAN | 自动前置审计（文件完整性+版本一致性） |
| DISCUSS | 需求讨论（三模式：快速/标准/专业） |
| DESIGN | 架构设计（SPEC+DESIGN+自反思循环） |
| BUILD | 代码生成（init_skill.py / update_skill.py） |
| VERIFY | 质量验证（10维度评分≥75合格） |
| EVOLVE | 持续进化（双层：king自身+目标skill） |

## 怎么解决
三种模板匹配不同复杂度：basic（简单工具）/ data-driven（有数据源）/ multi-scene（多场景路由）。所有产出 skill 自带 SPEC/DESIGN/CHANGELOG 三文件追溯，数据源声明式管理，缓存复用。
