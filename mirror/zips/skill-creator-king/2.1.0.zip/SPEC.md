# Skill Creator King — 需求规格说明书

## 版本历史

| 版本 | 日期 | 变更摘要 |
|------|------|---------|
| V2.1.0 | 2026-05-03 | 初始公开发布。含 28 条核心需求：五阶段工作流、三种模板、极简 SKILL.md、三级加载、数据源声明式、缓存复用、三文件追溯、配置分离、10 维度验证、增量更新、双层进化、DISCUSS 三模式分层、统一解析层、工具型 multi-scene 支持、Ralph Loop 自反思/外循环、行为约束、模板默认契约、PRESCAN 前置审计、设计理念前置、README.md 必选、版本同步清单 |

## 核心需求

### REQ-001: 五阶段引导式工作流
- **描述**: 创建/更新 skill 时，必须经历 DISCUSS→DESIGN→BUILD→VERIFY→EVOLVE 五个阶段
- **优先级**: P0
- **验证标准**: 每次创建/更新都有讨论记录、设计文档、构建产物、验证结果
- **状态**: ✅已完成

### REQ-002: 三种模板支持
- **描述**: 支持 basic / data-driven / multi-scene 三种模板，根据数据需求和场景数量自动推荐
- **优先级**: P0
- **验证标准**: init_skill.py 支持 --template 参数，三种模板均可正确生成
- **状态**: ✅已完成

### REQ-003: 产出 Skill 极简化
- **描述**: 产出的 SKILL.md 控制在 800 tokens 以内，只做触发+路由+精简指令
- **优先级**: P0
- **验证标准**: verify.py 检查 SKILL.md token 数量
- **状态**: ✅已完成

### REQ-004: 三级加载
- **描述**: L0 触发匹配(~100) → L1 核心执行(~800) → L2 深度参考(~3000，按需)
- **优先级**: P0
- **验证标准**: SKILL.md frontmatter 含 token_budget，references/ 存在但不在 SKILL.md 内联
- **状态**: ✅已完成

### REQ-005: 数据源声明式管理
- **描述**: 外部数据源通过 sources.yaml 声明（主源+备源+禁止源+固化日期），脚本不硬编码 URL
- **优先级**: P0（data-driven/multi-scene）
- **验证标准**: verify.py 检查 sources.yaml 完整性
- **状态**: ✅已完成

### REQ-006: 缓存复用
- **描述**: data/cache/ 存储带 TTL+来源+时间戳的缓存数据，避免重复获取
- **优先级**: P1（data-driven/multi-scene）
- **验证标准**: 缓存文件含 source/fetched_at/ttl/expires_at/data 字段
- **状态**: ✅已完成

### REQ-007: 两路并行更新
- **描述**: scheduled(cron主动) + on_demand(懒加载被动) 两路并行
- **优先级**: P1
- **验证标准**: sources.yaml 含 update_trigger 字段
- **状态**: ✅已完成

### REQ-008: 三文件追溯
- **描述**: SPEC.md(需求) / DESIGN.md(ADR决策) / CHANGELOG.md(含原因+勿回退标记)
- **优先级**: P0（multi-scene），P1（data-driven），P2（basic 仅 CHANGELOG）
- **验证标准**: verify.py 检查三文件存在性和内容质量
- **状态**: ✅已完成

### REQ-009: 配置分离
- **描述**: config.yaml 存储可调参数（阈值、URL、策略开关），脚本中无硬编码阈值
- **优先级**: P1（data-driven/multi-scene）
- **验证标准**: verify.py 检查脚本中是否有硬编码的阈值/URL
- **状态**: ✅已完成

### REQ-010: 10 维度质量验证
- **描述**: 整合 7 维度质量分析，扩展为 10 维度（+数据层规范/Token效率/可维护性）
- **优先级**: P0
- **验证标准**: verify.py 输出 10 维度评分，≥75 为合格
- **状态**: ✅已完成

### REQ-011: 增量更新能力
- **描述**: 支持对已有 skill 做增量更新（新增数据源/场景/阈值修改/废弃数据源），自动同步三文件
- **优先级**: P0
- **验证标准**: update_skill.py 支持 6 种变更类型
- **状态**: ✅已完成

### REQ-012: 自我进化（L1）
- **描述**: 每次创建/更新完成后，回顾过程中的经验，提炼改进项，经用户确认后更新 skill-creator-king 自身
- **优先级**: P1
- **验证标准**: EVOLVE L1 阶段有明确的触发条件、进化边界和确认流程
- **状态**: ✅已完成

### REQ-013: 旧版 skill 迁移支持
- **描述**: 从原有 skill 创建工具迁移到 King 规范
- **优先级**: P2
- **验证标准**: migrate_v2.py 能正确转换旧版 skill 到 King 规范
- **状态**: ⚠️已废弃（migrate_v2.py 已移除，迁移需求通过手动重建覆盖）

### REQ-014: 目标 skill 进化（L2）
- **描述**: EVOLVE 阶段不仅进化 king 自身，还能进化目标 skill。当反馈归因为目标 skill 的问题时（数据源失效、阈值偏差、触发词不足、缺少能力等），复用 update_skill.py 执行变更，同步 SPEC/DESIGN/CHANGELOG
- **优先级**: P1
- **验证标准**: EVOLVE L2 阶段有归因决策树、变更类型映射和标准变更流程
- **状态**: ✅已完成

### REQ-015: DISCUSS 三模式分层
- **描述**: DISCUSS 阶段提供快速（默认）/ 标准 / 专业三种模式。快速模式2步确认核心信息；标准模式按6步清单聊透；专业模式完整需求工程，含干系人地图、已知/未知清单、信息缺口分析、搜索任务，输出结构化确认书
- **优先级**: P1
- **验证标准**: discuss-guide.md 包含三模式完整引导，requirement-confirmation-template.md 存在
- **状态**: ✅已完成

### REQ-016: 统一 YAML 解析层
- **描述**: 新增 scripts/lib/yaml_parser.py，替代 update_skill.py 的 read_frontmatter() 和 verify.py 的全文字符串搜索，支持列表、嵌套、多行文本
- **优先级**: P0
- **验证标准**: parse_frontmatter() 能正确解析 triggers(列表)、token_budget(嵌套)、description(多行)；frontmatter_contains() 精确匹配字段
- **状态**: ✅已完成

### REQ-017: 多信号模板检测
- **描述**: detect_template() 从单一信号(sources.yaml)改为多信号投票(DESIGN.md + scenes字段 + sources.yaml + SPEC.md + config.yaml)，支持工具型 multi-scene
- **优先级**: P0
- **验证标准**: skill-creator-king 自身(无data/但有DESIGN.md)被正确检测为 multi-scene
- **状态**: ✅已完成

### REQ-018: 工具型 multi-scene 支持
- **描述**: verify.py 的 check_structure/check_data_layer/check_maintainability 识别工具型 multi-scene(无数据源)，不再误扣 data/ 目录的分
- **优先级**: P1
- **验证标准**: 工具型 multi-scene 不需要 data/sources.yaml 和 data/ 目录即可通过结构检查
- **状态**: ✅已完成

### REQ-019: 版本号/文档同步修复
- **描述**: update_spec() 版本号从硬编码 V0.1.0 改为动态 new_version；update_design() 增加版本历史更新；main() 传 new_version 给两个函数
- **优先级**: P0
- **验证标准**: 增量更新后 SPEC.md 和 DESIGN.md 的版本历史表格写入正确的版本号
- **状态**: ✅已完成

### REQ-020: handle_add_source 精确判断
- **描述**: handle_add_source() 使用 lib.yaml_parser 的 frontmatter_contains() 精确判断 data_sources 是否存在，替代原来永远判断错误的 read_frontmatter()
- **优先级**: P0
- **验证标准**: data_sources 存在时追加不重复，不存在时正确新增
- **状态**: ✅已完成

### REQ-021: DESIGN 自反思循环（Ralph Loop）
- **描述**: DESIGN 阶段生成 SPEC/DESIGN/sources.yaml 后，必须执行自反思循环：先通过 design_check.py 客观检查（REQ-ADR对齐、ADR互斥检测、需求覆盖、模板选择一致性、可构建性），再按 design-checklist.md 逐项主观自检（后果链、缓存合理性、用户体验）。有问题则修正后重检，最多 3 轮。basic 模板且客观检查全过时可短路跳过主观自检。design_check.py 对 basic 模板只检查 SKILL.md frontmatter 合理性（triggers 非空、token_budget 完整），跳过 REQ/ADR 相关检查
- **优先级**: P1
- **验证标准**: design_check.py 输出 JSON 格式检查结果；DESIGN 阶段 AI 必须先跑 design_check.py 再做主观自检；3轮后仍有问题须标注未通过项告知用户
- **状态**: ✅已完成

### REQ-022: VERIFY 迭代验证（快照对比）
- **描述**: VERIFY 阶段支持迭代验证：verify.py 新增 --snapshot-dir 参数，每次运行保存评分快照 JSON，自动与上次快照对比输出 delta（新增/已解决/未变 findings + 收敛状态 improving/stalled/regressed）。AI 修复后重新验证直到 score ≥75 且 criticals ≤ 上轮（首轮 score ≥75 即通过，无需对比）。最多3轮。收敛停滞（连续2轮分数差<2）时暂停报告用户。修复前建议备份（git stash 或 cp）
- **优先级**: P1
- **验证标准**: verify.py --snapshot-dir 可保存/对比快照；package_skill.py 排除 .verify_history 目录；SKILL.md VERIFY 段落含迭代验证流程
- **状态**: ✅已完成

### REQ-023: 外循环 Ralph Loop（深度迭代）
- **描述**: 五阶段流程走完后，若 EVOLVE L2 产生了实质改动（改了目标 skill 的代码/配置/数据源/触发词），则解冻 SPEC/DESIGN → 增量修改 → 用户确认 → 回到 DESIGN 重跑全流程，最多3轮（额外3遍）。默认关闭，DISCUSS 阶段询问用户是否启用。外循环期间 CHANGELOG 用 (Outer Loop Round N) 标注轮次，不单独升版本。VERIFY 未通过时外循环终止。收敛检测（从第2轮起，文件/REQ交集）和回退检测（score 下降）触发时暂停询问用户。相关 ADR: ADR-015（回退到DESIGN）、ADR-016（仅L2触发）、ADR-017（默认关闭）、ADR-018（解冻-修改-重确认）
- **优先级**: P1
- **验证标准**: SKILL.md 工作流含外循环标注；discuss-guide.md 含深度迭代开关引导；evolve-guide.md 含外循环完整专章（退出条件+解冻机制+异常检测+用户感知规范）
- **状态**: ✅已完成

### REQ-024: 行为约束规范
- **描述**: king 自身在五阶段执行过程中，除流程规则外，还须遵守运行时行为约束：①动态身份——每个阶段切换对应职业角色（需求分析师/架构师/工程师/质检员/迭代规划师），单阶段单一身份；②量化质量标准——每个阶段输出有可验证的质量要求（DISCUSS 摘要关键字段不缺失、DESIGN REQ 可验证+ADR 后果链、BUILD 脚本规范、VERIFY 评分达标、EVOLVE 归因决策树）；③分层交付——快速/标准/专业三种模式从 DISCUSS 延伸到全流程各阶段；④行文反模式——禁止套话开场/冗余过渡/emoji 装饰/内部状态描述，结论前置；⑤阶段自检——每阶段完成时按清单轻量自检
- **优先级**: P0
- **验证标准**: SKILL.md 含行为约束章节（~200 tokens）；references/behavior-spec.md 含完整行为规格文档（动态身份表+质量标准清单+分层交付矩阵+行文反模式清单+阶段自检清单）
- **状态**: ✅已完成

### REQ-025: 产出 Skill 行为质量注入
- **描述**: 让 king 产出的 skill 自带行为 DNA：①模板内置默认行为契约（不越界/不编造/结论前置/收尾闭环，~60 tokens），确保最差情况下也有行为底线；②DISCUSS 阶段引导用户思考边界/红线/输出质量（三种模式各有追问）；③BUILD 阶段 AI 读 SPEC 后，将具体行为需求覆盖模板默认值，写入 SKILL.md 行为约束段；④DESIGN 自检确认 SKILL.md 行为约束段内容与 SPEC 行为需求一致
- **优先级**: P0
- **验证标准**: init_skill.py 三种模板均含行为约束段；discuss-guide.md 快速/标准/专业模式均含行为追问；king-spec.md BUILD 指南含行为需求处理规则；design-checklist.md UX 项含行为检查子项
- **状态**: ✅已完成

### REQ-026: PRESCAN 前置审计
- **描述**: 每次加载 SCK 时自动执行前置审计：①SOUL.md 纪律注入——检查并补写「先审计再修改」纪律（幂等）；②prescan 文件完整性扫描——检查目标 skill 的文件结构、版本一致性、引用路径可达性。在 DISCUSS 之前执行，防止遗漏文件进入后续流程
- **优先级**: P0
- **验证标准**: prescan.py 存在且零外部依赖；SKILL.md 含 PRESCAN 章节；红线含「禁止跳过 PRESCAN 直接进入 DISCUSS」
- **状态**: ✅已完成

### REQ-027: 设计理念前置
- **描述**: DISCUSS 阶段采集核心设计理念（一句话的核心取舍，如"宁可漏判不可误判"），写入结构化摘要。DESIGN 阶段以设计理念为锚点，每条 ADR 须与设计理念对齐——不对齐即信号。确保产出 skill 的架构决策有统一的设计轴心
- **优先级**: P0
- **验证标准**: DISCUSS 摘要含「设计理念」字段；discuss-guide.md 三种模式均含设计理念追问；DESIGN 阶段 ADR 可追溯到设计理念
- **状态**: ✅已完成

### REQ-028: README.md 必选
- **描述**: 每个 skill 产出 README.md 作为产品说明书。层次定位：README.md 面向人类（也供 AI 回答用户基础问题），SKILL.md 面向 AI（运行时指令），SPEC/DESIGN 面向人和 AI（需求与设计追溯）。内容：一句话、适用场景、使用方法、设计理念、技术路径、工作流程。三种模板复杂度分层（basic精简/标准→data-driven/完整→multi-scene）。SKILL.md 行为约束段加「用户询问 skill 基本信息时，优先读 README.md」。verify.py CHECKLIST 加 README 存在性和内容质量检查
- **优先级**: P0
- **验证标准**: init_skill.py 三种模板均生成 README.md 骨架；verify.py check_structure 将 README.md 列为必选文件；verify 新增 README 内容质量检查；SKILL.md 行为约束段含 README 路由规则
- **状态**: ✅已完成

## 非功能需求

| 需求 | 说明 |
|------|------|
| Token 软约束 | 靠规范引导，非运行时强制截断 |
| 最小依赖 | 脚本仅依赖 Python 标准库 |
| 自反思成本控制 | basic 模板客观全过可短路跳过主观自检；DESIGN 自检最多3轮；VERIFY 迭代最多3轮 |
