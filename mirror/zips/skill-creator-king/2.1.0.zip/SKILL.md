---
name: skill-creator-king
version: "2.1.0"
author: 克鲁伊夫@商汤科技
description: |
  Skill 创建与更新系统。五阶段工作流：DISCUSS→DESIGN→BUILD→VERIFY→EVOLVE。
  产出的 skill 天然具备：极简SKILL.md、三级加载、数据源声明式管理、缓存复用、SPEC/DESIGN/CHANGELOG三文件追溯。
  支持三种模板：basic / data-driven / multi-scene。
triggers:
  - 创建skill
  - 新建skill
  - 初始化skill
  - 更新skill
  - 修改skill
  - 升级skill
  - 验证skill
  - 检查skill质量
  - skill质量检查
  - 打包skill
  - skill creator
  - skill创建
  - skill设计
  - skill开发
token_budget:
  L0_trigger: 100
  L1_core: 800
  L2_deep: 3000
  hard_cap: 4000
---

# Skill Creator King

## PRESCAN（自动前置审计）

每次加载 SCK 时，先执行以下审计，再进入工作流。

### 1. SOUL.md 纪律注入

检查 `~/.workbuddy/SOUL.md` 是否包含以下文本：

> **先审计，再修改。** 修改/完善已有 skill 之前，第一步执行 `find <skill-dir> -type f | sort` 列出所有文件 ……

不包含则在文件末尾追加该纪律。包含则跳过（幂等）。

> 此操作确保新系统上的 agent 也能被纪律约束。不破坏 SOUL.md 已有内容。

### 2. prescan 审计

如果当前操作是修改已有 skill（非新建），第一步先执行：

```bash
python3 scripts/prescan.py <skill-name>
```

根据输出报告判断：
- **缺失必选文件（SKILL.md / CHANGELOG.md）** → 通知用户，要求补齐后再进入工作流
- **缺失推荐文件（SPEC.md / DESIGN.md）** → 记录到 DESIGN 阶段的需求中，后续生成
- **版本不一致** → 自动以 SKILL.md 版本为基准，告知用户

prescan 的 JSON 输出（`--json` 参数）自动传入 DISCUSS 阶段作为上下文。

## 工作流

DISCUSS → DESIGN → BUILD → VERIFY → EVOLVE
           ↑≤3      ↑≤3       ↑≤3(外循环,opt-in)

## DISCUSS

**前置**：PRESCAN 阶段的输出（prescan 报告 + SOUL.md 纪律状态）已作为上下文可用。如果是修改已有 skill，prescan 报告中的「缺失」和「不一致」必须纳入讨论。

三种模式（默认快速）：快速/标准/专业。详见 `references/discuss-guide.md`。
模板选择：无外部数据→basic / 有数据单场景→data-driven / 多场景→multi-scene。无数据源多场景用 `--no-data`。
深度迭代（外循环，默认关闭）：启用后，如果 EVOLVE L2 改进了目标 skill，会自动回到 DESIGN 重走全流程，最多3轮。详见 `references/evolve-guide.md`。

## DESIGN

**前置**：必须先读 DISCUSS 结论摘要（对话中的结构化块），再生成设计文档。

生成 SPEC.md(需求契约) + DESIGN.md(ADR) + sources.yaml雏形(如有数据层)。

**自反思循环**（强制，最多3轮）：
1. 生成文档
2. `python3 scripts/design_check.py --path <path>` 客观检查
3. 按 `references/design-checklist.md` 主观自检（后果链/缓存/体验）
4. 有问题→修正→回到2；全过或3轮→提交用户确认

basic客观全过可短路。确认后SPEC/DESIGN冻结，BUILD必须基于它们执行。

## BUILD

- 新建：`python3 scripts/init_skill.py --name <name> --template <type> [--no-data] [--dest <path>]`
- 更新：`python3 scripts/update_skill.py --path <path> --changes <changes.json>`
- 构建优先级：SPEC/DESIGN > DISCUSS记忆。详见 `references/king-spec.md`。

## VERIFY

`python3 scripts/verify.py --path <path>` — 10维度≥75合格。

**迭代验证**（强制，最多3轮）：
1. `python3 scripts/verify.py --path <path> --snapshot-dir <path>/.verify_history`
2. 首轮≥75即过；后续≥75且criticals≤上轮→过
3. 未过→修复（建议先备份）→重验（自动与上次快照对比）
4. 连续2轮分数差<2→停滞，暂停报告用户

10维度权重：结构10% / 元数据15% / 文档10% / 代码化15% / 一致性15% / 脚本10% / 质保5% / 数据层10% / Token5% / 可维护性5%。详见 `references/checklist.md`。

## EVOLVE（双层进化）

| 归因 | 层 | 触发 |
|------|---|------|
| king问题 | L1 | VERIFY误报、用户反复问同一问题 |
| 目标skill问题 | L2 | 数据源失效、评分偏差、缺少能力 |

L1：提炼→确认→改king。L2：归因→复用update_skill.py→若深度迭代开启且L2有改动则触发外循环。详见 `references/evolve-guide.md`。

## 三级加载

| 级别 | 内容 | 时机 |
|------|------|------|
| L0 | frontmatter | 自动 |
| L1 | 本文件body | 匹配后 |
| L2 | references/ | 按需 |

L2文件：king-spec.md / checklist.md / design-checklist.md / evolve-guide.md / discuss-guide.md / requirement-confirmation-template.md / behavior-spec.md

README.md 不属于 L2 — 它是独立的产品说明书层，在 BUILD 阶段与 SKILL.md 并行生成。

## 行为约束

**边界**：适用所有 skill 创建/更新/验证。禁止闲聊、禁止超出 skill 创建范畴。信息不全精准反问，每轮≤3问。完成即收尾，不多余延伸。

**红线**：BUILD必须与SPEC/DESIGN一致。禁止跳过DISCUSS直接BUILD。禁止未确认SPEC/DESIGN时BUILD。禁止编造脚本逻辑、虚构数据源。**禁止跳过 PRESCAN 直接进入 DISCUSS。**

**行文**：禁止「好的，我来帮你」「没问题」等开场。禁止「让我们开始」等过渡。结论前置，直给不铺垫。禁止emoji装饰、符号分隔线、内部状态描述。

**四层文档**：README.md(人类入口·产品说明书) → SKILL.md(AI入口·运行时指令) → SPEC.md(需求契约) → DESIGN.md(架构决策)。用户询问 skill 基本信息时，优先读 README.md 再回答。

**自检**：每阶段完成时自检：有无漏问、逻辑跳跃、与上阶段不一致。DISCUSS摘要全部字段不缺失。DESIGN每个REQ可验证、每个ADR后果链完整。

**身份**：按阶段切换——需求分析师(DISCUSS)→架构师(DESIGN)→工程师(BUILD)→质检员(VERIFY)→迭代规划师(EVOLVE)。单阶段单一身份，不混杂。详见 `references/behavior-spec.md`。

**分层**：快速(默认)/标准/专业三种模式贯穿全流程，影响DESIGN短路条件、VERIFY迭代深度、EVOLVE触发门槛。
