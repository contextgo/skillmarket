#!/usr/bin/env python3
"""
update_skill.py — 增量更新已有 Skill
支持 6 种变更类型，自动同步 SPEC/DESIGN/CHANGELOG

用法：
    python3 update_skill.py --path <skill-path> --changes <changes.json>
"""

import argparse
import json
import re
import sys
from datetime import date
from pathlib import Path

# 添加 lib 目录到搜索路径
sys.path.insert(0, str(Path(__file__).parent))
from lib.yaml_parser import parse_frontmatter, get_field, frontmatter_contains, update_field


# ============================================================
# 版本号管理
# ============================================================

def parse_version(version_str: str) -> tuple:
    """解析版本号字符串为元组"""
    parts = version_str.strip('"').strip("'").split(".")
    return tuple(int(p) for p in parts)


def bump_version(version_str: str, bump_type: str) -> str:
    """版本号递增"""
    parts = list(parse_version(version_str))
    if bump_type == "major":
        parts[0] += 1
        parts[1] = 0
        parts[2] = 0
    elif bump_type == "minor":
        parts[1] += 1
        parts[2] = 0
    elif bump_type == "patch":
        parts[2] += 1
    return ".".join(str(p) for p in parts)


# ============================================================
# SKILL.md frontmatter 操作（使用 lib.yaml_parser）
# ============================================================

def update_version_in_skill_md(path: Path, new_version: str) -> bool:
    """更新 SKILL.md 中的版本号"""
    content = path.read_text(encoding="utf-8")
    content = re.sub(
        r'version:\s*["\']?[\d.]+["\']?',
        f'version: "{new_version}"',
        content
    )
    path.write_text(content, encoding="utf-8")
    return True


# ============================================================
# 变更处理器
# ============================================================

def handle_add_source(skill_path: Path, detail: dict) -> dict:
    """新增数据源"""
    sources_path = skill_path / "data" / "sources.yaml"
    if not sources_path.exists():
        return {"success": False, "error": "data/sources.yaml 不存在"}
    
    content = sources_path.read_text(encoding="utf-8")
    source_id = detail.get("source_id", "new_source")
    
    # 构建新的数据源条目
    new_entry = f"""
  {source_id}:
    primary:
      name: "{detail.get('primary', {}).get('name', '未命名')}"
      type: "{detail.get('primary', {}).get('type', 'api')}"
      url: "{detail.get('primary', {}).get('url', '')}"
      format: "{detail.get('primary', {}).get('format', 'json')}"
      pinned_at: "{date.today().isoformat()}"
"""
    if detail.get("fallback"):
        new_entry += f"""    fallback:
      name: "{detail['fallback'].get('name', '未命名')}"
      type: "{detail['fallback'].get('type', 'web_scrape')}"
      url: "{detail['fallback'].get('url', '')}"
      format: "{detail['fallback'].get('format', 'html')}"
      pinned_at: "{date.today().isoformat()}"
"""
    new_entry += f"""    forbidden: []
    cache_ttl: {detail.get('cache_ttl', 300)}
    update_trigger: "{detail.get('update_trigger', 'on_demand')}"
"""
    
    # 在 sources: 后插入
    content = content.replace("sources:\n", f"sources:\n{new_entry}")
    sources_path.write_text(content, encoding="utf-8")
    
    # 更新 SKILL.md data_sources（使用 lib.yaml_parser 精确判断）
    skill_md = skill_path / "SKILL.md"
    if skill_md.exists():
        md_content = skill_md.read_text(encoding="utf-8")
        if frontmatter_contains(md_content, "data_sources"):
            # data_sources 已存在，追加新 source_id
            current_sources = get_field(md_content, "data_sources")
            if isinstance(current_sources, list):
                current_sources.append(source_id)
            else:
                current_sources = [source_id]
            md_content = update_field(md_content, "data_sources", current_sources)
        else:
            # data_sources 不存在，在 frontmatter 中添加
            md_content = update_field(md_content, "data_sources", [source_id])
        skill_md.write_text(md_content, encoding="utf-8")
    
    return {"success": True, "source_id": source_id}


def handle_add_scene(skill_path: Path, detail: dict) -> dict:
    """新增场景（使用 lib.yaml_parser 精确操作 frontmatter）
    
    与 handle_add_source 保持一致：
    - 使用 frontmatter_contains() 精确判断
    - 使用 get_field() + update_field() 精确更新
    - 不会误修改正文中的 scenes: 字样
    """
    scene_name = detail.get("scene_name", "新场景")
    script_name = detail.get("script_name", "scene_new.py")
    
    # 创建场景脚本
    scripts_dir = skill_path / "scripts"
    scripts_dir.mkdir(parents=True, exist_ok=True)
    script_path = scripts_dir / script_name
    
    if not script_path.exists():
        template = f'''#!/usr/bin/env python3
"""{scene_name} — 评分脚本"""

import json
import sys
from pathlib import Path


def main():
    result = {{
        "success": True,
        "data": {{
            "scene": "{scene_name}",
            "message": "{scene_name}评分骨架，请替换为实际逻辑"
        }}
    }}
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
'''
        script_path.write_text(template, encoding="utf-8")
    
    # 更新 SKILL.md scenes 列表（使用 yaml_parser 精确操作）
    skill_md = skill_path / "SKILL.md"
    if skill_md.exists():
        content = skill_md.read_text(encoding="utf-8")
        
        if frontmatter_contains(content, "scenes"):
            # scenes 字段已存在，追加新场景
            current_scenes = get_field(content, "scenes")
            if isinstance(current_scenes, list):
                current_scenes.append(scene_name)
            elif isinstance(current_scenes, str):
                # 非标准：单值场景，转为列表并追加
                current_scenes = [current_scenes, scene_name]
            else:
                current_scenes = [scene_name]
            content = update_field(content, "scenes", current_scenes)
        else:
            # scenes 字段不存在，在 frontmatter 中新增
            content = update_field(content, "scenes", [scene_name])
        
        skill_md.write_text(content, encoding="utf-8")
    
    return {"success": True, "scene_name": scene_name, "script": script_name}


def handle_update_threshold(skill_path: Path, detail: dict) -> dict:
    """更新阈值"""
    config_path = skill_path / "config.yaml"
    if not config_path.exists():
        return {"success": False, "error": "config.yaml 不存在"}
    
    key = detail.get("key", "")
    old_value = detail.get("old_value", "")
    new_value = detail.get("new_value", "")
    
    content = config_path.read_text(encoding="utf-8")
    # 简易替换
    if str(old_value) in content:
        content = content.replace(str(old_value), str(new_value), 1)
        config_path.write_text(content, encoding="utf-8")
        return {"success": True, "key": key, "old": old_value, "new": new_value}
    
    return {"success": False, "error": f"未找到旧值: {old_value}"}


def _find_source_block_range(lines: list, source_id: str):
    """定位 sources.yaml 中指定 source_id 的行范围
    
    Returns:
        (start, end) 行索引（不含 end），未找到返回 None
        start: `  source_id:` 所在行
        end: 下一个同级 `  xxx:` 行或文件末尾
    """
    for i, line in enumerate(lines):
        if line.strip() == f"{source_id}:" and line.startswith("  "):
            start = i
            end = len(lines)
            for j in range(i + 1, len(lines)):
                # 同级块：2空格开头，但不4空格开头（排除子项）
                if lines[j].startswith("  ") and not lines[j].startswith("    ") and lines[j].strip():
                    end = j
                    break
                # 非空行且不缩进，说明已离开 sources: 区域
                if not lines[j].startswith("  ") and lines[j].strip():
                    end = j
                    break
            return (start, end)
    return None


def handle_deprecate_source(skill_path: Path, detail: dict) -> dict:
    """废弃数据源
    
    注释掉目标源块，并在该块内更新 forbidden 列表。
    使用行级定位而非全局字符串替换，避免多数据源时修改错误块。
    """
    sources_path = skill_path / "data" / "sources.yaml"
    if not sources_path.exists():
        return {"success": False, "error": "data/sources.yaml 不存在"}
    
    source_id = detail.get("source_id", "")
    reason = detail.get("reason", "")
    move_to_forbidden = detail.get("move_to_forbidden", True)
    
    content = sources_path.read_text(encoding="utf-8")
    lines = content.split("\n")
    
    # 定位目标源块
    block_range = _find_source_block_range(lines, source_id)
    
    if block_range is None:
        return {"success": False, "error": f"未找到数据源: {source_id}"}
    
    start, end = block_range
    
    # 第一步：如果需要移到 forbidden，先在原始块内替换 forbidden: []
    # 必须在注释之前操作，否则 forbidden: [] 已变成 # forbidden: [] 导致搜索失败
    if move_to_forbidden:
        forbidden_entry_lines = [
            "    forbidden:",
            f'      - name: "{source_id}"',
            f'        reason: "{reason}"',
        ]
        found_forbidden = False
        for i in range(start + 1, end):
            if "forbidden: []" in lines[i]:
                # 替换 forbidden: [] 为实际 forbidden 列表
                lines[i:i+1] = forbidden_entry_lines
                # 更新 end（插入3行替换1行，end+2）
                end += 2
                found_forbidden = True
                break
            elif "forbidden:" in lines[i] and not lines[i].strip().startswith("#"):
                # 已有 forbidden 列表，追加条目
                # 找到 forbidden 列表项的末尾
                insert_pos = i + 1
                while insert_pos < end and lines[insert_pos].startswith("        "):
                    insert_pos += 1
                lines.insert(insert_pos, f'      - name: "{source_id}"')
                lines.insert(insert_pos + 1, f'        reason: "{reason}"')
                end += 2
                found_forbidden = True
                break
        
        if not found_forbidden:
            # 源块内没有 forbidden 字段，在块末尾（end之前）追加
            for j, entry_line in enumerate(forbidden_entry_lines):
                lines.insert(end + j, entry_line)
            end += len(forbidden_entry_lines)
    
    # 第二步：注释掉源块（在 forbidden 已正确更新之后）
    new_lines = []
    for i, line in enumerate(lines):
        if i == start:
            new_lines.append(f"  # DEPRECATED ({reason}): {source_id}:")
        elif start < i < end:
            new_lines.append(f"  # {line.lstrip()}")
        else:
            new_lines.append(line)
    content = "\n".join(new_lines)
    sources_path.write_text(content, encoding="utf-8")
    
    return {"success": True, "source_id": source_id, "moved_to_forbidden": move_to_forbidden, "source_block_commented": True}


def handle_add_reference(skill_path: Path, detail: dict) -> dict:
    """新增参考文档"""
    refs_dir = skill_path / "references"
    refs_dir.mkdir(parents=True, exist_ok=True)
    
    filename = detail.get("filename", "new_reference.md")
    description = detail.get("description", "")
    
    ref_path = refs_dir / filename
    if not ref_path.exists():
        ref_path.write_text(f"# {filename.replace('.md', '').replace('_', ' ').title()}\n\n{description}\n", encoding="utf-8")
    
    return {"success": True, "filename": filename}


def handle_modify_script(skill_path: Path, detail: dict) -> dict:
    """记录脚本修改（实际修改由 AI 执行）"""
    script_name = detail.get("script_name", "")
    description = detail.get("description", "")
    
    return {"success": True, "script_name": script_name, "description": description, "note": "脚本修改需由 AI 手动执行"}


# ============================================================
# 文档同步
# ============================================================

def update_spec(skill_path: Path, changes: list, reason: str, new_version: str = ""):
    """更新 SPEC.md — 为每个变更添加需求条目"""
    spec_path = skill_path / "SPEC.md"
    if not spec_path.exists():
        return
    
    content = spec_path.read_text(encoding="utf-8")
    
    for change in changes:
        change_type = change.get("type", "")
        detail = change.get("detail", {})
        
        req_num = content.count("REQ-") + 1
        new_req = f"""
### REQ-{req_num:03d}: [{change_type}] {detail.get('source_id', detail.get('scene_name', detail.get('key', '更新')))}
- **描述**: {json.dumps(detail, ensure_ascii=False)}
- **优先级**: P1
- **验证标准**: 待定义
- **状态**: ✅已完成
"""
        if "## 非功能需求" in content:
            content = content.replace("## 非功能需求", new_req + "\n## 非功能需求")
        else:
            content += new_req
    
    # 更新版本历史（使用 new_version 替代硬编码）
    ver = new_version or "0.1.0"
    version_line = f"| V{ver} | {date.today().isoformat()} | 更新: {'; '.join(c.get('type', '') for c in changes)} |"
    if "## 版本历史" in content:
        # 在版本历史表格末尾追加
        parts = content.split("## 版本历史", 1)
        if len(parts) > 1:
            after_header = parts[1]
            # 找到表格结束位置（下一个 ## 标题或文件末尾）
            table_end = after_header.find("\n## ")
            if table_end != -1:
                content = parts[0] + "## 版本历史" + after_header[:table_end] + version_line + "\n" + after_header[table_end:]
            else:
                content += "\n" + version_line
    
    spec_path.write_text(content, encoding="utf-8")


def update_design(skill_path: Path, change_type: str, detail: dict, reason: str = "", new_version: str = ""):
    """更新 DESIGN.md — 新增 ADR + 版本历史"""
    design_path = skill_path / "DESIGN.md"
    if not design_path.exists():
        return
    
    content = design_path.read_text(encoding="utf-8")
    adr_num = content.count("ADR-") + 1
    
    new_adr = f"""
### ADR-{adr_num:03d}: [{change_type}] {detail.get('source_id', detail.get('scene_name', detail.get('key', '更新')))}
- **上下文**: {reason or f'执行 {change_type} 变更'}
- **选项**: A) 不变更 / B) 执行变更
- **决策**: 选 B — 执行变更
- **理由**: {reason or '用户确认的变更需求'}
- **后果**: {change_type} 已应用
- **状态**: ✅已采纳
"""
    
    if "## 模块关系" in content:
        content = content.replace("## 模块关系", new_adr + "\n## 模块关系")
    else:
        content += new_adr
    
    # 更新版本历史
    ver = new_version or "0.1.0"
    version_line = f"| V{ver} | {date.today().isoformat()} | 新增ADR: {change_type} |"
    if "## 版本历史" in content:
        parts = content.split("## 版本历史", 1)
        if len(parts) > 1:
            after_header = parts[1]
            table_end = after_header.find("\n## ")
            if table_end != -1:
                content = parts[0] + "## 版本历史" + after_header[:table_end] + version_line + "\n" + after_header[table_end:]
            else:
                content += "\n" + version_line
    
    design_path.write_text(content, encoding="utf-8")


def update_changelog(skill_path: Path, version: str, changes: list, reason: str = "", no_revert: bool = False):
    """更新 CHANGELOG.md"""
    changelog_path = skill_path / "CHANGELOG.md"
    if not changelog_path.exists():
        return
    
    content = changelog_path.read_text(encoding="utf-8")
    
    # 构建变更条目
    change_descriptions = []
    for c in changes:
        ct = c.get("type", "unknown")
        detail = c.get("detail", {})
        desc = f"  - {ct}: {json.dumps(detail, ensure_ascii=False)}"
        change_descriptions.append(desc)
    
    no_revert_marker = "❗ " if no_revert else ""
    reason_text = f"\n  - **原因**: {reason}" if reason else ""
    no_revert_text = "\n  - **勿回退**: 除非明确确认" if no_revert else ""
    
    new_entry = f"""
## [{version}] - {date.today().isoformat()}

### Changed
{no_revert_marker}{'; '.join(c.get('type', '') for c in changes)}{reason_text}{no_revert_text}
"""
    
    # 插入到文件开头（All notable changes 之后）
    if "All notable changes" in content:
        # 找到第二个 ## 标题
        parts = content.split("\n## ", 1)
        if len(parts) > 1:
            content = parts[0] + new_entry + "\n## " + parts[1]
        else:
            content += new_entry
    
    changelog_path.write_text(content, encoding="utf-8")


# ============================================================
# 主入口
# ============================================================

CHANGE_HANDLERS = {
    "add_source": handle_add_source,
    "add_scene": handle_add_scene,
    "update_threshold": handle_update_threshold,
    "deprecate_source": handle_deprecate_source,
    "add_reference": handle_add_reference,
    "modify_script": handle_modify_script,
}


def main():
    parser = argparse.ArgumentParser(description="增量更新已有 Skill")
    parser.add_argument("--path", required=True, help="目标 skill 的路径")
    parser.add_argument("--changes", required=True, help="变更描述 JSON 文件路径")
    
    args = parser.parse_args()
    
    skill_path = Path(args.path).resolve()
    changes_file = Path(args.changes).resolve()
    
    # 验证路径
    if not skill_path.exists():
        result = {"success": False, "error": f"路径不存在: {skill_path}"}
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(1)
    
    if not (skill_path / "SKILL.md").exists():
        result = {"success": False, "error": f"不是有效的 skill 目录: {skill_path}"}
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(1)
    
    # 读取变更
    if not changes_file.exists():
        result = {"success": False, "error": f"变更文件不存在: {changes_file}"}
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(1)
    
    with open(changes_file, "r", encoding="utf-8") as f:
        changes_data = json.load(f)
    
    changes = changes_data.get("changes", [])
    changelog_meta = changes_data.get("changelog_entry", {})
    
    if not changes:
        result = {"success": False, "error": "没有变更项"}
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(1)
    
    # 执行变更
    applied = []
    files_modified = set()
    
    for change in changes:
        change_type = change.get("type", "")
        detail = change.get("detail", {})
        
        handler = CHANGE_HANDLERS.get(change_type)
        if not handler:
            applied.append({"type": change_type, "success": False, "error": f"未知变更类型: {change_type}"})
            continue
        
        try:
            res = handler(skill_path, detail)
            applied.append({"type": change_type, **res})
            if res.get("success"):
                files_modified.add(change_type)
        except Exception as e:
            applied.append({"type": change_type, "success": False, "error": str(e)})
    
    # 计算新版本号（使用 lib.yaml_parser 精确获取）
    skill_md = skill_path / "SKILL.md"
    fm = parse_frontmatter(skill_md.read_text(encoding="utf-8"))
    old_version = str(fm.get("version", "0.1.0")).strip('"').strip("'")
    bump_type = changelog_meta.get("version_bump", "minor")
    new_version = bump_version(old_version, bump_type)
    
    # 更新版本号
    update_version_in_skill_md(skill_md, new_version)
    
    # 同步更新三文件（传入 new_version）
    reason = changelog_meta.get("reason", "")
    no_revert = changelog_meta.get("no_revert", False)
    
    update_spec(skill_path, changes, reason, new_version=new_version)
    
    # 逐个变更更新 DESIGN.md（ADR + 版本历史）
    for change in changes:
        update_design(skill_path, change.get("type", ""), change.get("detail", {}), reason, new_version=new_version)
    
    update_changelog(skill_path, new_version, changes, reason, no_revert)
    
    # 版本同步后自检：调用 prescan.py 确认版本一致性
    prescan_script = Path(__file__).parent / "prescan.py"
    if prescan_script.exists():
        try:
            import subprocess
            prescan_result = subprocess.run(
                [sys.executable, str(prescan_script), str(skill_path)],
                capture_output=True, text=True, timeout=15
            )
            prescan_output = json.loads(prescan_result.stdout) if prescan_result.stdout else {}
            prescan_issues = prescan_output.get("issues", [])
            version_issues = [i for i in prescan_issues if "[版本]" in i]
            if version_issues:
                result["warnings"] = result.get("warnings", [])
                result["warnings"].append(f"prescan 版本一致性告警: {'; '.join(version_issues)}")
        except (json.JSONDecodeError, subprocess.TimeoutExpired, FileNotFoundError) as e:
            pass  # prescan 失败不影响主流程
    
    # 更新 scripts/README.md
    scripts_readme = skill_path / "scripts" / "README.md"
    if scripts_readme.exists():
        # 简化处理：不修改，由 AI 手动更新
        pass
    
    result = {
        "success": True,
        "data": {
            "skill_name": skill_path.name,
            "version": new_version,
            "changes_applied": len([a for a in applied if a.get("success")]),
            "changes_failed": len([a for a in applied if not a.get("success")]),
            "details": applied,
            "files_modified": sorted(files_modified)
        }
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
