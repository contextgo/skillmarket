#!/usr/bin/env python3
"""Prescan: skill 修改前的文件完整性审计。

在修改某个 skill 之前执行，扫描其目录结构，检查：
- 标准文件是否存在
- 版本一致性
- 引用路径正确性

Usage:
    python3 scripts/prescan.py <skill-name>
    python3 scripts/prescan.py <skill-name> --json   (JSON 输出)

依赖：Python 标准库，零外部依赖。
"""

import json
import os
import re
import sys
from pathlib import Path

# ── 标准文件集 ─────────────────────────────────────────────────
REQUIRED_FILES = {
    "SKILL.md": "必选",
    "CHANGELOG.md": "必选",
}

RECOMMENDED_FILES = {
    "SPEC.md": "推荐",
    "DESIGN.md": "推荐",
}

OPTIONAL_DIRS = {
    "scripts/": "按需",
    "references/": "按需",
    "templates/": "按需",
    "tests/": "按需",
    "assets/": "按需",
}


def audit_skill(skill_name: str) -> dict:
    base = Path.home() / ".workbuddy" / "skills" / skill_name

    result = {
        "skill_name": skill_name,
        "exists": False,
        "files": [],
        "version_consistency": {},
        "issues": [],
    }

    if not base.exists() or not base.is_dir():
        result["issues"].append(f"skill 目录不存在: {base}")
        return result

    result["exists"] = True

    # ── 1. 扫描所有文件 ──
    all_files = sorted(base.rglob("*"))
    file_list = []
    for f in all_files:
        if f.is_file() and "__pycache__" not in f.parts:
            rel = str(f.relative_to(base))
            file_list.append(rel)
    result["files"] = file_list

    # ── 2. 检查标准文件 ──
    for fname, level in REQUIRED_FILES.items():
        path = base / fname
        status = "present" if path.exists() else "missing"
        if status == "missing":
            result["issues"].append(f"[{level}] 缺失: {fname}")

    for fname, level in RECOMMENDED_FILES.items():
        path = base / fname
        status = "present" if path.exists() else "missing"
        if status == "missing":
            result["issues"].append(f"[{level}] 缺失: {fname}")

    for dirname, level in OPTIONAL_DIRS.items():
        path = base / dirname
        if path.exists() and path.is_dir():
            count = len(list(path.rglob("*")))
            if count > 0:
                result["issues"].append(f"[{level}] {dirname} ({count} files)")

    # ── 3. 版本一致性 ──
    skill_version = None
    changelog_version = None
    spec_version = None
    design_version = None

    # SKILL.md → version 字段
    skill_path = base / "SKILL.md"
    if skill_path.exists():
        content = skill_path.read_text(encoding="utf-8")
        m = re.search(r'version:\s*["\']?([\d.]+)["\']?', content)
        if m:
            skill_version = m.group(1)

    # CHANGELOG → 最新版本号
    changelog_path = base / "CHANGELOG.md"
    if changelog_path.exists():
        content = changelog_path.read_text(encoding="utf-8")
        # 支持三种格式: ## [1.2.0], ## v1.2.0, ## 1.2.0
        m = re.search(r"##\s+\[?v?([\d.]+)\]?", content)
        if m:
            changelog_version = m.group(1)

    # helper: 从版本号列表中取最大版本（兼容表格的升序/降序排列）
    def newest_version(versions):
        return max(versions, key=lambda v: tuple(map(int, v.split("."))))

    # SPEC.md → 版本
    #   优先级1: 版本历史表格（| V1.0.0 | date | ...）
    #   优先级2: header 行（> 版本：v1.0.0）
    spec_path = base / "SPEC.md"
    if spec_path.exists():
        content = spec_path.read_text(encoding="utf-8")
        versions = re.findall(r"\|\s*V?(\d+\.\d+\.\d+)\s*\|", content)
        if versions:
            spec_version = newest_version(versions)
        else:
            m = re.search(r">\s*版本：\s*v?(\d+\.\d+\.\d+)", content)
            if m:
                spec_version = m.group(1)

    # DESIGN.md → 版本（同 SPEC 逻辑）
    design_path = base / "DESIGN.md"
    if design_path.exists():
        content = design_path.read_text(encoding="utf-8")
        versions = re.findall(r"\|\s*V?(\d+\.\d+\.\d+)\s*\|", content)
        if versions:
            design_version = newest_version(versions)
        else:
            m = re.search(r">\s*版本：\s*v?(\d+\.\d+\.\d+)", content)
            if m:
                design_version = m.group(1)

    versions = {
        "SKILL.md": skill_version,
        "CHANGELOG": changelog_version,
        "SPEC.md": spec_version,
        "DESIGN.md": design_version,
    }
    result["version_consistency"] = versions

    # 比对：以 SKILL.md 为基准
    base_ver = skill_version
    for name, ver in versions.items():
        if ver is None:
            result["issues"].append(f"[版本] {name}: 无版本信息")
        elif base_ver and ver != base_ver:
            result["issues"].append(
                f"[版本] {name} v{ver} ≠ SKILL.md v{base_ver}"
            )

    # ── 4. 引用路径正确性（SKILL.md 中引用的脚本/模板路径） ──
    if skill_path.exists():
        content = skill_path.read_text(encoding="utf-8")
        # 找到所有 python3 scripts/xxx.py 之类的引用
        refs = re.findall(
            r"python3\s+([\w./~]+/(scripts|templates)/[\w./]+\.\w+)",
            content,
        )
        for ref, _ in refs:
            # 处理 ~/ 和相对路径
            resolved = ref.replace("~", str(Path.home()))
            if not resolved.startswith("/"):
                resolved = str(base / resolved)
            if not Path(resolved).exists():
                result["issues"].append(f"[引用] 路径不存在: {ref}")

    return result


def format_report(data: dict) -> str:
    if not data["exists"]:
        return f"❌ skill 目录不存在: {data['skill_name']}"

    lines = []
    lines.append(f"📋 {data['skill_name']} 文件清单 ({len(data['files'])} 个)")
    lines.append("")

    # 标准文件状态
    for fname in REQUIRED_FILES:
        if fname in data["files"]:
            lines.append(f"  ✅ {fname}  (必选)")
        else:
            lines.append(f"  ❌ {fname}  (必选 — 缺失)")

    for fname in RECOMMENDED_FILES:
        if fname in data["files"]:
            lines.append(f"  ✅ {fname}  (推荐)")
        else:
            lines.append(f"  ⚪ {fname}  (推荐 — 缺失)")

    lines.append("")
    lines.append(f"版本一致性 (基准: SKILL.md v{data['version_consistency'].get('SKILL.md', '?')})")
    for name, ver in data["version_consistency"].items():
        if ver:
            lines.append(f"  {name}: v{ver}")
        else:
            lines.append(f"  {name}: 无版本信息")

    issues = [i for i in data["issues"] if "(" not in i or not i.endswith("files)")]
    if issues:
        lines.append("")
        lines.append(f"⚠️ 发现 {len(issues)} 个问题:")
        for issue in issues:
            lines.append(f"  {issue}")
    else:
        lines.append("")
        lines.append("✅ 无异常")

    return "\n".join(lines)


def main():
    if len(sys.argv) < 2:
        print("Usage: python3 prescan.py <skill-name> [--json]", file=sys.stderr)
        sys.exit(1)

    skill_name = sys.argv[1]
    use_json = "--json" in sys.argv

    data = audit_skill(skill_name)

    if use_json:
        print(json.dumps(data, ensure_ascii=False, indent=2))
    else:
        print(format_report(data))

    # exit code: 0 = 全部正常，1 = 有问题
    if data["exists"] and len([i for i in data["issues"] if "缺失" in i or "版本" in i]) > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
