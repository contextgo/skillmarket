# Scripts — 接口文档

skill-creator-king 的核心脚本，负责创建、更新、验证和打包 skill。

## 通用约定

- 所有脚本使用 Python 3 标准库，无外部依赖
- 输出格式为 JSON，`success` 字段表示执行结果
- 错误信息在 `error` 字段中返回
- 所有路径参数支持绝对路径和相对路径

## init_skill.py — 创建新 Skill

初始化一个新 skill 的完整目录结构和骨架文件。

```bash
python3 init_skill.py --name <skill-name> --template <basic|data-driven|multi-scene> [--dest <path>]
```

| 参数 | 必需 | 说明 |
|------|------|------|
| `--name` | ✅ | Skill 名称（小写+连字符，如 my-skill） |
| `--template` | ✅ | 模板类型：basic / data-driven / multi-scene |
| `--dest` | ❌ | 目标路径（默认：~/.workbuddy/skills/<name>） |

**输出**：

```json
{
  "success": true,
  "data": {
    "skill_name": "my-skill",
    "template": "data-driven",
    "path": "/path/to/my-skill",
    "files_created": ["SKILL.md", "SPEC.md", "CHANGELOG.md", "config.yaml", "data/sources.yaml", ...]
  }
}
```

## update_skill.py — 更新已有 Skill

对已有 skill 做增量更新，自动同步 SPEC/DESIGN/CHANGELOG。

```bash
python3 update_skill.py --path <skill-path> --changes <changes.json>
```

| 参数 | 必需 | 说明 |
|------|------|------|
| `--path` | ✅ | 目标 skill 的路径 |
| `--changes` | ✅ | 变更描述 JSON 文件路径 |

**变更类型**：

| type | 说明 | detail 必需字段 |
|------|------|----------------|
| `add_source` | 新增数据源 | source_id, primary |
| `add_scene` | 新增场景 | scene_name, script_name |
| `update_threshold` | 更新阈值 | key, old_value, new_value |
| `deprecate_source` | 废弃数据源 | source_id, reason |
| `add_reference` | 新增参考文档 | filename, description |
| `modify_script` | 修改脚本 | script_name, description |

**输出**：

```json
{
  "success": true,
  "data": {
    "skill_name": "my-skill",
    "changes_applied": 3,
    "files_modified": ["data/sources.yaml", "SPEC.md", "CHANGELOG.md"],
    "version": "1.1.0"
  }
}
```

## verify.py — 质量验证

10 维度质量验证。

```bash
python3 verify.py --path <skill-path> [--template <type>] [--action <verify|analyze>]
```

| 参数 | 必需 | 说明 |
|------|------|------|
| `--path` | ✅ | 目标 skill 的路径 |
| `--template` | ❌ | 模板类型（影响检查项，自动检测） |
| `--action` | ❌ | verify（默认）或 analyze |

**10 维度评分体系**：

| # | 维度 | 权重 |
|---|------|------|
| 1 | 结构规范 | 10% |
| 2 | 元数据完整 | 15% |
| 3 | 文档有效性 | 10% |
| 4 | 代码化优化 | 15% |
| 5 | 一致性校验 | 15% |
| 6 | 脚本规范 | 10% |
| 7 | 质量保障 | 5% |
| 8 | 数据层规范 | 10% |
| 9 | Token效率 | 5% |
| 10 | 可维护性 | 5% |

**评分标准**：≥90 优秀，≥75 合格，≥60 需改进，<60 不合格

## package_skill.py — 打包 Skill

将 skill 目录打包为可分享的压缩包。

```bash
python3 package_skill.py --path <skill-path> [--output <output-path>]
```
