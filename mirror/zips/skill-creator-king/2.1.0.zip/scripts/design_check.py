#!/usr/bin/env python3
"""
design_check.py — DESIGN 阶段客观语义检查

检查项（dd/ms 模板）：
  D1: REQ-ADR 对齐 — 每个 REQ 在 DESIGN 中有 ADR 支撑
  D2: ADR 互斥 — ADR 之间有无显式矛盾
  D3: 需求覆盖 — DISCUSS 提到的要点在 SPEC 中有对应 REQ
  D4: 模板选择一致性 — 有数据源但选了 basic？多场景但选了 data-driven？
  D5: 可构建性 — 无 TBD/TODO 占位符，ADR 选项具体可执行

basic 模板只检查 SKILL.md frontmatter 合理性（triggers 非空、token_budget 完整）。

用法：
    python3 design_check.py --path <skill-path>
"""

import argparse
import json
import re
import sys
from pathlib import Path

# 添加 lib 目录到搜索路径
sys.path.insert(0, str(Path(__file__).parent))
from lib.yaml_parser import parse_frontmatter, detect_template


# ============================================================
# Basic 模板检查
# ============================================================

def check_basic_frontmatter(skill_path: Path) -> dict:
    """basic 模板只检查 SKILL.md frontmatter 合理性"""
    findings = []
    score = 100

    skill_md = skill_path / "SKILL.md"
    if not skill_md.exists():
        return {"score": 0, "findings": [{"severity": "critical", "message": "SKILL.md 不存在"}]}

    try:
        fm = parse_frontmatter(skill_md.read_text(encoding="utf-8"))
    except Exception as e:
        return {"score": 0, "findings": [{"severity": "critical", "message": f"frontmatter 解析失败: {e}"}]}

    # triggers 非空
    triggers = fm.get("triggers")
    if not isinstance(triggers, list) or len(triggers) == 0:
        findings.append({"severity": "critical", "message": "frontmatter triggers 为空或缺失"})
        score -= 20

    # token_budget 完整
    budget = fm.get("token_budget")
    if not isinstance(budget, dict):
        findings.append({"severity": "critical", "message": "frontmatter token_budget 缺失或格式错误"})
        score -= 20
    else:
        budget_fields = ["L0_trigger", "L1_core", "L2_deep", "hard_cap"]
        for bf in budget_fields:
            if bf not in budget:
                findings.append({"severity": "warning", "message": f"token_budget 缺少: {bf}"})
                score -= 5

    # version 存在
    if "version" not in fm:
        findings.append({"severity": "warning", "message": "frontmatter 缺少 version"})
        score -= 5

    # description 存在
    if "description" not in fm or not fm["description"].strip():
        findings.append({"severity": "warning", "message": "frontmatter description 为空或缺失"})
        score -= 5

    return {"score": max(0, score), "findings": findings}


# ============================================================
# D1: REQ-ADR 对齐
# ============================================================

def check_req_adr_alignment(skill_path: Path) -> dict:
    """每个 REQ 在 DESIGN 中应有 ADR 支撑其技术选择"""
    findings = []
    score = 100

    spec = skill_path / "SPEC.md"
    design = skill_path / "DESIGN.md"

    if not spec.exists():
        return {"score": 0, "findings": [{"severity": "critical", "message": "SPEC.md 不存在，无法检查 REQ-ADR 对齐"}]}
    if not design.exists():
        return {"score": 0, "findings": [{"severity": "critical", "message": "DESIGN.md 不存在，无法检查 REQ-ADR 对齐"}]}

    spec_content = spec.read_text(encoding="utf-8")
    design_content = design.read_text(encoding="utf-8")

    # 提取 REQ-xxx 编号
    req_ids = re.findall(r'REQ-(\d+)', spec_content)

    # 提取 ADR-xxx 编号
    adr_ids = re.findall(r'ADR-(\d+)', design_content)

    if not req_ids:
        findings.append({"severity": "warning", "message": "SPEC.md 中没有 REQ-xxx 条目"})
        score -= 15

    if not adr_ids:
        findings.append({"severity": "warning", "message": "DESIGN.md 中没有 ADR-xxx 条目"})
        score -= 15

    # 检查 REQ 是否在 DESIGN 中被提及
    unreferenced_reqs = []
    for req_id in set(req_ids):
        req_tag = f"REQ-{req_id}"
        if req_tag not in design_content:
            unreferenced_reqs.append(req_tag)

    if unreferenced_reqs:
        findings.append({
            "severity": "warning",
            "message": f"以下 REQ 在 DESIGN.md 中未被引用: {', '.join(unreferenced_reqs[:10])}"
        })
        score -= 5 * min(len(unreferenced_reqs), 5)

    return {"score": max(0, score), "findings": findings}


# ============================================================
# D2: ADR 互斥检测
# ============================================================

def check_adr_conflicts(skill_path: Path) -> dict:
    """检测 ADR 之间的显式矛盾"""
    findings = []
    score = 100

    design = skill_path / "DESIGN.md"
    if not design.exists():
        return {"score": 0, "findings": [{"severity": "critical", "message": "DESIGN.md 不存在"}]}

    design_content = design.read_text(encoding="utf-8")

    # 提取所有 ADR 块
    adr_blocks = re.findall(
        r'### ADR-\d+:.*?(?=### ADR-\d+:|## \w|$)',
        design_content, re.DOTALL
    )

    if len(adr_blocks) < 2:
        return {"score": 100, "findings": []}

    # 从每个 ADR 中提取决策关键词和上下文
    adr_decisions = {}
    
    # 上下文感知的冲突对：只有同一决策维度上的对立选项才判为矛盾
    # 格式：(维度, 选项A, 选项B) — 同一维度内互斥
    dimension_conflicts = [
        ("架构模式", "独立", "整合"),
        ("约束类型", "硬约束", "软约束"),
        ("数据管理", "硬编码", "声明式"),
        ("数据源类型", "API", "web_scrape"),
    ]

    for block in adr_blocks:
        adr_match = re.match(r'### (ADR-\d+)', block)
        if not adr_match:
            continue
        adr_id = adr_match.group(1)
        
        # 提取 ADR 标题（主题）
        title_match = re.match(r'### ADR-\d+:\s*(.+)', block)
        title = title_match.group(1).strip() if title_match else ""
        
        # 提取"决策"行
        decision_match = re.search(r'\*?\*?决策\*?\*?:\s*选?\s*([A-C])\s*[—\-]', block)
        if decision_match:
            option = decision_match.group(1)
            # 提取关键词及其上下文维度
            keywords = {}
            keyword_dimension_map = {
                "API": "数据源类型", "web_scrape": "数据源类型",
                "硬约束": "约束类型", "软约束": "约束类型",
                "硬编码": "数据管理", "声明式": "数据管理",
                "独立": "架构模式", "整合": "架构模式",
            }
            for keyword, dimension in keyword_dimension_map.items():
                # 关键词必须在"决策"行本身出现
                # 决策行格式如：- **决策**: 选 B — 独立 EVOLVE 阶段
                # 只匹配决策行中选定的那个选项关键词
                if decision_match and keyword in decision_match.group(0):
                    keywords[keyword] = dimension
            adr_decisions[adr_id] = {"option": option, "keywords": keywords, "title": title}

    # 检查矛盾（同一维度内的对立选项才判为矛盾）
    adr_ids = list(adr_decisions.keys())
    for i in range(len(adr_ids)):
        for j in range(i + 1, len(adr_ids)):
            k1 = adr_decisions[adr_ids[i]]["keywords"]
            k2 = adr_decisions[adr_ids[j]]["keywords"]
            for kw1, dim1 in k1.items():
                for kw2, dim2 in k2.items():
                    if dim1 == dim2 and kw1 != kw2:
                        # 同一维度内的不同选项，检查是否为冲突对
                        for dimension, opt_a, opt_b in dimension_conflicts:
                            if (kw1 == opt_a and kw2 == opt_b) or (kw1 == opt_b and kw2 == opt_a):
                                findings.append({
                                    "severity": "warning",
                                    "message": f"{adr_ids[i]} 选择 {kw1} 与 {adr_ids[j]} 选择 {kw2} 在'{dimension}'维度可能矛盾"
                                })
                                score -= 10

    return {"score": max(0, score), "findings": findings}


# ============================================================
# D3: 需求覆盖
# ============================================================

def check_requirement_coverage(skill_path: Path) -> dict:
    """DISCUSS 提到的要点在 SPEC 中应有对应 REQ"""
    findings = []
    score = 100

    spec = skill_path / "SPEC.md"
    if not spec.exists():
        return {"score": 0, "findings": [{"severity": "critical", "message": "SPEC.md 不存在"}]}

    spec_content = spec.read_text(encoding="utf-8")

    # 检查 SPEC 是否有核心需求章节
    if "核心需求" not in spec_content and "## 核心需求" not in spec_content:
        findings.append({"severity": "warning", "message": "SPEC.md 缺少核心需求章节"})
        score -= 15

    # 检查每个 REQ 是否有完整字段
    req_blocks = re.findall(
        r'### REQ-\d+:.*?(?=### REQ-\d+:|## \w|$)',
        spec_content, re.DOTALL
    )

    for block in req_blocks:
        req_id_match = re.match(r'### (REQ-\d+)', block)
        if not req_id_match:
            continue
        req_id = req_id_match.group(1)

        # 检查关键字段
        missing_fields = []
        for field in ["描述", "优先级", "验证标准"]:
            if f"**{field}**" not in block and f"{field}:" not in block and f"{field}：" not in block:
                missing_fields.append(field)

        if missing_fields:
            findings.append({
                "severity": "info",
                "message": f"{req_id} 缺少字段: {', '.join(missing_fields)}"
            })
            score -= 3

    # 检查是否有"已完成"和"待实现"的混合状态
    completed = len(re.findall(r'✅已完成', spec_content))
    pending = len(re.findall(r'🟡待实现', spec_content))
    if completed > 0 and pending > 0:
        findings.append({
            "severity": "info",
            "message": f"SPEC 中有 {completed} 个已完成、{pending} 个待实现的 REQ，注意增量更新"
        })

    return {"score": max(0, score), "findings": findings}


# ============================================================
# D4: 模板选择一致性
# ============================================================

def check_template_consistency(skill_path: Path) -> dict:
    """检查模板选择是否合理"""
    findings = []
    score = 100

    template = detect_template(skill_path)

    # 检查：有数据源但选了 basic？
    has_sources = (skill_path / "data" / "sources.yaml").exists()
    skill_md = skill_path / "SKILL.md"
    has_data_sources_fm = False
    if skill_md.exists():
        try:
            fm = parse_frontmatter(skill_md.read_text(encoding="utf-8"))
            has_data_sources_fm = "data_sources" in fm and fm["data_sources"]
        except Exception:
            pass

    if template == "basic" and (has_sources or has_data_sources_fm):
        findings.append({
            "severity": "warning",
            "message": "检测到数据源但模板为 basic，建议使用 data-driven 或 multi-scene"
        })
        score -= 20

    # 检查：多场景但选了 data-driven？
    # 注意：data-driven 也可能有 DESIGN.md（P0/P1 架构决策时），不一定是多场景信号
    has_scenes_fm = False
    if skill_md.exists():
        try:
            fm = parse_frontmatter(skill_md.read_text(encoding="utf-8"))
            has_scenes_fm = "scenes" in fm and fm["scenes"]
        except Exception:
            pass

    if template == "data-driven" and has_scenes_fm:
        findings.append({
            "severity": "warning",
            "message": "检测到多场景信号(frontmatter scenes)但模板为 data-driven，建议使用 multi-scene"
        })
        score -= 20

    # 检查：multi-scene 但无 DESIGN.md
    if template == "multi-scene" and not has_design:
        findings.append({
            "severity": "warning",
            "message": "multi-scene 模板应有 DESIGN.md（ADR 决策记录）"
        })
        score -= 10

    return {"score": max(0, score), "findings": findings}


# ============================================================
# D5: 可构建性
# ============================================================

def check_buildability(skill_path: Path) -> dict:
    """检查 SPEC/DESIGN 中是否有 TBD/TODO 占位符"""
    findings = []
    score = 100

    for doc_name in ["SPEC.md", "DESIGN.md"]:
        doc = skill_path / doc_name
        if not doc.exists():
            continue

        content = doc.read_text(encoding="utf-8")

        # 检查 TBD/TODO
        tbd_lines = []
        for i, line in enumerate(content.split("\n"), 1):
            if re.search(r'\b(TBD|TODO|FIXME|XXX|HACK)\b', line, re.IGNORECASE):
                tbd_lines.append(f"L{i}: {line.strip()[:80]}")

        if tbd_lines:
            findings.append({
                "severity": "warning",
                "message": f"{doc_name} 有 {len(tbd_lines)} 处 TBD/TODO 占位符: {tbd_lines[0]}{'...' if len(tbd_lines) > 1 else ''}"
            })
            score -= 5 * min(len(tbd_lines), 5)

        # 检查 REQ 验证标准是否具体（非空且非占位符）
        if doc_name == "SPEC.md":
            req_blocks = re.findall(
                r'### REQ-\d+:.*?(?=### REQ-\d+:|## \w|$)',
                content, re.DOTALL
            )
            vague_standards = 0
            for block in req_blocks:
                # 检查验证标准是否含"验证通过"这种模糊描述
                std_match = re.search(r'\*?\*?验证标准\*?\*?:\s*(.+)', block)
                if std_match:
                    std_text = std_match.group(1).strip()
                    if len(std_text) < 10 or "验证通过" in std_text or "正常运行" in std_text:
                        vague_standards += 1

            if vague_standards > 0:
                findings.append({
                    "severity": "info",
                    "message": f"SPEC.md 有 {vague_standards} 个 REQ 的验证标准过于模糊"
                })
                score -= 3 * min(vague_standards, 5)

    return {"score": max(0, score), "findings": findings}


# ============================================================
# 主入口
# ============================================================

CHECK_FUNCS_DD_MS = [
    ("D1_req_adr_alignment", "REQ-ADR对齐", check_req_adr_alignment),
    ("D2_adr_conflicts", "ADR互斥检测", check_adr_conflicts),
    ("D3_requirement_coverage", "需求覆盖", check_requirement_coverage),
    ("D4_template_consistency", "模板选择一致性", check_template_consistency),
    ("D5_buildability", "可构建性", check_buildability),
]


def main():
    parser = argparse.ArgumentParser(description="DESIGN 阶段客观语义检查")
    parser.add_argument("--path", required=True, help="目标 skill 的路径")

    args = parser.parse_args()

    skill_path = Path(args.path).resolve()

    if not skill_path.exists():
        result = {"success": False, "error": f"路径不存在: {skill_path}"}
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(1)

    template = detect_template(skill_path)

    # basic 模板：只检查 frontmatter
    if template == "basic":
        res = check_basic_frontmatter(skill_path)
        result = {
            "success": True,
            "data": {
                "skill_name": skill_path.name,
                "template": template,
                "mode": "basic_frontmatter_only",
                "overall_score": res["score"],
                "pass": res["score"] >= 75,
                "can_shortcut": res["score"] >= 75,
                "checks": [{
                    "name": "frontmatter合理性",
                    "id": "basic_frontmatter",
                    "score": res["score"],
                    "findings": res["findings"]
                }]
            }
        }
    else:
        # dd/ms 模板：5 项语义检查
        checks = []
        total_score = 0

        for check_id, check_name, check_func in CHECK_FUNCS_DD_MS:
            try:
                res = check_func(skill_path)
            except Exception as e:
                res = {"score": 0, "findings": [{"severity": "critical", "message": f"检查异常: {str(e)}"}]}

            checks.append({
                "name": check_name,
                "id": check_id,
                "score": res["score"],
                "findings": res["findings"]
            })
            total_score += res["score"]

        # 等权平均
        overall_score = round(total_score / len(CHECK_FUNCS_DD_MS))

        # 汇总 critical 数量
        critical_count = sum(
            1 for c in checks for f in c["findings"] if f["severity"] == "critical"
        )

        result = {
            "success": True,
            "data": {
                "skill_name": skill_path.name,
                "template": template,
                "mode": "semantic_checks",
                "overall_score": overall_score,
                "pass": overall_score >= 75 and critical_count == 0,
                "can_shortcut": overall_score >= 75 and critical_count == 0,
                "critical_count": critical_count,
                "checks": checks,
                "next_step": "客观检查全过 → 可进入主观自检（design-checklist.md）" if overall_score >= 75 else "请修正上述问题后重新运行 design_check.py"
            }
        }

    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
