#!/usr/bin/env python3
"""
package_skill.py — 打包 Skill 为可分享的压缩包

用法：
    python3 package_skill.py --path <skill-path> [--output <output-path>]
"""

import argparse
import json
import shutil
import sys
import tempfile
from pathlib import Path


# 排除的文件/目录
EXCLUDE_PATTERNS = {
    "__pycache__",
    ".DS_Store",
    "*.pyc",
    ".git",
    "node_modules",
    ".gitkeep",        # 占位文件无实际用途
    "data/cache",      # 缓存不应打包分发
    ".verify_history", # 验证迭代快照不应打包分发
}


def should_exclude(path: Path, skill_path: Path) -> bool:
    """检查文件是否应该排除
    
    Args:
        path: 待检查的文件/目录路径
        skill_path: skill 根目录路径（用于计算相对路径）
    """
    name = path.name
    try:
        rel_path = str(path.relative_to(skill_path))
    except ValueError:
        rel_path = name
    
    for pattern in EXCLUDE_PATTERNS:
        if pattern.startswith("*"):
            # 通配符模式：匹配文件名后缀
            if name.endswith(pattern[1:]):
                return True
        elif "/" in pattern:
            # 路径模式：匹配相对路径的前缀或包含
            if rel_path.startswith(pattern) or pattern in rel_path:
                return True
            # 也检查路径组件是否以该模式开头
            if any(part == pattern.split("/")[0] for part in Path(rel_path).parts):
                # 更精确：匹配完整路径段
                path_parts = Path(rel_path).parts
                pattern_parts = tuple(pattern.split("/"))
                for i in range(len(path_parts) - len(pattern_parts) + 1):
                    if path_parts[i:i+len(pattern_parts)] == pattern_parts:
                        return True
        elif name == pattern:
            return True
    return False


def package_skill(skill_path: Path, output_path: Path = None) -> dict:
    """打包 skill 目录"""
    if not skill_path.exists():
        return {"success": False, "error": f"路径不存在: {skill_path}"}
    
    if not (skill_path / "SKILL.md").exists():
        return {"success": False, "error": f"不是有效的 skill 目录: {skill_path}"}
    
    # 确定输出路径
    if output_path is None:
        output_path = skill_path.parent / f"{skill_path.name}.zip"
    
    # 创建临时目录
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_skill = Path(tmp_dir) / skill_path.name
        
        # 复制文件（排除不需要的）
        for item in skill_path.rglob("*"):
            if should_exclude(item, skill_path):
                continue
            rel = item.relative_to(skill_path)
            dest = tmp_skill / rel
            if item.is_dir():
                dest.mkdir(parents=True, exist_ok=True)
            else:
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(item, dest)
        
        # 打包
        shutil.make_archive(str(output_path.with_suffix("")), "zip", tmp_dir, skill_path.name)
    
    # 获取打包大小
    zip_size = output_path.stat().st_size if output_path.exists() else 0
    
    return {
        "success": True,
        "data": {
            "skill_name": skill_path.name,
            "output_path": str(output_path),
            "size_bytes": zip_size,
            "size_human": f"{zip_size / 1024:.1f} KB" if zip_size > 1024 else f"{zip_size} B"
        }
    }


def main():
    parser = argparse.ArgumentParser(description="打包 Skill")
    parser.add_argument("--path", required=True, help="Skill 目录路径")
    parser.add_argument("--output", help="输出路径（默认：<skill-name>.zip）")
    
    args = parser.parse_args()
    
    skill_path = Path(args.path).resolve()
    output_path = Path(args.output) if args.output else None
    
    try:
        result = package_skill(skill_path, output_path)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        
        if not result["success"]:
            sys.exit(1)
    except Exception as e:
        error_result = {"success": False, "error": f"打包失败: {str(e)}"}
        print(json.dumps(error_result, ensure_ascii=False, indent=2))
        sys.exit(1)


if __name__ == "__main__":
    main()
