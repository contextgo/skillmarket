#!/usr/bin/env python3
"""
init_skill.py — 创建新 Skill 骨架
支持三种模板：basic / data-driven / multi-scene

用法：
    python3 init_skill.py --name <skill-name> --template <basic|data-driven|multi-scene> [--dest <path>]
"""

import argparse
import json
import os
import sys
from datetime import date
from pathlib import Path


# ============================================================
# README 模板（V2.0 新增 — 产品说明书层）
# ============================================================

def get_readme_basic(name: str) -> str:
    return f"""# {name}

## 一句话
[这个 skill 解决什么问题，一行说清]

## 什么时候用
[在什么场景下触发这个 skill]

## 怎么用
[最小可用的使用示例]

## 设计理念
[核心取舍，如"宁可漏判不可误判"或"先跑通再优化"]

## 怎么解决
[简要技术路径，不深入实现细节]
"""


def get_readme_data_driven(name: str) -> str:
    return f"""# {name}

## 一句话
[这个 skill 解决什么问题，一行说清]

## 什么时候用
[在什么场景下触发这个 skill]

## 怎么用
[最小可用的使用示例]

## 设计理念
[核心取舍，如"宁可漏判不可误判"或"先跑通再优化"]

## 怎么解决
[简要技术路径，不深入实现细节]

## 数据来源
- **主源**: [数据源名称和类型]
- **备源**: [备选数据源]
- **更新频率**: [实时/每日/每周/按需]
"""


def get_readme_multi_scene(name: str, scenes: list = None, no_data: bool = False) -> str:
    if scenes is None:
        scenes = ["场景一", "场景二"]
    scene_rows = "\n".join(f"| {s} | [描述] |" for s in scenes)
    data_section = ""
    if not no_data:
        data_section = """
## 数据来源
- **主源**: [数据源名称和类型]
- **备源**: [备选数据源]
- **更新频率**: [实时/每日/每周/按需]
"""
    return f"""# {name}

## 一句话
[这个 skill 解决什么问题，一行说清]

## 什么时候用
[在什么场景下触发这个 skill]

## 怎么用
[最小可用的使用示例]

## 设计理念
[核心取舍，如"宁可漏判不可误判"或"先跑通再优化"]

## 工作流程
| 场景 | 说明 |
|------|------|
{scene_rows}

## 怎么解决
[简要技术路径，不深入实现细节]
{data_section}
"""


# ============================================================
# 模板内容定义
# ============================================================

def get_skill_md_basic(name: str) -> str:
    return f"""---
name: {name}
version: "0.1.0"
description: |
  [在此填写 skill 描述和触发词]
triggers:
  - [触发词1]
  - [触发词2]
token_budget:
  L0_trigger: 100
  L1_core: 600
  L2_deep: 2000
  hard_cap: 3000
---

# {name}

## 功能说明

[在此描述核心功能，保持精简]

## 使用方式

[在此描述使用方式]

## 行为约束

收到与职责无关的请求，告知范围并停止。
数据不确定时标注「数据不足」，禁止编造。
结论前置，不铺垫。
回答完毕即收尾，不延伸。

## 三级加载

| 级别 | 内容 | 何时加载 |
|------|------|---------|
| L0 | frontmatter（触发匹配） | 自动 |
| L1 | 本文件 body（核心流程） | 匹配后 |
| L2 | references/（深度参考） | 按需 |
"""


def get_skill_md_data_driven(name: str) -> str:
    return f"""---
name: {name}
version: "0.1.0"
description: |
  [在此填写 skill 描述和触发词]
triggers:
  - [触发词1]
  - [触发词2]
token_budget:
  L0_trigger: 100
  L1_core: 800
  L2_deep: 3000
  hard_cap: 4000
data_sources:
  - [source_id_1]
  - [source_id_2]
---

# {name}

## 功能说明

[在此描述核心功能，保持精简]

## 数据源

读取 `data/sources.yaml` 获取数据源配置。主源失败自动降级到备源。

## 使用方式

[在此描述使用方式，引用 scripts/ 中的脚本]

## 脚本说明

| 脚本 | 用途 |
|------|------|
| scripts/main.py | 主逻辑 |
| scripts/refresh_cache.py | 刷新缓存 |

## 行为约束

收到与职责无关的请求，告知范围并停止。
数据不确定时标注「数据不足」，禁止编造。
结论前置，不铺垫。
回答完毕即收尾，不延伸。

## 三级加载

| 级别 | 内容 | 何时加载 |
|------|------|---------|
| L0 | frontmatter（触发匹配） | 自动 |
| L1 | 本文件 body（核心流程+数据源路由） | 匹配后 |
| L2 | references/（完整文档、数据源详情） | 按需 |
"""


def get_skill_md_multi_scene(name: str, scenes: list = None, no_data: bool = False) -> str:
    if scenes is None:
        scenes = ["场景一", "场景二"]
    scene_rows = "\n".join(
        f"| {s} | scripts/scene_{chr(97+i)}.py | [入口条件{i+1}] |"
        for i, s in enumerate(scenes)
    )
    
    # 根据是否有数据源生成不同 frontmatter
    data_sources_fm = ""
    data_section = ""
    if not no_data:
        data_sources_fm = """data_sources:
  - [source_id_1]
  - [source_id_2]
"""
        data_section = """
## 数据源

读取 `data/sources.yaml` 获取数据源配置。主源失败自动降级到备源。
"""
    
    return f"""---
name: {name}
version: "0.1.0"
description: |
  [在此填写 skill 描述和触发词]
triggers:
  - [触发词1]
  - [触发词2]
token_budget:
  L0_trigger: 100
  L1_core: 800
  L2_deep: 3000
  hard_cap: 4000
{data_sources_fm}scenes:
{chr(10).join(f'  - {s}' for s in scenes)}
---

# {name}

## 场景路由

| 场景 | 脚本 | 入选条件 |
|------|------|---------|
{scene_rows}
{data_section}
## 使用方式

[在此描述使用方式，根据场景调用对应脚本]

## 脚本说明

| 脚本 | 用途 |
|------|------|
{chr(10).join(f'  | scripts/scene_{chr(97+i)}.py | {s}评分 |' for i, s in enumerate(scenes))}
| scripts/router.py | 场景路由器 |
| scripts/data_validator.py | 数据验证 |
| scripts/refresh_cache.py | 刷新缓存 |

## 行为约束

收到与职责无关的请求，告知范围并停止。
数据不确定时标注「数据不足」，禁止编造。
结论前置，不铺垫。
回答完毕即收尾，不延伸。

## 三级加载

| 级别 | 内容 | 何时加载 |
|------|------|---------|
| L0 | frontmatter（触发匹配+场景路由） | 自动 |
| L1 | 本文件 body（场景路由+核心指令） | 匹配后 |
| L2 | references/（各场景完整文档、因子说明） | 按需 |
"""


def get_spec_md(name: str) -> str:
    return f"""# {name} — 需求规格说明书

## 版本历史

| 版本 | 日期 | 变更摘要 |
|------|------|---------|
| V0.1.0 | {date.today().isoformat()} | 初始规格 |

## 版本同步清单

本 skill 的版本号出现在以下文件，版本变更时须同步修改：

| 文件 | 版本号位置 |
|------|-----------|
| `SKILL.md` | frontmatter `version:` 字段 |
| `SPEC.md` | 版本历史表 |
| `CHANGELOG.md` | 版本条目标题 `## [X.Y.Z]` |

## 核心需求

### REQ-001: [需求名称]
- **描述**: [需求描述]
- **优先级**: P0/P1/P2
- **验证标准**: [如何验证]
- **状态**: 🔄待开发
"""


def get_design_md(name: str) -> str:
    return f"""# {name} — 设计文档

## 版本历史

| 版本 | 日期 | 变更摘要 |
|------|------|---------|
| V0.1.0 | {date.today().isoformat()} | 初始架构 |

## 版本同步清单

本 skill 的版本号出现在以下文件，版本变更时须同步修改：

| 文件 | 版本号位置 |
|------|-----------|
| `SKILL.md` | frontmatter `version:` 字段 |
| `SPEC.md` | 版本历史表 |
| `DESIGN.md` | 版本历史表 + 顶部 header |
| `CHANGELOG.md` | 版本条目标题 `## [X.Y.Z]` |

## 架构决策记录 (ADR)

### ADR-001: [决策标题]
- **上下文**: [为什么要做这个决策？]
- **选项**: A) ... vs B) ...
- **决策**: 选了什么
- **理由**: 为什么
- **后果**: 带来的影响
- **状态**: 🔄待定
"""


def get_changelog_md(name: str) -> str:
    return f"""# Changelog — {name}

All notable changes will be documented in this file.

> **版本同步提醒**: 本文件版本号（`## [X.Y.Z]`）须与 `SKILL.md` frontmatter 的 `version:` 字段一致。
> 如果本 skill 有 `SPEC.md` / `DESIGN.md`，其中的版本历史表也须同步修改。

## [0.1.0] - {date.today().isoformat()}

### Added
- 初始版本骨架
"""


def get_config_yaml() -> str:
    return """# 可调参数配置
# 修改配置不需要改代码

# 评分阈值
thresholds:
  pass_score: 0  # 通过分数

# 数据获取
fetch:
  timeout_seconds: 30
  retry_count: 3
  retry_delay_ms: 1000

# 缓存策略
cache:
  default_ttl_seconds: 3600
  max_age_seconds: 86400
"""


def get_sources_yaml() -> str:
    return """# 数据源声明
# 固化后除非遇到问题否则不更新
# 修改数据源不需要改代码

sources:
  example_source:
    primary:
      name: "主数据源名称"
      type: "api"  # api | web_scrape | file
      url: "https://example.com/api"
      format: "json"  # json | csv | html | xml
      pinned_at: \"""" + date.today().isoformat() + """\"
      notes: "主源说明"
    fallback:
      name: "备数据源名称"
      type: "web_scrape"
      url: "https://backup.example.com"
      format: "html"
      pinned_at: \"""" + date.today().isoformat() + """\"
    forbidden: []
    cache_ttl: 300
    update_trigger: "on_demand"  # on_demand | scheduled
"""


def get_scripts_readme() -> str:
    return """# Scripts — 接口文档

| 脚本 | 用途 | 用法 |
|------|------|------|
| main.py | 主逻辑 | `python3 scripts/main.py` |

## 通用约定

- 使用 Python 3 标准库，无外部依赖
- 输出格式为 JSON
- 读取 config.yaml 获取配置参数
- 读取 data/sources.yaml 获取数据源
- 缓存数据存入 data/cache/
"""


def get_main_script() -> str:
    return '''#!/usr/bin/env python3
"""主逻辑脚本 — [在此描述功能]"""

import json
import sys
from pathlib import Path


def load_config():
    """读取 config.yaml"""
    config_path = Path(__file__).parent.parent / "config.yaml"
    # 简易 YAML 读取（无外部依赖）
    config = {}
    if config_path.exists():
        with open(config_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if ":" in line and not line.startswith("#"):
                    key, _, val = line.partition(":")
                    config[key.strip()] = val.strip()
    return config


def main():
    config = load_config()
    result = {
        "success": True,
        "data": {
            "message": "脚本骨架，请替换为实际逻辑"
        }
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
'''


def get_refresh_cache_script() -> str:
    return '''#!/usr/bin/env python3
"""刷新缓存脚本 — 从数据源获取最新数据并更新缓存"""

import json
import sys
from datetime import datetime, timezone
from pathlib import Path


def load_sources():
    """读取 data/sources.yaml"""
    # 简易读取，返回数据源配置
    sources_path = Path(__file__).parent.parent / "data" / "sources.yaml"
    if not sources_path.exists():
        return {}
    # 实际实现需解析 YAML
    return {"sources": {}}


def save_cache(source_id: str, data: dict, ttl: int):
    """保存缓存数据"""
    cache_dir = Path(__file__).parent.parent / "data" / "cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    cache_file = cache_dir / f"{source_id}.json"
    
    cache_data = {
        "source": source_id,
        "fetched_at": datetime.now(timezone.utc).isoformat(),
        "ttl": ttl,
        "expires_at": "",  # 需计算
        "data": data
    }
    
    with open(cache_file, "w", encoding="utf-8") as f:
        json.dump(cache_data, f, ensure_ascii=False, indent=2)


def main():
    sources = load_sources()
    result = {
        "success": True,
        "data": {
            "message": "缓存刷新骨架，请替换为实际逻辑",
            "sources_found": len(sources.get("sources", {}))
        }
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
'''


def get_router_script(scenes: list = None) -> str:
    if scenes is None:
        scenes = ["scene_a", "scene_b"]
    scene_checks = "\n".join(
        f'    # {scenes[i]} 条件检查\n'
        f'    # if meets_{scenes[i]}_condition(data):\n'
        f'    #     return "{scenes[i]}"\n'
        for i in range(len(scenes))
    )
    return f'''#!/usr/bin/env python3
"""场景路由器 — 根据数据特征自动选择评分场景"""

import json
import sys
from pathlib import Path


def route(data: dict) -> str:
    """根据数据特征路由到对应场景
    
    Args:
        data: 标的数据字典
        
    Returns:
        场景标识: {"/".join(scenes)}
    """
{scene_checks}
    # 默认场景
    return "{scenes[0]}"


def main():
    # 读取输入数据
    if len(sys.argv) > 1:
        input_file = sys.argv[1]
        with open(input_file, "r", encoding="utf-8") as f:
            data = json.load(f)
    else:
        data = {{}}
    
    scene = route(data)
    result = {{
        "success": True,
        "data": {{
            "scene": scene,
            "message": f"路由到场景: {{scene}}"
        }}
    }}
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
'''


def get_data_validator_script() -> str:
    return '''#!/usr/bin/env python3
"""数据验证器 — 验证数据的完整性、时效性和格式"""

import json
from datetime import datetime, timezone
from pathlib import Path


def validate_cache(source_id: str, max_age_seconds: int = 86400) -> dict:
    """验证缓存数据是否有效
    
    Args:
        source_id: 数据源ID
        max_age_seconds: 最大允许年龄（秒）
        
    Returns:
        验证结果字典
    """
    cache_file = Path(__file__).parent.parent / "data" / "cache" / f"{source_id}.json"
    
    if not cache_file.exists():
        return {"valid": False, "reason": "cache_not_found"}
    
    with open(cache_file, "r", encoding="utf-8") as f:
        cache = json.load(f)
    
    # 检查必需字段
    required_fields = ["source", "fetched_at", "ttl", "data"]
    missing = [f for f in required_fields if f not in cache]
    if missing:
        return {"valid": False, "reason": f"missing_fields: {missing}"}
    
    # 检查时效性
    try:
        fetched_at = datetime.fromisoformat(cache["fetched_at"])
        age = (datetime.now(timezone.utc) - fetched_at).total_seconds()
        if age > max_age_seconds:
            return {"valid": False, "reason": f"cache_expired: {age:.0f}s > {max_age_seconds}s"}
    except (ValueError, TypeError):
        return {"valid": False, "reason": "invalid_fetched_at_format"}
    
    return {"valid": True, "age_seconds": age}


def main():
    result = {
        "success": True,
        "data": {
            "message": "数据验证器骨架，请替换为实际逻辑"
        }
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
'''


# ============================================================
# 文件生成逻辑
# ============================================================

def create_file(path: Path, content: str) -> bool:
    """创建文件，如果已存在则跳过"""
    if path.exists():
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    return True


def create_gitkeep(path: Path) -> bool:
    """创建 .gitkeep 占位文件"""
    return create_file(path / ".gitkeep", "")


def init_basic(dest: Path, name: str) -> list:
    """初始化 basic 模板"""
    created = []
    
    files = {
        "README.md": get_readme_basic(name),
        "SKILL.md": get_skill_md_basic(name),
        "CHANGELOG.md": get_changelog_md(name),
    }
    
    for rel_path, content in files.items():
        if create_file(dest / rel_path, content):
            created.append(rel_path)
    
    # 创建可选目录
    for dir_path in ["references", "scripts", "tests", "assets"]:
        p = dest / dir_path
        p.mkdir(parents=True, exist_ok=True)
        create_gitkeep(p)
        created.append(f"{dir_path}/.gitkeep")
    
    # 创建示例脚本
    scripts = {
        "scripts/main.py": get_main_script(),
        "scripts/README.md": get_scripts_readme(),
    }
    
    for rel_path, content in scripts.items():
        if create_file(dest / rel_path, content):
            created.append(rel_path)
    
    return created


def init_data_driven(dest: Path, name: str) -> list:
    """初始化 data-driven 模板"""
    created = []
    
    files = {
        "README.md": get_readme_data_driven(name),
        "SKILL.md": get_skill_md_data_driven(name),
        "SPEC.md": get_spec_md(name),
        "CHANGELOG.md": get_changelog_md(name),
        "config.yaml": get_config_yaml(),
        "data/sources.yaml": get_sources_yaml(),
    }
    
    for rel_path, content in files.items():
        if create_file(dest / rel_path, content):
            created.append(rel_path)
    
    # 创建缓存和 Schema 目录
    for dir_path in ["data/schemas", "data/cache", "references", "tests", "assets"]:
        p = dest / dir_path
        p.mkdir(parents=True, exist_ok=True)
        create_gitkeep(p)
        created.append(f"{dir_path}/.gitkeep")
    
    # 创建脚本
    scripts = {
        "scripts/main.py": get_main_script(),
        "scripts/refresh_cache.py": get_refresh_cache_script(),
        "scripts/data_validator.py": get_data_validator_script(),
        "scripts/README.md": get_scripts_readme(),
    }
    
    for rel_path, content in scripts.items():
        if create_file(dest / rel_path, content):
            created.append(rel_path)
    
    return created


def init_multi_scene(dest: Path, name: str, no_data: bool = False) -> list:
    """初始化 multi-scene 模板
    
    Args:
        dest: 目标路径
        name: skill 名称
        no_data: 是否为工具型（无外部数据源），默认 False
    """
    created = []
    scenes = ["场景一", "场景二"]
    
    files = {
        "README.md": get_readme_multi_scene(name, scenes, no_data=no_data),
        "SKILL.md": get_skill_md_multi_scene(name, scenes, no_data=no_data),
        "SPEC.md": get_spec_md(name),
        "DESIGN.md": get_design_md(name),
        "CHANGELOG.md": get_changelog_md(name),
        "config.yaml": get_config_yaml(),
    }
    
    if not no_data:
        files["data/sources.yaml"] = get_sources_yaml()
    
    for rel_path, content in files.items():
        if create_file(dest / rel_path, content):
            created.append(rel_path)
    
    # 创建目录（工具型不需要 data/ 相关目录）
    if no_data:
        dir_paths = ["references", "tests", "assets"]
    else:
        dir_paths = ["data/schemas", "data/cache", "references", "tests", "assets"]
    
    for dir_path in dir_paths:
        p = dest / dir_path
        p.mkdir(parents=True, exist_ok=True)
        create_gitkeep(p)
        created.append(f"{dir_path}/.gitkeep")
    
    # 创建多场景脚本（工具型不需要数据相关脚本）
    scripts = {
        "scripts/scene_a.py": get_main_script().replace("主逻辑", "场景一评分"),
        "scripts/scene_b.py": get_main_script().replace("主逻辑", "场景二评分"),
        "scripts/router.py": get_router_script(["scene_a", "scene_b"]),
    }
    if not no_data:
        scripts["scripts/data_validator.py"] = get_data_validator_script()
        scripts["scripts/refresh_cache.py"] = get_refresh_cache_script()
    scripts["scripts/README.md"] = get_scripts_readme()
    
    for rel_path, content in scripts.items():
        if create_file(dest / rel_path, content):
            created.append(rel_path)
    
    return created


# ============================================================
# 主入口
# ============================================================

def main():
    parser = argparse.ArgumentParser(description="初始化新 Skill 骨架")
    parser.add_argument("--name", required=True, help="Skill 名称（小写+连字符）")
    parser.add_argument(
        "--template", required=True,
        choices=["basic", "data-driven", "multi-scene"],
        help="模板类型"
    )
    parser.add_argument("--dest", help="目标路径（默认：~/.workbuddy/skills/<name>）")
    parser.add_argument("--no-data", action="store_true", help="工具型 multi-scene，不生成数据源相关文件")
    
    args = parser.parse_args()
    
    # 确定目标路径
    if args.dest:
        dest = Path(args.dest).resolve()
    else:
        dest = Path.home() / ".workbuddy" / "skills" / args.name
    
    # 检查是否已存在
    if dest.exists() and any(dest.iterdir()):
        result = {
            "success": False,
            "error": f"目标路径已存在且非空: {dest}",
            "hint": "请使用 update_skill.py 更新已有 skill，或指定新路径"
        }
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(1)
    
    # 创建根目录
    dest.mkdir(parents=True, exist_ok=True)
    
    # 根据模板初始化
    init_funcs = {
        "basic": init_basic,
        "data-driven": init_data_driven,
        "multi-scene": init_multi_scene,
    }
    
    if args.template == "multi-scene":
        created = init_funcs[args.template](dest, args.name, no_data=args.no_data)
    else:
        created = init_funcs[args.template](dest, args.name)
    
    result = {
        "success": True,
        "data": {
            "skill_name": args.name,
            "template": args.template,
            "path": str(dest),
            "files_created": sorted(created)
        }
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
