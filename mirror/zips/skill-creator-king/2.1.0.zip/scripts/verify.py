#!/usr/bin/env python3
"""
verify.py — 10 维度质量验证
整合 skill-refine 的 7 维度分析，扩展为 10 维度（V3 规范）

用法：
    python3 verify.py --path <skill-path> [--template <type>] [--action <verify|analyze>]
"""

import argparse
import json
import re
import sys
from datetime import datetime
from pathlib import Path

# 添加 lib 目录到搜索路径
sys.path.insert(0, str(Path(__file__).parent))
from lib.yaml_parser import parse_frontmatter, get_field, frontmatter_contains, detect_template, is_tool_type_multi_scene


# ============================================================
# 10 维度定义
# ============================================================

DIMENSIONS = [
    {"id": "structure", "name": "结构规范", "weight": 0.10},
    {"id": "metadata", "name": "元数据完整", "weight": 0.15},
    {"id": "documentation", "name": "文档有效性", "weight": 0.10},
    {"id": "code_optimization", "name": "代码化优化", "weight": 0.15},
    {"id": "consistency", "name": "一致性校验", "weight": 0.15},
    {"id": "scripts", "name": "脚本规范", "weight": 0.10},
    {"id": "qa", "name": "质量保障", "weight": 0.05},
    {"id": "data_layer", "name": "数据层规范", "weight": 0.10},
    {"id": "token_efficiency", "name": "Token效率", "weight": 0.05},
    {"id": "maintainability", "name": "可维护性", "weight": 0.05},
]

GRADE_MAP = {90: "优秀", 75: "合格", 60: "需改进", 0: "不合格"}


def get_grade(score: int) -> str:
    for threshold, grade in sorted(GRADE_MAP.items(), reverse=True):
        if score >= threshold:
            return grade
    return "不合格"


# ============================================================
# 维度1：结构规范（10%）
# ============================================================

def check_structure(skill_path: Path, template: str, is_tool_type: bool = False) -> dict:
    findings = []
    score = 100
    
    # 检测是否为工具型 multi-scene（无数据源）— 使用传入的参数
    if not is_tool_type and (skill_path / "SKILL.md").exists() and template == "multi-scene":
        is_tool_type = is_tool_type_multi_scene(skill_path)
    
    # 必需文件
    required = ["SKILL.md", "CHANGELOG.md", "README.md"]
    if template in ("data-driven", "multi-scene"):
        required += ["SPEC.md", "config.yaml"]
        # 工具型 multi-scene 不需要 data/sources.yaml
        if not is_tool_type:
            required += ["data/sources.yaml"]
    if template == "multi-scene":
        required += ["DESIGN.md"]
    
    for f in required:
        if not (skill_path / f).exists():
            findings.append({"severity": "critical", "message": f"缺少必需文件: {f}"})
            score -= 15
    
    # 必需目录
    required_dirs = ["scripts"]
    if template in ("data-driven", "multi-scene") and not is_tool_type:
        required_dirs += ["data", "data/cache", "data/schemas", "references"]
    elif template in ("data-driven", "multi-scene") and is_tool_type:
        # 工具型 multi-scene 仍需要 references
        required_dirs += ["references"]
    
    for d in required_dirs:
        if not (skill_path / d).exists():
            findings.append({"severity": "warning", "message": f"缺少目录: {d}"})
            score -= 5
    
    # scripts/README.md
    if (skill_path / "scripts").exists() and not (skill_path / "scripts" / "README.md").exists():
        findings.append({"severity": "warning", "message": "scripts/ 缺少 README.md"})
        score -= 5
    
    return {"score": max(0, score), "findings": findings}


# ============================================================
# 维度2：元数据完整（15%）
# ============================================================

def check_metadata(skill_path: Path, template: str) -> dict:
    findings = []
    score = 100
    
    skill_md = skill_path / "SKILL.md"
    if not skill_md.exists():
        return {"score": 0, "findings": [{"severity": "critical", "message": "SKILL.md 不存在"}]}
    
    content = skill_md.read_text(encoding="utf-8")
    fm = parse_frontmatter(content)
    
    # frontmatter 必需字段（精确检查，不误匹配正文）
    required_fields = ["name", "version", "description", "triggers", "token_budget"]
    for field in required_fields:
        if field not in fm:
            findings.append({"severity": "critical", "message": f"frontmatter 缺少字段: {field}"})
            score -= 10
    
    # triggers 非空
    triggers = fm.get("triggers")
    if triggers is not None:
        if not isinstance(triggers, list) or len(triggers) == 0:
            findings.append({"severity": "warning", "message": "triggers 列表为空"})
            score -= 5
    elif "triggers" not in fm:
        # 已在 required_fields 中扣分，此处不重复
        pass
    
    # token_budget 完整性
    budget = fm.get("token_budget")
    if isinstance(budget, dict):
        budget_fields = ["L0_trigger", "L1_core", "L2_deep", "hard_cap"]
        for bf in budget_fields:
            if bf not in budget:
                findings.append({"severity": "warning", "message": f"token_budget 缺少: {bf}"})
                score -= 3
    elif "token_budget" not in fm:
        # 已在 required_fields 中扣分
        pass
    
    # data_sources（data-driven 必需，multi-scene 可选——工具型不需要）
    if template == "data-driven" and "data_sources" not in fm:
        findings.append({"severity": "warning", "message": "data-driven 应声明 data_sources"})
        score -= 5
    
    return {"score": max(0, score), "findings": findings}


# ============================================================
# 维度3：文档有效性（10%）
# ============================================================

def check_documentation(skill_path: Path, template: str) -> dict:
    findings = []
    score = 100
    
    # SPEC.md
    if template in ("data-driven", "multi-scene"):
        spec = skill_path / "SPEC.md"
        if spec.exists():
            content = spec.read_text(encoding="utf-8")
            if "REQ-" not in content:
                findings.append({"severity": "warning", "message": "SPEC.md 缺少需求条目(REQ-xxx)"})
                score -= 10
            if "版本历史" not in content:
                findings.append({"severity": "warning", "message": "SPEC.md 缺少版本历史"})
                score -= 5
        else:
            findings.append({"severity": "critical", "message": "data-driven/multi-scene 缺少 SPEC.md"})
            score -= 20
    
    # DESIGN.md
    if template == "multi-scene":
        design = skill_path / "DESIGN.md"
        if design.exists():
            content = design.read_text(encoding="utf-8")
            if "ADR-" not in content:
                findings.append({"severity": "warning", "message": "DESIGN.md 缺少架构决策记录(ADR-xxx)"})
                score -= 10
        else:
            findings.append({"severity": "critical", "message": "multi-scene 缺少 DESIGN.md"})
            score -= 20
    
    # CHANGELOG.md
    changelog = skill_path / "CHANGELOG.md"
    if changelog.exists():
        content = changelog.read_text(encoding="utf-8")
        if "## [" not in content:
            findings.append({"severity": "warning", "message": "CHANGELOG.md 缺少版本条目"})
            score -= 5
    else:
        findings.append({"severity": "critical", "message": "缺少 CHANGELOG.md"})
        score -= 20
    
    # README.md（V2.0 必选）
    readme = skill_path / "README.md"
    if readme.exists():
        content = readme.read_text(encoding="utf-8")
        if "一句话" not in content:
            findings.append({"severity": "warning", "message": "README.md 缺少「一句话」章节"})
            score -= 5
        if "设计理念" not in content:
            findings.append({"severity": "info", "message": "README.md 缺少「设计理念」章节"})
            score -= 3
    else:
        findings.append({"severity": "critical", "message": "缺少 README.md"})
        score -= 20
    
    return {"score": max(0, score), "findings": findings}


# ============================================================
# 维度4：代码化优化（15%）
# ============================================================

def check_code_optimization(skill_path: Path, template: str) -> dict:
    findings = []
    score = 100
    
    skill_md = skill_path / "SKILL.md"
    if not skill_md.exists():
        return {"score": 0, "findings": [{"severity": "critical", "message": "SKILL.md 不存在"}]}
    
    content = skill_md.read_text(encoding="utf-8")
    
    # 检查 SKILL.md 中是否有大段代码（应该提取到脚本）
    code_blocks = re.findall(r'```[\s\S]*?```', content)
    long_code_blocks = [cb for cb in code_blocks if len(cb) > 500]
    if long_code_blocks:
        findings.append({"severity": "warning", "message": f"SKILL.md 有 {len(long_code_blocks)} 个长代码块(>500字符)，应提取到脚本"})
        score -= 10
    
    # scripts/ 目录是否有实际脚本
    scripts_dir = skill_path / "scripts"
    if scripts_dir.exists():
        py_files = list(scripts_dir.glob("*.py"))
        py_files = [f for f in py_files if f.name != "__init__.py"]
        if not py_files:
            findings.append({"severity": "warning", "message": "scripts/ 目录没有 .py 脚本"})
            score -= 10
        else:
            # 检查脚本是否是骨架（只有模板代码）
            skeleton_count = 0
            for pf in py_files:
                pc = pf.read_text(encoding="utf-8")
                if "请替换为实际逻辑" in pc or "TODO" in pc:
                    skeleton_count += 1
            if skeleton_count == len(py_files):
                findings.append({"severity": "info", "message": "所有脚本都是骨架，尚未填充实际逻辑"})
                score -= 5
    
    # SKILL.md 是否引用了脚本
    if "scripts/" not in content:
        findings.append({"severity": "warning", "message": "SKILL.md 未引用任何脚本"})
        score -= 5
    
    return {"score": max(0, score), "findings": findings}


# ============================================================
# 维度5：一致性校验（15%）
# ============================================================

def check_consistency(skill_path: Path, template: str) -> dict:
    findings = []
    score = 100
    
    skill_md = skill_path / "SKILL.md"
    if not skill_md.exists():
        return {"score": 0, "findings": [{"severity": "critical", "message": "SKILL.md 不存在"}]}
    
    content = skill_md.read_text(encoding="utf-8")
    
    # 提取版本号
    version_match = re.search(r'version:\s*["\']?([\d.]+)["\']?', content)
    skill_version = version_match.group(1) if version_match else None
    
    # CHANGELOG.md 最新版本
    changelog = skill_path / "CHANGELOG.md"
    if changelog.exists() and skill_version:
        cl_content = changelog.read_text(encoding="utf-8")
        # 支持三种格式: ## [1.2.0], ## v1.2.0, ## 1.2.0
        cl_versions = re.findall(r'##\s+\[?v?([\d.]+)\]?', cl_content)
        if cl_versions and cl_versions[0] != skill_version:
            findings.append({"severity": "warning", "message": f"SKILL.md 版本({skill_version})与 CHANGELOG 最新版本({cl_versions[0]})不一致"})
            score -= 10
    
    # helper: 从版本号列表中取最大版本（兼容升降序）
    def newest_ver(versions):
        return max(versions, key=lambda v: tuple(map(int, v.split("."))))
    
    # SPEC.md 版本
    spec = skill_path / "SPEC.md"
    if spec.exists() and skill_version:
        spec_content = spec.read_text(encoding="utf-8")
        # 表格格式: | V1.0.0 | ... 或 header 格式: > 版本：v1.0.0
        spec_table_vers = re.findall(r'\|\s*V?(\d+\.\d+\.\d+)\s*\|', spec_content)
        if spec_table_vers:
            spec_latest = newest_ver(spec_table_vers)
            if spec_latest != skill_version:
                findings.append({"severity": "info", "message": f"SPEC.md 版本({spec_latest})与 SKILL.md({skill_version})不一致"})
                score -= 3
        else:
            m = re.search(r'>\s*版本：\s*v?(\d+\.\d+\.\d+)', spec_content)
            if not m or m.group(1) != skill_version:
                if skill_version not in spec_content and "V" + skill_version not in spec_content:
                    findings.append({"severity": "info", "message": "SPEC.md 版本历史可能未同步"})
                    score -= 3
    
    # DESIGN.md 版本
    design = skill_path / "DESIGN.md"
    if design.exists() and skill_version:
        design_content = design.read_text(encoding="utf-8")
        design_table_vers = re.findall(r'\|\s*V?(\d+\.\d+\.\d+)\s*\|', design_content)
        if design_table_vers:
            design_latest = newest_ver(design_table_vers)
            if design_latest != skill_version:
                findings.append({"severity": "warning", "message": f"SKILL.md 版本({skill_version})与 DESIGN.md 最新版本({design_latest})不一致"})
                score -= 10
        else:
            m = re.search(r'>\s*版本：\s*v?(\d+\.\d+\.\d+)', design_content)
            if m and m.group(1) != skill_version:
                findings.append({"severity": "warning", "message": f"SKILL.md 版本({skill_version})与 DESIGN.md 版本({m.group(1)})不一致"})
                score -= 10
            elif not m:
                findings.append({"severity": "info", "message": "DESIGN.md 缺少版本信息（既无版本历史表，也无 header 行）"})
                score -= 3
    
    # 版本同步清单检查（适用于有 SPEC.md 或 DESIGN.md 的 skill）
    for doc_path in [skill_path / "SPEC.md", skill_path / "DESIGN.md"]:
        if doc_path.exists():
            doc_content = doc_path.read_text(encoding="utf-8")
            if "版本同步清单" not in doc_content and "版本同步" not in doc_content:
                findings.append({"severity": "info", "message": f"{doc_path.name} 缺少版本同步清单"})
                score -= 3
    
    # config.yaml 与脚本阈值一致性（简化检查）
    config_yaml = skill_path / "config.yaml"
    if config_yaml.exists():
        config_content = config_yaml.read_text(encoding="utf-8")
        # 检查脚本中是否有硬编码的数字阈值
        scripts_dir = skill_path / "scripts"
        if scripts_dir.exists():
            for py_file in scripts_dir.glob("*.py"):
                py_content = py_file.read_text(encoding="utf-8")
                # 简化检查：跳过骨架脚本
                if "请替换为实际逻辑" in py_content:
                    continue
                # 检查是否有明显的硬编码阈值（纯数字赋值）
                hardcodes = re.findall(r'=\s*(\d{2,})\s*#', py_content)
                if not hardcodes:
                    hardcodes = re.findall(r'threshold\s*=\s*(\d+)', py_content, re.IGNORECASE)
                if hardcodes and "load_config" not in py_content:
                    findings.append({"severity": "info", "message": f"{py_file.name} 可能含有硬编码阈值，建议使用 config.yaml"})
                    score -= 3
    
    return {"score": max(0, score), "findings": findings}


# ============================================================
# 维度6：脚本规范（10%）
# ============================================================

def check_scripts(skill_path: Path, template: str) -> dict:
    findings = []
    score = 100
    
    scripts_dir = skill_path / "scripts"
    if not scripts_dir.exists():
        return {"score": 50, "findings": [{"severity": "warning", "message": "scripts/ 目录不存在"}]}
    
    py_files = [f for f in scripts_dir.glob("*.py") if f.name != "__init__.py"]
    
    if not py_files:
        return {"score": 50, "findings": [{"severity": "warning", "message": "没有 Python 脚本"}]}
    
    for py_file in py_files:
        content = py_file.read_text(encoding="utf-8")
        
        # 检查 docstring
        if '"""' not in content and "'''" not in content:
            findings.append({"severity": "warning", "message": f"{py_file.name} 缺少模块 docstring"})
            score -= 3
        
        # 检查 main 函数
        if "def main" not in content:
            findings.append({"severity": "info", "message": f"{py_file.name} 缺少 main() 函数"})
            score -= 2
        
        # 检查 JSON 输出
        if "json.dumps" not in content and "json.dump" not in content:
            findings.append({"severity": "info", "message": f"{py_file.name} 未使用 JSON 格式输出"})
            score -= 2
        
        # 检查错误处理
        if "try:" not in content and "except" not in content:
            findings.append({"severity": "info", "message": f"{py_file.name} 缺少错误处理"})
            score -= 2
    
    # scripts/README.md
    if not (scripts_dir / "README.md").exists():
        findings.append({"severity": "warning", "message": "scripts/ 缺少 README.md"})
        score -= 5
    
    return {"score": max(0, score), "findings": findings}


# ============================================================
# 维度7：质量保障（5%）
# ============================================================

def check_qa(skill_path: Path, template: str) -> dict:
    findings = []
    score = 100
    
    tests_dir = skill_path / "tests"
    if tests_dir.exists():
        test_files = list(tests_dir.glob("*.py")) + list(tests_dir.glob("*.md"))
        if not test_files:
            findings.append({"severity": "info", "message": "tests/ 目录为空，建议添加测试"})
            score -= 10
    else:
        findings.append({"severity": "info", "message": "缺少 tests/ 目录"})
        score -= 10
    
    # 检查脚本是否有边界情况处理
    scripts_dir = skill_path / "scripts"
    if scripts_dir.exists():
        for py_file in scripts_dir.glob("*.py"):
            content = py_file.read_text(encoding="utf-8")
            if "请替换为实际逻辑" in content:
                continue
            if "sys.exit" not in content and "return" not in content:
                findings.append({"severity": "info", "message": f"{py_file.name} 缺少错误退出机制"})
                score -= 3
    
    return {"score": max(0, score), "findings": findings}


# ============================================================
# 维度8：数据层规范（10%）— V3新增
# ============================================================

def check_data_layer(skill_path: Path, template: str, is_tool_type: bool = False) -> dict:
    findings = []
    score = 100
    
    # 使用传入的 is_tool_type 或重新计算
    if not is_tool_type and template == "multi-scene":
        is_tool_type = is_tool_type_multi_scene(skill_path)
    
    # basic 和工具型 multi-scene 不需要数据层
    if template == "basic" or is_tool_type:
        if (skill_path / "data").exists():
            findings.append({"severity": "info", "message": "basic/工具型 multi-scene 不需要 data/ 目录"})
        return {"score": 100, "findings": []}
    
    # sources.yaml
    sources_yaml = skill_path / "data" / "sources.yaml"
    if not sources_yaml.exists():
        findings.append({"severity": "critical", "message": "data-driven/multi-scene 缺少 data/sources.yaml"})
        return {"score": 20, "findings": findings}
    
    sources_content = sources_yaml.read_text(encoding="utf-8")
    
    # 检查 primary
    if "primary:" not in sources_content:
        findings.append({"severity": "critical", "message": "sources.yaml 缺少 primary 定义"})
        score -= 20
    
    # 检查 fallback
    if "fallback:" not in sources_content:
        findings.append({"severity": "warning", "message": "建议为每个数据源配置 fallback"})
        score -= 5
    
    # 检查 pinned_at
    if "pinned_at:" not in sources_content:
        findings.append({"severity": "warning", "message": "建议为数据源添加 pinned_at 固化日期"})
        score -= 5
    
    # 检查 forbidden 与 primary/fallback 冲突
    if "forbidden:" in sources_content:
        # 简化检查
        pass
    
    # 检查缓存目录
    cache_dir = skill_path / "data" / "cache"
    if not cache_dir.exists():
        findings.append({"severity": "warning", "message": "缺少 data/cache/ 目录"})
        score -= 5
    
    # 检查缓存文件格式
    if cache_dir.exists():
        for cache_file in cache_dir.glob("*.json"):
            try:
                cache_data = json.loads(cache_file.read_text(encoding="utf-8"))
                required_cache_fields = ["source", "fetched_at", "ttl", "data"]
                missing = [f for f in required_cache_fields if f not in cache_data]
                if missing:
                    findings.append({"severity": "warning", "message": f"{cache_file.name} 缺少字段: {missing}"})
                    score -= 5
            except (json.JSONDecodeError, UnicodeDecodeError):
                findings.append({"severity": "warning", "message": f"{cache_file.name} 不是有效的 JSON"})
                score -= 5
    
    # 检查 schemas 目录
    if not (skill_path / "data" / "schemas").exists():
        findings.append({"severity": "info", "message": "缺少 data/schemas/ 目录"})
        score -= 3
    
    return {"score": max(0, score), "findings": findings}


# ============================================================
# 维度9：Token效率（5%）— V3新增
# ============================================================

def check_token_efficiency(skill_path: Path, template: str) -> dict:
    findings = []
    score = 100
    
    skill_md = skill_path / "SKILL.md"
    if not skill_md.exists():
        return {"score": 0, "findings": [{"severity": "critical", "message": "SKILL.md 不存在"}]}
    
    content = skill_md.read_text(encoding="utf-8")
    
    # 全文件 token 估算（含 frontmatter）
    # 注意：这是近似估算。中文字符 ~1.5-3 tokens/字，英文词 ~1-2 tokens/词，
    # 实际值取决于具体 tokenizer。当前系数取保守下限，实际可能 +20-30%。
    all_chinese = len(re.findall(r'[\u4e00-\u9fff]', content))
    all_english = len(re.findall(r'[a-zA-Z]+', content))
    estimated_tokens = int(all_chinese * 1.5 + all_english * 1.3)
    
    # L1 body token 估算（仅 frontmatter 之后的内容）
    if "---" in content:
        parts = content.split("---", 2)
        if len(parts) >= 3:
            body = parts[2].strip()
        else:
            body = content
    else:
        body = content
    
    body_chinese = len(re.findall(r'[\u4e00-\u9fff]', body))
    body_english = len(re.findall(r'[a-zA-Z]+', body))
    body_tokens = int(body_chinese * 1.5 + body_english * 1.3)
    
    # 检查 token_budget 声明
    if "token_budget:" not in content:
        findings.append({"severity": "warning", "message": "SKILL.md 未声明 token_budget"})
        score -= 10
    
    # L1 body 不应超过 800 tokens
    if body_tokens > 800:
        findings.append({"severity": "warning", "message": f"L1 body 估算 {body_tokens} tokens，建议精简到 800 以内"})
        score -= 15
    elif body_tokens > 600:
        findings.append({"severity": "info", "message": f"L1 body 估算 {body_tokens} tokens，接近 800 上限"})
    
    # 检查是否有大段内联代码
    code_blocks = re.findall(r'```[\s\S]*?```', body)
    total_code_len = sum(len(cb) for cb in code_blocks)
    if total_code_len > 1000:
        findings.append({"severity": "warning", "message": f"SKILL.md 内联代码总长 {total_code_len} 字符，应提取到脚本"})
        score -= 15
    
    # 检查是否声明了 L2 文件
    if "references/" not in content and template != "basic":
        findings.append({"severity": "info", "message": "建议在 SKILL.md 中声明 L2 深度参考文件"})
        score -= 5
    
    # 检查 L2 分离合规
    refs_dir = skill_path / "references"
    if refs_dir.exists():
        ref_files = list(refs_dir.glob("*.md"))
        if not ref_files:
            findings.append({"severity": "info", "message": "references/ 为空，考虑将详细文档移入"})
        else:
            for ref_file in ref_files:
                ref_content = ref_file.read_text(encoding="utf-8")
                if len(ref_content) > 200:
                    ref_title = ref_content.split("\n")[0]
                    if ref_title.strip("# ").strip() in content and len(ref_content) > 500:
                        findings.append({"severity": "info", "message": f"SKILL.md 可能内联了 {ref_file.name} 的内容"})
                        score -= 3
    
    return {"score": max(0, score), "findings": findings, "estimated_tokens": estimated_tokens, "body_tokens": body_tokens}


# ============================================================
# 维度10：可维护性（5%）— V3新增
# ============================================================

def check_maintainability(skill_path: Path, template: str, is_tool_type: bool = False) -> dict:
    findings = []
    score = 100
    
    # 使用传入的 is_tool_type 或重新计算
    if not is_tool_type and template == "multi-scene":
        is_tool_type = is_tool_type_multi_scene(skill_path)
    
    # SPEC.md 存在性
    if template in ("data-driven", "multi-scene"):
        if not (skill_path / "SPEC.md").exists():
            findings.append({"severity": "critical", "message": "data-driven/multi-scene 缺少 SPEC.md"})
            score -= 20
    
    # DESIGN.md 存在性
    if template == "multi-scene":
        if not (skill_path / "DESIGN.md").exists():
            findings.append({"severity": "critical", "message": "multi-scene 缺少 DESIGN.md"})
            score -= 20
    
    # CHANGELOG.md 质量检查
    changelog = skill_path / "CHANGELOG.md"
    if changelog.exists():
        cl_content = changelog.read_text(encoding="utf-8")
        
        # 检查是否有原因说明
        if "原因" not in cl_content and "reason" not in cl_content.lower():
            findings.append({"severity": "info", "message": "CHANGELOG 建议包含变更原因说明"})
            score -= 5
        
        # 检查是否有勿回退标记
        if "勿回退" not in cl_content and "no-revert" not in cl_content.lower() and "no_revert" not in cl_content.lower():
            findings.append({"severity": "info", "message": "关键变更建议添加'勿回退'标记"})
            score -= 3
    
    # config.yaml 分离
    if template in ("data-driven", "multi-scene"):
        # 工具型 multi-scene 可选 config.yaml
        
        if not is_tool_type and not (skill_path / "config.yaml").exists():
            findings.append({"severity": "warning", "message": "data-driven/multi-scene 缺少 config.yaml"})
            score -= 10
    
    # 3.7: SPEC REQ → 脚本实现信号（轻量检查）
    if template in ("data-driven", "multi-scene"):
        spec = skill_path / "SPEC.md"
        scripts_dir = skill_path / "scripts"
        if spec.exists() and scripts_dir.exists():
            spec_content = spec.read_text(encoding="utf-8")
            req_ids = re.findall(r'REQ-(\d+)', spec_content)
            if req_ids:
                all_script_content = ""
                for py_file in scripts_dir.glob("*.py"):
                    try:
                        all_script_content += py_file.read_text(encoding="utf-8")
                    except Exception:
                        pass
                missing_reqs = []
                for req_id in req_ids:
                    if f"REQ-{req_id}" not in all_script_content:
                        missing_reqs.append(f"REQ-{req_id}")
                if missing_reqs:
                    findings.append({"severity": "info", "message": f"以下 REQ 在脚本中未找到引用: {', '.join(missing_reqs)}"})
                    score -= 2 * min(len(missing_reqs), 5)  # 最多扣10分
    
    # 3.8: DESIGN ADR → 代码遵循信号（轻量检查）
    if template == "multi-scene":
        design = skill_path / "DESIGN.md"
        scripts_dir = skill_path / "scripts"
        if design.exists() and scripts_dir.exists():
            design_content = design.read_text(encoding="utf-8")
            adr_ids = re.findall(r'ADR-(\d+)', design_content)
            if adr_ids:
                all_script_content = ""
                for py_file in scripts_dir.glob("*.py"):
                    try:
                        all_script_content += py_file.read_text(encoding="utf-8")
                    except Exception:
                        pass
                missing_adrs = []
                for adr_id in adr_ids:
                    if f"ADR-{adr_id}" not in all_script_content:
                        missing_adrs.append(f"ADR-{adr_id}")
                if missing_adrs:
                    findings.append({"severity": "info", "message": f"以下 ADR 在脚本中未找到引用: {', '.join(missing_adrs)}"})
                    score -= 2 * min(len(missing_adrs), 5)  # 最多扣10分
    
    return {"score": max(0, score), "findings": findings}


# ============================================================
# 主入口
# ============================================================

CHECK_FUNCS = [
    # (func, [extra_params])
    (check_structure,         ["is_tool_type"]),
    (check_metadata,          []),
    (check_documentation,     []),
    (check_code_optimization, []),
    (check_consistency,      []),
    (check_scripts,          []),
    (check_qa,               []),
    (check_data_layer,        ["is_tool_type"]),
    (check_token_efficiency,  []),
    (check_maintainability,   ["is_tool_type"]),
]


# ============================================================
# 快照对比辅助函数
# ============================================================

def compute_delta(prev_data: dict, curr_data: dict) -> dict:
    """计算两轮快照之间的 delta"""
    prev_findings = set()
    for dim_id, messages in prev_data.get("findings_by_dimension", {}).items():
        for msg in messages:
            prev_findings.add(f"{dim_id}::{msg}")

    curr_findings = set()
    for dim_id, messages in curr_data.get("findings_by_dimension", {}).items():
        for msg in messages:
            curr_findings.add(f"{dim_id}::{msg}")

    new_findings = curr_findings - prev_findings
    resolved_findings = prev_findings - curr_findings
    unchanged_findings = prev_findings & curr_findings

    score_diff = curr_data["overall_score"] - prev_data["overall_score"]
    critical_diff = curr_data["critical_count"] - prev_data["critical_count"]

    return {
        "score_diff": score_diff,
        "score_trend": "↑" if score_diff > 0 else ("→" if score_diff == 0 else "↓"),
        "prev_score": prev_data["overall_score"],
        "curr_score": curr_data["overall_score"],
        "critical_diff": critical_diff,
        "new_findings_count": len(new_findings),
        "resolved_findings_count": len(resolved_findings),
        "unchanged_findings_count": len(unchanged_findings),
        "new_findings": sorted(list(new_findings))[:10],  # 最多显示10条
        "resolved_findings": sorted(list(resolved_findings))[:10],
    }


def detect_convergence(prev_prev_data: dict, prev_data: dict, curr_data: dict) -> str:
    """检测收敛状态：improving / stalled / regressed"""
    score_seq = [
        prev_prev_data["overall_score"],
        prev_data["overall_score"],
        curr_data["overall_score"],
    ]

    # 连续2轮分数差 <2 → 停滞
    diff1 = score_seq[1] - score_seq[0]
    diff2 = score_seq[2] - score_seq[1]
    if abs(diff1) < 2 and abs(diff2) < 2:
        return "stalled"

    # critical 数量增加 → 回退
    if curr_data["critical_count"] > prev_data["critical_count"]:
        return "regressed"

    # 分数提升 → 改善中
    if score_seq[2] > score_seq[1] or score_seq[1] > score_seq[0]:
        return "improving"

    return "stalled"


def main():
    parser = argparse.ArgumentParser(description="10 维度质量验证")
    parser.add_argument("--path", required=True, help="目标 skill 的路径")
    parser.add_argument("--template", choices=["basic", "data-driven", "multi-scene"], help="模板类型（不指定则自动检测）")
    parser.add_argument("--action", choices=["verify", "analyze"], default="verify", help="动作：verify 或 analyze（兼容 skill-refine）")
    parser.add_argument("--snapshot-dir", help="快照目录路径（保存/对比历史评分快照）")
    
    args = parser.parse_args()
    
    skill_path = Path(args.path).resolve()
    
    if not skill_path.exists():
        result = {"success": False, "error": f"路径不存在: {skill_path}"}
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(1)
    
    # 检测模板类型
    template = args.template or detect_template(skill_path)
    
    # 预计算 is_tool_type（供多个维度共用）
    _is_tool_type = is_tool_type_multi_scene(skill_path) if template == "multi-scene" else False
    
    # 执行 10 维度检查
    dimensions = []
    total_weighted = 0
    
    for i, (check_func, extra_params) in enumerate(CHECK_FUNCS):
        dim_info = DIMENSIONS[i]
        try:
            kwargs = {}
            if "is_tool_type" in extra_params:
                kwargs["is_tool_type"] = _is_tool_type
            res = check_func(skill_path, template, **kwargs)
            dim_score = res["score"]
            findings = res["findings"]
        except Exception as e:
            dim_score = 0
            findings = [{"severity": "critical", "message": f"检查异常: {str(e)}"}]
        
        weighted = dim_score * dim_info["weight"]
        total_weighted += weighted
        
        dim_result = {
            "name": dim_info["name"],
            "id": dim_info["id"],
            "score": dim_score,
            "weight": dim_info["weight"],
            "weighted_score": round(weighted, 1),
            "findings": findings
        }
        
        # 附加额外信息
        if "estimated_tokens" in res:
            dim_result["estimated_tokens"] = res["estimated_tokens"]
        if "body_tokens" in res:
            dim_result["body_tokens"] = res["body_tokens"]
        
        dimensions.append(dim_result)
    
    overall_score = round(total_weighted)
    grade = get_grade(overall_score)
    
    # 优先行动项（score < 70 的维度）
    prioritized_actions = []
    for dim in dimensions:
        if dim["score"] < 70:
            critical = [f for f in dim["findings"] if f["severity"] == "critical"]
            if critical:
                prioritized_actions.append({
                    "dimension": dim["name"],
                    "priority": "P0",
                    "actions": [f["message"] for f in critical]
                })
    
    # 快速收益（warning 级别的修复建议）
    quick_wins = []
    for dim in dimensions:
        warnings = [f for f in dim["findings"] if f["severity"] == "warning"]
        if warnings and dim["score"] >= 60:
            quick_wins.append({
                "dimension": dim["name"],
                "actions": [f["message"] for f in warnings]
            })
    
    # V3 特有信息
    token_dim = next((d for d in dimensions if d["id"] == "token_efficiency"), {})
    v3_specific = {
        "template": template,
        "has_data_layer": (skill_path / "data" / "sources.yaml").exists(),
        "has_spec": (skill_path / "SPEC.md").exists(),
        "has_design": (skill_path / "DESIGN.md").exists(),
        "has_config": (skill_path / "config.yaml").exists(),
        "token_budget_declared": "token_budget:" in (skill_path / "SKILL.md").read_text(encoding="utf-8") if (skill_path / "SKILL.md").exists() else False,
        "skill_md_estimated_tokens": token_dim.get("estimated_tokens", "N/A"),
    }
    
    # 数据源信息
    sources_yaml = skill_path / "data" / "sources.yaml"
    if sources_yaml.exists():
        sources_content = sources_yaml.read_text(encoding="utf-8")
        source_count = sources_content.count("primary:")
        fallback_count = sources_content.count("fallback:")
        v3_specific["sources_with_fallback"] = f"{fallback_count}/{source_count}"
        v3_specific["forbidden_conflicts"] = 0  # 简化

    # 统计 findings 汇总
    critical_count = sum(1 for d in dimensions for f in d["findings"] if f["severity"] == "critical")
    warning_count = sum(1 for d in dimensions for f in d["findings"] if f["severity"] == "warning")
    info_count = sum(1 for d in dimensions for f in d["findings"] if f["severity"] == "info")

    result = {
        "success": True,
        "data": {
            "skill_name": skill_path.name,
            "template": template,
            "overall_score": overall_score,
            "grade": grade,
            "pass": overall_score >= 75,
            "summary": f"总评分 {overall_score}/100（{grade}），{len(prioritized_actions)} 个优先修复项，{len(quick_wins)} 个快速收益",
            "dimensions": dimensions,
            "prioritized_actions": prioritized_actions,
            "quick_wins": quick_wins,
            "v3_specific": v3_specific,
            "findings_summary": {
                "critical": critical_count,
                "warning": warning_count,
                "info": info_count
            }
        }
    }

    # ============================================================
    # 快照功能（--snapshot-dir）
    # ============================================================
    if args.snapshot_dir:
        snapshot_dir = Path(args.snapshot_dir).resolve()
        snapshot_dir.mkdir(parents=True, exist_ok=True)

        # 保存本轮快照
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        snapshot_file = snapshot_dir / f"verify_{timestamp}.json"

        snapshot_data = {
            "timestamp": timestamp,
            "overall_score": overall_score,
            "grade": grade,
            "critical_count": critical_count,
            "warning_count": warning_count,
            "info_count": info_count,
            "findings_by_dimension": {
                d["id"]: [f["message"] for f in d["findings"]]
                for d in dimensions
            }
        }

        snapshot_file.write_text(
            json.dumps(snapshot_data, ensure_ascii=False, indent=2),
            encoding="utf-8"
        )

        # 查找历史快照并对比
        prev_snapshots = sorted(
            [f for f in snapshot_dir.glob("verify_*.json") if f != snapshot_file],
            key=lambda f: f.name
        )

        delta = None
        convergence = None

        if prev_snapshots:
            latest_prev = prev_snapshots[-1]
            try:
                prev_data = json.loads(latest_prev.read_text(encoding="utf-8"))
                delta = compute_delta(prev_data, snapshot_data)

                # 收敛检测：需要至少2个历史快照
                if len(prev_snapshots) >= 2:
                    prev_prev_data = json.loads(prev_snapshots[-2].read_text(encoding="utf-8"))
                    convergence = detect_convergence(prev_prev_data, prev_data, snapshot_data)
                else:
                    # 只有1个历史快照，简单判断
                    if delta["score_diff"] >= 2:
                        convergence = "improving"
                    elif delta["score_diff"] >= -1:
                        convergence = "stable"
                    else:
                        convergence = "regressed"

                result["data"]["delta"] = delta
                result["data"]["convergence"] = convergence

                # 迭代退出判断
                is_first_run = False
                if overall_score >= 75 and critical_count <= prev_data.get("critical_count", 999):
                    result["data"]["iteration_verdict"] = "pass"
                elif convergence == "stalled":
                    result["data"]["iteration_verdict"] = "stalled"
                elif convergence == "regressed":
                    result["data"]["iteration_verdict"] = "regressed"
                else:
                    result["data"]["iteration_verdict"] = "continue"
            except (json.JSONDecodeError, KeyError) as e:
                result["data"]["delta_error"] = f"快照对比失败: {e}"
        else:
            # 首轮：score ≥75 即通过
            result["data"]["convergence"] = "first_run"
            if overall_score >= 75:
                result["data"]["iteration_verdict"] = "pass"
            else:
                result["data"]["iteration_verdict"] = "continue"

        result["data"]["snapshot_file"] = str(snapshot_file)

    # 兼容 skill-refine 的 analyze action
    if args.action == "analyze":
        result["data"]["compat_note"] = "此输出由 skill-creator-king verify.py 生成，兼容 skill-refine analyze.py 格式"
    
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
