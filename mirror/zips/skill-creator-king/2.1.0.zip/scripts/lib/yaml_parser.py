#!/usr/bin/env python3
"""
yaml_parser.py — 轻量 YAML frontmatter 解析器
纯标准库实现，支持 frontmatter 中的单行值、多行文本、列表、一级嵌套

用法：
    from lib.yaml_parser import parse_frontmatter, get_field, update_field
    fm = parse_frontmatter(content)
    version = get_field(content, "version")
"""

import re
from typing import Any, Optional


def _extract_frontmatter_str(content: str) -> Optional[str]:
    """提取 --- 之间的 frontmatter 原始文本"""
    if not content.startswith("---"):
        return None
    end = content.find("---", 3)
    if end == -1:
        return None
    return content[3:end].strip()


def _parse_value(val_str: str) -> Any:
    """解析单个 YAML 值字符串为 Python 类型"""
    val_str = val_str.strip()
    
    # 空值
    if not val_str or val_str == "null" or val_str == "~":
        return None
    
    # 布尔值
    if val_str.lower() in ("true", "yes", "on"):
        return True
    if val_str.lower() in ("false", "no", "off"):
        return False
    
    # 带引号的字符串
    if (val_str.startswith('"') and val_str.endswith('"')) or \
       (val_str.startswith("'") and val_str.endswith("'")):
        return val_str[1:-1]
    
    # 数字
    try:
        if "." in val_str:
            return float(val_str)
        return int(val_str)
    except ValueError:
        pass
    
    # 行内列表 [a, b, c]
    if val_str.startswith("[") and val_str.endswith("]"):
        inner = val_str[1:-1].strip()
        if not inner:
            return []
        items = [item.strip().strip("'\"") for item in inner.split(",")]
        return items
    
    # 行内字典 {key: value}（简化处理）
    if val_str.startswith("{") and val_str.endswith("}"):
        return val_str  # 不展开，返回原始字符串
    
    # 普通字符串
    return val_str


def parse_frontmatter(content: str) -> dict:
    """解析 YAML frontmatter 为字典
    
    支持：
    - 单行 key: value
    - 多行文本 key: | 和 key: >
    - 列表 key:\\n  - item1\\n  - item2
    - 一级嵌套 key:\\n  sub_key: value
    - 带引号的值 key: "value" 和 key: 'value'
    """
    fm_str = _extract_frontmatter_str(content)
    if fm_str is None:
        return {}
    
    result = {}
    lines = fm_str.split("\n")
    i = 0
    
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()
        
        # 跳过空行和注释
        if not stripped or stripped.startswith("#"):
            i += 1
            continue
        
        # 列表项（顶级列表不应出现在 frontmatter 中，但安全跳过）
        if stripped.startswith("- "):
            i += 1
            continue
        
        # 顶层 key: value
        match = re.match(r'^(\w[\w_-]*)\s*:', line)
        if not match:
            i += 1
            continue
        
        key = match.group(1)
        after_colon = line[match.end():].strip()
        
        # 多行文本 | 或 >
        if after_colon in ("|", ">"):
            multiline_lines = []
            i += 1
            while i < len(lines):
                if lines[i].startswith("  ") or lines[i].startswith("\t") or not lines[i].strip():
                    multiline_lines.append(lines[i].strip())
                else:
                    break
                i += 1
            result[key] = "\n".join(multiline_lines)
            continue
        
        # 值为空 → 可能是列表或嵌套对象
        if not after_colon:
            # 查看下一行的缩进
            if i + 1 < len(lines):
                next_line = lines[i + 1]
                # 列表: 下一行以 "  - " 开头
                if next_line.strip().startswith("- "):
                    items = []
                    i += 1
                    while i < len(lines):
                        s = lines[i]
                        if s.startswith("  - ") or s.startswith("\t- "):
                            item_val = s.strip()[2:].strip()
                            items.append(_parse_value(item_val))
                        elif s.startswith("    ") or s.startswith("\t\t"):
                            # 列表项的续行（复杂值，简化处理）
                            pass
                        else:
                            break
                        i += 1
                    result[key] = items
                    continue
                
                # 嵌套对象: 下一行以 "  key: " 开头
                nested_match = re.match(r'^\s{2,}(\w[\w_-]*)\s*:', next_line)
                if nested_match:
                    nested = {}
                    i += 1
                    while i < len(lines):
                        s = lines[i]
                        nm = re.match(r'^\s{2,}(\w[\w_-]*)\s*:\s*(.*)', s)
                        if nm:
                            nested[nm.group(1)] = _parse_value(nm.group(2).strip())
                        else:
                            break
                        i += 1
                    result[key] = nested
                    continue
            
            # 既不是列表也不是嵌套 → 空值
            result[key] = None
            i += 1
            continue
        
        # 普通单行值
        result[key] = _parse_value(after_colon)
        i += 1
    
    return result


def get_field(content: str, field: str) -> Any:
    """从 frontmatter 中提取指定字段值"""
    fm = parse_frontmatter(content)
    return fm.get(field)


def update_field(content: str, field: str, value: Any) -> str:
    """更新 frontmatter 中的指定字段
    
    如果字段存在则替换，不存在则在 frontmatter 末尾追加
    """
    fm_str = _extract_frontmatter_str(content)
    if fm_str is None:
        return content
    
    # 格式化新值
    if isinstance(value, list):
        val_str = "\n" + "\n".join(f"  - {item}" for item in value)
    elif isinstance(value, dict):
        val_str = "\n" + "\n".join(f"  {k}: {v}" for k, v in value.items())
    elif isinstance(value, str) and (" " in value or ":" in value or value.startswith('"')):
        val_str = f' "{value}"'
    elif isinstance(value, str) and "\n" in value:
        val_str = " |\n" + "\n".join(f"  {line}" for line in value.split("\n"))
    elif value is None:
        val_str = ""
    else:
        val_str = f" {value}"
    
    # 尝试替换已有字段
    # 匹配字段行及其后续的列表/嵌套行
    pattern = re.compile(
        r'^(' + re.escape(field) + r'\s*:.*)$',
        re.MULTILINE
    )
    
    # 先检查字段是否存在（考虑可能是列表或嵌套，需要匹配多行）
    if re.search(r'^' + re.escape(field) + r'\s*:', fm_str, re.MULTILINE):
        # 找到字段起始位置
        fm_lines = fm_str.split("\n")
        new_fm_lines = []
        in_target = False
        skip_nested = False
        
        for line in fm_lines:
            # 检查是否是目标字段的起始行
            if re.match(r'^' + re.escape(field) + r'\s*:', line):
                in_target = True
                skip_nested = True
                # 写入新值
                new_fm_lines.append(f"{field}:{val_str}")
                continue
            
            if in_target:
                # 跳过原来的列表/嵌套行
                if line.startswith("  ") or line.startswith("\t"):
                    continue
                else:
                    in_target = False
                    new_fm_lines.append(line)
            else:
                new_fm_lines.append(line)
        
        new_fm = "\n".join(new_fm_lines)
    else:
        # 字段不存在，在 frontmatter 末尾追加
        new_fm = fm_str.rstrip() + f"\n{field}:{val_str}"
    
    # 替换原 content 中的 frontmatter
    # 保证 --- 分隔符独占一行（YAML 规范要求）
    end = content.find("---", 3)
    after_body = content[end + 3:]
    result = "---\n" + new_fm + "\n---" + after_body
    return result


def frontmatter_contains(content: str, field: str) -> bool:
    """检查 frontmatter 中是否包含指定字段
    
    精确匹配 frontmatter 区域内的字段声明，不会误匹配正文内容
    """
    fm_str = _extract_frontmatter_str(content)
    if fm_str is None:
        return False
    # 匹配字段声明行（key: 后面可以有值也可以没有）
    return bool(re.search(r'^' + re.escape(field) + r'\s*:', fm_str, re.MULTILINE))


def detect_template(skill_path) -> str:
    """多信号模板检测（统一实现）
    
    信号优先级：
    1. DESIGN.md 存在 或 scenes 字段非空 → multi-scene
    2. sources.yaml 存在 或 (SPEC.md + config.yaml) → data-driven
    3. 默认 → basic
    
    支持工具型 multi-scene（如 skill-creator-king 自身）：
    有 DESIGN.md 但无 sources.yaml → 仍判定为 multi-scene
    
    Args:
        skill_path: Path 对象或字符串路径
    
    Returns:
        "basic" | "data-driven" | "multi-scene"
    """
    from pathlib import Path
    
    if not isinstance(skill_path, Path):
        skill_path = Path(skill_path)
    
    signals = {
        "has_sources_yaml": (skill_path / "data" / "sources.yaml").exists(),
        "has_design": (skill_path / "DESIGN.md").exists(),
        "has_spec": (skill_path / "SPEC.md").exists(),
        "has_config": (skill_path / "config.yaml").exists(),
        "has_data_dir": (skill_path / "data").exists(),
    }
    
    # 读取 SKILL.md frontmatter 信号
    skill_md = skill_path / "SKILL.md"
    if skill_md.exists():
        try:
            fm = parse_frontmatter(skill_md.read_text(encoding="utf-8"))
            signals["has_scenes"] = "scenes" in fm and fm["scenes"]
            signals["has_data_sources"] = "data_sources" in fm and fm["data_sources"]
        except Exception:
            signals["has_scenes"] = False
            signals["has_data_sources"] = False
    else:
        signals["has_scenes"] = False
        signals["has_data_sources"] = False
    
    # 多场景信号：DESIGN.md 存在 或 scenes 字段非空
    if signals["has_design"] or signals["has_scenes"]:
        return "multi-scene"
    
    # 数据驱动信号：sources.yaml 存在 或 (SPEC + config)
    if signals["has_sources_yaml"] or (signals["has_spec"] and signals["has_config"]):
        return "data-driven"
    
    return "basic"


def is_tool_type_multi_scene(skill_path) -> bool:
    """判断是否为工具型 multi-scene（无数据源）
    
    工具型 = multi-scene 模板 且 无 data_sources 字段 且 无 data/ 目录
    
    Args:
        skill_path: Path 对象或字符串路径
    
    Returns:
        bool
    """
    from pathlib import Path
    
    if not isinstance(skill_path, Path):
        skill_path = Path(skill_path)
    
    template = detect_template(skill_path)
    if template != "multi-scene":
        return False
    
    skill_md = skill_path / "SKILL.md"
    if skill_md.exists():
        try:
            fm = parse_frontmatter(skill_md.read_text(encoding="utf-8"))
            return "data_sources" not in fm and not (skill_path / "data").exists()
        except Exception:
            pass
    
    return not (skill_path / "data").exists()
