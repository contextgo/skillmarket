#!/usr/bin/env python3
"""
test_core.py — 核心脚本基础测试
覆盖 yaml_parser、verify detect_template、update_skill 版本号修复
"""

import json
import sys
import tempfile
from pathlib import Path

# 添加 lib 到搜索路径
sys.path.insert(0, str(Path(__file__).parent.parent / "scripts"))
from lib.yaml_parser import parse_frontmatter, get_field, frontmatter_contains, update_field


# ============================================================
# yaml_parser 测试
# ============================================================

def test_parse_simple_fields():
    """测试单行 key: value 解析"""
    content = """---
name: test-skill
version: "1.0.0"
---
body"""
    fm = parse_frontmatter(content)
    assert fm["name"] == "test-skill", f"Expected 'test-skill', got '{fm['name']}'"
    assert fm["version"] == "1.0.0", f"Expected '1.0.0', got '{fm['version']}'"
    print("  ✅ test_parse_simple_fields")


def test_parse_list_field():
    """测试列表字段解析"""
    content = """---
name: test
triggers:
  - 触发词1
  - 触发词2
  - 触发词3
---
body"""
    fm = parse_frontmatter(content)
    assert isinstance(fm["triggers"], list), f"Expected list, got {type(fm['triggers'])}"
    assert len(fm["triggers"]) == 3, f"Expected 3 items, got {len(fm['triggers'])}"
    assert fm["triggers"][0] == "触发词1"
    print("  ✅ test_parse_list_field")


def test_parse_nested_field():
    """测试嵌套对象解析"""
    content = """---
name: test
token_budget:
  L0_trigger: 100
  L1_core: 800
  L2_deep: 3000
  hard_cap: 4000
---
body"""
    fm = parse_frontmatter(content)
    assert isinstance(fm["token_budget"], dict), f"Expected dict, got {type(fm['token_budget'])}"
    assert fm["token_budget"]["L1_core"] == 800
    assert fm["token_budget"]["hard_cap"] == 4000
    print("  ✅ test_parse_nested_field")


def test_parse_multiline_text():
    """测试多行文本 | 解析"""
    content = """---
name: test
description: |
  第一行描述
  第二行描述
  第三行描述
---
body"""
    fm = parse_frontmatter(content)
    assert "第一行描述" in fm["description"], f"Expected multiline, got '{fm['description']}'"
    assert "第三行描述" in fm["description"]
    print("  ✅ test_parse_multiline_text")


def test_frontmatter_contains():
    """测试精确字段存在性检查"""
    content = """---
name: test
version: "1.0.0"
triggers:
  - 触发词
token_budget:
  L0_trigger: 100
---
body中提到了version这个词"""
    assert frontmatter_contains(content, "name") is True
    assert frontmatter_contains(content, "version") is True
    assert frontmatter_contains(content, "triggers") is True
    assert frontmatter_contains(content, "token_budget") is True
    assert frontmatter_contains(content, "data_sources") is False
    assert frontmatter_contains(content, "body") is False  # 不匹配正文
    print("  ✅ test_frontmatter_contains")


def test_get_field():
    """测试字段值获取"""
    content = """---
name: test
version: "2.0.0"
triggers:
  - a
  - b
---
body"""
    assert get_field(content, "version") == "2.0.0"
    assert get_field(content, "triggers") == ["a", "b"]
    assert get_field(content, "nonexistent") is None
    print("  ✅ test_get_field")


# ============================================================
# verify detect_template 测试
# ============================================================

def test_detect_template_multi_scene_no_data():
    """测试工具型 multi-scene 检测（king 自身场景）"""
    from lib.yaml_parser import detect_template
    
    with tempfile.TemporaryDirectory() as tmpdir:
        skill_path = Path(tmpdir)
        # 创建 king 自身的结构：有 DESIGN.md 但无 data/
        (skill_path / "SKILL.md").write_text("""---
name: test
version: "1.0.0"
---
body""", encoding="utf-8")
        (skill_path / "DESIGN.md").write_text("# Design", encoding="utf-8")
        (skill_path / "SPEC.md").write_text("# Spec", encoding="utf-8")
        (skill_path / "config.yaml").write_text("key: value", encoding="utf-8")
        
        template = detect_template(skill_path)
        assert template == "multi-scene", f"Expected 'multi-scene', got '{template}'"
    print("  ✅ test_detect_template_multi_scene_no_data")


def test_detect_template_data_driven():
    """测试 data-driven 检测"""
    from lib.yaml_parser import detect_template
    
    with tempfile.TemporaryDirectory() as tmpdir:
        skill_path = Path(tmpdir)
        (skill_path / "SKILL.md").write_text("---\nname: test\n---\nbody", encoding="utf-8")
        (skill_path / "data").mkdir()
        (skill_path / "data" / "sources.yaml").write_text("sources: {}", encoding="utf-8")
        (skill_path / "SPEC.md").write_text("# Spec", encoding="utf-8")
        
        template = detect_template(skill_path)
        assert template == "data-driven", f"Expected 'data-driven', got '{template}'"
    print("  ✅ test_detect_template_data_driven")


def test_detect_template_basic():
    """测试 basic 检测"""
    from lib.yaml_parser import detect_template
    
    with tempfile.TemporaryDirectory() as tmpdir:
        skill_path = Path(tmpdir)
        (skill_path / "SKILL.md").write_text("---\nname: test\n---\nbody", encoding="utf-8")
        
        template = detect_template(skill_path)
        assert template == "basic", f"Expected 'basic', got '{template}'"
    print("  ✅ test_detect_template_basic")


# ============================================================
# update_skill 版本号修复测试
# ============================================================

def test_update_spec_version_not_hardcoded():
    """测试 update_spec 使用 new_version 而非硬编码 V0.1.0"""
    from update_skill import update_spec
    
    with tempfile.TemporaryDirectory() as tmpdir:
        skill_path = Path(tmpdir)
        spec_content = f"""# Test — SPEC

## 版本历史

| 版本 | 日期 | 变更摘要 |
|------|------|---------|
| V1.0.0 | 2026-01-01 | 初始 |

## 非功能需求

test
"""
        (skill_path / "SPEC.md").write_text(spec_content, encoding="utf-8")
        
        changes = [{"type": "add_source", "detail": {"source_id": "test"}}]
        update_spec(skill_path, changes, reason="测试", new_version="1.3.0")
        
        result = (skill_path / "SPEC.md").read_text(encoding="utf-8")
        assert "V1.3.0" in result, f"Expected 'V1.3.0' in SPEC, not found"
        assert "V0.1.0" not in result, f"Found hardcoded 'V0.1.0' in SPEC!"
    print("  ✅ test_update_spec_version_not_hardcoded")


def test_update_design_version_history():
    """测试 update_design 更新版本历史"""
    from update_skill import update_design
    
    with tempfile.TemporaryDirectory() as tmpdir:
        skill_path = Path(tmpdir)
        design_content = f"""# Test — DESIGN

## 版本历史

| 版本 | 日期 | 变更摘要 |
|------|------|---------|
| V1.0.0 | 2026-01-01 | 初始 |

## 模块关系

test
"""
        (skill_path / "DESIGN.md").write_text(design_content, encoding="utf-8")
        
        update_design(skill_path, "add_source", {"source_id": "test"}, reason="测试", new_version="1.3.0")
        
        result = (skill_path / "DESIGN.md").read_text(encoding="utf-8")
        assert "V1.3.0" in result, f"Expected 'V1.3.0' in DESIGN, not found"
        assert "ADR-" in result, f"Expected ADR entry in DESIGN"
    print("  ✅ test_update_design_version_history")


# ============================================================
# 运行所有测试
# ============================================================

if __name__ == "__main__":
    print("yaml_parser 测试:")
    test_parse_simple_fields()
    test_parse_list_field()
    test_parse_nested_field()
    test_parse_multiline_text()
    test_frontmatter_contains()
    test_get_field()
    
    print("\nverify detect_template 测试:")
    test_detect_template_multi_scene_no_data()
    test_detect_template_data_driven()
    test_detect_template_basic()
    
    print("\nupdate_skill 修复测试:")
    test_update_spec_version_not_hardcoded()
    test_update_design_version_history()
    
    print("\n✅ 所有 11 个测试通过！")
