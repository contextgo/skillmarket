# Changelog

All notable changes to skill-creator-king will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/), with additional
**reason** and **no-revert** markers to prevent regression.

## [2.1.0] - 2026-05-03（首次发布到 SkillHub）

### Added
- ❗ 五阶段工程化工作流：PRESCAN→DISCUSS→DESIGN→BUILD→VERIFY→EVOLVE
  - **原因**: 替代单阶段脚手架模式，确保先讨论再动手，每一步可追溯
  - **勿回退**: 缺少任一阶段的 skill 创建流程不可控
- ❗ 三种模板：basic / data-driven / multi-scene
  - **原因**: 不同复杂度的 skill 需要不同骨架，basic 不应生成多余的 data/ 目录
  - **勿回退**: 单一通用模板会导致 basic skill 冗余
- ❗ 三级加载 Token 架构：L0 frontmatter 匹配 → L1 <800 token body 路由 → L2 references 按需加载
  - **原因**: 全量加载浪费 token，分级加载让 90% 匹配在前两级结束
  - **勿回退**: 臃肿的 SKILL.md 消耗每一调用
- ❗ 自反思循环（Ralph Loop）：DESIGN/VERIFY 阶段双层自检 + 收敛检测，最多 3 轮
  - **原因**: AI 一次性输出常有遗漏，先自检再交用户不把人当第一道 QA
  - **勿回退**: 无自检的流程产出质量不可控
- ❗ 10 维度质量验证：加权评分（结构/元数据/文档/代码化/一致性/脚本/质量保障/数据层/Token/可维护性），≥75 合格
  - **原因**: 统一创建+验证，避免需要多个 skill 配合
  - **勿回退**: 单维度评分不足以覆盖完整质量
- ❗ 双层持续进化：L1 进化规则体系 + L2 进化目标 Skill，归因决策树先行
  - **原因**: 反馈不归因大概率改错对象
  - **勿回退**: 单层进化无法处理目标 skill 的改进需求
- ❗ 四层文档体系：README.md（人类入口）→ SKILL.md（AI 入口）→ SPEC.md（需求契约）→ DESIGN.md（架构决策）
  - **原因**: 不同受众需要不同视角的文档，混淆一起各看各不是
  - **勿回退**: 单一文档无法满足双受众需求，变更无法追溯
- ❗ 声明式数据源管理 + 缓存复用 + 配置分离
  - **原因**: 脚本硬编码 URL 和阈值导致每次调整需改代码
  - **勿回退**: 硬编码阈值的 skill 维护成本线性增长
- ❗ 三种模式分层：快速/标准/专业贯穿全流程
  - **原因**: 简单项目不劝退，复杂项目不妥协
  - **勿回退**: 单一模式无法兼顾不同复杂度
- ❗ 模板默认行为契约：产出的每个 Skill 自带不越界/不编造/结论前置的行为底线
  - **原因**: 最差情况下也保证产出 skill 有行为底线
  - **勿回退**: 模板不参与行为约束 = skill 行为裸奔
- ❗ PRESCAN 前置审计：每次加载自动扫描文件完整性和版本一致性
  - **原因**: AI 自觉不可靠，程序化检查不可跳过
  - **勿回退**: 无前置审计的流程靠自觉发现遗漏
- ❗ 版本同步清单：版本号出现位置显式声明，升级时四处同步
  - **原因**: 版本升级常遗漏同步部分文件
  - **勿回退**: 无同步清单的 skill 在迭代中必然版本碎片
