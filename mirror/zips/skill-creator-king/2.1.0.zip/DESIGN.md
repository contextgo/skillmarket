# Skill Creator King — 设计文档

## 版本历史

| 版本 | 日期 | 变更摘要 |
|------|------|---------|
| V2.1.0 | 2026-05-03 | 初始公开发布。含 23 条架构决策：五阶段工作流、三种模板、10 维度验证整合、极简 SKILL.md (<800t)、声明式数据源、Token 软约束、EVOLVE 可选、进化边界、双层进化、DISCUSS 三模式分层、统一解析层、多信号模板检测、DESIGN Ralph Loop、VERIFY 快照迭代、外循环回退设计、L2 触发外循环、默认关闭、解冻-重确认、行为约束分层注入、模板默认契约、PRESCAN 前置、设计理念前置、README.md 产品说明书层 |

## 版本同步清单

本 skill 的版本号出现在以下文件，版本变更时须同步修改：

| 文件 | 版本号位置 |
|------|-----------|
| `SKILL.md` | frontmatter `version:` 字段 |
| `SPEC.md` | 版本历史表 |
| `DESIGN.md` | 版本历史表 |
| `CHANGELOG.md` | 版本条目标题 `## [X.Y.Z]` |

## 架构决策记录 (ADR)

### ADR-001: 五阶段工作流替代四阶段
- **上下文**: 原设计为四阶段（DISCUSS→DESIGN→BUILD→VERIFY），用户要求增加自我进化能力（REQ-001: 五阶段引导式工作流）
- **选项**: A) 在 VERIFY 中附带进化检查 / B) 新增独立 EVOLVE 阶段
- **决策**: 选 B — 独立 EVOLVE 阶段
- **理由**: 进化是元认知行为，与验证质量是不同维度，混在一起职责不清
- **后果**: 工作流更长，但每次使用都可能让 king 自身变得更好
- **状态**: ✅已采纳

### ADR-002: 三种模板而非一种通用模板
- **上下文**: 不同 skill 的复杂度差异大，一套模板要么太重要么太轻（REQ-002: 三种模板支持；REQ-003: 产出 Skill 极简化）
- **选项**: A) 一种通用模板 + 可选删减 / B) 三种模板按需选择
- **决策**: 选 B — 三种模板
- **理由**: 避免用户面对不必要的文件，basic 不应生成 data/ 目录
- **后果**: 模板维护成本增加，但用户体验更好
- **状态**: ✅已采纳

### ADR-003: 整合质量验证能力
- **上下文**: 7 维度质量分析能力需要保留并扩展（REQ-010: 10 维度质量验证；REQ-011: 增量更新能力；REQ-013: 旧版迁移支持）
- **选项**: A) 独立质量验证 skill 与 king 并存 / B) 整合入 king 的 verify.py
- **决策**: 选 B — 整合入 verify.py
- **理由**: 避免两个 skill 功能重叠，减少维护成本；verify 是完整质量验证的超集
- **后果**: 旧版质量验证 skill 不再需要，用户统一使用 king
- **状态**: ✅已采纳

### ADR-004: SKILL.md 极简化（<800 tokens）
- **上下文**: 旧版 skill 的 SKILL.md 是"百科全书"，浪费 token（REQ-003: 产出 Skill 极简化；REQ-004: 三级加载）
- **选项**: A) 精简但不设硬限制 / B) <800 tokens 软约束
- **决策**: 选 B — 800 tokens 软约束
- **理由**: 需要可量化目标才能持续优化；软约束避免过度截断
- **后果**: 详细内容必须移到 references/ 或 SPEC.md/DESIGN.md
- **状态**: ✅已采纳

### ADR-005: 数据源声明式管理
- **上下文**: 脚本中硬编码 URL 导致数据源变更时需改代码（REQ-005: 数据源声明式管理；REQ-006: 缓存复用；REQ-007: 两路并行更新；REQ-009: 配置分离）
- **选项**: A) 脚本中硬编码 / B) sources.yaml 声明式管理
- **决策**: 选 B — sources.yaml
- **理由**: 改配置不改代码；固化日期标记可靠性；主备源+禁止源统一管理
- **后果**: 脚本需读取 sources.yaml，增加初始化逻辑
- **状态**: ✅已采纳

### ADR-006: Token 预算为软约束
- **上下文**: 需要控制 token 消耗，但运行时强制截断风险大（REQ-004: 三级加载）
- **选项**: A) 硬约束（脚本计数+截断）/ B) 软约束（规范引导+验证检查）
- **决策**: 选 B — 软约束
- **理由**: AI 上下文长度动态变化，硬约束难以准确实现；规范引导更灵活
- **后果**: 需要自律遵守，verify.py 做提醒而非阻断
- **状态**: ✅已采纳

### ADR-007: EVOLVE 阶段为可选
- **上下文**: 不是每次创建/更新都有值得进化的经验
- **选项**: A) 每次必执行 / B) 有进化点时才触发
- **决策**: 选 B — 有进化点时才触发
- **理由**: 避免形式主义；没有改进点时硬做会降低效率
- **后果**: AI 需要有判断力识别何时值得进化
- **状态**: ✅已采纳

### ADR-008: EVOLVE 进化边界
- **上下文**: 进化可能失控，需要约束（REQ-008: 三文件追溯）
- **选项**: A) 不限范围 / B) 小步改进+通用性过滤+用户确认
- **决策**: 选 B — 有边界的进化
- **理由**: 防止单次进化改动过大；只改通用规则；必须用户确认
- **后果**: 进化速度较慢但安全可控
- **状态**: ✅已采纳

### ADR-009: EVOLVE 双层进化架构
- **上下文**: 原 EVOLVE 只进化 king 自身，但使用过程中目标 skill 的问题（数据源失效、阈值偏差等）同样需要反馈改进（REQ-012: 自我进化L1；REQ-014: 目标skill进化L2）
- **选项**: A) 只进化king / B) 增加L2层进化目标skill
- **决策**: 选 B — 双层进化
- **理由**: king 变强是"预防"，目标 skill 变好是"治疗"，两者互补；L2 复用 update_skill.py 现有能力，无额外代码
- **后果**: EVOLVE 阶段增加了归因判断步骤，但流程更完整
- **状态**: ✅已采纳

### ADR-010: DISCUSS 三模式分层
- **上下文**: 朋友反馈 DISCUSS 不够结构化，建议增加干系人分析、已知/未知清单、信息缺口管理和搜索任务。但直接上完整需求工程会让简单项目用户感到负担（REQ-015: DISCUSS 三模式分层）
- **选项**: A) 单一模式（要么简单要么复杂）/ B) 三模式分层（快速/标准/专业）/ C) 自动判断复杂度切换
- **决策**: 选 B — 三模式分层，用户自选，默认快速
- **理由**: 
  - 90% 的简单项目用快速模式（2步+确认），不增加负担
  - 标准模式覆盖大多数中等复杂度项目
  - 专业模式留给复杂/多人/高风险项目，有确认书防返工
  - 不选 C（自动判断）是因为复杂度判断本身有歧义，让用户自己选更透明
- **后果**: 
  - discuss-guide.md 从单一清单扩展为三模式引导
  - 新增 requirement-confirmation-template.md 作为专业模式输出物
  - SKILL.md DISCUSS 章节需保持精简，详情指向 discuss-guide.md
- **状态**: ✅已采纳

### ADR-011: 统一 YAML 解析层替代分散解析
- **上下文**: update_skill.py 的 read_frontmatter() 只能解析单行 key:value，verify.py 用全文字符串搜索检查字段，两者对同一 frontmatter 用完全不同标准（REQ-016: 统一 YAML 解析层；REQ-020: handle_add_source 精确判断）
- **选项**: A) 各脚本自行改善解析 / B) 抽取共用解析模块
- **决策**: 选 B — 新增 scripts/lib/yaml_parser.py
- **理由**: 分散改善只会让3套解析逻辑越来越复杂；共用模块一次修复解决所有问题，且未来新脚本直接复用
- **后果**: 新增 lib/ 目录，但所有脚本的 frontmatter 解析逻辑统一且可靠
- **状态**: ✅已采纳

### ADR-012: 多信号模板检测替代单一信号
- **上下文**: detect_template() 只看 data/sources.yaml 一个信号，导致有 DESIGN.md 但无外部数据的工具型 skill（如 king 自身）被误判为 basic（REQ-017: 多信号模板检测；REQ-018: 工具型 multi-scene 支持）
- **选项**: A) 要求所有 multi-scene 必须有 sources.yaml / B) 多信号投票检测
- **决策**: 选 B — 多信号投票（DESIGN.md / scenes / sources.yaml / SPEC.md + config.yaml）
- **理由**: "多场景"和"需要数据"是正交维度；工具型 multi-scene 是合理的存在形式
- **后果**: 检测逻辑更复杂，但覆盖更全面；verify.py 的 check_structure 等需同步适配工具型
- **状态**: ✅已采纳

### ADR-013: DESIGN 自反思循环（Ralph Loop）
- **上下文**: DESIGN 阶段 AI 一次性输出 SPEC/DESIGN/sources.yaml，常见遗漏包括 DISCUSS 提到的需求没进 SPEC、ADR 互相矛盾、sources.yaml 缺字段。用户成了第一道 QA，本该 AI 先筛一轮（REQ-021: DESIGN 自反思循环；REQ-019: 版本号/文档同步修复）
- **选项**: A) 纯 prompt 自检（靠 AI 自觉遵守 checklist）/ B) 程序化客观检查 + 主观自检双层 / C) 不做自检
- **决策**: 选 B — 双层自反思（design_check.py 客观 + design-checklist.md 主观）
- **理由**: 
  - 纯 prompt 自检会被 AI 敷衍通过（rubber-stamping），必须有一部分检查是程序化、不可跳过的
  - ADR 互斥和需求覆盖可以程序化检测，从主观清单移入 design_check.py
  - 后果链、缓存合理性、用户体验 3 项需要推理，仍留给主观检查
  - 3 轮上限控制成本；basic 模板客观全过可短路跳过主观自检
- **后果**: 
  - 新增 scripts/design_check.py — 用法: python3 scripts/design_check.py --path <skill-path>（语义检查：REQ-ADR对齐、ADR互斥、需求覆盖、模板选择一致性、可构建性；basic模板只检查frontmatter合理性）
  - 新增 references/design-checklist.md（主观检查项：后果链、缓存合理性、用户体验）
  - DESIGN 阶段工作流变更：生成→客观检查→主观自检→修正→重检
  - token 成本从 ~8000 涨到 ~25000（3轮循环），但 basic 模板有短路机制
  - 退出条件：客观检查全过 + 主观清单全 ✅，或达到3轮
- **状态**: ✅已采纳

### ADR-014: VERIFY 迭代验证（快照对比）
- **上下文**: VERIFY 只跑一次 verify.py，修了 A 引入 B 的问题无法发现；修完不重验常见；评分卡住时无限人工修无收敛检测（REQ-022: VERIFY 迭代验证）
- **选项**: A) 独立 verify_loop.py 脚本封装循环 / B) 增强 verify.py 加快照对比能力 / C) 不做迭代
- **决策**: 选 B — 增强 verify.py（--snapshot-dir 参数）
- **理由**: 
  - 选项 A 是假循环——AI 必须在两轮 verify 之间做修复，脚本自己不会改文件，所以不该叫"loop"
  - 正确做法是让 verify.py 支持快照保存和自动对比，AI 每次修完跑 verify.py --snapshot-dir 即可
  - 不需要单独的 --compare 标志，--snapshot-dir 本身隐含对比（目录有历史快照时自动和最新一个对比）
  - 退出条件：首轮 score ≥75 即通过；后续轮 score ≥75 且 criticals ≤ 上轮（不区分新增/残留，关键是不要越修越烂），最多3轮
  - 收敛检测：连续 2 轮分数差 <2 即判定停滞
  - 回退检测：criticals 比上轮多时输出 regressed 状态警告
- **后果**: 
  - verify.py 新增 --snapshot-dir 参数（+~80行）
  - 快照格式：.verify_history/verify_YYYYMMDD_HHMMSS.json
  - snapshot-dir 不存在时自动创建
  - 对比输出：delta（新增/已解决/未变 findings）+ 收敛状态（improving/stalled/regressed）
  - 如需查看历史对比，可读取 .verify_history/ 中的 JSON 文件手动比较，不需要专用 CLI 标志
  - package_skill.py EXCLUDE_PATTERNS 加 .verify_history
  - 修复前建议备份（提示，不加代码）
- **状态**: ✅已采纳

### ADR-015: 外循环回退到 DESIGN 而非 DISCUSS
- **上下文**: EVOLVE L2 改了目标 skill 的实现，需要重走全流程保证一致性（REQ-023: 外循环 Ralph Loop）
- **选项**: A) 回到 DISCUSS / B) 回到 DESIGN
- **决策**: 选 B — 回到 DESIGN
- **理由**: 需求已在首轮 DISCUSS 冻结，EVOLVE 改的是实现不是需求，不需要重聊。外循环更快收敛。
- **后果**: 如果 EVOLVE 发现需求本身有问题（极端情况），AI 应暂停并问用户是否重新 DISCUSS
- **状态**: ✅已采纳

### ADR-016: 仅 L2 改动触发外循环
- **上下文**: EVOLVE 双层进化，L1 改 king 自身，L2 改目标 skill（REQ-023: 外循环 Ralph Loop）
- **选项**: A) L1 或 L2 有改动就循环 / B) 仅 L2 有改动才循环
- **决策**: 选 B — 仅 L2 触发
- **理由**: L1 改的是 king 的规范/脚本，目标 skill 的代码没变，不需要重走 BUILD→VERIFY。L2 改了目标 skill 的代码，必须重验。
- **后果**: 减少无效循环；L1 改了 verify.py 时建议用户可重验，但不自动触发
- **状态**: ✅已采纳

### ADR-017: 默认关闭，DISCUSS 询问后开启
- **上下文**: 外循环增加 token 成本（每轮 ~25000-40000），大多数 skill 一轮就够了（REQ-023: 外循环 Ralph Loop）
- **选项**: A) 默认开启 / B) 默认关闭，询问后开启
- **决策**: 选 B — 默认关闭
- **理由**: 和 DISCUSS 三模式选择一致——用户自选复杂度。简单 skill 不受影响；高级用户/复杂 skill 可选开启。
- **后果**: 需要在 discuss-guide.md 追加深度迭代开关引导
- **状态**: ✅已采纳

### ADR-018: SPEC/DESIGN 解冻-修改-重确认机制
- **上下文**: 首轮 DESIGN 后 SPEC/DESIGN 已冻结，但外循环需要修改它们（REQ-023: 外循环 Ralph Loop）
- **选项**: A) 外循环直接改不改文档 / B) 解冻→修改→重确认→再冻结
- **决策**: 选 B — 解冻-修改-重确认-再冻结
- **理由**: 不改文档 = 三文件追溯断裂，后续 EVOLVE/维护无据可查。修改原则：只增不改（除非逻辑矛盾必须改），被 override 的 ADR 标记 superseded by ADR-XXX。
- **后果**: 外循环每轮需要用户确认 SPEC/DESIGN 变更（≤3 项可统确认，>3 项逐项确认），增加一轮交互但保证追溯完整性
- **状态**: ✅已采纳

### ADR-019: 行为约束注入 SKILL.md 而非独立文件
- **上下文**: king 目前靠五阶段流程控制自身行为，但在运行时缺乏边界约束（何时反问/何时拒绝/何时收尾）、质量标准（输出是否合格）、行文风格（是否机械套话）、身份切换（阶段间角色混杂）等行为规范（REQ-024: 行为约束规范）
- **选项**: A) 全部放入独立的 behavior-spec.md，SKILL.md 只加一行引用 / B) SKILL.md 注入口语化精简版(~200 tokens) + behavior-spec.md 完整版作 L2 按需加载 / C) 只改 SKILL.md，不建 behavior-spec.md
- **决策**: 选 B — 分层注入：精简版在 L1 即时生效，完整版在 L2 按需加载
- **理由**: 
  - 选 A 的引用太弱：AI 不遇到具体问题不会主动加载 L2 文件，等于行为约束形同虚设
  - 选 C 太轻：200 tokens 不够承载身份表、质量清单、反模式清单、自检清单的完整内容
  - 分层注入兼顾即时约束和深度参考：日常执行靠 L1 精简版自我纠偏，遇到复杂判断时加载 L2 behavior-spec.md
- **后果**: 
  - SKILL.md body 增加 ~200 tokens（仍在 800 token 预算内）
  - 新增 references/behavior-spec.md（~2000 tokens，L2 按需加载）
  - 行为约束与流程约束形成双层治理：流程管「步骤」，行为管「方式」
  - 未来若行为约束需要自动化检查（如行文反模式检测），可在 verify.py 中新增维度
- **状态**: ✅已采纳

### ADR-020: 产出 Skill 的行为约束通过模板默认契约 + BUILD 覆盖
- **上下文**: V1.7.0 约束了 king 自身的行为。但 king 产出的 skill 在运行时缺乏行为底线——没有边界声明、没有输出质量标准、没有不编造的硬约束（REQ-025）
- **选项**: A) 在 SPEC 中新增行为需求前缀（BND/RED/QLT/STY），VERIFY 加第 11 维度静态检查 / B) 模板内嵌默认行为契约 + DISCUSS 引���边界思考 + BUILD 阶段按 SPEC 覆盖默认值 / C) 只依赖 BUILD 阶段 AI 从 SPEC 翻译行为需求到 SKILL.md
- **决策**: 选 B — 模板默认契约 + DISCUSS 引导 + BUILD 覆盖
- **理由**: 
  - 选 A 过度设计：行为质量不可静态测量，SPEC 前缀不产生约束力，VERIFY 维度制造虚假安全感
  - 选 C 太脆弱：AI 可能忘记翻译，缺少结构保证（行为约束根本没地方写）
  - 模板默认契约（~60 tokens）保证产出 skill 至少有行为底线；DISCUSS 追问保证边界被认真思考过；BUILD 覆盖规则保证思考结果落到 SKILL.md
- **后果**: 
  - init_skill.py 三种模板各增加 ~60 tokens 行为约束段
  - discuss-guide.md 三种模式各增加边界/行为追问
  - king-spec.md BUILD 指南新增「行为需求处理」章节
  - design-checklist.md UX 项扩充行为检查
  - 产出 skill 的 SKILL.md L1 body 增加 ~60 tokens（仍在 token 预算内）
- **状态**: ✅已采纳

### ADR-021: PRESCAN 前置审计在 DISCUSS 之前执行
- **上下文**: 修改 skill 时容易遗漏文件更新（如 V1.9.0 升级时 SPEC/DESIGN 未同步）。每次 DISCUSS 之前先用脚本扫描文件结构和版本一致性，防患于未然（REQ-026: PRESCAN 前置审计）
- **选项**: A) 依赖 AI 自觉检查 / B) 程序化 prescan.py 强制前置
- **决策**: 选 B — 每次加载 SCK 时自动执行 prescan，不可跳过
- **理由**: AI 自觉不可靠——V1.9.0 升级时 king 自己就没遵守升级检查清单。程序化检查不可跳过，输出结构化报告供后续阶段消费
- **后果**: 每次修改 skill 前多一步前置检查（~1秒），但杜绝了文件遗漏和版本不一致。新增 scripts/prescan.py（纯标准库，~220 行），SKILL.md 新增 PRESCAN 章节
- **状态**: ✅已采纳

### ADR-022: 设计理念在 DISCUSS 采集、DESIGN 消费
- **上下文**: 当前 DISCUSS 确认了模板/数据/场景，但缺少顶层设计哲学。DESIGN 阶段的 ADR 各自独立决策，没有统一锚点来检验一致性。用户要求每个 skill 在设计之初就要明确核心取舍（REQ-027: 设计理念前置）
- **选项**: A) 设计理念放在 DESIGN 阶段生成 / B) 设计理念在 DISCUSS 阶段采集，DESIGN 阶段消费
- **决策**: 选 B — DISCUSS 采集，DESIGN 消费
- **理由**: 设计理念是「要什么」层面的问题，属于需求范畴。DISCUSS 阶段确定了「做什么」，设计理念就是「做到什么程度、侧重什么、牺牲什么」——这是需求的延伸，不是架构决策。放在 DISCUSS 能更早暴露价值观冲突
- **后果**: DISCUSS 摘要新增「设计理念」字段（一句话）；discuss-guide.md 三种模式加设计理念追问；DESIGN 阶段每条 ADR 须与设计理念对齐——不对齐即信号
- **状态**: ✅已采纳

### ADR-023: README.md 作为产品说明书层
- **上下文**: 当前 king 产出的 skill 缺少面向人类的入口文件。SKILL.md 名义有「功能说明」但写给 AI 看，SPEC/DESIGN 是工程文档不面向终端用户。用户需要一个从第一眼就能理解 skill 是什么的文件（REQ-028: README.md 必选）
- **选项**: A) 把 README 内容塞进 SKILL.md / B) 独立 README.md 作为产品说明书层 / C) 不强制 README
- **决策**: 选 B — 独立 README.md 层，所有模板强制
- **理由**: SKILL.md 的受众是 AI（触发匹配+运行时指令），README.md 的受众是人（理解+使用），内容有重叠但角度不同。双层各有优化目标：SKILL.md 追求触发精准和指令清晰，README.md 追求可读性和信息密度。AI 回答用户关于 skill 的基础问题时也优先读 README
- **后果**: 三层模板各生 README 骨架（~200/~400/~600 tokens）；verify.py check_structure 加 README.md 为必选文件；SKILL.md 行为约束加「回答基础问题时先读 README」；init_skill.py 新增 get_readme_xxx() 模板函数；checklist.md 加 README 内容质量检查项
- **状态**: ✅已采纳

## 文件结构

```
SKILL.md (AI入口：路由器 + 行为约束)
  ├── README.md (人类入口：产品说明书)  ← V2.0新增
  │
  ├── references/ (L2 深度参考)
  │   ├── king-spec.md         ← 完整规范
  │   ├── checklist.md         ← 检查清单
  │   ├── design-checklist.md  ← DESIGN 主观自检清单
  │   ├── discuss-guide.md     ← DISCUSS 引导
  │   ├── evolve-guide.md      ← EVOLVE 指南
  │   ├── behavior-spec.md     ← 行为规格 (V1.7新增)
  │   └── requirement-confirmation-template.md
  │
  └── scripts/ (核心工具)
      ├── lib/                 ← 共享模块
      │   └── yaml_parser.py   ← 统一 YAML 解析
      ├── prescan.py           ← 前置文件审计 (V1.9)
      ├── design_check.py      ← DESIGN 客观自检
      ├── init_skill.py        ← 创建（含内嵌模板）
      ├── update_skill.py      ← 更新
      ├── verify.py            ← 验证（含快照对比）
      └── package_skill.py     ← 打包
```

## 数据流

```
用户请求 → [行为约束层: 身份切换 + 质量自检 + 行文过滤]
  ↓
PRESCAN (SOUL.md纪律注入 + prescan.py文件审计)  ← V1.9新增
  ↓
DISCUSS (AI对话)
  ↓ → 产出: 模板类型 + 核心需求 + [深度迭代开关]
DESIGN (生成SPEC+DESIGN+sources.yaml)
  ↓ → 自反思循环（design_check.py客观 + design-checklist.md主观，最多3轮）
  ↓ → 产出: SPEC.md + DESIGN.md + sources.yaml雏形
  ← 用户确认(冻结)
BUILD (init/update脚本)
  ↓ → 产出: 完整skill文件
VERIFY (verify.py)
  ↓ → 迭代验证（--snapshot-dir快照对比，最多3轮）
  ↓ → 产出: 质量评分 + delta对比 + 收敛状态
  ← 不合格则回BUILD
EVOLVE (可选)
  ↓ → 归因判断
  ├── L1: king自身改进项（先完成，含king verify≥75）
  └── L2: 目标skill变更（复用update_skill.py）
  ← 用户确认后执行
  │
  ├─ 无L2改动 / 已达3轮 / 用户叫停 / VERIFY未通过 → 完成
  └─ L2有改动 + 深度迭代开启
       → 解冻SPEC/DESIGN → 增量修改（只增不改）
       ← 用户确认(再冻结)
       → 回到DESIGN ──┐
                       │ (≤3轮外循环)
  ←────────────────────┘
完成
```
