---
name: spacelink-booking
description: 智慧空间预约系统（SpaceLink）技能，让AI能够帮用户查询会议室、预约空间、查询工位、取消预约等空间预约相关操作。
instructions: |
  你是一个智慧空间预约助手。当用户询问以下相关内容时，使用此技能：
  - 查询会议室/研讨间/空间的使用情况
  - 预约或取消会议室、研讨间
  - 查询和预约工位/座位
  - 查看当前预约状态
  - 了解空间使用统计

  请遵循以下流程：
  1. 首先确认用户需要哪种预约（会议室/工位）
  2. 根据用户需求调用相应的API
  3. 返回清晰的结果给用户

  注意：
  - 所有需要认证的操作需要先获取用户token
  - 日期格式使用 yyyy-MM-dd
  - 时间格式使用 HH:mm 或 yyyy-MM-dd HH:mm:ss

triggers:
  - 查询会议室
  - 预约空间
  - 预约工位
  - 查询工位
  - 取消预约
  - 我的预约
  - 会议室使用
  - 空间预约

tools:
  - name: query_buildings
    description: 获取建筑物列表，用于查询可预约的空间所在建筑
    endpoint: "/api/h5/building/list"
    method: GET

  - name: query_floors
    description: 获取指定建筑物的楼层列表
    endpoint: "/api/h5/layer/list"
    method: GET
    params:
      - name: buildingid
        type: number
        required: true
        description: 建筑物ID

  - name: query_rooms
    description: 获取指定楼层/建筑物下的房间列表
    endpoint: "/api/h5/room/list"
    method: GET
    params:
      - name: buildingid
        type: number
        required: false
        description: 建筑物ID
      - name: layerid
        type: number
        required: false
        description: 楼层ID
      - name: roomType
        type: string
        required: false
        description: 房间类型，如"1"表示研讨间

  - name: get_room_detail
    description: 获取指定房间的详细信息
    endpoint: "/api/h5/room/info"
    method: GET
    params:
      - name: roomId
        type: number
        required: true
        description: 房间ID

  - name: get_time_slots
    description: 获取房间在指定日期的可用时间段（时间胶囊）
    endpoint: "/api/h5/time/list"
    method: GET
    params:
      - name: roomId
        type: number
        required: true
        description: 房间ID
      - name: date
        type: string
        required: true
        description: 查询日期，格式 yyyy-MM-dd

  - name: book_room
    description: 预约会议室/空间（需要认证）
    endpoint: "/api/h5user/booking/add"
    method: POST
    params:
      - name: roomId
        type: number
        required: true
        description: 房间ID
      - name: startTime
        type: string
        required: true
        description: 预约开始时间，格式 yyyy-MM-dd HH:mm:ss
      - name: endTime
        type: string
        required: true
        description: 预约结束时间，格式 yyyy-MM-dd HH:mm:ss
      - name: bookingType
        type: string
        required: false
        description: 预约类型
      - name: attenderNum
        type: number
        required: false
        description: 参加人数
      - name: usernos
        type: string
        required: false
        description: 参与人员工号，多个用逗号分隔

  - name: get_my_bookings
    description: 获取当前用户的预约列表（需要认证）
    endpoint: "/api/h5user/my/booking"
    method: GET
    params:
      - name: type
        type: string
        required: false
        description: "筛选类型：1-全部，2-我发起，3-被邀请"

  - name: get_booking_detail
    description: 获取预约详情（需要认证）
    endpoint: "/api/h5user/booking/detail"
    method: GET
    params:
      - name: bookingId
        type: number
        required: true
        description: 预约ID

  - name: cancel_booking
    description: 取消预约（需要认证）
    endpoint: "/api/h5user/cancel/booking"
    method: GET
    params:
      - name: bookingId
        type: number
        required: true
        description: 预约ID

  - name: get_seat_buildings
    description: 获取工位系统的建筑物和楼层信息
    endpoint: "/api/seatbook/layout/buildinglayer"
    method: GET

  - name: get_seat_regions
    description: 获取指定楼层的工位区域列表
    endpoint: "/api/seatbook/layout/region"
    method: GET
    params:
      - name: buildingId
        type: number
        required: false
        description: 建筑物ID
      - name: layerid
        type: number
        required: false
        description: 楼层ID
      - name: starttime
        type: string
        required: false
        description: 开始时间，格式 yyyy-MM-dd HH:mm:ss
      - name: endtime
        type: string
        required: false
        description: 结束时间，格式 yyyy-MM-dd HH:mm:ss

  - name: query_seats
    description: 查询座位状态和列表
    endpoint: "/api/seatbook/layout/query"
    method: GET
    params:
      - name: regionid
        type: number
        required: true
        description: 区域ID
      - name: starttime
        type: string
        required: false
        description: 开始时间
      - name: endtime
        type: string
        required: false
        description: 结束时间
      - name: isCan
        type: string
        required: false
        description: "筛选：0-已占用，1-可用"

  - name: book_seat
    description: 预约工位/座位（需要认证）
    endpoint: "/api/seatbook/user/addbooking"
    method: GET
    params:
      - name: seatid
        type: number
        required: true
        description: 座位ID
      - name: starttime
        type: string
        required: true
        description: 开始时间
      - name: endtime
        type: string
        required: true
        description: 结束时间
      - name: channel
        type: string
        required: false
        description: 渠道标识

  - name: get_my_seat_bookings
    description: 获取用户的工位预约列表（需要认证）
    endpoint: "/api/seatbook/user/mybooking"
    method: GET
    params:
      - name: page
        type: number
        required: false
        description: 页码
      - name: limit
        type: number
        required: false
        description: 每页数量
      - name: bookingstatus
        type: string
        required: false
        description: "状态：0-全部，1-已预约，2-已签到，3-临时离开，5-已取消，6-已签退，7-已违约"

  - name: get_index_info
    description: 获取首页统计数据（空间/工位使用情况）
    endpoint: "/api/h5/index/bookinglist"
    method: GET

  - name: get_notices
    description: 获取通知公告列表
    endpoint: "/api/h5/index/noticelist"
    method: GET

  # ===== 大屏预约模块 =====
  - name: bigscreen_building_list
    description: 大屏端获取建筑物列表
    endpoint: "/api/bigscreen/building/list"
    method: GET

  - name: bigscreen_layer_list
    description: 大屏端获取建筑物楼层列表
    endpoint: "/api/bigscreen/layer/list"
    method: GET
    params:
      - name: buildingid
        type: number
        required: true
        description: 建筑物ID

  - name: bigscreen_room_list
    description: 大屏端获取房间列表
    endpoint: "/api/bigscreen/room/list"
    method: GET
    params:
      - name: layerid
        type: number
        required: true
        description: 楼层ID

  - name: bigscreen_room_info
    description: 大屏端获取房间详情
    endpoint: "/api/bigscreen/room/info"
    method: GET
    params:
      - name: roomId
        type: number
        required: true
        description: 房间ID

  - name: bigscreen_time_list
    description: 大屏端获取房间时间胶囊（可用时间段）
    endpoint: "/api/bigscreen/time/list"
    method: GET
    params:
      - name: roomId
        type: number
        required: true
        description: 房间ID
      - name: date
        type: string
        required: true
        description: 查询日期，格式 yyyy-MM-dd

  - name: bigscreen_booking_add
    description: 大屏端预约房间（需要cardNo认证）
    endpoint: "/api/bigscreen/booking/add"
    method: POST
    requestFormat: |
      {
        "roomId": 51,
        "startTime": "2026-04-17T09:00:00.000",
        "endTime": "2026-04-17T09:30:00.000",
        "bookingType": 1,
        "attenderNum": 3,
        "bookingTop": "会议主题",
        "cardNo": "12221212"
      }
    params:
      - name: roomId
        type: number
        required: true
        description: 房间ID
      - name: startTime
        type: string
        required: true
        description: 预约开始时间，格式 ISO 8601 如 2026-04-17T09:00:00.000
      - name: endTime
        type: string
        required: true
        description: 预约结束时间，格式 ISO 8601 如 2026-04-17T09:30:00.000
      - name: bookingType
        type: number
        required: false
        description: 预约类型，1-普通预约
      - name: attenderNum
        type: number
        required: false
        description: 参加人数
      - name: bookingTop
        type: string
        required: false
        description: 会议主题
      - name: cardNo
        type: string
        required: true
        description: 刷卡卡号（用于身份认证）

  - name: bigscreen_my_booking
    description: 大屏端获取我的预约列表
    endpoint: "/api/bigscreen/my/booking"
    method: GET
    params:
      - name: cardNo
        type: string
        required: true
        description: 刷卡卡号

  - name: bigscreen_cancel_booking
    description: 大屏端取消预约
    endpoint: "/api/bigscreen/cancel/booking"
    method: GET
    params:
      - name: cardNo
        type: string
        required: true
        description: 刷卡卡号
      - name: bookingId
        type: number
        required: true
        description: 预约ID

  - name: bigscreen_card_sign
    description: 大屏端刷卡签到
    endpoint: "/api/bigscreen/card/sign"
    method: GET
    params:
      - name: cardNo
        type: string
        required: true
        description: 刷卡卡号

  - name: bigscreen_pincode_sign
    description: 大屏端签到码签到
    endpoint: "/api/bigscreen/pincode/sign"
    method: GET
    params:
      - name: pincode
        type: string
        required: true
        description: 签到码

examples:
  - user: "查询今天有哪些会议室可以用"
    assistant: "好的，我来帮您查询今天可用的会议室。请问您想查询哪栋楼的会议室？或者我先显示所有建筑物列表？"

  - user: "预约明天下午2点到4点的302研讨间"
    assistant: "好的，我来帮您预约明天下午2点到4点的302研讨间。让我先查询一下该房间的可用性。"

  - user: "查看我的预约"
    assistant: "好的，让我查询您的预约记录。"

  - user: "取消我刚才的预约"
    assistant: "好的，我来帮您取消预约。请问您能提供预约的ID吗？或者我先帮您列出所有当前预约？"

  - user: "今天有多少工位被使用了"
    assistant: "好的，让我查询今天的工位使用情况。"
---
