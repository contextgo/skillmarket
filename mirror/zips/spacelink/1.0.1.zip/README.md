# SpaceLink 智慧空间预约系统 - OpenClaw Skill

本目录包含智慧空间预约系统（SpaceLink）的 OpenClaw Skill，使 AI Agent 能够帮助用户完成空间预约相关操作。

## 目录结构

```
spacelink-booking/
├── SKILL.md       # 主 Skill 定义文件
├── config.json    # 配置文件
└── README.md      # 说明文档
```

## 功能概述

### 支持的操作

| 功能模块 | 操作 | 认证要求 |
|---------|------|---------|
| **空间查询** | 查询建筑物、楼层、房间列表 | 否 |
| **空间详情** | 查看房间详细信息、时间胶囊 | 否 |
| **空间预约** | 预约会议室/研讨间 | 是 |
| **预约管理** | 查看预约、取消预约 | 是 |
| **工位查询** | 查询建筑物、区域、座位状态 | 否 |
| **工位预约** | 预约工位、查看我的工位预约 | 是 |
| **首页数据** | 空间使用统计、通知公告 | 否 |

### API 端点列表

#### 无需认证的接口（公开）

```
GET /api/h5/building/list          - 获取建筑物列表
GET /api/h5/layer/list              - 获取楼层列表
GET /api/h5/room/list               - 获取房间列表
GET /api/h5/room/info               - 获取房间详情
GET /api/h5/time/list               - 获取时间段
GET /api/h5/index/bookinglist       - 首页统计数据
GET /api/h5/index/noticelist       - 通知公告
GET /api/seatbook/layout/buildinglayer - 工位建筑楼层
GET /api/seatbook/layout/region     - 工位区域列表
GET /api/seatbook/layout/query      - 座位状态查询
```

#### 需要认证的接口

```
POST /api/h5user/booking/add        - 预约空间
GET  /api/h5user/my/booking         - 我的预约列表
GET  /api/h5user/booking/detail     - 预约详情
GET  /api/h5user/cancel/booking     - 取消预约
GET  /api/h5user/my/userinfo        - 用户信息
GET  /api/h5user/my/crrentbooking   - 当前预约
GET  /api/seatbook/user/addbooking  - 预约工位
GET  /api/seatbook/user/mybooking   - 我的工位预约
```

## 安装步骤

1. **复制 Skill 文件夹**

将 `spacelink-booking` 文件夹复制到 OpenClaw 的 skills 目录：

```bash
# Linux/Mac
cp -r skills/spacelink-booking ~/.openclaw/skills/

# Windows PowerShell
Copy-Item -Path "skills\spacelink-booking" -Destination "$env:USERPROFILE\.openclaw\skills\" -Recurse
```

2. **配置系统 API 地址**

编辑 `config.json` 中的 `api_config.base_url` 为实际的服务地址：

```json
{
  "api_config": {
    "base_url": "https://your-spacelink-server.com"
  }
}
```

3. **刷新 OpenClaw Skills**

在 OpenClaw 中执行刷新命令：
```
/refresh skills
```

## 使用示例

### 查询会议室

```
用户：今天3楼有哪些会议室可以用？
AI：好的，我来查询3楼的会议室列表。
```

### 预约空间

```
用户：帮我预约明天下午2点到4点的302研讨间
AI：好的，让我先查询302研讨间在明天下午2点到4点是否可用。
     然后为您创建预约。
```

### 管理预约

```
用户：查看我的预约
AI：好的，让我查询您的预约记录。
```

### 工位预约

```
用户：今天图书馆5楼有哪个工位可以用？
AI：好的，我来查询图书馆5楼的工位使用情况。
```

## 认证方式

系统使用 JWT Token 进行认证：

1. **登录获取 Token**
   ```
   POST /api/h5login/login
   Body: { "username": "xxx", "password": "xxx" }
   Response: { "code": 200, "token": "xxx" }
   ```

2. **使用 Token**
   在请求头中添加：
   ```
   Authorization: Bearer <token>
   ```

## 注意事项

1. **日期时间格式**
   - 日期：`yyyy-MM-dd`
   - 时间：`HH:mm`
   - 完整时间：`yyyy-MM-dd HH:mm:ss`

2. **状态码说明**
   - `code: 200` - 成功
   - `code: 500` - 失败
   - `code: 0` - 分页数据

3. **预约状态**
   - `BOOKED` - 已预约
   - `SIGN_IN` - 已签到
   - `SIGN_OUT` - 已签退
   - `AUDITING` - 审核中

4. **工位状态**
   - `0` - 全部
   - `1` - 已预约
   - `2` - 已签到
   - `3` - 临时离开
   - `5` - 已取消
   - `6` - 已签退
   - `7` - 已违约

## 开发说明

如需扩展更多 API 或功能，请修改 `SKILL.md` 文件：

```yaml
tools:
  - name: new_api
    description: 新API说明
    endpoint: "/api/xxx"
    method: GET
    params:
      - name: paramName
        type: string
        required: true
        description: 参数说明
```

## 联系方式

如有问题或建议，请联系系统管理员。
