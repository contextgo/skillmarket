#!/usr/bin/env node

import path from 'path';
import { fileURLToPath } from 'url';
import { httpsRequest, getApiKey, workspacesGetUrl, workspaceSkillsGetUrl, truncateBody } from './utils.mjs';
import { readCache, writeCache, getCacheDir, keyHashedPath } from './cache.mjs';

const CACHE_DIR = getCacheDir();
const SKILLS_CACHE_TTL = 60 * 60 * 1000; // 1 hour in ms
export const MAX_PAGES = 100;

function workspaceCacheFile(apiKey) {
  return keyHashedPath(path.join(CACHE_DIR, 'workspace-cache.json'), apiKey);
}

function skillsCacheFile(apiKey) {
  return keyHashedPath(path.join(CACHE_DIR, 'skills-cache.json'), apiKey);
}

export function buildEpId(workspaceId, localName) {
  // localName format: c-sk-XXXXX → extract XXXXX part
  const suffix = localName.replace(/^c-sk-/, '');
  return `ep-${workspaceId}-${suffix}`;
}

// ── API Functions ────────────────────────────────────────────────────

/**
 * Get the default workspace ID. Uses long-lived cache (tied to API key).
 */
export async function getDefaultWorkspaceId() {
  const apiKey = getApiKey();
  const cacheFile = workspaceCacheFile(apiKey);
  const cached = readCache(cacheFile);
  if (cached?.workspaceId) return cached.workspaceId;

  const url = workspacesGetUrl();
  const { statusCode, body } = await httpsRequest(url, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
  });

  if (statusCode !== 200) {
    throw new Error(`workspaces/get failed: HTTP ${statusCode} - ${truncateBody(body)}`);
  }

  let resp;
  try {
    resp = JSON.parse(body);
  } catch {
    throw new Error(`workspaces/get unexpected response: ${truncateBody(body)}`);
  }
  if (!resp.success || !resp.page?.result) {
    throw new Error(`workspaces/get unexpected response: ${truncateBody(body)}`);
  }

  const defaultWorkspace = resp.page.result.find(ws => ws.type === 'default');
  if (!defaultWorkspace) {
    throw new Error('No default workspace found');
  }

  const workspaceId = defaultWorkspace.id;
  writeCache(cacheFile, { workspaceId, timestamp: Date.now() });
  return workspaceId;
}

/**
 * Get all released SkillApi skills from the default workspace.
 * Uses file cache with 1-hour TTL. Each skill includes pre-constructed epId.
 */
export async function getWorkspaceSkills() {
  const apiKey = getApiKey();
  const cacheFile = skillsCacheFile(apiKey);
  const cached = readCache(cacheFile, SKILLS_CACHE_TTL);
  if (cached?.skills) return cached.skills;

  const workspaceId = await getDefaultWorkspaceId();
  const url = workspaceSkillsGetUrl(workspaceId);

  const allSkills = [];
  let pageNo = 1;
  const pageSize = 50;

  // Paginate to fetch all skills
  while (true) {
    if (pageNo > MAX_PAGES) {
      throw new Error(`Pagination exceeded ${MAX_PAGES} pages, aborting`);
    }
    const { statusCode, body } = await httpsRequest(url, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        workspaceID: workspaceId,
        orderBy: 'last_published_at',
        order: 'desc',
        pageNo,
        pageSize,
        publicationKinds: ['SkillApi'],
        status: 'Released',
      }),
    });

    if (statusCode !== 200) {
      throw new Error(`skills/get failed: HTTP ${statusCode} - ${truncateBody(body)}`);
    }

    let resp;
    try {
      resp = JSON.parse(body);
    } catch {
      throw new Error(`skills/get unexpected response: ${truncateBody(body)}`);
    }
    if (!resp.success || !resp.page?.result) {
      throw new Error(`skills/get unexpected response: ${truncateBody(body)}`);
    }

    const skills = resp.page.result.map(skill => ({
      epId: buildEpId(workspaceId, skill.localName),
      displayName: skill.displayName,
      description: skill.description || '',
      localName: skill.localName,
      workspaceId,
    }));

    allSkills.push(...skills);

    const totalCount = resp.page.totalCount || 0;
    if (allSkills.length >= totalCount || skills.length < pageSize) break;
    pageNo++;
  }

  writeCache(cacheFile, { workspaceId, skills: allSkills, timestamp: Date.now() });
  return allSkills;
}

// ── CLI ──────────────────────────────────────────────────────────────

async function main() {
  const command = process.argv[2];

  if (command === 'list-skills') {
    try {
      const skills = await getWorkspaceSkills();
      const result = {
        success: true,
        count: skills.length,
        skills: skills.map(s => ({
          epId: s.epId,
          displayName: s.displayName,
          description: s.description || null,
        })),
      };
      console.log(JSON.stringify(result, null, 2));
    } catch (err) {
      console.error(JSON.stringify({ success: false, error: err.message }, null, 2));
      process.exit(1);
    }
  } else {
    console.error('Usage: node workspace.mjs list-skills');
    process.exit(1);
  }
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  main();
}
