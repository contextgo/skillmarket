#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
未来7天逐3小时天气预报日常生活解读脚本
支持全国3193个区县级城市，从日常生活角度深度解读气象风险并提供防御措施
气象数据 -> 日常生活风险分析 -> 防御措施，完整闭环服务
"""

import sys
import json
import ssl
import urllib.request
import urllib.error
import os
from datetime import datetime

# 导入内置城市映射表
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cities import CITY_MAP

# COS基础URL（日常生活解读专属路径）
COS_BASE_URL = "https://diga2026-1252033877.cos.ap-beijing.myqcloud.com/kg3hour/"

# 合法的3小时时间点
VALID_HOURS = [2, 5, 8, 11, 14, 17, 20, 23]

# 日常生活场景配置（支持多个生活维度）
DAILY_SCENES = {
    "live": {"name": "日常生活", "emoji": "🏠", "suffix": "live"},
    "drying": {"name": "晾晒", "emoji": "👕", "suffix": "drying"},
    "outdoor": {"name": "户外活动", "emoji": "🌳", "suffix": "outdoor"},
    "indoor": {"name": "室内活动", "emoji": "🏠", "suffix": "indoor"},
    "pets": {"name": "宠物出行", "emoji": "🐕", "suffix": "pets"},
    "shopping": {"name": "购物出行", "emoji": "🛒", "suffix": "shopping"},
    "umbrella": {"name": "雨伞指数", "emoji": "☂️", "suffix": "umbrella"},
    "comfort": {"name": "舒适度", "emoji": "😊", "suffix": "comfort"},
}

# 场景中文关键词映射
SCENE_KEYWORDS = {
    "日常生活": "live", "生活": "live", "日常": "live",
    "晾晒": "drying", "晒衣服": "drying", "晾衣服": "drying",
    "户外": "outdoor", "室外": "outdoor", "外出": "outdoor",
    "室内": "indoor", "宅家": "indoor", "居家": "indoor",
    "宠物": "pets", "遛狗": "pets",
    "购物": "shopping", "逛街": "shopping",
    "雨伞": "umbrella", "带伞": "umbrella",
    "舒适": "comfort", "舒适度": "comfort",
}

# 创建SSL上下文（忽略证书验证，提高兼容性）
SSL_CONTEXT = ssl.create_default_context()
SSL_CONTEXT.check_hostname = False
SSL_CONTEXT.verify_mode = ssl.CERT_NONE


# ─────────────────────────────────────────────
# 城市匹配
# ─────────────────────────────────────────────

def fuzzy_match_city(city_name):
    """城市模糊匹配，支持精确/包含/前缀三种方式"""
    if not city_name:
        return None, None

    # 精确匹配
    if city_name in CITY_MAP:
        return CITY_MAP[city_name], city_name

    # 包含匹配：用户输入较短时，匹配包含该短串的完整城市名
    # 例如"公安县"匹配"公安"
    matches = [(name, cid) for name, cid in CITY_MAP.items() if name in city_name]
    if len(matches) == 1:
        return matches[0][1], matches[0][0]
    # 如果有多个匹配，优先选择最短的
    if matches:
        matches.sort(key=lambda x: len(x[0]))
        return matches[0][1], matches[0][0]

    # 前缀匹配
    matches = [(name, cid) for name, cid in CITY_MAP.items() if name.startswith(city_name)]
    if matches:
        return matches[0][1], matches[0][0]

    return None, None


# ─────────────────────────────────────────────
# 数据获取
# ─────────────────────────────────────────────

def fetch_daily_data(city_id, scene_suffix):
    """从云端获取指定城市+场景的日常生活解读数据"""
    url = "{}{}{}.json".format(COS_BASE_URL, city_id, scene_suffix)
    try:
        req = urllib.request.Request(url, headers={
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        })
        with urllib.request.urlopen(req, timeout=15, context=SSL_CONTEXT) as response:
            data = json.loads(response.read().decode("utf-8"))
            return data
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return None
        raise Exception("HTTP错误: {}".format(e.code))
    except Exception as e:
        raise Exception("获取数据失败 [{}]: {}".format(url, str(e)))


# ─────────────────────────────────────────────
# 时间处理
# ─────────────────────────────────────────────

def find_nearest_hour(target_hour):
    """找到最近的合法3小时时间点"""
    return min(VALID_HOURS, key=lambda h: abs(h - target_hour))


def filter_data(data, target_date=None, target_hour=None):
    """按日期和时间过滤数据
    当时间无法精准匹配时，自动获取距离最近小时值的数据
    """
    if not data or not isinstance(data, list):
        return []

    result = data
    if target_date:
        result = [item for item in result if item.get("date") == target_date]

    if target_hour is not None:
        # 按距离排序所有有效时间点
        sorted_hours = sorted(VALID_HOURS, key=lambda h: abs(h - target_hour))

        # 尝试每个时间点，返回第一个有数据的时间点
        for nearest in sorted_hours:
            filtered = [item for item in result if item.get("hour") == nearest]
            if filtered:
                return filtered

        # 如果所有时间点都没有数据，返回空
        return []

    return result


# ─────────────────────────────────────────────
# 主查询逻辑
# ─────────────────────────────────────────────

def query_daily_life(city_name, scene="all", target_date=None, target_hour=None):
    """
    查询日常生活解读数据

    Args:
        city_name: 城市名称（支持模糊匹配）
        scene: 场景 live/drying/outdoor/indoor/pets/shopping/umbrella/comfort/all
        target_date: 目标日期 YYYY-MM-DD（可选）
        target_hour: 目标小时 0-23（可选）

    Returns:
        dict: 包含解读数据的结果字典
    """
    # 解析中文场景关键词
    if scene and scene not in DAILY_SCENES and scene != "all":
        mapped = SCENE_KEYWORDS.get(scene)
        if mapped:
            scene = mapped
        else:
            raise ValueError("未知场景: {}，支持: {} 或 all".format(
                scene, "/".join(DAILY_SCENES.keys())))

    # 城市匹配
    city_id, matched_name = fuzzy_match_city(city_name)
    if not city_id:
        suggestions = [name for name in CITY_MAP.keys() if city_name in name][:5]
        hint = "您是否想找: {}".format(", ".join(suggestions)) if suggestions else ""
        raise ValueError("未找到城市: {}\n{}".format(city_name, hint))

    # 确定要查询的场景列表
    if scene == "all":
        scene_keys = list(DAILY_SCENES.keys())
    else:
        scene_keys = [scene]

    # 获取各场景数据
    result_scenes = {}
    errors = []
    matched_hour = None  # 记录实际匹配到的小时

    for sk in scene_keys:
        sc = DAILY_SCENES[sk]
        try:
            raw = fetch_daily_data(city_id, sc["suffix"])
            if raw is not None:
                filtered = filter_data(raw, target_date, target_hour)
                result_scenes[sk] = {
                    "scene_key": sk,
                    "scene_name": sc["name"],
                    "scene_emoji": sc["emoji"],
                    "total": len(raw),
                    "filtered": filtered,
                }
                # 记录实际匹配到的小时（取第一个有数据的）
                if matched_hour is None and filtered:
                    for item in filtered:
                        if item.get("hour") is not None:
                            matched_hour = item.get("hour")
                            break
            else:
                errors.append("{} 数据不存在".format(sc["name"]))
        except Exception as e:
            errors.append("{}: {}".format(sc["name"], str(e)))

    return {
        "city_id": city_id,
        "city_name": matched_name,
        "query_scene": scene,
        "query_date": target_date,
        "query_hour": target_hour,
        "matched_hour": matched_hour,  # 实际匹配到的小时
        "scenes": result_scenes,
        "errors": errors,
    }


# ─────────────────────────────────────────────
# 格式化输出
# ─────────────────────────────────────────────

def format_hour(hour):
    """格式化小时显示"""
    if isinstance(hour, int):
        return "{:02d}:00".format(hour)
    return "{}:00".format(hour)


def print_scene_data(scene_key, scene_info, max_records=None):
    """打印单个场景的解读数据"""
    sc_name = scene_info["scene_name"]
    sc_emoji = scene_info["scene_emoji"]
    records = scene_info["filtered"]

    if not records:
        return

    print("\n{} {} 解读".format(sc_emoji, sc_name))
    print("─" * 55)

    display = records[:max_records] if max_records else records
    current_date = None

    for item in display:
        date = item.get("date", "")
        hour = item.get("hour", "-")
        word = item.get("word", "").strip()
        content = item.get("content", "").strip()

        if date != current_date:
            current_date = date
            print("\n  📅 {}".format(date))

        hour_str = format_hour(hour)
        print("\n  ⏰ {}".format(hour_str))

        # 核心建议（word字段）
        if word:
            print("  💡 核心建议: {}".format(word))

        # 详细分析（content字段）
        if content:
            print("  📋 详细分析:")
            for line in content.split("\n"):
                line = line.strip()
                if line:
                    print("     {}".format(line))


def print_result(result):
    """打印完整解读结果"""
    city_name = result["city_name"]
    city_id = result["city_id"]
    scenes = result["scenes"]
    errors = result["errors"]
    query_scene = result["query_scene"]
    query_hour = result.get("query_hour")
    matched_hour = result.get("matched_hour")

    print("")
    print("=" * 60)
    print("📍 城市: {} (ID: {})".format(city_name, city_id))

    if result["query_date"]:
        print("📅 日期: {}".format(result["query_date"]))
    if query_hour is not None:
        if matched_hour is not None and matched_hour != query_hour:
            print("⏰ 时间: 查询 {:02d}:00 → 匹配到 {:02d}:00（最近可用）".format(query_hour, matched_hour))
        else:
            print("⏰ 时间: {:02d}:00".format(query_hour))

    scene_label = "全场景" if query_scene == "all" else DAILY_SCENES.get(query_scene, {}).get("name", query_scene)
    print("🏠 解读场景: 日常生活 - {}".format(scene_label))
    print("=" * 60)

    if not scenes:
        print("\n⚠️  未获取到任何解读数据")
    else:
        for sk, si in scenes.items():
            if si["filtered"]:
                # all模式下每个场景只显示最近3条，单场景全量显示
                max_rec = 3 if query_scene == "all" else None
                print_scene_data(sk, si, max_records=max_rec)

    if errors:
        print("\n⚠️  以下场景获取失败:")
        for err in errors:
            print("   • {}".format(err))

    print("\n" + "=" * 60)


def print_json_result(result):
    """以JSON格式输出结果（供AI工具链使用）"""
    output = {
        "city_id": result["city_id"],
        "city_name": result["city_name"],
        "scenes": {}
    }
    for sk, si in result["scenes"].items():
        output["scenes"][sk] = {
            "name": si["scene_name"],
            "records": si["filtered"]
        }
    print(json.dumps(output, ensure_ascii=False, indent=2))


# ─────────────────────────────────────────────
# 帮助信息
# ─────────────────────────────────────────────

def print_help():
    print("""
用法: python3 interpret.py <城市名> [场景] [日期] [小时] [--json]

参数:
  城市名   城市/区县名称，支持模糊匹配（必填）
  场景     解读场景（可选，默认 live 日常生活）
           live      日常生活解读（默认）
           drying    晾晒指数
           outdoor   户外活动
           indoor    室内活动
           pets      宠物出行
           shopping  购物出行
           umbrella  雨伞指数
           comfort   舒适度
           all       全部场景（每场景显示最新3条）
  日期     查询日期，YYYY-MM-DD 格式（可选）
  小时     查询时间点 0-23（可选）
  --json   以JSON格式输出（可选）

示例:
  python3 interpret.py 北京
  python3 interpret.py 北京 shopping
  python3 interpret.py 广州 umbrella 2026-04-20
  python3 interpret.py 上海 outdoor 2026-04-20 14
  python3 interpret.py 深圳 all 2026-04-20
  python3 interpret.py 成都 live --json

支持 {} 个城市/区县
""".format(len(CITY_MAP)))


# ─────────────────────────────────────────────
# 入口
# ─────────────────────────────────────────────

def main():
    args = sys.argv[1:]

    if not args or args[0] in ("-h", "--help"):
        print_help()
        sys.exit(0 if args else 1)

    # 解析参数
    city_name = args[0]
    scene = "live"  # 默认使用日常生活解读
    target_date = None
    target_hour = None
    output_json = "--json" in args

    # 去掉 --json 标志
    args = [a for a in args if a != "--json"]

    if len(args) >= 2:
        scene_arg = args[1]
        # 判断是场景还是日期
        if scene_arg in DAILY_SCENES or scene_arg == "all" or scene_arg in SCENE_KEYWORDS:
            scene = scene_arg
            pos = 2
        else:
            pos = 1

        if len(args) > pos:
            date_arg = args[pos]
            # 校验日期格式
            try:
                datetime.strptime(date_arg, "%Y-%m-%d")
                target_date = date_arg
                pos += 1
            except ValueError:
                pass

        if len(args) > pos:
            hour_arg = args[pos]
            try:
                h = int(hour_arg)
                if 0 <= h <= 23:
                    target_hour = h
                else:
                    print("❌ 小时参数需在 0-23 之间")
                    sys.exit(1)
            except ValueError:
                print("❌ 小时参数需为整数")
                sys.exit(1)

    try:
        result = query_daily_life(city_name, scene, target_date, target_hour)
        if output_json:
            print_json_result(result)
        else:
            print_result(result)
    except ValueError as e:
        print("❌ 参数错误: {}".format(e))
        sys.exit(1)
    except Exception as e:
        print("❌ 查询失败: {}".format(e))
        sys.exit(1)


if __name__ == "__main__":
    main()
