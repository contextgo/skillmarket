# Coding DevOps API Reference

## Base URL

```
https://e.coding.net/open-api
```

## Authentication

All requests require an access token in the Authorization header:

```
Authorization: token <your-access-token>
```

## Common Parameters

| Parameter | Type | Description |
|-----------|-------|-------------|
| Action | string | API action name (required) |
| PageNumber | integer | Page number (default: 1) |
| PageSize | integer | Items per page (default: 100) |

## API Actions

### Projects

#### DescribeCodingProjects
Get list of projects.

| Parameter | Type | Description |
|-----------|-------|-------------|
| ProjectName | string | Project name (fuzzy search) |

#### DescribeTeamMembers
Get list of team members.

| Parameter | Type | Description |
|-----------|-------|-------------|
| ShowDepartment | boolean | Include department information |

#### DescribeProjectDepotInfoList
Get list of code repositories for a project.

| Parameter | Type | Description |
|-----------|-------|-------------|
| ProjectId | integer | Project ID |

### Issues

#### DescribeTeamIssues
Query team issues with filters.

| Parameter | Type | Description |
|-----------|-------|-------------|
| Conditions | array | Filter conditions |
| Sorts | array | Sort conditions |
| ShowSubIssues | boolean | Include sub-issues |

**Condition Keys:**
- `ASSIGNEE` - Assignee ID(s)
- `STATUS_TYPE` - Status type(s): TODO, PROCESSING, COMPLETED
- `PROJECT_ID` - Project ID(s)
- `ISSUE_TYPE_ID` - Issue type ID(s)
- `UPDATED_AT` - Update time range (timestamp start,timestamp end)

### Builds

#### DescribeCodingCIJobs
Get list of CI jobs for a project.

| Parameter | Type | Description |
|-----------|-------|-------------|
| ProjectId | integer | Project ID |

#### DescribeCodingCIBuilds
Get build records for a CI job.

| Parameter | Type | Description |
|-----------|-------|-------------|
| JobId | integer | CI job ID |
| PageNumber | integer | Page number |
| PageSize | integer | Items per page |

### Git

#### DescribeGitCommitInfos
Get commit records for a repository.

| Parameter | Type | Description |
|-----------|-------|-------------|
| DepotId | integer | Repository ID |
| Ref | string | Branch name (default: master) |
| StartDate | string | Start date (YYYY-MM-DD) |
| EndDate | string | End date (YYYY-MM-DD) |
| KeyWord | string | Commit message keyword |
| PageNumber | integer | Page number |
| PageSize | integer | Items per page |

### Merge Requests

#### DescribeProjectMergeRequests
Get merge requests for a project.

| Parameter | Type | Description |
|-----------|-------|-------------|
| ProjectId | integer | Project ID |
| CreatedAtStartDate | string | Creation start date (YYYY-MM-DD) |
| CreatedAtEndDate | string | Creation end date (YYYY-MM-DD) |
| CreatorEmail | string | Creator email |
| Status | string | MR status filter |
| PageNumber | integer | Page number |
| PageSize | integer | Items per page |

## Rate Limits

- **Limit**: 30 requests per second per team per endpoint
- The tool automatically handles pagination for large datasets

## Data Models

### Project
| Field | Type | Description |
|-------|-------|-------------|
| Id | integer | Project ID |
| Name | string | Project name |
| DisplayName | string | Display name |
| Description | string | Project description |
| Status | integer | Status code |
| TeamId | integer | Team ID |

### TeamMember
| Field | Type | Description |
|-------|-------|-------------|
| Id | integer | Member ID |
| Name | string | Member name |
| Email | string | Email address |
| GlobalKey | string | Global key |

### Issue
| Field | Type | Description |
|-------|-------|-------------|
| Code | integer | Issue code |
| Type | string | Issue type |
| Name | string | Issue title |
| StatusType | string | Status type |
| AssigneeId | integer | Assignee ID |
| ProjectId | integer | Project ID |

## Error Handling

API errors return an error object:

```json
{
  "Code": "error_code",
  "Message": "Error description",
  "RequestId": "request-id"
}
```

Common error codes:
- `InvalidParameter` - Invalid request parameters
- `Unauthorized` - Invalid or missing access token
- `ResourceNotFound` - Requested resource not found
- `RateLimitExceeded` - Rate limit exceeded
