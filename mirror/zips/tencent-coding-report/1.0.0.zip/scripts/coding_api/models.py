"""Coding API 数据模型定义"""

from datetime import datetime
from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field


class IssueType(str, Enum):
    """事项类型"""
    REQUIREMENT = "REQUIREMENT"  # 需求
    MISSION = "MISSION"  # 任务
    DEFECT = "DEFECT"  # 缺陷
    EPIC = "EPIC"  # 史诗
    ALL = "ALL"  # 全部


class IssueStatusType(str, Enum):
    """事项状态类型"""
    TODO = "TODO"  # 未开始
    PROCESSING = "PROCESSING"  # 进行中
    COMPLETED = "COMPLETED"  # 已完成


class BuildStatus(str, Enum):
    """构建状态"""
    SUCCEED = "SUCCEED"  # 成功
    FAILED = "FAILED"  # 失败
    ABORTED = "ABORTED"  # 中止
    RUNNING = "RUNNING"  # 运行中
    WAITING = "WAITING"  # 等待中


class MRStatus(str, Enum):
    """合并请求状态"""
    OPEN = "OPEN"  # 打开中
    CLOSED = "CLOSED"  # 已关闭
    CANMERGE = "CANMERGE"  # 可合并
    CANNOTMERGE = "CANNOTMERGE"  # 不可合并


class Project(BaseModel):
    """项目模型"""
    id: int = Field(alias="Id")
    name: str = Field(alias="Name")
    display_name: str = Field(default="", alias="DisplayName")
    description: str = Field(default="", alias="Description")
    status: int = Field(default=1, alias="Status")
    team_id: int = Field(default=0, alias="TeamId")
    created_at: Optional[int] = Field(default=None, alias="CreatedAt")
    updated_at: Optional[int] = Field(default=None, alias="UpdatedAt")
    is_demo: bool = Field(default=False, alias="IsDemo")
    archived: bool = Field(default=False, alias="Archived")

    class Config:
        populate_by_name = True


class TeamMember(BaseModel):
    """团队成员模型"""
    id: int = Field(alias="Id")
    name: str = Field(alias="Name")
    email: str = Field(default="", alias="Email")
    phone: str = Field(default="", alias="Phone")
    avatar: str = Field(default="", alias="Avatar")
    global_key: str = Field(default="", alias="GlobalKey")
    status: int = Field(default=1, alias="Status")
    team_id: int = Field(default=0, alias="TeamId")

    class Config:
        populate_by_name = True


class Iteration(BaseModel):
    """迭代模型"""
    id: int = Field(default=0, alias="Id")
    code: int = Field(default=0, alias="Code")
    name: str = Field(default="", alias="Name")
    status: str = Field(default="", alias="Status")

    class Config:
        populate_by_name = True


class Issue(BaseModel):
    """事项模型"""
    code: int = Field(alias="Code")
    type: str = Field(alias="Type")
    name: str = Field(alias="Name")
    description: str = Field(default="", alias="Description")
    issue_status_id: int = Field(default=0, alias="IssueStatusId")
    issue_status_name: str = Field(default="", alias="IssueStatusName")
    issue_status_type: str = Field(default="", alias="IssueStatusType")
    priority: str = Field(default="3", alias="Priority")
    assignee_id: int = Field(default=0, alias="AssigneeId")
    creator_id: int = Field(default=0, alias="CreatorId")
    project_id: int = Field(default=0, alias="ProjectId")
    project_name: str = Field(default="", alias="ProjectName")
    iteration_id: int = Field(default=0, alias="IterationId")
    created_at: Optional[int] = Field(default=None, alias="CreatedAt")
    updated_at: Optional[int] = Field(default=None, alias="UpdatedAt")
    completed_at: Optional[int] = Field(default=None, alias="CompletedAt")
    iteration: Optional[Iteration] = Field(default=None, alias="Iteration")

    class Config:
        populate_by_name = True

    @property
    def is_completed(self) -> bool:
        return self.issue_status_type == IssueStatusType.COMPLETED.value

    @property
    def is_processing(self) -> bool:
        return self.issue_status_type == IssueStatusType.PROCESSING.value

    @property
    def is_todo(self) -> bool:
        return self.issue_status_type == IssueStatusType.TODO.value


class Depot(BaseModel):
    """代码仓库模型"""
    id: int = Field(alias="Id")
    name: str = Field(alias="Name")
    depot_path: str = Field(default="", alias="DepotPath")
    project_id: int = Field(default=0, alias="ProjectId")
    default_branch: str = Field(default="master", alias="DefaultBranch")

    class Config:
        populate_by_name = True


class Committer(BaseModel):
    """提交者信息"""
    email: str = Field(default="", alias="Email")
    name: str = Field(default="", alias="Name")

    class Config:
        populate_by_name = True


class Commit(BaseModel):
    """代码提交模型"""
    sha: str = Field(alias="Sha")
    short_message: str = Field(default="", alias="ShortMessage")
    author_name: str = Field(default="", alias="AuthorName")
    author_email: str = Field(default="", alias="AuthorEmail")
    committer: Optional[Committer] = Field(default=None, alias="Committer")
    commit_date: Optional[int] = Field(default=None, alias="CommitDate")
    created_at: Optional[int] = Field(default=None, alias="CreatedAt")
    depot_id: int = Field(default=0)
    depot_name: str = Field(default="")
    project_id: int = Field(default=0)
    project_name: str = Field(default="")

    class Config:
        populate_by_name = True


class Build(BaseModel):
    """构建记录模型"""
    id: int = Field(alias="Id")
    job_id: int = Field(alias="JobId")
    number: int = Field(default=0, alias="Number")
    status: str = Field(default="", alias="Status")
    cause: str = Field(default="", alias="Cause")
    duration: int = Field(default=0, alias="Duration")  # 毫秒
    created_at: Optional[int] = Field(default=None, alias="CreatedAt")
    job_name: str = Field(default="")
    project_id: int = Field(default=0)
    project_name: str = Field(default="")

    class Config:
        populate_by_name = True

    @property
    def is_success(self) -> bool:
        return self.status == BuildStatus.SUCCEED.value

    @property
    def is_failed(self) -> bool:
        return self.status == BuildStatus.FAILED.value

    @property
    def duration_seconds(self) -> float:
        return self.duration / 1000 if self.duration else 0


class MRAuthor(BaseModel):
    """MR 作者信息"""
    id: int = Field(default=0, alias="Id")
    name: str = Field(default="", alias="Name")
    email: str = Field(default="", alias="Email")
    global_key: str = Field(default="", alias="GlobalKey")
    avatar: str = Field(default="", alias="Avatar")

    class Config:
        populate_by_name = True


class MergeRequest(BaseModel):
    """合并请求模型"""
    id: int = Field(alias="Id")
    merge_id: int = Field(default=0, alias="MergeId")
    title: str = Field(default="", alias="Title")
    status: str = Field(default="", alias="Status")
    source_branch: str = Field(default="", alias="SourceBranch")
    target_branch: str = Field(default="", alias="TargetBranch")
    author: Optional[MRAuthor] = Field(default=None, alias="Author")
    reviewers: list[MRAuthor] = Field(default_factory=list, alias="Reviewers")
    created_at: Optional[int] = Field(default=None, alias="CreatedAt")
    updated_at: Optional[int] = Field(default=None, alias="UpdateAt")
    merged_at: Optional[int] = Field(default=None, alias="MergedAt")
    depot_id: int = Field(default=0, alias="DepotId")
    project_id: int = Field(default=0, alias="ProjectId")
    project_name: str = Field(default="")

    class Config:
        populate_by_name = True

    @property
    def is_merged(self) -> bool:
        return self.status in [MRStatus.CANMERGE.value, "MERGED"]

    @property
    def is_open(self) -> bool:
        return self.status == MRStatus.OPEN.value


class CIJob(BaseModel):
    """构建计划模型"""
    id: int = Field(alias="Id")
    project_id: int = Field(default=0, alias="ProjectId")
    name: str = Field(default="", alias="Name")
    creator_id: int = Field(default=0, alias="CreatorId")
    created_at: Optional[int] = Field(default=None, alias="CreatedAt")
    project_name: str = Field(default="")

    class Config:
        populate_by_name = True
