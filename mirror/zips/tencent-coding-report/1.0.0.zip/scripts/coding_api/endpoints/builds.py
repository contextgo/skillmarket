"""构建（CI）相关 API"""

from typing import Optional

from ..client import CodingClient
from ..models import Build, CIJob, BuildStatus


class BuildsAPI:
    """构建 API 封装"""

    def __init__(self, client: CodingClient):
        self.client = client

    def list_ci_jobs(
        self,
        project_id: int,
        filters: Optional[list[dict]] = None,
    ) -> list[CIJob]:
        """
        获取项目构建计划列表

        Args:
            project_id: 项目 ID
            filters: 过滤条件

        Returns:
            构建计划列表
        """
        params = {
            "ProjectId": project_id,
        }
        if filters:
            params["Filter"] = filters

        data = self.client.request("DescribeCodingCIJobs", **params)
        jobs = data.get("JobList", [])
        return [CIJob.model_validate(j) for j in jobs]

    def list_builds(
        self,
        job_id: int,
        page_number: int = 1,
        page_size: int = 100,
    ) -> list[Build]:
        """
        获取构建计划的构建记录列表

        Args:
            job_id: 构建计划 ID
            page_number: 页码
            page_size: 每页数量

        Returns:
            构建记录列表
        """
        params = {
            "JobId": job_id,
            "PageNumber": page_number,
            "PageSize": page_size,
        }

        data = self.client.request("DescribeCodingCIBuilds", **params)
        build_data = data.get("Data", {})
        builds = build_data.get("BuildList", [])

        result = []
        for b in builds:
            build = Build.model_validate(b)
            result.append(build)

        return result

    def list_all_builds(
        self,
        job_id: int,
        max_count: int = 1000,
    ) -> list[Build]:
        """
        获取构建计划的所有构建记录

        Args:
            job_id: 构建计划 ID
            max_count: 最大获取数量

        Returns:
            构建记录列表
        """
        all_builds = []
        page_number = 1
        page_size = 100

        while len(all_builds) < max_count:
            builds = self.list_builds(job_id, page_number, page_size)
            if not builds:
                break
            all_builds.extend(builds)
            if len(builds) < page_size:
                break
            page_number += 1

        return all_builds[:max_count]

    def list_project_builds(
        self,
        project_id: int,
        project_name: str = "",
    ) -> list[Build]:
        """
        获取项目的所有构建记录

        Args:
            project_id: 项目 ID
            project_name: 项目名称

        Returns:
            构建记录列表
        """
        all_builds = []

        # 获取项目的所有构建计划
        jobs = self.list_ci_jobs(project_id)

        for job in jobs:
            try:
                builds = self.list_all_builds(job.id)
                for build in builds:
                    build.project_id = project_id
                    build.project_name = project_name or str(project_id)
                    build.job_name = job.name
                all_builds.extend(builds)
            except Exception:
                continue

        return all_builds

    def get_build_stats(self, builds: list[Build]) -> dict:
        """
        统计构建数据

        Args:
            builds: 构建记录列表

        Returns:
            统计数据
        """
        stats = {
            "total": len(builds),
            "succeed": 0,
            "failed": 0,
            "aborted": 0,
            "running": 0,
            "success_rate": 0.0,
            "avg_duration": 0.0,
            "total_duration": 0,
            "by_project": {},
            "by_job": {},
        }

        if not builds:
            return stats

        total_duration = 0
        for build in builds:
            # 按状态统计
            if build.is_success:
                stats["succeed"] += 1
            elif build.is_failed:
                stats["failed"] += 1
            elif build.status == BuildStatus.ABORTED.value:
                stats["aborted"] += 1
            elif build.status in [BuildStatus.RUNNING.value, BuildStatus.WAITING.value]:
                stats["running"] += 1

            # 计算总耗时
            total_duration += build.duration

            # 按项目统计
            project_id = build.project_id
            if project_id not in stats["by_project"]:
                stats["by_project"][project_id] = {
                    "total": 0,
                    "succeed": 0,
                    "failed": 0,
                }
            stats["by_project"][project_id]["total"] += 1
            if build.is_success:
                stats["by_project"][project_id]["succeed"] += 1
            elif build.is_failed:
                stats["by_project"][project_id]["failed"] += 1

            # 按构建计划统计
            job_name = build.job_name
            if job_name not in stats["by_job"]:
                stats["by_job"][job_name] = {
                    "total": 0,
                    "succeed": 0,
                    "failed": 0,
                }
            stats["by_job"][job_name]["total"] += 1
            if build.is_success:
                stats["by_job"][job_name]["succeed"] += 1
            elif build.is_failed:
                stats["by_job"][job_name]["failed"] += 1

        # 计算成功率和平均耗时
        finished_count = stats["succeed"] + stats["failed"] + stats["aborted"]
        if finished_count > 0:
            stats["success_rate"] = round(stats["succeed"] / finished_count * 100, 2)

        if stats["total"] > 0:
            stats["avg_duration"] = round(total_duration / stats["total"] / 1000, 2)

        stats["total_duration"] = total_duration

        return stats
