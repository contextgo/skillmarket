"""项目与成员相关 API"""

from typing import Any, Optional

from ..client import CodingClient
from ..models import Project, TeamMember, Depot


class ProjectsAPI:
    """项目与成员 API 封装"""

    def __init__(self, client: CodingClient):
        self.client = client

    def list_projects(
        self,
        project_name: Optional[str] = None,
        page_number: int = 1,
        page_size: int = 100,
    ) -> list[Project]:
        """
        获取项目列表

        Args:
            project_name: 项目名称（模糊搜索）
            page_number: 页码
            page_size: 每页数量

        Returns:
            项目列表
        """
        params = {
            "PageNumber": page_number,
            "PageSize": page_size,
        }
        if project_name:
            params["ProjectName"] = project_name

        data = self.client.request("DescribeCodingProjects", **params)
        projects = data.get("Data", {}).get("ProjectList", [])
        return [Project.model_validate(p) for p in projects]

    def list_all_projects(self, project_name: Optional[str] = None) -> list[Project]:
        """
        获取所有项目

        Args:
            project_name: 项目名称（模糊搜索）

        Returns:
            所有项目列表
        """
        all_projects = []
        page_number = 1
        page_size = 100

        while True:
            projects = self.list_projects(project_name, page_number, page_size)
            if not projects:
                break
            all_projects.extend(projects)
            if len(projects) < page_size:
                break
            page_number += 1

        return all_projects

    def list_team_members(
        self,
        page_number: int = 1,
        page_size: int = 100,
        show_department: bool = False,
    ) -> list[TeamMember]:
        """
        获取团队成员列表

        Args:
            page_number: 页码
            page_size: 每页数量
            show_department: 是否展示部门信息

        Returns:
            团队成员列表
        """
        params = {
            "PageNumber": page_number,
            "PageSize": page_size,
            "ShowDepartment": show_department,
        }

        data = self.client.request("DescribeTeamMembers", **params)
        members = data.get("Data", {}).get("TeamMembers", [])
        return [TeamMember.model_validate(m) for m in members]

    def list_all_team_members(self) -> list[TeamMember]:
        """
        获取所有团队成员

        Returns:
            所有团队成员列表
        """
        all_members = []
        page_number = 1
        page_size = 100

        while True:
            members = self.list_team_members(page_number, page_size)
            if not members:
                break
            all_members.extend(members)
            if len(members) < page_size:
                break
            page_number += 1

        return all_members

    def list_project_members(
        self,
        project_id: int,
        page_number: int = 1,
        page_size: int = 100,
    ) -> list[TeamMember]:
        """
        获取项目成员列表

        Args:
            project_id: 项目 ID
            page_number: 页码
            page_size: 每页数量

        Returns:
            项目成员列表
        """
        params = {
            "ProjectId": project_id,
            "PageNumber": page_number,
            "PageSize": page_size,
        }

        data = self.client.request("DescribeProjectMembers", **params)
        members = data.get("ProjectMembers", [])
        return [TeamMember.model_validate(m) for m in members]

    def list_project_depots(
        self,
        project_id: int,
    ) -> list[Depot]:
        """
        获取项目仓库列表

        Args:
            project_id: 项目 ID

        Returns:
            仓库列表
        """
        params = {
            "ProjectId": project_id,
        }

        data = self.client.request("DescribeProjectDepotInfoList", **params)
        depots = data.get("DepotData", {}).get("Depots", [])
        return [Depot.model_validate(d) for d in depots]

    def list_all_depots(self, project_ids: list[int]) -> dict[int, list[Depot]]:
        """
        获取多个项目的仓库列表

        Args:
            project_ids: 项目 ID 列表

        Returns:
            项目 ID -> 仓库列表的映射
        """
        result = {}
        for project_id in project_ids:
            try:
                depots = self.list_project_depots(project_id)
                result[project_id] = depots
            except Exception:
                result[project_id] = []
        return result
