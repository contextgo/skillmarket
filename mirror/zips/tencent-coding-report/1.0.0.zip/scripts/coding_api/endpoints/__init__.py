"""API 端点封装"""

from .projects import ProjectsAPI
from .issues import IssuesAPI
from .builds import BuildsAPI
from .git import GitAPI
from .merge_requests import MergeRequestsAPI

__all__ = [
    "ProjectsAPI",
    "IssuesAPI",
    "BuildsAPI",
    "GitAPI",
    "MergeRequestsAPI",
]
