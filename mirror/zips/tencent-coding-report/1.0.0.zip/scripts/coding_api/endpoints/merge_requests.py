"""合并请求（MR）相关 API"""

from datetime import date, timedelta
from typing import Optional

from ..client import CodingClient
from ..models import MergeRequest, MRStatus


class MergeRequestsAPI:
    """合并请求 API 封装"""

    def __init__(self, client: CodingClient):
        self.client = client

    def list_project_merge_requests(
        self,
        project_id: int,
        created_at_start_date: Optional[str] = None,
        created_at_end_date: Optional[str] = None,
        creator_email: Optional[str] = None,
        status: Optional[str] = None,
        page_number: int = 1,
        page_size: int = 100,
    ) -> list[MergeRequest]:
        """
        获取项目下的合并请求列表

        Args:
            project_id: 项目 ID
            created_at_start_date: 创建开始日期
            created_at_end_date: 创建结束日期
            creator_email: 创建者邮箱
            status: 状态筛选
            page_number: 页码
            page_size: 每页数量

        Returns:
            合并请求列表
        """
        params = {
            "ProjectId": project_id,
            "PageNumber": page_number,
            "PageSize": page_size,
        }

        if created_at_start_date:
            params["CreatedAtStartDate"] = created_at_start_date
        if created_at_end_date:
            params["CreatedAtEndDate"] = created_at_end_date
        if creator_email:
            params["CreatorEmail"] = creator_email
        if status:
            params["Status"] = status

        data = self.client.request("DescribeProjectMergeRequests", **params)
        mr_list = data.get("Data", {}).get("List", [])
        return [MergeRequest.model_validate(mr) for mr in mr_list]

    def list_all_project_merge_requests(
        self,
        project_id: int,
        project_name: str = "",
        created_at_start_date: Optional[str] = None,
        created_at_end_date: Optional[str] = None,
        max_count: int = 1000,
    ) -> list[MergeRequest]:
        """
        获取项目下所有合并请求

        Args:
            project_id: 项目 ID
            project_name: 项目名称
            created_at_start_date: 创建开始日期
            created_at_end_date: 创建结束日期
            max_count: 最大获取数量

        Returns:
            合并请求列表
        """
        all_mrs = []
        page_number = 1
        page_size = 100

        while len(all_mrs) < max_count:
            mrs = self.list_project_merge_requests(
                project_id=project_id,
                created_at_start_date=created_at_start_date,
                created_at_end_date=created_at_end_date,
                page_number=page_number,
                page_size=page_size,
            )
            if not mrs:
                break

            # 附加项目信息
            for mr in mrs:
                mr.project_name = project_name

            all_mrs.extend(mrs)
            if len(mrs) < page_size:
                break
            page_number += 1

        return all_mrs[:max_count]

    def list_weekly_merge_requests(
        self,
        project_id: int,
        project_name: str = "",
        week_start: Optional[date] = None,
    ) -> list[MergeRequest]:
        """
        获取本周合并请求

        Args:
            project_id: 项目 ID
            project_name: 项目名称
            week_start: 周开始日期

        Returns:
            合并请求列表
        """
        if week_start is None:
            today = date.today()
            week_start = today - timedelta(days=today.weekday())

        week_end = week_start + timedelta(days=6)

        return self.list_all_project_merge_requests(
            project_id=project_id,
            project_name=project_name,
            created_at_start_date=week_start.strftime("%Y-%m-%d"),
            created_at_end_date=week_end.strftime("%Y-%m-%d"),
        )

    def list_depot_merge_requests(
        self,
        depot_id: int,
        created_at_start_date: Optional[str] = None,
        created_at_end_date: Optional[str] = None,
        status: Optional[str] = None,
        page_number: int = 1,
        page_size: int = 100,
    ) -> list[MergeRequest]:
        """
        获取仓库合并请求列表

        Args:
            depot_id: 仓库 ID
            created_at_start_date: 创建开始日期
            created_at_end_date: 创建结束日期
            status: 状态筛选
            page_number: 页码
            page_size: 每页数量

        Returns:
            合并请求列表
        """
        params = {
            "DepotId": depot_id,
            "PageNumber": page_number,
            "PageSize": page_size,
        }

        if created_at_start_date:
            params["CreatedAtStartDate"] = created_at_start_date
        if created_at_end_date:
            params["CreatedAtEndDate"] = created_at_end_date
        if status:
            params["Status"] = status

        data = self.client.request("DescribeDepotMergeRequests", **params)
        mr_list = data.get("Data", {}).get("List", [])
        return [MergeRequest.model_validate(mr) for mr in mr_list]

    def get_merge_request_stats(self, mrs: list[MergeRequest]) -> dict:
        """
        统计合并请求数据

        Args:
            mrs: 合并请求列表

        Returns:
            统计数据
        """
        stats = {
            "total": len(mrs),
            "open": 0,
            "merged": 0,
            "closed": 0,
            "cannot_merge": 0,
            "merge_rate": 0.0,
            "by_creator": {},
            "by_project": {},
            "by_status": {},
        }

        if not mrs:
            return stats

        for mr in mrs:
            # 按状态统计
            if mr.is_open:
                stats["open"] += 1
            elif mr.is_merged:
                stats["merged"] += 1
            elif mr.status == MRStatus.CLOSED.value:
                stats["closed"] += 1
            elif mr.status == MRStatus.CANNOTMERGE.value:
                stats["cannot_merge"] += 1

            # 按状态值统计
            if mr.status not in stats["by_status"]:
                stats["by_status"][mr.status] = 0
            stats["by_status"][mr.status] += 1

            # 按创建者统计
            if mr.author:
                author_name = mr.author.name
                if author_name not in stats["by_creator"]:
                    stats["by_creator"][author_name] = {
                        "total": 0,
                        "merged": 0,
                    }
                stats["by_creator"][author_name]["total"] += 1
                if mr.is_merged:
                    stats["by_creator"][author_name]["merged"] += 1

            # 按项目统计
            project_name = mr.project_name or str(mr.project_id)
            if project_name not in stats["by_project"]:
                stats["by_project"][project_name] = {
                    "total": 0,
                    "merged": 0,
                }
            stats["by_project"][project_name]["total"] += 1
            if mr.is_merged:
                stats["by_project"][project_name]["merged"] += 1

        # 计算合并率
        finished_count = stats["merged"] + stats["closed"] + stats["cannot_merge"]
        if finished_count > 0:
            stats["merge_rate"] = round(stats["merged"] / finished_count * 100, 2)

        return stats

    def list_team_weekly_merge_requests(
        self,
        project_ids: list[int],
        project_names: dict[int, str] = None,
        week_start: Optional[date] = None,
    ) -> list[MergeRequest]:
        """
        获取团队本周所有合并请求

        Args:
            project_ids: 项目 ID 列表
            project_names: 项目 ID -> 名称映射
            week_start: 周开始日期

        Returns:
            所有合并请求列表
        """
        if project_names is None:
            project_names = {}

        all_mrs = []
        for project_id in project_ids:
            try:
                mrs = self.list_weekly_merge_requests(
                    project_id=project_id,
                    project_name=project_names.get(project_id, ""),
                    week_start=week_start,
                )
                all_mrs.extend(mrs)
            except Exception:
                continue

        return all_mrs
