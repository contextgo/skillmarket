"""事项（需求/任务/缺陷）相关 API"""

from typing import Optional

from ..client import CodingClient
from ..models import Issue, IssueType, IssueStatusType


class IssuesAPI:
    """事项 API 封装"""

    def __init__(self, client: CodingClient):
        self.client = client

    def list_team_issues(
        self,
        page_number: int = 1,
        page_size: int = 500,
        conditions: Optional[list[dict]] = None,
        sorts: Optional[list[dict]] = None,
        show_sub_issues: bool = False,
    ) -> list[Issue]:
        """
        查询团队事项列表

        Args:
            page_number: 页码
            page_size: 每页数量（最大 500）
            conditions: 筛选条件列表
                - Key: "ASSIGNEE" | "STATUS_TYPE" | "PROJECT_ID" | "ISSUE_TYPE_ID" 等
                - Value: 逗号分隔的值
            sorts: 排序条件列表
                - Key: "UPDATED_AT" | "CREATED_AT" | "PRIORITY" 等
                - Value: "DESC" | "ASC"
            show_sub_issues: 是否展示子事项

        Returns:
            事项列表
        """
        params = {
            "PageNumber": page_number,
            "PageSize": min(page_size, 500),
            "Conditions": conditions or [],
            "Sorts": sorts or [],
            "ShowSubIssues": show_sub_issues,
        }

        data = self.client.request("DescribeTeamIssues", **params)
        issues = data.get("Issues", [])
        return [Issue.model_validate(i) for i in issues]

    def list_all_team_issues(
        self,
        conditions: Optional[list[dict]] = None,
        sorts: Optional[list[dict]] = None,
    ) -> list[Issue]:
        """
        获取所有团队事项

        Args:
            conditions: 筛选条件
            sorts: 排序条件

        Returns:
            所有事项列表
        """
        all_issues = []
        page_number = 1
        page_size = 500

        while True:
            issues = self.list_team_issues(
                page_number=page_number,
                page_size=page_size,
                conditions=conditions,
                sorts=sorts,
            )
            if not issues:
                break
            all_issues.extend(issues)
            if len(issues) < page_size:
                break
            page_number += 1

        return all_issues

    def list_project_issues(
        self,
        project_name: str,
        issue_type: IssueType = IssueType.ALL,
        page_number: int = 1,
        page_size: int = 100,
        conditions: Optional[list[dict]] = None,
        sort_key: str = "CODE",
        sort_value: str = "DESC",
    ) -> list[Issue]:
        """
        查询项目事项列表

        Args:
            project_name: 项目名称
            issue_type: 事项类型
            page_number: 页码
            page_size: 每页数量
            conditions: 筛选条件
            sort_key: 排序字段
            sort_value: 排序方式

        Returns:
            事项列表
        """
        params = {
            "ProjectName": project_name,
            "IssueType": issue_type.value,
            "Offset": (page_number - 1) * page_size,
            "Limit": page_size,
            "Conditions": conditions or [],
            "SortKey": sort_key,
            "SortValue": sort_value,
        }

        data = self.client.request("DescribeIssueList", **params)
        issues = data.get("IssueList", [])
        return [Issue.model_validate(i) for i in issues]

    def list_issues_by_assignee(
        self,
        assignee_id: int,
        status_types: Optional[list[IssueStatusType]] = None,
    ) -> list[Issue]:
        """
        按处理人查询事项

        Args:
            assignee_id: 处理人 ID
            status_types: 状态类型列表

        Returns:
            事项列表
        """
        conditions = [
            {"Key": "ASSIGNEE", "Value": str(assignee_id)},
        ]

        if status_types:
            status_value = ",".join([s.value for s in status_types])
            conditions.append({"Key": "STATUS_TYPE", "Value": status_value})

        return self.list_all_team_issues(conditions=conditions)

    def list_issues_by_project(
        self,
        project_id: int,
        status_types: Optional[list[IssueStatusType]] = None,
    ) -> list[Issue]:
        """
        按项目查询事项

        Args:
            project_id: 项目 ID
            status_types: 状态类型列表

        Returns:
            事项列表
        """
        conditions = [
            {"Key": "PROJECT_ID", "Value": str(project_id)},
        ]

        if status_types:
            status_value = ",".join([s.value for s in status_types])
            conditions.append({"Key": "STATUS_TYPE", "Value": status_value})

        return self.list_all_team_issues(conditions=conditions)

    def get_issue_stats(self, issues: list[Issue]) -> dict:
        """
        统计事项数据

        Args:
            issues: 事项列表

        Returns:
            统计数据
        """
        stats = {
            "total": len(issues),
            "requirements": 0,
            "missions": 0,
            "defects": 0,
            "todo": 0,
            "processing": 0,
            "completed": 0,
            "by_assignee": {},
            "by_project": {},
        }

        for issue in issues:
            # 按类型统计
            if issue.type == IssueType.REQUIREMENT.value:
                stats["requirements"] += 1
            elif issue.type == IssueType.MISSION.value:
                stats["missions"] += 1
            elif issue.type == IssueType.DEFECT.value:
                stats["defects"] += 1

            # 按状态统计
            if issue.is_todo:
                stats["todo"] += 1
            elif issue.is_processing:
                stats["processing"] += 1
            elif issue.is_completed:
                stats["completed"] += 1

            # 按处理人统计
            assignee_id = issue.assignee_id
            if assignee_id not in stats["by_assignee"]:
                stats["by_assignee"][assignee_id] = {
                    "name": issue.assignee_name,
                    "total": 0,
                    "completed": 0,
                    "processing": 0,
                    "todo": 0,
                    "issues": [],
                }
            stats["by_assignee"][assignee_id]["total"] += 1
            if issue.is_completed:
                stats["by_assignee"][assignee_id]["completed"] += 1
            elif issue.is_processing:
                stats["by_assignee"][assignee_id]["processing"] += 1
            elif issue.is_todo:
                stats["by_assignee"][assignee_id]["todo"] += 1
            stats["by_assignee"][assignee_id]["issues"].append(issue)

            # 按项目统计
            project_id = issue.project_id
            if project_id not in stats["by_project"]:
                stats["by_project"][project_id] = {
                    "total": 0,
                    "completed": 0,
                }
            stats["by_project"][project_id]["total"] += 1
            if issue.is_completed:
                stats["by_project"][project_id]["completed"] += 1

        return stats
