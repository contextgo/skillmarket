"""代码提交相关 API"""

from datetime import date, datetime, timedelta
from typing import Optional

from ..client import CodingClient
from ..models import Commit


class GitAPI:
    """Git API 封装"""

    def __init__(self, client: CodingClient):
        self.client = client

    def list_commits(
        self,
        depot_id: int,
        ref: str = "main",
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        page_number: int = 1,
        page_size: int = 100,
        keyword: Optional[str] = None,
        depot_path: Optional[str] = None,
    ) -> list[Commit]:
        """
        查询仓库分支下的提交列表

        Args:
            depot_id: 仓库 ID
            ref: 分支名称
            start_date: 开始日期 (YYYY-MM-DD)
            end_date: 结束日期 (YYYY-MM-DD)
            page_number: 页码
            page_size: 每页数量
            keyword: 提交信息关键词
            depot_path: 仓库路径

        Returns:
            提交记录列表
        """
        params = {
            "DepotId": depot_id,
            "Ref": ref,
            "PageNumber": page_number,
            "PageSize": page_size,
        }

        if start_date:
            params["StartDate"] = start_date
        if end_date:
            params["EndDate"] = end_date
        if keyword:
            params["KeyWord"] = keyword
        if depot_path:
            params["DepotPath"] = depot_path

        data = self.client.request("DescribeGitCommitInfos", **params)
        commits = data.get("Commits", [])
        return [Commit.model_validate(c) for c in commits]

    def list_all_commits(
        self,
        depot_id: int,
        ref: str = "main",
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        max_count: int = 1000,
    ) -> list[Commit]:
        """
        获取所有提交记录

        Args:
            depot_id: 仓库 ID
            ref: 分支名称
            start_date: 开始日期
            end_date: 结束日期
            max_count: 最大获取数量

        Returns:
            提交记录列表
        """
        all_commits = []
        page_number = 1
        page_size = 100

        while len(all_commits) < max_count:
            commits = self.list_commits(
                depot_id=depot_id,
                ref=ref,
                start_date=start_date,
                end_date=end_date,
                page_number=page_number,
                page_size=page_size,
            )
            if not commits:
                break
            all_commits.extend(commits)
            if len(commits) < page_size:
                break
            page_number += 1

        return all_commits[:max_count]

    def list_weekly_commits(
        self,
        depot_id: int,
        ref: str = "main",
        week_start: Optional[date] = None,
    ) -> list[Commit]:
        """
        获取本周提交记录

        Args:
            depot_id: 仓库 ID
            ref: 分支名称
            week_start: 周开始日期，默认为本周一

        Returns:
            提交记录列表
        """
        if week_start is None:
            today = date.today()
            week_start = today - timedelta(days=today.weekday())

        week_end = week_start + timedelta(days=6)

        return self.list_all_commits(
            depot_id=depot_id,
            ref=ref,
            start_date=week_start.strftime("%Y-%m-%d"),
            end_date=week_end.strftime("%Y-%m-%d"),
        )

    def list_depot_commits(
        self,
        depot_id: int,
        depot_name: str = "",
        project_id: int = 0,
        project_name: str = "",
        ref: str = "dev",
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> list[Commit]:
        """
        获取仓库提交记录（带项目信息）

        Args:
            depot_id: 仓库 ID
            depot_name: 仓库名称
            project_id: 项目 ID
            project_name: 项目名称
            ref: 分支名称
            start_date: 开始日期
            end_date: 结束日期

        Returns:
            提交记录列表
        """
        commits = self.list_all_commits(
            depot_id=depot_id,
            ref=ref,
            start_date=start_date,
            end_date=end_date,
        )

        # 附加项目信息
        for commit in commits:
            commit.depot_id = depot_id
            commit.depot_name = depot_name
            commit.project_id = project_id
            commit.project_name = project_name

        return commits

    def get_commit_stats(self, commits: list[Commit]) -> dict:
        """
        统计提交数据

        Args:
            commits: 提交记录列表

        Returns:
            统计数据
        """
        stats = {
            "total": len(commits),
            "by_author": {},
            "by_date": {},
            "by_project": {},
            "by_depot": {},
        }

        for commit in commits:
            # 按作者统计
            author = commit.author_email or commit.author_name
            if author not in stats["by_author"]:
                stats["by_author"][author] = {
                    "name": commit.author_name,
                    "email": commit.author_email,
                    "count": 0,
                }
            stats["by_author"][author]["count"] += 1

            # 按日期统计
            if commit.commit_date:
                commit_date = datetime.fromtimestamp(commit.commit_date / 1000).strftime("%Y-%m-%d")
                if commit_date not in stats["by_date"]:
                    stats["by_date"][commit_date] = 0
                stats["by_date"][commit_date] += 1

            # 按项目统计
            project_name = commit.project_name or str(commit.project_id)
            if project_name not in stats["by_project"]:
                stats["by_project"][project_name] = 0
            stats["by_project"][project_name] += 1

            # 按仓库统计
            depot_name = commit.depot_name or str(commit.depot_id)
            if depot_name not in stats["by_depot"]:
                stats["by_depot"][depot_name] = 0
            stats["by_depot"][depot_name] += 1

        # 按提交次数排序作者
        stats["top_authors"] = sorted(
            stats["by_author"].values(),
            key=lambda x: x["count"],
            reverse=True,
        )[:10]

        return stats
