"""Coding DevOps API 基础客户端"""

import os
from typing import Any, Optional

import requests
from pydantic import BaseModel
from dotenv import load_dotenv

load_dotenv()


class CodingAPIError(Exception):
    """Coding API 错误"""
    def __init__(self, code: str, message: str, request_id: str = ""):
        self.code = code
        self.message = message
        self.request_id = request_id
        super().__init__(f"[{code}] {message} (RequestId: {request_id})")


class CodingConfig(BaseModel):
    """Coding API 配置"""
    team_domain: str  # 团队域名前缀，如 your-team.coding.net 中的 your-team
    access_token: str  # 访问令牌
    api_base: str = "https://e.coding.net/open-api"  # API 基础地址

    @classmethod
    def from_env(cls) -> "CodingConfig":
        """从环境变量加载配置"""
        team_domain = os.getenv("CODING_TEAM_DOMAIN", "")
        access_token = os.getenv("CODING_ACCESS_TOKEN", "")

        if not team_domain:
            raise ValueError("CODING_TEAM_DOMAIN 环境变量未设置")
        if not access_token:
            raise ValueError("CODING_ACCESS_TOKEN 环境变量未设置")

        return cls(
            team_domain=team_domain,
            access_token=access_token,
        )


class CodingClient:
    """Coding DevOps API 客户端"""

    def __init__(self, config: Optional[CodingConfig] = None):
        self.config = config or CodingConfig.from_env()
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"token {self.config.access_token}",
            "Content-Type": "application/json",
        })

    def _build_url(self) -> str:
        """构建 API URL"""
        return self.config.api_base

    def request(self, action: str, **params) -> dict[str, Any]:
        """
        发送 API 请求

        Args:
            action: API Action 名称
            **params: 请求参数

        Returns:
            API 响应数据
        """
        url = self._build_url()
        payload = {"Action": action, **params}

        # 移除 None 值的参数
        payload = {k: v for k, v in payload.items() if v is not None}

        response = self.session.post(url, json=payload, timeout=30)
        response.raise_for_status()

        data = response.json()
        response_data = data.get("Response", {})

        # 检查错误
        if "Error" in response_data:
            error = response_data["Error"]
            raise CodingAPIError(
                code=error.get("Code", "UnknownError"),
                message=error.get("Message", "Unknown error"),
                request_id=response_data.get("RequestId", ""),
            )

        return response_data

    def request_with_pagination(
        self,
        action: str,
        page_number: int = 1,
        page_size: int = 100,
        **params,
    ) -> tuple[list, int]:
        """
        发送带分页的 API 请求

        Args:
            action: API Action 名称
            page_number: 页码
            page_size: 每页数量
            **params: 其他请求参数

        Returns:
            (数据列表, 总数)
        """
        params["PageNumber"] = page_number
        params["PageSize"] = page_size

        response = self.request(action, **params)

        # 提取列表数据（不同接口返回格式不同）
        if "Data" in response:
            data = response["Data"]
            if isinstance(data, dict):
                # 项目列表格式
                if "ProjectList" in data:
                    return data["ProjectList"], data.get("TotalCount", 0)
                # 团队成员格式
                if "TeamMembers" in data:
                    return data["TeamMembers"], data.get("TotalCount", 0)
                # 分页数据格式
                if "List" in data:
                    return data["List"], data.get("TotalRow", 0)
                return data, 0
            return data, 0

        # 事项列表格式
        if "Issues" in response:
            return response["Issues"], response.get("TotalCount", 0)
        if "IssueList" in response:
            return response["IssueList"], len(response["IssueList"])

        # 构建列表格式
        if "Data" not in response:
            if "BuildList" in response:
                data = response.get("Data", {})
                return data.get("BuildList", []), data.get("TotalRow", 0)

        # MR 列表格式
        if "List" in response.get("Data", {}):
            data = response["Data"]
            return data["List"], data.get("TotalRow", 0)

        # 提交列表格式
        if "Commits" in response:
            return response["Commits"], len(response["Commits"])
        if "Data" in response and "Commits" in response["Data"]:
            data = response["Data"]
            return data["Commits"], data.get("TotalRow", 0)

        return [], 0

    def request_all_pages(
        self,
        action: str,
        page_size: int = 100,
        max_pages: int = 100,
        **params,
    ) -> list:
        """
        获取所有分页数据

        Args:
            action: API Action 名称
            page_size: 每页数量
            max_pages: 最大页数限制
            **params: 其他请求参数

        Returns:
            所有数据列表
        """
        all_data = []
        page_number = 1

        while page_number <= max_pages:
            data, total = self.request_with_pagination(
                action, page_number, page_size, **params
            )

            if not data:
                break

            all_data.extend(data)

            # 检查是否还有更多数据
            if len(all_data) >= total or len(data) < page_size:
                break

            page_number += 1

        return all_data
