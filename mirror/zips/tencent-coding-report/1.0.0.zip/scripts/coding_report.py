#!/usr/bin/env python3
"""Coding 团队周报工具 - OpenClaw Skill 入口"""

import os
import sys
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Optional

import click
from dotenv import load_dotenv

# 添加 scripts 目录到 Python 路径
script_dir = Path(__file__).parent
if str(script_dir) not in sys.path:
    sys.path.insert(0, str(script_dir))

from coding_api import CodingClient, CodingConfig, CodingAPIError
from weekly_report import WeeklyReportCollector, WeeklyReportAggregator, WeeklyReportGenerator

# 优先从 skill 根目录加载 .env
skill_root = Path(__file__).parent.parent
load_dotenv(skill_root / ".env")


@click.group()
@click.version_option(version="0.1.0")
def cli():
    """Coding 团队周报工具"""
    pass


@cli.command()
@click.option("--start-date", "-s", default=None, help="周开始日期 (YYYY-MM-DD)，默认为本周一")
@click.option("--output", "-o", default="weekly_report.md", help="输出文件路径")
@click.option("--project-ids", "-p", default=None, help="项目 ID 列表，逗号分隔")
@click.option("--member-ids", "-m", default=None, help="成员 ID 列表，逗号分隔")
@click.option("--no-builds", is_flag=True, help="不包含构建数据")
@click.option("--no-commits", is_flag=True, help="不包含代码提交数据")
@click.option("--no-mrs", is_flag=True, help="不包含合并请求数据")
def generate(start_date, output, project_ids, member_ids, no_builds, no_commits, no_mrs):
    """生成团队周报"""
    try:
        if start_date:
            week_start = datetime.strptime(start_date, "%Y-%m-%d").date()
        else:
            today = date.today()
            week_start = today - timedelta(days=today.weekday())

        project_id_list = [int(x.strip()) for x in project_ids.split(",")] if project_ids else None
        member_id_list = [int(x.strip()) for x in member_ids.split(",")] if member_ids else None

        click.echo(f"正在生成周报 ({week_start} ~ {week_start + timedelta(days=6)})...")

        config = CodingConfig.from_env()
        client = CodingClient(config)

        collector = WeeklyReportCollector(client)
        data = collector.collect(
            week_start=week_start,
            project_ids=project_id_list,
            member_ids=member_id_list,
            include_builds=not no_builds,
            include_commits=not no_commits,
            include_merge_requests=not no_mrs,
        )

        aggregator = WeeklyReportAggregator()
        stats = aggregator.aggregate(data)

        generator = WeeklyReportGenerator()
        output_path = Path(output)
        generator.generate_and_save(stats, output_path)

        click.echo(f"周报已生成: {output_path}")
        click.echo("\n" + aggregator.get_summary_text(stats))

    except ValueError as e:
        click.echo(f"配置错误: {e}", err=True)
        sys.exit(1)
    except CodingAPIError as e:
        click.echo(f"API 错误: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"生成失败: {e}", err=True)
        sys.exit(1)


@cli.command()
@click.argument("member_id")
@click.option("--start-date", "-s", default=None, help="周开始日期 (YYYY-MM-DD)，默认为本周一")
@click.option("--output", "-o", default=None, help="输出文件路径")
def member(member_id, start_date, output):
    """生成指定成员的周报"""
    try:
        if start_date:
            week_start = datetime.strptime(start_date, "%Y-%m-%d").date()
        else:
            today = date.today()
            week_start = today - timedelta(days=today.weekday())

        if output is None:
            output = f"weekly_report_member_{member_id}.md"

        click.echo(f"正在生成成员 {member_id} 的周报...")

        config = CodingConfig.from_env()
        client = CodingClient(config)

        collector = WeeklyReportCollector(client)
        data = collector.collect_for_member(member_id=int(member_id), week_start=week_start)

        aggregator = WeeklyReportAggregator()
        stats = aggregator.aggregate(data)

        generator = WeeklyReportGenerator()
        generator.generate_and_save(stats, Path(output))

        click.echo(f"成员周报已生成: {output}")

    except Exception as e:
        click.echo(f"生成失败: {e}", err=True)
        sys.exit(1)


@cli.command()
@click.argument("project_id")
@click.option("--start-date", "-s", default=None, help="周开始日期 (YYYY-MM-DD)，默认为本周一")
@click.option("--output", "-o", default=None, help="输出文件路径")
def project(project_id, start_date, output):
    """生成指定项目的周报"""
    try:
        if start_date:
            week_start = datetime.strptime(start_date, "%Y-%m-%d").date()
        else:
            today = date.today()
            week_start = today - timedelta(days=today.weekday())

        if output is None:
            output = f"weekly_report_project_{project_id}.md"

        click.echo(f"正在生成项目 {project_id} 的周报...")

        config = CodingConfig.from_env()
        client = CodingClient(config)

        collector = WeeklyReportCollector(client)
        data = collector.collect_for_project(project_id=int(project_id), week_start=week_start)

        aggregator = WeeklyReportAggregator()
        stats = aggregator.aggregate(data)

        generator = WeeklyReportGenerator()
        generator.generate_and_save(stats, Path(output))

        click.echo(f"项目周报已生成: {output}")

    except Exception as e:
        click.echo(f"生成失败: {e}", err=True)
        sys.exit(1)


@cli.command()
def config():
    """显示当前配置"""
    click.echo("当前配置:")
    click.echo(f"  CODING_TEAM_DOMAIN: {os.getenv('CODING_TEAM_DOMAIN', '(未设置)')}")
    click.echo(f"  CODING_ACCESS_TOKEN: {'*' * 8 if os.getenv('CODING_ACCESS_TOKEN') else '(未设置)'}")


def main():
    cli()


if __name__ == "__main__":
    main()
