"""周报数据聚合器"""

from dataclasses import dataclass, field
from datetime import date, datetime
from typing import Any

from coding_api.models import Issue, Build, Commit, MergeRequest
from weekly_report.collector import WeeklyReportData


@dataclass
class IssueStats:
    """事项统计"""
    total: int = 0
    requirements: int = 0
    missions: int = 0
    defects: int = 0
    completed: int = 0
    processing: int = 0
    todo: int = 0
    completion_rate: float = 0.0
    by_assignee: dict[str, dict[str, Any]] = field(default_factory=dict)
    by_project: dict[str, dict[str, Any]] = field(default_factory=dict)


@dataclass
class BuildStats:
    """构建统计"""
    total: int = 0
    succeed: int = 0
    failed: int = 0
    aborted: int = 0
    running: int = 0
    success_rate: float = 0.0
    avg_duration_seconds: float = 0.0
    total_duration_seconds: float = 0.0
    by_project: dict[str, dict[str, Any]] = field(default_factory=dict)
    by_job: dict[str, dict[str, Any]] = field(default_factory=dict)


@dataclass
class CommitStats:
    """提交统计"""
    total: int = 0
    by_author: dict[str, dict[str, Any]] = field(default_factory=dict)
    by_date: dict[str, int] = field(default_factory=dict)
    by_project: dict[str, int] = field(default_factory=dict)
    top_authors: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class MRStats:
    """合并请求统计"""
    total: int = 0
    open: int = 0
    merged: int = 0
    closed: int = 0
    cannot_merge: int = 0
    merge_rate: float = 0.0
    by_creator: dict[str, dict[str, Any]] = field(default_factory=dict)
    by_project: dict[str, dict[str, Any]] = field(default_factory=dict)


@dataclass
class WeeklyReportStats:
    """周报统计数据"""
    week_start: date
    week_end: date
    project_count: int = 0
    member_count: int = 0
    issues: IssueStats = field(default_factory=IssueStats)
    builds: BuildStats = field(default_factory=BuildStats)
    commits: CommitStats = field(default_factory=CommitStats)
    merge_requests: MRStats = field(default_factory=MRStats)


class WeeklyReportAggregator:
    """周报数据聚合器"""

    def aggregate(self, data: WeeklyReportData) -> WeeklyReportStats:
        """
        聚合周报数据

        Args:
            data: 原始数据

        Returns:
            聚合后的统计数据
        """
        stats = WeeklyReportStats(
            week_start=data.week_start,
            week_end=data.week_end,
            project_count=len(data.projects),
            member_count=len(data.members),
        )

        # 聚合事项数据
        stats.issues = self._aggregate_issues(data)

        # 聚合构建数据
        stats.builds = self._aggregate_builds(data.builds)

        # 聚合提交数据
        stats.commits = self._aggregate_commits(data.commits)

        # 聚合合并请求数据
        stats.merge_requests = self._aggregate_merge_requests(data.merge_requests)

        return stats

    def _aggregate_issues(self, data: WeeklyReportData) -> IssueStats:
        """聚合事项数据"""
        stats = IssueStats()
        issues = data.issues
        stats.total = len(issues)

        for issue in issues:
            # 按类型统计
            issue_type = (issue.type or "").upper()
            if "REQUIREMENT" in issue_type:
                stats.requirements += 1
            elif "MISSION" in issue_type or "TASK" in issue_type:
                stats.missions += 1
            elif "DEFECT" in issue_type or "BUG" in issue_type:
                stats.defects += 1

            # 按状态统计
            status_type = (issue.issue_status_type or "").upper()
            if status_type == "COMPLETED":
                stats.completed += 1
            elif status_type == "PROCESSING":
                stats.processing += 1
            elif status_type == "TODO":
                stats.todo += 1

            # 按处理人统计
            assignee_id = issue.assignee_id
            assignee_name = data.member_names.get(assignee_id, f"用户{assignee_id}")
            if assignee_name not in stats.by_assignee:
                stats.by_assignee[assignee_name] = {
                    "total": 0,
                    "completed": 0,
                    "requirements": 0,
                    "missions": 0,
                    "defects": 0,
                }
            stats.by_assignee[assignee_name]["total"] += 1
            if status_type == "COMPLETED":
                stats.by_assignee[assignee_name]["completed"] += 1
            if "REQUIREMENT" in issue_type:
                stats.by_assignee[assignee_name]["requirements"] += 1
            elif "MISSION" in issue_type or "TASK" in issue_type:
                stats.by_assignee[assignee_name]["missions"] += 1
            elif "DEFECT" in issue_type or "BUG" in issue_type:
                stats.by_assignee[assignee_name]["defects"] += 1

            # 按项目统计
            project_name = data.project_names.get(issue.project_id, f"项目{issue.project_id}")
            if project_name not in stats.by_project:
                stats.by_project[project_name] = {"total": 0, "completed": 0}
            stats.by_project[project_name]["total"] += 1
            if status_type == "COMPLETED":
                stats.by_project[project_name]["completed"] += 1

        # 计算完成率
        if stats.total > 0:
            stats.completion_rate = round(stats.completed / stats.total * 100, 2)

        return stats

    def _aggregate_builds(self, builds: list[Build]) -> BuildStats:
        """聚合构建数据"""
        stats = BuildStats()
        stats.total = len(builds)

        if not builds:
            return stats

        total_duration = 0
        for build in builds:
            status = (build.status or "").upper()

            # 按状态统计
            if status == "SUCCEED":
                stats.succeed += 1
            elif status == "FAILED":
                stats.failed += 1
            elif status == "ABORTED":
                stats.aborted += 1
            elif status in ["RUNNING", "WAITING"]:
                stats.running += 1

            # 计算耗时
            total_duration += build.duration or 0

            # 按项目统计
            project_name = build.project_name or f"项目{build.project_id}"
            if project_name not in stats.by_project:
                stats.by_project[project_name] = {"total": 0, "succeed": 0, "failed": 0}
            stats.by_project[project_name]["total"] += 1
            if status == "SUCCEED":
                stats.by_project[project_name]["succeed"] += 1
            elif status == "FAILED":
                stats.by_project[project_name]["failed"] += 1

            # 按构建计划统计
            job_name = getattr(build, "job_name", None) or "未命名构建计划"
            if job_name not in stats.by_job:
                stats.by_job[job_name] = {"total": 0, "succeed": 0, "failed": 0}
            stats.by_job[job_name]["total"] += 1
            if status == "SUCCEED":
                stats.by_job[job_name]["succeed"] += 1
            elif status == "FAILED":
                stats.by_job[job_name]["failed"] += 1

        # 计算成功率和平均耗时
        finished_count = stats.succeed + stats.failed + stats.aborted
        if finished_count > 0:
            stats.success_rate = round(stats.succeed / finished_count * 100, 2)

        if stats.total > 0:
            stats.avg_duration_seconds = round(total_duration / stats.total / 1000, 2)

        stats.total_duration_seconds = total_duration / 1000

        return stats

    def _aggregate_commits(self, commits: list[Commit]) -> CommitStats:
        """聚合提交数据"""
        stats = CommitStats()
        stats.total = len(commits)

        if not commits:
            return stats

        for commit in commits:
            # 按作者统计
            author = commit.author_email or commit.author_name
            if author not in stats.by_author:
                stats.by_author[author] = {
                    "name": commit.author_name,
                    "email": commit.author_email,
                    "count": 0,
                }
            stats.by_author[author]["count"] += 1

            # 按日期统计
            commit_date = getattr(commit, "commit_date", None)
            if commit_date:
                commit_date_str = datetime.fromtimestamp(
                    commit_date / 1000
                ).strftime("%Y-%m-%d")
                stats.by_date[commit_date_str] = stats.by_date.get(commit_date_str, 0) + 1

            # 按项目统计
            project_name = commit.project_name or f"项目{commit.project_id}"
            stats.by_project[project_name] = stats.by_project.get(project_name, 0) + 1

        # 排序获取 top 提交者
        stats.top_authors = sorted(
            stats.by_author.values(),
            key=lambda x: x["count"],
            reverse=True,
        )[:10]

        return stats

    def _aggregate_merge_requests(self, mrs: list[MergeRequest]) -> MRStats:
        """聚合合并请求数据"""
        stats = MRStats()
        stats.total = len(mrs)

        if not mrs:
            return stats

        for mr in mrs:
            # 按状态统计
            if mr.is_open:
                stats.open += 1
            elif mr.is_merged:
                stats.merged += 1
            elif mr.status == "CLOSED":
                stats.closed += 1
            elif mr.status == "CANNOTMERGE":
                stats.cannot_merge += 1

            # 按创建者统计
            if mr.author:
                creator_name = mr.author.name
                if creator_name not in stats.by_creator:
                    stats.by_creator[creator_name] = {"total": 0, "merged": 0}
                stats.by_creator[creator_name]["total"] += 1
                if mr.is_merged:
                    stats.by_creator[creator_name]["merged"] += 1

            # 按项目统计
            project_name = mr.project_name or f"项目{mr.project_id}"
            if project_name not in stats.by_project:
                stats.by_project[project_name] = {"total": 0, "merged": 0}
            stats.by_project[project_name]["total"] += 1
            if mr.is_merged:
                stats.by_project[project_name]["merged"] += 1

        # 计算合并率
        finished_count = stats.merged + stats.closed + stats.cannot_merge
        if finished_count > 0:
            stats.merge_rate = round(stats.merged / finished_count * 100, 2)

        return stats

    def get_summary_text(self, stats: WeeklyReportStats) -> str:
        """生成摘要文本"""
        lines = [
            f"## 周报摘要 ({stats.week_start} ~ {stats.week_end})",
            "",
            "### 项目与团队",
            f"- 项目数: {stats.project_count}",
            f"- 团队成员数: {stats.member_count}",
            "",
            "### 事项完成情况",
            f"- 总计: {stats.issues.total} 项",
            f"- 已完成: {stats.issues.completed} 项 ({stats.issues.completion_rate}%)",
            f"- 进行中: {stats.issues.processing} 项",
            f"- 待处理: {stats.issues.todo} 项",
            f"  - 需求: {stats.issues.requirements}",
            f"  - 任务: {stats.issues.missions}",
            f"  - 缺陷: {stats.issues.defects}",
            "",
        ]

        if stats.builds.total > 0:
            lines.extend([
                "### 构建情况",
                f"- 总构建次数: {stats.builds.total}",
                f"- 成功: {stats.builds.succeed}, 失败: {stats.builds.failed}, 中止: {stats.builds.aborted}",
                f"- 成功率: {stats.builds.success_rate}%",
                f"- 平均构建时长: {stats.builds.avg_duration_seconds}秒",
                "",
            ])

        if stats.commits.total > 0:
            lines.extend([
                "### 代码提交",
                f"- 总提交次数: {stats.commits.total}",
            ])
            if stats.commits.top_authors:
                top = stats.commits.top_authors[0]
                lines.append(f"- 最活跃提交者: {top['name']} ({top['count']}次)")
            lines.append("")

        if stats.merge_requests.total > 0:
            lines.extend([
                "### 合并请求",
                f"- 总 MR 数: {stats.merge_requests.total}",
                f"- 已合并: {stats.merge_requests.merged}, 待处理: {stats.merge_requests.open}",
                f"- 合并率: {stats.merge_requests.merge_rate}%",
                "",
            ])

        return "\n".join(lines)
