"""周报模块"""

from .collector import WeeklyReportCollector
from .aggregator import WeeklyReportAggregator
from .generator import WeeklyReportGenerator

__all__ = [
    "WeeklyReportCollector",
    "WeeklyReportAggregator",
    "WeeklyReportGenerator",
]
