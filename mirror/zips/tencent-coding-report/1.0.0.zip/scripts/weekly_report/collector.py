"""周报数据收集器"""

from dataclasses import dataclass, field
from datetime import date, timedelta, datetime
from typing import Optional

from coding_api.client import CodingClient
from coding_api.models import Project, TeamMember, Issue, Build, Commit, MergeRequest, Depot


@dataclass
class WeeklyReportData:
    """周报数据"""
    # 时间范围
    week_start: date
    week_end: date

    # 基础数据
    projects: list[Project] = field(default_factory=list)
    members: list[TeamMember] = field(default_factory=list)

    # 事项数据
    issues: list[Issue] = field(default_factory=list)

    # 构建数据
    builds: list[Build] = field(default_factory=list)

    # 代码提交数据
    commits: list[Commit] = field(default_factory=list)

    # 合并请求数据
    merge_requests: list[MergeRequest] = field(default_factory=list)

    # 仓库映射
    depots: dict[int, list[Depot]] = field(default_factory=dict)
    depot_names: dict[int, str] = field(default_factory=dict)
    project_names: dict[int, str] = field(default_factory=dict)
    member_names: dict[int, str] = field(default_factory=dict)


class WeeklyReportCollector:
    """周报数据收集器"""

    def __init__(self, client: CodingClient):
        self.client = client

    def collect(
        self,
        week_start: Optional[date] = None,
        project_ids: Optional[list[int]] = None,
        member_ids: Optional[list[int]] = None,
        include_builds: bool = True,
        include_commits: bool = True,
        include_merge_requests: bool = True,
    ) -> WeeklyReportData:
        """
        收集周报数据

        Args:
            week_start: 周开始日期，默认本周一
            project_ids: 指定项目 ID 列表，为空则获取所有项目
            member_ids: 指定成员 ID 列表，为空则获取所有成员
            include_builds: 是否包含构建数据
            include_commits: 是否包含代码提交数据
            include_merge_requests: 是否包含合并请求数据

        Returns:
            周报数据
        """
        # 计算时间范围
        if week_start is None:
            today = date.today()
            week_start = today - timedelta(days=today.weekday())
        week_end = week_start + timedelta(days=6)

        data = WeeklyReportData(
            week_start=week_start,
            week_end=week_end,
        )

        # 1. 获取项目列表
        print("正在获取项目列表...")
        try:
            project_resp = self.client.request("DescribeCodingProjects", PageNumber=1, PageSize=100)
            project_list = project_resp.get("Data", {}).get("ProjectList", [])
            data.projects = [Project.model_validate(p) for p in project_list]
            data.project_names = {p.id: p.display_name or p.name for p in data.projects}
        except Exception as e:
            print(f"获取项目列表失败: {e}")
            data.projects = []
            data.project_names = {}

        # 2. 获取团队成员列表
        print("正在获取团队成员列表...")
        try:
            member_resp = self.client.request("DescribeTeamMembers", PageNumber=1, PageSize=100)
            member_list = member_resp.get("Data", {}).get("TeamMembers", [])
            data.members = [TeamMember.model_validate(m) for m in member_list]
            data.member_names = {m.id: m.name for m in data.members}
        except Exception as e:
            print(f"获取团队成员列表失败: {e}")
            data.members = []
            data.member_names = {}

        # 筛选项目
        target_project_ids = project_ids if project_ids else [p.id for p in data.projects]

        # 3. 获取事项数据
        print("正在获取事项数据...")
        data.issues = self._collect_issues(member_ids, data.project_names, data.member_names, week_start, week_end)

        # 4. 获取构建数据
        if include_builds:
            print("正在获取构建数据...")
            data.builds = self._collect_builds(target_project_ids, data.project_names, week_start, week_end)

        # 5. 获取代码提交数据
        if include_commits:
            print("正在获取仓库列表和代码提交数据...")
            data.depots = self._collect_depots(target_project_ids)
            data.commits = self._collect_commits(
                data.depots,
                data.project_names,
                week_start.strftime("%Y-%m-%d"),
                week_end.strftime("%Y-%m-%d"),
            )

        # 6. 获取合并请求数据
        if include_merge_requests:
            print("正在获取合并请求数据...")
            data.merge_requests = self._collect_merge_requests(
                target_project_ids,
                data.project_names,
                week_start.strftime("%Y-%m-%d"),
                week_end.strftime("%Y-%m-%d"),
            )

        print("数据收集完成!")
        return data

    def _collect_issues(
        self,
        member_ids: Optional[list[int]],
        project_names: dict[int, str],
        member_names: dict[int, str],
        week_start: date,
        week_end: date,
    ) -> list[Issue]:
        """收集事项数据"""
        try:
            # 转换为毫秒时间戳
            week_start_ts = int(datetime.combine(week_start, datetime.min.time()).timestamp() * 1000)
            week_end_ts = int(datetime.combine(week_end, datetime.max.time()).timestamp() * 1000)

            conditions = []
            if member_ids:
                conditions.append({"Key": "ASSIGNEE", "Value": ",".join(str(x) for x in member_ids)})

            # 添加更新时间筛选
            conditions.append({"Key": "UPDATED_AT", "Value": f"{week_start_ts},{week_end_ts}"})

            # 分页获取所有事项
            all_issues = []
            page_number = 1
            page_size = 500

            while True:
                resp = self.client.request(
                    "DescribeTeamIssues",
                    PageNumber=page_number,
                    PageSize=page_size,
                    Conditions=conditions,
                )
                issue_list = resp.get("Issues", [])
                if not issue_list:
                    break
                issues = [Issue.model_validate(i) for i in issue_list]

                # 客户端筛选：确保只返回在时间范围内的事项
                for issue in issues:
                    if issue.updated_at and week_start_ts <= issue.updated_at <= week_end_ts:
                        all_issues.append(issue)

                # 如果返回数量少于页大小，说明已经是最后一页
                if len(issues) < page_size:
                    break
                page_number += 1

            return all_issues
        except Exception as e:
            print(f"获取事项数据失败: {e}")
            return []

    def _collect_builds(
        self,
        project_ids: list[int],
        project_names: dict[int, str],
        week_start: date,
        week_end: date,
    ) -> list[Build]:
        """收集构建数据"""
        all_builds = []

        # 转换为毫秒时间戳
        week_start_ts = int(datetime.combine(week_start, datetime.min.time()).timestamp() * 1000)
        week_end_ts = int(datetime.combine(week_end, datetime.max.time()).timestamp() * 1000)

        for project_id in project_ids:
            try:
                # 获取构建计划列表
                jobs_resp = self.client.request(
                    "DescribeCodingCIJobs",
                    ProjectId=project_id,
                )
                jobs = jobs_resp.get("JobList", [])

                for job in jobs:
                    job_id = job.get("Id")
                    job_name = job.get("Name", "")

                    # 获取构建记录（默认按时间倒序，最新的在前）
                    builds_resp = self.client.request(
                        "DescribeCodingCIBuilds",
                        JobId=job_id,
                        PageNumber=1,
                        PageSize=100,
                    )
                    build_data = builds_resp.get("Data", {})
                    build_list = build_data.get("BuildList", [])

                    for b in build_list:
                        build_obj = Build.model_validate(b)
                        # 跳过没有创建时间的记录
                        if not build_obj.created_at:
                            continue
                        # 如果已超出时间范围（倒序排列，后面的更旧），提前退出
                        if build_obj.created_at < week_start_ts:
                            break
                        # 客户端时间筛选
                        if build_obj.created_at <= week_end_ts:
                            b["project_id"] = project_id
                            b["project_name"] = project_names.get(project_id, str(project_id))
                            b["job_name"] = job_name
                            all_builds.append(Build.model_validate(b))

            except Exception as e:
                print(f"获取项目 {project_id} 的构建数据失败: {e}")
                continue

        return all_builds

    def _collect_depots(self, project_ids: list[int]) -> dict[int, list[Depot]]:
        """收集仓库列表"""
        depots = {}

        for project_id in project_ids:
            try:
                resp = self.client.request(
                    "DescribeProjectDepotInfoList",
                    ProjectId=project_id,
                )
                depot_data = resp.get("DepotData", {})
                depot_list = depot_data.get("Depots", [])
                depots[project_id] = [Depot.model_validate(d) for d in depot_list]
            except Exception as e:
                print(f"获取项目 {project_id} 的仓库列表失败: {e}")
                depots[project_id] = []

        return depots

    def _collect_commits(
        self,
        depots: dict[int, list[Depot]],
        project_names: dict[int, str],
        start_date: str,
        end_date: str,
    ) -> list[Commit]:
        """收集代码提交数据"""
        all_commits = []
        # 常用分支名称列表，按优先级排序
        common_branches = ["main", "dev"]

        for project_id, depot_list in depots.items():
            project_name = project_names.get(project_id, str(project_id))

            for depot in depot_list:
                # 构建要尝试的分支列表
                branches_to_try = []
                if depot.default_branch and depot.default_branch not in ["", "null"]:
                    branches_to_try.append(depot.default_branch)
                branches_to_try.extend(common_branches)

                # 去重
                branches_to_try = list(dict.fromkeys(branches_to_try))

                commits_fetched = False
                for branch in branches_to_try:
                    try:
                        resp = self.client.request(
                            "DescribeGitCommitInfos",
                            DepotId=depot.id,
                            Ref=branch,
                            StartDate=start_date,
                            EndDate=end_date,
                            PageNumber=1,
                            PageSize=100,
                        )
                        commit_list = resp.get("Commits", [])

                        if commit_list:
                            for c in commit_list:
                                c["project_id"] = project_id
                                c["project_name"] = project_name
                                c["depot_id"] = depot.id
                                c["depot_name"] = depot.name
                                all_commits.append(Commit.model_validate(c))
                            commits_fetched = True
                            break  # 成功获取，跳出分支尝试循环

                    except Exception:
                        continue  # 尝试下一个分支

                if not commits_fetched:
                    print(f"获取仓库 {depot.name} 的提交记录失败: 无法找到有效分支")

        return all_commits

    def _collect_merge_requests(
        self,
        project_ids: list[int],
        project_names: dict[int, str],
        start_date: str,
        end_date: str,
    ) -> list[MergeRequest]:
        """收集合并请求数据"""
        all_mrs = []

        for project_id in project_ids:
            try:
                resp = self.client.request(
                    "DescribeProjectMergeRequests",
                    ProjectId=project_id,
                    CreatedAtStartDate=start_date,
                    CreatedAtEndDate=end_date,
                    PageNumber=1,
                    PageSize=100,
                )
                mr_list = resp.get("Data", {}).get("List", [])

                for mr in mr_list:
                    mr["project_id"] = project_id
                    mr["project_name"] = project_names.get(project_id, str(project_id))
                    all_mrs.append(MergeRequest.model_validate(mr))

            except Exception as e:
                print(f"获取项目 {project_id} 的合并请求失败: {e}")
                continue

        return all_mrs

    def collect_for_member(
        self,
        member_id: int,
        week_start: Optional[date] = None,
    ) -> WeeklyReportData:
        """为特定成员收集周报数据"""
        return self.collect(
            week_start=week_start,
            member_ids=[member_id],
        )

    def collect_for_project(
        self,
        project_id: int,
        week_start: Optional[date] = None,
    ) -> WeeklyReportData:
        """为特定项目收集周报数据"""
        return self.collect(
            week_start=week_start,
            project_ids=[project_id],
        )
