"""周报生成器"""

from datetime import date
from pathlib import Path
from typing import Optional

from .aggregator import WeeklyReportStats


class WeeklyReportGenerator:
    """周报生成器"""

    def __init__(self, template_dir: Optional[Path] = None):
        self.template_dir = template_dir

    def generate_markdown(self, stats: WeeklyReportStats) -> str:
        """
        生成 Markdown 格式周报

        Args:
            stats: 周报统计数据

        Returns:
            Markdown 内容
        """
        lines = []

        # 标题
        lines.append(f"# 团队周报")
        lines.append("")
        lines.append(f"**统计周期**: {stats.week_start} ~ {stats.week_end}")
        lines.append("")

        # 概览
        lines.append("## 📊 概览")
        lines.append("")
        lines.append("| 指标 | 数值 |")
        lines.append("| --- | --- |")
        lines.append(f"| 项目数 | {stats.project_count} |")
        lines.append(f"| 团队成员数 | {stats.member_count} |")
        lines.append(f"| 事项总数 | {stats.issues.total} |")
        lines.append(f"| 已完成事项 | {stats.issues.completed} ({stats.issues.completion_rate}%) |")
        if stats.builds.total > 0:
            lines.append(f"| 构建总数 | {stats.builds.total} |")
            lines.append(f"| 构建成功率 | {stats.builds.success_rate}% |")
        if stats.commits.total > 0:
            lines.append(f"| 代码提交数 | {stats.commits.total} |")
        if stats.merge_requests.total > 0:
            lines.append(f"| 合并请求数 | {stats.merge_requests.total} |")
            lines.append(f"| MR 合并率 | {stats.merge_requests.merge_rate}% |")
        lines.append("")

        # 事项统计
        lines.append("## 📋 事项统计")
        lines.append("")
        lines.append("### 按类型分布")
        lines.append("")
        lines.append("| 类型 | 数量 |")
        lines.append("| --- | --- |")
        lines.append(f"| 需求 | {stats.issues.requirements} |")
        lines.append(f"| 任务 | {stats.issues.missions} |")
        lines.append(f"| 缺陷 | {stats.issues.defects} |")
        lines.append("")

        lines.append("### 按状态分布")
        lines.append("")
        lines.append("| 状态 | 数量 |")
        lines.append("| --- | --- |")
        lines.append(f"| 已完成 | {stats.issues.completed} |")
        lines.append(f"| 进行中 | {stats.issues.processing} |")
        lines.append(f"| 待处理 | {stats.issues.todo} |")
        lines.append("")

        # 按成员统计
        if stats.issues.by_assignee:
            lines.append("### 按成员统计")
            lines.append("")
            lines.append("| 成员 | 总计 | 已完成 | 需求 | 任务 | 缺陷 |")
            lines.append("| --- | --- | --- | --- | --- | --- |")
            for name, data in sorted(
                stats.issues.by_assignee.items(),
                key=lambda x: x[1]["total"],
                reverse=True,
            ):
                lines.append(
                    f"| {name} | {data['total']} | {data['completed']} | "
                    f"{data['requirements']} | {data['missions']} | {data['defects']} |"
                )
            lines.append("")

        # 按项目统计
        if stats.issues.by_project:
            lines.append("### 按项目统计")
            lines.append("")
            lines.append("| 项目 | 总计 | 已完成 |")
            lines.append("| --- | --- | --- |")
            for name, data in sorted(
                stats.issues.by_project.items(),
                key=lambda x: x[1]["total"],
                reverse=True,
            )[:10]:
                lines.append(f"| {name} | {data['total']} | {data['completed']} |")
            lines.append("")

        # 构建统计
        if stats.builds.total > 0:
            lines.append("## 🔨 构建统计")
            lines.append("")
            lines.append("### 概览")
            lines.append("")
            lines.append("| 指标 | 数值 |")
            lines.append("| --- | --- |")
            lines.append(f"| 总构建次数 | {stats.builds.total} |")
            lines.append(f"| 成功 | {stats.builds.succeed} |")
            lines.append(f"| 失败 | {stats.builds.failed} |")
            lines.append(f"| 中止 | {stats.builds.aborted} |")
            lines.append(f"| 运行中 | {stats.builds.running} |")
            lines.append(f"| 成功率 | {stats.builds.success_rate}% |")
            lines.append(f"| 平均构建时长 | {stats.builds.avg_duration_seconds}秒 |")
            lines.append("")

            if stats.builds.by_project:
                lines.append("### 按项目统计")
                lines.append("")
                lines.append("| 项目 | 总计 | 成功 | 失败 | 成功率 |")
                lines.append("| --- | --- | --- | --- | --- |")
                for name, data in sorted(
                    stats.builds.by_project.items(),
                    key=lambda x: x[1]["total"],
                    reverse=True,
                )[:10]:
                    total = data["total"]
                    success_rate = round(data["succeed"] / total * 100, 2) if total > 0 else 0
                    lines.append(
                        f"| {name} | {total} | {data['succeed']} | {data['failed']} | {success_rate}% |"
                    )
                lines.append("")

        # 代码提交统计
        if stats.commits.total > 0:
            lines.append("## 💻 代码提交统计")
            lines.append("")
            lines.append("### 概览")
            lines.append("")
            lines.append("| 指标 | 数值 |")
            lines.append("| --- | --- |")
            lines.append(f"| 总提交次数 | {stats.commits.total} |")
            lines.append("")

            # 按日期统计
            if stats.commits.by_date:
                lines.append("### 每日提交趋势")
                lines.append("")
                lines.append("| 日期 | 提交数 |")
                lines.append("| --- | --- |")
                for date_str in sorted(stats.commits.by_date.keys()):
                    count = stats.commits.by_date[date_str]
                    lines.append(f"| {date_str} | {count} |")
                lines.append("")

            # 活跃提交者
            if stats.commits.top_authors:
                lines.append("### 活跃提交者 Top 10")
                lines.append("")
                lines.append("| 排名 | 提交者 | 提交数 |")
                lines.append("| --- | --- | --- |")
                for i, author in enumerate(stats.commits.top_authors, 1):
                    lines.append(f"| {i} | {author['name']} | {author['count']} |")
                lines.append("")

            # 按项目统计
            if stats.commits.by_project:
                lines.append("### 按项目统计")
                lines.append("")
                lines.append("| 项目 | 提交数 |")
                lines.append("| --- | --- |")
                for name, count in sorted(
                    stats.commits.by_project.items(),
                    key=lambda x: x[1],
                    reverse=True,
                )[:10]:
                    lines.append(f"| {name} | {count} |")
                lines.append("")

        # 合并请求统计
        if stats.merge_requests.total > 0:
            lines.append("## 🔀 合并请求统计")
            lines.append("")
            lines.append("### 概览")
            lines.append("")
            lines.append("| 指标 | 数值 |")
            lines.append("| --- | --- |")
            lines.append(f"| 总 MR 数 | {stats.merge_requests.total} |")
            lines.append(f"| 已合并 | {stats.merge_requests.merged} |")
            lines.append(f"| 待处理 | {stats.merge_requests.open} |")
            lines.append(f"| 已关闭 | {stats.merge_requests.closed} |")
            lines.append(f"| 合并率 | {stats.merge_requests.merge_rate}% |")
            lines.append("")

            # 按创建者统计
            if stats.merge_requests.by_creator:
                lines.append("### 按创建者统计")
                lines.append("")
                lines.append("| 创建者 | 总计 | 已合并 |")
                lines.append("| --- | --- | --- |")
                for name, data in sorted(
                    stats.merge_requests.by_creator.items(),
                    key=lambda x: x[1]["total"],
                    reverse=True,
                )[:10]:
                    lines.append(f"| {name} | {data['total']} | {data['merged']} |")
                lines.append("")

            # 按项目统计
            if stats.merge_requests.by_project:
                lines.append("### 按项目统计")
                lines.append("")
                lines.append("| 项目 | 总计 | 已合并 |")
                lines.append("| --- | --- | --- |")
                for name, data in sorted(
                    stats.merge_requests.by_project.items(),
                    key=lambda x: x[1]["total"],
                    reverse=True,
                )[:10]:
                    lines.append(f"| {name} | {data['total']} | {data['merged']} |")
                lines.append("")

        # 页脚
        lines.append("---")
        lines.append("")
        lines.append("*本报告由 Coding 周报工具自动生成*")

        return "\n".join(lines)

    def save_to_file(
        self,
        content: str,
        output_path: Path,
    ) -> None:
        """
        保存周报到文件

        Args:
            content: 周报内容
            output_path: 输出路径
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(content, encoding="utf-8")

    def generate_and_save(
        self,
        stats: WeeklyReportStats,
        output_path: Path,
    ) -> Path:
        """
        生成并保存周报

        Args:
            stats: 周报统计数据
            output_path: 输出路径

        Returns:
            保存的文件路径
        """
        content = self.generate_markdown(stats)
        self.save_to_file(content, output_path)
        return output_path

    def generate_filename(self, stats: WeeklyReportStats) -> str:
        """
        生成周报文件名

        Args:
            stats: 周报统计数据

        Returns:
            文件名
        """
        return f"weekly_report_{stats.week_start}_{stats.week_end}.md"
