---
name: tencent-coding
description: Generate weekly reports from Tencent Coding DevOps platform, including project progress, issues, builds, commits, and merge requests.
metadata:
  {
    "openclaw":
      {
        "emoji": "📊",
        "requires": {
          "bins": ["python3"],
          "env": ["CODING_TEAM_DOMAIN", "CODING_ACCESS_TOKEN"]
        }
      }
  }
---

# Tencent Coding Weekly Report

Generate comprehensive weekly reports from Tencent Coding DevOps platform, including project progress, issue tracking, CI/CD builds, code commits, and merge requests.

## Overview

This skill provides automated weekly report generation for teams using Tencent Coding DevOps platform. It collects data across projects, team members, issues, builds, commits, and merge requests to produce formatted Markdown reports.

## Quick Start

1. Set up environment variables (see Configuration section)
2. Generate a team weekly report:

```bash
python {baseDir}/scripts/coding_report.py generate
```

3. Generate a member-specific report:

```bash
python {baseDir}/scripts/coding_report.py member <member_id>
```

4. Generate a project-specific report:

```bash
python {baseDir}/scripts/coding_report.py project <project_id>
```

## Configuration

### Required Environment Variables

Create a `.env` file in the skill directory (see `.env.example`):

```bash
# Team domain prefix (e.g., your-team from your-team.coding.net)
CODING_TEAM_DOMAIN=your-team

# Access token (personal or project token)
CODING_ACCESS_TOKEN=your-access-token-here
```

### Getting Access Token

1. Log in to [Coding DevOps platform](https://coding.net)
2. Go to Personal Settings → Access Tokens
3. Create a new token with required permissions:
   - `project:profile:ro` - Read project information
   - `team:member:ro` - Read team members
   - `project:depot:ro` - Read code repositories
   - `collaboration:issue:ro` - Read issues
   - `ci:job:ro` - Read build jobs
   - `git:commit:ro` - Read commit records

## Usage

### Generate Team Weekly Report

Generate a comprehensive report for the entire team:

```bash
# Generate report for current week
python {baseDir}/scripts/coding_report.py generate

# Specify week start date (YYYY-MM-DD)
python {baseDir}/scripts/coding_report.py generate --start-date 2026-03-21

# Specify output file path
python {baseDir}/scripts/coding_report.py generate --output team_report.md

# Filter by specific projects (comma-separated IDs)
python {baseDir}/scripts/coding_report.py generate --project-ids 1,2,3

# Filter by specific members (comma-separated IDs)
python {baseDir}/scripts/coding_report.py generate --member-ids 1,2,3

# Exclude build data
python {baseDir}/scripts/coding_report.py generate --no-builds

# Exclude commit data
python {baseDir}/scripts/coding_report.py generate --no-commits

# Exclude merge request data
python {baseDir}/scripts/coding_report.py generate --no-mrs
```

### Generate Member Weekly Report

Generate a report for a specific team member:

```bash
# Generate report for member ID 123
python {baseDir}/scripts/coding_report.py member 123

# Specify date range and output file
python {baseDir}/scripts/coding_report.py member 123 --start-date 2026-03-21 --output member_report.md
```

### Generate Project Weekly Report

Generate a report for a specific project:

```bash
# Generate report for project ID 456
python {baseDir}/scripts/coding_report.py project 456

# Specify date range and output file
python {baseDir}/scripts/coding_report.py project 456 --start-date 2026-03-21 --output project_report.md
```

### Check Configuration

Verify your current configuration:

```bash
python {baseDir}/scripts/coding_report.py config
```

## Report Content

Generated weekly reports include:

### 1. Overview
- Project count and team member count
- Total issues and completion rate
- Build, commit, and merge request statistics

### 2. Issue Statistics
- Distribution by type (requirements/missions/defects)
- Distribution by status (completed/in-progress/todo)
- Statistics by assignee
- Statistics by project

### 3. Build Statistics
- Total builds and success rate
- Average build duration
- Statistics by project
- Statistics by build job

### 4. Code Commit Statistics
- Total commits
- Daily commit trends
- Top active contributors

### 5. Merge Request Statistics
- Total MR count and merge rate
- Statistics by creator
- Statistics by project

## Advanced Options

### Date Format

All date parameters use `YYYY-MM-DD` format. The week start date defaults to the current week's Monday if not specified.

### Output Format

Reports are generated in Markdown format for easy reading and compatibility with documentation platforms.

### Filtering

Use `--project-ids` and `--member-ids` to focus on specific projects or team members. Use the `--no-*` flags to exclude specific data types when not needed.

## Troubleshooting

### Common Issues

**Configuration Error: CODING_TEAM_DOMAIN not set**
- Ensure `CODING_TEAM_DOMAIN` is set in your `.env` file or environment variables

**API Error: Invalid access token**
- Verify your `CODING_ACCESS_TOKEN` is valid and has required permissions
- Check token expiration date

**No data found for specified date range**
- Confirm the date range matches when data was created
- Check that projects, members, or repositories exist

**Rate limiting errors**
- Coding API has rate limits (30 requests/second per team per endpoint)
- Large reports may take time to generate

### Debug Mode

The script provides progress messages during data collection. Check these messages to identify where issues occur.

## References

- [Coding DevOps OpenAPI Documentation](https://help.coding.net/openapi)
- [Access Token Management](https://help.coding.net/personal-settings/access-token)
- See `references/coding-api.md` for detailed API reference

## Notes

- API requests are rate-limited to 30 requests/second per team
- The tool automatically handles pagination for large datasets
- Sensitive information (access tokens) should never be committed to version control
- Reports include only data from the specified time range
- Member and project names are cached for efficient reporting
