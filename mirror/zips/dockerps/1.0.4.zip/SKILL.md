---
name: DockerPS
description: "List Docker containers with resource usage, logs, and health details. Use when checking status, viewing logs, inspecting resource usage."
version: "2.0.0"
author: "BytesAgain"
homepage: https://bytesagain.com
source: https://github.com/bytesagain/ai-skills
tags: ["docker","container","status","devops","monitor"]
categories: ["Developer Tools", "Utility"]
---

# DockerPS

A developer-focused toolkit for checking, validating, generating, formatting, linting, explaining, converting, templating, diffing, previewing, fixing, and reporting on Docker container operations — all from the command line with full history tracking.

## Commands

| Command | Description |
|---------|-------------|
| `dockerps check <input>` | Record and review check entries (run without args to see recent) |
| `dockerps validate <input>` | Record and review validation entries |
| `dockerps generate <input>` | Record and review generation entries |
| `dockerps format <input>` | Record and review formatting entries |
| `dockerps lint <input>` | Record and review lint entries |
| `dockerps explain <input>` | Record and review explanation entries |
| `dockerps convert <input>` | Record and review conversion entries |
| `dockerps template <input>` | Record and review template entries |
| `dockerps diff <input>` | Record and review diff entries |
| `dockerps preview <input>` | Record and review preview entries |
| `dockerps fix <input>` | Record and review fix entries |
| `dockerps report <input>` | Record and review report entries |
| `dockerps stats` | Show summary statistics across all log files |
| `dockerps export <fmt>` | Export all data in JSON, CSV, or TXT format |
| `dockerps search <term>` | Search across all logged entries |
| `dockerps recent` | Show the 20 most recent activity entries |
| `dockerps status` | Health check — version, data dir, entry count, disk usage |
| `dockerps help` | Show usage info and all available commands |
| `dockerps version` | Print version string |

Each data command (check, validate, generate, etc.) works in two modes:
- **With arguments:** Logs the input with a timestamp and saves to the corresponding `.log` file
- **Without arguments:** Displays the 20 most recent entries from that command's log

## Data Storage

All data is stored locally in `~/.local/share/dockerps/`. Each command writes to its own log file (e.g., `check.log`, `lint.log`, `report.log`). A unified `history.log` tracks all activity across commands with timestamps.

- Log format: `YYYY-MM-DD HH:MM|<input>`
- History format: `MM-DD HH:MM <command>: <input>`
- No external database or network access required
- Set `DOCKERPS_DIR` environment variable to change the data directory (default: `~/.local/share/dockerps/`)

## Requirements

- Bash 4+ (uses `set -euo pipefail`)
- Standard POSIX utilities: `date`, `wc`, `du`, `head`, `tail`, `grep`, `basename`, `cat`
- No root privileges needed
- No API keys or external dependencies
- Works on Linux and macOS

## When to Use

1. **Tracking container health checks** — Use `dockerps check` and `dockerps report` to log container status observations, creating a searchable history of Docker infrastructure health
2. **Validating and linting Dockerfiles** — Use `dockerps validate` and `dockerps lint` to record Dockerfile review findings, best practice violations, or security scan results
3. **Generating and templating Docker configs** — Use `dockerps generate` and `dockerps template` to log compose file generation notes, template customizations, and configuration decisions
4. **Diffing and comparing container states** — Use `dockerps diff` and `dockerps convert` to track changes between container versions, image layers, or configuration migrations
5. **Building exportable audit trails** — Use `dockerps export json` to produce a structured file of all logged Docker activity for compliance, incident review, or team handoff

## Examples

### Log a container check and review history

```bash
# Record a check
dockerps check "nginx:latest — healthy, 3 replicas running, 12MB memory each"

# View recent check entries
dockerps check
```

### Validate and lint workflow

```bash
# Log a validation finding
dockerps validate "docker-compose.yml: all services have healthchecks defined"

# Log a lint result
dockerps lint "Dockerfile: using latest tag — pin to specific version"

# Log an explanation
dockerps explain "Multi-stage build reduces final image from 1.2GB to 180MB"

# Search across all entries
dockerps search "nginx"
```

### Generate, template, and format

```bash
# Log a generation action
dockerps generate "Created docker-compose.yml for microservices stack: api, worker, redis"

# Log a template usage
dockerps template "Applied production template: resource limits, logging driver, restart policy"

# Log a format action
dockerps format "Reformatted compose file: sorted services alphabetically"
```

### Export and statistics

```bash
# Summary stats across all log files
dockerps stats

# Export everything as JSON
dockerps export json

# Export as CSV for spreadsheet import
dockerps export csv

# Health check
dockerps status

# Recent activity
dockerps recent
```

### Diff, fix, and report

```bash
# Log a diff observation
dockerps diff "staging vs prod: staging missing resource limits on worker service"

# Log a fix
dockerps fix "Added memory limit 512MB to worker container in production compose"

# Log a preview
dockerps preview "Dry-run deploy: 2 services updated, 1 new, 0 removed"

# Generate a report
dockerps report "Weekly Docker audit: 12 containers, 3 need image updates, all healthy"
```

## How It Works

DockerPS uses a simple case-dispatch architecture in a single Bash script. Each command maps to a log file under `~/.local/share/dockerps/`. When called with arguments, the input is appended with a timestamp. When called without arguments, the last 20 lines of that log are displayed. The `stats` command aggregates counts across all logs, `export` serializes everything into your chosen format, and `search` greps across all log files for a given term.

## Support

- Website: [bytesagain.com](https://bytesagain.com)
- Feedback: [bytesagain.com/feedback](https://bytesagain.com/feedback)
- Email: hello@bytesagain.com

---

*Powered by BytesAgain | bytesagain.com | hello@bytesagain.com*
