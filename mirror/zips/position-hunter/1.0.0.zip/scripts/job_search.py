#!/usr/bin/env python3
"""
Position Hunter - 求职职位搜索辅助脚本
用于解析和标准化招聘平台数据
"""

import json
import re
from datetime import datetime
from typing import List, Dict, Optional
from dataclasses import dataclass, asdict


@dataclass
class JobPosition:
    """岗位信息数据结构"""
    title: str                    # 岗位名称
    company: str                  # 招聘企业
    city: str                     # 工作城市
    salary_range: str             # 薪资范围
    publish_date: str             # 发布日期
    job_description: str          # 岗位职责
    requirements: str             # 任职要求
    link: str                     # 直达链接
    source: str                   # 来源平台
    priority: int = 3             # 优先级 1-5
    
    def to_dict(self) -> Dict:
        return asdict(self)


@dataclass
class JobPreference:
    """用户求职意向数据结构"""
    keywords: List[str]           # 岗位关键词
    industry: Optional[str]       # 所属行业
    city: Optional[str]           # 工作城市
    salary_min: Optional[int]     # 最低薪资
    salary_max: Optional[int]     # 最高薪资
    level: Optional[str]          # 职级要求
    job_type: str = "全职"         # 工作性质
    target_companies: List[str] = None  # 意向企业清单
    
    def __post_init__(self):
        if self.target_companies is None:
            self.target_companies = []


class JobSearchHelper:
    """职位搜索辅助工具"""
    
    # 主流招聘平台列表
    PLATFORMS = {
        "boss": {"name": "BOSS直聘", "url": "https://www.zhipin.com"},
        "liepin": {"name": "猎聘", "url": "https://www.liepin.com"},
        "zhaopin": {"name": "智联招聘", "url": "https://www.zhaopin.com"},
        "job51": {"name": "前程无忧", "url": "https://www.51job.com"},
        "lagou": {"name": "拉勾网", "url": "https://www.lagou.com"},
        "shixiseng": {"name": "实习僧", "url": "https://www.shixiseng.com"},
    }
    
    @staticmethod
    def parse_salary(salary_text: str) -> Dict[str, Optional[int]]:
        """
        解析薪资文本，提取薪资范围
        
        Args:
            salary_text: 薪资文本，如 "20-30K", "年薪30-50万"
            
        Returns:
            {"min": 最低薪资, "max": 最高薪资, "unit": "K/月"或"万/年"}
        """
        result = {"min": None, "max": None, "unit": None}
        
        if not salary_text:
            return result
            
        # 匹配 "20-30K" 或 "20K-30K" 格式
        k_pattern = r'(\d+)[Kk]?\s*[-~]\s*(\d+)[Kk]'
        k_match = re.search(k_pattern, salary_text)
        if k_match:
            result["min"] = int(k_match.group(1))
            result["max"] = int(k_match.group(2))
            result["unit"] = "K/月"
            return result
            
        # 匹配 "年薪30-50万" 格式
        year_pattern = r'年薪?\s*(\d+)[-\s]*(\d+)\s*万'
        year_match = re.search(year_pattern, salary_text)
        if year_match:
            result["min"] = int(year_match.group(1))
            result["max"] = int(year_match.group(2))
            result["unit"] = "万/年"
            return result
            
        # 匹配单个数字+K
        single_k_pattern = r'(\d+)[Kk]'
        single_k_match = re.search(single_k_pattern, salary_text)
        if single_k_match:
            result["min"] = int(single_k_match.group(1))
            result["max"] = int(single_k_match.group(1))
            result["unit"] = "K/月"
            return result
            
        return result
    
    @staticmethod
    def calculate_priority(
        job: JobPosition, 
        preference: JobPreference
    ) -> int:
        """
        计算岗位投递优先级
        
        Args:
            job: 岗位信息
            preference: 用户求职意向
            
        Returns:
            优先级评分 1-5
        """
        score = 0
        
        # 意向企业匹配 +2
        if preference.target_companies:
            for company in preference.target_companies:
                if company.lower() in job.company.lower():
                    score += 2
                    break
        
        # 关键词匹配 +1
        if preference.keywords:
            for keyword in preference.keywords:
                if keyword.lower() in job.title.lower():
                    score += 1
                    break
        
        # 城市匹配 +1
        if preference.city and preference.city in job.city:
            score += 1
            
        # 薪资匹配 +1
        salary_info = JobSearchHelper.parse_salary(job.salary_range)
        if salary_info["min"] and preference.salary_min:
            if salary_info["min"] >= preference.salary_min:
                score += 1
        
        # 发布日期 freshness (3天内+1)
        try:
            if "天" in job.publish_date:
                days = int(re.search(r'(\d+)', job.publish_date).group(1))
                if days <= 3:
                    score += 1
        except:
            pass
            
        return min(max(score, 1), 5)
    
    @staticmethod
    def format_job_list(jobs: List[JobPosition]) -> str:
        """
        格式化岗位列表为Markdown表格
        
        Args:
            jobs: 岗位列表
            
        Returns:
            Markdown格式表格
        """
        if not jobs:
            return "暂无匹配的岗位信息"
            
        # 按优先级排序
        sorted_jobs = sorted(jobs, key=lambda x: x.priority, reverse=True)
        
        # 生成表格
        lines = [
            "| 岗位名称 | 招聘企业 | 城市 | 薪资 | 发布 | 优先级 | 链接 |",
            "|---------|---------|------|------|------|--------|------|"
        ]
        
        for job in sorted_jobs:
            stars = "⭐" * job.priority
            link = f"[查看]({job.link})" if job.link else "-"
            lines.append(
                f"| {job.title} | {job.company} | {job.city} | {job.salary_range} | {job.publish_date} | {stars} | {link} |"
            )
            
        return "\n".join(lines)
    
    @staticmethod
    def generate_search_urls(preference: JobPreference) -> Dict[str, str]:
        """
        生成各平台的搜索链接
        
        Args:
            preference: 用户求职意向
            
        Returns:
            平台名称 -> 搜索链接 的映射
        """
        urls = {}
        keyword = " ".join(preference.keywords) if preference.keywords else ""
        city = preference.city or ""
        
        # BOSS直聘
        urls["BOSS直聘"] = f"https://www.zhipin.com/web/geek/job?query={keyword}&city={city}"
        
        # 猎聘
        urls["猎聘"] = f"https://www.liepin.com/zhaopin/?key={keyword}&dqs={city}"
        
        # 智联招聘
        urls["智联招聘"] = f"https://sou.zhaopin.com/?jl={city}&kw={keyword}"
        
        # 前程无忧
        urls["前程无忧"] = f"https://search.51job.com/?keyword={keyword}&jobarea={city}"
        
        # 拉勾网
        urls["拉勾网"] = f"https://www.lagou.com/wn/jobs?kd={keyword}&city={city}"
        
        return urls


class ResumeAnalyzer:
    """简历分析工具"""
    
    # 常见技能关键词库
    SKILL_KEYWORDS = {
        "技术": ["Java", "Python", "JavaScript", "React", "Vue", "Node.js", "Go", "C++", "SQL", "Linux"],
        "产品": ["需求分析", "用户研究", "原型设计", "Axure", "Figma", "数据分析", "项目管理"],
        "设计": ["UI设计", "UX设计", "Photoshop", "Sketch", "Illustrator", "视觉设计"],
        "运营": ["内容运营", "用户运营", "活动策划", "数据分析", "社群运营", "增长黑客"],
    }
    
    @staticmethod
    def extract_skills(resume_text: str) -> List[str]:
        """
        从简历文本中提取技能关键词
        
        Args:
            resume_text: 简历文本内容
            
        Returns:
            技能关键词列表
        """
        found_skills = []
        text_lower = resume_text.lower()
        
        for category, skills in ResumeAnalyzer.SKILL_KEYWORDS.items():
            for skill in skills:
                if skill.lower() in text_lower:
                    found_skills.append(skill)
                    
        return list(set(found_skills))
    
    @staticmethod
    def analyze_jd_match(
        resume_skills: List[str], 
        jd_requirements: str
    ) -> Dict:
        """
        分析简历与JD的匹配度
        
        Args:
            resume_skills: 简历中的技能列表
            jd_requirements: JD任职要求文本
            
        Returns:
            匹配分析结果
        """
        jd_lower = jd_requirements.lower()
        
        matched = []
        missing = []
        
        for skill in resume_skills:
            if skill.lower() in jd_lower:
                matched.append(skill)
            else:
                missing.append(skill)
        
        # 提取JD中的关键要求
        jd_keywords = []
        for category, skills in ResumeAnalyzer.SKILL_KEYWORDS.items():
            for skill in skills:
                if skill.lower() in jd_lower and skill not in matched:
                    jd_keywords.append(skill)
        
        match_rate = len(matched) / (len(matched) + len(jd_keywords)) * 100 if (len(matched) + len(jd_keywords)) > 0 else 0
        
        return {
            "match_rate": round(match_rate, 1),
            "matched_skills": matched,
            "missing_skills_from_resume": missing,
            "required_skills_in_jd": jd_keywords,
            "suggestions": ResumeAnalyzer._generate_suggestions(matched, jd_keywords)
        }
    
    @staticmethod
    def _generate_suggestions(matched: List[str], required: List[str]) -> List[str]:
        """生成优化建议"""
        suggestions = []
        
        if len(matched) < 3:
            suggestions.append("建议补充更多技能关键词，突出核心竞争力")
            
        if required:
            suggestions.append(f"JD中提到的关键技能：{', '.join(required[:5])}，建议在简历中突出相关经验")
            
        suggestions.append("建议使用数据量化项目成果，如'提升XX%'、'覆盖XX用户'")
        suggestions.append("将最相关的技能和经验放在简历前半部分，提高ATS系统匹配度")
        
        return suggestions


def main():
    """示例用法"""
    # 创建求职意向
    preference = JobPreference(
        keywords=["产品经理", "PM"],
        city="北京",
        salary_min=25,
        salary_max=40,
        target_companies=["字节跳动", "美团"]
    )
    
    # 生成搜索链接
    helper = JobSearchHelper()
    urls = helper.generate_search_urls(preference)
    print("各平台搜索链接：")
    for platform, url in urls.items():
        print(f"  {platform}: {url}")
    
    # 示例岗位
    job = JobPosition(
        title="高级产品经理",
        company="字节跳动",
        city="北京",
        salary_range="30-50K",
        publish_date="2天前",
        job_description="负责产品规划...",
        requirements="3年以上经验...",
        link="https://example.com/job/1",
        source="BOSS直聘"
    )
    
    # 计算优先级
    priority = helper.calculate_priority(job, preference)
    print(f"\n岗位优先级: {'⭐' * priority}")


if __name__ == "__main__":
    main()
