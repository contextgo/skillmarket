---
name: dev-flow
description: One-stop code change workflow. TRIGGER when: user says "add feature", "modify code", "implement XXX", "fix bug", "beautify UI". Flow: Questioning Agent → Coding → Check Agent → Testing → Acceptance. Browser testing with agent-browser (fallback to manual if unavailable).
argument-hint: [requirement description]
allowed-tools: Read Grep Glob Edit Write Bash(mvn *) Bash(npm *) Bash(git *) AskUserQuestion Agent Skill
---

# dev-flow - One-stop Code Change Workflow

---

## Core Design: Sub Agent Processing to Avoid Self-Bias

**Use independent sub Agents for critical phases. Main Agent ONLY handles coding and coordination.**

| Agent | Responsibility | Lifecycle |
| :--- | :--- | :--- |
| Questioning Agent | Requirement confirmation, questioning requirements, identifying gaps | Requirement confirmation start → Requirement confirmation end |
| Check Agent | Code review, checking modified files + affected files | Start BEFORE coding → Release when outputting results |

---

## Mandatory Requirements

| Requirement | Description |
| :--- | :--- |
| **MUST NOT pause midway** | After user confirmation, MUST execute all steps continuously |
| **MUST test if agent-browser available** | Browser testing phase MUST be executed when agent-browser skill is available |
| **MUST fallback if agent-browser unavailable** | Output fallback notice + manual test instructions, AskUserQuestion for user confirmation |
| **MUST cover all modifications** | Each modification MUST have corresponding test case, 100% coverage |
| **MUST output test report** | MUST show test cases and results to user before proceeding |
| **Check Agent MUST start BEFORE coding** | Start before coding, NOT after |
| **ROLLBACK MUST reuse Agent** | After rollback, MUST use SendMessage to reuse Check Agent, MUST NOT create new one |
| **No gaps MUST ask for supplement** | When Questioning Agent finds no gaps, MUST call AskUserQuestion to ask user for supplement |

---

## Phase 1: Requirement Confirmation

### Flow

```
Step 1: Start Questioning Agent
    ↓
Step 2: Get user requirements → Summarize requirements
    ↓
Step 3: Loop
    ↓
SendMessage(Questioning Agent) → Find gaps
    ↓
┌───────────────────────────────────────────────┐
│ Questioning Agent Result?                     │
│                                               │
│   Has gaps:                                   │
│     1. Output brief explanation (found N issues)│
│     2. AskUserQuestion                        │
│     3. Receive answer → Summarize → SendMessage → Loop│
│                                               │
│   No gaps:                                    │
│     1. Output "Questioning Agent found no new gaps"│
│     2. AskUserQuestion(supplement?)           │
│     3. Has supplement → Merge summary → Go to Step 2│
│     4. No supplement → End loop               │
│                                               │
│   User halt → End loop                        │
└───────────────────────────────────────────────┘
    ↓
Release Questioning Agent
```

**[MANDATORY]After receiving Agent result, MUST output brief explanation first, then call AskUserQuestion. Order: Output explanation → AskUserQuestion.**

**[MANDATORY]After receiving AskUserQuestion answers, MUST SendMessage to let Questioning Agent continue finding gaps. MUST NOT skip directly to asking for supplement.**

See: [reference/requirement.md](reference/requirement.md)

---

## Phase 2: Coding

### Flow

```
Start Check Agent (BEFORE coding!)
    ↓
Main Agent performs coding
```

**[MANDATORY]Check Agent MUST start BEFORE coding begins.**

---

## Phase 3: Check (Code + Test Plan Validation)

**Check Agent MUST validate two things: (1) code correctness, (2) test plan completeness**

### Flow

```
SendMessage(Check Agent) → Check code + Validate test plan
    ↓
┌─────────────────────────────────────────────────────────────┐
│ Check Result?                                               │
│   ├─ Code issues → ⏪ ROLLBACK to coding (fix code)         │
│   ├─ Test plan incomplete → ⏪ ROLLBACK to coding (add tests)│
│   └─ Both passed → Enter browser testing                    │
└─────────────────────────────────────────────────────────────┘
```

**Validation rules:**

Check Agent evaluates whether the test plan (from Phase 4) adequately covers all modifications. Use reasonable judgment:
- A simple typo fix may need only one test
- A new function needs success + failure paths
- A UI change needs interaction + edge cases
- A backend API needs validation + error handling

Check Agent output should include:
- Test coverage assessment (sufficient / needs improvement)
- Specific missing test cases (if any)
- Recommendation (proceed / add tests / rethink design)

If test plan is incomplete, Check Agent MUST explain what's missing and why.

**[MANDATORY]SendMessage MUST include the list of modified files.**

See: [reference/validation.md](reference/validation.md)

---

## Phase 4: Browser Testing

**[MANDATORY]Before starting Phase 4, confirm Check Agent has validated the test plan and result is PASS. If Check Agent returned warnings (missing exception paths), document them in test report but may proceed.**

### Flow

```
Confirm Check Agent validation passed
    ↓
┌─────────────────────────────────────────────────────┐
│ Check agent-browser skill availability              │
│   ├─ Available → Proceed to browser testing         │
│   └─ Not available → Fallback: skip testing         │
└─────────────────────────────────────────────────────┘
    ↓
┌─────────────────────────────────────────────────────┐
│ Testing Mode?                                        │
│                                                       │
│   Browser testing available:                         │
│     Main Agent identifies test coverage              │
│     ↓                                                │
│     Create test cases → Execute with agent-browser   │
│     ↓                                                │
│     Output test report → Pass/Fail decision          │
│                                                       │
│   Fallback (agent-browser unavailable):              │
│     Output fallback notice to user                   │
│     ↓                                                │
│     Provide manual test instructions                 │
│     ↓                                                │
│     AskUserQuestion: user confirms manual test       │
│     ↓                                                │
│     Enter output results                             │
└─────────────────────────────────────────────────────┘
```

**[MANDATORY]If agent-browser available: MUST NOT skip testing.**

**[MANDATORY]If agent-browser unavailable: MUST output fallback notice + manual test instructions, then AskUserQuestion for user confirmation.**

**[MANDATORY]Test coverage: Each modification MUST have corresponding test case.**

**[MANDATORY]Output test report: MUST show test cases and results to user.**

See: [reference/validation.md](reference/validation.md) for test commands, browser testing guide, and fallback procedure

---

## Phase 5: Output Results

```
Release Check Agent
    ↓
Output task complete
```

---

## Rollback Mechanism

```
Check/Test fail → ⏪ ROLLBACK to coding → SendMessage(Check Agent_ID) → Re-execute check→test
```

See: [reference/validation.md](reference/validation.md) for rollback declaration format

---

## User Commands

| Command | Effect |
| :--- | :--- |
| /abort | Abort task |
| 够了/确认/开始/OK | Stop questioning, start coding |

---

## Agent Invocation Rules

| Rule | Description |
| :--- | :--- |
| Before calling Agent | MUST NOT output text, call directly |
| After calling Agent | Wait for result directly, MUST NOT output "waiting" text |
| After receiving Agent result | Output brief explanation first, then call AskUserQuestion |
| After receiving AskUserQuestion answers | MUST SendMessage to let Agent continue, MUST NOT skip |
| If AskUserQuestion returns duplicate answers | Use only the first answer, ignore duplicates |
| SendMessage | MUST include list of modified files |
| Agent release | Release after entire workflow completes |

See: [reference/agent-templates.md](reference/agent-templates.md)

---

## Resource Navigation

- **Requirement Confirmation Rules**: [reference/requirement.md](reference/requirement.md)
- **Check→Test Rules**: [reference/validation.md](reference/validation.md)
- **Agent Templates**: [reference/agent-templates.md](reference/agent-templates.md)

---

$ARGUMENTS