# Requirement Confirmation Phase - Questioning Agent Rules

---

## Core Principle

**Questioning Agent is responsible for questioning requirements and identifying gaps. Main Agent ONLY handles summarizing and AskUserQuestion.**

**[MANDATORY]When Questioning Agent finds no gaps, MUST call AskUserQuestion to ask user for supplement. MUST NOT end loop directly.**

---

## 3-Step Loop Detail

```
Step 1: Start Questioning Agent
    ↓
Step 2: Get user requirements → Summarize requirements
    ↓
Step 3: Loop
    SendMessage(Questioning Agent) → Find gaps
        ↓
    Has gaps → Output brief explanation → AskUserQuestion → Summarize → SendMessage → Continue loop
    No gaps → Output "No new gaps" → AskUserQuestion(supplement?)
        Has supplement → Merge summary → Go to Step 2
        No supplement → End loop
    User halt → End loop
```

**[MANDATORY]Output and call order**:
```
Receive Questioning Agent result → Output brief explanation first → Then call AskUserQuestion → Receive answer → SendMessage
```

**Correct Example**:
```
● Questioning Agent found N issues, need confirmation:
[Output issue explanation]

● User answered Claude's questions:
[Wait for user answer]
```

**Wrong Example** (DO NOT do this):
```
● User answered Claude's questions:
[User already answered]

● Questioning Agent found N issues... ← Explanation after answer, confusing!
```

**[MANDATORY] After receiving AskUserQuestion answers, the ONLY allowed next action is SendMessage to the existing Questioning Agent with its Agent_ID. MUST NOT create a new Questioning Agent. MUST NOT call AskUserQuestion again. If SendMessage fails, retry SendMessage with corrected parameters, do not create new Agent. If SendMessage fails with error "required parameter `prompt` is missing", retry SendMessage with the correct format:**

```json
{
  "to": "[same Agent_ID]",
  "prompt": "[the message content]"
}
```

**MUST NOT create a new Agent. MUST NOT call AskUserQuestion again.**

**If AskUserQuestion renders as plain text without clickable options, user's text reply containing choices is STILL valid. Parse the reply for selections and proceed normally. DO NOT re-ask the same questions.**

---

**[MANDATORY] AskUserQuestion Format Per Round**:

When Questioning Agent returns N issues, Main Agent MUST call AskUserQuestion ONCE with N question objects in the questions array.

Each question object MUST have:
- question: "Issue X/N: [issue description]"
- header: short topic label
- options: at least 2 options specific to that issue
- multiSelect: true or false, determined by the nature of the issue

Correct format:
```json
{
  "questions": [
    {
      "question": "Issue 1/N: [issue description]",
      "header": "[topic]",
      "options": [
        {"label": "Option A", "description": "description of option A"},
        {"label": "Option B", "description": "description of option B"}
      ],
      "multiSelect": false
    },
    {
      "question": "Issue 2/N: [issue description]",
      "header": "[topic]",
      "options": [
        {"label": "Option A", "description": "description of option A"},
        {"label": "Option B", "description": "description of option B"}
      ],
      "multiSelect": true
    }
  ]
}
```

MUST NOT use a single question that batches all issues:
```json
{
  "questions": [
    {
      "question": "How to handle all N issues?",
      "options": [
        {"label": "Fix all", "description": "..."},
        {"label": "Ignore all", "description": "..."}
      ]
    }
  ]
}
```

**[MANDATORY] After receiving AskUserQuestion answers, the NEXT action MUST be SendMessage to Questioning Agent. MUST NOT call AskUserQuestion again with the same or similar questions. One AskUserQuestion per round. If answers are received, move forward. If answers are empty, re-ask with same question ONCE, then move forward.**

---

## Loop End Conditions

| Condition | Action |
| :--- | :--- |
| User halt (够了/确认/开始/OK) | End loop → Release Questioning Agent → Coding |
| Questioning Agent no gaps + User no supplement | End loop → Release Questioning Agent → Coding |
| Questioning Agent has gaps | AskUserQuestion → Summarize → Continue loop |
| Questioning Agent no gaps + User has supplement | Merge summary → Go to Step 2 |

---

## User Halt Keywords

| Keyword | Effect |
| :--- | :--- |
| 够了 | Stop questioning, end loop |
| 确认 | Stop questioning, end loop |
| 开始 | Stop questioning, end loop |
| OK | Stop questioning, end loop |
| /abort | Abort task |

---

## Main Agent MUST NOT Behaviors

| MUST NOT | Correct |
| :--- | :--- |
| Output text before calling Agent | Call directly, no text |
| Output "waiting for result" after calling Agent | Wait directly, process result immediately |
| Call AskUserQuestion directly after receiving Agent result | Output brief explanation first, then call AskUserQuestion |
| Judge whether requirements have gaps yourself | Let Questioning Agent judge, ONLY handle summarizing |
| End directly when Questioning Agent finds no gaps | MUST call AskUserQuestion to ask user for supplement |
| Skip SendMessage and ask for supplement after receiving answer | MUST first SendMessage to let Questioning Agent continue finding gaps |

---

## Requirement Summary Format

**Use when summarizing requirements:**

```
需求摘要：
- 目标: [一句话描述]
- 改动范围: [预估涉及的文件/模块]
- 关键点:
  - [第1轮确认的内容]
  - [第2轮确认的内容]（如有）
```

---

## Common Gaps Checklist

| Type | Gaps |
| :--- | :--- |
| Feature addition | Permissions, validation, concurrency, transactions, exception handling |
| API endpoint | Parameter validation, error handling, response format, idempotency |
| UI interface | Loading/empty/error states, responsive, interaction feedback |
| Data collection | Failure handling, format compatibility, performance, storage |
| Backend service | Logging, monitoring, config, health check, degradation |

---

## Agent Templates

See: [agent-templates.md](agent-templates.md) Questioning Agent section