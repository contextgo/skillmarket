# Check → Browser Test → Acceptance Phase - Check Agent Rules

---

## Core Principle

**Check Agent participates throughout entire phase. Any phase failure triggers ROLLBACK to coding and reuse via SendMessage.**

---

## Flow Diagram

```
Coding → SendMessage(Check Agent) → Check result (code + test plan)
    ↓
┌─────────────────────────────────────────────────────────────┐
│ Check Result?                                               │
│   ├─ Code issues → Output rollback → ROLLBACK to coding    │
│   ├─ Test plan incomplete → Output rollback → ROLLBACK to coding│
│   └─ Both passed → Enter testing phase                      │
│                ↓                                            │
│          SendMessage(Agent_ID) → Re-check                   │
└─────────────────────────────────────────────────────────────┘
    ↓
┌─────────────────────────────────────────────────────┐
│ Check agent-browser skill availability              │
│   ├─ Available → Proceed to browser testing         │
│   └─ Not available → Enter fallback procedure       │
└─────────────────────────────────────────────────────┘
    ↓
┌─────────────────────────────────────────────────────┐
│ Browser testing available?                          │
│   ├─ Yes: Need credentials?                         │
│   │     ├─ Yes → AskUserQuestion → Get credentials  │
│   │     └─ No → Execute tests                       │
│   │   ↓                                             │
│   │   Output test report → Pass/Fail decision       │
│   │                                                 │
│   └─ No (Fallback):                                 │
│       Output fallback notice                        │
│       ↓                                             │
│       Provide manual test instructions              │
│       ↓                                             │
│       AskUserQuestion → User confirms               │
│       ↓                                             │
│       Enter output results                          │
└─────────────────────────────────────────────────────┘
```

---

## Check Agent Invocation

### Input Scope

| File Type | Description |
| :--- | :--- |
| Modified files | Files edited/written by Main Agent this time |
| Affected files | Files that depend on modified files |

**Find affected files**:
```bash
# Java
grep -r "UserService" --include="*.java" | grep -v "UserService.java"

# JavaScript/Vue
grep -r "api" --include="*.vue" --include="*.js" | grep -v "api.js"

# Python
grep -r "user_service" --include="*.py" | grep -v "user_service.py"
```

### Check Items (MANDATORY)

1. Requirement compliance: Complete functionality, complete parameters, correct logic
2. Code syntax: Syntax/type/import/undefined errors
3. Security check: SQL injection, XSS, command injection, hardcoded sensitive info
4. Code standards: Naming, style, consistency
5. Affected impact: Call compatibility, interface matching
6. Test plan validation (NEW):
   - Does the test plan cover all modifications?
   - Are success paths tested?
   - Are critical error paths considered?
   - Is the test plan realistic and executable?

   Use judgment: small changes need less testing, complex changes need more. When uncertain, ask for clarification.

**Example - Check Agent validating test plan:**

Scenario: Main Agent modified a login form (added email format validation) and a user list (added search filter).

Modified files:
- src/Login.vue: added validateEmail() function, called before form submit
- src/UserList.vue: added searchInput field, filterUsers() method, debounce logic

Test plan provided by Main Agent:
- TC1: Enter valid email, submit, verify login success
- TC2: Enter search keyword, click search, verify results filter

Check Agent evaluation:
- TC1 covers success path for email validation: yes
- Missing: invalid email format test (should show error message)
- TC2 covers search success path: yes
- Missing: empty search result, debounce behavior test

Check Agent output: "Test plan incomplete. Missing tests: 1. Login.vue email validation - missing error path (invalid email format) 2. UserList.vue search - missing edge cases (empty results, debounce timing). Recommendation: Add these test cases before browser testing."

---

## SendMessage Reuse

**MUST include modified files list:**

```json
{
  "to": "[Agent_ID]",
  "prompt": "Fix content:\n[Fix description]\n\n[IMPORTANT]Please re-read the following files:\nModified files:\n[File list]\n\nPlease re-check."
}
```

---

## Rollback Declaration Format

### Check Failed

```
⏪ ROLLBACK: Check phase found issues, return to coding phase for fix

Found [N] issues:
1. [File path] Line [L] - [Issue description]
2. [File path] Line [L] - [Issue description]

After fix execute: SendMessage(Check Agent_ID) → Check→Test
```

### Test Plan Incomplete

```
⏪ ROLLBACK: Test plan incomplete, return to coding phase to add missing tests

Missing test coverage:
1. [File path] - [Modification] - Missing [success/error path] test

After adding tests, execute: SendMessage(Check Agent_ID) → Re-validate → Test
```

### Test Failed

```
⏪ ROLLBACK: Test phase failed, return to coding phase for fix

Test failure reason:
- [Test name]: [Error message]

After fix execute: SendMessage(Check Agent_ID) → Check→Test
```

---

## Browser Testing (MANDATORY Execution)

### Skill Availability Check

Before browser testing, check if agent-browser skill is available:

```
Check skill availability (via system-reminder skills list)
    ↓
┌─────────────────────────────────────────────────────┐
│ agent-browser skill found?                          │
│   ├─ Yes → Proceed to browser testing               │
│   └─ No → Enter fallback procedure                  │
└─────────────────────────────────────────────────────┘
```

**How to check**: System reminder message lists available skills. Look for "agent-browser" in the list.

### Fallback Procedure (agent-browser Unavailable)

When agent-browser skill is not available, use fallback procedure:

**Step 1: Output fallback notice**
```
⚠️ FALLBACK: agent-browser skill not available, skipping automated browser testing

Reason: agent-browser skill not found in available skills list
Proceeding with: Manual test instructions + User confirmation
```

**Step 2: Provide manual test instructions**

List test cases that would have been executed, formatted for manual testing:

```
=== Manual Test Instructions ===

Since automated testing is unavailable, please manually verify the following:

| # | Test Case | Instructions | Expected Result |
|---|-----------|--------------|-----------------|
| 1 | Login form | 1. Navigate to /login 2. Enter test@test.com / test123 3. Click Submit | Redirect to dashboard |
| 2 | Email validation | 1. Navigate to /login 2. Enter "invalid-email" 3. Click Submit | Show error message |
| 3 | Search filter | 1. Navigate to /users 2. Enter "keyword" in search 3. Click Search | Results filter by keyword |

Please test each case manually in your browser.
```

**Step 3: AskUserQuestion for user confirmation**

```json
{
  "questions": [
    {
      "header": "Manual Test",
      "multiSelect": false,
      "options": [
        {"description": "I have tested and all cases passed", "label": "All passed"},
        {"description": "Some tests failed, will provide details", "label": "Some failed"},
        {"description": "Skip testing for now (not recommended)", "label": "Skip testing"}
      ],
      "question": "Please confirm manual test results:"
    }
  ]
}
```

**Step 4: Handle user response**

| User Response | Action |
| :--- | :--- |
| All passed → Enter output results |
| Some failed → Output rollback → ⏪ ROLLBACK to coding |
| Skip testing → Enter output results (with warning) |

### Credential Acquisition Flow

```
Check browser testing requirements
    ↓
┌─────────────────────────────────────────────────────┐
│ Function testing requires login?                    │
│   ├─ Yes → AskUserQuestion → Get username/password  │
│   └─ No → Proceed to Skill tool                     │
└─────────────────────────────────────────────────────┘
```

**AskUserQuestion format for credentials:**
```json
{
  "questions": [
    {
      "header": "Test Account",
      "multiSelect": false,
      "options": [
        {"description": "Use test account documented in project docs", "label": "Use default test account"},
        {"description": "Will provide credentials later", "label": "I will provide"}
      ],
      "question": "Browser testing requires login credentials. Please select:"
    }
  ]
}
```

### Browser Testing with agent-browser

**Step 1: Determine testing scope**
- List all modified functions/features
- Identify test paths (URLs, pages, buttons)

**Step 2: Invoke agent-browser skill via Skill tool**

Skill tool 会加载 agent-browser 的 SKILL.md，然后执行浏览器测试：

```json
{
  "skill": "agent-browser",
  "args": "[testing description]"
}
```

agent-browser skill 内部流程：
1. 加载 SKILL.md
2. 执行 `agent-browser skills get core` 获取完整工作流程
3. 使用 Bash tool 执行 agent-browser CLI 命令进行测试

**args 内容示例（根据实际测试需求编写）：**
```
Open http://localhost:8080/login, fill username "test@example.com" and password "test123", click login button, verify redirect to dashboard.

Navigate to http://localhost:8080/form, fill name field with "Test", click submit button, verify success message appears.

Open http://localhost:8080/search, enter query "keyword", click search button, verify results appear.
```

**Step 3: Verify test results**

**[MANDATORY]Output test cases and results to user before proceeding:**

```
=== Browser Test Report ===

Modified functions: [N] items
1. [Function name] - [File path]
2. [Function name] - [File path]
...

Test cases: [N] items
| # | Test Case | Description | Result |
|---|-----------|-------------|--------|
| 1 | [Name]    | [What to test] | ✓ PASS |
| 2 | [Name]    | [What to test] | ✗ FAIL: [Error] |
...

Summary: [N] passed, [N] failed
```

| Result | Action |
| :--- | :--- |
| All pass → Show report to user → Enter output results |
| Any fail → Show report to user → ⏪ ROLLBACK to coding |

### Test Coverage Checklist

**[MANDATORY]Must create test case for EACH modified function:**

| Test Type | Description | Example Test Case |
| :--- | :--- | :--- |
| Form submission | Fill required fields → Submit → Verify response | "Test user creation form: fill name, email, click Create, verify success message" |
| Button click | Click → Verify expected action | "Test Delete button: click Delete, verify item removed from list" |
| Navigation | Navigate to page → Verify content loads | "Test Settings page: navigate to /settings, verify page content displays" |
| Search/Filter | Enter criteria → Verify results | "Test search: enter 'keyword', verify results contain keyword" |
| CRUD operations | Create → Read → Update → Delete | "Test CRUD: create item, view in list, edit name, delete, verify removed" |
| Error handling | Trigger error → Verify error message | "Test validation: submit empty form, verify error messages appear" |
| Loading state | Trigger async action → Verify loading indicator | "Test loading: click Refresh, verify spinner appears then disappears" |

**Test Case Naming Convention:**
```
[Function name]_[Action]_[Expected result]
Example: UserForm_Submit_Success, SearchButton_Click_ResultsDisplay
```

---

## Compilation Testing (Optional - Non-UI Projects)

For non-UI projects (CLI tools, backend APIs, libraries), use traditional compilation testing:

| Project Type | Command |
| :--- | :--- |
| Maven Java | `mvn test` |
| npm Node.js | `npm test` |
| pytest Python | `pytest` |
| Go | `go test ./...` |

**MUST NOT skip testing.**

---

## Check Agent Lifecycle

| Timing | Action |
| :--- | :--- |
| Before coding | Start Check Agent |
| When outputting results | Release Check Agent |

**Any phase failure, DO NOT release Agent, use SendMessage to reuse.**

---

## Main Agent MUST NOT Behaviors

| MUST NOT | Correct |
| :--- | :--- |
| Output text before calling Agent | Call directly, no text |
| Output "waiting for result" after calling Agent | Wait directly, process result immediately |
| Judge whether code has issues yourself | Let Check Agent judge, ONLY handle fixing |
| Release Agent after failure | Keep Agent, use SendMessage to reuse |

---

## Agent Templates

See: [agent-templates.md](agent-templates.md) Check Agent section