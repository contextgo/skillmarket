# Agent Prompt Templates

---

## Questioning Agent Templates

### First Invocation

```json
{
  "subagent_type": "general-purpose",
  "description": "Question requirements and raise issues",
  "prompt": "You are a Questioning Agent. Your ONLY job is to ask questions and identify requirement gaps.\n\n[MANDATORY]First read:\n1. CLAUDE.md - Project background, tech stack\n2. Related code - Existing implementation\n\nRequirement summary:\n[Requirement summary]\n\nCommon gaps checklist:\n| Type | Gaps |\n| :--- | :--- |\n| Feature addition | Permissions, validation, concurrency, transactions, exception handling |\n| API endpoint | Parameter validation, error handling, response format, idempotency |\n| UI interface | Loading/empty/error states, responsive, interaction feedback |\n| Data collection | Failure handling, format compatibility, performance, storage |\n| Backend service | Logging, monitoring, config, health check, degradation |\n\nOutput format:\nHas issues: Issue list: 1. [Issue] - Suggestion: A/B/C\nNo issues: No new issues\n\nMUST NOT: Do not judge whether there are issues, do not modify code, ONLY output issues or \"No new issues\".\n\nRemember: SendMessage will continue later, keep memory."
}
```

### SendMessage Continue

```json
{
  "to": "[Agent_ID]",
  "prompt": "User answer:\n[Answer]\n\nUpdated summary:\n[Summary]\n\nResolved issues (DO NOT repeat):\n[Previously asked and answered issue list]\n\nPlease continue questioning, raise new issues if any."
}
```

---

## Check Agent Templates

### First Invocation

```json
{
  "subagent_type": "general-purpose",
  "description": "Comprehensive code check",
  "prompt": "Comprehensive code check, MUST NOT modify.\n\nRequirement summary:\n[Requirement]\n\nCheck scope (MUST check all, MUST NOT skip):\nModified files:\n[File list]\n\nAffected files:\n[File list]\n\n[MANDATORY Check Items]:\n1. Requirement compliance: Functionality completeness, parameter/field completeness, business logic correctness\n2. Code syntax: Syntax errors, type errors, import errors, undefined variables\n3. Security check: SQL injection, XSS, command injection, hardcoded sensitive info\n4. Code standards: Naming conventions, code style, consistency with existing code\n5. Affected impact: Whether modifications affect calls in affected files, interface compatibility, parameter matching\n6. Test plan validation: Evaluate if the test plan (to be executed in Phase 4) adequately covers all modifications. Use reasonable judgment based on change complexity. Small changes (typo, style) need less testing; complex changes (new feature, API) need more. When uncertain, ask for clarification.\n\nOutput format:\nCheck result:\n- Requirement compliance: ✓/✗ [Explanation]\n- Code syntax: ✓/✗ [Explanation]\n- Security check: ✓/✗ [Explanation]\n- Code standards: ✓/✗ [Explanation]\n- Affected impact: ✓/✗ [Explanation]\n- Test plan validation: ✓/✗ [Explanation]\n\nIf issues exist, list all issues:\n- File: [File path]\n- Type: [Modified file/Affected file]\n- Location: [Line number]\n- Issue: [Issue description]\n\nMUST NOT: Do not modify code, ONLY perform check analysis.\n\nRemember: SendMessage will notify modified files later, keep memory."
}
```

### SendMessage Reuse (After Fix)

```json
{
  "to": "[Agent_ID]",
  "prompt": "Fix content:\n[Fix description]\n\n[IMPORTANT]Please re-read the following files:\nModified files:\n[File list]\n\nPlease re-check."
}
```

---

## Affected Files Search Method

```bash
# Java
grep -r "UserService" --include="*.java" | grep -v "UserService.java"

# JavaScript/Vue
grep -r "api" --include="*.vue" --include="*.js" | grep -v "api.js"

# Python
grep -r "user_service" --include="*.py" | grep -v "user_service.py"
```

---

## Browser Testing Guide

### When to Use Browser Testing

| Project Type | Testing Method |
| :--- | :--- |
| Web UI (Vue/React/Angular) | agent-browser testing |
| Mobile App Web Admin | agent-browser testing |
| Internal Web Tools | agent-browser testing |
| CLI/Backend/Library | Compilation testing |

### Browser Testing Flow

```
1. Identify modified functions → List ALL test items (MUST cover every modification)
    ↓
2. Need login? → AskUserQuestion → Get credentials
    ↓
3. Create test cases → Map each modification to test case
    ↓
4. Execute tests via Skill tool {"skill": "agent-browser", "args": "[test description]"}
    ↓
5. Collect results → Record pass/fail for each test case
    ↓
6. Output test report to user (MANDATORY)
    ↓
7. All pass → Output results
    Any fail → ROLLBACK to coding
```

### Test Case Creation (MANDATORY)

**Before testing, MUST list all test cases covering every modification:**

```
=== Test Plan ===

Modified files:
1. src/pages/Login.vue - Modified: login form validation, submit button
2. src/components/UserList.vue - Modified: search filter, delete button

Test cases (MUST cover all modifications):
| # | Function | File | Test Case | Description |
|---|----------|------|-----------|-------------|
| 1 | Login validation | Login.vue | LoginForm_Validation_Error | Submit empty form, verify error messages |
| 2 | Login submit | Login.vue | LoginForm_Submit_Success | Fill valid credentials, verify redirect |
| 3 | Search filter | UserList.vue | UserList_Search_Filter | Enter search term, verify filtered results |
| 4 | Delete button | UserList.vue | UserList_Delete_Success | Click delete, verify item removed |
```

### Test Report Format (MANDATORY Output to User)

**After all tests complete, MUST output this report:**

```
=== Browser Test Report ===

Test Plan Coverage:
- Total modifications: [N] functions
- Total test cases: [N] tests
- Coverage: 100% ([N] test cases for [N] modifications)

Test Results:
| # | Test Case | Description | Result | Details |
|---|-----------|-------------|--------|---------|
| 1 | LoginForm_Validation_Error | Submit empty form | ✓ PASS | Error messages displayed correctly |
| 2 | LoginForm_Submit_Success | Valid login | ✓ PASS | Redirected to dashboard |
| 3 | UserList_Search_Filter | Search users | ✗ FAIL | No results displayed, console error: "TypeError" |
| 4 | UserList_Delete_Success | Delete user | ✓ PASS | User removed from list |

Summary:
- Passed: [N] tests
- Failed: [N] tests
- Status: [ALL PASS / NEED FIX]
```

**If any test fails:**
- Highlight failed tests in report
- Describe failure details
- Proceed to ROLLBACK

### Test Description Examples

**Skill tool call format:**
```json
{"skill": "agent-browser", "args": "<natural language test description>"}
```

**args examples:**
```
Open http://localhost:8080/login, fill username "test@example.com" password "test123", click submit, verify redirect to dashboard.

Navigate to http://localhost:8080/form, fill field1 with "value1", field2 with "value2", click submit button, verify success toast appears.

Go to http://localhost:8080/settings, click "Save" button, verify settings saved message.

Open http://localhost:8080/search, type "keyword" in search input, press Enter, verify search results display.
```

### Credential Request Format

When testing requires login, use AskUserQuestion:

```json
{
  "questions": [
    {
      "header": "Test Account",
      "multiSelect": false,
      "options": [
        {"description": "Use test account documented in project docs", "label": "Use default test account"},
        {"description": "Will provide credentials later", "label": "I will provide"}
      ],
      "question": "Browser testing requires login credentials. Please select:"
    }
  ]
}
```

If user selects "I will provide", ask follow-up:
```json
{
  "questions": [
    {
      "header": "Credentials",
      "multiSelect": false,
      "options": [
        {"description": "Continue waiting for user input", "label": "Waiting for input"}
      ],
      "question": "Please provide test account username and password:"
    }
  ]
}
```