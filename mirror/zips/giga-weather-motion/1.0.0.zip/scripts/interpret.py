#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
未来7天逐3小时天气预报运动解读脚本
支持全国3193个区县级城市，从运动角度深度解读气象风险并提供防御措施
气象数据 -> 运动气象风险分析 -> 防御措施，完整闭环服务
"""

import sys
import json
import ssl
import urllib.request
import urllib.error
import os
from datetime import datetime

# 导入内置城市映射表
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cities import CITY_MAP

# 数据URL（运动解读专属路径）
BASE_URL = "https://diga2026-1252033877.cos.ap-beijing.myqcloud.com/kg3hour/"
DATA_SUFFIX = "motion"

# 合法的3小时时间点
VALID_HOURS = [2, 5, 8, 11, 14, 17, 20, 23]

# 时段场景参考（用于用户请求的中文解读定向提示）
SPORT_HINT = {
    "running":   "跑步",
    "cycling":   "骑行",
    "hiking":    "登山/徒步",
    "swimming":  "游泳",
    "ballsport": "球类运动",
    "morning":   "晨练",
    "motion":    "综合运动",
}

# 场景中文关键词映射（用于提示场景过滤）
SCENE_KEYWORDS = {
    "综合运动": "motion",  "运动": "motion",   "整体": "motion",
    "跑步": "running",     "慢跑": "running",  "长跑": "running",  "户外跑": "running",
    "骑行": "cycling",     "骑车": "cycling",  "单车": "cycling",  "自行车": "cycling",
    "登山": "hiking",      "爬山": "hiking",   "徒步": "hiking",   "远足": "hiking",
    "游泳": "swimming",    "戏水": "swimming",
    "球类": "ballsport",   "打球": "ballsport","篮球": "ballsport","足球": "ballsport",
    "羽毛球": "ballsport", "网球": "ballsport","排球": "ballsport",
    "晨练": "morning",     "晨跑": "morning",  "早锻炼": "morning",
}

# 创建SSL上下文（忽略证书验证，提高兼容性）
SSL_CONTEXT = ssl.create_default_context()
SSL_CONTEXT.check_hostname = False
SSL_CONTEXT.verify_mode = ssl.CERT_NONE


# ─────────────────────────────────────────────
# 城市匹配
# ─────────────────────────────────────────────

def fuzzy_match_city(city_name):
    """城市模糊匹配，支持精确/包含/前缀/反向包含四种方式"""
    if not city_name:
        return None, None

    # 精确匹配
    if city_name in CITY_MAP:
        return CITY_MAP[city_name], city_name

    # 城市名包含在输入中（如输入"北京朝阳"匹配"朝阳"）
    matches = [(name, cid) for name, cid in CITY_MAP.items() if name in city_name]
    if matches:
        matches.sort(key=lambda x: len(x[0]), reverse=True)  # 优先最长匹配
        return matches[0][1], matches[0][0]

    # 前缀匹配：城市名以输入开头
    matches = [(name, cid) for name, cid in CITY_MAP.items() if name.startswith(city_name)]
    if matches:
        return matches[0][1], matches[0][0]

    # 反向包含：城市名包含输入字符串
    matches = [(name, cid) for name, cid in CITY_MAP.items() if city_name in name]
    if matches:
        matches.sort(key=lambda x: len(x[0]))
        return matches[0][1], matches[0][0]

    return None, None


# ─────────────────────────────────────────────
# 数据获取
# ─────────────────────────────────────────────

def fetch_motion_data(city_id):
    """从云端获取指定城市的运动解读数据"""
    url = "{}{}{}.json".format(BASE_URL, city_id, DATA_SUFFIX)
    try:
        req = urllib.request.Request(url, headers={
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        })
        with urllib.request.urlopen(req, timeout=15, context=SSL_CONTEXT) as response:
            raw = response.read().decode("utf-8")
            data = json.loads(raw)
            return data
    except urllib.error.HTTPError as e:
        if e.code == 404:
            raise Exception("未找到城市数据（城市ID: {}）".format(city_id))
        raise Exception("HTTP错误: {}".format(e.code))
    except Exception as e:
        raise Exception("获取数据失败: {}".format(str(e)))


# ─────────────────────────────────────────────
# 时间处理
# ─────────────────────────────────────────────

def find_nearest_hour(target_hour):
    """找到最近的合法3小时时间点"""
    return min(VALID_HOURS, key=lambda h: abs(h - target_hour))


def filter_data(data, target_date=None, target_hour=None):
    """
    按日期和时间过滤数据。
    当指定时间无法精准匹配时，自动获取最近时间段的数据。
    """
    if not data or not isinstance(data, list):
        return []

    result = data[:]
    if target_date:
        result = [item for item in result if item.get("date") == target_date]

    if target_hour is not None:
        sorted_hours = sorted(VALID_HOURS, key=lambda h: abs(h - target_hour))
        for nearest in sorted_hours:
            filtered = [item for item in result if item.get("hour") == nearest]
            if filtered:
                return filtered
        return []

    return result


# ─────────────────────────────────────────────
# 主查询逻辑
# ─────────────────────────────────────────────

def query_sport(city_name, scene="motion", target_date=None, target_hour=None):
    """
    查询运动天气解读数据

    Args:
        city_name: 城市名称（支持模糊匹配）
        scene: 运动场景关键词（用于输出标注，不影响数据获取）
               motion/running/cycling/hiking/swimming/ballsport/morning
        target_date: 目标日期 YYYY-MM-DD（可选，默认今天）
        target_hour: 目标小时 0-23（可选，自动匹配最近3小时时段）

    Returns:
        dict: 包含解读数据的结果字典
    """
    # 解析中文场景关键词 → 英文 key
    if scene and scene not in SPORT_HINT:
        mapped = SCENE_KEYWORDS.get(scene)
        if mapped:
            scene = mapped
        else:
            scene = "motion"  # 未知场景默认综合运动

    scene_label = SPORT_HINT.get(scene, "综合运动")

    # 城市匹配
    city_id, matched_name = fuzzy_match_city(city_name)
    if not city_id:
        suggestions = [name for name in CITY_MAP.keys() if city_name in name][:5]
        hint = "您是否想找: {}".format(", ".join(suggestions)) if suggestions else ""
        raise ValueError("未找到城市: {}\n{}".format(city_name, hint))

    # 获取运动解读数据
    raw_data = fetch_motion_data(city_id)

    # 统一处理数据结构
    if isinstance(raw_data, dict):
        items = raw_data.get("data", raw_data.get("list", []))
    elif isinstance(raw_data, list):
        items = raw_data
    else:
        items = []

    # 过滤时间
    filtered = filter_data(items, target_date, target_hour)

    return {
        "city_name": matched_name,
        "city_id": city_id,
        "scene": scene,
        "scene_label": scene_label,
        "query_date": target_date,
        "query_hour": target_hour,
        "total": len(items),
        "items": filtered
    }


# ─────────────────────────────────────────────
# 格式化输出
# ─────────────────────────────────────────────

def format_item(item, scene_label="综合运动"):
    """格式化单个解读条目"""
    date = item.get("date", "")
    hour = item.get("hour", "")
    word = item.get("word", "")
    content = item.get("content", "")

    time_str = ""
    if date and hour != "":
        time_str = "{} {:02d}:00".format(date, int(hour))
    elif date:
        time_str = date

    lines = []
    lines.append("【🏃 运动天气解读 | {} | {}】".format(scene_label, time_str))
    lines.append("─" * 50)

    if word:
        lines.append("  ▶ 核心建议：{}".format(word))

    if content:
        lines.append("")
        lines.append("  ▶ 详细分析：")
        for line in content.strip().splitlines():
            lines.append("    {}".format(line))

    return "\n".join(lines)


def print_results(query_result, output_json=False):
    """打印查询结果"""
    if output_json:
        print(json.dumps(query_result, ensure_ascii=False, indent=2))
        return

    city_name = query_result.get("city_name", "")
    city_id = query_result.get("city_id", "")
    scene_label = query_result.get("scene_label", "综合运动")
    query_date = query_result.get("query_date", "")
    query_hour = query_result.get("query_hour")
    items = query_result.get("items", [])

    print("=" * 60)
    print("  🏃 运动天气解读 —— {} | {}场景".format(city_name, scene_label))
    print("  城市代码：{}".format(city_id))
    if query_date:
        print("  查询日期：{}".format(query_date))
    if query_hour is not None:
        print("  查询时间：约 {:02d}:00（已自动匹配最近时段）".format(int(query_hour)))
    print("  共 {} 个时段的运动解读数据".format(len(items)))
    print("=" * 60)

    if not items:
        print("\n暂无符合条件的运动解读数据。")
        print("请检查：城市名称是否正确、日期是否在未来7天预报范围内。")
    else:
        for item in items:
            print()
            print(format_item(item, scene_label))

    print("\n" + "=" * 60)


# ─────────────────────────────────────────────
# 命令行入口
# ─────────────────────────────────────────────

def main():
    args = sys.argv[1:]

    if not args or args[0] in ("-h", "--help"):
        print("""
运动天气解读查询工具

用法：
  python3 interpret.py <城市名> [场景] [日期] [小时] [--json]

参数：
  城市名    必填，支持模糊匹配，如：北京、广州、朝阳
  场景      可选，默认 motion（综合运动）
            支持：motion / running / cycling / hiking / swimming / ballsport / morning
            也支持中文：跑步、骑行、登山、游泳、打球、晨练
  日期      可选，格式 YYYY-MM-DD，默认今天
  小时      可选，0-23 整数，自动匹配最近3小时时段
  --json    可选，以JSON格式输出原始数据

示例：
  python3 interpret.py 北京
  python3 interpret.py 北京 running
  python3 interpret.py 广州 骑行
  python3 interpret.py 上海 hiking 2026-04-20 14
  python3 interpret.py 深圳 morning 2026-04-20
  python3 interpret.py 成都 --json
""")
        return

    output_json = "--json" in args
    args = [a for a in args if a != "--json"]

    city_name = args[0]
    scene = args[1] if len(args) > 1 else "motion"
    target_date = args[2] if len(args) > 2 else datetime.now().strftime("%Y-%m-%d")
    target_hour = int(args[3]) if len(args) > 3 else None

    try:
        result = query_sport(city_name, scene, target_date, target_hour)
        print_results(result, output_json)
    except ValueError as e:
        print("参数错误：{}".format(e), file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print("查询失败：{}".format(e), file=sys.stderr)
        sys.exit(2)


if __name__ == "__main__":
    main()
