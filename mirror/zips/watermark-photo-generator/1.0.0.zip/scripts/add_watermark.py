#!/usr/bin/env python3
"""
水印生成器 - 最终完善版本
"""

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import argparse
import os

def add_watermark(
    input_path,
    output_path="watermarked.jpg",
    time="",
    location="",
    latitude="",
    longitude="",
    remark="",
    project="",
    bar_color=(255, 200, 0),
    font_size=None,
    info_x=None,
    info_y=None,
    with_mask=False
):
    """为图片添加水印"""
    img = cv2.cvtColor(cv2.imread(input_path), cv2.COLOR_BGR2RGB)
    img_height, img_width = img.shape[:2]
    
    font_path = "/usr/share/fonts/truetype/wqy/wqy-microhei.ttc"
    
    if font_size is None:
        font_size = max(22, int(img_width * 0.042))
    
    font_value = ImageFont.truetype(font_path, font_size)
    line_spacing = int(font_size * 1.5)
    
    ref_text = "地点：XXXX省XXXX市XXXX区·XXXXXXX小区"
    
    temp_draw = ImageDraw.Draw(Image.new('RGB', (1, 1)))
    ref_bbox = temp_draw.textbbox((0, 0), ref_text, font=font_value)
    max_line_width = ref_bbox[2]
    
    label_width = temp_draw.textbbox((0, 0), "地点：", font=font_value)[2]
    
    def wrap_text(text, font, max_width):
        lines = []
        current_line = ""
        for char in text:
            test_line = current_line + char
            bbox = ImageDraw.Draw(Image.new('RGB', (1, 1))).textbbox((0, 0), test_line, font=font)
            if bbox[2] <= max_width:
                current_line = test_line
            else:
                if current_line:
                    lines.append(current_line)
                current_line = char
        if current_line:
            lines.append(current_line)
        return lines
    
    all_lines = []
    
    if time:
        wrapped = wrap_text("时间：" + time, font_value, max_line_width)
        all_lines.append((wrapped[0], False))
        for line in wrapped[1:]:
            all_lines.append((line, True))
    
    if location:
        wrapped = wrap_text("地点：" + location, font_value, max_line_width)
        all_lines.append((wrapped[0], False))
        for line in wrapped[1:]:
            all_lines.append((line, True))
    
    if latitude and longitude:
        wrapped = wrap_text("经纬度：" + latitude + " " + longitude, font_value, max_line_width)
        all_lines.append((wrapped[0], False))
        for line in wrapped[1:]:
            all_lines.append((line, True))
    
    if project:
        wrapped = wrap_text("项目：" + project, font_value, max_line_width)
        all_lines.append((wrapped[0], False))
        for line in wrapped[1:]:
            all_lines.append((line, True))
    
    if remark:
        wrapped = wrap_text("备注：" + remark, font_value, max_line_width)
        all_lines.append((wrapped[0], False))
        for line in wrapped[1:]:
            all_lines.append((line, True))
    else:
        all_lines.append(("备注：", False))
    
    total_height = len(all_lines) * line_spacing
    bar_height = total_height
    bar_width = 6
    
    temp_draw2 = ImageDraw.Draw(Image.new('RGB', (img_width, img_height)))
    max_text_width = max(temp_draw2.textbbox((0, 0), line[0], font=font_value)[2] for line in all_lines)
    
    watermark_width = bar_width + 15 + max_text_width
    watermark_height = total_height
    
    if info_x is None:
        info_x = int(img_width * 0.03)
    if info_y is None:
        info_y = img_height - watermark_height - 50
    
    if info_x + watermark_width > img_width - 10:
        info_x = img_width - watermark_width - 20
    if info_y + watermark_height > img_height - 10:
        info_y = img_height - watermark_height - 20
    if info_y < 10:
        info_y = 10
    
    img_pil = Image.fromarray(img)
    overlay = Image.new('RGBA', (img_width, img_height), (0, 0, 0, 0))
    overlay_draw = ImageDraw.Draw(overlay)
    
    if with_mask:
        mask_padding_h = 15
        mask_padding_v = 12
        
        mask_width = bar_width + 15 + max_text_width + mask_padding_h * 2
        mask_height = total_height + mask_padding_v * 2
        
        overlay_draw.rounded_rectangle(
            [info_x - mask_padding_h, info_y - mask_padding_v, 
             info_x + mask_width - mask_padding_h, info_y + mask_height - mask_padding_v],
            radius=18,
            fill=(0, 0, 0, 100)
        )
    
    overlay_draw.rectangle([info_x, info_y, info_x + bar_width, info_y + bar_height], fill=bar_color + (255,))
    
    base_x_offset = info_x + bar_width + 15
    y_offset = info_y
    
    for line_text, is_indent in all_lines:
        if is_indent:
            x_offset = base_x_offset + label_width
        else:
            x_offset = base_x_offset
        overlay_draw.text((x_offset, y_offset), line_text, font=font_value, fill=(255, 255, 255))
        y_offset += line_spacing
    
    img_pil.paste(overlay, (0, 0), overlay)
    result_img = cv2.cvtColor(np.array(img_pil), cv2.COLOR_RGB2BGR)
    cv2.imwrite(output_path, result_img)
    
    return output_path


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="水印生成器")
    parser.add_argument("--input", required=True, help="输入图片路径")
    parser.add_argument("--output", default="watermarked.jpg", help="输出图片路径")
    parser.add_argument("--time", default="", help="时间")
    parser.add_argument("--location", default="", help="地点")
    parser.add_argument("--latitude", default="", help="纬度")
    parser.add_argument("--longitude", default="", help="经度")
    parser.add_argument("--remark", default="", help="备注")
    parser.add_argument("--project", default="", help="项目名称")
    parser.add_argument("--bar-color", default="255,200,0", help="竖条颜色 (R,G,B)")
    parser.add_argument("--font-size", type=int, default=None, help="字体大小")
    parser.add_argument("--with-mask", action="store_true", help="添加遮罩")
    
    args = parser.parse_args()
    bar_color = tuple(map(int, args.bar_color.split(',')))
    
    add_watermark(
        input_path=args.input,
        output_path=args.output,
        time=args.time,
        location=args.location,
        latitude=args.latitude,
        longitude=args.longitude,
        remark=args.remark,
        project=args.project,
        bar_color=bar_color,
        font_size=args.font_size,
        with_mask=args.with_mask
    )
    
    print(f"水印添加完成: {args.output}")
