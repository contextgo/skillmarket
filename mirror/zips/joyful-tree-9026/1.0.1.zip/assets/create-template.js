/**
 * 创建文章排版模板 .docx 文件
 * 
 * 使用方法：node create-template.js [输出文件名]
 * 默认输出：template.docx
 */

const { Document, Packer, Paragraph, TextRun, Footer, AlignmentType,
        HeadingLevel, PageNumber, Header } = require('docx');
const fs = require('fs');

async function createTemplate() {
  const outputFile = process.argv[2] || 'template.docx';

  const doc = new Document({
    styles: {
      default: {
        document: {
          run: {
            font: "FangSong_GB2312",
            size: 32, // 三号字 = 16pt
          },
          paragraph: {
            spacing: { line: 600, lineRule: "exact" }, // 固定值30磅
          },
        },
      },
      paragraphStyles: [
        // 一级标题：三号黑体，不加粗
        {
          id: "Heading1",
          name: "Heading 1",
          basedOn: "Normal",
          next: "Normal",
          quickFormat: true,
          run: { font: "SimHei", size: 32 },
          paragraph: {
            spacing: { line: 600, lineRule: "exact", before: 0, after: 0 },
            outlineLevel: 0,
          },
        },
        // 二级标题：三号楷体GB2312，加粗
        {
          id: "Heading2",
          name: "Heading 2",
          basedOn: "Normal",
          next: "Normal",
          quickFormat: true,
          run: { font: "KaiTi_GB2312", size: 32, bold: true },
          paragraph: {
            spacing: { line: 600, lineRule: "exact", before: 0, after: 0 },
            outlineLevel: 1,
          },
        },
        // 三级标题：三号仿宋GB2312，加粗
        {
          id: "Heading3",
          name: "Heading 3",
          basedOn: "Normal",
          next: "Normal",
          quickFormat: true,
          run: { font: "FangSong_GB2312", size: 32, bold: true },
          paragraph: {
            spacing: { line: 600, lineRule: "exact", before: 0, after: 0 },
            outlineLevel: 2,
          },
        },
      ],
    },
    sections: [
      {
        properties: {
          page: {
            size: { width: 11906, height: 16838 }, // A4
            margin: {
              top: 2098,    // 37mm
              bottom: 1984, // 35mm
              left: 1588,   // 28mm
              right: 1474,  // 26mm
              footer: 425,  // 1.5cm
            },
          },
        },
        footers: {
          default: new Footer({
            children: [
              new Paragraph({
                alignment: AlignmentType.CENTER,
                spacing: { line: 600, lineRule: "exact" },
                children: [
                  new TextRun({
                    font: "SimSun",
                    size: 28, // 四号
                    children: ["\u2014 \u7B2C ", PageNumber.CURRENT, " \u9875 \u2014"],
                  }),
                ],
              }),
            ],
          }),
        },
        children: [
          // 大标题：二号方正小标宋简体
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { line: 600, lineRule: "exact", before: 0, after: 0 },
            children: [
              new TextRun({
                font: "FZXiaoBiaoSong-B05",
                size: 44, // 二号 = 22pt
                text: "\u8FD9\u91CC\u662F\u6587\u7AE0\u5927\u6807\u9898",
              }),
            ],
          }),

          // 署名：三号楷体GB2312，加粗
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { line: 600, lineRule: "exact" },
            children: [
              new TextRun({
                font: "KaiTi_GB2312",
                size: 32,
                bold: true,
                text: "\u4F5C\u8005\u7F72\u540D",
              }),
            ],
          }),

          // 日期：三号楷体GB2312，加粗
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { line: 600, lineRule: "exact" },
            children: [
              new TextRun({
                font: "KaiTi_GB2312",
                size: 32,
                bold: true,
                text: "\u0032\u0030\u0032\u0036\u5E74\u0034\u6708",
              }),
            ],
          }),

          // 示例正文段落
          new Paragraph({
            alignment: AlignmentType.JUSTIFIED,
            indent: { firstLine: 480 }, // 首行缩进2字符
            spacing: { line: 600, lineRule: "exact" },
            children: [
              new TextRun({
                font: "FangSong_GB2312",
                size: 32,
                text: "\u8FD9\u91CC\u662F\u6B63\u6587\u5185\u5BB9\u793A\u4F8B\u3002\u6B63\u6587\u4F7F\u7528\u4E09\u53F7\u4EFF\u5B8BGB2312\u5B57\u4F53\uFF0C\u4E0D\u52A0\u7C97\uFF0C\u6BCF\u6BB5\u9996\u884C\u7F29\u8FDB\u4E24\u4E2A\u5B57\u7B26\uFF0C\u884C\u95F4\u8DDD\u4E3A\u56FA\u5B9A\u503C30\u78C5\u3002\u8BF7\u5C06\u6B64\u793A\u4F8B\u6587\u5B57\u66FF\u6362\u4E3A\u60A8\u7684\u5B9E\u9645\u6587\u7AE0\u5185\u5BB9\u3002",
              }),
            ],
          }),
        ],
      },
    ],
  });

  const buffer = await Packer.toBuffer(doc);
  fs.writeFileSync(outputFile, buffer);
  console.log(`Template created: ${outputFile}`);
}

createTemplate().catch(console.error);
