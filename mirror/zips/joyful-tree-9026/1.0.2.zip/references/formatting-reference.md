# 排版标准详细参考文档

本文档为文章排版技能的详细参考，涵盖所有排版参数的技术细节和实现方法。

## 1. 页面设置

### 1.1 纸张大小

- 标准 A4 纸：210mm × 297mm
- DXA 值：宽 11906，高 16838（1mm ≈ 56.7 DXA）

### 1.2 页边距

| 方向 | 毫米值 | DXA 值 | 换算说明 |
|------|--------|--------|----------|
| 上 | 37mm | 2098 | 37 × 56.7 ≈ 2098 |
| 下 | 35mm | 1984 | 35 × 56.7 ≈ 1984 |
| 左 | 28mm | 1588 | 28 × 56.7 ≈ 1588 |
| 右 | 26mm | 1474 | 26 × 56.7 ≈ 1474 |

XML 设置：
```xml
<w:pgMar w:top="2098" w:right="1474" w:bottom="1984" w:left="1588"
         w:header="851" w:footer="425" w:gutter="0"/>
```

### 1.3 页脚底端距离

- 1.5cm = 15mm = 851 DXA

### 1.4 有效版心尺寸

- 版心宽度 = 210 - 28 - 26 = 156mm ≈ 8844 DXA
- 版心高度 = 297 - 37 - 35 = 225mm ≈ 12758 DXA

## 2. 字体与字号规范

### 2.1 字号对照

| 中文字号 | 磅值(pt) | half-points (docx) | EMU (docx-js) |
|----------|----------|---------------------|---------------|
| 二号 | 22 | 44 | 558800 |
| 三号 | 16 | 32 | 406400 |
| 四号 | 14 | 28 | 355600 |
| 小四 | 12 | 24 | 304800 |

### 2.2 各元素字体要求

#### 大标题
- 字体：方正小标宋简体（FangZhengXiaoBiaoSong-B05 / FZXiaoBiaoSong-B05）
- 字号：二号（22pt / 44 half-points）
- 对齐：居中
- 粗细：常规（不加粗）
- 行距：单倍行距

#### 署名及日期
- 字体：楷体GB2312（KaiTi_GB2312）
- 字号：三号（16pt / 32 half-points）
- 粗细：加粗
- 对齐：居中

#### 一级标题
- 字体：黑体（SimHei）
- 字号：三号（16pt / 32 half-points）
- 粗细：常规（不加粗）
- 对齐：左对齐

#### 二级标题
- 字体：楷体GB2312（KaiTi_GB2312）
- 字号：三号（16pt / 32 half-points）
- 粗细：加粗
- 对齐：左对齐

#### 三级标题
- 字体：仿宋GB2312（FangSong_GB2312）
- 字号：三号（16pt / 32 half-points）
- 粗细：加粗
- 对齐：左对齐

#### 正文
- 字体：仿宋GB2312（FangSong_GB2312）
- 字号：三号（16pt / 32 half-points）
- 粗细：常规（不加粗）
- 缩进：首行缩进2字符
- 对齐：两端对齐（justify）

### 2.3 字体兼容性说明

| 字体 | Windows 系统名 | 备用方案 |
|------|---------------|----------|
| 方正小标宋简体 | FangZhengXiaoBiaoSong-B05 / FZXiaoBiaoSong-B05 | 华文中宋（STZhongsong） |
| 黑体 | SimHei | Microsoft YaHei |
| 楷体GB2312 | KaiTi_GB2312 / KaiTi | 楷体（KaiTi） |
| 仿宋GB2312 | FangSong_GB2312 / FangSong | 仿宋（FangSong） |
| 宋体 | SimSun / NSimSun | 宋体（SimSun） |

## 3. 段落格式

### 3.1 行间距

#### 大标题（首页标题）

- 类型：单倍行距（auto）
- 值：1.0倍
- XML：`<w:spacing w:line="240" w:lineRule="auto"/>`
- docx-js：`spacing: { line: 240, lineRule: "auto" }`

说明：大标题（二号方正小标宋简体）使用单倍行距，使标题行距自然显示，不被固定行高截断。

#### 其余段落（正文、各级标题、署名等）

- 类型：固定值（exact）
- 值：30磅
- XML：`<w:spacing w:line="600" w:lineRule="exact"/>`
- docx-js：`spacing: { line: 600, lineRule: "exact" }`

### 3.2 首行缩进

- 缩进量：2个字符（基于三号字）
- XML 方式一（推荐）：`<w:ind w:firstLineChars="200" w:firstLine="640"/>`
- XML 方式二：`<w:ind w:firstLine="640"/>`（640 DXA = 三号字2个字符宽度 = 16pt × 2 × 20 twips/pt）
- docx-js：`indent: { firstLine: 640 }`

注意：推荐使用 `firstLineChars="200"` 属性，因为它会随字号自动调整缩进量。`firstLine="640"` 是三号字对应的 DXA 计算值，作为兼容回退。

### 3.3 段前段后间距

- 段前：0
- 段后：0
- XML：`<w:spacing w:before="0" w:after="0" w:line="600" w:lineRule="exact"/>`

## 4. 页码设置

### 4.1 页码格式

- 字体：宋体（SimSun）
- 字号：四号（14pt / 28 half-points）
- 位置：页脚居中
- 格式：— 第 X 页 —（"带小翅膀"样式）

### 4.2 XML 实现

在 `word/footer1.xml` 中：

```xml
<w:footer mc:Ignorable="w14 wp14">
  <w:p>
    <w:pPr>
      <w:pStyle w:val="Footer"/>
      <w:jc w:val="center"/>
      <w:spacing w:line="600" w:lineRule="exact"/>
    </w:pPr>
    <w:r>
      <w:rPr>
        <w:rFonts w:ascii="SimSun" w:eastAsia="SimSun" w:hAnsi="SimSun"/>
        <w:sz w:val="28"/>
        <w:szCs w:val="28"/>
      </w:rPr>
      <w:t xml:space="preserve">— 第 </w:t>
    </w:r>
    <w:r>
      <w:fldChar w:fldCharType="begin"/>
    </w:r>
    <w:r>
      <w:instrText xml:space="preserve"> PAGE </w:instrText>
    </w:r>
    <w:r>
      <w:fldChar w:fldCharType="separate"/>
    </w:r>
    <w:r>
      <w:rPr>
        <w:rFonts w:ascii="SimSun" w:eastAsia="SimSun" w:hAnsi="SimSun"/>
        <w:sz w:val="28"/>
        <w:szCs w:val="28"/>
      </w:rPr>
      <w:t>1</w:t>
    </w:r>
    <w:r>
      <w:fldChar w:fldCharType="end"/>
    </w:r>
    <w:r>
      <w:rPr>
        <w:rFonts w:ascii="SimSun" w:eastAsia="SimSun" w:hAnsi="SimSun"/>
        <w:sz w:val="28"/>
        <w:szCs w:val="28"/>
      </w:rPr>
      <w:t xml:space="preserve"> 页 —</w:t>
    </w:r>
  </w:p>
</w:footer>
```

## 5. 单位换算参考

| 单位 | 换算关系 |
|------|----------|
| 1 inch | 1440 DXA = 914400 EMU = 72pt = 25.4mm |
| 1 mm | 56.7 DXA = 36000 EMU |
| 1 cm | 567 DXA = 360000 EMU |
| 1 pt | 20 DXA = 12700 EMU |
| 1 磅 (pt) | 20 twips |
| 1 half-point | 1 = docx 中 sz 的单位 |

## 6. docx-js 完整创建模板

```javascript
const { Document, Packer, Paragraph, TextRun, Footer, AlignmentType,
        HeadingLevel, PageNumber } = require('docx');

function createFormattedDocument(title, author, date, sections) {
  return new Document({
    styles: {
      default: {
        document: {
          run: { font: "FangSong_GB2312", size: 32 },
          paragraph: { spacing: { line: 600, lineRule: "exact" } },
        },
      },
      paragraphStyles: [
        {
          id: "Heading1", name: "Heading 1", basedOn: "Normal",
          next: "Normal", quickFormat: true,
          run: { font: "SimHei", size: 32 },
          paragraph: { spacing: { line: 600, lineRule: "exact" }, outlineLevel: 0 },
        },
        {
          id: "Heading2", name: "Heading 2", basedOn: "Normal",
          next: "Normal", quickFormat: true,
          run: { font: "KaiTi_GB2312", size: 32, bold: true },
          paragraph: { spacing: { line: 600, lineRule: "exact" }, outlineLevel: 1 },
        },
        {
          id: "Heading3", name: "Heading 3", basedOn: "Normal",
          next: "Normal", quickFormat: true,
          run: { font: "FangSong_GB2312", size: 32, bold: true },
          paragraph: { spacing: { line: 600, lineRule: "exact" }, outlineLevel: 2 },
        },
      ],
    },
    sections: [{
      properties: {
        page: {
          size: { width: 11906, height: 16838 },
          margin: { top: 2098, bottom: 1984, left: 1588, right: 1474, footer: 425 },
        },
      },
      footers: {
        default: new Footer({
          children: [new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { line: 600, lineRule: "exact" },
            children: [new TextRun({
              font: "SimSun", size: 28,
              children: ["\u2014 \u7B2C ", PageNumber.CURRENT, " \u9875 \u2014"],
            })],
          })],
        }),
      },
      children: [
        // 大标题（单倍行距）
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { line: 240, lineRule: "auto" },
          children: [new TextRun({ font: "FZXiaoBiaoSong-B05", size: 44, text: title })],
        }),
        // 署名
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { line: 600, lineRule: "exact" },
          children: [new TextRun({ font: "KaiTi_GB2312", size: 32, bold: true, text: author })],
        }),
        // 日期
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { line: 600, lineRule: "exact" },
          children: [new TextRun({ font: "KaiTi_GB2312", size: 32, bold: true, text: date })],
        }),
        // 正文段落（使用传入的 sections 数据生成）
        ...sections,
      ],
    }],
  });
}
```
