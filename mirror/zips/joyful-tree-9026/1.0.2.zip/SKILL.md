---
name: article-formatting
description: 中文公文/文章排版技能。当用户需要对中文文章、公文、报告等 Word 文档进行排版时触发。典型触发词：排版、格式化文章、公文排版、设置字体、调整页边距、文档排版、按照标准排版。本技能遵循中国公文排版规范，自动设置页边距、字体字号、行间距、页码等格式要求，确保文档符合正式排版标准。
---

# 文章排版技能

## 概述

本技能用于将中文文章、公文、报告等 Word 文档按照标准排版规范进行格式化。支持对已有文档进行排版，也支持从零创建符合标准的文档。

## 排版标准速查

| 项目 | 要求 |
|------|------|
| 页边距 | 上37mm，下35mm，左28mm，右26mm |
| 页码 | 四号宋体，带小翅膀（括号样式） |
| 页脚底端距离 | 1.5cm |
| 大标题 | 二号方正小标宋简体，单倍行距 |
| 署名及日期 | 三号楷体GB2312，加粗 |
| 一级标题 | 三号黑体，不加粗 |
| 二级标题 | 三号楷体GB2312，加粗 |
| 三级标题 | 三号仿宋GB2312，加粗 |
| 正文 | 三号仿宋GB2312，不加粗，首行缩进2字符 |
| 行间距 | 大标题单倍行距，其余固定值30磅 |

## 工作流程

### 场景一：对已有 Word 文档排版

1. 使用 `unpack.py` 解包目标文档
2. 读取 `document.xml` 中的内容结构
3. 修改 XML 中的样式设置（字体、字号、行距、缩进等）
4. 设置页边距和页码
5. 使用 `pack.py` 重新打包

### 场景二：创建新的排版文档

1. 使用 `docx-js` 创建新文档
2. 按照排版标准设置所有样式
3. 写入内容
4. 生成 .docx 文件

## 详细规范

完整的字体映射、字号对应、XML 样式修改方法等，请参阅 `references/formatting-reference.md`。

## DOCX 编辑模式下的 XML 修改指南

解包文档后，需要修改以下 XML 文件：

### 1. 页边距设置 (`word/document.xml` → `<w:pgSz>` 和 `<w:pgMar>`)

```xml
<w:pgSz w:w="11906" w:h="16838" w:orient="portrait"/>
<w:pgMar w:top="2098" w:right="1474" w:bottom="1984" w:left="1588"
         w:header="851" w:footer="425" w:gutter="0"/>
```

DXA 换算：1mm ≈ 56.7 DXA

- 上37mm = 2098 DXA
- 下35mm = 1984 DXA  
- 左28mm = 1588 DXA
- 右26mm = 1474 DXA

### 2. 行间距设置

**大标题**（首页标题）使用单倍行距，在段落属性 `<w:pPr>` 中添加：

```xml
<w:spacing w:line="240" w:lineRule="auto"/>
```

`w:line="240"` 表示1.0倍行距（单倍行距），`w:lineRule="auto"` 表示自动行距模式。

**其余段落**（正文、标题、署名等）使用固定值30磅行距：

```xml
<w:spacing w:line="600" w:lineRule="exact"/>
```

30磅 = 600 twips（1磅 = 20 twips）

### 3. 字体设置

在 `<w:rPr>`（run 属性）中设置字体：

```xml
<!-- 正文：三号仿宋GB2312，不加粗 -->
<w:rPr>
  <w:rFonts w:ascii="FangSong_GB2312" w:eastAsia="FangSong_GB2312" w:hAnsi="FangSong_GB2312" w:cs="FangSong_GB2312"/>
  <w:sz w:val="32"/>
  <w:szCs w:val="32"/>
</w:rPr>

<!-- 一级标题：三号黑体，不加粗 -->
<w:rPr>
  <w:rFonts w:ascii="SimHei" w:eastAsia="SimHei" w:hAnsi="SimHei" w:cs="SimHei"/>
  <w:sz w:val="32"/>
  <w:szCs w:val="32"/>
</w:rPr>

<!-- 二级标题：三号楷体GB2312，加粗 -->
<w:rPr>
  <w:rFonts w:ascii="KaiTi_GB2312" w:eastAsia="KaiTi_GB2312" w:hAnsi="KaiTi_GB2312" w:cs="KaiTi_GB2312"/>
  <w:b/>
  <w:sz w:val="32"/>
  <w:szCs w:val="32"/>
</w:rPr>

<!-- 三级标题：三号仿宋GB2312，加粗 -->
<w:rPr>
  <w:rFonts w:ascii="FangSong_GB2312" w:eastAsia="FangSong_GB2312" w:hAnsi="FangSong_GB2312" w:cs="FangSong_GB2312"/>
  <w:b/>
  <w:sz w:val="32"/>
  <w:szCs w:val="32"/>
</w:rPr>

<!-- 署名及日期：三号楷体GB2312，加粗 -->
<w:rPr>
  <w:rFonts w:ascii="KaiTi_GB2312" w:eastAsia="KaiTi_GB2312" w:hAnsi="KaiTi_GB2312" w:cs="KaiTi_GB2312"/>
  <w:b/>
  <w:sz w:val="32"/>
  <w:szCs w:val="32"/>
</w:rPr>
```

### 4. 首行缩进

正文段落需要在 `<w:pPr>` 中添加首行缩进：

```xml
<w:ind w:firstLineChars="200" w:firstLine="640"/>
```

`w:firstLineChars="200"` 表示缩进2个字符（百分比为200%），`w:firstLine="640"` 为对应 DXA 值（三号字16pt × 2字符 = 32pt = 640 DXA）。推荐优先使用 `firstLineChars` 属性，因为它会随字号自动调整。

### 5. 页码设置

在 `<w:sectPr>` 中添加页脚引用：

```xml
<w:sectPr>
  <w:pgMar w:top="2098" w:right="1474" w:bottom="1984" w:left="1588"
           w:header="851" w:footer="425" w:gutter="0"/>
  <w:footerReference w:type="default" r:id="rIdFooter1"/>
</w:sectPr>
```

页脚内容（在 `word/footer1.xml` 中）：

```xml
<w:footer>
  <w:p>
    <w:pPr>
      <w:pStyle w:val="Footer"/>
      <w:jc w:val="center"/>
    </w:pPr>
    <w:r>
      <w:rPr>
        <w:rFonts w:ascii="SimSun" w:eastAsia="SimSun" w:hAnsi="SimSun" w:cs="SimSun"/>
        <w:sz w:val="28"/>
        <w:szCs w:val="28"/>
      </w:rPr>
      <w:fldChar w:fldCharType="begin"/>
    </w:r>
    <w:r>
      <w:rPr>
        <w:rFonts w:ascii="SimSun" w:eastAsia="SimSun" w:hAnsi="SimSun" w:cs="SimSun"/>
        <w:sz w:val="28"/>
        <w:szCs w:val="28"/>
      </w:rPr>
      <w:instrText> - 第 PAGE 页 - </w:instrText>
    </w:r>
    <w:r>
      <w:rPr>
        <w:rFonts w:ascii="SimSun" w:eastAsia="SimSun" w:hAnsi="SimSun" w:cs="SimSun"/>
        <w:sz w:val="28"/>
        <w:szCs w:val="28"/>
      </w:rPr>
      <w:fldChar w:fldCharType="end"/>
    </w:r>
  </w:p>
</w:footer>
```

注意：如果系统支持 "带小翅膀" 的页码样式（即 — 第 X 页 — 格式），使用上述方式；否则使用标准的居中页码。

## docx-js 创建模式下的规范

### 样式定义

```javascript
const doc = new Document({
  styles: {
    default: {
      document: {
        run: {
          font: "FangSong_GB2312",
          size: 32, // 三号 = 16pt = 32 half-points
        },
        paragraph: {
          spacing: { line: 600, lineRule: "exact" }, // 固定值30磅
        },
      },
    },
    paragraphStyles: [
      {
        id: "Heading1",
        name: "Heading 1",
        basedOn: "Normal",
        next: "Normal",
        quickFormat: true,
        run: {
          font: "SimHei",
          size: 32,
          bold: false,
        },
        paragraph: {
          spacing: { line: 240, lineRule: "auto" }, // 大标题单倍行距
          outlineLevel: 0,
        },
      },
      {
        id: "Heading2",
        name: "Heading 2",
        basedOn: "Normal",
        next: "Normal",
        quickFormat: true,
        run: {
          font: "KaiTi_GB2312",
          size: 32,
          bold: true,
        },
        paragraph: {
          spacing: { line: 600, lineRule: "exact", before: 0, after: 0 },
          outlineLevel: 1,
        },
      },
      {
        id: "Heading3",
        name: "Heading 3",
        basedOn: "Normal",
        next: "Normal",
        quickFormat: true,
        run: {
          font: "FangSong_GB2312",
          size: 32,
          bold: true,
        },
        paragraph: {
          spacing: { line: 600, lineRule: "exact", before: 0, after: 0 },
          outlineLevel: 2,
        },
      },
    ],
  },
  sections: [
    {
      properties: {
        page: {
          size: { width: 11906, height: 16838 },
          margin: {
            top: 2098,   // 37mm
            bottom: 1984, // 35mm
            left: 1588,   // 28mm
            right: 1474,  // 26mm
            footer: 425,  // 1.5cm
          },
        },
      },
      footers: {
        default: new Footer({
          children: [
            new Paragraph({
              alignment: AlignmentType.CENTER,
              children: [
                new TextRun({
                  font: "SimSun",
                  size: 28, // 四号
                  children: ["— 第 ", PageNumber.CURRENT, " 页 —"],
                }),
              ],
            }),
          ],
        }),
      },
      children: [/* content */],
    },
  ],
});
```

### 正文段落

```javascript
new Paragraph({
  indent: { firstLine: 640 }, // 首行缩进2字符（640 DXA = 三号字16pt × 2 = 32pt）
  spacing: { line: 600, lineRule: "exact" },
  children: [
    new TextRun({
      font: "FangSong_GB2312",
      size: 32,
      text: "正文内容...",
    }),
  ],
});
```

### 大标题

```javascript
new Paragraph({
  alignment: AlignmentType.CENTER,
  spacing: { line: 240, lineRule: "auto", before: 0, after: 0 }, // 单倍行距
  children: [
    new TextRun({
      font: "FangZhengXiaoBiaoSong-B05",
      size: 44, // 二号 = 22pt = 44 half-points
      text: "文章大标题",
    }),
  ],
});
```

### 署名及日期

```javascript
new Paragraph({
  alignment: AlignmentType.CENTER,
  spacing: { line: 600, lineRule: "exact" },
  children: [
    new TextRun({
      font: "KaiTi_GB2312",
      size: 32,
      bold: true,
      text: "作者署名",
    }),
  ],
});
```

## 字号对照表

| 中文字号 | 磅值(pt) | half-points | 像素(px) |
|----------|----------|-------------|----------|
| 二号 | 22pt | 44 | 约29px |
| 三号 | 16pt | 32 | 约21px |
| 四号 | 14pt | 28 | 约19px |
| 小四 | 12pt | 24 | 约16px |

## 字体名称参考

| 排版要素 | 字体名 |
|----------|--------|
| 大标题 | FangZhengXiaoBiaoSong-B05（方正小标宋简体） |
| 一级标题 | SimHei（黑体） |
| 二级标题 | KaiTi_GB2312（楷体GB2312） |
| 三级标题 | FangSong_GB2312（仿宋GB2312） |
| 正文 | FangSong_GB2312（仿宋GB2312） |
| 页码 | SimSun（宋体） |

## 注意事项

1. **字体兼容性**：方正小标宋简体、仿宋GB2312、楷体GB2312 是 Windows 系统内置字体。如果目标系统没有这些字体，文档打开时可能会使用替代字体。
2. **docx-js 字体名**：在 docx-js 中使用的字体名需要与系统字体名一致。
3. **首行缩进**：三号字（16pt）的2字符缩进为 640 DXA（16pt × 2 × 20 twips/pt = 640）。在 XML 中推荐使用 `firstLineChars="200"` 属性，它会随字号自动调整缩进量。
4. **行间距**：大标题使用单倍行距（`line: 240, lineRule: "auto"`），其余段落使用固定值30磅（`line: 600, lineRule: "exact"`），确保排版间距规范统一。
5. **页码格式**：文档中称为"带小翅膀"的页码，通常指 "— 第 X 页 —" 的格式。
