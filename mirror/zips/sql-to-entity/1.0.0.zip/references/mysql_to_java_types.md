# MySQL数据类型到Java类型映射参考

## 数值类型

| MySQL类型 | Java类型 | 说明 |
|-----------|----------|------|
| TINYINT | Integer | 微整型,1字节 |
| SMALLINT | Integer | 小整型,2字节 |
| MEDIUMINT | Integer | 中整型,3字节 |
| INT / INTEGER | Integer | 整型,4字节 |
| BIGINT | Long | 大整型,8字节 |
| FLOAT | Float | 单精度浮点 |
| DOUBLE | Double | 双精度浮点 |
| DECIMAL / NUMERIC | BigDecimal | 精确数值,用于金额等 |

## 字符串类型

| MySQL类型 | Java类型 | 说明 |
|-----------|----------|------|
| CHAR | String | 定长字符串 |
| VARCHAR | String | 变长字符串 |
| TINYTEXT | String | 微文本,255字节 |
| TEXT | String | 文本,64KB |
| MEDIUMTEXT | String | 中文本,16MB |
| LONGTEXT | String | 长文本,4GB |
| ENUM | String | 枚举类型 |
| SET | String | 集合类型 |
| JSON | String | JSON类型 |

## 日期时间类型

| MySQL类型 | Java类型 | 说明 |
|-----------|----------|------|
| DATE | Date | 日期,格式: yyyy-MM-dd |
| TIME | Date | 时间,格式: HH:mm:ss |
| DATETIME | LocalDateTime | 日期时间,格式: yyyy-MM-dd HH:mm:ss |
| TIMESTAMP | LocalDateTime | 时间戳,自动更新 |
| YEAR | Integer | 年份 |

## 二进制类型

| MySQL类型 | Java类型 | 说明 |
|-----------|----------|------|
| BIT | Boolean | 位字段 |
| BINARY | byte[] | 定长二进制 |
| VARBINARY | byte[] | 变长二进制 |
| TINYBLOB | byte[] | 微二进制对象 |
| BLOB | byte[] | 二进制对象,64KB |
| MEDIUMBLOB | byte[] | 中二进制对象,16MB |
| LONGBLOB | byte[] | 长二进制对象,4GB |

## 特殊处理

### 布尔类型
MySQL中通常使用 `TINYINT(1)` 表示布尔值,映射为 `Boolean` 类型。

### 自增主键
标记为 `AUTO_INCREMENT` 的字段应使用 `@TableId` 注解。

### 金额字段
涉及金额计算的字段应使用 `DECIMAL` 类型,映射为 `BigDecimal`,避免精度丢失。
