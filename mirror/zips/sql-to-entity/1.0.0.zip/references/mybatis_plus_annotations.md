# MyBatis-Plus常用注解说明

## @TableName

**用途**: 指定实体类对应的表名

**属性**:
- `value`: 表名(必填)
- `schema`: 数据库schema
- `keepGlobalPrefix`: 是否保持全局表前缀
- `resultMap`: xml中resultMap的id
- `autoResultMap`: 是否自动构建resultMap

**示例**:
```java
@TableName("t_user")
public class User { }

@TableName(value = "t_order", autoResultMap = true)
public class Order { }
```

**本工具使用**: 仅使用表名,不配置其他属性
```java
@TableName("t_user")
public class User { }
```

## @TableId

**用途**: 标记主键字段

**属性**:
- `value`: 主键字段名
- `type`: 主键类型(IdType枚举)
  - `AUTO`: 数据库自增
  - `NONE`: 无状态
  - `INPUT`: 自行输入
  - `ASSIGN_ID`: 分配ID(雪花算法)
  - `ASSIGN_UUID`: 分配UUID

**示例**:
```java
@TableId(type = IdType.AUTO)
private Long id;

@TableId(value = "user_id", type = IdType.ASSIGN_ID)
private Long userId;
```

**本工具使用**: 默认使用雪花算法(ASSIGN_ID)
```java
@TableId(type = IdType.ASSIGN_ID)
private Long id;
```

## @TableField

**用途**: 指定字段映射关系

**属性**:
- `value`: 数据库字段名
- `exist`: 是否为数据库字段(默认true)
- `condition`: 查询条件
- `update`: 更新策略
- `insertStrategy`: 插入策略
- `updateStrategy`: 更新策略
- `whereStrategy`: where条件策略
- `fill`: 字段自动填充策略
- `select`: 是否进行select查询
- `keepGlobalFormat`: 是否保持全局格式

**示例**:
```java
@TableField("user_name")
private String userName;

@TableField(exist = false)
private String extra; // 非数据库字段

@TableField(fill = FieldFill.INSERT)
private Date createTime; // 插入时自动填充
```

**本工具使用**:
```java
// 字段名映射
@TableField("user_name")
private String userName;

// create_time字段自动填充
@TableField(value = "create_time", fill = FieldFill.INSERT)
private LocalDateTime createTime;

// update_time字段自动填充
@TableField(value = "update_time", fill = FieldFill.INSERT_UPDATE)
private LocalDateTime updateTime;
```

## @Version

**用途**: 乐观锁标记

**示例**:
```java
@Version
private Integer version;
```

## @EnumValue

**用途**: 标记枚举值字段

**示例**:
```java
public enum Status {
    ENABLE(1, "启用"),
    DISABLE(0, "禁用");
    
    @EnumValue
    private final Integer code;
    private final String desc;
}
```

## @KeySequence

**用途**: 序列主键(Oracle/PostgreSQL)

**示例**:
```java
@KeySequence("SEQ_USER")
public class User {
    @TableId(type = IdType.INPUT)
    private Long id;
}
```

## 常见使用场景

### 场景1: 基础实体类
```java
@Data
public class BaseEntity {
    @TableId(type = IdType.AUTO)
    private Long id;
    
    @TableField(fill = FieldFill.INSERT)
    private Date createTime;
    
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date updateTime;
}
```

### 场景2: 逻辑删除
```java
@Data
@TableName("t_user")
public class User {
    @TableId
    private Long id;
    
    @TableLogic
    private Integer deleted; // 0-未删除, 1-已删除
}
```

### 场景3: 多字段映射
```java
@Data
@TableName("t_order")
public class Order {
    @TableId
    private Long id;
    
    @TableField("order_no")
    private String orderNo;
    
    @TableField("user_id")
    private Long userId;
    
    @TableField(exist = false)
    private User user; // 关联对象,非数据库字段
}
```
