# Lombok常用注解说明

## @Data

**用途**: 生成getter/setter/equals/canEqual/hashCode/toString方法

**等价于**:
```java
@Getter
@Setter
@EqualsAndHashCode
@ToString
```

**示例**:
```java
@Data
public class User {
    private Long id;
    private String name;
}
```

## @Getter / @Setter

**用途**: 生成getter或setter方法

**属性**:
- `value`: 访问级别(AccessLevel枚举)
  - `PUBLIC`
  - `PROTECTED`
  - `PACKAGE`
  - `PRIVATE`
  - `NONE` (不生成)
- `onMethod`: 方法上的注解
- `onParam`: 参数上的注解

**示例**:
```java
@Getter
@Setter
public class User {
    private Long id;
    
    @Setter(AccessLevel.NONE) // 不生成setter
    private String password;
}
```

## @Accessors

**用途**: 配置getter/setter生成方式

**属性**:
- `fluent`: 是否使用流式风格(方法名=字段名)
- `chain`: setter是否返回this(支持链式调用)
- `prefix`: 字段前缀(自动去除)

**示例**:
```java
@Data
@Accessors(chain = true)
public class User {
    private Long id;
    private String name;
}

// 使用
User user = new User()
    .setId(1L)
    .setName("张三");
```

## @NoArgsConstructor

**用途**: 生成无参构造器

**示例**:
```java
@NoArgsConstructor
public class User {
    private Long id;
    private String name;
}
```

## @AllArgsConstructor

**用途**: 生成全参构造器

**示例**:
```java
@AllArgsConstructor
public class User {
    private Long id;
    private String name;
}

// 使用
User user = new User(1L, "张三");
```

## @RequiredArgsConstructor

**用途**: 生成包含final和@NonNull字段的构造器

**示例**:
```java
@RequiredArgsConstructor
public class UserService {
    private final UserRepository userRepository;
    @NonNull
    private String env;
}
```

## @Builder

**用途**: 生成建造者模式代码

**示例**:
```java
@Data
@Builder
public class User {
    private Long id;
    private String name;
    private Integer age;
}

// 使用
User user = User.builder()
    .id(1L)
    .name("张三")
    .age(25)
    .build();
```

## @Slf4j / @Log4j2

**用途**: 注入日志对象

**示例**:
```java
@Slf4j
public class UserService {
    public void save() {
        log.info("保存用户");
    }
}
```

## @EqualsAndHashCode

**用途**: 生成equals和hashCode方法

**属性**:
- `exclude`: 排除的字段
- `of`: 包含的字段
- `callSuper`: 是否调用父类方法

**示例**:
```java
@EqualsAndHashCode(of = {"id"}) // 只比较id字段
public class User {
    private Long id;
    private String name;
}
```

## @ToString

**用途**: 生成toString方法

**属性**:
- `includeFieldNames`: 是否包含字段名
- `exclude`: 排除的字段
- `of`: 包含的字段
- `callSuper`: 是否调用父类方法

**示例**:
```java
@ToString(exclude = "password")
public class User {
    private Long id;
    private String name;
    private String password;
}
```

## 常见组合

### 实体类标准配置
```java
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_user")
public class User {
    @TableId(type = IdType.ASSIGN_ID)
    private Long id;
    
    private String name;
    private Integer age;
}
```

**本工具使用**: 实体类使用 @Data + @Builder + @NoArgsConstructor + @AllArgsConstructor

### DTO/VO配置
```java
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserDTO {
    private Long id;
    private String name;
}
```

### Service配置
```java
@Slf4j
@RequiredArgsConstructor
@Service
public class UserService {
    private final UserRepository userRepository;
    
    public void save() {
        log.info("保存用户");
    }
}
```

**本工具使用**: ServiceImpl使用 @Slf4j + @Service
