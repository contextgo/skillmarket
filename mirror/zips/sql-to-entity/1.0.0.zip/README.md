# SQL逆向实体类生成器

将MySQL建表语句(CREATE TABLE)逆向生成Java实体类(以DO结尾)、Mapper、Service和ServiceImpl,自动添加MyBatis-Plus和Lombok注解。

## 功能特性

- ✅ 解析MySQL CREATE TABLE语句
- ✅ 自动生成Java实体类、Mapper、Service、ServiceImpl
- ✅ 自动添加MyBatis-Plus注解(@TableName, @TableId, @TableField)
- ✅ 自动添加Lombok注解(@Data, @Builder, @NoArgsConstructor, @AllArgsConstructor)
- ✅ 自动映射MySQL数据类型到Java类型
- ✅ 支持字段注释和表注释
- ✅ 下划线命名自动转驼峰命名
- ✅ ID字段自动添加@JsonFormat注解防止精度丢失
- ✅ create_time和update_time字段自动配置填充策略

## 快速开始

### 安装

将本项目克隆到本地:

```bash
git clone https://gitee.com/your-username/sql-to-entity.git
```

### 基本用法 - 生成实体类

```bash
python scripts/sql_to_entity.py your_table.sql -o User.java
```

### 指定包名

```bash
python scripts/sql_to_entity.py your_table.sql -o User.java -p com.example.entity
```

### 生成所有文件(Entity, Mapper, Service, ServiceImpl)

```bash
python scripts/sql_to_entity.py your_table.sql --all --output-dir ./src/main/java/com/example -p com.example.entity
```

### 禁用注解

```bash
# 不使用Lombok
python scripts/sql_to_entity.py your_table.sql --no-lombok

# 不使用MyBatis-Plus
python scripts/sql_to_entity.py your_table.sql --no-mybatis-plus
```

## 数据类型映射

自动将MySQL数据类型映射为Java类型:

| MySQL类型 | Java类型 |
|-----------|----------|
| INT, INTEGER | Integer |
| BIGINT | Long |
| DECIMAL, NUMERIC | BigDecimal |
| VARCHAR, CHAR, TEXT | String |
| DATETIME, TIMESTAMP | LocalDateTime |
| DATE | Date |
| BLOB | byte[] |

详细映射关系见 [references/mysql_to_java_types.md](references/mysql_to_java_types.md)

## 示例

### 输入SQL

```sql
CREATE TABLE `t_user` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `user_name` VARCHAR(50) NOT NULL COMMENT '用户名',
  `email` VARCHAR(100) DEFAULT NULL COMMENT '邮箱',
  `age` INT(11) DEFAULT NULL COMMENT '年龄',
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表';
```

### 输出Java实体类

```java
package com.example.entity;

import java.io.Serializable;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 用户表
 *
 * @author Auto Generated
 * @date 2026-04-09 10:50:00
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_user")
public class UserDO implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 主键ID */
    @TableId(type = IdType.ASSIGN_ID)
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long id;

    /** 用户名 */
    @TableField("user_name")
    private String userName;

    /** 邮箱 */
    private String email;

    /** 年龄 */
    private Integer age;

    /** 创建时间 */
    @TableField(value = "create_time", fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    /** 更新时间 */
    @TableField(value = "update_time", fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
}
```

## 注意事项

1. **命名转换**: 自动将下划线命名(snake_case)转换为驼峰命名(camelCase)
2. **实体类命名**: 实体类名自动添加DO后缀(Data Object),例如: UserDO
3. **Mapper/Service命名**: Mapper、Service和ServiceImpl不使用DO后缀,例如: UserMapper、UserService、UserServiceImpl
4. **主键识别**: AUTO_INCREMENT字段自动标记为@TableId,使用雪花算法
5. **字段映射**: 当驼峰命名与原字段名不同时,自动添加@TableField注解
6. **导入优化**: 根据实际使用的类型自动导入相应的包
7. **时间类型**: DATETIME和TIMESTAMP类型映射为LocalDateTime
8. **ID精度**: ID字段自动添加@JsonFormat注解防止前端精度丢失
9. **自动填充**: create_time和update_time字段自动配置填充策略

## 高级用法

### 批量转换

可以编写shell脚本批量转换多个SQL文件:

```bash
#!/bin/bash
for sql_file in sqls/*.sql; do
    table_name=$(basename "$sql_file" .sql)
    python scripts/sql_to_entity.py "$sql_file" --all --output-dir ./src/main/java/com/example -p com.example.entity
done
```

### 自定义模板

如需自定义生成模板,可以修改 `scripts/sql_to_entity.py` 中的以下函数:
- `generate_java_entity`: 实体类生成
- `generate_java_mapper`: Mapper接口生成
- `generate_java_service`: Service接口生成
- `generate_java_service_impl`: ServiceImpl实现类生成

## 参考资源

- [MySQL到Java类型映射](references/mysql_to_java_types.md) - 详细的数据类型映射关系
- [MyBatis-Plus注解说明](references/mybatis_plus_annotations.md) - MyBatis-Plus常用注解详解
- [Lombok注解说明](references/lombok_annotations.md) - Lombok常用注解详解

## 许可证

MIT License

## 贡献

欢迎提交 Issue 和 Pull Request!
