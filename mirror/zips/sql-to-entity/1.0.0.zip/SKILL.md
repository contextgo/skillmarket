---
name: sql-to-entity
description: SQL建表语句逆向生成Java实体类,支持MySQL数据库,自动生成MyBatis-Plus和Lombok注解。当用户需要从SQL CREATE TABLE语句生成Java实体类时使用此skill,包括:(1) 解析SQL建表语句,(2) 生成带注解的Java实体类,(3) 自动映射数据类型,(4) 支持字段注释和表注释。适用于数据库表到Java实体类的逆向工程场景。
---

# SQL逆向实体类生成器

将MySQL建表语句(CREATE TABLE)逆向生成Java实体类(以DO结尾)、Mapper、Service和ServiceImpl,自动添加MyBatis-Plus和Lombok注解。

## 快速开始

### 基本用法 - 生成实体类

使用转换脚本生成实体类:

```bash
python scripts/sql_to_entity.py your_table.sql -o User.java
```

### 指定包名

```bash
python scripts/sql_to_entity.py your_table.sql -o User.java -p com.example.entity
```

### 生成所有文件(Entity, Mapper, Service, ServiceImpl)

```bash
python scripts/sql_to_entity.py your_table.sql --all --output-dir ./src/main/java/com/example -p com.example.entity
```

### 禁用注解

```bash
# 不使用Lombok
python scripts/sql_to_entity.py your_table.sql --no-lombok

# 不使用MyBatis-Plus
python scripts/sql_to_entity.py your_table.sql --no-mybatis-plus
```

## 工作流程

1. **解析SQL**: 读取并解析CREATE TABLE语句
2. **提取信息**: 提取表名、字段、注释、约束等
3. **类型映射**: 将MySQL类型映射为Java类型
4. **生成代码**: 生成带注解的Java代码文件

## 支持的特性

### 数据类型映射

自动将MySQL数据类型映射为Java类型:
- 数值类型: INT → Integer, BIGINT → Long, DECIMAL → BigDecimal
- 字符串类型: VARCHAR → String, TEXT → String
- 日期类型: DATETIME → LocalDateTime, TIMESTAMP → LocalDateTime, DATE → Date
- 二进制类型: BLOB → byte[]

详细映射关系见 [references/mysql_to_java_types.md](references/mysql_to_java_types.md)

### MyBatis-Plus注解

自动生成以下注解:
- `@TableName`: 表名映射(仅包含表名)
- `@TableId(type = IdType.ASSIGN_ID)`: 主键标记,使用雪花算法
- `@TableField`: 字段映射(当字段名与列名不同时)
- `@TableField(fill = FieldFill.INSERT)`: create_time字段自动填充
- `@TableField(fill = FieldFill.INSERT_UPDATE)`: update_time字段自动填充

详细说明见 [references/mybatis_plus_annotations.md](references/mybatis_plus_annotations.md)

### Lombok注解

自动生成以下注解:
- `@Data`: 生成getter/setter/equals/hashCode/toString
- `@Builder`: 支持建造者模式
- `@NoArgsConstructor`: 生成无参构造函数
- `@AllArgsConstructor`: 生成全参构造函数
- `@Slf4j`: ServiceImpl中自动生成日志对象

详细说明见 [references/lombok_annotations.md](references/lombok_annotations.md)

### Jackson注解

- `@JsonFormat(shape = JsonFormat.Shape.STRING)`: ID字段防止前端精度丢失

### 字段注释

自动提取SQL中的COMMENT作为Java字段注释:
```sql
`user_name` VARCHAR(50) COMMENT '用户姓名'
```

生成:
```java
/** 用户姓名 */
private String userName;
```

### 类文档注释

自动生成包含表注释、作者和创建时间的文档注释:
```java
/**
 * 用户表
 *
 * @author Auto Generated
 * @date 2026-04-09 10:50:00
 */
```

## 示例

### 输入SQL

```sql
CREATE TABLE `t_user` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `user_name` VARCHAR(50) NOT NULL COMMENT '用户名',
  `email` VARCHAR(100) DEFAULT NULL COMMENT '邮箱',
  `age` INT(11) DEFAULT NULL COMMENT '年龄',
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表';
```

### 输出Java实体类

```java
package com.example.entity;

import java.io.Serializable;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 用户表
 *
 * @author Auto Generated
 * @date 2026-04-09 10:50:00
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_user")
public class UserDO implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 主键ID */
    @TableId(type = IdType.ASSIGN_ID)
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long id;

    /** 用户名 */
    @TableField("user_name")
    private String userName;

    /** 邮箱 */
    private String email;

    /** 年龄 */
    private Integer age;

    /** 创建时间 */
    @TableField(value = "create_time", fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    /** 更新时间 */
    @TableField(value = "update_time", fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
}
```

### 输出Mapper接口

```java
package com.example.mapper;

import com.example.entity.UserDO;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 用户表 Mapper接口
 *
 * @author Auto Generated
 * @date 2026-04-09 10:50:00
 */
@Mapper
public interface UserMapper extends BaseMapper<UserDO> {

}
```

### 输出Service接口

```java
package com.example.service;

import com.example.entity.UserDO;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * 用户表 Service接口
 *
 * @author Auto Generated
 * @date 2026-04-09 10:50:00
 */
public interface UserService extends IService<UserDO> {

}
```

### 输出ServiceImpl实现类

```java
package com.example.service.impl;

import com.example.entity.UserDO;
import com.example.mapper.UserMapper;
import com.example.service.UserService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import lombok.extern.slf4j.Slf4j;

/**
 * 用户表 Service实现类
 *
 * @author Auto Generated
 * @date 2026-04-09 10:50:00
 */
@Slf4j
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, UserDO> implements UserService {

}
```

## 注意事项

1. **命名转换**: 自动将下划线命名(snake_case)转换为驼峰命名(camelCase)
2. **实体类命名**: 实体类名自动添加DO后缀(Data Object),例如: UserDO
3. **Mapper/Service命名**: Mapper、Service和ServiceImpl不使用DO后缀,例如: UserMapper、UserService、UserServiceImpl
4. **主键识别**: AUTO_INCREMENT字段自动标记为@TableId,使用雪花算法
5. **字段映射**: 当驼峰命名与原字段名不同时,自动添加@TableField注解
6. **导入优化**: 根据实际使用的类型自动导入相应的包
7. **时间类型**: DATETIME和TIMESTAMP类型映射为LocalDateTime
8. **ID精度**: ID字段自动添加@JsonFormat注解防止前端精度丢失
9. **自动填充**: create_time和update_time字段自动配置填充策略

## 高级用法

### 批量转换

可以编写shell脚本批量转换多个SQL文件:

```bash
#!/bin/bash
for sql_file in sqls/*.sql; do
    table_name=$(basename "$sql_file" .sql)
    python scripts/sql_to_entity.py "$sql_file" --all --output-dir ./src/main/java/com/example -p com.example.entity
done
```

### 自定义模板

如需自定义生成模板,可以修改 `scripts/sql_to_entity.py` 中的以下函数:
- `generate_java_entity`: 实体类生成
- `generate_java_mapper`: Mapper接口生成
- `generate_java_service`: Service接口生成
- `generate_java_service_impl`: ServiceImpl实现类生成

## 参考资源

- [MySQL到Java类型映射](references/mysql_to_java_types.md) - 详细的数据类型映射关系
- [MyBatis-Plus注解说明](references/mybatis_plus_annotations.md) - MyBatis-Plus常用注解详解
- [Lombok注解说明](references/lombok_annotations.md) - Lombok常用注解详解
