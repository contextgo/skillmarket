#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SQL建表语句逆向生成Java实体类
支持MySQL语法,生成MyBatis-Plus和Lombok注解的Java实体类
"""

import re
import sys
import argparse
from typing import List, Dict, Tuple, Optional


# MySQL数据类型到Java类型的映射
MYSQL_TO_JAVA_TYPE = {
    'tinyint': 'Integer',
    'smallint': 'Integer',
    'mediumint': 'Integer',
    'int': 'Integer',
    'integer': 'Integer',
    'bigint': 'Long',
    'float': 'Float',
    'double': 'Double',
    'decimal': 'BigDecimal',
    'numeric': 'BigDecimal',
    'bit': 'Boolean',
    'char': 'String',
    'varchar': 'String',
    'tinytext': 'String',
    'text': 'String',
    'mediumtext': 'String',
    'longtext': 'String',
    'date': 'Date',
    'datetime': 'LocalDateTime',
    'timestamp': 'LocalDateTime',
    'time': 'Date',
    'year': 'Integer',
    'binary': 'byte[]',
    'varbinary': 'byte[]',
    'tinyblob': 'byte[]',
    'blob': 'byte[]',
    'mediumblob': 'byte[]',
    'longblob': 'byte[]',
    'enum': 'String',
    'set': 'String',
    'json': 'String',
}


def parse_sql_create_table(sql: str) -> Tuple[str, List[Dict], Optional[Dict]]:
    """
    解析SQL CREATE TABLE语句
    返回: (表名, 字段列表, 表注释)
    """
    # 移除注释和多余空格
    sql = re.sub(r'--.*?\n', '', sql)
    sql = re.sub(r'/\*.*?\*/', '', sql, flags=re.DOTALL)
    sql = ' '.join(sql.split())
    
    # 提取表名
    table_match = re.search(r'CREATE\s+TABLE\s+`?(\w+)`?\s*\(', sql, re.IGNORECASE)
    if not table_match:
        raise ValueError("无法解析CREATE TABLE语句,未找到表名")
    
    table_name = table_match.group(1)
    
    # 提取表注释
    table_comment = None
    comment_match = re.search(r"COMMENT\s*=\s*'([^']*)'", sql, re.IGNORECASE)
    if comment_match:
        table_comment = comment_match.group(1)
    
    # 提取字段定义部分
    fields_start = sql.find('(')
    fields_end = sql.rfind(')')
    if fields_start == -1 or fields_end == -1:
        raise ValueError("无法解析字段定义")
    
    fields_sql = sql[fields_start + 1:fields_end]
    
    # 分割字段定义
    fields = []
    current_field = ''
    paren_depth = 0
    
    for char in fields_sql:
        if char == '(':
            paren_depth += 1
            current_field += char
        elif char == ')':
            paren_depth -= 1
            current_field += char
        elif char == ',' and paren_depth == 0:
            fields.append(current_field.strip())
            current_field = ''
        else:
            current_field += char
    
    if current_field.strip():
        fields.append(current_field.strip())
    
    # 解析每个字段
    parsed_fields = []
    for field_def in fields:
        # 跳过索引、主键、外键等约束
        if re.match(r'(PRIMARY|UNIQUE|KEY|INDEX|FOREIGN|CONSTRAINT|CHECK)', field_def, re.IGNORECASE):
            continue
        
        field_info = parse_field_definition(field_def)
        if field_info:
            parsed_fields.append(field_info)
    
    return table_name, parsed_fields, table_comment


def parse_field_definition(field_def: str) -> Optional[Dict]:
    """解析单个字段定义"""
    field_def = field_def.strip()
    
    # 提取字段名
    name_match = re.match(r'`?(\w+)`?\s+', field_def)
    if not name_match:
        return None
    
    field_name = name_match.group(1)
    remaining = field_def[name_match.end():]
    
    # 提取数据类型
    type_match = re.match(r'(\w+)(?:\([^)]*\))?', remaining, re.IGNORECASE)
    if not type_match:
        return None
    
    mysql_type = type_match.group(1).lower()
    java_type = MYSQL_TO_JAVA_TYPE.get(mysql_type, 'Object')
    
    # 检查是否为NOT NULL
    is_nullable = not re.search(r'\bNOT\s+NULL\b', remaining, re.IGNORECASE)
    
    # 检查是否为AUTO_INCREMENT
    is_auto_increment = bool(re.search(r'\bAUTO_INCREMENT\b', remaining, re.IGNORECASE))
    
    # 提取默认值
    default_value = None
    default_match = re.search(r"DEFAULT\s+('(?:[^'\\]|\\.)*'|NULL|\d+)", remaining, re.IGNORECASE)
    if default_match:
        default_value = default_match.group(1)
    
    # 提取字段注释
    field_comment = None
    comment_match = re.search(r"COMMENT\s+'([^']*)'", remaining, re.IGNORECASE)
    if comment_match:
        field_comment = comment_match.group(1)
    
    # 检查是否为主键(字段级别的PRIMARY KEY)
    is_primary_key = bool(re.search(r'\bPRIMARY\s+KEY\b', remaining, re.IGNORECASE))
    
    return {
        'name': field_name,
        'mysql_type': mysql_type,
        'java_type': java_type,
        'nullable': is_nullable,
        'auto_increment': is_auto_increment,
        'default': default_value,
        'comment': field_comment,
        'primary_key': is_primary_key,
    }


def to_camel_case(snake_str: str, first_upper: bool = False) -> str:
    """将下划线命名转换为驼峰命名"""
    components = snake_str.split('_')
    if first_upper:
        return ''.join(x.title() for x in components)
    else:
        return components[0] + ''.join(x.title() for x in components[1:])


def generate_java_entity(
    table_name: str,
    fields: List[Dict],
    table_comment: Optional[str] = None,
    package_name: str = 'com.example.entity',
    author: str = 'Auto Generated',
    use_lombok: bool = True,
    use_mybatis_plus: bool = True,
) -> str:
    """生成Java实体类代码"""
    from datetime import datetime
    
    # 类名(大驼峰 + DO后缀)
    class_name = to_camel_case(table_name, first_upper=True) + 'DO'
    
    # 生成导入语句
    imports = set()
    imports.add('java.io.Serializable')
    
    # 检查是否有id主键(需要JsonFormat注解)
    has_id_field = any(field['name'] == 'id' and (field['primary_key'] or field['auto_increment']) for field in fields)
    
    # 检查是否有create_time或update_time字段
    has_create_time = any(field['name'] == 'create_time' for field in fields)
    has_update_time = any(field['name'] == 'update_time' for field in fields)
    
    for field in fields:
        if field['java_type'] == 'Date':
            imports.add('java.util.Date')
        elif field['java_type'] == 'LocalDateTime':
            imports.add('java.time.LocalDateTime')
        elif field['java_type'] == 'BigDecimal':
            imports.add('java.math.BigDecimal')
    
    if use_mybatis_plus:
        imports.add('com.baomidou.mybatisplus.annotation.TableName')
        imports.add('com.baomidou.mybatisplus.annotation.TableId')
        imports.add('com.baomidou.mybatisplus.annotation.TableField')
        imports.add('com.baomidou.mybatisplus.annotation.IdType')
        if has_create_time or has_update_time:
            imports.add('com.baomidou.mybatisplus.annotation.FieldFill')
    
    # JsonFormat注解
    if has_id_field:
        imports.add('com.fasterxml.jackson.annotation.JsonFormat')
    
    # 开始生成代码
    code_lines = []
    
    # 包声明
    code_lines.append(f'package {package_name};')
    code_lines.append('')
    
    # 导入语句
    for imp in sorted(imports):
        code_lines.append(f'import {imp};')
    code_lines.append('')
    
    # Lombok注解
    if use_lombok:
        code_lines.append('import lombok.Data;')
        code_lines.append('import lombok.Builder;')
        code_lines.append('import lombok.NoArgsConstructor;')
        code_lines.append('import lombok.AllArgsConstructor;')
        code_lines.append('')
    
    # 类文档注释
    if table_comment:
        current_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        code_lines.append('/**')
        code_lines.append(f' * {table_comment}')
        code_lines.append(f' *')
        code_lines.append(f' * @author {author}')
        code_lines.append(f' * @date {current_date}')
        code_lines.append(' */')
    
    # Lombok类注解
    if use_lombok:
        code_lines.append('@Data')
        code_lines.append('@Builder')
        code_lines.append('@NoArgsConstructor')
        code_lines.append('@AllArgsConstructor')
    
    # MyBatis-Plus注解
    if use_mybatis_plus:
        code_lines.append(f'@TableName("{table_name}")')
    
    # 类声明
    code_lines.append(f'public class {class_name} implements Serializable {{')
    code_lines.append('')
    code_lines.append('    private static final long serialVersionUID = 1L;')
    code_lines.append('')
    
    # 字段定义
    for field in fields:
        field_name = to_camel_case(field['name'])
        java_type = field['java_type']
        
        # 字段注释
        if field['comment']:
            code_lines.append(f'    /** {field["comment"]} */')
        
        # MyBatis-Plus注解
        if use_mybatis_plus:
            if field['primary_key'] or field['auto_increment']:
                # 主键使用雪花算法
                code_lines.append('    @TableId(type = IdType.ASSIGN_ID)')
                # 如果是id字段,添加JsonFormat注解
                if field['name'] == 'id':
                    code_lines.append('    @JsonFormat(shape = JsonFormat.Shape.STRING)')
            elif field['name'] == 'create_time':
                # create_time字段自动填充
                code_lines.append('    @TableField(value = "create_time", fill = FieldFill.INSERT)')
            elif field['name'] == 'update_time':
                # update_time字段自动填充
                code_lines.append('    @TableField(value = "update_time", fill = FieldFill.INSERT_UPDATE)')
            elif field_name != field['name']:
                code_lines.append(f'    @TableField("{field["name"]}")')
        
        # 字段声明
        code_lines.append(f'    private {java_type} {field_name};')
        code_lines.append('')
    
    # 如果不使用Lombok,生成getter/setter
    if not use_lombok:
        for field in fields:
            field_name = to_camel_case(field['name'])
            field_name_upper = to_camel_case(field['name'], first_upper=True)
            java_type = field['java_type']
            
            # Getter
            code_lines.append(f'    public {java_type} get{field_name_upper}() {{')
            code_lines.append(f'        return {field_name};')
            code_lines.append('    }')
            code_lines.append('')
            
            # Setter
            code_lines.append(f'    public void set{field_name_upper}({java_type} {field_name}) {{')
            code_lines.append(f'        this.{field_name} = {field_name};')
            code_lines.append('    }')
            code_lines.append('')
    
    # 类结束
    code_lines.append('}')
    
    return '\n'.join(code_lines)


def generate_java_mapper(
    table_name: str,
    entity_class_name: str,
    table_comment: Optional[str] = None,
    package_name: str = 'com.example.mapper',
    entity_package: str = 'com.example.entity',
) -> str:
    """生成Mapper接口代码"""
    from datetime import datetime

    # Mapper类名不包含DO后缀
    base_class_name = entity_class_name.replace('DO', '')
    class_name = f"{base_class_name}Mapper"

    code_lines = []

    # 包声明
    code_lines.append(f'package {package_name};')
    code_lines.append('')

    # 导入语句
    code_lines.append(f'import {entity_package}.{entity_class_name};')
    code_lines.append('import com.baomidou.mybatisplus.core.mapper.BaseMapper;')
    code_lines.append('import org.apache.ibatis.annotations.Mapper;')
    code_lines.append('')

    # 类文档注释
    current_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    code_lines.append('/**')
    if table_comment:
        code_lines.append(f' * {table_comment} Mapper接口')
    else:
        code_lines.append(f' * {base_class_name} Mapper接口')
    code_lines.append(f' *')
    code_lines.append(f' * @author Auto Generated')
    code_lines.append(f' * @date {current_date}')
    code_lines.append(' */')
    code_lines.append('@Mapper')
    code_lines.append(f'public interface {class_name} extends BaseMapper<{entity_class_name}> {{')
    code_lines.append('')
    code_lines.append('}')
    
    return '\n'.join(code_lines)


def generate_java_service(
    table_name: str,
    entity_class_name: str,
    table_comment: Optional[str] = None,
    package_name: str = 'com.example.service',
    entity_package: str = 'com.example.entity',
) -> str:
    """生成Service接口代码"""
    from datetime import datetime

    # Service类名不包含DO后缀
    base_class_name = entity_class_name.replace('DO', '')
    class_name = f"{base_class_name}Service"

    code_lines = []

    # 包声明
    code_lines.append(f'package {package_name};')
    code_lines.append('')

    # 导入语句
    code_lines.append(f'import {entity_package}.{entity_class_name};')
    code_lines.append('import com.baomidou.mybatisplus.extension.service.IService;')
    code_lines.append('')

    # 类文档注释
    current_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    code_lines.append('/**')
    if table_comment:
        code_lines.append(f' * {table_comment} Service接口')
    else:
        code_lines.append(f' * {base_class_name} Service接口')
    code_lines.append(f' *')
    code_lines.append(f' * @author Auto Generated')
    code_lines.append(f' * @date {current_date}')
    code_lines.append(' */')
    code_lines.append(f'public interface {class_name} extends IService<{entity_class_name}> {{')
    code_lines.append('')
    code_lines.append('}')
    
    return '\n'.join(code_lines)


def generate_java_service_impl(
    table_name: str,
    entity_class_name: str,
    table_comment: Optional[str] = None,
    package_name: str = 'com.example.service.impl',
    entity_package: str = 'com.example.entity',
    mapper_package: str = 'com.example.mapper',
    service_package: str = 'com.example.service',
) -> str:
    """生成ServiceImpl实现类代码"""
    from datetime import datetime

    # ServiceImpl类名不包含DO后缀
    base_class_name = entity_class_name.replace('DO', '')
    class_name = f"{base_class_name}ServiceImpl"
    mapper_name = f"{base_class_name}Mapper"
    service_name = f"{base_class_name}Service"

    code_lines = []

    # 包声明
    code_lines.append(f'package {package_name};')
    code_lines.append('')

    # 导入语句
    code_lines.append(f'import {entity_package}.{entity_class_name};')
    code_lines.append(f'import {mapper_package}.{mapper_name};')
    code_lines.append(f'import {service_package}.{service_name};')
    code_lines.append('import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;')
    code_lines.append('import org.springframework.stereotype.Service;')
    code_lines.append('import lombok.extern.slf4j.Slf4j;')
    code_lines.append('')

    # 类文档注释
    current_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    code_lines.append('/**')
    if table_comment:
        code_lines.append(f' * {table_comment} Service实现类')
    else:
        code_lines.append(f' * {base_class_name} Service实现类')
    code_lines.append(f' *')
    code_lines.append(f' * @author Auto Generated')
    code_lines.append(f' * @date {current_date}')
    code_lines.append(' */')
    code_lines.append('@Slf4j')
    code_lines.append('@Service')
    code_lines.append(f'public class {class_name} extends ServiceImpl<{mapper_name}, {entity_class_name}> implements {service_name} {{')
    code_lines.append('')
    code_lines.append('}')
    
    return '\n'.join(code_lines)


def main():
    parser = argparse.ArgumentParser(description='SQL建表语句逆向生成Java实体类')
    parser.add_argument('sql_file', help='SQL文件路径')
    parser.add_argument('-o', '--output', help='输出文件路径(默认输出到控制台)')
    parser.add_argument('-p', '--package', default='com.example.entity', help='实体类包名(默认: com.example.entity)')
    parser.add_argument('--no-lombok', action='store_true', help='不使用Lombok注解')
    parser.add_argument('--no-mybatis-plus', action='store_true', help='不使用MyBatis-Plus注解')
    parser.add_argument('--all', action='store_true', help='生成所有文件(Entity, Mapper, Service, ServiceImpl)')
    parser.add_argument('--output-dir', help='输出目录(用于生成多个文件)')
    
    args = parser.parse_args()
    
    # 读取SQL文件
    try:
        with open(args.sql_file, 'r', encoding='utf-8') as f:
            sql = f.read()
    except FileNotFoundError:
        print(f"错误: 文件 '{args.sql_file}' 不存在", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"错误: 读取文件失败 - {e}", file=sys.stderr)
        sys.exit(1)
    
    # 解析SQL
    try:
        table_name, fields, table_comment = parse_sql_create_table(sql)
    except ValueError as e:
        print(f"错误: SQL解析失败 - {e}", file=sys.stderr)
        sys.exit(1)
    
    # 获取实体类名(添加DO后缀)
    entity_class_name = to_camel_case(table_name, first_upper=True) + 'DO'
    
    # 如果指定了--all参数,生成所有文件
    if args.all:
        if not args.output_dir:
            print("错误: 使用--all参数时必须指定--output-dir", file=sys.stderr)
            sys.exit(1)
        
        import os
        
        # 创建输出目录
        entity_dir = os.path.join(args.output_dir, 'entity')
        mapper_dir = os.path.join(args.output_dir, 'mapper')
        service_dir = os.path.join(args.output_dir, 'service')
        service_impl_dir = os.path.join(args.output_dir, 'service', 'impl')
        
        os.makedirs(entity_dir, exist_ok=True)
        os.makedirs(mapper_dir, exist_ok=True)
        os.makedirs(service_dir, exist_ok=True)
        os.makedirs(service_impl_dir, exist_ok=True)
        
        # 生成Entity
        entity_code = generate_java_entity(
            table_name=table_name,
            fields=fields,
            table_comment=table_comment,
            package_name=args.package,
            use_lombok=not args.no_lombok,
            use_mybatis_plus=not args.no_mybatis_plus,
        )
        entity_file = os.path.join(entity_dir, f'{entity_class_name}.java')
        with open(entity_file, 'w', encoding='utf-8') as f:
            f.write(entity_code)
        print(f'成功生成Entity: {entity_file}')
        
        # 生成Mapper
        mapper_package = args.package.replace('.entity', '.mapper')
        mapper_code = generate_java_mapper(
            table_name=table_name,
            entity_class_name=entity_class_name,
            table_comment=table_comment,
            package_name=mapper_package,
            entity_package=args.package,
        )
        base_class_name = entity_class_name.replace('DO', '')
        mapper_file = os.path.join(mapper_dir, f'{base_class_name}Mapper.java')
        with open(mapper_file, 'w', encoding='utf-8') as f:
            f.write(mapper_code)
        print(f'成功生成Mapper: {mapper_file}')

        # 生成Service
        service_package = args.package.replace('.entity', '.service')
        service_code = generate_java_service(
            table_name=table_name,
            entity_class_name=entity_class_name,
            table_comment=table_comment,
            package_name=service_package,
            entity_package=args.package,
        )
        service_file = os.path.join(service_dir, f'{base_class_name}Service.java')
        with open(service_file, 'w', encoding='utf-8') as f:
            f.write(service_code)
        print(f'成功生成Service: {service_file}')
        
        # 生成ServiceImpl
        service_impl_package = args.package.replace('.entity', '.service.impl')
        service_impl_code = generate_java_service_impl(
            table_name=table_name,
            entity_class_name=entity_class_name,
            table_comment=table_comment,
            package_name=service_impl_package,
            entity_package=args.package,
            mapper_package=mapper_package,
            service_package=service_package,
        )
        service_impl_file = os.path.join(service_impl_dir, f'{base_class_name}ServiceImpl.java')
        with open(service_impl_file, 'w', encoding='utf-8') as f:
            f.write(service_impl_code)
        print(f'成功生成ServiceImpl: {service_impl_file}')
        
        return
    
    # 生成Java实体类
    java_code = generate_java_entity(
        table_name=table_name,
        fields=fields,
        table_comment=table_comment,
        package_name=args.package,
        use_lombok=not args.no_lombok,
        use_mybatis_plus=not args.no_mybatis_plus,
    )
    
    # 输出结果
    if args.output:
        try:
            with open(args.output, 'w', encoding='utf-8') as f:
                f.write(java_code)
            print(f"成功生成实体类: {args.output}")
        except Exception as e:
            print(f"错误: 写入文件失败 - {e}", file=sys.stderr)
            sys.exit(1)
    else:
        print(java_code)


if __name__ == '__main__':
    main()
