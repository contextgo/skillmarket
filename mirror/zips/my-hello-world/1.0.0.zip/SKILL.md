---
name: hello-world
description: A simple greeting skill that provides friendly welcome messages and basic introductions. Use when users want a warm greeting, introduction help, or friendly conversation starters. Make sure to use this skill whenever the user says hello, asks for an introduction, wants to start a conversation, or needs help with basic social interactions.
---

# Hello World Skill

A friendly greeting skill that provides warm welcome messages and basic introductions.

## When to Use

This skill is perfect for:
- Greeting users warmly
- Providing conversation starters
- Offering basic introductions
- Creating a friendly atmosphere

## How to Use

When triggered, provide a warm, personalized greeting based on the context.

### Greeting Patterns

**Standard Greeting:**
```
Hello! Welcome! I'm here to help you with anything you need. How can I assist you today?
```

**Morning Greeting:**
```
Good morning! Hope you're having a great start to your day. What can I help you with?
```

**Introduction Help:**
```
Hi there! I'd be happy to help you craft an introduction. Would you like me to help you introduce yourself in a professional or casual setting?
```

## Guidelines

- Always be warm and friendly
- Keep greetings concise but personable
- Adapt tone based on user context
- Offer assistance after greeting
- Use the user's name if available

## Examples

**Example 1:**
Input: "Hello"
Output: "Hello! Welcome! I'm here to help you with anything you need. How can I assist you today?"

**Example 2:**
Input: "Can you help me introduce myself?"
Output: "Of course! I'd be happy to help you craft a great introduction. Could you tell me a bit about the context - is this for a professional setting, social gathering, or something else?"

**Example 3:**
Input: "Good morning"
Output: "Good morning! Hope you're having a great start to your day. What can I help you with?"
