#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
存储管理器模块
负责将处理后的文章存储到知识库，管理元数据，处理文件操作
"""

import os
import json
import hashlib
import shutil
import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from datetime import datetime
import yaml


class StorageManager:
    """存储管理器"""

    def __init__(self, config: Dict):
        """
        初始化存储管理器

        Args:
            config: 系统配置
        """
        self.config = config
        self.storage_config = config.get('storage_config', {})
        self.collection_config = config.get('collection_strategy', {})

        # 初始化存储目录
        self._initialize_storage_directories()

        # 加载现有元数据
        self.metadata = self._load_metadata()

        logging.info("存储管理器初始化完成")

    def _initialize_storage_directories(self):
        """初始化存储目录"""
        # 获取基础目录
        base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        knowledge_base_dir = os.path.join(base_dir, "knowledge-base")

        # 创建必要目录
        directories = [
            # 原始内容存储
            self._get_raw_content_dir(),
            # 处理后内容存储
            self._get_processed_content_dir('strategy'),
            self._get_processed_content_dir('organization_pay'),
            self._get_processed_content_dir('qualification'),
            self._get_processed_content_dir('talent_development'),
            self._get_processed_content_dir('integrated'),
            self._get_processed_content_dir('unknown'),
            # 临时目录
            self._get_temp_dir(),
            # 缓存目录
            os.path.join(knowledge_base_dir, "cache"),
            # 日志目录
            os.path.join(knowledge_base_dir, "logs"),
            # 元数据目录
            os.path.join(knowledge_base_dir, "metadata")
        ]

        for directory in directories:
            os.makedirs(directory, exist_ok=True)

        logging.debug("存储目录初始化完成")

    def _get_raw_content_dir(self) -> str:
        """获取原始内容存储目录"""
        raw_config = self.storage_config.get('raw_content', {})
        default_dir = "knowledge-base/raw/{year}/{month}/{source_type}"

        # 使用当前日期填充模板
        now = datetime.now()
        directory = raw_config.get('directory', default_dir)
        directory = directory.format(
            year=now.year,
            month=now.month,
            source_type="general"
        )

        return directory

    def _get_processed_content_dir(self, category: str) -> str:
        """获取处理后内容存储目录"""
        processed_config = self.storage_config.get('processed_content', {})
        default_dir = "knowledge-base/articles/{category}"

        directory = processed_config.get('directory', default_dir)
        directory = directory.format(category=category)

        return directory

    def _get_temp_dir(self) -> str:
        """获取临时目录"""
        temp_dir = self.storage_config.get('temp_directory', 'knowledge-base/temp')
        return temp_dir

    def _load_metadata(self) -> Dict:
        """加载元数据"""
        metadata_file = self.storage_config.get('processed_content', {}).get('metadata_file',
                                                                            'knowledge-base/metadata.json')

        if os.path.exists(metadata_file):
            try:
                with open(metadata_file, 'r', encoding='utf-8') as f:
                    metadata = json.load(f)
                logging.info(f"已加载元数据，包含 {len(metadata.get('articles', []))} 篇文章")
                return metadata
            except Exception as e:
                logging.error(f"加载元数据失败: {e}")

        # 创建新的元数据
        metadata = {
            'version': '1.0',
            'created_at': datetime.now().isoformat(),
            'updated_at': datetime.now().isoformat(),
            'total_articles': 0,
            'articles': [],
            'category_distribution': {},
            'source_distribution': {},
            'quality_distribution': {},
            'recent_updates': []
        }

        return metadata

    def _save_metadata(self):
        """保存元数据"""
        metadata_file = self.storage_config.get('processed_content', {}).get('metadata_file',
                                                                            'knowledge-base/metadata.json')

        try:
            # 确保目录存在
            os.makedirs(os.path.dirname(metadata_file), exist_ok=True)

            with open(metadata_file, 'w', encoding='utf-8') as f:
                json.dump(self.metadata, f, ensure_ascii=False, indent=2, ensure_ascii=False)

            logging.debug("元数据已保存")
        except Exception as e:
            logging.error(f"保存元数据失败: {e}")

    def save_articles(self, articles: List[Dict]) -> int:
        """
        保存文章到知识库

        Args:
            articles: 文章列表

        Returns:
            成功保存的文章数量
        """
        saved_count = 0

        for article in articles:
            try:
                if self._save_article(article):
                    saved_count += 1
            except Exception as e:
                logging.error(f"保存文章失败: {e}")

        # 更新元数据
        if saved_count > 0:
            self._update_metadata(articles[:saved_count])
            self._save_metadata()

        logging.info(f"成功保存 {saved_count}/{len(articles)} 篇文章")
        return saved_count

    def _save_article(self, article: Dict) -> bool:
        """保存单篇文章"""
        # 1. 检查是否已存在
        if self._article_exists(article):
            logging.debug(f"文章已存在，跳过: {article.get('title', 'Unknown')}")
            return False

        # 2. 获取存储信息
        category = article.get('category', 'unknown')
        storage_info = self._get_article_storage_info(article, category)

        if not storage_info:
            return False

        file_path, relative_path = storage_info

        # 3. 保存原始内容（如果需要）
        if self.storage_config.get('raw_content', {}).get('keep_raw_content', True):
            self._save_raw_content(article)

        # 4. 保存处理后的内容
        success = self._save_processed_content(article, file_path)

        if success:
            # 5. 更新文章信息
            article['storage_path'] = relative_path
            article['file_name'] = os.path.basename(file_path)
            article['saved_at'] = datetime.now().isoformat()

            # 6. 添加到元数据
            self._add_to_metadata(article)

            logging.debug(f"文章保存成功: {article.get('title', 'Unknown')}")
            return True

        return False

    def _article_exists(self, article: Dict) -> bool:
        """检查文章是否已存在"""
        # 基于URL哈希检查
        url = article.get('url', '')
        if not url:
            return False

        # 生成文章ID
        article_id = self._generate_article_id(article)

        # 在元数据中查找
        for existing_article in self.metadata.get('articles', []):
            if existing_article.get('article_id') == article_id:
                return True

        return False

    def _generate_article_id(self, article: Dict) -> str:
        """生成文章唯一ID"""
        # 基于URL和标题生成哈希
        url = article.get('url', '')
        title = article.get('title', '')
        publish_date = article.get('publish_date', '')

        content = f"{url}|{title}|{publish_date}"
        return hashlib.md5(content.encode('utf-8')).hexdigest()[:16]

    def _get_article_storage_info(self, article: Dict, category: str) -> Optional[Tuple[str, str]]:
        """获取文章存储信息"""
        # 生成文件名
        title = article.get('title', 'Unknown')
        publish_date = article.get('publish_date', '')

        # 清理文件名
        clean_title = self._clean_filename(title)
        if len(clean_title) > 50:
            clean_title = clean_title[:50]

        # 如果有发布日期，包含在文件名中
        date_part = ''
        if publish_date and len(publish_date) >= 10:
            try:
                date_obj = datetime.strptime(publish_date[:10], '%Y-%m-%d')
                date_part = date_obj.strftime('%Y%m%d')
            except:
                pass

        # 生成文件名
        if date_part:
            filename = f"{date_part}_{clean_title}.md"
        else:
            filename = f"{clean_title}.md"

        # 确保文件名唯一
        file_path = os.path.join(self._get_processed_content_dir(category), filename)
        file_path = self._ensure_unique_filename(file_path)

        # 相对路径（用于元数据）
        relative_path = os.path.relpath(file_path, start=os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

        return file_path, relative_path

    def _clean_filename(self, filename: str) -> str:
        """清理文件名，移除非法字符"""
        # 移除非法字符
        illegal_chars = r'[<>:"/\\|?*]'
        cleaned = re.sub(illegal_chars, '', filename)

        # 替换空格为下划线
        cleaned = cleaned.replace(' ', '_')

        # 移除连续的下划线
        cleaned = re.sub(r'_+', '_', cleaned)

        return cleaned.strip('_')

    def _ensure_unique_filename(self, file_path: str) -> str:
        """确保文件名唯一，避免覆盖"""
        if not os.path.exists(file_path):
            return file_path

        # 添加数字后缀
        base, ext = os.path.splitext(file_path)
        counter = 1

        while os.path.exists(f"{base}_{counter}{ext}"):
            counter += 1

        return f"{base}_{counter}{ext}"

    def _save_raw_content(self, article: Dict):
        """保存原始内容"""
        raw_config = self.storage_config.get('raw_content', {})
        if not raw_config.get('keep_raw_content', True):
            return

        try:
            raw_dir = self._get_raw_content_dir()
            os.makedirs(raw_dir, exist_ok=True)

            # 生成文件名
            source_name = article.get('source_name', 'unknown')
            collected_at = article.get('collected_at', datetime.now().isoformat())
            timestamp = collected_at.replace(':', '-').replace('.', '-')

            filename = f"{source_name}_{timestamp}.json"
            file_path = os.path.join(raw_dir, filename)

            # 保存原始数据
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(article, f, ensure_ascii=False, indent=2, ensure_ascii=False)

            logging.debug(f"原始内容已保存: {file_path}")

        except Exception as e:
            logging.warning(f"保存原始内容失败: {e}")

    def _save_processed_content(self, article: Dict, file_path: str) -> bool:
        """保存处理后的内容"""
        try:
            # 确保目录存在
            os.makedirs(os.path.dirname(file_path), exist_ok=True)

            # 生成文章ID
            article_id = self._generate_article_id(article)

            # 准备文章内容
            content = self._format_article_content(article, article_id)

            # 保存文件
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)

            logging.debug(f"文章内容已保存: {file_path}")
            return True

        except Exception as e:
            logging.error(f"保存文章内容失败 {file_path}: {e}")
            return False

    def _format_article_content(self, article: Dict, article_id: str) -> str:
        """格式化文章内容为Markdown格式"""
        # 提取信息
        title = article.get('title', '未知标题')
        author = article.get('author', '')
        publish_date = article.get('publish_date', '')
        source_name = article.get('source_name', '')
        source_type = article.get('source_type', '')
        url = article.get('url', '')
        content = article.get('content', '')
        summary = article.get('summary', '')
        category = article.get('category', 'unknown')
        quality_score = article.get('quality_score', 0.0)
        quality_grade = article.get('quality_grade', 'D')
        classification_confidence = article.get('classification_confidence', 0.0)

        # 获取分类详情
        classification_details = article.get('classification_details', {})
        final_scores = classification_details.get('final_scores', {})

        # 获取质量评估详情
        quality_assessment = article.get('quality_assessment', {})
        dimension_scores = quality_assessment.get('dimension_scores', {})

        # 生成YAML frontmatter
        frontmatter = {
            'article_id': article_id,
            'title': title,
            'author': author,
            'publish_date': publish_date,
            'source': {
                'name': source_name,
                'type': source_type,
                'url': url
            },
            'category': category,
            'collected_at': article.get('collected_at', ''),
            'collected_via': article.get('collected_via', ''),
            'quality': {
                'score': quality_score,
                'grade': quality_grade,
                'dimension_scores': dimension_scores
            },
            'classification': {
                'confidence': classification_confidence,
                'scores': final_scores
            },
            'word_count': article.get('word_count', 0),
            'tags': self._generate_tags(article)
        }

        # 构建Markdown内容
        lines = []

        # YAML frontmatter
        lines.append('---')
        yaml_content = yaml.dump(frontmatter, allow_unicode=True, default_flow_style=False)
        lines.append(yaml_content.strip())
        lines.append('---')
        lines.append('')

        # 标题
        lines.append(f'# {title}')
        lines.append('')

        # 元信息
        if author or publish_date:
            meta_line = []
            if author:
                meta_line.append(f'**作者**: {author}')
            if publish_date:
                meta_line.append(f'**发布日期**: {publish_date}')
            if source_name:
                meta_line.append(f'**来源**: {source_name}')
            if quality_grade:
                meta_line.append(f'**质量评级**: {quality_grade}')

            lines.append(' | '.join(meta_line))
            lines.append('')

        # 摘要
        if summary:
            lines.append('## 摘要')
            lines.append('')
            lines.append(summary)
            lines.append('')

        # 原文链接
        if url:
            lines.append(f'**原文链接**: [{url}]({url})')
            lines.append('')

        # 分类信息
        lines.append('## 分类信息')
        lines.append('')
        lines.append(f'- **类别**: {category}')
        lines.append(f'- **分类置信度**: {classification_confidence:.2%}')
        if final_scores:
            lines.append('- **各类别得分**:')
            for cat, score in final_scores.items():
                lines.append(f'  - {cat}: {score:.3f}')
        lines.append('')

        # 质量评估
        lines.append('## 质量评估')
        lines.append('')
        lines.append(f'- **综合得分**: {quality_score:.3f}')
        lines.append(f'- **质量等级**: {quality_grade}')
        if dimension_scores:
            lines.append('- **各维度得分**:')
            for dim, score in dimension_scores.items():
                lines.append(f'  - {dim}: {score:.3f}')
        lines.append('')

        # 正文内容
        lines.append('## 正文')
        lines.append('')
        lines.append(content)

        return '\n'.join(lines)

    def _generate_tags(self, article: Dict) -> List[str]:
        """生成文章标签"""
        tags = []

        # 基于类别
        category = article.get('category', '')
        if category:
            tags.append(f'category-{category}')

        # 基于质量等级
        quality_grade = article.get('quality_grade', '')
        if quality_grade:
            tags.append(f'quality-{quality_grade}')

        # 基于信源类型
        source_type = article.get('source_type', '')
        if source_type:
            tags.append(f'source-{source_type}')

        # 基于采集方式
        collected_via = article.get('collected_via', '')
        if collected_via:
            tags.append(f'collected-{collected_via}')

        return tags

    def _add_to_metadata(self, article: Dict):
        """将文章添加到元数据"""
        # 生成简化版本的文章信息
        simplified_article = {
            'article_id': self._generate_article_id(article),
            'title': article.get('title', ''),
            'author': article.get('author', ''),
            'publish_date': article.get('publish_date', ''),
            'source_name': article.get('source_name', ''),
            'source_type': article.get('source_type', ''),
            'category': article.get('category', ''),
            'quality_score': article.get('quality_score', 0.0),
            'quality_grade': article.get('quality_grade', 'D'),
            'storage_path': article.get('storage_path', ''),
            'saved_at': article.get('saved_at', ''),
            'url': article.get('url', ''),
            'word_count': article.get('word_count', 0)
        }

        # 添加到文章列表
        self.metadata['articles'].append(simplified_article)

        # 更新统计信息
        self.metadata['total_articles'] = len(self.metadata['articles'])
        self.metadata['updated_at'] = datetime.now().isoformat()

        # 添加到最近更新
        update_info = {
            'article_id': simplified_article['article_id'],
            'title': simplified_article['title'],
            'category': simplified_article['category'],
            'saved_at': simplified_article['saved_at']
        }
        self.metadata['recent_updates'].insert(0, update_info)
        self.metadata['recent_updates'] = self.metadata['recent_updates'][:100]  # 只保留最近的100条

    def _update_metadata(self, articles: List[Dict]):
        """更新元数据统计信息"""
        # 分类分布
        category_distribution = {}
        for article in articles:
            category = article.get('category', 'unknown')
            category_distribution[category] = category_distribution.get(category, 0) + 1

        # 信源分布
        source_distribution = {}
        for article in articles:
            source_type = article.get('source_type', 'unknown')
            source_distribution[source_type] = source_distribution.get(source_type, 0) + 1

        # 质量分布
        quality_distribution = {}
        for article in articles:
            quality_grade = article.get('quality_grade', 'D')
            quality_distribution[quality_grade] = quality_distribution.get(quality_grade, 0) + 1

        # 更新元数据
        self.metadata['category_distribution'] = category_distribution
        self.metadata['source_distribution'] = source_distribution
        self.metadata['quality_distribution'] = quality_distribution

    def update_metadata(self, articles: List[Dict] = None):
        """更新元数据（公开接口）"""
        if articles:
            self._update_metadata(articles)
        self._save_metadata()

    def cleanup(self):
        """清理临时文件"""
        temp_dir = self._get_temp_dir()
        cleanup_days = self.storage_config.get('cleanup_after_days', 7)

        if not os.path.exists(temp_dir) or not self.storage_config.get('cleanup_temp_files', True):
            return

        try:
            now = datetime.now()
            deleted_count = 0

            for item in os.listdir(temp_dir):
                item_path = os.path.join(temp_dir, item)
                if os.path.isfile(item_path):
                    # 检查文件修改时间
                    mtime = datetime.fromtimestamp(os.path.getmtime(item_path))
                    age_days = (now - mtime).days

                    if age_days > cleanup_days:
                        os.remove(item_path)
                        deleted_count += 1
                        logging.debug(f"删除临时文件: {item_path}")

            if deleted_count > 0:
                logging.info(f"清理了 {deleted_count} 个临时文件")

        except Exception as e:
            logging.error(f"清理临时文件失败: {e}")

    def get_statistics(self) -> Dict:
        """获取知识库统计信息"""
        stats = {
            'total_articles': self.metadata.get('total_articles', 0),
            'category_distribution': self.metadata.get('category_distribution', {}),
            'source_distribution': self.metadata.get('source_distribution', {}),
            'quality_distribution': self.metadata.get('quality_distribution', {}),
            'last_updated': self.metadata.get('updated_at', ''),
            'recent_updates_count': len(self.metadata.get('recent_updates', []))
        }

        # 计算文件大小
        total_size = 0
        for category in ['strategy', 'organization_pay', 'qualification', 'talent_development', 'integrated', 'unknown']:
            category_dir = self._get_processed_content_dir(category)
            if os.path.exists(category_dir):
                for file in os.listdir(category_dir):
                    file_path = os.path.join(category_dir, file)
                    if os.path.isfile(file_path):
                        total_size += os.path.getsize(file_path)

        stats['total_size_bytes'] = total_size
        stats['total_size_mb'] = total_size / (1024 * 1024)

        return stats

    def search_articles(self, query: Dict) -> List[Dict]:
        """搜索文章"""
        results = []
        articles = self.metadata.get('articles', [])

        if not query:
            return articles

        for article in articles:
            match = True

            # 按类别搜索
            if 'category' in query and article.get('category') != query['category']:
                match = False

            # 按质量等级搜索
            if 'quality_grade' in query and article.get('quality_grade') != query['quality_grade']:
                match = False

            # 按信源类型搜索
            if 'source_type' in query and article.get('source_type') != query['source_type']:
                match = False

            # 按关键词搜索（在标题中）
            if 'keyword' in query and query['keyword']:
                keyword = query['keyword'].lower()
                title = article.get('title', '').lower()
                if keyword not in title:
                    match = False

            # 按日期范围搜索
            if 'start_date' in query and article.get('publish_date'):
                try:
                    publish_date = datetime.strptime(article['publish_date'][:10], '%Y-%m-%d')
                    start_date = datetime.strptime(query['start_date'], '%Y-%m-%d')
                    if publish_date < start_date:
                        match = False
                except:
                    pass

            if 'end_date' in query and article.get('publish_date'):
                try:
                    publish_date = datetime.strptime(article['publish_date'][:10], '%Y-%m-%d')
                    end_date = datetime.strptime(query['end_date'], '%Y-%m-%d')
                    if publish_date > end_date:
                        match = False
                except:
                    pass

            if match:
                results.append(article)

        return results

    def get_article_content(self, article_id: str) -> Optional[str]:
        """获取文章完整内容"""
        # 在元数据中查找文章
        article_info = None
        for article in self.metadata.get('articles', []):
            if article.get('article_id') == article_id:
                article_info = article
                break

        if not article_info:
            return None

        # 获取存储路径
        storage_path = article_info.get('storage_path')
        if not storage_path or not os.path.exists(storage_path):
            return None

        try:
            with open(storage_path, 'r', encoding='utf-8') as f:
                return f.read()
        except Exception as e:
            logging.error(f"读取文章内容失败 {storage_path}: {e}")
            return None

    def export_metadata(self, format: str = 'json') -> str:
        """导出元数据"""
        if format == 'json':
            return json.dumps(self.metadata, ensure_ascii=False, indent=2)
        elif format == 'yaml':
            return yaml.dump(self.metadata, allow_unicode=True, default_flow_style=False)
        else:
            raise ValueError(f"不支持的格式: {format}")

    def backup(self, backup_dir: str = None):
        """备份知识库"""
        if not backup_dir:
            backup_dir = f"knowledge-base-backup-{datetime.now().strftime('%Y%m%d_%H%M%S')}"

        try:
            os.makedirs(backup_dir, exist_ok=True)

            # 备份元数据
            metadata_file = os.path.join(backup_dir, 'metadata.json')
            with open(metadata_file, 'w', encoding='utf-8') as f:
                json.dump(self.metadata, f, ensure_ascii=False, indent=2, ensure_ascii=False)

            # 备份文章目录
            for category in ['strategy', 'organization_pay', 'qualification', 'talent_development', 'integrated', 'unknown']:
                source_dir = self._get_processed_content_dir(category)
                if os.path.exists(source_dir) and os.listdir(source_dir):
                    dest_dir = os.path.join(backup_dir, 'articles', category)
                    shutil.copytree(source_dir, dest_dir)

            logging.info(f"知识库已备份到: {backup_dir}")
            return backup_dir

        except Exception as e:
            logging.error(f"备份知识库失败: {e}")
            return None


# 导入需要的模块
import re