#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
内容分类器模块
负责将采集到的文章分类到战略、组织薪酬、任职资格、人才发展等类别
"""

import re
import jieba
import logging
from typing import Dict, List, Tuple, Optional
from collections import Counter


class ContentClassifier:
    """内容分类器"""

    def __init__(self, config: Dict):
        """
        初始化分类器

        Args:
            config: 系统配置
        """
        self.config = config
        self.classifier_config = config.get('classifier_config', {})
        self.keyword_config = self.classifier_config.get('keyword_classification', {})

        # 加载关键词
        self.keywords = self._load_keywords()

        # 初始化jieba分词（用于中文）
        self._initialize_jieba()

        logging.info("内容分类器初始化完成")

    def _load_keywords(self) -> Dict[str, List[str]]:
        """加载分类关键词"""
        keywords = {
            'strategy': self.keyword_config.get('strategy_keywords', []),
            'organization_pay': self.keyword_config.get('organization_pay_keywords', []),
            'qualification': self.keyword_config.get('qualification_keywords', []),
            'talent_development': self.keyword_config.get('talent_development_keywords', [])
        }

        # 确保每个类别都有关键词
        for category in ['strategy', 'organization_pay', 'qualification', 'talent_development']:
            if not keywords[category]:
                logging.warning(f"类别 {category} 没有配置关键词，使用默认关键词")
                keywords[category] = self._get_default_keywords(category)

        logging.debug(f"加载关键词: 战略{len(keywords['strategy'])}个, "
                     f"组织薪酬{len(keywords['organization_pay'])}个, "
                     f"任职资格{len(keywords['qualification'])}个, "
                     f"人才发展{len(keywords['talent_development'])}个")

        return keywords

    def _get_default_keywords(self, category: str) -> List[str]:
        """获取默认关键词"""
        default_keywords = {
            'strategy': [
                '战略', '规划', '发展', '转型', '市场', '竞争', '数字化', '创新',
                '商业模式', '增长', '国际化', '并购', '重组', '定位', '愿景', '使命',
                '业务', '产品', '服务', '客户', '渠道', '品牌', '营销', '销售',
                '供应链', '运营', '效率', '成本', '质量', '风险', '合规', '治理'
            ],
            'organization_pay': [
                '组织', '架构', '薪酬', '工资', '绩效', '考核', '激励', '福利',
                '奖金', '股权', '期权', '晋升', '评价', '评估', '职级', '岗位',
                '编制', '编制', '管控', '授权', '流程', '制度', '政策', '规定',
                '公平', '公正', '透明', '竞争', '激励', '保留', '吸引', '流失'
            ],
            'qualification': [
                '任职', '资格', '能力', '素质', '岗位', '标准', '胜任', '模型',
                '技能', '知识', '经验', '行为', '评估', '认证', '通道', '发展',
                '等级', '级别', '序列', '路径', '要求', '条件', '门槛', '基准',
                '测评', '考核', '评审', '认证', '证书', '资质', '文凭', '学位'
            ],
            'talent_development': [
                '人才', '培养', '培训', '发展', '领导力', '梯队', '学习', '教育',
                '技能', '知识', '能力', '素质', '提升', '成长', '进步', '提高',
                '课程', '项目', '计划', '方案', '体系', '系统', '机制', '制度',
                '导师', '教练', '辅导', '指导', '传承', '继任', '储备', '后备'
            ]
        }

        return default_keywords.get(category, [])

    def _initialize_jieba(self):
        """初始化jieba分词"""
        try:
            # 添加自定义词典
            custom_words = []
            for category, words in self.keywords.items():
                custom_words.extend(words)

            for word in custom_words:
                jieba.add_word(word)

            logging.debug(f"添加了 {len(custom_words)} 个自定义分词词汇")
        except Exception as e:
            logging.warning(f"初始化jieba失败: {e}")

    def classify(self, article: Dict) -> str:
        """
        对文章进行分类

        Args:
            article: 文章数据

        Returns:
            分类结果：'strategy', 'organization_pay', 'qualification', 'talent_development'
                    或 'integrated'（综合类）
        """
        try:
            # 获取文章内容
            title = article.get('title', '')
            content = article.get('content', '')
            full_text = f"{title} {content}"

            if not full_text.strip():
                logging.warning("文章内容为空，无法分类")
                return 'unknown'

            # 1. 基于关键词的分类
            keyword_scores = self._classify_by_keywords(full_text)

            # 2. 基于来源类别的分类
            source_score = self._classify_by_source(article)

            # 3. 基于内容结构的分类
            structure_score = self._classify_by_structure(article)

            # 4. 综合评分
            final_scores = self._combine_scores(keyword_scores, source_score, structure_score)

            # 5. 确定最终分类
            category = self._determine_category(final_scores)

            # 记录分类详情
            article['classification_details'] = {
                'keyword_scores': keyword_scores,
                'source_score': source_score,
                'structure_score': structure_score,
                'final_scores': final_scores,
                'final_category': category
            }

            logging.debug(f"文章分类: {category}, 评分: {final_scores}")
            return category

        except Exception as e:
            logging.error(f"分类失败: {e}")
            return 'unknown'

    def _classify_by_keywords(self, text: str) -> Dict[str, float]:
        """
        基于关键词的分类

        Args:
            text: 文章文本

        Returns:
            每个类别的得分（0-1）
        """
        scores = {category: 0.0 for category in self.keywords.keys()}

        if not text:
            return scores

        # 转换为小写以进行不区分大小写的匹配
        text_lower = text.lower()

        # 统计每个关键词的出现次数
        keyword_counts = {category: 0 for category in self.keywords.keys()}
        total_matches = 0

        for category, keywords in self.keywords.items():
            for keyword in keywords:
                # 简单字符串匹配（可改进为分词后匹配）
                count = text_lower.count(keyword.lower())
                keyword_counts[category] += count
                total_matches += count

        # 计算得分
        if total_matches > 0:
            for category in self.keywords.keys():
                scores[category] = keyword_counts[category] / total_matches

        # 使用TF-IDF思路调整得分（简单版）
        # 如果某个关键词在文章中频繁出现，提高该类别得分
        total_words = len(text_lower)
        if total_words > 0:
            for category in self.keywords.keys():
                if keyword_counts[category] > 0:
                    # 关键词密度
                    density = keyword_counts[category] / total_words
                    # 调整得分：考虑密度和匹配次数
                    adjusted_score = scores[category] * (1 + density * 10)
                    scores[category] = min(adjusted_score, 1.0)

        return scores

    def _classify_by_source(self, article: Dict) -> Dict[str, float]:
        """
        基于信源类别的分类

        Args:
            article: 文章数据

        Returns:
            每个类别的得分（基于信源倾向性）
        """
        scores = {category: 0.0 for category in self.keywords.keys()}

        source_categories = article.get('source_categories', [])
        source_type = article.get('source_type', '')

        if not source_categories:
            return scores

        # 信源类别到文章类别的映射
        source_to_article_mapping = {
            'strategy': 'strategy',
            'digital-transformation': 'strategy',
            'organization': 'organization_pay',
            'compensation': 'organization_pay',
            'performance-management': 'organization_pay',
            'incentive': 'organization_pay',
            'qualification': 'qualification',
            'competency': 'qualification',
            'job-analysis': 'qualification',
            'career-path': 'qualification',
            'talent-development': 'talent_development',
            'leadership': 'talent_development',
            'training': 'talent_development',
            'succession-planning': 'talent_development'
        }

        # 根据信源类别分配权重
        for source_cat in source_categories:
            article_cat = source_to_article_mapping.get(source_cat)
            if article_cat and article_cat in scores:
                scores[article_cat] += 0.3  # 每个匹配的信源类别增加0.3分

        # 归一化
        total_score = sum(scores.values())
        if total_score > 1.0:
            for category in scores:
                scores[category] /= total_score

        # 根据信源类型调整权重
        source_type_weights = {
            'consulting_firms': 1.2,  # 咨询公司权重较高
            'hr_professionals': 1.1,  # HR专业机构
            'industry_media': 1.0,
            'official_sources': 1.3,  # 官方机构权重高
            'academic_sources': 1.2   # 学术机构权重高
        }

        weight = source_type_weights.get(source_type, 1.0)
        for category in scores:
            scores[category] *= weight
            scores[category] = min(scores[category], 1.0)

        return scores

    def _classify_by_structure(self, article: Dict) -> Dict[str, float]:
        """
        基于内容结构的分类

        Args:
            article: 文章数据

        Returns:
            每个类别的得分（基于文章结构特征）
        """
        scores = {category: 0.0 for category in self.keywords.keys()}

        content = article.get('content', '')
        if not content:
            return scores

        # 分析文章结构特征
        features = self._extract_structural_features(content)

        # 根据特征推断类别
        # 战略类文章特征：包含大量数据、图表引用、趋势分析
        if features.get('has_data_references', False) or features.get('has_trend_analysis', False):
            scores['strategy'] += 0.4

        # 组织薪酬类文章特征：包含表格、计算公式、政策引用
        if features.get('has_tables', False) or features.get('has_formulas', False):
            scores['organization_pay'] += 0.4

        # 任职资格类文章特征：包含能力模型、行为描述、评估标准
        if features.get('has_models', False) or features.get('has_behavior_descriptions', False):
            scores['qualification'] += 0.4

        # 人才发展类文章特征：包含培训计划、课程大纲、发展路径
        if features.get('has_plans', False) or features.get('has_pathways', False):
            scores['talent_development'] += 0.4

        # 归一化
        total_score = sum(scores.values())
        if total_score > 0:
            for category in scores:
                scores[category] /= total_score

        return scores

    def _extract_structural_features(self, content: str) -> Dict[str, bool]:
        """提取内容结构特征"""
        features = {
            'has_data_references': False,
            'has_trend_analysis': False,
            'has_tables': False,
            'has_formulas': False,
            'has_models': False,
            'has_behavior_descriptions': False,
            'has_plans': False,
            'has_pathways': False
        }

        # 检查数据引用（包含数字和百分比）
        data_patterns = [
            r'\d+%',  # 百分比
            r'\d+\.\d+%',  # 小数百分比
            r'同比增长\s*\d+%',
            r'环比增长\s*\d+%',
            r'市场占有率\s*\d+%',
            r'\d+亿元', r'\d+万元',  # 金额
            r'\d+人', r'\d+名'  # 人数
        ]

        for pattern in data_patterns:
            if re.search(pattern, content):
                features['has_data_references'] = True
                break

        # 检查趋势分析关键词
        trend_keywords = ['趋势', '走向', '发展态势', '未来展望', '预测', '前景', '方向']
        for keyword in trend_keywords:
            if keyword in content:
                features['has_trend_analysis'] = True
                break

        # 检查表格特征
        table_indicators = ['表\d+', '表格\d+', '如下表', '见表', '表所示']
        for indicator in table_indicators:
            if re.search(indicator, content):
                features['has_tables'] = True
                break

        # 检查公式特征
        formula_indicators = ['计算公式', '公式为', '计算方式', '=.*=', '×', '÷', '∑']
        for indicator in formula_indicators:
            if indicator in content or re.search(indicator, content):
                features['has_formulas'] = True
                break

        # 检查模型特征
        model_keywords = ['模型', '框架', '矩阵', '图谱', '地图', '体系图']
        for keyword in model_keywords:
            if keyword in content:
                features['has_models'] = True
                break

        # 检查行为描述特征
        behavior_keywords = ['行为', '表现', '示例', '案例', '情景', '场景']
        for keyword in behavior_keywords:
            if keyword in content:
                features['has_behavior_descriptions'] = True
                break

        # 检查计划特征
        plan_keywords = ['计划', '方案', '规划', '安排', '日程', '时间表']
        for keyword in plan_keywords:
            if keyword in content:
                features['has_plans'] = True
                break

        # 检查路径特征
        pathway_keywords = ['路径', '通道', '阶梯', '台阶', '阶段', '步骤']
        for keyword in pathway_keywords:
            if keyword in content:
                features['has_pathways'] = True
                break

        return features

    def _combine_scores(self, keyword_scores: Dict[str, float],
                       source_score: Dict[str, float],
                       structure_score: Dict[str, float]) -> Dict[str, float]:
        """综合各项评分"""
        weights = self.classifier_config.get('classification_weights', {
            'keyword_match': 0.6,
            'source_category': 0.2,
            'content_structure': 0.2
        })

        final_scores = {category: 0.0 for category in self.keywords.keys()}

        for category in self.keywords.keys():
            score = (keyword_scores.get(category, 0) * weights.get('keyword_match', 0.6) +
                    source_score.get(category, 0) * weights.get('source_category', 0.2) +
                    structure_score.get(category, 0) * weights.get('content_structure', 0.2))

            final_scores[category] = score

        return final_scores

    def _determine_category(self, scores: Dict[str, float]) -> str:
        """根据评分确定最终分类"""
        # 找到最高分
        max_score = max(scores.values())
        if max_score == 0:
            return 'unknown'

        # 找到所有达到最高分80%的类别
        threshold = max_score * 0.8
        top_categories = [cat for cat, score in scores.items() if score >= threshold]

        if len(top_categories) == 1:
            # 只有一个明显领先的类别
            return top_categories[0]
        elif len(top_categories) > 1:
            # 多个类别得分接近，判断为综合类
            # 但如果某个类别得分特别突出（超过第二名的20%），仍返回该类别
            sorted_scores = sorted(scores.items(), key=lambda x: x[1], reverse=True)
            if len(sorted_scores) >= 2:
                first_score = sorted_scores[0][1]
                second_score = sorted_scores[1][1]
                if first_score > second_score * 1.2:  # 领先20%以上
                    return sorted_scores[0][0]

            return 'integrated'
        else:
            return 'unknown'

    def classify_with_confidence(self, article: Dict) -> Tuple[str, float]:
        """
        分类并返回置信度

        Args:
            article: 文章数据

        Returns:
            (分类结果, 置信度0-1)
        """
        category = self.classify(article)

        if category == 'unknown':
            return category, 0.0

        details = article.get('classification_details', {})
        final_scores = details.get('final_scores', {})

        if category == 'integrated':
            # 综合类的置信度取各类别得分的平均值
            confidence = sum(final_scores.values()) / len(final_scores)
        else:
            confidence = final_scores.get(category, 0.0)

        return category, confidence

    def get_classification_details(self, article: Dict) -> Dict:
        """
        获取分类的详细分析

        Args:
            article: 文章数据

        Returns:
            分类详情
        """
        # 确保已经分类
        if 'classification_details' not in article:
            self.classify(article)

        return article.get('classification_details', {})

    def batch_classify(self, articles: List[Dict]) -> List[Dict]:
        """
        批量分类文章

        Args:
            articles: 文章列表

        Returns:
            分类后的文章列表（添加了classification字段）
        """
        classified_articles = []

        for i, article in enumerate(articles):
            try:
                category = self.classify(article)
                article['category'] = category

                # 添加置信度
                _, confidence = self.classify_with_confidence(article)
                article['classification_confidence'] = confidence

                classified_articles.append(article)

                if (i + 1) % 10 == 0:
                    logging.info(f"已分类 {i + 1}/{len(articles)} 篇文章")

            except Exception as e:
                logging.error(f"分类文章失败: {e}")
                article['category'] = 'unknown'
                article['classification_confidence'] = 0.0
                classified_articles.append(article)

        logging.info(f"批量分类完成: {len(classified_articles)} 篇文章")
        return classified_articles

    def evaluate_classification(self, test_articles: List[Dict]) -> Dict:
        """
        评估分类器性能

        Args:
            test_articles: 测试文章列表，需要包含正确的分类标签

        Returns:
            评估结果
        """
        if not test_articles:
            return {'error': '没有测试数据'}

        correct = 0
        total = 0
        confusion_matrix = {cat: {cat2: 0 for cat2 in self.keywords.keys()} for cat in self.keywords.keys()}
        confidence_scores = []

        for article in test_articles:
            true_category = article.get('true_category')
            if not true_category:
                continue

            predicted_category, confidence = self.classify_with_confidence(article)

            # 更新混淆矩阵
            if true_category in confusion_matrix and predicted_category in confusion_matrix[true_category]:
                confusion_matrix[true_category][predicted_category] += 1

            # 检查是否正确
            if predicted_category == true_category:
                correct += 1
                confidence_scores.append(confidence)

            total += 1

        if total == 0:
            return {'error': '没有有效的测试数据'}

        accuracy = correct / total
        avg_confidence = sum(confidence_scores) / len(confidence_scores) if confidence_scores else 0

        results = {
            'total_articles': total,
            'correct_predictions': correct,
            'accuracy': accuracy,
            'average_confidence': avg_confidence,
            'confusion_matrix': confusion_matrix
        }

        return results