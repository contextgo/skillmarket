#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
咨询方案审计知识库自动收集系统

提供自动从优质信源采集、分类、评估和存储咨询相关内容的完整解决方案。

主要模块：
- collector: 内容采集器，负责从配置的信源采集文章
- classifier: 内容分类器，将文章分类到战略、组织薪酬、任职资格、人才发展等类别
- quality_assessor: 质量评估器，从多个维度评估文章质量
- storage_manager: 存储管理器，负责将处理后的文章保存到知识库
- monitor: 系统监控器，监控系统运行状态和性能
- main: 主协调器，组织整个收集流程

使用方式：
1. 单次运行: python main.py --mode once
2. 定时任务: python main.py --mode scheduler
3. 交互式: python main.py --mode interactive

配置文件: config/sources.yaml
"""

__version__ = "1.0.0"
__author__ = "咨询方案审计系统"
__description__ = "知识库自动收集系统"

# 导出主要类
from .collector import ContentCollector
from .classifier import ContentClassifier
from .quality_assessor import QualityAssessor
from .storage_manager import StorageManager
from .monitor import SystemMonitor
from .main import KnowledgeBaseAutoCollector

__all__ = [
    "ContentCollector",
    "ContentClassifier",
    "QualityAssessor",
    "StorageManager",
    "SystemMonitor",
    "KnowledgeBaseAutoCollector"
]