#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
内容采集器模块
负责从配置的信源采集文章内容
"""

import re
import time
import random
import requests
import feedparser
from urllib.parse import urlparse, urljoin
from typing import Dict, List, Optional, Tuple
from datetime import datetime, timedelta
import logging
from bs4 import BeautifulSoup
import hashlib
import json


class ContentCollector:
    """内容采集器"""

    def __init__(self, config: Dict, monitor=None):
        """
        初始化采集器

        Args:
            config: 系统配置
            monitor: 监控器实例
        """
        self.config = config
        self.monitor = monitor
        self.network_config = config.get('network_config', {})
        self.collection_config = config.get('collection_strategy', {})

        # 初始化请求会话
        self.session = self._create_session()

        # 缓存已采集的URL
        self.collected_urls = set()
        self._load_collected_urls()

        logging.info("内容采集器初始化完成")

    def _create_session(self) -> requests.Session:
        """创建HTTP会话"""
        session = requests.Session()

        # 设置请求头
        headers = self.network_config.get('headers', {})
        session.headers.update(headers)

        # 设置代理
        proxy_config = self.network_config.get('proxy', {})
        if proxy_config.get('enabled', False):
            proxies = {
                'http': proxy_config.get('http_proxy'),
                'https': proxy_config.get('https_proxy')
            }
            session.proxies.update(proxies)

        # 设置超时
        timeout = self.network_config.get('request_limits', {}).get('request_timeout', 30)
        session.request = lambda method, url, **kwargs: requests.Session.request(
            self.session, method, url, timeout=timeout, **kwargs)

        return session

    def _load_collected_urls(self):
        """加载已采集的URL记录"""
        try:
            cache_file = "knowledge-base/cache/collected_urls.json"
            if os.path.exists(cache_file):
                with open(cache_file, 'r', encoding='utf-8') as f:
                    self.collected_urls = set(json.load(f))
                logging.info(f"已加载 {len(self.collected_urls)} 个已采集URL")
        except Exception as e:
            logging.warning(f"加载URL缓存失败: {e}")

    def _save_collected_urls(self):
        """保存已采集的URL记录"""
        try:
            cache_dir = "knowledge-base/cache"
            os.makedirs(cache_dir, exist_ok=True)

            cache_file = os.path.join(cache_dir, "collected_urls.json")
            with open(cache_file, 'w', encoding='utf-8') as f:
                json.dump(list(self.collected_urls), f, ensure_ascii=False, indent=2)
        except Exception as e:
            logging.warning(f"保存URL缓存失败: {e}")

    def collect_articles(self, source_types: List[str] = None, force_update: bool = False) -> List[Dict]:
        """
        从指定信源类型采集文章

        Args:
            source_types: 信源类型列表，如果为None则采集所有启用的信源
            force_update: 是否强制更新（忽略时间限制）

        Returns:
            采集到的文章列表
        """
        articles = []
        sources_config = self.config.get('sources', {})

        # 确定要采集的信源类型
        if source_types is None:
            source_types = []
            for source_type, config in sources_config.items():
                if config.get('enabled', True):
                    source_types.append(source_type)
        else:
            # 过滤启用的信源
            source_types = [st for st in source_types
                          if sources_config.get(st, {}).get('enabled', True)]

        logging.info(f"开始采集信源类型: {source_types}")

        for source_type in source_types:
            try:
                source_config = sources_config.get(source_type, {})
                source_articles = self._collect_from_source_type(source_type, source_config, force_update)
                articles.extend(source_articles)

                logging.info(f"从 {source_type} 采集到 {len(source_articles)} 篇文章")

                # 更新监控
                if self.monitor:
                    self.monitor.record_collection(source_type, len(source_articles))

            except Exception as e:
                logging.error(f"采集信源类型 {source_type} 失败: {e}")
                continue

        # 过滤重复和低质量内容
        filtered_articles = self._filter_articles(articles)

        # 保存URL缓存
        self._save_collected_urls()

        logging.info(f"采集完成: 总共 {len(articles)} 篇，过滤后 {len(filtered_articles)} 篇")
        return filtered_articles

    def _collect_from_source_type(self, source_type: str, source_config: Dict, force_update: bool) -> List[Dict]:
        """从特定信源类型采集"""
        articles = []
        source_list = []

        # 获取该类型下的所有信源
        if 'international' in source_config:
            source_list.extend(source_config['international'])
        if 'domestic' in source_config:
            source_list.extend(source_config['domestic'])
        if 'business_media' in source_config:
            source_list.extend(source_config['business_media'])
        if 'domestic_business' in source_config:
            source_list.extend(source_config['domestic_business'])
        if 'hr_media' in source_config:
            source_list.extend(source_config['hr_media'])
        if 'government' in source_config:
            source_list.extend(source_config['government'])
        if 'industry_associations' in source_config:
            source_list.extend(source_config['industry_associations'])
        if 'business_schools' in source_config:
            source_list.extend(source_config['business_schools'])
        if 'research_institutes' in source_config:
            source_list.extend(source_config['research_institutes'])
        if 'international_hr' in source_config:
            source_list.extend(source_config['international_hr'])
        if 'domestic_hr' in source_config:
            source_list.extend(source_config['domestic_hr'])

        # 限制每个信源类型的最大采集数量
        max_per_source = self.collection_config.get('depth_control', {}).get('max_articles_per_source', 20)
        source_list = source_list[:max_per_source]

        for source in source_list:
            try:
                source_articles = self._collect_from_source(source, source_type, force_update)
                articles.extend(source_articles)

                # 添加随机延迟，避免被封
                delay = self.network_config.get('request_limits', {}).get('delay_between_requests', 1)
                time.sleep(delay + random.uniform(0, 0.5))

            except Exception as e:
                logging.error(f"采集信源 {source.get('name', 'Unknown')} 失败: {e}")
                continue

        return articles

    def _collect_from_source(self, source: Dict, source_type: str, force_update: bool) -> List[Dict]:
        """从单个信源采集"""
        articles = []
        name = source.get('name', 'Unknown')
        url_patterns = source.get('url_patterns', [])
        rss_feeds = source.get('rss_feeds', [])
        categories = source.get('categories', [])

        logging.debug(f"开始采集信源: {name}")

        # 1. 从RSS订阅采集
        for rss_url in rss_feeds:
            try:
                rss_articles = self._collect_from_rss(rss_url, source, source_type)
                articles.extend(rss_articles)
            except Exception as e:
                logging.warning(f"采集RSS {rss_url} 失败: {e}")

        # 2. 从URL模式采集
        for url_pattern in url_patterns:
            try:
                pattern_articles = self._collect_from_url_pattern(url_pattern, source, source_type, force_update)
                articles.extend(pattern_articles)
            except Exception as e:
                logging.warning(f"采集URL模式 {url_pattern} 失败: {e}")

        # 为每篇文章添加信源信息
        for article in articles:
            article['source_name'] = name
            article['source_type'] = source_type
            article['source_categories'] = categories

        logging.debug(f"从信源 {name} 采集到 {len(articles)} 篇文章")
        return articles

    def _collect_from_rss(self, rss_url: str, source: Dict, source_type: str) -> List[Dict]:
        """从RSS订阅采集"""
        articles = []

        try:
            # 解析RSS
            feed = feedparser.parse(rss_url)

            if feed.bozo:
                logging.warning(f"RSS解析错误: {feed.bozo_exception}")
                return articles

            # 限制采集数量
            max_items = self.collection_config.get('depth_control', {}).get('max_articles_per_source', 20)
            items = feed.entries[:max_items]

            for item in items:
                try:
                    # 检查是否已采集
                    url = item.get('link', '')
                    if not url or self._is_already_collected(url):
                        continue

                    # 采集文章内容
                    article = self._fetch_article_from_url(url, source, source_type)
                    if article:
                        article['collected_via'] = 'rss'
                        articles.append(article)

                        # 标记为已采集
                        self.collected_urls.add(url)

                except Exception as e:
                    logging.warning(f"处理RSS项目失败: {e}")
                    continue

        except Exception as e:
            logging.error(f"采集RSS失败: {e}")

        return articles

    def _collect_from_url_pattern(self, url_pattern: str, source: Dict, source_type: str, force_update: bool) -> List[Dict]:
        """从URL模式采集"""
        articles = []

        try:
            # 解析URL模式，提取基础URL
            parsed = urlparse(url_pattern)
            base_url = f"{parsed.scheme}://{parsed.netloc}"

            # 获取页面链接
            links = self._extract_links_from_page(url_pattern, source)

            # 限制采集数量
            max_links = self.collection_config.get('depth_control', {}).get('max_articles_per_source', 20)
            links = links[:max_links]

            for link in links:
                try:
                    # 构建完整URL
                    if not link.startswith('http'):
                        link = urljoin(base_url, link)

                    # 检查是否已采集
                    if not force_update and self._is_already_collected(link):
                        continue

                    # 检查URL是否符合模式
                    if not self._url_matches_pattern(link, url_pattern):
                        continue

                    # 采集文章内容
                    article = self._fetch_article_from_url(link, source, source_type)
                    if article:
                        article['collected_via'] = 'web_crawl'
                        articles.append(article)

                        # 标记为已采集
                        self.collected_urls.add(link)

                        # 添加延迟
                        delay = self.network_config.get('request_limits', {}).get('delay_between_requests', 1)
                        time.sleep(delay)

                except Exception as e:
                    logging.warning(f"处理链接 {link} 失败: {e}")
                    continue

        except Exception as e:
            logging.error(f"从URL模式采集失败: {e}")

        return articles

    def _extract_links_from_page(self, url: str, source: Dict) -> List[str]:
        """从页面提取文章链接"""
        links = []

        try:
            # 获取页面内容
            response = self._make_request(url)
            if not response:
                return links

            soup = BeautifulSoup(response.text, 'html.parser')

            # 查找文章链接
            # 常见的选择器
            selectors = [
                'a[href*="article"]',
                'a[href*="post"]',
                'a[href*="blog"]',
                'a[href*="insights"]',
                'a.article-link',
                'a.post-link',
                'a.title',
                'h2 a',
                'h3 a'
            ]

            for selector in selectors:
                elements = soup.select(selector)
                for element in elements:
                    href = element.get('href')
                    if href and self._is_article_link(href, source):
                        links.append(href)

            # 去重
            links = list(set(links))

        except Exception as e:
            logging.error(f"提取链接失败: {e}")

        return links

    def _fetch_article_from_url(self, url: str, source: Dict, source_type: str) -> Optional[Dict]:
        """从URL获取文章内容"""
        try:
            # 获取页面内容
            response = self._make_request(url)
            if not response:
                return None

            # 解析文章内容
            article = self._parse_article_content(response.text, url, source)

            if not article or not article.get('content'):
                return None

            # 检查时间范围
            if not self._check_article_time_range(article):
                return None

            # 检查字数要求
            if not self._check_word_count(article):
                return None

            # 添加基本信息
            article['url'] = url
            article['collected_at'] = datetime.now().isoformat()
            article['source_hash'] = self._generate_source_hash(url)

            return article

        except Exception as e:
            logging.error(f"获取文章内容失败 {url}: {e}")
            return None

    def _parse_article_content(self, html: str, url: str, source: Dict) -> Optional[Dict]:
        """解析文章内容"""
        try:
            soup = BeautifulSoup(html, 'html.parser')

            # 提取标题
            title = self._extract_title(soup)
            if not title:
                return None

            # 提取内容
            content = self._extract_content(soup)
            if not content:
                return None

            # 提取发布日期
            publish_date = self._extract_publish_date(soup)

            # 提取作者
            author = self._extract_author(soup)

            # 提取摘要
            summary = self._extract_summary(soup, content)

            article = {
                'title': title,
                'content': content,
                'publish_date': publish_date,
                'author': author,
                'summary': summary,
                'word_count': len(content)
            }

            return article

        except Exception as e:
            logging.error(f"解析文章内容失败: {e}")
            return None

    def _extract_title(self, soup: BeautifulSoup) -> Optional[str]:
        """提取文章标题"""
        # 尝试多种选择器
        selectors = [
            'h1.article-title',
            'h1.post-title',
            'h1.entry-title',
            'h1.title',
            'article h1',
            'main h1',
            'h1'
        ]

        for selector in selectors:
            element = soup.select_one(selector)
            if element and element.text.strip():
                return element.text.strip()

        # 尝试meta标签
        meta_title = soup.find('meta', property='og:title')
        if meta_title and meta_title.get('content'):
            return meta_title['content'].strip()

        meta_title = soup.find('meta', attrs={'name': 'title'})
        if meta_title and meta_title.get('content'):
            return meta_title['content'].strip()

        return None

    def _extract_content(self, soup: BeautifulSoup) -> Optional[str]:
        """提取文章正文"""
        # 尝试多种选择器
        selectors = [
            'article .article-content',
            'article .post-content',
            'article .entry-content',
            'div.article-content',
            'div.post-content',
            'div.entry-content',
            'article',
            'main'
        ]

        for selector in selectors:
            element = soup.select_one(selector)
            if element:
                # 清理内容
                self._clean_element(element)
                content = element.get_text(separator='\n', strip=True)
                if content and len(content) > 100:  # 至少100字符
                    return content

        return None

    def _clean_element(self, element):
        """清理HTML元素"""
        # 移除脚本和样式
        for tag in element.find_all(['script', 'style', 'iframe', 'nav', 'footer', 'aside']):
            tag.decompose()

        # 移除广告相关元素
        for tag in element.find_all(class_=re.compile(r'ad|advertisement|sponsor|promo')):
            tag.decompose()

    def _extract_publish_date(self, soup: BeautifulSoup) -> Optional[str]:
        """提取发布日期"""
        # 尝试多种选择器
        selectors = [
            'time.article-date',
            'time.post-date',
            'time.entry-date',
            'span.publish-date',
            'meta[property="article:published_time"]',
            'meta[name="publish_date"]',
            'meta[name="date"]'
        ]

        for selector in selectors:
            if selector.startswith('meta'):
                meta = soup.find('meta', property=selector.split('[')[1].split(']')[0])
                if meta and meta.get('content'):
                    return meta['content']
            else:
                element = soup.select_one(selector)
                if element:
                    date_text = element.get('datetime') or element.text
                    if date_text:
                        return date_text.strip()

        return None

    def _extract_author(self, soup: BeautifulSoup) -> Optional[str]:
        """提取作者"""
        selectors = [
            'span.author',
            'span.byline',
            'a.author',
            'meta[name="author"]',
            'meta[property="article:author"]'
        ]

        for selector in selectors:
            if selector.startswith('meta'):
                meta = soup.find('meta', property=selector.split('[')[1].split(']')[0])
                if meta and meta.get('content'):
                    return meta['content']
            else:
                element = soup.select_one(selector)
                if element and element.text.strip():
                    return element.text.strip()

        return None

    def _extract_summary(self, soup: BeautifulSoup, content: str) -> Optional[str]:
        """提取摘要"""
        # 尝试meta描述
        meta_desc = soup.find('meta', attrs={'name': 'description'})
        if meta_desc and meta_desc.get('content'):
            return meta_desc['content'].strip()

        meta_og = soup.find('meta', property='og:description')
        if meta_og and meta_og.get('content'):
            return meta_og['content'].strip()

        # 从内容中提取前200字符作为摘要
        if content:
            return content[:200] + '...' if len(content) > 200 else content

        return None

    def _make_request(self, url: str, retry_count: int = 0) -> Optional[requests.Response]:
        """发送HTTP请求，支持重试"""
        retry_config = self.network_config.get('retry', {})
        max_retries = retry_config.get('max_retries', 3)

        try:
            response = self.session.get(url)
            response.raise_for_status()

            # 检查内容类型
            content_type = response.headers.get('content-type', '')
            if 'text/html' not in content_type and 'application/xhtml+xml' not in content_type:
                logging.debug(f"跳过非HTML内容: {content_type}")
                return None

            return response

        except requests.exceptions.RequestException as e:
            if retry_count < max_retries:
                # 检查是否需要重试
                retry_status_codes = retry_config.get('retry_status_codes', [500, 502, 503, 504])
                if hasattr(e.response, 'status_code') and e.response.status_code in retry_status_codes:
                    delay = retry_config.get('retry_delay', 2)
                    time.sleep(delay * (2 ** retry_count))  # 指数退避
                    logging.info(f"重试请求 {url} (第{retry_count + 1}次)")
                    return self._make_request(url, retry_count + 1)

            logging.warning(f"请求失败 {url}: {e}")
            return None

    def _is_already_collected(self, url: str) -> bool:
        """检查URL是否已采集"""
        return url in self.collected_urls

    def _url_matches_pattern(self, url: str, pattern: str) -> bool:
        """检查URL是否匹配模式"""
        # 简单实现：检查URL是否包含模式中的关键部分
        pattern_parts = pattern.split('*')
        for part in pattern_parts:
            if part and part not in url:
                return False
        return True

    def _is_article_link(self, href: str, source: Dict) -> bool:
        """判断链接是否为文章链接"""
        # 排除非文章链接
        exclude_extensions = ['.pdf', '.jpg', '.png', '.gif', '.zip', '.exe']
        if any(href.lower().endswith(ext) for ext in exclude_extensions):
            return False

        # 排除锚点链接
        if href.startswith('#'):
            return False

        # 排除明显非文章链接
        exclude_keywords = ['about', 'contact', 'privacy', 'terms', 'login', 'register']
        if any(keyword in href.lower() for keyword in exclude_keywords):
            return False

        return True

    def _check_article_time_range(self, article: Dict) -> bool:
        """检查文章时间范围"""
        publish_date = article.get('publish_date')
        if not publish_date:
            # 如果没有发布日期，使用采集日期
            collected_at = article.get('collected_at')
            if collected_at:
                publish_date = collected_at

        if not publish_date:
            # 如果没有日期信息，默认通过
            return True

        try:
            # 尝试解析日期
            # 这里简化处理，实际应该根据各种日期格式进行解析
            time_config = self.collection_config.get('time_range', {})
            min_date_str = time_config.get('minimum_date', '2020-01-01')
            min_date = datetime.strptime(min_date_str, '%Y-%m-%d')

            # 这里简化日期解析，实际应该更复杂
            article_date = datetime.strptime(publish_date[:10], '%Y-%m-%d')

            return article_date >= min_date

        except Exception:
            # 日期解析失败，默认通过
            return True

    def _check_word_count(self, article: Dict) -> bool:
        """检查文章字数"""
        word_count = article.get('word_count', 0)
        content_filtering = self.collection_config.get('content_filtering', {})

        min_words = content_filtering.get('min_word_count', 800)
        max_words = content_filtering.get('max_word_count', 10000)

        return min_words <= word_count <= max_words

    def _filter_articles(self, articles: List[Dict]) -> List[Dict]:
        """过滤文章"""
        filtered = []
        content_filtering = self.collection_config.get('content_filtering', {})

        exclude_keywords = content_filtering.get('exclude_keywords', [])
        require_keywords = content_filtering.get('require_keywords', {})

        for article in articles:
            try:
                content = article.get('content', '').lower()
                title = article.get('title', '').lower()

                # 检查排除关键词
                if any(keyword.lower() in content or keyword.lower() in title
                      for keyword in exclude_keywords):
                    continue

                # 检查必需关键词（按分类）
                category_keywords = {}
                for cat, keywords in require_keywords.items():
                    category_keywords[cat] = keywords

                # 这里简化处理，后续分类器会进行准确分类
                # 暂时只检查是否包含任何领域的关键词
                has_relevant_keywords = False
                for cat, keywords in category_keywords.items():
                    if any(keyword in content or keyword in title for keyword in keywords):
                        has_relevant_keywords = True
                        break

                if not has_relevant_keywords and require_keywords:
                    continue

                filtered.append(article)

            except Exception as e:
                logging.warning(f"过滤文章失败: {e}")
                continue

        return filtered

    def _generate_source_hash(self, url: str) -> str:
        """生成信源哈希"""
        return hashlib.md5(url.encode('utf-8')).hexdigest()[:8]


# 导入os模块（在文件顶部应该导入，这里为完整代码添加）
import os