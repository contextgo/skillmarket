#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
咨询方案审计知识库自动收集系统
主要功能：从配置的信源自动采集优质内容，分类、评估质量后存入知识库
"""

import os
import sys
import yaml
import json
import logging
import datetime
import time
import threading
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import schedule
import signal
import traceback

# 添加项目根目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from scripts.auto_collector.collector import ContentCollector
from scripts.auto_collector.classifier import ContentClassifier
from scripts.auto_collector.quality_assessor import QualityAssessor
from scripts.auto_collector.storage_manager import StorageManager
from scripts.auto_collector.monitor import SystemMonitor


class KnowledgeBaseAutoCollector:
    """知识库自动收集系统主类"""

    def __init__(self, config_path: str = None):
        """
        初始化自动收集系统

        Args:
            config_path: 配置文件路径，如果为None则使用默认路径
        """
        self.config_path = config_path or os.path.join(
            os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
            "config", "sources.yaml"
        )

        # 初始化配置
        self.config = self._load_config()

        # 初始化日志
        self._setup_logging()

        # 初始化组件
        self.collector = None
        self.classifier = None
        self.quality_assessor = None
        self.storage_manager = None
        self.monitor = None

        # 运行状态
        self.is_running = False
        self.scheduler_thread = None

        logging.info("知识库自动收集系统初始化完成")

    def _load_config(self) -> Dict:
        """加载配置文件"""
        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)

            # 设置默认值
            config.setdefault('collection_strategy', {})
            config.setdefault('frequency_config', {})
            config.setdefault('storage_config', {})
            config.setdefault('classifier_config', {})
            config.setdefault('quality_assessment', {})
            config.setdefault('monitoring_config', {})
            config.setdefault('network_config', {})
            config.setdefault('security_config', {})

            return config
        except Exception as e:
            logging.error(f"加载配置文件失败: {e}")
            raise

    def _setup_logging(self):
        """设置日志系统"""
        log_config = self.config.get('monitoring_config', {}).get('logging', {})

        log_level = getattr(logging, log_config.get('level', 'INFO'))
        log_file = log_config.get('file', 'logs/auto-collector.log')

        # 确保日志目录存在
        log_dir = os.path.dirname(log_file)
        if log_dir:
            os.makedirs(log_dir, exist_ok=True)

        # 配置日志
        logging.basicConfig(
            level=log_level,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_file, encoding='utf-8'),
                logging.StreamHandler()
            ]
        )

    def initialize_components(self):
        """初始化所有组件"""
        try:
            # 初始化监控器
            self.monitor = SystemMonitor(self.config)

            # 初始化采集器
            self.collector = ContentCollector(self.config, self.monitor)

            # 初始化分类器
            self.classifier = ContentClassifier(self.config)

            # 初始化质量评估器
            self.quality_assessor = QualityAssessor(self.config)

            # 初始化存储管理器
            self.storage_manager = StorageManager(self.config)

            logging.info("所有组件初始化完成")
            return True

        except Exception as e:
            logging.error(f"初始化组件失败: {e}")
            return False

    def run_once(self, source_types: List[str] = None, force_update: bool = False):
        """
        执行一次完整的收集流程

        Args:
            source_types: 要采集的信源类型列表，如果为None则采集所有启用的信源
            force_update: 是否强制更新（忽略时间限制）
        """
        if not self.initialize_components():
            logging.error("组件初始化失败，无法执行收集")
            return False

        try:
            start_time = time.time()
            logging.info("开始执行知识库收集流程")

            # 1. 采集内容
            articles = self.collector.collect_articles(source_types, force_update)

            if not articles:
                logging.warning("本轮未采集到新内容")
                return True

            # 2. 分类和预处理
            classified_articles = []
            for article in articles:
                try:
                    # 分类
                    category = self.classifier.classify(article)
                    article['category'] = category

                    # 质量评估
                    quality_score, quality_grade = self.quality_assessor.assess(article)
                    article['quality_score'] = quality_score
                    article['quality_grade'] = quality_grade

                    # 过滤低质量内容
                    min_score = self.config['quality_assessment'].get('quality_thresholds', {}).get('min_quality_score', 0.6)
                    if quality_score >= min_score:
                        classified_articles.append(article)
                        logging.info(f"文章分类: {category}, 质量: {quality_grade}({quality_score:.2f})")
                    else:
                        logging.debug(f"过滤低质量文章: {article.get('title', 'Unknown')}, 质量分: {quality_score:.2f}")

                except Exception as e:
                    logging.error(f"处理文章失败: {e}")
                    continue

            if not classified_articles:
                logging.warning("所有文章都被过滤，无合格内容")
                return True

            # 3. 存储到知识库
            saved_count = self.storage_manager.save_articles(classified_articles)

            # 4. 更新元数据
            metadata_updated = self.storage_manager.update_metadata(classified_articles)

            # 5. 清理临时文件
            self.storage_manager.cleanup()

            end_time = time.time()
            duration = end_time - start_time

            logging.info(f"收集流程完成: 采集{len(articles)}篇，保存{saved_count}篇，耗时{duration:.1f}秒")

            # 更新监控指标
            if self.monitor:
                self.monitor.update_metrics({
                    'last_run_time': datetime.datetime.now().isoformat(),
                    'articles_collected': len(articles),
                    'articles_saved': saved_count,
                    'run_duration': duration,
                    'success': True
                })

            return True

        except Exception as e:
            logging.error(f"收集流程执行失败: {e}")
            logging.error(traceback.format_exc())

            if self.monitor:
                self.monitor.update_metrics({
                    'last_run_time': datetime.datetime.now().isoformat(),
                    'success': False,
                    'error': str(e)
                })

            return False

    def start_scheduler(self):
        """启动定时任务调度器"""
        if self.is_running:
            logging.warning("调度器已在运行中")
            return

        frequency_config = self.config.get('frequency_config', {})
        schedules = frequency_config.get('schedules', {})

        # 配置定时任务
        for freq, schedule_config in schedules.items():
            sources = schedule_config.get('sources', [])
            if not sources:
                continue

            if freq == 'daily':
                time_str = schedule_config.get('time', '02:00')
                schedule.every().day.at(time_str).do(self._run_scheduled_task, sources, freq)
                logging.info(f"已安排每日任务: {time_str}, 信源: {sources}")

            elif freq == 'weekly':
                time_str = schedule_config.get('time', '03:00')
                day_str = schedule_config.get('day_of_week', 'sunday')
                getattr(schedule.every(), day_str).at(time_str).do(self._run_scheduled_task, sources, freq)
                logging.info(f"已安排每周任务: {day_str} {time_str}, 信源: {sources}")

            elif freq == 'monthly':
                time_str = schedule_config.get('time', '04:00')
                day = schedule_config.get('day_of_month', 1)
                # schedule库的每月调度：每月指定日期的指定时间
                schedule.every().month.on(day).at(time_str).do(self._run_scheduled_task, sources, freq)
                logging.info(f"已安排每月任务: 第{day}天 {time_str}, 信源: {sources}")

            elif freq == 'quarterly':
                time_str = schedule_config.get('time', '05:00')
                months = schedule_config.get('months', [1, 4, 7, 10])
                day_of_month = schedule_config.get('day_of_month', 1)

                # 创建季度调度函数
                def quarterly_job(source_types, target_months, day_of_month):
                    """季度任务执行函数"""
                    import datetime
                    now = datetime.datetime.now()

                    # 检查当前月份是否在目标月份列表中
                    if now.month in target_months:
                        # 检查是否是当月的指定日期
                        if now.day == day_of_month:
                            logging.info(f"执行季度任务，当前月份 {now.month} 在季度月份列表中")
                            return self._run_scheduled_task(source_types, 'quarterly')
                        else:
                            logging.debug(f"季度任务跳过：今天是 {now.day} 号，但季度任务在每月 {day_of_month} 号执行")
                    else:
                        logging.debug(f"季度任务跳过：当前月份 {now.month} 不在季度月份列表 {target_months} 中")

                # 安排每日检查，但只在季度月份执行
                schedule.every().day.at(time_str).do(quarterly_job, sources, months, day_of_month)
                logging.info(f"已安排季度任务: 月份{months} 第{day_of_month}天 {time_str}, 信源: {sources}")

        # 启动调度器线程
        self.is_running = True
        self.scheduler_thread = threading.Thread(target=self._scheduler_loop, daemon=True)
        self.scheduler_thread.start()

        logging.info("定时任务调度器已启动")

    def _run_scheduled_task(self, source_types: List[str], frequency: str):
        """执行定时任务"""
        logging.info(f"开始执行{frequency}定时任务，信源类型: {source_types}")
        try:
            success = self.run_once(source_types)
            if success:
                logging.info(f"{frequency}定时任务执行成功")
            else:
                logging.error(f"{frequency}定时任务执行失败")
        except Exception as e:
            logging.error(f"定时任务执行异常: {e}")
            logging.error(traceback.format_exc())

    def _scheduler_loop(self):
        """调度器主循环"""
        logging.info("调度器主循环启动")
        while self.is_running:
            try:
                schedule.run_pending()
                time.sleep(60)  # 每分钟检查一次
            except Exception as e:
                logging.error(f"调度器循环异常: {e}")
                time.sleep(300)  # 出错后等待5分钟

    def stop(self):
        """停止收集系统"""
        logging.info("正在停止收集系统...")
        self.is_running = False

        if self.scheduler_thread:
            self.scheduler_thread.join(timeout=10)

        logging.info("收集系统已停止")

    def run_interactive(self):
        """交互式运行模式"""
        print("=" * 60)
        print("咨询方案审计知识库自动收集系统")
        print("=" * 60)

        while True:
            print("\n请选择操作:")
            print("1. 执行一次完整收集（所有信源）")
            print("2. 收集指定类型信源")
            print("3. 查看系统状态")
            print("4. 启动定时任务")
            print("5. 停止定时任务")
            print("6. 退出")

            choice = input("请输入选项 (1-6): ").strip()

            if choice == "1":
                print("开始执行完整收集...")
                success = self.run_once()
                if success:
                    print("收集完成")
                else:
                    print("收集失败")

            elif choice == "2":
                print("可用的信源类型:")
                source_types = list(self.config.get('sources', {}).keys())
                for i, st in enumerate(source_types, 1):
                    print(f"  {i}. {st}")

                try:
                    selection = input("请输入信源类型编号（多个用逗号分隔）: ").strip()
                    indices = [int(idx.strip()) - 1 for idx in selection.split(',')]
                    selected_types = [source_types[i] for i in indices if 0 <= i < len(source_types)]

                    if selected_types:
                        print(f"开始收集信源: {selected_types}")
                        success = self.run_once(selected_types)
                        if success:
                            print("收集完成")
                        else:
                            print("收集失败")
                    else:
                        print("未选择有效信源")
                except Exception as e:
                    print(f"输入错误: {e}")

            elif choice == "3":
                self.show_status()

            elif choice == "4":
                if not self.is_running:
                    self.start_scheduler()
                    print("定时任务已启动")
                else:
                    print("定时任务已在运行中")

            elif choice == "5":
                if self.is_running:
                    self.stop()
                    print("定时任务已停止")
                else:
                    print("定时任务未运行")

            elif choice == "6":
                if self.is_running:
                    self.stop()
                print("退出系统")
                break

            else:
                print("无效选项，请重新选择")

    def show_status(self):
        """显示系统状态"""
        print("\n" + "=" * 60)
        print("系统状态")
        print("=" * 60)

        # 基本信息
        print(f"配置文件: {self.config_path}")
        print(f"调度器状态: {'运行中' if self.is_running else '已停止'}")

        # 信源状态
        sources = self.config.get('sources', {})
        print(f"\n信源配置 ({len(sources)}种类型):")
        for source_type, source_config in sources.items():
            enabled = source_config.get('enabled', False)
            freq = source_config.get('update_frequency', 'unknown')
            print(f"  {source_type}: {'启用' if enabled else '禁用'}, 频率: {freq}")

        # 存储信息
        if self.storage_manager:
            stats = self.storage_manager.get_statistics()
            print(f"\n知识库统计:")
            print(f"  总文章数: {stats.get('total_articles', 0)}")
            print(f"  按分类分布: {stats.get('category_distribution', {})}")

        print("=" * 60)


def signal_handler(signum, frame):
    """信号处理函数"""
    print("\n接收到终止信号，正在关闭系统...")
    sys.exit(0)


def main():
    """主函数"""
    # 注册信号处理
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    # 解析命令行参数
    import argparse
    parser = argparse.ArgumentParser(description='咨询方案审计知识库自动收集系统')
    parser.add_argument('--config', '-c', help='配置文件路径')
    parser.add_argument('--mode', '-m', choices=['once', 'scheduler', 'interactive'],
                       default='interactive', help='运行模式')
    parser.add_argument('--sources', '-s', help='指定信源类型，多个用逗号分隔')
    parser.add_argument('--force', '-f', action='store_true', help='强制更新')

    args = parser.parse_args()

    # 创建收集器实例
    try:
        collector = KnowledgeBaseAutoCollector(args.config)
    except Exception as e:
        print(f"初始化收集器失败: {e}")
        sys.exit(1)

    # 根据模式运行
    if args.mode == 'once':
        # 执行一次收集
        source_types = args.sources.split(',') if args.sources else None
        success = collector.run_once(source_types, args.force)
        sys.exit(0 if success else 1)

    elif args.mode == 'scheduler':
        # 启动定时任务
        collector.start_scheduler()

        # 保持主线程运行
        try:
            while True:
                time.sleep(3600)  # 每小时检查一次
        except KeyboardInterrupt:
            print("\n正在关闭调度器...")
            collector.stop()

    elif args.mode == 'interactive':
        # 交互式模式
        collector.run_interactive()


if __name__ == "__main__":
    main()