#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
系统监控模块
负责监控自动收集系统的运行状态、性能指标和错误处理
"""

import logging
import datetime
import json
import psutil
import time
from pathlib import Path
from typing import Dict, List, Optional, Any
import threading


class SystemMonitor:
    """系统监控器"""

    def __init__(self, config: Dict):
        """
        初始化监控器

        Args:
            config: 系统配置
        """
        self.config = config
        self.monitoring_config = config.get('monitoring_config', {})
        self.performance_config = self.monitoring_config.get('performance', {})

        # 监控数据
        self.metrics = {
            'start_time': datetime.datetime.now().isoformat(),
            'total_runs': 0,
            'successful_runs': 0,
            'failed_runs': 0,
            'total_articles_collected': 0,
            'total_articles_saved': 0,
            'last_run_time': None,
            'last_run_status': None,
            'error_history': [],
            'performance_metrics': []
        }

        # 当前运行状态
        self.current_run = {
            'start_time': None,
            'end_time': None,
            'status': None,
            'articles_collected': 0,
            'articles_saved': 0,
            'errors': []
        }

        # 性能监控线程
        self.performance_thread = None
        self.is_monitoring = False

        # 初始化日志
        self.logger = logging.getLogger(__name__)

        # 确保日志目录存在
        self._setup_logging()

        self.logger.info("系统监控器初始化完成")

    def _setup_logging(self):
        """设置监控专用日志"""
        log_config = self.monitoring_config.get('logging', {})
        if log_config.get('enable_monitoring_log', False):
            log_file = log_config.get('monitoring_file', 'logs/monitor.log')
            log_dir = Path(log_file).parent
            if log_dir:
                log_dir.mkdir(parents=True, exist_ok=True)

    def start_monitoring(self):
        """开始性能监控"""
        if self.is_monitoring:
            self.logger.warning("性能监控已在运行中")
            return

        if not self.performance_config.get('enable_monitoring', False):
            self.logger.info("性能监控未启用")
            return

        self.is_monitoring = True
        self.performance_thread = threading.Thread(
            target=self._monitoring_loop,
            daemon=True
        )
        self.performance_thread.start()

        self.logger.info("性能监控已启动")

    def stop_monitoring(self):
        """停止性能监控"""
        self.is_monitoring = False
        if self.performance_thread:
            self.performance_thread.join(timeout=5)

        self.logger.info("性能监控已停止")

    def _monitoring_loop(self):
        """监控主循环"""
        collect_interval = self.performance_config.get('collect_interval', 300)

        while self.is_monitoring:
            try:
                metrics = self._collect_performance_metrics()
                self.metrics['performance_metrics'].append(metrics)

                # 限制历史记录长度
                max_history = self.performance_config.get('max_history', 1000)
                if len(self.metrics['performance_metrics']) > max_history:
                    self.metrics['performance_metrics'] = self.metrics['performance_metrics'][-max_history:]

                # 保存到文件
                self._save_metrics_to_file()

            except Exception as e:
                self.logger.error(f"收集性能指标失败: {e}")

            time.sleep(collect_interval)

    def _collect_performance_metrics(self) -> Dict[str, Any]:
        """收集性能指标"""
        metrics = {
            'timestamp': datetime.datetime.now().isoformat(),
            'cpu_percent': psutil.cpu_percent(interval=1),
            'memory_percent': psutil.virtual_memory().percent,
            'disk_usage': psutil.disk_usage('/').percent,
            'network_io': self._get_network_io(),
            'process_info': self._get_process_info()
        }

        # 收集系统运行指标
        metrics.update({
            'total_runs': self.metrics['total_runs'],
            'successful_runs': self.metrics['successful_runs'],
            'failed_runs': self.metrics['failed_runs'],
            'total_articles': self.metrics['total_articles_collected']
        })

        return metrics

    def _get_network_io(self) -> Dict[str, float]:
        """获取网络IO信息"""
        try:
            net_io = psutil.net_io_counters()
            return {
                'bytes_sent': net_io.bytes_sent,
                'bytes_recv': net_io.bytes_recv,
                'packets_sent': net_io.packets_sent,
                'packets_recv': net_io.packets_recv
            }
        except Exception:
            return {}

    def _get_process_info(self) -> Dict[str, Any]:
        """获取进程信息"""
        try:
            process = psutil.Process()
            with process.oneshot():
                return {
                    'pid': process.pid,
                    'name': process.name(),
                    'status': process.status(),
                    'memory_rss': process.memory_info().rss,
                    'memory_vms': process.memory_info().vms,
                    'cpu_times': process.cpu_times()._asdict(),
                    'num_threads': process.num_threads(),
                    'connections': len(process.connections())
                }
        except Exception:
            return {}

    def _save_metrics_to_file(self):
        """保存指标到文件"""
        try:
            metrics_file = self.performance_config.get('metrics_file', 'logs/metrics.json')
            metrics_dir = Path(metrics_file).parent
            if metrics_dir:
                metrics_dir.mkdir(parents=True, exist_ok=True)

            with open(metrics_file, 'w', encoding='utf-8') as f:
                json.dump(self.metrics, f, indent=2, ensure_ascii=False)

            self.logger.debug(f"性能指标已保存到 {metrics_file}")
        except Exception as e:
            self.logger.error(f"保存性能指标失败: {e}")

    def start_run(self):
        """开始新的运行"""
        self.current_run = {
            'start_time': datetime.datetime.now().isoformat(),
            'end_time': None,
            'status': 'running',
            'articles_collected': 0,
            'articles_saved': 0,
            'errors': [],
            'warnings': []
        }

        self.metrics['total_runs'] += 1
        self.logger.info("开始新的收集运行")

    def end_run(self, success: bool, **kwargs):
        """结束当前运行"""
        self.current_run['end_time'] = datetime.datetime.now().isoformat()
        self.current_run['status'] = 'success' if success else 'failed'

        # 更新运行统计信息
        if success:
            self.metrics['successful_runs'] += 1
        else:
            self.metrics['failed_runs'] += 1

        # 更新文章统计
        articles_collected = kwargs.get('articles_collected', 0)
        articles_saved = kwargs.get('articles_saved', 0)

        self.current_run['articles_collected'] = articles_collected
        self.current_run['articles_saved'] = articles_saved

        self.metrics['total_articles_collected'] += articles_collected
        self.metrics['total_articles_saved'] += articles_saved

        # 更新最后一次运行信息
        self.metrics['last_run_time'] = self.current_run['start_time']
        self.metrics['last_run_status'] = self.current_run['status']

        # 记录错误历史
        errors = kwargs.get('errors', [])
        if errors:
            self.current_run['errors'].extend(errors)
            self.metrics['error_history'].extend(errors)

            # 限制错误历史长度
            max_error_history = 100
            if len(self.metrics['error_history']) > max_error_history:
                self.metrics['error_history'] = self.metrics['error_history'][-max_error_history:]

        # 检查告警条件
        self._check_alerts()

        # 保存指标
        self._save_metrics_to_file()

        status_str = '成功' if success else '失败'
        self.logger.info(f"收集运行结束: {status_str}, 采集{articles_collected}篇, 保存{articles_saved}篇")

    def update_metrics(self, metrics: Dict[str, Any]):
        """
        更新监控指标

        Args:
            metrics: 要更新的指标
        """
        if not metrics:
            return

        # 更新当前运行指标
        for key, value in metrics.items():
            if key in self.current_run:
                self.current_run[key] = value

        # 更新全局指标
        for key, value in metrics.items():
            if key in self.metrics:
                if isinstance(self.metrics[key], (int, float)) and isinstance(value, (int, float)):
                    self.metrics[key] += value
                else:
                    self.metrics[key] = value

        self.logger.debug(f"更新指标: {metrics}")

    def _check_alerts(self):
        """检查告警条件"""
        alert_config = self.monitoring_config.get('alerts', {})
        if not alert_config.get('enable_alerts', False):
            return

        conditions = alert_config.get('alert_conditions', [])

        for condition in conditions:
            try:
                # 这里简化处理，实际可以解析condition字符串
                # 例如: "error_count > 10"
                pass
            except Exception as e:
                self.logger.error(f"检查告警条件失败: {e}")

    def record_error(self, error_type: str, error_message: str, details: Dict = None):
        """
        记录错误

        Args:
            error_type: 错误类型
            error_message: 错误消息
            details: 错误详情
        """
        error_entry = {
            'timestamp': datetime.datetime.now().isoformat(),
            'type': error_type,
            'message': error_message,
            'details': details or {}
        }

        self.current_run['errors'].append(error_entry)
        self.metrics['error_history'].append(error_entry)

        self.logger.error(f"{error_type}: {error_message}")

    def record_warning(self, warning_type: str, warning_message: str, details: Dict = None):
        """
        记录警告

        Args:
            warning_type: 警告类型
            warning_message: 警告消息
            details: 警告详情
        """
        warning_entry = {
            'timestamp': datetime.datetime.now().isoformat(),
            'type': warning_type,
            'message': warning_message,
            'details': details or {}
        }

        self.current_run['warnings'].append(warning_entry)

        self.logger.warning(f"{warning_type}: {warning_message}")

    def get_system_status(self) -> Dict[str, Any]:
        """
        获取系统状态

        Returns:
            系统状态字典
        """
        status = {
            'monitoring': {
                'is_monitoring': self.is_monitoring,
                'total_runs': self.metrics['total_runs'],
                'successful_runs': self.metrics['successful_runs'],
                'failed_runs': self.metrics['failed_runs'],
                'success_rate': self._calculate_success_rate(),
                'last_run': {
                    'time': self.metrics['last_run_time'],
                    'status': self.metrics['last_run_status']
                }
            },
            'performance': self._get_current_performance(),
            'current_run': self.current_run.copy(),
            'timestamp': datetime.datetime.now().isoformat()
        }

        return status

    def _calculate_success_rate(self) -> float:
        """计算成功率"""
        total_runs = self.metrics['total_runs']
        successful_runs = self.metrics['successful_runs']

        if total_runs == 0:
            return 0.0

        return successful_runs / total_runs

    def _get_current_performance(self) -> Dict[str, Any]:
        """获取当前性能指标"""
        try:
            return {
                'cpu_percent': psutil.cpu_percent(interval=0.1),
                'memory_percent': psutil.virtual_memory().percent,
                'disk_usage': psutil.disk_usage('/').percent,
                'process_memory': psutil.Process().memory_info().rss
            }
        except Exception as e:
            self.logger.error(f"获取性能指标失败: {e}")
            return {}

    def get_statistics(self) -> Dict[str, Any]:
        """
        获取统计信息

        Returns:
            统计信息字典
        """
        return {
            'total_runs': self.metrics['total_runs'],
            'successful_runs': self.metrics['successful_runs'],
            'failed_runs': self.metrics['failed_runs'],
            'success_rate': self._calculate_success_rate(),
            'total_articles_collected': self.metrics['total_articles_collected'],
            'total_articles_saved': self.metrics['total_articles_saved'],
            'avg_articles_per_run': self._calculate_avg_articles(),
            'error_count': len(self.metrics['error_history']),
            'last_24h_runs': self._get_recent_runs(24),
            'last_7d_runs': self._get_recent_runs(7 * 24)
        }

    def _calculate_avg_articles(self) -> float:
        """计算平均每运行采集文章数"""
        total_runs = self.metrics['total_runs']
        total_articles = self.metrics['total_articles_collected']

        if total_runs == 0:
            return 0.0

        return total_articles / total_runs

    def _get_recent_runs(self, hours: int) -> Dict[str, int]:
        """获取最近N小时内的运行统计"""
        recent_runs = {
            'total': 0,
            'successful': 0,
            'failed': 0,
            'articles_collected': 0
        }

        # 这里简化处理，实际需要根据时间戳过滤
        # 在当前实现中，返回总的统计

        return recent_runs

    def reset_metrics(self):
        """重置监控指标"""
        self.metrics = {
            'start_time': datetime.datetime.now().isoformat(),
            'total_runs': 0,
            'successful_runs': 0,
            'failed_runs': 0,
            'total_articles_collected': 0,
            'total_articles_saved': 0,
            'last_run_time': None,
            'last_run_status': None,
            'error_history': [],
            'performance_metrics': []
        }

        self.current_run = {
            'start_time': None,
            'end_time': None,
            'status': None,
            'articles_collected': 0,
            'articles_saved': 0,
            'errors': []
        }

        self.logger.info("监控指标已重置")

    def generate_report(self) -> Dict[str, Any]:
        """
        生成监控报告

        Returns:
            监控报告字典
        """
        report = {
            'system_status': self.get_system_status(),
            'statistics': self.get_statistics(),
            'performance_summary': self._generate_performance_summary(),
            'error_summary': self._generate_error_summary(),
            'recommendations': self._generate_recommendations()
        }

        return report

    def _generate_performance_summary(self) -> Dict[str, Any]:
        """生成性能摘要"""
        if not self.metrics['performance_metrics']:
            return {}

        # 计算平均性能指标
        metrics_list = self.metrics['performance_metrics']
        cpu_values = [m.get('cpu_percent', 0) for m in metrics_list]
        memory_values = [m.get('memory_percent', 0) for m in metrics_list]

        return {
            'avg_cpu_percent': sum(cpu_values) / len(cpu_values) if cpu_values else 0,
            'avg_memory_percent': sum(memory_values) / len(memory_values) if memory_values else 0,
            'sample_count': len(metrics_list)
        }

    def _generate_error_summary(self) -> Dict[str, Any]:
        """生成错误摘要"""
        error_history = self.metrics['error_history']

        if not error_history:
            return {'total_errors': 0, 'error_types': {}}

        error_types = {}
        for error in error_history:
            error_type = error.get('type', 'unknown')
            error_types[error_type] = error_types.get(error_type, 0) + 1

        return {
            'total_errors': len(error_history),
            'error_types': error_types,
            'recent_errors': error_history[-10:]  # 最近10个错误
        }

    def _generate_recommendations(self) -> List[str]:
        """生成改进建议"""
        recommendations = []

        # 基于错误率的建议
        total_runs = self.metrics['total_runs']
        failed_runs = self.metrics['failed_runs']

        if total_runs > 10 and failed_runs / total_runs > 0.3:
            recommendations.append("失败率较高(>30%)，建议检查网络连接和信源配置")

        # 基于文章采集量的建议
        avg_articles = self._calculate_avg_articles()
        if total_runs > 5 and avg_articles < 5:
            recommendations.append("平均每运行采集文章数较低(<5)，建议增加信源或调整采集策略")

        # 基于性能的建议
        if self.metrics['performance_metrics']:
            cpu_values = [m.get('cpu_percent', 0) for m in self.metrics['performance_metrics']]
            avg_cpu = sum(cpu_values) / len(cpu_values)

            if avg_cpu > 80:
                recommendations.append("CPU使用率较高(>80%)，建议减少并发请求数")

        return recommendations

    def cleanup(self):
        """清理监控资源"""
        self.stop_monitoring()
        self._save_metrics_to_file()
        self.logger.info("监控资源清理完成")