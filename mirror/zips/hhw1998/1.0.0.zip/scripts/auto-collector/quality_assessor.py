#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
质量评估器模块
负责评估文章的质量，包括内容深度、数据支撑、方法论、原创性等维度
"""

import re
import math
import logging
from typing import Dict, List, Tuple, Optional
from datetime import datetime
import jieba.analyse


class QualityAssessor:
    """质量评估器"""

    def __init__(self, config: Dict):
        """
        初始化质量评估器

        Args:
            config: 系统配置
        """
        self.config = config
        self.quality_config = config.get('quality_assessment', {})
        self.dimension_weights = self.quality_config.get('dimension_weights', {})
        self.scoring_rules = self.quality_config.get('scoring_rules', {})
        self.quality_grades = self.quality_config.get('quality_grades', {})

        # 设置默认值
        self._set_defaults()

        logging.info("质量评估器初始化完成")

    def _set_defaults(self):
        """设置默认值"""
        # 默认维度权重
        if not self.dimension_weights:
            self.dimension_weights = {
                'content_depth': 0.25,  # 内容深度
                'data_support': 0.20,   # 数据支撑
                'methodology': 0.20,    # 方法论
                'originality': 0.15,    # 原创性
                'readability': 0.10,    # 可读性
                'source_authority': 0.10  # 信源权威性
            }

        # 默认质量等级阈值
        if not self.quality_grades:
            self.quality_grades = {
                'A+': 0.9,  # 卓越
                'A': 0.8,   # 优秀
                'B': 0.7,   # 良好
                'C': 0.6,   # 合格
                'D': 0.0    # 不合格
            }

    def assess(self, article: Dict) -> Tuple[float, str]:
        """
        评估文章质量

        Args:
            article: 文章数据

        Returns:
            (质量得分0-1, 质量等级)
        """
        try:
            # 各维度评估
            dimension_scores = self._assess_dimensions(article)

            # 计算综合得分
            total_score = self._calculate_total_score(dimension_scores)

            # 确定质量等级
            quality_grade = self._determine_quality_grade(total_score)

            # 记录评估详情
            article['quality_assessment'] = {
                'dimension_scores': dimension_scores,
                'total_score': total_score,
                'quality_grade': quality_grade,
                'assessed_at': datetime.now().isoformat()
            }

            logging.debug(f"质量评估: 得分{total_score:.3f}, 等级{quality_grade}")
            return total_score, quality_grade

        except Exception as e:
            logging.error(f"质量评估失败: {e}")
            return 0.0, 'D'

    def _assess_dimensions(self, article: Dict) -> Dict[str, float]:
        """评估各维度得分"""
        dimension_scores = {}

        # 1. 内容深度
        dimension_scores['content_depth'] = self._assess_content_depth(article)

        # 2. 数据支撑
        dimension_scores['data_support'] = self._assess_data_support(article)

        # 3. 方法论
        dimension_scores['methodology'] = self._assess_methodology(article)

        # 4. 原创性
        dimension_scores['originality'] = self._assess_originality(article)

        # 5. 可读性
        dimension_scores['readability'] = self._assess_readability(article)

        # 6. 信源权威性
        dimension_scores['source_authority'] = self._assess_source_authority(article)

        return dimension_scores

    def _assess_content_depth(self, article: Dict) -> float:
        """评估内容深度"""
        content = article.get('content', '')
        title = article.get('title', '')

        if not content:
            return 0.0

        score = 0.0

        # 1. 文章长度
        word_count = len(content)
        if word_count >= 3000:
            score += 0.3  # 长篇深度文章
        elif word_count >= 1500:
            score += 0.2
        elif word_count >= 800:
            score += 0.1

        # 2. 段落结构
        paragraphs = [p.strip() for p in content.split('\n') if p.strip()]
        if len(paragraphs) >= 10:
            score += 0.2  # 结构完整

        # 3. 小标题使用
        heading_patterns = [r'^#+ .+', r'^【.+】', r'^（.+）', r'^\d+\.\s+.+']
        heading_count = 0
        for para in paragraphs:
            for pattern in heading_patterns:
                if re.match(pattern, para):
                    heading_count += 1
                    break

        if heading_count >= 3:
            score += 0.2  # 结构清晰

        # 4. 分析深度关键词
        depth_keywords = [
            '分析', '研究', '探讨', '思考', '反思', '见解', '观点',
            '原因', '因素', '影响', '结果', '结论', '建议', '对策',
            '比较', '对比', '差异', '优势', '劣势', '机会', '挑战'
        ]

        depth_keyword_count = sum(1 for keyword in depth_keywords if keyword in content)
        if depth_keyword_count >= 5:
            score += 0.3
        elif depth_keyword_count >= 3:
            score += 0.2
        elif depth_keyword_count >= 1:
            score += 0.1

        return min(score, 1.0)

    def _assess_data_support(self, article: Dict) -> float:
        """评估数据支撑"""
        content = article.get('content', '')

        if not content:
            return 0.0

        score = 0.0

        # 1. 数据引用数量
        # 查找数字模式
        number_patterns = [
            r'\d+%',  # 百分比
            r'\d+\.\d+%',  # 小数百分比
            r'\d+亿元', r'\d+万元', r'\d+元',  # 金额
            r'\d+人', r'\d+名', r'\d+位',  # 人数
            r'\d+家', r'\d+个', r'\d+项',  # 数量
            r'\d+年', r'\d+月', r'\d+日',  # 时间
        ]

        data_count = 0
        for pattern in number_patterns:
            matches = re.findall(pattern, content)
            data_count += len(matches)

        if data_count >= 10:
            score += 0.4
        elif data_count >= 5:
            score += 0.3
        elif data_count >= 3:
            score += 0.2
        elif data_count >= 1:
            score += 0.1

        # 2. 数据来源引用
        source_keywords = [
            '数据显示', '据统计', '根据调查', '研究报告',
            '数据表明', '调查显示', '统计表明', '研究表明',
            '引用', '参考', '来源', '依据'
        ]

        source_count = sum(1 for keyword in source_keywords if keyword in content)
        if source_count >= 3:
            score += 0.3
        elif source_count >= 1:
            score += 0.1

        # 3. 图表引用
        chart_keywords = ['图表', '图\d+', '表\d+', '柱状图', '折线图', '饼图', '示意图']
        chart_count = 0
        for keyword in chart_keywords:
            if re.search(keyword, content):
                chart_count += 1

        if chart_count >= 2:
            score += 0.2
        elif chart_count >= 1:
            score += 0.1

        # 4. 案例引用
        case_keywords = ['案例', '例子', '实例', '事例', '典型案例']
        case_count = sum(1 for keyword in case_keywords if keyword in content)
        if case_count >= 2:
            score += 0.1

        return min(score, 1.0)

    def _assess_methodology(self, article: Dict) -> float:
        """评估方法论"""
        content = article.get('content', '')

        if not content:
            return 0.0

        score = 0.0

        # 1. 方法论关键词
        methodology_keywords = [
            '方法论', '框架', '模型', '理论', '原则', '方法',
            '步骤', '流程', '过程', '机制', '体系', '系统',
            '工具', '技术', '技巧', '策略', '方案', '计划'
        ]

        methodology_count = sum(1 for keyword in methodology_keywords if keyword in content)
        if methodology_count >= 5:
            score += 0.4
        elif methodology_count >= 3:
            score += 0.3
        elif methodology_count >= 1:
            score += 0.1

        # 2. 知名方法论引用
        famous_methodologies = [
            'SWOT分析', 'PEST分析', '波特五力', '波士顿矩阵', '麦肯锡7S',
            '平衡计分卡', 'PDCA循环', 'SMART原则', 'KPI', 'OKR',
            '六西格玛', '精益生产', '敏捷开发', '设计思维', '蓝海战略'
        ]

        famous_count = sum(1 for method in famous_methodologies if method in content)
        if famous_count >= 2:
            score += 0.3
        elif famous_count >= 1:
            score += 0.2

        # 3. 逻辑结构
        logic_keywords = [
            '首先', '其次', '然后', '最后', '第一', '第二', '第三',
            '一方面', '另一方面', '此外', '另外', '同时', '然而',
            '但是', '因此', '所以', '因而', '于是', '总结', '综上所述'
        ]

        logic_count = sum(1 for keyword in logic_keywords if keyword in content)
        if logic_count >= 5:
            score += 0.2
        elif logic_count >= 3:
            score += 0.1

        # 4. 分析框架完整性
        framework_patterns = [
            r'背景.*分析.*结论',
            r'问题.*原因.*对策',
            r'现状.*问题.*建议',
            r'理论.*实践.*案例'
        ]

        for pattern in framework_patterns:
            if re.search(pattern, content):
                score += 0.1
                break

        return min(score, 1.0)

    def _assess_originality(self, article: Dict) -> float:
        """评估原创性"""
        content = article.get('content', '')

        if not content:
            return 0.0

        score = 0.0

        # 1. 个人观点表达
        personal_keywords = [
            '我认为', '我觉得', '在我看来', '个人认为',
            '笔者', '本文', '本报告', '本研究',
            '我们的观点', '我们的研究发现', '我们建议'
        ]

        personal_count = sum(1 for keyword in personal_keywords if keyword in content)
        if personal_count >= 3:
            score += 0.3
        elif personal_count >= 1:
            score += 0.1

        # 2. 独特见解关键词
        insight_keywords = [
            '创新', '突破', '独特', '新颖', '首创',
            '首次', '领先', '前瞻', '预见', '预测',
            '趋势', '未来', '变革', '转型', '升级'
        ]

        insight_count = sum(1 for keyword in insight_keywords if keyword in content)
        if insight_count >= 3:
            score += 0.2
        elif insight_count >= 1:
            score += 0.1

        # 3. 案例独特性
        # 检查是否包含具体公司、具体人名等详细信息
        company_pattern = r'[A-Za-z0-9\u4e00-\u9fa5]+(公司|集团|企业|厂)'
        person_pattern = r'[张王李赵刘陈杨黄周吴徐孙胡朱高林何郭马罗梁宋郑谢韩唐冯于董萧程曹袁邓许傅沈曾彭吕苏卢蒋蔡贾丁魏薛叶阎余潘杜戴夏钟汪田任姜范方石姚谭廖邹熊金陆郝孔白崔康毛邱秦江史顾侯邵孟龙万段雷钱汤尹黎易常武乔贺赖龚文]'

        company_matches = re.findall(company_pattern, content)
        person_matches = re.findall(person_pattern, content)

        if len(company_matches) >= 3 or len(person_matches) >= 2:
            score += 0.3  # 包含具体案例
        elif len(company_matches) >= 1 or len(person_matches) >= 1:
            score += 0.1

        # 4. 引用比例（简化评估）
        # 如果文章中有大量引用标记，可能原创性较低
        quote_keywords = ['据', '引用', '摘自', '来源', '参考']
        quote_count = sum(1 for keyword in quote_keywords if keyword in content)

        if quote_count >= 5:
            score -= 0.2  # 过多引用可能降低原创性
        elif quote_count >= 3:
            score -= 0.1

        # 确保分数在合理范围
        score = max(0.0, min(score, 1.0))

        return score

    def _assess_readability(self, article: Dict) -> float:
        """评估可读性"""
        content = article.get('content', '')

        if not content:
            return 0.0

        score = 0.0

        # 1. 平均句长
        sentences = re.split(r'[。！？!?]', content)
        sentences = [s.strip() for s in sentences if s.strip()]

        if sentences:
            total_chars = sum(len(s) for s in sentences)
            avg_sentence_length = total_chars / len(sentences)

            # 理想句长：15-25字
            if 15 <= avg_sentence_length <= 25:
                score += 0.3
            elif 10 <= avg_sentence_length <= 30:
                score += 0.2
            elif 5 <= avg_sentence_length <= 40:
                score += 0.1

        # 2. 段落长度
        paragraphs = [p.strip() for p in content.split('\n') if p.strip()]
        if paragraphs:
            avg_paragraph_length = sum(len(p) for p in paragraphs) / len(paragraphs)

            # 理想段落长度：100-300字
            if 100 <= avg_paragraph_length <= 300:
                score += 0.2
            elif 50 <= avg_paragraph_length <= 500:
                score += 0.1

        # 3. 标题使用
        heading_patterns = [r'^#+ .+', r'^【.+】', r'^（.+）', r'^\d+\.\s+.+']
        heading_count = 0
        for para in paragraphs:
            for pattern in heading_patterns:
                if re.match(pattern, para):
                    heading_count += 1
                    break

        if 2 <= heading_count <= 10:
            score += 0.2  # 适当的标题数量
        elif heading_count > 0:
            score += 0.1

        # 4. 连接词使用
        connective_words = ['首先', '其次', '然后', '最后', '此外', '另外',
                          '同时', '然而', '但是', '因此', '所以', '因而',
                          '于是', '总结', '综上所述', '换句话说', '例如']

        connective_count = sum(1 for word in connective_words if word in content)
        if 3 <= connective_count <= 15:
            score += 0.2  # 适当的连接词数量
        elif connective_count > 0:
            score += 0.1

        # 5. 专业术语密度（适中为好）
        professional_terms = [
            '战略', '组织', '薪酬', '绩效', '考核', '激励',
            '任职', '资格', '能力', '素质', '人才', '培养',
            '培训', '发展', '领导力', '梯队', '模型', '框架'
        ]

        term_count = sum(1 for term in professional_terms if term in content)
        term_density = term_count / len(content) * 1000 if content else 0  # 每千字术语数

        if 5 <= term_density <= 20:
            score += 0.1  # 适当的专业术语密度

        return min(score, 1.0)

    def _assess_source_authority(self, article: Dict) -> float:
        """评估信源权威性"""
        source_name = article.get('source_name', '')
        source_type = article.get('source_type', '')

        score = 0.0

        # 1. 信源类型权重
        source_type_weights = {
            'official_sources': 1.0,    # 官方机构
            'academic_sources': 0.9,    # 学术机构
            'consulting_firms': 0.8,    # 咨询公司
            'hr_professionals': 0.7,    # HR专业机构
            'industry_media': 0.6       # 行业媒体
        }

        base_score = source_type_weights.get(source_type, 0.5)
        score += base_score * 0.5  # 占50%权重

        # 2. 知名信源加分
        prestigious_sources = [
            # 国际咨询公司
            '麦肯锡', 'McKinsey', '波士顿咨询', 'BCG', '贝恩', 'Bain',
            '德勤', 'Deloitte', '普华永道', 'PwC', '安永', 'EY',
            # HR专业机构
            '美世', 'Mercer', '怡安翰威特', 'Aon', '韦莱韬悦', 'Willis',
            '合益集团', 'Hay Group',
            # 知名媒体
            '哈佛商业评论', 'HBR', '财富', 'Fortune', '福布斯', 'Forbes',
            '经济学人', 'Economist',
            # 国内知名
            '和君咨询', '正略钧策', '北大纵横', '中智公司'
        ]

        for prestigious_source in prestigious_sources:
            if prestigious_source.lower() in source_name.lower():
                score += 0.3
                break

        # 3. 作者权威性（如果有作者信息）
        author = article.get('author', '')
        if author:
            # 检查作者是否包含职称、头衔等
            authority_indicators = ['教授', '博士', '专家', '总监', '总经理',
                                  '合伙人', '首席', '创始人', '院长', '主任']

            for indicator in authority_indicators:
                if indicator in author:
                    score += 0.1
                    break

        # 4. 发布时间新鲜度
        publish_date = article.get('publish_date')
        if publish_date:
            try:
                # 简化处理：假设日期格式为YYYY-MM-DD
                if isinstance(publish_date, str) and len(publish_date) >= 10:
                    pub_date = datetime.strptime(publish_date[:10], '%Y-%m-%d')
                    now = datetime.now()
                    days_diff = (now - pub_date).days

                    # 近一年的文章加分
                    if days_diff <= 365:
                        score += 0.1
                    # 近半年的文章再加分
                    if days_diff <= 180:
                        score += 0.1
            except:
                pass

        return min(score, 1.0)

    def _calculate_total_score(self, dimension_scores: Dict[str, float]) -> float:
        """计算综合质量得分"""
        total_score = 0.0
        total_weight = 0.0

        for dimension, weight in self.dimension_weights.items():
            score = dimension_scores.get(dimension, 0.0)
            total_score += score * weight
            total_weight += weight

        # 归一化
        if total_weight > 0:
            total_score /= total_weight

        return min(max(total_score, 0.0), 1.0)

    def _determine_quality_grade(self, score: float) -> str:
        """根据得分确定质量等级"""
        # 按阈值确定等级
        for grade, threshold in sorted(self.quality_grades.items(), key=lambda x: x[1], reverse=True):
            if score >= threshold:
                return grade

        return 'D'

    def get_detailed_assessment(self, article: Dict) -> Dict:
        """
        获取详细的评估报告

        Args:
            article: 文章数据

        Returns:
            详细评估报告
        """
        # 确保已经评估
        if 'quality_assessment' not in article:
            self.assess(article)

        assessment = article.get('quality_assessment', {})

        # 添加各维度的详细解释
        dimension_explanations = {}
        for dimension, score in assessment.get('dimension_scores', {}).items():
            explanation = self._get_dimension_explanation(dimension, score)
            dimension_explanations[dimension] = {
                'score': score,
                'explanation': explanation
            }

        detailed_report = {
            'total_score': assessment.get('total_score', 0.0),
            'quality_grade': assessment.get('quality_grade', 'D'),
            'dimension_details': dimension_explanations,
            'recommendation': self._get_recommendation(assessment.get('total_score', 0.0)),
            'improvement_suggestions': self._get_improvement_suggestions(assessment.get('dimension_scores', {}))
        }

        return detailed_report

    def _get_dimension_explanation(self, dimension: str, score: float) -> str:
        """获取维度得分的解释"""
        explanations = {
            'content_depth': {
                0.8: "内容分析深入，观点独到，结构完整",
                0.6: "有一定分析深度，但可进一步深入",
                0.4: "分析较浅，多为信息汇总",
                0.2: "内容浅显，缺乏深度分析"
            },
            'data_support': {
                0.8: "数据支撑充分，引用权威数据源",
                0.6: "有一定数据支撑，但可补充更多数据",
                0.4: "数据支撑不足，多为定性描述",
                0.2: "缺乏数据支撑"
            },
            'methodology': {
                0.8: "方法论先进，分析框架完整",
                0.6: "使用合适方法论，但可进一步完善",
                0.4: "方法论简单或不完整",
                0.2: "缺乏明确方法论"
            },
            'originality': {
                0.8: "观点新颖，有独特见解",
                0.6: "有一定原创性，但创新点不多",
                0.4: "多为常见观点，缺乏创新",
                0.2: "内容缺乏原创性"
            },
            'readability': {
                0.8: "可读性极佳，结构清晰，语言流畅",
                0.6: "可读性良好，部分地方可优化",
                0.4: "可读性一般，存在理解障碍",
                0.2: "可读性差，难以理解"
            },
            'source_authority': {
                0.8: "信源权威，作者专业背景强",
                0.6: "信源有一定权威性",
                0.4: "信源权威性一般",
                0.2: "信源权威性不足"
            }
        }

        dimension_exps = explanations.get(dimension, {})
        # 找到最接近的阈值
        closest_threshold = min(dimension_exps.keys(), key=lambda x: abs(x - score))
        return dimension_exps.get(closest_threshold, "暂无评价")

    def _get_recommendation(self, score: float) -> str:
        """根据得分获取推荐建议"""
        if score >= 0.8:
            return "强烈推荐：高质量内容，适合作为知识库核心参考"
        elif score >= 0.7:
            return "推荐：质量良好，可作为重要参考"
        elif score >= 0.6:
            return "可考虑：质量合格，可作为一般参考"
        else:
            return "不推荐：质量不足，建议过滤"

    def _get_improvement_suggestions(self, dimension_scores: Dict[str, float]) -> List[str]:
        """获取改进建议"""
        suggestions = []

        # 找出得分较低的维度
        low_score_dimensions = [dim for dim, score in dimension_scores.items() if score < 0.6]

        suggestion_map = {
            'content_depth': "建议增加深度分析、多角度思考、独特见解",
            'data_support': "建议补充数据支撑、引用权威数据源、增加案例分析",
            'methodology': "建议使用更先进的方法论、完善分析框架",
            'originality': "建议增加个人观点、独特见解、创新思考",
            'readability': "建议优化文章结构、调整段落长度、增加连接词",
            'source_authority': "建议选择更权威的信源、注明作者专业背景"
        }

        for dimension in low_score_dimensions:
            if dimension in suggestion_map:
                suggestions.append(suggestion_map[dimension])

        return suggestions

    def batch_assess(self, articles: List[Dict]) -> List[Dict]:
        """
        批量评估文章质量

        Args:
            articles: 文章列表

        Returns:
            评估后的文章列表（添加了quality_score和quality_grade字段）
        """
        assessed_articles = []

        for i, article in enumerate(articles):
            try:
                score, grade = self.assess(article)
                article['quality_score'] = score
                article['quality_grade'] = grade

                assessed_articles.append(article)

                if (i + 1) % 10 == 0:
                    logging.info(f"已评估 {i + 1}/{len(articles)} 篇文章")

            except Exception as e:
                logging.error(f"评估文章质量失败: {e}")
                article['quality_score'] = 0.0
                article['quality_grade'] = 'D'
                assessed_articles.append(article)

        logging.info(f"批量评估完成: {len(assessed_articles)} 篇文章")
        return assessed_articles

    def get_statistics(self, articles: List[Dict]) -> Dict:
        """
        获取质量评估统计

        Args:
            articles: 文章列表

        Returns:
            质量统计
        """
        if not articles:
            return {'error': '没有文章数据'}

        total_articles = len(articles)
        quality_scores = [a.get('quality_score', 0.0) for a in articles]
        quality_grades = [a.get('quality_grade', 'D') for a in articles]

        avg_score = sum(quality_scores) / total_articles if total_articles > 0 else 0.0

        # 等级分布
        grade_distribution = {}
        for grade in ['A+', 'A', 'B', 'C', 'D']:
            count = quality_grades.count(grade)
            grade_distribution[grade] = {
                'count': count,
                'percentage': count / total_articles * 100 if total_articles > 0 else 0
            }

        # 维度平均分
        dimension_scores = {dim: [] for dim in self.dimension_weights.keys()}
        for article in articles:
            assessment = article.get('quality_assessment', {})
            dim_scores = assessment.get('dimension_scores', {})
            for dim, score in dim_scores.items():
                dimension_scores[dim].append(score)

        avg_dimension_scores = {}
        for dim, scores in dimension_scores.items():
            avg_dimension_scores[dim] = sum(scores) / len(scores) if scores else 0.0

        statistics = {
            'total_articles': total_articles,
            'average_score': avg_score,
            'grade_distribution': grade_distribution,
            'average_dimension_scores': avg_dimension_scores
        }

        return statistics