---
name: picture-book-wizard
description: 专业的儿童双语绘本创作技能，使用 'banana nano' 生成高质量、风格一致的绘本。支持18种视觉风格（7种核心儿童绘本风格、5种氛围风格、5种中国文化风格、1种专业风格），12种场景（5种自然场景 + 7种文化场景），年龄驱动的动态内容系统（3-12岁），以及扩展学习领域（科学、数学、历史、心理学等）。适用于创建绘本故事、提示词或学习材料。
argument-hint: "[风格] [场景] [年龄] [页数-可选] [角色-可选]"
---

# 绘本魔法师

专业的绘本创作技能，生成中英双语教育内容，并为 'banana nano' 生成器优化图像提示词。

## 快速开始

**用法**: `/picture-book-wizard [风格] [场景] [年龄] [页数-可选] [角色-可选] [灵魂-可选]`

**完整故事系统**:
- 🦴 **骨架**: 风格、场景、年龄、页数、角色（必需）
- ❤️ **灵魂**: 情感、主题、叙事、节奏、色彩（可选，未指定时自动选择）

**年龄驱动系统**（推荐）:
- **年龄**: 目标读者年龄（3-12岁）
- **页数**: 根据年龄自动计算（可覆盖）
- **角色**: 根据年龄自动适配或动态生成

### 可用风格（共18种）

**一、核心儿童绘本风格**（⭐⭐⭐ 强烈推荐）：
- `storybook`（故事书）、`watercolor`（水彩）、`gouache`（水粉）、`crayon`（蜡笔）、`colored-pencil`（彩铅）、`clay`（粘土）、`paper-cut`（剪纸）

**二、氛围增强风格**（建议用于10-20%的页面）：
- `dreamy`（梦幻）、`fairytale`（童话）、`collage`（拼贴）、`fabric`（布艺）、`felt`（毛毡）

**三、中国文化风格**：
- `ink`（水墨）、`ink-line`（白描）、`nianhua`（年画）、`porcelain`（青花）、`shadow-puppet`（皮影）

**四、专业风格**: `tech`（科技）（⚠️ 谨慎使用）

> **完整详情**: `references/config/core/styles.md`

### 可用场景（12个核心 + 扩展）

**核心12场景**（高验证率 - >90% 准确度）：
- **自然场景**: `meadow`（草地）、`pond`（池塘）、`rice-paddy`（稻田）、`stars`（星空）、`forest`（森林）
- **文化与日常生活**: `kitchen`（厨房）、`courtyard`（庭院）、`market`（集市）、`temple`（寺庙）、`festival`（节日）、`grandma-room`（奶奶房间）、`kindergarten`（幼儿园）

**扩展场景**: 系统通过智能匹配支持无限场景扩展至核心场景。

> **完整详情**: `references/config/core/scenes.md`, `references/config/advanced/scene-matching.md`

### 可用角色

**主角**:
- `yueyue`（悦悦）- 5岁女孩，好奇温柔（默认）
- `xiaoming`（小明）- 6岁男孩，爱冒险有活力
- `lele`（乐乐）- 3岁男孩，开朗天真
- `meimei`（美美）- 4岁女孩，有创意爱想象

**配角**: `grandma`（奶奶）、`dad`（爸爸）、`mom`（妈妈）、`grandpa`（爷爷）、`sibling`（兄弟姐妹）
**动物伙伴**: `cat`（猫）、`dog`（狗）、`rabbit`（兔子）、`chick`（小鸡）、`duckling`（小鸭）等

> **完整详情**: `references/config/core/characters.md`, `references/config/advanced/supporting-characters.md`

### 多角色用法
- **家人**: `with:grandma`, `with:dad`, `with:mom`
- **动物**: `with:cat`, `with:dog`, `with:rabbit`
- **多个**: `with:grandma,cat`

### 灵魂元素（可选）
- **情感**: `joyful`（欢乐）、`calm`（平静）、`curious`（好奇）、`brave`（勇敢）、`warm`（温暖）、`wonder`（惊奇）、`reflective`（沉思）
- **主题**: `growth`（成长）、`friendship`（友谊）、`nature`（自然）、`family`（家庭）、`courage`（勇气）、`creativity`（创造力）、`discovery`（发现）
- **叙事**: `journey`（旅程）、`problem`（问题解决）、`cycle`（循环）、`transform`（转变）、`quest`（探索）
- **节奏**: `gentle`（轻柔）、`lively`（活泼）、`building`（渐进）、`varied`（变化）
- **色彩**: `warm-bright`（暖亮）、`fresh`（清新）、`dreamy`（梦幻）、`vibrant`（鲜艳）、`serene`（宁静）

> **完整详情**: `references/config/advanced/story-soul.md`

### 示例
```bash
# 基于年龄生成（推荐）
/picture-book-wizard watercolor meadow 4
/picture-book-wizard clay forest 8 5
/picture-book-wizard nianhua kitchen 10 7 xiaoming

# 带灵魂元素
/picture-book-wizard watercolor forest 8 yueyue emotion:curious
/picture-book-wizard storybook meadow 5 theme:friendship

# 带多角色
/picture-book-wizard watercolor kitchen 6 yueyue with:grandma theme:family

# 辅助命令
/picture-book-wizard help:style warm cozy
/picture-book-wizard help:character age:4 theme:creative
```

---

## 处理流程

### 步骤0: 内容安全验证（必须）

**关键**: 此检查在任何内容生成之前运行。

1. **输入验证**: 验证风格、角色、年龄是否在允许列表中
2. **禁止内容**: 拒绝暴力、恐怖、成人、政治、商业内容
3. **年龄-主题检查**: 确保主题适合年龄组

> **完整规则**: `references/config/core/content-safety-validation.md`

### 步骤0.5: 生成前辅助（可选）

**风格助手** (`help:style [氛围]`): 根据期望的感觉获取风格推荐
**角色顾问** (`help:character [上下文]`): 根据故事上下文获取角色推荐
**角色类型检测**: 自动检测动物vs人类角色请求

> **完整详情**: `references/config/core/style-assistant.md`, `references/config/core/character-advisor.md`

### 步骤1: 参数验证

验证风格、场景和年龄/页数参数。如果缺失，请求用户指定。

**年龄驱动自动计算**:
- 3-4岁: 1-3页，基础认知
- 5-6岁: 3-5页，基础科学 + 社交技能
- 7-8岁: 5-7页，科学 + 数学 + 历史
- 9-10岁: 7-10页，高级科学 + 心理学
- 11-12岁: 10-15页，跨学科学习

> **完整规格**: `references/config/core/age-system.md`

### 步骤2: 角色一致性（CCLP 4.0）

为多页故事应用**角色一致性锁定协议 v4.0**。

**三级灵活度**:
1. **严格模式**（默认）: 所有页面外观100%一致
2. **适度模式**: 固定脸部/头发/体型，场景自适应服装需叙事理由
3. **灵活模式**: 仅标志性特征，时间/主题自适应变化

**核心要求**:
- 关键特征上的**必须标志**标记
- 第1页的**锁定建立**声明
- 后续页面的**一致性参考**声明
- 提示词末尾的**水印预防等级2（35词）**
- **提示词压缩**: 总计280-300词

> **完整协议**: `references/config/cclp/character-consistency-lock.md`, `references/config/cclp/CCLP-FLEXIBILITY.md`

### 步骤3: 内容生成

#### 单页
生成四个组件:
1. **故事文本**: 双语（中文优先，英文），适龄
2. **学习重点**: 汉字 + 适龄学习领域
3. **图像提示词**: 角色锚点 + 场景 + 风格 + 渲染 + 水印预防
4. **格式化输出**: 标准模板

#### 多页故事
1. **封面页**: 角色展示，标题空间，吸引人的氛围
2. **故事弧**: 3页（开始-中间-结尾），5页（完整弧），7页（扩展旅程）
3. **叙事连贯性**: 角色一致性，故事流畅，学习进阶
4. **故事总结**: 学习的汉字，主题，延伸活动

> **故事模式**: `references/config/core/story-flow.md`
> **输出格式**: `assets/templates/output-format.md`

### 步骤4: 输出前验证

**现实验证**（用于发现/科学主题）:
- 交叉检查场景可观察元素
- 验证生物/物理准确性
- 扫描常见错误模式

> **验证规则**: `references/config/advanced/reality-validation.md`

### 步骤5: 文件输出

保存至: `./output/picture-books/[YYYY-MM]/[风格]-[场景]-[角色]-[页数]-[时间戳].md`

---

## 图像提示词组装

### 单角色格式
```
[风格] 儿童绘本插画,
[角色锚点带表情],
[动作/姿势],
[场景元素],
[风格关键词],
[渲染参数],
[水印预防等级2]
```

### 多角色格式
```
[主角色锚点 - 150词],
[主角色动作 + 互动],
[次要角色 - 40-50词],
[关系描述],
[场景 + 风格 + 渲染],
[水印预防等级2]
```

**关键多角色规则**: 永远不要使用通用描述（"家人"、"爸爸的剪影"）。每个可见角色必须有详细的视觉锚点。

> **配角锚点**: `references/config/advanced/supporting-characters.md`
> **多角色修复指南**: `references/guides/MULTI-CHARACTER-PROMPT-FIX.md`

### 水印预防（必须）

**等级2（35词 - 多页默认）**:
```
clean professional children's book illustration, publication-ready quality, pristine unmarked image, full bleed composition, no watermark, no text overlays, no signatures, no artist marks, no logos, no branding, no copyright symbols, no website URLs, clean professional image
```

**位置**: 必须放在提示词最后。

> **故障排除**: `references/guides/WATERMARK-TROUBLESHOOTING.md`

---

## 角色锚点（快速参考）

**悦悦**（5岁）:
- 标志: **鲜红缎带双马尾**、**阳光黄针织毛衣**、**牛仔背带裤**
- 体型: 胖嘟嘟的学龄前儿童，105-110cm

**小明**（6岁）:
- 标志: **左偏分短黑发**、**宝蓝色棉质T恤**、**卡其色短裤**
- 体型: 普通6岁男孩，115-118cm

**美美**（4岁）:
- 标志: **彩虹图案发卡马尾**、**粉色雏菊连衣裙**、**白色凉鞋**
- 体型: 纤细的4岁女孩，100-102cm

**乐乐**（3岁）:
- 标志: **蓬松短黑发**、**红白条纹T恤**、**宝蓝色松紧裤**
- 体型: 非常胖的幼儿，90-95cm

> **完整锚点**: `references/config/core/characters.md`

---

## 质量检查清单

**内容质量**:
- [ ] 适龄语言
- [ ] 准确的拼音带声调标记
- [ ] 学习目标匹配年龄
- [ ] 自然的双语翻译

**技术质量**:
- [ ] 包含角色锚点
- [ ] 包含风格关键词
- [ ] 渲染参数完整
- [ ] **包含水印指令**（关键）

**CCLP质量（多页）**:
- [ ] 关键特征上的必须标志标记
- [ ] 锁定建立 / 一致性参考声明
- [ ] 关键一致性强制命令
- [ ] 角色外观跨页面一致
- [ ] 仅表情和姿势变化（严格模式）
- [ ] 水印等级2（35词）在末尾
- [ ] 总提示词280-300词

---

## 配置参考

### 核心配置
| 文件 | 描述 |
|------|------|
| `references/config/core/characters.md` | 4个主角 + 选择指南 |
| `references/config/core/styles.md` | 18种视觉风格，4个类别 |
| `references/config/core/scenes.md` | 12个场景及可观察元素 |
| `references/config/core/age-system.md` | 年龄驱动内容规格 |
| `references/config/core/rendering.md` | 技术渲染 + 水印系统 |

### 角色一致性
| 文件 | 描述 |
|------|------|
| `references/config/cclp/character-consistency-lock.md` | CCLP 4.0 协议 |
| `references/config/cclp/CCLP-FLEXIBILITY.md` | 三级灵活度系统 |
| `references/config/advanced/supporting-characters.md` | 家人/动物角色锚点 |
| `references/config/advanced/relationship-dynamics.md` | 多角色模式 |

### 故事创作
| 文件 | 描述 |
|------|------|
| `references/config/advanced/story-soul.md` | 情感、主题、叙事、节奏、色彩 |
| `references/config/core/story-flow.md` | 多页故事模式 + 封面设计 |
| `references/config/advanced/scene-matching.md` | 扩展场景智能匹配 |
| `references/config/advanced/reality-validation.md` | 科学准确性验证 |

### 安全与辅助
| 文件 | 描述 |
|------|------|
| `references/config/core/content-safety-validation.md` | 禁止内容规则 |
| `references/config/core/style-assistant.md` | 风格推荐系统 |
| `references/config/core/character-advisor.md` | 角色推荐系统 |

### 动物
| 文件 | 描述 |
|------|------|
| `references/config/animals/animal-characters.md` | 动物角色系统 |
| `references/config/animals/animal-cclp.md` | 动物CCLP规则 |

### 模板与示例
| 文件 | 描述 |
|------|------|
| `assets/templates/output-format.md` | 输出结构 + 文件规格 |
| `references/examples/` | 按风格/场景的工作示范 |

### 指南
| 文件 | 描述 |
|------|------|
| `references/guides/design.md` | 架构文档 |
| `references/guides/extending.md` | 扩展指南 |
| `references/guides/WATERMARK-TROUBLESHOOTING.md` | 水印修复策略 |
| `references/guides/MULTI-CHARACTER-PROMPT-FIX.md` | 多角色修复指南 |

---

## 核心原则

1. **教育为本**: 每页都服务于明确的学习目标
2. **角色一致**: 标志性特征不可妥协
3. **提示优化**: 150-250词，包含所有VCP锚点
4. **文化真实**: 准确的汉字和文化语境
5. **无水印**: 始终包含水印预防指令

---

*详细规格请参阅引用的配置文件。*
