# OGSM Excel 报告生成器

基于Python的OGSM关键任务分解表生成工具，可以自动生成包含对比分析、评估报告和行动计划的Excel文件。

## 功能特性

- ✅ 自动生成4个Sheet的Excel报告
- ✅ 原文与优化后内容对比
- ✅ 多维度评分和优先级标注
- ✅ 行动计划清单生成
- ✅ 专业的格式和颜色配置

## 快速开始

### 1. 安装依赖

```bash
pip install openpyxl>=3.0.9
```

或者使用requirements.txt:

```bash
pip install -r requirements.txt
```

### 2. 使用示例

查看 `example_usage.py` 获取完整示例：

```python
from src.ogsm_excel_generator import OGSMExcelGenerator
from src.ogsm_excel_generator.models import (
    OGSMData, Objective, Goal, Strategy, Measure, Action, EvaluationDimension
)

# 创建OGSM数据
data = OGSMData()
data.year = "2024"
data.department = "人力资源部"
data.quarter = "Q1"

# 添加目的
obj = Objective(
    id="O1",
    description="打造AI驱动的敏捷高效能组织",
    original_description="打造AI驱动的敏捷高效能组织",
    adjustment_notes="目的清晰，可微调",
    status="已采纳"
)
data.add_objective(obj)

# 添加目标
goal = Goal(
    id="G1",
    objective_id="O1",
    description="成本优化：固定人工成本降10%",
    original_description="成本优化（职场 + 固定人工成本降10%）",
    adjustment_notes="需要明确具体策略",
    status="待确认"
)
data.add_goal(goal)

# 添加评估维度
data.add_evaluation_dimension(EvaluationDimension(
    dimension="目的(O)清晰度",
    score=4,
    problem_description="方向清晰",
    optimization_suggestion="建议增加时间维度",
    priority="中"
))

# 生成Excel
generator = OGSMExcelGenerator(data)
output_path = generator.generate("output/OGSM报告.xlsx")
print(f"Excel已生成: {output_path}")
```

### 3. 运行示例

```bash
python example_usage.py
```

## Excel报告结构

### Sheet 1: OGSM对比分析表
- 原文内容（黄色背景）
- 优化后内容（绿色背景）
- 调整说明
- 状态追踪

### Sheet 2: 完整OGSM（优化后版本）
- 标准10列表格
- 目的、目标、策略、衡量指标
- 行动清单、责任人、完成时间

### Sheet 3: 评估报告
- 6个维度评分
- 问题描述（红色字体）
- 优化建议（蓝色字体）
- 优先级标注

### Sheet 4: 行动计划清单
- 具体行动项
- 责任人、配合方
- 优先级、状态追踪

## 项目结构

```
OGSMHelper/
├── src/
│   └── ogsm_excel_generator/
│       ├── __init__.py          # 包初始化
│       ├── models.py            # 数据模型
│       ├── styles.py            # Excel样式
│       ├── generator.py         # 主生成器
│       └── example_usage.py     # 使用示例
├── example_usage.py             # 顶层使用示例
├── requirements.txt            # 依赖列表
└── README.md                   # 本文档
```

## 依赖

- Python 3.7+
- openpyxl >= 3.0.9

## License

MIT License
