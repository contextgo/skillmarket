"""
OGSM Excel Report Generator
OGSM Excel报告生成器主类
"""

import os
from datetime import datetime
from typing import Optional

try:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Border, Side, Alignment
    from openpyxl.utils import get_column_letter
except ImportError:
    print("请安装openpyxl库: pip install openpyxl")
    raise

from .models import OGSMData, OGSMEvaluation, Objective, Goal, Strategy, Measure, Action, EvaluationDimension
from .styles import Colors, Fonts, Fills, Borders, Alignments, ColumnWidths, RowHeights


class OGSMExcelGenerator:
    """OGSM Excel报告生成器"""

    def __init__(self, data: OGSMData):
        self.data = data
        self.workbook = Workbook()
        self.workbook.remove(self.workbook.active)

    def generate(self, output_path: Optional[str] = None) -> str:
        """生成完整的Excel报告"""
        self._create_comparison_sheet()
        self._create_ogsm_sheet()
        self._create_evaluation_sheet()
        self._create_action_sheet()

        if output_path is None:
            output_path = self._generate_filename()

        self.workbook.save(output_path)
        return output_path

    def _generate_filename(self) -> str:
        """生成文件名"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"OGSM_Analysis_Report_{timestamp}.xlsx"
        return filename

    def _create_comparison_sheet(self):
        """创建Sheet 1: OGSM对比分析表"""
        ws = self.workbook.create_sheet("OGSM对比分析表")

        headers = ["层级", "要素", "原文内容", "优化后内容", "调整说明", "状态"]

        for col, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col, value=header)
            cell.font = Fonts.HEADER
            cell.fill = Fills.HEADER
            cell.border = Borders.THIN
            cell.alignment = Alignments.CENTER

        row = 2
        for obj in self.data.objectives:
            self._add_comparison_row(ws, row, "O", "目的", obj)
            row += 1

        for goal in self.data.goals:
            self._add_comparison_row(ws, row, "G", f"目标{goal.id}", goal)
            row += 1

        for strategy in self.data.strategies:
            self._add_comparison_row(ws, row, "S", f"策略{strategy.id}", strategy)
            row += 1

        for measure in self.data.measures:
            self._add_comparison_row(ws, row, "M", f"衡量指标{measure.id}", measure)
            row += 1

        self._apply_column_widths(ws, ColumnWidths.COMPARISON_SHEET)
        ws.row_dimensions[1].height = RowHeights.HEADER

    def _add_comparison_row(self, ws, row: int, level: str, element: str, item):
        """添加对比分析表行"""
        data = [level, element, item.original_description or item.description, item.description,
                item.adjustment_notes, item.status]

        for col, value in enumerate(data, 1):
            cell = ws.cell(row=row, column=col, value=value)
            cell.border = Borders.THIN
            cell.alignment = Alignments.LEFT

            if col == 3:
                cell.fill = Fills.ORIGINAL
            elif col == 4:
                cell.fill = Fills.OPTIMIZED

        ws.row_dimensions[row].height = RowHeights.CONTENT

    def _create_ogsm_sheet(self):
        """创建Sheet 2: 完整OGSM（优化后版本）- 完整层级结构"""
        ws = self.workbook.create_sheet("完整OGSM（优化后）")

        headers = ["目的(Objective)", "年度目标(Goal)", "策略(Strategy)", "衡量指标(Measure)",
                   "具体行动清单", "责任人", "配合方", "预计完成时间", "完成情况", "备注"]

        for col, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col, value=header)
            cell.font = Fonts.HEADER
            cell.fill = Fills.HEADER
            cell.border = Borders.THIN
            cell.alignment = Alignments.CENTER

        row = 2
        for obj in self.data.objectives:
            obj_start_row = row
            goals = self.data.get_goals_by_objective(obj.id)

            for goal in goals:
                goal_start_row = row
                strategies = self.data.get_strategies_by_goal(goal.id)

                for strategy in strategies:
                    strategy_start_row = row
                    measures = self.data.get_measures_by_strategy(strategy.id)

                    for measure in measures:
                        ws.cell(row=row, column=4, value=measure.description)
                        ws.cell(row=row, column=4).border = Borders.THIN
                        ws.cell(row=row, column=4).alignment = Alignments.LEFT

                        actions = [a for a in self.data.actions if a.related_element == measure.id]
                        action_text = "\n".join([a.description for a in actions])
                        ws.cell(row=row, column=5, value=action_text)
                        ws.cell(row=row, column=5).border = Borders.THIN
                        ws.cell(row=row, column=5).alignment = Alignments.LEFT

                        if actions:
                            ws.cell(row=row, column=6, value=actions[0].owner)
                            ws.cell(row=row, column=7, value=actions[0].collaborator)
                            ws.cell(row=row, column=8, value=actions[0].deadline)
                            ws.cell(row=row, column=9, value=actions[0].status)

                        for col in range(5, 11):
                            ws.cell(row=row, column=col).border = Borders.THIN
                            if col in [6, 7, 8, 9]:
                                ws.cell(row=row, column=col).alignment = Alignments.CENTER

                        row += 1

                    strategy_end_row = row - 1
                    if strategy_start_row <= strategy_end_row:
                        ws.cell(row=strategy_start_row, column=3, value=strategy.description)
                        ws.cell(row=strategy_start_row, column=3).font = Fonts.BOLD
                        ws.cell(row=strategy_start_row, column=3).border = Borders.THIN
                        ws.cell(row=strategy_start_row, column=3).alignment = Alignments.LEFT

                        if strategy_start_row < strategy_end_row:
                            ws.merge_cells(
                                start_row=strategy_start_row, start_column=3,
                                end_row=strategy_end_row, end_column=3
                            )

                goal_end_row = row - 1
                if goal_start_row <= goal_end_row:
                    goal_text = f"{goal.id}: {goal.description}"
                    ws.cell(row=goal_start_row, column=2, value=goal_text)
                    ws.cell(row=goal_start_row, column=2).font = Font(
                        name='微软雅黑', size=10, bold=True
                    )
                    ws.cell(row=goal_start_row, column=2).border = Borders.THIN
                    ws.cell(row=goal_start_row, column=2).alignment = Alignments.LEFT

                    if goal_start_row < goal_end_row:
                        ws.merge_cells(
                            start_row=goal_start_row, start_column=2,
                            end_row=goal_end_row, end_column=2
                        )

            obj_end_row = row - 1
            if obj_start_row <= obj_end_row:
                ws.cell(row=obj_start_row, column=1, value=obj.description)
                ws.cell(row=obj_start_row, column=1).font = Font(
                    name='微软雅黑', size=11, bold=True, color=Colors.HEADER_BG
                )
                ws.cell(row=obj_start_row, column=1).border = Borders.THIN
                ws.cell(row=obj_start_row, column=1).alignment = Alignments.LEFT

                if obj_start_row < obj_end_row:
                    ws.merge_cells(
                        start_row=obj_start_row, start_column=1,
                        end_row=obj_end_row, end_column=1
                    )

        self._apply_column_widths(ws, ColumnWidths.OGSM_SHEET)
        ws.row_dimensions[1].height = RowHeights.HEADER
        for r in range(2, row):
            ws.row_dimensions[r].height = RowHeights.CONTENT

    def _create_evaluation_sheet(self):
        """创建Sheet 3: 评估报告"""
        ws = self.workbook.create_sheet("评估报告")

        headers = ["评估维度", "评分(1-5)", "问题描述", "优化建议", "优先级"]

        for col, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col, value=header)
            cell.font = Fonts.HEADER
            cell.fill = Fills.HEADER
            cell.border = Borders.THIN
            cell.alignment = Alignments.CENTER

        row = 2
        for dim in self.data.evaluation.dimensions:
            ws.cell(row=row, column=1, value=dim.dimension).border = Borders.THIN
            ws.cell(row=row, column=2, value=dim.score).border = Borders.THIN
            ws.cell(row=row, column=2).alignment = Alignments.CENTER

            problem_cell = ws.cell(row=row, column=3, value=dim.problem_description)
            problem_cell.font = Fonts.PROBLEM
            problem_cell.border = Borders.THIN

            suggestion_cell = ws.cell(row=row, column=4, value=dim.optimization_suggestion)
            suggestion_cell.font = Fonts.SUGGESTION
            suggestion_cell.border = Borders.THIN

            ws.cell(row=row, column=5, value=dim.priority).border = Borders.THIN
            ws.cell(row=row, column=5).alignment = Alignments.CENTER

            row += 1

        overall_score_row = row
        ws.cell(row=overall_score_row, column=1, value="综合评分")
        ws.cell(row=overall_score_row, column=1).font = Fonts.BOLD
        ws.cell(row=overall_score_row, column=1).fill = Fills.OVERALL_SCORE
        ws.cell(row=overall_score_row, column=1).border = Borders.THIN

        ws.cell(row=overall_score_row, column=2, value=round(self.data.evaluation.calculate_overall_score(), 1))
        ws.cell(row=overall_score_row, column=2).font = Fonts.BOLD
        ws.cell(row=overall_score_row, column=2).fill = Fills.OVERALL_SCORE
        ws.cell(row=overall_score_row, column=2).border = Borders.THIN
        ws.cell(row=overall_score_row, column=2).alignment = Alignments.CENTER

        for col in range(3, 6):
            ws.cell(row=overall_score_row, column=col).fill = Fills.OVERALL_SCORE
            ws.cell(row=overall_score_row, column=col).border = Borders.THIN

        self._apply_column_widths(ws, ColumnWidths.EVALUATION_SHEET)
        ws.row_dimensions[1].height = RowHeights.HEADER
        ws.row_dimensions[overall_score_row].height = RowHeights.CONTENT

    def _create_action_sheet(self):
        """创建Sheet 4: 行动计划清单"""
        ws = self.workbook.create_sheet("行动计划清单")

        headers = ["序号", "行动项", "对应OGSM要素", "责任人", "配合方", "完成时间", "优先级", "状态", "备注"]

        for col, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col, value=header)
            cell.font = Fonts.HEADER
            cell.fill = Fills.HEADER
            cell.border = Borders.THIN
            cell.alignment = Alignments.CENTER

        row = 2
        for action in self.data.actions:
            ws.cell(row=row, column=1, value=action.id).border = Borders.THIN
            ws.cell(row=row, column=1).alignment = Alignments.CENTER

            ws.cell(row=row, column=2, value=action.description).border = Borders.THIN
            ws.cell(row=row, column=3, value=action.related_element).border = Borders.THIN
            ws.cell(row=row, column=4, value=action.owner).border = Borders.THIN
            ws.cell(row=row, column=5, value=action.collaborator).border = Borders.THIN
            ws.cell(row=row, column=6, value=action.deadline).border = Borders.THIN
            ws.cell(row=row, column=6).alignment = Alignments.CENTER

            priority_cell = ws.cell(row=row, column=7, value=action.priority)
            priority_cell.border = Borders.THIN
            priority_cell.alignment = Alignments.CENTER
            if action.priority == "高":
                priority_cell.font = Font(name='微软雅黑', size=10, color=Colors.HIGH_PRIORITY, bold=True)
            elif action.priority == "中":
                priority_cell.font = Font(name='微软雅黑', size=10, color=Colors.MEDIUM_PRIORITY)

            ws.cell(row=row, column=8, value=action.status).border = Borders.THIN
            ws.cell(row=row, column=8).alignment = Alignments.CENTER
            ws.cell(row=row, column=9, value=action.notes).border = Borders.THIN

            row += 1

        self._apply_column_widths(ws, ColumnWidths.ACTION_SHEET)
        ws.row_dimensions[1].height = RowHeights.HEADER

    def _apply_column_widths(self, ws, widths: dict):
        """应用列宽"""
        for col_letter, width in widths.items():
            ws.column_dimensions[col_letter].width = width
