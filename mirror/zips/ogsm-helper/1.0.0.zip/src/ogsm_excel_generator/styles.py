"""
OGSM Excel Styles
Excel样式配置
"""

from openpyxl.styles import Font, Fill, PatternFill, Border, Side, Alignment
from openpyxl.utils import get_column_letter


class Colors:
    """颜色配置"""
    HEADER_BG = "1F4E79"       # 深蓝色 - 表头背景
    HEADER_FONT = "FFFFFF"      # 白色 - 表头字体

    ORIGINAL_BG = "FFF2CC"      # 浅黄色 - 原文内容
    OPTIMIZED_BG = "D9EAD3"     # 浅绿色 - 优化后内容

    HIGH_PRIORITY = "FF0000"    # 红色 - 高优先级
    MEDIUM_PRIORITY = "FFA500"  # 橙色 - 中优先级
    LOW_PRIORITY = "92D050"    # 浅绿色 - 低优先级

    PROBLEM_FONT = "FF0000"     # 红色字体 - 问题描述
    SUGGESTION_FONT = "0000FF"   # 蓝色字体 - 优化建议

    OVERALL_SCORE_BG = "FFFF00"  # 黄色 - 综合评分行

    TITLE_BG = "2E75B6"         # 蓝色 - 标题背景


class Fonts:
    """字体配置"""
    HEADER = Font(name='微软雅黑', size=11, bold=True, color=Colors.HEADER_FONT)
    NORMAL = Font(name='微软雅黑', size=10)
    BOLD = Font(name='微软雅黑', size=10, bold=True)
    TITLE = Font(name='微软雅黑', size=14, bold=True)
    PROBLEM = Font(name='微软雅黑', size=10, color=Colors.PROBLEM_FONT)
    SUGGESTION = Font(name='微软雅黑', size=10, color=Colors.SUGGESTION_FONT)


class Fills:
    """填充配置"""
    HEADER = PatternFill(start_color=Colors.HEADER_BG, end_color=Colors.HEADER_BG, fill_type="solid")
    ORIGINAL = PatternFill(start_color=Colors.ORIGINAL_BG, end_color=Colors.ORIGINAL_BG, fill_type="solid")
    OPTIMIZED = PatternFill(start_color=Colors.OPTIMIZED_BG, end_color=Colors.OPTIMIZED_BG, fill_type="solid")
    OVERALL_SCORE = PatternFill(start_color=Colors.OVERALL_SCORE_BG, end_color=Colors.OVERALL_SCORE_BG, fill_type="solid")


class Borders:
    """边框配置"""
    THIN = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )


class Alignments:
    """对齐配置"""
    CENTER = Alignment(horizontal='center', vertical='center', wrap_text=True)
    LEFT = Alignment(horizontal='left', vertical='center', wrap_text=True)
    RIGHT = Alignment(horizontal='right', vertical='center', wrap_text=True)


class ColumnWidths:
    """列宽配置"""
    COMPARISON_SHEET = {
        'A': 8,    # 层级
        'B': 12,   # 要素
        'C': 30,   # 原文内容
        'D': 35,   # 优化后内容
        'E': 40,   # 调整说明
        'F': 10,   # 状态
    }

    OGSM_SHEET = {
        'A': 25,   # 目的
        'B': 25,   # 年度目标
        'C': 25,   # 策略
        'D': 25,   # 衡量指标
        'E': 25,   # 具体行动
        'F': 12,   # 责任人
        'G': 12,   # 配合方
        'H': 12,   # 预计完成时间
        'I': 10,   # 完成情况
        'J': 20,   # 备注
    }

    EVALUATION_SHEET = {
        'A': 20,   # 评估维度
        'B': 10,   # 评分
        'C': 35,   # 问题描述
        'D': 35,   # 优化建议
        'E': 10,   # 优先级
    }

    ACTION_SHEET = {
        'A': 6,    # 序号
        'B': 35,   # 行动项
        'C': 15,   # 对应要素
        'D': 12,   # 责任人
        'E': 12,   # 配合方
        'F': 15,   # 完成时间
        'G': 10,   # 优先级
        'H': 10,   # 状态
        'I': 20,   # 备注
    }


class RowHeights:
    """行高配置"""
    HEADER = 35
    CONTENT = 40
    TITLE = 45
