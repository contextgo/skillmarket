"""
OGSM Data Models
OGSM数据模型定义
"""

from dataclasses import dataclass, field
from typing import List, Optional
from datetime import datetime


@dataclass
class Objective:
    """目的（O）"""
    id: str
    description: str
    original_description: str = ""
    adjustment_notes: str = ""
    status: str = "待确认"

    def to_dict(self):
        return {
            'id': self.id,
            'description': self.description,
            'original_description': self.original_description,
            'adjustment_notes': self.adjustment_notes,
            'status': self.status
        }


@dataclass
class Goal:
    """目标（G）"""
    id: str
    objective_id: str
    description: str
    original_description: str = ""
    adjustment_notes: str = ""
    status: str = "待确认"

    def to_dict(self):
        return {
            'id': self.id,
            'objective_id': self.objective_id,
            'description': self.description,
            'original_description': self.original_description,
            'adjustment_notes': self.adjustment_notes,
            'status': self.status
        }


@dataclass
class Strategy:
    """策略（S）"""
    id: str
    goal_id: str
    description: str
    original_description: str = ""
    adjustment_notes: str = ""
    status: str = "待确认"

    def to_dict(self):
        return {
            'id': self.id,
            'goal_id': self.goal_id,
            'description': self.description,
            'original_description': self.original_description,
            'adjustment_notes': self.adjustment_notes,
            'status': self.status
        }


@dataclass
class Measure:
    """衡量指标（M）"""
    id: str
    strategy_id: str
    description: str
    original_description: str = ""
    adjustment_notes: str = ""
    status: str = "待确认"

    def to_dict(self):
        return {
            'id': self.id,
            'strategy_id': self.strategy_id,
            'description': self.description,
            'original_description': self.original_description,
            'adjustment_notes': self.adjustment_notes,
            'status': self.status
        }


@dataclass
class Action:
    """具体行动"""
    id: int
    description: str
    owner: str = ""
    collaborator: str = ""
    deadline: str = ""
    priority: str = "中"
    status: str = "待开始"
    notes: str = ""
    related_element: str = ""

    def to_dict(self):
        return {
            'id': self.id,
            'description': self.description,
            'owner': self.owner,
            'collaborator': self.collaborator,
            'deadline': self.deadline,
            'priority': self.priority,
            'status': self.status,
            'notes': self.notes,
            'related_element': self.related_element
        }


@dataclass
class EvaluationDimension:
    """评估维度"""
    dimension: str
    score: int
    problem_description: str = ""
    optimization_suggestion: str = ""
    priority: str = "中"

    def to_dict(self):
        return {
            'dimension': self.dimension,
            'score': self.score,
            'problem_description': self.problem_description,
            'optimization_suggestion': self.optimization_suggestion,
            'priority': self.priority
        }


@dataclass
class OGSMEvaluation:
    """OGSM评估报告"""
    dimensions: List[EvaluationDimension] = field(default_factory=list)
    overall_score: float = 0.0
    summary: str = ""

    def calculate_overall_score(self):
        if self.dimensions:
            self.overall_score = sum(d.score for d in self.dimensions) / len(self.dimensions)
        return self.overall_score


@dataclass
class OGSMData:
    """完整OGSM数据"""
    year: str = ""
    department: str = ""
    quarter: str = ""
    objectives: List[Objective] = field(default_factory=list)
    goals: List[Goal] = field(default_factory=list)
    strategies: List[Strategy] = field(default_factory=list)
    measures: List[Measure] = field(default_factory=list)
    actions: List[Action] = field(default_factory=list)
    evaluation: OGSMEvaluation = field(default_factory=OGSMEvaluation)

    def add_objective(self, obj: Objective):
        self.objectives.append(obj)

    def add_goal(self, goal: Goal):
        self.goals.append(goal)

    def add_strategy(self, strategy: Strategy):
        self.strategies.append(strategy)

    def add_measure(self, measure: Measure):
        self.measures.append(measure)

    def add_action(self, action: Action):
        self.actions.append(action)

    def add_evaluation_dimension(self, dim: EvaluationDimension):
        self.evaluation.dimensions.append(dim)

    def get_objective_by_id(self, obj_id: str) -> Optional[Objective]:
        return next((o for o in self.objectives if o.id == obj_id), None)

    def get_goals_by_objective(self, obj_id: str) -> List[Goal]:
        return [g for g in self.goals if g.objective_id == obj_id]

    def get_strategies_by_goal(self, goal_id: str) -> List[Strategy]:
        return [s for s in self.strategies if s.goal_id == goal_id]

    def get_measures_by_strategy(self, strategy_id: str) -> List[Measure]:
        return [m for m in self.measures if m.strategy_id == strategy_id]
