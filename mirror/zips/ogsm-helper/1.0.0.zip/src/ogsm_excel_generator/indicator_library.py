"""
公司指标体系库 - 指标加载与推荐模块
支持从 Excel (.xlsx) 和 Markdown (.md) 两种格式加载
"""

import os
import re
from dataclasses import dataclass, field
from typing import List, Optional, Tuple


@dataclass
class Indicator:
    """单个指标"""
    module: str
    level: str
    sub_module: str
    name: str
    definition: str
    sheet_name: str

    def to_dict(self):
        return {
            'module': self.module,
            'level': self.level,
            'sub_module': self.sub_module,
            'name': self.name,
            'definition': self.definition,
            'sheet_name': self.sheet_name
        }

    @property
    def level_num(self) -> int:
        try:
            return int(self.level[1:])
        except (ValueError, IndexError):
            return 99


@dataclass
class RecommendationResult:
    """推荐结果"""
    indicator: Indicator
    score: float
    match_reasons: List[str] = field(default_factory=list)

    def to_dict(self):
        return {
            'indicator': self.indicator.to_dict(),
            'score': self.score,
            'match_reasons': self.match_reasons
        }


class IndicatorLibrary:
    """公司指标体系库

    加载优先级：同目录下的 .md 文件 > .xlsx 文件
    """

    def __init__(self, source_path: Optional[str] = None):
        self.project_root = None
        if source_path:
            self._init_from_path(source_path)
        else:
            self._init_auto()

    def _init_auto(self):
        """自动发现指标数据源：优先 .md，其次 .xlsx"""
        self.project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        md_path = os.path.join(self.project_root, '指标体系纯享版.md')
        xlsx_path = os.path.join(self.project_root, '指标体系纯享版.xlsx')

        if os.path.exists(md_path):
            self._init_from_path(md_path)
        elif os.path.exists(xlsx_path):
            self._init_from_path(xlsx_path)
        else:
            raise FileNotFoundError(
                f"未找到指标数据文件，尝试过：\n"
                f"  {md_path}\n"
                f"  {xlsx_path}"
            )

    def _init_from_path(self, path: str):
        """根据文件扩展名自动选择加载方式"""
        self.indicators: List[Indicator] = []
        ext = os.path.splitext(path)[1].lower()
        if ext == '.md':
            self._load_from_markdown(path)
        elif ext == '.xlsx':
            self._load_from_excel(path)
        else:
            raise ValueError(f"不支持的文件格式: {ext}，仅支持 .md 或 .xlsx")
        self._build_index()

    def _load_from_markdown(self, path: str):
        """从 Markdown 文件加载指标数据"""
        with open(path, 'r', encoding='utf-8') as f:
            text = f.read()

        current_sheet = ''
        current_module = ''
        current_sub_module = ''

        for line in text.split('\n'):
            line = line.strip()
            if not line:
                continue

            if line.startswith('## '):
                current_sheet = line[3:].strip()
                continue

            if line.startswith('| 模块 |') or line.startswith('|---'):
                continue

            if line.startswith('| '):
                parts = [p.strip() for p in line.split('|')[1:-1]]
                if len(parts) < 5:
                    continue

                raw_module = self._unescape_md(parts[0])
                level = self._unescape_md(parts[1])
                sub_module = self._unescape_md(parts[2])
                indicator_name = self._unescape_md(parts[3])
                definition = self._unescape_md(parts[4])

                if raw_module:
                    current_module = raw_module
                if sub_module:
                    current_sub_module = sub_module

                if not indicator_name:
                    continue

                indicator_name = self._clean_name(indicator_name)

                self.indicators.append(Indicator(
                    module=current_module,
                    level=level,
                    sub_module=current_sub_module if level else '',
                    name=indicator_name,
                    definition=definition,
                    sheet_name=current_sheet
                ))

    def _unescape_md(self, text: str) -> str:
        """反转 markdown 转义"""
        return text.replace('\\|', '|')

    def _load_from_excel(self, path: str):
        """从 Excel 文件加载指标数据"""
        try:
            from openpyxl import load_workbook
        except ImportError:
            raise ImportError("请安装openpyxl库: pip install openpyxl")

        wb = load_workbook(path, data_only=True)
        for sheet_name in wb.sheetnames:
            self._load_excel_sheet(wb, sheet_name)
        wb.close()

    def _load_excel_sheet(self, wb, sheet_name: str):
        """从单个Sheet加载指标"""
        ws = wb[sheet_name]
        current_module = ''
        current_sub_module = ''

        for r in range(2, ws.max_row + 1):
            col_a = ws.cell(r, 1).value
            col_b = ws.cell(r, 2).value
            col_c = ws.cell(r, 3).value
            col_d = ws.cell(r, 4).value
            col_e = ws.cell(r, 5).value

            if col_a and str(col_a).strip():
                current_module = str(col_a).strip()

            level = str(col_b).strip() if col_b else ''
            if col_c and str(col_c).strip():
                current_sub_module = str(col_c).strip()

            indicator_name = str(col_d).strip() if col_d else ''
            definition = str(col_e).strip() if col_e else ''

            if not indicator_name or indicator_name == 'None':
                continue

            indicator_name = self._clean_name(indicator_name)
            if not indicator_name:
                continue

            self.indicators.append(Indicator(
                module=current_module,
                level=level,
                sub_module=current_sub_module if level else '',
                name=indicator_name,
                definition=definition,
                sheet_name=sheet_name
            ))

    def _clean_name(self, name: str) -> str:
        """清理指标名称中的树形前缀符号"""
        name = re.sub(r'^[│├└\s─]+', '', name)
        name = re.sub(r'\s*其中\s*', '', name)
        return name.strip()

    def _build_index(self):
        """构建检索索引"""
        self._module_index = {}
        self._keyword_index = {}

        for idx, indicator in enumerate(self.indicators):
            if indicator.module not in self._module_index:
                self._module_index[indicator.module] = []
            self._module_index[indicator.module].append(idx)

        for idx, indicator in enumerate(self.indicators):
            keywords = self._extract_keywords(indicator.name)
            for kw in keywords:
                if kw not in self._keyword_index:
                    self._keyword_index[kw] = []
                self._keyword_index[kw].append(idx)

    def _extract_keywords(self, text: str) -> List[str]:
        """从文本中提取搜索关键词"""
        if not text:
            return []
        text = re.sub(r'[()（）\[\]【】{}「」\u201c\u201d\u2018\u2019\s,.，。、；;：:！!？?]+', ' ', text)
        words = text.split()
        keywords = []
        for w in words:
            w = w.strip().lower()
            if len(w) >= 1 and w not in ('的', '了', '在', '是', '和', '与', '或', '及', '每', '等', '个', '该', '其', '之', '为', '按', '均'):
                keywords.append(w)
        return keywords

    def search(self, keyword: str, top_n: int = 10) -> List[Indicator]:
        """按关键词搜索指标"""
        if not keyword:
            return []
        keyword_lower = keyword.strip().lower()
        results = []

        for indicator in self.indicators:
            score = 0
            if keyword_lower in indicator.name.lower():
                score += 3
                pos = indicator.name.lower().find(keyword_lower)
                if pos == 0:
                    score += 1
            if keyword_lower in (indicator.definition or '').lower():
                score += 2
            if keyword_lower in indicator.module.lower():
                score += 1
            if keyword_lower in indicator.sub_module.lower():
                score += 1

            if score > 0:
                results.append((score, indicator))

        results.sort(key=lambda x: x[0], reverse=True)
        return [r[1] for r in results[:top_n]]

    def recommend_by_ogsm(
        self,
        objectives: Optional[List[str]] = None,
        goals: Optional[List[str]] = None,
        strategies: Optional[List[str]] = None,
        measures: Optional[List[str]] = None,
        top_n: int = 15
    ) -> List[RecommendationResult]:
        """基于OGSM上下文推荐适配的公司指标"""
        context_texts = []
        if objectives:
            context_texts.extend(objectives)
        if goals:
            context_texts.extend(goals)
        if strategies:
            context_texts.extend(strategies)
        if measures:
            context_texts.extend(measures)

        combined_text = ' '.join(context_texts)
        query_keywords = self._tokenize_chinese(combined_text)

        scored = []
        seen_names = set()
        for indicator in self.indicators:
            indicator_text = f"{indicator.module} {indicator.sub_module} {indicator.name} {indicator.definition or ''}"
            indicator_keywords = self._tokenize_chinese(indicator_text)

            score = 0.0
            reasons = []

            for qk in query_keywords:
                if qk in indicator.name:
                    score += 0.3
                if qk in indicator_text:
                    score += 0.1

            common_keywords = set(query_keywords) & set(indicator_keywords)
            score += len(common_keywords) * 0.3

            if score > 0:
                if indicator.name in seen_names:
                    continue
                seen_names.add(indicator.name)
                shared = set(query_keywords) & {'收入', '营收', '回款', '利润', '毛利'}
                if shared and any(k in indicator_text for k in ['收入', '回款', '利润', '毛利']):
                    score += 0.5
                    reasons.append('收入相关指标')

                shared = set(query_keywords) & {'客户', '用户', 'C端', 'B端'}
                if shared and any(k in indicator_text for k in ['客户', '用户', 'C端', 'B端', 'DAU']):
                    score += 0.5
                    reasons.append('客户/用户相关指标')

                shared = set(query_keywords) & {'增长', '活跃', '新增', '新签', '续约'}
                if shared and any(k in indicator_text for k in ['增长', '活跃', '新增', '新签', '续约']):
                    score += 0.5
                    reasons.append('增长/活跃相关指标')

                shared = set(query_keywords) & {'人效', '效率', '成本', '降本'}
                if shared and any(k in indicator_text for k in ['人效', '效率', '成本']):
                    score += 0.5
                    reasons.append('人效/成本相关指标')

                shared = set(query_keywords) & {'转化', '转化率', '率'}
                if shared and any(k in indicator_text for k in ['转化率', '交付率', '接单率']):
                    score += 0.5
                    reasons.append('转化率相关指标')

                shared = set(query_keywords) & {'交付', '招聘', '职位'}
                if shared and any(k in indicator_text for k in ['交付', '招聘', '职位', '面试', '入职']):
                    score += 0.5
                    reasons.append('交付/招聘相关指标')

                shared = set(query_keywords) & {'DAU', '活跃', '渗透'}
                if shared and any(k in indicator_text for k in ['DAU', '活跃', '渗透']):
                    score += 0.5
                    reasons.append('活跃度相关指标')

                scored.append(RecommendationResult(
                    indicator=indicator,
                    score=score,
                    match_reasons=reasons
                ))

        scored.sort(key=lambda x: x.score, reverse=True)
        return scored[:top_n]

    def _tokenize_chinese(self, text: str) -> List[str]:
        """中文分词（简化版：基于字符ngram + 英文分词）"""
        if not text:
            return []
        text = text.lower()
        tokens = []
        tokens.extend(re.findall(r'[a-zA-Z]+', text))
        chinese_parts = re.sub(r'[^\u4e00-\u9fff]+', ' ', text).split()
        for part in chinese_parts:
            if len(part) <= 4:
                tokens.append(part)
            else:
                for i in range(len(part) - 1):
                    tokens.append(part[i:i + 2])
        stopwords = {'的', '了', '在', '是', '和', '与', '或', '及', '每', '等', '个',
                     '该', '其', '之', '为', '按', '均', '将', '以', '通过', '对', '从', '到'}
        tokens = [t for t in tokens if t not in stopwords and len(t) >= 1]
        return list(set(tokens))

    def get_by_module(self, module_keyword: str) -> List[Indicator]:
        """按模块名获取指标"""
        module_keyword_lower = module_keyword.strip().lower()
        results = []
        for indicator in self.indicators:
            if module_keyword_lower in indicator.module.lower():
                results.append(indicator)
        return results

    def get_by_level(self, level: str) -> List[Indicator]:
        """按层级获取指标"""
        return [i for i in self.indicators if i.level == level]

    def get_all_modules(self) -> List[str]:
        """获取所有顶层模块名"""
        modules = []
        for indicator in self.indicators:
            if indicator.module and indicator.module not in modules:
                modules.append(indicator.module)
        return modules

    def get_indicator_tree(self, module_filter: Optional[str] = None) -> dict:
        """获取指标树形结构"""
        tree = {}
        for indicator in self.indicators:
            mod = indicator.module
            if module_filter and module_filter not in mod:
                continue
            if mod not in tree:
                tree[mod] = {'L1': [], 'L2': [], 'L3': [], 'L4': [], 'L5': []}
            if indicator.level in tree[mod]:
                tree[mod][indicator.level].append(indicator.name)
        return tree

    def get_statistics(self) -> dict:
        """获取指标库统计信息"""
        modules = self.get_all_modules()
        levels = {}
        for i in self.indicators:
            levels[i.level] = levels.get(i.level, 0) + 1
        return {
            'total_indicators': len(self.indicators),
            'total_modules': len(modules),
            'modules': modules,
            'by_level': dict(sorted(levels.items())),
            'sheet_source': list(set(i.sheet_name for i in self.indicators))
        }
