"""
OGSM Excel Report Generator
OGSM关键任务分解表生成器
"""

__version__ = "1.1.0"
__author__ = "OGSM Helper"

from .generator import OGSMExcelGenerator
from .models import OGSMData, OGSMEvaluation, Objective, Goal, Strategy, Measure, Action, EvaluationDimension
from .indicator_library import IndicatorLibrary, Indicator, RecommendationResult

__all__ = [
    'OGSMExcelGenerator', 'OGSMData', 'OGSEvaluation',
    'Objective', 'Goal', 'Strategy', 'Measure', 'Action', 'EvaluationDimension',
    'IndicatorLibrary', 'Indicator', 'RecommendationResult'
]
