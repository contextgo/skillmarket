#!/bin/bash
# 微信支付集成 Skill 安装脚本
# Copyright: Tencent Inc. (WeChat Pay)

set -e

SKILL_NAME="wechat-pay-integration"
SKILL_DIR="$HOME/.openclaw/workspace/skills/$SKILL_NAME"

echo ""
echo "═══════════════════════════════════════════════════"
echo "  微信支付集成 Skill"
echo "  WeChat Pay Integration"
echo "═══════════════════════════════════════════════════"
echo ""
echo "  内容版权：腾讯公司（微信支付）"
echo "  客服咨询：95017"
echo ""
echo "═══════════════════════════════════════════════════"
echo ""

# 检查目录是否存在
if [ -d "$SKILL_DIR" ]; then
  echo "📁 Skill 目录已存在，正在更新..."
else
  echo "📁 创建 Skill 目录..."
  mkdir -p "$SKILL_DIR"
fi

# 复制文件
echo "📄 安装 SKILL.md..."
cat > "$SKILL_DIR/SKILL.md" << 'SKILL_EOF'
---
name: wechat-pay-integration
display_name: 微信支付集成
description: 微信支付商户平台接入最佳实践。涵盖JSAPI支付、小程序支付、APP支付、H5支付、Native支付、付款码支付等全场景产品选型与集成指导。
version: 1.0.0
author: 整合者：叶建国 | 内容版权：腾讯公司（微信支付）
homepage: https://pay.weixin.qq.com/
tags:
  - 微信支付
  - 支付集成
  - JSAPI支付
  - 小程序支付
  - Native支付
license: MIT
compatibility:
  - openclaw
  - skillhub
---

# 微信支付集成

> **版权声明**：本 Skill 内容来源于腾讯公司（微信支付）官方文档，版权归属腾讯公司所有。如有疑问可咨询微信支付客服：95017

## 简介

微信支付商户平台接入最佳实践。涵盖 JSAPI支付、小程序支付、APP支付、H5支付、Native支付、付款码支付等全场景产品选型与集成指导。

## 快速决策树

```
用户咨询微信支付接入
        |
        +-- 微信内支付？
        |       +-- 微信小程序内 --> 小程序支付
        |       +-- 微信浏览器内 --> JSAPI支付
        |
        +-- App支付？ --> APP支付
        +-- H5支付？ --> H5支付
        +-- 商家二维码 --> Native支付
        +-- 扫码枪 --> 付款码支付
```

## 版权声明

- **版权归属**：腾讯公司
- **客服热线**：95017
- **官方网站**：https://www.wechatpay.com
- **商户平台**：https://pay.weixin.qq.com

SKILL_EOF

echo ""
echo "═══════════════════════════════════════════════════"
echo "  ✅ 安装完成！"
echo "═══════════════════════════════════════════════════"
echo ""
echo "📚 使用说明："
echo ""
echo "  当用户提到以下关键词时自动触发："
echo "    - 接入微信支付、集成微信支付"
echo "    - 小程序支付、JSAPI支付"
echo "    - APP支付、H5支付"
echo "    - Native支付、付款码支付"
echo ""
echo "📖 完整文档请阅读："
echo "    $SKILL_DIR/SKILL.md"
echo ""
echo "═══════════════════════════════════════════════════"
