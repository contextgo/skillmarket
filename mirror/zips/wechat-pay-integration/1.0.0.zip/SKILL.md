---
name: wechat-pay-integration
display_name: 微信支付集成
description: 微信支付商户平台接入最佳实践。涵盖JSAPI支付、小程序支付、APP支付、H5支付、Native支付、付款码支付等全场景产品选型与集成指导。
version: 1.0.0
author: 整合者：叶建国 | 内容版权：腾讯公司（微信支付）
homepage: https://pay.weixin.qq.com/
tags:
  - 微信支付
  - 支付集成
  - JSAPI支付
  - 小程序支付
  - Native支付
license: MIT
compatibility:
  - openclaw
  - skillhub
---

# 微信支付集成

> **版权声明**：本 Skill 内容来源于腾讯公司（微信支付）官方文档，版权归属腾讯公司所有。如有疑问可咨询微信支付客服：95017
> 
> **Source**: 微信支付商户文档中心
> **Copyright**: Tencent Inc.

---

## 简介

微信支付商户平台接入最佳实践。涵盖 JSAPI支付、小程序支付、APP支付、H5支付、Native支付、付款码支付等全场景产品选型与集成指导。

**适用场景**：当用户提到"接入微信支付"、"集成微信支付"、"对接微信支付"、"微信收款"、"加个微信支付"、"微信下单"、"小程序支付"、"扫码支付"、"Native支付"、"H5支付"、"APP支付"、"付款码"、"Native支付"、"公众号支付"时使用此 Skill。

**不适用场景**：不用于支付宝支付、银联支付、微信转账、对账、红包等非收单场景。

---

## 支付产品一览

微信支付提供以下支付产品：

| 产品 | 场景 | 文档入口 |
|------|------|----------|
| JSAPI支付 | 微信客户端内浏览器网页支付 | [商户文档](https://pay.weixin.qq.com/doc/v3/merchant/4012062524) |
| 小程序支付 | 微信小程序内支付 | [商户文档](https://pay.weixin.qq.com) |
| APP支付 | 原生iOS/Android App支付 | [商户文档](https://pay.weixin.qq.com) |
| H5支付 | 手机浏览器H5支付 | [商户文档](https://pay.weixin.qq.com) |
| Native支付 | 商家生成二维码，用户扫码支付 | [商户文档](https://pay.weixin.qq.com) |
| 付款码支付 | 商家扫码用户付款码 | [商户文档](https://pay.weixin.qq.com) |
| 刷脸支付 | 微信刷脸设备支付 | [商户文档](https://pay.weixin.qq.com) |
| 医保支付 | 医保定点医药机构支付 | [商户文档](https://pay.weixin.qq.com) |

---

## 接入路由表

根据用户的业务场景，路由到对应的产品文档：

| 场景 | 推荐产品 | 接入方式 | 文档 |
|------|----------|----------|------|
| 微信内网页支付 | JSAPI支付 | 公众号/浏览器 | [JSAPI文档](https://pay.weixin.qq.com/doc/v3/merchant/4012062524) |
| 微信小程序内支付 | 小程序支付 | 小程序 | [小程序文档](https://pay.weixin.qq.com) |
| 原生App支付（iOS/Android） | APP支付 | App SDK | [APP文档](https://pay.weixin.qq.com) |
| 手机浏览器H5支付 | H5支付 | H5页面 | [H5文档](https://pay.weixin.qq.com) |
| 商家二维码用户扫码 | Native支付 | 二维码 | [Native文档](https://pay.weixin.qq.com) |
| 商家扫码用户付款码 | 付款码支付 | 扫码枪 | [付款码文档](https://pay.weixin.qq.com) |
| 刷脸设备支付 | 刷脸支付 | 刷脸设备 | [刷脸文档](https://pay.weixin.qq.com) |

---

## 快速决策树

```
用户咨询微信支付接入
        |
        +-- 微信内支付？
        |       +-- 微信小程序内 --> 小程序支付
        |       +-- 微信浏览器内 --> JSAPI支付
        |
        +-- App支付？
        |       +-- 原生iOS/Android App --> APP支付
        |
        +-- H5支付？
        |       +-- 手机浏览器H5 --> H5支付
        |
        +-- 扫码支付？
        |       +-- 商家生成二维码，用户扫 --> Native支付
        |       +-- 商家扫用户付款码 --> 付款码支付
        |
        +-- 特殊场景？
                +-- 刷脸设备 --> 刷脸支付
                +-- 医保定点 --> 医保支付
```

---

## 场景关键词匹配

| 关键词 | 路由产品 |
|--------|----------|
| 微信支付、接入微信支付、集成微信支付、微信收款 | JSAPI/小程序支付 |
| 小程序支付、小程序内支付、微盟小程序、有赞小程序 | 小程序支付 |
| APP支付、iOS支付、Android支付、App内支付、原生App | APP支付 |
| H5支付、WAP支付、手机网页支付、移动端网页 | H5支付 |
| Native支付、二维码支付、扫码支付、商家二维码 | Native支付 |
| 付款码、条码支付、扫码枪、被扫、线下门店 | 付款码支付 |
| 刷脸支付、人脸支付、蜻蜓设备、青蛙设备 | 刷脸支付 |
| 医保支付、医药支付、医保定点、药店支付 | 医保支付 |

---

## 核心API

### JSAPI/小程序支付流程

```javascript
// 1. 商户后端调用下单接口
const orderResult = await wechatPay.unifiedOrder({
  appid: 'wx2421b1c4370ec43b',
  mch_id: '1230000109',
  nonce_str: 'e61463f8efa94090b1f366cccfbbb444',
  body: '商品描述',
  out_trade_no: '20150806125346',
  total_fee: 88,
  spbill_create_ip: '123.12.12.123',
  notify_url: 'https://yourserver.com/notify',
  trade_type: 'JSAPI',
  openid: 'oUpF8uMuAJO_M2pxb1Q9zNjWeS6o'
});

// 2. 获取prepay_id
const prepay_id = orderResult.prepay_id;

// 3. 前端调起支付
WeixinJSBridge.invoke('getBrandWCPayRequest', {
  "appId": "wx2421b1c4370ec43b",
  "timeStamp": "1395712654",
  "nonceStr": "e61463f8efa94090b1f366cccfbbb444",
  "package": "prepay_id=wx21201855730335ac86f8c43d1889123400",
  "signType": "RSA",
  "paySign": "oR9d8PuhnIc+YZ8cBHFCwfgpaK9gd7vaRvk..."
}, function(res){
  if(res.err_msg == "get_brand_wcpay_request:ok"){
    // 支付成功
  }
});
```

---

## 澄清话术

当用户描述模糊时：

```
请确认您的业务场景：

1. 微信内支付
   - 微信小程序内支付 → 小程序支付
   - 微信浏览器内网页支付 → JSAPI支付

2. APP支付
   - 原生 iOS/Android App 内支付 → APP支付

3. H5支付
   - 手机浏览器 H5 页面支付 → H5支付

4. 扫码支付
   - 商家生成二维码，用户扫码 → Native支付
   - 商家扫码枪扫用户付款码 → 付款码支付

5. 特殊场景
   - 刷脸设备支付 → 刷脸支付
   - 医保定点机构 → 医保支付

请描述您的具体业务场景？
```

---

## 接入准备

### 1. 注册商户号

前往 [微信支付商户平台](https://pay.weixin.qq.com) 注册商户账号。

### 2. 获取必要参数

| 参数 | 说明 | 获取方式 |
|------|------|----------|
| appid | 公众号/小程序/应用ID | 微信开放平台 |
| mch_id | 商户号 | 商户平台申请 |
| api_key | API密钥 | 商户平台设置 |
| apiclient_key | 商户私钥 | 商户平台上传 |
| apiclient_cert | 商户证书 | 商户平台下载 |

### 3. 开发接入

```bash
# 微信支付SDK
# Java: https://github.com/WechatPay-Organization/wechatpay-java
# Node.js: https://github.com/WechatPay-Organization/wechatpay-node
# Python: https://github.com/WechatPay-Organization/wechatpay-python
```

---

## 文档资源

| 资源 | 链接 |
|------|------|
| 商户文档中心 | https://pay.weixin.qq.com |
| 产品文档 | https://pay.weixin.qq.com/doc/v3/merchant/4012062524 |
| API列表 | https://pay.weixin.qq.com/doc/v3/merchant/4012791857 |
| 开发工具 | https://pay.weixin.qq.com/wiki/doc/apiv3/index.shtml |
| 开发者社区 | https://developers.weixin.qq.com/community |

---

## 注意事项

- 本 Skill **不支持商家分账/转账到零钱**等产品，如需使用请查阅官方文档。
- 业务咨询和接入问题请查阅 [微信支付商户文档中心](https://pay.weixin.qq.com) 或拨打客服热线。
- 测试阶段建议开发者优先使用沙箱环境。
- 本文档链接均指向微信支付在线文档，内容会动态更新，编写代码前务必阅读最新版本。

---

## 版权声明

本 Skill 的内容来源于 **腾讯公司（微信支付）** 官方商户文档中心。

- **版权归属**：腾讯公司
- **客服热线**：95017
- **官方网站**：https://www.wechatpay.com
- **商户平台**：https://pay.weixin.qq.com
- **在线文档**：https://pay.weixin.qq.com/doc/v3/merchant/4012062524

本整合版仅作技术学习交流使用，原始内容由微信支付官方维护和更新。如有任何疑问或需要商业支持，请直接联系微信支付官方客服。

---

## 更新日志

### v1.0.0 (2026-04-04)
- 整合微信支付商户文档中心内容
- 适配 SkillHub 格式规范
- 添加版权声明和客服信息
