"""Financial data collection package."""
