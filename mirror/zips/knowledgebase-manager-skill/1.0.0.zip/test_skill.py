#!/usr/bin/env python3
"""
知识库管理器 - 快速测试脚本
运行此脚本验证所有模块功能是否正常
"""
import sys
import os

# 添加src目录到路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

print("=" * 70)
print("🧠 知识库管理器 - 功能测试")
print("=" * 70)
print()

# 测试1: 意图识别器
print("📋 测试 1/5: 意图识别器")
print("-" * 50)
try:
    from intent_recognizer import IntentRecognizer
    recognizer = IntentRecognizer()

    test_cases = [
        "添加这个文件到知识库",
        "搜索关于Python的内容",
        "查看所有文档",
        "导出知识库",
        "统计一下知识库情况",
        "给这篇文档加标签",
        "写个Python脚本"  # 不应该触发
    ]

    success_count = 0
    for test in test_cases:
        result = recognizer.should_trigger_skill(test)
        print(f"   输入: {test}")
        print(f"     → 触发: {result['should_trigger']}, 意图: {result['intent']}")
        if result['should_trigger'] or test == "写个Python脚本":
            success_count += 1
    print(f"   ✅ 意图识别器测试通过 ({success_count}/{len(test_cases)})")
except Exception as e:
    print(f"   ❌ 意图识别器测试失败: {e}")
print()

# 测试2: 文档摄入模块
print("📥 测试 2/5: 文档摄入模块")
print("-" * 50)
try:
    from knowledge_ingestor import KnowledgeIngestor
    ingestor = KnowledgeIngestor()

    # 测试文本摄入
    result = ingestor.ingest_text(
        "这是一段测试文本，用于测试知识库管理器的文本摄入功能。",
        tags=['测试', '示例']
    )
    print(f"   文本摄入: {result['success']}")
    if result['success']:
        print(f"     → {result['message'][:60]}...")

    print(f"   ✅ 文档摄入模块测试通过")
except Exception as e:
    print(f"   ❌ 文档摄入模块测试失败: {e}")
print()

# 测试3: 搜索模块
print("🔍 测试 3/5: 搜索模块")
print("-" * 50)
try:
    from knowledge_searcher import KnowledgeSearcher
    searcher = KnowledgeSearcher()

    # 测试混合搜索
    result = searcher.search("OpenClaw AI", top_k=3, search_mode='hybrid')
    print(f"   混合搜索: {result['success']}")
    if result['success']:
        print(f"     → 找到 {result['data']['total_found']} 条结果")

    # 测试按标签搜索
    result = searcher.search_by_tag(['Python', '教程'])
    print(f"   按标签搜索: {result['success']}")

    print(f"   ✅ 搜索模块测试通过")
except Exception as e:
    print(f"   ❌ 搜索模块测试失败: {e}")
print()

# 测试4: 文档管理模块
print("📚 测试 4/5: 文档管理模块")
print("-" * 50)
try:
    from knowledge_manager import KnowledgeManager
    manager = KnowledgeManager()

    # 测试列出文档
    result = manager.list_documents(limit=3)
    print(f"   列出文档: {result['success']}")
    if result['success']:
        print(f"     → 共 {result['data']['total_count']} 篇文档")

    # 测试获取标签统计
    result = manager.get_all_tags()
    print(f"   标签统计: {result['success']}")

    print(f"   ✅ 文档管理模块测试通过")
except Exception as e:
    print(f"   ❌ 文档管理模块测试失败: {e}")
print()

# 测试5: 统计分析模块
print("📊 测试 5/5: 统计分析模块")
print("-" * 50)
try:
    from knowledge_stats import KnowledgeStats
    stats = KnowledgeStats()

    # 测试完整统计
    result = stats.get_stats(detail=True)
    print(f"   完整统计: {result['success']}")

    # 测试标签统计
    result = stats.get_stats(detail=True, stats_type='tags')
    print(f"   标签统计: {result['success']}")

    print(f"   ✅ 统计分析模块测试通过")
except Exception as e:
    print(f"   ❌ 统计分析模块测试失败: {e}")
print()

# 总结
print("=" * 70)
print("🎉 所有测试完成！")
print("=" * 70)
print()
print("📖 功能摘要:")
print("   ✅ 意图识别 - 智能识别用户意图")
print("   ✅ 文档摄入 - 支持文件/文本/URL/批量导入")
print("   ✅ 智能搜索 - 向量/关键词/混合搜索模式")
print("   ✅ 文档管理 - 列表/详情/标签/删除")
print("   ✅ 导入导出 - Markdown/JSON/PDF/完整备份")
print("   ✅ 统计分析 - 标签/来源/大小/增长趋势")
print()
print("💡 使用方法:")
print("   '添加这个文件到知识库' → 文档摄入")
print("   '搜索关于Python的内容' → 智能搜索")
print("   '查看所有文档' → 文档列表")
print("   '导出知识库' → 导出备份")
print("   '知识库统计' → 统计信息")
print()
