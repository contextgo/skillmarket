"""
统计分析模块 - 知识库管理器
提供知识库的各种统计信息和分析报告
"""
import json
import os
from typing import Dict, List, Optional
from datetime import datetime, timedelta
from collections import Counter


class KnowledgeStats:
    """知识库统计分析器"""

    def __init__(self, config_path: Optional[str] = None):
        # 加载配置
        if config_path and os.path.exists(config_path):
            with open(config_path, 'r', encoding='utf-8') as f:
                self.config = json.load(f)
        else:
            self.config = {}

    def get_stats(self, detail: bool = False, stats_type: str = 'all') -> Dict:
        """
        获取知识库统计信息

        Args:
            detail: 是否显示详细统计（默认false）
            stats_type: 统计类型：all/tags/source/size (默认all)

        Returns:
            统计结果
        """
        try:
            # 获取所有文档
            from knowledge_manager import KnowledgeManager
            manager = KnowledgeManager()
            list_result = manager.list_documents(limit=1000)

            if not list_result['success']:
                return list_result

            documents = list_result['data']['documents']

            # 根据类型生成统计
            if stats_type == 'tags':
                return self._get_tag_stats(documents, detail)
            elif stats_type == 'source':
                return self._get_source_stats(documents, detail)
            elif stats_type == 'size':
                return self._get_size_stats(documents, detail)
            else:  # all
                return self._get_all_stats(documents, detail)

        except Exception as e:
            return {
                'success': False,
                'message': f"❌ 获取统计信息时发生错误: {str(e)}",
                'error': str(e)
            }

    def _get_all_stats(self, documents: List[Dict], detail: bool) -> Dict:
        """获取完整的统计信息"""
        # 基础统计
        total_docs = len(documents)
        total_size = sum(d['content_length'] for d in documents)
        total_chunks = sum(d['chunk_count'] for d in documents)
        avg_size = total_size / total_docs if total_docs > 0 else 0

        # 标签统计
        all_tags = []
        for doc in documents:
            all_tags.extend(doc['tags'])
        tag_counts = Counter(all_tags)
        unique_tags = len(tag_counts)

        # 来源统计
        source_counts = Counter(d['source'] for d in documents)
        unique_sources = len(source_counts)

        # 时间统计
        creation_dates = [d['created_at'][:10] for d in documents]
        date_counts = Counter(creation_dates)
        first_date = min(creation_dates) if creation_dates else 'N/A'
        last_date = max(creation_dates) if creation_dates else 'N/A'

        # 生成报告
        message = f"📊 知识库统计概览\n"
        message += f"{'=' * 50}\n\n"

        message += f"📈 基本信息\n"
        message += f"   - 文档总数: {total_docs} 篇\n"
        message += f"   - 总内容大小: {total_size / 1024 / 1024:.2f} MB\n"
        message += f"   - 总分片数量: {total_chunks} 个\n"
        message += f"   - 平均文档大小: {avg_size / 1024:.1f} KB\n"
        message += f"   - 平均每篇分片数: {total_chunks / total_docs:.1f} 个\n\n"

        message += f"🏷️ 标签信息\n"
        message += f"   - 标签总数: {unique_tags} 个\n"
        message += f"   - 平均每篇标签数: {len(all_tags) / total_docs:.1f} 个\n"
        if detail and tag_counts:
            top_tags = tag_counts.most_common(5)
            message += f"   - 热门标签: {', '.join([f'{t}({c})' for t, c in top_tags])}\n"
        message += "\n"

        message += f"📌 来源信息\n"
        message += f"   - 来源总数: {unique_sources} 个\n"
        if detail and source_counts:
            top_sources = source_counts.most_common(3)
            message += f"   - 主要来源: {', '.join([f'{s}({c})' for s, c in top_sources])}\n"
        message += "\n"

        message += f"📅 时间信息\n"
        message += f"   - 首篇文档: {first_date}\n"
        message += f"   - 最新文档: {last_date}\n"
        if detail:
            recent_days = 7
            recent_date = (datetime.now() - timedelta(days=recent_days)).strftime('%Y-%m-%d')
            recent_count = sum(1 for d in creation_dates if d >= recent_date)
            message += f"   - 近7天新增: {recent_count} 篇\n"

        return {
            'success': True,
            'message': message,
            'data': {
                'total_docs': total_docs,
                'total_size_bytes': total_size,
                'total_chunks': total_chunks,
                'avg_size_bytes': avg_size,
                'unique_tags': unique_tags,
                'unique_sources': unique_sources,
                'first_date': first_date,
                'last_date': last_date,
                'tag_counts': dict(tag_counts),
                'source_counts': dict(source_counts)
            }
        }

    def _get_tag_stats(self, documents: List[Dict], detail: bool) -> Dict:
        """获取标签统计"""
        all_tags = []
        for doc in documents:
            all_tags.extend(doc['tags'])

        tag_counts = Counter(all_tags)
        unique_tags = len(tag_counts)

        if not tag_counts:
            return {
                'success': True,
                'message': "🏷️ 知识库中暂无标签",
                'data': {'unique_tags': 0, 'tag_counts': {}}
            }

        # 生成报告
        message = f"🏷️ 知识库标签统计\n"
        message += f"{'=' * 50}\n\n"
        message += f"📊 标签总数: {unique_tags} 个\n"
        message += f"📊 标签使用总次数: {len(all_tags)} 次\n"
        message += f"📊 平均每篇文档标签数: {len(all_tags) / len(documents):.1f} 个\n\n"

        if detail or unique_tags <= 20:
            message += f"📋 标签详情:\n"
            sorted_tags = tag_counts.most_common()
            max_count = max(tag_counts.values())

            for tag, count in sorted_tags:
                bar_length = int(count / max_count * 30)
                bar = '█' * bar_length
                percentage = count / len(documents) * 100
                message += f"   {bar} {tag}: {count} 篇 ({percentage:.1f}%)\n"
        else:
            top_tags = tag_counts.most_common(10)
            message += f"🔥 TOP 10 热门标签:\n"
            for i, (tag, count) in enumerate(top_tags, 1):
                message += f"   {i:2d}. {tag}: {count} 篇\n"

        return {
            'success': True,
            'message': message,
            'data': {
                'unique_tags': unique_tags,
                'total_tag_uses': len(all_tags),
                'tag_counts': dict(tag_counts)
            }
        }

    def _get_source_stats(self, documents: List[Dict], detail: bool) -> Dict:
        """获取来源统计"""
        source_counts = Counter(d['source'] for d in documents)
        unique_sources = len(source_counts)

        if not source_counts:
            return {
                'success': True,
                'message': "📌 知识库中暂无来源信息",
                'data': {'unique_sources': 0, 'source_counts': {}}
            }

        # 生成报告
        message = f"📌 知识库来源统计\n"
        message += f"{'=' * 50}\n\n"
        message += f"📊 来源总数: {unique_sources} 个\n\n"

        if detail or unique_sources <= 15:
            message += f"📋 来源详情:\n"
            sorted_sources = source_counts.most_common()
            max_count = max(source_counts.values())

            for source, count in sorted_sources:
                bar_length = int(count / max_count * 30)
                bar = '█' * bar_length
                percentage = count / len(documents) * 100
                message += f"   {bar} {source}: {count} 篇 ({percentage:.1f}%)\n"
        else:
            top_sources = source_counts.most_common(10)
            message += f"🔥 TOP 10 主要来源:\n"
            for i, (source, count) in enumerate(top_sources, 1):
                percentage = count / len(documents) * 100
                message += f"   {i:2d}. {source}: {count} 篇 ({percentage:.1f}%)\n"

        return {
            'success': True,
            'message': message,
            'data': {
                'unique_sources': unique_sources,
                'source_counts': dict(source_counts)
            }
        }

    def _get_size_stats(self, documents: List[Dict], detail: bool) -> Dict:
        """获取大小分布统计"""
        if not documents:
            return {
                'success': True,
                'message': "📦 知识库中暂无文档",
                'data': {}
            }

        # 计算大小分布
        size_ranges = [
            ('< 1 KB', 0, 1024),
            ('1 KB - 10 KB', 1024, 10 * 1024),
            ('10 KB - 50 KB', 10 * 1024, 50 * 1024),
            ('50 KB - 100 KB', 50 * 1024, 100 * 1024),
            ('> 100 KB', 100 * 1024, float('inf'))
        ]

        size_distribution = {}
        for range_name, min_size, max_size in size_ranges:
            count = sum(1 for d in documents if min_size <= d['content_length'] < max_size)
            size_distribution[range_name] = count

        total_size = sum(d['content_length'] for d in documents)
        avg_size = total_size / len(documents)
        max_size = max(d['content_length'] for d in documents)
        min_size = min(d['content_length'] for d in documents)

        # 生成报告
        message = f"📦 知识库大小统计\n"
        message += f"{'=' * 50}\n\n"

        message += f"📊 总体统计:\n"
        message += f"   - 总内容大小: {total_size / 1024 / 1024:.2f} MB ({total_size:,} 字节)\n"
        message += f"   - 平均文档大小: {avg_size / 1024:.1f} KB\n"
        message += f"   - 最大文档: {max_size / 1024:.1f} KB\n"
        message += f"   - 最小文档: {min_size / 1024:.1f} KB\n\n"

        message += f"📈 大小分布:\n"
        max_count = max(size_distribution.values()) if size_distribution else 1

        for range_name, count in size_distribution.items():
            if count > 0:
                bar_length = int(count / max_count * 30)
                bar = '█' * bar_length
                percentage = count / len(documents) * 100
                message += f"   {bar} {range_name}: {count} 篇 ({percentage:.1f}%)\n"

        if detail:
            # 分片统计
            total_chunks = sum(d['chunk_count'] for d in documents)
            avg_chunks = total_chunks / len(documents)
            message += f"\n🧩 分片统计:\n"
            message += f"   - 总分片数: {total_chunks} 个\n"
            message += f"   - 平均每篇分片数: {avg_chunks:.1f} 个\n"
            message += f"   - 平均分片大小: {total_size / total_chunks / 1024:.1f} KB\n"

        return {
            'success': True,
            'message': message,
            'data': {
                'total_size_bytes': total_size,
                'avg_size_bytes': avg_size,
                'max_size_bytes': max_size,
                'min_size_bytes': min_size,
                'size_distribution': size_distribution
            }
        }

    def get_growth_trend(self, days: int = 30) -> Dict:
        """
        获取知识库增长趋势

        Args:
            days: 统计天数（默认30天）

        Returns:
            增长趋势结果
        """
        try:
            # 获取所有文档
            from knowledge_manager import KnowledgeManager
            manager = KnowledgeManager()
            list_result = manager.list_documents(limit=1000)

            if not list_result['success']:
                return list_result

            documents = list_result['data']['documents']

            # 按日期统计
            today = datetime.now()
            daily_counts = {}

            for i in range(days):
                date = (today - timedelta(days=i)).strftime('%Y-%m-%d')
                daily_counts[date] = 0

            for doc in documents:
                doc_date = doc['created_at'][:10]
                if doc_date in daily_counts:
                    daily_counts[doc_date] += 1

            # 计算增长统计
            total_in_period = sum(daily_counts.values())
            avg_daily = total_in_period / days

            # 生成趋势图
            message = f"📈 知识库增长趋势（近 {days} 天）\n"
            message += f"{'=' * 50}\n\n"

            message += f"📊 增长统计:\n"
            message += f"   - 新增文档: {total_in_period} 篇\n"
            message += f"   - 日均新增: {avg_daily:.1f} 篇\n\n"

            # 按日期排序显示
            sorted_dates = sorted(daily_counts.keys())
            max_count = max(daily_counts.values()) if daily_counts else 1

            message += f"📅 日增长趋势:\n"
            for date in sorted_dates[-14:]:  # 显示最近14天
                count = daily_counts[date]
                bar_length = int(count / max_count * 20) if max_count > 0 else 0
                bar = '█' * bar_length
                message += f"   {date} {bar} {count} 篇\n"

            return {
                'success': True,
                'message': message,
                'data': {
                    'days': days,
                    'total_in_period': total_in_period,
                    'avg_daily': avg_daily,
                    'daily_counts': daily_counts
                }
            }

        except Exception as e:
            return {
                'success': False,
                'message': f"❌ 获取增长趋势时发生错误: {str(e)}",
                'error': str(e)
            }


# 快速测试
if __name__ == "__main__":
    stats = KnowledgeStats()

    # 测试完整统计
    print("=" * 60)
    print("测试完整统计:")
    print("=" * 60)
    result = stats.get_stats(detail=True)
    print(result['message'])

    # 测试标签统计
    print("=" * 60)
    print("测试标签统计:")
    print("=" * 60)
    result = stats.get_stats(detail=True, stats_type='tags')
    print(result['message'])
