"""
文档摄入模块 - 知识库管理器
支持各种格式的文档摄入和处理
"""
import os
import json
import hashlib
from pathlib import Path
from typing import Dict, List, Optional, Union
import urllib.request
from urllib.parse import urlparse


class KnowledgeIngestor:
    """知识库文档摄入器"""

    def __init__(self, config_path: Optional[str] = None):
        # 加载配置
        if config_path and os.path.exists(config_path):
            with open(config_path, 'r', encoding='utf-8') as f:
                self.config = json.load(f)
        else:
            # 默认配置
            self.config = {
                'ingest': {
                    'auto_dedup': True,
                    'dedup_threshold': 0.9,
                    'supported_formats': ['.md', '.txt', '.pdf', '.docx', '.json', '.py', '.js', '.html']
                }
            }

        self.supported_formats = self.config['ingest']['supported_formats']
        self.ingested_history = {}  # 简单的去重历史

    def ingest_file(self, file_path: str, tags: Optional[List[str]] = None,
                    auto_dedup: Optional[bool] = None) -> Dict:
        """
        摄入单个文件到知识库

        Args:
            file_path: 文件路径
            tags: 标签列表
            auto_dedup: 是否自动去重（默认使用配置值）

        Returns:
            结果字典
        """
        try:
            file_path = os.path.expanduser(file_path)

            if not os.path.exists(file_path):
                return {
                    'success': False,
                    'message': f"❌ 文件不存在: {file_path}",
                    'error': f"File not found: {file_path}",
                    'suggestion': "请检查文件路径是否正确"
                }

            if not os.path.isfile(file_path):
                return {
                    'success': False,
                    'message': f"❌ 路径不是文件: {file_path}",
                    'error': "Not a file",
                    'suggestion': "如果是文件夹，请使用 ingest_folder 方法"
                }

            # 检查文件格式
            file_ext = os.path.splitext(file_path)[1].lower()
            if file_ext not in self.supported_formats:
                return {
                    'success': False,
                    'message': f"❌ 不支持的文件格式: {file_ext}",
                    'error': f"Unsupported format: {file_ext}",
                    'suggestion': f"支持的格式: {', '.join(self.supported_formats)}"
                }

            # 读取文件内容
            content = self._read_file_content(file_path)
            if content is None:
                return {
                    'success': False,
                    'message': "❌ 无法读取文件内容",
                    'error': "Failed to read file content",
                    'suggestion': "请检查文件是否损坏或权限是否正确"
                }

            # 去重检查
            dedup_flag = auto_dedup if auto_dedup is not None else self.config['ingest']['auto_dedup']
            if dedup_flag:
                is_duplicate, dup_info = self._check_duplicate(content, file_path)
                if is_duplicate:
                    return {
                        'success': False,
                        'message': f"⚠️ 检测到重复文档，已跳过: {os.path.basename(file_path)}",
                        'data': {'skipped': True, 'duplicate_info': dup_info}
                    }

            # 调用内置工具摄入
            result = self._call_ingest_tool(content, file_path, tags)

            if result['success']:
                # 记录到去重历史
                content_hash = self._hash_content(content)
                self.ingested_history[content_hash] = {
                    'file_path': file_path,
                    'timestamp': self._get_timestamp()
                }

            return result

        except Exception as e:
            return {
                'success': False,
                'message': f"❌ 摄入文件时发生错误: {str(e)}",
                'error': str(e),
                'suggestion': "请检查文件路径和内容是否正确"
            }

    def ingest_folder(self, folder_path: str, recursive: bool = True,
                      file_filter: Optional[List[str]] = None, tags: Optional[List[str]] = None) -> Dict:
        """
        批量摄入文件夹下的所有文件

        Args:
            folder_path: 文件夹路径
            recursive: 是否递归子文件夹
            file_filter: 文件格式过滤列表（如 ['.md', '.txt']）
            tags: 统一添加的标签

        Returns:
            结果字典
        """
        try:
            folder_path = os.path.expanduser(folder_path)

            if not os.path.exists(folder_path):
                return {
                    'success': False,
                    'message': f"❌ 文件夹不存在: {folder_path}",
                    'error': f"Folder not found: {folder_path}"
                }

            if not os.path.isdir(folder_path):
                return {
                    'success': False,
                    'message': f"❌ 路径不是文件夹: {folder_path}",
                    'error': "Not a directory"
                }

            # 收集所有文件
            files = []
            if recursive:
                for root, dirs, filenames in os.walk(folder_path):
                    for filename in filenames:
                        file_path = os.path.join(root, filename)
                        files.append(file_path)
            else:
                for filename in os.listdir(folder_path):
                    file_path = os.path.join(folder_path, filename)
                    if os.path.isfile(file_path):
                        files.append(file_path)

            # 过滤文件格式
            if file_filter:
                files = [f for f in files if os.path.splitext(f)[1].lower() in file_filter]
            else:
                files = [f for f in files if os.path.splitext(f)[1].lower() in self.supported_formats]

            if not files:
                return {
                    'success': False,
                    'message': "❌ 文件夹中没有找到支持的文件",
                    'data': {'found_count': 0}
                }

            # 批量摄入
            results = {
                'success_count': 0,
                'skipped_count': 0,
                'failed_count': 0,
                'added_docs': [],
                'skipped_docs': [],
                'failed_docs': []
            }

            for file_path in files:
                result = self.ingest_file(file_path, tags, auto_dedup=True)

                if result['success']:
                    results['success_count'] += 1
                    results['added_docs'].append({
                        'path': file_path,
                        'doc_id': result.get('data', {}).get('doc_id')
                    })
                elif result.get('data', {}).get('skipped'):
                    results['skipped_count'] += 1
                    results['skipped_docs'].append(file_path)
                else:
                    results['failed_count'] += 1
                    results['failed_docs'].append({
                        'path': file_path,
                        'error': result.get('error', 'Unknown error')
                    })

            message = f"✅ 批量摄入完成！\n"
            message += f"   - 成功添加: {results['success_count']} 篇\n"
            message += f"   - 跳过重复: {results['skipped_count']} 篇\n"
            if results['failed_count'] > 0:
                message += f"   - 失败: {results['failed_count']} 篇"

            return {
                'success': True,
                'message': message,
                'data': results
            }

        except Exception as e:
            return {
                'success': False,
                'message': f"❌ 批量摄入时发生错误: {str(e)}",
                'error': str(e)
            }

    def ingest_url(self, url: str, tags: Optional[List[str]] = None,
                   fetch_images: bool = False) -> Dict:
        """
        从URL摄入网页内容

        Args:
            url: 网页URL
            tags: 标签列表
            fetch_images: 是否抓取图片

        Returns:
            结果字典
        """
        try:
            # 验证URL
            parsed = urlparse(url)
            if not parsed.scheme or not parsed.netloc:
                return {
                    'success': False,
                    'message': "❌ 无效的URL格式",
                    'error': "Invalid URL format"
                }

            # 简单获取网页内容（实际应使用更完善的抓取工具）
            try:
                headers = {'User-Agent': 'Mozilla/5.0'}
                req = urllib.request.Request(url, headers=headers)
                with urllib.request.urlopen(req, timeout=30) as response:
                    html_content = response.read().decode('utf-8', errors='ignore')
            except Exception as e:
                return {
                    'success': False,
                    'message': f"❌ 无法获取网页内容: {str(e)}",
                    'error': str(e)
                }

            # 提取纯文本（简化处理）
            import re
            # 移除HTML标签
            text_content = re.sub(r'<[^>]+>', '', html_content)
            # 移除多余空白
            text_content = re.sub(r'\s+', ' ', text_content).strip()

            if len(text_content) < 100:
                return {
                    'success': False,
                    'message': "⚠️ 网页内容过短，可能抓取失败",
                    'data': {'content_length': len(text_content)}
                }

            # 调用内置工具摄入
            source_path = f"url:{url}"
            result = self._call_ingest_tool(text_content, source_path, tags)

            return result

        except Exception as e:
            return {
                'success': False,
                'message': f"❌ 从URL摄入时发生错误: {str(e)}",
                'error': str(e)
            }

    def ingest_text(self, text: str, source_name: str = "direct_input",
                    tags: Optional[List[str]] = None) -> Dict:
        """
        直接摄入文本内容

        Args:
            text: 文本内容
            source_name: 来源名称
            tags: 标签列表

        Returns:
            结果字典
        """
        try:
            if not text or len(text.strip()) < 10:
                return {
                    'success': False,
                    'message': "❌ 文本内容过短，请提供更多内容",
                    'error': "Content too short"
                }

            # 去重检查
            if self.config['ingest']['auto_dedup']:
                is_duplicate, dup_info = self._check_duplicate(text, source_name)
                if is_duplicate:
                    return {
                        'success': False,
                        'message': "⚠️ 检测到重复内容，已跳过",
                        'data': {'skipped': True, 'duplicate_info': dup_info}
                    }

            # 调用内置工具摄入
            result = self._call_ingest_tool(text, source_name, tags)

            return result

        except Exception as e:
            return {
                'success': False,
                'message': f"❌ 摄入文本时发生错误: {str(e)}",
                'error': str(e)
            }

    def _read_file_content(self, file_path: str) -> Optional[str]:
        """读取文件内容"""
        file_ext = os.path.splitext(file_path)[1].lower()

        try:
            # 文本格式直接读取
            if file_ext in ['.md', '.txt', '.py', '.js', '.html', '.json']:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    return f.read()

            # PDF需要特殊处理（这里简化，实际应使用PDF解析库）
            elif file_ext == '.pdf':
                return f"[PDF文件: {os.path.basename(file_path)}]"

            # DOCX需要特殊处理
            elif file_ext == '.docx':
                return f"[DOCX文件: {os.path.basename(file_path)}]"

            return None

        except Exception:
            return None

    def _hash_content(self, content: str) -> str:
        """计算内容的哈希值用于去重"""
        return hashlib.md5(content.encode('utf-8')).hexdigest()

    def _check_duplicate(self, content: str, source: str) -> tuple:
        """检查内容是否重复"""
        content_hash = self._hash_content(content)

        if content_hash in self.ingested_history:
            dup_info = self.ingested_history[content_hash]
            return True, dup_info

        return False, None

    def _get_timestamp(self) -> str:
        """获取当前时间戳"""
        from datetime import datetime
        return datetime.now().isoformat()

    def _call_ingest_tool(self, content: str, source_path: str,
                          tags: Optional[List[str]] = None) -> Dict:
        """
        调用内置的knowledgebase-ingest工具

        注意：实际使用时，此处应调用OpenClaw的内置工具
        这里提供模拟实现用于演示
        """
        try:
            # 模拟调用内置工具
            # 实际应使用: subprocess调用或直接调用SDK

            # 生成模拟的文档ID
            import uuid
            doc_id = str(uuid.uuid4())

            # 准备元数据
            metadata = {
                'source': source_path,
                'tags': tags or [],
                'imported_at': self._get_timestamp(),
                'content_length': len(content)
            }

            # 模拟成功（实际这里应调用真正的摄入工具）
            return {
                'success': True,
                'message': f"✅ 文档已成功添加到知识库！\n"
                          f"   - 来源: {os.path.basename(source_path) if os.path.exists(source_path) else source_path}\n"
                          f"   - 内容长度: {len(content)} 字符\n"
                          f"   - 标签: {', '.join(tags) if tags else '无'}\n"
                          f"   - 文档ID: {doc_id[:8]}...",
                'data': {
                    'doc_id': doc_id,
                    'metadata': metadata
                }
            }

        except Exception as e:
            return {
                'success': False,
                'message': f"❌ 调用知识库工具失败: {str(e)}",
                'error': str(e)
            }


# 快速测试
if __name__ == "__main__":
    ingestor = KnowledgeIngestor()

    # 测试文本摄入
    result = ingestor.ingest_text(
        "这是一段测试文本，用于测试知识库管理器的文本摄入功能。",
        tags=['测试', '示例']
    )
    print("文本摄入测试:")
    print(result['message'])
    print()

    # 测试意图识别器
    from intent_recognizer import IntentRecognizer
    recognizer = IntentRecognizer()
    result = recognizer.should_trigger_skill("添加这个文件到知识库")
    print("意图识别测试:")
    print(f"  触发: {result['should_trigger']}")
    print(f"  意图: {result['intent']}")
