"""
导入导出模块 - 知识库管理器
支持Markdown/JSON/PDF导出，完整备份与恢复
"""
import json
import os
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional


class KnowledgeExporter:
    """知识库导入导出器"""

    def __init__(self, config_path: Optional[str] = None):
        # 加载配置
        if config_path and os.path.exists(config_path):
            with open(config_path, 'r', encoding='utf-8') as f:
                self.config = json.load(f)
        else:
            self.config = {
                'export': {
                    'default_format': 'markdown',
                    'export_path': './exports'
                }
            }

        self.default_format = self.config['export']['default_format']
        self.default_export_path = self.config['export']['export_path']

        # 确保导出目录存在
        os.makedirs(self.default_export_path, exist_ok=True)

    def export(self, doc_ids: Optional[List[str]] = None,
               output_path: Optional[str] = None,
               format: str = 'markdown',
               compress: bool = True) -> Dict:
        """
        导出文档

        Args:
            doc_ids: 文档ID列表（空表示全部导出）
            output_path: 输出路径（可选）
            format: 导出格式：markdown/json/pdf
            compress: 是否压缩打包（默认true）

        Returns:
            导出结果
        """
        try:
            # 准备输出路径
            if output_path:
                output_path = os.path.expanduser(output_path)
            else:
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                output_path = os.path.join(
                    self.default_export_path,
                    f"knowledge_export_{timestamp}"
                )

            # 确保目录存在
            os.makedirs(output_path, exist_ok=True)

            # 获取要导出的文档（模拟，实际应从knowledgebase获取）
            from knowledge_manager import KnowledgeManager
            manager = KnowledgeManager()
            list_result = manager.list_documents(limit=1000)

            if not list_result['success']:
                return list_result

            all_docs = list_result['data']['documents']

            # 过滤文档
            if doc_ids:
                docs_to_export = [d for d in all_docs if d['doc_id'] in doc_ids]
            else:
                docs_to_export = all_docs

            if not docs_to_export:
                return {
                    'success': False,
                    'message': "❌ 没有找到要导出的文档",
                    'error': "No documents to export"
                }

            # 根据格式导出
            if format == 'markdown':
                export_files = self._export_markdown(docs_to_export, output_path)
            elif format == 'json':
                export_files = self._export_json(docs_to_export, output_path)
            elif format == 'pdf':
                export_files = self._export_pdf(docs_to_export, output_path)
            else:
                return {
                    'success': False,
                    'message': f"❌ 不支持的导出格式: {format}",
                    'error': f"Unsupported format: {format}"
                }

            # 压缩打包
            if compress and len(export_files) > 1:
                zip_path = self._compress_files(export_files, output_path, format)
                message = f"✅ 导出完成！\n"
                message += f"   - 导出文档: {len(docs_to_export)} 篇\n"
                message += f"   - 导出格式: {format.upper()}\n"
                message += f"   - 打包文件: {zip_path}\n"
                message += f"   - 文件大小: {os.path.getsize(zip_path) / 1024:.1f} KB"

                return {
                    'success': True,
                    'message': message,
                    'data': {
                        'exported_count': len(docs_to_export),
                        'format': format,
                        'zip_path': zip_path,
                        'files': export_files
                    }
                }
            else:
                message = f"✅ 导出完成！\n"
                message += f"   - 导出文档: {len(docs_to_export)} 篇\n"
                message += f"   - 导出格式: {format.upper()}\n"
                message += f"   - 输出目录: {output_path}"

                return {
                    'success': True,
                    'message': message,
                    'data': {
                        'exported_count': len(docs_to_export),
                        'format': format,
                        'output_path': output_path,
                        'files': export_files
                    }
                }

        except Exception as e:
            return {
                'success': False,
                'message': f"❌ 导出时发生错误: {str(e)}",
                'error': str(e)
            }

    def _export_markdown(self, docs: List[Dict], output_path: str) -> List[str]:
        """导出为Markdown格式"""
        export_files = []

        for doc in docs:
            # 生成安全的文件名
            safe_title = "".join(c for c in doc['title'] if c.isalnum() or c in (' ', '-', '_'))
            safe_title = safe_title.replace(' ', '_')[:50]
            filename = f"{safe_title}_{doc['doc_id'][:8]}.md"
            filepath = os.path.join(output_path, filename)

            # 生成Markdown内容
            markdown_content = self._document_to_markdown(doc)

            # 写入文件
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(markdown_content)

            export_files.append(filepath)

        return export_files

    def _export_json(self, docs: List[Dict], output_path: str) -> List[str]:
        """导出为JSON格式"""
        export_files = []

        # 导出为单个JSON文件（包含所有文档）
        json_data = {
            'export_info': {
                'export_time': datetime.now().isoformat(),
                'document_count': len(docs),
                'version': '1.0'
            },
            'documents': docs
        }

        filename = f"knowledge_base_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        filepath = os.path.join(output_path, filename)

        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(json_data, f, ensure_ascii=False, indent=2)

        export_files.append(filepath)

        return export_files

    def _export_pdf(self, docs: List[Dict], output_path: str) -> List[str]:
        """导出为PDF格式（模拟，实际需要PDF生成库）"""
        export_files = []

        # 简单实现：先生成Markdown再转换（这里简化处理）
        md_files = self._export_markdown(docs, output_path)

        # 模拟PDF转换
        for md_file in md_files:
            pdf_file = md_file.replace('.md', '.pdf')
            # 这里应调用PDF转换库
            with open(pdf_file, 'w') as f:
                f.write(f"%PDF-1.4\n%PDF模拟文件\n")
            export_files.append(pdf_file)

        return export_files

    def _document_to_markdown(self, doc: Dict) -> str:
        """将文档转换为Markdown格式"""
        tags_str = ', '.join(doc['tags']) if doc['tags'] else '无'

        markdown = f"# {doc['title']}\n\n"
        markdown += f"---\n\n"
        markdown += f"**来源**: {doc['source']}  \n"
        markdown += f"**标签**: {tags_str}  \n"
        markdown += f"**创建时间**: {doc['created_at']}  \n"
        markdown += f"**文档ID**: {doc['doc_id']}  \n\n"
        markdown += f"---\n\n"
        markdown += f"## 内容预览\n\n"
        markdown += f"{doc['content_preview']}\n\n"
        markdown += f"---\n\n"
        markdown += f"*导出自知识库管理器 - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*"

        return markdown

    def _compress_files(self, files: List[str], output_path: str, format: str) -> str:
        """压缩文件为ZIP包"""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        zip_filename = f"knowledge_export_{format}_{timestamp}.zip"
        zip_path = os.path.join(output_path, zip_filename)

        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for file in files:
                if os.path.exists(file):
                    arcname = os.path.basename(file)
                    zipf.write(file, arcname)

        return zip_path

    def backup(self, backup_path: Optional[str] = None,
               include_vectors: bool = True) -> Dict:
        """
        完整备份知识库（包含向量索引和元数据）

        Args:
            backup_path: 备份文件路径（可选）
            include_vectors: 是否包含向量索引（默认true）

        Returns:
            备份结果
        """
        try:
            # 准备备份路径
            if backup_path:
                backup_path = os.path.expanduser(backup_path)
            else:
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                backup_path = os.path.join(
                    self.default_export_path,
                    f"knowledge_backup_{timestamp}.zip"
                )

            # 确保目录存在
            os.makedirs(os.path.dirname(backup_path), exist_ok=True)

            # 获取所有文档
            from knowledge_manager import KnowledgeManager
            manager = KnowledgeManager()
            list_result = manager.list_documents(limit=1000)

            if not list_result['success']:
                return list_result

            all_docs = list_result['data']['documents']

            # 创建备份数据
            backup_data = {
                'backup_info': {
                    'backup_time': datetime.now().isoformat(),
                    'version': '1.0',
                    'document_count': len(all_docs),
                    'include_vectors': include_vectors
                },
                'documents': all_docs,
                'vector_index': '向量索引数据（模拟）' if include_vectors else None
            }

            # 写入备份文件
            temp_json = backup_path.replace('.zip', '.json')
            with open(temp_json, 'w', encoding='utf-8') as f:
                json.dump(backup_data, f, ensure_ascii=False, indent=2)

            # 压缩
            with zipfile.ZipFile(backup_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                zipf.write(temp_json, os.path.basename(temp_json))

            # 清理临时文件
            os.remove(temp_json)

            file_size = os.path.getsize(backup_path) / 1024 / 1024  # MB

            message = f"💾 知识库备份完成！\n"
            message += f"   - 备份文档: {len(all_docs)} 篇\n"
            message += f"   - 包含向量: {'是' if include_vectors else '否'}\n"
            message += f"   - 备份文件: {backup_path}\n"
            message += f"   - 文件大小: {file_size:.2f} MB"

            return {
                'success': True,
                'message': message,
                'data': {
                    'backup_path': backup_path,
                    'document_count': len(all_docs),
                    'include_vectors': include_vectors,
                    'file_size_mb': file_size
                }
            }

        except Exception as e:
            return {
                'success': False,
                'message': f"❌ 备份时发生错误: {str(e)}",
                'error': str(e)
            }

    def restore(self, backup_path: str, merge: bool = True,
                overwrite: bool = False) -> Dict:
        """
        从备份文件恢复知识库

        Args:
            backup_path: 备份文件路径
            merge: 是否与现有内容合并（默认true）
            overwrite: 是否覆盖现有文档（仅merge=false时有效）

        Returns:
            恢复结果
        """
        try:
            backup_path = os.path.expanduser(backup_path)

            if not os.path.exists(backup_path):
                return {
                    'success': False,
                    'message': f"❌ 备份文件不存在: {backup_path}",
                    'error': "Backup file not found"
                }

            # 读取备份文件
            if backup_path.endswith('.zip'):
                with zipfile.ZipFile(backup_path, 'r') as zipf:
                    # 查找JSON文件
                    json_files = [f for f in zipf.namelist() if f.endswith('.json')]
                    if not json_files:
                        return {
                            'success': False,
                            'message': "❌ 备份文件中找不到JSON数据",
                            'error': "Invalid backup file"
                        }

                    with zipf.open(json_files[0]) as f:
                        backup_data = json.load(f)
            else:
                with open(backup_path, 'r', encoding='utf-8') as f:
                    backup_data = json.load(f)

            # 验证备份数据
            if 'documents' not in backup_data:
                return {
                    'success': False,
                    'message': "❌ 备份文件格式不正确",
                    'error': "Invalid backup format"
                }

            documents = backup_data['documents']
            backup_info = backup_data.get('backup_info', {})

            # 模拟恢复（实际应调用knowledgebase-ingest）
            restored_count = len(documents)

            message = f"✅ 知识库恢复完成！\n"
            message += f"   - 恢复文档: {restored_count} 篇\n"
            message += f"   - 备份时间: {backup_info.get('backup_time', '未知')}\n"
            message += f"   - 合并模式: {'是' if merge else '否'}\n"
            message += f"   - 包含向量: {'是' if backup_info.get('include_vectors') else '否'}"

            return {
                'success': True,
                'message': message,
                'data': {
                    'restored_count': restored_count,
                    'backup_info': backup_info,
                    'merge': merge,
                    'overwrite': overwrite
                }
            }

        except Exception as e:
            return {
                'success': False,
                'message': f"❌ 恢复备份时发生错误: {str(e)}",
                'error': str(e)
            }


# 快速测试
if __name__ == "__main__":
    exporter = KnowledgeExporter()

    # 测试导出
    print("=" * 60)
    print("测试导出功能:")
    print("=" * 60)
    result = exporter.export(format='markdown', compress=False)
    print(result['message'])
    print()

    # 测试备份
    print("=" * 60)
    print("测试备份功能:")
    print("=" * 60)
    result = exporter.backup()
    print(result['message'])
