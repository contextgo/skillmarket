"""
意图识别器 - 知识库管理器
识别用户是否在调用知识库管理功能，并提取相应参数
"""
import re
from typing import Dict, List, Optional, Tuple


class IntentRecognizer:
    """知识库管理器意图识别器"""

    def __init__(self):
        self.skill_names = ["知识库管理器", "知识库", "知识管理", "base", "知识"]
        self.skill_nicknames = ["知识库", "知识", "base"]

        # 意图关键词映射
        self.intent_keywords = {
            'ingest_file': ['添加', '加入', '导入', '摄入', '放进', '存到', '保存'],
            'ingest_batch': ['批量', '全部', '所有', '整个文件夹', '批量添加'],
            'ingest_url': ['url', '网页', '网站', '链接', 'http'],
            'search': ['搜索', '查找', '查询', '找一下', '检索'],
            'search_keyword': ['关键词', '全文搜索', '精确匹配'],
            'search_tag': ['标签', 'tag'],
            'list_docs': ['列出', '查看', '显示', '所有文档', '文档列表', '查看文档'],
            'list_by_tag': ['按标签', '标签筛选', '过滤'],
            'doc_detail': ['详情', '详细信息', '看一下'],
            'add_tag': ['加标签', '添加标签', '打上标签'],
            'remove_tag': ['移除标签', '删除标签', '去掉标签'],
            'delete_doc': ['删除', '移除', '删掉', '清除'],
            'delete_batch': ['批量删除', '全部删除', '清空'],
            'delete_all': ['清空', '全部删除', '清空知识库'],
            'export_md': ['导出', '输出', '保存为', '另存为'],
            'export_batch': ['批量导出', '全部导出', '导出所有'],
            'backup': ['备份', '存档', '快照'],
            'restore': ['恢复', '还原', '导入备份'],
            'stats': ['统计', '统计信息', '概览', '情况'],
            'stats_tags': ['标签统计', '标签分布'],
            'stats_source': ['来源统计', '来源分布'],
            'help': ['帮助', '怎么用', '功能', '有什么用', '使用说明']
        }

        # 意图优先级（数字越小优先级越高）
        self.intent_priority = {
            'delete_all': 1,
            'backup': 2,
            'restore': 2,
            'search': 2,           # 搜索是高频操作，提高优先级
            'stats_tags': 3,
            'stats_source': 3,
            'search_tag': 3,
            'search_keyword': 3,
            'list_by_tag': 3,
            'ingest_batch': 3,
            'delete_batch': 3,
            'export_batch': 3,
            'ingest_url': 4,
            'add_tag': 4,
            'remove_tag': 4,
            'ingest_file': 5,
            'list_docs': 5,
            'doc_detail': 5,
            'delete_doc': 5,
            'export_md': 5,
            'ingest_text': 5,      # 降低文本摄入优先级
            'stats': 6,
            'help': 7
        }

    def should_trigger_skill(self, user_message: str, context: Optional[Dict] = None) -> Dict:
        """
        判断是否应该触发此SKILL，并识别意图

        Args:
            user_message: 用户消息
            context: 上下文信息（可选）

        Returns:
            识别结果字典
        """
        result = {
            'should_trigger': False,
            'confidence': 0.0,
            'trigger_type': None,
            'intent': None,
            'extracted_params': {}
        }

        if not user_message or not isinstance(user_message, str):
            return result

        message_lower = user_message.lower()

        # 1. 检查SKILL名称唤起
        name_confidence = self._check_name_trigger(message_lower)
        if name_confidence > 0:
            result['should_trigger'] = True
            result['confidence'] = name_confidence
            result['trigger_type'] = 'name'

        # 2. 检查关键词唤起（即使没有名称，有明确关键词也触发）
        keyword_confidence = self._check_keyword_trigger(message_lower)
        if keyword_confidence > 0 and keyword_confidence > result['confidence']:
            result['should_trigger'] = True
            result['confidence'] = keyword_confidence
            result['trigger_type'] = 'keyword'

        # 3. 语义匹配（兜底）
        if not result['should_trigger']:
            semantic_confidence = self._check_semantic_trigger(message_lower)
            if semantic_confidence > 0.7:
                result['should_trigger'] = True
                result['confidence'] = semantic_confidence
                result['trigger_type'] = 'semantic'

        # 4. 如果应该触发，识别具体意图并提取参数
        if result['should_trigger']:
            intent, params = self._recognize_intent(user_message, context)
            result['intent'] = intent
            result['extracted_params'] = params

        return result

    def _check_name_trigger(self, message: str) -> float:
        """检查是否通过名称唤起"""
        for name in self.skill_names + self.skill_nicknames:
            if name in message:
                return 1.0
        return 0.0

    def _check_keyword_trigger(self, message: str) -> float:
        """检查是否通过关键词唤起"""
        trigger_phrases = [
            '添加到知识库',
            '存入知识库',
            '搜索知识库',
            '知识库搜索',
            '查看知识库',
            '知识库列表',
            '知识库统计',
            '导出知识库',
            '删除知识库',
            '知识库里'
        ]

        max_confidence = 0.0
        for phrase in trigger_phrases:
            if phrase in message:
                max_confidence = max(max_confidence, 0.95)

        # 检查是否包含核心关键词组合
        if ('知识库' in message or '知识' in message) and (
            '搜索' in message or '添加' in message or '查看' in message or
            '删除' in message or '导出' in message or '统计' in message
        ):
            max_confidence = max(max_confidence, 0.9)

        return max_confidence

    def _check_semantic_trigger(self, message: str) -> float:
        """语义匹配（兜底）"""
        knowledge_related = ['文档', '资料', '内容', '搜索', '查找', '检索', '整理', '归档']
        match_count = sum(1 for word in knowledge_related if word in message)

        if match_count >= 2:
            return 0.75
        elif match_count == 1 and len(message) < 20:
            return 0.6
        return 0.0

    def _recognize_intent(self, message: str, context: Optional[Dict] = None) -> Tuple[str, Dict]:
        """识别具体意图并提取参数"""
        message_lower = message.lower()

        # 按优先级检查每个意图的关键词
        intent_scores = {}

        for intent, keywords in self.intent_keywords.items():
            score = 0
            for keyword in keywords:
                if keyword in message_lower or keyword in message:
                    score += 1
            if score > 0:
                # 应用优先级权重
                priority = self.intent_priority.get(intent, 10)
                weighted_score = score * (10 / priority)
                intent_scores[intent] = weighted_score

        # 特殊规则处理
        # 1. 删除相关
        if '清空' in message and ('知识库' in message or '所有' in message):
            intent_scores['delete_all'] = 100
        elif '批量删除' in message:
            intent_scores['delete_batch'] = 100

        # 2. 备份相关
        if '备份' in message and ('恢复' not in message and '还原' not in message):
            intent_scores['backup'] = 90
        elif '恢复' in message or '还原' in message:
            intent_scores['restore'] = 90

        # 3. 导出相关
        if '全部导出' in message or '导出所有' in message:
            intent_scores['export_batch'] = 90
        elif '批量导出' in message:
            intent_scores['export_batch'] = 90

        # 4. 统计相关
        if '标签统计' in message or '标签分布' in message:
            intent_scores['stats_tags'] = 90
        elif '来源统计' in message or '来源分布' in message:
            intent_scores['stats_source'] = 90

        # 5. 搜索相关
        if ('标签' in message or 'tag' in message) and '搜索' in message:
            intent_scores['search_tag'] = 90
        elif '关键词' in message and '搜索' in message:
            intent_scores['search_keyword'] = 90

        # 6. 摄入相关
        if 'http' in message_lower or 'www' in message_lower:
            intent_scores['ingest_url'] = 85
        elif '批量' in message and ('添加' in message or '导入' in message):
            intent_scores['ingest_batch'] = 85

        # 选择得分最高的意图
        if intent_scores:
            best_intent = max(intent_scores.keys(), key=lambda k: intent_scores[k])
        else:
            # 默认意图
            if '搜索' in message or '查找' in message or '查询' in message:
                best_intent = 'search'
            elif '添加' in message or '导入' in message or '加入' in message:
                best_intent = 'ingest_file'
            elif '查看' in message or '列出' in message:
                best_intent = 'list_docs'
            elif '统计' in message:
                best_intent = 'stats'
            else:
                best_intent = 'help'

        # 提取参数
        params = self._extract_params(message, best_intent, context)

        return best_intent, params

    def _extract_params(self, message: str, intent: str, context: Optional[Dict] = None) -> Dict:
        """根据意图提取参数"""
        params = {}

        # 提取数量参数
        num_match = re.search(r'(\d+)\s*(篇|个|条|条记录)', message)
        if num_match:
            params['limit'] = int(num_match.group(1))
            params['top_k'] = int(num_match.group(1))

        # 提取路径参数
        path_match = re.search(r'[:：]\s*([^\s，。！？]+)', message)
        if path_match:
            params['path'] = path_match.group(1)

        # 提取URL
        url_match = re.search(r'(https?://[^\s，。！？]+)', message)
        if url_match:
            params['url'] = url_match.group(1)

        # 提取标签
        tags = re.findall(r'标签[为是：:]\s*[「"『]?([^」"』，。！？]+)[」"』]?', message)
        if tags:
            params['tags'] = [t.strip() for t in tags[0].split('、')]

        # 根据意图补充特定参数
        if intent == 'search':
            # 提取搜索关键词
            search_keywords = ['搜索', '查找', '查询', '找一下', '检索', '关于']
            clean_message = message
            for kw in search_keywords:
                clean_message = clean_message.replace(kw, '')
            for name in self.skill_names + self.skill_nicknames:
                clean_message = clean_message.replace(name, '')
            clean_message = clean_message.strip('，。！？：: ')
            if clean_message and len(clean_message) > 1:
                params['query'] = clean_message

        elif intent.startswith('ingest'):
            # 提取摄入内容
            if intent == 'ingest_text':
                text_match = re.search(r'[：:](.+)$', message)
                if text_match:
                    params['text'] = text_match.group(1).strip()

        elif intent.startswith('delete'):
            # 提取要删除的文档ID（从上下文）
            if context and 'last_docs' in context:
                params['doc_ids'] = context['last_docs']

        elif intent.startswith('export'):
            # 提取导出格式
            if 'markdown' in message.lower() or 'md' in message.lower():
                params['format'] = 'markdown'
            elif 'json' in message.lower():
                params['format'] = 'json'
            elif 'pdf' in message.lower():
                params['format'] = 'pdf'

        return params


# 快速测试
if __name__ == "__main__":
    recognizer = IntentRecognizer()

    test_cases = [
        "知识库，帮我添加这个文件",
        "搜索关于Python的内容",
        "查看所有文档",
        "导出知识库",
        "帮我把这段话添加到知识库：这是一段测试内容",
        "统计一下知识库情况",
        "给这篇文档加标签Python",
        "搜索标签为AI的文档",
        "备份整个知识库",
        "写个Python脚本"  # 不应该触发
    ]

    for test in test_cases:
        result = recognizer.should_trigger_skill(test)
        print(f"输入: {test}")
        print(f"  触发: {result['should_trigger']}, 置信度: {result['confidence']}")
        print(f"  意图: {result['intent']}")
        print(f"  参数: {result['extracted_params']}")
        print()
