"""
搜索模块 - 知识库管理器
支持向量搜索、关键词搜索、混合搜索等多种搜索模式
"""
import json
import re
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass


@dataclass
class SearchResult:
    """搜索结果数据类"""
    doc_id: str
    title: str
    snippet: str
    source: str
    similarity: float
    tags: List[str]
    created_at: str


class KnowledgeSearcher:
    """知识库搜索器"""

    def __init__(self, config_path: Optional[str] = None):
        # 加载配置
        if config_path and os.path.exists(config_path):
            with open(config_path, 'r', encoding='utf-8') as f:
                self.config = json.load(f)
        else:
            # 默认配置
            self.config = {
                'search': {
                    'default_top_k': 10,
                    'min_similarity': 0.5,
                    'search_mode': 'hybrid'
                }
            }

        self.default_top_k = self.config['search']['default_top_k']
        self.min_similarity = self.config['search']['min_similarity']
        self.default_mode = self.config['search']['search_mode']

    def search(self, query: str, top_k: Optional[int] = None,
               min_score: Optional[float] = None,
               search_mode: Optional[str] = None,
               tag_filter: Optional[List[str]] = None) -> Dict:
        """
        智能搜索知识库

        Args:
            query: 搜索关键词
            top_k: 返回结果数量（默认使用配置值）
            min_score: 最小相似度（默认使用配置值）
            search_mode: 搜索模式：vector/keyword/hybrid（默认使用配置值）
            tag_filter: 标签过滤列表（可选）

        Returns:
            搜索结果字典
        """
        try:
            if not query or len(query.strip()) == 0:
                return {
                    'success': False,
                    'message': "❌ 搜索关键词不能为空",
                    'error': "Empty query"
                }

            top_k = top_k or self.default_top_k
            min_score = min_score or self.min_similarity
            search_mode = search_mode or self.default_mode

            # 根据搜索模式调用不同的搜索方法
            if search_mode == 'vector':
                results = self._vector_search(query, top_k, min_score)
            elif search_mode == 'keyword':
                results = self._keyword_search(query, top_k, min_score)
            else:  # hybrid
                results = self._hybrid_search(query, top_k, min_score)

            # 应用标签过滤
            if tag_filter:
                results = [r for r in results if any(tag in r.tags for tag in tag_filter)]
                results = results[:top_k]

            # 格式化输出
            formatted_results = self._format_results(results, query)

            return {
                'success': True,
                'message': formatted_results['message'],
                'data': {
                    'query': query,
                    'total_found': len(results),
                    'top_k': top_k,
                    'search_mode': search_mode,
                    'results': [self._result_to_dict(r) for r in results]
                }
            }

        except Exception as e:
            return {
                'success': False,
                'message': f"❌ 搜索时发生错误: {str(e)}",
                'error': str(e)
            }

    def _vector_search(self, query: str, top_k: int, min_score: float) -> List[SearchResult]:
        """
        向量搜索（语义相似度搜索）

        注意：实际应调用knowledgebase-search工具，这里提供模拟实现
        """
        # 模拟向量搜索结果
        # 实际应调用: knowledgebase-search(query=query, top_k=top_k, mode='vector')

        mock_results = self._generate_mock_results(query, top_k, 'vector')
        return [r for r in mock_results if r.similarity >= min_score]

    def _keyword_search(self, query: str, top_k: int, min_score: float) -> List[SearchResult]:
        """
        关键词全文搜索

        注意：实际应调用knowledgebase-search工具，这里提供模拟实现
        """
        # 模拟关键词搜索结果
        mock_results = self._generate_mock_results(query, top_k, 'keyword')

        # 关键词匹配得分计算
        query_keywords = set(re.findall(r'\w+', query.lower()))

        for result in mock_results:
            content_lower = (result.title + ' ' + result.snippet).lower()
            match_count = sum(1 for kw in query_keywords if kw in content_lower)
            result.similarity = match_count / len(query_keywords) if query_keywords else 0

        # 按得分排序
        mock_results.sort(key=lambda x: x.similarity, reverse=True)

        return [r for r in mock_results[:top_k] if r.similarity >= min_score]

    def _hybrid_search(self, query: str, top_k: int, min_score: float) -> List[SearchResult]:
        """
        混合搜索（向量 + 关键词，RRF重排序）

        注意：实际应调用knowledgebase-search工具，这里提供模拟实现
        """
        # 获取两种搜索结果
        vector_results = self._vector_search(query, top_k * 2, 0)
        keyword_results = self._keyword_search(query, top_k * 2, 0)

        # RRF (Reciprocal Rank Fusion) 融合排序
        rrf_k = 60
        scores = {}

        for rank, result in enumerate(vector_results):
            doc_id = result.doc_id
            scores[doc_id] = scores.get(doc_id, 0) + 1 / (rrf_k + rank + 1)

        for rank, result in enumerate(keyword_results):
            doc_id = result.doc_id
            scores[doc_id] = scores.get(doc_id, 0) + 1 / (rrf_k + rank + 1)

        # 合并结果并按RRF得分排序
        all_results = {r.doc_id: r for r in vector_results + keyword_results}
        sorted_doc_ids = sorted(scores.keys(), key=lambda x: scores[x], reverse=True)

        # 更新相似度为RRF得分并返回
        results = []
        for doc_id in sorted_doc_ids[:top_k]:
            result = all_results[doc_id]
            result.similarity = scores[doc_id]
            results.append(result)

        return [r for r in results if r.similarity >= min_score / 2]

    def _generate_mock_results(self, query: str, count: int, mode: str) -> List[SearchResult]:
        """生成模拟的搜索结果（用于演示）"""
        import uuid
        from datetime import datetime

        mock_docs = [
            {
                'title': 'OpenClaw 快速入门指南',
                'snippet': 'OpenClaw是一个强大的AI助手框架，支持自定义技能和工具集成。本文档介绍如何快速开始使用OpenClaw。',
                'source': '官方文档',
                'tags': ['OpenClaw', '入门', '教程']
            },
            {
                'title': 'Python 基础教程',
                'snippet': 'Python是一种简单易学的编程语言，广泛应用于数据科学、人工智能、Web开发等领域。',
                'source': '菜鸟教程',
                'tags': ['Python', '编程', '基础']
            },
            {
                'title': '向量数据库原理与应用',
                'snippet': '向量数据库是专门用于存储和查询向量嵌入的数据库，广泛应用于语义搜索、推荐系统等场景。',
                'source': '技术博客',
                'tags': ['向量数据库', 'RAG', 'AI']
            },
            {
                'title': '飞书API开发指南',
                'snippet': '飞书开放平台提供了丰富的API接口，支持开发者构建各种应用和集成。',
                'source': '飞书文档',
                'tags': ['飞书', 'API', '开发']
            },
            {
                'title': 'RAG系统最佳实践',
                'snippet': '检索增强生成（RAG）是目前AI应用的热门技术，本文介绍RAG系统的构建和优化方法。',
                'source': '技术文章',
                'tags': ['RAG', 'AI', '最佳实践']
            }
        ]

        results = []
        query_lower = query.lower()

        for i, doc in enumerate(mock_docs[:count]):
            # 计算模拟的相似度（查询词出现在标题或内容中得分更高）
            title_match = query_lower in doc['title'].lower()
            snippet_match = query_lower in doc['snippet'].lower()
            tag_match = any(query_lower in tag.lower() for tag in doc['tags'])

            base_sim = 0.5 + i * 0.08
            if title_match:
                base_sim += 0.3
            if snippet_match:
                base_sim += 0.15
            if tag_match:
                base_sim += 0.1

            similarity = min(0.99, base_sim)

            results.append(SearchResult(
                doc_id=str(uuid.uuid4()),
                title=doc['title'],
                snippet=doc['snippet'],
                source=doc['source'],
                similarity=similarity,
                tags=doc['tags'],
                created_at=datetime.now().isoformat()
            ))

        return results

    def _format_results(self, results: List[SearchResult], query: str) -> Dict:
        """格式化搜索结果输出"""
        if not results:
            return {
                'message': f"🔍 搜索 '{query}' 未找到匹配的文档\n"
                          f"   建议：尝试使用不同的关键词，或放宽搜索条件"
            }

        message = f"🔍 搜索 '{query}' 找到 {len(results)} 条相关文档：\n\n"

        for i, result in enumerate(results, 1):
            score_bar = self._generate_score_bar(result.similarity)
            tags_str = ', '.join(result.tags) if result.tags else '无'

            message += f"📍 第 {i} 条 (相似度: {score_bar} {result.similarity:.2%})\n"
            message += f"   📄 标题: {result.title}\n"
            message += f"   📝 摘要: {result.snippet[:80]}...\n"
            message += f"   🏷️ 标签: {tags_str}\n"
            message += f"   📌 来源: {result.source}\n\n"

        return {'message': message}

    def _generate_score_bar(self, score: float, length: int = 10) -> str:
        """生成分数进度条"""
        filled = int(score * length)
        bar = '█' * filled + '░' * (length - filled)
        return bar

    def _result_to_dict(self, result: SearchResult) -> Dict:
        """将SearchResult转换为字典"""
        return {
            'doc_id': result.doc_id,
            'title': result.title,
            'snippet': result.snippet,
            'source': result.source,
            'similarity': result.similarity,
            'tags': result.tags,
            'created_at': result.created_at
        }

    def search_by_tag(self, tags: List[str], top_k: Optional[int] = None) -> Dict:
        """
        按标签搜索文档

        Args:
            tags: 标签列表
            top_k: 返回结果数量

        Returns:
            搜索结果字典
        """
        try:
            if not tags:
                return {
                    'success': False,
                    'message': "❌ 请指定要搜索的标签",
                    'error': "No tags specified"
                }

            # 模拟按标签搜索（实际应调用knowledgebase-search的tag_filter参数）
            mock_query = ' '.join(tags)
            results = self._generate_mock_results(mock_query, top_k or self.default_top_k, 'vector')

            # 过滤匹配标签的结果
            matched_results = []
            for result in results:
                if any(tag in result.tags for tag in tags):
                    matched_results.append(result)

            formatted_results = self._format_results(matched_results, f"标签: {', '.join(tags)}")

            return {
                'success': True,
                'message': formatted_results['message'],
                'data': {
                    'query_tags': tags,
                    'total_found': len(matched_results),
                    'results': [self._result_to_dict(r) for r in matched_results]
                }
            }

        except Exception as e:
            return {
                'success': False,
                'message': f"❌ 按标签搜索时发生错误: {str(e)}",
                'error': str(e)
            }

    def keyword_search(self, query: str, top_k: Optional[int] = None) -> Dict:
        """
        精确关键词搜索（便捷方法）

        Args:
            query: 搜索关键词
            top_k: 返回结果数量

        Returns:
            搜索结果字典
        """
        return self.search(query, top_k=top_k, search_mode='keyword')

    def semantic_search(self, query: str, top_k: Optional[int] = None) -> Dict:
        """
        纯语义向量搜索（便捷方法）

        Args:
            query: 搜索关键词
            top_k: 返回结果数量

        Returns:
            搜索结果字典
        """
        return self.search(query, top_k=top_k, search_mode='vector')


# 快速测试
if __name__ == "__main__":
    import os

    searcher = KnowledgeSearcher()

    # 测试混合搜索
    print("=" * 60)
    print("测试混合搜索:")
    print("=" * 60)
    result = searcher.search("OpenClaw AI", top_k=3, search_mode='hybrid')
    print(result['message'])

    # 测试按标签搜索
    print("=" * 60)
    print("测试按标签搜索:")
    print("=" * 60)
    result = searcher.search_by_tag(['Python', '教程'])
    print(result['message'])
