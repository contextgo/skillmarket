"""
文档管理模块 - 知识库管理器
支持文档列表、详情查看、标签管理、删除等功能
"""
import json
import os
from typing import Dict, List, Optional
from dataclasses import dataclass, asdict
from datetime import datetime


@dataclass
class Document:
    """文档数据类"""
    doc_id: str
    title: str
    source: str
    content_preview: str
    tags: List[str]
    created_at: str
    updated_at: str
    content_length: int
    chunk_count: int


class KnowledgeManager:
    """知识库文档管理器"""

    def __init__(self, config_path: Optional[str] = None):
        # 加载配置
        if config_path and os.path.exists(config_path):
            with open(config_path, 'r', encoding='utf-8') as f:
                self.config = json.load(f)
        else:
            self.config = {}

        # 模拟的文档存储（实际应从knowledgebase获取）
        self._mock_docs = self._generate_mock_docs()

    def list_documents(self, limit: int = 20, offset: int = 0,
                       sort_by: str = 'time', tag_filter: Optional[List[str]] = None,
                       source_filter: Optional[List[str]] = None) -> Dict:
        """
        列出知识库中的文档

        Args:
            limit: 每页数量
            offset: 偏移量
            sort_by: 排序字段：time/score/name
            tag_filter: 标签过滤列表
            source_filter: 来源过滤列表

        Returns:
            文档列表结果
        """
        try:
            docs = list(self._mock_docs.values())

            # 应用标签过滤
            if tag_filter:
                docs = [d for d in docs if any(tag in d.tags for tag in tag_filter)]

            # 应用来源过滤
            if source_filter:
                docs = [d for d in docs if any(source in d.source for source in source_filter)]

            # 排序
            if sort_by == 'time':
                docs.sort(key=lambda x: x.created_at, reverse=True)
            elif sort_by == 'name':
                docs.sort(key=lambda x: x.title)
            elif sort_by == 'size':
                docs.sort(key=lambda x: x.content_length, reverse=True)

            # 分页
            total_count = len(docs)
            docs = docs[offset:offset + limit]

            # 格式化输出
            message = self._format_document_list(docs, offset, limit, total_count)

            return {
                'success': True,
                'message': message,
                'data': {
                    'documents': [asdict(d) for d in docs],
                    'total_count': total_count,
                    'offset': offset,
                    'limit': limit,
                    'page': (offset // limit) + 1,
                    'total_pages': (total_count + limit - 1) // limit
                }
            }

        except Exception as e:
            return {
                'success': False,
                'message': f"❌ 获取文档列表时发生错误: {str(e)}",
                'error': str(e)
            }

    def get_document_detail(self, doc_id: str) -> Dict:
        """
        获取单文档详情

        Args:
            doc_id: 文档ID

        Returns:
            文档详情结果
        """
        try:
            if doc_id not in self._mock_docs:
                return {
                    'success': False,
                    'message': f"❌ 找不到文档: {doc_id}",
                    'error': "Document not found"
                }

            doc = self._mock_docs[doc_id]
            message = self._format_document_detail(doc)

            return {
                'success': True,
                'message': message,
                'data': asdict(doc)
            }

        except Exception as e:
            return {
                'success': False,
                'message': f"❌ 获取文档详情时发生错误: {str(e)}",
                'error': str(e)
            }

    def add_tags(self, doc_ids: List[str], tags: List[str]) -> Dict:
        """
        给文档添加标签

        Args:
            doc_ids: 文档ID列表
            tags: 要添加的标签列表

        Returns:
            操作结果
        """
        try:
            success_count = 0
            failed_ids = []

            for doc_id in doc_ids:
                if doc_id in self._mock_docs:
                    for tag in tags:
                        if tag not in self._mock_docs[doc_id].tags:
                            self._mock_docs[doc_id].tags.append(tag)
                    self._mock_docs[doc_id].updated_at = datetime.now().isoformat()
                    success_count += 1
                else:
                    failed_ids.append(doc_id)

            message = f"✅ 标签添加完成！\n"
            message += f"   - 成功更新: {success_count} 篇文档\n"
            message += f"   - 添加标签: {', '.join(tags)}\n"
            if failed_ids:
                message += f"   - 失败: {len(failed_ids)} 篇 (ID不存在)"

            return {
                'success': True,
                'message': message,
                'data': {
                    'success_count': success_count,
                    'failed_ids': failed_ids,
                    'added_tags': tags
                }
            }

        except Exception as e:
            return {
                'success': False,
                'message': f"❌ 添加标签时发生错误: {str(e)}",
                'error': str(e)
            }

    def remove_tags(self, doc_ids: List[str], tags: List[str]) -> Dict:
        """
        移除文档的标签

        Args:
            doc_ids: 文档ID列表
            tags: 要移除的标签列表

        Returns:
            操作结果
        """
        try:
            success_count = 0
            removed_count = 0

            for doc_id in doc_ids:
                if doc_id in self._mock_docs:
                    for tag in tags:
                        if tag in self._mock_docs[doc_id].tags:
                            self._mock_docs[doc_id].tags.remove(tag)
                            removed_count += 1
                    self._mock_docs[doc_id].updated_at = datetime.now().isoformat()
                    success_count += 1

            message = f"✅ 标签移除完成！\n"
            message += f"   - 更新文档: {success_count} 篇\n"
            message += f"   - 移除标签数: {removed_count} 个\n"
            message += f"   - 移除标签: {', '.join(tags)}"

            return {
                'success': True,
                'message': message,
                'data': {
                    'success_count': success_count,
                    'removed_count': removed_count,
                    'removed_tags': tags
                }
            }

        except Exception as e:
            return {
                'success': False,
                'message': f"❌ 移除标签时发生错误: {str(e)}",
                'error': str(e)
            }

    def delete_documents(self, doc_ids: List[str], confirm: bool = False) -> Dict:
        """
        删除文档

        Args:
            doc_ids: 文档ID列表
            confirm: 是否确认删除（删除多个时需要确认）

        Returns:
            操作结果
        """
        try:
            # 需要二次确认的情况
            if len(doc_ids) >= 5 and not confirm:
                return {
                    'success': False,
                    'message': f"⚠️ 即将删除 {len(doc_ids)} 篇文档，请确认后再次执行\n"
                              f"   提示：请再次发送命令并附带'确认删除'",
                    'need_confirm': True
                }

            success_count = 0
            failed_ids = []

            for doc_id in doc_ids:
                if doc_id in self._mock_docs:
                    del self._mock_docs[doc_id]
                    success_count += 1
                else:
                    failed_ids.append(doc_id)

            message = f"✅ 删除完成！\n"
            message += f"   - 成功删除: {success_count} 篇文档\n"
            if failed_ids:
                message += f"   - 失败: {len(failed_ids)} 篇 (ID不存在)"

            return {
                'success': True,
                'message': message,
                'data': {
                    'success_count': success_count,
                    'failed_ids': failed_ids
                }
            }

        except Exception as e:
            return {
                'success': False,
                'message': f"❌ 删除文档时发生错误: {str(e)}",
                'error': str(e)
            }

    def delete_by_condition(self, condition: Dict, confirm: bool = False) -> Dict:
        """
        按条件删除文档

        Args:
            condition: 删除条件（如 {'tags': ['TODO'], 'source': 'test'}）
            confirm: 是否确认删除

        Returns:
            操作结果
        """
        try:
            # 查找匹配的文档
            matching_ids = []
            for doc_id, doc in self._mock_docs.items():
                match = True

                if 'tags' in condition:
                    if not any(tag in doc.tags for tag in condition['tags']):
                        match = False

                if 'source' in condition:
                    if condition['source'] not in doc.source:
                        match = False

                if match:
                    matching_ids.append(doc_id)

            if not matching_ids:
                return {
                    'success': False,
                    'message': "❌ 没有找到匹配条件的文档",
                    'data': {'matching_count': 0}
                }

            # 调用删除方法
            return self.delete_documents(matching_ids, confirm)

        except Exception as e:
            return {
                'success': False,
                'message': f"❌ 按条件删除时发生错误: {str(e)}",
                'error': str(e)
            }

    def get_all_tags(self) -> Dict:
        """
        获取所有标签统计

        Returns:
            标签统计结果
        """
        try:
            tag_counts = {}
            for doc in self._mock_docs.values():
                for tag in doc.tags:
                    tag_counts[tag] = tag_counts.get(tag, 0) + 1

            # 按使用次数排序
            sorted_tags = sorted(tag_counts.items(), key=lambda x: x[1], reverse=True)

            message = f"🏷️ 知识库标签统计（共 {len(sorted_tags)} 个标签）：\n\n"
            for tag, count in sorted_tags:
                bar = '█' * min(count, 20)
                message += f"   {bar} {tag}: {count} 篇\n"

            return {
                'success': True,
                'message': message,
                'data': {
                    'total_tags': len(sorted_tags),
                    'tag_counts': dict(sorted_tags)
                }
            }

        except Exception as e:
            return {
                'success': False,
                'message': f"❌ 获取标签统计时发生错误: {str(e)}",
                'error': str(e)
            }

    def _format_document_list(self, docs: List[Document], offset: int,
                              limit: int, total: int) -> str:
        """格式化文档列表输出"""
        if not docs:
            return "📭 知识库中暂无文档"

        message = f"📚 知识库文档列表（第 {offset // limit + 1} 页，共 {total} 篇）：\n\n"

        for i, doc in enumerate(docs, offset + 1):
            tags_str = ', '.join(doc.tags[:3])
            if len(doc.tags) > 3:
                tags_str += f' 等{len(doc.tags)}个标签'

            message += f"📄 {i}. {doc.title}\n"
            message += f"   🏷️ 标签: {tags_str or '无'}\n"
            message += f"   📌 来源: {doc.source}\n"
            message += f"   📊 大小: {doc.content_length // 1024} KB | {doc.chunk_count} 个分片\n"
            message += f"   🕒 创建: {doc.created_at[:10]}\n\n"

        return message

    def _format_document_detail(self, doc: Document) -> str:
        """格式化文档详情输出"""
        tags_str = ', '.join(doc.tags) if doc.tags else '无'

        message = f"📄 文档详情\n"
        message += f"{'=' * 50}\n"
        message += f"📝 标题: {doc.title}\n"
        message += f"🆔 ID: {doc.doc_id}\n"
        message += f"📌 来源: {doc.source}\n"
        message += f"🏷️ 标签: {tags_str}\n"
        message += f"📊 内容大小: {doc.content_length} 字符 ({doc.content_length // 1024} KB)\n"
        message += f"🧩 分片数量: {doc.chunk_count} 个\n"
        message += f"🕒 创建时间: {doc.created_at}\n"
        message += f"🔄 更新时间: {doc.updated_at}\n"
        message += f"{'=' * 50}\n"
        message += f"📖 内容预览:\n{doc.content_preview}\n"

        return message

    def _generate_mock_docs(self) -> Dict[str, Document]:
        """生成模拟的文档数据（用于演示）"""
        import uuid

        mock_data = [
            {
                'title': 'OpenClaw 快速入门指南',
                'source': '官方文档',
                'content_preview': 'OpenClaw是一个强大的AI助手框架，支持自定义技能和工具集成。本文档介绍如何快速开始使用OpenClaw，包括安装配置、基础使用、技能开发等内容。',
                'tags': ['OpenClaw', '入门', '教程'],
                'content_length': 15420,
                'chunk_count': 8
            },
            {
                'title': 'Python 基础教程',
                'source': '菜鸟教程',
                'content_preview': 'Python是一种简单易学的编程语言，广泛应用于数据科学、人工智能、Web开发等领域。本教程从基础语法开始，逐步深入到高级主题。',
                'tags': ['Python', '编程', '基础'],
                'content_length': 28750,
                'chunk_count': 15
            },
            {
                'title': '向量数据库原理与应用',
                'source': '技术博客',
                'content_preview': '向量数据库是专门用于存储和查询向量嵌入的数据库，广泛应用于语义搜索、推荐系统等场景。本文介绍向量数据库的工作原理和主流产品对比。',
                'tags': ['向量数据库', 'RAG', 'AI'],
                'content_length': 12300,
                'chunk_count': 7
            },
            {
                'title': '飞书API开发指南',
                'source': '飞书文档',
                'content_preview': '飞书开放平台提供了丰富的API接口，支持开发者构建各种应用和集成。包括消息发送、日历管理、文档操作、多维表格等功能。',
                'tags': ['飞书', 'API', '开发'],
                'content_length': 35600,
                'chunk_count': 18
            },
            {
                'title': 'RAG系统最佳实践',
                'source': '技术文章',
                'content_preview': '检索增强生成（RAG）是目前AI应用的热门技术，本文介绍RAG系统的构建和优化方法，包括分块策略、嵌入选择、检索优化等核心要点。',
                'tags': ['RAG', 'AI', '最佳实践'],
                'content_length': 18900,
                'chunk_count': 10
            }
        ]

        docs = {}
        from datetime import timedelta

        for i, data in enumerate(mock_data):
            created_at = (datetime.now() - timedelta(days=i)).isoformat()
            doc_id = str(uuid.uuid4())

            docs[doc_id] = Document(
                doc_id=doc_id,
                title=data['title'],
                source=data['source'],
                content_preview=data['content_preview'],
                tags=data['tags'],
                created_at=created_at,
                updated_at=created_at,
                content_length=data['content_length'],
                chunk_count=data['chunk_count']
            )

        return docs


# 快速测试
if __name__ == "__main__":
    manager = KnowledgeManager()

    # 测试列出文档
    print("=" * 60)
    print("测试列出文档:")
    print("=" * 60)
    result = manager.list_documents(limit=3)
    print(result['message'])

    # 测试获取标签统计
    print("=" * 60)
    print("测试标签统计:")
    print("=" * 60)
    result = manager.get_all_tags()
    print(result['message'])
