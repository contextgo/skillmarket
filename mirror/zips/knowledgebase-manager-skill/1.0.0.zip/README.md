# 🧠 知识库管理器

> 完整的本地知识库管理 SKILL - 让知识管理更高效

## 🌟 功能特性

### 📥 文档摄入
- ✅ 单个文件导入
- ✅ 批量文件夹导入
- ✅ URL网页内容抓取
- ✅ 直接文本内容输入
- ✅ 自动去重检测
- ✅ 多种格式支持（Markdown/TXT/PDF/DOCX/代码等）

### 🔍 智能搜索
- ✅ 语义向量搜索
- ✅ 关键词全文搜索
- ✅ 混合搜索（RRF重排序）
- ✅ 按标签过滤搜索
- ✅ 相似度分数显示
- ✅ 搜索结果高亮

### 📋 文档管理
- ✅ 分页文档列表
- ✅ 多维度排序（时间/名称/大小）
- ✅ 按标签/来源筛选
- ✅ 单文档详情查看
- ✅ 标签管理（添加/移除）
- ✅ 批量/按条件删除

### 📤 导入导出
- ✅ Markdown格式导出
- ✅ JSON格式导出
- ✅ PDF格式导出
- ✅ 批量导出打包
- ✅ 完整备份（含向量）
- ✅ 从备份恢复

### 📊 统计分析
- ✅ 知识库概览统计
- ✅ 标签使用分布
- ✅ 文档来源分布
- ✅ 大小分布统计
- ✅ 增长趋势分析
- ✅ 可视化进度条

---

## 📁 项目结构

```
knowledgebase-manager/
├── README.md                          # 本文档
├── SKILL.md                           # SKILL说明文档
├── SKILL_INTERFACE.md                 # Agent调用接口文档
├── test_skill.py                      # 快速测试脚本
├── src/                               # 核心模块
│   ├── __init__.py
│   ├── intent_recognizer.py           # 意图识别器
│   ├── knowledge_ingestor.py          # 文档摄入模块
│   ├── knowledge_searcher.py          # 搜索模块
│   ├── knowledge_manager.py           # 文档管理模块
│   ├── knowledge_exporter.py          # 导入导出模块
│   └── knowledge_stats.py             # 统计分析模块
├── data/                              # 数据和配置
│   └── config.json                    # 配置文件
└── exports/                           # 导出文件目录（自动创建）
```

---

## 🚀 快速开始

### 1. 运行测试

```bash
cd ~/.openclaw/workspace/skills/knowledgebase-manager
python test_skill.py
```

### 2. 自然语言使用

只要在对话中提到相关关键词，SKILL会自动触发：

| 功能 | 触发指令示例 |
|------|------------|
| 添加文件 | "把这个文档添加到知识库" |
| 批量导入 | "批量添加这个文件夹下的所有文档" |
| 智能搜索 | "搜索关于Python的内容" |
| 列出文档 | "查看知识库所有文档" |
| 标签管理 | "给这篇文档加标签'Python'" |
| 导出备份 | "把整个知识库导出为Markdown" |
| 统计信息 | "查看知识库统计信息" |
| 帮助 | "知识库有什么功能" |

### 3. 名称唤起

直接使用SKILL名称唤起：

```
"知识库，帮我添加这个文件"
"知识库管理器，搜索关于AI的内容"
"base，导出所有数据"
```

---

## 📖 核心模块说明

### 意图识别器 (IntentRecognizer)
智能识别用户意图，支持：
- 名称唤起触发
- 关键词触发
- 语义匹配触发
- 参数自动提取
- 10+种意图识别

### 文档摄入器 (KnowledgeIngestor)
处理各种来源的文档导入：
- 文件格式检测和转换
- 内容哈希去重
- 标签自动提取
- 批量导入进度跟踪

### 智能搜索器 (KnowledgeSearcher)
多模式搜索支持：
- 向量语义搜索（理解上下文）
- 关键词精确匹配
- 混合RRF重排序
- 标签/来源过滤

### 文档管理器 (KnowledgeManager)
完整的CRUD操作：
- 分页列表和排序
- 标签管理系统
- 条件删除
- 回收站机制

### 导入导出器 (KnowledgeExporter)
多种格式支持：
- Markdown导出（带元数据）
- JSON结构化导出
- 完整ZIP备份
- 增量恢复支持

### 统计分析器 (KnowledgeStats)
全方位数据分析：
- 基础统计指标
- 标签云分布
- 来源占比分析
- 增长趋势图表

---

## ⚙️ 配置说明

编辑 `data/config.json` 自定义行为：

```json
{
  "skill": {
    "name": "知识库管理器",
    "nicknames": ["知识库", "知识管理", "base", "知识"]
  },
  "ingest": {
    "auto_dedup": true,           // 自动去重
    "dedup_threshold": 0.9        // 去重相似度阈值
  },
  "search": {
    "default_top_k": 10,          // 默认返回结果数
    "min_similarity": 0.5,        // 最小相似度
    "search_mode": "hybrid"       // 默认搜索模式
  },
  "export": {
    "default_format": "markdown", // 默认导出格式
    "export_path": "./exports"    // 导出目录
  }
}
```

---

## 🎯 使用示例

### 示例1: 添加文档并搜索

```
用户: 把这个Python教程添加到知识库，标签设为Python、教程
```

→ 自动调用摄入模块，添加标签，返回成功消息

```
用户: 搜索知识库中关于Python性能优化的内容
```

→ 自动调用搜索模块，返回最相关的5篇文档，显示相似度

### 示例2: 批量导出和备份

```
用户: 把所有标签为'AI'的文档导出为Markdown
```

→ 筛选标签为'AI'的文档，批量导出为Markdown并打包

```
用户: 备份整个知识库，包含向量索引
```

→ 创建完整备份ZIP，包含所有文档、向量、元数据

### 示例3: 统计和分析

```
用户: 查看知识库的详细统计信息
```

→ 返回完整统计报告，包含文档数、大小、标签分布、来源统计、增长趋势

---

## 🔌 与内置工具集成

此SKILL基于OpenClaw内置的`knowledgebase-*`工具构建，提供更高级的封装：

| 内置工具 | SKILL增强功能 |
|---------|--------------|
| `knowledgebase-ingest` | 批量导入、自动去重、标签提取、格式转换 |
| `knowledgebase-search` | 混合搜索、标签过滤、结果高亮、分页展示 |
| `knowledgebase-list` | 分类筛选、统计信息、详情展示 |
| `knowledgebase-delete` | 批量删除、按条件删除、回收站 |

---

## 📝 开发说明

### 添加新意图

1. 在 `intent_recognizer.py` 的 `intent_keywords` 中添加关键词
2. 实现对应的处理函数
3. 在 `_recognize_intent()` 中添加分发逻辑

### 添加新导出格式

1. 在 `knowledge_exporter.py` 中添加 `_export_xxx()` 方法
2. 在 `export()` 方法中添加格式分支
3. 更新配置文件支持的格式列表

---

## 📞 故障排除

### 导入失败？
- 检查文件格式是否在支持列表中
- 查看 `data/logs/ingest.log` 日志文件
- 大文件尝试分批导入

### 搜索结果不准确？
- 尝试不同的搜索模式（vector/keyword/hybrid）
- 调整 `min_similarity` 阈值
- 添加更多相关文档训练

### 存储空间不足？
- 清理旧的备份文件
- 删除不需要的文档
- 导出后重新导入优化索引

---

## 📄 许可证

MIT License - 可自由使用和修改

---

## 🤝 贡献

欢迎提交Issue和PR来改进这个SKILL！

---

**💡 开始使用：现在就说"帮我把这个文件添加到知识库"试试看！**
