# 知识库管理器 - SKILL 调用接口文档

## 🎯 概述

用户无需关心底层实现，只需用自然语言对话即可触发所有知识库管理功能。

**SKILL 名称：** 知识库管理器（别名：知识库、知识管理、base、知识）

---

## 📋 调用方式

### 方式 1：名称唤起（推荐）⭐

用户直接在对话中说：

```
"知识库，帮我添加这个文件"
"知识库管理器，搜索关于Python的内容"
"知识，查看所有文档"
"base，导出所有数据"
```

**响应：** 自动识别意图，调用对应功能，返回结果。

---

### 方式 2：关键词触发

用户直接说功能关键词，无需带名称：

```
"添加到知识库"
"搜索知识库"
"查看知识库"
"删除知识库内容"
"知识库统计"
"导出知识库"
```

**响应：** 识别到关键词，自动调用功能。

---

## 🧠 意图识别器

当 Agent 收到用户消息后，调用意图识别器：

```python
from src.intent_recognizer import IntentRecognizer

recognizer = IntentRecognizer()
result = recognizer.should_trigger_skill(user_message, context)
```

**返回结构：**

```python
{
  'should_trigger': bool,      # 是否应该触发此 SKILL
  'confidence': float,         # 置信度 0-1
  'trigger_type': str,         # 'name' / 'keyword' / 'semantic'
  'intent': str,               # 识别出的意图
  'extracted_params': dict     # 提取的参数
}
```

---

## 📋 完整意图清单

| 意图 (intent) | 说明 | 示例指令 | 处理方式 |
|--------------|------|---------|---------|
| `ingest_file` | 添加单个文件 | "把这个文档添加到知识库" | 调用 knowledgebase-ingest |
| `ingest_batch` | 批量添加文件 | "批量添加这个文件夹下的所有文档" | 批量扫描并摄入 |
| `ingest_url` | 从URL导入 | "添加这个网页到知识库" | 抓取网页并摄入 |
| `ingest_text` | 添加文本内容 | "把这段话添加到知识库" | 直接摄入文本 |
| `search` | 智能搜索 | "搜索关于Python的内容" | 调用 knowledgebase-search |
| `search_keyword` | 关键词搜索 | "关键词搜索'性能优化'" | 全文关键词匹配 |
| `search_tag` | 按标签搜索 | "搜索标签为'Python'的文档" | 按标签过滤搜索 |
| `list_docs` | 列出文档 | "查看知识库所有文档" | 调用 knowledgebase-list |
| `list_by_tag` | 按标签筛选 | "显示所有标签为'AI'的文档" | 按标签过滤列表 |
| `doc_detail` | 查看文档详情 | "查看第3个文档的详情" | 显示单文档完整信息 |
| `add_tag` | 添加标签 | "给这篇文档加标签'Python'" | 更新文档标签 |
| `remove_tag` | 移除标签 | "移除标签'TODO'" | 更新文档标签 |
| `delete_doc` | 删除文档 | "删除这篇文档" | 调用 knowledgebase-delete |
| `delete_batch` | 批量删除 | "删除所有标签为'TODO'的文档" | 按条件批量删除 |
| `delete_all` | 清空知识库 | "清空整个知识库" | 删除所有文档（需确认） |
| `export_md` | 导出Markdown | "把这篇文档导出为Markdown" | 单文档导出 |
| `export_batch` | 批量导出 | "把整个知识库导出为Markdown" | 批量导出 |
| `backup` | 完整备份 | "备份整个知识库" | 完整备份（含向量） |
| `restore` | 恢复备份 | "从这个备份恢复知识库" | 从备份恢复 |
| `stats` | 知识库统计 | "查看知识库统计信息" | 生成统计报告 |
| `stats_tags` | 标签分布 | "查看标签分布情况" | 标签统计 |
| `stats_source` | 来源分布 | "查看文档来源分布" | 来源统计 |
| `help` | 帮助说明 | "知识库有什么功能" | 返回功能列表 |
| `unknown` | 未知意图 | 其他指令 | 确认用户需求，或返回帮助 |

---

## 🔧 调用流程

```
用户说一句话
    ↓
🧠 调用意图识别器
    ├─ ❌ should_trigger = False
    │       ↓
    │    不触发此 SKILL，走其他流程
    │
    └─ ✅ should_trigger = True
            ↓
    根据 intent 分发到对应功能模块：
    ├─ ingest_* → 文档摄入模块
    ├─ search* → 搜索模块
    ├─ list_* / doc_detail → 文档管理模块
    ├─ *_tag → 标签管理模块
    ├─ delete_* → 删除模块
    ├─ export_* / backup / restore → 导入导出模块
    ├─ stats* → 统计分析模块
    └─ help → 帮助说明
```

---

## 📝 参数提取规范

### ingest_file - 添加单个文件

```python
# 提取参数
{
  'file_path': str,       # 文件路径（自动从上下文提取）
  'file_content': str,    # 文件内容（可选）
  'tags': list,           # 标签列表（可选）
  'auto_dedup': bool      # 是否自动去重（默认true）
}

# 调用
from src.knowledge_ingestor import KnowledgeIngestor
ingestor = KnowledgeIngestor()
result = ingestor.ingest_file(file_path, tags, auto_dedup)
```

### ingest_batch - 批量添加文件

```python
# 提取参数
{
  'folder_path': str,     # 文件夹路径
  'recursive': bool,      # 是否递归子文件夹（默认true）
  'file_filter': list,    # 文件格式过滤（默认全部支持）
  'tags': list            # 统一添加的标签（可选）
}

# 调用
from src.knowledge_ingestor import KnowledgeIngestor
ingestor = KnowledgeIngestor()
result = ingestor.ingest_folder(folder_path, recursive, file_filter, tags)
```

### ingest_url - 从URL导入

```python
# 提取参数
{
  'url': str,             # 网页URL
  'tags': list,           # 标签列表（可选）
  'fetch_images': bool    # 是否抓取图片（默认false）
}

# 调用
from src.knowledge_ingestor import KnowledgeIngestor
ingestor = KnowledgeIngestor()
result = ingestor.ingest_url(url, tags, fetch_images)
```

### search - 智能搜索

```python
# 提取参数
{
  'query': str,           # 搜索关键词
  'top_k': int,           # 返回结果数量（默认10）
  'min_score': float,     # 最小相似度（默认0.5）
  'search_mode': str,     # 搜索模式：vector/keyword/hybrid（默认hybrid）
  'tag_filter': list      # 标签过滤（可选）
}

# 调用
from src.knowledge_searcher import KnowledgeSearcher
searcher = KnowledgeSearcher()
results = searcher.search(query, top_k, min_score, search_mode, tag_filter)
```

### list_docs - 列出文档

```python
# 提取参数
{
  'limit': int,           # 每页数量（默认20）
  'offset': int,          # 偏移量（默认0）
  'sort_by': str,         # 排序字段：time/score/name（默认time）
  'tag_filter': list,     # 标签过滤（可选）
  'source_filter': list   # 来源过滤（可选）
}

# 调用
from src.knowledge_manager import KnowledgeManager
manager = KnowledgeManager()
docs = manager.list_documents(limit, offset, sort_by, tag_filter, source_filter)
```

### add_tag / remove_tag - 标签管理

```python
# 提取参数
{
  'doc_ids': list,        # 文档ID列表
  'tags': list            # 标签列表
}

# 调用
from src.knowledge_manager import KnowledgeManager
manager = KnowledgeManager()
result = manager.add_tags(doc_ids, tags)  # 或 remove_tags
```

### delete_doc / delete_batch - 删除文档

```python
# 提取参数
{
  'doc_ids': list,        # 文档ID列表（单个删除传[id]）
  'confirm': bool         # 是否确认删除（批量删除需二次确认）
}

# 调用
from src.knowledge_manager import KnowledgeManager
manager = KnowledgeManager()
result = manager.delete_documents(doc_ids, confirm)
```

### export_md / export_batch - 导出

```python
# 提取参数
{
  'doc_ids': list,        # 文档ID列表（空表示全部）
  'output_path': str,     # 输出路径（可选）
  'format': str,          # 格式：markdown/json/pdf（默认markdown）
  'compress': bool        # 是否压缩（默认true）
}

# 调用
from src.knowledge_exporter import KnowledgeExporter
exporter = KnowledgeExporter()
result = exporter.export(doc_ids, output_path, format, compress)
```

### stats - 统计分析

```python
# 提取参数
{
  'detail': bool,         # 是否显示详细统计（默认false）
  'stats_type': str       # 统计类型：all/tags/source/size（默认all）
}

# 调用
from src.knowledge_stats import KnowledgeStats
stats = KnowledgeStats()
result = stats.get_stats(detail, stats_type)
```

---

## 📦 核心模块

| 模块 | 文件 | 功能 |
|------|------|------|
| 意图识别 | `src/intent_recognizer.py` | 识别用户是否在调用此 SKILL |
| 文档摄入 | `src/knowledge_ingestor.py` | 各种格式的文档摄入和处理 |
| 智能搜索 | `src/knowledge_searcher.py` | 向量/关键词/混合搜索 |
| 文档管理 | `src/knowledge_manager.py` | 列表、详情、标签、删除 |
| 导入导出 | `src/knowledge_exporter.py` | Markdown/JSON/PDF导出，备份恢复 |
| 统计分析 | `src/knowledge_stats.py` | 知识库统计和分析报告 |

---

## 🎯 错误处理规范

所有模块统一返回格式：

```python
{
  'success': bool,         # 是否成功
  'message': str,          # 结果消息（用户可见）
  'data': dict/list,       # 返回数据（成功时）
  'error': str,            # 错误信息（失败时）
  'suggestion': str        # 建议操作（失败时）
}
```

**示例 - 成功：**
```python
{
  'success': True,
  'message': "✅ 成功添加 5 篇文档到知识库！",
  'data': {
    'added_count': 5,
    'skipped_count': 2,
    'doc_ids': ["uuid1", "uuid2", ...]
  }
}
```

**示例 - 失败：**
```python
{
  'success': False,
  'message': "❌ 文件格式不支持",
  'error': "Unsupported file format: .exe",
  'suggestion': "支持的格式：.md, .txt, .pdf, .docx, .json"
}
```

---

## ✅ 功能实现状态

- ✅ 文档摄入（单个/批量/URL/文本）
- ✅ 自动去重检测
- ✅ 智能向量搜索
- ✅ 关键词全文搜索
- ✅ 混合搜索模式
- ✅ 文档列表管理（分页/排序/筛选）
- ✅ 标签管理（添加/移除/按标签筛选）
- ✅ 文档删除（单个/批量/按条件）
- ✅ Markdown/JSON导出
- ✅ 完整备份与恢复
- ✅ 知识库统计报告
- ✅ 标签分布统计
- ✅ 来源分布统计
- ✅ 空间占用统计
