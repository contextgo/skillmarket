"""
生成ETF全扫描平台突破形态报告（含K线图）
修复：K线图空白问题 + 声明与代码规则一致
"""

import json, os, datetime

# 动态路径：脚本所在目录的上一级 = workspace根目录
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.abspath(os.path.join(SCRIPT_DIR, '..'))

# 读取全量结果
with open(os.path.join(OUTPUT_DIR, 'full_scan_result.json'), 'r', encoding='utf-8') as f:
    all_results = json.load(f)

# 读取含rows的候选数据
with open(os.path.join(OUTPUT_DIR, 'scan_candidates.json'), 'r', encoding='utf-8') as f:
    candidates = json.load(f)

# 动态获取数据最新日期
all_dates = []
for item in candidates:
    for row in item['rows']:
        all_dates.append(row['date'])
latest_date = max(all_dates) if all_dates else '2026-04-30'
print(f"报告数据截止日期: {latest_date}")

def calc_ema(data, period):
    result = [data[0]]
    k = 2 / (period + 1)
    for i in range(1, len(data)):
        result.append(data[i] * k + result[-1] * (1 - k))
    return result

def date_to_ts(date_str):
    """将 YYYY-MM-DD 转为Unix时间戳（秒）"""
    try:
        return int(datetime.datetime.strptime(date_str, '%Y-%m-%d').timestamp())
    except:
        return 0

# 为每个候选生成K线数据JS
chart_scripts = []
for item in candidates:
    code = item['code']
    name = item['name']
    rows = item['rows']
    platform_high = item['platform_high']

    candle_data = []
    volume_data = []
    for r in rows:
        candle_data.append({
            'time': date_to_ts(r['date']),
            'open': round(r['open'], 4),
            'high': round(r['high'], 4),
            'low': round(r['low'], 4),
            'close': round(r['close'], 4),
        })
        volume_data.append({
            'time': date_to_ts(r['date']),
            'value': round(r['volume'] / 1e8, 4),
            'color': 'rgba(248,81,73,0.5)' if r['close'] >= r['open'] else 'rgba(63,185,80,0.5)',
        })

    closes = [r['close'] for r in rows]
    exp12 = calc_ema(closes, 12)
    exp50 = calc_ema(closes, min(50, len(closes)))

    exp12_data   = [{'time': date_to_ts(rows[i]['date']), 'value': round(exp12[i], 4)} for i in range(len(rows))]
    exp50_data   = [{'time': date_to_ts(rows[i]['date']), 'value': round(exp50[i], 4)} for i in range(len(rows))]
    platform_line = [{'time': date_to_ts(rows[i]['date']), 'value': platform_high} for i in range(len(rows))]

    # 时间范围（加1%边距使边缘不贴边）
    first_ts = date_to_ts(rows[0]['date'])
    last_ts  = date_to_ts(rows[-1]['date'])
    pad = int((last_ts - first_ts) * 0.01) if last_ts > first_ts else 0
    vis_from = first_ts - pad
    vis_to   = last_ts + pad

    js = f'''(function() {{
        var w = document.getElementById('{code}_wrapper');
        if (!w) return;

        // 等高次轮询，直到容器有宽度再初始化（避免clientWidth=0导致空白）
        function initChart() {{
            var cw = w.clientWidth || 380;
            var chart = LightweightCharts.createChart(w, {{
                width: cw,
                height: 280,
                layout: {{ background: {{ type: 'solid', color: '#0d1117' }}, textColor: '#8b949e', fontSize: 11 }},
                grid: {{ vertLines: {{ color: '#21262d' }}, horzLines: {{ color: '#21262d' }} }},
                crosshair: {{ mode: 0 }},
                rightPriceScale: {{ borderColor: '#30363d' }},
                timeScale: {{ borderColor: '#30363d', timeVisible: false, secondsVisible: false, rightOffset: 3, barSpacing: 5 }},
            }});

            var cs = chart.addCandlestickSeries({{
                upColor: '#f85149', downColor: '#3fb950',
                borderUpColor: '#f85149', borderDownColor: '#3fb950',
                wickUpColor: '#f85149', wickDownColor: '#3fb950',
            }});
            cs.setData({json.dumps(candle_data)});

            var vs = chart.addHistogramSeries({{
                priceFormat: {{ type: 'volume' }},
                priceScaleId: 'volume',
            }});
            chart.priceScale('volume').applyOptions({{ scaleMargins: {{ top: 0.78, bottom: 0 }} }});
            vs.setData({json.dumps(volume_data)});

            var e12 = chart.addLineSeries({{ color: '#58a6ff', lineWidth: 1, priceLineVisible: false, lastValueVisible: false }});
            e12.setData({json.dumps(exp12_data)});

            var e50 = chart.addLineSeries({{ color: '#f778ba', lineWidth: 1, priceLineVisible: false, lastValueVisible: false }});
            e50.setData({json.dumps(exp50_data)});

            var pl = chart.addLineSeries({{ color: '#d29922', lineWidth: 2, lineStyle: 2, priceLineVisible: false, lastValueVisible: false }});
            pl.setData({json.dumps(platform_line)});

            // 用数字时间戳强制显示全部K线
            try {{
                chart.timeScale().setVisibleRange({{ from: {vis_from}, to: {vis_to} }});
            }} catch(e) {{
                chart.timeScale().fitContent();
            }}

            // 延迟再fit一次（应对容器尺寸延迟生效）
            setTimeout(function() {{ chart.timeScale().fitContent(); }}, 200);

            window.addEventListener('resize', function() {{
                var cw2 = w.clientWidth || 380;
                chart.applyOptions({{ width: cw2 }});
                try {{ chart.timeScale().setVisibleRange({{ from: {vis_from}, to: {vis_to} }}); }} catch(e) {{}}
            }});
        }}

        // 确保DOM完成布局后再初始化
        if (w.clientWidth > 0) {{
            initChart();
        }} else {{
            var t = setInterval(function() {{
                if (w.clientWidth > 0) {{
                    clearInterval(t);
                    initChart();
                }}
            }}, 50);
        }}
    }})();
    '''
    chart_scripts.append(js)

# ========== 构建HTML ==========
html_parts = []
html_parts.append(f'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ETF平台突破形态全扫描报告</title>
<script src="https://cdn.jsdelivr.net/npm/lightweight-charts@4.1.0/dist/lightweight-charts.standalone.production.js"></script>
<style>
* {{ margin:0; padding:0; box-sizing:border-box; }}
body {{ font-family:-apple-system,"PingFang SC","Microsoft YaHei",sans-serif; background:#0d1117; color:#c9d1d9; padding:16px; max-width:1100px; margin:0 auto; }}
h1 {{ text-align:center; color:#f0f6fc; font-size:22px; margin-bottom:6px; }}
.subtitle {{ text-align:center; color:#8b949e; font-size:13px; margin-bottom:20px; }}
.note {{ background:#161b22; border:1px solid #30363d; border-radius:10px; padding:14px 18px; margin-bottom:20px; font-size:12px; color:#8b949e; line-height:1.7; }}
.note strong {{ color:#d29922; }}

.overview {{ background:#161b22; border:1px solid #30363d; border-radius:10px; padding:16px; margin-bottom:20px; overflow-x:auto; }}
.overview h2 {{ color:#f0f6fc; font-size:16px; margin-bottom:10px; }}
table {{ width:100%; border-collapse:collapse; font-size:11px; }}
th {{ color:#8b949e; font-weight:500; padding:6px 8px; text-align:left; border-bottom:1px solid #30363d; white-space:nowrap; }}
td {{ padding:5px 8px; border-bottom:1px solid #21262d; white-space:nowrap; }}
tr:hover {{ background:#1c2128; }}
.up {{ color:#f85149; }} .down {{ color:#3fb950; }}
.badge {{ display:inline-block; padding:2px 8px; border-radius:10px; font-size:11px; font-weight:600; }}
.badge-AA {{ background:#1a4731; color:#3fb950; }}
.badge-A {{ background:#1a3630; color:#58a6ff; }}
.badge-Bp {{ background:#4d3a08; color:#d29922; }}
.badge-B {{ background:#2d333b; color:#8b949e; }}

.card {{ background:#161b22; border:1px solid #30363d; border-radius:10px; margin-bottom:14px; overflow:hidden; }}
.card-header {{ padding:10px 14px; display:flex; align-items:center; gap:10px; flex-wrap:wrap; border-bottom:1px solid #30363d; }}
.etf-name {{ font-size:15px; font-weight:600; color:#f0f6fc; }}
.etf-code {{ font-size:12px; color:#8b949e; }}
.metrics {{ display:flex; gap:12px; flex-wrap:wrap; padding:8px 14px; background:#0d1117; font-size:11px; }}
.metric {{ text-align:center; min-width:65px; }}
.metric-label {{ color:#8b949e; font-size:9px; }}
.metric-value {{ font-weight:600; font-size:13px; }}
.chart-wrap {{ height:280px; padding:4px; }}
.analysis {{ padding:10px 14px; border-top:1px solid #30363d; font-size:11px; line-height:1.6; }}
.analysis h4 {{ color:#d29922; font-size:12px; margin-bottom:4px; }}
.analysis p {{ color:#8b949e; }}
.legend {{ display:flex; gap:12px; padding:5px 14px; font-size:10px; color:#8b949e; flex-wrap:wrap; }}
.legend-line {{ width:16px; height:2px; display:inline-block; vertical-align:middle; }}

.section-title {{ color:#f0f6fc; font-size:15px; margin:20px 0 12px; padding-left:4px; border-left:3px solid #d29922; }}
</style>
</head>
<body>
<h1>95个ETF「平台突破」形态全扫描报告</h1>
<p class="subtitle">基于科创200参考形态 | 数据截至{latest_date} | 共分析{len(all_results)}个ETF</p>

<div class="note">
<strong>分析方法：</strong>取前<strong>80%</strong>区间最高价作为"前期平台阻力位"，统计触及次数(±2.5%)和持续时间。后<strong>20%</strong>区间验证是否有效突破。
评分维度（满分15分）：平台质量(<strong>最多6分</strong>：触及次数+持续时间，非平台趋势减半) + 突破力度(<strong>最多5分</strong>：创新高+站稳+突破幅度) + 趋势量能(<strong>最多4分</strong>：整体趋势+量比) + 中间段压制加分(<strong>1分</strong>)。
评级标准：<strong>AA≥11分</strong>（且必须为"平台突破"类型）、<strong>A≥9分</strong>（平台突破/微幅突破）、<strong>B+≥6分</strong>（平台突破/微幅突破/平台蓄势）。
<strong>筛选标准：</strong>评分≥5 且 形态类型=平台突破/微幅突破/平台蓄势 且 平台触及次数≥2。
</div>
''')

# === TOP AA级概览 ===
aa_list = [r for r in all_results if r.get('grade') == 'AA' and r.get('pattern_type') in ('平台突破','微幅突破')]
html_parts.append(f'''
<div class="overview">
<h2>TOP推荐 — 真正的平台突破标的 (AA级，共{len(aa_list)}个)</h2>
<table>
<thead><tr><th>#</th><th>ETF名称</th><th>代码</th><th>形态</th><th>平台阻力</th><th>当前价</th><th>突破幅度</th><th>整体涨幅</th><th>触及次数</th><th>持续天数</th><th>量比</th><th>评分</th></tr></thead>
<tbody>
''')
for i, r in enumerate(aa_list[:15]):
    bo_class = 'up' if r['breakout_pct'] > 0 else 'down'
    tr_class = 'up' if r['total_trend_pct'] > 0 else 'down'
    badge_cls = f"badge-{r['grade'].replace('+','p')}"
    html_parts.append(f'''<tr>
        <td>{i+1}</td>
        <td style="color:#f0f6fc;font-weight:600">{r['name']}</td>
        <td>{r['code']}</td>
        <td>{r['pattern_type']}</td>
        <td>{r['platform_high']}</td>
        <td style="color:#f0f6fc">{r['current_close']}</td>
        <td class="{bo_class}">{r['breakout_pct']:+.2f}%</td>
        <td class="{tr_class}">{r['total_trend_pct']:+.2f}%</td>
        <td>{r['platform_touches']}次</td>
        <td>{r['platform_duration_days']}根</td>
        <td>{r['vol_ratio']:.2f}x</td>
        <td><span class="badge {badge_cls}">{r['grade']} {r['score']}</span></td>
    </tr>''')
html_parts.append('</tbody></table></div>')

# A和B+级概览
ab_list = [r for r in all_results if r.get('grade') in ('A','B+') and r.get('score') >= 7]
if ab_list:
    html_parts.append(f'''
<div class="overview">
<h2>值得关注 — A/B+级 (共{len(ab_list)}个)</h2>
<table>
<thead><tr><th>#</th><th>ETF名称</th><th>代码</th><th>形态</th><th>平台阻力</th><th>当前价</th><th>突破%</th><th>趋势%</th><th>触及</th><th>评分</th></tr></thead>
<tbody>
''')
    for i, r in enumerate(ab_list):
        bo_class = 'up' if r['breakout_pct'] > 0 else 'down'
        tr_class = 'up' if r['total_trend_pct'] > 0 else 'down'
        badge_cls = f"badge-{r['grade'].replace('+','p')}"
        html_parts.append(f'''<tr>
            <td>{i+1}</td><td style="color:#f0f6fc">{r['name']}</td><td>{r['code']}</td><td>{r['pattern_type']}</td>
            <td>{r['platform_high']}</td><td>{r['current_close']}</td>
            <td class="{bo_class}">{r['breakout_pct']:+.2f}%</td><td class="{tr_class}">{r['total_trend_pct']:+.2f}%</td>
            <td>{r['platform_touches']}次</td>
            <td><span class="badge {badge_cls}">{r['grade']} {r['score']}</span></td>
        </tr>''')
    html_parts.append('</tbody></table></div>')

# === 逐个K线图 (仅AA+A级) ===
top_candidates = [c for c in candidates if c['score'] >= 9 and c['pattern_type'] in ('平台突破','微幅突破')]

if top_candidates:
    html_parts.append(f'<h3 class="section-title">重点标的K线图 (AA/A级，含平台阻力线和EXP均线)</h3>')

    for item in top_candidates:
        code = item['code']
        name = item['name']
        platform_high = item['platform_high']
        current_c = item['current_close']
        breakout = item['breakout_pct']
        trend = item['total_trend_pct']
        score = item['score']
        grade = item['grade']
        ptype = item['pattern_type']
        touches = item['platform_touches']
        duration = item['platform_duration_days']
        vol_r = item['vol_ratio']

        bo_cls = 'up' if breakout > 0 else 'down'
        tr_cls = 'up' if trend > 0 else 'down'
        badge_cls = f"badge-{grade.replace('+','p')}"

        html_parts.append(f'''
<div class="card">
    <div class="card-header">
        <span class="badge {badge_cls}">{grade} {score}分</span>
        <span class="etf-name">{name}ETF</span>
        <span class="etf-code">{code}</span>
        <span style="font-size:11px;color:#8b949e;margin-left:auto">[{ptype}]</span>
    </div>
    <div class="metrics">
        <div class="metric"><div class="metric-label">平台阻力位</div><div class="metric-value" style="color:#d29922">{platform_high:.3f}</div></div>
        <div class="metric"><div class="metric-label">当前价</div><div class="metric-value">{current_c:.3f}</div></div>
        <div class="metric"><div class="metric-label">突破幅度</div><div class="metric-value {bo_cls}">{breakout:+.2f}%</div></div>
        <div class="metric"><div class="metric-label">整体涨幅</div><div class="metric-value {tr_cls}">{trend:+.2f}%</div></div>
        <div class="metric"><div class="metric-label">平台触及</div><div class="metric-value">{touches}次/{duration}根</div></div>
        <div class="metric"><div class="metric-label">量比</div><div class="metric-value">{vol_r:.2f}x</div></div>
    </div>
    <div class="legend">
        <span><span class="legend-line" style="background:#d29922;border-style:dashed"></span> 阻力线 {platform_high:.3f}</span>
        <span><span class="legend-line" style="background:#58a6ff"></span> EXP12</span>
        <span><span class="legend-line" style="background:#f778ba"></span> EXP50</span>
    </div>
    <div class="chart-wrap" id="{code}_wrapper" style="height:280px"></div>
    <div class="analysis">
        <h4>形态解读</h4>
        <p>前<strong>80%</strong>区间的平台高点在 <b style="color:#d29922">{platform_high:.3f}</b> 附近，共有 <b>{touches}</b> 根K线的最高价触及该区域(±2.5%)，平台持续约 <b>{duration}</b> 个交易日。{"后段成功放量突破并站稳其上" if breakout > 0.5 else "当前价格接近但尚未完全突破"}。整体趋势{'+' if trend > 0 else ''}{trend:.2f}%，成交量较前期{'放大' if vol_r > 1.1 else '持平或萎缩'}。</p>
    </div>
</div>
''')

# 结尾总结
aa_count = len([r for r in all_results if r.get('grade') == 'AA'])
a_count  = len([r for r in all_results if r.get('grade') == 'A'])
bp_count = len([r for r in all_results if r.get('grade') == 'B+'])

html_parts.append(f'''
<div class="note" style="margin-top:16px;">
<h3 style="color:#f0f6fc;font-size:14px;margin-bottom:8px;">核心结论</h3>
<p>在{len(all_results)}个ETF中，<b style="color:#3fb950">{aa_count}个</b>达到AA级（真正符合平台突破形态），<b style="color:#58a6ff">{a_count}个</b>A级（接近突破或微幅突破），<b style="color:#d29922">{bp_count}个</b>B+级（平台蓄势中）。</p>
<p><strong>TOP {min(7, len(aa_list))} AA级标的（按评分排序）：</strong></p>
<ol style="padding-left:20px;color:#8b949e;font-size:12px;line-height:2;">
''')

for r in aa_list[:7]:
    html_parts.append(f'<li><b style="color:#f0f6fc">{r["name"]}</b>({r["code"]}) — 平台{r["platform_high"]} → 当前{r["current_close"]}，突破{r["breakout_pct"]:+.2f}%，趋势{r["total_trend_pct"]:+.2f}%，{r["platform_touches"]}次触及平台</li>')

html_parts.append(f'''</ol>
<p style="margin-top:8px;">⚠️ 注意：本报告为技术面形态筛选，不构成投资建议。实际决策需结合基本面、估值、资金面等多维因素综合判断。</p>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {{
    setTimeout(function() {{
''' + '\n'.join(chart_scripts) + '''
    }}, 300);
}});
</script>
</body></html>''')

output_path = os.path.join(OUTPUT_DIR, 'etf_breakout_full_scan.html')
with open(output_path, 'w', encoding='utf-8') as f:
    f.write('\n'.join(html_parts))

print(f"报告已生成: {output_path}")
print(f"包含 {len(top_candidates)} 个K线图表")
