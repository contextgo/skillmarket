"""
批量拉取92个ETF近8个月历史K线 - AKShare版
AKShare可获取完整历史数据，不受API条数限制
"""

import json, os, time
import akshare as ak

# 获取脚本所在目录，构建默认ETF清单路径
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_ETF_LIST_PATH = os.path.join(SCRIPT_DIR, '..', 'references', 'default_etf_list.json')

# 读取默认ETF清单（必须从配置文件读取）
with open(DEFAULT_ETF_LIST_PATH, 'r', encoding='utf-8') as f:
    etf_list_data = json.load(f)
ETF_LIST = [(item['code'], item['name'], item['market']) for item in etf_list_data]
print(f"从配置文件加载ETF清单: {len(ETF_LIST)} 个")

OUTPUT_DIR = r'c:\Users\40529\WorkBuddy\20260424095249'

print(f"AKShare 批量拉取ETF近8个月K线")
print(f"标的数量: {len(ETF_LIST)}")
print("=" * 60)

# 尝试导入akshare
try:
    import akshare as ak
    print("AKShare 已安装")
except ImportError:
    print("AKShare 未安装，正在安装...")
    import subprocess, sys
    subprocess.check_call([sys.executable, "-m", "pip", "install", "akshare", "-q"])
    import akshare as ak
    print("AKShare 安装完成")

success_count = 0
fail_list = []

for i, (code, name, market) in enumerate(ETF_LIST):
    out_file = os.path.join(OUTPUT_DIR, f"akshare_{market}{code}.json")
    print(f"[{i+1:02d}/{len(ETF_LIST)}] {code} {name}...", end="", flush=True)
    
    try:
        # AKShare ETF日线: fund_etf_hist_em
        # 参数: symbol=代码(不带市场前缀), period="daily", start_date, end_date, adjust="qfq"
        # 注意: AKShare的ETF接口需要用纯代码，不带sh/sz前缀
        df = ak.fund_etf_hist_em(
            symbol=code,
            period="daily",
            start_date="20250901",  # 从2025年9月开始，覆盖8个月
            end_date="20260504",
            adjust="qfq"  # 前复权
        )
        
        if df is None or df.empty:
            print(" 无数据")
            fail_list.append((code, name, "empty_df"))
            time.sleep(0.3)
            continue
        
        # 转换格式
        rows = []
        for _, row in df.iterrows():
            rows.append({
                'date': str(row['日期']),
                'open': float(row['开盘']),
                'close': float(row['收盘']),
                'high': float(row['最高']),
                'low': float(row['最低']),
                'volume': float(row['成交量'])
            })
        
        payload = {
            'code': code,
            'name': name,
            'market': market,
            'source': 'akshare_qfq',
            'date_range': f"{rows[0]['date']} ~ {rows[-1]['date']}",
            'count': len(rows),
            'klines': rows
        }
        
        with open(out_file, 'w', encoding='utf-8') as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
        
        print(f" ✅ {len(rows)}根 ({rows[0]['date']}~{rows[-1]['date']})")
        success_count += 1
        
    except Exception as e:
        print(f" ❌ {str(e)[:50]}")
        fail_list.append((code, name, str(e)[:80]))
    
    time.sleep(0.3)

print()
print("=" * 60)
print(f"完成: 成功={success_count}  失败={len(fail_list)}/{len(ETF_LIST)}")

if fail_list:
    print("\n失败列表:")
    for c, n, e in fail_list[:20]:
        print(f"  {c} {n}: {e}")

print(f"\n输出文件: akshare_XXXX.json (共{success_count}个)")
