"""
严格平台突破形态分析 - ETF全扫描
核心算法：
1. 前80%区间找"平台阻力位"（多次触及的高点区域）
2. 平台质量评分：触及次数、持续时间、中间段压制确认
3. 后20%是否有效突破（创新高+站稳）

数据源优先级：
  akshare_*.json (AKShare，约159条≈8个月，最优先)
  tencent_*.json  (腾讯财经，约125条≈6个月)
  hist6_*.json    (NeoData近6个月)
  hist3_*.json    (NeoData近3个月)
"""

import json, os, re, glob, time, sys

# 动态路径：脚本所在目录的上一级 = workspace根目录
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.abspath(os.path.join(SCRIPT_DIR, '..'))

# 读取默认ETF清单
DEFAULT_ETF_LIST_PATH = os.path.join(SCRIPT_DIR, '..', 'references', 'default_etf_list.json')

# 解析命令行参数
ANALYZE_ALL = '--all' in sys.argv
CUSTOM_ETF_LIST = None
for i, arg in enumerate(sys.argv):
    if arg == '--etf-list' and i + 1 < len(sys.argv):
        CUSTOM_ETF_LIST = sys.argv[i + 1]
        break

# 加载ETF清单
if CUSTOM_ETF_LIST:
    with open(CUSTOM_ETF_LIST, 'r', encoding='utf-8') as f:
        etf_list_data = json.load(f)
    ETF_MAP = {item['code']: (item['name'], item['market']) for item in etf_list_data}
    print(f"使用自定义ETF清单: {len(ETF_MAP)} 个")
elif ANALYZE_ALL:
    ETF_MAP = {}
    print("分析模式: 所有可用数据文件")
else:
    with open(DEFAULT_ETF_LIST_PATH, 'r', encoding='utf-8') as f:
        etf_list_data = json.load(f)
    ETF_MAP = {item['code']: (item['name'], item['market']) for item in etf_list_data}
    print(f"使用默认ETF清单: {len(ETF_MAP)} 个")


def parse_akshare_data(filepath):
    """从AKShare JSON解析K线数据"""
    with open(filepath, 'r', encoding='utf-8') as f:
        data = json.load(f)
    klines = data.get('klines', [])
    if not klines:
        return None
    rows = []
    for row in klines:
        try:
            rows.append({
                'date': row['date'],
                'open': float(row['open']),
                'close': float(row['close']),
                'high': float(row['high']),
                'low': float(row['low']),
                'volume': float(row['volume']),
            })
        except:
            pass
    return rows if len(rows) >= 25 else None


def parse_tencent_data(filepath):
    """从腾讯财经JSON解析K线数据（兼容 qfqday 和 day 两种字段名）"""
    with open(filepath, 'r', encoding='utf-8') as f:
        data = json.load(f)
    klines = data.get('qfqday', []) or data.get('day', [])
    if not klines:
        return None
    rows = []
    for row in klines:
        try:
            rows.append({
                'date': row['date'],
                'open': float(row['open']),
                'close': float(row['close']),
                'high': float(row['high']),
                'low': float(row['low']),
                'volume': float(row['volume']),
            })
        except:
            pass
    return rows if len(rows) >= 25 else None


def parse_neodata_data(filepath):
    """从NeoData JSON解析K线数据（Markdown表格格式）"""
    with open(filepath, 'r', encoding='utf-8') as f:
        data = json.load(f)
    content = data.get('data', {}).get('apiData', {}).get('apiRecall', [])
    if not content:
        return None
    ctext = content[0].get('content', '')
    rows = []
    for line in ctext.strip().split('\n'):
        if re.search(r'\d{4}-\d{2}-\d{2}\s*\|', line) and '---' not in line and '日期' not in line:
            parts = [p.strip() for p in line.split('|')]
            try:
                row_date = parts[-2].strip() if len(parts) >= 10 and parts[-2].strip() else parts[-1].strip()
                rows.append({
                    'open': float(parts[1]),
                    'close': float(parts[2]),
                    'high': float(parts[3]),
                    'low': float(parts[4]),
                    'volume': float(parts[5]),
                    'date': row_date
                })
            except:
                pass
    return rows if len(rows) >= 25 else None


def calc_ema(data, period):
    if len(data) < period:
        return data + [data[-1]] * (period - len(data))
    result = [data[0]]
    k = 2 / (period + 1)
    for i in range(1, len(data)):
        result.append(data[i] * k + result[-1] * (1 - k))
    return result


def analyze_breakout_strict(rows, code, name):
    """
    严格版平台突破分析（80/20框架）

    评分规则（满分15分）：
    A. 平台质量（最多6分）：触及次数 + 持续时间（非真实平台减半）
    B. 突破力度（最多5分）：创新高 + 站稳 + 突破幅度
    C. 趋势量能（最多4分）：整体趋势(2分) + 量比(2分)
    D. 中间段压制加分（1分）

    评级标准：
    AA ≥ 11分 且 pattern_type == "平台突破"
    A  ≥ 9分  且 pattern_type in ("平台突破", "微幅突破")
    B+ ≥ 6分  且 pattern_type in ("平台突破", "微幅突破", "平台蓄势")
    """
    n = len(rows)
    if n < 25:
        return {'code': code, 'name': name, 'skip': True, 'reason': '数据不足'}

    # === 核心算法：前80%定义平台，后20%验证突破 ===
    platform_end = int(n * 0.80)
    first_part = rows[:platform_end]
    recent_part = rows[platform_end:]
    # 中间段：箱体后的压制确认区间（平台末尾前15根）
    middle_start = max(platform_end - 15, 0)
    middle_part = rows[middle_start:platform_end]

    # --- 平台高点：找"被多次触及的最高价位" ---
    unique_highs_desc = sorted(set(r['high'] for r in first_part), reverse=True)

    platform_high = None
    touches_25pct = 0

    # 第一遍：找被>=3次触及的最高价位
    for h in unique_highs_desc:
        cnt = sum(1 for r in first_part if r['high'] >= h * 0.975 and r['high'] <= h * 1.025)
        if cnt >= 3:
            platform_high = h
            touches_25pct = cnt
            break

    # 第二遍：放宽到>=2次触及
    if platform_high is None:
        for h in unique_highs_desc:
            cnt = sum(1 for r in first_part if r['high'] >= h * 0.975 and r['high'] <= h * 1.025)
            if cnt >= 2:
                platform_high = h
                touches_25pct = cnt
                break

    # 后备：没有任何价位被多次触及
    if platform_high is None:
        platform_high = unique_highs_desc[0]
        touches_25pct = 1

    # 平台触及次数（±5%范围，用于展示）
    touches_5pct = sum(1 for r in first_part if r['high'] >= platform_high * 0.95)

    # 平台持续时间：首次触及到最后一次触及的K线跨度
    touch_indices = [i for i, r in enumerate(first_part)
                     if r['high'] >= platform_high * 0.975 and r['high'] <= platform_high * 1.025]
    platform_duration = touch_indices[-1] - touch_indices[0] + 1 if len(touch_indices) >= 2 else 0

    # --- 判断"平台形成区间"是否真实平台 ---
    if len(touch_indices) >= 2:
        p_start = touch_indices[0]
        p_end   = touch_indices[-1]
        platform_period = first_part[p_start : p_end+1]
        p_closes = [r['close'] for r in platform_period]
        p_n = len(p_closes)
        p_avg_first = sum(p_closes[:max(1, p_n//4)]) / max(1, p_n//4)
        p_avg_last  = sum(p_closes[3*p_n//4:]) / max(1, p_n - 3*p_n//4)
        p_trend = (p_avg_last - p_avg_first) / p_avg_first * 100 if p_avg_first > 0 else 0
        p_highs = [r['high'] for r in platform_period]
        p_lows  = [r['low']  for r in platform_period]
        p_range = (max(p_highs) - min(p_lows)) / min(p_lows) * 100 if min(p_lows) > 0 else 0
        is_real_platform = (abs(p_trend) < 25) and (p_range < 40)
    else:
        p_closes = [r['close'] for r in first_part]
        p_n = len(p_closes)
        p_avg_first = sum(p_closes[:max(1, p_n//4)]) / max(1, p_n//4)
        p_avg_last  = sum(p_closes[3*p_n//4:]) / max(1, p_n - 3*p_n//4)
        p_trend = (p_avg_last - p_avg_first) / p_avg_first * 100 if p_avg_first > 0 else 0
        p_highs = [r['high'] for r in first_part]
        p_lows  = [r['low']  for r in first_part]
        p_range = (max(p_highs) - min(p_lows)) / min(p_lows) * 100 if min(p_lows) > 0 else 0
        is_real_platform = (abs(p_trend) < 25) and (p_range < 40)

    # 2. 中间段压制确认
    middle_max_h = max(r['high'] for r in middle_part) if middle_part else 0
    middle_suppressed = all(r['high'] < platform_high * 1.01 for r in middle_part) if middle_part else False

    # 3. 后段突破验证
    second_part = rows[platform_end:]
    second_max_h = max(r['high'] for r in second_part)
    current_c = rows[-1]['close']
    recent_close_avg = sum(r['close'] for r in recent_part) / len(recent_part) if recent_part else current_c

    breakout_pct = (current_c - platform_high) / platform_high * 100
    new_high_made = second_max_h > platform_high * 1.005
    high_above_platform = (second_max_h - platform_high) / platform_high * 100
    recent3_avg = sum(r['close'] for r in rows[-3:]) / 3
    standing_firm = recent3_avg > platform_high * 0.995

    start_price = rows[0]['close']
    total_trend = (current_c - start_price) / start_price * 100

    closes = [r['close'] for r in rows]
    exp12 = calc_ema(closes, 12)
    exp50 = calc_ema(closes, min(50, n))
    ma_bullish = exp12[-1] > exp50[-1] if n >= 12 else False

    vol_recent = [r['volume'] for r in rows[platform_end:]]
    vol_early  = [r['volume'] for r in rows[:platform_end]]
    vol_ratio = (sum(vol_recent)/len(vol_recent)) / (sum(vol_early)/len(vol_early)) if vol_early and vol_recent else 1.0

    # === 综合评分系统 (0-15分) ===
    score = 0

    # A. 平台质量 (最多6分)
    if is_real_platform:
        if touches_25pct >= 5:
            score += 3
        elif touches_25pct >= 3:
            score += 2
        elif touches_25pct >= 2:
            score += 1

        if platform_duration >= 10:
            score += 2
        elif platform_duration >= 5:
            score += 1
        elif platform_duration >= 2:
            score += 0.5
    else:
        # 非真实平台（持续上涨趋势），大幅降级
        if touches_25pct >= 5:
            score += 1
        elif touches_25pct >= 3:
            score += 0.5

    # B. 突破力度 (最多5分)
    if new_high_made and standing_firm and breakout_pct > 3:
        score += 5
    elif new_high_made and standing_firm and breakout_pct > 0:
        score += 3.5
    elif new_high_made and not standing_firm:
        score += 2
    elif breakout_pct > -2 and not new_high_made:
        score += 1
    elif breakout_pct <= -5:
        score += 0

    # C. 趋势与量能 (最多4分)
    if total_trend > 10:
        score += 2
    elif total_trend > 3:
        score += 1
    elif total_trend > 0:
        score += 0.5

    if vol_ratio > 1.3:
        score += 2
    elif vol_ratio > 1.1:
        score += 1
    elif vol_ratio > 0.95:
        score += 0.5

    # D. 中间段压制加分 (1分)
    if middle_suppressed and len(middle_part) >= 3:
        score += 1

    # === 形态分类 ===
    if is_real_platform and touches_25pct >= 3 and new_high_made and standing_firm and breakout_pct > 1:
        pattern_type = "平台突破"
    elif is_real_platform and touches_25pct >= 3 and new_high_made and breakout_pct <= 1:
        pattern_type = "微幅突破"
    elif is_real_platform and touches_25pct >= 3 and not new_high_made and abs(breakout_pct) < 5:
        pattern_type = "平台蓄势"
    elif total_trend > 8 and touches_25pct < 2:
        pattern_type = "趋势上涨"
    elif is_real_platform and touches_25pct >= 3 and breakout_pct < -5:
        pattern_type = "跌破平台"
    elif touches_25pct < 2 and total_trend < -3:
        pattern_type = "下跌趋势"
    else:
        pattern_type = "其他"

    # 最终评级（注意AA级有额外类型限制）
    final_score = round(score, 1)
    if final_score >= 11 and pattern_type == "平台突破":
        grade = "AA"
    elif final_score >= 9 and pattern_type in ("平台突破", "微幅突破"):
        grade = "A"
    elif final_score >= 6 and pattern_type in ("平台突破", "微幅突破", "平台蓄势"):
        grade = "B+"
    elif final_score >= 4:
        grade = "B"
    elif final_score >= 2.5:
        grade = "C+"
    else:
        grade = "C"

    return {
        'code': code,
        'name': name,
        'n': n,
        'date_range': f"{rows[0]['date']} ~ {rows[-1]['date']}",
        'platform_high': round(platform_high, 4),
        'platform_touches': touches_25pct,
        'platform_touches_5pct': touches_5pct,
        'platform_duration_days': platform_duration,
        'is_real_platform': is_real_platform,
        'second_high': round(second_max_h, 4),
        'current_close': round(current_c, 4),
        'breakout_pct': round(breakout_pct, 2),
        'new_high_made': new_high_made,
        'standing_firm': standing_firm,
        'high_above_pct': round(high_above_platform, 2),
        'total_trend_pct': round(total_trend, 2),
        'ma_bullish': ma_bullish,
        'vol_ratio': round(vol_ratio, 2),
        'score': final_score,
        'grade': grade,
        'pattern_type': pattern_type,
        'rows': rows,
    }


# ===== 主程序 =====

# 扫描所有JSON文件（优先 AKShare 8个月 > 腾讯财经 6个月 > NeoData）
all_files = (glob.glob(os.path.join(OUTPUT_DIR, 'akshare_*.json')) +
             glob.glob(os.path.join(OUTPUT_DIR, 'tencent_*.json')) +
             glob.glob(os.path.join(OUTPUT_DIR, 'hist6_*.json')) +
             glob.glob(os.path.join(OUTPUT_DIR, 'hist3_*.json')))

print(f"找到 {len(all_files)} 个数据文件")

results = []
seen_codes = set()

for filepath in all_files:
    base = os.path.basename(filepath).replace('.json', '')

    code = None
    is_akshare = False
    is_tencent = False

    if base.startswith('akshare_sh') or base.startswith('akshare_sz'):
        is_akshare = True
        code = base[8:]
    elif base.startswith('tencent_sh') or base.startswith('tencent_sz'):
        is_tencent = True
        code = base[8:]
    elif base.startswith('hist6_sh'):
        code = base[6:]
    elif base.startswith('hist6_sz'):
        code = base[6:]
    elif base.startswith('hist3_sh'):
        code = base[6:]
    elif base.startswith('hist3_sz'):
        code = base[6:]

    if not code or code not in ETF_MAP:
        continue
    if code in seen_codes:
        continue
    seen_codes.add(code)

    name, expected_market = ETF_MAP[code]

    if is_akshare:
        rows = parse_akshare_data(filepath)
    elif is_tencent:
        rows = parse_tencent_data(filepath)
    else:
        rows = parse_neodata_data(filepath)

    if not rows:
        print(f"  跳过 {code} {name}: 数据不足")
        continue

    analysis = analyze_breakout_strict(rows, code, name)
    results.append(analysis)

print(f"\n成功分析 {len(results)} 个ETF")
print("="*100)

# 按分数排序
results.sort(key=lambda x: x['score'], reverse=True)

# 输出完整结果表
print(f"\n{'排名':<4}{'代码':<8}{'名称':<14}{'类型':<10}{'平台高':>8}{'当前价':>8}{'突破%':>8}{'趋势%':>8}{'触及':>4}{'持续':>4}{'量比':>6}{'评分':>5}{'评级':<4}")
print("-"*100)
for i, r in enumerate(results):
    bo = f"{r['breakout_pct']:+.1f}%"
    tr = f"{r['total_trend_pct']:+.1f}%"
    print(f"{i+1:<4}{r['code']:<8}{r['name']:<14}{r['pattern_type']:<10}{r['platform_high']:>8.3f}{r['current_close']:>8.3f}"
          f"{bo:>8}{tr:>8}{r['platform_touches']:>4}{r['platform_duration_days']:>4}"
          f"{r['vol_ratio']:>6.2f}{r['score']:>5}{r['grade']:<4}")

# 筛选候选（隐藏规则：platform_touches >= 2）
print("\n" + "="*100)
print("【筛选结果】平台突破形态候选 (评分>=5 且 类型=平台突破/微幅突破/平台蓄势 且 触及>=2)")
print("="*100)

candidates = [r for r in results
              if r['score'] >= 5
              and r['pattern_type'] in ('平台突破', '微幅突破', '平台蓄势')
              and r['platform_touches'] >= 2]

candidates.sort(key=lambda x: x['score'], reverse=True)

if candidates:
    print(f"\n共 {len(candidates)} 个候选:\n")
    for i, c in enumerate(candidates):
        print(f"\n{i+1}. 【{c['grade']} | 评分{c['score']}】{c['name']} ({c['code']})")
        print(f"   类型: {c['pattern_type']}")
        print(f"   平台阻力: {c['platform_high']} | 当前价: {c['current_close']} | 突破: {c['breakout_pct']:+.2f}%")
        print(f"   平台触及次数: {c['platform_touches']}次 (±2.5%) | 平台持续: {c['platform_duration_days']}根K线")
        print(f"   整体涨幅: {c['total_trend_pct']:+.2f}% | 量比: {c['vol_ratio']:.2f}x")
        print(f"   数据范围: {c['date_range']} ({c['n']}根)")
else:
    print("\n未找到符合条件的标的！降低标准看看...")
    candidates2 = [r for r in results if r['score'] >= 4 and r['pattern_type'] in ('平台突破','微幅突破','平台蓄势')]
    print(f"\n降低标准(score>=4): {len(candidates2)}个")
    for c in candidates2:
        print(f"  {c['code']} {c['name']}: 评分{c['score']} {c['pattern_type']}")

# 保存全部结果
with open(os.path.join(OUTPUT_DIR, 'full_scan_result.json'), 'w', encoding='utf-8') as f:
    summary_results = [{k: v for k, v in r.items() if k != 'rows'} for r in results]
    json.dump(summary_results, f, ensure_ascii=False, indent=2)

# 保存候选的完整数据（含rows）用于画图
candidates_with_rows = []
for c in candidates:
    full = [r for r in results if r['code'] == c['code']]
    if full:
        candidates_with_rows.append(full[0])

with open(os.path.join(OUTPUT_DIR, 'scan_candidates.json'), 'w', encoding='utf-8') as f:
    json.dump(candidates_with_rows, f, ensure_ascii=False, indent=2)

print(f"\n结果已保存:")
print(f"  全量扫描: full_scan_result.json ({len(results)}个)")
print(f"  候选标的: scan_candidates.json ({len(candidates)}个)")
