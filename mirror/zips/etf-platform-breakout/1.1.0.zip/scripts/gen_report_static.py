"""
生成ETF平台突破形态报告 — 静态图片版（兼容QQ邮箱）
K线图用 matplotlib 预渲染为PNG，base64嵌入HTML，无需JS
"""

import json, os, datetime, base64, io
import matplotlib
matplotlib.use('Agg')  # 无头模式
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import Rectangle
import matplotlib.font_manager as fm

# 设置中文字体（全局）
def setup_chinese_font():
    font_paths = [
        'C:/Windows/Fonts/msyh.ttc',
        'C:/Windows/Fonts/simhei.ttf',
        'C:/Windows/Fonts/simsun.ttc',
        'C:/Windows/Fonts/msyhbd.ttc',
    ]
    for fp in font_paths:
        if os.path.exists(fp):
            try:
                fm.fontManager.addfont(fp)
                prop = fm.FontProperties(fname=fp)
                plt.rcParams['font.family'] = prop.get_name()
                plt.rcParams['axes.unicode_minus'] = False
                print(f'  使用字体: {fp}')
                return
            except:
                pass
    print('  警告: 未找到中文字体，将使用默认字体')

setup_chinese_font()

OUTPUT_DIR = r'c:\Users\40529\WorkBuddy\20260424095249'

def calc_ema(data, period):
    result = [data[0]]
    k = 2 / (period + 1)
    for i in range(1, len(data)):
        result.append(data[i] * k + result[-1] * (1 - k))
    return result

def draw_kline_chart(code, name, rows, platform_high, current_close, breakout_pct, grade, score):
    """
    用matplotlib绘制K线+成交量图，返回base64 PNG字符串
    """
    closes = [r['close'] for r in rows]
    highs  = [r['high']  for r in rows]
    lows   = [r['low']   for r in rows]
    opns   = [r['open']  for r in rows]
    vols   = [r['volume']/1e8 for r in rows]  # 亿股

    exp12 = calc_ema(closes, 12)
    exp50 = calc_ema(closes, min(50, len(closes)))

    dates = [r['date'] for r in rows]
    n = len(dates)

    # 创建图表
    fig = plt.figure(figsize=(10, 5), facecolor='#0d1117')
    # 上：K线 78%，下：成交量 22%
    ax1 = plt.subplot2grid((100, 1), (0, 0), rowspan=78)
    ax2 = plt.subplot2grid((100, 1), (78, 0), rowspan=22, sharex=ax1)

    # —— K线 ——
    for i in range(n):
        color = '#f85149' if closes[i] >= opns[i] else '#3fb950'
            # 影线
        ax1.plot([i, i], [lows[i], highs[i]], color=color, linewidth=0.8, alpha=0.8)
        # 实体
        body_h = abs(closes[i] - opns[i])
        body_b = min(opns[i], closes[i])
        rect = Rectangle((i - 0.3, body_b), 0.6, body_h if body_h > 0 else 0.001,
                         color=color, alpha=0.9)
        ax1.add_patch(rect)

    # EMA线
    x_vals = list(range(n))
    ax1.plot(x_vals, exp12, color='#58a6ff', linewidth=1.2, label='EXP12')
    ax1.plot(x_vals, exp50, color='#f778ba', linewidth=1.2, label='EXP50')

    # 平台阻力线
    ax1.axhline(y=platform_high, color='#d29922', linewidth=1.5, linestyle='--', label='阻力位')

    # K线区域样式
    ax1.set_facecolor('#0d1117')
    ax1.tick_params(colors='#8b949e', labelsize=8)
    ax1.spines['bottom'].set_color('#30363d')
    ax1.spines['top'].set_color('#30363d')
    ax1.spines['left'].set_color('#30363d')
    ax1.spines['right'].set_color('#30363d')
    ax1.yaxis.label.set_color('#8b949e')
    ax1.ticklabel_format(useOffset=False, style='plain')
    ax1.grid(True, color='#21262d', linewidth=0.5)

    # Y轴范围加一点边距
    price_min = min(lows)
    price_max = max(highs)
    margin = (price_max - price_min) * 0.08
    ax1.set_ylim(price_min - margin, price_max + margin)

    # X轴：显示部分日期
    step = max(1, n // 6)
    show_idx = list(range(0, n, step))
    ax1.set_xticks(show_idx)
    ax1.set_xticklabels([dates[i][-5:] for i in show_idx], rotation=30, ha='right', fontsize=7, color='#8b949e')
    ax1.set_yticks(ax1.get_yticks())
    ax1.set_yticklabels([f'{y:.3f}' for y in ax1.get_yticks()], fontsize=7, color='#8b949e')

    # 标题
    title_color = '#f85149' if breakout_pct > 0 else '#3fb950'
    ax1.set_title(f'{name}  {code}  [{grade}{score}分]  阻力位:{platform_high:.3f}  当前:{current_close:.3f}  突破:{breakout_pct:+.2f}%',
                  color='#c9d1d9', fontsize=9, loc='left', pad=2)
    for i in range(n):
        color = '#f85149' if closes[i] >= opns[i] else '#3fb950'
        alpha = 0.6 if closes[i] >= opns[i] else 0.5
        ax2.bar(i, vols[i], color=color, alpha=alpha, width=0.6)

    ax2.set_facecolor('#0d1117')
    ax2.tick_params(colors='#8b949e', labelsize=7)
    ax2.spines['bottom'].set_color('#30363d')
    ax2.spines['top'].set_color('#30363d')
    ax2.spines['left'].set_color('#30363d')
    ax2.spines['right'].set_color('#30363d')
    ax2.set_xticks(show_idx)
    ax2.set_xticklabels([dates[i][-5:] for i in show_idx], rotation=30, ha='right', fontsize=7, color='#8b949e')
    ax2.set_ylabel('成交量(亿)', color='#8b949e', fontsize=7)
    ax2.grid(True, color='#21262d', linewidth=0.5)
    ax2.set_xlim(-0.5, n - 0.5)

    # 成交量Y轴
    ax2.set_yticks(ax2.get_yticks())
    ax2.set_yticklabels([f'{y:.1f}' for y in ax2.get_yticks()], fontsize=7, color='#8b949e')

    plt.tight_layout(pad=0.5)

    # 转base64
    buf = io.BytesIO()
    fig.savefig(buf, format='png', dpi=100, facecolor='#0d1117',
                bbox_inches='tight', pad_inches=0.1)
    buf.seek(0)
    b64 = base64.b64encode(buf.read()).decode('utf-8')
    plt.close(fig)
    return b64

# ===== 主程序 =====

# 读取数据
with open(os.path.join(OUTPUT_DIR, 'full_scan_result.json'), 'r', encoding='utf-8') as f:
    all_results = json.load(f)
with open(os.path.join(OUTPUT_DIR, 'scan_candidates.json'), 'r', encoding='utf-8') as f:
    candidates = json.load(f)

# 为候选生成静态图表
img_map = {}  # code -> base64
for item in candidates:
    code = item['code']
    name = item['name']
    rows = item['rows']
    platform_high = item['platform_high']
    current_close = item['current_close']
    breakout_pct  = item['breakout_pct']
    grade = item['grade']
    score = item['score']
    print(f'  渲染图表: {name}({code}) ...')
    b64 = draw_kline_chart(code, name, rows, platform_high, current_close, breakout_pct, grade, score)
    img_map[code] = b64

print(f'共渲染 {len(img_map)} 张K线图')

# ===== 构建HTML =====
html_parts = []
html_parts.append('''<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ETF平台突破形态全扫描报告（静态版）</title>
<style>
* { margin:0; padding:0; box-sizing:border-box; }
body { font-family:-apple-system,"PingFang SC","Microsoft YaHei",sans-serif; background:#0d1117; color:#c9d1d9; padding:16px; max-width:1100px; margin:0 auto; }
h1 { text-align:center; color:#f0f6fc; font-size:22px; margin-bottom:6px; }
.subtitle { text-align:center; color:#8b949e; font-size:13px; margin-bottom:20px; }
.note { background:#161b22; border:1px solid #30363d; border-radius:10px; padding:14px 18px; margin-bottom:20px; font-size:12px; color:#8b949e; line-height:1.7; }
.note strong { color:#d29922; }

.overview { background:#161b22; border:1px solid #30363d; border-radius:10px; padding:16px; margin-bottom:20px; overflow-x:auto; }
.overview h2 { color:#f0f6fc; font-size:16px; margin-bottom:10px; }
table { width:100%; border-collapse:collapse; font-size:11px; }
th { color:#8b949e; font-weight:500; padding:6px 8px; text-align:left; border-bottom:1px solid #30363d; white-space:nowrap; }
td { padding:5px 8px; border-bottom:1px solid #21262d; white-space:nowrap; }
tr:hover { background:#1c2128; }
.up { color:#f85149; } .down { color:#3fb950; }
.badge { display:inline-block; padding:2px 8px; border-radius:10px; font-size:11px; font-weight:600; }
.badge-AA { background:#1a4731; color:#3fb950; }
.badge-A { background:#1a3630; color:#58a6ff; }
.badge-Bp { background:#4d3a08; color:#d29922; }
.badge-B { background:#2d333b; color:#8b949e; }

.card { background:#161b22; border:1px solid #30363d; border-radius:10px; margin-bottom:14px; overflow:hidden; }
.card-header { padding:10px 14px; display:flex; align-items:center; gap:10px; flex-wrap:wrap; border-bottom:1px solid #30363d; }
.etf-name { font-size:15px; font-weight:600; color:#f0f6fc; }
.etf-code { font-size:12px; color:#8b949e; }
.metrics { display:flex; gap:12px; flex-wrap:wrap; padding:8px 14px; background:#0d1117; font-size:11px; }
.metric { text-align:center; min-width:65px; }
.metric-label { color:#8b949e; font-size:9px; }
.metric-value { font-weight:600; font-size:13px; }
.chart-img { width:100%; display:block; }
.analysis { padding:10px 14px; border-top:1px solid #30363d; font-size:11px; line-height:1.6; }
.analysis h4 { color:#d29922; font-size:12px; margin-bottom:4px; }
.analysis p { color:#8b949e; }
.legend { display:flex; gap:12px; padding:5px 14px; font-size:10px; color:#8b949e; flex-wrap:wrap; }
.legend-line { width:16px; height:2px; display:inline-block; vertical-align:middle; }

.section-title { color:#f0f6fc; font-size:15px; margin:20px 0 12px; padding-left:4px; border-left:3px solid #d29922; }
</style>
</head>
<body>
<h1>ETF「平台突破」形态全扫描报告（静态版）</h1>
<p class="subtitle">基于科创200参考形态 | 数据截至2026-04-30 | 共分析95个ETF | 静态图片格式，兼容所有邮箱</p>

<div class="note">
<strong>分析方法：</strong>取前<strong>80%</strong>区间最高价作为"前期平台阻力位"，统计触及次数(±2.5%)和持续时间。后<strong>20%</strong>区间验证是否有效突破。
评分维度（满分15分）：平台质量(<strong>最多6分</strong>) + 突破力度(<strong>最多5分</strong>) + 趋势量能(<strong>最多4分</strong>) + 中间段压制加分(<strong>1分</strong>)。
评级标准：<strong>AA≥11分</strong>（且必须为"平台突破"类型）、<strong>A≥9分</strong>（平台突破/微幅突破）、<strong>B+≥6分</strong>（平台突破/微幅突破/平台蓄势）。
<strong>筛选标准：</strong>评分≥5 且 形态类型=平台突破/微幅突破/平台蓄势 且 平台触及次数≥2。
</div>
''')

# TOP AA级概览
aa_list = [r for r in all_results if r.get('grade') == 'AA' and r.get('pattern_type') in ('平台突破','微幅突破')]
html_parts.append(f'''
<div class="overview">
<h2>TOP推荐 — 真正的平台突破标的 (AA级，共{len(aa_list)}个)</h2>
<table>
<thead><tr><th>#</th><th>ETF名称</th><th>代码</th><th>形态</th><th>平台阻力</th><th>当前价</th><th>突破幅度</th><th>整体涨幅</th><th>触及次数</th><th>持续天数</th><th>量比</th><th>评分</th></tr></thead>
<tbody>
''')
for i, r in enumerate(aa_list[:15]):
    bo_class = 'up' if r['breakout_pct'] > 0 else 'down'
    tr_class = 'up' if r['total_trend_pct'] > 0 else 'down'
    badge_cls = f"badge-{r['grade'].replace('+','p')}"
    html_parts.append(f'''<tr>
        <td>{i+1}</td>
        <td style="color:#f0f6fc;font-weight:600">{r['name']}</td>
        <td>{r['code']}</td>
        <td>{r['pattern_type']}</td>
        <td>{r['platform_high']}</td>
        <td style="color:#f0f6fc">{r['current_close']}</td>
        <td class="{bo_class}">{r['breakout_pct']:+.2f}%</td>
        <td class="{tr_class}">{r['total_trend_pct']:+.2f}%</td>
        <td>{r['platform_touches']}次</td>
        <td>{r['platform_duration_days']}根</td>
        <td>{r['vol_ratio']:.2f}x</td>
        <td><span class="badge {badge_cls}">{r['grade']} {r['score']}</span></td>
    </tr>''')
html_parts.append('</tbody></table></div>')

# A和B+级概览
ab_list = [r for r in all_results if r.get('grade') in ('A','B+') and r.get('score') >= 7]
if ab_list:
    html_parts.append(f'''
    <div class="overview">
    <h2>值得关注 — A/B+级 (共{len(ab_list)}个)</h2>
    <table>
    <thead><tr><th>#</th><th>ETF名称</th><th>代码</th><th>形态</th><th>平台阻力</th><th>当前价</th><th>突破%</th><th>趋势%</th><th>触及</th><th>评分</th></tr></thead>
    <tbody>
    ''')
    for i, r in enumerate(ab_list):
        bo_class = 'up' if r['breakout_pct'] > 0 else 'down'
        tr_class = 'up' if r['total_trend_pct'] > 0 else 'down'
        badge_cls = f"badge-{r['grade'].replace('+','p')}"
        html_parts.append(f'''<tr>
            <td>{i+1}</td><td style="color:#f0f6fc">{r['name']}</td><td>{r['code']}</td><td>{r['pattern_type']}</td>
            <td>{r['platform_high']}</td><td>{r['current_close']}</td>
            <td class="{bo_class}">{r['breakout_pct']:+.2f}%</td><td class="{tr_class}">{r['total_trend_pct']:+.2f}%</td>
            <td>{r['platform_touches']}次</td>
            <td><span class="badge {badge_cls}">{r['grade']} {r['score']}</span></td>
        </tr>''')
    html_parts.append('</tbody></table></div>')

# 逐个K线图（AA+A级，静态图片）
top_candidates = [c for c in candidates if c['score'] >= 9 and c['pattern_type'] in ('平台突破','微幅突破')]

if top_candidates:
    html_parts.append(f'<h3 class="section-title">重点标的K线图 (AA/A级，含平台阻力线和EXP均线) — 静态图片版</h3>')

    for item in top_candidates:
        code = item['code']
        name = item['name']
        platform_high = item['platform_high']
        current_c = item['current_close']
        breakout = item['breakout_pct']
        trend = item['total_trend_pct']
        score = item['score']
        grade = item['grade']
        ptype = item['pattern_type']
        touches = item['platform_touches']
        duration = item['platform_duration_days']
        vol_r = item['vol_ratio']

        bo_cls = 'up' if breakout > 0 else 'down'
        tr_cls = 'up' if trend > 0 else 'down'
        badge_cls = f"badge-{grade.replace('+','p')}"

        b64_img = img_map.get(code, '')
        img_tag = f'<img class="chart-img" src="data:image/png;base64,{b64_img}" alt="{name}K线图">' if b64_img else '<p style="color:#8b949e;text-align:center;padding:40px 0">图表生成失败</p>'

        html_parts.append(f'''
<div class="card">
    <div class="card-header">
        <span class="badge {badge_cls}">{grade} {score}分</span>
        <span class="etf-name">{name}ETF</span>
        <span class="etf-code">{code}</span>
        <span style="font-size:11px;color:#8b949e;margin-left:auto">[{ptype}]</span>
    </div>
    <div class="metrics">
        <div class="metric"><div class="metric-label">平台阻力位</div><div class="metric-value" style="color:#d29922">{platform_high:.3f}</div></div>
        <div class="metric"><div class="metric-label">当前价</div><div class="metric-value">{current_c:.3f}</div></div>
        <div class="metric"><div class="metric-label">突破幅度</div><div class="metric-value {bo_cls}">{breakout:+.2f}%</div></div>
        <div class="metric"><div class="metric-label">整体涨幅</div><div class="metric-value {tr_cls}">{trend:+.2f}%</div></div>
        <div class="metric"><div class="metric-label">平台触及</div><div class="metric-value">{touches}次/{duration}根</div></div>
        <div class="metric"><div class="metric-label">量比</div><div class="metric-value">{vol_r:.2f}x</div></div>
    </div>
    <div class="legend">
        <span><span class="legend-line" style="background:#d29922;border-style:dashed"></span> 阻力线 {platform_high:.3f}</span>
        <span><span class="legend-line" style="background:#58a6ff"></span> EXP12</span>
        <span><span class="legend-line" style="background:#f778ba"></span> EXP50</span>
    </div>
    {img_tag}
    <div class="analysis">
        <h4>形态解读</h4>
        <p>前<strong>80%</strong>区间的平台高点在 <b style="color:#d29922">{platform_high:.3f}</b> 附近，共有 <b>{touches}</b> 根K线的最高价触及该区域(±2.5%)，平台持续约 <b>{duration}</b> 个交易日。{"后段成功放量突破并站稳其上" if breakout > 0.5 else "当前价格接近但尚未完全突破"}。整体趋势{'+' if trend > 0 else ''}{trend:.2f}%，成交量较前期{'放大' if vol_r > 1.1 else '持平或萎缩'}。</p>
    </div>
</div>
''')

# 结尾总结
aa_count = len([r for r in all_results if r.get('grade') == 'AA'])
a_count  = len([r for r in all_results if r.get('grade') == 'A'])
bp_count = len([r for r in all_results if r.get('grade') == 'B+'])

html_parts.append(f'''
<div class="note" style="margin-top:16px;">
<h3 style="color:#f0f6fc;font-size:14px;margin-bottom:8px;">核心结论</h3>
<p>在95个ETF中，<b style="color:#3fb950">{aa_count}个</b>达到AA级（真正符合平台突破形态），<b style="color:#58a6ff">{a_count}个</b>A级（接近突破或微幅突破），<b style="color:#d29922">{bp_count}个</b>B+级（平台蓄势中）。</p>
<p><strong>TOP {min(7, len(aa_list))} AA级标的（按评分排序）：</strong></p>
<ol style="padding-left:20px;color:#8b949e;font-size:12px;line-height:2;">
''')

for r in aa_list[:7]:
    html_parts.append(f'<li><b style="color:#f0f6fc">{r["name"]}</b>({r["code"]}) — 平台{r["platform_high"]} → 当前{r["current_close"]}，突破{r["breakout_pct"]:+.2f}%，趋势{r["total_trend_pct"]:+.2f}%，{r["platform_touches"]}次触及平台</li>')

html_parts.append('''</ol>
<p style="margin-top:8px;">⚠️ 注意：本报告为技术面形态筛选，不构成投资建议。实际决策需结合基本面、估值、资金面等多维因素综合判断。</p>
</div>
</body></html>''')

output_path = os.path.join(OUTPUT_DIR, 'etf_breakout_full_scan_static.html')
with open(output_path, 'w', encoding='utf-8') as f:
    f.write('\n'.join(html_parts))

print(f"\n✅ 静态报告已生成: {output_path}")
print(f"   包含 {len(top_candidates)} 张静态K线图（base64嵌入，无需JS）")
print(f"   文件大小约: {os.path.getsize(output_path)/1024:.0f} KB")
