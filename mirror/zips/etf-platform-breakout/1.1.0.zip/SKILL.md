---
name: etf-platform-breakout
description: >
  ETF 平台突破形态分析工具。当用户提到"平台突破"、"箱体突破"、"阻力位突破"、
  "ETF技术分析"、"找突破标的"等关键词时触发。
  分析 ETF 是否形成价格平台（多次触及同一高点），并判断是否有效突破。
  输出评分、评级、形态分类，并生成带 K 线图的 HTML 报告。
---

# ETF 平台突破形态分析

## 核心概念

**平台突破**：ETF 在某个价格水平多次震荡（形成阻力位），经过整理后放量突破，是强势上涨信号。

**判断逻辑**（80/20 框架）：
- 前 80% K 线：寻找"平台高点"（被多次触及的最高价位）
- 后 20% K 线：验证是否有效突破

## 使用步骤

### 0. ETF清单配置（重要）

默认分析范围：**95个ETF**（存储在 `references/default_etf_list.json`）

- **默认行为**：如果不指定分析范围，自动使用这95个ETF
- **自定义范围**：可通过以下方式指定：
  - 修改 `references/default_etf_list.json` 文件
  - 使用 `--etf-list` 参数指定自定义清单
  - 使用 `--all` 参数分析所有可用的数据文件

ETF清单格式（JSON数组）：
```json
[
  {"code": "513730", "name": "东南亚科技", "market": "sh"},
  ...
]
```

### 1. 下载 K 线数据（首次或数据过期时）

优先使用 **AKShare**（可获取 8 个月数据，约 160 根 K 线）：
```bash
cd <workspace>
python scripts/analyze.py --fetch-only   # 仅下载，不分析
```

备用方案：**腾讯财经 API**（免费，但最多 125 根）：
```bash
cd <workspace>
python scripts/fetch_kline_tencent.py
```

### 2. 运行分析
```bash
cd <workspace>
python scripts/analyze.py            # 默认：分析95个ETF
python scripts/analyze.py --all      # 分析所有可用数据文件
python scripts/analyze.py --etf-list custom.json  # 使用自定义ETF清单
```

输出：
- `full_scan_result.json`：全量分析结果
- `scan_candidates.json`：候选标的（含 K 线数据）

### 3. 生成 HTML 报告
```bash
cd <workspace>
python scripts/gen_report.py
```

输出：`etf_breakout_full_scan.html`

**QQ邮箱兼容版（静态图片，无需JS）**：
```bash
cd <workspace>
python scripts/gen_report_static.py
```
输出：`etf_breakout_full_scan_static.html`（K线图预渲染为静态图片，base64嵌入，QQ邮箱中可正常显示）

## 评分标准（0-15 分）

### 评分维度

| 维度 | 满分 | 说明 |
|------|------|------|
| A. 平台质量 | 6分 | 触及次数(3分) + 持续时间(2分)，非真实平台减半 |
| B. 突破力度 | 5分 | 创新高+站稳+突破幅度 |
| C. 趋势量能 | 4分 | 整体趋势(2分) + 量比(2分) |
| D. 中间段压制 | 1分 | 平台高点后15根K线持续受压制 |

### 评级标准

| 分数 | 评级 | 附加条件 |
|------|------|----------|
| ≥ 11 | AA | **且** pattern_type == "平台突破" |
| ≥ 9  | A  | 且 pattern_type in ("平台突破", "微幅突破") |
| ≥ 6  | B+ | 且 pattern_type in ("平台突破", "微幅突破", "平台蓄势") |
| ≥ 4  | B  | — |
| ≥ 2.5| C+ | — |
| < 2.5| C  | — |

### 筛选标准（生成报告时的候选过滤）

```
评分 ≥ 5
且 形态类型 in ("平台突破", "微幅突破", "平台蓄势")
且 平台触及次数(±2.5%) ≥ 2     ← 隐藏规则，报告中已声明
```

## 关键参数

| 参数 | 当前值 | 说明 |
|------|---------|------|
| 平台定义区间 | 前 80% K 线 | analyze.py `platform_end = int(n * 0.80)` |
| 触及区间 | ±2.5% | 判断"触及平台高点"的容忍度 |
| 站稳判断 | 最近3日均价 > 平台高点×0.995 | 避免单日假突破 |
| 中间段定义 | 平台末尾前15根K线 | 验证平台高点后的压制确认 |

## 文件结构

```
references/
  default_etf_list.json  # 默认95个ETF清单
  algorithm_notes.md     # 算法细节和已知问题
scripts/
  fetch_kline_akshare.py   # 下载 K 线（AKShare）
  analyze.py               # 核心分析脚本（支持--all和--etf-list参数）
  gen_report.py           # 生成 HTML 报告（含K线图）
```

## 常见调整

**收紧标准**（减少假阳性）：
- 提高 `touches_25pct` 阈值（analyze.py 评分A部分）
- 增加 `platform_duration` 要求
- 提高 `is_real_platform` 的趋势/振幅阈值

**放松标准**（增加候选）：
- 降低评分阈值
- 放宽 `is_real_platform` 判断（algorithm_notes.md 中有说明）

## 已知问题与修复记录

### gen_report.py K线图左侧空白（2026-05-04修复）

**问题**：报告中的K线图左侧大面积空白，数据未填满图表。

**根因**：
1. K线数据 `time` 字段使用日期字符串 `'2025-09-01'`，Lightweight Charts v4 优先使用数字时间戳
2. 图表初始化时容器 `clientWidth` 可能为0，导致 `fitContent()` 计算错误
3. `setVisibleRange` 传入字符串而非数字时间戳

**修复内容**：
1. K线数据 `time` 改为 Unix 时间戳整数（`date_to_ts()` 函数）
2. JS 初始化增加 `setInterval` 轮询，等待容器有宽度再初始化
3. `setVisibleRange` 使用数字时间戳 `from/to`
4. 增加 `rightOffset: 3` 和 `barSpacing: 5` 让K线紧密排列

### gen_report.py 动态日期和标题（2026-05-04修复）

**问题**：报告副标题硬编码日期，数据更新后不会自动变化。

**修复**：从 `scan_candidates.json` 的K线数据中自动提取最新日期，动态生成副标题。

### 腾讯财经API字段兼容性

**问题**：部分ETF的K线数据返回字段名为 `day` 而非 `qfqday`，导致解析失败。

**修复**：优先读取 `qfqday`，若为空则降级读取 `day`：
```python
klines = data.get('qfqday', []) or data.get('day', [])
```

### 报告声明与代码规则不一致（2026-05-04修复）

**问题**：网页顶部声明的分析方法与代码实际逻辑不一致：
- 声明写"前60%/后40%"，代码实际是"前80%/后20%"
- 声明写"AA≥13分"，代码实际是"AA≥11分"
- 声明写"B+≥7分"，代码实际是"B+≥6分"
- 未声明中间段压制加分(+1分)和触及次数≥2过滤条件

**修复**：以代码为准，更新 `gen_report.py` 中所有声明文字，与 `analyze.py` 实际逻辑完全一致。
