---
name: etf-platform-breakout
description: >
  ETF 平台突破形态分析工具。当用户提到"平台突破"、"箱体突破"、"阻力位突破"、
  "ETF技术分析"、"找突破标的"等关键词时触发。
  分析 ETF 是否形成价格平台（多次触及同一高点），并判断是否有效突破。
  输出评分、评级、形态分类，并生成带 K 线图的 HTML 报告。
---

# ETF 平台突破形态分析

## 核心概念

**平台突破**：ETF 在某个价格水平多次震荡（形成阻力位），经过整理后放量突破，是强势上涨信号。

**判断逻辑**（80/20 框架）：
- 前 80% K 线：寻找"平台高点"（被多次触及的最高价位）
- 后 20% K 线：验证是否有效突破

## 使用步骤

### 0. ETF清单配置（重要）

默认分析范围：**92个ETF**（存储在 `references/default_etf_list.json`）

- **默认行为**：如果不指定分析范围，自动使用这92个ETF
- **自定义范围**：可通过以下方式指定：
  - 修改 `references/default_etf_list.json` 文件
  - 使用 `--etf-list` 参数指定自定义清单
  - 使用 `--all` 参数分析所有可用的数据文件

ETF清单格式（JSON数组）：
```json
[
  {"code": "513730", "name": "东南亚科技", "market": "sh"},
  ...
]
```

### 1. 下载 K 线数据（首次或数据过期时）

优先使用 **AKShare**（可获取 8 个月数据，约 160 根 K 线）：
```bash
cd <workspace>
python scripts/fetch_kline_akshare.py
```

备用方案：**腾讯财经 API**（免费，但最多 125 根）：
```bash
cd <workspace>
python scripts/fetch_kline_tencent.py
```

### 2. 运行分析
```bash
cd <workspace>
python scripts/analyze.py            # 默认：分析92个ETF
python scripts/analyze.py --all      # 分析所有可用数据文件
python scripts/analyze.py --etf-list custom.json  # 使用自定义ETF清单
```

输出：
- `full_scan_result.json`：全量分析结果
- `scan_candidates.json`：候选标的（含 K 线数据）

### 3. 生成 HTML 报告
```bash
cd <workspace>
python scripts/gen_report.py
```

输出：`etf_breakout_full_scan.html`

## 评分标准（0-15 分）

| 分数 | 评级 | 条件 |
|------|------|------|
| >= 11 且类型=平台突破 | AA | 高确定性突破 |
| >= 9 且类型=平台突破/微幅突破 | A | 较强突破信号 |
| >= 6 | B+ | 中等信号 |
| >= 4 | B | 弱信号 |

## 关键参数

| 参数 | 当前值 | 说明 |
|------|---------|------|
| 平台定义 | 前 80% K 线 | analyze.py 第 157 行 |
| 触及区间 | +-2.5% | 判断"触及平台高点"的容忍度 |
| 站稳判断 | 最近 3 日均价 > 平台高点 | 避免单日假突破 |

## 文件结构

```
references/
  default_etf_list.json  # 默认92个ETF清单
  algorithm_notes.md     # 算法细节和已知问题
scripts/
  fetch_kline_akshare.py   # 下载 K 线（AKShare）
  analyze.py               # 核心分析脚本（支持--all和--etf-list参数）
  gen_report.py           # 生成 HTML 报告
```

## 常见调整

**收紧标准**（减少假阳性）：
- 提高 touches_25pct 阈值（analyze.py 第 270-275 行）
- 增加 platform_duration 要求（第 277-282 行）

**放松标准**（增加候选）：
- 降低评分阈值（第 341-352 行）
- 放宽 is_real_platform 判断（第 216 行）
