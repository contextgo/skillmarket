#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
竞争优势护城河分析 — HTML 生成器
融合《投资的护城河》(晨星) 五大来源 + 《竞争优势》(格林沃尔德) 三大优势
用法：python generate_moat_html.py "[公司名称]" "[公司代码]" "[日期字符串]"
示例：python generate_moat_html.py "贵州茅台" "600519.SH" "2026年04月11日"
"""

import os
import sys
from datetime import datetime

# ─── 配置 ───────────────────────────────────────────────────────────────────
OUTPUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output")
os.makedirs(OUTPUT_DIR, exist_ok=True)

# ─── 字体常量 ───────────────────────────────────────────────────────────────
FP = "'PingFang SC','Microsoft YaHei','Helvetica Neue',Arial,sans-serif"


def get_params(argv):
    company_name = argv[1] if len(argv) >= 2 else "[待填写公司名称]"
    company_code = argv[2] if len(argv) >= 3 else "[待填写公司代码]"
    report_date = argv[3] if len(argv) >= 4 else datetime.now().strftime("%Y年%m月%d日 %H:%M")
    return company_name, company_code, report_date


def get_file_date():
    return datetime.now().strftime("%Y%m%d")


# ─── 四大模块数据 ───────────────────────────────────────────────────────────

def build_module_1():
    """模块一：定义与分析市场（起点）"""
    return '''
    <div class="module-block" style="border-left-color:#2563eb;">
        <div class="module-header">
            <span class="module-badge" style="background:#2563eb;">模块一</span>
            <h2 class="module-title">定义与分析市场</h2>
            <p class="module-subtitle">起点：竞争优势往往是「局部」的，必须先清晰界定竞争的「战场」</p>
        </div>
        <table class="analysis-table">
            <thead>
                <tr>
                    <th class="col-no">#</th>
                    <th class="col-q">核心问题 &amp; 分析要点</th>
                    <th class="col-answer">分析记录</th>
                </tr>
            </thead>
            <tbody>
                <tr class="row-light">
                    <td class="q-no">1</td>
                    <td class="q-text">
                        <div class="q-title">市场界定：公司核心赚钱的业务在哪个具体市场中竞争？</div>
                        <div class="q-detail">
                            请从以下两个维度清晰界定：<br>
                            <strong>地理范围</strong>：是全球、全国、区域还是本地市场？<br>
                            <strong>产品/服务范围</strong>：是宽泛的行业还是细分的品类/客户群体？<br>
                            <span class="tip">提示：竞争优势往往是「局部」的——大多数企业只在一个有限的地理区域或产品范围内拥有优势。避免泛泛而谈「白酒行业」或「银行业」，而应精确定义。</span>
                        </div>
                    </td>
                    <td class="answer-cell">
                        <div class="answer-line"></div>
                        <div class="answer-line"></div>
                        <div class="answer-line"></div>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>'''


def build_module_2():
    """模块二：识别竞争优势的潜在来源（定性分析）"""
    sections = [
        {
            "no": 2,
            "title": "供给侧优势（成本优势）",
            "source": "格林沃尔德 + 晨星",
            "icon": "&#9881;",
            "color": "#059669",
            "questions": "公司是否能以显著低于竞争对手的成本运营？原因是什么？",
            "details": [
                "专有技术/工艺：竞争对手无法复制的技术壁垒或复杂工艺？",
                "独特的低成本资源获取渠道？如自有矿产资源、地理位置优越的工厂？",
                "显著的规模经济/范围经济：固定成本是否被大幅摊薄？",
                "注意区分：简单的「效率高」可以被模仿，不属于结构性竞争优势"
            ]
        },
        {
            "no": 3,
            "title": "需求侧优势（客户锁定）",
            "source": "格林沃尔德 + 晨星",
            "icon": "&#128274;",
            "color": "#d97706",
            "questions": "客户是否因高转换成本、高搜寻成本或消费习惯而被锁定，不愿轻易转向竞争对手？",
            "details": [
                "高转换成本：客户学习新系统、数据迁移、业务中断风险是否很高？",
                "高搜寻成本：产品是否复杂、供应商评估是否困难（如专业服务、B2B）？",
                "消费习惯/品牌情感：客户是否出于习惯或情感忠诚不愿更换？",
                "注意：简单的品牌知名度或产品差异化，若无实质锁定效应，则不能构成持续壁垒"
            ]
        },
        {
            "no": 4,
            "title": "网络效应",
            "source": "晨星",
            "icon": "&#127760;",
            "color": "#7c3aed",
            "questions": "公司产品或服务的价值，是否会随着用户（或供应商）数量的增加而显著提升？",
            "details": [
                "是否形成「赢家通吃」或强者恒强的正反馈循环？",
                "新用户加入是否提升了老用户的价值（如社交网络、交易平台）？",
                "是否存在双边网络效应（如连接买家和卖家）？",
                "网络效应是最强大的护城河之一，但需要验证是否真正存在"
            ]
        },
        {
            "no": 5,
            "title": "无形资产",
            "source": "晨星",
            "icon": "&#127942;",
            "color": "#dc2626",
            "questions": "公司是否拥有能带来定价权或客户忠诚度的强大品牌、受保护的关键专利，或由政府授予的特许经营权/牌照？",
            "details": [
                "品牌：品牌是否能让公司收取溢价？客户是否因为品牌名而持续选择？",
                "专利：是否存在受法律保护、难以绕过的关键专利组合？专利到期时间？",
                "特许经营权/牌照：是否存在政府授予的、能限制竞争的合法垄断？",
                "监管许可：是否需要特殊审批或资质才能进入该领域？"
            ]
        },
        {
            "no": 6,
            "title": "有效规模",
            "source": "晨星",
            "icon": "&#9878;",
            "color": "#0891b2",
            "questions": "公司所在的是一个规模有限的利基市场吗？新竞争者进入是否会因无法达到经济规模而亏损？",
            "details": [
                "市场规模是否有限，只够容纳少数玩家？",
                "新进入者是否会因无法达到经济规模而亏损？",
                "现有参与者是否都无利可图，导致市场长期稳定？",
                "这通常出现在机场、公用事业、小众细分行业"
            ]
        }
    ]

    rows_html = ""
    for i, s in enumerate(sections):
        bg_class = "row-light" if i % 2 == 0 else "row-dark"
        details_html = "".join(f"<li>{d}</li>" for d in s["details"])
        rows_html += f'''
                <tr class="{bg_class}">
                    <td class="q-no">{s["no"]}</td>
                    <td class="q-text">
                        <div class="source-tag" style="background:{s["color"]};">
                            {s["icon"]} {s["title"]}
                            <span class="source-ref">{s["source"]}</span>
                        </div>
                        <div class="q-title">{s["questions"]}</div>
                        <div class="q-detail">
                            <ul class="detail-list">{details_html}</ul>
                        </div>
                    </td>
                    <td class="answer-cell">
                        <div class="answer-line"></div>
                        <div class="answer-line"></div>
                        <div class="answer-line"></div>
                    </td>
                </tr>'''

    return f'''
    <div class="module-block" style="border-left-color:#059669;">
        <div class="module-header">
            <span class="module-badge" style="background:#059669;">模块二</span>
            <h2 class="module-title">识别竞争优势的潜在来源（定性分析）</h2>
            <p class="module-subtitle">融合晨星「五大来源」+ 格林沃尔德「三大优势」，评估公司是否至少拥有一项或多项优势</p>
        </div>
        <div class="framework-note">
            <strong>分析框架对照：</strong>
            格林沃尔德三大优势 = 供给侧（成本优势）+ 需求侧（客户锁定）+ 规模经济效益；
            晨星五大来源 = 无形资产 + 成本优势 + 转换成本 + 网络效应 + 有效规模。
            二者高度互补，本模块将其整合为五项核心评估维度。
        </div>
        <table class="analysis-table">
            <thead>
                <tr>
                    <th class="col-no">#</th>
                    <th class="col-q">核心问题 &amp; 分析要点</th>
                    <th class="col-answer">分析记录</th>
                </tr>
            </thead>
            <tbody>
                {rows_html}
            </tbody>
        </table>
    </div>'''


def build_module_3():
    """模块三：验证竞争优势的存在（定量分析）"""
    return '''
    <div class="module-block" style="border-left-color:#d97706;">
        <div class="module-header">
            <span class="module-badge" style="background:#d97706;">模块三</span>
            <h2 class="module-title">验证竞争优势的存在（定量分析）</h2>
            <p class="module-subtitle">竞争优势必须体现在持久的优异财务表现上——用数据交叉验证定性判断</p>
        </div>
        <div class="framework-note">
            <strong>证据原则：</strong>两本书都强调——如果一家公司声称拥有竞争优势，其财务数据必须能够证明。定性分析是「可能性」，定量数据是「证据」。只有两者相互印证，结论才可靠。
        </div>
        <table class="analysis-table">
            <thead>
                <tr>
                    <th class="col-no">#</th>
                    <th class="col-q">核心问题 &amp; 分析要点</th>
                    <th class="col-answer">分析记录</th>
                </tr>
            </thead>
            <tbody>
                <tr class="row-light">
                    <td class="q-no">7</td>
                    <td class="q-text">
                        <div class="q-title">市场份额的稳定性：公司在您定义的市场中，市场份额是否长期保持稳定或增长？</div>
                        <div class="q-detail">
                            <ul class="detail-list">
                                <li>主导地位是否稳固？过去 5-10 年排名变化如何？</li>
                                <li>市场内是否少有新进入者或失败退出者？</li>
                                <li>如果市场份额变动剧烈、没有明确主导者，则很可能不存在强大的进入壁垒</li>
                            </ul>
                            <span class="tip">交叉验证：市场份额稳定 + 高盈利能力同时成立 = 竞争优势存在的高度可靠证据</span>
                        </div>
                    </td>
                    <td class="answer-cell">
                        <div class="answer-line"></div>
                        <div class="answer-line"></div>
                        <div class="answer-line"></div>
                    </td>
                </tr>
                <tr class="row-dark">
                    <td class="q-no">8</td>
                    <td class="q-text">
                        <div class="q-title">超额盈利能力：公司的 ROIC 是否长期、显著地高于 WACC？</div>
                        <div class="q-detail">
                            <ul class="detail-list">
                                <li>投入资本回报率（ROIC）是否长期显著高于加权平均资本成本（WACC）？</li>
                                <li>毛利率、营业利润率等是否持续高于行业平均水平？</li>
                                <li>这证明了其能持续创造「经济利润」，而非仅仅获得资本的平均回报</li>
                                <li>使用至少 10 年数据进行跨周期评估，避免单一年份的偶然性</li>
                            </ul>
                            <span class="tip">核心指标：如果 ROIC 长期趋于平均化（约 6%-8%），则很可能不存在竞争优势</span>
                        </div>
                    </td>
                    <td class="answer-cell">
                        <div class="answer-line"></div>
                        <div class="answer-line"></div>
                        <div class="answer-line"></div>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>'''


def build_module_4():
    """模块四：评估竞争优势的可持续性与趋势"""
    return '''
    <div class="module-block" style="border-left-color:#dc2626;">
        <div class="module-header">
            <span class="module-badge" style="background:#dc2626;">模块四</span>
            <h2 class="module-title">评估竞争优势的可持续性与趋势</h2>
            <p class="module-subtitle">向前看：评估优势的持久性和变化趋势——这是投资决策的关键</p>
        </div>
        <table class="analysis-table">
            <thead>
                <tr>
                    <th class="col-no">#</th>
                    <th class="col-q">核心问题 &amp; 分析要点</th>
                    <th class="col-answer">分析记录</th>
                </tr>
            </thead>
            <tbody>
                <tr class="row-light">
                    <td class="q-no">9</td>
                    <td class="q-text">
                        <div class="q-title">可持续性：公司的优势来源在未来 5-10 年甚至更长时间内是否可能持续？</div>
                        <div class="q-detail">
                            <strong>哪些因素可能<strong style="color:#dc2626;">侵蚀</strong>这些优势？</strong>
                            <ul class="detail-list">
                                <li>技术变革：是否有可能被颠覆性技术替代？</li>
                                <li>监管变化：政策调整是否可能削弱现有壁垒？</li>
                                <li>消费者偏好转移：客户需求是否正在发生结构性变化？</li>
                                <li>管理层决策：是否可能因错误的资本配置而削弱优势？</li>
                            </ul>
                            <strong>哪些因素可能<strong style="color:#059669;">加强</strong>这些优势？</strong>
                            <ul class="detail-list">
                                <li>品牌是否在增强？客户忠诚度是否在提高？</li>
                                <li>规模是否在扩大，成本优势是否在巩固？</li>
                                <li>网络效应是否在加速？</li>
                            </ul>
                        </div>
                    </td>
                    <td class="answer-cell">
                        <div class="answer-line"></div>
                        <div class="answer-line"></div>
                        <div class="answer-line"></div>
                    </td>
                </tr>
                <tr class="row-dark">
                    <td class="q-no">10</td>
                    <td class="q-text">
                        <div class="q-title">趋势判断：公司的护城河是在拓宽、维持不变还是收窄？</div>
                        <div class="q-detail">
                            请从以下各维度逐一判断趋势方向：
                            <ul class="detail-list">
                                <li>成本差距：与竞争对手的成本差距是在拉大还是缩小？</li>
                                <li>客户锁定：转换成本是否在增强？客户粘性是否在提高？</li>
                                <li>网络效应：用户增长速度是否在加速？</li>
                                <li>品牌价值：品牌溢价能力是否在增强？</li>
                                <li>规模优势：市场份额和规模效应是否在巩固？</li>
                            </ul>
                            <div class="trend-indicators">
                                <span class="trend-tag widening">&#9650; 拓宽</span>
                                <span class="trend-tag stable">&#9654; 维持</span>
                                <span class="trend-tag narrowing">&#9660; 收窄</span>
                            </div>
                        </div>
                    </td>
                    <td class="answer-cell">
                        <div class="answer-line"></div>
                        <div class="answer-line"></div>
                        <div class="answer-line"></div>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>'''


def build_conclusion():
    """最终结论模块"""
    return '''
    <div class="conclusion-block">
        <div class="conclusion-header">
            <span class="conclusion-icon">&#9733;</span>
            <h2>最终结论</h2>
        </div>
        <p class="conclusion-desc">综合以上四个模块的分析，请给出您的最终判断：</p>
        <table class="conclusion-table">
            <tr>
                <td class="conclusion-label">该公司是否拥有真正的、可持续的竞争优势？</td>
                <td class="conclusion-value">
                    <span class="verdict-yes">&#10003; 是</span>
                    <span class="verdict-no">&#10007; 否</span>
                    <span class="verdict-partial">&#9679; 部分拥有</span>
                </td>
            </tr>
            <tr>
                <td class="conclusion-label">最核心的优势来源是什么？</td>
                <td class="conclusion-value">
                    <span class="source-option">供给侧（成本优势）</span>
                    <span class="source-option">需求侧（客户锁定）</span>
                    <span class="source-option">网络效应</span>
                    <span class="source-option">无形资产</span>
                    <span class="source-option">有效规模</span>
                </td>
            </tr>
            <tr>
                <td class="conclusion-label">竞争优势的强度如何？</td>
                <td class="conclusion-value">
                    <span class="strength-tag wide">宽阔（Very Wide）</span>
                    <span class="strength-tag narrow">狭窄（Narrow）</span>
                    <span class="strength-tag none">无（None）</span>
                </td>
            </tr>
            <tr>
                <td class="conclusion-label">竞争优势的可持续性如何？</td>
                <td class="conclusion-value">
                    <span class="sustain-tag long">长期可持续（10年+）</span>
                    <span class="sustain-tag medium">中期可持续（5-10年）</span>
                    <span class="sustain-tag short">短期/不确定</span>
                </td>
            </tr>
            <tr>
                <td class="conclusion-label" style="vertical-align:top;">综合分析论述：</td>
                <td class="conclusion-value" style="vertical-align:top;">
                    <div class="conclusion-text-area">
                        <div class="answer-line"></div>
                        <div class="answer-line"></div>
                        <div class="answer-line"></div>
                        <div class="answer-line"></div>
                        <div class="answer-line"></div>
                        <div class="answer-line"></div>
                    </div>
                </td>
            </tr>
        </table>
    </div>'''


def build_html(company_name, company_code, report_date):
    """组装完整的 HTML 报告"""
    module1 = build_module_1()
    module2 = build_module_2()
    module3 = build_module_3()
    module4 = build_module_4()
    conclusion = build_conclusion()

    html = f'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>竞争优势护城河分析 · {company_name}</title>
<style>
/* ── 全局重置 ── */
* {{ box-sizing: border-box; margin: 0; padding: 0; }}

/* ── 基础排版 ── */
body {{
    font-family: {FP};
    background: #e8eef5;
    color: #1e293b;
    line-height: 1.8;
    padding: 20px 10px;
    -webkit-text-size-adjust: 100%;
}}

/* ── 外层容器 ── */
.wrapper {{
    max-width: 960px;
    margin: 0 auto;
    background: #ffffff;
    border-radius: 12px;
    box-shadow: 0 4px 24px rgba(0,0,0,0.10);
    overflow: hidden;
}}

/* ── 报告头部 ── */
.report-header {{
    background: linear-gradient(135deg, #0f172a 0%, #1e3a5f 50%, #0f172a 100%);
    color: #fff;
    padding: 40px 50px 36px;
    text-align: center;
    position: relative;
    overflow: hidden;
}}
.report-header::before {{
    content: "";
    position: absolute;
    top: -60px; right: -60px;
    width: 220px; height: 220px;
    border-radius: 50%;
    background: rgba(201,168,76,0.12);
}}
.report-header::after {{
    content: "";
    position: absolute;
    bottom: -40px; left: -40px;
    width: 180px; height: 180px;
    border-radius: 50%;
    background: rgba(37,99,235,0.10);
}}
.logo-tag {{
    display: inline-block;
    background: rgba(201,168,76,0.20);
    border: 1px solid rgba(201,168,76,0.45);
    color: #c9a84c;
    padding: 5px 18px;
    border-radius: 20px;
    font-size: 12px;
    letter-spacing: 3px;
    margin-bottom: 14px;
    text-transform: uppercase;
    position: relative; z-index: 1;
}}
.report-header h1 {{
    font-size: 26px;
    font-weight: 700;
    color: #ffffff;
    letter-spacing: 1px;
    margin-bottom: 10px;
    position: relative; z-index: 1;
}}
.report-header h1 .highlight {{ color: #c9a84c; }}
.company-info {{
    display: inline-block;
    background: rgba(255,255,255,0.10);
    border: 1px solid rgba(255,255,255,0.20);
    padding: 8px 24px;
    border-radius: 8px;
    margin: 10px 0;
    position: relative; z-index: 1;
}}
.company-info .name {{
    font-size: 20px;
    font-weight: 700;
    color: #ffffff;
}}
.company-info .code {{
    font-size: 14px;
    color: #7ab8e0;
    margin-left: 8px;
}}
.report-meta {{
    font-size: 13px;
    color: rgba(255,255,255,0.6);
    margin-top: 8px;
    position: relative; z-index: 1;
}}
.report-meta strong {{ color: #c9a84c; }}
.report-subtitle {{
    font-size: 13px;
    color: rgba(255,255,255,0.45);
    margin-top: 14px;
    max-width: 640px;
    margin-left: auto;
    margin-right: auto;
    position: relative; z-index: 1;
    line-height: 1.7;
}}

/* ── 使用指南 ── */
.guide-box {{
    background: linear-gradient(90deg, #f0f4ff 0%, #fff 100%);
    border: 1px solid #c5d8f8;
    border-radius: 8px;
    margin: 28px 36px;
    padding: 18px 22px;
}}
.guide-box h3 {{
    color: #0f172a;
    font-size: 15px;
    margin-bottom: 10px;
    display: flex;
    align-items: center;
    gap: 8px;
}}
.guide-box h3::before {{
    content: "\\25B6";
    color: #2563eb;
    font-size: 11px;
}}
.guide-box ol {{
    padding-left: 20px;
    color: #334155;
    font-size: 13px;
}}
.guide-box ol li {{ margin-bottom: 4px; }}
.guide-box .highlight {{
    background: #fffbeb;
    border: 1px solid #fde68a;
    border-radius: 6px;
    padding: 10px 14px;
    font-size: 12.5px;
    color: #92400e;
    margin-top: 10px;
}}

/* ── 模块区块 ── */
.module-block {{
    margin: 22px 36px;
    border-radius: 10px;
    overflow: hidden;
    border-left: 5px solid #ccc;
    background: #ffffff;
    box-shadow: 0 2px 10px rgba(0,0,0,0.06);
}}
.module-header {{
    padding: 16px 22px 12px;
    border-bottom: 2px solid #f1f5f9;
    display: flex;
    align-items: center;
    gap: 12px;
    flex-wrap: wrap;
}}
.module-badge {{
    color: #fff;
    font-size: 11px;
    font-weight: 700;
    padding: 3px 12px;
    border-radius: 20px;
    letter-spacing: 1px;
    white-space: nowrap;
    flex-shrink: 0;
}}
.module-title {{
    font-size: 17px;
    font-weight: 700;
    color: #0f172a;
}}
.module-subtitle {{
    width: 100%;
    font-size: 12.5px;
    color: #64748b;
    margin-top: 4px;
    padding-left: 0;
    font-style: italic;
}}

/* ── 框架说明 ── */
.framework-note {{
    background: #fefce8;
    border: 1px solid #fde68a;
    border-radius: 6px;
    margin: 14px 22px;
    padding: 12px 16px;
    font-size: 12.5px;
    color: #78350f;
    line-height: 1.7;
}}

/* ── 分析表格 ── */
.analysis-table {{
    width: 100%;
    border-collapse: collapse;
    font-size: 13.5px;
}}
.analysis-table thead {{
    background: #0f172a;
    color: #fff;
}}
.analysis-table thead th {{
    padding: 10px 14px;
    font-weight: 600;
    font-size: 12px;
    letter-spacing: 0.5px;
    text-align: left;
}}
.col-no {{ width: 42px; text-align: center !important; }}
.col-q {{ width: 58%; }}
.col-answer {{ width: 30%; }}
.analysis-table tbody tr {{
    border-bottom: 1px solid #f1f5f9;
}}
.row-light {{ background: rgba(255,255,255,1.0); }}
.row-dark {{ background: #f8fafc; }}
.analysis-table tbody tr:hover {{ background: #eff6ff; }}
.analysis-table td {{
    padding: 14px 14px;
    vertical-align: top;
}}
.q-no {{
    text-align: center;
    font-size: 18px;
    font-weight: 700;
    color: #0f172a;
    width: 42px;
}}
.source-tag {{
    display: inline-block;
    color: #fff;
    font-size: 12px;
    font-weight: 700;
    padding: 4px 14px;
    border-radius: 6px;
    margin-bottom: 8px;
    letter-spacing: 0.5px;
}}
.source-ref {{
    font-weight: 400;
    font-size: 10px;
    opacity: 0.8;
    margin-left: 6px;
}}
.q-title {{
    font-weight: 600;
    color: #0f172a;
    font-size: 13.5px;
    margin-bottom: 6px;
    line-height: 1.6;
}}
.q-detail {{
    font-size: 12px;
    color: #475569;
    line-height: 1.7;
}}
.q-detail strong {{
    color: #1e293b;
}}
.detail-list {{
    padding-left: 18px;
    margin: 4px 0;
}}
.detail-list li {{
    margin-bottom: 3px;
    line-height: 1.6;
}}
.tip {{
    display: block;
    background: #eff6ff;
    border-left: 3px solid #2563eb;
    padding: 8px 12px;
    border-radius: 0 4px 4px 0;
    margin-top: 8px;
    font-size: 11.5px;
    color: #1e40af;
}}

/* ── 答案区域 ── */
.answer-cell {{
    border-left: 1px solid #e2e8f0;
    min-height: 80px;
}}
.answer-line {{
    border-bottom: 1px dashed #cbd5e1;
    height: 18px;
    margin: 0 4px 4px;
}}

/* ── 趋势标签 ── */
.trend-indicators {{
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
    margin-top: 8px;
}}
.trend-tag {{
    display: inline-block;
    padding: 3px 12px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 600;
}}
.widening {{ background: #dcfce7; color: #166534; border: 1px solid #86efac; }}
.stable {{ background: #fef9c3; color: #854d0e; border: 1px solid #fde047; }}
.narrowing {{ background: #fee2e2; color: #991b1b; border: 1px solid #fca5a5; }}

/* ── 最终结论 ── */
.conclusion-block {{
    margin: 28px 36px;
    background: linear-gradient(135deg, #fefce8 0%, #fff7ed 100%);
    border: 2px solid #c9a84c;
    border-radius: 10px;
    overflow: hidden;
}}
.conclusion-header {{
    padding: 16px 22px;
    background: #0f172a;
    display: flex;
    align-items: center;
    gap: 10px;
}}
.conclusion-icon {{
    color: #c9a84c;
    font-size: 22px;
}}
.conclusion-header h2 {{
    color: #ffffff;
    font-size: 18px;
    font-weight: 700;
}}
.conclusion-desc {{
    padding: 14px 22px 8px;
    font-size: 13.5px;
    color: #44403c;
}}
.conclusion-table {{
    width: 100%;
    border-collapse: collapse;
    margin: 0 22px 22px;
}}
.conclusion-table tr {{
    border-bottom: 1px solid #fde68a;
}}
.conclusion-table tr:last-child {{
    border-bottom: none;
}}
.conclusion-label {{
    padding: 12px 16px;
    font-size: 13px;
    font-weight: 600;
    color: #44403c;
    width: 42%;
    background: rgba(255,255,255,0.5);
}}
.conclusion-value {{
    padding: 12px 16px;
    font-size: 13px;
    color: #1e293b;
    width: 58%;
}}
.verdict-yes {{
    display: inline-block;
    background: #dcfce7;
    color: #166534;
    padding: 4px 16px;
    border-radius: 6px;
    font-weight: 700;
    margin-right: 6px;
    border: 1px solid #86efac;
}}
.verdict-no {{
    display: inline-block;
    background: #fee2e2;
    color: #991b1b;
    padding: 4px 16px;
    border-radius: 6px;
    font-weight: 700;
    margin-right: 6px;
    border: 1px solid #fca5a5;
}}
.verdict-partial {{
    display: inline-block;
    background: #fef9c3;
    color: #854d0e;
    padding: 4px 16px;
    border-radius: 6px;
    font-weight: 700;
    border: 1px solid #fde047;
}}
.source-option {{
    display: inline-block;
    background: #eff6ff;
    color: #1e40af;
    padding: 3px 10px;
    border-radius: 6px;
    font-size: 12px;
    margin: 2px 4px;
    border: 1px solid #bfdbfe;
}}
.strength-tag {{
    display: inline-block;
    padding: 4px 14px;
    border-radius: 6px;
    font-weight: 700;
    font-size: 12px;
    margin-right: 6px;
}}
.wide {{ background: #dcfce7; color: #166534; border: 1px solid #86efac; }}
.narrow {{ background: #fef9c3; color: #854d0e; border: 1px solid #fde047; }}
.none {{ background: #fee2e2; color: #991b1b; border: 1px solid #fca5a5; }}
.sustain-tag {{
    display: inline-block;
    padding: 4px 14px;
    border-radius: 6px;
    font-weight: 700;
    font-size: 12px;
    margin-right: 6px;
}}
.long {{ background: #dcfce7; color: #166534; border: 1px solid #86efac; }}
.medium {{ background: #fef9c3; color: #854d0e; border: 1px solid #fde047; }}
.short {{ background: #fee2e2; color: #991b1b; border: 1px solid #fca5a5; }}
.conclusion-text-area {{
    min-height: 100px;
}}

/* ── 底部声明 ── */
.footer-section {{
    margin: 28px 36px 36px;
    padding: 22px;
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
}}
.footer-section h3 {{
    font-size: 15px;
    color: #0f172a;
    margin-bottom: 10px;
    display: flex;
    align-items: center;
    gap: 8px;
}}
.footer-section h3::before {{
    content: "\\25C6";
    color: #c9a84c;
    font-size: 10px;
}}
.footer-section p {{
    font-size: 12.5px;
    color: #64748b;
    line-height: 1.8;
    margin-bottom: 6px;
}}
.footer-section .highlight {{
    background: #fffbeb;
    border: 1px solid #fde68a;
    border-radius: 6px;
    padding: 10px 14px;
    font-size: 12.5px;
    color: #92400e;
    margin-top: 10px;
}}

/* ── 页脚 ── */
.report-footer {{
    background: #0f172a;
    color: rgba(255,255,255,0.45);
    text-align: center;
    padding: 16px;
    font-size: 11.5px;
}}
.report-footer span {{ color: #c9a84c; }}

/* ── 响应式 ── */
@media (max-width: 700px) {{
    .report-header {{ padding: 28px 20px 24px; }}
    .report-header h1 {{ font-size: 20px; }}
    .company-info .name {{ font-size: 17px; }}
    .guide-box {{ margin: 18px 14px; }}
    .module-block {{ margin: 14px 14px; }}
    .conclusion-block {{ margin: 18px 14px; }}
    .footer-section {{ margin: 18px 14px 28px; }}
    .analysis-table {{ font-size: 12px; }}
    .analysis-table td,
    .analysis-table thead th {{ padding: 10px; }}
    .col-q {{ width: 55%; }}
    .col-answer {{ width: 25%; }}
    .q-title {{ font-size: 12.5px; }}
    .q-detail {{ font-size: 11px; }}
    .framework-note {{ margin: 10px 14px; }}
    .conclusion-table {{ margin: 0 10px 14px; }}
    .conclusion-label {{ width: 38%; padding: 10px 8px; font-size: 12px; }}
    .conclusion-value {{ width: 62%; padding: 10px 8px; font-size: 12px; }}
}}
@media (max-width: 480px) {{
    .analysis-table {{ font-size: 11px; }}
    .col-answer {{ display: none; }}
    .col-q {{ width: auto; }}
    .module-header {{ padding: 12px 14px 10px; }}
    .module-title {{ font-size: 15px; }}
    .source-tag {{ font-size: 11px; padding: 3px 10px; }}
}}
</style>
</head>
<body>
<div class="wrapper">

    <!-- 报告头部 -->
    <div class="report-header">
        <div class="logo-tag">归江价值投资体系</div>
        <h1>竞争优势<span class="highlight">&middot;</span>护城河分析</h1>
        <div class="company-info">
            <span class="name">{company_name}</span>
            <span class="code">{company_code}</span>
        </div>
        <div class="report-meta">
            生成时间：<strong>{report_date}</strong> &nbsp;|&nbsp; 数据截止日期：<strong>{report_date.split(" ")[0]}</strong>
        </div>
        <div class="report-subtitle">
            融合《投资的护城河》（晨星）五大来源 + 《竞争优势》（格林沃尔德）三大优势 &middot; 四模块十项系统评估
        </div>
    </div>

    <!-- 使用指南 -->
    <div class="guide-box">
        <h3>使用指南</h3>
        <ol>
            <li>首先完成<strong>模块一</strong>，清晰界定目标公司参与竞争的具体市场（地理 + 产品范围）。</li>
            <li>在<strong>模块二</strong>中，逐一评估五项潜在优势来源，判断公司是否至少拥有一项。</li>
            <li>用<strong>模块三</strong>的定量指标（市场份额稳定性 + ROIC vs WACC）交叉验证定性判断。</li>
            <li>在<strong>模块四</strong>中前瞻评估优势的可持续性，判断护城河的演变趋势。</li>
            <li>最终在<strong>结论区</strong>给出综合判断，确认优势类型、强度和可持续性。</li>
        </ol>
        <div class="highlight">
            <strong>核心原则：</strong>定性分析是「可能性」，定量数据是「证据」。只有两者相互印证，结论才可靠。
            竞争优势往往是「局部」的——先精确定义战场，再评估壁垒。
        </div>
    </div>

    <!-- 模块一 -->
    {module1}

    <!-- 模块二 -->
    {module2}

    <!-- 模块三 -->
    {module3}

    <!-- 模块四 -->
    {module4}

    <!-- 最终结论 -->
    {conclusion}

    <!-- 底部声明 -->
    <div class="footer-section">
        <h3>分析框架说明</h3>
        <p>本分析框架融合了两部经典著作的核心思想：</p>
        <p>
            <strong>《投资的护城河》（帕特&middot;多尔西，晨星公司）</strong>提出竞争优势的五大来源：
            无形资产、成本优势、转换成本、网络效应、有效规模。
        </p>
        <p>
            <strong>《竞争优势：透视企业护城河》（布鲁斯&middot;格林沃尔德）</strong>提出三种真正的竞争优势：
            供给侧（成本优势）、需求侧（客户锁定）、规模经济效益。
        </p>
        <p>二者高度互补。格林沃尔德框架强调「从局部市场出发、用市场份额和盈利能力验证」；晨星框架提供更丰富的分类维度。本分析将二者整合，力求全面、系统。</p>
        <div class="highlight">
            <strong>数据时效性说明：</strong>本报告所有财务数据与行情数据均以报告生成时的计算机当前时间为基准获取。
            财务报告期次根据各市场披露规则自动判断（A股：一季报4月底、中报8月底、三季报10月底、年报次年4月底；
            港股：中报9月底、年报次年3月底；美股：10-Q财季后45天、10-K财年后90天）。
            行情数据使用最新交易日收盘价。数据截止日期：<strong>{report_date.split(" ")[0]}</strong>
        </div>
        <div class="highlight">
            <strong>免责声明：</strong>本分析工具仅为研究辅助框架，不构成投资建议。请结合具体标的的基本面研究、行业分析和独立判断，理性决策。
        </div>
    </div>

    <!-- 页脚 -->
    <div class="report-footer">
        归江价值投资体系 &middot; <span>归江价值精选</span> &middot; 竞争优势护城河分析 &middot; 深度价值 &middot; 逆向投资
    </div>

</div>
</body>
</html>'''
    return html


def main():
    company_name, company_code, report_date = get_params(sys.argv)
    file_date = get_file_date()
    html_content = build_html(company_name, company_code, report_date)

    filename = f"竞争优势护城河分析_{company_name}_{file_date}.html"
    filepath = os.path.join(OUTPUT_DIR, filename)

    with open(filepath, "w", encoding="utf-8") as f:
        f.write(html_content)

    print(f"[OK] HTML 报告已生成：{filepath}")
    print(f"[INFO] 公司名称：{company_name}")
    print(f"[INFO] 公司代码：{company_code}")
    print(f"[DATE] 报告日期：{report_date}")
    return filepath


if __name__ == "__main__":
    main()
