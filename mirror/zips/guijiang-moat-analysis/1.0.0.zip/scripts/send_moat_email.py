# -*- coding: utf-8 -*-
"""
竞争优势护城河分析 — 邮件发送模块
功能：
  1. HTML 报告作为附件添加到邮件
  2. 邮件正文使用白底高对比格式（内联样式，表格布局）
  3. 保留纯文本降级版本
  4. 完整的邮件头信息
  5. 转发格式保持一致（全内联样式）

格式标准：
  - 白色正文区背景 + 深色标题 + 高对比度
  - HTML 表格布局（兼容 QQ/163/Outlook/Gmail）
  - 移除 border-radius（邮件客户端不支持）
  - 全局 inline style
  - 字号 >= 13px
"""

import os
import sys
import smtplib
import importlib.util
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from email.header import Header
from email.utils import formataddr

# ─── 邮件配置（复用 Claw 中已保存的配置）──────────────
CONFIG_PATH = r"C:\Users\Administrator\WorkBuddy\Claw\email_config.py"


def load_email_config():
    """从 email_config.py 读取配置"""
    spec = importlib.util.spec_from_file_location("email_config", CONFIG_PATH)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return {
        "sender":      module.SENDER_EMAIL,
        "password":    module.EMAIL_PASSWORD,
        "recipient":   module.RECEIVER_EMAIL,
        "smtp_server": getattr(module, "SMTP_SERVER", "smtp.qq.com"),
        "smtp_port":   getattr(module, "SMTP_PORT", 587),
    }


def find_latest_report():
    """查找 output 目录下最新的护城河分析 HTML 文件"""
    skill_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    output_dir = os.path.join(skill_dir, "scripts", "output")
    if not os.path.exists(output_dir):
        return None
    files = [
        f for f in os.listdir(output_dir)
        if f.startswith("竞争优势护城河分析_") and f.endswith(".html")
    ]
    if not files:
        return None
    latest = sorted(files)[-1]
    return os.path.join(output_dir, latest)


def extract_info_from_filename(filename):
    """从文件名提取公司名称和日期"""
    # 文件名格式: 竞争优势护城河分析_贵州茅台_20260411.html
    base = os.path.basename(filename).replace(".html", "")
    parts = base.split("_")
    # parts[0] = 竞争优势护城河分析
    # parts[1:-1] = 公司名称（可能含下划线）
    # parts[-1] = 日期
    if len(parts) >= 3:
        company_name = "_".join(parts[1:-1])
        date_str = parts[-1]
    else:
        company_name = "目标公司"
        date_str = parts[-1] if len(parts) > 1 else ""

    formatted_date = f"{date_str[:4]}年{date_str[4:6]}月{date_str[6:8]}日" if len(date_str) >= 8 else date_str
    return company_name, formatted_date, date_str


def build_email_body(company_name, formatted_date, filename):
    """
    构建白底高对比邮件正文（内联样式，表格布局）。
    转发格式保持一致：全内联样式，无外部依赖。
    """
    FP = "'PingFang SC','Microsoft YaHei',sans-serif"
    return (
        '<!DOCTYPE html>'
        '<html lang="zh-CN">'
        '<head><meta charset="UTF-8">'
        '<meta name="viewport" content="width=device-width,initial-scale=1">'
        f'<title>竞争优势护城河分析 · {company_name}</title></head>'
        f'<body style="margin:0;padding:0;background:#e8eef5;font-family:{FP}">'

        # 外层包裹
        '<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#e8eef5;padding:20px 0">'
        '<tr><td align="center">'
        '<table width="700" cellpadding="0" cellspacing="0" border="0" style="max-width:700px">'

        # 邮件头
        '<tr><td style="background:#0f172a;padding:28px 28px 22px">'
        '<div style="text-align:center">'
        f'<div style="font-size:11px;color:#7ab8e0;letter-spacing:3px;margin-bottom:8px;font-family:{FP}">归江价值投资体系</div>'
        f'<h1 style="font-size:22px;font-weight:700;color:#ffffff;margin:0 0 8px;letter-spacing:2px;font-family:{FP}">竞争优势 · 护城河分析</h1>'
        f'<div style="font-size:15px;color:#ffffff;margin:0 0 6px;font-weight:600;font-family:{FP}">{company_name}</div>'
        f'<div style="font-size:13px;color:#7ab8e0;margin-bottom:0;font-family:{FP}">生成日期：{formatted_date}</div>'
        '</div></td></tr>'

        # 提示
        '<tr><td style="background:#ffffff;padding:16px 20px;border-left:1px solid #d0dff0;border-right:1px solid #d0dff0">'
        '<table cellpadding="0" cellspacing="0" border="0" style="background:#fffbeb;border:1px solid #fde68a;width:100%">'
        '<tr><td style="padding:12px 20px;font-size:13px;color:#92400e;font-family:{FP}">'
        '<b>提示：</b>完整的护城河分析报告已作为附件附上。如正文显示不完整，请下载附件在浏览器中打开查看。'
        '</td></tr></table></td></tr>'

        # 内容简介
        '<tr><td style="background:#ffffff;padding:20px 24px;border-left:1px solid #d0dff0;border-right:1px solid #d0dff0">'
        f'<p style="font-size:14px;font-weight:700;color:#0f172a;margin:0 0 12px;font-family:{FP}">尊敬的价值投资者：</p>'
        f'<p style="font-size:13px;color:#334155;line-height:1.9;margin:0 0 12px;font-family:{FP}">'
        f'您好！附件为您自动生成的《竞争优势护城河分析报告》，分析对象：{company_name}，生成日期：{formatted_date}。</p>'
        f'<p style="font-size:13px;color:#334155;line-height:1.9;margin:0 0 12px;font-family:{FP}">'
        f'本报告融合《投资的护城河》（晨星）与《竞争优势》（格林沃尔德），涵盖四大模块十项评估：</p>'
        f'<table cellpadding="0" cellspacing="0" border="0" style="margin:0 0 8px">'
        f'<tr><td style="padding:3px 0;font-size:13px;color:#0f172a;font-family:{FP};font-weight:600">模块一：定义与分析市场</td></tr>'
        f'<tr><td style="padding:3px 0;font-size:13px;color:#334155;font-family:{FP}">界定竞争的「战场」——地理范围 + 产品/服务范围</td></tr>'
        f'</table>'
        f'<table cellpadding="0" cellspacing="0" border="0" style="margin:0 0 8px">'
        f'<tr><td style="padding:3px 0;font-size:13px;color:#0f172a;font-family:{FP};font-weight:600">模块二：识别竞争优势来源</td></tr>'
        f'<tr><td style="padding:3px 0;font-size:13px;color:#334155;font-family:{FP}">供给侧（成本优势）、需求侧（客户锁定）、网络效应、无形资产、有效规模</td></tr>'
        f'</table>'
        f'<table cellpadding="0" cellspacing="0" border="0" style="margin:0 0 8px">'
        f'<tr><td style="padding:3px 0;font-size:13px;color:#0f172a;font-family:{FP};font-weight:600">模块三：验证竞争优势</td></tr>'
        f'<tr><td style="padding:3px 0;font-size:13px;color:#334155;font-family:{FP}">市场份额稳定性 + ROIC vs WACC 定量交叉验证</td></tr>'
        f'</table>'
        f'<table cellpadding="0" cellspacing="0" border="0" style="margin:0 0 16px">'
        f'<tr><td style="padding:3px 0;font-size:13px;color:#0f172a;font-family:{FP};font-weight:600">模块四：可持续性与趋势</td></tr>'
        f'<tr><td style="padding:3px 0;font-size:13px;color:#334155;font-family:{FP}">前瞻评估 5-10 年可持续性 + 护城河拓宽/维持/收窄趋势</td></tr>'
        f'</table>'
        f'<p style="font-size:13px;color:#334155;line-height:1.9;margin:0;font-family:{FP}">'
        f'请在投资决策前逐一填写分析记录，做好护城河「体检」。</p>'
        '</td></tr>'

        # 邮件底
        '<tr><td style="background:#f0f4f8;padding:18px 24px;border:1px solid #d0dff0;border-top:none">'
        f'<p style="font-size:11px;color:#64748b;text-align:center;margin:0 0 4px;font-family:{FP}">'
        f'本邮件由归江价值精选自动化系统生成 · {formatted_date}</p>'
        f'<p style="font-size:11px;color:#94a3b8;text-align:center;margin:0;font-family:{FP}">'
        f'归江价值投资体系 · 竞争优势护城河分析 · 深度价值 · 逆向投资</p>'
        '</td></tr>'

        '</table></td></tr></table>'
        '</body></html>'
    )


def send_email(html_path, config):
    """
    发送护城河分析邮件，包含：
      - HTML 邮件正文（白底高对比，全内联样式）
      - HTML 报告作为附件
    """
    filename = os.path.basename(html_path)
    company_name, formatted_date, date_str = extract_info_from_filename(filename)

    # 构建邮件
    msg = MIMEMultipart('mixed')
    subject = f"【竞争优势护城河分析】{company_name} · {formatted_date}"
    msg['From']    = formataddr((str(Header("归江价值精选·护城河分析", 'utf-8')), config["sender"]))
    msg['To']      = config["recipient"]
    msg['Subject'] = Header(subject, 'utf-8')

    # 纯文本版本（降级）
    plain_text = (
        f"竞争优势护城河分析报告\n"
        f"{'='*40}\n\n"
        f"尊敬的价值投资者：\n\n"
        f"您好！附件为您自动生成的《竞争优势护城河分析报告》。\n"
        f"分析对象：{company_name}\n"
        f"生成日期：{formatted_date}\n\n"
        f"本报告融合《投资的护城河》（晨星）与《竞争优势》（格林沃尔德），涵盖：\n"
        f"  模块一：定义与分析市场\n"
        f"  模块二：识别竞争优势来源（五大维度）\n"
        f"  模块三：验证竞争优势（定量分析）\n"
        f"  模块四：可持续性与趋势评估\n\n"
        f"请在投资决策前逐一填写分析记录。\n\n"
        f"归江价值投资体系 · 深度价值 · 逆向投资\n"
        f"（本邮件由自动化系统发送，请勿直接回复）"
    )
    msg.attach(MIMEText(plain_text, "plain", "utf-8"))

    # HTML 邮件正文
    email_body = build_email_body(company_name, formatted_date, filename)
    msg.attach(MIMEText(email_body, "html", "utf-8"))

    # ── HTML 报告作为附件 ───────────────────────────────────
    att_name = filename
    with open(html_path, 'rb') as f:
        att = MIMEApplication(f.read(), Name=att_name)
    att.add_header(
        'Content-Disposition', 'attachment',
        filename=('utf-8', '', att_name)
    )
    msg.attach(att)

    # 发送
    print(f"[INFO] 连接 SMTP: {config['smtp_server']}:{config['smtp_port']}")
    print(f"[INFO] 发件人: {config['sender']}")
    print(f"[INFO] 收件人: {config['recipient']}")
    print(f"[INFO] 附件: {att_name}")

    with smtplib.SMTP(config["smtp_server"], config["smtp_port"]) as server:
        server.ehlo()
        server.starttls()
        server.ehlo()
        server.login(config["sender"], config["password"])
        server.sendmail(config["sender"], config["recipient"], msg.as_string())

    print(f"[OK] 邮件发送成功！")
    return True


def main():
    # 确定 HTML 文件路径
    if len(sys.argv) >= 2:
        html_path = sys.argv[1]
    else:
        html_path = find_latest_report()
        if html_path is None:
            print("[ERROR] 请先运行 generate_moat_html.py 生成分析报告，"
                  "或传入 HTML 文件路径作为参数。")
            sys.exit(1)

    if not os.path.exists(html_path):
        print(f"[ERROR] HTML 文件不存在：{html_path}")
        sys.exit(1)

    print(f"[INFO] 使用报告文件：{html_path}")

    try:
        config = load_email_config()
    except Exception as e:
        print(f"[ERROR] 读取邮件配置失败：{e}")
        print("[ERROR] 请确保 email_config.py 存在并包含正确的配置字段。")
        sys.exit(1)

    send_email(html_path, config)
    print(f"\n[COMPLETE] 邮件已发送至 {config['recipient']}")
    print(f"[FILE] HTML 文件路径：{html_path}")


if __name__ == "__main__":
    main()
