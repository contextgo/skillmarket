---
name: x-publisher
description: >
  X (Twitter) 自动化发布工具，支持推文、推文串、互动、数据抓取。
  使用 openclaw browser 操控浏览器执行操作。
triggers:
  - 发布推文/post tweet
  - 发推文/发推
  - 推文串/thread
  - 点赞/like
  - 转发/repost
  - 回复/reply
  - 收藏/bookmark
  - 删除/delete
  - 粉丝数/followers
  - 推文统计/stats
metadata:
  openclaw:
    homepage: x-publisher
---

# x-publisher — X (Twitter) 发布工具

X (Twitter) 自动化发布工具，支持推文、推文串、互动、数据抓取。

## 路由表

| 命令 | 说明 | 示例 |
|------|------|------|
| check | 检查运行环境 | `x-publish.py check` |
| tweet | 发布推文 | `x-publish.py tweet "内容"` |
| thread | 发布推文串 | `x-publish.py thread "第一篇\|\|\|第二篇"` |
| reply | 回复帖子 | `x-publish.py reply 123456789 "内容"` |
| like/unlike | 点赞/取消点赞 | `x-publish.py like 123456789` |
| bookmark/unbookmark | 收藏/取消收藏 | `x-publish.py bookmark 123456789` |
| repost | 转发 | `x-publish.py repost 123456789` |
| quote | 引用转发 | `x-publish.py quote 123456789 "评论"` |
| delete | 删除推文 | `x-publish.py delete 123456789` |
| followers | 获取粉丝数 | `x-publish.py followers "用户名"` |
| stats | 获取推文统计 | `x-publish.py stats 123456789` |

## 环境要求

| 依赖 | 说明 |
|------|------|
| Python 3.6+ | 运行环境 |
| openclaw CLI | 浏览器控制核心 |

### 安装 openclaw

```bash
# macOS
brew install openclaw

# 或参考 openclaw 官方文档
```

### 检查环境

```bash
x-publish.py check
```

### 检查账号登录

使用 openclaw browser 访问 X.com 确认已登录：

```bash
openclaw browser open https://x.com/home
```

或访问 https://x.com 确认登录状态。

## 使用方式

```bash
cd ./scripts
python3 x-publish.py <命令> [参数]
```

## 选项

（无全局选项）

## 命令详解

### tweet — 发布推文

```bash
x-publish.py tweet "这是一条推文"
```

### thread — 发布推文串

使用 `|||` 分隔多篇推文：

```bash
x-publish.py thread "第一篇内容|||第二篇内容|||第三篇内容"
```

**Thread 发布流程：**
1. 打开 `compose/post` 页面
2. 输入第一篇内容
3. 出现"添加帖子"按钮，点击新增 textbox
4. 输入后续内容
5. 最后点击"全部发帖"发布

### reply — 回复推文

```bash
x-publish.py reply 123456789 "回复内容"
```

### like / unlike — 点赞/取消点赞

```bash
x-publish.py like 123456789
x-publish.py unlike 123456789
```

### bookmark / unbookmark — 收藏/取消收藏

```bash
x-publish.py bookmark 123456789
x-publish.py unbookmark 123456789
```

### repost — 转发（无评论）

```bash
x-publish.py repost 123456789
```

### quote — 引用转发（带评论）

```bash
x-publish.py quote 123456789 "我的评论"
```

### delete — 删除推文

```bash
x-publish.py delete 123456789
```

### followers — 获取粉丝数

```bash
x-publish.py followers "用户名"
```

### stats — 获取推文统计

```bash
x-publish.py stats 123456789
```

返回：观看数、点赞数、转发数

## 完整示例

```bash
# 发布推文
x-publish.py tweet "内容"

# 发布推文串
x-publish.py thread "第一篇|||第二篇|||第三篇"

# 互动操作
x-publish.py like 123456789
x-publish.py bookmark 123456789
```

## 技术实现

- 使用 `openclaw browser` 操控浏览器
- 自动重试机制（最多3次）
- 支持中英文界面
- Shell 命令注入防护
- 上下文管理器自动关闭资源

## 按钮文字参考

脚本使用 `_find_and_click()` 方法，通过按钮文字匹配元素 ref 后点击。支持多语言匹配：

| 功能 | 支持的文字 |
|------|-----------|
| 发布 | 发帖、Post、Send |
| 添加帖子 | 添加帖子、Add、添加推文 |
| 回复 | 回复、Reply |
| 发送 | 发送、Post |
| 点赞 | 喜欢、Like、like |
| 取消点赞 | 不喜欢、Unlike、unlike |
| 收藏 | 收藏、Bookmark |
| 已收藏 | 已收藏、Bookmarked、Unbookmark |
| 转发 | 转发、Repost、Reblog |
| 确认转发 | 确认、Confirm |
| 引用 | 引用、Quote、Add comment |
| 更多 | 更多、More |
| 删除 | 删除、Delete |
| 确认删除 | 确认、Confirm |

## 脚本位置

```
./scripts/x-publish.py
```
