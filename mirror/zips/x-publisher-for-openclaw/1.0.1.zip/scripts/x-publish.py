#!/usr/bin/env python3
"""x-publish v10.1 - X (Twitter) 发布工具（修复致命Bug+稳定版）"""
import sys
import re
import time
import subprocess
import argparse
from functools import wraps
from datetime import datetime

# ==================== 集中配置（唯一修改点，无硬编码）====================
DEFAULT_DELAY = 2
DEFAULT_TIMEOUT = 30
MAX_RETRIES = 3
RETRY_DELAY = 2

BASE_URL = "https://x.com"
COMPOSE_URL = f"{BASE_URL}/compose/post"
POST_URL_TEMPLATE = f"{BASE_URL}/i/status/{{post_id}}"

def post_id_to_url(post_id: str) -> str:
    """将帖子 ID 转换为完整 URL"""
    return POST_URL_TEMPLATE.format(post_id=post_id)

# ==================== 修复：通用重试装饰器（解决装饰器BUG）====================
def retry(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        last_err = None
        for _ in range(MAX_RETRIES):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                last_err = e
                time.sleep(RETRY_DELAY)
        raise last_err
    return wrapper

# ==================== 修复：浏览器类（安全、空校验、命令检查）====================
class Browser:
    def __init__(self, timeout=DEFAULT_TIMEOUT):
        self.timeout = timeout
        self.current_tab = None

    def run(self, cmd, timeout=None):
        """修复：检查命令返回码，杜绝静默失败"""
        t = timeout or self.timeout
        cmd_list = ["openclaw", "browser"] + cmd.split()
        result = subprocess.run(
            cmd_list, capture_output=True, text=True, timeout=t
        )
        if result.returncode != 0:
            raise RuntimeError(f"命令执行失败: {result.stderr[:200]}")
        return result.stdout

    def open_url(self, url):
        out = self.run(f"open {url}")
        m = re.search(r'id:\s*(\w+)', out)
        if m:
            self.current_tab = m.group(1)
            return self.current_tab
        raise RuntimeError(f"未获取tab: {out[:150]}")

    def click(self, ref):
        cmd = f"click {ref}"
        if self.current_tab:
            cmd += f" --target-id {self.current_tab}"
        return self.run(cmd)

    def type_text(self, ref, text):
        """修复：安全转义，杜绝Shell命令注入"""
        safe_text = text.replace("'", "'\\''")
        cmd = f"type {ref} '{safe_text}'"
        if self.current_tab:
            cmd += f" --target-id {self.current_tab}"
        return self.run(cmd)

    def snapshot(self):
        """修复：空指针校验，防止崩溃"""
        if not self.current_tab:
            raise RuntimeError("未打开任何标签页")
        return self.run(f"snapshot --target-id {self.current_tab} --format ai")

    def close(self):
        if self.current_tab:
            self.run(f"close --target-id {self.current_tab}")
            self.current_tab = None

    def find_ref(self, snap, *names):
        for line in snap.split('\n'):
            line_lower = line.lower()
            if any(name.lower() in line_lower for name in names):
                m = re.search(r'\[ref=(\w+)\]', line)
                if m:
                    return m.group(1)
        return None

    def find_ref_by_type(self, snap, element_type, index=0):
        count = 0
        for line in snap.split('\n'):
            if element_type.lower() in line.lower():
                if count == index:
                    m = re.search(r'\[ref=(\w+)\]', line)
                    if m:
                        return m.group(1)
                count += 1
        return None

    def find_textbox(self, snap):
        return self.find_ref_by_type(snap, 'textbox')

    def wait(self, seconds=DEFAULT_DELAY):
        time.sleep(seconds)

# ==================== 核心发布类（保留你的结构，修复bug）====================
class XPublisher:
    def __init__(self):
        self.browser = Browser()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def close(self):
        self.browser.close()

    def _find_and_click(self, *names, retry_count=2):
        for _ in range(retry_count):
            try:
                snap = self.browser.snapshot()
                ref = self.browser.find_ref(snap, *names)
                if ref:
                    self.browser.click(ref)
                    return ref
            except Exception:
                pass
            self.browser.wait(1)
        return None

    def _find_textbox_and_type(self, text):
        snap = self.browser.snapshot()
        ref = self.browser.find_textbox(snap)
        if not ref:
            raise RuntimeError("未找到文本框")
        self.browser.click(ref)
        self.browser.type_text(ref, text)
        return ref

    def _post(self):
        self._find_and_click('发帖', 'Post', 'Send')
        self.browser.wait(3)

    # 修复：使用通用重试装饰器
    @retry
    def publish_tweet(self, text):
        self.browser.open_url(COMPOSE_URL)
        self.browser.wait()
        self._find_textbox_and_type(text)
        self.browser.wait(0.8)
        self._post()

    @retry
    def publish_thread(self, texts):
        if len(texts) == 1:
            return self.publish_tweet(texts[0])
        self.browser.open_url(COMPOSE_URL)
        self.browser.wait()
        self._find_textbox_and_type(texts[0])
        self.browser.wait(0.8)
        for i in range(1, len(texts)):
            self._find_and_click('添加帖子', 'Add', '添加推文')
            self.browser.wait(1.2)
            self._find_textbox_and_type(texts[i])
            self.browser.wait(0.8)
        self._find_and_click('全部发帖', 'Post all')
        self.browser.wait(3)

    @retry
    def reply_to_post(self, post_id, text):
        self.browser.open_url(post_id_to_url(post_id))
        self.browser.wait()
        if not self._find_and_click('回复', 'Reply'):
            raise RuntimeError("未找到回复按钮")
        self.browser.wait(2)
        self._find_textbox_and_type(text)
        self.browser.wait(0.8)
        if not self._find_and_click('回复', 'Reply', '发送', 'Post'):
            raise RuntimeError("未找到发送按钮")
        self.browser.wait(3)

    @retry
    def like_post(self, post_id):
        self.browser.open_url(post_id_to_url(post_id))
        self.browser.wait()
        if not self._find_and_click('喜欢', 'Like', 'like'):
            raise RuntimeError("未找到点赞按钮")
        self.browser.wait(1)

    @retry
    def unlike_post(self, post_id):
        self.browser.open_url(post_id_to_url(post_id))
        self.browser.wait()
        if not self._find_and_click('不喜欢', 'Unlike', 'unlike'):
            raise RuntimeError("未找到取消点赞按钮")
        self.browser.wait(1)

    @retry
    def bookmark_post(self, post_id):
        self.browser.open_url(post_id_to_url(post_id))
        self.browser.wait()
        if not self._find_and_click('收藏', 'Bookmark'):
            raise RuntimeError("未找到收藏按钮")
        self.browser.wait(1)

    @retry
    def unbookmark_post(self, post_id):
        self.browser.open_url(post_id_to_url(post_id))
        self.browser.wait()
        if not self._find_and_click('已收藏', 'Bookmarked', 'Unbookmark'):
            raise RuntimeError("未找到已收藏按钮")
        self.browser.wait(1)

    @retry
    def repost_post(self, post_id):
        self.browser.open_url(post_id_to_url(post_id))
        self.browser.wait()
        if not self._find_and_click('转发', 'Repost', 'Reblog'):
            raise RuntimeError("未找到转发按钮")
        self.browser.wait(2)
        if not self._find_and_click('转发', 'Repost', 'Confirm'):
            raise RuntimeError("未找到确认转发按钮")
        self.browser.wait(2)

    @retry
    def quote_post(self, post_id, text):
        self.browser.open_url(post_id_to_url(post_id))
        self.browser.wait()
        if not self._find_and_click('转发', 'Repost'):
            raise RuntimeError("未找到转发按钮")
        self.browser.wait(2)
        if not self._find_and_click('引用', 'Quote', 'Add comment'):
            raise RuntimeError("未找到引用按钮")
        self.browser.wait(2)
        self._find_textbox_and_type(text)
        self.browser.wait(0.8)
        if not self._find_and_click('转发', 'Repost', 'Post', 'Quote'):
            raise RuntimeError("未找到发布按钮")
        self.browser.wait(3)

    @retry
    def delete_post(self, post_id):
        self.browser.open_url(post_id_to_url(post_id))
        self.browser.wait()
        if not self._find_and_click('更多', 'More'):
            raise RuntimeError("未找到更多按钮")
        self.browser.wait(1)
        if not self._find_and_click('删除', 'Delete'):
            raise RuntimeError("未找到删除按钮")
        self.browser.wait(1)
        if not self._find_and_click('删除', 'Delete', '确认', 'Confirm'):
            raise RuntimeError("未找到确认删除按钮")
        self.browser.wait(2)

    def get_followers(self, username):
        self.browser.open_url(f"{BASE_URL}/{username}")
        self.browser.wait(3)
        snap = self.browser.snapshot()
        return self._extract_followers(snap)

    def get_tweet_stats(self, post_id):
        self.browser.open_url(post_id_to_url(post_id))
        self.browser.wait(3)
        snap = self.browser.snapshot()
        return self._extract_tweet_stats(snap)

    @staticmethod
    def _extract_followers(snap):
        patterns = [
            r'([\d,.]+)\s*[Kk]?\s* fans?',
            r'([\d,.]+)\s*粉丝',
            r'粉丝\s*([\d,.]+)'
        ]
        for pattern in patterns:
            m = re.search(pattern, snap, re.I)
            if m:
                num_str = m.group(1).replace(',', '').replace('.', '')
                if 'k' in m.group(0).lower():
                    return int(float(num_str) * 1000)
                return int(num_str) if num_str.isdigit() else None
        return None

    @staticmethod
    def _extract_tweet_stats(snap):
        stats = {'views': None, 'likes': None, 'reposts': None}
        patterns = [
            (r'(\d+)\s*(观看|查看|Views)', 'views'),
            (r'(\d+)\s*(喜欢|点赞|Likes)', 'likes'),
            (r'(\d+)\s*(转帖|转发|Reposts)', 'reposts')
        ]
        for pattern, key in patterns:
            m = re.search(pattern, snap, re.I)
            if m:
                stats[key] = int(m.group(1))
        return stats

# ==================== 统一命令执行 ====================
def run_tweet(publisher, args):
    publisher.publish_tweet(args)
    return "✅ 推文发布成功"

def run_thread(publisher, args):
    texts = [t.strip() for t in args.split("|||") if t.strip()]
    if not texts:
        return "❌ 内容不能为空"
    publisher.publish_thread(texts)
    return f"✅ Thread发布成功: {len(texts)}篇"

def run_reply(publisher, args):
    publisher.reply_to_post(args[0], " ".join(args[1:]))
    return "✅ 回复成功"

def run_like(publisher, args):
    publisher.like_post(args[0])
    return "✅ 点赞成功"

def run_unlike(publisher, args):
    publisher.unlike_post(args[0])
    return "✅ 取消点赞成功"

def run_bookmark(publisher, args):
    publisher.bookmark_post(args[0])
    return "✅ 收藏成功"

def run_unbookmark(publisher, args):
    publisher.unbookmark_post(args[0])
    return "✅ 取消收藏成功"

def run_repost(publisher, args):
    publisher.repost_post(args[0])
    return "✅ 转发成功"

def run_quote(publisher, args):
    publisher.quote_post(args[0], " ".join(args[1:]))
    return "✅ 引用转发成功"

def run_delete(publisher, args):
    publisher.delete_post(args[0])
    return "✅ 删除成功"

def run_followers(publisher, args):
    data = publisher.get_followers(args[0])
    return f"✅ 粉丝数: {data or 'N/A'}"

def run_stats(publisher, args):
    stats = publisher.get_tweet_stats(args[0])
    return f"✅ 观看:{stats['views']}, 点赞:{stats['likes']}, 转发:{stats['reposts']}"

COMMANDS = {
    "tweet": run_tweet,
    "thread": run_thread,
    "reply": run_reply,
    "like": run_like,
    "unlike": run_unlike,
    "bookmark": run_bookmark,
    "unbookmark": run_unbookmark,
    "repost": run_repost,
    "quote": run_quote,
    "delete": run_delete,
    "followers": run_followers,
    "stats": run_stats,
}

def run_command(action, args):
    if action not in COMMANDS:
        return "❌ 未知命令"
    with XPublisher() as publisher:
        return COMMANDS[action](publisher, args)

# ==================== 环境检查 ====================
CHECK_TIMEOUT = 5

def run_cmd(cmd, timeout=CHECK_TIMEOUT):
    """运行命令并返回 (成功, 输出)"""
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return result.returncode == 0, result.stdout
    except subprocess.TimeoutExpired:
        return False, "命令超时"
    except FileNotFoundError:
        return False, "命令未找到"
    except Exception as e:
        return False, str(e)

def check_environment(include_login=False):
    """检查运行环境是否就绪"""
    checks = []

    ok, ver = run_cmd(["python3", "--version"])
    checks.append(("Python 版本", ok, ver.replace("Python ", "").strip() if ok else "未找到"))

    ok, ver = run_cmd(["openclaw", "--version"])
    checks.append(("openclaw CLI", ok, ver.strip() if ok else "未安装"))

    ok, out = run_cmd(["openclaw", "browser", "--help"])
    checks.append(("browser 子命令", ok and "browser" in out.lower(), "可用" if ok else "不可用"))

    if include_login:
        ok, out = run_cmd(["openclaw", "browser", "screenshot", "--url", "https://x.com"], timeout=10)
        if ok:
            logged_in = not any(k in out.lower() for k in ["login", "sign in", "登录", "登录 / 注册"])
            checks.append(("X 账号登录", logged_in, "已登录" if logged_in else "未登录"))
        else:
            checks.append(("X 账号登录", False, "检查失败"))

    return checks

def run_check():
    """执行环境检查"""
    print("🔍 检查 x-publisher 运行环境...\n")
    checks = check_environment(include_login=True)
    all_pass = True
    for name, passed, detail in checks:
        status = "✅" if passed else "❌"
        print(f"  {status} {name}: {detail}")
        if not passed:
            all_pass = False
    print()
    if all_pass:
        print("✅ 环境检查通过，可以正常使用！")
    else:
        print("❌ 环境检查未通过，请安装缺失的依赖。")
        print("\n安装 openclaw:")
        print("  brew install openclaw  # 或参考 openclaw 官方文档")
    return all_pass

# ==================== 简化命令行解析====================
def show_help():
    print("""
x-publish v10.2 - X (Twitter) 发布工具

用法:
  x-publish.py [选项] <命令> [参数]

选项:
  --pub-dir <路径>       发布目录
  --report-dir <路径>    报告目录
  --user <username>      默认用户名

命令:
  check                      检查运行环境
  tweet <内容>              发布推文
  thread <内容1>|||<内容2>|||...  发布推文串
  reply <帖子ID> <内容>      回复帖子
  like|unlike|bookmark|unbookmark <帖子ID>  互动
  repost <帖子ID>            转发
  quote <帖子ID> <评论>     引用转发
  delete <帖子ID>           删除
  followers <username>       粉丝数
  stats <帖子ID>            帖子统计

示例:
  x-publish.py check                        # 检查环境
  x-publish.py tweet "内容"                 # 发布推文
  x-publish.py reply 123456789 "回复内容"   # 回复帖子
  x-publish.py like 123456789               # 点赞帖子
""")

def create_parser():
    parser = argparse.ArgumentParser(
        prog='x-publish.py',
        description='x-publish v10.2 - X (Twitter) 发布工具',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  x-publish.py check
  x-publish.py tweet "内容"
  x-publish.py reply 123456789 "回复内容"
  x-publish.py like 123456789
        """
    )
    parser.add_argument('command', nargs='?', help='命令: check/tweet/thread/reply/like/unlike/bookmark/unbookmark/repost/quote/delete/followers/stats')
    parser.add_argument('args', nargs='*', help='命令参数')
    return parser

def main():
    parser = create_parser()
    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return

    action = args.command
    raw_args = args.args

    try:
        if action == "check":
            run_check()
        elif action in ["tweet", "thread"]:
            if not raw_args:
                print(f"❌ {action} 命令需要内容参数")
                return
            result = run_command(action, " ".join(raw_args))
            print(result)
        elif action in ["reply", "quote"]:
            if len(raw_args) < 2:
                print(f"❌ {action} 命令需要 帖子ID 和内容参数")
                return
            result = run_command(action, raw_args)
            print(result)
        elif action in ["like", "unlike", "bookmark", "unbookmark", "repost", "delete", "followers", "stats"]:
            if len(raw_args) < 1:
                print(f"❌ {action} 命令需要 帖子ID 或用户名参数")
                return
            result = run_command(action, raw_args)
            print(result)
        else:
            print(f"❌ 未知命令: {action}")
            parser.print_help()
    except Exception as e:
        print(f"❌ 执行失败: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()