"""
xlsx_extract.py — XLSX 参数提取脚本
用法：
  python xlsx_extract.py "文件路径"
  python xlsx_extract.py "文件路径" "SheetName"
"""
import sys, openpyxl

def extract(path, sheet_name=None):
    wb = openpyxl.load_workbook(path, data_only=True)
    sheets = [sheet_name] if sheet_name else wb.sheetnames
    for name in sheets:
        ws = wb[name]
        print(f"=== Sheet: {name} ===")
        for row in ws.iter_rows(values_only=True):
            if any(c is not None for c in row):
                print(list(row))
        print()

if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    extract(args[0], args[1] if len(args) > 1 else None)
