"""
docx_extract.py — DOCX 参数提取脚本
用法：
  python docx_extract.py "文件路径"
  python docx_extract.py "文件路径" --tables-only
"""
import sys
from docx import Document

def extract(path, tables_only=False):
    doc = Document(path)
    if not tables_only:
        # 提取所有段落文本
        for p in doc.paragraphs:
            if p.text.strip():
                print(p.text)
        print("\n--- TABLES ---\n")
    # 提取表格
    for i, t in enumerate(doc.tables):
        print(f"=== Table {i+1} ===")
        for row in t.rows:
            print([c.text.strip() for c in row.cells])
        print()

if __name__ == "__main__":
    tables_only = "--tables-only" in sys.argv
    path = [a for a in sys.argv[1:] if not a.startswith("--")][0]
    extract(path, tables_only)
