"""
pdf_extract.py — PDF 参数提取脚本
用法：
  python pdf_extract.py "文件路径" [start_page] [end_page]
  python pdf_extract.py "文件路径"              # 全量提取
  python pdf_extract.py "文件路径" -3           # 最后3页
"""
import sys, pypdf, argparse

sys.stdout.reconfigure(encoding='utf-8')

def extract_pages(path, start=None, end=None):
    r = pypdf.PdfReader(path)
    total = len(r.pages)
    start = max(0, start if start is not None else 0)
    end = min(total, end if end is not None else total)
    for i in range(start, end):
        t = r.pages[i].extract_text()
        if t and t.strip():
            print(f"=== Page {i+1}/{total} ===")
            print(t)
            print()

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("path")
    parser.add_argument("start", nargs="?", type=int, default=None)
    parser.add_argument("end", nargs="?", type=int, default=None)
    args = parser.parse_args()
    # 负数表示倒数第N页
    if args.start is not None and args.start < 0:
        r = pypdf.PdfReader(args.path)
        total = len(r.pages)
        args.start = max(0, total + args.start)
        args.end = total
    extract_pages(args.path, args.start, args.end)
