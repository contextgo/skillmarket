"""
WorkBuddy 每日礼包 —— 定时任务安装器 v2 (Skill 版)
运行此脚本一次即可完成安装，之后每天自动领取。

策略（v2）：
  - 每天零点后自动执行（00:05）
  - 电脑开机/登录时也执行一次（脚本内部判断是否需要补偿）
  - 失败后自动重试（脚本内部3分钟间隔，最多3次）

使用方法：
    python install_task.py           # 安装（默认每天 00:05 + 开机触发）
    python install_task.py --time 08:30   # 指定每日时间
    python install_task.py --remove  # 卸载任务
    python install_task.py --status  # 查看状态

作者：polaris  QQ: 1817694478
"""
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: workbuddy-gift-claimer | Version: 2.0.0
# Author: QQ 1817694478 | Q-Group: 972156177
# Unauthorized copying, modification, or distribution is prohibited.
# This software is provided "as is" without warranty of any kind.

import sys
import os
import argparse
import subprocess
from pathlib import Path

TASK_NAME  = "WorkBuddy每日礼包自动领取"
SCRIPT_DIR = Path(__file__).parent.resolve()
SCRIPT     = SCRIPT_DIR / "gift_claimer.py"


def run(cmd: str, check=True):
    result = subprocess.run(
        cmd, shell=True, capture_output=True, text=True, encoding="gbk", errors="replace"
    )
    if check and result.returncode != 0:
        print(f"[错误] {result.stderr.strip() or result.stdout.strip()}")
        sys.exit(1)
    return result


def python_exe() -> str:
    return sys.executable


def install(run_time: str):
    hour, minute = run_time.split(":")
    py = python_exe()

    # schtasks XML 方式，支持中文任务名
    # 包含两个触发器：每日定时 + 用户登录时
    xml = f"""<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo>
    <Description>每天自动领取 WorkBuddy 每日礼包（100 Credits）- 含开机补偿</Description>
  </RegistrationInfo>
  <Triggers>
    <CalendarTrigger>
      <StartBoundary>2026-01-01T{hour}:{minute}:00</StartBoundary>
      <ScheduleByDay>
        <DaysInterval>1</DaysInterval>
      </ScheduleByDay>
    </CalendarTrigger>
    <LogonTrigger>
      <Enabled>true</Enabled>
      <Delay>PT2M</Delay>
    </LogonTrigger>
  </Triggers>
  <Settings>
    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <ExecutionTimeLimit>PT30M</ExecutionTimeLimit>
    <Enabled>true</Enabled>
  </Settings>
  <Actions Context="Author">
    <Exec>
      <Command>{py}</Command>
      <Arguments>"{SCRIPT}"</Arguments>
      <WorkingDirectory>{SCRIPT_DIR}</WorkingDirectory>
    </Exec>
  </Actions>
</Task>"""

    xml_path = SCRIPT_DIR / "_wb_task.xml"
    xml_path.write_text(xml, encoding="utf-16")

    # 先删除旧任务（忽略错误）
    run(f'schtasks /delete /tn "{TASK_NAME}" /f', check=False)

    # 注册新任务
    r = run(f'schtasks /create /xml "{xml_path}" /tn "{TASK_NAME}"')

    xml_path.unlink(missing_ok=True)

    msg = f"""
+--------------------------------------------------+
|  [OK] WorkBuddy 每日礼包定时任务安装成功！        |
+--------------------------------------------------+
|  任务名称：{TASK_NAME}
|  每日执行：每天 {run_time}
|  开机补偿：用户登录后 2 分钟自动检测并执行
|  失败重试：3 分钟间隔，最多 3 次
|  脚本路径：{SCRIPT}
|  Python  ：{py}
+--------------------------------------------------+
|  查看任务：任务计划程序 -> 任务计划程序库          |
|  卸载任务：python install_task.py --remove  |
|  立即测试：python gift_claimer.py             |
+--------------------------------------------------+
"""
    sys.stdout.buffer.write(msg.encode("utf-8", errors="replace"))
    sys.stdout.buffer.write("\n🌹有问题、建议、需求可📧 联系作者QQ：1817694478🐧加Q群：972156177交流分享更多...\n".encode("utf-8", errors="replace"))


def remove():
    r = run(f'schtasks /delete /tn "{TASK_NAME}" /f', check=False)
    if r.returncode == 0:
        print(f"✅ 任务 [{TASK_NAME}] 已删除")
    else:
        print(f"⚠️  未找到任务（可能从未安装）：{r.stderr.strip()}")


def status():
    r = run(f'schtasks /query /tn "{TASK_NAME}" /fo LIST', check=False)
    if r.returncode == 0:
        sys.stdout.buffer.write(r.stdout.encode("utf-8", errors="replace"))
    else:
        print(f"⚠️  任务不存在")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="WorkBuddy 礼包定时任务管理 v2 (Skill)")
    parser.add_argument("--time",   default="00:05", help="每天执行时间，格式 HH:MM（默认 00:05）")
    parser.add_argument("--remove", action="store_true", help="卸载定时任务")
    parser.add_argument("--status", action="store_true", help="查看任务状态")
    args = parser.parse_args()

    if args.remove:
        remove()
    elif args.status:
        status()
    else:
        install(args.time)
