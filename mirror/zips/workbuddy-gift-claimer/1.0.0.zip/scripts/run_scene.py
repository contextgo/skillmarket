#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
通用场景执行器 - 执行任意 scenes/*.json 场景
用法: python run_scene.py <scene_name> [--force]
"""
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: workbuddy-gift-claimer | Version: 2.0.0
# Author: QQ 1817694478 | Q-Group: 972156177
# Unauthorized copying, modification, or distribution is prohibited.
# This software is provided "as is" without warranty of any kind.
import sys, os, time, logging, json, re
from pathlib import Path

# 设置
SKILL_DIR = Path(__file__).parent.resolve()
SCENES_DIR = SKILL_DIR / "scenes"
LOG_DIR    = SKILL_DIR / "logs"
LOG_DIR.mkdir(exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(str(LOG_DIR / "scene_runner.log"), encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ]
)
log = logging.getLogger("scene_runner")

# 依赖检测
try:
    import pyautogui as pag
    import pygetwindow as gw
    from PIL import Image
    import numpy as np
except ImportError as e:
    log.error("缺少依赖，请运行: pip install pyautogui pygetwindow pillow")
    sys.exit(1)

try:
    from rapidocr_onnxruntime import RapidOCR
    HAS_OCR = True
except ImportError:
    HAS_OCR = False
    log.warning("rapidocr-onnxruntime 未安装，OCR功能不可用")


def load_scene(name: str) -> dict:
    """加载场景配置"""
    path = SCENES_DIR / f"{name}.json"
    if not path.exists():
        # 尝试 scenes 子目录
        alt = SKILL_DIR / "scenes" / f"{name}.json"
        if alt.exists():
            path = alt
        else:
            raise FileNotFoundError(f"场景配置不存在: {path} 和 {alt}")
    with open(path, encoding="utf-8") as f:
        cfg = json.load(f)
    log.info(f"加载场景: {cfg.get('description', name)} ({name})")
    log.info(f"  类型: {cfg.get('type')} | 目标: {cfg.get('target', {})}")
    return cfg


def find_window(cfg: dict) -> object:
    """找到目标窗口并激活"""
    target = cfg.get("target", {})
    app_name = target.get("app_name", "")
    window_title = target.get("window_title", app_name)

    log.info(f"正在查找窗口: {window_title}")
    wins = gw.getWindowsWithTitle(window_title)
    if not wins:
        log.error(f"未找到窗口: {window_title}")
        # 尝试部分匹配
        all_wins = gw.getAllWindows()
        for w in all_wins:
            if app_name.lower() in w.title.lower() or window_title.lower() in w.title.lower():
                log.info(f"  找到候选窗口: {w.title}")
                wins = [w]
                break
    if not wins:
        raise RuntimeError(f"无法找到目标窗口: {window_title}")
    win = wins[0]
    log.info(f"  激活窗口: {win.title} ({win.left},{win.top}) {win.width}x{win.height}")
    try:
        win.activate()
    except Exception:
        try:
            win.minimize()
            time.sleep(0.5)
            win.restore()
        except Exception:
            pass
    time.sleep(1.0)
    return win


def ocr_window(win) -> list:
    """对窗口进行 OCR，返回 [box, text, conf] 列表"""
    if not HAS_OCR:
        return []
    try:
        ocr = RapidOCR()
        img = pag.screenshot(region=(win.left, win.top, win.width, win.height))
        img_np = np.array(img)
        result, _ = ocr(img_np)
        return result if result else []
    except Exception as e:
        log.warning(f"OCR失败: {e}")
        return []


def ocr_click_keyword(win, keywords: list, cx: float = None, cy: float = None, conf_threshold: float = 0.5) -> bool:
    """
    OCR扫描窗口，找到关键词后点击
    keywords: 关键词列表（任意包含即命中）
    cx, cy: 可选，指定点击位置（窗口比例坐标）
    """
    results = ocr_window(win)
    if not results:
        log.warning("OCR未识别到任何文字")
        return False

    texts_found = []
    hit = None
    for row in results:
        if len(row) < 3:
            continue
        box, text, conf = row[0], str(row[1]).strip(), float(row[2]) if row[2] is not None else 0.0
        if conf < conf_threshold:
            continue
        texts_found.append(f"{text}({conf:.2f})")
        if hit is None:
            for kw in keywords:
                if kw in text:
                    hit = (box, text, conf)
                    log.info(f"  命中关键词: '{text}' conf={conf:.2f}")
                    break

    if not hit:
        log.warning(f"  未找到关键词 {keywords}，识别到: {texts_found[:10]}")
        return False

    box, text, conf = hit
    # 计算点击坐标
    if cx is not None and cy is not None:
        # 使用预知的坐标（来自视频分析）
        click_x = win.left + int(win.width * cx)
        click_y = win.top + int(win.height * cy)
    else:
        # 从OCR结果计算中心
        xs = [pt[0] for pt in box]
        ys = [pt[1] for pt in box]
        click_x = win.left + int((min(xs) + max(xs)) / 2)
        click_y = win.top + int((min(ys) + max(ys)) / 2)

    log.info(f"  点击屏幕坐标: ({click_x}, {click_y})")
    pag.click(click_x, click_y)
    return True


def execute_actions(win, actions: list) -> tuple:
    """
    执行动作序列
    返回: (success, claimed)
    """
    success = False
    claimed = False

    for i, action in enumerate(actions):
        atype = action.get("type", "")
        desc  = action.get("desc", atype)

        if atype == "wait":
            sec = action.get("seconds", 1)
            log.info(f"[{i+1}/{len(actions)}] 等待 {sec}s: {desc}")
            time.sleep(sec)

        elif atype == "click_abs":
            x, y = action.get("x"), action.get("y")
            log.info(f"[{i+1}/{len(actions)}] 绝对点击 ({x},{y}): {desc}")
            pag.click(x, y)

        elif atype == "click_ratio":
            rx, ry = action.get("x", 0.5), action.get("y", 0.5)
            x = win.left + int(win.width * rx)
            y = win.top + int(win.height * ry)
            log.info(f"[{i+1}/{len(actions)}] 比例点击 ({rx:.1%},{ry:.1%}): {desc}")
            pag.click(x, y)

        elif atype == "ocr_click":
            keywords = action.get("keywords", [])
            cx = action.get("cx")
            cy = action.get("cy")
            log.info(f"[{i+1}/{len(actions)}] OCR点击 {keywords}: {desc}")
            ocr_click_keyword(win, keywords, cx, cy)

        elif atype == "ocr_check":
            keywords = action.get("keywords", [])
            log.info(f"[{i+1}/{len(actions)}] OCR检查 {keywords}: {desc}")
            results = ocr_window(win)
            for row in results:
                if len(row) < 2:
                    continue
                text = str(row[1]).strip()
                conf = float(row[2]) if row[2] is not None else 0.0
                for kw in keywords:
                    if kw in text and conf >= 0.5:
                        log.info(f"  确认成功! 命中 '{text}' conf={conf:.2f}")
                        success = True
                        break
            if not success:
                log.warning("  未检测到成功关键词")

        elif atype == "screenshot":
            path = action.get("path", "result.png")
            log.info(f"[{i+1}/{len(actions)}] 截图: {path}")
            img = pag.screenshot(region=(win.left, win.top, win.width, win.height))
            img.save(path)
            log.info(f"  截图已保存: {path}")

        elif atype == "key":
            key = action.get("key", "escape")
            log.info(f"[{i+1}/{len(actions)}] 按键 {key}")
            pag.press(key)

        else:
            log.warning(f"[{i+1}/{len(actions)}] 未知动作类型: {atype} ({desc})")

    return success, claimed


def print_operation_warning(scene_name: str):
    """打印醒目操作警告横幅"""
    banner = f"""
{'='*60}
  ⚠️  自动化执行进行中，请勿操作鼠标键盘！
{'='*60}
  场景: {scene_name}
  原因: 技能正在模拟用户操作，任何鼠标移动或
        键盘输入都会干扰点击位置，导致失败。

  如需中止，请立即关闭窗口或按 Ctrl+C
{'='*60}
"""
    # 同时打印到控制台和日志
    print(banner)
    log.warning(f"自动化执行开始，场景: {scene_name}，请勿操作鼠标键盘！")


def run_scene(name: str, force: bool = False):
    """运行指定场景"""
    cfg = load_scene(name)

    # 打印操作警告
    print_operation_warning(name)

    # 查找窗口
    win = find_window(cfg)

    # 执行动作
    actions = cfg.get("actions", [])
    if not actions:
        log.error("场景没有配置动作")
        return False

    success, claimed = execute_actions(win, actions)
    return success


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python run_scene.py <scene_name> [--force]")
        print("示例: python run_scene.py wechat_mini_signin")
        sys.exit(1)

    scene_name = sys.argv[1]
    force = "--force" in sys.argv

    try:
        ok = run_scene(scene_name, force)
        if ok:
            print("\n场景执行成功!")
        else:
            print("\n场景执行完成（状态未知，请检查截图）")
    except Exception as e:
        print(f"\n场景执行出错: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
