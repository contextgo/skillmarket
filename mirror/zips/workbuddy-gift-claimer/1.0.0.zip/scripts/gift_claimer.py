"""
WorkBuddy 每日礼包自动领取脚本 v5 (Skill 版)
核心逻辑：OCR 定位礼包领取按钮文字 -> 点击

运行策略（v5 优化）：
  - 每天零点后首次检测未领取则执行
  - 失败后 3 分钟重试，最多重试 3 次
  - 开机补偿：检测日志昨天未成功领取则启动后立即执行

自学习机制（v4 新增）：
  - 每次执行自动记录 OCR 全量识别结果到经验文件
  - 失败时自动分析经验文件，发现新关键词自动追加到配置
  - 头像坐标自适应：记录成功的坐标比例，优先使用历史成功值
  - 版本检测：自动记录 WorkBuddy 版本号，版本变化时触发重新学习

作者：polaris  QQ: 1817694478
依赖：pyautogui, pygetwindow, pillow, rapidocr-onnxruntime
安装：python -m pip install pyautogui pygetwindow pillow rapidocr-onnxruntime
"""
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: workbuddy-gift-claimer | Version: 2.0.0
# Author: QQ 1817694478 | Q-Group: 972156177
# Unauthorized copying, modification, or distribution is prohibited.
# This software is provided "as is" without warranty of any kind.

import sys
import time
import json
import logging
import subprocess
import base64
from datetime import datetime, timedelta
from pathlib import Path

# Integrity check on startup
_SKILL_DIR = Path(__file__).parent.parent
try:
    sys.path.insert(0, str(_SKILL_DIR.parent))
    from integrity_guard import IntegrityGuard
    _guard = IntegrityGuard(str(_SKILL_DIR))
    _ok, _msg = _guard.startup_check_with_message()
    if not _ok:
        print(f'[ERROR] {_msg}', flush=True)
        sys.exit(1)
except ImportError:
    pass

try:
    import pyautogui
    import pygetwindow as gw
    from PIL import ImageGrab
    import numpy as np
    from rapidocr_onnxruntime import RapidOCR
except ImportError as e:
    print(f"缺少依赖: {e}")
    print("请运行: python -m pip install pyautogui pygetwindow pillow rapidocr-onnxruntime")
    sys.exit(1)

# -- 配置（Skill 路径适配） --
SCRIPT_DIR = Path(__file__).parent.resolve()
LOG_FILE = SCRIPT_DIR / "wb_gift.log"
LEARN_FILE = SCRIPT_DIR / "wb_gift_learn.json"
# 配置参数（编码存储，运行时解码）
WB_EXE = base64.b64decode(b'RDpcUHJvZ3JhbSBGaWxlcyAoeDg2KVxXb3JrQnVkZHlcV29ya0J1ZGR5LmV4ZQ==').decode()

WAIT_WINDOW = 60   # 冷启动等待上限（秒）
WAIT_PANEL  = 4.0
WAIT_CLICK  = 1
RETRY_INTERVAL = 180  # 失败重试间隔（秒）= 3分钟
MAX_RETRIES = 3       # 最大重试次数

# -- 默认配置（可被经验文件覆盖） --
DEFAULT_GIFT_BTN_KEYWORDS = ["领取100积分", "领取积分", "立即领取"]
DEFAULT_CLAIMED_KEYWORDS  = ["今日礼包已到账", "已领取", "已签到"]
DEFAULT_AVATAR_CANDIDATES = [
    (0.11, 0.95),   # v4.9.x 默认
    (0.05, 0.97),   # 左下角更靠边
    (0.08, 0.96),   # 中间值
    (0.11, 0.97),   # 稍微靠下
]

# -- 日志 --
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)s  %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE, encoding="utf-8"),
        logging.StreamHandler(
            open(sys.stdout.fileno(), mode="w", encoding="utf-8", errors="replace", closefd=False)
        ),
    ],
)
log = logging.getLogger(__name__)

pyautogui.FAILSAFE = True
pyautogui.PAUSE    = 0.3

# OCR 引擎（只初始化一次）
_ocr = None

def get_ocr():
    global _ocr
    if _ocr is None:
        _ocr = RapidOCR()
    return _ocr


# ========== 日志分析模块 ==========

def check_yesterday_unclaimed() -> bool:
    """检查昨天是否未成功领取（开机补偿判断）。"""
    if not LOG_FILE.exists():
        return True  # 从未运行过，需要领取

    yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
    today = datetime.now().strftime("%Y-%m-%d")
    content = LOG_FILE.read_text(encoding="utf-8")

    # 检查昨天是否有成功记录
    yesterday_success = False
    for line in content.split("\n"):
        if line.startswith(yesterday) and ("[OK]" in line or "✅" in line):
            yesterday_success = True
            break

    # 检查今天是否已有成功记录
    today_success = False
    for line in content.split("\n"):
        if line.startswith(today) and ("[OK]" in line or "✅" in line):
            today_success = True
            break

    # 昨天没成功且今天还没领 => 需要开机补偿
    if not yesterday_success and not today_success:
        log.info(f"[开机补偿] 检测到昨天({yesterday})未成功领取，立即执行")
        return True

    return False


def already_claimed_today() -> bool:
    """检查今天是否已成功领取。"""
    today = datetime.now().strftime("%Y-%m-%d")
    if not LOG_FILE.exists():
        return False
    content = LOG_FILE.read_text(encoding="utf-8")
    return (f"{today}  INFO  [OK]" in content or 
            f"{today}  INFO  \u2705" in content)


def get_last_log_date() -> str | None:
    """获取日志中最后一条记录的日期（判断关机前状态）。"""
    if not LOG_FILE.exists():
        return None
    try:
        lines = LOG_FILE.read_text(encoding="utf-8").strip().split("\n")
        for line in reversed(lines):
            if line.strip() and len(line) >= 10:
                return line[:10]  # "YYYY-MM-DD"
    except Exception:
        pass
    return None


def should_run_on_boot() -> bool:
    """判断是否需要开机补偿执行。

    条件：
    1. 日志最后记录日期 < 今天 => 电脑关机期间未执行
    2. 且今天尚未成功领取
    """
    last_date = get_last_log_date()
    today = datetime.now().strftime("%Y-%m-%d")

    if last_date and last_date < today and not already_claimed_today():
        log.info(f"[开机补偿] 上次日志日期={last_date}，今天={today}，尚未领取，触发补偿执行")
        return True

    # 也检查昨天是否未领取
    if check_yesterday_unclaimed():
        return True

    return False


# ========== 自学习模块 ==========

def load_learn_data() -> dict:
    """加载经验文件，不存在则返回默认值。"""
    if LEARN_FILE.exists():
        try:
            return json.loads(LEARN_FILE.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, Exception):
            log.warning("经验文件损坏，使用默认配置")
    return {
        "gift_btn_keywords": list(DEFAULT_GIFT_BTN_KEYWORDS),
        "claimed_keywords": list(DEFAULT_CLAIMED_KEYWORDS),
        "avatar_candidates": [list(c) for c in DEFAULT_AVATAR_CANDIDATES],
        "success_avatar_ratio": None,       # 上次成功的头像坐标比例
        "last_wb_version": None,            # 上次记录的 WorkBuddy 版本
        "last_success_date": None,           # 上次成功日期
        "ocr_discoveries": [],               # OCR 发现的新关键词（自动学习用）
        "fail_streak": 0,                    # 连续失败次数
        "history": [],                       # 最近执行历史（保留最近30条）
    }


def save_learn_data(data: dict):
    """保存经验文件。"""
    # 历史记录只保留最近30条
    if "history" in data and len(data["history"]) > 30:
        data["history"] = data["history"][-30:]
    LEARN_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def record_ocr_result(data: dict, ocr_results: list, context: str):
    """记录一次 OCR 识别结果到经验历史。"""
    entry = {
        "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "context": context,  # "avatar_click" / "gift_search" / "claimed_search"
        "texts": [item[1] for item in (ocr_results or [])],
    }
    data.setdefault("history", []).append(entry)

    # 自动发现：如果 OCR 结果中出现"领取"+"积分"/"签到"/"礼包"等组合词，可能是新按钮文字
    for item in (ocr_results or []):
        text = item[1].replace(" ", "").strip()
        # 检测可能的领取按钮新文字（包含"领取"且不是已有的关键词）
        if "领取" in text and text not in data.get("gift_btn_keywords", []):
            # 排除明显的非按钮文字（太长或包含其他关键词）
            if len(text) <= 12 and "已" not in text and "到账" not in text:
                log.info(f"[自学习] 发现可能的领取按钮新文字: [{text}]")
                if text not in data.get("ocr_discoveries", []):
                    data.setdefault("ocr_discoveries", []).append(text)
                    log.info(f"[自学习] 已记录到发现列表: {data['ocr_discoveries']}")

        # 检测可能的已领取新文字
        claimed_markers = ["已到账", "已领取", "已签到", "已到帐"]
        for marker in claimed_markers:
            if marker in text and text not in data.get("claimed_keywords", []):
                if len(text) <= 15:
                    log.info(f"[自学习] 发现可能的已领取状态新文字: [{text}]")
                    if text not in data.get("claimed_keywords", []):
                        data["claimed_keywords"].append(text)


def record_success(data: dict, avatar_ratio: tuple, wb_version: str = None):
    """记录成功执行，更新经验。"""
    data["success_avatar_ratio"] = list(avatar_ratio)
    data["last_success_date"] = datetime.now().strftime("%Y-%m-%d")
    data["fail_streak"] = 0
    if wb_version:
        data["last_wb_version"] = wb_version
    # 成功后将发现的候选关键词提升为正式关键词
    for kw in data.get("ocr_discoveries", []):
        if kw not in data.get("gift_btn_keywords", []):
            data["gift_btn_keywords"].insert(0, kw)  # 新发现的关键词优先
            log.info(f"[自学习] 将发现关键词 [{kw}] 提升为正式关键词")
    data["ocr_discoveries"] = []  # 清空发现列表
    save_learn_data(data)


def record_failure(data: dict, wb_version: str = None):
    """记录失败，触发自适应调整。"""
    data["fail_streak"] = data.get("fail_streak", 0) + 1
    if wb_version and wb_version != data.get("last_wb_version"):
        log.warning(f"[自学习] 检测到版本变化: {data.get('last_wb_version')} -> {wb_version}，可能需要重新学习")
        data["last_wb_version"] = wb_version
    # 连续失败3次以上，将 ocr_discoveries 中的关键词临时加入搜索列表
    if data["fail_streak"] >= 3 and data.get("ocr_discoveries"):
        for kw in data["ocr_discoveries"]:
            if kw not in data["gift_btn_keywords"]:
                data["gift_btn_keywords"].append(kw)
                log.info(f"[自学习] 连续失败{data['fail_streak']}次，临时加入发现关键词: [{kw}]")
    save_learn_data(data)


def detect_wb_version(win) -> str | None:
    """通过 OCR 检测 WorkBuddy 版本号。"""
    try:
        img = ImageGrab.grab(bbox=(win.left, win.top, win.left + win.width, win.top + win.height))
        img_np = np.array(img)
        ocr = get_ocr()
        result, _ = ocr(img_np)
        if result:
            for item in result:
                text = item[1].strip()
                # 匹配 v4.x.x 格式
                if text.startswith("v") and "." in text and len(text) <= 12:
                    import re
                    if re.match(r'v\d+\.\d+', text):
                        return text
    except Exception:
        pass
    return None


def get_effective_keywords(data: dict, keyword_type: str) -> list:
    """获取生效的关键词列表（合并默认值和自学习值）。"""
    if keyword_type == "gift":
        base = data.get("gift_btn_keywords", DEFAULT_GIFT_BTN_KEYWORDS)
        # 确保默认关键词都在列表中（兜底）
        for kw in DEFAULT_GIFT_BTN_KEYWORDS:
            if kw not in base:
                base.append(kw)
        return base
    elif keyword_type == "claimed":
        base = data.get("claimed_keywords", DEFAULT_CLAIMED_KEYWORDS)
        for kw in DEFAULT_CLAIMED_KEYWORDS:
            if kw not in base:
                base.append(kw)
        return base
    return []


def get_effective_avatar_candidates(data: dict) -> list:
    """获取生效的头像坐标候选列表（优先使用历史成功的坐标）。"""
    candidates = [tuple(c) for c in data.get("avatar_candidates", DEFAULT_AVATAR_CANDIDATES)]
    success_ratio = data.get("success_avatar_ratio")
    if success_ratio:
        sr = tuple(success_ratio)
        # 将历史成功的坐标放在第一位
        if sr in candidates:
            candidates.remove(sr)
        candidates.insert(0, sr)
    return candidates if candidates else list(DEFAULT_AVATAR_CANDIDATES)


# ========== 核心函数 ==========
def get_workbuddy_window():
    """查找 WorkBuddy 主窗口，支持模糊标题匹配。"""
    # 精确匹配
    wins = gw.getWindowsWithTitle("WorkBuddy")
    if wins:
        # 过滤掉空标题或最小化的，优先返回有内容的
        visible = [w for w in wins if w.width > 100]
        return visible[0] if visible else wins[0]
    # 模糊匹配（启动过渡期标题可能不同）
    all_wins = gw.getAllWindows()
    for w in all_wins:
        if "workbuddy" in w.title.lower() and w.width > 100:
            return w
    return None


def wb_process_running() -> bool:
    """检查 WorkBuddy 进程是否存在（不依赖窗口标题）。"""
    try:
        result = subprocess.run(
            ["tasklist", "/FI", "IMAGENAME eq WorkBuddy.exe", "/NH"],
            capture_output=True, text=True, encoding="gbk", errors="replace"
        )
        return "WorkBuddy.exe" in result.stdout
    except Exception:
        return False


def activate_workbuddy() -> bool:
    win = get_workbuddy_window()
    if win:
        try:
            if win.isMinimized:
                win.restore()
            win.activate()
            time.sleep(1)
            log.info("WorkBuddy 窗口已激活")
            return True
        except Exception as e:
            log.warning(f"激活窗口失败: {e}")

    # 尝试启动（包含多个常见安装位置）
    exe_candidates = [
        WB_EXE,
        r"D:\Program Files (x86)\WorkBuddy\WorkBuddy.exe",
        r"C:\Program Files (x86)\WorkBuddy\WorkBuddy.exe",
        r"C:\Program Files\WorkBuddy\WorkBuddy.exe",
        Path.home() / "AppData/Local/Programs/WorkBuddy/WorkBuddy.exe",
        Path.home() / "AppData/Local/WorkBuddy/WorkBuddy.exe",
    ]
    for exe in exe_candidates:
        if Path(exe).exists():
            log.info(f"启动 WorkBuddy: {exe}")
            subprocess.Popen(str(exe))

            # 等待进程出现
            log.info("等待 WorkBuddy 进程启动...")
            deadline = time.time() + 15
            while time.time() < deadline:
                time.sleep(1)
                if wb_process_running():
                    log.info("WorkBuddy 进程已启动，等待界面加载...")
                    break
            else:
                log.error("WorkBuddy 进程启动超时")
                return False

            # 等待窗口出现（最多 WAIT_WINDOW 秒）
            deadline = time.time() + WAIT_WINDOW
            while time.time() < deadline:
                time.sleep(2)
                win = get_workbuddy_window()
                if win:
                    log.info(f"WorkBuddy 窗口已出现: [{win.title}]，再等 5 秒让界面加载完成")
                    time.sleep(5)
                    try:
                        win.activate()
                    except Exception:
                        pass
                    log.info("WorkBuddy 已就绪")
                    return True

            log.error(f"等待 WorkBuddy 窗口超时（{WAIT_WINDOW}s）")
            return False

    log.error("找不到 WorkBuddy 可执行文件")
    return False




def ocr_find_text(win, target_text: str) -> tuple | None:
    """
    OCR 扫描窗口，查找目标文字，返回屏幕坐标 (center_x, center_y)。
    优先匹配短文本（精确匹配），避免匹配到包含目标文字的长句子。
    """
    log.info(f"OCR 扫描窗口查找: [{target_text}]")
    img = ImageGrab.grab(bbox=(win.left, win.top, win.left + win.width, win.top + win.height))
    img_np = np.array(img)

    ocr = get_ocr()
    result, _ = ocr(img_np)

    if not result:
        log.warning("OCR 未识别到任何文字")
        return None

    # 收集所有包含目标文字的匹配项
    matches = []
    for item in result:
        bbox, text = item[0], item[1]
        conf = float(item[2])
        clean_text = text.replace(" ", "").strip()
        if target_text in clean_text:
            x1 = bbox[0][0]
            y1 = bbox[0][1]
            x2 = bbox[2][0]
            y2 = bbox[2][1]
            cx = int((x1 + x2) / 2) + win.left
            cy = int((y1 + y2) / 2) + win.top
            matches.append({
                "text": text, "conf": conf, "cx": cx, "cy": cy,
                "length": len(clean_text),
                "window": (int(x1), int(y1), int(x2), int(y2)),
            })

    if matches:
        # 按文本长度升序排列，优先选最短的（精确匹配）
        matches.sort(key=lambda m: m["length"])
        best = matches[0]
        log.info(f"OCR 找到 [{best['text']}] conf={best['conf']:.2f} "
                 f"@ 窗口{best['window']} 屏幕({best['cx']},{best['cy']})")
        if len(matches) > 1:
            log.info(f"  (跳过其他 {len(matches)-1} 个匹配)")
        return (best["cx"], best["cy"])

    # 未找到目标文字时，仅打印前30条（避免日志过长）
    log.info(f"未找到[{target_text}]，当前识别到的文字（前30条）:")
    for item in result[:30]:
        text = item[1]
        conf = float(item[2])
        log.info(f"  {text} (conf={conf:.2f})")
    if len(result) > 30:
        log.info(f"  ...（共 {len(result)} 条，省略后续）")

    return None


def ocr_find_any(win, keywords: list, learn_data: dict = None, context: str = "search") -> tuple | None:
    """
    依次尝试多个关键词，返回第一个找到的坐标。
    同时在一次 OCR 结果中搜索所有关键词，避免重复截图。
    同时记录 OCR 结果到自学习模块。
    """
    log.info(f"OCR 扫描窗口，依次查找关键词: {keywords}")
    img = ImageGrab.grab(bbox=(win.left, win.top, win.left + win.width, win.top + win.height))
    img_np = np.array(img)

    ocr = get_ocr()
    result, _ = ocr(img_np)

    # 记录 OCR 结果到经验
    if learn_data is not None:
        record_ocr_result(learn_data, result, context)

    if not result:
        log.warning("OCR 未识别到任何文字")
        return None

    # 为每个关键词收集匹配项
    found = {}  # keyword -> [match, ...]
    for item in result:
        bbox, text = item[0], item[1]
        conf = float(item[2])
        clean_text = text.replace(" ", "").strip()
        for kw in keywords:
            if kw in clean_text:
                x1 = bbox[0][0]; y1 = bbox[0][1]
                x2 = bbox[2][0]; y2 = bbox[2][1]
                cx = int((x1 + x2) / 2) + win.left
                cy = int((y1 + y2) / 2) + win.top
                entry = {
                    "text": text, "conf": conf, "cx": cx, "cy": cy,
                    "length": len(clean_text),
                    "window": (int(x1), int(y1), int(x2), int(y2)),
                }
                found.setdefault(kw, []).append(entry)

    # 按关键词优先级返回
    for kw in keywords:
        if kw in found:
            matches = sorted(found[kw], key=lambda m: m["length"])
            best = matches[0]
            log.info(f"OCR 命中关键词[{kw}]: [{best['text']}] conf={best['conf']:.2f} "
                     f"@ 窗口{best['window']} 屏幕({best['cx']},{best['cy']})")
            return (best["cx"], best["cy"])

    # 全部未找到时打印前30条日志
    log.info(f"所有关键词均未找到，识别文字（前30条）:")
    for item in result[:30]:
        log.info(f"  {item[1]} (conf={float(item[2]):.2f})")
    if len(result) > 30:
        log.info(f"  ...（共 {len(result)} 条，省略后续）")
    return None


# -- 单次领取尝试 --
def try_claim_once(learn: dict, force=False) -> bool:
    """执行一次领取尝试，返回 True=成功 False=失败。"""
    gift_keywords = get_effective_keywords(learn, "gift")
    claimed_keywords = get_effective_keywords(learn, "claimed")
    avatar_candidates = get_effective_avatar_candidates(learn)

    # 1. 激活窗口
    if not activate_workbuddy():
        log.error("无法启动/激活 WorkBuddy")
        return False

    time.sleep(1.5)
    win = get_workbuddy_window()
    if not win:
        log.error("找不到 WorkBuddy 窗口")
        return False

    # 检测版本号
    wb_version = detect_wb_version(win)
    if wb_version:
        log.info(f"检测到 WorkBuddy 版本: {wb_version}")
        if learn.get("last_wb_version") and wb_version != learn["last_wb_version"]:
            log.warning(f"[自学习] 版本变化! {learn['last_wb_version']} -> {wb_version}，可能需要重新适应")

    # 2. 点击头像打开用户面板，支持多组坐标候选
    found_target = None
    used_avatar_ratio = None
    for cand_idx, (xr, yr) in enumerate(avatar_candidates):
        ax = win.left + int(win.width * xr)
        ay = win.top + int(win.height * yr)
        log.info(f"点击头像 @ ({ax}, {ay})  [候选{cand_idx+1}: x={xr:.0%} y={yr:.0%}]")
        pyautogui.click(ax, ay)
        time.sleep(WAIT_PANEL)

        # 3. 一次 OCR 同时搜索所有礼包按钮关键词
        target = ocr_find_any(win, gift_keywords, learn_data=learn, context="gift_search")
        if target:
            found_target = target
            used_avatar_ratio = (xr, yr)
            break

        # 检查是否已经领取了（说明面板弹出了但今天已领）
        already = ocr_find_any(win, claimed_keywords, learn_data=learn, context="claimed_search")
        if already:
            log.info("今日礼包已领取过（检测到已签到标识）")
            log.info("[OK] 今日礼包领取成功")
            record_success(learn, (xr, yr), wb_version)
            pyautogui.press("escape")
            return True

        log.warning(f"候选坐标{cand_idx+1}未找到礼包面板，关闭后尝试下一个...")
        pyautogui.press("escape")
        time.sleep(1.0)

    if not found_target:
        log.error("所有头像坐标候选均未能找到礼包领取按钮")
        record_failure(learn, wb_version)
        return False

    # 4. 点击领取按钮
    log.info(f"点击礼包领取按钮 @ {found_target}")
    pyautogui.click(found_target)
    time.sleep(WAIT_CLICK)

    # 关闭面板
    time.sleep(1)
    pyautogui.press("escape")
    time.sleep(0.5)

    log.info("[OK] 今日礼包领取成功")
    sys.stdout.buffer.write("\n[OK] 今日 100 Credits 礼包已领取!\n".encode("utf-8", errors="replace"))
    sys.stdout.buffer.flush()

    # 5. 记录成功经验
    record_success(learn, used_avatar_ratio, wb_version)
    return True


# -- 主流程（带重试机制） --
def main(force=False):
    log.info("=" * 50)
    log.info("WorkBuddy 每日礼包自动领取 开始 (v5 智能重试版)")

    # 0. 开机补偿检测
    if not force and should_run_on_boot():
        log.info("[开机补偿] 触发补偿执行")
        force = True

    # 1. 检查今天是否已领取
    if not force and already_claimed_today():
        log.info("今日已领取，跳过")
        return

    # 2. 加载自学习经验
    learn = load_learn_data()
    log.info(f"[自学习] 礼包关键词: {get_effective_keywords(learn, 'gift')}")
    log.info(f"[自学习] 已领取关键词: {get_effective_keywords(learn, 'claimed')}")
    log.info(f"[自学习] 头像坐标候选: {[(f'{x:.0%}', f'{y:.0%}') for x, y in get_effective_avatar_candidates(learn)]}")
    log.info(f"[自学习] 历史成功坐标: {learn.get('success_avatar_ratio')}")
    log.info(f"[自学习] 连续失败次数: {learn.get('fail_streak', 0)}")
    if learn.get("ocr_discoveries"):
        log.info(f"[自学习] 待确认发现: {learn['ocr_discoveries']}")

    # 3. 执行领取（带重试机制）
    for attempt in range(1, MAX_RETRIES + 1):
        log.info(f"--- 第 {attempt}/{MAX_RETRIES} 次尝试 ---")

        success = try_claim_once(learn, force=force)

        if success:
            log.info(f"领取成功（第 {attempt} 次尝试）")
            sys.stdout.buffer.write("\n🌹有问题、建议、需求可📧 联系作者QQ：1817694478🐧加Q群：972156177交流分享更多...\n".encode("utf-8", errors="replace"))
            sys.stdout.buffer.flush()
            return

        if attempt < MAX_RETRIES:
            log.warning(f"第 {attempt} 次尝试失败，{RETRY_INTERVAL//60} 分钟后重试...")
            sys.stdout.buffer.write(f"\n第 {attempt} 次尝试失败，{RETRY_INTERVAL//60} 分钟后自动重试...\n".encode("utf-8", errors="replace"))
            sys.stdout.buffer.flush()
            time.sleep(RETRY_INTERVAL)

    log.error(f"连续 {MAX_RETRIES} 次尝试均失败，今日领取失败")
    sys.stdout.buffer.write(f"\n❌ 连续 {MAX_RETRIES} 次尝试均失败，请手动领取\n".encode("utf-8", errors="replace"))
    sys.stdout.buffer.write("\n🌹有问题、建议、需求可📧 联系作者QQ：1817694478🐧加Q群：972156177交流分享更多...\n".encode("utf-8", errors="replace"))
    sys.stdout.buffer.flush()


def _handle_video_learn(argv):
    """
    --learn-from-video 子命令处理
    用法: gift_claimer.py --learn-from-video <video_path>
                          [--name scene_name]
                          [--desc "描述"]
                          [--type desktop|web|hybrid]
                          [--app 应用名]
                          [--url https://...]
                          [--schedule HH:MM]
                          [--install-task]
    """
    try:
        from video_learner import VideoLearner, print_result
    except ImportError:
        sys.stdout.buffer.write(
            b"[error] video_learner.py not found in scripts directory\n"
        )
        sys.exit(1)

    import argparse
    parser = argparse.ArgumentParser(prog="gift_claimer.py --learn-from-video")
    parser.add_argument("video",           help="视频路径")
    parser.add_argument("--name",  "-n",   required=True, help="场景名称")
    parser.add_argument("--desc",  "-d",   default="",    help="场景描述")
    parser.add_argument("--type",  "-t",   default="desktop",
                        choices=["desktop", "web", "hybrid"])
    parser.add_argument("--app",           default="",    help="桌面应用名")
    parser.add_argument("--url",           default="",    help="目标 URL")
    parser.add_argument("--schedule",      default="00:05", help="每日时间 HH:MM")
    parser.add_argument("--install-task",  action="store_true", help="注册定时任务")
    parser.add_argument("--keep-frames",   action="store_true", help="保留帧文件")

    # 去掉 --learn-from-video 本身，把剩余参数传入
    sub_argv = [a for a in argv if a != "--learn-from-video"]
    args = parser.parse_args(sub_argv)

    learner = VideoLearner(args.video)
    res = learner.run(
        scene_name  = args.name,
        description = args.desc,
        scene_type  = args.type,
        target_app  = args.app,
        target_url  = args.url,
        schedule    = args.schedule,
        keep_frames = args.keep_frames,
    )
    print_result(res)

    if args.install_task:
        import subprocess as sp
        log.info("正在注册 Windows 定时任务...")
        r = sp.run(res["schtask_cmd"], shell=True, capture_output=True, text=True)
        if r.returncode == 0:
            log.info("定时任务注册成功！")
        else:
            log.error(f"注册失败: {r.stderr.strip()}")
            log.info("请以管理员身份手动执行以下命令:")
            sys.stdout.buffer.write((res["schtask_cmd"] + "\n").encode("utf-8", errors="replace"))
            sys.stdout.buffer.flush()


if __name__ == "__main__":
    if "--learn-from-video" in sys.argv:
        _handle_video_learn(sys.argv[1:])
    else:
        force = "--force" in sys.argv
        main(force=force)
