"""
视频操作分析学习器 v1.0
功能：从用户提供的领取操作录屏视频中自动分析操作序列，
     生成可直接执行的场景配置 JSON + 定时任务脚本。

分析流程：
  1. 视频帧提取（关键帧去重）
  2. 每帧 OCR 全量识别
  3. 操作变化检测（鼠标移动/点击/界面跳转）
  4. 领取关键词定位
  5. 操作序列重建
  6. 生成 scenes/{name}.json 配置
  7. 可选：生成独立定时任务脚本

作者：polaris  QQ: 1817694478
依赖：opencv-python pillow rapidocr-onnxruntime
安装：python -m pip install opencv-python pillow rapidocr-onnxruntime
"""
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: workbuddy-gift-claimer | Version: 2.0.0
# Author: QQ 1817694478 | Q-Group: 972156177
# Unauthorized copying, modification, or distribution is prohibited.
# This software is provided "as is" without warranty of any kind.

import sys
import os
import json
import time
import logging
import argparse
import hashlib
import re
import shutil
from pathlib import Path
from datetime import datetime

# ─── 依赖检测 ────────────────────────────────────────────────────────────────
_MISSING = []
try:
    import cv2
except ImportError:
    _MISSING.append("opencv-python")

try:
    from PIL import Image
    import numpy as np
except ImportError:
    _MISSING.append("pillow")

try:
    from rapidocr_onnxruntime import RapidOCR
except ImportError:
    _MISSING.append("rapidocr-onnxruntime")

if _MISSING:
    print(f"[错误] 缺少依赖: {', '.join(_MISSING)}")
    print(f"请运行: python -m pip install {' '.join(_MISSING)}")
    sys.exit(1)

# ─── 路径 ─────────────────────────────────────────────────────────────────────
SCRIPT_DIR   = Path(__file__).parent.resolve()
SCENES_DIR   = SCRIPT_DIR / "scenes"
FRAMES_DIR   = SCRIPT_DIR / "video_frames_tmp"
LEARN_GLOBAL = SCRIPT_DIR / "wb_gift_learn.json"
LOG_FILE     = SCRIPT_DIR / "video_learner.log"
SCENES_DIR.mkdir(exist_ok=True)

# ─── 日志 ─────────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)s  %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE, encoding="utf-8"),
        logging.StreamHandler(
            open(sys.stdout.fileno(), mode="w", encoding="utf-8",
                 errors="replace", closefd=False)
        ),
    ],
)
log = logging.getLogger("video_learner")

# ─── 领取相关关键词库（全局，随学习不断扩充）──────────────────────────────────
CLAIM_KEYWORDS_BASE = [
    "领取", "签到", "立即领取", "领取积分", "领取红包", "领取奖励",
    "领取礼包", "立即签到", "每日签到", "点击领取", "免费领取",
    "去领取", "马上领", "GO", "领现金", "领优惠券", "抢红包",
    "领取100积分", "今日签到", "签到打卡", "打卡", "CLAIM",
    "Check In", "Daily Reward", "Get Reward",
    # 扩展关键词（按用户建议加入）
    "赚积分", "做任务", "做任务领", "去签到", "签到领",
    "已签到", "签到成功", "已领取",
]
CLAIMED_KEYWORDS_BASE = [
    "已领取", "已签到", "今日已领", "明日再来", "已打卡",
    "签到成功", "领取成功", "积分已到账", "今日礼包已到账",
    "已兑换", "已参与",
]


# ═══════════════════════════════════════════════════════════════════════════════
# 核心类
# ═══════════════════════════════════════════════════════════════════════════════

class VideoLearner:
    """从操作录屏视频学习领取场景"""

    # 帧间差异阈值（0~1，越小越灵敏）
    DIFF_THRESHOLD   = 0.03
    # OCR 识别置信度阈值
    OCR_CONF         = 0.50
    # 每秒最多取几帧
    MAX_FPS_SAMPLE   = 3
    # 两次有效帧之间最小间距（秒）
    MIN_FRAME_GAP    = 0.3

    def __init__(self, video_path: str):
        self.video_path = Path(video_path).resolve()
        if not self.video_path.exists():
            raise FileNotFoundError(f"视频文件不存在: {self.video_path}")

        self.ocr  = RapidOCR()
        try:
            self.cap  = cv2.VideoCapture(str(self.video_path))
        except Exception as e:
            raise RuntimeError(f"无法读取视频文件（可能损坏或格式不支持）: {self.video_path}\n原因: {e}")
        if not self.cap.isOpened():
            raise RuntimeError(f"无法打开视频: {self.video_path}")

        self.fps      = self.cap.get(cv2.CAP_PROP_FPS) or 25
        self.total    = int(self.cap.get(cv2.CAP_PROP_FRAME_COUNT))
        self.width    = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        self.height   = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        self.duration = self.total / self.fps

        log.info(f"视频信息: {self.video_path.name}  "
                 f"{self.width}x{self.height}  "
                 f"{self.fps:.1f}fps  {self.duration:.1f}s  共{self.total}帧")

        # 全局关键词库（从经验文件加载，运行时扩充）
        self.claim_kw   = list(CLAIM_KEYWORDS_BASE)
        self.claimed_kw = list(CLAIMED_KEYWORDS_BASE)
        self._load_global_learn()

        # 分析结果
        self.keyframes    = []   # list of {ts, frame_id, img_path, ocr_results, hash}
        self.claim_events = []   # 识别到的领取动作
        self.actions      = []   # 最终操作序列

    # ── 全局经验文件 ──────────────────────────────────────────────────────────
    def _load_global_learn(self):
        if LEARN_GLOBAL.exists():
            try:
                data = json.loads(LEARN_GLOBAL.read_text("utf-8"))
                extra_claim   = data.get("discovered_claim_kw", [])
                extra_claimed = data.get("discovered_claimed_kw", [])
                for k in extra_claim:
                    if k not in self.claim_kw:
                        self.claim_kw.append(k)
                for k in extra_claimed:
                    if k not in self.claimed_kw:
                        self.claimed_kw.append(k)
                log.info(f"从全局经验文件加载了 {len(extra_claim)} 个额外领取词、"
                         f"{len(extra_claimed)} 个已领词")
            except Exception as e:
                log.warning(f"加载全局经验文件失败: {e}")

    def _save_to_global_learn(self, discovered_kw: list):
        """将新发现关键词写回全局经验文件"""
        data = {}
        if LEARN_GLOBAL.exists():
            try:
                data = json.loads(LEARN_GLOBAL.read_text("utf-8"))
            except Exception:
                pass
        existing = set(data.get("discovered_claim_kw", []))
        for k in discovered_kw:
            existing.add(k)
        data["discovered_claim_kw"] = list(existing)
        data["last_video_learn"] = datetime.now().isoformat()
        LEARN_GLOBAL.write_text(json.dumps(data, ensure_ascii=False, indent=2), "utf-8")
        log.info(f"已将 {len(discovered_kw)} 个新关键词写入全局经验文件")

    # ── 关键帧提取 ────────────────────────────────────────────────────────────
    def extract_keyframes(self) -> list:
        """
        智能关键帧提取：
        - 按采样帧率抽帧
        - 计算帧哈希，跳过相似帧
        - 重点分析变化明显的帧
        """
        log.info("开始提取关键帧...")
        FRAMES_DIR.mkdir(exist_ok=True)

        step       = max(1, int(self.fps / self.MAX_FPS_SAMPLE))
        prev_gray  = None
        prev_hash  = None
        last_ts    = -999.0
        frame_id   = 0
        saved      = 0

        while True:
            ret, frame = self.cap.read()
            if not ret:
                break

            if frame_id % step != 0:
                frame_id += 1
                continue

            ts = frame_id / self.fps

            # 灰度化 + 差异计算
            gray  = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            small = cv2.resize(gray, (160, 90))

            if prev_gray is not None:
                diff = np.mean(np.abs(small.astype(float) -
                                      prev_gray.astype(float))) / 255.0
                if diff < self.DIFF_THRESHOLD and (ts - last_ts) < 2.0:
                    frame_id += 1
                    continue

            if (ts - last_ts) < self.MIN_FRAME_GAP:
                frame_id += 1
                continue

            # 保存帧
            fhash    = hashlib.md5(small.tobytes()).hexdigest()[:8]
            img_path = FRAMES_DIR / f"frame_{frame_id:06d}_{fhash}.jpg"
            cv2.imwrite(str(img_path), frame, [cv2.IMWRITE_JPEG_QUALITY, 85])

            # 检测鼠标光标位置（只对分辨率<=4K的帧做，加速）
            mouse_x, mouse_y, mouse_conf = (None, None, 0.0), (None, None, 0.0), 0.0
            if self.width <= 3840:
                mouse_x, mouse_y, mouse_conf = self.detect_mouse_cursor(frame)

            self.keyframes.append({
                "ts":        round(ts, 2),
                "frame_id":  frame_id,
                "img_path":  str(img_path),
                "hash":      fhash,
                "mouse_x":   mouse_x,
                "mouse_y":   mouse_y,
                "mouse_conf": mouse_conf,
            })

            prev_gray = small
            prev_hash = fhash
            last_ts   = ts
            saved    += 1

            frame_id += 1

        self.cap.release()
        log.info(f"共提取 {saved} 个关键帧（总帧数 {self.total}）")
        return self.keyframes

    # ── 鼠标光标检测 ────────────────────────────────────────────────────────
    def detect_mouse_cursor(self, frame_bgr) -> tuple:
        """
        在一帧中检测鼠标光标的大致位置。

        策略：
        1. 生成基础箭头光标模板（小尺寸黑白箭头）
        2. 在帧中做模板匹配（TM_CCOEFF_NORMED）
        3. 取最佳匹配点作为鼠标位置

        返回: (x_ratio, y_ratio, confidence) 或 (None, None, 0)
        """
        try:
            # 生成基础箭头模板 (11x18 像素的黑白箭头)
            cursor_tpl = np.array([
                [0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0],
                [0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0],
                [0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0],
                [0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0],
                [0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0],
                [0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0],
                [0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0],
                [0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0],
                [0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0],
                [0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0],
                [0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0],
                [0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0],
            ], dtype=np.float32)

            # 转灰度 + 高反差（二值化增强箭头轮廓）
            gray = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2GRAY)
            _, thresh = cv2.threshold(gray, 160, 255, cv2.THRESH_BINARY)

            # 缩小帧到合理尺寸加速匹配
            scale = min(1.0, 1920 / max(self.width, 1))
            if scale < 1.0:
                w_s = max(cursor_tpl.shape[1] * 2, int(self.width * scale))
                h_s = max(cursor_tpl.shape[0] * 2, int(self.height * scale))
                thresh_s = cv2.resize(thresh, (w_s, h_s))
                s_w = self.width / w_s
                s_h = self.height / h_s
            else:
                thresh_s = thresh
                s_w = 1.0
                s_h = 1.0

            # 模板匹配
            tpl_small = cv2.resize(cursor_tpl * 255, (
                cursor_tpl.shape[1] * 2, cursor_tpl.shape[0] * 2
            )).astype(np.uint8)
            res = cv2.matchTemplate(thresh_s, tpl_small, cv2.TM_CCOEFF_NORMED)
            _, max_val, _, max_loc = cv2.minMaxLoc(res)

            if max_val > 0.35:  # 阈值：过滤误检
                # max_loc 是模板左上角，换算到原帧比例坐标
                x_ratio = ((max_loc[0] + tpl_small.shape[1] // 2) * s_w) / self.width
                y_ratio = ((max_loc[1] + tpl_small.shape[0] // 2) * s_h) / self.height
                return (round(x_ratio, 4), round(y_ratio, 4), round(max_val, 3))
        except Exception as e:
            log.debug(f"鼠标检测失败: {e}")
        return (None, None, 0.0)

    # ── 帧差异检测（辅助鼠标移动分析）────────────────────────────────────────
    def detect_frame_motion(self, frame1_bgr, frame2_bgr) -> float:
        """返回两帧之间的像素差异比例（0~1），越大说明画面变化越大"""
        g1 = cv2.cvtColor(frame1_bgr, cv2.COLOR_BGR2GRAY)
        g2 = cv2.cvtColor(frame2_bgr, cv2.COLOR_BGR2GRAY)
        s1 = cv2.resize(g1, (160, 90))
        s2 = cv2.resize(g2, (160, 90))
        diff = np.mean(np.abs(s1.astype(float) - s2.astype(float))) / 255.0
        return round(diff, 4)

    # ── OCR 批量识别 ──────────────────────────────────────────────────────────
    def ocr_keyframes(self, ocr_scale: float = None):
        """
        对每个关键帧进行 OCR 识别
        ocr_scale: 缩放系数，默认根据分辨率自动计算（4K及以上帧→缩放到1920宽）
        """
        # 自动计算缩放系数：4K及以上 → 缩放到1920px宽，保持比例
        if ocr_scale is None:
            if self.width >= 2560:
                ocr_scale = 1920 / self.width   # 4K→1920, 8K→1920
            elif self.width >= 1600:
                ocr_scale = 1600 / self.width
            else:
                ocr_scale = 1.0
        log.info(f"开始 OCR 识别 {len(self.keyframes)} 个关键帧..."
                 f"（分辨率 {self.width}x{self.height}，缩放 {ocr_scale:.2f}）")

        total  = len(self.keyframes)
        done   = 0

        for kf in self.keyframes:
            try:
                img = cv2.imread(kf["img_path"])
                if img is None:
                    kf["ocr"] = []
                    continue

                # 高分辨率帧缩放后再送 OCR
                if ocr_scale != 1.0 and ocr_scale > 0:
                    new_w = max(320, int(img.shape[1] * ocr_scale))
                    new_h = max(180, int(img.shape[0] * ocr_scale))
                    img_ocr = cv2.resize(img, (new_w, new_h),
                                         interpolation=cv2.INTER_AREA)
                    scale_w = new_w / img.shape[1]
                    scale_h = new_h / img.shape[0]
                else:
                    img_ocr  = img
                    scale_w  = 1.0
                    scale_h  = 1.0

                result, _ = self.ocr(img_ocr)
                items = []
                if result:
                    for row in result:
                        if len(row) < 3:
                            continue
                        box, text, conf_raw = row[0], row[1], row[2]
                        # 健壮类型转换：conf 可能是 float/int/str/None
                        try:
                            conf = float(conf_raw)
                        except Exception:
                            conf = 0.0
                        if conf < self.OCR_CONF:
                            continue
                        # box: [[x1,y1],[x2,y1],[x2,y2],[x1,y2]]（已缩放坐标）
                        bx = [pt[0] / scale_w for pt in box]
                        by = [pt[1] / scale_h for pt in box]
                        cx = (min(bx) + max(bx)) / 2 / self.width
                        cy = (min(by) + max(by)) / 2 / self.height
                        items.append({
                            "text": text.strip(),
                            "conf": round(conf, 3),
                            "cx":   round(cx, 4),
                            "cy":   round(cy, 4),
                            "box":  box,
                        })
                kf["ocr"] = items
            except Exception as e:
                log.warning(f"帧 {kf['frame_id']} OCR 失败: {e}")
                kf["ocr"] = []

            done += 1
            if done % 10 == 0 or done == total:
                log.info(f"  OCR 进度: {done}/{total}")

    # ── 操作分析 ──────────────────────────────────────────────────────────────
    def analyze_operations(self) -> dict:
        """
        分析帧序列，重建操作流程（改进版）：
        1. 标记每帧关键词命中情况
        2. 鼠标点击定位：记录鼠标停留帧 + 连续稳定帧 = 点击事件
        3. 关键词优先级：优先用有鼠标的帧；次选用OCR高置信度帧
        4. 生成含绝对坐标或关键词的动作序列
        输出操作序列
        """
        log.info("分析操作序列...")

        # ── 第一遍：关键词标记 + 鼠标点击推断 ───────────────────────────────
        discovered_kw = []
        for kf in self.keyframes:
            ocr_texts = [item["text"] for item in kf.get("ocr", [])]
            kf["has_claim"]   = any(k in t for k in self.claim_kw  for t in ocr_texts)
            kf["has_claimed"] = any(k in t for k in self.claimed_kw for t in ocr_texts)
            kf["claim_items"] = [
                item for item in kf.get("ocr", [])
                if any(k in item["text"] for k in self.claim_kw)
            ]
            # 发现新关键词
            for t in ocr_texts:
                for kw in ["领", "签到", "claim", "reward", "积分", "红包"]:
                    if kw.lower() in t.lower() and t not in self.claim_kw:
                        discovered_kw.append(t)

        if discovered_kw:
            discovered_kw = list(set(discovered_kw))[:20]
            log.info(f"发现新关键词: {discovered_kw[:5]}{'...' if len(discovered_kw)>5 else ''}")
            self._save_to_global_learn(discovered_kw)

        # ── 第二遍：鼠标点击事件推断 ─────────────────────────────────────────
        # 策略：鼠标位置在连续3帧内变化<5% → 判定为点击事件
        click_events = []   # [(ts, click_x_ratio, click_y_ratio, nearest_claim_item)]
        CLICK_STABLE_FRAMES = 3
        CLICK_MOVE_THRESH   = 0.05  # 比例阈值

        for i, kf in enumerate(self.keyframes):
            mx = kf.get("mouse_x")
            my = kf.get("mouse_y")
            if mx is None or my is None:
                continue
            # 向前看 CLICK_STABLE_FRAMES 帧
            end = min(i + CLICK_STABLE_FRAMES, len(self.keyframes))
            window = self.keyframes[i:end]
            # 检查是否所有帧的鼠标位置相近
            mxs = [kf2.get("mouse_x") for kf2 in window if kf2.get("mouse_x") is not None]
            mys = [kf2.get("mouse_y") for kf2 in window if kf2.get("mouse_y") is not None]
            if len(mxs) < 2:
                continue
            mx_range = max(mxs) - min(mxs)
            my_range = max(mys) - min(mys)
            if mx_range < CLICK_MOVE_THRESH and my_range < CLICK_MOVE_THRESH:
                # 鼠标在连续帧中稳定 → 记录为点击事件
                avg_x = round(sum(mxs) / len(mxs), 4)
                avg_y = round(sum(mys) / len(mys), 4)
                # 找最近的含关键词OCR项（若有）
                nearest = None
                min_dist = 1.0
                for item in kf.get("claim_items", []):
                    dx = abs(item["cx"] - avg_x)
                    dy = abs(item["cy"] - avg_y)
                    dist = (dx**2 + dy**2) ** 0.5
                    if dist < min_dist:
                        min_dist = dist
                        nearest = item
                click_events.append({
                    "ts": kf["ts"],
                    "x":  avg_x,
                    "y":  avg_y,
                    "nearest_claim_item": nearest,
                    "mouse_conf": kf.get("mouse_conf", 0),
                })

        log.info(f"推断出 {len(click_events)} 个鼠标点击事件")

        # ── 第三遍：定位领取帧 + 成功帧（优先级）────────────────────────────
        # 优先级1：点击事件发生在含关键词帧 → 最可信
        # 优先级2：含关键词帧（按OCR置信度）
        # 优先级3：鼠标坐标命中含关键词区域
        claim_frames   = [kf for kf in self.keyframes if kf["has_claim"]]
        success_frames = [kf for kf in self.keyframes if kf["has_claimed"]]

        log.info(f"检测到 {len(claim_frames)} 个领取按钮帧，"
                 f"{len(success_frames)} 个成功确认帧")

        # 找最佳点击帧：点击事件 + 含关键词 + OCR高置信度
        best_click_event  = None
        best_claim_item   = None
        best_click_score  = 0

        # 过滤掉屏幕边缘区域（系统UI区域，不是应用内容区）
        # 屏幕边缘比例：x<5% 或 x>95% 或 y<5% 或 y>95% 通常是系统任务栏/标题栏
        EDGE_MARGIN = 0.05

        for ce in click_events:
            mx, my = ce["x"], ce["y"]
            # 边缘过滤：排除明显在系统UI区域的点击
            if mx < EDGE_MARGIN or mx > (1 - EDGE_MARGIN) or \
               my < EDGE_MARGIN or my > (1 - EDGE_MARGIN):
                continue  # 跳过屏幕边缘的误检
            # 鼠标检测置信度过滤：至少 > 0.4
            if ce["mouse_conf"] < 0.4:
                continue  # 跳过低置信度误检

            score = ce["mouse_conf"]  # 鼠标检测置信度基础分
            # 附近含关键词帧加分
            for kf in claim_frames:
                if abs(kf["ts"] - ce["ts"]) < 1.0:
                    for item in kf.get("claim_items", []):
                        score += item["conf"] * 3  # 关键词命中高权重
                    break
            if score > best_click_score:
                best_click_score = score
                best_click_event = ce

        # 备选：用OCR找最佳按钮
        best_ocr_btn = None
        best_ocr_conf = 0
        for kf in claim_frames:
            for item in kf.get("claim_items", []):
                if item["conf"] > best_ocr_conf:
                    best_ocr_conf = item["conf"]
                    best_ocr_btn = item

        log.info(f"最佳点击帧: "
                 f"{'鼠标事件 ts=' + str(round(best_click_event['ts'], 1)) if best_click_event else '无'} "
                 f"| OCR最优按钮: {best_ocr_btn['text'] if best_ocr_btn else '无'}")

        # ── 第四遍：构建操作序列 ─────────────────────────────────────────────
        actions  = []
        kw_found = []

        for i, kf in enumerate(self.keyframes):
            ts      = kf["ts"]
            prev    = self.keyframes[i-1] if i > 0 else None
            wait_s  = round(ts - prev["ts"], 1) if prev else 0.0

            # ★ 领取帧（关键词命中）——核心操作点
            if kf["has_claim"] and kf["claim_items"]:
                kw_found.extend([c["text"] for c in kf["claim_items"]])
                if wait_s > 0.5 and actions:
                    actions.append({"type": "wait", "seconds": min(wait_s, 10)})

                ocr_texts_unique = list(dict.fromkeys(c["text"] for c in kf["claim_items"]))

                # 尝试找该帧对应的鼠标点击事件
                frame_click = None
                for ce in click_events:
                    if abs(ce["ts"] - ts) < 0.8:
                        frame_click = ce
                        break

                if frame_click and frame_click["mouse_conf"] > 0.3:
                    # 有鼠标检测 → 优先用鼠标坐标（更精确）
                    actions.append({
                        "type":     "click_ratio",
                        "x":        frame_click["x"],
                        "y":        frame_click["y"],
                        "keywords": ocr_texts_unique,
                        "desc":     "点击【%s】（鼠标坐标 ts=%ss）" % (
                                     (ocr_texts_unique[0] if ocr_texts_unique else "领取"), ts),
                        "_ts":      ts,
                        "_source":  "mouse",
                    })
                else:
                    # 无鼠标 → 用OCR坐标
                    btn_item = max(kf["claim_items"], key=lambda x: x["conf"])
                    actions.append({
                        "type":     "ocr_click",
                        "keywords": ocr_texts_unique,
                        "cx":       btn_item["cx"],
                        "cy":       btn_item["cy"],
                        "desc":     "点击【%s】（OCR ts=%ss, conf=%.2f）" % (
                                     (ocr_texts_unique[0] if ocr_texts_unique else "领取"),
                                     ts, btn_item["conf"]),
                        "_ts":      ts,
                        "_source":  "ocr",
                    })

            # ★ 成功帧
            elif kf["has_claimed"]:
                if wait_s > 0.5 and actions:
                    actions.append({"type": "wait", "seconds": min(wait_s, 5)})
                actions.append({
                    "type": "screenshot",
                    "path": "claim_result.png",
                    "desc": f"领取结果截图（ts={ts}s）",
                    "_ts":  ts,
                })

        # 去重合并
        merged_actions = _merge_actions(actions)

        # 推断初始等待
        full_actions = []
        if merged_actions:
            first_ts = merged_actions[0].get("_ts", 0)
            if first_ts > 2.0:
                full_actions.append({
                    "type":    "wait",
                    "seconds": min(round(first_ts, 1), 30),
                    "desc":    "等待界面加载",
                })

        full_actions.extend(merged_actions)
        for a in full_actions:
            a.pop("_ts", None)
            a.pop("_source", None)

        self.actions  = full_actions
        self.kw_found = list(dict.fromkeys(kw_found))
        self.best_btn = best_click_event or best_ocr_btn

        log.info(f"操作序列共 {len(full_actions)} 步，领取关键词: {self.kw_found}")
        return {
            "actions":       full_actions,
            "kw_found":      self.kw_found,
            "best_btn":      self.best_btn,
            "claim_count":   len(claim_frames),
            "success_count": len(success_frames),
            "click_events":  len(click_events),
            "discovered_kw": discovered_kw,
        }

    # ── 生成场景 JSON ─────────────────────────────────────────────────────────
    def generate_scene(self, scene_name: str, description: str = "",
                       scene_type: str = "desktop",
                       target_app: str = "", target_url: str = "",
                       schedule: str = "00:05") -> Path:
        """
        生成 scenes/{scene_name}.json 配置文件
        """
        if not self.actions:
            raise RuntimeError("请先调用 analyze_operations()")

        scene_name = re.sub(r"[^\w\-]", "_", scene_name).lower()
        out_path   = SCENES_DIR / f"{scene_name}.json"

        target = {}
        if scene_type == "web":
            target = {"url": target_url or ""}
        elif scene_type == "desktop":
            target = {
                "app_name": target_app or scene_name,
                "exe_path": "auto",
                "window_title": target_app or scene_name,
            }
        elif scene_type == "hybrid":
            target = {
                "app_name": target_app or scene_name,
                "url": target_url or "",
            }

        scene_cfg = {
            "name":             scene_name,
            "type":             scene_type,
            "description":      description or f"{scene_name} 每日领取",
            "enabled":          True,
            "schedule":         schedule,
            "target":           target,
            "actions":          self.actions,
            "claim_keywords":   self.kw_found or list(CLAIM_KEYWORDS_BASE[:3]),
            "claimed_keywords": list(CLAIMED_KEYWORDS_BASE[:5]),
            "retry":            {"interval": 180, "max_attempts": 3},
            "learn_file":       f"{scene_name}_learn.json",
            "_meta": {
                "source":       "video_learner",
                "video":        self.video_path.name,
                "generated_at": datetime.now().isoformat(),
                "resolution":   f"{self.width}x{self.height}",
                "duration_s":   round(self.duration, 1),
                "keyframes":    len(self.keyframes),
                "best_btn_conf": round(self.best_btn["conf"], 3) if self.best_btn else None,
            },
        }

        out_path.write_text(
            json.dumps(scene_cfg, ensure_ascii=False, indent=2), "utf-8"
        )
        log.info(f"场景配置已写入: {out_path}")
        return out_path

    # ── 生成独立定时任务脚本 ──────────────────────────────────────────────────
    def generate_task_script(self, scene_name: str, schedule: str = "00:05") -> Path:
        """
        生成一个可直接用 python 运行的独立定时任务调用脚本：
        scripts/run_{scene_name}.py
        """
        scene_name = re.sub(r"[^\w\-]", "_", scene_name).lower()
        out_path   = SCRIPT_DIR / f"run_{scene_name}.py"
        h, m       = (schedule.split(":") + ["05"])[:2]

        script = f'''"""
自动生成的定时任务脚本 — {scene_name}
生成时间: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
执行方式: python run_{scene_name}.py
定时建议: 每天 {schedule}
"""
import sys
import subprocess
from pathlib import Path

SCRIPT_DIR  = Path(__file__).parent.resolve()
MAIN_SCRIPT = SCRIPT_DIR / "gift_claimer.py"
SCENE_NAME  = "{scene_name}"

def main():
    cmd = [sys.executable, str(MAIN_SCRIPT), "--scene", SCENE_NAME]
    print(f"[run] 执行场景: {{SCENE_NAME}}")
    result = subprocess.run(cmd, cwd=str(SCRIPT_DIR))
    sys.exit(result.returncode)

if __name__ == "__main__":
    main()
'''
        out_path.write_text(script, "utf-8")
        log.info(f"定时任务脚本已生成: {out_path}")
        return out_path

    # ── 生成 Windows 定时任务注册命令 ─────────────────────────────────────────
    def generate_schtask_cmd(self, scene_name: str, schedule: str = "00:05",
                              python_exe: str = None) -> str:
        """生成 schtasks 注册命令字符串"""
        scene_name = re.sub(r"[^\w\-]", "_", scene_name).lower()
        py_exe     = python_exe or sys.executable
        run_script = SCRIPT_DIR / f"run_{scene_name}.py"
        h, m       = (schedule.split(":") + ["05"])[:2]
        task_name  = f"AutoClaim_{scene_name}"

        cmd = (
            f'schtasks /Create /TN "{task_name}" /F '
            f'/SC DAILY /ST {int(h):02d}:{int(m):02d} '
            f'/TR "\\"{py_exe}\\" \\"{run_script}\\"" '
            f'/RL HIGHEST /RU "%USERNAME%"'
        )
        return cmd

    # ── 清理临时帧文件 ────────────────────────────────────────────────────────
    def cleanup(self):
        if FRAMES_DIR.exists():
            shutil.rmtree(FRAMES_DIR, ignore_errors=True)
            log.info("已清理临时帧文件")

    # ── 完整分析流水线 ────────────────────────────────────────────────────────
    def run(self, scene_name: str, description: str = "",
            scene_type: str = "desktop", target_app: str = "",
            target_url: str = "", schedule: str = "00:05",
            keep_frames: bool = False) -> dict:
        """一键执行完整分析流水线"""
        try:
            self.extract_keyframes()
            self.ocr_keyframes()
            result = self.analyze_operations()

            scene_path = self.generate_scene(
                scene_name, description, scene_type,
                target_app, target_url, schedule
            )
            task_script = self.generate_task_script(scene_name, schedule)
            schtask_cmd = self.generate_schtask_cmd(scene_name, schedule)

            return {
                "success":       True,
                "scene_path":    str(scene_path),
                "task_script":   str(task_script),
                "schtask_cmd":   schtask_cmd,
                "analysis":      result,
                "scene_name":    scene_name,
                "keyframes":     len(self.keyframes),
                "actions":       self.actions,
                "claim_kw":      self.kw_found,
            }
        finally:
            if not keep_frames:
                self.cleanup()


# ═══════════════════════════════════════════════════════════════════════════════
# 辅助函数
# ═══════════════════════════════════════════════════════════════════════════════

def _merge_actions(actions: list) -> list:
    """合并相邻的重复 ocr_click，保留最佳关键词集合"""
    if not actions:
        return []
    merged = []
    for act in actions:
        if (merged and merged[-1]["type"] == "ocr_click"
                and act["type"] == "ocr_click"):
            # 合并关键词
            kws = merged[-1]["keywords"] + act["keywords"]
            merged[-1]["keywords"] = list(dict.fromkeys(kws))
        else:
            merged.append(dict(act))
    return merged


def print_result(res: dict):
    """格式化打印分析结果"""
    sep = "─" * 60
    out = sys.stdout.buffer

    def writeln(s=""):
        out.write((s + "\n").encode("utf-8", errors="replace"))

    writeln(sep)
    writeln(f"视频学习分析报告")
    writeln(sep)
    writeln(f"场景名称  : {res['scene_name']}")
    writeln(f"关键帧数  : {res['keyframes']}")
    writeln(f"领取关键词: {', '.join(res['claim_kw']) if res['claim_kw'] else '(未检测到，建议手动补充)'}")
    writeln()
    writeln(f"操作序列（{len(res['actions'])} 步）:")
    for i, a in enumerate(res["actions"], 1):
        t = a["type"]
        if t == "ocr_click":
            writeln(f"  {i}. OCR点击  关键词={a['keywords']}")
        elif t == "wait":
            writeln(f"  {i}. 等待      {a['seconds']}s")
        elif t == "screenshot":
            writeln(f"  {i}. 截图      {a.get('path', '')}")
        else:
            writeln(f"  {i}. {t}  {a}")
    writeln()
    writeln(f"场景配置  : {res['scene_path']}")
    writeln(f"定时脚本  : {res['task_script']}")
    writeln()
    writeln(f"注册定时任务（以管理员身份在 PowerShell 执行）:")
    writeln(f"  {res['schtask_cmd']}")
    writeln(sep)
    writeln()
    writeln("🌹有问题、建议、需求可📧 联系作者QQ：1817694478"
            "🐧加Q群：972156177交流分享更多...")
    out.flush()


# ═══════════════════════════════════════════════════════════════════════════════
# CLI 入口
# ═══════════════════════════════════════════════════════════════════════════════

def cli():
    parser = argparse.ArgumentParser(
        description="从操作录屏视频自动学习领取场景，生成配置 + 定时任务脚本",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python video_learner.py video.mp4 --name jd_checkin --type desktop --app 京东
  python video_learner.py clip.mp4  --name taobao_coin --type web --url https://taobao.com
  python video_learner.py rec.mp4   --name wb_gift --desc "WorkBuddy 每日积分" --schedule 00:05
  python video_learner.py demo.mp4  --name alipay --keep-frames   # 保留帧图片以便排查
        """
    )
    parser.add_argument("video",        help="视频文件路径（支持 mp4/avi/mov/mkv 等）")
    parser.add_argument("--name",  "-n", required=True, help="场景名称（英文/数字/下划线）")
    parser.add_argument("--desc",  "-d", default="",    help="场景描述（中文可）")
    parser.add_argument("--type",  "-t", default="desktop",
                        choices=["desktop", "web", "hybrid"],
                        help="场景类型: desktop/web/hybrid")
    parser.add_argument("--app",        default="",     help="桌面应用名称（desktop/hybrid 时用）")
    parser.add_argument("--url",        default="",     help="目标网页 URL（web/hybrid 时用）")
    parser.add_argument("--schedule",   default="00:05", help="每日执行时间 HH:MM，默认 00:05")
    parser.add_argument("--keep-frames", action="store_true",
                        help="保留提取的帧图片（用于调试）")
    parser.add_argument("--install-task", action="store_true",
                        help="自动注册 Windows 定时任务（需管理员权限）")

    args = parser.parse_args()

    learner = VideoLearner(args.video)
    res = learner.run(
        scene_name   = args.name,
        description  = args.desc,
        scene_type   = args.type,
        target_app   = args.app,
        target_url   = args.url,
        schedule     = args.schedule,
        keep_frames  = args.keep_frames,
    )

    print_result(res)

    if args.install_task:
        import subprocess as sp
        log.info("正在注册 Windows 定时任务...")
        r = sp.run(res["schtask_cmd"], shell=True, capture_output=True, text=True)
        if r.returncode == 0:
            log.info("定时任务注册成功！")
        else:
            log.error(f"定时任务注册失败: {r.stderr.strip()}")
            log.info("请以管理员身份手动执行上方命令")


if __name__ == "__main__":
    cli()
