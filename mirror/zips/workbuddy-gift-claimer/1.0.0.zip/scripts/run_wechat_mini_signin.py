#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
微信小程序每日签到 - 自动执行脚本
由 video_learner.py 自动生成 | 时间: 2026-04-24 14:17
场景: 微信小程序每日签到
使用方式: python run_wechat_mini_signin.py
"""
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: workbuddy-gift-claimer | Version: 2.0.0
# Author: QQ 1817694478 | Q-Group: 972156177
# Unauthorized copying, modification, or distribution is prohibited.
# This software is provided "as is" without warranty of any kind.
import sys, os, logging
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("wechat_signin.log", encoding="utf-8"),
        logging.StreamHandler()
    ]
)

def main():
    from gift_claimer import main as claimer_main
    original = sys.argv.copy()
    sys.argv = [original[0], "--scene", "wechat_mini_signin"]
    try:
        claimer_main(force=False)
    finally:
        sys.argv = original

if __name__ == "__main__":
    main()
