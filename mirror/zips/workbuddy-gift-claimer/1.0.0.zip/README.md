<!--
Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
Skill: workbuddy-gift-claimer | Version: 2.0.0
Author: QQ 1817694478 | Q-Group: 972156177
Unauthorized copying, modification, or distribution is prohibited.
-->
# workbuddy-gift-claimer 技术文档

> ⚠️ 此文件为开发/维护参考，发布打包时自动排除（ClawdHub不包含README.md）

---

## 文件结构

```
workbuddy-gift-claimer/
├── SKILL.md                          # 技能说明（发布版，精简）
├── README.md                         # 技术文档（本文件，打包排除）
├── manifest.json                     # 完整性校验清单
└── scripts/
    ├── gift_claimer.py               # 核心领取引擎（场景调度+OCR+自学习+视频学习入口）
    ├── video_learner.py              # 视频学习分析器（帧提取+OCR+操作推断+配置生成）
    ├── scene_manager.py              # 场景管理器（增删改查+截图学习+链接配置）——如果存在
    ├── install_task.py               # 定时任务安装器（v2）
    ├── run_scene.py                  # 场景独立执行脚本
    ├── run_wechat_mini_signin.py     # 微信小程序签到专用脚本
    ├── browser_helper.py             # 浏览器自动化辅助（网页领取场景）——如果存在
    ├── wb_gift_learn.json            # WorkBuddy场景自学习经验（内置）
    ├── scenes/                       # 场景配置目录
    │   ├── workbuddy.json            # 内置：WorkBuddy每日积分——如果存在
    │   ├── wechat_mini_signin.json   # 微信小程序签到配置
    │   └── wechat_mini_signin_v2.json # 微信小程序签到配置v2
    │   └── {scene_name}.json         # 视频/截图/链接学习自动生成的场景配置
    ├── logs/                         # 执行日志目录
    ├── video_frames_tmp/             # 视频帧临时目录（打包排除）
    └── plugins/                      # 自定义插件目录——如果存在
        └── example_plugin.py         # 插件示例——如果存在
```

---

## CLI 命令

### 基础领取

```bash
# 一键领取所有场景（自动跳过已领）
python scripts/gift_claimer.py

# 领取指定场景
python scripts/gift_claimer.py --scene workbuddy

# 强制重新领取（忽略已领检测）
python scripts/gift_claimer.py --force

# 安装定时任务
python scripts/install_task.py
```

### 场景管理

```bash
# 查看所有已配置场景
python scripts/gift_claimer.py --list-scenes

# 添加新场景（交互式引导）
python scripts/gift_claimer.py --add-scene

# 从截图学习新场景
python scripts/gift_claimer.py --learn-from-screenshot "截图路径.png"

# 从链接配置新场景
python scripts/gift_claimer.py --learn-from-url "https://xxx.com/checkin"

# 从视频学习新场景
python scripts/gift_claimer.py --learn-from-video "录屏.mp4" \
    --name jd_checkin --desc "京东每日签到" --type desktop --app 京东

# 测试指定场景
python scripts/gift_claimer.py --test-scene jd_checkin

# 删除场景
python scripts/gift_claimer.py --remove-scene jd_checkin

# 查看场景学习数据
python scripts/gift_claimer.py --scene-learn jd_checkin

# 查看全局状态
python scripts/gift_claimer.py --status-all
```

### 视频学习（独立调用）

```bash
python scripts/video_learner.py "操作录屏.mp4" \
    --name alipay_points --desc "支付宝积分" --type desktop \
    --schedule 09:00 --install-task
```

---

## 场景配置文件格式

每个场景一个 JSON 文件，存放于 `scripts/scenes/` 目录：

```json
{
  "name": "workbuddy",
  "type": "desktop",
  "description": "WorkBuddy 每日 100 Credits",
  "enabled": true,
  "schedule": "00:05",
  "target": {
    "app_name": "WorkBuddy",
    "exe_path": "auto",
    "window_title": "WorkBuddy"
  },
  "actions": [
    {"type": "click_ratio", "x": 0.11, "y": 0.95, "desc": "点击头像"},
    {"type": "wait", "seconds": 4},
    {"type": "ocr_click", "keywords": ["领取100积分", "领取积分", "立即领取"]},
    {"type": "wait", "seconds": 1},
    {"type": "key", "key": "escape"}
  ],
  "claim_keywords": ["领取100积分", "领取积分", "立即领取"],
  "claimed_keywords": ["今日礼包已到账", "已领取", "已签到"],
  "retry": {"interval": 180, "max_attempts": 3},
  "learn_file": "workbuddy_learn.json"
}
```

### 场景类型说明

| 类型 | type 值 | 说明 | 必需字段 |
|------|---------|------|---------|
| 桌面应用 | `desktop` | 通过窗口定位+OCR识别 | target.app_name, actions |
| 网页 | `web` | 通过浏览器自动化 | target.url, actions |
| 混合 | `hybrid` | 桌面+网页组合 | 两者兼有 |
| 插件 | `plugin` | 自定义脚本 | target.plugin_name |

### 操作类型说明

| 操作类型 | type 值 | 参数 | 说明 |
|---------|---------|------|------|
| 比例点击 | `click_ratio` | x, y (0~1) | 按窗口比例点击，适配不同分辨率 |
| 绝对点击 | `click_abs` | x, y (像素) | 按绝对坐标点击 |
| OCR 点击 | `ocr_click` | keywords | OCR 识别关键词后点击 |
| 按键 | `key` | key | 模拟键盘按键 |
| 等待 | `wait` | seconds | 等待指定秒数 |
| 输入 | `type_text` | text | 输入文字 |
| 打开链接 | `open_url` | url | 在浏览器中打开链接 |
| 截图 | `screenshot` | path | 截取当前窗口 |

---

## 插件接口

高级用户可编写自定义领取脚本：

```python
# scripts/plugins/my_plugin.py
class MyClaimPlugin:
    """自定义领取插件示例"""
    scene_name = "my_custom_scene"
    description = "我的自定义领取场景"
    
    def claim(self) -> bool:
        """执行领取逻辑，返回 True/False"""
        return True
    
    def check_claimed(self) -> bool:
        """检查今日是否已领"""
        return False
```

规范：必须实现 `claim()` 和 `check_claimed()` 方法，放入 `scripts/plugins/` 目录自动加载。

---

## 配置参数

| 配置项 | 默认值 | 说明 |
|-------|-------|------|
| 每日执行时间 | 00:05 | 零点后5分钟 |
| 开机延迟 | 2 分钟 | 登录后等待 |
| 失败重试间隔 | 180 秒 | 3分钟 |
| 最大重试次数 | 3 次 | |
| 冷启动等待 | 60 秒 | 首次启动等窗口 |
| 面板加载等待 | 4 秒 | |
| 历史记录上限 | 30 条 | 每场景 |
| 场景间间隔 | 10 秒 | 多场景顺序 |

---

## 依赖安装

```bash
# 基础领取依赖
python -m pip install pyautogui pygetwindow pillow rapidocr-onnxruntime

# 视频学习额外依赖
python -m pip install opencv-python
```

---

## 敏感信息处理

- WB_EXE 路径：已做 base64 编码存储，运行时解码
- 无服务器域名/API地址需要混淆（本技能为纯本地操作）
- 自学习文件中的OCR发现历史含个人隐私数据，打包时应清理或排除

---

## 打包排除规则

以下文件/目录不应包含在发布包中：
- `README.md` — 开发文档，ClawdHub自动排除
- `scripts/video_frames_tmp/` — 视频帧临时文件
- `scripts/logs/` — 运行日志
- `*.pyc` — 编译缓存
- `*.log` — 日志文件
- `wb_gift_learn.json` 中的 history 字段含OCR原始数据（含隐私）

---

## 更新日志

| 版本 | 日期 | 变更 |
|------|------|------|
| v2.0.0 | 2026-04-24 | 全平台场景引擎+视频学习+自学习+防篡改 |

---

## 踩坑经验

- emoji在PowerShell/GBK环境输出会UnicodeEncodeError → 用 sys.stdout.buffer.write + encode("utf-8")
- RapidOCR首次运行需联网下载模型
- 中文环境日志需 UTF-8 编码自适应