name: tianyancha-page-monitor
description: 通过已打开的浏览器页面监控天眼查“应用 > 新增企业”模块，自动筛选松江区和嘉定区的当日新增企业，每5分钟自动刷新页面、检测新企业并通过企业微信推送，内置基于DOM快照的去重机制
version: 1.0.0
author: YourName
license: MIT
tags:
  - tianyancha
  - browser-automation
  - wecom
  - monitoring
  - page-monitor
requirements:
  python: ">=3.7"
  pip:
    - requests>=2.25.0
    - beautifulsoup4>=4.12.0
    - openclaw-tools>=0.1.0  # 或通过 OpenClaw 内置 browser 工具
env_vars:
  - WECOM_WEBHOOK_URL
  - TIANYANCHA_PAGE_URL
  - TARGET_REGIONS
cron_suggestion: "*/5 * * * *"