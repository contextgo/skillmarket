import json
import requests
import os
import subprocess
from datetime import datetime
from typing import List, Dict, Set
from bs4 import BeautifulSoup

# ================== 配置区域 ==================
WECOM_WEBHOOK_URL = os.getenv("WECOM_WEBHOOK_URL")
TIANYANCHA_PAGE_URL = os.getenv("TIANYANCHA_PAGE_URL", "https://pro.tianyancha.com/app/newCompany")
TARGET_REGIONS = json.loads(os.getenv("TARGET_REGIONS", '["松江区", "嘉定区"]'))
# ===========================================

HISTORY_FILE = "page_snapshot.json"  # 记录上次扫描时的企业快照

def get_page_html() -> str:
    """通过 OpenClaw browser 工具获取当前已打开页面的 HTML"""
    # 方式一：如果页面已打开，直接获取快照
    cmd = ["agent-browser", "snapshot", "--format", "html"]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode == 0:
        return result.stdout
    
    # 方式二：打开/刷新目标页面
    cmd_refresh = ["agent-browser", "visit", TIANYANCHA_PAGE_URL, "--html"]
    result = subprocess.run(cmd_refresh, capture_output=True, text=True)
    return result.stdout if result.returncode == 0 else ""

def parse_companies_from_html(html_content: str) -> List[Dict]:
    """从页面 HTML 中提取企业信息"""
    soup = BeautifulSoup(html_content, 'html.parser')
    companies = []
    
    # 根据天眼查页面实际结构选择合适的选择器
    # 以下选择器需根据天眼查专业版页面实际 DOM 结构调整
    company_rows = soup.select('.company-list-item, .new-company-item, table tbody tr')
    
    for row in company_rows:
        # 提取企业名称、统一社会信用代码、法定代表人等信息
        name_elem = row.select_one('.company-name, .name')
        credit_elem = row.select_one('.credit-code, .creditCode')
        legal_elem = row.select_one('.legal-person, .legalPerson')
        reg_date_elem = row.select_one('.establish-date, .establishTime')
        region_elem = row.select_one('.region, .area')
        
        company = {
            'id': credit_elem.text.strip() if credit_elem else name_elem.text.strip(),
            'name': name_elem.text.strip() if name_elem else '未知',
            'creditCode': credit_elem.text.strip() if credit_elem else '',
            'legalPerson': legal_elem.text.strip() if legal_elem else '',
            'establishDate': reg_date_elem.text.strip()[:10] if reg_date_elem else '',
            'region': region_elem.text.strip() if region_elem else ''
        }
        companies.append(company)
    
    # 根据 TARGET_REGIONS 筛选目标区域的企业
    filtered = [c for c in companies if any(region in c.get('region', '') for region in TARGET_REGIONS)]
    return filtered

def load_snapshot() -> Set[str]:
    """加载上次扫描时的企业 ID 快照"""
    if not os.path.exists(HISTORY_FILE):
        return set()
    with open(HISTORY_FILE, 'r', encoding='utf-8') as f:
        data = json.load(f)
        return set(data.get('company_ids', []))

def save_snapshot(company_ids: Set[str]):
    """保存当前企业 ID 快照"""
    with open(HISTORY_FILE, 'w', encoding='utf-8') as f:
        json.dump({'company_ids': list(company_ids), 'timestamp': datetime.now().isoformat()}, f)

def send_to_wechat(message: str):
    """通过企业微信机器人发送消息"""
    if not message:
        return
    payload = {"msgtype": "markdown", "markdown": {"content": message}}
    requests.post(WECOM_WEBHOOK_URL, json=payload)

def main():
    print(f"[{datetime.now()}] 开始执行页面监控任务")
    
    # 1. 获取页面 HTML
    html = get_page_html()
    if not html:
        print("获取页面 HTML 失败，请检查浏览器页面是否已打开")
        return
    
    # 2. 解析当前企业列表
    current_companies = parse_companies_from_html(html)
    current_ids = {c['id'] for c in current_companies}
    
    # 3. 与快照比对，找出新增企业
    previous_ids = load_snapshot()
    new_companies = [c for c in current_companies if c['id'] not in previous_ids]
    
    # 4. 如有新企业，推送并更新快照
    if new_companies:
        msg = format_markdown_message(new_companies)
        send_to_wechat(msg)
        print(f"发现 {len(new_companies)} 家新企业，已推送")
    else:
        print("未发现新企业")
    
    # 5. 更新快照
    save_snapshot(current_ids)

if __name__ == "__main__":
    main()