---
name: edgeone-pages-deploy
description: 腾讯云 EdgeOne Pages 静态网站部署技能。当用户提到"部署到 EdgeOne"、"EdgeOne Pages 发布"、"edgeone 部署"、"发布静态页面到腾讯云"等场景时使用此技能。支持完整部署流程：注册引导、CLI 安装检测、页面生成、一键部署、预览链接输出。
---

# EdgeOne Pages 部署技能

腾讯云 EdgeOne Pages 是一个全球边缘网络静态托管平台，支持秒级部署、自动 CDN 加速。

## 完整部署流程

### Step 1：确认账号注册

询问用户是否已注册腾讯云账号并开通 EdgeOne Pages：

> "你是否已注册腾讯云账号并开通了 EdgeOne Pages 服务？"

- **已注册** → 继续 Step 2
- **未注册** → 提供以下链接引导注册：
  - 腾讯云注册：https://cloud.tencent.com/register
  - EdgeOne Pages 控制台：https://console.cloud.tencent.com/edgeone/package
  - 注册完成后继续 Step 2

### Step 2：检测 edgeone CLI

运行以下命令检测是否已安装：

```powershell
edgeone -v
```

- **已安装** → 显示版本号，继续 Step 3
- **未安装** → 提示用户并询问是否立即安装：

  > "检测到未安装 edgeone CLI，是否现在安装？"

  确认后执行：
  ```powershell
  npm install -g edgeone
  ```
  安装完成后验证：`edgeone -v`，然后继续 Step 3

### Step 3：获取 API Token

询问用户是否已有 API Token：

- **已有** → 请用户提供，继续 Step 4
- **没有** → 引导用户创建：
  1. 访问：https://console.cloud.tencent.com/edgeone/pages?tab=settings
  2. 点击「创建 API Token」
  3. 填写描述，设置过期时间（建议 30 天）
  4. 复制 Token 后提供给我

### Step 4：确认生成 Demo

收到 Token 后，告诉用户：

> "好的！我将为你生成一个精美的 Demo 页面并部署到 EdgeOne Pages。部署完成后，你可以预览效果，然后告诉我你想设计的页面内容（如名字、标题、风格等），我会帮你定制并重新部署。"

确认后继续 Step 5。

### Step 5：生成测试页面

使用 `scripts/generate_hello_page.py` 生成一个精美的 Hello World 测试页面：

```powershell
python scripts/generate_hello_page.py <输出目录>
```

例如：
```powershell
python scripts/generate_hello_page.py C:\Users\pengyanwei\.qclaw\workspace\edgeone-test
```

脚本会在指定目录生成 `index.html`，包含动态背景、渐变文字、实时时钟等效果。

### Step 6：执行部署

使用以下命令部署（替换 `<项目名>` 和 `<API_TOKEN>`）：

```powershell
edgeone pages deploy <页面目录路径> -n <项目名> -t <API_TOKEN>
```

完整示例：
```powershell
edgeone pages deploy C:\Users\pengyanwei\.qclaw\workspace\edgeone-test -n my-hello-page -t YOUR_TOKEN_HERE
```

参数说明：
- `<页面目录路径>`：包含 index.html 的文件夹路径
- `-n`：项目名称（不存在会自动创建）
- `-t`：API Token
- `-e preview`：可选，部署到预览环境（默认 production）

### Step 7：输出结果

部署成功后，从命令输出中提取并展示：

```
🎉 部署成功！

🔗 访问链接：https://xxx.edgeone.cool?eo_token=xxx
📋 项目 ID：pages-xxxxxxxx
🚀 部署 ID：xxxxxxxxxx
🖥️ 控制台：https://console.tencentcloud.com/edgeone/pages/project/...
```

## 注意事项

- API Token 含敏感信息，不要记录到日志或文件中
- 项目名只能包含字母、数字、连字符，不能有中文
- 纯静态 HTML 无需构建命令，直接上传文件夹即可
- 每次重新部署同一项目名会自动更新，不会创建新项目
- 部署区域默认 global（全球），国内用户可加 `--region china`

## 快速重新部署

已有项目更新内容后，直接运行：
```powershell
edgeone pages deploy <目录> -n <项目名> -t <TOKEN>
```
无需重新配置，自动覆盖更新。