---
name: audience-barrier-reframer
description: reframe abstract or institution-centered topics into audience-enterable story angles for international communication. use when chatgpt needs to identify audience comprehension barriers, convert theory-heavy themes into concrete issue entry points, and recommend expressions that improve clarity, proximity, and credibility for overseas audiences in editorial planning.
---

# Audience Barrier Reframer

Reframe abstract, policy-heavy, institution-centered, or internally familiar topics into story angles that an external audience can enter, follow, and understand.

This skill is for editorial planning and framing, not final story drafting.

## Core task

Given a topic, target audience, and communication objective, produce a reframing plan that answers:
- What is likely to confuse, distance, or disengage this audience?
- Which parts of the original framing are too abstract or internally coded?
- What concrete entry point would make the topic easier to enter?
- How should the topic be restated so the audience understands the issue before the conclusion?

## Method

### 1. Identify the original framing problem
Diagnose whether the topic is too abstract, slogan-like, institution-centered, reliant on internal shorthand, or conclusion-first.

### 2. Infer likely audience questions
List what this audience would ask before they are ready to engage: what does this mean, why should I care, how is this visible in real life, and why is it relevant beyond China?

### 3. Convert the topic into an enterable issue
Prefer a real-world problem, visible place-based transformation, ordinary-life question, governance dilemma, or practical contradiction.

### 4. Design the explanation bridge
Use one or more of these bridges:
- problem to method
- case to principle
- person to system
- local practice to broader logic
- visible result to earlier decision

### 5. Replace internal language with legible editorial language
Decide which terms to keep and explain, paraphrase, delay, or avoid entirely in the opening.

### 6. Output a reframing plan
Use the structure in `references/reframing-output-template.md` and the diagnostic patterns in `references/barrier-patterns.md`.

## Editorial rules
- Start from the audience’s cognitive position.
- Replace declarations with entry paths.
- Translate without flattening.
- Reduce internal shorthand early.
- Prefer evidence-led explanation.

## Boundary
This skill is for audience-facing reframing, entry-point redesign, and wording strategy. It is not for full article drafting, opinion writing, or headline optimization only.
