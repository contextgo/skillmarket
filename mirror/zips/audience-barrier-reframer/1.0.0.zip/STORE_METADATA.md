# Store Metadata

    ## Listing identity
    - **Display name:** Audience Barrier Reframer
    - **Slug:** `audience-barrier-reframer`
    - **Category:** editorial-planning
    - **Short description:** Reframe hard-to-enter topics for overseas audiences.
    - **One-line positioning:** Diagnose why a topic feels too official or abstract, then redesign the entry point, language, and explanation bridge.

    ## Suggested tags
    - `editorial-planning`
- `audience-reframing`
- `international-communication`
- `story-framing`
- `cross-cultural`
- `message-design`

    ## Best-fit queries
    - This angle feels too official. Reframe it for overseas readers.
- Identify the audience barriers in this topic and redesign the entry point.
- Give me three more audience-enterable versions of this major-theme angle.

    ## Core use cases
    - Reframe policy-heavy topics for external audiences
- Reduce abstraction and internal shorthand
- Design audience-enterable central questions

    ## README intro block
    > Audience Barrier Reframer helps editorial teams and planning agents solve one specific planning problem with repeatable structure, output patterns, and reference materials. It is best used as one module inside a larger editorial planning system.

    ## Publish notes
    - Keep this skill listed separately rather than bundling it with all six skills.
    - Use a concise changelog line such as `Initial public release` or `Improved trigger wording and examples`.
    - Keep the public listing focused on the problem it solves, not the full six-skill architecture.
    - Recommended audience: editorial strategists, newsroom innovation teams, international communication planners, and multi-agent OpenClaw builders.
