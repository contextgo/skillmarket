# Audience Barrier Reframer

Reframe abstract topics into audience-enterable story angles.

## Included files
- SKILL.md
- agents/openai.yaml
- references/
- MANIFEST.yaml
- CHANGELOG.md
- _meta.json

## Install notes
This bundle is packaged as a standard ZIP with a top-level `audience-barrier-reframer/` directory so it can be imported by skill installers that expect one skill per archive.
