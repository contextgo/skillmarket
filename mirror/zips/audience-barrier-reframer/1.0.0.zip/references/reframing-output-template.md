# Reframing Output Template

### Original Topic
Restate the original topic briefly.

### Audience Profile
Define the target audience in practical terms.

### Barrier Diagnosis
List the main barriers in order of importance.

### Likely Audience Questions
List the questions the audience is likely to ask before they can follow the story.

### Dominant Barrier
Name the single most important barrier to solve first.

### Reframed Entry Point
Give the best issue, scene, person, contradiction, or place-based entry.

### Reframed Central Question
Rewrite the topic as an issue or question the audience can enter naturally.

### Explanation Bridge
Explain how the reporting should move from the entry point to the larger theme.

### Recommended Expressions
List better wording choices for early, middle, and later parts of the piece.

### Expressions to Avoid or Delay
List phrases that should not appear early or should appear only after explanation.

### Evidence and Scene Suggestions
List the most useful kinds of evidence.

### Why This Reframing Works
Explain why the new frame improves clarity, relevance, and credibility.

### Risks and Limits
State what remains difficult or easy to mishandle.
