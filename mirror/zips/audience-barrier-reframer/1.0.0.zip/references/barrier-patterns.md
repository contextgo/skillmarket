# Barrier Patterns

## Use
Use this file to diagnose why a topic may feel correct internally but fail to travel externally.

## Major barrier types
- **Abstract-concept overload**: starts with a large concept and no concrete issue
- **Institution-centered framing**: begins from institutions rather than audience experience
- **Internal shorthand barrier**: uses terms meaningful only to insiders
- **Conclusion-first framing**: tells the audience what to conclude before showing the path
- **Low relevance barrier**: gives no reason to care
- **Evidence-thin framing**: lacks scenes, proof, and visible outcomes
- **Trust-distance barrier**: likely to trigger skepticism if explanation is too declarative
- **Comparison mismatch barrier**: invites the wrong comparisons or avoids useful ones

## Diagnosis sequence
1. What would stop the audience in the first 2 to 3 sentences?
2. Is the block meaning, relevance, trust, evidence, vocabulary, or comparison?
3. What does the audience need first: clearer issue, scene, familiar question, stronger evidence, or less coded language?
4. Choose one dominant reframing move first.

## Matching barriers to moves
- Abstract overload -> issue-first opening
- Institution-centered -> function-first explanation
- Internal shorthand -> plain-language paraphrase or delayed formal term
- Conclusion-first -> question-led entry
- Low relevance -> shared civic concern or daily-life consequence
- Evidence-thin -> one strong anchor case and one visible result
