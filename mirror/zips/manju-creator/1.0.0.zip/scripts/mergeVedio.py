#!/usr/bin/env python3
"""将 SRT 字幕烧录到视频中 - 使用 Pillow 直接渲染"""
import re
import os
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from moviepy import VideoFileClip, VideoClip, CompositeVideoClip

# 使用可用的中文字体
FONT_PATH = '/Library/Fonts/Arial Unicode.ttf'
FONT_SIZE = 28
STROKE_WIDTH = 2

def get_font():
    """获取中文字体"""
    try:
        return ImageFont.truetype(FONT_PATH, FONT_SIZE)
    except:
        # 备选字体
        for f in ['/System/Library/Fonts/STHeiti Medium.ttc',
                  '/System/Library/Fonts/Hiragino Sans GB.ttc']:
            try:
                return ImageFont.truetype(f, FONT_SIZE, index=0)
            except:
                continue
    return ImageFont.load_default()

def parse_srt(srt_path):
    """解析 SRT 字幕文件"""
    subtitles = []
    with open(srt_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    blocks = re.split(r'\n\s*\n', content.strip())
    for block in blocks:
        lines = block.strip().split('\n')
        if len(lines) < 3:
            continue
        time_match = re.match(r'(\d+:\d+:\d+[,\.]\d+)\s*-->\s*(\d+:\d+:\d+[,\.]\d+)', lines[1])
        if not time_match:
            continue
        start_str = time_match.group(1).replace(',', '.')
        end_str = time_match.group(2).replace(',', '.')
        start = timestamp_to_seconds(start_str)
        end = timestamp_to_seconds(end_str)
        text = '\n'.join(lines[2:])
        subtitles.append((start, end, text))
    
    return subtitles

def timestamp_to_seconds(ts):
    """将 HH:MM:SS.mmm 转为秒"""
    parts = ts.split(':')
    h = int(parts[0])
    m = int(parts[1])
    s = float(parts[2])
    return h * 3600 + m * 60 + s

def render_text_on_frame(frame, text, font, video_w, video_h):
    """在视频帧上渲染字幕文本"""
    # 转为 PIL Image
    img = Image.fromarray(frame)
    draw = ImageDraw.Draw(img)
    
    # 计算文本位置（底部居中）
    bbox = draw.textbbox((0, 0), text, font=font)
    text_w = bbox[2] - bbox[0]
    text_h = bbox[3] - bbox[1]
    
    x = (video_w - text_w) // 2
    y = video_h - text_h - 50  # 距底部50px
    
    # 绘制黑色描边
    for dx in range(-STROKE_WIDTH, STROKE_WIDTH + 1):
        for dy in range(-STROKE_WIDTH, STROKE_WIDTH + 1):
            if dx != 0 or dy != 0:
                draw.text((x + dx, y + dy), text, font=font, fill='black')
    
    # 绘制白色文字
    draw.text((x, y), text, font=font, fill='white')
    
    return np.array(img)

def burn_subtitles(video_path, srt_path, output_path):
    """将字幕烧录到视频"""
    print(f"处理: {os.path.basename(video_path)}")
    
    subtitles = parse_srt(srt_path)
    if not subtitles:
        print(f"  无有效字幕，跳过")
        return False
    
    print(f"  字幕条数: {len(subtitles)}")
    
    font = get_font()
    video = VideoFileClip(video_path)
    video_w, video_h = video.size
    
    def make_frame(t):
        """为每帧添加字幕"""
        frame = video.get_frame(t)
        
        # 查找当前时间对应的字幕
        current_text = None
        for start, end, text in subtitles:
            if start <= t < end:
                current_text = text
                break
        
        if current_text:
            frame = render_text_on_frame(frame, current_text, font, video_w, video_h)
        
        return frame
    
    # 创建带字幕的视频
    subtitled_video = VideoClip(make_frame, duration=video.duration)
    subtitled_video = subtitled_video.with_fps(video.fps)
    
    # 设置音频
    if video.audio is not None:
        subtitled_video = subtitled_video.with_audio(video.audio)
    
    subtitled_video.write_videofile(
        output_path,
        codec='libx264',
        audio_codec='aac',
        fps=video.fps,
        preset='fast',
        logger=None
    )
    
    video.close()
    print(f"  完成: {os.path.basename(output_path)}")
    return True

if __name__ == '__main__':
    base_dir = '/Users/danielmou/Desktop/漫剧/福威镖局穿越记'
    clips_dir = os.path.join(base_dir, 'clips')
    output_dir = os.path.join(base_dir, 'output')
    
    clips_info = [
        ('01-夜袭镖局.mp4', '01-subtitle.srt'),
        ('02-系统觉醒.mp4', '02-subtitle.srt'),
        ('03-风卷残云.mp4', '03-subtitle.srt'),
    ]
    
    subtitled_clips = []
    for video_name, srt_name in clips_info:
        video_path = os.path.join(clips_dir, video_name)
        srt_path = os.path.join(clips_dir, srt_name)
        output_name = video_name.replace('.mp4', '-sub.mp4')
        output_path = os.path.join(clips_dir, output_name)
        
        if not os.path.exists(video_path):
            print(f"视频不存在: {video_path}")
            continue
        if not os.path.exists(srt_path):
            print(f"字幕不存在: {srt_path}")
            subtitled_clips.append(video_path)
            continue
        
        success = burn_subtitles(video_path, srt_path, output_path)
        if success:
            subtitled_clips.append(output_path)
        else:
            subtitled_clips.append(video_path)
    
    # 拼接最终视频（统一分辨率为1280x720）
    if subtitled_clips:
        print("\n开始拼接最终视频...")
        # 先统一分辨率
        normalized_clips = []
        for i, clip_path in enumerate(subtitled_clips):
            norm_path = clip_path.replace('-sub.mp4', '-norm.mp4').replace('.mp4', '-norm.mp4') if '-norm' not in clip_path else clip_path
            cmd = f'ffmpeg -i "{clip_path}" -vf "scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2" -c:v libx264 -preset fast -crf 23 -c:a aac -b:a 128k -ar 44100 "{norm_path}" -y 2>/dev/null'
            os.system(cmd)
            normalized_clips.append(norm_path)
        
        # 拼接
        concat_path = os.path.join(base_dir, 'concat_sub.txt')
        with open(concat_path, 'w') as f:
            for clip_path in normalized_clips:
                f.write(f"file '{clip_path}'\n")
        
        final_output = os.path.join(output_dir, '福威镖局穿越记-final.mp4')
        cmd = f'ffmpeg -f concat -safe 0 -i "{concat_path}" -c copy "{final_output}" -y 2>/dev/null'
        os.system(cmd)
        
        # 清理
        os.remove(concat_path)
        for norm in normalized_clips:
            if '-norm' in norm and os.path.exists(norm):
                os.remove(norm)
        
        # 验证
        if os.path.exists(final_output):
            size = os.path.getsize(final_output) / (1024*1024)
            print(f"\n✅ 最终视频（含字幕）: {final_output} ({size:.1f}MB)")
        else:
            print("\n❌ 拼接失败")