# 遇事不决问Gemini

**全自动Gemini问答技能** - 让小龙虾自动操作Edge浏览器，向Gemini提问并获取答案。

## 功能

- 🚀 **完全自动化** - 不需要手动操作，小龙虾自己打开Gemini、输入问题、获取答案
- 🔄 **复用登录态** - 连接已有的Edge浏览器，不需要重新登录
- 🎯 **智能定位** - 自动找到Gemini标签页，没有就创建
- ⏱️ **智能等待** - 等待Gemini回答完成再返回结果

## 使用场景

当你遇到以下情况，可以让小龙虾去问Gemini：
- 代码写不出来，需要AI帮忙
- 不确定的问题，想听听AI的意见
- 需要快速获取信息，但不想自己打开浏览器
- 批量问题需要AI解答

## 使用方法

直接告诉小龙虾：

> "去问问Gemini：xxx问题"
> "问问Gemini怎么写这个代码"
> "让Gemini帮我看看这个问题"

小龙虾会自动：
1. 连接你的Edge浏览器
2. 打开Gemini（如果没有打开的话）
3. 输入你的问题
4. 等待回答
5. 把答案发给你

## 技术原理

- 使用Playwright连接Edge的CDP端口（9222）
- 自动定位Gemini的输入框和回答区域
- 模拟人类输入和回车发送
- 智能等待AI生成完成

## 前置要求

1. Edge浏览器需要开启CDP调试端口（9222）
2. 已登录Gemini账号

### 如何开启Edge CDP端口

**方法一：快捷方式启动（推荐）**
1. 右键Edge快捷方式 → 属性
2. 目标后面加：` --remote-debugging-port=9222 --remote-allow-origins=*`
3. 用这个快捷方式启动Edge

**方法二：命令行启动**
```powershell
& "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" --remote-debugging-port=9222 --remote-allow-origins=*
```

## 依赖

- Python 3.8+
- playwright (`pip install playwright`)
- websocket-client

## 文件结构

```
ask-gemini/
├── SKILL.md                    # 本文档
└── scripts/
    ├── gemini_cdp.py          # 主脚本（Playwright + CDP）
    ├── gemini_playwright.py   # 备用方案（需关闭Edge）
    └── ask_v2.py              # 纯CDP版本
```

## 作者

- 小龙虾 🦞
- 洋洋
- Gemini（帮忙重写了核心代码）

## 版本历史

- v1.0 (2026-04-18) - 初始版本，基于Playwright + CDP
