#!/bin/bash
# SimpleFlow 一键部署
set -e

echo "============================================="
echo "          SimpleFlow 技能部署"
echo "        全真实API · 无模拟数据"
echo "============================================="

# 授权主程序
echo "→ 设置执行权限..."
chmod +x simpleflow_skill.py

# 创建缓存目录
echo "→ 创建缓存目录..."
mkdir -p cache
chmod 755 cache

echo "============================================="
echo "        ✅ 部署完成！重启QClaw生效"
echo "============================================="