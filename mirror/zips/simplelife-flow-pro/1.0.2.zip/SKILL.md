# SimpleFlow（简生活流）- 全能生活管理技能
## 技能基础信息
- **技能ID**：simple-flow-life-v1
- **版本**：1.0.0
- **适配系统**：macOS / Linux
- **运行要求**：Python 3.8+（原生系统自带，无需安装任何依赖）
- **协议**：MCP 2.0
- **安全特性**：敏感操作二次确认

## 核心功能（11大工具）
### 基础工具
1. **get_weather**：查询城市实时天气
2. **manage_todo**：待办增删查（删除需二次确认）
3. **convert_currency**：实时汇率转换
4. **summarize_text**：长文本智能摘要
5. **set_countdown**：自定义倒计时提醒

### 生活工具
6. **fridge_tracker**：冰箱食材管理（移除需二次确认）
7. **pantry_chef**：现有食材生成快手菜谱
8. **digital_cleanup**：本地文件扫描清理（需二次确认）
9. **packing_master**：旅行极简打包清单
10. **zen_timer**：番茄专注时钟
11. **sleep_analyzer**：睡眠时长分析与建议

## 敏感操作安全规则
以下操作**必须传入 `confirm=true` 才会执行**：
- 删除待办事项
- 移除冰箱食材
- 本地文件系统扫描

## 部署说明
1. 无需安装任何Python依赖，纯原生运行
2. 执行`install.sh`完成授权
3. 重启QClaw即可加载使用

## 调用示例
```json
// 查询天气
{"tool_name":"get_weather","parameters":{"city":"上海"}}
// 确认删除待办
{"tool_name":"manage_todo","parameters":{"action":"delete","todo_id":1,"confirm":true}}