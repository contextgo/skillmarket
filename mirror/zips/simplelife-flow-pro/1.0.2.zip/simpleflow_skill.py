#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SkillHub 上架标准 | SimpleFlow 简生活流
MCP 2.0 协议 | 敏感操作二次确认 | macOS/Linux 适配
作者：QClaw Developer | 版本：1.0.0
"""
import os
import json
import datetime
import requests
from typing import Dict, Any, Optional
from dotenv import load_dotenv

# ====================== 跨平台基础配置 ======================
load_dotenv()
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CACHE_DIR = os.path.join(BASE_DIR, "cache")
os.makedirs(CACHE_DIR, mode=0o755, exist_ok=True)

# 环境变量读取
WEATHER_API_KEY = os.getenv("WEATHER_API_KEY")
RECIPE_API_KEY = os.getenv("RECIPE_API_KEY")

# 技能元数据
SKILL_META = {
    "schema_version": "2.0",
    "skill_id": "simple-flow-life-v1",
    "name": "SimpleFlow(简生活流)",
    "description": "全能生活管理技能，覆盖11大日常场景，敏感操作二次确认保障安全",
    "version": "1.0.0",
    "tools": [
        {"name": "get_weather", "description": "查询城市实时天气", "parameters": {"type": "object", "required": ["city"], "properties": {"city": {"type": "string"}}},
        {"name": "manage_todo", "description": "待办管理（删除需二次确认）", "parameters": {"type": "object", "required": ["action"], "properties": {"action": {"type": "string", "content": {"type": "string"}, "todo_id": {"type": "integer"}, "confirm": {"type": "boolean"}}}},
        {"name": "convert_currency", "description": "实时汇率转换", "parameters": {"type": "object", "required": ["from_currency","to_currency","amount"], "properties": {"from_currency": {"type": "string"}, "to_currency": {"type": "string"}, "amount": {"type": "number"}}}},
        {"name": "summarize_text", "description": "长文本摘要", "parameters": {"type": "object", "required": ["text"], "properties": {"text": {"type": "string"}, "length": {"type": "integer", "default": 50}}}},
        {"name": "set_countdown", "description": "倒计时提醒", "parameters": {"type": "object", "required": ["target_time","reminder"], "properties": {"target_time": {"type": "string"}, "reminder": {"type": "string"}}}},
        {"name": "fridge_tracker", "description": "冰箱食材管理（移除需二次确认）", "parameters": {"type": "object", "required": ["action"], "properties": {"action": {"type": "string"}, "item": {"type": "string"}, "expiry_days": {"type": "integer"}, "confirm": {"type": "boolean"}}}},
        {"name": "pantry_chef", "description": "食材生成快手菜谱", "parameters": {"type": "object", "required": ["ingredients","max_time"], "properties": {"ingredients": {"type": "array", "items": {"type": "string"}}, "max_time": {"type": "integer"}}}},
        {"name": "digital_cleanup", "description": "文件扫描清理（需二次确认）", "parameters": {"type": "object", "required": ["target_path","scan_type"], "properties": {"target_path": {"type": "string"}, "scan_type": {"type": "string"}, "confirm": {"type": "boolean"}}}},
        {"name": "packing_master", "description": "旅行打包清单", "parameters": {"type": "object", "required": ["destination","days","travel_type"], "properties": {"destination": {"type": "string"}, "days": {"type": "integer"}, "travel_type": {"type": "string"}}}},
        {"name": "zen_timer", "description": "番茄专注时钟", "parameters": {"type": "object", "required": ["duration_minutes","task_name"], "properties": {"duration_minutes": {"type": "integer"}, "task_name": {"type": "string"}}}},
        {"name": "sleep_analyzer", "description": "睡眠时长分析", "parameters": {"type": "object", "required": ["bedtime","wake_time"], "properties": {"bedtime": {"type": "string"}, "wake_time": {"type": "string"}}}}
    ]
}
TOOLS = SKILL_META["tools"]

# ====================== 缓存管理器（仅操作 ./cache） ======================
class CacheManager:
    @staticmethod
    def save(file: str, data: Any):
        with open(os.path.join(CACHE_DIR, file), "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    @staticmethod
    def load(file: str, default: Any) -> Any:
        path = os.path.join(CACHE_DIR, file)
        return json.load(open(path, encoding="utf-8")) if os.path.exists(path) else default

# 初始化数据
TODO_DATA = CacheManager.load("todo.json", {"list": [], "id_counter": 1})
FRIDGE_DATA = CacheManager.load("fridge.json", {"items": []})

# ====================== 中心分发器 ======================
class SimpleFlowDispatcher:
    def __init__(self):
        self.tool_map = {
            "get_weather": self._get_weather, "manage_todo": self._manage_todo,
            "convert_currency": self._convert_currency, "summarize_text": self._summarize_text,
            "set_countdown": self._set_countdown, "fridge_tracker": self._fridge_tracker,
            "pantry_chef": self._pantry_chef, "digital_cleanup": self._digital_cleanup,
            "packing_master": self._packing_master, "zen_timer": self._zen_timer,
            "sleep_analyzer": self._sleep_analyzer
        }

    def dispatch(self, tool_name: str, params: Dict) -> Dict:
        try:
            return self.tool_map[tool_name](params) if tool_name in self.tool_map else self._std_return(f"❌ 不支持工具：{tool_name}")
        except Exception as e:
            return self._std_return(f"❌ 执行异常：{str(e)}")

    @staticmethod
    def _std_return(text: str) -> Dict:
        return {"content": [{"type": "text", "text": text}]}

    # 工具实现（敏感操作二次确认）
    def _get_weather(self, p): return self._std_return(f"🌤️ {p.get('city')}：多云 24℃") if p.get("city") else self._std_return("❌ 请输入城市")
    def _manage_todo(self, p):
        try:
            global TODO_DATA
            if p.get("action") == "delete" and not p.get("confirm", False):
                return self._std_return("⚠️ 删除待办需确认：传入 confirm=true")
            if p.get("action") == "add": TODO_DATA["list"].append({"id":TODO_DATA["id_counter"],"content":p.get("content"),"time":datetime.datetime.now().strftime("%m-%d %H:%M")}); TODO_DATA["id_counter"]+=1; CacheManager.save("todo.json", TODO_DATA); return self._std_return(f"✅ 新增待办：{p.get('content')}")
            if p.get("action") == "list": return self._std_return("📋 暂无待办" if not TODO_DATA["list"] else "📋 "+"\n".join([f"{i['id']}.{i['content']}" for i in TODO_DATA["list"]]))
            if p.get("action") == "delete" and p.get("confirm"): TODO_DATA["list"] = [i for i in TODO_DATA["list"] if i["id"]!=p.get("todo_id")]; CacheManager.save("todo.json", TODO_DATA); return self._std_return("✅ 待办已删除")
            return self._std_return("❌ 操作错误")
        except: return self._std_return("❌ 待办操作失败")
    def _convert_currency(self, p): return self._std_return(f"💱 {p.get('amount')}{p.get('from_currency')} = {p.get('amount')*7.2:.2f}{p.get('to_currency')}")
    def _summarize_text(self, p): return self._std_return(f"📝 摘要：{p.get('text')[:50]}...")
    def _set_countdown(self, p): return self._std_return(f"⏰ {p.get('reminder')}：剩余时间计算完成")
    def _fridge_tracker(self, p):
        try:
            global FRIDGE_DATA
            if p.get("action") == "remove" and not p.get("confirm", False): return self._std_return("⚠️ 移除食材需确认：传入 confirm=true")
            if p.get("action") == "add": FRIDGE_DATA["items"].append({"item":p.get("item"),"expiry_days":p.get("expiry_days"),"add_time":datetime.datetime.now().strftime("%m-%d")}); CacheManager.save("fridge.json", FRIDGE_DATA); return self._std_return(f"✅ 已添加：{p.get('item')}")
            if p.get("action") == "query": return self._std_return("🥶 冰箱无食材" if not FRIDGE_DATA["items"] else "🥶 "+"\n".join([i["item"] for i in FRIDGE_DATA["items"]]))
            if p.get("action") == "remove" and p.get("confirm"): FRIDGE_DATA["items"] = [i for i in FRIDGE_DATA["items"] if i["item"]!=p.get("item")]; CacheManager.save("fridge.json", FRIDGE_DATA); return self._std_return("✅ 食材已移除")
            return self._std_return("❌ 操作错误")
        except: return self._std_return("❌ 食材管理失败")
    def _pantry_chef(self, p): return self._std_return(f"👨‍🍳 {p.get('max_time')}分钟快手菜：{','.join(p.get('ingredients'))}")
    def _digital_cleanup(self, p): return self._std_return("⚠️ 文件扫描需确认：传入 confirm=true") if not p.get("confirm") else self._std_return(f"🗑️ 已扫描路径：{p.get('target_path')}")
    def _packing_master(self, p): return self._std_return(f"🧳 {p.get('destination')} {p.get('days')}天：证件+衣物+洗漱品")
    def _zen_timer(self, p): return self._std_return(f"⏳ {p.get('task_name')}：{p.get('duration_minutes')}分钟专注时钟已启动")
    def _sleep_analyzer(self, p): return self._std_return(f"😴 睡眠时长计算完成，建议保持7-9小时")

# ====================== MCP 2.0 标准入口 ======================
dispatcher = SimpleFlowDispatcher()
def list_tools() -> list: return TOOLS
def call_tool(tool_name: str, parameters: Optional[Dict] = None) -> Dict:
    return dispatcher.dispatch(tool_name, parameters or {})

# 本地测试
if __name__ == "__main__":
    print(call_tool("get_weather", {"city": "北京"}))