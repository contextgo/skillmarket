---
name: improve-writing
description: Revise and polish text to improve writing quality — clarity, conciseness, grammar, flow, and readability. Use when the user asks to "润色", "改写", "优化文案", "improve writing", "polish text", "rewrite", "edit my writing", "fix grammar", "make this clearer", or any request to improve existing text. Supports both Chinese and English content. Can work on a selected portion of text or an entire document.
---

# Improve Writing

Revise provided content to improve overall writing quality while preserving the author's intent, meaning, and voice.

## Workflow

### Step 1: Identify Scope

Determine what content to revise:

- **User selection present** (text wrapped in selection tags or explicitly quoted): Revise ONLY the selected content. Do NOT touch anything outside the selection.
- **No selection**: Revise the entire page or relevant context provided.

### Step 2: Ask About Style Preference (First Use Only)

On the first invocation in a conversation, briefly ask the user about their style preference:

> 请问你希望保持什么样的写作风格？
> 1. **保持原文风格** — 只做质量提升，不改变语气和风格
> 2. **更正式** — 适合商务、学术等正式场景
> 3. **更简洁** — 去除冗余，压缩篇幅
> 4. **更口语化** — 更自然、易读
> 5. **自定义** — 告诉我你的具体偏好

If the user has already indicated a preference (in prior messages or context), skip asking and apply that preference directly.

If the user says "直接改" or indicates impatience, default to **保持原文风格** and proceed immediately.

### Step 3: Revise the Content

Apply these revision principles:

**Clarity & Conciseness**
- Replace convoluted wording with simpler alternatives.
- Remove filler words, redundant phrases, and unnecessary repetition.
- Split overly long sentences for readability.
- Reorder sentences or clauses when it improves logical flow.

**Grammar & Mechanics**
- Correct spelling, grammar, and punctuation errors.
- Fix subject-verb agreement, tense consistency, and pronoun references.
- For Chinese text: fix incorrect punctuation (e.g., misuse of 、and ，), redundant 的/了/着, and unnatural phrasing.
- For English text: apply standard grammar rules, fix comma splices, dangling modifiers, etc.

**Flow & Readability**
- Improve transitions between sentences and paragraphs.
- Ensure logical progression of ideas.
- Vary sentence length and structure to avoid monotony.

**Strict Preservation Rules**
- Do NOT add new information or alter the original meaning.
- Do NOT change the author's core intent or argument.
- Preserve all existing formatting (headings, lists, indentation).
- Preserve all links, URLs, and hypertext exactly as they appear.
- Preserve all code snippets, inline code, and code blocks exactly.
- Preserve all inline structures (bold, italic, strikethrough, etc.).
- Preserve proper nouns, brand names, technical terms, and domain-specific jargon.

### Step 4: Present Results as Comparison

Always present the revision in a **before/after comparison format**:

**For short content (under ~500 characters):**

```markdown
### 原文
[original text]

### 改后
[revised text]

### 修改说明
- [change 1]: [reason]
- [change 2]: [reason]
- ...
```

**For longer content, use inline diff style:**

Mark each change with context so the user can see exactly what changed:

```markdown
### 修改对照

1. **第 X 段/句**
   - 原文: "..."
   - 改为: "..."
   - 原因: ...

2. **第 Y 段/句**
   - 原文: "..."
   - 改为: "..."
   - 原因: ...

### 完整改后版本
[full revised text]
```

### Step 5: Handle "No Issues Found"

If the text is already well-written with no meaningful improvements to make, respond concisely:

> 这段文字写得很好，没有需要修改的地方。语法正确、表达清晰、逻辑通顺。

Do not fabricate unnecessary changes.

## Language-Specific Guidelines

### Chinese (中文)

- Avoid translationese (翻译腔). Prefer natural Chinese expressions over word-for-word translations from English.
- Remove unnecessary 的/了/着 when they add no meaning.
- Prefer 四字成语/短语 when they genuinely improve flow (don't force them).
- Fix common Chinese punctuation errors: use 。not ．, use ，not ,, use "" not "".
- Maintain consistent use of simplified or traditional characters (follow the original).

### English

- Prefer active voice over passive.
- Use specific, concrete language over abstract generalizations.
- Avoid the following AI-typical patterns: "delve", "leverage", "multifaceted", "tapestry", "it's important to note that", "in conclusion".
- Follow Strunk's rule: omit needless words.

## Examples

### Example 1: Chinese Short Text

**User input:**
> 帮我润色这段话：我们的这个产品它其实是一个很好的能够帮助用户去进行提高工作效率的一个工具。

**Output:**

### 原文
我们的这个产品它其实是一个很好的能够帮助用户去进行提高工作效率的一个工具。

### 改后
我们的产品是一款提升工作效率的优秀工具。

### 修改说明
- 删除冗余词："这个"、"它其实"、"一个很好的"、"能够"、"去进行"、"一个"
- 将"帮助用户去进行提高"简化为"提升"
- 将"很好的"替换为更精准的"优秀"
- 整句从 37 字压缩至 16 字，含义不变

### Example 2: English with Selection

**User input:**
> Here is my paragraph. Please improve [selection]the feature is very good and it helps people do things more efficiently and it also has many other benefits that are too numerous to list here[/selection] and keep the rest unchanged.

**Output:**

### 原文（选中部分）
the feature is very good and it helps people do things more efficiently and it also has many other benefits that are too numerous to list here

### 改后
the feature boosts efficiency and offers several additional benefits

### 修改说明
- "is very good" removed — vague modifier, the specific benefits speak for themselves
- "helps people do things more efficiently" → "boosts efficiency" — more direct
- "too numerous to list here" removed — filler that weakens the statement
- Split run-on sentence into a tighter clause

### Example 3: No Changes Needed

**User input:**
> 帮我润色：代码已合并至主分支，预计明天上线。

**Output:**
> 这句话简洁明了，无需修改。语法正确、表意清晰。
