---
name: network-manager
version: 1.0.0
description: 人脉管理助手
license: PROPRIETARY

slash_commands:
  /network-advice: 获取沟通建议
  /network-analyze: 分析人脉关系
  /network-reminder: 智能跟进提醒
  /network-gift: 送礼建议

capabilities:
  - communication_advice
  - network_analysis
  - follow_up_reminder
  - gift_suggestion

dependencies:
  - requests (可选，用于调用大模型 API)

---

# 人脉管理助手

基于你之前做人脉管家的完整策略，这个 Agent 提供 AI 驱动的人脉管理功能。

## 功能
1. **沟通建议**：初次接触、日常跟进、请求帮助的话术
2. **人脉分析**：人脉网络质量分析、关系亲密度评估
3. **智能提醒**：生日提醒、跟进周期提醒、节日问候
4. **送礼建议**：根据喜好和场合推荐礼物

## 依赖安装
可选安装（如需调用大模型 API）：
```bash
pip install requests
```

## 使用
```
/network-advice --name "张三" --company "腾讯" --position "产品总监" --mbti "ENTJ"
/network-advice --type followup --name "李四" --last-contact "上次聊了产品合作"
/network-analyze --contacts data.json
/network-reminder --relationship "好友" --days-since-contact 20
/network-gift --gender male --age 35 --interests "读书，登山" --budget 500
```

## 关系等级
- 密友：7 天跟进周期
- 好友：14 天跟进周期
- 熟悉：30 天跟进周期
- 认识：60 天跟进周期
- 陌生：90 天跟进周期
