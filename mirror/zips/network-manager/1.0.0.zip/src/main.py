#!/usr/bin/env python3
"""
Network Manager - 人脉管理助手
基于 6 维度人脉档案的 AI 驱动联系人管理和关系维护工具
"""

import json
import sys
import os
import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List
from pathlib import Path

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


# ========== 常量定义 ==========

# 关系等级对应的跟进周期（天）
FOLLOW_UP_CYCLES = {
    '密友': 7,
    '好友': 14,
    '熟悉': 30,
    '认识': 60,
    '陌生': 90,
}

# 关系等级说明
RELATIONSHIP_LEVELS = {
    '核心伙伴': '无话不谈，互相帮助，长期稳定',
    '重要合作': '经常联系，互相信任，愿意帮忙',
    '普通关系': '见面聊天，基本信息了解，偶尔互动',
    '保持距离': '需要谨慎对待，避免深交',
}

# 星座特点
ZODIAC_TRAITS = {
    '白羊座': {'traits': '热情冲动、爱冒险、执行力强、爱面子',
              '交流': '夸他、顺他的意，不当众怼，陪他闯',
              '合作': '借他冲劲推动事、打头阵，活跃气氛',
              '避坑': '不激惹、不泼冷水，避免他冲动迁怒'},
    '金牛座': {'traits': '踏实稳重、吃苦耐劳、固执、慢热',
              '交流': '讲事实、不催他，尊重他的节奏',
              '合作': '托付长期事、体力活，借他踏实兜底',
              '避坑': '不强迫他改变，不敷衍他的努力'},
    '双子座': {'traits': '聪明灵活、善变、爱交流、好奇心强',
              '交流': '聊新鲜事、不无聊，保持话题变化',
              '合作': '让他做沟通、创意、多变的工作',
              '避坑': '不强迫他专注一件事，不限制自由'},
    '巨蟹座': {'traits': '敏感细腻、重感情、顾家、情绪化',
              '交流': '温和共情、聊家庭和情感',
              '合作': '托付需要细心和情感投入的事',
              '避坑': '不刺激情绪，不忽视他的感受'},
    '狮子座': {'traits': '自信霸气、爱面子、领导力强、慷慨',
              '交流': '多赞美、给足面子，当他面夸他',
              '合作': '让他当领导，负责核心决策',
              '避坑': '不当众反驳，不忽视他的存在'},
    '处女座': {'traits': '追求完美、注重细节、挑剔、分析力强',
              '交流': '讲细节、逻辑清晰，不敷衍',
              '合作': '让他做品控、分析、优化工作',
              '避坑': '不马虎，不让他做粗糙的事'},
    '天秤座': {'traits': '温和优雅、爱和平、犹豫、社交能力强',
              '交流': '温和有礼，不让他做选择',
              '合作': '让他做协调、公关、美学工作',
              '避坑': '不逼他站队，不制造冲突'},
    '天蝎座': {'traits': '神秘深刻、洞察力强、记仇、专一',
              '交流': '真诚深入，不 superficial，不欺骗',
              '合作': '让他做研究、侦查、核心机密工作',
              '避坑': '不背叛，不试探底线'},
    '射手座': {'traits': '乐观自由、爱旅行、直接、讨厌束缚',
              '交流': '聊旅行、哲学、未来，不约束他',
              '合作': '让他做拓展、探索、对外工作',
              '避坑': '不限制自由，不强迫他守规矩'},
    '摩羯座': {'traits': '务实稳重、事业心强、传统、耐心',
              '交流': '聊事业、规划，展现上进心',
              '合作': '让他做长期规划、管理、执行',
              '避坑': '不画大饼，不轻视他的努力'},
    '水瓶座': {'traits': '独立创新、理性、另类、博爱',
              '交流': '聊创新、科技、独特想法',
              '合作': '让他做创新、研发、战略规划',
              '避坑': '不强迫他合群，不用传统束缚他'},
    '双鱼座': {'traits': '浪漫敏感、艺术气质、逃避、共情强',
              '交流': '温和浪漫，聊艺术、情感、梦想',
              '合作': '让他做创意、艺术、关怀工作',
              '避坑': '不打击幻想，不强迫面对现实'},
}

# 属相特点
CHINESE_ZODIAC_TRAITS = {
    '鼠': {'traits': '聪明机灵、善于交际、适应力强',
          '交流': '聊机会、人脉、新鲜事物',
          '合作': '让他做公关、市场、对外联络'},
    '牛': {'traits': '踏实勤恳、任劳任怨、固执',
          '交流': '讲事实，尊重他的节奏',
          '合作': '托付需要耐心和毅力的事'},
    '虎': {'traits': '勇敢霸气、领导力强、冲动',
          '交流': '给足面子，让他做决定',
          '合作': '让他当领导，负责开拓'},
    '兔': {'traits': '温和谨慎、人缘好、优雅',
          '交流': '温和有礼，不制造冲突',
          '合作': '让他做协调、公关工作'},
    '龙': {'traits': '自信霸气、事业心强、完美主义',
          '交流': '多赞美，聊事业和理想',
          '合作': '让他做核心决策和领导'},
    '蛇': {'traits': '冷静睿智、洞察力强、神秘',
          '交流': '深入交流，展现你的深度',
          '合作': '让他做研究、分析、规划'},
    '马': {'traits': '自由奔放、积极行动、讨厌束缚',
          '交流': '聊旅行、冒险、未来计划',
          '合作': '让他做拓展、对外工作'},
    '羊': {'traits': '温和善良、有艺术气质、依赖',
          '交流': '温和关怀，聊艺术和生活',
          '合作': '让他做关怀、创意工作'},
    '猴': {'traits': '聪明灵活、爱开玩笑、善变',
          '交流': '聊有趣的事，保持新鲜感',
          '合作': '让他做创意、沟通工作'},
    '鸡': {'traits': '勤奋守时、注重形象、爱表现',
          '交流': '多赞美，聊形象和成就',
          '合作': '让他做展示、管理工作'},
    '狗': {'traits': '忠诚可靠、正义感强、固执',
          '交流': '真诚直接，讲信用',
          '合作': '托付需要信任和忠诚的事'},
    '猪': {'traits': '随和善良、乐观、享受当下',
          '交流': '轻松愉快，聊生活享受',
          '合作': '让他做协调、服务性工作'},
}

# 地域特点
REGION_TRAITS = {
    '东北': {'traits': '豪爽热情、能言善辩、爱热闹、讲义气',
            '交流': '陪他唠嗑、不较真，讲情义，爱热闹',
            '合作': '借他热情拉人脉、活跃气氛，组队做事',
            '避坑': '不扫他的兴、不抠门，真诚讲义气'},
    '北京': {'traits': '大气、能侃、讲规矩、爱面子',
            '交流': '聊大局、讲规矩，给足面子',
            '合作': '让他做对外、公关、统筹'},
    '上海': {'traits': '精致、讲效率、重契约、有边界感',
            '交流': '讲效率、守信用，保持专业',
            '合作': '让他做精细、专业、对外工作'},
    '广东': {'traits': '务实、低调、讲意头、会做生意',
            '交流': '聊生意、务实不浮夸，讲实际利益',
            '合作': '让他做商业、贸易、落地执行'},
    '江浙': {'traits': '精明、会算计、重教育、低调务实',
            '交流': '讲利益、展现你的价值',
            '合作': '让他做商业规划、资源对接'},
    '四川': {'traits': '乐观悠闲、爱吃辣、会享受、能摆龙门阵',
            '交流': '陪他摆龙门阵、聊美食、享受生活',
            '合作': '让他做协调、服务、创意工作'},
    '湖南': {'traits': '热情直爽、能吃苦、霸蛮、讲义气',
            '交流': '直来直去，讲情义',
            '合作': '让他做开拓、执行、攻坚'},
    '福建': {'traits': '会做生意、宗族观念强、敢拼',
            '交流': '聊生意、讲宗族情谊',
            '合作': '让他做商业、贸易、对外'},
}

# MBTI 特点
MBTI_TRAITS = {
    'INTJ': {'traits': '独立寡言、理性极强、目光长远、讨厌无效社交',
            '交流': '只讲逻辑和结果，不啰嗦、不情绪化、不套近乎',
            '合作': '让他做战略规划、难题攻坚、技术核心、长期布局',
            '避坑': '别用情绪绑架，别敷衍方案，别强迫他社交'},
    'INTP': {'traits': '逻辑分析、好奇心强、独立思考',
            '交流': '聊理论、知识、科技',
            '合作': '让他做研究、分析、技术攻坚'},
    'ENTJ': {'traits': '领导力强、果断、目标导向',
            '交流': '讲效率和结果，直接说重点',
            '合作': '让他做决策、领导、统筹'},
    'ENTP': {'traits': '聪明好奇、喜欢辩论、点子多',
            '交流': '聊新点子、辩论、商业机会',
            '合作': '让他做创意、开拓、对外'},
    'INFJ': {'traits': '温和深入、注重共情、理想主义',
            '交流': '深度交流，聊人生意义和价值观',
            '合作': '让他做关怀、指导、创意工作'},
    'INFP': {'traits': '理想主义、富有同情心、内心丰富',
            '交流': '聊个人成长、艺术、人文关怀',
            '合作': '让他做创意、写作、关怀工作'},
    'ENFJ': {'traits': '魅力领导、关心他人、善于激励',
            '交流': '聊团队发展、人际关系、社会影响',
            '合作': '让他做团队管理、培训、公关'},
    'ENFP': {'traits': '热情创意、喜欢新想法、爱创业',
            '交流': '聊新想法、创业机会、创意灵感',
            '合作': '让他做创意、开拓、对外'},
    'ISTJ': {'traits': '严谨负责、注重细节、传统',
            '交流': '聊专业知识、经验交流、品质生活',
            '合作': '让他做品控、执行、管理工作'},
    'ISFJ': {'traits': '细心负责、忠诚可靠、关心他人',
            '交流': '聊家人朋友、健康生活、实用建议',
            '合作': '让他做服务、关怀、执行工作'},
    'ESTJ': {'traits': '务实高效、组织能力强',
            '交流': '聊工作效率、管理方法、实务操作',
            '合作': '让他做管理、执行、统筹'},
    'ESFJ': {'traits': '热心助人、重视和谐、社交能力强',
            '交流': '聊家庭生活、社交活动、传统价值',
            '合作': '让他做协调、服务、公关'},
    'ISTP': {'traits': '冷静理性、动手能力强',
            '交流': '聊技术操作、机械电子、户外运动',
            '合作': '让他做技术、操作、执行'},
    'ISFP': {'traits': '温和敏感、有艺术天赋',
            '交流': '聊艺术美学、个人体验、自然环境',
            '合作': '让他做创意、艺术、设计'},
    'ESTP': {'traits': '冒险刺激、行动力强',
            '交流': '聊运动竞技、商业机会、实用技巧',
            '合作': '让他做开拓、销售、执行'},
    'ESFP': {'traits': '活泼开朗、享受当下',
            '交流': '聊娱乐活动、美食旅行、时尚潮流',
            '合作': '让他做活动、公关、展示'},
}

# 内置节日（公历）
FESTIVALS = {
    '01-01': '元旦',
    '02-14': '情人节',
    '03-08': '妇女节',
    '04-04': '清明节',
    '05-01': '劳动节',
    '06-01': '儿童节',
    '09-10': '教师节',
    '10-01': '国庆节',
    '12-25': '圣诞节',
}


# ========== 核心功能类 ==========

class NetworkManager:
    """人脉管理助手 - 基于 6 维度档案"""

    def __init__(self, ollama_url: str = None):
        self.ollama_url = ollama_url or os.environ.get('OLLAMA_URL', '')

    def get_contact_profile(self, contact: Dict) -> Dict[str, Any]:
        """获取联系人档案分析（6 维度）"""

        profile = {
            '基础信息': self._analyze_base_info(contact),
            '人格与人品': self._analyze_personality(contact),
            '能力与喜好': self._analyze_ability_preferences(contact),
            '沟通指南': self._analyze_communication(contact),
            '关系网络': self._analyze_network_relations(contact),
            '关系策略': self._analyze_relationship_strategy(contact),
        }
        return profile

    def _analyze_base_info(self, contact: Dict) -> Dict:
        """分析基础信息"""
        result = {}

        # 星座分析
        if contact.get('星座'):
            zodiac = contact['星座']
            result['星座分析'] = ZODIAC_TRAITS.get(zodiac, {})

        # 属相分析
        if contact.get('属相'):
            zodiac_cn = contact['属相']
            result['属相分析'] = CHINESE_ZODIAC_TRAITS.get(zodiac_cn, {})

        # 家乡分析
        if contact.get('家乡区域'):
            region = contact['家乡区域']
            for key in REGION_TRAITS:
                if key in region:
                    result['地域分析'] = REGION_TRAITS[key]
                    break

        # MBTI 分析
        if contact.get('MBTI'):
            mbti = contact['MBTI']
            result['MBTI 分析'] = MBTI_TRAITS.get(mbti, {})

        return result

    def _analyze_personality(self, contact: Dict) -> Dict:
        """分析人格与人品"""
        return {
            '核心特质': contact.get('核心特质', []),
            '情绪特点': contact.get('情绪特点', {}),
            '人品底线': contact.get('人品底线', []),
        }

    def _analyze_ability_preferences(self, contact: Dict) -> Dict:
        """分析能力与喜好"""
        return {
            '能力亮点': contact.get('能力亮点', ''),
            '喜好清单': {
                '食物': contact.get('喜好_食物', ''),
                '兴趣': contact.get('喜好_兴趣', ''),
                '偶像': contact.get('喜好_偶像', ''),
                '礼物': contact.get('喜好_礼物', ''),
            },
            '绝对雷区': contact.get('绝对雷区', []),
        }

    def _analyze_communication(self, contact: Dict) -> Dict:
        """分析沟通指南"""
        # 综合星座、MBTI、地域等给出沟通建议
        base_traits = self._analyze_base_info(contact)

        communication = {
            '沟通风格': contact.get('沟通风格', '自然友好'),
            '最佳开场': contact.get('最佳开场', '你好，最近怎么样？'),
            '激励方式': contact.get('激励方式', ['认可', '表扬']),
            '劝阻方式': contact.get('劝阻方式', '温和沟通'),
        }

        # 整合各维度的交流建议
        tips = []
        if '星座分析' in base_traits:
            tips.append(base_traits['星座分析'].get('交流', ''))
        if 'MBTI 分析' in base_traits:
            tips.append(base_traits['MBTI 分析'].get('交流', ''))
        if '地域分析' in base_traits:
            tips.append(base_traits['地域分析'].get('交流', ''))

        communication['综合建议'] = [t for t in tips if t]
        return communication

    def _analyze_network_relations(self, contact: Dict) -> Dict:
        """分析关系网络"""
        return {
            '核心盟友': contact.get('核心盟友', []),
            '潜在对手': contact.get('潜在对手', []),
            '关键影响者': contact.get('关键影响者', []),
        }

    def _analyze_relationship_strategy(self, contact: Dict) -> Dict:
        """分析关系策略"""
        return {
            '关系定位': contact.get('关系定位', '普通关系'),
            '相处原则': contact.get('相处原则', '真诚对待'),
            '共同点': contact.get('共同点', []),
            '差异点': contact.get('差异点', []),
            '行动清单': contact.get('行动清单', []),
        }

    def get_communication_advice(self, contact: Dict, scene: str = '初次联系') -> Dict:
        """获取沟通建议"""

        # 输入验证
        if not contact.get('name'):
            logger.warning("联系人姓名为空")
            return {'error': '联系人姓名不能为空'}

        logger.info(f"生成 {contact['name']} 的沟通建议，场景：{scene}")
        profile = self.get_contact_profile(contact)
        communication = profile['沟通指南']

        # 综合建议
        advice = {
            'scene': scene,
            'name': contact.get('name', '对方'),
            '沟通风格': communication.get('沟通风格', '自然友好'),
            '最佳开场': communication.get('最佳开场', '你好，最近怎么样？'),
            '推荐话题': self._get_topics(contact),
            '激励方式': communication.get('激励方式', []),
            '注意事项': [],
            '避坑指南': [],
        }

        # 收集避坑建议
        for key in ['星座分析', '属相分析', '地域分析', 'MBTI 分析']:
            if key in profile['基础信息']:
                pitfall = profile['基础信息'][key].get('避坑', '')
                if pitfall:
                    advice['避坑指南'].append(pitfall)

        # 收集注意事项
        if contact.get('绝对雷区'):
            advice['注意事项'].extend(contact['绝对雷区'])
        if contact.get('情绪特点', {}).get('易怒点'):
            advice['注意事项'].append(f"避免触发：{contact['情绪特点']['易怒点']}")

        return advice

    def _get_topics(self, contact: Dict) -> List[str]:
        """获取推荐话题"""
        topics = []

        # 根据 MBTI 推荐
        if contact.get('MBTI') and contact['MBTI'] in MBTI_TRAITS:
            topics.extend(MBTI_TRAITS[contact['MBTI']].get('交流', '').split('、')[:2])

        # 根据喜好推荐
        if contact.get('喜好_兴趣'):
            topics.append(f"对方兴趣：{contact['喜好_兴趣']}")
        if contact.get('喜好_偶像'):
            topics.append(f"对方偶像：{contact['喜好_偶像']}")

        # 默认话题
        if not topics:
            topics = ['工作近况', '行业动态', '共同兴趣']

        return topics

    def get_follow_up_reminder(self, contact: Dict) -> Dict:
        """获取跟进提醒"""

        # 输入验证
        if not contact:
            return {'error': '联系人数据为空'}

        relationship = contact.get('关系定位', '普通关系')
        days_since = contact.get('days_since_contact', 0)
        logger.info(f"生成跟进提醒：{contact.get('name', '未知')}，关系：{relationship}，未联系：{days_since}天")

        # 关系等级映射
        level_map = {
            '核心伙伴': '密友',
            '重要合作': '好友',
            '普通关系': '熟悉',
            '保持距离': '陌生',
        }
        level = level_map.get(relationship, '认识')
        cycle = FOLLOW_UP_CYCLES.get(level, 30)

        days_overdue = days_since - cycle

        if days_overdue >= 7:
            status = 'urgent'
            message = f"🚨 急需联系 {contact.get('name', '对方')}"
            detail = f"已逾期{days_overdue}天，关系可能疏远"
        elif days_overdue >= 0:
            status = 'overdue'
            message = f"📞 该联系{contact.get('name', '对方')}了"
            detail = f"已逾期{days_overdue}天，建议尽快联系"
        elif days_overdue >= -7:
            status = 'upcoming'
            message = f"⏰ 即将联系{contact.get('name', '对方')}"
            detail = f"还有{abs(days_overdue)}天到跟进周期"
        else:
            status = 'ok'
            message = f"✅ {contact.get('name', '对方')}关系维护良好"
            detail = f"下次建议联系时间：{cycle}天周期内"

        return {
            'status': status,
            'message': message,
            'detail': detail,
            'cycle': cycle,
            'suggestion': self._get_follow_suggestion(level),
            'conversation_starters': self._get_conversation_starters(contact),
        }

    def _get_follow_suggestion(self, level: str) -> List[str]:
        """获取跟进方式建议"""
        suggestions = {
            '密友': ['约饭聊天', '深度交流', '互相帮助', '分享生活'],
            '好友': ['微信问候', '分享有趣内容', '约咖啡', '行业交流'],
            '熟悉': ['点赞互动', '节日问候', '简单聊天', '分享资讯'],
            '认识': ['微信好友', '简单问候', '交换名片'],
            '陌生': ['自我介绍', '表达合作意向'],
        }
        return suggestions.get(level, ['保持联系'])

    def _get_conversation_starters(self, contact: Dict) -> List[str]:
        """获取开场白建议"""
        name = contact.get('name', '对方')
        starters = []

        # 根据喜好生成
        if contact.get('喜好_兴趣'):
            starters.append(f"最近看到你分享的{contact['喜好_兴趣']}相关内容，很有意思！")

        # 根据 MBTI 生成
        if contact.get('MBTI') in ['ENTJ', 'ESTJ', 'INTJ']:
            starters.append(f"{name}，最近工作上有什么新进展吗？")
        elif contact.get('MBTI') in ['ENFP', 'ESFP', 'INFP']:
            starters.append(f"嘿{name}，最近有什么好玩的事分享吗？")

        # 默认开场
        if not starters:
            starters = [
                f"好久不见，{name}最近怎么样？",
                f"看到一条信息想到你，分享给你看看",
            ]

        return starters

    def get_gift_suggestion(self, contact: Dict, occasion: str = '生日', budget: int = 500) -> Dict:
        """获取送礼建议"""

        suggestions = []

        # 根据喜好推荐
        if contact.get('喜好_礼物'):
            suggestions.append({
                'name': f"对方喜欢的：{contact['喜好_礼物']}",
                'price': f"{budget}元以内",
                'reason': '符合对方喜好',
                'category': '个人喜好'
            })

        # 根据兴趣推荐
        if contact.get('喜好_兴趣'):
            interest = contact['喜好_兴趣']
            suggestions.append({
                'name': f"{interest}相关礼品",
                'price': f"200-{budget}元",
                'reason': f'符合对方兴趣：{interest}',
                'category': '兴趣爱好'
            })

        # 根据食物推荐
        if contact.get('喜好_食物'):
            food = contact['喜好_食物']
            suggestions.append({
                'name': f"特色食品礼盒：{food}",
                'price': f"100-{budget//2}元",
                'reason': '民以食为天，分享美食',
                'category': '食品'
            })

        # 通用推荐
        if len(suggestions) < 3:
            suggestions.extend([
                {'name': '定制礼品（刻字/印名字）', 'price': f"200-{budget}元", 'reason': '体现用心', 'category': '定制'},
                {'name': '品质书籍', 'price': f"100-300 元", 'reason': '提升自我', 'category': '文化'},
                {'name': '科技配件', 'price': f"300-{budget}元", 'reason': '实用性强', 'category': '数码'},
            ])

        return {
            'occasion': occasion,
            'budget': budget,
            'suggestions': suggestions[:5],
            'tips': '礼物在于心意，不在于价格。最好与对方兴趣相关，避免触碰雷区。',
            'avoid': contact.get('绝对雷区', []),
        }

    def analyze_network_quality(self, contacts: List[Dict]) -> Dict:
        """分析人脉网络质量"""

        total = len(contacts)
        logger.info(f"分析人脉网络，总人数：{total}")

        if total == 0:
            logger.warning("联系人数据为空")
            return {'error': '没有联系人数据'}

        # 关系等级分布
        relationship_dist = {}
        for c in contacts:
            level = c.get('关系定位', '普通关系')
            relationship_dist[level] = relationship_dist.get(level, 0) + 1

        # 计算评分
        score = self._calculate_network_score(contacts, relationship_dist)

        # 生成报告
        core_count = relationship_dist.get('核心伙伴', 0) + relationship_dist.get('重要合作', 0)
        core_ratio = core_count / total if total > 0 else 0

        if score >= 80:
            level = '优秀'
        elif score >= 60:
            level = '良好'
        elif score >= 40:
            level = '一般'
        else:
            level = '待提升'

        return {
            'score': score,
            'level': level,
            'analysis': {
                'total': total,
                'core_relations': core_count,
                'core_ratio': f"{core_ratio:.1%}",
                'relationship_distribution': relationship_dist,
            },
            'suggestions': self._generate_network_suggestions(relationship_dist),
        }

    def _calculate_network_score(self, contacts: List[Dict], relationship_dist: Dict) -> int:
        """计算人脉质量评分"""

        total = len(contacts)

        # 关系质量分（50 分）
        core_count = relationship_dist.get('核心伙伴', 0) + relationship_dist.get('重要合作', 0)
        close_ratio = core_count / total if total > 0 else 0
        relationship_score = min(50, close_ratio * 100)

        # 人脉总数分（30 分）- 50 人以上满分
        total_score = min(30, total * 0.6)

        # 多样性分（20 分）- 假设有行业/地域分布
        industries = set(c.get('行业', '') for c in contacts if c.get('行业'))
        diversity_score = min(20, len(industries) * 2)

        return int(relationship_score + total_score + diversity_score)

    def _generate_network_suggestions(self, relationship_dist: Dict) -> List[str]:
        """生成人脉发展建议"""

        suggestions = []

        # 核心关系不足
        core_count = relationship_dist.get('核心伙伴', 0) + relationship_dist.get('重要合作', 0)
        total = sum(relationship_dist.values())
        if total > 0 and core_count / total < 0.2:
            suggestions.append('核心关系比例偏低，建议深化 2-3 段重要关系')

        # 总数不足
        if total < 20:
            suggestions.append('人脉总数偏少，建议多参加社交活动拓展人脉')
        elif total > 200:
            suggestions.append('人脉总数充足，建议聚焦核心关系维护')

        # 保持距离的人太多
        if relationship_dist.get('保持距离', 0) > total * 0.3:
            suggestions.append('需要保持距离的人偏多，建议简化社交圈')

        if not suggestions:
            suggestions.append('人脉结构健康，继续保持')

        return suggestions

    def get_birthday_reminder(self, contacts: List[Dict], days_ahead: int = 7) -> List[Dict]:
        """获取生日提醒"""

        today = datetime.now()
        reminders = []

        for contact in contacts:
            birthday_str = contact.get('生日')
            if not birthday_str:
                continue

            try:
                # 解析生日（格式：YYYY-MM-DD 或 MM-DD 或 农历）
                if len(birthday_str) == 10 and '-' in birthday_str:
                    parts = birthday_str.split('-')
                    month, day = int(parts[1]), int(parts[2])
                elif '-' in birthday_str:
                    parts = birthday_str.split('-')
                    month, day = int(parts[0]), int(parts[1])
                else:
                    continue

                # 今年生日
                this_year_birthday = datetime(today.year, month, day)
                if this_year_birthday < today:
                    this_year_birthday = datetime(today.year + 1, month, day)

                days_left = (this_year_birthday - today).days

                if 0 <= days_left <= days_ahead:
                    if days_left == 0:
                        reminders.append({
                            'type': 'birthday',
                            'priority': 'high',
                            'name': contact.get('name', '未知'),
                            'message': f"🎂 {contact.get('name', '未知')}今天生日！",
                            'action': '发送生日祝福，准备礼物',
                            'gift_suggestion': contact.get('喜好_礼物', '根据兴趣选择')
                        })
                    else:
                        reminders.append({
                            'type': 'birthday',
                            'priority': 'medium',
                            'name': contact.get('name', '未知'),
                            'message': f"🎂 {contact.get('name', '未知')}生日将至",
                            'detail': f"还有{days_left}天",
                            'action': '准备生日礼物和祝福',
                            'gift_suggestion': contact.get('喜好_礼物', '根据兴趣选择')
                        })
            except (ValueError, IndexError):
                continue

        return reminders

    def get_festival_reminder(self, contacts: List[Dict], days_ahead: int = 7) -> List[Dict]:
        """获取节日提醒"""

        today = datetime.now()
        reminders = []

        for date_str, festival_name in FESTIVALS.items():
            month, day = map(int, date_str.split('-'))
            festival_date = datetime(today.year, month, day)

            if festival_date < today:
                festival_date = datetime(today.year + 1, month, day)

            days_left = (festival_date - today).days

            if 0 <= days_left <= days_ahead:
                priority = 'high' if days_left == 0 else 'medium'
                reminders.append({
                    'type': 'festival',
                    'priority': priority,
                    'name': festival_name,
                    'message': f"🎉 {festival_name}{'到了' if days_left == 0 else f'还有{days_left}天'}",
                    'action': '发送节日祝福，准备礼物',
                    'contacts_to_greet': [c.get('name') for c in contacts[:5]]  # 提醒联系核心人脉
                })

        return reminders


# ========== CLI 入口 ==========

class_colors = {
    'reset': '\033[0m',
    'red': '\033[91m',
    'green': '\033[92m',
    'yellow': '\033[93m',
    'blue': '\033[94m',
    'magenta': '\033[95m',
    'cyan': '\033[96m',
}

def print_colored(text: str, color: str = 'reset'):
    """打印彩色文本"""
    color_code = class_colors.get(color, '')
    reset = class_colors.get('reset', '')
    print(f"{color_code}{text}{reset}")


def main():
    import argparse

    parser = argparse.ArgumentParser(description='人脉管理助手 - 基于 6 维度档案')
    subparsers = parser.add_subparsers(dest='action')

    # profile 命令 - 档案分析
    profile_parser = subparsers.add_parser('profile', help='分析联系人档案（6 维度）')
    profile_parser.add_argument('--name', '-n', required=True, help='联系人姓名')
    profile_parser.add_argument('--mbti', '-m', help='MBTI 人格类型')
    profile_parser.add_argument('--zodiac', '-z', help='星座')
    profile_parser.add_argument('--chinese-zodiac', '-c', help='属相')
    profile_parser.add_argument('--region', '-r', help='家乡区域')
    profile_parser.add_argument('--file', '-f', help='联系人数据文件（JSON）')

    # advice 命令 - 沟通建议
    advice_parser = subparsers.add_parser('advice', help='获取沟通建议')
    advice_parser.add_argument('--name', '-n', required=True, help='联系人姓名')
    advice_parser.add_argument('--mbti', '-m', help='MBTI 人格类型')
    advice_parser.add_argument('--scene', '-s', default='初次联系', help='联系场景')
    advice_parser.add_argument('--file', '-f', help='联系人数据文件（JSON）')

    # reminder 命令 - 跟进提醒
    reminder_parser = subparsers.add_parser('reminder', help='跟进提醒')
    reminder_parser.add_argument('--name', '-n', help='联系人姓名')
    reminder_parser.add_argument('--relationship', '-r', help='关系定位')
    reminder_parser.add_argument('--days', '-d', type=int, default=0, help='距离上次联系天数')
    reminder_parser.add_argument('--file', '-f', help='联系人数据文件（JSON）')

    # gift 命令 - 送礼建议
    gift_parser = subparsers.add_parser('gift', help='送礼建议')
    gift_parser.add_argument('--name', '-n', help='联系人姓名')
    gift_parser.add_argument('--interest', '-i', help='兴趣爱好')
    gift_parser.add_argument('--gift-pref', help='礼物偏好')
    gift_parser.add_argument('--age', type=int, default=30, help='年龄')
    gift_parser.add_argument('--occasion', '-o', default='生日', help='场合')
    gift_parser.add_argument('--budget', '-b', type=int, default=500, help='预算（元）')
    gift_parser.add_argument('--file', '-f', help='联系人数据文件（JSON）')

    # analyze 命令 - 人脉分析
    analyze_parser = subparsers.add_parser('analyze', help='人脉网络分析')
    analyze_parser.add_argument('--file', '-f', required=True, help='联系人数据文件（JSON）')

    # birthday 命令 - 生日提醒
    birthday_parser = subparsers.add_parser('birthday', help='生日提醒')
    birthday_parser.add_argument('--file', '-f', required=True, help='联系人数据文件（JSON）')
    birthday_parser.add_argument('--days', '-d', type=int, default=7, help='提前多少天提醒')

    args = parser.parse_args()

    manager = NetworkManager()

    # 加载联系人数据
    def load_contact(file_path: str, name_filter: str = None) -> Dict:
        with open(file_path, 'r', encoding='utf-8') as f:
            contacts = json.load(f)
        if name_filter:
            for c in contacts:
                if c.get('name') == name_filter:
                    return c
            return {}
        return contacts if isinstance(contacts, list) else contacts

    if args.action == 'profile':
        if args.file:
            contact = load_contact(args.file, args.name)
        else:
            contact = {
                'name': args.name,
                'MBTI': args.mbti,
                '星座': args.zodiac,
                '属相': args.chinese_zodiac,
                '家乡区域': args.region,
            }

        profile = manager.get_contact_profile(contact)

        print(f"\n📋 人脉档案 - {args.name}")
        print("=" * 60)

        print("\n【一、基础信息】")
        if '星座分析' in profile['基础信息']:
            print(f"  星座：{args.zodiac or '未填写'}")
            print(f"    特点：{profile['基础信息']['星座分析'].get('traits', '')}")
        if 'MBTI 分析' in profile['基础信息']:
            print(f"  MBTI: {args.mbti or '未填写'}")
            print(f"    特点：{profile['基础信息']['MBTI 分析'].get('traits', '')}")
        if '地域分析' in profile['基础信息']:
            print(f"  家乡：{args.region or '未填写'}")
            print(f"    特点：{profile['基础信息']['地域分析'].get('traits', '')}")

        print("\n【二、人格与人品】")
        print(f"  核心特质：{profile['人格与人品'].get('核心特质', '待补充')}")
        print(f"  情绪特点：{profile['人格与人品'].get('情绪特点', '待补充')}")
        print(f"  人品底线：{profile['人格与人品'].get('人品底线', '待补充')}")

        print("\n【三、能力与喜好】")
        print(f"  能力亮点：{profile['能力与喜好'].get('能力亮点', '待补充')}")
        print(f"  喜好：{profile['能力与喜好'].get('喜好清单', '待补充')}")
        print(f"  雷区：{profile['能力与喜好'].get('绝对雷区', '待补充')}")

        print("\n【四、沟通指南】")
        print(f"  沟通风格：{profile['沟通指南'].get('沟通风格', '自然友好')}")
        print(f"  最佳开场：{profile['沟通指南'].get('最佳开场', '你好')}")
        print(f"  综合建议：{profile['沟通指南'].get('综合建议', [])}")

        print("\n【五、关系网络】")
        print(f"  核心盟友：{profile['关系网络'].get('核心盟友', '待补充')}")
        print(f"  潜在对手：{profile['关系网络'].get('潜在对手', '待补充')}")
        print(f"  关键影响者：{profile['关系网络'].get('关键影响者', '待补充')}")

        print("\n【六、关系策略】")
        print(f"  关系定位：{profile['关系策略'].get('关系定位', '普通关系')}")
        print(f"  相处原则：{profile['关系策略'].get('相处原则', '真诚对待')}")
        print(f"  行动清单：{profile['关系策略'].get('行动清单', '待补充')}")

        print("=" * 60)

    elif args.action == 'advice':
        if args.file:
            contact = load_contact(args.file, args.name)
        else:
            contact = {
                'name': args.name,
                'MBTI': args.mbti,
            }

        advice = manager.get_communication_advice(contact, args.scene)

        print(f"\n💡 沟通建议 - {args.name}")
        print(f"场景：{args.scene}")
        print("=" * 50)
        print(f"\n沟通风格：{advice.get('沟通风格', '自然友好')}")
        print(f"\n最佳开场:")
        print(f"  \"{advice.get('最佳开场', '你好，最近怎么样？')}\"")
        print(f"\n推荐话题:")
        for topic in advice.get('推荐话题', []):
            print(f"  • {topic}")
        if advice.get('激励方式'):
            print(f"\n激励方式:")
            for method in advice['激励方式']:
                print(f"  ✓ {method}")
        if advice.get('避坑指南'):
            print(f"\n避坑指南:")
            for tip in advice['避坑指南']:
                print(f"  ✕ {tip}")
        if advice.get('注意事项'):
            print(f"\n注意事项:")
            for note in advice['注意事项']:
                print(f"  ⚠ {note}")
        print("=" * 50)

    elif args.action == 'reminder':
        if args.file:
            contact = load_contact(args.file, args.name)
        else:
            contact = {
                'name': args.name,
                '关系定位': args.relationship or '普通关系',
                'days_since_contact': args.days,
            }

        result = manager.get_follow_up_reminder(contact)

        print(f"\n📋 跟进提醒")
        print("=" * 50)
        if args.name:
            print(f"联系人：{args.name}")
        print(f"关系定位：{args.relationship or contact.get('关系定位', '普通关系')}")
        print(f"建议周期：{result.get('cycle', 30)}天")
        print(f"状态：{result.get('message', '')}")
        print(f"详情：{result.get('detail', '')}")
        print(f"\n建议方式:")
        for suggestion in result.get('suggestion', []):
            print(f"  • {suggestion}")
        print(f"\n开场白建议:")
        for starter in result.get('conversation_starters', []):
            print(f"  \"{starter}\"")
        print("=" * 50)

    elif args.action == 'gift':
        if args.file:
            contact = load_contact(args.file, args.name)
        else:
            contact = {
                'name': args.name,
                '喜好_兴趣': args.interest,
                '喜好_礼物': args.gift_pref,
            }

        result = manager.get_gift_suggestion(contact, args.occasion, args.budget)

        print(f"\n🎁 送礼建议")
        print("=" * 50)
        if args.name:
            print(f"收礼人：{args.name}")
        print(f"场合：{args.occasion} | 预算：{args.budget}元")
        print(f"\n推荐礼物:")
        for i, gift in enumerate(result.get('suggestions', []), 1):
            print(f"\n  {i}. {gift.get('name', '礼品')}")
            print(f"     价格：{gift.get('price', '面议')}")
            print(f"     类别：{gift.get('category', '')}")
            print(f"     理由：{gift.get('reason', '')}")
        print(f"\n💡 送礼贴士：{result.get('tips', '')}")
        if result.get('avoid'):
            print(f"\n⚠ 避免：{', '.join(result['avoid'])}")
        print("=" * 50)

    elif args.action == 'analyze':
        contacts = load_contact(args.file)
        if not isinstance(contacts, list):
            contacts = [contacts]

        result = manager.analyze_network_quality(contacts)

        print(f"\n📊 人脉分析报告")
        print("=" * 50)
        print(f"总人数：{result.get('analysis', {}).get('total', 0)}")
        print(f"核心关系：{result.get('analysis', {}).get('core_relations', 0)} ({result.get('analysis', {}).get('core_ratio', '0%')})")
        print(f"质量评分：{result.get('score', 0)}/100 - {result.get('level', '未知')}")
        print(f"\n关系分布:")
        for level, count in result.get('analysis', {}).get('relationship_distribution', {}).items():
            bar = '█' * (count // 2)
            print(f"  {level}: {count} {bar}")
        print(f"\n发展建议:")
        for suggestion in result.get('suggestions', []):
            print(f"  ✓ {suggestion}")
        print("=" * 50)

    elif args.action == 'birthday':
        contacts = load_contact(args.file)
        if not isinstance(contacts, list):
            contacts = [contacts]

        reminders = manager.get_birthday_reminder(contacts, args.days)

        if not reminders:
            print(f"\n📅 未来{args.days}天内没有生日提醒")
        else:
            print(f"\n📅 生日提醒（未来{args.days}天）")
            print("=" * 50)
            for reminder in sorted(reminders, key=lambda x: x.get('priority', 'low'), reverse=True):
                print(f"\n{reminder.get('message', '')}")
                if 'detail' in reminder:
                    print(f"   {reminder['detail']}")
                print(f"   建议：{reminder.get('action', '')}")
                if reminder.get('gift_suggestion'):
                    print(f"   礼物建议：{reminder['gift_suggestion']}")
            print("=" * 50)

    else:
        parser.print_help()


if __name__ == '__main__':
    main()
