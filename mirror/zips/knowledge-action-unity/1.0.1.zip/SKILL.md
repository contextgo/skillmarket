---
name: academic-learning-assistant
description: 根据学科、年级生成个性化学习助理，支持数学、物理、化学、生物、语文、英语、历史、地理、计算机科学、工程技术、医学、经济学、文学、管理学、艺术学、农学等学科；当用户需要创建学科学习助手、定制教学内容或设计学习路径时使用
---

# 学科学习助理生成器

## 任务目标
- 本 Skill 用于: 根据用户提供的学科、年级、学习目标等信息，生成个性化的学科学习助理和学科应用助理，实现"学习-应用"一体化智能体
- 学习助理能力: 助理角色设计、知识体系梳理、学习路径规划、教学方法定制、知识讲解、习题辅导、学情分析
- 应用助理能力: 知识蒸馏、技能匹配、场景推荐、实战模拟、能力认证
- 触发条件: 用户需要创建学科学习助手、定制教学内容、设计学习路径或创建应用助理进行知识应用

## 前置准备
- 无需特殊依赖或环境准备
- 确定目标学科、年级和主要学习目标

## 操作步骤

### 双身份切换机制

本 Skill 支持两种身份的智能生成和无缝切换：

#### 学科学习助理
- **核心目标**: 帮助用户掌握知识
- **交互方式**: 讲解、辅导、答疑
- **输出形式**: 知识点解析、习题讲解、学习路径

#### 学科应用助理
- **核心目标**: 帮助用户应用知识
- **交互方式**: 技能匹配、场景推荐、实战模拟
- **输出形式**: 技能卡片、操作步骤、解决方案

#### 切换机制
- 支持在两种身份间快速切换
- 共享用户学习数据和应用数据
- 保持对话上下文，无需重新输入问题

---

### 学科学习助理生成流程

#### 步骤 1: 收集学科信息
与用户确认以下核心信息：
- 学科名称（数学、物理、化学、生物、语文、英语、历史、地理、计算机科学、工程技术、医学、经济学、文学、管理学、艺术学、农学）
- 年级阶段（小学/初中/高中/大学/职业培训）
- 学习目标（知识巩固、能力提升、考试备考、兴趣拓展等）
- 特殊需求（教学风格偏好、交互方式等）

### 步骤 2: 设计助理角色
根据学科特点设计助理人设：
- **角色定位**: 参考学科特性（如数学强调逻辑推理、语文注重文学素养）
- **学科视角内核**: 提取该学科特有的思维方式和分析视角（见三重验证机制）
- **教学风格**: 选择启发性、引导式、系统化或趣味性风格
- **教学DNA**: 量化描述该学科特有的教学风格、表达方式、互动模式
- **交互方式**: 确定提问方式、反馈机制、难度调整策略
- **个性特征**: 赋予助理独特的教学人格（如严谨、耐心、幽默、鼓励型）

参考 [references/assistant-role-template.md](references/assistant-role-template.md) 获取角色设计模板
参考 [references/extraction-methodology.md](references/extraction-methodology.md) 了解学科视角内核提取方法

### 步骤 3: 生成核心内容
根据学科和年级生成教学内容：

#### 3.1 知识体系梳理
读取对应学科的 [references/<学科>-knowledge-system.md](references/) 文件，了解：
- 学科核心知识模块
- 年级对应的知识点分布
- 教学重点和难点

#### 3.2 学习路径设计
基于知识体系设计渐进式学习路径：
- 基础知识铺垫
- 核心概念深入
- 综合能力应用
- 拓展延伸探索

#### 3.3 教学方法制定
针对学科特点选择教学方法：
- **数学/物理/化学**: 强调概念理解、例题讲解、练习反馈
- **生物**: 注重知识点关联、实验思维培养
- **语文/英语**: 侧重阅读理解、写作表达、语言运用
- **历史/地理**: 强调时空观念、因果关系、记忆策略
- **计算机科学**: 重视代码实践、调试能力、项目驱动、技术跟踪
- **工程技术**: 强调理论联系实际、工程思维、系统设计、创新实践
- **医学**: 注重理论与实践结合、临床思维、人文关怀、循证决策
- **经济学**: 强调数据分析、经济建模、政策分析、决策能力
- **文学**: 注重文本分析与创作实践、审美体验、文学鉴赏
- **管理学**: 强化案例教学与模拟实训、团队协作、领导力培养
- **艺术学**: 强调审美体验与创作表达、技能训练、艺术创新
- **农学**: 重视田间实践与技术应用、生态保护、可持续发展

### 步骤 4: 输出助理配置
将设计结果结构化输出，包含：
- 助理基本信息（名称、角色、目标）
- 学科视角内核（三重验证通过的核心思维框架）
- 研究式学习工作流（何时调研、何时直接讲解）
- 教学策略与风格
- 教学DNA（量化的教学特征描述）
- 学科知识框架图
- 核心知识点解析
- 学习路径规划
- 学习方法指导
- 学科内在张力（学科内的固有矛盾和权衡）
- 学科谱系（学科发展脉络、关键人物、学派演变）
- 资源推荐清单
- 角色扮演规则（免责声明、退出机制）
- 交互示例与场景

### 步骤 5: 验证与优化
- 检查内容是否符合学科教学规律
- 验证学习路径的合理性和渐进性
- 确保助理角色与学科特点匹配

---

### 学科应用助理生成流程

#### 步骤 A: 确定应用需求
与用户确认以下核心信息：
- 应用学科（与学习助理相同的学科）
- 应用场景类型（数据分析、优化决策、实验设计等）
- 技能需求（需要掌握哪些技能）
- 实践目标（解决什么实际问题）

#### 步骤 B: 设计应用助理角色
根据学科应用特点设计助理人设：
- **角色定位**: 侧重技能应用和问题解决
- **技能类型**: 技能卡片生成、场景匹配、实战模拟
- **交互方式**: 场景化搜索、技能推荐、实时反馈
- **个性特征**: 务实型、结果导向、效率优先

参考 [references/application-assistant-template.md](references/application-assistant-template.md) 获取应用助理模板

#### 步骤 C: 生成技能卡片
根据学科和应用场景生成技能卡片：

##### C.1 知识蒸馏
采用 RIA-TV++ 方法论将知识点转化为技能卡片（见 [references/ria-tv-methodology.md](references/ria-tv-methodology.md)）：
- 原文引用（R）：技能的理论基础
- 深度解读（I）：核心概念和原理
- 应用案例（A）：典型应用场景
- 触发条件（T）：何时使用
- 执行步骤（V）：如何操作
- 边界场景（T）：何时不用

##### C.2 三重验证
- 跨域验证：技能在多个场景中可应用
- 预测力验证：技能能帮助解决新问题
- 独特性验证：技能具有学科特色

##### C.3 技能分类
- 按难度分类：基础、中级、高级
- 按应用频率分类：高频、中频、低频
- 按学科分类：各学科的技能类型

#### 步骤 D: 场景匹配与推荐
根据用户需求匹配应用场景：

##### D.1 场景识别
- 分析用户的问题描述
- 提取关键信息和意图
- 识别问题的类型和领域

##### D.2 技能匹配
- 单一技能匹配：简单问题的直接匹配
- 技能组合匹配：复杂问题的组合方案
- 智能推荐：基于用户历史的个性化推荐

参考 [references/application-scenarios.md](references/application-scenarios.md) 查看应用场景库

#### 步骤 E: 实战模拟设计
提供虚拟场景进行技能实践：
- 场景类型：案例模拟、任务模拟、危机模拟
- 实时反馈：记录操作、识别问题、提供建议
- 能力评估：评估应用效果、生成能力报告

#### 步骤 F: 能力认证体系
对用户技能掌握程度进行认证：
- 认证维度：理论掌握度、实践应用度、创新能力
- 认证方式：实战模拟测试、自测题验证、项目实践
- 能力证书：生成认证证书，记录成长轨迹

## 资源索引
- 学习助理模板: [references/assistant-role-template.md](references/assistant-role-template.md)
- 应用助理模板: [references/application-assistant-template.md](references/application-assistant-template.md)
- 内核提取方法: [references/extraction-methodology.md](references/extraction-methodology.md)
- 技能卡片方法论: [references/ria-tv-methodology.md](references/ria-tv-methodology.md)
- 应用场景库: [references/application-scenarios.md](references/application-scenarios.md)
- 数学知识体系: [references/math-knowledge-system.md](references/math-knowledge-system.md)
- 物理知识体系: [references/physics-knowledge-system.md](references/physics-knowledge-system.md)
- 化学知识体系: [references/chemistry-knowledge-system.md](references/chemistry-knowledge-system.md)
- 生物知识体系: [references/biology-knowledge-system.md](references/biology-knowledge-system.md)
- 语文知识体系: [references/chinese-knowledge-system.md](references/chinese-knowledge-system.md)
- 英语知识体系: [references/english-knowledge-system.md](references/english-knowledge-system.md)
- 历史知识体系: [references/history-knowledge-system.md](references/history-knowledge-system.md)
- 地理知识体系: [references/geography-knowledge-system.md](references/geography-knowledge-system.md)
- 计算机科学知识体系: [references/computer-science-knowledge-system.md](references/computer-science-knowledge-system.md)
- 工程技术知识体系: [references/engineering-technology-knowledge-system.md](references/engineering-technology-knowledge-system.md)
- 医学知识体系: [references/medicine-knowledge-system.md](references/medicine-knowledge-system.md)
- 经济学知识体系: [references/economics-knowledge-system.md](references/economics-knowledge-system.md)
- 文学知识体系: [references/literature-knowledge-system.md](references/literature-knowledge-system.md)
- 管理学知识体系: [references/management-knowledge-system.md](references/management-knowledge-system.md)
- 艺术学知识体系: [references/arts-knowledge-system.md](references/arts-knowledge-system.md)
- 农学知识体系: [references/agriculture-knowledge-system.md](references/agriculture-knowledge-system.md)

## 注意事项
- 仅在需要时读取特定学科的参考文档，保持上下文简洁
- 充分利用智能体的知识库和推理能力，设计符合教育规律的教学方案
- 根据用户反馈动态调整助理配置，确保个性化适配
- 避免过度设计，聚焦核心教学价值

## 使用示例

### 示例 1: 创建高中数学学习助理
- **用户需求**: "帮我创建一个针对高一数学的学习助理，重点是函数部分"
- **执行方式**: 智能体主导
- **关键步骤**:
  1. 确认年级为高一，重点模块为函数
  2. 读取 math-knowledge-system.md 了解函数知识点
  3. 设计严谨逻辑型助理，强调概念理解和应用能力
  4. 生成函数章节的学习路径（定义→性质→图像→应用）

### 示例 2: 设计初中英语学习路径
- **用户需求**: "需要为初一学生设计英语学习路径，重点是词汇和语法"
- **执行方式**: 智能体主导
- **关键步骤**:
  1. 确认学科为英语，年级初一，重点词汇和语法
  2. 读取 english-knowledge-system.md 获取初一知识模块
  3. 设计趣味互动型助理，注重听说读写综合能力
  4. 规划词汇记忆策略和语法练习方法

### 示例 3: 创建高考备考历史助理
- **用户需求**: "创建一个历史学习助理，帮助学生备考高考"
- **执行方式**: 智能体主导
- **关键步骤**:
  1. 确认学科为历史，目标为高考备考
  2. 读取 history-knowledge-system.md 了解高考考点
  3. 设计时间线索型助理，强调时空观念和因果关系
  4. 生成按时间轴和主题的复习路径

### 示例 4: 创建大学计算机科学学习助理
- **用户需求**: "帮我创建一个计算机科学学习助理，重点是数据结构与算法"
- **执行方式**: 智能体主导
- **关键步骤**:
  1. 确认学科为计算机科学，学习阶段为大学
  2. 读取 computer-science-knowledge-system.md 获取算法与数据结构模块
  3. 设计逻辑推理型助理，强调代码实践和调试能力
  4. 规划从基础数据结构到高级算法的学习路径，包含项目实践

### 示例 5: 设计职业培训医学学习路径
- **用户需求**: "需要为医学职业培训设计学习助理，重点是临床技能"
- **执行方式**: 智能体主导
- **关键步骤**:
  1. 确认学科为医学，学习阶段为职业培训
  2. 读取 medicine-knowledge-system.md 了解临床技能模块
  3. 设计实践导向型助理，注重理论与实践结合、临床思维训练
  4. 规划从基础医学到临床实践的学习路径，包含病例分析和模拟训练
