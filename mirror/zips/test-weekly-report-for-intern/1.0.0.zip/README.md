# weekly_report_skill

这是一个独立的实习生周报写作 Skill 文件夹，用于在用户输入“写周报”或类似意图时，帮助整理、润色、生成实习周报。

## 文件结构

```text
weekly_report_skill/
├── SKILL.md
├── README.md
├── templates/
│   └── weekly_report_template.md
├── references/
│   └── weekly_report_style_guide.md
└── examples/
    ├── example_product_intern.md
    └── example_ai_product_intern.md
```

## 使用方式

当用户输入：

```text
写周报
```

或提供零散工作内容时，按照 `SKILL.md` 的规则进行处理。

## 注意

该 Skill 与 IELTS 项目、论文项目或其他已有项目无关，应放在独立文件夹中使用，严禁覆盖或修改原项目文档。
