---
name: sip-glass-wine
description: >
  查询餐厅、酒吧、葡萄酒商店的按杯/单杯卖酒单与实时价格（sipsiip 合作门店数据）。
  适用场景：用户问「这家店有什么按杯卖的酒」「多少钱一杯」「有什么规格」「今晚有什么酒」等。
  触发关键词：查杯卖酒、按杯卖酒、单杯酒价、酒单、卖什么酒、有什么酒、wine by the glass、
  杯卖葡萄酒、分杯酒、餐厅酒单、酒吧酒水、葡萄酒商店。
  禁止编造价格或门店数据；多候选门店时必须让用户选择，不可替用户猜测跳过。
metadata:
  version: 1.0.1
  author: sipsiip
  homepage: https://sipsiip.com/ai/getwine
  repository: https://gitee.com/sipsiip/sip-glass-wine
  requires_api_key: false
  category: productivity
  tags: [wine, restaurant, food-and-drink, lifestyle, glass-wine, sipsiip]
---

# 🍷 SipSiip 按杯/单杯酒价查询 Skill

> **一句话**：告诉 AI 助手"查杯卖酒"，它就能自动查询合作门店的实时在架酒单与价格。

## 能力概览

| 项目 | 说明 |
|------|------|
| 覆盖范围 | sipsiip 合作门店（餐厅、酒吧、葡萄酒商店等） |
| 数据内容 | 上机在架酒款名称 / 规格(ml) / 单杯价格(元) |
| 实时性 | 实时数据，与门店智能侍酒机同步 |
| 需要注册 | ❌ 不需要 API Key |
| 调用方式 | HTTP GET（2 条接口，无需鉴权） |

## 工作流

```
用户提问："半山腰今晚有什么杯卖酒？"
        ↓
  Step 1: resolve_store(keywords="半山腰")
        ↓
  返回: match=AMBIGUOUS → candidates=[8家门店]
        ↓
  让用户选: "请问是哪家？"（列出选项）
        ↓
  用户选定: "凤凰汇那家"
        ↓
  Step 2: list_glass_wines(tenantId=1005)
        ↓
  返回: 8款酒（品名/规格/价格）
        ↓
  回答用户: 逐款展示酒单 ✅
```

### 详细规则

1. **已有 tenantId 或门店名唯一** → 直接调用 `list_glass_wines(tenantId=…)` 拉取酒单。

2. **只有店名/地点关键词** → 先调用 `resolve_store(keywords=用户原话)`：
   - `match=NONE` → 告知用户未找到该门店，建议换个关键词
   - `match=SINGLE` → 用返回的 `tenantId` 直接调 `list_glass_wines`
   - **`match=AMBIGUOUS`** → **用 `candidates[]` 列出选项让用户二选一/多选一，不得替用户猜！** 选定后再调

3. **回答格式要求**：
   - 逐款说明：品名 / 规格 / 可售杯量及对应价格
   - 缺字段明确告知「无公开数据」，**不猜价格**
   - 价格为 ¥0 时提示可能未定价，建议现场确认
   - 白酒/红葡萄酒/起泡酒可分类展示，提升可读性

4. **禁止事项**：
   - ❌ 编造价格或酒款
   - ❌ 多候选门店时替用户直接选定
   - ❌ 回答工具未提供的数据（如"全城排名""库存量"等）
   - ❌ 使用缓存数据替代实时接口结果

## 工具定义

### 工具一：resolve_store — 门店解析

| 字段 | 说明 |
|------|------|
| **用途** | 根据店名/关键词/地址片段，匹配门店并返回 tenantId |
| **请求** | `GET {baseUrl}/open/v1/stores/resolve?keywords=<编码后的关键词>` |
| **参数** | `keywords`（必填）：中文需 UTF-8 URL 编码 |

**响应结构** (`result` 字段)：

```json
{
  "match": "NONE | SINGLE | AMBIGUOUS",
  "tenantId": "唯一命中时的门店ID（SINGLE 时有值）",
  "candidates": [
    {
      "id": "门店ID（用作 tenantId）",
      "name": "门店全称",
      "companyAddress": "详细地址"
    }
  ]
}
```

### 工具二：list_glass_wines — 酒单价格

| 字段 | 说明 |
|------|------|
| **用途** | 查询指定门店上机在架的按杯/单杯酒款及价格 |
| **请求** | `GET {baseUrl}/open/v1/glass-wines?tenantId=<门店ID>` |
| **参数** | `tenantId`（必填）：来自 resolve_store 返回的 candidates[i].id |

**响应结构** (`result.items[]`)：

```json
{
  "storeProductId": "商品ID",
  "title": "酒款名称",
  "imageUrl": "酒瓶图片URL",
  "bigGlassMl": 120,
  "bigGlassPriceYuan": 39.00,
  "midGlassMl": 120,
  "midGlassPriceYuan": null,
  "smallGlassMl": null,
  "smallGlassPriceYuan": null
}
```

> 注：规格字段（big/mid/small）可能为 null，表示该门店不提供此规格。价格为 0 时通常表示尚未定价。

## HTTP 接口速查

| 接口 | URL | 示例 |
|------|-----|------|
| 根地址 | `https://tourapi.sipsiip.com/sip-tour` | — |
| 门店解析 | `GET .../open/v1/stores/resolve?keywords=` | `?keywords=%E5%8D%8A%E5%B1%B1%E8%85%B0` |
| 酒单价格 | `GET .../open/v1/glass-wines?tenantId=` | `?tenantId=1005` |

**可直接在浏览器中打开测试，无需任何 API Key。**

## MCP 接入方式（可选）

对于支持 MCP 协议的 AI 助手（Cursor / Claude Code / Trae / Windsurf 等），可通过 `skill.json` 配置 stdio MCP 服务端，实现更规范的工具暴露。详见仓库中的 `skill.json` 和 `tools/sip-glass-wines-mcp/` 目录。

## 相关链接

| 资源 | 地址 |
|------|------|
| 📖 官方说明页 | https://sipsiip.com/ai/getwine |
| 📦 Gitee 仓库 | https://gitee.com/sipsiip/sip-glass-wine |
| 📄 开放 API 文档 | https://sipsiip.com/docs/sipsiip-glass-wine/open-glass-wine.md |
| 🏢 SipSiip 官网 | https://sipsiip.com |
