# sip-glass-wine 🍷

**SipSiip 按杯/单杯酒价查询 Skill** — 让 AI 助手一键拥有查询合作门店实时杯卖酒单的能力。

## ✨ 特性

- 🍷 **零门槛**：无需 API Key，2 条 GET 接口直接调用
- ⚡ **实时数据**：与门店智能侍酒机同步，在架即有价
- 🏪 **多门店覆盖**：餐厅、酒吧、葡萄酒商店等合作商户
- 🤖 **AI 原生**：支持 MCP / HTTP 双模式，适配主流 AI 助手
- 🎯 **关键词触发**：用户说"查杯卖酒"即可自动激活

## 快速体验（零安装）

把下面这段话发给任何支持 HTTP 调用的 AI 助手，它就能立刻查酒单：

```
你有两个查询杯卖酒的接口可用：

1. 门店解析：GET https://tourapi.sipsiip.com/sip-tour/open/v1/stores/resolve?keywords=店名
2. 酒单价格：GET https://tourapi.sipsiip.com/sip-tour/open/v1/glass-wines?tenantId=门店ID

规则：先调接口1拿到 tenantId，再调接口2拿酒单。
     如果接口1返回多个候选门店，让用户选一个。
     回答时逐款列出品名/规格/价格，不要编造。
```

## 安装到 AI 助手

### 方式一：ClawHub / SkillHub 市场（推荐）

本技能已发布至 [ClawHub](https://clawhub.com) / [SkillHub](https://lightmake.site)，在支持的市场中搜索 **"sip-glass-wine"** 或 **"杯卖酒"** 即可一键安装。

### 方式二：手动安装

将 `SKILL.md` 和 `_meta.json` 复制到对应目录：

| AI 助手 | 技能目录 |
|---------|---------|
| Cursor | `.cursor/skills/sip-glass-wine/` |
| Claude Code | `.claude/skills/sip-glass-wine/` |
| Trae | `.trae/skills/sip-glass-wine/` |
| Windsurf | `.windsurf/skills/sip-glass-wine/` |
| WorkBuddy | `.workbuddy/skills/sip-glass-wine/` |
| 通用 | `.agents/skills/sip-glass-wine/` |

### 方式三：MCP 模式（完整功能）

```bash
git clone https://gitee.com/sipsiip/sip-glass-wine
# 将 skill.json + SKILL.md 放入 skills 目录
# MCP 服务端：tools/sip-glass-wines-mcp/index.js
```

## 接口文档

| 接口 | 方法 | 说明 |
|------|------|------|
| 门店解析 | `GET /open/v1/stores/resolve?keywords=…` | 店名 → tenantId |
| 酒单价格 | `GET /open/v1/glass-wines?tenantId=…` | 酒款列表与价格 |

- **根地址**：`https://tourapi.sipsiip.com/sip-tour`
- **鉴权**：公开只读，不需要 API Key
- **详细文档**：[open-glass-wine.md](https://sipsiip.com/docs/sipsiip-glass-wine/open-glass-wine.md)

## 文件说明

| 文件 | 用途 |
|------|------|
| `SKILL.md` | 核心技能文件 — AI 行为规范与工作流定义 |
| `_meta.json` | 技能元数据 — 名称/描述/标签/分类（市场提交用） |
| `skill.json` | MCP 配置 — 工具定义与服务端启动参数 |
| `tools/` | MCP 参考实现（Node.js stdio） |

## 使用示例

```
用户: 半山腰今晚有什么杯卖酒？

AI: （调用 resolve_store → 8家候选）
    请问是哪家半山腰？
    ① 半山腰—凤凰汇（北京）  ← 用户选这个
    ② 半山腰—王府中環（北京）
    ...

AI: （调用 list_glass_wines tenantId=1005）

🍷 半山腰—凤凰汇 · 杯卖酒单

🥂 白葡萄酒
├─ 布朗姆干白        120ml  ¥39
├─ 霞多丽干白 2022   120ml  ¥70
...

🍷 红葡萄酒
├─ 爱之山干红        120ml  ¥39
├─ 法国黑皮诺        120ml  ¥49
...
```

## 相关链接

- 📖 **官方说明页**：https://sipsiip.com/ai/getwine
- 📦 **Gitee 仓库**：https://gitee.com/sipsiip/sip-glass-wine
- 🌐 **SipSiip 官网**：https://sipsiip.com

## License

MIT
