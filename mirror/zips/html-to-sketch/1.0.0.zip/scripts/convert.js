#!/usr/bin/env node
const fs = require("fs");
const path = require("path");
const { spawnSync } = require("child_process");

const skillRoot = path.resolve(__dirname, "..");
const bundledCliPath = path.join(skillRoot, "bin", "index.js");
const browserBundlePath = path.join(skillRoot, "vendor", "html2sketch.min.js");

function showUsage() {
  console.log("html-to-sketch skill runner");
  console.log("");
  console.log("用法:");
  console.log("  node skill/html-to-sketch/scripts/convert.js <input.html> <output.sketch> [--ignore-errors] [--validate] [--split-top-level]");
  console.log("");
  console.log("示例:");
  console.log("  node skill/html-to-sketch/scripts/convert.js ./test/index.html ./dist/index.sketch --validate");
}

function fail(message, tips) {
  console.error(`❌ ${message}`);
  if (tips && tips.length) {
    console.error("");
    console.error("请按以下方式处理：");
    for (const tip of tips) {
      console.error(`- ${tip}`);
    }
  }
  process.exit(1);
}

function commandExists(command, args) {
  const result = spawnSync(command, args, {
    stdio: "ignore",
    shell: process.platform === "win32",
  });
  return result.status === 0;
}

function ensureEnvironment() {
  if (!commandExists("node", ["--version"])) {
    fail("当前环境未检测到 Node.js。", [
      "安装 Node.js 18 或更高版本。",
      "安装后重新打开终端或 IDE，再重新触发该 skill。",
    ]);
  }

  if (!fs.existsSync(bundledCliPath)) {
    fail("技能包缺少打包后的 CLI 入口。", [
      `缺失文件：${bundledCliPath}`,
      "在 html2sketch-cli 项目根目录执行：npm run build:skill",
      "重新生成后再审查或使用该 skill。",
    ]);
  }

  if (!fs.existsSync(browserBundlePath)) {
    fail("技能包缺少 html2sketch 浏览器端资源。", [
      `缺失文件：${browserBundlePath}`,
      "在 html2sketch-cli 项目根目录执行：npm run build:skill",
      "重新生成后再审查或使用该 skill。",
    ]);
  }
}

function normalizeArgs(argv) {
  const passthrough = [...argv];
  const inputIndex = passthrough.findIndex((arg) => !arg.startsWith("--"));
  const outputIndex = passthrough.findIndex((arg, index) => index > inputIndex && !arg.startsWith("--"));

  if (inputIndex === -1 || outputIndex === -1) {
    showUsage();
    process.exit(1);
  }

  const inputPath = path.resolve(process.cwd(), passthrough[inputIndex]);
  const outputPath = path.resolve(process.cwd(), passthrough[outputIndex]);

  if (!fs.existsSync(inputPath)) {
    fail(`输入 HTML 文件不存在：${inputPath}`, [
      "检查输入路径是否正确。",
      "可使用相对当前工作目录的路径，或使用绝对路径。",
    ]);
  }

  if (!inputPath.toLowerCase().endsWith(".html") && !inputPath.toLowerCase().endsWith(".htm")) {
    fail(`输入文件不是 HTML 文件：${inputPath}`, [
      "请传入 .html 或 .htm 文件。",
    ]);
  }

  if (!outputPath.toLowerCase().endsWith(".sketch")) {
    fail(`输出文件扩展名不是 .sketch：${outputPath}`, [
      "请将输出路径命名为 .sketch 文件。",
    ]);
  }

  fs.mkdirSync(path.dirname(outputPath), { recursive: true });

  passthrough[inputIndex] = inputPath;
  passthrough[outputIndex] = outputPath;
  return passthrough;
}

function main() {
  const rawArgs = process.argv.slice(2);
  if (rawArgs.includes("--help") || rawArgs.includes("-h")) {
    showUsage();
    process.exit(0);
  }

  if (rawArgs.length < 2) {
    showUsage();
    process.exit(1);
  }

  ensureEnvironment();

  const cliArgs = normalizeArgs(rawArgs);

  console.log("🐶 html-to-sketch skill：环境检查通过，开始调用打包 CLI...");
  const result = spawnSync(process.execPath, [bundledCliPath, ...cliArgs], {
    cwd: process.cwd(),
    stdio: "inherit",
    env: {
      ...process.env,
      HTML2SKETCH_BROWSER_BUNDLE: browserBundlePath,
    },
  });

  if (result.error) {
    fail(`执行转换失败：${result.error.message}`, [
      "确认 Node.js、Chrome/Edge 浏览器可用。",
      "确认 skill/bin/index.js 与 skill/vendor/html2sketch.min.js 存在。",
    ]);
  }

  process.exit(result.status || 0);
}

main();
