from dataclasses import dataclass
from typing import List, Dict, Optional

@dataclass
class HandoverConfig:
    threshold: int
    action_description: str
    context_requirements: str = None

@dataclass
class SymptomSkill:
    id: str
    name: str
    definition: str
    identification: str
    grading: str
    suggestion: str
    handover_config: HandoverConfig
    checklist: List[str] = None

# 腹泻单技能
SYMPTOM_LIBRARY: Dict[str, SymptomSkill] = {
    "腹泻": SymptomSkill(
        id="diarrhea",
        name="腹泻",
        definition="排便次数明显超过平日习惯(基线)的频率，粪质稀薄，水分增加。",
        identification="拉肚子、腹泻、跑肚、大便稀、拉稀、排便次数多。",
        grading="""
CTCAE v5.0 标准分级：
- 1级 (G1): 较基线增加 < 4次/天；造口排出量轻度增加。
- 2级 (G2): 较基线增加 4-6次/天；造口排出量中度增加；日常生活受限。
- 3级 (G3): 较基线增加 >= 7次/天；失禁；需住院；重度增加造口排出量；日常生活自理受限。
- 4级 (G4): 危及生命的后果；需要紧急干预。
- 5级 (G5): 死亡。
""",
        suggestion="""
1. 腹泻 1级 (居家护理):
   - 饮食调整：少渣低纤维饮食（如米粥、面条），避免乳制品、辛辣及油腻食物。多饮温水。
   - 观察记录：记录排便次数及性状。
   - 用药建议：若无感染迹象，可观察或遵医嘱少量使用蒙脱石散。
2. 腹泻 2级 (药物干预):
   - 药物治疗：遵医嘱服用洛哌丁胺（首剂4mg，随后每次不成形便后2mg，每日不超过16mg）。
   - 补液支持：口服补液盐（ORS）预防脱水。
   - 评估：若持续超过24小时未缓解，需联系医生。
3. 腹泻 3级及以上 (紧急医疗):
   - 立即就医：前往急诊或联系主治医生住院，进行静脉补液及电解质纠正。
   - 停药评估：可能需要暂停化疗或靶向药物。
   - 排除感染：需排除伪膜性肠炎（C.difficile）或其他感染性腹泻。
""",
        handover_config=HandoverConfig(
            threshold=3,
            action_description="停止引导性提问，给出紧急就医建议并声明个案管理师已接入。",
        ),
        checklist=[
            "您最近大便次数比平时多了几次?",
            "大便的形状是怎样的（水样、稀便）?",
            "有没有肚子疼或者发烧的情况?",
            "是否使用了止泻药?"
        ]
    )
}

# 激活仅腹泻技能
ACTIVE_SYMPTOM_IDS = ["腹泻"]
SYMPTOM_SKILLS = [SYMPTOM_LIBRARY[sid] for sid in ACTIVE_SYMPTOM_IDS]