---
name: volcengine-global-search
description: Query Volcano Engine (火山引擎) product information, documentation, parameters, features, and pricing from official sources without login. Use when the user asks about Volcano Engine products (ECS, TOS, RDS, VKE, etc.), needs product documentation, wants to compare product specifications, or needs help finding specific product parameters and features.
---

# 火山引擎产品查询 (Volcano Engine Product Query)

This skill helps users find detailed information about Volcano Engine (ByteDance Cloud) products by searching official documentation and product pages without requiring login.

本技能帮助用户通过搜索官方文档和产品页面，无需登录即可获取火山引擎（字节跳动云）产品的详细信息。

## When to Use / 使用场景

- User asks about specific Volcano Engine products (ECS, TOS, RDS, VKE, etc.) / 用户询问特定的火山引擎产品（ECS、TOS、RDS、VKE等）
- User needs product documentation or API references / 用户需要产品文档或API参考
- User wants to compare product specifications or pricing / 用户想要比较产品规格或价格
- User needs help finding specific product parameters or features / 用户需要帮助查找特定的产品参数或功能
- User mentions "Volcano Engine", "火山引擎", or "字节云" and needs product information / 用户提到"火山引擎"或"字节云"并需要产品信息

---

## Step 1: Identify the Product (识别产品)

从全面的产品目录中确定用户询问的是哪个火山引擎产品：

### 1.1 识别用户查询中的产品关键词 / Identify Product Keywords from User Query

分析用户问题，提取以下信息 / Analyze user questions and extract the following information:
- **产品名称 (Product Name)**: 用户提到的具体产品名（如 ECS、TOS、RDS）/ Specific product names mentioned by the user (e.g., ECS, TOS, RDS)
- **产品类别 (Product Category)**: 用户可能提到的产品类别（如计算、数据库、存储）/ Product categories mentioned (e.g., Compute, Database, Storage)
- **功能需求 (Functional Requirements)**: 用户想要实现的功能（如搭建网站、数据备份、负载均衡）/ Functions the user wants to implement (e.g., build websites, data backup, load balancing)
- **使用场景 (Use Cases)**: 用户的业务场景（如电商、游戏、金融）/ User's business scenarios (e.g., e-commerce, gaming, finance)

### 1.2 使用产品别名对照表 / Product Alias Reference Table

如果用户使用非标准名称，参考以下别名映射 / If users use non-standard names, refer to the following alias mapping:

| 用户可能说的 (User May Say) | 对应产品 (Product) | 英文名 (English Name) |
|---------------------------|-------------------|----------------------|
| 云服务器、虚拟机、VM、云主机 (Cloud Server, VM, Cloud Host) | 云服务器 ECS | Elastic Compute Service |
| 对象存储、云盘、云存储 (Object Storage, Cloud Disk) | 对象存储 TOS | Tinder Object Storage |
| 负载均衡、ALB、CLB (Load Balancer) | 应用型负载均衡 ALB | Application Load Balancer |
| 数据库、MySQL、PostgreSQL、veDB (Database) | 云数据库 RDS / veDB | Relational Database Service |
| Redis、缓存 (Redis, Cache) | 缓存数据库 Redis | Cloud Redis |
| 大模型、豆包、Doubao (Large Model) | 豆包大模型 | Doubao LLM |
| 容器、K8s、Kubernetes (Container, K8s) | 容器服务 VKE | Volcano Kubernetes Engine |
| 函数计算、Serverless (Function Compute) | 函数服务 | Function Service |
| 安全中心 (Security Center) | 云安全中心 | Security Center |
| WAF、防火墙 (Firewall) | Web应用防火墙 WAF | Web Application Firewall |
| CDN、加速 (CDN, Acceleration) | 内容分发网络 CDN | Content Delivery Network |
| VPC、私有网络 (VPC, Private Network) | 私有网络 VPC | Virtual Private Cloud |
| 大数据、数仓 (Big Data, Data Warehouse) | ByteHouse / E-MapReduce | Big Data Warehouse |
| 消息队列、RocketMQ (Message Queue) | 消息队列 RocketMQ | Message Queue RocketMQ |

### 1.3 确定目标产品 / Identify Target Product

从产品目录中找到最匹配的产品，记录 / Find the best matching product from the catalog and record:
- **产品中文名 (Chinese Name)**: 产品的中文名称
- **产品英文名 (English Name)**: 产品的英文名称
- **产品类别 (Category)**: 产品所属类别
- **产品代码 (Product Code)**: 用于构造URL的产品代码

---

## 📦 火山引擎全产品目录 (Volcano Engine Full Product Catalog)

### 🤖 一、人工智能与机器学习 (AI & Machine Learning)

| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 豆包大模型 | Doubao LLM | 字节跳动自研大模型，提供多模态能力 / ByteDance self-developed LLM with multimodal capabilities |
| 火山方舟 | Volcano Ark | 一站式大模型服务平台，提供模型精调、推理、评测 / One-stop large model service platform |
| 扣子 | Coze | 一站式AI Agent开发工具 / One-stop AI Agent development platform |
| 机器学习平台 | ML Platform | 面向机器学习应用开发者的企业级云原生平台 / Enterprise-grade cloud-native ML platform |
| VikingDB | VikingDB | 大规模云原生向量数据库 / Large-scale cloud-native vector database |
| TRAE CN | TRAE CN | 基于AI的智能开发环境(IDE) / AI-powered intelligent development environment |
| Viking AI 搜索 | Viking AI Search | AI搜索引擎，大模型时代的搜索推荐 / AI search engine for the LLM era |
| 联网问答 Agent | Connected Q&A Agent | 整合豆包大模型及联网能力的智能体服务 / Agent service with Doubao LLM and internet connectivity |
| 市场洞察 Agent | Market Insight Agent | 依托大模型技术的市场分析智能体 / Market analysis agent powered by LLM |
| 图像生成大模型 | Image Generation LLM | 提供文生图、图生图及图像特效能力 / Text-to-image and image-to-image generation |

---

### 🖥️ 二、计算 (Compute)

#### 弹性计算 (Elastic Compute)
| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 云服务器 ECS | Elastic Compute Service | 安全稳定、可弹性伸缩的云计算服务 / Secure, stable, elastic cloud computing service |
| GPU 云服务器 | GPU Cloud Server | 提供GPU算力的弹性计算服务，适用于AI、视觉处理 / GPU-powered computing for AI and graphics |
| 弹性裸金属服务器 | Elastic Bare Metal | 高性能算力服务、安全物理隔离 / High-performance bare metal with physical isolation |
| 弹性伸缩 | Auto Scaling | 根据业务需求自动调整计算资源 / Automatically adjust computing resources |
| 云手机 | Cloud Phone | 跨终端虚拟安卓云服务 / Cross-terminal virtual Android cloud service |
| 函数服务 | Function Service | 事件驱动的无服务器函数托管平台 / Event-driven serverless function platform |
| veLinux | veLinux | 针对火山引擎公有云深度定制的自研操作系统 / Volcano Engine optimized Linux OS |

#### 边缘计算 (Edge Computing)
| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 边缘计算节点 | Edge Computing Node | 基于全域覆盖的边缘节点，提供异构算力 / Edge nodes with heterogeneous computing power |
| 流式计算 Flink 版 | Flink Streaming | 云原生全托管实时数据处理分析服务 / Cloud-native managed real-time data processing |
| 可信隐私计算平台 | Trusted Privacy Computing | 基于多方安全计算、联邦学习的隐私计算方案 / Privacy-preserving computing platform |

---

### 💾 三、存储 (Storage)

| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 对象存储 TOS | Tinder Object Storage | 海量、安全、低成本、高可靠的分布式云存储 / Massive, secure, low-cost distributed cloud storage |
| 弹性文件存储 EFS | Elastic File Storage | AI云原生文件存储，弹性伸缩、极致性能 / AI cloud-native file storage with elastic scaling |
| 弹性块存储 EBS | Elastic Block Storage | 高可用、高可靠、高性能的块存储设备 / Highly available, reliable block storage |
| 文件存储 vePFS | vePFS | 高吞吐、低延时、可扩展的并行文件存储 / High-throughput parallel file storage |
| 大数据文件存储 | Big Data File Storage | 支持HDFS语义，提供数据加速 / HDFS-compatible big data file storage |
| 存储迁移服务 | Storage Migration Service | 将其他云服务商对象存储数据迁移到TOS / Migrate data from other cloud providers to TOS |
| 数据闪送服务 | Data Express Service | 通过离线设备将数据迁移到对象存储 / Offline data migration service |
| AI 数据湖服务 | AI Data Lake Service | 新一代AI数据湖，高效存储管理多模态数据 / AI-native data lake for multimodal data |
| 弹性极速缓存 EIC | Elastic Instant Cache | 为大模型等场景提供的高速KVCache服务 / High-speed KV cache for LLM scenarios |

---

### 🗄️ 四、数据库 (Database)

#### 关系型数据库 (Relational Database)
| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 云数据库 MySQL 版 | RDS for MySQL | 即开即用、稳定可靠、灵活弹性的关系型数据库 / Ready-to-use, reliable relational database |
| 云数据库 PostgreSQL 版 | RDS for PostgreSQL | 完全兼容原生PostgreSQL的云数据库服务 / PostgreSQL-compatible cloud database |
| 云数据库 SQL Server 版 | RDS for SQL Server | 拥有正版授权，高度兼容微软生态 / Licensed SQL Server with Microsoft ecosystem compatibility |
| 云数据库 veDB MySQL 版 | veDB for MySQL | 新一代分布式关系型数据库，完全兼容MySQL / Next-gen distributed MySQL-compatible database |
| ByteHouse | ByteHouse | 极致性能弹性伸缩的分析型数据库 / High-performance analytical database |

#### NoSQL数据库 (NoSQL Database)
| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 缓存数据库 Redis 版 | Cloud Redis | 兼容Redis的缓存数据库，支持缓存和持久化 / Redis-compatible cache and persistence database |
| 文档数据库 MongoDB 版 | MongoDB | 完全兼容原生MongoDB的云数据库 / MongoDB-compatible cloud database |
| 表格数据库 HBase 版 | Cloud HBase | 基于Apache HBase的全托管数据库服务 / Managed HBase database service |
| 向量数据库 Milvus 版 | Milvus | 100%兼容开源Milvus的云原生向量检索引擎 / Cloud-native vector search engine |
| VikingDB | VikingDB | 大规模云原生向量数据库 / Large-scale cloud-native vector database |
| ContextSearch | ContextSearch | 面向AI应用的智能查询服务，融合向量检索 / AI-oriented intelligent query service |

#### 数据库管理服务 (Database Management)
| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 数据库传输服务 DTS | Database Transmission Service | 一体化数据库数据传输管理服务 / Integrated database migration service |
| 数据库工作台 | Database Workbench | 面向多类型数据库生命周期管理的统一云管平台 / Unified database management platform |

---

### 🐳 五、容器与中间件 (Container & Middleware)

| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 容器服务 VKE | Volcano Kubernetes Engine | 以容器为核心的高性能Kubernetes容器集群管理服务 / High-performance Kubernetes container service |
| 镜像仓库 CR | Container Registry | 安全高可用的容器镜像托管服务 / Secure container image hosting service |
| 函数服务 | Function Service | 事件驱动的无服务器函数托管计算平台 / Event-driven serverless function platform |
| 消息队列 RocketMQ 版 | RocketMQ | 低延迟、高并发、高可用的分布式消息中间件 / Low-latency distributed message middleware |
| 微服务引擎 | Microservices Engine | 微服务治理和托管平台 / Microservices governance platform |
| API 网关 | API Gateway | API发布、管理、调用的托管服务 / API publishing and management service |

---

### 🌐 六、网络 (Networking)

#### 云上网络 (Cloud Networking)
| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 私有网络 VPC | Virtual Private Cloud | 为云上资源构建隔离的虚拟网络环境 / Isolated virtual network environment |
| NAT 网关 | NAT Gateway | 为私有网络内云服务器提供网络地址转换 / NAT service for private network access |
| 私网连接 PrivateLink | PrivateLink | 建立私密的VPC间网络连接 / Private connectivity between VPCs |
| 中转路由器 | Transit Router | 地域级路由器，支持灵活构建任意拓扑云上网络 / Regional router for flexible network topology |
| 应用型负载均衡 ALB | Application Load Balancer | 面向7层互联网应用的负载均衡服务 / Layer 7 application load balancing |

#### 混合云网络 (Hybrid Cloud Networking)
| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 专线连接 | Direct Connect | 连接本地数据中心与云上网络的高速专属通道 / Dedicated high-speed connection to cloud |
| VPN 连接 | VPN Connection | 在Internet中建立临时、安全、可靠的通信隧道 / Secure VPN tunnel over Internet |

#### 跨地域网络 (Cross-Region Networking)
| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 云企业网 CEN | Cloud Enterprise Network | 提供云上网络实例之间高速稳定的网络互通 / High-speed interconnection between cloud networks |
| 内容分发网络 CDN | Content Delivery Network | 全球加速节点，为多种内容提供高性能加速服务 / Global content delivery acceleration |
| 全站加速 DCDN | Dynamic Content Delivery Network | 为API和互联网应用提供全链路网络加速 / Full-site acceleration for dynamic content |
| 全球加速 GA | Global Accelerator | 为游戏、协同办公提供全球网络加速服务 / Global network acceleration for gaming and collaboration |

---

### 📊 七、大数据 (Big Data)

| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| E-MapReduce | E-MapReduce | 云原生开源大数据平台 / Cloud-native open-source big data platform |
| 大数据研发治理套件 DataLeap | DataLeap | 一站式数据中台套件 / One-stop data platform suite |
| 流式计算 Flink 版 | Flink Streaming | 云原生全托管实时数据处理分析服务 / Cloud-native managed real-time data processing |
| ByteHouse | ByteHouse | 极致性能弹性伸缩的分析型数据库 / High-performance analytical database |

---

### 🎬 八、视频云 (Video Cloud)

| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 视频直播 | Live Streaming | 为企业和个人提供安全、稳定、专业的云端直播服务 / Secure and stable live streaming service |
| 视频点播 VOD | Video on Demand | 提供音视频上传、存储、转码、播放等一站式服务 / End-to-end video on demand service |
| 实时音视频 RTC | Real-Time Communication | 提供实时音视频通信能力 / Real-time audio and video communication |
| 智能美化特效 | Visual Effects | 提供图像视频美化和计算机视觉算法能力 / Image and video beautification and CV capabilities |

---

### 🔒 九、安全 (Security)

#### 大模型安全 (LLM Security)
| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 安全运营智能体 | Security Operations Agent | 7X24小时值守的企业安全专家 / 24/7 security operations agent |
| 大模型应用防火墙 | LLM Application Firewall | 防护算力DDoS、提示词注入、敏感数据泄露 / Protection against LLM-specific threats |
| Jeddak AICC | Jeddak AICC | 芯片级全链路加密，实现敏感数据流转安全 / Chip-level full-link encryption |
| 智能体安全防护平台 | Agent Security Platform | 为企业智能体业务提供全生命周期安全防护 / End-to-end agent security protection |
| 大模型安全测评 | LLM Security Assessment | 对标TC260及OWASP标准的内容安全测评 / LLM security assessment platform |

#### 办公安全 (Office Security)
| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 飞连 | Feilian | AI时代的办公安全平台 / AI-era office security platform |

#### 云安全 (Cloud Security)
| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| Web 应用防火墙 WAF | Web Application Firewall | 有效防御恶意入侵和攻击，保障数据安全 / Defense against malicious attacks |
| 云安全中心 | Security Center | 集资产管理、威胁检测、智能分析于一体的安全运营平台 / Integrated security operations platform |
| 云堡垒机 | Bastion Host | 4A统一的运维安全审计平台 / 4A unified O&M security audit platform |

#### 数据安全 (Data Security)
| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 可信隐私计算平台 | Trusted Privacy Computing | 基于多方安全计算、联邦学习的隐私计算方案 / Privacy-preserving computing platform |

---

### 📞 十、企业服务与云通信 (Enterprise Services & Cloud Communication)

| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 短信服务 SMS | Short Message Service | 安全可靠、便捷高效的全球短信服务 / Secure and efficient global SMS service |
| 邮件服务 | Email Service | 稳定可靠的邮件发送服务 / Stable and reliable email service |
| TrafficRoute DNS 套件 | TrafficRoute DNS Suite | 安全、可靠、快速的DNS及全局流量管理服务 / Secure and reliable DNS and GTM service |

---

### 🔧 十一、管理与治理 (Management & Governance)

| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 访问控制 IAM | Identity and Access Management | 提供安全的身份认证和权限管理 / Secure identity and access management |
| 云监控 CloudMonitor | CloudMonitor | 全方位监控云资源性能和运行状况 / Comprehensive cloud resource monitoring |
| 云拨测 | Cloud Dial-test | 通过全球监测节点模拟用户访问 / Global monitoring for user experience |
| 操作审计 ActionTrail | ActionTrail | 记录和审计账号下的所有API调用 / Record and audit all API calls |

---

## Step 2: Search for Product Information (搜索产品信息)

### 2.1 构建搜索查询 / Construct Search Queries

根据目标产品，使用以下搜索模板查找官方信息：

**产品首页搜索 / Product Homepage Search**:
```
site:volcengine.com [product-name] 产品首页
site:volcengine.com/product [product-code]
```

**文档搜索 / Documentation Search**:
```
site:volcengine.com/docs [product-name] 产品简介
site:volcengine.com/docs [product-name] 快速入门
site:volcengine.com/docs [product-name] API参考
```

**定价搜索 / Pricing Search**:
```
site:volcengine.com [product-name] 定价
site:volcengine.com/docs [product-name] 计费说明
```

**最佳实践搜索 / Best Practices Search**:
```
site:volcengine.com/docs [product-name] 最佳实践
site:volcengine.com [product-name] 使用场景
```

### 2.2 执行搜索 / Execute Search

使用 `WebSearch` 工具执行上述查询，获取官方文档和产品页面的URL。

---

## Step 3: Retrieve and Extract Information (获取并提取信息)

### 3.1 获取产品首页信息 / Retrieve Product Homepage Info

访问产品首页获取核心信息：
- **官方URL格式**: `https://www.volcengine.com/product/[product-code]`
- 使用 `Browser Navigate` 或 `WebFetch` 访问页面

**提取信息 / Information to Extract**:
1. **产品标语 (Tagline)**: 一句话价值主张
2. **核心功能 (Core Features)**: 主要能力列表
3. **应用场景 (Use Cases)**: 典型应用案例
4. **产品优势 (Advantages)**: 差异化优势
5. **架构图 (Architecture)**: 技术架构概述

### 3.2 获取技术文档 / Retrieve Technical Documentation

**文档URL格式 / Documentation URL Format**:
- 产品简介: `https://www.volcengine.com/docs/[product-code]/introduction/`
- 快速入门: `https://www.volcengine.com/docs/[product-code]/getting-started/`
- API参考: `https://www.volcengine.com/docs/[product-code]/api-reference/`
- 计费说明: `https://www.volcengine.com/docs/[product-code]/billing/`

**常见产品代码 / Common Product Codes**:
| 产品 | 代码 |
|------|------|
| 云服务器 ECS | ecs |
| 对象存储 TOS | tos |
| 云数据库 MySQL | rds_mysql |
| 容器服务 VKE | vke |
| 私有网络 VPC | vpc |
| 内容分发网络 CDN | cdn |

### 3.3 提取关键参数 / Extract Key Parameters

从产品文档中提取：
- **规格参数 (Specifications)**: 实例类型、性能指标、资源限制
- **定价信息 (Pricing)**: 计费模式、单价、免费额度
- **技术参数 (Technical Parameters)**: 配置选项、支持协议
- **限制说明 (Limits)**: 配额限制、使用限制

---

## Step 4: Integrate and Present Results (整合并呈现结果)

### 4.1 信息整合规则 / Information Integration Rules

1. **优先级 / Priority**:
   - 官方文档 > 产品首页 > 第三方来源
   - 最新版本 > 旧版本

2. **冲突处理 / Conflict Resolution**:
   - 以官方文档为准
   - 标注信息来源和时间

3. **完整性检查 / Completeness Check**:
   - 确保所有关键信息已填充
   - 缺失信息标注为"[未在公开资料中找到]"

### 4.2 输出模板 / Output Template

```markdown
# [产品中文名] | [Product English Name]

## 产品概述 (Product Overview)

**产品标语 (Tagline)**: [一句话描述]

**产品描述 (Description)**:
[中文描述]

[English Description]

**核心功能 (Core Features)**:
- [功能1] | [Feature 1]
- [功能2] | [Feature 2]
- ...

**应用场景 (Use Cases)**:
1. [场景1] | [Use Case 1]
2. [场景2] | [Use Case 2]
- ...

---

## 产品规格 (Specifications)

### 实例类型 / Instance Types
| 类型 (Type) | 规格 (Spec) | 适用场景 (Use Case) |
|------------|------------|-------------------|
| [类型1] | [规格1] | [场景1] |

### 支持地域 / Supported Regions
- [地域1] | [Region 1]
- [地域2] | [Region 2]

---

## 定价信息 (Pricing)

### 计费模式 / Billing Models
- **按量计费 (Pay-as-you-go)**: [描述]
- **包年包月 (Subscription)**: [描述]

### 价格详情 / Price Details
| 资源类型 | 规格 | 价格 |
|---------|------|------|
| [资源] | [规格] | [价格] |

### 免费额度 / Free Tier
[免费额度说明]

---

## 快速入门 (Quick Start)

### 前提条件 (Prerequisites)
- [条件1] | [Requirement 1]
- [条件2] | [Requirement 2]

### 入门步骤 (Getting Started)
1. [步骤1] | [Step 1]
2. [步骤2] | [Step 2]

---

## 开发参考 (Development Reference)

### API 概览 / API Overview
**服务端点 / Service Endpoint**: `https://[service].volcengineapi.com`

### SDK 支持 / SDK Support
- **Java**: [Maven依赖]
- **Python**: [pip安装]
- **Go**: [go get]

### 代码示例 / Code Example
```python
# 示例代码
import volcenginesdk

client = volcenginesdk.Client(
    access_key='<your-access-key-id>',
    secret_key='<your-secret-key-secret>',
    region='<your-region>'
)
```

---

## 相关资源 (Related Resources)

### 文档链接 / Documentation Links
- [产品文档](https://www.volcengine.com/docs/[product])
- [API参考](https://www.volcengine.com/docs/[product]/api-reference)

### 相关产品 / Related Products
- [产品1] - [描述]
- [产品2] - [描述]
```

---

## Important Notes (重要说明)

### 信息准确性 / Information Accuracy
- 所有信息来源于火山引擎官方公开文档
- 定价和规格可能变动，请以官网为准
- 部分详细参数可能需要登录后查看

### 工具限制 / Tool Limitations
- `WebFetch` 可能对部分动态页面返回错误
- 建议使用 `WebSearch` + `Browser Navigate` 组合
- 搜索摘要通常足以回答基础查询

### 凭证安全 / Credential Security
所有代码示例使用占位符：
- `<your-access-key-id>` - Access Key ID
- `<your-secret-key-secret>` - Secret Access Key
- `<your-region>` - 地域ID (如 cn-beijing)

---

## Official Resources (官方资源)

- **官方网站**: https://www.volcengine.com/
- **产品目录**: https://www.volcengine.com/product
- **帮助中心**: https://www.volcengine.com/support
- **开发者社区**: https://www.volcengine.com/community
