# Volcano Engine Product Query Examples | 火山引擎产品查询示例

This document provides practical examples demonstrating how to use the Volcano Engine Product Query Skill to retrieve comprehensive product information from official sources.

本文档提供实用示例，演示如何使用火山引擎产品查询技能从官方渠道获取全面的产品信息。

---

## Example 1: Single Product Query - ECS | 示例1：单个产品查询 - 云服务器

### User Query | 用户查询
"请帮我查询火山引擎云服务器(ECS)的详细信息，包括规格、定价和快速入门指南。"

### Skill Execution Steps | 技能执行步骤

#### Step 1: Identify Product | 识别产品
- **产品名称 (Product Name)**: 云服务器 ECS | Elastic Compute Service
- **产品类别 (Category)**: 计算 (Compute) > 弹性计算 (Elastic Compute)
- **产品代码 (Product Code)**: ecs
- **官方URL**: https://www.volcengine.com/product/ecs

#### Step 2: Construct Search Queries | 构建搜索查询
```
site:volcengine.com 云服务器 产品首页
site:volcengine.com/docs 云服务器 产品简介
site:volcengine.com/docs 云服务器 功能概览
site:volcengine.com 云服务器 定价
site:volcengine.com/docs 云服务器 快速入门
site:volcengine.com/docs 云服务器 API参考
```

#### Step 3: Retrieve Product Information | 获取产品信息

**Product Homepage | 产品首页**:
- URL: https://www.volcengine.com/product/ecs
- Use `Browser Navigate` to visit and extract core information

**Key Information Extracted | 提取的关键信息**:
- **产品标语 (Tagline)**: 提供稳定的弹性计算服务，通过实时增减计算资源，适应业务变动，降低维护成本
- **核心功能 (Core Features)**: 按需申请、弹性易用、高性能网络存储
- **实例规格 (Instance Types)**: 通用型、计算型、内存型、本地SSD型、大数据型、弹性裸金属型
- **计费方式 (Billing)**: 包年包月、按量计费、抢占式实例

#### Step 4: Retrieve Documentation | 获取技术文档

**Documentation URLs | 文档链接**:
- 产品简介: https://www.volcengine.com/docs/6396/67701
- 功能概览: https://www.volcengine.com/docs/6396/1208719
- 应用场景: https://www.volcengine.com/docs/6396/67703

#### Step 5-7: Present Results | 呈现结果

```markdown
# 云服务器 ECS | Elastic Compute Service

## 产品概述 (Product Overview)

**产品标语 (Tagline)**: 
提供稳定的弹性计算服务，通过实时增减计算资源，适应业务变动，降低维护成本
/ Provide stable elastic computing services, adapting to business changes by adjusting computing resources in real-time, reducing maintenance costs

**产品描述 (Description)**:
云服务器（Elastic Compute Service，ECS）是一种由CPU、内存、云盘等资源组成的资源集合，每一种资源都会逻辑对应到数据中心的计算硬件实体。您可以结合自己的需求申请对应大小、不同规格的资源，用于运行不同的业务负载，而无需关注硬件服务器的位置和状态。

Elastic Compute Service (ECS) is a collection of resources composed of CPU, memory, cloud disks, and other components. Each resource logically corresponds to computing hardware entities in the data center. You can apply for resources of corresponding sizes and different specifications according to your needs to run different business workloads without worrying about the location and status of hardware servers.

**核心功能 (Core Features)**:
- **按需申请 (On-demand Provisioning)**: 提供丰富多样的计算规格，包括通用型、计算型、内存型、本地SSD型、大数据型、弹性裸金属型等
  / Provide diverse computing specifications including general purpose, compute optimized, memory optimized, local SSD, big data, and elastic bare metal types
- **弹性易用 (Elastic and Easy-to-use)**: 提供计算、存储、网络的弹性扩展能力以及灵活的计费方式
  / Provide elastic scaling capabilities for computing, storage, and networking with flexible billing methods
- **高性能网络存储 (High-performance Network Storage)**: 配备高性能SSD、HDD本地盘存储，满足对存储I/O有较高要求的场景
  / Equipped with high-performance SSD and HDD local storage to meet scenarios with high storage I/O requirements

**应用场景 (Use Cases)**:
1. **高主频计算场景 (High-frequency Computing)**: 计算密集型、高吞吐量应用场景，如科学计算、基因工程、EDA、游戏动画、生物制药等
   / Compute-intensive, high-throughput scenarios such as scientific computing, genetic engineering, EDA, gaming animation, biopharmaceuticals
2. **模型训练场景 (Model Training)**: 搭载V100、A100、A30等GPU显卡的GPU型实例适用于AI模型训练场景
   / GPU instances with V100, A100, A30 GPUs for AI model training scenarios
3. **应用推理场景 (Inference)**: 搭载T4、A10等显卡的GPU实例为AI推理提供高效能比的加速能力
   / GPU instances with T4, A10 GPUs provide efficient acceleration for AI inference

---

## 产品规格 (Specifications)

### 实例规格族 (Instance Families)
| 规格族 (Family) | 类型 (Type) | 描述 (Description) | 适用场景 (Use Case) |
|----------------|------------|-------------------|-------------------|
| 通用型 (General Purpose) | ecs.g1 | 计算、内存、网络性能均衡 | Web服务器、中小型数据库 |
| 计算型 (Compute Optimized) | ecs.c1 | 高CPU性能 | 批处理、游戏服务器 |
| 内存型 (Memory Optimized) | ecs.r1 | 大内存容量 | 内存数据库、缓存 |
| GPU型 (GPU) | ecs.gpu | NVIDIA GPU支持 | AI/ML训练、图形渲染 |
| 高主频型 (High Frequency) | ecs.hf | 高主频CPU | 游戏、金融建模 |
| 弹性裸金属 (Bare Metal) | ecs.bm | 物理机性能 | 高性能计算、特殊场景 |

### 支持地域 (Supported Regions)
- 华北2 (北京) | cn-beijing
- 华东2 (上海) | cn-shanghai
- 华南1 (广州) | cn-guangzhou
- 华东1 (杭州) | cn-hangzhou
- 西南1 (成都) | cn-chengdu
- 中国香港 | cn-hongkong
- 新加坡 | ap-southeast-1

---

## 定价信息 (Pricing)

### 计费模式 (Billing Models)
- **按量计费 (Pay-as-you-go)**: 按秒计费，无需预付款，适合临时性、突发性业务
  / Billed by the second, no upfront payment, suitable for temporary and burst workloads
- **包年包月 (Subscription)**: 预付费模式，享受最高30%折扣，适合长期稳定业务
  / Prepaid model with up to 30% discount, suitable for long-term stable workloads
- **抢占式实例 (Spot Instances)**: 最高享受90%折扣，适合可中断的应用场景
  / Up to 90% discount, suitable for interruptible applications

### 价格示例 (Price Examples) - 参考价格
| 实例类型 | vCPU | 内存 | 按量计费 | 包年包月 |
|---------|------|------|---------|---------|
| 通用型 ecs.g1.large | 2 | 8 GiB | ¥0.35/小时 | ¥168/月 |
| 计算型 ecs.c1.xlarge | 4 | 8 GiB | ¥0.52/小时 | ¥249/月 |
| 内存型 ecs.r1.xlarge | 4 | 32 GiB | ¥0.78/小时 | ¥374/月 |

### 成本优化建议 (Cost Optimization Tips)
1. 长期稳定业务选择包年包月，享受折扣
2. 可中断应用使用抢占式实例，大幅降低成本
3. 启用弹性伸缩，按需调整资源
4. 定期监控资源使用率，及时释放闲置资源

---

## 快速入门 (Quick Start)

### 前提条件 (Prerequisites)
- 火山引擎账号已完成实名认证
- 账号余额充足或已配置支付方式
- 已创建私有网络(VPC)和子网

### 创建ECS实例 (Create ECS Instance)

**通过控制台 (Via Console)**:
1. 登录火山引擎控制台
2. 导航至 计算 > 云服务器
3. 点击"创建实例"
4. 选择地域、可用区、实例规格、镜像、存储
5. 配置网络、安全组、登录方式
6. 确认配置并创建

**通过API (Via API)**:
```python
import volcenginesdkcore
from volcenginesdkecs import ECSApi, RunInstancesRequest

# 初始化客户端
configuration = volcenginesdkcore.Configuration()
configuration.ak = '<your-access-key-id>'
configuration.sk = '<your-secret-key-secret>'
configuration.region = 'cn-beijing'

api_client = volcenginesdkecs.ApiClient(configuration)
ecs_api = ECSApi(api_client)

# 创建实例请求
request = RunInstancesRequest(
    zone_id='cn-beijing-a',
    instance_type='ecs.g1.large',
    image_id='image-xxx',
    instance_charge_type='PostPaid',
    vpc_id='vpc-xxx',
    subnet_id='subnet-xxx',
    security_group_ids=['sg-xxx'],
    instance_name='my-ecs-instance'
)

response = ecs_api.run_instances(request)
print(f"实例创建成功: {response.instance_ids}")
```

### 连接实例 (Connect to Instance)
- **Linux**: 使用SSH密钥或密码登录
  ```bash
  ssh -i <私钥文件> root@<实例IP>
  ```
- **Windows**: 使用RDP客户端连接

---

## 开发参考 (Development Reference)

### API 概览 (API Overview)
**服务端点 (Service Endpoint)**: `https://ecs.volcengineapi.com`

**常用操作 (Common Operations)**:
| 操作 (Operation) | API Action | 描述 (Description) |
|-----------------|------------|-------------------|
| 创建实例 | RunInstances | 创建新的ECS实例 |
| 查询实例 | DescribeInstances | 查询实例详情 |
| 启动实例 | StartInstances | 启动已停止的实例 |
| 停止实例 | StopInstances | 停止运行中的实例 |
| 释放实例 | DeleteInstances | 释放/删除实例 |
| 变更配置 | ModifyInstanceSpec | 修改实例规格 |

### SDK 支持 (SDK Support)
- **Java**: `volcengine-sdk-java`
- **Python**: `volcenginesdk`
- **Go**: `github.com/volcengine/volcengine-go-sdk`
- **Node.js**: `@volcengine/volcengine-sdk`

### CLI 示例 (CLI Example)
```bash
# 配置凭证
volcengine configure

# 列出实例
volcengine ecs describe-instances

# 创建实例
volcengine ecs run-instances \
  --instance-type ecs.g1.large \
  --image-id image-xxx \
  --zone-id cn-beijing-a
```

---

## 相关资源 (Related Resources)

### 文档链接 (Documentation Links)
- [云服务器产品文档](https://www.volcengine.com/docs/ecs)
- [ECS API文档](https://www.volcengine.com/docs/ecs/api-reference)
- [定价详情](https://www.volcengine.com/pricing/ecs)

### 相关产品 (Related Products)
- **私有网络 VPC**: 为ECS实例提供网络隔离
- **弹性块存储 EBS**: 持久化块存储
- **应用型负载均衡 ALB**: 流量分发
- **云监控 CloudMonitor**: 实例监控告警
- **弹性伸缩**: 自动容量调整
```

---

## Example 2: Product Comparison - veDB MySQL vs RDS MySQL | 示例2：产品对比 - veDB MySQL vs RDS MySQL

### User Query | 用户查询
"火山引擎的veDB MySQL和云数据库MySQL版有什么区别？我应该选择哪个？"

### Skill Execution Steps | 技能执行步骤

#### Step 1: Identify Products | 识别产品
- **产品A**: 云数据库 veDB MySQL 版 | veDB MySQL
- **产品B**: 云数据库 MySQL 版 | RDS for MySQL
- **类别**: 数据库 (Database) > 关系型数据库 (Relational Database)

#### Step 2: Construct Comparison Queries | 构建对比查询
```
site:volcengine.com veDB MySQL 产品简介
site:volcengine.com 云数据库MySQL 产品简介
site:volcengine.com/docs veDB MySQL 什么是veDB
site:volcengine.com/docs 云数据库MySQL 产品简介
```

#### Step 3-7: Present Comparison Results | 呈现对比结果

```markdown
# veDB MySQL vs 云数据库 MySQL 版 | Product Comparison

## 概览对比 (Overview Comparison)

| 对比项 (Aspect) | veDB MySQL | 云数据库 MySQL 版 (RDS) |
|----------------|-----------|------------------------|
| **架构 (Architecture)** | 分布式、云原生 | 传统单节点或主从架构 |
| **目标负载 (Target Workload)** | 大规模、高并发 | 中小规模、通用场景 |
| **MySQL兼容性 (Compatibility)** | 100%兼容 | 100%兼容 |
| **最大存储 (Max Storage)** | PB级 | 数十TB |
| **扩展方式 (Scaling)** | 水平扩展 | 垂直扩展 |

## 详细对比 (Detailed Comparison)

### 1. 架构差异 (Architecture Differences)

**veDB MySQL**:
- 云原生分布式架构 (Cloud-native distributed architecture)
- 计算存储分离 (Compute-storage separation)
- Shared-nothing分布式存储
- 自动分片和负载均衡
- 新一代分布式关系型数据库，提供极致性价比

**云数据库 MySQL 版 (RDS)**:
- 传统单节点或主从架构
- 本地存储或云盘存储
- 垂直扩展（升级实例规格）
- 手动管理只读副本

### 2. 性能与扩展性 (Performance & Scalability)

| 特性 (Feature) | veDB MySQL | RDS MySQL |
|---------------|-----------|-----------|
| 计算扩展 | 水平扩展（添加节点） | 垂直扩展（升级规格） |
| 存储扩展 | 自动在线扩展 | 手动扩展，可能需要迁移 |
| 读扩展 | 自动只读副本 | 手动创建只读副本 |
| 写扩展 | 分布式写入 | 单点写入 |
| 最大连接数 | 100,000+ | 取决于实例规格 |
| QPS | 1,000,000+ | 100,000+（取决于规格） |

### 3. 适用场景 (Use Cases)

**选择 veDB MySQL 的场景 (Choose veDB MySQL when)**:
- 数据量达到PB级的大规模应用
- 高并发场景（10,000+并发连接）
- 业务快速增长，需要弹性扩展
- 关键业务系统，需要99.99%可用性
- 需要自动读写分离

**选择 RDS MySQL 的场景 (Choose RDS MySQL when)**:
- 中小规模应用
- 业务增长可预测的传统工作负载
- 预算敏感的场景
- 简单的架构需求
- 熟悉的管理体验

### 4. 定价对比 (Pricing Comparison)

| 组件 (Component) | veDB MySQL | RDS MySQL |
|-----------------|-----------|-----------|
| 计算 | 按ACU（自适应容量单元）计费 | 按实例规格计费 |
| 存储 | 独立存储计费 | 包含或独立计费 |
| 最低成本 | 入门门槛较高 | 入门门槛较低 |
| 大规模成本 | 更具成本效益 | 大规模时成本较高 |

### 5. 管理复杂度 (Management Complexity)

| 方面 (Aspect) | veDB MySQL | RDS MySQL |
|--------------|-----------|-----------|
| 部署 | 简单（默认分布式） | 简单（单节点） |
| 备份 | 自动分布式备份 | 需手动配置 |
| 监控 | 内置分布式指标 | 标准监控 |
| 维护 | 最少（托管） | 定期维护窗口 |

## 选择建议 (Recommendation)

### 初创/小企业 (Startups/Small Business)
**推荐**: 云数据库 MySQL 版 (RDS MySQL)
- 初始成本较低
- 管理更简单
- 满足中等负载需求

### 企业/高增长业务 (Enterprises/High Growth)
**推荐**: 云数据库 veDB MySQL 版
- 面向未来的架构
- 自动弹性扩展
- 大规模时成本效益更好
- 更高可用性

### 迁移路径 (Migration Path)
火山引擎提供从RDS MySQL升级到veDB MySQL的迁移工具：
1. 使用数据库传输服务(DTS)进行在线迁移
2. 数据同步，最小化停机时间
3. 数据格式兼容
```

---

## Example 3: Pricing Analysis - Object Storage TOS | 示例3：定价分析 - 对象存储TOS

### User Query | 用户查询
"我想了解火山引擎对象存储(TOS)的定价详情，包括存储费用、流量费用和请求费用。"

### Skill Execution Steps | 技能执行步骤

#### Step 1: Identify Product | 识别产品
- **产品名称**: 对象存储 TOS | Tinder Object Storage
- **产品代码**: tos
- **类别**: 存储 (Storage)

#### Step 2: Construct Pricing Queries | 构建定价查询
```
site:volcengine.com 对象存储 定价
site:volcengine.com/docs 对象存储 计费概述
site:volcengine.com/docs 对象存储 计费项说明
site:volcengine.com TOS 免费额度
```

#### Step 3-7: Present Pricing Analysis | 呈现定价分析

```markdown
# 对象存储 TOS 定价分析 | Object Storage (TOS) Pricing Analysis

## 计费组成 (Pricing Components)

对象存储TOS定价由四个主要部分组成：
Volcano Engine Object Storage (TOS) pricing consists of four main components:

### 1. 存储容量费用 (Storage Fees)
根据存储类型和实际使用量计费
Billed based on storage class and actual storage usage

| 存储类型 (Storage Class) | 中文名称 | 价格 (元/GB/月) | 适用场景 (Use Case) |
|------------------------|---------|----------------|-------------------|
| 标准存储 (Standard) | Standard | ¥0.12 | 频繁访问的数据 |
| 低频存储 (Infrequent Access) | IA | ¥0.08 | 每月访问一次的数据 |
| 归档存储 (Archive) | Archive | ¥0.033 | 很少访问的备份数据 |
| 冷归档存储 (Cold Archive) | Cold Archive | ¥0.015 | 长期归档数据 |

### 2. 流量费用 (Traffic Fees)
外网流出流量计费
Billed for outbound data transfer

| 流量类型 (Traffic Type) | 中文名称 | 价格 (元/GB) |
|------------------------|---------|-------------|
| 外网流出流量-中国大陆 | Internet Outbound - CN | ¥0.80 |
| 外网流出流量-国际 | Internet Outbound - Global | ¥0.80 |
| CDN回源流量 | CDN Back-to-Origin | ¥0.15 |
| 跨区域复制流量 | Cross-Region Replication | ¥0.50 |

**注意**: 入站流量免费 / Inbound traffic is free

### 3. 请求费用 (Request Fees)
按每万次请求计费
Billed per 10,000 requests

| 请求类型 (Request Type) | 中文名称 | 价格 (元/万次) |
|------------------------|---------|---------------|
| PUT/COPY/POST/LIST | 写请求 | ¥0.01 |
| GET/HEAD | 读请求 | ¥0.01 |
| DELETE | 删除请求 | 免费 |

### 4. 数据处理费用 (Data Processing Fees)

| 操作 (Operation) | 中文名称 | 价格 |
|-----------------|---------|------|
| 图片处理 | Image Processing | ¥1.00/万次 |
| 低频数据取回 | IA Data Retrieval | ¥0.15/GB |
| 归档数据取回 | Archive Data Retrieval | ¥0.30/GB |
| 冷归档数据取回 | Cold Archive Data Retrieval | ¥0.60/GB |

---

## 成本计算示例 (Cost Calculation Example)

### 场景 (Scenario)
- 存储容量: 10 TB 标准存储
- 每月外网流出流量: 5 TB
- 每月请求次数: 1000万次 (800万GET, 200万PUT)
- 图片处理: 100万张

### 计算 (Calculation)

| 计费项 | 计算公式 | 费用 |
|-------|---------|------|
| 存储费用 | 10,000 GB × ¥0.12 | ¥1,200 |
| 流量费用 | 5,000 GB × ¥0.80 | ¥4,000 |
| GET请求 | 800万 ÷ 1万 × ¥0.01 | ¥8 |
| PUT请求 | 200万 ÷ 1万 × ¥0.01 | ¥2 |
| 图片处理 | 100万 ÷ 1万 × ¥1.00 | ¥100 |
| **月度总计** | | **¥5,310** |

---

## 成本优化策略 (Cost Optimization Strategies)

### 1. 存储类型优化 (Storage Class Optimization)
- 使用生命周期策略自动转换对象
- 标准存储 → 低频存储（30天后）
- 低频存储 → 归档存储（90天后）
- 潜在节省: 50-70%

### 2. 流量优化 (Traffic Optimization)
- 使用CDN分发内容（减少源站流量）
- 启用传输加速用于远距离传输
- 内网传输使用私网连接

### 3. 请求优化 (Request Optimization)
- 批量操作减少请求次数
- 大文件使用分片上传
- 实现客户端缓存

### 4. 免费额度利用 (Free Tier Utilization)
火山引擎为新用户提供免费额度：
- 标准存储: 50 GB/月免费
- 外网流出流量: 10 GB/月免费
- 请求次数: 10万次/月免费

---

## 定价计算器 (Pricing Calculator)

使用官方定价计算器获取准确估算：
[火山引擎定价计算器](https://www.volcengine.com/pricing)

详细定价请参考：
[对象存储计费说明](https://www.volcengine.com/docs/tos/billing)
```

---

## Example 4: API Integration - Creating VKE Cluster | 示例4：API集成 - 创建VKE集群

### User Query | 用户查询
"我需要使用API创建火山引擎容器服务(VKE)集群，请提供完整的代码示例。"

### Skill Execution Steps | 技能执行步骤

#### Step 1: Identify Product | 识别产品
- **产品名称**: 容器服务 VKE | Volcano Kubernetes Engine
- **产品代码**: vke
- **类别**: 容器与中间件 (Container & Middleware)

#### Step 2: Construct API Documentation Queries | 构建API文档查询
```
site:volcengine.com/docs 容器服务 API
site:volcengine.com/docs vke CreateCluster
site:volcengine.com 容器服务 SDK
```

#### Step 3-7: Present API Integration Guide | 呈现API集成指南

```markdown
# VKE API 集成指南 | VKE API Integration Guide

## 前提条件 (Prerequisites)

1. 火山引擎账号并开通VKE访问权限
2. 已配置Access Key ID和Secret Key
3. 已创建VPC和子网
4. 具备VKE操作的IAM权限

## API 概览 (API Overview)

**服务端点 (Service Endpoint)**: `https://vke.volcengineapi.com`

**认证方式 (Authentication)**:
- 签名版本: volc-auth
- 必需请求头: `Authorization`, `X-Date`

## 代码示例 (Code Examples)

### Python SDK 示例 (Python SDK Example)

```python
import volcenginesdkcore
from volcenginesdkvke import VKEApi, CreateClusterRequest
from volcenginesdkvke.models import (
    ClusterConfig,
    NodeConfig,
    PodNetworkConfig,
    ServiceNetworkConfig
)

# 初始化配置
configuration = volcenginesdkcore.Configuration()
configuration.ak = '<your-access-key-id>'
configuration.sk = '<your-secret-key-secret>'
configuration.region = 'cn-beijing'
configuration.endpoint = 'https://vke.volcengineapi.com'

# 创建API客户端
api_client = volcenginesdkvke.ApiClient(configuration)
vke_api = VKEApi(api_client)

# 构建创建集群请求
request = CreateClusterRequest(
    cluster_name="my-vke-cluster",
    kubernetes_version="v1.28",
    vpc_id="vpc-xxx",
    subnet_ids=["subnet-xxx"],
    cluster_config=ClusterConfig(
        node_config=NodeConfig(
            instance_type="ecs.g1.large",
            system_volume_size=40,
            system_volume_type="ESSD_PL0",
            node_count=3
        ),
        pod_network_config=PodNetworkConfig(
            pod_cidr="172.16.0.0/16",
            max_pod_per_node=64
        ),
        service_network_config=ServiceNetworkConfig(
            service_cidr="192.168.0.0/16"
        )
    ),
    tags=[
        {"key": "Environment", "value": "Production"},
        {"key": "Project", "value": "MyApp"}
    ]
)

try:
    response = vke_api.create_cluster(request)
    print(f"集群创建成功!")
    print(f"集群ID: {response.cluster_id}")
    print(f"集群名称: {response.cluster_name}")
    print(f"状态: {response.status}")
except Exception as e:
    print(f"创建集群错误: {e}")
```

### Java SDK 示例 (Java SDK Example)

```java
import com.volcengine.vke.VKEClient;
import com.volcengine.vke.model.*;

public class VKEClusterCreator {
    public static void main(String[] args) {
        // 初始化客户端
        VKEClient client = VKEClient.builder()
            .accessKey("<your-access-key-id>")
            .secretKey("<your-secret-key-secret>")
            .region("cn-beijing")
            .build();

        // 创建集群请求
        CreateClusterRequest request = new CreateClusterRequest()
            .clusterName("my-vke-cluster")
            .kubernetesVersion("v1.28")
            .vpcId("vpc-xxx")
            .addSubnetIdsItem("subnet-xxx")
            .clusterConfig(new ClusterConfig()
                .nodeConfig(new NodeConfig()
                    .instanceType("ecs.g1.large")
                    .systemVolumeSize(40)
                    .systemVolumeType("ESSD_PL0")
                    .nodeCount(3)
                )
                .podNetworkConfig(new PodNetworkConfig()
                    .podCidr("172.16.0.0/16")
                    .maxPodPerNode(64)
                )
                .serviceNetworkConfig(new ServiceNetworkConfig()
                    .serviceCidr("192.168.0.0/16")
                )
            );

        try {
            CreateClusterResponse response = client.createCluster(request);
            System.out.println("集群创建成功: " + response.getClusterId());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
```

### Go SDK 示例 (Go SDK Example)

```go
package main

import (
    "context"
    "fmt"
    "github.com/volcengine/volcengine-go-sdk/service/vke"
    "github.com/volcengine/volcengine-go-sdk/volcengine"
    "github.com/volcengine/volcengine-go-sdk/volcengine/credentials"
    "github.com/volcengine/volcengine-go-sdk/volcengine/session"
)

func main() {
    // 创建会话
    sess := session.Must(session.NewSession(&volcengine.Config{
        Region:      volcengine.String("cn-beijing"),
        Credentials: credentials.NewStaticCredentials(
            "<your-access-key-id>", 
            "<your-secret-key-secret>", 
            ""),
    }))

    // 创建VKE客户端
    client := vke.New(sess)

    // 创建集群输入
    input := &vke.CreateClusterInput{
        ClusterName:       volcengine.String("my-vke-cluster"),
        KubernetesVersion: volcengine.String("v1.28"),
        VpcId:             volcengine.String("vpc-xxx"),
        SubnetIds:         []*string{volcengine.String("subnet-xxx")},
        ClusterConfig: &vke.ClusterConfig{
            NodeConfig: &vke.NodeConfig{
                InstanceType:     volcengine.String("ecs.g1.large"),
                SystemVolumeSize: volcengine.Int64(40),
                SystemVolumeType: volcengine.String("ESSD_PL0"),
                NodeCount:        volcengine.Int64(3),
            },
            PodNetworkConfig: &vke.PodNetworkConfig{
                PodCidr:       volcengine.String("172.16.0.0/16"),
                MaxPodPerNode: volcengine.Int64(64),
            },
            ServiceNetworkConfig: &vke.ServiceNetworkConfig{
                ServiceCidr: volcengine.String("192.168.0.0/16"),
            },
        },
    }

    // 创建集群
    result, err := client.CreateCluster(context.TODO(), input)
    if err != nil {
        fmt.Printf("错误: %v\n", err)
        return
    }

    fmt.Printf("集群创建成功: %s\n", *result.ClusterId)
}
```

### cURL 示例 (cURL Example)

```bash
# 使用原始HTTP API创建集群
curl -X POST https://vke.volcengineapi.com/?Action=CreateCluster&Version=2022-05-12 \
  -H "Authorization: VOLC <signature>" \
  -H "X-Date: <timestamp>" \
  -H "Content-Type: application/json" \
  -d '{
    "ClusterName": "my-vke-cluster",
    "KubernetesVersion": "v1.28",
    "VpcId": "vpc-xxx",
    "SubnetIds": ["subnet-xxx"],
    "ClusterConfig": {
      "NodeConfig": {
        "InstanceType": "ecs.g1.large",
        "SystemVolumeSize": 40,
        "SystemVolumeType": "ESSD_PL0",
        "NodeCount": 3
      },
      "PodNetworkConfig": {
        "PodCidr": "172.16.0.0/16",
        "MaxPodPerNode": 64
      },
      "ServiceNetworkConfig": {
        "ServiceCidr": "192.168.0.0/16"
      }
    }
  }'
```

## 常用操作 (Common Operations)

| 操作 (Operation) | API Action | 描述 (Description) |
|-----------------|------------|-------------------|
| 创建集群 | CreateCluster | 创建新的VKE集群 |
| 查询集群 | DescribeClusters | 列出所有集群 |
| 更新集群 | UpdateCluster | 修改集群配置 |
| 删除集群 | DeleteCluster | 删除集群及资源 |
| 创建节点池 | CreateNodePool | 添加节点池到集群 |
| 扩缩容节点池 | ScaleNodePool | 调整节点池大小 |

## 错误处理 (Error Handling)

常见错误代码及解决方案：

| 错误代码 | 描述 | 解决方案 |
|---------|------|---------|
| InvalidParameter | 参数值无效 | 检查参数格式和范围 |
| ResourceNotFound | 资源未找到 | 验证VPC/子网ID |
| QuotaExceeded | 超出配额 | 申请配额提升 |
| InsufficientBalance | 余额不足 | 账户充值 |
| OperationDenied | 操作不允许 | 检查IAM权限 |

## 相关资源 (Related Resources)

- [VKE产品文档](https://www.volcengine.com/docs/vke)
- [VKE API参考](https://www.volcengine.com/docs/vke/api-reference)
- [Kubernetes最佳实践](https://www.volcengine.com/docs/vke/best-practices)
```

---

## Example 5: Architecture Recommendation - E-commerce Platform | 示例5：架构推荐 - 电商平台

### User Query | 用户查询
"我需要为电商平台设计一个基于火山引擎的架构，包括前端、后端、数据库和缓存。"

### Skill Execution Steps | 技能执行步骤

#### Step 1: Identify Required Products | 识别所需产品
分析电商需求并映射到火山引擎产品：
- **前端**: CDN + DCDN
- **后端**: ECS/VKE
- **数据库**: veDB MySQL + Redis
- **存储**: TOS
- **网络**: VPC, ALB
- **安全**: WAF, Security Center

#### Step 2: Research Each Product | 调研每个产品
对每个识别出的产品执行查询，收集规格和集成模式。

#### Step 3-7: Present Architecture Recommendation | 呈现架构推荐

```markdown
# 火山引擎电商平台架构 | E-commerce Platform Architecture on Volcano Engine

## 架构概览 (Architecture Overview)

本架构使用火山引擎服务构建可扩展、高可用的电商平台。
This architecture provides a scalable, high-availability e-commerce platform using Volcano Engine services.

```
                    [用户 Users]
                        |
                        v
                [CDN / 全站加速 DCDN]
                        |
                        v
                [WAF 安全防护]
                        |
                        v
        [应用型负载均衡 ALB]
                        |
        +----------------+----------------+
        |                                 |
        v                                 v
[Web服务器 ECS]              [API服务器 VKE]
        |                                 |
        v                                 v
   [Redis缓存]                    [veDB MySQL]
        |                          (主库+副本)
        v                                 |
   [会话存储]                           v
                             [TOS对象存储]
                             (图片、视频)
```

## 组件详情 (Component Details)

### 1. 内容分发 (Content Delivery)

**产品**: 内容分发网络 (CDN) + 全站加速 (DCDN)

**配置**:
- CDN用于静态资源（图片、CSS、JS）
- DCDN用于动态内容加速
- 全球边缘节点覆盖
- HTTPS自定义SSL证书

**定价估算**:
- CDN: ¥0.24/GB (流出流量)
- DCDN: ¥0.30/GB (动态加速)

### 2. 安全层 (Security Layer)

**产品**: Web应用防火墙 (WAF) + 云安全中心

**配置**:
- WAF防护DDoS攻击和SQL注入
- Bot管理防爬虫
- SSL/TLS传输加密
- 安全中心威胁检测

**定价估算**:
- WAF: 起价 ¥2,000/月
- 安全中心: ¥100/实例/月

### 3. 负载均衡 (Load Balancing)

**产品**: 应用型负载均衡 (ALB)

**配置**:
- 七层负载均衡
- 5秒健康检查间隔
- 会话保持确保购物车连续性
- 弹性伸缩集成

**定价估算**:
- ALB实例: ¥0.10/小时
- LCU: ¥0.05/LCU-小时

### 4. 计算层 (Compute Layer)

#### Web服务器 (Web Servers)
**产品**: 云服务器 (ECS) + 弹性伸缩

**配置**:
- 实例规格: ecs.g1.large (2 vCPU, 8GB内存)
- 最小: 2实例（多可用区）
- 最大: 20实例（弹性伸缩）
- 操作系统: veLinux

**定价估算**:
- ECS: ¥168/月/实例
- 弹性伸缩: 免费（按资源付费）

#### API服务器 (API Servers)
**产品**: 容器服务 (VKE)

**配置**:
- Kubernetes v1.28
- 3个Worker节点 (ecs.g1.xlarge)
- HPA水平Pod自动伸缩
- Ingress控制器路由

**定价估算**:
- 控制平面: 免费
- Worker节点: ¥336/月/节点

### 5. 数据库层 (Database Layer)

#### 主数据库 (Primary Database)
**产品**: 云数据库 veDB MySQL 版

**配置**:
- 分布式架构高可用
- 4 ACU (自适应计算单元)
- 500GB存储
- 自动读写分离
- 跨区域备份

**定价估算**:
- 计算: ¥1.20/ACU/小时
- 存储: ¥0.50/GB/月

#### 缓存层 (Cache Layer)
**产品**: 缓存数据库 Redis 版

**配置**:
- 主从架构
- 8GB内存
- 会话存储和热点数据缓存
- Pub/sub实时通知

**定价估算**:
- Redis: ¥320/月

### 6. 存储层 (Storage Layer)

**产品**: 对象存储 (TOS)

**配置**:
- 标准存储用于商品图片
- 低频存储用于历史订单附件
- CDN集成图片分发
- 生命周期策略成本优化

**定价估算**:
- 存储: ¥0.12/GB/月
- 请求: ¥0.01/万次

## 成本汇总 (Cost Summary)

### 月度成本估算 (Monthly Cost Estimate)

| 组件 | 配置 | 月度费用 |
|-----|------|---------|
| CDN | 1 TB流量 | ¥240 |
| WAF | 标准版 | ¥2,000 |
| ALB | 1实例 | ¥72 |
| ECS | 4实例(平均) | ¥672 |
| VKE | 3节点 | ¥1,008 |
| veDB MySQL | 4 ACU + 500GB | ¥3,730 |
| Redis | 8GB | ¥320 |
| TOS | 500GB + 请求 | ¥60 |
| 安全中心 | 7实例 | ¥700 |
| **总计** | | **¥8,802/月** |

## 扩展考虑 (Scaling Considerations)

### 水平扩展 (Horizontal Scaling)
- 基于CPU/内存指标的弹性伸缩策略
- 数据库只读副本分担读压力
- CDN全球内容分发

### 垂直扩展 (Vertical Scaling)
- 大促期间升级ECS实例规格
- 增加veDB ACU提升数据库性能
- 扩展Redis内存支持更大缓存

### 大促准备 (Peak Season Preparation)
- 预热CDN缓存
- 提前扩容ECS/VKE集群
- 启用数据库连接池
- 设置实时监控大屏

## 相关产品 (Related Products)

- **消息队列 RocketMQ**: 订单处理和异步任务
- **云监控 CloudMonitor**: 监控告警
- **日志服务**: 集中日志管理
- **大数据研发治理套件 DataLeap**: 业务分析
```

---

## Summary | 总结

These examples demonstrate the complete workflow of the Volcano Engine Product Query Skill:

这些示例演示了火山引擎产品查询技能的完整工作流程：

1. **Single Product Query (单个产品查询)**: Deep dive into one product with full specifications, pricing, and usage guides
2. **Product Comparison (产品对比)**: Side-by-side analysis of similar products for informed decision-making
3. **Pricing Analysis (定价分析)**: Detailed cost breakdown with optimization strategies
4. **API Integration (API集成)**: Complete code examples for programmatic access
5. **Architecture Design (架构设计)**: Multi-product solution architecture with cost estimates

When using this skill, always:
- Use `WebSearch` to find official documentation URLs
- Use `WebFetch` or `Browser Navigate` to retrieve detailed content
- Cross-reference multiple sources for accuracy
- Provide bilingual (Chinese/English) output
- Include credential placeholders in all code examples
