def run(inputs):
    topic = inputs.get("research_topic")
    r_type = inputs.get("research_type", "行业+产品")
    market = inputs.get("target_market", "全球")
    depth = inputs.get("depth_level", "标准")

    result = {}

    # 1. 行业定义
    result["definition"] = f"{topic}属于{r_type}调研范畴，需界定其上下游边界"

    # 2. 市场规模（模拟估算）
    result["market_size"] = "基于行业增长率+渗透率估算"

    # 3. 竞争分析
    result["competition"] = "头部品牌 + 渠道结构 + 价格带"

    # 4. 产品分析
    result["product"] = "产品形态 + 规格 + 卖点"

    # 5. 消费者
    result["consumer"] = "人群 + 场景 + 动机"

    # 6. 趋势
    result["trend"] = [
        "高端化",
        "功能化",
        "便捷化",
        "内容电商驱动"
    ]

    # 7. 机会
    result["opportunity"] = "细分人群 + 新渠道 + 新产品形态"

    # 8. 风险
    result["risk"] = "政策 + 竞争 + 成本"

    return result