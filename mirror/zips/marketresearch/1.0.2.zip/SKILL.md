---
name: market_research_super
description: 全行业通用市场调研分析Skill，支持行业、产品、品牌、渠道多维分析，输出商业决策级报告
version: 3.0.0
author: az-ai
tags:
  - 市场调研
  - 行业分析
  - 产品分析
  - 商业策略
  - 投资分析

inputs:
  - name: research_topic
    type: string
    required: true
    description: 调研主题（如：宠物食品、胶原蛋白饮料、预制菜）

  - name: research_type
    type: string
    required: false
    default: 行业+产品
    enum:
      - 行业
      - 产品
      - 品牌
      - 渠道
      - 行业+产品
    description: 调研类型

  - name: target_market
    type: string
    required: false
    default: 全球
    description: 目标市场（中国/美国/东南亚等）

  - name: depth_level
    type: string
    required: false
    default: 标准
    enum:
      - 简版
      - 标准
      - 深度
    description: 调研深度

outputs:
  - name: report
    type: markdown
    description: 市场调研报告

  - name: brief
    type: markdown
    description: 一页纸总结

  - name: ppt_outline
    type: markdown
    description: PPT大纲
---