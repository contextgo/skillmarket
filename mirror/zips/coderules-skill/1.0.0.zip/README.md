# CodeRules Skill

## 🚀 简介

CodeRules 是一个智能代码规范助手 Skill，能够让 AI 自动识别项目技术栈，加载对应的代码规范，生成严格符合最佳实践的代码。

## 📋 特性

✅ **自动识别** - 扫描项目文件，识别语言、框架、工具链
✅ **规范匹配** - 根据识别结果，自动加载对应规范
✅ **代码生成** - 生成严格符合规范的代码
✅ **代码审查** - 检查现有代码是否符合规范

## 🛠️ 支持的技术栈

### 语言规范
- TypeScript / JavaScript
- Python (3.10+)
- Go (1.21+)
- Rust
- Java

### 框架规范
- React / Next.js
- Vue / Nuxt
- Angular
- Svelte
- Django / Spring Boot

## 📖 使用方法

### 安装

```bash
# OpenClaw 用户
git clone https://github.com/你的用户名/coderules-skill
cp -r coderules-skill ~/.openclaw/skills/

# Cursor 用户
cp coderules-skill/SKILL.md .cursorrules
```

### 自动分析项目

```bash
node scripts/analyzer.js
```

### 自定义配置

在项目根目录创建 `.coderules.json`：

```json
{
  "customRules": [
    "所有 API 请求必须添加重试机制",
    "组件文件不能超过 300 行"
  ],
  "ignore": ["legacy/**/*"]
}
```

## 💡 示例

```typescript
// CodeRules 生成的 React 组件
interface UserAvatarProps {
  src: string;
  name: string;
  size?: 'sm' | 'md' | 'lg';
}

export const UserAvatar: React.FC<UserAvatarProps> = ({ src, name, size = 'md' }) => {
  const sizeMap = { sm: 32, md: 48, lg: 64 };
  return (
    <Image
      src={src}
      alt={`${name}'s avatar`}
      width={sizeMap[size]}
      height={sizeMap[size]}
      className="rounded-full"
    />
  );
};
```

## 🏗️ 架构

```
coderules-skill/
├── SKILL.md           # AI 核心指令
├── rules/             # 规范知识库
│   ├── languages/     # 语言规范
│   └── frameworks/    # 框架规范
├── scripts/           # 自动化工具
└── README.md          # 项目说明
```

## 🤝 贡献

欢迎贡献！可以：
1. 添加新的语言规范
2. 添加新的框架规范
3. 改进分析脚本
4. 提 issue 反馈问题

## 📄 许可证

MIT License