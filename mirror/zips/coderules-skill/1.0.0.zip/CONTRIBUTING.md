# 贡献指南

感谢你的兴趣！我们欢迎各种形式的贡献。

## 如何贡献

### 1. 添加新的语言规范

1. 在 `rules/languages/` 创建 `<language>.json` 文件
2. 参考现有规范的格式
3. 在 `rules/index.json` 中注册

示例规范文件：

```json
{
  "name": "LanguageName",
  "version": "1.0+",
  "priority": 70,
  "rules": {
    "naming": {
      "variables": "camelCase",
      "functions": "camelCase",
      "classes": "PascalCase"
    }
  },
  "promptTemplates": [
    "使用规范提示模板"
  ]
}
```

### 2. 添加新的框架规范

1. 在 `rules/frameworks/` 创建 `<framework>.json` 文件
2. 设置 `extends` 继承基础语言规范
3. 在 `rules/index.json` 中注册

### 3. 改进分析脚本

- 确保脚本在 Node.js 16+ 运行
- 添加足够的错误处理
- 更新测试用例

## 代码规范

- JSON 文件使用 2 空格缩进
- 注释清晰明了
- 遵循现有的命名约定

## Pull Request 流程

1. Fork 本仓库
2. 创建特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 创建 Pull Request

## 问题反馈

如果你发现问题或有建议，请：
1. 搜索现有 issue
2. 创建新的 issue
3. 详细描述问题和复现步骤

## 许可证

通过贡献代码，你同意你的代码使用 MIT 许可证。
