---
name: auto-api
description: 基于 meta.json 动态解析 API 配置,通过自然语言理解用户指令,自动匹配 API 接口、校验参数并执行调用。
---

# Auto-API 技能

---
## 读前须知

**需要认真读完全部SKILL内容，不要因为过长而粗略读取SKILL

## 用户引导流程（问"怎么用"就按这个执行）

**当用户问"如何使用"、"怎么用"、"怎么操作"、"如何使用SKILL"时，行动并逐步引导：**

### 步骤一：立即检测配置状态
```
立刻读取 meta.json → 判断配置是否存在、字段是否完整
```

### 步骤二：未配置 → 引导配置

**告诉用户：**
```
"需要先配置 API 信息才能使用，正在检测配置状态..."
"检测到尚未配置，需要提供以下信息："
```
**最后告诉用户：**
```
"你不会配我帮你配，把这些信息告诉我就行！"
```

用户提供了信息后，自动生成 meta.json 保存。
meta.json的内容请详细查看第二节。

### 步骤三：已配置 → 检测登录状态

**WeCall 流程：**
```
调用 au.check_login_status() 检查登录状态

已登录 → 告诉用户账号信息，继续下一步
未登录 → 询问账号密码，调用 au.login() 登录
```

**通用流程：**
```
看 API 文档要求
- 需要登录 → 询问登录信息
- 不需要 → 直接进入下一步
```

### 步骤四：就绪 → 告诉用户如何发指令

**告诉用户：**
```
"配置完成！你现在可以直接告诉我："
"1. 项目名 — 说名字就行，我帮你找ID"
"2. 任务名 — 必填！不说就导出全部任务数据！"
"3. 时间范围 — 昨天、上周、本月、或具体日期"
"4. 要做什么 — 导出什么报表、导入什么数据"

"示例："
"  '导出话务报表，项目 测试添加26，任务 测试任务1，昨天到今天'"
"  '导出CDR，项目ID=5727，任务ID=4406，2026年4月'"
"  '生成坐席3016的考勤报表，本周'"
"  '导出质检报表，项目名xxx，任务xxx，上月'"
```

---

## 一、总体流程(每次任务按这个顺序走)

```
第1步  读 meta.json → 判断配置是否存在?
第2步  不存在?→ 引导用户编写(见第二节场景A)
第3步  用户说配置好了?→ 验证配置(见第二节场景B)
第4步  用户要改配置?→ 引导修改(见第二节场景C)
第5步  配置就绪 → 走两套流程之一(见第三节)
```

---

## 二、meta.json 配置(步骤1-4)

### 场景A:meta.json 不存在 或 字段为空 → 引导用户编写

**检测逻辑:**
1. meta.json 文件不存在 → 需配置
2. meta.json 存在,但任意必填字段为空(Choose 除外)→ 视为未配置,需补全
   - 必填字段:need、Key、ApiUrl、ApiList、ApiUseInfo
   - **只有 Choose 可以留空 `""`,其余字段必须非空**

```
检测到 meta.json 缺少必要配置(字段为空),需要先补全。
请提供以下信息:

第一步：选择流程类型
- WeCall：使用我们产品内部的流程
- 留空(通用)：未使用产品的流程

第二步：根据选择的流程填写配置

【选择 WeCall】
| 参数 | 含义 | 怎么填 |
|------|------|--------|
| Key | 这个配置的名字 | 自己起，比如 devapi |
| need | 指定用哪个配置（匹配相对应的 Key） | 跟 Key 填一样 |
| ApiUrl | API 基础地址 | https://..... 或直接给网址自动推导 |
| ApiList | API 文档地址 | https://..... 或直接给网址自动推导 |
| ApiUseInfo | 指定调用的脚本文件 | Use/xxx.txt 或 Use/xxx.py |
| Choose | 固定填 | WeCall |

只需给一个网址，例如 https://yy.xxxx.com
   → ApiUrl=https://yyapi.xxxx.com/api/, ApiList=https://yyapi.xxxx.com/v-api/

【选择通用】
| 参数 | 含义 | 怎么填 |
|------|------|--------|
| Key | 这个配置的名字 | 自己起 |
| need | 指定用哪个配置（匹配相对应的 Key） | 跟 Key 填一样 |
| ApiUrl | API 基础地址 | https://..... |
| ApiList | API 文档地址 | https://..... |
| ApiUseInfo | 指定调用的脚本文件 | Use/xxx.txt 或 Use/xxx.py |
| Choose | 固定填 | 留空 "" |
```

用户提供了信息后,生成 `meta.json` 保存到 SKILL 目录,然后继续。

---

### 场景B:用户说"配置好了" → 验证配置

**不能跳过验证,必须展示结果让用户确认:**

```
读取 meta.json 结果:
- need: "xxx"
- ApiUrl: "https://....."
- ApiList: "https://....."
- ApiUseInfo: "Use/...."
- Choose: "WeCall"
......

配置验证通过 → 继续任务
发现问题 → 告诉用户哪里不对,引导修正
```

---

### 场景C:用户要改 meta.json → 引导修改

**分两步,绝不擅自修改:**

**Step 1:问清楚要改什么**
```
请告诉我要修改哪些字段?例如:
- "把 Choose 改成通用流程"
- "把 ApiUrl 改成新的地址"
```

**Step 2:展示修改前后对比,用户回复"确认"后才写入**
```
确认以下修改:
【修改前】Choose: "WeCall"
【修改后】Choose: ""
请回复"确认"写入。
```

---

## 三、两套流程(Choose 决定用哪个)

### 3.1 判断方法

```
读 meta.json → Items[].Choose 字段
"WeCall"  → WeCall 流程(第三节 3.2)
"" 或空   → 通用流程(第三节 3.3)
```

### 3.2 WeCall 流程(Choose="WeCall")

| | 行为 |
|---|---|
| 危险操作 | **直接拦截,不确认**,拒绝执行 |
| 登录 | 自动检查,已登录跳过;未登录询问账号密码 |
| 调用 | 调 `em.generate_xxx()` 系列函数(见函数速查表) |

**危险操作示例(直接拒绝):**
```
用户:帮我删除项目5957
AI:拒绝执行。Choose="WeCall",危险操作直接拦截,不执行。
```

### 3.3 通用流程(Choose="")

| | 行为 |
|---|---|
| 危险操作 | **需用户明确回复"确认"**后才执行 |
| 登录 | 同上 |
| 调用 | 用 `au.execute_command('call_api', ...)` 或调封装函数 |

**危险操作示例(需确认):**
```
用户:帮我删除项目5957
AI:您正在执行"删除项目"操作,请回复"确认删除"继续,或"取消"放弃。
```

## 四、执行清单(进入任务后按顺序执行)

```
[ ] 步骤0  读 SKILL.md  → 每次任务都要读完全部内容
[ ] 步骤1  读 meta.json → 确定 Choose(WeCall 还是通用)
[ ] 步骤2  导入模块     → import sys; sys.path.insert(0, 'SKILL_DIR/scripts'); import alluse as au, export_manager as em
[ ] 步骤3  检查登录     → 已登录跳过;未登录询问账号密码【详情查看第五节】
[ ] 步骤4  理解指令     → 识别:项目?任务?报表类型?日期?
[ ] 步骤5  查 API 文档  → 从 meta.json → ApiList 打开文档页面,搜索API名称,**确认参数名和类型,禁止凭记忆猜测** 【详情查看第6节】
[ ] 步骤6  校验参数      → 必填没提供 → 先问用户;可选没提供 → 不传
[ ] 步骤7  调用已有函数  → 只用 export_manager.py / alluse.py 的函数,禁止写新脚本
[ ] 步骤8  返回结果     → 成功→文件路径/摘要;失败→展示方法名+参数+错误

注意:就调用主要代码alluse.py和expory_manager.py即可,除非没有对应指令的代码才可以新写代码,放于meta.json所在文件夹的scripts文件夹下
严禁写临时脚本/代码(如果不是临时脚本，而是常用的可以写，尽量合并为一个代码)
```

---

## 五、登录(WeCall流程必须,通用看用户情况)

```python
status = au.check_login_status()
# logged_in=True  → 已登录,跳过
# logged_in=False → 未登录,询问账号密码

au.login("账号", "密码", API_URL)
```

> **更换账号规则**
>
> 当用户要求更换账号时:
> 1. **删除原登录信息** → 清空 `session_state.json`(token)和 `wecall_credentials.json`(账号密码)
> 2. **用新账号重新登录** → 询问新账号密码,执行 `au.login()`
> 3. **cli 参数始终为 `ai`** → 不管是换账号还是换用户,登录时 cli 一律用 `"ai"`,**禁止用 `"pc"`**
> 4. 更换账号可以将旧的账号退出然后再新的账号登陆,不需要先注销,直接用新账号登录即可覆盖

---

## 六、API相关说明

### 6.1 查阅API

如果不会调用相应API就去API列表中去查看

### 6.2 查阅文档步骤

**步骤1:获取 ApiList 地址**
```python
# 从 meta.json 读取
with open('meta.json', 'r', encoding='utf-8') as f:
    meta = json.load(f)
api_list_url = meta['ApiList']  
```

**步骤2:打开文档页面**
- 用浏览器打开 ApiList 地址
- 页面会列出所有可用 API

**步骤3:搜索目标 API**
- 按 Ctrl+F 搜索 API 名称(如 GetFields)
- 找到对应的 API 条目,点击进入详情

**步骤4:确认参数信息**
必须确认以下信息:
| 确认项 | 说明 | 示例 |
|--------|------|------|
| 参数名 | 区分大小写 | extId ≠ extid ≠ id |
| 参数类型 | string / int / array | Cell 是 integer |
| 是否必填 | required / optional | id 通常是必填 |
| 参数格式 | 特殊格式要求 | daterange 用 , 分隔 |

**步骤5:验证参数值**
- 不确定的参数值,先打印出来检查
- 数组类型确认是 [] 还是 '' 分隔

### 6.3 文档查阅检查清单

调用任何 API 前,必须完成:
- [ ] 打开 ApiList 页面
- [ ] 搜索并找到目标 API
- [ ] 阅读参数列表(每个参数的名称、类型、必填性)
- [ ] 确认参数值格式
- [ ] 对照检查清单验证代码中的参数


## 七、函数速查表

> 所有函数在 `export_manager.py` 里,直接 `import em`,不需要再写内容。

| 函数 | 必填参数 | 可选参数 | 说明 |
|------|---------|---------|------|
| `generate_traffic_report(topic_ids, daterange, rule_id=None)` | topic_ids, daterange | rule_id | 话务报表 |
| `generate_agent_report(topic_id, daterange, rule_id=None)` | topic_id, daterange | rule_id, exte, so, ratio | 坐席话务报表 |
| `generate_attendance_report(daterange, exte=None)` | daterange | exte | 考勤报表 |
| `generate_quality_report(topic_ids, daterange, rule_id=None)` | topic_ids, daterange | rule_id, user_id | 质检报表 |
| `generate_smart_quality_report(daterange, rule_id)` | daterange, rule_id | display_exte, display_code, **userid** | 智能质检报表 |
| `generate_monitor_report(mid, daterange, rule_id=None)` | mid, daterange | rule_id, exte, attr | 监控报表 |
| `export_cdr(topic_id, rule_id=None, daterange=None)` | topic_id | rule_id, daterange | 导出 CDR（ rule_id 不写=导出项目全部任务） |
| `import_cdr(rule_id, file_path)` | rule_id, file_path | - | 导入 CDR(会话记录或者导出答卷) |
| `download_report(topic_id, rule_id, daterange, ...)` | topic_id, rule_id, daterange | 见下方 GetReport 可选参数表 | 下载报表/报表导出/报表下载 |
| `generic_export(api_method, params=None, ...)` | api_method | params, columns, data_key, filename, column_titles, hide_columns, require_sign, auto_number, include_total_row | **通用导出** |
| `search_projects(keyword)` | keyword | - | 搜索项目，返回 `[{id, title}]` |
| `search_rules(topic_id, keyword=None)` | topic_id | keyword | 查询项目下任务，返回 `[{id, title}]` |
| `search_quotas(topic_id, rule_id=None, keyword=None)` | topic_id | rule_id, keyword | 查询配额，返回 `[{id, title}]` |
| `search_groups(topic_id, keyword=None)` | topic_id | keyword | 查询数据分组，返回 `[{id, grouname}]` |
| `search_sample_templates(topic_id)` | topic_id | - | 查号码模板，返回 `[{id, title}]` |
| `build_sample(topic_id, conditions)` | topic_id, conditions | - | 构建 sample JSON，conditions: `[{title, value, mode}]`，mode: include/exclude/fuzzy |
| `get_task_name(topic_id, rule_id=None)` | topic_id | rule_id | 获取项目名称(rule_id=None)或任务名称 |

> **辅助查询函数（alluse.py）**
>
> | 函数 | 必填参数 | 说明 |
> |------|---------|------|
> | `search_agent_by_nickname(nickname)` | nickname | 昵称查坐席，返回 `{username, number, agentid}` |
> | `get_agent_exte(nickname)` | nickname | 昵称查坐席号（快捷版），直接返回坐席号字符串 |


> **generic_export 通用导出函数（适用于通用流程 Choose=""）**
> 
> 调用用户配置的 API，将返回数据导出为 Excel。
> 
> **参数说明：**
> - `api_method` (必填): API 方法名，如 "GetUserList", "GetOrders"
> - `params` (可选): API 请求参数字典
> - `columns` (可选): 要导出的列名列表，如 `['id', 'name', 'date']`，None 则导出所有列
> - `data_key` (可选): 数据在响应中的键名，如 `'data'`、`'list'`、`'rows'`，None 则自动检测
> - `filename` (可选): 导出文件名，默认 "导出_时间戳"
> - `column_titles` (可选): 列名标题映射，如 `{'id': 'ID', 'name': '名称'}`
> - `hide_columns` (可选): 要隐藏的列名列表
> - `require_sign` (可选): 是否需要签名，默认 True
> - `auto_number` (可选): 是否自动添加序号列，默认 True
> - `include_total_row` (可选): 是否添加合计行，默认 False
> 
> **使用示例：**
> ```python
> # 基本用法 - 导出所有列
> result = generic_export('GetUserList', {'page': 1, 'size': 100})
> 
> # 指定列名和标题
> result = generic_export(
>     api_method='GetOrders',
>     params={'status': 1},
>     columns=['order_id', 'customer', 'amount'],
>     column_titles={'order_id': '订单号', 'customer': '客户', 'amount': '金额'},
>     filename='订单列表'
> )
> ```

> **daterange 格式**：日期和时间都可以，不严格区分。
> 示例：`"2026-04-01,2026-04-15"` 或 `"2026-04-01 00:00:00,2026-04-15 23:59:59"`
> **唯一硬性要求：用 `,` 分隔起止时间，禁止用 `~`**

**download_report 说明**：
- 报表名称 = 任务名称
- 创建下载任务时 `locktype`：1=锁定，2=解锁

> **术语说明**：「报表导出」「报表下载」「下载报表」均指 `download_report`，用于下载非质检报表、智能质检报表、话务报表等的报表。

**download_report 可选参数（GetReport）**：

| 可选参数 | 类型 | 说明 | 获取方式 |
|---------|------|------|---------|
| `quotaid` | string | 配额ID（只能选一个） | GetQuotaLs(topicId=项目ID)，匹配名称 |
| `chkdaterange` | string | 质检时间，格式同 daterange | 用户说明 |
| `duration` | string | 通话时长范围，中间用 `-` 分隔 | 用户说明，格式：`HH:MM:SS-HH:MM:SS` |
| `chk` | int | 是否质检：0=未质检，1=通过，2=作废，3=已质检，4=AI质检 | 用户说明 |
| `sample` | string | 号码模板条件，格式同导出 CDR 的 sample | 见 CDR 导出号码模板条件流程 |
| `groupids` | string | 数据分组ID | GetGroupLs(topicId=项目ID)，用户说明 |
| `rpt` | int | 排重：1=开启 | 用户说明 |
| `clr` | bool | 重新生成：true=开启 | 用户说明 |
| `style` | int | 导出格式（各报表不同） | 默认0 |

---

## 八、参数阻拦规则

| 情况 | 处理 |
|------|------|
| 必填参数用户没提供 | **先问用户,禁止直接调用** |
| 可选参数用户没提供 | **不传,禁止设默认值** |
| daterange 用户没说 | **先问,禁止导出全部数据** |

> **报表/会话类操作(话务报表、坐席报表、CDR导出等),daterange 是必填参数,必须先问时间段。**

## 九、安全规则(十分重要)

- **WeCall**:Delete / Del / Remove / 删除 → **直接拒绝**
- **通用**:以上操作 → 需用户回复"确认"后才执行(如果用户也说了删除操作不可执行则直接拦截)
- 注意：对于隐私数据需要保护，不泄露，不随便传递
---

## 十、文件结构

```
SKILL_DIR/                     ← meta.json 所在目录
|-- SKILL.md                   ← 本文件
|-- meta.json                  ← API 配置(第一步必读)
|-- scripts/
|   |-- alluse.py              ← 登录/API调用/token管理
|   |-- export_manager.py      ← 所有报表/导入导出函数
|   |-- session_state.json     ← token持久化(自动读写)
|   |-- wecall_credentials.json← 账号密码(token过期自动重登)
```

路径:`SKILL_DIR = os.path.dirname(meta_json_path)`

---
