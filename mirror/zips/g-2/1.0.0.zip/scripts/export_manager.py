#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
WeCall 报表导出管理器
统一入口：所有报表/导入/导出功能都放在这里
API 调用统一走 alluse.call_api，登录/会话由 alluse 管理
"""
import json, os, time, math, re, base64
from urllib.parse import quote
import openpyxl
import requests
import alluse as au          # 统一使用 alluse 的登录/会话/call_api
from pathlib import Path
from datetime import datetime
import logging

# 日志配置：默认只输出 ERROR 及以上，带时间戳
logging.basicConfig(
    level=logging.ERROR,
    format='%(asctime)s [%(levelname)s] %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)

SCRIPT_DIR = Path(__file__).parent
DOWNLOAD_DIR = os.path.join(os.path.expanduser("~"), "Downloads")

# =============================================================================
# 工具函数
# =============================================================================

def _api_url():
    meta = au.load_meta()
    return meta["Items"][0]["ApiUrl"]


def _session():
    s = au.load_session()
    return s["token"], s["secret"]


def _fmt_daterange(daterange):
    """
    统一日期范围格式：
    - 只有日期：不补时分秒，原样返回（用户没说就不要加）
    - 已有时分秒：原样返回
    - 格式不匹配：原样返回
    """
    daterange = daterange.strip()
    m = re.match(
        r"^(\d{4}-\d{2}-\d{2})(?:[ ,](\d{2}:\d{2}:\d{2}))?,(\d{4}-\d{2}-\d{2})(?:[ ,](\d{2}:\d{2}:\d{2}))?$",
        daterange,
    )
    if m:
        s_date, s_time, e_date, e_time = m.groups()
        # 用户没说时分秒，就不加
        if s_time and e_time:
            return f"{s_date} {s_time},{e_date} {e_time}"
        elif s_time:
            return f"{s_date} {s_time},{e_date}"
        elif e_time:
            return f"{s_date},{e_date} {e_time}"
        else:
            return f"{s_date},{e_date}"
    return daterange




def _parse_hide_columns(hide_columns):
    """将 hide_columns 转换为小写集合，支持列表或逗号分隔字符串"""
    if not hide_columns:
        return set()
    if isinstance(hide_columns, str):
        names = [n.strip() for n in hide_columns.split(",") if n.strip()]
    else:
        names = [str(n).strip() for n in hide_columns if n]
    return {n.lower() for n in names}

def _save_excel(wb, prefix):
    os.makedirs(DOWNLOAD_DIR, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d%H%M%S")
    path = os.path.join(DOWNLOAD_DIR, f"{prefix}{ts}.xlsx")
    wb.save(path)
    return path


def _safe_int(val, default=0):
    try:
        return max(int(val or default), 0)
    except (ValueError, TypeError):
        return default


def _safe_float(val, default=0.0):
    try:
        return max(float(val or default), 0.0)
    except (ValueError, TypeError):
        return default


def _strip_zero(v):
    """去掉浮点数尾部的 .00 或 .0... 并去掉无意义的尾零"""
    if v is None:
        return ""
    s = str(v)
    if "." not in s:
        return s
    stripped = s.rstrip("0").rstrip(".")
    return stripped


def _fmt_rate(a, b):
    a = _safe_int(a)
    b = _safe_int(b)
    v = round(a / b * 100, 2) if b > 0 else 0
    return _strip_zero(min(v, 100))


# =============================================================================
# 搜索辅助函数（不调API，只告诉AI用什么API）
# =============================================================================

def search_projects(keyword):
    """
    搜索项目
    用法示例：
        au.execute_command('call_api', {
            'method': 'GetTopicLs',
            'params': {'word': '四川移动'}
        })
    返回字段：id, name
    """
    return {
        'tip': '调 API: GetTopicLs，参数 word=关键词，返回 list.items[id/name/...]',
        'api': 'GetTopicLs',
        'params': {'word': keyword},
        'note': '返回 items[].id 和 items[].name，匹配 keyword 的项目'
    }


def search_rules(topic_id, keyword=None):
    """
    查询项目下所有任务
    用法示例：
        au.execute_command('call_api', {
            'method': 'GetRuleLs',
            'params': {'topicId': '5964'}
        })
    参数：topicId 必填，word 可选（任务名关键词过滤）
    返回字段：id, title, enabled
    """
    params = {'topicId': str(topic_id)}
    if keyword:
        params['word'] = keyword
    return {
        'tip': '调 API: GetRuleLs，参数 topicId=项目ID，word=可选关键词，返回 list[id/title/enabled/...]',
        'api': 'GetRuleLs',
        'params': params,
        'note': '返回 items[].id（任务ID）、items[].title（任务名）、items[].enabled（是否启用）'
    }


# =============================================================================
# GetReport 下载（会话报表 / 话务报表 / 质检报表）
# =============================================================================

def search_quotas(topic_id, rule_id=None, keyword=None):
    """
    查询项目下所有配额（GetQuotaLs）

    返回字段：id, title（配额名称）

    注意：必须传 ruleId 且 vcount=true 才能获取真实配额ID，否则返回 id=-1
    """
    token, secret = _session()
    api = _api_url()
    params = {"topicId": str(topic_id), "vcount": "true", "pi": "1", "ps": "100"}
    if rule_id:
        params["ruleId"] = str(rule_id)
    if keyword:
        params["word"] = str(keyword)
    r = au.call_api(api, "GetQuotaLs", params, token, secret)
    if r.get("succeed") != "true" and r.get("code") != "1":
        return []
    items = r.get("data", {}).get("list", []) or r.get("data", {}).get("items", [])
    return [{"id": i["id"], "title": i["title"]} for i in items]


def search_groups(topic_id, keyword=None):
    """
    查询项目下所有数据分组（GetGroupLs）

    返回字段：id, grouname（分组名称）
    """
    token, secret = _session()
    api = _api_url()
    params = {"topicId": str(topic_id)}
    if keyword:
        params["word"] = str(keyword)
    r = au.call_api(api, "GetGroupLs", params, token, secret)
    if r.get("succeed") != "true" and r.get("code") != "1":
        return []
    items = r.get("data", {}).get("list", []) or r.get("data", {}).get("items", [])
    return [{"id": i["id"], "grouname": i["grouname"]} for i in items]


def search_sample_templates(topic_id):
    """
    查询项目的号码模板字段（GetTopic + GetFields）

    流程：GetTopic 获取 extendid → extendid=-1 则无号码模板 → 否则 GetFields 获取字段
    返回：{"extendid": 值, "fields": [{"field": 键名, "title": 字段名称}]}
           或 {"extendid": -1, "fields": []} 表示无号码模板
    """
    token, secret = _session()
    api = _api_url()

    # Step 1: 获取项目的 extendid
    r1 = au.call_api(api, "GetTopic", {"id": str(topic_id)}, token, secret)
    extendid = r1.get("data", {}).get("extendid")
    if extendid is None or str(extendid) == "-1":
        return {"extendid": -1, "fields": []}

    # Step 2: 直接用 extendid 获取字段
    r2 = au.call_api(api, "GetFields", {"extId": str(extendid)}, token, secret)
    items = r2.get("data", {}).get("list", []) or r2.get("data", {}).get("items", [])
    fields = [{"field": i["field"], "title": i["title"]} for i in items]
    return {"extendid": extendid, "fields": fields}


def build_sample(topic_id, conditions):
    """
    构建号码模板条件 JSON 字符串

    参数：
        topic_id   : 项目ID
        conditions : list of dict, 每项包含:
            - "title" : 字段名称（用户说的是 title，如"手机号"）
            - "value" : 条件值（如 "33"）
            - "mode"  : "include"(默认) / "exclude"(不包括) / "fuzzy"(模糊)

    返回：{"success": True, "sample": "{\"field_xxx\": \"33\"}"} 或 错误信息

    说明：
        - 不包括：值前面加 !，如 !44
        - 模糊：值前面加 *，如 *35
        - 同一字段只能用一次
    """
    token, secret = _session()
    api = _api_url()

    # Step 1: 获取号码模板字段
    result = search_sample_templates(topic_id)
    if result["extendid"] == -1:
        return {"success": False, "message": f"项目 {topic_id} 没有号码模板（extendid=-1），sample 参数不可用"}
    fields = result["fields"]
    if not fields:
        return {"success": False, "message": f"项目 {topic_id} 的号码模板没有配置字段"}

    # 可用字段信息可省略

    # Step 2: 构建 title -> field 映射
    title_map = {f["title"]: f["field"] for f in fields}

    # Step 3: 逐个匹配条件
    sample_dict = {}
    for cond in conditions:
        title = cond.get("title", "")
        value = cond.get("value", "")
        mode = cond.get("mode", "include")

        if title not in title_map:
            return {"success": False,
                    "message": f"找不到字段「{title}」，可用字段: {list(title_map.keys())}"}

        field_key = title_map[title]
        if field_key in sample_dict:
            return {"success": False,
                    "message": f"字段「{title}」({field_key}) 只能使用一次"}

        # 处理模式前缀
        final_value = value
        if mode == "exclude":
            final_value = "!" + value
        elif mode == "fuzzy":
            final_value = "*" + value

        sample_dict[field_key] = final_value

    sample_str = json.dumps(sample_dict, ensure_ascii=False)
    return {"success": True, "sample": sample_str}


def get_task_name(topic_id, rule_id=None):
    """
    获取项目名和任务名（用于文件命名）
    返回：(项目名, 任务名)
    """
    token, secret = _session()
    api = _api_url()

    # 项目名：GetTopicLs
    r = au.call_api(api, "GetTopicLs", {"word": str(topic_id)}, token, secret)
    proj_name = str(topic_id)
    if r.get("succeed") == "true" or r.get("code") == "1":
        items = r.get("data", {}).get("list", []) or r.get("data", {}).get("items", [])
        for it in items:
            if str(it.get("id", "")) == str(topic_id):
                n = it.get("name", it.get("title", ""))
                # GetTopicLs 返回的名称可能是 ID（如光凭 word 搜索解析失败），
                # 如果名称仍等于 topic_id，再尝试从 GetRuleLs 的 tag.topic.name 获取
                if not n or n == str(topic_id):
                    break  # 跳过，用后面的备用方案
                proj_name = n
                break

    # 备用：若 proj_name 仍是 topic_id（名称解析失败），从 GetRuleLs tag.topic.name 拿
    if proj_name == str(topic_id) and rule_id:
        r_lu = au.call_api(api, "GetRuleLs", {"topicId": str(topic_id)}, token, secret)
        if r_lu.get("succeed") == "true" or r_lu.get("code") == "1":
            tasks_lu = r_lu.get("data", {}).get("list", []) or []
            for t_lu in tasks_lu:
                if str(t_lu.get("id", "")) == str(rule_id):
                    tag_topic = t_lu.get("tag", {}).get("topic", {})
                    proj_name = tag_topic.get("name", proj_name)
                    break

    # 任务名：GetRuleLs
    task_name = str(rule_id) if rule_id else ""
    if rule_id:
        r2 = au.call_api(api, "GetRuleLs", {"topicId": str(topic_id)}, token, secret)
        if r2.get("succeed") == "true" or r2.get("code") == "1":
            tasks = r2.get("data", {}).get("list", []) or []
            for t in tasks:
                if str(t.get("id", "")) == str(rule_id):
                    task_name = t.get("title", task_name)
                    break

    return proj_name, task_name


def download_report(topic_id, rule_id, daterange, style=0, rpt=0, clr=True,
                    proj_name=None, task_name=None, quotaid=None):
    """
    GetReport 下载流程：创建任务 → 轮询状态 → oss.aicati.com 下载

    参数：
        topic_id   : 项目ID（Int32，必填）
        rule_id    : 任务ID（String，必填）
        daterange  : 时间范围（必填），格式 "YYYY-MM-DD,YYYY-MM-DD"
        style      : 0=csv, 3=xlsx, 4=txt, 1=SPSS, 2=ASR
        rpt        : 0=不排重, 1=排重
        clr        : True=重新生成, False=使用缓存
        proj_name  : 项目名（可选，用于文件命名，不传则自动查询）
        task_name  : 任务名（可选，用于文件命名，不传则自动查询）
        quotaid    : 配额ID（可选，筛选指定配额）

    返回：{"success": True, "file_path": "..."}
    """
    token, secret = _session()
    api = _api_url()
    daterange = _fmt_daterange(daterange)

    # 自动获取名称
    if not proj_name or not task_name:
        p, t = get_task_name(topic_id, rule_id)
        proj_name = proj_name or p
        task_name = task_name or t

    topic_str = str(topic_id)
    rule_str = str(rule_id)

    # Step 1: 创建下载任务
    pass  # 静默
    api_params = {
        "topicId": topic_str,
        "ruleId": rule_str,
        "daterange": daterange,
        "style": style,
        "rpt": rpt,
        "clr": "true" if clr else "false",
        "listType": 1,
    }
    if quotaid:
        api_params["quotaid"] = str(quotaid)
    r = au.call_api(api, "GetReport", api_params, token, secret)

    if r.get("succeed") != "true" and r.get("code") != "1":
        return {"success": False, "message": r.get("message", "创建下载任务失败")}

    # Step 2~3: 轮询任务状态
    pass  # 静默
    task_found = False
    for i in range(60):   # 最多等 60 轮 × 2秒 = 120秒
        time.sleep(2)
        r2 = au.call_api(api, "GetTaskLs", {"days": "1"}, token, secret)
        tasks = r2.get("data", {}).get("list", []) or []

        for t in tasks:
            task_info = t.get("task", {})
            prog = t.get("progress", {})
            # 匹配当前 topicId 的任务
            if str(task_info.get("topicid", "")) != topic_str:
                continue

            info = prog.get("info", "")
            state = str(task_info.get("state", ""))
            value = prog.get("value", "")
            maxval = prog.get("maxvalue", "")
            pass  # 静默

            task_found = True

            # 判断完成：info 含"完成"或"已停止"，且有 result
            if ("完成" in info or "停止" in info or state == "2") and t.get("result"):
                reskey = t.get("result", {}).get("reskey", "")
                # API 返回的 title 即为任务名（报表名称），优先使用；其次用用户传入的 task_name；最后才用 get_task_name 获取的
                api_title = t.get("title", "")
                final_task_name = api_title or task_name or ""

                if not reskey:
                    return {"success": False, "message": "任务完成但无下载文件"}

                # Step 4: 下载
                pass  # 静默
                url = "https://oss.aicati.com/" + reskey
                resp = requests.get(url, timeout=60)
                if resp.status_code != 200:
                    return {"success": False, "message": f"下载失败 HTTP {resp.status_code}"}

                # Step 5: 保存（根据 style 转换格式）
                ts_str = datetime.now().strftime("%Y%m%d%H%M%S")
                # 用 proj_name（项目名）而不是 topic_id，避免文件名出现 "5968_"
                safe_proj = (proj_name or "项目").replace("/", "-").replace("\\", "-")
                safe_task = (final_task_name or "任务").replace("/", "-").replace("\\", "-")

                # 根据 style 决定扩展名和转换
                style_ext_map = {0: ".csv", 3: ".xlsx", 4: ".txt", 1: ".sav", 2: ".csv"}
                target_ext = style_ext_map.get(style, ".csv")

                # 先保存原始内容到临时文件
                raw_content = resp.content

                if style == 3:  # xlsx: csv 转 xlsx
                    import csv as _csv
                    import io
                    wb = openpyxl.Workbook()
                    ws = wb.active
                    ws.title = "会话报表"
                    # 解析 csv 内容
                    text_content = raw_content.decode('utf-8-sig') if b'\xef\xbb\xbf' in raw_content[:3] else raw_content.decode('utf-8')
                    reader = _csv.reader(io.StringIO(text_content))
                    for row in reader:
                        ws.append(row)
                    fname = f"{safe_proj}_{safe_task}_{ts_str}.xlsx"
                    dest = os.path.join(DOWNLOAD_DIR, fname)
                    wb.save(dest)
                    size = os.path.getsize(dest)
                elif style == 4:  # txt: csv 转 txt（制表符分隔）
                    import csv as _csv
                    import io
                    text_content = raw_content.decode('utf-8-sig') if b'\xef\xbb\xbf' in raw_content[:3] else raw_content.decode('utf-8')
                    reader = _csv.reader(io.StringIO(text_content))
                    lines = []
                    for row in reader:
                        lines.append("\t".join(row))
                    txt_content = "\n".join(lines)
                    fname = f"{safe_proj}_{safe_task}_{ts_str}.txt"
                    dest = os.path.join(DOWNLOAD_DIR, fname)
                    with open(dest, "w", encoding="utf-8") as f:
                        f.write(txt_content)
                    size = os.path.getsize(dest)
                else:  # csv/sav 或其他：保持原样
                    fname = f"{safe_proj}_{safe_task}_{ts_str}{target_ext}"
                    dest = os.path.join(DOWNLOAD_DIR, fname)
                    with open(dest, "wb") as f:
                        f.write(raw_content)
                    size = len(raw_content)

                pass  # 静默
                return {"success": True, "file_path": dest, "size": size,
                        "message": f"下载成功，{size} bytes"}

        if not task_found and i == 0:
            pass  # 静默

    return {"success": False, "message": "任务超时未完成"}


# =============================================================================
# 会话记录导入（ImportCdrLs）
# =============================================================================

def import_cdr(rule_id, file_path):
    """
    导入会话记录 CDR 文件

    参数：
        rule_id   : 任务ID（Int32）
        file_path : 本地 .cdr 文件路径

    返回：{"success": True, "message": "导入成功"}
    """
    token, secret = _session()
    api = _api_url()

    if not os.path.exists(file_path):
        return {"success": False, "message": f"文件不存在: {file_path}"}

    # 读取并 Base64 编码
    with open(file_path, "rb") as f:
        raw = f.read()

    b64 = base64.b64encode(raw).decode("ascii")
    s = quote(b64)   # URL 编码

    fname = os.path.basename(file_path)
    logger.info(f"[ImportCdr] ruleId={rule_id}, file={fname}, size={len(raw)} bytes")

    r = au.call_api(api, "ImportCdrLs", {
        "ruleId": str(rule_id),
        "s": s,
        "fileName": fname,
    }, token, secret)

    if r.get("succeed") == "true" or r.get("code") == "1":
        return {"success": True, "message": f"导入成功: {fname} ({len(raw)} bytes)"}
    else:
        return {"success": False, "message": r.get("message", "导入失败")}


# =============================================================================
# 会话记录导出（GetCdrLs + ExportCdrLs）
# =============================================================================

def export_cdr(topic_id, rule_id, daterange,
               doc=None, state=None, quotaid=None, duration=None,
               chk=None, chkdaterange=None, exte=None, word=None,
               rpt=None, GroupIds=None, sample=None):
    """
    导出会话记录（CDR）

    参数：
        topic_id      : 项目ID
        rule_id       : 任务ID（必填）
        daterange     : 日期范围，格式 'YYYY-MM-DD,YYYY-MM-DD'（必填）
        doc           : 是否回放，0=未回放，1=已回放
        state         : 是否接通，0=未接通，1=已接通
        quotaid       : 配额ID（通过 GetQuotaLs 获取）
        duration      : 通话时长范围，格式 'HH:MM:SS-HH:MM:SS'，如 '00:01:00-00:05:00'
        chk           : 是否质检，0=未质检，1=通过，2=作废，3=已质检，4=智能质检
        chkdaterange  : 质检时间，格式同 daterange
        exte          : 坐席号
        word          : 关键词
        rpt           : 排重，0=不排重，1=排重
        GroupIds      : 数据分组ID（通过 GetGroupLs 获取）
        sample        : 号码模板条件，JSON字符串，如 '{"field0": "33"}'
                       可通过 build_sample() 自动构建

    返回：{"success": True, "file_path": "...cdr"}
    """
    token, secret = _session()
    api = _api_url()

    params = {"topicId": str(topic_id)}
    if rule_id:
        params["ruleId"] = str(rule_id)
    if daterange:
        params["daterange"] = str(daterange)
    if doc is not None:
        params["doc"] = str(doc)
    if state is not None:
        params["state"] = str(state)
    if quotaid is not None:
        params["quotaid"] = str(quotaid)
    if duration is not None:
        params["duration"] = str(duration)
    if chk is not None:
        params["chk"] = str(chk)
    if chkdaterange is not None:
        params["chkdaterange"] = str(chkdaterange)
    if exte is not None:
        params["exte"] = str(exte)
    if word is not None:
        params["word"] = str(word)
    if rpt is not None:
        params["rpt"] = str(rpt)
    if GroupIds is not None:
        params["GroupIds"] = str(GroupIds)
    if sample is not None:
        params["sample"] = str(sample)

    # Step 1: 查询记录数量
    logger.info(f"[ExportCdr] params={params}")
    r = au.call_api(api, "GetCdrLs", params, token, secret)
    if r.get("succeed") != "true" and r.get("code") != "1":
        return {"success": False, "message": r.get("message", "查询会话记录失败")}

    count = len(r.get("data", {}).get("list", []))
    pass  # 静默

    # Step 2: 导出
    r2 = au.call_api(api, "ExportCdrLs", params, token, secret)
    if r2.get("succeed") != "true" and r2.get("code") != "1":
        return {"success": False, "message": r2.get("message", "导出会话记录失败")}

    data = r2.get("data", "")
    if not data:
        return {"success": False, "message": "导出内容为空"}

    # Step 3: Base64 解码并保存
    xml_bytes = base64.b64decode(data)

    # Step 4: 文件命名
    _, task_n = get_task_name(topic_id, rule_id)
    safe_task = task_n.replace("/", "-").replace("\\", "-") if task_n else str(topic_id)
    ts_str = datetime.now().strftime("%Y-%m-%d %H_%M_%S")
    fname = f"{safe_task}_{ts_str}.cdr"
    dest = os.path.join(DOWNLOAD_DIR, fname)

    with open(dest, "wb") as f:
        f.write(xml_bytes)

    size = len(xml_bytes)
    pass  # 静默
    return {"success": True, "file_path": dest, "size": size, "count": count,
            "message": f"导出成功，{size} bytes，{count} 条记录"}


# =============================================================================
# 话务报表（GetDailys）
# =============================================================================

def generate_traffic_report(topic_ids, daterange, rule_id=None, fields=None, hide_columns=None):
    """
    话务统计报表

    必要参数：topicIds(项目) / ruleId(单项目时必填) / daterange(范围)
    包含：时间、项目、呼叫总量、通话时长(秒)、通话率(%)、启动率(%)等 +
    统计信息列（分组字段内容）。

    fields：号码模板字段名称，支持多个（用逗号分隔）。
            会自动通过 GetTopic(id) 获取 extendid，
            再通过 GetFields(extId) 查找对应 field ID，
            多个 ID 用逗号分隔后传给 GetDailys 的 fields 参数。
            例如：fields="归属地,运营商"
    """
    is_single = "," not in str(topic_ids)
    if is_single and not rule_id:
        raise TypeError("单项目时规则ID(rule_id)为必填")

    token, secret = _session()
    api = _api_url()
    daterange = _fmt_daterange(daterange)

    # 如果 fields 传入的是字段名称（非 ID），需要先解析为 field ID
    resolved_fields = None
    if fields:
        # 取第一个项目 ID 用于查找 extendid
        primary_topic_id = str(topic_ids).split(",")[0].strip()

        # 1. 获取项目的 extendid
        topic_result = au.call_api(api, "GetTopic", {"id": primary_topic_id}, token, secret)
        if not topic_result.get("succeed"):
            raise TypeError("获取项目信息失败：" + str(topic_result.get("message", "未知错误")))
        extendid = topic_result.get("data", {}).get("extendid")
        if not extendid:
            raise TypeError("该项目未配置号码模板，无法使用 fields 分组功能")

        # 2. 获取字段列表
        fields_result = au.call_api(api, "GetFields", {"extId": extendid}, token, secret)
        if not fields_result.get("succeed"):
            raise TypeError("获取字段列表失败：" + str(fields_result.get("message", "未知错误")))

        field_list = fields_result.get("data", [])
        # 建立 title -> id 的映射
        field_id_map = {}
        for f in field_list:
            fid = f.get("id") or f.get("field", "")
            fname = f.get("title") or f.get("name", "")
            if fid and fname:
                field_id_map[fname] = fid

        # 3. 按用户提供的标题匹配 field ID
        title_list = [t.strip() for t in str(fields).split(",") if t.strip()]
        matched_ids = []
        for title in title_list:
            if title in field_id_map:
                matched_ids.append(field_id_map[title])
            else:
                available = " / ".join(list(field_id_map.keys())[:20])
                raise TypeError(
                    "未找到字段【" + title + "】，当前可用字段：" + available
                    if available else "未找到字段【" + title + "】，该项目无可用字段"
                )
        resolved_fields = ",".join(matched_ids)

    params = {"topicIds": str(topic_ids), "daterange": daterange}
    if rule_id:
        params["ruleId"] = str(rule_id)
    if resolved_fields:
        params["fields"] = resolved_fields

    r = au.call_api(api, "GetDailys", params, token, secret)
    if r.get("succeed") != "true" and r.get("code") != "1":
        return {"success": False, "message": r.get("message", "获取数据失败")}
    if not r.get("data"):
        return {"success": False, "message": "API返回数据为空"}

    raw = r["data"].get("list", [])
    items = [x for x in raw if str(x.get("id", "")) != "0"]

    # ── 多项目 vs 单项目：列定义不同 ──────────────────────────────────
    if not is_single:
        # 多项目：精简列 + 统计信息（成功、作废）固定两列
        BASE = ["时间", "项目", "任务",
                "总量", "接通量", "接通率(%)",
                "质检率(%)", "时长(分)"]
        STAT_COLS = ["成功", "作废"]   # 固定统计信息列

        _hide = _parse_hide_columns(hide_columns)
        base_show = [h for h in BASE if h.lower() not in _hide]
        stat_show = [s for s in STAT_COLS if s.lower() not in _hide]
        total_cols = len(base_show) + len(stat_show)

        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "话务统计"

        # 表头：基础列合并两行，统计信息合并第一行
        for ci, h in enumerate(base_show, 1):
            c = ws.cell(1, ci, h)
            c.font = openpyxl.styles.Font(bold=True)
            c.alignment = openpyxl.styles.Alignment(horizontal="center", vertical="center")
            ws.merge_cells(start_row=1, start_column=ci, end_row=2, end_column=ci)

        stat_start = len(base_show) + 1
        if stat_show:
            ws.merge_cells(start_row=1, start_column=stat_start,
                           end_row=1, end_column=total_cols)
            c = ws.cell(1, stat_start, "统计信息")
            c.font = openpyxl.styles.Font(bold=True)
            c.alignment = openpyxl.styles.Alignment(horizontal="center", vertical="center")
            for gi, gn in enumerate(stat_show):
                c = ws.cell(2, stat_start + gi, gn)
                c.font = openpyxl.styles.Font(bold=True)
                c.alignment = openpyxl.styles.Alignment(horizontal="center", vertical="center")

        # 数据行
        rows_data = []
        for ri, it in enumerate(items, 3):
            tag = it.get("tag", {})
            total   = _safe_int(it.get("total"))
            connect = _safe_int(it.get("connect"))
            complete = _safe_int(it.get("complete"))
            chkn    = _safe_int(it.get("chkn"))    # 作废量
            chky    = _safe_int(it.get("chky"))    # 质检通过量
            dur_min = _safe_int(it.get("time"))     # API time 字段 = 通话分钟数

            chk_rate = _strip_zero(tag.get("chk", "0")) or "0"

            base_vals = [
                tag.get("day", ""),             # 时间（日期 YYYY-MM-DD）
                tag.get("topicname", ""),    # 项目
                tag.get("ruletitle", "") or tag.get("rulename", ""),  # 任务
                total,                        # 总量
                connect,                      # 接通量
                _fmt_rate(connect, total),    # 接通率(%)
                chk_rate,                     # 质检率(%)
                dur_min,                      # 时长(分)
            ]
            # 统计信息从 tag.groups 取值（成功/作废等）
            grp_map = {g.get("title", ""): int(g.get("value", 0) or 0)
                       for g in tag.get("groups", [])}
            stat_vals = [grp_map.get("成功", 0), grp_map.get("作废", 0)]

            rows_data.append({"total": total, "connect": connect, "complete": complete,
                               "chkn": chkn, "dur_min": dur_min, "chky": chky})

            row_filtered = [v for i, v in enumerate(base_vals) if BASE[i].lower() not in _hide]
            stat_filtered = [v for i, v in enumerate(stat_vals) if STAT_COLS[i].lower() not in _hide]
            for col, val in enumerate(row_filtered + stat_filtered, 1):
                ws.cell(ri, col, val).alignment = openpyxl.styles.Alignment(
                    horizontal="left", vertical="center")

        # 合计行
        n = len(items)
        # 合计：优先取 id=0 汇总行
        summary_row = next((x for x in raw if str(x.get("id")) == "0"), None)
        if summary_row:
            s_tag = summary_row.get("tag", {})
            s_total = _safe_int(summary_row.get("total"))
            s_connect = _safe_int(summary_row.get("connect"))
            s_chky = _safe_int(summary_row.get("chky"))
            s_chkn = _safe_int(summary_row.get("chkn"))
            s_dur_min = _safe_int(summary_row.get("time"))
            s_grp = {g.get("title", ""): int(g.get("value", 0) or 0)
                     for g in s_tag.get("groups", [])}
            sum_stat_vals = [s_grp.get("成功", 0), s_grp.get("作废", 0)]
        else:
            s_total = sum(rd["total"] for rd in rows_data)
            s_connect = sum(rd["connect"] for rd in rows_data)
            s_chky = sum(rd["chky"] for rd in rows_data)
            s_chkn = sum(rd["chkn"] for rd in rows_data)
            s_dur_min = sum(rd["dur_min"] for rd in rows_data)
            sum_stat_vals = [s_total, s_chkn]

        s_chk_rate = _strip_zero(s_tag.get("chk", "0")) if summary_row else "0"
        sum_base_vals = ["合计", "", "", s_total, s_connect,
                         _fmt_rate(s_connect, s_total),
                         s_chk_rate,
                         s_dur_min]
        sum_base_f = [v for i, v in enumerate(sum_base_vals) if BASE[i].lower() not in _hide]
        sum_stat_f = [v for i, v in enumerate(sum_stat_vals) if STAT_COLS[i].lower() not in _hide]
        sum_row_f = sum_base_f + sum_stat_f

        for col, val in enumerate(sum_row_f, 1):
            c = ws.cell(3 + n, col, val)
            c.font = openpyxl.styles.Font(bold=True)
            c.alignment = openpyxl.styles.Alignment(horizontal="left", vertical="center")

        for col in range(1, total_cols + 1):
            ws.column_dimensions[openpyxl.utils.get_column_letter(col)].width = 16

        path = _save_excel(wb, "话务统计")
        return {"success": True, "file_path": path, "data_count": n,
                "message": "话务统计报表生成成功，共" + str(n) + "条数据"}

    # ── 单项目：保留原有完整列 ─────────────────────────────────────────
    # 数据行中，取 data.groups 按 sortindex 取 grouname
    tag_defs = items[0].get("tag", {}).get("groups", []) or r["data"].get("groups", []) or []
    tag_defs_sorted = sorted(tag_defs, key=lambda x: int(x.get("sortindex", 0) or 0))
    group_names = [t.get("title", "") or t.get("grouname", "") or t.get("name", "") for t in tag_defs_sorted]
    col_id_map = {str(t.get("id", "")).strip(): i for i, t in enumerate(tag_defs_sorted)}

    BASE = ["时间", "项目", "任务",
            "总量", "接通量", "接通率(%)",
            "质检率(%)", "时长(分)"]

    total_cols = len(BASE) + len(group_names)
    _hide = _parse_hide_columns(hide_columns)
    base_show = [h for h in BASE if h.lower() not in _hide]
    group_show = [g for g in group_names if g.lower() not in _hide]
    total_cols = len(base_show) + len(group_show)

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "话务统计"

    # 合并表头第二行
    for ci, h in enumerate(base_show, 1):
        c = ws.cell(1, ci, h)
        c.font = openpyxl.styles.Font(bold=True)
        c.alignment = openpyxl.styles.Alignment(horizontal="center", vertical="center")
        ws.merge_cells(start_row=1, start_column=ci, end_row=2, end_column=ci)

    stat_start = len(base_show) + 1
    if group_names:
        ws.merge_cells(start_row=1, start_column=stat_start,
                       end_row=1, end_column=total_cols)
        c = ws.cell(1, stat_start, "统计信息")
        c.font = openpyxl.styles.Font(bold=True)
        c.alignment = openpyxl.styles.Alignment(horizontal="center", vertical="center")
        for gi, gn in enumerate(group_show):
            c = ws.cell(2, stat_start + gi, gn)
            c.font = openpyxl.styles.Font(bold=True)
            c.alignment = openpyxl.styles.Alignment(horizontal="center", vertical="center")

    # 填充数据行
    rows_data = []
    for ri, it in enumerate(items, 3):
        tag = it.get("tag", {})
        gvals = ["" for _ in range(len(group_names))]
        for g in tag.get("groups", []):
            idx = col_id_map.get(str(g.get("id", "")).strip())
            if idx is not None:
                gvals[idx] = str(g.get("value", ""))

        row = [
            tag.get("day", ""),             # 时间（日期 YYYY-MM-DD）
            tag.get("topicname", ""),    # 项目
            tag.get("ruletitle", "") or tag.get("rulename", ""),  # 任务
            _safe_int(it.get("total")),    # 总量
            _safe_int(it.get("connect")),  # 接通量
            _fmt_rate(it.get("connect"), it.get("total")),    # 接通率(%)
            _strip_zero(tag.get("chk", "0")),  # 质检率(%)
            _safe_int(it.get("time")),      # 时长(分)
        ] + gvals

        rows_data.append({"gvals": gvals})
        # Filter hidden BASE columns from row before writing
        row_filtered = [v for i, v in enumerate(row) if i < len(BASE) and BASE[i].lower() not in _hide]
        gvals_filtered = [v for i, v in enumerate(gvals) if i < len(group_names) and group_names[i].lower() not in _hide]
        for col, val in enumerate(row_filtered + gvals_filtered, 1):
            ws.cell(ri, col, val).alignment = openpyxl.styles.Alignment(
                horizontal="left", vertical="center")

    # 合计行（只合计数字列）
    n = len(items)
    stat_sums = [0.0] * len(group_names)
    for rd in rows_data:
        for ci, v in enumerate(rd["gvals"]):
            try:
                stat_sums[ci] += float(v)
            except (ValueError, TypeError):
                pass

    # 合计行（优先取 id=0 汇总行，否则自己合计）
    summary_row = next((x for x in raw if str(x.get("id")) == "0"), None)
    if summary_row:
        s_tag = summary_row.get("tag", {})
        s_total = _safe_int(summary_row.get("total"))
        s_connect = _safe_int(summary_row.get("connect"))
        s_dur_min = _safe_int(summary_row.get("time"))
        s_chk_rate = _strip_zero(s_tag.get("chk", "0")) or "0"
    else:
        s_total = sum(_safe_int(it.get("total")) for it in items)
        s_connect = sum(_safe_int(it.get("connect")) for it in items)
        s_dur_min = sum(_safe_int(it.get("time")) for it in items)
        s_chk_rate = "0"

    sum_row = [
        "合计", "", "",
        s_total, s_connect, _fmt_rate(s_connect, s_total), s_chk_rate, s_dur_min
    ] + stat_sums

    # Filter hidden columns from sum row
    sum_base = [v for i, v in enumerate(sum_row) if i < len(BASE) and BASE[i].lower() not in _hide]
    stat_sum_filtered = [v for i, v in enumerate(stat_sums) if i < len(group_names) and group_names[i].lower() not in _hide]
    sum_row_f = sum_base + stat_sum_filtered

    for col, val in enumerate(sum_row_f, 1):
        c = ws.cell(3 + n, col, val)
        c.font = openpyxl.styles.Font(bold=True)
        c.alignment = openpyxl.styles.Alignment(horizontal="left", vertical="center")

    for col in range(1, total_cols + 1):
        ws.column_dimensions[openpyxl.utils.get_column_letter(col)].width = 16

    path = _save_excel(wb, "话务统计")
    return {"success": True, "file_path": path, "data_count": n,
            "message": "话务统计报表生成成功，共" + str(n) + "条数据"}

def generate_agent_report(topic_id, daterange, rule_id=None, exte=None, so=None, ratio=False, hide_columns=None):
    """
    坐席话务报表 - know2.txt 规范（14列 + 动态分组列）

    参数：topicId(必填)，ruleId(单项目时必填)，daterange(必填)
    列：坐席号、名称、项目、项目数、总量、接通量、接通率、时长(分)、
        进线均长(秒)、成功时长(分)、成功均长(秒)、成功量、成功率、
        质检通过量、质检作废量 + 统计分组列
    
    多项目时：逐项目调用API，然后合并结果，每项目单独一行
    """
    import math as _math

    is_multi = "," in str(topic_id)
    if not is_multi and not rule_id:
        return {"success": False, "message": "单项目时任务ID(rule_id)为必填"}

    token, secret = _session()
    api = _api_url()
    daterange = _fmt_daterange(daterange)

    params_base = {"pi": 1, "ps": 1000, "daterange": daterange}
    if exte:
        params_base["exte"] = str(exte)
    if so:
        params_base["so"] = str(so)

    # 多项目时：直接调用API，返回数据已经是合并后的
    if is_multi:
        params = dict(params_base)
        params["topicIds"] = str(topic_id)
        # 多项目不传ruleId
        r = au.call_api(api, "GetDailyAgents", params, token, secret)
        if r.get("succeed") != "true" and r.get("code") != "1":
            return {"success": False, "message": r.get("message", "获取数据失败")}
        if not r.get("data"):
            return {"success": False, "message": "API返回数据为空"}

        raw = r["data"].get("list", []) or r["data"].get("items", [])
        items = [x for x in raw if str(x.get("id", "")) != "0"
                 and str(x.get("exte", "")).strip() != "合计"]
        # 按坐席号排序（升序）
        items.sort(key=lambda x: int(x.get("exte", 0)) if str(x.get("exte", "")).isdigit() else x.get("exte", ""))
        
        tag_defs = items[0].get("tag", {}).get("groups", []) or r["data"].get("tag", []) or []
        
        if not items:
            return {"success": False, "message": "无数据"}
    else:
        # 单项目：原有逻辑
        params = dict(params_base)
        params["topicIds"] = str(topic_id)
        params["ruleId"] = str(rule_id)
        r = au.call_api(api, "GetDailyAgents", params, token, secret)
        if r.get("succeed") != "true" and r.get("code") != "1":
            return {"success": False, "message": r.get("message", "获取数据失败")}
        if not r.get("data"):
            return {"success": False, "message": "API返回数据为空"}

        raw = r["data"].get("list", []) or r["data"].get("items", [])
        items = [x for x in raw if str(x.get("id", "")) != "0"
                 and str(x.get("exte", "")).strip() != "合计"]
        tag_defs = items[0].get("tag", {}).get("groups", []) or r["data"].get("tag", []) or []

    if not items:
        return {"success": False, "message": "无数据"}
    tag_defs_sorted = sorted(tag_defs, key=lambda x: int(x.get("id", 0) or 0))
    group_names = [t.get("title") or t.get("grouname", "") for t in tag_defs_sorted]
    col_id_map = {str(t["id"]): i for i, t in enumerate(tag_defs_sorted)}

    BASE = ["坐席号", "坐席名称",
            "项目名称",  # 多项目时显示实际项目名，每行一个项目
            "总量", "接通量", "接通率(%)",
            "时长(分)", "进线平均时长(秒)", "成功时长(分)", "成功平均时长(秒)",
            "成功量", "成功率(%)",
            "质检通过量", "质检作废量"]

    total_cols = len(BASE) + len(group_names)
    _hide = _parse_hide_columns(hide_columns)
    base_show = [h for h in BASE if h.lower() not in _hide]
    group_show = [g for g in group_names if g.lower() not in _hide]
    total_cols = len(base_show) + len(group_show)

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "话务报表"

    # 表头第一行：基础列合并两行，分组列合并第一行
    for ci, h in enumerate(base_show, 1):
        c = ws.cell(1, ci, h)
        c.font = openpyxl.styles.Font(bold=True)
        c.alignment = openpyxl.styles.Alignment(horizontal="center", vertical="center")
        ws.merge_cells(start_row=1, start_column=ci, end_row=2, end_column=ci)

    stat_start = len(base_show) + 1
    if group_names:
        ws.merge_cells(start_row=1, start_column=stat_start,
                       end_row=1, end_column=total_cols)
        c = ws.cell(1, stat_start, "统计信息")
        c.font = openpyxl.styles.Font(bold=True)
        c.alignment = openpyxl.styles.Alignment(horizontal="center", vertical="center")
        for gi, gn in enumerate(group_show):
            c = ws.cell(2, stat_start + gi, gn)
            c.font = openpyxl.styles.Font(bold=True)
            c.alignment = openpyxl.styles.Alignment(horizontal="center", vertical="center")

    # 数据行
    rows_data = []
    for ri, it in enumerate(items, 3):
        tag = it.get("tag", {})
        exte_v = str(it.get("exte", "")).strip()
        name = tag.get("employee", {}).get("name", "") or tag.get("name", "")

        total = _safe_int(it.get("total"))
        connect = _safe_int(it.get("connect"))
        complete = _safe_int(it.get("complete"))
        dur_raw = _safe_int(it.get("duration"))
        talk_raw = _safe_int(it.get("talksec"))

        dur_min = _math.ceil(dur_raw / 60) if dur_raw > 0 else 0
        talk_min = _math.ceil(talk_raw / 60) if talk_raw > 0 else 0
        callave = _safe_float(it.get("callave"))
        talkave = _safe_float(it.get("talkave"))

        gvals = ["" for _ in range(len(group_names))]
        for g in tag.get("groups", []):
            idx = col_id_map.get(str(g.get("id", "")).strip())
            if idx is not None:
                gvals[idx] = str(g.get("value", ""))

        def rate_fmt(a, b):
            pct = round(a / b * 100, 2) if b > 0 else 0
            return f"{a}({pct}%)" if ratio else pct

        proj_v = tag.get("topicname", "")  # 多项目时API已返回合并后的项目名

        row = [exte_v, name, proj_v,
               total, connect, rate_fmt(connect, total),
               dur_min, callave, talk_min, talkave,
               complete, rate_fmt(complete, connect),
               _safe_int(it.get("chky")), _safe_int(it.get("chkn"))
               ] + gvals

        rows_data.append({
            "total": total, "connect": connect, "complete": complete,
            "chky": _safe_int(it.get("chky")), "chkn": _safe_int(it.get("chkn")),
            "dur_raw": dur_raw, "talk_raw": talk_raw,
            "gvals": gvals,
        })

        for col, val in enumerate(row, 1):
            ws.cell(ri, col, val).alignment = openpyxl.styles.Alignment(
                horizontal="left", vertical="center")

    # 合计行
    n = len(items)
    s_total = sum(r["total"] for r in rows_data)
    s_conn = sum(r["connect"] for r in rows_data)
    s_comp = sum(r["complete"] for r in rows_data)
    s_chky = sum(r["chky"] for r in rows_data)
    s_chkn = sum(r["chkn"] for r in rows_data)
    s_dur = sum(r["dur_raw"] for r in rows_data)
    s_talk = sum(r["talk_raw"] for r in rows_data)

    # 统计列合计和平均
    stat_sums = [0.0] * len(group_names)
    for rd in rows_data:
        for ci, v in enumerate(rd["gvals"]):
            try:
                stat_sums[ci] += float(v)
            except (ValueError, TypeError):
                pass
    stat_avgs = [round(stat_sums[i] / n, 2) if n > 0 else 0.0 for i in range(len(group_names))]

    # 取 API 合计行(id=0)的预计算值
    sum_callave = sum_talkave = 0.0
    for it in raw:
        if str(it.get("id", "")) == "0":
            sum_callave = _safe_float(it.get("callave"))
            sum_talkave = _safe_float(it.get("talkave"))
            break

    sum_row = (
        ["合计", str(n), ""]
        + [s_total, s_conn, _fmt_rate(s_conn, s_total)]
        + [_math.ceil(s_dur / 60), sum_callave,
           _math.ceil(s_talk / 60), sum_talkave]
        + [s_comp, _fmt_rate(s_comp, s_conn),
           s_chky, s_chkn]
        + stat_sums
    )
    sum_base = [v for i, v in enumerate(sum_row) if i < len(BASE) and BASE[i].lower() not in _hide]
    stat_sum_f = [v for i, v in enumerate(stat_sums) if i < len(group_names) and group_names[i].lower() not in _hide]
    sum_row_f = sum_base + stat_sum_f

    # 平均行 - 必须先定义再使用
    avg_row = (
        ["平均", "", ""]
        + [round(s_total / n, 2), round(s_conn / n, 2), _fmt_rate(s_conn, s_total)]
        + [_math.ceil(s_dur / n / 60), sum_callave,
           _math.ceil(s_talk / n / 60), sum_talkave]
        + [round(s_comp / n, 2), _fmt_rate(s_comp, s_conn),
           round(s_chky / n, 2), round(s_chkn / n, 2)]
        + stat_avgs
    )
    avg_base = [v for i, v in enumerate(avg_row) if i < len(BASE) and BASE[i].lower() not in _hide]
    stat_avg_f = [v for i, v in enumerate(stat_avgs) if i < len(group_names) and group_names[i].lower() not in _hide]
    avg_row_f = avg_base + stat_avg_f

    for col, val in enumerate(sum_row_f, 1):
        c = ws.cell(3 + n, col, val)
        c.font = openpyxl.styles.Font(bold=True)
        c.alignment = openpyxl.styles.Alignment(horizontal="left", vertical="center")

    for col, val in enumerate(avg_row_f, 1):
        c = ws.cell(3 + n + 1, col, val)
        c.font = openpyxl.styles.Font(bold=True)
        c.alignment = openpyxl.styles.Alignment(horizontal="left", vertical="center")

    for col in range(1, total_cols + 1):
        ws.column_dimensions[openpyxl.utils.get_column_letter(col)].width = 16

    path = _save_excel(wb, "话务报表")
    return {"success": True, "file_path": path, "data_count": n,
            "message": f"话务报表生成成功，共{n}条坐席数据"}


# =============================================================================
# 坐席考勤报表（GetDailyWorks）
# =============================================================================

def generate_attendance_report(daterange, exte=None, hide_columns=None):
    """
    坐席考勤报表（GetDailyWorks）
    列：日期、账号名称、登陆时间、退出时间、签入次数、工作时长(分)、无效工作时长(分)、
        通话时长(分)、效率、总量、接通量、接通率、成功量、成功率
    合计行：有（排全部明细行之后）
    平均行：无
    """
    import math as _math

    def _parse_day(iday):
        """'240318' -> '2024-03-18'"""
        s = str(iday).strip()
        if len(s) == 6:
            return '20' + s[0:2] + '-' + s[2:4] + '-' + s[4:6]
        return s

    def _hhmm(t):
        """'2024/3/18 16:14:03' -> '16:14'"""
        s = str(t).strip()
        if not s:
            return ''
        parts = s.split(' ')
        if len(parts) >= 2:
            hm = parts[1].split(':')
            return hm[0].zfill(2) + ':' + hm[1]
        return s[:5]

    token, secret = _session()
    api = _api_url()
    daterange = _fmt_daterange(daterange)

    params = {"pi": 1, "ps": 1000, "daterange": daterange}
    if exte:
        params["exte"] = str(exte)

    r = au.call_api(api, "GetDailyWorks", params, token, secret)
    if r.get("succeed") != "true" and r.get("code") != "1":
        return {"success": False, "message": r.get("message", "获取数据失败")}

    items = r.get("data", {}).get("list", []) or r.get("data", {}).get("items", [])
    if not items:
        return {"success": False, "message": "无数据"}

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "坐席考勤报表"

    headers = ["日期", "账号名称", "登录时间", "退出时间", "签入次数",
               "工作时长(分)", "有效工作时长(分)", "无效工作时长(分)", "通话时长(分)", "空闲时长(分)", "效率",
               "总量", "接通量", "接通率", "成功量", "成功率"]

    _hide = _parse_hide_columns(hide_columns)
    show_headers = [h for h in headers if h.lower() not in _hide]
    for col, h in enumerate(show_headers, 1):
        c = ws.cell(1, col, h)
        c.font = openpyxl.styles.Font(bold=True)
        c.alignment = openpyxl.styles.Alignment(horizontal="center", vertical="center")

    rows = []
    for item in items:
        tag = item.get("tag", {})
        agent = tag.get("agent", {})

        day = _parse_day(item.get("iday", ""))
        name = item.get("name", "")
        login = _hhmm(item.get("login", ""))
        logout = _hhmm(item.get("logout", ""))
        login_count = _safe_int(item.get("logincount"))

        mins = _safe_int(item.get("mins"))      # 总工作时长（秒）
        secs = _safe_int(item.get("secs"))      # 有效工作时长（秒）
        duration_raw = agent.get("duration")             # 原始通话时长（用于判断是否存在）
        duration = _safe_int(duration_raw)                # 通话时长（秒）

        # 工作时长（分）- 向上取整
        work_min = _math.ceil(mins / 60) if mins > 0 else 0
        # 有效工作时长（分）- 向上取整
        # 先向上取整到分
        work_min = _math.ceil(mins / 60) if mins > 0 else 0   # 总工作时长（分）
        secs_min = _math.ceil(secs / 60) if secs > 0 else 0   # 有效工作时长（分）
        dur_min = _math.ceil(duration / 60) if duration > 0 else 0  # 通话时长（分）

        # 无效工作时长 = 总工作时长 - 有效工作时长
        # 条件：secs_min > 0 且相减结果 > 0
        invalid_min = work_min - secs_min if secs_min > 0 and work_min > secs_min else 0
        # 通话时长 = 直接用向上取整的值
        talk_min = dur_min
        # 空闲时长计算
        # duration 不存在（None）→ 新规则：ceil(secs/60) 如果 >0
        # duration 存在（任意值，包括-1）→ 旧规则：secs_min - dur_min，条件：secs_min > 0 且 dur_min > 0 且差值 >0
        if duration_raw is None:
            idle_min = secs_min if secs_min > 0 else 0
        else:
            idle_min = secs_min - dur_min if secs_min > 0 and dur_min > 0 and (secs_min - dur_min) > 0 else 0
        # 有效工作时长（兼容原变量名）
        valid_min = secs_min

        # 效率：通话时长(分) / 有效工作时长(分) * 100，上限100，负值置0
        if valid_min > 0:
            eff = min(talk_min / valid_min * 100, 100)
        else:
            eff = 0

        total = max(_safe_int(agent.get("total")), 0)
        connect = max(_safe_int(agent.get("connect")), 0)
        complete = max(_safe_int(agent.get("complete")), 0)

        def _fmt_pct(v):
            if v == 0:
                return "0%"
            try:
                v = float(v)
            except (ValueError, TypeError):
                pass
            s = f"{v:.2f}".rstrip("0").rstrip(".")
            return s + "%"

        rows.append([
            day, name, login, logout, login_count,
            work_min, valid_min, invalid_min, talk_min, idle_min, _fmt_pct(round(eff, 2)),
            total, connect, _fmt_pct(_fmt_rate(connect, total)),
            complete, _fmt_pct(_fmt_rate(complete, connect)),
        ])

    n = len(rows)

    # 写入明细行（根据 hide_columns 过滤）
    for ri, row in enumerate(rows, 2):
        filtered_vals = [v for i, v in enumerate(row) if i < len(headers) and headers[i].lower() not in _hide]
        for col, val in enumerate(filtered_vals, 1):
            ws.cell(ri, col, val).alignment = openpyxl.styles.Alignment(
                horizontal="left", vertical="center")

    for col in range(1, len(show_headers) + 1):
        ws.column_dimensions[openpyxl.utils.get_column_letter(col)].width = 16

    path = _save_excel(wb, "考勤报表")
    return {"success": True, "file_path": path, "data_count": n,
            "message": "考勤报表生成成功，共{}条数据".format(n)}



def generate_quality_report(topic_ids, daterange, rule_id=None, user_id=None, show_employee=True, hide_columns=None):
    """
    质检报表
    包含：时间、项目名称、规则名称、质检员、质检通过量、质检总量

    show_employee：是否显示质检员列，默认True（显示）；设为False则隐藏该列
    hide_columns：要隐藏的列名列表（支持列表或逗号分隔字符串），如 hide_columns=["质检通过量", "规则名称"]
    """
    is_single = "," not in str(topic_ids)
    if is_single and not rule_id:
        raise TypeError("单项目时规则ID(rule_id)为必填")

    hide = _parse_hide_columns(hide_columns)
    if not show_employee:
        hide = hide | {"质检员"}

    token, secret = _session()
    api = _api_url()
    daterange = _fmt_daterange(daterange)

    params = {"topicIds": str(topic_ids), "daterange": daterange}
    if rule_id:
        params["ruleId"] = str(rule_id)
    if user_id:
        params["userId"] = str(user_id)

    r = au.call_api(api, "GetDailyChks", params, token, secret)
    if r.get("succeed") != "true" and r.get("code") != "1":
        return {"success": False, "message": r.get("message", "获取数据失败")}

    raw = r.get("data", [])
    items = [x for x in raw if str(x.get("id", "")) != "0"]

    # 列配置：(列名, lambda取值的函数)
    ALL_COLS = [
        ("时间",       lambda: tag.get("day", "")),
        ("项目名称",   lambda: tag.get("topicname", "")),
        ("规则名称",   lambda: tag.get("ruletitle", "")),
        ("质检员",     lambda: tag.get("employee", {}).get("name", "")),
        ("质检通过量", lambda: _safe_int(item.get("chky"))),
        ("质检总量",   lambda: _safe_int(item.get("chkn"))),
    ]

    show_cols = [(name, fn) for name, fn in ALL_COLS if name.lower() not in hide]

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "质检报表"
    ws.append([name for name, _ in show_cols])

    for item in items:
        tag = item.get("tag", {})
        ws.append([fn() for _, fn in show_cols])

    total_chky = sum(max(0, _safe_int(x.get("chky"))) for x in items)
    total_chkn = sum(max(0, _safe_int(x.get("chkn"))) for x in items)
    sum_row = []
    for name, _ in show_cols:
        if name == "时间":
            sum_row.append("合计")
        elif name in ("项目名称", "规则名称", "质检员"):
            sum_row.append("")
        elif name == "质检通过量":
            sum_row.append(total_chky)
        else:
            sum_row.append(total_chkn)
    ws.append(sum_row)

    path = _save_excel(wb, "质检报表")
    return {"success": True, "file_path": path, "data_count": len(items),
            "message": f"质检报表生成成功，共{len(items)}条数据"}

def generate_smart_quality_report(daterange, rule_id, display_exte=False, display_code=False, userid=None, hide_columns=None):
    """
    智能质检报表

    API 返回结构：
        header = {key: 名称, ...}   # 如 {exte:坐席号, code:题号, Id_2584:LLM模型多项正确率}
        list   = [{key: value, ...}, ...]  # 每行按 header 的 key 取值

    displayExte：是否显示坐席号
    displayCode：是否显示题号
    userid：质检员ID（可选）。支持传入员工名称，会自动通过 GetEmployeeLs 查找对应ID
    """

    if not rule_id:
        raise TypeError("任务ID(rule_id)为必填")
    if not daterange:
        raise TypeError("daterange为必填")
    if not display_exte and not display_code:
        raise TypeError("displayExte或displayCode至少选一个")

    # 如果 userid 是字符串，则认为是员工名称，需要先查找员工ID
    resolved_userid = userid
    if userid and isinstance(userid, str):
        # 通过 GetEmployeeLs 搜索员工
        emp_result = au.call_api(_api_url(), "GetEmployeeLs", {
            "word": userid,
            "pi": 1,
            "ps": 10
        }, *_session())
        if emp_result.get("succeed"):
            items = emp_result.get("data", {}).get("list", [])
            matched = [e for e in items if userid in (e.get("employee", {}).get("name") or "")]
            if matched:
                resolved_userid = matched[0].get("employee", {}).get("userid")
            else:
                raise TypeError("未找到名为【" + userid + "】的员工，请检查姓名是否正确")
        else:
            raise TypeError("GetEmployeeLs 调用失败：" + emp_result.get("message", "未知错误"))

    token, secret = _session()
    api = _api_url()
    daterange = _fmt_daterange(daterange)

    params = {
        "ruleId": str(rule_id),
        "daterange": daterange,
        "displayExte": "true" if str(display_exte).lower() == "true" else "false",
        "displayCode": "true" if str(display_code).lower() == "true" else "false",
    }
    if resolved_userid:
        params["userid"] = str(resolved_userid)

    r = au.call_api(api, "GetAiChkReport", params, token, secret)
    if not r.get("succeed"):
        return {"success": False, "message": r.get("message", "API调用失败")}

    data = r.get("data", {})
    header_dict = data.get("header", {})
    rows = data.get("list", [])

    # 排序：exte 和 code 放前面，Id_ 放中间
    def _sort_key(k):
        if k == "exte":  return (0, 0)
        if k == "code":  return (0, 1)
        if k.startswith("Id_"): return (1, int(k.split("_")[1]))
        return (2, k)
    header_keys = sorted(header_dict.keys(), key=_sort_key)
    header_vals = [header_dict[k] for k in header_keys]

    # 去除合计行
    data_rows = [row for row in rows
                 if str(row.get("Code", row.get("code", ""))).strip() != "合计"]

    # 写入 Excel
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "智能质检报表"
    _hide = _parse_hide_columns(hide_columns)
    if _hide:
        filtered_pairs = [(k, header_dict[k]) for k in header_keys if header_dict.get(k, "").lower() not in _hide]
        header_keys = [p[0] for p in filtered_pairs]
        header_vals = [p[1] for p in filtered_pairs]
    ws.append(header_vals)

    for row in rows:
        if isinstance(row, dict):
            row_lc = {k.lower(): v for k, v in row.items()}
            # 严格按 header 的写，缺失的填空
            header_keys_set = set(k.lower() for k in header_keys)
            filtered_row = {k: v for k, v in row_lc.items() if k in header_keys_set}
            row_vals = [filtered_row.get(k.lower(), '') for k in header_keys]
            ws.append(row_vals)
        else:
            ws.append(row)

    # 合计行：只有 Id_ 开头的列填数字
    bold = openpyxl.styles.Font(bold=True)
    al = openpyxl.styles.Alignment(horizontal="left", vertical="center")
    sum_row = []
    for i, k in enumerate(header_keys):
        if i == 0:
            sum_row.append("合计")  # 第一列显示合计
        elif k.startswith("Id_"):
            total = 0
            for row in data_rows:
                row_lc = {kk.lower(): vv for kk, vv in row.items()}
                try:
                    total += int(float(row_lc.get(k.lower(), "0") or "0"))
                except (TypeError, ValueError):
                    pass
            sum_row.append(total)
        else:
            sum_row.append("")
    ws.append(sum_row)
    for ci in range(1, len(sum_row) + 1):
        ws.cell(ws.max_row, ci).font = bold
        ws.cell(ws.max_row, ci).alignment = al

    path = _save_excel(wb, "智能质检报表")
    return {"success": True, "file_path": path, "data_count": len(data_rows),
            "message": "智能质检报表生成成功，共" + str(len(data_rows)) + "条明细"}


def generate_monitor_report(mid, topicId=None, daterange=None, rule_id=None, exte=None, attr=None, hide_columns=None):
    """
    监控报表（GetDailyMon）
    参数：
        mid       : 监控模板ID（Int32，必填）
        topicId   : 项目ID（Int32，可选），GetMonmodLs 需要用项目ID查模板，
                   不传则尝试用 mid 本身作为 topicId 查询，失败则提示用户提供
        daterange : 日期范围（String，Cell包含2时必填），格式 "YYYY-MM-DD,YYYY-MM-DD"
        rule_id   : 任务ID（Int32，Cell包含1时必填）
        exte      : 坐席号（String，Cell包含8时可选，不传则不限坐席）
        attr      : 属性（String，可选）
    返回：{"success": True, "file_path": "...", "data_count": N, "message": "..."}
          {"success": False, "message": "错误原因"}
    Cell 位掩码规则：
        1  = 需要任务  → rule_id 必填
        2  = 需要日期  → daterange 必填
        8  = 需要坐席号（选填）
        16 = 什么都不需要（基础态）
        例：Cell=9  (1+8)      → 需要任务+坐席号
           Cell=27 (16+8+2+1) → 需要任务+坐席号+日期
    """
    token, secret = _session()
    api = _api_url()

    # ── Step 1：通过 GetMonmodLs 获取 cell 值 ──────────────────────
    # GetMonmodLs 用 project topicId 查询监控模板列表
    # 不传 topicId → 尝试用 mid 本身作为 topicId（有时两者相等）
    #               → 失败则提示用户提供
    template = None
    if topicId:
        r_list = au.call_api(api, "GetMonmodLs", {"topicId": str(topicId)}, token, secret)
        if r_list.get("succeed") == "true" or r_list.get("code") == "1":
            items = r_list.get("data", {}).get("items", [])
            for item in items:
                if str(item.get("id")) == str(mid):
                    template = item
                    break
    else:
        # 优先尝试 mid 当 topicId（性能最优）
        r_list = au.call_api(api, "GetMonmodLs", {"topicId": str(mid)}, token, secret)
        if r_list.get("succeed") == "true" or r_list.get("code") == "1":
            items = r_list.get("data", {}).get("items", [])
            for item in items:
                if str(item.get("id")) == str(mid):
                    template = item
                    break

    if not template:
        raise TypeError(
            f"未找到 mid={mid} 的监控模板。"
            f"请传入该项目所属的 topicId 参数（如 topicId=5726），"
            f"或通过 GetTopicLs 查询项目 ID。"
        )

    cell = int(template.get("cell", 16))
    template_title = template.get("title", "")

    # ── Step 2：解析 cell 位掩码，判断必填参数 ───────────────────────
    # 标志位：1=任务，2=日期，8=坐席号，16=基础态
    needs_task   = (cell & 1) != 0
    needs_date   = (cell & 2) != 0
    # base_only = (cell == 16)  # 纯基础态，什么都不加

    # 必填校验
    if needs_task and not rule_id:
        raise TypeError(
            f"监控模板「{template_title}」（cell={cell}）需要任务ID，"
            f"请传入 rule_id 参数。"
            f"该项目下可用任务：需用 GetRuleLs 查询 topicId={template.get('topicid')} 获取"
        )
    if needs_date and not daterange:
        raise TypeError(
            f"监控模板「{template_title}」（cell={cell}）需要日期范围，"
            f"请传入 daterange 参数，格式如 'YYYY-MM-DD,YYYY-MM-DD'"
        )

    # ── Step 3：组装 API 参数 ────────────────────────────────────────
    params = {"mid": int(mid)}
    if daterange:
        params["daterange"] = _fmt_daterange(daterange)
    if rule_id:
        params["ruleId"] = int(rule_id)
    if exte:
        params["exte"] = str(exte)
    if attr:
        params["attr"] = str(attr)

    r = au.call_api(api, "GetDailyMon", params, token, secret)
    if r.get("succeed") != "true" and r.get("code") != "1":
        return {"success": False, "message": r.get("message", "API调用失败")}
    if not r.get("data"):
        return {"success": False, "message": "API返回数据为空"}

    data = r.get("data", {})
    header = data.get("header", {})
    rows = data.get("list", [])

    # 列名合法性：单字母 A/I/O 补足
    def _sanitize_col(name):
        name = str(name).strip()
        if name.upper() in ("A", "I", "O") or len(name) <= 1:
            return name + "_col"
        return name

    # 监控报表标准列顺序（GetDailyMon 动态列固定这几类）
    # API 返回 header 字典，字段映射固定为：attr, rulename, date, dept, employee, total
    MONITOR_COL_ORDER = ["67", "任务", "日期", "团队", "姓名", "计数"]
    MONITOR_COL_FIELDS = ["attr", "rulename", "date", "dept", "employee", "total"]

    # 从 API header 中提取真实列名（有动态key如"67"可能略有差异，兜底用预设名）
    header_keys = list(header.keys())
    header_field_map = {header.get(k, k): k for k in header_keys}   # field_key → col_name

    # 按标准顺序排列，未出现的列追加到末尾
    col_names = []
    col_field_keys = []
    seen_fields = set()
    for wanted, field in zip(MONITOR_COL_ORDER, MONITOR_COL_FIELDS):
        col_names.append(_sanitize_col(wanted))
        col_field_keys.append(field)
        seen_fields.add(field)
    # 兜底：API 返回了标准顺序之外的额外列
    for k, fk in header.items():
        if fk not in seen_fields:
            col_names.append(_sanitize_col(k))
            col_field_keys.append(fk)

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "监控报表"
    _hide = _parse_hide_columns(hide_columns)
    if _hide:
        pairs = [(n, f) for n, f in zip(col_names, col_field_keys) if n.lower() not in _hide]
        col_names = [p[0] for p in pairs]
        col_field_keys = [p[1] for p in pairs]
    ws.append(col_names)

    data_rows = [row for row in rows if str(row.get("id", "")) != "0"]
    total_rows = [row for row in rows if str(row.get("id", "")) == "0"]
    bold_font = openpyxl.styles.Font(bold=True)

    # 写入全部行
    for row in rows:
        row_vals = []
        for fk in col_field_keys:
            v = row.get(fk, "")
            # 合计行（id=0）且 rulename 为空时显示"合计"
            if str(row.get("id", "")) == "0" and fk == "rulename" and not v:
                v = "合计"
            if str(row.get("id", "")) == "0" and fk == "rulename" and not v:
                v = "合计"
            row_vals.append(v)
        ws.append(row_vals)
        row_idx = ws.max_row
        # 合计行标粗
        if str(row.get("id", "")) == "0":
            for col_idx in range(1, len(col_names) + 1):
                ws.cell(row_idx, col_idx).font = bold_font

    # 无合计行但有明细时自行计算合计
    if not total_rows and data_rows:
        sum_row = ["合计"] + [0] * (len(col_field_keys) - 1)
        for i, fk in enumerate(col_field_keys[1:], 1):
            try:
                sum_row[i] = sum(int(float(row.get(fk, 0) or 0)) for row in data_rows)
            except (ValueError, TypeError):
                sum_row[i] = 0
        sum_idx = ws.max_row + 1
        ws.append(sum_row)
        for col_idx in range(1, len(sum_row) + 1):
            ws.cell(sum_idx, col_idx).font = bold_font

    path = _save_excel(wb, "监控报表")
    return {
        "success": True,
        "file_path": path,
        "data_count": len(rows),
        "message": f"监控报表生成成功，共{len(rows)}条数据，文件已保存至Downloads文件夹"
    }



# =============================================================================
# 通用导出函数（适用于通用流程 Choose=""）
# =============================================================================

def generic_export(
    api_method: str,
    params: dict = None,
    columns: list = None,
    data_key: str = None,
    filename: str = None,
    sheet_name: str = "Sheet1",
    column_titles: dict = None,
    hide_columns: list = None,
    require_sign: bool = True,
    auto_number: bool = True,
    include_total_row: bool = False,
):
    """
    通用导出函数 - 适用于通用流程（Choose=""）
    
    调用用户配置的 API，将返回数据导出为 Excel 文件。
    
    Args:
        api_method: API 方法名（必填），如 "GetUserList", "GetOrders" 等
        params: API 请求参数（可选，默认 {}）
        columns: 要导出的列名列表（可选，None 表示导出所有列）
                 示例: ['id', 'name', 'date', 'amount']
        data_key: 数据在响应中的键名（可选，None 表示自动检测）
                  常见值: 'data', 'list', 'rows', 'items', 'records'
        filename: 导出文件名（可选，默认 "导出_时间戳"）
        sheet_name: 工作表名称（默认 "Sheet1"）
        column_titles: 列名标题映射（可选）
                       示例: {'id': 'ID', 'name': '名称', 'date': '日期'}
        hide_columns: 要隐藏的列名列表（可选）
        require_sign: 是否需要签名（默认 True）
        auto_number: 是否自动添加序号列（默认 True）
        include_total_row: 是否添加合计行（默认 False，仅对数值列求和）
    
    Returns:
        dict: {
            'success': True/False,
            'file_path': '导出文件路径',
            'data_count': 数据条数,
            'message': '结果说明'
        }
    
    使用示例:
        # 基本用法 - 导出所有列
        result = generic_export('GetUserList', {'page': 1, 'size': 100})
        
        # 指定列名和标题
        result = generic_export(
            api_method='GetOrders',
            params={'status': 1, 'daterange': '2026-01-01,2026-04-30'},
            columns=['order_id', 'customer', 'amount', 'status'],
            column_titles={'order_id': '订单号', 'customer': '客户', 'amount': '金额', 'status': '状态'},
            filename='订单列表'
        )
    """
    import alluse as au
    
    # 参数默认值
    if params is None:
        params = {}
    if column_titles is None:
        column_titles = {}
    if hide_columns is None:
        hide_columns = []
    
    # 1. 调用 API
    try:
        result = au.execute_command('call_api', {
            'method': api_method,
            'params': params,
            'require_sign': require_sign
        })
    except Exception as e:
        return {'success': False, 'message': f'API 调用失败: {str(e)}'}
    
    # 2. 检查响应
    if not result:
        return {'success': False, 'message': 'API 无响应'}
    
    # 检查常见的错误状态字段
    status = result.get('status') or result.get('code') or result.get('ret')
    if status and str(status) not in ('0', '200', 'success', 'ok', 'true'):
        msg = result.get('message') or result.get('msg') or result.get('error') or '未知错误'
        return {'success': False, 'message': f'API 返回错误: {msg}'}
    
    # 3. 提取数据
    # 自动检测数据键名
    if data_key is None:
        for key in ['data', 'list', 'rows', 'items', 'records', 'result', 'results']:
            if key in result and isinstance(result.get(key), list):
                data_key = key
                break
    
    if data_key is None:
        # 如果没找到列表数据，尝试直接用响应根对象
        # 检查响应本身是否是列表（某些 API 直接返回数组）
        if isinstance(result, list):
            data = result
        else:
            # 找不到数据，返回错误
            return {'success': False, 'message': '响应中未找到列表数据，请指定 data_key 参数'}
    else:
        data = result.get(data_key, [])
    
    if not data:
        return {'success': False, 'message': '数据为空，无需导出'}
    
    # 4. 确定列名
    if columns is None:
        # 自动检测所有列名（从第一条数据）
        if isinstance(data[0], dict):
            columns = list(data[0].keys())
        else:
            return {'success': False, 'message': '数据格式不支持（非字典列表）'}
    
    # 过滤隐藏列
    if hide_columns:
        columns = [c for c in columns if c not in hide_columns]
    
    if not columns:
        return {'success': False, 'message': '没有可导出的列'}
    
    # 5. 创建 Excel
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = sheet_name
    
    # 表头
    header_row = []
    if auto_number:
        header_row.append('序号')
    
    for col in columns:
        # 使用 column_titles 映射，没有则用原列名
        header_row.append(column_titles.get(col, col))
    
    ws.append(header_row)
    
    # 表头样式
    bold_font = Font(bold=True)
    header_fill = PatternFill(start_color='D9E1F2', end_color='D9E1F2', fill_type='solid')
    for col_idx, cell in enumerate(ws[1], 1):
        cell.font = bold_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal='center')
    
    # 数据行
    for row_idx, item in enumerate(data, 1):
        if not isinstance(item, dict):
            continue
        
        row_vals = []
        if auto_number:
            row_vals.append(row_idx)
        
        for col in columns:
            val = item.get(col, '')
            # 空值处理
            if val is None:
                val = ''
            row_vals.append(val)
        
        ws.append(row_vals)
    
    # 6. 合计行（可选）
    if include_total_row and data:
        total_row = ['合计'] if auto_number else []
        numeric_cols = []  # 记录哪些列是数值列
        
        for col_idx, col in enumerate(columns):
            if auto_number:
                col_idx_offset = col_idx + 1  # 跳过序号列
            else:
                col_idx_offset = col_idx
            
            # 尝试计算数值列的和
            try:
                total = 0
                is_numeric = True
                for item in data:
                    val = item.get(col)
                    if val is not None:
                        total += float(val)
                    else:
                        is_numeric = False
                
                if is_numeric and total != 0:
                    total_row.append(_strip_zero(round(total, 2)))
                    numeric_cols.append(col_idx_offset)
                else:
                    total_row.append('')
            except (ValueError, TypeError):
                total_row.append('')
        
        ws.append(total_row)
        # 合计行加粗
        for col_idx in range(1, len(total_row) + 1):
            ws.cell(ws.max_row, col_idx).font = bold_font
    
    # 7. 设置列宽（自适应）
    for col_idx, col in enumerate(columns, 1):
        if auto_number:
            col_idx += 1  # 跳过序号列
        
        # 计算最大宽度
        max_width = len(str(column_titles.get(col, col)))  # 表头宽度
        for item in data:
            val = str(item.get(col, ''))
            # 中文字符算 2 宽度
            width = sum(2 if ord(c) > 127 else 1 for c in val)
            max_width = max(max_width, min(width, 50))  # 最大 50
        
        ws.column_dimensions[openpyxl.utils.get_column_letter(col_idx)].width = max_width + 2
    
    # 序号列宽度
    if auto_number:
        ws.column_dimensions['A'].width = 8
    
    # 8. 保存文件
    if filename is None:
        filename = f"导出_{datetime.now().strftime('%Y%m%d%H%M%S')}"
    
    downloads_dir = Path.home() / 'Downloads'
    file_path = downloads_dir / f"{filename}.xlsx"
    
    # 避免文件名冲突
    counter = 1
    while file_path.exists():
        file_path = downloads_dir / f"{filename}_{counter}.xlsx"
        counter += 1
    
    try:
        wb.save(str(file_path))
    except Exception as e:
        return {'success': False, 'message': f'文件保存失败: {str(e)}'}
    
    return {
        'success': True,
        'file_path': str(file_path),
        'data_count': len(data),
        'message': f'导出成功，共 {len(data)} 条数据，文件已保存至: {file_path}'
    }


# =============================================================================
# 入口：__main__ 测试
# =============================================================================

if __name__ == "__main__":
    import sys

    def _help():
        print("用法: python export_manager.py <功能> [参数JSON]")
        print("")
        print("功能列表:")
        print("  login          登录")
        print("  status         检查登录状态")
        print("  task_name      获取项目/任务名称  [{\"topic_id\": 5919, \"rule_id\": 4840}]")
        print("  download_report下载会话报表      [{\"topic_id\":5919,\"rule_id\":4840,\"daterange\":\"2026-03-06,2026-03-06\"}]")
        print("  export_cdr     导出会话记录      [{\"topic_id\":5919,\"rule_id\":4840}]")
        print("  import_cdr     导入会话记录      [{\"rule_id\":4920,\"file_path\":\"xxx.cdr\"}]")
        print("  traffic        话务报表          [{\"topic_ids\":5919,\"daterange\":\"...\",\"rule_id\":...}]")
        print("  agent          坐席话务报表      [{\"topic_id\":5919,\"daterange\":\"...\",\"rule_id\":...}]")
        print("  attendance     考勤报表          [{\"daterange\":\"...\"}]")
        print("  quality        质检报表          [{\"topic_ids\":5919,\"daterange\":\"...\",\"rule_id\":...}]")
        print("  smart_quality  智能质检报表      [{\"rule_id\":4897,\"daterange\":\"...\",\"display_exte\":true}]")
        print("  monitor       监控报表           [{\"mid\":115,\"topicId\":5726,\"daterange\":\"2025-08-07,2025-08-15\",\"rule_id\":4374}]")

    if len(sys.argv) < 2:
        _help()
        sys.exit(0)

    cmd = sys.argv[1]
    params = json.loads(sys.argv[2]) if len(sys.argv) > 2 else {}

    if cmd == "login":
        print(json.dumps(au.login(params["account"], params["password"], params.get("api_url", _api_url())), ensure_ascii=False))
    elif cmd == "status":
        print(json.dumps(au.check_login_status(), ensure_ascii=False))
    elif cmd == "task_name":
        print(json.dumps(get_task_name(params["topic_id"], params.get("rule_id")), ensure_ascii=False))
    elif cmd == "download_report":
        print(json.dumps(download_report(**params), ensure_ascii=False))
    elif cmd == "export_cdr":
        print(json.dumps(export_cdr(params["topic_id"], params.get("rule_id")), ensure_ascii=False))
    elif cmd == "import_cdr":
        print(json.dumps(import_cdr(params["rule_id"], params["file_path"]), ensure_ascii=False))
    elif cmd == "traffic":
        print(json.dumps(generate_traffic_report(**params), ensure_ascii=False))
    elif cmd == "agent":
        print(json.dumps(generate_agent_report(**params), ensure_ascii=False))
    elif cmd == "attendance":
        print(json.dumps(generate_attendance_report(**params), ensure_ascii=False))
    elif cmd == "quality":
        print(json.dumps(generate_quality_report(**params), ensure_ascii=False))
    elif cmd == "smart_quality":
        print(json.dumps(generate_smart_quality_report(**params), ensure_ascii=False))
    elif cmd == "monitor":
        print(json.dumps(generate_monitor_report(**params), ensure_ascii=False))
    elif cmd == "generic":
        print(json.dumps(generic_export(**params), ensure_ascii=False))
    else:
        print(json.dumps({"success": False, "message": f"未知命令: {cmd}"}, ensure_ascii=False))
