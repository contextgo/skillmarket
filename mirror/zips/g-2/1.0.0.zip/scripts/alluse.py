#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Auto-API 统一调用脚本
功能：登录管理、API 调用、日志记录、安全处理
"""

import os
import sys
import json
import time
import requests
import hashlib
from datetime import datetime, timedelta
from pathlib import Path

# ==================== 配置加载 ====================

def load_meta():
    """加载 meta.json 配置"""
    script_dir = Path(__file__).parent
    meta_path = script_dir.parent / "meta.json"
    with open(meta_path, 'r', encoding='utf-8') as f:
        return json.load(f)


def get_choose():
    meta = load_meta()
    if meta and 'Items' in meta and len(meta['Items']) > 0:
        return meta['Items'][0].get('Choose', '')
    return ''



def load_api_use_info(meta_config):
    """加载 API 使用说明文件"""
    script_dir = Path(__file__).parent
    use_info_path = script_dir.parent / meta_config['Items'][0]['ApiUseInfo']
    with open(use_info_path, 'r', encoding='utf-8') as f:
        return f.read()

# ==================== 日志系统 ====================

def get_log_path():
    """获取今日日志文件路径"""
    script_dir = Path(__file__).parent
    log_dir = script_dir.parent / "Log"
    log_dir.mkdir(exist_ok=True)
    today = datetime.now().strftime("%Y%m%d")
    return log_dir / f"{today}.txt"

def write_log(message, level="ERROR"):
    """写入日志（敏感信息脱敏）"""
    # 只记录 ERROR 级别日志
    if level != "ERROR":
        return
    log_path = get_log_path()
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # 敏感信息脱敏
    safe_message = desensitize(message)
    
    log_line = f"[{timestamp}] [{level}] {safe_message}\n"
    with open(log_path, 'a', encoding='utf-8') as f:
        f.write(log_line)

def desensitize(text):
    """敏感信息脱敏处理"""
    if not text:
        return text
    
    # 脱敏 Token（显示前后各 4 位）
    if 'Token' in text or 'token' in text or 'appkey' in text:
        import re
        text = re.sub(r'["\']?[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{6,}["\']?', '"***TOKEN***"', text)
    
    # 脱敏密码
    if 'password' in text.lower() or 'pwd' in text.lower():
        import re
        text = re.sub(r'["\'][^"\']{32,}["\']', '"***PWD***"', text)
    
    # 脱敏手机号
    import re
    text = re.sub(r'1[3-9]\d{9}', '1****0000', text)
    
    return text

# ==================== 会话管理 ====================

def get_session_file():
    """获取会话状态文件路径"""
    script_dir = Path(__file__).parent
    return script_dir / "session_state.json"


def get_flow_type():
    session = load_session()
    if session:
        return session.get('flow_type', '')
    return ''



def load_session():
    """加载当前会话状态"""
    session_file = get_session_file()
    if not session_file.exists():
        return None
    
    try:
        with open(session_file, 'r', encoding='utf-8') as f:
            session = json.load(f)
        
        # 注意：会话过期由框架检测用户沉默时间处理
        # 此处不再自动检查30分钟超时，避免对话过程中意外过期
        
        return session
    except Exception as e:
        write_log(f"加载会话失败：{str(e)}", "ERROR")
        return None

def save_session(account, token, secret, username_display="", company_id=None):
    """保存会话状态"""
    session_file = get_session_file()
    session = {
        'account': account,
        'token': token,
        'secret': secret,
        'username_display': username_display,
        'company_id': company_id,
        'last_active': datetime.now().isoformat(),
        'logged_in': True
    }
    
    with open(session_file, 'w', encoding='utf-8') as f:
        json.dump(session, f, ensure_ascii=False, indent=2)
    
    write_log(f"用户登录：{account[:3]}***{account[-2:]}", "INFO")

def clear_session():
    """清除会话状态（登出）"""
    session_file = get_session_file()
    if session_file.exists():
        os.remove(session_file)
    write_log("用户已登出", "INFO")

def update_session_activity():
    """更新会话活动时间"""
    session = load_session()
    if session:
        session['last_active'] = datetime.now().isoformat()
        session_file = get_session_file()
        with open(session_file, 'w', encoding='utf-8') as f:
            json.dump(session, f, ensure_ascii=False, indent=2)

# ==================== 加密和签名 ====================

def md5_encrypt(text):
    """MD5 加密"""
    return hashlib.md5(text.encode('utf-8')).hexdigest()

def generate_signature(appkey, secret, method, timestamp):
    """生成 API 调用签名"""
    lst = [
        f"appkey={appkey}",
        f"time={timestamp}",
        f"method={method}"
    ]
    tmp = "".join(sorted(lst)) + secret
    return md5_encrypt(tmp)

# ==================== API 调用 ====================

def call_api_direct(url, params, require_sign=False, appkey='', secret='', method=''):
    """
    直接调用指定 URL 的 API（用于登录等特殊情况）
    
    Args:
        url: 完整 API URL
        params: 请求参数
        require_sign: 是否需要签名
        appkey: Token
        secret: MD5 加密后的密码
        method: 方法名（用于签名）
    
    Returns:
        dict: API 响应结果
    """
    headers = {
        'Content-Type': 'application/json',
    }
    
    if require_sign and appkey and secret and method:
        now_time = int(round(time.time() * 1000))
        sign = generate_signature(appkey, secret, method, now_time)
        headers['appkey'] = appkey
        headers['method'] = method
        headers['time'] = str(now_time)
        headers['sign'] = sign
    
    json_data = json.dumps(params, ensure_ascii=False)
    
    try:
        response = requests.post(url, headers=headers, data=json_data.encode('utf-8'), timeout=10)
        # 尝试多种编码方式解码
        try:
            result = json.loads(response.text)
        except:
            try:
                result = json.loads(response.content.decode('gbk'))
            except:
                result = json.loads(response.content.decode('utf-8', errors='ignore'))
        return result
    except Exception as e:
        return {'succeed': 'false', 'message': f'调用失败：{str(e)}'}

def call_api(api_url, method, params, appkey, secret, require_sign=True):
    """
    通用 API 调用函数
    
    Args:
        api_url: API 基础地址
        method: 接口方法名
        params: 请求参数（字典）
        appkey: Token
        secret: MD5 加密后的密码
        require_sign: 是否需要签名（默认 True）
    
    Returns:
        dict: API 响应结果
    """
    now_time = int(round(time.time() * 1000))
    
    # 构造完整 URL
    target_url = api_url if api_url.endswith('/') else api_url + '/'
    target_url += method
    
    headers = {
        'Content-Type': 'application/json',
        'appkey': appkey,
    }
    
    # 如果需要签名
    if require_sign:
        sign = generate_signature(appkey, secret, method, now_time)
        headers['method'] = method
        headers['time'] = str(now_time)
        headers['sign'] = sign
    
    # 构造请求数据
    json_data = json.dumps(params, ensure_ascii=False)
    
    write_log(f"调用 API: method={method}, params={desensitize(json_data)}", "INFO")
    
    try:
        response = requests.post(target_url, headers=headers, data=json_data.encode('utf-8'), timeout=10)
        # 尝试多种编码方式解码（WeCall API 返回 GBK 编码的中文 JSON）
        raw_bytes = response.content
        # 先尝试 GBK（WeCall 常用），再尝试 UTF-8，再降级
        for enc in ('gbk', 'utf-8', 'latin-1'):
            try:
                text = raw_bytes.decode(enc)
                result = json.loads(text)
                # 验证解析成功且中文不为空（乱码检测）
                break
            except (UnicodeDecodeError, json.JSONDecodeError):
                continue
        else:
            # 全失败，强制 UTF-8 忽略错误
            result = json.loads(raw_bytes.decode('utf-8', errors='ignore'))

        write_log(f"API 响应：status={result.get('status', 'unknown')}", "INFO")
        return result
    
    except requests.exceptions.Timeout:
        write_log(f"API 调用超时：method={method}", "ERROR")
        return {'status': 'error', 'message': '网络超时，请重试'}
    
    except Exception as e:
        write_log(f"API 调用失败：{str(e)}", "ERROR")
        return {'status': 'error', 'message': f'调用失败：{str(e)}'}

# ==================== 登录功能 ====================

def login(account, password, api_url, secret=None, cli="ai", app=""):
    """
    用户登录
    
    Args:
        account: 账号
        password: 密码（明文）
        api_url: API 地址
        secret: 可选，如果已提供则直接使用（用于会话恢复）
        cli: 客户端类型（ai/pc/app），只有 ai 需要冲突检测
        app: 应用标识（微信登录时有值）
    
    Returns:
        dict: 登录结果 {'success': bool, 'message': str, 'token': str}
    """
    # 只有 cli="ai" 时才进行冲突检测
    # cli="pc" 或 app 有内容时，允许多地同时登录
    if cli == "ai" and not app:
        # 检查是否已有会话
        existing_session = load_session()
        if existing_session:
            if existing_session['account'] == account:
                write_log(f"账号已登录：{account[:3]}***{account[-2:]} (cli={cli})", "INFO")
                return {
                    'success': True,
                    'message': f"账号 {existing_session['username_display']} 已在登录状态",
                    'token': existing_session['token'],
                    'already_logged': True
                }
            else:
                write_log(f"账号冲突：当前登录{existing_session['account'][:3]}***，尝试登录{account[:3]}*** (cli={cli})", "WARNING")
                return {
                    'success': False,
                    'message': f"当前已有账号登录（{existing_session['username_display']}），请先登出后再登录新账号",
                    'already_logged': False,
                    'conflicting_account': existing_session['account']
                }
    else:
        write_log(f"登录类型：cli={cli}, app={app}，跳过冲突检测", "INFO")
    
    # MD5 加密密码
    password_md5 = md5_encrypt(password)
    
    # 构造登录请求参数
    login_params = {
        "cli": cli,
        "app": app,
        "param": {
            "username": account,
            "password": password_md5
        }
    }
    
    write_log(f"尝试登录：{account[:3]}***{account[-2:]} (cli={cli}, app={app})", "INFO")
    
    # 调用登录 API（直接 POST 到 /Login）
    login_url = api_url if api_url.endswith('/') else api_url + '/'
    login_url += 'Login'
    
    result = call_api_direct(login_url, login_params, require_sign=False)
    
    if result.get('succeed') == 'true' or result.get('code') == '1' or result.get('status') == 'success':
        # 登录成功，提取 Token
        data = result.get('data', {})
        token = data.get('token') or result.get('appkey') or result.get('token')
        username_display = data.get('userinfo', {}).get('name') or result.get('username') or account
        # 提取 CompanyId（从 userinfo.company.id 或 data.companyid）
        company_id = None
        userinfo = data.get('userinfo', {})
        if userinfo.get('company'):
            company_id = userinfo['company'].get('id') or userinfo['company'].get('companyid')
        if not company_id:
            company_id = userinfo.get('companyid') or data.get('companyid')
        
        if token:
            # 保存会话（只有 cli="ai" 且 app 为空时才保存，用于冲突检测）
            if cli == "ai" and not app:
                save_session(account, token, password_md5, username_display, company_id)
            write_log(f"登录成功：{username_display}，CompanyId={company_id} (cli={cli})", "INFO")
            return {
                'success': True,
                'message': f"登录成功，欢迎 {username_display}",
                'token': token,
                'username': username_display,
                'company_id': company_id,
                'cli': cli
            }
        else:
            write_log("登录成功但未返回 Token", "ERROR")
            return {
                'success': False,
                'message': '登录成功但未获取到 Token，请联系管理员'
            }
    else:
        error_msg = result.get('message') or result.get('msg') or '登录失败'
        write_log(f"登录失败：{error_msg}", "ERROR")
        return {
            'success': False,
            'message': f'登录失败：{error_msg}'
        }

def logout():
    """用户登出"""
    session = load_session()
    if session:
        account = session['account']
        clear_session()
        return {
            'success': True,
            'message': f"账号 {session['username_display']} 已安全登出"
        }
    else:
        return {
            'success': True,
            'message': "当前未登录"
        }

def check_login_status():
    """检查登录状态"""
    session = load_session()
    if session:
        return {
            'logged_in': True,
            'account': f"{session['account'][:3]}***{session['account'][-2:]}",
            'username': session['username_display'],
            'last_active': session['last_active']
        }
    else:
        return {
            'logged_in': False,
            'message': "未登录，请先登录"
        }

# ==================== 主函数（根据用户指令执行） ====================

def execute_command(command, params=None):
    """
    执行用户命令
    
    Args:
        command: 命令类型（login, logout, check_status, call_api）
        params: 命令参数
    
    Returns:
        dict: 执行结果
    """
    # 加载配置
    meta = load_meta()
    api_url = meta['Items'][0]['ApiUrl']
    
    if command == 'login':
        account = params.get('account')
        password = params.get('password')
        return login(account, password, api_url)
    
    elif command == 'logout':
        return logout()
    
    elif command == 'check_status':
        return check_login_status()
    
    elif command == 'call_api':
        # 检查登录状态
        session = load_session()
        if not session:
            return {'success': False, 'message': '请先登录'}
        
        # 更新活动时间
        update_session_activity()
        
        method = params.get('method')
        api_params = params.get('params', {})
        require_sign = params.get('require_sign', True)
        
        return call_api(
            api_url,
            method,
            api_params,
            session['token'],
            session['secret'],
            require_sign
        )
    
    else:
        return {'success': False, 'message': f'未知命令：{command}'}

# ==================== 坐席管理 ====================

def get_employee_list():
    """
    获取坐席/员工列表
    
    Returns:
        dict: API 响应结果，包含坐席列表
              {'succeed': bool, 'data': {'list': [{agent info}, ...]}}
    
    示例返回数据结构:
        - agent.number: 坐席号（工号），用于考勤报表 exte 参数
        - agent.userid: 用户ID
        - employee.name: 坐席昵称
        - user.username: 登录用户名
    """
    session = load_session()
    if not session:
        return {'succeed': False, 'message': '请先登录'}
    
    meta = load_meta()
    api_url = meta['Items'][0]['ApiUrl']
    
    # 调用 GetEmployeeLs 获取坐席列表
    result = call_api(
        api_url,
        'GetEmployeeLs',
        {},  # 无需参数
        session['token'],
        session['secret'],
        require_sign=True
    )
    
    return result


def search_agent_by_nickname(nickname):
    """
    根据昵称搜索坐席信息
    
    Args:
        nickname: 坐席昵称（部分匹配）
    
    Returns:
        dict: 匹配到的坐席信息 {'exte': str, 'userid': str, 'name': str, 'username': str}
              如果没找到返回 None
    
    示例:
        # 查找昵称为 user003 的坐席
        agent = search_agent_by_nickname('user003')
        if agent:
            print(f"坐席号: {agent['exte']}")  # 输出: 3009
    """
    result = get_employee_list()
    
    if result.get('succeed') != 'true' and result.get('code') != '1':
        return None
    
    # 从 data.list 或 data.items 中获取坐席列表
    data = result.get('data', {})
    agent_list = data.get('list', []) + data.get('items', [])
    
    # 遍历查找昵称匹配的坐席（支持模糊匹配）
    for agent_info in agent_list:
        employee = agent_info.get('employee', {})
        agent = agent_info.get('agent', {})
        user = agent_info.get('user', {})
        
        # employee.name 是坐席昵称（如"昵称user003"）
        # agent.number 是坐席号（用于 exte 参数，如"3009"）
        name = employee.get('name', '')
        if nickname.lower() in name.lower():
            return {
                'exte': agent.get('number', ''),     # 坐席号（考勤报表 exte 参数）
                'userid': employee.get('userid', ''), # 用户ID
                'name': name,                          # 昵称
                'username': user.get('username', ''),  # 登录用户名
                'agent_id': agent.get('id', '')        # 坐席ID
            }
    
    return None


def get_agent_exte(nickname):
    """
    根据昵称获取坐席号（快捷函数）
    
    Args:
        nickname: 坐席昵称
    
    Returns:
        str: 坐席号（如找不到返回空字符串）
    
    示例:
        exte = get_agent_exte('user003')  # 返回 '3009'
    """
    agent = search_agent_by_nickname(nickname)
    return agent['exte'] if agent else ''


# ==================== CLI 入口 ====================

if __name__ == '__main__':
    """
    命令行调用示例：
    
    登录：
    python alluse.py login {"account": "test", "password": "123456"}
    
    检查状态：
    python alluse.py check_status
    
    登出：
    python alluse.py logout
    
    调用 API：
    python alluse.py call_api {"method": "CreateSample", "params": {...}}
    """
    if len(sys.argv) < 2:
        print(json.dumps({'success': False, 'message': '请提供命令'}, ensure_ascii=False))
        sys.exit(1)
    
    command = sys.argv[1]
    params = {}
    
    if len(sys.argv) > 2:
        try:
            params = json.loads(sys.argv[2])
        except json.JSONDecodeError:
            print(json.dumps({'success': False, 'message': '参数格式错误'}, ensure_ascii=False))
            sys.exit(1)
    
    result = execute_command(command, params)
    # 使用二进制输出避免编码问题
    output = json.dumps(result, ensure_ascii=False)
    sys.stdout.buffer.write(output.encode('utf-8'))
    sys.stdout.buffer.flush()
