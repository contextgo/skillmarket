﻿由于不能上传Word，就凑合着看吧，感谢你下载SKILL。

Auto-API

一句话调 API，自然语言驱动的万能接口引擎



告别手动拼参数、翻文档、写脚本的日子。
Auto-API 把「找文档 → 看参数 → 写请求 → 处理返回 → 导出文件」压缩成「说一句话」。
 
一、概述
两个世界，一个入口。Auto-API 通过 meta.json 的 Choose 字段自动切换工作流。

Choose = "WeCall"	                                 Choose = ""（通用）
适用平台	WeCall 外呼平台专有	适配任意 RESTful API
接口支持	内置部分业务接口	                 填写 ApiUrl + ApiList 即用
签名算法	自动封装	                                  签名方式随 API 自定义
危险操作	直接拦截	                                  高危操作需用户确认
登录态	自动管理	                                  多环境自由切换
开箱即用	零配置	                                  适合非 WeCall 场景

核心能力
•	API 全覆盖：你说什么，它调什么。输入任意合法 API 即可调用，不限于下文列举的内置函数。本文档仅展示部分典型场景，实际能力远不止于此。
•	级联搜索：自然语言描述 → 自动模糊匹配 → 返回精确结果（项目 ID、任务 ID、配额 ID 等）。
•	Excel 智能导出：自动序号、合计行、中文列名、隐藏列过滤、号码模板筛选。
•	安全沙箱：删除/清空直接拒绝，批量导入需确认，查询导出直接执行；隐私数据不得随意传递。
二、前置准备
第一步：配置 meta.json
在 auto-api 技能目录下找到或创建 meta.json，根据使用场景填写配置（详见下一节）。
第二步：开始说话
配置完成后，直接用自然语言描述需求。
三、配置详解：meta.json
每个字段的作用如下，请按需填写。

meta.json 字段说明
字段	说明
need	调用哪个API配置
Key	API 密钥，用于接口鉴权
ApiUrl	API 服务地址，末尾建议带斜杠(在WeCall流程可以填写网址自动填充)
ApiList	API 文档页面地址，用于参数自动查询(在WeCall流程可以填写网址自动填充)
ApiUseInfo	API 使用说明，在Use文件夹下存储，可以是.txt，也可以是.py等
Choose	流程，WeCall / “”(通用流程)
ApiUseCode	代码，这个是通用的，不需要设置

配置示例：
{
  {
  "need": "aapi",
  "Items": [
    {
      "Key": "aapi",
      "ApiUrl": "https://....",
      "ApiList": "https://.... 或者本地路径",
      "ApiUseInfo": "Use/xxx.txt / Use/xxx.py等",
      "Choose": "WeCall" / ""
},
{
      "Key": "bapi",
      "ApiUrl": "https://....",
      "ApiList": "https://.... 或者本地路径",
      "ApiUseInfo": "Use/yyy.txt / Use/yyy.py等",
      "Choose": "WeCall" / ""
},
……
  ],
  "ApiUseCode": "alluse.py"
}
}

四、AI自动问题解决
不知道怎么做？直接问！配置 meta.json、调试 API、排查问题……说你遇到什么困难，AI 自动帮你分析并解决。

场景	AI 怎么做
不知道 meta.json 怎么配	AI 自动引导，提供配置模板，用户只需回答几个问题即可完成
不知道该调哪个 API	AI 自动查文档、匹配接口，告诉用户哪个最适合
调用失败了，不知道错在哪	AI 分析错误信息，给出修复建议，甚至自动重试
不知道参数怎么填	AI 直接查 API 文档，展示每个参数的作用和示例
想要的功能文档里没写	AI 根据你的需求，帮你找到最接近的实现方式

示例：不会配 meta.json？直接说"帮我配"
用户：我不会配置 meta.json
↓
AI：检测到尚未配置，请提供以下信息：
  ……查看meta.json配置那一节

用户：输入内容即可，不会可以由AI辅助
↓
AI：正在生成配置...
  ✅ meta.json 已保存
  ✅ 开始登录验证...
  ✅ 配置完成！你现在可以说需求了

用户：导出昨天的话务报表
↓
AI：generate_traffic_report(daterange="2026-04-23,2026-04-23") → 返回 Excel

示例：不知道该用哪个 API？直接描述需求
用户：我想知道某个项目的所有坐席的通话时长总和
↓
AI：分析需求 → 查 API 文档 → 匹配 GetAgentReport
  推荐接口：generate_agent_report（坐席报表）
  参数：topic_id, daterange
  → 帮你查坐席列表 → 自动填充参数 → 执行 → 返回 Excel

核心原则：你只管说需求，AI 负责找方法。遇到任何问题，不用自己摸索，直接问！


五、WeCall 专有能力
流程：Choose = "WeCall"。以下能力为 WeCall/AICall 平台独有，其他 API 平台不可用。
注：以下仅列举常用场景，WeCall 平台的任意 API 接口均可通过自然语言调用，功能不限于此处列表。

报表引擎一览
报表类型	关键函数	输出格式
话务报表	generate_traffic_report	Excel（多列、合计行）
坐席报表	generate_agent_report	Excel（多维度）
考勤报表	generate_attendance_report	Excel（日期+坐席）
质检报表	generate_quality_report	Excel（质检结果）
智能质检报表	generate_smart_quality_report	Excel（AI 质检数据）
监控报表	generate_monitor_report	Excel（动态列配置）
会话记录导出	export_cdr	Excel（可过滤/排重）
CDR 批量导入	import_cdr	批量写入
通用导出	generic_export	Excel（自定义列映射）

Excel 导出引擎特性
•	✅ 自动生成序号列
•	✅ 合计行自动计算
•	✅ 列名中文映射（column_titles）
•	✅ 隐藏列过滤（hide_columns）
•	✅ 号码模板条件构建（build_sample）

自然语言调用示例（示例均不为真实数据）
用户：帮我导出昨天的话务报表
AI → generate_traffic_report(daterange="2026-04-23,2026-04-23") → 返回 Excel

用户：查一下user003的考勤，上周二到周五
AI → 搜索坐席号 → generate_attendance_report(exte="3009", daterange="...") → 返回 Excel

用户：把5964和5967两个项目的话务报表导出来
AI → 匹配项目名 → generate_traffic_report(topic_ids="5964,5967", daterange="...") → 返回 Excel

用户：导出会话记录，只要已接通的，通话超过1分钟的
AI → export_cdr(topic_id="...", daterange="...", state="1", duration="00:01:00-") → 返回 Excel

六、辅助查询链
流程：Choose = "WeCall"
再也不用手动翻列表找 ID 了。自然语言描述 → 自动模糊匹配 → 返回精确结果：
函数	说明
search_projects(keyword)	按名称搜项目，返回项目 ID
search_rules(topic_id)	搜项目下的任务，返回任务 ID
search_quotas(topic_id)	搜项目下的配额，返回配额 ID
search_groups(topic_id)	搜项目下的数据分组，返回分组 ID
search_agents(keyword)	按昵称搜坐席，返回坐席号
search_sample_templates()	获取号码模板列表
get_sample_fields(template_id)	获取模板字段
build_sample(topic_id, conditions)	构建号码模板筛选 JSON

build_sample 构建示例（示例均不为真实数据）
# 包含广东移动号码，排除联通和电信
conditions = [
    {"title": "手机号", "value": "1[345789]", "mode": "fuzzy"},
    {"title": "运营商", "value": "广东移动", "mode": "include"}
]
sample = build_sample(topic_id="项目ID", conditions=conditions)
# 结果: "1[345789]*|!联通|!电信"

# 排除特定号段
conditions = [
    {"title": "手机号", "value": "138", "mode": "fuzzy"},
    {"title": "手机号", "value": "!139000", "mode": "fuzzy"}
]
sample = build_sample(topic_id="项目ID", conditions=conditions)
# 结果: "138*|!139000*"
 
七、通用能力
流程：Choose = ""（通用）。以下为通用流程下的核心能力，同样不限于此——任意 API 均可通过自然语言调用。

generic_export 通用导出函数
适用于通用流程（Choose=""），调用用户配置的 API 并导出 Excel。
参数	说明	必填
api_method	API 方法名	✅ 必填
params	API 请求参数	可选
columns	要导出的列名列表	可选
column_titles	列名标题映射 {"字段名": "中文标题"}	可选
hide_columns	要隐藏的列名列表	可选
filename	导出文件名	可选
data_key	数据在响应中的键名（自动检测 data/list/rows 等）	可选
auto_number	是否自动添加序号列，默认 True	可选
include_total_row	是否添加合计行，默认 False	可选
require_sign	是否需要签名，默认 True	可选

调用示例（示例均不为真实数据）
# 调用坐席列表接口并导出
generic_export(
    api_method="GetEmployeeLs",
    params={"topicId": "项目ID"},
    columns=["username", "agentnum", "status"],
    column_titles={"username": "登录账号", "agentnum": "坐席号", "status": "状态"},
    filename="坐席列表.xlsx"
)

# 自定义列映射导出 CDR
generic_export(
    api_method="GetCdrLs",
    params={"topicId": "项目ID", "daterange": "2026-04-23,2026-04-23"},
    columns=["callid", "phone", "duration", "state"],
    column_titles={"callid": "通话ID", "phone": "客户号码", "duration": "通话时长", "state": "状态"},
    hide_columns=["callid"],
    filename="CDR导出.xlsx"
)

API调用
因为每个API都不同所以通用参数无法写太多功能，所以可以通过调用对应的API来获取对应的结果

八、必填参数速查表
流程：Choose = "WeCall"。本节内容为 WeCall 专有流程的参数速查。
在调用任何导出/查询函数前，先确认以下必填参数是否齐全。参数缺失时：STOP → 直接询问用户 → 绝不先调用 API 瞎猜。

函数	必填参数	触发条件
generate_traffic_report	topic_ids, daterange	单项目加 rule_id，多项目不加
generate_agent_report	topic_ids, daterange	可选 exte 过滤坐席
generate_attendance_report	topic_ids, daterange	可选 exte 过滤坐席
generate_quality_report	topic_ids, daterange	—
generate_smart_quality_report	topic_ids, daterange	—
generate_monitor_report	topic_ids, daterange, rule_id	需先查 GetMonmodLs 的 cell 值
export_cdr	topic_id, daterange	可选 state/duration/word 等过滤
import_cdr	topic_id, file_path	需用户确认后执行
generic_export	api_method	其余参数按需传入

GetCdrLs / ExportCdrLs 可选参数
可选参数只有用户明确说了才填，没说就不传，不要传空值。

参数	说明	值
doc	是否回放	0=未回放，1=已回放
state	是否接通	0=未接通，1=已接通
quotaid	配额 ID	通过 GetQuotaLs 获取
duration	通话时长范围	HH:MM:SS-HH:MM:SS，如 00:01:00-00:05:00
chk	是否质检	0=未质检，1=通过，2=作废，3=已质检，4=智能质检
chkdaterange	质检时间	YYYY-MM-DD,YYYY-MM-DD
exte	坐席号	坐席工号
word	关键词	搜索关键词
rpt	排重	0=不排重，1=排重
GroupIds	数据分组 ID	通过获取数据分组信息接口获得

监控报表 Cell 位掩码规则
GetMonmodLs 返回的 cell 字段，用于判断监控报表需要哪些参数。

标志位	含义	必填参数
1	需要任务	rule_id 必填
2	需要日期	daterange 必填
8	需要坐席号	exte 选填，None=不限
16	什么都不需要	基础态/默认态

Cell 值 = 多个标志位之和，常见组合：
Cell 值	拆解	含义
3	1+2	需要任务+日期
9	1+8	需要任务+坐席号
17	16+1	等价于需要任务
27	16+8+2+1	需要坐席号+日期+任务

九、安全沙箱
保护数据安全与隐私是第一优先级。Auto-API 不会将用户隐私信息（如账号、密码、客户数据等）随意传递到外部服务。所有敏感操作均受沙箱管控。

操作类型	WeCall 流程	通用流程
删除 / 清空数据	🔴 直接拒绝	🟡 需用户确认
批量导入数据	🟡 需用户确认	🟡 需用户确认
查询 / 导出报表	🟢 直接执行	🟢 直接执行
登录 / 状态检查	🟢 直接执行	🟢 直接执行

数据隐私保护原则
•	不得将用户隐私信息（账号、密码、客户号码等）传递给未经授权的第三方服务。
•	所有 API 调用仅发往 meta.json 中配置的目标地址，不会外泄数据。
•	删除/清空等高危操作一律拦截或需二次确认，防止误操作造成数据丢失。
•	导出文件仅保存到用户本地，不经过任何中间服务器。


