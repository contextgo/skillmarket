---
name: cn-meeting-minutes
version: "1.4.0"
description: "会议纪要生成工具。输入音频文件路径，生成结构化纪要文档，包含讨论点、决策和待办事项。"
metadata:
  openclaw:
    emoji: "📝"
    category: productivity

## 功能
- 音频文件转写（支持MP3/WAV/M4A格式）
- 关键讨论点提取
- 决策结论归纳
- 待办事项自动识别（含责任人和截止日期）
- Markdown格式纪要输出

## 使用方法
```
python3 scripts/meeting_minutes.py audio_file.mp3
python3 scripts/meeting_minutes.py meeting.wav -o output.md
```

## 参数
- 第一个位置参数：音频文件路径（MP3/WAV/M4A/MP4/WMA）
- `-o` / `--output`：输出文件路径（可选，默认{文件名}_纪要.md）
- `--asr`：ASR引擎选择（local/volcano/siliconflow，默认volcano）

## 依赖
- Python 3.7+（纯标准库）

## 注意
- 音频文件最大500MB
- ASR转写需要网络连接
