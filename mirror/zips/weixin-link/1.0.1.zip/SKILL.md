# 微信渠道无响应修复技能

## 问题现象

- 微信渠道显示 `ON / OK`，但发送消息后机器人无回应
- 日志显示 `weixin monitor started` 但随后出现 `createTypingCallbacks is not a function` 错误
- 或日志中没有任何微信消息接收记录

## 触发条件

使用此技能当用户报告：
- "微信渠道配置好了但发送消息没有回应"
- "微信 chatbot 发送消息没有回应"
- "微信渠道无法接收/回复消息"

## 诊断步骤

### 1. 检查微信渠道状态

```bash
openclaw status 2>&1 | grep -A10 "Channels"
```

**预期输出**：
```
│ Weixin   │ ON      │ OK     │ token unknown (2a1c…7370 · len 58) · accounts 1/1
```

如果状态不是 `ON / OK`，先运行：
```bash
openclaw channels login --channel openclaw-weixin
```

### 2. 检查实时日志

```bash
cat /tmp/openclaw/openclaw-$(date +%Y-%m-%d).log | grep -i "weixin" | tail -30
```

**关键错误模式**：
- `createTypingCallbacks is not a function` → 导入路径错误（见修复步骤 A）
- `weixin not configured: missing token` → 缺少 channels 配置（见修复步骤 B）
- `plugins.allow is empty` → 缺少插件允许列表（见修复步骤 C）
- 没有任何 inbound 记录 → 监控器未启动（见修复步骤 B）

## 修复步骤

### A. 修复导入路径错误（必做）

这是微信插件 v1.0.0 的已知 bug，`createTypingCallbacks` 从错误的模块导入。

**修复命令**：

```bash
# 备份原文件
cp ~/.openclaw/extensions/openclaw-weixin/src/messaging/process-message.ts \
   ~/.openclaw/extensions/openclaw-weixin/src/messaging/process-message.ts.bak

# 修复导入路径
sed -i '' 's/import { createTypingCallbacks,/import { resolveSenderCommandAuthorizationWithRuntime, resolveDirectDmAuthorizationOutcome } from "openclaw\/plugin-sdk\/command-auth";\nimport { createTypingCallbacks/g' \
  ~/.openclaw/extensions/openclaw-weixin/src/messaging/process-message.ts
```

**如果 sed 失败，手动编辑文件**：

文件：`~/.openclaw/extensions/openclaw-weixin/src/messaging/process-message.ts`

**修改前**（第 3-7 行左右）：
```typescript
import {
  createTypingCallbacks,
  resolveSenderCommandAuthorizationWithRuntime,
  resolveDirectDmAuthorizationOutcome,
} from "openclaw/plugin-sdk/command-auth";
```

**修改后**：
```typescript
import { resolveSenderCommandAuthorizationWithRuntime, resolveDirectDmAuthorizationOutcome } from "openclaw/plugin-sdk/command-auth";
import { createTypingCallbacks } from "openclaw/plugin-sdk/channel-runtime";
```

### B. 添加 Channels 配置（必做）

微信账户需要在 `openclaw.json` 中明确启用才能启动监控器。

**1. 获取微信账户 ID**：
```bash
cat ~/.openclaw/openclaw-weixin/accounts.json
```

输出示例：`["2a1c03a8ddd4-im-bot"]`

**2. 编辑 `~/.openclaw/openclaw.json`**：

在 `plugins` 配置块**之前**添加 `channels` 配置：

```json
{
  "channels": {
    "openclaw-weixin": {
      "accounts": {
        "2a1c03a8ddd4-im-bot": {
          "enabled": true
        }
      }
    }
  },
  "plugins": {
    "allow": ["openclaw-weixin"],
    ...
  }
}
```

**使用 jq 自动添加**（如果已安装）：
```bash
ACCOUNT_ID=$(cat ~/.openclaw/openclaw-weixin/accounts.json | jq -r '.[0]')
cat ~/.openclaw/openclaw.json | jq --arg acc "$ACCOUNT_ID" '
  .channels = {"openclaw-weixin": {"accounts": {($acc): {"enabled": true}}}} |
  .plugins.allow = ["openclaw-weixin"]
' > ~/.openclaw/openclaw.json.tmp && mv ~/.openclaw/openclaw.json.tmp ~/.openclaw/openclaw.json
```

### C. 添加 plugins.allow 配置（必做）

在 `~/.openclaw/openclaw.json` 中添加：

```json
{
  "plugins": {
    "allow": ["openclaw-weixin"],
    ...
  }
}
```

### D. 重启网关（必做）

```bash
openclaw gateway restart
```

等待 5-10 秒让网关完全重启。

## 验证修复

### 1. 检查监控器状态

```bash
cat /tmp/openclaw/openclaw-$(date +%Y-%m-%d).log | grep -i "weixin monitor" | tail -5
```

**预期输出**：
```
weixin monitor started (https://ilinkai.weixin.qq.com, account=xxx-im-bot)
```

### 2. 发送测试消息

从微信发送一条消息（如 "测试"），然后检查日志：

```bash
cat /tmp/openclaw/openclaw-$(date +%Y-%m-%d).log | grep -i "inbound\|outbound" | tail -10
```

**预期输出**：
```
inbound message: from=xxx@im.wechat types=1
inbound: from=xxx@im.wechat to=xxx@im.wechat bodyLen=2 hasMedia=false
outbound: to=xxx@im.wechat contextToken=... textLen=xx mediaUrl=none
outbound: text sent OK to=xxx@im.wechat
```

### 3. 检查渠道状态

```bash
openclaw status 2>&1 | grep -A5 "Channels"
```

**预期输出**：
```
│ Weixin   │ ON      │ OK     │ token unknown (2a1c…7370 · len 58) · accounts 1/1
```

## 快速修复脚本

将以下内容保存为 `~/.openclaw/scripts/fix-weixin.sh`：

```bash
#!/bin/bash
set -e

echo "🔧 修复微信渠道..."

# 1. 修复导入路径
echo "  [1/4] 修复 process-message.ts 导入路径..."
TS_FILE="$HOME/.openclaw/extensions/openclaw-weixin/src/messaging/process-message.ts"
if [ -f "$TS_FILE" ]; then
  cp "$TS_FILE" "$TS_FILE.bak"
  # 使用 node 脚本进行精确替换
  node -e "
    const fs = require('fs');
    const file = '$TS_FILE';
    let content = fs.readFileSync(file, 'utf8');
    content = content.replace(
      /import \{\s*createTypingCallbacks,\s*resolveSenderCommandAuthorizationWithRuntime,\s*resolveDirectDmAuthorizationOutcome,\s*\} from \"openclaw\/plugin-sdk\/command-auth\";/g,
      'import { resolveSenderCommandAuthorizationWithRuntime, resolveDirectDmAuthorizationOutcome } from \"openclaw/plugin-sdk/command-auth\";\nimport { createTypingCallbacks } from \"openclaw/plugin-sdk/channel-runtime\";'
    );
    fs.writeFileSync(file, content);
  "
  echo "  ✅ 导入路径已修复"
else
  echo "  ⚠️  文件不存在：$TS_FILE"
fi

# 2. 获取账户 ID
echo "  [2/4] 读取微信账户配置..."
ACCOUNT_ID=$(cat ~/.openclaw/openclaw-weixin/accounts.json 2>/dev/null | grep -o '"[^"]*"' | head -1 | tr -d '"')
if [ -z "$ACCOUNT_ID" ]; then
  echo "  ❌ 未找到微信账户，请先运行：openclaw channels login --channel openclaw-weixin"
  exit 1
fi
echo "  ✅ 账户 ID: $ACCOUNT_ID"

# 3. 更新 openclaw.json
echo "  [3/4] 更新 openclaw.json 配置..."
cat ~/.openclaw/openclaw.json | jq --arg acc "$ACCOUNT_ID" '
  .channels = {"openclaw-weixin": {"accounts": {($acc): {"enabled": true}}}} |
  .plugins.allow = ["openclaw-weixin"]
' > ~/.openclaw/openclaw.json.tmp && mv ~/.openclaw/openclaw.json.tmp ~/.openclaw/openclaw.json
echo "  ✅ 配置已更新"

# 4. 重启网关
echo "  [4/4] 重启网关..."
openclaw gateway restart
echo "  ✅ 网关重启中..."

sleep 8

# 5. 验证
echo ""
echo "📋 验证修复..."
cat /tmp/openclaw/openclaw-$(date +%Y-%m-%d).log | grep -i "weixin monitor started" | tail -1

echo ""
echo "✅ 修复完成！请从微信发送一条测试消息验证。"
```

**使用**：
```bash
chmod +x ~/.openclaw/scripts/fix-weixin.sh
~/.openclaw/scripts/fix-weixin.sh
```

## 常见问题

### Q: 修复后仍然无响应

**检查项**：
1. 微信账号是否已登录：`cat ~/.openclaw/openclaw-weixin/accounts/*.json`
2. token 是否有效：检查是否有 `session expired` 错误
3. 是否需要重新扫码：`openclaw channels login --channel openclaw-weixin`

### Q: 多账号如何配置

在 `channels.openclaw-weixin.accounts` 中添加多个账户：

```json
{
  "channels": {
    "openclaw-weixin": {
      "accounts": {
        "account-id-1": {"enabled": true},
        "account-id-2": {"enabled": true}
      }
    }
  }
}
```

### Q: 如何隔离不同账号的对话上下文

```bash
openclaw config set session.dmScope "per-channel-peer"
```

这样每个「微信账号 + 发送者」组合都有独立的 AI 会话。

## 参考文档

- OpenClaw 微信渠道文档：https://docs.openclaw.ai/channels/openclaw-weixin
- 微信插件 GitHub：https://github.com/tencent-weixin/openclaw-weixin
