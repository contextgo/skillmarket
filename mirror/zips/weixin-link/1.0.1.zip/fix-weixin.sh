#!/bin/bash
# 微信渠道快速修复脚本
# 用法：./fix-weixin.sh

set -e

echo "🔧 修复微信渠道无响应问题..."
echo ""

# 1. 修复导入路径
echo "  [1/4] 修复 process-message.ts 导入路径..."
TS_FILE="$HOME/.openclaw/extensions/openclaw-weixin/src/messaging/process-message.ts"
if [ -f "$TS_FILE" ]; then
  cp "$TS_FILE" "$TS_FILE.bak"
  # 使用 node 脚本进行精确替换
  node -e "
    const fs = require('fs');
    const file = '$TS_FILE';
    let content = fs.readFileSync(file, 'utf8');
    const oldImport = /import \{\s*createTypingCallbacks,\s*resolveSenderCommandAuthorizationWithRuntime,\s*resolveDirectDmAuthorizationOutcome,\s*\} from \"openclaw\/plugin-sdk\/command-auth\";/g;
    const newImport = 'import { resolveSenderCommandAuthorizationWithRuntime, resolveDirectDmAuthorizationOutcome } from \"openclaw/plugin-sdk/command-auth\";\nimport { createTypingCallbacks } from \"openclaw/plugin-sdk/channel-runtime\";';
    if (oldImport.test(content)) {
      content = content.replace(oldImport, newImport);
      fs.writeFileSync(file, content);
      console.log('  ✅ 导入路径已修复');
    } else {
      console.log('  ℹ️  导入路径可能已修复，跳过');
    }
  "
else
  echo "  ⚠️  文件不存在：$TS_FILE"
  echo "  请确认微信插件已安装"
  exit 1
fi

# 2. 获取账户 ID
echo "  [2/4] 读取微信账户配置..."
ACCOUNTS_FILE="$HOME/.openclaw/openclaw-weixin/accounts.json"
if [ ! -f "$ACCOUNTS_FILE" ]; then
  echo "  ❌ 未找到微信账户配置文件"
  echo "  请先运行：openclaw channels login --channel openclaw-weixin"
  exit 1
fi

ACCOUNT_ID=$(cat "$ACCOUNTS_FILE" | grep -o '"[^"]*"' | head -1 | tr -d '"')
if [ -z "$ACCOUNT_ID" ]; then
  echo "  ❌ 未找到微信账户，请先运行：openclaw channels login --channel openclaw-weixin"
  exit 1
fi
echo "  ✅ 账户 ID: $ACCOUNT_ID"

# 3. 更新 openclaw.json
echo "  [3/4] 更新 openclaw.json 配置..."
CONFIG_FILE="$HOME/.openclaw/openclaw.json"
if [ ! -f "$CONFIG_FILE" ]; then
  echo "  ❌ 未找到配置文件：$CONFIG_FILE"
  exit 1
fi

# 检查 jq 是否可用
if command -v jq &> /dev/null; then
  cat "$CONFIG_FILE" | jq --arg acc "$ACCOUNT_ID" '
    .channels = {"openclaw-weixin": {"accounts": {($acc): {"enabled": true}}}} |
    .plugins.allow = ["openclaw-weixin"]
  ' > "$CONFIG_FILE.tmp" && mv "$CONFIG_FILE.tmp" "$CONFIG_FILE"
  echo "  ✅ 配置已更新 (使用 jq)"
else
  # 备用方案：使用 node
  node -e "
    const fs = require('fs');
    const file = '$CONFIG_FILE';
    const acc = '$ACCOUNT_ID';
    let config = JSON.parse(fs.readFileSync(file, 'utf8'));
    config.channels = {'openclaw-weixin': {accounts: {[acc]: {enabled: true}}}};
    config.plugins.allow = ['openclaw-weixin'];
    fs.writeFileSync(file, JSON.stringify(config, null, 2));
  "
  echo "  ✅ 配置已更新 (使用 node)"
fi

# 4. 重启网关
echo "  [4/4] 重启网关..."
openclaw gateway restart
echo "  ✅ 网关重启中..."

sleep 8

# 5. 验证
echo ""
echo "📋 验证修复..."
LOG_FILE="/tmp/openclaw/openclaw-$(date +%Y-%m-%d).log"
if [ -f "$LOG_FILE" ]; then
  MONITOR_STATUS=$(cat "$LOG_FILE" | grep -i "weixin monitor started" | tail -1)
  if [ -n "$MONITOR_STATUS" ]; then
    echo "  ✅ 监控器已启动"
    echo "  $MONITOR_STATUS"
  else
    echo "  ⚠️  未找到监控器启动日志，请稍后检查"
  fi
else
  echo "  ⚠️  日志文件不存在，请稍后检查"
fi

echo ""
echo "========================================"
echo "✅ 修复完成！"
echo "========================================"
echo ""
echo "请从微信发送一条测试消息（如 '测试'），然后运行："
echo ""
echo "  cat /tmp/openclaw/openclaw-\$(date +%Y-%m-%d).log | grep -i 'inbound\\|outbound' | tail -10"
echo ""
echo "如果看到 'outbound: text sent OK' 则表示修复成功。"
echo ""
