# 微信渠道无响应修复工具

快速修复 OpenClaw 微信渠道配置后无法接收/回复消息的问题。

## 📦 包含文件

- `SKILL.md` - 完整诊断和修复指南
- `fix-weixin.sh` - 一键自动修复脚本

## 🚀 快速使用

### 方法一：自动修复脚本（推荐）

```bash
cd ~/.openclaw/workspace/skills/weixin-fix
./fix-weixin.sh
```

### 方法二：手动修复

参考 `SKILL.md` 中的详细步骤。

## 🔍 适用场景

- ✅ 微信渠道显示 `ON / OK` 但发送消息无回应
- ✅ 日志显示 `createTypingCallbacks is not a function` 错误
- ✅ 日志中没有微信消息接收记录
- ✅ 新安装的 OpenClaw 微信渠道无法工作

## ⚠️ 前提条件

- 已完成微信扫码登录：`openclaw channels login --channel openclaw-weixin`
- 微信账号已保存在 `~/.openclaw/openclaw-weixin/accounts.json`

## 📋 修复内容

1. **修复导入路径错误** - 更正 `process-message.ts` 中的模块导入
2. **添加 channels 配置** - 在 `openclaw.json` 中启用微信账户
3. **添加 plugins.allow** - 明确允许微信插件加载
4. **重启网关** - 应用所有配置更改

## 🧪 验证方法

修复后，从微信发送一条消息，然后检查：

```bash
cat /tmp/openclaw/openclaw-$(date +%Y-%m-%d).log | grep -i "outbound.*sent OK"
```

看到 `outbound: text sent OK` 表示修复成功。

## 📝 版本信息

- 适用插件版本：`@tencent-weixin/openclaw-weixin@1.0.0`
- 适用 OpenClaw 版本：`2026.3.x` 及以上
- 最后更新：2026-04-01
