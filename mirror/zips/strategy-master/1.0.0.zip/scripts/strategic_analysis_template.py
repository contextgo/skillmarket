#!/usr/bin/env python3
"""
战略分析模板生成器
生成战略分析报告框架，帮助结构化思考
"""

import argparse
from datetime import datetime
from pathlib import Path


TEMPLATES = {
    "五力分析": """
# 波特五力分析

## 行业：{industry}
## 分析日期：{date}

### 1. 行业竞争程度
- 竞争者数量：
- 增长率：
- 固定成本占比：
- 差异化程度：
- 退出壁垒：
- **评估**：[高/中/低]

### 2. 进入威胁
- 进入壁垒：
  - 规模经济：
  - 品牌认知：
  - 渠道准入：
  - 技术/专利：
  - 政策法规：
- 报复可能性：
- **评估**：[高/中/低]

### 3. 替代品威胁
- 主要替代品：
- 性价比对比：
- 转换成本：
- **评估**：[高/中/低]

### 4. 买方议价力
- 买方集中度：
- 采购占比：
- 转换成本：
- 后向一体化能力：
- **评估**：[高/中/低]

### 5. 供应商议价力
- 供应商集中度：
- 产品差异化：
- 转换成本：
- 前向一体化能力：
- **评估**：[高/中/低]

## 行业吸引力总结
- 综合评分：
- 关键力量：
- 变化趋势：
""",

    "SWOT分析": """
# SWOT分析

## 企业：{company}
## 分析日期：{date}

### 优势（Strengths）
1.
2.
3.
4.
5.

### 劣势（Weaknesses）
1.
2.
3.
4.
5.

### 机会（Opportunities）
1.
2.
3.
4.
5.

### 威胁（Threats）
1.
2.
3.
4.
5.

## 战略匹配

| 组合 | 策略思路 |
|------|----------|
| SO | 利用__抓住__ |
| WO | 克服__利用__ |
| ST | 利用__应对__ |
| WT | 减少__避免__ |
""",

    "战略画布": """
# 蓝海战略画布

## 行业：{industry}
## 分析日期：{date}

### 价值要素（横轴）

| 价值要素 | 行业标准 | 我方曲线 |
|----------|----------|----------|
| 价格 | | |
| 质量 | | |
| 服务 | | |
| 品牌 | | |
| 选择 | | |
| 便利性 | | |
| 定制化 | | |
| 速度 | | |

### 四步动作

| 动作 | 具体内容 |
|------|----------|
| 剔除（Eliminate） | |
| 减少（Reduce） | |
| 增加（Raise） | |
| 创造（Create） | |

### 核心洞察
- 传统行业假设：
- 我们的新价值主张：
""",

    "战略报告": """
# 战略分析报告

## 企业：{company}
## 日期：{date}

---

## 执行摘要（一页纸）

### 核心结论
1.
2.
3.

### 关键建议

---

## 一、问题界定

### 1.1 背景

### 1.2 核心问题

### 1.3 分析范围

---

## 二、外部环境分析

### 2.1 宏观环境（STEEP）

### 2.2 行业分析（五力）

### 2.3 竞争格局

### 2.4 关键洞察

---

## 三、内部能力分析

### 3.1 财务表现

### 3.2 核心能力（VRIO）

### 3.3 组织能力（7S）

### 3.4 关键洞察

---

## 四、战略选项

### 选项A：
- 核心逻辑：
- 所需资源：
- 风险点：

### 选项B：
- 核心逻辑：
- 所需资源：
- 风险点：

### 选项C：
- 核心逻辑：
- 所需资源：
- 风险点：

---

## 五、方案评估

| 维度 | 权重 | 选项A | 选项B | 选项C |
|------|------|-------|-------|-------|
| 战略一致性 | | | | |
| 资源匹配 | | | | |
| 风险可控性 | | | | |
| 时间窗口 | | | | |
| 预期回报 | | | | |
| **加权总分** | | | | |

### 推荐方案：

---

## 六、实施路径

### 6.1 阶段划分

| 阶段 | 时间 | 目标 | 关键举措 |
|------|------|------|----------|
| 第一阶段 | | | |
| 第二阶段 | | | |
| 第三阶段 | | | |

### 6.2 资源需求

### 6.3 风险与应对

---

## 七、监控指标

| 指标 | 目标值 | 监控频率 | 负责人 |
|------|--------|----------|--------|
| | | | |

---

## 附录

### 数据来源

### 分析方法

### 参考资料
"""
}


def generate_template(template_type: str, output_path: str, **kwargs):
    """生成战略分析模板"""
    if template_type not in TEMPLATES:
        print(f"错误：未知的模板类型 '{template_type}'")
        print(f"可用模板：{', '.join(TEMPLATES.keys())}")
        return False

    # 添加日期
    kwargs['date'] = datetime.now().strftime('%Y-%m-%d')

    # 填充模板
    template = TEMPLATES[template_type]
    content = template.format(**kwargs)

    # 写入文件
    output_file = Path(output_path)
    output_file.write_text(content, encoding='utf-8')

    print(f"✓ 模板已生成：{output_file}")
    return True


def list_templates():
    """列出所有可用模板"""
    print("可用战略分析模板：")
    for i, name in enumerate(TEMPLATES.keys(), 1):
        print(f"  {i}. {name}")


def main():
    parser = argparse.ArgumentParser(description='战略分析模板生成器')
    parser.add_argument('command', choices=['list', 'generate'],
                       help='list: 列出模板；generate: 生成模板')
    parser.add_argument('--type', '-t', help='模板类型')
    parser.add_argument('--output', '-o', default='./', help='输出路径')
    parser.add_argument('--industry', '-i', default='待填写', help='行业名称')
    parser.add_argument('--company', '-c', default='待填写', help='企业名称')

    args = parser.parse_args()

    if args.command == 'list':
        list_templates()
    elif args.command == 'generate':
        if not args.type:
            print("错误：生成模板需要指定 --type 参数")
            return

        filename = f"{args.type}_{datetime.now().strftime('%Y%m%d')}.md"
        output_file = Path(args.output) / filename

        generate_template(
            args.type,
            str(output_file),
            industry=args.industry,
            company=args.company
        )


if __name__ == '__main__':
    main()
