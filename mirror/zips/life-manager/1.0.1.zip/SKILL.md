---
name: life-manager
description: 帮助用户在不同人生阶段平衡健康、事业、家庭、关系、兴趣、意义六个维度，实现可持续的幸福人生；当用户需要人生规划、日常计划、复盘反思、记录追踪或搜索历史经验时使用
---

# 人生经营智能管家

## 任务目标
- 本 Skill 用于：帮助用户经营完整人生，在健康、事业、家庭、关系、兴趣、意义六个维度找到平衡
- 能力包含：人生阶段识别、六维度管理、计划安排、复盘反思、记忆检索、个人系统迭代
- 触发条件：用户需要规划人生、安排日程、记录数据、复盘总结、或搜索历史经验时

## 前置准备
- 无特殊依赖
- 首次使用建议先完成5阶段引导流程
- 所有数据存储在用户本地 Markdown 文件中

## 核心概念

### 人生六维度框架
```
                    ┌─────────────┐
                    │   身体健康   │
                    └──────┬──────┘
                           │
        ┌──────────────────┼──────────────────┐
        │                  │                  │
        ▼                  ▼                  ▼
┌───────────────┐  ┌───────────────┐  ┌───────────────┐
│   事业财富    │  │   家庭管理    │  │  人际关系    │
└───────┬───────┘  └───────┬───────┘  └───────┬───────┘
        │                  │                  │
        └──────────────────┼──────────────────┘
                           │
                           ▼
                    ┌─────────────┐
                    │  生活兴趣   │
                    └──────┬──────┘
                           │
                           ▼
                    ┌─────────────┐
                    │  人生意义   │
                    └─────────────┘
```

### 人生阶段模型
- **探索期**（18-25岁）：尝试、学习、定位
- **建立期**（26-35岁）：专注、成长、突破
- **稳定期**（36-45岁）：巩固、责任、平衡
- **成熟期**（46-60岁）：传承、影响、准备
- **享受期**（60岁+）：享受、意义、健康

### 核心循环
```
愿景 → 计划 → 执行 → 复盘 → 迭代 → 成长
 ↑______________________________↓
```

### 记忆系统
- **工作记忆**：当前对话、当日任务（秒级访问）
- **短期记忆**：近30天记录（毫秒级访问）
- **长期记忆**：历史归档（秒级检索）
- **智能检索**：语义搜索 + 多维过滤 + 关联推荐

## 操作步骤

### 首次使用引导（5阶段）
1. **欢迎与人生阶段识别**（2-3分钟）
   - 询问年龄、职业状态、婚姻状态、子女情况
   - 系统自动推荐人生阶段（可手动调整）
   - 参考见 [references/onboarding-guide.md](references/onboarding-guide.md)

2. **人生六维度初探**（5-8分钟）
   - 介绍六个维度及其含义
   - 引导用户给各维度打分（1-10分）
   - 生成六维度雷达图
   - 参考见 [references/life-dimensions.md](references/life-dimensions.md)

3. **当前关注点识别**（3-5分钟）
   - 询问用户当前最关心的1-3件事
   - 分析关注点涉及的维度
   - 提供初步建议

4. **首个目标设定**（3-5分钟）
   - 选择最容易开始的目标
   - 设定具体、可衡量的目标
   - 确定开始日期和追踪方式

5. **功能推荐与开始使用**（2-3分钟）
   - 根据人生阶段推荐核心功能
   - 介绍快捷命令
   - 引导开始第一次记录

### 日常使用流程

#### 每日使用
1. **日计划制定**
   - 触发：`/日计划` 或 "帮我规划今天"
   - 内容：今日三件事、时间块安排、六维度时间分配
   - 模板：`assets/templates/daily_plan.md`

2. **日记录**
   - 记录健康数据：`/健康`（睡眠、运动、饮食）
   - 记录家庭活动：`/家庭`（伴侣互动、亲子时间）
   - 记录其他维度数据

3. **日复盘**
   - 触发：`/日复盘` 或 "今天复盘"
   - 内容：今日三件事完成情况、成就、改进、感恩、六维度评分
   - 模板：`assets/templates/daily_review.md`

#### 每周使用
1. **周计划制定**
   - 触发：`/周计划` 或 "帮我规划下周"
   - 内容：本周重点、六维度目标、固定安排
   - 模板：`assets/templates/weekly_plan.md`

2. **周复盘**
   - 触发：`/周复盘`
   - 内容：周重点完成、时间分析、六维度变化、小成就、下周计划
   - 模板：`assets/templates/weekly_review.md`

#### 每月使用
1. **月度人生复盘**
   - 触发：`/复盘` 或 `/月复盘`
   - 内容：六维度评分、目标完成度、关键反思、下月规划
   - 模板：`assets/templates/monthly_review.md`

2. **人生雷达图更新**
   - 触发：`/雷达`
   - 内容：查看六维度评分历史变化

#### 随时使用
1. **记录各种数据**
   - 健康：`/健康`
   - 家庭：`/家庭`
   - 关系：`/关系`
   - 兴趣：`/兴趣`
   - 意义：`/意义`

2. **记忆检索**
   - 语义搜索：`/搜索 我什么时候效率最高`
   - 主动回忆：`/回忆 工作生活平衡的反思`
   - 查看实践：`/实践`
   - 查看认知：`/认知`
   - 查看里程碑：`/里程碑`

3. **查看人生阶段**
   - 触发：`/阶段`
   - 内容：当前阶段特征、关键任务、权重配置
   - 参考见 [references/life-stages.md](references/life-stages.md)

4. **管理人生目标**
   - 触发：`/目标`
   - 内容：查看和设定各维度目标
   - 模板：`assets/templates/life_goals.md`

### 记忆系统使用
参考见 [references/memory-system.md](references/memory-system.md)

#### 工作记忆（智能体自动维护）
- 存储当前对话上下文
- 存储当日计划和任务状态
- 无需用户手动操作

#### 短期记忆（智能体自动管理）
- 自动索引近30天记录
- 快速查询近期数据
- 自动归档到长期记忆

#### 长期记忆（智能体管理）
- 历史复盘归档
- 最佳实践库累积
- 认知升级记录
- 人生里程碑

#### 智能检索
- **语义查询**："我什么时候效率最高"
- **关键词查询**："找一下关于运动的记录"
- **时间查询**："上个月的健康情况"
- **维度查询**："家庭维度的所有复盘"
- **关联查询**："我上次遇到类似问题是怎么解决的"

### 个人系统迭代升级

#### PDCA循环
1. **Plan（计划）**
   - 人生愿景 → 长期目标 → 年度目标 → 月/周/日计划
   - 六维度平衡 + 人生阶段权重

2. **Do（执行）**
   - 日计划执行 + 时间记录
   - 六维度活动追踪

3. **Check（检查）**
   - 日复盘 → 周复盘 → 月复盘
   - 六维度评分追踪

4. **Act（处理）**
   - 成功经验标准化
   - 问题根因分析
   - 计划调整 + 方法优化
   - 认知更新

#### 最佳实践积累
- 记录有效的方法和习惯
- 标签化分类管理
- 效果评分和使用次数追踪
- 模板：`assets/templates/best_practices.md`

#### 认知升级记录
- 记录观念转变时刻
- 旧认知 vs 新认知
- 触发事件和行为改变
- 模板：`assets/templates/cognitive_upgrades.md`

## 使用示例

### 示例1：首次使用
- **场景**：新用户首次使用
- **预期产出**：完成人生阶段识别、六维度评分、首个目标设定
- **关键要点**：渐进式引导，不一次性展示所有功能，从最简单的记录开始

### 示例2：日常计划与复盘
- **场景**：32岁在职用户，已婚有子女
- **预期产出**：制定日计划、记录健康数据、完成日复盘
- **关键要点**：平衡工作、家庭、健康三个维度，重点完成今日三件事

### 示例3：周度人生复盘
- **场景**：周日晚上进行周复盘
- **预期产出**：生成周复盘报告，包含六维度变化、目标完成度、下周计划
- **关键要点**：聚焦小成就，识别改进点，保持正向激励

### 示例4：搜索历史经验
- **场景**：遇到睡眠问题，想找之前的解决方案
- **预期产出**：检索到相关的最佳实践和复盘记录，提供具体建议
- **关键要点**：使用语义搜索，展示相关度排序，提供关联推荐

## 资源索引

### 参考文档
- [references/life-stages.md](references/life-stages.md) - 人生阶段模型详细说明（包含5个阶段的特征、关键任务、权重配置）
- [references/life-dimensions.md](references/life-dimensions.md) - 人生六维度框架（包含各维度子维度、管理内容、关键指标）
- [references/memory-system.md](references/memory-system.md) - 记忆系统设计（包含工作/短期/长期记忆架构、智能检索系统）
- [references/onboarding-guide.md](references/onboarding-guide.md) - 首次使用引导流程（包含5阶段完整对话脚本）

### 模板文件（31个核心模板）

**基础维度模板**：
- [assets/templates/life_stage.md](assets/templates/life_stage.md) - 人生阶段信息
- [assets/templates/life_dimensions.md](assets/templates/life_dimensions.md) - 六维度评分和追踪
- [assets/templates/life_goals.md](assets/templates/life_goals.md) - 人生目标

**身体健康维度**：
- [assets/templates/health_records.md](assets/templates/health_records.md) - 健康记录

**事业财富维度**（9个模板）：
- [assets/templates/career_development.md](assets/templates/career_development.md) - 事业发展追踪
- [assets/templates/finance_income.md](assets/templates/finance_income.md) - 收入记录
- [assets/templates/finance_expense.md](assets/templates/finance_expense.md) - 支出记录
- [assets/templates/finance_budget.md](assets/templates/finance_budget.md) - 预算管理
- [assets/templates/finance_investment.md](assets/templates/finance_investment.md) - 投资管理
- [assets/templates/finance_health.md](assets/templates/finance_health.md) - 财务健康评估
- [assets/templates/finance_summary.md](assets/templates/finance_summary.md) - 财务汇总
- [assets/templates/wealth_net_worth.md](assets/templates/wealth_net_worth.md) - 财富净值计算
- [assets/templates/career_wealth_analysis.md](assets/templates/career_wealth_analysis.md) - 事业财富关联分析

**家庭管理维度**：
- [assets/templates/family_records.md](assets/templates/family_records.md) - 家庭记录

**人际关系维度**：
- [assets/templates/relationship_map.md](assets/templates/relationship_map.md) - 人际关系地图

**生活兴趣维度**：
- [assets/templates/interest_journal.md](assets/templates/interest_journal.md) - 兴趣日志

**人生意义维度**：
- [assets/templates/meaning_reflection.md](assets/templates/meaning_reflection.md) - 意义反思

**计划复盘系统**（8个模板）：
- [assets/templates/daily_plan.md](assets/templates/daily_plan.md) - 日计划
- [assets/templates/daily_review.md](assets/templates/daily_review.md) - 日复盘
- [assets/templates/weekly_plan.md](assets/templates/weekly_plan.md) - 周计划
- [assets/templates/weekly_review.md](assets/templates/weekly_review.md) - 周复盘
- [assets/templates/monthly_plan.md](assets/templates/monthly_plan.md) - 月计划
- [assets/templates/monthly_review.md](assets/templates/monthly_review.md) - 月复盘
- [assets/templates/quarterly_review.md](assets/templates/quarterly_review.md) - 季度复盘
- [assets/templates/annual_review.md](assets/templates/annual_review.md) - 年度复盘

**个人系统迭代**（3个模板）：
- [assets/templates/best_practices.md](assets/templates/best_practices.md) - 最佳实践库
- [assets/templates/cognitive_upgrades.md](assets/templates/cognitive_upgrades.md) - 认知升级记录
- [assets/templates/milestones.md](assets/templates/milestones.md) - 人生里程碑

## 注意事项
- 所有数据存储在本地 Markdown 文件中，智能体不主动联网
- 首次使用建议完成5阶段引导流程，建立基础数据结构
- 六维度评分是主观评估，无需追求精确，主要目的是追踪变化趋势
- 计划复盘不需要严格按时间执行，根据实际情况灵活调整
- 记忆系统由智能体自动管理，用户无需手动操作索引
- 智能体具备完整的语言理解和内容分析能力，可直接读取和分析用户文件
- 检索功能支持语义搜索，不依赖精确关键词匹配
- 建议每周至少进行一次周复盘，每月进行一次月度人生复盘
- 人生阶段不是固定标签，可手动调整
- 维度权重会根据人生阶段自动调整，也可手动修改
