{
  "version": "3.1.4",
  "subskills": [
    {
      "id": "S01",
      "name": "项目质量策划",
      "name_en": "Quality Planning",
      "priority": "P0",
      "layer": "layer1",
      "prompt_file": "s01_quality_planning/main.md",
      "templates": [],
      "keywords": [
        "质量策划",
        "APQP",
        "项目质量",
        "质量目标",
        "阶段门",
        "质量管理计划"
      ],
      "trigger_conditions": [
        "新项目",
        "启动",
        "策划",
        "质量计划"
      ],
      "output_format": "formal_report",
      "estimated_time": "5-10分钟"
    },
    {
      "id": "S02",
      "name": "DFMEA分析",
      "name_en": "Design FMEA",
      "priority": "P0",
      "layer": "layer2",
      "prompt_file": "s02_fmea/main.md",
      "templates": [],
      "keywords": [
        "DFMEA",
        "FMEA",
        "失效模式",
        "风险评估",
        "RPN",
        "严重度",
        "频度",
        "探测度"
      ],
      "trigger_conditions": [
        "设计阶段",
        "风险分析",
        "FMEA分析"
      ],
      "output_format": "table",
      "estimated_time": "3-5分钟"
    },
    {
      "id": "S03",
      "name": "NUDD问题管理",
      "name_en": "NUDD Issue Management",
      "priority": "P1",
      "layer": "layer2",
      "prompt_file": "s03_nudd/main.md",
      "templates": [],
      "keywords": [
        "NUDD",
        "NUFR",
        "DNFR",
        "严重度",
        "重大问题",
        "紧急问题",
        "P0问题",
        "升级"
      ],
      "trigger_conditions": [
        "重大问题",
        "严重不良",
        "客诉",
        "安全问题"
      ],
      "output_format": "formal_report",
      "estimated_time": "2-3分钟"
    },
    {
      "id": "S04",
      "name": "PVT准出评审",
      "name_en": "PVT Gate Review",
      "priority": "P0",
      "layer": "layer2",
      "prompt_file": "s04_pvt/main.md",
      "templates": [],
      "keywords": [
        "PVT",
        "EVT",
        "DVT",
        "准出评审",
        "阶段评审",
        "试产",
        "评审检查表",
        "准出条件"
      ],
      "trigger_conditions": [
        "试产评审",
        "阶段评审",
        "PVT",
        "DVT",
        "EVT"
      ],
      "output_format": "table",
      "estimated_time": "5-8分钟"
    },
    {
      "id": "S05",
      "name": "供应商准入评估",
      "name_en": "Supplier Entry Evaluation",
      "priority": "P1",
      "layer": "layer2",
      "prompt_file": "s05_supplier_entry/main.md",
      "templates": [],
      "keywords": [
        "供应商准入",
        "供应商评估",
        "供应商评审",
        "新增供应商",
        "TPU",
        "体系审核"
      ],
      "trigger_conditions": [
        "新供应商",
        "准入评估",
        "供应商开发"
      ],
      "output_format": "table",
      "estimated_time": "8-10分钟"
    },
    {
      "id": "S06",
      "name": "供应商审核",
      "name_en": "Supplier Audit",
      "priority": "P1",
      "layer": "layer1",
      "prompt_file": "s06_supplier_audit/main.md",
      "templates": [
        "03_templates/03_checklists/audit_plan.md",
        "03_templates/01_formal_reports/supplier_audit_report.md"
      ],
      "keywords": [
        "供应商审核",
        "现场审核",
        "体系审核",
        "过程审核",
        "CAR",
        "纠正措施"
      ],
      "trigger_conditions": [
        "审核",
        "巡厂",
        "供应商检查"
      ],
      "output_format": "formal_report",
      "estimated_time": "10-15分钟"
    },
    {
      "id": "S07",
      "name": "来料异常分析",
      "name_en": "IQC Abnormal Analysis",
      "priority": "P1",
      "layer": "layer2",
      "prompt_file": "s07_iqc/main.md",
      "templates": [],
      "keywords": [
        "来料异常",
        "IQC",
        "来料检验",
        "不良分析",
        "AQL",
        "批退",
        "特采"
      ],
      "trigger_conditions": [
        "来料不良",
        "IQC判退",
        "来料异常"
      ],
      "output_format": "table",
      "estimated_time": "3-5分钟"
    },
    {
      "id": "S08",
      "name": "供应商8D管理",
      "name_en": "Supplier 8D Management",
      "priority": "P1",
      "layer": "layer1",
      "prompt_file": "s08_8d/main.md",
      "templates": [],
      "keywords": [
        "8D",
        "供应商8D",
        "D1-D8",
        "纠正措施",
        "永久措施",
        "问题解决"
      ],
      "trigger_conditions": [
        "8D",
        "供应商问题",
        "持续改进"
      ],
      "output_format": "formal_report",
      "estimated_time": "10-15分钟"
    },
    {
      "id": "S09",
      "name": "OQC出货检验",
      "name_en": "OQC Outgoing Inspection",
      "priority": "P0",
      "layer": "layer2",
      "prompt_file": "s09_oqc/main.md",
      "templates": [],
      "keywords": [
        "OQC",
        "出货检验",
        "出货检验报告",
        "终检",
        "FQC"
      ],
      "trigger_conditions": [
        "出货",
        "终检",
        "OQC"
      ],
      "output_format": "table",
      "estimated_time": "5-8分钟"
    },
    {
      "id": "S10",
      "name": "制程异常分析",
      "name_en": "Manufacturing Abnormal Analysis",
      "priority": "P1",
      "layer": "layer2",
      "prompt_file": "s10_mfg_abnormal/main.md",
      "templates": [],
      "keywords": [
        "制程异常",
        "过程异常",
        "IPQC",
        "巡检",
        "异常单",
        "工单异常"
      ],
      "trigger_conditions": [
        "制程问题",
        "生产异常",
        "过程不良"
      ],
      "output_format": "formal_report",
      "estimated_time": "5-10分钟"
    },
    {
      "id": "S11",
      "name": "客诉处理",
      "name_en": "Customer Complaint Handling",
      "priority": "P0",
      "layer": "layer1",
      "prompt_file": "s11_customer_complaint/main.md",
      "templates": [],
      "keywords": [
        "客诉",
        "客户投诉",
        "市场反馈",
        "退换货",
        "索赔",
        "客户满意度"
      ],
      "trigger_conditions": [
        "客户投诉",
        "市场问题",
        "客户反馈"
      ],
      "output_format": "formal_report",
      "estimated_time": "8-10分钟"
    },
    {
      "id": "S12",
      "name": "可靠性测试计划",
      "name_en": "Reliability Test Plan",
      "priority": "P1",
      "layer": "layer2",
      "prompt_file": "s12_reliability/main.md",
      "templates": [],
      "keywords": [
        "可靠性测试",
        "安规测试",
        "GB31241",
        "IP防水",
        "跌落测试",
        "寿命测试"
      ],
      "trigger_conditions": [
        "可靠性",
        "测试计划",
        "安规认证"
      ],
      "output_format": "table",
      "estimated_time": "8-12分钟"
    },
    {
      "id": "S13",
      "name": "安规标准查询",
      "name_en": "Safety Standard Reference",
      "priority": "P2",
      "layer": "layer3",
      "prompt_file": "s13_safety_standard/main.md",
      "templates": [],
      "keywords": [
        "安规",
        "GB31241",
        "GB4943",
        "IEC62368",
        "安全标准",
        "认证要求"
      ],
      "trigger_conditions": [
        "标准查询",
        "认证要求",
        "法规符合"
      ],
      "output_format": "quick_reference",
      "estimated_time": "1-2分钟"
    },
    {
      "id": "S14",
      "name": "质量成本分析",
      "name_en": "Quality Cost Analysis",
      "priority": "P2",
      "layer": "layer2",
      "prompt_file": "s14_quality_cost/main.md",
      "templates": [],
      "keywords": [
        "质量成本",
        "COQ",
        "不良成本",
        "预防成本",
        "鉴定成本",
        "失败成本"
      ],
      "trigger_conditions": [
        "成本分析",
        "质量损失",
        "成本改善"
      ],
      "output_format": "table",
      "estimated_time": "5-8分钟"
    },
    {
      "id": "S15",
      "name": "DOE验证方案",
      "name_en": "DOE Verification Plan",
      "priority": "P2",
      "layer": "layer2",
      "prompt_file": "s15_doe/main.md",
      "templates": [],
      "keywords": [
        "DOE",
        "正交试验",
        "参数优化",
        "试验设计",
        "因子分析",
        "响应面"
      ],
      "trigger_conditions": [
        "参数优化",
        "DOE",
        "试验设计"
      ],
      "output_format": "table",
      "estimated_time": "8-10分钟"
    },
    {
      "id": "S16",
      "name": "SPC/MSA分析",
      "name_en": "SPC and MSA Analysis",
      "priority": "P2",
      "layer": "layer2",
      "prompt_file": "s16_spc_msa/main.md",
      "templates": [],
      "keywords": [
        "SPC",
        "CPK",
        "过程能力",
        "控制图",
        "MSA",
        "GRR",
        "量具分析"
      ],
      "trigger_conditions": [
        "SPC",
        "CPK",
        "过程能力",
        "控制图"
      ],
      "output_format": "table",
      "estimated_time": "5-8分钟"
    },
    {
      "id": "S17",
      "name": "IPQC巡检标准",
      "name_en": "IPQC Inspection Standard",
      "priority": "P2",
      "layer": "layer2",
      "prompt_file": "s17_ipqc/main.md",
      "templates": [],
      "keywords": [
        "IPQC",
        "巡检",
        "过程检验",
        "首件",
        "巡检标准",
        "过程检查"
      ],
      "trigger_conditions": [
        "巡检",
        "IPQC",
        "过程检验"
      ],
      "output_format": "table",
      "estimated_time": "3-5分钟"
    },
    {
      "id": "S18",
      "name": "纠正预防措施",
      "name_en": "Corrective and Preventive Action",
      "priority": "P2",
      "layer": "layer1",
      "prompt_file": "s18_cap/main.md",
      "templates": [],
      "keywords": [
        "CAPA",
        "纠正",
        "预防",
        "纠正措施",
        "预防措施",
        "CAR",
        "改善措施"
      ],
      "trigger_conditions": [
        "改善",
        "预防",
        "纠正",
        "CAPA"
      ],
      "output_format": "formal_report",
      "estimated_time": "8-10分钟"
    },
    {
      "id": "S19",
      "name": "ISO文档生成",
      "name_en": "ISO Document Generation",
      "priority": "P2",
      "layer": "layer1",
      "prompt_file": "s19_iso_docs/main.md",
      "templates": [],
      "keywords": [
        "ISO9001",
        "质量手册",
        "程序文件",
        "作业指导书",
        "SOP",
        "体系文件"
      ],
      "trigger_conditions": [
        "体系文件",
        "ISO",
        "程序文件",
        "SOP"
      ],
      "output_format": "formal_report",
      "estimated_time": "10-15分钟"
    },
    {
      "id": "S20",
      "name": "质量周报生成",
      "name_en": "Quality Weekly Report",
      "priority": "P2",
      "layer": "layer4",
      "prompt_file": "s20_weekly_report/main.md",
      "templates": [],
      "keywords": [
        "质量周报",
        "质量月报",
        "质量报告",
        "周报",
        "月报",
        "质量数据",
        "质量看板"
      ],
      "trigger_conditions": [
        "周报",
        "月报",
        "质量报告",
        "数据汇总"
      ],
      "output_format": "table",
      "estimated_time": "5-10分钟"
    }
  ]
}