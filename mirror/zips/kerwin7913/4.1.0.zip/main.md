---
title: "Layer 3 - Meeting Minutes Style"
description: >
  English: Output style prompt for meeting minutes, quick communications, and status syncs.
  中文：会议纪要、快速沟通和状态同步的输出风格Prompt。
version: "1.0.0"
last_updated: "2026-04-02"
---

# Layer 3 Output Style: Meeting Minutes / 会议纪要风格

## When to Use / 适用场景

- **快速沟通** / Quick communication
- **状态同步** / Status sync
- **问题评审会** / Problem review meetings
- **日常站会** / Daily standups
- **紧急会议** / Urgent meetings

---

## Meeting Minutes Template / 会议纪要模板

```
# 【会议纪要】/ Meeting Minutes

> **会议信息** / Meeting Info
> | 项目 | 内容 |
> |------|------|
> | 会议主题 | [主题] |
> | 日期时间 | YYYY-MM-DD HH:MM - HH:MM |
> | 地点/方式 | [会议室/线上] |
> | 主持人 | [姓名] |
> | 记录人 | [姓名] |
> | 出席人员 | [姓名列表] |

---

## 议程 / Agenda

1. [议题1]
2. [议题2]
3. [议题3]

---

## 讨论要点 / Discussion Points

### 议题1: [主题]
- **提出方**: [姓名/部门]
- **问题描述**: [简明扼要描述]
- **讨论结果**: [结论或下一步]

### 议题2: [主题]
- **提出方**: [姓名/部门]
- **问题描述**: [简明扼要描述]
- **讨论结果**: [结论或下一步]

---

## 行动项 / Action Items

| # | 行动项 | 负责人 | 完成日期 | 状态 |
|---|--------|--------|----------|------|
| 1 | | | | ⏳进行中 |
| 2 | | | | ✅已完成 |

---

## 待跟进事项 / Follow-ups

- [待解决问题]: [负责人] @ [日期]
- [待确认信息]: [负责人] @ [日期]

---

## 下次会议 / Next Meeting

- **时间**: [日期时间]
- **议程**: [预议题]

---

*记录人: [姓名] | 日期: YYYY-MM-DD*
```

---

## Condensed Format / 精简格式

For very urgent or simple meetings:

```
## 【会议纪要】[日期] | [主题]

### 与会
[人员名单]

### 决议
1. [决定1]
2. [决定2]

### 待办
- [行动项] → [负责人] @ [日期]
```

---

## Problem Review Format / 问题评审格式

```
## 【问题评审纪要】[问题编号]

| 项目 | 内容 |
|------|------|
| 问题等级 | 🔴P0 / 🟠P1 / 🟡P2 |
| 问题类型 | [NUDD/NUFR/DNFR/其他] |
| 提出时间 | YYYY-MM-DD |
| 负责人 | [姓名] |

### 问题描述
[简明描述，3行以内]

### 影响评估
| 维度 | 影响 |
|------|------|
| 产品质量 | |
| 交期 | |
| 成本 | |
| 客户 | |

### 评审决议
[最终决定]

### 后续计划
- [下一步行动] → [负责人] @ [日期]
```

---

## Status Sync Format / 状态同步格式

```
## 【状态同步】[日期] | [项目/主题]

### 进度更新 / Progress Update
- ✅ 已完成: [任务列表]
- ⏳ 进行中: [任务列表] ([进度%])
- 🔴 延期风险: [任务列表]

### 关键问题 / Blockers
| 问题 | 影响 | 解决方案 | 负责人 |
|------|------|----------|--------|
| | | | |

### 下周计划 / Next Week
1. [计划1]
2. [计划2]
```

---

## Formatting Rules / 格式规范

### Status Indicators / 状态符号
| 符号 | 含义 | 英文 |
|------|------|------|
| ✅ | 已完成 | Done |
| ⏳ | 进行中 | In Progress |
| 🔴 | 紧急/阻塞 | Urgent/Blocked |
| ⚠️ | 需关注 | Attention Needed |
| 📅 | 按时 | On Schedule |
| ❌ | 严重问题 | Critical Issue |

### Time Formatting / 时间格式
- 日期: `YYYY-MM-DD`
- 时间: `HH:MM` (24小时制)
- 日期时间: `YYYY-MM-DD HH:MM`

### Action Item Format / 行动项格式
```
[行动描述] → [负责人] @ [完成日期]
```

---

## Quality Checklist / 质量检查项

- [ ] 会议信息完整
- [ ] 决议明确无歧义
- [ ] 行动项有负责人和日期
- [ ] 待跟进事项已记录
- [ ] 下次会议已安排（如果需要）
- [ ] 发送范围正确

---

*Maintained by Kerwin | Version 1.0.0 | 2026-04-02*
