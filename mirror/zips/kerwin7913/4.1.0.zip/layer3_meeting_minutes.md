{
  "version": "3.1.2",
  "last_updated": "2026-04-02",
  "description": {
    "en": "Global tag library for 3C Quality Assistant. Used for content classification, filtering, and routing.",
    "zh": "3C质量助手的全局标签库，用于内容分类、筛选和路由。"
  },

  "tag_categories": {

    "product_line": {
      "description": "产品线标签 / Product Line Tags",
      "tags": [
        { "id": "PL-001", "name": "盆底肌训练器", "name_en": "Pelvic Floor Trainer", "synonyms": ["盆底肌", "PF", "凯格尔"] },
        { "id": "PL-002", "name": "振动按摩器", "name_en": "Vibrator/Massager", "synonyms": ["按摩器", "振动器", "跳蛋"] },
        { "id": "PL-003", "name": "智能飞机杯", "name_en": "Smart Masturbator", "synonyms": ["飞机杯", "男性器具"] },
        { "id": "PL-004", "name": "App/软件", "name_en": "App/Software", "synonyms": ["App", "小程序", "固件", "软件"] },
        { "id": "PL-005", "name": "附件/配件", "name_en": "Accessories", "synonyms": ["配件", "充电器", "说明书"] }
      ]
    },

    "process_stage": {
      "description": "研发阶段标签 / R&D Stage Tags",
      "tags": [
        { "id": "ST-001", "name": "EVT", "name_en": "Engineering Verification Test", "level": 1 },
        { "id": "ST-002", "name": "DVT", "name_en": "Design Verification Test", "level": 2 },
        { "id": "ST-003", "name": "PVT", "name_en": "Production Verification Test", "level": 3 },
        { "id": "ST-004", "name": "MP", "name_en": "Mass Production", "level": 4 },
        { "id": "ST-005", "name": "NPI", "name_en": "New Product Introduction", "synonyms": ["新品导入"] }
      ]
    },

    "quality_dimension": {
      "description": "质量维度标签 / Quality Dimension Tags",
      "tags": [
        { "id": "QD-001", "name": "功能质量", "name_en": "Functional Quality" },
        { "id": "QD-002", "name": "可靠性", "name_en": "Reliability" },
        { "id": "QD-003", "name": "安全性", "name_en": "Safety" },
        { "id": "QD-004", "name": "法规符合性", "name_en": "Regulatory Compliance" },
        { "id": "QD-005", "name": "外观质量", "name_en": "Aesthetic Quality" },
        { "id": "QD-006", "name": "包装质量", "name_en": "Packaging Quality" },
        { "id": "QD-007", "name": "成本质量", "name_en": "Cost Quality" }
      ]
    },

    "severity": {
      "description": "严重度标签 / Severity Tags",
      "tags": [
        { "id": "SEV-1", "name": "致命", "name_en": "Critical", "color": "#FF0000", "description": "可能导致人身伤害或重大财产损失" },
        { "id": "SEV-2", "name": "严重", "name_en": "Major", "color": "#FF6600", "description": "可能导致产品失效或严重投诉" },
        { "id": "SEV-3", "name": "一般", "name_en": "Moderate", "color": "#FFCC00", "description": "可能影响使用但可接受" },
        { "id": "SEV-4", "name": "轻微", "name_en": "Minor", "color": "#00CC00", "description": "不影响功能的小瑕疵" }
      ]
    },

    "occurrence_frequency": {
      "description": "发生频次标签 / Occurrence Frequency Tags",
      "tags": [
        { "id": "OCC-1", "name": "极高", "name_en": "Very High", "range": ">20%" },
        { "id": "OCC-2", "name": "高", "name_en": "High", "range": "10-20%" },
        { "id": "OCC-3", "name": "中等", "name_en": "Medium", "range": "2-10%" },
        { "id": "OCC-4", "name": "低", "name_en": "Low", "range": "<2%" },
        { "id": "OCC-5", "name": "极低", "name_en": "Very Low", "range": "<0.1%" }
      ]
    },

    "detection_difficulty": {
      "description": "探测难度标签 / Detection Difficulty Tags",
      "tags": [
        { "id": "DET-1", "name": "极难探测", "name_en": "Very Difficult", "score": 10 },
        { "id": "DET-2", "name": "难探测", "name_en": "Difficult", "score": 7 },
        { "id": "DET-3", "name": "中等", "name_en": "Moderate", "score": 5 },
        { "id": "DET-4", "name": "易探测", "name_en": "Easy", "score": 3 },
        { "id": "DET-5", "name": "极易探测", "name_en": "Very Easy", "score": 1 }
      ]
    },

    "problem_type": {
      "description": "问题类型标签 / Problem Type Tags",
      "tags": [
        { "id": "PRB-001", "name": "NUDD", "name_en": "New/Unusual/Difficult/Deadlock", "description": "新问题/异常问题/困难问题/僵局问题" },
        { "id": "PRB-002", "name": "NUFR", "name_en": "New Unusual Field Report", "description": "现场新异常报告" },
        { "id": "PRB-003", "name": "DNFR", "name_en": "Defect Not Found in Review", "description": "评审未发现的缺陷" },
        { "id": "PRB-004", "name": "P0", "name_en": "Critical Problem", "description": "严重问题，需立即处理" },
        { "id": "PRB-005", "name": "SCAR", "name_en": "Supplier Corrective Action Request", "description": "供应商纠正措施要求" }
      ]
    },

    "standard_reference": {
      "description": "标准参考标签 / Standard Reference Tags",
      "tags": [
        { "id": "STD-001", "name": "GB 31241", "name_en": "Lithium Battery Safety", "domain": "锂电池安全" },
        { "id": "STD-002", "name": "GB 4943.1", "name_en": "IT Equipment Safety", "domain": "信息技术设备安全" },
        { "id": "STD-003", "name": "IEC 62368-1", "name_en": "AV/IT Equipment Safety", "domain": "音视频/信息技术设备安全" },
        { "id": "STD-004", "name": "ISO 9001", "name_en": "Quality Management System", "domain": "质量管理体系" },
        { "id": "STD-005", "name": "IP防水", "name_en": "IP Rating", "domain": "防水防尘等级" },
        { "id": "STD-006", "name": "RoHS", "name_en": "RoHS Directive", "domain": "有害物质限制" },
        { "id": "STD-007", "name": "REACH", "name_en": "REACH Regulation", "domain": "化学品注册与评估" }
      ]
    },

    "output_layer": {
      "description": "输出层级标签 / Output Layer Tags",
      "tags": [
        { "id": "LYR-1", "name": "正式报告", "name_en": "Formal Report", "usage": "正式交付、存档、评审", "format": "Markdown/Word" },
        { "id": "LYR-2", "name": "表格输出", "name_en": "Table Format", "usage": "数据分析、清单整理", "format": "Markdown Table/Excel" },
        { "id": "LYR-3", "name": "会议纪要", "name_en": "Meeting Minutes", "usage": "快速沟通、同步信息", "format": "Markdown" },
        { "id": "LYR-4", "name": "管理汇报", "name_en": "Management Report", "usage": "向上汇报、数据看板", "format": "Markdown/Dashboard" }
      ]
    },

    "supplier_issue_type": {
      "description": "供应商问题类型标签 / Supplier Issue Type Tags",
      "tags": [
        { "id": "SUP-001", "name": "来料不良", "name_en": "Incoming Defect", "scope": "IQC" },
        { "id": "SUP-002", "name": "交期延误", "name_en": "Delivery Delay", "scope": "PMC" },
        { "id": "SUP-003", "name": "包装问题", "name_en": "Packaging Issue", "scope": "IQC/仓库" },
        { "id": "SUP-004", "name": "标识错误", "name_en": "Labeling Error", "scope": "IQC" },
        { "id": "SUP-005", "name": "认证缺失", "name_en": "Certification Missing", "scope": "SQE" },
        { "id": "SUP-006", "name": "工艺变更", "name_en": "Process Change", "scope": "SQE/研发" }
      ]
    }

  },

  "tag_usage_rules": {
    "min_tags_per_output": 1,
    "max_tags_per_output": 5,
    "required_tags": ["product_line", "process_stage", "output_layer"],
    "optional_tags": ["severity", "quality_dimension", "standard_reference"]
  }
}
