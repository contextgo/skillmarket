---
title: "Layer 2 - Table Format Style"
description: >
  English: Output style prompt for structured tables, checklists, and data presentations.
  中文：结构化表格、检查表和数据呈现的输出风格Prompt。
version: "1.0.0"
last_updated: "2026-04-02"
---

# Layer 2 Output Style: Table Format / 表格输出风格

## When to Use / 适用场景

- **数据分析** / Data analysis
- **评审检查表** / Review checklists
- **清单整理** / List organization
- **评估打分** / Evaluation scoring
- **台账记录** / Records/ledgers

---

## Standard Table Templates / 标准表格模板

### Template 1: Basic Data Table / 基础数据表

```
## [表格标题] / Table Title

| 序号 | 项目 | 规格/要求 | 实际值 | 判定 | 备注 |
|------|------|-----------|--------|------|------|
| 1 | ... | ... | ... | ✅/❌ | ... |
| 2 | ... | ... | ... | ✅/❌ | ... |

**汇总**: 共 [X] 项，通过 [Y] 项，不通过 [Z] 项
```

### Template 2: Evaluation Scoring Table / 评估打分表

```
## [评估项] / Evaluation Item

### 评估标准 / Criteria
| 评分维度 | 权重 | 得分(0-10) | 加权得分 |
|----------|------|------------|----------|
| 技术能力 | 30% | | |
| 质量管控 | 25% | | |
| 交付能力 | 20% | | |
| 价格竞争力 | 15% | | |
| 服务响应 | 10% | | |
| **总分** | **100%** | | |

**评估结论**: [总分] / 100
```

### Template 3: Checklist Table / 检查表

```
## [检查项] / Checklist

| # | 检查项目 | 检查方法 | 标准 | 结果 | 判定 | 改善措施 |
|---|----------|----------|------|------|------|----------|
| 1 | ... | ... | ... | ... | ✅/❌/N/A | ... |
| 2 | ... | ... | ... | ... | ✅/❌/N/A | ... |

**检查结论**: 
- ✅ 符合项: [X]
- ❌ 不符合项: [Y]
- N/A 不适用项: [Z]
```

### Template 4: Comparison Table / 对比表

```
## [对比项] / Comparison

| 对比维度 | 方案A | 方案B | 方案C | 推荐 |
|----------|-------|-------|-------|------|
| 成本 | | | | |
| 质量 | | | | |
| 交期 | | | | |
| 风险 | | | | |
| **综合推荐** | | | | **★** |

**推荐理由**: [简要说明]
```

### Template 5: Trend/Time Series Table / 趋势表

```
## [趋势分析] / Trend Analysis

| 时间 | 指标1 | 指标2 | 指标3 | 环比 | 备注 |
|------|-------|-------|-------|------|------|
| 2026-01 | | | | - | |
| 2026-02 | | | | +X% | |
| 2026-03 | | | | +X% | |

**趋势判断**: [上升/下降/稳定]
```

---

## Table Formatting Rules / 表格格式规范

### Column Alignment / 列对齐
- 文字内容：左对齐 `|:---|`
- 数字内容：右对齐 `|---:|`
- 混合内容：居中 `|:---:|`

### Data Validation Symbols / 数据验证符号
| 符号 | 含义 | 使用场景 |
|------|------|----------|
| ✅ | 符合/通过 | 检查项判定 |
| ❌ | 不符合/不通过 | 检查项判定 |
| ⚠️ | 警告/注意 | 临界状态 |
| N/A | 不适用 | 不相关项 |
| 🔴 | 严重/高风险 | 风险评估 |
| 🟡 | 一般/中风险 | 风险评估 |
| 🟢 | 轻微/低风险 | 风险评估 |

### Numeric Formatting / 数值格式
- 百分比：保留2位小数 `XX.XX%`
- 金额：保留2位小数 `¥X,XXX.XX`
- 数量：整数 `X,XXX`
- 比率：保留3位小数 `X.XXX`

---

## Summary Section / 汇总区域

Every table output should include a summary section:

```
## 汇总 / Summary

| 汇总项 | 数值 |
|--------|------|
| 总数 | [X] |
| 通过数 | [Y] |
| 通过率 | [Z%] |
| 关键问题 | [简述] |

### 关键发现 / Key Findings
1. [最重要发现]
2. [第二重要发现]
3. [第三重要发现]

### 建议行动 / Recommended Actions
- [优先级P0]: [行动项]
- [优先级P1]: [行动项]
```

---

## Quality Checklist / 质量检查项

- [ ] 所有表格有清晰的标题
- [ ] 表头与数据对齐正确
- [ ] 数值格式统一规范
- [ ] 判定结果用统一符号
- [ ] 汇总区完整
- [ ] 关键发现突出显示

---

*Maintained by Kerwin | Version 1.0.0 | 2026-04-02*
