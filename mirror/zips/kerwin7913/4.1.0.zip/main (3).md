---
title: "Shared - 3C Product Context (大人糖)"
description: >
  English: Product category and context information for 3C Quality Assistant, focused on DareTo brand products.
  中文：3C质量助手的产品类别和上下文信息，聚焦大人糖品牌产品。
version: "1.0.0"
last_updated: "2026-04-02"
---

# Product Context / 产品上下文

## Brand Background / 品牌背景

### 大人糖 (DareTo)
- **定位**: 阳光情趣美学
- **使命**: 情趣阳光化，去色情化
- **目标客群**: 25-45岁女性
- **核心价值**: 女性视角、审美设计、健康关怀

---

## Product Categories / 产品分类

### 1. 盆底肌训练器 (Pelvic Floor Trainer)
| 属性 | 说明 |
|------|------|
| 英文名 | Pelvic Floor Muscle Trainer / Kegel Trainer |
| 产品形态 | 侵入式/非侵入式康复器械 |
| 核心技术 | 生物反馈、EMS电刺激 |
| App联动 | 蓝牙连接，数据记录 |
| 安全关注 | 材质生物相容性、充电安全 |

**典型规格**:
- 材质: 医用级硅胶、ABS
- 电池: 锂电池/USB充电
- 防水等级: IPX7
- 连接方式: 蓝牙BLE

---

### 2. 振动按摩器 (Vibrator/Massager)
| 属性 | 说明 |
|------|------|
| 英文名 | Vibrator / Massager |
| 产品形态 | 多形态（跳蛋、按摩棒等） |
| 核心技术 | 振动马达、智能控制 |
| 安全关注 | 材质安全、防水性能、充电安全 |

**典型规格**:
- 材质: 硅胶、TPE、ABS
- 防水等级: IPX6-IPX7
- 充电方式: 磁吸充电/无线充电

---

### 3. 智能互动设备 (Smart Interactive Devices)
| 属性 | 说明 |
|------|------|
| 产品形态 | 远程互动、智能控制 |
| 核心技术 | IoT、远程控制、App联动 |
| 安全关注 | 数据安全、隐私保护 |

---

## Key Quality Requirements / 关键质量要求

### 电气安全 / Electrical Safety
| 标准 | 适用范围 |
|------|----------|
| GB 4943.1-2022 | 信息技术设备安全 |
| IEC 62368-1 | 音视频/信息技术设备安全 |
| GB 31241-2014 | 锂电池安全（带电池产品） |

### 材料安全 / Material Safety
| 要求 | 说明 |
|------|------|
| 皮肤接触材料 | 符合RoHS、REACH要求 |
| 侵入式材料 | 需生物相容性测试（如果适用） |
| 儿童安全 | 需防儿童开启设计（如果含电池） |

### 防水要求 / Waterproof Requirements
| IP等级 | 适用产品 |
|--------|----------|
| IPX6 | 防泼溅，短时间雨淋 |
| IPX7 | 短时浸水（1米，30分钟） |
| IP67 | 完全防尘，短时浸水 |

---

## Quality Focus Areas / 质量关注点

### 研发阶段 (EVT/DVT)
| 关注点 | 说明 |
|--------|------|
| DFMEA | 重点关注材料相容性、防水设计、App稳定性 |
| 可靠性测试 | 寿命测试、防水测试、电池循环 |
| 安规预检 | 提前识别安规风险 |

### 生产阶段 (PVT/MP)
| 关注点 | 说明 |
|------|------|
| 来料检验 | 硅胶/电池/PCBA重点管控 |
| 过程检验 | 防水装配、App配对测试 |
| 出货检验 | 全检或抽检按AQL |

---

## Terminology Guidelines / 术语使用规范

### Preferred Terms / 推荐术语
| 禁用 | 推荐 |
|------|------|
| 情趣用品 | 情趣美学产品 / 健康护理产品 |
| 性生活 | 亲密关系 / 两性健康 |
| 性玩具 | 智能按摩器 / 健康训练器 |

### English Translation Tips / 英文翻译注意
| 中文 | 英文 | 备注 |
|------|------|------|
| 跳蛋 | Vibrating egg | 避免俚语 |
| 飞机杯 | Male masturbator | 使用正式名称 |
| 成人用品 | Adult wellness products | 避免敏感词 |

---

## Product Development Stage Definitions / 研发阶段定义

| 阶段 | 英文 | 含义 |
|------|------|------|
| EVT | Engineering Verification Test | 工程验证测试，验证设计可行性 |
| DVT | Design Verification Test | 设计验证测试，验证设计符合性 |
| PVT | Production Verification Test | 生产验证测试，验证量产可行性 |
| MP | Mass Production | 量产阶段 |

---

*Maintained by Kerwin | Last Updated: 2026-04-02*
