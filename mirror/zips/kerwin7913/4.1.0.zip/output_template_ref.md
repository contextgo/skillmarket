---
title: "Layer 1 - Formal Report Style"
description: >
  English: Output style prompt for formal reports with complete structure, headers, tables, and appendices.
  中文：正式报告输出风格Prompt，包含完整结构、标题、表格和附录。
version: "1.0.0"
last_updated: "2026-04-02"
---

# Layer 1 Output Style: Formal Report / 正式报告风格

## When to Use / 适用场景

- **正式交付** / Formal delivery
- **存档归档** / Archival
- **评审会议** / Review meetings
- **客户提交** / Client submission
- **体系文件** / System documentation

---

## Document Structure / 文档结构

```
# 【文档标题】

> **文档信息表** / Document Info Table
> | 项目 | 内容 |
> |------|------|
> | 文档编号 | [自动生成] |
> | 版本 | V1.0 |
> | 日期 | YYYY-MM-DD |
> | 编写人 | [根据上下文] |
> | 审核人 | [待填写] |
> | 批准人 | [待填写] |

---

## 1. 概述 / Executive Summary

### 1.1 背景 / Background
[说明文档生成的背景和目的]

### 1.2 范围 / Scope
[明确文档适用的范围]

### 1.3 依据 / Reference
[列出参考的标准、规范、文件]

---

## 2. 核心内容 / Core Content

### 2.1 [主题1] / [Topic 1]
[详细内容和表格]

### 2.2 [主题2] / [Topic 2]
[详细内容和表格]

---

## 3. 分析与结论 / Analysis & Conclusions

### 3.1 关键发现 / Key Findings
| # | 发现项 | 说明 | 建议 |
|---|--------|------|------|
| 1 | ... | ... | ... |

### 3.2 结论 / Conclusions
[总结性结论]

---

## 4. 建议与措施 / Recommendations

| 序号 | 建议项 | 负责人 | 完成日期 | 优先级 |
|------|--------|--------|----------|--------|
| 1 | ... | ... | ... | P0/P1/P2 |

---

## 5. 附录 / Appendices

### 附录A: [附件名称]
[附件内容]

### 附录B: [附件名称]
[附件内容]

---

## 6. 签核栏 / Sign-off

| 角色 | 姓名 | 日期 | 签字 |
|------|------|------|------|
| 编写 | | | |
| 审核 | | | |
| 批准 | | | |

---

*文档结束 / End of Document*
```

---

## Formatting Rules / 格式规范

### Headers / 标题层级
- `#` 一级标题：文档标题
- `##` 二级标题：大章节
- `###` 三级标题：小节
- `####` 四级标题：子节

### Tables / 表格
- 必须包含表头和边框线
- 使用 `|---|` 分隔符
- 重要数据加粗

### Lists / 列表
- 使用有序列表 `1. 2. 3.` 表示步骤
- 使用无序列表 `-` 表示要点
- 嵌套列表使用 `  -`

### Emphasis / 强调
- **加粗** 用于关键词和重要数据
- *斜体* 用于定义和说明
- `代码格式` 用于专业术语

---

## Quality Checklist / 质量检查项

Before finalizing, verify:

- [ ] 文档编号和版本正确
- [ ] 日期格式为 YYYY-MM-DD
- [ ] 所有表格有标题
- [ ] 必要签核栏完整
- [ ] 专业术语使用正确
- [ ] 无错别字和语法错误
- [ ] 页眉页脚（如果需要）

---

*Maintained by Kerwin | Version 1.0.0 | 2026-04-02*
