{
  "skill_id": "3c-quality-assistant",
  "name": "3C Quality Assistant",
  "name_cn": "3C消费电子质量管理助手",
  "version": "3.1.4",
  "author": "WorkBuddy AI",
  "created_date": "2026-04-02",
  "last_updated": "2026-04-02",
  "description": {
    "zh": "面向3C消费电子研发质量工程师的AI助手，覆盖项目全生命周期质量管理场景，包括质量策划、FMEA分析、NUDD管理、供应商审核、PVT评审、质量报告等20个核心能力域。",
    "en": "AI assistant for 3C consumer electronics R&D quality engineers, covering full project lifecycle quality management including quality planning, FMEA, NUDD management, supplier audit, PVT review, quality reports."
  },
  "scope": {
    "industry": [
      "3C消费电子",
      "智能硬件",
      "IoT设备",
      "女性健康电子产品"
    ],
    "product_categories": [
      "手机配件",
      "充电器/移动电源",
      "音频设备",
      "智能按摩/健康设备",
      "智能穿戴",
      "情趣健康产品"
    ],
    "standards": [
      "GB 31241-2014",
      "GB 4943.1-2022",
      "IEC 62368-1",
      "ISO 9001:2015"
    ]
  },
  "capabilities": {
    "total_subskills": 20,
    "p0_count": 4,
    "p1_count": 8,
    "p2_count": 8,
    "layer1_reports": 6,
    "layer2_reports": 11,
    "layer3_reports": 1,
    "layer4_reports": 2
  },
  "file_structure": {
    "total_files": 99,
    "prompt_files": 30,
    "template_files": 28,
    "routing_configs": 4,
    "example_files": 12,
    "knowledge_files": 20
  },
  "dependencies": {
    "required": [],
    "optional": [
      "finance-data-retrieval"
    ],
    "compatible_skills": [
      "Hardware Quality Engineering"
    ]
  },
  "configuration": {
    "auto_route": true,
    "multi_task_enabled": true,
    "output_layer_auto_detect": true,
    "prohibited_words_check": true
  },
  "maintenance": {
    "update_frequency": "monthly",
    "knowledge_refresh": "quarterly",
    "example_refresh": "semi-annual"
  },
  "status": "ready_for_development"
}