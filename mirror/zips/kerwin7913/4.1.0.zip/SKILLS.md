# 3C质量专家系统安装指南 v3.1.2

## 📦 一键安装
将此文件夹复制到：
- Windows: C:\Users\你的用户名\.workbuddy\skills\3c-quality-assistant
- macOS: ~/.workbuddy/skills/3c-quality-assistant

## 🔍 验证安装
重启WorkBuddy后，在技能中心搜索"3C Quality Assistant"

## 🎯 快速测试
输入以下命令测试安装：
"帮我做个APQP项目质量策划"
"需要写一份客户8D报告"

## 📞 获取帮助
完整文档：查看 README-INSTALL.md
技术支持：kerwin.lua@outlook.com

---
> 企业级3C消费电子产品质量管理AI专家系统
> 采用三层智能路由架构，覆盖EVT→DVT→PVT→量产全生命周期