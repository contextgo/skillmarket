{
  "version": "3.1.2",
  "last_updated": "2026-04-02",
  "description": "质量领域禁止输出词汇表，避免在报告中出现不专业或违规的表达",
  "categories": {
    "imprecise_terms": {
      "description": "不精确/模糊表达",
      "words": [
        "可能大概",
        "也许应该",
        "差不多",
        "基本上",
        "基本上没问题",
        "应该可以",
        "估计问题不大",
        "估计差不多",
        "大概其",
        "应该没问题吧"
      ],
      "replacement": "建议使用具体数据或量化描述"
    },
    "irresponsible_statements": {
      "description": "不负责任的表达",
      "words": [
        "这不关我的事",
        "不是我的问题",
        "供应商自己的问题",
        "客户自己弄坏的",
        "这谁也没办法",
        "没有办法解决",
        "只能这样了"
      ],
      "replacement": "聚焦问题解决和根因分析"
    },
    "unsafe_practices": {
      "description": "涉及安全隐患的表述",
      "words": [
        "可以不用接地",
        "这个安全问题不大",
        "安规测试可以跳过",
        "偷工减料也没关系",
        "用便宜的材料代替",
        "降低安全系数"
      ],
      "replacement": "安全相关必须严格遵循标准"
    },
    "non_professional": {
      "description": "非专业表达",
      "words": [
        "乱七八糟",
        "一塌糊涂",
        "太烂了",
        "质量太差了",
        "供应商太差",
        "设计师脑残",
        "这设计有问题"
      ],
      "replacement": "使用质量专业术语描述问题"
    }
  },
  "output_guidelines": {
    "negative_expression": {
      "rule": "避免单纯抱怨问题，应同时提供解决方案",
      "example": "不良率高 → 分析根因并提出改善措施"
    },
    "responsibility_attribution": {
      "rule": "问题归因需基于事实，避免无端指责",
      "example": "基于数据分析判定责任方，而非主观判断"
    },
    "safety_related": {
      "rule": "安全相关结论必须引用标准，不使用模糊表述",
      "example": "依据GB31241第X.X条，判定为不符合"
    }
  }
}
