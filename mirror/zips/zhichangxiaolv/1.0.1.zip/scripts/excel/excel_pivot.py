#!/usr/bin/env python3
"""
Excel数据透视表工具
功能：快速创建数据透视表，支持多维度分析
"""

import argparse
from pathlib import Path
import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment


def create_pivot_table(data_file, output_file, 
                       index, values, aggfunc='sum',
                       columns=None, fill_value=0):
    """
    创建数据透视表
    
    Args:
        data_file: 源数据文件
        output_file: 输出文件路径
        index: 行索引（分组字段）
        values: 值字段（聚合字段）
        aggfunc: 聚合函数 sum/mean/count/max/min
        columns: 列分组字段
        fill_value: 缺失值填充
    """
    # 读取数据
    suffix = Path(data_file).suffix.lower()
    if suffix == '.csv':
        df = pd.read_csv(data_file, encoding='utf-8-sig')
    else:
        df = pd.read_excel(data_file)
    
    print(f"✅ 读取数据: {len(df)} 行 x {len(df.columns)} 列")
    
    # 创建透视表
    if isinstance(values, str):
        values = [values]
    
    pivot = pd.pivot_table(
        df,
        index=index,
        values=values,
        aggfunc=aggfunc,
        columns=columns,
        fill_value=fill_value
    )
    
    print(f"✅ 生成透视表: {len(pivot)} 行 x {len(pivot.columns)} 列")
    
    # 保存
    output_path = Path(output_file)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    if output_path.suffix.lower() == '.csv':
        pivot.to_csv(output_file, encoding='utf-8-sig')
    else:
        with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
            # 写入透视表
            pivot.to_excel(writer, sheet_name='透视表')
            
            # 格式化
            wb = writer.book
            ws = wb['透视表']
            
            # 表头样式
            header_fill = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')
            header_font = Font(bold=True, color='FFFFFF')
            
            for cell in ws[1]:
                cell.fill = header_fill
                cell.font = header_font
                cell.alignment = Alignment(horizontal='center', vertical='center')
            
            # 设置列宽
            for col in ws.columns:
                max_length = 0
                col_letter = col[0].column_letter
                for cell in col:
                    try:
                        if len(str(cell.value)) > max_length:
                            max_length = len(str(cell.value))
                    except:
                        pass
                adjusted_width = min(max_length + 4, 30)
                ws.column_dimensions[col_letter].width = adjusted_width
    
    print(f"✅ 输出文件: {output_file}")
    return pivot


def pivot_by_multiple(data_file, output_file, 
                      rows, cols, values, aggfunc='sum'):
    """多维度透视"""
    suffix = Path(data_file).suffix.lower()
    if suffix == '.csv':
        df = pd.read_csv(data_file, encoding='utf-8-sig')
    else:
        df = pd.read_excel(data_file)
    
    # 分组统计
    grouped = df.groupby(rows + cols)[values].agg(aggfunc).reset_index()
    
    # 转换为透视格式
    pivot = grouped.pivot_table(
        index=rows if isinstance(rows, str) else rows,
        columns=cols,
        values=values,
        fill_value=0
    )
    
    pivot.to_excel(output_file)
    print(f"✅ 多维度透视完成: {output_file}")
    
    return pivot


def main():
    parser = argparse.ArgumentParser(description='Excel数据透视表工具')
    parser.add_argument('input', help='输入数据文件')
    parser.add_argument('-o', '--output', required=True, help='输出文件')
    parser.add_argument('-i', '--index', required=True, help='行索引字段')
    parser.add_argument('-v', '--values', required=True, help='值字段')
    parser.add_argument('-a', '--aggfunc', default='sum',
                       choices=['sum', 'mean', 'count', 'max', 'min'],
                       help='聚合函数')
    parser.add_argument('-c', '--columns', help='列分组字段')
    parser.add_argument('-f', '--fill', type=int, default=0, help='缺失值填充')
    
    args = parser.parse_args()
    
    create_pivot_table(
        args.input,
        args.output,
        index=args.index,
        values=args.values,
        aggfunc=args.aggfunc,
        columns=args.columns,
        fill_value=args.fill
    )


if __name__ == '__main__':
    main()
