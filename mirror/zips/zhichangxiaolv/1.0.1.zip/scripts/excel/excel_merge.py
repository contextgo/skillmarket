#!/usr/bin/env python3
"""
Excel数据合并工具
功能：合并多个Excel/CSV文件，支持按sheet或按列合并
"""

import os
import argparse
import pandas as pd
from pathlib import Path
from datetime import datetime


def merge_excel_files(file_list, output_file, sheet_name=None, 
                     concat_axis='rows', join_type='outer',
                     ignore_index=True):
    """
    合并Excel文件
    
    Args:
        file_list: 文件路径列表
        output_file: 输出文件路径
        sheet_name: 读取的sheet名称
        concat_axis: 'rows'=纵向合并, 'columns'=横向合并
        join_type: 'inner'=内连接, 'outer'=外连接
        ignore_index: 是否重置索引
    """
    dfs = []
    
    for file_path in file_list:
        path = Path(file_path)
        if not path.exists():
            print(f"⚠️  文件不存在，跳过: {file_path}")
            continue
        
        suffix = path.suffix.lower()
        
        try:
            if suffix == '.csv':
                df = pd.read_csv(file_path, encoding='utf-8-sig')
            elif suffix in ['.xlsx', '.xls']:
                if sheet_name:
                    df = pd.read_excel(file_path, sheet_name=sheet_name)
                else:
                    # 读取所有sheet并合并
                    all_sheets = pd.read_excel(file_path, sheet_name=None)
                    dfs_sheet = []
                    for sheet_n, sheet_df in all_sheets.items():
                        sheet_df['_source_sheet'] = sheet_n
                        dfs_sheet.append(sheet_df)
                    if dfs_sheet:
                        df = pd.concat(dfs_sheet, ignore_index=True)
                    else:
                        continue
            else:
                print(f"⚠️  不支持的文件格式: {suffix}")
                continue
            
            df['_source_file'] = path.name
            dfs.append(df)
            print(f"✅ 读取: {path.name} ({len(df)} 行)")
            
        except Exception as e:
            print(f"❌ 读取失败 {file_path}: {e}")
    
    if not dfs:
        print("❌ 没有成功读取任何文件")
        return
    
    # 合并数据
    if concat_axis == 'rows':
        merged = pd.concat(dfs, axis=0, join=join_type, ignore_index=ignore_index)
    else:
        merged = pd.concat(dfs, axis=1, join=join_type, ignore_index=ignore_index)
    
    # 保存结果
    output_path = Path(output_file)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    if output_path.suffix.lower() == '.csv':
        merged.to_csv(output_file, index=False, encoding='utf-8-sig')
    else:
        merged.to_excel(output_file, index=False, sheet_name=sheet_name or 'Merged')
    
    print(f"\n{'='*50}")
    print(f"✅ 合并完成!")
    print(f"   总行数: {len(merged)}")
    print(f"   总列数: {len(merged.columns)}")
    print(f"   输出文件: {output_file}")
    
    return merged


def merge_by_key(file_list, output_file, key_column, 
                 keep_strategy='first'):
    """
    按指定键合并多个文件
    
    Args:
        file_list: 文件路径列表
        output_file: 输出文件路径
        key_column: 作为键的列名
        keep_strategy: 'first'=保留第一个文件的值, 'last'=保留最后一个
    """
    dfs = {}
    
    for file_path in file_list:
        path = Path(file_path)
        if not path.exists():
            continue
        
        suffix = path.suffix.lower()
        
        if suffix == '.csv':
            df = pd.read_csv(file_path, encoding='utf-8-sig')
        else:
            df = pd.read_excel(file_path)
        
        if key_column not in df.columns:
            print(f"⚠️  文件 {path.name} 不包含键列 '{key_column}'")
            continue
        
        df['_source_file'] = path.name
        dfs[path.name] = df
        print(f"✅ 读取: {path.name} ({len(df)} 行)")
    
    if not dfs:
        print("❌ 没有找到有效文件")
        return
    
    # 以第一个文件为基准
    base_name = list(dfs.keys())[0]
    result = dfs[base_name]
    
    # 依次合并其他文件
    for name, df in list(dfs.items())[1:]:
        # 获取新增列
        common_cols = set(result.columns) & set(df.columns)
        common_cols.discard(key_column)
        new_cols = [c for c in df.columns if c not in result.columns]
        
        # 重命名新增列以区分来源
        rename_dict = {c: f"{c}_{name}" for c in new_cols if c != '_source_file'}
        
        # 合并
        result = result.merge(
            df[[key_column] + new_cols].rename(columns=rename_dict),
            on=key_column,
            how='outer'
        )
        print(f"   合并 {name}: +{len(new_cols)} 列")
    
    # 保存
    output_path = Path(output_file)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    if output_path.suffix.lower() == '.csv':
        result.to_csv(output_file, index=False, encoding='utf-8-sig')
    else:
        result.to_excel(output_file, index=False)
    
    print(f"\n{'='*50}")
    print(f"✅ 键合并完成!")
    print(f"   输出文件: {output_file}")
    
    return result


def main():
    parser = argparse.ArgumentParser(description='Excel/CSV数据合并工具')
    parser.add_argument('files', nargs='+', help='要合并的文件（支持通配符）')
    parser.add_argument('-o', '--output', required=True, help='输出文件路径')
    parser.add_argument('-s', '--sheet', help='指定读取的sheet名称')
    parser.add_argument('-m', '--mode', choices=['concat', 'key'], default='concat',
                       help='合并模式: concat=追加合并, key=按键合并')
    parser.add_argument('-k', '--key', help='键合并时的键列名')
    parser.add_argument('-a', '--axis', choices=['rows', 'columns'], default='rows',
                       help='合并方向: rows=纵向, columns=横向')
    
    args = parser.parse_args()
    
    # 展开通配符
    import glob
    file_list = []
    for pattern in args.files:
        file_list.extend(glob.glob(pattern))
    file_list = list(set(file_list))  # 去重
    
    if not file_list:
        print("❌ 未找到匹配的文件")
        return
    
    print(f"找到 {len(file_list)} 个文件:")
    for f in file_list:
        print(f"  - {f}")
    print()
    
    if args.mode == 'key' and args.key:
        merge_by_key(file_list, args.output, args.key)
    else:
        merge_excel_files(
            file_list, args.output,
            sheet_name=args.sheet,
            concat_axis=args.axis
        )


if __name__ == '__main__':
    main()
