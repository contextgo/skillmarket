#!/usr/bin/env python3
"""
Excel报表生成器
功能：自动生成格式化Excel报表，支持数据透视和图表
"""

import os
import argparse
from pathlib import Path
from datetime import datetime
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.chart import BarChart, LineChart, PieChart, Reference
from openpyxl.utils.dataframe import dataframe_to_rows
import pandas as pd


class ExcelReportGenerator:
    """Excel报表生成器"""
    
    def __init__(self, output_file):
        self.output_file = output_file
        self.wb = Workbook()
        self.styles = self._init_styles()
    
    def _init_styles(self):
        """初始化样式"""
        return {
            'header': {
                'font': Font(bold=True, color='FFFFFF', size=12),
                'fill': PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid'),
                'alignment': Alignment(horizontal='center', vertical='center'),
                'border': Border(
                    left=Side(style='thin'),
                    right=Side(style='thin'),
                    top=Side(style='thin'),
                    bottom=Side(style='thin')
                )
            },
            'subheader': {
                'font': Font(bold=True, size=11),
                'fill': PatternFill(start_color='D9E2F3', end_color='D9E2F3', fill_type='solid'),
                'alignment': Alignment(horizontal='left', vertical='center'),
                'border': Border(bottom=Side(style='thin'))
            },
            'data': {
                'alignment': Alignment(horizontal='left', vertical='center'),
                'border': Border(
                    left=Side(style='thin', color='E0E0E0'),
                    right=Side(style='thin', color='E0E0E0'),
                    bottom=Side(style='thin', color='E0E0E0')
                )
            },
            'number': {
                'alignment': Alignment(horizontal='right', vertical='center'),
                'border': Border(
                    left=Side(style='thin', color='E0E0E0'),
                    right=Side(style='thin', color='E0E0E0'),
                    bottom=Side(style='thin', color='E0E0E0')
                )
            },
            'title': {
                'font': Font(bold=True, size=16, color='333333'),
                'alignment': Alignment(horizontal='left', vertical='center')
            },
            'subtitle': {
                'font': Font(size=11, color='666666'),
                'alignment': Alignment(horizontal='left', vertical='center')
            }
        }
    
    def add_cover_sheet(self, title, subtitle='', author=''):
        """添加封面页"""
        ws = self.wb.active
        ws.title = '封面'
        ws.column_dimensions['A'].width = 30
        
        # 标题
        ws.merge_cells('A2:D2')
        ws['A2'] = title
        ws['A2'].font = Font(bold=True, size=24, color='2F5496')
        ws['A2'].alignment = Alignment(horizontal='center', vertical='center')
        ws.row_dimensions[2].height = 50
        
        # 副标题
        if subtitle:
            ws.merge_cells('A3:D3')
            ws['A3'] = subtitle
            ws['A3'].font = Font(size=14, color='666666')
            ws['A3'].alignment = Alignment(horizontal='center')
        
        # 信息
        ws['A5'] = '报表生成时间:'
        ws['B5'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        if author:
            ws['A6'] = '制表人:'
            ws['B6'] = author
        
        return ws
    
    def add_data_sheet(self, df, sheet_name, title='', freeze_panes='B2'):
        """添加数据表"""
        ws = self.wb.create_sheet(sheet_name)
        
        start_row = 1
        # 添加标题行
        if title:
            ws.merge_cells(start_row=start_row, start_column=1, 
                          end_row=start_row, end_column=len(df.columns))
            ws.cell(start_row, 1, title)
            ws.cell(start_row, 1).font = Font(bold=True, size=14)
            ws.cell(start_row, 1).alignment = Alignment(horizontal='left')
            start_row += 1
        
        # 写入表头
        for col, col_name in enumerate(df.columns, 1):
            cell = ws.cell(start_row, col, col_name)
            cell.font = self.styles['header']['font']
            cell.fill = self.styles['header']['fill']
            cell.alignment = self.styles['header']['alignment']
            cell.border = self.styles['header']['border']
        
        # 写入数据
        for row_idx, row_data in enumerate(df.values, start_row + 1):
            for col_idx, value in enumerate(row_data, 1):
                cell = ws.cell(row_idx, col_idx, value)
                cell.border = self.styles['data']['border']
                
                # 数字格式化
                if isinstance(value, (int, float)):
                    cell.number_format = '#,##0.00'
                    cell.alignment = self.styles['number']['alignment']
                else:
                    cell.alignment = self.styles['data']['alignment']
        
        # 设置列宽
        for col_idx, col_name in enumerate(df.columns, 1):
            col_letter = ws.cell(start_row, col_idx).column_letter
            ws.column_dimensions[col_letter].width = max(len(str(col_name)) + 4, 12)
        
        # 冻结窗格
        if freeze_panes:
            ws.freeze_panes = freeze_panes
        
        return ws
    
    def add_summary_sheet(self, summary_data, sheet_name='汇总'):
        """添加汇总表"""
        ws = self.wb.create_sheet(sheet_name)
        
        ws['A1'] = '数据汇总统计'
        ws['A1'].font = Font(bold=True, size=14)
        
        row = 3
        for label, value in summary_data.items():
            ws.cell(row, 1, label).font = Font(bold=True)
            ws.cell(row, 2, value)
            row += 1
        
        ws.column_dimensions['A'].width = 25
        ws.column_dimensions['B'].width = 20
        
        return ws
    
    def add_chart(self, sheet_name, chart_type, data_range, 
                  title='', position='E2', width=15, height=10):
        """添加图表"""
        ws = self.wb[sheet_name]
        
        if chart_type == 'bar':
            chart = BarChart()
        elif chart_type == 'line':
            chart = LineChart()
        elif chart_type == 'pie':
            chart = PieChart()
        else:
            raise ValueError(f'不支持的图表类型: {chart_type}')
        
        chart.title = title
        chart.width = width
        chart.height = height
        
        # 设置数据
        data = Reference(ws, range_string=data_range)
        chart.add_data(data, titles_from_data=True)
        
        # 放置位置
        ws.add_chart(chart, position)
        
        return chart
    
    def save(self):
        """保存文件"""
        self.wb.save(self.output_file)
        print(f'✅ 报表已生成: {self.output_file}')


def generate_report_from_csv(csv_file, output_file, title='',
                            generate_chart=True, chart_column=''):
    """从CSV文件生成报表"""
    # 读取数据
    df = pd.read_csv(csv_file, encoding='utf-8-sig')
    
    # 计算汇总数据
    summary = {
        '数据记录数': len(df),
        '数据列数': len(df.columns),
        '数值列数': len(df.select_dtypes(include=['number']).columns),
    }
    
    # 添加数值列统计
    for col in df.select_dtypes(include=['number']).columns:
        summary[f'{col} - 平均值'] = f"{df[col].mean():.2f}"
        summary[f'{col} - 最大值'] = f"{df[col].max():.2f}"
        summary[f'{col} - 最小值'] = f"{df[col].min():.2f}"
    
    # 创建报表
    generator = ExcelReportGenerator(output_file)
    
    # 添加封面
    generator.add_cover_sheet(
        title=title or Path(csv_file).stem,
        subtitle='数据报表自动生成'
    )
    
    # 添加汇总表
    generator.add_summary_sheet(summary)
    
    # 添加数据表
    sheet_name = Path(csv_file).stem[:31]  # Excel sheet名最长31字符
    generator.add_data_sheet(df, sheet_name)
    
    # 添加图表
    if generate_chart and chart_column and chart_column in df.columns:
        generator.add_chart(
            sheet_name,
            'bar',
            f'{sheet_name}!A1:B{len(df)+1}',
            title=f'{chart_column} 数据分布',
            position=f'D{len(df.columns)+2}'
        )
    
    # 保存
    generator.save()
    
    return df


def main():
    parser = argparse.ArgumentParser(description='Excel报表自动生成工具')
    parser.add_argument('input', help='输入CSV文件')
    parser.add_argument('-o', '--output', required=True, help='输出Excel文件')
    parser.add_argument('-t', '--title', help='报表标题')
    parser.add_argument('--no-chart', action='store_true', help='不生成图表')
    parser.add_argument('-c', '--chart-column', help='图表数据列')
    
    args = parser.parse_args()
    
    generate_report_from_csv(
        args.input,
        args.output,
        title=args.title,
        generate_chart=not args.no_chart,
        chart_column=args.chart_column
    )


if __name__ == '__main__':
    main()
