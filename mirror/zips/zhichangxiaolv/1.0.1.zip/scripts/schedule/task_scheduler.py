#!/usr/bin/env python3
"""
定时任务调度器
功能：定时执行脚本、循环任务、定时提醒
"""

import os
import sys
import time
import argparse
import schedule
from datetime import datetime, timedelta
from pathlib import Path
import subprocess


class TaskScheduler:
    """任务调度器"""
    
    def __init__(self):
        self.tasks = []
    
    def add_task(self, job_func, interval, interval_type='seconds', 
                 at_time=None, tag=None):
        """
        添加定时任务
        
        Args:
            job_func: 要执行的函数
            interval: 间隔数量
            interval_type: seconds/minutes/hours/days
            at_time: 定点执行时间 (HH:MM)
            tag: 任务标签
        """
        task = {
            'func': job_func,
            'interval': interval,
            'type': interval_type,
            'at_time': at_time,
            'tag': tag or str(len(self.tasks))
        }
        self.tasks.append(task)
        return task
    
    def run_once(self, task):
        """执行单次任务"""
        try:
            print(f"[{datetime.now().strftime('%H:%M:%S')}] 执行任务: {task['tag']}")
            task['func']()
            print(f"[{datetime.now().strftime('%H:%M:%S')}] 任务完成: {task['tag']}")
        except Exception as e:
            print(f"[{datetime.now().strftime('%H:%M:%S')}] 任务失败: {e}")
    
    def run_continuously(self, check_interval=1):
        """持续运行调度器"""
        print(f"🚀 调度器启动，等待 {len(self.tasks)} 个任务...")
        print("按 Ctrl+C 停止\n")
        
        last_run = {i: None for i in range(len(self.tasks))}
        
        while True:
            now = datetime.now()
            current_time = now.strftime('%H:%M')
            
            for i, task in enumerate(self.tasks):
                interval = task['interval']
                task_type = task['type']
                
                # 检查是否到达执行时间
                should_run = False
                
                if task['at_time'] and current_time == task['at_time']:
                    if last_run.get(i) != current_time:
                        should_run = True
                        last_run[i] = current_time
                else:
                    # 间隔执行
                    if last_run[i] is None:
                        last_run[i] = now
                    else:
                        elapsed = (now - last_run[i]).total_seconds()
                        
                        if task_type == 'seconds':
                            threshold = interval
                        elif task_type == 'minutes':
                            threshold = interval * 60
                        elif task_type == 'hours':
                            threshold = interval * 3600
                        elif task_type == 'days':
                            threshold = interval * 86400
                        else:
                            threshold = interval
                        
                        if elapsed >= threshold:
                            should_run = True
                            last_run[i] = now
                
                if should_run:
                    self.run_once(task)
            
            time.sleep(check_interval)


# 预定义任务函数
def backup_folder(source, destination):
    """备份文件夹"""
    import shutil
    from pathlib import Path
    
    source_path = Path(source)
    dest_path = Path(destination)
    
    if not source_path.exists():
        print(f"⚠️  源目录不存在: {source}")
        return
    
    # 创建带时间戳的备份目录
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    backup_path = dest_path / f"backup_{timestamp}"
    
    shutil.copytree(source_path, backup_path)
    print(f"✅ 备份完成: {backup_path}")


def clean_old_files(folder, days=7, extensions=None):
    """清理旧文件"""
    from pathlib import Path
    
    folder_path = Path(folder)
    if not folder_path.exists():
        return
    
    cutoff = datetime.now() - timedelta(days=days)
    removed = 0
    
    for file_path in folder_path.rglob('*'):
        if not file_path.is_file():
            continue
        
        if extensions and file_path.suffix not in extensions:
            continue
        
        mtime = datetime.fromtimestamp(file_path.stat().st_mtime)
        if mtime < cutoff:
            file_path.unlink()
            removed += 1
    
    print(f"🗑️  清理完成: 删除 {removed} 个文件")


def run_script(script_path):
    """执行Python脚本"""
    result = subprocess.run(
        [sys.executable, script_path],
        capture_output=True,
        text=True
    )
    if result.returncode == 0:
        print(f"✅ 脚本执行成功: {script_path}")
    else:
        print(f"❌ 脚本执行失败: {script_path}")
        print(result.stderr)


def send_reminder(message, repeat=1):
    """发送提醒"""
    print(f"\n📌 提醒 ({datetime.now().strftime('%H:%M')}): {message}\n")


def website_monitor(url, keyword, check_interval=60):
    """监控网站变化"""
    import requests
    
    try:
        response = requests.get(url, timeout=10)
        content = response.text
        
        if keyword in content:
            print(f"🔔 发现关键词 '{keyword}' 在 {url}")
            return True
        else:
            print(f"👁️  未发现变化，继续监控...")
            return False
    except Exception as e:
        print(f"⚠️  请求失败: {e}")
        return False


# CLI 接口
def main():
    parser = argparse.ArgumentParser(description='定时任务调度器')
    parser.add_argument('command', choices=['run', 'backup', 'clean', 'monitor'],
                       help='操作命令')
    parser.add_argument('--interval', type=int, default=1, help='执行间隔')
    parser.add_argument('--unit', default='hours', 
                       choices=['seconds', 'minutes', 'hours', 'days'],
                       help='时间单位')
    parser.add_argument('--at', help='定点执行时间 (HH:MM)')
    parser.add_argument('--tag', help='任务标签')
    
    # 任务特定参数
    parser.add_argument('--source', help='源路径')
    parser.add_argument('--dest', help='目标路径')
    parser.add_argument('--folder', help='文件夹路径')
    parser.add_argument('--days', type=int, default=7, help='天数')
    parser.add_argument('--ext', nargs='+', help='文件扩展名')
    parser.add_argument('--url', help='网站URL')
    parser.add_argument('--keyword', help='监控关键词')
    parser.add_argument('--message', help='提醒消息')
    parser.add_argument('--script', help='脚本路径')
    
    args = parser.parse_args()
    
    scheduler = TaskScheduler()
    
    if args.command == 'run':
        if args.script:
            task_func = lambda: run_script(args.script)
        elif args.message:
            task_func = lambda: send_reminder(args.message)
        else:
            print("❌ 需要指定 --script 或 --message")
            return
        
        scheduler.add_task(task_func, args.interval, args.unit, args.at, args.tag)
    
    elif args.command == 'backup':
        if not args.source or not args.dest:
            print("❌ 需要指定 --source 和 --dest")
            return
        task_func = lambda: backup_folder(args.source, args.dest)
        scheduler.add_task(task_func, args.interval, args.unit, args.at, args.tag or 'backup')
    
    elif args.command == 'clean':
        if not args.folder:
            print("❌ 需要指定 --folder")
            return
        task_func = lambda: clean_old_files(args.folder, args.days, args.ext)
        scheduler.add_task(task_func, args.interval, args.unit, args.at, args.tag or 'clean')
    
    elif args.command == 'monitor':
        if not args.url or not args.keyword:
            print("❌ 需要指定 --url 和 --keyword")
            return
        task_func = lambda: website_monitor(args.url, args.keyword)
        scheduler.add_task(task_func, args.interval, args.unit, args.at, args.tag or 'monitor')
    
    scheduler.run_continuously()


if __name__ == '__main__':
    main()
