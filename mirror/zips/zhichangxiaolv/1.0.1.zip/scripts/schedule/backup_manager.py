#!/usr/bin/env python3
"""
数据备份工具
功能：自动备份文件、数据库、同步到云端
"""

import os
import shutil
import hashlib
import argparse
import json
from pathlib import Path
from datetime import datetime
import tarfile
import zipfile


class BackupManager:
    """备份管理器"""
    
    def __init__(self, backup_root='backups'):
        self.backup_root = Path(backup_root)
        self.backup_root.mkdir(parents=True, exist_ok=True)
        self.db_file = self.backup_root / 'backup_history.json'
        self.history = self._load_history()
    
    def _load_history(self):
        """加载备份历史"""
        if self.db_file.exists():
            with open(self.db_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {'backups': [], 'last_backup': None}
    
    def _save_history(self):
        """保存备份历史"""
        with open(self.db_file, 'w', encoding='utf-8') as f:
            json.dump(self.history, f, ensure_ascii=False, indent=2)
    
    def backup_files(self, source, name=None, compression='gzip',
                    exclude=None, include_hidden=False):
        """
        备份文件/文件夹
        
        Args:
            source: 源路径
            name: 备份名称
            compression: 压缩方式 gzip/zip/none
            exclude: 排除模式列表
            include_hidden: 是否包含隐藏文件
        """
        source_path = Path(source)
        if not source_path.exists():
            print(f"❌ 源路径不存在: {source}")
            return None
        
        name = name or source_path.name
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_name = f"{name}_{timestamp}"
        
        # 创建备份目录
        backup_dir = self.backup_root / backup_name
        backup_dir.mkdir(parents=True, exist_ok=True)
        
        # 复制文件
        files_copied = 0
        total_size = 0
        exclude_patterns = exclude or []
        
        for item in source_path.rglob('*'):
            if not item.is_file():
                continue
            
            # 检查隐藏文件
            if not include_hidden and any(part.startswith('.') for part in item.parts):
                continue
            
            # 检查排除模式
            if any(item.match(pattern) for pattern in exclude_patterns):
                continue
            
            # 复制文件
            relative_path = item.relative_to(source_path)
            dest_path = backup_dir / relative_path
            dest_path.parent.mkdir(parents=True, exist_ok=True)
            
            shutil.copy2(item, dest_path)
            
            file_size = item.stat().st_size
            total_size += file_size
            files_copied += 1
        
        # 打包
        archive_path = self.backup_root / backup_name
        
        if compression == 'gzip':
            archive_path = self.backup_root / f"{backup_name}.tar.gz"
            with tarfile.open(archive_path, 'w:gz') as tar:
                tar.add(backup_dir, arcname=name)
            shutil.rmtree(backup_dir)
        
        elif compression == 'zip':
            archive_path = self.backup_root / f"{backup_name}.zip"
            with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED) as zf:
                for item in backup_dir.rglob('*'):
                    if item.is_file():
                        zf.write(item, item.relative_to(backup_dir))
            shutil.rmtree(backup_dir)
        
        # 计算哈希
        file_hash = self._calculate_hash(archive_path)
        
        # 记录历史
        backup_record = {
            'name': name,
            'timestamp': timestamp,
            'archive': str(archive_path),
            'size': total_size,
            'files': files_copied,
            'hash': file_hash,
            'type': 'files'
        }
        
        self.history['backups'].append(backup_record)
        self.history['last_backup'] = timestamp
        self._save_history()
        
        print(f"✅ 备份完成: {archive_path.name}")
        print(f"   文件数: {files_copied}")
        print(f"   总大小: {total_size / 1024 / 1024:.2f} MB")
        print(f"   哈希值: {file_hash[:16]}...")
        
        return archive_path
    
    def backup_database(self, db_path, db_type='mysql', output_dir=None):
        """备份数据库（需要对应工具）"""
        import subprocess
        
        output_dir = Path(output_dir) if output_dir else self.backup_root
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        
        if db_type == 'mysql':
            # 需要配置MySQL连接信息
            output_file = output_dir / f"mysql_backup_{timestamp}.sql"
            
            # 示例：使用mysqldump
            # subprocess.run([
            #     'mysqldump', '-u', 'user', '-p', 'database',
            #     '>', str(output_file)
            # ])
            print(f"⚠️ MySQL备份需要配置数据库连接信息")
        
        elif db_type == 'postgresql':
            output_file = output_dir / f"postgres_backup_{timestamp}.sql"
            # 使用pg_dump
        
        elif db_type == 'sqlite':
            output_file = output_dir / f"sqlite_backup_{timestamp}.db"
            shutil.copy2(db_path, output_file)
            print(f"✅ SQLite备份完成: {output_file}")
        
        return output_file
    
    def restore_backup(self, backup_file, restore_path):
        """恢复备份"""
        backup_path = Path(backup_file)
        
        if not backup_path.exists():
            print(f"❌ 备份文件不存在: {backup_file}")
            return False
        
        restore_path = Path(restore_path)
        restore_path.mkdir(parents=True, exist_ok=True)
        
        if backup_path.suffix == '.zip':
            with zipfile.ZipFile(backup_path, 'r') as zf:
                zf.extractall(restore_path)
        elif backup_path.suffix == '.gz' and '.tar' in backup_path.name:
            with tarfile.open(backup_path, 'r:gz') as tar:
                tar.extractall(restore_path)
        else:
            print(f"❌ 不支持的压缩格式")
            return False
        
        print(f"✅ 恢复完成: {restore_path}")
        return True
    
    def cleanup_old_backups(self, keep_days=30, keep_count=None):
        """清理旧备份"""
        cutoff_date = datetime.now() - timedelta(days=keep_days)
        
        removed = 0
        remaining = []
        
        for record in self.history['backups']:
            backup_date = datetime.strptime(record['timestamp'], '%Y%m%d_%H%M%S')
            
            if backup_date < cutoff_date:
                # 删除文件
                backup_file = Path(record['archive'])
                if backup_file.exists():
                    backup_file.unlink()
                removed += 1
            else:
                remaining.append(record)
        
        # 限制保留数量
        if keep_count and len(remaining) > keep_count:
            removed += len(remaining) - keep_count
            remaining = remaining[-keep_count:]
        
        self.history['backups'] = remaining
        self._save_history()
        
        print(f"🗑️  清理完成: 删除 {removed} 个旧备份")
        print(f"   保留 {len(remaining)} 个备份")
    
    def list_backups(self):
        """列出所有备份"""
        print("\n📦 备份列表")
        print("="*70)
        print(f"{'名称':<20} {'时间':<20} {'大小':<12} {'文件数':<8}")
        print("-"*70)
        
        for record in reversed(self.history['backups'][-20:]):
            size_mb = record['size'] / 1024 / 1024 if record['size'] else 0
            print(f"{record['name']:<20} {record['timestamp']:<20} {size_mb:>8.2f} MB {record.get('files', '-'):>6}")
        
        print("="*70)
        print(f"总计: {len(self.history['backups'])} 个备份")
    
    def _calculate_hash(self, file_path, algorithm='md5'):
        """计算文件哈希"""
        hasher = hashlib.new(algorithm)
        
        with open(file_path, 'rb') as f:
            for chunk in iter(lambda: f.read(4096), b''):
                hasher.update(chunk)
        
        return hasher.hexdigest()


def incremental_backup(source, backup_root, name='backup'):
    """增量备份（基于rsync风格）"""
    source_path = Path(source)
    backup_path = Path(backup_root) / name
    backup_path.mkdir(parents=True, exist_ok=True)
    
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    current_backup = backup_path / 'current'
    new_backup = backup_path / timestamp
    
    # 如果存在当前备份，使用硬链接创建增量
    if current_backup.exists():
        import subprocess
        
        # 使用rsync进行增量同步
        # 这里简化为复制
        shutil.copytree(str(current_backup), str(new_backup), dirs_exist_ok=True)
    else:
        shutil.copytree(str(source_path), str(new_backup))
    
    # 更新当前备份链接
    if current_backup.exists():
        shutil.rmtree(current_backup)
    shutil.copytree(str(new_backup), str(current_backup))
    
    print(f"✅ 增量备份完成: {new_backup}")


def main():
    parser = argparse.ArgumentParser(description='数据备份工具')
    parser.add_argument('command', 
                       choices=['backup', 'restore', 'list', 'cleanup'],
                       help='操作命令')
    parser.add_argument('-s', '--source', help='源路径')
    parser.add_argument('-o', '--output', help='输出路径')
    parser.add_argument('-n', '--name', help='备份名称')
    parser.add_argument('-c', '--compression', default='gzip',
                       choices=['gzip', 'zip', 'none'], help='压缩方式')
    parser.add_argument('--keep-days', type=int, default=30, help='保留天数')
    parser.add_argument('--keep-count', type=int, help='保留数量')
    parser.add_argument('--root', default='backups', help='备份根目录')
    
    args = parser.parse_args()
    
    manager = BackupManager(args.root)
    
    if args.command == 'backup':
        if not args.source:
            print("❌ 需要指定源路径: -s")
            return
        manager.backup_files(args.source, args.name, args.compression)
    
    elif args.command == 'restore':
        if not args.source or not args.output:
            print("❌ 需要指定备份文件和恢复路径: -s, -o")
            return
        manager.restore_backup(args.source, args.output)
    
    elif args.command == 'list':
        manager.list_backups()
    
    elif args.command == 'cleanup':
        manager.cleanup_old_backups(args.keep_days, args.keep_count)


if __name__ == '__main__':
    main()
