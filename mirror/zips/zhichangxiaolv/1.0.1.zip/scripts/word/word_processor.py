#!/usr/bin/env python3
"""
Word文档批量处理工具
功能：批量转换、模板填充、内容替换、格式调整
"""

import os
import argparse
from pathlib import Path
from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE
import re


def convert_docx_to_pdf(input_file, output_dir=None):
    """Word转PDF（需要docx2pdf库）"""
    try:
        from docx2pdf import convert
    except ImportError:
        print("❌ 请先安装: pip install docx2pdf")
        return False
    
    input_path = Path(input_file)
    output_dir = Path(output_dir) if output_dir else input_path.parent
    output_dir.mkdir(parents=True, exist_ok=True)
    
    output_file = output_dir / f"{input_path.stem}.pdf"
    
    convert(str(input_path), str(output_file))
    print(f"✅ 转换完成: {output_file}")
    return True


def batch_convert_docx(folder, output_dir=None, target_format='pdf'):
    """批量转换Word文档"""
    folder = Path(folder)
    output_dir = Path(output_dir) if output_dir else folder / f'converted_{target_format}'
    output_dir.mkdir(parents=True, exist_ok=True)
    
    docx_files = list(folder.glob('*.docx')) + list(folder.glob('*.doc'))
    
    if not docx_files:
        print("❌ 未找到Word文档")
        return
    
    print(f"找到 {len(docx_files)} 个Word文档")
    
    success = 0
    for docx_file in docx_files:
        try:
            if target_format == 'pdf':
                convert_docx_to_pdf(docx_file, output_dir)
                success += 1
            else:
                print(f"⚠️  不支持的格式: {target_format}")
        except Exception as e:
            print(f"❌ 转换失败 {docx_file.name}: {e}")
    
    print(f"\n完成: {success}/{len(docx_files)} 个文件")


def fill_template(template_file, output_file, replacements):
    """
    填充Word模板
    replacements: dict，如 {'{姓名}': '张三', '{日期}': '2024-01-01'}
    """
    doc = Document(template_file)
    
    # 替换段落中的文本
    for paragraph in doc.paragraphs:
        for old_text, new_text in replacements.items():
            if old_text in paragraph.text:
                paragraph.text = paragraph.text.replace(old_text, new_text)
    
    # 替换表格中的文本
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                for old_text, new_text in replacements.items():
                    if old_text in cell.text:
                        cell.text = cell.text.replace(old_text, new_text)
    
    doc.save(output_file)
    print(f"✅ 模板填充完成: {output_file}")


def batch_replace(file_or_folder, search_text, replace_text, 
                  case_sensitive=False, use_regex=False):
    """批量文本替换"""
    folder = Path(file_or_folder)
    
    if folder.is_file():
        files = [folder]
    else:
        files = list(folder.glob('*.docx'))
    
    total = 0
    for file_path in files:
        doc = Document(file_path)
        count = 0
        
        # 替换段落
        for para in doc.paragraphs:
            if use_regex:
                if re.sub(search_text, replace_text, para.text) != para.text:
                    para.text = re.sub(search_text, replace_text, para.text)
                    count += 1
            else:
                if case_sensitive:
                    if search_text in para.text:
                        para.text = para.text.replace(search_text, replace_text)
                        count += 1
                else:
                    import re
                    pattern = re.compile(re.escape(search_text), re.IGNORECASE)
                    if pattern.search(para.text):
                        para.text = pattern.sub(replace_text, para.text)
                        count += 1
        
        # 替换表格
        for table in doc.tables:
            for row in table.rows:
                for cell in row.cells:
                    if use_regex:
                        if re.sub(search_text, replace_text, cell.text) != cell.text:
                            cell.text = re.sub(search_text, replace_text, cell.text)
                            count += 1
                    else:
                        if case_sensitive:
                            if search_text in cell.text:
                                cell.text = cell.text.replace(search_text, replace_text)
                                count += 1
                        else:
                            pattern = re.compile(re.escape(search_text), re.IGNORECASE)
                            if pattern.search(cell.text):
                                cell.text = pattern.sub(replace_text, cell.text)
                                count += 1
        
        if count > 0:
            doc.save(file_path)
            print(f"✅ {file_path.name}: 替换 {count} 处")
            total += count
    
    print(f"\n总计替换: {total} 处")


def extract_text(input_file, output_file=None):
    """提取Word文档文本"""
    doc = Document(input_file)
    texts = []
    
    for para in doc.paragraphs:
        if para.text.strip():
            texts.append(para.text)
    
    # 提取表格文本
    for i, table in enumerate(doc.tables, 1):
        texts.append(f"\n[表格 {i}]")
        for row in table.rows:
            row_text = ' | '.join(cell.text.strip() for cell in row.cells if cell.text.strip())
            if row_text:
                texts.append(row_text)
    
    content = '\n'.join(texts)
    
    if output_file:
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"✅ 文本已提取: {output_file}")
    else:
        print(content)
    
    return content


def add_watermark(docx_file, output_file, text='CONFIDENTIAL'):
    """添加水印"""
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement
    
    doc = Document(docx_file)
    
    # 添加水印到所有section
    for section in doc.sections:
        header = section.header
        header.is_linked_to_previous = False
        paragraph = header.paragraphs[0]
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        run = paragraph.add_run()
        run.text = text
        
        # 设置水印样式
        run.font.size = Pt(60)
        run.font.color.rgb = RGBColor(220, 220, 220)
        run.font.italic = True
    
    doc.save(output_file)
    print(f"✅ 水印已添加: {output_file}")


def main():
    parser = argparse.ArgumentParser(description='Word文档批量处理工具')
    parser.add_argument('command', 
                       choices=['convert', 'fill', 'replace', 'extract', 'watermark'],
                       help='操作命令')
    parser.add_argument('input', help='输入文件或文件夹')
    parser.add_argument('-o', '--output', help='输出文件或文件夹')
    parser.add_argument('-t', '--text', help='要替换/填充的文本')
    parser.add_argument('-r', '--replace', help='替换为')
    parser.add_argument('-c', '--case-sensitive', action='store_true', help='区分大小写')
    parser.add_argument('--regex', action='store_true', help='使用正则表达式')
    
    args = parser.parse_args()
    
    if args.command == 'convert':
        batch_convert_docx(args.input, args.output)
    
    elif args.command == 'fill':
        # 解析替换对
        replacements = {}
        if args.text:
            for pair in args.text.split(','):
                if '=' in pair:
                    key, value = pair.split('=', 1)
                    replacements[key.strip()] = value.strip()
        fill_template(args.input, args.output or 'output.docx', replacements)
    
    elif args.command == 'replace':
        if not args.text or not args.replace:
            print("❌ 需要指定 -t 和 -r 参数")
            return
        batch_replace(args.input, args.text, args.replace,
                     case_sensitive=args.caseSensitive,
                     use_regex=args.regex)
    
    elif args.command == 'extract':
        extract_text(args.input, args.output)
    
    elif args.command == 'watermark':
        add_watermark(args.input, args.output or 'output.docx', 
                     text=args.text or 'CONFIDENTIAL')


if __name__ == '__main__':
    main()
