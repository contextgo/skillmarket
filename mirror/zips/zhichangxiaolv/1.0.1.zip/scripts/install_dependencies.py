#!/usr/bin/env python3
"""
依赖安装脚本
自动安装职场效率大师所需的所有依赖
"""

import subprocess
import sys


def install_package(package):
    """安装单个包"""
    print(f"📦 安装 {package}...")
    try:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', package, '-q'])
        print(f"   ✅ {package} 安装成功")
        return True
    except Exception as e:
        print(f"   ❌ {package} 安装失败: {e}")
        return False


def main():
    print("🚀 职场效率大师 - 依赖安装\n")
    
    # 基础依赖
    basic_packages = [
        'pandas',
        'openpyxl',
        'python-docx',
        'PyPDF2',
    ]
    
    # 增强依赖
    extra_packages = [
        'Pillow',           # 图片处理
        'qrcode',           # 二维码生成
        'requests',         # HTTP请求
        'beautifulsoup4',    # 网页解析
    ]
    
    # 可选依赖
    optional_packages = [
        'speech-recognition',  # 语音转文字
        'pytesseract',         # OCR识别
        'schedule',            # 定时任务
    ]
    
    print("="*50)
    print("安装基础依赖...")
    print("="*50)
    
    for pkg in basic_packages:
        install_package(pkg)
    
    print("\n" + "="*50)
    print("安装增强依赖...")
    print("="*50)
    
    for pkg in extra_packages:
        install_package(pkg)
    
    print("\n" + "="*50)
    print("安装可选依赖...")
    print("="*50)
    
    for pkg in optional_packages:
        install_package(pkg)
    
    print("\n" + "="*50)
    print("✅ 依赖安装完成!")
    print("="*50)
    print("\n提示：")
    print("- 如需OCR功能，请自行安装Tesseract OCR引擎")
    print("- 如需Word转PDF，请安装docx2pdf: pip install docx2pdf")


if __name__ == '__main__':
    main()
