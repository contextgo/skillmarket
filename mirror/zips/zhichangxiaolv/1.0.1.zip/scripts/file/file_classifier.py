#!/usr/bin/env python3
"""
文件分类整理工具
功能：将文件夹中的文件按类型、日期、大小等规则自动分类整理
"""

import os
import shutil
import argparse
from pathlib import Path
from collections import defaultdict
from datetime import datetime


# 文件类型映射
FILE_TYPE_MAP = {
    'images': ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.svg', '.webp', '.ico', '.tiff'],
    'documents': ['.doc', '.docx', '.pdf', '.txt', '.rtf', '.odt', '.xlsx', '.xls', '.csv', '.pptx', '.ppt'],
    'archives': ['.zip', '.rar', '.7z', '.tar', '.gz', '.bz2', '.xz'],
    'videos': ['.mp4', '.avi', '.mkv', '.mov', '.wmv', '.flv', '.webm'],
    'audio': ['.mp3', '.wav', '.flac', '.aac', '.ogg', '.wma', '.m4a'],
    'code': ['.py', '.js', '.html', '.css', '.java', '.cpp', '.c', '.h', '.php', '.rb', '.go', '.rs'],
    'data': ['.json', '.xml', '.yaml', '.yml', '.sql', '.db', '.sqlite'],
    'executables': ['.exe', '.msi', '.dmg', '.app', '.deb', '.rpm'],
}


def classify_by_type(source_dir, dest_dir=None, create_subdirs=True, move=False):
    """按文件类型分类"""
    source = Path(source_dir)
    dest = Path(dest_dir) if dest_dir else source / 'classified'
    dest.mkdir(parents=True, exist_ok=True)
    
    stats = defaultdict(list)
    
    for file_path in source.iterdir():
        if not file_path.is_file():
            continue
        
        ext = file_path.suffix.lower()
        category = 'others'
        
        for cat, extensions in FILE_TYPE_MAP.items():
            if ext in extensions:
                category = cat
                break
        
        # 创建分类目录
        if create_subdirs:
            target_dir = dest / category
        else:
            target_dir = dest
        target_dir.mkdir(exist_ok=True)
        
        # 移动或复制文件
        target_path = target_dir / file_path.name
        if move:
            shutil.move(str(file_path), str(target_path))
        else:
            shutil.copy2(str(file_path), str(target_path))
        
        stats[category].append(file_path.name)
    
    return dict(stats)


def classify_by_date(source_dir, dest_dir=None, date_format='%Y-%m'):
    """按修改日期分类"""
    source = Path(source_dir)
    dest = Path(dest_dir) if dest_dir else source / 'by_date'
    dest.mkdir(parents=True, exist_ok=True)
    
    stats = defaultdict(list)
    
    for file_path in source.iterdir():
        if not file_path.is_file():
            continue
        
        mtime = datetime.fromtimestamp(file_path.stat().st_mtime)
        date_folder = mtime.strftime(date_format)
        
        target_dir = dest / date_folder
        target_dir.mkdir(parents=True, exist_ok=True)
        
        target_path = target_dir / file_path.name
        shutil.copy2(str(file_path), str(target_path))
        
        stats[date_folder].append(file_path.name)
    
    return dict(stats)


def classify_by_size(source_dir, dest_dir=None, 
                     small='<1MB', medium='1MB-10MB', large='>10MB'):
    """按文件大小分类"""
    source = Path(source_dir)
    dest = Path(dest_dir) if dest_dir else source / 'by_size'
    dest.mkdir(parents=True, exist_ok=True)
    
    # 解析大小阈值
    def parse_size(size_str):
        size_str = size_str.upper().strip()
        if size_str.startswith('<'):
            return 0, parse_value(size_str[1:])
        elif size_str.startswith('>'):
            return parse_value(size_str[1:]), float('inf')
        elif '-' in size_str:
            parts = size_str.split('-')
            return parse_value(parts[0]), parse_value(parts[1])
        return 0, float('inf')
    
    def parse_value(s):
        s = s.upper().strip()
        multipliers = {'B': 1, 'KB': 1024, 'MB': 1024**2, 'GB': 1024**3}
        for unit, mult in multipliers.items():
            if s.endswith(unit):
                return float(s[:-len(unit)]) * mult
        return float(s)
    
    small_range = parse_size(small)
    medium_range = parse_size(medium)
    large_range = parse_size(large)
    
    stats = {'small': [], 'medium': [], 'large': [], 'others': []}
    
    for file_path in source.iterdir():
        if not file_path.is_file():
            continue
        
        size = file_path.stat().st_size
        category = 'others'
        
        if small_range[0] <= size < small_range[1]:
            category = 'small'
        elif medium_range[0] <= size < medium_range[1]:
            category = 'medium'
        elif size >= large_range[0]:
            category = 'large'
        
        target_dir = dest / category
        target_dir.mkdir(exist_ok=True)
        
        target_path = target_dir / file_path.name
        shutil.copy2(str(file_path), str(target_path))
        
        stats[category].append(f"{file_path.name} ({size/1024:.1f}KB)")
    
    return stats


def remove_duplicates(directory, delete=True):
    """查找并删除重复文件（基于MD5）"""
    import hashlib
    
    directory = Path(directory)
    hash_dict = defaultdict(list)
    
    print("正在计算文件哈希...")
    
    for file_path in directory.rglob('*'):
        if not file_path.is_file():
            continue
        
        try:
            with open(file_path, 'rb') as f:
                file_hash = hashlib.md5(f.read()).hexdigest()
                hash_dict[file_hash].append(file_path)
        except:
            pass
    
    duplicates = {k: v for k, v in hash_dict.items() if len(v) > 1}
    
    if duplicates:
        print(f"\n发现 {len(duplicates)} 组重复文件：")
        for i, (hash_val, files) in enumerate(duplicates.items(), 1):
            print(f"\n第{i}组（{len(files)}个相同）:")
            for f in files:
                print(f"  - {f}")
            
            if delete:
                # 保留第一个，删除其余
                for f in files[1:]:
                    f.unlink()
                    print(f"  已删除: {f.name}")
    else:
        print("未发现重复文件")
    
    return duplicates


def main():
    parser = argparse.ArgumentParser(description='文件分类整理工具')
    parser.add_argument('command', choices=['type', 'date', 'size', 'dedup'],
                       help='分类方式: type=按类型, date=按日期, size=按大小, dedup=去重')
    parser.add_argument('directory', help='源目录')
    parser.add_argument('-o', '--output', help='输出目录（可选）')
    parser.add_argument('--move', action='store_true', help='移动文件（默认复制）')
    parser.add_argument('--dry-run', action='store_true', help='预览模式')
    
    args = parser.parse_args()
    
    if args.dry_run:
        print("🔍 预览模式：仅显示分类结果，不执行实际操作")
    
    if args.command == 'type':
        result = classify_by_type(args.directory, args.output, move=args.move)
    elif args.command == 'date':
        result = classify_by_date(args.directory, args.output)
    elif args.command == 'size':
        result = classify_by_size(args.directory, args.output)
    elif args.command == 'dedup':
        result = remove_duplicates(args.directory, delete=not args.dry_run)
        return
    
    print("\n分类结果：")
    for category, files in result.items():
        print(f"\n📁 {category}: {len(files)} 个文件")


if __name__ == '__main__':
    main()
