#!/usr/bin/env python3
"""
批量文件重命名工具
功能：按指定规则批量重命名文件，支持添加前缀、后缀、序号、时间戳
"""

import os
import re
import argparse
from datetime import datetime
from pathlib import Path


def batch_rename_by_pattern(folder_path, prefix='', suffix='', 
                            pattern=None, replacement='', 
                            add_index=False, index_start=1,
                            add_date=False, dry_run=True):
    """
    批量重命名文件
    
    Args:
        folder_path: 文件夹路径
        prefix: 文件名前缀
        suffix: 文件名后缀（不含扩展名）
        pattern: 匹配模式（正则）
        replacement: 替换内容
        add_index: 是否添加序号
        index_start: 序号起始值
        add_date: 是否添加日期
        dry_run: True=预览模式，False=执行重命名
    """
    folder = Path(folder_path)
    if not folder.exists():
        print(f"错误：文件夹不存在 - {folder_path}")
        return
    
    renamed_files = []
    index = index_start
    
    for file_path in sorted(folder.iterdir()):
        if not file_path.is_file():
            continue
        
        original_name = file_path.stem  # 不含扩展名的文件名
        extension = file_path.suffix     # 扩展名
        
        # 构建新文件名
        new_name = original_name
        
        # 应用正则替换
        if pattern:
            new_name = re.sub(pattern, replacement, new_name)
        
        # 添加前缀
        if prefix:
            new_name = prefix + new_name
        
        # 添加后缀
        if suffix:
            new_name = new_name + suffix
        
        # 添加序号
        if add_index:
            new_name = f"{new_name}_{index:03d}"
            index += 1
        
        # 添加日期
        if add_date:
            date_str = datetime.now().strftime('%Y%m%d')
            new_name = f"{new_name}_{date_str}"
        
        new_filename = new_name + extension
        new_path = folder / new_filename
        
        action = "[预览]" if dry_run else "[重命名]"
        print(f"{action} {original_name}{extension} -> {new_filename}")
        renamed_files.append((file_path, new_path))
    
    # 执行重命名
    if not dry_run:
        for old_path, new_path in renamed_files:
            if old_path != new_path:
                # 处理文件名冲突
                counter = 1
                while new_path.exists():
                    stem = Path(new_path).stem
                    ext = Path(new_path).suffix
                    new_path = new_path.parent / f"{stem}_{counter}{ext}"
                    counter += 1
                old_path.rename(new_path)
        print(f"\n✅ 完成！共重命名 {len(renamed_files)} 个文件")
    else:
        print(f"\n📋 预览模式：共 {len(renamed_files)} 个文件待重命名")
        print("   添加 -f 参数执行实际重命名")


def main():
    parser = argparse.ArgumentParser(description='批量文件重命名工具')
    parser.add_argument('folder', help='目标文件夹路径')
    parser.add_argument('-p', '--prefix', default='', help='文件名前缀')
    parser.add_argument('-s', '--suffix', default='', help='文件名后缀')
    parser.add_argument('--pattern', default='', help='正则匹配模式')
    parser.add_argument('--replacement', default='', help='替换内容')
    parser.add_argument('-i', '--add-index', action='store_true', help='添加序号')
    parser.add_argument('--index-start', type=int, default=1, help='序号起始值')
    parser.add_argument('-d', '--add-date', action='store_true', help='添加日期')
    parser.add_argument('-f', '--force', action='store_true', help='执行重命名（默认预览模式）')
    
    args = parser.parse_args()
    
    batch_rename_by_pattern(
        args.folder,
        prefix=args.prefix,
        suffix=args.suffix,
        pattern=args.pattern if args.pattern else None,
        replacement=args.replacement,
        add_index=args.add_index,
        index_start=args.index_start,
        add_date=args.add_date,
        dry_run=not args.force
    )


if __name__ == '__main__':
    main()
