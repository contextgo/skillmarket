#!/usr/bin/env python3
"""
文件搜索器
功能：在目录中搜索包含指定关键词的文件
"""

import os
import argparse
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed


def search_in_files(directory, keyword, extensions=None, 
                    case_sensitive=False, recursive=True):
    """
    搜索包含关键词的文件
    
    Args:
        directory: 搜索目录
        keyword: 搜索关键词
        extensions: 限定文件类型，如 ['.txt', '.py']
        case_sensitive: 是否区分大小写
        recursive: 是否递归搜索子目录
    """
    directory = Path(directory)
    if not directory.exists():
        print(f"错误：目录不存在 - {directory}")
        return []
    
    results = []
    keyword_lower = keyword if case_sensitive else keyword.lower()
    
    # 确定搜索范围
    if recursive:
        all_files = directory.rglob('*')
    else:
        all_files = directory.glob('*')
    
    files_to_search = [f for f in all_files if f.is_file()]
    
    # 过滤扩展名
    if extensions:
        extensions = [ext.lower() for ext in extensions]
        files_to_search = [
            f for f in files_to_search 
            if f.suffix.lower() in extensions
        ]
    
    print(f"正在搜索 {len(files_to_search)} 个文件...")
    
    def check_file(file_path):
        matches = []
        try:
            # 跳过二进制文件
            if is_binary(file_path):
                return matches
            
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                for line_num, line in enumerate(f, 1):
                    content = line if case_sensitive else line.lower()
                    if keyword_lower in content:
                        matches.append((line_num, line.strip()))
        except Exception as e:
            pass
        return matches
    
    # 使用线程池加速搜索
    with ThreadPoolExecutor(max_workers=10) as executor:
        futures = {executor.submit(check_file, f): f for f in files_to_search}
        
        for future in as_completed(futures):
            file_path = futures[future]
            matches = future.result()
            
            if matches:
                relative_path = file_path.relative_to(directory)
                print(f"\n📄 {relative_path}")
                for line_num, line_content in matches[:5]:  # 最多显示5行
                    print(f"   第{line_num}行: {line_content[:100]}")
                results.append({
                    'file': str(relative_path),
                    'matches': matches
                })
    
    print(f"\n{'='*50}")
    print(f"✅ 搜索完成：找到 {len(results)} 个匹配文件")
    return results


def is_binary(file_path, block_size=1024):
    """判断文件是否为二进制文件"""
    try:
        with open(file_path, 'rb') as f:
            block = f.read(block_size)
            if b'\x00' in block:
                return True
            # 检查不可打印字符的比例
            text_chars = bytearray({7, 8, 9, 10, 12, 13, 27} | 
                                   set(range(0x20, 0x100)) - {0x7f})
            non_text = len([b for b in block if b not in text_chars])
            return non_text / len(block) > 0.3 if block else False
    except:
        return True


def main():
    parser = argparse.ArgumentParser(description='文件内容搜索工具')
    parser.add_argument('directory', help='搜索目录')
    parser.add_argument('keyword', help='搜索关键词')
    parser.add_argument('-e', '--extensions', nargs='+', help='限定文件类型')
    parser.add_argument('-c', '--case-sensitive', action='store_true', help='区分大小写')
    parser.add_argument('-n', '--no-recursive', action='store_true', help='不搜索子目录')
    
    args = parser.parse_args()
    
    search_in_files(
        args.directory,
        args.keyword,
        extensions=args.extensions,
        case_sensitive=args.case_sensitive,
        recursive=not args.no_recursive
    )


if __name__ == '__main__':
    main()
