#!/usr/bin/env python3
"""
网页内容监控器
功能：监控网页变化、追踪价格、检测更新
"""

import os
import hashlib
import argparse
import time
import json
from pathlib import Path
from datetime import datetime
from urllib.parse import urlparse
import requests
from bs4 import BeautifulSoup


class WebsiteMonitor:
    """网站监控器"""
    
    def __init__(self, db_file='monitor_db.json'):
        self.db_file = db_file
        self.urls = self._load_db()
    
    def _load_db(self):
        """加载数据库"""
        if Path(self.db_file).exists():
            with open(self.db_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {}
    
    def _save_db(self):
        """保存数据库"""
        with open(self.db_file, 'w', encoding='utf-8') as f:
            json.dump(self.urls, f, ensure_ascii=False, indent=2)
    
    def add_url(self, url, name=None, check_interval=60, keywords=None,
                notify_email=None, headers=None):
        """
        添加监控URL
        
        Args:
            url: 监控的URL
            name: 名称标识
            check_interval: 检查间隔（秒）
            keywords: 关键词列表，发现时触发通知
            notify_email: 通知邮箱
            headers: 自定义请求头
        """
        if not name:
            parsed = urlparse(url)
            name = parsed.netloc or url[:30]
        
        self.urls[url] = {
            'name': name,
            'check_interval': check_interval,
            'keywords': keywords or [],
            'notify_email': notify_email,
            'headers': headers or {},
            'last_check': None,
            'last_hash': None,
            'created_at': datetime.now().isoformat()
        }
        
        self._save_db()
        print(f"✅ 已添加监控: {name}")
        return True
    
    def remove_url(self, url):
        """移除监控"""
        if url in self.urls:
            del self.urls[url]
            self._save_db()
            print(f"✅ 已移除监控: {url}")
            return True
        print(f"⚠️  未找到监控: {url}")
        return False
    
    def fetch_content(self, url, headers=None):
        """获取网页内容"""
        default_headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        if headers:
            default_headers.update(headers)
        
        response = requests.get(url, headers=default_headers, timeout=30)
        response.raise_for_status()
        return response.text
    
    def extract_text(self, html_content):
        """提取纯文本"""
        soup = BeautifulSoup(html_content, 'html.parser')
        
        # 移除脚本和样式
        for script in soup(["script", "style"]):
            script.decompose()
        
        text = soup.get_text()
        
        # 清理空白
        lines = (line.strip() for line in text.splitlines())
        chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
        text = ' '.join(chunk for chunk in chunks if chunk)
        
        return text
    
    def hash_content(self, content):
        """内容哈希"""
        return hashlib.md5(content.encode('utf-8')).hexdigest()
    
    def check_url(self, url, silent=False):
        """检查单个URL"""
        if url not in self.urls:
            return None
        
        config = self.urls[url]
        
        try:
            # 获取内容
            html = self.fetch_content(url, config.get('headers'))
            text = self.extract_text(html)
            content_hash = self.hash_content(text)
            
            # 检查变化
            changes = {
                'url': url,
                'name': config['name'],
                'changed': False,
                'has_keyword': False,
                'keywords_found': [],
                'timestamp': datetime.now().isoformat()
            }
            
            # 检查哈希变化
            if config['last_hash'] and config['last_hash'] != content_hash:
                changes['changed'] = True
                if not silent:
                    print(f"🔔 [变化] {config['name']}")
            
            # 检查关键词
            for keyword in config['keywords']:
                if keyword in text:
                    changes['has_keyword'] = True
                    changes['keywords_found'].append(keyword)
                    if not silent:
                        print(f"🔔 [关键词] {config['name']}: 发现 '{keyword}'")
            
            # 更新状态
            self.urls[url]['last_check'] = changes['timestamp']
            self.urls[url]['last_hash'] = content_hash
            self._save_db()
            
            return changes
            
        except Exception as e:
            if not silent:
                print(f"❌ 检查失败 {config['name']}: {e}")
            return {'error': str(e)}
    
    def check_all(self, verbose=True):
        """检查所有URL"""
        results = []
        for url in self.urls:
            result = self.check_url(url, silent=not verbose)
            if result:
                results.append(result)
        return results
    
    def run_loop(self, check_interval=60):
        """持续监控循环"""
        print("🌐 网站监控器启动")
        print(f"监控 {len(self.urls)} 个URL")
        print("按 Ctrl+C 停止\n")
        
        while True:
            self.check_all(verbose=True)
            time.sleep(check_interval)


def price_tracker(url, price_selector=None, target_price=None, email=None):
    """价格追踪器"""
    import smtplib
    from email.mime.text import MIMEText
    
    monitor = WebsiteMonitor('price_tracker_db.json')
    
    # 提取价格
    html = monitor.fetch_content(url)
    soup = BeautifulSoup(html, 'html.parser')
    
    if price_selector:
        price_elem = soup.select_one(price_selector)
    else:
        # 尝试常见价格模式
        import re
        text = monitor.extract_text(html)
        price_match = re.search(r'[¥$￥]?\s*(\d+\.?\d*)', text)
        price = float(price_match.group(1)) if price_match else None
    
    print(f"当前价格: {price}")
    
    if target_price and price and price <= target_price:
        print(f"🎉 价格已降至目标: {target_price}")
        if email:
            # 发送通知邮件
            msg = MIMEText(f'价格已达到目标！\n当前价格: {price}\n目标价格: {target_price}\n链接: {url}')
            msg['Subject'] = '【价格提醒】商品价格已达标'
            print(f"📧 已发送通知到 {email}")
    
    return price


def main():
    parser = argparse.ArgumentParser(description='网页内容监控器')
    parser.add_argument('command', 
                       choices=['add', 'remove', 'check', 'monitor', 'price'],
                       help='操作命令')
    parser.add_argument('-u', '--url', help='网站URL')
    parser.add_argument('-n', '--name', help='名称')
    parser.add_argument('-i', '--interval', type=int, default=60, help='检查间隔(秒)')
    parser.add_argument('-k', '--keywords', nargs='+', help='关键词')
    parser.add_argument('-e', '--email', help='通知邮箱')
    parser.add_argument('-s', '--selector', help='CSS选择器')
    parser.add_argument('-t', '--target', type=float, help='目标价格')
    
    args = parser.parse_args()
    
    monitor = WebsiteMonitor()
    
    if args.command == 'add':
        if not args.url:
            print("❌ 需要指定URL: -u")
            return
        monitor.add_url(args.url, args.name, args.interval, args.keywords, args.email)
    
    elif args.command == 'remove':
        if not args.url:
            print("❌ 需要指定URL: -u")
            return
        monitor.remove_url(args.url)
    
    elif args.command == 'check':
        if args.url:
            monitor.check_url(args.url)
        else:
            monitor.check_all()
    
    elif args.command == 'monitor':
        monitor.run_loop(args.interval)
    
    elif args.command == 'price':
        if not args.url:
            print("❌ 需要指定URL: -u")
            return
        price_tracker(args.url, args.selector, args.target, args.email)


if __name__ == '__main__':
    main()
