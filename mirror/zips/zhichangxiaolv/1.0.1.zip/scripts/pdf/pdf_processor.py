#!/usr/bin/env python3
"""
PDF处理工具集
功能：合并、分割、提取页面、添加水印、提取文本
"""

import os
import argparse
from pathlib import Path
from PyPDF2 import PdfMerger, PdfReader, PdfWriter
from PyPDF2.generic import AnnotationBuilder
import datetime


def merge_pdfs(input_files, output_file):
    """合并多个PDF文件"""
    merger = PdfMerger()
    
    for pdf_file in input_files:
        if not Path(pdf_file).exists():
            print(f"⚠️  文件不存在，跳过: {pdf_file}")
            continue
        merger.append(pdf_file)
        print(f"✅ 添加: {Path(pdf_file).name}")
    
    output_path = Path(output_file)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    merger.write(output_file)
    merger.close()
    
    print(f"\n✅ 合并完成: {output_file}")
    print(f"   共 {len(input_files)} 个文件")


def split_pdf(input_file, output_dir=None, pages_per_file=1, 
              ranges=None):
    """
    分割PDF
    
    Args:
        input_file: 输入文件
        output_dir: 输出目录
        pages_per_file: 每个文件多少页
        ranges: 页面范围，如 '1-3,5,7-9'
    """
    input_path = Path(input_file)
    output_dir = Path(output_dir) if output_dir else input_path.parent / 'split'
    output_dir.mkdir(parents=True, exist_ok=True)
    
    reader = PdfReader(input_file)
    total_pages = len(reader.pages)
    
    print(f"输入文件: {input_path.name} ({total_pages} 页)")
    
    if ranges:
        # 按范围分割
        page_groups = parse_page_ranges(ranges, total_pages)
        for i, group in enumerate(page_groups, 1):
            writer = PdfWriter()
            for page_num in group:
                writer.add_page(reader.pages[page_num - 1])
            
            output_file = output_dir / f"{input_path.stem}_part{i}.pdf"
            with open(output_file, 'wb') as f:
                writer.write(f)
            print(f"✅ 第{i}部分: {output_file.name} ({len(group)}页)")
    
    else:
        # 按固定页数分割
        page_num = 0
        part_num = 1
        writer = PdfWriter()
        
        for page in reader.pages:
            writer.add_page(page)
            page_num += 1
            
            if page_num >= pages_per_file:
                output_file = output_dir / f"{input_path.stem}_part{part_num}.pdf"
                with open(output_file, 'wb') as f:
                    writer.write(f)
                print(f"✅ 第{part_num}部分: {output_file.name} ({pages_per_file}页)")
                
                writer = PdfWriter()
                page_num = 0
                part_num += 1
        
        # 保存剩余页面
        if page_num > 0:
            output_file = output_dir / f"{input_path.stem}_part{part_num}.pdf"
            with open(output_file, 'wb') as f:
                writer.write(f)
            print(f"✅ 第{part_num}部分: {output_file.name} ({page_num}页)")
    
    print(f"\n输出目录: {output_dir}")


def parse_page_ranges(ranges_str, max_pages):
    """解析页面范围字符串"""
    groups = []
    for part in ranges_str.split(','):
        part = part.strip()
        if '-' in part:
            start, end = part.split('-')
            pages = list(range(int(start), int(end) + 1))
            pages = [p for p in pages if 1 <= p <= max_pages]
            if pages:
                groups.append(pages)
        else:
            page = int(part)
            if 1 <= page <= max_pages:
                groups.append([page])
    return groups


def extract_pages(input_file, pages, output_file=None):
    """提取指定页面"""
    input_path = Path(input_file)
    reader = PdfReader(input_file)
    writer = PdfWriter()
    
    all_pages = list(range(len(reader.pages)))
    pages_to_extract = parse_page_ranges(pages, len(reader.pages))[0]
    
    for page_num in pages_to_extract:
        writer.add_page(reader.pages[page_num - 1])
    
    output_file = output_file or input_path.parent / f"{input_path.stem}_extracted.pdf"
    
    with open(output_file, 'wb') as f:
        writer.write(f)
    
    print(f"✅ 提取完成: {output_file} ({len(pages_to_extract)}页)")


def extract_text(input_file, output_file=None, start_page=1, end_page=None):
    """提取PDF文本"""
    input_path = Path(input_file)
    reader = PdfReader(input_file)
    
    end_page = end_page or len(reader.pages)
    
    texts = []
    for i in range(start_page - 1, min(end_page, len(reader.pages))):
        page = reader.pages[i]
        text = page.extract_text()
        if text:
            texts.append(f"[第{i+1}页]\n{text}")
    
    content = '\n\n'.join(texts)
    
    if output_file:
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"✅ 文本已提取: {output_file}")
    else:
        print(content)
    
    return content


def add_watermark(input_file, output_file, text='CONFIDENTIAL', 
                 opacity=0.3, angle=45):
    """添加文字水印"""
    from PyPDF2 import PdfReader, PdfWriter
    from PyPDF2.generic import (
        NameObject, DictionaryObject, ArrayObject, 
        NumberObject, FloatObject
    )
    
    input_path = Path(input_file)
    reader = PdfReader(input_path)
    writer = PdfWriter()
    
    for page in reader.pages:
        # 创建水印
        writer.add_annotation(
            page=writer.pages[reader.pages.index(page)] if writer.pages else page,
            annotation=AnnotationBuilder.text_annotation(
                text=text,
                rect=(100, 100, 500, 500),
            )
        )
    
    output_file = output_file or input_path.parent / f"{input_path.stem}_watermarked.pdf"
    
    with open(output_file, 'wb') as f:
        writer.write(f)
    
    print(f"✅ 水印已添加: {output_file}")


def rotate_pdf(input_file, output_file=None, degrees=90):
    """旋转PDF页面"""
    input_path = Path(input_file)
    reader = PdfReader(input_path)
    writer = PdfWriter()
    
    for page in reader.pages:
        page.rotate(degrees)
        writer.add_page(page)
    
    output_file = output_file or input_path.parent / f"{input_path.stem}_rotated.pdf"
    
    with open(output_file, 'wb') as f:
        writer.write(f)
    
    print(f"✅ 旋转完成: {output_file} ({degrees}°)")


def encrypt_pdf(input_file, output_file=None, password=''):
    """加密PDF"""
    input_path = Path(input_file)
    reader = PdfReader(input_path)
    writer = PdfWriter()
    
    for page in reader.pages:
        writer.add_page(page)
    
    writer.encrypt(password if password else input_path.stem)
    
    output_file = output_file or input_path.parent / f"{input_path.stem}_encrypted.pdf"
    
    with open(output_file, 'wb') as f:
        writer.write(f)
    
    print(f"✅ 加密完成: {output_file}")


def decrypt_pdf(input_file, output_file, password):
    """解密PDF"""
    input_path = Path(input_file)
    reader = PdfReader(input_path)
    
    if not reader.is_encrypted:
        print("⚠️  文件未加密")
        return
    
    reader.decrypt(password)
    writer = PdfWriter()
    
    for page in reader.pages:
        writer.add_page(page)
    
    with open(output_file, 'wb') as f:
        writer.write(f)
    
    print(f"✅ 解密完成: {output_file}")


def main():
    parser = argparse.ArgumentParser(description='PDF处理工具集')
    parser.add_argument('command', 
                       choices=['merge', 'split', 'extract', 'text', 
                               'watermark', 'rotate', 'encrypt', 'decrypt'],
                       help='操作命令')
    parser.add_argument('input', help='输入文件')
    parser.add_argument('-o', '--output', help='输出文件')
    parser.add_argument('-p', '--pages', help='页面范围 (如: 1-3,5,7-9)')
    parser.add_argument('-n', '--number', type=int, default=1, help='每份页数')
    parser.add_argument('-t', '--text', help='水印文本')
    parser.add_argument('-d', '--degrees', type=int, default=90, help='旋转角度')
    parser.add_argument('-pw', '--password', help='密码')
    
    args = parser.parse_args()
    
    if args.command == 'merge':
        import glob
        files = glob.glob(args.input)
        merge_pdfs(files, args.output or 'merged.pdf')
    
    elif args.command == 'split':
        split_pdf(args.input, args.output, 
                  pages_per_file=args.number,
                  ranges=args.pages)
    
    elif args.command == 'extract':
        extract_pages(args.input, args.pages, args.output)
    
    elif args.command == 'text':
        extract_text(args.input, args.output)
    
    elif args.command == 'watermark':
        add_watermark(args.input, args.output, text=args.text)
    
    elif args.command == 'rotate':
        rotate_pdf(args.input, args.output, args.degrees)
    
    elif args.command == 'encrypt':
        encrypt_pdf(args.input, args.output, args.password)
    
    elif args.command == 'decrypt':
        if not args.password:
            print("❌ 需要提供密码: -pw")
            return
        decrypt_pdf(args.input, args.output, args.password)


if __name__ == '__main__':
    main()
