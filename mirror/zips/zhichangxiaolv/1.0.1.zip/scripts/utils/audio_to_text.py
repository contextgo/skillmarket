#!/usr/bin/env python3
"""
语音转文字工具
功能：将音频文件转换为文字，支持多种格式
"""

import os
import argparse
import speech_recognition as sr
from pathlib import Path


def audio_to_text(audio_file, output_file=None, language='zh-CN'):
    """
    音频转文字
    
    Args:
        audio_file: 音频文件路径
        output_file: 输出文件路径
        language: 识别语言
    """
    recognizer = sr.Recognizer()
    
    # 确定文件格式并使用合适的读取方法
    suffix = Path(audio_file).suffix.lower()
    
    if suffix == '.wav':
        with sr.AudioFile(audio_file) as source:
            print("正在读取音频...")
            audio_data = recognizer.record(source)
    else:
        # 转换为wav
        print(f"正在转换音频格式...")
        import subprocess
        import tempfile
        
        temp_wav = tempfile.NamedTemporaryFile(suffix='.wav', delete=False).name
        
        # 使用ffmpeg转换
        try:
            subprocess.run([
                'ffmpeg', '-i', audio_file,
                '-acodec', 'pcm_s16le',
                '-ar', '16000',
                '-ac', '1',
                temp_wav,
                '-y'
            ], capture_output=True)
            
            with sr.AudioFile(temp_wav) as source:
                print("正在读取音频...")
                audio_data = recognizer.record(source)
            
            os.unlink(temp_wav)
        except Exception as e:
            print(f"❌ 音频转换失败: {e}")
            return None
    
    # 识别
    print("正在识别...")
    try:
        # 使用Google API
        text = recognizer.recognize_google(audio_data, language=language)
        print(f"\n✅ 识别完成！\n")
        print("="*50)
        print(text)
        print("="*50)
        
        # 保存到文件
        if output_file:
            output_path = Path(output_file)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(text)
            print(f"\n📄 已保存至: {output_file}")
        
        return text
        
    except sr.UnknownValueError:
        print("❌ 无法识别音频内容")
    except sr.RequestError as e:
        print(f"❌ 请求服务失败: {e}")
    
    return None


def batch_audio_to_text(folder, output_dir, language='zh-CN'):
    """批量处理音频文件夹"""
    folder = Path(folder)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    audio_files = []
    for ext in ['.wav', '.mp3', '.m4a', '.flac', '.ogg']:
        audio_files.extend(folder.glob(f'*{ext}'))
    
    print(f"找到 {len(audio_files)} 个音频文件\n")
    
    results = []
    for i, audio_file in enumerate(audio_files, 1):
        print(f"[{i}/{len(audio_files)}] 处理: {audio_file.name}")
        
        output_file = output_dir / f"{audio_file.stem}.txt"
        text = audio_to_text(str(audio_file), str(output_file), language)
        
        results.append({
            'file': audio_file.name,
            'success': text is not None,
            'output': str(output_file)
        })
    
    # 生成汇总
    success_count = sum(1 for r in results if r['success'])
    print(f"\n{'='*50}")
    print(f"批量处理完成: {success_count}/{len(results)} 成功")
    
    return results


def main():
    parser = argparse.ArgumentParser(description='语音转文字工具')
    parser.add_argument('input', help='音频文件或文件夹')
    parser.add_argument('-o', '--output', help='输出文件')
    parser.add_argument('-l', '--language', default='zh-CN', help='识别语言')
    parser.add_argument('--batch', action='store_true', help='批量处理文件夹')
    parser.add_argument('--output-dir', default='transcripts', help='批量输出目录')
    
    args = parser.parse_args()
    
    if args.batch:
        batch_audio_to_text(args.input, args.output_dir, args.language)
    else:
        audio_to_text(args.input, args.output, args.language)


if __name__ == '__main__':
    main()
