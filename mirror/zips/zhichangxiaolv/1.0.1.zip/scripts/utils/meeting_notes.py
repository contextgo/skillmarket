#!/usr/bin/env python3
"""
会议纪要生成器
功能：从会议录音自动生成结构化会议纪要
"""

import os
import argparse
from pathlib import Path
from datetime import datetime
from collections import defaultdict


class MeetingNotesGenerator:
    """会议纪要生成器"""
    
    def __init__(self, meeting_title="", date=None, participants=None):
        self.meeting_title = meeting_title
        self.date = date or datetime.now().strftime('%Y-%m-%d')
        self.participants = participants or []
        self.agenda = []
        self.discussions = []
        self.decisions = []
        self.action_items = []
        self.notes = []
    
    def add_discussion(self, topic, content):
        """添加讨论内容"""
        self.discussions.append({
            'topic': topic,
            'content': content,
            'timestamp': datetime.now().strftime('%H:%M')
        })
    
    def add_decision(self, decision, owner=None):
        """添加决议"""
        self.decisions.append({
            'decision': decision,
            'owner': owner,
            'timestamp': datetime.now().strftime('%H:%M')
        })
    
    def add_action_item(self, task, owner, deadline=None, priority='中'):
        """添加待办事项"""
        self.action_items.append({
            'task': task,
            'owner': owner,
            'deadline': deadline,
            'priority': priority,
            'status': '待完成'
        })
    
    def generate_markdown(self):
        """生成Markdown格式纪要"""
        lines = []
        
        # 标题
        lines.append(f"# {self.meeting_title or '会议纪要'}")
        lines.append("")
        
        # 基本信息
        lines.append("## 📋 基本信息")
        lines.append(f"- **会议日期**: {self.date}")
        lines.append(f"- **参会人员**: {', '.join(self.participants) if self.participants else '未记录'}")
        lines.append(f"- **记录时间**: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
        lines.append("")
        
        # 议程
        if self.agenda:
            lines.append("## 📌 会议议程")
            for i, item in enumerate(self.agenda, 1):
                lines.append(f"{i}. {item}")
            lines.append("")
        
        # 讨论内容
        if self.discussions:
            lines.append("## 💬 讨论内容")
            for d in self.discussions:
                lines.append(f"### {d['topic']}")
                lines.append(f"_{d['timestamp']}_")
                lines.append(d['content'])
                lines.append("")
        
        # 决议
        if self.decisions:
            lines.append("## ✅ 会议决议")
            for i, decision in enumerate(self.decisions, 1):
                lines.append(f"{i}. {decision['decision']}")
                if decision['owner']:
                    lines.append(f"   - 负责人: {decision['owner']}")
            lines.append("")
        
        # 待办事项
        if self.action_items:
            lines.append("## 📝 待办事项")
            lines.append("| 序号 | 任务 | 负责人 | 截止日期 | 优先级 | 状态 |")
            lines.append("|------|------|--------|----------|--------|------|")
            for i, item in enumerate(self.action_items, 1):
                lines.append(f"| {i} | {item['task']} | {item['owner']} | {item['deadline'] or '-'} | {item['priority']} | {item['status']} |")
            lines.append("")
        
        # 备注
        if self.notes:
            lines.append("## 📎 备注")
            for note in self.notes:
                lines.append(f"- {note}")
        
        return '\n'.join(lines)
    
    def generate_docx(self, output_file):
        """生成Word文档"""
        from docx import Document
        from docx.shared import Pt
        
        doc = Document()
        
        # 标题
        title = doc.add_heading(self.meeting_title or '会议纪要', 0)
        
        # 基本信息
        doc.add_heading('基本信息', level=1)
        info_table = doc.add_table(rows=3, cols=2)
        info_table.cell(0, 0).text = '会议日期'
        info_table.cell(0, 1).text = self.date
        info_table.cell(1, 0).text = '参会人员'
        info_table.cell(1, 1).text = ', '.join(self.participants) if self.participants else '未记录'
        info_table.cell(2, 0).text = '记录时间'
        info_table.cell(2, 1).text = datetime.now().strftime('%Y-%m-%d %H:%M')
        
        # 决议
        if self.decisions:
            doc.add_heading('会议决议', level=1)
            for i, decision in enumerate(self.decisions, 1):
                p = doc.add_paragraph()
                p.add_run(f'{i}. {decision["decision"]}').bold = True
                if decision['owner']:
                    p.add_run(f'\n负责人: {decision["owner"]}')
        
        # 待办事项
        if self.action_items:
            doc.add_heading('待办事项', level=1)
            table = doc.add_table(rows=len(self.action_items) + 1, cols=5)
            table.style = 'Light Grid Accent 1'
            
            # 表头
            headers = ['任务', '负责人', '截止日期', '优先级', '状态']
            for i, header in enumerate(headers):
                table.cell(0, i).text = header
            
            # 数据
            for row_idx, item in enumerate(self.action_items, 1):
                table.cell(row_idx, 0).text = item['task']
                table.cell(row_idx, 1).text = item['owner']
                table.cell(row_idx, 2).text = item['deadline'] or '-'
                table.cell(row_idx, 3).text = item['priority']
                table.cell(row_idx, 4).text = item['status']
        
        doc.save(output_file)
        print(f"✅ 会议纪要已生成: {output_file}")


def create_template():
    """创建会议纪要模板"""
    template = """# 会议纪要模板

## 📋 基本信息
- **会议日期**: YYYY-MM-DD
- **参会人员**: 姓名1, 姓名2, ...
- **会议地点**: 
- **会议时间**: HH:MM - HH:MM
- **主持人**: 
- **记录人**: 

## 📌 会议议程
1. 
2. 
3. 

## 💬 讨论内容

### 议题1: 
**讨论要点**:


**结论**:

### 议题2:
**讨论要点**:


**结论**:

## ✅ 会议决议
1. 
2. 
3. 

## 📝 待办事项
| 序号 | 任务 | 负责人 | 截止日期 | 优先级 | 状态 |
|------|------|--------|----------|--------|------|
| 1 |  |  |  |  | 待完成 |
| 2 |  |  |  |  | 待完成 |

## 📎 下次会议安排
- 时间: 
- 地点: 
- 议题: 

## 📎 备注
- 
"""
    return template


def main():
    parser = argparse.ArgumentParser(description='会议纪要生成工具')
    parser.add_argument('command', choices=['generate', 'template'])
    parser.add_argument('-o', '--output', help='输出文件')
    parser.add_argument('-t', '--title', default='周例会纪要', help='会议标题')
    parser.add_argument('-d', '--date', help='会议日期')
    parser.add_argument('-p', '--participants', nargs='+', help='参会人员')
    parser.add_argument('--format', choices=['md', 'docx'], default='md', help='输出格式')
    
    args = parser.parse_args()
    
    if args.command == 'template':
        print(create_template())
        if args.output:
            with open(args.output, 'w', encoding='utf-8') as f:
                f.write(create_template())
            print(f"✅ 模板已保存: {args.output}")
    
    elif args.command == 'generate':
        generator = MeetingNotesGenerator(
            meeting_title=args.title,
            date=args.date,
            participants=args.participants
        )
        
        # 这里可以添加自动填充逻辑
        # 或者从录音转文字的结果导入
        
        if args.format == 'md':
            output = args.output or 'meeting_notes.md'
            content = generator.generate_markdown()
            with open(output, 'w', encoding='utf-8') as f:
                f.write(content)
            print(f"✅ 会议纪要已生成: {output}")
        else:
            output = args.output or 'meeting_notes.docx'
            generator.generate_docx(output)


if __name__ == '__main__':
    main()
