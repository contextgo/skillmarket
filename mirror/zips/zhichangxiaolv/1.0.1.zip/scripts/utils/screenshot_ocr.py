#!/usr/bin/env python3
"""
截图OCR识别工具
功能：截取屏幕指定区域并识别文字
"""

import os
import sys
import argparse
import base64
import subprocess
from pathlib import Path
from datetime import datetime


def capture_screen(region=None):
    """
    截取屏幕
    
    Args:
        region: (x, y, width, height) 截取区域
    """
    try:
        from PIL import Image, ImageGrab
    except ImportError:
        print("❌ 需要安装Pillow: pip install pillow")
        return None
    
    if region:
        screenshot = ImageGrab.grab(bbox=region)
    else:
        screenshot = ImageGrab.grab()
    
    return screenshot


def ocr_image(image_path, language='chi_sim+eng'):
    """
    OCR识别图片文字
    
    Args:
        image_path: 图片路径或PIL Image对象
        language: 识别语言
    """
    try:
        import pytesseract
    except ImportError:
        print("❌ 需要安装pytesseract和tesseract")
        print("   安装指南: https://github.com/tesseract-ocr/tesseract")
        return None
    
    if isinstance(image_path, str):
        from PIL import Image
        img = Image.open(image_path)
    else:
        img = image_path
    
    # 配置语言
    config = f'--oem 3 --psm 6 -l {language}'
    
    # 识别
    text = pytesseract.image_to_string(img, config=config)
    
    return text.strip()


def save_screenshot(output_dir='screenshots'):
    """保存截图"""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = f"screenshot_{timestamp}.png"
    filepath = output_dir / filename
    
    screenshot = capture_screen()
    screenshot.save(filepath)
    
    print(f"✅ 截图已保存: {filepath}")
    return str(filepath)


def quick_ocr():
    """快捷OCR：截图->识别->复制"""
    print("📸 请在3秒后选择截取区域...")
    import time
    time.sleep(3)
    
    screenshot = capture_screen()
    
    print("🔍 正在识别文字...")
    text = ocr_image(screenshot)
    
    if text:
        print("\n识别结果:")
        print("="*50)
        print(text)
        print("="*50)
        
        # 复制到剪贴板
        try:
            import pyperclip
            pyperclip.copy(text)
            print("✅ 已复制到剪贴板")
        except:
            print("⚠️ 复制到剪贴板失败，请手动复制")
    else:
        print("❌ 未识别到文字")


def batch_ocr(input_dir, output_dir='ocr_results'):
    """批量OCR处理文件夹中的图片"""
    input_path = Path(input_dir)
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)
    
    image_files = []
    for ext in ['.png', '.jpg', '.jpeg', '.bmp', '.gif']:
        image_files.extend(input_path.glob(f'*{ext}'))
    
    print(f"找到 {len(image_files)} 张图片\n")
    
    results = []
    for i, img_file in enumerate(image_files, 1):
        print(f"[{i}/{len(image_files)}] 处理: {img_file.name}")
        
        try:
            text = ocr_image(str(img_file))
            
            if text:
                # 保存识别结果
                output_file = output_path / f"{img_file.stem}.txt"
                with open(output_file, 'w', encoding='utf-8') as f:
                    f.write(text)
                
                results.append({
                    'file': img_file.name,
                    'success': True,
                    'output': str(output_file),
                    'length': len(text)
                })
                print(f"   ✅ 识别成功 ({len(text)} 字符)")
            else:
                print(f"   ⚠️ 未识别到文字")
                results.append({
                    'file': img_file.name,
                    'success': False
                })
        except Exception as e:
            print(f"   ❌ 处理失败: {e}")
            results.append({
                'file': img_file.name,
                'success': False,
                'error': str(e)
            })
    
    # 汇总
    success_count = sum(1 for r in results if r['success'])
    print(f"\n{'='*50}")
    print(f"批量处理完成: {success_count}/{len(results)} 成功")


def main():
    parser = argparse.ArgumentParser(description='截图OCR识别工具')
    parser.add_argument('command', 
                       choices=['capture', 'ocr', 'quick', 'batch'],
                       help='操作命令')
    parser.add_argument('-i', '--input', help='输入图片路径')
    parser.add_argument('-o', '--output', help='输出文件')
    parser.add_argument('-l', '--language', default='chi_sim+eng', 
                       help='识别语言 (chi_sim=简体中文, eng=英文)')
    parser.add_argument('--dir', default='screenshots', help='截图保存目录')
    
    args = parser.parse_args()
    
    if args.command == 'capture':
        filepath = save_screenshot(args.dir)
        if args.output:
            print(f"📍 截图路径: {filepath}")
    
    elif args.command == 'ocr':
        if not args.input:
            print("❌ 需要指定图片路径: -i")
            return
        
        print(f"🔍 正在识别: {args.input}")
        text = ocr_image(args.input, args.language)
        
        if text:
            print("\n识别结果:")
            print("="*50)
            print(text)
            print("="*50)
            
            if args.output:
                with open(args.output, 'w', encoding='utf-8') as f:
                    f.write(text)
                print(f"\n✅ 已保存至: {args.output}")
        else:
            print("❌ 未识别到文字")
    
    elif args.command == 'quick':
        quick_ocr()
    
    elif args.command == 'batch':
        if not args.input:
            print("❌ 需要指定图片目录: -i")
            return
        batch_ocr(args.input, args.output or 'ocr_results')


if __name__ == '__main__':
    main()
