#!/usr/bin/env python3
"""
周报/月报自动生成器
功能：从工作记录自动生成格式化报告
"""

import os
import argparse
import json
from pathlib import Path
from datetime import datetime, timedelta


class WeeklyReportGenerator:
    """周报生成器"""
    
    def __init__(self, name, week_start=None):
        self.name = name
        self.week_start = week_start or self._get_week_start()
        self.week_end = self.week_start + timedelta(days=6)
        self.tasks_completed = []
        self.tasks_in_progress = []
        self.problems = []
        self.next_week_plans = []
        self.metrics = {}
    
    def _get_week_start(self):
        """获取本周起始日期（周一）"""
        today = datetime.now()
        return today - timedelta(days=today.weekday())
    
    def add_completed_task(self, task, description='', hours=None):
        """添加已完成任务"""
        self.tasks_completed.append({
            'task': task,
            'description': description,
            'hours': hours
        })
    
    def add_in_progress_task(self, task, progress, blocker=''):
        """添加进行中任务"""
        self.tasks_in_progress.append({
            'task': task,
            'progress': progress,
            'blocker': blocker
        })
    
    def add_problem(self, problem, impact='', solution=''):
        """添加问题"""
        self.problems.append({
            'problem': problem,
            'impact': impact,
            'solution': solution
        })
    
    def add_next_plan(self, task, deadline=None, priority='中'):
        """添加下周计划"""
        self.next_week_plans.append({
            'task': task,
            'deadline': deadline,
            'priority': priority
        })
    
    def set_metric(self, key, value, unit=''):
        """设置指标"""
        self.metrics[key] = {'value': value, 'unit': unit}
    
    def generate_markdown(self):
        """生成Markdown格式周报"""
        lines = []
        
        # 标题
        week_str = f"{self.week_start.strftime('%Y-%m-%d')} ~ {self.week_end.strftime('%Y-%m-%d')}"
        lines.append(f"# 📊 {self.name} - 工作周报")
        lines.append(f"**周报周期**: {week_str}")
        lines.append("")
        
        # 本周完成工作
        lines.append("## ✅ 本周完成工作")
        if self.tasks_completed:
            for i, task in enumerate(self.tasks_completed, 1):
                lines.append(f"### {i}. {task['task']}")
                if task['description']:
                    lines.append(f"   - {task['description']}")
                if task['hours']:
                    lines.append(f"   - ⏱️ 耗时: {task['hours']}小时")
                lines.append("")
        else:
            lines.append("*暂无完成的工作记录*")
            lines.append("")
        
        # 进行中工作
        if self.tasks_in_progress:
            lines.append("## 🔄 进行中工作")
            for task in self.tasks_in_progress:
                lines.append(f"- **{task['task']}** - 进度: {task['progress']}")
                if task['blocker']:
                    lines.append(f"  - 障碍: {task['blocker']}")
            lines.append("")
        
        # 工作指标
        if self.metrics:
            lines.append("## 📈 工作指标")
            for key, data in self.metrics.items():
                unit = f" ({data['unit']})" if data['unit'] else ''
                lines.append(f"- {key}: **{data['value']}**{unit}")
            lines.append("")
        
        # 遇到问题
        if self.problems:
            lines.append("## ⚠️ 遇到的问题")
            for p in self.problems:
                lines.append(f"- **{p['problem']}**")
                if p['impact']:
                    lines.append(f"  - 影响: {p['impact']}")
                if p['solution']:
                    lines.append(f"  - 解决方案: {p['solution']}")
            lines.append("")
        
        # 下周计划
        lines.append("## 📋 下周工作计划")
        if self.next_week_plans:
            for task in self.next_week_plans:
                deadline_str = f" (截止: {task['deadline']})" if task['deadline'] else ""
                lines.append(f"- [ ] {task['task']}{deadline_str} - 优先级: {task['priority']}")
        else:
            lines.append("*暂无计划*")
        lines.append("")
        
        # 备注
        lines.append("---")
        lines.append(f"*📝 报告生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M')}*")
        
        return '\n'.join(lines)
    
    def save(self, output_file):
        """保存周报"""
        content = self.generate_markdown()
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"✅ 周报已保存: {output_file}")


class MonthlyReportGenerator:
    """月报生成器"""
    
    def __init__(self, name, year=None, month=None):
        self.name = name
        self.year = year or datetime.now().year
        self.month = month or datetime.now().month
        self.summary = ''
        self.accomplishments = []
        self.challenges = []
        self.goals = []
        self.financial_summary = {}
        self.team_summary = {}
    
    def set_summary(self, text):
        """设置月度总结"""
        self.summary = text
    
    def add_accomplishment(self, item, impact=''):
        """添加本月成就"""
        self.accomplishments.append({'item': item, 'impact': impact})
    
    def add_challenge(self, challenge, solution=''):
        """添加本月挑战"""
        self.challenges.append({'challenge': challenge, 'solution': solution})
    
    def add_goal(self, goal, metric='', deadline=''):
        """添加目标"""
        self.goals.append({'goal': goal, 'metric': metric, 'deadline': deadline})
    
    def set_financial(self, revenue=None, cost=None, profit=None, growth=None):
        """设置财务数据"""
        if revenue:
            self.financial_summary['revenue'] = revenue
        if cost:
            self.financial_summary['cost'] = cost
        if profit:
            self.financial_summary['profit'] = profit
        if growth:
            self.financial_summary['growth'] = growth
    
    def set_team(self, headcount=None, hires=None, departures=None):
        """设置团队数据"""
        if headcount:
            self.team_summary['headcount'] = headcount
        if hires:
            self.team_summary['hires'] = hires
        if departures:
            self.team_summary['departures'] = departures
    
    def generate_markdown(self):
        """生成月报"""
        lines = []
        
        month_str = f"{self.year}年{self.month}月"
        lines.append(f"# 📊 {self.name} - 月度工作报告")
        lines.append(f"**报告月份**: {month_str}")
        lines.append("")
        
        # 月度总结
        lines.append("## 📝 月度总结")
        lines.append(self.summary if self.summary else "*本月工作整体顺利推进...*")
        lines.append("")
        
        # 主要成就
        if self.accomplishments:
            lines.append("## 🎯 主要成就")
            for a in self.accomplishments:
                lines.append(f"- ✅ {a['item']}")
                if a['impact']:
                    lines.append(f"  - 影响: {a['impact']}")
            lines.append("")
        
        # 挑战与解决
        if self.challenges:
            lines.append("## ⚠️ 挑战与解决方案")
            for c in self.challenges:
                lines.append(f"- **{c['challenge']}**")
                if c['solution']:
                    lines.append(f"  - 解决方案: {c['solution']}")
            lines.append("")
        
        # 财务数据
        if self.financial_summary:
            lines.append("## 💰 财务概览")
            if 'revenue' in self.financial_summary:
                lines.append(f"- 营收: **{self.financial_summary['revenue']}**")
            if 'cost' in self.financial_summary:
                lines.append(f"- 成本: {self.financial_summary['cost']}")
            if 'profit' in self.financial_summary:
                lines.append(f"- 利润: **{self.financial_summary['profit']}**")
            if 'growth' in self.financial_summary:
                lines.append(f"- 增长率: {self.financial_summary['growth']}")
            lines.append("")
        
        # 团队数据
        if self.team_summary:
            lines.append("## 👥 团队概览")
            if 'headcount' in self.team_summary:
                lines.append(f"- 当前人数: **{self.team_summary['headcount']}**")
            if 'hires' in self.team_summary:
                lines.append(f"- 新入职: {self.team_summary['hires']}")
            if 'departures' in self.team_summary:
                lines.append(f"- 离职: {self.team_summary['departures']}")
            lines.append("")
        
        # 下月目标
        if self.goals:
            lines.append("## 🎯 下月目标")
            for g in self.goals:
                lines.append(f"- [ ] {g['goal']}")
                if g['metric']:
                    lines.append(f"  - 指标: {g['metric']}")
                if g['deadline']:
                    lines.append(f"  - 截止: {g['deadline']}")
            lines.append("")
        
        lines.append("---")
        lines.append(f"*📝 报告生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M')}*")
        
        return '\n'.join(lines)
    
    def save(self, output_file):
        """保存月报"""
        content = self.generate_markdown()
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"✅ 月报已保存: {output_file}")


def create_template(report_type='weekly'):
    """创建报告模板"""
    if report_type == 'weekly':
        return """# 📊 周报模板

## 基本信息
- **姓名**: 
- **部门**: 
- **周次**: 
- **周期**: YYYY-MM-DD ~ YYYY-MM-DD

## ✅ 本周完成工作
1. 
2. 
3. 

## 🔄 进行中工作
- 项目A - 进度: 50%

## 📈 工作指标
- 完成任务: X个
- 工作时长: X小时

## ⚠️ 遇到的问题
- 问题描述及解决方案

## 📋 下周工作计划
- [ ] 任务1
- [ ] 任务2

---
*报告生成时间: YYYY-MM-DD*
"""
    else:
        return """# 📊 月报模板

## 基本信息
- **姓名/部门**: 
- **月份**: YYYY年MM月

## 📝 月度总结


## 🎯 主要成就
- 

## 💰 财务/工作数据


## 🎯 下月目标
- [ ] 
"""
    return template


def main():
    parser = argparse.ArgumentParser(description='工作报告自动生成工具')
    parser.add_argument('command', choices=['weekly', 'monthly', 'template'])
    parser.add_argument('-n', '--name', default='员工', help='姓名/部门')
    parser.add_argument('-o', '--output', help='输出文件')
    parser.add_argument('-t', '--type', default='weekly', choices=['weekly', 'monthly'])
    
    args = parser.parse_args()
    
    if args.command == 'template':
        print(create_template(args.type))
        if args.output:
            with open(args.output, 'w', encoding='utf-8') as f:
                f.write(create_template(args.type))
            print(f"✅ 模板已保存: {args.output}")
    
    elif args.command == 'weekly':
        generator = WeeklyReportGenerator(args.name)
        
        # 可以从这里添加自动填充逻辑
        # 例如从任务管理系统导入数据
        
        output = args.output or f"周报_{datetime.now().strftime('%Y%m%d')}.md"
        generator.save(output)
    
    elif args.command == 'monthly':
        generator = MonthlyReportGenerator(args.name)
        output = args.output or f"月报_{datetime.now().strftime('%Y%m')}.md"
        generator.save(output)


if __name__ == '__main__':
    main()
