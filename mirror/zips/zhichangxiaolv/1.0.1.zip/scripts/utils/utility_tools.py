#!/usr/bin/env python3
"""
实用工具集
功能：密码生成、二维码、图片处理等
"""

import os
import argparse
import string
import secrets
import qrcode
from pathlib import Path
from datetime import datetime
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageEnhance


def generate_password(length=16, use_special=True, use_digits=True,
                      use_upper=True, use_lower=True, exclude_ambiguous=False):
    """
    生成随机强密码
    
    Args:
        length: 密码长度
        use_special: 包含特殊字符
        use_digits: 包含数字
        use_upper: 包含大写字母
        use_lower: 包含小写字母
        exclude_ambiguous: 排除易混淆字符 (0, O, l, 1, I)
    """
    chars = ''
    
    if use_lower:
        chars += string.ascii_lowercase
    if use_upper:
        chars += string.ascii_uppercase
    if use_digits:
        chars += string.digits
    if use_special:
        chars += string.punctuation
    
    # 排除易混淆字符
    if exclude_ambiguous:
        ambiguous = '0O1lI|'
        chars = ''.join(c for c in chars if c not in ambiguous)
    
    if not chars:
        print("❌ 至少需要选择一种字符类型")
        return None
    
    password = ''.join(secrets.choice(chars) for _ in range(length))
    
    return password


def generate_multiple_passwords(count=5, length=16, **kwargs):
    """批量生成密码"""
    passwords = []
    for _ in range(count):
        pwd = generate_password(length, **kwargs)
        if pwd:
            passwords.append(pwd)
    
    return passwords


def create_qrcode(text, output_file=None, size=10, 
                  error_correction='M', color='black', bg_color='white'):
    """
    生成二维码
    
    Args:
        text: 二维码内容
        output_file: 输出文件
        size: 每个模块的像素大小
        error_correction: 纠错级别 L/M/Q/H
        color: 前景色
        bg_color: 背景色
    """
    error_levels = {
        'L': qrcode.constants.ERROR_CORRECT_L,
        'M': qrcode.constants.ERROR_CORRECT_M,
        'Q': qrcode.constants.ERROR_CORRECT_Q,
        'H': qrcode.constants.ERROR_CORRECT_H
    }
    
    qr = qrcode.QRCode(
        version=1,
        error_correction=error_levels.get(error_correction, qrcode.constants.ERROR_CORRECT_M),
        box_size=size,
        border=4,
    )
    
    qr.add_data(text)
    qr.make(fit=True)
    
    img = qr.make_image(fill_color=color, back_color=bg_color)
    
    if output_file:
        output_path = Path(output_file)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        img.save(output_file)
        print(f"✅ 二维码已生成: {output_file}")
    else:
        img.show()
    
    return img


def resize_image(input_file, output_file, width=None, height=None,
                keep_aspect=True, scale=None):
    """调整图片尺寸"""
    img = Image.open(input_file)
    original_width, original_height = img.size
    
    if scale:
        new_width = int(original_width * scale)
        new_height = int(original_height * scale)
    elif width and height:
        new_width, new_height = width, height
        if keep_aspect:
            ratio = min(width / original_width, height / original_height)
            new_width = int(original_width * ratio)
            new_height = int(original_height * ratio)
    elif width:
        ratio = width / original_width
        new_width, new_height = width, int(original_height * ratio)
    elif height:
        ratio = height / original_height
        new_width, new_height = int(original_width * ratio), height
    else:
        print("❌ 需要指定尺寸或缩放比例")
        return
    
    resized = img.resize((new_width, new_height), Image.LANCZOS)
    
    output_path = Path(output_file)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    resized.save(output_file)
    
    print(f"✅ 尺寸调整: {original_width}x{original_height} -> {new_width}x{new_height}")
    print(f"   保存至: {output_file}")


def compress_image(input_file, output_file=None, quality=85, max_size=None):
    """压缩图片"""
    img = Image.open(input_file)
    
    if max_size:
        original_size = os.path.getsize(input_file)
        target_size = max_size * 1024 * 1024  # MB to bytes
        
        if original_size <= target_size:
            print("⚠️  图片已小于目标大小")
            return
        
        # 逐步降低质量
        quality = 95
        while quality > 10:
            output_buffer = io.BytesIO()
            img.save(output_buffer, format='JPEG', quality=quality)
            if output_buffer.tell() <= target_size:
                break
            quality -= 5
        
        output_path = Path(output_file) if output_file else Path(f"compressed_{input_file}")
        with open(output_path, 'wb') as f:
            f.write(output_buffer.getvalue())
    else:
        output_path = Path(output_file) if output_file else Path(f"compressed_{input_file}")
        img.save(output_path, quality=quality, optimize=True)
    
    new_size = os.path.getsize(output_path)
    print(f"✅ 压缩完成: {output_path}")
    print(f"   原始大小: {original_size/1024:.1f} KB")
    print(f"   压缩后: {new_size/1024:.1f} KB")
    print(f"   压缩比: {(1-new_size/original_size)*100:.1f}%")


def add_watermark_image(input_file, output_file, watermark_text,
                       position='bottom-right', opacity=0.3, font_size=20):
    """添加图片水印"""
    img = Image.open(input_file).convert('RGBA')
    
    # 创建水印层
    txt_layer = Image.new('RGBA', img.size, (255, 255, 255, 0))
    draw = ImageDraw.Draw(txt_layer)
    
    # 尝试加载字体
    try:
        font = ImageFont.truetype("arial.ttf", font_size)
    except:
        font = ImageFont.load_default()
    
    # 计算水印位置
    bbox = draw.textbbox((0, 0), watermark_text, font=font)
    text_width = bbox[2] - bbox[0]
    text_height = bbox[3] - bbox[1]
    
    positions = {
        'top-left': (10, 10),
        'top-right': (img.width - text_width - 10, 10),
        'bottom-left': (10, img.height - text_height - 10),
        'bottom-right': (img.width - text_width - 10, img.height - text_height - 10),
        'center': ((img.width - text_width) // 2, (img.height - text_height) // 2)
    }
    
    pos = positions.get(position, positions['bottom-right'])
    
    # 绘制水印
    alpha = int(255 * opacity)
    draw.text(pos, watermark_text, fill=(255, 255, 255, alpha), font=font)
    
    # 合并图层
    watermarked = Image.alpha_composite(img, txt_layer)
    
    output_path = Path(output_file)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    watermarked.save(output_file)
    print(f"✅ 水印已添加: {output_file}")


def batch_convert_images(input_dir, output_dir, target_format='jpg'):
    """批量转换图片格式"""
    input_path = Path(input_dir)
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)
    
    image_files = []
    for ext in ['.jpg', '.jpeg', '.png', '.bmp', '.gif', '.webp']:
        image_files.extend(input_path.glob(f'*{ext}'))
    
    converted = 0
    for img_file in image_files:
        try:
            img = Image.open(img_file)
            
            if target_format.lower() in ['jpg', 'jpeg']:
                img = img.convert('RGB')
            
            output_file = output_path / f"{img_file.stem}.{target_format.lower()}"
            img.save(output_file)
            converted += 1
        except Exception as e:
            print(f"❌ 转换失败 {img_file.name}: {e}")
    
    print(f"✅ 批量转换完成: {converted}/{len(image_files)}")


def main():
    parser = argparse.ArgumentParser(description='实用工具集')
    parser.add_argument('command',
                       choices=['password', 'qrcode', 'resize', 
                               'compress', 'watermark', 'convert'],
                       help='操作命令')
    
    # 密码生成参数
    parser.add_argument('-l', '--length', type=int, default=16, help='密码长度')
    parser.add_argument('-n', '--count', type=int, default=1, help='生成数量')
    parser.add_argument('--no-special', action='store_true', help='不含特殊字符')
    parser.add_argument('--no-digits', action='store_true', help='不含数字')
    parser.add_argument('--no-upper', action='store_true', help='不含大写')
    parser.add_argument('--no-lower', action='store_true', help='不含小写')
    parser.add_argument('--exclude-ambiguous', action='store_true', help='排除易混淆字符')
    
    # 二维码参数
    parser.add_argument('-t', '--text', help='二维码内容/URL')
    parser.add_argument('-s', '--size', type=int, default=10, help='二维码大小')
    
    # 图片处理参数
    parser.add_argument('-i', '--input', help='输入文件')
    parser.add_argument('-o', '--output', help='输出文件')
    parser.add_argument('-w', '--width', type=int, help='目标宽度')
    parser.add_argument('-H', '--height', type=int, help='目标高度')
    parser.add_argument('--scale', type=float, help='缩放比例')
    parser.add_argument('-q', '--quality', type=int, default=85, help='压缩质量')
    parser.add_argument('--max-size', type=float, help='最大文件大小(MB)')
    parser.add_argument('--wm-text', help='水印文字')
    parser.add_argument('--position', default='bottom-right',
                       choices=['top-left', 'top-right', 'bottom-left', 
                               'bottom-right', 'center'])
    
    args = parser.parse_args()
    
    if args.command == 'password':
        passwords = generate_multiple_passwords(
            count=args.count,
            length=args.length,
            use_special=not args.no_special,
            use_digits=not args.no_digits,
            use_upper=not args.no_upper,
            use_lower=not args.no_lower,
            exclude_ambiguous=args.exclude_ambiguous
        )
        
        print("\n生成的密码:")
        for i, pwd in enumerate(passwords, 1):
            print(f"  {i}. {pwd}")
    
    elif args.command == 'qrcode':
        if not args.text:
            print("❌ 需要指定内容: -t")
            return
        output_file = args.output or f"{args.text[:20]}_qrcode.png"
        create_qrcode(args.text, output_file, args.size)
    
    elif args.command == 'resize':
        if not args.input:
            print("❌ 需要指定输入文件: -i")
            return
        output_file = args.output or f"resized_{Path(args.input).name}"
        resize_image(args.input, output_file, args.width, args.height, scale=args.scale)
    
    elif args.command == 'compress':
        if not args.input:
            print("❌ 需要指定输入文件: -i")
            return
        output_file = args.output
        compress_image(args.input, output_file, args.quality, args.max_size)
    
    elif args.command == 'watermark':
        if not args.input or not args.wm_text:
            print("❌ 需要指定输入文件和水印文字: -i, --wm-text")
            return
        output_file = args.output or f"watermarked_{Path(args.input).name}"
        add_watermark_image(args.input, output_file, args.wm_text, args.position)
    
    elif args.command == 'convert':
        if not args.input:
            print("❌ 需要指定输入目录: -i")
            return
        if not args.output:
            print("❌ 需要指定输出目录: -o")
            return
        batch_convert_images(args.input, args.output)


if __name__ == '__main__':
    main()
