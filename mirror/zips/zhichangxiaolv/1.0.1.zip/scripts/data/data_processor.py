#!/usr/bin/env python3
"""
数据处理工具集
功能：JSON/CSV转换、数据清洗、去重、合并
"""

import os
import json
import argparse
import csv
from pathlib import Path
from collections import defaultdict
import pandas as pd


def json_to_csv(input_file, output_file, encoding='utf-8'):
    """JSON转CSV"""
    with open(input_file, 'r', encoding=encoding) as f:
        data = json.load(f)
    
    if isinstance(data, list) and data:
        if isinstance(data[0], dict):
            keys = set()
            for item in data:
                keys.update(item.keys())
            keys = sorted(keys)
            
            with open(output_file, 'w', newline='', encoding='utf-8-sig') as f:
                writer = csv.DictWriter(f, fieldnames=keys)
                writer.writeheader()
                writer.writerows(data)
            
            print(f"✅ 转换完成: {len(data)} 条记录")
            print(f"   字段: {', '.join(keys)}")
        else:
            print("❌ JSON格式不支持：需要是对象数组")
    else:
        print("❌ JSON格式不支持：需要是数组格式")


def csv_to_json(input_file, output_file, encoding='utf-8'):
    """CSV转JSON"""
    df = pd.read_csv(input_file, encoding='utf-8-sig')
    data = df.to_dict('records')
    
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    
    print(f"✅ 转换完成: {len(data)} 条记录")
    print(f"   字段: {', '.join(df.columns)}")


def clean_data(input_file, output_file, 
               drop_duplicates=True, drop_na=True,
               fill_na_value='', strip_strings=True):
    """数据清洗"""
    suffix = Path(input_file).suffix.lower()
    
    if suffix == '.csv':
        df = pd.read_csv(input_file, encoding='utf-8-sig')
    else:
        df = pd.read_excel(input_file)
    
    original_len = len(df)
    
    # 去重
    if drop_duplicates:
        df = df.drop_duplicates()
        removed = original_len - len(df)
        if removed > 0:
            print(f"🗑️  删除重复行: {removed}")
    
    # 填充/删除空值
    if drop_na:
        before = len(df)
        df = df.dropna()
        removed = before - len(df)
        if removed > 0:
            print(f"🗑️  删除空值行: {removed}")
    elif fill_na_value is not None:
        df = df.fillna(fill_na_value)
        print(f"📝 填充空值: {fill_na_value}")
    
    # 清理字符串
    if strip_strings:
        for col in df.select_dtypes(include=['object']).columns:
            df[col] = df[col].apply(
                lambda x: x.strip() if isinstance(x, str) else x
            )
    
    # 保存
    output_path = Path(output_file)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    if output_path.suffix.lower() == '.csv':
        df.to_csv(output_file, index=False, encoding='utf-8-sig')
    else:
        df.to_excel(output_file, index=False)
    
    print(f"\n✅ 清洗完成: {len(df)} 条记录 (原始: {original_len})")
    print(f"   输出文件: {output_file}")


def merge_by_key(input_files, output_file, key_column, join_type='outer'):
    """按键合并多个文件"""
    dfs = []
    
    for file_path in input_files:
        path = Path(file_path)
        if not path.exists():
            print(f"⚠️  文件不存在: {file_path}")
            continue
        
        if path.suffix.lower() == '.csv':
            df = pd.read_csv(file_path, encoding='utf-8-sig')
        else:
            df = pd.read_excel(file_path)
        
        df['_source'] = path.name
        dfs.append(df)
        print(f"✅ 读取: {path.name} ({len(df)} 行)")
    
    if not dfs:
        print("❌ 没有成功读取文件")
        return
    
    # 合并
    merged = dfs[0]
    for df in dfs[1:]:
        merged = merged.merge(df, on=key_column, how=join_type, suffixes=('', '_dup'))
    
    # 保存
    output_path = Path(output_file)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    if output_path.suffix.lower() == '.csv':
        merged.to_csv(output_file, index=False, encoding='utf-8-sig')
    else:
        merged.to_excel(output_file, index=False)
    
    print(f"\n✅ 合并完成: {len(merged)} 行 x {len(merged.columns)} 列")
    print(f"   输出文件: {output_file}")


def deduplicate(input_file, output_file, key_columns, keep='first'):
    """数据去重"""
    suffix = Path(input_file).suffix.lower()
    
    if suffix == '.csv':
        df = pd.read_csv(input_file, encoding='utf-8-sig')
    else:
        df = pd.read_excel(input_file)
    
    original_len = len(df)
    
    # 去重
    df = df.drop_duplicates(subset=key_columns, keep=keep)
    
    removed = original_len - len(df)
    
    # 保存
    output_path = Path(output_file)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    if output_path.suffix.lower() == '.csv':
        df.to_csv(output_file, index=False, encoding='utf-8-sig')
    else:
        df.to_excel(output_file, index=False)
    
    print(f"✅ 去重完成: 删除 {removed} 条重复记录")
    print(f"   保留 {len(df)} 条记录")
    print(f"   输出文件: {output_file}")


def filter_data(input_file, output_file, conditions):
    """
    按条件筛选数据
    conditions格式: "column>100,column2==张三,column3<50"
    """
    suffix = Path(input_file).suffix.lower()
    
    if suffix == '.csv':
        df = pd.read_csv(input_file, encoding='utf-8-sig')
    else:
        df = pd.read_excel(input_file)
    
    original_len = len(df)
    
    # 解析条件
    for condition in conditions.split(','):
        condition = condition.strip()
        if '==' in condition:
            col, val = condition.split('==')
            df = df[df[col.strip()] == val.strip()]
        elif '!=' in condition:
            col, val = condition.split('!=')
            df = df[df[col.strip()] != val.strip()]
        elif '>' in condition:
            col, val = condition.split('>')
            df = df[df[col.strip()] > float(val.strip())]
        elif '<' in condition:
            col, val = condition.split('<')
            df = df[df[col.strip()] < float(val.strip())]
        elif '>=' in condition:
            col, val = condition.split('>=')
            df = df[df[col.strip()] >= float(val.strip())]
        elif '<=' in condition:
            col, val = condition.split('<=')
            df = df[df[col.strip()] <= float(val.strip())]
    
    # 保存
    output_path = Path(output_file)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    if output_path.suffix.lower() == '.csv':
        df.to_csv(output_file, index=False, encoding='utf-8-sig')
    else:
        df.to_excel(output_file, index=False)
    
    print(f"✅ 筛选完成: 保留 {len(df)} 条记录 (原始: {original_len})")
    print(f"   条件: {conditions}")
    print(f"   输出文件: {output_file}")


def aggregate_data(input_file, output_file, group_by, agg_funcs):
    """
    数据聚合统计
    agg_funcs格式: "col1=sum,col2=mean,col3=count"
    """
    suffix = Path(input_file).suffix.lower()
    
    if suffix == '.csv':
        df = pd.read_csv(input_file, encoding='utf-8-sig')
    else:
        df = pd.read_excel(input_file)
    
    # 解析聚合函数
    agg_dict = {}
    for func_pair in agg_funcs.split(','):
        col, func = func_pair.split('=')
        col, func = col.strip(), func.strip()
        if col not in agg_dict:
            agg_dict[col] = []
        agg_dict[col].append(func)
    
    # 执行聚合
    result = df.groupby(group_by).agg(agg_dict).reset_index()
    
    # 保存
    output_path = Path(output_file)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    if output_path.suffix.lower() == '.csv':
        result.to_csv(output_file, index=False, encoding='utf-8-sig')
    else:
        result.to_excel(output_file, index=False)
    
    print(f"✅ 聚合完成: {len(result)} 组")
    print(f"   分组: {group_by}")
    print(f"   聚合: {agg_funcs}")
    print(f"   输出文件: {output_file}")


def main():
    parser = argparse.ArgumentParser(description='数据处理工具集')
    parser.add_argument('command', 
                       choices=['json2csv', 'csv2json', 'clean', 'merge', 
                               'dedup', 'filter', 'aggregate'],
                       help='操作命令')
    parser.add_argument('input', help='输入文件')
    parser.add_argument('-o', '--output', required=True, help='输出文件')
    parser.add_argument('-k', '--key', help='键列名')
    parser.add_argument('-g', '--group-by', help='分组列')
    parser.add_argument('-a', '--agg', help='聚合函数 (col=sum,col2=mean)')
    parser.add_argument('-c', '--conditions', help='筛选条件')
    parser.add_argument('--drop-dup', action='store_true', help='删除重复行')
    parser.add_argument('--drop-na', action='store_true', help='删除空值行')
    parser.add_argument('extra', nargs='*', help='额外输入文件')
    
    args = parser.parse_args()
    
    if args.command == 'json2csv':
        json_to_csv(args.input, args.output)
    
    elif args.command == 'csv2json':
        csv_to_json(args.input, args.output)
    
    elif args.command == 'clean':
        clean_data(args.input, args.output,
                  drop_duplicates=args.drop_dup,
                  drop_na=args.drop_na)
    
    elif args.command == 'merge':
        if not args.key:
            print("❌ 需要指定键列: -k")
            return
        files = [args.input] + args.extra
        merge_by_key(files, args.output, args.key)
    
    elif args.command == 'dedup':
        if not args.key:
            print("❌ 需要指定键列: -k")
            return
        deduplicate(args.input, args.output, args.key.split(','))
    
    elif args.command == 'filter':
        if not args.conditions:
            print("❌ 需要指定筛选条件: -c")
            return
        filter_data(args.input, args.output, args.conditions)
    
    elif args.command == 'aggregate':
        if not args.group_by or not args.agg:
            print("❌ 需要指定分组列和聚合函数")
            return
        aggregate_data(args.input, args.output, args.group_by, args.agg)


if __name__ == '__main__':
    main()
