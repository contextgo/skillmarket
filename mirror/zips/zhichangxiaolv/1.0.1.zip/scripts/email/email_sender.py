#!/usr/bin/env python3
"""
邮件自动处理工具
功能：自动发送邮件、批量发送、邮件清理
"""

import os
import argparse
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from pathlib import Path
import csv


def send_email(smtp_server, smtp_port, username, password, 
               to_address, subject, body, attachments=None,
               is_html=False):
    """
    发送邮件
    
    Args:
        smtp_server: SMTP服务器
        smtp_port: SMTP端口
        username: 用户名
        password: 密码
        to_address: 收件人
        subject: 主题
        body: 正文
        attachments: 附件列表
        is_html: 是否为HTML格式
    """
    msg = MIMEMultipart()
    msg['From'] = username
    msg['To'] = to_address
    msg['Subject'] = subject
    
    # 添加正文
    if is_html:
        msg.attach(MIMEText(body, 'html'))
    else:
        msg.attach(MIMEText(body, 'plain'))
    
    # 添加附件
    if attachments:
        for attachment in attachments:
            file_path = Path(attachment)
            if not file_path.exists():
                print(f"⚠️  附件不存在: {attachment}")
                continue
            
            with open(file_path, 'rb') as f:
                part = MIMEBase('application', 'octet-stream')
                part.set_payload(f.read())
                encoders.encode_base64(part)
                part.add_header(
                    'Content-Disposition',
                    f'attachment; filename="{file_path.name}"'
                )
                msg.attach(part)
    
    # 发送邮件
    try:
        with smtplib.SMTP_SSL(smtp_server, smtp_port) as server:
            server.login(username, password)
            server.send_message(msg)
        print(f"✅ 邮件已发送: {to_address}")
        return True
    except Exception as e:
        print(f"❌ 发送失败: {e}")
        return False


def batch_send_from_csv(csv_file, smtp_config, template, subject_template):
    """
    从CSV文件批量发送邮件
    
    CSV格式: email,name,var1,var2,...
    """
    with open(csv_file, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        contacts = list(reader)
    
    print(f"准备发送 {len(contacts)} 封邮件...")
    
    success = 0
    for contact in contacts:
        # 替换模板变量
        body = template
        subject = subject_template
        
        for key, value in contact.items():
            placeholder = f'{{{key}}}'
            body = body.replace(placeholder, value)
            subject = subject.replace(placeholder, value)
        
        result = send_email(
            smtp_server=smtp_config['server'],
            smtp_port=smtp_config['port'],
            username=smtp_config['username'],
            password=smtp_config['password'],
            to_address=contact['email'],
            subject=subject,
            body=body
        )
        
        if result:
            success += 1
    
    print(f"\n完成: {success}/{len(contacts)} 封邮件发送成功")


def batch_send_with_attachments(csv_file, smtp_config, template, subject_template, attachment_col):
    """批量发送带不同附件的邮件"""
    with open(csv_file, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        contacts = list(reader)
    
    print(f"准备发送 {len(contacts)} 封邮件（每人附带不同附件）...")
    
    success = 0
    for contact in contacts:
        body = template
        subject = subject_template
        
        for key, value in contact.items():
            placeholder = f'{{{key}}}'
            body = body.replace(placeholder, value)
            subject = subject.replace(placeholder, value)
        
        # 获取附件
        attachment = contact.get(attachment_col, '')
        attachments = [attachment] if attachment and Path(attachment).exists() else None
        
        result = send_email(
            smtp_server=smtp_config['server'],
            smtp_port=smtp_config['port'],
            username=smtp_config['username'],
            password=smtp_config['password'],
            to_address=contact['email'],
            subject=subject,
            body=body,
            attachments=attachments
        )
        
        if result:
            success += 1
    
    print(f"\n完成: {success}/{len(contacts)} 封邮件发送成功")


def send_salary_slips(csv_file, smtp_config, template_file, attachment_dir):
    """发送工资条"""
    with open(csv_file, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        employees = list(reader)
    
    # 读取模板
    with open(template_file, 'r', encoding='utf-8') as f:
        template = f.read()
    
    print(f"准备发送 {len(employees)} 份工资条...")
    
    success = 0
    for emp in employees:
        body = template
        for key, value in emp.items():
            body = body.replace(f'{{{key}}}', value)
        
        # 查找附件
        emp_id = emp.get('工号', '')
        name = emp.get('姓名', '')
        attachment = Path(attachment_dir) / f"{emp_id}_{name}.pdf"
        
        if attachment.exists():
            result = send_email(
                smtp_server=smtp_config['server'],
                smtp_port=smtp_config['port'],
                username=smtp_config['username'],
                password=smtp_config['password'],
                to_address=emp['email'],
                subject=f'【工资条】{emp.get("姓名")} - {emp.get("月份", "")}',
                body=body,
                attachments=[str(attachment)]
            )
        else:
            result = send_email(
                smtp_server=smtp_config['server'],
                smtp_port=smtp_config['port'],
                username=smtp_config['username'],
                password=smtp_config['password'],
                to_address=emp['email'],
                subject=f'【工资条】{emp.get("姓名")} - {emp.get("月份", "")}',
                body=body
            )
        
        if result:
            success += 1
    
    print(f"\n完成: {success}/{len(employees)} 份工资条发送成功")


# 示例SMTP配置
SMTP_CONFIGS = {
    'qq': {
        'server': 'smtp.qq.com',
        'port': 465,
    },
    '163': {
        'server': 'smtp.163.com', 
        'port': 465,
    },
    'gmail': {
        'server': 'smtp.gmail.com',
        'port': 587,
    },
    'outlook': {
        'server': 'smtp-mail.outlook.com',
        'port': 587,
    }
}


def main():
    parser = argparse.ArgumentParser(description='邮件自动处理工具')
    parser.add_argument('command', 
                       choices=['send', 'batch', 'salary'],
                       help='操作命令')
    parser.add_argument('-s', '--server', default='qq', 
                       choices=list(SMTP_CONFIGS.keys()),
                       help='邮件服务商')
    parser.add_argument('-u', '--username', required=True, help='邮箱账号')
    parser.add_argument('-p', '--password', required=True, help='邮箱密码/授权码')
    parser.add_argument('-t', '--to', help='收件人')
    parser.add_argument('--subject', default='邮件主题', help='邮件主题')
    parser.add_argument('--body', default='邮件正文', help='邮件正文')
    parser.add_argument('-a', '--attachment', nargs='+', help='附件')
    parser.add_argument('-c', '--csv', help='联系人CSV文件')
    parser.add_argument('-f', '--template', help='邮件模板文件')
    parser.add_argument('--attachment-dir', help='工资条附件目录')
    
    args = parser.parse_args()
    
    smtp_config = SMTP_CONFIGS[args.server]
    smtp_config['username'] = args.username
    smtp_config['password'] = args.password
    
    if args.command == 'send':
        send_email(
            smtp_server=smtp_config['server'],
            smtp_port=smtp_config['port'],
            username=args.username,
            password=args.password,
            to_address=args.to,
            subject=args.subject,
            body=args.body,
            attachments=args.attachment
        )
    
    elif args.command == 'batch':
        if not args.csv or not args.template:
            print("❌ 需要指定 -c (CSV文件) 和 -f (模板文件)")
            return
        
        with open(args.template, 'r', encoding='utf-8') as f:
            template = f.read()
        
        batch_send_from_csv(args.csv, smtp_config, template, args.subject)
    
    elif args.command == 'salary':
        if not args.csv or not args.template:
            print("❌ 需要指定 -c (员工CSV) 和 -f (模板文件)")
            return
        
        with open(args.template, 'r', encoding='utf-8') as f:
            template = f.read()
        
        send_salary_slips(args.csv, smtp_config, template, args.attachment_dir or '.')


if __name__ == '__main__':
    main()
