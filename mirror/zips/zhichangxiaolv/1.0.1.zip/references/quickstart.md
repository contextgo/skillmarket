# 快速入门指南

## 环境准备

### 1. 安装Python
确保已安装Python 3.8或更高版本。

```bash
python --version
```

### 2. 安装依赖

#### 自动安装（推荐）
```bash
cd workplace-efficiency-master/scripts
python install_dependencies.py
```

#### 手动安装
```bash
pip install pandas openpyxl python-docx PyPDF2 Pillow qrcode requests beautifulsoup4
```

### 3. 验证安装
```bash
python -c "import pandas, openpyxl, docx; print('✅ 依赖检查通过')"
```

## 常用命令速查

### 文件处理
```bash
# 批量重命名
python scripts/file/batch_rename.py ./files -p "doc_" -i -f

# 搜索文件内容
python scripts/file/file_search.py ./project "TODO"

# 文件分类
python scripts/file/file_classifier.py type ./downloads
```

### Excel处理
```bash
# 合并报表
python scripts/excel/excel_merge.py *.xlsx -o monthly.xlsx

# 生成报表
python scripts/excel/excel_report.py data.csv -o report.xlsx

# 数据透视
python scripts/excel/excel_pivot.py sales.xlsx -i "部门" -v "销售额" -a sum
```

### PDF处理
```bash
# 合并PDF
python scripts/pdf/pdf_processor.py merge *.pdf -o combined.pdf

# 提取页面
python scripts/pdf/pdf_processor.py extract doc.pdf -p "1-5"

# 添加水印
python scripts/pdf/pdf_processor.py watermark doc.pdf -t "CONFIDENTIAL"
```

### 数据处理
```bash
# JSON转CSV
python scripts/data/data_processor.py json2csv data.json -o data.csv

# 数据清洗
python scripts/data/data_processor.py clean data.xlsx -o clean.xlsx --drop-dup --drop-na

# 筛选数据
python scripts/data/data_processor.py filter data.csv -c "金额>1000"
```

### 邮件发送
```bash
# 发送邮件
python scripts/email/email_sender.py send -u you@email.com -p "password" -t target@email.com

# 批量发送
python scripts/email/email_sender.py batch -c contacts.csv -f template.txt
```

### 实用工具
```bash
# 生成密码
python scripts/utils/utility_tools.py password -l 16 -n 5

# 生成二维码
python scripts/utils/utility_tools.py qrcode -t "https://example.com"

# 压缩图片
python scripts/utils/utility_tools.py compress photo.jpg -q 80
```

## 常见问题

### Q: 脚本运行报错 "ModuleNotFoundError"
**A**: 运行 `python install_dependencies.py` 安装缺失的依赖包

### Q: OCR功能无法使用
**A**: 需要额外安装Tesseract OCR引擎：
- Windows: 下载安装包并添加到PATH
- macOS: `brew install tesseract`
- Linux: `sudo apt install tesseract-ocr`

### Q: Word转PDF失败
**A**: 安装docx2pdf: `pip install docx2pdf`

### Q: 如何查看帮助信息
**A**: 使用 `--help` 参数，如 `python batch_rename.py --help`

## 使用技巧

1. **预览模式**: 大多数文件操作脚本默认是预览模式，使用 `-f` 或 `--force` 执行实际操作
2. **批量处理**: 使用通配符 `*.xlsx` 可以一次性处理多个文件
3. **管道操作**: 脚本输出可以重定向到文件保存日志
4. **定时任务**: 结合系统cron可以实现自动化定时执行

## 获取帮助

- 查看完整文档: `SKILL.md`
- 查看脚本帮助: `python script.py --help`
- 查看模板: `templates/` 目录
