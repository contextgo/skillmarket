# 职场效率大师 (Workplace Efficiency Master) v1.0.1

> 一站式职场办公自动化工具箱，涵盖文件处理、数据分析、文档转换、邮件管理、定时任务等常见办公场景。

## 📁 目录结构

```
workplace-efficiency-master/
├── SKILL.md                    # 技能说明文档
├── scripts/                    # 脚本目录
│   ├── file/                   # 文件处理模块
│   │   ├── batch_rename.py    # 批量重命名
│   │   ├── file_search.py      # 文件内容搜索
│   │   └── file_classifier.py  # 文件分类整理
│   ├── excel/                  # Excel处理模块
│   │   ├── excel_merge.py      # 数据合并
│   │   ├── excel_report.py     # 报表生成
│   │   └── excel_pivot.py      # 数据透视
│   ├── word/                   # Word处理模块
│   │   └── word_processor.py   # Word批量处理
│   ├── pdf/                    # PDF处理模块
│   │   └── pdf_processor.py    # PDF合并/分割/水印
│   ├── email/                  # 邮件处理模块
│   │   └── email_sender.py     # 邮件自动发送
│   ├── data/                   # 数据处理模块
│   │   └── data_processor.py   # JSON/CSV转换清洗
│   ├── schedule/               # 定时任务模块
│   │   ├── task_scheduler.py   # 任务调度器
│   │   └── backup_manager.py   # 数据备份
│   ├── web/                    # 网页处理模块
│   │   └── web_monitor.py      # 网页监控器
│   └── utils/                  # 实用工具模块
│       ├── utility_tools.py    # 密码生成/二维码/图片
│       ├── audio_to_text.py    # 语音转文字
│       ├── meeting_notes.py    # 会议纪要生成
│       ├── report_generator.py # 周报月报生成
│       └── screenshot_ocr.py   # 截图OCR识别
├── templates/                  # 模板目录
└── references/                 # 参考文档
```

## 🚀 快速开始

### 环境要求
- Python 3.8+
- 依赖库: pandas, openpyxl, python-docx, PyPDF2, Pillow, qrcode 等

### 安装依赖
```bash
pip install pandas openpyxl python-docx PyPDF2 Pillow qrcode requests beautifulsoup4 speech_recognition pytesseract
```

## 📜 功能模块详解

### 1. 文件处理 (`scripts/file/`)

#### batch_rename.py - 批量重命名
```bash
# 添加前缀
python batch_rename.py ./files -p "report_" -f

# 添加序号
python batch_rename.py ./photos -i -f

# 正则替换
python batch_rename.py ./files --pattern "IMG_\d+" --replacement "photo_" -f
```

#### file_search.py - 文件内容搜索
```bash
# 搜索关键词
python file_search.py ./docs "Python"

# 限定文件类型
python file_search.py ./docs "TODO" -e .py .md

# 不区分大小写
python file_search.py ./docs "config" -c
```

#### file_classifier.py - 文件分类
```bash
# 按类型分类
python file_classifier.py type ./downloads

# 按日期分类
python file_classifier.py date ./documents

# 查找重复文件
python file_classifier.py dedup ./folder
```

### 2. Excel处理 (`scripts/excel/`)

#### excel_merge.py - 数据合并
```bash
# 合并多个Excel文件
python excel_merge.py *.xlsx -o merged.xlsx

# 按键合并
python excel_merge.py *.xlsx -o merged.xlsx -m key -k "工号"
```

#### excel_report.py - 报表生成
```bash
# 从CSV生成格式化报表
python excel_report.py data.csv -o report.xlsx -t "销售报表"
```

#### excel_pivot.py - 数据透视
```bash
# 创建透视表
python excel_pivot.py sales.xlsx -o pivot.xlsx -i "部门" -v "销售额" -a sum
```

### 3. Word处理 (`scripts/word/`)

#### word_processor.py
```bash
# Word转PDF
python word_processor.py convert ./docs

# 批量文本替换
python word_processor.py replace ./docs -t "旧文本" -r "新文本"

# 提取文本
python word_processor.py extract report.docx -o text.txt
```

### 4. PDF处理 (`scripts/pdf/`)

#### pdf_processor.py
```bash
# 合并PDF
python pdf_processor.py merge ./*.pdf -o merged.pdf

# 分割PDF
python pdf_processor.py split large.pdf -n 10

# 提取页面
python pdf_processor.py extract input.pdf -p "1-3,5"

# 添加水印
python pdf_processor.py watermark input.pdf -o output.pdf -t "CONFIDENTIAL"
```

### 5. 邮件处理 (`scripts/email/`)

#### email_sender.py
```bash
# 发送单封邮件
python email_sender.py send -u your@email.com -p password -t recipient@email.com --subject "主题"

# 批量发送
python email_sender.py batch -u your@email.com -p password -c contacts.csv -f template.txt
```

### 6. 数据处理 (`scripts/data/`)

#### data_processor.py
```bash
# JSON转CSV
python data_processor.py json2csv data.json -o data.csv

# 数据清洗
python data_processor.py clean data.xlsx -o clean.xlsx --drop-dup --drop-na

# 按条件筛选
python data_processor.py filter data.csv -o filtered.csv -c "年龄>18,部门==销售"
```

### 7. 定时任务 (`scripts/schedule/`)

#### task_scheduler.py
```bash
# 定时备份
python task_scheduler.py backup --source ./data --dest ./backup --interval 1 --unit days

# 清理旧文件
python task_scheduler.py clean --folder ./temp --days 7

# 网站监控
python task_scheduler.py monitor --url https://example.com --keyword "有货" --interval 60
```

#### backup_manager.py
```bash
# 创建备份
python backup_manager.py backup -s ./important_data -n mybackup

# 恢复备份
python backup_manager.py restore -s backups/mybackup_20240115.tar.gz -o ./restored

# 清理旧备份
python backup_manager.py cleanup --keep-days 30
```

### 8. 网页监控 (`scripts/web/`)

#### web_monitor.py
```bash
# 添加监控
python web_monitor.py add -u https://shop.example.com/product -k "有货"

# 检查所有
python web_monitor.py check

# 持续监控
python web_monitor.py monitor --interval 300
```

### 9. 实用工具 (`scripts/utils/`)

#### utility_tools.py
```bash
# 生成密码
python utility_tools.py password -l 16 -n 5

# 生成二维码
python utility_tools.py qrcode -t "https://example.com" -o qr.png

# 压缩图片
python utility_tools.py compress input.jpg -q 80 --max-size 1
```

#### report_generator.py
```bash
# 生成周报模板
python report_generator.py template -t weekly

# 生成月报模板
python report_generator.py template -t monthly -o template.md
```

#### screenshot_ocr.py
```bash
# OCR识别图片
python screenshot_ocr.py ocr -i screenshot.png

# 批量处理
python screenshot_ocr.py batch -i ./images -o ./texts
```

## 🔧 常用场景

### 场景1: 每周数据汇总
```bash
# 1. 合并多份报表
python excel_merge.py week1.xlsx week2.xlsx week3.xlsx week4.xlsx -o monthly.xlsx

# 2. 生成透视表
python excel_pivot.py monthly.xlsx -o summary.xlsx -i "产品" -v "销量" -a sum

# 3. 生成报表
python excel_report.py summary.xlsx -o final_report.xlsx -t "月度汇总报告"
```

### 场景2: 批量文档处理
```bash
# 1. 批量转换Word为PDF
python word_processor.py convert ./contracts

# 2. 添加水印
for f in *.pdf; do
    python pdf_processor.py watermark "$f" -o "./watermarked/$f" -t "CONFIDENTIAL"
done

# 3. 合并为一个PDF
python pdf_processor.py merge ./watermarked/*.pdf -o contracts_final.pdf
```

### 场景3: 定时数据备份
```bash
# 创建定时备份脚本 backup_task.sh
#!/bin/bash
python backup_manager.py backup -s /data -n daily_backup --root /backups

# 添加到crontab
crontab -e
# 每天凌晨2点执行
0 2 * * * /path/to/backup_task.sh
```

## 📊 效率提升统计

| 场景 | 传统方式 | 使用本工具 | 效率提升 |
|------|---------|-----------|---------|
| 100个文件重命名 | 30分钟 | 5秒 | 99% |
| 月度数据汇总 | 4小时 | 10分钟 | 95% |
| 批量文档转换 | 2小时 | 5分钟 | 96% |
| 每周备份 | 1小时 | 1分钟 | 98% |

## 📝 贡献指南

欢迎提交Issue和Pull Request！

## 📄 许可证

MIT License
