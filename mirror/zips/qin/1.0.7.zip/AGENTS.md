# AGENTS.md - Qin 全力模式技能架构

> 🌳 Skill 级架构规范

---

## 📋 Skill 信息

| 属性 | 值 |
|------|-----|
| Skill 名称 | qin (秦) |
| 触发词 | qin / 秦 |
| 版本 | v5 |
| 描述 | 全力模式技能 |

---

## 📁 Skill 目录结构

```
~/.workbuddy/skills/qin/
├── SKILL.md                    ← 主文件（入口）
├── AGENTS.md                   ← 当前文件（Skill 架构）
├── quick-ref.md               ← 快速参考
├── patterns.md                ← 执行模式库
├── phases/                    ← 各阶段详细文档
│   ├── AGENTS.md             ← Phase 层级架构
│   ├── p0-context.md
│   ├── p1-analysis.md
│   ├── p2-execution.md
│   ├── pm-memory.md
│   ├── ps-safety.md
│   ├── pl-learning.md
│   ├── pe-error.md
│   ├── pc-context-window.md
│   ├── pr-recovery.md
│   └── p3-delivery.md
└── references/
    ├── skill-combo.md
    └── templates.md
```

---

## 🎯 执行阶段

| Phase | 名称 | 执行时机 |
|-------|------|----------|
| 0 | 并行上下文收集 | 强制第一步 |
| 1 | 任务分析与规划 | 紧接 Phase 0 |
| 2 | 深度执行 | 核心工作 |
| M | 记忆管理 | 贯穿全程 |
| S | 安全检查 | 贯穿全程 |
| L | 自学习 | 贯穿全程 |
| E | 错误处理 | 按需 |
| C | 上下文管理 | 长对话按需 |
| R | 中断恢复 | 按需 |
| 3 | 验证与交付 | 最后一步 |

---

## 🔗 层级规范

### Phase 级规范

每个 Phase 文档应包含：
- 目的说明
- 执行步骤
- 决策树
- 模板/示例
- 反模式

### Reference 文档

- `templates.md` — 常用模板库
- `skill-combo.md` — 技能协同指南

---

*自动生成 | 如需修改请编辑此文件*
