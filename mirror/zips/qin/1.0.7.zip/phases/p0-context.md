# PHASE 0: 并行上下文收集（强制第一步）

> 任何任务开始前，必须先并行收集上下文信息。

## 为什么要并行收集？

- **节省时间**：多个信息源同时查询
- **建立全局视图**：了解项目全貌再行动
- **避免盲区**：发现可能被忽略的重要信息

## 并行执行命令

<parallel_gathering>
**立即执行以下所有操作：**

```bash
# 当前状态
git status
git diff --stat

# 历史上下文
git log -30 --oneline

# 工作目录结构
ls -la
pwd

# 如果是代码任务，查看文件分布
find . -name "*.ts" -o -name "*.js" -o -name "*.py" | head -50
```
</parallel_gathering>

## 特殊场景的额外收集

### 服务器诊断场景
```bash
# 进程状态
ps aux | grep -E "node|python|java"
systemctl list-units --type=service

# 网络连接
netstat -tlnp | head -20
ss -tlnp

# 资源使用
df -h
free -m
```

### 数据库场景
```sql
-- 连接状态
SHOW PROCESSLIST;

-- 表大小
SELECT table_name, data_length FROM information_schema.tables 
WHERE table_schema = 'your_db';

-- 最近的慢查询
SHOW VARIABLES LIKE 'slow_query_log';
```

### Web 开发场景
```bash
# 依赖状态
cat package.json | grep -E '"dependencies"|"scripts"'
npm ls --depth=0

# 环境配置
cat .env | head -10
```

## 输出格式

```
📊 上下文收集结果

## Git 状态
[git status 和 log 的关键信息]

## 文件结构
[关键文件和目录]

## 发现的问题/亮点
- [发现1]
- [发现2]

## 初步判断
[基于收集到的信息，初步判断任务的方向]
```

---

*此文件为 Qin 全力模式技能的一部分*
