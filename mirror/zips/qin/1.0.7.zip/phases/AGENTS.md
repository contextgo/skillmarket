# AGENTS.md - Phase 模块层级架构

> 🌳 Phase 文档层级规范

---

## 📁 Phases 目录结构

```
phases/
├── AGENTS.md              ← 当前文件：Phase 层级规范
├── p0-context.md         → 并行上下文收集
├── p1-analysis.md        → 任务分析与规划
├── p2-execution.md        → 深度执行
├── pm-memory.md          → 记忆管理
├── ps-safety.md          → 安全检查
├── pl-learning.md        → 自学习机制
├── pe-error.md           → 错误处理
├── pc-context-window.md   → 上下文管理
├── pr-recovery.md        → 中断恢复
└── p3-delivery.md        → 验证交付
```

---

## 📝 每个 Phase 文档标准结构

```markdown
# [Phase 名称]

> [一句话说明]

## 目的
[为什么需要这个 Phase]

## 执行步骤
[详细步骤列表]

## 决策树
[可视化决策流程]

## 模板
[可复用的模板]

## 示例
[实际使用示例]

## 反模式
[绝对禁止的做法]
```

---

## 🔗 依赖关系

```
Phase 0 (上下文收集)
    ↓
Phase 1 (任务分析)
    ↓
Phase 2 (深度执行) ←── Phase M (记忆) 贯穿
    ↓               ←── Phase S (安全) 贯穿
    ↓               ←── Phase L (学习) 贯穿
    ↓               ←── Phase E (错误) 按需
    ↓               ←── Phase C (上下文) 按需
    ↓               ←── Phase R (恢复) 按需
    ↓
Phase 3 (验证交付)
```

---

*自动生成 | 如需修改请编辑此文件*
