# 廖彩杏书单 (130本)

**推荐人**: 廖彩杏 (台湾)  
**专业领域**: 英语启蒙  
**适用年龄**: 0-8岁  
**核心理念**: 用有声书轻松听出英语力

## 书单特点

- **体系化**: 分4个阶段,52周进阶学习计划
- **有声书**: 强调通过听力输入学习英语
- **重复学习**: 每个阶段都有重复周,巩固记忆
- **不强调认字**: 先听说,后读写
- **母语习得法**: 模拟母语学习环境

---

## 第一阶段 (1-13周) 22本

### 目标
通过节奏、韵律和重复性强的作品,让孩子熟悉英语语音。

### 第1周
1. **My Very First Mother Goose** (鹅妈妈童谣)
   - 年龄: 0-3岁
   - 关键词: 韵律、童谣

2. **Brown Bear, Brown Bear, What Do You See?**
   - 作者: Bill Martin Jr. / Eric Carle
   - 年龄: 0-3岁
   - 关键词: 颜色、动物、重复句型

3. **The Wheels On The Bus**
   - 年龄: 0-3岁
   - 关键词: 交通工具、歌谣

### 第2周
4. **Five Little Monkeys Jumping On the Bed**
   - 年龄: 2-5岁
   - 关键词: 数字、韵律

5. **Go Away, Mr. Wolf!**
   - 年龄: 2-5岁
   - 关键词: 故事性、对话

### 第3周
6. **Down By The Station**
   - 年龄: 2-5岁
   - 关键词: 交通、歌谣

7. **Hop On Pop**
   - 作者: Dr. Seuss
   - 年龄: 3-5岁
   - 关键词: 押韵、字母拼读

### 第4周
8. **Five Little Men In A Flying Saucer**
   - 年龄: 3-6岁
   - 关键词: 数字、想象力

9. **Green Eggs And Ham**
   - 作者: Dr. Seuss
   - 年龄: 4-8岁
   - 关键词: 重复句型、幽默

10. **Henny Penny**
    - 年龄: 3-6岁
    - 关键词: 经典故事

### 第5-6周
重复第1-4周书单

### 第7周
11. **Ape in A Cape: An Alphabet of Odd Animals**
    - 年龄: 3-6岁
    - 关键词: 字母、押韵

12. **Ten Fat Sausages**
    - 年龄: 2-5岁
    - 关键词: 数字、歌谣

13. **The Very Hungry Caterpillar**
    - 作者: Eric Carle
    - 年龄: 2-5岁
    - 关键词: 毛毛虫、星期、食物

### 第8周
14. **Hattie And The Fox**
    - 作者: Mem Fox
    - 年龄: 3-6岁
    - 关键词: 重复、悬念

15. **I Am the Music Man**
    - 年龄: 3-6岁
    - 关键词: 乐器、歌谣

16. **Today is Monday**
    - 作者: Eric Carle
    - 年龄: 3-6岁
    - 关键词: 星期、食物

### 第9周
17. **Does a Kangaroo Have A Mother, Too?**
    - 作者: Eric Carle
    - 年龄: 2-5岁
    - 关键词: 动物、亲情

18. **Five Little Ducks**
    - 年龄: 2-5岁
    - 关键词: 数字、歌谣

19. **Fox in Socks**
    - 作者: Dr. Seuss
    - 年龄: 4-8岁
    - 关键词: 绕口令、押韵

### 第10周
20. **Dr. Seuss's ABC**
    - 作者: Dr. Seuss
    - 年龄: 3-6岁
    - 关键词: 字母表

21. **Dry Bones**
    - 年龄: 3-6岁
    - 关键词: 身体部位、歌谣

22. **Go Away, Big Green Monster!**
    - 作者: Ed Emberley
    - 年龄: 2-5岁
    - 关键词: 克服恐惧、互动

### 第11-13周
重复第7-10周书单

---

## 第二阶段 (14-26周) 24本

### 目标
通过字音、字义的连接认识字形,增强故事性。

### 第14周
23. **Five Little Monkeys Sitting In A Tree**
    - 年龄: 3-6岁

24. **Sheep In A Jeep**
    - 年龄: 3-6岁
    - 关键词: 押韵、幽默

25. **The Mixed-Up Chameleon**
    - 作者: Eric Carle
    - 年龄: 3-6岁
    - 关键词: 变色龙、自我认同

### 第15周
26. **Down In The Jungle**
    - 年龄: 3-6岁

27. **Goodnight Moon**
    - 作者: Margaret Wise Brown
    - 年龄: 0-3岁
    - 关键词: 睡前故事、经典

28. **Sheep In A Shop**
    - 年龄: 3-6岁

### 第16周
29. **Here We Go Round The Mulberry Bush**
    - 年龄: 2-5岁

30. **King Bidgood's In The Bathtub**
    - 年龄: 4-8岁
    - 关键词: 幽默、重复

31. **Rosie's Walk**
    - 作者: Pat Hutchins
    - 年龄: 3-6岁
    - 关键词: 方位、悬念

### 第17周
32. **Color Zoo**
    - 作者: Lois Ehlert
    - 年龄: 2-5岁
    - 关键词: 形状、颜色、凯迪克奖

33. **The Napping House**
    - 作者: Audrey Wood
    - 年龄: 3-6岁
    - 关键词: 累积故事、幽默

34. **We All Go Traveling By**
    - 年龄: 2-5岁

### 第18-19周
重复第14-17周书单

### 第20周
35. **Creepy Crawly Calypso**
    - 年龄: 4-8岁

36. **Polar Bear, Polar Bear, What Do You Hear?**
    - 作者: Bill Martin Jr. / Eric Carle
    - 年龄: 2-5岁
    - 关键词: 动物、声音

37. **We're Going On A Bear Hunt**
    - 作者: Michael Rosen
    - 年龄: 3-6岁
    - 关键词: 冒险、重复、韵律

### 第21周
38. **Guess How Much I Love You**
    - 作者: Sam McBratney
    - 年龄: 3-6岁
    - 关键词: 爱、亲情、经典

39. **The Very Quiet Cricket**
    - 作者: Eric Carle
    - 年龄: 3-6岁
    - 关键词: 蟋蟀、成长

40. **Walking Through The Jungle**
    - 年龄: 3-6岁

### 第22周
41. **Is Your Mama a Llama?**
    - 年龄: 3-6岁
    - 关键词: 押韵、动物

42. **Animal Boogie**
    - 年龄: 3-6岁

43. **The Foot Book**
    - 作者: Dr. Seuss
    - 年龄: 2-5岁
    - 关键词: 反义词

### 第23周
44. **Kipper's A to Z**
    - 年龄: 3-6岁
    - 关键词: 字母表、小狗Kipper

45. **One Fish Two Fish Red Fish Blue Fish**
    - 作者: Dr. Seuss
    - 年龄: 4-8岁
    - 关键词: 数字、颜色、押韵

46. **The Journey Home From Grandpa**
    - 年龄: 3-6岁

### 第24-26周
重复第20-23周书单

---

## 第三阶段 (27-39周) 24本

### 目标
通过自然科学、知识性主题绘本,熟悉专业领域字汇。

### 第27周
47. **Chicken Soup With Rice: A Book of Months**
    - 作者: Maurice Sendak
    - 年龄: 4-8岁
    - 关键词: 月份

48. **On Market Street**
    - 年龄: 4-8岁
    - 关键词: 字母、购物

49. **Silly Sally**
    - 作者: Audrey Wood
    - 年龄: 3-6岁
    - 关键词: 押韵、幽默

### 第28周
50. **Each Peach Pear Plum**
    - 作者: Janet & Allan Ahlberg
    - 年龄: 2-5岁
    - 关键词: 童话角色、押韵

51. **Papa Please Get The Moon For Me**
    - 作者: Eric Carle
    - 年龄: 3-6岁
    - 关键词: 月亮、想象力

52. **Quick As A Cricket**
    - 年龄: 3-6岁
    - 关键词: 形容词、自我认知

### 第29周
53. **Eating the Alphabet: Fruits & Vegetables from A to Z**
    - 作者: Lois Ehlert
    - 年龄: 3-6岁
    - 关键词: 字母、食物

54. **See You Later, Alligator!**
    - 年龄: 3-6岁

55. **The Princess and the Dragon**
    - 年龄: 4-8岁

### 第30周
56-61. **I Am系列科普绘本** (6本)
    - **I Am An Apple**
    - **I'm A Caterpillar**
    - **I'm A Seed**
    - **I Am A Star**
    - **I Am Snow**
    - **I Am Water**
    - **I Am A Leaf**
    - **I Am Fire**
    - **I Am A Rock**
    - **I Am Planet Earth**
    - 年龄: 4-8岁
    - 关键词: 科普、自然

62. **The Little Mouse, The Red Ripe Strawberry, and The Big Hungry Bear**
    - 作者: Don & Audrey Wood
    - 年龄: 2-5岁
    - 关键词: 小老鼠、草莓

### 第31-32周
重复第27-30周书单

### 第33-36周
63. **A Dragon On The Doorstep**
64. **Alligators All Around: An Alphabet**
65. **Maisy Goes Camping**
66. **The Itsy Bitsy Spider**
67. **Maisy's Christmas Eve**
68. **Over In The Meadow**

### 第37-39周
重复第33-36周书单

---

## 第四阶段 (40-52周) 30本

### 目标
通过传神的插画理解故事内容,进阶到章节书。

### 第40周
69. **Do You Want to Be My Friend?**
    - 作者: Eric Carle
    - 年龄: 2-5岁

70. **Row Row Row Your Boat**
    - 年龄: 2-5岁

### 第41周
71. **Handa's Surprise**
    - 年龄: 3-6岁
    - 关键词: 非洲、水果

72-74. **太阳系科普系列**
    - **The Solar System**
    - **The Sun**
    - **Earth**
    - **The Moon**
    - **Comets**
    - **Shooting Stars**
    - 年龄: 6-10岁
    - 关键词: 天文、科普

75. **What's The Time, Mr. Wolf?**
    - 年龄: 3-6岁
    - 关键词: 时间

### 第42周
76. **Tomorrow's Alphabet**
    - 年龄: 4-8岁

77. **Where's My Teddy?**
    - 作者: Jez Alborough
    - 年龄: 3-6岁
    - 关键词: 泰迪熊、幽默

### 第43周
78. **If You Give A Mouse A Cookie**
    - 作者: Laura Numeroff
    - 年龄: 4-8岁
    - 关键词: 因果关系、幽默、经典

79. **Owl Babies**
    - 作者: Martin Waddell
    - 年龄: 2-5岁
    - 关键词: 分离焦虑、亲情

### 第44-45周
重复第40-43周书单

### 第46周
80. **Chica Chica Boom Boom**
    - 年龄: 2-5岁
    - 关键词: 字母、韵律

81. **If You Take A Mouse To School**
    - 年龄: 4-8岁

82. **Kipper's Christmas Eve**
    - 年龄: 3-6岁

83. **Mouse Paint**
    - 作者: Ellen Stoll Walsh
    - 年龄: 2-5岁
    - 关键词: 颜色、科学

### 第47周
84. **Curious George Learns the Alphabets**
    - 年龄: 4-8岁
    - 关键词: 好奇的乔治、字母

85. **If The Dinosaurs Came Back**
    - 年龄: 4-8岁
    - 关键词: 恐龙、想象力

86. **Kipper's Monster**
    - 年龄: 3-6岁

87. **Madeline**
    - 作者: Ludwig Bemelmans
    - 年龄: 4-8岁
    - 关键词: 经典、巴黎、冒险

### 第48周
88. **Miss Nelson Is Missing**
    - 年龄: 5-8岁
    - 关键词: 老师、行为规范

89. **The Blue Balloon**
    - 年龄: 3-6岁

90. **The Runaway Bunny**
    - 作者: Margaret Wise Brown
    - 年龄: 2-5岁
    - 关键词: 母爱、安全感、经典

### 第49周
91. **Click, Clack, Moo: Cows That Type**
    - 年龄: 4-8岁
    - 关键词: 幽默、农场

92. **Dinosaur Encore**
    - 年龄: 3-6岁

93. **Noisy Nora**
    - 作者: Rosemary Wells
    - 年龄: 3-6岁
    - 关键词: 二胎、关注需求

### 第50-52周
重复第46-49周书单

---

## 使用建议

1. **严格按周执行**: 52周计划,每周3本新书+重复书
2. **每天听3-4次**: 早上、下午、睡前,每次10-15分钟
3. **不强迫认字**: 重点是听力输入,自然习得
4. **亲子共读**: 配合有声书,家长也要陪读
5. **重复是关键**: 每本书至少听20-30遍
6. **不翻译**: 让孩子在情境中理解,不要逐句翻译

## 廖彩杏书单的优势

✅ 体系完整,循序渐进  
✅ 强调韵律和节奏,易于记忆  
✅ 大量经典作品,质量有保障  
✅ 配套有声书资源丰富  
✅ 适合英语零基础启蒙

## 局限性

⚠️ 仅适合0-8岁英语启蒙  
⚠️ 不涉及中文阅读  
⚠️ 需要长期坚持(1年)  
⚠️ 对家长执行力要求高  
⚠️ 有声书资源需要额外购买

## 适用人群

- 0-8岁英语零基础或初学儿童
- 希望通过"磨耳朵"方式学英语的家庭
- 有时间和精力坚持1年计划的家长
- 注重英语韵律和语感培养的家庭
