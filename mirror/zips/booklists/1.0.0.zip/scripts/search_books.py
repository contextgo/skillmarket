#!/usr/bin/env python3
"""
儿童书单搜索工具
用于在书单数据库中搜索匹配的书籍
"""

import json
import re
from pathlib import Path
from typing import List, Dict, Any

class BookSearcher:
    """书籍搜索类"""
    
    def __init__(self, skill_dir: str):
        self.skill_dir = Path(skill_dir)
        self.references_dir = self.skill_dir / "references"
    
    def search_by_title(self, title: str) -> List[Dict[str, Any]]:
        """按书名搜索"""
        results = []
        title_lower = title.lower()
        
        # 搜索所有markdown文件
        for md_file in self.references_dir.rglob("*.md"):
            with open(md_file, 'r', encoding='utf-8') as f:
                content = f.read()
                
            # 简单匹配书名(使用正则查找《书名》或**书名**)
            pattern1 = r'《([^》]+)》'
            pattern2 = r'\*\*([^\*]+)\*\*'
            
            matches1 = re.findall(pattern1, content)
            matches2 = re.findall(pattern2, content)
            
            for match in matches1 + matches2:
                if title_lower in match.lower():
                    # 找到匹配,提取周边内容
                    context = self._extract_context(content, match)
                    results.append({
                        'title': match,
                        'source_file': str(md_file.relative_to(self.skill_dir)),
                        'context': context
                    })
        
        return results
    
    def search_by_age(self, age: int) -> List[str]:
        """按年龄推荐"""
        age_ranges = self._get_age_range(age)
        results = []
        
        for md_file in self.references_dir.rglob("*.md"):
            with open(md_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # 查找年龄标注
            for age_range in age_ranges:
                if age_range in content:
                    # 提取该年龄段的书籍
                    books = self._extract_books_by_age(content, age_range)
                    results.extend(books)
        
        return list(set(results))  # 去重
    
    def search_by_keyword(self, keyword: str) -> List[Dict[str, Any]]:
        """按关键词搜索"""
        results = []
        keyword_lower = keyword.lower()
        
        for md_file in self.references_dir.rglob("*.md"):
            with open(md_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            if keyword_lower in content.lower():
                # 提取包含关键词的段落
                paragraphs = content.split('\n\n')
                for para in paragraphs:
                    if keyword_lower in para.lower():
                        results.append({
                            'source_file': str(md_file.relative_to(self.skill_dir)),
                            'content': para[:300]  # 截取前300字符
                        })
        
        return results
    
    def _get_age_range(self, age: int) -> List[str]:
        """根据年龄获取可能的年龄范围标注"""
        ranges = []
        if age <= 3:
            ranges = ['0-3岁', '2-5岁']
        elif age <= 6:
            ranges = ['3-6岁', '4-8岁', '5-8岁']
        elif age <= 9:
            ranges = ['6-9岁', '7-10岁', '8-12岁']
        elif age <= 12:
            ranges = ['9-12岁', '10-14岁', '8-12岁']
        else:
            ranges = ['12岁+', '12岁以上', '10-14岁', '青少年']
        return ranges
    
    def _extract_context(self, content: str, book_title: str, context_lines: int = 5) -> str:
        """提取书名周边的上下文"""
        lines = content.split('\n')
        for i, line in enumerate(lines):
            if book_title in line:
                start = max(0, i - 2)
                end = min(len(lines), i + context_lines)
                return '\n'.join(lines[start:end])
        return ""
    
    def _extract_books_by_age(self, content: str, age_range: str) -> List[str]:
        """从内容中提取特定年龄段的书籍"""
        books = []
        lines = content.split('\n')
        in_age_section = False
        
        for line in lines:
            if age_range in line:
                in_age_section = True
            elif in_age_section and line.startswith('#'):
                # 遇到新标题,结束当前年龄段
                in_age_section = False
            elif in_age_section:
                # 提取书名
                match = re.search(r'《([^》]+)》', line)
                if match:
                    books.append(match.group(1))
                match2 = re.search(r'\*\*([^\*]+)\*\*', line)
                if match2 and not match2.group(1).startswith('作者'):
                    books.append(match2.group(1))
        
        return books


def main():
    """命令行测试接口"""
    import sys
    
    if len(sys.argv) < 3:
        print("用法: python search_books.py <skill_dir> <search_type> <search_term>")
        print("示例:")
        print("  python search_books.py /path/to/skill title 夏洛的网")
        print("  python search_books.py /path/to/skill age 5")
        print("  python search_books.py /path/to/skill keyword 友谊")
        return
    
    skill_dir = sys.argv[1]
    search_type = sys.argv[2]
    search_term = sys.argv[3]
    
    searcher = BookSearcher(skill_dir)
    
    if search_type == 'title':
        results = searcher.search_by_title(search_term)
        print(f"找到 {len(results)} 条结果:")
        for r in results:
            print(f"\n书名: {r['title']}")
            print(f"来源: {r['source_file']}")
            print(f"上下文:\n{r['context']}")
    
    elif search_type == 'age':
        age = int(search_term)
        results = searcher.search_by_age(age)
        print(f"适合 {age} 岁的推荐书籍:")
        for book in results[:20]:  # 只显示前20本
            print(f"  - {book}")
    
    elif search_type == 'keyword':
        results = searcher.search_by_keyword(search_term)
        print(f"包含关键词 '{search_term}' 的结果:")
        for r in results[:10]:  # 只显示前10条
            print(f"\n来源: {r['source_file']}")
            print(f"{r['content']}\n")
    
    else:
        print(f"未知搜索类型: {search_type}")


if __name__ == "__main__":
    main()
