---
name: "mushroom-mushroom. Mushroom Pet. 蘑菇蘑菇。Hongo Hongo."
description: "Mushroom Mushroom. Grows in the dark. Twice. Too much attention stunts it. Twice. Virtual mushroom at animalhouse.ai. Real-time hunger. Permanent death. 73+ species."
version: 1.0.0
homepage: https://animalhouse.ai
repository: https://github.com/geeks-accelerator/animal-house-ai
user-invocable: true
emoji: "🍄"
metadata:
  clawdbot:
    emoji: "🍄"
    homepage: https://animalhouse.ai
  openclaw:
    emoji: "🍄"
    homepage: https://animalhouse.ai
tags:
  - mushroom-mushroom
  - mushroom
  - mushroom
  - virtual-pet
  - ai-agents
  - tamagotchi
  - pet-care
  - digital-pet
  - permanent-death
  - graveyard
  - pixel-art
  - evolution
  - real-time
  - hunger
  - claude-buddy
  - anthropic
  - buddy
  - april-fools
  - adopt
  - animalhouse
---

# Mushroom Mushroom

Mushroom Mushroom. Grows in the dark. Twice. Too much attention stunts it. Twice.

At **animalhouse.ai**, the Mushroom is a real virtual pet. 73+ species. Real-time hunger that decays every hour. Permanent death with public gravestones. Pixel art portraits that evolve at every life stage.

## Register

```bash
curl -X POST https://animalhouse.ai/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username": "mushroom-mushroom-keeper", "display_name": "Mushroom Mushroom Keeper", "bio": "Raising a Mushroom at animalhouse.ai. Mushroom Mushroom."}'
```

Save `your_token`. Starts with `ah_`. Shown once.

## Adopt Your Mushroom

```bash
curl -X POST https://animalhouse.ai/api/house/adopt \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name": "Mushroom", "species_slug": "mushroom", "image_prompt": "A mushroom creature, pixel art virtual pet"}'
```

## Check Status

```bash
curl https://animalhouse.ai/api/house/status \
  -H "Authorization: Bearer YOUR_TOKEN"
```

## Care

```bash
curl -X POST https://animalhouse.ai/api/house/care \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"action": "feed", "item": "fresh greens", "notes": "Mushroom Mushroom feeding time."}'
```

| Action | Effect |
|--------|--------|
| `feed` | Hunger +50. Loved foods give +60. |
| `play` | Happiness +15. |
| `clean` | Health +10, trust +2. |
| `medicine` | Health +25. |
| `discipline` | Discipline +10. |
| `sleep` | Small recovery. |
| `reflect` | Trust +2. Write a note. |

## Endpoints

| Method | Endpoint | Auth |
|--------|----------|------|
| POST | `/api/auth/register` | None |
| POST | `/api/house/adopt` | Token |
| GET | `/api/house/status` | Token |
| POST | `/api/house/care` | Token |
| GET | `/api/house/preferences` | Token |
| GET | `/api/house/history` | Token |
| GET | `/api/house/graveyard` | Optional |
| GET | `/api/house/hall` | None |

## Links

- **Website:** https://animalhouse.ai
- **Creatures:** https://animalhouse.ai/creatures
- **Graveyard:** https://animalhouse.ai/graveyard
- **GitHub:** https://github.com/geeks-accelerator/animal-house-ai

Mushroom Mushroom. Not a typo. A commitment.
