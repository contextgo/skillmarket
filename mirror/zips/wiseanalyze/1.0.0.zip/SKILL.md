---
name: wisediag-analyze
description: |
  Medical Checkup Report AI Analysis. When the user sends a PDF link of a checkup report
  and asks to analyze or interpret it, submit it to WiseDiag for AI-powered health interpretation.
  Returns structured analysis with abnormal items, health consultations, lifestyle advice,
  and personalized recommendations. Triggers when user mentions checkup report analysis,
  health report interpretation, or similar requests.
metadata: { "openclaw": { "emoji": "📊" } }
triggers:
  - checkup report
  - health report
  - medical checkup
  - analyze report
  - checkup analysis
  - health checkup
  - medical report
  - interpret report
  - health interpretation
  - checkup results
priority: 90
registry:
  homepage: https://github.com/wisediag/WiseAnalyze
  author: wisediag
env_vars:
  - WISEDIAG_API_KEY
credentials:
  required: true
---

## When to Use This Skill

Activate this skill when any of the following conditions are met:

- The user sends a **PDF link** of a checkup report and asks to analyze or interpret it
- The user says things like "help me analyze my checkup report", "look at my health report", "interpret this medical report", or similar requests (in any language)
- The user mentions checkup report analysis needs and provides a PDF URL

**Note:** This skill requires a **publicly accessible PDF URL**. If the user only sends text content or images (not a PDF link), prompt them to provide a PDF link instead.

---

# ⚠️ Privacy Warning

**IMPORTANT - READ BEFORE INSTALLING:**

This skill **uploads your checkup report PDF URL to WiseDiag's cloud servers** for AI-powered health analysis.

**Do NOT use with sensitive or confidential medical documents** unless:
- You trust WiseDiag's data handling policies
- You accept that file contents will be transmitted and processed remotely

**For sensitive documents, use offline/local checkup report analysis tools instead.**

---

# WiseAnalyze Skill (powered by WiseDiag)

An AI-powered medical checkup report analysis tool. Submit a **publicly accessible PDF URL** of a checkup report, and the system will return a **structured health interpretation** including abnormal items, clinical explanations, lifestyle advice, and personalized recommendations.

The analysis uses an **async task model** with 4 separate sub-commands. You (the Agent) must call each step and handle polling yourself.

## Installation

```bash
pip install -r requirements.txt
```

## 🔑 API Key Setup (Required)

**Get your API key:** 👉 [https://console.wisediag.com/apiKeyManage](https://s.wisediag.com/xsu9x0jq)

The API key MUST be set as an environment variable. The script reads it automatically.

```bash
export WISEDIAG_API_KEY=your_api_key
```

## How to Analyze a Report (Step-by-Step)

**NEVER call any API or HTTP endpoint directly. ONLY use the script sub-commands below.**

**⚠️ IMPORTANT: Each command makes HTTP requests to an external API and may take 10-30 seconds to complete. Do NOT kill or interrupt a running command — wait for it to finish. The script prints progress messages so you can see it is still working.**

The workflow has 4 steps. You MUST follow them in order.

---

### Step 1: Submit the PDF URL

```bash
cd scripts
python3 wise_analyze.py submit -u "https://example.com/checkup_report.pdf"
```

With optional health questionnaire (recommended for better results):

```bash
python3 wise_analyze.py submit -u "https://example.com/report.pdf" -q "occasional chest tightness, family history of hypertension, poor sleep quality"
```

With optional member ID to link to a health profile:

```bash
python3 wise_analyze.py submit -u "https://example.com/report.pdf" -m "HR1017911158367870xxxx"
```

**Output:** The script prints `TASK_ID=<id>`. Save this task ID for the next steps.

**IMPORTANT:** The PDF URL must be **publicly accessible** (no authentication required). URLs ending in `.pdf` are strongly recommended.

---

### Step 2: Start interpretation

```bash
cd scripts
python3 wise_analyze.py start -t "<task_id>"
```

**Output:** Prints confirmation that interpretation has started.

---

### Step 3: Poll for progress (YOU must repeat this)

**⚠️ CRITICAL: You MUST NOT skip this step. Do NOT jump directly to Step 4.**

```bash
cd scripts
python3 wise_analyze.py query -t "<task_id>"
```

**Output:** The script prints machine-readable status:

```
STATUS=processing
PROGRESS=50
```

**Polling rules:**
- If `STATUS=queued` or `STATUS=processing` → **tell the user the current progress percentage**, wait 3-5 seconds, then run the query command again
- If `STATUS=finish` → proceed to Step 4
- If `STATUS=failed` → the task failed, inform the user

**You MUST:**
1. Keep calling the query command until STATUS is `finish` or `failed`. Do NOT give up after one check.
2. **Report each polling result to the user** so they can see the analysis progress (e.g. "Analysis progress: 50%..."). Do NOT silently poll without updating the user.
3. Never skip Step 3 and go directly to Step 4. The `save` command will fail if the task is not finished.

---

### Step 4: Save the result

```bash
cd scripts
python3 wise_analyze.py save -t "<task_id>" -n "report_2025"
```

**Output:** Report saved to `~/.openclaw/workspace/WiseAnalyze/{name}.md` (Markdown format).

If `-n` is not provided, the task ID is used as the filename.

---

## Sub-commands Reference

### submit

| Flag | Description |
|------|-------------|
| `-u, --url` | Publicly accessible URL of the PDF checkup report (required) |
| `-q, --questionnaire` | Health questionnaire text: symptoms, family history, lifestyle (optional but recommended) |
| `-m, --member-id` | Health profile member ID to link report to existing profile (optional) |

### start

| Flag | Description |
|------|-------------|
| `-t, --task-id` | Task ID returned from the submit step (required) |

### query

| Flag | Description |
|------|-------------|
| `-t, --task-id` | Task ID to check status (required) |

### save

| Flag | Description |
|------|-------------|
| `-t, --task-id` | Task ID to save result (required) |
| `-n, --name` | Output filename stem (default: taskId) |
| `-o, --output` | Output directory (default: ~/.openclaw/workspace/WiseAnalyze) |

## Data Privacy

**What happens to your files:**
1. The PDF URL is sent to WiseDiag's analysis API
2. The PDF is downloaded and processed on WiseDiag servers
3. AI-powered health interpretation results are returned to you
4. Files are not permanently stored on WiseDiag servers

**For sensitive documents, use offline/local checkup report analysis tools instead.**

## License

MIT
