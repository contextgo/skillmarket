---
name: "job-hunter"
description: "找工作助手 - 搜索招聘网站、整理职位链接、总结 JD 摘要。触发词：找工作、搜职位、查 JD、整理职位、猎聘职位、拉勾职位、BOSS职位、搜杭州职位、搜上海职位、南京职位、苏州职位"
---

# 找工作 Skill

## 用途

辅助求职过程中的职位搜索和信息整理工作。支持猎聘、BOSS直聘、拉勾等主流招聘平台。

## ⚠️ 必填参数（强制校验）

**以下三个参数必须从用户 prompt 中获取，如果缺失则必须追问用户：**

| 参数 | 说明 | 示例 |
|:---|:---|:---|
| **城市** | 必须指定，可多选 | `杭州`、`上海`、`杭州+南京+苏州` |
| **薪资范围** | 必须指定最低薪资下限 | `25K以上`、`30K以上`、`50K以上` |
| **职位关键字** | 必须指定搜索关键词 | `AI产品经理`、`金融+产品`、`C++开发` |

### 缺少参数时的追问模板

如果用户没有指定全部三个参数，必须追问：

```
请补充以下信息：
1. 城市：想搜索哪些城市？（如：杭州、上海、南京）
2. 薪资：期望月薪下限是多少？（如：25K、30K）
3. 职位：想搜索什么职位？（如：AI产品经理、金融+产品经理）
```

## 核心功能

1. **智能防反爬** - 每次请求间隔 2-5 秒随机等待，避免触发反爬机制
2. **动态 URL 构建** - 支持任意城市+关键词组合，自动构建搜索 URL
3. **参数化薪资筛选** - 支持设置薪资下限，自动过滤不符合条件的职位
4. **过滤停招职位** - 自动跳过显示"停止招聘"字样的职位
5. **保存职位链接** - 整理成结构化 Excel 表格
6. **总结 JD 摘要** - 提取关键信息，保留最有用的内容

## 城市代码对照表

| 城市 | 代码 | 城市 | 代码 |
|:---|:---:|:---|:---:|
| 北京 | 010 | 深圳 | 030 |
| 上海 | 020 | 南京 | 060000 |
| 杭州 | 050020 | 苏州 | 070000 |
| 广州 | 050000 | 成都 | 090020 |
| 武汉 | 180020 | 西安 | 080020 |

## 动态 URL 构建

### 猎聘搜索 URL 格式

```
https://www.liepin.com/search/?dqs={城市代码}&key={关键词}&compsalary={薪资下限},100&sortFlag=15&d_pageSize=40&d_curPage={页码}
```

### URL 参数说明

| 参数 | 必填 | 说明 | 示例 |
|:---|:---:|:---|:---|
| `dqs` | ✅ | 城市代码，见上方对照表 | `050020`（杭州） |
| `key` | ✅ | 搜索关键词 | `AI产品经理` |
| `compsalary` | ✅ | 薪资下限，格式：`下限,100` | `25,100`（25K以上） |
| `sortFlag` | | 排序方式，默认15=最新发布 | `15` |
| `d_pageSize` | | 每页数量，默认40 | `40` |
| `d_curPage` | | 页码，从0开始 | `0`, `1`, `2`... |

### URL 构建示例

```python
def build_liepin_url(city_code, keyword, min_salary=0, page=0):
    """
    构建猎聘搜索 URL
    
    Args:
        city_code: 城市代码
        keyword: 搜索关键词
        min_salary: 最低薪资（K），0表示不限
        page: 页码，从0开始
    
    Returns:
        str: 完整的搜索 URL
    """
    base_url = "https://www.liepin.com/search/?"
    salary_str = f"{min_salary},100" if min_salary > 0 else "0,0"
    
    params = {
        "dqs": city_code,
        "key": keyword,
        "compsalary": salary_str,
        "sortFlag": "15",
        "d_pageSize": "40",
        "d_curPage": str(page)
    }
    
    # 构建查询字符串
    query = "&".join([f"{k}={v}" for k, v in params.items()])
    return base_url + query

# 示例调用
url = build_liepin_url("050020", "AI产品经理", min_salary=25, page=0)
# https://www.liepin.com/search/?dqs=050020&key=AI%E4%BA%A7%E5%93%81%E7%BB%8F%E7%90%86&compsalary=25,100&sortFlag=15&d_pageSize=40&d_curPage=0
```

## 工作流程

### Step 1: 分析用户需求

解析用户输入，提取：
- **城市列表**：如"杭州、上海、南京"
- **关键词**：如"AI产品经理、金融"
- **薪资下限**：如"25K以上"

### Step 2: 构建搜索 URL

根据城市和关键词，动态构建猎聘搜索 URL：

```python
# 单城市搜索
url = build_liepin_url("050020", "AI产品经理", min_salary=25)

# 多城市搜索（循环处理）
cities = {"杭州": "050020", "上海": "020", "南京": "060000"}
for city, code in cities.items():
    url = build_liepin_url(code, "AI产品经理", min_salary=25)
```

### Step 3: 抓取数据

#### web_fetch 抓取

```python
# 抓取搜索结果
result = web_fetch(url="搜索URL", fetchInfo="职位名称、公司名称、薪资、工作地点")

# 解析返回数据
jobs = parse_jobs_from_result(result)
```

#### 防反爬策略
- 每次请求后等待 2-5 秒: `time.sleep(random.uniform(2, 5))`
- 避免短时间内连续请求
- 优先使用 web_fetch 而非 Playwright 自动化
- 猎聘有较强反爬，优先用 web_fetch

### Step 4: 过滤职位

```python
def filter_jobs(jobs):
    """
    过滤职位列表
    
    1. 过滤掉显示"停止招聘"、"已暂停"、"已下线"的职位
    2. 过滤掉薪资低于下限的职位
    
    Args:
        jobs: 原始职位列表
    
    Returns:
        list: 过滤后的职位列表
    """
    filtered = []
    stop_keywords = ['停止招聘', '已暂停', '已下线', '暂停招聘', '停止职位']
    
    for job in jobs:
        # 检查是否停招
        title = job.get('职位名称', '')
        company = job.get('公司名称', '')
        status = job.get('状态', '')
        
        is_stopped = any(kw in title or kw in company or kw in status 
                        for kw in stop_keywords)
        
        if is_stopped:
            continue  # 跳过停招职位
        
        # 检查薪资
        salary = parse_salary(job.get('薪资', ''))
        if salary > 0 and salary < min_salary:
            continue  # 薪资低于下限，跳过
        
        filtered.append(job)
    
    return filtered

def parse_salary(salary_str):
    """解析薪资字符串，返回月薪（K）"""
    import re
    # 匹配如 "25-50k", "30K·15薪", "面议" 等格式
    match = re.search(r'(\d+)-(\d+)k', salary_str, re.IGNORECASE)
    if match:
        return (int(match.group(1)) + int(match.group(2))) // 2  # 返回中位数
    match = re.search(r'(\d+)k', salary_str, re.IGNORECASE)
    if match:
        return int(match.group(1))
    return 0  # 面议等返回0
```

### Step 5: 整理链接表格

调用 xlsx skill 创建表格，**固定字段**（必须包含）：

| 城市 | 职位名称 | 公司名称 | 薪资 | 工作地点 | 经验要求 | 职位说明 | 职位链接 |
|:---:|---------|---------|------|---------|---------|---------|---------|
| 杭州 | AI产品经理 | 阿里云 | 25-50k·16薪 | 杭州-余杭 | 3年以上 | 负责AI产品规划与落地，协同研发推进功能... | https://... |

**字段说明：**

| 字段 | 说明 |
|:---|:---|
| 城市 | 职位所在城市 |
| 职位名称 | 完整职位名称 |
| 公司名称 | 公司名，猎头直推可写"某公司" |
| 薪资 | 月薪范围，如"25-50k·16薪" |
| 工作地点 | 具体区域，如"杭州-余杭"、"上海-浦东" |
| 经验要求 | 如"3-5年"、"5-10年"、"不限" |
| 职位说明 | **粗略版**，50-100字概括核心职责 |
| 职位链接 | 完整猎聘链接 |

**职位说明（粗略版）生成规则：**
- 从网页抓取后，提取 3-5 条核心职责
- 合并为 50-100 字的中文摘要
- 保留关键词：AI、大模型、Agent、金融、电商等
- 格式：`负责XXX，协同XXX，推动XXX`

### Step 6: 总结 JD（可选）

使用 `references/JD_summary_template.md` 作为模板，提取核心职责和技能要求。

## JD 总结模板

```
## 职位基本信息
- **职位名称**: 
- **公司名称**: 
- **薪资范围**: 
- **工作地点**: 
- **经验要求**: 
- **学历要求**: 

## 工作内容
1. 
2. 
3. 

## 技能要求
**硬技能**:
- 

**软技能**:
- 

## 加分项
- 

## 发展前景
```

## 筛选条件

**以下三个参数必须用户提供，否则必须追问：**

| 参数 | 说明 | 示例 |
|:---|:---|:---|
| **城市** | 任意城市组合（使用城市代码） | `杭州、上海、南京`、`杭州+深圳` |
| **薪资下限** | 期望月薪最低值（K） | `25`、`30`、`50` |
| **职位关键字** | 搜索关键词，支持组合 | `AI产品经理`、`金融+产品经理` |

**可选筛选：**
- **经验**: 不限/1-3年/3-5年/5-10年

## 输出格式

1. **职位链接表格** (.xlsx) - 保存到 workspace
2. **JD 摘要表格** (.xlsx) - 保存到 workspace
3. **腾讯文档链接** - 使用 COS 导入工作流上传

## 腾讯文档上传流程

```python
# 1. 计算文件 MD5 和大小
md5 = subprocess.run(['md5', '-q', 'jobs.xlsx'], capture_output=True).stdout.decode().strip()
size = os.path.getsize('jobs.xlsx')

# 2. 预导入获取上传链接
pre_import = mcporter.call("tencent-docs", "manage.pre_import", {
    "file_name": "jobs.xlsx",
    "file_size": size,
    "file_md5": md5
})

# 3. 上传到 COS
upload_url = pre_import['upload_url']
subprocess.run(['curl', '-X', 'PUT', '-H', 'Content-Type: application/octet-stream',
                '--data-binary', '@/path/to/jobs.xlsx', upload_url])

# 4. 触发导入
async_import = mcporter.call("tencent-docs", "manage.async_import", {
    "task_id": pre_import['task_id'],
    "file_size": size,
    "file_key": pre_import['file_key'],
    "file_name": "jobs.xlsx",
    "file_md5": md5
})

# 5. 轮询进度
while True:
    progress = mcporter.call("tencent-docs", "manage.import_progress", {
        "task_id": async_import['task_id']
    })
    if progress['progress'] == 100:
        print(f"完成: {progress['file_url']}")
        break
    time.sleep(3)
```

## 常用 URL

| 平台 | 搜索 URL |
|-----|---------|
| 猎聘杭州AI产品 | `build_liepin_url("050020", "AI产品经理")` |
| 猎聘上海AI产品 | `build_liepin_url("020", "AI产品经理")` |
| 猎聘深圳AI产品 | `build_liepin_url("030", "AI产品经理")` |

## 注意事项

- 猎聘防爬较强，优先用 web_fetch
- 每次请求间隔 2-5 秒
- 表格保存到 workspace
- JD 摘要保留最有价值的信息
- 上传腾讯文档使用 COS 导入工作流
