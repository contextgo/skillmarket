#!/usr/bin/env python3
"""
防反爬抓取辅助脚本
每次请求后等待随机时间，避免触发反爬机制
"""
import time
import random
import sys

def random_delay(min_sec=2, max_sec=5):
    """生成随机延迟"""
    delay = random.uniform(min_sec, max_sec)
    print(f"⏰ 等待 {delay:.1f} 秒...")
    time.sleep(delay)
    return delay

def progressive_delay(base_delay=2, increment=0.5, max_delay=10):
    """
    渐进式延迟，请求次数越多等待越久

    Args:
        base_delay: 基础延迟秒数
        increment: 每次请求增加的延迟
        max_delay: 最大延迟
    """
    request_count = getattr(progressive_delay, 'count', 0)
    progressive_delay.count = request_count + 1

    delay = min(base_delay + (request_count * increment), max_delay)
    print(f"⏰ 第 {request_count + 1} 次请求，等待 {delay:.1f} 秒...")
    time.sleep(delay)
    return delay

if __name__ == "__main__":
    print("=== 防反爬延迟工具 ===")
    print("用法: 在 Python 中 import 此模块")
    print()
    print("示例:")
    print("  from scrape_with_delay import random_delay")
    print("  random_delay()  # 等待 2-5 秒")
    print()
    print("  from scrape_with_delay import progressive_delay")
    print("  progressive_delay()  # 第1次2秒，第2次2.5秒...")
