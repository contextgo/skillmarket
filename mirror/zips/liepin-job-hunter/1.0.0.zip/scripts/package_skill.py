#!/usr/bin/env python3
"""打包 Skill 为 zip 文件"""

import os
import sys
import zipfile
import yaml

def validate_skill(skill_path):
    """验证 skill 结构"""
    errors = []
    
    # 检查 SKILL.md
    skill_md = os.path.join(skill_path, "SKILL.md")
    if not os.path.exists(skill_md):
        errors.append("缺少 SKILL.md 文件")
    else:
        # 检查 frontmatter
        with open(skill_md, 'r') as f:
            content = f.read()
            if not content.startswith('---'):
                errors.append("SKILL.md 缺少 YAML frontmatter")
            else:
                # 解析 frontmatter
                parts = content.split('---')
                if len(parts) >= 2:
                    try:
                        frontmatter = yaml.safe_load(parts[1])
                        if 'name' not in frontmatter:
                            errors.append("frontmatter 缺少 name 字段")
                        if 'description' not in frontmatter:
                            errors.append("frontmatter 缺少 description 字段")
                    except:
                        errors.append("frontmatter 格式错误")
    
    return errors

def package_skill(skill_path, output_dir=None):
    """打包 skill"""
    skill_name = os.path.basename(skill_path)
    
    if output_dir is None:
        output_dir = os.path.dirname(skill_path)
    
    zip_path = os.path.join(output_dir, f"{skill_name}.zip")
    
    errors = validate_skill(skill_path)
    if errors:
        print("❌ 验证失败:")
        for e in errors:
            print(f"  - {e}")
        return False
    
    print(f"✅ 验证通过")
    print(f"📦 正在打包 {skill_name}...")
    
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(skill_path):
            for file in files:
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, os.path.dirname(skill_path))
                zipf.write(file_path, arcname)
                print(f"  + {arcname}")
    
    print(f"✅ 打包完成: {zip_path}")
    return True

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python package_skill.py <skill-path> [output-dir]")
        sys.exit(1)
    
    skill_path = sys.argv[1]
    output_dir = sys.argv[2] if len(sys.argv) > 2 else None
    
    package_skill(skill_path, output_dir)
