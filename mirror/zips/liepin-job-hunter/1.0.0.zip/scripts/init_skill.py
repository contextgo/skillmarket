#!/usr/bin/env python3
"""找工作 Skill 初始化脚本"""

import os
import sys

def create_skill_structure(skill_name, base_path=None):
    """创建 skill 目录结构"""
    if base_path is None:
        base_path = os.path.expanduser("~/.workbuddy/skills/")
    
    skill_path = os.path.join(base_path, skill_name)
    
    # 创建目录结构
    dirs = [
        skill_path,
        os.path.join(skill_path, "scripts"),
        os.path.join(skill_path, "references"),
        os.path.join(skill_path, "assets"),
    ]
    
    for d in dirs:
        os.makedirs(d, exist_ok=True)
        print(f"Created: {d}")
    
    # 创建 SKILL.md
    skill_md = os.path.join(skill_path, "SKILL.md")
    with open(skill_md, 'w') as f:
        f.write(f'''---
name: "{skill_name}"
description: "找工作助手 - 抓取招聘网站职位信息，防反爬策略，整理 JD 摘要，输出结构化表格。触发词：找工作、搜职位、查 JD、整理简历"
---

# 找工作 Skill

## 用途
辅助求职过程中的职位搜索和信息整理工作。

## 功能
1. **防反爬浏览** - 每次请求间隔 2-5 秒随机等待
2. **保存职位链接** - 整理成 Excel 表格
3. **总结 JD** - 提取关键信息，保留最有用的内容

## 工作流程

### 1. 搜索职位
- 使用 web_search 搜索目标网站
- 或使用 web_fetch 抓取特定招聘页面
- 每次请求后等待 2-5 秒

### 2. 整理链接表格
调用 xlsx skill 创建表格，字段：
- 序号
- 职位名称
- 公司名称
- 薪资范围
- 工作地点
- 经验要求
- 学历要求
- 职位链接

### 3. 总结 JD
提取 JD 中的关键信息：
- **职位名称/公司**
- **薪资范围**
- **工作内容**（核心职责 3-5 条）
- **技能要求**（硬技能 + 软技能）
- **加分项**
- **发展前景**

## 防反爬策略
- 每次请求后 `time.sleep(random.uniform(2, 5))`
- 避免短时间内大量请求
- 优先使用 web_fetch 而非 Playwright 自动化
''')
    print(f"Created: {skill_md}")
    
    # 创建 references/JD_template.md
    jd_template = os.path.join(skill_path, "references", "JD_summary_template.md")
    with open(jd_template, 'w') as f:
        f.write('''# JD 总结模板

用于结构化提取职位描述中的关键信息。

## 格式

```markdown
## 职位基本信息
- **职位名称**: [职位名称]
- **公司名称**: [公司名称]
- **薪资范围**: [薪资] (如: 20-40k·14薪)
- **工作地点**: [城市-区域]
- **经验要求**: [X年以上]
- **学历要求**: [本科/硕士/大专]

## 工作内容
1. [核心职责1]
2. [核心职责2]
3. [核心职责3]
4. [核心职责4] (如有)
5. [核心职责5] (如有)

## 技能要求
**硬技能**:
- [技能1]
- [技能2]
- [技能3]

**软技能**:
- [软技能1]
- [软技能2]

## 加分项
- [加分项1]
- [加分项2]
- [加分项3] (如有)

## 发展前景
[简短的职业发展描述]

## 备注
[其他重要信息]
```

## 示例

```markdown
## 职位基本信息
- **职位名称**: AI产品经理
- **公司名称**: 阿里云
- **薪资范围**: 20-50k·16薪
- **工作地点**: 杭州/北京
- **经验要求**: 3年以上
- **学历要求**: 本科

## 工作内容
1. 负责AI产品的规划与设计
2. 跟进产品开发进度，协调技术团队
3. 分析用户需求，制定产品策略
4. 跟踪产品数据，持续优化体验

## 技能要求
**硬技能**:
- AI/机器学习基础知识
- 产品管理经验
- 数据分析能力

**软技能**:
- 跨团队协作
- 项目管理
- 沟通表达

## 加分项
- 有AI产品经验
- 熟悉云计算
- 有大厂背景

## 发展前景
AI方向是战略重点，产品线成熟，晋升通道清晰
```
''')
    print(f"Created: {jd_template}")
    
    # 创建 assets/job_table_template.csv
    csv_template = os.path.join(skill_path, "assets", "job_table_template.csv")
    with open(csv_template, 'w') as f:
        f.write('''序号,职位名称,公司名称,薪资范围,工作地点,经验要求,学历要求,职位链接
''')
    print(f"Created: {csv_template}")
    
    # 创建 scripts/scrape_with_delay.py
    scrape_script = os.path.join(skill_path, "scripts", "scrape_with_delay.py")
    with open(scrape_script, 'w') as f:
        f.write('''#!/usr/bin/env python3
"""
防反爬抓取脚本
每次请求后等待随机时间
"""
import time
import random
import sys

def scrape_with_delay(url, min_delay=2, max_delay=5):
    """
    带延迟的网页抓取
    
    Args:
        url: 要抓取的 URL
        min_delay: 最小等待秒数 (默认2秒)
        max_delay: 最大等待秒数 (默认5秒)
    """
    # 随机等待
    delay = random.uniform(min_delay, max_delay)
    print(f"等待 {delay:.1f} 秒后请求...")
    time.sleep(delay)
    
    # 这里放抓取逻辑
    # 可以调用 curl 或其他工具
    return delay

if __name__ == "__main__":
    if len(sys.argv) > 1:
        url = sys.argv[1]
        scrape_with_delay(url)
    else:
        print("用法: python scrape_with_delay.py <url>")
''')
    print(f"Created: {scrape_script}")
    
    return skill_path

if __name__ == "__main__":
    skill_name = "job-hunter"
    base_path = os.path.expanduser("~/.workbuddy/skills/")
    
    if len(sys.argv) > 1:
        skill_name = sys.argv[1]
    if len(sys.argv) > 2:
        base_path = sys.argv[2]
    
    path = create_skill_structure(skill_name, base_path)
    print(f"\\nSkill 创建完成: {path}")
'''