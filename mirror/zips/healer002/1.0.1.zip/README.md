# 发现你的个人天赋Discover Your Personal Talent

## Overview
A structured thinking toolkit for extracting insight from experience.

## Features
- Structured questioning
- Behavior abstraction
- Cognitive modeling
- Expression generation

## How to Use
Follow the pipeline:
Input → Question → Abstract → Model → Express

## License
MIT
