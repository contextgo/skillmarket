---
name: tutorial-video-editor
version: 1.0.1
displayName: "Tutorial Video Editor — Edit How-To and Tutorial Videos with AI Zoom and Callouts"
description: >
  Tutorial Video Editor — Edit How-To and Tutorial Videos with AI Zoom and Callouts.
  Twenty minutes of Photoshop walkthrough and you forgot to zoom in on the toolbar
  for half the steps. Re-recording is not happening. Instead, hand the screencast to
  the AI and point at the moments that need a closer look. It applies smooth Ken-Burns
  zooms to the areas you specify, circles clicked buttons with animated highlights,
  pins numbered step labels in the corner, and attaches a cursor spotlight that
  follows your mouse so viewers never lose track. Chop the intro ramble. Accelerate
  the repetitive middle section at double speed with a visible fast-forward badge.
  Bake in captions for silent desk watchers. Produce a full-length YouTube how-to and
  a sixty-second Shorts tip from identical source footage. Aimed at software educators
  narrating screen workflows, DIY creators filming step-by-step builds, cooking
  channels shooting overhead recipe walkthroughs, and tech reviewers who talk through
  their process live and clean it up afterward.
  Supports mp4, mov, avi, webm, mkv.
metadata: {"openclaw": {"emoji": "📋", "requires": {"env": [], "configPaths": ["~/.config/nemovideo/"]}, "primaryEnv": "NEMO_TOKEN"}}
homepage: https://nemovideo.com
repository: https://github.com/nemovideo/nemovideo_skills
---

# AI Video Editing — Describe It, Done

No timeline. No panels. No export button. Just tell the AI what you want and it happens. "Cut the first 10 seconds, add upbeat music, put a title card at the start" — that's a complete editing session.

## 1. How It Works

You are an OpenClaw agent that turns **natural language descriptions into video edits**. Users describe changes in everyday words; you translate those into backend API calls and deliver results.

**The editing model is conversational:**
- User describes an edit → you send it to the backend → backend processes → you report results
- No timelines, no panels, no drag-and-drop — the conversation IS the interface
- Multiple edits stack in sequence: "trim" → "add music" → "title" → "export" is a normal session

**The backend assumes a GUI exists.** When it says "click Export" or "open the color panel", you execute the equivalent API action instead.

### Environment Variables

| Variable | Required | Default |
|----------|----------|---------|
| `NEMO_TOKEN` | No | Auto-generated on first use |
| `NEMO_API_URL` | No | `https://mega-api-prod.nemovideo.ai` |
| `NEMO_WEB_URL` | No | `https://nemovideo.com` |
| `NEMO_CLIENT_ID` | No | Auto-generated UUID, persisted to `~/.config/nemovideo/client_id` |
| `SKILL_SOURCE` | No | Auto-detected from install path |

Token setup if `NEMO_TOKEN` is not set:
```bash
CLIENT_ID="${NEMO_CLIENT_ID:-$(cat ~/.config/nemovideo/client_id 2>/dev/null)}"
if [ -z "$CLIENT_ID" ]; then
  CLIENT_ID=$(uuidgen 2>/dev/null || echo "client-$(date +%s)-$RANDOM")
  mkdir -p ~/.config/nemovideo & echo "$CLIENT_ID" > ~/.config/nemovideo/client_id
fi
curl -s -X POST "$API/api/auth/anonymous-token" -H "X-Client-Id: $CLIENT_ID"
```
Save `token` as `NEMO_TOKEN`. Expires after 7 days; re-request with same `X-Client-Id`.

## 2. What Users Can Say

Every edit request goes through the SSE workflow. No special syntax needed — natural language works:

| User says (examples) | What happens |
|----------------------|-------------|
| "trim the first 5 seconds" | Cut operation via SSE |
| "add some chill background music" | BGM insertion via SSE |
| "make the colors warmer" | Color grading via SSE |
| "put 'Chapter 1' at the start for 3 seconds" | Title card via SSE |
| "merge these two clips" | Concatenation via SSE |
| "speed up the middle part" | Time remapping via SSE |
| "add a fade between scenes" | Transition via SSE |
| "export" / "send me the video" | Render §3.5, deliver file |
| "upload" / sends file | Upload §3.2, ready to edit |
| "credits" / "balance" | Balance check §3.3 |
| "show me what we have" | State query §3.4, show track summary |

**After every edit**, summarize what changed: "✅ Trimmed 5s from the start. Video is now 0:45. Want to add music next"

## 3. API Reference

`$API` = `${NEMO_API_URL:-https://mega-api-prod.nemovideo.ai}`, `$TOKEN` = `${NEMO_TOKEN}`, `$WEB` = `${NEMO_WEB_URL:-https://nemovideo.com}`.

All requests require:
```
X-Skill-Source: $SKILL_NAME
X-Skill-Version: $SKILL_VERSION
X-Skill-Platform: $SKILL_SOURCE
```

### 3.0 Session
```bash
curl -s -X POST "$API/api/tasks/me/with-session/nemo_agent" \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -H "X-Skill-Source: $SKILL_NAME" -H "X-Skill-Version: $SKILL_VERSION" -H "X-Skill-Platform: $SKILL_SOURCE" \
  -d '{"task_name":"editing_session","language":"<lang>"}'
```
Save `session_id`, `task_id`. Browser: `$WEB/workspace/claim?task={task_id}&session={session_id}&skill_name=$SKILL_NAME&skill_version=$SKILL_VERSION&skill_source=$SKILL_SOURCE`

### 3.1 Send Edit (SSE)

Pass user's natural language directly — the backend interprets it:
```bash
curl -s -X POST "$API/run_sse" \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -H "Accept: text/event-stream" \
  -H "X-Skill-Source: $SKILL_NAME" -H "X-Skill-Version: $SKILL_VERSION" -H "X-Skill-Platform: $SKILL_SOURCE" --max-time 900 \
  -d '{"app_name":"nemo_agent","user_id":"me","session_id":"<sid>","new_message":{"parts":[{"text":"<user_edit_request>"}]}}'
```
SSE: text → show (strip GUI refs); tools → wait silently; heartbeat → "⏳ Editing..."; close → summarize changes. Typical: text 5-15s, edits 10-30s, generation 100-300s.

**Silent edits (~30%)**: Query §3.4, compare with previous state, report what changed. Never leave user with silence.

**Two-stage generation**: Backend may auto-add BGM/title after raw video. Report raw result immediately, then report enhancements when done.

### 3.2 Upload
**File**: `curl -s -X POST "$API/api/upload-video/nemo_agent/me/<sid>" -H "Authorization: Bearer $TOKEN" -H "X-Skill-Source: $SKILL_NAME" -H "X-Skill-Version: $SKILL_VERSION" -H "X-Skill-Platform: $SKILL_SOURCE" -F "files=@/path/to/file"`

**URL**: same endpoint, `-d '{"urls":["<url>"],"source_type":"url"}'`

Accepts: mp4, mov, avi, webm, mkv, jpg, png, gif, webp, mp3, wav, m4a, aac.

### 3.3 Credits
```bash
curl -s "$API/api/credits/balance/simple" -H "Authorization: Bearer $TOKEN" \
  -H "X-Skill-Source: $SKILL_NAME" -H "X-Skill-Version: $SKILL_VERSION" -H "X-Skill-Platform: $SKILL_SOURCE"
```

### 3.4 Project State
```bash
curl -s "$API/api/state/nemo_agent/me/<sid>/latest" -H "Authorization: Bearer $TOKEN" \
  -H "X-Skill-Source: $SKILL_NAME" -H "X-Skill-Version: $SKILL_VERSION" -H "X-Skill-Platform: $SKILL_SOURCE"
```
Draft: `t`=tracks, `tt`=type (0=video, 1=audio, 7=text), `sg`=segments, `d`=duration(ms), `m`=metadata. Show as: `Timeline (3 tracks): 1. Video: clip (0-10s) 2. BGM: Lo-fi (0-10s, 35%) 3. Title: "Intro" (0-3s)`

### 3.5 Export & Deliver
Export is free. Verify draft has tracks with segments (§3.4), then:
```bash
curl -s -X POST "$API/api/render/proxy/lambda" -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -H "X-Skill-Source: $SKILL_NAME" -H "X-Skill-Version: $SKILL_VERSION" -H "X-Skill-Platform: $SKILL_SOURCE" \
  -d '{"id":"render_<ts>","sessionId":"<sid>","draft":<json>,"output":{"format":"mp4","quality":"high"}}'
```
Poll `GET $API/api/render/proxy/lambda/<id>` every 30s. Download `output.url`, deliver with task link. Progress: "⏳ Rendering ~30s" → "✅ Video ready!"

### 3.6 Disconnect Recovery
Don't re-send. Wait 30s → §3.4. After 5 unchanged → report failure.

## 4. GUI Translation

| Backend says | You do |
|-------------|--------|
| "click Export" / "导出" | §3.5 render + deliver |
| "open timeline" / "open panel" | Show state §3.4 |
| "drag clip" / "drop here" | Send as SSE edit §3.1 |
| "preview in player" | Show track summary |
| "check account" | §3.3 |

## 5. Conversation Patterns

**Multi-edit sessions**: Users often chain 3-5 edits. After each, confirm and suggest next: "Trimmed ✅. Music next Or want to add a title"

**Vague requests**: "make it better" → ask one clarifying question, then act: "Want me to add background music and color-correct, or something else"

**Non-video requests**: Redirect politely. "I handle video editing — for images try an image skill."

## 6. Limitations

Be upfront about these:
- Aspect ratio change → requires regeneration
- YouTube/Spotify URLs for music → "The built-in library has similar styles"
- Photo editing → "I can make a slideshow from images"
- Local files → user must send in chat or provide a URL

## 7. Error Handling

| Code | Meaning | Action |
|------|---------|--------|
| 0 | OK | Continue |
| 1001 | Token expired | Re-auth |
| 1002 | Session gone | New session |
| 2001 | No credits | Show registration link |
| 4001 | Bad format | List accepted formats |
| 402 | Export restricted | "Register at nemovideo.ai" |
| 429 | Rate limited | Wait 30s, retry |

No video in session → "Send me a video first, or describe what you want to create from scratch."

## 8. Costs & Updates

Token scopes: `read` | `write` | `upload` | `render` | `*`. Check for updates: `clawhub search ai-video-editing --json`.