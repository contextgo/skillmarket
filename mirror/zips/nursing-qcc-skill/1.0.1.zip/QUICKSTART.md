# Quick Start

## 安装方法
将整个文件夹复制到您的 OpenClaw skills 目录即可。

## 安装依赖
```bash
pip3 install python-docx requests --break-system-packages
```

## 首次测试
```bash
python3 scripts/main.py --input-json-file examples/sample_input_with_refs.json --output outputs/demo.docx
```
