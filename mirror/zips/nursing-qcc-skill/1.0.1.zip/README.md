# 护理质量改善课题研究型开题报告 Skill 工具包

这是一个可分发、可部署、可二次开发的 OpenClaw Skill 工具包，用于生成《护理质量改善课题研究型开题报告书》。

## 工具包定位
本工具包适合医院护理部、科护士长、专科小组与信息部门联合部署，支持以下目标：

- 统一开题报告写作结构
- 统一 QC STORY 主题判定方式
- 统一团队角色描述与分工风格
- 统一现状调查写法与敏感指标表达
- 统一参考文献格式（GB/T 7714-2015）
- 统一 Word 导出成果，便于院内流转与再编辑

## 包含内容
- OpenClaw Skill 定义（SKILL.md）
- 自动真实文献检索模块（PubMed / Europe PMC / Crossref）
- 文本生成与章节规划模块
- QC STORY 判定表
- 组织团队自动生成
- 现状调查自动撰写
- 甘特图（Word 表格）
- GB/T 7714-2015 参考文献格式化
- 可编辑 Word 导出
- 最近 10 条历史记录
- 医院内部部署说明与安装脚本

## 快速开始
### 1. 安装到当前工作区
将整个目录复制到：

```bash
<workspace>/skills/nursing-qcc-proposal-docx/
```

### 2. 安装依赖
```bash
python3 -m pip install -r requirements.txt
```

### 3. 运行示例
```bash
python3 scripts/main.py   --input-json-file examples/sample_input_auto_search.json   --output outputs/护理质量改善课题研究型开题报告书.docx   --auto-search
```

### 4. 产出文件
- `outputs/*.docx`：最终 Word 文档
- `outputs/*_literature_report.json`：文献检索报告
- `data/history.json`：最近 10 条历史记录

## 目录结构
详见 `docs/HOSPITAL_DISTRIBUTION.md`。
