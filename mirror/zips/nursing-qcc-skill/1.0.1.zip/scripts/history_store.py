# -*- coding: utf-8 -*-
import json
import os
from datetime import datetime


def load_history(history_file: str):
    if not os.path.exists(history_file):
        return []
    try:
        with open(history_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return []


def save_history(history_file: str, items):
    os.makedirs(os.path.dirname(history_file), exist_ok=True)
    with open(history_file, 'w', encoding='utf-8') as f:
        json.dump(items, f, ensure_ascii=False, indent=2)


def append_history(history_file: str, title: str, output_path: str, ref_count: int):
    items = load_history(history_file)
    record = {
        'id': datetime.now().strftime('%Y%m%d-%H%M%S'),
        'title': title,
        'created_at': datetime.now().isoformat(timespec='seconds'),
        'output_path': output_path,
        'references_count': ref_count
    }
    items.insert(0, record)
    items = items[:10]
    save_history(history_file, items)
    return record, items
