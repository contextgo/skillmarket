# -*- coding: utf-8 -*-
from docx import Document
from docx.shared import Pt, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
import re


def set_doc_base_style(document: Document):
    style = document.styles['Normal']
    style.font.name = '宋体'
    style._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')
    style.font.size = Pt(12)


def set_run_font(run, bold=False, size=12):
    run.font.name = '宋体'
    run._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')
    run.font.size = Pt(size)
    run.bold = bold


def add_title(document: Document, text: str):
    p = document.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run(text)
    set_run_font(run, bold=True, size=16)


def add_meta_line(document: Document, label: str, value: str):
    p = document.add_paragraph()
    r1 = p.add_run(f'{label}：')
    set_run_font(r1, bold=True, size=12)
    r2 = p.add_run(value or '')
    set_run_font(r2, bold=False, size=12)


def add_heading(document: Document, text: str, level: int = 1):
    p = document.add_paragraph()
    run = p.add_run(text)
    size = 14 if level == 1 else 12
    set_run_font(run, bold=True, size=size)
    return p


def add_paragraph_with_superscript_citations(document: Document, text: str):
    p = document.add_paragraph()
    parts = re.split(r'(\[\d+\])', text)
    for part in parts:
        run = p.add_run(part)
        if re.fullmatch(r'\[\d+\]', part):
            set_run_font(run, size=10)
            run.font.superscript = True
        else:
            set_run_font(run, size=12)
    p.paragraph_format.first_line_indent = Cm(0.74)
    p.paragraph_format.line_spacing = 1.5
    return p


def add_table(document: Document, headers, rows):
    table = document.add_table(rows=1, cols=len(headers))
    table.style = 'Table Grid'
    hdr = table.rows[0].cells
    for i, h in enumerate(headers):
        hdr[i].text = str(h)
    for row in rows:
        cells = table.add_row().cells
        for i, cell_value in enumerate(row):
            cells[i].text = str(cell_value)
    return table


def shade_cell(cell, fill='D9EAF7'):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:fill'), fill)
    tc_pr.append(shd)


def add_gantt_table(document: Document, gantt_plan, months: int = 12):
    headers = ['活动阶段'] + [f'{i}月' for i in range(1, months + 1)]
    table = document.add_table(rows=1, cols=len(headers))
    table.style = 'Table Grid'
    hdr = table.rows[0].cells
    for i, h in enumerate(headers):
        hdr[i].text = h
    for item in gantt_plan:
        row = table.add_row().cells
        row[0].text = item['stage']
        start = int(item['start_month'])
        end = int(item['end_month'])
        for m in range(1, months + 1):
            row[m].text = '■' if start <= m <= end else ''
            if start <= m <= end:
                shade_cell(row[m], fill='92D050')
    return table


def build_docx(payload, outline, reference_texts, output_path):
    document = Document()
    set_doc_base_style(document)
    section = document.sections[0]
    section.top_margin = Cm(2.54)
    section.bottom_margin = Cm(2.54)
    section.left_margin = Cm(3.18)
    section.right_margin = Cm(3.18)

    add_title(document, '护理质量改善课题研究型开题报告书')
    document.add_paragraph('')
    add_meta_line(document, '主体名称', payload.get('organization_name', ''))
    add_meta_line(document, '科室', payload.get('department', ''))
    add_meta_line(document, '课题题目', payload.get('title', ''))
    document.add_paragraph('')

    draft = payload.get('draft_sections', {})
    team = payload.get('team', [])
    qc_story_table = payload.get('qc_story_table', [])
    gantt_plan = payload.get('gantt_plan', [])
    metrics = payload.get('metrics', [])

    for item in outline:
        add_heading(document, item['title'], level=1)
        if item['title'] == '一、选题':
            add_heading(document, '（一）选题背景、理由与文献分析', level=2)
            combined = draft.get('background_analysis', '') + '\n\n国内研究现状：' + draft.get('domestic_status', '') + '\n\n国外研究现状：' + draft.get('international_status', '')
            add_paragraph_with_superscript_citations(document, combined)
            add_heading(document, '（二）QC STORY判定主题类型', level=2)
            intro = '依据研究型品管圈的选题逻辑，本课题围绕明确的护理质量问题展开，通过现状测量、目标设定、原因分析与对策实施形成持续改进闭环。为增强主题定性的清晰度，现采用 QC STORY 判定表进行归类分析如下。'
            add_paragraph_with_superscript_citations(document, intro)
            add_table(document, headers=['判定维度', '判定内容', '判定依据'], rows=[[r['判定维度'], r['判定内容'], r['判定依据']] for r in qc_story_table])
        elif item['title'] == '二、组织团队':
            add_heading(document, '（一）团队成员组成及分工', level=2)
            team_intro = '为保证课题实施的系统性、持续性与可评价性，项目团队按照质量改善研究的流程需求进行编组，兼顾临床执行、专科支持、质控监测、管理督导与数据分析等关键职责。团队成员设置并非固定模板，而是根据课题主题、实施环境与改进重点进行针对性编撰，以确保各成员职责与项目推进任务相匹配。'
            add_paragraph_with_superscript_citations(document, team_intro)
            add_table(document, headers=['团队成员', '角色定位', '工作内容'], rows=[[t['member_name'], t['role'], t['work_content']] for t in team])
        elif item['title'] == '三、课题论述':
            add_heading(document, '（一）课题立项过程及模式构建', level=2)
            add_paragraph_with_superscript_citations(document, draft.get('project_argumentation', ''))
        elif item['title'] == '四、拟定项目推进计划':
            add_heading(document, '（一）活动计划进度设计（甘特图）', level=2)
            gantt_intro = '项目推进以年度周期为基本框架，按照“立项准备—调查分析—目标设定—对策实施—效果验证—标准化巩固”逻辑推进。为直观呈现各阶段时间安排，现以甘特图形式展示如下。'
            add_paragraph_with_superscript_citations(document, gantt_intro)
            add_gantt_table(document, gantt_plan, months=payload.get('project_period_months', 12))
        elif item['title'] == '五、现状调查与目标设定':
            add_heading(document, '（一）现状调查', level=2)
            metric_sentence = '本课题建议重点关注的评价指标包括：' + '、'.join(metrics) + '。'
            add_paragraph_with_superscript_citations(document, metric_sentence)
            add_paragraph_with_superscript_citations(document, draft.get('current_status_investigation', ''))
            add_heading(document, '（二）现状水平调查', level=2)
            survey_text = '现状水平调查拟通过回顾性资料抽取、床旁观察、过程查检与人员访谈等方法综合完成，在保证可追溯性的前提下，形成结果指标与过程指标相结合的现况描述。若部分指标尚无稳定数据基础，则应在项目启动后通过连续监测进一步校正。'
            add_paragraph_with_superscript_citations(document, survey_text)
            add_heading(document, '（三）明确目标值', level=2)
            add_paragraph_with_superscript_citations(document, draft.get('target_setting', ''))
        elif item['title'] == '六、参考文献':
            for ref_text in reference_texts:
                p = document.add_paragraph()
                r = p.add_run(ref_text)
                set_run_font(r, size=11)
    document.save(output_path)
