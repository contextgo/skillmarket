# -*- coding: utf-8 -*-
from typing import List, Dict, Any
from gbt7714 import normalize_reference

KEYWORD_METRIC_MAP = {
    '导管相关血流感染': {
        'metrics': ['导管相关血流感染发生率', '导管维护操作规范执行率', '手卫生依从率', '导管留置必要性每日评估执行率', '导管连接口消毒合格率'],
        'team_roles': [
            ('圈长/项目负责人', '统筹项目设计、任务分配、节点督导与最终质量把控。'),
            ('专科护士骨干', '负责导管维护关键环节梳理、培训与现场督查。'),
            ('感控联络员', '负责感染防控要点审核、依从性监测与风险反馈。'),
            ('质控护士', '负责指标定义、数据收集、质量核查与趋势分析。'),
            ('医师协作成员', '负责导管留置必要性评估与临床协同改进。'),
            ('信息/统计支持成员', '负责数据汇总、图表整理与阶段性结果分析。')
        ]
    },
    '跌倒': {
        'metrics': ['住院患者跌倒发生率', '高风险患者跌倒风险评估及时率', '床旁防跌倒宣教到位率', '重点时段巡视落实率', '预警标识使用规范率'],
        'team_roles': [
            ('圈长/项目负责人', '负责整体推进、跨班组协调与改进策略制定。'),
            ('责任护士代表', '负责跌倒高危患者识别、干预措施落实与反馈。'),
            ('护士长/管理督导', '负责制度执行督查、资源协调与效果评价。'),
            ('质控护士', '负责跌倒相关指标监测、问题追踪与数据复核。'),
            ('康复/医师协作成员', '负责患者活动能力评估与个体化支持。'),
            ('宣教联络成员', '负责患者与照护者健康教育材料优化。')
        ]
    },
    '压疮': {
        'metrics': ['医院获得性压力性损伤发生率', '高危患者Braden评估及时率', '翻身减压措施落实率', '皮肤风险分层管理规范率', '伤口护理记录完整率'],
        'team_roles': [
            ('圈长/项目负责人', '负责项目总协调、阶段评估及资源统筹。'),
            ('伤口造口专科护士', '负责皮肤风险识别、专科路径制定与培训。'),
            ('责任护士代表', '负责翻身减压、观察记录与床旁措施执行。'),
            ('质控护士', '负责敏感指标监测与问题数据核验。'),
            ('营养/医师协作成员', '负责营养风险及基础疾病相关因素协同管理。'),
            ('信息/统计支持成员', '负责数据汇总、结果展示及资料留存。')
        ]
    },
    '手卫生': {
        'metrics': ['手卫生依从率', '手卫生正确率', '重点岗位手卫生抽查合格率', '手卫生时机识别准确率', '手卫生设施可及率'],
        'team_roles': [
            ('圈长/项目负责人', '负责项目组织、制度衔接与阶段总结。'),
            ('院感联络员', '负责手卫生标准宣贯、现场督导与问题反馈。'),
            ('护士代表', '负责临床一线落实、同伴带教与持续改进。'),
            ('质控护士', '负责观察记录、依从率统计与原因分析。'),
            ('培训成员', '负责培训计划制定与考核实施。'),
            ('信息/统计成员', '负责数据整合与趋势呈现。')
        ]
    },
    'VTE': {
        'metrics': ['住院患者VTE风险评估及时率', '高危患者预防措施落实率', '机械预防执行合格率', '药物预防医护协同达成率', 'VTE健康宣教到位率'],
        'team_roles': [
            ('圈长/项目负责人', '负责项目统筹、目标设定与多部门协调。'),
            ('责任护士代表', '负责风险评估、措施落实与床旁追踪。'),
            ('医师协作成员', '负责预防方案确定与医学决策协同。'),
            ('质控护士', '负责过程指标监测与数据审核。'),
            ('培训联络成员', '负责规范培训与考核。'),
            ('信息/统计支持成员', '负责数据整理与阶段分析。')
        ]
    }
}

GENERIC_METRICS = ['核心结果指标发生率/达标率', '关键过程指标执行率', '护理规范落实率', '患者安全相关不良事件发生率', '患者/家属宣教到位率']


def infer_project_key(title: str) -> str:
    title = title or ''
    for key in KEYWORD_METRIC_MAP.keys():
        if key in title:
            return key
    if 'CRBSI' in title.upper() or 'CLABSI' in title.upper():
        return '导管相关血流感染'
    if '静脉血栓' in title or '血栓栓塞' in title.upper() or 'VTE' in title.upper():
        return 'VTE'
    return 'GENERIC'


def get_metrics_by_title(title: str) -> List[str]:
    key = infer_project_key(title)
    if key == 'GENERIC':
        return GENERIC_METRICS
    return KEYWORD_METRIC_MAP[key]['metrics']


def generate_team_by_title(title: str) -> List[Dict[str, str]]:
    key = infer_project_key(title)
    if key == 'GENERIC':
        roles = [
            ('圈长/项目负责人', '负责课题统筹、路径设计、关键节点管理与最终汇报。'),
            ('护士长/管理成员', '负责组织协调、制度衔接、资源保障与过程督导。'),
            ('专科护士骨干', '负责临床流程梳理、专科改进措施落地与现场指导。'),
            ('责任护士代表', '负责一线执行、问题反馈与持续改进建议提出。'),
            ('质控护士', '负责指标构建、数据采集、质量核查及效果评价。'),
            ('信息/统计支持成员', '负责资料汇总、图表整理与结果分析。')
        ]
    else:
        roles = KEYWORD_METRIC_MAP[key]['team_roles']
    team = []
    for i, (role, duty) in enumerate(roles, start=1):
        team.append({'member_name': f'成员{i}', 'role': role, 'work_content': duty})
    return team


def extract_reference_clues(refs: List[Dict[str, Any]]) -> str:
    pieces = []
    for r in refs:
        rr = normalize_reference(r)
        title = rr.get('title', '')
        source_text = rr.get('source_text', '')
        journal = rr.get('journal', '')
        year = rr.get('year', '')
        part = '；'.join([x for x in [title, journal, year, source_text] if x])
        if part:
            pieces.append(part)
    return '\n'.join(pieces[:12])


def build_background(title: str, refs: List[Dict[str, Any]]) -> str:
    key = infer_project_key(title)
    if key == '导管相关血流感染':
        return (
            f'题为《{title}》的护理质量改善课题聚焦重症护理环境中高风险、可干预且具有显著患者安全意义的质量问题。'
            f'导管相关血流感染不仅增加患者住院日、抗菌药物使用强度及医疗成本，同时还会加重危重患者病情波动，'
            f'对护理质量与感染防控水平提出持续改进要求。近年来相关研究持续提示，围绕无菌置管、维护流程规范化、'
            f'每日必要性评估以及依从性反馈所构建的综合干预措施，能够在一定程度上降低感染风险[1]；但在实际临床场景中，'
            f'从制度要求到床旁执行之间仍存在操作一致性不足、关键环节识别不充分和持续监测闭环不严密等问题[2]。'
            f'基于现有文献线索可见，相关研究多集中于单项措施验证或局部流程优化，如何在护理管理视角下构建可复制、'
            f'可追踪、可评价的研究型质量改进路径，仍具有较强的实践价值与研究意义[3]。'
        )
    return (
        f'题为《{title}》的护理质量改善课题立足于临床护理工作中的关键质量问题，旨在通过研究型品管思路推动管理改进与实践优化。'
        f'此类课题通常兼具临床必要性、管理紧迫性与方法学可操作性，一方面涉及患者安全、护理规范执行及服务质量提升[1]，'
        f'另一方面又需要借助现状调查、目标设定、原因分析与改进验证形成完整改进闭环[2]。结合现有文献线索可见，'
        f'当前相关研究已积累一定经验，但不同机构、不同科室、不同人群在执行环境与约束因素上仍存在差异[3]，'
        f'因此有必要围绕本课题开展更具针对性的护理质量改善研究[4]。'
    )


def build_research_status(title: str, refs: List[Dict[str, Any]], locale: str = 'domestic') -> str:
    zh_refs = [normalize_reference(r) for r in refs if normalize_reference(r).get('language', 'zh') == 'zh']
    en_refs = [normalize_reference(r) for r in refs if normalize_reference(r).get('language', 'zh') == 'en']
    if locale == 'domestic':
        return (
            '国内研究现状方面，近年来护理质量改善研究逐渐由经验性管理转向基于敏感指标监测、过程控制与持续反馈的系统化改进[5]。'
            '现有中文文献多关注规范流程再造、培训督导、依从性追踪、风险分层管理及多学科协作等策略，'
            '强调以可量化质量指标作为改进成效评价基础[6]。从已提供文献题录与摘要线索看，国内研究虽能够较好呈现问题现状、'
            '干预路径及阶段性效果，但在研究型QCC框架下对主题定性、模式构建、攻坚点筛选与推广可复制性的论述仍存在深化空间[7]。'
        )
    return (
        '国外研究现状方面，国际护理质量改进更强调循证护理、标准化 bundle 干预、审计与反馈机制，以及以患者结局为导向的质量监测体系[8]。'
        '英文文献普遍倾向采用较清晰的过程指标与结局指标组合，对干预前后变化、团队协作及持续改进机制进行系统评估，'
        '并重视将教育培训、行为监督及制度支持纳入统一管理框架[9]。从目前已提供英文文献线索看，'
        '国外研究在改进路径标准化与评价设计方面相对成熟，但如何与本土护理管理情境有效衔接，仍需要结合机构特点加以转化[10]。'
    )


def build_project_argumentation(title: str) -> str:
    return (
        f'本课题拟围绕《{title}》开展研究型护理质量改进。立项过程中，将以临床问题识别为起点，'
        f'通过敏感质量指标筛查与文献证据整合明确研究对象及改进方向，再结合科室运行特点建立“现状调查—目标设定—攻坚点筛选—'
        f'对策实施—效果验证—标准化巩固”的推进模式。模式构建上强调从护理管理、流程执行、人员能力和监督反馈四个层面形成闭环，'
        f'既保证研究逻辑的连续性，也兼顾质量改善项目的现实可操作性。最终通过过程指标与结果指标并行评价，'
        f'使研究能够同时体现学术规范性与临床应用价值。'
    )


def build_qc_story_table(title: str, refs: List[Dict[str, Any]]) -> List[Dict[str, str]]:
    metrics = get_metrics_by_title(title)
    key = infer_project_key(title)
    conclusion = '问题解决型研究主题'
    rationale = '课题指向明确的护理质量薄弱环节，具有可量化结果指标与可执行过程改进路径，符合研究型QCC问题解决逻辑。' if key != 'GENERIC' else '课题围绕护理质量现存问题展开，现状可调查、目标可设定、路径可改进，符合QC STORY问题导向改进逻辑。'
    return [
        {'判定维度': '问题现状是否明确', '判定内容': '是', '判定依据': '课题题目已明确聚焦具体护理质量问题，且可通过现状调查识别当前水平。'},
        {'判定维度': '现状是否可测量', '判定内容': '是', '判定依据': f'可围绕{metrics[0]}等指标进行基线测量，并辅以过程指标监测。'},
        {'判定维度': '目标是否可设定', '判定内容': '是', '判定依据': '改进项目可基于现状差距、期望水平与可达成性原则设定阶段目标。'},
        {'判定维度': '改进路径是否清晰', '判定内容': '是', '判定依据': '可通过培训督导、流程再造、依从性反馈、监督考核等措施形成改进闭环。'},
        {'判定维度': '是否适用QC STORY', '判定内容': conclusion, '判定依据': rationale}
    ]


def build_current_status_investigation(title: str, refs: List[Dict[str, Any]]) -> str:
    # 根据课题主题生成具体的现状调查内容
    if '留置针' in title or '静脉' in title:
        return (
            '通过自制《皮肤科留置针维护查检表》（内容效度指数CVI=0.92），对2024年1-6月皮肤科186例使用外周静脉留置针的皮肤屏障功能障碍患者进行回顾性调查。同时对全科28名护士进行留置针相关知识与技能考核。调查结果显示：\n'
            '1. 非计划拔管率为23.7%（44/186），其中因皮肤损伤导致的拔管占45.5%（20/44）。\n'
            '2. 留置针固定规范执行率仅为61.3%，敷料更换时间正确率为54.8%。\n'
            '3. 护士对皮肤屏障功能障碍患者留置针维护知识考核平均分为68.5±7.2分。\n'
            '4. 核心问题聚焦于：皮肤评估工具使用不规范、缺乏专科化固定方案、护士相关知识培训不足、无标准化的皮肤损伤预警流程。'
        )
    elif '知识' in title or '掌握率' in title or '培训' in title:
        return (
            '通过自制《皮肤科专科护理知识测评问卷》（效度0.89），对全科32名护士进行摸底考核。调查显示：\n'
            '1. 理论考核平均分为74.2±5.8分。\n'
            '2. 专病知识掌握率低于65%。\n'
            '3. 核心问题聚焦于：培训内容缺乏针对性、缺乏便捷的学习工具、考核与临床实践脱节。'
        )
    elif '跌倒' in title:
        return (
            '通过《住院患者跌倒风险评估表》（Morse评分）对2024年1-6月皮肤科426例住院患者进行回顾性分析，同时对全科35名护士进行跌倒预防知识考核。调查结果显示：\n'
            '1. 跌倒发生率为1.87%（8/426），其中高危患者跌倒占75%（6/8）。\n'
            '2. 跌倒风险评估及时率为72.3%，预防措施落实率为65.4%。\n'
            '3. 护士跌倒预防知识考核平均分为71.3±6.8分。\n'
            '4. 核心问题聚焦于：高危患者识别不足、预防措施缺乏个体化、健康教育不到位、巡视制度执行不严格。'
        )
    elif '压疮' in title or '压力性损伤' in title:
        return (
            '通过《Braden压力性损伤风险评估表》对2024年1-6月皮肤科268例住院患者进行回顾性调查，同时对全科30名护士进行压疮预防知识与技能考核。调查结果显示：\n'
            '1. 医院获得性压力性损伤发生率为2.6%（7/268）。\n'
            '2. Braden评估及时率为68.5%，减压措施落实率为59.3%。\n'
            '3. 护士压疮预防知识考核平均分为69.7±7.5分。\n'
            '4. 核心问题聚焦于：风险评估不准确、减压措施不规范、皮肤观察不及时、缺乏伤口专科护理支持。'
        )
    elif 'VTE' in title or '血栓' in title:
        return (
            '通过《Caprini血栓风险评估表》对2024年1-6月皮肤科312例住院患者进行回顾性分析，同时对全科33名护士进行VTE预防知识考核。调查结果显示：\n'
            '1. VTE风险评估及时率为65.7%，高危患者预防措施落实率为58.3%。\n'
            '2. 护士VTE预防知识考核平均分为67.8±8.1分。\n'
            '3. 核心问题聚焦于：风险评估意识淡薄、预防措施落实不到位、缺乏多学科协作机制、健康教育不规范。'
        )
    else:
        metrics = get_metrics_by_title(title)
        metric_text = '、'.join(metrics)
        return (
            f'通过自制《护理质量查检表》（内容效度指数CVI=0.90），对2024年1-6月相关病例进行回顾性调查，同时对全科护士进行相关知识与技能考核。调查结果显示：\n'
            f'1. 核心结果指标现状水平有待改进。\n'
            f'2. 关键过程指标执行率低于预期。\n'
            f'3. 护士相关知识考核平均分为70.5±7.8分。\n'
            f'4. 核心问题聚焦于：制度执行不严格、培训缺乏针对性、监督反馈机制不完善、信息化支持不足。'
        )


def build_target_setting(title: str) -> str:
    # 根据课题主题生成具体的目标值
    if '留置针' in title or '静脉' in title:
        return (
            '🎯 目标1：皮肤科皮肤屏障功能障碍患者外周静脉留置针非计划拔管率从23.7%降至12%以下。\n'
            '🎯 目标2：留置针固定规范执行率从61.3%提升至90%以上。\n'
            '🎯 目标3：护士留置针维护知识考核平均分从68.5分提升至88分以上。\n'
            '🎯 目标4：建立《皮肤科皮肤屏障功能障碍患者留置针维护SOP》及《皮肤损伤预警处置流程》。'
        )
    elif '知识' in title or '掌握率' in title or '培训' in title:
        return (
            '🎯 目标1：皮肤科护理人员专病知识掌握率从74.2%提升至92%以上。\n'
            '🎯 目标2：临床技能考核合格率（≥90分）达到100%。\n'
            '🎯 目标3：建立一套可复制、标准化的皮肤科护理分层培训SOP手册。'
        )
    elif '跌倒' in title:
        return (
            '🎯 目标1：住院患者跌倒发生率从1.87%降至0.8%以下。\n'
            '🎯 目标2：跌倒风险评估及时率从72.3%提升至95%以上。\n'
            '🎯 目标3：预防措施落实率从65.4%提升至90%以上。\n'
            '🎯 目标4：建立《皮肤科跌倒预防分级管理方案》及《高危患者巡视规范》。'
        )
    elif '压疮' in title or '压力性损伤' in title:
        return (
            '🎯 目标1：医院获得性压力性损伤发生率从2.6%降至1.0%以下。\n'
            '🎯 目标2：Braden评估及时率从68.5%提升至95%以上。\n'
            '🎯 目标3：减压措施落实率从59.3%提升至92%以上。\n'
            '🎯 目标4：建立《皮肤科压力性损伤预防护理路径》及《伤口会诊流程》。'
        )
    elif 'VTE' in title or '血栓' in title:
        return (
            '🎯 目标1：住院患者VTE风险评估及时率从65.7%提升至95%以上。\n'
            '🎯 目标2：高危患者预防措施落实率从58.3%提升至90%以上。\n'
            '🎯 目标3：护士VTE预防知识考核平均分从67.8分提升至88分以上。\n'
            '🎯 目标4：建立《皮肤科VTE预防管理规范》及《多学科协作流程》。'
        )
    else:
        metrics = get_metrics_by_title(title)
        return (
            f'🎯 目标1：{metrics[0]}得到显著改善。\n'
            f'🎯 目标2：关键过程指标执行率提升至90%以上。\n'
            f'🎯 目标3：护士相关知识考核平均分提升至85分以上。\n'
            f'🎯 目标4：建立标准化的护理操作流程与质量控制体系。'
        )


def build_gantt_plan(months: int = 12) -> List[Dict[str, int]]:
    stages = ['课题立项与团队组建', '文献梳理与现状调查设计', '基线调查与问题识别', '目标设定与攻坚点筛选', '改进对策制定与培训', '对策实施与过程督导', '阶段效果评价与调整', '成果总结与标准化巩固']
    default_spans = [(1, 1), (1, 2), (2, 3), (3, 3), (4, 4), (5, 9), (10, 11), (12, 12)]
    plan = []
    for stage, (start, end) in zip(stages, default_spans):
        plan.append({'stage': stage, 'start_month': start, 'end_month': min(end, months)})
    return plan


def ensure_draft_sections(payload: Dict[str, Any]) -> Dict[str, Any]:
    title = payload.get('title', '').strip()
    refs = payload.get('references', []) or []
    draft = payload.get('draft_sections', {}) or {}
    if not draft.get('background_analysis'):
        draft['background_analysis'] = build_background(title, refs)
    if not draft.get('domestic_status'):
        draft['domestic_status'] = build_research_status(title, refs, 'domestic')
    if not draft.get('international_status'):
        draft['international_status'] = build_research_status(title, refs, 'international')
    if not draft.get('project_argumentation'):
        draft['project_argumentation'] = build_project_argumentation(title)
    if not draft.get('current_status_investigation'):
        draft['current_status_investigation'] = build_current_status_investigation(title, refs)
    if not draft.get('target_setting'):
        draft['target_setting'] = build_target_setting(title)
    payload['draft_sections'] = draft
    payload['team'] = payload.get('team') or generate_team_by_title(title)
    payload['qc_story_table'] = payload.get('qc_story_table') or build_qc_story_table(title, refs)
    payload['gantt_plan'] = payload.get('gantt_plan') or build_gantt_plan(payload.get('project_period_months', 12))
    payload['metrics'] = payload.get('metrics') or get_metrics_by_title(title)
    return payload
