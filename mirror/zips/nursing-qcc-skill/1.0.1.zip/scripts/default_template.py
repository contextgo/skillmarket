# -*- coding: utf-8 -*-

DEFAULT_OUTLINE = [
    {
        "title": "一、选题",
        "children": [
            "（一）选题背景、理由与文献分析",
            "（二）QC STORY判定主题类型"
        ]
    },
    {
        "title": "二、组织团队",
        "children": [
            "（一）团队成员组成及分工"
        ]
    },
    {
        "title": "三、课题论述",
        "children": [
            "（一）课题立项过程及模式构建"
        ]
    },
    {
        "title": "四、拟定项目推进计划",
        "children": [
            "（一）活动计划进度设计（甘特图）"
        ]
    },
    {
        "title": "五、现状调查与目标设定",
        "children": [
            "（一）现状调查",
            "（二）现状水平调查",
            "（三）明确目标值"
        ]
    },
    {
        "title": "六、参考文献",
        "children": []
    }
]
