# -*- coding: utf-8 -*-

def safe_join_authors(authors):
    if not authors:
        return '[作者不详]'
    if isinstance(authors, str):
        return authors.strip()
    return ', '.join([str(a).strip() for a in authors if str(a).strip()])


def normalize_reference(ref):
    if isinstance(ref, str):
        return {
            'authors': [], 'title': ref.strip(), 'journal': '', 'year': '',
            'volume': '', 'issue': '', 'pages': '', 'language': 'zh',
            'doi': '', 'pmid': '', 'pmcid': '', 'source_text': ref.strip(),
            'source': 'user_input', 'url': ''
        }
    return {
        'authors': ref.get('authors', []),
        'title': str(ref.get('title', '')).strip(),
        'journal': str(ref.get('journal', '')).strip(),
        'year': str(ref.get('year', '')).strip(),
        'volume': str(ref.get('volume', '')).strip(),
        'issue': str(ref.get('issue', '')).strip(),
        'pages': str(ref.get('pages', '')).strip(),
        'language': str(ref.get('language', 'zh')).strip().lower(),
        'doi': str(ref.get('doi', '')).strip(),
        'pmid': str(ref.get('pmid', '')).strip(),
        'pmcid': str(ref.get('pmcid', '')).strip(),
        'source_text': str(ref.get('source_text', '')).strip(),
        'source': str(ref.get('source', '')).strip(),
        'url': str(ref.get('url', '')).strip(),
    }


def format_gbt7714(ref, idx: int):
    r = normalize_reference(ref)
    authors = safe_join_authors(r['authors'])
    title = r['title'] or '[题名缺失]'
    journal = r['journal'] or '[刊名缺失]'
    year = r['year'] or '[年份缺失]'
    volume = r['volume']
    issue = r['issue']
    pages = r['pages']
    vol_issue = ''
    if volume and issue:
        vol_issue = f'{volume}({issue})'
    elif volume:
        vol_issue = volume
    elif issue:
        vol_issue = f'({issue})'
    tail_parts = [year]
    if vol_issue:
        tail_parts.append(vol_issue)
    tail = ', '.join(tail_parts)
    if pages:
        tail = f'{tail}: {pages}'
    text = f'[{idx}] {authors}. {title}[J]. {journal}, {tail}.'
    if r['doi']:
        text += f' DOI: {r["doi"]}.'
    return text


def format_reference_list(refs):
    normalized = [normalize_reference(r) for r in refs]
    return [format_gbt7714(r, i + 1) for i, r in enumerate(normalized)]
