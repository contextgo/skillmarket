# -*- coding: utf-8 -*-
from __future__ import annotations

import os
import re
import time
import html
import requests
from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Optional, Tuple
import xml.etree.ElementTree as ET

DEFAULT_TIMEOUT = 30
USER_AGENT = 'nursing-qcc-proposal-docx/2.1'
PUBMED_EUTILS = 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils'
EUROPEPMC_SEARCH = 'https://www.ebi.ac.uk/europepmc/webservices/rest/search'
CROSSREF_WORKS = 'https://api.crossref.org/works'

@dataclass
class LiteratureItem:
    authors: List[str]
    title: str
    journal: str
    year: str
    volume: str = ''
    issue: str = ''
    pages: str = ''
    language: str = 'en'
    doi: str = ''
    pmid: str = ''
    pmcid: str = ''
    abstract: str = ''
    source: str = ''
    source_text: str = ''
    url: str = ''
    score: float = 0.0

    def to_reference_dict(self) -> Dict[str, Any]:
        return {
            'authors': self.authors,
            'title': self.title,
            'journal': self.journal,
            'year': self.year,
            'volume': self.volume,
            'issue': self.issue,
            'pages': self.pages,
            'language': self.language,
            'doi': self.doi,
            'pmid': self.pmid,
            'pmcid': self.pmcid,
            'source_text': self.abstract or self.source_text,
            'source': self.source,
            'url': self.url,
        }


def _session() -> requests.Session:
    s = requests.Session()
    s.headers.update({'User-Agent': USER_AGENT})
    return s


def _clean_text(text: str) -> str:
    if not text:
        return ''
    text = html.unescape(text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text


def _normalize_title(title: str) -> str:
    title = (title or '').lower()
    title = re.sub(r'[^\w一-鿿]+', ' ', title)
    title = re.sub(r'\s+', ' ', title).strip()
    return title


def _guess_language(title: str, abstract: str = '', explicit: str = '') -> str:
    if explicit:
        exp = explicit.lower()
        if exp.startswith('zh') or exp in ('chi', 'chinese'):
            return 'zh'
        if exp.startswith('en') or exp in ('eng', 'english'):
            return 'en'
    sample = (title or '') + ' ' + (abstract or '')[:200]
    cjk_count = len(re.findall(r'[一-鿿]', sample))
    ascii_alpha = len(re.findall(r'[A-Za-z]', sample))
    return 'zh' if cjk_count > 4 and cjk_count >= ascii_alpha / 3 else 'en'


def _extract_year(value: Any) -> str:
    if value is None:
        return ''
    s = str(value)
    m = re.search(r'(19|20)\d{2}', s)
    return m.group(0) if m else ''


def _authors_from_crossref(item: Dict[str, Any]) -> List[str]:
    authors = []
    for a in item.get('author', []) or []:
        given = (a.get('given') or '').strip()
        family = (a.get('family') or '').strip()
        name = ' '.join([x for x in [family, given] if x]).strip() or (a.get('name') or '').strip()
        if name:
            authors.append(name)
    return authors


def _authors_from_europepmc(author_string: str) -> List[str]:
    if not author_string:
        return []
    return [p.strip() for p in re.split(r',\s*', author_string) if p.strip()][:10]


def _extract_keywords_from_title(title: str) -> List[str]:
    title = title or ''
    seeds = []
    seeds.extend(re.findall(r'[一-鿿]{2,12}', title))
    seeds.extend(re.findall(r'[A-Za-z][A-Za-z\-]{3,}', title))
    out, seen = [], set()
    for x in seeds:
        k = x.lower()
        if k not in seen:
            seen.add(k)
            out.append(x)
    return out[:12]


def build_search_profile(payload: Dict[str, Any]) -> Dict[str, Any]:
    title = payload.get('title', '')
    search_options = payload.get('search_options', {}) or {}
    refs = payload.get('references', []) or []
    keywords_zh = list(search_options.get('optional_keywords_zh', []) or [])
    keywords_en = list(search_options.get('optional_keywords_en', []) or [])
    for term in _extract_keywords_from_title(title):
        (keywords_zh if re.search(r'[一-鿿]', term) else keywords_en).append(term)
    for ref in refs[:10]:
        ref_title = ref.get('title', '') if isinstance(ref, dict) else str(ref)
        for term in _extract_keywords_from_title(ref_title):
            (keywords_zh if re.search(r'[一-鿿]', term) else keywords_en).append(term)
    def uniq(vals):
        out, seen = [], set()
        for v in vals:
            key = str(v).strip().lower()
            if key and key not in seen:
                seen.add(key)
                out.append(str(v).strip())
        return out
    return {
        'title': title,
        'target_total': int(search_options.get('target_total', 20)),
        'target_zh': int(search_options.get('target_zh', 8)),
        'target_en': int(search_options.get('target_en', 12)),
        'year_from': int(search_options.get('year_from', 2021)),
        'year_to': int(search_options.get('year_to', 2026)),
        'max_results_per_source': int(search_options.get('max_results_per_source', 30)),
        'keywords_zh': uniq(keywords_zh)[:10],
        'keywords_en': uniq(keywords_en)[:10],
    }


def _backoff_sleep(attempt: int):
    time.sleep(min(2 ** attempt, 8))


def _request_json(url: str, params: Dict[str, Any], timeout: int = DEFAULT_TIMEOUT, retries: int = 3) -> Dict[str, Any]:
    s = _session()
    for i in range(retries):
        try:
            r = s.get(url, params=params, timeout=timeout)
            if r.status_code in (429, 500, 502, 503, 504):
                _backoff_sleep(i + 1)
                continue
            r.raise_for_status()
            return r.json()
        except Exception:
            if i == retries - 1:
                raise
            _backoff_sleep(i + 1)
    return {}


def _request_text(url: str, params: Dict[str, Any], timeout: int = DEFAULT_TIMEOUT, retries: int = 3) -> str:
    s = _session()
    for i in range(retries):
        try:
            r = s.get(url, params=params, timeout=timeout)
            if r.status_code in (429, 500, 502, 503, 504):
                _backoff_sleep(i + 1)
                continue
            r.raise_for_status()
            return r.text
        except Exception:
            if i == retries - 1:
                raise
            _backoff_sleep(i + 1)
    return ''


def pubmed_esearch(term: str, year_from: int, year_to: int, retmax: int = 20, language: Optional[str] = None) -> List[str]:
    base_term = f'({term}) AND ({year_from}:{year_to}[pdat])'
    if language == 'zh':
        base_term += ' AND chinese[lang]'
    elif language == 'en':
        base_term += ' AND english[lang]'
    params = {'db': 'pubmed', 'term': base_term, 'retmax': retmax, 'retmode': 'json', 'sort': 'relevance', 'usehistory': 'n'}
    api_key = os.getenv('NCBI_API_KEY', '').strip()
    if api_key:
        params['api_key'] = api_key
    data = _request_json(f'{PUBMED_EUTILS}/esearch.fcgi', params)
    return data.get('esearchresult', {}).get('idlist', []) or []


def pubmed_efetch(pmids: List[str]) -> List[LiteratureItem]:
    if not pmids:
        return []
    params = {'db': 'pubmed', 'id': ','.join(pmids), 'retmode': 'xml'}
    api_key = os.getenv('NCBI_API_KEY', '').strip()
    if api_key:
        params['api_key'] = api_key
    xml_text = _request_text(f'{PUBMED_EUTILS}/efetch.fcgi', params)
    root = ET.fromstring(xml_text.encode('utf-8') if isinstance(xml_text, str) else xml_text)
    items = []
    for article in root.findall('.//PubmedArticle'):
        pmid = _clean_text(article.findtext('.//PMID', default=''))
        title = _clean_text(article.findtext('.//ArticleTitle', default=''))
        journal = _clean_text(article.findtext('.//Journal/Title', default=''))
        year = _extract_year(article.findtext('.//PubDate/Year', default='') or article.findtext('.//PubDate/MedlineDate', default=''))
        volume = _clean_text(article.findtext('.//JournalIssue/Volume', default=''))
        issue = _clean_text(article.findtext('.//JournalIssue/Issue', default=''))
        pages = _clean_text(article.findtext('.//Pagination/MedlinePgn', default=''))
        abstract_parts = []
        for ab in article.findall('.//Abstract/AbstractText'):
            label = ab.attrib.get('Label', '').strip()
            txt = ''.join(ab.itertext()).strip()
            abstract_parts.append(f'{label}: {txt}' if label and txt else txt)
        abstract = _clean_text(' '.join([x for x in abstract_parts if x]))
        authors = []
        for a in article.findall('.//AuthorList/Author'):
            name = _clean_text((a.findtext('CollectiveName', default='') or ' '.join([a.findtext('LastName', default='').strip(), a.findtext('ForeName', default='').strip()])).strip())
            if name:
                authors.append(name)
        doi, pmcid = '', ''
        for aid in article.findall('.//ArticleIdList/ArticleId'):
            aid_type = (aid.attrib.get('IdType') or '').lower()
            if aid_type == 'doi' and not doi:
                doi = _clean_text(''.join(aid.itertext()))
            if aid_type == 'pmc' and not pmcid:
                pmcid = _clean_text(''.join(aid.itertext()))
        lang_tag = _clean_text(article.findtext('.//Article/Language', default=''))
        items.append(LiteratureItem(authors=authors, title=title, journal=journal, year=year, volume=volume, issue=issue, pages=pages, language=_guess_language(title, abstract, explicit=lang_tag), doi=doi, pmid=pmid, pmcid=pmcid, abstract=abstract, source='pubmed', source_text=abstract, url=f'https://pubmed.ncbi.nlm.nih.gov/{pmid}/' if pmid else ''))
    return items


def search_pubmed(profile: Dict[str, Any]) -> List[LiteratureItem]:
    search_terms = [profile['title']] + profile.get('keywords_en', []) + profile.get('keywords_zh', [])
    pmids, seen = [], set()
    for term in [x for x in search_terms if x][:6]:
        lang = 'zh' if re.search(r'[一-鿿]', term) else None
        batches = [pubmed_esearch(term, profile['year_from'], profile['year_to'], retmax=profile['max_results_per_source'], language=lang)]
        if lang is None:
            batches.append(pubmed_esearch(term, profile['year_from'], profile['year_to'], retmax=profile['max_results_per_source'], language='en'))
        for batch in batches:
            for pmid in batch:
                if pmid not in seen:
                    seen.add(pmid)
                    pmids.append(pmid)
                if len(pmids) >= profile['max_results_per_source']:
                    break
            if len(pmids) >= profile['max_results_per_source']:
                break
        if len(pmids) >= profile['max_results_per_source']:
            break
    return pubmed_efetch(pmids[:profile['max_results_per_source']])


def search_europepmc(profile: Dict[str, Any]) -> List[LiteratureItem]:
    queries = []
    if profile['title']:
        queries.append(f'TITLE:"{profile["title"]}" OR TITLE_ABS:"{profile["title"]}"')
    if profile.get('keywords_en'):
        queries.append(' AND '.join([f'TITLE_ABS:"{k}"' if ' ' in k else f'TITLE_ABS:{k}' for k in profile['keywords_en'][:4]]))
    if profile.get('keywords_zh'):
        queries.append(' AND '.join([f'TITLE_ABS:"{k}"' for k in profile['keywords_zh'][:4]]))
    items, seen = [], set()
    for q in queries[:4]:
        params = {'query': f'({q}) AND (PUB_YEAR:[{profile["year_from"]} TO {profile["year_to"]}])', 'format': 'json', 'pageSize': profile['max_results_per_source'], 'sort': 'DATE_DESC', 'resultType': 'core'}
        try:
            data = _request_json(EUROPEPMC_SEARCH, params)
        except Exception:
            continue
        for r in data.get('resultList', {}).get('result', []) or []:
            ext_id = _clean_text(r.get('id', ''))
            source_db = _clean_text(r.get('source', ''))
            key = f'{source_db}:{ext_id}'
            if key in seen:
                continue
            seen.add(key)
            title_text = _clean_text(r.get('title', ''))
            abstract = _clean_text(r.get('abstractText', ''))
            items.append(LiteratureItem(authors=_authors_from_europepmc(r.get('authorString', '')), title=title_text, journal=_clean_text(r.get('journalTitle', '')), year=_extract_year(r.get('pubYear', '')), volume=_clean_text(r.get('journalVolume', '')), issue=_clean_text(r.get('issue', '')), pages=_clean_text(r.get('pageInfo', '')), language=_guess_language(title_text, abstract), doi=_clean_text(r.get('doi', '')), pmid=ext_id if source_db == 'MED' and ext_id.isdigit() else _clean_text(r.get('pmid', '')), pmcid=_clean_text(r.get('pmcid', '')), abstract=abstract, source='europepmc', source_text=abstract, url=''))
            if len(items) >= profile['max_results_per_source']:
                break
        if len(items) >= profile['max_results_per_source']:
            break
    return items[:profile['max_results_per_source']]


def search_crossref(profile: Dict[str, Any]) -> List[LiteratureItem]:
    contact_email = os.getenv('LITERATURE_CONTACT_EMAIL', '').strip()
    query_plans = []
    if profile['title']:
        query_plans.append({'query.title': profile['title']})
    if profile.get('keywords_en'):
        query_plans.append({'query.bibliographic': ' '.join(profile['keywords_en'][:5])})
    if profile.get('keywords_zh'):
        query_plans.append({'query.bibliographic': ' '.join(profile['keywords_zh'][:5])})
    items, seen = [], set()
    for q in query_plans[:4]:
        params = {**q, 'rows': profile['max_results_per_source'], 'filter': f'type:journal-article,from-pub-date:{profile["year_from"]}-01-01,until-pub-date:{profile["year_to"]}-12-31', 'sort': 'relevance', 'order': 'desc'}
        if contact_email:
            params['mailto'] = contact_email
        try:
            data = _request_json(CROSSREF_WORKS, params)
        except Exception:
            continue
        for r in data.get('message', {}).get('items', []) or []:
            doi = _clean_text(r.get('DOI', ''))
            key = doi or _normalize_title(' '.join(r.get('title', []) or []))
            if not key or key in seen:
                continue
            seen.add(key)
            title_text = _clean_text(' '.join(r.get('title', []) or []))
            abstract = _clean_text(re.sub(r'<[^>]+>', ' ', r.get('abstract', '') or ''))
            year = ''
            for node_key in ['issued', 'published-print', 'published-online']:
                node = r.get(node_key, {}) or {}
                parts = node.get('date-parts', []) if isinstance(node, dict) else []
                if parts and parts[0]:
                    year = str(parts[0][0])
                    break
            items.append(LiteratureItem(authors=_authors_from_crossref(r), title=title_text, journal=_clean_text(' '.join(r.get('container-title', []) or [])), year=year, volume=_clean_text(r.get('volume', '')), issue=_clean_text(r.get('issue', '')), pages=_clean_text(r.get('page', '')), language=_guess_language(title_text, abstract, explicit=r.get('language', '')), doi=doi, abstract=abstract, source='crossref', source_text=abstract, url=_clean_text(r.get('URL', ''))))
            if len(items) >= profile['max_results_per_source']:
                break
        if len(items) >= profile['max_results_per_source']:
            break
    return items[:profile['max_results_per_source']]


def normalize_input_references(refs: List[Any]) -> List[LiteratureItem]:
    out = []
    for ref in refs or []:
        if isinstance(ref, str):
            title = _clean_text(ref)
            out.append(LiteratureItem(authors=[], title=title, journal='', year='', language=_guess_language(title), source='user_input', source_text=title))
        elif isinstance(ref, dict):
            title = _clean_text(ref.get('title', ''))
            abstract = _clean_text(ref.get('source_text', ''))
            out.append(LiteratureItem(authors=ref.get('authors', []) or [], title=title, journal=_clean_text(ref.get('journal', '')), year=_extract_year(ref.get('year', '')), volume=_clean_text(ref.get('volume', '')), issue=_clean_text(ref.get('issue', '')), pages=_clean_text(ref.get('pages', '')), language=_guess_language(title, abstract, explicit=ref.get('language', '')), doi=_clean_text(ref.get('doi', '')), pmid=_clean_text(ref.get('pmid', '')), pmcid=_clean_text(ref.get('pmcid', '')), abstract=abstract, source=ref.get('source', 'user_input') or 'user_input', source_text=abstract, url=_clean_text(ref.get('url', ''))))
    return out


def score_item(item: LiteratureItem, profile: Dict[str, Any]) -> float:
    score = 0.0
    title_norm = _normalize_title(item.title)
    query_title_norm = _normalize_title(profile.get('title', ''))
    if query_title_norm and query_title_norm == title_norm:
        score += 12
    elif query_title_norm and query_title_norm in title_norm:
        score += 8
    title_tokens = set(title_norm.split())
    key_tokens = set()
    for k in profile.get('keywords_en', []) + profile.get('keywords_zh', []):
        key_tokens.update(_normalize_title(k).split())
    overlap = len(title_tokens & key_tokens)
    score += min(overlap * 1.5, 9)
    if item.abstract:
        score += 2
    if item.doi:
        score += 2
    if item.pmid or item.pmcid:
        score += 2
    if item.journal:
        score += 1
    if item.year.isdigit():
        score += max(0, 2026 - abs(2026 - int(item.year))) * 0.1
    if item.source == 'pubmed':
        score += 2.5
    elif item.source == 'europepmc':
        score += 2.0
    elif item.source == 'crossref':
        score += 1.5
    return round(score, 3)


def deduplicate_items(items: List[LiteratureItem]) -> List[LiteratureItem]:
    best = {}
    for item in items:
        if item.doi:
            key = f'doi:{item.doi.lower()}'
        elif item.pmid:
            key = f'pmid:{item.pmid}'
        elif item.pmcid:
            key = f'pmcid:{item.pmcid.lower()}'
        else:
            key = f'title:{_normalize_title(item.title)}'
        if not key.replace('title:', '').strip():
            continue
        current = best.get(key)
        if current is None or item.score > current.score:
            best[key] = item
    return list(best.values())


def split_by_language(items: List[LiteratureItem]) -> Tuple[List[LiteratureItem], List[LiteratureItem]]:
    zh, en = [], []
    for x in items:
        (zh if x.language == 'zh' else en).append(x)
    return zh, en


def select_targets(items: List[LiteratureItem], profile: Dict[str, Any]) -> Tuple[List[LiteratureItem], Dict[str, Any]]:
    for item in items:
        item.score = score_item(item, profile)
    items = deduplicate_items(items)
    items.sort(key=lambda x: (-x.score, -(int(x.year) if x.year.isdigit() else 0), x.title))
    zh_items, en_items = split_by_language(items)
    chosen = zh_items[:profile['target_zh']] + en_items[:profile['target_en']]
    chosen_keys = set((x.doi.lower() if x.doi else _normalize_title(x.title)) for x in chosen)
    for item in items:
        key = item.doi.lower() if item.doi else _normalize_title(item.title)
        if key in chosen_keys:
            continue
        if len(chosen) >= profile['target_total']:
            break
        chosen.append(item)
        chosen_keys.add(key)
    chosen.sort(key=lambda x: (x.language != 'zh', -x.score))
    report = {
        'selected_total': len(chosen),
        'selected_zh': sum(1 for x in chosen if x.language == 'zh'),
        'selected_en': sum(1 for x in chosen if x.language == 'en'),
        'needs_manual_cn_topup': sum(1 for x in chosen if x.language == 'zh') < profile['target_zh'],
        'target_total': profile['target_total'],
        'target_zh': profile['target_zh'],
        'target_en': profile['target_en'],
    }
    return chosen[:profile['target_total']], report


def enrich_references(payload: Dict[str, Any]) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    profile = build_search_profile(payload)
    existing = normalize_input_references(payload.get('references', []))
    auto_enabled = bool((payload.get('search_options', {}) or {}).get('enable_auto_search', False))
    auto_items = []
    source_counts = {'user_input': len(existing), 'pubmed': 0, 'europepmc': 0, 'crossref': 0}
    errors = []
    if auto_enabled:
        for source_name, func in [('pubmed', search_pubmed), ('europepmc', search_europepmc), ('crossref', search_crossref)]:
            try:
                found = func(profile)
                auto_items.extend(found)
                source_counts[source_name] = len(found)
            except Exception as e:
                errors.append({'source': source_name, 'error': str(e)})
    all_items = existing + auto_items
    selected, selected_report = select_targets(all_items, profile)
    references = [x.to_reference_dict() for x in selected]
    report = {
        'profile': profile,
        'source_counts': source_counts,
        'selected_report': selected_report,
        'errors': errors,
        'selected_items': [asdict(x) for x in selected],
    }
    return references, report
