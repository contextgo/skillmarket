---
name: nursing-qcc-proposal-docx
description: 生成护理质量改善课题研究型开题报告书，支持自动真实文献检索、QC STORY 判定表、组织团队、现状调查、GB/T 7714-2015 参考文献与可编辑 Word 导出
version: 2.1.0
author: your_name
license: MIT
metadata: {"openclaw":{"emoji":"🩺","os":["linux","darwin","win32"],"requires":{"bins":["python3"]}}}
---

# Nursing QCC Proposal DOCX Skill

## 功能说明
本技能面向护理质量改善课题研究型开题报告书的完整生成流程。
当用户提供题目、参考文献、题录、摘要、DOI、PMID 或 URL 时，本技能先整理已有文献，再在需要时自动补齐近五年真实文献，最后根据护理 QCC 研究型开题报告模板输出可编辑 Word 文档。

## 触发场景
当用户要求以下任一任务时，优先使用本技能：
- 根据题目和参考文献生成护理质量改善课题研究型开题报告
- 自动检索近五年文献并导出 Word
- 撰写选题背景、国内外研究现状、QC STORY 判定、组织团队、现状调查
- 将文献整理成 GB/T 7714-2015 格式并写入开题报告

## 模板与写作硬约束
- 严格遵循护理质量改善课题研究型开题报告模板的章节顺序
- 正文主体采用护理学教授级学术段落表达，禁止清单化堆砌
- 国内研究现状与国外研究现状必须分节独立论述
- QC STORY 判定主题必须使用表格形式输出
- 组织团队必须输出团队成员、角色定位与工作内容，人员按课题需求自动编撰
- 现状调查必须围绕课题评价指标展开，并结合文献线索形成现况调查文字
- 参考文献采用 GB/T 7714-2015 顺序编码制
- 正文引文序号必须在 Word 中显示为上标

## 输入格式
建议使用 JSON 文件，结构示例如下：

{
  "title": "课题题目",
  "department": "科室",
  "organization_name": "主体名称",
  "project_period_months": 12,
  "references": [
    {
      "authors": ["张三", "李四"],
      "title": "文献题名",
      "journal": "期刊名",
      "year": "2024",
      "volume": "59",
      "issue": "6",
      "pages": "701-706",
      "language": "zh",
      "doi": "",
      "source_text": "摘要或摘录"
    }
  ],
  "search_options": {
    "enable_auto_search": true,
    "target_total": 20,
    "target_zh": 8,
    "target_en": 12,
    "year_from": 2021,
    "year_to": 2026
  },
  "draft_sections": {
    "background_analysis": "",
    "domestic_status": "",
    "international_status": "",
    "project_argumentation": "",
    "current_status_investigation": "",
    "target_setting": ""
  }
}

## 运行步骤
1. 若用户提供 JSON 文件，直接调用脚本：
   `python3 {baseDir}/scripts/main.py --input-json-file <json路径> --output <docx路径> --auto-search`
2. 若用户只给出自然语言信息，先整理成上述 JSON 结构，再调用脚本。
3. 成功后向用户返回：Word 输出路径、文献检索报告路径、历史记录编号、是否仍需补充中文题录。

## 输出内容
- 可编辑 Word 文档（.docx）
- 文献检索报告 JSON（*_literature_report.json）
- 最近 10 条历史记录（data/history.json）
