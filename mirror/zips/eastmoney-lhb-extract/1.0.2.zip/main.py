#!/usr/bin/env python3
import requests
import pandas as pd
import time
from datetime import datetime, timedelta
import argparse
import sys


def get_previous_workday():
    """获取前一个工作日（排除周六、周日）"""
    today = datetime.now()
    delta = 1
    if today.weekday() == 0:  # 周一
        delta = 3
    elif today.weekday() == 6:  # 周日
        delta = 2
    elif today.weekday() == 5:  # 周六
        delta = 1
    prev_day = today - timedelta(days=delta)
    return prev_day.strftime('%Y-%m-%d')


class EastMoneyLHBExtractor:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36',
            'Referer': 'https://data.eastmoney.com/stock/tradedetail.html'
        })

    def get_lhb_data(self, date=None):
        """获取龙虎榜数据"""
        url = "https://datacenter-web.eastmoney.com/api/data/v1/get"
        all_data = []
        page = 1

        while True:
            params = {
                "reportName": "RPT_DAILYBILLBOARD_DETAILS",
                "columns": "ALL",
                "pageNumber": page,
                "pageSize": 500,
                "sortTypes": -1,
                "sortColumns": "TRADE_DATE",
                "source": "WEB",
                "client": "WEB"
            }

            # 如果指定了日期，在API层面过滤
            if date:
                params["filter"] = f"(TRADE_DATE='{date}')"

            try:
                response = self.session.get(url, params=params, timeout=30)
                response.raise_for_status()
                data = response.json()

                result = data.get('result')
                if result and result.get('data'):
                    page_data = result['data']
                    all_data.extend(page_data)

                    # 检查是否还有更多页
                    total_count = result.get('count', 0)
                    if len(all_data) >= total_count or len(page_data) < 500:
                        break

                    page += 1
                    time.sleep(0.2)  # 避免请求过快
                else:
                    break
            except Exception as e:
                print(f"获取龙虎榜数据失败(第{page}页): {e}")
                break

        return all_data

    def get_detail_data(self, trade_id):
        """获取单只股票的每日成交明细"""
        url = "https://datacenter-web.eastmoney.com/api/data/v1/get"
        params = {
            "reportName": "RPT_OPERATEDEPT_TRADE",
            "columns": "ALL",
            "filter": f'(TRADE_ID={trade_id})',
            "pageNumber": 1,
            "pageSize": 100,
            "source": "WEB",
            "client": "WEB"
        }

        try:
            response = self.session.get(url, params=params, timeout=30)
            response.raise_for_status()
            data = response.json()

            if data.get('result', {}).get('data'):
                return data['result']['data']
            return []
        except Exception as e:
            print(f"获取明细数据失败: {e}")
            return []

    def extract_top5_buyers(self, detail_data):
        """提取买入金额最大的前5名"""
        buyer_list = []
        for item in detail_data:
            if item.get('TRADE_DIRECTION') == '0':
                buyer_list.append(item)

        buyer_list.sort(key=lambda x: float(x.get('BUY_AMT_REAL', 0)), reverse=True)
        return buyer_list[:5]

    def export_to_excel(self, lhb_data, output_path="eastmoney_lhb.xlsx"):
        """导出数据到Excel - 匹配模板格式"""
        records = []

        for stock in lhb_data:
            security_code = stock.get('SECURITY_CODE', '')
            security_name = stock.get('SECURITY_NAME_ABBR', '')
            trade_date = stock.get('TRADE_DATE', '')
            secucode = stock.get('SECUCODE', '')
            trade_id = stock.get('TRADE_ID')

            # 提取基础数据
            close_price = stock.get('CLOSE_PRICE', '')
            change_rate = stock.get('CHANGE_RATE', '')
            billboard_net_amt = stock.get('BILLBOARD_NET_AMT', 0) / 10000 if stock.get('BILLBOARD_NET_AMT') else ''
            billboard_buy_amt = stock.get('BILLBOARD_BUY_AMT', 0) / 10000 if stock.get('BILLBOARD_BUY_AMT') else ''
            billboard_sell_amt = stock.get('BILLBOARD_SELL_AMT', 0) / 10000 if stock.get('BILLBOARD_SELL_AMT') else ''
            billboard_deal_amt = stock.get('BILLBOARD_DEAL_AMT', 0) / 10000 if stock.get('BILLBOARD_DEAL_AMT') else ''
            total_amount = stock.get('ACCUM_AMOUNT', 0) / 10000 if stock.get('ACCUM_AMOUNT') else ''
            deal_net_ratio = stock.get('DEAL_NET_RATIO', '')
            deal_amount_ratio = stock.get('DEAL_AMOUNT_RATIO', '')
            turnoverrate = stock.get('TURNOVERRATE', '')
            free_market_cap = stock.get('FREE_MARKET_CAP', 0) / 100000000 if stock.get('FREE_MARKET_CAP') else ''
            explanation = stock.get('EXPLANATION', '')

            detail_data = []
            if trade_id:
                detail_data = self.get_detail_data(trade_id)

            top5_buyers = self.extract_top5_buyers(detail_data)

            for buyer in top5_buyers:
                record = {
                    'SECUCODE': secucode,
                    '股票代码': security_code,
                    '股票名称': security_name,
                    '交易日期': trade_date,
                    '收盘价': close_price,
                    '涨跌幅': change_rate,
                    '龙虎榜净买额(万)': billboard_net_amt,
                    '龙虎榜买入额(万)': billboard_buy_amt,
                    '龙虎榜卖出额(万)': billboard_sell_amt,
                    '龙虎榜成交额(万)': billboard_deal_amt,
                    '市场总成交额(万)': total_amount,
                    '净买额占总成交比': deal_net_ratio,
                    '成交额占总成交比': deal_amount_ratio,
                    '换手率': turnoverrate,
                    '流通市值(亿)': free_market_cap,
                    '上榜原因': explanation,
                    '买方前五席': buyer.get('OPERATEDEPT_NAME', ''),
                    '买入金额(万)': buyer.get('BUY_AMT', 0),
                    '买入占总成交比例': buyer.get('BUY_RATIO', ''),
                    '卖出金额(万)': buyer.get('SELL_AMT', 0),
                    '卖出占总成交比例': buyer.get('SELL_RATIO', ''),
                    '净额(万)': buyer.get('NET', 0) / 10000 if buyer.get('NET') else 0,
                }
                records.append(record)

            if not top5_buyers:
                record = {
                    'SECUCODE': secucode,
                    '股票代码': security_code,
                    '股票名称': security_name,
                    '交易日期': trade_date,
                    '收盘价': close_price,
                    '涨跌幅': change_rate,
                    '龙虎榜净买额(万)': billboard_net_amt,
                    '龙虎榜买入额(万)': billboard_buy_amt,
                    '龙虎榜卖出额(万)': billboard_sell_amt,
                    '龙虎榜成交额(万)': billboard_deal_amt,
                    '市场总成交额(万)': total_amount,
                    '净买额占总成交比': deal_net_ratio,
                    '成交额占总成交比': deal_amount_ratio,
                    '换手率': turnoverrate,
                    '流通市值(亿)': free_market_cap,
                    '上榜原因': explanation,
                    '买方前五席': '',
                    '买入金额(万)': '',
                    '买入占总成交比例': '',
                    '卖出金额(万)': '',
                    '卖出占总成交比例': '',
                    '净额(万)': '',
                }
                records.append(record)

            time.sleep(0.2)

        if records:
            df = pd.DataFrame(records)
            columns = [
                'SECUCODE', '股票代码', '股票名称', '交易日期', '收盘价', '涨跌幅',
                '龙虎榜净买额(万)', '龙虎榜买入额(万)', '龙虎榜卖出额(万)', '龙虎榜成交额(万)',
                '市场总成交额(万)', '净买额占总成交比', '成交额占总成交比', '换手率',
                '流通市值(亿)', '上榜原因', '买方前五席',
                '买入金额(万)', '买入占总成交比例', '卖出金额(万)', '卖出占总成交比例', '净额(万)'
            ]
            df = df[columns]
            df.to_excel(output_path, index=False)
            print(f"数据已导出到: {output_path}")
            return output_path
        else:
            print("没有数据可导出")
            return None


def main():
    parser = argparse.ArgumentParser(description='东方财富龙虎榜数据提取工具')
    parser.add_argument('--date', type=str, help='交易日期 (YYYY-MM-DD)，默认为前一个工作日')
    parser.add_argument('--output', type=str, default='eastmoney_lhb.xlsx', help='输出Excel文件路径')

    args = parser.parse_args()

    extractor = EastMoneyLHBExtractor()

    target_date = args.date
    if not target_date:
        target_date = get_previous_workday()
        print(f"未指定日期，使用前一个工作日: {target_date}")

    print("正在获取龙虎榜数据...")
    lhb_data = extractor.get_lhb_data(target_date)

    if not lhb_data:
        print("未获取到龙虎榜数据，请检查日期或网络连接")
        return 1

    print(f"获取到 {len(lhb_data)} 条龙虎榜数据")

    print("正在提取明细数据并导出Excel...")
    output_file = extractor.export_to_excel(lhb_data, args.output)

    if output_file:
        return 0
    else:
        return 1


if __name__ == "__main__":
    sys.exit(main())
