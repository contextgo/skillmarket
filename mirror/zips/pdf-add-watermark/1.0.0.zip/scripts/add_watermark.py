#!/usr/bin/env python3
import io
import os
import re
import subprocess

from PyPDF2 import PdfReader, PdfWriter
from reportlab.lib.colors import gray
from reportlab.lib.pagesizes import letter
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas


def detect_chinese_font():
    """自动检测系统中的中文字体，支持更多常见字体路径"""
    # 定义不同操作系统下的常见中文字体路径
    font_candidates = {
        "Windows": [
            "C:/Windows/Fonts/simsun.ttc",  # 宋体 (SimSun)
            "C:/Windows/Fonts/msyh.ttc",  # 微软雅黑 (Microsoft YaHei)
            "C:/Windows/Fonts/simhei.ttf",  # 黑体 (SimHei)
            "C:/Windows/Fonts/kaiti.ttf",  # 楷体 (KaiTi)
            "C:/Windows/Fonts/fangsong.ttf",  # 仿宋 (FangSong)
        ],
        "Linux": [
            "/usr/share/fonts/truetype/wqy/wqy-microhei.ttc",  # 文泉驿微米黑
            "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc",  # 文泉驿正黑
            "/usr/share/fonts/truetype/droid/DroidSansFallbackFull.ttf",  # Droid Sans Fallback
            "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",  # Noto Sans CJK
            "/usr/share/fonts/truetype/arphic/uming.ttc",  # AR PL UMing
        ],
        "Darwin": [  # macOS
            "/System/Library/Fonts/PingFang.ttc",  # 苹方 (PingFang SC)
            "/Library/Fonts/Arial Unicode.ttf",  # Arial Unicode MS
            "/System/Library/Fonts/STHeiti Light.ttc",  # 华文黑体
            "/System/Library/Fonts/STHeiti Medium.ttc",  # 华文黑体
        ]
    }

    # 获取当前操作系统类型
    os_name = os.name
    if os_name == 'nt':
        system_key = "Windows"
    elif os_name == 'posix':
        # 进一步区分 Linux 和 macOS
        if os.path.exists("/System/Library/Fonts"):
            system_key = "Darwin"
        else:
            system_key = "Linux"
    else:
        system_key = None

    # 根据系统类型获取对应的字体路径列表
    paths_to_check = []
    if system_key and system_key in font_candidates:
        paths_to_check = font_candidates[system_key]

    # 如果无法确定系统或没有特定配置，尝试所有已知路径作为后备
    if not paths_to_check:
        for paths in font_candidates.values():
            paths_to_check.extend(paths)

    # 遍历检查文件是否存在
    for font_path in paths_to_check:
        if os.path.exists(font_path):
            return font_path

    ######### 如果上述方法都无法找到中文字体，采用如下方式
    if system_key != " Windows":
        try:
            # 调用 fc-list 命令获取所有字体列表，捕获标准输出
            result = subprocess.run(
                ["fc-list"],
                capture_output=True,
                text=True,
                check=True
            )
            font_list = result.stdout.splitlines()
            # 匹配关键词：微软雅黑(msyh)、文泉驿(wqy)、黑体(Micro Hei)、苹方(PingFang)、宋体(simsun)
            pattern = re.compile(r'(msyh|wqy|Micro|PingFang|simsun|Song|Hei)', re.IGNORECASE)
            for font_line in font_list:
                if pattern.search(font_line):
                    # 提取冒号前面的路径部分
                    font_path = font_line.split(":", 1)[0].strip()
                    # 确保是ttf/ttc格式的字体文件
                    if font_path.endswith(('.ttf', '.ttc', '.otf')) and os.path.exists(font_path):
                        return font_path
            return None
        except (subprocess.CalledProcessError, FileNotFoundError):
            # 系统没有fc-list命令（比如Windows），降级返回None
            return None
    return None


def add_watermark(input_pdf, output_pdf, watermark_text,
                  opacity=0.3, rotation=45, font_size=20):
    """
    给PDF添加文字水印
    :param input_pdf: 输入PDF路径
    :param output_pdf: 输出PDF路径
    :param watermark_text: 水印文字
    :param opacity: 透明度 0-1
    :param rotation: 旋转角度
    :param font_size: 字体大小
    """
    # 创建水印画布
    packet = io.BytesIO()
    can = canvas.Canvas(packet, pagesize=letter)

    # 👇 替换原来的setFont部分 👇
    chinese_font_path = detect_chinese_font()
    font_name = "Helvetica"

    if chinese_font_path:
        # 注册中文字体
        try:
            pdfmetrics.registerFont(TTFont("ChineseFont", chinese_font_path))
            font_name = "ChineseFont"
        except Exception as e:
            print(f"⚠️ 字体注册失败: {e}，使用默认字体")
    else:
        print("⚠️ 未找到中文字体，中文可能显示为方块")

    # 设置水印样式
    can.setFont(font_name, font_size)
    can.setFillColor(gray, alpha=opacity)

    # 计算水印位置（居中）
    width, height = letter
    can.saveState()
    can.translate(width / 2, height / 2)
    can.rotate(rotation)

    # 添加水印（重复覆盖整页）
    text_width = can.stringWidth(watermark_text, font_name, font_size)
    for x in range(-int(width), int(width), int(text_width * 2)):
        for y in range(-int(height), int(height), int(font_size * 3)):
            can.drawString(x, y, watermark_text)

    can.restoreState()
    can.save()

    # 移动到开始位置
    packet.seek(0)

    # 读取水印PDF
    watermark_pdf = PdfReader(packet)
    watermark_page = watermark_pdf.pages[0]

    # 读取原PDF
    original_pdf = PdfReader(input_pdf)
    output_writer = PdfWriter()

    # 加密并设置权限：禁止修改、提取内容
    output_writer.encrypt(
        user_password="123456",
        owner_password="helloworld",
        use_128bit=True,  # 128位加密
        permissions_flag=0b0011000000000000  # 权限位：禁止修改、提取内容
    )

    # 给每一页加水印
    for page in original_pdf.pages:
        page.merge_page(watermark_page)
        output_writer.add_page(page)

    # 判断文件是否存在，如果存在，先删除
    if os.path.exists(output_pdf):
        os.remove(output_pdf)

    # 保存输出
    with open(output_pdf, "wb") as f:
        output_writer.write(f)

    print(f"✅ 水印添加成功：{output_pdf}")


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--input", help="输入PDF路径")
    parser.add_argument("--output", help="输出PDF路径")
    parser.add_argument("--text", help="水印文字")
    parser.add_argument("--opacity", type=float, default=0.4, help="透明度")
    parser.add_argument("--rotation", type=int, default=35, help="旋转角度")
    parser.add_argument("--font-size", type=int, default=20, help="字体大小")
    args = parser.parse_args()
    # 1.加水印
    add_watermark(args.input, args.output, args.text,
                  args.opacity, args.rotation, args.font_size)
