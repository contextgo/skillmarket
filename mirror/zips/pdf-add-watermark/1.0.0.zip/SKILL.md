---
name: pdf_watermark
description: 给PDF文件添加自定义文字水印，支持设置水印内容、透明度、旋转角度、字体大小。Use when user needs to add watermark to PDF files, or add brand/confidential watermarks to documents.
metadata:
  {
    "openclaw":
      {
        "requires": { 
		"bins":["python","pip","fc-cache","fc-list","awk","grep"]
	}
      }
  }
---

# PDF水印添加Skill
## 使用场景
✅ 给文档添加"机密"/"内部使用"等标识，或者自定文字内容。
✅ 保护版权文档
✅ PDF添加水印
❌ 不支持图片PDF/OCR处理
❌ 不支持加密PDF

## 核心用法
python scripts/add_watermark.py --input /root/test.pdf --output /root/output.pdf --text "内部机密"


## 高级指引
如需查看依赖安装说明、中文字体配置方法、常见错误处理方案，请读取 [usage.md](references/usage.md)

