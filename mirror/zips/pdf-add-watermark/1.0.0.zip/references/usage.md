## 依赖安装
- 系统需要安装fontconfig包，用于检查系统是否包含中文字体。
- 系统需要安装python,类库需要PyPDF2、reportlab


## 脚本说明
 - scripts/add_watermark.py：PDF添加加水印脚本
 - 此代码，至少需要三个参数，分别如下：
 --input 需要加水印的pdf文件路径
 --output 添加水印后的pdf文件路径
 --text 水印文字内容


## ⚠️ 注意事项
1. 不支持加密PDF，如果遇到加密文件请先解密
2. 中文水印需要系统有中文字体，否则会显示为方块
3. 大文件处理可能需要几秒钟，请耐心等待


## 字体检测与安装
1. 中文字体检测
- 确保当前系统能使用fc-list命令，如果提示命令不存在，请先执行安装：sudo yum install fontconfig
- 检查字体执行命令：fc-list|grep -iE "wqy|msyh|Micro|黑" ，如果输出有结果，则表明支持中文字体。
2. 中文字体安装方法
- 在Fedora上，可以使用dnf命令安装：sudo dnf install wqy-microhei wqy-zenhei noto-fonts-cjk
- 在CentOS上，首先需要启用EPEL仓库执行如下命令安装：
  sudo yum install epel-release
  sudo yum install wqy-microhei wqy-zenhei google-noto-sans-cjk-fonts
- 还可以从windows字体文件夹下选择一个中文字体，上传到linux主机的 /usr/share/fonts/ 目录。
- 安装完成后执行命令：fc-cache -fv


## ❌ 常见错误处理
- `ModuleNotFoundError`：请先安装依赖 `pip install PyPDF2 reportlab`
- `PermissionError`：检查文件是否被其他程序占用
- `PdfReadError`：文件不是有效的PDF或已损坏
