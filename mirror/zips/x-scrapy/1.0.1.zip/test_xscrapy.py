#!/usr/bin/env python3
"""XScrapy v1.0 - Functional Test Suite"""
import sys
import traceback

def run_tests():
    passed = 0
    total = 8
    
    try:
        # Test 1: Models
        from xscrapy.models.data_models import (
            XScrapyConfig, CrawlMetadata, StandardItem,
        )
        config = XScrapyConfig(urls=["https://example.com"])
        meta = CrawlMetadata(task_id="t1", spider="test", source_url="https://example.com")
        item = StandardItem(metadata=meta, data={"title": "Test", "price": 299.0})
        assert item.data["title"] == "Test"
        print("[1/8] ✅ Data Models OK (Pydantic v2)")
        passed += 1

        # Test 2: Rule Parser
        from xscrapy.parsers.rule_parser import RuleBuilder
        parser = RuleBuilder().add("title", "h1::text").add("price", ".p::text").build()
        assert len(parser.rules) == 2
        print(f"[2/8] ✅ Rule Parser OK ({len(parser.rules)} rules built)")
        passed += 1

        # Test 3: Entity Extractor
        from xscrapy.parsers.entity_extractor import EntityExtractor
        ex = EntityExtractor()
        ents = ex.extract_from_text("email: test@example.com, price: 299, tel: 13812345678")
        assert len(ents) > 0, f"No entities found"
        print(f"[3/8] ✅ Entity Extractor OK (found: {list(ents.keys())})")
        passed += 1

        # Test 4: Schema Validator
        from xscrapy.parsers.schema_validator import SchemaValidator
        v = SchemaValidator({"title": {"type": "string"}})
        ok, _, _ = v.validate({"title": "Test"})
        assert ok is True
        print(f"[4/8] ✅ Schema Validator OK (valid={ok})")
        passed += 1

        # Test 5: Pipelines
        from xscrapy.pipelines.standardize_pipeline import StandardizePipeline
        from xscrapy.pipelines.clean_pipeline import CleanPipeline
        
        sp = StandardizePipeline.__new__(StandardizePipeline)
        r = sp._standardize_field_names({"heading": "Hello World"})
        assert "title" in r, f"Field mapping failed: {r}"
        
        cp = CleanPipeline()
        c_raw = cp._clean_string("  Hello   World  \n  ")
        c_cleaned = c_raw.strip()
        assert c_cleaned == "Hello World", f"Clean failed: got {c_cleaned!r}"
        
        print(f"[5/8] ✅ Pipelines OK (clean={c_cleaned!r}, heading→title={('title' in r)})")
        passed += 1

        # Test 6: URL Utils
        from xscrapy.utils.url_utils import is_valid_url, normalize_url, extract_domain
        
        a1 = is_valid_url("https://x.com")
        a2 = not is_valid_url("badurl")
        norm = normalize_url("http://Example.COM/?b=2&a=1#frag")
        dom = extract_domain("https://shop.example.com/path?q=1")
        
        assert a1 and a2 and norm == "http://example.com/?a=1&b=2" and dom == "shop.example.com"
        print("[6/8] ✅ URL Utils OK (normalize, validate, domain extraction)")
        passed += 1

        # Test 7: HTML & File Utils
        from xscrapy.utils.html_utils import strip_html, count_words
        from xscrapy.utils.file_utils import safe_filename
        
        h = strip_html("<b>Hello</b>")
        h_clean = h.strip()
        wc = count_words("Hello 世界 Test")
        sf = safe_filename("a/b<c>d.txt")
        
        assert h_clean == "Hello", f"strip_html failed: {h_clean!r}"
        assert wc == 5, f"count_words failed: {wc}"
        assert "/" not in sf and "<" not in sf and ">" not in sf, f"safe_filename failed: {sf!r}"
        
        print(f"[7/8] ✅ HTML & File Utils OK (html={h_clean!r}, words={wc}, safe={sf!r})")
        passed += 1

        # Test 8: Core Engine & Spider Factory
        from xscrapy.core.settings import build_scrapy_settings
        from xscrapy.core.spider_factory import SpiderFactory
        
        s = build_scrapy_settings(config)
        types = SpiderFactory.available_types()
        assert len(types) >= 3, f"Not enough spider types: {types}"
        
        print(f"[8/8] ✅ Core Engine OK ({len(types)} spider types: {types})")
        passed += 1

    except Exception as e:
        print(f"\n❌ TEST FAILED at step {passed + 1}: {e}")
        traceback.print_exc()
        return False
    
    return True


if __name__ == "__main__":
    print("=" * 60)
    print("  XScrapy v1.0 — Complete Functional Test Suite")
    print("=" * 60)
    
    success = run_tests()
    
    print()
    if success:
        print("=" * 60)
        print("  🎉 ALL TESTS PASSED! XScrapy ready to run.")
        print("=" * 60)
        sys.exit(0)
    else:
        print("❌ Some tests failed.")
        sys.exit(1)
