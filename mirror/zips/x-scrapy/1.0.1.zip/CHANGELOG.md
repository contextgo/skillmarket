# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2026-04-07

### 🎉 Initial Release

#### Added
- **Core Engine**: AI-Native 爬虫引擎，基于 Scrapy 2.14 + Pydantic v2，零配置智能数据提取
- **5 大场景支持**: 电商 / 新闻 / 社交媒体 / 论坛 / 文档 — 自动检测页面类型并匹配最佳提取策略
- **AI 增强解析**: 集成 LLM 智能解析兜底（规则优先 + AI 兜底双模式）
- **Playwright 渲染**: 支持 JS 动态渲染页面的完整抓取（SPA / SSR / 混合渲染）
- **反检测中间件**: User-Agent 轮换、指纹伪装、请求头随机化
- **代理管理**: HTTP/SOCKS5 代理池支持，自动轮换与故障转移
- **限速控制**: 自适应下载延迟 + 并发限制 + 域级限速
- **多层 Pipeline 架构**:
  - 清洗 Pipeline（HTML 标签清理、空白压缩）
  - 去重 Pipeline（内容指纹去重、URL 去重）
  - 富化 Pipeline（AI 摘要生成、实体识别、情感分析）
  - 校验 Pipeline（Schema 校验、必填字段检查）
  - 标准化 Pipeline（字段归一化、类型转换）
- **多格式导出**: JSON / NDJSON（行式JSON） / CSV / Webhook 回调
- **CLI 工具集**:
  - `xscrapy run <url>` — 一键抓取
  - `xscrapy extract <url> --fields title,content` — 字段提取
  - `xscrapy templates` — 场景模板浏览与管理
  - `xscrapy check` — 环境自检（Python / Scrapy / AI / Playwright）
- **10+ 内置场景模板**: 电商商品、新闻文章、社交媒体帖子、论坛帖子、招聘信息等
- **配置系统**: YAML 配置文件 + CLI 参数覆盖 + 环境变量三级优先级
- **调试模式**: Rich 终端可视化输出（表格 / 进度条 / 日志着色）
- **完整测试套件**: 单元测试 + E2E 端到端测试
- **SKILL.md**: 完整的 Skill 定义文件，兼容 WorkBuddy / OpenClaw 平台加载

### Technical Stack
- Python 3.11+
- Scrapy 2.14.2
- Pydantic v2
- Playwright (optional)
- Typer (CLI framework)
- Rich (terminal UI)
- orjson (high-performance JSON)
