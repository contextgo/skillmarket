# XScrapy — AI-Native 通用爬虫引擎 Skill

> **项目价值定位：百万级爬虫基础设施**
> 一个基于 Scrapy 的 AI 增强型通用爬虫 Skill，能够智能识别网页结构、自动提取结构化数据、输出标准化 JSON。

---

## 一、核心痛点分析

| 痛点 | 传统方案 | XScrapy 方案 |
|------|---------|-------------|
| 每个目标站都要写专用 Spider | 大量重复代码 | 通用 Spider + 配置驱动 |
| 页面结构变化导致爬虫失效 | 手动维护 CSS/XPath | AI 自适应解析 |
| 反爬机制越来越强 | 频繁被 ban | 多层反检测策略 |
| 数据格式混乱 | 各字段命名不一 | 标准化 JSON Schema |
| 动态渲染页面（JS/SPA） | 需要 Selenium/Playwright | 内置多种渲染引擎适配 |
| 非结构化文本提取困难 | 正则表达式地狱 | LLM 智能抽取 |

## 二、XScrapy 架构设计

```
┌─────────────────────────────────────────────────────────────────┐
│                         XScrapy Skill                           │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌──────────────┐   ┌──────────────┐   ┌────────────────────┐  │
│  │  CLI 入口     │   │  API 接口     │   │  Skill 触发器      │  │
│  │  xscrapy run │   │  REST/GraphQL│   │  Agent 调用        │  │
│  └──────┬───────┘   └──────┬───────┘   └────────┬───────────┘  │
│         │                  │                    │              │
│         └──────────────────┼────────────────────┘              │
│                            ▼                                    │
│                 ┌────────────────────┐                          │
│                 │   任务调度器        │                          │
│                 │  (Task Scheduler)  │                          │
│                 └────────┬───────────┘                          │
│                          ▼                                      │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │                   Spider 引擎层                          │    │
│  ├─────────────────────────────────────────────────────────┤    │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌─────────┐  │    │
│  │  │通用Spider│  │列表Spider│  │详情Spider│  │自定义SP │  │    │
│  │  │Universal │  │ List     │  │ Detail   │  │Custom   │  │    │
│  │  └──────────┘  └──────────┘  └──────────┘  └─────────┘  │    │
│  └─────────────────────────────────────────────────────────┘    │
│                          │                                      │
│          ┌───────────────┼───────────────┐                      │
│          ▼               ▼               ▼                      │
│  ┌──────────────┐ ┌───────────┐ ┌────────────────┐            │
│  │ 下载中间件    │ │ 渲染引擎  │ │ 反爬中间件      │            │
│  │ - 重试       │ │ - Static  │ │ - UA轮换       │            │
│  │ - 超时       │ │ - JS Render│ │ - Cookie管理   │            │
│  │ - 代理       │ │ - Playwright│ │ - 速率限制    │            │
│  │ - 缓存       │ │           │ │ - 验证码处理   │            │
│  └──────────────┘ └───────────┘ └────────────────┘            │
│                          │                                      │
│                          ▼                                      │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │                   解析管线 (Pipeline)                     │    │
│  ├─────────────────────────────────────────────────────────┤    │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────────┐  │    │
│  │  │规则匹配解析  │  │ AI智能解析  │  │ 数据清洗/标准化 │  │    │
│  │  │CSS/XPath    │  │ LLM Extract │  │ Schema Validate │  │    │
│  │  │Regex        │  │ Entity Rec  │  │ Type Convert    │  │    │
│  │  └─────────────┘  └─────────────┘  └─────────────────┘  │    │
│  └─────────────────────────────────────────────────────────┘    │
│                          │                                      │
│                          ▼                                      │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │                   输出管道 (Exporter)                     │    │
│  ├─────────────────────────────────────────────────────────┤    │
│  │  Standard JSON │ CSV │ Database │ Stream │ Webhook       │    │
│  └─────────────────────────────────────────────────────────┘    │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

## 三、功能模块详解

### 3.1 核心模块

#### Module 1: Universal Spider（通用爬虫）
- **零配置启动**：给定 URL 自动识别页面类型（列表页/详情页/搜索页）
- **自动分页**：识别分页模式（下一页/加载更多/无限滚动）
- **链接发现**：自动发现并跟踪同域相关链接
- **配置模板**：内置电商、新闻、社交、论坛、文档等场景模板

#### Module 2: AI Parser（AI 智能解析器）
- 基于语义的字段提取（而非依赖脆弱的 DOM 结构）
- 实体识别（人名、日期、价格、地址、邮箱、电话等）
- 自动 Schema 推断和生成
- 支持自定义提取 Prompt
- 结果置信度评分

#### Module 3: Anti-Detection Suite（反检测套件）
- 浏览器指纹伪装（真实浏览器指纹库）
- 请求间隔随机化（模拟人类行为）
- User-Agent 池自动轮换
- Cookie Jar 自动管理
- 代理池集成（支持 HTTP/SOCKS5）
- CAPTCHA 处理接口预留

#### Module 4: Rendering Engine（渲染引擎适配）
- **Level 0**: 纯 HTTP（静态页面，最快）
- **Level 1**: Scrapy-Splash（轻量 JS 渲染）
- **Level 2**: Playwright（完整浏览器，SPA 支持）

#### Module 5: Data Pipeline（数据管线）
- 字段重命名与映射
- 类型转换与校验
- 去重（URL级 / 内容级 / 哈希级）
- 数据补全与富化
- 标准化输出 Schema

#### Module 6: Export Engine（输出引擎）
- 标准 JSON（带元数据：来源URL、抓取时间、置信度）
- NDJSON（流式，适合大数据量）
- CSV / Excel
- 数据库直写（SQLite / PostgreSQL / MongoDB）
- Webhook 回调
- 文件下载（图片/PDF/附件）

### 3.2 高级特性

| 特性 | 描述 |
|------|------|
| 🔄 增量爬取 | 基于 URL 去重 + 时间戳，只抓新内容 |
| 🔍 智能发现 | 从种子 URL 自动发现同站点相关页面 |
| 📊 实时监控 | 抓取进度、成功率、数据量实时统计 |
| ⚡ 并发控制 | 自适应并发，根据响应时间动态调整 |
| 💾 断点续爬 | 任务中断后可从断点恢复 |
| 🛡️ 合规模式 | 自动尊重 robots.txt + 自定义抓取规则 |
| 🎯 目标提取 | 只提取用户关心的字段，忽略噪音 |

## 四、技术选型

| 组件 | 技术选择 | 理由 |
|------|---------|------|
| 核心 | Python 3.11+ / Scrapy 2.12+ | 成熟稳定，生态丰富 |
| AI 解析 | OpenAI API / 本地模型双支持 | 灵活可切换 |
| JS 渲染 | Playwright（异步） | 比 Selenium 快 10x |
| 代理 | scrapy-proxy-pool + 自定义 | 支持多代理源 |
| 配置 | YAML + JSON Schema | 可读性强 + 可校验 |
| 输出 | orjson（高性能JSON） | 比标准库快 5-10x |
| CLI | Typer（现代 CLI 框架） | 自动生成帮助信息 |
| 日志 | structlog（结构化日志） | 便于调试和分析 |

## 五、标准输出格式

```json
{
  "metadata": {
    "task_id": "xscrapy_20260407_163000",
    "spider": "universal",
    "source_url": "https://example.com/product/123",
    "crawled_at": "2026-04-07T16:30:00+08:00",
    "render_mode": "playwright",
    "confidence_score": 0.95,
    "version": "1.0.0"
  },
  "data": {
    "title": "产品名称",
    "price": 299.00,
    "currency": "CNY",
    "description": "产品描述文本...",
    "images": ["https://cdn.example.com/img1.jpg"],
    "category": "电子产品",
    "brand": "品牌名",
    "rating": 4.8,
    "review_count": 1234,
    "in_stock": true,
    "specs": {
      "颜色": "黑色",
      "尺寸": "15.6英寸",
      "重量": "1.8kg"
    },
    "seller": {
      "name": "店铺名",
      "rating": 4.9,
      "location": "广东深圳"
    }
  },
  "_links": {
    "related_urls": [],
    "next_page": null
  }
}
```

## 六、使用场景示例

### 场景1: 电商价格监控
```bash
xscrapy run --url "https://shop.example.com/item/123" \
  --template ecommerce \
  --fields title,price,stock,rating \
  --output results.json
```

### 场景2: 新闻聚合
```bash
xscrapy run --url "https://news.example.com/tech" \
  --template news \
  --max-pages 20 \
  --render js \
  --ai-extract true \
  --output news_feed.jsonl
```

### 场景3: 竞品分析
```bash
xscrapy run --urls competitor_urls.txt \
  --template custom \
  --schema schema.yaml \
  --concurrent 5 \
  --delay 2 \
  --output competitor_analysis.json
```

## 七、项目文件结构

```
xscrapy/
├── SKILL.md                    # Skill 定义文件（Agent 触发入口）
├── README.md                   # 项目说明文档
├── pyproject.toml              # 项目配置与依赖
├── requirements.txt            # Python 依赖
├── config/
│   ├── templates/              # 场景模板
│   │   ├── ecommerce.yaml
│   │   ├── news.yaml
│   │   ├── social.yaml
│   │   ├── forum.yaml
│   │   ├── docs.yaml
│   │   └── custom.yaml
│   ├── user_agents.json        # UA 池
│   └── default.yaml            # 默认配置
├── xscrapy/
│   ├── __init__.py
│   ├── cli.py                  # CLI 入口（Typer）
│   ├── core/
│   │   ├── __init__.py
│   │   ├── engine.py           # 核心引擎
│   │   ├── spider_factory.py   # Spider 工厂
│   │   ├── scheduler.py        # 任务调度器
│   │   └── settings.py         # 全局设置
│   ├── spiders/
│   │   ├── __init__.py
│   │   ├── universal.py        # 通用 Spider
│   │   ├── list_spider.py      # 列表页 Spider
│   │   ├── detail_spider.py    # 详情页 Spider
│   │   └── base.py             # Spider 基类
│   ├── parsers/
│   │   ├── __init__.py
│   │   ├── rule_parser.py      # 规则解析器
│   │   ├── ai_parser.py        # AI 智能解析器
│   │   ├── entity_extractor.py # 实体提取器
│   │   └── schema_validator.py # Schema 校验器
│   ├── middlewares/
│   │   ├── __init__.py
│   │   ├── anti_detect.py      # 反检测中间件
│   │   ├── proxy_rotator.py    # 代理轮换
│   │   ├── rate_limiter.py     # 速率限制
│   │   ├── render_middleware.py# 渲染控制
│   │   └── cache_middleware.py # 缓存中间件
│   ├── pipelines/
│   │   ├── __init__.py
│   │   ├── clean_pipeline.py   # 清洗管道
│   │   ├── dedup_pipeline.py   # 去重管道
│   │   ├── enrich_pipeline.py  # 富化管道
│   │   ├── validate_pipeline.py# 校验管道
│   │   └── standardize_pipeline.py # 标准化管道
│   ├── exporters/
│   │   ├── __init__.py
│   │   ├── json_exporter.py    # JSON 导出
│   │   ├── ndjson_exporter.py  # NDJSON 导出
│   │   ├── csv_exporter.py     # CSV 导出
│   │   ├── database_exporter.py # 数据库导出
│   │   └── webhook_exporter.py # Webhook 导出
│   ├── utils/
│   │   ├── __init__.py
│   │   ├── url_utils.py        # URL 工具
│   │   ├── html_utils.py       # HTML 工具
│   │   ├── file_utils.py       # 文件工具
│   │   └── ai_client.py        # AI 客户端封装
│   └── models/
│       ├── __init__.py
│       ├── data_models.py      # 数据模型
│       ├── config_models.py    # 配置模型
│       └── response_models.py  # 响应模型
├── tests/
│   ├── __init__.py
│   ├── test_parsers/
│   ├── test_pipelines/
│   ├── test_middlewares/
│   ├── test_exporters/
│   └── fixtures/              # 测试用 HTML 固件
├── examples/
│   ├── basic_crawl.py          # 基础示例
│   ├── ecommerce_demo.py       # 电商示例
│   ├── news_aggregator.py      # 新闻聚合示例
│   └── ai_extraction_demo.py   # AI 提取示例
└── scripts/
    ├── setup.sh                # 环境初始化
    └── quick_start.py          # 快速开始脚本
```

## 八、设计原则

1. **Convention over Configuration** — 有合理默认值，零配置即可运行
2. **Progressive Enhancement** — 简单场景简单用，复杂场景有扩展能力
3. **Fail Gracefully** — 单个页面失败不影响整体任务
4. **Observable** — 丰富的日志和指标，方便 debug
5. **Extensible** — 所有组件可替换、可插拔
6. **AI-First** — AI 不是附加功能，而是核心能力
7. **Output-First** — 标准化 JSON 是一等公民

---

*文档版本: v1.0*
*创建时间: 2026-04-07*
*作者: XScrapy Team*
