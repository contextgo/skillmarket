# XScrapy — AI-Native 通用爬虫引擎

> 🕷️ 零配置智能爬取 · AI 增强解析 · 标准化 JSON 输出
> 
> 基于 [Scrapy](https://scrapy.org/) 构建，集成 LLM 智能解析能力。

## ✨ 特性

| 能力 | 描述 |
|------|------|
| 🧠 **零配置启动** | 给个 URL 就能跑，自动识别页面类型 |
| 🤖 **AI 增强解析** | 规则提取不到？LLM 兜底，智能补全 |
| 🛡️ **反检测套件** | UA 轮换、指纹伪装、自适应限速 |
| 🌐 **多渲染模式** | 静态 / Splash / Playwright 三级切换 |
| 📊 **标准化输出** | 统一 JSON Schema，含元数据和置信度 |
| 🔗 **智能发现** | 自动分页、链接跟踪、增量更新 |
| ⚡ **高性能** | 异步并发、断点续爬、流式 NDJSON 导出 |
| 🔌 **可扩展** | 所有组件可插拔、可替换 |

## 🚀 快速开始

```bash
# 安装
cd xscrapy && pip install -e .

# 最简用法
xscrapy run https://example.com

# 指定模板
xscrapy run https://shop.com/item/123 --template ecommerce

# AI 增强模式
xscrapy run https://complex-page.com --ai

# 检查环境
xscrapy check
```

## 📖 完整文档

详见 [SKILL.md](./SKILL.md) — 包含完整的使用指南、API 参考、架构设计、场景模板等。

## 🏗️ 项目结构

```
xscrapy/
├── SKILL.md              # Skill 定义 & 使用文档
├── README.md             # 本文件
├── PLAN.md               # 架构设计与技术方案
├── pyproject.toml        # 项目配置
├── requirements.txt      # Python 依赖
│
├── xscrapy/
│   ├── cli.py            # CLI 入口 (Typer)
│   ├── core/             # 核心引擎
│   │   ├── engine.py     # 任务编排器
│   │   ├── settings.py   # Scrapy 设置映射
│   │   └── spider_factory.py
│   ├── spiders/          # Spider 层
│   │   ├── universal.py  # ★ 通用 Spider（核心）
│   │   ├── list_spider.py
│   │   ├── detail_spider.py
│   │   └── base.py
│   ├── parsers/          # 解析管线
│   │   ├── rule_parser.py      # CSS/XPath/Regex 规则解析
│   │   ├── ai_parser.py         # ★ LLM 智能解析
│   │   ├── entity_extractor.py  # 命名实体提取
│   │   └── schema_validator.py  # 数据校验
│   ├── middlewares/      # 中间件
│   │   ├── anti_detect.py       # 反检测（UA/指纹/延迟）
│   │   ├── proxy_rotator.py     # 代理轮换
│   │   ├── rate_limiter.py      # 自适应限速
│   │   ├── render_middleware.py # 渲染控制
│   │   └── cache_middleware.py  # 智能缓存
│   ├── pipelines/        # 处理管线
│   │   ├── clean_pipeline.py       # 数据清洗
│   │   ├── dedup_pipeline.py       # URL/内容去重
│   │   ├── enrich_pipeline.py      # 信息富化
│   │   ├── validate_pipeline.py    # 质量校验
│   │   └── standardize_pipeline.py # 字段标准化
│   ├── exporters/        # 输出管道
│   │   ├── json_exporter.py    # 标准 JSON
│   │   ├── ndjson_exporter.py  # 流式 JSON Lines
│   │   ├── csv_exporter.py     # CSV
│   │   └── webhook_exporter.py # Webhook/DB
│   ├── utils/            # 工具函数
│   │   ├── url_utils.py    # URL 工具
│   │   ├── html_utils.py   # HTML 工具
│   │   ├── file_utils.py   # 文件工具
│   │   └── ai_client.py    # AI 客户端封装
│   └── models/           # 数据模型 (Pydantic v2)
│       ├── data_models.py      # 核心模型
│       ├── config_models.py    # 配置模型
│       └── response_models.py  # API 响应模型
│
├── tests/              # 测试用例
├── examples/           # 使用示例
└── config/templates/   # 场景模板
```

## 📋 开发计划

- [x] 核心架构设计与规划
- [x] 数据模型 (Pydantic v2)
- [x] 核心引擎与任务调度
- [x] Universal Spider（通用爬虫，含自动分类、Schema.org、启发式提取）
- [x] List Spider / Detail Spider
- [x] 规则解析器 (RuleParser + RuleBuilder)
- [x] AI 智能解析器 (AIParser)
- [x] 命名实体提取器
- [x] Schema 校验器
- [x] 反检测中间件
- [x] 代理轮换中间件
- [x] 速率限制中间件
- [x] 缓存中间件
- [x] 数据清洗/去重/富化/校验/标准化 Pipeline
- [x] JSON / NDJSON / CSV / Webhook 导出器
- [x] CLI 入口 (Typer + Rich)
- [ ] 测试用例编写
- [ ] 更多场景模板
- [ ] 分布式爬取支持
- [ ] Web UI 监控面板

## License

MIT License © XScrapy Team
