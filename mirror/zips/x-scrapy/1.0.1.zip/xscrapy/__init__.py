"""
XScrapy — AI-Native 通用爬虫引擎
零配置智能爬取 · 标准化 JSON 输出
"""

__version__ = "1.0.0"
__author__ = "XScrapy Team"

from xscrapy.core.engine import XScrapyEngine
from xscrapy.cli import app

__all__ = ["XScrapyEngine", "app", "__version__"]
