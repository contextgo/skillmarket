"""Pipelines package init"""

from xscrapy.pipelines.clean_pipeline import CleanPipeline
from xscrapy.pipelines.dedup_pipeline import DedupPipeline
from xscrapy.pipelines.enrich_pipeline import EnrichPipeline
from xscrapy.pipelines.validate_pipeline import ValidatePipeline
from xscrapy.pipelines.standardize_pipeline import StandardizePipeline

__all__ = [
    "CleanPipeline", "DedupPipeline", "EnrichPipeline",
    "ValidatePipeline", "StandardizePipeline",
]
