"""
富化管道 — 补充数据的额外信息
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any
from urllib.parse import urlparse

from xscrapy.parsers.entity_extractor import EntityExtractor

logger = logging.getLogger(__name__)


class EnrichPipeline:
    """
    数据富化管道
    
    自动补充：
    - 从 URL 提取域名、路径等信息
    - 添加抓取时间戳
    - 补充实体识别结果
    - 计算文本统计指标
    """

    def __init__(self, settings=None):
        self.entity_extractor = EntityExtractor()

    @classmethod
    def from_crawler(cls, crawler):
        return cls(crawler.settings)

    def process_item(self, item: Any, spider) -> Any:
        """富化数据项"""
        has_data_attr = hasattr(item, 'data')
        data = getattr(item, 'data', item) if has_data_attr else (item.get('data') if isinstance(item, dict) and 'data' in item else {})
        if not isinstance(data, dict):
            return item

        # URL 信息补全
        url = data.get("url", "") or (
            item.metadata.source_url if hasattr(item, 'metadata') else ""
        )
        if url and "domain" not in data:
            parsed = urlparse(url)
            data["domain"] = parsed.netloc
            if parsed.path and "path" not in data:
                data["path"] = parsed.path
            if parsed.query and "query" not in data:
                data["query_params"] = parsed.query

        # 文本统计
        body = data.get("body_text") or data.get("article_body") or data.get("description") or ""
        if body and "word_count" not in data:
            data["word_count"] = len(body.split())
            data["char_count"] = len(body)
            data["sentence_count_approx"] = len([s for s in body.split('。') if s])

        # 实体提取
        entities = self.entity_extractor.extract_from_dict(data)
        if entities and "_entities" not in data:
            data["_entities"] = entities

        # 语言检测（简单启发式）
        text_sample = (data.get("title") or "") + " " + (data.get("description") or "")
        if len(text_sample) > 10 and "language" not in data:
            cn_chars = sum(1 for c in text_sample if '\u4e00' <= c <= '\u9fff')
            total_chars = sum(1 for c in text_sample if c.isalpha())
            if total_chars > 0 and cn_chars / total_chars > 0.3:
                data["language"] = "zh"
            elif total_chars > 0:
                data["language"] = "en"

        return item
