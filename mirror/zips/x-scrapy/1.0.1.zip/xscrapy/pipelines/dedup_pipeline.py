"""
去重管道 — URL 级和内容级去重
"""

from __future__ import annotations

import hashlib
import logging
from typing import Any

from scrapy import Item

logger = logging.getLogger(__name__)


class DedupPipeline:
    """
    去重管道
    
    支持三级去重：
    1. URL 级：相同 URL 只保留一条
    2. 内容哈希级：相同内容只保留一条
    3. 字段组合级：指定字段组合唯一性
    """

    def __init__(self, settings=None):
        self._seen_urls: set[str] = set()
        self._seen_hashes: set[str] = set()
        self._seen_keys: set[str] = set()
        self.dedup_mode = "url" if settings is None else settings.get("XSCRAPY_DEDUP_MODE", "url")
        self.dedup_fields: list[str] | None = None
        self.stats = {"total_in": 0, "duplicates_dropped": 0}

    @classmethod
    def from_crawler(cls, crawler):
        pipeline = cls(crawler.settings)
        fields_str = crawler.settings.get("XSCRAPY_DEDUP_FIELDS")
        if fields_str:
            pipeline.dedup_fields = [f.strip() for f in fields_str.split(",")]
        return pipeline

    def process_item(self, item: Any, spider) -> Any:
        """去重处理"""
        self.stats["total_in"] += 1
        data = getattr(item, 'data', {})
        
        # URL 去重
        url = data.get("url") or (item.metadata.source_url if hasattr(item, 'metadata') else "")
        if url and url in self._seen_urls:
            self.stats["duplicates_dropped"] += 1
            logger.debug(f"URL 去重跳过: {url[:80]}")
            raise DropItem("Duplicate URL")
        
        if url:
            self._seen_urls.add(url)
        
        # 内容哈希去重
        content_hash = self._compute_hash(data)
        if content_hash in self._seen_hashes:
            self.stats["duplicates_dropped"] += 1
            logger.debug(f"内容哈希去重跳过: {content_hash}")
            raise DropItem("Duplicate content")
        
        self._seen_hashes.add(content_hash)
        
        # 字段组合去重
        if self.dedup_fields:
            key_parts = []
            for f in self.dedup_fields:
                val = data.get(f)
                if val is not None:
                    key_parts.append(str(val))
            
            combo_key = "|".join(key_parts)
            if combo_key in self._seen_keys:
                self.stats["duplicates_dropped"] += 1
                logger.debug(f"字段组合去重跳过: {combo_key[:80]}")
                raise DropItem("Duplicate field combination")
            
            self._seen_keys.add(combo_key)
        
        return item

    @staticmethod
    def _compute_hash(data: dict[str, Any]) -> str:
        """计算数据的内容哈希（基于关键字段）"""
        important_fields = ["title", "description", "body_text", "url"]
        hash_input = ""
        for field in important_fields:
            val = data.get(field)
            if val:
                hash_input += str(val)[:200]
        
        return hashlib.sha256(hash_input.encode()).hexdigest()[:16]

    def get_stats(self) -> dict:
        """返回去重统计"""
        stats_copy = dict(self.stats)
        stats_copy["unique_urls"] = len(self._seen_urls)
        stats_copy["unique_content"] = len(self._seen_hashes)
        return stats_copy


class DropItem(Exception):
    """丢弃项目信号"""
    pass
