"""
清洗管道 — 清理提取的原始数据
"""

from __future__ import annotations

import re
import logging
from typing import Any

from scrapy import Item

logger = logging.getLogger(__name__)


class CleanPipeline:
    """
    数据清洗管道
    
    功能：
    - 去除多余空白和不可见字符
    - 处理 HTML 实体
    - 截断过长文本
    - 统一空值表示
    """

    def __init__(self, settings=None):
        self.max_text_length = 50000 if settings is None else settings.getint("XSCRAPY_MAX_TEXT_LENGTH", 50000)

    @classmethod
    def from_crawler(cls, crawler):
        return cls(crawler.settings)

    def process_item(self, item: Any, spider) -> Any:
        """清洗数据项"""
        # 判断 item 结构
        has_data_attr = hasattr(item, 'data')
        data = getattr(item, 'data', item) if has_data_attr else item
        
        if isinstance(data, dict):
            cleaned = self._clean_dict(data)
            if has_data_attr:
                # Pydantic model 或有 .data 属性的对象
                try:
                    item.data = cleaned
                except Exception:
                    pass
                return item
            elif isinstance(item, dict) and 'data' in item:
                # 标准 dict 格式: {"metadata": ..., "data": {...}, "links": ...}
                item['data'] = cleaned
                return item
            else:
                # item 本身就是裸数据 dict
                return cleaned
        
        return item

    def _clean_dict(self, d: dict[str, Any], depth: int = 0) -> dict[str, Any]:
        """递归清洗字典"""
        result: dict[str, Any] = {}
        
        for key, value in d.items():
            # 跳过空键
            clean_key = key.strip() if isinstance(key, str) else key
            
            match value:
                case str():
                    cleaned_value = self._clean_string(value)
                    if cleaned_value or cleaned_value == "":
                        result[clean_key] = cleaned_value
                case list():
                    cleaned_list = [self._clean_string(v) if isinstance(v, str) else v for v in value]
                    result[clean_key] = cleaned_list
                case dict():
                    if depth < 5:  # 防止无限递归
                        result[clean_key] = self._clean_dict(value, depth + 1)
                    else:
                        result[clean_key] = value
                case _:
                    result[clean_key] = value
                    
        return result

    def _clean_string(self, s: str) -> str:
        """清洗单个字符串"""
        if not s:
            return ""
        
        # 去除控制字符（保留换行和制表）
        s = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]', '', s)
        
        # 压缩连续空白为单个空格
        s = re.sub(r'[ \t]+', ' ', s)
        
        # 去除首尾空白
        s = s.strip()
        
        # 解码常见 HTML 实体
        html_entities = {
            "&nbsp;": " ", "&amp;": "&", "&lt;": "<", "&gt;": ">",
            "&quot;": '"', "&#39;": "'", "&mdash;": "—", "&ndash;": "–",
            "&hellip;": "…", "&copy;": "©", "&reg;": "®",
        }
        for entity, char in html_entities.items():
            s = s.replace(entity, char)
        
        # 截断超长文本
        if len(s) > self.max_text_length:
            logger.warning(f"文本截断: 原长 {len(s)} -> {self.max_text_length}")
            s = s[:self.max_text_length]
            
        return s
