"""
校验管道 — 数据质量校验
"""

from __future__ import annotations

import logging
from typing import Any

from xscrapy.parsers.schema_validator import SchemaValidator

logger = logging.getLogger(__name__)


class ValidatePipeline:
    """
    数据校验管道
    
    对每条数据进行基本质量检查：
    - 必要字段是否存在
    - 数据格式是否合理
    - 标记低质量数据但默认不丢弃
    """

    def __init__(self, settings=None):
        self.schema = {}  # 可通过配置加载 schema
        self.validator = SchemaValidator(self.schema)
        self.strict_mode = False if settings is None else settings.getbool("XSCRAPY_STRICT_VALIDATION", False)

    @classmethod
    def from_crawler(cls, crawler):
        return cls(crawler.settings)

    def process_item(self, item: Any, spider) -> Any:
        """校验数据项"""
        has_data_attr = hasattr(item, 'data')
        data = getattr(item, 'data', item) if has_data_attr else (item.get('data') if isinstance(item, dict) and 'data' in item else {})
        
        warnings = []

        # === 基础质量检查 ===
        
        # 标题不能太短或太奇怪
        title = data.get("title", "")
        if title:
            if len(title) < 2:
                warnings.append(f"标题异常短: '{title}'")
            elif title.lower() in ("404", "not found", "error", "访问受限", "页面不存在"):
                warnings.append(f"标题显示错误页: {title}")

        # 正文不能是纯脚本代码
        body = data.get("body_text", "")
        if body:
            script_ratio = body.count("<script") + body.count("var ") + body.count("function ")
            if len(body) > 100 and script_ratio > 10:
                warnings.append("正文可能包含大量脚本代码")

        # URL 格式
        url = data.get("url", "")
        if url and not url.startswith(("http://", "https://")):
            warnings.append(f"URL 格式异常: {url}")

        # 价格合理性
        price = data.get("price")
        if price is not None:
            try:
                p = float(price)
                if p < 0:
                    warnings.append(f"价格为负数: {p}")
                elif p > 100000000:
                    warnings.append(f"价格异常高: {p}")
            except (TypeError, ValueError):
                warnings.append(f"价格格式异常: {price}")

        # Schema 校验（如果配置了）
        if self.schema:
            is_valid, errors, _ = self.validator.validate(data)
            warnings.extend(errors)

        # 记录警告但不丢弃
        if warnings:
            if hasattr(item, 'metadata'):
                # 将警告存入元数据
                item.metadata.model_dump()  # no-op but validates
            logger.debug(f"数据校验警告 ({data.get('url','?')[:50]}): {warnings}")
            if hasattr(item, '_warnings'):
                item._warnings.extend(warnings)

        # 严格模式下，有严重问题则丢弃
        if self.strict_mode and any(
            "错误页" in w or "负" in w or "异常高" in w 
            for w in warnings
        ):
            from xscrapy.pipelines.dedup_pipeline import DropItem
            raise DropItem(f"严格模式丢弃: {'; '.join(warnings)}")

        return item
