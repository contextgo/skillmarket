"""Debug Pipeline — 在 pipeline 链中记录 item 状态"""

import logging

logger = logging.getLogger(__name__)


class DebugPipeline:
    """调试用：在所有其他 pipeline 之前检查 item 原始状态"""

    def __init__(self, settings=None):
        pass

    @classmethod
    def from_crawler(cls, crawler):
        return cls(crawler.settings)

    def process_item(self, item, spider):
        logger.info(f"[DEBUG-PIPE] Item received! type={type(item).__name__}")
        if isinstance(item, dict):
            logger.info(f"[DEBUG-PIPE] dict keys: {list(item.keys())[:10]}")
            for k in list(item.keys())[:5]:
                v = item.get(k)
                logger.info(f"  [DEBUG-PIPE]   {k}: type={type(v).__name__}, preview={str(v)[:100]}")
        elif hasattr(item, 'data'):
            logger.info(f"[DEBUG-PIPE] has .data attr, data keys: {list(getattr(item,'data',{}).keys())[:10]}")
        return item


class DebugPipelineLate:
    """调试用：在 JsonExportPipeline 之前检查 item 状态"""

    def __init__(self, settings=None):
        pass

    @classmethod
    def from_crawler(cls, crawler):
        return cls(crawler.settings)

    def process_item(self, item, spider):
        logger.info(f"[DEBUG-LATE] Pre-export item! type={type(item).__name__}")
        if isinstance(item, dict):
            logger.info(f"[DEBUG-LATE] dict keys: {list(item.keys())[:10]}, id={id(item)}")
        return item
