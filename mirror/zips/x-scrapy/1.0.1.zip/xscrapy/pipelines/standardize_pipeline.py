"""
标准化管道 — 将数据转换为统一的标准格式输出
"""

from __future__ import annotations

import logging
from typing import Any
from datetime import datetime, timezone

from scrapy import Item

logger = logging.getLogger(__name__)

# 字段名标准化映射（将各种可能的命名映射到标准名）
FIELD_ALIASES = {
    # 标题
    "heading": "title",
    "headline": "title",
    "name": "title",
    "product_name": "title",
    "product_title": "title",
    "page_title": "title",
    
    # 内容
    "content": "body_text",
    "text": "body_text",
    "main_content": "body_text",
    "full_text": "body_text",
    "post_body": "body_text",
    "detail": "description",
    "abstract": "description",
    "summary": "description",
    
    # 价格
    "cost": "price",
    "amount": "price",
    "current_price": "price",
    "sale_price": "price",
    
    # 图片
    "image": "images",
    "photo": "images",
    "picture": "images",
    "thumbnail": "images",
    
    # 时间
    "date": "published_date",
    "pub_date": "published_date",
    "publish_time": "published_date",
    "created_at": "published_date",
    "time": "published_date",
    
    # 作者
    "writer": "author",
    "byline": "author",
    "creator": "author",
}


class StandardizePipeline:
    """
    标准化管道
    
    将不同来源的字段名统一到 XScrapy 标准字段集，
    并确保所有数据类型一致。
    """

    def __init__(self, settings=None):
        self.include_metadata = True if settings is None else settings.getbool(
            "XSCRAPY_OUTPUT_INCLUDE_METADATA", True
        )

    @classmethod
    def from_crawler(cls, crawler):
        return cls(crawler.settings)

    def process_item(self, item: Any, spider) -> Any:
        """标准化数据项"""
        # 兼容两种格式: {"metadata":..., "data":...} dict 或有 .data 属性的对象
        has_data_attr = hasattr(item, 'data')
        data = getattr(item, 'data', item) if has_data_attr else (item.get('data') if isinstance(item, dict) and 'data' in item else {})
        
        if not isinstance(data, dict):
            return item

        # 1. 字段名标准化
        standardized = self._standardize_field_names(dict(data))

        # 2. 类型标准化
        standardized = self._standardize_types(standardized)

        # 3. 排序字段顺序（重要字段在前）
        ordered = self._order_fields(standardized)

        if has_data_attr:
            # Pydantic model 或有 .data 属性的对象
            try:
                item.data = ordered
            except Exception:
                pass
            return item
        elif isinstance(item, dict) and 'data' in item:
            # 标准 XScrapy dict 格式，保留 metadata 和 links
            item['data'] = ordered
            return item
        else:
            # 裸数据 dict（不应该发生但防御性处理）
            return ordered

        return item

    def _standardize_field_names(self, data: dict[str, Any]) -> dict[str, Any]:
        """将别名字段名映射为标准名"""
        result: dict[str, Any] = {}
        
        for key, value in data.items():
            # 检查是否是已知别名
            standard_name = FIELD_ALIASES.get(key.lower().strip(), key)
            
            if standard_name in result:
                # 已存在同名标准字段，合并或用更长的值
                existing = result[standard_name]
                new_val_len = len(str(value)) if value else 0
                existing_val_len = len(str(existing)) if existing else 0
                
                if new_val_len > existing_val_len:
                    result[standard_name] = value
                elif key != standard_name:  # 保留原始字段
                    result[key] = value
            else:
                result[standard_name] = value
                
        return result

    def _standardize_types(self, data: dict[str, Any]) -> dict[str, Any]:
        """确保数据类型一致"""
        for key, value in list(data.items()):
            if value is None:
                continue

            # 确保 images 是列表
            if key == "images" and isinstance(value, str):
                data[key] = [value]

            # 确保 keywords/tags 是列表
            if key in ("keywords", "tags", "internal_links", "external_links"):
                if isinstance(value, str):
                    data[key] = [v.strip() for v in value.split(",")]
                elif not isinstance(value, list):
                    data[key] = [value]

            # 确保布尔类型
            if key == "in_stock" and isinstance(value, str):
                data[key] = value.lower() in ("true", "yes", "1", "有货", "in stock")

        return data

    def _order_fields(self, data: dict[str, Any]) -> dict[str, Any]:
        """按重要性排序字段"""
        priority_order = [
            "title", "url", "domain", "description", "body_text",
            "author", "published_date", "price", "currency", "brand",
            "category", "images", "rating", "review_count", "in_stock",
            "keywords", "tags", "language", "word_count",
            "specs", "comments", "related_items",
            "internal_links", "external_links", "_entities",
        ]
        
        ordered: dict[str, Any] = {}
        
        # 先放优先字段
        for field in priority_order:
            if field in data:
                ordered[field] = data.pop(field)
        
        # 再放剩余字段
        remaining = sorted(data.keys())
        for field in remaining:
            ordered[field] = data[field]
        
        return ordered
