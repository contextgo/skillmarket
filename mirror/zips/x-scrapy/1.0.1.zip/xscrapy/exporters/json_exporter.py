"""
JSON 导出管道 — 标准格式 JSON 输出（简化可靠版）
"""

from __future__ import annotations

import json
import logging
import os
import threading
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger(__name__)

# 模块级全局存储 — 不依赖实例状态
_global_items: list[dict] = []
_global_lock = threading.Lock()
_output_file: str = ""


class JsonExportPipeline:
    """
    标准 JSON 导出管道
    
    使用模块级变量存储数据，确保在 Scrapy Pipeline 单例模式下
    所有方法调用都能访问到同一份数据。
    """

    def __init__(self, settings):
        global _output_file
        self.file_path: Optional[str] = settings.get("XSCRAPY_OUTPUT_PATH") or None
        self.pretty: bool = settings.getbool("XSCRAPY_OUTPUT_PRETTY", True)
        self.encoding: str = settings.get("XSCRAPY_OUTPUT_ENCODING", "utf-8")
        self.include_metadata: bool = settings.getbool(
            "XSCRAPY_OUTPUT_INCLUDE_METADATA", True
        )
        
        if not self.file_path:
            output_dir = Path.cwd() / "xscrapy_output"
            output_dir.mkdir(exist_ok=True)
            self.file_path = str(output_dir / "result.json")
        
        _output_file = self.file_path

    @classmethod
    def from_crawler(cls, crawler):
        return cls(crawler.settings)

    @classmethod
    def reset(cls) -> None:
        """重置全局存储（每次新任务前调用）"""
        global _global_items
        with _global_lock:
            _global_items = []

    @staticmethod
    def get_collected() -> list[dict]:
        """获取已收集的所有数据"""
        with _global_lock:
            return list(_global_items)

    def open_spider(self, spider) -> None:
        """爬虫开始 — 重置存储"""
        self.reset()
        logger.info(f"JSON 导出管道就绪 -> {self.file_path}")

    def process_item(self, item: Any, spider) -> Any:
        """收集数据项"""
        # DEBUG: 看 item 到底长什么样
        logger.info(f"[DEBUG] process_item: type={type(item).__name__}, dir={dir(item)[:200]}")
        if hasattr(item, 'get'):
            logger.info(f"[DEBUG] process_item: has get, keys={list(item.keys())[:10]}")
            for k in list(item.keys())[:5]:
                v = item.get(k)
                logger.info(f"[DEBUG]   key={k}, value type={type(v).__name__}, value_preview={str(v)[:80]}")
        
        # 序列化为纯 dict
        if hasattr(item, 'model_dump'):
            serialized = item.model_dump() if self.include_metadata else getattr(item, 'data', {})
        elif isinstance(item, dict):
            serialized = dict(item)
        else:
            serialized = {"raw": str(item)}
        
        # 写入全局存储
        with _global_lock:
            _global_items.append(serialized)
            
        return item

    def close_spider(self, spider) -> None:
        """爬虫结束 — 写入文件"""
        with _global_lock:
            items = list(_global_items)
        
        count = len(items)
        
        # DEBUG: 打印实际数据
        logger.info(f"[DEBUG] close_spider: items count={count}, type={type(items)}")
        for i, it in enumerate(items[:2]):
            logger.info(f"[DEBUG] item[{i}] type={type(it)}, keys={list(it.keys()) if isinstance(it, dict) else 'N/A'}")
            if isinstance(it, dict):
                for k, v in list(it.items())[:5]:
                    logger.info(f"  [{i}] {k}: type={type(v).__name__}, value_preview={str(v)[:100]}")
        
        if not items:
            logger.warning("没有数据可导出")
            return
        
        file_path = Path(self.file_path or _output_file)
        file_path.parent.mkdir(parents=True, exist_ok=True)

        # 先用标准 json（最可靠）
        indent = 2 if self.pretty else None
        try:
            content = json.dumps(items, ensure_ascii=False, indent=indent, default=str)
            raw_bytes = content.encode(self.encoding)
            logger.info(f"[DEBUG] json.dumps success: bytes_len={len(raw_bytes)}")
        except Exception as e:
            logger.error(f"序列化失败: {e}")
            raw_bytes = b"[]"
            logger.error(f"  error detail: {type(e).__name__}: {e}")

        with open(file_path, "wb") as f:
            f.write(raw_bytes)

        size_kb = len(raw_bytes) / 1024
        logger.info(f"✅ JSON 导出完成 | 文件: {file_path} | 记录数: {count} | 大小: {size_kb:.1f}KB")
