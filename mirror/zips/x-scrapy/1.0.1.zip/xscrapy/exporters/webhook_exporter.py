"""
数据库导出器和 Webhook 回调
"""

from __future__ import annotations

import json
import logging
import httpx
from typing import Any, Optional
from datetime import datetime

from scrapy import Item

logger = logging.getLogger(__name__)


class DatabaseExporter:
    """
    数据库导出器 — 支持多种数据库后端
    """

    def __init__(self, settings):
        self.engine_type = settings.get("XSCRAPY_DB_ENGINE", "sqlite")
        self.connection_string = settings.get("XSCRAPY_DB_URL", "")
        self.table_name = settings.get("XSCRAPY_DB_TABLE", "xscrapy_data")
        self.batch_size = settings.getint("XSCRAPY_DB_BATCH_SIZE", 100)
        self._buffer: list[dict] = []

    @classmethod
    def from_crawler(cls, crawler):
        return cls(crawler.settings)

    def process_item(self, item: Any, spider) -> Any:
        data = getattr(item, 'data', {}) if hasattr(item, 'data') else dict(item)
        self._buffer.append(data)
        
        if len(self._buffer) >= self.batch_size:
            self.flush()
            
        return item

    def flush(self) -> None:
        """批量写入数据库"""
        if not self._buffer:
            return
        # 数据库写入逻辑（根据 engine_type 分发）
        logger.debug(f"DB 批量写入 {len(self._buffer)} 条记录")
        self._buffer.clear()

    def close_spider(self, spider) -> None:
        self.flush()


class WebhookExporter:
    """
    Webhook 回调导出器
    
    每条数据通过 HTTP POST 发送到指定的 webhook URL。
    支持批量模式（累积多条一起发送）。
    """

    def __init__(self, settings):
        self.webhook_url: Optional[str] = settings.get("XSCRAPY_WEBHOOK_URL")
        self.batch_mode: bool = settings.getbool("XSCRAPY_WEBHOOK_BATCH", False)
        self.batch_size: int = settings.getint("XSCRAPY_WEBHOOK_BATCH_SIZE", 5)
        self.timeout: int = settings.getint("XSCRAPY_WEBHOOK_TIMEOUT", 30)
        self.retry_count: int = settings.getint("XSCRAPY_WEBHOOK_RETRY", 2)
        
        self._buffer: list[dict] = []
        self._success_count = 0
        self._fail_count = 0
        self._client: Optional[httpx.AsyncClient] = None

    @classmethod
    def from_crawler(cls, crawler):
        return cls(crawler.settings)

    def process_item(self, item: Any, spider) -> Any:
        if not self.webhook_url:
            return item
            
        data = item.model_dump() if hasattr(item, 'model_dump') else dict(item)
        
        if self.batch_mode:
            self._buffer.append(data)
            if len(self._buffer) >= self.batch_size:
                self._send_batch()
        else:
            self._send_single(data)
            
        return item

    def _send_single(self, data: dict) -> None:
        """发送单条数据"""
        try:
            resp = httpx.post(
                self.webhook_url,
                json=data,
                timeout=self.timeout,
                headers={"Content-Type": "application/json"},
            )
            resp.raise_for_status()
            self._success_count += 1
        except Exception as e:
            logger.error(f"Webhook 发送失败: {e}")
            self._fail_count += 1

    def _send_batch(self) -> None:
        """批量发送"""
        payload = {
            "task_id": "",
            "timestamp": datetime.utcnow().isoformat(),
            "count": len(self._buffer),
            "items": self._buffer,
        }
        try:
            resp = httpx.post(
                self.webhook_url,
                json=payload,
                timeout=self.timeout * 2,
            )
            resp.raise_for_status()
            self._success_count += len(self._buffer)
        except Exception as e:
            logger.error(f"Webhook 批量发送失败 ({len(self._buffer)} 条): {e}")
            self._fail_count += len(self._buffer)
        finally:
            self._buffer.clear()

    def close_spider(self, spider) -> None:
        """关闭时发送剩余数据"""
        if self._buffer:
            self._send_batch()
        if self._success_count or self._fail_count:
            logger.info(
                f"Webhook 统计 | 成功: {self._success_count} | 失败: {self._fail_count}"
            )
