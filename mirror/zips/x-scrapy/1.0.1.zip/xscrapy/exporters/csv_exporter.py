"""
CSV 导出器
"""

from __future__ import annotations

import csv
import logging
import os
from pathlib import Path
from typing import Any

from scrapy import Item

logger = logging.getLogger(__name__)


class CsvExportPipeline:
    """
    CSV 导出器
    
    自动推断字段名并写入标准 CSV。
    嵌套对象会被展平。
    """

    def __init__(self, settings):
        self.file_path: str = (
            settings.get("XSCRAPY_OUTPUT_PATH", "").replace(".json", ".csv")
            or ""
        )
        if not self.file_path:
            output_dir = Path.cwd() / "xscrapy_output"
            output_dir.mkdir(exist_ok=True)
            self.file_path = str(output_dir / f"result_{os.getpid()}.csv")

        self.encoding = settings.get("XSCRAPY_OUTPUT_ENCODING", "utf-8-sig")  # BOM for Excel
        self._fields: set[str] = set()
        self._rows: list[dict] = []
        self._writer = None
        self._file_handle = None
        self._header_written = False

    @classmethod
    def from_crawler(cls, crawler):
        return cls(crawler.settings)

    def open_spider(self, spider) -> None:
        Path(self.file_path).parent.mkdir(parents=True, exist_ok=True)
        self._file_handle = open(self.file_path, "w", newline="", encoding=self.encoding)
        logger.info(f"CSV 导出就绪 -> {self.file_path}")

    def process_item(self, item: Any, spider) -> Any:
        data = getattr(item, 'data', {})
        if isinstance(data, dict):
            flattened = self._flatten(data)
            self._fields.update(flattened.keys())
            self._rows.append(flattened)
            
            # 动态添加新列（如果之前已写 header）
            if self._header_written and self._writer:
                new_fields = flattened.keys() - self._fields
                # CSV 无法真正动态加列，但记录日志
                if new_fields:
                    logger.debug(f"发现新字段: {new_fields}")
                    
        return item

    def _flatten(self, d: dict[str, Any], prefix: str = "") -> dict:
        """扁平化嵌套字典"""
        result = {}
        for k, v in d.items():
            key = f"{prefix}.{k}" if prefix else k
            if isinstance(v, dict):
                result.update(self._flatten(v, key))
            elif isinstance(v, list):
                result[key] = "|".join(str(x)[:100] for x in v[:10])
            else:
                result[key] = v
        return result

    def close_spider(self, spider) -> None:
        if not self._file_handle or not self._rows:
            if self._file_handle:
                self._file_handle.close()
            return

        all_fields = sorted(self._fields)
        self._writer = csv.DictWriter(self._file_handle, fieldnames=all_fields, extrasaction="ignore")
        self._writer.writeheader()
        
        for row in self._rows:
            self._writer.writerow({k: self._to_str(v) for k, v in row.items()})
        
        self._file_handle.close()
        logger.info(f"✅ CSV 导出完成 | 行数: {len(self._rows)} | 列数: {len(all_fields)} | 文件: {self.file_path}")

    @staticmethod
    def _to_str(value) -> str:
        if value is None:
            return ""
        if isinstance(value, (list, dict)):
            import orjson as json
            try:
                return json.dumps(value).decode()
            except Exception:
                return str(value)
        return str(value)
