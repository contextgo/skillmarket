"""
NDJSON (JSON Lines) 导出器 — 流式输出，适合大数据量
"""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import Any, Optional

from scrapy import Item

logger = logging.getLogger(__name__)


class NdjsonExportPipeline:
    """
    NDJSON 流式导出
    
    每行一条 JSON 记录，适合：
    - 大数据量场景（内存高效）
    - 实时流处理
    - 与 jq 等工具链配合使用
    """

    def __init__(self, settings):
        self.file_path: Optional[str] = (
            settings.get("XSCRAPY_OUTPUT_PATH", "").replace(".json", ".ndjson")
            or None
        )
        if not self.file_path:
            output_dir = Path.cwd() / "xscrapy_output"
            output_dir.mkdir(exist_ok=True)
            self.file_path = str(output_dir / f"result_{os.getpid()}.ndjson")
        
        self.encoding = settings.get("XSCRAPY_OUTPUT_ENCODING", "utf-8")
        self.include_metadata = settings.getbool("XSCRAPY_OUTPUT_INCLUDE_METADATA", True)
        self._file_handle = None
        self._count = 0

    @classmethod
    def from_crawler(cls, crawler):
        return cls(crawler.settings)

    def open_spider(self, spider) -> None:
        """打开文件准备写入"""
        Path(self.file_path).parent.mkdir(parents=True, exist_ok=True)
        self._file_handle = open(self.file_path, "w", encoding=self.encoding)
        logger.info(f"NDJSON 流式导出就绪 -> {self.file_path}")

    def process_item(self, item: Any, spider) -> Any:
        """逐条写入"""
        if not self._file_handle:
            return item
        
        try:
            if hasattr(item, 'model_dump'):
                data = item.model_dump() if self.include_metadata else getattr(item, 'data', {})
            elif isinstance(item, dict):
                data = item
            else:
                data = dict(item)
                
            line = json.dumps(data, ensure_ascii=False)
            self._file_handle.write(line + "\n")
            self._file_handle.flush()
            self._count += 1
            
        except Exception as e:
            logger.error(f"NDJSON 写入失败: {e}")
            
        return item

    def close_spider(self, spider) -> None:
        """关闭文件"""
        if self._file_handle:
            self._file_handle.close()
            logger.info(f"✅ NDJSON 导出完成 | 记录数: {self._count} | 文件: {self.file_path}")
