"""
XScrapy 核心引擎 — 任务编排与执行入口
"""

from __future__ import annotations

import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from scrapy.crawler import CrawlerProcess
from scrapy.utils.log import configure_logging
from scrapy.utils.project import get_project_settings
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TimeElapsedColumn

from xscrapy.core.settings import build_scrapy_settings
from xscrapy.models.data_models import (
    BatchCrawlResult,
    OutputFormat,
    XScrapyConfig,
)

console = Console()


class XScrapyEngine:
    """
    XScrapy 核心引擎
    
    职责：
    - 接收配置并初始化爬虫任务
    - 管理 Scrapy CrawlerProcess 的生命周期
    - 汇总抓取结果并输出标准格式
    """

    def __init__(self, config: XScrapyConfig):
        self.config = config
        self.task_id = config.task_id or f"xscrapy_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"
        config.task_id = self.task_id
        self.result: Optional[BatchCrawlResult] = None
        self._start_time: float = 0

    def run(self) -> BatchCrawlResult:
        """执行爬取任务"""
        if not self.config.urls:
            raise ValueError("至少需要提供一个目标 URL")

        self.result = BatchCrawlResult(task_id=self.task_id)
        self.result.total_urls = len(self.config.urls)
        from datetime import timezone as _tz
        now = datetime.now(_tz.utc)
        self.result.started_at = now
        self._start_time = time.time()

        console.print(f"\n[bold blue]🔍 XScrapy v1.0[/bold blue] — 任务 [cyan]{self.task_id}[/cyan]")
        console.print(f"   目标 URL 数量: {len(self.config.urls)}")
        console.print(f"   渲染模式: {self.config.render_mode.value}")
        console.print(f"   AI 解析: {'✅ 已启用' if self.config.ai.enabled else '❌ 未启用'}")
        console.print(f"   输出格式: {self.config.output.format.value}")
        console.print()

        if self.config.dry_run:
            console.print("[yellow]⚠️  干运行模式 — 不发送实际请求[/yellow]")
            self._dry_run()
            return self.result

        # 构建设置
        scrapy_settings = build_scrapy_settings(self.config)
        
        # 将配置传递给 Spider
        scrapy_settings.set("XSCRAPY_CONFIG", self.config)
        scrapy_settings.set("TASK_ID", self.task_id)
        # 注意: 不设置 FEED_URI/FEED_FORMAT，由我们的 JsonExportPipeline 控制输出

        # 初始化 Scrapy 进程
        configure_logging({"LOG_LEVEL": self.config.log_level})
        process = CrawlerProcess(settings=scrapy_settings)

        # 创建并添加 Spider（Scrapy 2.14+ 需要传 class）
        from xscrapy.spiders.universal import UniversalSpider
        process.crawl(
            UniversalSpider,
            urls=self.config.urls,
            config=self.config,
            task_id=self.task_id,
        )

        # 执行爬取
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TimeElapsedColumn(),
            console=console,
        ) as progress:
            task = progress.add_task("[cyan]正在爬取...", total=None)
            process.start()  # This blocks until crawling is finished
            progress.update(task, completed=True)

        # 从 Pipeline 回收结果
        from xscrapy.exporters.json_exporter import JsonExportPipeline
        pipeline_items = JsonExportPipeline.get_collected()
        
        if pipeline_items:
            from xscrapy.models.data_models import CrawlMetadata, StandardItem
            for item_dict in pipeline_items:
                meta_data = item_dict.get("metadata", {})
                data = item_dict.get("data", {})
                links = item_dict.get("links", {})
                if meta_data and data:
                    try:
                        meta = CrawlMetadata(**meta_data) if isinstance(meta_data, dict) else meta_data
                        std_item = StandardItem(metadata=meta, data=data)
                        self.result.items.append(std_item)
                        self.result.success_count += 1
                    except Exception as e:
                        logger.warning(f"结果回收失败: {e}")
                        self.result.items.append(item_dict)
                        self.result.success_count += 1

        # 完成结果
        self._finalize_result()

        return self.result

    def _dry_run(self) -> None:
        """干运行模式 — 只展示计划不实际执行"""
        for url in self.config.urls:
            item_data = {
                "_dry_run": True,
                "url": url,
                "template": self.config.template or "auto",
                "fields": self.config.fields or ["auto"],
            }
            console.print(f"  📋 计划爬取: [link]{url}[/link]")

        self.result.success_count = len(self.config.urls)
        self.result.finalize()
        self._save_output()

    def _get_feed_uri(self) -> str:
        """构建 Scrapy Feed URI"""
        if self.config.output.file_path:
            path = Path(self.config.output.file_path)
            path.parent.mkdir(parents=True, exist_ok=True)
            return str(path.absolute())

        default_name = f"{self.task_id}.{self._get_extension()}"
        return str(Path.cwd() / "output" / default_name)

    def _get_feed_format(self) -> str:
        """获取 Scrapy Feed 格式"""
        mapping = {
            OutputFormat.JSON: "json",
            OutputFormat.NDJSON: "jsonlines",
            OutputFormat.CSV: "csv",
        }
        return mapping.get(self.config.output.format, "json")

    def _get_extension(self) -> str:
        """获取输出文件扩展名"""
        mapping = {
            OutputFormat.JSON: "json",
            OutputFormat.NDJSON: "ndjson",
            OutputFormat.CSV: "csv",
        }
        return mapping.get(self.config.output.format, "json")

    def _finalize_result(self) -> None:
        """最终化结果"""
        if self.result:
            self.result.finalize()
            
            elapsed = time.time() - self._start_time
            
            console.print("\n[bold green]✅ 爬取完成![/bold green]")
            console.print(f"   总计: {self.result.total_urls} 个 URL")
            console.print(f"   成功: [green]{self.result.success_count}[/green]")
            console.print(f"   失败: [red]{self.result.failed_count}[/red]" if self.result.failed_count else "   失败: 0")
            console.print(f"   数据条目: [bold]{len(self.result.items)}[/bold] 条")
            console.print(f"   耗时: [yellow]{elapsed:.2f}s[/yellow]")
            
            if self.config.output.file_path:
                console.print(f"   输出文件: [cyan]{self.config.output.file_path}[/cyan]")

            self._save_output()

    def _save_output(self) -> None:
        """保存输出"""
        if not self.result:
            return

        output_config = self.config.output
        
        match output_config.format:
            case OutputFormat.JSON | OutputFormat.NDJSON:
                self._export_json(output_config)
            case OutputFormat.CSV:
                self._export_csv(output_config)
            case _:
                pass  # database / webhook handled by pipeline

    def _export_json(self, output_config: OutputConfig) -> None:
        """导出 JSON/NDJSON"""
        import orjson as json

        file_path = output_config.file_path or self._default_output_path()
        Path(file_path).parent.mkdir(parents=True, exist_ok=True)

        data = []
        for item in self.result.items:
            if output_config.include_metadata:
                data.append(item.model_dump())
            else:
                data.append(item.data)

        mode = "w"
        indent = 2 if output_config.pretty else None
        
        if output_config.format == OutputFormat.NDJSON:
            lines = [json.dumps(d).decode() for d in data]
            content = "\n".join(lines) + "\n" if lines else ""
        else:
            content = json.dumps(data, option=json.OPT_INDENT_2 if indent else 0).decode()

        with open(file_path, "w", encoding=output_config.encoding) as f:
            f.write(content)

        console.print(f"\n💾 结果已保存至: [cyan]{file_path}[/cyan] ({len(data)} 条记录)")

    def _export_csv(self, output_config: OutputConfig) -> None:
        """导出 CSV"""
        import csv
        import io

        file_path = output_config.file_path or self._default_output_path(".csv")
        Path(file_path).parent.mkdir(parents=True, exist_ok=True)

        if not self.result.items:
            return

        # 收集所有字段
        all_fields: set[str] = set()
        for item in self.result.items:
            all_fields.update(item.data.keys())
        
        fields = sorted(all_fields)

        with open(file_path, "w", newline="", encoding=output_config.encoding) as f:
            writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
            writer.writeheader()
            for item in self.result.items:
                row = {k: self._flatten_value(v) for k, v in item.data.items()}
                writer.writerow(row)

        console.print(f"\n💾 CSV 已保存至: [cyan]{file_path}[/cyan] ({len(self.result.items)} 行)")

    @staticmethod
    def _flatten_value(value) -> str:
        """扁平化值为字符串"""
        if isinstance(value, dict):
            import orjson as json
            return json.dumps(value).decode()
        if isinstance(value, list):
            return "|".join(str(v) for v in value)
        return str(value) if value is not None else ""

    def _default_output_path(self, ext: Optional[str] = None) -> str:
        """默认输出路径"""
        extension = ext or f".{self._get_extension()}"
        return str(Path.cwd() / "output" / f"{self.task_id}{extension}")
