"""
Spider 工厂 — 根据 SpiderType 和模板创建合适的 Spider 实例
"""

from __future__ import annotations

from typing import Type

from xscrapy.models.data_models import SpiderType, TemplateConfig, XScrapyConfig
from xscrapy.spiders.universal import UniversalSpider
from xscrapy.spiders.list_spider import ListSpider
from xscrapy.spiders.detail_spider import DetailSpider


SPIDER_REGISTRY: dict[SpiderType, Type] = {
    SpiderType.UNIVERSAL: UniversalSpider,
    SpiderType.LIST: ListSpider,
    SpiderType.DETAIL: DetailSpider,
}


class SpiderFactory:
    """Spider 工厂"""

    @staticmethod
    def create(spider_type: SpiderType, **kwargs):
        """创建指定类型的 Spider 实例"""
        spider_cls = SPIDER_REGISTRY.get(spider_type)
        if not spider_cls:
            raise ValueError(f"未知的 Spider 类型: {spider_type}")
        return spider_cls(**kwargs)

    @staticmethod
    def create_from_template(template_config: TemplateConfig, **kwargs):
        """从模板配置自动选择合适的 Spider 类型"""
        spider_type = template_config.spider_type
        kwargs.setdefault("template_config", template_config)
        return SpiderFactory.create(spider_type, **kwargs)

    @staticmethod
    def create_auto(config: XScrapyConfig, **kwargs):
        """自动推断最佳 Spider 类型"""
        if config.template_config:
            return SpiderFactory.create_from_template(config.template_config, **kwargs)
        
        # 默认使用通用 Spider
        return SpiderFactory.create(SpiderType.UNIVERSAL, **kwargs)

    @staticmethod
    def register(spider_type: SpiderType, spider_cls: Type) -> None:
        """注册自定义 Spider 类型"""
        SPIDER_REGISTRY[spider_type] = spider_cls

    @staticmethod
    def available_types() -> list[str]:
        """返回所有可用的 Spider 类型"""
        return [t.value for t in SPIDER_REGISTRY.keys()]
