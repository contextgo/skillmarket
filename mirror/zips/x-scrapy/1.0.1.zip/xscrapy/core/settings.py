"""
XScrapy 全局设置管理
将 XScrapy 配置映射为 Scrapy settings
"""

from __future__ import annotations

import random
from typing import Any, Optional

from scrapy.settings import Settings

from xscrapy.models.data_models import (
    AntiDetectConfig,
    AIConfig,
    OutputConfig,
    ProxyConfig,
    RenderMode,
    XScrapyConfig,
)


def build_scrapy_settings(config: XScrapyConfig) -> Settings:
    """根据 XScrapyConfig 构建 Scrapy Settings"""
    settings = Settings()

    # === 基础设置 ===
    settings.set("LOG_LEVEL", config.log_level)
    settings.set("ROBOTSTXT_OBEY", config.anti_detect.respect_robots_txt)
    settings.set("DEPTH_LIMIT", config.depth_limit)

    # === 并发与延迟 ===
    settings.set("CONCURRENT_REQUESTS", config.anti_detect.concurrent_requests)
    settings.set("CONCURRENT_REQUESTS_PER_DOMAIN", min(config.anti_detect.concurrent_requests, 8))
    settings.set("DOWNLOAD_TIMEOUT", config.anti_detect.download_timeout)
    settings.set("RETRY_TIMES", config.anti_detect.retry_times)

    if config.anti_detect.enable_delay:
        delay = random.uniform(config.anti_detect.min_delay, config.anti_detect.max_delay)
        settings.set("DOWNLOAD_DELAY", round(delay, 2))
        settings.set("RANDOMIZE_DOWNLOAD_DELAY", True)

    # === User-Agent ===
    if config.anti_detect.enable_ua_rotation:
        try:
            from fake_useragent import UserAgent
            ua = UserAgent()
            settings.set("USER_AGENT", ua.random)
        except Exception:
            settings.set(
                "USER_AGENT",
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/120.0.0.0 Safari/537.36"
            )

    # === Cookies ===
    settings.set("COOKIES_ENABLED", config.anti_detect.enable_cookie_jar)

    # === 渲染模式 ===
    settings.set("XSCRAPY_RENDER_MODE", config.render_mode.value)

    # === AI 配置 ===
    _apply_ai_settings(settings, config.ai)

    # === 输出配置 ===
    _apply_output_settings(settings, config.output)

    # === 代理配置 ===
    _apply_proxy_settings(settings, config.proxy)

    # === 中间件配置 ===
    _configure_middlewares(settings, config)

    return settings


def _apply_ai_settings(settings: Settings, ai_config: AIConfig) -> None:
    """应用 AI 相关设置"""
    settings.set("XSCRAPY_AI_ENABLED", ai_config.enabled)
    settings.set("XSCRAPY_AI_PROVIDER", ai_config.provider)
    settings.set("XSCRAPY_AI_MODEL", ai_config.model)
    settings.set("XSCRAPY_AI_API_KEY", ai_config.api_key or "")
    settings.set("XSCRAPY_AI_BASE_URL", ai_config.base_url or "")
    settings.set("XSCRAPY_AI_TEMPERATURE", ai_config.temperature)
    settings.set("XSCRAPY_AI_MAX_TOKENS", ai_config.max_tokens)
    settings.set("XSCRAPY_AI_FALLBACK_TO_RULES", ai_config.fallback_to_rules)
    settings.set("XSCRAPY_AI_CONFIDENCE_THRESHOLD", ai_config.confidence_threshold)


def _apply_output_settings(settings: Settings, output: OutputConfig) -> None:
    """应用输出相关设置"""
    settings.set("XSCRAPY_OUTPUT_FORMAT", output.format.value)
    settings.set("XSCRAPY_OUTPUT_PATH", output.file_path or "")
    settings.set("XSCRAPY_OUTPUT_PRETTY", output.pretty)
    settings.set("XSCRAPY_OUTPUT_INCLUDE_METADATA", output.include_metadata)
    settings.set("XSCRAPY_OUTPUT_ENCODING", output.encoding)
    settings.set("XSCRAPY_WEBHOOK_URL", output.webhook_url or "")


def _apply_proxy_settings(settings: Settings, proxy: ProxyConfig) -> None:
    """应用代理设置"""
    if proxy.enabled and proxy.pool:
        settings.set("DOWNLOADER_MIDDLEWARES", {
            "xscrapy.middlewares.proxy_rotator.ProxyRotatorMiddleware": 750,
        }, priority="cmdline")
        settings.set("XSCRAPY_PROXY_POOL", proxy.pool)
        settings.set("XSCRAPY_PROXY_ROTATION", proxy.rotation)


def _configure_middlewares(settings: Settings, config: XScrapyConfig) -> None:
    """配置中间件"""
    middlewares = {}

    # 反检测中间件
    middlewares["xscrapy.middlewares.anti_detect.AntiDetectMiddleware"] = 600

    # 速率限制中间件（如果启用）
    if config.anti_detect.enable_delay:
        middlewares["xscrapy.middlewares.rate_limiter.RateLimitMiddleware"] = 650

    # 缓存中间件
    middlewares["xscrapy.middlewares.cache_middleware.XScrapyCacheMiddleware"] = 700

    # 渲染中间件（如果需要 JS 渲染）
    if config.render_mode in (RenderMode.SPLASH, RenderMode.PLAYWRIGHT, RenderMode.AUTO):
        middlewares["xscrapy.middlewares.render_middleware.RenderMiddleware"] = 800

    settings.set("DOWNLOADER_MIDDLEWARES", middlewares, priority="cmdline")

    # 管道配置
    pipelines = {
        "xscrapy.pipelines.debug_pipeline.DebugPipeline": 100,  # 最前面
        "xscrapy.pipelines.clean_pipeline.CleanPipeline": 200,
        "xscrapy.pipelines.dedup_pipeline.DedupPipeline": 300,
        "xscrapy.pipelines.validate_pipeline.ValidatePipeline": 400,
        "xscrapy.pipelines.enrich_pipeline.EnrichPipeline": 500,
        "xscrapy.pipelines.standardize_pipeline.StandardizePipeline": 600,
        "xscrapy.pipelines.debug_pipeline.DebugPipelineLate": 899,
        "xscrapy.exporters.json_exporter.JsonExportPipeline": 900,
    }
    settings.set("ITEM_PIPELINES", pipelines, priority="cmdline")


def get_default_settings() -> Settings:
    """获取默认 Scrapy 设置"""
    config = XScrapyConfig(urls=[])
    return build_scrapy_settings(config)
