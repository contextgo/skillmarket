"""响应模型"""

from __future__ import annotations

from typing import Any, Optional
from datetime import datetime
from pydantic import BaseModel, Field


class HealthResponse(BaseModel):
    """健康检查响应"""
    status: str = "ok"
    version: str
    uptime_seconds: float
    active_tasks: int = 0
    total_crawled: int = 0


class TaskStatusResponse(BaseModel):
    """任务状态响应"""
    task_id: str
    status: str  # pending / running / completed / failed / paused
    progress: float = Field(ge=0.0, le=1.0)
    total_urls: int = 0
    completed_urls: int = 0
    items_collected: int = 0
    error_count: int = 0
    started_at: Optional[datetime] = None
    estimated_remaining: Optional[float] = None  # seconds
    result_file: Optional[str] = None


class ErrorResponse(BaseModel):
    """错误响应"""
    error: str
    code: str
    detail: Optional[Any] = None
    timestamp: datetime = Field(default_factory=datetime.now)


class ExtractRequest(BaseModel):
    """提取请求（API 模式）"""
    url: str
    template: Optional[str] = None
    fields: Optional[list[str]] = None
    config: Optional[dict[str, Any]] = None


class BatchExtractRequest(BaseModel):
    """批量提取请求"""
    urls: list[str]
    template: Optional[str] = None
    fields: Optional[list[str]] = None
    config: Optional[dict[str, Any]] = None
    concurrent: int = Field(default=3, ge=1, le=20)


class TemplateListResponse(BaseModel):
    """模板列表响应"""
    templates: list[dict[str, Any]]
    count: int
