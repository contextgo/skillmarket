"""
XScrapy 数据模型定义
使用 Pydantic v2 实现类型安全和序列化
"""

from __future__ import annotations

from enum import Enum
from typing import Any, Optional
from datetime import datetime
from pydantic import BaseModel, Field


class RenderMode(str, Enum):
    """页面渲染模式"""
    STATIC = "static"           # 纯 HTTP，无 JS 渲染
    SPLASH = "splash"           # Scrapy-Splash 轻量渲染
    PLAYWRIGHT = "playwright"   # Playwright 完整浏览器
    AUTO = "auto"               # 自动检测并选择


class OutputFormat(str, Enum):
    """输出格式"""
    JSON = "json"               # 标准 JSON 数组
    NDJSON = "ndjson"           # 流式 JSON Lines
    CSV = "csv"                 # 逗号分隔值
    DATABASE = "database"       # 数据库直写
    WEBHOOK = "webhook"         # Webhook 回调


class SpiderType(str, Enum):
    """爬虫类型"""
    UNIVERSAL = "universal"     # 通用（自动识别）
    LIST = "list"               # 列表页专用
    DETAIL = "detail"           # 详情页专用
    CUSTOM = "custom"           # 自定义配置驱动


class ConfidenceLevel(str, Enum):
    """数据置信度"""
    HIGH = "high"               # > 0.9 — 高置信
    MEDIUM = "medium"           # 0.7 - 0.9 — 中等置信
    LOW = "low"                 # < 0.7 — 低置信，需人工审核


class CrawlMetadata(BaseModel):
    """抓取元数据 — 每条数据都附带"""
    task_id: str = Field(description="任务唯一标识")
    spider: str = Field(description="使用的 Spider 名称")
    source_url: str = Field(description="来源 URL")
    crawled_at: datetime = Field(default_factory=datetime.now, description="抓取时间")
    render_mode: str = Field(default="static", description="渲染模式")
    confidence_score: float = Field(ge=0.0, le=1.0, default=1.0, description="置信度评分")
    version: str = Field(default="1.0.0", description="XScrapy 版本")
    extract_method: str = Field(default="rule", description="提取方式: rule / ai / hybrid")
    response_time_ms: Optional[int] = Field(default=None, description="响应时间(毫秒)")
    retry_count: int = Field(default=0, description="重试次数")


class StandardItem(BaseModel):
    """标准化数据项"""
    metadata: CrawlMetadata
    data: dict[str, Any] = Field(description="提取的结构化数据")
    links: dict[str, Any] = Field(default_factory=dict, description="关联链接", alias="_links")


class CrawlResult(BaseModel):
    """单次抓取结果"""
    success: bool
    item: Optional[StandardItem] = None
    error: Optional[str] = None
    warnings: list[str] = Field(default_factory=list)


class BatchCrawlResult(BaseModel):
    """批量抓取结果汇总"""
    task_id: str
    total_urls: int = 0
    success_count: int = 0
    failed_count: int = 0
    skipped_count: int = 0
    items: list[StandardItem] = Field(default_factory=list)
    errors: list[dict[str, str]] = Field(default_factory=list)
    started_at: datetime = Field(default_factory=lambda: datetime.now())
    finished_at: Optional[datetime] = None
    duration_seconds: Optional[float] = None

    def finalize(self) -> None:
        """完成抓取，计算耗时"""
        from datetime import timezone as tz
        self.finished_at = datetime.now(tz.utc)
        if self.started_at:
            # 统一处理时区
            start = self.started_at
            finish = self.finished_at
            if hasattr(start, 'tzinfo') and start.tzinfo is None:
                from datetime import timezone
                start = start.replace(tzinfo=timezone.utc)
            if hasattr(finish, 'tzinfo') and finish.tzinfo is None:
                from datetime import timezone
                finish = finish.replace(tzinfo=timezone.utc)
            self.duration_seconds = (finish - start).total_seconds()


class PageClassification(str, Enum):
    """页面类型自动分类"""
    PRODUCT = "product"          # 产品/商品页
    ARTICLE = "article"          # 文章/内容页
    LISTING = "listing"          # 列表/搜索结果页
    HOME = "home"                # 首页
    PROFILE = "profile"          # 个人/公司主页
    FORUM = "forum"              # 论坛帖子
    DOCUMENT = "document"        # 文档/API 页面
    UNKNOWN = "unknown"          # 无法识别


class ExtractionRule(BaseModel):
    """提取规则定义"""
    field_name: str = Field(description="目标字段名")
    selector: Optional[str] = Field(default=None, description="CSS/XPath 选择器")
    attribute: Optional[str] = Field(default=None, description="提取的属性(如 href, src)")
    regex: Optional[str] = Field(default=None, description="正则表达式后处理")
    default: Any = Field(default=None, description="默认值")
    required: bool = Field(default=False, description="是否必填")
    type_hint: Optional[str] = Field(default=None, description="类型提示: string/int/float/bool/list/url/date/price")
    ai_fallback: bool = Field(default=True, description="规则失败时是否回退到 AI 提取")
    description: Optional[str] = Field(default=None, description="字段描述(供 AI 参考)")


class TemplateConfig(BaseModel):
    """场景模板配置"""
    name: str = Field(description="模板名称")
    description: str = Field(description="模板说明")
    spider_type: SpiderType = Field(default=SpiderType.UNIVERSAL)
    page_type: Optional[PageClassification] = Field(default=None)
    render_mode: RenderMode = Field(default=RenderMode.AUTO)
    rules: list[ExtractionRule] = Field(default_factory=list)
    list_selector: Optional[str] = Field(default=None, description="列表容器选择器")
    pagination: Optional[PaginationConfig] = Field(default=None)
    next_page_selectors: list[str] = Field(
        default_factory=lambda: [
            'a.next',
            'a[aria-label="Next"]',
            'li.next a',
            'a:contains("下一页")',
            'a:contains(">")',
            'a:contains("»")',
            '[rel="next"]',
        ],
        description="下一页按钮候选选择器"
    )
    allowed_domains: Optional[list[str]] = Field(default=None, description="允许的域名")
    exclude_patterns: list[str] = Field(
        default_factory=lambda: [r'#.*', r'\?.*', r'javascript:', r'mailto:'],
        description="排除的 URL 模式"
    )


class PaginationConfig(BaseModel):
    """分页配置"""
    enabled: bool = True
    max_pages: int = Field(default=50, ge=1, le=10000, description="最大翻页数")
    selector: Optional[str] = Field(default=None, description="分页导航选择器")
    type: str = Field(default="auto", description="分页类型: auto / click / scroll / param")
    scroll_wait: float = Field(default=2.0, description="滚动等待秒数")
    url_pattern: Optional[str] = Field(default=None, description="URL 分页参数模式, 如 ?page={page}")


class ProxyConfig(BaseModel):
    """代理配置"""
    enabled: bool = False
    pool: list[str] = Field(default_factory=list, description="代理地址列表")
    rotation: str = Field(default="round_robin", description="轮换策略: round_robin / random / sticky")
    auth: Optional[dict[str, str]] = Field(default=None, description="认证信息 {username, password}")
    health_check: bool = Field(default=True, description="健康检查")


class AntiDetectConfig(BaseModel):
    """反检测配置"""
    enable_ua_rotation: bool = True
    enable_cookie_jar: bool = True
    enable_delay: bool = True
    min_delay: float = Field(default=1.0, ge=0.1)
    max_delay: float = Field(default=3.0, ge=0.5)
    respect_robots_txt: bool = True
    concurrent_requests: int = Field(default=8, ge=1, le=64)
    download_timeout: int = Field(default=30, ge=5, le=300)
    retry_times: int = Field(default=3, ge=0, le=10)
    custom_headers: dict[str, str] = Field(default_factory=dict)


class AIConfig(BaseModel):
    """AI 解析配置"""
    enabled: bool = False
    provider: str = Field(default="openai", description="AI 提供商: openai / local / custom")
    model: str = Field(default="gpt-4o-mini", description="模型名称")
    api_key: Optional[str] = Field(default=None, description="API Key (也可通过环境变量 XSCRAPY_AI_KEY)")
    base_url: Optional[str] = Field(default=None, description="API Base URL")
    temperature: float = Field(default=0.1, ge=0.0, le=2.0)
    max_tokens: int = Field(default=4096, ge=256, le=16384)
    fallback_to_rules: bool = Field(default=True, description="AI 失败时回退到规则解析")
    batch_size: int = Field(default=5, ge=1, le=20, description="批处理大小")
    confidence_threshold: float = Field(default=0.7, ge=0.0, le=1.0, description="置信度阈值")


class OutputConfig(BaseModel):
    """输出配置"""
    format: OutputFormat = Field(default=OutputFormat.JSON)
    file_path: Optional[str] = Field(default=None, description="输出文件路径")
    pretty: bool = Field(default=True, description="JSON 美化输出")
    include_metadata: bool = Field(default=True, description="包含元数据")
    encoding: str = Field(default="utf-8")
    webhook_url: Optional[str] = Field(default=None, description="Webhook URL")
    database_url: Optional[str] = Field(default=None, description="数据库连接串")


class XScrapyConfig(BaseModel):
    """XScrapy 全局配置"""
    task_id: Optional[str] = Field(default=None)
    urls: list[str] = Field(description="目标 URL 列表")
    template: Optional[str] = Field(default=None, description="场景模板名称")
    template_config: Optional[TemplateConfig] = Field(default=None)
    fields: Optional[list[str]] = Field(default=None, description="指定要提取的字段")
    custom_rules: list[ExtractionRule] = Field(default_factory=list)
    max_pages: int = Field(default=10, ge=1, le=10000)
    max_items: int = Field(default=1000, ge=1, le=1000000)
    follow_links: bool = Field(default=True, description="是否跟踪链接")
    depth_limit: int = Field(default=2, ge=0, le=10, description="爬取深度")

    render_mode: RenderMode = Field(default=RenderMode.AUTO)
    output: OutputConfig = Field(default_factory=OutputConfig)

    anti_detect: AntiDetectConfig = Field(default_factory=AntiDetectConfig)
    proxy: ProxyConfig = Field(default_factory=ProxyConfig)
    ai: AIConfig = Field(default_factory=AIConfig)

    log_level: str = Field(default="INFO")
    verbose: bool = Field(default=False)
    dry_run: bool = Field(default=False, description="干运行模式，不实际发送请求")

    class Config:
        extra = "forbid"
