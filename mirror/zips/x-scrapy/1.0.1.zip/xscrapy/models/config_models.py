"""配置相关模型"""

from __future__ import annotations

from typing import Any, Optional
from pydantic import BaseModel, Field


# 这里放置配置相关的扩展模型
# 主要配置已放在 data_models.py 的 XScrapyConfig 中

class DatabaseConfig(BaseModel):
    """数据库写入配置"""
    engine: str = Field(default="sqlite", description="数据库引擎: sqlite / postgresql / mongodb")
    connection_string: Optional[str] = Field(default=None)
    table_name: str = Field(default="xscrapy_data")
    batch_size: int = Field(default=100, ge=1, create_pool: bool = True)
    upsert_key: Optional[str] = Field(default=None, description="去重键字段名")
