"""
实体提取器 — 从文本中识别和提取命名实体
使用基于规则的方法 + 可选的 LLM 增强
"""

from __future__ import annotations

import re
import logging
from datetime import datetime
from typing import Any, Optional

logger = logging.getLogger(__name__)


class EntityExtractor:
    """
    命名实体提取器
    
    支持提取的实体类型：
    - 人名、邮箱、电话号码
    - 日期时间、价格金额
    - URL、IP地址
    - 地址、公司名
    - 社交媒体账号
    """

    # 正则模式库
    PATTERNS = {
        "email": re.compile(
            r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',
            re.IGNORECASE,
        ),
        "phone_cn": re.compile(
            r'(?:\+?86[-\s]?)?(?:1[3-9]\d|400|800)[- ]?\d{4}[- ]?\d{4}',
        ),
        "phone_intl": re.compile(
            r'\+?[1-9]\d{1,14}(?:[\s.-]?\d{2,}){0,5}',
        ),
        "price_cny": re.compile(
            r'¥\s*([\d,]+(?:\.\d{1,2})?)',
        ),
        "price_usd": re.compile(
            r'\$\s*([\d,]+(?:\.\d{1,2})?)',
        ),
        "price_generic": re.compile(
            r'(?<!\w)(?:CNY|RMB|USD|EUR|GBP)\s*[\$¥€£]?\s*([\d,]+(?:\.\d{1,2})?)'
            r'|(?<!\w)(?:￥|€|£)\s*([\d,]+(?:\.\d{1,2})?)',
        ),
        "url_http": re.compile(r'https?://[^\s<>"\']+', re.IGNORECASE),
        "ipv4": re.compile(
            r'\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b'
        ),
        "date_iso": re.compile(
            r'\b(\d{4})-(\d{2})-(\d{2})(?:[T\s](\d{2}):(\d{2}))?',
        ),
        "date_cn": re.compile(
            r'(\d{4})[年/-](\d{1,2})[月/-]?(\d{1,2})?[日号]?',
        ),
        "social_wechat": re.compile(r'wx[_:]?[\w_-]{6,20}', re.IGNORECASE),
        "social_weibo": re.compile(r'@[\u4e00-\u9fff\w_-]{2,30}', re.IGNORECASE),
    }

    def extract_from_text(self, text: str) -> dict[str, list[str]]:
        """从纯文本中提取所有实体"""
        entities: dict[str, list[str]] = {}
        for entity_type, pattern in self.PATTERNS.items():
            matches = pattern.findall(text)
            unique_matches = list(dict.fromkeys(matches))  # 去重保序
            if unique_matches:
                entities[entity_type] = unique_matches
        return entities

    def extract_from_dict(self, data: dict[str, Any]) -> dict[str, list[str]]:
        """从字典的所有字符串值中提取实体"""
        all_text = " ".join(str(v) for v in data.values() if v)
        return self.extract_from_text(all_text)

    def extract_prices(self, text: str) -> list[dict[str, Any]]:
        """专门提取价格信息，带货币单位"""
        prices = []
        
        for match in self.PATTERNS["price_cny"].finditer(text):
            prices.append({
                "amount": float(match.group(1).replace(",", "")),
                "currency": "CNY",
                "raw": match.group(0),
            })
            
        for match in self.PATTERNS["price_usd"].findall(text):
            prices.append({
                "amount": float(match.replace(",", "")),
                "currency": "USD",
                "raw": f"${match}",
            })
            
        return prices

    def extract_dates(self, text: str) -> list[dict[str, Any]]:
        """专门提取日期信息"""
        dates = []
        
        for match in self.PATTERNS["date_iso"].finditer(text):
            try:
                dt_dict = match.groupdict()
                date_obj = datetime(
                    int(dt_dict.get("1") or match.group(1)),
                    int(dt_dict.get("2") or match.group(2)),
                    int(dt_dict.get("3") or match.group(3) or 1),
                )
                dates.append({
                    "date_iso": date_obj.strftime("%Y-%m-%d"),
                    "raw": match.group(0),
                    "type": "iso",
                })
            except (ValueError, IndexError):
                continue
                
        for match in self.PATTERNS["date_cn"].finditer(text):
            try:
                date_obj = datetime(int(match.group(1)), int(match.group(2)), int(match.group(3) or 1))
                dates.append({
                    "date_iso": date_obj.strftime("%Y-%m-%d"),
                    "raw": match.group(0),
                    "type": "cn",
                })
            except (ValueError, IndexError):
                continue
                
        return dates

    def summarize(self, text: str) -> dict[str, Any]:
        """生成文本的实体摘要"""
        all_entities = self.extract_from_text(text)
        prices = self.extract_prices(text)
        dates = self.extract_dates(text)
        
        return {
            "entities": all_entities,
            "prices": prices,
            "dates": dates,
            "entity_count": sum(len(v) for v in all_entities.values()),
            "price_count": len(prices),
            "date_count": len(dates),
        }
