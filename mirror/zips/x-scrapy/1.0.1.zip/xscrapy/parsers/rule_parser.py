"""
规则解析器 — 基于 CSS/XPath/Regex 的结构化数据提取
"""

from __future__ import annotations

import re
import logging
from typing import Any, Optional
from urllib.parse import urljoin

from scrapy.http import Response

from xscrapy.models.data_models import ExtractionRule, TemplateConfig

logger = logging.getLogger(__name__)


class RuleParser:
    """
    基于规则的数据提取器
    
    支持三种选择器语法：
    - CSS 选择器 (默认)
    - XPath (以 / 或 ( 开头)
    - 正则表达式 (以 regex: 前缀)
    """

    def __init__(self, rules: list[ExtractionRule]):
        self.rules = rules

    def parse_response(self, response: Response) -> list[dict[str, Any]]:
        """对响应执行所有提取规则"""
        results = [{}]
        
        # 检查是否有列表容器（返回多条数据）
        template_config = getattr(response, 'template_config', None)
        list_container = None
        if isinstance(template_config, TemplateConfig) and template_config.list_selector:
            list_container = response.css(template_config.list_selector)

        if list_container and len(list_container) > 1:
            # 列表模式 — 为每个列表项创建一条记录
            results = []
            for item_elem in list_container:
                record = self._apply_rules(item_elem, response, is_element=True)
                if record:
                    results.append(record)
            return results
        
        # 单条模式
        record = self._apply_rules(response, response, is_element=False)
        return [record] if record else []

    def _apply_rules(self, target: Any, response: Response, is_element: bool) -> dict[str, Any]:
        """对目标应用所有规则"""
        record: dict[str, Any] = {}
        
        for rule in self.rules:
            try:
                value = self._extract_single(target, rule, response)
                
                if value is not None:
                    # 类型转换
                    converted = self._convert_type(value, rule.type_hint)
                    record[rule.field_name] = converted
                elif rule.required:
                    logger.warning(f"必填字段缺失: {rule.field_name}")
                    
            except Exception as e:
                logger.debug(f"字段 {rule.field_name} 提取异常: {e}")
                if rule.default is not None:
                    record[rule.field_name] = rule.default
                    
        return record

    def _extract_single(self, target: Any, rule: ExtractionRule, response: Response) -> Any:
        """提取单个字段的值"""
        raw_value = None

        if rule.selector:
            selector_str = rule.selector.strip()
            
            # 判断选择器类型
            if selector_str.startswith("regex:"):
                # 正则模式
                pattern = selector_str[6:].strip()
                text = target.get() if hasattr(target, 'get') else str(target)
                match = re.search(pattern, text or "")
                raw_value = match.group(0) if match else None
                
            elif selector_str.startswith("/") or selector_str.startswith("("):
                # XPath 模式
                elements = target.xpath(selector_str).getall()
                raw_value = self._get_first(elements, rule.attribute)
                
            else:
                # CSS 选择器模式（默认）
                elements = target.css(selector_str).getall()
                raw_value = self._get_first(elements, rule.attribute)

        # 后处理正则
        if raw_value and rule.regex:
            match = re.search(rule.regex, str(raw_value))
            raw_value = match.group(0) if match else raw_value

        return raw_value

    def _get_first(self, values: list[str], attribute: Optional[str] = None) -> Any:
        """从多个值中取第一个有效值"""
        if not values:
            return None
            
        first = values[0].strip()
        if not first:
            return None if len(values) < 2 else self._get_first(values[1:], attribute)
            
        return first

    def _convert_type(self, value: Any, type_hint: Optional[str]) -> Any:
        """类型转换"""
        if type_hint is None:
            return value

        try:
            match type_hint.lower():
                case "int":
                    return int(str(value).replace(",", "").replace(" ", ""))
                case "float" | "price":
                    cleaned = re.sub(r'[^\d.]', '', str(value))
                    return float(cleaned) if cleaned else value
                case "bool":
                    if isinstance(value, bool):
                        return value
                    return str(value).lower() in ("true", "yes", "1", "on")
                case "list":
                    if isinstance(value, list):
                        return value
                    return [value]
                case "url":
                    return value  # URL 通常由调用方处理 join
                case "date":
                    return str(value)  # 保持原始格式
                case _:
                    return value
        except (ValueError, TypeError):
            return value


class RuleBuilder:
    """流式规则构建器 — 方便链式定义提取规则"""

    def __init__(self):
        self.rules: list[ExtractionRule] = []

    def add(
        self,
        field_name: str,
        selector: str,
        *,
        attribute: Optional[str] = None,
        regex: Optional[str] = None,
        default: Any = None,
        required: bool = False,
        type_hint: Optional[str] = None,
        description: Optional[str] = None,
        ai_fallback: bool = True,
    ) -> "RuleBuilder":
        self.rules.append(ExtractionRule(
            field_name=field_name,
            selector=selector,
            attribute=attribute,
            regex=regex,
            default=default,
            required=required,
            type_hint=type_hint,
            ai_fallback=ai_fallback,
            description=description,
        ))
        return self

    def build(self) -> RuleParser:
        return RuleParser(self.rules)

    @staticmethod
    def from_template(template: TemplateConfig) -> RuleParser:
        """从模板配置构建解析器"""
        return RuleParser(template.rules)
