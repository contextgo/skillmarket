"""
AI 解析器 — 基于 LLM 的智能内容提取
"""

from __future__ import annotations

import json
import logging
from typing import Any, Optional

from scrapy.http import Response

from xscrapy.models.data_models import (
    AIConfig,
    CrawlMetadata,
    StandardItem,
)

logger = logging.getLogger(__name__)

# 系统提示词模板
EXTRACTION_SYSTEM_PROMPT = """你是一个专业的网页数据提取助手。
从给定的 HTML 页面文本中，精确提取请求的字段信息。

规则：
1. 只输出 JSON，不要其他文字
2. 如果某个字段在页面中找不到，设为 null
3. 价格和数字保持原始值，不做转换
4. 文本字段去除多余空白
5. 保持数据的准确性优先于完整性"""

EXTRACTION_USER_PROMPT_TEMPLATE = """
## 目标页面 URL
{url}

## 需要提取的字段
{fields}

## HTML 内容（截取前 {max_chars} 字符）
```html
{html_content}
```

请以上述字段为 key，提取对应值，输出标准 JSON 格式。
"""


class AIParser:
    """
    AI 智能解析器
    
    使用 LLM 从非结构化/半结构化 HTML 中提取结构化数据。
    
    支持两种模式：
    - extract: 直接从页面提取（规则失败时的回退）
    - enhance: 对已有数据进行补充和验证
    """

    def __init__(self, config: AIConfig):
        self.config = config
        self._client: Any = None

    def _get_client(self) -> Any:
        """延迟初始化 AI 客户端"""
        if self._client is not None:
            return self._client

        api_key = self.config.api_key or ""
        base_url = self.config.base_url

        try:
            import openai
            client_kwargs = {
                "api_key": api_key,
            }
            if base_url:
                client_kwargs["base_url"] = base_url
            self._client = openai.OpenAI(**client_kwargs)
        except ImportError:
            logger.warning("openai 包未安装，AI 解析不可用")
            raise
        except Exception as e:
            logger.error(f"AI 客户端初始化失败: {e}")
            raise

        return self._client

    def extract(self, response: Response, fields: list[str]) -> Optional[dict]:
        """
        使用 AI 从页面中直接提取指定字段
        
        Args:
            response: Scrapy 响应对象
            fields: 要提取的字段名列表

        Returns:
            提取的数据字典，失败时返回 None
        """
        if not fields:
            return None

        html_text = response.text[:15000]  # 限制长度避免超 token
        url = response.url

        prompt = EXTRACTION_USER_PROMPT_TEMPLATE.format(
            url=url,
            fields=json.dumps(fields, ensure_ascii=False, indent=2),
            max_chars=len(html_text),
            html_content=html_text,
        )

        try:
            client = self._get_client()
            result = client.chat.completions.create(
                model=self.config.model,
                messages=[
                    {"role": "system", "content": EXTRACTION_SYSTEM_PROMPT},
                    {"role": "user", "content": prompt},
                ],
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens,
                response_format={"type": "json_object"},
            )
            
            content = result.choices[0].message.content
            if content:
                data = json.loads(content)
                logger.info(f"AI 提取成功: {url} -> {len(data)} 个字段")
                return data
            return None

        except Exception as e:
            logger.error(f"AI 提取失败 ({url}): {e}")
            return None

    def enhance(self, item: StandardItem, response: Response) -> Optional[StandardItem]:
        """
        使用 AI 增强已提取的数据
        
        - 补充缺失字段
        - 验证已有字段的准确性
        - 提取额外有价值的信息
        """
        missing_fields = [
            k for k in ("title", "description", "author", "published_date", 
                        "price", "brand", "category")
            if k not in item.data or not item.data[k]
        ]

        if not missing_fields:
            return item  # 无需增强

        additional_data = self.extract(response, missing_fields)
        if additional_data:
            new_data = {**item.data}
            for field, value in additional_data.items():
                if field not in new_data or not new_data[field]:
                    new_data[field] = value
            
            # 创建新的 StandardItem
            enhanced = StandardItem(
                metadata=item.metadata.model_copy(),
                data=new_data,
                _links=item._links,
            )
            enhanced.metadata.confidence_score = min(enhanced.metadata.confidence_score + 0.05, 1.0)
            enhanced.metadata.extract_method = "hybrid"
            return enhanced

        return None

    def batch_extract(self, responses_with_fields: list[tuple[Response, list[str]]]) -> list[Optional[dict]]:
        """批量提取 — 减少API调用次数"""
        results = []
        for response, fields in responses_with_fields:
            result = self.extract(response, fields)
            results.append(result)
        return results

    def classify_page_content(self, response: Response) -> dict:
        """用 AI 分析页面内容和类型"""
        html_sample = response.text[:8000]
        prompt = f"""分析这个页面的类型和主要内容。

URL: {response.url}

HTML 内容:
```html
{html_sample}
```

请以 JSON 格式返回：
{{
  "page_type": "product/article/listing/home/forum/document/other",
  "main_topic": "一句话描述这个页面的主题",
  "key_entities": ["实体1", "实体2"],
  "language": "zh/en/ja/other",
  "has_structured_data": true/false,
  "suggested_fields": ["建议提取的字段1", "..."]
}}"""

        try:
            client = self._get_client()
            result = client.chat.completions.create(
                model=self.config.model,
                messages=[
                    {"role": "system", "content": "你是网页分析专家，只返回JSON。"},
                    {"role": "user", "content": prompt},
                ],
                temperature=0.05,
                max_tokens=500,
                response_format={"type": "json_object"},
            )
            return json.loads(result.choices[0].message.content)
        except Exception as e:
            logger.error(f"AI 分类失败: {e}")
            return {}
