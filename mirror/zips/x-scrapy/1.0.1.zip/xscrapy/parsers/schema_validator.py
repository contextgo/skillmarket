"""
Schema 校验器 — 校验提取数据是否符合预期 Schema
"""

from __future__ import annotations

import logging
from typing import Any, Optional

logger = logging.getLogger(__name__)


class SchemaValidator:
    """
    数据 Schema 校验器
    
    功能：
    - 必填字段检查
    - 数据类型校验
    - 值域范围验证
    - 自定义校验函数支持
    - 自动填充默认值
    """

    def __init__(self, schema: Optional[dict[str, Any]] = None):
        self.schema = schema or {}

    def validate(self, data: dict[str, Any]) -> tuple[bool, list[str], dict[str, Any]]:
        """
        校验数据
        
        Returns:
            (是否通过, 错误列表, 清洗后的数据)
        """
        errors: list[str] = []
        clean_data = dict(data)

        for field_name, field_schema in self.schema.items():
            value = data.get(field_name)
            
            # 必填检查
            if field_schema.get("required", False) and (value is None or value == ""):
                error_msg = f"必填字段 '{field_name}' 缺失"
                if "default" in field_schema:
                    clean_data[field_name] = field_schema["default"]
                    logger.info(f"{error_msg}，使用默认值: {field_schema['default']}")
                else:
                    errors.append(error_msg)
                continue

            # 跳过空值（非必填）
            if value is None:
                continue

            # 类型校验
            expected_type = field_schema.get("type")
            if expected_type:
                validated, type_error = self._check_type(field_name, value, expected_type)
                if type_error:
                    if field_schema.get("coerce", True):
                        clean_data[field_name] = validated
                    else:
                        errors.append(type_error)

            # 值域范围
            min_val = field_schema.get("min")
            max_val = field_schema.get("max")
            if isinstance(value, (int, float)):
                if min_val is not None and value < min_val:
                    errors.append(f"字段 '{field_name}' 值 {value} 小于最小值 {min_val}")
                if max_val is not None and value > max_val:
                    errors.append(f"字段 '{field_name}' 值 {value} 大于最大值 {max_val}")

            # 正则匹配
            pattern = field_schema.get("pattern")
            if pattern and isinstance(value, str):
                import re
                if not re.match(pattern, value):
                    errors.append(f"字段 '{field_name}' 不匹配模式 {pattern}")

            # 枚举值检查
            enum_values = field_schema.get("enum")
            if enum_values and value not in enum_values:
                errors.append(f"字段 '{field_name}' 值不在允许范围内: {enum_values}")

            # 自定义校验函数
            validator_fn = field_schema.get("validator")
            if callable(validator_fn):
                custom_error = validator_fn(value, field_name, clean_data)
                if custom_error:
                    errors.append(custom_error)

        is_valid = len(errors) == 0
        if not is_valid:
            logger.warning(f"Schema 校验未通过: {errors}")

        return is_valid, errors, clean_data

    def _check_type(self, field_name: str, value: Any, expected_type: str) -> tuple[Any, Optional[str]]:
        """类型检查与自动转换"""
        type_map = {
            "string": str,
            "int": (int, lambda v: int(float(str(v).replace(",",""))) if "." in str(v) else int(v.replace(",",""))),
            "float": (float, lambda v: float(str(v).replace(",",""))),
            "bool": (bool, lambda v: str(v).lower() in ("true","1","yes","on")),
            "list": (list, lambda v: [v] if not isinstance(v, list) else v),
            "dict": (dict, lambda v: v if isinstance(v, dict) else {}),
            "url": str,
            "email": str,
        }

        type_info = type_map.get(expected_type)
        if not type_info:
            return value, None

        if isinstance(type_info, tuple):
            target_type, converter = type_info
        else:
            target_type, converter = type_info, type_info

        if isinstance(value, target_type):
            return value, None

        # 尝试转换
        try:
            converted = converter(value)
            return converted, None
        except (ValueError, TypeError) as e:
            return value, f"字段 '{field_name}' 类型错误: 期望 {expected_type}, 实际 {type(value).__name__}"

    def build_schema_from_data(self, sample_data: dict[str, Any]) -> dict[str, Any]:
        """从样本数据推断 Schema"""
        schema: dict[str, Any] = {}
        for key, value in sample_data.items():
            field_schema: dict[str, Any] = {"type": self._infer_type(value)}
            if value is not None:
                if isinstance(value, str) and len(value) > 100:
                    field_schema["description"] = value[:50] + "..."
            schema[key] = field_schema
        return schema

    @staticmethod
    def _infer_type(value: Any) -> str:
        """推断值的类型"""
        if isinstance(value, bool):
            return "bool"
        elif isinstance(value, int):
            return "int"
        elif isinstance(value, float):
            return "float"
        elif isinstance(value, list):
            return "list"
        elif isinstance(value, dict):
            return "dict"
        elif isinstance(value, str):
            if value.startswith("http://") or value.startswith("https://"):
                return "url"
            return "string"
        return "string"
