"""Detail Spider — 详情页专用爬虫，深度提取"""

from __future__ import annotations

from typing import Any

from scrapy.http import Response

from xscrapy.spiders.universal import UniversalSpider


class DetailSpider(UniversalSpider):
    """
    详情页 Spider — 继承自 UniversalSpider
    
    在通用提取基础上增加详情页深度提取能力：
    - 更完整的正文提取
    - 评论/评价提取
    - 相关推荐提取
    - 规格参数提取
    """

    name = "detail"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def parse_detail(self, response: Response) -> dict[str, Any]:
        """深度提取详情页数据"""
        data = self.universal_extract(response, self.classify_page(response))

        # 评论区
        comments = self._extract_comments(response)
        if comments:
            data["comments"] = comments

        # 相关推荐
        related = self._extract_related(response)
        if related:
            data["related_items"] = related

        # 规格参数表
        specs = self._extract_specs_table(response)
        if specs:
            data["specifications"] = specs

        # 面包屑导航
        breadcrumbs = self._extract_breadcrumbs(response)
        if breadcrumbs:
            data["breadcrumbs"] = breadcrumbs

        return data

    def _extract_comments(self, response: Response) -> list[dict]:
        """提取评论区"""
        comment_blocks = response.css(
            '[class*="review"], [class*="comment"], '
            '[class*="feedback"], [itemprop="review"]'
        )
        comments = []
        for block in comment_blocks[:20]:
            comment: dict[str, Any] = {}
            
            author = block.css(
                '[class*="author"], [class*="user"], [itemprop="author"] ::text'
            ).get()
            if author:
                comment["author"] = self._clean_text(author)

            rating = block.css(
                '[class*="rating"] ::attr(data-rating), '
                '[itemprop="ratingValue"] ::attr(content), '
                '[class*="star"] ::attr(class)'
            ).get()
            if rating:
                digits = "".join(c for c in rating if c.isdigit())
                if digits:
                    comment["rating"] = int(digits)

            text = block.css(
                '[class*="content"], [class*="text"], '
                '[itemprop="reviewBody"] ::text'
            ).getall()
            if text:
                comment["text"] = self._clean_text(" ".join(text))[:500]

            if comment:
                comments.append(comment)

        return comments

    def _extract_related(self, response: Response) -> list[dict]:
        """提取相关推荐"""
        related_blocks = response.css(
            '[class*="related"], [class*="recommend"], [class*="also"], '
            '[class*="similar"] [class*="item"], [class*="related"] li'
        )
        related = []
        for block in related_blocks[:10]:
            item: dict[str, Any] = {}
            title = block.css("a ::text").get()
            if title:
                item["title"] = self._clean_text(title)
            href = block.css("a ::attr(href)").get()
            if href:
                item["url"] = href
            if item:
                related.append(item)
        return related

    def _extract_specs_table(self, response: Response) -> dict[str, str]:
        """提取规格参数表格"""
        tables = response.css(
            'table.specs table, [class*="spec"] table, '
            'table:has(th):has(td), dl:has(dt):has(dd)'
        )
        specs: dict[str, str] = {}

        for table in tables:
            rows = table.css("tr, dt+dd")
            for row in rows:
                key = row.css("th, dt ::text").get()
                val = row.css("td, dd ::text").get()
                if key and val:
                    specs[self._clean_text(key)] = self._clean_text(val)

        return specs

    def _extract_breadcrumbs(self, response: Response) -> list[dict]:
        """提取面包屑导航"""
        crumbs = response.css(
            'nav [class*="breadcrumb"] a, '
            'ol [class*="breadcrumb"] li a, '
            '[class*="breadcrumb"] a'
        )
        breadcrumbs = []
        for crumb in crumbs:
            text = crumb.css("::text").get()
            href = crumb.attrib.get("href")
            if text:
                breadcrumbs.append({
                    "label": self._clean_text(text),
                    "url": href,
                })
        return breadcrumbs
