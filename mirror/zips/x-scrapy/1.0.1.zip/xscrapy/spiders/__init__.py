# Spiders package
from xscrapy.spiders.base import XScrapySpider
from xscrapy.spiders.universal import UniversalSpider
from xscrapy.spiders.list_spider import ListSpider
from xscrapy.spiders.detail_spider import DetailSpider

__all__ = ["XScrapySpider", "UniversalSpider", "ListSpider", "DetailSpider"]
