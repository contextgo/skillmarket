"""
Universal Spider — XScrapy 的核心通用爬虫
自动识别页面类型、智能提取结构化数据
"""

from __future__ import annotations

import re
import json
import logging
from typing import Any, Iterator, Optional
from urllib.parse import urljoin, urlparse

from scrapy import Request
from scrapy.http import Response

from xscrapy.spiders.base import XScrapySpider
from xscrapy.models.data_models import (
    PageClassification,
    TemplateConfig,
    XScrapyConfig,
)
from xscrapy.parsers.rule_parser import RuleParser
from xscrapy.parsers.entity_extractor import EntityExtractor

logger = logging.getLogger(__name__)


class UniversalSpider(XScrapySpider):
    """
    通用 Spider — 零配置即可运行
    
    特性：
    - 自动识别页面类型（产品/文章/列表/首页等）
    - 智能提取核心字段（标题、正文、链接、图片等）
    - 自动发现分页和关联链接
    - 支持 AI 增强解析（可选）
    """

    name = "universal"

    # 页面特征模式（用于自动分类）
    PAGE_PATTERNS = {
        PageClassification.PRODUCT: [
            r'price', r'\$\d+', r'add.to.cart|加入购物车',
            r'product|商品', r'sku', r'stock|库存',
            r'review|评价', r'specification|规格',
            r'buy.now|立即购买',
        ],
        PageClassification.ARTICLE: [
            r'article|文章', r'published|发布',
            r'author|作者', r'content|内容|正文',
            r'tags?|标签', r'comment|评论',
            r'read.time|阅读时间',
        ],
        PageClassification.LISTING: [
            r'result.*\d+|共\d+条', r'page.*\d+.*result',
            r'listing|列表', r'grid|网格',
            r'filter|筛选', r'sort|排序',
            r'per.page|每页',
        ],
        PageClassification.FORUM: [
            r'post|帖子', r'thread|主题',
            r'reply|回复', r'forum|论坛',
            r'moderator|版主', r'topic|话题',
        ],
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.rule_parser: Optional[RuleParser] = None
        self.entity_extractor = EntityExtractor()
        self._template_config: Optional[TemplateConfig] = None
        self._items_count: int = 0
        self._max_items_reached: bool = False
        # 暴露 task_id 供 Pipeline 使用
        self._task_id = kwargs.get('task_id', '')
        self._init_parsers()

    def _init_parsers(self) -> None:
        """初始化解析器"""
        if self.config.template_config:
            self._template_config = self.config.template_config
            if self.config.template_config.rules:
                self.rule_parser = RuleParser(self.config.template_config.rules)

    def parse(self, response: Response) -> Any:
        """通用解析入口"""
        if not self._is_text_response(response):
            logger.warning(f"非文本响应，跳过: {response.url}")
            return

        # 检查是否达到最大数量限制
        if self._max_items_reached:
            return

        # 自动分类页面类型
        page_type = self.classify_page(response)
        logger.debug(f"页面分类: {response.url} -> {page_type.value}")

        # 根据页面类型选择提取策略
        items = self.extract_data(response, page_type)
        
        # DEBUG
        logger.info(f"[DEBUG] extract_data returned {len(items)} items for {response.url}")
        for idx, it in enumerate(items[:2]):
            if isinstance(it, dict):
                d = it.get('data', it)
                logger.info(f"[DEBUG] item[{idx}] data keys: {list(d.keys())[:10] if isinstance(d, dict) else type(d)}")
            else:
                logger.info(f"[DEBUG] item[{idx}] type: {type(it)}")

        for item in items:
            yield item
            self._items_count += 1
            
            if self._items_count >= self.config.max_items:
                self._max_items_reached = True
                logger.info(f"已达最大数量限制: {self.config.max_items}")
                break

        # 处理分页
        yield from self.handle_pagination(response)

        # 发现并跟踪链接
        if self.config.follow_links and not self._max_items_reached:
            yield from self.discover_links(response)

    def classify_page(self, response: Response) -> PageClassification:
        """
        基于 URL 和内容特征自动分类页面类型
        
        使用多维度信号：
        1. URL 结构特征
        2. 页面标题关键词
        3. 页面内容中的语义标记
        """
        url_lower = response.url.lower()
        text_lower = response.text.lower()[:5000]
        
        # URL 特征快速匹配
        score_map: dict[PageClassification, float] = {t: 0.0 for t in PageClassification}
        
        for page_type, patterns in self.PAGE_PATTERNS.items():
            for pattern in patterns:
                if re.search(pattern, url_lower):
                    score_map[page_type] += 2.0
                if re.search(pattern, text_lower):
                    score_map[page_type] += 1.0

        # HTML 结构特征
        if response.xpath("//article").get():
            score_map[PageClassification.ARTICLE] += 3.0
        if response.xpath("//*[@itemtype='http://schema.org/Product']").get():
            score_map[PageClassification.PRODUCT] += 5.0
        if response.xpath("//ol[@class='pagination'] | //ul[@class='pagination'] | //nav[@aria-label]").get():
            score_map[PageClassification.LISTING] += 3.0
        if response.xpath("//main//a[count(ancestor::div[@class='list']) > 0 or count(ancestor::div[contains(@class,'grid')]) > 0]").get():
            score_map[PageClassification.LISTING] += 2.0

        # 选择得分最高的类型
        best_type = max(score_map, key=score_map.get)
        best_score = score_map[best_type]

        if best_score < 1.0:
            return PageClassification.UNKNOWN

        return best_type

    def extract_data(self, response: Response, page_type: PageClassification) -> list[Any]:
        """
        根据页面类型提取数据
        
        策略优先级：
        1. 用户自定义规则（模板配置）
        2. 页面 Schema.org 结构化数据
        3. 通用启发式提取
        """
        results = []

        # === 策略1: 使用用户自定义规则 ===
        if self.rule_parser:
            try:
                parsed_items = self.rule_parser.parse_response(response)
                for item_data in parsed_items:
                    item = self._make_item(item_data, response, method="rule")
                    results.append(item)
                return results
            except Exception as e:
                logger.warning(f"规则解析失败，回退到通用提取: {e}")

        # === 策略2: 提取 JSON-LD / Microdata ===
        structured_data = self.extract_structured_data(response)
        if structured_data:
            for sd in structured_data:
                item = self._make_item(sd, response, method="schema_org")
                results.append(item)
            
            # 如果有结构化数据，直接返回
            if results:
                return results

        # === 策略3: 通用启发式提取 ===
        universal_data = self.universal_extract(response, page_type)
        if universal_data:
            item = self._make_item(universal_data, response, method="heuristic")
            results.append(item)

        # === 策略4: AI 增强（如果启用）===
        if self.config.ai.enabled and results:
            # 用 AI 补充/验证已提取的数据
            try:
                from xscrapy.parsers.ai_parser import AIParser
                ai_parser = AIParser(self.config.ai)
                
                for item in results:
                    enhanced = ai_parser.enhance(item, response)
                    if enhanced is not None:
                        results[results.index(item)] = enhanced
            except Exception as e:
                logger.warning(f"AI 增强失败，使用原始结果: {e}")

        return results

    def extract_structured_data(self, response: Response) -> list[dict]:
        """提取页面中的 Schema.org 结构化数据 (JSON-LD / Microdata)"""
        results = []

        # JSON-LD
        scripts = response.xpath('//script[@type="application/ld+json"]/text()').getall()
        for script_text in scripts:
            try:
                data = json.loads(script_text)
                flattened = self._flatten_jsonld(data)
                if flattened and any(v for v in flattened.values() if v):
                    results.append(flattened)
            except (json.JSONDecodeError, TypeError):
                continue

        # Microdata (简化提取)
        itemscope = response.xpath('//*[@itemscope]')
        for elem in itemscope:
            item = {}
            name = elem.xpath('.//*[@itemprop="name"]/text()').get()
            desc = elem.xpath('.//*[@itemprop="description"]/text()').get()
            image = elem.xpath('.//*[@itemprop="image"]/@src | .//*[@itemprop="image"]/@content').get()
            price = elem.xpath('.//*[@itemprop="price"]/@content | .//*[@itemprop="price"]/text()').get()

            if name:
                item["title"] = name.strip()
            if desc:
                item["description"] = desc.strip()
            if image:
                item["images"] = [image]
            if price:
                item["raw_price"] = price.strip()

            if item:
                results.append(item)

        return results

    def _flatten_jsonld(self, data: dict | list, prefix: str = "") -> dict:
        """扁平化 JSON-LD 数据为平面字典"""
        result: dict[str, Any] = {}

        if isinstance(data, list):
            if len(data) == 1 and isinstance(data[0], dict):
                data = data[0]
            else:
                result[prefix or "@graph"] = str(data)[:2000]
                return result

        if not isinstance(data, dict):
            return {"value": str(data)}

        # 类型映射
        type_mapping = {
            "Product": {
                "title": ["name"],
                "description": ["description"],
                "price": ["offers", "price"],
                "currency": ["offers", "priceCurrency"],
                "images": ["image"],
                "brand": ["brand", "name"],
                "sku": ["sku"],
                "rating": ["aggregateRating", "ratingValue"],
                "review_count": ["aggregateRating", "reviewCount"],
                "availability": ["offers", "availability"],
            },
            "Article": {
                "title": ["headline", "name"],
                "description": ["description"],
                "author": ["author", "name"],
                "published_date": ["datePublished"],
                "modified_date": ["dateModified"],
                "article_body": ["articleBody"],
            },
            "WebPage": {
                "title": ["name"],
                "description": ["description"],
            },
        }

        schema_type = data.get("@type", "")
        mapping = type_mapping.get(schema_type, {})

        for field_name, path_list in mapping.items():
            value = data
            try:
                for key in path_list:
                    value = value[key]
                if isinstance(value, list):
                    value = value[0] if value else None
                if value:
                    result[field_name] = value
            except (KeyError, IndexError, TypeError):
                continue

        # 提取未映射的字段作为 raw
        if not result:
            for k, v in data.items():
                if not k.startswith("@") and isinstance(v, (str, int, float, bool)):
                    result[k] = v

        return result

    def universal_extract(self, response: Response, page_type: PageClassification) -> dict[str, Any]:
        """
        通用启发式提取 — 不依赖任何规则或 AI
        对任意页面都能提取出有意义的数据
        """
        data: dict[str, Any] = {}

        # === 通用字段（所有页面都尝试提取）===

        # 标题（多种策略）
        title = (
            response.xpath("//meta[@property='og:title']/@content").get()
            or response.xpath("//title/text()").get()
            or response.xpath("//h1/text()").get()
        )
        if title:
            data["title"] = self._clean_text(title)

        # 描述
        description = (
            response.xpath("//meta[@name='description']/@content").get()
            or response.xpath("//meta[@property='og:description']/@content").get()
        )
        if description:
            data["description"] = self._clean_text(description)

        # 关键词
        keywords = response.xpath("//meta[@name='keywords']/@content").get()
        if keywords:
            data["keywords"] = [k.strip() for k in keywords.split(",")]

        # 主图片
        og_image = response.xpath("//meta[@property='og:image']/@content").get()
        if og_image:
            data["images"] = [urljoin(response.url, og_image)]
        else:
            # 取第一张有意义的图片（排除图标等）
            images = response.xpath(
                "//img[@width >= '100']"
                "| //img[contains(@class, 'content')]"
                "| //img[contains(@class, 'article')]"
                "| //img[contains(@class, 'main')]"
            )
            img_urls = []
            for img in images[:5]:
                src = img.xpath("./@src | ./@data-src | ./@data-original").get()
                if src:
                    full_url = urljoin(response.url, src)
                    if full_url not in img_urls:
                        img_urls.append(full_url)
            if img_urls:
                data["images"] = img_urls

        # URL 信息
        data["url"] = response.url
        parsed_url = urlparse(response.url)
        data["domain"] = parsed_url.netloc
        data["path"] = parsed_url.path

        # 所有外部链接
        links = response.xpath("//a[@href]/@href").getall()
        external_links = []
        internal_links = []
        for link in links:
            link = urljoin(response.url, link)
            if urlparse(link).netloc == parsed_url.netloc:
                if link != response.url and "#" not in link:
                    internal_links.append(link)
            else:
                external_links.append(link)
        if internal_links[:20]:
            data["internal_links"] = internal_links[:20]
        if external_links[:10]:
            data["external_links"] = external_links[:10]

        # 正文文本（去除脚本和样式）
        body_text = response.xpath(
            '//body//text()[not(parent::script)][not(parent::style)]'
        ).getall()
        clean_text = " ".join(t.strip() for t in body_text if t.strip())
        data["body_text"] = clean_text[:10000]  # 限制长度

        # === 根据页面类型的特定提取 ===
        match page_type:
            case PageClassification.PRODUCT:
                self._extract_product_fields(response, data)
            case PageClassification.ARTICLE:
                self._extract_article_fields(response, data)
            case PageClassification.LISTING:
                self._extract_listing_fields(response, data)
            case _:
                pass

        # 实体提取补充
        entities = self.entity_extractor.extract_from_dict(data)
        if entities:
            data["_entities"] = entities

        return data

    def _extract_product_fields(self, response: Response, data: dict) -> None:
        """提取电商产品特有字段"""
        # 价格
        price_patterns = [
            "//span[contains(@class,'price')]/text()",
            "//div[contains(@class,'price')]/text()",
            "//*[@itemprop='price']/@content",
            "//*[@itemprop='price']/text()",
            "//meta[@property='product:price:amount']/@content",
            "//span[@id='price']/text()",
        ]
        for pattern in price_patterns:
            prices = response.xpath(pattern).getall()
            for p in prices:
                p_clean = self._clean_text(p).replace(",", "").replace("¥", "").replace("$", "")
                try:
                    data["price"] = float(p_clean)
                    break
                except ValueError:
                    continue
            if "price" in data:
                break

        # 品牌
        brand = (
            response.xpath("//a[contains(@class,'brand')]/text()").get()
            or response.xpath("//*[@itemprop='brand']/@content | //*[@itemprop='brand']/text()").get()
        )
        if brand:
            data["brand"] = self._clean_text(brand)

        # 库存状态
        stock = response.xpath(
            "//*[contains(text(),'库存') or contains(text(),'stock') or contains(text(),'in stock')]/text()"
        ).get()
        if stock:
            stock_lower = stock.lower()
            data["in_stock"] = "out" not in stock_lower and "缺货" not in stock

        # SKU
        sku = response.xpath("//*[@itemprop='sku']/text() | //*[@id='sku']/text()").get()
        if sku:
            data["sku"] = self._clean_text(sku)

    def _extract_article_fields(self, response: Response, data: dict) -> None:
        """提取文章/内容页特有字段"""
        # 作者
        author = (
            response.xpath("//meta[@name='author']/@content").get()
            or response.xpath("//a[contains(@class,'author')]/text()").get()
            or response.xpath("//*[@itemprop='author']/text()").get()
            or response.xpath("//span[contains(@class,'author')]//text()").get()
        )
        if author:
            data["author"] = self._clean_text(author)

        # 发布日期
        date_patterns = [
            "//meta[@property='article:published_time']/@content",
            "//meta[@itemprop='datePublished']/@content",
            "//time/@datetime",
            "//span[contains(@class,'date')]/text()",
            "//abbr[contains(@class,'published')]/@title",
        ]
        for pattern in date_patterns:
            date_val = response.xpath(pattern).get()
            if date_val:
                data["published_date"] = self._clean_text(date_val)
                break

        # 正文（更精确的提取）
        article_body = (
            response.xpath("//article").get()
            or response.xpath("//*[contains(@class,'post-content') or contains(@class,'entry-content') "
                            "or contains(@class,'article-body') or contains(@class,'article-content')]").get()
        )
        if article_body:
            from lxml.html import fromstring as html_fromstring
            tree = html_fromstring(article_body)
            text_content = tree.text_content().strip()
            if len(text_content) > len(data.get("body_text", "")):
                data["article_body"] = text_content[:15000]
                data["word_count"] = len(text_content.split())

        # 标签/分类
        tags = response.xpath(
            "//a[contains(@class,'tag')]/text() "
            "| //*[contains(@class,'tags') or contains(@class,'category')]//a/text()"
        ).getall()
        if tags:
            data["tags"] = [self._clean_text(t) for t in tags if self._clean_text(t)]

    def _extract_listing_fields(self, response: Response, data: dict) -> None:
        """提取列表页特有字段"""
        # 列表项数量
        count_patterns = [
            "//*[contains(@class,'count') or contains(@class,'total')]/text()",
            "//*[contains(text(),'条') or contains(text(),'results')]/text()",
        ]
        for pattern in count_patterns:
            counts = response.xpath(pattern).getall()
            for c in counts:
                nums = re.findall(r'\d[\d,]*', c.replace(",", ""))
                if nums:
                    data["total_results"] = int(nums[0])
                    break
            if "total_results" in data:
                break

        # 列表项摘要
        items_preview = response.xpath(
            "//*[contains(@class,'item') or contains(@class,'card') "
            "or contains(@class,'result') or contains(@class,'product')][position() <= 10]"
        )
        preview_list = []
        for item in items_preview[:10]:
            title_el = item.xpath(".//h2 | .//h3 | .//h4 | .//*[contains(@class,'title')]")
            title = title_el.xpath(".//text()").get()
            if title:
                preview_list.append(self._clean_text(title))
        if preview_list:
            data["items_preview"] = preview_list

    def handle_pagination(self, response: Response) -> Iterator[Request]:
        """处理分页 — 发现下一页链接"""
        if self._template_config and self._template_config.pagination:
            pagination_cfg = self._template_config.pagination
            if not pagination_cfg.enabled:
                return

            # URL 参数分页
            if pagination_cfg.url_pattern and "{page}" in pagination_cfg.url_pattern:
                current_page = response.meta.get("page", 1)
                next_page = current_page + 1
                if next_page <= pagination_cfg.max_pages:
                    next_url = pagination_cfg.url_pattern.format(page=next_page)
                    yield Request(
                        url=urljoin(response.url, next_url),
                        callback=self.parse,
                        meta={**response.meta, "page": next_page},
                    )
                return

        # 通用分页发现
        next_selectors = getattr(
            self._template_config, "next_page_selectors", None
        ) or [
            'a.next', 'a[aria-label="Next"]', 
            'a:contains("下一页")', 'a:contains(">")', 'a:contains("»")',
            '[rel="next"]',
        ]

        for selector in next_selectors:
            next_link = response.css(selector).attrib.get("href")
            if not next_link:
                # skip xpath for css pseudo-selectors
                    try:
                        next_link = response.xpath(f"//{selector}/@href").get()
                    except ValueError:
                        next_link = None

            if next_link:
                full_next_url = urljoin(response.url, next_link)
                current_page = response.meta.get("page", 1)
                
                if current_page < (self.config.max_pages or 50) and full_next_url != response.url:
                    yield Request(
                        url=full_next_url,
                        callback=self.parse,
                        meta={
                            **response.meta,
                            "page": current_page + 1,
                            "start_time": time.time(),
                        },
                    )
                    return  # 只取一个下一页

    def discover_links(self, response: Response) -> Iterator[Request]:
        """发现并跟踪同域相关链接"""
        base_domain = urlparse(response.url).netloc
        depth = response.meta.get("depth", 0)

        if depth >= self.config.depth_limit:
            return

        # 获取同域链接
        links = response.xpath("//a[@href]/@href").getall()
        seen: set[str] = set()

        for link in links[:50]:  # 限制每页发现的链接数
            full_url = urljoin(response.url, link)
            parsed = urlparse(full_url)

            # 只跟踪同域链接
            if parsed.netloc != base_domain:
                continue

            # 排除特殊路径
            exclude = self.config.template_config.exclude_patterns if self.config.template_config else []
            excluded = any(re.match(pat, full_url) for pat in exclude)
            if excluded or full_url in seen or full_url == response.url:
                continue

            seen.add(full_url)

            yield Request(
                url=full_url,
                callback=self.parse,
                errback=self._handle_error,
                meta={
                    "task_id": self.task_id,
                    "start_time": time.time(),
                    "depth": depth + 1,
                },
            )
