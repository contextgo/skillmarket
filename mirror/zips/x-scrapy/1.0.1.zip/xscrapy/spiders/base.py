"""
Spider 基类 — 所有 XScrapy Spider 的公共基类
"""

from __future__ import annotations

import time
import logging
from typing import Any, Optional, Iterator
from datetime import datetime, timezone

import scrapy
from scrapy.http import Response, TextResponse, JsonRequest
from scrapy import Request

from xscrapy.models.data_models import (
    CrawlMetadata,
    StandardItem,
    XScrapyConfig,
)

logger = logging.getLogger(__name__)


class XScrapySpider(scrapy.Spider):
    """XScrapy Spider 基类"""

    # 子类必须定义这些属性
    custom_settings: dict[str, Any] = {}

    def __init__(
        self,
        urls: Optional[list[str]] = None,
        config: Optional[XScrapyConfig] = None,
        task_id: Optional[str] = None,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.start_urls = urls or []
        self.config = config or XScrapyConfig(urls=self.start_urls)
        self.task_id = task_id or "xscrapy_unknown"
        self._start_time: float = 0

    def start_requests(self) -> Iterator[Request]:
        """生成初始请求"""
        for url in self.start_urls:
            yield Request(
                url=url,
                callback=self.parse,
                errback=self._handle_error,
                meta={
                    "task_id": self.task_id,
                    "start_time": time.time(),
                    "depth": 0,
                },
                dont_filter=True,
            )

    def parse(self, response: Response) -> Any:
        """主解析入口 — 由子类实现"""
        raise NotImplementedError("子类必须实现 parse 方法")

    def _build_metadata(self, response: Response, extract_method: str = "rule") -> CrawlMetadata:
        """构建抓取元数据"""
        start_time = response.meta.get("start_time", time.time())
        response_time_ms = int((time.time() - start_time) * 1000) if start_time else None
        
        return CrawlMetadata(
            task_id=self.task_id,
            spider=self.name,
            source_url=response.url,
            crawled_at=datetime.now(timezone.utc),
            render_mode=getattr(response.meta.get("render_mode"), "value", "static") or "static",
            confidence_score=1.0,
            version="1.0.0",
            extract_method=extract_method,
            response_time_ms=response_time_ms,
            retry_count=response.meta.get("retry_times", 0),
        )

    def _make_item(self, data: dict[str, Any], response: Response, method: str = "rule") -> dict:
        """构建标准化数据项 — 返回 dict 以兼容 Scrapy pipeline"""
        metadata = self._build_metadata(response, extract_method=method)
        result = {
            "metadata": metadata.model_dump() if hasattr(metadata, 'model_dump') else metadata,
            "data": data,
            "links": {},
        }
        logger.info(f"[DEBUG] _make_item -> keys={list(result.keys())}, data_keys={list(data.keys())[:8]}")
        return result

    def _handle_error(self, failure: Any) -> None:
        """统一错误处理"""
        logger.error(f"请求失败: {failure.request.url} | 错误: {failure}")
        # 可在此处记录到错误统计

    @staticmethod
    def _is_text_response(response: Response) -> bool:
        """检查是否为文本响应（可解析）"""
        return isinstance(response, TextResponse) and len(response.text.strip()) > 10

    @staticmethod
    def _clean_text(text: str) -> str:
        """清理文本：去空白、换行等"""
        if not text:
            return ""
        return " ".join(text.split()).strip()
