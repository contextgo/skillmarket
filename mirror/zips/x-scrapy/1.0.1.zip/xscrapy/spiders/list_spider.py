"""List Spider — 列表页专用爬虫"""

from __future__ import annotations

from typing import Any, Iterator
from urllib.parse import urljoin

from scrapy import Request
from scrapy.http import Response

from xscrapy.spiders.base import XScrapySpider


class ListSpider(XScrapySpider):
    """
    列表页 Spider
    
    专注于列表/搜索结果页的高效爬取：
    - 批量提取列表项
    - 自动翻页
    - 支持无限滚动
    """

    name = "list_spider"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.list_selector = None
        self._setup_template()

    def _setup_template(self) -> None:
        if self.config.template_config and self.config.template_config.list_selector:
            self.list_selector = self.config.template_config.list_selector

    def parse(self, response: Response) -> Any:
        if not self._is_text_response(response):
            return

        # 获取列表容器
        container_sel = self.list_selector or self._auto_detect_list_container(response)
        items = response.css(container_sel) if container_sel else []

        if not items:
            # 回退到通用提取
            from xscrapy.spiders.universal import UniversalSpider
            uni = UniversalSpider(urls=[], config=self.config)
            uni.name = self.name
            yield from uni.parse(response)
            return

        # 提取列表项
        for item_elem in items:
            item_data = self._extract_list_item(item_elem, response)
            if item_data:
                # 返回 dict 以兼容 Scrapy pipeline
                yield {
                    "metadata": self._build_metadata(response).model_dump(),
                    "data": item_data,
                    "links": {},
                }

        # 分页
        yield from self._paginate(response)

    def _auto_detect_list_container(self, response: Response) -> str | None:
        """自动检测列表容器选择器"""
        candidates = [
            "div.product-list", "div.item-list", "ul.result-list",
            "div[class*='list']", "div[class*='grid']",
            "section[class*='products']", "[class*='search-results']",
            "ol.products", "ul.posts",
            "[role='list']",
            "main > div > div", "main > ul", "main > ol",
        ]
        for sel in candidates:
            elements = response.css(sel)
            if len(elements) >= 2:  # 至少2个元素才认为是列表
                return sel
        return None

    def _extract_list_item(self, selector: Any, response: Response) -> dict:
        """提取单个列表项"""
        data: dict[str, Any] = {}

        # 标题/名称
        title_parts = selector.css("h2 a::text, h3 a::text, h4 a::text, [class*='title']::text, [class*='name']::text").getall()
        if title_parts:
            data["title"] = self._clean_text(" ".join(title_parts))

        # 链接
        href = selector.css("a::attr(href)").get()
        if href:
            data["url"] = urljoin(response.url, href)

        # 图片
        img_src = selector.css("img::attr(src), img::attr(data-src)").get()
        if img_src:
            data["image"] = urljoin(response.url, img_src)

        # 价格
        price_texts = selector.css("[class*='price']::text, [class*='cost']::text").getall()
        for pt in price_texts:
            cleaned = "".join(c for c in pt if c.isdigit() or c in ".," or c in ("¥", "$"))
            try:
                data["price"] = float(cleaned.replace("¥", "").replace("$", "").replace(",", ""))
                break
            except ValueError:
                continue

        # 描述
        desc_parts = selector.css("[class*='desc']::text, [class*='summary']::text, p::text").getall()
        if desc_parts:
            data["description"] = self._clean_text(" ".join(desc_parts[:3]))[:300]

        # 元信息（评分、销量等）
        meta_text = " ".join(selector.css("[class*='meta'], [class*='info'], [class*='stat']::text").getall())
        if meta_text.strip():
            data["meta_info"] = self._clean_text(meta_text)[:200]

        return data

    def _paginate(self, response: Response) -> Iterator[Request]:
        """翻页逻辑"""
        current_page = response.meta.get("page", 1)
        if current_page >= self.config.max_pages:
            return

        next_link = (
            response.css('a.next::attr(href)').get()
            or response.css('[rel="next"]::attr(href)').get()
            or response.xpath('//a[contains(text(), "下一页")]//@href').get()
        )

        if next_link:
            yield Request(
                url=urljoin(response.url, next_link),
                callback=self.parse,
                meta={**response.meta, "page": current_page + 1},
            )
