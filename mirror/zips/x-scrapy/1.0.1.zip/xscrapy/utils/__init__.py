"""Utils package init"""
from xscrapy.utils.url_utils import normalize_url, extract_domain, is_valid_url
from xscrapy.utils.html_utils import strip_html, truncate_text, extract_text
from xscrapy.utils.file_utils import ensure_dir, safe_filename, write_json, read_json
from xscrapy.utils.ai_client import AIClient

__all__ = [
    "normalize_url", "extract_domain", "is_valid_url",
    "strip_html", "truncate_text", "extract_text",
    "ensure_dir", "safe_filename", "write_json", "read_json",
    "AIClient",
]
