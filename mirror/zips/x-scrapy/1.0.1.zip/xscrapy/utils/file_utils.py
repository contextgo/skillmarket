"""文件工具函数"""

from __future__ import annotations

import json
import os
import hashlib
import shutil
from pathlib import Path
from typing import Any, Optional


def ensure_dir(path: str | Path) -> Path:
    """确保目录存在"""
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def safe_filename(name: str, max_length: int = 200) -> str:
    """将任意字符串转换为安全的文件名"""
    # 移除不安全字符
    unsafe = '<>:"/\\|?*\n\r\t'
    for char in unsafe:
        name = name.replace(char, "_")
    # 截断
    if len(name) > max_length:
        name = name[:max_length].rstrip("_")
    # 避免空文件名
    return name or "unnamed"


def write_json(
    path: str | Path,
    data: Any,
    pretty: bool = True,
    encoding: str = "utf-8",
) -> None:
    """写入 JSON 文件"""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    
    indent = 2 if pretty else None
    with open(path, "w", encoding=encoding) as f:
        json.dump(data, f, ensure_ascii=False, indent=indent)


def read_json(path: str | Path) -> Any:
    """读取 JSON 文件"""
    with open(Path(path), "r", encoding="utf-8") as f:
        return json.load(f)


def file_hash(path: str | Path) -> str:
    """计算文件的 SHA256 哈希"""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def file_size_human(size_bytes: int) -> str:
    """将字节大小转换为人类可读格式"""
    for unit in ("B", "KB", "MB", "GB"):
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f} TB"


def backup_file(path: str | Path) -> str:
    """创建文件备份，返回备份路径"""
    src = Path(path)
    if not src.exists():
        raise FileNotFoundError(f"文件不存在: {path}")
    
    timestamp = __import__("datetime").datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_name = f"{src.stem}_{timestamp}.bak{src.suffix}"
    backup_path = src.parent / backup_name
    
    shutil.copy2(src, backup_path)
    return str(backup_path)


def find_files_by_pattern(directory: str, pattern: str = "*.json") -> list[str]:
    """在目录中按通配符查找文件"""
    directory = Path(directory)
    return [str(p) for p in directory.glob(pattern) if p.is_file()]
