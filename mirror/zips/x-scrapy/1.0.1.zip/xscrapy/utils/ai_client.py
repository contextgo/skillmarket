"""AI 客户端封装 — 统一的 LLM 调用接口"""

from __future__ import annotations

import logging
from typing import Any, Optional, AsyncIterator

logger = logging.getLogger(__name__)


class AIClient:
    """
    AI 客户端 — 统一封装多个 LLM 提供商的调用接口
    
    支持的提供商：
    - OpenAI (GPT-3.5/4/o 系列)
    - 本地模型 (Ollama/vLLM 兼容 API)
    - 自定义兼容 OpenAI 接口的服务
    """

    def __init__(
        self,
        provider: str = "openai",
        model: str = "gpt-4o-mini",
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        temperature: float = 0.1,
        max_tokens: int = 4096,
        **kwargs,
    ):
        self.provider = provider.lower()
        self.model = model
        self.api_key = api_key
        self.base_url = base_url
        self.temperature = temperature
        self.max_tokens = max_tokens
        self._client: Any = None
        self._extra_kwargs = kwargs

    def _get_client(self):
        """延迟初始化客户端"""
        if self._client is not None:
            return self._client
            
        match self.provider:
            case "openai":
                import openai
                kwargs = {"api_key": self.api_key}
                if self.base_url:
                    kwargs["base_url"] = self.base_url
                self._client = openai.OpenAI(**kwargs)
            case "local":
                import openai
                self._client = openai.OpenAI(
                    base_url=self.base_url or "http://localhost:11434/v1",
                    api_key="ollama",  # Ollama 不需要真实 key
                )
            case _:
                # 默认尝试 OpenAI SDK
                import openai
                kwargs = {"api_key": self.api_key or ""}
                if self.base_url:
                    kwargs["base_url"] = self.base_url
                self._client = openai.OpenAI(**kwargs)
                
        return self._client

    def chat(
        self,
        messages: list[dict],
        *,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        response_format: Optional[dict] = None,
        stream: bool = False,
    ) -> str | AsyncIterator:
        """
        发送聊天请求
        
        Args:
            messages: 消息列表 [{"role": "system/user", "content": "..."}]
            temperature: 温度参数
            max_tokens: 最大 token 数
            response_format: 响应格式限制，如 {"type": "json_object"}
            stream: 是否流式输出
        
        Returns:
            字符串或异步迭代器（stream=True）
        """
        client = self._get_client()
        
        kwargs = dict(
            model=self.model,
            messages=messages,
            temperature=temperature or self.temperature,
            max_tokens=max_tokens or self.max_tokens,
            **self._extra_kwargs,
        )
        
        if response_format:
            kwargs["response_format"] = response_format
            
        if stream:
            return client.chat.completions.create(**{**kwargs, "stream": True})
            
        response = client.chat.completions.create(**kwargs)
        return response.choices[0].message.content or ""

    def chat_json(
        self,
        messages: list[dict],
        **kwargs,
    ) -> dict:
        """发送聊天请求并自动解析 JSON 返回"""
        import json
        raw = self.chat(messages, response_format={"type": "json_object"}, **kwargs)
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            logger.warning("AI 返回的不是有效 JSON，尝试修复...")
            # 尝试从响应中提取 JSON
            start = raw.find("{")
            end = raw.rfind("}") + 1
            if start >= 0 and end > start:
                return json.loads(raw[start:end])
            raise ValueError(f"无法解析 AI 响应为 JSON: {raw[:200]}")

    async def chat_async(self, messages: list[dict], **kwargs) -> str:
        """异步聊天方法"""
        client = self._get_client()
        response = await client.chat.completions.create(
            model=self.model,
            messages=messages,
            **kwargs,
        )
        return response.choices[0].message.content or ""

    def health_check(self) -> dict:
        """健康检查 — 验证连接和认证是否正常"""
        try:
            test_response = self.chat(
                messages=[{"role": "user", "content": "Hi"}],
                max_tokens=5,
            )
            return {
                "status": "ok",
                "provider": self.provider,
                "model": self.model,
                "test_response": test_response[:50] if test_response else "",
            }
        except Exception as e:
            return {
                "status": "error",
                "provider": self.provider,
                "model": self.model,
                "error": str(e),
            }

    @staticmethod
    def detect_available_providers() -> list[str]:
        """检测环境中可用的 AI 提供商"""
        available = []
        try:
            import openai
            available.append("openai")
        except ImportError:
            pass
            
        # 检查本地服务
        import socket
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(1)
                s.connect(("localhost", 11434))
                available.append("local (Ollama)")
        except (socket.error, socket.timeout):
            pass
            
        return available
