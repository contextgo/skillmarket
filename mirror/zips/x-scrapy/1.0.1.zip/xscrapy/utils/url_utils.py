"""URL 工具函数"""

from __future__ import annotations

from urllib.parse import urlparse, urljoin, urlencode, parse_qs, unquote
from typing import Optional


def normalize_url(url: str) -> str:
    """标准化 URL：去除 fragment，排序 query params，统一 scheme"""
    if not url:
        return url
    
    parsed = urlparse(url)
    
    # 标准化 scheme
    scheme = parsed.scheme.lower() or "https"
    netloc = parsed.netloc.lower()
    
    # 排序参数
    params = sorted(parse_qs(parsed.query).items())
    new_query = urlencode({k: v[0] for k, v in params}) if params else ""
    
    normalized = f"{scheme}://{netloc}{parsed.path}"
    if new_query:
        normalized += f"?{new_query}"
        
    return normalized


def extract_domain(url: str) -> str:
    """提取域名（不含 scheme 和 path）"""
    parsed = urlparse(url)
    return parsed.netloc or ""


def is_valid_url(url: str) -> bool:
    """检查 URL 是否有效"""
    try:
        result = urlparse(url)
        return all([result.scheme in ("http", "https"), result.netloc])
    except Exception:
        return False


def get_base_url(url: str) -> str:
    """获取基础 URL (scheme + domain)"""
    parsed = urlparse(url)
    return f"{parsed.scheme}://{parsed.netloc}"


def urls_same_domain(url1: str, url2: str) -> bool:
    """判断两个 URL 是否同域"""
    return extract_domain(url1).lower() == extract_domain(url2).lower()


def clean_url(url: str) -> str:
    """清理 URL：去掉追踪参数等"""
    from urllib.parse import urlparse, urlencode, parse_qs, ParseResult
    
    parsed = urlparse(url)
    # 常见的追踪/广告参数
    tracking_params = {
        'utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content',
        'fbclid', 'gclid', '_ga', '__ref', 'ref', 'source', 'clickid',
    }
    params = {k: v for k, v in parse_qs(parsed.query).items()
              if k.lower() not in tracking_params}
    
    cleaned_query = urlencode({k: v[0] for k, v in params.items()}, doseq=True) if params else ""
    
    return ParseResult(
        scheme=parsed.scheme,
        netloc=parsed.netloc,
        path=parsed.path,
        params=parsed.params,
        query=cleaned_query,
        fragment="",  # 去掉 fragment
    ).geturl()


def resolve_relative(base_url: str, relative_url: str) -> str:
    """解析相对 URL 为绝对 URL"""
    return urljoin(base_url, relative_url)
