"""HTML 工具函数"""

from __future__ import annotations

import re
import html as html_module
from typing import Optional


def strip_html(html_str: str) -> str:
    """
    移除所有 HTML 标签，返回纯文本
    保留基本的文本结构（段落换行等）
    """
    if not html_str:
        return ""
    
    # 替换块级元素为换行
    block_tags = re.compile(r'</?(?:p|div|br|li|tr|td|h[1-6]|section|article)[^>]*>', re.IGNORECASE)
    text = block_tags.sub('\n', html_str)
    
    # 移除 script 和 style 内容
    text = re.sub(r'<script[^>]*>.*?</script>', '', text, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r'<style[^>]*>.*?</style>', '', text, flags=re.DOTALL | re.IGNORECASE)
    
    # 移除其余标签
    text = re.sub(r'<[^>]+>', '', text)
    
    # 解码 HTML 实体
    text = html_module.unescape(text)
    
    # 清理空白
    text = re.sub(r'[ \t]+', ' ', text)
    text = re.sub(r'\n\s*\n+', '\n\n', text)
    
    return text.strip()


def extract_text(element, max_length: int = 0) -> str:
    """从 Scrapy Selector/lxml 元素提取纯文本"""
    if element is None:
        return ""
    
    try:
        texts = element.xpath(".//text()").getall()
        text = " ".join(t.strip() for t in texts if t.strip())
        return truncate_text(text, max_length) if max_length else text
    except Exception:
        return str(element)[:max_length] if max_length else str(element)


def truncate_text(text: str, max_length: int) -> str:
    """智能截断文本（尽量在句号处截断）"""
    if not text or len(text) <= max_length:
        return text
    
    # 尝试在句子边界截断
    cutoff_point = text[:max_length].rfind("。")
    if cutoff_point > max_length * 0.5:
        return text[:cutoff_point + 1].strip()
    
    cutoff_point = text[:max_length].rfind(" ")
    if cutoff_point > max_length * 0.7:
        return text[:cutoff_point].strip() + "..."
    
    return text[:max_length - 3].strip() + "..."


def count_words(text: str) -> int:
    """统计字数（中英文混合）"""
    if not text:
        return 0
    
    cn_chars = sum(1 for c in text if '\u4e00' <= c <= '\u9fff')
    en_words = len(text.split())
    return cn_chars + en_words


def get_fingerprint(html_content: str) -> str:
    """生成 HTML 页面的指纹（用于内容去重）"""
    import hashlib
    
    # 提取主要内容生成指纹
    text = strip_html(html_content)
    text = re.sub(r'\s+', ' ', text).lower().strip()
    
    return hashlib.sha256(text.encode()).hexdigest()[:20]


def is_likely_dynamic_page(html_content: str) -> bool:
    """检测页面是否可能是动态渲染的（JS SPA 等）"""
    indicators = [
        r'<script[^>]*src="[^"]*react[^"]*"[^>]*>',
        r'<script[^>]*src="[^"]*vue[^"]*"[^>]*>',
        r'<script[^>]*src="[^"]*angular[^"]*"[^>]*>',
        r'<script[^>]*src="[^"]*next[^"]*"[^>]*>',
        r'<div\s+id=["\']app["\']',
        r'<div\s+id=["\']root["\']',
        r'ng-app\b',
        r'data-reactroot\b',
        r'nuxt\.',
        r'window\.__NUXT__',
        r'__NEXT_DATA__',
        r'"@ng_module"',
        r'<noscript>[^<]*请启用JavaScript',
        r'Please enable JavaScript',
        r'require\(\[\s*[\'"]',
    ]
    
    content_lower = html_content[:10000].lower()
    return any(re.search(indicator, content_lower) for indicator in indicators)
