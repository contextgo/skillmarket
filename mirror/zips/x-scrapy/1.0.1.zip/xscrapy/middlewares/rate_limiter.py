"""
速率限制中间件
"""

from __future__ import annotations

import time
import random
import logging
from collections import defaultdict
from typing import Any

from scrapy import Request
from scrapy.http import Response
from scrapy.downloadermiddlewares.retry import RetryMiddleware

logger = logging.getLogger(__name__)


class RateLimitMiddleware:
    """
    自适应速率限制中间件
    
    特性：
    - 根据响应时间自动调整延迟
    - 对不同域名独立限速
    - 支持突发流量控制
    """

    def __init__(self, settings):
        self.min_delay = settings.getfloat("DOWNLOAD_DELAY", 1.0)
        self.max_delay = settings.getfloat("XSCRAPY_MAX_DELAY", 10.0)
        self.concurrent_requests = settings.getint("CONCURRENT_REQUESTS", 8)
        
        self._domain_last_access: dict[str, float] = {}
        self._domain_response_times: dict[str, list[float]] = defaultdict(list)
        self._adaptive_delays: dict[str, float] = {}

    @classmethod
    def from_crawler(cls, crawler):
        return cls(crawler.settings)

    def process_request(self, request: Request, spider) -> None:
        """在发送前检查速率限制"""
        domain = request.url.split("/")[2]
        now = time.time()

        last_access = self._domain_last_access.get(domain, 0)
        
        # 使用该域名的自适应延迟或默认延迟
        delay = self._adaptive_delays.get(domain, self.min_delay)
        
        wait_time = last_access + delay - now
        if wait_time > 0:
            time.sleep(wait_time)
        
        self._domain_last_access[domain] = time.time()

    def process_response(self, request: Request, response: Response, spider) -> Response:
        """根据响应调整延迟"""
        domain = request.url.split("/")[2]
        # Scrapy 不同版本 meta 获取方式不同
        try:
            response_time = response.meta.get("download_latency") or 0
        except AttributeError:
            try:
                response_time = getattr(response, "meta", {}).get("download_latency") or 0
            except Exception:
                response_time = 0
        
        # 记录响应时间
        times = self._domain_response_times[domain]
        times.append(response_time)
        if len(times) > 10:
            times.pop(0)  # 只保留最近10次
        
        # 自适应调整：如果响应变慢，增加延迟
        avg_response_time = sum(times) / len(times) if times else 0
        
        if avg_response_time > 5.0:  # 平均响应超过5秒
            new_delay = min(delay * 1.5, self.max_delay)
        elif avg_response_time < 1.0:  # 响应很快，可以适当加速
            delay = self._adaptive_delays.get(domain, self.min_delay)
            new_delay = max(delay * 0.95, self.min_delay)
        else:
            new_delay = self._adaptive_delays.get(domain, self.min_delay)
        
        self._adaptive_delays[domain] = new_delay
        
        return response
