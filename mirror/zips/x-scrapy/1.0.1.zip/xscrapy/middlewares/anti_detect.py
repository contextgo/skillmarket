"""
反检测中间件 — 模拟真实浏览器行为，降低被识别为爬虫的概率
"""

from __future__ import annotations

import random
import logging
import time
from typing import Any

from scrapy import signals
from scrapy.http import Request, Response, Headers
from scrapy.downloadermiddlewares.useragent import UserAgentMiddleware
from scrapy.core.downloader.contextfactory import ScrapyClientContextFactory

logger = logging.getLogger(__name__)

# 真实浏览器 UA 池（按权重）
UA_POOL = [
    # Chrome (Windows) - 40%
    ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
     "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36", 15),
    ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
     "(KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36", 10),
    ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
     "(KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36", 8),
    ("Mozilla/5.0 (Windows NT 11.0; Win64; x64) AppleWebKit/537.36 "
     "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36", 7),
    # Safari (macOS) - 20%
    ("Mozilla/5.0 (Macintosh; Intel Mac OS X 14_3) AppleWebKit/605.1.15 "
     "(KHTML, like Gecko) Version/18.4.1 Safari/605.1.15", 12),
    ("Mozilla/5.0 (Macintosh; Intel Mac OS X 14_2) AppleWebKit/605.1.15 "
     "(KHTML, like Gecko) Version/18.3 Safari/605.1.15", 6),
    ("Mozilla/5.0 (Macintosh; Intel Mac OS X 14_4) AppleWebKit/605.1.15 "
     "(KHTML, like Gecko) Version/18.5 Safari/605.1.15", 2),
    # Firefox - 15%
    ("Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:133.0) "
     "Gecko/20100101 Firefox/133.0", 8),
    ("Mozilla/5.0 (Macintosh; Intel Mac OS X 14.3; rv:133.0) "
     "Gecko/20100101 Firefox/133.0", 7),
    # Edge - 15%
    ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
     "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0", 12),
    ("Mozilla/5.0 (Macintosh; Intel Mac OS X 14_3) AppleWebKit/537.36 "
     "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0", 3),
    # Mobile - 10%
    ("Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X) "
     "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Mobile/15E148 Safari/604.1", 5),
    ("Mozilla/5.0 (Linux; Android 14; SM-S928B) AppleWebKit/537.36 "
     "(KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36", 5),
]

# 构建带权重的 UA 列表用于随机选择
_WEIGHTED_UA: list[str] = []
for ua, weight in UA_POOL:
    _WEIGHTED_UA.extend([ua] * weight)

# 接受的语言列表
ACCEPT_LANGUAGES = [
    "zh-CN,zh;q=0.9,en;q=0.8",
    "zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.6",
    "en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.6",
    "zh-Hans-CN,zh;q=0.9",
]

# 默认请求头
DEFAULT_HEADERS = {
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,"
              "image/webp,image/apng,*/*;q=0.8",
    "Accept-Language": ACCEPT_LANGUAGES[0],
    "Accept-Encoding": "gzip, deflate, br",
    "Connection": "keep-alive",
    "Upgrade-Insecure-Requests": "1",
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none",
    "Sec-Fetch-User": "?1",
    "Cache-Control": "max-age=0",
}


class AntiDetectMiddleware:
    """
    反检测中间件
    
    功能：
    1. User-Agent 随机轮换（基于真实浏览器分布）
    2. 伪装浏览器指纹头信息
    3. 请求间隔模拟人类行为
    4. Cookie 自动管理
    5. Referer 智能设置
    """

    def __init__(self, settings):
        self.enable_ua_rotation = settings.getbool("XSCRAPY_ENABLE_UA_ROTATION", True)
        self.custom_headers = settings.getdict("XSCRAPY_CUSTOM_HEADERS", {})
        self._last_request_time: float = 0
        self._min_delay = settings.getfloat("DOWNLOAD_DELAY", 1.0)

    @classmethod
    def from_crawler(cls, crawler):
        middleware = cls(crawler.settings)
        return middleware

    def process_request(self, request: Request, spider) -> None:
        """处理出站请求 — 添加反检测措施"""
        
        # 1. User-Agent 轮换
        if self.enable_ua_rotation and not request.headers.get("User-Agent"):
            ua = random.choice(_WEIGHTED_UA)
            request.headers["User-Agent"] = ua
        
        # 2. 设置标准浏览器头
        for key, value in DEFAULT_HEADERS.items():
            if key not in request.headers or key.lower() == "accept-language":
                # Accept-Language 也随机化
                if key == "Accept-Language":
                    value = random.choice(ACCEPT_LANGUAGES)
                request.headers[key] = value
        
        # 3. 自定义覆盖
        for key, value in self.custom_headers.items():
            request.headers[key] = value
        
        # 4. Referer 处理
        if not request.headers.get("Referer") and request.meta.get("referer_url"):
            request.headers["Referer"] = request.meta["referer_url"]
        
        # 5. 速率控制 — 检查距上次请求的时间
        elapsed = time.time() - self._last_request_time
        if elapsed < self._min_delay * 0.5:  # 至少等待一半的最小延迟
            time.sleep(self._min_delay * 0.5)
        
        self._last_request_time = time.time()

    def process_response(self, request: Request, response: Response, spider) -> Response:
        """处理响应 — 检测是否被封"""
        
        # 常见封禁特征检测
        response_text = response.text[:500] if hasattr(response, 'text') else ""
        
        ban_indicators = [
            "访问频率过高",
            "access denied",
            "403 forbidden",
            "人机验证",
            "captcha",
            "验证码",
            "请稍后再试",
            "too many requests",
            "rate limit",
            "cloudflare",
            "just a moment",
        ]
        
        lower_text = response_text.lower()
        for indicator in ban_indicators:
            if indicator.lower() in lower_text:
                spider.logger.warning(
                    f"⚠️ 可能被封禁 ({response.status}) {request.url} | 特征: {indicator}"
                )
                # 可以在这里触发代理切换或 CAPTCHA 处理
                break
        
        return response
