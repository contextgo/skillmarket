"""
渲染中间件 — 控制页面渲染方式（静态/JS/Playwright）
"""

from __future__ import annotations

import logging
from typing import Any, Optional

from scrapy import Request
from scrapy.http import HtmlResponse, Response
from scrapy.http.headers import Headers

logger = logging.getLogger(__name__)


class RenderMiddleware:
    """
    渲染模式控制中间件
    
    根据配置决定如何渲染页面：
    - static: 直接 HTTP 请求（默认，最快）
    - splash: 通过 Scrapy-Splash 渲染 JS
    - playwright: 通过 Playwright 完整浏览器渲染
    """

    def __init__(self, settings):
        render_mode = settings.get("XSCRAPY_RENDER_MODE", "static")
        self.render_mode = render_mode
        self.splash_url = settings.get("SPLASH_URL", "")
        self._playwright_available = False
        
        if render_mode in ("splash", "auto"):
            try:
                import scrapy_splash
                self._splash_available = True
                logger.info("Splash 渲染模式就绪")
            except ImportError:
                self._splash_available = False
                
        if render_mode in ("playwright", "auto"):
            try:
                from playwright.async_api import async_playwright
                self._playwright_available = True
                logger.info("Playwright 渲染模式就绪")
            except ImportError:
                self._playwright_available = False

    @classmethod
    def from_crawler(cls, crawler):
        return cls(crawler.settings)

    def process_request(self, request: Request, spider) -> Optional[Response]:
        """决定渲染方式"""
        meta_render = request.meta.get("render_mode", self.render_mode)
        
        if meta_render == "static" or (
            meta_render == "auto" and not request.meta.get("needs_js")
        ):
            return None  # 不干预，正常 HTTP 请求
        
        if meta_render == "splash" and self._splash_available:
            return self._render_with_splash(request)
        
        if meta_render in ("playwright", "auto") and self._playwright_available:
            # Playwright 是异步的，这里标记由下载器处理
            request.meta["needs_js"] = True
            request.meta["playwright"] = True
            return None
            
        # 回退到静态
        logger.debug(f"渲染引擎不可用，回退到静态: {meta_render}")
        request.meta["render_mode"] = "static"
        return None

    def _render_with_splash(self, request: Request) -> Request:
        """通过 Splash 渲染"""
        splash_args = {
            "html": 1,
            "png": 0,
            "wait": 2.0,
            "timeout": 30,
        }
        splash_request = request.replace(
            url=self.splash_url + "/render.json",
            method="POST",
            body=f"url={request.url}",
            headers={
                "Content-Type": "application/x-www-form-urlencoded",
            },
            meta={
                **request.meta,
                "splash_args": splash_args,
                "splash": splash_args,
            },
        )
        return splash_request
