"""
代理轮换中间件
"""

from __future__ import annotations

import random
import logging
from typing import Optional

from scrapy import Request
from scrapy.http import Response

logger = logging.getLogger(__name__)


class ProxyRotatorMiddleware:
    """
    代理 IP 轮换中间件
    
    支持策略：
    - round_robin: 轮询
    - random: 随机
    - sticky: 同一域名粘性（保持同一会话用同一代理）
    """

    def __init__(self, settings):
        proxy_pool: list[str] = settings.getlist("XSCRAPY_PROXY_POOL", [])
        rotation_strategy = settings.get("XSCRAPY_PROXY_ROTATION", "round_robin")
        auth_info: dict = settings.getdict("XSCRAPY_PROXY_AUTH", {})

        self.proxy_pool = [p.strip() for p in proxy_pool if p.strip()]
        self.strategy = rotation_strategy
        self.auth = auth_info
        self._index = 0
        self._sticky_map: dict[str, str] = {}  # domain -> proxy

        if not self.proxy_pool:
            logger.warning("代理池为空，ProxyRotatorMiddleware 将不会生效")

    @classmethod
    def from_crawler(cls, crawler):
        return cls(crawler.settings)

    def process_request(self, request: Request, spider) -> None:
        """为请求分配代理"""
        if not self.proxy_pool:
            return

        domain = request.url.split("/")[2]  # 提取 netloc

        match self.strategy:
            case "round_robin":
                proxy = self.proxy_pool[self._index % len(self.proxy_pool)]
                self._index += 1
            case "random":
                proxy = random.choice(self.proxy_pool)
            case "sticky":
                if domain not in self._sticky_map:
                    self._sticky_map[domain] = random.choice(self.proxy_pool)
                proxy = self._sticky_map[domain]
            case _:
                proxy = self.proxy_pool[0]

        request.meta["proxy"] = proxy
        request.meta["download_timeout"] = request.meta.get("download_timeout", 30)

        logger.debug(f"使用代理 {proxy[:30]}... 访问 {domain}")

    def process_exception(self, request: Request, exception: Exception, spider) -> Optional[Request]:
        """代理失败时的处理"""
        if isinstance(exception, (TimeoutError, ConnectionRefusedError)):
            current_proxy = request.meta.get("proxy", "")
            logger.warning(f"代理异常: {current_proxy[:30]}... | 错误: {exception}")
            
            # 如果有备用代理，可以重试
            if len(self.proxy_pool) > 1:
                # 标记当前代理不可用（简单处理：从池中移除）
                if current_proxy in self.proxy_pool:
                    self.proxy_pool.remove(current_proxy)
                    logger.info(f"已移除故障代理，剩余 {len(self.proxy_pool)} 个可用")
                
                return request.replace(dont_filter=True)
            
        return None

    def add_proxy(self, proxy_url: str) -> None:
        """动态添加代理"""
        if proxy_url not in self.proxy_pool:
            self.proxy_pool.append(proxy_url)
