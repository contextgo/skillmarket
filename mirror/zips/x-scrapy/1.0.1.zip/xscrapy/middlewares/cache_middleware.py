"""
缓存中间件 — 避免重复爬取相同 URL
"""

from __future__ import annotations

import hashlib
import logging
from typing import Optional

from scrapy import Request
from scrapy.http import Response
from scrapy.downloadermiddlewares.httpcache import HttpCacheMiddleware

logger = logging.getLogger(__name__)


class XScrapyCacheMiddleware:
    """
    智能缓存中间件
    
    基于 URL + 可选内容哈希的缓存策略：
    - 相同 URL 在同一任务中只抓取一次
    - 支持 TTL 过期
    - 缓存命中时返回缓存结果而不发网络请求
    """

    def __init__(self, settings):
        self.enabled = settings.getbool("HTTPCACHE_ENABLED", True)
        self.expiry_secs = settings.getint("XSCRAPY_CACHE_EXPIRY", 3600)  # 默认1小时
        self._cache: dict[str, tuple[float, Response]] = {}  # url -> (timestamp, response)
        
        logger.info(f"缓存中间件初始化 | TTL={self.expiry_secs}s")

    @classmethod
    def from_crawler(cls, crawler):
        return cls(crawler.settings)

    def process_request(self, request: Request, spider) -> Optional[Response]:
        """检查缓存"""
        if not self.enabled or request.meta.get("dont_cache"):
            return None
            
        cache_key = self._make_key(request.url)
        
        if cache_key in self._cache:
            timestamp, cached_response = self._cache[cache_key]
            
            if (time.time() - timestamp) < self.expiry_secs:
                logger.debug(f"缓存命中: {request.url[:80]}")
                spider.crawler.stats.inc_value("xscrapy/cache/hits")
                return cached_response
            else:
                del self._cache[cache_key]
                logger.debug(f"缓存过期: {request.url[:80]}")
        
        return None

    def process_response(self, request: Request, response: Response, spider) -> Response:
        """缓存成功的响应"""
        if not self.enabled or request.meta.get("dont_cache"):
            return response
            
        if response.status == 200:
            cache_key = self._make_key(request.url)
            self._cache[cache_key] = (time.time(), response)
            spider.crawler.stats.inc_value("xscrapy/cache/stored")
            
        return response

    @staticmethod
    def _make_key(url: str) -> str:
        """生成缓存键（URL 的 SHA256）"""
        return hashlib.sha256(url.encode()).hexdigest()[:16]

    def clear(self) -> None:
        """清空缓存"""
        count = len(self._cache)
        self._cache.clear()
        logger.info(f"缓存已清空 | 共 {count} 条")

    def stats(self) -> dict:
        """返回缓存统计"""
        return {
            "cached_urls": len(self._cache),
            "expiry_seconds": self.expiry_secs,
        }


# 需要在模块级导入 time
import time
