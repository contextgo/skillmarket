"""Middlewares package init"""

from xscrapy.middlewares.anti_detect import AntiDetectMiddleware
from xscrapy.middlewares.proxy_rotator import ProxyRotatorMiddleware
from xscrapy.middlewares.rate_limiter import RateLimitMiddleware
from xscrapy.middlewares.render_middleware import RenderMiddleware
from xscrapy.middlewares.cache_middleware import XScrapyCacheMiddleware

__all__ = [
    "AntiDetectMiddleware", "ProxyRotatorMiddleware",
    "RateLimitMiddleware", "RenderMiddleware", "XScrapyCacheMiddleware",
]
