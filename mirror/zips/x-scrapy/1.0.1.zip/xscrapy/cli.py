"""
XScrapy CLI — 命令行入口
基于 Typer 的现代化命令行工具
"""

from __future__ import annotations

import json
import sys
import time
from pathlib import Path
from typing import Optional, List

import typer
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn

from xscrapy.models.data_models import (
    AIConfig,
    AntiDetectConfig,
    OutputConfig,
    OutputFormat,
    ProxyConfig,
    RenderMode,
    TemplateConfig,
    XScrapyConfig,
)
from xscrapy.core.engine import XScrapyEngine
from xscrapy.core.settings import build_scrapy_settings
from xscrapy.core.spider_factory import SpiderFactory
from xscrapy.utils.file_utils import read_json, write_json

console = Console()
app = typer.Typer(
    name="xscrapy",
    help="🕷️  XScrapy — AI-Native 通用爬虫引擎 | 零配置智能爬取 · 标准化 JSON 输出",
    no_args_is_help=True,
    rich_markup_mode="rich",
)


# ============================================================
# 主命令: run — 运行爬取任务
# ============================================================

@app.command()
def run(
    urls: List[str] = typer.Argument(..., help="目标 URL (支持多个)"),
    
    # 模板和字段
    template: Optional[str] = typer.Option(None, "--template", "-t", help="场景模板 (ecommerce/news/social/forum/docs/custom)"),
    fields: Optional[str] = typer.Option(None, "--fields", "-f", help="指定提取字段，逗号分隔"),
    schema_file: Optional[typer.FileText] = typer.Option(None, "--schema", "-s", help="自定义 Schema 文件"),
    
    # 渲染模式
    render_mode: str = typer.Option("auto", "--render", "-r", help="渲染模式: static/splash/playwright/auto"),
    
    # 输出控制
    output: Optional[str] = typer.Option(None, "--output", "-o", help="输出文件路径"),
    format: str = typer.Option("json", "--format", help="输出格式: json/ndjson/csv"),
    no_metadata: bool = typer.Option(False, "--no-metadata", help="不包含元数据"),
    
    # 爬取范围
    max_pages: int = typer.Option(10, "--max-pages", help="最大翻页数"),
    max_items: int = typer.Option(1000, "--max-items", help="最大数据条数"),
    follow_links: bool = typer.Option(True, "--follow/--no-follow", help="是否跟踪链接"),
    depth_limit: int = typer.Option(2, "--depth", help="最大爬取深度"),
    
    # 反爬设置
    delay_min: float = typer.Option(1.0, "--delay-min", help="最小请求间隔(秒)"),
    delay_max: float = typer.Option(3.0, "--delay-max", help="最大请求间隔(秒)"),
    concurrent: int = typer.Option(8, "--concurrent", "-c", help="并发请求数"),
    timeout: int = typer.Option(30, "--timeout", help="请求超时(秒)"),
    retries: int = typer.Option(3, "--retries", help="重试次数"),
    
    # AI 设置
    ai: bool = typer.Option(False, "--ai", "--no-ai", help="启用 AI 智能解析"),
    ai_model: str = typer.Option("gpt-4o-mini", "--ai-model", help="AI 模型名称"),
    ai_key: Optional[str] = typer.Option(None, "--ai-key", help="AI API Key"),
    ai_url: Optional[str] = typer.Option(None, "--ai-url", help="AI API Base URL (用于兼容服务)"),
    
    # 代理设置
    proxy: Optional[str] = typer.Option(None, "--proxy", help="代理地址，如 socks5://127.0.0.1:1080"),
    proxy_list: Optional[str] = typer.Option(None, "--proxy-list", help="代理列表文件路径"),
    
    # 其他
    dry_run: bool = typer.Option(False, "--dry-run", help="干运行模式（不发送请求）"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="详细日志"),
):
    """运行爬取任务
    
    \b
    [bold]示例:[/bold]
      xscrapy run https://example.com
      xscrapy run https://shop.com/item/123 -t ecommerce -f title,price,stock
      xscrapy run https://news.com/tech --ai --max-pages 20 -o news.json
      xscrapy run https://example.com --dry-run --verbose
    """
    
    # 构建配置
    config = _build_config(
        urls=urls,
        template=template,
        fields=fields,
        schema_file=schema_file,
        render_mode=render_mode,
        output_path=output,
        format=format,
        include_metadata=not no_metadata,
        max_pages=max_pages,
        max_items=max_items,
        follow_links=follow_links,
        depth_limit=depth_limit,
        delay_min=delay_min,
        delay_max=delay_max,
        concurrent=concurrent,
        timeout=timeout,
        retries=retries,
        ai_enabled=ai,
        ai_model=ai_model,
        ai_key=ai_key,
        ai_url=ai_url,
        proxy=proxy,
        proxy_list=proxy_list,
        dry_run=dry_run,
        verbose=verbose,
    )
    
    # 执行爬取
    engine = XScrapyEngine(config)
    result = engine.run()
    
    # 打印结果摘要
    _print_result_summary(result)


def _build_config(**kwargs) -> XScrapyConfig:
    """从 CLI 参数构建 XScrapyConfig"""
    urls = kwargs["urls"]
    fields_str = kwargs.get("fields")
    
    # 解析字段列表
    fields = None
    if fields_str:
        fields = [f.strip() for f in fields_str.split(",") if f.strip()]
    
    # 加载模板
    template_config = None
    template_name = kwargs.get("template")
    if template_name:
        template_config = load_template(template_name)
    
    # 渲染模式映射
    render_map = {
        "static": RenderMode.STATIC,
        "splash": RenderMode.SPLASH,
        "playwright": RenderMode.PLAYWRIGHT,
        "auto": RenderMode.AUTO,
    }
    render_mode = render_map.get(kwargs["render_mode"], RenderMode.AUTO)
    
    # 输出格式映射
    fmt_map = {
        "json": OutputFormat.JSON,
        "ndjson": OutputFormat.NDJSON,
        "csv": OutputFormat.CSV,
    }
    output_format = fmt_map.get(kwargs["format"].lower(), OutputFormat.JSON)
    
    # 代理池
    proxy_pool = []
    if kwargs.get("proxy"):
        proxy_pool.append(kwargs["proxy"])
    if kwargs.get("proxy_list"):
        try:
            with open(kwargs["proxy_list"]) as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#"):
                        proxy_pool.append(line)
        except FileNotFoundError:
            console.print(f"[red]代理列表文件不存在: {kwargs['proxy_list']}[/red]")
            raise typer.Exit(1)
    
    config = XScrapyConfig(
        urls=urls,
        template=kwargs.get("template"),
        template_config=template_config,
        fields=fields,
        max_pages=kwargs["max_pages"],
        max_items=kwargs["max_items"],
        follow_links=kwargs["follow_links"],
        depth_limit=kwargs["depth_limit"],
        
        render_mode=render_mode,
        output=OutputConfig(
            format=output_format,
            file_path=kwargs.get("output_path"),
            pretty=True,
            include_metadata=kwargs["include_metadata"],
        ),
        
        anti_detect=AntiDetectConfig(
            enable_delay=True,
            min_delay=kwargs["delay_min"],
            max_delay=kwargs["delay_max"],
            concurrent_requests=kwargs["concurrent"],
            download_timeout=kwargs["timeout"],
            retry_times=kwargs["retries"],
        ),
        
        proxy=ProxyConfig(
            enabled=len(proxy_pool) > 0,
            pool=proxy_pool,
        ),
        
        ai=AIConfig(
            enabled=kwargs["ai_enabled"],
            model=kwargs["ai_model"],
            api_key=kwargs.get("ai_key"),
            base_url=kwargs.get("ai_url"),
        ),
        
        log_level="DEBUG" if kwargs["verbose"] else "INFO",
        dry_run=kwargs["dry_run"],
    )
    
    return config


# ============================================================
# 子命令: templates — 列出可用模板
# ============================================================

@app.command("templates")
def list_templates():
    """列出所有可用的场景模板"""
    table = Table(title="XScrapy 场景模板", show_header=True)
    table.add_column("模板名", style="cyan")
    table.add_column("描述", style="white")
    table.add_column("Spider 类型", style="yellow")
    table.add_column("推荐字段", style="dim")
    
    templates_info = get_all_templates_info()
    
    for info in templates_info:
        table.add_row(
            info["name"],
            info["description"],
            info["spider_type"],
            ", ".join(info["suggested_fields"][:6]),
        )
    
    console.print(table)


# ============================================================
# 子命令: extract — 单页快速提取
# ============================================================

@app.command()
def extract(
    url: str = typer.Argument(..., help="目标 URL"),
    *,
    template: Optional[str] = typer.Option(None, "-t", "--template", help="场景模板"),
    fields: Optional[str] = typer.Option(None, "-f", "--fields", help="指定字段"),
    ai: bool = typer.Option(False, "--ai", help="使用 AI 提取"),
    output: Optional[str] = typer.Option(None, "-o", "--output", help="输出文件"),
):
    """
    快速单页数据提取
    
    \b
    示例：
      xscrapy extract https://news.example.com/article/123 -t news --ai
      xscrapy extract https://product.example.com/p/456 -f title,price,rating
    """
    result_data = quick_extract(url=url, template=template, fields=fields, ai=ai)
    
    if output:
        write_json(output, result_data, pretty=True)
        console.print(f"✅ 结果已保存到 [cyan]{output}[/cyan]")
    else:
        console.print_json(json.dumps(result_data, ensure_ascii=False, indent=2))


# ============================================================
# 子命令: check — 健康检查
# ============================================================

@app.command("check")
def health_check():
    """运行健康检查"""
    from xscrapy.utils.ai_client import AIClient
    
    console.print("[bold]🔍 XScrapy 健康检查[/bold]\n")
    
    checks_passed = 0
    checks_total = 4
    
    # 1. Python 环境
    import sys
    py_version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    console.print(f"  🐍 Python: {py_version} {'✅' if sys.version_info >= (3, 11) else '⚠️'}")
    if sys.version_info >= (3, 11):
        checks_passed += 1
    
    # 2. Scrapy
    try:
        import scrapy
        console.print(f"  🕷️  Scrapy: {scrapy.__version__} ✅")
        checks_passed += 1
    except ImportError:
        console.print(f"  🕷️  Scrapy: 未安装 ❌")
    
    # 3. AI 客户端
    providers = AIClient.detect_available_providers()
    if providers:
        console.print(f"  🤖 AI 提供商: {', '.join(providers)} ✅")
        checks_passed += 1
    else:
        console.print(f"  🤖 AI 提供商: 未检测到 ⚠️ (可选)")
        checks_total -= 1  # 不算失败
    
    # 4. Playwright
    try:
        import playwright
        console.print(f"  🌐 Playwright: 已安装 ✅")
        checks_passed += 1
    except ImportError:
        console.print(f"  🌐 Playwright: 未安装 ⚠️ (JS 渲染需要)")
        checks_total -= 1
    
    console.print()
    bar_width = 40
    ratio = checks_passed / max(checks_total, 1)
    filled = int(bar_width * ratio)
    bar = "█" * filled + "░" * (bar_width - filled)
    color = "green" if ratio >= 0.8 else "yellow" if ratio >= 0.5 else "red"
    
    console.print(f"  [{color}]{bar}[/{color}] {checks_passed}/{checks_total}")


# ============================================================
# 辅助函数
# ============================================================

def load_template(template_name: str) -> Optional[TemplateConfig]:
    """加载预定义或自定义模板"""
    # 内置模板定义
    BUILTIN_TEMPLATES: dict[str, dict] = {
        "ecommerce": {
            "name": "电商产品页",
            "description": "电商商品详情页数据提取",
            "spider_type": "universal",
            "page_type": "product",
            "suggested_fields": ["title", "price", "currency", "images", "brand", 
                               "category", "rating", "review_count", "in_stock", "specs", "seller"],
        },
        "news": {
            "name": "新闻文章",
            "description": "新闻/博客文章页面数据提取",
            "spider_type": "universal",
            "page_type": "article",
            "suggested_fields": ["title", "author", "published_date", "article_body", 
                               "tags", "word_count", "language", "images", "category"],
        },
        "social": {
            "name": "社交媒体",
            "description": "社交媒体帖子/用户主页数据提取",
            "spider_type": "universal",
            "page_type": "unknown",
            "suggested_fields": ["title", "author", "published_date", "body_text",
                               "likes", "shares", "comments_count", "images"],
        },
        "forum": {
            "name": "论坛帖子",
            "description": "论坛/BBS 帖子及回复提取",
            "spider_type": "detail",
            "page_type": "forum",
            "suggested_fields": ["title", "author", "published_date", "body_text",
                               "comments", "related_items", "breadcrumbs"],
        },
        "docs": {
            "name": "技术文档",
            "description": "技术文档/API 文档页面提取",
            "spider_type": "universal",
            "page_type": "document",
            "suggested_fields": ["title", "body_text", "sections", "code_blocks",
                               "internal_links", "last_updated", "version"],
        },
        "listing": {
            "name": "通用列表",
            " description": "搜索结果/列表页面批量提取",
            "spider_type": "list",
            "page_type": "listing",
            "suggested_fields": ["items_preview", "total_results", "url", "domain"],
        },
    }
    
    template_def = BUILTIN_TEMPLATES.get(template_name.lower())
    if template_def:
        return TemplateConfig(
            name=template_name,
            description=template_def["description"],
            page_type=template_def.get("page_type"),  # type: ignore
        )
    
    # 尝试从文件加载
    custom_path = Path.cwd() / f"xscrapy_templates/{template_name}.yaml"
    if custom_path.exists():
        import yaml
        data = yaml.safe_load(custom_path.read_text(encoding="utf-8"))
        return TemplateConfig(**data)
    
    console.print(f"[yellow]⚠️  模板 '{template_name}' 未找到，使用默认配置[/yellow]")
    return None


def get_all_templates_info() -> list[dict]:
    """获取所有模板信息"""
    return [
        {"name": "ecommerce", "description": "电商产品页（价格、库存、评价等）", 
         "spider_type": "Universal", "suggested_fields": ["title","price","brand","rating"]},
        {"name": "news", "description": "新闻/博客文章（正文、作者、标签等）", 
         "spider_type": "Universal", "suggested_fields": ["title","author","date","body"]},
        {"name": "social", "description": "社交媒体帖子", 
         "spider_type": "Universal", "suggested_fields": ["title","author","likes","shares"]},
        {"name": "forum", "description": "论坛帖子及回复", 
         "spider_type": "Detail", "suggested_fields": ["title","author","comments","replies"]},
        {"name": "docs", "description": "技术文档/API 文档", 
         "spider_type": "Universal", "suggested_fields": ["title","body","links","code"]},
        {"name": "listing", "description": "搜索结果/列表页", 
         "spider_type": "List", "suggested_fields": ["items","count","url"]},
    ]


def quick_extract(url: str, *, template=None, fields=None, ai=False) -> dict:
    """快速单页提取（非 Scrapy 方式，更轻量）"""
    import httpx
    
    console.print(f"🔍 正在提取: [link]{url}[/link]")
    
    with httpx.Client(timeout=30, follow_redirects=True) as client:
        resp = client.get(url, headers={
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_3) "
                         "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.3 Safari/605.1.15"
        })
        resp.raise_for_status()
    
    from xscrapy.spiders.universal import UniversalSpider
    from xscrapy.html import HtmlResponse
    
    spider = UniversalSpider(urls=[url])
    response = HtmlResponse(url=url, body=resp.content, encoding="utf-8")
    
    page_type = spider.classify_page(response)
    data = spider.universal_extract(response, page_type)
    
    # 如果有字段过滤
    field_list = [f.strip() for f in fields.split(",")] if fields else None
    if field_list:
        data = {k: v for k, v in data.items() if k in set(field_list)}
    
    return {
        "metadata": {
            "task_id": f"quick_{int(time.time())}",
            "source_url": url,
            "crawled_at": __import__("datetime").datetime.now().isoformat(),
            "extract_method": "quick" + ("_ai" if ai else ""),
        },
        "data": data,
    }


def _print_result_summary(result) -> None:
    """打印结果摘要"""
    if not result:
        return
    
    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_column("指标", style="bold")
    table.add_column("值")
    
    table.add_row("任务 ID", result.task_id or "-")
    table.add_row("总 URL 数", str(getattr(result, 'total_urls', '-')))
    table.add_row("成功数", f"[green]{getattr(result, 'success_count', 0)}[/green]" if getattr(result, 'success_count', 0) else "0")
    failed = getattr(result, 'failed_count', 0)
    table.add_row("失败数", f"[red]{failed}[/red]" if failed else "0")
    items_len = len(getattr(result, 'items', []))
    table.add_row("数据条目", f"[bold]{items_len}[/bold]")
    
    duration = getattr(result, 'duration_seconds', None)
    table.add_row("耗时", f"{duration:.2f}s" if duration else "-")
    
    console.print("\n")
    console.print(table)


if __name__ == "__main__":
    app()
