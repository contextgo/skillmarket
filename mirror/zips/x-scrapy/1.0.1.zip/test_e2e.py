#!/usr/bin/env python3
"""XScrapy E2E — Real page crawl test"""
import json, time, sys

from xscrapy.core.engine import XScrapyEngine
from xscrapy.models.data_models import (
    XScrapyConfig, RenderMode, OutputFormat, OutputConfig,
    AntiDetectConfig,
)

print("=" * 60)
print("  XScrapy v1.0 - End-to-End Crawl Test")
print("  Target: https://httpbin.org/html")
print("=" * 60)
print()

config = XScrapyConfig(
    urls=["https://httpbin.org/html"],
    render_mode=RenderMode.STATIC,
    max_pages=1,
    max_items=10,
    follow_links=False,
    depth_limit=0,
    output=OutputConfig(
        format=OutputFormat.JSON,
        file_path="xscrapy_output/e2e_result.json",
        pretty=True,
        include_metadata=True,
    ),
    anti_detect=AntiDetectConfig(
        enable_delay=True,
        min_delay=0.5,
        max_delay=1.5,
        concurrent_requests=2,
        download_timeout=15,
        retry_times=2,
    ),
)

engine = XScrapyEngine(config)

t0 = time.time()
try:
    result = engine.run()
except Exception as e:
    print(f"Engine error: {e}")
    import traceback; traceback.print_exc()
    sys.exit(1)

elapsed = time.time() - t0

print()
print("=" * 60)
print(f"  Result Summary")
print(f"  Task ID:     {result.task_id}")
print(f"  Total URLs:  {result.total_urls}")
print(f"  Success:     {result.success_count}")
print(f"  Failed:      {result.failed_count}")
print(f"  Items:       {len(result.items)}")
print(f"  Duration:    {elapsed:.2f}s")

if result.items:
    item = result.items[0]
    print()
    print("  --- First Item Preview ---")
    meta = item.metadata if hasattr(item, 'metadata') else item.get('metadata', {})
    data = item.data if hasattr(item, 'data') else item.get('data', {})
    
    print(f"  URL:          {meta.get('source_url', 'N/A')}")
    print(f"  Method:       {meta.get('extract_method', 'N/A')}")
    print(f"  Confidence:   {meta.get('confidence_score', 'N/A')}")
    print()
    print("  Data Fields:")
    for key in list(data.keys())[:20]:
        val = str(data[key])[:80]
        print(f"    {key}: {val}")

print()
print("=" * 60)
print("  End-to-End Test Complete!")
print("=" * 60)
