# Seedance 2.0 最新文档内容

> 自动更新于 2026-04-20
> 通过 `scripts/update_knowledge.py` 脚本抓取官方文档

---

## 待更新

首次运行更新脚本后将自动填充内容。

**官方参考文档**：
1. [Seedance 2.0 科幻场景生成实战手册](https://m.blog.csdn.net/u014177256/article/details/158035544)
2. [Seedance 2.0 提示词完全指南](https://m.blog.csdn.net/misslelover/article/details/158040401)
3. [小云雀产品手册](https://bytedance.larkoffice.com/docx/OJ3jdZ6e2oWvIuxfb1Kczsk8nVe)
