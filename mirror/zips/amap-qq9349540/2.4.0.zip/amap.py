#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
高德地图命令行工具 v2.4.0 (Python Version)
==========================================

功能：地理编码、周边搜索、路线规划（驾车/步行/骑行/公交）、POI查询、
      坐标转换、天气预报、批量操作、数据导出等
支持：Python 3.8+
作者：高德地图 Skill (qq9349540)
许可：MIT License

版本历史:
  v2.4.0 (2026-04-11) - 深度审查修复：统一navi URL / 增强骑行信息 /
                        消除代码重复(~90行) / 补齐export命令 / 清理冗余config
  v2.3.0 (2026-04-11) - API修复：骑行改用v5 API / 公交改用transit/integrated端点
  v2.2.0             - 第三轮审查补丁：错误处理/分页/缓存/Shell补全
  v2.1.0             - 第二轮审查：健壮性增强/导出功能/坐标校验
  v2.0.0             - 初始发布：全功能CLI工具(Python+PowerShell双实现)
"""

import os
import sys
import json
import time
import argparse
import urllib.parse
import urllib.request
import urllib.error
from typing import Optional, Dict, List, Any, Tuple, Union
from pathlib import Path
import re

# Windows 控制台 UTF-8 修复
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

# 版本信息
VERSION = "2.4.0"

# 默认配置
DEFAULT_CONFIG = {
    "base_url": "https://restapi.amap.com/v3",
    "base_url_v5": "https://restapi.amap.com/v5",  # v5 API (骑行路线等)
    "default_city": "蚌埠市",
    "default_radius": 1500,
    "default_page_size": 50,
    "max_retries": 3,
    "timeout": 30,
    "output_format": "json"
}

# 全局状态
_cache: Dict[str, Any] = {}
_request_count = 0
_session_start = time.time()


# ============================================================================
# 配置管理
# ============================================================================

def get_config_path() -> Path:
    """获取配置文件路径"""
    config_dir = Path.home() / ".amap"
    config_dir.mkdir(parents=True, exist_ok=True)
    return config_dir / "config.json"


def get_config() -> Optional[Dict]:
    """获取配置"""
    config_path = get_config_path()
    if config_path.exists():
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            return None
    return None


def save_config(config: Dict) -> None:
    """保存配置"""
    config_path = get_config_path()
    with open(config_path, "w", encoding="utf-8") as f:
        json.dump(config, f, ensure_ascii=False, indent=2)


def get_api_key() -> str:
    """获取API Key"""
    key = os.environ.get("AMAP_API_KEY")
    
    if not key:
        try:
            import winreg
            key = winreg.QueryValueEx(
                winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Environment"),
                "AMAP_API_KEY"
            )[0]
        except (OSError, ImportError):
            pass
    
    if not key:
        try:
            import winreg
            key = winreg.QueryValueEx(
                winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\Session Manager\Environment"),
                "AMAP_API_KEY"
            )[0]
        except (OSError, ImportError):
            pass
    
    if not key:
        saved_config = get_config()
        if saved_config and saved_config.get("apiKey"):
            key = saved_config["apiKey"]
    
    if not key:
        raise ValueError("AMAP_API_KEY 未设置。请运行: amap set-amapkey <your-key>")
    
    return key


def set_api_key(key: str, level: str = "User") -> None:
    """设置API Key"""
    if not key or not isinstance(key, str) or len(key) < 8:
        print("[ERROR] API Key 无效或长度不足，请检查输入", file=sys.stderr)
        return

    # 设置环境变量
    os.environ["AMAP_API_KEY"] = key
    
    # 尝试写入系统环境变量（仅Windows）
    try:
        import winreg
        reg_key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER if level == "User" else winreg.HKEY_LOCAL_MACHINE,
            r"Environment",
            0,
            winreg.KEY_SET_VALUE
        )
        winreg.SetValueEx(reg_key, "AMAP_API_KEY", 0, winreg.REG_SZ, key)
        winreg.CloseKey(reg_key)
    except (OSError, ImportError):
        pass  # 忽略注册表写入失败
    
    # 保存到配置文件
    saved_config = get_config() or {}
    saved_config["apiKey"] = key
    saved_config["updatedAt"] = time.strftime("%Y-%m-%d %H:%M:%S")
    save_config(saved_config)
    
    # 显示脱敏后的Key
    display_key = f"{key[:8]}...{key[-4:]}" if len(key) > 12 else f"{key[:4]}..."
    print(f"[OK] API Key 已设置 ({level} 级别)")
    print(f"     Key: {display_key}")


def _config_get(config: Optional[Dict], *keys, default=None):
    """从配置中读取值，支持多个 key 名（兼容不同命名风格）"""
    if not config:
        return default
    for k in keys:
        val = config.get(k)
        if val is not None:
            return val
    return default


def show_config() -> None:
    """显示当前配置"""
    config = get_config()
    
    print("\n╔══════════════════════════════════════════════════════════╗")
    print("║                    当前配置信息                           ║")
    print("╠══════════════════════════════════════════════════════════╣")
    print("║                                                          ║")
    
    # API Key
    try:
        key = get_api_key()
        display_key = f"{key[:8]}...{key[-4:]}" if len(key) > 12 else "****"
        print(f"║  API Key:    {display_key:<47} ║")
    except (ValueError, Exception):
        print("║  API Key:    未设置" + " " * 40 + "║")
    
    # 默认城市
    default_city = _config_get(config, "defaultCity", "default_city", default=DEFAULT_CONFIG["default_city"])
    print(f"║  默认城市:   {default_city:<42} ║")
    
    # 默认半径
    default_radius = _config_get(config, "defaultRadius", "default_radius", default=DEFAULT_CONFIG["default_radius"])
    print(f"║  默认半径:   {default_radius:<40}米   ║")
    
    # 输出格式
    output_format = _config_get(config, "outputFormat", "output_format", default=DEFAULT_CONFIG["output_format"])
    print(f"║  输出格式:   {output_format:<42} ║")
    
    print("║                                                          ║")
    print("╚══════════════════════════════════════════════════════════╝")
    print("")
    print("修改配置: amap config set <key> <value>")
    print("  例: amap config set defaultCity 合肥市")
    print("  例: amap config set defaultRadius 2000")
    print("  例: amap config set outputFormat table")


def set_config_value(key: str, value: str) -> None:
    """设置配置值"""
    config = get_config() or {}
    
    key_lower = key.lower()
    
    if key_lower in ("defaultcity", "default_city"):
        config["defaultCity"] = value
        print(f"默认城市已设置为: {value}")
    elif key_lower in ("defaultradius", "default_radius"):
        if value.isdigit():
            config["defaultRadius"] = int(value)
            print(f"默认半径已设置为: {value}米")
        else:
            print(f"[ERROR] 半径必须是数字", file=sys.stderr)
    elif key_lower in ("outputformat", "output_format"):
        if value in ("json", "table", "simple", "detail"):
            config["outputFormat"] = value
            print(f"输出格式已设置为: {value}")
        else:
            print(f"[ERROR] 格式必须是: json, table, simple, detail", file=sys.stderr)
    else:
        print(f"[ERROR] 未知配置项: {key}", file=sys.stderr)
        print("支持的配置项: defaultCity, defaultRadius, outputFormat")


# ============================================================================
# API 请求核心
# ============================================================================

def _do_http_request(base_url: str, endpoint: str, params: Dict,
                      no_cache: bool = False, no_retry: bool = False,
                      cache_prefix: str = "") -> Dict:
    """统一的 HTTP 请求核心 (v3/v5 API 共用)
    
    Args:
        base_url: API 基础 URL (v3 或 v5)
        endpoint: API 端点路径
        params: 请求参数
        no_cache: 是否跳过缓存
        no_retry: 是否禁用重试
        cache_prefix: 缓存 key 前缀 (v5 用 "v5-")
    """
    global _request_count, _cache
    
    api_key = get_api_key()
    params["key"] = api_key
    params["output"] = "json"
    
    _request_count += 1
    
    # 构建查询字符串（排序后）
    sorted_params = sorted(params.items())
    query_string = "&".join(f"{k}={urllib.parse.quote(str(v), safe='')}" 
                           for k, v in sorted_params)
    
    base_url = base_url.rstrip("/")
    endpoint = endpoint.lstrip("/")
    url = f"{base_url}/{endpoint}?{query_string}"
    
    retry_count = 0
    max_retries = DEFAULT_CONFIG["max_retries"]
    
    while retry_count < max_retries:
        try:
            request = urllib.request.Request(url)
            with urllib.request.urlopen(request, timeout=DEFAULT_CONFIG["timeout"]) as response:
                data = json.loads(response.read().decode("utf-8"))
            
            if data.get("status") == "1" or data.get("status") == 1:
                if not no_cache:
                    cache_key = f"{cache_prefix}{endpoint}-{query_string}"
                    _cache[cache_key] = data
                return data
            else:
                info_code = data.get("infocode", "")
                error_messages = {
                    "10001": "API密钥无效",
                    "10002": "服务不存在",
                    "10003": "访问超频限制，请稍后重试",
                    "10004": "访问流控",
                    "10005": "权限不足"
                }
                error_msg = error_messages.get(info_code, data.get("info", "未知错误"))
                raise Exception(f"API错误 [{info_code}]: {error_msg}")
        except Exception as e:
            retry_count += 1
            if retry_count >= max_retries or no_retry:
                raise Exception(f"请求失败 (已重试 {retry_count} 次): {e}")
            time.sleep(0.5 * retry_count)
    
    raise Exception("请求失败")


def invoke_amap_request(endpoint: str, params: Dict, no_cache: bool = False, 
                        no_retry: bool = False) -> Dict:
    """调用高德地图 v3 API"""
    return _do_http_request(
        base_url=DEFAULT_CONFIG["base_url"],
        endpoint=endpoint,
        params=params,
        no_cache=no_cache,
        no_retry=no_retry
    )


def get_default_city() -> str:
    """获取默认城市"""
    config = get_config()
    if config and config.get("defaultCity"):
        return config["defaultCity"]
    return DEFAULT_CONFIG["default_city"]


def get_default_radius() -> int:
    """获取默认半径"""
    config = get_config()
    if config and config.get("defaultRadius"):
        return config["defaultRadius"]
    return DEFAULT_CONFIG["default_radius"]


def get_default_format() -> str:
    """获取默认输出格式"""
    config = get_config()
    if config and config.get("outputFormat"):
        return config["outputFormat"]
    return DEFAULT_CONFIG["output_format"]


def invoke_amap_v5_request(endpoint: str, params: Dict, no_cache: bool = False,
                            no_retry: bool = False) -> Dict:
    """调用高德地图 v5 API (用于骑行路线等)
    
    v5 API 使用新的 URL 格式: https://restapi.amap.com/v5/direction/xxx
    """
    return _do_http_request(
        base_url=DEFAULT_CONFIG["base_url_v5"],
        endpoint=endpoint,
        params=params,
        no_cache=no_cache,
        no_retry=no_retry,
        cache_prefix="v5-"
    )


# ============================================================================
# 格式化输出
# ============================================================================

def format_output(data: Any, output_format: str = "json") -> None:
    """格式化输出"""
    if output_format == "json":
        print(json.dumps(data, ensure_ascii=False, indent=2))
    elif output_format == "simple":
        if isinstance(data, list):
            for item in data[:20]:
                name = (item.get("名称") or item.get("name") or "(无名称)")
                print(name)
    elif output_format == "detail":
        if isinstance(data, list):
            for i, item in enumerate(data[:10], 1):
                name = (item.get("名称") or item.get("name") or "(未命名)")
                print(f"\n--- {name} ---")
                for k, v in item.items():
                    if v:
                        print(f"  {k}: {v}")
    elif output_format == "table":
        print("(table 格式) 请使用 json 或 simple 格式查看完整数据")


# ============================================================================
# 核心命令
# ============================================================================

def cmd_geo(address: str, city: Optional[str] = None, simple: bool = False) -> None:
    """地理编码：地址转坐标"""
    if not city:
        city = get_default_city()
    
    result = invoke_amap_request("geocode/geo", {
        "address": address,
        "city": city
    })
    
    if int(result.get("count", 0)) > 0:
        location = result["geocodes"][0]
        coords = location["location"]
        
        if simple:
            print(coords)
            return
        
        output = {
            "status": "成功",
            "地址": location.get("formatted_address"),
            "坐标": coords,
            "经度": coords.split(",")[0],
            "纬度": coords.split(",")[1],
            "省份": location.get("province"),
            "城市": location.get("city"),
            "区县": location.get("district"),
            "区域码": location.get("adcode")
        }
        
        if location.get("street"):
            output["道路"] = location["street"]
        if location.get("number"):
            output["门牌号"] = location["number"]
        
        print(json.dumps(output, ensure_ascii=False, indent=2))
    else:
        print(json.dumps({
            "status": "失败",
            "地址": address,
            "错误": "未找到匹配的地理编码结果"
        }, ensure_ascii=False, indent=2), file=sys.stderr)


def cmd_regeo(location: str, simple: bool = False) -> None:
    """逆地理编码：坐标转地址"""
    result = invoke_amap_request("geocode/regeo", {
        "location": location,
        "extensions": "all"
    })
    
    if result.get("status") == "1":
        regeo = result["regeocode"]
        
        if simple:
            print(regeo.get("formatted_address"))
            return
        
        output = {
            "status": "成功",
            "坐标": location,
            "标准地址": regeo.get("formatted_address"),
            "省份": regeo.get("addressComponent", {}).get("province"),
            "城市": regeo.get("addressComponent", {}).get("city") or "未知",
            "区县": regeo.get("addressComponent", {}).get("district"),
            "乡镇": regeo.get("addressComponent", {}).get("township") or "未知"
        }
        
        if regeo.get("pois") and len(regeo["pois"]) > 0:
            nearby_pois = " | ".join(p.get("name", "") for p in regeo["pois"][:5] if p.get("name"))
            output["附近POI"] = nearby_pois
        
        print(json.dumps(output, ensure_ascii=False, indent=2))
    else:
        print(json.dumps({
            "status": "失败",
            "坐标": location,
            "错误": "逆地理编码无结果"
        }, ensure_ascii=False, indent=2), file=sys.stderr)


def cmd_weather(city: Optional[str] = None, output_format: str = "json") -> None:
    """天气预报"""
    if not city:
        city = get_default_city()
    
    result = invoke_amap_request("weather/weatherInfo", {"city": city})
    
    if result.get("lives"):
        weather = result["lives"][0]
        
        if output_format == "simple":
            wind_dir = weather.get("winddirection", "")
            wind_power = weather.get("windpower", "")
            print(f"{weather.get('weather')} {weather.get('temperature')}℃ {wind_dir}{wind_power}级")
            return
        
        output = {
            "status": "成功",
            "城市": weather.get("province", "") + weather.get("city", ""),
            "天气": weather.get("weather"),
            "温度": f"{weather.get('temperature')}℃",
            "风力": f"{weather.get('winddirection')} {weather.get('windpower')}级",
            "湿度": f"{weather.get('humidity')}%",
            "发布时间": weather.get("reporttime")
        }
        
        print(json.dumps(output, ensure_ascii=False, indent=2))
    else:
        print(json.dumps({
            "status": "失败",
            "城市": city,
            "错误": "未获取到天气数据，请检查城市名称是否正确"
        }, ensure_ascii=False, indent=2), file=sys.stderr)


def cmd_search(keywords: str, city: Optional[str] = None,
              output_format: Optional[str] = None, limit: int = 20,
              all_pages: bool = False, output_file: Optional[str] = None) -> None:
    """POI关键字搜索"""
    if not city:
        city = get_default_city()
    if not output_format:
        output_format = get_default_format()

    all_pois = []
    page_size = min(limit, 25)
    page_no = 1
    result = None

    while True:
        result = invoke_amap_request("place/text", {
            "keywords": keywords,
            "city": city,
            "offset": page_size,
            "page": page_no
        }, no_cache=True)

        if not result.get("pois"):
            break

        all_pois.extend(result["pois"])

        if not all_pages:
            break
        if len(all_pois) >= int(result.get("count", 0)):
            break
        if len(all_pois) >= limit:
            break

        page_no += 1
        time.sleep(0.1)

    total_found = int(result.get("count", len(all_pois))) if result else len(all_pois)
    display_count = min(len(all_pois), limit)
    print(f"找到 {total_found} 个结果 (本次返回 {display_count} 条)")

    pois = []
    for poi in all_pois[:limit]:
        poi_type = poi.get("type", "").split(";")[0] if poi.get("type") else ""
        pois.append({
            "名称": poi.get("name"),
            "类型": poi_type,
            "地址": poi.get("address") or "无",
            "坐标": poi.get("location"),
            "距离": f"{poi['distance']}米" if poi.get("distance") else None
        })

    if output_file:
        export_data("json", output_file, pois)

    format_output(pois, output_format)


def cmd_around(keywords: str, location: str, radius: Optional[int] = None,
              output_format: Optional[str] = None, limit: int = 50,
              all_pages: bool = False, output_file: Optional[str] = None) -> None:
    """周边POI搜索"""
    if not radius:
        radius = get_default_radius()
    if not output_format:
        output_format = get_default_format()
    
    all_pois = []
    page_size = min(limit, 25)
    page_no = 1
    result = None
    
    while True:
        result = invoke_amap_request("place/around", {
            "keywords": keywords,
            "location": location,
            "radius": radius,
            "offset": page_size,
            "extensions": "all",
            "page": page_no
        }, no_cache=True)
        
        if not result.get("pois"):
            break

        all_pois.extend(result["pois"])

        if not all_pages:
            break
        if len(all_pois) >= int(result.get("count", 0)):
            break
        if len(all_pois) >= limit:
            break

        page_no += 1
        time.sleep(0.1)

    total_found = int(result.get("count", len(all_pois))) if result else len(all_pois)
    display_count = min(len(all_pois), limit)
    print(f"找到 {total_found} 个结果 (本次返回 {display_count} 条)")

    pois = []
    for poi in all_pois[:limit]:
        poi_type = poi.get("type", "").split(";")[0] if poi.get("type") else ""
        pois.append({
            "名称": poi.get("name"),
            "类型": poi_type,
            "地址": poi.get("address") or "无",
            "坐标": poi.get("location"),
            "距离": f"{poi['distance']}米" if poi.get("distance") else None
        })

    if output_file:
        export_data("json", output_file, pois)

    format_output(pois, output_format)


def cmd_detail(poi_id: str) -> None:
    """获取POI详情"""
    result = invoke_amap_request("place/detail", {"id": poi_id})
    
    if result.get("pois"):
        poi = result["pois"][0]
        
        output = {
            "名称": poi.get("name"),
            "类型": poi.get("type"),
            "类型编码": poi.get("typecode"),
            "地址": poi.get("address"),
            "坐标": poi.get("location"),
            "城市": poi.get("cityname"),
            "区域": poi.get("adname"),
            "标签": poi.get("tag"),
            "营业时间": poi.get("opening_time"),
            "费用说明": f"{poi['cost']}元" if poi.get("cost") else None
        }
        
        print(json.dumps(output, ensure_ascii=False, indent=2))
    else:
        print(json.dumps({
            "status": "失败",
            "ID": poi_id,
            "错误": "未找到该POI"
        }, ensure_ascii=False, indent=2), file=sys.stderr)


# ============================================================================
# 安全类型转换（高德API返回的数值字段可能是字符串）
# ============================================================================

def _safe_int(val, default=0):
    """安全转为整数（处理高德API返回的字符串数字）"""
    try:
        return int(val)
    except (ValueError, TypeError):
        return default


def _safe_float(val, default=0.0):
    """安全转为浮点数"""
    try:
        return float(val)
    except (ValueError, TypeError):
        return default


def cmd_route(from_loc: str, to_loc: str, strategy: str = "driving",
             output_format: str = "json") -> None:
    """路线规划
    
    策略说明:
    - driving: 驾车路线 (v3 API)
    - walking: 步行路线 (v3 API)
    - bicycling: 骑行路线 (v5 API - 新的骑行路线API)
    - transit: 公交路线 (v3 API transit/integrated)
    """
    
    if strategy == "bicycling":
        # 骑行路线使用 v5 API
        result = invoke_amap_v5_request("direction/bicycling", {
            "origin": from_loc,
            "destination": to_loc,
            "show_fields": "cost,navi,polyline"  # 请求详细信息
        })
        
        if result.get("route") and result["route"].get("paths"):
            path = result["route"]["paths"][0]
            distance = _safe_int(path.get("distance", 0))
            duration = _safe_int(path.get("duration", 0))
            
            if output_format == "simple":
                print(f"距离: {round(distance / 1000, 2)}公里 | 时长: {round(duration / 60)}分钟")
                return

            output = {
                "起点": from_loc,
                "终点": to_loc,
                "距离": f"{round(distance / 1000, 2)}公里",
                "时长": f"{round(duration / 60)}分钟"
            }
            
            # 如果有详细信息 (v5 API cost 字段)
            if path.get("cost"):
                cost = path["cost"]
                if cost.get("toll"):
                    output["收费"] = f"{_safe_int(cost.get('toll'))}元"
                if cost.get("toll_distance"):
                    output["收费路段"] = f"{_safe_int(cost.get('toll_distance'))}米"
                if cost.get("traffic_light_count"):
                    output["红绿灯"] = f"{_safe_int(cost.get('traffic_light_count'))}个"
            # v5 API 路径额外信息
            if path.get("steps"):
                output["路线步数"] = f"{len(path['steps'])}"
            
            print(json.dumps(output, ensure_ascii=False, indent=2))
        else:
            print(json.dumps({
                "status": "失败",
                "起点": from_loc,
                "终点": to_loc,
                "方式": strategy,
                "错误": "无法规划骑行路线，请检查起点终点是否在中国大陆境内"
            }, ensure_ascii=False, indent=2), file=sys.stderr)
        return
    
    elif strategy == "transit":
        # 公交路线使用 v3 API 的 transit/integrated 端点，需要 city 参数
        city = get_default_city()
        # 提取城市名称（去掉"市"等后缀）
        city_name = city.replace("市", "").replace("省", "").replace("县", "")
        
        result = invoke_amap_request("direction/transit/integrated", {
            "origin": from_loc,
            "destination": to_loc,
            "city": city_name,
            "extensions": "all"  # 返回全部信息
        })
        
        if result.get("route") and result["route"].get("transits"):
            transits = result["route"]["transits"]
            # 返回第一条（最快）路线
            transit = transits[0]
            
            if output_format == "simple":
                cost_str = f" | 费用:{transit.get('cost', '未知')}元" if transit.get("cost") else ""
                segments_count = len(transit.get("segments", []))
                print(f"时长: {round(_safe_int(transit.get('duration')) / 60)}分钟{cost_str} | 换乘{segments_count - 1}次")
                return

            segments = []
            for seg in transit.get("segments", []):
                seg_info = {}
                walking_dist = _safe_int((seg.get("walking") or {}).get("distance"), 0)
                if seg.get("walking") and walking_dist > 0:
                    seg_info["步行"] = f"{walking_dist}米"
                
                # 处理公交线路
                if seg.get("bus") and seg["bus"].get("buslines") and len(seg["bus"]["buslines"]) > 0:
                    bus_names = " → ".join(b.get("name", "未知线路") for b in seg["bus"]["buslines"] if b.get("name"))
                    seg_info["公交"] = bus_names
                    if seg["bus"]["buslines"][0].get("exitstop"):
                        seg_info["下车站"] = seg["bus"]["buslines"][0]["exitstop"].get("name")
                    if seg["bus"]["buslines"][0].get("entrystop"):
                        seg_info["上车站"] = seg["bus"]["buslines"][0]["entrystop"].get("name")
                
                # 处理地铁/轨道交通
                if seg.get("railway"):
                    railway = seg["railway"]
                    seg_info["轨道交通"] = railway.get("name", "未知")
                    if railway.get("departure_stop"):
                        seg_info["上车站"] = railway["departure_stop"].get("name")
                    if railway.get("arrival_stop"):
                        seg_info["下车站"] = railway["arrival_stop"].get("name")
                
                if seg_info:
                    segments.append(seg_info)
            
            segments_count = len(transit.get("segments", []))
            output = {
                "起点": from_loc,
                "终点": to_loc,
                "总时长": f"{round(_safe_int(transit.get('duration')) / 60)}分钟",
                "总费用": f"{transit.get('cost', '未知')}元" if transit.get("cost") else "未知",
                "换乘次数": f"{segments_count - 1}次",
                "步行距离": f"{_safe_int(transit.get('walking_distance'))}米" if transit.get("walking_distance") else "未知",
                "方案详情": segments
            }
            
            print(json.dumps(output, ensure_ascii=False, indent=2))
        else:
            print(json.dumps({
                "status": "失败",
                "起点": from_loc,
                "终点": to_loc,
                "方式": strategy,
                "错误": "无法规划公交路线，请确保起点和终点在同一城市"
            }, ensure_ascii=False, indent=2), file=sys.stderr)
        return
    
    # 驾车和步行路线使用 v3 API
    endpoint_map = {
        "driving": "driving",
        "walking": "walking"
    }
    
    endpoint = endpoint_map.get(strategy, "driving")
    
    result = invoke_amap_request(f"direction/{endpoint}", {
        "origin": from_loc,
        "destination": to_loc
    })
    
    if result.get("route"):
        route = result["route"]
        
        if strategy == "driving" and route.get("paths"):
            path = route["paths"][0]
            
            if output_format == "simple":
                distance_km = round(_safe_int(path.get("distance")) / 1000, 1)
                duration_min = round(_safe_int(path.get("time")) / 60)
                print(f"距离: {distance_km}公里 | 时长: {duration_min}分钟")
                return
            
            strategy_map = {
                "1": "速度优先",
                "2": "费用优先",
                "3": "时间优先",
                "4": "距离优先"
            }
            
            output = {
                "起点": from_loc,
                "终点": to_loc,
                "距离": f"{round(_safe_int(path.get('distance')) / 1000, 2)}公里",
                "时长": f"{round(_safe_int(path.get('time')) / 60)}分钟",
                "策略": strategy_map.get(str(path.get("strategy", "")), path.get("strategy")),
                "收费": f"{_safe_int(path.get('tolls'))}元" if _safe_int(path.get("tolls", 0)) > 0 else "无",
                "红绿灯": f"{path.get('light', 0)}个"
            }
            
            print(json.dumps(output, ensure_ascii=False, indent=2))
            
        elif strategy == "walking" and route.get("paths"):
            path = route["paths"][0]
            steps_count = len(path.get("steps", []))
            
            # 步行时间可能为0或很小，使用步数估算（每步约0.7米/秒）
            duration = _safe_int(path.get("time", 0))
            distance = _safe_int(path.get("distance", 0))
            if duration == 0 and distance > 0:
                # 估算：步行速度约1.2m/s
                duration = int(distance / 1.2)
            
            if output_format == "simple":
                print(f"距离: {distance}米 | 时长: {round(duration / 60)}分钟 | 步数: {steps_count}步")
                return
            
            output = {
                "起点": from_loc,
                "终点": to_loc,
                "距离": f"{distance}米",
                "时长": f"{round(duration / 60)}分钟",
                "步数": f"{steps_count}步"
            }
            
            print(json.dumps(output, ensure_ascii=False, indent=2))
        else:
            print(json.dumps({
                "status": "失败",
                "起点": from_loc,
                "终点": to_loc,
                "方式": strategy,
                "错误": "无法规划路线"
            }, ensure_ascii=False, indent=2), file=sys.stderr)
    else:
        print(json.dumps({
            "status": "失败",
            "起点": from_loc,
            "终点": to_loc,
            "方式": strategy,
            "错误": "无法规划路线，请检查坐标是否正确"
        }, ensure_ascii=False, indent=2), file=sys.stderr)


def cmd_distance(origin: str, destination: str, simple: bool = False) -> None:
    """距离测量"""
    result = invoke_amap_request("distance", {
        "origins": origin,
        "destination": destination
    })

    if result.get("results"):
        dist = result["results"][0]

        dist_val = _safe_int(dist.get("distance", 0))
        if simple:
            print(f"{round(dist_val / 1000, 2)}公里")
            return

        output = {
            "起点": origin,
            "终点": destination,
            "直线距离": f"{dist_val}米",
            "直线距离km": f"{round(dist_val / 1000, 2)}公里"
        }
        
        print(json.dumps(output, ensure_ascii=False, indent=2))
    else:
        print(json.dumps({
            "status": "失败",
            "起点": origin,
            "终点": destination,
            "错误": "无法获取距离数据"
        }, ensure_ascii=False, indent=2), file=sys.stderr)


def cmd_ip(ip_addr: Optional[str] = None, simple: bool = False) -> None:
    """IP定位"""
    params = {"ip": ip_addr or ""}
    result = invoke_amap_request("ip", params)
    
    province = result.get("province") or "未知"
    city = result.get("city") or "未知"
    
    if simple:
        print(f"{province} {city}")
        return
    
    output = {
        "IP": result.get("ip") or "本机IP",
        "省份": province,
        "城市": city,
        "区域码": result.get("adcode") or "未知"
    }
    
    print(json.dumps(output, ensure_ascii=False, indent=2))


def cmd_navi(location: str, name: str) -> None:
    """生成导航链接（打开高德地图导航到指定位置）"""
    if not re.match(r"^\d+\.\d+,\d+\.\d+$", location):
        print(f"[ERROR] 坐标格式无效，应为: 经度,纬度 (如: 117.3,33.0)", file=sys.stderr)
        return

    encoded_name = urllib.parse.quote(name)
    # 高德URI协议：to为目标点；from留空则自动使用当前定位
    uri = f"https://uri.amap.com/navigation?to={location},{encoded_name}&mode=car"
    
    output = {
        "status": "成功",
        "名称": name,
        "坐标": location,
        "导航链接": uri
    }
    
    print(json.dumps(output, ensure_ascii=False, indent=2))


def cmd_taxi(from_loc: str, from_name: str, to_loc: str, to_name: str) -> None:
    """生成打车链接"""
    if not (re.match(r"^\d+\.\d+,\d+\.\d+$", from_loc) and 
            re.match(r"^\d+\.\d+,\d+\.\d+$", to_loc)):
        print(f"[ERROR] 坐标格式无效，应为: 经度,纬度 (如: 117.3,33.0)", file=sys.stderr)
        return
    
    encoded_from_name = urllib.parse.quote(from_name)
    encoded_to_name = urllib.parse.quote(to_name)
    uri = f"https://uri.amap.com/to?from={from_loc},{encoded_from_name}&to={to_loc},{encoded_to_name}"
    
    output = {
        "status": "成功",
        "起点": f"{from_name} ({from_loc})",
        "终点": f"{to_name} ({to_loc})",
        "打车链接": uri
    }
    
    print(json.dumps(output, ensure_ascii=False, indent=2))


def cmd_batch_geo(addresses: str, simple: bool = False) -> None:
    """批量地理编码"""
    addr_list = [a.strip() for a in re.split(r"[,，;]", addresses) if a.strip()]
    
    print(f"批量地理编码: {len(addr_list)} 个地址")
    
    results = []
    for i, addr in enumerate(addr_list, 1):
        print(f"\r批量查询: {i}/{len(addr_list)}", end="", flush=True)
        
        try:
            result = invoke_amap_request("geocode/geo", {
                "address": addr,
                "city": get_default_city()
            }, no_cache=True)
            
            if int(result.get("count", 0)) > 0:
                geo = result["geocodes"][0]
                results.append({
                    "地址": addr,
                    "坐标": geo.get("location"),
                    "标准地址": geo.get("formatted_address"),
                    "区县": geo.get("district"),
                    "状态": "成功"
                })
            else:
                results.append({
                    "地址": addr,
                    "坐标": None,
                    "标准地址": None,
                    "区县": None,
                    "状态": "未找到"
                })
        except Exception as e:
            results.append({
                "地址": addr,
                "坐标": None,
                "标准地址": None,
                "区县": None,
                "状态": "错误"
            })
        
        time.sleep(0.1)
    
    print("")  # 换行
    
    success_count = sum(1 for r in results if r["状态"] == "成功")
    print(f"成功率: {success_count}/{len(results)}")
    
    if simple:
        for r in results:
            print(r["坐标"] or "")
    else:
        print(json.dumps(results, ensure_ascii=False, indent=2))


def cmd_batch_around(keywords: str, location: str, radius: Optional[int] = None,
                     simple: bool = False) -> None:
    """批量周边搜索"""
    if not radius:
        radius = get_default_radius()
    
    keyword_list = [k.strip() for k in re.split(r"[,，;]", keywords) if k.strip()]
    
    print(f"批量周边搜索: {len(keyword_list)} 个类别 (半径{radius}米)")
    
    results = []
    for i, kw in enumerate(keyword_list, 1):
        print(f"\r批量搜索: {kw} ({i}/{len(keyword_list)})", end="", flush=True)
        
        try:
            result = invoke_amap_request("place/around", {
                "keywords": kw,
                "location": location,
                "radius": radius,
                "offset": 20
            })
            
            poi_names = " | ".join(p.get("name", "") for p in result.get("pois", [])[:5] if p.get("name"))
            results.append({
                "关键词": kw,
                "数量": int(result.get("count", 0)),
                "POI列表": poi_names or "无"
            })
        except Exception:
            results.append({
                "关键词": kw,
                "数量": 0,
                "POI列表": "查询失败"
            })
        
        time.sleep(0.1)
    
    print("")  # 换行
    
    if simple:
        for r in results:
            print(f"{r['关键词']}: {r['数量']}个")
    else:
        print(json.dumps(results, ensure_ascii=False, indent=2))


def export_data(file_type: str, file_path: str, data: Any) -> None:
    """导出数据到文件"""
    # 确保目录存在
    dir_path = os.path.dirname(file_path)
    if dir_path:
        os.makedirs(dir_path, exist_ok=True)
    
    ext = os.path.splitext(file_path)[1].lower()
    
    if ext == ".json":
        if isinstance(data, str):
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(data)
        else:
            with open(file_path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
    elif ext == ".csv":
        if isinstance(data, str):
            try:
                obj = json.loads(data)
            except (json.JSONDecodeError, ValueError):
                print("[ERROR] 无法解析数据为JSON", file=sys.stderr)
                return
        else:
            obj = data
        
        if isinstance(obj, list) and len(obj) > 0:
            # 获取所有可能的列
            headers = set()
            for item in obj:
                if isinstance(item, dict):
                    headers.update(item.keys())
            
            headers = sorted(headers)
            
            with open(file_path, "w", encoding="utf-8", newline="") as f:
                f.write(",".join(headers) + "\n")
                for item in obj:
                    if isinstance(item, dict):
                        row = [str(item.get(h, "")) for h in headers]
                        f.write(",".join(row) + "\n")
        else:
            print("[WARNING] 无数据可导出或数据格式不支持CSV", file=sys.stderr)
            return
    else:
        print(f"[ERROR] 不支持的格式: {ext}", file=sys.stderr)
        print("支持的格式: .json, .csv", file=sys.stderr)
        return
    
    print(f"已导出: {file_path}")


def show_status() -> None:
    """显示运行状态"""
    uptime = time.time() - _session_start
    hours = int(uptime // 3600)
    minutes = int((uptime % 3600) // 60)
    seconds = int(uptime % 60)
    uptime_str = f"{hours:02d}:{minutes:02d}:{seconds:02d}"
    
    print("\n╔══════════════════════════════════════════════════════════╗")
    print("║                    运行状态                              ║")
    print("╠══════════════════════════════════════════════════════════╣")
    print("║                                                          ║")
    print(f"║  版本:       {VERSION:<44} ║")
    print(f"║  会话时长:   {uptime_str:<44} ║")
    print(f"║  请求次数:   {_request_count:<44} ║")
    print(f"║  缓存条目:   {len(_cache):<44} ║")
    
    try:
        key = get_api_key()
        print("║  API Key:   ...✓" + " " * 39 + "║")
    except (ValueError, Exception) as e:
        print("║  API Key:   未配置 ✗" + " " * 37 + "║")
    
    print("║                                                          ║")
    print("╚══════════════════════════════════════════════════════════╝")


def clear_cache() -> None:
    """清除缓存"""
    global _cache
    cache_count = len(_cache)
    _cache.clear()
    print(f"[OK] 缓存已清除 (之前有 {cache_count} 条缓存)")


def show_help() -> None:
    """显示帮助"""
    print(f"""
╔══════════════════════════════════════════════════════════════════════╗
║                 高德地图命令行工具 v{VERSION}                        ║
║                 AMap CLI for Python                                ║
╠══════════════════════════════════════════════════════════════════════╣
║                                                                      ║
║  【配置命令】                                                         ║
║    set-amapkey <key>      设置API密钥                                ║
║    get-amapkey            查看当前密钥                               ║
║    config                 查看当前配置                               ║
║    config set <key> <val>  修改配置                                   ║
║    clear-cache             清除请求缓存                               ║
║                                                                      ║
║  【位置服务】                                                         ║
║    geo <地址> [城市]       地址转坐标                                ║
║    regeo <坐标>            坐标转地址                                ║
║    weather [城市]          天气预报                                  ║
║    ip [IP]                 IP定位                                    ║
║                                                                      ║
║  【搜索服务】                                                         ║
║    search <关键词> [城市]  POI搜索                                   ║
║    around <关键词> <坐标> <半径>  周边搜索                            ║
║    detail <ID>             POI详情                                   ║
║                                                                      ║
║  【路线规划】                                                         ║
║    route <起点> <终点> [方式]  路线规划                              ║
║      driving/walking/bicycling/transit (公交)                       ║
║    distance <起点> <终点>   距离测量                                 ║
║                                                                      ║
║  【链接生成】                                                         ║
║    navi <坐标> <名称>       生成导航链接                             ║
║    taxi <起点> <名> <终点> <名>  生成打车链接                        ║
║                                                                      ║
║  【批量操作】                                                         ║
║    batch-geo <地址1,地址2,...>  批量地理编码                         ║
║    batch-around <关键词,...> <坐标> <半径>  批量周边搜索             ║
║                                                                      ║
║  【快捷别名】                                                         ║
║    g=geo  rg=regeo  w=weather  s=search  a=around                    ║
║    r=route  dist=distance  n=navi  t=taxi  h=help                    ║
║                                                                      ║
╠══════════════════════════════════════════════════════════════════════╣
║  【示例】                                                             ║
║    amap geo "蚌埠市梅桥街道"                                        ║
║    amap s "餐厅" "蚌埠"                                              ║
║    amap a "超市" "117.3,33.0" 2000                                   ║
║    amap r "117.3,33.0" "117.4,33.1" transit                         ║
║    amap bg "梅桥,联盟家博城,温莎"                                    ║
║    amap shell                                                        ║
║                                                                      ║
╚══════════════════════════════════════════════════════════════════════╝

提示:
  • 坐标格式: 经度,纬度 (如: 117.3,33.0)
  • 半径单位: 米; 路线方式: driving/walking/bicycling/transit(公交)
  • 使用 --all-pages 获取POI全量数据(自动分页)
  • 使用 --output <path> 将结果保存到文件
""")


def enter_shell() -> None:
    """进入交互式Shell"""
    
    print("\n╔══════════════════════════════════════════════════════════╗")
    print("║              高德地图交互式 Shell (Python版)                 ║")
    print("╠══════════════════════════════════════════════════════════╣")
    print("║  输入命令直接执行，输入 'exit' 或 'quit' 退出               ║")
    print("║  输入 'help' 查看帮助                                       ║")
    print("╚══════════════════════════════════════════════════════════╝\n")
    
    while True:
        try:
            user_input = input("amap> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n再见!")
            break
        
        if user_input.lower() in ("exit", "quit", "q"):
            print("再见!")
            break
        
        if not user_input:
            continue
        
        # 简单解析命令
        parts = user_input.split()
        cmd = parts[0].lower()
        args = parts[1:]
        
        try:
            if cmd == "geo" or cmd == "g":
                if len(args) < 1:
                    print("用法: geo <地址> [城市]")
                    continue
                cmd_geo(args[0], args[1] if len(args) > 1 else None)
            
            elif cmd == "regeo" or cmd == "rg":
                if len(args) < 1:
                    print("用法: regeo <坐标>")
                    continue
                cmd_regeo(args[0])
            
            elif cmd == "weather" or cmd == "w":
                cmd_weather(args[0] if args else None)
            
            elif cmd == "search" or cmd == "s":
                if len(args) < 1:
                    print("用法: search <关键词> [城市]")
                    continue
                cmd_search(args[0], args[1] if len(args) > 1 else None)
            
            elif cmd == "around" or cmd == "a":
                if len(args) < 2:
                    print("用法: around <关键词> <坐标> [半径]")
                    continue
                cmd_around(args[0], args[1], int(args[2]) if len(args) > 2 else None)
            
            elif cmd == "detail" or cmd == "d":
                if len(args) < 1:
                    print("用法: detail <POI ID>")
                    continue
                cmd_detail(args[0])
            
            elif cmd == "route" or cmd == "r":
                if len(args) < 2:
                    print("用法: route <起点> <终点> [方式]")
                    continue
                cmd_route(args[0], args[1], args[2] if len(args) > 2 else "driving")
            
            elif cmd == "distance" or cmd == "dist":
                if len(args) < 2:
                    print("用法: distance <起点> <终点>")
                    continue
                cmd_distance(args[0], args[1])
            
            elif cmd == "ip":
                cmd_ip(args[0] if args else None)
            
            elif cmd == "navi" or cmd == "n":
                if len(args) < 2:
                    print("用法: navi <坐标> <名称>")
                    continue
                cmd_navi(args[0], args[1])
            
            elif cmd == "taxi" or cmd == "t":
                if len(args) < 4:
                    print("用法: taxi <起点> <起点名> <终点> <终点名>")
                    continue
                cmd_taxi(args[0], args[1], args[2], args[3])
            
            elif cmd == "batch-geo" or cmd == "bg":
                if len(args) < 1:
                    print("用法: batch-geo <地址1,地址2,...>")
                    continue
                cmd_batch_geo(" ".join(args))
            
            elif cmd == "batch-around" or cmd == "ba":
                if len(args) < 2:
                    print("用法: batch-around <关键词,...> <坐标> [半径]")
                    continue
                cmd_batch_around(args[0], args[1], int(args[2]) if len(args) > 2 else None)
            
            elif cmd == "config":
                if len(args) >= 3 and args[0] == "set":
                    set_config_value(args[1], args[2])
                else:
                    show_config()
            
            elif cmd == "clear-cache":
                clear_cache()
            
            elif cmd == "export":
                if len(args) < 2:
                    print("用法: export <json|csv> <文件路径> [数据]")
                    continue
                data_to_export = " ".join(args[2:]) if len(args) > 2 else None
                export_data(args[0], args[1], data_to_export)
            
            elif cmd == "status":
                show_status()
            
            elif cmd == "help" or cmd == "h":
                show_help()
            
            elif cmd == "exit" or cmd == "quit":
                break
            
            else:
                # 可能是坐标
                if re.match(r"^\d+\.\d+,\d+\.\d+$", cmd):
                    cmd_regeo(cmd, simple=True)
                else:
                    print(f"未知命令: {cmd} (输入 'help' 查看帮助)")
        
        except Exception as e:
            print(f"错误: {e}")


# ============================================================================
# 命令行参数解析
# ============================================================================

def create_parser() -> argparse.ArgumentParser:
    """创建命令行参数解析器"""
    parser = argparse.ArgumentParser(
        description="高德地图命令行工具 v" + VERSION,
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    subparsers = parser.add_subparsers(dest="command", help="可用命令")
    
    # 地理编码
    geo_parser = subparsers.add_parser("geo", aliases=["g"], help="地址转坐标")
    geo_parser.add_argument("address", help="地址")
    geo_parser.add_argument("city", nargs="?", help="城市")
    geo_parser.add_argument("-s", "--simple", action="store_true", help="简洁输出")
    
    # 逆地理编码
    regeo_parser = subparsers.add_parser("regeo", aliases=["rg"], help="坐标转地址")
    regeo_parser.add_argument("location", help="坐标 (经度,纬度)")
    regeo_parser.add_argument("-s", "--simple", action="store_true", help="简洁输出")
    
    # 天气
    weather_parser = subparsers.add_parser("weather", aliases=["w"], help="天气预报")
    weather_parser.add_argument("city", nargs="?", help="城市")
    weather_parser.add_argument("-f", "--format", choices=["json", "simple"], default="json", help="输出格式")
    
    # IP定位
    ip_parser = subparsers.add_parser("ip", help="IP定位")
    ip_parser.add_argument("ip", nargs="?", help="IP地址")
    ip_parser.add_argument("-s", "--simple", action="store_true", help="简洁输出")
    
    # POI搜索
    search_parser = subparsers.add_parser("search", aliases=["s"], help="POI搜索")
    search_parser.add_argument("keywords", help="关键词")
    search_parser.add_argument("city", nargs="?", help="城市")
    search_parser.add_argument("-f", "--format", choices=["json", "table", "simple", "detail"], help="输出格式")
    search_parser.add_argument("-l", "--limit", type=int, default=20, help="返回数量限制")
    search_parser.add_argument("-a", "--all-pages", action="store_true", help="获取全部结果")
    search_parser.add_argument("-o", "--output", help="输出文件路径")
    
    # 周边搜索
    around_parser = subparsers.add_parser("around", aliases=["a"], help="周边搜索")
    around_parser.add_argument("keywords", help="关键词")
    around_parser.add_argument("location", help="中心坐标 (经度,纬度)")
    around_parser.add_argument("radius", nargs="?", type=int, help="搜索半径(米)")
    around_parser.add_argument("-f", "--format", choices=["json", "table", "simple", "detail"], help="输出格式")
    around_parser.add_argument("-l", "--limit", type=int, default=50, help="返回数量限制")
    around_parser.add_argument("-a", "--all-pages", action="store_true", help="获取全部结果")
    around_parser.add_argument("-o", "--output", help="输出文件路径")
    
    # POI详情
    detail_parser = subparsers.add_parser("detail", aliases=["d"], help="POI详情")
    detail_parser.add_argument("id", help="POI ID")
    
    # 路线规划
    route_parser = subparsers.add_parser("route", aliases=["r"], help="路线规划")
    route_parser.add_argument("from", help="起点坐标")
    route_parser.add_argument("to", help="终点坐标")
    route_parser.add_argument("strategy", nargs="?", choices=["driving", "walking", "bicycling", "transit"], default="driving", help="路线方式")
    route_parser.add_argument("-f", "--format", choices=["json", "simple"], default="json", help="输出格式")
    
    # 距离测量
    dist_parser = subparsers.add_parser("distance", aliases=["dist"], help="距离测量")
    dist_parser.add_argument("origin", help="起点坐标")
    dist_parser.add_argument("destination", help="终点坐标")
    dist_parser.add_argument("-s", "--simple", action="store_true", help="简洁输出")
    
    # 导航链接
    navi_parser = subparsers.add_parser("navi", aliases=["n"], help="生成导航链接")
    navi_parser.add_argument("location", help="坐标")
    navi_parser.add_argument("name", help="名称")
    
    # 打车链接
    taxi_parser = subparsers.add_parser("taxi", aliases=["t"], help="生成打车链接")
    taxi_parser.add_argument("from", help="起点坐标")
    taxi_parser.add_argument("from_name", help="起点名称")
    taxi_parser.add_argument("to", help="终点坐标")
    taxi_parser.add_argument("to_name", help="终点名称")
    
    # 批量地理编码
    batch_geo_parser = subparsers.add_parser("batch-geo", aliases=["bg"], help="批量地理编码")
    batch_geo_parser.add_argument("addresses", help="地址列表(逗号分隔)")
    batch_geo_parser.add_argument("-s", "--simple", action="store_true", help="简洁输出")
    
    # 批量周边搜索
    batch_around_parser = subparsers.add_parser("batch-around", aliases=["ba"], help="批量周边搜索")
    batch_around_parser.add_argument("keywords", help="关键词列表(逗号分隔)")
    batch_around_parser.add_argument("location", help="中心坐标")
    batch_around_parser.add_argument("radius", nargs="?", type=int, help="搜索半径")
    batch_around_parser.add_argument("-s", "--simple", action="store_true", help="简洁输出")
    
    # 配置命令
    config_parser = subparsers.add_parser("config", help="配置管理")
    config_parser.add_argument("action", nargs="?", default="show", help="操作 (set/show)")
    config_parser.add_argument("key", nargs="?", help="配置项")
    config_parser.add_argument("value", nargs="?", help="配置值")
    
    # API Key管理
    set_key_parser = subparsers.add_parser("set-amapkey", help="设置API Key")
    set_key_parser.add_argument("key", help="API Key")
    set_key_parser.add_argument("-l", "--level", choices=["User", "Machine"], default="User", help="环境变量级别")
    
    subparsers.add_parser("get-amapkey", help="查看API Key")
    
    # 其他
    subparsers.add_parser("status", help="运行状态")
    subparsers.add_parser("clear-cache", help="清除缓存")
    subparsers.add_parser("shell", help="交互式Shell")
    
    # 导出数据
    export_parser = subparsers.add_parser("export", help="导出数据到文件")
    export_parser.add_argument("file_type", help="文件类型 (json/csv)")
    export_parser.add_argument("file_path", help="输出文件路径")
    export_parser.add_argument("data", nargs="?", default=None, help="要导出的数据(JSON字符串或文件路径)")
    
    subparsers.add_parser("help", aliases=["h"], help="显示帮助")
    
    return parser


def main():
    """主程序入口"""
    global _session_start
    _session_start = time.time()
    
    parser = create_parser()
    args = parser.parse_args()
    
    # 如果没有命令，显示帮助
    if not args.command or args.command == "help":
        show_help()
        return
    
    try:
        cmd = args.command.lower()
        
        # 别名映射
        alias_map = {
            "g": "geo", "rg": "regeo", "w": "weather", "s": "search",
            "a": "around", "d": "detail", "r": "route", "dist": "distance",
            "n": "navi", "t": "taxi", "bg": "batch-geo", "ba": "batch-around",
            "h": "help"
        }
        cmd = alias_map.get(cmd, cmd)
        
        if cmd == "geo":
            cmd_geo(args.address, args.city, args.simple)
        
        elif cmd == "regeo":
            cmd_regeo(args.location, args.simple)
        
        elif cmd == "weather":
            cmd_weather(args.city, args.format)
        
        elif cmd == "ip":
            cmd_ip(args.ip, args.simple)
        
        elif cmd == "search":
            cmd_search(args.keywords, args.city, args.format, args.limit, 
                      args.all_pages, args.output)
        
        elif cmd == "around":
            cmd_around(args.keywords, args.location, args.radius, args.format,
                      args.limit, args.all_pages, args.output)
        
        elif cmd == "detail":
            cmd_detail(args.id)
        
        elif cmd == "route":
            cmd_route(getattr(args, "from"), args.to, args.strategy, args.format)
        
        elif cmd == "distance":
            cmd_distance(args.origin, args.destination, args.simple)
        
        elif cmd == "navi":
            cmd_navi(args.location, args.name)
        
        elif cmd == "taxi":
            cmd_taxi(getattr(args, "from"), args.from_name, args.to, args.to_name)
        
        elif cmd == "batch-geo":
            cmd_batch_geo(args.addresses, args.simple)
        
        elif cmd == "batch-around":
            cmd_batch_around(args.keywords, args.location, args.radius, args.simple)
        
        elif cmd == "config":
            if args.action == "set" and args.key and args.value:
                set_config_value(args.key, args.value)
            else:
                show_config()
        
        elif cmd == "set-amapkey":
            set_api_key(args.key, args.level)
        
        elif cmd == "get-amapkey":
            key = get_api_key()
            display_key = f"{key[:8]}...{key[-4:]}" if len(key) > 12 else "****"
            print(f"当前API Key: {display_key}")
        
        elif cmd == "status":
            show_status()
        
        elif cmd == "clear-cache":
            clear_cache()
        
        elif cmd == "shell":
            enter_shell()
        
        elif cmd == "export":
            data_to_export = args.data
            # 如果 data 是文件路径，先读取内容
            if data_to_export:
                data_path = Path(data_to_export)
                if data_path.is_file():
                    try:
                        with open(data_path, "r", encoding="utf-8") as f:
                            data_to_export = f.read()
                    except (IOError, OSError):
                        pass
            export_data(args.file_type, args.file_path, data_to_export)
        
        else:
            show_help()
    
    except Exception as e:
        print(f"[ERROR] {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
