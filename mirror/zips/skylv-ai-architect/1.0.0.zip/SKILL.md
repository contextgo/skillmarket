---
name: "ai-architect"
slug: skylv-ai-architect
version: 1.0.0
description: "AI架构设计助手。设计AI系统架构、技术选型、性能优化。使用场景：(1) AI系统架构设计，(2) 技术选型建议，(3) 性能优化方案，(4) 成本优化策略。"
author: SKY-lv
license: MIT-0
tags: [ai, openclaw, agent]
---

# AI Architect — AI架构设计助手

## 功能说明

设计和优化AI系统架构。

## 使用方法

### 1. 系统架构

```
用户: 设计一个RAG系统架构
```

### 2. 技术选型

```
用户: 推荐什么向量数据库？
```

### 3. 性能优化

```
用户: 如何优化LLM响应速度？
```

### 4. 成本优化

```
用户: 如何降低AI API调用成本？
```
