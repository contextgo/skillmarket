"""业务逻辑：把输入文案润色一下（mock）"""
import re

async def polish_text(text: str) -> str:
    trimmed = (text or '').strip()
    if not trimmed:
        return ''
    polished = re.sub(r',\s*', '， ', trimmed)
    polished = re.sub(r'\.\s*', '。 ', polished)
    polished = re.sub(r'\s+', ' ', polished)
    tail = '' if polished.endswith('。') else '。'
    return f'【润色后】{polished}{tail}'
