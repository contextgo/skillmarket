# 与原始版本代码完全一致
from fastapi import FastAPI, HTTPException
from polish import polish_text

app = FastAPI(title='polish-skill-plan-a')

@app.post('/polish')
async def polish(payload: dict):
    text = payload.get('text')
    if not text:
        raise HTTPException(400, 'text 必填')
    polished = await polish_text(text)
    return {'polished': polished}

# 启动命令：
#   uvicorn service:app --host 127.0.0.1 --port 3000   ← 只监听内网
#   sidecar 来做公网入口
