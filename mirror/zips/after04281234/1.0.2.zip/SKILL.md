---
name: polish-skill-plan-a
description: AI 文案润色 Skill（方案 A 反向代理接入 AgentPay，业务代码 0 行改动，按次收费 0.01 元）。在业务前加 fypay-proxy sidecar，所有 AgentPay 协议由 sidecar 处理。
version: 1.0.0
license: MIT
pricing:
  model: per_call
  amount_cny: 0.01
agentpay:
  integration: reverse_proxy
  business_code_changes: 0
---

# AI 文案润色 Skill · 方案 A（反向代理）

## 架构

业务服务 + 前置 fypay-proxy sidecar 实现按次收费，业务代码零改动。

## 接口

对买家暴露（走 sidecar）：

```
POST /polish   # sidecar 自动分流询价/付款/退款
```
