// 业务逻辑：把输入文案润色一下（mock：只是简单加个前后缀 + 标点规整）
async function polishText(text) {
  // 真实环境会调 LLM：https://llm.example.com/polish
  // demo 里用本地规则 mock
  const trimmed = String(text || '').trim();
  if (!trimmed) return '';
  const polished = trimmed
    .replace(/,\s*/g, '， ')
    .replace(/\.\s*/g, '。 ')
    .replace(/\s+/g, ' ');
  return `【润色后】${polished}${polished.endsWith('。') ? '' : '。'}`;
}
module.exports = { polishText };
