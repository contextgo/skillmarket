const express = require('express');
const { polishText } = require('./polish');
const app = express();
app.use(express.json());

// 与原始版本代码完全一致，只是 listen 改为 127.0.0.1
app.post('/polish', async (req, res) => {
  const { text } = req.body || {};
  if (!text) return res.status(400).json({ error: 'text 必填' });
  const polished = await polishText(text);
  res.json({ polished });
});

// ← 唯一的"改动"：只监听内网，sidecar 来做公网入口
app.listen(3000, '127.0.0.1', () => console.log('[plan-a] listening on 127.0.0.1:3000'));
