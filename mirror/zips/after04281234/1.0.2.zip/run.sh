#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
[ ! -d node_modules ] && npm install --omit=dev
# 后台启动业务进程
node service.js &
BIZ_PID=$!
trap "kill $BIZ_PID" EXIT
# 前台启动 sidecar（需先安装 fypay-proxy）
fypay-proxy serve --quote ./quote.json --listen :443 --upstream http://127.0.0.1:3000 "$@"
