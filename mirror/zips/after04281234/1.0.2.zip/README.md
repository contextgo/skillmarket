# 🧩 AI 文案润色 Skill · 方案 A（反向代理 / Sidecar）

> ⚠️ **这是教学用 Demo Skill，不会主动调用任何远端服务**。装了之后只是在你本机跑一份示例代码，用来展示「方案 A（反代）」的代码结构。
>
> 如果你想 **直接调到 AgentPay 线上润色服务**，请改装 👉 **`polish-skill-client`**。

> 在原始 Skill 的基础上，**业务代码 0 行改动**，通过 fypay-proxy sidecar 实现按次收费（0.01 元/次）。

## 接入亮点

- ✅ **业务代码零修改**：service.js / service.py 与原始版本完全一致
- ✅ **语言无关**：任何 HTTP 服务都能套用（Java / Go / PHP 同理）
- ✅ **协议独立升级**：升 sidecar 不动业务
- ⚠️ 依赖部署拓扑：在业务服务前面要能加一层代理

## 运行

```bash
# 1. 启动业务服务（只监听 127.0.0.1）
npm install && node service.js   # 监听 127.0.0.1:3000

# 2. 启动 fypay-proxy sidecar（公网入口，分流询价/付款）
npm install -g fypay-proxy
fypay-proxy serve \
  --quote ./quote.json \
  --listen :443 \
  --upstream http://127.0.0.1:3000 \
  --platform-endpoint https://api.agentpay.qq.com
```

本地开发可用 mock 模式：
```bash
fypay-proxy serve --quote ./quote.json \
  --listen :8080 --upstream http://127.0.0.1:3000 --mode=mock
```

## 流量示意

```
买家 Agent ──HTTPS──> fypay-proxy (:443) ──HTTP──> 业务服务 (127.0.0.1:3000)
                         │
                         ├─ 无支付票：直接返回 402 + AgentPay-Quote（由 quote.json 签发）
                         ├─ 带支付票：验证通过后透传到业务
                         └─ 业务返 4xx/5xx：自动向平台推 Void 退款
```

## 适用场景

- K8s / 自建机房 / 裸机，业务前面可以加 Nginx / Ingress 或 sidecar 容器
- 多语言团队（业务是 Java/Go/PHP 都行）
- 需要协议层和业务层解耦的场景
