#!/usr/bin/env python3
"""
Java Spring API 文档生成器（稳定版 v5）
- 支持 ResponseEntity<?> 等泛型通配符
- 增加 @RequestHeader 参数过滤
- 修复类级别路径提取（只取类定义之前）
- 增强实体类字段展开（请求体与响应）
"""

import re
import json
import argparse
from pathlib import Path
from typing import List, Dict, Optional

class EntityField:
    def __init__(self, name: str, type_str: str, description: str = "", required: bool = False):
        self.name = name
        self.type = type_str
        self.description = description
        self.required = required

class EntityParser:
    def __init__(self, project_roots: List[Path]):
        self.roots = project_roots

    def find_entity_file(self, class_name: str, current_file: Path) -> Optional[Path]:
        if '$' in class_name:
            class_name = class_name.split('$')[0]
        same_dir = current_file.parent / f"{class_name}.java"
        if same_dir.exists():
            return same_dir
        for root in self.roots:
            for java_file in root.rglob(f"{class_name}.java"):
                return java_file
        return None

    def parse_entity(self, file_path: Path) -> List[EntityField]:
        content = file_path.read_text(encoding='utf-8', errors='ignore')
        fields = []
        lines = content.splitlines()
        i = 0
        while i < len(lines):
            line = lines[i].strip()
            if line.startswith('import ') or line.startswith('package ') or line.startswith('@'):
                i += 1
                continue
            match = re.match(r'(private|protected|public)\s+(\w+(?:<[\w\s,<>?]+>)?)\s+(\w+)\s*[;=]', line)
            if match:
                field_type = match.group(2)
                field_name = match.group(3)
                description = self._extract_field_comment(lines, i)
                required = self._has_notnull_annotation(lines, i)
                fields.append(EntityField(field_name, field_type, description, required))
            i += 1
        return fields

    def _extract_field_comment(self, lines: List[str], idx: int) -> str:
        comment_lines = []
        i = idx - 1
        while i >= 0:
            line = lines[i].strip()
            if line.startswith('//'):
                comment_lines.insert(0, line[2:].strip())
            elif '/*' in line and '*/' in line:
                comment = re.sub(r'/\*+|\*/', '', line).strip()
                comment_lines.insert(0, comment)
            elif line.startswith('*'):
                comment_lines.insert(0, line[1:].strip())
            elif line.endswith('*/') and not line.lstrip().startswith('*'):
                comment_lines.insert(0, line.replace('*/', '').strip())
                break
            elif line == '':
                i -= 1
                continue
            else:
                break
            i -= 1
        return ' '.join(comment_lines)

    def _has_notnull_annotation(self, lines: List[str], idx: int) -> bool:
        for offset in range(-5, 4):
            check_idx = idx + offset
            if 0 <= check_idx < len(lines):
                if any(ann in lines[check_idx] for ann in ('@NotNull', '@NotBlank', '@NotEmpty')):
                    return True
        return False


class ControllerParser:
    def __init__(self, file_path: Path, entity_parser: EntityParser):
        self.file_path = file_path
        self.entity_parser = entity_parser
        self.content = file_path.read_text(encoding='utf-8', errors='ignore')
        self.class_path_prefix = ""
        self.class_desc = ""
        self.methods = []

    def is_controller(self) -> bool:
        return bool(re.search(r'@(Rest)?Controller\b', self.content))

    def parse(self):
        if not self.is_controller():
            return False
        self.class_path_prefix = self._extract_class_path_prefix()
        self.class_desc = self._extract_class_javadoc()
        self.methods = self._parse_methods()
        return True

    def _extract_class_path_prefix(self) -> str:
        """只提取类定义之前的 @RequestMapping 路径"""
        class_match = re.search(r'\bpublic\s+class\s+\w+', self.content)
        if not class_match:
            return ""
        before_class = self.content[:class_match.start()]
        before_class = re.sub(r'/\*.*?\*/', '', before_class, flags=re.DOTALL)
        pattern = r'@RequestMapping\s*\(\s*(?:value|path)?\s*=\s*["\']([^"\']+)["\']'
        m = re.search(pattern, before_class)
        if m:
            return m.group(1)
        pattern2 = r'@RequestMapping\s*\(\s*["\']([^"\']+)["\']'
        m2 = re.search(pattern2, before_class)
        if m2:
            return m2.group(1)
        return ""

    def _extract_class_javadoc(self) -> str:
        class_def = re.search(r'\bpublic\s+class\s+\w+', self.content)
        if not class_def:
            return ""
        before = self.content[:class_def.start()]
        doc_match = re.search(r'/\*\*(.*?)\*/', before, re.DOTALL)
        if doc_match:
            doc = doc_match.group(1)
            lines = [re.sub(r'^\s*\*\s?', '', line) for line in doc.splitlines()]
            return ' '.join(lines).strip()
        return ""

    def _parse_methods(self) -> List[Dict]:
        methods = []
        lines = self.content.splitlines()
        i = 0
        while i < len(lines):
            line = lines[i]
            if re.match(r'\s*(public|private|protected)\s+', line):
                method_block = self._collect_method_block(lines, i)
                if method_block:
                    ann = self._extract_mapping_annotation(method_block['block_text'])
                    if ann:
                        param_str = method_block['param_str']
                        raw_params = self._extract_params(param_str, method_block['block_text'])
                        expanded_params = self._expand_body_params(raw_params)
                        response_example = self._expand_response_entity(method_block.get('return_type'))
                        methods.append({
                            'http_method': ann['method'],
                            'path': self._join_path(self.class_path_prefix, ann['path']),
                            'name': method_block['name'],
                            'doc': self._extract_method_javadoc(lines, i),
                            'params': expanded_params,
                            'request_body_example': self._generate_request_body(expanded_params),
                            'response_example': response_example,
                            'deprecated': '@Deprecated' in method_block['block_text']
                        })
                i = method_block['end_line'] if method_block else i + 1
            else:
                i += 1
        return methods

    def _collect_method_block(self, lines: List[str], start_idx: int) -> Optional[Dict]:
        block = ""
        i = start_idx
        brace = 0
        while i < len(lines):
            line = lines[i]
            block += line + "\n"
            if '{' in line:
                brace += 1
            if '}' in line:
                brace -= 1
            if brace == 0 and ('{' in line or ';' in line):
                break
            i += 1
            if i - start_idx > 200:
                break
        # 匹配方法签名，允许泛型通配符 ?
        match = re.search(r'\b(?:public|private|protected)\s+(\w+(?:<[\w\s,<>?]+>)?)\s+(\w+)\s*\(([^)]*)\)', block)
        if not match:
            return None
        return {
            'name': match.group(2),
            'return_type': match.group(1),
            'param_str': match.group(3),
            'block_text': block,
            'end_line': i
        }

    def _extract_mapping_annotation(self, block_text: str) -> Optional[Dict]:
        simple_patterns = [
            r'@(Get|Post|Put|Delete|Patch)Mapping\s*\(\s*["\']([^"\']+)["\']',
            r'@(Get|Post|Put|Delete|Patch)Mapping\s*\(\s*(?:value|path)\s*=\s*["\']([^"\']+)["\']',
        ]
        for pat in simple_patterns:
            m = re.search(pat, block_text, re.IGNORECASE)
            if m:
                return {'method': m.group(1).upper(), 'path': m.group(2)}
        if '@RequestMapping' in block_text:
            path = ''
            method = 'GET'
            path_match = re.search(r'@RequestMapping\s*\(\s*(?:value|path)\s*=\s*["\']([^"\']+)["\']', block_text)
            if path_match:
                path = path_match.group(1)
            else:
                path_match2 = re.search(r'@RequestMapping\s*\(\s*["\']([^"\']+)["\']', block_text)
                if path_match2:
                    path = path_match2.group(1)
            method_match = re.search(r'method\s*=\s*RequestMethod\.(\w+)', block_text)
            if method_match:
                method = method_match.group(1).upper()
            if path:
                return {'method': method, 'path': path}
        return None

    def _extract_method_javadoc(self, lines: List[str], start_idx: int) -> str:
        doc_lines = []
        i = start_idx - 1
        while i >= 0:
            line = lines[i].strip()
            if line.endswith('*/'):
                doc_lines.insert(0, line)
                break
            if line.startswith('*') or line.startswith('/*'):
                doc_lines.insert(0, line)
            elif line == '':
                i -= 1
                continue
            else:
                break
            i -= 1
        if doc_lines:
            doc = ' '.join([re.sub(r'^[\s\*/*]+', '', l) for l in doc_lines])
            return doc.strip()
        return ""

    def _extract_params(self, param_str: str, block_text: str) -> List[Dict]:
        if not param_str:
            return []
        # 分割参数，忽略尖括号内的逗号
        params = []
        depth = 0
        current = []
        for ch in param_str:
            if ch == '<':
                depth += 1
            elif ch == '>':
                depth -= 1
            elif ch == ',' and depth == 0:
                params.append(''.join(current).strip())
                current = []
                continue
            current.append(ch)
        if current:
            params.append(''.join(current).strip())
        result = []
        for p in params:
            if not p:
                continue
            # 忽略 HttpServletRequest/Response/Session/HttpHeaders
            if any(x in p for x in ('HttpServletRequest', 'HttpServletResponse', 'HttpSession', 'HttpHeaders')):
                continue
            param_info = {'in': 'query', 'type': 'string', 'required': True, 'example': 'example', 'name': 'unknown'}
            if '@PathVariable' in p:
                param_info['in'] = 'path'
                name = self._extract_param_name(p)
                param_info['name'] = name if name else 'id'
                param_info['type'] = self._extract_type(p)
                param_info['example'] = '1'
            elif '@RequestParam' in p:
                param_info['in'] = 'query'
                name = self._extract_param_name(p)
                param_info['name'] = name if name else 'param'
                param_info['type'] = self._extract_type(p)
                param_info['required'] = 'required=false' not in p
                param_info['example'] = self._example_for_type(param_info['type'])
            elif '@RequestBody' in p:
                param_info['in'] = 'body'
                param_info['type'] = self._extract_type(p)
                param_info['name'] = 'body'
                param_info['is_body_object'] = True
                param_info['body_class_name'] = self._extract_type(p)
            elif '@RequestHeader' in p:
                # 请求头参数，忽略（文档中不展示）
                continue
            else:
                name = self._extract_param_name(p)
                param_info['name'] = name if name else 'param'
                param_info['type'] = self._extract_type(p)
                param_info['example'] = self._example_for_type(param_info['type'])
            if param_info['name'] == 'unknown':
                param_info['name'] = 'param'
            result.append(param_info)
        return result

    def _extract_param_name(self, param_token: str) -> str:
        cleaned = re.sub(r'@\w+(\([^)]*\))?', '', param_token)
        words = cleaned.split()
        if words:
            candidate = words[-1]
            if candidate not in ('final', 'var'):
                return candidate
        return ""

    def _extract_type(self, param_token: str) -> str:
        cleaned = re.sub(r'@\w+(\([^)]*\))?', '', param_token)
        words = cleaned.split()
        for w in words:
            if w not in ('final', 'var') and (w[0].isupper() or w in ('int', 'long', 'double', 'float', 'boolean', 'String', 'Integer', 'Long', 'Boolean')):
                return w
        return 'String'

    def _example_for_type(self, typ: str) -> str:
        typ_lower = typ.lower()
        if typ_lower in ('int', 'long', 'double', 'float', 'integer'):
            return '1'
        if typ_lower == 'boolean':
            return 'true'
        return 'example'

    def _expand_body_params(self, params: List[Dict]) -> List[Dict]:
        expanded = []
        for p in params:
            if p.get('is_body_object') and p.get('body_class_name'):
                class_name = p['body_class_name']
                entity_file = self.entity_parser.find_entity_file(class_name, self.file_path)
                if entity_file:
                    fields = self.entity_parser.parse_entity(entity_file)
                    if fields:
                        for f in fields:
                            expanded.append({
                                'name': f.name,
                                'in': 'body',
                                'type': f.type,
                                'required': f.required,
                                'description': f.description,
                                'example': self._example_for_type(f.type)
                            })
                        continue
                expanded.append(p)
            else:
                expanded.append(p)
        return expanded

    def _expand_response_entity(self, return_type: Optional[str]) -> Optional[Dict]:
        if not return_type or return_type in ('void', 'String', 'ResponseEntity', 'ResponseEntity<?>'):
            return None
        clean_type = return_type
        # 处理 ResponseEntity<User> -> User
        if '<' in clean_type:
            inner = re.search(r'<(\w+(?:<[\w\s,<>?]+>)?)>', clean_type)
            if inner:
                clean_type = inner.group(1)
        # 去除 ? 通配符
        clean_type = clean_type.replace('?', '').strip()
        if not clean_type or clean_type[0].islower():
            return None
        entity_file = self.entity_parser.find_entity_file(clean_type, self.file_path)
        if entity_file:
            fields = self.entity_parser.parse_entity(entity_file)
            if fields:
                example = {}
                for f in fields:
                    example[f.name] = self._example_for_type(f.type)
                return example
        return {clean_type: "example object"}

    def _generate_request_body(self, params: List[Dict]) -> Optional[Dict]:
        body_fields = [p for p in params if p.get('in') == 'body' and p.get('name') != 'body']
        if body_fields:
            example = {}
            for f in body_fields:
                example[f['name']] = f.get('example', 'string')
            return example
        return None

    def _join_path(self, parent: str, child: str) -> str:
        if not parent:
            return child if child.startswith('/') else '/' + child
        if not child:
            return parent
        parent = parent.rstrip('/')
        child = child.lstrip('/')
        return f"/{parent}/{child}" if parent else f"/{child}"


class MarkdownGenerator:
    def __init__(self, project_name: str = "API Documentation", base_url: str = "http://localhost:8080"):
        self.project_name = project_name
        self.base_url = base_url
        self.controllers = []

    def add_controller(self, class_name: str, prefix: str, desc: str, methods: List[Dict]):
        self.controllers.append({
            'name': class_name,
            'prefix': prefix,
            'desc': desc,
            'methods': methods
        })

    def generate(self) -> str:
        lines = [f"# {self.project_name}\n", f"**Base URL**: `{self.base_url}`\n", "---\n"]
        for ctrl in self.controllers:
            lines.append(f"## {ctrl['name']}\n")
            if ctrl['desc']:
                lines.append(f"{ctrl['desc']}\n")
            if ctrl['prefix']:
                lines.append(f"**Controller 前缀**: `{ctrl['prefix']}`\n")
            for method in ctrl['methods']:
                lines.append(f"### {method['name']}\n")
                lines.append(f"**{method['http_method']}** `{method['path']}`\n")
                if method['doc']:
                    lines.append(f"*描述*: {method['doc']}\n")
                if method['deprecated']:
                    lines.append("> ⚠️ **废弃接口**\n")
                if method['params']:
                    lines.append("#### 请求参数\n")
                    lines.append("| 参数名 | 位置 | 类型 | 必填 | 描述 |")
                    lines.append("|--------|------|------|------|------|")
                    for p in method['params']:
                        name = p.get('name', 'unknown')
                        loc = p.get('in', 'query')
                        typ = p.get('type', 'string')
                        required = '是' if p.get('required', True) else '否'
                        desc = p.get('description', '')
                        lines.append(f"| {name} | {loc} | {typ} | {required} | {desc} |")
                    lines.append("")
                if method['request_body_example']:
                    lines.append("#### 请求体示例\n")
                    lines.append("```json")
                    lines.append(json.dumps(method['request_body_example'], indent=2, ensure_ascii=False))
                    lines.append("```\n")
                if method['response_example']:
                    lines.append("#### 响应示例\n")
                    lines.append("```json")
                    lines.append(json.dumps(method['response_example'], indent=2, ensure_ascii=False))
                    lines.append("```\n")
                lines.append("---\n")
        return '\n'.join(lines)


def find_java_files(root: Path) -> List[Path]:
    return list(root.rglob("*.java"))

def main():
    parser = argparse.ArgumentParser(description="零侵入 Java Spring API 文档生成器 v5")
    parser.add_argument("--src", action='append', help="源码根目录（可多次使用）")
    parser.add_argument("--output", default="API_DOCUMENTATION.md", help="输出 Markdown 文件")
    parser.add_argument("--base-url", default="http://localhost:8080", help="API 基础 URL")
    parser.add_argument("--title", default="API Documentation", help="文档标题")
    args = parser.parse_args()

    roots = []
    if args.src:
        for s in args.src:
            p = Path(s).resolve()
            if p.exists():
                roots.append(p)
            else:
                print(f"警告: 目录不存在 {p}")
    if not roots:
        default = Path.cwd() / "src" / "main" / "java"
        if default.exists():
            roots.append(default)
        else:
            roots.append(Path.cwd())

    all_java = []
    for r in roots:
        all_java.extend(find_java_files(r))
    all_java = list(set(all_java))

    if not all_java:
        print("未找到任何 Java 文件")
        return

    entity_parser = EntityParser(roots)
    doc_gen = MarkdownGenerator(args.title, args.base_url)
    total_methods = 0

    for java_file in all_java:
        parser_obj = ControllerParser(java_file, entity_parser)
        if parser_obj.parse():
            doc_gen.add_controller(java_file.stem, parser_obj.class_path_prefix, parser_obj.class_desc, parser_obj.methods)
            total_methods += len(parser_obj.methods)
            print(f"解析 {java_file} : 发现 {len(parser_obj.methods)} 个接口")

    if total_methods == 0:
        print("未发现任何 Controller 接口")
        return

    out_path = Path(args.output)
    out_path.write_text(doc_gen.generate(), encoding='utf-8')
    print(f"\n✅ 文档已生成: {out_path.resolve()}")
    print(f"   包含 {len(doc_gen.controllers)} 个 Controller，{total_methods} 个接口")

if __name__ == "__main__":
    main()