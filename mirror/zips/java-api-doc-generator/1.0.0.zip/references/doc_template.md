# 项目 API 文档模板

**Base URL**: `https://api.example.com/v1`

## 用户模块

### 获取用户详情

**GET** `/users/{id}`

*描述*: 根据用户ID获取用户信息

#### 请求参数

| 参数名 | 位置 | 类型 | 必填 | 描述 |
|--------|------|------|------|------|
| id     | path | Long | 是   | 用户ID |

#### 响应示例

```json
{
  "id": 1,
  "name": "张三",
  "email": "zhangsan@example.com"
}