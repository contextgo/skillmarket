
---

## 📚 references/annotation_guide.md

```markdown
# Spring 注解解析说明

本解析器支持以下常见注解：

| 注解 | 提取内容 |
|------|----------|
| `@RestController` / `@Controller` | 识别为控制器 |
| `@RequestMapping` (类级别) | 路径前缀 |
| `@GetMapping`, `@PostMapping` 等 | HTTP 方法和子路径 |
| `@PathVariable` | 路径参数 |
| `@RequestParam` | 查询参数 |
| `@RequestBody` | 请求体参数 |
| `@Deprecated` | 标记废弃接口 |
| `@ApiOperation` (Swagger) | 接口摘要 |

**不支持**（但可后续扩展）：
- `@MatrixVariable`
- `@RequestAttribute`
- 通过 `HttpServletRequest` 动态获取参数
- 非 Spring 框架（如 JAX-RS）