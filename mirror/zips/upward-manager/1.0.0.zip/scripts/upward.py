#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
向上管理器 - 主脚本
职场向上管理神器：汇报策略、预期管理、资源争取、指令解码
"""

import json
import argparse
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

# 数据文件路径
DATA_DIR = Path(__file__).parent.parent / "data"
BOSS_PROFILES_FILE = DATA_DIR / "boss_profiles.json"
CONTRIBUTIONS_FILE = DATA_DIR / "contributions.json"
HISTORY_FILE = DATA_DIR / "history.json"


class UpwardManager:
    """向上管理器核心类"""
    
    # 老板类型定义
    BOSS_TYPES = {
        "result": {
            "name": "结果导向型",
            "traits": "只看结果，不关心过程",
            "strategy": "结论先行，关键数据，不找借口"
        },
        "process": {
            "name": "过程控制型", 
            "traits": "追问细节，关注过程",
            "strategy": "数据齐全，过程展示，方案对比"
        },
        "control": {
            "name": "控制欲强型",
            "traits": "事无巨细都要知道",
            "strategy": "高频同步，主动汇报，及时请示"
        },
        "trust": {
            "name": "放手信任型",
            "traits": "给目标就行，过程不管",
            "strategy": "节点同步，有风险才说，结果验收"
        },
        "emotional": {
            "name": "情绪型",
            "traits": "看心情",
            "strategy": "观察状态，选对时机，灵活应对"
        }
    }
    
    # 模糊指令解码库
    DECODE_LIBRARY = {
        "你看着办": {
            "meanings": [
                "真放手让你决定",
                "测试你的判断力",
                "他也不确定，不想担责",
                "没时间细说，以后会追问"
            ],
            "strategy": "用选择题确认，留书面记录",
            "confirm_template": "好的，我理解是要xxx，这样对吗？我目前计划A方案/B方案，您觉得哪个更合适？"
        },
        "尽快": {
            "meanings": [
                "今天下班前",
                "本周内",
                "越快越好（没标准）"
            ],
            "strategy": "明确具体时间节点",
            "confirm_template": "收到，我预计xx时间完成，这个时间可以吗？"
        },
        "这个你跟进一下": {
            "meanings": [
                "全权负责",
                "只是盯着，不用亲自做",
                "出问题你背锅"
            ],
            "strategy": "明确责任边界",
            "confirm_template": "好的，我理解需要跟进xxx，我的角色是A还是B？有情况随时同步您。"
        },
        "这个不急": {
            "meanings": [
                "真的不急",
                "现在不说，但会突然问",
                "排在后面，但别忘"
            ],
            "strategy": "记录在案，定期确认",
            "confirm_template": "好的，我记录下来了，预计xx时间处理，到时候再跟您确认优先级。"
        }
    }
    
    # 资源争取说服框架
    PERSUADE_FRAMEWORK = [
        ("痛点锚定", "目前xxx问题导致xxx损失"),
        ("方案呈现", "如果xxx，可以解决xxx问题"),
        ("投入产出", "投入xx，预计收益xx"),
        ("降低风险", "前期可以小规模试点，效果好再推广")
    ]
    
    # 汇报时机矩阵
    TIMING_MATRIX = {
        "good_news": {
            "name": "好消息",
            "best": "周一上午",
            "ok": "周二至周四",
            "avoid": "周五下午"
        },
        "bad_news": {
            "name": "坏消息",
            "best": "周二至周三",
            "ok": "周一/周四",
            "avoid": "周一早/月底"
        },
        "resource": {
            "name": "争取资源",
            "best": "老板心情好时",
            "ok": "常规时间",
            "avoid": "刚被批之后"
        },
        "decision": {
            "name": "请示决策",
            "best": "上午",
            "ok": "下午早",
            "avoid": "临下班"
        },
        "progress": {
            "name": "汇报进度",
            "best": "定期同步",
            "ok": "被问之前",
            "avoid": "突然袭击"
        },
        "leave": {
            "name": "请假",
            "best": "周二至周三",
            "ok": "周一",
            "avoid": "周五/月底"
        }
    }

    def __init__(self):
        self._ensure_data_dir()
    
    def _ensure_data_dir(self):
        """确保数据目录存在"""
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        for file in [BOSS_PROFILES_FILE, CONTRIBUTIONS_FILE, HISTORY_FILE]:
            if not file.exists():
                file.write_text("{}", encoding="utf-8")
    
    def _load_json(self, file_path: Path) -> Dict:
        """加载JSON文件"""
        try:
            return json.loads(file_path.read_text(encoding="utf-8"))
        except:
            return {}
    
    def _save_json(self, file_path: Path, data: Dict):
        """保存JSON文件"""
        file_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    
    # ==================== 汇报策略 ====================
    
    def generate_report(self, tasks: List[str], boss_type: str = "result") -> Dict:
        """生成汇报策略"""
        if boss_type not in self.BOSS_TYPES:
            boss_type = "result"
        
        boss_info = self.BOSS_TYPES[boss_type]
        
        # 构建汇报结构
        report = {
            "boss_type": boss_info["name"],
            "strategy": boss_info["strategy"],
            "structure": self._build_report_structure(tasks, boss_type),
            "template": self._generate_report_template(tasks, boss_type),
            "tips": self._get_report_tips(boss_type)
        }
        
        # 保存历史
        self._save_history("report", {"tasks": tasks, "boss_type": boss_type})
        
        return report
    
    def _build_report_structure(self, tasks: List[str], boss_type: str) -> List[str]:
        """构建汇报结构"""
        if boss_type == "result":
            return ["结论先行", "关键数据", "下一步计划", "需要支持"]
        elif boss_type == "process":
            return ["背景说明", "详细过程", "数据支撑", "方案对比", "结论建议"]
        elif boss_type == "control":
            return ["当前进展", "具体细节", "遇到问题", "解决方案", "下次汇报时间"]
        elif boss_type == "trust":
            return ["核心成果", "关键节点", "风险提示（如有）"]
        else:
            return ["成果总结", "关键信息", "下一步"]
    
    def _generate_report_template(self, tasks: List[str], boss_type: str) -> str:
        """生成汇报模板"""
        structure = self._build_report_structure(tasks, boss_type)
        template_lines = ["📋 汇报模板", ""]
        
        for i, section in enumerate(structure, 1):
            template_lines.append(f"{i}. {section}")
            template_lines.append(f"   [填写内容]")
            template_lines.append("")
        
        return "\n".join(template_lines)
    
    def _get_report_tips(self, boss_type: str) -> List[str]:
        """获取汇报提示"""
        tips_map = {
            "result": [
                "先说结论，再说过程",
                "用数据说话，避免形容词",
                "有问题直接说解决方案，不要只说问题"
            ],
            "process": [
                "准备充分的数据和细节",
                "预判可能的追问",
                "展示你的思考过程"
            ],
            "control": [
                "主动汇报，不要等被问",
                "事无巨细都要同步",
                "提前告知风险"
            ],
            "trust": [
                "关注结果，过程简述",
                "有问题再说，没问题不用频繁汇报",
                "关键节点主动同步"
            ],
            "emotional": [
                "观察老板状态再决定汇报方式",
                "心情好时可以多说",
                "心情不好时长话短说"
            ]
        }
        return tips_map.get(boss_type, tips_map["result"])
    
    # ==================== 指令解码 ====================
    
    def decode_instruction(self, message: str) -> Dict:
        """解码模糊指令"""
        # 查找匹配的指令
        matched_key = None
        for key in self.DECODE_LIBRARY:
            if key in message:
                matched_key = key
                break
        
        if not matched_key:
            return {
                "status": "未识别",
                "message": message,
                "suggestion": "无法自动解码，建议主动确认具体要求"
            }
        
        decode_info = self.DECODE_LIBRARY[matched_key]
        
        result = {
            "status": "已识别",
            "original": matched_key,
            "possible_meanings": decode_info["meanings"],
            "strategy": decode_info["strategy"],
            "confirm_template": decode_info["confirm_template"],
            "risk_warning": "建议：不要猜测，用选择题确认，留下书面记录"
        }
        
        self._save_history("decode", {"message": message, "result": result})
        
        return result
    
    # ==================== 资源争取 ====================
    
    def generate_persuade_script(self, need: str, pain: str, benefit: str = "") -> Dict:
        """生成资源争取话术"""
        script_lines = ["💬 资源争取话术", ""]
        
        framework_items = [
            ("痛点锚定", f"目前{pain}，导致影响了整体进度/质量"),
            ("方案呈现", f"如果{need}，可以解决这个问题"),
            ("投入产出", f"投入{need}后，预计{benefit if benefit else '效率提升/风险降低'}"),
            ("降低风险", "前期可以小范围试点，效果好再全面推广")
        ]
        
        for step, content in framework_items:
            script_lines.append(f"【{step}】")
            script_lines.append(f"  {content}")
            script_lines.append("")
        
        script_lines.append("────── 完整话术示例 ──────")
        script_lines.append("")
        script_lines.append(f"关于{need}的申请：")
        script_lines.append(f"目前我们{pain}，这已经影响了xxx。")
        script_lines.append(f"如果能够{need}，可以解决这个问题，预计{benefit if benefit else '提升整体效率'}。")
        script_lines.append("投入产出比是划算的，建议可以先小范围试点验证效果。")
        
        result = {
            "framework": self.PERSUADE_FRAMEWORK,
            "script": "\n".join(script_lines),
            "checklist": [
                "✓ 量化了现状痛点",
                "✓ 说明了投入产出比",
                "✓ 提供了小范围试点方案",
                "✓ 预留了风险应对"
            ]
        }
        
        self._save_history("persuade", {"need": need, "pain": pain, "benefit": benefit})
        
        return result
    
    # ==================== 预期管理 ====================
    
    def analyze_expectation(self, expectation: str, reality: str) -> Dict:
        """分析预期差距并给出策略"""
        # 简单分析
        analysis = {
            "expectation": expectation,
            "reality": reality,
            "gap_analysis": "",
            "strategy": "",
            "scripts": []
        }
        
        # 判断情况
        if "高" in expectation or "紧" in expectation or "快" in expectation:
            analysis["gap_analysis"] = "预期可能过高"
            analysis["strategy"] = "降预期策略"
            analysis["scripts"] = [
                f"这个目标很有挑战，{reality}",
                "考虑到实际情况，建议我们可以分阶段进行",
                "核心保底目标是xxx，争取做到xxx"
            ]
        elif "低" in expectation or "松" in expectation:
            analysis["gap_analysis"] = "预期较低，可以超预期交付"
            analysis["strategy"] = "超预期策略"
            analysis["scripts"] = [
                f"保底能完成{expectation}",
                f"我这边会额外关注{reality}",
                "核心目标是xxx，争取做到xxx"
            ]
        else:
            analysis["gap_analysis"] = "预期合理，需留buffer"
            analysis["strategy"] = "保守承诺策略"
            analysis["scripts"] = [
                f"目标没问题，预计{expectation}",
                "保守估计xx时间完成",
                "理想情况下可以更早"
            ]
        
        analysis["key_formula"] = "承诺80分 → 交付100分 = 超预期"
        analysis["warning"] = "避免：承诺120分 → 交付100分 = 失望"
        
        return analysis
    
    # ==================== 时机分析 ====================
    
    def get_timing_advice(self, message_type: str) -> Dict:
        """获取沟通时机建议"""
        if message_type not in self.TIMING_MATRIX:
            return {"error": f"未知消息类型: {message_type}"}
        
        timing = self.TIMING_MATRIX[message_type]
        
        return {
            "message_type": timing["name"],
            "best_timing": timing["best"],
            "acceptable_timing": timing["ok"],
            "avoid_timing": timing["avoid"],
            "tips": self._get_timing_tips(message_type)
        }
    
    def _get_timing_tips(self, message_type: str) -> List[str]:
        """获取时机提示"""
        tips = {
            "good_news": ["好消息适合周一说，开启好的一周", "避免周五下午，容易被遗忘"],
            "bad_news": ["坏消息周二周三说最安全", "给老板消化时间，不要临下班才说"],
            "resource": ["观察老板心情再开口", "最好在他刚有好消息之后"],
            "decision": ["上午精神好，决策效率高", "避免临下班，大家都想走"],
            "progress": ["定期同步比突然汇报好", "主动汇报比被动询问好"],
            "leave": ["避开老板忙碌的时间", "提前说比临时说好"]
        }
        return tips.get(message_type, [])
    
    # ==================== 贡献记录 ====================
    
    def add_contribution(self, item: str, category: str = "delivered", impact: str = "") -> Dict:
        """添加贡献记录"""
        contributions = self._load_json(CONTRIBUTIONS_FILE)
        
        today = datetime.now().strftime("%Y-%m-%d")
        week_key = datetime.now().strftime("%Y-W%W")
        
        if week_key not in contributions:
            contributions[week_key] = {
                "delivered": [],
                "risk_avoided": [],
                "efficiency_improved": [],
                "in_progress": []
            }
        
        category_map = {
            "delivered": "delivered",
            "risk": "risk_avoided",
            "efficiency": "efficiency_improved",
            "progress": "in_progress"
        }
        
        cat_key = category_map.get(category, "delivered")
        contributions[week_key][cat_key].append({
            "item": item,
            "impact": impact,
            "date": today
        })
        
        self._save_json(CONTRIBUTIONS_FILE, contributions)
        
        return {"status": "success", "message": f"已记录: {item}"}
    
    def get_contribution_report(self, period: str = "week") -> Dict:
        """获取贡献报告"""
        contributions = self._load_json(CONTRIBUTIONS_FILE)
        
        week_key = datetime.now().strftime("%Y-W%W")
        week_data = contributions.get(week_key, {})
        
        report_lines = ["📋 本周贡献清单", ""]
        
        category_names = {
            "delivered": "✅ 已交付",
            "risk_avoided": "🛡️ 风险规避",
            "efficiency_improved": "📈 效率提升",
            "in_progress": "🔄 进行中"
        }
        
        for cat_key, cat_name in category_names.items():
            items = week_data.get(cat_key, [])
            if items:
                report_lines.append(f"{cat_name}：")
                for item in items:
                    impact = f"（{item['impact']}）" if item.get('impact') else ""
                    report_lines.append(f"  • {item['item']}{impact}")
                report_lines.append("")
        
        if not any(week_data.values()):
            report_lines.append("本周暂无记录")
        
        return {
            "week": week_key,
            "report": "\n".join(report_lines),
            "data": week_data
        }
    
    # ==================== 辅助功能 ====================
    
    def _save_history(self, action: str, data: Dict):
        """保存操作历史"""
        history = self._load_json(HISTORY_FILE)
        timestamp = datetime.now().isoformat()
        
        if "records" not in history:
            history["records"] = []
        
        history["records"].append({
            "timestamp": timestamp,
            "action": action,
            "data": data
        })
        
        # 只保留最近100条
        if len(history["records"]) > 100:
            history["records"] = history["records"][-100:]
        
        self._save_json(HISTORY_FILE, history)
    
    def list_boss_types(self) -> Dict:
        """列出所有老板类型"""
        return {
            "boss_types": self.BOSS_TYPES,
            "usage": "使用 --boss-type 参数指定类型，如: result, process, control, trust, emotional"
        }
    
    def list_message_types(self) -> Dict:
        """列出所有消息类型"""
        return {
            "message_types": {k: v["name"] for k, v in self.TIMING_MATRIX.items()},
            "usage": "使用 --message-type 参数指定类型，如: good_news, bad_news, resource"
        }


def main():
    """主函数"""
    parser = argparse.ArgumentParser(description="向上管理器 - 职场向上管理神器")
    subparsers = parser.add_subparsers(dest="command", help="可用命令")
    
    # 汇报策略命令
    report_parser = subparsers.add_parser("report", help="生成汇报策略")
    report_parser.add_argument("--tasks", nargs="+", required=True, help="任务列表")
    report_parser.add_argument("--boss-type", default="result", 
                               choices=["result", "process", "control", "trust", "emotional"],
                               help="老板类型")
    
    # 指令解码命令
    decode_parser = subparsers.add_parser("decode", help="解码模糊指令")
    decode_parser.add_argument("--message", required=True, help="老板的原话")
    
    # 资源争取命令
    persuade_parser = subparsers.add_parser("persuade", help="生成资源争取话术")
    persuade_parser.add_argument("--need", required=True, help="需要的资源")
    persuade_parser.add_argument("--pain", required=True, help="当前痛点")
    persuade_parser.add_argument("--benefit", default="", help="预期收益")
    
    # 预期管理命令
    expect_parser = subparsers.add_parser("expect", help="分析预期差距")
    expect_parser.add_argument("--expectation", required=True, help="老板期望")
    expect_parser.add_argument("--reality", required=True, help="实际情况")
    
    # 时机分析命令
    timing_parser = subparsers.add_parser("timing", help="获取沟通时机建议")
    timing_parser.add_argument("--message-type", required=True,
                               choices=["good_news", "bad_news", "resource", "decision", "progress", "leave"],
                               help="消息类型")
    
    # 贡献记录命令
    contrib_parser = subparsers.add_parser("contribution", help="管理贡献记录")
    contrib_parser.add_argument("--action", choices=["add", "report"], default="report", help="操作类型")
    contrib_parser.add_argument("--item", help="贡献内容")
    contrib_parser.add_argument("--category", default="delivered",
                                choices=["delivered", "risk", "efficiency", "progress"],
                                help="贡献类型")
    contrib_parser.add_argument("--impact", default="", help="影响/成果")
    
    # 列表命令
    list_parser = subparsers.add_parser("list", help="列出可用选项")
    list_parser.add_argument("--type", choices=["boss", "message"], required=True, help="列表类型")
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
    
    manager = UpwardManager()
    
    if args.command == "report":
        result = manager.generate_report(args.tasks, args.boss_type)
        print("\n" + result["template"])
        print("\n💡 提示：")
        for tip in result["tips"]:
            print(f"  • {tip}")
    
    elif args.command == "decode":
        result = manager.decode_instruction(args.message)
        if result["status"] == "已识别":
            print(f"\n🔍 识别到指令：【{result['original']}】")
            print("\n可能含义：")
            for i, meaning in enumerate(result["possible_meanings"], 1):
                print(f"  {i}. {meaning}")
            print(f"\n📋 应对策略：{result['strategy']}")
            print(f"\n💬 确认话术：{result['confirm_template']}")
            print(f"\n⚠️ {result['risk_warning']}")
        else:
            print(f"\n❌ {result['suggestion']}")
    
    elif args.command == "persuade":
        result = manager.generate_persuade_script(args.need, args.pain, args.benefit)
        print("\n" + result["script"])
        print("\n✅ 检查清单：")
        for item in result["checklist"]:
            print(f"  {item}")
    
    elif args.command == "expect":
        result = manager.analyze_expectation(args.expectation, args.reality)
        print(f"\n📊 分析结果：{result['gap_analysis']}")
        print(f"📋 推荐策略：{result['strategy']}")
        print(f"\n💬 话术参考：")
        for i, script in enumerate(result["scripts"], 1):
            print(f"  {i}. {script}")
        print(f"\n🔑 核心公式：{result['key_formula']}")
        print(f"⚠️ 避免：{result['warning']}")
    
    elif args.command == "timing":
        result = manager.get_timing_advice(args.message_type)
        print(f"\n📅 【{result['message_type']}】最佳沟通时机")
        print(f"\n✅ 最佳时机：{result['best_timing']}")
        print(f"○ 可接受：{result['acceptable_timing']}")
        print(f"❌ 避免时机：{result['avoid_timing']}")
        print("\n💡 提示：")
        for tip in result["tips"]:
            print(f"  • {tip}")
    
    elif args.command == "contribution":
        if args.action == "add":
            if not args.item:
                print("❌ 请使用 --item 指定贡献内容")
                return
            result = manager.add_contribution(args.item, args.category, args.impact)
            print(f"✅ {result['message']}")
        else:
            result = manager.get_contribution_report()
            print("\n" + result["report"])
    
    elif args.command == "list":
        if args.type == "boss":
            result = manager.list_boss_types()
            print("\n📋 老板类型列表：")
            for key, info in result["boss_types"].items():
                print(f"\n  {key}: {info['name']}")
                print(f"    特征：{info['traits']}")
                print(f"    策略：{info['strategy']}")
            print(f"\n{result['usage']}")
        else:
            result = manager.list_message_types()
            print("\n📋 消息类型列表：")
            for key, name in result["message_types"].items():
                print(f"  {key}: {name}")
            print(f"\n{result['usage']}")


if __name__ == "__main__":
    main()
