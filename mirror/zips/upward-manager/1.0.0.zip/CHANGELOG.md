# 更新日志

## [1.0.0] - 2026-04-20

### 新增功能

- ✨ 汇报策略生成器：根据老板类型生成汇报结构和话术
- ✨ 指令解码器：解码老板模糊指令，给出确认话术
- ✨ 资源争取话术生成：四步说服法生成资源申请话术
- ✨ 预期管理分析：分析预期差距，给出管理策略
- ✨ 沟通时机建议：不同消息类型的最佳沟通时机
- ✨ 贡献记录管理：记录和生成贡献清单

### 文档

- 📝 完整 SKILL.md 技能文档
- 📝 简洁 README.md 对外简介
- 📝 汇报模板库（多场景、多老板类型）
- 📝 话术模板库（确认、拒绝、争取、坏消息等）
- 📝 向上管理心法参考文档

### 脚本

- 🔧 upward.py 主脚本，支持命令行操作

---

## 核心命令

```bash
# 生成汇报策略
python upward.py report --tasks "任务1" "任务2" --boss-type result

# 解码模糊指令
python upward.py decode --message "你看着办"

# 生成资源争取话术
python upward.py persuade --need "招人" --pain "人力不足" --benefit "效率提升30%"

# 分析预期差距
python upward.py expect --expectation "一周完成" --reality "需要两周"

# 获取沟通时机建议
python upward.py timing --message-type good_news

# 管理贡献记录
python upward.py contribution --add --item "完成xxx功能" --category delivered --impact "提升用户体验"

# 查看贡献报告
python upward.py contribution --report
```
