#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
同城获客短视频文案生成器 - 核心引擎
支持本地独立运行，也可作为模块被调用

用法示例（本地测试）：
    python generate_copy.py
    python generate_copy.py --profile restaurant_bbq_basic --name "老李烧烤" --region "杭州萧山" --years "3年" --scene daily
    python generate_copy.py --profile restaurant_cafe --name "阳光咖啡" --region "成都锦江" --years "2年" --scene new_product --extra "燕麦拿铁"
    python generate_copy.py --profile retail_clothing --name "小美服装" --region "广州天河" --years "5年" --scene promotion --extra "店庆充值送"
"""

import json
import argparse
from datetime import datetime
from typing import Dict, List, Any, Optional


# ============================================================
# 内置数据（与 references/profiles.md 和 strategies.md 对应）
# ============================================================

PROFILES: List[Dict[str, Any]] = [
    {
        "id": "restaurant_bbq_basic",
        "name": "烧烤店",
        "desc": "适用于各类烧烤、烤肉门店",
        "selling_points": [
            {"key": "口碑好", "example": "吃过我们家烧烤的99%都是好评。"},
            {"key": "味道好", "example": "很多来咱家的客人啊，都说为了这口烧烤愿意来100次。"},
            {"key": "性价比", "example": "在我们这里只需要花费三分之二的价格就可以吃上别人家同等价位的烧烤。"},
            {"key": "食材鲜", "example": "羊肉现切现穿，每天从内蒙冷链直达，现烤现卖保证滋滋冒油。"}
        ]
    },
    {
        "id": "restaurant_cafe",
        "name": "咖啡馆",
        "desc": "适用于独立咖啡馆、连锁咖啡店",
        "selling_points": [
            {"key": "环境好", "example": "店里每个角落都适合拍照，是很多小姐姐的打卡圣地。"},
            {"key": "豆子好", "example": "咖啡豆都是自家烘焙，冠军豆子，风味独特。"},
            {"key": "性价比", "example": "一杯拿铁才20出头，用的还是鲜牛奶。"}
        ]
    },
    {
        "id": "retail_clothing",
        "name": "服装店",
        "desc": "适用于女装、男装、童装实体店",
        "selling_points": [
            {"key": "款式好", "example": "款式都是店主每周飞广州、杭州亲自挑的，不撞衫。"},
            {"key": "质量好", "example": "面料摸得到，做工看得见，穿几年都不变形。"},
            {"key": "性价比", "example": "商场同品质，我这里至少便宜三分之一。"}
        ]
    },
    {
        "id": "restaurant_hotpot",
        "name": "火锅/中餐厅",
        "desc": "适用于火锅店、家常菜馆",
        "selling_points": [
            {"key": "食材鲜", "example": "所有食材每天早市现采，不过夜，新鲜才敢卖。"},
            {"key": "口味正", "example": "祖传配方，在这条街开了15年，老顾客都是带着孩子来的。"},
            {"key": "环境好", "example": "包间够大，聚会没有拘束，停车也方便。"}
        ]
    },
    {
        "id": "beauty_salon",
        "name": "美容/美发",
        "desc": "适用于美发、美甲、美容院",
        "selling_points": [
            {"key": "技术好", "example": "师傅都在一线城市进修回来的，手法特别稳。"},
            {"key": "产品好", "example": "用的都是大牌正品，绝不用杂牌货。"},
            {"key": "服务好", "example": "每次来都有专属记录，不用重复交代你的需求。"}
        ]
    }
]

STRATEGIES: List[Dict[str, Any]] = [
    {
        "id": "daily",
        "name": "日常引流",
        "desc": "常规营业日吸引顾客到店",
        "shooting_hint": "拍摄店内实景、产品特写、顾客用餐/消费场景",
        "hashtags": ["#同城美食", "#宝藏店铺", "#今天吃什么"]
    },
    {
        "id": "new_product",
        "name": "新品推广",
        "desc": "重点推广新上市的产品或服务",
        "shooting_hint": "重点拍摄新品特写、制作过程、顾客首次体验反应",
        "hashtags": ["#新品上市", "#尝鲜", "#美食探店"]
    },
    {
        "id": "promotion",
        "name": "活动促销",
        "desc": "配合店庆、节日、会员日等促销活动",
        "shooting_hint": "拍摄活动海报、优惠价签、排队盛况，营造紧迫感",
        "hashtags": ["#限时优惠", "#店庆活动", "#羊毛福利"]
    }
]


# ============================================================
# 文案生成引擎
# ============================================================

class VideoCopyEngine:
    """同城获客短视频文案生成引擎"""

    def __init__(self, api_key: Optional[str] = None, contact_info: Optional[Dict[str, str]] = None):
        self.api_key = api_key
        self.profiles = PROFILES
        self.strategies = STRATEGIES
        # 用户会话状态（对话模式时使用）
        self.user_sessions: Dict[str, Dict] = {}
        # 联系方式（用于文案底部）
        self.contact_info = contact_info or {}
        # 授权状态
        self.authorized_sessions: Dict[str, bool] = {}

    # ----------------------------------------------------------
    # 授权相关方法
    # ----------------------------------------------------------

    def _auth_required_message(self) -> str:
        """返回授权确认提示"""
        return """⚠️ 使用前请先确认授权

请回复【同意】或【开始建档】继续使用。

了解以下内容：
• 您的店铺信息仅用于生成同城短视频文案
• 文案内容严格遵循平台合规规范
• 可支持10个行业：餐饮、鞋服、美容美发、汽修、便利店、装修、建材、教育培训、牙科、实体工厂
"""

    def _welcome_after_auth(self, user_id: str) -> str:
        """授权通过后的欢迎消息"""
        return """✅ 授权确认成功！欢迎使用同城获客文案生成器

请先建立您的店铺档案，只需选择类型并告诉我：
1. 您的店铺名称
2. 所在城市/区域
3. 开了多久

或者直接告诉我您的需求，比如：
「帮我写一条杭州烧烤店的抖音文案」
"""
        """处理对话指令（企业微信/命令行对话模式）"""
        session = self.user_sessions.get(user_id, {})

        # 授权确认拦截
        if not self.authorized_sessions.get(user_id, False):
            if command in ("同意", "开始建档", "开始", "确认"):
                self.authorized_sessions[user_id] = True
                return self._welcome_after_auth(user_id)
            return self._auth_required_message()

        # 首次建档
        if "写文案" in command:
            if not session:
                self.user_sessions[user_id] = {"step": "choose_profile"}
                return self._profile_menu()
            return "您已有档案，可直接说：\n• 老样子（日常引流）\n• 推新品 [产品名]\n• 做活动 [活动描述]"

        # 建档流程
        if session.get("step") == "choose_profile":
            return self._handle_choose_profile(user_id, command, session)
        if session.get("step") == "ask_name":
            session["store_name"] = command
            session["step"] = "ask_region"
            return "店铺开在哪个城市哪个区？（如：杭州萧山）"
        if session.get("step") == "ask_region":
            session["store_region"] = command
            session["step"] = "ask_years"
            return "开了多久了？（如：3年老店）"
        if session.get("step") == "ask_years":
            session["years"] = command
            session["step"] = "complete"
            session["profile_id"] = session.get("selected_profile", "restaurant_bbq_basic")
            return (
                f"✅ 建档完成！\n"
                f"店名：{session['store_name']}\n"
                f"位置：{session['store_region']}\n"
                f"类型：{self._get_profile_name(session['profile_id'])}\n\n"
                f"现在可以说：\n"
                f"1. 老样子（日常3条文案）\n"
                f"2. 推新品 小龙虾\n"
                f"3. 做活动 充值100送50"
            )

        # 文案生成
        if "老样子" in command and session.get("step") == "complete":
            return self.generate_copy(session, "daily")
        if "推新品" in command and session.get("step") == "complete":
            extra = command.replace("推新品", "").strip()
            return self.generate_copy(session, "new_product", extra_input=extra)
        if "做活动" in command and session.get("step") == "complete":
            extra = command.replace("做活动", "").strip()
            return self.generate_copy(session, "promotion", extra_input=extra)

        # 默认帮助
        return (
            "请发送：\n"
            "1. 写文案（首次使用，建立档案）\n"
            "2. 老样子（日常引流文案）\n"
            "3. 推新品 XXX（新品推广）\n"
            "4. 做活动 XXX（促销活动）"
        )

    # ----------------------------------------------------------
    # 直接生成模式入口（无需对话建档）
    # ----------------------------------------------------------

    def generate_copy(
        self,
        store_info: Dict[str, Any],
        scene: str = "daily",
        extra_input: str = ""
    ) -> str:
        """
        直接生成文案（无需对话建档）

        参数：
            store_info: 包含 profile_id/store_name/store_region/years 的字典
            scene: 'daily' | 'new_product' | 'promotion'
            extra_input: 新品名称或活动描述
        """
        prompt = self._build_prompt(store_info, scene, extra_input)
        ai_text = self._call_ai(prompt)
        return self._format_output(ai_text, scene, store_info)

    # ----------------------------------------------------------
    # 内部方法
    # ----------------------------------------------------------

    def _profile_menu(self) -> str:
        lines = ["请选择您的店铺类型（回复编号）："]
        for i, p in enumerate(self.profiles, 1):
            lines.append(f"{i}. {p['name']} — {p['desc']}")
        return "\n".join(lines)

    def _handle_choose_profile(self, user_id: str, choice: str, session: Dict) -> str:
        try:
            idx = int(choice.strip()) - 1
            if 0 <= idx < len(self.profiles):
                selected = self.profiles[idx]
                session["selected_profile"] = selected["id"]
                session["step"] = "ask_name"
                return f"已选择：{selected['name']}\n请告诉我您的店铺名称？"
            return "编号无效，请重新选择（输入1-5的数字）。"
        except ValueError:
            return "请输入有效的编号（数字）。"

    def _get_profile_name(self, profile_id: str) -> str:
        p = next((x for x in self.profiles if x["id"] == profile_id), None)
        return p["name"] if p else "未知类型"

    def _build_prompt(self, store_info: Dict, scene: str, extra_input: str) -> str:
        """组装AI提示词"""
        profile = next(
            (p for p in self.profiles if p["id"] == store_info.get("profile_id")),
            self.profiles[0]
        )
        selling_points = "; ".join(
            sp["example"] for sp in profile["selling_points"][:3]
        )

        prompt = f"""请严格遵循"标签文案、广告文案、行动文案"三段式完整结构。
结合我的身份背景和产品卖点：
- 身份背景：我是一家{profile['name']}的老板，门店开在{store_info.get('store_region', '本地')}，开了{store_info.get('years', '多年')}。
- 产品卖点：{selling_points}
"""
        if scene == "new_product" and extra_input:
            prompt += f"\n今天重点推荐新品：{extra_input}，请围绕它创作。"
        elif scene == "promotion" and extra_input:
            prompt += f"\n今天有活动：{extra_input}，请突出活动的限时和优惠。"

        prompt += f"""
为我创作出3条短视频文案，每条100字左右。
文案目标是吸引更多{store_info.get('store_region', '本地')}的客户刷到视频，来我家消费。
要求文案口语化、真实亲切，并严格避免使用"最"、"第一"、"根治"、"保证"等绝对化或承诺性违规词汇。
"""
        return prompt

    def _call_ai(self, prompt: str) -> str:
        """调用AI API生成文案（默认使用DeepSeek）"""
        if not self.api_key:
            # 无API Key时返回模拟输出（用于测试）
            return self._mock_output(prompt)

        try:
            import requests
            url = "https://api.deepseek.com/chat/completions"
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
            data = {
                "model": "deepseek-chat",
                "messages": [{"role": "user", "content": prompt}],
                "stream": False
            }
            resp = requests.post(url, json=data, headers=headers, timeout=30)
            result = resp.json()
            return result.get("choices", [{}])[0].get("message", {}).get("content", "AI生成失败，请重试。")
        except ImportError:
            return "提示：requests库未安装，请运行 pip install requests\n\n" + self._mock_output(prompt)
        except Exception as e:
            return f"调用AI服务出错：{e}"

    def _mock_output(self, prompt: str) -> str:
        """模拟AI输出（无API Key时的测试数据）"""
        return """【文案1 - 日常引流款】
在外面吃了那么多，还是觉得咱家这口最对味。
不信你来试试，老顾客都是一来再来的那种，
不是因为别的，就是踏实、好吃、不贵。
📍地址：[店铺位置]，营业时间：[时间]，欢迎预约！

【文案2 - 情感共鸣款】
开店这几年，见过太多来了又来的老面孔。
他们说，不用想太多，就想吃这口熟悉的味道。
这就是我们一直坚持做好食材、认真做口味的原因。
来吧，这里永远有一个位子留着你。

【文案3 - 直接促单款】
不骗你，这家店真的藏在巷子里，
但每天人还不少，全靠口碑撑着。
现在来报我的账号名，直接享受专属优惠！
名额有限，今天就来～"""

    def _format_output(self, ai_text: str, scene: str, store_info: Dict) -> str:
        """格式化最终输出，包含联系方式"""
        strategy = next((s for s in self.strategies if s["id"] == scene), self.strategies[0])
        store_name = store_info.get("store_name", "您的店铺")
        tags = " ".join(strategy.get("hashtags", ["#同城推广", "#宝藏店铺"]))

        # 联系方式部分
        contact_lines = []
        if self.contact_info:
            if self.contact_info.get("wechat"):
                contact_lines.append(f"📱 微信：{self.contact_info['wechat']}")
            if self.contact_info.get("phone"):
                contact_lines.append(f"📞 电话：{self.contact_info['phone']}")
            if self.contact_info.get("address"):
                contact_lines.append(f"📍 地址：{self.contact_info['address']}")

        contact_block = ""
        if contact_lines:
            contact_block = f"{'─' * 30}\n" + "\n".join(contact_lines) + "\n"

        return (
            f"\n【文案生成 | {datetime.now().strftime('%m-%d %H:%M')}】\n"
            f"🏪 店铺：{store_name}\n"
            f"🎯 场景：{strategy['name']}\n"
            f"📹 拍摄建议：{strategy['shooting_hint']}\n"
            f"{'─' * 30}\n"
            f"{ai_text}\n"
            f"{'─' * 30}\n"
            f"🏷️ 推荐话题：{tags}\n"
            f"{contact_block}"
        )


# ============================================================
# 命令行入口
# ============================================================

def parse_args():
    parser = argparse.ArgumentParser(
        description="同城获客短视频文案生成器",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""示例：
  python generate_copy.py
  python generate_copy.py --profile restaurant_bbq_basic --name "老李烧烤" --region "杭州萧山" --years "3年" --scene daily
  python generate_copy.py --profile restaurant_cafe --name "阳光咖啡" --region "成都锦江" --years "2年" --scene new_product --extra "燕麦拿铁"
  python generate_copy.py --profile restaurant_bbq_basic --name "老李烧烤" --region "杭州萧山" --years "3年" --scene daily --contact "config/contact.json"
        """
    )
    parser.add_argument("--profile", default="restaurant_bbq_basic",
                        choices=["restaurant_bbq_basic", "restaurant_cafe", "retail_clothing",
                                 "restaurant_hotpot", "beauty_salon"],
                        help="店铺类型ID（默认：restaurant_bbq_basic）")
    parser.add_argument("--name", default="测试门店", help="店铺名称")
    parser.add_argument("--region", default="上海浦东", help="所在城市+区域")
    parser.add_argument("--years", default="3年", help="经营年限")
    parser.add_argument("--scene", default="daily",
                        choices=["daily", "new_product", "promotion"],
                        help="文案场景（默认：daily）")
    parser.add_argument("--extra", default="", help="新品名称或活动描述（new_product/promotion场景使用）")
    parser.add_argument("--api-key", default="", help="AI API密钥（可选，不填则使用模拟输出）")
    parser.add_argument("--contact", default="", help="联系方式配置文件路径（JSON格式，如：config/contact.json）")
    return parser.parse_args()


def interactive_demo():
    """交互式对话演示"""
    print("=" * 50)
    print("  同城获客短视频文案生成器 - 对话演示")
    print("=" * 50)
    print("输入指令开始，输入 'quit' 退出\n")

    engine = VideoCopyEngine()
    user_id = "demo_user"

    while True:
        try:
            cmd = input("你: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n已退出。")
            break

        if not cmd:
            continue
        if cmd.lower() in ("quit", "exit", "退出"):
            print("再见！")
            break

        response = engine.handle_command(user_id, cmd)
        print(f"\n助手:\n{response}\n")


def main():
    import sys

    # 无参数时进入交互演示
    if len(sys.argv) == 1:
        interactive_demo()
        return

    args = parse_args()

    # 加载联系方式配置
    contact_info = {}
    if args.contact:
        try:
            with open(args.contact, "r", encoding="utf-8") as f:
                contact_info = json.load(f)
            print(f"\n✅ 已加载联系方式配置：{args.contact}")
        except Exception as e:
            print(f"\n⚠️ 联系方式配置加载失败：{e}，将不显示联系方式")

    print("\n正在生成文案...\n")
    engine = VideoCopyEngine(api_key=args.api_key or None, contact_info=contact_info)

    store_info = {
        "profile_id": args.profile,
        "store_name": args.name,
        "store_region": args.region,
        "years": args.years
    }

    result = engine.generate_copy(store_info, args.scene, args.extra)
    print(result)


if __name__ == "__main__":
    main()
