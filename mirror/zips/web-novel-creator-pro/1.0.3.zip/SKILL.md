---
name: web-novel-creator
version: 2.0.0
description: |
  Web Novel Creation coordination layer for OpenClaw.
  Serves as the unified bridge between novel creation Skills (novel-generator, open-novel-writing, novel-orchestrator)
  and Memory Manager Pro's indexing system.
  Use when: A novel creation Skill has finished chapters and needs archiving, index updates, or coordination for next steps.
  Triggers on: "网文创作", "继续创作", "小说归档", "更新小说索引", "完成章节更新索引".
---

# Web Novel Creator v2.0

网文创作兼容协调层。作为 **novel-generator**、**open-novel-writing**、**novel-orchestrator** 等创作 Skill 与 **Memory Manager Pro** 索引系统之间的统一桥梁。

## 核心定位

```
┌─────────────────────────────────────────────────────────────────┐
│                    Web Novel Creator v2.0                       │
│                     （网文创作协调层）                           │
│                                                                 │
│  职责：                                                         │
│  1. 统一项目目录规范                                             │
│  2. 检测外部 Skill 创作完成                                      │
│  3. 归档产出到标准位置                                           │
│  4. 调用 Memory Manager Pro 更新索引（V2.0统一接口）            │
└─────────────────────────────────────────────────────────────────┘
                              ▲
          ┌───────────────────┼───────────────────┐
          │                   │                   │
   ┌─────────────┐    ┌─────────────┐    ┌─────────────┐
   │novel-generator│   │open-novel-  │   │novel-       │
   │  （创作引擎） │   │  writing    │   │orchestrator │
   │              │   │（设定管理） │   │（协作流程） │
   └─────────────┘    └─────────────┘    └─────────────┘
          │                   │                   │
          └───────────────────┴───────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    Memory Manager Pro v2.0                      │
│                   （8步索引更新流程）                            │
└─────────────────────────────────────────────────────────────────┘
```

## 统一目录规范（V2.0）

所有兼容的创作 Skill 必须遵循以下目录结构：

```
novel/{项目名}/
├── 正文/                    # 章节正文（必须）
│   ├── 第001章.md
│   └── 第XXX章.md
├── 规划/                    # 章节规划（必须）
│   ├── 已用标题库.md        # 标题去重库
│   ├── 第XXX章规划.md       # 单章规划
│   └── 规划模板.md          # 标准模板
├── 设定/                    # 世界观/人设（可选）
│   ├── 世界观.md
│   └── 人物/
├── 总纲/                    # 故事总纲（可选）
│   └── 故事总纲.md
├── .learnings/              # 记忆系统（novel-generator使用）
│   ├── CHARACTERS.md
│   ├── LOCATIONS.md
│   └── PLOT_POINTS.md
└── output/                  # 临时输出（创作中）
```

## 核心工作流程

### 阶段1：检测创作完成

```
检测标识文件/目录：
├── .learnings/ → novel-generator 完成
├── 设定/世界观.md → open-novel-writing 完成
├── references/agent-setup.md → novel-orchestrator 完成
└── 总纲/故事总纲.md → cq-novel-writer 完成
```

### 阶段2：归档产出

```
1. 将 output/ 中的正文迁移到 正文/
2. 检查 规划/ 中是否有对应规划文件
3. 检查并更新 已用标题库.md
4. 生成下一章规划（如需要）
```

### 阶段3：调用 Memory Manager Pro（V2.0统一接口）

**所有小说创作任务完成后，统一调用 Memory Manager Pro：**

```json
{
  "操作": "完成任务并更新索引",
  "任务ID": "TASK_NOVEL_YYYYMMDD_XXX",
  "项目": "天道养殖场",
  "成果摘要": "第XXX章《标题》：XXXX字",
  "创建下一任务": true,
  "下一任务信息": {
    "任务ID": "TASK_NOVEL_YYYYMMDD_XXX+1",
    "标题": "第XXX+1章《标题》创作",
    "内容": "预估字数XXXX字"
  }
}
```

**Memory Manager Pro 自动执行8步索引更新：**
1. 更新任务详情（标记已完成）
2. 更新已完成任务索引
3. 更新活跃任务索引
4. 更新小说项目索引
5. 更新创作类类型索引
6. 更新 MEMORY.md
7. 更新核心索引
8. 更新关键词映射

## 对接外部 Skill 详细规范

### 对接 novel-generator

**检测标识：** `.learnings/` 目录存在

**归档流程：**
```
1. 检测 output/ 目录中的章节文件
2. 重命名为 第XXX章.md 格式
3. 迁移到 novel/{项目名}/正文/
4. 更新 已用标题库.md
5. 调用 Memory Manager Pro 更新索引
```

**调用参数示例：**
```json
{
  "操作": "完成任务并更新索引",
  "任务ID": "TASK_NOVEL_20260429_001",
  "项目": "天道养殖场",
  "成果摘要": "第121-130章批量创作：10章约2.1万字",
  "创建下一任务": true,
  "下一任务信息": {
    "任务ID": "TASK_NOVEL_20260429_002",
    "标题": "第131-140章批量创作",
    "内容": "延续界域之战剧情线"
  }
}
```

### 对接 open-novel-writing

**检测标识：** `设定/世界观.md` 文件存在

**归档流程：**
```
1. 确认目录结构符合规范
2. 检查 正文/ 目录中的新章节
3. 更新 已用标题库.md（如未更新）
4. 调用 Memory Manager Pro 更新索引
```

### 对接 novel-orchestrator

**检测标识：** `references/agent-setup.md` 存在

**归档流程：**
```
1. 检测 checker 的通过记录
2. 确认 writer 产出的章节
3. 更新 已用标题库.md
4. 调用 Memory Manager Pro 更新索引
```

### 对接 cq-novel-writer

**检测标识：** `总纲/故事总纲.md` 文件存在

**归档流程：**
```
1. 将根目录下的正文文件迁移到 正文/
2. 重命名为 第XXX章.md 格式
3. 调用 Memory Manager Pro 更新索引
```

## 标题去重检验

无论使用哪个外部 Skill 创作，都必须通过标题库去重检验：

**标题库位置：** `novel/{项目名}/规划/已用标题库.md`

**检验流程：**
```
1. 提取新章节标题
2. 查重：与已用标题库对比
3. 如重复 → 提示修改
4. 如不重复 → 录入标题库
5. 继续后续流程
```

## 规划预生成

当外部 Skill 未生成下一章规划时，Web Novel Creator 自动补充：

**存储位置：** `novel/{项目名}/规划/第XXX+1章规划.md`

**规划内容模板：**
```markdown
# 第XXX+1章《待定标题》规划

## 核心冲突
...

## 剧情要点
1. ...
2. ...

## 字数目标
XXXX字

## 伏笔设置
- 前置伏笔：...
- 本章节伏笔：...
```

## 与 Memory Manager Pro 的协作规范

### 调用时机

**必须在以下操作完成后调用：**
1. ✅ 正文已归档到 正文/ 目录
2. ✅ 标题已录入 已用标题库.md
3. ✅ 规划文件已确认（如适用）
4. ✅ 下一章规划已生成（如需要）

### 调用参数

**必须使用 V2.0 统一接口格式：**

```json
{
  "操作": "完成任务并更新索引",
  "任务ID": "TASK_NOVEL_{YYYYMMDD}_{SEQ}",
  "项目": "项目名称",
  "成果摘要": "第XXX章《标题》：XXXX字",
  "创建下一任务": true/false,
  "下一任务信息": {...}
}
```

**禁止行为：**
- ❌ 不要直接编辑索引文件
- ❌ 不要使用旧版接口格式
- ❌ 不要遗漏必填参数

## 兼容检测模板

```markdown
# .skill-detect

当 web-novel-creator 被调用时，按以下优先级检测：

| 优先级 | 标识文件/目录 | 对应的 Skill | 检测方式 |
|--------|--------------|-------------|---------|
| 1 | references/agent-setup.md | novel-orchestrator | 文件是否存在 |
| 2 | .learnings/ | novel-generator | 目录是否存在 |
| 3 | 设定/世界观.md | open-novel-writing | 文件是否存在 |
| 4 | 总纲/故事总纲.md | cq-novel-writer | 文件是否存在 |
| 5 | 无检测结果 | fallback | 使用内置创作 |
```

## 使用示例

### 示例1：novel-generator 完成创作后归档

```
用户: "天道养殖场第121-130章已创作完成，请归档"

系统:
1. 检测 .learnings/ 目录存在 → 识别为 novel-generator 产出
2. 检测 output/ 中的章节文件
3. 迁移到 novel/天道养殖场/正文/（第121-130章.md）
4. 更新 已用标题库.md（录入10个新标题）
5. 调用 Memory Manager Pro:
   {
     "操作": "完成任务并更新索引",
     "任务ID": "TASK_NOVEL_20260429_001",
     "项目": "天道养殖场",
     "成果摘要": "第121-130章批量创作：10章约2.1万字",
     "创建下一任务": true,
     "下一任务信息": {...}
   }
6. Memory Manager Pro 执行8步索引更新
7. 返回: 归档完成，索引已更新
```

### 示例2：初始化新项目

```
用户: "创建新小说项目《星际征途》"

系统:
1. 创建目录结构
2. 初始化 已用标题库.md
3. 调用 Memory Manager Pro 初始化项目索引
4. 返回: 项目已创建，可以开始创作
```

## 版本历史

### v2.0.0 (2026-04-29)
- ✅ 更新为 Memory Manager Pro v2.0 统一接口
- ✅ 明确8步索引更新流程调用规范
- ✅ 优化与4种外部 Skill 的对接流程
- ✅ 新增标题去重检验强制要求
- ✅ 新增规划预生成规范

### v1.0.0 (2026-04-26)
- 初始版本
- 支持统一目录规范
- 支持基础索引归档

## 设计原则

1. **不重复造轮子** - 不自建创作引擎，依赖专业 Skill
2. **统一规范** - 所有 Skill 共享同一目录结构
3. **标准接口** - 统一调用 Memory Manager Pro v2.0 接口
4. **完整归档** - 正文、标题、规划必须全部更新
5. **无缝衔接** - 创作完成→归档→索引更新→下一章规划，全流程自动化
