# Web Novel Creator v2.0

网文创作兼容协调层 Skill for OpenClaw。

## 功能特性

- ✅ **统一目录规范**：所有创作 Skill 共享同一项目结构
- ✅ **多 Skill 对接**：支持 novel-generator / open-novel-writing / novel-orchestrator / cq-novel-writer
- ✅ **自动归档**：创作完成后自动归档正文、更新标题库
- ✅ **标准索引接口**：统一调用 Memory Manager Pro v2.0

## 目录规范

```
novel/{项目名}/
├── 正文/           # 章节正文
├── 规划/           # 章节规划 + 已用标题库
├── 设定/           # 世界观/人设（可选）
├── 总纲/           # 故事总纲（可选）
├── .learnings/     # 记忆系统
└── output/         # 临时输出
```

## 对接流程

1. 检测外部 Skill 创作完成（通过标识文件）
2. 归档产出到标准目录
3. 更新已用标题库
4. 调用 Memory Manager Pro 更新索引

## 调用示例

```json
{
  "操作": "完成任务并更新索引",
  "任务ID": "TASK_NOVEL_20260426_001",
  "项目": "天道养殖场",
  "成果摘要": "第091章《第七层觉醒》：2833字",
  "创建下一任务": true,
  "下一任务信息": {...}
}
```

## 版本历史

- **v2.0.0** (2026-04-29): 更新为 Memory Manager Pro v2.0 接口
- **v1.0.0** (2026-04-26): 初始版本

## 许可证

MIT
