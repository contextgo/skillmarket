# Store Metadata

    ## Listing identity
    - **Display name:** Collaborative Resource Orchestrator
    - **Slug:** `collaborative-resource-orchestrator`
    - **Category:** editorial-planning
    - **Short description:** Map the collaborators and resources a topic actually needs.
    - **One-line positioning:** Identify essential, strengthening, and shape-determining resources so editors can tell whether a plan is truly executable.

    ## Suggested tags
    - `editorial-planning`
- `resource-mapping`
- `coordination`
- `feasibility`
- `collaboration`
- `execution`

    ## Best-fit queries
    - What resources and collaborators does this topic need?
- Show me the shape-determining resources for this package.
- Can this plan still work if we do not get local archive access?

    ## Core use cases
    - Map essential versus optional resources
- Identify resource gaps before production
- Design a minimum viable resource setup

    ## README intro block
    > Collaborative Resource Orchestrator helps editorial teams and planning agents solve one specific planning problem with repeatable structure, output patterns, and reference materials. It is best used as one module inside a larger editorial planning system.

    ## Publish notes
    - Keep this skill listed separately rather than bundling it with all six skills.
    - Use a concise changelog line such as `Initial public release` or `Improved trigger wording and examples`.
    - Keep the public listing focused on the problem it solves, not the full six-skill architecture.
    - Recommended audience: editorial strategists, newsroom innovation teams, international communication planners, and multi-agent OpenClaw builders.
