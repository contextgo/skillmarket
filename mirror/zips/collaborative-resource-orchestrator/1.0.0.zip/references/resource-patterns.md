# Resource Patterns

## Core distinction
Always separate:
- resources the topic needs
- resources that shape what form the topic can take
- resources that only strengthen an already viable plan

## Common resource categories
- editorial resources
- reporting resources
- evidence resources
- archive and historical resources
- interview resources
- visual resources
- coordination resources
- platform resources

## Shape-determining resource signals
A resource is shape-determining when losing it changes the topic itself.
Examples:
- no source-point access -> topic may lose anchor status
- no visual proof -> package may need to become text-led
- no archive support -> continuity claim weakens
- no key witness -> story may shift from lived memory to institutional explanation

## Strong resource structure
- clear essential set
- clear optional set
- fallback structure exists
- collaboration dependencies visible
- topic-shape consequences named
