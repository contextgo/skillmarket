# Resource Output Template

### Topic Spine
Restate the topic in one to three sentences.

### Resource Logic
Explain what the topic must prove, show, and coordinate.

### Resource Categories
Break resources into editorial, reporting, evidence and archive, interview and relationship, visual and production, coordination and partners, and platform and distribution.

### Shape-Determining Resources
List the resources that determine what kind of story or package is possible.

### Collaboration Map
For each collaborator, specify role, contribution, essentiality, and coordination risk.

### Essential vs Strengthening Resources
Separate must-have resources from high-value but non-essential resources.

### Resource Gaps
List missing or uncertain resources and their impact.

### Minimum Viable Resource Configuration
Describe the smallest resource setup that still preserves the topic spine.

### Topic-Shape Consequences
Explain how the topic or package must change if specific resources are unavailable.

### Final Resource Verdict
Choose one clear verdict and explain why.
