---
name: collaborative-resource-orchestrator
description: map, prioritize, and coordinate the editorial, reporting, evidence, partner, and platform resources required for major-theme topic planning in international communication. use when chatgpt needs to determine what resources a topic requires, which resources shape the possible reporting form, what collaboration structure is needed, and how to reduce execution risk caused by missing access, weak evidence, or poor coordination.
---

# Collaborative Resource Orchestrator

Map and coordinate the resources required to make a major-theme editorial plan actually executable.

This skill is for planning resource architecture, not generic project management.

## Core task
Given a topic plan, communication objective, and rough organizational context, produce a resource orchestration plan that answers:
- what resources are essential to make this topic credible and executable?
- which resources determine the reporting form, not just support it?
- which internal and external collaborators should be involved?
- what minimum viable resource configuration can still preserve topic quality?

## Method

### 1. Restate the topic as an execution problem
Convert the topic into an execution-oriented question: what must be seen, verified, accessed, explained, and coordinated?

### 2. Separate resource types
Use categories such as editorial, reporting, evidence, archives, interviews, visual production, local coordination, platform distribution, and review/risk-control.

### 3. Distinguish support resources from shape-determining resources
Some resources only help execution. Others determine what kind of story is even possible.

### 4. Map the collaboration structure
For each collaborator, define why they matter, what they contribute, whether they are essential, and what risk they introduce.

### 5. Identify resource gaps and fallback shapes
Always produce an ideal resource map, a minimum viable resource map, and the topic-shape consequences of missing resources.

### 6. Output a resource orchestration plan
Use `references/resource-output-template.md` and the prioritization logic in `references/resource-patterns.md`.

## Boundary
This skill is for resource architecture, collaboration mapping, feasibility planning, and fallback design. It is not for detailed budgets, procurement, or full project management schedules.
