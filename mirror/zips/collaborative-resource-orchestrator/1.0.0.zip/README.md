# Collaborative Resource Orchestrator

Map collaborators, dependencies, and fallback resource plans.

## Included files
- SKILL.md
- agents/openai.yaml
- references/
- MANIFEST.yaml
- CHANGELOG.md
- _meta.json

## Install notes
This bundle is packaged as a standard ZIP with a top-level `collaborative-resource-orchestrator/` directory so it can be imported by skill installers that expect one skill per archive.
