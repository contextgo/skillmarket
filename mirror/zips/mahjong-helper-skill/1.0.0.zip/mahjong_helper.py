import re
from collections import Counter

HAS_IMAGE_SUPPORT = False
try:
    from PIL import Image
    import pytesseract
    HAS_IMAGE_SUPPORT = True
except:
    pass

SUPPORTED_RULES = [
    "通用", "四川", "广东", "杭州", "长沙",
    "东北", "上海", "武汉", "温州", "陕西",
    "苏州", "安徽"
]

MAHJONG_TIPS = {
    "通用": {
        "基础技巧": ["孤张字牌最先打，留着没用易点炮","中张牌价值最高，3-7尽量不要扔","对子不拆是基本，搭子够了再优化","先打熟张后生张，听牌不追险张"],
        "实战口诀": ["搭子够，拆孤张；搭子少，留边张","三对拆一对，听牌快一倍","早听早胡不贪大，晚听大牌易点炮","牌差就跑，牌好再飘","别人打啥你打啥，卡住下家最稳妥","听牌不单调，能胡两面胡"]
    },
    "四川": {
        "基础技巧": ["开局定缺看花色，越少越先打","缺门之后坚决不留该花色","清一色收益最高，能做就做","血流优先胡，血战不贪杠"],
        "实战口诀": ["缺门要坚决，留着必点炮","先打完定缺，再组顺子","碰杠别乱开，后期容易炸","牌差跑快点，牌好做清一色"]
    },
    "广东": {
        "基础技巧": ["鸡胡能胡就胡，平胡优先做","门清、碰碰胡番数翻倍","单张字牌尽早出，留着没用","不贪大牌，稳胡最香"],
        "实战口诀": ["不吃鸡胡等平胡，番数差一倍","字牌孤张趁早打，别留到听牌","能碰不犹豫，快速组牌型","听牌选多面，不选单调"]
    },
    "杭州": {
        "基础技巧": ["财神是万能牌，绝对不能打","飘财收益翻倍，能飘就飘","只许自摸，不许抢杠胡","门清飘财收益最大"],
        "实战口诀": ["见财神就锁死，谁打谁后悔","飘财不飘穷，听牌再敲最稳","单吊财神最舒服，胡牌概率翻倍","不吃不碰守门清，飘财直接起飞"]
    },
    "长沙": {
        "基础技巧": ["2、5、8做将，缺一不可胡","四喜、六六顺可直接起手胡","将对胡牌收益极高","优先留对子，少留孤张"],
        "实战口诀": ["非258不做将，孤张优先扔","起手四喜直接胡，别犹豫","对子多就做将对，收益拉满","搭子够了拆边张，快速听258"]
    },
    "东北": {
        "基础技巧": ["混子（宝牌）万能，必须死留","幺九边张价值最低，优先打","能吃能碰，快速成型","字牌单张直接扔"],
        "实战口诀": ["混子在手，天下我有","幺九没用赶紧打，别占位置","能碰就碰不拖沓，快速听牌","字牌孤张不留恋，早打早安"]
    },
    "上海": {
        "基础技巧": ["必须敲牌才能胡，敲前组好搭","门清分数最高，尽量不吃碰","字牌成对留，单张直接打","敲牌后不能换牌，谨慎操作"],
        "实战口诀": ["不敲不胡，敲早敲晚看牌型","门清不碰不吃，敲牌收益翻倍","单字牌不留，留对不留单","敲牌定生死，听牌再敲最稳"]
    },
    "武汉": {
        "基础技巧": ["红中是癞子，绝对不能打","必须开口（吃碰杠）才能胡","癞子不能单吊，不能乱打","开口越多番数越高"],
        "实战口诀": ["红中锁死不打出，打红中是新手","不开口不胡牌，先开口再听牌","癞子留着组牌，别乱用","能杠就杠多开口，番数直接涨"]
    },
    "温州": {
        "基础技巧": ["有财神必留，百搭万能","2、5、8固定做将","风牌幺九优先打","快速组搭，稳健听牌"],
        "实战口诀": ["财神在手，胡牌不愁","将牌只留258，其余孤张都可打","风牌幺九先清场，中张留着组顺子","听牌选两面，不选单调"]
    },
    "陕西": {
        "基础技巧": ["推倒胡规则，快速胡牌优先","只能碰杠，不能吃牌","字牌全部没用，优先打完","不贪大牌，能胡就胡"],
        "实战口诀": ["推倒胡，跑得快，不贪大牌不受害","字牌全是废牌，越早打越安全","能碰就碰组搭子，不听单调听两面","后期不打生张，避免点炮"]
    },
    "苏州": {
        "基础技巧": ["百搭牌万能，必须留","门清收益高，少吃少碰","孤张字牌与幺九优先打","听牌选多面，胡牌更轻松"],
        "实战口诀": ["百搭不打，打百搭是外行","门清胡牌最划算，不乱吃碰","幺九风牌先打完，中张留组牌","多面听牌最舒服，单吊尽量避免"]
    },
    "安徽": {
        "基础技巧": ["推倒胡为主，快速成型","可吃可碰，灵活组牌","边张1、9与单字优先打","不贪大牌，稳扎稳打"],
        "实战口诀": ["能胡就胡不贪番，小胡也是赢","19边张最先打，中张顺子好组","吃碰快速成搭，早听早胡","熟张优先打，生张听牌再考虑"]
    }
}

def expand_hand(hand):
    arr = []
    for s in ['万','条','筒']:
        for n in hand[s]:
            arr.append(f"{n}{s}")
    for z in hand['字']:
        arr.append(z)
    return arr

def is_hu(cards):
    c = sorted(cards)
    cnt = Counter(c)
    keys = list(cnt.keys())
    def check(p):
        p = sorted(p)
        while p:
            a = p[0]
            if p.count(a) >= 3:
                p = p[3:]
            elif len(p)>=3 and len(a)==2 and str(int(a[0])+1)+a[1] in p and str(int(a[0])+2)+a[1] in p:
                p.remove(a)
                p.remove(str(int(a[0])+1)+a[1])
                p.remove(str(int(a[0])+2)+a[1])
            else:
                return False
        return True
    for k in keys:
        if cnt[k] >= 2:
            tmp = c.copy()
            tmp.remove(k)
            tmp.remove(k)
            if check(tmp):
                return True
    return False

def get_ting_tiles(hand):
    all_tiles = []
    for s in ['万','条','筒']:
        for n in '123456789':
            all_tiles.append(f"{n}{s}")
    for z in ['东','南','西','北','中','发','白']:
        all_tiles.append(z)
    current = expand_hand(hand)
    ting = []
    for t in all_tiles:
        test = current + [t]
        if is_hu(test):
            ting.append(t)
    return sorted(list(set(ting)))

def calc_fan(hand, rule="通用"):
    tiles = expand_hand(hand)
    fan = 0
    fan_names = []
    c = Counter(tiles)
    fan +=1
    fan_names.append("门清(1番)")
    pairs = [k for k,v in c.items() if v>=2]
    if len(pairs)>=4:
        fan +=2
        fan_names.append("对对胡(2番)")
    suits = []
    for t in tiles:
        if len(t)==2:
            suits.append(t[1])
    if suits and all(s==suits[0] for s in suits):
        fan +=3
        fan_names.append("清一色(3番)")
    if all(len(t)==1 for t in tiles):
        fan +=4
        fan_names.append("字一色(4番)")
    if rule in ["长沙","温州"]:
        if any(t[0] in "258" for t in tiles if len(t)==2):
            fan +=1
            fan_names.append("258将(1番)")
    if rule == "武汉" and "红中" in tiles:
        fan +=1
        fan_names.append("红中癞子(1番)")
    return fan, fan_names

def discard_risk(hand, discard_tile, rule="通用"):
    tiles = expand_hand(hand)
    if discard_tile not in tiles:
        return "❌ 错误", "该牌不在手牌中"
    test_hand = tiles.copy()
    test_hand.remove(discard_tile)
    new_hand = {
        "万": [t[0] for t in test_hand if len(t)==2 and t[1]=="万"],
        "条": [t[0] for t in test_hand if len(t)==2 and t[1]=="条"],
        "筒": [t[0] for t in test_hand if len(t)==2 and t[1]=="筒"],
        "字": [t for t in test_hand if len(t)==1]
    }
    ting_after = get_ting_tiles(new_hand)
    if not ting_after:
        return "🟢 安全", "打出后不听牌，无点炮风险"
    danger = len(ting_after)
    if danger >= 4:
        return "🔴 高危", f"听{danger}张牌，点炮概率极高"
    elif danger >=2:
        return "🟡 危险", f"听{danger}张牌，有点炮风险"
    else:
        return "🟡 轻微危险", f"听{danger}张牌，风险较低"

def ocr_recognize(image_path):
    try:
        img = Image.open(image_path)
        text = pytesseract.image_to_string(img, lang="chi_sim")
        return re.sub(r'[^\u4e00-\u9fa5\d]', '', text)
    except:
        return None

def parse_hand(text):
    hand = {"万":[],"条":[],"筒":[],"字":[]}
    pattern = re.compile(r'([1-9][万条筒]|[东南西北中发白])')
    cards = pattern.findall(text)
    for c in cards:
        if len(c)==2:
            num, suit = c[0], c[1]
            hand[suit].append(num)
        else:
            hand["字"].append(c)
    for s in hand:
        hand[s].sort()
    return hand

def suggest_discard(hand, rule="通用"):
    if rule == "四川":
        suits = ["万","条","筒"]
        cnt = {s:len(hand[s]) for s in suits}
        min_suit = min(cnt, key=cnt.get)
        if hand[min_suit]:
            return f"{hand[min_suit][0]}{min_suit}", f"四川定缺优先打{min_suit}"
    if rule in ["长沙","温州"]:
        for suit in ["万","条","筒"]:
            for n in hand[suit]:
                if n not in ["2","5","8"] and hand[suit].count(n)==1:
                    return f"{n}{suit}", f"{rule}非258孤张优先打"
    if rule == "武汉":
        hand["字"] = [z for z in hand["字"] if z != "红中"]
    for c in hand["字"]:
        if hand["字"].count(c)==1:
            return c, f"{rule}：孤张字牌优先打"
    for suit in ["万","条","筒"]:
        nums = hand[suit]
        for i,n in enumerate(nums):
            left = int(nums[i-1]) if i>0 else -99
            right = int(nums[i+1]) if i<len(nums)-1 else -99
            if nums.count(n)==1 and int(n)-left!=1 and right-int(n)!=1:
                return f"{n}{suit}", "花色孤张优先打"
    for suit in ["万","条","筒"]:
        for n in hand[suit]:
            if n in ["1","9"] and hand[suit].count(n)==1:
                return f"{n}{suit}", "幺九边张价值低优先打"
    for suit in ["万","条","筒"]:
        if len(hand[suit])>=3:
            return f"{hand[suit][-1]}{suit}", "搭子充足拆冗余"
    return "手牌结构优秀", "已接近听牌"

def run(params):
    msg_type = params.get("type", "text")
    content = params.get("content", "").strip()

    if msg_type == "image":
        if HAS_IMAGE_SUPPORT:
            txt = ocr_recognize(content)
            if txt:
                try:
                    hand = parse_hand(txt)
                    card, reason = suggest_discard(hand)
                    ting = get_ting_tiles(hand)
                    fan, fan_names = calc_fan(hand)
                    risk_level, risk_tip = discard_risk(hand, card)
                    return {
                        "title": "🀄️ 图片识别成功",
                        "content": {
                            "识别结果": txt,
                            "推荐打出": card,
                            "理由": reason,
                            "点炮风险": risk_level + " | " + risk_tip,
                            "听牌": ting if ting else "未听牌",
                            "番数": fan,
                            "番型": fan_names
                        }
                    }
                except:
                    pass
            return {"title":"🀄️识别失败","content":"请发文字手牌，例：123万 45条 中"}
        else:
            return {
                "title":"🀄️图片功能未开启",
                "content":"安装依赖可开启：pip install pillow pytesseract\n或直接发文字手牌"
            }

    text = content
    rule = "通用"
    for r in SUPPORTED_RULES:
        if r in text:
            rule = r
            text = text.replace(r,"").strip()
            break

    if any(k in text for k in ["技巧","口诀","攻略","教学","打法"]):
        return {"title":f"🀄️{rule}麻将·技巧+口诀","content":MAHJONG_TIPS[rule]}

    try:
        hand = parse_hand(text)
        card, reason = suggest_discard(hand, rule)
        ting = get_ting_tiles(hand)
        fan, fan_names = calc_fan(hand, rule)
        risk_level, risk_tip = discard_risk(hand, card, rule)
        return {
            "title": f"🀄️{rule}麻将·终极分析",
            "content": {
                "当前规则": rule,
                "推荐打出": card,
                "理由": reason,
                "点炮风险等级": risk_level,
                "风险说明": risk_tip,
                "听牌": ting if ting else "未听牌",
                "总番数": fan,
                "番型": fan_names
            }
        }
    except Exception as e:
        return {"title":"使用示例","content":"武汉 123万 45条 中 88筒"}