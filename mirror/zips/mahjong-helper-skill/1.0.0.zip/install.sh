#!/bin/bash

# ==============================================
# 全能麻将助手 —— 环境自动安装脚本
# SkillHub 上架专用
# ==============================================

clear
echo "=============================================="
echo " 🀄️  全能麻将助手 - 依赖安装程序 "
echo "=============================================="
echo ""

# 检查 Python 与 pip 是否存在
if ! command -v python3 &> /dev/null; then
    echo "⚠️  未检测到 Python3，请先安装 Python3 后重试！"
    exit 1
fi

if ! command -v pip &> /dev/null && ! command -v pip3 &> /dev/null; then
    echo "⚠️  未检测到 pip，请先安装 pip 后重试！"
    exit 1
fi

# 自动选择 pip3 / pip
PIP_CMD="pip"
if command -v pip3 &> /dev/null; then
    PIP_CMD="pip3"
fi

echo "✅ 检测到 Python 环境正常"
echo "📦 使用包管理器：$PIP_CMD"
echo ""

# 升级 pip
echo "=============================================="
echo "🔄 正在升级 pip..."
echo "=============================================="
$PIP_CMD install --upgrade pip

# 安装图片识别依赖（Pillow + pytesseract）
echo ""
echo "=============================================="
echo "🖼️  正在安装图片识别支持库..."
echo "=============================================="
$PIP_CMD install "pillow>=9.0.0"
$PIP_CMD install "pytesseract>=0.3.10"

echo ""
echo "=============================================="
echo "✅ 所有依赖安装完成！"
echo "=============================================="
echo ""
echo "🎉 功能已解锁："
echo "   ✅ 图片手牌识别"
echo "   ✅ 12 地区麻将规则"
echo "   ✅ 听牌检测"
echo "   ✅ 番数计算"
echo "   ✅ 点炮风险等级"
echo ""
echo "👉 现在可以直接发送麻将图片使用！"
echo ""