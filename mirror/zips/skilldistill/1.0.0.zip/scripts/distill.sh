#!/bin/bash
# Skill 蒸馏工具 - 辅助脚本
# 用途：读取目标 skill 并生成可执行脚本

set -e

SKILL_DIR="$HOME/.openclaw/workspace/skills"
OUTPUT_DIR="$SKILL_DIR/skill-distill/output"
CONFIG_FILE="$HOME/.openclaw/openclaw.json"

# 确保输出目录存在
mkdir -p "$OUTPUT_DIR"

# 获取当前模型配置
get_model_config() {
    if [ -f "$CONFIG_FILE" ]; then
        jq -r '.model // .defaults.model // .agents.defaults.model // {}' "$CONFIG_FILE" 2>/dev/null || echo '{}'
    else
        echo '{}'
    fi
}

# 列出所有 skills
list_skills() {
    echo "=== Available Skills ==="
    ls -1 "$SKILL_DIR" 2>/dev/null | grep -v "^\\." | grep -v "skill-distill" || echo "No skills found"
}

# 读取 skill 的 SKILL.md
read_skill_md() {
    local skill_name="$1"
    if [ -f "$SKILL_DIR/$skill_name/SKILL.md" ]; then
        cat "$SKILL_DIR/$skill_name/SKILL.md"
    else
        echo "Error: SKILL.md not found for $skill_name"
        exit 1
    fi
}

# 列出 skill 的脚本
list_skill_scripts() {
    local skill_name="$1"
    if [ -d "$SKILL_DIR/$skill_name/scripts" ]; then
        ls -1 "$SKILL_DIR/$skill_name/scripts/"
    else
        echo "No scripts directory for $skill_name"
    fi
}

# 读取 skill 的脚本内容
read_skill_script() {
    local skill_name="$1"
    local script_name="$2"
    if [ -f "$SKILL_DIR/$skill_name/scripts/$script_name" ]; then
        cat "$SKILL_DIR/$skill_name/scripts/$script_name"
    else
        echo "Error: script not found: $skill_name/scripts/$script_name"
        exit 1
    fi
}

# 生成蒸馏脚本
generate_distilled_script() {
    local skill_name="$1"
    local model_config="$2"
    local script_content="$3"
    
    cat > "$OUTPUT_DIR/${skill_name}.sh" << EOF
#!/bin/bash
# Skill: ${skill_name}
# Model: ${model_config}
# Generated: $(date)

set -e

# 嵌入的模型配置
OPENCLAW_MODEL='${model_config}'

${script_content}
EOF
    chmod +x "$OUTPUT_DIR/${skill_name}.sh"
    echo "Generated: $OUTPUT_DIR/${skill_name}.sh"
}

# 主命令处理
case "${1:-}" in
    list)
        list_skills
        ;;
    read)
        if [ -z "$2" ]; then
            echo "Usage: $0 read <skill-name>"
            exit 1
        fi
        read_skill_md "$2"
        ;;
    scripts)
        if [ -z "$2" ]; then
            echo "Usage: $0 scripts <skill-name>"
            exit 1
        fi
        list_skill_scripts "$2"
        ;;
    model)
        get_model_config
        ;;
    *)
        echo "Usage: $0 <command> [args]"
        echo ""
        echo "Commands:"
        echo "  list                    - List all available skills"
        echo "  read <skill-name>       - Read SKILL.md content"
        echo "  scripts <skill-name>    - List skill's scripts"
        echo "  model                   - Get current model config"
        echo ""
        echo "Examples:"
        echo "  $0 list"
        echo "  $0 read xiaohongshu-yq"
        echo "  $0 scripts xiaohongshu-yq"
        echo "  $0 model"
        ;;
esac