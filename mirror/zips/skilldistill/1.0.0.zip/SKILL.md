---
name: skill-distill
description: "将现有 skill 转换为可执行的脚本工具。读取指定 skill 的 SKILL.md 和脚本，生成独立的可执行脚本，并在脚本中嵌入当前 OpenClaw 模型配置。当需要：(1) 把某个 skill 转换成独立脚本工具 (2) 提取 skill 的功能生成命令行工具 (3) 将 skill 封装为可直接运行的脚本 时使用此技能。"
---

# Skill 蒸馏工具

将现有 skill 转换为可执行的 shell 脚本工具。

## 工作流程

### 1. 读取目标 Skill

```bash
# 列出所有可用 skills
ls -la ~/.openclaw/workspace/skills/

# 读取目标 skill 的 SKILL.md
cat ~/.openclaw/workspace/skills/<skill-name>/SKILL.md

# 查看 skill 的脚本目录
ls -la ~/.openclaw/workspace/skills/<skill-name>/scripts/
```

### 2. 获取当前模型配置

```bash
# 从 openclaw.json 读取模型配置
cat ~/.openclaw/openclaw.json | jq '.model // .defaults.model // .agents.defaults.model'
```

输出示例：
```json
{
  "primary": "minimax-cn/MiniMax-M2.5",
  "fallbacks": ["minimax/MiniMax-M2.5"]
}
```

### 3. 生成脚本

读取目标 skill 的内容后，生成一个独立的执行脚本，脚本头部需包含：

```bash
#!/bin/bash
# Skill: <skill-name>
# Model: <从 openclaw.json 读取的模型配置>
# Generated: $(date)

set -e

# ⚠️ API Key 配置说明（本脚本使用 MiniMax 模型）
#
# 方法1: 设置环境变量（推荐）
#   export MINIMAX_API_KEY="your-api-key"
#
# 方法2: 在启动脚本前source配置文件
#   source ~/.api_keys.sh
#
# 获取 API Key: https://platform.minimaxi.com/

# 模型配置（从 openclaw.json 读取）
OPENCLAW_MODEL='{"primary":"minimax-cn/MiniMax-M2.5","fallbacks":["minimax/MiniMax-M2.5"]}'
MODEL_PRIMARY="minimax-cn/MiniMax-M2.5"

# === 检查 API Key ===
check_api_key() {
    if [ -z "$MINIMAX_API_KEY" ]; then
        echo "⚠️ 请先配置 MINIMAX_API_KEY 环境变量"
        echo "   export MINIMAX_API_KEY='your-api-key'"
        return 1
    fi
    return 0
}

# === 调用 LLM 函数 ===
call_llm() {
    local prompt="$1"
    local system="$2"
    
    if ! check_api_key; then
        return 1
    fi
    
    curl -s -X POST 'https://api.minimax.chat/v1/text/chatcompletion_pro' \
        -H "Authorization: Bearer $MINIMAX_API_KEY" \
        -H "Content-Type: application/json" \
        -d "{\"model\": \"$MODEL_PRIMARY\", ...}"
}

# 这里是 skill 的核心功能逻辑
# ...
```

### 4. 保存脚本

将生成的脚本保存到 `~/.openclaw/workspace/tools/<skill-name>.sh`

## 重要：API Key 配置

由于脚本中可能需要调用大模型（如 MiniMax），必须提醒用户配置 API Key：

1. **环境变量方式**（推荐）：
   ```bash
   export MINIMAX_API_KEY="your-api-key"
   ```

2. **配置文件方式**：
   在 `~/.api_keys.sh` 中写入：
   ```bash
   export MINIMAX_API_KEY="xxx"
   ```
   然后 `source ~/.api_keys.sh`

脚本中需包含 `check_api_key()` 函数，在调用 LLM 前检查是否已配置。

## 输出目录

生成的脚本保存在：`~/.openclaw/workspace/tools/`

## 注意事项

- 保持脚本的可执行性（chmod +x）
- 脚本应尽可能自包含，减少外部依赖
- 模型配置以 JSON 字符串形式嵌入脚本头部注释中
- 必须包含 API Key 配置说明和检查函数