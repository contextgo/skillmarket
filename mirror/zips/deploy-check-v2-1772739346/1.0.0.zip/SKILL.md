---
name: Deploy Check V2
description: "embedding server side"
metadata:
  synthetic_archive: true
  source: public-metadata-placeholder
---

# Deploy Check V2

This archive was synthesized from public SkillHub / ClawHub metadata because the upstream zip package was unavailable during mirroring.

## Metadata

- slug: `deploy-check-v2-1772739346`
- version: `1.0.0`
- owner: `skipzhang`
- homepage: https://clawhub.ai/skipzhang/deploy-check-v2-1772739346
- category: ``
- downloads: `0`
- stars: `0`
- installs: `0`

## Description

embedding server side

## Note

If the upstream package becomes available later, you can replace this synthesized archive with the original zip.
