"""Security rules and patterns."""
