#!/usr/bin/env python3
"""
加班车费报销自动化
处理报销申请表 -> 解析凭证(PDF/图片) -> 7条规则校验 -> 填写结算表
"""

import sys
import os
import re
import json
from pathlib import Path
from datetime import datetime

import openpyxl
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter

# ─── 全局常量 ────────────────────────────────────────────────

INVOICE_TITLE = "北京外企德科人力资源服务上海有限公司"
INVOICE_TAX_ID = "913100007776072078"

# 花名册列（1-indexed）
ROSTER_COL = {
    "工号": 1,   # A
    "姓名": 2,   # B
    "身份证": 6, # F
}

# 报销申请表列（1-indexed）
APP_COL = {
    "报销金额": 6,    # F（本行报销金额）
    "报销类型": 5,    # E
    "申请人": 10,    # J
    "月份": 2,       # B
    "凭证路径": 4,   # D
}

# 结算表列（1-indexed）
SETTLE_COL = {
    "工号": 1,        # A
    "姓名": 2,        # B
    "身份证": 3,     # C
    "报销类型": 4,    # D
    "申请金额": 5,    # E
    "报销金额": 6,    # F
    "月份": 7,       # G
    "电子流金额": 8,  # H
    "发票金额": 9,    # I
    "备注": 10,       # J
}

# 车型黑名单
CAR_TYPE_BLACKLIST = ["优享型", "专车", "商务车", "豪华", "六座"]

# 文件名含这些关键词的，跳过不归类为发票或行程单
SKIP_FILENAME_KEYWORDS = ["Screenshot", "加班", "打卡截图"]

# ─── PDF 解析 ────────────────────────────────────────────────

def parse_pdf_text(pdf_path: str) -> str:
    """从 PDF 提取全文本"""
    try:
        import pdfplumber
        texts = []
        with pdfplumber.open(pdf_path) as pdf:
            for page in pdf.pages:
                t = page.extract_text()
                if t:
                    texts.append(t)
        return "\n".join(texts)
    except Exception as e:
        return f"[PDF解析失败: {e}]"


def parse_image_ocr(image_path: str) -> str:
    """用 TextIn API 解析图片文字，返回拼接后的纯文本"""
    try:
        app_id_path = os.path.expanduser("~/.textin_app_id")
        secret_path = os.path.expanduser("~/.textin_secret_code")
        if not os.path.exists(app_id_path) or not os.path.exists(secret_path):
            return "[OCR失败: 未找到 TextIn 密钥文件]"
        app_id = open(app_id_path).read().strip()
        secret_code = open(secret_path).read().strip()

        import urllib.request
        req = urllib.request.Request(
            "https://api.textin.com/ai/service/v4/recognize/document",
            data=open(image_path, "rb").read(),
            method="POST"
        )
        req.add_header("x-ti-app-id", app_id)
        req.add_header("x-ti-secret-code", secret_code)
        req.add_header("Content-Type", "application/octet-stream")

        with urllib.request.urlopen(req, timeout=30) as resp:
            import json
            data = json.loads(resp.read())

        if data.get("code") != 200:
            return f"[OCR失败: code={data.get('code')} {data.get('message', '')}]"

        chunks = data.get("result", {}).get("parse_chunk_results", [])
        texts = []
        for chunk in chunks:
            if chunk.get("chunk_type") == "textchunk" and chunk.get("text"):
                texts.append(chunk["text"])
        return " ".join(texts) if texts else ""

    except Exception as e:
        return f"[OCR失败: {e}]"


# ─── 发票/行程单解析 ──────────────────────────────────────────

def extract_amounts(text: str) -> list[float]:
    """从文本中提取金额，仅匹配真正带货币符号/金额标签的上下文"""
    amounts = []
    for m in re.findall(r'(?:[¥￥]|金额|合计|计费|价税合计)[：:\s]*([0-9]+\.?[0-9]*)', text):
        try:
            v = float(m)
            if 0 < v < 10000:
                amounts.append(v)
        except:
            pass
    return amounts


def parse_invoice_text(text: str) -> dict:
    """
    从发票全文中提取关键字段
    返回 dict: {title, tax_id, total_amount, date, has_title_ok, type}
    """
    info = {
        "type": "unknown",
        "title_ok": False,
        "tax_id_ok": False,
        "total_amount": 0.0,
        "date": None,
        "time": None,
        "raw": text[:500],
    }

    # 发票抬头
    if INVOICE_TITLE in text:
        info["title_ok"] = True
    if INVOICE_TAX_ID in text:
        info["tax_id_ok"] = True

    # 价税合计（取第一个大金额）
    amounts = extract_amounts(text)
    # 过滤过小的值，取最大者
    valid_amounts = [a for a in amounts if a >= 1.0]
    if valid_amounts:
        info["total_amount"] = max(valid_amounts)

    # 开票日期
    date_m = re.search(r'开票日期[：:]\s*(\d{4}[年/-]\d{1,2}[月/-]\d{1,2}[日]?)', text)
    if date_m:
        info["date"] = date_m.group(1)

    # 出行日期 + 时间
    trip_m = re.search(r'(\d{4}[年/-]\d{1,2}[月/-]\d{1,2}[日]?)\s*(\d{1,2}:\d{2})', text)
    if trip_m:
        info["date"] = trip_m.group(1)
        info["time"] = trip_m.group(2)

    # 打车类型判断
    lower = text.lower()
    # 关键词：打车平台名、运输服务关键词
    rideshare_keywords = ["滴滴", "快车", "网约车", "高德", "曹操", "t3出行", "享道", 
                          "及时用车", "及时雨", "阳光出行", "哈啰", "美团打车",
                          "运输服务", "客运服务", "出行服务"]
    taxi_keywords = ["出租", "taxi"]
    
    if any(k in lower for k in rideshare_keywords):
        info["type"] = "网约车"
    elif any(k in lower for k in taxi_keywords):
        info["type"] = "出租车"

    return info


def parse_trip_text(text: str) -> dict:
    """
    从行程单全文中提取关键字段
    返回 dict: {car_type, city, start_loc, end_loc, amount, time}
    """
    info = {
        "car_type": None,
        "city": None,
        "start_loc": None,
        "end_loc": None,
        "amount": 0.0,
        "time": None,
        "raw": text[:500],
    }

    # 高德打车行程单表格格式解析
    # 格式：序号 服务商 车型 上车时间 城市 起点 终点 金额
    # 例：1 经济型 2026-03-18 21:10 西安市 软件新城云汇谷(南1门) 井上村地铁站F口 44.22元
    table_m = re.search(
        r'(\d+)\s+(\S+)\s+(\S+)\s+(\d{4}-\d{2}-\d{2})\s+(\d{1,2}:\d{2})\s+(\S+)\s+(.+?)\s+(.+?)\s+([\d.]+)元',
        text
    )
    if table_m:
        info["car_type"] = table_m.group(3)  # 车型
        info["time"] = table_m.group(5)      # 时间
        info["city"] = table_m.group(6)      # 城市
        info["start_loc"] = table_m.group(7).strip()  # 起点
        info["end_loc"] = table_m.group(8).strip()    # 终点
        info["amount"] = float(table_m.group(9))      # 金额
        return info

    # 兜底：尝试提取金额
    amounts = extract_amounts(text)
    valid_amounts = [a for a in amounts if a >= 1.0]
    if valid_amounts:
        info["amount"] = max(valid_amounts)

    # 时间
    time_m = re.search(r'(\d{1,2}:\d{2})', text)
    if time_m:
        info["time"] = time_m.group(1)

    return info


# ─── 凭证文件夹扫描 ──────────────────────────────────────────

def scan_voucher_folder(folder_path: str, depth: int = 0, max_depth: int = 10) -> dict:
    """
    递归扫描凭证文件夹（支持多层嵌套），返回 {pdf_texts, image_texts, files_found, invoice_infos, trip_infos}
    """
    result = {
        "files_found": [],
        "pdf_texts": [],
        "image_texts": [],
        "invoice_infos": [],
        "trip_infos": [],
        "_seen_files": set(),  # 用于去重
    }

    if not os.path.isdir(folder_path):
        return result
    
    # 防止无限递归
    if depth > max_depth:
        return result

    try:
        for fname in os.listdir(folder_path):
            fpath = os.path.join(folder_path, fname)
            
            # 如果是目录，递归扫描
            if os.path.isdir(fpath):
                sub_result = scan_voucher_folder(fpath, depth + 1, max_depth)
                # 合并子目录结果（不重复）
                for f in sub_result["files_found"]:
                    if f not in result["files_found"]:
                        result["files_found"].append(f)
                result["pdf_texts"].extend(sub_result["pdf_texts"])
                result["image_texts"].extend(sub_result["image_texts"])
                result["invoice_infos"].extend(sub_result["invoice_infos"])
                result["trip_infos"].extend(sub_result["trip_infos"])
                result["_seen_files"].update(sub_result["_seen_files"])
                continue
            
            if not os.path.isfile(fpath):
                continue

            # 跳过截图类文件（钉钉截图、加班截图、打卡截图）
            if any(kw in fname for kw in SKIP_FILENAME_KEYWORDS):
                continue

            # 文件去重：使用文件名+大小作为唯一标识
            file_key = f"{fname}_{os.path.getsize(fpath)}"
            if file_key in result["_seen_files"]:
                continue
            result["_seen_files"].add(file_key)

            result["files_found"].append(fname)
            ext = os.path.splitext(fname)[1].lower()

            if ext == ".pdf":
                text = parse_pdf_text(fpath)
                result["pdf_texts"].append(text)
                # 根据内容判断：含"发票"→发票，含"行程"→行程单
                if "发票" in text:
                    info = parse_invoice_text(text)
                    result["invoice_infos"].append(info)
                elif "行程" in text or "行程报销单" in fname:
                    info = parse_trip_text(text)
                    result["trip_infos"].append(info)

            elif ext in [".jpg", ".jpeg", ".png", ".heic"]:
                try:
                    from PIL import Image
                    import tempfile
                    img = Image.open(fpath)
                    with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:
                        img.convert("RGB").save(tmp.name, "PNG")
                        tmp_path = tmp.name
                    try:
                        text = parse_image_ocr(tmp_path)
                    finally:
                        os.unlink(tmp_path)
                    result["image_texts"].append(text)
                    # 根据 OCR 文本内容判断类型
                    if "发票" in text:
                        info = parse_invoice_text(text)
                        result["invoice_infos"].append(info)
                    elif "行程" in text:
                        info = parse_trip_text(text)
                        result["trip_infos"].append(info)
                except Exception as e:
                    result["image_texts"].append(f"[图片OCR失败: {e}]")
    except PermissionError:
        pass  # 跳过无权限访问的文件夹

    # 不移除 _seen_files，让调用方清理
    return result


# ─── 7条规则校验 ─────────────────────────────────────────────

def validate(voucher_data: dict, apply_amount: float) -> list[str]:
    """
    执行7条校验，返回异常列表
    """
    errors = []
    invoice_infos = voucher_data["invoice_infos"]
    trip_infos = voucher_data["trip_infos"]
    TAXI_TYPES = ["网约车", "出租车"]

    # 过滤出打车类发票（非打车发票如餐饮便利店等不参与金额/时间校验）
    taxi_invoices = [inv for inv in invoice_infos if inv["type"] in TAXI_TYPES]

    # 规则1: 发票抬头（所有发票都检查）
    for inv in invoice_infos:
        if not inv["title_ok"]:
            errors.append(f"规则1-发票抬头错误或缺失（应为{INVOICE_TITLE}）")
        if not inv["tax_id_ok"]:
            errors.append(f"规则1-税号缺失或错误（应为{INVOICE_TAX_ID}）")

    # 判断是否有网约车（有行程单或有任何打车类发票即算）
    is_rideshare = bool(trip_infos) or bool(taxi_invoices)

    # 规则2: 网约车需发票+行程单，金额一致
    if is_rideshare:
        if not trip_infos:
            errors.append("规则2-网约车缺少行程单")
        if not taxi_invoices:
            errors.append("规则2-网约车缺少发票")
        if taxi_invoices and trip_infos:
            inv_total = sum(inv["total_amount"] for inv in taxi_invoices if inv["total_amount"] > 0)
            trip_total = sum(t["amount"] for t in trip_infos if t["amount"] > 0)
            if inv_total > 0 and trip_total > 0 and abs(inv_total - trip_total) > 0.01:
                errors.append(f"规则2-发票金额({round(inv_total,2)})与行程单金额({round(trip_total,2)})不一致")

    # 规则3: 出租车等仅需发票（已默认满足）
    # 规则4: 打车时间≥21:00（只看打车发票和行程单的时间）
    all_times = []
    for inv in taxi_invoices:
        if inv["time"]:
            all_times.append(inv["time"])
    for trip in trip_infos:
        if trip["time"]:
            all_times.append(trip["time"])
    for t_str in all_times:
        try:
            hour = int(t_str.split(":")[0])
            if hour < 21:
                errors.append(f"规则4-打车时间{hour}:00 < 21:00（不符合21:00及之后的要求）")
        except:
            pass

    # 规则5: 行程单车型限制
    for trip in trip_infos:
        if trip["car_type"]:
            ct = trip["car_type"]
            for black in CAR_TYPE_BLACKLIST:
                if black in ct:
                    errors.append(f"规则5-行程单车型'{ct}'含黑名单词'{black}'")

    # 规则6: 上下车同城市
    for trip in trip_infos:
        start = trip.get("start_loc", "") or ""
        end = trip.get("end_loc", "") or ""
        city = trip.get("city", "") or ""
        # 简单判断：上下车地点包含城市名
        if city:
            for loc in [start, end]:
                if loc and city not in loc and loc not in city:
                    errors.append(f"规则6-行程单上车/下车地点可能跨城（上:{start} 下:{end} 城市:{city}）")

    # 规则7: 打车发票合计 ≥ 申请金额（非打车发票不计入）
    total_inv_amount = sum(inv["total_amount"] for inv in taxi_invoices if inv["total_amount"] > 0)
    if total_inv_amount > 0 and total_inv_amount < apply_amount - 0.01:
        errors.append(f"规则7-发票合计金额({round(total_inv_amount,2)}) < 申请金额({apply_amount})")

    # 如果没有任何打车发票
    if total_inv_amount == 0 and not taxi_invoices:
        errors.append("规则7-未找到任何打车发票，无法核实金额")

    return errors


# ─── 主流程 ────────────────────────────────────────────────────

def build_merged_cell_map(ws):
    """
    返回 dict：{(row, col): master_value}
    key是被合并的单元格坐标，value是主单元格的值
    """
    merged_map = {}
    for merged_range in ws.merged_cells.ranges:
        # 获取主单元格（左上角）
        min_col, min_row, max_col, max_row = merged_range.bounds
        # 主单元格是 min_row, min_col
        for r in range(min_row, max_row + 1):
            for c in range(min_col, max_col + 1):
                if (r, c) != (min_row, min_col):
                    merged_map[(r, c)] = (min_row, min_col)
    return merged_map


def get_cell_value(ws, row, col, merged_map):
    """读取单元格，处理合并单元格：若是从单元格，返回主单元格的值"""
    val = ws.cell(row=row, column=col).value
    if val is None and (row, col) in merged_map:
        master_row, master_col = merged_map[(row, col)]
        val = ws.cell(row=master_row, column=master_col).value
    return val

def load_roster(roster_path: str) -> dict:
    """返回 {工号: {姓名, 身份证}}"""
    wb = load_workbook(roster_path, data_only=True)
    ws = wb.active
    result = {}
    # Row 3 = 列名(A=工号,B=姓名,F=身份证)，Row 4+ = 实际数据
    for row in ws.iter_rows(min_row=4, values_only=True):
        emp_no = row[0]  # A列
        if emp_no and isinstance(emp_no, str) and emp_no.startswith("WB"):
            name = row[1]      # B列
            id_card = row[5] or ""  # F列
            result[emp_no] = {"name": name, "id_card": id_card}
    return result


def load_application(app_path: str) -> list:
    """
    读取报销申请表，返回 [{工号, 姓名, 报销类型, 凭证文件夹名, 申请金额, 月份}]
    """
    wb = load_workbook(app_path, data_only=True)
    ws = wb.active

    # 构建合并单元格 map，用于解析从单元格的值
    merged_map = build_merged_cell_map(ws)

    records = []

    # Row 1 = 实例标题, Row 2 = 列名行, Row 3+ = 数据
    for row_idx in range(3, ws.max_row + 1):
        apply_type = get_cell_value(ws, row_idx, APP_COL["报销类型"], merged_map)  # E列
        if not apply_type or "加班" not in str(apply_type):
            continue

        # 申请人优先从 J 列读（格式 "姓名(工号)"）；若无则从 A 列标题提取
        applicant = get_cell_value(ws, row_idx, APP_COL["申请人"], merged_map)  # J列
        a_title = ws.cell(row=row_idx, column=1).value or ""  # A列 = 实例标题（不参与合并，直接读）

        name, emp_no = "", ""
        # 尝试从J列解析
        if applicant:
            m = re.match(r'(.+?)\((([^)]+))\)', str(applicant))
            if m:
                name, emp_no = m.group(1).strip(), m.group(2).strip()
        # 兜底：从A列标题 "XXX发起的报销申请" 提取姓名
        if not name:
            m2 = re.match(r'^(.+?)发起的报销申请', a_title)
            if m2:
                name = m2.group(1).strip()

        # 凭证文件夹路径：从 D 列取（处理合并单元格）
        d_path = get_cell_value(ws, row_idx, APP_COL["凭证路径"], merged_map)  # D列
        folder_name = None
        sub_path = None
        if d_path:
            parts = str(d_path).split("/")
            folder_name = parts[0]
            if len(parts) > 1:
                sub_path = "/".join(parts[1:])  # 如 "附件/报销凭证"

        total_amount = get_cell_value(ws, row_idx, APP_COL["报销金额"], merged_map)  # F列
        month = get_cell_value(ws, row_idx, APP_COL["月份"], merged_map)  # B列

        records.append({
            "emp_no": emp_no,
            "name": name,
            "apply_type": str(apply_type),
            "folder_name": folder_name,
            "sub_path": sub_path,
            "total_amount": float(total_amount) if total_amount else 0.0,
            "month": month,
        })

    return records


def fill_settlement(
    template_path: str,
    output_path: str,
    records: list,
    roster: dict,
    base_folder: str,
) -> dict:
    """
    追加填写结算表（根据表头动态匹配列位置）
    """
    wb = load_workbook(template_path)
    ws = wb.active
    
    # 读取表头行，建立列名映射
    header_row = 1
    col_map = {}
    for col_idx, cell in enumerate(ws[header_row], start=1):
        if cell.value:
            col_name = str(cell.value).strip()
            # 标准化列名
            if "工号" in col_name:
                col_map["工号"] = col_idx
            elif "姓名" in col_name:
                col_map["姓名"] = col_idx
            elif "身份证" in col_name:
                col_map["身份证"] = col_idx
            elif col_name == "报销类型":
                col_map["报销类型"] = col_idx
            elif col_name == "申请金额":
                col_map["申请金额"] = col_idx
            elif col_name == "报销金额":
                col_map["报销金额"] = col_idx
            elif "月份" in col_name:
                col_map["月份"] = col_idx
            elif col_name == "电子流金额":
                col_map["电子流金额"] = col_idx
            elif col_name == "发票金额":
                col_map["发票金额"] = col_idx
            elif col_name == "备注" and "备注" not in col_map:
                col_map["备注"] = col_idx
    
    print(f"  结算表列映射: {col_map}")
    
    next_row = ws.max_row + 1
    summary = {"total": 0, "success": 0, "errors": 0}

    for rec in records:
        summary["total"] += 1
        row = next_row

        # 取花名册中的身份证
        id_card = ""
        if rec["emp_no"] in roster:
            id_card = roster[rec["emp_no"]]["id_card"] or ""

        # 扫描凭证文件夹：扫描整个 UUID 文件夹（递归搜索所有子文件夹）
        if rec["folder_name"]:
            folder_path = os.path.join(base_folder, rec["folder_name"])
        else:
            folder_path = None

        voucher_data = {"files_found": [], "pdf_texts": [], "image_texts": [],
                        "invoice_infos": [], "trip_infos": []}
        if folder_path and os.path.isdir(folder_path):
            voucher_data = scan_voucher_folder(folder_path)
            voucher_data.pop("_seen_files", None)

        # 校验
        errors = validate(voucher_data, rec["total_amount"])

        # 凭证总金额（只统计打车类发票）
        total_voucher = sum(inv["total_amount"]
                           for inv in voucher_data["invoice_infos"]
                           if inv["type"] in ["网约车", "出租车"] and inv["total_amount"] > 0)
        if total_voucher == 0:
            # 尝试从行程单取金额
            total_voucher = sum(t["amount"]
                               for t in voucher_data["trip_infos"]
                               if t["amount"] > 0)

        # 月份处理
        month_val = rec["month"]
        if month_val:
            if isinstance(month_val, str) and re.match(r'\d{4}-\d{2}', month_val):
                month_val = int(month_val.replace("-", ""))
            elif isinstance(month_val, str) and re.match(r'\d{6}', month_val):
                month_val = int(month_val)

        # 备注
        remark = ""
        if errors:
            remark = "; ".join(errors[:5])
            summary["errors"] += 1
        else:
            summary["success"] += 1

        # 根据表头映射写入数据
        if "工号" in col_map:
            ws.cell(row, col_map["工号"], rec["emp_no"])
        if "姓名" in col_map:
            ws.cell(row, col_map["姓名"], rec["name"])
        if "身份证" in col_map:
            ws.cell(row, col_map["身份证"], id_card)
        if "报销类型" in col_map:
            ws.cell(row, col_map["报销类型"], rec["apply_type"])
        if "申请金额" in col_map:
            ws.cell(row, col_map["申请金额"], rec["total_amount"])
        if "报销金额" in col_map:
            ws.cell(row, col_map["报销金额"], total_voucher if total_voucher > 0 else "")
        if "月份" in col_map:
            ws.cell(row, col_map["月份"], month_val)
        if "电子流金额" in col_map:
            ws.cell(row, col_map["电子流金额"], rec["total_amount"])
        if "发票金额" in col_map:
            ws.cell(row, col_map["发票金额"], total_voucher if total_voucher > 0 else "")
        if "备注" in col_map:
            ws.cell(row, col_map["备注"], remark)

        next_row += 1

    wb.save(output_path)
    return summary


# ─── 入口 ──────────────────────────────────────────────────────

def main():
    if len(sys.argv) < 3:
        print("用法: python3 overtime_expense.py <文件夹路径> <输出结算表路径>")
        sys.exit(1)

    base_folder = sys.argv[1]
    output_path = sys.argv[2]

    # 找报销申请表（文件名含"报销申请"）
    app_files = [f for f in os.listdir(base_folder)
                 if f.endswith(".xlsx") and "报销申请" in f]
    if not app_files:
        print(f"错误：未找到报销申请表（文件名需含'报销申请'）")
        sys.exit(1)
    app_path = os.path.join(base_folder, app_files[0])
    print(f"使用报销申请表: {app_files[0]}")

    # 找花名册（文件名含"花名册"）
    roster_files = [f for f in os.listdir(base_folder)
                    if f.endswith(".xlsx") and "花名册" in f]
    if not roster_files:
        print(f"错误：未找到花名册文件（文件名需含'花名册'）")
        sys.exit(1)
    roster_path = os.path.join(base_folder, roster_files[0])
    print(f"使用花名册: {roster_files[0]}")

    # 找结算表模板（文件名含"结算"且不是输出文件）
    xlsx_files = [f for f in os.listdir(base_folder)
                  if f.endswith(".xlsx") and "结算" in f]
    if not xlsx_files:
        print(f"错误：未找到结算表模板（文件名需含'结算'）")
        sys.exit(1)
    template_path = os.path.join(base_folder, xlsx_files[0])
    print(f"使用结算表模板: {xlsx_files[0]}")

    print(f"加载花名册: {os.path.basename(roster_path)} ...")
    roster = load_roster(roster_path)
    print(f"  花名册: {len(roster)} 条记录")

    print(f"读取报销申请表: {os.path.basename(app_path)} ...")
    records = load_application(app_path)
    print(f"  加班车费记录: {len(records)} 条")
    for r in records:
        print(f"    {r['emp_no']} {r['name']} | {r['apply_type']} | {r['total_amount']} | 文件夹:{r['folder_name']}")

    if not records:
        print("无加班车费记录，退出")
        sys.exit(0)

    print(f"\n处理凭证并填写结算表 ...")
    summary = fill_settlement(template_path, output_path, records, roster, base_folder)

    print(f"\n完成！")
    print(f"  总记录: {summary['total']}")
    print(f"  正常: {summary['success']}")
    print(f"  有异常: {summary['errors']}")
    print(f"  输出: {output_path}")


if __name__ == "__main__":
    main()
