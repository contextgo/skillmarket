#!/usr/bin/env python3
"""
open_url.py - 携带 IOA Cookie 打开指定 URL，支持截图和页面内容提取

用法：
    # 直接打开（弹出浏览器窗口）
    python open_url.py --url <URL> --token <ioa_token>

    # 静默截图
    python open_url.py --url <URL> --token <ioa_token> --screenshot output.png

    # 提取页面文本
    python open_url.py --url <URL> --token <ioa_token> --text

    # 不需要 IOA Cookie 的普通页面
    python open_url.py --url <URL>
"""

import argparse
import json
import sys
import requests
from playwright.sync_api import sync_playwright

IOA_TOKEN_API = "https://alpha.xinhulu.com/ioatoken/getCookieByToken"
IOA_COOKIE_DOMAIN = ".xinhulu.com"


def get_ioa_cookies(token: str) -> dict:
    """通过 ioa_token 获取三个 IOA Cookie"""
    resp = requests.post(IOA_TOKEN_API, data={"token": token}, timeout=10)
    result = resp.json()
    if result.get("ret") != 0:
        print(f"[ERROR] 获取 IOA Cookie 失败: {result.get('errmsg')}", file=sys.stderr)
        sys.exit(1)
    return result["data"]


def run(url: str, token: str = None, headless: bool = False,
        screenshot: str = None, dump_text: bool = False):

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=headless)
        context = browser.new_context(
            viewport={"width": 1440, "height": 900},
            ignore_https_errors=True
        )

        # 注入 IOA Cookie
        if token:
            print(f"[INFO] 获取 IOA Cookie (token={token[:20]}...)")
            cookie_data = get_ioa_cookies(token)
            context.add_cookies([
                {"name": "ioa_expire",   "value": cookie_data["ioa_expire"],   "domain": IOA_COOKIE_DOMAIN, "path": "/"},
                {"name": "ioa_sess",     "value": cookie_data["ioa_sess"],     "domain": IOA_COOKIE_DOMAIN, "path": "/"},
                {"name": "ioa_userinfo", "value": cookie_data["ioa_userinfo"], "domain": IOA_COOKIE_DOMAIN, "path": "/"},
            ])
            print("[INFO] IOA Cookie 注入成功")

        page = context.new_page()
        print(f"[INFO] 正在打开: {url}")
        page.goto(url, timeout=30000, wait_until="networkidle")
        print(f"[INFO] 页面标题: {page.title()}")

        # 截图
        if screenshot:
            page.screenshot(path=screenshot, full_page=True)
            print(f"[INFO] 截图已保存: {screenshot}")

        # 提取文本
        if dump_text:
            text = page.inner_text("body")
            print("\n===== 页面文本内容 =====")
            print(text[:3000])  # 最多输出前 3000 字符
            if len(text) > 3000:
                print(f"\n... (共 {len(text)} 字符，已截断)")

        # 非静默模式：监听页面关闭事件，窗口关闭后自动退出
        if not headless and not screenshot and not dump_text:
            print("[INFO] 浏览器已打开，关闭窗口后自动退出")
            page.wait_for_event("close", timeout=0)

        browser.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="携带 IOA Cookie 打开网页")
    parser.add_argument("--url",        required=True,  help="目标 URL")
    parser.add_argument("--token",      default=None,   help="ioa_token，访问 xinhulu.com 内网页面时必填")
    parser.add_argument("--screenshot", default=None,   help="截图保存路径（如 output.png），指定后静默运行")
    parser.add_argument("--text",       action="store_true", help="提取并打印页面文本")
    parser.add_argument("--headless",   action="store_true", help="静默模式（不弹出浏览器窗口）")
    args = parser.parse_args()

    run(
        url=args.url,
        token=args.token,
        headless=args.headless or bool(args.screenshot),
        screenshot=args.screenshot,
        dump_text=args.text,
    )
