---
name: playwright-browser-control
description: 使用内置脚本控制浏览器进行自动化操作，包括打开网页、携带 IOA Cookie 访问内网页面、截图、抓取页面文本等。当用户说"用浏览器打开"、"模拟操作网页"、"截图"、"访问内网页面"、"抓取页面内容"时触发。访问 xinhulu.com 内网页面时自动通过 ioa_token 获取并注入 IOA Cookie，无需额外编写脚本。
---

# Playwright 浏览器控制

## 内置脚本

所有操作通过 `scripts/open_url.py` 执行，**无需每次编写代码**。

脚本路径：`~/.qoder/skills/playwright-browser-control/scripts/open_url.py`

## 环境准备（首次使用）

```bash
pip install playwright requests
playwright install chromium
```

## 使用方式

### 1. 打开内网页面（弹出浏览器窗口）

```bash
python ~/.qoder/skills/playwright-browser-control/scripts/open_url.py \
  --url "https://alpha-internal.xinhulu.com/xadmin/tokenService.php" \
  --token "ioa_ak_erick_xxxxxx"
```

浏览器会弹出并保持打开状态，**关闭窗口后自动退出**，无需手动操作终端。

### 2. 截图（静默运行）

```bash
python ~/.qoder/skills/playwright-browser-control/scripts/open_url.py \
  --url "https://alpha-internal.xinhulu.com/xadmin/tokenService.php" \
  --token "ioa_ak_erick_xxxxxx" \
  --screenshot /tmp/page.png
```

### 3. 提取页面文本内容

```bash
python ~/.qoder/skills/playwright-browser-control/scripts/open_url.py \
  --url "https://alpha-internal.xinhulu.com/xadmin/tokenService.php" \
  --token "ioa_ak_erick_xxxxxx" \
  --text
```

### 4. 普通页面（无需 IOA Cookie）

```bash
python ~/.qoder/skills/playwright-browser-control/scripts/open_url.py \
  --url "https://www.baidu.com"
```

## 参数说明

| 参数 | 必填 | 说明 |
|------|------|------|
| `--url` | 是 | 目标页面地址 |
| `--token` | 否 | ioa_token，访问 xinhulu.com 内网域名时必填 |
| `--screenshot` | 否 | 截图保存路径，指定后静默运行 |
| `--text` | 否 | 提取并打印页面文本（前 3000 字符） |
| `--headless` | 否 | 静默模式，不弹出浏览器窗口 |

## 工作流程

```
用户提供 URL + ioa_token
        ↓
脚本调用 get-ioa-cookie 接口获取三个 Cookie
        ↓
注入 Cookie（domain=.xinhulu.com）
        ↓
打开浏览器访问目标页面
        ↓
执行指定操作（展示 / 截图 / 提取文本）
```

## 注意事项

- 访问 xinhulu.com 内网域名需在内网或 VPN 环境下运行
- 不指定 `--screenshot` 和 `--text` 时，默认弹出浏览器窗口供交互
- Cookie domain 设为 `.xinhulu.com`，覆盖所有子域名
