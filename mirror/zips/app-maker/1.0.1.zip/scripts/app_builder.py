#!/usr/bin/env python3
"""
App Builder - 全栈应用开发工�?自动完成从页面设计、数据库构建到代码生成与部署的全流程
"""

import asyncio
import json
import os
import sys
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict, List, Any
import hashlib

try:
    import httpx
except ImportError:
    print("错误：需要安�?httpx �?)
    print("运行：pip install httpx")
    sys.exit(1)


class ModelConfig:
    """模型配置管理"""
    
    DEFAULT_CONFIG = {
        "default": "claude-code",
        "models": {
            "claude-code": {
                "provider": "anthropic",
                "model": "claude-sonnet-4-20250514",
                "priority": 1,
                "capabilities": ["code", "design", "debug"]
            },
            "qwen": {
                "provider": "aliyun",
                "model": "qwen-max",
                "priority": 2,
                "capabilities": ["code", "design"]
            },
            "gemini": {
                "provider": "google",
                "model": "gemini-2.0-pro",
                "priority": 3,
                "capabilities": ["code", "multimodal"]
            },
            "glm": {
                "provider": "zhipu",
                "model": "glm-4-plus",
                "priority": 4,
                "capabilities": ["code"]
            }
        },
        "fallback": True,
        "maxRetries": 3
    }
    
    def __init__(self, config_path: Optional[Path] = None):
        if config_path is None:
            config_path = Path.home() / ".config" / "app-maker" / "models.json"
        self.config_path = config_path
        self.config = self.load_config()
    
    def load_config(self) -> Dict:
        """加载配置文件"""
        if self.config_path.exists():
            with open(self.config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        return self.DEFAULT_CONFIG.copy()
    
    def save_config(self):
        """保存配置文件"""
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.config_path, 'w', encoding='utf-8') as f:
            json.dump(self.config, f, indent=2, ensure_ascii=False)
    
    def get_model(self, name: Optional[str] = None) -> Dict:
        """获取模型配置"""
        if name is None:
            name = self.config.get("default", "claude-code")
        return self.config["models"].get(name, self.config["models"]["claude-code"])
    
    def get_api_key(self, model_name: str) -> Optional[str]:
        """获取模型 API Key"""
        model = self.config["models"].get(model_name, {})
        return model.get("apiKey") or os.environ.get(f"{model_name.upper()}_API_KEY")


class AppBuilder:
    """App Builder 主类"""
    
    def __init__(self, output_dir: Path, model_config: Optional[ModelConfig] = None):
        self.output_dir = output_dir
        self.model_config = model_config or ModelConfig()
        self.current_model = None
        self.project_config = {}
        
    async def analyze_requirements(self, description: str) -> Dict:
        """阶段 1: 需求分�?""
        print("\n📋 阶段 1: 需求分�?)
        print("-" * 50)
        
        prompt = f"""
你是一个专业的产品经理。请分析以下应用需求，生成完整的产品需求文档�?
用户需求：{description}

请生成以下内容：
1. 产品概述（一句话描述�?2. 目标用户群体
3. 核心功能列表（按优先级排序）
4. 用户故事（至�?5 个）
5. 验收标准
6. MVP 范围定义
7. 技术栈建议

�?JSON 格式返回�?"""
        
        result = await self._call_llm(prompt)
        
        # 生成 PRD 文件
        docs_dir = self.output_dir / "docs"
        docs_dir.mkdir(parents=True, exist_ok=True)
        
        prd_content = self._format_prd(result)
        with open(docs_dir / "prd.md", 'w', encoding='utf-8') as f:
            f.write(prd_content)
        
        print(f"�?PRD 已生成：{docs_dir / 'prd.md'}")
        
        return result
    
    async def design_ui(self, prd: Dict) -> Dict:
        """阶段 2: 页面设计"""
        print("\n🎨 阶段 2: 页面设计")
        print("-" * 50)
        
        prompt = f"""
你是一个专业的 UI/UX 设计师。基于以�?PRD，设计应用的界面和组件结构�?
PRD 摘要�?{json.dumps(prd, ensure_ascii=False, indent=2)[:2000]}

请生成：
1. 用户流程�?2. 页面列表和路由结�?3. 组件树（层次结构�?4. 设计规范（颜色、字体、间距）
5. 关键页面的线框图描述

�?JSON 格式返回�?"""
        
        result = await self._call_llm(prompt)
        
        # 创建设计文件
        design_dir = self.output_dir / "design"
        design_dir.mkdir(parents=True, exist_ok=True)
        
        with open(design_dir / "components.json", 'w', encoding='utf-8') as f:
            json.dump(result, f, indent=2, ensure_ascii=False)
        
        print(f"�?组件设计已生成：{design_dir / 'components.json'}")
        
        return result
    
    async def design_database(self, prd: Dict, ui_design: Dict) -> Dict:
        """阶段 3: 数据库设�?""
        print("\n🗄�?阶段 3: 数据库设�?)
        print("-" * 50)
        
        prompt = f"""
你是一个专业的数据库架构师。基于以下需求设计数据库 Schema�?
PRD 摘要：{json.dumps(prd, ensure_ascii=False)[:1000]}
UI 设计摘要：{json.dumps(ui_design, ensure_ascii=False)[:1000]}

请生成：
1. 实体列表和关系描�?2. 完整�?Prisma Schema（推荐）�?SQL Schema
3. 索引设计
4. 初始数据迁移

�?JSON 格式返回，包�?schema 字段�?"""
        
        result = await self._call_llm(prompt)
        
        # 创建数据库文�?        db_dir = self.output_dir / "database"
        db_dir.mkdir(parents=True, exist_ok=True)
        
        schema = result.get("schema", "")
        schema_file = db_dir / "schema.prisma"
        with open(schema_file, 'w', encoding='utf-8') as f:
            f.write(schema)
        
        print(f"�?Schema 已生成：{schema_file}")
        
        return result
    
    async def generate_code(self, prd: Dict, ui_design: Dict, db_schema: Dict) -> Dict:
        """阶段 4: 代码生成"""
        print("\n💻 阶段 4: 代码生成")
        print("-" * 50)
        
        # 创建项目结构
        project_structure = {
            "src/frontend": ["components/", "pages/", "hooks/", "styles/"],
            "src/backend": ["controllers/", "models/", "routes/", "middleware/"],
            "src/shared": ["types/", "utils/"],
            "tests": ["unit/", "integration/", "e2e/"],
            "infra": ["docker/", "k8s/"]
        }
        
        for dir_path, subdirs in project_structure.items():
            full_path = self.output_dir / dir_path
            full_path.mkdir(parents=True, exist_ok=True)
            for subdir in subdirs:
                (full_path / subdir).mkdir(exist_ok=True)
        
        # 生成前端代码
        print("  生成前端代码...")
        frontend_code = await self._generate_frontend(prd, ui_design)
        self._write_frontend_code(frontend_code)
        
        # 生成后端代码
        print("  生成后端代码...")
        backend_code = await self._generate_backend(prd, db_schema)
        self._write_backend_code(backend_code)
        
        # 生成配置文件
        self._generate_config_files(prd)
        
        print(f"�?代码已生成：{self.output_dir / 'src'}")
        
        return {"frontend": frontend_code, "backend": backend_code}
    
    async def _generate_frontend(self, prd: Dict, ui_design: Dict) -> Dict:
        """生成前端代码"""
        prompt = f"""
你是一个资深的前端工程师。基于以下设计生�?React + TypeScript 代码�?
PRD: {json.dumps(prd, ensure_ascii=False)[:1500]}
UI 设计：{json.dumps(ui_design, ensure_ascii=False)[:1500]}

生成以下文件的内容：
1. package.json
2. tsconfig.json
3. src/App.tsx
4. src/main.tsx
5. 主要组件文件

�?JSON 格式返回，key 为文件名，value 为文件内容�?"""
        return await self._call_llm(prompt)
    
    async def _generate_backend(self, prd: Dict, db_schema: Dict) -> Dict:
        """生成后端代码"""
        prompt = f"""
你是一个资深的后端工程师。基于以下设计生�?Node.js + Express 代码�?
PRD: {json.dumps(prd, ensure_ascii=False)[:1500]}
数据�?Schema: {json.dumps(db_schema, ensure_ascii=False)[:1500]}

生成以下文件的内容：
1. package.json
2. src/index.ts
3. src/controllers/
4. src/routes/
5. src/models/

�?JSON 格式返回，key 为文件名，value 为文件内容�?"""
        return await self._call_llm(prompt)
    
    def _write_frontend_code(self, code: Dict):
        """写入前端代码"""
        frontend_dir = self.output_dir / "src" / "frontend"
        for filename, content in code.items():
            file_path = frontend_dir / filename
            file_path.parent.mkdir(parents=True, exist_ok=True)
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)
    
    def _write_backend_code(self, code: Dict):
        """写入后端代码"""
        backend_dir = self.output_dir / "src" / "backend"
        for filename, content in code.items():
            file_path = backend_dir / filename
            file_path.parent.mkdir(parents=True, exist_ok=True)
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)
    
    def _generate_config_files(self, prd: Dict):
        """生成配置文件"""
        # .gitignore
        gitignore = """
node_modules/
dist/
.env
.env.local
*.log
.DS_Store
coverage/
"""
        with open(self.output_dir / ".gitignore", 'w', encoding='utf-8') as f:
            f.write(gitignore)
        
        # README.md
        readme = f"""# {prd.get('product_name', 'My App')}

{prd.get('description', 'A new application generated by App Builder')}

## 技术栈

- 前端：React + TypeScript
- 后端：Node.js + Express
- 数据库：PostgreSQL

## 快速开�?
```bash
# 安装依赖
npm install

# 开发模�?npm run dev

# 构建
npm run build
```

## 部署

详见 [部署指南](docs/deploy_guide.md)

---

Generated by App Builder on {datetime.now().strftime('%Y-%m-%d %H:%M')}
"""
        with open(self.output_dir / "README.md", 'w', encoding='utf-8') as f:
            f.write(readme)
    
    async def preview(self):
        """阶段 5: 可视化调�?""
        print("\n🔍 阶段 5: 可视化调�?)
        print("-" * 50)
        
        # 创建预览配置
        preview_config = {
            "port": 3000,
            "hotReload": True,
            "debugMode": True
        }
        
        preview_dir = self.output_dir / ".app-maker"
        preview_dir.mkdir(parents=True, exist_ok=True)
        
        with open(preview_dir / "preview.json", 'w', encoding='utf-8') as f:
            json.dump(preview_config, f, indent=2)
        
        print(f"�?预览配置已生�?)
        print(f"   运行：cd {self.output_dir} && npm install && npm run dev")
        
        return preview_config
    
    async def deploy(self, target: str = "vercel"):
        """阶段 6: 部署"""
        print(f"\n🚀 阶段 6: 部署�?{target}")
        print("-" * 50)
        
        # 创建部署配置
        deploy_config = {
            "target": target,
            "timestamp": datetime.now().isoformat(),
            "status": "ready"
        }
        
        deploy_dir = self.output_dir / ".app-maker"
        deploy_dir.mkdir(parents=True, exist_ok=True)
        
        with open(deploy_dir / "deploy.json", 'w', encoding='utf-8') as f:
            json.dump(deploy_config, f, indent=2)
        
        print(f"�?部署配置已生�?)
        print(f"   运行：npx vercel --prod")
        
        return deploy_config
    
    async def _call_llm(self, prompt: str) -> Dict:
        """调用 LLM 生成内容"""
        model_name = self.model_config.config.get("default", "claude-code")
        model = self.model_config.get_model(model_name)
        api_key = self.model_config.get_api_key(model_name)
        
        if not api_key:
            print(f"⚠️  警告：{model_name} �?API Key 未配置，使用模拟响应")
            return self._mock_response(prompt)
        
        max_retries = self.model_config.config.get("maxRetries", 3)
        
        for attempt in range(max_retries):
            try:
                async with httpx.AsyncClient(timeout=60.0) as client:
                    if model["provider"] == "anthropic":
                        response = await self._call_anthropic(client, model, api_key, prompt)
                    elif model["provider"] == "aliyun":
                        response = await self._call_aliyun(client, model, api_key, prompt)
                    elif model["provider"] == "google":
                        response = await self._call_google(client, model, api_key, prompt)
                    elif model["provider"] == "zhipu":
                        response = await self._call_zhipu(client, model, api_key, prompt)
                    else:
                        response = self._mock_response(prompt)
                    
                    return response
                    
            except Exception as e:
                print(f"  尝试 {attempt + 1}/{max_retries} 失败：{e}")
                if attempt == max_retries - 1:
                    print("  使用模拟响应")
                    return self._mock_response(prompt)
        
        return self._mock_response(prompt)
    
    async def _call_anthropic(self, client: httpx.AsyncClient, model: Dict, api_key: str, prompt: str) -> Dict:
        """调用 Anthropic API"""
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        
        payload = {
            "model": model["model"],
            "max_tokens": 4096,
            "messages": [{"role": "user", "content": prompt}]
        }
        
        response = await client.post(
            "https://api.anthropic.com/v1/messages",
            headers=headers,
            json=payload
        )
        response.raise_for_status()
        
        data = response.json()
        content = data["content"][0]["text"]
        return json.loads(content) if content.startswith("{") else {"raw": content}
    
    async def _call_aliyun(self, client: httpx.AsyncClient, model: Dict, api_key: str, prompt: str) -> Dict:
        """调用阿里云百�?API"""
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        
        payload = {
            "model": model["model"],
            "input": {"messages": [{"role": "user", "content": prompt}]}
        }
        
        response = await client.post(
            "https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation",
            headers=headers,
            json=payload
        )
        response.raise_for_status()
        
        data = response.json()
        content = data["output"]["text"]
        return json.loads(content) if content.startswith("{") else {"raw": content}
    
    async def _call_google(self, client: httpx.AsyncClient, model: Dict, api_key: str, prompt: str) -> Dict:
        """调用 Google Gemini API"""
        payload = {
            "contents": [{"parts": [{"text": prompt}]}]
        }
        
        response = await client.post(
            f"https://generativelanguage.googleapis.com/v1beta/models/{model['model']}:generateContent?key={api_key}",
            json=payload
        )
        response.raise_for_status()
        
        data = response.json()
        content = data["candidates"][0]["content"]["parts"][0]["text"]
        return json.loads(content) if content.startswith("{") else {"raw": content}
    
    async def _call_zhipu(self, client: httpx.AsyncClient, model: Dict, api_key: str, prompt: str) -> Dict:
        """调用智谱 AI API"""
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        
        payload = {
            "model": model["model"],
            "messages": [{"role": "user", "content": prompt}]
        }
        
        response = await client.post(
            "https://open.bigmodel.cn/api/paas/v4/chat/completions",
            headers=headers,
            json=payload
        )
        response.raise_for_status()
        
        data = response.json()
        content = data["choices"][0]["message"]["content"]
        return json.loads(content) if content.startswith("{") else {"raw": content}
    
    def _mock_response(self, prompt: str) -> Dict:
        """模拟响应（用于无 API Key 时）"""
        return {
            "product_name": "My App",
            "description": "应用描述",
            "features": ["功能 1", "功能 2", "功能 3"],
            "schema": """
generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

model User {
  id        String   @id @default(uuid())
  email     String   @unique
  name      String?
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
}
"""
        }
    
    def _format_prd(self, result: Dict) -> str:
        """格式�?PRD �?Markdown"""
        return f"""# 产品需求文�?
## 产品概述

{result.get('description', '暂无描述')}

## 目标用户

{result.get('target_users', '暂无')}

## 核心功能

""" + "\n".join([f"- {f}" for f in result.get('features', [])]) + f"""

## 用户故事

""" + "\n".join([f"- {s}" for s in result.get('user_stories', [])]) + """

---

Generated by App Builder
"""


async def main():
    """命令行入�?""
    import argparse
    
    parser = argparse.ArgumentParser(description="App Builder - 全栈应用开发工�?)
    parser.add_argument("command", choices=["init", "generate", "preview", "deploy"], 
                       help="命令")
    parser.add_argument("--output", "-o", type=Path, default=Path("./my-app"),
                       help="输出目录")
    parser.add_argument("--description", "-d", type=str, default="",
                       help="应用描述")
    parser.add_argument("--target", "-t", type=str, default="vercel",
                       help="部署目标")
    
    args = parser.parse_args()
    
    if args.command == "init":
        args.output.mkdir(parents=True, exist_ok=True)
        print(f"�?项目已初始化：{args.output}")
        
    elif args.command == "generate":
        builder = AppBuilder(args.output)
        
        description = args.description
        if not description:
            description = input("请输入应用描述：")
        
        # 执行完整流程
        prd = await builder.analyze_requirements(description)
        ui_design = await builder.design_ui(prd)
        db_schema = await builder.design_database(prd, ui_design)
        code = await builder.generate_code(prd, ui_design, db_schema)
        await builder.preview()
        
        print(f"\n�?应用生成完成：{args.output}")
        print("下一步：cd {args.output} && npm install && npm run dev")
        
    elif args.command == "preview":
        builder = AppBuilder(args.output)
        await builder.preview()
        
    elif args.command == "deploy":
        builder = AppBuilder(args.output)
        await builder.deploy(args.target)


if __name__ == "__main__":
    asyncio.run(main())
