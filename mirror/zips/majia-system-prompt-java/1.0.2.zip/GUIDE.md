# 马甲系统 Java版 新手指南

**SKILL名称**：提示词翻译器

**SKILL描述**：
```
马甲系统 —— AI提示词翻译器

把脑海中的画面，变成专业提示词。

你以为用透了？
试试「帮我规划...」「帮我分析...」「帮我决策...」

输入「新手指南」查看完整功能
```

---

## 一、原理

**Java版是什么**

Java版是马甲系统的本地完整实现。基于Spring Boot框架，适合有Java环境的用户。

**完整三层架构**

```
输入层：用户生活语言描述
    ↓
处理层（Java代码层）：
  安全预检 → 意图分类 → RAG检索 → 上下文压缩 → API调用
    ↓
输出层：
  提示词生成 / 可行性建议 / 多维度分析 / 流程规划 / 直接回答
```

**核心优势**

- **Token消耗低**：前四步在代码层完成，模型只参与最后一步
- **零预设领域**：不在代码中硬编码任何具体领域，从 rules/*.yaml 动态加载
- **REST接口**：提供HTTP接口供其他程序调用
- **本地持久化**：用户偏好和规则自动保存到本地

**代码层意图执行**

```
用户输入 → 安全预检 → 意图分类 → RAG检索 → 上下文压缩 → API调用 → 输出
    ↓            ↓           ↓           ↓           ↓          ↓
  代码执行     代码执行     代码执行     代码执行     代码执行    模型执行
```

**冷启动 vs 热启动**

**冷启动 vs 热启动**
- 冷启动（第一次/切换领域）：查规则→记规则→查约束→记约束→查格式→记格式→输出，Token消耗约500-1000
- 热启动（老用户+同领域）：输入→调用缓存包→输出，Token消耗约50-100

---

## 二、缓存决策流程

**核心概念：从慢查询进化为直觉反应**

Java版的缓存机制让老用户越用越快。从冷启动的"翻手册三遍"，到热启动的"直接调取记忆"。

**用户判断标准**

  - 是否进行过本地缓存（手动启动/自动写入）
  - 启动过本地缓存 → 老用户
  - 未启动过本地缓存 → 新用户

**代码实现**

Java版在代码层实现了完整的决策树：

  - `isWarmUser()`：判断是否为老用户
  - `isSameDomain()`：判断是否为同领域请求
  - `fastLaneProcess()`：快车道流程（热启动）
  - `fullProcess()`：完整流程（冷启动）

**决策树**

  1. 是否为老用户？（有本地缓存记录）
  2. 是否为同领域请求？
  3. 老用户+同领域 → 启用快车道流程
  4. 新用户 或 切换领域 → 启用完整流程

**快车道流程（热启动）**

  1. 构建偏好包 `buildPreferencePack()`
  2. 组装最小化上下文 `buildFastContext()`
  3. 调用模型 `apiCaller.callFastLane()`
  4. 更新会话
  - Token消耗：约 50-100

**完整流程（冷启动）**

  1. RAG检索 `ragSearcher.search()`
  2. 调用模型 `apiCaller.call()`
  3. 更新会话和偏好
  - Token消耗：约 500-1000

**偏好包格式**

  - 常用领域：[domain]
  - 风格偏好：[如有]
  - 术语偏好：[如有]
  - 保持极短，不超过100字符

**降级机制**

  快车道生成内容被用户连续两次否定时，降级回完整流程，并更新缓存以纠正错误偏好。

## 三、关键节点

### 1. 安全预检（代码层）

输入首先经过代码层安全检查。违规内容直接拒绝，不消耗API Token。

检查基于相关法律法规（如《宪法》《网络安全法》《著作权法》等），而非硬编码敏感词列表。

SafetyChecker 类负责执行检查，返回 `{safe: boolean, reason: String}`。

### 2. 意图分类（代码层）

从本地 `rules/*.yaml` 文件动态读取关键词进行匹配。**无硬编码领域分类**。

DomainClassifier 扫描 rules 目录，自动发现所有可用领域。

### 3. RAG检索（代码层）

从本地规则库检索最相关的规则片段，默认返回 top_k=3 条。

**检索精度控制**：

  - min_score（application.yaml）：0.6，最低相关度阈值
  - top_k（application.yaml）：3，最多返回条数
  - min_score（RagSearcher.java）：0.6，低于此值不返回

**检索范围（按优先级）**：

- **高精度字段**：name、keywords、terminology
- **中精度字段**：questions.must_have、trigger_words
- **低精度字段**：description、notes

**评分算法**：
- 关键词命中：0.4分
- 术语命中：0.3分
- 语义相似度：0.3分（模型层）

### 4. 上下文压缩（代码层）

代码层完成上下文组装，只将最小化上下文传给模型。

### 5. API调用（模型层）

组装最小化上下文，调用配置的模型（支持OpenAI/Claude/DeepSeek/智谱/月之暗面等兼容接口）。

ApiCaller 类封装了所有API调用逻辑。

### 6. 本地存储（代码层）

**⚠️ 缓存调用的重要性**

本地缓存是提高用户目标结果达成率的核心功能。每一次规则的保存与调用，都在构建用户的"专属知识库"。

**没有缓存 vs 有缓存**：

  - 无缓存：每次都需要从零描述需求
  - 有缓存：系统记得你的偏好领域、常用术语、历史规则

**缓存调用效果示例**：

```
第一次："帮我画一个赛博朋克风格的机器人"
第二次："画机器人" → 自动识别为"赛博朋克+文生图"
第三次：直接生成优化后的提示词
```

**缓存内容**：

  - sessions/：会话摘要（✅ 自动保存）
  - preferences/：用户偏好（✅ 自动保存）
  - history/：完整对话（❌ 需手动parse）
  - rules/：领域规则（❌ 需手动保存）

**RagSearcher 配置**：

```yaml
rag:
  enable: true
  top-k: 3
  min-score: 0.6
  max-content-length: 2000
```

## 三、快速开始

### Maven依赖

```xml
<dependency>
    <groupId>com.majia</groupId>
    <artifactId>majia-system</artifactId>
    <version>1.0.0</version>
</dependency>
```

### 配置 application.yaml

配置项请参考 application.yaml 文件中的注释说明。

### 运行 MajiaLocal（独立模式）

```java
MajiaLocal majia = new MajiaLocal("./storage");
majia.configureApi(apiConfig);
ObjectNode result = majia.process("你好，我想画一个赛博朋克风格的机器人");
```

### 或运行 MajiaApplication（Web服务模式）

```bash
mvn spring-boot:run
```

访问 http://localhost:8080/api/process 输入处理请求。

## 四、REST接口

### POST /api/process

处理用户请求：

```json
POST /api/process
{
  "input": "你的需求描述"
}
```

响应：

```json
{
  "status": "success",
  "sessionId": "uuid",
  "domain": "文生图",
  "confidence": 0.85,
  "response": "生成结果...",
  "rulesLoaded": 2
}
```

### POST /api/parse

解析对话内容：

```json
POST /api/parse
{
  "text": "对话内容"
}
```

### GET /api/prefs

获取用户偏好：

```json
GET /api/prefs
{
  "domainHistory": ["文生图", "心理咨询"],
  "updated": "2026-04-12T17:00:00",
  "lastSession": "uuid"
}
```

### GET /api/status

获取系统状态：

```json
GET /api/status
{
  "domainsCount": 5,
  "sessionsCount": 12
}
```

## 五、目录结构

```
java/
├── pom.xml                   # Maven配置
├── application.yaml           # Spring Boot配置
└── src/main/java/com/majia/
    ├── MajiaLocal.java        # 独立模式入口
    ├── MajiaApplication.java # Web服务入口
    ├── core/
    │   ├── SafetyChecker.java    # 安全预检
    │   ├── DomainClassifier.java # 意图分类
    │   ├── RAG.java              # RAG检索
    │   ├── ContextCompressor.java # 上下文压缩
    │   └── ApiCaller.java        # API调用
    └── storage/
        ├── rules/               # 领域规则（*.yaml）
        ├── sessions/             # 会话摘要
        ├── preferences/          # 用户偏好
        └── history/             # 对话历史
```

## 六、添加自定义领域

在 `storage/rules/` 目录创建 `*.yaml` 文件：

```yaml
name: 自定义领域
keywords:
  - 关键词1
  - 关键词2
terminology:
  用户词汇: 专业术语
questions:
  must_have:
    - 问题1
    - 问题2
```

DomainClassifier 启动时自动扫描 rules 目录。

## 七、常见问题Q&A

**Q：未配置API能使用吗？**

A：可以。返回结构化上下文供其他AI使用。

**Q：如何添加自定义领域？**

A：在 `storage/rules/` 目录创建 `*.yaml` 文件。系统自动发现。

**Q：Java版支持哪些模型？**

A：支持所有OpenAI兼容接口的模型（OpenAI/Claude/DeepSeek/智谱/月之暗面等）。

**Q：storage_path在哪配置？**

A：在 application.yaml 中配置 storage.path 字段。

**Q：与Python版有什么区别？**

A：功能完全一致。Java版提供REST接口，适合集成到其他Java项目或微服务架构。

## 八、安全说明

Java版在代码层进行安全预检。违规内容基于相关法律法规（《宪法》《网络安全法》《著作权法》等）判断，而非硬编码敏感词列表。

SafetyChecker 类执行检查，违规输入直接拒绝。

## 九、下一步

```bash
mvn spring-boot:run
```
