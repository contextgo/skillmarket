# PPT 风格规范参考

生成 PPT 时遵循此规范，保持视觉一致性。

## 配色体系（白底简洁风格）

```javascript
const C = {
  bg: "FFFFFF",        // 纯白背景
  card: "F8FAFC",      // 卡片背景
  cardBorder: "E2E8F0", // 卡片边框
  white: "0F172A",     // 标题文字（深色）
  secondary: "475569", // 正文文字（中灰）
  muted: "94A3B8",     // 辅助文字（浅灰）
  red: "DC2626",
  orange: "D97706",
  green: "059669",
  cyan: "0891B2",
  blue: "2563EB",
  purple: "7C3AED",
  pink: "DB2777",
  lightBlue: "EFF6FF",
  lightGreen: "ECFDF5",
  lightPurple: "F5F3FF",
  lightOrange: "FFFBEB",
  lightRed: "FEF2F2",
  lightCyan: "ECFEFF",
};

// 阴影：极轻
const makeShadow = () => ({ type: "outer", blur: 4, offset: 1, angle: 135, color: "000000", opacity: 0.08 });
```

## 页面布局规范

- 尺寸：16:9（10" × 5.625"）
- 边距：左右 0.5"，上下 0.35"
- 卡片间距：0.25"-0.3"

### 每页标准头部

```javascript
// 顶部强调线
slide.addShape(pres.shapes.RECTANGLE, { x: 0, y: 0, w: 10, h: 0.04, fill: { color: accentColor } });

// 页码徽章（圆角矩形）
slide.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 0.5, y: 0.35, w: 0.9, h: 0.32, fill: { color: accentColor }, rectRadius: 0.08 });
slide.addText("0X / 04", { /* ... */ });

// 标题
slide.addText("标题", { x: 1.55, y: 0.28, w: 5, h: 0.5, fontSize: 28, color: C.white, bold: true });

// 副标题
slide.addText("副标题描述", { x: 0.5, y: 0.82, w: 9, h: 0.3, fontSize: 11, color: C.muted });
```

### 卡片组件

```javascript
// 标准卡片（带边框 + 顶部强调色条）
slide.addShape(pres.shapes.RECTANGLE, { x, y, w, h, fill: { color: C.card }, line: { color: C.cardBorder, width: 1 }, shadow: makeShadow() });
slide.addShape(pres.shapes.RECTANGLE, { x, y, w, h: 0.04, fill: { color: accentColor } }); // 顶部色条
```

### 标签/徽章组件

```javascript
// 带浅色背景的标签
slide.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, fill: { color: C.lightBlue }, line: { color: C.blue, width: 0.5 }, rectRadius: 0.06 });
slide.addText("标签文字", { /* ... color: C.blue, white text on colored badge ... */ });
```

## 4 页标准结构

### Page 1: 核心问题（2×2 卡片网格）

- 4 个问题卡片，每张含：图标 + 英文标签 + 中文标题 + 一句话描述
- 底部：论文基本信息栏（模型、参数、上下文长度等）

### Page 2: 核心方法（一大两小布局）

- 左侧大卡片（~55%宽）：核心创新
  - 标签 + 标题
  - 流程 pipeline（5步，圆角矩形 + 箭头）
  - Bullet 列表（3-4条，圆点 + 粗体标题 + 描述）
  - 底部：后训练/辅助技术区域（浅色背景条）
- 右上卡片：辅助方法 1
- 右下卡片：辅助方法 2

### Page 3: 实验结论（指标 + 表格 + 判定）

- 顶部 hero 指标条：3-4 个最亮眼的数字（大号 + 标签 + 副标签）
- 中部：左右两个数据表格（带标签 + 标题行浅灰底）
- 底部 verdict 判定卡：图标 + 总体结论 + 4 条判定行（✅/⚠️ + 标题 + 描述）+ 右侧标签组

### Page 4: 研究启示（2×2 卡片网格）

- 4 个方向卡片，每张含：
  - 顶部色条（不同颜色区分）
  - 方向标题
  - 触发点（浅灰小字）
  - 分隔线
  - 3 个具体方向（编号 + 标题 + 简述）

## 字体规范

| 用途 | 字体 | 字号 |
|------|------|------|
| 页面标题 | Microsoft YaHei | 28px, bold |
| 卡片标题 | Microsoft YaHei | 13-15px, bold |
| 副标题/描述 | Microsoft YaHei | 10-11px |
| 表格内容 | Microsoft YaHei | 9px |
| 英文标签 | Consolas | 8-10px |
| hero 数字 | Consolas | 30px, bold |
| 底部信息 | Microsoft YaHei | 8-9px |

## 依赖

生成脚本需要以下 Node.js 包（已安装在 managed workspace）：
- pptxgenjs
- react, react-dom
- sharp
- react-icons

运行命令：
```bash
NODE_PATH=~/.workbuddy/binaries/node/workspace/node_modules ~/.workbuddy/binaries/node/versions/22.12.0/bin/node generate_ppt.js
```
