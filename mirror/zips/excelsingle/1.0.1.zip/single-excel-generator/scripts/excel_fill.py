#!/usr/bin/env python3
"""
Excel 模板填充脚本
根据汇总表数据，按行填充模板单元格，生成多个 Excel 文件并打包
"""

import argparse
import json
import os
import shutil
import tempfile
import zipfile
from pathlib import Path

from openpyxl import load_workbook


def parse_cell(cell_str):
    """解析单元格字符串，如 'A1' -> (row=1, col=1)"""
    col_str = ""
    row_str = ""
    for char in cell_str:
        if char.isalpha():
            col_str += char
        else:
            row_str += char
    if not col_str or not row_str:
        raise ValueError(f"Invalid cell format: {cell_str}")
    
    # 将列字母转换为数字（A=1, B=2, ...）
    col_num = 0
    for char in col_str.upper():
        col_num = col_num * 26 + (ord(char) - ord('A') + 1)
    
    return int(row_str), col_num


def fill_template(template_path, summary_path, cells, output_dir):
    """
    填充模板并生成多个 Excel 文件
    
    Args:
        template_path: 模板 Excel 文件路径
        summary_path: 汇总数据表路径
        cells: 单元格列表，如 ['A1', 'B1', 'C1']
        output_dir: 输出目录
    
    Returns:
        生成的文件数量
    """
    # 加载模板
    template_wb = load_workbook(template_path)
    template_ws = template_wb.active
    
    # 加载汇总表
    summary_wb = load_workbook(summary_path)
    summary_ws = summary_wb.active
    
    # 解析单元格
    cell_positions = [parse_cell(c.strip()) for c in cells]
    
    # 获取汇总表数据行（跳过表头）
    data_rows = []
    for row_idx, row in enumerate(summary_ws.iter_rows(min_row=2, values_only=True), start=2):
        # 检查整行是否为空
        if all(cell is None for cell in row):
            continue
        data_rows.append(row)
    
    if not data_rows:
        raise ValueError("汇总表中没有数据行（仅表头或全部为空）")
    
    # 为每行数据生成一个 Excel 文件
    generated_files = []
    for row_idx, row_data in enumerate(data_rows, start=1):
        # 复制模板
        wb = load_workbook(template_path)
        ws = wb.active
        
        # 填充数据到指定单元格
        for col_idx, cell_pos in enumerate(cell_positions):
            if col_idx < len(row_data):
                value = row_data[col_idx]
                ws.cell(row=cell_pos[0], column=cell_pos[1], value=value)
        
        # 保存文件
        output_file = os.path.join(output_dir, f"template_{row_idx}.xlsx")
        wb.save(output_file)
        generated_files.append(output_file)
    
    return len(generated_files)


def create_zip(output_dir, zip_path):
    """将输出目录中的所有文件打包成 ZIP"""
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for file in sorted(Path(output_dir).glob("*.xlsx")):
            zipf.write(file, file.name)
    return zip_path


def main():
    parser = argparse.ArgumentParser(description="Excel 模板填充工具")
    parser.add_argument("--template", required=True, help="模板 Excel 文件路径")
    parser.add_argument("--summary", required=True, help="汇总数据表路径")
    parser.add_argument("--cells", required=True, help="模板中填充位置的单元格列表，逗号分隔，如 'A1,B1,C1'")
    parser.add_argument("--output", required=True, help="输出目录路径")
    
    args = parser.parse_args()
    
    # 验证文件存在
    if not os.path.exists(args.template):
        print(json.dumps({"status": "error", "message": f"模板文件不存在: {args.template}"}))
        return
    
    if not os.path.exists(args.summary):
        print(json.dumps({"status": "error", "message": f"汇总表文件不存在: {args.summary}"}))
        return
    
    # 创建临时目录用于存放生成的 Excel 文件
    with tempfile.TemporaryDirectory() as temp_dir:
        try:
            # 填充模板
            count = fill_template(
                args.template,
                args.summary,
                args.cells.split(","),
                temp_dir
            )
            
            # 创建 ZIP 包
            zip_name = f"filled_templates_{count}.zip"
            zip_path = os.path.join(args.output, zip_name)
            create_zip(temp_dir, zip_path)
            
            # 返回结果
            result = {
                "status": "success",
                "generated_count": count,
                "zip_path": zip_path,
                "message": f"成功生成 {count} 个 Excel 文件并打包为 {zip_name}"
            }
            print(json.dumps(result, ensure_ascii=False))
            
        except Exception as e:
            print(json.dumps({"status": "error", "message": str(e)}))
            raise


if __name__ == "__main__":
    main()
