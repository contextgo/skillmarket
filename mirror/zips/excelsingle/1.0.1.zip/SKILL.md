---
name: single-excel-generator
description: 根据模板和汇总数据表批量生成Excel文件；用户上传模板+汇总表并指定填充单元格后，按汇总表行数生成对应数量的Excel并打包导出
dependency:
  python:
    - openpyxl==3.1.5
---

# Excel 模板填充工具

## 任务目标

- 本 Skill 用于：批量根据模板生成多个 Excel 文件
- 能力包含：读取模板、遍历汇总表数据、按指定单元格填充、批量生成并打包
- 触发条件：用户需要从一张汇总表和模板表生成多个 Excel 文件

## 前置准备

- 依赖：`openpyxl==3.1.5`（已声明）
- 用户需准备：
  - 模板 Excel 文件（.xlsx）
  - 汇总数据表（.xlsx），第一行是表头，后续是数据
  - 确定要填充的单元格位置（如 A2、B2、C2）

## 操作步骤

1. **读取文件格式**：参考 [references/format.md](references/format.md) 确认模板和汇总表格式
2. **调用脚本生成**：
   ```bash
   python scripts/excel_fill.py \
     --template ./template.xlsx \
     --summary ./summary.xlsx \
     --cells "A2,B2,C2" \
     --output ./output
   ```
3. **获取结果**：脚本返回 JSON，包含生成的 ZIP 文件路径

## 使用示例

- 示例1：基础使用
  - 场景/输入：模板文件 `template.xlsx`、汇总表 `data.xlsx`、填充位置 `A2,B2,C2`、输出到当前目录
  - 预期产出：生成包含多个 Excel 文件的 ZIP 包
  - 关键要点：汇总表每列数据按顺序填入指定的单元格

- 示例2：指定输出目录
  - 场景/输入：需要将结果输出到 `results/` 目录
  - 预期产出：`results/filled_templates_N.zip`
  - 关键要点：输出目录需已存在或程序会自动创建

## 资源索引

- 脚本：见 [scripts/excel_fill.py](scripts/excel_fill.py)（用途：核心填充逻辑，参数说明见下方）
- 参考：见 [references/format.md](references/format.md)（何时读取：确认输入文件格式时）

## 脚本参数说明

| 参数 | 必需 | 说明 |
|------|------|------|
| `--template` | 是 | 模板 Excel 文件路径 |
| `--summary` | 是 | 汇总数据表路径 |
| `--cells` | 是 | 填充单元格列表，逗号分隔，如 `A2,B2,C2` |
| `--output` | 是 | 输出目录路径 |

## 输出格式

脚本输出 JSON 到 stdout：
```json
{
  "status": "success",
  "generated_count": 5,
  "zip_path": "./output/filled_templates_5.zip",
  "message": "成功生成 5 个 Excel 文件并打包为 filled_templates_5.zip"
}
```

错误时：
```json
{
  "status": "error",
  "message": "汇总表中没有数据行"
}
```
