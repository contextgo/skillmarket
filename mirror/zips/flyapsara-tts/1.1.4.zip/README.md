# Flyapsara TTS Skill

**文档版本：1.1.4**（`SKILL.md` 的 `version` 与 `openapi.yaml` 的 `info.version` 与此相同。）

## Overview

Flyapsara TTS 提供文本转语音（异步任务）：创建任务 → 轮询状态 → 获取带时效的下载链接。**`GET /v1/tts/voices`** 在有效 Bearer 下返回平台音色与 **当前 Key 用户的克隆音色**（字段 **`is_user_voice`** / **`owner_user_id`**，列表项含 **`reference_asset_id`** 表示默认参考音）；合成统一使用 **`voice_id`**（**`reference_asset_id` 任务字段已废弃**）。

适用场景：视频旁白 / 配音、语音播报、有声书片段、文本朗读、自有克隆音色等。

### 注册与 API Key

1. 在 Flyapsara **官网**注册并登录（用户门户一般为 **`https://service.flyapsara.com`**）。
2. 打开 **API Key 管理**：路由一般为 **`/account/api-keys`**（需已登录）。
3. 新建 Key，授予 **`voice:read`**、**`tts:task:create`**（或按控制台说明勾选 **`tts:trial:create`** 等）。
4. 复制 **`sk_live_...`**，配置为环境变量 **`FLYAPSARA_API_KEY`**，勿泄露。

---

## Quick Start

以下 **`${BASE}`** 为 HTTP API 根路径。新开终端或只复制某段 `curl` 时，建议先执行：

```bash
export BASE="${FLYAPSARA_BASE_URL:-https://service.flyapsara.com/api}"
```

### 1. 认证

所有需登录或 Key 的请求加请求头：

```http
Authorization: Bearer <YOUR_API_KEY>
```

API Key 在官网登录后于「API Key 管理」创建（`sk_live_...`）。调用 TTS 建议至少包含 **`voice:read`** 与 **`tts:task:create`**（或允许的 **`tts:trial:create`**）。

可选环境变量：

- `FLYAPSARA_BASE_URL`：调用 HTTP API 时的**根路径**（须含网关前缀）。与公开默认环境一致时为 **`https://service.flyapsara.com/api`**；自建或本地对接请改为实际地址（例如 `http://127.0.0.1:3000`）。

### 参数缺省（集成 / Agent）

| 场景 | 建议 |
|------|------|
| 用户未给 **`voice_id`** | 先 **`GET /v1/tts/voices`**，从 **`data.voices[]`**（平台 ∪ 本人克隆）取一项的 **`voice_id`**（勿编造 UUID）。缺省可用列表第一项；**`mode: instruct2` 时须选 `reference_asset_id` 非空** 的条目，避免缺参考音导致创建任务失败。 |
| 用户未给 **`output_format`** | 请求体可省略，服务端缺省 **`mp3`**；需要 wav/pcm 时再写入 body。 |
| **`language`** | **若接口/契约允许省略则不写**；**一旦必须传入或省略导致校验失败，使用 `zh`**。 |
| **`mode`** | 常用 **`zero_shot`**；方言与风格见下文 **`instruct2`**。 |

**最小请求体示例**（默认 mp3；**`voice_id` 须为真实 UUID**）：

```json
{
  "text": "你好，欢迎使用语音合成。",
  "voice_id": "<从 GET /v1/tts/voices 复制>",
  "language": "zh",
  "mode": "zero_shot"
}
```

### 2. 列出音色（获取真实 `voice_id`）

```bash
BASE="${FLYAPSARA_BASE_URL:-https://service.flyapsara.com/api}"
curl -sS "${BASE}/v1/tts/voices" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Accept: application/json"
```

音色在响应 **`data.voices`** 中，每项含 **`voice_id`**（一般为 UUID，勿编造占位符）。

### 3. 创建 TTS 任务

下面示例显式写 **`output_format: wav`**；若省略该字段则与 **`scripts/smoke-tts.sh`** 默认行为一致，服务端按 **`mp3`** 输出。

```bash
curl -sS -X POST "${BASE}/v1/tts/tasks" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Idempotency-Key: $(uuidgen 2>/dev/null || echo demo-$$)" \
  -d '{
    "text": "你好世界",
    "voice_id": "<从上一接口复制的 voice_id>",
    "language": "zh",
    "output_format": "wav",
    "streaming": false,
    "mode": "zero_shot",
    "instruct_text": "",
    "speed": 1
  }'
```

成功时 **`data.task_id`** 为任务 ID；整体形如：

```json
{
  "ok": true,
  "data": {
    "task_id": "...",
    "status": "queued",
    "idem_replay": false,
    "queue": "tts",
    "created_at": "..."
  },
  "error": null
}
```

### 3b. 方言 / 自然语言控制（与网页「高级设置 → 自然语言控制」一致）

- **不要**向 API 增加单独的 **`dialect`** 字段（不存在该字段）。
- 方言、情绪、语速风格等指令一律写入 **`instruct_text`**（自然语言），并设 **`mode: instruct2`**。**`text`** 仅为要朗读的正文。
- **`voice_id`**：**必须**来自本次 **`GET /v1/tts/voices`** 返回项，**不得伪造**；方言由 **`instruct_text`** 描述，**不是**通过「查找某方言专用 voice_id」实现。
- 若用户给的 **`text` 少于 6 个字符**：**优先请用户补充**；自动化、无法交互时可扩写为**不改变原意的完整短句**再调用，否则会命中 **`INVALID_TEXT_TOO_SHORT`**。

限制（服务端校验）：**`instruct_text` 必填**；**`text` 至少 6 个字符**；**`instruct2` 须使用列表中带默认参考音的音色**（通常 **`reference_asset_id` 非空**）；若列表首项无参考音，换选有参考的项。

```bash
curl -sS -X POST "${BASE}/v1/tts/tasks" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Idempotency-Key: $(uuidgen 2>/dev/null || echo demo-$$)" \
  -d '{
    "text": "今日天气不错，适合出门走走。",
    "voice_id": "<从 GET /v1/tts/voices 选取且 reference_asset_id 非空的 voice_id>",
    "language": "zh",
    "output_format": "wav",
    "streaming": false,
    "mode": "instruct2",
    "instruct_text": "请用广东话表达。",
    "speed": 1
  }'
```

方言示例（`scripts/smoke-tts.sh`）：

```bash
export TTS_MODE=instruct2
export TTS_INSTRUCT_TEXT="请用四川话表达。"
export TTS_TEXT="这一段用于方言合成示例，正文须不少于六个字。"
bash scripts/smoke-tts.sh
```

### 4. 查询状态

```bash
curl -sS "${BASE}/v1/tts/tasks/<task_id>" \
  -H "Authorization: Bearer YOUR_API_KEY"
```

关注 **`data.status`**。

**轮询建议（与 `scripts/smoke-tts.sh` 默认策略一致）**

- 间隔约 **2 秒**；最多 **60 次**（约 120s）。超时则停止轮询，向用户返回 **`task_id`** 与最后已知状态。
- **成功终态**：`succeeded`（仅此状态后再调 `/result`）。
- **失败终态**：`failed`、`cancelled`（以及服务端实际使用的同类终态）；中间态含 `queued`、`running`，亦可能出现 `cancel_requested`（取消处理中），应继续轮询直至落入终态。

### 错误与恢复（摘要）

| 情况 | 处理 |
|------|------|
| **401** | Key 缺失或无效；检查 `Authorization` 与环境变量。 |
| **403** | Key scope 不足（如缺 `voice:read`、`tts:task:create`）。 |
| **429** | 配额用尽；稍后重试或换账号。 |
| **`voice_id` 无效 / 参考音报错** | 重新 **`GET /v1/tts/voices`**；**`instruct2`** 时换 **`reference_asset_id` 非空** 的项。 |
| **`GET .../result` 返回 409**（如 `RESULT_NOT_READY`） | 任务未成功；继续轮询状态后再请求。 |
| **轮询超时** | 返回 **`task_id`**，建议稍后手动查询状态。 |
| **`download.url` 过期或下载 403** | **重新 `GET .../result`** 获取新预签名 URL。 |
| **终态为 `failed` / `cancelled`** | 勿当作成功；向用户说明并附上 **`task_id`**。 |

### 交付给用户（Agent）

- **具备落盘/本地文件能力的运行时**（如部分 ChatGPT / Agent 沙箱）：若已将音频**下载到本地**，可向用户返回**本地路径或平台提供的文件引用**。
- **若仅能通过 HTTP 交付**：返回 **`data.result.download.url`** 与过期说明（预签名 URL **非永久**）。
- **落盘命名（可选）**：**`tts_<unix_timestamp>.<ext>`**；目录以**当前工作目录**为准；**`/mnt/data`** 等路径**仅适用于部分沙箱**，其他环境按实际可写目录处理。

### 5. 获取结果（需在 succeeded 后）

```bash
curl -sS "${BASE}/v1/tts/tasks/<task_id>/result" \
  -H "Authorization: Bearer YOUR_API_KEY"
```

成功时 **`data.result.download.url`** 为预签名下载地址（含过期时间 **`expires_at`**），并非固定域名下的永久 `audio_url`：

```json
{
  "ok": true,
  "data": {
    "task_id": "...",
    "status": "succeeded",
    "duration_sec": null,
    "result": {
      "format": "wav",
      "sample_rate_hz": 22050,
      "channels": 1,
      "asset_id": "...",
      "download": {
        "method": "GET",
        "url": "https://...",
        "expires_at": "..."
      }
    }
  },
  "error": null
}
```

若任务未完成，可能返回 **409**（如 `RESULT_NOT_READY`）。

---

## API Summary

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/v1/tts/voices` | 列出音色（需 `voice:read`）；默认含平台与当前用户克隆；管理可用 `?scope=all`（需 `voice:write`） |
| POST | `/v1/me/tts/voices` | 当前用户登记克隆音色（需登录 + `tts:task:create`；网页上传成功后调用） |
| POST | `/v1/tts/tasks` | 创建任务（需 `tts:task:create` 或 `tts:trial:create`）；仅 **`voice_id`** |
| GET | `/v1/tts/tasks/{task_id}` | 查询状态 |
| GET | `/v1/tts/tasks/{task_id}/result` | 获取下载信息 |

---

## 集成验证

在本 Skill 解压或克隆后的目录中执行（需已设置 **`FLYAPSARA_API_KEY`**）。**`scripts/smoke-tts.sh`** 会依次请求音色列表、创建任务、轮询状态、获取 **`/result`**，并在末尾打印预签名 **`download.url`**。依赖 **curl**，以及 **jq** 或 **python3** 之一用于解析 JSON；须使用 **bash**。若从 Windows 复制脚本后出现 CRLF 问题，可同目录执行 **`scripts/run-smoke.sh`**（将调用同目录的 **`smoke-tts.sh`**）。**分发本 Skill 时请将 `smoke-tts.sh` 与 `run-smoke.sh` 一并置于 `scripts/` 目录**；`run-smoke.sh` 使用进程替换 `<(...)`，同样需要 bash。

```bash
export FLYAPSARA_API_KEY="sk_live_..."
bash scripts/smoke-tts.sh
```

若从 Windows 拷贝脚本后出现 `set:` / `$'\r': command not found`，**可选**用包装脚本（仅去掉 CRLF，逻辑仍在 `smoke-tts.sh`）：

```bash
bash scripts/run-smoke.sh
```

或一次性修复换行：`dos2unix scripts/smoke-tts.sh` / `sed -i 's/\r$//' scripts/smoke-tts.sh`。

安装 jq（Debian/Ubuntu 示例）：`sudo apt update && sudo apt install -y curl jq`

### 脚本成功时的响应结构（参考）

脚本会先打印选用的 `voice_id`，再 `POST` 得到 `task_id`，轮询直至 `succeeded`，最后 `GET .../result` 的 JSON 与下面结构类似（字段以实际为准；`download.url` 为**短时有效**的预签名链接，勿长期保存或公开完整 URL）。

```json
{
  "ok": true,
  "data": {
    "task_id": "<uuid>",
    "status": "succeeded",
    "duration_sec": null,
    "result": {
      "format": "wav",
      "sample_rate_hz": 22050,
      "channels": 1,
      "asset_id": "<uuid>",
      "download": {
        "method": "GET",
        "url": "https://<对象存储主机>/<bucket>/.../任务.wav?<查询参数已省略>",
        "expires_at": "<ISO8601>"
      }
    }
  },
  "error": null
}
```

过期后需**再次**请求 `GET /v1/tts/tasks/{task_id}/result` 获取新签名 URL。

---

## Project Structure

```text
.
├── SKILL.md           # AI 触发策略与 YAML 元数据
├── openapi.yaml       # HTTP 契约摘要（version 与上文「文档版本」一致；含 response `examples`）
├── README.md          # 面向用户的调用说明
└── scripts/
    ├── smoke-tts.sh   # 端到端示例（随包分发）
    └── run-smoke.sh   # 换行符兼容入口；须与 smoke-tts.sh 同目录一并分发
```

---

## Notes

- **版本**：**`SKILL.md`**（YAML `version`）、**`openapi.yaml`**（`info.version`）与文首 **文档版本** 应保持同一 semver（当前 **1.1.4**）。
- **`smoke-tts.sh`** 内含完整请求流程；**`run-smoke.sh`** 仅作换行符兼容；默认 **`TTS_OUTPUT_FORMAT=mp3`**（与服务端 body 缺省一致）。
- **方言**：用 **`mode: instruct2`** + **`instruct_text`**，无单独 `dialect` 字段；正文 **`text`** 在 instruct2 下须 ≥6 字符；过短优先请用户补充，自动化时可扩写为不改变原意的短句。
- 响应统一带 **`ok` / `data` / `error`** 外壳；音频地址字段为 **`data.result.download.url`**（非顶层 `audio_url`）。
- 异步任务：须在 **`succeeded`** 后再请求 **`/result`**；轮询见上文「轮询建议」。
- **`download.url` 含签名、有过期时间**；过期后重新调 `/result`，勿把完整 URL 长期暴露在公开场合。
- 未带 `Authorization` 时，部分环境仍允许访客试用（配额与权限不同）；集成请以 API Key 为准。
- 合规与内容政策请遵守服务条款与当地法规。
