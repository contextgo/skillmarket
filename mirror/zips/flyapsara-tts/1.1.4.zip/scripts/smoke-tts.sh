#!/usr/bin/env bash
# Flyapsara TTS 端到端验证脚本（独立可执行）。
# 同目录 run-smoke.sh 为换行符兼容入口（调用本文件）；分发 Skill 时请与 smoke-tts.sh 一并置于 scripts/。
# 依赖：curl；JSON 解析需 jq 或 python3 其一。
# 可选：TTS_MODE=zero_shot|instruct2|cross_lingual（默认 zero_shot）
#       TTS_INSTRUCT_TEXT=风格/方言指令（instruct2 必填，如「请用广东话表达。」）
#       TTS_TEXT=正文（instruct2 时正文须至少 6 个字符）
#       TTS_OUTPUT_FORMAT=mp3|wav|pcm（默认 mp3，与服务端缺省一致）
# 须为 LF 换行。从 Windows 拷贝后若报错，可先：bash scripts/run-smoke.sh
set -eu

if [[ -z "${FLYAPSARA_API_KEY:-}" ]]; then
  echo "请设置环境变量 FLYAPSARA_API_KEY（sk_live_...）" >&2
  exit 1
fi

BASE="${FLYAPSARA_BASE_URL:-https://service.flyapsara.com/api}"
KEY="$FLYAPSARA_API_KEY"

if ! command -v curl >/dev/null 2>&1; then
  echo "需要已安装: curl" >&2
  exit 1
fi

if command -v jq >/dev/null 2>&1; then
  JSON_MODE=jq
elif command -v python3 >/dev/null 2>&1; then
  JSON_MODE=py
else
  echo "需要 jq 或 python3 之一用于解析 JSON。例如: sudo apt install -y jq" >&2
  exit 1
fi

# --- JSON 小工具（stdin 为 JSON 字符串）---
json_first_voice_id() {
  if [[ "$JSON_MODE" == jq ]]; then
    jq -r '.data.voices[0].voice_id // empty' 2>/dev/null
  else
    python3 -c "import json,sys;d=json.load(sys.stdin);v=(d.get('data')or{}).get('voices')or[];print((v[0]or{}).get('voice_id')or'')"
  fi
}

json_task_id() {
  if [[ "$JSON_MODE" == jq ]]; then
    jq -r '.data.task_id // empty' 2>/dev/null
  else
    python3 -c "import json,sys;d=json.load(sys.stdin);print((d.get('data')or{}).get('task_id')or'')"
  fi
}

json_task_status() {
  if [[ "$JSON_MODE" == jq ]]; then
    jq -r '.data.status // empty' 2>/dev/null
  else
    python3 -c "import json,sys;d=json.load(sys.stdin);print((d.get('data')or{}).get('status')or'')"
  fi
}

json_download_url() {
  if [[ "$JSON_MODE" == jq ]]; then
    jq -r '.data.result.download.url // empty' 2>/dev/null
  else
    python3 -c "import json,sys;d=json.load(sys.stdin);print(((d.get('data')or{}).get('result')or{}).get('download')or{}).get('url')or'')"
  fi
}

json_pretty() {
  if [[ "$JSON_MODE" == jq ]]; then
    jq . 2>/dev/null || cat
  else
    python3 -m json.tool 2>/dev/null || cat
  fi
}

build_task_body() {
  local text="$1" vid="$2" mode="$3" instruct="$4" outfmt="$5"
  if [[ "$JSON_MODE" == jq ]]; then
    jq -n \
      --arg text "$text" \
      --arg vid "$vid" \
      --arg mode "$mode" \
      --arg instruct "$instruct" \
      --arg outfmt "$outfmt" \
      '{text:$text, language:"zh", output_format:$outfmt, streaming:false, mode:$mode, instruct_text:$instruct, speed:1, voice_id:$vid}'
  else
    TEXT="$text" VOICE_ID_JSON="$vid" MODE_JSON="$mode" INSTRUCT_JSON="$instruct" OUTFMT_JSON="$outfmt" python3 -c "import json,os;print(json.dumps({'text':os.environ['TEXT'],'language':'zh','output_format':os.environ['OUTFMT_JSON'],'streaming':False,'mode':os.environ['MODE_JSON'],'instruct_text':os.environ['INSTRUCT_JSON'],'speed':1,'voice_id':os.environ['VOICE_ID_JSON']}))"
  fi
}

utf8_char_len() {
  TEXT_LEN_ONLY="$1" python3 -c "import os; print(len(os.environ.get('TEXT_LEN_ONLY','')))"
}

hdr_auth=(-H "Authorization: Bearer ${KEY}" -H "Accept: application/json")

if [[ -z "${VOICE_ID:-}" ]]; then
  echo "== GET ${BASE}/v1/tts/voices，取第一个 voice_id =="
  voices_json="$(curl -sS "${BASE}/v1/tts/voices" "${hdr_auth[@]}")"
  VOICE_ID="$(echo "$voices_json" | json_first_voice_id)"
  if [[ -z "$VOICE_ID" || "$VOICE_ID" == "null" ]]; then
    echo "无法解析 .data.voices[0].voice_id（须为 UUID）。可手动: export VOICE_ID=<uuid>" >&2
    echo "$voices_json" | json_pretty >&2 || echo "$voices_json" >&2
    exit 1
  fi
  echo "使用 voice_id=$VOICE_ID"
fi

TEXT="${TTS_TEXT:-Flyapsara 语音合成验证文案。}"
MODE="${TTS_MODE:-zero_shot}"
INSTRUCT="${TTS_INSTRUCT_TEXT:-}"

case "$MODE" in
  zero_shot|instruct2|cross_lingual) ;;
  *)
    echo "TTS_MODE 须为 zero_shot、instruct2 或 cross_lingual，当前: $MODE" >&2
    exit 1
    ;;
esac

if [[ "$MODE" == "instruct2" ]]; then
  if [[ -z "${INSTRUCT// /}" ]]; then
    echo "TTS_MODE=instruct2 时必须设置 TTS_INSTRUCT_TEXT（自然语言指令，如方言：请用广东话表达。）" >&2
    exit 1
  fi
  tlen="$(utf8_char_len "$TEXT")"
  if [[ "$tlen" -lt 6 ]]; then
    echo "instruct2 模式下正文至少 6 个字符（当前长度 $tlen），请设置更长的 TTS_TEXT" >&2
    exit 1
  fi
fi

OUTFMT="${TTS_OUTPUT_FORMAT:-mp3}"
case "$OUTFMT" in
  wav|mp3|pcm) ;;
  *)
    echo "TTS_OUTPUT_FORMAT 须为 wav、mp3 或 pcm，当前: $OUTFMT" >&2
    exit 1
    ;;
esac

echo "== 请求参数: mode=$MODE output_format=$OUTFMT${INSTRUCT:+ instruct_text=$INSTRUCT}"

body="$(build_task_body "$TEXT" "$VOICE_ID" "$MODE" "$INSTRUCT" "$OUTFMT")"

echo "== POST ${BASE}/v1/tts/tasks =="
idem="smoke-$(date +%s)-$$"
create_res="$(curl -sS -X POST "${BASE}/v1/tts/tasks" \
  "${hdr_auth[@]}" \
  -H "Content-Type: application/json" \
  -H "Idempotency-Key: ${idem}" \
  -d "$body")"

TASK_ID="$(echo "$create_res" | json_task_id)"
if [[ -z "$TASK_ID" || "$TASK_ID" == "null" ]]; then
  echo "创建失败或无法解析 .data.task_id:" >&2
  echo "$create_res" | json_pretty >&2 || echo "$create_res" >&2
  exit 1
fi
echo "task_id=$TASK_ID"

echo "== GET ${BASE}/v1/tts/tasks/:id（轮询：间隔 2s，最多 60 次；终态含 succeeded / failed / cancelled）=="
final_status=""
for _ in $(seq 1 60); do
  st="$(curl -sS "${BASE}/v1/tts/tasks/${TASK_ID}" "${hdr_auth[@]}")"
  status="$(echo "$st" | json_task_status)"
  final_status="$status"
  echo "  status=$status"
  if [[ "$status" == "succeeded" || "$status" == "failed" || "$status" == "cancelled" ]]; then
    break
  fi
  sleep 2
done

if [[ "$final_status" != "succeeded" && "$final_status" != "failed" && "$final_status" != "cancelled" ]]; then
  echo "轮询超时（已达 60×2s），仍非终态。请稍后手动查询或排障。task_id=$TASK_ID last_status=${final_status:-unknown}" >&2
  exit 1
fi
if [[ "$final_status" != "succeeded" ]]; then
  echo "任务未成功结束（status=$final_status）。task_id=$TASK_ID" >&2
  exit 1
fi

echo "== GET ${BASE}/v1/tts/tasks/:id/result（完整 JSON）=="
result_json="$(curl -sS "${BASE}/v1/tts/tasks/${TASK_ID}/result" "${hdr_auth[@]}")"
echo "$result_json" | json_pretty || echo "$result_json"

download_url="$(echo "$result_json" | json_download_url)"
if [[ -n "$download_url" && "$download_url" != "null" ]]; then
  echo ""
  echo "== 预签名下载 URL（短时有效，勿长期公开；过期请重新 GET .../result）=="
  echo "$download_url"
else
  echo "" >&2
  echo "（未解析到 data.result.download.url：任务可能未成功或返回错误体，见上）" >&2
fi
