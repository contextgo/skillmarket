#!/usr/bin/env bash
# 可选入口：当 smoke-tts.sh 为 CRLF 换行时，去掉行尾 \r 再执行。
# 主流程在 smoke-tts.sh；正常情况下可直接运行：bash scripts/smoke-tts.sh
# 分发 Skill 时须与本目录 smoke-tts.sh 一并提供；本脚本通过 "$HERE/smoke-tts.sh" 调用主逻辑。
set -eu
HERE="$(cd "$(dirname "$0")" && pwd)"
exec bash <(sed 's/\r$//' "$HERE/smoke-tts.sh")
