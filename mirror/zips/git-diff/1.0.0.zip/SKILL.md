---
name: git-diff
description: 分析两个 Git commit 之间的类（Swift/OC）、UI/配置文件、图片资源（imageset）变动。适用 iOS 项目。
tags: [git, diff, ios, swift, objective-c, code-review, release-notes]
---

# Git 提交类与图片变动分析

## 触发场景
- 用户说"从 A 到 B 变更"、"比较 A 和 C"、"A -> B 有什么改动"
- 版本发布前对比两个 tag/commit
- PR review 时对照变更范围
- 生成版本变更摘要

## 前置条件
- 目标为 iOS 项目（Swift / Objective-C / 混编）
- 两个 commit hash 或 tag（起点 + 终点）
- 本地 git 仓库

## 核心逻辑
**不是分别查看两个 commit 各自的变动**，而是计算从起点到终点的净差异。

```
错误做法: git show A + git show B（分别输出 A 和 B 的改动）
正确做法: git diff A..B（输出从 A 到 B 的净变化）
```

## 操作步骤

### 1. 获取差异文件列表
```bash
git diff --name-status <commit-A>..<commit-B>
```

### 2. 过滤业务代码（排除第三方）
- **排除** `Pods/`、`build/`、`.build/` 目录下的文件
- 只分析项目自身代码，不分析第三方依赖变动

### 3. 提取类文件
- Swift：过滤 `.swift` 文件，提取文件名（含 `.swift` 扩展名）
- OC：过滤 `.h` / `.m` / `.mm` 文件，提取文件名（含扩展名）
- 混编：同时过滤 `.swift` + `.h` + `.m` + `.mm`

### 4. 提取 UI/配置文件
- `.xib` / `.storyboard`：UI 布局文件
- `.plist`：配置文件
- `.html`：H5 页面文件

### 5. 提取图片资源
- 过滤 `.png` / `.jpg` / `.webp` / `.pdf` 等图片文件
- 合并同一 `imageset` / `appiconset` 目录下的多尺寸图片为单个图库条目
- **排除** `Contents.json`、`.colorset/Contents.json`、`.xcassets/Contents.json`
- 图片以图库维度聚合，如 `AppIcon.appiconset`、`icon.imageset`

### 6. 分类输出
- **操作含义**：A=新增，D=删除，M=修改，R=重命名
- 变动类：带扩展名（.swift / .h / .m / .mm）
- 变动 UI/配置：.xib / .storyboard / .plist / .html
- 变动图片：以图库维度聚合（忽略 Contents.json）
- 每个分类末尾附**净变化**汇总（如：-3 +14，+11 个类）

## 输出格式

```
### 变动类

| 类名 | 操作 |
|------|------|
| AppDelegate.swift | 删除 |
| BTApi.swift | 新增 |
| NetworkManager.h | 新增 |
| NetworkManager.m | 新增 |

净变化: -1 +3，+2 个类

### 变动 UI/配置

| 文件 | 操作 |
|------|------|
| LoginViewController.xib | 新增 |
| Main.storyboard | 修改 |
| Info.plist | 修改 |
| about.html | 新增 |

净变化: +3 新增，1 修改

### 变动图片

| 图库 | 操作 | 说明 |
|------|------|------|
| AppIcon.appiconset | 变更 | 多尺寸图标（60/80/87/120/180/1024.png） |
| icon.imageset | 新增 | 3个尺寸图标（60/120/180.png） |

净变化: 1 变更，1 新增
```

## 注意事项

- **大仓库**：`git diff` 输出可能很长，务必排除 Pods/build 目录后再分析
- **重命名检测**：git 可能将重命名识别为 D+A 而非 R，需注意路径相似的删除+新增是否实际为重命名
- **Bridging Header**：`.h` 文件中可能是桥接头文件而非 OC 类，仍应列出
- **净变化计算**：删除再新增同名文件（路径不同）算删除+新增，不算修改

## 适用项目
- iOS (Swift / Objective-C / 混编)
- Xcode 项目
- CocoaPods / SPM 管理依赖
