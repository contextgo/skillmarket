#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SpringBoot 缓存注解功能
功能：为项目添加基于Redis的缓存注解支持

@author: wql
@date: 2026-04-21
"""

import os
import re
import sys
import urllib.request
from datetime import datetime


class SpringBootCache:

    DEFAULT_VERSIONS = {
        "3.5": {
            "hutool": "5.8.40",
            "redis_starter": "spring-boot-starter-data-redis",
            "aop_starter": "spring-boot-starter-aop"
        },
        "3.2": {
            "hutool": "5.8.40",
            "redis_starter": "spring-boot-starter-data-redis",
            "aop_starter": "spring-boot-starter-aop"
        },
        "3.1": {
            "hutool": "5.8.40",
            "redis_starter": "spring-boot-starter-data-redis",
            "aop_starter": "spring-boot-starter-aop"
        },
        "2.7": {
            "hutool": "5.8.40",
            "redis_starter": "spring-boot-starter-data-redis",
            "aop_starter": "spring-boot-starter-aop"
        }
    }

    MAVEN_CENTRAL_API = "https://repo.maven.apache.org/maven2"

    def __init__(self, artifact_id: str, package_name: str, project_name: str = None, spring_boot_version: str = "3.5", **kwargs):
        if not artifact_id or not package_name:
            raise ValueError("artifactId和packageName不能为空")

        self.artifact_id = artifact_id
        self.package_name = package_name
        self.project_name = project_name or artifact_id
        self.spring_boot_version = spring_boot_version
        self.author = kwargs.get("author", "wql")
        self.create_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        version_key = spring_boot_version.split(".")[0] + "." + spring_boot_version.split(".")[1]
        if version_key not in self.DEFAULT_VERSIONS:
            version_key = "3.5"
        self.version_key = version_key

        self.project_dir = os.getcwd()
        package_path = package_name.replace(".", os.sep)
        self.src_main_java = os.path.join(self.project_dir, "src", "main", "java", package_path)
        self.src_main_resources = os.path.join(self.project_dir, "src", "main", "resources")
        self.pom_path = os.path.join(self.project_dir, "pom.xml")

        self._resolve_versions()

    def _check_network(self) -> bool:
        try:
            req = urllib.request.Request("https://repo.maven.apache.org/maven2", headers={"User-Agent": "Mozilla/5.0"})
            urllib.request.urlopen(req, timeout=3)
            return True
        except Exception:
            return False

    def _fetch_latest_version(self, group_id: str, artifact_id: str) -> str:
        try:
            url = f"{self.MAVEN_CENTRAL_API}/{group_id.replace('.', '/')}/{artifact_id}/maven-metadata.xml"
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=5) as response:
                content = response.read().decode("utf-8")

            release_match = re.search(r'<release>([\d.]+)</release>', content)
            if release_match:
                return release_match.group(1)

            latest_match = re.search(r'<latest>([\d.]+)</latest>', content)
            if latest_match:
                return latest_match.group(1)

            versions = re.findall(r'<version>([\d.]+)</version>', content)
            if versions:
                return versions[-1]

        except Exception:
            pass

        return None

    def _resolve_versions(self):
        print("解析依赖版本...")

        has_network = self._check_network()

        default_hutool = self.DEFAULT_VERSIONS[self.version_key]["hutool"]

        if has_network:
            print("网络可用，搜索最新稳定版本...")

            latest_hutool = self._fetch_latest_version("cn.hutool", "hutool-all")
            if latest_hutool:
                self.hutool_version = latest_hutool
                print(f"  hutool-all: {latest_hutool} (在线)")
            else:
                self.hutool_version = default_hutool
                print(f"  hutool-all: {default_hutool} (默认)")
        else:
            print("网络不可用，使用默认版本...")
            self.hutool_version = default_hutool
            print(f"  hutool-all: {default_hutool}")

    def generate(self):
        print(f"开始添加缓存注解功能...")

        self._update_pom_xml()
        self._update_application_yml()

        self._ensure_package_structure()
        self._generate_cache_result_annotation()
        self._generate_cache_null_value()
        self._generate_cache_key_generator()
        self._generate_cache_result_aspect()
        self._generate_redis_config()

        print(f"\n[OK] 缓存注解功能添加成功!")
        print(f"更新文件:")
        print(f"  - pom.xml")
        print(f"  - src/main/resources/application.yml")
        print(f"生成文件:")
        print(f"  - annotation/CacheResult.java")
        print(f"  - common/CacheNullValue.java")
        print(f"  - util/CacheKeyGenerator.java")
        print(f"  - aspect/CacheResultAspect.java")
        print(f"  - config/RedisConfig.java")

    def _check_dependency_exists(self, content: str, artifact_id: str) -> bool:
        pattern = re.compile(rf'<artifactId>{artifact_id}</artifactId>')
        return bool(pattern.search(content))

    def _update_pom_xml(self):
        print("更新pom.xml...")

        if not os.path.exists(self.pom_path):
            print("错误: pom.xml不存在，请先运行springboot-init")
            sys.exit(1)

        with open(self.pom_path, "r", encoding="utf-8") as f:
            content = f.read()

        hutool_dep = f'''
        <dependency>
            <groupId>cn.hutool</groupId>
            <artifactId>hutool-all</artifactId>
            <version>${{hutool.version}}</version>
        </dependency>'''

        redis_dep = f'''
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>{self.DEFAULT_VERSIONS[self.version_key]["redis_starter"]}</artifactId>
        </dependency>'''

        aop_dep = f'''
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>{self.DEFAULT_VERSIONS[self.version_key]["aop_starter"]}</artifactId>
        </dependency>'''

        if "hutool-all" not in content:
            content = content.replace(
                "</dependencies>",
                hutool_dep + "\n    </dependencies>"
            )

        redis_starter = self.DEFAULT_VERSIONS[self.version_key]["redis_starter"]
        if not self._check_dependency_exists(content, redis_starter):
            content = content.replace(
                "</dependencies>",
                redis_dep + "\n    </dependencies>"
            )

        aop_starter = self.DEFAULT_VERSIONS[self.version_key]["aop_starter"]
        if not self._check_dependency_exists(content, aop_starter):
            content = content.replace(
                "</dependencies>",
                aop_dep + "\n    </dependencies>"
            )

        version_props = f"""        <hutool.version>{self.hutool_version}</hutool.version>"""

        prop_pattern = re.compile(r'<hutool\.version>[\d.]+</hutool\.version>')
        if not prop_pattern.search(content):
            if "</properties>" in content:
                content = content.replace("</properties>", version_props + "\n    </properties>", 1)

        with open(self.pom_path, "w", encoding="utf-8") as f:
            f.write(content)

    def _update_application_yml(self):
        print("更新application.yml...")

        yml_path = os.path.join(self.src_main_resources, "application.yml")

        if not os.path.exists(yml_path):
            print("错误: application.yml不存在，请先运行springboot-init")
            sys.exit(1)

        with open(yml_path, "r", encoding="utf-8") as f:
            content = f.read()

        redis_config = '''
# Redis Configuration
  data:
    redis:
      host: localhost
      port: 6379
      password:
      database: 0
      timeout: 3000ms
      lettuce:
        pool:
          max-active: 8
          max-idle: 8
          min-idle: 0
          max-wait: -1ms
'''

        if "spring.data.redis" not in content:
            if "spring:" in content:
                content = content.replace("spring:", "spring:" + redis_config, 1)

        with open(yml_path, "w", encoding="utf-8") as f:
            f.write(content)

    def _ensure_package_structure(self):
        annotation_dir = os.path.join(self.src_main_java, "annotation")
        aspect_dir = os.path.join(self.src_main_java, "aspect")
        config_dir = os.path.join(self.src_main_java, "config")
        common_dir = os.path.join(self.src_main_java, "common")
        util_dir = os.path.join(self.src_main_java, "util")

        os.makedirs(annotation_dir, exist_ok=True)
        os.makedirs(aspect_dir, exist_ok=True)
        os.makedirs(config_dir, exist_ok=True)
        os.makedirs(common_dir, exist_ok=True)
        os.makedirs(util_dir, exist_ok=True)

    def _generate_cache_result_annotation(self):
        print("生成CacheResult注解...")

        content = f'''package {self.package_name}.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.concurrent.TimeUnit;

/**
 * 缓存结果注解
 * 用于将方法返回值缓存到Redis，支持普通key、SpEL表达式key和默认key三种策略
 *
 * @author {self.author}
 * @date {self.create_time}
 */
@Target({{ElementType.METHOD}})
@Retention(RetentionPolicy.RUNTIME)
public @interface CacheResult {{

    /**
     * 缓存key的前缀
     */
    String keyPrefix() default "project:cache";

    /**
     * 普通缓存key
     */
    String key() default "";

    /**
     * SpEL表达式缓存key
     */
    String spelKey() default "";

    /**
     * 缓存时间
     */
    int cacheTime() default 1;

    /**
     * 缓存时间单位
     */
    TimeUnit cacheTimeUnit() default TimeUnit.HOURS;
}}
'''

        file_path = os.path.join(self.src_main_java, "annotation", "CacheResult.java")
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(content)

    def _generate_cache_null_value(self):
        print("生成CacheNullValue标记类...")

        content = f'''package {self.package_name}.common;

import java.io.Serializable;

/**
 * null值标记类
 * 用于区分"未缓存"和"缓存了null值"两种情况
 *
 * @author {self.author}
 * @date {self.create_time}
 */
public class CacheNullValue implements Serializable {{

    private static final long serialVersionUID = 1L;

    public static final CacheNullValue INSTANCE = new CacheNullValue();

    private CacheNullValue() {{}}
}}
'''

        file_path = os.path.join(self.src_main_java, "common", "CacheNullValue.java")
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(content)

    def _generate_cache_key_generator(self):
        print("生成CacheKeyGenerator工具类...")

        content = f'''package {self.package_name}.util;

import cn.hutool.core.util.StrUtil;
import cn.hutool.crypto.digest.DigestUtil;
import com.example.common.CacheNullValue;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;
import org.springframework.core.ParameterNameDiscoverer;
import org.springframework.core.DefaultParameterNameDiscoverer;

import java.util.Objects;

/**
 * 缓存Key生成器
 * 支持普通key、SpEL表达式key和默认key三种生成策略
 *
 * @author {self.author}
 * @date {self.create_time}
 */
public class CacheKeyGenerator {{

    private static final ExpressionParser EXPRESSION_PARSER = new SpelExpressionParser();
    private static final ParameterNameDiscoverer PARAMETER_NAME_DISCOVERER = new DefaultParameterNameDiscoverer();

    /**
     * 生成缓存key
     *
     * @param keyPrefix key前缀
     * @param key 普通key
     * @param spelKey SpEL表达式key
     * @param className 类全限定名
     * @param methodName 方法名
     * @param args 方法参数
     * @param method 方法对象
     * @return 缓存key
     */
    public String generateKey(String keyPrefix, String key, String spelKey, String className, String methodName, Object[] args, java.lang.reflect.Method method) {{
        if (StrUtil.isNotBlank(key)) {{
            return keyPrefix + ":" + key;
        }}

        if (StrUtil.isNotBlank(spelKey)) {{
            String spelValue = evaluateSpel(spelKey, args, method);
            return keyPrefix + ":" + spelValue;
        }}

        String defaultKey = generateDefaultKey(className, methodName, args);
        return keyPrefix + ":" + defaultKey;
    }}

    /**
     * 生成默认key
     * 格式: 类全限定名:方法名:MD5(参数)
     */
    private String generateDefaultKey(String className, String methodName, Object[] args) {{
        String argsStr = Objects.nonNull(args) && args.length > 0 ? toJsonString(args) : "";
        String rawKey = className + ":" + methodName + ":" + DigestUtil.md5Hex(argsStr);
        return rawKey;
    }}

    /**
     * 解析SpEL表达式
     */
    private String evaluateSpel(String spelKey, Object[] args, java.lang.reflect.Method method) {{
        try {{
            StandardEvaluationContext context = new StandardEvaluationContext();
            if (Objects.nonNull(args) && args.length > 0) {{
                String[] parameterNames = PARAMETER_NAME_DISCOVERER.getParameterNames(method);
                if (Objects.nonNull(parameterNames)) {{
                    for (int i = 0; i < parameterNames.length; i++) {{
                        context.setVariable(parameterNames[i], args[i]);
                    }}
                }}
                context.setRootObject(new SimpleRootObject(args));
            }}

            Object result = EXPRESSION_PARSER.parseExpression(spelKey).getValue(context);
            return Objects.toString(result, "");
        }} catch (Exception e) {{
            return spelKey;
        }}
    }}

    /**
     * 简单根对象，用于SpEL解析
     */
    private static class SimpleRootObject {{
        private final Object[] args;

        public SimpleRootObject(Object[] args) {{
            this.args = args;
        }}

        public Object[] getArgs() {{
            return args;
        }}
    }}

    /**
     * 对象转JSON字符串
     */
    private String toJsonString(Object obj) {{
        if (Objects.isNull(obj)) {{
            return "";
        }}
        try {{
            return cn.hutool.json.JSONUtil.toJsonStr(obj);
        }} catch (Exception e) {{
            return obj.toString();
        }}
    }}

    /**
     * 解包null值
     */
    public Object unwrapNullValue(Object value) {{
        if (value instanceof CacheNullValue) {{
            return null;
        }}
        return value;
    }}
}}
'''

        file_path = os.path.join(self.src_main_java, "util", "CacheKeyGenerator.java")
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(content)

    def _generate_cache_result_aspect(self):
        print("生成CacheResultAspect切面...")

        content = f'''package {self.package_name}.aspect;

import {self.package_name}.annotation.CacheResult;
import {self.package_name}.common.CacheNullValue;
import {self.package_name}.util.CacheKeyGenerator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import java.util.Objects;

/**
 * 缓存结果切面
 * 通过AOP拦截带有@CacheResult注解的方法，实现缓存功能
 *
 * @author {self.author}
 * @date {self.create_time}
 */
@Slf4j
@Aspect
@Component
@RequiredArgsConstructor
public class CacheResultAspect {{

    private final RedisTemplate<String, Object> redisTemplate;
    private final CacheKeyGenerator cacheKeyGenerator = new CacheKeyGenerator();

    @Around("@annotation(cacheResult)")
    public Object around(ProceedingJoinPoint pjp, CacheResult cacheResult) throws Throwable {{
        String cacheKey = generateCacheKey(pjp, cacheResult);

        Object cachedValue = tryGetFromCache(cacheKey);
        if (Objects.nonNull(cachedValue)) {{
            log.debug("从缓存获取成功: {{}}", cacheKey);
            return cacheKeyGenerator.unwrapNullValue(cachedValue);
        }}

        try {{
            Object result = pjp.proceed();

            Object valueToCache = Objects.isNull(result) ? CacheNullValue.INSTANCE : result;
            tryPutToCache(cacheKey, valueToCache, cacheResult.cacheTime(), cacheResult.cacheTimeUnit());

            log.debug("结果已缓存: {{}}", cacheKey);
            return result;
        }} catch (Throwable e) {{
            throw e;
        }}
    }}

    /**
     * 生成缓存key
     */
    private String generateCacheKey(ProceedingJoinPoint pjp, CacheResult cacheResult) {{
        MethodSignature signature = (MethodSignature) pjp.getSignature();
        String className = signature.getDeclaringType().getName();
        String methodName = signature.getName();
        Object[] args = pjp.getArgs();

        java.lang.reflect.Method method = null;
        try {{
            method = pjp.getTarget().getClass().getMethod(methodName, signature.getParameterTypes());
        }} catch (NoSuchMethodException e) {{
            log.warn("获取方法失败: {{}}.{{}}", className, methodName);
        }}

        return cacheKeyGenerator.generateKey(
            cacheResult.keyPrefix(),
            cacheResult.key(),
            cacheResult.spelKey(),
            className,
            methodName,
            args,
            method
        );
    }}

    /**
     * 尝试从缓存获取
     */
    private Object tryGetFromCache(String cacheKey) {{
        try {{
            return redisTemplate.opsForValue().get(cacheKey);
        }} catch (Exception e) {{
            log.warn("从缓存获取失败: {{}}, 错误: {{}}", cacheKey, e.getMessage());
            return null;
        }}
    }}

    /**
     * 尝试存入缓存
     */
    private void tryPutToCache(String cacheKey, Object value, int cacheTime, java.util.concurrent.TimeUnit cacheTimeUnit) {{
        try {{
            redisTemplate.opsForValue().set(cacheKey, value, cacheTime, cacheTimeUnit);
        }} catch (Exception e) {{
            log.warn("存入缓存失败: {{}}, 错误: {{}}", cacheKey, e.getMessage());
        }}
    }}
}}
'''

        file_path = os.path.join(self.src_main_java, "aspect", "CacheResultAspect.java")
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(content)

    def _generate_redis_config(self):
        print("生成RedisConfig配置类...")

        content = f'''package {self.package_name}.config;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.jsontype.impl.LaissezFaireSubTypeValidator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;

/**
 * Redis配置类
 *
 * @author {self.author}
 * @date {self.create_time}
 */
@Configuration
public class RedisConfig {{

    @Bean
    public RedisTemplate<String, Object> redisTemplate(RedisConnectionFactory factory) {{
        RedisTemplate<String, Object> template = new RedisTemplate<>();
        template.setConnectionFactory(factory);

        StringRedisSerializer stringSerializer = new StringRedisSerializer();

        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.setVisibility(PropertyAccessor.ALL, JsonAutoDetect.Visibility.ANY);
        objectMapper.activateDefaultTyping(
            LaissezFaireSubTypeValidator.instance,
            ObjectMapper.DefaultTyping.NON_FINAL,
            JsonTypeInfo.As.PROPERTY
        );
        GenericJackson2JsonRedisSerializer jsonSerializer = new GenericJackson2JsonRedisSerializer(objectMapper);

        template.setKeySerializer(stringSerializer);
        template.setValueSerializer(jsonSerializer);
        template.setHashKeySerializer(stringSerializer);
        template.setHashValueSerializer(jsonSerializer);

        template.afterPropertiesSet();
        return template;
    }}
}}
'''

        file_path = os.path.join(self.src_main_java, "config", "RedisConfig.java")
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(content)


def main():
    if len(sys.argv) < 3:
        print("用法: python cache_annotation.py <artifactId> <packageName> [projectName] [springBootVersion] [author]")
        print("示例: python cache_annotation.py demo com.example Demo 3.5 wql")
        sys.exit(1)

    artifact_id = sys.argv[1]
    package_name = sys.argv[2]
    project_name = sys.argv[3] if len(sys.argv) > 3 else None
    spring_boot_version = sys.argv[4] if len(sys.argv) > 4 else "3.5"
    author = sys.argv[5] if len(sys.argv) > 5 else "wql"

    cache = SpringBootCache(artifact_id, package_name, project_name, spring_boot_version, author=author)
    cache.generate()


if __name__ == "__main__":
    main()
