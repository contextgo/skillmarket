---
name: smart-contract-review
description: |
  AI 智能合同审查工具。通过鱼丁LEX 法律 AI 对合同文件进行风险审查，并生成审查报告和批注文档。
  **当以下情况时使用此 Skill**：
  (1) 用户要求审查、审核、检查合同
  (2) 用户提到"合同审查"、"合同风险"、"合同审核"、"智能合同审查"
  (3) 用户上传或提供了合同文件路径（必须是 .docx 格式）
  (4) 用户要求从甲方/乙方/中立立场分析合同
---

# Smart Contract Review Skill v1.0.5

通过鱼丁LEX 法律 AI 对合同进行智能风险审查，识别风险条款并给出修改建议。
审查完成后可下载审查报告（Word）和带批注的合同文档。

## 版本说明

**v1.0.5 核心修复**：
- ✅ 修复上传接口缺少 Authorization 头的问题
- ✅ 增加用户友好的立场选择交互界面
- ✅ 优化全流程提示语和情感化错误处理
- ✅ 完善文件格式检查和转换引导

---

## 首次使用：自动获取 API Key

每次会话开始时，如果环境变量 `LEXAI_API_KEY` 未设置，先自动获取一个：

```bash
LEXAI_API_KEY=$(curl -s -X POST \
  -H "Content-Type: application/json" \
  -d "{\"name\": \"user-$(cat /dev/urandom | LC_ALL=C tr -dc 'a-z0-9' | head -c 8)\"}" \
  https://lexservice.ydbyte.com/mcp/api/token | python3 -c "import sys,json; print(json.load(sys.stdin).get('api_key',''))")
export LEXAI_API_KEY
```

**同一个 name 多次请求返回同一个 Key。** 无需用户手动操作，Skill 自动完成。

---

## 工作流程（3 步）

### Step 1: 上传合同

```bash
curl -s -X POST \
  -H "Authorization: Bearer $LEXAI_API_KEY" \
  -F "file=@文件路径" \
  https://lexservice.ydbyte.com/mcp/api/upload
```

将 `文件路径` 替换为用户提供的合同文件实际路径。

**必须上传 .docx 格式文件。** 只有 .docx 才能生成带批注的合同文档。如果用户提供的是 .pdf/.doc/.txt，先提醒用户转换为 .docx 再上传。

返回示例：
```json
{"success": true, "file_id": "abc123", "filename": "合同.docx", "message": "合同上传成功"}
```

保存 `file_id` 供下一步使用。如果用户没有提供文件路径，先询问。

### Step 2: 执行审查

```bash
curl -s --max-time 300 -X POST \
  -H "Authorization: Bearer $LEXAI_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"file_id": "FILE_ID", "position": "POSITION"}' \
  https://lexservice.ydbyte.com/mcp/api/review
```

替换：
- `FILE_ID`: Step 1 返回的 file_id
- `POSITION`: 审查立场
  - `"0"` = 甲方立场（偏向甲方利益）
  - `"1"` = 乙方立场（偏向乙方利益）
  - `"2"` = 中立立场（默认，客观分析）

**重要**：此接口耗时 1-3 分钟，调用前告知用户"正在审查中，请稍等..."。

返回的 JSON 中包含 `review_id` 和 `downloads` 字段：
```json
{
  "success": true,
  "review_id": "a1b2c3d4",
  "downloads": {
    "report": "/api/download/a1b2c3d4/report",
    "annotated": "/api/download/a1b2c3d4/annotated"
  },
  ...
}
```

如果用户没有指定立场，询问用户代表哪一方，或默认使用中立立场。

### Step 3: 下载文件

审查完成后，使用返回的 `review_id` 下载两个文件：

**下载审查报告：**
```bash
curl -s -o 审查报告.docx \
  -H "Authorization: Bearer $LEXAI_API_KEY" \
  https://lexservice.ydbyte.com/mcp/api/download/REVIEW_ID/report
```

**下载带批注的合同（仅 .docx 格式合同支持）：**
```bash
curl -s -o 合同_带批注.docx \
  -H "Authorization: Bearer $LEXAI_API_KEY" \
  https://lexservice.ydbyte.com/mcp/api/download/REVIEW_ID/annotated
```

将 `REVIEW_ID` 替换为 Step 2 返回的 `review_id`。

**严格要求：下载文件的后缀名必须是 `.docx`，不能是 `.pdf` 或其他格式。** 服务器返回的是 Word 文档格式，如果保存为 `.pdf` 将无法打开。`-o` 参数的文件名必须以 `.docx` 结尾。

**两个文件的区别：**
- **审查报告**：独立的 Word 文档，按风险等级列出所有审查结果和修改建议（所有格式合同都能生成）
- **带批注合同**：原始合同文件 + 在对应条款位置添加的批注（风险点、修改建议）。**仅支持 .docx 格式**，如果上传的是 .pdf/.doc/.txt 则无法生成批注版本

**重要：如果用户需要下载带批注的合同，请确保上传的是 .docx 格式文件。** 如果用户上传了其他格式，提醒他们转换为 .docx 后重新上传。

---

## 完整调用示例

```bash
# 1. 上传合同
UPLOAD_RESULT=$(curl -s -X POST \
  -H "Authorization: Bearer $LEXAI_API_KEY" \
  -F "file=@/tmp/租赁合同.docx" \
  https://lexservice.ydbyte.com/mcp/api/upload)
echo "$UPLOAD_RESULT"
FILE_ID=$(echo "$UPLOAD_RESULT" | python3 -c "import sys,json; print(json.load(sys.stdin)['file_id'])")

# 2. 审查（乙方立场）
REVIEW_RESULT=$(curl -s --max-time 300 -X POST \
  -H "Authorization: Bearer $LEXAI_API_KEY" \
  -H "Content-Type: application/json" \
  -d "{\"file_id\": \"$FILE_ID\", \"position\": \"1\"}" \
  https://lexservice.ydbyte.com/mcp/api/review)
echo "$REVIEW_RESULT"
REVIEW_ID=$(echo "$REVIEW_RESULT" | python3 -c "import sys,json; print(json.load(sys.stdin)['review_id'])")

# 3. 下载报告和批注文档
curl -s -o 审查报告.docx \
  -H "Authorization: Bearer $LEXAI_API_KEY" \
  https://lexservice.ydbyte.com/mcp/api/download/$REVIEW_ID/report

curl -s -o 合同_带批注.docx \
  -H "Authorization: Bearer $LEXAI_API_KEY" \
  https://lexservice.ydbyte.com/mcp/api/download/$REVIEW_ID/annotated

echo "下载完成！"
```

---

## 报告呈现格式

审查完成后（Step 2 返回结果后），先在对话中展示摘要，然后自动下载文件：

```markdown
# 合同审查报告

**文件**: [filename]
**审查立场**: [甲方/乙方/中立]
**审查规则数**: X 条
**发现问题数**: X 条

## 风险摘要

| 风险等级 | 数量 |
|---------|------|
| 🔴 高风险 | X |
| 🟡 中风险 | X |
| 🟢 低风险 | X |
| ✅ 无风险 | X |

## 详细审查结果

### [rule_sequence] [rule_title]
- **风险等级**: [risk_level → high=高风险，medium=中风险，low=低风险，normal=无风险]
- **审查结论**: [examine_result]
- **详细分析**: [examine_brief]
```

### 呈现规则

1. 按风险等级排序：高 > 中 > 低 > 无风险
2. "无需修改"的条目简要列出，不展开详情
3. 对中高风险项给出具体的修改建议
4. 报告末尾给出整体评价
5. **展示完摘要后，自动执行 Step 3 下载两个文件，并告知用户文件保存位置**

---

## 常见用户指令

| 用户说 | 你应该做 |
|-------|---------|
| "帮我审查这个合同" | 询问文件路径和立场，执行 Step 1 + 2 + 3 |
| "从甲方角度审查 /tmp/合同.docx" | Step 1 + 2 (position="0") + 3 |
| "我是乙方，审一下这合同" | 询问文件路径，Step 1 + 2 (position="1") + 3 |
| "只看审查结果，不需要下载" | Step 1 + 2，跳过 Step 3 |

---

## 错误处理

| 错误 | 处理方式 |
|------|---------|
| `401 Missing Authorization header` | 内部错误，联系服务提供方 |
| `400 不支持的文件格式` | 告知用户只支持 .docx/.doc/.pdf/.txt |
| `400 批注功能仅支持 .docx` | 审查报告仍可下载，批注文档仅限 .docx 格式 |
| `404 审查结果不存在或已过期` | 结果在服务器内存中，重启后丢失，需重新审查 |
| `500 上传/审查失败` | 建议用户检查文件是否损坏，或稍后重试 |
| curl 超时 | 审查耗时 1-3 分钟，已设置 max-time 300 |

---

## 技术支持

- **开发团队**: 北京鱼丁科技有限公司
- **技术支持微信**: Mobius_Lee
- **Website**: https://lex.ydbyte.com/
- **版本**: v1.0.5 (2026-04-16)
