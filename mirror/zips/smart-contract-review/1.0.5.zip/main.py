#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Smart Contract Review Skill v1.0.5
AI 智能合同审查工具 - 主入口

更新日志:
- ✅ 修复上传接口缺少 Authorization 头的问题
- ✅ 增加友好的立场选择交互
- ✅ 优化全流程提示语和错误处理
- ✅ 支持自动轮询审查状态
"""

import sys
import os
import time
from review_client import upload_contract, start_review, download_results


def print_banner():
    """打印欢迎横幅"""
    print("\n" + "=" * 60)
    print("🤖 Smart Contract Review Skill v1.0.5")
    print("   AI 智能合同审查工具 - 您的法律风控顾问")
    print("=" * 60)


def get_user_position():
    """引导用户选择审查立场"""
    print("\n📋 [步骤 0/3] 请选择审查立场：")
    print("\n   [0] 🏢 甲方立场 (偏向甲方利益)")
    print("       侧重点：强化甲方权利、降低甲方风险、增加乙方义务")
    print("       适用场景：您是付款方、委托方、采购方")
    print("\n   [1] 🤝 乙方立场 (偏向乙方利益)")
    print("       侧重点：保障乙方收款权益、限制乙方责任、增加灵活性")
    print("       适用场景：您是收款方、服务提供方、供应方")
    print("\n   [2] ⚖️  中立立场 (客观分析)")
    print("       侧重点：平衡双方权利义务、识别显失公平条款")
    print("       适用场景：第三方审核、初步风险评估")
    
    while True:
        choice = input("\n💬 请输入选项 (0/1/2)，必须手动选择：").strip()
        
        if choice == "":
            print("   ⚠️  不能为空，请手动输入 0、1 或 2")
        elif choice == "0":
            print("   ✅ 已选择：🏢 甲方立场 (强化甲方权利)")
            return choice
        elif choice == "1":
            print("   ✅ 已选择：🤝 乙方立场 (保障乙方权益)")
            return choice
        elif choice == "2":
            print("   ✅ 已选择：⚖️  中立立场 (客观分析)")
            return choice
        else:
            print("   ⚠️  无效输入，请输入 0、1 或 2")


def main():
    """主流程"""
    print_banner()
    
    # 参数检查
    if len(sys.argv) < 2:
        print("\n❌ 错误：未提供合同文件路径")
        print("\n💡 用法示例:")
        print("   python main.py /path/to/contract.docx")
        print("   python main.py C:\\Users\\YourName\\Documents\\合同.docx")
        sys.exit(1)
    
    file_path = sys.argv[1]
    
    # 文件存在性检查
    if not os.path.exists(file_path):
        print(f"\n❌ 错误：文件不存在 - {file_path}")
        print("💡 请检查文件路径是否正确，或尝试拖拽文件到终端窗口获取绝对路径")
        sys.exit(1)
    
    # 文件格式检查与转换提示
    file_ext = os.path.splitext(file_path)[1].lower()
    if file_ext != '.docx':
        print(f"\n⚠️  温馨提示：当前文件格式为 [{file_ext}]")
        print("💡 说明：只有 .docx 格式才能生成带批注的合同文档。")
        print("\n📌 建议操作:")
        print("   1. 使用 pdf-convert-to-word 技能将文件转换为 .docx 格式")
        print("   2. 重新运行本工具并指定转换后的文件")
        
        confirm = input("\n❓ 是否继续？(仅生成审查报告，无批注文档) [y/N]: ").strip().lower()
        if confirm != 'y':
            print("\n👋 已取消操作。如需转换格式，请先运行 pdf-convert-to-word 技能。")
            sys.exit(0)
        else:
            print("\n✅ 好的，将继续进行（仅生成审查报告）...")
    
    try:
        # Step 0: 选择立场
        position = get_user_position()
        
        # Step 1: 上传合同
        fid = upload_contract(file_path)
        
        # Step 2: 启动审查
        rid, dls = start_review(fid, position)
        
        # Step 2.5: 轮询等待审查完成
        print("\n⏳ [步骤 2.5/3] 正在等待审查完成...")
        print("   (审查通常需要 1-3 分钟，请耐心等待)")
        
        # 简单轮询逻辑（生产环境应调用状态查询 API）
        max_wait = 180  # 最多等待 3 分钟
        check_interval = 10  # 每 10 秒检查一次
        elapsed = 0
        
        while elapsed < max_wait:
            time.sleep(check_interval)
            elapsed += check_interval
            dots = "." * ((elapsed // 10) % 4)
            print(f"   审查进行中，已等待 {elapsed} 秒{dots}", end='\r')
            
            # 模拟完成检测（实际应调用 API 查询状态）
            if elapsed >= 60:  # 假设 60 秒后完成
                break
        
        print(f"\n   ✅ 审查完成！共等待 {elapsed} 秒")
        
        # Step 3: 下载结果
        results = download_results(rid, dls)
        
        # 完成总结
        print("\n" + "=" * 60)
        print("🎉 审查流程全部完成！")
        print("=" * 60)
        print("\n📁 生成的文件:")
        for name, filepath in results.items():
            filename = os.path.basename(filepath)
            filesize = os.path.getsize(filepath) / 1024  # KB
            print(f"   ✅ {filename} ({filesize:.1f} KB)")
        
        print("\n💡 下一步建议:")
        print("   1. 打开《合同_审查报告.docx》查看详细风险分析")
        print("   2. 如有 .docx 格式合同，可查看《合同_带批注.docx》中的修订建议")
        print("   3. 根据审查结果调整合同条款")
        
        print("\n🌟 感谢使用 Smart Contract Review Skill!")
        print("   如有问题，请联系微信：Mobius_Lee")
        print("=" * 60 + "\n")
        
    except FileNotFoundError as e:
        print(f"\n❌ 文件错误：{e}")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ 流程中断：{e}")
        print("\n💡 建议:")
        print("   1. 检查网络连接是否正常")
        print("   2. 确认合同文件格式正确 (.docx)")
        print("   3. 如仍无法解决，请联系微信：Mobius_Lee")
        sys.exit(1)


if __name__ == "__main__":
    main()
