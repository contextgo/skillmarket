#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Smart Contract Review Skill v1.0.5 测试套件

测试重点:
1. ✅ 上传接口 Authorization 头是否正确
2. ✅ 立场选择交互功能
3. ✅ 提示语友好性检查
4. ✅ 错误处理完整性
"""

import sys
import os

# 添加当前目录到路径
sys.path.insert(0, os.path.dirname(__file__))


def test_import():
    """测试 1: 模块导入"""
    print("\n" + "=" * 60)
    print("测试 1: 模块导入")
    print("=" * 60)
    
    try:
        from review_client import API_TOKEN, BASE_URL, upload_contract, start_review
        print(f"✅ API Token 已加载：{API_TOKEN[:20]}...")
        print(f"✅ Base URL: {BASE_URL}")
        print("✅ 所有函数导入成功")
        return True
    except Exception as e:
        print(f"❌ 导入失败：{e}")
        return False


def test_auth_header():
    """测试 2: 检查 Authorization 头配置"""
    print("\n" + "=" * 60)
    print("测试 2: Authorization 头配置检查")
    print("=" * 60)
    
    from review_client import HEADERS, API_TOKEN
    
    if "Authorization" not in HEADERS:
        print("❌ 失败：HEADERS 中缺少 Authorization 字段")
        return False
    
    expected_auth = f"Bearer {API_TOKEN}"
    if HEADERS["Authorization"] != expected_auth:
        print(f"❌ 失败：Authorization 值不匹配")
        print(f"   期望：{expected_auth}")
        print(f"   实际：{HEADERS['Authorization']}")
        return False
    
    print(f"✅ Authorization 头配置正确")
    print(f"   值：{HEADERS['Authorization'][:30]}...")
    return True


def test_upload_function_signature():
    """测试 3: 检查 upload_contract 函数签名"""
    print("\n" + "=" * 60)
    print("测试 3: upload_contract 函数检查")
    print("=" * 60)
    
    from review_client import upload_contract
    import inspect
    
    # 获取函数源码
    source = inspect.getsource(upload_contract)
    
    # 检查是否包含 Authorization 相关代码
    if "HEADERS" not in source and "Authorization" not in source:
        print("❌ 失败：upload_contract 函数未使用 HEADERS 或 Authorization")
        print("💡 请确保上传请求包含认证头")
        return False
    
    # 检查是否为 POST 请求
    if "requests.post" not in source:
        print("❌ 失败：upload_contract 未使用 POST 请求")
        return False
    
    # 检查是否使用 files 参数（文件上传）
    if "files=" not in source:
        print("⚠️  警告：未检测到 files 参数，可能不是文件上传")
    
    print("✅ upload_contract 函数实现正确")
    print("   - 使用 POST 请求 ✓")
    print("   - 包含 Authorization 头 ✓")
    print("   - 支持文件上传 ✓")
    return True


def test_main_interactive():
    """测试 4: 检查 main.py 的交互功能"""
    print("\n" + "=" * 60)
    print("测试 4: main.py 交互功能检查")
    print("=" * 60)
    
    main_path = os.path.join(os.path.dirname(__file__), "main.py")
    
    if not os.path.exists(main_path):
        print(f"❌ 失败：main.py 不存在 ({main_path})")
        return False
    
    with open(main_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 检查关键功能
    checks = {
        "立场选择": "get_user_position" in content,
        "输入提示": "请输入选项" in content,
        "默认值处理": "直接回车" in content or 'return "2"' in content,
        "友好提示": "温馨提示" in content or "💡" in content,
        "错误处理": "try:" in content and "except" in content,
        "进度显示": "步骤" in content or "/" in content,
    }
    
    all_passed = True
    for name, passed in checks.items():
        status = "✅" if passed else "❌"
        print(f"   {status} {name}: {'通过' if passed else '缺失'}")
        if not passed:
            all_passed = False
    
    if all_passed:
        print("\n✅ main.py 交互功能完整")
    else:
        print("\n⚠️  main.py 缺少部分交互功能")
    
    return all_passed


def test_error_handling():
    """测试 5: 错误处理检查"""
    print("\n" + "=" * 60)
    print("测试 5: 错误处理完整性检查")
    print("=" * 60)
    
    from review_client import upload_contract, start_review
    import inspect
    
    # 检查 upload_contract 的错误处理
    upload_source = inspect.getsource(upload_contract)
    
    error_checks = {
        "文件存在检查": "os.path.exists" in upload_source or "FileNotFoundError" in upload_source,
        "格式检查": ".docx" in upload_source or "file_ext" in upload_source,
        "HTTP 错误处理": "status_code" in upload_source or "response.status_code" in upload_source,
        "JSON 解析保护": "try:" in upload_source and "except" in upload_source,
        "友好提示": "print" in upload_source and ("⚠️" in upload_source or "温馨提示" in upload_source),
    }
    
    all_passed = True
    for name, passed in error_checks.items():
        status = "✅" if passed else "❌"
        print(f"   {status} {name}: {'通过' if passed else '缺失'}")
        if not passed:
            all_passed = False
    
    if all_passed:
        print("\n✅ 错误处理机制完善")
    else:
        print("\n⚠️  部分错误处理待完善")
    
    return all_passed


def run_all_tests():
    """运行所有测试"""
    print("\n" + "=" * 60)
    print("🧪 Smart Contract Review Skill v1.0.5 测试套件")
    print("=" * 60)
    
    tests = [
        ("模块导入", test_import),
        ("Authorization 头配置", test_auth_header),
        ("upload_contract 函数", test_upload_function_signature),
        ("main.py 交互功能", test_main_interactive),
        ("错误处理", test_error_handling),
    ]
    
    results = []
    for name, test_func in tests:
        try:
            passed = test_func()
            results.append((name, passed))
        except Exception as e:
            print(f"\n❌ 测试异常 [{name}]: {e}")
            results.append((name, False))
    
    # 汇总结果
    print("\n" + "=" * 60)
    print("测试结果汇总")
    print("=" * 60)
    
    passed_count = sum(1 for _, passed in results if passed)
    total_count = len(results)
    
    for name, passed in results:
        status = "✅ 通过" if passed else "❌ 失败"
        print(f"   {status}: {name}")
    
    print(f"\n总计：{passed_count}/{total_count} 项测试通过")
    
    if passed_count == total_count:
        print("\n🎉 所有测试通过！v1.0.5 可以提交安全扫描。")
        return True
    else:
        print(f"\n⚠️  有 {total_count - passed_count} 项测试未通过，请修复后再提交。")
        return False


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
