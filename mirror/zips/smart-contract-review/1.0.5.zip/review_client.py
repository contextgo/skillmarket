import os
import sys
import time
import json
import random
import string
import requests
from dotenv import load_dotenv

# 加载 .env 文件中的配置（可选）
load_dotenv()

# v1.0.4 安全策略：自动获取 API Token
def get_api_token():
    """
    自动获取 API Token
    
    策略：
    1. 优先从环境变量 LEXAI_API_KEY 读取（用户手动配置）
    2. 若未设置，则自动调用 API 生成一个新 Token
    3. 同一个 name 多次请求返回同一个 Key
    """
    # 尝试从环境变量读取
    token = os.getenv("LEXAI_API_KEY")
    if token:
        return token
    
    # 自动生成：使用随机 name 获取 Token
    random_name = "user-" + ''.join(random.choices(string.ascii_lowercase + string.digits, k=8))
    
    try:
        response = requests.post(
            "https://lexservice.ydbyte.com/mcp/api/token",
            headers={"Content-Type": "application/json"},
            json={"name": random_name},
            timeout=10
        )
        
        if response.status_code == 200:
            result = response.json()
            api_key = result.get("api_key")
            if api_key:
                print(f"✅ 已自动获取 API Token (用户：{random_name})")
                return api_key
        
        raise Exception(f"获取 Token 失败：{response.status_code}")
        
    except Exception as e:
        raise EnvironmentError(
            f"⚠️ 无法获取 API Token: {e}\n"
            f"💡 建议：\n"
            f"   1. 检查网络连接\n"
            f"   2. 手动配置环境变量：export LEXAI_API_KEY='your_token'\n"
            f"   3. 联系微信：Mobius_Lee 获取帮助"
        )

# 初始化 API Token
API_TOKEN = get_api_token()
BASE_URL = os.getenv("LEX_BASE_URL", "https://lexservice.ydbyte.com/mcp").rstrip("/")

HEADERS = {
    "Authorization": f"Bearer {API_TOKEN}",
    "ngrok-skip-browser-warning": "1"
}


def upload_contract(file_path):
    """Step 1: 上传合同文件"""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"❌ 文件不存在：{file_path}")
    
    # 检查文件格式
    file_ext = os.path.splitext(file_path)[1].lower()
    if file_ext != '.docx':
        print(f"\n⚠️  温馨提示：当前文件格式为 {file_ext}，但只有 .docx 格式才能生成带批注的合同文档。")
        print("💡 建议：您可以先将文件转换为 .docx 格式，再重新运行本工具。")
        confirm = input("\n是否继续上传？（仅审查报告可用，无法生成批注文档）[y/N]: ").strip().lower()
        if confirm != 'y':
            print("已取消操作。如需转换格式，可使用 pdf-convert-to-word 技能。")
            sys.exit(0)
    
    filename = os.path.basename(file_path)
    print(f"\n📤 [步骤 1/3] 正在上传合同：{filename} ...")
    
    with open(file_path, 'rb') as f:
        response = requests.post(
            f"{BASE_URL}/api/upload",
            headers={**HEADERS, "ngrok-skip-browser-warning": "1"},  # ✅ 添加 Authorization 头
            files={"file": f},
            timeout=60
        )
    
    if response.status_code != 200:
        try:
            error_msg = response.json().get("message", "未知错误")
        except:
            error_msg = response.text
        raise Exception(f"上传失败 (HTTP {response.status_code}): {error_msg}")
    
    result = response.json()
    if not result.get("success"):
        raise Exception(f"上传失败：{result.get('message', '未知错误')}")
    
    file_id = result["file_id"]
    print(f"   ✅ 上传成功！File ID: {file_id}")
    return file_id


def start_review(file_id, position="2"):
    """Step 2: 启动审查任务"""
    position_names = {"0": "甲方", "1": "乙方", "2": "中立"}
    position_name = position_names.get(str(position), "中立")
    
    print(f"\n🔍 [步骤 2/3] 正在提交审查（立场：{position_name}）...")
    
    payload = {"file_id": file_id, "position": str(position)}
    response = requests.post(
        f"{BASE_URL}/api/review",
        headers={**HEADERS, "Content-Type": "application/json"},
        json=payload,
        timeout=300
    )
    
    if response.status_code != 200:
        try:
            error_msg = response.json().get("message", "未知错误")
        except:
            error_msg = response.text
        raise Exception(f"审查提交失败 (HTTP {response.status_code}): {error_msg}")
    
    result = response.json()
    if not result.get("success"):
        raise Exception(f"审查提交失败：{result.get('message', '未知错误')}")
    
    review_id = result["review_id"]
    print(f"   ✅ 审查已启动！Review ID: {review_id}")
    print("   ⏳ 审查通常需要 1-3 分钟，请稍候...\n")
    return review_id, result.get("downloads", {})


def download_results(review_id, downloads, output_dir="."):
    """Step 3: 下载审查报告与批注文档"""
    print("[3/3] 正在下载结果文件 ...")
    os.makedirs(output_dir, exist_ok=True)
    
    downloaded_files = {}
    for name, path in downloads.items():
        url = f"{BASE_URL}{path}"
        filename = f"合同_{'审查报告' if name == 'report' else '带批注'}.docx"
        filepath = os.path.join(output_dir, filename)
        
        try:
            resp = requests.get(url, headers=HEADERS)
            with open(filepath, 'wb') as f:
                f.write(resp.content)
            downloaded_files[name] = filepath
            print(f"      ✅ 已保存：{filename}")
        except Exception as e:
            print(f"      ❌ 下载 {name} 失败：{e}")
            
    return downloaded_files


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法：python review_client.py <合同路径> [立场：0/1/2]")
        sys.exit(1)
    
    file_path = sys.argv[1]
    position = sys.argv[2] if len(sys.argv) > 2 else "2"
    
    try:
        fid = upload_contract(file_path)
        rid, dls = start_review(fid, position)
        # 模拟等待（实际生产中应轮询状态）
        time.sleep(5)
        results = download_results(rid, dls)
        print("\n🎉 全部完成！")
    except Exception as e:
        print(f"\n❌ 发生错误：{e}")
        sys.exit(1)
