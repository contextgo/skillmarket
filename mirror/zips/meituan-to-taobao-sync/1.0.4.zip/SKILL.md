---
name: meituan-to-taobao-sync
description: 将美团外卖商家商品同步到淘宝闪购。当用户请求以下操作时使用：同步美团外卖商品到淘宝闪购、美团商品转淘宝闪购、将美团外卖的商品同步到淘宝、meituan to taobao、CopyMeituanToTaobao。
---

# 美团外卖 → 淘宝闪购 商品同步

## 概述

此技能用于将美团外卖商家的商品批量同步到淘宝闪购商家账号。调用前需确保已完成商家绑定和报备。

## 触发条件

当用户请求以下操作时触发本技能：
- 同步美团外卖商品到淘宝闪购
- 美团商品转淘宝闪购
- 将美团外卖的商品同步到淘宝

## 参数收集（必须）

调用 API 前必须向用户收集以下四个参数，**缺一不可**：

| 参数 | 说明 | 示例 |
|------|------|------|
| `poiCode` | 美团外卖商家唯一编码 | `12345678` |
| `shopId` | 淘宝闪购商家唯一编码 | `88888888` |
| `token` | JWT 认证令牌 | `eyJhbGciOiJIUzI1NiIs...` |
| `deviceId` | 设备唯一标识 | `ABC123DEF456` |

> ⚠️ 如果用户未提供上述任意参数，必须先询问，不得直接调用 API。

## 前置要求

> ⚠️ **报备要求**：调用此 API 之前，必须先联系管理员进行报备，未报备的商家无法使用此功能。
>
> **商家绑定**：在后台系统中需要先完成美团外卖和淘宝闪购商家账号的绑定，才能进行商品同步。

## API 调用

**接口地址：** `POST https://piaoleaf.tiaowulan.com/api/RabbitMQ/CopyMeituanToTaobao`

**请求头：**
- `Content-Type: application/x-www-form-urlencoded`
- `Authorization: Bearer {token}`
- `Device-ID: {deviceId}`

**请求参数（Form 表单）：**
```
poiCode={poiCode}&shopId={shopId}
```

## 执行方式

使用 `exec` 工具发送 PowerShell POST 请求：

```powershell
$token = "{token}"
$deviceId = "{deviceId}"
$poiCode = "{poiCode}"
$shopId = "{shopId}"

$body = "poiCode=$poiCode&shopId=$shopId"

$headers = @{
    "Authorization" = "Bearer $token"
    "Device-ID" = "$deviceId"
}

Invoke-RestMethod `
    -Uri "https://piaoleaf.tiaowulan.com/api/RabbitMQ/CopyMeituanToTaobao" `
    -Method Post `
    -Body $body `
    -ContentType "application/x-www-form-urlencoded" `
    -Headers $headers
```

## 响应处理

| 状态码 | 含义 | 处理方式 |
|--------|------|----------|
| 成功 | 同步已触发 | 告知用户同步已触发，显示返回结果 |
| 401/403 | Token 无效或已过期 | 提示用户重新获取 Token |
| 其他错误 | 请求失败 | 显示错误信息，建议检查 poiCode 是否正确或联系管理员 |

## 敏感信息保存

Token 与 deviceId 使用后应保存到系统变量或记忆文件中，供后续使用：

- 检查 `MEMORY.md` 或 `TOOLS.md` 是否已有保存的 token/deviceId
- 如有新值，更新上述文件中的对应字段
