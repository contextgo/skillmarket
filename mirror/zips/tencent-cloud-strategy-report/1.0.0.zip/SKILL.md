---
name: tencent-cloud-strategy-report
description: 腾讯云销售专属的客户战略分析报告生成工具。当用户需要分析客户公司、生成战略分析报告、了解行业情况、识别决策链条时使用。触发关键词包括"战略分析"、"客户画像"、"SWOT分析"、"决策链条"、"CEO痛点"、"行业分析"、"客户报告"等。自动生成MD/Word/HTML/PDF四种格式的完整报告。
---

# 腾讯云客户画像两步法

快速生成客户战略分析报告的专业工具,帮助销售人员从产品推销者升级为战略对话者。

## ⚠️ 重要提示 - 必须生成四种格式

**每次执行必须按顺序生成以下四种格式的报告**:

1. ✅ **Markdown格式** (`{公司名}_战略分析报告.md`) - 完整详细版本
   - 位置: 工作目录根目录
   - 内容: 包含完整的分析内容、数据和建议

2. ✅ **Word格式** (`{公司名}_战略分析报告.docx`) - 专业排版版本
   - 位置: 工作目录根目录
   - 生成方式: 使用docx skill,从Markdown转换
   - 样式: 专业商务文档格式

3. ✅ **HTML格式** (`{公司名}_战略分析报告_HTML/` 文件夹) - 电影级滚动式网站
   - 位置: 工作目录根目录
   - **必须使用interactive-showcase-site skill生成**
   - 技术栈: React + Vite + Tailwind CSS + Framer Motion
   - 特性: 滚动动画、章节导航、深色主题、响应式设计

4. ✅ **PDF格式** (`{公司名}_战略分析报告.pdf`) - 从HTML服务器生成
   - 位置: 工作目录根目录
   - **必须使用Playwright从运行中的HTML服务器生成,禁止手动生成**
   - 格式: A4纸、长图模式、精确分页
   - 最后**必须打开PDF供用户查看**

**执行流程**:
1. 生成Markdown → 2. 转换为Word → 3. 构建HTML项目并启动服务器 → 4. 使用Playwright访问HTML服务器生成PDF → 5. 打开PDF

**故障处理**:
- 如果某种格式生成失败,必须排查问题并重新生成
- 不得跳过任何格式
- 确保所有文件都生成在正确位置

## 工作流程

### 第一步:信息收集 ⚠️ 以下每一步必填 - 不可跳过

使用web_search收集三类信息:

1. **行业分析**
   - 搜索"{行业名} 市场规模 行业分析 2025"
   - 搜索"{行业名} 竞争对手 Top 5"
   - 搜索"{行业名} 政策 扶持 中国 2025"

2. **公司分析**
   - 搜索"{公司名} 公司 业务 融资"
   - 搜索"{公司名} CEO 创始人"
   - 搜索"{公司名} 产品 技术"

3. **关键人物分析** ⚠️ 必填 - 不可跳过
   - 搜索"{公司名} 创始人 CEO 董事长"
   - 搜索"{公司名} CTO COO 高管团队"
   - 搜索"{公司名} 公司简介 核心团队"
   - 搜索"{公司名} 董监高 股东"
   - 输出格式要求:
     - 核心高管团队表格(姓名、职位、背景资历、关注焦点)
     - 创始人/核心团队背景详细介绍
     - 董监高结构分析
     - 决策风格推断
     - 关键人物沟通策略

### 第二步:战略分析 ⚠️ 以下每一步必填 - 不可跳过

基于收集的信息进行深度分析:

#### CEO痛点提炼：需要结合以上人物分析和公司业务分析内容

分析维度:
- 规模化与成本控制矛盾
- 护城河构建压力
- 人才争夺与团队稳定性
- 市场竞争威胁
- 技术迭代风险

提炼3个核心痛点,每个痛点包含:
- 痛点描述
- 深层原因
- 可能的解决方向

#### 行业术语速查表

收集10个必知术语:
- 行业专业术语(如HMD、FOV、波导)
- 技术术语(如端侧AI、SLAM、6DoF)
- 产品术语(如MR、AR、XR)

格式: `| 序号 | 术语 | 通俗解释 | 使用场景示例 |`

#### SWOT分析

分析四个维度:需要结合以上人物分析和公司业务分析内容
- **优势(S)**: 技术、团队、产品、布局
- **劣势(W)**: 品牌、产能、生态、渠道
- **机会(O)**: 市场、政策、竞争、场景
- **威胁(T)**: 巨头、技术、监管、价格战

**战略机会识别**: 基于SWOT,识别2026年最佳战略机会和具体路径。

#### 决策链条分析：需要结合以上人物分析和公司业务分析内容

**Champion识别**:
- 通常角色: COO、市场VP、业务负责人
- 特征: 需要业绩突破、推动业务拓展
- 支持动机: 扩大营收、证明能力、获取资源
- 沟通策略: 提供案例、ROI数据、打包方案

**Blocker识别**:
- 通常角色: CTO、财务总监、风险管控者
- 特征: 关注风险、成本、技术实现
- 阻碍动机: 担心定制化、技术依赖、成本超支
- 应对策略: 标准化方案、技术支持、成功案例

### 第三步:生成报告 ⚠️ 以下每一步必填 - 不可跳过

按顺序生成四种格式报告:

#### 1. Markdown报告

**文件名**: `{公司名}_战略分析报告.md`

**结构**:
```markdown
# {公司名} 战略分析报告

**生成时间**: YYYY年MM月DD日  
**分析对象**: {公司名}  
**所属行业**: {行业名}

---

## 📊 第一部分:行业深度分析

### 一、市场规模与增长趋势
### 二、竞争格局分析
### 三、政策环境扫描
### 四、关键人物分析  

---

## 🎯 第二部分:AI战略顾问

### 一、CEO级业务痛点提炼
### 二、行业黑话速查表

---

## 🎯 第三部分:客户画像两步法

### 第一步:战略穿透(SWOT分析)
### 第二步:决策链条分析

---

## 💡 战略对话示例

## 📌 总结与建议
```

#### 2. Word报告 

**文件名**: `{公司名}_战略分析报告.docx`

**操作流程**:
1. 使用docx skill
2. 基于Markdown内容生成Word文档
3. 设置专业排版:
   - 标题1: 16pt,加粗,深色
   - 标题2: 14pt,加粗,蓝色
   - 正文: 12pt,常规
   - 表格: 网格线,浅色背景
4. 添加页眉: "{公司名}战略分析报告"
5. 添加页脚: "生成时间: YYYY-MM-DD"

**注意**: 必须先检查docx skill是否已加载,未加载则使用use_skill加载。

#### 3. HTML报告

**文件名**: `{公司名}_战略分析报告.html`

**操作流程**:
1. 使用interactive-showcase-site skill
2. 创建React项目结构
3. 基于模板生成内容
4. 启动开发服务器(端口5173-5179中可用端口)
5. **重要**: 等待服务器启动完成(使用curl检查)
6. 可选: 打包生成静态HTML文件

**核心特性**:
- 电影级滚动动画
- 深色主题(支持切换)
- 响应式设计
- 章节导航
- 进度条

**注意**: 
- 必须先检查interactive-showcase-site skill是否已加载,未加载则使用use_skill加载
- PDF生成依赖HTML服务器,必须确保服务器正常运行
- 静态HTML文件需要配套的assets目录

#### 4. PDF报告

**文件名**: `{公司名}_战略分析报告.pdf`

> ⚠️ **重要警告 - 错误案例**:
> 
> **禁止使用以下错误方式生成PDF**:
> - ❌ 使用Python reportlab库手动生成PDF
> - ❌ 使用其他PDF生成库手动编写内容
> - ❌ 直接从Markdown转换为PDF
> 
> **正确做法**: 必须使用Playwright从HTML服务器截图生成,确保PDF内容与HTML完全一致。
> 
> **错误后果**: PDF内容与HTML不一致,样式丢失,违反工作流规范。

**操作流程**:

**优先方案:从静态HTML文件生成PDF(推荐)**

> ⚠️ **重要**: 必须先修改HTML文件的`@media print`样式,设置hero的`min-height: auto`,避免首页留白过多!

1. **检查并修改HTML文件的CSS**(如果需要):
   ```bash
   # 检查HTML文件中的@media print部分
   grep -A 15 "@media print" {公司名}_战略分析报告.html
   
   # 如果hero使用了min-height: 100vh,需要修改为auto
   # 参考上方"首页和末尾留白优化关键配置"中的CSS代码
   ```

2. **生成PDF**:
   ```python
   import asyncio
   from playwright.async_api import async_playwright

   async def generate_pdf():
       async with async_playwright() as p:
           browser = await p.chromium.launch()
           
           # 创建页面,设置合适的视口大小
           page = await browser.new_page(
               viewport={'width': 1200, 'height': 1600},
               device_scale_factor=2  # 提高渲染质量
           )
           
           # ✅ 关键: 启用print媒体类型
           await page.emulate_media(media='print')
           
           # 使用file://协议加载本地HTML文件
           await page.goto('file:///{工作目录}/{公司名}_战略分析报告.html', wait_until='networkidle')
           await page.wait_for_timeout(2000)
           
           # 滚动加载所有内容
           for i in range(5):
               await page.evaluate('window.scrollTo(0, document.body.scrollHeight)')
               await page.wait_for_timeout(500)
           
           await page.evaluate('window.scrollTo(0, 0)')
           await page.wait_for_timeout(1000)
           
           # ✅ 关键: 获取每个section的实际高度,精确计算
           sections_info = await page.evaluate('''
               () => {
                   const sections = document.querySelectorAll('section');
                   const info = [];
                   let totalHeight = 0;
                   
                   sections.forEach((section, index) => {
                       const rect = section.getBoundingClientRect();
                       const bottom = rect.bottom + window.scrollY;
                       totalHeight = bottom;
                   });
                   
                   return {
                       sections: info,
                       totalHeight: totalHeight
                   };
               }
           ''')
           
           # ✅ 关键: 只添加50px缓冲
           total_height = sections_info['totalHeight'] + 50
           
           await page.pdf(
               path='{公司名}_战略分析报告.pdf',
               width='1200px',
               height=f'{total_height}px',
               print_background=True,
               margin={
                   'top': '0px',      # 首页顶部无边距
                   'bottom': '0px',   # 末尾底部无边距
                   'left': '0px',     # 左侧无边距
                   'right': '0px'     # 右侧无边距
               },
               scale=1.0,  # 不缩放,使用原始大小
               prefer_css_page_size=False
           )
           await browser.close()

   asyncio.run(generate_pdf())
   ```

**备选方案:从HTML服务器生成PDF**

> ⚠️ **重要**: 必须先检查端口是否被其他项目占用!

1. 检查HTML服务器端口并验证内容:
   ```bash
   # 检查端口是否监听
   lsof -ti:5173,5174,5175,5176,5177,5178,5179
   
   # 验证服务器返回的内容是否正确(避免端口冲突)
   curl -s http://localhost:5174 | grep "{公司名}"
   ```
2. 如果端口被占用或内容错误,启动新端口:
   ```bash
   # 停止旧进程
   kill -9 {PID}
   
   # 启动新服务器(使用不同端口)
   npm run dev -- --port 5175
   ```
3. 等待HTML服务器启动完成
4. 使用Playwright生成长图PDF

**命令示例**:

**方案A: 从静态HTML文件生成(推荐)**

```bash
# 1. 检查HTML文件是否存在
ls -lh {公司名}_战略分析报告.html

# 2. 检查HTML文件的@media print样式
grep -A 15 "@media print" {公司名}_战略分析报告.html

# 3. 如果hero使用了min-height: 100vh,修改为auto
# (参考上方"首页和末尾留白优化关键配置"中的CSS代码)

# 4. 直接从本地文件生成PDF
/usr/bin/python3 -c "
import asyncio
from playwright.async_api import async_playwright

async def generate_pdf():
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        
        # 创建页面
        page = await browser.new_page(
            viewport={'width': 1200, 'height': 1600},
            device_scale_factor=2
        )

        # ✅ 启用print媒体类型
        await page.emulate_media(media='print')

        # 加载本地HTML文件
        await page.goto('file:///{工作目录}/{公司名}_战略分析报告.html', wait_until='networkidle')
        await page.wait_for_timeout(2000)
        
        # 滚动加载所有内容
        for i in range(5):
            await page.evaluate('window.scrollTo(0, document.body.scrollHeight)')
            await page.wait_for_timeout(500)
        
        await page.evaluate('window.scrollTo(0, 0)')
        await page.wait_for_timeout(1000)
        
        # ✅ 关键: 获取每个section的实际高度
        sections_info = await page.evaluate('''
            () => {
                const sections = document.querySelectorAll('section');
                const info = [];
                let totalHeight = 0;
                
                sections.forEach((section, index) => {
                    const rect = section.getBoundingClientRect();
                    const height = rect.height;
                    const top = rect.top + window.scrollY;
                    const bottom = rect.bottom + window.scrollY;
                    
                    info.push({
                        index: index,
                        id: section.id,
                        className: section.className,
                        height: height,
                        top: top,
                        bottom: bottom
                    });
                    
                    totalHeight = bottom;
                });
                
                return {
                    sections: info,
                    totalHeight: totalHeight
                };
            }
        ''')
        
        # ✅ 关键: 只添加50px缓冲
        total_height = sections_info['totalHeight'] + 50
        section_count = len(sections_info['sections'])
        
        await page.pdf(
            path='{公司名}_战略分析报告.pdf',
            width='1200px',
            height=f'{total_height}px',
            print_background=True,
            margin={
                'top': '0px',
                'bottom': '0px',
                'left': '0px',
                'right': '0px'
            },
            scale=1.0,
            prefer_css_page_size=False
        )
        
        await browser.close()
        print(f'✅ PDF已优化生成:')
        print(f'   总高度: {total_height}px (内容高度 + 50px缓冲)')
        print(f'   包含 {section_count} 个section')
        print(f'   首页和末尾留白已最小化')

asyncio.run(generate_pdf())
"

# 5. 验证PDF生成成功(文件大小应>100KB)
ls -lh {公司名}_战略分析报告.pdf
```

**方案B: 从HTML服务器生成(需要检查端口冲突)**

```bash
# 1. 检查HTML服务器是否运行
lsof -ti:5173,5174,5175,5176,5177,5178,5179

# 2. 验证服务器内容是否正确(避免端口冲突!)
curl -s http://localhost:5174 | grep "{公司名}"

# 3. 如果端口冲突或内容错误,启动新服务器
npm run dev -- --port 5175

# 4. 生成长图PDF
```

**关键要求**:
- ✅ **必须先确认HTML服务器正在运行** (使用curl检查)
- ✅ **必须使用长图模式** - 一张完整的纵向长图,不使用A4分页
- ✅ **必须启用print媒体类型** - `await page.emulate_media(media='print')`触发@media print样式
- ✅ **必须修改HTML的CSS** - 设置hero的`min-height: auto`,使用固定padding
- ✅ **必须精确计算高度** - 获取每个section的实际高度,只添加50px缓冲
- ✅ **首页和末尾优化配置**:
  - 视口高度设置为1600px
  - 使用device_scale_factor=2提高渲染质量
  - 使用scale=1.0不缩放,保持原始大小
  - 使用0边距,让内容填充整个页面
  - hero section设置`min-height: auto`和`padding: 80px 60px`
  - conclusion section设置`padding: 60px 60px`
- ✅ 固定宽度1200px,确保内容完整呈现
- ✅ 生成后自动打开PDF供查看

**PDF生成常见问题与解决方案**:

| 问题 | 症状 | 原因 | 解决方案 |
|------|------|------|----------|
| 首页标题显示不全 | PDF首页标题文字被截断或显示不完整 | 视口高度不足或hero顶部padding太小 | 增加视口高度至1600px,hero顶部padding至少70px |
| 首页留白太多 | PDF首页上下留白过大(>200px) | `@media print`中hero使用`min-height:100vh` | 设置`min-height:auto`,padding:70px 60px 10px 60px |
| 首页和第二页间距过大 | section之间间距>50px | section的padding过大+page-break-after属性 | 减少section padding到30px,移除page-break-after |
| 末尾留白太多 | PDF末尾空白>100px | 总高度计算添加了过大缓冲(200px) | 只添加50px缓冲,使用0边距,底部padding 10px |
| 首页标题不显示 | PDF首页标题空白或黑色 | CSS渐变文字在print模式下不支持 | 在`@media print`中禁用渐变,使用固定颜色 |
| 末尾空白太多 | PDF末尾200-300px空白 | `body.scrollHeight`包含隐藏元素 | 计算sections实际高度,排除隐藏元素 |
| PDF文件太小 | <100KB | 内容未完整加载 | 增加滚动次数(5次)和等待时间(500ms) |
| 深色主题丢失 | PDF背景色变白 | 未启用`print_background` | 设置`print_background=True` |

**首页和末尾留白优化关键配置**:

**步骤1: 修改HTML的CSS**

在HTML文件的`<style>`标签中,找到`@media print`部分,修改hero和conclusion的样式:

```css
/* Print Styles */
@media print {
  .progress-bar, .nav-dots {
    display: none;
  }
  
  section {
    opacity: 1;
    transform: none;
    animation: none;
    min-height: auto;
    page-break-inside: avoid;
    padding: 30px 60px;  /* ✅ 减少section的padding到30px */
  }
  
  .hero {
    min-height: auto;  /* ❌ 不使用100vh,根据内容自动调整 */
    padding: 70px 60px 10px 60px;  /* ✅ 首页顶部70px,底部10px */
  }
  
  .hero h1 {
    -webkit-text-fill-color: initial;  /* ✅ print模式下使用固定颜色 */
    background: none;
    color: var(--accent-teal);  /* ✅ 使用固定颜色避免显示问题 */
  }
  
  .conclusion {
    padding: 30px 60px 10px 60px;  /* ✅ 末尾section顶部30px,底部10px */
  }
}
```

**关键点**:
- ✅ `min-height: auto` - 不使用100vh,让首页高度根据内容自动调整
- ✅ `padding: 30px 60px` - 普通section使用较小的padding
- ✅ `hero的padding: 70px 60px 10px 60px` - 首页顶部70px确保标题不被遮挡,底部10px
- ✅ `hero h1样式修复` - 禁用CSS渐变,使用固定颜色,避免print模式显示问题
- ✅ `conclusion的padding: 30px 60px 10px 60px` - 末尾顶部30px,底部10px
- ✅ **移除`page-break-after: always`** - 避免造成额外的分页空白
- ✅ 首页与第二页的总间距: 10px(hero底部) + 30px(part1顶部) = **40px**

**步骤2: 优化PDF生成脚本**

```python
async def generate_pdf():
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        
        # 创建页面
        page = await browser.new_page(
            viewport={'width': 1200, 'height': 1600},
            device_scale_factor=2  # 提高渲染质量
        )
        
        # 启用print媒体类型
        await page.emulate_media(media='print')
        
        # 加载HTML
        html_path = '/Users/super/WorkBuddy/20260403012034/韶音科技_战略分析报告.html'
        await page.goto(f'file://{html_path}', wait_until='networkidle')
        await page.wait_for_timeout(2000)
        
        # 滚动加载所有内容
        for _ in range(5):
            await page.evaluate('window.scrollTo(0, document.body.scrollHeight)')
            await page.wait_for_timeout(500)
        await page.evaluate('window.scrollTo(0, 0)')
        await page.wait_for_timeout(1000)
        
        # ✅ 关键: 获取每个section的实际高度,精确计算
        sections_info = await page.evaluate('''
            () => {
                const sections = document.querySelectorAll('section');
                const info = [];
                let totalHeight = 0;
                
                sections.forEach((section, index) => {
                    const rect = section.getBoundingClientRect();
                    const height = rect.height;
                    const top = rect.top + window.scrollY;
                    const bottom = rect.bottom + window.scrollY;
                    
                    info.push({
                        index: index,
                        id: section.id,
                        className: section.className,
                        height: height,
                        top: top,
                        bottom: bottom
                    });
                    
                    totalHeight = bottom;
                });
                
                return {
                    sections: info,
                    totalHeight: totalHeight
                };
            }
        ''')
        
        # ✅ 关键: 计算总高度,只添加最小缓冲(50px)
        total_height = sections_info['totalHeight'] + 50
        
        # 生成PDF - 使用优化的参数
        pdf_path = '/Users/super/WorkBuddy/20260403012034/韶音科技_战略分析报告.pdf'
        await page.pdf(
            path=pdf_path,
            width='1200px',
            height=f'{total_height}px',  # 使用实际内容高度+最小缓冲
            print_background=True,
            margin={
                'top': '0px',      # 首页顶部无边距
                'bottom': '0px',   # 末尾底部无边距
                'left': '0px',     # 左侧无边距
                'right': '0px'     # 右侧无边距
            },
            scale=1.0,  # 不缩放,使用原始大小
            prefer_css_page_size=False
        )
        
        await browser.close()
        
        print(f'✅ PDF已优化生成:')
        print(f'   总高度: {total_height}px (内容高度 + 50px缓冲)')
        print(f'   包含 {len(sections_info["sections"])} 个section')
        print(f'   首页和末尾留白已最小化')
```

**关键优化点**:
- ✅ 修改HTML的`@media print`样式,设置`min-height: auto`
- ✅ 使用固定padding(80px)替代100vh
- ✅ 精确计算每个section的高度
- ✅ 总高度只添加50px缓冲(不是200px)
- ✅ 使用0边距,让内容填充整个页面
- ✅ 使用scale=1.0不缩放,保持原始大小

**正确的做法 vs 错误做法对比**:

| 项目 | ❌ 错误做法 | ✅ 正确做法 |
|------|-----------|-----------|
| 生成方式 | Python reportlab手动编写 | Playwright从HTML截图 |
| 内容一致性 | 简化版,与HTML不匹配 | 完全一致 |
| 样式保留 | 丢失所有设计和动画 | 保留HTML所有样式 |
| 视觉效果 | 简陋,无深色主题 | 精美,深色科技风格 |
| 工作流合规 | 违反SKILL.md规定 | 符合规定 |
| 文件大小 | 通常<50KB | 通常>100KB |
| 高度计算 | `body.scrollHeight` | sections实际高度 |
| 媒体类型 | 未设置print | `emulate_media(media='print')` |

**常见问题处理**:
- 如果PDF首页标题不显示: 检查HTML中`@media print`样式是否覆盖了渐变文字
- 如果PDF末尾空白太多: 使用sections高度计算代替body.scrollHeight
- 如果PDF打开显示异常: 重新运行生成脚本,确保滚动次数和等待时间足够
- 确保HTML服务器正常运行(端口监听)
- 检查Python脚本路径是否正确

---

## 报告内容规范

### 信息准确性
- 所有数据必须来自实时web_search
- 标注信息来源和时效性
- 对不确定信息使用"预计"、"约"等修饰词

### 分析深度
- CEO痛点必须有深层原因和解决方向
- SWOT分析要具体,避免泛泛而谈
- Champion/Blocker识别要有明确依据

### 格式规范
- 文件名使用中文公司名
- 所有文件保存在工作目录
- 自动打开PDF供查看

---

## 质量检查清单

在完成报告生成前,确认:

- [ ] 行业数据准确,来自实时搜索
- [ ] CEO痛点有深层分析和解决方向
- [ ] 行业术语表完整(10个)
- [ ] SWOT分析四象限完整
- [ ] 战略机会明确,有执行路径
- [ ] Champion和Blocker识别有依据
- [ ] 战略对话示例专业且具体
- [ ] MD文件内容完整
- [ ] Word文件排版专业
- [ ] HTML页面可访问且动画流畅
- [ ] **HTML文件已生成** (检查四种格式完整性)
- [ ] **HTML的@media print样式已优化**:
  - [ ] hero使用`min-height: auto`
  - [ ] hero使用`padding: 60px 60px 20px 60px`
  - [ ] section使用`padding: 40px 60px`
  - [ ] conclusion使用`padding: 40px 60px 20px 60px`
- [ ] **PDF已启用print媒体类型** (`emulate_media(media='print')`)
- [ ] **PDF视口高度设置为1600px**
- [ ] **PDF使用scale=1.0不缩放** (保持原始大小)
- [ ] **PDF使用0边距** (让内容填充整个页面)
- [ ] **PDF首页标题完整显示** (无截断、无显示不全)
- [ ] **PDF首页留白合理** (约60px padding-top,20px padding-bottom)
- [ ] **PDF section间距合理** (约60px: 20px + 40px)
- [ ] **PDF高度基于sections实际计算** (只添加50px缓冲)
- [ ] **PDF末尾空白合理** (<50px缓冲)
- [ ] **PDF文件大小>100KB** (确保内容完整)
- [ ] 最终自动打开PDF供查看

---

## 示例用法

**用户**: "请帮我分析Gyges Labs公司"

**执行流程**:
1. 收集AI智能眼镜行业信息
2. 收集Gyges Labs公司信息
3. 提炼CEO痛点(量产成本、护城河、人才)
4. 生成行业术语表(HMD、FOV、波导等)
5. SWOT分析(技术优势 vs 品牌劣势)
6. 识别Champion(COO邓旭东)和Blocker(CTO吕正)
7. 生成四种格式报告
8. 打开PDF供查看

---

## 重要提示

1. **按顺序执行**: 必须先生成MD,再Word,再HTML,最后PDF
2. **技能依赖**: Word需要docx skill,HTML需要interactive-showcase-site skill
3. **PDF生成关键配置**:
   - 优先从静态HTML文件生成(避免端口冲突)
   - **必须先修改HTML的CSS**: 
     - 设置hero的`min-height: auto`
     - 设置hero的`padding: 60px 60px 20px 60px`(底部20px)
     - 设置section的`padding: 40px 60px`
     - 设置conclusion的`padding: 40px 60px 20px 60px`(底部20px)
   - 必须启用print媒体类型: `await page.emulate_media(media='print')`
   - 视口高度设置为1600px: `viewport={'width': 1200, 'height': 1600}`
   - 使用device_scale_factor=2提高渲染质量
   - 精确计算高度: 获取每个section的实际高度,只添加50px缓冲
   - 使用scale=1.0不缩放: 保持原始大小
   - 使用0边距: 让内容填充整个页面
   - 处理渐变文字: 在`@media print`中禁用渐变,使用固定颜色
4. **长图模式**: PDF必须使用长图模式,不使用A4分页
5. **质量验证**: 
   - PDF文件大小>100KB
   - 首页标题完整显示,无截断
   - 首页留白合理(约60px top,20px bottom)
   - section间距合理(约60px: 20px + 40px)
   - 末尾空白<50px
6. **自动打开**: 最后必须自动打开PDF供用户查看

## 参考文档

- **完整工作流程**: [references/workflow.md](references/workflow.md)
- **最佳实践**: [references/best-practices.md](references/best-practices.md) - 基于实际案例总结的经验
- **实际案例**: workflow.md中的"实际案例经验"章节
