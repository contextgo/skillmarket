#!/usr/bin/env python3
"""
将HTML报告转换为长图模式PDF
使用Playwright浏览器自动化工具
"""

from playwright.sync_api import sync_playwright
import time
import sys
import os


def html_to_pdf(html_url: str, output_path: str, width: int = 1200):
    """
    将HTML转换为长图模式PDF
    
    Args:
        html_url: HTML文件URL或本地路径
        output_path: PDF输出路径
        width: 固定宽度（默认1200px）
    """
    with sync_playwright() as p:
        # 启动浏览器
        browser = p.chromium.launch()
        page = browser.new_page()
        
        # 访问页面
        print(f"🌐 访问页面: {html_url}")
        if os.path.exists(html_url):
            page.goto(f'file://{html_url}', wait_until='networkidle')
        else:
            page.goto(html_url, wait_until='networkidle')
        
        # 等待页面加载
        time.sleep(2)
        
        # 滚动页面以加载所有懒加载内容
        print("📜 滚动加载所有内容...")
        for i in range(10):
            page.evaluate('window.scrollTo(0, document.body.scrollHeight)')
            time.sleep(0.3)
        
        # 滚回顶部
        page.evaluate('window.scrollTo(0, 0)')
        time.sleep(1)
        
        # 获取页面完整高度
        page_height = page.evaluate('document.body.scrollHeight')
        
        print(f"📐 页面尺寸: {width}px x {page_height}px")
        
        # 设置视口大小为完整页面
        page.set_viewport_size({'width': width, 'height': page_height})
        
        # 生成长图PDF
        print("📄 生成长图PDF...")
        page.pdf(
            path=output_path,
            width=f'{width}px',
            height=f'{page_height}px',
            print_background=True,
            margin={
                'top': '0px',
                'bottom': '0px',
                'left': '0px',
                'right': '0px'
            }
        )
        
        print(f"✅ PDF已生成: {output_path}")
        print(f"   页面高度: {page_height}px")
        
        browser.close()


if __name__ == '__main__':
    if len(sys.argv) < 3:
        print("使用方法: python html_to_pdf.py <html_path_or_url> <output_pdf_path> [width]")
        print("示例: python html_to_pdf.py http://localhost:5173 report.pdf 1200")
        sys.exit(1)
    
    html_path = sys.argv[1]
    output_path = sys.argv[2]
    width = int(sys.argv[3]) if len(sys.argv) > 3 else 1200
    
    html_to_pdf(html_path, output_path, width)
