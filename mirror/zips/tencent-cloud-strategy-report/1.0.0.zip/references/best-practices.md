# 腾讯云客户画像两步法 - 最佳实践

> 基于李未可科技案例(2026年4月3日)总结的最佳实践

---

## 一、工作流程最佳实践

### 1.1 信息收集阶段

#### 搜索策略

**行业分析搜索词组合**:
```
1. "{行业名} 市场规模 行业分析 2025"
2. "{行业名} 竞争对手 Top 5"
3. "{行业名} 政策 扶持 中国 2025"
4. "{行业名} 发展趋势 未来三年"
```

**公司分析搜索词组合**:
```
1. "{公司名} 公司 业务 融资"
2. "{公司名} CEO 创始人"
3. "{公司名} 产品 技术"
4. "{公司名} 核心团队 高管"
```

**关键人物分析搜索词组合(至少执行4个)**:
```
1. "{公司名} 创始人 CEO 董事长"
2. "{公司名} CTO COO 高管团队"
3. "{公司名} 公司简介 核心团队"
4. "{公司名} 董监高 股东"
5. "{公司名} 参保人数 团队规模"
```

#### 信息缺失的应对策略

**场景1: 完全找不到关键人物信息**
- 在报告中明确标注"关键人物信息有限"
- 基于公司背景和行业特点推断决策风格
- 不编造人物信息和背景
- 示例: "由于公开信息有限,以下分析基于公司背景和行业特点推断"

**场景2: 只找到部分关键人物信息**
- 只列出已确认的人物信息
- 标注信息来源和时效性
- 对不确定的信息使用"预计"、"约"等修饰词
- 示例: "CEO茹忆(前阿里A.I.Labs智能终端负责人,信息来自公开报道)"

**场景3: 信息冲突或不一致**
- 优先采用官方渠道信息
- 标注不同来源的差异
- 使用"据公开资料显示"等表述
- 示例: "据天眼查数据显示...,但公司官网显示..."

---

### 1.2 战略分析阶段

#### CEO痛点提炼技巧

**痛点识别的三个维度**:
1. **行业维度**: 行业共性问题(如价格战、监管、人才稀缺)
2. **公司维度**: 公司发展阶段问题(如初创期的品牌、规模、资金)
3. **竞争维度**: 竞争格局问题(如巨头涌入、护城河薄弱)

**痛点描述的三个要素**:
```markdown
**痛点X: {痛点名称}**

**痛点描述**: 具体现象和表现(1-2句话)

**深层原因**: 为什么会出现这个问题(2-3个原因)

**解决方向**: 可能的解决思路(2-3个方向)
```

**示例(李未可科技案例)**:
```markdown
**痛点1: 规模化与成本控制的矛盾**

**痛点描述**: AI眼镜价格战开启,低毛利模式下如何实现规模化出货并保持盈利能力

**深层原因**: 
1. 行业处于早期教育阶段,消费者认知门槛高,需低价策略获客
2. 供应链尚未成熟,核心器件成本高

**解决方向**: 
1. 技术降本(端侧AI减少云端算力成本)
2. 规模效应(扩大出货量降低单位成本)
3. 生态变现(硬件+服务订阅模式)
```

#### SWOT分析技巧

**优势(S)识别要点**:
- 技术: 核心技术、专利、研发团队背景
- 团队: 创始团队背景、核心成员履历
- 产品: 产品差异化、价格优势、用户口碑
- 布局: 市场布局、合作伙伴、生态建设

**劣势(W)识别要点**:
- 品牌: 知名度、影响力、用户认知度
- 规模: 出货量、营收规模、团队规模
- 生态: 应用生态、开发者社区、合作伙伴
- 资金: 融资情况、现金流、盈利能力

**机会(O)识别要点**:
- 市场: 市场增长、细分市场空白、消费趋势
- 政策: 国家战略、地方扶持、行业标准
- 竞争: 竞争对手弱点、市场空白点
- 场景: 新应用场景、垂直行业需求

**威胁(T)识别要点**:
- 巨头: 行业巨头进入、跨界竞争者
- 技术: 技术迭代、替代技术
- 监管: 政策变化、合规要求
- 价格战: 降价竞争、毛利压力

#### 决策链条分析技巧

**Champion识别要点**:
- **通常角色**: COO、市场VP、业务负责人、事业部总经理
- **核心特征**: 
  - 需要业绩突破
  - 推动业务拓展
  - 关注ROI和增长
- **支持动机**: 
  - 扩大营收
  - 证明能力
  - 获取资源
  - 晋升机会
- **沟通策略**: 
  - 提供ROI数据和案例
  - 打包解决方案
  - 试点支持
  - 案例背书

**Blocker识别要点**:
- **通常角色**: CTO、技术负责人、财务总监、风控负责人
- **核心特征**: 
  - 关注技术风险
  - 关注成本压力
  - 关注供应商依赖
  - 关注合规风险
- **阻碍动机**: 
  - 技术风险(定制化、技术债务)
  - 成本压力(预算超支、贬值风险)
  - 供应商依赖(被锁定、议价能力弱)
- **应对策略**: 
  - 标准化方案(避免定制化)
  - 技术支持(降低风险)
  - 成本拆解(透明定价)
  - 分期采购(降低一次性投入)
  - 服务订阅(降低资产风险)

---

### 1.3 报告生成阶段

#### Markdown报告生成

**文件命名规范**:
```
{公司名}_战略分析报告.md
示例: 李未可科技_战略分析报告.md
```

**报告结构(必须完整)**:
```markdown
# {公司名} 战略分析报告

**生成时间**: YYYY年MM月DD日  
**分析对象**: {公司名}  
**所属行业**: {行业名}

---

## 📊 第一部分:行业深度分析

### 一、市场规模与增长趋势
### 二、竞争格局分析
### 三、政策环境扫描
### 四、关键人物分析  ⚠️ 必填章节

---

## 🎯 第二部分:AI战略顾问

### 一、CEO级业务痛点提炼
### 二、行业黑话速查表

---

## 🎯 第三部分:客户画像两步法

### 第一步:战略穿透(SWOT分析)
### 第二步:决策链条分析

---

## 💡 战略对话示例

## 📌 总结与建议
```

**关键人物分析章节模板**:
```markdown
### 四、关键人物分析

#### 核心高管团队

| 姓名 | 职位 | 背景资历 | 关注焦点 |
|------|------|---------|---------|
| XXX | 董事长/CEO | 学术背景、职业经历 | 战略方向、技术创新 |

#### 创始团队背景

**XXX博士 - 核心创始人**:
- 学术背景: XX大学博士
- 人才认定: XX计划人才
- 技术积累: XX领域深耕多年
- 管理角色: 担任XX职位

#### 董监高结构分析

**治理特点**:
1. 技术主导型治理: 董事长兼任CTO
2. 创始团队控制: 核心高管为创始成员

#### 决策风格推断

**XXX（董事长/CEO）**:
- 决策风格: 技术驱动型
- 关注焦点: 技术壁垒、产品差异化
- 风险偏好: 中等偏高
- 沟通特点: 重视数据验证

#### 关键人物沟通策略

**与XXX沟通要点**:
1. 技术领先性: 展示技术积累
2. 量产能力: 证明规模化能力
```

#### Word报告生成

**使用docx skill**:
```bash
# 检查docx skill是否已加载
# 如果未加载,使用use_skill加载
```

**排版要求**:
- 标题1: 16pt,加粗,深色
- 标题2: 14pt,加粗,蓝色
- 正文: 12pt,常规
- 表格: 网格线,浅色背景
- 页眉: "{公司名}战略分析报告"
- 页脚: "生成时间: YYYY-MM-DD"

#### HTML报告生成

**使用interactive-showcase-site skill**:
```bash
# 检查interactive-showcase-site skill是否已加载
# 如果未加载,使用use_skill加载
```

**核心特性**:
- 电影级滚动动画
- 深色主题(支持切换)
- 响应式设计
- 章节导航
- 进度条

**重要提示**:
- 必须生成静态HTML文件(用于PDF生成)
- 静态HTML文件需要配套的assets目录
- 文件路径: `{公司名}_战略分析报告.html`

#### PDF报告生成 ⚠️ 最关键

**优先方案:从静态HTML文件生成(推荐)**

**原因**:
- 避免端口冲突问题
- 不需要启动HTML服务器
- 文件路径更稳定
- 更可靠

**完整流程**:
```bash
# 1. 检查HTML文件是否存在
ls -lh {公司名}_战略分析报告.html

# 2. 使用Python脚本生成PDF(从静态HTML)
/usr/bin/python3 -c "
import asyncio
from playwright.async_api import async_playwright

async def generate_pdf():
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        page = await browser.new_page(viewport={'width': 1200, 'height': 1080})
        
        # ✅ 关键1: 启用print媒体类型
        await page.emulate_media(media='print')
        
        # 加载本地HTML文件
        await page.goto('file:///{工作目录}/{公司名}_战略分析报告.html', wait_until='networkidle')
        
        # ✅ 关键2: 初始等待时间
        await page.wait_for_timeout(3000)
        
        # ✅ 关键3: 增加滚动次数和等待时间
        for i in range(30):
            await page.evaluate('window.scrollTo(0, document.body.scrollHeight)')
            await page.wait_for_timeout(800)
        
        # ✅ 关键4: 回到顶部并等待
        await page.evaluate('window.scrollTo(0, 0)')
        await page.wait_for_timeout(2000)
        
        # 获取页面高度和section数量
        height = await page.evaluate('document.body.scrollHeight')
        section_count = await page.evaluate('document.querySelectorAll(\"section\").length')
        
        # ✅ 关键5: PDF配置
        await page.pdf(
            path='{公司名}_战略分析报告.pdf',
            width='1200px',
            height=f'{height}px',
            print_background=True,  # 必须为True
            margin={'top': '0', 'bottom': '0', 'left': '0', 'right': '0'}
        )
        
        await browser.close()
        print(f'✅ PDF已生成: 1200px × {height}px, 包含{section_count}个section')

asyncio.run(generate_pdf())
"

# 3. 验证PDF质量
ls -lh {公司名}_战略分析报告.pdf
# 文件大小应>100KB,理想情况>500KB
```

**关键配置参数**:
- 视口宽度: 1200px
- 视口高度: 1080px
- 初始等待: 3000ms
- 滚动次数: 30次
- 滚动等待: 800ms
- 最终等待: 2000ms
- 总等待时间: 3000 + 30×800 + 2000 = 29秒

**质量标准**:
- ✅ 文件大小>100KB(理想>500KB)
- ✅ 页面高度>4000px(根据内容量)
- ✅ 深色主题样式完整保留
- ✅ 内容与HTML完全一致
- ✅ 无分页空白
- ✅ 首页文字完整显示

---

## 二、常见问题处理

### 2.1 信息收集问题

#### 问题1: 找不到关键人物信息

**现象**:
- 执行4个以上搜索,仍找不到CEO、CTO等核心高管信息
- 只找到创始人/CEO的基本信息,缺少详细背景

**应对策略**:
1. 在报告中明确标注"关键人物信息有限"
2. 基于公司背景和行业特点推断决策风格
3. 不编造人物信息和背景
4. 使用以下表述:
   - "由于公开信息有限,以下分析基于公司背景推断"
   - "据公开资料显示...,其他高管信息未公开"
   - "基于行业特点和企业发展阶段,推断决策风格如下"

**示例**:
```markdown
### 四、关键人物分析

**信息说明**: 由于李未可科技为创业公司,公开的高管团队信息有限。以下分析基于公开资料和行业特点推断。

#### 核心高管团队

| 姓名 | 职位 | 背景资历 | 关注焦点 |
|------|------|---------|---------|
| 茹忆 | CEO | 前阿里A.I.Labs智能终端负责人 | 产品创新、市场拓展 |

**注**: 其他高管信息未公开,基于公司背景推断如下...

#### 决策风格推断(基于公司背景)

**茹忆（CEO）**:
- 决策风格: 产品驱动型(基于阿里产品经理背景)
- 关注焦点: 用户体验、产品差异化、AI技术应用
- 风险偏好: 中等偏高(创业公司特征)
- 沟通特点: 重视数据验证和用户反馈
```

#### 问题2: 信息冲突或不一致

**现象**:
- 不同来源显示的融资轮次、金额不一致
- 官网和媒体报道的信息有差异

**应对策略**:
1. 优先采用官方渠道信息(官网、官方公告)
2. 标注不同来源的差异
3. 使用以下表述:
   - "据天眼查数据显示...,但公司官网显示..."
   - "不同来源显示的融资信息存在差异,以下为综合分析"
4. 对不确定的信息使用"预计"、"约"等修饰词

---

### 2.2 PDF生成问题

#### 问题1: PDF文件过小(<100KB)

**原因分析**:
- PDF内容未完全加载
- 滚动加载未完成
- 等待时间过短

**解决方案**:
```python
# 增加滚动次数和等待时间
for i in range(30):  # 从20增加到30
    await page.evaluate('window.scrollTo(0, document.body.scrollHeight)')
    await page.wait_for_timeout(800)  # 从500ms增加到800ms
```

#### 问题2: PDF首页文字显示不完整

**原因分析**:
- CSS动画初始不可见(`opacity: 0`)
- 渐变文字兼容性问题
- Hero Section高度问题

**解决方案**:

**步骤1: 在HTML中添加 `@media print` 样式**
```css
/* PDF打印优化 */
@media print {
    /* 禁用所有动画 */
    *, *::before, *::after {
        animation: none !important;
        animation-delay: 0s !important;
        animation-duration: 0s !important;
    }

    /* Hero Section 标题使用实色替代渐变 */
    .hero h1 {
        -webkit-text-fill-color: #00F5FF !important;
        color: #00F5FF !important;
        background: none !important;
    }

    /* 确保所有元素可见 */
    .hero .subtitle,
    .hero .meta,
    .hero-content {
        opacity: 1 !important;
        transform: none !important;
    }

    /* 优化Hero高度 */
    .hero {
        min-height: auto !important;
        padding: 4rem 0 !important;
    }
}
```

**步骤2: 使用Playwright生成PDF时启用print媒体类型**
```python
# ✅ 关键: 启用print媒体类型
await page.emulate_media(media='print')
```

#### 问题3: PDF黑屏过多或内容缺失

**原因分析**:
- Hero section占用过多空间(`min-height: 100vh`)
- 滚动加载不充分
- 懒加载内容未触发

**解决方案**:
```python
# 1. 增加滚动次数和等待时间
for i in range(30):
    await page.evaluate('window.scrollTo(0, document.body.scrollHeight)')
    await page.wait_for_timeout(800)

# 2. 分段滚动(更温和的方式)
for i in range(30):
    current_height = await page.evaluate('document.body.scrollHeight')
    scroll_position = int(current_height * (i + 1) / 30)
    await page.evaluate(f'window.scrollTo(0, {scroll_position})')
    await page.wait_for_timeout(800)

# 3. 等待所有图片加载
await page.wait_for_selector('img', state='attached', timeout=10000)
await page.wait_for_timeout(3000)

# 4. 等待所有section渲染完成
section_count = await page.evaluate('document.querySelectorAll("section").length')
print(f'✅ 已加载{section_count}个section')
```

---

## 三、质量检查清单

### 3.1 信息收集阶段

- [ ] 执行了行业分析搜索(3个以上搜索词)
- [ ] 执行了公司分析搜索(3个以上搜索词)
- [ ] 执行了关键人物分析搜索(4个以上搜索词)
- [ ] 所有数据来自实时搜索
- [ ] 标注了信息来源和时效性
- [ ] 对不确定信息使用了"预计"、"约"等修饰词

### 3.2 战略分析阶段

- [ ] 提炼了3个CEO级痛点
- [ ] 每个痛点包含:痛点描述、深层原因、解决方向
- [ ] 收集了10个行业术语
- [ ] 每个术语包含:通俗解释、使用场景示例
- [ ] SWOT分析四象限完整
- [ ] 识别了Champion和Blocker
- [ ] 提供了沟通策略

### 3.3 报告生成阶段

#### Markdown报告
- [ ] 文件名格式正确
- [ ] 包含完整的三个部分
- [ ] 包含关键人物分析章节
- [ ] 内容完整,无遗漏

#### Word报告
- [ ] 使用docx skill生成
- [ ] 排版专业
- [ ] 包含页眉页脚
- [ ] 格式规范

#### HTML报告
- [ ] 使用interactive-showcase-site skill生成
- [ ] 生成静态HTML文件
- [ ] 电影级滚动动画
- [ ] 深色主题
- [ ] 响应式设计
- [ ] 章节导航
- [ ] 进度条

#### PDF报告
- [ ] 从静态HTML生成
- [ ] 启用print媒体类型
- [ ] 增加滚动次数(30次)
- [ ] 增加等待时间(800ms)
- [ ] 文件大小>100KB
- [ ] 页面高度>4000px
- [ ] 深色主题样式完整保留
- [ ] 内容与HTML完全一致
- [ ] 无分页空白
- [ ] 首页文字完整显示

### 3.4 最终交付

- [ ] 四种格式文件都已生成
- [ ] 文件命名规范
- [ ] 文件保存在工作目录
- [ ] PDF已自动打开查看
- [ ] 质量达标

---

## 四、案例参考

### 4.1 李未可科技案例(2026年4月3日)

**案例特点**:
- AI智能眼镜行业新兴企业
- 缺少关键人物信息(仅找到CEO茹忆的基本信息)
- 成功从静态HTML生成高质量PDF长图

**执行结果**:
- ✅ MD文件: 完整内容,标注关键人物信息有限
- ✅ Word文件: 专业排版
- ✅ HTML文件: 电影级滚动动画,深色主题
- ✅ PDF文件: 1.8MB, 8800px高度, 5个section

**经验总结**:
1. 静态HTML生成PDF更可靠
2. 滚动加载要充分(30次,800ms)
3. 启用print媒体类型
4. 信息缺失要诚实标注
5. 质量验证要全面

**详细案例**: 参见 `workflow.md` 中的"实际案例经验"章节

---

## 五、工具使用技巧

### 5.1 web_search技巧

**搜索词组合**:
- 行业: "{行业名} 市场规模 行业分析 2025"
- 公司: "{公司名} 公司 业务 融资"
- 人物: "{公司名} 创始人 CEO 董事长"

**搜索结果处理**:
- 提取关键数据(市场规模、增长率、融资轮次)
- 记录信息来源和时效性
- 标注不确定信息

### 5.2 docx skill技巧

**使用流程**:
1. 检查docx skill是否已加载
2. 基于Markdown内容生成Word文档
3. 设置专业排版
4. 添加页眉页脚

### 5.3 interactive-showcase-site skill技巧

**使用流程**:
1. 检查interactive-showcase-site skill是否已加载
2. 创建React项目结构
3. 基于模板生成内容
4. 启动开发服务器(端口5173-5179中可用端口)
5. **重要**: 等待服务器启动完成(使用curl检查)
6. 打包生成静态HTML文件

**注意事项**:
- 必须生成静态HTML文件(用于PDF生成)
- 静态HTML文件需要配套的assets目录
- PDF生成依赖静态HTML文件

### 5.4 Playwright技巧

**PDF生成配置**:
```python
# 视口配置
viewport={'width': 1200, 'height': 1080}

# 启用print媒体类型
await page.emulate_media(media='print')

# 加载HTML文件
await page.goto('file:///{工作目录}/{公司名}_战略分析报告.html', wait_until='networkidle')

# 滚动加载
for i in range(30):
    await page.evaluate('window.scrollTo(0, document.body.scrollHeight)')
    await page.wait_for_timeout(800)

# PDF配置
await page.pdf(
    path='{公司名}_战略分析报告.pdf',
    width='1200px',
    height=f'{height}px',
    print_background=True,
    margin={'top': '0', 'bottom': '0', 'left': '0', 'right': '0'}
)
```

---

## 六、常见错误与避免

### 6.1 跳过PDF生成

**错误表现**:
- 只生成MD、Word、HTML三种格式
- 没有生成PDF文件
- 用户期望看到完整四格式报告

**正确做法**:
- 必须完成四步流程:MD→Word→HTML→PDF
- PDF是最终交付物
- 用户期望看到完整四格式报告

### 6.2 PDF生成配置错误

**错误表现**:
- PDF文件过小(<100KB)
- PDF首页文字显示不完整
- PDF黑屏过多
- PDF内容缺失

**正确做法**:
- 必须设置`print_background=True`
- 必须设置零边距
- 必须启用print媒体类型
- 必须增加滚动次数和等待时间

### 6.3 编造关键人物信息

**错误表现**:
- 找不到关键人物信息时编造内容
- 虚构CEO、CTO等高管背景
- 误导用户决策

**正确做法**:
- 在报告中明确标注"关键人物信息有限"
- 基于公司背景和行业特点推断决策风格
- 不编造人物信息和背景
- 使用"基于公开信息推断"等表述

---

## 七、持续改进

### 7.1 案例库建设

**目标**: 积累不同行业、不同类型企业的案例

**案例分类**:
- 行业分类: AI、SaaS、硬件、消费、金融等
- 企业类型: 初创企业、成长企业、成熟企业
- 信息完整度: 信息完整、信息部分缺失、信息严重缺失

**案例记录**:
- 基本信息: 公司名、行业、执行时间
- 执行流程: 信息收集、战略分析、报告生成
- 遇到问题: 问题类型、解决方案
- 经验总结: 成功经验、注意事项
- 文件质量: 文件大小、页面高度、内容完整性

### 7.2 技能文档更新

**更新频率**: 每个重要案例完成后更新

**更新内容**:
- 添加实际案例经验到workflow.md
- 更新best-practices.md最佳实践
- 优化SKILL.md流程说明

**更新原则**:
- 只记录有价值的经验
- 保持文档简洁
- 提供可复用的配置和模板

---

## 八、PDF生成问题排查与解决(2026-04-03更新)

### 8.1 v2版本HTML文件缺失问题

**问题描述**:
- 只生成了v2版本的MD、Word、PDF文件
- 缺少v2版本的HTML中间文件
- 四步流程不完整

**解决方案**:
1. 如果时间紧迫,可以复制之前的HTML文件并修改内容
2. 理想情况:使用interactive-showcase-site skill重新生成HTML
3. 确保每种格式都有对应的v2版本文件

**检查清单**:
```bash
# 验证v2版本四种格式文件都已生成
ls -lh {公司名}_战略分析_report_v2*.{md,docx,html,pdf}
```

### 8.2 PDF首页标题显示不完整问题(已解决)

**问题症状**:
- PDF首页标题文字不显示或显示不完整
- 渐变文字效果丢失
- 标题显示为空白或黑色

**根本原因**:
- HTML使用了CSS渐变文字效果(`background-clip: text`)
- Playwright在print模式下不支持CSS渐变文字
- `-webkit-text-fill-color: transparent`导致文字在PDF中不可见

**解决方案**(已在v2_optimized版本中应用):

在HTML的`@media print`样式中禁用渐变效果:

```css
@media print {
    /* 其他print样式... */

    /* 修复首页标题渐变文字在PDF中不可见的问题 */
    .hero h1 {
        background: none;
        -webkit-background-clip: unset;
        -webkit-text-fill-color: unset;
        background-clip: unset;
        color: #4ECDC4;  /* 使用固定颜色替代渐变 */
    }
}
```

**验证方法**:
1. 在浏览器中打开HTML文件
2. 打开开发者工具,切换到print媒体类型
3. 检查首页标题是否正常显示

### 8.3 PDF末尾黑屏空白内容太多问题(已解决)

**问题症状**:
- PDF末尾有大段空白
- 文件高度计算不准确
- 包含隐藏元素的高度

**根本原因**:
- `document.body.scrollHeight`包含了隐藏元素的高度
- 滚动容器或固定定位元素影响高度计算
- body高度包含导航栏、进度条等固定元素

**解决方案**(已在v2_optimized版本中应用):

精确计算实际内容高度,排除隐藏元素:

```python
# 获取实际内容高度(排除空白)
height = await page.evaluate('''
    () => {
        const sections = document.querySelectorAll('section');
        let maxHeight = 0;
        sections.forEach(section => {
            const rect = section.getBoundingClientRect();
            const bottom = rect.bottom + window.scrollY;
            if (bottom > maxHeight) maxHeight = bottom;
        });
        return maxHeight + 100; // 添加100px缓冲
    }
''')
```

**优化后的PDF生成脚本**:

```python
import asyncio
from playwright.async_api import async_playwright

async def generate_pdf():
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        page = await browser.new_page(viewport={'width': 1200, 'height': 1080})

        # ✅ 启用print媒体类型
        await page.emulate_media(media='print')

        # 加载本地HTML文件
        await page.goto('file:///{工作目录}/{文件名}.html', wait_until='networkidle')
        await page.wait_for_timeout(3000)

        # 滚动加载所有内容
        for i in range(30):
            await page.evaluate('window.scrollTo(0, document.body.scrollHeight)')
            await page.wait_for_timeout(800)

        await page.evaluate('window.scrollTo(0, 0)')
        await page.wait_for_timeout(2000)

        # 获取实际内容高度(排除空白)
        height = await page.evaluate('''
            () => {
                const sections = document.querySelectorAll('section');
                let maxHeight = 0;
                sections.forEach(section => {
                    const rect = section.getBoundingClientRect();
                    const bottom = rect.bottom + window.scrollY;
                    if (bottom > maxHeight) maxHeight = bottom;
                });
                return maxHeight + 100;
            }
        ''')

        section_count = await page.evaluate('document.querySelectorAll("section").length')

        await page.pdf(
            path='{文件名}.pdf',
            width='1200px',
            height=f'{height}px',
            print_background=True,
            margin={'top': '0', 'bottom': '0', 'left': '0', 'right': '0'}
        )

        await browser.close()
        print(f'✅ PDF已生成: 1200px × {height}px, 包含{section_count}个section')

asyncio.run(generate_pdf())
```

### 8.4 PDF生成关键参数总结

| 参数 | 推荐值 | 说明 | 必须设置 |
|------|--------|------|----------|
| viewport width | 1200px | 固定宽度,确保布局一致 | ✅ |
| viewport height | 1080px | 初始视口高度 | ✅ |
| emulate_media | 'print' | 触发@media print样式 | ✅ **必须** |
| 滚动次数 | 30次 | 确保所有懒加载内容触发 | ✅ |
| 滚动等待 | 800ms | 每次滚动后的等待时间 | ✅ |
| 初始等待 | 3000ms | 页面加载后的初始等待 | ✅ |
| 最终等待 | 2000ms | 滚动完成后的最终等待 | ✅ |
| print_background | True | 保留背景色 | ✅ **必须** |
| 边距 | 全0 | 长图模式,无分页空白 | ✅ **必须** |
| 高度计算 | sections实际高度 | 排除隐藏元素 | ✅ **推荐** |

### 8.5 质量验证标准(更新)

**PDF文件质量标准**:
- ✅ 文件大小>1MB(理想情况)
- ✅ 页面高度基于sections实际计算
- ✅ 首页标题完整显示(无渐变问题)
- ✅ 末尾空白<200px
- ✅ 深色主题样式完整保留
- ✅ 所有章节内容完整

**四种格式完整性**:
- ✅ MD文件: 完整内容,标注信息来源
- ✅ Word文件: 专业排版
- ✅ HTML文件: 电影级滚动动画,深色主题
- ✅ PDF文件: 长图模式,内容完整,显示正常

---

**文档版本**: v1.1
**更新时间**: 2026年4月3日 01:56
**基于案例**: 李未可科技战略分析报告v2优化
**更新内容**: 添加PDF生成问题排查与解决方案