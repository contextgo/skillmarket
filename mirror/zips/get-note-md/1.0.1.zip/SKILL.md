---
name: biji-note
description: |
  输入B站视频链接，自动在Get笔记(biji.com)中添加AI笔记，并保存到F:\Open目录。
  触发词：「记笔记」「添加到笔记」「生成笔记」
---

# Get笔记 · AI链接笔记

> 给一个B站视频链接，自动完成AI分析并生成笔记，保存为Markdown文件到 F:\Open

## 使用方式

```
/biji-note
https://www.bilibili.com/video/BV1ooDyBmE6v
```

## 执行流程

### Step 1: 打开笔记网站
```bash
playwright-cli open https://www.biji.com/note --persistent
```

### Step 2: 获取页面快照
```bash
playwright-cli snapshot
```
从快照中找到 `添加链接` 按钮（通常显示为"添加链接" + "AI智能分析"）

### Step 3: 点击"添加链接"按钮
```bash
playwright-cli click <添加链接按钮的ref>
```

### Step 4: 获取弹窗快照
```bash
playwright-cli snapshot
```
找到链接输入框（name="粘贴或者输入链接"）和生成笔记按钮

### Step 5: 粘贴链接
```bash
playwright-cli fill <链接输入框ref> "<B站视频链接>"
```

### Step 6: 点击"生成笔记"
```bash
playwright-cli click <生成笔记按钮ref>
```

### Step 7: 等待60秒
```bash
sleep 60
```
等待AI处理完成

### Step 8: 查看笔记列表
```bash
playwright-cli snapshot
```
找到新生成的笔记（通常在"今天"分区）

### Step 9: 点击笔记查看详情
```bash
playwright-cli click <新笔记ref>
```

### Step 10: 获取笔记内容
```bash
playwright-cli snapshot
```
提取笔记的标题、标签和正文内容

### Step 11: 保存为Markdown文件
根据笔记标题生成文件名（移除特殊字符），将内容保存到 `F:\Open\<标题>.md`

内容格式（含Obsidian属性）：
```markdown
---
uid: <生成的时间戳>
title: <笔记标题>
tags: [<标签1>, <标签2>]
created: <创建日期 YYYY-MM-DD>
source: <B站视频链接>
---

# <笔记标题>

**描述**：<视频描述>

**标签**：<标签1> | <标签2> | ...

---

<笔记正文内容>
```

### Step 12: 输出完成信息
显示保存的文件路径
