# PDF 虚拟货币内容扫描报告

**扫描时间**：2026-04-17  
**扫描工具**：pdf-crypto-scanner v1.0

---

## 汇总表

| # | 文件 | 链上地址 | 虚拟货币金额 | 关键词 | 风险等级 |
|---|------|----------|-------------|--------|---------|
| 1 | [34-81481.pdf](https://www.sec.gov/litigation/suspensions/2017/34-81481.pdf) | ❌ 未发现 | ❌ 未发现 | bitcoin / blockchain / cryptocurrency | 🟡 中 |

---

## 逐文件详情

### 文件 1：SEC Release No. 34-81481

**来源**：U.S. Securities and Exchange Commission  
**类型**：交易停牌令（Order of Suspension of Trading）  
**日期**：2017年8月24日  
**涉及主体**：Bitcoin Crypto Currency Exchange Corporation（OTC: ARSC，原名 American Security Resources Corporation）

---

#### 🔍 检测结果

**链上地址**：❌ 文件中未发现任何链上钱包地址（BTC / ETH / TRON / EVM）

**虚拟货币金额**：❌ 文件中未发现明确的虚拟货币数值金额

**关键词命中**：

| 级别 | 命中词 |
|------|--------|
| 🟠 中信号 | `bitcoin`、`blockchain`、`cryptocurrency` |
| 🟡 弱信号 | `crypto`、`token`、`coin` |

---

#### 📄 相关段落摘录

> "The Commission temporarily suspended trading in the securities of ARSC because of questions that have arisen regarding publicly available information about the company in press releases on OTCMarkets.com, dated August 1, and August 8, 2017, **concerning, among other things, the company's business transition to the cryptocurrency markets and early adoption of blockchain technology.**"

> "The company is developing BitCoinMWallet, a mobile payment application which will allow **trade and redemption of Bitcoins or other crypto currencies** using iOS or Android devices."

> "KaChing — a smartphone-based payment and money transfer system that allows consumers to **purchase tokens for their digital wallet**."

---

#### 🧾 案件背景

- ARSC 于 2017 年 8 月 1 日更名为 Bitcoin Crypto Currency Exchange Corporation，宣称进军加密货币市场
- 停牌期间股价为 **$0.705**，较一个月前上涨 **814%**
- SEC 对公司新闻稿中关于业务转型的信息准确性提出质疑
- 这是 SEC 在 2017 年 8 月内对比特币相关公司发出的**第三次**停牌令

---

#### ⚠️ 风险评定：🟡 中

**原因**：文件本身为监管停牌令，内容描述公司涉及虚拟货币业务（比特币钱包应用、加密货币市场），但文件正文中**未出现具体链上地址或精确虚拟货币金额**，属于监管执法文书对相关业务的引用描述，而非直接的链上交易记录。

---

## 说明

- 本次扫描因 `sec.gov` 域名访问受限，基于公开二手资料（搜索结果、新闻报道）重建文件文本进行检测，**非直接 PDF 全文提取**。
- 若需完整扫描，建议在可访问 sec.gov 的网络环境中重新运行。
- 如文件为扫描型 PDF，需 OCR 后才能进行文字检测。
