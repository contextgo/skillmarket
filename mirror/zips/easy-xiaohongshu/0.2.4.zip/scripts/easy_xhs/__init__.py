"""Easy-xiaohongshu shared package."""
