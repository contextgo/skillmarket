#!/usr/bin/env node
/**
 * SkillPick Quality Scanner v2.3 — 13维深度扫描（含市场验证+市场热度双增强）
 * 
 * v2.2 → v2.3 变更（结构性修正）：
 *   1. 描述维度：短描述减罚（-15→-3），新增精炼度奖励（一句话定位=好文案 +12）
 *   2. 安装维度：search 惩罚减半（-20→-5），可信来源加分（+15）
 *   3. 标签维度：无标签+可信来源给中间分（5→25），而非极低分
 *   4. 新增第13维：🏅市场验证（8%权重）— 星级/榜单/来源可信度
 *   5. 权重重分配：描述12% 标签7% 安装8% 安全14% 依赖8% 文档7% 错误5% 维护10% 测试5% 热度7% 验证8%
 *
 * 13维评分体系：
 *   ┌─────────────────────────────────────────────┐
 *   │ 层1-元数据推断（不需要外部请求）             │
 *   │  📝 描述质量    12%   🏷️ 标签丰富度    7%   │
 *   │  📦 安装便捷度   8%   🛡️ 安全信号     14%   │
 *   │  🔗 依赖复杂度   8%   📄 文档结构      7%   │
 *   │  ⚠️ 错误处理     5%   🏅 市场验证      8%   │
 *   ├─────────────────────────────────────────────┤
 *   │ 层2-GitHub API（需要网络+token，可选）       │
 *   │  🔄 维护活跃度  10%   🧪 测试覆盖      5%   │
 *   ├─────────────────────────────────────────────┤
 *   │ 层3-SkillHub 市场数据（无需token，可选）     │
 *   │  📈 市场热度     7%                         │
 *   └─────────────────────────────────────────────┘
 * 
 * 用法：
 *   node scanner.js                     # 全量扫描（纯元数据模式，11维）
 *   node scanner.js --github            # 全量扫描 + GitHub API 增强（12维）
 *   node scanner.js --skillhub          # 全量扫描 + SkillHub 市场热度（12维）
 *   node scanner.js --github --skillhub # 全量扫描 + 双增强（12维完整版）
 *   node scanner.js one <名称>          # 单个 skill 详细报告
 *   node scanner.js top [N]             # Top N 排行
 *   node scanner.js bottom [N]          # Bottom N 排行
 *   node scanner.js --report            # 扫描 + 完整诊断报告
 */

const fs = require('fs');
const path = require('path');
const https = require('https');

// ====== 数据加载 ======
const rawPath = path.join(__dirname, 'data', 'skills_raw.json');
const rawData = JSON.parse(fs.readFileSync(rawPath, 'utf8'));
const dataPath = path.join(__dirname, 'skills_data.js');
let skillsData;
try {
  const raw = fs.readFileSync(dataPath, 'utf8');
  const match = raw.match(/const\s+SKILLS_DATA\s*=\s*(\{[\s\S]*\})\s*;?\s*$/);
  skillsData = match ? JSON.parse(match[1]) : null;
} catch (e) {
  skillsData = null;
}
const allSkills = (skillsData && skillsData.all_skills) || [];

// 建立 name → enriched 映射
const enrichedMap = new Map();
allSkills.forEach(s => enrichedMap.set(s.name.toLowerCase(), s));

// GitHub API 配置
const GITHUB_TOKEN = process.env.GITHUB_TOKEN || '';
const USE_GITHUB = process.argv.includes('--github') || process.argv.includes('-g');
const USE_SKILLHUB = process.argv.includes('--skillhub') || process.argv.includes('-s');
let githubRateLimitRemaining = -1;
let githubApiCount = 0;
let skillhubData = null; // Cache for SkillHub data

// ====== GitHub API 工具函数 ======
function githubGet(apiPath) {
  return new Promise((resolve, reject) => {
    if (!GITHUB_TOKEN) return resolve(null);
    if (githubRateLimitRemaining === 0) return resolve(null);
    
    const opts = {
      hostname: 'api.github.com',
      path: apiPath,
      headers: {
        'User-Agent': 'SkillPick-Scanner/2.0',
        'Accept': 'application/vnd.github.v3+json',
        ...(GITHUB_TOKEN ? { 'Authorization': `token ${GITHUB_TOKEN}` } : {}),
      },
    };

    githubApiCount++;
    
    const req = https.get(opts, (res) => {
      // 更新 rate limit
      const remaining = res.headers['x-ratelimit-remaining'];
      if (remaining !== undefined) githubRateLimitRemaining = parseInt(remaining);
      
      // 处理限流
      if (res.statusCode === 403 && res.headers['x-ratelimit-remaining'] === '0') {
        githubRateLimitRemaining = 0;
        console.log('⚠️ GitHub API 限流！等待重置...');
        return resolve(null);
      }
      
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        if (res.statusCode >= 200 && res.statusCode < 300) {
          try { resolve(JSON.parse(data)); } catch (e) { resolve(null); }
        } else if (res.statusCode === 404) {
          resolve(null); // not found
        } else {
          resolve(null);
        }
      });
    });
    
    req.setTimeout(8000, () => { req.destroy(); resolve(null); });
    req.on('error', () => resolve(null));
  });
}

/**
 * 从 install_url 解析 owner/repo
 * 支持格式：
 *   https://github.com/owner/repo
 *   https://github.com/owner/repo.git
 *   https://www.github.com/owner/repo/tree/main
 */
function parseGitHubRepo(url) {
  if (!url || !url.includes('github.com')) return null;
  const match = url.match(/github\.com\/([^/]+\/[^/#?]+?)(?:\.git|\/|#|\?|$)/i);
  return match ? match[1].replace(/\/$/, '') : null;
}

/**
 * 缓存 GitHub API 结果，避免重复请求同一 repo
 */
const githubCache = new Map();
async function getGitHubInfo(repoFullName) {
  if (!repoFullName || !USE_GITHUB || !GITHUB_TOKEN) return null;
  if (githubCache.has(repoFullName)) return githubCache.get(repoFullName);
  
  // 并行拉取 repo 信息 + 最近 commits
  const [repoInfo, commits] = await Promise.all([
    githubGet(`/repos/${repoFullName}`),
    githubGet(`/repos/${repoFullName}/commits?per_page=5`),
  ]);
  
  // 检测是否有测试文件
  let hasTests = false;
  let testPatterns = [];
  if (repoInfo && repoInfo.default_branch) {
    const treeRes = await githubGet(`/repos/${repoFullName}/git/trees/${repoInfo.default_branch}?recursive=1`);
    if (treeRes && treeRes.tree) {
      const testFiles = treeRes.tree.filter(f =>
        f.path.match(/test|spec|__test__/i) &&
        (f.path.endsWith('.js') || f.path.endsWith('.ts') || f.path.endsWith('.py'))
      );
      hasTests = testFiles.length > 0;
      testPatterns = testFiles.slice(0, 5).map(f => f.path);
    }
  }

  const info = {
    stars: repoInfo?.stars_count || 0,
    forks: repoInfo?.forks_count || 0,
    open_issues: repoInfo?.open_issues_count || 0,
    updated_at: repoInfo?.pushed_at || repoInfo?.updated_at || null,
    created_at: repoInfo?.created_at || null,
    default_branch: repoInfo?.default_branch || 'main',
    license: repoInfo?.license?.spdx_id || null,
    language: repoInfo?.language || null,
    size: repoInfo?.size || 0,
    is_archived: repoInfo?.archived || false,
    recent_commits: (commits || []).map(c => ({
      date: c.commit?.author?.date || c.sha?.substring(0, 7) || null,
      message: (c.commit?.message || '').split('\n')[0].substring(0, 80),
      author: c.commit?.author?.name || 'unknown',
    })),
    has_tests,
    test_file_patterns: testPatterns,
  };
  
  githubCache.set(repoFullName, info);
  return info;
}

// ====== 11维评分函数 ======

/**
 * 维度1: 描述质量分 (weight: 12%)
 *   评估 SKILL.md 描述的完整性、专业度、结构化程度
 *   v2.3: 短描述减罚（-15→-3），新增精炼度奖励（一句话定位=好文案）
 */
function scoreDescription(skill) {
  let score = 35; // 基础分
  const desc = (skill.desc || '').trim();
  
  // 长度评分（v2.3: 短描述减罚，不再把精炼当缺陷）
  if (desc.length >= 500) score += 25;      // 超详细
  else if (desc.length >= 300) score += 20; // 很详细
  else if (desc.length >= 150) score += 14; // 比较详细
  else if (desc.length >= 80) score += 7;   // 一般
  else if (desc.length >= 30) score += 2;   // 简短但够用
  else if (desc.length >= 10) score -= 3;   // 一句话定位（v2.3: 从-15改为-3）
  else score -= 10;                          // 确实缺失（v2.3: 从-15改为-10）
  
  // v2.3 精炼度奖励：短描述但有信息密度 = 好文案
  if (desc.length >= 6 && desc.length < 30) {
    const techKeywords = desc.match(/[A-Z][a-z]+|[A-Z]{2,}|[\u4e00-\u9fa5]{2,4}/g) || [];
    if (techKeywords.length >= 2) {
      score += 18; // v2.3b: 从12提升到18（一句话定位=精炼好文案，与长描述等价）
    } else if (techKeywords.length >= 1) {
      score += 8;  // 至少有一个技术词
    }
  }
  // 额外精炼度：描述虽短但功能清晰（包含动词+名词结构）
  if (desc.length >= 4 && desc.length < 50) {
    if (/管家|助手|中枢|之选|构建|管理|搜索|执行|接入|平台|引擎|自动化/i.test(desc)) {
      score += 6; // 功能定位词加分
    }
  }
  
  // 专业信号检测（扩展版）
  const professionalSignals = [
    // 触发条件（最重要）
    { pattern: /Use when|use when|触发|适用场景/i, weight: 8 },
    { pattern: /NOT for|不要.*用|不适合|避免|Do NOT/i, weight: 7 },
    // 功能描述
    { pattern: /support|支持|can |able to|能够|允许/i, weight: 4 },
    // 结构标记
    { pattern: /\d\.\s|步骤|step\s\d|workflow|流程/i, weight: 5 },
    { pattern: /example|示例|例如|比如|sample/i, weight: 4 },
    // 技术细节
    { pattern: /API|接口|endpoint|parameter|参数|config|配置/i, weight: 4 },
    { pattern: /install|安装|setup|部署|requirement|依赖/i, weight: 3 },
    // 错误处理提示
    { pattern: /error|fail|如果.*失败|troubleshoot|注意|warning/i, weight: 3 },
    // 版本/更新信息
    { pattern: /v\d|version|版本|更新|changelog|change log/i, weight: 2 },
  ];
  
  let signalScore = 0;
  for (const sig of professionalSignals) {
    if (sig.pattern.test(desc)) signalScore += sig.weight;
  }
  score += Math.min(signalScore, 30);
  
  // 中文适配加分
  if (/[\u4e00-\u9fa5]/.test(desc) && desc.length >= 50) score += 6;
  
  // 结构化标记（编号列表、括号引用等）
  const structMarkers = (desc.match(/\d[\.\)]/g) || []).length;
  if (structMarkers >= 3) score += 8;
  else if (structMarkers >= 2) score += 4;
  
  // 有明确的"如何使用"说明
  if (/how to|怎么|如何|用法|usage|使用方法/i.test(desc)) score += 5;
  
  return Math.max(0, Math.min(100, score));
}

/**
 * 维度2: 标签丰富度 (weight: 7%)
 *   v2.3: 无标签+可信来源给中间分(25)而非极低分(5)
 */
function scoreTags(skill) {
  const tags = skill.tags || [];
  let score = 30;
  
  if (tags.length === 0) {
    // v2.3: 来源可信但无标签 → 给中间分（元数据格式限制，非产品缺陷）
    const trustedSource = ['cocoloop', 'workbuddy', 'openclaw', 'skillhub'].includes((skill.source || '').toLowerCase().split('+')[0]);
    if (trustedSource) return 25;
    return 10; // v2.3: 从5改为10
  }
  
  // 数量评分
  if (tags.length >= 6) score += 28;
  else if (tags.length >= 4) score += 20;
  else if (tags.length >= 2) score += 12;
  else score += 5;
  
  // 标签质量：排除通用词
  const genericWords = ['tool', 'ai', 'utility', 'helper', '工具', '助手', 'app', 'bot'];
  const specificTags = tags.filter(t => {
    const tl = t.toLowerCase().trim();
    return !genericWords.some(g => tl === g || tl.includes(g)) && tl.length >= 2;
  });
  score += Math.min(specificTags.length * 7, 28);
  
  // 多语言标签（维护用心）
  const hasChinese = tags.some(t => /[\u4e00-\u9fa5]/.test(t));
  const hasEnglish = tags.some(t => /^[a-zA-Z][a-zA-Z0-9_\-/.]*$/.test(t));
  if (hasChinese && hasEnglish) score += 8;
  
  // 标签长度合理性（太长或太短都不好）
  const avgLen = tags.reduce((sum, t) => sum + t.length, 0) / tags.length;
  if (avgLen >= 4 && avgLen <= 18) score += 4;
  
  return Math.max(0, Math.min(100, score));
}

/**
 * 维度3: 安装便捷度 (weight: 8%)
 *   v2.3: search 惩罚从-20减为-5，新增可信来源加分+15
 */
function scoreInstall(skill) {
  let score = 35;
  const method = skill.install_method || '';
  const url = skill.install_url || '';
  const enriched = enrichedMap.get(skill.name.toLowerCase());
  
  // 安装方式评分
  if (method === 'direct' && url) {
    score += 30;
    // GitHub 直连加分
    if (url.includes('github.com')) score += 12;
    // npm 包直连
    else if (url.includes('npmjs.com') || url.includes('npm')) score += 10;
  } else if (method === 'npm' || method === 'plugin') {
    score += 22; // 插件式也还行
  } else if (method === 'search') {
    score -= 5; // v2.3: 从-20减为-5（search只是元数据格式限制，不是产品缺陷）
  } else {
    score += 5;
  }
  
  // v2.3: 有可信来源的 search 安装 → 用户能找到，不扣分
  const trustedSource = ['cocoloop', 'workbuddy', 'openclaw', 'skillhub', 'clawhub'].includes((skill.source || '').toLowerCase().split('+')[0]);
  if (method === 'search' && trustedSource) {
    score += 20; // v2.3b: 从15提升到20（来源可信=可安装）
  }
  
  // install_hint 分析
  if (enriched && enriched.install_hint) {
    const hint = (enriched.install_hint.hint || '').toLowerCase();
    
    // 具体安装命令加分
    if (/npm\s+(install|i)\s|pip\s+install|brew\s+install|cargo\s+add/i.test(hint)) {
      score += 18;
    } else if (/curl|wget|git\s+clone|npx/i.test(hint)) {
      score += 12; // 有命令但可能不安全
    } else if (/find-skills|搜索|search/i.test(hint)) {
      score -= 3; // v2.3: 从-10减为-3（套娃但来源可信时上面已补分）
    }
    
    // hint 里给了具体 URL 加分
    if ((enriched.install_hint.url || '').startsWith('http')) score += 8;
  }
  
  // 安装前是否说明了前置条件
  const desc = (skill.desc || '');
  if (/require|need|前提|依赖|prerequisite|before.*install/i.test(desc)) score += 8;
  
  return Math.max(0, Math.min(100, score));
}

/**
 * 维度4: 安全信号 (weight: 15%) — 一票否决制
 */
function scoreSafety(skill) {
  let score = 75; // 默认安全
  const desc = (skill.desc || '');
  const url = (skill.install_url || '');
  const combined = desc + ' ' + url;
  const enriched = enrichedMap.get(skill.name.toLowerCase());
  const hint = (enriched?.install_hint?.hint || '') + ' ' + (enriched?.install_hint?.url || '');
  const fullText = combined + ' ' + hint;
  
  // 🔴 致命危险（一票否决）
  const fatalPatterns = [
    { pattern: /curl\s+.*\|\s*(bash|sh|python|node|exec|perl)/i, penalty: -120, label: '远程脚本管道执行(curl|bash)' },
    { pattern: /wget\s+.*\|\s*(bash|sh)/i, penalty: -120, label: '远程脚本管道执行(wget|bash)' },
    { pattern: /eval\s*\(\s*['"]/i, penalty: -90, label: 'eval动态执行字符串' },
    { pattern: /rm\s+-rf\s+[~/$]|del\s+\/S\/Q/i, penalty: -120, label: '破坏性递归删除' },
    { pattern: /chmod\s+777/i, penalty: -60, label: '危险权限设置(777)' },
    { pattern: /--unsafe|--insecure|-k\s+https|no-check-certificate/i, penalty: -50, label: '禁用SSL证书验证' },
  ];
  
  let fatalReason = null;
  for (const fp of fatalPatterns) {
    if (fp.pattern.test(fullText)) {
      score += fp.penalty;
      if (!fatalReason) fatalReason = fp.label;
    }
  }
  
  // 🔴 密钥/API Key 依赖检测
  const keyPatterns = [
    { pattern: /API_KEY|API_SECRET|SECRET_KEY/i, label: 'API密钥' },
    { pattern: /PRIVATE_KEY|PASSPHRASE/i, label: '私钥/密码短语' },
    { pattern: /OPENAI_API_KEY|ANTHROPIC_API_KEY/i, label: 'AI服务密钥' },
    { pattern: /TENCENT.*SECRET|AWS_ACCESS|ALIYUN.*KEY/i, label: '云服务凭证' },
    { pattern: /SLACK_TOKEN|DISCORD_TOKEN|TELEGRAM_BOT/i, label: '平台Token' },
    { pattern: /DATABASE_URL|MONGO_URI|REDIS_URL/i, label: '数据库连接串' },
    { pattern: /OAUTH.*CLIENT_ID|APP_SECRET/i, label: 'OAuth凭证' },
  ];
  
  let detectedKeys = [];
  for (const kp of keyPatterns) {
    if (kp.pattern.test(fullText)) detectedKeys.push(kp.label);
  }
  
  if (detectedKeys.length > 0) {
    // 密钥依赖本身不致命，但需要降权
    score -= Math.min(detectedKeys.length * 6, 25);
  }
  
  // 🟡 敏感操作
  if (/(sudo|admin|root privilege)/i.test(fullText)) score -= 8;
  if (/access.*token|login.*required|authenticate/i.test(fullText)) score -= 5;
  
  // 🟢 安全加分项
  if (/permission|权限检查|安全检查|sandbox|沙箱/i.test(desc)) score += 8;
  if (/readonly|只读|read.?only|scan.*only|dry.?run/i.test(desc)) score += 5;
  if (/no.*external.*request|离线|local.*only|no.*network/i.test(desc)) score += 8;
  // 是否说明了数据隐私
  if (/privacy|privacy|数据不会|不上传|本地处理/i.test(desc)) score += 6;
  
  return Math.max(-30, Math.min(100, score)); // 允许负分用于一票否决判定
}

/**
 * 维度5: 依赖复杂度 (weight: 10%)
 *   检测 skill 是否有外部依赖（API Key、登录、第三方服务、系统包等）
 *   依赖越少越好装，越多越容易失败
 */
function scoreDependencyComplexity(skill) {
  let score = 70; // 默认低依赖
  const desc = (skill.desc || '');
  const enriched = enrichedMap.get(skill.name.toLowerCase());
  const hint = (enriched?.install_hint?.hint || '');
  const fullText = desc + ' ' + hint;
  
  let dependencies = [];
  let depWeight = 0;
  
  // 🔴 重型依赖（严重降低可用性）
  const heavyDeps = [
    { pattern: /docker|containerize|docker-compose/i, label: 'Docker环境', weight: 25 },
    { pattern: /gpu|cuda|tensor[i]?flow|pytorch\s+gpu/i, label: 'GPU/CUDA', weight: 25 },
    { pattern: /postgres|mysql|mongodb|redis.*server|elastic/i, label: '数据库服务器', weight: 20 },
    { pattern: /kubernetes|k8s|minikube/i, label: 'Kubernetes集群', weight: 25 },
    { pattern: /aws.*cli|gcloud|azure.*cli/i, label: '云CLI工具', weight: 15 },
  ];
  
  for (const dep of heavyDeps) {
    if (dep.pattern.test(fullText)) {
      dependencies.push(`🔴 ${dep.label}`);
      depWeight += dep.weight;
    }
  }
  
  // 🟡 中型依赖
  const mediumDeps = [
    { pattern: /python\s+\d|node\s*\d+|npm|yarn|pnpm|pip/i, label: '运行时/包管理器', weight: 8 },
    { pattern: /chrome|chromium|firefox|playwright|puppeteer|selenium/i, label: '浏览器运行时', weight: 12 },
    { pattern: /ffmpeg|imagemagick|ghostscript|pandoc/i, label: '系统工具(ffmpeg等)', weight: 10 },
    { pattern: /openai|anthropic|claude|gemini|llm.*api/i, label: 'LLM API服务', weight: 10 },
    { pattern: /google.*api|twitter.*api|slack.*api|discord.*api/i, label: '第三方平台API', weight: 10 },
    { pattern: /oauth|认证|登录|login.*required|account/i, label: '账号/登录', weight: 8 },
  ];
  
  for (const dep of mediumDeps) {
    if (dep.pattern.test(fullText)) {
      dependencies.push(`🟡 ${dep.label}`);
      depWeight += dep.weight;
    }
  }
  
  // 🟢 轻型/正常依赖（不扣分但记录）
  const lightDeps = [
    { pattern: /npm install|pip install/i, label: 'npm/pip安装', weight: 0 },
    { pattern: /api[_-]?key|token|required/i, label: 'API Key配置', weight: 5 },
  ];
  
  for (const dep of lightDeps) {
    if (dep.pattern.test(fullText) && !dependencies.find(d => d.includes(dep.label))) {
      dependencies.push(`🟢 ${dep.label}`);
      depWeight += dep.weight;
    }
  }
  
  score -= depWeight;
  
  // 无任何依赖的纯本地工具加分
  if (dependencies.length === 0 && !/require|need|install|depend/i.test(fullText)) {
    score += 15;
    dependencies.push('✅ 无显式依赖');
  }
  
  // 返回带详情的分数
  return {
    score: Math.max(0, Math.min(100, score)),
    dependencies,
    dep_count: dependencies.length,
    dep_weight: depWeight,
  };
}

/**
 * 维度6: 文档结构质量 (weight: 10%)
 *   评估 MD 文件的结构化程度（基于描述文本和 highlights 推断）
 */
function scoreDocStructure(skill) {
  let score = 30;
  const desc = (skill.desc || '');
  const highlights = skill.highlights || [];
  const enriched = enrichedMap.get(skill.name.toLowerCase());
  
  // 描述结构化程度
  const structSignals = [];
  
  // 有 "Use when / NOT for" 分段
  if (/Use when/i.test(desc) && /NOT for/i.test(desc)) {
    structSignals.push('明确触发条件和边界');
    score += 15;
  }
  
  // 编号列表
  const numberedItems = (desc.match(/\d[\.\)]\s|[\(（]\d[\)）]\s/g) || []).length;
  if (numberedItems >= 4) { structSignals.push(`${numberedItems}个编号列表`); score += 12; }
  else if (numberedItems >= 2) { score += 6; }
  
  // 有 examples / 示例
  if (/example|示例|例如|sample code|code:?/i.test(desc)) {
    structSignals.push('包含示例');
    score += 10;
  }
  
  // 有 FAQ 或 Troubleshooting
  if (/faq|常见问题| troubleshoot|故障|问题解决|note|注意/i.test(desc)) {
    structSignals.push('FAQ/注意事项');
    score += 8;
  }
  
  // 有 Changelog / 更新记录
  if (/changelog|更新日志|version history|what'?s new/i.test(desc)) {
    structSignals.push('更新日志');
    score += 5;
  }
  
  // highlights 字段质量
  if (highlights.length >= 3) {
    // 检查 highlights 是否是模板化的复制粘贴
    const templatePhrases = ['超大型开源项目', '文档完善', '边界明确'];
    const uniqueHighlights = highlights.filter(h => !templatePhrases.some(p => h.includes(p)));
    if (uniqueHighlights.length >= 2) {
      structSignals.push(`${highlights.length}条亮点(非模板)`);
      score += 10;
    } else if (highlights.length >= 2) {
      structSignals.push(`${highlights.length}条亮点`);
      score += 5;
    }
  }
  
  // recommend_reason 质量判断
  if (enriched?.recommend_reason) {
    const rr = enriched.recommend_reason;
    // 长且具体的推荐理由
    if (rr.length >= 30 && rr.split(/[·|,]/).length >= 3) {
      structSignals.push('详细推荐理由');
      score += 8;
    }
  }
  
  // vs_note（对比分析）
  if (enriched?.vs_note) {
    structSignals.push('竞品对比');
    score += 6;
  }
  
  // 总长度足够长（说明内容充实）
  if (desc.length >= 400) score += 5;
  
  return {
    score: Math.max(0, Math.min(100, score)),
    signals: structSignals,
  };
}

/**
 * 维度7: 错误处理机制 (weight: 8%)
 *   检测 skill 是否考虑了异常情况
 */
function scoreErrorHandling(skill) {
  let score = 30; // 大多数 skill 不提错误处理
  const desc = (skill.desc || '');
  const hints = (enrichedMap.get(skill.name.toLowerCase())?.install_hint?.hint || '');
  const fullText = desc + ' ' + hints;
  
  let signals = [];
  
  // 明确说了不支持什么（边界意识 = 最好的错误预防）
  if (/NOT for|don'?t use|不适合|不支持|无法|not support|cannot/i.test(fullText)) {
    signals.push('明确声明边界/限制');
    score += 20;
  }
  
  // 提到了错误场景的处理
  const errorPatterns = [
    { pattern: /if.*fail|如果.*失败|when.*error|出错时|on error/i, msg: '失败处理指引' },
    { pattern: /fallback|降级|备选方案|alternative/i, msg: '降级方案' },
    { pattern: /timeout|超时|重试|retry|try again/i, msg: '超时/重试策略' },
    { pattern: /empty result|no data|无结果|空返回/i, msg: '空结果处理' },
    { pattern: /rate limit|限流|throttl|频率限制/i, msg: '限流应对' },
    { pattern: /permission denied|权限不足|no access|没有权限/i, msg: '权限错误处理' },
    { pattern: /check.*first|verify|验证.*before|确认/i, msg: '预检查机制' },
  ];
  
  for (const ep of errorPatterns) {
    if (ep.pattern.test(fullText)) {
      signals.push(ep.msg);
      score += 10;
    }
  }
  score = Math.min(score, 30 + errorPatterns.length * 10); // 上限控制
  
  // 有 troubleshooting 章节
  if (/troubleshoot|常见问题|faq|known issue|已知问题/i.test(fullText)) {
    signals.push('FAQ/Troubleshooting');
    score += 10;
  }
  
  // 提供了联系方式或 issue 渠道
  if (/issue|github.*issue|反馈|contact|联系作者|bug report/i.test(fullText)) {
    signals.push('问题反馈渠道');
    score += 5;
  }
  
  // 安全相关警告（也算一种错误预防）
  if (/warning| caution| ⚠️|注意.*安全|小心/i.test(fullText)) {
    signals.push('安全警告');
    score += 5;
  }
  
  return {
    score: Math.max(0, Math.min(100, score)),
    signals,
  };
}

/**
 * 维度8: 维护活跃度 (weight: 12%) — 需要GitHub API，否则用元数据推断
 */
async function scoreMaintenanceActivity(skill, githubInfo) {
  let score = 40; // 基础分：未知维护状态
  let signals = [];
  
  if (githubInfo) {
    // ★ 真实 GitHub 数据
    const now = new Date();
    const lastPush = githubInfo.updated_at ? new Date(githubInfo.updated_at) : null;
    const createdAt = githubInfo.created_at ? new Date(githubInfo.created_at) : null;
    
    // 已归存 = 死了
    if (githubInfo.is_archived) {
      signals.push('💀 仓库已归档(archived)');
      return { score: 0, signals, source: 'github_api', details: githubInfo };
    }
    
    // 根据 last push 时间评分
    if (lastPush) {
      const daysSincePush = Math.floor((now - lastPush) / (1000 * 60 * 60 * 24));
      
      if (daysSincePush <= 7) { score = 95; signals.push(`🟢 ${daysSincePush}天内有推送`); }
      else if (daysSincePush <= 30) { score = 85; signals.push(`🟢 ${Math.round(daysSincePush)}天内有推送`); }
      else if (daysSincePush <= 90) { score = 70; signals.push(`🟡 ${Math.round(daysSincePush/30)}个月前最后推送`); }
      else if (daysSincePush <= 180) { score = 50; signals.push(`🟠 ${Math.round(daysSincePush/30)}个月前最后推送`); }
      else if (daysSincePush <= 365) { score = 30; signals.push(`🔴 超过半年未更新`); }
      else { score = 10; signals.push(`💀 ${Math.round(daysSincePush/365)}年未更新`); }
    }
    
    // commit 频率
    if (githubInfo.recent_commits && githubInfo.recent_commits.length > 0) {
      const oldestCommit = new Date(githubInfo.recent_commits[githubInfo.recent_commits.length - 1].date);
      const commitDays = Math.floor((now - oldestCommit) / (1000 * 60 * 60 * 24));
      const commitFreq = commitDays > 0 ? (githubInfo.recent_commits.length / commitDays).toFixed(2) : 'N/A';
      signals.push(`最近${githubInfo.recent_commits.length}次提交(频率~${commitFreq}/天)`);
      
      // 高频提交加分
      if (parseFloat(commitFreq) >= 1) score = Math.min(score + 8, 100);
    }
    
    // Stars 和 forks 作为社区健康指标
    if (githubInfo.stars >= 1000) signals.push(`⭐ ${githubInfo.stars}stars`);
    else if (githubInfo.stars >= 100) signals.push(`⭐ ${githubInfo.stars}stars`);
    if (githubInfo.forks >= 50) signals.push(`🍴 ${githubInfo.forks}forks`);
    
    // Open issues 过多扣分（维护者响应不及时）
    if (githubInfo.open_issues > 50) {
      score -= 10;
      signals.push(`⚠️ ${githubInfo.open_issues}个开放issue`);
    }
    
    // 有 license 说明规范
    if (githubInfo.license) signals.push(`📜 ${githubInfo.license}`);
    
    return { 
      score: Math.max(0, Math.min(100, score)), 
      signals, 
      source: 'github_api',
      details: {
        stars: githubInfo.stars,
        pushed_at: githubInfo.updated_at,
        archived: githubInfo.is_archived,
        open_issues: githubInfo.open_issues,
        language: githubInfo.language,
        license: githubInfo.license,
      },
    };
    
  } else {
    // 🔽 无 GitHub 数据时的元数据推断（粗糙但有总比没有好）
    const source = skill.source || '';
    const desc = (skill.desc || '');
    
    // 来源可信度作为维护代理指标
    if (source === 'openclaw') { score += 25; signals.push('官方openclaw源'); }
    else if (source === 'workbuddy') { score += 20; signals.push('WorkBuddy官方源'); }
    else if (source === 'cocoloop' || source === 'skillhub') { score += 12; signals.push('榜单/市场源'); }
    else if (source === 'minimaxi') { score += 5; signals.push('镜像源(可能有延迟)'); }
    else { signals.push('来源不明'); score -= 10; }
    
    // 描述中提到版本号暗示还在维护
    if (/v?\d+\.\d+/i.test(desc)) { score += 8; signals.push('含版本号'); }
    // 提到 recently / latest / updated
    if (/recently|最新版|latest version|recent update|202[5-9]/i.test(desc)) { 
      score += 10; 
      signals.push('提及近期更新'); 
    }
    
    // stars 高分通常代表维护较好
    if ((skill.stars || 0) >= 4) { score += 10; signals.push(`高星(${skill.stars})`); }
    
    return { score: Math.max(0, Math.min(100, score)), signals, source: 'metadata_inference' };
  }
}

/**
 * 维度9: 测试覆盖信号 (weight: 8%) — 需要GitHub API
 */
function scoreTestCoverage(skill, githubInfo) {
  if (!githubInfo) {
    // 无 GitHub 数据时从描述文本推断
    const desc = (skill.desc || '');
    let score = 20;
    let signals = [];
    
    if (/test|testing|单元测试|e2e|integration test/i.test(desc)) {
      score += 25;
      signals.push('文档中提及测试');
    }
    if (/jest|mocha|vitest|pytest|coverage|ci\/cd/i.test(desc)) {
      score += 20;
      signals.push('提及测试框架');
    }
    if (/quality gate|lint|eslint|prettier|type[s]?cript strict/i.test(desc)) {
      score += 10;
      signals.push('提及代码质量工具');
    }
    
    return { score: Math.max(0, Math.min(100, score)), signals, source: 'text_inference', has_tests: false };
  }
  
  // ★ GitHub API 真实数据
  if (githubInfo.has_tests) {
    const testCount = githubInfo.test_file_patterns.length;
    return {
      score: Math.min(80 + testCount * 4, 100),
      signals: [`发现${testCount}个测试文件`, ...githubInfo.test_file_patterns.slice(0, 3)],
      source: 'github_api',
      has_tests: true,
      test_files: githubInfo.test_file_patterns,
    };
  }
  
  return { 
    score: 15, 
    signals: ['未发现测试文件'], 
    source: 'github_api', 
    has_tests: false,
    test_files: [],
  };
}

/**
 * 维度13: 市场验证分 (weight: 8%)
 *   数据源：cocoloop 榜单排名、星级、来源可信度、赛道上榜数
 *   核心逻辑：市场已验证 = 最硬的质量信号（类似"票房"）
 *   v2.3 新增维度
 */
function scoreMarketValidation(skill) {
  let score = 25; // 基础分：未验证
  const stars = skill.stars || 0;
  const source = (skill.source || '').toLowerCase().split('+')[0];
  const enriched = enrichedMap.get(skill.name.toLowerCase());
  let signals = [];
  
  // ⭐ 星级评分（最强市场信号）
  if (stars >= 5) { score += 30; signals.push('⭐5星'); }
  else if (stars >= 4) { score += 22; signals.push('⭐4星'); }
  else if (stars >= 3) { score += 12; signals.push('⭐3星'); }
  else if (stars >= 2) { score += 5; signals.push('⭐2星'); }
  
  // 🏅 来源可信度（榜单/官方筛选 = 市场验证）
  if (source === 'cocoloop') { score += 15; signals.push('🏅cocoloop榜单'); }
  else if (source === 'workbuddy') { score += 12; signals.push('🏅WorkBuddy官方'); }
  else if (source === 'openclaw') { score += 8; signals.push('🏅openclaw'); }
  else if (source === 'microsoft') { score += 8; signals.push('🏅Microsoft'); }
  else if (source === 'clawhub') { score += 5; signals.push('🏅clawhub'); }
  
  // 🏆 上榜信号（enriched 数据中的榜单信息）
  if (enriched) {
    const chartCount = enriched.chart_count || (enriched.charts ? enriched.charts.length : 0);
    if (chartCount >= 3) { score += 15; signals.push('🏆' + chartCount + '榜上榜'); }
    else if (chartCount >= 2) { score += 10; signals.push('🏆' + chartCount + '榜上榜'); }
    else if (chartCount >= 1) { score += 5; signals.push('🏆上榜'); }
  }
  
  // 🔥 高星+榜单的组合加分（市场双重验证）
  if (stars >= 4 && (source === 'cocoloop' || source === 'workbuddy')) {
    score += 5; // 上榜+高星 = 强验证
    signals.push('🔥双重验证');
  }
  
  return {
    score: Math.max(0, Math.min(100, score)),
    signals: signals,
    source: 'market_validation',
  };
}

// ====== 综合评分（同步版，用于无GitHub API时）======

function scanSkillSync(skill) {
  const descScore = scoreDescription(skill);
  const tagScore = scoreTags(skill);
  const installScore = scoreInstall(skill);
  const safetyScore = scoreSafety(skill);
  const depResult = scoreDependencyComplexity(skill);           // 返回对象
  const docResult = scoreDocStructure(skill);                   // 返回对象
  const errResult = scoreErrorHandling(skill);                  // 返回对象
  const marketValResult = scoreMarketValidation(skill);         // v2.3: 第13维
  
  // 维度8-9 用元数据推断替代（同步，无需网络请求）
  const maintResult = { score: 70, signals: ['元数据推断（无GitHub API）'], source: 'metadata_inference' };
  // 把维护信号的逻辑内联一下
  const source = skill.source || '';
  if (source === 'openclaw') maintResult.score += 20;
  else if (source === 'workbuddy') maintResult.score += 15;
  else if (['cocoloop', 'skillhub'].includes(source)) maintResult.score += 8;
  if ((skill.stars || 0) >= 4) maintResult.score += 10;
  maintResult.score = Math.max(0, Math.min(100, maintResult.score));
  
  const testResult = { score: 20, signals: ['未检测（需GitHub API）'], source: 'skipped', has_tests: false };
  
  return buildFinalScore(skill, descScore, tagScore, installScore, safetyScore, 
    depResult, docResult, errResult, maintResult, testResult, null, null, marketValResult);
}

// ====== 综合评分（异步版，含GitHub API）======

async function scanSkillAsync(skill) {
  const descScore = scoreDescription(skill);
  const tagScore = scoreTags(skill);
  const installScore = scoreInstall(skill);
  const safetyScore = scoreSafety(skill);
  const depResult = scoreDependencyComplexity(skill);
  const docResult = scoreDocStructure(skill);
  const errResult = scoreErrorHandling(skill);
  const marketValResult = scoreMarketValidation(skill);         // v2.3: 第13维
  
  // GitHub API 调用
  const repoPath = parseGitHubRepo(skill.install_url || '');
  const githubInfo = await getGitHubInfo(repoPath);
  
  const maintResult = await scoreMaintenanceActivity(skill, githubInfo);
  const testResult = scoreTestCoverage(skill, githubInfo);
  
  return buildFinalScore(skill, descScore, tagScore, installScore, safetyScore,
    depResult, docResult, errResult, maintResult, testResult, githubInfo, null, marketValResult);
}

/**
 * 同步版：使用预缓存的 GitHub 数据给 skill 打分（不调 API）
 * 用于 Phase 3 批量评分
 */
function scanSkillWithGitHub(skill, ghCacheData, marketResult) {
  const descScore = scoreDescription(skill);
  const tagScore = scoreTags(skill);
  const installScore = scoreInstall(skill);
  const safetyScore = scoreSafety(skill);
  const depResult = scoreDependencyComplexity(skill);
  const docResult = scoreDocStructure(skill);
  const errResult = scoreErrorHandling(skill);
  const marketValResult = scoreMarketValidation(skill);         // v2.3: 第13维
  
  // 用缓存数据构造 githubInfo 对象（与 getGitHubInfo 返回格式一致）
  let githubInfo = null;
  if (ghCacheData && ghCacheData.info) {
    const info = ghCacheData.info;
    const commits = ghCacheData.commits || [];
    
    // 从 commits 推算最后提交时间和频率
    let lastCommitDate = null;
    let commitFreqDays = null;
    if (commits.length > 0) {
      lastCommitDate = commits[0]?.commit?.author?.date || commits[0]?.sha?.substring(0, 7);
      if (commits.length >= 2 && commits[0]?.commit?.author?.date && commits[commits.length-1]?.commit?.author?.date) {
        const d1 = new Date(commits[0].commit.author.date);
        const d2 = new Date(commits[commits.length-1].commit.author.date);
        const diffMs = Math.abs(d1 - d2);
        commitFreqDays = Math.round(diffMs / (1000 * 60 * 60 * 24) / (commits.length - 1));
      }
    }
    
    githubInfo = {
      stars: info.stargazers_count || info.stars_count || 0,
      forks: info.forks_count || 0,
      open_issues: info.open_issues_count || 0,
      updated_at: info.pushed_at || info.updated_at || null,
      created_at: info.created_at || null,
      archived: info.archived || false,
      license: info.license?.spdx_id || info.license?.name || null,
      default_branch: info.default_branch || 'main',
      language: info.language || null,
      last_commit_date: lastCommitDate,
      commit_frequency_days: commitFreqDays,
      has_tests: ghCacheData.hasTests || false,
      topics: info.topics || [],
      size: info.size || 0,
    };
  }
  
  const maintResult = scoreMaintenanceActivitySync(skill, githubInfo);
  const testResult = scoreTestCoverage(skill, githubInfo);
  
  return buildFinalScore(skill, descScore, tagScore, installScore, safetyScore,
    depResult, docResult, errResult, maintResult, testResult, githubInfo, marketResult, marketValResult);
}

/**
 * 同步版维护活跃度评分（用于缓存数据模式）
 */
function scoreMaintenanceActivitySync(skill, githubInfo) {
  if (!githubInfo) {
    return { score: 35, signals: ['无 GitHub 信息'], source: 'none' };
  }
  
  let score = 50; // 基础分
  const signals = [];
  
  // Archived → 一票否决
  if (githubInfo.archived) {
    return { score: 0, signals: ['仓库已归档(archived)'], source: 'github_archived' };
  }
  
  // 最后推送时间
  if (githubInfo.updated_at) {
    const daysAgo = daysSince(githubInfo.updated_at);
    if (daysAgo <= 30) { score += 25; signals.push(`最近更新(${daysAgo}天前)`); }
    else if (daysAgo <= 90) { score += 18; signals.push(`${daysAgo}天前更新`); }
    else if (daysAgo <= 180) { score += 10; signals.push(`${daysAgo}天前更新`); }
    else if (daysAgo <= 365) { score += 2; signals.push(`1年+未更新`); }
    else { score -= 15; signals.push(`超久未更新(${daysAgo}天)`); }
  }
  
  // Commit 频率
  if (githubInfo.commit_frequency_days !== null) {
    if (githubInfo.commit_frequency_days <= 7) { score += 10; signals.push('周更+'); }
    else if (githubInfo.commit_frequency_days <= 30) { score += 5; signals.push('月更'); }
    else if (githubInfo.commit_frequency_days > 90) { score -= 5; signals.push('低频维护'); }
  }
  
  // Stars 社区认可
  if (githubInfo.stars >= 500) { score += 8; signals.push(`⭐${githubInfo.stars}`); }
  else if (githubInfo.stars >= 100) { score += 5; signals.push(`⭐${githubInfo.stars}`); }
  else if (githubInfo.stars >= 20) { score += 2; signals.push(`⭐${githubInfo.stars}`); }
  
  // License
  if (githubInfo.license) { score += 4; signals.push(`License: ${githubInfo.license}`); }
  
  // Open issues 过多扣分
  if (githubInfo.open_issues > 50) { score -= 8; signals.push(`🐛${githubInfo.open_issues} issues`); }
  else if (githubInfo.open_issues > 20) { score -= 3; signals.push(`${githubInfo.open_issues} open issues`); }
  
  score = Math.max(0, Math.min(100, score));
  return { score, signals: signals.slice(0, 4), source: 'github_cached' };
}

/**
 * 构建最终评分结果
 * v2.3: 13维权重体系（新增市场验证8%）
 *   描述12% 标签7% 安装8% 安全14% 依赖8% 文档7% 错误5% 维护10% 测试5% 市场热度7% 市场验证8%
 */
function buildFinalScore(skill, descScore, tagScore, installScore, safetyScore,
  depResult, docResult, errResult, maintResult, testResult, githubInfo = null,
  marketResult = null, marketValResult = null) {
  
  // 解构各维度分数
  const d_dep = typeof depResult === 'object' ? depResult.score : depResult;
  const d_doc = typeof docResult === 'object' ? docResult.score : docResult;
  const d_err = typeof errResult === 'object' ? errResult.score : errResult;
  const d_maint = typeof maintResult === 'object' ? maintResult.score : maintResult;
  const d_test = typeof testResult === 'object' ? testResult.score : testResult;
  const d_market = (marketResult !== null && typeof marketResult === 'object') ? marketResult.score : (marketResult || null);
  const d_marketVal = (marketValResult !== null && typeof marketValResult === 'object') ? marketValResult.score : (marketValResult || null);
  
  // v2.3: 13维加权综合分
  // 市场验证(marketVal)始终可用，市场热度(market)需--skillhub
  // 无市场热度时，其7%权重按比例分配给其他维度
  const hasMarketHeat = d_market !== null;
  
  // 有市场热度时的完整权重（合计1.0）
  const w = hasMarketHeat
    ? { desc: 0.12, tag: 0.07, install: 0.08, safety: 0.14, dep: 0.08, doc: 0.07, err: 0.05, maint: 0.10, test: 0.05, market: 0.07, marketVal: 0.08 }
    : { desc: 0.129, tag: 0.075, install: 0.086, safety: 0.151, dep: 0.086, doc: 0.075, err: 0.054, maint: 0.108, test: 0.054, marketVal: 0.086 };
  // 无市场热度时，7%按原比例分配给前9维+市场验证
  
  const rawQuality = hasMarketHeat
    ? descScore * w.desc + tagScore * w.tag + installScore * w.install + safetyScore * w.safety
      + d_dep * w.dep + d_doc * w.doc + d_err * w.err + d_maint * w.maint + d_test * w.test
      + d_market * w.market + d_marketVal * w.marketVal
    : descScore * w.desc + tagScore * w.tag + installScore * w.install + safetyScore * w.safety
      + d_dep * w.dep + d_doc * w.doc + d_err * w.err + d_maint * w.maint + d_test * w.test
      + d_marketVal * w.marketVal;
  
  const weightedQuality = Math.round(rawQuality);
  
  // 质量等级
  let grade, gradeLabel;
  if (weightedQuality >= 80) { grade = 'A+'; gradeLabel = '卓越'; }
  else if (weightedQuality >= 70) { grade = 'A'; gradeLabel = '优秀'; }
  else if (weightedQuality >= 55) { grade = 'B+'; gradeLabel = '良好+'; }
  else if (weightedQuality >= 45) { grade = 'B'; gradeLabel = '良好'; }
  else if (weightedQuality >= 35) { grade = 'C'; gradeLabel = '及格'; }
  else if (weightedQuality >= 20) { grade = 'D'; gradeLabel = '较差'; }
  else { grade = 'F'; gradeLabel = '不合格'; }
  
  // 问题检测（v2.3: 适配新权重阈值）
  const issues = [];
  if (descScore < 25) issues.push('描述过短或不清晰');
  if (tagScore < 15) issues.push('标签缺失或过于通用');
  if (installScore < 25) issues.push('安装方式不友好');
  if (safetyScore <= 0) issues.push('🔴 存在致命安全隐患');
  if (safetyScore < 40) issues.push('⚠️ 安全风险较高');
  if (d_dep < 30) issues.push('🔗 依赖较重（影响安装成功率）');
  if (d_doc < 25) issues.push('📄 文档结构差（缺乏使用指引）');
  if (d_err < 20) issues.push('⚠️ 缺少错误处理说明');
  if (d_maint < 30 && maintResult.signals) issues.push('🔄 可能已停止维护: ' + maintResult.signals[0]);
  if (d_test < 15) issues.push('🧪 无测试覆盖证据');
  if (d_market !== null && d_market < 25) issues.push('📈 市场认可度低');
  if (d_marketVal !== null && d_marketVal < 30) issues.push('🏅 市场验证不足');
  if ((skill.tags || []).length === 0 && !['cocoloop', 'workbuddy', 'openclaw', 'skillhub'].includes((skill.source || '').toLowerCase().split('+')[0])) issues.push('无分类标签');
  
  // 依赖和安全详情
  const deps = typeof depResult === 'object' ? depResult.dependencies : [];
  const safetyFatal = safetyScore <= 0;
  
  return {
    name: skill.name,
    _skill: skill,
    quality_score: weightedQuality,
    quality_grade: grade,
    quality_label: gradeLabel,
    
    // 13维明细
    dimensions: {
      description: descScore,
      tags: tagScore,
      install: installScore,
      safety: safetyScore,
      dependency: d_dep,
      doc_structure: d_doc,
      error_handling: d_err,
      maintenance: d_maint,
      tests: d_test,
      market: d_market,
      market_validation: d_marketVal, // v2.3 NEW
    },
    
    // 详情（用于 detail 查看）
    details: {
      dependencies: deps,
      dep_count: deps.length,
      doc_signals: typeof docResult === 'object' ? docResult.signals : [],
      error_signals: typeof errResult === 'object' ? errResult.signals : [],
      maintenance_signals: typeof maintResult === 'object' ? maintResult.signals : [],
      maintenance_source: typeof maintResult === 'object' ? maintResult.source : 'unknown',
      test_info: typeof testResult === 'object' ? {
        has_tests: testResult.has_tests || false,
        signals: testResult.signals || [],
        source: testResult.source || 'unknown',
      } : {},
      market_info: (marketResult && typeof marketResult === 'object') ? {
        score: marketResult.score,
        signals: marketResult.signals || [],
        source: marketResult.source || 'unknown',
        raw: marketResult.raw || null,
      } : null,
      market_validation_info: (marketValResult && typeof marketValResult === 'object') ? {
        score: marketValResult.score,
        signals: marketValResult.signals || [],
        source: marketValResult.source || 'unknown',
      } : null,
    },
    
    safety_fatal: safetyFatal,
    issues: issues,
    
    // GitHub 信息（如果有）
    github: githubInfo ? {
      stars: githubInfo.stars,
      updated_at: githubInfo.updated_at,
      archived: githubInfo.archived,
      language: githubInfo.language,
      license: githubInfo.license,
    } : null,

    // SkillHub 信息（如果有）
    skillhub: (marketResult && marketResult.raw) ? marketResult.raw : null,
  };
}

// ====== 批量扫描（同步版）======

function scanAllSync() {
  console.log(`🔍 开始扫描 ${rawData.length} 个 skill（13维深度扫描，纯元数据模式）...\n`);
  
  const results = [];
  let stats = { 'A+': 0, A: 0, 'B+': 0, B: 0, C: 0, D: 0, F: 0, fatal: 0 };
  const dimStats = {
    low_desc: 0, low_tag: 0, low_install: 0, unsafe: 0,
    heavy_dep: 0, poor_doc: 0, no_error_handling: 0, unmaintained: 0, no_tests: 0,
  };
  
  let idx = 0;
  for (const skill of rawData) {
    const result = scanSkillSync(skill);
    results.push(result);
    stats[result.quality_grade]++;
    if (result.safety_fatal) stats.fatal++;
    
    // 各维度统计
    if (result.dimensions.description < 30) dimStats.low_desc++;
    if (result.dimensions.tags < 20) dimStats.low_tag++;
    if (result.dimensions.install < 30) dimStats.low_install++;
    if (result.safety_fatal) dimStats.unsafe++;
    if (result.dimensions.dependency < 30) dimStats.heavy_dep++;
    if (result.dimensions.doc_structure < 25) dimStats.poor_doc++;
    if (result.dimensions.error_handling < 20) dimStats.no_error_handling++;
    if (result.dimensions.maintenance < 30) dimStats.unmaintained++;
    if (result.dimensions.tests < 15) dimStats.no_tests++;
    
    idx++;
    if (idx % 200 === 0) process.stdout.write(`  进度: ${idx}/${rawData.length}\r`);
  }
  console.log(`  进度: ${rawData.length}/${rawData.length} ✅\n`);
  
  // ====== v2.3b: Z-score 标准化拉宽分布 ======
  // 原始分太集中(std~4)，用 Z-score 映射到更宽范围
  const rawScores = results.filter(r => r.quality_grade !== 'ERR').map(r => r.quality_score);
  const zMean = rawScores.reduce((a, b) => a + b, 0) / rawScores.length;
  const zStd = Math.sqrt(rawScores.reduce((s, v) => s + Math.pow(v - zMean, 2), 0) / rawScores.length);
  
  const TARGET_MEAN = 55;
  const TARGET_SD = 15;
  const MIN_SCORE = 20;
  const MAX_SCORE = 98;
  
  results.forEach(r => {
    if (r.quality_grade === 'ERR') return;
    const z = (r.quality_score - zMean) / (zStd || 1);
    const normalized = Math.round(Math.max(MIN_SCORE, Math.min(MAX_SCORE, TARGET_MEAN + z * TARGET_SD)));
    r.quality_score_raw = r.quality_score; // 保留原始分
    r.quality_score = normalized;
    
    // 重新计算等级
    if (normalized >= 80) { r.quality_grade = 'A+'; r.quality_label = '卓越'; }
    else if (normalized >= 70) { r.quality_grade = 'A'; r.quality_label = '优秀'; }
    else if (normalized >= 55) { r.quality_grade = 'B+'; r.quality_label = '良好+'; }
    else if (normalized >= 45) { r.quality_grade = 'B'; r.quality_label = '良好'; }
    else if (normalized >= 35) { r.quality_grade = 'C'; r.quality_label = '及格'; }
    else if (normalized >= 20) { r.quality_grade = 'D'; r.quality_label = '较差'; }
    else { r.quality_grade = 'F'; r.quality_label = '不合格'; }
  });
  
  // 重新统计等级
  stats = { 'A+': 0, A: 0, 'B+': 0, B: 0, C: 0, D: 0, F: 0, fatal: 0 };
  results.forEach(r => {
    if (r.quality_grade !== 'ERR') stats[r.quality_grade]++;
    if (r.safety_fatal) stats.fatal++;
  });
  
  // 输出统计
  console.log('📊 13维质量分布（Z-score标准化后）:');
  Object.entries(stats).forEach(([grade, count]) => {
    if (count > 0) {
      const labels = { 'A+': '🌟A+(≥80)卓越', 'A': '🏆A(≥70)优秀', 'B+': '✅B+(≥55)良好+', 'B': '✅B(≥45)良好', 'C': '⚠️C(≥35)及格', 'D': '❌D(≥20)较差', 'F': '💀F(<20)不合格' };
      console.log(`   ${labels[grade] || grade}: ${count} 个 (${(count/rawData.length*100).toFixed(1)}%)`);
    }
  });
  if (stats.fatal > 0) console.log(`   ☠️  致命安全问题: ${stats.fatal} 个`);
  
  console.log('\n📉 各维度薄弱统计（低于阈值）:');
  console.log(`   📝 描述差(<30): ${dimStats.low_desc}个  |  🏷️ 标签差(<20): ${dimStats.low_tag}个`);
  console.log(`   📦 安装难(<30): ${dimStats.low_install}个 |  🛡️ 安全致命: ${dimStats.unsafe}个`);
  console.log(`   🔗 依赖重(<30): ${dimStats.heavy_dep}个 |  📄 文档差(<25): ${dimStats.poor_doc}个`);
  console.log(`   ⚠️ 无错误处理(<20): ${dimStats.no_error_handling}个 |  🔄 可能耗尽(<30): ${dimStats.unmaintained}个`);
  console.log(`   🧪 无测试(<15): ${dimStats.no_tests}个`);
  
  // 保存结果
  const outputPath = path.join(__dirname, 'data', 'quality_v2_scores.json');
  fs.writeFileSync(outputPath, JSON.stringify(results, null, 2), 'utf8');
  console.log(`\n💾 完整评分已保存到 ${outputPath}`);
  
  // 同时输出精简版映射（供 api.js 使用）
  const scoreMap = {};
  for (const r of results) {
    scoreMap[r.name] = {
      q: r.quality_score,
      g: r.quality_grade,
      d: r.dimensions,
      safe: r.safety_fatal,
      deps: r.details.dep_count,
      maint: r.details.maintenance_source,
    };
  }
  const mapPath = path.join(__dirname, 'data', 'quality_map.json');
  fs.writeFileSync(mapPath, JSON.stringify(scoreMap), 'utf8');
  console.log(`💾 质量映射已保存到 ${mapPath}`);
  
  return results;
}

// ====== 批量扫描（异步版 + GitHub API 增强版）======

async function scanAllAsync() {
  if (!GITHUB_TOKEN) {
    console.error('❌ 未设置 GITHUB_TOKEN 环境变量！');
    console.log('   请设置后重试:  $env:GITHUB_TOKEN="ghp_xxxx"; node scanner.js --github');
    console.log('   或回退到纯元数据模式:  node scanner.js\n');
    return scanAllSync();
  }
  
  console.log(`🔍 开始扫描 ${rawData.length} 个 skill（11维深度扫描 + GitHub API 增强）...`);
  console.log(`   GitHub Token: ${GITHUB_TOKEN.substring(0, 8)}...${GITHUB_TOKEN.substring(GITHUB_TOKEN.length - 4)}`);
  console.log(`   API 额度剩余: ${githubRateLimitRemaining === -1 ? '待查询' : githubRateLimitRemaining}`);
  
  // ====== Phase 1: 去重 repo，减少 API 调用 ======
  const repoMap = new Map(); // repoFullName → [skills]
  const nonRepoSkills = [];
  
  for (const skill of rawData) {
    const repo = parseGitHubRepo(skill.install_url);
    if (repo) {
      if (!repoMap.has(repo)) repoMap.set(repo, []);
      repoMap.get(repo).push(skill);
    } else {
      nonRepoSkills.push(skill);
    }
  }
  
  console.log(`\n   📦 Repo 去重: ${rawData.length} 个 skill → ${repoMap.size} 个唯一仓库 + ${nonRepoSkills.length} 个非GitHub`);
  console.log(`   ⏱️  预计 API 调用: ~${repoMap.size * 2} 次（每仓库 repo+commits）\n`);

  // ====== Phase 2: 并行拉取所有 repo 信息（批次大小 10） ======
  const BATCH_SIZE = 10;
  const repos = Array.from(repoMap.keys());
  let fetchedRepos = 0;
  const repoInfoCache = new Map(); // repoFullName → {info, commits}
  
  for (let i = 0; i < repos.length; i += BATCH_SIZE) {
    const batch = repos.slice(i, i + BATCH_SIZE);
    
    await Promise.all(batch.map(async (repo) => {
      try {
        const [repoInfo, commits] = await Promise.all([
          githubGet(`/repos/${repo}`),
          githubGet(`/repos/${repo}/commits?per_page=3`),
        ]);
        
        if (repoInfo || commits) {
          repoInfoCache.set(repo, { info: repoInfo, commits: commits });
          
          // 简单测试检测：只检查 repo 有没有测试目录（不扫 tree 了）
          let hasTests = false;
          if (repoInfo && repoInfo.topics) {
            hasTests = repoInfo.topics.some(t => t.includes('test') || t.includes('coverage'));
          }
          repoInfoCache.get(repo).hasTests = hasTests;
        }
      } catch (e) { /* 单个失败不影响 */ }
      
      fetchedRepos++;
      if (fetchedRepos % 20 === 0 || fetchedRepos === repos.length) {
        console.log(`   📡 GitHub API: ${fetchedRepos}/${repos.length} 仓库已查询 (${(fetchedRepos/repos.length*100).toFixed(0)}%) [已用:${githubApiCount}额度]`);
      }
    }));
    
    // 每批之间小延迟避免触发限流
    if (i + BATCH_SIZE < repos.length) await sleep(300);
  }

  console.log(`\n   ✅ GitHub data collected! ${githubApiCount} API calls used\n`);

  // ====== Phase 2.5: Fetch SkillHub market data (if enabled) ======
  var shData = null;
  if (USE_SKILLHUB) {
    shData = await fetchSkillHubData();
  }

  // ====== Phase 3: 用缓存的 repo 数据 + SkillHub 数据给每个 skill 打分 ======
  const results = [];
  let stats = { 'A+': 0, A: 0, 'B+': 0, B: 0, C: 0, D: 0, F: 0, fatal: 0 };
  
  let idx = 0;
  for (const skill of rawData) {
    try {
      // 查找对应的 repo 缓存数据
      let ghData = null;
      const repo = parseGitHubRepo(skill.install_url);
      if (repo && repoInfoCache.has(repo)) {
        ghData = repoInfoCache.get(repo);
      }
      
      // 查找 SkillHub 市场数据
      var marketResult = null;
      if (shData) {
        marketResult = scoreMarketPopularity(skill, shData);
      }
      
      const result = scanSkillWithGitHub(skill, ghData, marketResult);
      results.push(result);
      stats[result.quality_grade]++;
      if (result.safety_fatal) stats.fatal++;
    } catch (e) {
      results.push({ name: skill.name, quality_score: 0, quality_grade: 'ERR', error: e.message });
    }
    
    idx++;
    if (idx % 200 === 0) {
      console.log(`   📊 本地评分进度: ${idx}/${rawData.length} (${(idx/rawData.length*100).toFixed(0)}%)`);
    }
  }
  console.log(`   📊 Local scoring done: ${idx}/${idx} (100%)\n`);

  // ====== v2.3b: Z-score 标准化拉宽分布 ======
  const rawScores2 = results.filter(r => r.quality_grade !== 'ERR').map(r => r.quality_score);
  const zMean2 = rawScores2.reduce((a, b) => a + b, 0) / rawScores2.length;
  const zStd2 = Math.sqrt(rawScores2.reduce((s, v) => s + Math.pow(v - zMean2, 2), 0) / rawScores2.length);
  const TARGET_MEAN2 = 55;
  const TARGET_SD2 = 15;
  results.forEach(r => {
    if (r.quality_grade === 'ERR') return;
    const z = (r.quality_score - zMean2) / (zStd2 || 1);
    const normalized = Math.round(Math.max(20, Math.min(98, TARGET_MEAN2 + z * TARGET_SD2)));
    r.quality_score_raw = r.quality_score;
    r.quality_score = normalized;
    if (normalized >= 80) { r.quality_grade = 'A+'; r.quality_label = '卓越'; }
    else if (normalized >= 70) { r.quality_grade = 'A'; r.quality_label = '优秀'; }
    else if (normalized >= 55) { r.quality_grade = 'B+'; r.quality_label = '良好+'; }
    else if (normalized >= 45) { r.quality_grade = 'B'; r.quality_label = '良好'; }
    else if (normalized >= 35) { r.quality_grade = 'C'; r.quality_label = '及格'; }
    else if (normalized >= 20) { r.quality_grade = 'D'; r.quality_label = '较差'; }
    else { r.quality_grade = 'F'; r.quality_label = '不合格'; }
  });
  // 重新统计
  stats = { 'A+': 0, A: 0, 'B+': 0, B: 0, C: 0, D: 0, F: 0, fatal: 0 };
  results.forEach(r => {
    if (r.quality_grade !== 'ERR') stats[r.quality_grade]++;
    if (r.safety_fatal) stats.fatal++;
  });

  // Output stats
  var dimLabel = (USE_SKILLHUB && shData) ? '12-dim (GH+SkillHub)' : '11-dim (GitHub)';
  console.log('📊 Quality Distribution (' + dimLabel + '):');
  Object.entries(stats).forEach(([grade, count]) => {
    if (count > 0) console.log(`   ${grade}: ${count}个 (${(count/rawData.length*100).toFixed(1)}%)`);
  });
  if (stats.fatal > 0) console.log(`   ☠️  致命安全: ${stats.fatal}个`);
  console.log(`   GitHub API 调用次数: ${githubApiCount}`);
  console.log(`   Rate Limit 剩余: ${githubRateLimitRemaining}`);
  
  // 保存
  const outputPath = path.join(__dirname, 'data', 'quality_v2_scores.json');
  fs.writeFileSync(outputPath, JSON.stringify(results, null, 2), 'utf8');
  console.log(`\n💾 完整评分已保存到 ${outputPath}`);
  
  const scoreMap = {};
  for (const r of results) {
    if (r.quality_grade === 'ERR') continue;
    scoreMap[r.name] = {
      q: r.quality_score,
      g: r.quality_grade,
      d: r.dimensions,
      safe: r.safety_fatal,
      deps: r.details?.dep_count,
      maint: r.details?.maintenance_source,
      gh: r.github ? { stars: r.github.stars, updated: r.github.updated_at } : null,
    };
  }
  const mapPath = path.join(__dirname, 'data', 'quality_map.json');
  fs.writeFileSync(mapPath, JSON.stringify(scoreMap), 'utf8');
  console.log(`💾 质量映射已保存到 ${mapPath}`);
  
  return results;
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

/**
 * 计算日期距今多少天
 */
function daysSince(dateStr) {
  if (!dateStr) return 9999;
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return 9999;
  return Math.floor((Date.now() - d.getTime()) / (1000 * 60 * 60 * 24));
}

// ====== SkillHub API 工具函数 ======

const SKILLHUB_API = 'https://api.skillhub.cn/api/skills';

async function fetchSkillHubData() {
  if (skillhubData) return skillhubData;

  // 尝试先从本地缓存加载（如果之前已拉取过全量数据）
  var cachePath = path.join(__dirname, 'data', 'skillhub_full.json');
  if (fs.existsSync(cachePath)) {
    try {
      var cached = JSON.parse(fs.readFileSync(cachePath, 'utf8'));
      if (Array.isArray(cached) && cached.length > 100) {
        return buildSkillHubIndex(cached);
      }
    } catch(e) { /* fall through */ }
  }

  console.log('   SkillHub 全量分页拉取中...');
  return new Promise((resolve, reject) => {
    var allSkills = [];
    var page = 1;
    var pageSize = 100;

    function fetchPage() {
      var url = SKILLHUB_API + '?page=' + page + '&pageSize=' + pageSize;
      https.get(url, {
        headers: { 'User-Agent': 'SkillPick-Scanner/2.2', 'Accept': 'application/json' }
      }, (res) => {
        var data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          if (res.statusCode === 200) {
            try {
              var json = JSON.parse(data);
              var batch = json.data?.skills || [];
              allSkills = allSkills.concat(batch);
              
              process.stdout.write('\r   SkillHub: 已获取 ' + allSkills.length + ' 个...');

              if (batch.length >= pageSize && allSkills.length < 25000) {
                page++;
                setTimeout(fetchPage, 150); // 节流
              } else {
                // 拉取完毕，保存缓存并建索引
                console.log('\n   OK SkillHub: ' + allSkills.length + ' skills');
                try { fs.writeFileSync(cachePath, JSON.stringify(allSkills), 'utf8'); } catch(e2) {}
                resolve(buildSkillHubIndex(allSkills));
              }
            } catch(e) {
              console.log('\n   WARN Parse error at page ' + page + ': ' + e.message);
              resolve(buildSkillHubIndex(allSkills));
            }
          } else {
            console.log('   WARN HTTP status: ' + res.statusCode);
            resolve(buildSkillHubIndex(allSkills));
          }
        });
      }).on('error', function(e) {
        console.log('   WARN Connection error at page ' + page + ': ' + e.message);
        resolve(buildSkillHubIndex(allSkills));
      }).setTimeout(10000, function() {
        console.log('   WARN Timeout at page ' + page);
        resolve(buildSkillHubIndex(allSkills));
      });
    }

    fetchPage();
  });
}

function buildSkillHubIndex(skills) {
  var bySlug = new Map();
  var byName = new Map();
  var byDesc = new Map(); // 新增：按描述前30字符索引
  
  skills.forEach(function(s) {
    if (s.slug) bySlug.set(s.slug.toLowerCase().trim(), s);
    if (s.name) byName.set(s.name.toLowerCase().trim(), s);
    if (s.slug) byName.set(s.slug.toLowerCase().trim(), s);
    // 描述索引：取描述前40字符作为 key
    if (s.description && s.description.length >= 10) {
      byDesc.set(s.description.substring(0, 40).toLowerCase().replace(/\s+/g, ' ').trim(), s);
    }
  });
  
  var totalDl = 0;
  skills.forEach(function(x) { totalDl += (x.downloads || 0); });
  
  skillhubData = { 
    skills: skills, 
    bySlug: bySlug, 
    byName: byName,
    byDesc: byDesc,
    count: skills.length,
    fetchedAt: new Date().toISOString() 
  };
  
  return skillhubData;
}

function findSkillHubMatch(skillName, shData) {
  if (!shData || !shData.byName) return null;
  
  var key = skillName.toLowerCase().trim();
  var normalizedKey = key.replace(/[-_\s]+/g, ''); // 去掉分隔符
  
  // 1. 精确名称匹配
  if (shData.byName.has(key)) return { data: shData.byName.get(key), method: 'exact_name' };
  
  // 2. Slug 匹配
  if (shData.bySlug.has(key)) return { data: shData.bySlug.get(key), method: 'slug' };
  var slugKey = key.replace(/[^a-z0-9-]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
  if (shData.bySlug.has(slugKey)) return { data: shData.bySlug.get(slugKey), method: 'slug_norm' };

  // 3. 规范化匹配（去掉分隔符后比较）
  for (var pair of shData.byName) {
    var k = pair[0];
    if (k.replace(/[-_\s]+/g, '') === normalizedKey || 
        k.replace(/[-_\s]+/g, '').includes(normalizedKey) ||
        normalizedKey.includes(k.replace(/[-_\s]+/g, ''))) {
      return { data: pair[1], method: 'normalized' };
    }
  }
  
  // 4. 包含匹配（双向）
  var bestMatch = null;
  var bestOverlap = 0;
  for (var pair2 of shData.byName) {
    var k2 = pair2[0];
    if (k2.includes(key) || key.includes(k2)) {
      var overlap = Math.min(k2.length, key.length);
      if (overlap > bestOverlap) {
        bestOverlap = overlap;
        bestMatch = pair2[1];
      }
    }
  }
  if (bestMatch && bestOverlap >= 4) return { data: bestMatch, method: 'contains', overlap: bestOverlap };

  return null;
}

/**
 * 第12维: 市场热度评分 (SkillHub downloads/installs/score)
 */
function scoreMarketPopularity(skill, shData) {
  if (!shData || !shData.skills || shData.skills.length === 0) {
    return { score: 35, signals: ['no market data'], source: 'none' };
  }

  var match = findSkillHubMatch(skill.name, shData);
  if (!match) {
    return { score: 30, signals: ['not listed on SkillHub'], source: 'not_found' };
  }

  var m = match.data; // 新格式: { data: {...}, method: '...' }
  var score = 40; // base: listed
  var signals = [match.method]; // 记录匹配方式

  var dl = m.downloads || 0;
  if (dl >= 100000) { score += 30; signals.push('dl:' + (dl/10000).toFixed(1) + 'w'); }
  else if (dl >= 10000) { score += 22; signals.push('dl:' + (dl/1000).toFixed(1) + 'k'); }
  else if (dl >= 1000) { score += 14; signals.push('dl:' + dl); }
  else if (dl >= 100) { score += 6; signals.push('dl:' + dl); }
  else { signals.push('dl:' + dl); }

  var inst = m.installs || 0;
  if (inst >= 10000) { score += 18; signals.push('install:' + (inst/1000).toFixed(1) + 'k+'); }
  else if (inst >= 1000) { score += 10; signals.push('install:' + inst); }
  else if (inst >= 100) { score += 4; signals.push('install:' + inst); }

  var sc = m.score || m.community_score || 0;
  if (sc >= 50000) { score += 12; signals.push('community:' + Math.round(sc/1000) + 'k'); }
  else if (sc >= 5000) { score += 6; signals.push('community:' + Math.round(sc/1000) + 'k'); }
  else if (sc >= 500) { score += 2; signals.push('community:' + Math.round(sc)); }

  var stars = m.stars || 0;
  if (stars >= 50) { score += 5; signals.push('star:' + stars); }
  else if (stars >= 10) { score += 2; signals.push('star:' + stars); }

  if (m.updated_at) {
    var days = daysSince(m.updated_at);
    if (days <= 30) { score += 5; signals.push('recent update'); }
    else if (days <= 90) { score += 2; }
  }

  score = Math.max(0, Math.min(100, score));
  return {
    score: score,
    signals: signals,
    source: 'skillhub',
    raw: { downloads: dl, installs: inst, community_score: sc, sh_stars: stars, slug: m.slug, owner: m.ownerName },
  };
}

// ====== 单个详情报告 ======

function scanOne(name) {
  const ql = name.toLowerCase();
  const skill = rawData.find(s => s.name.toLowerCase() === ql) 
            || rawData.find(s => s.name.toLowerCase().includes(ql));
  if (!skill) {
    console.log(`❌ 未找到 skill: ${name}`);
    return null;
  }
  
  const r = scanSkillSync(skill);
  const d = r.dimensions;
  const det = r.details;
  
  console.log(`\n${'='.repeat(56)}`);
  console.log(`📋 ${r.name} — 13维深度质量扫描`);
  console.log(`${'='.repeat(56)}`);
  console.log(`   综合分: ${r.quality_score}/100 [${r.quality_grade}] ${r.quality_label}\n`);
  
  console.log(`   ┌──────────────────────────────────────────────┐`);
  console.log(`   │ 📝 描述质量:     ${bar(d.description)} ${d.description}/100 │`);
  console.log(`   │ 🏷️ 标签丰富度:   ${bar(d.tags)} ${d.tags}/100 │`);
  console.log(`   │ 📦 安装便捷度:   ${bar(d.install)} ${d.install}/100 │`);
  console.log(`   │ 🛡️ 安全信号:     ${bar(d.safety)} ${d.safety}/100 │`);
  console.log(`   │ 🔗 依赖复杂度:   ${bar(d.dependency)} ${d.dependency}/100 │`);
  console.log(`   │ 📄 文档结构:     ${bar(d.doc_structure)} ${d.doc_structure}/100 │`);
  console.log(`   │ ⚠️ 错误处理:     ${bar(d.error_handling)} ${d.error_handling}/100 │`);
  console.log(`   │ 🔄 维护活跃度:   ${bar(d.maintenance)} ${d.maintenance}/100 │`);
  console.log(`   │ 🧪 测试覆盖:     ${bar(d.tests)} ${d.tests}/100 │`);
  if (d.market !== null) {
  console.log(`   │ 📈 市场热度:     ${bar(d.market)} ${d.market}/100 │`);
  }
  if (d.market_validation !== null) {
  console.log(`   │ 🏅 市场验证:     ${bar(d.market_validation)} ${d.market_validation}/100 │`);
  }
  console.log(`   └──────────────────────────────────────────────┘`);
  
  // 依赖详情
  if (det.dependencies && det.dependencies.length > 0) {
    console.log(`\n   🔗 依赖 (${det.dep_count}个):`);
    det.dependencies.forEach(dep => console.log(`      ${dep}`));
  }
  
  // 文档信号
  if (det.doc_signals && det.doc_signals.length > 0) {
    console.log(`\n   📄 文档结构:`);
    det.doc_signals.forEach(s => console.log(`      ✅ ${s}`));
  }
  
  // 错误处理信号
  if (det.error_signals && det.error_signals.length > 0) {
    console.log(`\n   ⚠️ 错误处理:`);
    det.error_signals.forEach(s => console.log(`      ✅ ${s}`));
  } else {
    console.log(`\n   ⚠️ 错误处理: 未发现任何错误处理说明`);
  }
  
  // 维护状态
  if (det.maintenance_signals && det.maintenance_signals.length > 0) {
    console.log(`\n   🔄 维护状态 [${det.maintenance_source}]:`);
    det.maintenance_signals.forEach(s => console.log(`      ${s}`));
  }
  
  // 测试信息
  const ti = det.test_info || {};
  if (ti.has_tests) {
    console.log(`\n   🧪 测试覆盖 [${ti.source}]: ✅ 发现测试`);
    ti.signals?.forEach(s => console.log(`      ${s}`));
  } else {
    console.log(`\n   🧪 测试覆盖 [${ti.source || '?'}]: ❌ ${ti.signals?.join(', ') || '无测试证据'}`);
  }
  
  // 市场验证信息
  const mvi = det.market_validation_info || null;
  if (mvi) {
    console.log(`\n   🏅 市场验证 [${mvi.source}]: ${mvi.score}/100`);
    if (mvi.signals && mvi.signals.length > 0) {
      mvi.signals.forEach(s => console.log(`      ${s}`));
    }
  }
  
  // 问题列表
  if (r.issues.length > 0) {
    console.log(`\n   ⚠️ 问题清单:`);
    r.issues.forEach(i => console.log(`      • ${i}`));
  }
  
  console.log(`\n   来源: ${skill.source} | 安装: ${skill.install_method || '无'} | 赛道: ${skill.cat || '未分类'} | 星级: ${skill.stars || '?'}`);
  if (skill.install_url) console.log(`   链接: ${skill.install_url}`);
  if (skill.desc) console.log(`   描述: ${skill.desc.substring(0, 150)}${skill.desc.length > 150 ? '...' : ''}`);
  
  return r;
}

function bar(score, max = 100) {
  const len = Math.round(score / max * 14);
  const filled = '█'.repeat(len);
  const empty = '░'.repeat(14 - len);
  return `${filled}${empty}`;
}

// ====== Top/Bottom ======

function showTop(n = 10) {
  const all = rawData.map(s => scanSkillSync(s));
  all.sort((a, b) => b.quality_score - a.quality_score);
  
  console.log(`\n🏆 11维质量 TOP${n}\n`);
  all.slice(0, n).forEach((r, i) => {
    const mark = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : ` ${i + 1}`;
    const src = r._skill?.source || '?';
    const deps = r.details?.dep_count || 0;
    console.log(`${mark} ${r.name} (${r.quality_score}[${r.quality_grade}]) · ${r.quality_label} · deps:${deps} · ${src}`);
  });
}

function showBottom(n = 10) {
  const all = rawData.map(s => scanSkillSync(s));
  all.sort((a, b) => a.quality_score - b.quality_score);
  
  console.log(`\n💀 11维质量 BOTTOM${n}\n`);
  all.slice(0, n).forEach((r, i) => {
    const issues = r.issues.slice(0, 3).join(' | ');
    const safeMark = r.safety_fatal ? '☠️' : '❌';
    console.log(`${i + 1}. ${safeMark} ${r.name} (${r.quality_score}[${r.quality_grade}]) · ${issues}`);
  });
}

// ====== 维度专项报告 ======

function showDimensionReport() {
  const all = rawData.map(s => scanSkillSync(s));
  
  console.log('\n' + '='.repeat(60));
  console.log('📊 11维专项诊断报告');
  console.log('='.repeat(60));
  
  const dims = [
    { key: 'description', label: '📝 描述质量', threshold: 30 },
    { key: 'tags', label: '🏷️ 标签丰富度', threshold: 20 },
    { key: 'install', label: '📦 安装便捷度', threshold: 30 },
    { key: 'safety', label: '🛡️ 安全信号', threshold: 40, reverse: true },
    { key: 'dependency', label: '🔗 依赖复杂度', threshold: 30 },
    { key: 'doc_structure', label: '📄 文档结构', threshold: 25 },
    { key: 'error_handling', label: '⚠️ 错误处理', threshold: 20 },
    { key: 'maintenance', label: '🔄 维护活跃度', threshold: 30 },
    { key: 'tests', label: '🧪 测试覆盖', threshold: 15 },
  ];
  
  for (const dim of dims) {
    // 找出最差的 5 个
    const sorted = [...all].sort((a, b) => a.dimensions[dim.key] - b.dimensions[dim.key]);
    const worst = sorted.slice(0, 5);
    const avg = (all.reduce((s, r) => s + r.dimensions[dim.key], 0) / all.length).toFixed(1);
    const belowThreshold = all.filter(r => r.dimensions[dim.key] < dim.threshold).length;
    
    console.log(`\n--- ${dim.label} (均值=${avg}, 低于阈值${dim.threshold}: ${belowThreshold}/${all.length}) ---`);
    worst.forEach((r, i) => {
      const val = r.dimensions[dim.key];
      const barStr = bar(val);
      const extra = dim.key === 'dependency' ? `[deps:${r.details?.dep_count}]` : '';
      console.log(`  ${i + 1}. ${r.name}: ${val}/100 ${barStr} ${extra}`);
    });
  }
  
  // 安全致命汇总
  const fatals = all.filter(r => r.safety_fatal);
  if (fatals.length > 0) {
    console.log('\n--- ☠️ 致命安全汇总 ---');
    fatals.forEach(r => {
      console.log(`  💀 ${r.name} — ${r.issues.find(i => i.includes('致命')) || '致命安全问题'}`);
    });
  }
  
  // 高依赖汇总
  const heavyDep = all.filter(r => (r.details?.dep_count || 0) >= 3);
  if (heavyDep.length > 0) {
    console.log(`\n--- 🔗 重依赖汇总(>=3个依赖): ${heavyDep.length}个 ---`);
    heavyDep.sort((a, b) => (b.details?.dep_count || 0) - (a.details?.dep_count || 0));
    heavyDep.slice(0, 10).forEach(r => {
      console.log(`  ${r.name}: ${r.details?.dep_count}个依赖 → ${r.details?.dependencies?.join(', ')}`);
    });
  }
}

// ====== 主入口 ======

const args = process.argv.slice(2);
const cmd = args.find(a => !a.startsWith('--') && a !== '-g') || 'all';
const numArg = args.find(a => /^\d+$/.test(a));

(async () => {
  switch (cmd) {
    case 'all':
    case 'scan':
      if (USE_GITHUB) await scanAllAsync();
      else scanAllSync();
      break;
      
    case 'one':
    case 'detail':
      scanOne(args[args.indexOf(cmd) + 1]);
      break;
      
    case 'top':
      showTop(parseInt(numArg) || 10);
      break;
      
    case 'bottom':
      showBottom(parseInt(numArg) || 10);
      break;
      
    case '--report':
    case 'report':
      scanAllSync();
      showDimensionReport();
      break;
      
    case 'help':
    case '-h':
    case '--help':
      console.log(`
🔍 SkillPick Quality Scanner v2.3 — 13维深度扫描引擎

用法:
  node scanner.js                    全量扫描（纯元数据模式，<1秒完成）
  node scanner.js --github            全量扫描 + GitHub API 增强（需 GITHUB_TOKEN）
  node scanner.js --skillhub          全量扫描 + SkillHub 市场热度（12维完整版）
  node scanner.js --github --skillhub 全量扫描 + 双增强（13维完整版）
  node scanner.js one <名称>          单个 skill 13维详细报告
  node scanner.js top [N]             Top N 排行
  node scanner.js bottom [N]          Bottom N 排行
  node scanner.js --report            扫描 + 9维度专项诊断报告

13维评分体系（v2.3 结构性修正）:

  层1-元数据推断（无需外部请求）:
    📝 描述质量    12%  — 长度、专业信号、精炼度奖励（v2.3）
    🏷️ 标签丰富度   7%  — 数量、非通用词比例、可信来源兜底（v2.3）
    📦 安装便捷度   8%  — search减罚+可信来源加分（v2.3）
    🛡️ 安全信号    14%  — 远程脚本(一票否决)、密钥依赖、破坏性命令
    🔗 依赖复杂度   8%  — Docker/GPU/数据库/API Key/登录/Browser
    📄 文档结构     7%  — Use when/NOT for、示例、FAQ、highlight质量
    ⚠️ 错误处理     5%  — 边界声明、失败处理、降级、超时、权限
    🏅 市场验证     8%  — 星级、榜单、来源可信度（v2.3新增）

  层2-GitHub API（需 --github + GITHUB_TOKEN）:
    🔄 维护活跃度  10%  — last_push、commit频率、archived、stars/issues
    🧪 测试覆盖     5%  — ***/test/__tests__/ 文件存在性检测

  层3-SkillHub 市场数据（需 --skillhub，可选）:
    📈 市场热度     7%  — downloads/installs/community_score

等级划分: A+≥80卓越 | A≥70优秀 | B+≥55良好+ | B≥45良好 | C≥35及格 | D≥20较差 | F<20不合格

GitHub Token 设置:
  PowerShell: $env:GITHUB_TOKEN="ghp_xxxxxxxxx"
  Linux/Mac:   export GITHUB_TOKEN="ghp_xxxxxxxxx"
`);
      break;
      
    default:
      // 如果输入的不是命令，当作 search 处理
      if (cmd && !cmd.startsWith('-')) {
        console.log(`❌ 未知命令: ${cmd}`);
        console.log('   运行 "node scanner.js help" 查看帮助');
      } else {
        if (USE_GITHUB) await scanAllAsync();
        else scanAllSync();
      }
  }
})();
