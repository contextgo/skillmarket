# SkillPick — 什么Skill值得装

> 一句话：不是搜索、不是排行，是帮你**判断**哪个值得装。
> 版本：v6.1.0 | 更新：2026-04-19

## 跟竞品有什么不同？

| 工具 | 做什么 | 一句话 |
|------|--------|--------|
| find-skills | 搜索查找 | "你要什么？我帮你找到安装方式" |
| skillhub 排行榜 | 跟风装 | "大家装什么？你照着装" |
| **SkillPick** | 判断推荐 | **"哪些最好？我帮你分析推荐"** |

就像「什么值得买」不搜商品也不排销量，它做的是消费决策。

## 双受众

- **人类** → 打开页面看赛道精选，一眼就知道每个赛道该装什么
- **Agent** → 通过 CLI 调用 search / similar / workflow，获取精确推荐结果

## 四大功能

| 功能 | 给谁用 | 干嘛 |
|------|--------|------|
| 🏆 赛道 TOP3 | 人类 | 每个赛道 Top3，带评分/星级/榜单认证/置信度/质量等级 |
| 🔍 搜索推荐 | Agent | 输入关键词，返回 1-3 条推荐 + 结论 |
| 🔄 相似替代 | Agent | 给个 skill 名，返回 1-3 个替代 + 差异分析 |
| 🧩 工作流组合 | Agent | 选场景，每个角色推荐 1 个最优 skill |

## Agent CLI 接口（核心）

```bash
node api.js <命令> [参数]
```

### 六个命令

```bash
node api.js top3              # 全部赛道 TOP3
node api.js top3 "AI Agent"   # 指定赛道
node api.js search PDF        # 搜索推荐
node api.js similar pdf       # 替代选择
node api.js workflow 短视频   # 工作流推荐
node api.js detail docx       # 技能详情（含13维雷达）
node api.js quality           # 全局质量报告
```

别名速查：top3=categories/tracks, search=find/s, similar=alt, workflow=combo/wf, detail=info/d, quality=report/q

## 数据体系

- 954 条 skill / 45+ 赛道 / 7 个数据源
- **13维Z-score质量评分** + 三层门控（pass/warn/block）
- 三源榜单交叉验证 + GitHub API + SkillHub 全量25K
- 全部数据预计算，前端零延迟

## 文件说明

| 文件 | 用途 |
|------|------|
| `index.html` | 前端页面（四大 Tab + 13维 Modal，单文件无依赖） |
| `skills_data.js` | 全量 skill 数据（前端 + CLI 共用） |
| `api.js` | Agent CLI 接口（6 个命令） |
| `scanner.js` | 13维质量扫描引擎 |
| `data/quality_v2_scores.json` | 13维评分结果 |
| `data/workflows.json` | 工作流定义 |
| `SKILL.md` | 元数据入口（SkillHub 集成） |

## 版本历史

- **v6.1.0** (2026-04-19): 纯净版发布——移除行为信号体系，统一版本号，清理残留，13维Z-score质量评分为核心引擎
- **v6.0.1** (2026-04-18): 文档质量升级——清除乱码/英文残留/重复内容，统一纯中文风格
- **v6.0.0** (2026-04-17): 安全清理 + 无关文件清除 + 新增 CLI 接口
- **v5.1.0** (2026-04-17): TOP3 回退平铺列表 + 排序优化 + bug 修复
