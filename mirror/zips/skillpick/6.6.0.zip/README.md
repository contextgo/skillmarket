<div align="center">

# SkillPick

[![Version](https://img.shields.io/badge/version-v6.5.0-blue.svg)](https://github.com/huangjihua007-rgb/skillpick/releases)
[![License: MIT](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![Platform](https://img.shields.io/badge/platform-Windows%20%7C%20macOS%20%7C%20Linux-lightgrey.svg)]()
[![Skills](https://img.shields.io/badge/skills-29%2C000%2B-orange.svg)]()

**AI Skill Recommendation Engine -- not search, not ranking, but helping you decide which one is worth installing.**

AI Skill 推荐引擎 -- 不是搜索、不是排行，是帮你判断哪个值得装。

</div>

---

## Install

```bash
# npx (recommended)
npx skills add huangjihua007-rgb/skillpick

# ClawHub
clawhub install skillpick

# SkillHub
skillhub install skillpick
```

---

## What It Does

- **Track TOP3** -- 58 categories, each with the top 3 picks scored by both popularity and quality
- **Smart Search** -- keyword in, structured recommendation out (with reasoning)
- **Similar Alternatives** -- give a skill name, get comparable options with diff analysis
- **Workflow Combos** -- 8 predefined scenarios, best skill for each role
- **13-Dim Quality Scoring** -- Z-score normalized, safety veto, three-layer gating (pass / warn / block)
- **Dual Audience** -- humans browse TOP3 visually; agents call CLI for structured JSON

---

## Usage

```bash
skillpick top3                  # All 58 tracks, TOP3 per track
skillpick top3 "AI Agent"       # Single track
skillpick search PDF            # Search with recommendation + reasoning
skillpick similar pdf           # Find alternatives + diff analysis
skillpick workflow video         # Workflow scenario recommendation
skillpick detail coding-agent   # Full 13-dimension quality breakdown
skillpick quality               # Global quality distribution report
```

Example output:

```
$ skillpick search PDF

  [Search] "PDF" -- 3 results

  #1  pdf-reader           A+  (score: 92)
      Full-text extraction with table recognition. Production-ready.
      -> npx skills add pdf-reader

  #2  pdf-toolkit          A   (score: 78)
      Lightweight PDF ops: merge, split, watermark.
      -> npx skills add pdf-toolkit

  #3  doc-converter        B+  (score: 65)
      Multi-format conversion including PDF output.
      -> npx skills add doc-converter

  Verdict: pdf-reader is the top pick for PDF workflows.
```

Human output is readable; Agent output is structured JSON. Same commands, dual-mode.

---

## Data at a Glance

| Metric | Value |
|--------|-------|
| Total Skills | 29,000+ |
| Curated Tracks | 58 |
| Top Picks (A+/A grade) | 3,000 |
| Quality Dimensions | 13 |
| Data Sources | SkillHub + GitHub + Manual |
| Frontend Latency | 0ms (pre-computed) |

---

## How Scoring Works

```
final_score = textMatchScore x qualityMultiplier
```

- **A+ / A grade** -- boosted, shown first
- **B+ / B grade** -- neutral
- **C grade** -- penalized 30%
- **D / F grade** -- excluded entirely (safety veto)

The 13 dimensions cover: description quality, tags, install ease, safety signals, dependency complexity, doc structure, error handling, market validation, maintenance activity, test coverage, and market popularity.

---

## Compared To

| Tool | What it does | One line |
|------|--------------|----------|
| find-skills | Search | "What do you want? I'll find it." |
| SkillHub Leaderboard | Ranking | "What's popular? Install that." |
| **SkillPick** | **Recommendation** | **"What's best? I'll analyze and tell you."** |

---

## Links

- GitHub: [github.com/huangjihua007-rgb/skillpick](https://github.com/huangjihua007-rgb/skillpick)
- SkillHub: [skillhub.com/skillpick](https://skillhub.com/skill/skillpick)
- ClawHub: [clawhub.com/skillpick](https://clawhub.com/skill/skillpick)

---

## License

MIT
