# thesis-tutor

论文写作全流程AI导师 — 从选题到答辩的七阶段辅导系统

## 核心定位

**不是代写，是导师。**

解决学生"不知道该怎么开始""不知道写得对不对"的痛点，分阶段带学生走完论文全流程。

## 七阶段流程

1. **选题诊断** — 帮你找到能写下去的题目
2. **开题报告** — 生成结构化开题文档
3. **大纲构建** — 多级学术大纲+写作指引
4. **逐章辅导** — 像导师批注一样给修改建议（含导师反馈处理）
5. **自检清单** — 提交前四维检查
6. **导出docx** — 符合模板的Word文档
7. **答辩准备** — 自述稿+PPT框架+高频问题预判

## 专项模块

- 📊 **量化研究全程指南** — 问卷设计→预测试→SPSS分析→中介效应
- 📋 **质性研究专项** — 访谈法/案例研究/扎根理论/主题分析法
- 🔍 **查重与AI检测指南** — 降重方法/AI率控制/超标处理
- 🛠️ **论文写作工具链** — 文献管理/数据分析工具/时间规划
- 📚 **文献综述专项** — 分类框架/述评写法/研究缺口

## 快速开始

### 命令行工具

```bash
# 选题诊断
python scripts/thesis_tutor.py --stage topic --major "计算机" --level bachelor

# 生成大纲
python scripts/thesis_tutor.py --stage outline --title "XXX研究" --discipline cs

# 逐章辅导
python scripts/thesis_tutor.py --stage chapter --file my_chapter.txt

# 自检清单
python scripts/thesis_tutor.py --stage check

# 导出Word
python scripts/export_docx.py --title "论文标题" --author "作者" --level bachelor

# 量化研究指南
python scripts/thesis_tutor.py --stage quantitative --level master

# 质性研究指南
python scripts/thesis_tutor.py --stage qualitative --level bachelor

# 答辩准备
python scripts/thesis_tutor.py --stage defense --level master
```

### 对话使用

直接描述你的论文困境：
- "我是计算机专业的，不知道写什么题目"
- "题目定了，帮我搭个大纲"
- "写了绪论，你帮我看看"
- "导师说论证不够，怎么改"
- "快交了，帮我检查一下"
- "答辩PPT怎么做"

## 文件结构

```
thesis-tutor/
├── SKILL.md                        # 核心技能文档（v3.4）
├── README.md                       # 本文件
├── test-prompts.json               # 测试用例
├── scorecard.json                  # 评分卡
├── test-runner.md                  # 测试指南
├── references/                     # 参考资料
│   ├── topic-selection.md          # 选题评估框架
│   ├── outline-templates.md        # 各学科大纲模板
│   ├── writing-guide.md            # 逐章写作指引
│   ├── checklist.md                # 自检清单
│   ├── literature-review.md        # 文献综述四步法
│   ├── quantitative-research.md    # 量化研究全程指南（问卷法）
│   ├── qualitative-research.md     # 质性研究全程指南（访谈/案例/扎根）
│   ├── plagiarism-guide.md         # 查重与AI检测指南
│   ├── toolchain-guide.md          # 论文写作工具链
│   └── source-map.md               # 来源地图
├── scripts/                        # 工具脚本
│   ├── thesis_tutor.py             # 核心引擎（12个stage）
│   ├── export_docx.py              # 文档导出
│   ├── run_tests.py                # 自动化测试（12项）
│   └── quick_validate.py           # 快速验证
└── assets/                         # 资源文件
    └── (学校模板可放这里)
```

## 支持的学科

- 计算机/电子/机械（理工类）
- 管理/营销/金融（经管类）
- 文学/传媒（文科类）
- 教育/心理（教育类）
- 法学（法学类）
- 艺术/设计（艺术类）
- 生物/医学（理工类）

## 设计原则

1. **引导而非代写** — 启发学生思考，不直接给答案
2. **结构化输出** — 每阶段都有清晰框架
3. **学科适配** — 不同学科有不同的结构模板
4. **阶段推进** — 每阶段结束主动提示下一步
5. **学术规范** — 符合 GB/T 7714 等国家标准
6. **模式自动识别** — 学生贴文本走批注，说"不知道写"走框架引导

## 评分维度

| 维度 | 权重 | 说明 |
|------|------|------|
| 论文专业度 | 30% | 学术规范掌握程度 |
| 引导力 | 25% | 能否引导学生找到方向 |
| 结构化 | 20% | 输出是否有清晰框架 |
| 交互性 | 15% | 是否让学生参与决策 |
| 实用性 | 10% | 建议是否可落地 |

## 版本

- v1.0 (2026-04-19) — 初始完整版本，七阶段核心流程
- v2.0 (2026-04-19) — 新增答辩准备、文献综述专项、导师反馈处理
- v3.0 (2026-04-20) — 新增量化研究/查重/工具链专项；升级段落分析引擎
- v3.1 (2026-04-20) — 新增质性研究专项；修复阶段④表格格式；补全阶段⑥对话引导
- v3.4 (2026-04-21) — 新增八学科专属大纲模板；教育/医学/法学深度模板；阶段⑥完整 docx skill 调用说明；对话式答辩模拟；跨学科路径提示；92项测试用例，100%通过率；全面优化修复

## 测试

运行 `python scripts/run_tests.py` 进行自动化测试。完整测试报告见 `test-report-v3.4-comprehensive.json`。

测试覆盖：4个学科方向（计算机/商科/教育/法学）× 7个核心阶段 + 5个专项模块 + 边界测试（表达规范/底线拒绝）

## 来源

学术规范参考 GB/T 7714-2015 及各高校学位论文要求

## License

MIT
