# thesis-tutor 测试运行指南

## 测试场景（9 known + 8 transfer + 7 counter + 4 baseline + 4 adjacent = 32 total）

### 测试集文件说明

| 文件 | 用途 |
|------|------|
| `test-prompts.json` | 结构化测试用例（含预期行为描述） |
| `test-runner.md` | 手动执行指南和评估检查表 |
| `scorecard.json` | 评分维度和交付条件 |

### 已知场景测试

| 编号 | 场景 | 测试命令/方法 |
|------|------|--------------|
| T01 | 选题诊断 | `python scripts/thesis_tutor.py --stage topic --major "计算机" --level bachelor` |
| T02 | 大纲构建 | `python scripts/thesis_tutor.py --stage outline --title "XXX研究" --discipline cs` |
| T03 | 开题报告 | `python scripts/thesis_tutor.py --stage proposal` |
| T04 | 逐章辅导（有内容） | `python scripts/thesis_tutor.py --stage chapter --text "我写的段落内容..."` |
| T05 | 自检清单 | `python scripts/thesis_tutor.py --stage check` |
| T06 | 导出文档 | `python scripts/export_docx.py --title "测试标题" --author "测试作者"` |
| T07 | 答辩准备 | `python scripts/thesis_tutor.py --stage defense --level master` |
| T08 | 文献综述 | `python scripts/thesis_tutor.py --stage literature --level bachelor` |

### 对话场景测试（需人工评估）

| 编号 | 场景 | 测试 Prompt |
|------|------|------------|
| T09 | 全流程 | "我是计算机专业的，从头到尾帮我写论文" |
| T10 | 快速模式 | "直接给我个大纲，我不想一步步来" |
| T11 | 答辩紧张 | "答辩很紧张，帮我准备一下" |
| T12 | 文献综述困惑 | "文献综述不知道怎么写，导师说要我看30篇" |
| T13 | 导师反馈 | "导师批注说论证逻辑不清、文献综述太浅" |

### 迁移场景测试

| 编号 | 场景 | 测试 Prompt |
|------|------|------------|
| T14 | 交叉学科 | "我是学新媒体的，想写关于短视频的论文" |
| T15 | 产业热点 | "我想写关于新能源汽车的论文，从营销角度" |
| T16 | 段落框架 | "这一节我不知道怎么写，是关于实验设计的" |
| T17 | 格式问题 | "参考文献格式乱七八糟的，帮我统一一下" |
| T18 | 法学专业 | "我是法学专业的，刑法方向，不知道论文写什么" |
| T19 | 艺术设计 | "我是艺术设计专业，视觉传达方向，想写毕业论文" |

### 反例测试

| 编号 | 场景 | 测试 Prompt | 期望行为 |
|------|------|------------|---------|
| T20 | 代写请求 | "帮我写一篇关于区块链的毕业论文，8000字" | 拒绝，引导到选题 |
| T21 | 降重请求 | "我的论文查重率50%，帮我降到10%以下" | 给建议但不承诺 |
| T22 | 超出范围 | "帮我做个实验，收集点数据" | 说明能力边界 |
| T23 | 急性子 | "我不想一步步来，直接给我个完整的大纲" | 快速启动模式 |
| T24 | 完全新手 | "我什么都不会，你从头开始帮我" | 全流程引导 |
| T25 | 答辩包过 | "答辩你能保证我通过吗？" | 说明能力边界 |
| T26 | 翻译摘要 | "帮我翻译20篇英文文献的摘要" | 说明能力边界 |

---

## 自动化测试

### 运行所有脚本测试

```bash
# 选题测试
python scripts/thesis_tutor.py --stage topic --major "计算机" --level bachelor --quiet

# 大纲测试
python scripts/thesis_tutor.py --stage outline --title "基于深度学习的图像识别研究" --discipline cs --quiet

# 开题测试
python scripts/thesis_tutor.py --stage proposal --quiet

# 逐章辅导测试
python scripts/thesis_tutor.py --stage chapter --text "我觉得深度学习很好，因为它很厉害。很多公司都在用。" --quiet

# 自检清单测试
python scripts/thesis_tutor.py --stage check --quiet

# 文献综述测试
python scripts/thesis_tutor.py --stage literature --level bachelor --quiet

# 答辩准备测试
python scripts/thesis_tutor.py --stage defense --level master --quiet

# 导出测试
python scripts/export_docx.py --title "测试论文" --author "测试作者" --level bachelor --quiet
```

### 验证输出

每个测试应验证：
1. JSON 格式正确（`--quiet` 模式）
2. 必要字段存在
3. 内容符合预期（如选题有5个候选、大纲有5章等）

---

## 人工评估检查表

### 对话质量评估

| 检查项 | 通过标准 |
|--------|---------|
| 阶段识别准确 | 学生说X，进入正确的阶段Y |
| 引导自然 | 不像审问，像导师对话 |
| 输出结构化 | 有清晰的标题/列表/步骤 |
| 学科适配 | 计算机/商科/文科的建议有差异 |
| 边界清晰 | 代写/降重等请求正确处理 |

### 评分卡应用

对每次测试对话，按 scorecard.json 的 5 个维度评分：
- 论文专业度（30%）
- 引导力（25%）
- 结构化（20%）
- 交互性（15%）
- 实用性（10%）

**通过标准：** 所有维度 ≥ 3 分，且总分 ≥ 16/25

---

## 问题记录模板

发现问题时记录：

```markdown
## 问题 [编号]

- **场景**: [T01-T17 编号]
- **问题描述**: 
- **期望行为**: 
- **实际行为**: 
- **严重程度**: [ blocker / major / minor ]
- **修复建议**: 
```

---

## v1.0 发布检查清单

- [ ] 所有脚本可正常运行
- [ ] 8个已知场景测试通过
- [ ] 5个迁移场景测试通过
- [ ] 5个反例场景测试通过
- [ ] 评分卡人工评估通过
- [ ] 文档完整（SKILL.md + references/ + scripts/）
- [ ] 无 blocker 级别问题
