# CLI 命令参考（v3.1）

> 本文件是 SKILL.md 中 CLI 参数表的完整展开，供调试、自动化、集成使用。
> 所有 JSON 字段名以 `scripts/thesis_tutor.py` v3.1 引擎实际输出为准。

---

## thesis_tutor.py — 论文导师引擎

**路径**：`scripts/thesis_tutor.py`

### 全局参数

| 参数 | 短参数 | 必填 | 说明 |
|------|--------|------|------|
| `--stage` | `-s` | ✅ | 阶段名称（见下方 Stage 详解） |
| `--major` | `-m` | 部分 | 专业名称，如"计算机"、"法学" |
| `--title` | `-t` | 部分 | 论文题目 |
| `--level` | `-l` | 推荐 | 学位级别：`bachelor` / `master` / `phd`，默认 bachelor |
| `--discipline` | `-d` | 可选 | 学科代码：`cs` / `ee` / `mech` / `bio` / `biz` / `econ` / `law` / `lit` / `media` / `edu` / `psy` / `art` |
| `--text` | `-x` | 部分 | 逐章辅导：要批注的段落文本 |
| `--file` | `-f` | 部分 | 逐章辅导：要批注的文件路径（优先于 `--text`） |
| `--quick` | `-q` | 可选 | 快速模式（选题只出3个） |
| `--output` | `-o` | 可选 | 结果输出到文件（JSON 格式） |
| `--quiet` | — | 可选 | 安静模式，只输出 JSON |

### 退出码

| 退出码 | 含义 |
|--------|------|
| `0` | 执行成功（`success=true`） |
| `1` | 参数错误或必填参数缺失（`success=false`） |

---

### Stage 详解

#### `topic` — 选题诊断

```bash
python scripts/thesis_tutor.py --stage topic --major "计算机" --level bachelor --quiet
```

**必填**：`--major` | **可选**：`--level` / `--quick`

**JSON 输出**：

```json
{
  "success": true,
  "stage": "topic",
  "major": "计算机",
  "level": "bachelor",
  "topics": [
    {
      "id": "topic_1",
      "template": "基于{技术}的{场景}{任务}研究",
      "example": "基于大模型的代码生成质量评估研究",
      "difficulty": "中",
      "innovation": "高",
      "resource": "高",
      "reason": "基于计算机的常见研究范式，适合bachelor水平"
    }
  ],
  "next_step": "选择感兴趣的题目，进入开题报告阶段"
}
```

**错误**（未传 `--major`）：`{"success": false, "error": "选题阶段需要指定专业方向 (--major)"}`

---

#### `proposal` — 开题报告

```bash
python scripts/thesis_tutor.py --stage proposal --quiet
```

无需额外参数。

**JSON 输出**：

```json
{
  "success": true,
  "stage": "proposal",
  "sections": [
    {"title": "研究背景与意义", "content": "...", "tips": "..."},
    {"title": "国内外研究现状", "content": "...", "tips": "..."}
  ],
  "next_step": "完成开题报告后，可以细化成完整大纲"
}
```

---

#### `outline` — 大纲构建

```bash
python scripts/thesis_tutor.py --stage outline --title "基于深度学习的图像识别研究" --discipline cs --quiet
```

**必填**：`--title` | **可选**：`--discipline`

**JSON 输出**：

```json
{
  "success": true,
  "stage": "outline",
  "title": "基于深度学习的图像识别研究",
  "outline": {
    "title": "基于深度学习的图像识别研究",
    "discipline": "理工",
    "level": "bachelor",
    "chapters": [
      {
        "chapter": "1 绪论",
        "sections": ["研究背景与意义", "国内外研究现状", "研究内容与论文结构"],
        "words": "2000-3000",
        "guidance": "本章应围绕研究背景与意义展开..."
      }
    ],
    "total_words": "13000-19500"
  },
  "next_step": "确认大纲结构后，可以逐章开始写作"
}
```

---

#### `chapter` — 逐章辅导（v3.0+ 段落分析引擎）

```bash
python scripts/thesis_tutor.py --stage chapter --text "我觉得深度学习很好，因为它很厉害。" --quiet
```

**必填**：`--text` 或 `--file`

**JSON 输出**：

```json
{
  "success": true,
  "stage": "chapter",
  "total_paragraphs": 1,
  "paragraphs_analyzed": [
    {
      "index": 1,
      "text_preview": "我觉得深度学习很好，因为它很厉害。",
      "issues": [
        {
          "type": "expression",
          "severity": "warn",
          "marker": "我觉得",
          "issue": "发现口语化表达「我觉得」",
          "suggestion": "建议改为：'本文认为' 或 '研究表明' 或 '数据显示'",
          "academy_example": "学术表达示例：'本文认为、研究表明'"
        }
      ]
    }
  ],
  "summary": {"expression": 1, "logic": 0, "concept": 0, "argument": 0, "structure": 0},
  "overall_score": 10,
  "overall_grade": "优秀 — 无明显问题，可进入下一阶段",
  "top_issues": [],
  "suggestions": ["全局口语化：全文1处口语化表达需改为学术表达"],
  "next_step": "按批注修改后继续下一章，或进入自检阶段"
}
```

**错误**（未传文本）：`{"success": false, "error": "逐章辅导需要提供文本内容 (--text 或 --file)"}`

---

#### `check` — 自检清单

```bash
python scripts/thesis_tutor.py --stage check --quiet
```

无需参数。

**JSON 输出**：

```json
{
  "success": true,
  "stage": "check",
  "checks": [
    {"category": "format", "name": "格式检查", "items": ["标题层级格式统一", ...]},
    {"category": "citation", "name": "引用检查", "items": [...]},
    {"category": "logic", "name": "逻辑检查", "items": [...]},
    {"category": "common", "name": "常见硬伤", "items": [...]}
  ],
  "total_items": 20,
  "next_step": "逐项检查完成后，可以导出最终文档"
}
```

---

#### `defense` — 答辩准备

```bash
python scripts/thesis_tutor.py --stage defense --level master --quiet
```

**可选**：`--level`

**JSON 输出**：

```json
{
  "success": true,
  "stage": "defense",
  "ppt_framework": [
    {"page": 1, "title": "封面", "time": "0:00", "content": "题目+姓名+导师+学校"}
  ],
  "total_minutes": "10-15分钟",
  "self_intro_template": {
    "opening": "各位老师好，我是XXX...",
    "background": "...",
    "method": "...",
    "result": "...",
    "closing": "感谢各位老师的聆听..."
  },
  "common_questions": [
    {"type": "方法质疑", "example": "你的样本量够吗？", "strategy": "说清楚选择理由+承认局限性"}
  ],
  "next_step": "根据框架准备自述稿，熟悉论文全文，预判可能被追问的内容"
}
```

---

#### `literature` — 文献综述专项

```bash
python scripts/thesis_tutor.py --stage literature --level bachelor --quiet
```

**可选**：`--level`

**JSON 输出**：

```json
{
  "success": true,
  "stage": "literature",
  "literature_review": {
    "wrong_patterns": ["教科书式...", "流水账式..."],
    "classification_methods": {"cs": "...", "biz": "..."},
    "structure": {"step1": "...", "step2": "...", "step3": "...", "step4": "..."},
    "quantities": {"bachelor": "中文15-30篇 + 英文5-10篇", "master": "..."}
  },
  "next_step": "按上述步骤整理文献，建立分类框架，然后进入逐章写作"
}
```

---

#### `export` — 导出提示

```bash
python scripts/thesis_tutor.py --stage export --title "论文标题" --level bachelor --quiet
```

此 stage 不直接生成文件，返回 `export_docx.py` 的调用命令。

**JSON 输出**：

```json
{
  "success": true,
  "stage": "export",
  "message": "请使用 scripts/export_docx.py 生成Word文档",
  "command": "python scripts/export_docx.py --title '论文标题' --level bachelor"
}
```

---

#### `quantitative` — 量化研究指南

```bash
python scripts/thesis_tutor.py --stage quantitative --level master --quiet
```

**可选**：`--level`

**JSON 输出**：

```json
{
  "success": true,
  "stage": "quantitative",
  "overview": "本指南覆盖问卷法实证研究的全流程...",
  "workflow": [
    {"step": 1, "name": "研究设计", "duration": "1-2周", "output": "...", "key_points": ["..."]}
  ],
  "spss_checklist": [{"name": "描述性统计", "path": "...", "output": "..."}],
  "common_mistakes": [{"mistake": "...", "consequence": "...", "fix": "..."}],
  "sample_size_recommendation": "200-500",
  "hypotheses_recommendation": "4-8个",
  "next_step": "按流程推进：研究设计→预测试→正式发放→数据分析→结果讨论"
}
```

---

#### `qualitative` — 质性研究指南

```bash
python scripts/thesis_tutor.py --stage qualitative --level bachelor --quiet
```

**可选**：`--level`

**JSON 输出**：

```json
{
  "success": true,
  "stage": "qualitative",
  "overview": "本指南覆盖质性研究的全流程...",
  "methods": [
    {"name": "半结构化访谈", "suitable_for": "...", "sample_size": "10-15", "key_points": ["..."]}
  ],
  "analysis_method": {
    "name": "主题分析法（Braun & Clarke, 2006）",
    "recommended": true,
    "steps": [{"step": 1, "name": "熟悉数据", "description": "..."}]
  },
  "quality_criteria": [
    {"name": "可信性", "methods": "三角验证、成员检核"}
  ],
  "common_mistakes": [{"mistake": "...", "consequence": "...", "fix": "..."}],
  "writing_notes": ["..."],
  "detailed_reference": "references/qualitative-research.md",
  "next_step": "选择研究方法（访谈/案例研究/扎根理论），设计研究方案"
}
```

---

#### `plagiarism` — 查重与AI检测指南

```bash
python scripts/thesis_tutor.py --stage plagiarism --quiet
```

无需额外参数。

**JSON 输出**：

```json
{
  "success": true,
  "stage": "plagiarism",
  "detection_systems": {"知网CNKI": {"target": "...", "note": "..."}},
  "standards": {"bachelor_below_15": "绝大多数高校合格线"},
  "correct_methods": [{"method": "...", "example": "...", "effect": "..."}],
  "wrong_methods": [{"method": "...", "why": "..."}],
  "ai_reduction_tips": ["..."],
  "data_cleaning_example": {"发放": 350, "回收": 310, ...},
  "notes": ["..."],
  "next_step": "查重前自查：先用格子达等工具测初稿，降重后再用学校指定系统测终稿"
}
```

---

#### `toolchain` — 工具链指南

```bash
python scripts/thesis_tutor.py --stage toolchain --quiet
```

无需额外参数。

**JSON 输出**：

```json
{
  "success": true,
  "stage": "toolchain",
  "categories": {
    "literature_management": {"name": "文献管理", "tools": [{"name": "Zotero", ...}]},
    "writing_tools": {"name": "写作排版", "tools": [...]},
    "data_analysis": {"name": "数据分析", "tools": [...]},
    "efficiency": {"name": "效率工具", "tools": [...]}
  },
  "timeline_bachelor": {"description": "...", "phases": [...]},
  "timeline_master": {"description": "...", "phases": [...]},
  "common_traps": [{"trap": "...", "fix": "..."}],
  "next_step": "工具选好后，按时间规划推进..."
}
```

---

## export_docx.py — Word 文档导出

**路径**：`scripts/export_docx.py`

### 参数

| 参数 | 短参数 | 必填 | 说明 |
|------|--------|------|------|
| `--title` | `-t` | ✅ | 论文标题 |
| `--author` | `-a` | ✅ | 作者姓名 |
| `--level` | `-l` | 推荐 | 学位：`bachelor` / `master` / `phd`，默认 bachelor |
| `--major` | `-m` | 可选 | 专业名称 |
| `--advisor` | `-d` | 可选 | 指导教师 |
| `--school` | `-s` | 可选 | 学校/学院名称 |
| `--template` | — | 可选 | 学校模板文件路径 |
| `--output` | `-o` | 可选 | 输出文件名，默认 thesis.docx |
| `--quiet` | `-q` | 可选 | 安静模式（输出 JSON） |

### 依赖

```
pip install python-docx
```

未安装时生成 `thesis_config.json` 配置文件。

### 输出

- **成功**（python-docx 已安装）：生成 `.docx` 文件
- **无依赖**：生成 JSON 配置文件（`--quiet` 模式下）

---

## 输出模式

| 模式 | 触发 | 说明 |
|------|------|------|
| 友好格式 | 默认（无 `--quiet`） | emoji + 中文说明 |
| JSON | `--quiet` | 纯 JSON，可管道给其他工具 |
| 文件 | `--output file.json` | 写入文件 |

```bash
# 管道提取选题
python scripts/thesis_tutor.py --stage topic --major "计算机" --quiet | python -m json.tool

# 输出到文件
python scripts/thesis_tutor.py --stage outline --title "XXX研究" -o result.json
```
