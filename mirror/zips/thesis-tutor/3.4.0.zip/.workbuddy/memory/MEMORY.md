# thesis-tutor 长期记忆

## 项目概况
- **项目**：thesis-tutor，论文写作全流程AI导师 Skill
- **作者**：一梦繁星
- **当前版本**：v3.1（2026-04-20，经过三轮优化）
- **路径**：`d:\Skill Encyclopedia\thesis-tutor`

## v3.1 更新历程

### 第一轮（核心功能）
- 修复阶段④导师反馈处理表格格式错位（补全对策列）
- 补充阶段⑥导出docx的对话模式引导逻辑（区分对话模式/脚本模式）
- 新增质性研究专项：`references/qualitative-research.md`（访谈/案例研究/扎根理论/主题分析法）
- 在 `scripts/thesis_tutor.py` 新增 qualitative stage 全链路支持
- 修复 `references/quantitative-research.md` 中"补充指南"死链接
- 更新 SKILL.md：决策启发式表格新增质性研究触发行，description 新增质性研究引用
- 合并 SKILL.md description 中重复的专项模块列表为5行统一格式
- 更新 README.md 同步到七阶段 + 完整文件结构 + v3.1 版本号
- 更新 scorecard.json 补充 v3.1 版本记录
- 全文件版本号对齐 v3.1

### 第二轮（测试修复）
- 修复 run_tests.py 的 check_chapter 函数（T04/T11 测试：检查 paragraphs_analyzed 而非 comments）
- 新增 T12 质性研究专项测试
- 12项测试全部通过

### 第三轮（专业审计）
- **修复概念混淆检测逻辑 bug**（thesis_tutor.py）：CONCEPT_CONFUSIONS 的正则检测分支条件自相矛盾，导致概念混淆检测完全失效
- **全面重写 api_reference.md**：从 v1.0 升级到 v3.1，12 个 stage 全覆盖，所有 JSON 字段与引擎实际输出对齐
- **消除孤立文件**：SKILL.md 添加 api_reference.md 引用
- **修复 CLI 参数表不一致**：--quiet/--quick 短参数拆分、12个学科代码补全、stage 列表补全 export、--config 参数补全
- **增强测试严谨性**：T06 添加内容验证、T10 正确检测空内容拒绝行为、T08 用 lit 替代 humanities
- **新增 T13 概念混淆检测测试**
- 补全 scorecard.json v3.0 版本记录
- README.md stage 数量修正为 12 个

## 测试状态
- `scripts/run_tests.py` **13项测试全部通过（100%）**
- 报告文件：`test-report-v3.1.json`
- P0/P1 级问题已全部清零

## 遗留观察（非阻塞）
- export_docx.py 无依赖时输出混合中文+JSON，建议后续统一为纯 JSON
- TOPIC_TEMPLATES 只覆盖 cs/biz/lit/edu 四个学科，其余用通用模板
- 概念混淆配对规则只有 5 对，可扩展
