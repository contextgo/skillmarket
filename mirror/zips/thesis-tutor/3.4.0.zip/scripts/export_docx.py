#!/usr/bin/env python3
"""
thesis-tutor 文档导出工具
生成符合学校模板格式的Word文档
version: 3.4 | updated: 2026-04-21

用法:
python export_docx.py --title "论文标题" --author "作者" --level bachelor
python export_docx.py --config thesis_config.json --output thesis.docx
"""

import sys
import os
import json
import argparse
from datetime import datetime
from pathlib import Path

# Windows UTF-8 修复
if sys.platform == "win32":
    os.environ["PYTHONIOENCODING"] = "utf-8"
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass

# 尝试导入python-docx
try:
    from docx import Document
    from docx.shared import Pt, Inches, Cm, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
    from docx.enum.style import WD_STYLE_TYPE
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement
    HAS_DOCX = True
except ImportError:
    HAS_DOCX = False
    print("警告: 未安装 python-docx，将生成模板配置文件")
    print("安装命令: pip install python-docx")

def set_cell_border(cell, **kwargs):
    """设置表格单元格边框（预留接口，当前版本未调用）"""
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    
    for edge in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
        edge_data = kwargs.get(edge)
        if edge_data:
            tag = f'w:{edge}'
            element = tcPr.find(qn(tag))
            if element is None:
                element = OxmlElement(tag)
                tcPr.append(element)
            
            for key in ['val', 'sz', 'space', 'color']:
                if key in edge_data:
                    element.set(qn(f'w:{key}'), str(edge_data[key]))

def create_thesis_doc(title: str, author: str, level: str = "bachelor",
                      major: str = "", advisor: str = "", school: str = "",
                      template_path: str = None):
    """创建论文文档
    
    Returns:
        Document: python-docx Document 对象（python-docx 已安装时）
        str: JSON 配置字符串（python-docx 未安装时）
    """
    
    if not HAS_DOCX:
        # 生成配置模板
        config = {
            "title": title,
            "author": author,
            "level": level,
            "major": major,
            "advisor": advisor,
            "school": school,
            "date": datetime.now().strftime("%Y年%m月"),
            "sections": {
                "abstract_cn": "中文摘要内容...",
                "abstract_en": "English abstract content...",
                "keywords_cn": ["关键词1", "关键词2", "关键词3"],
                "keywords_en": ["keyword1", "keyword2", "keyword3"],
                "chapters": [
                    {"title": "1 绪论", "content": "第一章内容..."},
                    {"title": "2 相关理论与技术基础", "content": "第二章内容..."},
                    {"title": "3 核心方法", "content": "第三章内容..."},
                    {"title": "4 实验与分析", "content": "第四章内容..."},
                    {"title": "5 总结与展望", "content": "第五章内容..."}
                ],
                "references": [
                    "[1] 作者. 文献标题[J]. 期刊名, 年份, 卷(期): 页码.",
                    "[2] Author. Title[J]. Journal, Year, Vol(Issue): Pages."
                ],
                "acknowledgement": "致谢内容..."
            }
        }
        return json.dumps(config, ensure_ascii=False, indent=2)
    
    # 创建文档
    doc = Document()
    
    # 设置默认字体
    style = doc.styles['Normal']
    style.font.name = 'Times New Roman'
    style.font.size = Pt(12)
    style._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')
    
    # 设置段落格式
    style.paragraph_format.line_spacing = 1.5
    style.paragraph_format.space_after = Pt(0)
    
    # ===== 封面 =====
    if school:
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run(school)
        run.font.size = Pt(22)
        run.font.bold = True
        run.font.name = '黑体'
        run._element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    # 学位类型
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    level_text = {"bachelor": "本科毕业论文", "master": "硕士学位论文", "phd": "博士学位论文"}
    run = p.add_run(level_text.get(level, "毕业论文"))
    run.font.size = Pt(26)
    run.font.bold = True
    run.font.name = '黑体'
    run._element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    doc.add_paragraph()  # 空行
    
    # 论文标题
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run(f"题目：{title}")
    run.font.size = Pt(18)
    run.font.name = '黑体'
    run._element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    doc.add_paragraph()
    doc.add_paragraph()
    
    # 信息表格
    info_items = [
        ("学院", school or "XXX学院"),
        ("专业", major or "XXX专业"),
        ("姓名", author),
        ("学号", "20XXXXXXXX"),
        ("指导教师", advisor or "XXX 教授")
    ]
    
    table = doc.add_table(rows=len(info_items), cols=2)
    table.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    for i, (label, value) in enumerate(info_items):
        row = table.rows[i]
        # 标签单元格
        cell_label = row.cells[0]
        cell_label.text = label
        cell_label.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.RIGHT
        for run in cell_label.paragraphs[0].runs:
            run.font.size = Pt(14)
            run.font.name = '宋体'
            run._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')
        
        # 值单元格
        cell_value = row.cells[1]
        cell_value.text = value
        cell_value.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.LEFT
        for run in cell_value.paragraphs[0].runs:
            run.font.size = Pt(14)
            run.font.name = '宋体'
            run._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')
    
    # 日期
    doc.add_paragraph()
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run(datetime.now().strftime("%Y年%m月"))
    run.font.size = Pt(14)
    run.font.name = '宋体'
    run._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')
    
    # 分页
    doc.add_page_break()
    
    # ===== 摘要 =====
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run("摘  要")
    run.font.size = Pt(16)
    run.font.bold = True
    run.font.name = '黑体'
    run._element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    doc.add_paragraph()
    
    # 摘要内容占位
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.74)  # 2字符缩进
    run = p.add_run("【中文摘要内容】\n\n本文研究了...（此处为摘要内容占位，实际使用时请替换为具体摘要内容）")
    run.font.size = Pt(12)
    run.font.name = '宋体'
    run._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')
    
    doc.add_paragraph()
    
    # 关键词
    p = doc.add_paragraph()
    run = p.add_run("关键词：")
    run.font.size = Pt(12)
    run.font.bold = True
    run.font.name = '黑体'
    run._element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    run = p.add_run("关键词1；关键词2；关键词3")
    run.font.size = Pt(12)
    run.font.name = '宋体'
    run._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')
    
    doc.add_page_break()
    
    # ===== 英文摘要 =====
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run("Abstract")
    run.font.size = Pt(16)
    run.font.bold = True
    run.font.name = 'Times New Roman'
    
    doc.add_paragraph()
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.74)
    run = p.add_run("【English Abstract Content】\n\nThis paper studies... (Placeholder for English abstract)")
    run.font.size = Pt(12)
    run.font.name = 'Times New Roman'
    
    doc.add_paragraph()
    
    # Keywords
    p = doc.add_paragraph()
    run = p.add_run("Keywords: ")
    run.font.size = Pt(12)
    run.font.bold = True
    run.font.name = 'Times New Roman'
    
    run = p.add_run("keyword1; keyword2; keyword3")
    run.font.size = Pt(12)
    run.font.name = 'Times New Roman'
    
    doc.add_page_break()
    
    # ===== 目录占位 =====
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run("目  录")
    run.font.size = Pt(16)
    run.font.bold = True
    run.font.name = '黑体'
    run._element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    doc.add_paragraph()
    
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run("【目录将在Word中自动生成】\n\n请使用Word的'引用'->'目录'功能生成自动目录")
    run.font.size = Pt(12)
    run.font.name = '宋体'
    run._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')
    
    doc.add_page_break()
    
    # ===== 正文章节占位 =====
    chapters = [
        "1 绪论",
        "2 相关理论与技术基础",
        "3 核心方法/主体分析",
        "4 实验与结果/案例分析",
        "5 总结与展望"
    ]
    
    for chapter in chapters:
        # 一级标题
        p = doc.add_paragraph()
        run = p.add_run(chapter)
        run.font.size = Pt(16)
        run.font.bold = True
        run.font.name = '黑体'
        run._element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
        
        doc.add_paragraph()
        
        # 占位内容
        p = doc.add_paragraph()
        p.paragraph_format.first_line_indent = Cm(0.74)
        run = p.add_run(f"【{chapter}内容】\n\n（此处为{chapter}内容占位，请根据大纲填充具体内容）")
        run.font.size = Pt(12)
        run.font.name = '宋体'
        run._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')
        
        doc.add_page_break()
    
    # ===== 参考文献占位 =====
    p = doc.add_paragraph()
    run = p.add_run("参考文献")
    run.font.size = Pt(16)
    run.font.bold = True
    run.font.name = '黑体'
    run._element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    doc.add_paragraph()
    
    refs = [
        "[1] 作者姓名. 文献标题[J]. 期刊名称, 2024, 卷(期): 起止页码.",
        "[2] Author Name. Article Title[J]. Journal Name, 2024, Vol(Issue): Pages.",
        "[3] 作者姓名. 书名[M]. 出版地: 出版社, 2024.",
        "[4] 作者姓名. 论文标题[D]. 保存地: 保存单位, 2024."
    ]
    
    for ref in refs:
        p = doc.add_paragraph()
        run = p.add_run(ref)
        run.font.size = Pt(10.5)
        run.font.name = '宋体'
        run._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')
    
    doc.add_page_break()
    
    # ===== 致谢 =====
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run("致  谢")
    run.font.size = Pt(16)
    run.font.bold = True
    run.font.name = '黑体'
    run._element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    doc.add_paragraph()
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.74)
    run = p.add_run("【致谢内容】\n\n（此处为致谢内容占位，请根据实际情况填写）")
    run.font.size = Pt(12)
    run.font.name = '宋体'
    run._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')
    
    return doc

def main():
    parser = argparse.ArgumentParser(description="thesis-tutor 文档导出工具")
    parser.add_argument("--title", "-t", required=True, help="论文标题")
    parser.add_argument("--author", "-a", required=True, help="作者姓名")
    parser.add_argument("--level", "-l", default="bachelor", 
                       choices=["bachelor", "master", "phd"],
                       help="学位级别")
    parser.add_argument("--major", "-m", default="", help="专业")
    parser.add_argument("--advisor", "-d", default="", help="指导教师")
    parser.add_argument("--school", "-s", default="", help="学校/学院")
    parser.add_argument("--template", help="学校模板文件路径")
    parser.add_argument("--config", "-c", help="配置文件(JSON)")
    parser.add_argument("--output", "-o", default="thesis.docx", help="输出文件名")
    parser.add_argument("--quiet", "-q", action="store_true", help="安静模式")
    
    args = parser.parse_args()
    
    # 读取配置
    config = {}
    if args.config and os.path.exists(args.config):
        with open(args.config, 'r', encoding='utf-8') as f:
            config = json.load(f)
    
    # 合并参数
    title = config.get("title", args.title)
    author = config.get("author", args.author)
    level = config.get("level", args.level)
    major = config.get("major", args.major)
    advisor = config.get("advisor", args.advisor)
    school = config.get("school", args.school)
    
    if not HAS_DOCX:
        # 生成配置模板文件
        config_json = create_thesis_doc(title, author, level, major, advisor, school)
        config_path = args.output.replace('.docx', '_config.json')
        with open(config_path, 'w', encoding='utf-8') as f:
            f.write(config_json)
        
        if args.quiet:
            result = {
                "success": False,
                "error": "python-docx not installed",
                "config_path": config_path,
                "install_cmd": "pip install python-docx"
            }
            print(json.dumps(result, ensure_ascii=False))
        else:
            print(f"已生成配置模板: {config_path}")
            print(f"请安装 python-docx 后重新运行: pip install python-docx")
        return 0 if args.quiet else 1
    
    # 创建文档
    doc = create_thesis_doc(title, author, level, major, advisor, school, args.template)
    
    # 保存
    output_path = args.output
    if not output_path.endswith('.docx'):
        output_path += '.docx'
    
    doc.save(output_path)
    
    if not args.quiet:
        print(f"\n{'='*60}")
        print(f"[EXPORT] thesis-tutor Document Export")
        print(f"{'='*60}")
        print(f"\n[OK] Document saved: {output_path}")
        print(f"\nDocument Info:")
        print(f"   Title: {title}")
        print(f"   Author: {author}")
        print(f"   Level: {level}")
        print(f"   Major: {major or 'Not specified'}")
        print(f"   Advisor: {advisor or 'Not specified'}")
        print(f"\nTips:")
        print(f"   1. Open the Word document and replace placeholder content")
        print(f"   2. Use 'References' -> 'Table of Contents' to generate auto TOC")
        print(f"   3. Adjust formatting according to your school template")
        print(f"\n{'='*60}\n")
    else:
        result = {
            "success": True,
            "output_path": output_path,
            "title": title,
            "author": author,
            "level": level
        }
        print(json.dumps(result, ensure_ascii=False))
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
