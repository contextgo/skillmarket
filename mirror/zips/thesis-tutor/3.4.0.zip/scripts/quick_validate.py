#!/usr/bin/env python3
"""Quick validation script for thesis-tutor skill"""

import sys
import os
import re
import json
from pathlib import Path

def validate_skill(skill_path):
    skill_path = Path(skill_path)
    errors = []
    warnings = []
    
    # Check required files
    required_files = [
        'SKILL.md',
        'test-prompts.json',
        'scorecard.json',
        'test-runner.md'
    ]
    
    for file in required_files:
        file_path = skill_path / file
        if not file_path.exists():
            errors.append(f"Missing required file: {file}")
    
    # Check references/
    refs_dir = skill_path / 'references'
    if not refs_dir.exists():
        errors.append("Missing references/ directory")
    else:
        ref_files = ['topic-selection.md', 'outline-templates.md', 'writing-guide.md', 'checklist.md']
        for file in ref_files:
            if not (refs_dir / file).exists():
                warnings.append(f"Missing reference file: {file}")
    
    # Check scripts/
    scripts_dir = skill_path / 'scripts'
    if not scripts_dir.exists():
        errors.append("Missing scripts/ directory")
    else:
        script_files = ['thesis_tutor.py', 'export_docx.py']
        for file in script_files:
            if not (scripts_dir / file).exists():
                errors.append(f"Missing script: {file}")
    
    # Validate SKILL.md
    skill_md = skill_path / 'SKILL.md'
    if skill_md.exists():
        try:
            content = skill_md.read_text(encoding='utf-8')
            
            # Check frontmatter
            if not content.startswith('---'):
                errors.append("SKILL.md: No YAML frontmatter found")
            else:
                match = re.match(r'^---\n(.*?)\n---', content, re.DOTALL)
                if not match:
                    errors.append("SKILL.md: Invalid frontmatter format")
            
            # Check required sections
            required_sections = [
                '角色定位', '决策启发式', '阶段①', '阶段②', '阶段③', 
                '阶段④', '阶段⑤', '阶段⑥', '快速启动', '能做/不能做'
            ]
            for section in required_sections:
                if section not in content:
                    errors.append(f"SKILL.md: Missing section '{section}'")
            
            # Check for anti-patterns
            anti_patterns = ['我来帮你写', '这是一篇非常优秀的', '直接输出大段论文']
            for pattern in anti_patterns:
                if pattern in content:
                    warnings.append(f"SKILL.md: May contain anti-pattern: '{pattern}'")
                    
        except Exception as e:
            errors.append(f"Cannot read SKILL.md: {e}")
    
    # Validate test-prompts.json
    test_prompts = skill_path / 'test-prompts.json'
    if test_prompts.exists():
        try:
            with open(test_prompts, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            required_keys = ['known', 'transfer', 'counterexample', 'baseline_comparison', 'adjacent_comparison']
            for key in required_keys:
                if key not in data:
                    errors.append(f"test-prompts.json: Missing key '{key}'")
            
            # Check known scenarios count
            if 'known' in data and len(data['known']) < 5:
                warnings.append(f"test-prompts.json: Only {len(data['known'])} known scenarios (recommend 5+)")
                
        except json.JSONDecodeError as e:
            errors.append(f"test-prompts.json: Invalid JSON - {e}")
        except Exception as e:
            errors.append(f"Cannot read test-prompts.json: {e}")
    
    # Summary
    return len(errors) == 0, errors, warnings

if __name__ == "__main__":
    if len(sys.argv) != 2:
        skill_path = Path(__file__).parent.parent
    else:
        skill_path = Path(sys.argv[1])
    
    valid, errors, warnings = validate_skill(skill_path)
    
    print(f"\n{'='*60}")
    print(f"[VALIDATE] thesis-tutor Skill Validation")
    print(f"{'='*60}")
    print(f"\nPath: {skill_path}")
    
    if errors:
        print(f"\n[ERROR] ({len(errors)}):")
        for e in errors:
            print(f"   - {e}")
    
    if warnings:
        print(f"\n[WARNING] ({len(warnings)}):")
        for w in warnings:
            print(f"   - {w}")
    
    if valid and not warnings:
        print(f"\n[OK] Skill validation passed!")
    elif valid:
        print(f"\n[OK] Skill validation passed (with warnings)")
    else:
        print(f"\n[FAIL] Skill validation failed")
    
    print(f"\n{'='*60}\n")
    
    sys.exit(0 if valid else 1)
