#!/usr/bin/env python3
"""
thesis-tutor 论文导师引擎 v3.4
论文写作全流程AI导师

用法:
python thesis_tutor.py --stage topic --major "计算机" --level bachelor
python thesis_tutor.py --stage outline --title "XXX研究" --discipline cs
python thesis_tutor.py --stage chapter --text "我觉得深度学习很好..."
python thesis_tutor.py --stage quantitative --level master
python thesis_tutor.py --stage plagiarism --quiet
python thesis_tutor.py --stage toolchain --quiet
"""

import sys
import os
import json
import argparse
import re
from typing import Dict, List, Optional, Tuple
from pathlib import Path

# Windows UTF-8 修复
if sys.platform == "win32":
    os.environ["PYTHONIOENCODING"] = "utf-8"
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass

# ============ 学科分类与特性 ============

DISCIPLINES = {
    "cs": {"name": "计算机", "type": "理工", "keywords": ["算法", "系统", "模型", "实验", "软件", "网络", "安全", "人工智能"]},
    "ee": {"name": "电子/通信", "type": "理工", "keywords": ["信号", "电路", "通信", "仿真", "自动化"]},
    "mech": {"name": "机械", "type": "理工", "keywords": ["设计", "仿真", "制造", "控制", "材料"]},
    "bio": {"name": "生物/医学", "type": "理工", "keywords": ["生物", "医学", "药学", "公卫", "临床"]},
    "biz": {"name": "商科", "type": "经管", "keywords": ["管理", "营销", "人力资源", "运营", "战略", "电商"]},
    "econ": {"name": "经济/金融", "type": "经管", "keywords": ["经济", "金融", "财政", "保险", "银行"]},
    "law": {"name": "法学", "type": "法学", "keywords": ["法律", "法学", "司法", "立法", "合规"]},
    "lit": {"name": "文学", "type": "文科", "keywords": ["文学", "语言", "汉语", "外语"]},
    "media": {"name": "传媒", "type": "文科", "keywords": ["传播", "传媒", "新闻", "广告", "影视"]},
    "edu": {"name": "教育", "type": "教育", "keywords": ["教育", "教学", "学习", "课程", "教师"]},
    "psy": {"name": "心理", "type": "教育", "keywords": ["心理", "认知", "行为", "临床心理"]},
    "art": {"name": "艺术/设计", "type": "艺术", "keywords": ["艺术", "设计", "视觉", "音乐", "美术", "非遗"]},
}

# ============ 选题方向库 ============

TOPIC_TEMPLATES = {
    "cs": [
        {"template": "基于{技术}的{场景}{任务}研究", "example": "基于大模型的代码生成质量评估研究", "difficulty": "中", "innovation": "高"},
        {"template": "{方法}在{领域}中的应用与优化", "example": "强化学习在推荐系统中的应用与优化", "difficulty": "中", "innovation": "中"},
        {"template": "面向{场景}的{系统}设计与实现", "example": "面向边缘计算的轻量级图像识别系统设计与实现", "difficulty": "低", "innovation": "中"},
        {"template": "{数据类型}驱动的{任务}方法研究", "example": "多模态数据驱动的情感分析方法研究", "difficulty": "高", "innovation": "高"},
        {"template": "{问题}的{技术}解决方案研究", "example": "低资源场景下的模型压缩与部署方案研究", "difficulty": "中", "innovation": "中"}
    ],
    "biz": [
        {"template": "{因素}对{对象}{行为}的影响研究", "example": "直播互动性对消费者购买意愿的影响研究", "difficulty": "低", "innovation": "低"},
        {"template": "{企业/行业}的{问题}与{策略}研究", "example": "新能源汽车企业的品牌传播策略研究", "difficulty": "中", "innovation": "中"},
        {"template": "基于{理论}的{现象}解释与实证", "example": "基于计划行为理论的Z世代可持续消费行为研究", "difficulty": "中", "innovation": "中"},
        {"template": "{技术/趋势}背景下{领域}的变革研究", "example": "AIGC背景下内容创意产业的商业模式变革研究", "difficulty": "中", "innovation": "高"},
        {"template": "{变量}与{变量}的关系研究：{调节/中介}效应检验", "example": "工作自主权与员工创新行为的关系研究：心理安全感的中介效应", "difficulty": "中", "innovation": "中"}
    ],
    "lit": [
        {"template": "{作家/作品}的{主题}研究", "example": "余华小说中的苦难叙事研究", "difficulty": "低", "innovation": "低"},
        {"template": "{现象}的{理论}视角分析", "example": "网络文学的IP改编机制研究", "difficulty": "中", "innovation": "中"},
        {"template": "{文本}的{方法}解读", "example": "《流浪地球》系列电影的跨文化叙事策略分析", "difficulty": "中", "innovation": "中"},
        {"template": "{时期/流派}文学中的{主题}演变", "example": "新世纪以来都市文学中的空间书写演变", "difficulty": "高", "innovation": "高"},
        {"template": "比较视野下的{对象}研究", "example": "中美科幻电影中的未来想象比较研究", "difficulty": "中", "innovation": "中"}
    ],
    "edu": [
        {"template": "{技术/方法}在{学科}教学中的应用研究", "example": "项目式学习在高中物理教学中的应用研究", "difficulty": "低", "innovation": "中"},
        {"template": "{群体}的{能力/素养}培养策略研究", "example": "师范生数字素养培养策略研究", "difficulty": "中", "innovation": "中"},
        {"template": "{政策/改革}背景下{问题}的应对研究", "example": "双减政策背景下课后服务质量的提升策略", "difficulty": "中", "innovation": "中"},
        {"template": "基于{理论}的{现象}分析", "example": "基于社会文化理论的在线协作学习分析", "difficulty": "高", "innovation": "高"},
        {"template": "{学段}学生{问题}的现状调查与对策", "example": "初中生学习动机衰减的现状调查与干预对策", "difficulty": "低", "innovation": "低"}
    ]
}

DEFAULT_TEMPLATES = [
    {"template": "{领域}中的{问题}研究", "example": "XXX领域中的YYY问题研究", "difficulty": "中", "innovation": "中"},
    {"template": "基于{方法}的{任务}研究", "example": "基于ZZZ方法的WWW任务研究", "difficulty": "中", "innovation": "中"},
    {"template": "{场景}下的{系统/方案}设计", "example": "AAA场景下的BBB系统设计", "difficulty": "低", "innovation": "中"}
]

# ============ 大纲结构模板 ============

OUTLINE_TEMPLATES = {
    "理工": {
        "structure": [
            {"chapter": "1 绪论", "sections": ["研究背景与意义", "国内外研究现状", "研究内容与论文结构"], "words": "2000-3000"},
            {"chapter": "2 相关理论与技术基础", "sections": ["核心概念定义", "相关技术介绍", "本文技术路线"], "words": "3000-4000"},
            {"chapter": "3 核心方法/系统设计", "sections": ["问题建模", "方法设计", "技术创新点"], "words": "4000-6000"},
            {"chapter": "4 实验与结果分析", "sections": ["实验环境", "评价指标", "结果对比", "消融实验"], "words": "3000-5000"},
            {"chapter": "5 总结与展望", "sections": ["研究总结", "不足与展望"], "words": "1000-1500"}
        ]
    },
    "经管": {
        "structure": [
            {"chapter": "1 绪论", "sections": ["研究背景", "研究目的与意义", "研究内容与方法", "论文结构"], "words": "2000-3000"},
            {"chapter": "2 文献综述与理论基础", "sections": ["概念界定", "国内外研究现状", "理论基础与研究假设"], "words": "4000-6000"},
            {"chapter": "3 研究设计", "sections": ["研究模型", "变量测量", "数据收集", "分析方法"], "words": "3000-4000"},
            {"chapter": "4 数据分析与结果", "sections": ["描述性统计", "信效度检验", "假设检验", "结果讨论"], "words": "4000-6000"},
            {"chapter": "5 结论与建议", "sections": ["研究结论", "管理启示", "局限与展望"], "words": "2000-3000"}
        ]
    },
    "文科": {
        "structure": [
            {"chapter": "1 绪论", "sections": ["研究背景与问题", "研究现状", "研究思路与方法", "研究意义"], "words": "3000-4000"},
            {"chapter": "2 核心概念与理论框架", "sections": ["概念界定", "理论基础", "分析框架"], "words": "3000-4000"},
            {"chapter": "3 主体分析（一）", "sections": ["具体分析内容"], "words": "4000-6000"},
            {"chapter": "4 主体分析（二）", "sections": ["具体分析内容"], "words": "4000-6000"},
            {"chapter": "5 结论", "sections": ["研究结论", "研究局限", "研究展望"], "words": "2000-3000"}
        ]
    },
    "教育": {
        "structure": [
            {"chapter": "1 绪论", "sections": ["研究背景", "研究问题", "研究意义", "概念界定"], "words": "2000-3000"},
            {"chapter": "2 文献综述", "sections": ["国内研究现状", "国外研究现状", "研究述评"], "words": "3000-4000"},
            {"chapter": "3 研究设计", "sections": ["研究对象", "研究方法", "研究过程", "数据分析"], "words": "3000-4000"},
            {"chapter": "4 研究结果与分析", "sections": ["量化分析", "质性分析", "综合讨论"], "words": "4000-6000"},
            {"chapter": "5 结论与建议", "sections": ["研究结论", "教育建议", "不足与展望"], "words": "2000-3000"}
        ]
    }
}

# ============ 自检清单 ============

CHECKLIST_ITEMS = {
    "format": [
        "标题层级格式统一",
        "字体字号符合规范",
        "页边距和行距正确",
        "图表编号连续",
        "页码格式正确"
    ],
    "citation": [
        "参考文献格式统一（GB/T 7714）",
        "正文引用与参考文献对应",
        "引用数量达标",
        "外文文献占比达标",
        "近5年文献占比达标"
    ],
    "logic": [
        "绪论问题在结论中回应",
        "研究方法支撑结论",
        "论证有论据支撑",
        "无自相矛盾论述",
        "章节间有过渡"
    ],
    "common": [
        "摘要字数符合要求",
        "关键词3-5个",
        "目录与正文一致",
        "致谢无错别字",
        "无第一人称（我）"
    ]
}

# ============ 段落分析规则库 ============

# 口语化表达 → 学术替代表达
ORAL_TO_ACADEMIC = {
    "我觉得": ("本文认为", "研究表明", "数据显示"),
    "这个东西": ("该对象", "该变量", "该因素"),
    "那玩意儿": ("该方法", "该技术"),
    "很多": ("较多", "显著", "明显增多"),
    "非常好": ("效果显著", "表现优异"),
    "特别好": ("优势明显", "优势突出"),
    "挺好的": ("较好", "具有优势"),
    "非常不好": ("存在显著不足", "效果欠佳"),
    "很明显": ("显著", "明显"),
    "其实": ("实际上", "事实上"),
    "所以说": ("因此", "由此可见"),
    "大家都知道": ("已有研究表明", "学术界普遍认为"),
    "大概": ("约", "约为"),
    "差不多": ("相近", "接近"),
    "基本上": ("总体上", "整体而言"),
    "应该可以": ("可能", "有望"),
    "挺": ("较", "较为"),
}

# 因果关系逻辑错误检测（相关性当因果）
CORRELATION_MISTAKEN_CAUSAL = [
    (r"(?<![被])导致", "使用了'导致'但未明确说明因果机制。需补充：①因果逻辑说明；②排除其他解释；③说明因果方向"),
    (r"(?<![被])造成", "使用了'造成'但缺少因果证据。请确认这是因果关系而非相关关系"),
    (r"所以就", "推理跳跃。请补充中间的逻辑环节，不要从'A'直接跳到'所以B'"),
    (r"从而", "逻辑跳跃。'从而'前后必须有清晰的因果链条"),
]

# 概念混淆检测（常见错误配对）
CONCEPT_CONFUSIONS = [
    ("相关", "因果", "相关不等于因果。'X与Y相关'不能推出'X导致Y'，需补充因果机制说明"),
    ("相关", "因果", "发现了相关关系后，需要进一步论证因果方向（A→B 还是 B→A 还是共同被C驱动）"),
    ("显著", "重要", "'统计显著'不等于'实际重要'。需说明效应量（effect size）以及实际意义"),
    ("创新", "正确", "创新不等于正确。答辩时需说明创新点同时接受了实证检验"),
    ("样本", "总体", "样本结论不能直接推广到总体。需说明抽样范围和推广条件"),
]

# 无效论证模式
WEAK_ARGUMENT_PATTERNS = [
    (r"专家学者认为", "权威引用不等于论证。需要说明引用内容与本文论点的逻辑关系"),
    (r"很多人都在用", "从众不等于正确。请从原理或数据层面说明'为什么好'"),
    (r"这是常识", "学术写作不承认'常识'。所有论点都需要论证，即使是公认事实"),
    (r"显然", "请用数据或逻辑证明，'显然'不是论据"),
    (r"显而易见", "同上，请用证据替代修辞"),
    (r"无可否认", "同上，学术论断需基于证据"),
]

# 结构问题检测
STRUCTURE_PATTERNS = [
    (r"^.{10,50}$", "段落过短（少于50字），内容可能不够充分展开"),
    (None, "段落过长（超过500字）", lambda t: len(t) > 500),
]

# ============ 核心函数 ============

def detect_discipline(major: str) -> str:
    """根据专业名称检测学科代码"""
    if not major:
        return "cs"
    major_lower = major.lower()
    for code, info in DISCIPLINES.items():
        if info["name"] in major or any(kw in major_lower for kw in info["keywords"]):
            return code
    return "cs"

def get_discipline_type(discipline_code: str) -> str:
    """获取学科类型"""
    if discipline_code in DISCIPLINES:
        return DISCIPLINES[discipline_code]["type"]
    return "理工"

def generate_topics(major: str, level: str = "bachelor", count: int = 5) -> List[Dict]:
    """生成候选题目"""
    discipline = detect_discipline(major)
    templates = TOPIC_TEMPLATES.get(discipline, DEFAULT_TEMPLATES)
    topics = []
    for i, template in enumerate(templates[:count]):
        difficulty = template["difficulty"]
        innovation = template["innovation"]
        if level == "bachelor" and difficulty == "高":
            difficulty = "中"
        if "影响" in template["example"] or "行为" in template["example"]:
            resource = "高"
        elif "设计" in template["example"] or "实现" in template["example"]:
            resource = "中"
        else:
            resource = "中"
        topics.append({
            "id": f"topic_{i+1}",
            "template": template["template"],
            "example": template["example"],
            "difficulty": difficulty,
            "innovation": innovation,
            "resource": resource,
            "reason": f"基于{major or '本领域'}的常见研究范式，适合{level}水平"
        })
    return topics

def generate_outline(title: str, discipline_code: str, level: str = "bachelor") -> Dict:
    """生成论文大纲"""
    discipline_type = get_discipline_type(discipline_code)
    template = OUTLINE_TEMPLATES.get(discipline_type, OUTLINE_TEMPLATES["理工"])
    outline = {"title": title, "discipline": discipline_type, "level": level, "chapters": []}
    total_min, total_max = 0, 0
    for chapter in template["structure"]:
        words_range = chapter["words"].split("-")
        w_min = int(words_range[0])
        w_max = int(words_range[1]) if len(words_range) > 1 else w_min
        total_min += w_min
        total_max += w_max
        outline["chapters"].append({
            "chapter": chapter["chapter"],
            "sections": chapter["sections"],
            "words": chapter["words"],
            "guidance": f"本章应围绕{chapter['sections'][0]}展开，注意与前后章节的逻辑衔接"
        })
    outline["total_words"] = f"{total_min}-{total_max}"
    return outline

def generate_checklist(stage: str = "all") -> Dict:
    """生成自检清单"""
    if stage == "all":
        return CHECKLIST_ITEMS
    elif stage in CHECKLIST_ITEMS:
        return {stage: CHECKLIST_ITEMS[stage]}
    return CHECKLIST_ITEMS

# ============ v3.1 段落分析引擎 ============

def split_paragraphs(text: str) -> List[str]:
    """智能分段落，保留段落结构"""
    # 按换行+段间距分割
    paras = re.split(r'\n\s*\n', text.strip())
    return [p.strip() for p in paras if p.strip()]

def analyze_paragraph_v3(text: str) -> Dict:
    """
    v3.1 段落分析引擎：多维度导师式批注
    
    分析维度：
    1. 口语化表达
    2. 逻辑漏洞
    3. 概念混淆
    4. 无效论证
    5. 学术规范
    6. 结构问题
    """
    result = {
        "success": True,
        "total_paragraphs": 0,
        "paragraphs_analyzed": [],
        "summary": {"expression": 0, "logic": 0, "concept": 0, "argument": 0, "structure": 0},
        "overall_score": 10,
        "overall_grade": "",
        "top_issues": [],
        "suggestions": []
    }
    
    paragraphs = split_paragraphs(text)
    result["total_paragraphs"] = len(paragraphs)
    
    for idx, para in enumerate(paragraphs):
        para_feedback = {"index": idx + 1, "text_preview": para[:80] + ("..." if len(para) > 80 else ""), "issues": []}
        
        # 1. 口语化表达检测
        for oral_word, alternatives in ORAL_TO_ACADEMIC.items():
            if oral_word in para:
                para_feedback["issues"].append({
                    "type": "expression",
                    "severity": "warn",
                    "marker": oral_word,
                    "issue": f"发现口语化表达「{oral_word}」",
                    "suggestion": f"建议改为：'{"' 或 '".join(alternatives)}'",
                    "academy_example": f"学术表达示例：'{"、".join(alternatives[0:2])}'"
                })
                result["summary"]["expression"] += 1
        
        # 2. 因果关系逻辑错误
        for pattern, suggestion in CORRELATION_MISTAKEN_CAUSAL:
            matches = list(re.finditer(pattern, para))
            for match in matches:
                context = para[max(0, match.start()-20):match.end()+40]
                para_feedback["issues"].append({
                    "type": "logic",
                    "severity": "error",
                    "marker": match.group(),
                    "context": f"...{context}...",
                    "issue": suggestion,
                    "suggestion": "补充因果链条：①说明因果机制；②排除替代解释；③论证因果方向"
                })
                result["summary"]["logic"] += 1
        
        # 3. 无效论证模式
        for pattern, suggestion in WEAK_ARGUMENT_PATTERNS:
            if re.search(pattern, para):
                para_feedback["issues"].append({
                    "type": "argument",
                    "severity": "error",
                    "marker": re.search(pattern, para).group(),
                    "issue": f"无效论证：{suggestion}",
                    "suggestion": "用证据（数据/文献/实验结果）替代修辞性表达"
                })
                result["summary"]["argument"] += 1
        
        # 4. 概念混淆检测
        for word1, word2, suggestion in CONCEPT_CONFUSIONS:
            if word1 in para and word2 in para:
                para_feedback["issues"].append({
                    "type": "concept",
                    "severity": "warn",
                    "issue": f"疑似概念混淆：'{word1}'和'{word2}'需要区分",
                    "suggestion": suggestion
                })
                result["summary"]["concept"] += 1
        
        # 5. 学术规范检测
        academic_issues = check_academic_norm(para)
        for issue in academic_issues:
            para_feedback["issues"].append(issue)
        
        # 6. 结构问题
        if len(para) < 50:
            para_feedback["issues"].append({
                "type": "structure",
                "severity": "info",
                "issue": "段落过短（<50字），可能未充分展开论点",
                "suggestion": "建议补充：①论据支撑；②进一步分析；③与相邻段落合并"
            })
            result["summary"]["structure"] += 1
        elif len(para) > 600:
            para_feedback["issues"].append({
                "type": "structure",
                "severity": "info",
                "issue": f"段落偏长（>{600}字），建议拆分",
                "suggestion": "每个段落聚焦一个核心论点，建议每段100-300字"
            })
            result["summary"]["structure"] += 1
        
        if para_feedback["issues"]:
            result["paragraphs_analyzed"].append(para_feedback)
    
    # 计算综合评分
    total_issues = sum(result["summary"].values())
    result["overall_score"] = max(1, min(10, 10 - total_issues * 0.5))
    score = result["overall_score"]
    if score >= 8:
        result["overall_grade"] = "优秀 — 无明显问题，可进入下一阶段"
    elif score >= 6:
        result["overall_grade"] = "良好 — 有少量问题，按建议修改后更佳"
    elif score >= 4:
        result["overall_grade"] = "一般 — 存在逻辑或论证问题，需要认真修改"
    else:
        result["overall_grade"] = "需要大改 — 建议先通读写作指引，重新梳理论证逻辑"
    
    # 总结前3个最严重问题
    all_issues = []
    for p in result["paragraphs_analyzed"]:
        for issue in p["issues"]:
            if issue.get("severity") == "error":
                all_issues.append((issue["type"], issue["issue"][:60]))
    seen = set()
    for t, i in all_issues:
        if (t, i) not in seen:
            result["top_issues"].append({"type": t, "issue": i})
            seen.add((t, i))
            if len(result["top_issues"]) >= 3:
                break
    
    # 整体修改建议
    if result["summary"]["expression"] > 0:
        result["suggestions"].append(f"全局口语化：全文{result['summary']['expression']}处口语化表达需改为学术表达")
    if result["summary"]["logic"] > 0:
        result["suggestions"].append(f"⚠️ 逻辑问题：{result['summary']['logic']}处因果关系疑似证据不足，请逐一补充因果链条")
    if result["summary"]["argument"] > 0:
        result["suggestions"].append(f"论证问题：{result['summary']['argument']}处使用了无效论据（修辞代替证据）")
    if result["summary"]["concept"] > 0:
        result["suggestions"].append(f"概念区分：{result['summary']['concept']}处疑似存在概念混淆，注意核心术语的界定")
    
    return result

def check_academic_norm(text: str) -> List[Dict]:
    """学术规范检测"""
    issues = []
    # 检测是否用了第一人称（本科/硕士）
    if re.search(r"^我(觉得|认为|发现|做了)", text, re.MULTILINE):
        issues.append({
            "type": "norm",
            "severity": "warn",
            "issue": "本科/硕士论文应避免第一人称'我'开头",
            "suggestion": "改为'本文''研究表明''数据显示'"
        })
    # 检测长引用无出处
    if "。" in text and text.count("。") > 3:
        if not any(kw in text for kw in ["（", "）", "[", "]", "表明", "指出", "认为", "研究显示"]):
            issues.append({
                "type": "norm",
                "severity": "info",
                "issue": "段落引用较多但未见引用标注",
                "suggestion": "确保引用的观点、数据都有来源标注（作者, 年份）或（文献序号）"
            })
    return issues

# ============ 量化研究辅助函数 ============

def generate_quantitative_guide(level: str = "bachelor") -> Dict:
    """生成问卷法实证研究全程指南"""
    sample_size = {"bachelor": "100-200", "master": "200-500", "phd": "300+"}
    hypotheses = {"bachelor": "2-4个", "master": "4-8个", "phd": "8+个"}
    
    return {
        "success": True,
        "stage": "quantitative",
        "overview": "本指南覆盖问卷法实证研究的全流程，适用于经管/教育/心理/社科类论文",
        "workflow": [
            {"step": 1, "name": "研究设计", "duration": "1-2周", 
             "output": "变量设计 + 假设清单 + 问卷初稿",
             "key_points": [
                 "每个变量必须有操作化定义（如：'服务质量'→5维度22题 Likert量表）",
                 "优先使用成熟量表（来自CSSCI期刊论文方法部分），注明来源",
                 "假设格式：H1-变量X对变量Y有显著正向影响（需理论支撑）",
                 "样本量参考：G*Power软件计算，或经验法则（题项数×10）"
             ]},
            {"step": 2, "name": "预测试", "duration": "1-2周",
             "output": "有效问卷30-50份 + 信效度检验报告",
             "key_points": [
                 "项目分析：删除高分组/低分组得分无差异的题项（区分度检验）",
                 "信度：Cronbach's α ≥ 0.7（越好越好，<0.6必须修改）",
                 "效度：KMO ≥ 0.7，Bartlett球形检验 p<0.05",
                 "探索性因子分析：验证维度结构是否与理论预期一致"
             ]},
            {"step": 3, "name": "正式发放", "duration": "2-4周",
             "output": "有效问卷 N≥目标样本量",
             "key_points": [
                 "发放量 = 目标量×1.2（留20%缓冲，以防无效问卷）",
                 "数据清洗标准：填写时间<60秒/答案全相同/漏答>10% → 剔除",
                 "记录：发放量、回收量、有效量、回收率、有效回收率"
             ]},
            {"step": 4, "name": "数据分析（SPSS）", "duration": "2-3周",
             "output": "统计结果表格 + 假设检验结论",
             "key_points": [
                 "描述性统计：均值、标准差、频次分布",
                 "信效度再检验：正式数据的Cronbach's α和KMO",
                 "相关分析（Pearson）：初步判断变量间关系方向",
                 "回归分析（分层逐步）：控制变量→自变量→中介/调节变量",
                 "中介效应：推荐Bootstrap方法（Hayes PROCESS宏，Model 4）",
                 "报告格式：β系数 + 显著性p值 + R²（解释力）"
             ]},
            {"step": 5, "name": "结果呈现与讨论", "duration": "1-2周",
             "output": "数据结果 + 讨论章节",
             "key_points": [
                 "每张表格/图下方必须有简短分析文字（不是只展示数字）",
                 "讨论：逐条与已有研究对比，解释'为什么支持/不支持假设'",
                 "承认局限：样本局限/方法局限/测量局限（诚实≠没做好）"
             ]}
        ],
        "spss_checklist": [
            {"name": "描述性统计", "path": "分析→描述统计→频率/交叉表", "output": "均值SD/频次分布"},
            {"name": "信度检验", "path": "分析→度量→可靠性分析", "output": "Cronbach's α"},
            {"name": "效度检验", "path": "分析→降维→因子分析", "output": "KMO值 + 因子载荷"},
            {"name": "相关分析", "path": "分析→相关→双变量", "output": "Pearson r + p值"},
            {"name": "回归分析", "path": "分析→回归→线性→逐步", "output": "β + R² + ΔR²"},
            {"name": "中介效应", "path": "分析→回归→PROCESS宏(Model 4)", "output": "间接效应 + Bootstrap CI"},
        ],
        "common_mistakes": [
            {"mistake": "假设没有理论依据", "consequence": "答辩被质疑'假设从哪来'", 
             "fix": "每条假设对应至少1篇文献，明确说'基于XX理论/研究，假设H1...'"},
            {"mistake": "问卷自己编不做预测试", "consequence": "信效度不过关，结果不可信",
             "fix": "正式发放前必须做30人以上预测试，保留信效度数据"},
            {"mistake": "样本量不够硬跑分析", "consequence": "统计功效低，结果不稳定",
             "fix": "用G*Power计算（免费软件，输入效应量、α水平、功效，自动算样本量）"},
            {"mistake": "只报系数不报p值", "consequence": "不知道显著不显著，结论无效",
             "fix": "必须同时报告β值 + p值 + 置信区间"},
            {"mistake": "用逐步法检验中介（老方法）", "consequence": "统计检验力低，结论不稳健",
             "fix": "改用Bootstrap方法（Sobel法已被淘汰）"},
            {"mistake": "表格用SPSS默认样式提交", "consequence": "格式不规范，不美观",
             "fix": "导出数据后在Excel/Word里手动美化（表头加粗、网格线、字号）"},
        ],
        "sample_size_recommendation": sample_size.get(level, "100-200"),
        "hypotheses_recommendation": hypotheses.get(level, "2-4个"),
    }

# ============ 质性研究辅助函数 ============

def generate_qualitative_guide(level: str = "bachelor") -> Dict:
    """生成质性研究全程指南（访谈法/案例研究/扎根理论）"""
    sample_size = {"bachelor": "10-15", "master": "15-30", "phd": "30-50"}
    
    return {
        "success": True,
        "stage": "qualitative",
        "overview": "本指南覆盖质性研究的全流程，适用于教育/心理/社会/管理/传媒等学科中采用访谈、案例研究等方法收集非数值型数据的论文",
        "methods": [
            {
                "name": "半结构化访谈",
                "suitable_for": "了解个人观点/体验/动机",
                "sample_size": sample_size.get(level, "10-15"),
                "key_points": [
                    "设计访谈提纲：开场→暖场→核心问题（开放式为主）→结束",
                    "避免封闭式问题（'你觉得好不好？'）和引导性问题（'你是不是觉得压力很大？'）",
                    "访谈前录音设备就绪+知情同意书+选安静环境",
                    "访谈后24小时内完成转录，标注停顿/笑声等非语言信息",
                ]
            },
            {
                "name": "案例研究",
                "suitable_for": "深入分析特定现象/组织/事件",
                "sample_size": "1-4个案例（多案例对比更有说服力）",
                "key_points": [
                    "采用目的性抽样：选信息丰富的案例（典型案例/极端案例/启示性案例）",
                    "至少两种数据来源实现三角验证（访谈+文档+观察+问卷辅助）",
                    "案例选择需说明理由：不是随机抽，要解释'为什么选这个案例'",
                ]
            },
            {
                "name": "扎根理论",
                "suitable_for": "从数据中自下而上建构理论框架（硕士及以上推荐）",
                "sample_size": sample_size.get(level, "15-20"),
                "key_points": [
                    "三阶段编码：开放编码→主轴编码→选择性编码",
                    "持续比较：不断在新数据和已有编码间比较",
                    "理论抽样：根据分析需要决定下一步访谈谁",
                    "本科慎用，工作量大",
                ]
            }
        ],
        "analysis_method": {
            "name": "主题分析法（Braun & Clarke, 2006）",
            "recommended": True,
            "steps": [
                {"step": 1, "name": "熟悉数据", "description": "反复阅读转录稿，做初步笔记"},
                {"step": 2, "name": "生成初始编码", "description": "逐段标注关键词/短语（如'时间压力''自主性强'）"},
                {"step": 3, "name": "搜索主题", "description": "将相关编码归类到同一主题下"},
                {"step": 4, "name": "审查主题", "description": "检查主题内编码一致性、主题间是否有重叠"},
                {"step": 5, "name": "定义和命名主题", "description": "给每个主题起名字，写清晰定义"},
                {"step": 6, "name": "撰写分析结果", "description": "每个主题用'主题名+定义+引用原文+分析'的结构呈现"},
            ]
        },
        "quality_criteria": [
            {"name": "可信性", "methods": "三角验证（多资料来源）、成员检核（让受访者确认）"},
            {"name": "可转移性", "methods": "厚描述（详细描述研究情境，让读者判断适用性）"},
            {"name": "可靠性", "methods": "保留访谈录音/转录稿/编码记录，可追溯"},
            {"name": "可确认性", "methods": "反思日志、同行审查"},
        ],
        "common_mistakes": [
            {"mistake": "把质性研究写成'观点汇总'", "consequence": "缺乏分析深度，像工作报告",
             "fix": "每个发现都要和理论/文献对话"},
            {"mistake": "引用太少，全是大段分析", "consequence": "读者无法判断分析是否可信",
             "fix": "每200-300字至少1条原文引用"},
            {"mistake": "没有编码过程说明", "consequence": "被质疑'你怎么得出这个结论'",
             "fix": "方法章节写清分析步骤，可附编码示例"},
            {"mistake": "样本选择没有理由", "consequence": "被质疑'这几个人有代表性吗'",
             "fix": "说明目的性抽样策略和选择标准"},
            {"mistake": "忽略反例/矛盾数据", "consequence": "被质疑'你在选择性呈现'",
             "fix": "主动呈现并讨论不一致的发现"},
        ],
        "writing_notes": [
            "方法章节必须写清：研究对象选择标准、访谈/观察过程、数据分析方法、研究伦理",
            "引用格式：'原文内容'（受访者编号-段落号）",
            "每200-300字至少1条原文引用",
            "矛盾/不一致的数据也要呈现并讨论",
            "用表格呈现编码框架/主题结构",
        ],
        "detailed_reference": "references/qualitative-research.md",
    }

# ============ 查重指南函数 ============

def generate_plagiarism_guide() -> Dict:
    """生成查重与AI检测指南"""
    return {
        "success": True,
        "stage": "plagiarism",
        "detection_systems": {
            "知网CNKI": {"target": "国内高校本科/硕士", "note": "最权威，查重标准依据"},
            "万方": {"target": "部分高校备用检测", "note": "数据库与知网有差异"},
            "维普": {"target": "部分高校", "note": "注意今年新增AI检测功能"},
            "格子达/论文狗": {"target": "自查（付费）", "note": "适合初稿自查，不能作为终稿依据"},
            "Turnitin": {"target": "英文论文/中外合办", "note": "含AI检测模块"},
        },
        "standards": {
            "bachelor_below_15": "绝大多数高校合格线，安全区",
            "bachelor_15_25": "可能需要修改，高校允许1-2次修改机会",
            "bachelor_25_40": "必须修改，延迟答辩",
            "master_below_15": "多数高校硕士合格线",
            "master_below_10": "部分高校要求更严格",
            "ai_rate_below_20": "安全区",
            "ai_rate_20_40": "警告区，部分高校要求修改",
            "ai_rate_above_40": "高风险，可能延迟答辩或要求重写",
        },
        "correct_methods": [
            {"method": "句式重构", "example": "原文：'随着电商发展，物流配送成为关键。'\n改写：'物流配送效率已成为电商竞争的核心要素——这一判断基于艾瑞咨询2024年报告数据显示的78%消费者因配送速度改变平台选择的事实。'",
             "effect": "⭐⭐⭐⭐⭐ 最有效"},
            {"method": "增加数据和分析", "example": "原文：'共享经济近年来发展迅速。'\n改写：'国家信息中心数据显示，2023年我国共享经济市场交易规模达3.9万亿元，同比增长9.2%（国家信息中心，2024）。'",
             "effect": "⭐⭐⭐⭐⭐ 最有效，加入具体数据等于重写"},
            {"method": "图表替代文字", "example": "把趋势描述文字→做成折线图/柱状图",
             "effect": "⭐⭐⭐⭐ 图表在查重中通常不计入文字"},
            {"method": "拆解+重组", "example": "一段被标红的内容：①拆成要点②打乱顺序③每个要点用自己的话重写",
             "effect": "⭐⭐⭐⭐ 适合大段重复"},
        ],
        "wrong_methods": [
            {"method": "无脑同义替换", "why": "查重系统看语义，能识别简单的词替换模式"},
            {"method": "文字转图片", "why": "规避查重但导师一眼看出，图片会导致其他部分AI率更高"},
            {"method": "翻译回转法（中→英→中）", "why": "产生中式英语痕迹，语义扭曲，几乎等于没用"},
            {"method": "直接删除标红段落", "why": "可能导致字数不够，或结构缺失"},
        ],
        "ai_reduction_tips": [
            "在AI初稿中插入自己的数据/案例/观点（每300字插一个'人的痕迹'）",
            "用第一人称过渡句（'我在文献阅读时发现……''值得注意的是……'）",
            "保留适度的'不完美'：偶尔的用词变化、句子长度变化是人工写作的特征",
            "重要段落手动重打（不要复制粘贴），语音输入后修改也是好方法",
        ],
        "data_cleaning_example": {
            "发放": 350,
            "回收": 310,
            "回收率": "88.6%",
            "剔除": {"填写时间<60秒": 20, "规律作答": 15, "漏答>10%": 7, "小计": 42},
            "有效": 268,
            "有效回收率": "76.6%"
        },
        "notes": [
            "具体查重/AI率标准以学校当年通知为准，不要用去年的信息套今年",
            "引用自己已发表论文也算重复（自我抄袭），必须规范标注",
            "降重顺序：先降重复率，再降AI率（降重过程中AI率通常会同步下降）",
        ]
    }

# ============ 工具链函数 ============

def generate_toolchain_guide() -> Dict:
    """生成论文写作工具链指南"""
    return {
        "success": True,
        "stage": "toolchain",
        "categories": {
            "literature_management": {
                "name": "文献管理",
                "tools": [
                    {"name": "Zotero（强烈推荐）", "platform": "Win/Mac/Linux", "price": "免费",
                     "features": ["浏览器插件一键抓CNKI论文", "自动识别PDF元数据", "Word插件插入引用", "5GB云同步"],
                     "tutorial": "zotero.org → 下载 → Word插件安装 → Chrome装Zotero Connector → 开始抓论文"},
                    {"name": "EndNote", "platform": "Win/Mac", "price": "学校图书馆通常有授权",
                     "features": ["老牌文献管理工具", "与Word深度集成", "中文支持一般"],
                     "tutorial": "找学校图书馆申请授权账号 → 下载安装 → Word引用工具栏"},
                ],
                "recommendation": "选Zotero，免费+中文友好+持续更新"
            },
            "writing_tools": {
                "name": "写作排版",
                "tools": [
                    {"name": "Microsoft Word + Zotero插件", "platform": "Win/Mac", "price": "学校一般提供正版授权",
                     "best_for": "商科/文科/教育/法学/艺术设计",
                     "tips": ["善用样式窗格统一标题格式", "安装小U办公（部分高校授权）批量处理格式"]},
                    {"name": "LaTeX（Overleaf在线版）", "platform": "浏览器", "price": "免费",
                     "best_for": "理工科/数学/计算机",
                     "tips": ["Overleaf: overleaf.com → 注册 → 上传学校模板 → 开始写", "参考文献用BibTeX格式，在线编译"]},
                ]
            },
            "data_analysis": {
                "name": "数据分析",
                "tools": [
                    {"name": "SPSS", "platform": "Win", "price": "学校实验室版本或付费",
                     "best_for": "经管/教育/心理/社科问卷分析",
                     "analysis": ["描述统计", "信效度检验", "相关分析", "回归分析", "中介/调节效应"]},
                    {"name": "Amos / SmartPLS", "platform": "Win", "price": "付费（学校有授权）",
                     "best_for": "结构方程模型（SEM）",
                     "note": "经管/心理硕士常用，需要一定学习成本"},
                    {"name": "Python (Jupyter)", "platform": "Win/Mac/Linux", "price": "免费",
                     "best_for": "机器学习/数据挖掘/深度学习类论文",
                     "analysis": ["数据处理pandas", "统计分析scipy", "机器学习sklearn", "深度学习pytorch/tensorflow"]},
                    {"name": "R", "platform": "Win/Mac/Linux", "price": "免费",
                     "best_for": "统计建模/计量经济/医学统计",
                     "note": "学习曲线陡，但统计功能最全"},
                ]
            },
            "efficiency": {
                "name": "效率工具",
                "tools": [
                    {"name": "方方格子", "platform": "Excel插件", "price": "部分功能免费",
                     "use_for": "Excel数据批量处理、格式刷、统计函数"},
                    {"name": "ProcessOn", "platform": "在线", "price": "免费基础版",
                     "use_for": "流程图/框架图/概念图（不用装Visio）"},
                    {"name": "AxMath", "platform": "Word插件", "price": "付费",
                     "use_for": "数学公式编辑，比Word自带公式编辑器好用很多"},
                    {"name": "坚果云", "platform": "云同步", "price": "免费试用",
                     "use_for": "Zotero附件同步（配合Zotero用），多人协作文件同步"},
                ]
            }
        },
        "timeline_bachelor": {
            "description": "示例时间线（5月答辩）",
            "phases": [
                {"month": "10-11月", "task": "选题 + 开题报告", "output": "开题报告定稿"},
                {"month": "11-12月", "task": "文献综述", "output": "文献综述初稿"},
                {"month": "12-1月", "task": "数据/资料收集", "output": "数据收集完成"},
                {"month": "1-2月", "task": "正文写作（最密集）", "output": "第3-4章初稿"},
                {"month": "2-3月", "task": "完善 + 导师反馈修改", "output": "全文修改2-3轮"},
                {"month": "3-4月", "task": "格式 + 查重降重", "output": "终稿排版完成"},
                {"month": "4-5月", "task": "答辩准备", "output": "PPT + 自述稿 + 正式答辩"},
            ]
        },
        "timeline_master": {
            "description": "示例时间线（12月答辩）",
            "phases": [
                {"month": "1-3月", "task": "深度文献综述", "output": "2万字以上文献综述"},
                {"month": "4-6月", "task": "研究设计 + 预测试", "output": "问卷定稿 + 预测试信效度"},
                {"month": "7-9月", "task": "正式数据收集", "output": "有效问卷 N≥目标"},
                {"month": "9-11月", "task": "数据分析 + 论文写作", "output": "各章节写作"},
                {"month": "11月", "task": "初稿 + 导师反馈修改", "output": "全文修改"},
                {"month": "12月", "task": "定稿 + 查重 + 答辩", "output": "通过答辩"},
            ]
        },
        "common_traps": [
            {"trap": "等看完所有文献再开始写", "fix": "边读边写卡片笔记，每读一篇写300字，读文献时间不超过论文总时间的1/3"},
            {"trap": "开题拖太久导致后面时间不够", "fix": "强制设定开题截止日，过了就强制进入写作阶段"},
            {"trap": "用Word默认格式提交", "fix": "下载学校官方模板，严格按模板排版"},
            {"trap": "只写不说，忽视口头表达", "fix": "答辩前至少模拟演练3次，计时，控制语速"},
        ]
    }

# ============ 主函数 ============

def main():
    parser = argparse.ArgumentParser(description="thesis-tutor 论文导师工具 v3.4")
    parser.add_argument("--stage", "-s", required=True,
                       choices=["topic", "proposal", "outline", "chapter", "check",
                               "defense", "literature", "export", "quantitative",
                               "qualitative", "plagiarism", "toolchain"],
                       help="阶段名称")
    parser.add_argument("--major", "-m", default="", help="专业方向")
    parser.add_argument("--title", "-t", default="", help="论文题目")
    parser.add_argument("--level", "-l", default="bachelor", choices=["bachelor", "master", "phd"],
                       help="学位级别")
    parser.add_argument("--discipline", "-d", default="", help="学科代码(cs/biz/lit/edu等)")
    parser.add_argument("--text", "-x", default="", help="要分析的文本内容")
    parser.add_argument("--file", "-f", default="", help="要分析的文件路径")
    parser.add_argument("--quick", "-q", action="store_true", help="快速模式")
    parser.add_argument("--output", "-o", default="", help="输出文件路径")
    parser.add_argument("--quiet", action="store_true", help="安静模式（只输出JSON）")
    
    args = parser.parse_args()
    
    result = {"success": True, "stage": args.stage}
    
    # 读取文件内容
    text_content = args.text
    if args.file and os.path.exists(args.file):
        with open(args.file, 'r', encoding='utf-8') as f:
            text_content = f.read()
    
    # ================== 阶段处理 ==================
    
    if args.stage == "topic":
        if not args.major:
            result["success"] = False
            result["error"] = "选题阶段需要指定专业方向 (--major)"
        else:
            topics = generate_topics(args.major, args.level, 5 if not args.quick else 3)
            result["major"] = args.major
            result["level"] = args.level
            result["topics"] = topics
            result["next_step"] = "选择感兴趣的题目，进入开题报告阶段"
    
    elif args.stage == "outline":
        if not args.title:
            result["success"] = False
            result["error"] = "大纲阶段需要指定论文题目 (--title)"
        else:
            discipline = args.discipline or detect_discipline(args.major or "")
            outline = generate_outline(args.title, discipline, args.level)
            result["title"] = args.title
            result["outline"] = outline
            result["next_step"] = "确认大纲结构后，可以逐章开始写作"
    
    elif args.stage == "chapter":
        if not text_content:
            result["success"] = False
            result["error"] = "逐章辅导需要提供文本内容 (--text 或 --file)"
        else:
            analysis = analyze_paragraph_v3(text_content)
            result.update(analysis)
            result["next_step"] = "按批注修改后继续下一章，或进入自检阶段"
    
    elif args.stage == "check":
        checklist = generate_checklist("all")
        result["checks"] = [
            {"category": "format", "name": "格式检查", "items": checklist["format"]},
            {"category": "citation", "name": "引用检查", "items": checklist["citation"]},
            {"category": "logic", "name": "逻辑检查", "items": checklist["logic"]},
            {"category": "common", "name": "常见硬伤", "items": checklist["common"]}
        ]
        result["total_items"] = sum(len(v) for v in checklist.values())
        result["next_step"] = "逐项检查完成后，可以导出最终文档"
    
    elif args.stage == "proposal":
        result["sections"] = [
            {"title": "研究背景与意义", "content": "交代问题来源和重要性", "tips": "从宏观到微观，说明为什么要研究这个问题"},
            {"title": "国内外研究现状", "content": "按观点分类综述，指出研究空白", "tips": "按时间或观点分类，最后指出研究缺口"},
            {"title": "研究目标与内容", "content": "明确要解决什么问题", "tips": "目标要具体可衡量，内容要对应目标"},
            {"title": "研究方法与技术路线", "content": "说明用什么方法、怎么做", "tips": "方法要与研究问题匹配，技术路线可用流程图"},
            {"title": "预期成果与创新点", "content": "预计产出什么、新在哪里", "tips": "创新点要具体，避免空泛的'首次研究'"},
            {"title": "研究计划与时间安排", "content": "分阶段的时间规划", "tips": "按月份或季度划分，预留修改时间"}
        ]
        result["next_step"] = "完成开题报告后，可以细化成完整大纲"
    
    elif args.stage == "defense":
        ppt_pages = [
            {"page": 1, "title": "封面", "time": "0:00", "content": "题目+姓名+导师+学校"},
            {"page": 2, "title": "研究背景", "time": "1:30", "content": "具体问题/现象切入，不要从'随着XXX发展'说起"},
            {"page": 3, "title": "研究目的与意义", "time": "1:00", "content": "现有研究缺什么，本文补什么"},
            {"page": 4, "title": "研究方法", "time": "1:30", "content": "方法选择理由，数据来源，样本描述"},
            {"page": 5, "title": "研究结果", "time": "2:30", "content": "核心发现，用图/表呈现"},
            {"page": 6, "title": "结论与展望", "time": "1:00", "content": "3点以内，不要超过3点"},
            {"page": 7, "title": "致谢", "time": "0:30", "content": "简短"},
        ]
        result["ppt_framework"] = ppt_pages
        result["total_minutes"] = {"bachelor": "5-8分钟", "master": "10-15分钟", "phd": "20-30分钟"}.get(args.level, "5-8分钟")
        result["self_intro_template"] = {
            "opening": "各位老师好，我是XXX，专业是XXX。我的论文题目是《XXX》，接下来我将从研究背景、研究方法、研究结果三个方面进行汇报。",
            "background": "随着XXX问题的日益突出，现有研究在XXX方面存在不足。因此，本文旨在...",
            "method": "为了解决上述问题，本文采用了XXX方法，以XXX为研究对象，通过XXX方式收集数据...",
            "result": "本文的主要发现有以下三点：第一，...；第二，...；第三，...",
            "closing": "本文的研究结论对XXX有以下启示。本文也存在以下局限，下来后会继续研究。感谢各位老师的聆听，请各位老师批评指正。",
        }
        result["common_questions"] = [
            {"type": "方法质疑", "example": "你的样本量够吗？为什么用这个方法？", "strategy": "说清楚选择理由+承认局限性"},
            {"type": "概念不清", "example": "你这个'XXX'是怎么定义的？", "strategy": "用论文原文回答，不要临时发挥"},
            {"type": "数据来源", "example": "数据从哪来的？", "strategy": "具体数字+抽样方式"},
            {"type": "结论夸大", "example": "你说效果显著，具体怎么证明？", "strategy": "用数据说话，不要用'很明显''非常好'"},
            {"type": "创新性", "example": "你的研究和已有的XX研究有什么不同？", "strategy": "提前准备，1-2句话说清楚"},
        ]
        result["next_step"] = "根据框架准备自述稿，熟悉论文全文，预判可能被追问的内容"
    
    elif args.stage == "literature":
        result["literature_review"] = {
            "wrong_patterns": [
                "教科书式：把概念定义抄一遍，不是文献综述",
                "流水账式：'张三(2018)研究了...李四(2019)研究了...'，没有分析和综合",
                "以多为好：列出50篇但没有分类，导师问'你的综述有什么观点'答不上来",
            ],
            "classification_methods": {
                "cs": "按技术路线分类（算法/模型路线），结尾说明方法演进趋势",
                "biz": "按变量关系分类（X对Y的影响），重点梳理假设发展脉络",
                "law": "按学术观点/学派分类，注意司法实践的补充",
                "edu": "按研究设计类型分类（量化/质性/混合），注意政策文本补充",
                "literature": "按时间/流派/主题分类",
            },
            "structure": {
                "step1": "筛选文献：近5年+核心期刊+外文补充，整理到Excel",
                "step2": "分类框架：按技术/观点/变量关系分类，每类末尾加评述",
                "step3": "述评写法：现有研究在XXX方面有缺口①，YYY方面有缺口②",
                "step4": "衔接本文：从缺口过渡到本文研究目标，说明本文的边际贡献",
            },
            "quantities": {
                "bachelor": "中文15-30篇 + 英文5-10篇",
                "master": "中文30-50篇 + 英文10-20篇",
                "phd": "中文50篇以上 + 英文20篇以上",
            },
        }
        result["next_step"] = "按上述步骤整理文献，建立分类框架，然后进入逐章写作"
    
    elif args.stage == "export":
        result["message"] = "请使用 scripts/export_docx.py 生成Word文档"
        result["command"] = f"python scripts/export_docx.py --title '{args.title}' --level {args.level}"
    
    # ========== v3.1 新增阶段 ==========
    
    elif args.stage == "quantitative":
        guide = generate_quantitative_guide(args.level)
        result.update(guide)
        result["next_step"] = "按流程推进：研究设计→预测试→正式发放→数据分析→结果讨论"
    
    elif args.stage == "qualitative":
        guide = generate_qualitative_guide(args.level)
        result.update(guide)
        result["next_step"] = "选择研究方法（访谈/案例研究/扎根理论），设计研究方案"
    
    elif args.stage == "plagiarism":
        guide = generate_plagiarism_guide()
        result.update(guide)
        result["next_step"] = "查重前自查：先用格子达等工具测初稿，降重后再用学校指定系统测终稿"
    
    elif args.stage == "toolchain":
        guide = generate_toolchain_guide()
        result.update(guide)
        result["next_step"] = "工具选好后，按时间规划推进，关键路径：文献综述→数据→写作→查重→答辩"
    
    # ================== 输出 ==================
    
    if args.quiet or args.output:
        output_json = json.dumps(result, ensure_ascii=False, indent=2)
        if args.output:
            with open(args.output, 'w', encoding='utf-8') as f:
                f.write(output_json)
            print(f"结果已保存至: {args.output}")
        else:
            print(output_json)
    else:
        # 友好输出
        print(f"\n{'='*60}")
        print(f"🎓 thesis-tutor 论文导师 v3.4")
        print(f"{'='*60}")
        print(f"\n阶段: {args.stage}")
        
        if not result.get("success", True):
            print(f"\n❌ 错误: {result.get('error', '未知错误')}")
        elif args.stage == "topic":
            print(f"\n📚 专业: {args.major} ({args.level})")
            print(f"\n💡 候选题目:")
            for topic in result.get("topics", []):
                diff_emoji = {"低": "🟢", "中": "🟡", "高": "🔴"}
                print(f"\n  {topic['id']}: {topic['example']}")
                print(f"     难度: {diff_emoji.get(topic['difficulty'], '⚪')} {topic['difficulty']} | "
                      f"创新: {diff_emoji.get(topic['innovation'], '⚪')} {topic['innovation']} | "
                      f"资料: {diff_emoji.get(topic['resource'], '⚪')} {topic['resource']}")
                print(f"     说明: {topic['reason']}")
        
        elif args.stage == "outline":
            outline = result.get("outline", {})
            print(f"\n📝 题目: {outline.get('title', '')}")
            print(f"📊 学科: {outline.get('discipline', '')}")
            print(f"📏 预估字数: {outline.get('total_words', '')}")
            print(f"\n📋 大纲结构:")
            for ch in outline.get("chapters", []):
                print(f"\n  {ch['chapter']} ({ch['words']}字)")
                for sec in ch["sections"]:
                    print(f"    - {sec}")
        
        elif args.stage == "chapter":
            print(f"\n📄 文本分析结果")
            print(f"段落数: {result.get('total_paragraphs', 0)} | "
                  f"口语化: {result.get('summary', {}).get('expression', 0)}处 | "
                  f"逻辑: {result.get('summary', {}).get('logic', 0)}处 | "
                  f"论证: {result.get('summary', {}).get('argument', 0)}处")
            print(f"综合评分: {result.get('overall_score', 10)}/10 | {result.get('overall_grade', '')}")
            
            for p in result.get("paragraphs_analyzed", []):
                if p["issues"]:
                    print(f"\n  📌 第{p['index']}段: {p['text_preview']}")
                    for issue in p["issues"]:
                        sev = {"error": "❌", "warn": "⚠️", "info": "💡"}.get(issue.get("severity", ""), "•")
                        print(f"     {sev} [{issue['type']}] {issue.get('issue', '')}")
                        if "suggestion" in issue:
                            print(f"        → {issue['suggestion']}")
            
            if result.get("top_issues"):
                print(f"\n  ⚠️ 最需关注的问题:")
                for i in result["top_issues"]:
                    print(f"     [{i['type']}] {i['issue']}")
            
            for s in result.get("suggestions", []):
                print(f"\n  💡 {s}")
        
        elif args.stage == "check":
            print(f"\n✅ 自检清单 (共{result.get('total_items', 0)}项):")
            for category, items in result.get("checks", {}).items() if "checks" in result else result.get("checks", {}).items():
                cat_emoji = {"format": "📐", "citation": "📚", "logic": "🔍", "common": "⚠️"}
                print(f"\n  {cat_emoji.get(category, '📝')} {category.upper()}")
                for item in (items.get("items") if isinstance(items, dict) else items):
                    print(f"    [ ] {item}")

        elif args.stage == "defense":
            print(f"\n📊 答辩参考时长: {result.get('total_minutes', '')}")
            print(f"\n📋 PPT框架 ({len(result.get('ppt_framework', []))}页):")
            for p in result.get("ppt_framework", []):
                print(f"  第{p['page']}页 {p['title']} [{p['time']}]: {p['content']}")
            print(f"\n❓ 常见问题预判:")
            for q in result.get("common_questions", []):
                print(f"  [{q['type']}] {q['example']}")
                print(f"    → {q['strategy']}")

        elif args.stage == "literature":
            print(f"\n📚 文献综述专项")
            print(f"\n❌ 常见错误:")
            for w in result.get("literature_review", {}).get("wrong_patterns", []):
                print(f"  • {w}")
            print(f"\n📋 写作步骤:")
            for k, v in result.get("literature_review", {}).get("structure", {}).items():
                print(f"  {k}. {v}")
            print(f"\n📊 文献数量参考:")
            for level, q in result.get("literature_review", {}).get("quantities", {}).items():
                print(f"  {level}: {q}")
        
        elif args.stage == "quantitative":
            print(f"\n📊 量化研究指南（问卷法）")
            print(f"\n📋 工作流程:")
            for step in result.get("workflow", []):
                print(f"\n  步骤{step['step']}: {step['name']}（预计{step['duration']}）")
                print(f"  产出: {step['output']}")
                for pt in step.get("key_points", []):
                    print(f"    • {pt}")
            print(f"\n🔧 SPSS操作清单:")
            for item in result.get("spss_checklist", []):
                print(f"  {item['name']}: {item['path']}")
            print(f"\n⚠️ 常见错误:")
            for m in result.get("common_mistakes", []):
                print(f"  ❌ {m['mistake']}")
                print(f"     → {m['fix']}")
        
        elif args.stage == "qualitative":
            print(f"\n📋 质性研究指南")
            print(f"\n🔍 三种核心方法:")
            for method in result.get("methods", []):
                print(f"\n  📌 {method['name']}")
                print(f"     适用: {method['suitable_for']}")
                print(f"     样本量参考: {method['sample_size']}")
                for pt in method.get("key_points", []):
                    print(f"     • {pt}")
            print(f"\n📊 推荐分析方法: {result.get('analysis_method', {}).get('name', '')}")
            for step in result.get("analysis_method", {}).get("steps", []):
                print(f"  {step['step']}. {step['name']}: {step['description']}")
            print(f"\n✅ 质量保障四维度:")
            for criterion in result.get("quality_criteria", []):
                print(f"  • {criterion['name']}: {criterion['methods']}")
            print(f"\n⚠️ 常见错误:")
            for m in result.get("common_mistakes", []):
                print(f"  ❌ {m['mistake']}")
                print(f"     → {m['fix']}")
        
        elif args.stage == "plagiarism":
            print(f"\n🔍 查重与AI检测指南")
            print(f"\n📊 各系统检测能力:")
            for sys_name, info in result.get("detection_systems", {}).items():
                print(f"  {sys_name}: {info['target']} ({info['note']})")
            print(f"\n✅ 正确降重方法:")
            for m in result.get("correct_methods", []):
                print(f"  [{m['effect']}] {m['method']}")
            print(f"\n❌ 错误降重方法:")
            for m in result.get("wrong_methods", []):
                print(f"  ✗ {m['method']}: {m['why']}")
        
        elif args.stage == "toolchain":
            print(f"\n🛠️ 论文写作工具链")
            for cat_key, cat_info in result.get("categories", {}).items():
                print(f"\n📂 {cat_info['name']}:")
                for tool in cat_info.get("tools", []):
                    print(f"  • {tool['name']} ({tool.get('platform', '')}) - {tool.get('price', '')}")
                    if "best_for" in tool:
                        print(f"    适合: {tool['best_for']}")
                    if "features" in tool:
                        for f in tool["features"]:
                            print(f"    ✓ {f}")
                    if "tips" in tool:
                        for t in tool["tips"]:
                            print(f"    ✓ {t}")
        
        if "next_step" in result:
            print(f"\n➡️  下一步: {result['next_step']}")
        
        print(f"\n{'='*60}\n")
    
    return 0 if result.get("success", True) else 1

if __name__ == "__main__":
    sys.exit(main())
