#!/usr/bin/env python3
"""Sync index.html category data from categories.json.

Run from any directory:
    python scripts/build_index.py

The script keeps categories.json as the single source of truth and replaces only
the inline `const CATEGORIES` block in index.html. It does not modify UI events,
styles, or rendering logic.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CATEGORIES_PATH = ROOT / "categories.json"
INDEX_PATH = ROOT / "index.html"


def load_categories() -> dict:
    with CATEGORIES_PATH.open("r", encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, dict) or not data:
        raise ValueError("categories.json must be a non-empty object")
    for l1, l2s in data.items():
        if not isinstance(l1, str) or not isinstance(l2s, list):
            raise ValueError(f"Invalid category group: {l1!r}")
        for item in l2s:
            if not isinstance(item, dict):
                raise ValueError(f"Invalid category item under {l1!r}: {item!r}")
            for key in ("name", "code", "l3"):
                if key not in item:
                    raise ValueError(f"Missing key {key!r} in category item under {l1!r}")
            if not isinstance(item["l3"], list):
                raise ValueError(f"l3 must be a list for {l1!r}/{item.get('name')!r}")
    return data


def json_for_script(data: dict) -> str:
    """Serialize JSON safely for embedding inside an inline script block."""
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return raw.replace("</", "<\\/")


def sync_index(categories: dict) -> None:
    html = INDEX_PATH.read_text(encoding="utf-8")
    category_json = json_for_script(categories)
    replacement = (
        "// Generated from categories.json by scripts/build_index.py; do not edit this block manually.\n"
        f"const CATEGORIES = {category_json};\n\nconst CASES ="
    )
    html, count = re.subn(
        r"(?:\/\/ Generated from categories\.json by scripts\/build_index\.py; do not edit this block manually\.\n)?const CATEGORIES = .*?;\n\nconst CASES =",
        replacement,
        html,
        count=1,
        flags=re.S,
    )
    if count != 1:
        raise RuntimeError("Failed to locate exactly one const CATEGORIES block")
    INDEX_PATH.write_text(html, encoding="utf-8", newline="\n")


def main() -> None:
    categories = load_categories()
    sync_index(categories)
    l1_count = len(categories)
    l2_count = sum(len(v) for v in categories.values())
    l3_count = sum(len(item.get("l3", [])) for items in categories.values() for item in items)
    print(f"Synced index.html from categories.json: l1={l1_count}, l2={l2_count}, l3={l3_count}")


if __name__ == "__main__":
    main()
