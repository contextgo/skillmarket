// ═══════════════════════════════════════════════════════════════
// 贴图号运营方案生成器 - 共享生成引擎 v20260506
// 同时支持浏览器（index.html）和 Node.js（cli.js）
// ═══════════════════════════════════════════════════════════════

(function (root, factory) {
  if (typeof module !== "undefined" && module.exports) {
    // Node.js
    module.exports = factory();
  } else {
    // Browser - 挂载到全局
    var exports = factory();
    for (var key in exports) {
      if (exports.hasOwnProperty(key)) {
        root[key] = exports[key];
      }
    }
  }
})(typeof globalThis !== "undefined" ? globalThis : typeof window !== "undefined" ? window : this, function () {

// ─── 赛道与目的选项 ─────────────────────────
var TRACKS = ["餐饮", "酒旅", "零售", "丽人", "家政", "婚摄", "教培", "医美"];
var PURPOSES = ["商品下单", "线索收集", "种草曝光"];

// ─── 赛道策略矩阵 ─────────────────────────
var TRACK_STRATEGY = {
  "餐饮": {
    content_type: "种草型", content_type_alt: "攻略型",
    title_formulas: ["数字锚点法", "地域限定法"],
    style: "暖色调美食摄影，突出食物色泽，带蒸汽/油光/拉丝效果",
    topic_tags: ["#[城市]美食", "#[品类]推荐", "#探店"],
    publish_times: ["11:00-12:00", "17:00-18:00"],
    publish_reason: "饭点前1小时，用户在想吃什么",
    cta: "点击下方位置直达门店👇",
    kpi: {"POI点击率": "> 5%", "互动率": "> 3%"},
    hot_data: "某咖啡品牌ROI 60+，某茶饮品牌ROI 5+",
    explosion_variant: "美女在门店门口+手持招牌菜",
    product_focus: "菜品详细测评+价格+套餐",
  },
  "酒旅": {
    content_type: "攻略型", content_type_alt: "种草型",
    title_formulas: ["地域限定法", "FOMO紧迫法"],
    style: "冷色调/自然色旅行摄影，大场景+人文细节",
    topic_tags: ["#[目的地]旅行", "#旅行攻略", "#周末去哪玩"],
    publish_times: ["20:00-22:00"],
    publish_reason: "晚间规划出行时间",
    cta: "点击位置查看详情/预订👇",
    kpi: {"收藏率": "> 3%", "POI点击率": "> 8%为优秀"},
    hot_data: "周末/节假日前发布效果最佳",
    explosion_variant: "美女在景区门口+旅游穿搭",
    product_focus: "行程攻略+费用明细+预订",
  },
  "零售": {
    content_type: "测评型", content_type_alt: "种草型",
    title_formulas: ["对比冲突法", "FOMO紧迫法"],
    style: "明亮干净产品摄影，白底/浅色底，价格标签醒目",
    topic_tags: ["#[品牌]", "#[品类]", "#好物推荐", "#省钱攻略"],
    publish_times: ["10:00-11:00", "20:00-21:00"],
    publish_reason: "上午浏览+晚间购物",
    cta: "点击位置立享优惠👇",
    kpi: {"分享率": "> 1.5%", "POI点击率": "> 3%"},
    hot_data: "折扣季+节日营销效果倍增",
    explosion_variant: "美女在门店门口+展示产品",
    product_focus: "产品对比+折扣+购买攻略",
  },
  "丽人": {
    content_type: "种草型", content_type_alt: "故事型",
    title_formulas: ["痛点共鸣法", "对比冲突法"],
    style: "精致人像+环境，柔和光线，Before/After对比",
    topic_tags: ["#[城市]美容", "#护肤日常", "#变美日记"],
    publish_times: ["20:00-22:00"],
    publish_reason: "晚间护肤/变美话题",
    cta: "点击位置预约体验👇",
    kpi: {"POI点击率": "> 5%", "留资率": "> 8%"},
    hot_data: "Before/After视觉冲击型内容效果好",
    explosion_variant: "美女在门店门口+效果展示",
    product_focus: "项目详细介绍+效果对比",
  },
  "家政": {
    content_type: "攻略型", content_type_alt: "测评型",
    title_formulas: ["痛点共鸣法", "数字锚点法"],
    style: "真实场景Before/After，干净明亮的成果展示",
    topic_tags: ["#[城市]家政", "#保洁攻略", "#生活小妙招"],
    publish_times: ["10:00-11:00", "19:00-20:00"],
    publish_reason: "白天预约+晚间规划",
    cta: "点击位置免费预约👇",
    kpi: {"POI点击率": "> 3%", "留资率": "> 10%"},
    hot_data: "真实场景对比型内容转化高",
    explosion_variant: "美女在整洁家居场景",
    product_focus: "服务流程+价格+预约",
  },
  "婚摄": {
    content_type: "故事型", content_type_alt: "种草型",
    title_formulas: ["地域限定法", "FOMO紧迫法"],
    style: "精致婚纱/写真作品，浪漫柔光，场地+人物",
    topic_tags: ["#[城市]婚纱照", "#婚礼纪实", "#备婚日记"],
    publish_times: ["20:00-22:00"],
    publish_reason: "晚间情感/规划时间",
    cta: "点击位置查看客片/预约👇",
    kpi: {"收藏率": "> 5%", "POI点击率": "> 4%"},
    hot_data: "客片展示+情感故事型效果好",
    explosion_variant: "新人+闺蜜在拍摄场景",
    product_focus: "套餐对比+客片展示",
  },
  "教培": {
    content_type: "攻略型", content_type_alt: "种草型",
    title_formulas: ["数字锚点法", "痛点共鸣法"],
    style: "学习场景实拍，师生互动，成果展示",
    topic_tags: ["#[城市]培训", "#[技能]学习", "#自我提升"],
    publish_times: ["10:00-11:00", "20:00-21:00"],
    publish_reason: "白天咨询+晚间学习",
    cta: "点击位置免费试听👇",
    kpi: {"POI点击率": "> 3%", "留资率": "> 10%"},
    hot_data: "效果对比+免费试听钩子效果好",
    explosion_variant: "美女学员在教室场景",
    product_focus: "课程详情+效果+试听",
  },
  "医美": {
    content_type: "故事型", content_type_alt: "测评型",
    title_formulas: ["痛点共鸣法", "对比冲突法"],
    style: "精致环境+专业设备，Before/After对比",
    topic_tags: ["#[城市]医美", "#皮肤管理", "#变美记录"],
    publish_times: ["20:00-22:00"],
    publish_reason: "晚间关注变美",
    cta: "点击位置免费咨询👇",
    kpi: {"POI点击率": "> 4%", "留资率": "> 12%"},
    hot_data: "需注意合规，用'改善'替代'治愈'",
    explosion_variant: "美女在机构门口（注意合规）",
    product_focus: "项目介绍+专业背书+咨询",
    compliance_note: "医美内容需合规，避免过度宣传疗效，使用'改善'替代'治愈'",
  },
};

// ─── 营销目的策略 ─────────────────────────
var PURPOSE_STRATEGY = {
  "商品下单": {
    core: "价格锚点制造 → 限时紧迫感 → POI一键下单",
    content_priority: "测评型 > 种草型 > 攻略型",
    cta_keyword: "立即下单/限时抢购",
    title_formulas: ["FOMO紧迫法", "数字锚点法", "对比冲突法"],
    conversion_path: "贴图→POI→小程序下单页",
    mini_program_tip: "直接跳转商品详情页，简化下单流程（1-2步完成）",
    body_template: "hook_price",
    image_strategy: "首图：商品+价格标注（原价划掉+活动价醒目）；内图：商品细节/使用场景/对比图；尾图：活动信息总结+POI引导+倒计时",
  },
  "线索收集": {
    core: "痛点共鸣 → 免费钩子 → 预约/留资入口",
    content_priority: "故事型 > 攻略型 > 种草型",
    cta_keyword: "免费预约/0元体验",
    title_formulas: ["痛点共鸣法", "数字锚点法", "地域限定法"],
    conversion_path: "贴图→POI→小程序预约/表单页",
    mini_program_tip: "跳转预约/表单页面，表单字段精简（姓名+电话即可），突出'免费''0元'",
    body_template: "hook_pain",
    image_strategy: "首图：Before/After对比 OR 真人体验+门头；内图：环境/设备/服务过程/效果展示；尾图：免费体验信息+预约引导+信任背书",
  },
  "种草曝光": {
    core: "视觉冲击 → 真实体验 → 社交传播",
    content_priority: "种草型 > 故事型 > 攻略型",
    cta_keyword: "点击看看/离你多近",
    title_formulas: ["地域限定法", "痛点共鸣法", "数字锚点法"],
    conversion_path: "贴图→POI→门店详情页",
    mini_program_tip: "跳转门店详情页（展示更多内容/评价），可嵌入official-account-publish组件引导用户UGC",
    body_template: "hook_visual",
    image_strategy: "首图：真人+门头+视觉冲击（10w+爆款公式）；内图：真实体验场景/产品细节/环境氛围；尾图：总结+POI引导",
  },
};

// ─── 5种固化爆款首图模板（100%必出，每次生成全部给出） ─────────────────────────
// 来源：贴图号平台实测爆文拆解，这5种视觉模式反复验证高点击
var COVER_TEMPLATES = [
  {
    id: "yoga_girls",
    name: "① 瑜伽裤·大长腿·多美女门头",
    why: "平台实测10w+爆文核心公式：黑色瑜伽裤+大长腿+2-3位美女+门头招牌，视觉冲击力最强，复制率最高",
    prompt: "生活方式摄影，2-3位身材高挑的中国年轻女性，穿着黑色紧身瑜伽裤配{outfit_top}，大长腿充分展示占画面主体，站在{merchant}门店入口处，{track_action}，门头招牌清晰可见，{holding}，自信微笑，腿长动态站姿，{lighting}，浅景深虚化背景，顶部留白用于文字叠加，底部留白用于POI标签，专业生活方式摄影，8K超高清，9:16竖版构图",
    checklist: ["2-3位美女真人组合？", "黑色瑜伽裤+大长腿明显？", "门店门头招牌清晰可见？", "自信笑容+动态姿势？"],
  },
  {
    id: "dining_group",
    name: "② 多美女聚餐合影·闺蜜场景",
    why: "闺蜜聚餐/合影社交属性极强，用户天然想评论'好羡慕/你们在哪'，互动率比单人图高2-3倍",
    prompt: "真实生活摄影，3-4位身材高挑的中国年轻女性，穿着时尚精致服装，{dining_scene}，开心聚餐合影微笑，桌上摆着{scene_items}，大长腿自然展露，举杯或手持食物/饮品欢笑，闺蜜聚会欢乐氛围，{lighting}，暖色调，顶部留白用于文字叠加，专业摄影，8K超高清，9:16竖版构图",
    checklist: ["3-4位美女闺蜜组合？", "聚餐/聚会场景感强？", "大长腿自然展露？", "笑容真实欢快？"],
  },
  {
    id: "luxury_car",
    name: "③ 豪车下来·高跟鞋弯腰整裙",
    why: "豪车+美女+门店制造强烈品质感：'来这里的都是有品位的人'，强转发动力，适合中高端定位",
    prompt: "时尚摄影，一位身材高挑的中国年轻女性，穿着{dress_style}，脚踩细高跟鞋，正从停在{merchant}门店正门前的黑色豪华轿车旁下车，微微弯腰整理裙摆/捋发丝，大长腿和高跟鞋特写明显，{merchant}门头招牌清晰可见，{lighting}，浅景深，奢华时尚质感，顶部留白用于文字叠加，底部留白用于POI标签，专业时尚摄影，8K超高清，9:16竖版构图",
    checklist: ["豪车可见（侧面或局部）？", "高跟鞋+大长腿特写？", "弯腰/整理裙摆动作？", "门店门头清晰可见？"],
  },
  {
    id: "restroom_selfie",
    name: "④ 洗手间镜前·半遮面手机自拍",
    why: "半遮面制造神秘感和强烈悬念，洗手间镜前自拍是当前贴图号互动率最高视觉格式之一，评论区'在哪家'必刷屏",
    prompt: "第一人称镜前摄影，一位中国年轻女性在{merchant}{restroom_type}洗手间，手持手机对着镜子自拍，单手遮住半张脸只露出精致眼妆和眉毛，眼神深邃撩人，嘴角微微上扬，镜中反射可见洗手间{restroom_decor}，妆容精致发型完美，镜像叠影层次感，{lighting}，网红打卡高级感，顶部留白用于文字叠加，专业摄影，8K超高清，9:16竖版构图",
    checklist: ["单手半遮面只露眼？", "手持手机镜前自拍姿势？", "洗手间精致装修镜中可见？", "眼神有吸引力？"],
  },
  {
    id: "street_legs",
    name: "⑤ 门店外街拍·大长腿时尚穿搭",
    why: "门店外街拍自然轻松，腿长比例突出，时尚感强，拍摄最简单易复制，适配所有赛道批量生产",
    prompt: "时尚街拍摄影，一位身材高挑腿长的中国年轻女性，穿着{street_outfit}，站在{merchant}门店外，{street_pose}，腿部修长占画面比例超过60%，{merchant}品牌招牌/门头元素清晰可见，{lighting}，浅景深，时尚街拍质感，顶部留白用于文字叠加，底部留白用于POI标签，专业时尚街拍，8K超高清，9:16竖版构图",
    checklist: ["大长腿占画面主体（>60%）？", "街拍自然感（非摆拍感）？", "门店品牌/招牌元素可见？", "穿搭时尚度够？"],
  },
];

// ─── 赛道对应的5种首图模板变量（中文） ─────────────────────────
var COVER_TRACK_VARS = {
  "餐饮": {
    outfit_top: "修身运动上衣",
    track_action: "看菜单相互推荐/聊天欢笑",
    holding: "手持招牌菜品或特色饮品",
    lighting: "温暖午后自然光线",
    dining_scene: "围坐在精致餐厅餐桌旁",
    scene_items: "色彩鲜艳的菜肴和特色饮品",
    dress_style: "高档连衣裙或精致晚装",
    restroom_type: "网红餐厅",
    restroom_decor: "大理石台面/精致镜前灯/鲜花装饰",
    street_outfit: "修身连衣裙或时尚休闲套装",
    street_pose: "回眸微笑或整理发丝",
  },
  "酒旅": {
    outfit_top: "轻薄运动上衣或度假风衬衫",
    track_action: "指向远处景点/相谈甚欢",
    holding: "手持墨镜或旅行帽配件",
    lighting: "金色黄昏暖阳光线",
    dining_scene: "坐在酒店大堂休息区或景区特色餐厅旁",
    scene_items: "特色美食、旅行地图和当地饮品",
    dress_style: "度假风长裙或精致旅行装",
    restroom_type: "精品酒店",
    restroom_decor: "奢华大理石洗手台/精致摆件/暖金灯光",
    street_outfit: "度假风长裙或时尚旅行穿搭",
    street_pose: "眺望远景或举手遮阳",
  },
  "零售": {
    outfit_top: "时尚运动上衣或休闲上衣",
    track_action: "看橱窗/品评商品相互讨论",
    holding: "手持展示门店热销商品",
    lighting: "明亮商场自然灯光",
    dining_scene: "坐在商场咖啡区或品牌休息区",
    scene_items: "精致购物袋和特色饮品",
    dress_style: "时尚休闲装或精致正装",
    restroom_type: "高档商场",
    restroom_decor: "白色大理石/品牌标识元素/柔和灯光",
    street_outfit: "时尚休闲穿搭或OL风格",
    street_pose: "手提购物袋或展示商品",
  },
  "丽人": {
    outfit_top: "优雅修身上衣",
    track_action: "互相检查对方妆容/聊天欢笑",
    holding: "展示美业前后对比效果",
    lighting: "柔和暖光",
    dining_scene: "坐在美业机构精致休息区沙发旁",
    scene_items: "下午茶和精致护肤品摆设",
    dress_style: "优雅连衣裙或精致晚装",
    restroom_type: "高端美业机构",
    restroom_decor: "粉色系精致装饰/玫瑰花摆设/高端护肤品陈列",
    street_outfit: "优雅连衣裙或时尚修身套装",
    street_pose: "轻抚脸庞或展示肌肤状态",
  },
  "家政": {
    outfit_top: "简洁休闲上衣",
    track_action: "轻松交谈/相互微笑",
    holding: "在整洁明亮的家居环境中",
    lighting: "明亮自然光线",
    dining_scene: "坐在整洁温馨的家居客厅沙发旁",
    scene_items: "鲜花摆设和精致茶点",
    dress_style: "简约优雅连衣裙",
    restroom_type: "刚打扫完毕的高档住宅",
    restroom_decor: "洁白瓷砖/精致香皂台/薰衣草摆件",
    street_outfit: "简约时尚休闲装",
    street_pose: "自然站立微笑",
  },
  "婚摄": {
    outfit_top: "婚纱或优雅礼服",
    track_action: "相互欣赏/开心交流",
    holding: "手持鲜花捧花配件",
    lighting: "金色夕阳逆光",
    dining_scene: "坐在婚庆场地或浪漫花园布置餐桌旁",
    scene_items: "鲜花、蜡烛和精致甜点",
    dress_style: "婚纱礼服或优雅伴娘裙",
    restroom_type: "婚宴酒店",
    restroom_decor: "奢华大理石/鲜花装饰/浪漫梦幻灯光",
    street_outfit: "婚纱礼服或浪漫长裙",
    street_pose: "手捧鲜花回眸",
  },
  "教培": {
    outfit_top: "清爽休闲上衣或运动装",
    track_action: "翻阅教材/相互讨论交流",
    holding: "手持学习资料或教材",
    lighting: "明亮室内灯光",
    dining_scene: "坐在现代明亮培训机构休息区",
    scene_items: "咖啡、笔记本和学习材料",
    dress_style: "清爽休闲装或知性职业装",
    restroom_type: "现代培训机构",
    restroom_decor: "简洁白色装修/激励标语/绿植装饰",
    street_outfit: "知性休闲穿搭",
    street_pose: "手持教材自信微笑",
  },
  "医美": {
    outfit_top: "优雅修身上衣",
    track_action: "轻声交谈/相互欣赏",
    holding: "在专业医美机构门口展示肌肤状态",
    lighting: "柔和专业灯光",
    dining_scene: "坐在高端医美机构等候区精致椅上",
    scene_items: "精致护肤品展示和医美产品",
    dress_style: "优雅连衣裙或精致休闲装",
    restroom_type: "高端医美机构",
    restroom_decor: "洁白专业环境/高端护肤品/金属质感装饰",
    street_outfit: "优雅时尚穿搭",
    street_pose: "轻抚脸颊展示肌肤",
  },
};

// ─── 真实探店图片拍摄指引（第2-5张，不用AI生成） ─────────────────────────
var REAL_PHOTO_GUIDE = {
  note: "📸 第2-5张为真实探店实拍图，不用AI生成 — 真实感是算法正向加权的核心信号，官方实测真实图远优于精修图",
  shots: [
    { num: 2, label: "商品/服务近景特写", desc: "核心产品手持或近景，展示真实质感和细节，可以有人手入镜", format: "1:1方图" },
    { num: 3, label: "门店/场地环境全景", desc: "内部全景展示空间氛围和装修风格，展示真实环境", format: "1:1或9:16" },
    { num: 4, label: "美女/顾客真实体验场景", desc: "有人（美女/真实顾客）在场景中的互动，有人的图比纯产品图互动率高3倍", format: "1:1方图" },
    { num: 5, label: "价格/活动信息图", desc: "拍摄菜单/价目表/活动海报/优惠信息，让用户直接看到价格和优惠", format: "9:16竖版" },
  ],
  shooting_tips: [
    "真实手机拍摄比精修图更受算法青睐（贴图号官方实测数据）",
    "图片必须有人（美女/真实顾客）而非纯产品/纯环境图",
    "拍摄最佳时段：上午10-12点（自然光最好），避开中午强光",
    "9:16竖版构图优先，1:1方图次之，不要用横版图",
    "不要修图过度，真实感 > 精致感",
  ],
};

// ─── 商品收割文首图Prompt（中文，{merchant}/{product}自动替换） ─────────────────────────
var PRODUCT_COVER_PROMPTS = {
  "餐饮": "美食摄影，{product}，热气腾腾，芝士拉丝效果，新鲜香草点缀，陶瓷餐盘盛放，诱人的金棕色泽配光泽酱汁，暖色调，浅景深，顶部留白用于价格标注叠加，专业美食摄影，8K超高清，9:16竖版构图",
  "酒旅": "旅行摄影，{merchant}景区全景，蓝天阳光，标志性地标配翠绿植被，1-2位游客沉浸体验中，自然金色黄昏光线，温暖鲜艳色调，广角镜头，底部留白用于价格信息叠加，专业旅行摄影，8K超高清，9:16竖版构图",
  "零售": "商品摄影，{product}，明亮彩色包装放置在干净白色台面上，原价用红色粗线划掉，新活动价用黄色大号粗体标注，明亮灯光，清晰细节，专业商业摄影，8K超高清，9:16竖版构图",
  "丽人": "美业效果对比图，左侧改善前：暗沉皮肤可见毛孔，右侧改善后：光滑透亮发光肌，中间分隔线标注改善周期，{merchant}标志水印，优雅柔和粉色版式，柔和暖光，专业美业摄影，8K超高清，9:16竖版构图",
  "家政": "家居清洁效果对比，左侧改善前：凌乱积灰杂乱房间，右侧改善后：整洁有序摆放鲜花房间，中间标注服务时长，专业保洁人员穿制服展示成果，明亮干净色调，8K超高清，9:16竖版构图",
  "婚摄": "婚纱摄影风格，新人在浪漫花园场地，穿着优雅白色婚纱和西装，恩爱浪漫姿态，金色夕阳逆光，梦幻虚化氛围，底部留白用于套餐信息，专业婚纱摄影，8K超高清，9:16竖版构图",
  "教培": "教育培训场景摄影，学生在明亮现代教室中，专注学习使用笔记本电脑和笔记本，专业设备可见，明亮自然学习环境，讲师在白板前指导，温暖专注氛围，底部留白用于课程信息，8K超高清，9:16竖版构图",
  "医美": "医疗美容机构摄影，{merchant}门口+现代前台，专业洁净白色医疗环境，柔和漫射灯光，白大褂顾问专业迎接，高端品质温暖色调，建立信任氛围，底部留白用于咨询信息，8K超高清，9:16竖版构图",
};

// ─── 内图Prompt模板（中文，{merchant}/{product}自动替换） ─────────────────────────
var INNER_IMAGE_PROMPTS = {
  "餐饮": {
    detail: "美食特写，{product}，芝士拉丝和酱汁滴落细节，筷子夹起一块，热气可见，深色石板餐盘，暖色调，浅景深，8K超高清，1:1方图",
    scene: "{merchant}用餐环境，现代温馨室内装潢，舒适灯光，顾客用餐交谈，暖色调，8K超高清，1:1方图",
    info: "菜单价格信息卡，{product}价格醒目标注，清晰排版布局，暖红橙色背景，8K超高清，1:1方图",
  },
  "酒旅": {
    detail: "{merchant}细节特写，精致建筑细节和当地文化元素，自然阳光，8K超高清，1:1方图",
    scene: "{merchant}全景视野，开阔景观有游客漫步，晴朗蓝天，自然鲜艳色调，8K超高清，1:1方图",
    info: "旅行费用明细信息卡，门票/餐饮/交通逐项价格，清晰排版配图标，自然绿蓝色调，8K超高清，1:1方图",
  },
  "零售": {
    detail: "商品特写，{product}，高级材质质感和包装细节，微距摄影柔和阴影，8K超高清，1:1方图",
    scene: "{merchant}购物场景，整齐商品货架和陈列，顾客浏览商品，明亮干净色调，8K超高清，1:1方图",
    info: "价格对比信息卡，原价划掉对比红色粗体活动价，黄色折扣标签，8K超高清，1:1方图",
  },
  "丽人": {
    detail: "皮肤效果特写，肤质和光泽明显改善，柔光微距摄影，8K超高清，1:1方图",
    scene: "{merchant}优雅室内，简约奢华装潢配柔和粉调，专业服务场景，8K超高清，1:1方图",
    info: "服务对比信息卡，服务名称+价格+时长，优雅柔和版式，8K超高清，1:1方图",
  },
  "家政": {
    detail: "清洁效果特写，光亮地板和厨房台面，明亮反光，清新整洁，8K超高清，1:1方图",
    scene: "专业清洁进行中，穿制服工作人员配设备，工具整齐可见，明亮干净色调，8K超高清，1:1方图",
    info: "服务对比信息卡，服务名称+价格+时长，干净现代版式，8K超高清，1:1方图",
  },
  "婚摄": {
    detail: "新人情感特写，交换戒指或手捧花束细节，柔和浪漫虚化，8K超高清，1:1方图",
    scene: "婚摄场地，优雅花艺布置和灯光设置，浪漫氛围，8K超高清，1:1方图",
    info: "套餐对比信息卡，套餐内容+价格+包含项目，浪漫粉色调版式，8K超高清，1:1方图",
  },
  "教培": {
    detail: "学习成果特写，学员作品或证书展示，明亮成就感场景，8K超高清，1:1方图",
    scene: "现代教室环境，学员专注学习讲师指导中，明亮温暖氛围，8K超高清，1:1方图",
    info: "课程信息卡，课程名称+价格+时长，教育风格蓝色版式，8K超高清，1:1方图",
  },
  "医美": {
    detail: "专业设备特写，现代治疗仪器在洁净诊疗环境中，柔和医疗灯光，8K超高清，1:1方图",
    scene: "机构大厅和治疗室，专业设备和舒适座椅，洁净高端白色调，8K超高清，1:1方图",
    info: "服务信息卡，服务名称+价格+改善方向，医疗风格洁净版式，8K超高清，1:1方图",
  },
};

// ─── 尾图Prompt（中文） ─────────────────────────
var TAIL_IMAGE_PROMPT =
  "活动信息汇总卡，{merchant}，{theme}，" +
  "核心要点：{key_points}，" +
  "行动号召文案：{cta_text}，" +
  "位置图标+文字，" +
  "暖色主色调，干净现代版式，" +
  "底部留白用于POI信息，" +
  "专业平面设计，8K超高清，9:16竖版构图";

// ─── 标题生成公式 ─────────────────────────
var TITLE_FORMULAS = {
  "数字锚点法": {
    template: "[数字] + [反常识/惊喜] + [品类]",
    generate: function(m, p, t, pr) { return [
      "5折！" + m + pr + "只要" + t,
      "3次体验" + m + "，效果肉眼可见！",
      "人均" + t + "！" + m + pr + "闭眼冲",
    ]; },
  },
  "痛点共鸣法": {
    template: "[痛点] + [解决方案] + [情绪词]",
    generate: function(m, p, t, pr) { return [
      "还在纠结？" + m + pr + "帮你搞定",
      p + "越来越差？" + m + "让你逆袭",
      "踩了无数坑？" + m + pr + "才是正解",
    ]; },
  },
  "地域限定法": {
    template: "[城市] + [品类] + [限定/独家]",
    generate: function(m, p, t, pr) { return [
      "本地仅此一家！" + m + pr + "绝了",
      "这家" + m + "藏在巷子里，本地人才知道",
      "[城市]" + pr + "天花板！" + m + "必须去",
    ]; },
  },
  "对比冲突法": {
    template: "[A] vs [B] + [意外结果]",
    generate: function(m, p, t, pr) { return [
      "原价vs" + t + "！" + m + pr + "差距惊人",
      "贵的不一定好！" + m + pr + "碾压同价",
      "[高价竞品] vs " + t + "！" + m + "效果竟然更好？",
    ]; },
  },
  "FOMO紧迫法": {
    template: "[限时/限量] + [福利] + [行动号召]",
    generate: function(m, p, t, pr) { return [
      "最后3天！" + m + pr + t + "冲",
      "限时抢！" + m + t + pr + "手慢无",
      "仅剩[名额]个名额！" + m + pr + t + "速来",
    ]; },
  },
};

// ─── 朋友圈激励方式 ─────────────────────────
var FRIEND_CIRCLE_INCENTIVES = {
  "餐饮": "小礼品（饮品/甜点）| 优惠券/折扣码",
  "酒旅": "优惠券/折扣码 | 抽奖资格",
  "零售": "积分/会员成长值 | 优惠券/折扣码",
  "丽人": "免费体验/试做 | 优惠券/折扣码",
  "家政": "优惠券/折扣码 | 首单折扣",
  "婚摄": "免费试拍/方案定制 | 优惠券/折扣码",
  "教培": "免费试听/体验课 | 优惠券/折扣码",
  "医美": "免费面诊/皮肤检测 | 优惠券/折扣码",
};

// ─── 评论话术库 ─────────────────────────
var COMMENT_TEMPLATES = [
  "今天刚去过！真的绝了，强烈推荐",
  "就在我公司楼下，午休必去！",
  "性价比太高了，人均才XX",
  "周末带孩子去的，环境超好",
  "第一次体验就爱上了，已经回购3次",
  "朋友圈都被刷屏了，果然没失望",
  "店员特别热情，体验满分",
  "这个价格买到这个品质，真的值了",
];


// ═══════════════════════════════════════════════════════════════
// 核心生成引擎
// ═══════════════════════════════════════════════════════════════

function generateCampaign(merchant, track, purpose, product, theme) {
  if (!TRACK_STRATEGY[track]) throw new Error("不支持的赛道: " + track + "，可选: " + TRACKS.join("/"));
  if (!PURPOSE_STRATEGY[purpose]) throw new Error("不支持的营销目的: " + purpose + "，可选: " + PURPOSES.join("/"));

  var ts = TRACK_STRATEGY[track];
  var ps = PURPOSE_STRATEGY[purpose];

  var now = new Date();
  var pad = function(n) { return String(n).padStart(2, '0'); };
  var generatedAt = now.getFullYear() + "-" + pad(now.getMonth()+1) + "-" + pad(now.getDate()) + " " + pad(now.getHours()) + ":" + pad(now.getMinutes());

  return {
    meta: { generated_at: generatedAt, merchant: merchant, track: track, purpose: purpose, product: product, theme: theme },
    strategy: buildStrategy(merchant, track, purpose, product, theme, ts, ps),
    images: buildImages(merchant, track, purpose, product, theme, ts, ps),
    titles: buildTitles(merchant, track, purpose, product, theme, ts, ps),
    articles: buildArticles(merchant, track, purpose, product, theme, ts, ps),
    publishing: buildPublishing(merchant, track, purpose, product, theme, ts, ps),
    conversion_path: buildConversion(merchant, track, purpose, product, theme, ts, ps),
  };
}

function buildStrategy(merchant, track, purpose, product, theme, ts, ps) {
  return {
    track_positioning: {
      track_feature: ts.style,
      content_type_primary: ts.content_type,
      content_type_secondary: ts.content_type_alt,
      target_audience: "对" + track + "类本地生活服务有需求的微信用户",
      explosion_data: ts.hot_data,
    },
    purpose_strategy: {
      core: ps.core,
      content_priority: ps.content_priority,
      cta_keyword: ps.cta_keyword,
    },
    explosion_harvest: {
      description: "爆款引流文吸10w+流量 → 商品收割文精准转化",
      combo: [
        { order: 1, type: "爆款引流文", cover: "🔥 5种固化首图选1种（瑜伽裤大长腿/聚餐合影/豪车高跟鞋/洗手间自拍/街拍长腿）", goal: "10w+曝光，最大化流量入口", schedule: "Day1 " + ts.publish_times[0] },
        { order: 2, type: "商品收割文1", cover: "真实" + product + "特写+价格标注", goal: "深度种草+转化", schedule: "Day1 " + ts.publish_times[0] + "+5min" },
        { order: 3, type: "商品收割文2", cover: "使用场景+优惠信息", goal: "促下单/留资", schedule: "Day1 " + ts.publish_times[0] + "+10min" },
        { order: 4, type: "口碑/攻略文", cover: "真实场景+用户评价", goal: "信任建立", schedule: "Day1 " + ts.publish_times[0] + "+15min" },
      ],
      unified_topic: "#" + merchant + theme,
      effect_estimate: {
        single_article: { exposure: "50-100", poi_clicks: "1-5", conversion: "0-1" },
        combo_4_articles: { exposure: "10w+（爆款文带动）", product_exposure: "3000-5000（话题互通）", poi_clicks: "50-200", conversion: "5-20" },
      },
    },
  };
}

function buildImages(merchant, track, purpose, product, theme, ts, ps) {
  // 通用替换函数：将所有{...}模板变量替换为实际值
  function fillTemplate(tmpl, extraMap) {
    var fullMap = { merchant: merchant, product: product, destination: merchant, theme: theme };
    if (extraMap) {
      for (var k in extraMap) { if (extraMap.hasOwnProperty(k)) fullMap[k] = extraMap[k]; }
    }
    var result = tmpl;
    for (var key in fullMap) {
      if (fullMap.hasOwnProperty(key)) {
        result = result.split("{" + key + "}").join(fullMap[key]);
      }
    }
    // 清除任何残留的{...}占位符（防止遗漏）
    result = result.replace(/\{[^}]+\}/g, "");
    return result;
  }

  // ── 5种固化爆款首图（全部生成，100%推荐） ──
  var tv = COVER_TRACK_VARS[track] || COVER_TRACK_VARS["餐饮"];
  var varMap = { merchant: merchant, product: product };
  for (var vk in tv) { if (tv.hasOwnProperty(vk)) varMap[vk] = tv[vk]; }

  var cover_templates = COVER_TEMPLATES.map(function(tpl) {
    return {
      id: tpl.id,
      name: tpl.name,
      why: tpl.why,
      prompt: fillTemplate(tpl.prompt, varMap),
      checklist: tpl.checklist.map(function(c) {
        return c.replace("{merchant}", merchant);
      }),
      size: "1080×1440px（9:16 竖版）",
    };
  });

  // ── 商品收割文首图（第1张AI图之外的正经商品首图） ──
  var productPromptTemplate = PRODUCT_COVER_PROMPTS[track] || PRODUCT_COVER_PROMPTS["餐饮"];
  var productPrompt = fillTemplate(productPromptTemplate);

  // ── 真实探店图片指引（第2-5张） ──
  var realPhotoGuide = {
    note: REAL_PHOTO_GUIDE.note,
    shots: REAL_PHOTO_GUIDE.shots,
    shooting_tips: REAL_PHOTO_GUIDE.shooting_tips,
  };

  // ── 内图Prompt（可选，仅当无法实拍时备用） ──
  var inner = INNER_IMAGE_PROMPTS[track] || INNER_IMAGE_PROMPTS["餐饮"];
  var innerPrompts = {};
  for (var key in inner) {
    if (inner.hasOwnProperty(key)) {
      innerPrompts[key] = fillTemplate(inner[key]);
    }
  }

  // ── 尾图 ──
  var ctaMap = {
    "商品下单": "点击位置立即下单👇 限时优惠",
    "线索收集": "点击位置免费预约👇 每日限额",
    "种草曝光": "点击位置看看离你多近👇",
  };
  var tailPrompt = fillTemplate(TAIL_IMAGE_PROMPT, {
    key_points: product + " | " + theme + " | 限时优惠 | 门店直达",
    cta_text: ctaMap[purpose] || "点击位置了解更多👇",
  });

  return {
    // 5种固化爆款首图模板（100%推荐全部给用户）
    cover_templates: cover_templates,
    cover_strategy: "🔥 首图 = 流量入口。以下5种首图公式均经过实测验证，选择其中1种拍摄或用AI生成即可。推荐优先：①瑜伽裤大长腿（10w+核心公式）",
    // 商品收割文首图
    product_cover: {
      direction: product + "真实特写+价格标注，回归商品展示，承接爆款流量",
      prompt: productPrompt,
      size: "1080×1440px（9:16 竖版）",
    },
    // 第2-5张：真实探店图片指引
    real_photo_guide: realPhotoGuide,
    // 备用AI内图Prompt（无法实拍时）
    inner_images_fallback: innerPrompts,
    // 尾图
    tail_image: {
      direction: theme + "活动总结+行动号召+POI引导",
      prompt: tailPrompt,
      size: "1080×1440px（9:16 竖版）",
    },
    image_strategy: ps.image_strategy,
  };
}

function buildTitles(merchant, track, purpose, product, theme, ts, ps) {
  var formulas = ps.title_formulas;
  var result = {};

  // 爆款引流文标题
  var explosionFormula = formulas[0];
  result.explosion_article = {
    formula: explosionFormula,
    template: TITLE_FORMULAS[explosionFormula].template,
    titles: TITLE_FORMULAS[explosionFormula].generate(merchant, track, product, theme),
  };

  // 商品收割文标题
  var productFormula = formulas.length > 1 ? formulas[1] : formulas[0];
  result.product_article = {
    formula: productFormula,
    template: TITLE_FORMULAS[productFormula].template,
    titles: TITLE_FORMULAS[productFormula].generate(merchant, track, product, theme),
  };

  // 口碑攻略文标题
  var reviewFormula = formulas.length > 2 ? formulas[2] : "地域限定法";
  result.review_article = {
    formula: reviewFormula,
    template: TITLE_FORMULAS[reviewFormula].template,
    titles: TITLE_FORMULAS[reviewFormula].generate(merchant, track, product, theme),
  };

  // 推荐首选
  result.recommended = {
    explosion: result.explosion_article.titles[0],
    product: result.product_article.titles[0],
  };

  // 自检5问
  result.self_check = [
    "前7个字是否包含核心关键词？",
    "是否有数字（价格/排名/数量）？",
    "是否触发了好奇心或紧迫感？",
    "是否标注了城市/地域？",
    "长度是否控制在15字以内？",
  ];

  return result;
}

function buildArticles(merchant, track, purpose, product, theme, ts, ps) {
  var topic = "#" + merchant + theme;
  var cta = ts.cta;
  var tags = ts.topic_tags.join(" ")
    .replace("[城市]", "[你的城市]")
    .replace("[品类]", track)
    .replace("[目的地]", merchant)
    .replace("[品牌]", merchant)
    .replace("[技能]", product);

  // 第1篇：爆款引流文
  var article1 = {
    type: "爆款引流文（轻量化，以图为主）",
    title_suggestion: "见标题方案区",
    body:
      "终于去了" + merchant + "！" + product + "真的绝了！✨\n\n" +
      "朋友推荐了好久，这次终于安排上了～\n" +
      product + "体验太惊喜了，强烈推荐！\n\n" +
      "📍 " + cta + "\n" +
      "觉得有用？转发朋友圈让更多人看到 ❤️",
    topic_tags: topic + " " + tags,
  };

  // 第2篇：商品收割文1
  var body2;
  if (purpose === "商品下单") {
    body2 =
      "🔥 " + product + "限时特惠！" + theme + "！\n\n" +
      "✅ 亮点1：品质过硬，口碑爆棚\n" +
      "✅ 亮点2：对比同类，性价比拉满\n" +
      "✅ 亮点3：用户好评如潮，回购率超高\n" +
      "✅ 亮点4：" + merchant + "出品，品质保证\n\n" +
      "💰 原价[原价] → 现在只要[活动价]！省下[优惠金额]元\n\n" +
      "📍 " + cta + "\n" +
      "⏰ " + theme + "，手慢无！";
  } else if (purpose === "线索收集") {
    body2 =
      "还在为" + track + "烦恼？试了好多方法都没用？\n\n" +
      "朋友推荐来了" + merchant + "，本来没抱希望，结果...\n\n" +
      "✅ 专业度：资质齐全/设备先进/团队资深\n" +
      "✅ 效果：明显改善/提升/解决痛点\n" +
      "✅ 体验：环境舒适/服务贴心/流程规范\n\n" +
      "🎁 首次体验免费/0元预约/限时体验价\n\n" +
      "📍 " + cta + "\n" +
      "名额每天限XX人，速约！";
  } else {
    body2 =
      "今天终于去打卡了" + merchant + "，真的绝了！\n\n" +
      "朋友推荐了好久，这次终于安排上了\n\n" +
      "🌟 第一印象：" + product + "太惊艳了\n" +
      "🌟 体验感受：超出预期，性价比爆表\n" +
      "🌟 惊喜点：没想到" + merchant + "还有这个\n" +
      "🌟 氛围：环境超好，拍照绝了\n\n" +
      "💡 Tips：建议XX点去，人少体验更好\n\n" +
      "📍 " + merchant + "（[地址]）💰 " + product + "\n\n" +
      "点击位置看看离你多近👇\n" +
      "觉得有用？转发朋友圈让更多人看到 ❤️";
  }
  var article2 = { type: "商品收割文1（详细商品介绍）", title_suggestion: "见标题方案区", body: body2, topic_tags: topic + " " + tags };

  // 第3篇：商品收割文2
  var body3;
  if (purpose === "商品下单") {
    body3 =
      "💡 " + merchant + "省钱攻略来了！\n\n" +
      "🎯 " + product + "怎么买最划算？\n\n" +
      "1️⃣ 方案一：直接下单" + product + "，立省[金额]元\n" +
      "2️⃣ 方案二：叠加会员折扣，再省[金额]元\n" +
      "3️⃣ 方案三：拉好友拼单，每人再减[金额]元\n\n" +
      "📊 价格对比：\n" +
      "原价：¥[原价]\n" +
      "活动价：¥[活动价]\n" +
      "叠加优惠后：¥[最终价]（历史最低！）\n\n" +
      "📍 " + cta + "\n" +
      "⏰ 活动截止倒计时！手慢无！";
  } else if (purpose === "线索收集") {
    body3 =
      "📋 " + merchant + "服务流程详解\n\n" +
      "很多朋友问我" + product + "怎么预约，这里统一说一下：\n\n" +
      "Step 1：点击下方位置进入预约页\n" +
      "Step 2：填写姓名+电话（只需2项）\n" +
      "Step 3：选择时间，确认预约\n" +
      "Step 4：到店体验" + product + "\n\n" +
      "💡 注意事项：\n" +
      "- 首次体验免费/特价\n" +
      "- 到店后出示预约码\n" +
      "- 预约后可改期，不扣费\n\n" +
      "📍 " + cta + "\n" +
      "已服务[用户数]+用户 | 好评率[好评率]%";
  } else {
    body3 =
      "📸 " + merchant + "真实体验全记录\n\n" +
      "很多人问" + product + "到底值不值得去？\n" +
      "我实地体验了，给各位说下感受：\n\n" +
      "🏠 环境：[描述]\n" +
      "🛎 服务：[描述]\n" +
      "💰 价格：[描述]\n" +
      "⭐ 推荐指数：⭐⭐⭐⭐⭐\n\n" +
      "📍 " + merchant + "（[地址]）\n" +
      "点击位置看看离你多近👇";
  }
  var article3 = { type: "商品收割文2（价格+优惠+购买引导）", title_suggestion: "见标题方案区", body: body3, topic_tags: topic + " " + tags };

  // 第4篇：口碑/攻略文
  var body4 =
    "📝 " + merchant + "避坑攻略！" + product + "必看\n\n" +
    "去了3次总结的经验，帮你省钱省时间：\n\n" +
    "1️⃣ 最佳时间：[推荐时段]\n" +
    "2️⃣ 必选项目：" + product + "\n" +
    "3️⃣ 省钱技巧：[省钱方法]\n" +
    "4️⃣ 避坑提醒：[注意事项]\n" +
    "5️⃣ 隐藏福利：[隐藏优惠]\n\n" +
    "💬 用户好评：\n" +
    "'去了3次了，每次都很满意' — 用户A\n" +
    "'性价比超高，推荐给朋友了' — 用户B\n\n" +
    "📍 " + cta + "\n" +
    "觉得有用？转发朋友圈让更多人看到 ❤️";
  var article4 = { type: "口碑/攻略文", title_suggestion: "见标题方案区", body: body4, topic_tags: topic + " " + tags };

  return {
    article_1_explosion: article1,
    article_2_product: article2,
    article_3_product: article3,
    article_4_review: article4,
  };
}

function buildPublishing(merchant, track, purpose, product, theme, ts, ps) {
  return {
    publish_time: {
      best_slots: ts.publish_times,
      reason: ts.publish_reason,
      frequency_recommendation: "2-3篇/天（推荐广撒网+测试）",
      special_timing: "节假日前3-5天发布效果倍增",
    },
    traffic_sources: [
      {name:"POI详情页",priority:"1️⃣ 最高",tip:"必须挂载POI！转化率最高入口",click_rate:"10-20%"},
      {name:"公众号/服务号消息盒子",priority:"2️⃣ 规模最大",tip:"注册服务号，贴图不限1次/周",open_rate:"3-15%"},
      {name:"贴图后推荐",priority:"3️⃣ 精准度最高",tip:"同话题多发内容，提高被推荐率",click_rate:"8-15%"},
      {name:"话题聚合页",priority:"4️⃣ 系列互通",tip:"4篇同话题，话题页展示系列内容",avg_browse:"3-5篇"},
      {name:"搜一搜",priority:"5️⃣ 长尾流量",tip:"标题含城市+品类+品牌关键词",type:"持续流量"},
    ],
    friend_circle: {
      in_article: "觉得有用？转发朋友圈让更多人看到 ❤️",
      in_comment: "🔗 点击位置直达门店 | 觉得有用转朋友圈让更多人看到~",
      staff_script: "我们店在微信贴图号有活动，扫码看看~觉得好帮忙转发朋友圈哈！",
      incentive: FRIEND_CIRCLE_INCENTIVES[track] || "优惠券/折扣码",
    },
    staff_warmup: {
      why: "发布后前30分钟的互动数据决定了内容能否进入推荐池！",
      sop: [
        {time:"0分钟",action:"店长发布贴图，转发到员工群",who:"店长"},
        {time:"1分钟",action:"全员完整浏览（至少停留30秒）",who:"全员"},
        {time:"2分钟",action:"全员点赞+收藏",who:"全员"},
        {time:"3分钟",action:"全员发表不同评论",who:"全员"},
        {time:"5分钟",action:"全员转发朋友圈",who:"全员"},
        {time:"10分钟",action:"转发2-3个私域社群",who:"全员"},
        {time:"30分钟",action:"检查数据，看是否进入推荐池",who:"运营"},
      ],
      comment_templates: COMMENT_TEMPLATES,
      kpi: { "点赞数":"≥ 10（30分钟内）", "收藏数":"≥ 5", "评论数":"≥ 8条（每人不同）", "朋友圈转发":"≥ 5人" },
    },
    matrix: {
      accounts: [
        {type:"品牌官方号",count:1,role:"正式种草+活动发布"},
        {type:"门店号",count:"N（按门店数）",role:"本地探店+门店活动"},
        {type:"员工号",count:"3-5",role:"个人探店+真实分享"},
        {type:"达人号",count:"2-3",role:"深度测评+攻略"},
      ],
      key_principle: "10个账号各发3篇 > 1个账号发30篇",
      rhythm: "Day1: 品牌号→爆款引流文 | 门店号A→商品文1 | 门店号B→商品文2 | 员工号→攻略文（统一话题#" + merchant + theme + "）",
    },
    data_monitoring: [
      {time:"30分钟",metric:"点赞+评论数",target:"> 10",emergency:"低于则私域催互动"},
      {time:"2小时",metric:"点击率",target:"> 3%",emergency:"低于则首图/标题有问题"},
      {time:"24小时",metric:"互动率",target:"> 2%",emergency:"低于则正文需优化"},
      {time:"48小时",metric:"POI点击率",target:"> 3%",emergency:"低于则POI引导需优化"},
      {time:"7天",metric:"总曝光",target:"> 500",emergency:"低于则换内容方向"},
    ],
  };
}

function buildConversion(merchant, track, purpose, product, theme, ts, ps) {
  var pathMap = {
    "商品下单": "贴图号内容 → 点击POI → 小程序商品下单页 → 完成支付",
    "线索收集": "贴图号内容 → 点击POI → 小程序预约/表单页 → 留资完成",
    "种草曝光": "贴图号内容 → 点击POI → 门店详情页 → 品牌认知提升",
  };
  var result = {
    full_path: pathMap[purpose],
    mini_program_tip: ps.mini_program_tip,
    scene_1430: "✅ 已配置场景值1430追踪（贴图→小程序来源追踪）",
    official_account_publish: {
      component: "official-account-publish",
      min_library: "3.9.3",
      tip: "在小程序门店详情页嵌入，引导用户UGC内容生产",
      topic_limit: "话题名称≤20字",
      limit: "最多展示10条贴图",
    },
    wx_share_api: {
      api: "wx.shareToOfficialAccount",
      min_library: "3.9.2",
      tip: "必须用户点击触发，不可异步调用",
    },
  };
  if (track === "医美" && ts.compliance_note) {
    result.compliance_note = ts.compliance_note;
  }
  return result;
}


// ═══════════════════════════════════════════════════════════════
// Markdown 格式化
// ═══════════════════════════════════════════════════════════════

function formatMarkdown(result) {
  var m = result.meta;
  var s = result.strategy;
  var img = result.images;
  var t = result.titles;
  var a = result.articles;
  var p = result.publishing;
  var c = result.conversion_path;

  var md = "# 🎯 " + m.merchant + " · 贴图号运营方案\n\n";
  md += "> 生成时间：" + m.generated_at + " | 赛道：" + m.track + " | 目的：" + m.purpose + "\n\n";
  md += "## 📋 基本信息\n\n| 项目 | 内容 |\n|------|------|\n";
  md += "| 商家名称 | " + m.merchant + " |\n| 行业赛道 | " + m.track + " |\n| 营销目的 | " + m.purpose + " |\n| 商品名称 | " + m.product + " |\n| 营销主题 | " + m.theme + " |\n\n---\n\n";

  md += "## 📊 一、整体运营策略\n\n### 1.1 赛道定位\n\n";
  md += "**赛道特征**：" + s.track_positioning.track_feature + "\n\n";
  md += "**内容策略**：" + s.track_positioning.content_type_primary + "为主，" + s.track_positioning.content_type_secondary + "为辅\n\n";
  md += "**爆款数据**：" + s.track_positioning.explosion_data + "\n\n";

  md += "### 1.2 营销目的策略\n\n";
  md += "**核心策略**：" + s.purpose_strategy.core + "\n\n";
  md += "**内容优先级**：" + s.purpose_strategy.content_priority + "\n\n";
  md += "**CTA关键词**：" + s.purpose_strategy.cta_keyword + "\n\n";

  md += "### 1.3 🔥 爆款引流 + 商品收割策略\n\n";
  md += "> 💡 核心打法：爆款文吸10w+流量 → 商品文收割转化\n\n";
  md += "**4篇组合发布方案**：\n\n| 篇序 | 类型 | 首图 | 目标 | 发布时间 |\n|------|------|------|------|----------|\n";
  for (var i = 0; i < s.explosion_harvest.combo.length; i++) {
    var item = s.explosion_harvest.combo[i];
    md += "| 第" + item.order + "篇 | " + item.type + " | " + item.cover + " | " + item.goal + " | " + item.schedule + " |\n";
  }

  md += "\n**统一话题**：" + s.explosion_harvest.unified_topic + "（4篇同话题，话题页互通展示）\n\n";
  md += "**效果预估对比**：\n\n| 指标 | 单篇投放 | 4篇组合投放 |\n|------|----------|------------|\n";
  var ee = s.explosion_harvest.effect_estimate;
  md += "| 总曝光量 | " + ee.single_article.exposure + " | " + ee.combo_4_articles.exposure + " |\n";
  md += "| 商品文曝光 | — | " + ee.combo_4_articles.product_exposure + " |\n";
  md += "| POI点击量 | " + ee.single_article.poi_clicks + " | " + ee.combo_4_articles.poi_clicks + " |\n";
  md += "| 转化量 | " + ee.single_article.conversion + " | " + ee.combo_4_articles.conversion + " |\n\n";

  md += "### 1.4 发布节奏与流量策略\n\n";
  md += "**发布频率**：" + p.publish_time.frequency_recommendation + "\n\n";
  md += "**最佳发布时间**：\n";
  for (var si = 0; si < p.publish_time.best_slots.length; si++) {
    md += "- " + p.publish_time.best_slots[si] + "（" + p.publish_time.reason + "）\n";
  }

  md += "\n**6大公域流量露出入口优化**：\n\n| 入口 | 优先级 | 优化要点 | 数据 |\n|------|--------|----------|------|\n";
  for (var ti = 0; ti < p.traffic_sources.length; ti++) {
    var src = p.traffic_sources[ti];
    var dataVal = src.click_rate || src.open_rate || src.avg_browse || src.type || "";
    md += "| " + src.name + " | " + src.priority + " | " + src.tip + " | " + dataVal + " |\n";
  }

  md += "\n**朋友圈引导方案**：\n";
  md += "- 正文引导：" + p.friend_circle.in_article + "\n";
  md += "- 店员引导：" + p.friend_circle.staff_script + "\n";
  md += "- 激励方式：" + p.friend_circle.incentive + "\n\n";

  md += "**店员预热SOP**：\n\n| 时间 | 动作 | 参与人 |\n|------|------|--------|\n";
  for (var soi = 0; soi < p.staff_warmup.sop.length; soi++) {
    var step = p.staff_warmup.sop[soi];
    md += "| " + step.time + " | " + step.action + " | " + step.who + " |\n";
  }

  md += "\n**评论话术库**：\n";
  for (var ci = 0; ci < p.staff_warmup.comment_templates.length; ci++) {
    md += (ci + 1) + ". " + p.staff_warmup.comment_templates[ci] + "\n";
  }

  md += "\n**多账号矩阵建议**：\n";
  md += "- 推荐账号数：品牌号1 + 门店号N + 员工号3-5 + 达人号2-3\n";
  md += "- 核心原则：" + p.matrix.key_principle + "\n";
  md += "- 发布节奏：" + p.matrix.rhythm + "\n\n";

  md += "### 1.5 转化链路\n\n```\n" + c.full_path + "\n```\n\n";
  md += "**小程序页面建议**：" + c.mini_program_tip + "\n\n";
  md += "**场景值1430追踪**：" + c.scene_1430 + "\n\n---\n\n";

  // 图片
  md += "## 🖼️ 二、图片方向与提示词\n\n";
  md += "> 💡 " + img.cover_strategy + "\n\n";

  // 5种固化首图模板
  for (var ci = 0; ci < img.cover_templates.length; ci++) {
    var tpl = img.cover_templates[ci];
    md += "### 首图模板 " + tpl.name + "\n\n";
    md += "**为什么有效**：" + tpl.why + "\n\n";
    md += "**AI绘图Prompt**：\n```\n" + tpl.prompt + "\n```\n\n";
    md += "**尺寸**：" + tpl.size + "\n\n";
    md += "**首图自检**：\n";
    for (var cki = 0; cki < tpl.checklist.length; cki++) {
      md += "- [ ] " + tpl.checklist[cki] + "\n";
    }
    md += "\n---\n\n";
  }

  // 商品收割文首图
  md += "### 商品收割文首图（9:16竖版）\n\n";
  md += "**设计方向**：" + img.product_cover.direction + "\n\n";
  md += "**AI绘图Prompt**：\n```\n" + img.product_cover.prompt + "\n```\n\n";
  md += "**尺寸**：" + img.product_cover.size + "\n\n---\n\n";

  // 第2-5张真实探店图片指引
  md += "### 📸 第2-5张：真实探店实拍图（重要！）\n\n";
  md += "> " + img.real_photo_guide.note + "\n\n";
  md += "| 张数 | 拍摄内容 | 说明 | 格式 |\n|------|----------|------|------|\n";
  for (var ri = 0; ri < img.real_photo_guide.shots.length; ri++) {
    var shot = img.real_photo_guide.shots[ri];
    md += "| 第" + shot.num + "张 | " + shot.label + " | " + shot.desc + " | " + shot.format + " |\n";
  }
  md += "\n**实拍技巧**：\n";
  for (var rti = 0; rti < img.real_photo_guide.shooting_tips.length; rti++) {
    md += "- " + img.real_photo_guide.shooting_tips[rti] + "\n";
  }
  md += "\n---\n\n";

  // 备用AI内图
  md += "### 备用AI内图Prompt（无法实拍时）\n\n";
  var innerLabels = {detail:"细节特写",scene:"环境/场景",info:"信息图"};
  var innerIdx = 1;
  for (var ik in innerLabels) {
    if (innerLabels.hasOwnProperty(ik) && img.inner_images_fallback[ik]) {
      md += "#### 备用内图" + innerIdx + "（1:1方图）— " + innerLabels[ik] + "\n\n```\n" + img.inner_images_fallback[ik] + "\n```\n\n";
      innerIdx++;
    }
  }

  md += "### 尾图（9:16竖版）— 行动号召\n\n";
  md += "**设计方向**：" + img.tail_image.direction + "\n\n";
  md += "**AI绘图Prompt**：\n```\n" + img.tail_image.prompt + "\n```\n\n";
  md += "**图片整体策略**：" + img.image_strategy + "\n\n---\n\n";

  // 标题
  md += "## 📝 三、标题文案（A/B测试备选）\n\n";
  var titleSections = [
    {key:"explosion_article", label:"爆款引流文标题"},
    {key:"product_article", label:"商品收割文标题"},
    {key:"review_article", label:"口碑/攻略文标题"},
  ];
  for (var tsi = 0; tsi < titleSections.length; tsi++) {
    var sec = titleSections[tsi];
    var d = t[sec.key];
    md += "### " + sec.label + "（" + d.formula + "）\n模板：" + d.template + "\n";
    for (var tii = 0; tii < d.titles.length; tii++) {
      md += (tii + 1) + ". " + d.titles[tii] + "\n";
    }
    md += "\n";
  }

  md += "### 🏆 推荐首选\n**爆款引流文**：" + t.recommended.explosion + "\n**商品收割文**：" + t.recommended.product + "\n\n";
  md += "### 标题自检5问\n";
  for (var sci = 0; sci < t.self_check.length; sci++) {
    md += "- [ ] " + t.self_check[sci] + "\n";
  }

  md += "\n---\n\n## 📄 四、文章详细文案\n";
  var artKeys = ["article_1_explosion","article_2_product","article_3_product","article_4_review"];
  for (var ai = 0; ai < artKeys.length; ai++) {
    var art = a[artKeys[ai]];
    md += "\n### " + art.type + "\n\n**话题标签**：" + art.topic_tags + "\n\n**正文**：\n\n" + art.body + "\n\n---\n";
  }

  md += "\n## 🚀 五、发布策略\n\n";
  md += "### 发布时间\n- 🕐 最佳时段：" + p.publish_time.best_slots.join(" / ") + "\n";
  md += "- 📅 特殊节点：" + p.publish_time.special_timing + "\n";
  md += "- ⏰ 店员预热：发布前1小时通知全员\n\n";

  md += "### 店员预热SOP\n**发布后0-30分钟（黄金期！）**：\n\n| 时间 | 动作 | 参与人 |\n|------|------|--------|\n";
  for (var sop2i = 0; sop2i < p.staff_warmup.sop.length; sop2i++) {
    var step2 = p.staff_warmup.sop[sop2i];
    md += "| " + step2.time + " | " + step2.action + " | " + step2.who + " |\n";
  }

  md += "\n### 朋友圈引导方案\n- **正文引导**：" + p.friend_circle.in_article + "\n";
  md += "- **评论区引导**：" + p.friend_circle.in_comment + "\n";
  md += "- **店员引导**：" + p.friend_circle.staff_script + "\n";
  md += "- **激励方式**：" + p.friend_circle.incentive + "\n\n";

  md += "### 数据监控\n\n| 时间节点 | 关注指标 | 目标值 | 应急方案 |\n|----------|----------|--------|----------|\n";
  for (var di = 0; di < p.data_monitoring.length; di++) {
    var mon = p.data_monitoring[di];
    md += "| " + mon.time + " | " + mon.metric + " | " + mon.target + " | " + mon.emergency + " |\n";
  }

  md += "\n---\n\n## ⚠️ 注意事项\n\n";
  md += "1. **首图公式100%固化**：5种爆款首图模板均经实测，选1种拍摄或AI生成，每篇必用其中之一\n";
  md += "   - ① 瑜伽裤+大长腿+多美女+门头（10w+核心公式，优先推荐）\n";
  md += "   - ② 多美女聚餐合影（互动率2-3倍）\n";
  md += "   - ③ 豪车+高跟鞋+弯腰整裙（中高端定位专用）\n";
  md += "   - ④ 洗手间镜前半遮面手机自拍（神秘感悬念）\n";
  md += "   - ⑤ 门店外街拍大长腿（最易拍摄，适配所有赛道）\n";
  md += "2. 第2-5张用真实探店照片（不要AI图），真实感是算法正向加权的核心信号\n";
  md += "3. 爆款文和商品文必须在同一话题下发布，才能话题页互通展示\n";
  md += "4. 必须挂载POI，没有POI不会出现在POI详情页\n";
  md += "5. 发布后30分钟内店员预热是冷启动的关键\n";
  md += "6. 多账号矩阵策略优于单账号深耕（10个账号各发3篇 > 1个账号发30篇）\n";
  md += "7. 贴图号 ≠ 小红书，去中心化分发逻辑，广撒网比精品化更有效\n";

  if (c.compliance_note) md += "8. ⚠️ " + c.compliance_note + "\n";

  md += "\n---\n\n> 📌 本方案由贴图号运营方案生成器自动生成，数据参考来源：贴图号算法策略实测数据、8篇爆款拆解、小程序贴图能力官方文档\n";

  return md;
}


// ═══════════════════════════════════════════════════════════════
// 导出
// ═══════════════════════════════════════════════════════════════

return {
  TRACKS: TRACKS,
  PURPOSES: PURPOSES,
  TRACK_STRATEGY: TRACK_STRATEGY,
  PURPOSE_STRATEGY: PURPOSE_STRATEGY,
  TITLE_FORMULAS: TITLE_FORMULAS,
  COVER_TEMPLATES: COVER_TEMPLATES,
  COVER_TRACK_VARS: COVER_TRACK_VARS,
  REAL_PHOTO_GUIDE: REAL_PHOTO_GUIDE,
  PRODUCT_COVER_PROMPTS: PRODUCT_COVER_PROMPTS,
  INNER_IMAGE_PROMPTS: INNER_IMAGE_PROMPTS,
  TAIL_IMAGE_PROMPT: TAIL_IMAGE_PROMPT,
  FRIEND_CIRCLE_INCENTIVES: FRIEND_CIRCLE_INCENTIVES,
  COMMENT_TEMPLATES: COMMENT_TEMPLATES,
  generateCampaign: generateCampaign,
  formatMarkdown: formatMarkdown,
  buildStrategy: buildStrategy,
  buildImages: buildImages,
  buildTitles: buildTitles,
  buildArticles: buildArticles,
  buildPublishing: buildPublishing,
  buildConversion: buildConversion,
};

});
