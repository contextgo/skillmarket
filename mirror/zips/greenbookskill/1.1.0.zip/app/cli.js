#!/usr/bin/env node
/**
 * 贴图号运营方案生成器 - CLI入口 v20260506
 * 零外部依赖，纯Node.js内置模块
 *
 * 用法:
 *   node cli.js --merchant "某茶饮品牌" --track "餐饮" --purpose "商品下单" --product "9.9新品" --theme "51大放送"
 *   node cli.js --merchant "某茶饮品牌" --track "餐饮" --purpose "商品下单" --product "9.9新品" --theme "51大放送" --format markdown
 *   node cli.js --merchant "某茶饮品牌" --track "餐饮" --purpose "商品下单" --product "9.9新品" --theme "51大放送" --format json --output plan.json
 */

var fs = require("fs");
var path = require("path");
var gen = require("./generator.js");

// ─── 参数解析（零依赖） ─────────────────────────

function parseArgs(argv) {
  var args = {};
  for (var i = 2; i < argv.length; i++) {
    var arg = argv[i];
    if (arg.startsWith("--")) {
      var key = arg.slice(2);
      var val = (i + 1 < argv.length && !argv[i + 1].startsWith("--")) ? argv[++i] : true;
      args[key] = val;
    }
  }
  return args;
}

function showHelp() {
  console.log([
    "",
    "  贴图号运营方案生成器 CLI",
    "",
    "  用法:",
    "    node cli.js [选项]",
    "",
    "  必填参数:",
    "    --merchant <名称>   商家名称（例如：某茶饮品牌）",
    "    --track <赛道>      行业赛道（" + gen.TRACKS.join("/") + "）",
    "    --purpose <目的>    营销目的（" + gen.PURPOSES.join("/") + "）",
    "    --product <商品>    商品名称（例如：9.9新品）",
    "    --theme <主题>      营销主题（例如：51大放送）",
    "",
    "  可选参数:",
    "    --format <格式>     输出格式: summary（默认）/ json / markdown",
    "    --output <路径>     输出到文件（不指定则打印到stdout）",
    "    --help              显示帮助",
    "",
    "  示例:",
    "    node cli.js --merchant \"某茶饮品牌\" --track \"餐饮\" --purpose \"商品下单\" --product \"9.9新品\" --theme \"51大放送\"",
    "    node cli.js --merchant \"某茶饮品牌\" --track \"餐饮\" --purpose \"商品下单\" --product \"9.9新品\" --theme \"51大放送\" --format markdown",
    "    node cli.js --merchant \"某茶饮品牌\" --track \"餐饮\" --purpose \"商品下单\" --product \"9.9新品\" --theme \"51大放送\" --format json --output plan.json",
    "",
  ].join("\n"));
}

// ─── 主逻辑 ─────────────────────────

var args = parseArgs(process.argv);

if (args.help) {
  showHelp();
  process.exit(0);
}

// 验证必填参数
var required = ["merchant", "track", "purpose", "product", "theme"];
var missing = required.filter(function(k) { return !args[k]; });
if (missing.length) {
  console.error("❌ 缺少必填参数: " + missing.join(", "));
  console.error("   使用 --help 查看帮助");
  process.exit(1);
}

// 生成
var result;
try {
  result = gen.generateCampaign(args.merchant, args.track, args.purpose, args.product, args.theme);
} catch (e) {
  console.error("❌ " + e.message);
  process.exit(1);
}

// 格式化输出
var format = args.format || "summary";
var output;

if (format === "markdown") {
  output = gen.formatMarkdown(result);
} else if (format === "json") {
  output = JSON.stringify(result, null, 2);
} else {
  // summary - 精简输出（适合agent快速读取）
  var summary = {
    merchant: result.meta.merchant,
    track: result.meta.track,
    purpose: result.meta.purpose,
    product: result.meta.product,
    theme: result.meta.theme,
    core_strategy: result.strategy.purpose_strategy.core,
    combo_strategy: result.strategy.explosion_harvest.combo.map(function(c) { return "第" + c.order + "篇-" + c.type; }),
    unified_topic: result.strategy.explosion_harvest.unified_topic,
    // 5种固化首图模板（100%必出）
    cover_templates_note: "以下5种首图模板每篇贴图必选其中之一，100%推荐给用户",
    cover_templates: result.images.cover_templates.map(function(t) {
      return { name: t.name, why: t.why, prompt: t.prompt };
    }),
    // 商品收割文首图
    product_cover_prompt: result.images.product_cover.prompt,
    // 第2-5张真实探店图片指引
    real_photo_guide: result.images.real_photo_guide,
    // 标题
    titles_explosion: result.titles.explosion_article.titles,
    titles_product: result.titles.product_article.titles,
    // 转化
    conversion_path: result.conversion_path.full_path,
    best_publish_time: result.publishing.publish_time.best_slots,
  };
  output = JSON.stringify(summary, null, 2);
}

// 输出
if (args.output) {
  var outPath = path.resolve(args.output);
  fs.writeFileSync(outPath, output, "utf-8");
  console.log("✅ 方案已保存到: " + outPath);
} else {
  console.log(output);
}
