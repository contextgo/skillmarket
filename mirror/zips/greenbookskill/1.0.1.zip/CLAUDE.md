# Project Memory

## Project Overview
- **Name**: 贴图号SKILL - 贴图号（原小绿书）运营全流程知识库 + 运营方案生成器
- **Purpose**: SkillHub skill，提供贴图号运营知识库 + 一键生成完整运营方案
- **Architecture**: 纯JS，零外部依赖（无Python、无npm包）

## Directory Structure
```
贴图号SKILL/
├── SKILL.md                     # Skill frontmatter + 知识库（产品介绍/算法/集成/爆款/文案）
├── app/
│   ├── generator.js             # 共享生成引擎（UMD模式，浏览器+Node.js通用）
│   ├── cli.js                   # Node.js CLI入口（Agent调用）
│   └── index.html               # 可视化页面（双击即用，引用generator.js）
├── references/                  # 8个参考文档(.md) + 29张参考图片
│   ├── 贴图号产品介绍.md
│   ├── 贴图号算法策略.md
│   ├── 贴图号内容策略深度分析.md
│   ├── 贴图号与小程序集成打通.md
│   ├── 小程序贴图能力完整介绍.md
│   ├── 贴图号内容爆款解析.md
│   ├── 贴图号8篇文章爆款拆解.md
│   ├── 贴图号文案标题图片生成.md
│   └── images/ (29 images)
└── .claude/settings.local.json
```

## Key Technical Decisions
- **UMD module pattern** in generator.js: `(function(root, factory){})(...)` supports both `module.exports` (Node) and global scope (browser)
- **No build step**: index.html loads generator.js via `<script src="generator.js">`
- **CLI arg parsing**: Zero-dependency, manual `process.argv` parsing in cli.js
- **8 industry tracks**: 餐饮/酒旅/零售/丽人/家政/婚摄/教培/医美
- **3 marketing purposes**: 商品下单/线索收集/种草曝光
- **3 output formats**: summary(default)/json/markdown

## CLI Usage
```bash
node app/cli.js --merchant "商家名" --track "餐饮" --purpose "商品下单" --product "商品名" --theme "主题" [--format summary|json|markdown] [--output file.md]
```

## Current Version
- **v20260506** — `贴图号SKILL_v20260506.zip` — 5种固化首图模板升级版

## Security Notes（index.html）
- `generate()` 取原始用户输入，**不提前 escHtml()**，直接传入 `generateCampaign()`
- 所有 HTML 转义统一在 `renderResult()` 的每个 `innerHTML` 插入点调用 `escHtml()`
- 这样导出的 Markdown/JSON 是纯文本（无 `&lt;` 等实体），显示层也安全

## History
- 2026-04-30: Converted from Python (app.py) to pure JS. Deleted app.py, created generator.js + cli.js, refactored index.html to load shared module.
- 2026-05-01: Security fix — 修复 XSS 漏洞 + 导出乱码 Bug（过早 escHtml 问题）。打包 v20260501.zip。
- 2026-05-01: v20260502 — 信息准确性修复（算法策略旧版警告/ROI数据免责标注/城市概念区分/爆款天花板说明）；脱敏享库公司名；代码修复（9900硬编码/占位符格式统一/escHtml空值防崩溃）；打包排除 references/images/（29张图片）。
- 2026-05-01: v20260503 — 删除全部"POI开城计划"内容（该功能不存在）：移除开城城市列表、开城节奏报价表、相关说明共4节。
- 2026-05-01: v20260504 — 删除互选广告全部内容（尚未上线）；删除规划中功能正文；零售赛道加未开放标注；转化路径由3种改为2种；删除Pitfalls中空悬报价提示。
- 2026-05-01: v20260506 — 核心升级：5种固化爆款首图模板100%覆盖（瑜伽裤大长腿/聚餐合影/豪车高跟鞋/洗手间自拍/街拍长腿）；新增赛道变量矩阵8赛道×10变量；新增真实探店图片指引（第2-5张）；CLI summary输出全量首图模板；HTML渲染全面重构。
