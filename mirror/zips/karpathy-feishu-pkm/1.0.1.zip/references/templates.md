# karpathy-feishu-pkm 文档模板

## Wiki 文档标准模板

```markdown
# {title}

> **来源**：[{source_title}]({source_url})
> **作者**：{author}
> **整理时间**：{compile_time}
> **标签**：{tags}

---

## 摘要

{auto_summary}

---

## 正文

{structured_content}

---

## 关键概念

- **{concept_name}**：{definition}

---

## 相关链接

- [{doc_title}]({wiki_doc_url}) - {brief_description}

---

## 处理记录

- {ingest_time} 摄入到[收件箱]({raw_doc_url})
- {compile_time} 编译为 Wiki
- 编译者：{compiler_name}

---

*本文档由 AI 自动生成，如有错误请指正*
```

## 索引表记录模板

| 字段 | 值 |
|------|---|
| 标题 | {title} |
| 类型 | {content_type} |
| 来源 | {source_url} |
| 摄入时间 | {ingest_time} |
| 编译时间 | {compile_time} |
| 状态 | {compiled_status} |
| 标签 | {tags} |
| 收件箱链接 | [查看]({raw_doc_url}) |
| {legacy_wiki_link_field} | [查看]({wiki_doc_url}) |
| {primary_wiki_link_field} | [查看]({wiki_doc_url}) |
| 优先级 | {priority} |
| 备注 | {notes} |

> 回写索引总表时，优先更新 `{primary_wiki_link_field}`；如果仍保留 `{legacy_wiki_link_field}`，则两个字段都写入同一个 URL。

## 通知消息格式

### 编译成功

```text
✅ Wiki 编译完成：{title}

📋 编译信息：
   摘要：{summary_preview}
   标签：{tags}
   关键概念：{concepts_count} 个
   相关链接：{links_count} 个

📍 Wiki：[查看文档]({wiki_doc_url})
   原始：[查看原文]({raw_doc_url})

📊 质量评分：{quality_score}/100
```

### 编译完成（待完善）

```text
⚠️ Wiki 编译完成，但需完善：{title}

🔍 待完善项：
   - {issue_1}
   - {issue_2}

📍 查看文档：[Wiki 链接]({wiki_doc_url})
```

### 批量编译报告

```text
📊 批量编译完成

✅ 成功：{success_count}  ⚠️ 待完善：{warning_count}  ❌ 失败：{error_count}

📋 详情：
{details_list}

📍 [{wiki_space_name}]({wiki_space_url})
```

## 目录索引模板

```markdown
# 📚 知识库目录

> 最后更新：{update_time}

---

## 按主题分类

### {topic}
- [{doc_title}]({url}) - {brief}

---

## 最近更新

| 时间 | 文档 | 操作 |
|-----|------|------|
| {time} | {title} | 新增 |

---

## 统计

- 总文档数：{total_count}
- 本月新增：{month_count}
- 待完善：{pending_count}
```

## 使用说明

- 把 `{compiler_name}` 改成你想显示的身份，例如 `Claude`、`AI 助手`、你的团队名
- 把 `{wiki_space_name}` 和 `{wiki_space_url}` 改成接收方自己的 Wiki 信息
- 如果接收方没有旧字段，把 `{legacy_wiki_link_field}` 保留为说明占位符，或删掉该行
