# karpathy-feishu-pkm 配置模板

> 这是分享版模板。请在使用前把下面的占位值替换成你自己的飞书空间、节点、表格和字段配置。

## 快速安装检查

在首次使用前，确认以下条件：

- 已安装并可调用 Feishu 相关工具：`feishu_fetch_doc`、`feishu_create_doc`、`feishu_update_doc`、`feishu_wiki_space_node`、`feishu_bitable_app_table_record`
- Claude 环境有权限访问你的飞书文档、Wiki 和多维表格
- 你的索引表字段名与下方配置一致，或你已经按自己的字段名修改

## 空间配置

| 用途 | 名称 | Space ID | Node Token |
|------|------|----------|------------|
| 来源（收件箱） | `<YOUR_INBOX_SPACE_NAME>` | `<YOUR_INBOX_SPACE_ID>` | `<YOUR_INBOX_NODE_TOKEN>` |
| 目标（Wiki） | `<YOUR_WIKI_SPACE_NAME>` | `<YOUR_WIKI_SPACE_ID>` | `<YOUR_WIKI_NODE_TOKEN>` |

## 索引总表

| 项目 | 值 |
|------|----|
| Base URL | `<YOUR_BITABLE_URL>` |
| Base ID | `<YOUR_BASE_ID>` |
| Table ID | `<YOUR_TABLE_ID>` |
| View ID | `<YOUR_VIEW_ID_OR_EMPTY>` |
| 主链接字段 | `<YOUR_PRIMARY_WIKI_LINK_FIELD>` |
| 兼容旧链接字段 | `<YOUR_LEGACY_WIKI_LINK_FIELD_OR_EMPTY>` |
| 备注字段 | `<YOUR_NOTES_FIELD_OR_EMPTY>` |

## 编译参数

| 参数 | 默认值 | 说明 |
|------|--------|------|
| auto_tag | true | 自动优化标签 |
| create_summary | true | 生成内容摘要 |
| extract_concepts | true | 提取关键概念 |
| build_links | true | 建立内部链接 |
| quality_check | true | 执行质量检查 |
| max_content_length | 50000 | 最大处理长度（字符） |
| rewrite_similarity | 0.8 | 视为同主题并优先改写已有文档 |
| related_similarity_min | 0.5 | 视为相关文档的最小相似度 |
| link_similarity | 0.7 | 建立内部链接的最小相似度 |
| max_links_per_doc | 10 | 每文档最大关联数 |
| batch_size | 10 | 每批处理数量 |
| create_retry_times | 3 | 创建失败时重试次数 |

## 质量检查标准

| 检查项 | 阈值 |
|--------|------|
| 标题长度 | 5–100 字符 |
| 内容长度 | ≥ 100 字符 |
| 必须章节 | 正文、处理记录 |
| 通过分数 | ≥ 70 |

## 命名与分类

- 命名模式：`{title}`（可改为 `{date}-{title}` 等）
- 按主题分文件夹：`AI/`、`产品/`、`技术/`、`商业/`、`个人成长/`、`未分类/`
- 如果你的 Wiki 不按主题分文件夹，可以把这里改成“平铺创建”

## 状态流转

`待编译 → 编译中 → 已编译 / 待完善 / 需人工`

如果你的表格使用不同状态名，请同步修改 skill 中的判断逻辑描述。

## 索引表字段建议

| 字段 | 类型 | 说明 |
|------|------|------|
| 标题 | 文本 | 文档标题 |
| 类型 | 单选 | `article/doc/pdf/image` |
| 来源 | 文本 | 原始链接 |
| 摄入时间 | 日期 | 摄入时间 |
| 编译时间 | 日期 | 编译时间 |
| 状态 | 单选 | 如：待编译/已编译/需人工 |
| 标签 | 多选 | 文档标签 |
| 收件箱链接 | 超链接 | 原始文档 |
| Wiki 链接 | 超链接 | 旧版兼容字段，可选 |
| wiki文档链接 | 超链接 | 主回写字段，推荐 |
| 优先级 | 单选 | 高/中/低 |
| 备注 | 文本 | 用户备注或匹配说明 |

## 关联类型

| 类型 | 说明 | 示例 |
|------|------|------|
| 相关 | 主题相关 | AI 文章 ↔ 机器学习文章 |
| 引用 | 引用关系 | 文章A 引用 文章B |
| 前置 | 前置知识 | 深度学习 ← 神经网络基础 |
| 后续 | 后续内容 | 入门教程 → 进阶教程 |
| 对比 | 对比关系 | 方案A ↔ 方案B |

## 分享建议

- 分享给别人前，不要保留任何真实的 Space ID、Node Token、Base ID、Table ID
- 如果别人没有和你一样的表结构，优先让他们先改这份配置模板
- 如果别人使用不同的飞书工具名，需要一起修改 `SKILL.md`
