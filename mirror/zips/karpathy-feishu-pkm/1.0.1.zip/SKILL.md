---
name: karpathy-feishu-pkm
description: >
  Compile inbox raw documents into structured Wiki pages in Feishu knowledge base.
  Use when the user says "编译/整理/生成 Wiki", asks to process inbox documents,
  update knowledge base index, or build cross-document links.
  Also triggers on "批量编译" or requests to compile multiple pending documents.
  Before creating any document, always search the Wiki space for existing similar
  topics and decide whether to supplement an existing doc or create a new one.
---

# karpathy-feishu-pkm

Shareable version of the Feishu Wiki compilation skill.

Before using this skill, the recipient must fill in their own values in [references/config.md](references/config.md).

**Space config** → see [references/config.md](references/config.md).
**Document templates & notification formats** → see [references/templates.md](references/templates.md).

## Workflow

```text
Read raw doc from inbox → LLM compile → Quality check → Dedup check → Create/Update Wiki doc → Update index → Build links
```

### Single document compile

1. **Read raw document** — Use `feishu_fetch_doc` to fetch content from the configured inbox node token in `references/config.md`. Extract title, source_url, author, ingest_time, tags, user_notes.
2. **LLM compile** — Analyze topic, generate structured content (summary + body), extract key concepts, optimize tags.
3. **Quality check** — Verify the configured quality thresholds from `references/config.md`: title length, content length, required sections, and passing score.
4. **Dedup check (existing doc search)** — Before creating a new document, search the configured target Wiki space for existing docs on the same or highly similar topic:
   - Use `feishu_wiki_space_node` to list child nodes of the configured Wiki space.
   - Compare the compiled doc's title, key concepts, and tags against existing Wiki doc titles and summaries.
   - **Decision logic:**
     - **Similarity ≥ configured rewrite threshold**: → **Supplement/rewrite** the existing doc with `feishu_update_doc`. Merge new content, update tags/links, append to 处理记录.
     - **Similarity within configured related range**: → **Create new doc**, but auto-add a bidirectional link to the existing related doc.
     - **Similarity below related range**: → **Create new doc** as normal.
   - Report the dedup result to the user (which existing doc was found, what action was taken and why).
5. **Create/Update Wiki document** — Based on dedup result:
   - **New doc**: Use `feishu_create_doc` in the configured wiki node. Apply template from [references/templates.md](references/templates.md).
   - **Update existing**: Use `feishu_update_doc` on the matched doc's node_token. Preserve original structure, append new sections, update metadata.
6. **Update index** — Update the configured master index table via `feishu_bitable_app_table_record`:
   - Always target the configured base ID, table ID, and optional view ID.
   - Match the source row for the current document, then update status and compile time fields using the configured field names.
   - If a new Wiki doc was created, write the newly created document URL into the configured primary wiki link field immediately.
   - If the table schema also contains a legacy wiki link field, keep it synchronized with the primary wiki link field using the same URL.
   - If updating an existing doc instead of creating a new one, also backfill the existing Wiki URL into the primary wiki link field, and optionally record the matched doc's node_token in the configured notes field.
   - Never finish a compile run without verifying that the index row contains the final Wiki link.
7. **Build links** — Search existing wiki docs by concepts/tags, add internal links using the configured similarity threshold and link count limit. Update a directory index only if the recipient has enabled one.

### Batch compile

1. Query the configured index table for records with the configured pending status.
2. Process each document sequentially using the configured batch size.
3. For each successful item, update the same index table row and write the generated URL into the configured wiki link field.
4. Generate batch report (success / warning / error counts + details).

## Error handling

| Condition | Action |
|-----------|--------|
| Raw doc not found | Alert user, suggest checking inbox config |
| Content parse failure | Mark configured manual-review status, preserve raw material |
| Quality score below threshold | Create doc anyway, mark configured warning status, alert user |
| Wiki creation API error | Retry up to configured retry count, then cache or report failure |
| Index row missing or link write-back failed | Alert user, keep created wiki URL in output, and mark the run as incomplete until the table link is backfilled |

## Critical rules

- **Always preserve** `source_url` and `raw_doc_url` in the compiled document.
- **Always update** the master index table after creating or updating a Wiki doc.
- **Always backfill** the final Wiki URL into the configured primary wiki link field after a new doc is created.
- **Always check** existing concepts and add internal links when link building is enabled.
- **Always dedup check** before creating a new Wiki doc — never blindly create a new doc without checking.
- **Never assume** the recipient uses your field names, status names, or space layout; always read `references/config.md` first.

## Dependencies

Required Feishu tools:

- `feishu_fetch_doc`
- `feishu_create_doc`
- `feishu_update_doc`
- `feishu_wiki_space_node`
- `feishu_bitable_app_table_record`

If the recipient environment uses different tool names or lacks these integrations, this skill must be adapted before use.

## Related skills

- **REQUIRED:** knowledge-schema (config), knowledge-ingest (data source)
- **NEXT:** knowledge-query (Wiki-based Q&A)
