# karpathy-feishu-pkm

A shareable Claude skill template for building a Feishu-based personal knowledge management workflow.

This package is designed for people who want to:

- collect raw materials in a Feishu inbox
- compile them into structured Wiki pages
- maintain a Bitable index
- create cross-links between related documents

## What is included

- `SKILL.md` — the actual Claude skill behavior
- `references/config.md` — user-editable configuration template
- `references/templates.md` — document, notification, and index templates

## Installation

1. Copy this directory into your Claude skills folder:
   - target path: `~/.claude/skills/karpathy-feishu-pkm`
2. Restart Claude Code if the skill does not appear immediately.
3. Open `references/config.md` and replace all placeholder values.
4. Make sure your Feishu integration tools are available in your environment.

## Required integrations

This skill assumes the following Feishu tools are available:

- `feishu_fetch_doc`
- `feishu_create_doc`
- `feishu_update_doc`
- `feishu_wiki_space_node`
- `feishu_bitable_app_table_record`

If your environment uses different tool names, update `SKILL.md` accordingly.

## Required configuration

Before first use, edit `references/config.md` and fill in:

- inbox space name / ID / node token
- wiki space name / ID / node token
- bitable URL / base ID / table ID / view ID
- primary wiki link field name
- optional legacy field name
- optional notes field name
- any custom status names or thresholds you use

## Recommended setup flow

1. Create or identify a Feishu inbox document space.
2. Create or identify a Feishu Wiki space for compiled knowledge.
3. Create a Bitable table to track ingestion and compilation status.
4. Align your field names with `references/config.md`, or update the template to match your schema.
5. Test with one sample document before running batch compilation.

## How to use

After installation, invoke the skill through natural language requests such as:

- “Compile this inbox document into Wiki.”
- “Batch compile all pending items.”
- “Update the knowledge base index.”
- “Search for similar docs before creating a new Wiki page.”

## Privacy and sharing notes

Before sending this package to someone else:

- remove all real Feishu IDs and node tokens
- remove any real Bitable links
- remove personal names from templates or signatures
- verify that no private workspace URLs remain

## Customization points

The most common things recipients will want to change are:

- field names in the Bitable table
- status values such as pending / compiled / manual review
- similarity thresholds for dedup and linking
- document folder taxonomy
- template language and author signature

## Files to edit

- `SKILL.md`
- `references/config.md`
- `references/templates.md`

## Troubleshooting

- If the skill appears but fails at runtime, check whether the Feishu tools are installed.
- If links are not written back, check table field names and permissions.
- If duplicates are not handled well, tune the similarity thresholds.
- If the skill creates docs in the wrong place, check the configured node tokens.
