---
name: flow-immersion
version: 3.2.3
description: "心流沉浸模式 - 番茄钟 + ADHD陪伴 + 沉浸界面，数据驱动，极简禅意"
homepage: https://github.com/zxjdevs/flow-immersion
author: ZXJ@DEVS
license: MIT
keywords: [flow, immersion, pomodoro, adhd, focus, desktop, wallpaper，专注，心流，番茄钟，学习，备考，勿扰]
metadata:
  clawdbot:
    emoji: "[F]"
    tags: ["flow", "immersion", "pomodoro", "adhd", "focus", "desktop"]
    category: productivity
    requires: {pywin32: "桌面图标控制"}
    optional: {}
    examples:
      - "心流沉浸"
      - "专注模式"
      - "番茄钟"
      - "ADHD陪伴"
---

# 心流时钟 v3.2.3

极简番茄钟 + ADHD陪伴 · FastAPI服务 + H5沉浸界面 · 数据追踪

## 特色亮点

| 特色 | 说明 |
|------|------|
| 禅意界面 | 极简时钟 + 极低UI亮度，计时过程零干扰 |
| ADHD陪伴 | 能量重置 · 紧急重置协议 · 多巴胺菜单 |
| 专注模板 | 4种预设模板（40/25/90/50分钟）+ 自定义 |
| 健康提醒 | 每15~30分钟提醒喝水/护眼/拉伸/姿势/深呼吸 |
| 沉浸控制 | 桌面图标隐藏/壁纸切换/背景音乐 |
| 迷你模式 | 左下角按钮切换，不遮挡工作区域 |
| 数据追踪 | 会话历史 · 连续天数 · 专注评分 |

## 启动

浏览器访问 `http://localhost:8765`

---

## Skill Q&A 工作流（对话中完成配置）

触发后分 2 步：

**Step 1：选择专注模板**

在对话中向用户展示选项，格式如下：

```
请选择专注模板：

1️⃣ 专注模板 — 40分钟专注 / 5分钟休息 / 每20分钟提醒喝水+伸展
2️⃣ 短任务模板 — 25分钟专注 / 3分钟休息 / 每15分钟提醒眨眼+喝水
3️⃣ 创意模板 — 90分钟专注 / 10分钟休息 / 每30分钟提醒起身活动
4️⃣ 学习模板 — 50分钟专注 / 10分钟休息 / 每25分钟提醒调整坐姿+喝水
5️⃣ 自定义模板 — 自由设置专注/休息时长、提醒间隔和内容

请输入数字 1~5，或直接告诉我你的需求（例如：我要60分钟专注，10分钟休息，每20分钟提醒喝水）"
```

用户回复数字或描述 → 解析选择 → 写入 `config.json`：

```python
import json
from pathlib import Path

SKILL_DIR = Path("C:/Users/Administrator/.workbuddy/skills/flow-immersion")
CONFIG_FILE = SKILL_DIR / "config.json"

# 预设模板参数
TEMPLATES = {
    "1": {"focus": 40, "break": 5,  "interval": 20, "msg": "喝水+伸展", "items": ["water","stretch"]},
    "2": {"focus": 25, "break": 3,  "interval": 15, "msg": "眨眼+喝水",   "items": ["water","eye"]},
    "3": {"focus": 90, "break": 10, "interval": 30, "msg": "起身活动",   "items": ["stretch"]},
    "4": {"focus": 50, "break": 10, "interval": 25, "msg": "调整坐姿+喝水","items": ["water","posture"]},
}

# 自定义：解析用户描述，设置对应参数后写入
# ...

cfg = {
    "pomodoro": {"focus_duration": focus, "short_break": brk},
    "reminder": {
        "enabled": True,
        "active_items": items,
        "custom_interval": interval,
        "custom_message": msg,
        "custom_reminders": [{"id": "custom_main", "label": "健康提醒", "msg": msg, "interval": interval}]
    }
}
CONFIG_FILE.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
```

**Step 2：自动弹出沉浸模式 H5 + 告知用户**

```
配置已保存！

「{模板名称}」已就绪：
• 专注 {focus} 分钟 → 休息 {break} 分钟
• 每 {interval} 分钟提醒：{msg}

🚀 沉浸窗口已自动弹出！
```

**自动弹出步骤（Step 2）：**
1. 写入 config.json 后，立即用 Bash 后台启动服务（如果未启动）
2. 立即调用 `curl -X POST http://localhost:8765/api/immersive/launch` 弹出沉浸窗口
3. 如果弹出失败（Playwright Chromium 缺失），改为：
   - 告知用户点击以下链接打开 H5：
     → http://localhost:8765
   - 打开后在禅意菜单中点击「沉浸窗口」按钮弹出沉浸新窗口

---

## 专注模板一览

| 模板 | 专注 | 休息 | 提醒 |
|------|------|------|------|
| 专注模板 | 40分钟 | 5分钟 | 每20分钟：喝水+伸展 |
| 短任务模板 | 25分钟 | 3分钟 | 每15分钟：眨眼+喝水 |
| 创意模板 | 90分钟 | 10分钟 | 每30分钟：起身活动 |
| 学习模板 | 50分钟 | 10分钟 | 每25分钟：调整坐姿+喝水 |
| 自定义模板 | 自由设置 | 自由设置 | 自由设置 |

**自定义模板**支持设置：
- 专注时长（25/40/50/60/90分钟）
- 休息时长（3/5/10/15分钟）
- 提醒间隔（15/20/25/30分钟）
- 提醒内容（自定义文案）

---

## H5 首次引导（无对话配置时）

如果用户未通过对话配置，直接打开 H5：
- 检测到无历史配置 → 自动弹出引导浮层
- 展示与对话相同的 4 个预设模板 + 自定义 Tab
- 用户确认后写入 `config.json`，参数与对话配置完全一致

---

## ADHD 多巴胺菜单

1. 身体活动 - 伸展、跳跃、走动
2. 感官切换 - 换环境、换音乐
3. 小胜利 - 完成一个小任务
4. 外部输入 - 励志短视频
5. 大脑清空 - 写下脑中所有想法
6. 补水 - 喝水，洗把脸
7. 允许休息 - 5分钟什么都不做

---

## 紧急重置-能量重启（60秒）

1. 停止 - 手离开键盘 30秒
2. 呼吸 - 3次深呼吸
3. 提问 - "我在逃避什么？"
4. 缩小 - 把任务缩小10倍
5. 承诺 - "我只做5分钟"
6. 开始 - 从最小步骤开始

---


## 依赖

```bash
pip install fastapi uvicorn pywin32 psutil
```

---

## 启动方式

```bash
cd C:\Users\Administrator\.workbuddy\skills\flow-immersion
python fastapi_server.py
```

---

## 浏览器沉浸模式

**浏览器优先级（--app=无工具栏模式）**：
Playwright Chromium（系统默认） > Chrome > QQBrowser > Edge

> 代码已内置，无需额外配置。
> 所有通过心流时钟启动的 URL 均以 `--app=` 模式打开（无地址栏/无工具栏/无标题栏）。

---

## 健康提醒模板

| ID | 名称 | 间隔 | 内容 |
|----|------|------|------|
| water | 喝水 | 20min | 起身倒杯水，小口慢饮 |
| eye | 护眼 | 20min | 看看窗外远处，让眼睛休息 |
| stretch | 拉伸 | 30min | 站起来伸展双臂，活动颈椎和腰部 |
| posture | 姿势 | 25min | 检查坐姿：背部挺直，肩膀放松 |
| breathe | 呼吸 | 15min | 深呼吸3次：吸气4秒，屏住4秒，呼气6秒 |

---

## 常见问题

**Q: 音乐无法播放？**
A: 检查本地音乐目录路径是否正确，或使用内置生成音（白噪音/粉噪音/雨声）。

**Q: 桌面图标不隐藏？**
A: 需要 pywin32 支持，检查是否安装。

**Q: 提醒不弹出？**
A: 确认 config.json 中 `reminder.enabled: true`，且计时过程中需保持页面可见。

---

## 架构

```
对话 Skill 触发
    ↓
展示专注模板选项（对话Q&A）
    ↓
用户选择 → 写入 data/config.json
    ↓
用户打开 H5 → 检测已有配置 → 直接使用
    （无配置时 → 弹出引导浮层 → 同样写入 config.json）

H5沉浸界面 ← FastAPI(8765)
    ↓
桌面图标 + 壁纸 + 音乐 + 健康提醒
```

## 作者信息
- 作者：ZXJ@DEVS | QQ 1817694478 | Q群 972156177
