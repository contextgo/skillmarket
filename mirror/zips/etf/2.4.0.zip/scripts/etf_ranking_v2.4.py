#!/usr/bin/env python3
"""
ETF v2.4 方案 A+B 优化版
优化:
A. 严格筛选活跃代码（只保留主流 ETF，~1,800 只）
B. 智能跳过空批次（记录历史空批次，避免重复请求）
目标：4.5 秒 → 1.5 秒
"""
import os, sys, time, requests, json, pandas as pd
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List, Dict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from extended_etf_codes import ETF_CODES

# ==================== 配置 ====================
# 主流 ETF 代码前缀（覆盖 99% 实时数据）
MAINSTREAM_PREFIXES = [
    '510', '511', '512', '513', '515', '518',  # 上海
    '1599', '1590', '1591', '1592', '1593',    # 深圳
    '520', '560', '588'  # 其他主流
]

# 空批次记录文件
EMPTY_BATCHES_FILE = os.path.join(os.path.dirname(__file__), 'empty_batches.json')

class EmptyBatchTracker:
    """空批次追踪器 - 记录历史空批次"""
    def __init__(self, cache_file=EMPTY_BATCHES_FILE):
        self.cache_file = cache_file
        self.empty_batches = self._load()
    
    def _load(self):
        try:
            if os.path.exists(self.cache_file):
                with open(self.cache_file, 'r') as f:
                    return set(json.load(f))
        except: pass
        return set()
    
    def save(self):
        try:
            with open(self.cache_file, 'w') as f:
                json.dump(list(self.empty_batches), f)
        except: pass
    
    def mark_empty(self, batch_idx):
        self.empty_batches.add(batch_idx)
        self.save()
    
    def is_empty(self, batch_idx):
        return batch_idx in self.empty_batches
    
    def clear_old(self, max_size=1000):
        """清理过大的记录"""
        if len(self.empty_batches) > max_size:
            self.empty_batches = set(list(self.empty_batches)[-max_size:])
            self.save()

class SimpleCache:
    """简单缓存"""
    def __init__(self, cache_dir, ttl=300):
        self.cache_file = os.path.join(cache_dir, 'etf_cache_v2.4.json')
        self.ttl = ttl
        if not os.path.exists(cache_dir): os.makedirs(cache_dir)
    
    def get(self, code):
        try:
            if not os.path.exists(self.cache_file): return None
            with open(self.cache_file, 'r') as f:
                data = json.load(f)
            if code in data and time.time() - data[code].get('ts', 0) < self.ttl:
                return data[code].get('data')
        except: pass
        return None
    
    def set(self, code, data):
        try:
            cache = {}
            if os.path.exists(self.cache_file):
                with open(self.cache_file, 'r') as f: cache = json.load(f)
            cache[code] = {'data': data, 'ts': time.time()}
            # 清理过期
            now = time.time()
            cache = {k: v for k, v in cache.items() if now - v.get('ts', 0) < self.ttl}
            with open(self.cache_file, 'w') as f: json.dump(cache, f)
        except: pass

class ETFFetcher:
    """ETF 获取器 - v2.4 方案 A+B"""
    def __init__(self, concurrency=20, max_retries=2, cache_ttl=300):
        self.concurrency = concurrency
        self.max_retries = max_retries
        self.cache = SimpleCache('/root/.openclaw/workspace', cache_ttl)
        self.tracker = EmptyBatchTracker()
        self.stats = {'total': 0, 'success': 0, 'failed': 0, 'skipped': 0}
        
        # 方案 A: 严格筛选活跃代码
        self.active_codes = self._get_active_codes()
        print(f"📊 方案 A: 从 {len(ETF_CODES)} 只筛选到 {len(self.active_codes)} 只活跃 ETF")
    
    def _get_active_codes(self):
        """获取活跃 ETF 代码（方案 A 核心）"""
        all_codes = []
        for code in ETF_CODES:
            if code.startswith('sh.'): all_codes.append('sh'+code[3:])
            elif code.startswith('sz.'): all_codes.append('sz'+code[3:])
        
        # 只保留主流前缀
        active = []
        for c in all_codes:
            code_num = c[2:]  # 去掉市场前缀
            if any(code_num.startswith(p) for p in MAINSTREAM_PREFIXES):
                active.append(c)
        
        return active
    
    def fetch_all(self):
        """主获取方法 - 方案 A+B"""
        # 分批
        batch_size = 100
        batches = [self.active_codes[i:i+batch_size] for i in range(0, len(self.active_codes), batch_size)]
        
        # 方案 B: 跳过已知空批次
        filtered_batches = []
        for i, batch in enumerate(batches):
            if self.tracker.is_empty(i):
                self.stats['skipped'] += 1
            else:
                filtered_batches.append((i, batch))
        
        print(f"📋 总计 {len(batches)} 批，跳过 {self.stats['skipped']} 个空批次，查询 {len(filtered_batches)} 批")
        print(f"🚀 并发线程：{self.concurrency}, 重试：{self.max_retries}")
        
        all_data = []
        with ThreadPoolExecutor(max_workers=self.concurrency) as ex:
            futures = {ex.submit(self._fetch_batch, b, i): i for i, b in filtered_batches}
            for f in as_completed(futures):
                i = futures[f]
                self.stats['total'] += 1
                try:
                    r = f.result()
                    if r:
                        all_data.extend(r)
                        self.stats['success'] += 1
                        print(f"  ✅ 批次{i+1}: {len(r)}只")
                    else:
                        self.stats['failed'] += 1
                        # 方案 B: 标记为空批次
                        self.tracker.mark_empty(i)
                        print(f"  ⚠️ 批次{i+1}: 0 只 (已记录)")
                except Exception as e:
                    self.stats['failed'] += 1
                    print(f"  ❌ 批次{i+1}: {str(e)[:40]}")
        
        print(f"\n✅ 获取 {len(all_data)} 条数据，跳过 {self.stats['skipped']} 个空批次")
        return pd.DataFrame(all_data) if all_data else None
    
    def _fetch_batch(self, codes, batch_idx):
        """带重试的单批次获取"""
        if not codes: return []
        
        for attempt in range(self.max_retries):
            try:
                url = f"https://qt.gtimg.cn/q={','.join(codes)}"
                r = requests.get(url, headers={'User-Agent': 'Mozilla/5.0'}, timeout=30)
                r.encoding = 'gbk'
                if r.status_code == 200:
                    data = self._parse(r.text, codes)
                    # 更新缓存
                    for d in data: self.cache.set(d['code'], d)
                    return data
            except Exception as e:
                if attempt < self.max_retries - 1:
                    time.sleep(0.5 * (attempt + 1))
        return []
    
    def _parse(self, text, codes):
        results = []
        try:
            for line in text.strip().split('\n'):
                if '=' in line:
                    parts = line.split('=')
                    if len(parts) >= 2:
                        code = parts[0].split('_')[-1]
                        fields = parts[1].strip('"').split('~')
                        if len(fields) >= 50:
                            try:
                                # 字段 35: 收盘价/成交量/成交额
                                turnover = 0
                                if len(fields) > 35 and fields[35] and '/' in fields[35]:
                                    parts = fields[35].split('/')
                                    if len(parts) >= 3:
                                        turnover = float(parts[2])  # 成交额（元）
                                
                                results.append({
                                    'code': code,
                                    'name': fields[1][:12] if len(fields) > 1 else code,
                                    'close': float(fields[3]) if fields[3] else 0,
                                    'pctChg': float(fields[32]) if fields[32] else 0,
                                    'turnover': turnover
                                })
                            except: pass
        except: pass
        return results

def run(top_n=15):
    print("="*70)
    print("🔍 ETF v2.4 方案 A+B 优化版")
    print(f"📅 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*70)
    
    start = time.time()
    fetcher = ETFFetcher()
    df = fetcher.fetch_all()
    
    if df is None or len(df) == 0:
        print("❌ 无数据")
        return
    
    # 筛选：成交额 > 500 万
    if 'turnover' in df.columns:
        df['turnover'] = pd.to_numeric(df['turnover'], errors='coerce')
        before = len(df)
        df = df[df['turnover'] > 5_000_000]
        after = len(df)
        print(f"📊 成交额筛选（>500 万）: {before} → {after} 只")
    
    # 排名
    df['pctChg'] = pd.to_numeric(df['pctChg'], errors='coerce')
    top_g = df.nlargest(top_n, 'pctChg')
    top_l = df.nsmallest(top_n, 'pctChg')
    
    # 输出
    print(f"\n📈 涨幅 TOP{top_n}")
    for i, (_, r) in enumerate(top_g.iterrows(), 1):
        print(f"  {i}. {r['code']} {r['name']}: {r['close']:.3f} ({r['pctChg']:+.2f}%)")
    
    print(f"\n📉 跌幅 TOP{top_n}")
    for i, (_, r) in enumerate(top_l.iterrows(), 1):
        print(f"  {i}. {r['code']} {r['name']}: {r['close']:.3f} ({r['pctChg']:+.2f}%)")
    
    elapsed = time.time() - start
    print(f"\n⏱️  耗时：{elapsed:.2f}秒")
    print(f"🚀 对比：v2.1=25.36 秒，v2.2=3.7 秒，v2.3=4.53 秒")
    print(f"📈 提速：{25.36/elapsed:.1f}x vs v2.1, {3.7/elapsed:.1f}x vs v2.2")
    print("="*70)

if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument('--top', type=int, default=15)
    args = p.parse_args()
    run(args.top)
