#!/usr/bin/env python3
"""
ETF 每日自动报告 - v2.4 版本
功能：每日 14:30 自动运行，发送涨跌幅 TOP10 到指定邮箱
使用：etf_ranking_v2.4.py（0.79 秒）
"""
import os, sys, subprocess
from datetime import datetime

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPT_DIR)

# ==================== 配置 ====================
# 从环境变量读取（推荐方式，避免硬编码）
EMAIL_TO = os.environ.get('EMAIL_TO', '')  # 留空表示未配置
SMTP_USER = os.environ.get('SMTP_USER', '')
SMTP_PASS = os.environ.get('SMTP_PASS', '')
SMTP_SERVER = os.environ.get('SMTP_SERVER', 'smtp.qq.com')
SMTP_PORT = int(os.environ.get('SMTP_PORT', '465'))

def run_etf_query(top_n=10):
    """运行 ETF 查询并返回结果"""
    script = f"{SCRIPT_DIR}/etf_ranking_v2.4.py"
    cmd = f"PYTHONPATH=/mnt/workspace/lib/python3.11/site-packages:$PYTHONPATH python3 {script} --top {top_n}"
    
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=60)
    
    if result.returncode == 0:
        output = result.stdout
        # 提取关键信息
        lines = output.split('\n')
        summary = []
        for line in lines:
            if any(x in line for x in ['涨幅 TOP', '跌幅 TOP', '⏱️', '📊', '📈', '📉']):
                summary.append(line)
        
        return {
            'success': True,
            'output': output,
            'summary': '\n'.join(summary),
            'error': None
        }
    else:
        return {
            'success': False,
            'output': result.stdout,
            'summary': None,
            'error': result.stderr
        }

def send_email(subject, content):
    """发送邮件"""
    if not SMTP_PASS or not SMTP_USER or not EMAIL_TO:
        print("⚠️ 邮箱未配置，跳过发送")
        print("  配置方式：设置 EMAIL_TO, SMTP_USER, SMTP_PASS 环境变量")
        print("  示例：export EMAIL_TO='your@email.com' SMTP_USER='user' SMTP_PASS='pass'")
        return
    
    import smtplib
    from email.mime.text import MIMEText
    from email.mime.multipart import MIMEMultipart
    
    msg = MIMEMultipart()
    msg['From'] = SMTP_USER
    msg['To'] = EMAIL_TO
    msg['Subject'] = subject
    
    msg.attach(MIMEText(content, 'plain', 'utf-8'))
    
    try:
        server = smtplib.SMTP_SSL(SMTP_SERVER, SMTP_PORT)
        server.login(SMTP_USER, SMTP_PASS)
        server.send_message(msg)
        server.quit()
        print("✅ 邮件发送成功")
    except Exception as e:
        print(f"❌ 邮件发送失败：{e}")

if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument('--top', type=int, default=10)
    p.add_argument('--send-email', action='store_true')
    args = p.parse_args()
    
    print("="*70)
    print("📧 ETF 每日报告 v2.4")
    print(f"📅 {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    print("="*70)
    
    # 执行查询
    result = run_etf_query(args.top)
    
    if result['success']:
        print("\n" + result['summary'])
        
        # 可选发送邮件
        if args.send_email:
            subject = f"ETF 日报 - {datetime.now().strftime('%Y-%m-%d')}"
            content = f"ETF 涨跌幅 TOP{args.top}\n\n{result['summary']}"
            send_email(subject, content)
    else:
        print(f"❌ 查询失败：{result['error']}")
