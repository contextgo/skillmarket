#!/bin/bash
# ETF 快速查询脚本 v2.4
# 使用：./etf.sh 或 ./etf.sh --top 10
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHONPATH=/mnt/workspace/lib/python3.11/site-packages:$PYTHONPATH python3 "$SCRIPT_DIR/scripts/etf_ranking_v2.4.py" "$@"
