# ETF 每日自动任务安装说明

## 📋 自动任务配置

### 方案 1：使用系统 Cron（推荐）

**步骤 1**: 打开 crontab
```bash
crontab -e
```

**步骤 2**: 添加以下行（每日 14:30 运行，仅限交易日）
```bash
# ETF 每日报告（周一至周五 14:30）
30 14 * * 1-5 cd /root/.openclaw/skills/etf-analysis && PYTHONPATH=/mnt/workspace/lib/python3.11/site-packages:$PYTHONPATH python3 scripts/etf_ranking_v2.4.py --top 10 >> /tmp/etf_daily.log 2>&1
```

**步骤 3**: 验证
```bash
crontab -l  # 查看已安装的任务
```

### 方案 2：使用 OpenClaw 定时任务

如果 OpenClaw 支持定时任务，可在配置中添加：
```json
{
  "scheduled_tasks": [
    {
      "name": "etf_daily_report",
      "schedule": "30 14 * * 1-5",
      "command": "python3 /root/.openclaw/skills/etf-analysis/scripts/etf_daily_report_v2.4.py --top 10"
    }
  ]
}
```

## 🚀 快速启动

### 手动运行
```bash
# 方式 1：使用启动脚本
cd /root/.openclaw/skills/etf-analysis
./etf.sh

# 方式 2：直接运行
python3 /root/.openclaw/skills/etf-analysis/scripts/etf_ranking_v2.4.py

# 方式 3：指定数量
python3 /root/.openclaw/skills/etf-analysis/scripts/etf_ranking_v2.4.py --top 20
```

### 发送邮件报告
```bash
# 设置邮箱环境变量
export EMAIL_TO="980244057@qq.com"
export SMTP_USER="980244057@qq.com"
export SMTP_PASS="your_auth_code"

# 运行并发送
python3 /root/.openclaw/skills/etf-analysis/scripts/etf_daily_report_v2.4.py --top 10 --send-email
```

## 📊 性能监控

查看运行日志：
```bash
tail -f /tmp/etf_daily.log
```

查看历史运行时间：
```bash
grep "⏱️" /tmp/etf_daily.log | tail -10
```

## ✅ 验证安装

运行测试：
```bash
cd /root/.openclaw/skills/etf-analysis
./etf.sh --top 5
```

预期输出：
- ✅ 显示 "📊 方案 A: 从 6161 只筛选到 830 只活跃 ETF"
- ✅ 耗时 < 1 秒
- ✅ 显示涨跌幅 TOP5

## 📁 文件清单

| 文件 | 说明 |
|------|------|
| `scripts/etf_ranking_v2.4.py` | v2.4 主程序 |
| `scripts/etf_ranking_pro.py` | 软链接（指向 v2.4） |
| `scripts/etf_daily_report_v2.4.py` | 每日报告脚本 |
| `etf.sh` | 快速启动脚本 |
| `INSTALL_CRON.md` | 本文档 |

## 🎯 运行时间

- **首次运行**: ~1 秒
- **后续运行**: 可能更快（缓存命中）
- **最佳时间**: 交易日 14:30（收盘后）

## 📞 故障排查

### 问题 1: 运行超时
**解决**: 检查网络连接，腾讯财经接口是否可访问

### 问题 2: 数据为 0
**解决**: 检查是否为非交易日或收盘后时间

### 问题 3: 邮件发送失败
**解决**: 检查 SMTP 配置，确认授权码正确

---

**最后更新**: 2026-04-19  
**版本**: v2.4  
**性能**: 0.95 秒完成查询
