const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const videoData = JSON.parse(fs.readFileSync(path.join(__dirname, '../video_data.json'), 'utf-8'));
const audioDir = path.join(__dirname, '../public/audio');

// 确保音频目录存在
if (!fs.existsSync(audioDir)) {
  fs.mkdirSync(audioDir, { recursive: true });
}

/**
 * 方式 1: 使用 node-edge-tts npm 包（推荐）
 * 返回 { success: boolean, duration: number|null }
 */
async function generateWithNpmPackage(text, outputPath, voice = 'zh-CN-XiaoxiaoNeural') {
  try {
    const { EdgeTTS } = require('node-edge-tts');

    // 生成字幕文件路径（node-edge-tts 保存为 {audio}.json）
    const subtitlePath = outputPath + '.json';

    const tts = new EdgeTTS({
      voice: voice,
      lang: 'zh-CN',
      outputFormat: 'audio-24khz-48kbitrate-mono-mp3',
      rate: '+0%',
      pitch: '+0Hz',
      saveSubtitles: true  // 保存字幕文件，用于获取时长
    });

    await tts.ttsPromise(text, outputPath);

    // 从字幕文件获取时长
    let duration = null;
    if (fs.existsSync(subtitlePath)) {
      try {
        const subtitles = JSON.parse(fs.readFileSync(subtitlePath, 'utf-8'));
        // 最后一个词的 end 时间就是总时长（毫秒）
        if (Array.isArray(subtitles) && subtitles.length > 0) {
          const lastItem = subtitles[subtitles.length - 1];
          duration = lastItem.end / 1000; // 转换为秒
        }
        // 删除字幕文件（不需要保留）
        fs.unlinkSync(subtitlePath);
      } catch (e) {
        // 字幕解析失败，返回 null，后续用 ffprobe
      }
    }

    return { success: true, duration };
  } catch (error) {
    return { success: false, duration: null };
  }
}

/**
 * 方式 2: 使用 Python edge-tts 命令行工具（备用）
 */
function detectPythonEdgeTts() {
  const commands = ['edge-tts', 'python -m edge_tts', 'python3 -m edge_tts'];

  for (const cmd of commands) {
    try {
      execSync(`${cmd} --version`, { stdio: 'pipe', timeout: 5000 });
      return cmd;
    } catch (e) {
      // 继续尝试下一个命令
    }
  }
  return null;
}

function generateWithPythonEdgeTts(text, outputPath, edgeTtsCmd, voice = 'zh-CN-XiaoxiaoNeural') {
  // 使用单引号包裹文本，转义内部单引号
  const escapedText = "'" + text.replace(/'/g, "'\\''") + "'";

  const command = `${edgeTtsCmd} --voice "${voice}" --text ${escapedText} --write-media "${outputPath}"`;

  execSync(command, {
    stdio: 'pipe',
    timeout: 30000,
    shell: process.platform === 'win32' ? 'cmd.exe' : undefined
  });

  return fs.existsSync(outputPath);
}

/**
 * 使用 ffprobe 获取音频时长（备用方案）
 */
function getAudioDurationWithFfprobe(audioPath) {
  try {
    const durationStr = execSync(
      `ffprobe -i "${audioPath}" -show_entries format=duration -v quiet -of csv="p=0"`,
      { encoding: 'utf-8', shell: process.platform === 'win32' ? 'cmd.exe' : undefined }
    ).toString().trim();

    return parseFloat(durationStr);
  } catch (error) {
    return null;
  }
}

/**
 * 检测 ffprobe
 */
function checkFfprobe() {
  try {
    execSync('ffprobe -version', { stdio: 'pipe' });
    return true;
  } catch (e) {
    return false;
  }
}

/**
 * 生成单个场景的语音
 */
async function generateSceneAudio(scene, index, useNpm, pythonCmd, hasFfprobe) {
  if (!scene.narration) {
    console.log(`场景 ${index + 1}: 无解说文本，使用默认时长 3 秒`);
    return { id: scene.id, duration: 3 };
  }

  const audioPath = path.join(audioDir, `${scene.id}.mp3`);

  console.log(`\n生成语音: ${scene.id}`);
  console.log(`文本: ${scene.narration.substring(0, 50)}...`);

  let success = false;
  let duration = null;

  // 优先使用 npm 包
  if (useNpm) {
    console.log('使用 node-edge-tts npm 包...');
    const result = await generateWithNpmPackage(scene.narration, audioPath);
    success = result.success;
    duration = result.duration;

    if (!success) {
      console.log('npm 包不可用，尝试 Python edge-tts...');
    } else if (duration) {
      console.log(`✅ 从字幕获取时长: ${duration.toFixed(2)} 秒`);
    }
  }

  // 回退到 Python edge-tts
  if (!success && pythonCmd) {
    console.log(`使用 Python edge-tts (${pythonCmd})...`);
    try {
      success = generateWithPythonEdgeTts(scene.narration, audioPath, pythonCmd);
    } catch (error) {
      console.error(`Python edge-tts 失败: ${error.message}`);
    }
  }

  if (!success) {
    console.error('❌ 所有 TTS 方式都失败');
    return { id: scene.id, duration: 5 };
  }

  // 检查文件是否生成
  if (!fs.existsSync(audioPath)) {
    console.error('❌ 音频文件未生成');
    return { id: scene.id, duration: 5 };
  }

  // 如果 npm 包没有返回时长，尝试 ffprobe
  if (duration === null) {
    if (hasFfprobe) {
      duration = getAudioDurationWithFfprobe(audioPath);
      if (duration !== null) {
        console.log(`✅ 从 ffprobe 获取时长: ${duration.toFixed(2)} 秒`);
      }
    }

    // 如果还是没有时长，使用默认值
    if (duration === null) {
      console.log('⚠️  无法获取音频时长，使用默认 5 秒');
      duration = 5;
    }
  }

  // 添加 0.5 秒缓冲
  return {
    id: scene.id,
    duration: Math.ceil(duration + 0.5),
    audioFile: `${scene.id}.mp3`
  };
}

// 主流程
async function main() {
  console.log('========================================');
  console.log('BytePlan 视频语音生成工具');
  console.log('========================================\n');

  // 检测 TTS 工具
  let useNpm = false;
  let pythonCmd = null;

  // 检测 npm 包
  try {
    require('node-edge-tts');
    useNpm = true;
    console.log('✅ 检测到 node-edge-tts npm 包');
  } catch (e) {
    console.log('⚠️  未检测到 node-edge-tts npm 包');
  }

  // 检测 Python edge-tts
  pythonCmd = detectPythonEdgeTts();
  if (pythonCmd) {
    console.log(`✅ 检测到 Python edge-tts: ${pythonCmd}`);
  } else {
    console.log('⚠️  未检测到 Python edge-tts');
  }

  // 如果两者都没有
  if (!useNpm && !pythonCmd) {
    console.error('\n❌ 未检测到任何 TTS 工具，请安装其中一种:');
    console.error('');
    console.error('方式 1: 安装 npm 包（推荐，无需额外依赖）');
    console.error('  npm install node-edge-tts');
    console.error('  或');
    console.error('  pnpm add node-edge-tts');
    console.error('');
    console.error('方式 2: 安装 Python edge-tts');
    console.error('  pip install edge-tts');
    console.error('  或');
    console.error('  pip3 install edge-tts');
    process.exit(1);
  }

  // 检测 ffprobe（可选，仅 Python edge-tts 需要）
  const hasFfprobe = checkFfprobe();
  if (hasFfprobe) {
    console.log('✅ 检测到 ffprobe（备用）');
  } else {
    if (!useNpm && pythonCmd) {
      // 只有在使用 Python edge-tts 时才需要 ffprobe
      console.error('❌ 使用 Python edge-tts 需要安装 ffprobe:');
      console.error('  Windows: choco install ffmpeg');
      console.error('  macOS: brew install ffmpeg');
      console.error('  Linux: sudo apt install ffmpeg');
      console.error('');
      console.error('或者使用 npm 包（node-edge-tts），无需 ffprobe');
      process.exit(1);
    }
    console.log('⚠️  未检测到 ffprobe（npm 包模式下不影响使用）');
  }

  console.log('\n开始生成语音...\n');

  // 生成所有场景的语音
  const sceneDurations = [];
  for (let i = 0; i < videoData.scenes.length; i++) {
    const result = await generateSceneAudio(videoData.scenes[i], i, useNpm, pythonCmd, hasFfprobe);
    sceneDurations.push(result);
  }

  // 保存时长配置
  const durationsPath = path.join(__dirname, '../scene_durations.json');
  fs.writeFileSync(durationsPath, JSON.stringify(sceneDurations, null, 2));

  console.log('\n========================================');
  console.log('所有语音生成完成！');
  console.log('场景时长配置已保存到 scene_durations.json');
  console.log('\n时长汇总:');
  sceneDurations.forEach((s, i) => {
    console.log(`  ${i + 1}. ${s.id}: ${s.duration} 秒`);
  });
  const totalDuration = sceneDurations.reduce((sum, s) => sum + s.duration, 0);
  console.log(`\n总时长: ${totalDuration} 秒 (${Math.floor(totalDuration / 60)}分${totalDuration % 60}秒)`);
}

main().catch(console.error);