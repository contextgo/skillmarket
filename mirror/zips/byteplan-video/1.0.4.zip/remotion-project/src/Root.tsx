import { Composition, staticFile } from "remotion";
import { DynamicReport } from "./DynamicReport";
import videoData from "../video_data.json";
import sceneDurations from "../scene_durations.json";

// 计算总帧数
const fps = 30;

// 合并场景时长信息
const slidesWithData = videoData.scenes.map((scene, index) => {
  const durationInfo = sceneDurations.find(s => s.id === scene.id);
  return {
    ...scene,
    duration: durationInfo?.duration || scene.duration || 10,
    audioFile: durationInfo?.audioFile || `${scene.id}.mp3`
  };
});

// 计算总帧数和每个场景的帧范围
let currentFrame = 0;
const slideData = slidesWithData.map((s) => {
  const startFrame = currentFrame;
  currentFrame += s.duration * fps;
  return {
    ...s,
    startFrame,
    endFrame: currentFrame
  };
});

const totalFrames = currentFrame;

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition
        id="SalesReport"
        component={DynamicReport}
        durationInFrames={totalFrames}
        fps={fps}
        width={1920}
        height={1080}
        defaultProps={{
          slides: slideData,
          chartData: videoData.chartData,
          period: videoData.period
        }}
      />
    </>
  );
};