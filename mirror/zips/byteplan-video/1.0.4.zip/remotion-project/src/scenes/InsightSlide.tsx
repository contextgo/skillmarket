import {
  AbsoluteFill,
  useCurrentFrame,
  interpolate,
  spring,
} from "remotion";

interface InsightSlideProps {
  title: string;
  insights: Array<{ title: string; content: string; warning?: boolean }>;
}

export const InsightSlide: React.FC<InsightSlideProps> = ({ title, insights }) => {
  const frame = useCurrentFrame();

  const titleOpacity = interpolate(frame, [0, 20], [0, 1], { extrapolateRight: "clamp" });

  // 根据 insights 数量决定布局
  const gridCols = insights.length <= 3 ? 1 : 2;
  const gridRows = Math.ceil(insights.length / gridCols);

  return (
    <AbsoluteFill
      style={{
        background: "linear-gradient(135deg, #1a1a2e 0%, #16213e 100%)",
        justifyContent: "center",
        alignItems: "center",
        flexDirection: "column",
        padding: 60,
      }}
    >
      <div
        style={{
          fontSize: 48,
          fontWeight: "bold",
          color: "#fff",
          marginBottom: 50,
          opacity: titleOpacity,
        }}
      >
        💡 {title}
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: gridCols === 1 ? "1fr" : "1fr 1fr",
          gap: 25,
          width: gridCols === 1 ? 800 : 1200,
        }}
      >
        {insights.map((insight, index) => {
          const delay = 20 + index * 12;
          const scale = spring({
            frame: frame - delay,
            fps: 30,
            config: { damping: 100, stiffness: 200 },
          });
          const opacity = interpolate(frame, [delay, delay + 20], [0, 1], { extrapolateRight: "clamp" });

          return (
            <div
              key={index}
              style={{
                background: insight.warning
                  ? "rgba(251,191,36,0.15)"
                  : "rgba(255,255,255,0.1)",
                borderRadius: 18,
                padding: 30,
                borderLeft: `5px solid ${insight.warning ? "#fbbf24" : "#667eea"}`,
                opacity,
                transform: `scale(${scale})`,
              }}
            >
              {insight.title && (
                <div
                  style={{
                    fontSize: 26,
                    fontWeight: "bold",
                    color: insight.warning ? "#fbbf24" : "#fff",
                    marginBottom: 12,
                  }}
                >
                  {insight.title}
                </div>
              )}
              <div style={{ 
                fontSize: 20, 
                color: "#CBD5E1", 
                lineHeight: 1.6,
                fontWeight: insight.title ? "normal" : "bold"
              }}>
                {insight.content}
              </div>
            </div>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};