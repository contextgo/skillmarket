import {
  AbsoluteFill,
  useCurrentFrame,
  interpolate,
  spring,
} from "remotion";

interface KpiSlideProps {
  title: string;
  kpis: Array<{ icon: string; label: string; value: string }>;
}

export const KpiSlide: React.FC<KpiSlideProps> = ({ title, kpis }) => {
  const frame = useCurrentFrame();

  const titleOpacity = interpolate(frame, [0, 20], [0, 1], { extrapolateRight: "clamp" });

  return (
    <AbsoluteFill
      style={{
        background: "linear-gradient(135deg, #0f3460 0%, #16213e 100%)",
        justifyContent: "center",
        alignItems: "center",
        flexDirection: "column",
        padding: 60,
      }}
    >
      <div
        style={{
          fontSize: 44,
          fontWeight: "bold",
          color: "#fff",
          marginBottom: 60,
          opacity: titleOpacity,
        }}
      >
        📈 {title}
      </div>

      <div
        style={{
          display: "flex",
          flexDirection: "row",
          gap: 40,
          justifyContent: "center",
        }}
      >
        {kpis.map((kpi, index) => {
          const delay = 20 + index * 15;
          const scale = spring({
            frame: frame - delay,
            fps: 30,
            config: { damping: 100, stiffness: 200 },
          });
          const opacity = interpolate(frame, [delay, delay + 20], [0, 1], { extrapolateRight: "clamp" });

          return (
            <div
              key={index}
              style={{
                background: "rgba(255,255,255,0.1)",
                borderRadius: 20,
                padding: 40,
                textAlign: "center",
                border: "2px solid rgba(255,255,255,0.2)",
                width: 280,
                opacity,
                transform: `scale(${scale})`,
              }}
            >
              <div style={{ fontSize: 48, marginBottom: 20 }}>{kpi.icon}</div>
              <div style={{ fontSize: 18, color: "#94A3B8", marginBottom: 12 }}>
                {kpi.label}
              </div>
              <div style={{ fontSize: 36, fontWeight: "bold", color: "#4ade80" }}>
                {kpi.value}
              </div>
            </div>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};