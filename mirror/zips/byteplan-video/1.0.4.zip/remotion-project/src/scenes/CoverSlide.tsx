import {
  AbsoluteFill,
  useCurrentFrame,
  interpolate,
} from "remotion";

interface CoverSlideProps {
  title: string;
  subtitle: string;
}

export const CoverSlide: React.FC<CoverSlideProps> = ({ title, subtitle }) => {
  const frame = useCurrentFrame();

  const titleOpacity = interpolate(frame, [0, 30], [0, 1], { extrapolateRight: "clamp" });
  const subtitleOpacity = interpolate(frame, [30, 60], [0, 1], { extrapolateRight: "clamp" });

  return (
    <AbsoluteFill
      style={{
        background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
        justifyContent: "center",
        alignItems: "center",
        flexDirection: "column",
      }}
    >
      <div
        style={{
          fontSize: 64,
          fontWeight: "bold",
          color: "#fff",
          textAlign: "center",
          opacity: titleOpacity,
          marginBottom: 40,
        }}
      >
        📊 {title}
      </div>
      <div
        style={{
          fontSize: 32,
          color: "rgba(255,255,255,0.9)",
          textAlign: "center",
          opacity: subtitleOpacity,
        }}
      >
        {subtitle}
      </div>
      <div
        style={{
          fontSize: 18,
          color: "rgba(255,255,255,0.6)",
          marginTop: 60,
          opacity: subtitleOpacity,
        }}
      >
        2026年4月1日 · 跨境电商租户
      </div>
    </AbsoluteFill>
  );
};