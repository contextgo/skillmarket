import {
  AbsoluteFill,
  useCurrentFrame,
  interpolate,
} from "remotion";

interface ChartSlideProps {
  title: string;
  chartType: string;
  data: Array<{ name: string; value: number }>;
}

const COLORS = ["#667eea", "#4ade80", "#f472b6", "#fbbf24", "#06B6D4"];

export const ChartSlide: React.FC<ChartSlideProps> = ({
  title,
  chartType,
  data,
}) => {
  const frame = useCurrentFrame();

  const titleOpacity = interpolate(frame, [0, 20], [0, 1], { extrapolateRight: "clamp" });

  if (chartType === "pie") {
    // 饼图
    const total = data.reduce((sum, d) => sum + d.value, 0);
    const radius = 180;
    const svgSize = 400;
    const cx = svgSize / 2;
    const cy = svgSize / 2;

    let cumulativeAngle = 0;
    const slices = data.map((d, i) => {
      const angle = (d.value / total) * 360;
      const startAngle = cumulativeAngle;
      cumulativeAngle += angle;
      return { ...d, startAngle, angle, color: COLORS[i % COLORS.length] };
    });

    const pieOpacity = interpolate(frame, [20, 50], [0, 1], { extrapolateRight: "clamp" });

    return (
      <AbsoluteFill
        style={{
          background: "linear-gradient(135deg, #16213e 0%, #1a1a2e 100%)",
          justifyContent: "center",
          alignItems: "center",
          flexDirection: "column",
        }}
      >
        <div
          style={{
            fontSize: 44,
            fontWeight: "bold",
            color: "#fff",
            marginBottom: 50,
            opacity: titleOpacity,
          }}
        >
          📦 {title}
        </div>

        <div style={{ display: "flex", flexDirection: "row", gap: 80, alignItems: "center", opacity: pieOpacity }}>
          {/* 饼图 SVG */}
          <svg width={svgSize} height={svgSize}>
            {slices.map((slice, i) => {
              const startRad = (slice.startAngle - 90) * (Math.PI / 180);
              const endRad = (slice.startAngle + slice.angle - 90) * (Math.PI / 180);
              const x1 = cx + radius * Math.cos(startRad);
              const y1 = cy + radius * Math.sin(startRad);
              const x2 = cx + radius * Math.cos(endRad);
              const y2 = cy + radius * Math.sin(endRad);
              const largeArc = slice.angle > 180 ? 1 : 0;

              return (
                <path
                  key={i}
                  d={`M ${cx} ${cy} L ${x1} ${y1} A ${radius} ${radius} 0 ${largeArc} 1 ${x2} ${y2} Z`}
                  fill={slice.color}
                  stroke="#fff"
                  strokeWidth={2}
                />
              );
            })}
          </svg>

          {/* 图例 */}
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            {data.map((d, i) => (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: 16 }}>
                <div
                  style={{
                    width: 24,
                    height: 24,
                    borderRadius: 4,
                    background: COLORS[i % COLORS.length],
                  }}
                />
                <div style={{ fontSize: 20, color: "#fff", width: 100 }}>{d.name}</div>
                <div style={{ fontSize: 18, color: "#4ade80" }}>
                  ¥{d.value.toLocaleString()}
                </div>
              </div>
            ))}
          </div>
        </div>
      </AbsoluteFill>
    );
  }

  // 柱状图
  const maxValue = Math.max(...data.map((d) => d.value));
  const barWidth = 140;
  const barGap = 40;
  const chartHeight = 400;

  return (
    <AbsoluteFill
      style={{
        background: "linear-gradient(135deg, #1a1a2e 0%, #16213e 100%)",
        justifyContent: "center",
        alignItems: "center",
        flexDirection: "column",
      }}
    >
      <div
        style={{
          fontSize: 44,
          fontWeight: "bold",
          color: "#fff",
          marginBottom: 60,
          opacity: titleOpacity,
        }}
      >
        {title.includes("渠道") ? "🛒" : "🗺️"} {title}
      </div>

      {/* 图表容器 - 居中 */}
      <div
        style={{
          display: "flex",
          flexDirection: "row",
          alignItems: "flex-end",
          gap: barGap,
          justifyContent: "center",
        }}
      >
        {data.map((d, i) => {
          const barHeight = (d.value / maxValue) * chartHeight;
          const delay = 20 + i * 10;
          const animatedHeight = interpolate(
            frame,
            [delay, delay + 30],
            [0, barHeight],
            { extrapolateRight: "clamp" }
          );
          const opacity = interpolate(frame, [delay, delay + 20], [0, 1], { extrapolateRight: "clamp" });

          return (
            <div
              key={i}
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                opacity,
                width: barWidth,
              }}
            >
              {/* 数值 */}
              <div
                style={{
                  fontSize: 24,
                  fontWeight: "bold",
                  color: "#4ade80",
                  marginBottom: 10,
                }}
              >
                {maxValue <= 100 ? `${d.value}%` : `¥${(d.value / 1000).toFixed(0)}k`}
              </div>
              {/* 柱状条 */}
              <div
                style={{
                  width: barWidth,
                  height: animatedHeight,
                  background: `linear-gradient(180deg, ${COLORS[i]} 0%, ${COLORS[i]}80 100%)`,
                  borderRadius: 8,
                  boxShadow: `0 4px 20px ${COLORS[i]}40`,
                }}
              />
              {/* 标签 */}
              <div style={{ fontSize: 22, color: "#fff", marginTop: 16 }}>
                {d.name}
              </div>
            </div>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};