import {
  AbsoluteFill,
  useCurrentFrame,
  interpolate,
} from "remotion";

interface EndSlideProps {
  title: string;
  subtitle: string;
}

export const EndSlide: React.FC<EndSlideProps> = ({ title, subtitle }) => {
  const frame = useCurrentFrame();

  const titleOpacity = interpolate(frame, [0, 30], [0, 1], { extrapolateRight: "clamp" });
  const subtitleOpacity = interpolate(frame, [30, 60], [0, 1], { extrapolateRight: "clamp" });

  return (
    <AbsoluteFill
      style={{
        background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
        justifyContent: "center",
        alignItems: "center",
        flexDirection: "column",
      }}
    >
      <div
        style={{
          fontSize: 52,
          fontWeight: "bold",
          color: "#fff",
          textAlign: "center",
          opacity: titleOpacity,
        }}
      >
        📊 {title}
      </div>
      <div
        style={{
          fontSize: 28,
          color: "rgba(255,255,255,0.8)",
          marginTop: 30,
          opacity: subtitleOpacity,
        }}
      >
        {subtitle}
      </div>
      <div
        style={{
          fontSize: 18,
          color: "rgba(255,255,255,0.6)",
          marginTop: 50,
          opacity: subtitleOpacity,
        }}
      >
        BytePlan 数据平台
      </div>
    </AbsoluteFill>
  );
};