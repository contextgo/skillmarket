import {
  AbsoluteFill,
  useCurrentFrame,
  interpolate,
  spring,
} from "remotion";

interface RecommendationSlideProps {
  title: string;
  recommendations: string[];
  source?: string;
}

export const RecommendationSlide: React.FC<RecommendationSlideProps> = ({
  title,
  recommendations,
  source,
}) => {
  const frame = useCurrentFrame();

  const titleOpacity = interpolate(frame, [0, 20], [0, 1], { extrapolateRight: "clamp" });

  // 根据建议数量决定布局
  const gridCols = recommendations.length <= 2 ? 1 : Math.min(recommendations.length, 2);
  const gridRows = Math.ceil(recommendations.length / gridCols);

  return (
    <AbsoluteFill
      style={{
        background: "linear-gradient(135deg, #0f3460 0%, #16213e 100%)",
        justifyContent: "center",
        alignItems: "center",
        flexDirection: "column",
        padding: 60,
      }}
    >
      <div
        style={{
          fontSize: 48,
          fontWeight: "bold",
          color: "#fff",
          marginBottom: 50,
          opacity: titleOpacity,
        }}
      >
        🎯 {title}
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: gridCols === 1 ? "1fr" : "1fr 1fr",
          gap: 25,
          width: gridCols === 1 ? 800 : 1200,
        }}
      >
        {recommendations.map((rec, index) => {
          const delay = 20 + index * 12;
          const scale = spring({
            frame: frame - delay,
            fps: 30,
            config: { damping: 100, stiffness: 200 },
          });
          const opacity = interpolate(frame, [delay, delay + 20], [0, 1], { extrapolateRight: "clamp" });

          return (
            <div
              key={index}
              style={{
                background: "rgba(74,222,128,0.15)",
                borderRadius: 18,
                padding: 30,
                borderLeft: "5px solid #4ade80",
                opacity,
                transform: `scale(${scale})`,
              }}
            >
              <div style={{ fontSize: 22, color: "#fff", lineHeight: 1.6 }}>
                {rec}
              </div>
            </div>
          );
        })}
      </div>

      {source && (
        <div
          style={{
            fontSize: 16,
            color: "#94A3B8",
            marginTop: 40,
            opacity: interpolate(frame, [60, 80], [0, 1], { extrapolateRight: "clamp" }),
          }}
        >
          数据来源：{source}
        </div>
      )}
    </AbsoluteFill>
  );
};