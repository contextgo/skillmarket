import {
  AbsoluteFill,
  useCurrentFrame,
  useVideoConfig,
  Audio,
  staticFile,
  Sequence,
} from "remotion";
import { CoverSlide } from "./scenes/CoverSlide";
import { KpiSlide } from "./scenes/KpiSlide";
import { ChartSlide } from "./scenes/ChartSlide";
import { InsightSlide } from "./scenes/InsightSlide";
import { RecommendationSlide } from "./scenes/RecommendationSlide";
import { EndSlide } from "./scenes/EndSlide";

interface SlideData {
  id: string;
  duration: number;
  audioFile: string;
  startFrame: number;
  endFrame: number;
}

interface SalesReportProps {
  slides: SlideData[];
}

export const SalesReport: React.FC<SalesReportProps> = ({ slides }) => {
  const { fps } = useVideoConfig();

  return (
    <AbsoluteFill
      style={{
        backgroundColor: "#1a1a2e",
        fontFamily: "'Microsoft YaHei', '微软雅黑', Arial, sans-serif",
      }}
    >
      {/* 场景1: 封面 */}
      <Sequence from={0} durationInFrames={slides[0]?.endFrame || 180}>
        <CoverSlide title="边际贡献分析报告" subtitle="找出贡献最大的三个要素 · 跨境电商" />
        <Audio src={staticFile(`audio/${slides[0]?.audioFile}`)} />
      </Sequence>

      {/* 场景2: 核心发现 */}
      <Sequence from={slides[0]?.endFrame || 180} durationInFrames={slides[1]?.duration * fps || 450}>
        <InsightSlide
          title="核心发现"
          insights={[
            { title: "🥇 第一名：天猫", content: "边际贡献 1,627万元，贡献率 68%" },
            { title: "🥈 第二名：CD120P", content: "边际贡献 563万元，贡献率 74%" },
            { title: "🥉 第三名：美国", content: "边际贡献 498万元，贡献率 65%" }
          ]}
        />
        <Audio src={staticFile(`audio/${slides[1]?.audioFile}`)} />
      </Sequence>

      {/* 场景3: 边际贡献对比图 */}
      <Sequence from={slides[1]?.endFrame || 630} durationInFrames={slides[2]?.duration * fps || 240}>
        <ChartSlide
          title="边际贡献对比（TOP5）"
          chartType="bar"
          data={[
            { name: "天猫", value: 1627 },
            { name: "CD120P", value: 563 },
            { name: "美国", value: 498 },
            { name: "Amazon", value: 279 },
            { name: "京东", value: 156 }
          ]}
        />
        <Audio src={staticFile(`audio/${slides[2]?.audioFile}`)} />
      </Sequence>

      {/* 场景4: 关键洞察 */}
      <Sequence from={slides[2]?.endFrame || 870} durationInFrames={slides[3]?.duration * fps || 540}>
        <InsightSlide
          title="关键洞察"
          insights={[
            { title: "天猫渠道表现卓越", content: "贡献占比68%，是最大收入来源" },
            { title: "CD120P盈利效率最高", content: "贡献率74%，变动成本控制得当" },
            { title: "美国市场规模最大", content: "收入3,543万元最高，贡献率65%" },
            { title: "⚠️ 天猫变动成本偏高", content: "需排查运营成本构成，优化空间大", warning: true }
          ]}
        />
        <Audio src={staticFile(`audio/${slides[3]?.audioFile}`)} />
      </Sequence>

      {/* 场景5: 行动建议 */}
      <Sequence from={slides[3]?.endFrame || 1410} durationInFrames={slides[4]?.duration * fps || 270}>
        <RecommendationSlide
          title="行动建议"
          recommendations={[
            "加大CD120P产能，贡献率74%的产品应获得更多资源",
            "优化天猫运营成本，降低变动成本提升贡献率",
            "建立月度边际贡献监控机制，及时发现问题"
          ]}
          source="BytePlan 数据平台 · 跨境电商租户"
        />
        <Audio src={staticFile(`audio/${slides[4]?.audioFile}`)} />
      </Sequence>

      {/* 场景6: 结尾 */}
      <Sequence from={slides[4]?.endFrame || 1680} durationInFrames={slides[5]?.duration * fps || 300}>
        <EndSlide title="谢谢观看" subtitle="边际贡献分析报告 · BytePlan" />
      </Sequence>
    </AbsoluteFill>
  );
};