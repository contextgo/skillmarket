import {
  AbsoluteFill,
  useVideoConfig,
  Audio,
  staticFile,
  Sequence,
} from "remotion";
import { CoverSlide } from "./scenes/CoverSlide";
import { ChartSlide } from "./scenes/ChartSlide";
import { InsightSlide } from "./scenes/InsightSlide";
import { RecommendationSlide } from "./scenes/RecommendationSlide";
import { EndSlide } from "./scenes/EndSlide";

interface SlideData {
  id: string;
  type: string;
  title: string;
  subtitle?: string;
  duration: number;
  audioFile: string;
  startFrame: number;
  endFrame: number;
  highlights?: string[];
  points?: string[];
  source?: string;
  dataKey?: string;
  visualConfig?: {
    highlights?: string[];
    points?: string[];
    source?: string;
    dataKey?: string;
    title?: string;
    subtitle?: string;
  };
}

interface ChartData {
  [key: string]: Array<{ name: string; value: number }>;
}

interface DynamicReportProps {
  slides: SlideData[];
  chartData?: ChartData;
  period?: string;
}

/**
 * 将 highlights 字符串数组转换为 insights 格式
 */
function parseHighlights(highlights: string[]): Array<{ title: string; content: string; warning?: boolean }> {
  return highlights.map(h => {
    // 检测是否包含警告标志
    const warning = h.includes('⚠️') || h.includes('风险') || h.includes('异常');
    
    // 移除 emoji，提取标题和内容
    const cleanText = h.replace(/[🥇🥈🥉⚠️]/g, '').trim();
    
    // 尝试分割标题和内容
    const colonIndex = cleanText.indexOf('：');
    if (colonIndex > 0) {
      const title = cleanText.substring(0, colonIndex).trim();
      const content = cleanText.substring(colonIndex + 1).trim();
      return { title, content, warning };
    }
    
    // 如果没有冒号，整段作为内容
    return { title: '', content: cleanText, warning };
  });
}

export const DynamicReport: React.FC<DynamicReportProps> = ({ slides, chartData, period }) => {
  const { fps } = useVideoConfig();

  // 根据场景类型渲染对应组件
  const renderScene = (slide: SlideData, index: number) => {
    switch (slide.type) {
      case 'title':
        return (
          <CoverSlide
            title={slide.title}
            subtitle={slide.subtitle || ''}
          />
        );

      case 'insight':
        // 支持 highlights 字符串数组（顶层或 visualConfig 内）
        const rawHighlights = slide.highlights || slide.visualConfig?.highlights || [];
        const insights = rawHighlights.length > 0
          ? parseHighlights(rawHighlights)
          : [];
        return (
          <InsightSlide
            title={slide.title}
            insights={insights}
          />
        );

      case 'bar_chart':
      case 'line_chart':
      case 'chart':
        // 从 chartData 获取图表数据，优先使用 dataKey
        const chartKey = slide.dataKey || slide.visualConfig?.dataKey || Object.keys(chartData || {})[0] || 'default';
        const data = chartData?.[chartKey] || [];
        
        // 数据格式化：转换为合适单位
        const formattedData = data.map(d => ({
          name: d.name,
          value: typeof d.value === 'number' && d.value > 10000
            ? Math.round(d.value / 10000)  // 转换为万元
            : d.value
        }));
        
        return (
          <ChartSlide
            title={slide.title}
            chartType={slide.type === 'line_chart' ? 'line' : 'bar'}
            data={formattedData}
          />
        );

      case 'summary':
        const rawPoints = slide.points || slide.visualConfig?.points || [];
        const rawSource = slide.source || slide.visualConfig?.source;
        return (
          <RecommendationSlide
            title={slide.title}
            recommendations={rawPoints}
            source={rawSource}
          />
        );

      case 'end':
        return (
          <EndSlide
            title="谢谢观看"
            subtitle={slide.title}
          />
        );

      default:
        // 默认渲染为洞察卡片
        return (
          <InsightSlide
            title={slide.title}
            insights={slide.highlights ? parseHighlights(slide.highlights) : [{ title: '', content: '' }]}
          />
        );
    }
  };

  return (
    <AbsoluteFill
      style={{
        backgroundColor: "#1a1a2e",
        fontFamily: "'Microsoft YaHei', '微软雅黑', Arial, sans-serif",
      }}
    >
      {slides.map((slide, index) => (
        <Sequence
          key={slide.id}
          from={slide.startFrame}
          durationInFrames={slide.duration * fps}
        >
          {renderScene(slide, index)}
          {slide.audioFile && (
            <Audio src={staticFile(`audio/${slide.audioFile}`)} />
          )}
        </Sequence>
      ))}
    </AbsoluteFill>
  );
};