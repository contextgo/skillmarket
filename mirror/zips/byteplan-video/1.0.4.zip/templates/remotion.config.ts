import { Config } from "@remotion/cli/config";

// macOS Chrome 路径
Config.setBrowserExecutable("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome");

// 设置入口文件
Config.setEntryPoint("src/register-root.tsx");

export default Config;