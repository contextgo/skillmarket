import * as fs from 'fs';
import * as path from 'path';
import { execSync } from 'child_process';
import { getAudioDurationInSeconds } from 'get-audio-duration';

const VOICE = 'zh-CN-XiaoxiaoNeural'; // 女声，自然流畅

async function generateAudio() {
  const storyboardPath = path.join(process.cwd(), 'src/storyboard/scenes.json');
  const audioDir = path.join(process.cwd(), 'public/audio');

  // 确保音频目录存在
  if (!fs.existsSync(audioDir)) {
    fs.mkdirSync(audioDir, { recursive: true });
  }

  // 读取分镜配置
  const scenesData = JSON.parse(fs.readFileSync(storyboardPath, 'utf-8'));
  const scenes = Array.isArray(scenesData) ? scenesData : scenesData.scenes;

  console.log(`开始生成 ${scenes.length} 个场景的语音...\n`);

  for (const scene of scenes) {
    const audioFileName = `${scene.id}.mp3`;
    const audioPath = path.join(audioDir, audioFileName);

    console.log(`生成语音: ${scene.id}`);
    console.log(`  文本: ${scene.narration.substring(0, 30)}...`);

    // 使用 edge-tts CLI 生成语音
    const text = scene.narration.replace(/"/g, '\\"');
    const cmd = `edge-tts --voice "${VOICE}" --text "${text}" --write-media "${audioPath}"`;

    try {
      execSync(cmd, { stdio: 'pipe' });
    } catch (error) {
      console.error(`  错误: ${error}`);
      continue;
    }

    // 获取音频时长
    const duration = await getAudioDurationInSeconds(audioPath);
    scene.audioPath = `/audio/${audioFileName}`;
    scene.audioDuration = Math.ceil(duration);

    console.log(`  时长: ${duration.toFixed(2)}秒\n`);
  }

  // 保存更新后的分镜配置
  const outputData = Array.isArray(scenesData) ? scenes : { scenes };
  fs.writeFileSync(storyboardPath, JSON.stringify(outputData, null, 2));
  console.log('语音生成完成！分镜配置已更新。');
}

generateAudio().catch(console.error);