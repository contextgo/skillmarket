import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig, spring } from "remotion";
import { VisualConfig } from "../storyboard/types";
import chartData from "../data/chartData.json";

interface LineChartSceneProps {
  config: VisualConfig;
  narration: string;
}

const COLORS = {
  primary: "#667eea",    // BytePlan 紫
  secondary: "#1E293B",
  accent: "#764ba2",
  background: "linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)",
  text: "#FFFFFF",
  lightText: "#94A3B8",
  grid: "rgba(255,255,255,0.1)",
};

export const LineChartScene: React.FC<LineChartSceneProps> = ({ config }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  // 必须提供 dataKey
  if (!config.dataKey) {
    throw new Error("LineChartScene requires 'dataKey' in config");
  }

  // 获取数据
  const dataKey = config.dataKey;
  const rawData = (chartData as Record<string, unknown>)[dataKey];
  const data = Array.isArray(rawData) ? rawData : [];

  if (data.length === 0) {
    throw new Error(`LineChartScene: No data found for dataKey '${dataKey}'`);
  }

  // 动画
  const titleOpacity = spring({ frame, fps, config: { damping: 100 } });
  const chartOpacity = spring({ frame: frame - 20, fps, config: { damping: 100 } });
  const lineProgress = spring({ frame: frame - 30, fps, config: { damping: 100, stiffness: 50 } });

  // 计算坐标
  const chartWidth = 1400;
  const chartHeight = 350;
  const chartStartX = 260;
  const chartStartY = 80;

  const maxValue = Math.max(...data.map((d: Record<string, number>) => d.value || 0), 1);
  const pointSpacing = chartWidth / (data.length - 1 || 1);

  // 生成路径
  const generatePath = () => {
    if (data.length === 0) return "";

    const points = data.map((item: Record<string, unknown>, index: number) => {
      const value = (item.value as number) || 0;
      const x = chartStartX + index * pointSpacing;
      const y = chartStartY + chartHeight - (value / maxValue) * chartHeight;
      return { x, y, value };
    });

    let path = `M ${points[0].x} ${points[0].y}`;

    for (let i = 1; i < points.length; i++) {
      const prev = points[i - 1];
      const curr = points[i];
      const midX = (prev.x + curr.x) / 2;
      path += ` C ${midX} ${prev.y}, ${midX} ${curr.y}, ${curr.x} ${curr.y}`;
    }

    return path;
  };

  const pathLength = 3000; // 估计的路径长度
  const animatedDashoffset = pathLength * (1 - lineProgress);

  return (
    <AbsoluteFill style={{ background: COLORS.background }}>
      {/* 标题 */}
      <div style={{
        position: "absolute",
        top: 60,
        left: 0,
        right: 0,
        textAlign: "center",
        opacity: titleOpacity,
      }}>
        <h2 style={{
          fontSize: 48,
          fontWeight: 600,
          color: COLORS.text,
          margin: 0,
        }}>
          {config.title}
        </h2>
      </div>

      {/* 图表区域 */}
      <div style={{
        position: "absolute",
        top: 150,
        left: 0,
        right: 0,
        opacity: chartOpacity,
      }}>
        <svg width="1920" height="500" viewBox="0 0 1920 500">
          {/* 网格线 */}
          {[0, 1, 2, 3, 4].map((i) => (
            <g key={i}>
              <line
                x1={chartStartX}
                y1={chartStartY + i * (chartHeight / 4)}
                x2={chartStartX + chartWidth}
                y2={chartStartY + i * (chartHeight / 4)}
                stroke={COLORS.grid}
                strokeWidth="1"
              />
              {/* Y轴标签 */}
              <text
                x={chartStartX - 30}
                y={chartStartY + i * (chartHeight / 4) + 5}
                textAnchor="end"
                fill={COLORS.lightText}
                fontSize={16}
              >
                {Math.round(maxValue - (maxValue / 4) * i)}亿
              </text>
            </g>
          ))}

          {/* 渐变填充区域 */}
          <defs>
            <linearGradient id="areaGradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor={COLORS.primary} stopOpacity="0.4" />
              <stop offset="100%" stopColor={COLORS.primary} stopOpacity="0" />
            </linearGradient>
          </defs>

          {/* 填充区域 */}
          {data.length > 0 && (
            <path
              d={`${generatePath()} L ${chartStartX + (data.length - 1) * pointSpacing} ${chartStartY + chartHeight} L ${chartStartX} ${chartStartY + chartHeight} Z`}
              fill="url(#areaGradient)"
              opacity={lineProgress}
            />
          )}

          {/* 折线 */}
          <path
            d={generatePath()}
            fill="none"
            stroke={COLORS.primary}
            strokeWidth="4"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeDasharray={pathLength}
            strokeDashoffset={animatedDashoffset}
          />

          {/* 数据点 */}
          {data.map((item: Record<string, unknown>, index: number) => {
            const value = (item.value as number) || 0;
            const label = (item.label as string) || "";
            const x = chartStartX + index * pointSpacing;
            const y = chartStartY + chartHeight - (value / maxValue) * chartHeight;
            const delay = index * 3;
            const pointOpacity = spring({ frame: frame - 40 - delay, fps, config: { damping: 100 } });

            return (
              <g key={index}>
                {/* 数据点 */}
                <circle
                  cx={x}
                  cy={y}
                  r={10}
                  fill={COLORS.primary}
                  stroke={COLORS.text}
                  strokeWidth="3"
                  opacity={pointOpacity}
                />

                {/* 数值 */}
                <text
                  x={x}
                  y={y - 25}
                  textAnchor="middle"
                  fill={COLORS.text}
                  fontSize={20}
                  fontWeight="600"
                  opacity={pointOpacity}
                >
                  {(value / 100).toFixed(0)}亿
                </text>

                {/* X轴标签 */}
                <text
                  x={x}
                  y={chartStartY + chartHeight + 40}
                  textAnchor="middle"
                  fill={COLORS.lightText}
                  fontSize={18}
                >
                  {label}
                </text>
              </g>
            );
          })}
        </svg>
      </div>
    </AbsoluteFill>
  );
};