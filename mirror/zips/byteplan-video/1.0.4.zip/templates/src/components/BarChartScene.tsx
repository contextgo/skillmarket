import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig, spring } from "remotion";
import { VisualConfig } from "../storyboard/types";
import chartData from "../data/chartData.json";

interface BarChartSceneProps {
  config: VisualConfig;
  narration: string;
}

const COLORS = {
  primary: "#667eea",    // BytePlan 紫
  secondary: "#1E293B",
  accent: "#764ba2",
  background: "linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)",
  text: "#FFFFFF",
  lightText: "#94A3B8",
  grid: "rgba(255,255,255,0.1)",
};

export const BarChartScene: React.FC<BarChartSceneProps> = ({ config }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  // 必须提供 dataKey
  if (!config.dataKey) {
    throw new Error("BarChartScene requires 'dataKey' in config");
  }

  // 获取数据
  const dataKey = config.dataKey;
  const rawData = (chartData as Record<string, unknown>)[dataKey];
  const data = Array.isArray(rawData) ? rawData : [];

  if (data.length === 0) {
    throw new Error(`BarChartScene: No data found for dataKey '${dataKey}'`);
  }

  // 动画
  const titleOpacity = spring({ frame, fps, config: { damping: 100 } });
  const chartOpacity = spring({ frame: frame - 20, fps, config: { damping: 100 } });

  // 计算最大值
  const maxValue = Math.max(...data.map((d: Record<string, number>) => d.value || 0), 1);
  const barWidth = 60;
  const barGap = 30;
  const chartHeight = 350;
  const chartStartX = (1920 - (data.length * (barWidth + barGap) - barGap)) / 2;

  return (
    <AbsoluteFill style={{ background: COLORS.background }}>
      {/* 标题 */}
      <div style={{
        position: "absolute",
        top: 80,
        left: 0,
        right: 0,
        textAlign: "center",
        opacity: titleOpacity,
      }}>
        <h2 style={{
          fontSize: 48,
          fontWeight: 600,
          color: COLORS.text,
          margin: 0,
        }}>
          {config.title}
        </h2>
      </div>

      {/* 图表区域 */}
      <div style={{
        position: "absolute",
        top: "50%",
        left: 0,
        right: 0,
        transform: "translateY(-50%)",
        opacity: chartOpacity,
      }}>
        <svg width="1920" height="450" viewBox="0 0 1920 450">
          {/* 网格线 */}
          {[0, 1, 2, 3, 4].map((i) => (
            <line
              key={i}
              x1={chartStartX - 50}
              y1={50 + i * 100}
              x2={1920 - chartStartX + 50}
              y2={50 + i * 100}
              stroke={COLORS.grid}
              strokeWidth="1"
            />
          ))}

          {/* 柱状图 */}
          {data.map((item: Record<string, unknown>, index: number) => {
            const value = (item.value as number) || 0;
            const label = (item.label as string) || "";
            const height = (value / maxValue) * chartHeight;
            const delay = index * 5;
            const barProgress = spring({ frame: frame - 20 - delay, fps, config: { damping: 100 } });
            const animatedHeight = height * barProgress;

            return (
              <g key={index}>
                {/* 柱子 */}
                <rect
                  x={chartStartX + index * (barWidth + barGap)}
                  y={400 - animatedHeight}
                  width={barWidth}
                  height={animatedHeight}
                  fill={`url(#barGradient${index})`}
                  rx={8}
                />

                {/* 数值标签 */}
                <text
                  x={chartStartX + index * (barWidth + barGap) + barWidth / 2}
                  y={400 - animatedHeight - 15}
                  textAnchor="middle"
                  fill={COLORS.text}
                  fontSize={20}
                  fontWeight="600"
                  opacity={barProgress}
                >
                  {typeof value === 'number' ? (value >= 100 ? `${(value / 100).toFixed(0)}亿` : `${value}%`) : value}
                </text>

                {/* X轴标签 */}
                <text
                  x={chartStartX + index * (barWidth + barGap) + barWidth / 2}
                  y={430}
                  textAnchor="middle"
                  fill={COLORS.lightText}
                  fontSize={18}
                >
                  {label}
                </text>

                {/* 渐变定义 */}
                <defs>
                  <linearGradient id={`barGradient${index}`} x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stopColor={COLORS.primary} />
                    <stop offset="100%" stopColor={COLORS.accent} />
                  </linearGradient>
                </defs>
              </g>
            );
          })}
        </svg>
      </div>
    </AbsoluteFill>
  );
};