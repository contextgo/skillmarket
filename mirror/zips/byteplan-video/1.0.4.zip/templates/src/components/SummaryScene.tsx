import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig, spring } from "remotion";
import { VisualConfig } from "../storyboard/types";

interface SummarySceneProps {
  config: VisualConfig;
  narration: string;
}

const COLORS = {
  primary: "#667eea",
  secondary: "#1E293B",
  accent: "#764ba2",
  background: "linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)",
  text: "#FFFFFF",
  lightText: "#94A3B8",
};

export const SummaryScene: React.FC<SummarySceneProps> = ({ config }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  // 必须提供 points 数据
  const points = config.points;

  if (!points || points.length === 0) {
    throw new Error("SummaryScene requires 'points' array in config");
  }

  // 动画
  const titleOpacity = spring({ frame, fps, config: { damping: 100 } });
  const contentOpacity = spring({ frame: frame - 15, fps, config: { damping: 100 } });

  return (
    <AbsoluteFill style={{ background: COLORS.background }}>
      {/* 装饰背景 */}
      <div style={{
        position: "absolute",
        top: "50%",
        left: "50%",
        transform: "translate(-50%, -50%)",
        width: 600,
        height: 600,
        borderRadius: "50%",
        background: "radial-gradient(circle, rgba(255,106,0,0.1) 0%, transparent 60%)",
        filter: "blur(80px)",
      }} />

      {/* 标题 */}
      <div style={{
        position: "absolute",
        top: 100,
        left: 0,
        right: 0,
        textAlign: "center",
        opacity: titleOpacity,
      }}>
        <h2 style={{
          fontSize: 56,
          fontWeight: 700,
          color: COLORS.text,
          margin: 0,
        }}>
          {config.title}
        </h2>
        <div style={{
          width: 100,
          height: 4,
          background: COLORS.primary,
          margin: "20px auto",
        }} />
      </div>

      {/* 总结要点 */}
      <div style={{
        position: "absolute",
        top: 220,
        left: 200,
        right: 200,
        display: "grid",
        gridTemplateColumns: "1fr 1fr",
        gap: 30,
        opacity: contentOpacity,
      }}>
        {points.map((point, index) => {
          const delay = index * 6;
          const itemOpacity = spring({ frame: frame - 25 - delay, fps, config: { damping: 100 } });
          const itemScale = spring({ frame: frame - 25 - delay, fps, config: { damping: 100, stiffness: 80 } });

          return (
            <div
              key={index}
              style={{
                display: "flex",
                alignItems: "center",
                gap: 20,
                padding: "24px 32px",
                background: "rgba(255,255,255,0.05)",
                borderRadius: 16,
                border: "1px solid rgba(255,255,255,0.1)",
                opacity: itemOpacity,
                transform: `scale(${itemScale})`,
              }}
            >
              {/* 序号 */}
              <div style={{
                width: 50,
                height: 50,
                borderRadius: "50%",
                background: `linear-gradient(135deg, ${COLORS.primary}, ${COLORS.accent})`,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: 24,
                fontWeight: 700,
                flexShrink: 0,
              }}>
                {index + 1}
              </div>

              {/* 文本 */}
              <div style={{
                fontSize: 26,
                fontWeight: 500,
                color: COLORS.text,
              }}>
                {point}
              </div>
            </div>
          );
        })}
      </div>

      {/* 感谢文字 */}
      {config.source && (
        <div style={{
          position: "absolute",
          bottom: 80,
          left: 0,
          right: 0,
          textAlign: "center",
          opacity: spring({ frame: frame - 50, fps, config: { damping: 100 } }),
        }}>
          <p style={{
            fontSize: 24,
            color: COLORS.lightText,
            margin: 0,
          }}>
            感谢观看 · 数据来源：{config.source}
          </p>
        </div>
      )}
    </AbsoluteFill>
  );
};