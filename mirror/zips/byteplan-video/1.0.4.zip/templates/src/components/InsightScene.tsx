import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig, spring } from "remotion";
import { VisualConfig } from "../storyboard/types";

interface InsightSceneProps {
  config: VisualConfig;
  narration: string;
}

const COLORS = {
  primary: "#667eea",    // BytePlan 紫
  secondary: "#1E293B",
  accent: "#764ba2",
  background: "linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)",
  text: "#FFFFFF",
  lightText: "#94A3B8",
  highlight: "#22C55E",
};

export const InsightScene: React.FC<InsightSceneProps> = ({ config }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  // 必须提供 highlights 数据
  const highlights = config.highlights;

  if (!highlights || highlights.length === 0) {
    throw new Error("InsightScene requires 'highlights' array in config");
  }

  // 动画
  const titleOpacity = spring({ frame, fps, config: { damping: 100 } });
  const contentOpacity = spring({ frame: frame - 15, fps, config: { damping: 100 } });

  return (
    <AbsoluteFill style={{ background: COLORS.background }}>
      {/* 装饰元素 */}
      <div style={{
        position: "absolute",
        top: "20%",
        right: "10%",
        width: 150,
        height: 150,
        borderRadius: "50%",
        background: "radial-gradient(circle, rgba(255,106,0,0.2) 0%, transparent 70%)",
        filter: "blur(30px)",
      }} />

      {/* 标题 */}
      <div style={{
        position: "absolute",
        top: 100,
        left: 0,
        right: 0,
        textAlign: "center",
        opacity: titleOpacity,
      }}>
        <h2 style={{
          fontSize: 56,
          fontWeight: 700,
          color: COLORS.text,
          margin: 0,
        }}>
          {config.title}
        </h2>
        <div style={{
          width: 120,
          height: 4,
          background: COLORS.primary,
          margin: "20px auto",
        }} />
      </div>

      {/* 洞察要点 */}
      <div style={{
        position: "absolute",
        top: 250,
        left: 150,
        right: 150,
        display: "flex",
        flexDirection: "column",
        gap: 30,
        opacity: contentOpacity,
      }}>
        {highlights.map((point, index) => {
          const delay = index * 8;
          const itemOpacity = spring({ frame: frame - 25 - delay, fps, config: { damping: 100 } });
          const itemX = spring({ frame: frame - 25 - delay, fps, config: { damping: 100, stiffness: 80 } });

          return (
            <div
              key={index}
              style={{
                display: "flex",
                alignItems: "center",
                gap: 24,
                opacity: itemOpacity,
                transform: `translateX(${(1 - itemX) * -50}px)`,
              }}
            >
              {/* 图标 */}
              <div style={{
                width: 48,
                height: 48,
                borderRadius: 12,
                background: `linear-gradient(135deg, ${COLORS.primary}, ${COLORS.accent})`,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: 24,
                flexShrink: 0,
              }}>
                ✓
              </div>

              {/* 文本 */}
              <div style={{
                fontSize: 32,
                fontWeight: 500,
                color: COLORS.text,
                padding: "16px 32px",
                background: "rgba(255,255,255,0.05)",
                borderRadius: 12,
                borderLeft: `4px solid ${COLORS.primary}`,
                flex: 1,
              }}>
                {point}
              </div>
            </div>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};