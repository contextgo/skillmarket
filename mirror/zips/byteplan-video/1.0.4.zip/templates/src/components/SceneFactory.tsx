import React from "react";
import { StoryboardScene } from "../storyboard/types";
import { TitleScene } from "./TitleScene";
import { BarChartScene } from "./BarChartScene";
import { LineChartScene } from "./LineChartScene";
import { InsightScene } from "./InsightScene";
import { SummaryScene } from "./SummaryScene";

const sceneComponents: Record<string, React.FC<{ config: any; narration: string }>> = {
  title: TitleScene,
  bar_chart: BarChartScene,
  line_chart: LineChartScene,
  insight: InsightScene,
  summary: SummaryScene,
};

export const SceneFactory: React.FC<{ scene: any }> = ({ scene }) => {
  const Component = sceneComponents[scene.type];
  if (!Component) {
    return (
      <div style={{ padding: 40, color: "white", background: "#1a1a2e" }}>
        Unknown scene type: {scene.type}
      </div>
    );
  }
  // 支持 visualConfig 或直接使用 scene 作为 config
  const config = scene.visualConfig || {
    title: scene.title,
    subtitle: scene.subtitle,
    data: scene.data,
    content: scene.content,
  };
  return <Component config={config} narration={scene.narration} />;
};