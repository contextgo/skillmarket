import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig, spring } from "remotion";
import { VisualConfig } from "../storyboard/types";

interface TitleSceneProps {
  config: VisualConfig;
  narration: string;
}

const COLORS = {
  primary: "#667eea",    // BytePlan 紫
  secondary: "#1E293B",
  accent: "#764ba2",
  background: "linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)",
  text: "#FFFFFF",
  lightText: "#94A3B8",
};

export const TitleScene: React.FC<TitleSceneProps> = ({ config }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  // 动画效果
  const titleOpacity = spring({ frame, fps, config: { damping: 100 } });
  const titleScale = spring({ frame, fps, config: { damping: 100, stiffness: 50 } });
  const subtitleOpacity = spring({ frame: frame - 15, fps, config: { damping: 100 } });
  const logoOpacity = spring({ frame: frame - 30, fps, config: { damping: 100 } });

  return (
    <AbsoluteFill style={{ background: COLORS.background }}>
      {/* 装饰元素 */}
      <div style={{
        position: "absolute",
        top: "10%",
        left: "5%",
        width: 200,
        height: 200,
        borderRadius: "50%",
        background: "radial-gradient(circle, rgba(102,126,234,0.2) 0%, transparent 70%)",
        filter: "blur(40px)",
      }} />

      <div style={{
        position: "absolute",
        bottom: "10%",
        right: "5%",
        width: 300,
        height: 300,
        borderRadius: "50%",
        background: "radial-gradient(circle, rgba(118,75,162,0.15) 0%, transparent 70%)",
        filter: "blur(60px)",
      }} />

      {/* Logo 装饰 */}
      <div style={{
        position: "absolute",
        top: 80,
        left: 80,
        opacity: logoOpacity,
        display: "flex",
        alignItems: "center",
        gap: 16,
      }}>
        <div style={{
          width: 60,
          height: 60,
          borderRadius: 12,
          background: COLORS.primary,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: 32,
          fontWeight: "bold",
          color: "white",
        }}>
          B
        </div>
        <span style={{
          color: COLORS.text,
          fontSize: 24,
          fontWeight: 500,
        }}>
          BytePlan
        </span>
      </div>

      {/* 主标题 */}
      <div style={{
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        alignItems: "center",
        height: "100%",
        gap: 24,
      }}>
        <h1 style={{
          fontSize: 72,
          fontWeight: 700,
          color: COLORS.text,
          margin: 0,
          opacity: titleOpacity,
          transform: `scale(${titleScale})`,
          textShadow: "0 4px 30px rgba(102,126,234,0.3)",
        }}>
          {config.title}
        </h1>

        <div style={{
          width: 200,
          height: 4,
          background: `linear-gradient(90deg, transparent, ${COLORS.primary}, transparent)`,
          opacity: subtitleOpacity,
        }} />

        {config.subtitle && (
          <h2 style={{
            fontSize: 32,
            fontWeight: 400,
            color: COLORS.lightText,
            margin: 0,
            opacity: subtitleOpacity,
            letterSpacing: 2,
          }}>
            {config.subtitle}
          </h2>
        )}
      </div>
    </AbsoluteFill>
  );
};