// 场景类型
export type SceneType = 'title' | 'bar_chart' | 'line_chart' | 'insight' | 'summary';

// 视觉配置
export interface VisualConfig {
  title: string;           // 必须提供标题
  subtitle?: string;
  chartType?: string;
  highlights?: string[];   // InsightScene 必需
  points?: string[];       // SummaryScene 必需
  dataKey?: string;        // 图表场景必需
  source?: string;         // 数据来源（可选）
  [key: string]: unknown;
}

// 分镜场景
export interface StoryboardScene {
  id: string;
  type: SceneType;
  description: string;
  narration: string;
  visualConfig: VisualConfig;
  audioPath?: string;
  audioDuration?: number;
}

// 分镜配置
export interface Storyboard {
  scenes: StoryboardScene[];
}

// 营收数据
export interface RevenueData {
  fiscal_year: string;
  total_revenue: number;
  year_over_year_growth?: number;
  net_income?: number;
}

// 业务板块数据
export interface BusinessSegmentData {
  segment: string;
  revenue: number;
  percentage: number;
  year?: string;
}