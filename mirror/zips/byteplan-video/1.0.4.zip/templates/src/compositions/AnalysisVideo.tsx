import React from "react";
import { AbsoluteFill, Sequence, Audio, staticFile, useVideoConfig } from "remotion";
import { SceneFactory } from "../components/SceneFactory";
import storyboardData from "../storyboard/scenes.json";

export const AnalysisVideo: React.FC = () => {
  const { fps } = useVideoConfig();
  const scenes = Array.isArray(storyboardData) ? storyboardData : storyboardData.scenes;

  let currentFrame = 0;

  return (
    <AbsoluteFill style={{ backgroundColor: "#1a1a2e" }}>
      {scenes.map((scene, index) => {
        // 默认每个场景 5 秒，如果已有音频时长则使用
        const durationSeconds = scene.audioDuration || 5;
        const durationInFrames = Math.round(durationSeconds * fps);

        const startFrame = currentFrame;
        currentFrame += durationInFrames;

        return (
          <Sequence
            key={scene.id}
            from={startFrame}
            durationInFrames={durationInFrames}
          >
            <AbsoluteFill>
              <SceneFactory scene={scene} />
              {scene.audioPath && (
                <Audio src={staticFile(scene.audioPath.replace('/audio/', 'audio/'))} />
              )}
            </AbsoluteFill>
          </Sequence>
        );
      })}
    </AbsoluteFill>
  );
};