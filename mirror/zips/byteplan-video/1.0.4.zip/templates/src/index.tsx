import React from "react";
import { Composition } from "remotion";
import { AnalysisVideo } from "./compositions/AnalysisVideo";
import storyboardData from "./storyboard/scenes.json";

// 支持直接的数组或 { scenes: [] } 格式
const scenes = Array.isArray(storyboardData) ? storyboardData : storyboardData.scenes;

// 计算总时长
const totalDuration = scenes.reduce(
  (sum, scene) => sum + (scene.audioDuration || 5),
  0
);

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition
        id="AnalysisVideo"
        component={AnalysisVideo}
        durationInFrames={totalDuration * 30}
        fps={30}
        width={1920}
        height={1080}
      />
    </>
  );
};