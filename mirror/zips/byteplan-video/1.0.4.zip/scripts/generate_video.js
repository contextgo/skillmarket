#!/usr/bin/env node

/**
 * BytePlan 视频生成脚本
 * 根据数据文件生成数据可视化视频
 */

import { Command } from 'commander';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { execSync } from 'child_process';
import { resolve, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));

const program = new Command();

program
  .name('generate-video')
  .description('生成 BytePlan 数据可视化视频')
  .option('-o, --output <file>', '输出文件名', 'report.mp4')
  .option('-d, --data <file>', '数据文件路径', 'video_data.json')
  .option('--width <number>', '视频宽度', '1920')
  .option('--height <number>', '视频高度', '1080')
  .option('--fps <number>', '帧率', '30')
  .option('--skip-audio', '跳过语音生成', false)
  .parse(process.argv);

const options = program.opts();

/**
 * 检查依赖是否安装
 */
function checkDependencies() {
  console.log('🔍 检查依赖...');

  // 检查 edge-tts
  try {
    execSync('which edge-tts', { stdio: 'ignore' });
    console.log('  ✅ edge-tts 已安装');
  } catch {
    console.log('  ⚠️  edge-tts 未安装，语音功能将不可用');
    console.log('     安装命令: npm install -g edge-tts');
  }

  // 检查 node_modules
  if (!existsSync(resolve(__dirname, '../node_modules'))) {
    console.log('  📦 正在安装依赖...');
    execSync('pnpm install', { cwd: resolve(__dirname, '..'), stdio: 'inherit' });
  }
}

/**
 * 加载数据文件
 */
function loadData(dataPath) {
  const fullPath = resolve(dataPath);

  if (!existsSync(fullPath)) {
    console.error(`❌ 数据文件不存在: ${fullPath}`);
    console.log('\n请确保数据文件存在，或使用 -d 参数指定正确的路径。');
    process.exit(1);
  }

  console.log(`📄 加载数据文件: ${fullPath}`);
  const content = readFileSync(fullPath, 'utf-8');
  return JSON.parse(content);
}

/**
 * 验证数据格式
 */
function validateData(data) {
  const required = ['title', 'scenes'];
  const missing = required.filter(key => !data[key]);

  if (missing.length > 0) {
    console.error(`❌ 数据格式错误，缺少必需字段: ${missing.join(', ')}`);
    process.exit(1);
  }

  if (!Array.isArray(data.scenes) || data.scenes.length === 0) {
    console.error('❌ 数据格式错误: scenes 必须是非空数组');
    process.exit(1);
  }

  console.log(`  ✅ 数据验证通过: ${data.scenes.length} 个场景`);
}

/**
 * 生成场景配置文件
 */
function generateSceneConfig(data) {
  const configPath = resolve(__dirname, '../src/data/scenes.json');

  // 确保目录存在
  mkdirSync(dirname(configPath), { recursive: true });

  // 计算总时长
  const totalDuration = data.scenes.reduce((sum, scene) => sum + (scene.duration || 10), 0);

  const config = {
    title: data.title,
    subtitle: data.subtitle || '',
    period: data.period || '',
    source: data.source || 'BytePlan 数据平台',
    scenes: data.scenes,
    totalDuration,
    totalFrames: totalDuration * parseInt(options.fps)
  };

  writeFileSync(configPath, JSON.stringify(config, null, 2));
  console.log(`  ✅ 场景配置已生成: ${configPath}`);

  return config;
}

/**
 * 生成图表数据文件
 */
function generateChartData(data) {
  const chartPath = resolve(__dirname, '../src/data/chartData.json');

  const chartData = {
    title: data.title,
    scenes: data.scenes.map(scene => {
      if (scene.data) {
        return {
          type: scene.type,
          title: scene.title,
          data: scene.data
        };
      }
      return null;
    }).filter(Boolean)
  };

  writeFileSync(chartPath, JSON.stringify(chartData, null, 2));
  console.log(`  ✅ 图表数据已生成: ${chartPath}`);
}

/**
 * 生成语音文件
 */
async function generateAudio(data) {
  if (options.skipAudio) {
    console.log('  ⏭️  跳过语音生成');
    return data;
  }

  // 检查 edge-tts 是否安装
  try {
    execSync('which edge-tts', { stdio: 'ignore' });
  } catch {
    console.log('  ⚠️  edge-tts 未安装，跳过语音生成');
    console.log('     安装命令: npm install -g edge-tts');
    return data;
  }

  const audioDir = resolve(__dirname, '../templates/public/audio');
  mkdirSync(audioDir, { recursive: true });

  console.log('🎙️  生成语音文件...');

  const voice = 'zh-CN-XiaoxiaoNeural';
  let totalAudioFiles = 0;

  for (let i = 0; i < data.scenes.length; i++) {
    const scene = data.scenes[i];
    if (scene.narration) {
      const audioFile = resolve(audioDir, `scene_${i}.mp3`);

      try {
        // 生成语音
        execSync(
          `edge-tts --voice ${voice} --text "${scene.narration.replace(/"/g, '\\"')}" --write-media "${audioFile}"`,
          { stdio: 'pipe' }
        );

        // 获取音频时长
        const durationOutput = execSync(
          `ffprobe -i "${audioFile}" -show_entries format=duration -v quiet -of csv="p=0"`,
          { encoding: 'utf-8' }
        );
        const audioDuration = parseFloat(durationOutput.trim());

        // 更新场景配置
        scene.audioPath = `/audio/scene_${i}.mp3`;
        scene.audioDuration = Math.ceil(audioDuration);
        scene.duration = scene.audioDuration;

        console.log(`  ✅ 场景 ${i + 1}: "${scene.narration.substring(0, 20)}..." (${audioDuration.toFixed(1)}s)`);
        totalAudioFiles++;
      } catch (err) {
        console.log(`  ⚠️  场景 ${i + 1} 语音生成失败`);
      }
    }
  }

  console.log(`  ✅ 共生成 ${totalAudioFiles} 个语音文件`);
  return data;
}

/**
 * 渲染视频
 */
function renderVideo(outputPath) {
  console.log('🎬 渲染视频中...');
  console.log(`  输出: ${outputPath}`);
  console.log(`  分辨率: ${options.width}x${options.height}`);
  console.log(`  帧率: ${options.fps} fps`);

  const renderCmd = [
    'remotion render AnalysisVideo',
    resolve(outputPath),
    `--codec h264`,
    `--concurrency 1`,
    `--width ${options.width}`,
    `--height ${options.height}`,
    `--fps ${options.fps}`
  ].join(' ');

  try {
    execSync(renderCmd, {
      cwd: resolve(__dirname, '..'),
      stdio: 'inherit'
    });
    console.log('✅ 视频渲染完成！');
  } catch (err) {
    console.error('❌ 视频渲染失败');
    console.error(err.message);
    process.exit(1);
  }
}

/**
 * 主函数
 */
async function main() {
  console.log('\n🎥 BytePlan 视频生成器\n');

  // 1. 检查依赖
  checkDependencies();

  // 2. 加载数据
  let data = loadData(options.data);

  // 3. 验证数据
  validateData(data);

  // 4. 生成语音（会更新 data.scenes 中的 audioDuration）
  console.log('\n');
  data = await generateAudio(data);

  // 5. 生成配置文件
  console.log('\n📝 生成配置文件...');
  generateSceneConfig(data);
  generateChartData(data);

  // 6. 渲染视频
  console.log('\n');
  renderVideo(options.output);

  console.log(`\n📁 输出文件: ${resolve(options.output)}\n`);
}

main().catch(err => {
  console.error('❌ 发生错误:', err.message);
  process.exit(1);
});