#!/usr/bin/env python3
"""
pdf-craft-converter 环境检查脚本
检查 UV、Python、Poppler 及各 OCR 后端的可用性
"""

import json
import shutil
import subprocess
import sys
from pathlib import Path


def run_cmd(cmd: list[str], timeout: int = 15) -> tuple[bool, str]:
    """运行命令并返回 (成功与否, 输出)"""
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.returncode == 0, (r.stdout + r.stderr).strip()
    except FileNotFoundError:
        return False, "command not found"
    except subprocess.TimeoutExpired:
        return False, "timeout"


def check_uv() -> tuple[bool, str]:
    """检查 UV 是否安装"""
    ok, out = run_cmd(["uv", "--version"])
    if ok:
        return True, out.splitlines()[0] if out else "installed"
    return False, "not installed (install: https://docs.astral.sh/uv/getting-started/installation/)"


def check_python() -> tuple[bool, str]:
    """检查 Python 版本"""
    major, minor = sys.version_info[:2]
    ok = major == 3 and minor >= 11
    return ok, f"Python {major}.{minor}"


def check_pip_package(name: str, import_name: str | None = None) -> tuple[bool, str]:
    """检查 Python 包是否已安装"""
    mod = import_name or name.replace("-", "_")
    try:
        m = __import__(mod)
        ver = getattr(m, "__version__", "unknown")
        return True, str(ver)
    except ImportError:
        return False, "not installed"


def check_command(cmd: str) -> tuple[bool, str]:
    """检查系统命令"""
    p = shutil.which(cmd)
    return (p is not None, p or "not found")


def check_gpu() -> tuple[bool, str]:
    """检查 CUDA GPU (macOS MPS 由各后端自行检测)"""
    try:
        import torch
        if torch.cuda.is_available():
            name = torch.cuda.get_device_name(0)
            vram = torch.cuda.get_device_properties(0).total_mem / (1024**3)
            return True, f"{name} ({vram:.0f} GB)"
        # macOS MPS: PyTorch 支持 MPS 但这里只报告 CUDA
        if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
            return False, "Apple Silicon MPS (各后端内部自动利用)"
        return False, "CPU only"
    except ImportError:
        return False, "torch not installed"


def check_poppler() -> tuple[bool, str]:
    """检查 Poppler"""
    cmds = ["pdftoppm", "pdftotext"]
    found = []
    for c in cmds:
        p = shutil.which(c)
        if p:
            found.append(p)
    ok = len(found) >= 2
    if ok:
        return True, "; ".join(found)
    if found:
        return False, f"部分缺失 (found: {found[0]}, missing: {[c for c in cmds if shutil.which(c) is None]})"
    return False, "not found"


def check_ocr_backend(name: str) -> tuple[bool, str]:
    """检查 OCR 后端"""
    backends = {
        "pdf-craft": ("pdf_craft", None),
        "marker": ("marker", None),
        "minera": ("magic_pdf", None),
    }
    import_name, _ = backends.get(name, (name, None))
    return check_pip_package(name, import_name)


def get_platform_hint(backend_name: str) -> str:
    """根据平台生成后端安装提示"""
    import platform
    system = platform.system()
    machine = platform.machine().lower()
    is_arm_mac = system == "Darwin" and machine in ("arm64", "aarch64")
    is_mac = system == "Darwin"
    is_linux = system == "Linux"

    if backend_name == "minera" and is_arm_mac:
        return "uv pip install 'mineru[core]'   # macOS Apple Silicon 用 core 版"
    return f"uv pip install {backend_name}"


def main():
    print("=" * 60)
    print("  pdf-craft-converter 环境检查")
    print("=" * 60)
    print()

    results = {}

    # --- UV ---
    ok, info = check_uv()
    tag = "OK" if ok else "FAIL"
    results["uv"] = ok
    print(f"  [{tag}] UV: {info}")
    if not ok:
        print("         https://docs.astral.sh/uv/getting-started/installation/")

    # --- Python ---
    ok, info = check_python()
    tag = "OK" if ok else "FAIL"
    results["python"] = ok
    print(f"  [{tag}] {info}")
    if not ok:
        print("         需要 Python >= 3.11")

    # --- Poppler ---
    ok, info = check_poppler()
    tag = "OK" if ok else "FAIL"
    results["poppler"] = ok
    print(f"  [{tag}] Poppler: {info}")
    if not ok:
        import platform
        system = platform.system()
        if system == "win32":
            print("         Windows: choco install poppler | scoop install poppler")
            print("         安装后请重启终端")
        elif system == "Darwin":
            print("         macOS:   brew install poppler")
        else:
            print("         Linux:   sudo apt install poppler-utils   (Debian/Ubuntu)")
            print("                   sudo dnf install poppler-utils   (Fedora)")
            print("                   sudo pacman -S poppler          (Arch)")

    # --- GPU ---
    ok, info = check_gpu()
    tag = "OK" if ok else ("WARN" if "not installed" not in info else "SKIP")
    results["gpu"] = ok
    print(f"  [{tag}] GPU: {info}")

    # --- OCR 后端 ---
    print()
    print("  --- OCR 后端 ---")
    backends = {
        "pdf-craft": "DeepSeek OCR, 专注扫描书籍, 支持 EPUB 输出",
        "marker": "Surya OCR, 速度快, 适合批量处理",
        "minera": "上海AI Lab, 中文最强, 公式表格极准",
    }
    for name, desc in backends.items():
        ok, ver = check_ocr_backend(name)
        tag = "OK" if ok else "--"
        results[name] = ok
        ver_str = f"v{ver}" if ok else "未安装"
        print(f"  [{tag}] {name}: {ver_str}")
        print(f"       {desc}")
        if not ok:
            hint = get_platform_hint(name)
            print(f"       安装: {hint}")

    # --- 汇总 ---
    print()
    print("=" * 60)
    installed_backends = [n for n in backends if results.get(n)]
    if installed_backends:
        print(f"  可用后端: {', '.join(installed_backends)}")
    else:
        print("  未检测到任何 OCR 后端，请至少安装一个:")
        print("    uv pip install pdf-craft   # 推荐: 扫描书籍转电子书")
        print("    uv pip install marker-pdf  # 速度快, 批量处理, 跨平台最佳")
        import platform
        if platform.system() == "Darwin" and platform.machine().lower() in ("arm64", "aarch64"):
            print("    uv pip install 'mineru[core]'  # macOS Apple Silicon 用 core 版")
        else:
            print("    uv pip install 'magic-pdf[full]'  # 中文最强, 公式表格")

    critical = all([results.get("python", False), results.get("poppler", False), len(installed_backends) > 0])
    if critical:
        print("\n  环境就绪!")
    else:
        print("\n  请按上方提示安装缺失依赖。")
    print("=" * 60)

    # 写报告
    report_path = Path(__file__).parent / ".env_check.json"
    report_path.write_text(json.dumps(results, indent=2, ensure_ascii=False), encoding="utf-8")

    return 0 if critical else 1


if __name__ == "__main__":
    sys.exit(main())
