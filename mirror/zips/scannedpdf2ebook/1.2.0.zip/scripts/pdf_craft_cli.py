#!/usr/bin/env python3
"""
pdf-craft-converter 核心转换脚本
支持多 OCR 后端: pdf-craft (DeepSeek OCR) / Marker / MinerU
纯本地运行, 零 API 依赖
"""

import argparse
import sys
import time
from pathlib import Path

SKILL_DIR = Path(__file__).resolve().parent.parent
SCRIPTS_DIR = Path(__file__).resolve().parent


def detect_text_layer(pdf_path: str) -> dict:
    """检测 PDF 是否包含可提取的文本层"""
    try:
        import pypdf
    except ImportError:
        return {"has_text": None, "confidence": "unknown", "reason": "pypdf not installed"}

    reader = pypdf.PdfReader(pdf_path)
    total = len(reader.pages)
    sample = min(10, total)
    total_chars = 0
    pages_with_text = 0

    for i in range(sample):
        try:
            text = reader.pages[i].extract_text() or ""
            chars = len(text.strip())
            if chars > 50:
                pages_with_text += 1
            total_chars += chars
        except Exception:
            pass

    avg = total_chars / sample if sample > 0 else 0
    if avg > 200:
        return {"has_text": True, "confidence": "high", "avg_chars": round(avg),
                "pages": total, "reason": "PDF 包含可提取的文本层"}
    elif avg > 50:
        return {"has_text": True, "confidence": "low", "avg_chars": round(avg),
                "pages": total, "reason": "文本层质量较差, 建议同时使用 OCR"}
    else:
        return {"has_text": False, "confidence": "high", "avg_chars": round(avg),
                "pages": total, "reason": "纯扫描件, 需要 OCR"}


def auto_ocr_size() -> str:
    """根据 GPU 自动选择 OCR 模型大小"""
    try:
        import torch
        return "gundam" if torch.cuda.is_available() else "base"
    except Exception:
        return "base"


# ============================================================
# Backend 1: pdf-craft (DeepSeek OCR)
# ============================================================

def _ensure_pdf_craft():
    try:
        import pdf_craft
        return True
    except ImportError:
        print("  错误: pdf-craft 未安装")
        print("  安装: uv pip install pdf-craft")
        return False


def to_markdown_pdfcraft(args):
    """pdf-craft 后端: PDF -> Markdown"""
    if not _ensure_pdf_craft():
        return 1
    from pdf_craft import transform_markdown

    pdf = args.input
    out = args.output
    assets = args.assets_dir or str(Path(out).parent / "images")
    ocr = args.ocr_size or auto_ocr_size()
    dpi = args.dpi

    print(f"\n  [pdf-craft] PDF -> Markdown")
    print(f"  输入: {pdf}")
    print(f"  输出: {out}")
    print(f"  OCR 模型: {ocr}")
    print(f"  DPI: {dpi}")

    Path(out).parent.mkdir(parents=True, exist_ok=True)
    Path(assets).mkdir(parents=True, exist_ok=True)

    t0 = time.time()
    try:
        transform_markdown(
            pdf_path=pdf,
            markdown_path=out,
            markdown_assets_path=assets,
            ocr_size=ocr,
            dpi=dpi,
            includes_cover=args.cover,
            includes_footnotes=not args.no_footnotes,
            ignore_pdf_errors=True,
            ignore_ocr_errors=True,
        )
        print(f"\n  完成! ({time.time()-t0:.0f}s) -> {out}")
        return 0
    except Exception as e:
        print(f"\n  失败: {e}")
        return 1


def to_epub_pdfcraft(args):
    """pdf-craft 后端: PDF -> EPUB"""
    if not _ensure_pdf_craft():
        return 1
    from pdf_craft import transform_epub, BookMeta, TableRender, LaTeXRender

    pdf = args.input
    out = args.output
    ocr = args.ocr_size or auto_ocr_size()
    dpi = args.dpi

    book_meta = BookMeta(
        title=args.title or Path(pdf).stem,
        authors=[args.author] if args.author else ["Unknown"],
        language=args.language,
    )

    print(f"\n  [pdf-craft] PDF -> EPUB")
    print(f"  书名: {book_meta.title}")
    print(f"  作者: {', '.join(book_meta.authors)}")
    print(f"  OCR 模型: {ocr}")
    print(f"  DPI: {dpi}")

    Path(out).parent.mkdir(parents=True, exist_ok=True)

    t0 = time.time()
    try:
        transform_epub(
            pdf_path=pdf,
            epub_path=out,
            book_meta=book_meta,
            ocr_size=ocr,
            dpi=dpi,
            includes_cover=True,
            includes_footnotes=True,
            ignore_pdf_errors=True,
            ignore_ocr_errors=True,
            toc_assumed=True,
            lan=args.language,
            table_render=TableRender.HTML,
            latex_render=LaTeXRender.MATHML,
            inline_latex=True,
        )
        print(f"\n  完成! ({time.time()-t0:.0f}s) -> {out}")
        return 0
    except Exception as e:
        print(f"\n  失败: {e}")
        return 1


# ============================================================
# Backend 2: Marker
# ============================================================

def _ensure_marker():
    try:
        from marker.converters.pdf import PdfConverter
        return True
    except ImportError:
        print("  错误: marker-pdf 未安装")
        print("  安装: uv pip install marker-pdf")
        return False


def to_markdown_marker(args):
    """Marker 后端: PDF -> Markdown"""
    if not _ensure_marker():
        return 1
    from marker.converters.pdf import PdfConverter
    from marker.models import create_model_dict

    pdf = args.input
    out = args.output

    print(f"\n  [marker] PDF -> Markdown")
    print(f"  输入: {pdf}")
    print(f"  输出: {out}")

    Path(out).parent.mkdir(parents=True, exist_ok=True)

    t0 = time.time()
    try:
        converter = PdfConverter(artifact_dict=create_model_dict())
        rendered = converter(pdf)
        markdown = rendered.markdown

        Path(out).write_text(markdown, encoding="utf-8")
        print(f"\n  完成! ({time.time()-t0:.0f}s) -> {out}")
        return 0
    except Exception as e:
        print(f"\n  失败: {e}")
        return 1


# ============================================================
# Backend 3: MinerU (magic-pdf)
# ============================================================

def _ensure_minera():
    try:
        import magic_pdf
        return True
    except ImportError:
        print("  错误: magic-pdf 未安装")
        print("  安装: uv pip install 'magic-pdf[full]'")
        return False


def to_markdown_minera(args):
    """MinerU 后端: PDF -> Markdown"""
    if not _ensure_minera():
        return 1

    pdf = args.input
    out = args.output

    print(f"\n  [minera] PDF -> Markdown")
    print(f"  输入: {pdf}")
    print(f"  输出: {out}")

    Path(out).parent.mkdir(parents=True, exist_ok=True)

    t0 = time.time()
    try:
        from magic_pdf.pipe.UNIPipe import UNIPipe
        from magic_pdf.data.data_reader_writer import FileBasedDataWriter, FileBasedDataReader
        import os

        # MinerU 需要按特定流程处理
        reader = FileBasedDataReader("")
        pdf_bytes = reader.read(pdf)

        # 创建临时输出目录
        out_dir = Path(out).parent / f"_minera_{Path(pdf).stem}"
        out_dir.mkdir(parents=True, exist_ok=True)

        # 使用 MinerU 的 pipe
        image_dir = str(out_dir / "images")
        os.makedirs(image_dir, exist_ok=True)

        # MinerU 新版本 API
        try:
            from magic_pdf.pipe.UNIPipe import UNIPipe
            from magic_pdf.model.model_list import MODEL_LIST

            model = MODEL_LIST[0]
            jso_useful_key = {"_pdf_type": "", "model_list": model}

            # 写入临时文件
            pdf_name = Path(pdf).stem
            input_path = str(out_dir / f"{pdf_name}.pdf")
            import shutil
            shutil.copy2(pdf, input_path)

            pipe = UNIPipe(input_path, jso_useful_key, image_dir)
            pipe.pipe_classify()
            pipe.pipe_parse()

            # 获取 Markdown 内容
            md_content = pipe.pipe_mk_markdown(str(out_dir), f"{pdf_name}")

            # 写入最终输出
            Path(out).write_text(md_content, encoding="utf-8")

            # 清理临时目录
            import shutil as sh
            sh.rmtree(out_dir, ignore_errors=True)

            print(f"\n  完成! ({time.time()-t0:.0f}s) -> {out}")
            return 0

        except Exception as inner_e:
            # 回退: 尝试 MinerU CLI
            print(f"  API 方式失败 ({inner_e}), 尝试 CLI 方式...")
            import subprocess
            result = subprocess.run(
                ["magic-pdf", "-p", pdf, "-o", str(Path(out).parent), "-m", "auto"],
                capture_output=True, text=True, timeout=600
            )
            if result.returncode == 0:
                # MinerU 会生成 {name}/{name}.md
                auto_out = Path(Path(out).parent / Path(pdf).stem / f"{Path(pdf).stem}.md")
                if auto_out.exists():
                    import shutil as sh
                    sh.copy2(str(auto_out), out)
                    print(f"\n  完成! ({time.time()-t0:.0f}s) -> {out}")
                    return 0

            print(f"\n  CLI 也失败: {result.stderr}")
            return 1

    except Exception as e:
        print(f"\n  失败: {e}")
        import traceback
        traceback.print_exc()
        return 1


# ============================================================
# 统一入口
# ============================================================

BACKEND_MARKDOWN = {
    "pdf-craft": to_markdown_pdfcraft,
    "marker": to_markdown_marker,
    "minera": to_markdown_minera,
}

BACKEND_EPUB = {
    "pdf-craft": to_epub_pdfcraft,
}


def main():
    parser = argparse.ArgumentParser(
        prog="pdf-craft-cli",
        description="PDF 转换工具 - 扫描版书籍 -> Markdown / EPUB (纯本地, 零 API)",
    )
    parser.add_argument("-b", "--backend", default="pdf-craft",
                        choices=["pdf-craft", "marker", "minera", "auto"],
                        help="OCR 后端 (默认: pdf-craft)")
    sub = parser.add_subparsers(dest="command")

    # markdown
    p = sub.add_parser("markdown", help="转换为 Markdown")
    p.add_argument("input", help="输入 PDF")
    p.add_argument("output", help="输出 .md")
    p.add_argument("--assets-dir", help="图片目录")
    p.add_argument("--ocr-size", choices=["tiny", "small", "base", "large", "gundam"])
    p.add_argument("--dpi", type=int, default=300)
    p.add_argument("--cover", action="store_true")
    p.add_argument("--no-footnotes", action="store_true")

    # epub
    p = sub.add_parser("epub", help="转换为 EPUB")
    p.add_argument("input", help="输入 PDF")
    p.add_argument("output", help="输出 .epub")
    p.add_argument("--ocr-size", choices=["tiny", "small", "base", "large", "gundam"])
    p.add_argument("--dpi", type=int, default=300)
    p.add_argument("--title", help="书名")
    p.add_argument("--author", help="作者")
    p.add_argument("--language", default="zh")

    # detect
    p = sub.add_parser("detect", help="检测 PDF 类型")
    p.add_argument("input", help="PDF 文件")

    # download-models
    p = sub.add_parser("download-models", help="预下载 OCR 模型")
    p.add_argument("--cache-dir", default="models")
    p.add_argument("--backend", default="pdf-craft")

    args = parser.parse_args()

    if args.command == "detect":
        info = detect_text_layer(args.input)
        print(f"\n  PDF: {args.input}")
        print(f"  文本层: {info['has_text']}")
        print(f"  每页字符: {info.get('avg_chars', 'N/A')}")
        print(f"  总页数: {info.get('pages', 'N/A')}")
        print(f"  说明: {info['reason']}")
        return 0

    if args.command == "download-models":
        if args.backend == "pdf-craft":
            if not _ensure_pdf_craft():
                return 1
            from pdf_craft import predownload_models
            Path(args.cache_dir).mkdir(parents=True, exist_ok=True)
            predownload_models(models_cache_path=args.cache_dir)
            print(f"  模型已下载到 {args.cache_dir}")
            return 0
        else:
            print(f"  {args.backend} 模型会在首次使用时自动下载")
            return 0

    if args.command in ("markdown", "epub"):
        backend = args.backend
        if backend == "auto":
            # 自动选择: 有 pdf-craft 用 pdf-craft, 否则尝试 marker, 再 minera
            try:
                import pdf_craft
                backend = "pdf-craft"
            except ImportError:
                try:
                    import marker
                    backend = "marker"
                except ImportError:
                    try:
                        import magic_pdf
                        backend = "minera"
                    except ImportError:
                        print("  错误: 未找到任何 OCR 后端")
                        print("  请先安装: uv pip install pdf-craft")
                        return 1

        if args.command == "markdown":
            if backend in BACKEND_MARKDOWN:
                return BACKEND_MARKDOWN[backend](args)
            else:
                print(f"  错误: {backend} 不支持 Markdown 输出 (仅 pdf-craft 支持 EPUB)")
                return 1
        elif args.command == "epub":
            if backend in BACKEND_EPUB:
                return BACKEND_EPUB[backend](args)
            else:
                print(f"  错误: {backend} 不支持 EPUB 输出")
                print(f"  EPUB 输出需要 pdf-craft 后端")
                return 1

    parser.print_help()
    return 0


if __name__ == "__main__":
    sys.exit(main())
