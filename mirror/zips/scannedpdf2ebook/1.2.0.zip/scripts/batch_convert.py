#!/usr/bin/env python3
"""
pdf-craft-converter 批量转换脚本
支持多 OCR 后端, 自动跳过已有输出
"""

import argparse
import sys
import time
from pathlib import Path

SCRIPTS_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPTS_DIR))
from pdf_craft_cli import detect_text_layer, auto_ocr_size, BACKEND_MARKDOWN, BACKEND_EPUB


def find_pdfs(directory: str, recursive: bool = False) -> list[str]:
    """查找目录中的 PDF 文件"""
    base = Path(directory)
    pattern = "**/*.pdf" if recursive else "*.pdf"
    return sorted(str(p) for p in base.glob(pattern))


def batch_convert(args):
    """批量转换"""
    pdfs = find_pdfs(args.input_dir, args.recursive)
    if not pdfs:
        print(f"  未找到 PDF 文件: {args.input_dir}")
        return 1

    fmt = args.format
    backend = args.backend
    ocr = args.ocr_size or auto_ocr_size()
    out_dir = args.output_dir

    print(f"\n  批量转换: {len(pdfs)} 个 PDF -> {fmt}")
    print(f"  输入: {args.input_dir}")
    print(f"  输出: {out_dir}")
    print(f"  后端: {backend}")
    print(f"  OCR: {ocr}")
    print()

    Path(out_dir).mkdir(parents=True, exist_ok=True)

    success = 0
    failed = 0
    skipped = 0
    t0 = time.time()

    for i, pdf_path in enumerate(pdfs, 1):
        name = Path(pdf_path).stem

        if fmt == "markdown":
            ext = ".md"
            handler = BACKEND_MARKDOWN.get(backend)
        else:
            ext = ".epub"
            handler = BACKEND_EPUB.get(backend)

        if not handler:
            print(f"  [{i}/{len(pdfs)}] {name} - 跳过 (后端不支持 {fmt})")
            skipped += 1
            continue

        out_path = str(Path(out_dir) / f"{name}{ext}")

        # 跳过已存在
        if Path(out_path).exists() and not args.force:
            print(f"  [{i}/{len(pdfs)}] {name} - 跳过 (已存在)")
            skipped += 1
            continue

        print(f"  [{i}/{len(pdfs)}] {name}... ", end="", flush=True)

        # 构造模拟 args
        class FakeArgs:
            pass
        a = FakeArgs()
        a.input = pdf_path
        a.output = out_path
        a.ocr_size = ocr
        a.dpi = args.dpi
        a.assets_dir = str(Path(out_dir) / "images")
        a.cover = args.cover
        a.no_footnotes = args.no_footnotes
        a.title = name
        a.author = args.author
        a.language = args.language
        a.backend = backend

        try:
            rc = handler(a)
            if rc == 0:
                success += 1
                print("OK")
            else:
                failed += 1
                print("FAIL")
        except Exception as e:
            failed += 1
            print(f"FAIL ({e})")

    elapsed = time.time() - t0
    mins, secs = divmod(elapsed, 60)

    print(f"\n  完成! 成功: {success}  失败: {failed}  跳过: {skipped}")
    print(f"  耗时: {int(mins)}分{secs:.0f}秒")
    print(f"  输出: {out_dir}")
    return 0 if failed == 0 else 1


def main():
    parser = argparse.ArgumentParser(
        prog="batch-convert",
        description="批量 PDF 转换 - 扫描书籍 -> Markdown / EPUB",
    )
    parser.add_argument("input_dir", help="PDF 目录")
    parser.add_argument("output_dir", help="输出目录")
    parser.add_argument("-f", "--format", default="markdown", choices=["markdown", "epub"],
                        help="输出格式 (默认: markdown)")
    parser.add_argument("-b", "--backend", default="pdf-craft",
                        choices=["pdf-craft", "marker", "minera", "auto"],
                        help="OCR 后端 (默认: pdf-craft)")
    parser.add_argument("--recursive", action="store_true", help="递归子目录")
    parser.add_argument("--force", action="store_true", help="覆盖已有文件")
    parser.add_argument("--ocr-size", choices=["tiny", "small", "base", "large", "gundam"])
    parser.add_argument("--dpi", type=int, default=300)
    parser.add_argument("--cover", action="store_true")
    parser.add_argument("--no-footnotes", action="store_true")
    parser.add_argument("--author", help="批量 EPUB 的作者")

    args = parser.parse_args()

    if args.backend == "auto":
        try:
            import pdf_craft
            args.backend = "pdf-craft"
        except ImportError:
            try:
                import marker
                args.backend = "marker"
            except ImportError:
                try:
                    import magic_pdf
                    args.backend = "minera"
                except ImportError:
                    print("  错误: 未找到任何 OCR 后端")
                    return 1

    return batch_convert(args)


if __name__ == "__main__":
    sys.exit(main())
