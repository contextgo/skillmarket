# Font Awesome 6.4.0 图标映射表

## CDN 引入

```html
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css">
```

---

## 侧边栏菜单图标

| 功能 | Font Awesome 6.4.0 | 旧 Remix Icon |
|------|-------------------|---------------|
| 仪表盘 | `fa-solid fa-chart-line` | `ri-dashboard-line` |
| 用户管理 | `fa-solid fa-users` | `ri-user-line` |
| 角色管理 | `fa-solid fa-user-tag` | `ri-team-line` |
| 权限管理 | `fa-solid fa-shield-halved` | `ri-shield-key-line` |
| 系统设置 | `fa-solid fa-gears` | `ri-settings-3-line` |
| 数据统计 | `fa-solid fa-chart-column` | `ri-bar-chart-line` |
| 文件管理 | `fa-solid fa-folder` | `ri-folder-line` |
| 日志审计 | `fa-solid fa-file-lines` | `ri-file-text-line` |
| 消息通知 | `fa-solid fa-bell` | `ri-notification-line` |
| 个人中心 | `fa-solid fa-circle-user` | `ri-user-settings-line` |

---

## 操作按钮图标

| 功能 | Font Awesome 6.4.0 |
|------|-------------------|
| 新增 | `fa-solid fa-plus` |
| 编辑 | `fa-solid fa-pen-to-square` |
| 删除 | `fa-solid fa-trash-can` |
| 查看 | `fa-solid fa-eye` |
| 搜索 | `fa-solid fa-magnifying-glass` |
| 刷新 | `fa-solid fa-rotate` |
| 下载 | `fa-solid fa-download` |
| 上传 | `fa-solid fa-upload` |
| 导出 | `fa-solid fa-file-export` |
| 导入 | `fa-solid fa-file-import` |
| 筛选 | `fa-solid fa-filter` |
| 重置 | `fa-solid fa-rotate-left` |
| 保存 | `fa-solid fa-floppy-disk` |
| 提交 | `fa-solid fa-check` |
| 取消 | `fa-solid fa-xmark` |
| 返回 | `fa-solid fa-arrow-left` |
| 更多 | `fa-solid fa-ellipsis` |
| 设置 | `fa-solid fa-gear` |

---

## 状态图标

| 功能 | Font Awesome 6.4.0 |
|------|-------------------|
| 成功 | `fa-solid fa-circle-check` |
| 警告 | `fa-solid fa-circle-exclamation` |
| 错误 | `fa-solid fa-circle-xmark` |
| 信息 | `fa-solid fa-circle-info` |
| 帮助 | `fa-solid fa-circle-question` |
| 加载中 | `fa-solid fa-spinner fa-spin` |
| 空状态 | `fa-solid fa-inbox` |
| 开发中 | `fa-solid fa-wrench` |
| 未找到 | `fa-solid fa-magnifying-glass` |
| 锁定 | `fa-solid fa-lock` |
| 解锁 | `fa-solid fa-lock-open` |

---

## 导航图标

| 功能 | Font Awesome 6.4.0 |
|------|-------------------|
| 上箭头 | `fa-solid fa-chevron-up` |
| 下箭头 | `fa-solid fa-chevron-down` |
| 左箭头 | `fa-solid fa-chevron-left` |
| 右箭头 | `fa-solid fa-chevron-right` |
| 双左箭头 | `fa-solid fa-angles-left` |
| 双右箭头 | `fa-solid fa-angles-right` |
| 首页 | `fa-solid fa-house` |
| 返回 | `fa-solid fa-arrow-left` |
| 前进 | `fa-solid fa-arrow-right` |
| 面包屑分隔 | `fa-solid fa-chevron-right` |

---

## 表单图标

| 功能 | Font Awesome 6.4.0 |
|------|-------------------|
| 日历 | `fa-solid fa-calendar-days` |
| 时钟 | `fa-solid fa-clock` |
| 邮件 | `fa-solid fa-envelope` |
| 电话 | `fa-solid fa-phone` |
| 手机 | `fa-solid fa-mobile-screen` |
| 密码 | `fa-solid fa-key` |
| 清除 | `fa-solid fa-circle-xmark` |
| 附件 | `fa-solid fa-paperclip` |

---

## 文件类型图标

| 类型 | Font Awesome 6.4.0 |
|------|-------------------|
| 文件 | `fa-solid fa-file` |
| PDF | `fa-solid fa-file-pdf` |
| Word | `fa-solid fa-file-word` |
| Excel | `fa-solid fa-file-excel` |
| 图片 | `fa-solid fa-file-image` |
| 视频 | `fa-solid fa-file-video` |
| 音频 | `fa-solid fa-file-audio` |
| 压缩包 | `fa-solid fa-file-zipper` |
| 代码 | `fa-solid fa-file-code` |

---

## 使用示例

```html
<!-- 侧边栏菜单项 -->
<div class="nav-item active">
  <i class="fa-solid fa-chart-line"></i>
  <span>仪表盘</span>
</div>

<!-- 按钮 -->
<button class="ft-btn ft-btn-primary">
  <i class="fa-solid fa-plus"></i> 新增用户
</button>

<!-- 状态标签 -->
<span class="ft-tag ft-tag-success">
  <i class="fa-solid fa-check"></i> 已启用
</span>

<!-- 空状态 -->
<div class="ft-empty">
  <i class="fa-solid fa-inbox ft-empty-icon"></i>
  <p class="ft-empty-title">暂无数据</p>
</div>
```

---

## 注意事项

1. **版本锁定**：使用稳定的 6.4.0 版本
2. **类名格式**：必须使用 `fa-solid fa-{name}` 格式
3. **不要混用**：禁止同时使用 Remix Icon 和 Font Awesome
4. **CDN降级**：如 CDN 失败，可切换至 `cdnjs` 或 `unpkg`
